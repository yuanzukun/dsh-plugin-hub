#!/usr/bin/env node
// scripts/arch-claims.mjs — 结构判据机检：**ADR 承诺 ↔ 代码现状**（P4 · 2026-09-19）
//
// 为什么要有它：本项目的贯穿性根因是「**无结构判据**」——架构决策写进 ADR 之后，
// 承诺有没有兑现、什么时候被后续决策取代，全靠人记。人记的东西会漂：ADR-197 的终局
// 曾被当成"待办"追，而 ADR-230 已把它的轨迹改过一轮却没人知道。本脚本把**每条 PE
// 架构决策**（= 分不分母，见下）的承诺翻成一条可执行断言，命令/期望/实测/判定一并输出。
//
// 分母出处（**不得自拟条数**）：`nav_graph mode=adrs` 全量 37 条中、锚点匹配
//   /pe-f\d|prompt-enhancer/ 的 **7 条** —— ADR-146(feature:pe-f06) ·
//   ADR-194/197/201/234(module:prompt-enhancer) · ADR-224/230(feature:pe-f01)。
//   采集命令与录制时间见 docs/internal/P4-状态归属-2026-09-19.md §一。
//   治理事件日志可读时脚本**自行交叉核对**这个多重集（S-2），不可读则记 SKIP（不记 PASS）。
//   ⚠ 新增一条 PE 决策（nav_decide）后**必须同步加一行判据**，否则 S-2 立即红——判据面随决策面走。
//
// 判据三档（**不可混算**——混算就是又一次代理指标当判据）：
//   REQUIRED 仓库内可机检、必须成立 —— 失败即**冲突**，exit 1
//   LOCAL    本地治理档 / 治理日志（gitignore，CI 与干净 clone 无此文件）—— 缺文件记 **SKIP**，不记 PASS
//   TARGET   终局目标、尚未达成 —— 必须写明**在册依据**（后续 ADR / 决策档），无依据即冲突
//
// 用法：node scripts/arch-claims.mjs [--check] [--json] [--md] [--write]
//   --check  REQUIRED 失败 / 判据面漂移 → exit 1
//   --md     输出 Markdown 判据表（**投影，勿手抄**）
//   --write  把判据表写入治理档标记区（本地档；文件不存在则跳过）
//
// 投影漂移的判定口径（T2 · 2026-09-27，**三态**——本会要的"读数可解释"就落在这里）：
//   投影里「期望/实测/判定」列**是环境的函数**（治理日志可不可读决定 A194-4/S-2 走实判还是 SKIP）。
//   故判据面与环境派生列**分开判**：
//     · 判据面一致 + 档内读数取自**另一种**环境 ⇒ `stale-readings`：陈旧读数，**不判漂移**、打印提示；
//     · 判据面变了（加/删/改断言、表体缺行、指纹被替换） ⇒ `drift`：**exit 1**；
//     · 判据面一致 + **同一种**环境读数却变了 ⇒ `drift`：环境解释不了，仍 exit 1（不放宽）。
//   ⚠ 反面教训（本仓实测 2026-09-27）：只按"档区与本次实算逐字相等"判，则投影必然只对**生成它的
//     那个环境**成立——同一份治理根态投影，带 PE_GOV_ROOT 跑 exit 0、不带则 exit 1（gate 整链跟着红）。
//     那是**假红**（判据表一个字未变），与假绿同属"读数不可解释"。
//   ⚠ `--write` 请**在本形态**跑；跨形态写出的投影会被判 stale-readings（提示刷新，不是失败）。

import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
// 状态出口契约（P5）：本环的 SKIP/冲突/漂移 → 三态映射只在**下面 --check 出口一处**作出。
import { emitRingState, installCrashGuard } from './lib/ring-state.mjs';
// D-10 修正批（2026-10-14）：剥注释器收敛到单一事实源（原为内联「先块后行」实现，会吞代码）。
import { codeOnly as importedCodeOnly } from './lib/code-only.mjs';
import * as libManifest from './lib/lib-manifest.mjs';
// 声明面三面相等（甲-1）的判定逻辑——单一事实源，纯函数可内存变异自证（S-10 消费）。
import { compareDeclaredSurface } from './lib/declared-surface.mjs';
import { resolveGovRoot } from './lib/gov-root.mjs';

installCrashGuard('arch-claims');
const require = createRequire(import.meta.url);
const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const ARGS = process.argv.slice(2);
const has = (f) => ARGS.includes(f);

const DOC = 'docs/internal/P4-状态归属-2026-09-19.md';
const MARK_BEGIN = '<!-- ARCH-CLAIMS:BEGIN -->';
const MARK_END = '<!-- ARCH-CLAIMS:END -->';
const GOV_EVENTS = process.env.PE_NAV_EVENTS
  || path.join(resolveGovRoot(), '.internal', 'events.jsonl');
// 读数快照环境标签（T2）：投影里「期望/实测/判定」列**是环境的函数**（治理日志可不可读决定
//   A194-4/S-2 走实判还是 SKIP）。故投影必须自述「这份读数是在哪种环境下取的」——否则读者
//   无法分辨「判据变了」与「只是换了个环境跑」，而那正是本会要的可解释性。
const SNAP_ENV = fs.existsSync(GOV_EVENTS) ? 'gov-readable' : 'gov-unreadable';
// A-2（2026-10-19）：`--write` 时记下的 HEAD —— **只用于漂移时点名具体文件**。
//   ⚠⚠ 硬约束：它**不得进入逐字比对区**。HEAD 每提交一次就变，若参与逐字比对，
//     则**每次 commit 都会把投影判成漂移**（本仓最忌的假红）。故它与指纹行一起被
//     `stripFp` **两侧对称**剥掉，只在 FAIL 时从档区里读出来用（--check 绿时不打印）。
let SNAP_HEAD = null;

const abs = (p) => path.join(ROOT, p);
const exists = (p) => fs.existsSync(abs(p));
const read = (p) => fs.readFileSync(abs(p), 'utf8');
const lines = (p) => read(p).split('\n').length;   // 口径：物理行 = split('\n').length
const occurrences = (s, re) => (s.match(re) || []).length;

/**
 * 剥注释后的代码文本（P2 复核处置批 2026-10-13 · 处置 F5）。
 * 病历：`A197-3` 原用 `occurrences(read('lib/index.cjs'), /new Function\(/g)` ⇒ **注释里提到
 *   `new Function(` 也算一处**（实测 `lib/index.cjs:39` 的载体约束注释命中 ⇒ 读数 2，而同批
 *   报告/文档写 1）。⇒ 判据读数被"说明文字"污染，与判据意图（**真装配点** = 0）不符。
 * 现改为剥注释后计数（与 `dead-code-gate.mjs` 的 R5 引用判定**同一口径**），读数 = 1（真装配点）；
 * **判定式不变**（仍严格 `=== 0`），仍属「在册未达」。
 *
 * ⚠ D-10 修正批（2026-10-14）：**实现已收敛到单一事实源 `scripts/lib/code-only.mjs`**
 *   —— 原内联实现「先块后行」会因 `//` 注释里的 `/*` 而吞掉其后真实代码（D-10 病历）。
 *   本处只换实现、**判定式与扫描面一字未动**。
 *
 * ⚠⚠ P3-2e（2026-10-14）：该单一事实源又经 **R-1** 修正 —— D-10 的「先逐行后块」在
 *   「**单行内闭合的块注释、其中含 `//`**」上**比修前更坏**（会把闭合符一起剥掉 ⇒ 留下
 *   未闭合的块注释起点 ⇒ 一路吞到下一个块注释结束符）；现改为**单趟左→右扫描**。本处同样**只换实现**。
 *   ⚠ **工具链单点提示（`D-16` 扩面，见 `A197-5` 处注释）**：本处 `codeOnly` 的读数**直接决定**
 *     `A197-3` / `A197-5` 的判定结果 ⇒ 本族与 `R5` **同属**「读数可信度依赖剥离器正确性」。
 */
const codeOnly = importedCodeOnly;

/**
 * **装配用** `new Function` 求值点的形态（P2 载体决策 A 批 2026-10-13 · A197-3 改判）。
 * 装配点的特征签名：第一实参是**字符串字面量 `'harness'`**（BODY 的求值入参名）——
 * `new Function('harness', BODY)(harness)`。与之相对，`new Function(pureText + …)` 这类
 * **非装配**求值（PURE 片段提取）首参是表达式 ⇒ 不匹配。
 * ⚠ 本形态**只用于分辨「装配点」**，不主张覆盖所有 `new Function` 用法（见 A197-3 的不覆盖声明）。
 */
const ASSEMBLY_EVAL = /new Function\(\s*'harness'/g;
const list = (p) => fs.readdirSync(abs(p));

/**
 * 线上 RPC 注册面派生（与 rpc-manifest.mjs 同一规则：扫插件双半部的 harness.handle）。
 * ⚠ P2-3（2026-10-13 拆分批）：`lib/index.cjs` 拆域后原生注册面分布在 `lib/*.cjs`
 *   （config/* → rpc-config.cjs；voice/* → rpc-voice.cjs）。若仍只扫 `lib/index.cjs`，
 *   `native` 静默变 0 ⇒ 与 rpc-manifest 派生面**不一致**（两处事实源漂移）。
 *   ⇒ 与 rpc-manifest.mjs 同步：枚举 `lib/` 下全部非生成 .cjs（排除构建产物 client.cjs）。
 */
function liveMethods() {
  const grab = (f) => [...read(f).matchAll(/harness\.handle\(\s*'([^']+)'/g)].map((m) => m[1]);
  // ⚠ P2 窄复核处置批（2026-10-13 · F-1）：与 dead-code-gate / rpc-manifest 共用同一事实源
  const native = libManifest.libHandwrittenTargets().flatMap((f) => grab(f));
  return { native, bundled: grab('plugin-host.js') };
}

/**
 * PE-F01 **域清单**（ADR-230 的声明面）。
 *
 * ⚠ P2-3（2026-10-13 拆分批）改判：原判据是「**单文件内**的域行范围表」——
 *   行数和 == `lines('lib/index.cjs')`、首域 1 起、连续无缝、末域止于末行。
 *   **拆分后该判据对象整体消失**（域不再共享一个文件的行空间）⇒ 依既有退役规则，
 *   改判合法。**但不许悄悄变松** ⇒ 换成**同一意图的等值集形态**（覆盖 100% / 无缝隙 /
 *   无重叠 → 文件集等值 + 无未接线孤儿），牙齿**同等或更强**：
 *     · 旧：表内行区间必须无缝覆盖 1..n（漏一段 ⇒ 红）
 *     · 新：`lib/` 磁盘 .cjs 集合必须与下表**逐键等值**（**多一件即 FAIL** —— 与 R4 的
 *       `src/host` 等值集同思路）；且**每个拆分产物必须被入口 `require` 接线**（声明了
 *       却没接线 = 孤儿模块 ⇒ 红）。后者是新判据**多出**的牙齿（旧判据管不到"文件级孤儿"）。
 *
 * ⚠ 本判据**不覆盖**（如实声明）：① 不再判「单文件内的行区间切分」（对象已消失）；
 *   ② 不判各文件**内部**的代码是否属于其声明的域（那是 code review 面，非机检面）；
 *   ③ 不判 `src/host/**`（那由 R4 的等值集管）。
 */
const PE_F01_LIB_MANIFEST = {
// 历史沿革（判据对象已随 P2-3 拆分整体消失，保留供追溯）：
//   · `lib/index.cjs` 行数轨迹：839（P1-a 前）→ 786（P1-a 缩批）→ 656（P1-c 执行器退役）
//     → 319（P2-1 清死簇）→ **109（P2-3 拆分，`lines()` 口径）**。
//   · 旧 A230-1 判「单文件内域行区间之和 == lines('lib/index.cjs') 且连续无缝」——
//     拆分后域不再共享一个文件的行空间 ⇒ **该判据对象整体消失** ⇒ 改判（见上方说明）。
  // —— P2-3 拆分批产物（本次新增的域模块；`PE_F01_SPLIT_PRODUCTS` 同步维护）——
  'index.cjs': 'D0 装配入口（requires · BODY · new Function 桥接 · module.exports · apply）',
  'harness.cjs': 'D1 harness facade（BODY 求值入参）',
  'rpc-http.cjs': 'D2 RPC 网关与 HTTP 栅栏（来源校验 / 1MiB 上限 / 路由注册）',
  'rpc-config.cjs': 'D3 配置持久化（config/get · config/set）',
  'rpc-voice.cjs': 'D4 语音 RPC（voice/status）',
  // —— 拆分前既有的 lib 模块（本批未拆分，登记以维持等值集语义）——
  'sys.cjs': '既有：环境 / 路径 / probe',
  'asr.cjs': '既有：voice 配置净化 / status（CHG-117 起：清口水词已移至 client 半部）',
  'net-proxy.cjs': '既有：出网代理',
  'platform-service.cjs': '既有：跨平台服务',
  'integrity.cjs': '既有：sha256',
  'maintain-lib.cjs': '既有：装配维护',
  'rpc-schema.cjs': '既有：RPC schema 单一事实源',
  'client.cjs': '⚠ 构建产物（scripts/build-client.mjs 生成；非手改面，仍须登记）',
};

/** P2-3 拆分批的**域模块产物**白名单（须被入口 require 接线；见 A230-5）。 */
const PE_F01_SPLIT_PRODUCTS = ['harness.cjs', 'rpc-http.cjs', 'rpc-config.cjs', 'rpc-voice.cjs'];


/** 一条断言：kind ∈ 行为|结构|门禁|见证|索引|目标；fn 返回 {pass, actual} */
const A = (id, kind, detail, expect, fn) => ({ id, kind, detail, expect, fn });
const ok = (actual) => ({ pass: true, actual });
const no = (actual) => ({ pass: false, actual });
const assert = (cond, actual) => (cond ? ok(actual) : no(actual));

/** 门禁类断言：子进程跑既有门禁，退出码为判据（**不重复实现**对方规则） */
const gate = (id, scriptArgs, detail) => A(
  id, '门禁', detail, `exit 0（node ${scriptArgs.join(' ')}）`,
  () => {
    try {
      execFileSync(process.execPath, scriptArgs, { cwd: ROOT, encoding: 'utf8', timeout: 60000, stdio: ['ignore', 'pipe', 'pipe'] });
      return ok('exit 0');
    } catch (e) {
      return no(`exit ${e.status === undefined ? 'ERR:' + String(e.message).slice(0, 60) : e.status}`);
    }
  },
);

/** 见证类断言：断言"更细的行为证据还在"——防止判据引用悬空（证据被删而声称仍验过） */
const witness = (id, file, cases, detail) => A(
  id, '见证', detail, `${file} 含 ${cases.join('/')}`,
  () => {
    if (!exists(file)) return no(`${file} 不存在（证据悬空）`);
    const src = read(file);
    const miss = cases.filter((c) => !src.includes(c));
    return miss.length ? no(`缺 ${miss.join(',')}`) : ok(`${cases.length}/${cases.length} 在册`);
  },
);

// ─────────────── 门禁链 / 行尾：派生读取（F4 · F5 · 2026-09-26 红队修复波 1）───────────────

/** 门禁链**点名面**：本判据表认可的环（每条须写明"本表为何需要它"）。
 *  判据形态 = 点名集合 ≡ package.json 链上实际集合（**双向相等**）。
 *  ⚠ 为何保留点名面而不做"纯派生"：两条负控互斥——"加一环不更新期望→红"要派生侧多出来，
 *    "删掉一环→红"要点名侧仍点名。只从 package.json 取集合的话，删环会把两侧一起缩小，
 *    判据恒绿。故：本表 = 点名面，package.json = 事实面，任一侧单独变动都红。 */
const GATE_RINGS = [
  { id: 'dead-code', script: 'scripts/dead-code-gate.mjs', why: 'R1–R4 死代码 / 装配契约（ADR-224）' },
  { id: 'rpc', script: 'scripts/rpc-manifest.mjs', why: 'RPC 注册面派生一致（ADR-201 / ADR-230）' },
  { id: 'prompts', script: 'scripts/sync-prompts.mjs', why: '提示词生成区不漂移' },
  { id: 'arch-claims', script: 'scripts/arch-claims.mjs', why: '本判据表自身（ADR-234）' },
  { id: 'cards', script: 'scripts/card-arch-consistency.mjs', why: '知识卡 ↔ 架构档一致性（册 A · 2026-09-25 接入）' },
  // ⭐ CHG-301：拆包前置两道 cross 环（第 6、7 环）。⚠ 本表与 gate.mjs 的 RINGS 是**双向锁**，
  //   必须同批同序增删；只改一侧 ⇒ B234-1 的 `extra` / `lost` 腿必红。
  { id: 'pkg-identity', script: 'scripts/split-identity.mjs', why: '两包 identity 不撞（撞了宿主静默 `warns= []`，只能仓内机检拦）' },
  { id: 'shared-fns', script: 'scripts/split-shared-fns.mjs', why: '两包各一份的 7 个共享 host 函数逐字节相等（漂移 = 同一输入两种结果）' },
];

/** 从命令串摘出 `node scripts/xxx.mjs [args]`，顺序即链序 */
function parseRings(cmd) {
  const out = [];
  const re = /node\s+(scripts\/[\w.\-]+\.mjs)([^&|]*)/g;
  let m;
  while ((m = re.exec(cmd)) !== null) out.push({ script: m[1], args: (m[2].match(/--[\w-]+/g) || []), pos: m.index });
  return out;
}

/** 摘 `scripts/<名>.mjs` 字面量（首次出现序、去重） */
function ringLiterals(text) {
  const seen = [];
  const re = /scripts\/([\w.\-]+\.mjs)/g;
  let m;
  while ((m = re.exec(text)) !== null) { const s = 'scripts/' + m[1]; if (!seen.includes(s)) seen.push(s); }
  return seen;
}

/** 剥块注释与行注释：入口脚本的头注里普遍写了自身用法（`用法：node scripts/gate.mjs`），
 *  不剥会把入口脚本自己当成一环（未点名 → 假红）。同理，被注释掉的环不算环。 */
function stripCommentLines(text) {
  return text
    .split('\n')
    .map((l) => l.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/, ''))
    .join('\n');
}

/** 派生门禁链：① 直接解析 package.json.scripts.gate；② 若该命令只调一个**入口脚本**
 *  （编排器形态，如 `node scripts/gate.mjs`），下探一层读入口脚本，按首次出现序取其内 `scripts/*.mjs`。
 *  ⚠ 波 2（F1 gate.mjs）接口：各环须以 `scripts/<名>.mjs` 字面量出现在入口脚本内，
 *    否则此处置零环 → 判红（fail-closed，不静默取空集）。
 *  ⚠ 归因（2026-09-27 · I4）：零环时**必须说得出零环是怎么来的**。只报「链 0 环」会把读者
 *    引到点名面 / package.json 上找并不存在的问题（真凶在下探面），故一并返回 diag，
 *    归因文案见 chainZeroReason；判定语义不变（零环照样判红）。 */
function gateChain() {
  const cmd = String(require(abs('package.json')).scripts.gate || '');
  let rings = parseRings(cmd);
  let source = 'package.json';
  let nested = false;
  // 归因三态（state）：not-applicable 本条腿不适用（命令里 ≥2 环，无需下探）· nested 下探成功
  //   · zero-literal 入口在但取不到环 · missing 入口不在位 · unparsed 命令里认不出入口
  let diag = { state: 'not-applicable', entryScript: null, entryExists: false, suspicious: false };
  if (rings.length < 2) {
    // ⚠ 入口只从命令里的 `scripts/<名>.mjs` **字面量**取；一条都没有（如 `node "$ENTRY"`、变量拼接）时
    //   **不做「模糊匹配最近路径」的猜测**——猜出来的入口会把读者指到另一个错文件上，等于用第二个
    //   错误回答 I4（这条腿的意义正是不再瞎指）。此时如实说「认不出」，并如实标可疑形态。
    //   本仓 gate 若改用变量拼接调用入口，此腿**照样判红**（零环），正如实报告为「认不出入口」。
    //   ⚠ 形态与 parseRings 同一（必须带 `node ` 前缀）：放宽成「忽略前缀」会让「别名/包装器直接调入口」
    //     这一类命令从判红变成下探成功——那是**语义变更**，不属于本次归因修复的范围。
    const literals = [...cmd.matchAll(/node\s+(scripts\/[\w.\-]+\.mjs)/g)].map((m) => m[1]);
    const entry = literals.find((s) => exists(s)) || literals[0] || null;
    if (entry && exists(entry)) {
      // ⚠ 剥注释再扫：入口脚本的头注里普遍写了自身用法（\`用法：node scripts/gate.mjs\`），
      //   不剥会把入口脚本自己当成一环（未点名 → 假红）。同理，被注释掉的环不算环。
      const seen = ringLiterals(stripCommentLines(read(entry)));
      const self = entry.replace(/^\.\//, '');
      for (let i = seen.length - 1; i >= 0; i -= 1) if (seen[i] === self) seen.splice(i, 1);
      // 编排器形态下旗标由入口脚本自己传（不在 package.json 字面量里），故 args 留空并置 nested。
      // ⚠ 旧实现由此**整体关闭**旗标腿（nested ? [] : …）——那会让 card-arch 的旗丢失一并漏检
      //   （复核席实测的净回归）。现改为：nested 时旗标改从**入口脚本自身文本**取证（见 chainFlags），
      //   只把"字面量里读不到旗"降级为"改看入口脚本"，不放弃这一腿。
      rings = seen.map((s, i) => ({ script: s, args: [], pos: i }));
      // ⚠ 零环也置 source/nested：下探**确实发生过**（读的确实是这份入口脚本），只是它没有字面量。
      //   若此处不置，读数里的「源」会写成 package.json —— 那又是一次错误归因（I4 要关的正是这个）。
      source = entry + '（编排器入口，下探一层）';
      nested = true;
      diag = { state: seen.length ? 'nested' : 'zero-literal', entryScript: entry, entryExists: true, suspicious: false };
    } else if (entry) {
      diag = { state: 'missing', entryScript: entry, entryExists: false, suspicious: false };
    } else {
      // 命令面认不出入口：如实说「认不出」。suspicious = 命令里出现了变量拼接 / 插值 / 字符串拼接形态
      //   （只是提示可能的原因，**不作为入口指认**——没有可指认的入口就写成 null）。
      const suspicious = /\$\{|\$[A-Za-z_][\w]*|%[A-Za-z_][\w]*%|\+\s*["']/.test(cmd);
      diag = { state: 'unparsed', entryScript: null, entryExists: false, suspicious };
    }
  }
  // ⚠ 不再用 `/npm run/.test(cmd)` 判 nested：那会让「命令里带 npm run」把旗标腿整体带偏
  //   （且在编排器下探已成功时属于误判）。nested 只认"下探确实发生"。
  return { cmd, rings, source, nested, entryScript: diag.entryScript, diag };
}

/** 零环归因文案（I4）：把「链上取不到环」回答到**真正的面**上，并给出可执行的检查动作。
 *  两条禁令（都是这条腿存在的理由）：① 认不出入口时**不得猜一个路径**——宁说「认不出」，不给假指向；
 *  ② 措辞不得读起来像「点名面 / package.json 有问题」——零环时点名面根本没被比对过，那是最初的错误归因。
 *  ⚠ 本节只改**归因与措辞**：任何 state 都仍然判红（fail-closed，见 B234-1）。 */
function chainZeroReason(diag) {
  const e = diag.entryScript;
  switch (diag.state) {
    case 'missing':
      return `⚠ 编排器入口不在位：${e}（判据知道它，是因为 package.json.scripts.gate 指向它）`
        + '——链上取不到环来自**入口缺位**（读数里只会剩入口脚本自己，那不是一环），'
        + '不是点名面/package.json 的问题；检查该入口脚本是否已建并已提交（F1 gate.mjs 波次是否落地）';
    case 'zero-literal':
      return `⚠ 编排器入口解析到 0 环：请检查 ${e} 是否以**字面量** \`scripts/<名>.mjs\` 调用各环`
        + '（本判据按下探字面量取环，不解释变量拼接 / shell 展开；零环会一路被误报成点名面问题，真因就在这里）';
    case 'unparsed':
      return '⚠ 认不出编排器入口：package.json.scripts.gate 的命令面里没有 \`node scripts/<名>.mjs\` 字面量'
        + (diag.suspicious ? '（命令含变量拼接/插值形态，疑似入口由变量给出）' : '')
        + '，故无从下探、也无从指认入口；本仓 gate 须以字面量调用入口脚本（编排器形态见 gate 链约定）';
    default:
      return '';
  }
}

/** 环脚本是否**实装** --check：识别 argv 检索的多种真实写法（各环不统一，实测 2026-09-26）：
 *    \`has('--check')\`（arch-claims / card-arch-consistency）· \`args.includes('--check')\`（rpc-manifest）
 *    · \`process.argv.includes('--check')\`（sync-prompts）——变量名任意、接收者须是 args/argv/ARGV 之类。
 *  ⚠ 不得退化成"文中出现 --check 就算实装"：头注/注释里普遍写了用法（本文件即如此），
 *    那样会把**没实装**的脚本判成实装。故先剥注释行，再要求"接收者 + includes/has"形态。 */
function implementsCheck(p) {
  if (!exists(p)) return false;
  const code = read(p)
    .split('\n')
    .map((l) => l.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/, ''))   // 剥块注释与行注释
    .join('\n');
  return /(?:process\.)?(?:argv|args|ARGV|ARGS|[A-Za-z_$][\w$]*Args)\s*\.\s*includes\s*\(\s*['"]--check['"]\s*\)/.test(code)
    || /has\s*\(\s*['"]--check['"]\s*\)/.test(code);
}

/** 行尾三列读数（F5）：`git ls-files -z --eol`。
 *  列序 = <i/> <w/> <attr/> [<eol=>] \t <path>；用 -z 防文件名含空白/换行被拆错列。 */
function eolRows() {
  if (!exists('.git')) return null;                     // 非 git 检出（发行包解包）→ 不可判
  let raw = '';
  try {
    raw = execFileSync('git', ['ls-files', '-z', '--eol'], { cwd: ROOT, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, timeout: 60000 });
  } catch (e) { return { error: String(e.message).slice(0, 80) }; }
  const rows = [];
  for (const rec of raw.split('\0')) {
    if (!rec) continue;
    const tab = rec.indexOf('\t');
    if (tab < 0) { rows.push({ file: rec, raw: true }); continue; }
    const f = rec.slice(0, tab).trim().split(/\s+/);
    const strip = (s, p) => (s && s.startsWith(p) ? s.slice(p.length) : s);   // --eol 三列带 i/ w/ attr/ 前缀
    rows.push({
      index: strip(f[0], 'i/') || '?',
      worktree: strip(f[1], 'w/') || '?',
      attr: strip(f[2], 'attr/') || '?',
      eol: f[3] || '',
      file: rec.slice(tab + 1),
    });
  }
  return { rows };
}

/** 字节级往返：字节 --utf8 解码--> 串 --utf8 编码--> 字节 必须相等。
 *  不等 ⇒ 判据读到的"文本"与磁盘不是同一份（编码被换过），行尾断言会静默失效。 */
function roundTripOk(f) {
  const buf = fs.readFileSync(path.join(ROOT, f));
  return Buffer.from(buf.toString('utf8'), 'utf8').equals(buf);
}

process.env.DSH_ENHANCER_NO_INDEX = '1';          // 与仓库其它 lib 测试同口径：不写进程索引
const indexMod = require(abs('lib/index.cjs'));

// ───────────────────────────── 判据表（1 ADR = 1 行） ─────────────────────────────

const CLAIMS = [
  {
    adr: 'ADR-146', anchor: 'feature:pe-f06', at: '2026-09-12', level: '已兑现',
    promise: 'RPC 入口显式来源边界（同源校验 / 跨站拒 / 无来源头放行 / 1MiB 上限）+ .cmd 值统一 cmdSafeValue 安全化',
    assertions: [
      A('A146-1', '行为', '来源栅栏四态（跨站 / 跨源 / Origin:null 拒；同源 / 无头放行）', '6/6 态正确', () => {
        const R = (h) => ({ headers: h || {} });
        const H = { host: '127.0.0.1:3080' };
        const cases = [
          [indexMod.isTrustedRpcRequest(R(H)), true, '无来源头'],
          [indexMod.isTrustedRpcRequest(R({ ...H, origin: 'http://127.0.0.1:3080', 'sec-fetch-site': 'same-origin' })), true, '同源'],
          [indexMod.isTrustedRpcRequest(R({ ...H, origin: 'https://evil.example', 'sec-fetch-site': 'cross-site' })), false, '跨站'],
          [indexMod.isTrustedRpcRequest(R({ ...H, origin: 'https://evil.example' })), false, '跨源'],
          [indexMod.isTrustedRpcRequest(R({ ...H, 'sec-fetch-site': 'cross-site' })), false, '仅跨站标记'],
          [indexMod.isTrustedRpcRequest(R({ origin: 'null' })), false, 'Origin:null'],
        ];
        const bad = cases.filter(([got, want]) => got !== want);
        return assert(!bad.length, bad.length ? `错 ${bad.map((c) => c[2]).join(',')}` : '6/6 态正确');
      }),
      A('A146-2', '行为', '1MiB 请求体上限', '超限 → __tooLarge；正常体照常解析', async () => {
        const { EventEmitter } = require('node:events');
        // P2-3（2026-10-13 拆分批）：RPC_BODY_LIMIT 随「RPC 网关域」移至 lib/rpc-http.cjs（重锚，非放宽）
        const lim = read('lib/rpc-http.cjs').match(/RPC_BODY_LIMIT\s*=\s*(\d+)\s*\*\s*(\d+)/);
        const size = lim ? Number(lim[1]) * Number(lim[2]) : 0;
        const req = new EventEmitter();
        req.destroy = () => {};
        const p = indexMod.readBody(req);
        req.emit('data', Buffer.alloc(1024 * 1024 + 1));
        const over = await p;
        const req2 = new EventEmitter();
        const p2 = indexMod.readBody(req2);
        req2.emit('data', Buffer.from('{"method":"config/get"}'));
        req2.emit('end');
        const normal = await p2;
        return assert(size === 1024 * 1024 && over.__tooLarge === true && normal.method === 'config/get',
          `上限 ${size} B｜超限 ${over.__tooLarge === true ? '__tooLarge' : '未短路'}｜正常体 ${normal.method === 'config/get' ? '解析成功' : '解析失败'}`);
      }),
      // A146-3（`cmdSafeValue`：剥双引号 / 折 CRLF / 按需转义 %）**随 P2-1 清死簇退役**：
      //   其判据对象 `cmdSafeValue` 的唯一调用点 = 执行器 `.cmd` / schtasks 任务生成
      //   （`buildExecutorTaskXml`/`spawnExecutor` 族），该族已随 P1-c 执行器退役整体消失；
      //   P2-1 实测「簇外引用只剩注释」后把函数本体与该导出面一并删除 ⇒ **无被判对象**。
      //   ⚠ 这不是改浅：若保留原断言，`indexMod.cmdSafeValue` 为 undefined ⇒ `c(...)` 抛错，
      //     该条**永远为红**（假红）；若改成「无此函数就算过」则**永远为真**（假绿，同
      //     A201-3/S-5 先例）。两者都比退役更差，故依「判据随被测对象一并退役」整条删除。
      //   ⚠ 不丢信息：ADR-146 的行为面仍由 A146-1（来源栅栏四态）/A146-2（1MiB 上限）/
      //     A146-4（端到端冒烟见证）覆盖；被删的只是「.cmd 注入面安全化」这一子面。
      //   ⚠ 门禁盲区（登记，本轮不修）：`.cmd` / schtasks 任务生成的**注入面**自此**再无任何
      //     判据在看**（A146-3 已退、其下 RPCG-02/RPCG-04 两条亦退）。当前该面自身也已无代码，
      //     故不是活缺陷；但**若将来重新引入命令注入点，判据面必须同步补回**。
      witness('A146-4', 'test/rpc-guard.test.cjs', ['RPCG-01', 'RPCG-03', 'RPCG-04', 'RPCG-05'], '端到端冒烟证据仍在册（403/413/405/栅栏放行）'),
    ],
  },
  {
    adr: 'ADR-194', anchor: 'module:prompt-enhancer', at: '2026-09-12', level: '部分兑现',
    promise: '判定「需要架构重构，分期执行、不推倒重写」：①P0 死层退役 + 协议事实源由注册面派生；②P1 host 半部改原生模块；③P2 规范收敛；④P3 待验证',
    assertions: [
      // P1-c（2026-10-13）：src/host 再收缩 7 件/33 行 → **5 件/18 行**（`plugins.js` 与 `update.js`
      //   随「设置第三 tab 退役 + 更新执行器退役」一并删除）⇒ 事实同步。
      //   P1 余账批再 +1 行（pure.js 的退役说明注释）⇒ 实测 5 件 / **24 物理行**；判据强度不变（仍为严格等号）。
      A('A194-1', '结构', '①P0 死层退役（src/host 收敛）', '5 件 / 24 物理行', () => {
        const files = list('src/host');
        const n = files.reduce((a, f) => a + lines(`src/host/${f}`), 0);
        return assert(files.length === 5 && n === 24, `${files.length} 件 / ${n} 行`);
      }),
      A('A194-2', '结构', '①协议事实源改由注册面派生（废除 protocol.js）', 'src/protocol.js 不存在且 scripts/rpc-manifest.mjs 存在', () => {
        const gone = !exists('src/protocol.js');
        const born = exists('scripts/rpc-manifest.mjs');
        return assert(gone && born, `protocol.js ${gone ? '已废除' : '仍在'} / rpc-manifest.mjs ${born ? '在位' : '缺失'}`);
      }),
      A('A194-3', '结构', '①dead-code-gate 增可达性/一致性规则', '含 R1–R4 四规则', () => {
        const src = read('scripts/dead-code-gate.mjs');
        const rules = ['R1', 'R2', 'R3', 'R4'].filter((r) => src.includes(`'${r}'`) || src.includes(`[${r}]`) || new RegExp(`\\b${r}\\b`).test(src));
        return assert(rules.length === 4, `命中 ${rules.join('/')}`);
      }),
      A('A194-4', '索引', '④索引侧新建 PE-F07「宿主基础层与插件管理面」', `治理日志可读时含 PE-F07 节点（${GOV_EVENTS}）`, () => {
        if (!fs.existsSync(GOV_EVENTS)) return { skip: true, actual: '治理日志不可读（CI/干净 clone 预期）' };
        const hit = fs.readFileSync(GOV_EVENTS, 'utf8').split('\n').filter((l) => l.includes('PE-F07')).length;
        return assert(hit > 0, `日志内 PE-F07 出现 ${hit} 次`);
      }),
      // A194-5（`'②P1 host 半部改原生 Node 模块（真 require）'`：`plugin-host.js` 内 `require(` > 0）
      //   **随 P2-0 退役**（2026-10-13）。退役依据（ADR 原文，`/mnt/d/FF/.internal/events.jsonl`）：
      //   · ADR-197 §① 已把「换装载形态」**改判**为「前置项」——其 pending 依据原文：「ADR-230
      //     修订该轨迹：改为按 9 域分批（首批 D8），且**换装载形态是拆分收益的前置项**」；
      //   · ADR-230 decision ③ 二次降级为「**不立项**」：「`plugin-host.js` 内 `require(`=0 是
      //     **结构性约束不是可优化项**……终局要让它们彻底模块化，前提是先换装载形态」。
      //   ⇒ 本条的「终局目标」地位已被两次改判取代，**已无消费方**。
      //   ⚠ **逻辑互斥是本条最硬的退役理由**：它与 A230-2（同文件 `require(` == 0，当前 PASS）
      //     谓词方向相反，两条并存 ⇒ 判据面永久含一对**不可能同真**的断言，读者无法分辨现行口径。
      //   ⚠ **不是改浅**：① A230-2 **保留且不得改浅**——它是 ADR-230 自己设的**触发绊线**
      //     （「若实测到拆分被无 require 硬墙挡住，再回到是否立项换装载形态」），载体一变即红，
      //     是功能不是缺陷；② 本条承载的轨迹**由 ADR-197 自身断言继续在册**（A197-1 `≤120 行`
      //     已由 P2-3 拆分**真实达标**；A197-3 已由 `UD-0013`（载体选 A）**改判为**
      //     「装配用求值点恰好一处且限定入口」并**通过**）⇒ **信息不丢**，且两条现均**非**「在册未达」。
      //   ⚠ **不得**改成恒真 / skip / 区间 / 白名单绕过（同 A201-2·A201-3·S-5·B234-4 的处置惯例）：
      //     恒真即假绿（A201-3 先例），skip 即把「已作废」谎报成「本地面缺位」。
    ],
    // pending 段随 A194-5 退役一并清空：原唯一条目（A194-5 的「载体折叠未换」依据）已随该断言
    // 退役而失去判据对象；同一条依据**仍完整保存在 ADR-197 的 pending（A197-1 / A197-3）里**
    //（2026-10-13 更新：其中 A197-3 已由 `UD-0013` 关闭该轨迹、A197-1 已真实达标
    //  ⇒ 两条**均不再是「在册未达」**，pending 条目保留作决定留痕）⇒ 故不丢信息
    //  （S-3 只要求「每条 `kind === '目标'` 的断言有依据」，无此类断言即无此义务）。
  },
  {
    adr: 'ADR-197', anchor: 'module:prompt-enhancer', at: '2026-09-12', level: '部分兑现',
    // ⚠ level 由「在册未达」改为「**部分兑现**」（2026-10-13 · 载体决策 A / `UD-0013`）：
    //   A197-1（≤120 行）已由 P2-3 拆分**真实达标**（109 行）；A197-3 已**改判并通过**
    //   （「装配用求值点恰好一处且限定入口」）；A197-2/A197-4 一直通过。
    //   ⚠ 唯一仍**未兑现**的是 promise 里的两项：①「领域逻辑分层」的终局形态、
    //     ②「自建基础设施换官方缝」。⇒ 取「部分兑现」而非「已兑现」（**不为好看而改**）。
    //   ⚠ 另：promise 原文含「弃 chunk/marker/new Function 装配」一节 —— 该节已由 `UD-0013`
    //     裁定**关闭**（载体选 A：保动态安装）。promise 文本属 ADR 历史原文，本批**不改史**；
    //     其失效由 A197-3 自身的改判注释与上面这段说明承载。
    promise: '终局目标架构：lib/index.js ≤120 行只做装配 + 领域逻辑分层 + 自建基础设施换官方缝 + 弃 chunk/marker/new Function 装配',
    assertions: [
      A('A197-1', '目标', '装配薄化：lib/index.cjs ≤ 120 行', '≤120 行', () => {
        const n = lines('lib/index.cjs');
        return assert(n <= 120, `${n} 行`);
      }),
      A('A197-2', '结构', '弃孤儿产物 plugin-client.js', '磁盘无、files 白名单无、构建不产出', () => {
        const disk = !exists('plugin-client.js');
        const whitelist = !JSON.stringify(require(abs('package.json')).files).includes('plugin-client.js');
        const builder = !read('scripts/build-client.mjs').includes("'plugin-client.js'");
        return assert(disk && whitelist && builder, `磁盘${disk ? '无' : '有'} / 白名单${whitelist ? '无' : '有'} / 构建${builder ? '不产出' : '仍产出'}`);
      }),
      // ── A197-3 **改判**（2026-10-13 · 载体决策 A / `UD-0013`）─────────────────────────────
      // **为什么必须改判（不是可选项）**：用户拍板**载体选 A**（保动态安装）⇒
      //   `lib/index.cjs` 的 `new Function('harness', BODY)` 桥接**长期保留** ⇒
      //   原判据（「装配点 = 0」）**按设计不可达**。依既有规则（`A201-3` 先例）：
      //   **恒红与恒绿同类，都比退役更差**（恒红=制造噪音，会训练后来者忽略真信号）⇒ 必须改判。
      //   方向取自 `docs/internal/P2-立项勘察-2026-10-13.md:336`：从「求值路径退役」
      //   改为「**限定文件集内可拆分**」。
      // **新形态**：判「**装配用求值点恰好一处，且仅存在于装配入口**」。
      //   ⚠ 口径按**形态**（`new Function('harness', …)` 这一装配签名，见 `ASSEMBLY_EVAL`）分辨。
      //   ⚠ 为什么用「形态」而非「一律计数」（2026-10-13 实测依据）：扫描面扩到全 `lib/` 后，
      //     实测 `lib/` 内有**两处** `new Function` —— 本入口，以及 `lib/sys.cjs:94` 的
      //     `new Function(pureText + …)`（`extractPure`：把 plugin-host.js 的 `==PURE==` 切片求值
      //     以取出 5 个纯函数）。后者是 v2.6.0 `6ce3097` 引入的 **PURE 提取辅助**（早于 P2 全部
      //     批次、有测试 `SYS-05`、被 `lib/harness.cjs:24` 消费），**与载体决策 A 无关**；
      //     若按「一律计数 == 1」判会留下**恒红**判据（正是本批要消除的形态）。
      //     ⇒ 判「**装配点**」而非「所有 new Function」，**忠实于原承诺语义**
      //     （原判据标题即「弃 chunk/marker/new Function **装配**」）。
      //   ⚠ 牙齿**不少于原判据**且**多出两个方向**：① 第二处**装配点**出现在任何其它文件 ⇒ 红；
      //     ② 装配点**迁出入口**（入口归零）⇒ 红。原判据只管「入口有没有」，本判据管「恰好一处且位置受限」。
      //   ⚠ 本判据**不覆盖什么**（如实声明）：不判求值点的**输入安全性**（`BODY` 来源/是否被污染）、
      //     不判 `BODY` 内容、不判 chunk/marker 装配形态（由 R4 的 `src/host` 等值集管）、
      //     不判 `plugin-host.js` 内部（无模块系统，由 A230-2 管）、**不判非装配用途的
      //     `new Function`**（如 `lib/sys.cjs` 的 PURE 提取 —— 超出本判据语义，另有其自身测试覆盖）。
      A('A197-3', '结构', '装配用 new Function 求值点恰好一处且限定在装配入口（载体决策 A 后的可判形态）', '装配点 == 1 处，且该点位于 lib/index.cjs', () => {
        const ENTRY = 'lib/index.cjs';
        const targets = libManifest.libHandwrittenTargets();   // 同一事实源（轮次 16 收敛）
        const hits = [];
        for (const rel of targets) {
          const n = occurrences(codeOnly(read(rel)), ASSEMBLY_EVAL);
          if (n > 0) hits.push({ file: rel, n });
        }
        const total = hits.reduce((a, h) => a + h.n, 0);
        const inEntry = hits.filter((h) => h.file === ENTRY).reduce((a, h) => a + h.n, 0);
        const elsewhere = hits.filter((h) => h.file !== ENTRY);
        const detail = `装配点 ${total} 处｜入口 ${inEntry} 处`
          + (hits.length ? `｜分布 [${hits.map((h) => h.file + '×' + h.n).join(', ')}]` : '')
          + `｜扫描面 ${targets.length} 件手改 .cjs`;
        return assert(total === 1 && inEntry === 1 && elsewhere.length === 0,
          detail + (elsewhere.length ? `｜⚠ 入口外出现装配点: ${elsewhere.map((h) => h.file).join(',')}` : ''));
      }),
      A('A197-4', '结构', '半部通信保留 HTTP（/rpc 兼容别名）', "RPC_PATH = '/dsh-prompt-enhancer/rpc'", () => {
        // P2-3（2026-10-13）：RPC_PATH 仍定义在 entry `lib/index.cjs`（未随拆分搬走）⇒ 判定面不变。
        const m = read('lib/index.cjs').match(/RPC_PATH\s*=\s*'([^']+)'/);
        return assert(!!m && m[1] === '/dsh-prompt-enhancer/rpc', m ? m[1] : '未找到 RPC_PATH');
      }),
      // ── A197-5 **净增**（P3-2b 2026-10-14 · `extractPure` 求值路径终结）──────────────────────
      // **为什么必须净增（不是重复 A197-3）**：`A197-3` 的口径是 **`ASSEMBLY_EVAL`
      //   = `/new Function\(\s*'harness'/g`（装配签名形态）**，它**故意**只认装配点 ⇒ 对
      //   `lib/sys.cjs` 那处 `new Function(pureText + …)`（PURE 片段提取）**完全看不见**。
      //   实证（P3-2b 报告 §③）：改前 `lib/sys.cjs` 的 `ASSEMBLY_EVAL` 命中 = **0**，
      //   而「任意 `new Function(`」命中 = **1** ⇒ 旧判据下该求值路径**逃逸机检**，
      //   正是「让失败不可观测」的形态（P2-1 `lib/**` 死码盲区同族）。
      //   故本条把粒度收紧到「**任意 `new Function`**」，管住 `A197-3` 明确声明**不覆盖**的那一面。
      // **语义**：`lib/` 下全部**手改** `.cjs` 中，`new Function` 求值点**恰好一处**，且该处
      //   必须是**装配入口** `lib/index.cjs` 的装配签名 ⇒ 等价于「**lib 侧对 PURE 片段的
      //   求值依赖归零，只留载体桥接**」。
      //   ⚠ 口径与 `A197-3` 严格同源：`libManifest.libHandwrittenTargets()`（同一事实源）+
      //     `codeOnly()`（剥注释，避免注释提及被计数 —— `A197-3` 的病历即此）。
      //   ⚠ **本判据不覆盖什么**（如实声明）：① 不判 `.cjs` 之外的形态（如 ESM `.mjs` 内求值）；
      //     ② 不判 `eval(` / `vm.runIn*` 等其它动态求值族；③ 不判 `plugin-host.js` 内部
      //     （无模块系统，由 `A230-2` 的 `require(` == 0 管）；④ 不判求值点的**输入安全性**
      //     （`BODY` 来源/是否被污染）—— 那是另一条轨迹，本条只判「求值点在哪、有几处」。
      //
      //   ⚠⚠ **R-2 / D-16 扩面（P3-2e 判据工具修正批 2026-10-14 · 独立复核发现）**：
      //     `D-16` 原表述为「R5 的读数可信度**完全依赖剥离器/语料面的正确性** ⇒ 工具链单点」，
      //     **只给 R5 开了处方**。复核实测证明**本族同样中招**，处方须**扩到 `A197-x` 全族**：
      //       · 实测（复核席 + 本批独立复现）：在 `532dc25` 上，**旧剥离器**（先块后行）
      //         读取 `lib/sys.cjs` 的 `new Function` = **1** ⇒ 本条判 `total === 1` ⇒ **PASS**；
      //         而**真值 = 2**（`lib/index.cjs` 装配 + `lib/sys.cjs` 的 PURE 提取）⇒ **假绿**；
      //       · 换用 D-10 修正后的剥离器 ⇒ 读数 **2** ⇒ 本条**正确转红**。
      //     ⇒ 结论：`A197-3` / `A197-5` 的读数与 R5 **同属「工具链单点」**，不是 R5 独有。
      //     ⚠ 该风险**不由本批（实施批）裁**：处方落账本由主持侧落；此处**只如实声明**
      //       本族存在同一依赖，供后续统一处置（**判定式一字未动**）。
      A('A197-5', '结构', 'lib/ 侧动态求值面收敛：手改 .cjs 内 `new Function` 恰好一处且仅在装配入口（PURE 求值路径已终结）', '任意 `new Function(` 总计 == 1 处，且全部位于 lib/index.cjs（装配签名）', () => {
        const ENTRY = 'lib/index.cjs';
        const targets = libManifest.libHandwrittenTargets();     // 同一事实源（与 A197-3 收敛）
        const ANY = /new Function\s*\(/g;
        const hits = [];
        for (const rel of targets) {
          const n = occurrences(codeOnly(read(rel)), ANY);
          if (n > 0) hits.push({ file: rel, n });
        }
        const total = hits.reduce((a, h) => a + h.n, 0);
        const elsewhere = hits.filter((h) => h.file !== ENTRY);
        // 与 A197-3 交叉：入口那一处必须仍是**装配签名**（防「入口换成非装配求值」蒙混）
        const entryAssembly = occurrences(codeOnly(read(ENTRY)), ASSEMBLY_EVAL);
        const detail = `任意 new Function ${total} 处｜分布 [${hits.map((h) => h.file + '×' + h.n).join(', ') || '无'}]`
          + `｜入口装配签名 ${entryAssembly} 处｜扫描面 ${targets.length} 件手改 .cjs`;
        return assert(total === 1 && elsewhere.length === 0 && entryAssembly === 1,
          detail + (elsewhere.length ? `｜⚠ 入口外出现 new Function: ${elsewhere.map((h) => h.file).join(',')}` : ''));
      }),
    ],
    pending: [
      { id: 'A197-1', reason: 'ADR-230 修订该轨迹：改为按 9 域分批（首批 D8），且换装载形态是拆分收益的前置项' },
      // ⚠ 本条目**保留为「决定记录」**（`UD-0013` 关闭该轨迹），措辞已订正为「已裁定」语气，
      //   **不留「待办」语气**（后者会误导后来者以为还欠着）。
      //   ⚠ **订正说明（TASK §3② 的「移除」选项）**：原指令给的是「订正**或移除**」——
      //     ⚠「移除」在 **`kind === '目标'` 的前提下是错的**：`S-3`（`:785`）收集**每条**
      //     `kind === '目标'` 的断言（`c.assertions.filter((a) => a.kind === '目标')`，**不区分
      //     pass/fail**）并要求非空 pending ⇒ 删条目会报 `✗ S-3 无依据：A197-3`。
      //     该形态**已实测复现**（2026-10-13 变异自证，见本批报告 §2）。
      //   ⚠ 但本判据的 kind 在本批已由 `'目标'` 改为**`'结构'`**（理由见 A197-3 本体注释：
      //     改判后它是**守现状的结构约束**，不再是 unmet 目标）⇒ 此后 **`S-3` 不再要求本条目**，
      //     且**退出码语义反而更强**：`'目标'` 类失败只进 `pendingTargets`（**不影响 exit code**，
      //     见 `:913` `conflicts` 定义与 `:1193` 的 `ringState`），而 `'结构'` 类失败进 `conflicts`
      //     ⇒ **exit 1（阻断）**。这正是选 `'结构'` 的原因（牙齿只增不减）。
      //   ⇒ 保留本条目**仅为留痕**；即便删掉也不再影响任何判据（与「移除」的原始风险不同）。
      { id: 'A197-3', reason: '**已由用户拍板 `USER-DECISIONS.md` `UD-0013`（载体选 A：保动态安装）关闭该轨迹** ——'
        + '「弃 chunk/marker/new Function 装配」不再是目标；本判据已改判为「**装配用求值点恰好一处且仅存在于装配入口**」'
        + '（守现状的结构约束，不再以「装配点 = 0」为目标；kind 亦由 `目标` 改为 `结构`）。' },
    ],
  },
  {
    adr: 'ADR-201', anchor: 'module:prompt-enhancer', at: '2026-09-12', level: '已兑现',
    promise: '收缩为「提示词增强 + 语音识别」双核心并移除插件内重启：删 update/portRestart、update/makeShortcut，新增 update/install（BREAKING）',
    assertions: [
      // P1-a（2026-10-13 缩批）：数字 34 → **26**。⚠ 这不是「改浅断言」——
      //   本条判的是「**注册面条数这个事实**」，34 是 P1-a 前的实测值；P1-a 删掉 8 条
      //   `voice/*`（model*/deploy*：引擎/云端/模型下载/运行时部署退役，识别交官方
      //   `speechToText`）⇒ 事实变为 26（原生 8 + bundle 18）。**判据强度不变**：
      //   仍是「注册面必须等于实测条数」（`assert(all.size === 26)` 与旧式的严格等号同形，
      //   未改成区间/大于等于，也未跳过任何一条注册面）。
      // CHG-117（2026-10-16 · 规整改造批）：数字锁 15 → **14**（删 `voice/transcribe`；自建链退役后已无调用方）。
      // CHG-143（2026-10-17 · 纠错语音独立步批）：数字锁 14 → **15**（新增 `voice/correct` —— 语音识别完成后的
      //   **独立纠错步**，注册在 bundle 内；native 3 不变、bundled 11 → 12）。
      //   ⚠ 判据强度不变：仍是「注册面必须等于实测条数」（`all.size === 15` 严格等号，未改区间/未跳过）。
      A('A201-1', '结构', '线上注册面条数（与 test/rpc-contract.test.cjs 的数字锁交叉核）', '15 条', () => {
        const { native, bundled } = liveMethods();
        const all = new Set([...native, ...bundled]);
        return assert(all.size === 15, `${all.size} 条（原生 ${native.length} + bundle ${bundled.length}）`);
      }),
      // A201-2（判「删 portRestart/makeShortcut + 新增 update/install」）**随 P1-c 退役**：
      //   P1-c 把 `update/install` 也删了（更新执行器整体交回官方 plugin manager，Q3 拍板）
      //   ⇒ 「install 在位」不再成立，本断言无被判对象。⚠ 「portRestart/makeShortcut 永不回流」
      //   未丢失：由 A201-1 的严格等号计数锁（15，回流即 16 ⇒ 立红）覆盖。
      // A201-3（`lib/updater-host.cjs ≤ 855 行`）**随 P1-c 退役**：该文件已整体删除——
      //   ⚠ 注意它此前会**假绿**（`lines()` 读不到文件返回 0 ⇒ 0 ≤ 855 恒真），故必须删而非留。
      //   等价的新判据见 A201-6（判「执行器安装面确已不存在」，含文件缺席 + update/* 残留为 0）。
      A('A201-6', '结构', '更新执行器安装面已退役（P1-c · 交回官方 plugin manager）', 'updater-host/stage-install 缺席；未再注册 update/* RPC', () => {
        const files = ['lib/updater-host.cjs', 'lib/stage-install.cjs'];
        const disk = files.map((f) => exists(f));
        const { native, bundled } = liveMethods();
        const all = [...native, ...bundled];
        const upd = all.filter((m) => m.startsWith('update/'));
        return assert(!disk[0] && !disk[1] && upd.length === 0,
          `updater-host ${disk[0] ? '仍在' : '已删'} / stage-install ${disk[1] ? '仍在' : '已删'} / 残留 update/* = ${upd.length}`);
      }),
      A('A201-4', '结构', '客户端重启 UI 已删', 'src/client 下无 portRestart / makeShortcut 引用', () => {
        const walk = (d) => fs.readdirSync(abs(d), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(`${d}/${e.name}`) : [`${d}/${e.name}`]));
        const hits = walk('src/client').filter((f) => /portRestart|makeShortcut/.test(read(f)));
        return assert(!hits.length, hits.length ? `命中 ${hits.join(',')}` : '零引用');
      }),
      // P1-a（2026-10-13 缩批）：witness 的**字面量**随数字锁同步 34 → 26（仅指向「数字锁仍在册」这一事实，
      //   不改变 witness 的判据强度：仍要求 test/rpc-contract.test.cjs 内含该数字与 update/portRestart）。
      witness('A201-5', 'test/rpc-contract.test.cjs', ['15', 'update/portRestart'], '数字契约锁与「已删方法永不返回」证据在册'),
    ],
  },
  {
    adr: 'ADR-224', anchor: 'feature:pe-f01', at: '2026-09-18', level: '已兑现',
    promise: 'P1a+P1b 收敛：client 载体单一化（lib/client.cjs）+ M2 目标架构层整体退役 + 两条结构门禁 R3/R4 固化',
    assertions: [
      A('A224-1', '结构', 'client 唯一载体', 'exports["./client"] → lib/client.cjs 且文件在位', () => {
        const exp = require(abs('package.json')).exports['./client'];
        return assert(exp === './lib/client.cjs' && exists('lib/client.cjs'), `${exp} / 文件${exists('lib/client.cjs') ? '在位' : '缺失'}`);
      }),
      gate('A224-2', ['scripts/dead-code-gate.mjs'], '结构门禁整体通过（含 R3 产物清单 ↔ files 白名单、R4 src/host 等值集）'),
      A('A224-3', '结构', 'R3/R4 两条规则仍在位（防规则被静默删除而门禁仍 exit 0）', 'R3 + R4 均命中', () => {
        const src = read('scripts/dead-code-gate.mjs');
        const hit = ['R3', 'R4'].filter((r) => src.includes(r));
        return assert(hit.length === 2, `命中 ${hit.join('/')}`);
      }),
    ],
  },
  {
    adr: 'ADR-230', anchor: 'feature:pe-f01', at: '2026-09-18', level: '已兑现',
    promise: 'P3 装配契约：lib/index.cjs 按 9 域划界且 100% 覆盖；拆分按域分批；plugin-host.js 无 require 是结构约束（判据未声明入边 = 0 降级，不虚报）',
    assertions: [
      A('A230-1', '结构', 'lib/ 域清单等值集（多一件即 FAIL）—— 覆盖 100% / 无缝隙 / 无重叠的拆分后形态', 'lib/ 磁盘 .cjs 集合 == 声明清单（逐键等值）且各域文件非空', () => {
        const declared = Object.keys(PE_F01_LIB_MANIFEST).sort();
        const disk = list('lib').filter((f) => f.endsWith('.cjs')).sort();
        const extra = disk.filter((f) => !declared.includes(f));
        const missing = declared.filter((f) => !disk.includes(f));
        // 各域文件非空（空文件 = 声明了却没内容的缝隙）
        const empty = declared.filter((f) => !disk.includes(f) ? false : lines(`lib/${f}`) <= 1);
        return assert(extra.length === 0 && missing.length === 0 && empty.length === 0,
          `声明 ${declared.length} 件 / 磁盘 ${disk.length} 件`
          + (extra.length ? `｜⚠ 未声明（多一件）: ${extra.join(',')}` : '')
          + (missing.length ? `｜⚠ 声明但缺失: ${missing.join(',')}` : '')
          + (empty.length ? `｜⚠ 空域文件: ${empty.join(',')}` : '')
          + '｜全部非空');
      }),
      A('A230-5', '结构', '拆分产物无孤儿：每个域模块都必须被入口 require 接线（声明了却没接线 ⇒ 红）', `入口 require 覆盖 ${PE_F01_SPLIT_PRODUCTS.length} 个域模块`, () => {
        const entry = read('lib/index.cjs');
        const unwired = PE_F01_SPLIT_PRODUCTS.filter((f) => !new RegExp(`require\\(\\s*'\\./${f.replace('.', '\\.')}'`).test(entry));
        return assert(unwired.length === 0, unwired.length ? `未接线: ${unwired.join(',')}` : `${PE_F01_SPLIT_PRODUCTS.length}/${PE_F01_SPLIT_PRODUCTS.length} 个域模块均被入口 require`);
      }),
      A('A230-2', '结构', '载体约束事实：plugin-host.js 内无模块系统', 'require( 计数 == 0', () => {
        const n = occurrences(read('plugin-host.js'), /require\(/g);
        return assert(n === 0, `${n}`);
      }),
      A('A230-3', '索引', 'P3 决策档在位且三项拍板已回写', '档存在且含三项拍板行', () => {
        // ⚠ CI 首跑实证（run 35397066749）：`docs/internal` 整目录在干净 clone 里不存在，
        //   先 list() 再判空会 ENOENT 抛错 → 记为冲突（假冲突）。必须先判目录存在。
        if (!exists('docs/internal')) return { skip: true, actual: 'docs/internal 整目录缺位（本地治理档，CI/干净 clone 预期无）' };
        const f = list('docs/internal').find((x) => x.startsWith('P3-装配契约'));
        if (!f) return { skip: true, actual: 'P3 决策档缺位（本地治理档）' };
        const src = read(`docs/internal/${f}`);
        const hit = ['拍板结果', 'D8 诊断面', '不立项'].filter((k) => src.includes(k));
        return assert(hit.length === 3, `${f} 命中 ${hit.length}/3`);
      }),
      gate('A230-4', ['scripts/rpc-manifest.mjs', '--check'], 'RPC 契约面不受本轮影响（派生事实源一致）'),
    ],
  },
  {
    adr: 'ADR-234', anchor: 'module:prompt-enhancer', at: '2026-09-18', level: '已兑现',
    promise: 'P4：结构判据机检化（分母由模型派生、判据表为投影、四档语义含 SKIP/在册未达/在册缺陷）+ 四条结构门禁收敛为 `npm run gate` 并首次进 CI + RC-F 收敛基线（10 个状态面 / 在册缺陷 D-1）',
    assertions: [
      A('B234-1', '结构', '门禁链收敛为一条命令（顺序即依赖序）', '点名集合 ≡ gate 链实际集合（双向）；链序 == 本表声明序；实装 --check 的环在链上必须带 --check（含编排器入口自传旗的形态）', () => {
        const { rings, source, nested, entryScript, diag } = gateChain();
        const named = GATE_RINGS.map((r) => r.script);
        const actual = rings.map((r) => r.script);
        const extra = actual.filter((s) => !named.includes(s));      // 链上新增环未点名 → 红（R4 要堵的那一面）
        const lost = named.filter((s) => !actual.includes(s));       // 点名环从链上消失 → 红（F4 负控）
        const dup = actual.filter((s, i) => actual.indexOf(s) !== i);
        const order = rings
          .map((r) => named.indexOf(r.script))
          .filter((i) => i >= 0);
        const asc = order.every((v, i) => i === 0 || v > order[i - 1]);
        // 旗标腿：直连形态从命令行字面量取证；编排器形态旗由入口脚本自传，改从**入口脚本文本**取证
        //   （条目内需出现 `scripts/<名>.mjs` 与 `--check`，二者相隔不超过 160 字符）。
        //   ⚠ 旧实现 nested 时整条腿短路 —— 复核席实测那是相对基线的判别力净回归（丢 rpc/prompts 的
        //     --check 后判绿）。入口脚本不可读/取不到条目 → 记 fail（fail-closed，不静默放过）。
        const entryText = nested && entryScript && exists(entryScript) ? read(entryScript) : null;
        const flagMiss = [];
        for (const r of rings) {
          if (!implementsCheck(r.script)) continue;
          if (!nested) {
            if (!r.args.includes('--check')) flagMiss.push(r.script);
            continue;
          }
          if (entryText === null) { flagMiss.push(r.script + '(入口脚本不可读，无法取证旗标)'); continue; }
          const k = entryText.indexOf(r.script);
          if (k < 0) { flagMiss.push(r.script); continue; }
          // 取证窗 = 该环自己的条目行，**遇到下一环的 .mjs 字面量即截断**（定宽窗口会串到下一环的旗标上 → 假绿）
          const rest = entryText.slice(k).split('\n');
          let seg = rest[0];
          for (let i = 1; i < Math.min(rest.length, 4) && !/\.mjs['"]/.test(rest[i]); i += 1) seg += '\n' + rest[i];
          if (!/--check/.test(seg)) flagMiss.push(r.script);
        }
        const flags = flagMiss;
        const okAll = !extra.length && !lost.length && !dup.length && asc && !flags.length;
        // ⚠ 归因先行（I4 · 2026-09-27）：零环时**不得**用「点名却缺席 N 件」当结论——读者会去点名面/
        //   package.json 找问题，而真凶在下探面（入口里没有字面量 / 入口不在位 / 入口认不出）。
        //   此行改成只报「零环怎么来的」+ 该查哪个文件；判定不变（照样 okAll=false → 仍判红）。
        //   ⚠ 不只是 actual.length===0：下探失败时 rings 常残留「入口脚本自己」（parseRings 会命中
        //     `node scripts/gate.mjs`），报成「链 1 环｜未点名 gate.mjs」同样是错误归因。故判据是
        //     「下探是否失败」，不是「数出来几个」。
        const diveFailed = diag.state === 'missing' || diag.state === 'zero-literal' || diag.state === 'unparsed';
        if (diveFailed || !actual.length) return no(chainZeroReason(diag));
        return assert(okAll,
          `链 ${actual.length} 环（源 ${source}${nested ? '｜旗标取证面 = 入口脚本文本' : ''}）`
          + `｜未点名 ${extra.length ? extra.join(',') : '无'}`
          + `｜点名却缺席 ${lost.length ? lost.join(',') : '无'}`
          // 部分缺席（有环、但少了某几环）同样要能指向**下探面**：若入口脚本文本里没有该环字面量，
          //   该环很可能是被变量拼接调用（而非被删）——归因必须落在入口脚本上，别让读者去点名面找。
          + (nested && lost.length ? `（下探面：入口脚本 ${entryScript} 字面量里没有它们——请检查该入口是否以变量拼接调用此环）` : '')
          + `｜重复 ${dup.length ? dup.join(',') : '无'}`
          + `｜链序单调 ${asc}`
          + `｜实装 --check 却未带旗 ${flags.length ? flags.join(',') : '无'}`);
      }),
      A('B234-2', '结构', '门禁进 CI 且判据之间不得互相遮蔽（失败仍出读数）', 'Structure gates 跑 npm run gate 且与 Run tests 两步均 if: always()', () => {
        const ci = read('.github/workflows/ci.yml');
        const step = /- name: Structure gates[\s\S]{0,400}?run: npm run gate/.test(ci);
        const gateAlways = /- name: Structure gates[\s\S]{0,300}?if: always\(\)/.test(ci);
        const testsAlways = /- name: Run tests[\s\S]{0,160}?if: always\(\)/.test(ci);
        return assert(step && gateAlways && testsAlways, `步骤 ${step}｜gate always ${gateAlways}｜tests always ${testsAlways}`);
      }),
      A('B234-3', '结构', '判据表是投影（三种模式 + 治理档标记区），治理档缺位不判漂移', '脚本含 --check/--md/--write 与标记对；**语义**守卫：档缺位 ⇒ 判定不是 drift（不锁返回字面量）', () => {
        const src = read('scripts/arch-claims.mjs');
        const modes = ['--check', '--md', '--write'].filter((m) => src.includes(`'${m}'`));
        const marks = src.includes('ARCH-CLAIMS:BEGIN') && src.includes('ARCH-CLAIMS:END');
        // 守卫的**语义**是"缺档 ⇒ 不判漂移"，不是某个具体返回字面量：锁死字面量会把
        //   T2 的归因改造（return {kind:'missing-doc'}）误判成"守卫被删"（2026-09-27 实测踩到）。
        //   改用**行为**判定：拿分类器在缺档/缺标记两个变异体上实跑，看它是否落在"不判漂移"。
        const g1 = classifyDrift(null, 'x', 'sha256:0', 0);
        const g2 = classifyDrift(undefined, 'x', 'sha256:0', 0);
        const skipGuard = g1.kind === 'missing-doc' && g2.kind === 'missing-marker';
        return assert(modes.length === 3 && marks && skipGuard, `模式 ${modes.length}/3｜标记 ${marks}｜缺档守卫（语义）${skipGuard}：缺档→${g1.kind}｜缺标记→${g2.kind}`);
      }),
      A('B234-5', '结构', '投影漂移判定的**归因两分**与**防手抄守卫**在位（T2 · 2026-09-27）', '投影带跨环境同值的判据面指纹；漂移时能分辨"换环境"与"判据过期"；指纹行参与判定且自底向上重算', () => {
        const src = read('scripts/arch-claims.mjs');
        const hasFp = /function claimsFingerprint/.test(src);
        // 指纹的**判据面**必须不含环境派生列：detail 在（判据文本），pass/skip/actual 必须不在。
        const facesLine = (src.match(/const faces = rows\.map\(\(r\) => \[([^\]]*)\]/) || [])[1] || '';
        const facesClean = !/\br\.(pass|skip|actual|expect)\b|\bpassed\b|\bskips\b/.test(facesLine);
        // 跨环境同值的计数腿：计数里只许有 RUN.length / DEFECTS.length（passed/skips 会随环境抖）
        const countsLine = (src.match(/const c = counts \|\| \[([^\]]*)\]/) || [])[1] || '';
        const countsClean = /RUN\.length/.test(countsLine) && !/passed|skips|conflicts/.test(countsLine);
        // 判定例程不得引用投影里的指纹（须自底向上重算），且必须**先剥指纹行**再比对（否则递归）
        const stampStrip = /stampedMd/.test(src) && /stripFp/.test(src);
        const judgeByRecalc = /const localFp = claimsFingerprint\(\)/.test(src);
        // 归因两分：判据面没变 ⇒ 陈旧读数（stale-readings，不判漂移）；变了 ⇒ 真漂移（drift）
        const twoWay = /kind === 'stale-readings'/.test(src) && /判据面\*\*已过期\*\*/.test(src);
        // 指纹行参与判定（否则改档里的指纹无人抓）
        const fpInVerdict = /fpConsistent/.test(src) && /process\.exit\(1\)/.test(src);
        const pass = hasFp && facesClean && countsClean && stampStrip && judgeByRecalc && twoWay && fpInVerdict;
        return assert(pass, `指纹函数 ${hasFp}｜判据面不含环境列 ${facesClean}｜计数跨环境同值 ${countsClean}｜剥指纹行 ${stampStrip}｜自底向上重算 ${judgeByRecalc}｜归因两分 ${twoWay}｜指纹参与判定 ${fpInVerdict}`);
      }),
      A('B234-6', '结构', '投影漂移判定**判别力自证**（内存变异：陈旧读数 与 判据面演化 必须被分成两类，防手抄腿在两种环境下都有效）', '换环境->stale-readings（不判漂移）；同环境读数漂移/指纹变/条数过期/表体缺行->drift 真红；指纹被替换->fpConsistent=false；缺档/缺标记->各 1 且不判漂移', () => {
        // 判别力自证（变异体，仿 S-8/A-4b 的形态）：只"声明"归因两分是不够的——
        //   必须证明这条判定**真能把两类分开放**，否则它可被静默掏空（比如两分腿恒真）。
        //   ⚠ 这是本会 2026-09-27 的**假红**复盘落点：修复前单形态判漂移 ⇒ 另一种形态必假红。
        const FP = 'sha256:' + 'a'.repeat(16);
        const OTHER = 'sha256:' + 'b'.repeat(16);
        // 真实判据面目（用本进程实跑出来的行，不编造文本）
        const ROWS = RUN.slice(0, 3);
        const body = (rows) => rows.map((r) => `| ${r.id} ${r.kind}：${r.detail} |`);
        const mk = (fp, n, rows, env) => ['表头', '|---|---|', ...body(rows),
          '', `> fingerprint（判据面指纹·跨环境同值）：\`${fp}\`（${n} 条断言｜读数快照 env=${env}｜判据面 = id/kind/detail）`,
          '', '> 生成：--md｜通过 1'].join('\n');
        // 另一种环境算出来的同一份表体（剥掉指纹行、读数列不同）
        const computedEnvDiff = mk('', 0, [], 'x').replace(/\n> fingerprint[^\n]*/, '').replace('通过 1', '通过 9');
        const c = [
          ['换环境->陈旧读数', classifyDrift(mk(FP, 3, ROWS, 'gov-readable'), computedEnvDiff, FP, 3, ROWS, 'gov-unreadable').kind === 'stale-readings'],
          ['同环境读数漂移仍判红', classifyDrift(mk(FP, 3, ROWS, 'gov-unreadable'), computedEnvDiff, FP, 3, ROWS, 'gov-unreadable').kind === 'drift'],
          ['指纹变->真漂移', classifyDrift(mk(OTHER, 3, ROWS, 'x'), computedEnvDiff, FP, 3, ROWS, 'x').kind === 'drift'],
          ['条数过期->真漂移', classifyDrift(mk(FP, 2, ROWS, 'x'), computedEnvDiff, FP, 3, ROWS, 'x').kind === 'drift'],
          ['表体缺行->真漂移', classifyDrift(mk(FP, 3, ROWS.slice(0, 2), 'x'), computedEnvDiff, FP, 3, ROWS, 'x').kind === 'drift'],
          ['指纹被替换', (() => { const d = classifyDrift(computedEnvDiff, computedEnvDiff, FP, 3, []); return d.kind === 'none' && d.fpConsistent === false; })()],
          ['逐字相等+行齐', (() => { const x = mk(FP, 3, ROWS, 'x'); const d = classifyDrift(x, x, FP, 3, ROWS, 'x'); return d.kind === 'none' && d.fpConsistent === true && !d.missingRows.length; })()],
          ['缺档', classifyDrift(null, computedEnvDiff, FP, 3, ROWS).kind === 'missing-doc'],
          ['缺标记', classifyDrift(undefined, computedEnvDiff, FP, 3, ROWS).kind === 'missing-marker'],
        ];
        const bad = c.filter((x) => !x[1]).map((x) => x[0]);
        return assert(!bad.length, c.map(([k, v]) => k + ' ' + (v ? '✓' : '✗')).join('｜') + (bad.length ? '｜未命中 ' + bad.join(',') : ''));
      }),
      A('B234-7', '结构', '漂移**归因文本**与事实同向：判据面未变时不得叙述成「已过期」（措辞面假红）', '面变→（已过期+判据面变了）；面未变（同环境读数漂移）→（未变+不是判据演化）且两分类措辞不互借', () => {
        // 依据（2026-09-27 独立复核实测）：同环境读数漂移时，档内指纹 == 本形态指纹、表体齐，
        //   归因却打印「判据面**已过期**」+ 收尾「已归因：判据面变了」——判据面一个字未改。
        //   这是 b2/I3 同族的**措辞与事实相反**：人读会被引向错误的修复方向。只声明两分类不够，
        //   必须证明**文本真的跟着分类走**（纯函数变异体，仿 B234-6 形态）。
        const FP = 'sha256:' + 'a'.repeat(16);
        const OTHER = 'sha256:' + 'b'.repeat(16);
        const ROWS = RUN.slice(0, 3);
        const mk = (fp, n, rows, env) => ['表头', '|---|---|', ...rows.map((r) => `| ${r.id} ${r.kind}：${r.detail} |`),
          '', `> fingerprint（判据面指纹·跨环境同值）：\`${fp}\`（${n} 条断言｜读数快照 env=${env}｜判据面 = id/kind/detail）`,
          '', '> 生成：--md｜通过 1'].join('\n');
        const envDiff = mk('', 0, [], 'x').replace(/\n> fingerprint[^\n]*/, '').replace('通过 1', '通过 9');
        // ① 面未变 + 同环境读数漂移 ⇒ 措辞必须是「未变」，且不得含「已过期」
        const sameEnv = classifyDrift(mk(FP, 3, ROWS, 'gov-readable'), envDiff, FP, 3, ROWS, 'gov-readable');
        const a1 = driftAttribution(sameEnv, FP, 3, 'gov-readable');
        const ok1 = sameEnv.kind === 'drift' && a1.faceChanged === false
          && /判据面\*\*未变\*\*/.test(a1.why) && !/已过期/.test(a1.why)
          && !/判据面变了/.test(a1.tail) && /不是判据演化/.test(a1.tail);
        // ② 面变（指纹变）⇒ 措辞必须是「已过期」，且不得反过来写「未变」
        const faceChg = classifyDrift(mk(OTHER, 3, ROWS, 'x'), envDiff, FP, 3, ROWS, 'x');
        const a2 = driftAttribution(faceChg, FP, 3, 'x');
        const ok2 = faceChg.kind === 'drift' && a2.faceChanged === true
          && /判据面\*\*已过期\*\*/.test(a2.why) && /判据面变了/.test(a2.tail) && !/未变/.test(a2.why);
        // ③ 面变（表体缺行）也必须走「已过期」支
        const rowChg = classifyDrift(mk(FP, 3, ROWS.slice(0, 2), 'x'), envDiff, FP, 3, ROWS, 'x');
        const ok3 = driftAttribution(rowChg, FP, 3, 'x').faceChanged === true;
        // ④ 印刷面：正文两支都真的被调用到（防函数存在却没人调）
        const src = read('scripts/arch-claims.mjs');
        const wired = (src.match(/driftAttribution\(/g) || []).length >= 3;
        const bad = [['面未变→未变措辞', ok1], ['面变→已过期措辞', ok2], ['表体缺行→已过期支', ok3], ['函数已接线(≥3处)', wired]].filter((x) => !x[1]).map((x) => x[0]);
        return assert(!bad.length, `面未变措辞 ${ok1 ? '✓' : '✗'}｜面变措辞 ${ok2 ? '✓' : '✗'}｜缺行支 ${ok3 ? '✓' : '✗'}｜接线 ${wired ? '✓' : '✗'}` + (bad.length ? `｜未命中 ${bad.join(',')}` : ''));
      }),
      // B234-4（判「D-1 的处置形态是判据而非一次性修复：S-5 在位 + 两副本无已退役件」）
      //   **随 P1 余账批退役**：它的两个被测物都已消失 —— ① 它要求「S-5 在位」，而 S-5 本身因
      //   判据对象消失而退役（见上）；② 它 `read('src/client/updater.js')` 检查「两副本洁净」，
      //   而该文件已整件删除 ⇒ 原判据会 `ENOENT` 抛错（假红）。
      //   ⚠ **这不是改浅**：D-1 的处置形态已由**更上游的事实**固化 —— `plugin-client.js` 的缺席由
      //     A197-2（判「弃孤儿产物 plugin-client.js」）独立覆盖，且 `UPDATE_MANIFEST` 本身已不存在
      //     ⇒「清单含已退役件」这一缺陷类别**在当前代码面上不可再发生**。
    ],
  },
];

// ───────────────────────── 结构性判据（分母与在册性，不属任何单条 ADR） ─────────────────────────

const PE_ADR_SET = CLAIMS.map((c) => c.adr).sort();

/** 在册缺陷台账：机检发现的**非 ADR 面**问题——必须写明处置指向，否则 S-4 记冲突（防"发现了但没人管"）。
 *  当前为空：唯一一条 D-1（`UPDATE_MANIFEST` 含已退役 `plugin-client.js`，使 `update/pull` 在本仓不可能成功）
 *  已于 2026-09-19 按用户拍板方案 A 修复（两处副本 + 注释条数 + U30 断言 + 重建产物），并把「这一类」固化为判据 **S-5**
 *  ——一次性修复会复长，判据才会拦住下一次。 */
const DEFECTS = [];

const STRUCTURAL = [
  // ── S-9（P2 窄复核处置批 2026-10-13 · 处置 F-1）：**排除集不得被偷偷扩大** ──────────────
  // 病历：`libTargets()` 的排除集（原 `GENERATED_LIB`）是**单点可漂移且无人复核**的 ——
  //   多排除一个真实手改模块 ⇒ **R5 覆盖面 83→65 符号、R6 12→11**，而 `gate` 绿、`A230-1` 绿、
  //   上一批的两条回归锁也绿（它们只验「新文件是否入网」，**不验排除集**）⇒ 全链零红。
  // ⇒ 本条锁死：**排除集 == 构建脚本的真实写盘点**（由 `lib-manifest.mjs` 同源派生），
  //   且**每个被排除件都必须是构建产物**（有构建脚本写它），**不得**出现"无写盘点的排除项"。
  A('S-9', '结构', 'lib/ 排除集不可漂移：被排除件必须件件有构建脚本写盘点（无写盘点 = 偷排除 ⇒ 红）', '排除集 ⊆ 构建脚本写盘点集合，且排除集非空', () => {
    const gen = libManifest.generatedLibFiles();
    // 独立取证：从构建脚本正文里现取「写 lib/ 下文件」的盘点（不采信 lib-manifest 的返回值）
    const builderSrc = read('scripts/build-client.mjs');
    const written = new Set();
    for (const m of builderSrc.matchAll(/writeFileSync\(\s*join\(root,\s*'lib',\s*'([^']+)'/g)) written.add(m[1]);
    const unjustified = gen.filter((f) => !written.has(f));
    return assert(gen.length > 0 && unjustified.length === 0,
      `排除 ${gen.length} 件 [${gen.join(',')}]｜构建写盘点 [${[...written].join(',')}]`
      + (unjustified.length ? `｜⚠ 无写盘点的偷排除: ${unjustified.join(',')}` : '｜逐件有据'));
  }),
  A('S-1', '结构', '分母完整性：判据表覆盖的 ADR 集合 == 声明的 PE 决策集（出处 nav_graph mode=adrs）', '7 条且逐条对应', () => {
    // 声明面（出处：`nav_graph mode=adrs`，锚点匹配 /pe-f\d|prompt-enhancer/，采集 2026-09-19）。
    // 新增 PE 决策必须同步加行，否则 S-1（本处）与 S-2（治理日志交叉核对）都会红。
    const declared = ['ADR-146', 'ADR-194', 'ADR-197', 'ADR-201', 'ADR-224', 'ADR-230', 'ADR-234'].sort();
    const same = declared.length === PE_ADR_SET.length && declared.every((x, i) => x === PE_ADR_SET[i]);
    return assert(same, `${PE_ADR_SET.length} 条：${PE_ADR_SET.join(',')}`);
  }),
  A('S-2', '索引', '分母交叉核对：治理日志内 PE 锚点的多重集 == 判据表锚点多重集', `日志可读时 ${CLAIMS.length} 条锚点逐一对应`, () => {
    if (!fs.existsSync(GOV_EVENTS)) return { skip: true, actual: '治理日志不可读（CI/干净 clone 预期）' };
    const anchors = fs.readFileSync(GOV_EVENTS, 'utf8').split('\n')
      .map((l) => { try { return JSON.parse(l); } catch { return null; } })
      .filter((e) => e && e.kind === 'decide' && /pe-f\d|prompt-enhancer/.test(String(e.anchor || '')))
      .map((e) => e.anchor);
    const want = CLAIMS.map((c) => c.anchor).sort();
    const got = anchors.sort();
    return assert(got.length === want.length && got.every((x, i) => x === want[i]), `日志 ${got.length} 条 vs 表 ${want.length} 条`);
  }),
  A('S-3', '结构', '在册性：每条 TARGET（未达）断言必须写明依据', '每条 TARGET 均有 pending 依据', () => {
    const targets = CLAIMS.flatMap((c) => c.assertions.filter((a) => a.kind === '目标').map((a) => ({ adr: c.adr, id: a.id, why: (c.pending || []).find((p) => p.id === a.id) })));
    const bare = targets.filter((t) => !t.why || !t.why.reason);
    return assert(!bare.length, bare.length ? `无依据：${bare.map((t) => t.id).join(',')}` : `${targets.length} 条 TARGET 全部在册`);
  }),
  A('S-4', '结构', '在册缺陷台账：每条缺陷必须写明处置指向与证据（防"发现了但没人管"）', '每条缺陷含 disposition + evidence', () => {
    const bare = DEFECTS.filter((d) => !d.disposition || !(d.evidence || []).length || !d.owner);
    return assert(!bare.length, bare.length ? `条目不全：${bare.map((d) => d.id).join(',')}` : `${DEFECTS.length} 条在册缺陷均有处置指向`);
  }),

  // ── 状态归属判据（RC-F：同一状态多处持有 ⇒ 让副本可机检） ──────────────────────────

  // S-5（两处 `UPDATE_MANIFEST` 副本相等 + ⊆ files 白名单 + 注释条数 == 数组长度）
  //   **随 P1 余账批退役**：该判据的**判据对象整体消失** —— host 侧 `UPDATE_MANIFEST`
  //   （`src/host/pure.js`）与 client 侧 `UPDATER_MANIFEST`（`src/client/updater.js`）**两副本均已移除**
  //   （其唯一消费者 `update/*` RPC 已随 P1-c 退役 ⇒ 零活消费者）。
  //   ⚠ **这不是改浅判据**：判据对象（两份清单）已不存在，判据**无被测物**。
  //     若保留原判据，`grabArr()` 将解析不到清单 ⇒ 恒走 `no('清单未解析到')` **永远为红**（假红）；
  //     若改成「解析不到就算过」则**永远为真**（假绿，同 A201-3 先例）——两者都比退役更差。
  //     故依「判据随被测对象一并退役」定论整条删除。
  // S-6（`RESTART_FILES` 逐项在位 + ⊆ 白名单 + 含两个装配链入口）**随 P1-c 退役**：
  //   `RESTART_FILES` 常量定义在 `lib/index.cjs` 的 `update/restartNeeded` 段内 —— 该 RPC
  //   连同「插件自建重启探测」整体退役（交回官方 plugin manager）⇒ 常量已不存在，
  //   本断言**无被判对象**（`no('未解析到 RESTART_FILES')` 正是它退役后的必然读数）。
  //   ⚠ 替代判据：S-6' 判「**清单若在则必须自洽；若已退役则必须确证其不存在**」——
  //     既不假绿（不再因解析失败就报 no），也不假红（确实退了就应记 PASS 并说明）。
  // ⚠ P2 复核处置批（2026-10-13 · F8）：原判据只读 `lib/index.cjs` ⇒ **牙齿可绕**：
  //   把 `RESTART_FILES` 引回 `lib/**` 的**其它文件**（如新建 `lib/x.cjs` 或塞进 `lib/sys.cjs`）
  //   时本判据**不报**（复核实测）——即"看起来在守、实际不守"。现扩为 **`lib/**` 全枚举扫描**
  //   （保留守卫与牙齿），任一文件出现该清单即走「逐项自洽」分支。
  A('S-6', '结构', '重启探测名单：已随执行器退役（若在 `lib/**` 任一处复现则必须逐项自洽）', 'RESTART_FILES 缺席（已退役）或逐项在位且合法', () => {
    // 扫描面 = lib/ 下全部 .cjs（含拆分后的域模块；排除构建产物 client.cjs）
    const libFiles = libManifest.libHandwrittenTargets().map((f) => f.replace(/^lib\//, ''));
    const hits = [];
    for (const f of libFiles) {
      const m = read('lib/' + f).match(/const RESTART_FILES = \[([^\]]*)\]/);
      if (m) hits.push({ file: 'lib/' + f, m });
    }
    if (hits.length === 0) return ok(`RESTART_FILES 已随 P1-c 执行器退役一并删除（无被判对象 ⇒ 不适用，非失败）｜扫描面 lib/ 全网 ${libFiles.length} 件`);
    if (hits.length > 1) return assert(false, `RESTART_FILES 在 ${hits.length} 处复现（应唯一）：${hits.map((h) => h.file).join(', ')}`);
    const m = hits[0].m;
    const arr = m[1].split(',').map((s) => s.trim().replace(/^'|'$/g, '')).filter(Boolean);
    const wl = require(abs('package.json')).files;
    const legal = (n) => wl.includes(n) || wl.some((w) => n.startsWith(w + '/'));
    const missing = arr.filter((f) => !exists(f));
    const outside = arr.filter((f) => !legal(f));
    const entries = arr.includes('plugin-host.js') && arr.includes('lib/index.cjs');
    return assert(!missing.length && !outside.length && entries,
      `[${hits[0].file}] ${arr.length} 项｜缺文件 ${missing.length ? missing.join(',') : '无'}｜白名单外 ${outside.length ? outside.join(',') : '无'}｜入口齐 ${entries}`);
  }),
  A('S-7', '结构', 'i18n 全局平衡：`ZH` 与 `EN` 顶层键集相等且非空', '两语言键集完全相同（0 差异）', () => {
    const raw = read('src/client/i18n.js');
    const lit = raw.match(/^module\.exports\s*=\s*"([\s\S]*)"\s*;?\s*$/m);
    if (!lit) return no('未解析到 i18n 字符串字面量');
    const src = lit[1].replace(/\\r\\n/g, '\n').replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    const iZ = src.indexOf('const ZH');
    const iE = src.indexOf('const EN');
    if (iZ < 0 || iE <= iZ) return no('未定位到 ZH/EN 两个表');
    const keys = (block) => { const o = []; const re = /^\s{2}([A-Za-z0-9_]+)\s*:/gm; let x; while ((x = re.exec(block)) !== null) o.push(x[1]); return o; };
    const KZ = keys(src.slice(iZ, iE));
    const KE = keys(src.slice(iE));
    const onlyZ = KZ.filter((k) => !KE.includes(k));
    const onlyE = KE.filter((k) => !KZ.includes(k));
    return assert(KZ.length > 0 && !onlyZ.length && !onlyE.length,
      `ZH ${KZ.length} 键 / EN ${KE.length} 键｜仅 ZH ${onlyZ.length ? onlyZ.join(',') : '无'}｜仅 EN ${onlyE.length ? onlyE.join(',') : '无'}`);
  }),
  A('S-8', '结构', '行尾契约执行：受控文本跨机 LF + 二进制不被转换 + 契约在位且被匹配', 'i/ 与 w/ 仅 lf|none；二进制扩展名有显式 binary 声明；.gitattributes 含 * text=auto eol=lf', () => {
    // 依据：.gitattributes「源文件一律 LF」是**契约**，契约无用例即声明（红队 R5）。
    // 只断言跨机稳定的量：索引/工作树行尾、二进制声明面、契约行本身。判定语义（什么算 LF）不可重定义。
    const attrs = exists('.gitattributes') ? read('.gitattributes') : null;
    if (attrs === null) return no('.gitattributes 不在位（行尾契约无载体）—— i/ w/ attr/ 无从断言');
    const contract = /^\s*\*\s+text=auto\s+eol=lf\s*$/m.test(attrs);
    const r = eolRows();
    if (!r || r.error) return no('git ls-files --eol 不可执行：' + (r && r.error ? r.error : '.git 缺位（非 git 检出 / 解包发行物）'));
    const rows = r.rows.filter((x) => !x.raw);
    const malformed = r.rows.filter((x) => x.raw);
    const scan = (rs) => {
      const text = rs.filter((x) => x.attr === 'text' || x.attr === 'text=auto');
      const bins = rs.filter((x) => x.index === '-text');
      return {
        text, bins,
        badText: text.filter((x) => !['lf', 'none'].includes(x.index) || !['lf', 'none'].includes(x.worktree)),
        // 注：不再有 badBin 腿——「i/-text ⇒ attr 含 binary/-text」与 --eol 的列来源同源，恒真（空转）。
        //     二进制面的真判据是下面的 undeclared（**声明面**：扩展名必须在 .gitattributes 有显式规则）。
        badBin: [],
      };
    };
    const j = scan(rows);
    // 判别力自证（变异体）：把第 1 件 w/lf 改成 w/crlf，同一判定路径必须变红；否则本判据可被静默掏空。
    const at = rows.findIndex((y) => y.worktree === 'lf');
    const neg = scan(rows.map((x, i) => (i === at ? { ...x, worktree: 'crlf' } : x)));
    // 二进制**声明面**：真实存在的二进制扩展名必须在 .gitattributes 有显式规则。
    //   ⚠ 不采用「i/-text ⇒ attr 含 -text」的字面写法——--eol 的 attr/ 列本就是 i/-text 的来源，该式恒真（空转）。
    const body = attrs.split(/\r?\n/).filter((l) => l.trim() && !/^\s*#/.test(l)).join('\n');
    const binExts = [...new Set(j.bins.map((x) => (path.extname(x.file) || '(无扩展名)').toLowerCase()))].filter((e) => e !== '(无扩展名)');
    const undeclared = binExts.filter((e) => !new RegExp('\\*\\' + e + '\\s+(binary|-text)\\s*$', 'm').test(body));
    const zero = rows.length === 0 || j.text.length === 0 || j.bins.length === 0 || binExts.length === 0;
    const dist = (k) => { const m = {}; for (const x of rows) m[x[k]] = (m[x[k]] || 0) + 1; return Object.entries(m).map(([a, b]) => a + '×' + b).join(' '); };
    const show = (xs) => xs.slice(0, 8).map((x) => x.file + '(' + x.index + ' ' + x.worktree + ' ' + x.attr + ')').join(' ');
    // --deep（可选，不进 gate 链）：逐件字节往返核对，防"判据读到的不是磁盘那份"。默认关，避免每跑一次读全仓。
    if (has('--deep') && !zero) {
      const enc = j.text.filter((x) => !roundTripOk(x.file)).map((x) => x.file);
      if (enc.length) return no('字节往返不等（判据读到的与磁盘非同源）' + enc.length + ' 件：' + enc.slice(0, 5).join(',') + '｜i/ ' + dist('index') + '｜w/ ' + dist('worktree'));
    }
    const pass = contract && !zero && !j.badText.length && !j.badBin.length && !undeclared.length && !malformed.length && neg.badText.length === 1;
    return assert(pass,
      '契约行 ' + contract
      + '｜i/ ' + dist('index') + '｜w/ ' + dist('worktree') + '｜attr/ ' + dist('attr')
      + '｜受控 ' + rows.length + ' 件：文本判 ' + j.text.length + ' 恰越界 ' + j.badText.length + (j.badText.length ? '：' + show(j.badText) : '')
      + '｜二进制 ' + j.bins.length + ' 件（扩展名 ' + binExts.join(',') + '）声明缺 ' + undeclared.length + (undeclared.length ? '：' + undeclared.join(',') : '')
      + '｜畸形 --eol 行 ' + malformed.length
      + '｜负控 命中 ' + neg.badText.length + '/1'
      + (zero ? '｜⚠ 空扫：分母含 0（' + rows.length + '/' + j.text.length + '/' + j.bins.length + '），不判绿' : ''));
  }),

  // ── S-10（治理面落地批 2026-10-17 · 处置正本 §12.13.2 **甲-1**）────────────────────────
  // 病历（甲-1 原文）：`peerDependencies` ↔ `dsh.client.inject` 逐项相等**这条红线无任何机械判据**
  //   —— 实测 `grep -rn "peerDependencies" scripts/ test/` 零命中（范围 = 工作区 `scripts/` + `test/`）。
  //   后果不是小错：宿主的 compatibility 门（`dsh-app-boot/lib/index.js` `evaluatePluginCompatibility`）
  //   只审 `peerDependencies` 里 `@deepseek-ai/dsh*` 命名空间，任一不满足即 **deny 整个 bundle**
  //   ⇒ 现象为 profile 启动阶段 `skipping profile bundle`、插件 UI 全无且**客户端零提示**（不可观测）。
  //
  // 判据形态（**三面相等**，逐面**真实读取**，任一面读不到即 fail-closed 判红）：
  //   ① `package.json` 的 `peerDependencies` **键集**
  //   ② `package.json` 的 `dsh.client.inject` **项集**
  //   ③ `package-lock.json` root 条目（`packages[""]`）的 `peerDependencies` **键集**（镜像面）
  //
  // ⚠ **判据边界（如实写明，⛔ 不得让判据看起来比实际更强）**：
  //   · 本断言只判**集合相等**（本仓红线 §五 的原文形态）。它**不判**：
  //     ‑ 某个名字**是否实存/可解析**（那属 `C-31`「待验证的依赖名不得留在声明面」，人载 + 外部环境实算）；
  //     ‑ **semver 区间是否覆盖目标运行时**（同上，须实算）。
  //   · **命名空间边界**：宿主 compatibility 门**只审 `@deepseek-ai/dsh*`**。本断言对**全集合**判相等
  //     （红线原文如此），但若将来注入面出现**非该命名空间**的包，**宿主不会审它** ⇒ 本断言的"绿"
  //     在那类名字上**不代表**"宿主认可其可解析"。⇒ 读数里显式打印命名空间外的项数，使该边界**可见**，
  //     而不是让读者把"三面相等"读成"全部已实算可解析"。
  A('S-10', '结构', '声明面三面相等：`peerDependencies` 键集 == `dsh.client.inject` 项集 == `package-lock.json` root 镜像键集（⚠ 只判集合相等；不判实存/semver；宿主只审 `@deepseek-ai/dsh*`）', '三面集合逐名相等，且各面非空（任一面读不到 ⇒ fail-closed 判红）', () => {
    // 判定逻辑收敛到单一事实源（`scripts/lib/declared-surface.mjs`）：纯函数 ⇒ 可内存变异自证
    // （回归锁见 `test/governance-landing-locks.test.cjs`），此处只做**磁盘读取 + 读数呈现**。
    let pkg, lock;
    try { pkg = JSON.parse(read('package.json')); } catch (e) { return no('package.json 不可解析：' + String(e.message).slice(0, 60)); }
    try { lock = JSON.parse(read('package-lock.json')); } catch (e) { return no('package-lock.json 不可解析：' + String(e.message).slice(0, 60)); }
    const r = compareDeclaredSurface(pkg, lock);
    return assert(r.ok,
      r.reason
      + (r.peer.length || r.inject.length || r.lockPeer.length
        ? `｜peer ${r.peer.length} 项${r.peer.length ? ' [' + r.peer.join(',') + ']' : ''}｜inject ${r.inject.length} 项｜lock-root ${r.lockPeer.length} 项`
        : '')
      // ⚠ 边界行：让"宿主只审该命名空间"这一事实**在读数里可见**，防读者高估本断言的覆盖面
      + `｜⚠ 判据边界：只判集合相等，⛔ 不判实存/semver（属 C-31 人载）；宿主 compatibility 门只审 @deepseek-ai/dsh* ⇒ 命名空间外 ${r.outsideNamespace.length} 项${r.outsideNamespace.length ? '（' + r.outsideNamespace.join(',') + '）其"相等"不代表宿主认可可解析' : '（当前无此类项）'}`);
  }),
];

// ───────────────────────────────── 执行 ─────────────────────────────────

const RUN = [];
async function run(list_, tier) {
  for (const a of list_) {
    let r;
    try { r = await a.fn(); } catch (e) { r = { pass: false, actual: `抛错 ${String(e.message).slice(0, 70)}` }; }
    RUN.push({ tier, ...a, ...r });
  }
}
for (const c of CLAIMS) await run(c.assertions.map((a) => ({ ...(a.kind === '目标' ? { target: true } : {}), claim: c.adr, ...a })), 'CLAIM');
await run(STRUCTURAL, 'STRUCT');

const conflicts = RUN.filter((r) => !r.skip && r.pass === false && !r.target);
const skips = RUN.filter((r) => r.skip);
const pendingTargets = RUN.filter((r) => r.target && r.pass === false);
const passed = RUN.filter((r) => !r.skip && r.pass === true);

const ICON = (r) => (r.skip ? '⤫' : r.pass ? '✓' : r.target ? '⧗' : '✗');
const fmt = (r) => `  ${ICON(r)} ${r.id} ${r.kind}  ${r.detail}\n      期望 ${r.expect}\n      实测 ${r.actual}${r.skip ? '' : ''}`;

function textReport() {
  const out = [];
  out.push('结构判据机检 · ADR 承诺 ↔ 代码现状（P4 · 口径：物理行 = split(\'\\n\').length）');
  out.push(`分母：PE 架构决策 ${CLAIMS.length} 条（ADR-146 · 194 · 197 · 201 · 224 · 230）`);
  out.push('');
  for (const c of CLAIMS) {
    const rows = RUN.filter((r) => r.claim === c.adr);
    out.push(`${c.adr} @${c.anchor} · ${c.at} · [${c.level}] ${c.promise}`);
    for (const r of rows) out.push(fmt(r));
    const p = (c.pending || []).filter((x) => rows.some((r) => r.id === x.id && !r.pass));
    for (const x of p) out.push(`      ↳ 在册依据 ${x.id}：${x.reason}`);
    out.push('');
  }
  out.push('结构性判据（分母 / 在册性）');
  for (const r of RUN.filter((x) => x.tier === 'STRUCT')) out.push(fmt(r));
  out.push('');
  out.push(`⚠ 在册缺陷 ${DEFECTS.length} 条（非 ADR 面，机检发现；有处置指向但**尚未处置**）`);
  for (const d of DEFECTS) {
    out.push(`  ⚠ ${d.id} @${d.at} · ${d.surface}`);
    out.push(`      发现 ${d.finding}`);
    out.push(`      证据 ${d.evidence.join('｜')}`);
    out.push(`      处置 ${d.disposition}（owner=${d.owner}）`);
  }
  out.push('');
  out.push(`汇总：通过 ${passed.length} · 冲突 ${conflicts.length} · SKIP ${skips.length} · 在册未达 ${pendingTargets.length} · 在册缺陷 ${DEFECTS.length}`);
  if (skips.length) out.push(`  SKIP 明细：${skips.map((s) => s.id).join(', ')}（本地治理档/日志缺位——不记 PASS）`);
  return out.join('\n');
}

function mdTable() {
  const out = [];
  out.push('| ADR | 锚点 | 承诺 | 判据 | 档 | 期望 | 实测 | 判定 |');
  out.push('|---|---|---|---|---|---|---|---|');
  for (const r of RUN) {
    const c = CLAIMS.find((x) => x.adr === r.claim);
    out.push(`| ${r.claim || '—'} | \`${c ? c.anchor : '—'}\` | ${c ? c.promise.slice(0, 46) + (c.promise.length > 46 ? '…' : '') : '（结构性）'} | ${r.id} ${r.kind}：${r.detail} | ${r.skip ? 'SKIP' : r.pass ? (r.target ? '在册未达' : 'PASS') : r.target ? '在册未达' : '冲突'} | ${r.expect} | ${r.actual} | ${ICON(r)} |`);
  }
  return out.join('\n');
}

/** 判据面指纹（T2 · 2026-09-27）：**跨环境同值**的判据面摘要。
 *  只吃「非环境派生」列，不吃 期望/实测/判定（那三列随治理日志可不可读而变）。
 *  用法：投影里展示 + `--check` 可归因（漂移时先比指纹）。 */
function claimsFingerprint(rows = RUN, counts = null) {
  // ⚠ 计数里**只许放跨环境同值的量**（本仓实测的坑）：passed/conflicts/skips 随治理日志可不可读
  //   而变（治理根态 33/0/1 vs 工件形态 31/0/3），放进去指纹就会跨形态抖 ⇒ 归因会说反。
  const c = counts || [RUN.length, DEFECTS.length];
  const faces = rows.map((r) => [r.claim || '—', r.id, r.kind, r.detail, r.tier, r.target ? 'T' : '-'].join('\u0001'));
  return 'sha256:' + createHash('sha256').update(faces.join('\u0002') + '\u0003' + c.join(','), 'utf8').digest('hex').slice(0, 16);
}

function mdTail() {
  const out = [];
  // ── 判据面指纹（T2 · 2026-09-27）────────────────────────────────────────────
  // 为什么要有它（本仓实测的假红）：本档**同时**是投影与判定基准，而投影里的「实测/判定」列
  //   **天然随环境变**——实测（--json 逐列比对，同脚本同树）：id/kind/detail/claim/tier/target
  //   两形态全同；actual×2、pass/skip×2、expect×1 仅因「治理日志可不可读」而不同（A194-4/S-2）。
  //   ⇒ 单形态判漂移，另一种形态必然**假红**（实测：治理根态投影留在档里，不带 PE_GOV_ROOT 的
  //     默认形态就报「文档漂移」，而判据表其实一个字都没变）。
  //   故判据面 = 「非环境派生」列（id/kind/detail/claim/tier/target + 计数），跨形态同值。
  //   它点名的是**判据演化**（加/删/改一条断言），不点名读数——正是「投影过期」与「只是换了个
  //   环境跑」的分界。计数进指纹是为了「加一条判据而投影没重生成」可见。
  //   副作用（声明的边界）：断言文案（detail）改动也会让 fingerprint 变，即使判据等价——
  //   工程上是刻意的（本表 detail 即判据文本）；必要时应重生成投影，**不要**判这条为假红。
  out.push(`> fingerprint（判据面指纹·跨环境同值）：\`${claimsFingerprint()}\`（${RUN.length} 条断言｜读数快照 env=${SNAP_ENV}｜判据面 = id/kind/detail/claim/tier/target + 计数，**不含**环境派生的期望/实测/判定列）`);
  out.push('');
  // A-2：`--write` 时把当时的 HEAD 记进投影，供**漂移时点名具体文件**。
  //   ⚠ 只在 --write（SNAP_HEAD 非空）时出现；⚠ 该行**不进逐字比对区**（见 stripFp 的对称剥行）。
  if (SNAP_HEAD) out.push(`> 写入 HEAD（--write 时的提交）：\`${SNAP_HEAD}\`（⛔ 不参与判定；仅漂移时用于 \`git diff --name-status\` 点名文件）`);
  out.push(`> 生成：\`node scripts/arch-claims.mjs --md\`（**投影，勿手抄；判定例程不手抄，见 --check**）｜通过 ${passed.length} · 冲突 ${conflicts.length} · SKIP ${skips.length} · 在册未达 ${pendingTargets.length} · 在册缺陷 ${DEFECTS.length}`);
  out.push('');
  out.push('**在册缺陷（非 ADR 面；有处置指向但尚未处置）**');
  out.push('');
  out.push('| # | 状态面 | 发现 | 证据 | 处置 |');
  out.push('|---|---|---|---|---|');
  for (const d of DEFECTS) out.push(`| ${d.id} | ${d.surface} | ${d.finding} | ${d.evidence.join('<br>')} | ${d.disposition} |`);
  return out.join('\n');
}

function mdReport() { return mdTable() + '\n' + mdTail(); }

if (has('--write')) {
  // A-2：先记下**当时**的 HEAD，再写投影（供漂移时用 `git diff --name-status <HEAD>..HEAD` 点名文件）。
  //   ⚠ 取不到就留 null（投影里那一行随之缺席，判定侧按「无记录」降级，不编造）。
  try { SNAP_HEAD = execFileSync('git', ['rev-parse', '--short', 'HEAD'], { cwd: ROOT, encoding: 'utf8', timeout: 20000 }).trim() || null; } catch { SNAP_HEAD = null; }
  if (exists(DOC)) {
    const src = read(DOC);
    const i = src.indexOf(MARK_BEGIN);
    const j = src.indexOf(MARK_END);
    if (i >= 0 && j > i) {
      fs.writeFileSync(abs(DOC), src.slice(0, i + MARK_BEGIN.length) + '\n\n' + mdReport() + '\n\n' + src.slice(j), 'utf8');
      console.log(`✓ 判据表已写入 ${DOC} 标记区`);
    } else console.log(`✗ ${DOC} 缺标记 ${MARK_BEGIN} / ${MARK_END}，未写入`);
  } else console.log(`✗ ${DOC} 不存在（跳过写入）`);
} else if (has('--md')) {
  console.log(mdReport());
} else if (has('--json')) {
  console.log(JSON.stringify({
    peAdrSet: PE_ADR_SET,
    summary: { pass: passed.length, conflict: conflicts.length, skip: skips.length, pendingTarget: pendingTargets.length, defects: DEFECTS.length },
    defects: DEFECTS,
    rows: RUN.map(({ fn, ...r }) => r),
  }, null, 1));
} else {
  console.log(textReport());
}

/** 投影漂移**分类器**（纯函数·可内存变异自证，见 B234-6）。
 *  region: string（标记区文本）| null（档不存在）| undefined（档在但缺标记）
 *  envOnly / stale-readings ⇒ 判据面没变，差异只来自环境派生列（期望/实测/判定）。
 *  drift ⇒ 判据面变了（判据演化 / 表体缺行 / 指纹被替换 / 同环境读数漂移）⇒ 投影确实过期。 */
function classifyDrift(region, computedMd, fp, n, rows = [], snapEnv = null, stripFp = null) {
  if (region === null) return { kind: 'missing-doc' };
  if (region === undefined) return { kind: 'missing-marker' };
  // ⚠ 两件事必须分开：①指纹/条数/env 从**原始档区**读（它们是数据）；
  //   ②比对拿**已剥指纹行**的档区（与 compute 侧对称）。曾把两者合成一步 ⇒ 指纹读成（无）、
  //   "环境一致"被误报成指纹不一致（2026-09-27 实测踩到，两种环境都红）。
  const meta = String(region).trim();
  const r = stripFp ? stripFp(meta) : meta;
  const docFp = (meta.match(/fingerprint（[^）]*）：`(sha256:[0-9a-f]+)`/) || [])[1] || null;
  // 指纹行把「读数快照 env=…」插在条数与判据面之间 ⇒ 条数定式只能取到「N 条断言」，
  //   不能沿用上游那版「（N 条断言｜判据面 = 」——旧定式会取不到条数，
  //   把「判据面未过期」误判成过期（2026-09-27 实测踩到）。
  const boundN = (meta.match(/（(\d+) 条断言/) || [])[1] || null;
  const docEnv = (meta.match(/读数快照 env=([a-z-]+)/) || [])[1] || null;
  // 三腿：①档内指纹有值 ②等于本形态实算值 ③条数与本形态一致
  const fpConsistent = docFp === fp && boundN === String(n);
  const verbatim = r === String(computedMd).trim();   // r 已剥指纹行，与 compute 侧对称
  // 表体**行绑定**：每行的 `| id kind：detail |` 必须逐字在位。防"留着指纹行、把表体删空/删几行"，
  //   也防"投影是旧判据面拼出来的新指纹"。（不切单元格：实测 S-8 的期望/实测列内含 ASCII `|`，
  //   切列会误判——这也是读数列不得参与判定的又一条理由。）
  const rowPrefix = (x) => `| ${x.id} ${x.kind}：${x.detail} |`;
  const missingRows = rows.filter((x) => !r.includes(rowPrefix(x)));
  if (verbatim) return { kind: 'none', docFp, boundN, fpConsistent, missingRows };
  // 判据面（指纹 + 表体逐行）一致 ⇒ 差异只能在**读数尾巴**上。还要再分一层，
  //   因为「换环境」与「同环境读数变了」是两件事：
  //   · 档内读数取自**另一种**环境（env 标签不同）⇒ 陈旧读数，刷新即可，**不判漂移**；
  //   · **同一种**环境、读数却变了 ⇒ 环境解释不了（例如代码改了、实测值跟着动）⇒ 仍判红。
  //     ⚠ 少了这一层就是把闸门放宽：同环境也先放过，等于把「读数漂移」整类静默掉——
  //       那正是本仓最忌的「失败不可观测」。
  const thesisOk = fpConsistent && !missingRows.length;
  const envExplains = !!docEnv && docEnv !== snapEnv;
  if (thesisOk && envExplains) return { kind: 'stale-readings', docFp, boundN, docEnv, fpConsistent, missingRows, envOnly: true };
  return { kind: 'drift', docFp, boundN, docEnv, fpConsistent, missingRows, envOnly: false, sameEnvReadings: thesisOk };
}

/** 漂移**归因文本**（纯函数·可内存变异自证，见 B234-7）。
 *  判据面「变没变」决定措辞，**两分类不得互相借用**：
 *   · 面变（指纹/条数/表体任一失效）⇒ 判据面**已过期**，是判据演化；
 *   · 面未变、只剩同环境读数漂移 ⇒ 判据面**未变**，不得写「已过期」（一个字未改却叙述成过期，
 *     即 b2/I3「措辞与事实相反」同族缺陷——2026-09-27 独立复核实测踩到）。
 *  tail 供收尾行复用，避免收尾与上文两处说反。 */
function driftAttribution(drift, localFp, localN, snapEnv) {
  const missing = drift.missingRows || [];
  const legs = [];
  if (drift.docFp !== localFp) legs.push(`指纹不一致（档内 ${drift.docFp || '（无）'} vs 本形态 ${localFp}）`);
  if (drift.boundN !== String(localN)) legs.push(`条数不一致（档内 ${drift.boundN || '（无）'} 条 vs 本形态 ${localN} 条）`);
  if (missing.length) legs.push(`表体缺行 ${missing.length}/${localN}（如 ${missing.slice(0, 3).map((x) => x.id).join(',')}）`);
  if (drift.sameEnvReadings) legs.push(`读数漂移（同为 env=${snapEnv}，实测/判定列却与投影不符）`);
  const faceChanged = drift.docFp !== localFp || drift.boundN !== String(localN) || missing.length > 0;
  const why = faceChanged
    ? `判据面**已过期**（${legs.join('｜') || '表体与指纹之外的内容不一致'}）——投影随判据演化而过期，请在**本形态**跑 --write 重生成`
    : `判据面**未变**，同环境（env=${snapEnv}）读数漂移：${legs.join('｜')}——档内指纹与表体均与本形态一致，不符的是**读数列**（判据面一个字未改），请跑 --write 重生成`;
  const tail = faceChanged
    ? '上面已归因：判据面变了，不是换环境'
    : '上面已归因：判据面未变，是同环境读数漂移（不是判据演化）';
  return { faceChanged, why, tail };
}

/** 漂移**逐文件成因**的读取面（A-2 · 2026-10-19 抽成一处可复用，供 drift / stale-readings 两支共用）。
 *  为什么要有它：S-8 一类「受控件数变了」的漂移，光知道 A≠B 还得自己去猜是哪几个文件——
 *   `--write` 记下的 HEAD 存在时，`git diff --name-status <记下的HEAD>..HEAD` 能**直接点名**；
 *   没有记录（旧投影 / 非 git 检出）时逐级降级到工作区未提交差集与 git log，不编造。
 *  ⚠ 只**读**、只**返回数据**：不判定、不写盘、不改任何通过条件。 */
function fileAttribution(docRegion, entry, kind = 'drift') {
  const stale = kind === 'stale-readings';
  // ⚠ 措辞分流：stale-readings **不是漂移**，正文里不得出现"本漂移"（作业书 §1.1 的坑）。
  const what = stale ? '本处读数不可比' : '本漂移';
  const s8 = RUN.find((x) => x.id === 'S-8');
  const numFrom = (t) => { const m = String(t || '').match(/受控 (\d+) 件/); return m ? Number(m[1]) : null; };
  const A = numFrom(docRegion);
  const B = numFrom(s8 && s8.actual);
  const recorded = String(docRegion || '').match(/^> 写入 HEAD（--write 时的提交）：`([0-9a-f]{7,40})`/m);
  const head = recorded ? recorded[1] : null;
  const out = [];
  out.push('   档内受控件数 A=' + (A === null ? '（无）' : A + ' 件') + '；本次实算 B=' + (B === null ? '（无）' : B + ' 件')
    + (A !== null && B !== null ? '（相差 ' + (B - A) + ' 件）' : ''));
  const git = (args) => {
    try { return execFileSync('git', args, { cwd: ROOT, encoding: 'utf8', timeout: 20000 }); } catch { return null; }
  };
  // ① 首选：--write 记下的 HEAD → 直接点名「投影生成之后」增删/改名的文件
  if (head) {
    const ns = git(['diff', '--name-status', head + '..HEAD']);
    if (ns === null) {
      out.push('   投影记录的 HEAD=' + head + '，但 git diff 不可用 ⇒ 逐文件请跑：git status --porcelain / git log --name-status');
    } else {
      const rows = String(ns).split('\n').map((l) => l.trim()).filter(Boolean);
      if (!rows.length) {
        out.push('   投影记录的 HEAD=' + head + '..HEAD 之间**无提交差异** ⇒ 文件增删改名不是' + what + '的成因'
          + (stale ? '（成因是本形态与投影的环境标签不同，见下一行）' : '（成因见上行走廊）'));
      } else {
        out.push(stale
          ? '   投影生成之后的提交差集（git diff --name-status ' + head + '..HEAD）——**仅说明这期间动过什么**；'
            + '本处读数不可比**不是**它们造成的（成因见下面的环境标签行）：'
          : '   投影记录的 HEAD=' + head + ' → 当前 HEAD 之间的文件差集（git diff --name-status ' + head + '..HEAD）——受控件数就是被这些条目改的：');
        for (const l of rows.slice(0, 40)) out.push('     ' + l);
        if (rows.length > 40) out.push('     …另有 ' + (rows.length - 40) + ' 条，跑 git diff --name-status ' + head + '..HEAD 看全');
      }
    }
  } else {
    out.push('   ⚠ 档内**无** HEAD 记录（该投影由旧版 --write 写出）⇒ 无法用 git diff 点名文件；先按下面次序重生成，下次即可点名：');
  }
  // ② 工作区未提交差集（--write 之后又有改动时的形态）
  const st = git(['status', '--porcelain']);
  const wl = String(st || '').split('\n').filter((l) => l.trim());
  if (wl.length) {
    out.push('   另有工作区未提交改动（git status --porcelain）——它们尚未进 HEAD，同样会改受控件数：');
    for (const l of wl.slice(0, 40)) out.push('     ' + l);
    if (wl.length > 40) out.push('     …另有 ' + (wl.length - 40) + ' 条，跑 git status 看全');
  } else if (!head) {
    out.push('   工作区干净 ⇒ 差异来自**档生成之后**的提交；逐文件用：git log --oneline --name-status -20');
  }
  if (A !== null && B !== null && A === B) {
    out.push('   ⚠ 受控件数未变（A=B）⇒ ' + what + '不是"文件增删"造成的'
      + (entry ? '；成因见上行走廊：' + entry : (stale ? '；成因见下一行的环境标签差异' : '')));
  }
  return out;
}

/** 漂移/陈旧读数时的**自解释输出**（A-1 · 2026-10-19：抽成一处可复用，两支共用三件事）。
 *
 *  三件事（每支都打印，⛔ 不是只给 drift）：
 *    ① 可复制的修复命令；② A vs B 差额 + 逐文件成因；③ 「读数须在提交之后取」。
 *
 *  ⚠⚠ **两分支的措辞必须分开**（作业书 §1.1 点名的坑）：
 *    · `drift`           = 判据表与投影**不一致**（判据面变了 / 同环境读数变了）⇒ 投影**确实过期**；
 *    · `stale-readings`  = 投影本身仍与判据表一致，只是**读数取自另一种环境** ⇒ 它**不是漂移**，
 *      是「换环境导致读数不可比」。若把两者写成同一句话，读的人下次就会把"换环境"当成
 *      "判据演化"去改判据面 —— 那正是本环历史上假红的来源（2026-09-27 实测）。
 *
 *  ⚠ 硬边界（红线）：只**打印**，⛔ 不改通过条件、不改三态语义、不改指纹、不自动 --write。 */
function printSelfExplain(kind, attr, docRegion) {
  const stale = kind === 'stale-readings';
  console.log('');
  console.log(stale
    ? '=== 自解释（读数快照陈旧 —— ⚠ 这不是"漂移"）==='
    : '=== 自解释（本环红了要你做什么）===');
  if (stale) {
    console.log('   口径：投影的表体与判据面**与本形态一致**，差异只在环境派生列（期望/实测/判定）——');
    console.log('   即「换了一种环境取读数 ⇒ 两边的读数不可比」，**判据表一个字都没变**，不记冲突。');
  }
  console.log(stale
    ? '① 刷新命令（可直接复制；⚠ 须在**本形态**里跑，否则下次仍不可比）——'
    : '① 修复命令（可直接复制）——');
  console.log('   node scripts/arch-claims.mjs --write');
  console.log(stale
    ? '② 本次「不可比」的读数来源与文件面 ——'
    : '② 本次漂移的逐文件成因 ——');
  for (const l of fileAttribution(docRegion, stale ? null : (attr && attr.why), kind)) console.log(l);
  if (stale) {
    console.log('   本形态 env=' + SNAP_ENV + ' ← 投影取自 env=' + (docRegion && (String(docRegion).match(/读数快照 env=([a-z-]+)/) || [])[1] || '?')
      + ' ⇒ 两边**环境标签不同**；要可比就统一形态再 --write（⛔ 不要为此改判据面）。');
  }
  console.log('③ ⚠ 读数须在**提交之后**取 —— --write 写进去的是「当前工作区读数」；');
  console.log('   若还有未提交改动（新增/删除/改行尾），投影会在下次提交后**立刻再漂移/再不可比**。');
  console.log(stale
    ? '   正确顺序：先 commit ⇒ 再 --write ⇒ 再 commit 那次投影刷新（且 --write 与 --check 须同一环境形态）。'
    : '   正确顺序：先 commit ⇒ 再 --write ⇒ 再 commit 那次投影刷新。');
}

if (has('--check')) {
  // 判定例程（**不手抄**）：把指纹行从**两侧**都剥掉，只比其余部分。
  //   ⚠ 两侧必须用**同一个**剥行函数（对称）——--write 写进档里的投影是**含**指纹行的，
  //     只剥实算侧就永远比不齐、还会把"环境一致"误报成"读数快照陈旧"（2026-09-27 实测踩到）。
  //   ⚠ 必须自底向上重算，不得引用投影里那行 fingerprint——否则"改档里的指纹"能绕过门禁。
  //   ⚠ A-2（2026-10-19）：写入 HEAD 那行**必须同样剥掉**（两侧对称）。它每提交一次就变，
  //     若留在逐字比对面里，**每次 commit 都会把投影判成漂移** —— 那正是 A-2 的陷阱本身。
  const stripFp = (t) => String(t).split('\n').filter((l, i, a) => !/^> fingerprint（/.test(l)
    && !/^> 写入 HEAD（/.test(l)
    // 剥行后空行塌缩，按同样规则归一：丢弃"生成："行**之后**的第一个空行
    && !(i > 0 && /^> 生成：/.test(a[i - 1]) && l === '')).join('\n').trim();
  const stampedMd = () => stripFp(mdReport());
  const docText = exists(DOC) ? read(DOC) : null;
  const docRegion = (() => {
    if (docText === null) return null;                    // 本地治理档缺位 → 不判漂移（SKIP）
    const i = docText.indexOf(MARK_BEGIN);
    const j = docText.indexOf(MARK_END);
    return (i < 0 || j < 0) ? undefined : docText.slice(i + MARK_BEGIN.length, j);
  })();

  const localFp = claimsFingerprint();
  const localN = RUN.length;
  // 档区原样传入；classifyDrift 内部分离「读元数据（原始）」与「比对（已剥指纹行）」两侧
  const drift = classifyDrift(docRegion, stampedMd(), localFp, localN, RUN, SNAP_ENV, stripFp);
  // 判据面指纹一致性：档里那行必须**同时**满足 ①有值 ②与本形态实算值相等 ③条数与本形态一致。
  //   三腿缺一即记一票冲突（原来这条只会打印，不参与判定——改档里的指纹或留下旧指纹都无人抓）。
  const fpConsistent = !!drift.fpConsistent;
  // 收尾措辞的**诚实腿**（b2/I3 同源教训）：本环存在 SKIP ⇒ 措辞不得说「一致」而不加限定，
  //   否则"有环未判"会被读成"判过了"。这条在**加指纹前就已存在**（实测：治理根态输出
  //   「✓ 结构判据一致：… SKIP 0」而工件形态输出同样以「✓ 结构判据一致」开头、SKIP 3——
  //   门禁编排器靠**尾行计数**兜住了，但人读会被误导）。声明它，不改任何环的判定语义。
  const partial = skips.length > 0;
  const fpLine = `判据面指纹 ${localFp}（${localN} 条断言）${drift.docFp && drift.docFp !== localFp ? `｜⚠ 投影内指纹不一致：${drift.docFp}` : ''}`;

  if (drift.kind === 'missing-marker') {
    console.log(`⚠ ${DOC} 缺标记区，文档漂移未判（本地档可重建，可跑 --write 重生成）`);
  } else if (drift.kind === 'missing-doc') {
    console.log(`⤫ 文档投影未判：${DOC} 不存在（本地治理档 gitignore，CI/干净 clone 无此件）——不记 PASS｜${fpLine}`);
  } else if (drift.kind === 'stale-readings') {
    // ── 归因两分（其一）：判据面**没变**，只是读数取自另一种环境 ──────────────
    // 这是本会要的「读数可解释」：**不判漂移、不 exit 1**（否则换个环境跑就假红，
    //   而判据表其实一个字都没变）。
    console.log(`⤫ 读数快照陈旧（非判据面漂移）：投影表体与判据面一致，仅环境派生列（期望/实测/判定）取自`
      + ` env=${drift.docEnv || '?'} 而本次是 env=${SNAP_ENV}——跑 --write 可刷新，本条不记 PASS 也不记冲突｜${fpLine}`);
    // ── A-1（2026-10-19）：自解释块扩到本支 ──────────────────────────────────
    //   病历：同一族「换环境导致读数不可比」的提示此前只有一句，不说**拿什么命令修 / 是哪几个
    //   文件 / 读数须在提交之后取**；而 drift 支已有那三件事 ⇒ 形状不对称，读的人仍要自己拼。
    //   ⚠ 措辞由 printSelfExplain 按 kind 分流：本支**不是漂移**，⛔ 不得与 drift 支混为一谈。
    //   ⚠ 硬边界：只**打印**，⛔ 不改通过条件、不改三态语义、不自动 --write。
    printSelfExplain('stale-readings', null, docRegion);
  } else if (drift.kind === 'drift') {
    // 归因另一支：**点名具体是哪条腿失效**——笼统写「指纹 A vs B」会把'指纹相同但表体缺行'
    //   也叙述成指纹不同（实测踩到）。⚠ 措辞由 driftAttribution 统一出，面未变时**不得**说「已过期」。
    const attr = driftAttribution(drift, localFp, localN, SNAP_ENV);
    console.log(`✗ 文档漂移：判据表与投影不一致｜${attr.why}｜${fpLine}`);
  }

  // 状态出口（T1/P5）：三态与尾行、退出码**同源**——基于上面 M-1 的 drift.kind 分类（不再用字符串比较）。
  // ⚠ 只有**真漂移**（drift）与**真冲突**（conflicts）才 FAIL。
  //   missing-doc = 治理档不在（CI/干净 clone 必然缺位，gitignore 覆盖）⇒ 结构性缺位 ⇒ SKIP；
  //   missing-marker / stale-readings = 不判漂移（既有口径）⇒ 连同无冲突时落 SKIP 或 PASS。
  //   ⚠ 不得把 missing-doc 记 FAIL：退出码路径只给 drift 退 1，记 FAIL 会产出「FAIL 而 exit 0」的自相矛盾
  //     （CI 实测踩到：RING arch-claims FAIL exit 0）。
  const driftIsReal = drift.kind === 'drift';
  const ringState = (conflicts.length || driftIsReal)
    ? ['FAIL', conflicts.length
      ? `结构判据冲突 ${conflicts.length} 条：${conflicts.map((c) => c.id).join(', ')}`
      : '文档漂移：判据表与投影不一致']
    : skips.length
      ? ['SKIP', `断言 ${passed.length} 通过 · 冲突 0 · SKIP ${skips.length}（未判：${skips.map((s) => s.id).join(',')}——本地治理档/日志缺位，不记 PASS）`]
      : ['PASS', `断言 ${passed.length} 通过 · 冲突 0 · SKIP 0 · 在册未达 ${pendingTargets.length} · 在册缺陷 ${DEFECTS.length}`];
  if (conflicts.length) {
    console.log(`✗ 结构判据冲突 ${conflicts.length} 条：${conflicts.map((c) => c.id).join(', ')}`);
    emitRingState('arch-claims', ringState[0], ringState[1]);
    process.exit(1);
  }
  if (drift.kind === 'drift') {
    const attr = driftAttribution(drift, localFp, localN, SNAP_ENV);
    console.log(`✗ ${attr.faceChanged ? '投影已过期' : '投影读数漂移'}：请跑 --write 重生成（${attr.tail}）`);
    // ── D-5（清债批 2026-10-19）：红得能自解释 ────────────────────────────────
    //   病历：S-8（行尾契约 / 受控件数）漂移在历史上已第 9 次出现，而每次的**输出**只说明
    //   "投影与判据表不一致"，不告诉人：拿什么命令修、这次的差异是哪几个文件造成的、
    //   以及最要命的一条——**读数必须在提交之后取**（提交前写进去的投影下次提交后立刻再漂）。
    //   ⇒ 本段只在**真漂移**时打印，逐条补齐这三件事。
    //   ⚠ 硬边界（红线）：只**打印**，⛔ 不改通过条件、不改三态语义、不改指纹、不自动 --write。
    //   A-1（2026-10-19）：原内联块抽成 printSelfExplain —— 与 stale-readings 支共用**同一处输出**，
    //   但措辞按 kind 分流（⛔ 两支文案不得混为一谈）。逐文件成因多了 `--write` 记下的 HEAD
    //   这一级（A-2）：可直接 `git diff --name-status <记下的 HEAD>..HEAD` 点名文件。
    printSelfExplain('drift', attr, docRegion);
    emitRingState('arch-claims', ringState[0], ringState[1]);
    process.exit(1);
  }
  // 防手抄腿：档在、标记在、**档区与实算逐字相等**却仍不一致 ⇒ 只能是档内那行指纹被
  //   替换/缺失/条数过期（逐字相等时该腿不会误伤）。⚠ 不受 partial 影响——有 SKIP 也得抓。
  const docPresent = drift.kind !== 'missing-doc' && drift.kind !== 'missing-marker';
  if (docPresent && fpConsistent === false) {
    console.log(`✗ 投影内指纹行与会话实算不符（防手抄失效）：档内 ${drift.docFp || '（无）'} / ${drift.boundN || '（无）'} 条 vs 本形态 ${localFp} / ${localN} 条——请跑 --write 重生成`);
    emitRingState('arch-claims', ringState[0], ringState[1]);
    process.exit(1);
  }
  const tail = partial
    ? `（${passed.length} 条判定通过；另有 SKIP ${skips.length} 条**未判**：${skips.map((s) => s.id).join(', ')}——本条不是"全过"）`
    : '（——有处置指向、尚未处置）';
  console.log(`✓ 结构判据一致${partial ? '（未判全）' : ''}：断言 ${passed.length} 通过 · 冲突 0 · SKIP ${skips.length}（本地档/日志缺位）· 在册未达 ${pendingTargets.length} · 在册缺陷 ${DEFECTS.length}${tail}｜${fpLine}`
    + (drift.kind === 'stale-readings' ? `｜读数快照 env=${drift.docEnv || '?'} ≠ 本次 env=${SNAP_ENV}（表体与判据面一致，仅读数列陈旧；跑 --write 可刷新，不记冲突）` : ''));
  // 收尾措辞的诚实腿：有 SKIP 时不得只留一个 ✓ 让编排器/人读成"全过"。
  if (partial) console.log(`⤫ 未判全：SKIP ${skips.length} 条（${skips.map((s) => s.id).join(', ')}）——不记 PASS`);
  // 正常出口：与环级状态同源打契约行（恰一行，走 stderr）
  emitRingState('arch-claims', ringState[0], ringState[1]);
}
