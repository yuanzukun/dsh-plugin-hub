'use strict';

// 目标模式：增强阶段执行器普通模块的产物面与接线锁。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { REPO_ROOT } = require('../scripts/lib/chunk-decode.mjs');
const { createEnhancePipeline } = require('../src/host/enhance-pipeline.cjs');

const PIPELINE_REL = 'src/host/enhance-pipeline.cjs';

test('HPMOD-01 普通模块在位且可独立求值', () => {
  assert.equal(fs.existsSync(path.join(REPO_ROOT, PIPELINE_REL)), true, '增强阶段模块必须存在');
  assert.equal(typeof createEnhancePipeline, 'function');
});

test('HPMOD-02 产物内联增强阶段模块与共享契约（无外部 require）', () => {
  const host = fs.readFileSync(path.join(REPO_ROOT, 'plugin-host.js'), 'utf8');
  assert.ok(host.includes('"src/host/enhance-pipeline.cjs"'), 'host 产物必须内联增强阶段模块 id');
  assert.ok(host.includes('"src/shared/contracts/enhance-stages.cjs"'), 'host 产物必须内联阶段契约');
  assert.ok(host.includes('createEnhancePipeline'), 'host 产物必须含增强阶段工厂');
  assert.equal(host.includes("require('../src/host/enhance-pipeline.cjs')"), false,
    'host 产物不得保留外部 require');
  assert.equal((host.match(/require\(/g) || []).length, 0, 'host 产物不得含外部 require');
});

test('HPMOD-03 主链按共享契约一次运行全部阶段（不再逐条写死）', () => {
  const handlers = fs.readFileSync(path.join(REPO_ROOT, 'src/host/enhance-handlers-module.cjs'), 'utf8');
  assert.ok(handlers.includes('await runEnhancePipeline(state);'), '主链必须调用统一执行器');
  assert.equal(/await runEnhanceStages\('(analyze|retrieve|assemble|llm)', state\)/.test(handlers), false,
    '主链不得再逐条写死四阶段调用');
  assert.ok(handlers.includes("registerEnhanceStage('analyze'"), '阶段注册仍在');
  assert.ok(handlers.includes("registerEnhanceStage('retrieve'"), '阶段注册仍在');
  assert.ok(handlers.includes("registerEnhanceStage('assemble'"), '阶段注册仍在');
  assert.ok(handlers.includes("registerEnhanceStage('llm'"), '阶段注册仍在');
});

test('HPMOD-04 线上阶段名未改：enhance/progress 契约仍为 llm', () => {
  const host = fs.readFileSync(path.join(REPO_ROOT, 'plugin-host.js'), 'utf8');
  assert.ok(host.includes("registerEnhanceStage('llm'"), '生成阶段必须仍注册为 llm');
  assert.ok(host.includes("stage: rec.stage || STAGE_PREPARE"), 'progress 的 stage 字段保持原契约');
  assert.equal(host.includes("registerEnhanceStage('generate'"), false, '不得把线上阶段名改成 generate');
});
