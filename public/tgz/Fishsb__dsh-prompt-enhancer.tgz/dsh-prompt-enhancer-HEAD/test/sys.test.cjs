'use strict';
// sys.cjs 共享原语单测（M0 基线补充）
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const net = require('node:net');
const sys = require('../lib/sys.cjs');
const psvc = require('../lib/platform-service.cjs');

test('SYS-01 executorDir 返回外部版本化目录', () => {
  const dir = sys.executorDir('0.1.6');
  assert.ok(dir.includes('dsh-prompt-enhancer'));
  assert.ok(dir.includes('executor'));
  assert.ok(dir.endsWith(path.join('0.1.6')), '版本号作为末级目录');
});

test('SYS-02 profileDir 返回 DSH profile 路径', () => {
  const dir = sys.profileDir('web');
  assert.ok(dir.endsWith(path.join('.dsh', 'profiles', 'web')), 'profile 路径拼接正确');
});

test('SYS-03 isLocalTarballInstallArgs 只允许 staging 内 tarball', () => {
  const good = sys.isLocalTarballInstallArgs([
    'node', 'plugin', '--profile', 'web', 'add', path.join(sys.STAGING_DIR, 'dsh-prompt-enhancer-2.8.3.tgz'),
  ]);
  assert.equal(good, true, 'staging 内 tgz 应放行');

  const badPath = sys.isLocalTarballInstallArgs([
    'node', 'plugin', '--profile', 'web', 'add', 'C:\\Temp\\evil.tgz',
  ]);
  assert.equal(badPath, false, 'staging 外路径应拒绝');

  const badExt = sys.isLocalTarballInstallArgs([
    'node', 'plugin', '--profile', 'web', 'add', path.join(sys.STAGING_DIR, 'evil.zip'),
  ]);
  assert.equal(badExt, false, '非 tgz 应拒绝');

  const badArgs = sys.isLocalTarballInstallArgs(['node', 'plugin', '--profile', 'web', 'install', 'x.tgz']);
  assert.equal(badArgs, false, '非 add 命令应拒绝');
});

// P3-2d（2026-10-14）：`isEnvcheckBlocked` 已随探针肢体收口退役（生产面零消费者；
//   其承载的 envcheck RPC 面早随 P1-c 消失）⇒ 判据对象**整体消失**。
//   ⚠ 非改浅：对象消失是唯一合法退役理由（`CHG-025`）。原 2 条语义断言随之退役 ——
//   本批**不**保留「找不到就算过」的软断言；改为**反向守卫**：该符号**必须不在**导出面。
test('SYS-04 isEnvcheckBlocked 已退役（P3-2d · 判据对象整体消失 · 反向守卫）', () => {
  assert.equal(sys.isEnvcheckBlocked, undefined,
    'isEnvcheckBlocked 必须已从 lib/sys.cjs 导出面退役（生产面零消费者）');
});

// P3-2b（2026-10-14）：`extractPure` **整体退役** ⇒ 本用例的判据对象**整体消失**。
//   处置（依「判据退役的唯一合法理由是判据对象整体消失」）：把「求值路径**已终结**」这一
//   新事实**固化**为断言，并把原先只由 extractPure 覆盖的 `mergeEnvPath` **行为面**迁到
//   原生实现上（下方 U44 已打原生实现；此处只锁「已终结」+「原生导出在位」）。
//   ⚠ 这不是改浅：原断言管「切片求值能取出 mergeEnvPath」，现断言管
//     「**该求值路径整体不存在** + 原生实现承其位」——方向由「可用」转为「**必须不存在**」。
test('SYS-05 求值路径已终结 + env 合并肢体退役（P3-2b/P3-2c · 判据对象整体消失）', () => {
  // ① extractPure 不再存在于 sys 导出面（防复活）
  assert.equal(sys.extractPure, undefined, 'extractPure 已退役，不得再出现在 lib/sys.cjs 导出面');
  // ② P3-2c（2026-10-14）：`mergeEnvPath` / `mergedEnv`（env 合并肢体）已随本批退役。
  //    其唯一上游是零调用者的 `harness.probeEnv` facade ⇒ 判据（生产面零消费者）成立。
  //    ⚠ 原断言「原生实现承其位」的对象**已不存在** ⇒ 改为**反向守卫**（不得复活），门槛不降。
  assert.equal(sys.mergeEnvPath, undefined, 'mergeEnvPath 已随 env 合并肢体退役（P3-2c）');
  assert.equal(sys.mergedEnv, undefined, 'mergedEnv 已随 env 合并肢体退役（P3-2c）');
  // ③ lib/sys.cjs 源码内不再出现 new Function（该求值路径终结的**机械**判据）
  const REPO = path.join(__dirname, '..');
  const src = fs.readFileSync(path.join(REPO, 'lib', 'sys.cjs'), 'utf8');
  assert.equal((src.match(/new Function\(/g) || []).length, 0,
    'lib/sys.cjs 内 new Function 计数必须为 0（P3-2b 后）');
  // ④ PURE 区侧副本不得复活（单一事实源纪律；原 PURE 版本已随本批移除）
  const pureSrc = fs.readFileSync(path.join(REPO, 'src', 'host', 'pure.js'), 'utf8');
  assert.ok(!pureSrc.includes('function mergeEnvPath'),
    'PURE 区不得重建 mergeEnvPath 副本（会形成双实现漂移）');
});

/* ================= 批次C（P1-4）：probeEnv 异步化 + net 熔断 ================= */

/** promisified-execFile 契约 mock：handlers 按 'cmd arg1 arg2' 匹配（缺省回退 handlers[cmd]）；
 *  值为 resolve 对象 {stdout,stderr}、Error 实例（reject）、或 (args)=>… 工厂。 */
function makeExecMock(handlers) {
  const calls = [];
  const fn = async (cmd, args) => {
    const key = cmd + (args.length ? ' ' + args.join(' ') : '');
    calls.push(key);
    const h = handlers[key] !== undefined ? handlers[key] : handlers[cmd];
    if (h === undefined) throw Object.assign(new Error('unexpected exec: ' + key), { code: 'UNMOCKED' });
    if (typeof h === 'function') return await h(args);
    if (h instanceof Error) throw h;
    return h;
  };
  fn.calls = calls;
  return fn;
}

const WHERE_OK = { stdout: 'C:\\WINDOWS\\System32\\sc.exe\r\n' };
/** 平台工具解析命令（与 lib/sys.cjs probeEnv 预检同源）：win `where sc.exe`；darwin `which launchctl`；
 *  linux `which systemctl`。mock 键 =「命令 参数」——POSIX 侧工具预检与 tools 项是同一命令，共用一个 handler。
 *  注：不把「发行版一定装了 which」当前提——POSIX 真机若缺 which，runProbeAsync 映射 ENOENT，
 *  probeEnv 照既有语义落「工具不可达」早退；本组用例注入 mock 执行器，故与真实 PATH 无关。 */
const TOOL_PROBE_TARGET = process.platform === 'win32' ? 'sc.exe'
  : process.platform === 'darwin' ? 'launchctl' : 'systemctl';
const TOOL_PROBE_KEY = (process.platform === 'win32' ? 'where' : 'which') + ' ' + TOOL_PROBE_TARGET;
const TOOL_PROBE_OK = process.platform === 'win32' ? WHERE_OK : { stdout: '/usr/bin/' + TOOL_PROBE_TARGET + '\n' };
const NETSTAT_3080_4242 = '\r\nTCP    0.0.0.0:3080           0.0.0.0:0              LISTENING       4242\r\n';
const NETSTAT_NONE = '\r\nTCP    0.0.0.0:9999           0.0.0.0:0              LISTENING       99\r\n';
const TASKLIST_SVC0 = '"node.exe","4242","Services","0","8,888 K"\r\n';
const CURL_EXIT7 = Object.assign(new Error('curl exit 7'), { code: 7 });

/** win 全链标准 mock（工具预检过 + 3080 有监听者 + curl 可控）。 */
function winChainMock(curlResult) {
  return makeExecMock({
    [TOOL_PROBE_KEY]: TOOL_PROBE_OK,
    'netstat -ano': { stdout: NETSTAT_3080_4242 },
    'tasklist /FO CSV /NH': { stdout: TASKLIST_SVC0 },
    curl: curlResult,
  });
}
/** win 无监听链 mock。 */
function winNoListenerMock(curlResult) {
  return makeExecMock({
    [TOOL_PROBE_KEY]: TOOL_PROBE_OK,
    'netstat -ano': { stdout: NETSTAT_NONE },
    curl: curlResult,
  });
}
/** sc query/qc 异步孪生 mock（RUNNING + AUTO_START）。 */
function scRunningAsync() {
  return async (cmd, args) => {
    if (cmd === 'sc' && args[0] === 'query') return { ok: true, status: 0, stdout: 'STATE : 4 RUNNING', stderr: '', error: null };
    if (cmd === 'sc' && args[0] === 'qc') return { ok: true, status: 0, stdout: 'START_TYPE : 2 AUTO_START', stderr: '', error: null };
    throw Object.assign(new Error('unexpected ' + cmd), { code: 'UNMOCKED_PSVC' });
  };
}

/** POSIX 服务检测孪生 mock（与 platform-service 平台分发同源）：linux `systemctl is-active/is-enabled`；
 *  darwin `launchctl list`。state='running'|'stopped'——win 侧仍走 scRunningAsync（原样，不动）。
 *  输出对齐解析契约：parseSystemdActive 认 status 0 + 'active'/'inactive'（'inactive' = 已装未运行）。 */
function posixServiceMock(state) {
  return async (cmd, args) => {
    if (cmd === 'launchctl' && args[0] === 'list') {
      return { ok: true, status: 0, stdout: state === 'running' ? '4242 0 dsh-web' : '- 0 dsh-web', stderr: '', error: null };
    }
    if (cmd === 'systemctl' && args[0] === 'is-active') {
      return { ok: true, status: 0, stdout: (state === 'running' ? 'active' : 'inactive') + '\n', stderr: '', error: null };
    }
    if (cmd === 'systemctl' && args[0] === 'is-enabled') {
      return { ok: true, status: 0, stdout: 'enabled\n', stderr: '', error: null };
    }
    throw Object.assign(new Error('unexpected ' + cmd), { code: 'UNMOCKED_PSVC' });
  };
}
/** 服务「存在且在跑」的平台分发选择器：win 原样返回 scRunningAsync()；POSIX 走对应后端命令形态。 */
function runningServiceMock() {
  return process.platform === 'win32' ? scRunningAsync() : posixServiceMock('running');
}

/** POSIX 真实探测夹具：临时目录自建可执行文件 + PATH 前置（经 runProbe/runProbeAsync 的 env 参数注入），
 *  用于验证真实 spawn 通道的成功/非 0 退出映射，而**不依赖发行版装了哪些工具**（which/curl 的有无不作前提）。
 *  仅 POSIX 分支调用（shell 脚本 + ':' 分隔符语义），win32 分支保持原样。 */
function makeProbeStub(name, body) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-sys-probe-'));
  const file = path.join(dir, name);
  fs.writeFileSync(file, '#!/bin/sh\n' + body, { mode: 0o755 });
  fs.chmodSync(file, 0o755);
  return {
    env: Object.assign({}, process.env, { PATH: dir + path.delimiter + process.env.PATH }),
    cleanup() { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* 清理失败不掩盖断言结果 */ } },
  };
}

function teardownProbeMocks() {
  sys.__setProbeExecutor(null);
  psvc.__setProbeAsync(null);
  sys.__resetNetBreaker();
  delete process.env.DSH_PE_NET_BREAKER;
}

/** 3080 监听者探测桩（平台无关判据用）。
 *
 *  为什么需要它：`probePortHolder` 在**非 win32** 走 `dshPrimPortHolder` —— 一个真实子进程原语
 *  （`ss -ltnp` → `netstat -tlnp` 退路），**没有执行器 mock 缝**。于是 SYS-09/10 的 POSIX 分支只能
 *  把期望绑在「本机 3080 恰好空闲」上：插件自己的部署机（3080 上就住着 DSH）反而必红 ——
 *  这是**环境凑不齐型**假红（判据本身一个字没错），正是本批要拿掉的「必须某个环境才能判」。
 *
 *  做法：把 `ss`/`netstat` 换成 PATH **前置**的桩可执行文件，两种形态都能在任何机器上钉住：
 *    · body 为空        ⇒ 无监听者（→ service-stopped / no-listener 分支）
 *    · body 给一行 ss 输出 ⇒ 有监听者（→ pid-only / service 分支）
 *  这与本文件既有的 `makeProbeStub` 是同一手法；win32 走 mock（`netstat -ano`），本桩为空操作。
 *  @returns {() => void} 还原函数（务必 finally 调用） */
function withPortHolderStub(body) {
  if (process.platform === 'win32') return () => {};
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-holder-stub-'));
  for (const f of ['ss', 'netstat']) {
    const p = path.join(dir, f);
    fs.writeFileSync(p, '#!/bin/sh\n' + (body || ''), { mode: 0o755 });
    fs.chmodSync(p, 0o755);
  }
  const old = process.env.PATH;
  process.env.PATH = dir + path.delimiter + old;
  return () => {
    process.env.PATH = old;
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* 清理失败不掩盖断言结果 */ }
  };
}

// P3-2d（2026-10-14）：同步 `runProbe` 已随探针肢体收口退役（生产面零消费者）⇒ 判据对象**整体消失**。
//   ⚠ 非改浅：对象消失是唯一合法退役理由（`CHG-025`）。本批**不**保留「找不到就算过」的软断言；
//     改为**反向守卫**：该符号**必须不在**导出面。
//   ⚠ 同时结清 **D-19**：原 SYS-06 断言信息称「重启阶梯链 svcStateRaw 等依赖」——
//     与该函数失效注释同源；`svcStateRaw` / `degradeNssmService` / `index.cjs restartPort` 三名
//     经 P3-2c 实测**全仓只存于注释**。此处不再复述该不存在的消费方。
//   ⚠ 仍存活且**未受影响**：`runProbeAsync`（探针肢体保留）与其形态契约由 SYS-07 继续覆盖；
//     `validateProbe` / `PROBE_TIMEOUT_MS` 亦保留（前者为 `runProbeAsync` 的白名单单一事实源）。
test('SYS-06 runProbe 已退役（P3-2d · 判据对象整体消失 · 反向守卫）', () => {
  assert.equal(sys.runProbe, undefined, 'runProbe 必须已从 lib/sys.cjs 导出面退役（生产面零消费者）');
});

test('SYS-07 runProbeAsync：Promise 形状/白名单/非 0 退出映射对齐 spawnSync status 语义', async () => {
  const p = sys.runProbeAsync('not-allowed-cmd', [], undefined);
  assert.ok(p instanceof Promise);
  const r1 = await p;
  assert.deepEqual(r1, { ok: false, code: 'BAD_PROBE_CMD' });

  // 真实执行器：非 0 退出 → {ok:false,code:<exit>}（spawnSync status 等价）
  if (process.platform === 'win32') {
    // win：where 存在但名字查不到 → 退出码 1
    const r2 = await sys.runProbeAsync('where', ['dsh-definitely-not-exist-xyz-9x7'], undefined);
    assert.equal(r2.ok, false);
    assert.equal(r2.code, 1, '非 0 退出码必须映射为 number');
  } else {
    // POSIX：where 本身不可达 → ENOENT（string，非退出码）；「非 0 退出 → number」改由自建工具真实验证
    const rw = await sys.runProbeAsync('where', ['dsh-definitely-not-exist-xyz-9x7'], undefined);
    assert.equal(rw.ok, false);
    assert.equal(rw.code, 'ENOENT', 'POSIX 无 where：不可达语义（string code，与退出码区分）');
    const stub = makeProbeStub('where', 'exit 3\n');
    try {
      const r2 = await sys.runProbeAsync('where', [], stub.env);
      assert.equal(r2.ok, false);
      assert.equal(r2.code, 3, '非 0 退出码必须映射为 number');
      assert.equal(typeof r2.code, 'number', '退出码不得退化为字符串');
    } finally { stub.cleanup(); }
  }

  // ENOENT 映射（mock 注入，避免依赖白名单外命令）
  sys.__setProbeExecutor(makeExecMock({
    where: () => { throw Object.assign(new Error('spawn ENOENT'), { code: 'ENOENT' }); },
  }));
  try {
    const r3 = await sys.runProbeAsync('where', ['sc.exe'], undefined);
    assert.deepEqual({ ok: r3.ok, code: r3.code }, { ok: false, code: 'ENOENT' });
  } finally { teardownProbeMocks(); }
});

test('SYS-08 C-3 超时硬杀：挂起子进程被击杀 → ETIMEDOUT 且远短于命令自然时长', { timeout: 20000 }, async () => {
  // 【挂起来源已换：黑洞地址 → 环回停滞服务】旧写法连 http://10.255.255.1/（黑洞地址）指望 connect 挂起，
  // 实测**同一台机上就能翻脸**：直连该地址 3 次 = exit 28(5020ms) / exit 7(31ms) / exit 7(29ms)——
  // 首连挂起、随后被邻居/路由缓存的下一条不可达秒回 EHOSTUNREACH ⇒ curl 秒退 7，探针根本等不到超时，
  // 断言 code==='ETIMEDOUT' 随机变红（flaky；同文件连跑 3 次 = OK/FAIL/FAIL 即此因）。
  // 换成本机停滞服务：端口由内核分配、必然处于 LISTEN、连接必被 accept，服务端只读不写 ⇒ curl 阻塞等响应
  // 直到 -m 到点。不触网、不吃路由/代理/ICMP 的影响，挂起是**服务端行为**而非网络运气。
  // 腿①走真实 curl 二进制 + 真实 spawn/杀进程链路（POSIX）；腿②③用执行器注入缝钉住归一化契约，
  // 跨平台恒跑（形状取自本机实测：execFile 超时拒绝 = code:null / killed:true / signal:'SIGTERM'，
  // 不带 'ETIMEDOUT' 字样——归一化读的是 killed/signal，不是某个平台特有的 code）。
  const conns = [];
  const srv = net.createServer((conn) => { conns.push(conn); /* 持有连接、永不写响应：就是挂起 */ });
  await new Promise((res, rej) => { srv.once('error', rej); srv.listen(0, '127.0.0.1', res); });
  const url = 'http://127.0.0.1:' + srv.address().port + '/';
  // 探针环境剥掉代理变量 + --noproxy '*'：确保「连本机」不受宿主代理配置影响（本机代理命中与否不再是不确定项）
  const probeEnv = Object.assign({}, process.env);
  for (const k of ['http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'all_proxy']) delete probeEnv[k];
  probeEnv.no_proxy = '*'; probeEnv.NO_PROXY = '*';
  // 注：--noproxy 的值必须是白名单参数字符集（validateProbe 正则无 `*`）——写 '*' 会先被判 BAD_PROBE_ARG，
  // 探针根本不执行 curl。这里用本机回环字面量，语义等价（只需豁免回环一条）。
  const args = ['-s', '-m', '8', '--noproxy', '127.0.0.1', url]; // -m 8 = 自然时长 8s，远长于探针 700ms 硬超时
  try {
    if (process.platform !== 'win32') {
      // 腿①（真实链路·证伪腿）：真实 curl 连本机停滞服务 → 挂起 → 探针 700ms 硬超时应击杀它
      // 负控实证：抽掉 execOpts.timeout 后本腿在 ~8s 处红（elapsed<5000 断言），非永真。
      const t0 = Date.now();
      const r = await sys.runProbeAsync('curl', args, probeEnv, { timeoutMs: 700 });
      const elapsed = Date.now() - t0;
      assert.equal(r.ok, false);
      assert.equal(r.code, 'ETIMEDOUT', '超时必须归一化为 ETIMEDOUT');
      assert.ok(elapsed < 5000, '子进程必须在超时窗内被杀死（实际 ' + elapsed + 'ms；未击杀将 ≥8s）');
    }
    // 腿②（执行器契约）：真实超时拒绝形状 → 归一化 ETIMEDOUT，且硬超时确被透传给执行器
    let seen = null;
    sys.__setProbeExecutor(async (cmd, a, opts) => {
      seen = { cmd, a, opts };
      throw Object.assign(new Error('Command failed: timeout'), { code: null, killed: true, signal: 'SIGTERM', stdout: '', stderr: '' });
    });
    const r2 = await sys.runProbeAsync('curl', args, probeEnv, { timeoutMs: 700 });
    assert.deepEqual({ ok: r2.ok, code: r2.code }, { ok: false, code: 'ETIMEDOUT' }, 'code=null + killed/signal 的超时拒绝必须归一化为 ETIMEDOUT');
    assert.equal(seen.opts.timeout, 700, '探针硬超时必须透传到执行器（去掉超时处理本断言即红）');
    // 腿③（反向对照·防永真）：非超时失败不得被误判为 ETIMEDOUT——exit 7 正是本缺陷的现场症状
    sys.__setProbeExecutor(makeExecMock({ curl: CURL_EXIT7 }));
    const r3 = await sys.runProbeAsync('curl', args, probeEnv, { timeoutMs: 700 });
    assert.equal(r3.code, 7, 'curl 连不上（exit 7）必须原样透传为退出码，不得被当作 ETIMEDOUT');
  } finally {
    for (const c of conns) { try { c.destroy(); } catch { /* 连接已由对端销毁：无妨 */ } }
    await new Promise((res) => srv.close(res));
    teardownProbeMocks();
  }
});

test('SYS-09 probeEnv golden 契约：mock 全链下 items 序/key 集/字段与同步版逐字段一致', async () => {
  sys.__setProbeExecutor(winChainMock({ stdout: '200' }));
  psvc.__setProbeAsync(runningServiceMock());
  // POSIX 的 3080 监听者走不可 mock 的真实原语 ⇒ 用 PATH 前置桩把它钉成「本机 3080 空闲」，
  // 使本用例的前提**由用例自己保证**，不再依赖「插件恰好没跑在这台机上」（见 withPortHolderStub 注释）。
  const undoHolder = withPortHolderStub('');
  try {
    const items = await sys.probeEnv('dsh-web', {}, {});
    assert.deepEqual(items.map((i) => i.key), ['tools', 'net', 'port-mode', 'port-pid'], '数组序契约');

    const [tools, net, portMode, portPid] = items;
    // tools/net：无 level 字段（同步版形状）
    assert.deepEqual(Object.keys(tools).sort(), ['detail', 'key', 'ok', 'warn']);
    assert.deepEqual({ ok: tools.ok, warn: tools.warn, detail: tools.detail }, { ok: true, warn: false, detail: 'ok' });
    assert.deepEqual(Object.keys(net).sort(), ['detail', 'key', 'ok', 'warn']);
    assert.deepEqual({ ok: net.ok, warn: net.warn, detail: net.detail }, { ok: true, warn: false, detail: 'ok' });
    // port 两项：带 level:'warn'
    if (process.platform === 'win32') {
      assert.deepEqual(Object.keys(portMode).sort(), ['detail', 'key', 'level', 'ok']);
      assert.deepEqual({ ok: portMode.ok, level: portMode.level, detail: portMode.detail }, { ok: true, level: 'warn', detail: 'service' });
      assert.deepEqual({ ok: portPid.ok, level: portPid.level, detail: portPid.detail }, { ok: true, level: 'warn', detail: '4242' });
    } else {
      // POSIX：3080 监听者由同步原语真实探测（dshPrimPortHolder，无可注入的 mock 缝）——用例前提是
      // 本机 3080 空闲（CI runner 无 DSH 服务）→ 平台映射「服务存在但无监听」：port-mode=service-stopped、
      // port-pid=no-listener，且失败态合同按定义带 warn:true（win 侧有监听者故为 ok 形态，形状契约仍逐字段断言）。
      assert.deepEqual(Object.keys(portMode).sort(), ['detail', 'key', 'level', 'ok', 'warn']);
      assert.deepEqual({ ok: portMode.ok, warn: portMode.warn, level: portMode.level, detail: portMode.detail }, { ok: false, warn: true, level: 'warn', detail: 'service-stopped' });
      assert.deepEqual({ ok: portPid.ok, warn: portPid.warn, level: portPid.level, detail: portPid.detail }, { ok: false, warn: true, level: 'warn', detail: 'no-listener' });
    }
  } finally { undoHolder(); teardownProbeMocks(); }
});

test('SYS-10 probeEnv 无监听→service-stopped；工具不可达早退形状逐字一致；单项异常不拖垮整表', async () => {
  // POSIX 的 3080 探测不可 mock ⇒ 同 SYS-09，用 PATH 前置桩把「无监听」由用例自己钉住。
  const undoHolder = withPortHolderStub('');
  // 分支①：3080 无监听 + 服务存在（STOPPED）
  sys.__setProbeExecutor(winNoListenerMock({ stdout: '200' }));
  psvc.__setProbeAsync(process.platform === 'win32'
    ? async () => ({ ok: true, status: 0, stdout: 'STATE : 1 STOPPED', stderr: '', error: null })
    : posixServiceMock('stopped'));
  try {
    const items = await sys.probeEnv('dsh-web', {}, {});
    const pm = items.find((i) => i.key === 'port-mode');
    const pp = items.find((i) => i.key === 'port-pid');
    assert.deepEqual(pm, { key: 'port-mode', ok: false, warn: true, detail: 'service-stopped', level: 'warn' });
    assert.deepEqual(pp, { key: 'port-pid', ok: false, warn: true, detail: 'no-listener', level: 'warn' });
  } finally { undoHolder(); teardownProbeMocks(); }

  // 分支②：工具解析命令非 0 退出 → 早退四项 tool-unreachable（含 level 字段）
  sys.__setProbeExecutor(makeExecMock({
    [TOOL_PROBE_KEY]: () => { throw Object.assign(new Error('exit 1'), { code: 1 }); },
  }));
  psvc.__setProbeAsync(async () => { throw new Error('must not be called'); });
  try {
    const items = await sys.probeEnv('dsh-web', {}, {});
    assert.deepEqual(items.map((i) => i.key), ['tools', 'net', 'port-mode', 'port-pid']);
    for (const it of items) {
      assert.deepEqual(it, { key: it.key, ok: false, warn: true, level: 'warn', detail: 'tool-unreachable' }, '早退项形状逐字一致');
    }
  } finally { teardownProbeMocks(); }

  // 分支③：单项执行器抛异常 → 该项降级 warn，其余项照常
  sys.__setProbeExecutor(makeExecMock({
    [TOOL_PROBE_KEY]: () => { throw new Error('boom'); },
  }));
  try {
    const items = await sys.probeEnv('dsh-web', {}, {});
    assert.deepEqual(items.map((i) => i.key), ['tools', 'net', 'port-mode', 'port-pid'], '异常不拖垮整表');
  } finally { teardownProbeMocks(); }
});

test('SYS-11 net 熔断状态机：3 连败入冷却→窗内零实测回缓存+degraded 标注；成功清零；旋钮关闭', async () => {
  // 阶段①：3 次连败全部实测，第 4 次起进冷却窗
  const execFail = winChainMock(CURL_EXIT7);
  sys.__setProbeExecutor(execFail);
  psvc.__setProbeAsync(runningServiceMock());
  try {
    for (let i = 1; i <= 3; i++) {
      const items = await sys.probeEnv('dsh-web', {}, {});
      const net = items.find((x) => x.key === 'net');
      assert.equal(net.detail, 'unreachable', '第 ' + i + ' 次连败仍实测');
      assert.deepEqual(Object.keys(net).sort(), ['detail', 'key', 'ok', 'warn'], '失败态字段契约不变');
    }
    const curlCallsAfter3 = execFail.calls.filter((c) => c.startsWith('curl')).length;
    assert.equal(curlCallsAfter3, 3);

    // 第 4/5 次：冷却窗内不再实测（curl 计数冻结）、回缓存判定并标注 degraded
    const r4 = await sys.probeEnv('dsh-web', {}, {});
    const net4 = r4.find((x) => x.key === 'net');
    assert.deepEqual({ ok: net4.ok, warn: net4.warn, detail: net4.detail }, { ok: false, warn: true, detail: 'unreachable+cooldown' });
    assert.deepEqual(Object.keys(net4).sort(), ['detail', 'key', 'ok', 'warn'], '冷却项字段契约不变');
    await sys.probeEnv('dsh-web', {}, {});
    const curlCallsAfter5 = execFail.calls.filter((c) => c.startsWith('curl')).length;
    assert.equal(curlCallsAfter5, 3, '冷却窗内零实测');
  } finally { teardownProbeMocks(); }

  // 阶段②：成功清零（在未入冷却的连败中途成功）——清零后再次两连败仍全部实测（fail 计数从 0 重计）
  let succeedNext = false;
  const execMix = winChainMock(() => (succeedNext ? { stdout: '200' } : CURL_EXIT7));
  sys.__setProbeExecutor(execMix);
  psvc.__setProbeAsync(runningServiceMock());
  try {
    await sys.probeEnv('dsh-web', {}, {}); // fail=1（实测）
    succeedNext = true;
    const okNet = (await sys.probeEnv('dsh-web', {}, {})).find((x) => x.key === 'net'); // 实测成功 → 清零
    assert.deepEqual({ ok: okNet.ok, warn: okNet.warn, detail: okNet.detail }, { ok: true, warn: false, detail: 'ok' }, '成功即清零且回正常判定');
    const curlAtOk = execMix.calls.filter((c) => c.startsWith('curl')).length;
    assert.equal(curlAtOk, 2);
    succeedNext = false;
    // 清零后两次连败必须仍是实测（若未清零，这两次会是 fail=2、3——第二次就进冷却）
    for (let i = 0; i < 2; i++) {
      const items = await sys.probeEnv('dsh-web', {}, {});
      assert.equal(items.find((x) => x.key === 'net').detail, 'unreachable', '清零后重计连败仍实测');
    }
    assert.equal(execMix.calls.filter((c) => c.startsWith('curl')).length, 4, '每次均为实测');
  } finally { teardownProbeMocks(); }

  // 阶段③：旋钮 DSH_PE_NET_BREAKER=0 —— 连败 5 次全部实测、永不标注 cooldown
  process.env.DSH_PE_NET_BREAKER = '0';
  const execKnob = winChainMock(CURL_EXIT7);
  sys.__setProbeExecutor(execKnob);
  psvc.__setProbeAsync(runningServiceMock());
  try {
    for (let i = 0; i < 5; i++) {
      const items = await sys.probeEnv('dsh-web', {}, {});
      assert.equal(items.find((x) => x.key === 'net').detail, 'unreachable', '旋钮关闭时每次都实测');
    }
    assert.equal(execKnob.calls.filter((c) => c.startsWith('curl')).length, 5, '旋钮关闭时无熔断计数');
  } finally { teardownProbeMocks(); }
}, { timeout: 30000 });

test('SYS-12 形状防御断言（C-2 兜底）：probeEnv 返回 Promise、runProbeAsync Promise 化 + runProbe 反向守卫', async () => {
  sys.__setProbeExecutor(makeExecMock({
    'where sc.exe': WHERE_OK,
    'netstat -ano': { stdout: NETSTAT_NONE },
    'tasklist /FO CSV /NH': { stdout: '' },
    curl: { stdout: '000' },
  }));
  psvc.__setProbeAsync(async () => ({ ok: true, status: 0, stdout: 'STATE : 1 STOPPED', stderr: '', error: null }));
  try {
    const p = sys.probeEnv('dsh-web', {}, {});
    assert.ok(p instanceof Promise, '漏网消费方拿到的是 Promise 而非数组——防御断言兜底');
    const items = await p;
    assert.ok(Array.isArray(items));

    // P3-2d（2026-10-14）：同步 `runProbe` 已退役 ⇒ 其形态断言随之消失（对象不存在）。
    //   ⚠ 反向守卫（不得复活）；`runProbeAsync` 仍存活 ⇒ 其 Promise 形态断言**保留**（门槛不降）。
    assert.equal(sys.runProbe, undefined, 'runProbe 已退役（P3-2d），不得复活');
    const asyncR = sys.runProbeAsync('nope', [], undefined);
    assert.ok(asyncR instanceof Promise, 'runProbeAsync 必须 Promise 化（该肢体本批保留）');
    await asyncR;

    // B1 扩展原语发射闭合：解析原语随 PORT_PRIMS 全量发射（生成脚本自包含纪律）
    const prims = sys.scriptPortPrims();
    assert.ok(prims.includes('var dshPrimParsePortHolder ='), '解析原语必须进入发射块');
    assert.equal(typeof sys.portHolderPid, 'function');
  } finally { teardownProbeMocks(); }
});

test('SYS-13 detectService 孪生 parity：同 mock 下 sync 与 async 结果逐字段一致', async () => {
  if (process.platform !== 'win32') {
    // 孪生分发按平台路由；跨平台孪生共享 parse* 纯函数（另有平台测试覆盖），此处仅验分发存在
    assert.equal(typeof psvc.detectServiceAsync, 'function');
    assert.ok(psvc.detectServiceAsync('svc-x', {}) instanceof Promise);
    return;
  }
  // 场景①：RUNNING + AUTO_START → exists/enabled/detail 一致
  let step = 0;
  const outsRunning = [
    { ok: true, status: 0, stdout: 'STATE : 4 RUNNING', stderr: '', error: null },
    { ok: true, status: 0, stdout: 'START_TYPE : 2 AUTO_START', stderr: '', error: null },
  ];
  psvc.__setProbe(() => outsRunning[Math.min(step++, outsRunning.length - 1)]);
  const syncRunning = psvc.win.detectService('svc-x', {});
  step = 0;
  psvc.__setProbeAsync(async () => outsRunning[Math.min(step++, outsRunning.length - 1)]);
  const asyncRunning = await psvc.detectServiceAsync('svc-x', {});
  assert.deepEqual(syncRunning, asyncRunning);
  assert.deepEqual(syncRunning, { exists: true, enabled: true, detail: 'ok', tool: 'sc/reg/nssm' });

  // 场景②：服务缺失 → missing 形状一致
  step = 0;
  const outsMissing = [{ ok: false, status: 1060, stdout: 'OPENSC FAILED 1060', stderr: '', error: null }];
  psvc.__setProbe(() => outsMissing[Math.min(step++, outsMissing.length - 1)]);
  const syncMissing = psvc.win.detectService('svc-x', {});
  step = 0;
  psvc.__setProbeAsync(async () => outsMissing[Math.min(step++, outsMissing.length - 1)]);
  const asyncMissing = await psvc.detectServiceAsync('svc-x', {});
  assert.deepEqual(syncMissing, asyncMissing);
  assert.deepEqual(syncMissing, { exists: false, enabled: false, detail: 'missing', tool: 'sc/reg/nssm' });

  psvc.__setProbe(null);
  psvc.__setProbeAsync(null);
});
