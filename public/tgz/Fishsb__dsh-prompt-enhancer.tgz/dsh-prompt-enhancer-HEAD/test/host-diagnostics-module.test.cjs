'use strict';

// 目标模式：诊断日志普通模块的语义锁 + 产物接线锁。
// 契约与旧 chunk 一致：ISO 前缀、console 分路、300 行环形上限、序列化容错。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { REPO_ROOT } = require('../scripts/lib/chunk-decode.mjs');
const { createDiagnostics, LOG_RING_MAX } = require('../src/host/diagnostics-module.cjs');

const MODULE_REL = 'src/host/diagnostics-module.cjs';
const ISO_PREFIX = /^\[20\d{2}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z\] /;

function fakeConsole() {
  const captured = [];
  return {
    captured,
    api: {
      log: (...a) => captured.push(['log', a.join(' ')]),
      error: (...a) => captured.push(['error', a.join(' ')]),
    },
  };
}

test('HDM-01 旧 chunk 已退役，普通模块在位（不得双份）', () => {
  assert.equal(fs.existsSync(path.join(REPO_ROOT, 'src/host/diagnostics.js')), false,
    '旧 diagnostics.js 不得复活（R4 等值集亦会判红）');
  assert.equal(fs.existsSync(path.join(REPO_ROOT, MODULE_REL)), true, '普通模块必须存在');
  assert.equal(typeof createDiagnostics, 'function');
  assert.equal(LOG_RING_MAX, 300);
});

test('HDM-02 ISO 时间戳 + console 分路 + 原文案保留', () => {
  const f = fakeConsole();
  const api = createDiagnostics(f.api);
  api.hlog('[enhance] update/envcheck ok svc=dsh-web', { items: 4 });
  api.herr('[enhance] update/envcheck failed', 42);

  assert.equal(f.captured.length, 2);
  assert.equal(f.captured[0][0], 'log', 'hlog 走 console.log');
  assert.equal(f.captured[1][0], 'error', 'herr 走 console.error');
  assert.match(f.captured[0][1], ISO_PREFIX, 'hlog 行必须带 ISO 前缀');
  assert.match(f.captured[1][1], ISO_PREFIX, 'herr 行必须带 ISO 前缀');
  assert.ok(f.captured[0][1].endsWith('[enhance] update/envcheck ok svc=dsh-web {"items":4}'),
    '关键 token 与对象序列化必须保持原样：' + f.captured[0][1]);
  assert.ok(f.captured[1][1].endsWith('[enhance] update/envcheck failed 42'),
    '数字参数必须保持原样：' + f.captured[1][1]);
  assert.deepEqual(api.LOG_RING.slice(), [f.captured[0][1], f.captured[1][1]],
    'LOG_RING 必须与输出行逐字一致（logs/last 消费方可见）');
});

test('HDM-03 环形上限 300 行：第 301 行挤掉最旧一行', () => {
  const f = fakeConsole();
  const api = createDiagnostics(f.api);
  for (let i = 0; i < LOG_RING_MAX + 5; i++) api.hlog('line-' + i);
  assert.equal(api.LOG_RING.length, LOG_RING_MAX, '环形缓冲不得超过 300 行');
  assert.ok(api.LOG_RING[0].endsWith('line-5'), '最旧 5 行必须被挤出：' + api.LOG_RING[0]);
  assert.ok(api.LOG_RING[api.LOG_RING.length - 1].endsWith('line-' + (LOG_RING_MAX + 4)), '最新一行必须在尾部');
  assert.equal(f.captured.length, LOG_RING_MAX + 5, 'console 输出不受环形缓冲影响（每行都写）');
});

test('HDM-04 序列化容错：循环对象回退 String，不抛错、不丢日志', () => {
  const f = fakeConsole();
  const api = createDiagnostics(f.api);
  const circular = {};
  circular.self = circular;
  assert.doesNotThrow(() => api.hlog('circular', circular));
  assert.equal(f.captured.length, 1);
  assert.match(f.captured[0][1], ISO_PREFIX, '仍须写出带 ISO 时间戳的一行');
  assert.ok(f.captured[0][1].includes('circular'), '字符串参数必须保留');
  assert.equal(api.LOG_RING.length, 1, '容错路径仍须收录日志');
});

test('HDM-05 产物内联诊断模块（无外部 require），logs/last 契约不变', () => {
  const host = fs.readFileSync(path.join(REPO_ROOT, 'plugin-host.js'), 'utf8');
  assert.ok(host.includes('"src/host/diagnostics-module.cjs"'), 'host 产物必须内联诊断模块 id');
  assert.ok(host.includes('"src/host/diagnostics-module.cjs"'), 'host 产物必须内联诊断模块 id');
  assert.ok(host.includes('createDiagnostics(r.console || console)'), '构建期必须把宿主 console 注入模块');
  assert.ok(host.includes("harness.handle('logs/last', logsLast)"), 'logs/last RPC 必须仍在位');
  assert.ok(host.includes('lines: ring.slice()'), 'logs/last 必须仍返回环形缓冲副本');
  assert.equal((host.match(/require\(/g) || []).length, 0, 'host 产物不得含外部 require');
});

test('HDM-06 logsLast 返回环形缓冲副本，不暴露可改内部数组', async () => {
  const f = fakeConsole();
  const api = createDiagnostics(f.api);
  api.hlog('one');
  const out = await api.logsLast();
  assert.equal(out.ok, true);
  assert.deepEqual(out.lines, api.LOG_RING.slice());
  out.lines.push('mutated');
  assert.equal(api.LOG_RING.length, 1, '返回副本不得修改内部环形缓冲');
});
