'use strict';

// 目标模式：增强 analyze 阶段的语义锁（配置/模板/记忆/场景/超时）。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { REPO_ROOT } = require('../scripts/lib/chunk-decode.mjs');
const { createAnalyzeStage } = require('../src/host/enhance-analyze.cjs');

function makeStage(overrides) {
  const logs = [];
  const calls = { templates: [], memory: [], deltas: [] };
  const cache = new Map();
  const deps = {
    validateConfig: (cfg) => Object.assign({ mode: 'base', memory: false, context: { budgetChars: 2000 }, fallback: [], maxTokens: 2000, outputLimit: 8000, timeoutMs: 30000 }, cfg || {}),
    buildTryChain: (fallback) => (Array.isArray(fallback) ? fallback : []),
    resolveTemplateSystem: (cfg, mode, templates) => { calls.templates.push([cfg, mode, templates]); return 'SYSTEM-' + mode; },
    shouldInjectMemory: () => false,
    computeEditDelta: () => ({ added: [], removed: [] }),
    filterDeltaForPublish: (d) => d,
    detectScenario: () => 'generic',
    resolveEnhanceTimeoutMs: () => 30000,
    setProgress: () => {},
    hlog: (...args) => logs.push(args.join(' ')),
    skillManifest: { base: { templates: { t1: 'T1', t2: 'T2' } } },
    modeKeys: ['base', 'lite', 'publish'],
    memoryRoundsMax: 4,
    stageAnalyze: 'analyze',
    disciplinePrompt: 'DISC',
    publishScenarioCache: cache,
  };
  return { stage: createAnalyzeStage(Object.assign(deps, overrides || {})).enhanceStageAnalyze, logs, calls, cache };
}

test('HEA-01 配置与 mode 覆盖 + 模板/纪律组装 + state 字段', async () => {
  const { stage, calls } = makeStage();
  const state = { args: { mode: 'lite', config: { mode: 'base', fallback: [{ provider: 'p', model: 'm' }] } }, sessionId: 's', text: '原文', rec: {} };
  const out = await stage(state);
  assert.equal(out.cfg.mode, 'lite', '请求 mode 覆盖配置 mode');
  assert.deepEqual(out.chain, [{ provider: 'p', model: 'm' }]);
  assert.equal(out.system, 'SYSTEM-lite\n\nDISC');
  assert.equal(out.isPublish, false);
  assert.equal(out.scenario, 'generic');
  assert.equal(out.timeoutMs, 30000);
  assert.equal(out.maxTokens, 2000);
  assert.equal(out.outputLimit, 8000);
  assert.deepEqual(calls.templates[0][2], { base: ['T1', 'T2'] });
});

test('HEA-02 记忆轮次过滤/截断与 hasMemory/memoryActive 语义', async () => {
  const { stage, calls } = makeStage({
    shouldInjectMemory: (on, has, budget) => { calls.memory.push([on, has, budget]); return has; },
  });
  const state = {
    args: { config: { mode: 'lite', memory: true, context: { budgetChars: 1200 } }, memory: { rounds: [
      { input: '', output: '' }, { input: 'a', output: 'b' }, { input: 'c', output: 'd' },
    ] } },
    sessionId: 's', text: 'x', rec: {},
  };
  const out = await stage(state);
  assert.equal(out.memRounds.length, 2, '空轮次被过滤');
  assert.equal(out.hasMemory, true);
  assert.equal(out.memoryActive, true);
  assert.deepEqual(calls.memory[0], [true, true, 1200]);
});

test('HEA-03 publish 场景缓存：首轮判定写入，后续轮读取且不重判', async () => {
  let judged = 0;
  const { stage, cache } = makeStage({ detectScenario: () => { judged += 1; return 'game'; } });
  const s1 = { args: { config: { mode: 'publish' } }, sessionId: 'sess', text: '体素游戏', rec: {} };
  const o1 = await stage(s1);
  assert.equal(o1.scenario, 'game');
  assert.equal(cache.get('sess'), 'game');
  assert.ok(o1.system.includes('【场景判定】本次场景判定：game'));
  const s2 = { args: { config: { mode: 'publish' } }, sessionId: 'sess', text: '别的文本', rec: {} };
  const o2 = await stage(s2);
  assert.equal(o2.scenario, 'game');
  assert.equal(judged, 1, '同会话第二次不得重判');
});

test('HEA-04 产物内联 analyze 模块，阶段名仍注册为 analyze', () => {
  const host = fs.readFileSync(path.join(REPO_ROOT, 'plugin-host.js'), 'utf8');
  assert.ok(host.includes('"src/host/enhance-analyze.cjs"'));
  assert.ok(host.includes('"src/host/enhance-analyze.cjs"'));
  assert.ok(host.includes("registerEnhanceStage('analyze', enhanceStageAnalyze"));
  assert.equal((host.match(/require\(/g) || []).length, 0);
});
