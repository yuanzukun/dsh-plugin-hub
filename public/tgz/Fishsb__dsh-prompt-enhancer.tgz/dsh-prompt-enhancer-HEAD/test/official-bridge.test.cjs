'use strict';
// official-bridge.test —— 官方录音路径增值桥（CHG-011 / 方案 §4.6.2.6 / UD-0014 选 B）
//
// 验证要求（UD-0010 / UD-0011）：**自动化不得以「需要真麦克风」为前置** ——
// 全部用**注入假件**（假 navigator.mediaDevices.getUserMedia / 假 MediaStream /
// 假 MediaRecorder / 假 AudioContext+AnalyserNode）驱动到「静音达标」，断言官方 stop 被触发。
// 真麦只作人工项登记（见报告）。
//
// 判据强度：数字锁用严格 ===；无 skip；不存在恒真断言。
// 覆盖：正例(A1 停官方) · 负控(未命中不改行为/同一性) · 幂等(层数) · 卸载恢复(===原函数) ·
//       互斥(两方向) · 不静默失效(状态可被观察到) · A2 兜底 · 显式降级 · 让位官方钩子 ·
//       变异自证(正例必红 + 负控必绿)。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const CHUNK = 'src/client/voice/official-bridge.js';

const decodeChunk = (rel) => {
  const raw = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  // 行首锚定（chunk 头部注释里可能含代码样文本，裸 module.exports 正则会被误导）
  const m = raw.match(/(?:^|\n)module\.exports = "([\s\S]*)";?\s*$/);
  if (!m) throw new Error('chunk wrapper mismatch: ' + rel);
  return JSON.parse('"' + m[1] + '"');
};

// §7.4 起：official-bridge 依赖 state.js 的单一事实源（vadSilenceMsOf / vadRequiredQuiet / voiceCfgState）。
// 测试注入**真实的 state.js**（而非桩），以保证「两条入口共用同一值」在测试里也是同一份实现。
function loadStateForBridge(env) {
  const src = decodeChunk('src/client/voice/state.js');
  const factory = new Function(
    'localStorage', 'host',
    src + '\n;return { vadSilenceMsOf, vadRequiredQuiet, voiceCfgState };'
  );
  return factory(env.localStorage, { call: () => Promise.resolve({ ok: false }) });
}

// ── 假浏览器环境 ────────────────────────────────────────────────────────────
// 用假件把「静音达标」推到底：先给高 RMS（有语音），再给低 RMS（静音）达 2s/100ms = 20 帧。
function makeFakeEnv(opts) {
  const o = opts || {};
  const timers = [];
  const frames = [];              // 每次 tick 返回的 RMS（归一化）
  // 默认脚本：5 帧校准（低）+ 1 帧语音（高）+ 20 帧静音 ⇒ 达标自动停
  for (let i = 0; i < 5; i++) frames.push(0.001);
  frames.push(0.5);
  for (let i = 0; i < 20; i++) frames.push(0.001);

  const recorderInstances = [];
  class FakeMediaRecorder {
    // 构造即 idle，start() 才进入 recording —— 模拟真实 MediaRecorder 行为
    // （包装器只在 state==='recording' 时捕获实例 ⇒ 必须 start 后捕获）
    constructor(stream) { this.stream = stream; this.state = 'inactive'; this.mimeType = 'audio/webm'; this.onstop = null; recorderInstances.push(this); }
    start() { this.state = 'recording'; mediaDevices.lastRecorder = this; }
    stop() { this.state = 'inactive'; this.stopCalls = (this.stopCalls || 0) + 1; if (typeof this.onstop === 'function') this.onstop(); }
    static isTypeSupported() { return true; }
  }

  // 官方停止按钮（P2-补做：停止**第一优先**路径 —— 唯一走完官方 finish() 的入口）
  const stopButton = {
    disabled: o.stopDisabled === true, clicks: 0,
    getAttribute: (n) => (n === 'aria-label' ? '停止并识别' : null),
    dispatchEvent() { this.clicks++; return true; },
    click() { this.clicks++; },
  };
  // 官方开始按钮（P2-补做：热键 → 派发点击它 = 「远程按一下官方按钮」；只在 idle 时存在）
  const startButton = {
    disabled: o.startDisabled === true, clicks: 0,
    getAttribute: (n) => (n === 'aria-label' ? '开始录音' : null),
    dispatchEvent() { this.clicks++; return true; },
    click() { this.clicks++; },
  };
  // 官方失败出口（相位 feedback + 文案节点，官方自带、插件只读）
  // ⚠ B-1（2026-10-14 定位批 · CDP 实读官方 DOM）：官方该节点是 **CSS-module 哈希类**
  //   （实测 `ddpbLW_activityMessage`）⇒ 裸 `.activityMessage` 选择器在真实 DOM 里**永不命中**。
  //   本假件**照实模拟**该点（realClassName 默认 true）：裸类名选择器返回 null，子串选择器才命中。
  const feedbackNode = {};
  const messageNode = { textContent: o.feedbackText || '未识别到语音', className: 'ddpbLW_activityMessage' };
  const activityRegion = { };
  const activityNodes = o.recordingPhase ? [{}, ] : [];

  class FakeAnalyser {
    constructor() { this.fftSize = 1024; }
    getByteTimeDomainData(buf) {
      const rms = o.frameRms ? o.frameRms(frames) : frames.shift();
      const v = (rms === undefined ? 0.001 : rms);
      // 反解：v = |d|，取正半轴 ⇒ (buf[i]-128)/128 = v
      const byte = Math.max(0, Math.min(255, Math.round(128 + v * 128)));
      for (let i = 0; i < buf.length; i++) buf[i] = byte;
    }
  }
  let closed = false;
  // SW-1（2026-10-15 接线批）：计数 AudioContext 构造 —— 「VAD 是否被启动」的**直接**判据
  //   （开关关闭 ⇒ 不得建 AC ⇒ 不观测）。原 `closed` 变量与既有断言语义不变，仅新增计数。
  let acCreated = 0;
  class FakeAudioContext {
    constructor() { acCreated++; this.state = 'running'; }
    createMediaStreamSource() { return { connect() {} }; }
    createAnalyser() { return new FakeAnalyser(); }
    close() { closed = true; this.state = 'closed'; return Promise.resolve(); }
  }

  const mediaDevices = {};
  const originalGum = function (constraints) {
    mediaDevices.lastConstraints = constraints;
    mediaDevices.callCount = (mediaDevices.callCount || 0) + 1;
    const stream = {
      id: 'stream-' + mediaDevices.callCount,
      getTracks: () => [{ stop() {} }],
    };
    mediaDevices.lastStream = stream;
    return Promise.resolve(stream);
  };
  mediaDevices.getUserMedia = originalGum;

  const windowStub = {
    AudioContext: FakeAudioContext,
    MediaRecorder: o.noRecorder ? undefined : FakeMediaRecorder,
    __dshPeDisableOfficialBridge: o.disabled === true,
    __dshSpeechVoiceActivityHook: o.officialHook || undefined,
    // F-18 回归锁：记录监听器，使测试能驱动**真实**的 keydown/keyup 处理器（而非另写一套假处理器）
    _ls: {},
    addEventListener(type, fn) { (this._ls[type] = this._ls[type] || []).push(fn); },
    removeEventListener(type, fn) { if (this._ls[type]) this._ls[type] = this._ls[type].filter((f) => f !== fn); },
    _fire(type, ev) { for (const fn of (this._ls[type] || [])) fn(ev); },
  };
  const documentStub = {
    // 初始必须为 null（真实 DOM 在录音开始前**根本没有**该属性）——需要相位的用例自行置位并驱动 observer
    // （若初始就置位，install 的首次 sync 会误判为「已有会话」⇒ missed 误报，实测被 OVB-M02/D02 抓到）
    _attr: null,
    body: {},
    querySelector(sel) {
      if (sel === '[data-voice-activity]') return documentStub._attr ? activityNodes[0] : null;
      if (sel === '[data-voice-activity="recording"]') return documentStub._attr === 'recording' ? activityNodes[0] : null;
      if (sel === '[data-voice-activity="feedback"]') return documentStub._attr === 'feedback' ? feedbackNode : null;
      // ⚠ 真实 DOM 里该类名被 CSS-module 哈希化（CDP 实测 `ddpbLW_activityMessage`）。
      //   o.realClassName !== false ⇒ 裸类名**不命中**（正是本批定位到的缺陷形态）；
      //   子串选择器（[class*="activityMessage"]）仍命中。
      if (sel === '[data-voice-activity="feedback"] .activityMessage') {
        if (o.realClassName === false) return documentStub._attr === 'feedback' ? messageNode : null;
        return null;
      }
      if (sel === '[data-voice-activity="feedback"] [class*="activityMessage"]') {
        return documentStub._attr === 'feedback' ? messageNode : null;
      }
      return null;
    },
    querySelectorAll(sel) {
      if (sel !== 'button') return [];
      const btns = [];
      // 官方结构：idle 时只有开始按钮（相位节点未挂载）；recording 时只有停止按钮。
      // ⚠ 开始按钮的标签在**非 idle** 时会被官方换成 setupPrompt.trigger ⇒ 此处据相位模拟该行为。
      if (!documentStub._attr) {
        if (!o.noStartButton) btns.push(startButton);
      } else if (!o.noStopButton) {
        btns.push(stopButton);
      }
      return btns;
    },
  };
  const localStorageStub = {
    _m: new Map(),
    getItem(k) { return this._m.has(k) ? this._m.get(k) : null; },
    setItem(k, v) { this._m.set(k, String(v)); },
    removeItem(k) { this._m.delete(k); },
  };
  // 记录若干次 timer 注册（驱动静音所需），并给出手动驱动句柄
  const timerSvc = {
    interval(fn, ms) { const rec = { fn, ms, cleared: false }; timers.push(rec); return () => { rec.cleared = true; }; },
  };
  const observerInstances = [];
  class FakeMutationObserver {
    constructor(cb) { this.cb = cb; observerInstances.push(this); }
    observe() {}
    disconnect() {}
  }

  const sandboxWindow = windowStub;
  return {
    window: sandboxWindow, document: documentStub, localStorage: localStorageStub,
    navigator: { mediaDevices }, timers, timerSvc, observerInstances,
    mediaDevices, originalGum, recorderInstances, stopButton, startButton, feedbackNode, frames,
    driveTicks: (n) => { let i = 0; for (const r of timers) { /* noop */ } return i; },
    // SW-1（2026-10-15）：AudioContext 构造计数 —— 「VAD 是否被启动」的直接读数
    acCreated: () => acCreated,
  };
}

// 求值 chunk：注入假全局，返回桥对象 + 观察句柄
function loadBridge(env, cfg) {
  const src = decodeChunk(CHUNK);
  const S = loadStateForBridge(env);
  // SW-1（2026-10-15 接线批）：允许用例注入指定配置（默认不注入 ⇒ 走真实 state.js 的默认值，
  //   既有用例行为逐字不变）。注入的是**真实** voiceCfgState 对象，故桥读到的是真实配置形态。
  if (cfg !== undefined) S.voiceCfgState.value = cfg;
  const factory = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    src + '\n;return officialVoiceBridge;'
  );
  let seq = 0;
  const bridge = factory(
    env.window, env.document, env.navigator, env.localStorage,
    (fn, ms) => { const rec = { fn, ms, cleared: false, id: ++seq }; env.timers.push(rec); return rec.id; },
    (id) => { const rec = env.timers.find((r) => r.id === id); if (rec) rec.cleared = true; },
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent(type, init) { return { type, init }; },
    S.vadSilenceMsOf, S.vadRequiredQuiet, S.voiceCfgState
  );
  bridge.setTimer(env.timerSvc);
  return bridge;
}

// 把假件的时间轴推到底：反复调用注册的 interval 回调直到不再新增或达上限
function runVad(env, maxTicks) {
  const cap = maxTicks || 200;
  let ticks = 0;
  for (const rec of env.timers) {
    if (rec.cleared) continue;
    while (!rec.cleared && ticks < cap) { rec.fn(); ticks++; }
  }
  return ticks;
}

const flush = () => new Promise((r) => setImmediate(r));

// ───────────────────────────── 正例：停止走官方停止按钮 ─────────────────────────────
// P2-补做（2026-10-13 · UD-0016）：热键改走官方路径后，**停止的第一优先 = 派发点击官方停止按钮**
// （唯一走完官方 `finish()`：相位收尾 → capture.stop() → 转写 → 写回）；MediaRecorder 实例仅兜底。
test('OVB-P01 正例：假件驱动到静音达标 ⇒ 派发点击官方停止按钮（走完官方链）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  assert.equal(bridge.install(), true, '安装应成功');
  // 官方采集：走标准接口（经包装器）
  const stream = await env.navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true }, video: false });
  assert.ok(stream, '官方拿到 stream');
  // 官方 start() 会 new MediaRecorder(stream) 然后 .start()
  const rec = new env.window.MediaRecorder(stream);
  rec.start();
  assert.equal(env.mediaDevices.lastRecorder, rec, '兜底包装须捕获到正在录音的官方实例');
  env.document._attr = 'recording';                  // 官方相位进入 recording（停止按钮此时才挂载）
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  const ticks = runVad(env);
  assert.ok(ticks >= 20, 'VAD 至少跑到静音帧数（实际 tick ' + ticks + '）');
  assert.equal(env.stopButton.clicks, 1, '静音达标 ⇒ 官方停止按钮必须被派发点击恰好 1 次（第一优先路径）');
  assert.equal(rec.stopCalls || 0, 0, '走官方停止按钮时不得再直接 stop 实例（不得双停）');
});

test('OVB-P02 兜底：无官方停止按钮时用 MediaRecorder 实例停（且明确记为兜底）', async () => {
  const env = makeFakeEnv({ recordingPhase: true, noStopButton: true });
  const bridge = loadBridge(env);
  bridge.install();
  const stream = await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  const rec = new env.window.MediaRecorder(stream);
  rec.start();
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  runVad(env);
  assert.equal(env.stopButton.clicks, 0, '无停止按钮 ⇒ 无点击');
  assert.equal(rec.stopCalls, 1, '兜底路径须停掉 MediaRecorder 实例恰好 1 次');
});

test('OVB-P03 显式降级：采集进行中且 A1/A2 都不可用 ⇒ stopped=false + 记录降级原因（不假装已停）', async () => {
  const env = makeFakeEnv({ recordingPhase: true, noStopButton: true });
  const bridge = loadBridge(env);
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  // ⚠ N-1 语义（本批）：只有「**采集确在进行中**」才允许计降级 ⇒ 必须先把官方相位置为 recording
  //   （否则属「会话已收尾/未开」分支，按新语义**不得**写 abandonReason）。
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  const r = bridge.stopOfficial();
  assert.equal(r.stopped, false, '不得假装已停');
  assert.equal(r.via, 'abandoned', '须走显式降级路径');
  assert.ok(bridge.snapshot().abandonReason, '必须记录降级原因');
  assert.equal(bridge.snapshot().stopMissed, 1, '采集进行中且两路不可用 ⇒ 恰好计 1 次 missed');
});

// ───────────────────────────── 负控 ─────────────────────────────
test('OVB-N01 负控：包装未命中（非音频约束）不得有任何行为改变', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  bridge.install();
  const before = env.timers.length;
  const s = await env.navigator.mediaDevices.getUserMedia({ video: true });
  assert.equal(s.id, 'stream-1', '返回值原样');
  assert.equal(env.timers.length, before, '视频采集不得挂 VAD');
  assert.equal(bridge.snapshot().firstCallAt, 0, '未命中 ⇒ 首次调用时间仍为 0');
});

test('OVB-N02 负控：参数与返回值原样（同一性 === 同一对象）', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  bridge.install();
  const constraints = { audio: { noiseSuppression: true }, video: false };
  const p = env.navigator.mediaDevices.getUserMedia(constraints);
  // 参数同一性（同一对象引用被原样透传，未被克隆/改写）
  assert.equal(env.mediaDevices.lastConstraints, constraints, '约束对象必须原样透传（=== 同一对象）');
  const stream = await p;
  assert.equal(stream, env.mediaDevices.lastStream, '返回的 stream 必须是原函数返回的同一对象（===）');
  assert.equal(stream.id, 'stream-1', '未被替换');
});

test('OVB-N03 负控：原函数抛错 ⇒ 异常原样透传（不得改写异常）', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  bridge.install();
  const boom = new Error('permission-denied-by-fake');
  // 在安装之后替换原函数（包装器闭包持有对象引用 ⇒ 原样透传本函数）
  env.mediaDevices.getUserMedia = () => Promise.reject(boom);
  await assert.rejects(
    () => env.navigator.mediaDevices.getUserMedia({ audio: true, video: false }),
    (e) => e === boom && e.message === 'permission-denied-by-fake',
    '异常必须是原对象（===）'
  );
});

// ───────────────────────────── 幂等 ─────────────────────────────
test('OVB-I01 幂等：两次安装 = 只包一次（断言包装层数）', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  assert.equal(bridge.install(), true, '首次安装 true');
  const wrapped = env.navigator.mediaDevices.getUserMedia;
  assert.equal(wrapped.__dshPeWrapped, true, '包装层须带标记');
  assert.equal(bridge.install(), false, '二次安装返回 false（不叠层）');
  assert.equal(env.navigator.mediaDevices.getUserMedia, wrapped, '二次安装不得替换包装层（层数仍为 1）');
  assert.equal(!!env.navigator.mediaDevices.getUserMedia.__dshPeWrapped, true, '仍是同一包装层');
});

test('OVB-I02 幂等：N 次安装后调用链深度仍为 1（不是 N 层叠加）', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  const first = () => { env.mediaDevices.callCount = 0; };
  for (let i = 0; i < 7; i++) bridge.install();
  assert.equal(env.navigator.mediaDevices.getUserMedia.__dshPeWrapped, true, '唯一包装层');
  const stream = await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.equal(env.mediaDevices.callCount, 1, '原函数恰被调用 1 次（无多层转发）');
  assert.ok(stream, 'stream 正常');
});

// ───────────────────────────── 卸载恢复（HMR 安全） ─────────────────────────────
test('OVB-U01 卸载恢复：卸载后 getUserMedia === 原函数', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  const orig = env.navigator.mediaDevices.getUserMedia;
  bridge.install();
  assert.notEqual(env.navigator.mediaDevices.getUserMedia, orig, '安装后应不同');
  assert.equal(bridge.uninstall(), true, '卸载应成功');
  assert.equal(env.navigator.mediaDevices.getUserMedia, orig, '卸载后必须 === 原函数');
});

test('OVB-U02 卸载恢复：MediaRecorder 亦恢复原构造函数', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  const origRec = env.window.MediaRecorder;
  bridge.install();
  assert.notEqual(env.window.MediaRecorder, origRec, '安装后 MediaRecorder 被包');
  bridge.uninstall();
  assert.equal(env.window.MediaRecorder, origRec, '卸载后 MediaRecorder === 原构造函数');
});

test('OVB-U03 重装可用：卸载 → 再安装仍能工作（HMR 反复挂载不失效）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install(); bridge.uninstall(); bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  const rec = new env.window.MediaRecorder(env.mediaDevices.lastStream);
  rec.start();
  runVad(env);
  assert.equal(rec.state, 'inactive', '重装后 A1 仍能停官方');
});

// ───────────────────────────── 互斥（两方向） ─────────────────────────────
test('OVB-M01 互斥方向一：热键自控采集中 ⇒ 包装器直接透传不介入', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  bridge.install();
  bridge.setSelfCapture(true);
  const before = env.timers.length;
  const stream = await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.equal(stream, env.mediaDevices.lastStream, '仍原样返回');
  assert.equal(env.timers.length, before, '自控采集中不得挂官方 VAD（不介入）');
  assert.equal(bridge.snapshot().firstCallAt, 0, '不得记为官方命中');
});

test('OVB-M02 互斥方向二：官方采集中 ⇒ 热键侧可查询到并会拒绝启动', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  // 先命中包装器（官方真实路径同样会经包装器），避免把「未命中」与「互斥」两件事混在一个测试里
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.equal(bridge.officialCapturing(), false, '未采集时为 false');
  // 官方相位标记挂载 ⇒ watchActivity 同步（经 MutationObserver 回调驱动）
  const mo = env.observerInstances[env.observerInstances.length - 1];
  assert.ok(mo, '须注册 MutationObserver 观察官方相位');
  env.document._attr = 'recording';
  mo.cb();
  assert.equal(bridge.officialCapturing(), true, '官方采集中 ⇒ 热键侧必须能查到（拒绝启动的依据）');
  // 官方会话结束
  env.document._attr = null;
  mo.cb();
  assert.equal(bridge.officialCapturing(), false, '结束后恢复可启动');
});

test('OVB-M03 互斥：自控标记释放后包装器恢复介入', async () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  bridge.install();
  bridge.setSelfCapture(true);
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.equal(bridge.snapshot().firstCallAt, 0, '自控期间不介入');
  bridge.setSelfCapture(false);
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.ok(bridge.snapshot().firstCallAt > 0, '释放后恢复介入');
});

// ───────────────── 热键 → 派发点击官方开始按钮（P2-补做 · UD-0016 形态变更落点） ─────────────────
test('OVB-S01 正例：startOfficial 派发点击官方开始按钮（事件对象可捕获）', () => {
  const env = makeFakeEnv({});
  const bridge = loadBridge(env);
  bridge.install();
  // idle 态：只有官方开始按钮在位（相位节点未挂载）
  assert.equal(env.stopButton.clicks, 0, '前置：尚无停止按钮点击');
  const r = bridge.startOfficial();
  assert.equal(r.started, true, '须报告已启动');
  assert.equal(r.via, 'official-start-button', '必须经「派发点击官方开始按钮」这条路径（唯一驱动官方整条链）');
  assert.equal(env.startButton.clicks, 1, '官方开始按钮必须被派发点击恰好 1 次');
  const snap = bridge.snapshot();
  assert.equal(snap.startClicks, 1, '派发点击计数须入诊断读数');
  assert.equal(snap.startMissed, 0, '成功启动不得计 missed');
});

test('OVB-S02 负控：官方开始按钮不存在 ⇒ 不得静默失败（诊断可见 + 零行为改变）', () => {
  const env = makeFakeEnv({ noStartButton: true });
  const bridge = loadBridge(env);
  bridge.install();
  const before = env.timers.length;
  const r = bridge.startOfficial();
  assert.equal(r.started, false, '无按钮 ⇒ 不得报告已启动');
  assert.equal(r.via, 'start-button-not-found', '须给出明确的未启动原因');
  const snap = bridge.snapshot();
  assert.equal(snap.startMissed, 1, '必须记为未启动（诊断区据此显示「未能派发点击官方开始按钮」）');
  assert.ok(snap.lastStartMissedAt > 0, '须记时间戳（可观察）');
  assert.ok(snap.abandonReason, '须留下降级原因（不得静默）');
  assert.equal(env.timers.length, before, '零行为改变（不得挂任何观察器/定时器）');
});

test('OVB-S03 负控：按钮 disabled ⇒ 不得派发点击（不得静默失败）', () => {
  const env = makeFakeEnv({ startDisabled: true });
  const bridge = loadBridge(env);
  bridge.install();
  const r = bridge.startOfficial();
  assert.equal(r.started, false, 'disabled 按钮不得被点击');
  assert.equal(env.startButton.clicks, 0, '不得派发点击到 disabled 按钮');
  assert.equal(bridge.snapshot().startMissed, 1, '须记为未启动');
});

test('OVB-S04 互斥：官方采集中再按热键 ⇒ 拒绝重复启动（不派发第二个开始）', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  assert.equal(bridge.officialCapturing(), true, '前置：官方采集中');
  const r = bridge.startOfficial();
  assert.equal(r.started, false, '官方采集中 ⇒ 热键必须拒绝启动');
  assert.equal(r.via, 'already-capturing', '须给出「已在采集中」这一原因');
  assert.equal(env.startButton.clicks, 0, '不得再派发点击开始按钮');
});

// ───────────────── 官方 feedback 相位 · 语义订正批（2026-10-14 定位批）─────────────────
// ⚠ 语义订正的依据（静态证明 + CDP 实读，非推测）：
//   官方 `dsh-experimental-client-ui-voice-input/lib/client.js:4990-5026` 实读 —— `feedback(text)`
//   **只在转写已经完成之后**被调用，四个调用点是 `tooLarge` / `transcribe` 返回 !ok / `text === ""`
//   （未识别到语音）/ **`insertText` 返回 false（草稿冲突）**。最后一种**转写是成功的**。
//   ⇒ `feedback` **不是**「识别失败」专用出口；把它一律当失败并直接 return 会**跳过会话收口**
//   （`settleMiss` 不计、`lastEndedAt` 永不更新）⇒ 自动增强永不触发（本批 E1 夹具实测）。
//   故本组判据改为：feedback **照记读数**（endedInFeedback 保留给"不空等写回"），
//   且**必须完成会话收口**（lastEndedAt 更新 + missed 结算 + active 语义）。
test('OVB-F01 反馈相位：照记读数，且**必须完成会话收口**（订正：feedback ≠ 仅失败出口）', () => {
  const env = makeFakeEnv({ recordingPhase: true, feedbackText: '未识别到语音' });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();       // 进入采集
  env.document._attr = 'feedback'; mo.cb();        // 官方 feedback 相位
  const snap = bridge.snapshot();
  assert.equal(snap.feedbackSeen, 1, '必须识别出官方自带的 feedback 相位（恰好 1 次）');
  assert.equal(snap.endedInFeedback, true, '读数须置位（订阅方据此不进入「空等写回」）');
  assert.equal(snap.feedbackMessage, '未识别到语音', '文案须进诊断读数（经**子串**选择器命中哈希类）');
  // ⚠ 本批订正的核心：收口**必须**发生（旧实现此处为 lastEndedAt===0，直接跳过收口）
  assert.ok(snap.lastEndedAt > 0, 'feedback 即一次会话收口 ⇒ 必须记结束时刻（否则自动增强永不触发）');
  assert.equal(bridge.officialCapturing(), true, '收藏态语义不变：官方仍占用语音入口（等用户关闭/重试）');
});

test('OVB-F01b 订正回归锁：feedback 的收口**恰好一次**（节点随后消失不得再计一次 missed）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  env.document._attr = 'feedback'; mo.cb();
  const afterFb = bridge.snapshot();
  assert.equal(afterFb.sessionsMissed, 0, '本会话包装器已被调用 ⇒ 收口不得计 missed');
  const endedAtFb = afterFb.lastEndedAt;
  env.document._attr = null; mo.cb();              // 用户点 X：节点消失
  const afterGone = bridge.snapshot();
  assert.equal(afterGone.sessionsMissed, 0, '⚠ 同一会话不得**二次**收口（否则 missed 被计两次）');
  assert.equal(afterGone.lastEndedAt, endedAtFb, '⚠ 不得覆盖首次收口时刻（否则订阅方重复装臂）');
  assert.equal(afterGone.endedInFeedback, false, '收口后标志必须复位');
});

test('OVB-F01c 订正回归锁：从 feedback 重试（相位回 recording）⇒ 不得残留「失败收场」读数', () => {
  const env = makeFakeEnv({ recordingPhase: true, feedbackText: '未识别到语音' });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  env.document._attr = 'feedback'; mo.cb();
  assert.equal(bridge.snapshot().endedInFeedback, true, '前置：已进 feedback');
  env.document._attr = 'recording'; mo.cb();       // 官方「重新录音」⇒ 相位回到 recording
  const snap = bridge.snapshot();
  assert.equal(snap.lastPhase, 'recording', '前置：相位确已回到 recording');
  assert.equal(snap.endedInFeedback, false,
    '⚠ 实测病：标志残留在真 ⇒ 诊断区报「上次官方会话以失败收场」而实际**正在录音**（读数说反话）');
});

test('OVB-F02 失败出口：未出现 feedback 时不得误报（负控）', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  assert.equal(bridge.snapshot().feedbackSeen, 0, '正常采集不得计失败出口');
  assert.equal(bridge.snapshot().endedInFeedback, false, '正常采集不得置失败收尾');
  env.document._attr = null; mo.cb();              // 成功路：节点消失
  const snap = bridge.snapshot();
  assert.equal(snap.endedInFeedback, false, '成功收尾不得带失败标记');
  assert.ok(snap.lastEndedAt > 0, '成功收尾须记结束时刻（自动增强据此等写回）');
});

// ───────────── N-1 回归锁：会话已收尾/未开 ⇒ 不得计 missed、不得写 abandonReason ─────────────
// 实测病（第 25 轮运行期）：一次**正常手动停**之后，相位停在 feedback（节点不消失）⇒ 静默 VAD 仍在跑；
// 它在**录音器已释放**时到阈值 ⇒ 旧实现照记 stopMissed + 写 abandonReason（第一优先分支）
// ⇒ 设置页此后**一直**显示「自动停已降级」，而自动停从未失败。
test('OVB-N04 N-1 回归锁：会话已收尾（相位非 recording）⇒ 不得计 missed、不得写降级原因', () => {
  const env = makeFakeEnv({ recordingPhase: true, noStopButton: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  // 会话走完：进入 recording 再收尾到 feedback（节点**不消失**——正是实测形态）
  env.document._attr = 'recording'; mo.cb();
  env.document._attr = 'feedback'; mo.cb();
  const before = bridge.snapshot();
  assert.equal(before.stopMissed, 0, '前置：尚未计 missed');
  // 静默 VAD 迟到触发（录音器已释放、停止按钮也不在）
  const r = bridge.stopOfficial();
  assert.equal(r.stopped, false, '不得假装已停');
  assert.equal(r.via, 'no-active-session', '会话已收尾 ⇒ 必须走「无进行中会话」分支');
  const after = bridge.snapshot();
  assert.equal(after.stopMissed, 0, 'N-1：会话已收尾 ⇒ **不得**计 stopMissed（诊断不得说反话）');
  assert.equal(after.abandonReason, '', 'N-1：会话已收尾 ⇒ **不得**写 abandonReason（否则诊断区常挂「已降级」）');
});

test('OVB-N05 N-1 回归锁：节点已卸载（idle）后迟到触发 ⇒ 同样不得计 missed/写原因', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  env.document._attr = null; mo.cb();              // 成功收尾：节点消失
  const r = bridge.stopOfficial();
  assert.equal(r.via, 'no-active-session', '无进行中会话 ⇒ 不得走降级分支');
  assert.equal(bridge.snapshot().stopMissed, 0, 'N-1：不得计 missed');
  assert.equal(bridge.snapshot().abandonReason, '', 'N-1：不得写 abandonReason');
});

test('OVB-N06 N-1 反向锁（不得修过头）：采集**进行中**且两路不可用 ⇒ 仍须计 missed + 写原因', () => {
  const env = makeFakeEnv({ recordingPhase: true, noStopButton: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();       // 采集确在进行中
  const r = bridge.stopOfficial();
  assert.equal(r.via, 'abandoned', '采集进行中且两路不可用 ⇒ 必须显式降级（不得被 N-1 修复顺手改没）');
  assert.equal(bridge.snapshot().stopMissed, 1, '仍须计 missed');
  assert.ok(bridge.snapshot().abandonReason, '仍须留下降级原因');
});

// ───────────────── 不静默失效 ─────────────────────────────
test('OVB-D01 不静默：官方会话但包装器从未被调用 ⇒ 该状态可被观察到', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  // 官方绕开包装器自行采集（模拟官方改走别处 / 其它插件影子采集）
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording';
  mo.cb();
  env.document._attr = null;      // 会话结束（missed 判定点在**收口**，见竞态修复注释）
  mo.cb();
  const snap = bridge.snapshot();
  assert.equal(snap.sessionsStarted, 1, '须记录观察到 1 次官方会话');
  assert.equal(snap.sessionsMissed, 1, '包装器整场从未被调用 ⇒ 必须计为 missed');
  assert.ok(snap.lastMissedAt > 0, '须记时间戳（设置页据此显示「未观测到官方采集」）');
  assert.notEqual(snap.sessionsMissed, 0, '不得静默（0 = 静默失效）');
});

// ⚠ 竞态回归（CDP 实测命中并修复）：官方相位属性出现早于 getUserMedia 包装的 .then() 落地
//   （实测排序 phase@+18ms → firstCallAt@+30ms）⇒ 若在**上升沿**快照 firstCallAt===0 就永久计 missed，
//   会把**真命中**误报为「未观测到官方采集」。本判据锁死「命中不得误报」。
test('OVB-D04 竞态回归：相位先到、包装后落地 ⇒ 真命中不得被误判为 missed', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording';   // ① 相位先出现（此刻包装尚未被调用）
  mo.cb();
  assert.equal(bridge.snapshot().firstCallAt, 0, '前置：此刻包装确实尚未落地');
  // ② 包装随后落地（官方 getUserMedia 调用返回）
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.ok(bridge.snapshot().firstCallAt > 0, '前置：包装已落地');
  // ③ 会话收口
  env.document._attr = null;
  mo.cb();
  const snap = bridge.snapshot();
  assert.equal(snap.sessionsStarted, 1, '仍记录 1 次会话');
  assert.equal(snap.sessionsMissed, 0, '真命中 ⇒ 必须 0（旧实现在此处误报 1 = 掩盖问题）');
});

test('OVB-D02 不静默：正常命中时 missed 保持 0（诊断不误报）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  // 先命中包装器（firstCallAt 置位），再让官方相位标记挂载 ⇒ 不得计为 missed
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.ok(bridge.snapshot().firstCallAt > 0, '包装器须已命中');
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording';
  mo.cb();
  const snap = bridge.snapshot();
  assert.equal(snap.sessionsStarted, 1, '仍记录会话数');
  assert.equal(snap.sessionsMissed, 0, '已命中 ⇒ 不得报 missed（诊断不误报）');
});

test('OVB-D03 不静默：订阅者能收到状态变更（设置页可刷新）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  let hits = 0;
  const off = bridge.subscribe(() => { hits++; });
  bridge.install();
  assert.ok(hits >= 1, '安装即应通知订阅者（设置页诊断区刷新）');
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.ok(hits >= 2, '命中官方采集亦应通知');
  off();
  const frozen = hits;
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  assert.equal(hits, frozen, '退订后不再收到通知');
});

// ───────────────────────────── 可关闭 / 让位官方 ─────────────────────────────
test('OVB-C01 可关闭：环境标志置位 ⇒ 不安装且原因可见', async () => {
  const env = makeFakeEnv({ disabled: true });
  const bridge = loadBridge(env);
  assert.equal(bridge.install(), false, '被标志停用时不得安装');
  assert.equal(bridge.snapshot().abandonReason, 'disabled-by-flag', '须记原因');
  assert.equal(env.navigator.mediaDevices.getUserMedia.__dshPeWrapped, undefined, '不得包装');
});

test('OVB-C02 可关闭：localStorage 关闭开关同样生效', async () => {
  const env = makeFakeEnv({});
  env.localStorage.setItem('dsh.prompt-enhancer.officialBridge', 'off');
  const bridge = loadBridge(env);
  assert.equal(bridge.install(), false, 'localStorage=off 时不得安装');
});

test('OVB-C03 让位官方：检测到官方钩子 ⇒ 停用包装并恢复原函数', async () => {
  const env = makeFakeEnv({ officialHook: { version: 1 }, recordingPhase: true });
  const bridge = loadBridge(env);
  const orig = env.navigator.mediaDevices.getUserMedia;
  bridge.install();
  assert.notEqual(env.navigator.mediaDevices.getUserMedia, orig, '先装上了');
  const yielded = bridge.yieldToOfficialIfPresent();
  assert.equal(yielded, true, '检测到官方钩子须让位');
  assert.equal(env.navigator.mediaDevices.getUserMedia, orig, '让位后恢复原函数');
  assert.equal(bridge.snapshot().installed, false, '不再处于安装态');
  assert.equal(bridge.snapshot().abandonReason, 'yielded-to-official-hook', '让位原因可见');
});

test('OVB-C04 让位官方：无官方钩子时不得误让位', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  assert.equal(bridge.yieldToOfficialIfPresent(), false, '无钩子不得让位');
  assert.equal(bridge.snapshot().installed, true, '仍处于安装态');
});

// ───────────────────── 官方路径·自动增强（§4.6.2.6 第 4 条） ─────────────────────
// 极简 React 桩：ref/state 槽位**跨渲染持久**（真 React 的语义），effect 每次渲染后执行。
// 为什么必须持久：组件的自动增强逻辑靠 `draftRef.current` 跨渲染读草稿，槽位若不持久，
// 第二此渲染会拿到全新 ref ⇒ 永远读不到写回。
function makeMiniReact() {
  const refSlots = [];
  const stateSlots = [];
  let effects = [];
  let ri = 0, si = 0;
  return {
    begin() { ri = 0; si = 0; effects = []; },
    React: {
      useState(init) { const i = si++; if (!(i in stateSlots)) stateSlots[i] = typeof init === 'function' ? init() : init; return [stateSlots[i], (v) => { stateSlots[i] = v; }]; },
      useRef(init) { const i = ri++; if (!(i in refSlots)) refSlots[i] = { current: init }; return refSlots[i]; },
      useEffect(fn) { effects.push(fn); },
    },
    runEffects() { for (const fn of effects) fn(); },
  };
}

function buildHotkeyHost(env, bridge, opts) {
  const o = opts || {};
  const mini = makeMiniReact();
  const timerRegs = [];
  const timerSvcLocal = {
    interval: (fn, ms) => { const r = { fn, ms, kind: 'interval', cleared: false }; timerRegs.push(r); return () => { r.cleared = true; }; },
    // F-18：补停用 timeout 步进 ⇒ 测试可确定性地驱动 tick（不必等真实时钟）
    timeout: (fn, ms) => { const r = { fn, ms, kind: 'timeout', cleared: false }; timerRegs.push(r); return () => { r.cleared = true; }; },
  };
  bridge.setTimer(timerSvcLocal);
  // F-18：热键监听器只在「已启用且有组合键」时注册 ⇒ 需要驱动真实处理器的用例须传 hotkey:true
  const hkCombo = o.hotkeyCombo || 'Backquote';
  const voiceCfgState = { value: { autoEnhance: o.autoEnhance === true, vad: { enabled: true }, hotkey: { enabled: o.hotkey === true, combo: o.hotkey === true ? hkCombo : '' }, refine: {} }, listeners: new Set(), synced: true };
  const enhanceCalls = [];
  // F-18：持久 store 桩 —— 组件通过 storeFor(sessionId) 写 `error` 作为「失败可见」出口，
  //   旧桩每次返回新对象 ⇒ 写进去看不见。改为稳定对象，使该出口可被断言。
  const storeStub = { phase: 'idle', error: null, backup: '', enhanced: '', seq: 0, memoryRounds: [], optimized: false, lastModel: '', fallbackUsed: false, degraded: [], truncated: false };
  const src = decodeChunk('src/client/voice/hotkey.js');
  const factory = new Function(
    'React', 'host', 'voiceCfgState', 'subscribeVoiceConfig', 'voiceHotkeyDisplay', 'parseVoiceHotkey',
    'matchVoiceHotkey', 'isEnhancing', 'subscribe', 'storeFor', 'startVoiceRecording', 'stopVoiceRecording',
    'isVoiceRecording', 'insertVoiceText', 'notify', 'enhance', 'timerSvc', 'officialVoiceBridge', 'makeT', 'ZH',
    'MarqueeSelect', 'CollapsibleSection', 'setInterval', 'clearInterval', 'setTimeout', 'navigator', 'window',
    src + '\n;return { VoiceHotkeyHost };'
  );
  const api = factory(
    mini.React,
    { call: () => Promise.resolve({ ok: true }) },
    voiceCfgState, () => () => {}, (c) => c, () => null, () => false, () => false,
    () => () => {}, () => storeStub,
    async () => { throw new Error('should not record'); }, async () => null, () => false,
    () => Promise.resolve({ filled: true }), () => {},
    (...a) => { enhanceCalls.push(a); },   // enhance 桩
    timerSvcLocal, bridge, (p) => (k) => k, {}, null, null,
    setInterval, clearInterval, setTimeout, env.navigator, env.window
  );
  const props = { sessionId: o.sessionId || 'sess-x', inputActions: { setDraft() {} }, input: { draft: o.draft0 || '' } };
  const render = (draft) => { if (draft !== undefined) props.input = { draft }; mini.begin(); api.VoiceHotkeyHost(props); mini.runEffects(); };
  // 驱动生产代码里的真实热键处理器（windows stub 记录的监听器）
  // ⚠ 必须显式给四个修饰键为 false：matchVoiceHotkey 用 `e.ctrlKey === hk.ctrl` 严格比较，
  //   缺字段（undefined）会与 hk 的 false 不等 ⇒ 匹配失败、处理器直接 return（实测踩到）。
  const KEYDOWN = (extra) => Object.assign({
    code: 'Backquote', key: '`', ctrlKey: false, altKey: false, shiftKey: false, metaKey: false,
    repeat: false, preventDefault() {}, stopPropagation() {},
  }, extra || {});
  const keydown = () => env.window._fire('keydown', KEYDOWN());
  const keyup = () => env.window._fire('keyup', KEYDOWN());
  // 跑所有未清除的 timeout 步进（模拟时钟推进）
  const runTimeouts = (max) => { let n = 0; for (const r of timerRegs) { if (!r.cleared && r.kind === 'timeout') { r.cleared = true; r.fn(); n += 1; if (max && n >= max) break; } } return n; };
  return { render, props, enhanceCalls, timerRegs, voiceCfgState, mini, keydown, keyup, runTimeouts, store: storeStub };
}

test('OVB-A01 官方路径·自动增强：会话结束 + 写回落地 ⇒ autoEnhance 触发增强（有限轮询）', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: true, sessionId: 'sess-a1' });
  host.render('');                                  // 渲染#1：注册订阅
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();        // 官方会话开始（相位标记出现）
  env.document._attr = null; mo.cb();               // 官方会话结束（武装等待，快照 = 当前空草稿）
  host.render('官方识别出来的文字');                  // 渲染#2：官方写回落地
  let fired = false;
  for (const r of host.timerRegs) { if (!r.cleared) { r.fn(); fired = true; } }
  assert.equal(fired, true, '轮询必须真的跑过（不是空转）');
  assert.equal(host.enhanceCalls.length, 1, 'autoEnhance 开 ⇒ 写回落地后恰好触发 1 次增强（同一会话不重复）');
});

test('OVB-A02 官方路径·自动增强：autoEnhance 关 ⇒ 不得触发（负控）', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: false, sessionId: 'sess-a2' });
  host.render('');
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();        // 官方会话开始
  env.document._attr = null; mo.cb();
  host.render('写回的文本');
  for (const r of host.timerRegs) { if (!r.cleared) r.fn(); }
  assert.equal(host.enhanceCalls.length, 0, 'autoEnhance 关 ⇒ 不得触发增强');
});

test('OVB-A03 官方路径·自动增强：草稿始终未变 ⇒ 不得误触发（防"停完就增强"）', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: true, sessionId: 'sess-a3' });
  host.render('');
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();        // 官方会话开始
  env.document._attr = null; mo.cb();
  // 不写回（草稿不变）⇒ 轮询耗尽也不得增强，且不得无限轮询
  for (const r of host.timerRegs) { for (let i = 0; i < 60 && !r.cleared; i++) r.fn(); }
  assert.equal(host.enhanceCalls.length, 0, '草稿未变 ⇒ 不得触发增强');
  assert.equal(host.timerRegs.every((r) => r.cleared), true, '必须有轮询上限（停止轮询，不得无限跑）');
});

// ⚠ 本用例精确复现**本批真实语音链实测**命中的形态（V-5 的断点）：
//   官方 `finish()` 的顺序是 `insertText(...)` **然后** `setPhase("idle")`
//   ⇒ 相位节点消失（bridge 判「收口」）时，**写回已经落地**。
//   旧实现只在「收口那一刻」才快照基线 ⇒ 基线 = 写回后的草稿 ⇒ 永远测不到 delta ⇒ 自动增强永不触发。
test('OVB-A04 官方路径·自动增强（实测形态）：写回**先于**收口落地 ⇒ 仍必须触发增强', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: true, sessionId: 'sess-a4' });
  host.render('')                                   // 渲染#1：注册订阅（基线 = 空草稿）
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();         // 会话开始（此刻基线被记录 = 空草稿）
  host.render('官方写回的文字');                      // ⭐ 写回**先**落地（相位仍在 recording）
  env.document._attr = null; mo.cb();                // 收口（相位消失）
  let fired = false;
  for (const r of host.timerRegs) { if (!r.cleared) { r.fn(); fired = true; } }
  assert.equal(fired, true, '轮询必须真的跑过');
  assert.equal(host.enhanceCalls.length, 1, '写回先于收口 ⇒ 仍须恰好触发 1 次增强（旧实现此处为 0 = V-5 断点）');
});

test('OVB-A05 官方路径·自动增强：跨会话基线不串（第二会话以自己的起点为准）', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: true, sessionId: 'sess-a5' });
  host.render('');
  const mo = env.observerInstances[env.observerInstances.length - 1];
  // 第一会话：有写回 ⇒ 触发 1 次
  env.document._attr = 'recording'; mo.cb();
  host.render('第一段写回');
  env.document._attr = null; mo.cb();
  for (const r of host.timerRegs) { if (!r.cleared) r.fn(); }
  assert.equal(host.enhanceCalls.length, 1, '第一会话触发 1 次');
  // 第二会话：无写回（草稿保持第一段）⇒ 不得再触发
  env.document._attr = 'recording'; mo.cb();
  env.document._attr = null; mo.cb();
  for (const r of host.timerRegs) { for (let i = 0; i < 60 && !r.cleared; i++) r.fn(); }
  assert.equal(host.enhanceCalls.length, 1, '第二会话无写回 ⇒ 不得误触发（基线须随会话重置）');
});

// ───────────────────────────── 接线契约（防"注释有、代码无"） ─────────────────────────────
test('OVB-W01 接线：buildclient 装配清单与 skeleton 注入标记均在位', () => {
  const build = fs.readFileSync(path.join(ROOT, 'scripts', 'build-client.mjs'), 'utf8');
  const skel = fs.readFileSync(path.join(ROOT, 'src', 'client', 'skeleton.js'), 'utf8');
  assert.ok(build.includes("require('../src/client/voice/official-bridge.js')"), 'build-client 缺 official-bridge chunk 引用');
  assert.ok(build.includes('@dsh-client-voice-official-bridge-inject'), 'build-client 缺注入标记映射');
  assert.ok(skel.includes('@dsh-client-voice-official-bridge-inject'), 'skeleton 缺注入标记');
});

test('OVB-W02 接线：apply 安装 + 卸载（HMR）+ 热键→派发点击官方按钮的接线均在位', () => {
  const app = decodeChunk('src/client/app.js');
  assert.ok(app.includes('officialVoiceBridge.install()'), 'apply 缺安装调用');
  assert.ok(app.includes('officialVoiceBridge.uninstall()'), 'apply 缺卸载（HMR 恢复）');
  assert.ok(app.includes('officialVoiceBridge.setTimer'), 'apply 缺 timer 注入');
  const hk = decodeChunk('src/client/voice/hotkey.js');
  // P2-补做（UD-0016）：热键改为派发点击官方按钮 —— 启动走 startOfficial，停止走 stopOfficial
  assert.ok(hk.includes('officialVoiceBridge.startOfficial()'), '热键缺「派发点击官方开始按钮」（本批形态变更的落点）');
  assert.ok(hk.includes('officialVoiceBridge.stopOfficial()'), '热键缺「派发点击官方停止按钮」（唯一走完官方 finish() 的路径）');
  assert.ok(hk.includes("st.error = 'VOICE_BUSY'"), '热键缺「录音中」可见提示');
  assert.ok(hk.includes("st.error = 'VOICE_OFFICIAL_UNAVAILABLE'"), '热键缺「官方按钮不可用」可见提示（不得静默失败）');
  // 自建采集链退役：热键不得再自行取麦/录音/转写/停止（看**活代码**——注释里记录退役事实是允许的）
  const hkLive = hk.split('\n').filter((l) => !l.trim().startsWith('//')).join('\n');
  assert.equal(hkLive.includes('startVoiceRecording'), false, '自建链退役后热键不得再调 startVoiceRecording');
  assert.equal(hkLive.includes('stopVoiceRecording'), false, '自建链退役后热键不得再调 stopVoiceRecording');
  assert.equal(hkLive.includes('voice/transcribe'), false, '自建链退役后热键不得再自行调 voice/transcribe');
  assert.equal(hkLive.includes('getUserMedia'), false, '自建链退役后热键不得再自行取麦');
  assert.equal(hkLive.includes('isVoiceRecording'), false, '自建链退役后热键不得再查自建录音态');
  // 纯函数（四项增值之一）必须保留且行为不变
  for (const fn of ['parseVoiceHotkey', 'matchVoiceHotkey', 'voiceHotkeyDisplay']) {
    assert.ok(hk.includes('function ' + fn), '热键纯函数 ' + fn + ' 必须保留（四项增值不得丢）');
  }
});

test('OVB-W03 接线：设置页诊断区在位（不静默失效的可见面）且有 i18n 键', () => {
  const vs = decodeChunk('src/client/voice/voice-section.js');
  assert.ok(vs.includes('function OfficialVoiceDiag'), '设置段缺诊断组件');
  assert.ok(vs.includes("React.createElement(OfficialVoiceDiag, props)"), '诊断组件未进入渲染路径');
  assert.ok(vs.includes("t('voiceOfficialMissed')"), '缺「未观测到官方采集」文案引用');
  // D-1/D-2（FOLLOWUP §4）：三态可区分 + selfCapture 分支 + 派发点击失败可见
  assert.ok(vs.includes("t('voiceOfficialVerified')"), '缺「已观测到官方采集（N 次）」分支（D-1 修复：0 次须可区分）');
  // F-11 修复（2026-10-13）：键内含占位符 ⇒ 渲染处**代入** `{n}`，不得再追加第二个计数
  //   （旧实现：键内 %d 未替换 + 渲染处又追加括号计数 ⇒ 用户可见 `…（共 %d 次）（1）`）
  assert.ok(vs.includes(".replace('{n}', String(snap.sessionsStarted))"),
    'F-11 修复：须以 .replace(\'{n}\', …) 代入计数（不得再追加第二个计数）');
  assert.ok(vs.includes("t('voiceOfficialStartMissed')"), '缺「未能派发点击官方开始按钮」分支（不得静默失败）');
  assert.ok(vs.includes("t('voiceOfficialSelfCapture')"), '缺 selfCapture 分支（D-2 修复）');
  assert.ok(vs.includes('snap.sessionsStarted > 0'), 'D-1 修复须以官方会话计数分支（严格可判别）');
  const i18n = decodeChunk('src/client/i18n.js');
  for (const k of ['voiceOfficialDiagTitle', 'voiceOfficialActive', 'voiceOfficialMissed', 'voiceOfficialAbandon', 'voiceOfficialSelfCapture', 'voiceOfficialArmed', 'voiceOfficialDisabled',
    'voiceOfficialVerified', 'voiceOfficialStartMissed', 'voiceOfficialFeedback', 'voiceOfficialFeedbackSeen']) {
    assert.ok(i18n.includes(k + ":"), 'i18n 缺键 ' + k);
  }
  // ZH/EN 键集必须相等（S-7）
  const zh = i18n.split('const EN = {')[0];
  const en = 'const EN = {' + i18n.split('const EN = {')[1];
  const zk = (zh.match(/voiceOfficial[A-Za-z]+:/g) || []).sort();
  const ek = (en.match(/voiceOfficial[A-Za-z]+:/g) || []).sort();
  assert.deepEqual(zk, ek, 'voiceOfficial* ZH/EN 键集必须相等（S-7）');
  assert.equal(zk.length, 11, 'voiceOfficial* 键数锁定为 11（严格 ===：7 原有 + 4 本批新增）');
});

// F-11（2026-10-13）：用户可见面不得出现未替换的占位符，且计数只留一个
test('OVB-W04 F-11：诊断区成功态原文不含未替换占位符，且计数只出现一次', () => {
  const vs = decodeChunk('src/client/voice/voice-section.js');
  const i18n = decodeChunk('src/client/i18n.js');
  // 键：不得再含 printf 风格 %d（本项目约定为 {n}）
  assert.ok(!/voiceOfficialVerified: '[^']*%d/.test(i18n), 'F-11：键内不得再用 %d（约定 {n}）');
  assert.ok(/voiceOfficialVerified: '[^']*\{n\}[^']*'/.test(i18n), 'F-11：键内须含 {n} 占位符');
  assert.ok(/voiceOfficialVerified: 'Official capture observed \(\{n\}[^']*'/.test(i18n), 'F-11：EN 键同样须含 {n}');
  // 渲染处：只代入，不再追加计数（不得同时出现 replace 与第二个拼接）
  const seg = vs.slice(vs.indexOf('voiceOfficialVerified'), vs.indexOf('voiceOfficialVerified') + 220);
  assert.ok(seg.includes(".replace('{n}'"), 'F-11：渲染处须代入 {n}');
  assert.ok(!/voiceOfficialVerified'\)\s*\+\s*'（'/.test(vs),
    'F-11：渲染处不得再追加第二个计数（旧实现 t(...) + \'（\' + n + \'）\'）');
  // 端到端字面值：代入后不得残留 {n} / %d
  const t = (k) => { const m = new RegExp("  " + k + ": '([^']*)'"); const r = i18n.match(m); return r ? r[1] : ''; };
  const zhText = t('voiceOfficialVerified').replace('{n}', '1');
  assert.equal(/[{]n[}]|%d/.test(zhText), false, 'F-11：代入后不得残留占位符 —— ' + zhText);
  assert.equal(zhText, '已观测到官方采集（共 1 次）', 'F-11：成功态原文须恰为一次计数');
});

test('OVB-W05 F-11 变异自证：把键退回 %d（且渲染处仍追加）⇒ OVB-W04 必红', () => {
  const i18n = decodeChunk('src/client/i18n.js');
  const anchor = "voiceOfficialVerified: '已观测到官方采集（共 {n} 次）'";
  assert.ok(i18n.includes(anchor), 'F-11 修复锚点须存在');
  const mutated = i18n.replace(anchor, "voiceOfficialVerified: '已观测到官方采集（共 %d 次）'");
  assert.ok(!/voiceOfficialVerified: '[^']*%d/.test(i18n), '前置：修复后不得含 %d');
  assert.ok(/voiceOfficialVerified: '[^']*%d/.test(mutated), '退回 %d 后必须能被 OVB-W04 检出（若检出不了 ⇒ 判据没牙）');
});

test('OVB-W04 边界：src/host 与 plugin-host.js 零改动（本批不许碰载体）', () => {
  const host = fs.readFileSync(path.join(ROOT, 'plugin-host.js'), 'utf8');
  assert.equal(host.includes('officialVoiceBridge'), false, 'plugin-host.js 不得出现本批新增标识符（载体零改动）');
  const buildHost = fs.readFileSync(path.join(ROOT, 'scripts', 'build-host.mjs'), 'utf8');
  assert.equal(buildHost.includes('officialVoiceBridge'), false, 'build-host.mjs 不得涉及本批改动');
  // lib/index.cjs 的求值桥接原样保留（UD-0013 硬边界）
  const idx = fs.readFileSync(path.join(ROOT, 'lib', 'index.cjs'), 'utf8');
  assert.ok(idx.includes("new Function('harness', BODY)"), 'lib/index.cjs 的 new Function 桥接必须原样保留');
});

// ───────────────────────────── 变异自证 ─────────────────────────────
// 变异名运行时拼接（不在源码里形成字面量），且为判据的合法输入（合法约束对象）。
// 正例必红：把 A1 的 stop 触发点摘掉 ⇒ OVB-P01 必失败。
// 负控必绿：摘掉 stop 后，负控类判据（OVB-N01/N02）必须仍然通过。
function applyMutation(src, kind) {
  const KILL_A1 = 'ovb' + 'StopOfficial';
  if (kind === 'kill-a1-stop') {
    // 让 A1 分支永不成立（只改判定条件），A2 也随之不可用 ⇒ 正例必红
    const before = "if (b.recording && b.recording.state === 'recording') {";
    const after = "if (false && b.recording && b.recording.state === 'recording') {";
    if (!src.includes(before)) throw new Error('mutation anchor missing: ' + before);
    return src.replace(before, after);
  }
  if (kind === 'kill-vad-call') {
    const before = 'vadStop = ovbStartVad(stream,';
    const after = 'vadStop = (0 && ovbStartVad)(stream,';
    if (!src.includes(before)) throw new Error('mutation anchor missing: ' + before);
    return src.replace(before, after);
  }
  throw new Error('unknown mutation kind');
}

function loadMutant(env, kind) {
  const src = applyMutation(decodeChunk(CHUNK), kind);
  const S = loadStateForBridge(env);
  const factory = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    src + '\n;return officialVoiceBridge;'
  );
  let seq = 0;
  const bridge = factory(
    env.window, env.document, env.navigator, env.localStorage,
    (fn, ms) => { const rec = { fn, ms, cleared: false, id: ++seq }; env.timers.push(rec); return rec.id; },
    (id) => { const rec = env.timers.find((r) => r.id === id); if (rec) rec.cleared = true; },
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent(type, init) { return { type, init }; },
    S.vadSilenceMsOf, S.vadRequiredQuiet, S.voiceCfgState
  );
  bridge.setTimer(env.timerSvc);
  return bridge;
}

test('OVB-V01 变异自证·正例必红：摘掉 A1 stop ⇒ 正例判据必须失败', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadMutant(env, 'kill-a1-stop');
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  const rec = new env.window.MediaRecorder(env.mediaDevices.lastStream);
  rec.start();
  runVad(env);
  // 正例判据在变异下必须失败（此处断言"确实失败了"，以证明判据有牙）
  const wouldPass = (rec.state === 'inactive' && rec.stopCalls === 1);
  assert.equal(wouldPass, false, '变异后正例判据必须为红（若仍绿 ⇒ 判据没牙）');
});

test('OVB-V02 变异自证·负控必绿：同一变异下负控判据仍须通过', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadMutant(env, 'kill-a1-stop');
  bridge.install();
  // 负控：非音频约束不介入 + 同一性 —— 与 A1 stop 无关，必须仍绿
  const before = env.timers.length;
  const s = await env.navigator.mediaDevices.getUserMedia({ video: true });
  assert.equal(s, env.mediaDevices.lastStream, '负控·同一性仍绿');
  assert.equal(env.timers.length, before, '负控·未命中仍绿');
});

test('OVB-V03 变异自证·摘掉 VAD ⇒ 静音达标不再触发官方 stop（读数来自变异本身）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadMutant(env, 'kill-vad-call');
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  const rec = new env.window.MediaRecorder(env.mediaDevices.lastStream);
  rec.start();
  runVad(env);
  assert.equal(rec.stopCalls || 0, 0, 'VAD 被摘掉后不得再触发 stop（证明静音链路是 stop 的真实来源）');
});

test('OVB-V04 变异自证·幂等判据有牙：破坏幂等 ⇒ 层数判据必红', () => {
  const src = decodeChunk(CHUNK);
  const before = 'if (b.installed) return false;';
  assert.ok(src.includes(before), '幂等锚点须存在');
  // 运行期拼接变异：删掉幂等短路
  const mutated = src.replace(before, 'if (false) return false;');
  const env = makeFakeEnv({});
  const S4 = loadStateForBridge(env);
  const factory = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    mutated + '\n;return officialVoiceBridge;'
  );
  let seq = 0;
  const bridge = factory(
    env.window, env.document, env.navigator, env.localStorage,
    (fn, ms) => { const rec = { fn, ms, cleared: false, id: ++seq }; env.timers.push(rec); return rec.id; },
    () => {},
    class FakeMO { constructor() {} observe() {} disconnect() {} },
    function MouseEvent() { return {}; },
    S4.vadSilenceMsOf, S4.vadRequiredQuiet, S4.voiceCfgState
  );
  bridge.install();
  const first = env.navigator.mediaDevices.getUserMedia;
  const second = bridge.install();
  // 破坏幂等后：二次安装会返回 true（或替换包装层）⇒ 幂等判据必红
  const stillOneLayer = (env.navigator.mediaDevices.getUserMedia === first);
  assert.equal(second === false || stillOneLayer, false, '破坏幂等后「只包一次」判据必须为红');
});

// ── P2-补做（UD-0016）新增能力的变异自证 ──────────────────────────────────────
// 变异名一律**运行时拼接**（不在源码里形成字面量），且为判据的合法输入。
test('OVB-V05 变异自证·正例必红：掏空「官方开始按钮查找」⇒ 启动正例必须失败', () => {
  const src = decodeChunk(CHUNK);
  // 变异：把按钮查找函数体掏空（恒返回 null）⇒ 启动必然失败。变异名运行时拼接，不形成字面量。
  const fnName = 'ovbFind' + 'StartButton';
  const anchor = 'function ' + fnName + '() {';
  const kill = 'function ' + fnName + '() { return null;';
  assert.ok(src.includes(anchor), '启动锚点须存在');
  const mutated = src.replace(anchor, kill);
  const env = makeFakeEnv({});
  const S5 = loadStateForBridge(env);
  const bridge = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    mutated + '\n;return officialVoiceBridge;'
  )(env.window, env.document, env.navigator, env.localStorage, () => 0, () => {},
    class FakeMO { constructor() {} observe() {} disconnect() {} }, function MouseEvent() { return {}; },
    S5.vadSilenceMsOf, S5.vadRequiredQuiet, S5.voiceCfgState);
  bridge.setTimer(env.timerSvc);
  bridge.install();
  const r = bridge.startOfficial();
  assert.equal(r.started, false, '变异后「派发点击开始按钮」不得再成立（若仍绿 ⇒ 启动判据没牙）');
  assert.equal(env.startButton.clicks, 0, '变异后不得有任何点击（判据的读数来源就是它）');
});

test('OVB-V06 变异自证·负控必绿：同一变异下「按钮不存在不得静默」判据仍须通过', () => {
  const src = decodeChunk(CHUNK);
  const fnName = 'ovbFind' + 'StartButton';
  const mutated = src.replace('function ' + fnName + '() {', 'function ' + fnName + '() { return null;');
  const env = makeFakeEnv({ noStartButton: true });
  const S6 = loadStateForBridge(env);
  const bridge = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    mutated + '\n;return officialVoiceBridge;'
  )(env.window, env.document, env.navigator, env.localStorage, () => 0, () => {},
    class FakeMO { constructor() {} observe() {} disconnect() {} }, function MouseEvent() { return {}; },
    S6.vadSilenceMsOf, S6.vadRequiredQuiet, S6.voiceCfgState);
  bridge.setTimer(env.timerSvc);
  bridge.install();
  const r = bridge.startOfficial();
  // 负控与「是否真找到按钮」无关：无论变异与否，「未启动必须留可见读数」都必须成立
  assert.equal(r.started, false, '负控必绿：未启动');
  assert.ok(bridge.snapshot().startMissed >= 1, '负控必绿：未启动必须计数（不得静默）');
});

test('OVB-V07 变异自证·正例必红：把 missed 判定退回「上升沿快照」⇒ 竞态回归判据必须失败', () => {
  const src = decodeChunk(CHUNK);
  const anchor = 'if (now === (b.callCountAtPrevSessionEnd || 0)) {';
  // 变异 = 精确复现**被 CDP 证伪**的旧口径：把窗口下界当成「本会话上升沿那一刻的计数」，
  //   而实现里上升沿读到的计数**已经含本次调用**（实测：相位出现时 callCount 已为 1）
  //   ⇒ 拿它当界 ⇒ 真命中被判 missed。运行期拼接变异名（不形成字面量）。
  const kill = 'if ((b.callCount || 0) === 1) {';
  assert.ok(src.includes(anchor), 'missed 收口锚点须存在');
  const mutated = src.replace(anchor, kill);
  const env = makeFakeEnv({ recordingPhase: true });
  const S7 = loadStateForBridge(env);
  const bridge = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    mutated + '\n;return officialVoiceBridge;'
  )(env.window, env.document, env.navigator, env.localStorage, () => 0, () => {},
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent() { return {}; }, S7.vadSilenceMsOf, S7.vadRequiredQuiet, S7.voiceCfgState);
  bridge.setTimer(env.timerSvc);
  bridge.install();
  // 精确复现 CDP 实测形态：**调用先落地**（相位尚未出现），相位随后才到 ⇒ 旧口径误报 missed
  return env.navigator.mediaDevices.getUserMedia({ audio: true, video: false }).then(() => {
    const mo = env.observerInstances[env.observerInstances.length - 1];
    env.document._attr = 'recording'; mo.cb();
    env.document._attr = null; mo.cb();
    const snap = bridge.snapshot();
    assert.equal(snap.callCount > 0, true, '前置：包装确实落地过');
    assert.equal(snap.sessionsMissed > 0, true, '退回旧口径后必须误报 missed（若仍为 0 ⇒ 竞态判据没牙）');
  });
});

// ── N-1 修复的变异自证（变异名一律**运行时拼接**，且为判据的合法输入）──
test('OVB-V08 变异自证·正例必红：把 N-1 守卫退回旧口径 ⇒ N-1 回归锁必须失败', () => {
  const src = decodeChunk(CHUNK);
  const guard = 'if (!ovb' + 'RecordingNow()) {';
  assert.ok(src.includes(guard), 'N-1 守卫锚点须存在');
  const mutated = src.replace(guard, 'if (false) {');
  const env = makeFakeEnv({ recordingPhase: true, noStopButton: true });
  const S8 = loadStateForBridge(env);
  const bridge = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    mutated + '\n;return officialVoiceBridge;'
  )(env.window, env.document, env.navigator, env.localStorage, () => 0, () => {},
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent() { return {}; }, S8.vadSilenceMsOf, S8.vadRequiredQuiet, S8.voiceCfgState);
  bridge.setTimer(env.timerSvc);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  env.document._attr = 'feedback'; mo.cb();        // 会话已收尾（实测病形态）
  const r = bridge.stopOfficial();
  const snap = bridge.snapshot();
  // 退回旧口径 ⇒ 照记 missed + 写原因 ⇒ N-1 回归锁的两条断言必红
  const wouldPass = (r.via !== 'no-active-session' && snap.stopMissed === 0 && snap.abandonReason === '');
  assert.equal(wouldPass, false, '退回旧口径后 N-1 回归锁必须为红（若仍绿 ⇒ 该锁没牙）');
});

test('OVB-V09 变异自证·负控必绿：同一变异下「采集进行中仍须降级」的反向锁仍须通过', () => {
  const src = decodeChunk(CHUNK);
  const guard = 'if (!ovb' + 'RecordingNow()) {';
  const mutated = src.replace(guard, 'if (false) {');
  const env = makeFakeEnv({ recordingPhase: true, noStopButton: true });
  const S9 = loadStateForBridge(env);
  const bridge = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    mutated + '\n;return officialVoiceBridge;'
  )(env.window, env.document, env.navigator, env.localStorage, () => 0, () => {},
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent() { return {}; }, S9.vadSilenceMsOf, S9.vadRequiredQuiet, S9.voiceCfgState);
  bridge.setTimer(env.timerSvc);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();       // 采集**进行中**
  const r = bridge.stopOfficial();
  // 负控与「守卫在不在」无关：采集进行中且两路不可用，无论变异与否都必须降级
  assert.equal(r.via, 'abandoned', '负控必绿：采集进行中 ⇒ 仍须走降级');
  assert.equal(bridge.snapshot().stopMissed, 1, '负控必绿：仍须计 missed');
});

// ── missed 判定的「迟到落地」回归锁（本批 CDP 实测命中的第二种误报形态）──
// 病：某次会话的真正 `getUserMedia` 可能**极晚**才落地（实测：official start → phase recording
//     → 120s 上限 finish → 包装器 `.then()` 才落地）。若用「时刻快照」比 `firstCallAt`，
//     该会话的收口发生在包装落地**之前** ⇒ 真命中被判成 missed（实测 sessionsMissed=1 且 firstCallAt>0 并存）。
// 修：改用**调用计数**（只增不减）⇒ 收口时比较计数即可，无「迟到窗口」。
test('OVB-D05 迟到落地回归锁：会话收口早于包装调用 ⇒ 不得误报 missed', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();          // ① 相位先到（包装尚未被调用）
  env.document._attr = null; mo.cb();                 // ② 会话**先收口**（收口时 callCount 仍为 0）
  // ③ 包装调用**迟到**（收口之后才落地）
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  const snap = bridge.snapshot();
  assert.equal(snap.callCount, 1, '前置：包装确实被调用过 1 次');
  assert.equal(snap.sessionsStarted, 1, '仍记录 1 次会话');
  assert.equal(snap.sessionsMissed, 1, '收口时确实一次都没被调用 ⇒ 该情形**应**计 missed（诚实判据）');
});

test('OVB-D06 迟到落地回归锁·真命中：会话内调用虽晚但**在收口前**计数已增 ⇒ 不得误报', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();          // 相位先到
  await env.navigator.mediaDevices.getUserMedia({ audio: true, video: false });  // 包装落地（会话仍在录）
  env.document._attr = null; mo.cb();                 // 会话收口
  const snap = bridge.snapshot();
  assert.equal(snap.callCount, 1, '前置：调用计数为 1');
  assert.equal(snap.sessionsMissed, 0, '会话内发生过调用 ⇒ 收口时计数不同 ⇒ **不得**计 missed');
});

test('OVB-V10 变异自证·正例必红：摘掉 missed 收口判定 ⇒ 迟到落地锁（该计 missed 那一支）必须失败', () => {
  const src = decodeChunk(CHUNK);
  const anchor = 'if (now === (b.callCountAtPrevSessionEnd || 0)) {';
  // 变异 = 精确复现本批实测误报的那个写法：**只看 firstCallAt 与「会话起点是否有过调用」的时刻关系**。
  // 实测形态：上一次会话已置 firstCallAt，而本次会话的 getUserMedia 迟到到收口之后 ⇒ 时刻口径判 missed。
  // 运行期拼接变异名（不形成字面量）。
  // 变异 = 让收口判定**永不成立**（等价于把 missed 判据整条摘掉）⇒ D05「该计 missed」必然失败
  const kill = 'if (false) {';
  assert.ok(src.includes(anchor), 'missed 锚点须存在');
  const mutated = src.replace(anchor, kill);
  const env = makeFakeEnv({ recordingPhase: true });
  const SV = loadStateForBridge(env);
  const bridge = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    mutated + '\n;return officialVoiceBridge;'
  )(env.window, env.document, env.navigator, env.localStorage, () => 0, () => {},
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent() { return {}; }, SV.vadSilenceMsOf, SV.vadRequiredQuiet, SV.voiceCfgState);
  bridge.setTimer(env.timerSvc);
  bridge.install();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  env.document._attr = null; mo.cb();      // 会话收口（此时一次都没被调用）⇒ 无变异时应计 missed
  return env.navigator.mediaDevices.getUserMedia({ audio: true, video: false }).then(() => {
    const snap = bridge.snapshot();
    assert.equal(snap.callCount, 1, '前置：确实调用过');
    assert.equal(snap.sessionsMissed === 0, true, '摘掉收口判定后必须**不再**计 missed ⇒ D05 的两义必红（若仍计 ⇒ 该锁没牙）');
  });
});

// ── F-18 修复的回归锁（2026-10-13·收尾批）─────────────────────────────────────
// 病：长按松开时若「启动尚未落地/停止派发太早」⇒ 旧实现**只写 `longReleaseRef` 标记、无人消费**
//     ⇒ 「松开即停」（README 承诺）静默落空，且**不留任何读数**（症状：已松手、官方仍在录音）。
// 修：两条进入路径都补**有界**消费（真派发停止并校验是否生效）；成功/失败都留读数。
test('OVB-R01 F-18：长按松开时启动尚未落地 ⇒ 必须在启动落地后**补停**，且 stopClicks 恰好 1', async () => {
  // ⚠ 必须 recordingPhase:true —— 该开关决定「相位节点数组」是否存在（false ⇒ 数组为空 ⇒ 相位永远查不到）。
  //   本组要的是「松开时相位**尚未**出现、随后才出现」，故节点须存在、`_attr` 初始为 null 由用例控制。
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: false, hotkey: true, sessionId: 'sess-r1' });
  host.render('');
  // 长按：按下 → 真实时间过阈值（500ms 是生产常量，不可改）→ 松开
  host.keydown();
  await new Promise((r) => setTimeout(r, 620));
  host.keyup();
  // 松开后官方启动才落地（相位出现）⇒ 桥报 recording；补停轮询应能真的派发到停止按钮
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  const snapMid = bridge.snapshot();
  for (let i = 0; i < 20; i++) host.runTimeouts(1);
  const snap = bridge.snapshot();
  assert.equal(snapMid.recording, true, '前置：官方确已进入采集态（补停窗口内）');
  assert.equal(snap.stopClicks, 1, 'F-18：补停必须恰好派发 1 次停止（旧实现为 0 = 松开即停落空）');
  assert.equal(snap.stopMissed, 0, '补停成功 ⇒ 不得记 missed');
});

test('OVB-R02 F-18：补停**成功**后不得再补（不得重复派发）⇒ stopClicks 不 >1', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: false, hotkey: true, sessionId: 'sess-r2' });
  host.render('');
  host.keydown();
  await new Promise((r) => setTimeout(r, 620));
  host.keyup();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  for (let i = 0; i < 40; i++) host.runTimeouts(1);   // 远超上限地驱动
  const snap = bridge.snapshot();
  assert.equal(snap.stopClicks, 1, 'F-18：补停成功即停 ⇒ stopClicks 必须恰好 1（>1 = 重复派发）');
});

test('OVB-R03 F-18：补停**失败**必须留可见读数（不得静默）', async () => {
  const env = makeFakeEnv({ recordingPhase: true, noStopButton: true });  // 停止按钮不可用 ⇒ 补停必败
  const bridge = loadBridge(env);
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: false, hotkey: true, sessionId: 'sess-r3' });
  host.render('');
  host.keydown();
  await new Promise((r) => setTimeout(r, 620));
  host.keyup();
  // 官方进入采集态但**没有停止按钮** ⇒ 每次补停都会落到显式降级
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  for (let i = 0; i < 40; i++) host.runTimeouts(1);
  const snap = bridge.snapshot();
  assert.equal(snap.stopClicks, 0, '前置：确实一次都没停掉');
  assert.equal(host.store.error, 'VOICE_OFFICIAL_UNAVAILABLE', 'F-18：补停失败必须在组件状态留错误（可见面不得静默）');
});

test('OVB-R04 F-18 变异自证：退回「只写标记、无消费」⇒ OVB-R01 必红', async () => {
  const src = decodeChunk('src/client/voice/hotkey.js');
  // 变异 = 精确复现旧写法：只置标记，不启动补停轮询
  const anchor = "        longReleaseRef.current = true;\n        scheduleDeferredStop();";
  assert.ok(src.includes(anchor), 'F-18 消费锚点须存在');
  const mutated = src.replace(anchor, "        longReleaseRef.current = true;");
  assert.ok(!mutated.includes('scheduleDeferredStop();\n      }\n      return;'), '变异后不得再启动补停（否则变异无效）');
  // 用变异源码建一个宿主，断言补停**不会**发生 ⇒ 证明 OVB-R01 的判据有牙
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env);
  bridge.install();
  const mini = makeMiniReact();
  const timerRegs = [];
  const timerSvcLocal = {
    interval: (fn, ms) => { const r = { fn, ms, kind: 'interval', cleared: false }; timerRegs.push(r); return () => { r.cleared = true; }; },
    timeout: (fn, ms) => { const r = { fn, ms, kind: 'timeout', cleared: false }; timerRegs.push(r); return () => { r.cleared = true; }; },
  };
  bridge.setTimer(timerSvcLocal);
  const voiceCfgState = { value: { autoEnhance: false, vad: { enabled: true }, hotkey: { enabled: true, combo: 'Backquote' }, refine: {} }, listeners: new Set() };
  const storeStub = { phase: 'idle', error: null, backup: '', enhanced: '', seq: 0, memoryRounds: [], optimized: false, lastModel: '', fallbackUsed: false, degraded: [], truncated: false };
  const factory = new Function(
    'React', 'host', 'voiceCfgState', 'subscribeVoiceConfig', 'voiceHotkeyDisplay', 'parseVoiceHotkey',
    'matchVoiceHotkey', 'isEnhancing', 'subscribe', 'storeFor', 'startVoiceRecording', 'stopVoiceRecording',
    'isVoiceRecording', 'insertVoiceText', 'notify', 'enhance', 'timerSvc', 'officialVoiceBridge', 'makeT', 'ZH',
    'MarqueeSelect', 'CollapsibleSection', 'setInterval', 'clearInterval', 'setTimeout', 'navigator', 'window',
    mutated + '\n;return { VoiceHotkeyHost };'
  );
  const api = factory(
    mini.React, { call: () => Promise.resolve({ ok: true }) },
    voiceCfgState, () => () => {}, (c) => c, () => null, () => false, () => false,
    () => () => {}, () => storeStub,
    async () => { throw new Error('x'); }, async () => null, () => false,
    () => Promise.resolve({ filled: true }), () => {}, () => {},
    timerSvcLocal, bridge, (p) => (k) => k, {}, null, null,
    setInterval, clearInterval, setTimeout, env.navigator, env.window
  );
  const props = { sessionId: 'sess-r4', inputActions: { setDraft() {} }, input: { draft: '' } };
  mini.begin(); api.VoiceHotkeyHost(props); mini.runEffects();
  env.window._fire('keydown', { code: 'Backquote', key: '`', ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, repeat: false, preventDefault() {}, stopPropagation() {} });
  await new Promise((r) => setTimeout(r, 620));
  env.window._fire('keyup', { code: 'Backquote', key: '`', ctrlKey: false, altKey: false, shiftKey: false, metaKey: false, repeat: false, preventDefault() {}, stopPropagation() {} });
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();
  for (let i = 0; i < 40; i++) { for (const r of timerRegs) { if (!r.cleared && r.kind === 'timeout') { r.cleared = true; r.fn(); } } }
  const snap = bridge.snapshot();
  assert.equal(snap.stopClicks, 0, '变异（只写标记、无消费）下补停**不会**发生 ⇒ OVB-R01 的 stopClicks===1 判据有牙');
});

// ═══════════════════════════════════════════════════════════════════════════════
// VAD-1/VAD-2 订正批（2026-10-14 定位批）：**校准窗不可信** 的机制回归锁
// ═══════════════════════════════════════════════════════════════════════════════
// 背景（用户现场读数）：手动点官方 🎤 后「一直在录，不说话也不停 / 说完停顿也不停」。
// 机制（本批已定位）：`ovbStartVad` 拿**前 5 帧（≈500ms）中位数 ×2.5** 当阈值。
//   真人「按下按钮即开口」⇒ **校准样本含语音** ⇒ 底噪被抬到语音电平 ⇒ 阈值 = 底噪×2.5
//   **结构上高于同一段语音** ⇒ `heardSpeech` 永不为真 ⇒ 静音计数永不启动 ⇒ 一直录。
//   这也解释了为何既有 CDP 取证（假设备 + 素材，校准期恰落在素材**前置静音**里）会「通过」——
//   假件对「起始即说话」这一形态**有盲区**。
//
// 本组夹具用**生成器**驱帧（永不耗尽）：旧实现用有限数组时，帧取尽会被折叠成常量，
// 那会**伪造**出自愈行为（本席第一版夹具即栽在此处，已在报告中记录）。
function makeGenEnv(gen) {
  const env = makeFakeEnv({ recordingPhase: true });
  // 替换假件的取帧方式：改为按 tick 调用生成器（不再是有限数组 shift）
  const frames = [];
  env.frames = frames;
  const origMake = null; void origMake;
  return { env, gen };
}

// 用生成器驱动：重建假件的 analyser 取帧源
function installGenFrames(env, gen) {
  const FakeAnalyser = function () { this.fftSize = 1024; };
  FakeAnalyser.prototype.getByteTimeDomainData = function (buf) {
    const v = Math.max(0, Math.min(1, gen()));
    const byte = Math.max(0, Math.min(255, Math.round(128 + v * 128)));
    for (let i = 0; i < buf.length; i++) buf[i] = byte;
  };
  env.window.AudioContext = class {
    constructor() { this.state = 'running'; }
    createMediaStreamSource() { return { connect() {} }; }
    createAnalyser() { return new FakeAnalyser(); }
    close() { this.state = 'closed'; return Promise.resolve(); }
  };
}

// 夹具语法：stages = [{frames, rms}]，超出末段后沿用末段
function stageGen(stages) {
  let i = 0; let k = 0;
  return () => {
    while (i < stages.length - 1 && k >= stages[i].frames) { k -= stages[i].frames; i++; }
    k++;
    return stages[i].rms;
  };
}

// 驱动到静音达标/上限，返回读数（stopClicks 等）
async function driveVad(env, bridge, cap) {
  await env.navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
  await flush();
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  let ticks = 0;
  for (const rec of env.timers) { while (!rec.cleared && ticks < (cap || 600)) { rec.fn(); ticks++; } }
  return { ticks, snap: bridge.snapshot(), clicks: env.stopButton.clicks };
}

test('OVB-VAD-01 F2 首要假设：校准窗含语音（起始即说话）⇒ 修复后**必须**自动停', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.05 },     // 校准窗：用户按下即开口 ⇒ 样本含语音
    { frames: 100, rms: 0.05 },   // 持续说话（与校准同电平）
    { frames: 300, rms: 0.001 },  // 说完停顿
  ]));
  const bridge = loadBridge(env);
  bridge.install();
  const r = await driveVad(env, bridge);
  assert.equal(r.clicks, 1, '起始即说话（校准含语音）⇒ 修复后必须派发点击官方停止恰好 1 次');
  assert.equal(r.snap.stopMissed, 0, '不得计 missed');
  assert.equal(r.snap.abandonReason, '', '不得留下降级原因');
});

test('OVB-VAD-02 F2\' 真实形态：校准含语音 + 语音有起伏（词间回落）⇒ 必须自动停', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.05 },
    { frames: 100, rms: 0.08 },
    { frames: 300, rms: 0.001 },
  ]));
  const bridge = loadBridge(env);
  bridge.install();
  const r = await driveVad(env, bridge);
  assert.equal(r.clicks, 1, '有起伏的真实语音同样必须能自动停（阈值须已自愈回落）');
});

test('OVB-VAD-03 F1 低电平边界（语音低于绝对下限 0.025）⇒ **不得**误停（负控）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.001 },
    { frames: 100, rms: 0.02 },   // 音量低于绝对阈值下限
    { frames: 300, rms: 0.001 },
  ]));
  const bridge = loadBridge(env);
  bridge.install();
  const r = await driveVad(env, bridge);
  assert.equal(r.clicks, 0, '语音电平低于绝对阈值下限时不得误判为说话（防误停取向保持）');
});

test('OVB-VAD-04 N1 关键负控：校准窗含语音/噪声但**此后从未说话** ⇒ 绝不得误停', async () => {
  // ⚠ 本判据是修复的**反向锁**：自愈会让阈值快速回落，若不同步清掉平滑残留，
  //   校准窗的电平会被残留的 smoothRms 当作「听到过语音」⇒ 误计静音帧 ⇒ 误停。
  //   （本席第一版修复即命中该形态，被本夹具抓到后加了 VAD-2「校准结束清平滑」。）
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.05 },     // 校准含噪（用户按按钮时有环境声/呼吸）
    { frames: 400, rms: 0.002 },  // 此后一片安静：用户**从未说话**
  ]));
  const bridge = loadBridge(env);
  bridge.install();
  const r = await driveVad(env, bridge);
  assert.equal(r.clicks, 0, '⚠ 校准含噪但此后从未说话 ⇒ **不得**误停（否则等于凭空结束录音）');
});

test('OVB-VAD-05 F3 高底噪（持续噪声不下降）⇒ 语音未过抬高后的阈 ⇒ 不得误停（负控）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.06 },     // 高底噪：阈 = 0.06×2.5 = 0.15
    { frames: 100, rms: 0.1 },    // 说话 0.1 < 0.15 ⇒ 未过门
    { frames: 300, rms: 0.06 },
  ]));
  const bridge = loadBridge(env);
  bridge.install();
  const r = await driveVad(env, bridge);
  assert.equal(r.clicks, 0, '持续高底噪下语音未过门 ⇒ 不得计静音（与旧实现同取向；本判据锁住"未过门就不停"）');
});

test('OVB-VAD-06 读数不静默：VAD 内部状态必须进诊断快照（门是否开过可判）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([{ frames: 400, rms: 0.001 }]));
  const bridge = loadBridge(env);
  bridge.install();
  await driveVad(env, bridge);
  const snap = bridge.snapshot();
  for (const k of ['vadHeardSpeech', 'vadQuietFrames', 'vadThreshold', 'vadNoiseFloor']) {
    assert.ok(Object.prototype.hasOwnProperty.call(snap, k), '诊断快照缺读数 ' + k + '（门从未开过这一形态此前**无法判别**）');
  }
  assert.equal(snap.vadHeardSpeech, false, '全程静音 ⇒ 门未开过（这正是用户现场"一直录"的那一格）');
});

// ── 变异自证：把修复退回（仅降不升的自愈 + 校准清平滑）⇒ 判据必须转红 ──────────
// ⚠ 只在**内存副本**内变异（不动仓库文件）。
function loadMutantBridge(env, mutate) {
  const src = mutate(decodeChunk(CHUNK));
  const S = loadStateForBridge(env);
  const factory = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState',
    src + '\n;return officialVoiceBridge;'
  );
  let seq = 0;
  const bridge = factory(
    env.window, env.document, env.navigator, env.localStorage,
    (fn, ms) => { const rec = { fn, ms, cleared: false, id: ++seq }; env.timers.push(rec); return rec.id; },
    (id) => { const rec = env.timers.find((r) => r.id === id); if (rec) rec.cleared = true; },
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent(type, init) { return { type, init }; },
    S.vadSilenceMsOf, S.vadRequiredQuiet, S.voiceCfgState
  );
  bridge.setTimer(env.timerSvc);
  return bridge;
}

// 变异①：把「运行期自愈（只降不升）」整段退回 ⇒ 校准被语音污染后阈值不再回落
function mutateNoSelfHeal(src) {
  const anchor = 'if (rms < noiseFloor) {';
  assert.ok(src.includes(anchor), '变异锚点须存在（自愈分支）');
  return src.replace(anchor, 'if (false) {');
}
// 变异②：把「校准结束清平滑残留」退回 ⇒ N1 形态被误判为「听到过语音」⇒ 误停
function mutateKeepSmooth(src) {
  const anchor = '            smoothRms = 0;\n';
  assert.ok(src.includes(anchor), '变异锚点须存在（校准清平滑）');
  return src.replace(anchor, '');
}

test('OVB-VAD-V01 变异自证·正例必红：退回「无自愈」⇒ F2 判据必须失败', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.05 }, { frames: 100, rms: 0.05 }, { frames: 300, rms: 0.001 },
  ]));
  const bridge = loadMutantBridge(env, mutateNoSelfHeal);
  bridge.install();
  const r = await driveVad(env, bridge);
  const wouldPass = (r.clicks === 1);
  assert.equal(wouldPass, false, '退回无自愈后 F2（校准含语音）判据必须为红 —— 若仍绿说明判据没牙');
});

test('OVB-VAD-V02 变异自证·负控必绿：同一变异下 F1 低电平判据仍须通过', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.001 }, { frames: 100, rms: 0.02 }, { frames: 300, rms: 0.001 },
  ]));
  const bridge = loadMutantBridge(env, mutateNoSelfHeal);
  bridge.install();
  const r = await driveVad(env, bridge);
  assert.equal(r.clicks, 0, '负控·低电平不得误停（与自愈无关，必须仍绿）');
});

test('OVB-VAD-V03 变异自证·正例必红：退回「不清平滑」⇒ N1 误停判据必须失败', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  installGenFrames(env, stageGen([
    { frames: 5, rms: 0.05 }, { frames: 400, rms: 0.002 },
  ]));
  const bridge = loadMutantBridge(env, mutateKeepSmooth);
  bridge.install();
  const r = await driveVad(env, bridge);
  const wouldPass = (r.clicks === 0);
  assert.equal(wouldPass, false, '退回不清平滑后 N1（校准含噪但未说话）必须**误停** ⇒ 证明该判据有牙');
});

// ═══════════════════════════════════════════════════════════════════════════════
// SW-1（2026-10-15 接线批）：`vad.enabled` 开关必须**真的约束运行期行为**
// ═══════════════════════════════════════════════════════════════════════════════
// 病（上批报出）：`voice-section.js` 写 `vad.enabled` **8 处**，`official-bridge.js` **引用 0 处**
//   ⇒ 用户关掉「静音监测」，VAD **照跑**、仍会派发点击官方停止 = **用户可见的开关说了假话**
//   （属「让失败不可观测」类，CHG-065 同族）⇒ 必须修。
// 本组判据（逐条有牙）：
//   SW-01 关 ⇒ **不启动 VAD**（不建 AudioContext、不挂 interval、不自动停）+ 读数可判
//   SW-02 开 ⇒ 行为与改前一致（**负控**：静音达标照常派发点击官方停止）
//   SW-03 关「静音监测」**不得**连带关「自动增强」（两者语义独立）
//   SW-04 缺 `vad` / 缺 `enabled` ⇒ 视为**开**（不改动未配置用户语义）
//   SW-05 会话**中途**关掉 ⇒ 当帧起不再派发（开关对整场为真，不只启动那一刻）
//   SW-06 诊断可见：`vadEnabled`/`vadSkipped` 进快照，分支能区分「已关闭」与「已开启未触发」
//   SW-V01/V02 变异自证（退回接线 ⇒ SW-01 必红；同变异下 SW-02 负控必绿）
test('OVB-SW01 开关关（vad.enabled:false）⇒ 不启动 VAD、不自动停，且读数可判', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env, { vad: { enabled: false, silenceMs: 2000 }, autoEnhance: true, hotkey: {}, refine: {} });
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
  await flush();
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  // 夹具默认脚本：校准 5 帧 + 1 帧语音 + 20 帧静音 ⇒ 开着时**必然**达标自动停
  runVad(env);
  const snap = bridge.snapshot();
  assert.equal(env.acCreated(), 0, '开关关闭 ⇒ **不得**创建 AudioContext（不观测）');
  assert.equal(env.timers.length, 0, '开关关闭 ⇒ **不得**挂 VAD 轮询');
  assert.equal(env.stopButton.clicks, 0, '开关关闭 ⇒ **不得**自动停（不得派发点击官方停止）');
  assert.equal(snap.vadEnabled, false, '快照须如实报「开关关」（不得静默）');
  assert.equal(snap.vadSkipped, 1, '须留下「因开关关闭而未启动 VAD」的计数（开关真的约束了行为的证据）');
  assert.equal(snap.abandonReason, '', '按意图关闭**不是**降级 ⇒ 不得写 abandonReason');
});

test('OVB-SW02 负控：开关开（默认）⇒ 行为与改前逐字一致（静音达标照常自动停）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env, { vad: { enabled: true, silenceMs: 2000 }, autoEnhance: false, hotkey: {}, refine: {} });
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
  await flush();
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  runVad(env);
  const snap = bridge.snapshot();
  assert.equal(env.acCreated(), 1, '开关开 ⇒ 正常启动 VAD（负控：接线不得把开着的也挡掉）');
  assert.equal(env.stopButton.clicks, 1, '开关开 ⇒ 静音达标须照常派发点击官方停止（恰好 1 次）');
  assert.equal(snap.vadSkipped, 0, '开关开 ⇒ 不得计「未启动」');
  assert.equal(snap.vadEnabled, true, '快照须如实报「开关开」');
});

test('OVB-SW03 独立性：关「静音监测」**不得**连带关「自动增强」', () => {
  // 静态证明（两条配置各读各的路径，无耦合）：
  const br = decodeChunk(CHUNK);
  // 「静音监测」只在桥内被读，且只用于 VAD 启动/守卫
  assert.ok(/ovbVadEnabled\(\)/.test(br), '桥须读 vad.enabled 决定是否启动 VAD');
  // 「自动增强」的读取点仍在 hotkey.js（本批**未触碰**）——不得被 vad.enabled 影响
  const hk = decodeChunk('src/client/voice/hotkey.js');
  assert.ok(hk.includes('voiceCfgState.value.autoEnhance === true'),
    'autoEnhance 的读取点须仍在 hotkey.js（关静音监测 ≠ 关自动增强）');
  // ⚠ 只看**活代码**：桥内注释会提到 `autoEnhance`（说明「两者无关」这一契约本身），
  //   注释不是判定 ⇒ 判据须落在活代码上（与既有用例的 hkLive 做法同款）。
  const brLive = br.split('\n').filter((l) => !l.trim().startsWith('//')).join('\n');
  assert.equal(/autoEnhance/.test(brLive), false,
    '桥的**活代码**内不得出现 autoEnhance 判定（否则两开关被耦合 —— 本批只接 vad.enabled）');
});

// ⚠ SW03b：SW03 是**静态**证明（读取点不耦合）。本条补**行为**证明：
//   「静音监测关」与「自动增强开」同时成立时，自动增强**仍须照常触发** ——
//   否则用户关掉一个开关会静默丢掉另一个功能（连带关闭 = 开关说假话的另一种形态）。
test('OVB-SW03b 行为独立性：静音监测关 + 自动增强开 ⇒ 自动增强仍须触发（不得连带关闭）', () => {
  const env = makeFakeEnv({ recordingPhase: true });
  // 桥读到「静音监测关」；热键组件的 config 桩保持 autoEnhance = true
  const bridge = loadBridge(env, { vad: { enabled: false, silenceMs: 2000 }, autoEnhance: true, hotkey: {}, refine: {} });
  bridge.install();
  const host = buildHotkeyHost(env, bridge, { autoEnhance: true, sessionId: 'sess-sw03b' });
  host.render('');
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();      // 官方会话开始（桥不启 VAD，但照记相位）
  env.document._attr = null; mo.cb();             // 会话结束 ⇒ 自动增强装臂
  host.render('官方识别出来的文字');               // 写回落地
  for (const r of host.timerRegs) { if (!r.cleared) r.fn(); }
  assert.equal(host.enhanceCalls.length, 1,
    '静音监测关**不得**连带关自动增强 —— 写回落地后仍须恰好触发 1 次增强');
  assert.equal(bridge.snapshot().vadEnabled, false, '前置：静音监测确为关');
});

// ⚠ SW01b：「按意图关闭」**不得**被误报成「未观测到官方采集（自动停未生效）」。
//   桥的包装器调用计数（callCount）与开关**无关**，且是 missed 判据的基元 ⇒
//   必须在跳过 VAD 的同时**照记**计数，否则用户关掉开关后会看到一句错误的失效告警。
test('OVB-SW01b 关闭态不得误报 missed：跳过 VAD 但包装计数照记 ⇒ sessionsMissed 保持 0', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const bridge = loadBridge(env, { vad: { enabled: false, silenceMs: 2000 }, autoEnhance: false, hotkey: {}, refine: {} });
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: {}, video: false });
  await flush();
  const mo = env.observerInstances[env.observerInstances.length - 1];
  env.document._attr = 'recording'; mo.cb();     // 会话开始
  env.document._attr = null; mo.cb();            // 会话收口（missed 判定点）
  const snap = bridge.snapshot();
  assert.equal(snap.sessionsStarted, 1, '官方会话须照常被观测到（开关只管 VAD）');
  assert.equal(snap.sessionsMissed, 0, '⚠ 包装器确被调用过 ⇒ 不得计 missed（否则关闭态会显示错误的失效告警）');
  assert.equal(snap.vadSkipped, 1, '须留下「因开关未启动 VAD」的计数');
  assert.equal(snap.abandonReason, '', '关闭不是降级 ⇒ 不得写 abandonReason');
});

test('OVB-SW04 缺配置 ⇒ 视为开（不改动未配置用户语义）', async () => {
  for (const cfg of [
    { autoEnhance: false },                                  // 缺 vad 段
    { vad: { silenceMs: 2000 }, autoEnhance: false },        // 缺 enabled 字段
    { vad: {}, autoEnhance: false },                         // vad 空对象
  ]) {
    const env = makeFakeEnv({ recordingPhase: true });
    const bridge = loadBridge(env, cfg);
    bridge.install();
    await env.navigator.mediaDevices.getUserMedia({ audio: {}, video: false });
    await flush();
    env.document._attr = 'recording';
    const mo = env.observerInstances[env.observerInstances.length - 1];
    mo.cb();
    runVad(env);
    assert.equal(bridge.snapshot().vadEnabled, true,
      '缺配置必须视为**开**（配置形态 ' + JSON.stringify(cfg) + '）—— 不得把未配置用户静默关掉');
    assert.equal(env.stopButton.clicks, 1, '缺配置 ⇒ 与改前一致地自动停');
  }
});

test('OVB-SW05 中途关开关：会话进行中改配置 ⇒ 当帧起不再派发（开关对整场为真）', async () => {
  const env = makeFakeEnv({ recordingPhase: true });
  const cfg = { vad: { enabled: true, silenceMs: 2000 }, autoEnhance: false, hotkey: {}, refine: {} };
  const bridge = loadBridge(env, cfg);
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: {}, video: false });
  await flush();
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  // ⚠ 有界驱动（与 runVad 同款上限）：VAD 的 interval **不会**因停止而 cleared
  //   （`stopped=true` 后 tick 直接 return）⇒ 无界 while 会永久空转（本席首版即栽在此处）。
  const pump = (n) => { let t = 0; for (const rec of env.timers) { if (rec.cleared) continue; while (!rec.cleared && t < n) { rec.fn(); t++; } } return t; };
  pump(3);                                     // 先跑少量帧（未达静音阈值）
  cfg.vad.enabled = false;                     // 用户**中途**关掉开关
  pump(200);                                   // 再跑满：若守卫失效，静音必然达标 ⇒ stopClicks 会 >0
  pump(200);                                   // 再多跑一轮，确保「达标」有充分机会发生
  assert.equal(env.stopButton.clicks, 0,
    '会话中途关掉开关 ⇒ 此后不得再派发自动停（否则开关只说半场真话）');
});

test('OVB-SW06 诊断可见：开关态进快照且分支可区分「已关闭」与「已开启未触发」', () => {
  const vs = decodeChunk('src/client/voice/voice-section.js');
  const i18n = decodeChunk('src/client/i18n.js');
  // 独立 i18n 键（前缀刻意避开被既有判据锁数的 voiceOfficial*/voiceVad*）
  assert.ok(i18n.includes("voiceSilenceOff:"), 'i18n 缺「静音监测已关闭」键');
  assert.ok(vs.includes("t('voiceSilenceOff')"), '诊断分支缺「已关闭」分支引用');
  assert.ok(vs.includes('snap.vadEnabled === false'), '该分支须以**开关真值**为判据（严格 ===）');
  // 与「已开启但未触发」可区分：后者不得命中「已关闭」分支
  assert.ok(vs.includes("t('voiceOfficialArmed')"), '「已开启但未触发」分支须仍在（armed）');
  // ⚠ 位置纪律（本席自查修正）：开关态必须排在**所有失效/异常分支之后** ——
  //   否则用户一旦关掉开关，`abandonReason`/`startMissed`/`endedInFeedback`/`sessionsMissed`
  //   这些**真实故障会被永久掩蔽**（实测命中：关掉开关后「热键启动失败」也显示成「静音监测已关闭」，
  //   用户会误以为是自己设置导致，实则热键坏了）= 正是本批要消灭的「让失败不可观测」类。
  const iSilenceOff = vs.indexOf("t('voiceSilenceOff')");
  for (const [k, ind] of [
    ['voiceOfficialAbandon', "t('voiceOfficialAbandon')"],
    ['voiceOfficialStartMissed', "t('voiceOfficialStartMissed')"],
    ['voiceOfficialFeedback', "t('voiceOfficialFeedback')"],
    ['voiceOfficialMissed', "t('voiceOfficialMissed')"],
  ]) {
    const idx = vs.indexOf(ind);
    assert.ok(idx > 0 && iSilenceOff > idx,
      '「已关闭」分支须排在失效分支 ' + k + ' **之后**（否则该故障会被开关态掩蔽）');
  }
  // 但必须排在**正常/瞬态**分支之前（「开关关没关」是用户此刻的疑问 ⇒ 优先作答）
  for (const [k, ind] of [
    ['voiceOfficialActive', "t('voiceOfficialActive')"],
    ['voiceOfficialArmed', "t('voiceOfficialArmed')"],
  ]) {
    const idx = vs.indexOf(ind);
    assert.ok(idx > 0 && iSilenceOff < idx,
      '「已关闭」分支须排在正常分支 ' + k + ' **之前**（否则关了开关仍显示「已就绪/采集进行中」）');
  }
  // title 暴露开关真值与「未启动」计数（可判别）
  assert.ok(vs.includes("'vadOn='"), '诊断 title 缺开关真值');
  assert.ok(vs.includes("'vadSkipped='"), '诊断 title 缺「因开关未启动 VAD」的计数');
  const br = decodeChunk(CHUNK);
  assert.ok(br.includes('vadEnabled: ovbVadEnabled()'), '快照须暴露开关当前真值');
  assert.ok(br.includes('b.vadSkipped = (b.vadSkipped || 0) + 1'), '快照须暴露「未启动」计数');
});

// ── 变异自证：把接线退回（仅内存副本）⇒ SW-01 必红，SW-02 负控必绿 ──────────────
// 变异名运行时拼接（不在源码里形成字面量）。
function mutateUnwire(src) {
  const anchor = 'if (!ovb' + 'VadEnabled()) {';
  assert.ok(src.includes(anchor), '变异锚点须存在（接线分支）');
  return src.replace(anchor, 'if (false) {');
}

async function runSwitchScenario(cfg, mutate) {
  const env = makeFakeEnv({ recordingPhase: true });
  const src = mutate ? mutate(decodeChunk(CHUNK)) : decodeChunk(CHUNK);
  const S = loadStateForBridge(env);
  S.voiceCfgState.value = cfg;
  const factory = new Function(
    'window', 'document', 'navigator', 'localStorage', 'setInterval', 'clearInterval', 'MutationObserver', 'MouseEvent',
    'vadSilenceMsOf', 'vadRequiredQuiet', 'voiceCfgState', src + '\n;return officialVoiceBridge;');
  let seq = 0;
  const bridge = factory(env.window, env.document, env.navigator, env.localStorage,
    (fn, ms) => { const rec = { fn, ms, cleared: false, id: ++seq }; env.timers.push(rec); return rec.id; },
    (id) => { const rec = env.timers.find((r) => r.id === id); if (rec) rec.cleared = true; },
    class FakeMO { constructor(cb) { this.cb = cb; env.observerInstances.push(this); } observe() {} disconnect() {} },
    function MouseEvent(type, init) { return { type, init }; },
    S.vadSilenceMsOf, S.vadRequiredQuiet, S.voiceCfgState);
  bridge.setTimer(env.timerSvc);
  bridge.install();
  await env.navigator.mediaDevices.getUserMedia({ audio: {}, video: false });
  await flush();
  env.document._attr = 'recording';
  const mo = env.observerInstances[env.observerInstances.length - 1];
  mo.cb();
  runVad(env);
  return { env, snap: bridge.snapshot() };
}

test('OVB-SW-V01 变异自证·正例必红：退回接线 ⇒ SW-01 判据必须失败', async () => {
  const r = await runSwitchScenario({ vad: { enabled: false, silenceMs: 2000 }, autoEnhance: false, hotkey: {}, refine: {} }, mutateUnwire);
  const wouldPass = (r.env.acCreated() === 0 && r.env.stopButton.clicks === 0);
  assert.equal(wouldPass, false,
    '退回接线后「开关关 ⇒ 不启动 VAD」必须为红 —— 若仍绿说明判据没牙（这正是改前的缺陷形态）');
});

test('OVB-SW-V02 变异自证·负控必绿：同一变异下「开关开」路径仍须通过', async () => {
  const r = await runSwitchScenario({ vad: { enabled: true, silenceMs: 2000 }, autoEnhance: false, hotkey: {}, refine: {} }, mutateUnwire);
  assert.equal(r.env.stopButton.clicks, 1, '负控·开关开时自动停仍须发生（与接线是否在位无关）');
  assert.equal(r.env.acCreated(), 1, '负控·开关开时 VAD 仍须启动');
});
