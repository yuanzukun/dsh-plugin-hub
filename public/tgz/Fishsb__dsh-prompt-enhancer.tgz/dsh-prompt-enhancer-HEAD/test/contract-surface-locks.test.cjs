'use strict';
// 契约面收口批（2026-10-17）回归锁 —— 两个构建期 chunk 契约门**对称** + `decodeChunk` 单一事实源。
//
// 病历（本锁要防的形态）：
//   ① **契约门只存在于两半部的一半**：`build-client.mjs:83-97` 在构建期拒绝非字符串 chunk，
//      而 `build-host.mjs` **此前完全没有这道门**。两半部写**同一条**契约
//      （`module.exports = "<JSON 转义源码>"`）、用**同一种**注入
//      （`composed.replace(marker, chunk)`）⇒ 该不对称本身就是缺陷形态。
//   ② **同一契约手工多副本**：`test/**` 下曾有 **8 处** chunk 解码实现
//      （5 份 `decodeChunk` + 3 份内联/异名），**判别力不等**，实测：
//        · `test/filler.test.cjs` 那份**无守卫** ⇒ 裸 JS chunk 上抛的是
//          `TypeError: Cannot read properties of null (reading '1')` —— **不点名文件**、
//          也不是契约口径的裁决（实测复现）；
//        · `test/client-enhance-flow.test.cjs` 那份要求结尾恰为 `\n` ⇒ 在
//          `src/client/components/model-main-section.js`（以 `\r\n"` 结束）上 **NO-MATCH**。
//
// ⚠ 为什么必须单独锁：判据**存在** ≠ 判据**有牙**。门若被下一轮重构顺手删掉/改弱，
//   没有本锁则重归「只在一半有门 / 解码器各写一份」的旧状态。
// ⚠ 夹具策略与 `gate-gap-locks.test.cjs` / `dead-code-lib-gate.test.cjs` 同源（整仓副本 +
//   临时目录），**绝不碰真实工作区** —— 变异若留在真仓里会把"自证"变成"破坏"。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const ROOT = path.join(__dirname, '..');
const EXCLUDE = new Set(['.git', 'node_modules', '.dsh-worktrees', 'test-reports', 'internal']);

// ⚠ 取具名成员解构（`require()` 一个 ESM 模块拿到命名空间对象，不可直接调用 —— 实测）。
const chunkDecode = require(path.join(ROOT, 'scripts', 'lib', 'chunk-decode.mjs'));
const { decodeChunkText, chunkWrapperLiteral } = chunkDecode;

/** 整仓副本（排除 .git/node_modules/报告/治理档）。 */
function mkFixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cs-'));
  fs.cpSync(ROOT, dir, { recursive: true, filter: (src) => !EXCLUDE.has(path.basename(src)) });
  return dir;
}
function withFixture(mutate, fn) {
  const dir = mkFixture();
  try { if (mutate) mutate(dir); return fn(dir); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
const runScript = (dir, script, args = []) => {
  const p = spawnSync(process.execPath, [script, ...args], { cwd: dir, encoding: 'utf8' });
  return { code: p.status, out: String(p.stdout || '') + String(p.stderr || '') };
};
/** 把 chunk 文件改回**裸 JS**（= 本次事故的真实形态）。 */
function unwrapToBareJs(dir, rel) {
  const abs = path.join(dir, rel);
  fs.writeFileSync(abs, decodeChunkText(fs.readFileSync(abs, 'utf8'), rel), 'utf8');
}
/** 递归枚举某目录下的 chunk（与两个构建门同一口径）。 */
function listChunks(dir, relDir) {
  const out = [];
  const walk = (d) => {
    for (const ent of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, ent.name);
      if (ent.isDirectory()) { if (ent.name !== 'vendor') walk(full); continue; }
      if (ent.name.endsWith('.js')) out.push(path.relative(dir, full));
    }
  };
  walk(path.join(dir, relDir));
  return out.sort();
}

// ─────────────── ① 两个构建期门**对称** ───────────────

test('CS-01 两个构建器都从单一普通入口模块打包，且对装配图 fail-closed', () => {
  const host = fs.readFileSync(path.join(ROOT, 'scripts', 'build-host.mjs'), 'utf8');
  const client = fs.readFileSync(path.join(ROOT, 'scripts', 'build-client.mjs'), 'utf8');
  assert.match(host, /bundleModules\(\{ root, entry: 'src\/host\/app-module\.cjs' \}\)/, 'build-host 必须从单一普通模块入口打包');
  assert.match(host, /装配图不完整/, 'build-host 必须对模块图完整性 fail-closed');
  assert.match(client, /bundleModules\(\{\s*root,\s*entry: 'src\/client\/app-module\.cjs',\s*\}\)/, 'build-client 必须从单一普通模块入口打包');
  assert.match(client, /装配图不完整/, 'build-client 必须对模块图完整性 fail-closed');
});

test('CS-02 host 装配图门变异自证：入口引用缺失模块 ⇒ 必红且点名', () => {
  withFixture((dir) => {
    const p = path.join(dir, 'src', 'host', 'app-module.cjs');
    const s = fs.readFileSync(p, 'utf8');
    fs.writeFileSync(p, s.replace("require('./pure-module.cjs')", "require('./missing-module.cjs')"), 'utf8');
  }, (dir) => {
    const r = runScript(dir, path.join('scripts', 'build-host.mjs'), ['--check']);
    assert.equal(r.code, 1, '装配图缺模块必须 exit 1');
    assert.match(r.out, /无法解析相对导入|missing-module\.cjs/, '门必须给出可归因的构建裁决');
  });
});

test('CS-03 host 门覆盖面：新增未被装配的模块 ⇒ R4 必红（无硬编码）', () => {
  withFixture((dir) => {
    fs.writeFileSync(path.join(dir, 'src', 'host', 'brandnew.cjs'), "'use strict';\nmodule.exports = {};\n", 'utf8');
  }, (dir) => {
    const r = runScript(dir, path.join('scripts', 'dead-code-gate.mjs'), []);
    assert.equal(r.code, 1, '新增未装配模块必须入网（否则覆盖面是硬编码的）');
    assert.match(r.out, /brandnew\.cjs/, '必须点名新增文件（证明是装配图可达集而非固定清单）');
  });
});

test('CS-04 host 门 fail-closed：装配入口缺位 ⇒ 不得静默判绿', () => {
  withFixture((dir) => { fs.rmSync(path.join(dir, 'src', 'host', 'app-module.cjs'), { recursive: true, force: true }); }, (dir) => {
    const r = runScript(dir, path.join('scripts', 'build-host.mjs'), ['--check']);
    assert.equal(r.code, 1, '装配入口缺位必须非 0 退出（不得"没有就不判"）');
  });
});

test('CS-05 client 门：入口模块缺失 ⇒ 必红（装配图 fail-closed）', () => {
  withFixture((dir) => { fs.rmSync(path.join(dir, 'src', 'client', 'app-module.cjs')); }, (dir) => {
    const r = runScript(dir, path.join('scripts', 'build-client.mjs'), ['--check']);
    assert.equal(r.code, 1, 'client 入口缺位必须判红');
    assert.match(r.out, /无法解析相对导入|app-module\.cjs|装配图不完整/, 'client 门须给出可归因裁决');
  });
});

test('CS-06 单一事实源：test/ 面**不得**再出现任何内联 chunk 解码实现', () => {
  // ⚠ 判定前先剥注释行：本批的迁移注释里**引用**了旧正则原文（病历性说明），
  //   那是溯源信息、不是副本；只有**代码行**里的解码腿才算副本。
  // ⚠ 本文件自身豁免：CS-08/CS-09 必须**持有**旧正则才能对拍判别力（否则空转）。
  const SELF = path.basename(__filename);
  const dir = path.join(ROOT, 'test');
  const offenders = [];
  const stripCommentLines = (src) => src.split('\n')
    .filter((ln) => !/^\s*(\/\/|\*|\/\*)/.test(ln)).join('\n');
  const walk = (d) => {
    for (const ent of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, ent.name);
      if (ent.isDirectory()) { walk(full); continue; }
      if (!ent.name.endsWith('.cjs') && !ent.name.endsWith('.mjs')) continue;
      if (ent.name === SELF) continue;
      const src = stripCommentLines(fs.readFileSync(full, 'utf8'));
      // 内联解码的两种真实代码形态：
      //   ① raw.match(/module\.exports ... "([\s\S]*)"/) —— 自带包裹正则
      //   ② JSON.parse('"' + … + '"')            —— 自做 JSON 转义还原
      if (/\.match\(\s*\/module\\?\.exports/.test(src)) offenders.push(path.relative(ROOT, full) + '（自带包裹正则）');
      if (/JSON\.parse\(\s*'"'\s*\+/.test(src)) offenders.push(path.relative(ROOT, full) + '（自做 JSON 还原）');
    }
  };
  walk(dir);
  assert.deepEqual(offenders, [],
    'test/ 面不得再自带 chunk 解码副本（收敛到 scripts/lib/chunk-decode.mjs）：' + offenders.join(', '));
});

test('CS-07 共享解码器 fail-closed 且**点名声**：裸 JS / 空文件 / 无包裹 三种形态', () => {
  // 裸 JS
  assert.throws(() => decodeChunkText('var A = 1;\nfunction f() {}\n', 'SENTINEL-BARE.js'),
    (e) => e instanceof Error && e.message.includes('SENTINEL-BARE.js') && /chunk wrapper mismatch/.test(e.message),
    '裸 JS 必须抛契约错误并点名文件（旧 filler 实现抛的是不点名的 TypeError —— 实测）');
  // 空文件
  assert.throws(() => decodeChunkText('', 'SENTINEL-EMPTY.js'),
    (e) => e.message.includes('SENTINEL-EMPTY.js'), '空文件必须点名');
  // 无包裹（普通 JS 模块）
  assert.throws(() => decodeChunkText("'use strict';\nmodule.exports = { a: 1 };\n", 'SENTINEL-OBJ.js'),
    (e) => e.message.includes('SENTINEL-OBJ.js'), '对象导出必须点名');
  // 负控：合法包裹必须解出且**不抛**
  const ok = decodeChunkText('module.exports = "var x = 1;";\n', 'SENTINEL-OK.js');
  assert.equal(ok, 'var x = 1;', '合法包裹必须正确解出（负控）');
});

test('CS-08 判别力**只升不降**：旧 `client-enhance-flow` 正则的覆盖洞不得复发', () => {
  // 病历：旧变体要求结尾恰为 `\n`，在历史 chunk `model-main-section.js`
  // （以 `\r\n"` 结束）上 NO-MATCH。目标模式已退役该 chunk，故用等价合成的
  // CRLF 结尾包裹锁住同一判别洞，不再依赖已退役文件。
  const rel = path.join('src', 'client', 'components', 'CRLF-FIXTURE.js');
  const raw = 'module.exports = "var A = 1;\\r\\n\\r\\n";';
  const OLD = /module\.exports\s*=\s*"([\s\S]*)";?\s*\n$/;
  assert.equal(raw.match(OLD), null, '夹具前提：该 chunk 在旧正则下应 NO-MATCH（否则本断言空转）');
  const now = decodeChunkText(raw, rel);
  assert.equal(now, 'var A = 1;\r\n\r\n', '共享解码器必须能解出 CRLF 结尾 chunk（判别力上升的证据）');
});

test('CS-09 取值等价：共享解码器与旧实现口径在**全部** chunk 上逐字同值', () => {
  const chunks = listChunks(ROOT, path.join('src', 'client'));
  // 目标模式：host 已无字符串 chunk；client 仍是唯一 chunk 面。
  const clientChunks = listChunks(ROOT, path.join('src', 'client'));
  assert.equal(chunks.length, clientChunks.length,
    '扫描面必须等于 client 的实际 chunk 文件集（不得写死件数）');
  // 目标模式：chunk 面允许为 0（业务已全部是普通模块）；
  // 这里仍对拍 R7 的真实读数，0 必须是两侧一致的实际枚举结果。
  const OLD_LOOSE = /module\.exports\s*=\s*"([\s\S]*)";?\s*$/;
  for (const rel of chunks) {
    const raw = fs.readFileSync(path.join(ROOT, rel), 'utf8');
    const m = raw.match(OLD_LOOSE);
    assert.ok(m, rel + ' 应为包裹形态（本批不得放宽）');
    assert.equal(decodeChunkText(raw, rel), JSON.parse('"' + m[1] + '"'),
      rel + ' 共享解码器取值必须与旧实现逐字相同（本批不得改浅既有断言）');
  }
});

test('CS-10 行首锚定仍生效：头部注释里的 decoy 包裹不得把解码带偏', () => {
  // 依据：official-bridge 那份旧实现特意用行首锚定，注释里可能含代码样文本。
  const decoy = '// module.exports = "DECOY"\nconst A = 1;\nmodule.exports = "REAL";\n';
  assert.equal(decodeChunkText(decoy, 'SENTINEL-DECOY.js'), 'REAL',
    '行首锚定必须取到**真**包裹，而不是注释里的 decoy');
  assert.equal(chunkWrapperLiteral(decoy), 'REAL', '捕获组须为真包裹内容');
});

test('CS-11 负控：真实工作区不动 ⇒ 两个构建门与全部受影响测试**必绿**', () => {
  // 两门负控（真实工作区）
  for (const s of ['build-host.mjs', 'build-client.mjs']) {
    const r = runScript(ROOT, path.join('scripts', s), ['--check']);
    assert.equal(r.code, 0, s + ' --check 在未改动的真实工作区必须绿：' + r.out);
  }
  // 共享解码器在真实仓上可用（真值非空）
  const real = fs.readFileSync(path.join(ROOT, 'src', 'host', 'enhance-handlers-module.cjs'), 'utf8');
  assert.ok(real.length > 0, '真实仓的 host 注册域模块必须非空');
});

// ─────────────── ③ host 侧无门时期的历史产物是否干净（只读核） ───────────────

test('CS-12 历史产物只读核：现有 plugin-host.js **不得**含对象字符串化污染', () => {
  // 由来：`build-host.mjs` 此前无门 ⇒ 需排查"host 侧是否也曾在无门状态下构建过"。
  // 判据：产物内 `[object Object]` 出现次数 = 0（若 >0 说明曾把对象注入产物）。
  const prod = fs.readFileSync(path.join(ROOT, 'plugin-host.js'), 'utf8');
  const hits = (prod.match(/\[object Object\]/g) || []).length;
  assert.equal(hits, 0, 'plugin-host.js 不得含 [object Object]（本批只读核，未改该产物）');
  // 并且当前门上马后，产物仍可被 `lib/index.cjs` 同款方式求值
  assert.doesNotThrow(() => new Function('harness', prod), 'plugin-host.js 必须可求值（装载点同款）');
});
