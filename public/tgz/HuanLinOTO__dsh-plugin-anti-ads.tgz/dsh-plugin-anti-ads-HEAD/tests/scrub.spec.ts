// @vitest-environment jsdom

/**
 * Scrub tests: the signature matchers and the removal sweep.
 *
 * Each test builds the minimum DOM that exercises one branch of the matcher
 * — root portal, standalone child, anti-ads-protected element, false
 * positive — so a regression that loosens or tightens the signature fails
 * loudly on the case it touched rather than on a downstream side-effect.
 */
import { describe, it, expect, beforeEach } from 'vitest'
import {
  ADS_OVERLAY_Z_FLOOR,
  ADS_ROOT_Z_INDEX,
  ANTIADS_ATTR,
  hasAntiAdsAncestor,
  isAdsOverlay,
  isAdsRoot,
  isAdsChild,
  isInsideScope,
  scrubAds,
} from '../src/client/scrub.ts'

/** Make a `<div>` with the inline styles React would write for dsh-ads's root. */
function rootLike(extra: Partial<CSSStyleDeclaration> = {}): HTMLElement {
  const el = document.createElement('div')
  Object.assign(el.style, {
    position: 'fixed',
    inset: '0px',
    zIndex: String(ADS_ROOT_Z_INDEX),
    pointerEvents: 'none',
    ...extra,
  })
  return el
}

/** Make a `<div>` with the inline styles of a standalone dsh-ads placement. */
function childLike(zIndex: number): HTMLElement {
  const el = document.createElement('div')
  el.style.position = 'fixed'
  el.style.zIndex = String(zIndex)
  return el
}

/** Make a `<div>` shaped like a loose full-viewport click-through overlay. */
function overlayLike(extra: Partial<CSSStyleDeclaration> = {}): HTMLElement {
  const el = document.createElement('div')
  Object.assign(el.style, {
    position: 'fixed',
    inset: '0px',
    zIndex: String(ADS_OVERLAY_Z_FLOOR),
    pointerEvents: 'none',
    ...extra,
  })
  return el
}

beforeEach(() => {
  document.body.innerHTML = ''
})

describe('isAdsRoot', () => {
  it('matches the canonical root signature', () => {
    expect(isAdsRoot(rootLike())).toBe(true)
  })

  it('rejects a non-element', () => {
    expect(isAdsRoot(document.createTextNode('x') as unknown as Element)).toBe(false)
  })

  it('rejects a non-HTMLElement', () => {
    expect(isAdsRoot(document.createElementNS('http://www.w3.org/2000/svg', 'svg'))).toBe(false)
  })

  it('rejects when position is not fixed', () => {
    expect(isAdsRoot(rootLike({ position: 'absolute' }))).toBe(false)
  })

  it('rejects when inset is not zero', () => {
    expect(isAdsRoot(rootLike({ inset: '1px' }))).toBe(false)
  })

  it('rejects when z-index is off by one', () => {
    expect(isAdsRoot(rootLike({ zIndex: String(ADS_ROOT_Z_INDEX + 1) }))).toBe(false)
  })

  it('rejects when pointer-events is not none', () => {
    expect(isAdsRoot(rootLike({ pointerEvents: 'auto' }))).toBe(false)
  })
})

describe('isAdsChild', () => {
  it('matches a fixed element in the z-index band', () => {
    expect(isAdsChild(childLike(ADS_ROOT_Z_INDEX + 5))).toBe(true)
  })

  it('matches the band maximum', () => {
    expect(isAdsChild(childLike(2_147_483_647))).toBe(true)
  })

  it('rejects a z-index just below the band', () => {
    expect(isAdsChild(childLike(ADS_ROOT_Z_INDEX - 1))).toBe(false)
  })

  it('rejects a non-integer z-index', () => {
    const el = childLike(ADS_ROOT_Z_INDEX)
    el.style.zIndex = 'auto'
    expect(isAdsChild(el)).toBe(false)
  })

  it('rejects a non-fixed element in the band', () => {
    const el = childLike(ADS_ROOT_Z_INDEX)
    el.style.position = 'absolute'
    expect(isAdsChild(el)).toBe(false)
  })
})

describe('isAdsOverlay', () => {
  it('matches a full-viewport click-through overlay above the floor', () => {
    expect(isAdsOverlay(overlayLike())).toBe(true)
  })

  it('matches the spelled-out four-edge serialisation of inset', () => {
    const el = overlayLike()
    el.style.inset = ''
    el.style.top = '0px'
    el.style.left = '0px'
    el.style.width = '100vw'
    el.style.height = '100vh'
    expect(isAdsOverlay(el)).toBe(true)
  })

  it('rejects when pointer-events is not none', () => {
    expect(isAdsOverlay(overlayLike({ pointerEvents: 'auto' }))).toBe(false)
  })

  it('rejects a z-index below the floor', () => {
    expect(isAdsOverlay(overlayLike({ zIndex: String(ADS_OVERLAY_Z_FLOOR - 1) }))).toBe(false)
  })

  it('rejects a non-integer z-index', () => {
    const el = overlayLike()
    el.style.zIndex = 'auto'
    expect(isAdsOverlay(el)).toBe(false)
  })

  it('rejects a non-full-viewport fixed layer', () => {
    const el = overlayLike()
    el.style.inset = ''
    el.style.top = '12px'
    el.style.left = '12px'
    el.style.width = '200px'
    el.style.height = '120px'
    expect(isAdsOverlay(el)).toBe(false)
  })
})

describe('hasAntiAdsAncestor', () => {
  it('returns true for the marked element itself', () => {
    const el = document.createElement('div')
    el.setAttribute(ANTIADS_ATTR, '')
    expect(hasAntiAdsAncestor(el)).toBe(true)
  })

  it('returns true for a descendant of a marked element', () => {
    const root = document.createElement('div')
    root.setAttribute(ANTIADS_ATTR, '')
    const child = document.createElement('div')
    root.appendChild(child)
    expect(hasAntiAdsAncestor(child)).toBe(true)
  })

  it('returns false for an unmarked tree', () => {
    const el = document.createElement('div')
    expect(hasAntiAdsAncestor(el)).toBe(false)
  })
})

describe('isInsideScope', () => {
  it('returns true for the skip node itself', () => {
    const badge = document.createElement('div')
    expect(isInsideScope(badge, badge)).toBe(true)
  })

  it('returns true for a descendant of the skip node', () => {
    const badge = document.createElement('div')
    const child = document.createElement('div')
    badge.appendChild(child)
    expect(isInsideScope(child, badge)).toBe(true)
  })

  it('returns false for a sibling of the skip node', () => {
    const badge = document.createElement('div')
    const sibling = document.createElement('div')
    document.body.append(badge, sibling)
    expect(isInsideScope(sibling, badge)).toBe(false)
  })

  it('returns false when skip is null or undefined', () => {
    const el = document.createElement('div')
    expect(isInsideScope(el, null)).toBe(false)
    expect(isInsideScope(el, undefined)).toBe(false)
  })
})

describe('scrubAds', () => {
  it('removes a root portal appended to body', () => {
    const root = rootLike()
    document.body.appendChild(root)
    expect(scrubAds()).toBe(1)
    expect(root.parentElement).toBe(null)
  })

  it('removes a standalone child but not its non-fixed sibling', () => {
    const child = childLike(2_147_450_000)
    const innocent = document.createElement('div')
    innocent.style.position = 'static'
    document.body.append(child, innocent)
    expect(scrubAds()).toBe(1)
    expect(child.parentElement).toBe(null)
    expect(innocent.parentElement).toBe(document.body)
  })

  it('removes a restyled overlay root outside the exact signature', () => {
    // The root's exact match pins all four inline styles; a version that
    // serialises them differently must still be caught by shape.
    const overlay = overlayLike({ zIndex: '999999999' })
    document.body.appendChild(overlay)
    expect(scrubAds()).toBe(1)
    expect(overlay.parentElement).toBe(null)
  })

  it('does not double-count a child whose root was also removed', () => {
    const root = rootLike()
    const child = childLike(2_147_450_000)
    root.appendChild(child)
    document.body.appendChild(root)
    // The child sits inside the root; removing the root orphans it, and the
    // sweep must not count it as a second removal.
    expect(scrubAds()).toBe(1)
    expect(root.parentElement).toBe(null)
  })

  it('leaves the skip node and its descendants alone', () => {
    // The badge is identified by DOM reference, not by attribute: dsh-ads 0.2
    // copies `data-dsh-anti-ads` onto its own root, so attribute-based skip
    // would spare the ads too.
    const badge = document.createElement('div')
    badge.setAttribute(ANTIADS_ATTR, '')
    // A real dsh-ads-shaped child inside the badge — scrub must skip it.
    const nested = childLike(ADS_ROOT_Z_INDEX)
    nested.style.position = 'fixed'
    badge.appendChild(nested)
    document.body.appendChild(badge)
    expect(scrubAds(document, badge)).toBe(0)
    expect(badge.parentElement).toBe(document.body)
    expect(nested.parentElement).toBe(badge)
  })

  it('removes an ads root that carries the anti-ads honeypot attribute', () => {
    // dsh-ads 0.2 stamps `data-dsh-anti-ads` onto its own root to fool any
    // attribute-based scrub. The reference-based skip must not be fooled.
    const honeypot = rootLike()
    honeypot.setAttribute(ANTIADS_ATTR, '')
    document.body.appendChild(honeypot)
    // No skip node passed — the honeypot is not our badge.
    expect(scrubAds(document, null)).toBe(1)
    expect(honeypot.parentElement).toBe(null)
  })

  it('removes an ads root with the honeypot attribute even when a badge is present', () => {
    // The real badge and the honeypot ads root are siblings on body.
    // The scrub skips only the badge (by reference); the ads root is removed.
    const badge = document.createElement('div')
    badge.setAttribute(ANTIADS_ATTR, '')
    document.body.appendChild(badge)
    const honeypot = rootLike()
    honeypot.setAttribute(ANTIADS_ATTR, '')
    document.body.appendChild(honeypot)
    expect(scrubAds(document, badge)).toBe(1)
    expect(badge.parentElement).toBe(document.body)
    expect(honeypot.parentElement).toBe(null)
  })

  it('returns zero on an empty document', () => {
    expect(scrubAds()).toBe(0)
  })

  it('scopes to the given root', () => {
    const container = document.createElement('div')
    const root = rootLike()
    container.appendChild(root)
    document.body.appendChild(container)
    expect(scrubAds(container)).toBe(1)
    expect(root.parentElement).toBe(null)
    expect(container.parentElement).toBe(document.body)
  })
})
