// @vitest-environment jsdom

/**
 * Client tests: the four defences assembled in the layer.
 *
 * Rendering the real component against a real jsdom document, not mocking
 * React: the write-through, the observer, the fetch patch, and the retire
 * broadcast each get one test that proves the defence acts on the live
 * DOM/storage surface it would in a session.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import React from 'react'
import { act } from 'react-dom/test-utils'
import { createRoot } from 'react-dom/client'
import { AntiAdLayer, REGISTRY_ROUTE } from '../src/client/AntiAdLayer.tsx'
import {
  ADS_CHANGED_EVENT,
  ADS_RETIRED_EVENT,
  ADS_SETTINGS_DETAIL,
  ADS_SETTINGS_KEY,
  ADS_ALL_OFF,
  resetRetireToken,
  hasRetireToken,
} from '../src/client/settings.ts'
import { scrubAds, ANTIADS_ATTR } from '../src/client/scrub.ts'
import { clearPersisted } from '../src/client/persist.ts'

/** Build a fake dsh-ads portal root, exactly as its AdLayer would. */
function adsPortal(opts: { honeypot?: boolean } = {}): HTMLElement {
  const el = document.createElement('div')
  Object.assign(el.style, {
    position: 'fixed',
    inset: '0px',
    zIndex: '2147400000',
    pointerEvents: 'none',
  })
  // dsh-ads 0.2 stamps `data-dsh-anti-ads` onto its own root as a honeypot.
  if (opts.honeypot) el.setAttribute(ANTIADS_ATTR, '')
  document.body.appendChild(el)
  return el
}

beforeEach(() => {
  localStorage.clear()
  clearPersisted()
  resetRetireToken()
})

afterEach(() => {
  document.body.innerHTML = ''
  vi.restoreAllMocks()
})

describe('AntiAdLayer', () => {
  it('writes dsh-ads settings all-off on mount', () => {
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const stored = JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string)
    expect(stored).toEqual(ADS_ALL_OFF)
    act(() => reactRoot.unmount())
  })

  it('re-broadcasts suppression when dsh-ads settings come back on', () => {
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    // Simulate dsh-ads writing its own defaults back.
    localStorage.setItem(ADS_SETTINGS_KEY, JSON.stringify({ ...ADS_ALL_OFF, gutter: true }))
    dispatchEvent(new CustomEvent(ADS_CHANGED_EVENT, { detail: ADS_SETTINGS_DETAIL }))
    expect(JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string)).toEqual(ADS_ALL_OFF)
    act(() => reactRoot.unmount())
  })

  it('scrubs a dsh-ads portal that appears after mount', async () => {
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const portal = adsPortal()
    // The observer fires on a microtask; give it a tick.
    await vi.waitFor(() => {
      expect(portal.parentElement).toBe(null)
    })
    act(() => reactRoot.unmount())
  })

  it('answers the registry route with an empty list', async () => {
    // jsdom's window has no fetch of its own; hand it Node's so the patch
    // has something to stand in front of.
    window.fetch = fetch
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const response = await window.fetch(REGISTRY_ROUTE)
    const payload = await response.json() as { plugins: unknown[] }
    expect(payload.plugins).toEqual([])
    act(() => reactRoot.unmount())
  })

  it('still blocks the registry route when a cache-buster is appended', async () => {
    // dsh-ads's client (or the shell's asset layer) could request the route
    // with a query string; the block must match on the path, not the whole
    // href, or the query would dodge it.
    window.fetch = fetch
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const response = await window.fetch(`${REGISTRY_ROUTE}?v=${Date.now()}`)
    const payload = await response.json() as { plugins: unknown[] }
    expect(payload.plugins).toEqual([])
    act(() => reactRoot.unmount())
  })

  it('lets unrelated fetches through', async () => {
    const mock = vi.fn(() => Promise.resolve(new Response('ok')))
    window.fetch = mock
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const response = await window.fetch('/other')
    expect(response.status).toBe(200)
    expect(mock).toHaveBeenCalledWith('/other', undefined)
    act(() => reactRoot.unmount())
  })

  it('broadcasts dsh-ads\'s retire event on mount', () => {
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    // L4: dsh-ads's whole layer checks this flag before rendering anything,
    // so one broadcast on mount retires it for the page load.
    expect(listener).toHaveBeenCalledTimes(1)
    act(() => reactRoot.unmount())
  })

  it('re-broadcasts retire when dsh-ads settings come back on', () => {
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    expect(listener).toHaveBeenCalledTimes(1)
    localStorage.setItem(ADS_SETTINGS_KEY, JSON.stringify({ ...ADS_ALL_OFF, gutter: true }))
    dispatchEvent(new CustomEvent(ADS_CHANGED_EVENT, { detail: ADS_SETTINGS_DETAIL }))
    expect(listener).toHaveBeenCalledTimes(2)
    act(() => reactRoot.unmount())
  })

  it('does not broadcast retire when the deep switch is off', () => {
    localStorage.setItem('dsh-anti-ads:settings', JSON.stringify({ enabled: true, aggressive: true, blockDynamic: true, deep: false }))
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    expect(listener).not.toHaveBeenCalled()
    // The write-through still runs: only the broadcast is gated off.
    expect(JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string)).toEqual(ADS_ALL_OFF)
    act(() => reactRoot.unmount())
  })

  it('auto-clicks dsh-ads\'s retire button to capture the Token', async () => {
    // dsh-ads 0.2 stamps its retire event with a module-private Symbol.
    // The Token is only available when retireAds() runs — i.e. when the
    // "关闭所有广告" button is pressed. The badge's L4 observer auto-clicks
    // that button the moment it appears, capturing the Token and retiring
    // the layer through dsh-ads's own code path.
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    expect(hasRetireToken()).toBe(false)
    // Simulate dsh-ads's retire button appearing (e.g. settings dialog opens).
    const retireBtn = document.createElement('button')
    retireBtn.type = 'button'
    retireBtn.textContent = '立刻关闭所有广告（刷新后恢复）'
    const onClick = vi.fn(() => {
      // Simulate retireAds dispatching the event with a real Symbol Token.
      // The CustomEvent patch in settings.ts captures it.
      dispatchEvent(new CustomEvent(ADS_RETIRED_EVENT, { detail: Symbol('dsh-ads:retired') }))
    })
    retireBtn.addEventListener('click', onClick)
    document.body.appendChild(retireBtn)
    // The L4 observer should click the button, which captures the Token.
    await vi.waitFor(() => {
      expect(onClick).toHaveBeenCalledTimes(1)
    })
    expect(hasRetireToken()).toBe(true)
    act(() => reactRoot.unmount())
  })

  it('does not auto-click the retire button when deep is off', async () => {
    localStorage.setItem('dsh-anti-ads:settings', JSON.stringify({ enabled: true, aggressive: true, blockDynamic: true, deep: false }))
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const retireBtn = document.createElement('button')
    retireBtn.type = 'button'
    retireBtn.textContent = '立刻关闭所有广告（刷新后恢复）'
    const onClick = vi.fn()
    retireBtn.addEventListener('click', onClick)
    document.body.appendChild(retireBtn)
    // Give the observer a tick to prove it did not fire.
    await new Promise((r) => setTimeout(r, 50))
    expect(onClick).not.toHaveBeenCalled()
    expect(hasRetireToken()).toBe(false)
    act(() => reactRoot.unmount())
  })

  it('stops auto-clicking once the Token is captured', async () => {
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    // First retire button: clicked, Token captured.
    const btn1 = document.createElement('button')
    btn1.type = 'button'
    btn1.textContent = '立刻关闭所有广告（刷新后恢复）'
    const click1 = vi.fn(() => {
      dispatchEvent(new CustomEvent(ADS_RETIRED_EVENT, { detail: Symbol('dsh-ads:retired') }))
    })
    btn1.addEventListener('click', click1)
    document.body.appendChild(btn1)
    await vi.waitFor(() => {
      expect(click1).toHaveBeenCalledTimes(1)
    })
    expect(hasRetireToken()).toBe(true)
    // Second retire button: NOT clicked — the observer stops once the
    // Token is in hand.
    const btn2 = document.createElement('button')
    btn2.type = 'button'
    btn2.textContent = '关闭所有广告'
    const click2 = vi.fn()
    btn2.addEventListener('click', click2)
    document.body.appendChild(btn2)
    await new Promise((r) => setTimeout(r, 50))
    expect(click2).not.toHaveBeenCalled()
    act(() => reactRoot.unmount())
  })

  it('marks its own portal and is not removed by the scrub', () => {
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const badge = document.querySelector<HTMLElement>(`[${ANTIADS_ATTR}]`)
    expect(badge).not.toBeNull()
    // Scrubbing with the badge as skip must not remove the badge itself.
    // The scrub identifies the badge by DOM reference, not by attribute.
    expect(scrubAds(document, badge)).toBe(0)
    expect(badge?.parentElement).toBe(document.body)
    act(() => reactRoot.unmount())
  })

  it('scrubs a dsh-ads portal that carries the honeypot attribute', async () => {
    // dsh-ads 0.2 stamps `data-dsh-anti-ads` onto its own root to fool any
    // attribute-based scrub. The reference-based skip must not be fooled.
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    const portal = adsPortal({ honeypot: true })
    await vi.waitFor(() => {
      expect(portal.parentElement).toBe(null)
    })
    act(() => reactRoot.unmount())
  })

  it('renders nothing and stops guarding when disabled', () => {
    // Persist the disabled state first, then mount.
    localStorage.setItem('dsh-anti-ads:settings', JSON.stringify({ enabled: false, aggressive: true, blockDynamic: true }))
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    expect(document.querySelector(`[${ANTIADS_ATTR}]`)).toBeNull()
    // No write-through happens: dsh-ads's settings are left alone.
    expect(localStorage.getItem(ADS_SETTINGS_KEY)).toBeNull()
    act(() => reactRoot.unmount())
  })

  it('restores dsh-ads defaults when the master switch is turned off', () => {
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(AntiAdLayer)))
    // Click the badge chip (the role=button div inside the marked container),
    // then the master switch row (the first button inside the panel).
    const chip = document.querySelector<HTMLElement>(`[${ANTIADS_ATTR}] > div[role="button"]`) as HTMLElement
    act(() => { chip.click() })
    const rows = document.querySelectorAll<HTMLButtonElement>('button[type="button"]')
    act(() => { rows[0]?.click() })
    const stored = JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string)
    expect(stored.gutter).toBe(true)
    expect(stored.poster).toBe(true)
    expect(stored.muted).toBe(false)
    act(() => reactRoot.unmount())
  })
})
