// @vitest-environment jsdom

/**
 * Settings tests: the write-through contract against dsh-ads's persistence.
 *
 * The core assertions are about *protocol*, not implementation: the storage
 * key, the broadcast event name and detail, and the loop-breaker all have to
 * match what dsh-ads's client actually listens for. Anything that loosens
 * that contract here fails against these tests rather than silently breaking
 * in a real session.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import React from 'react'
import { act } from 'react-dom/test-utils'
import { createRoot } from 'react-dom/client'
import {
  ADS_ALL_OFF,
  ADS_CHANGED_EVENT,
  ADS_RETIRED_EVENT,
  ADS_SETTINGS_DETAIL,
  ADS_SETTINGS_KEY,
  adsSettingsAreOff,
  broadcastAdsRetired,
  getRetireToken,
  hasRetireToken,
  resetRetireToken,
  writeAdsSettingsOff,
  useAdsGuard,
  useAntiAdsSettings,
  DEFAULT_ANTI_ADS_SETTINGS,
  type AntiAdsSettings,
} from '../src/client/settings.ts'
import { clearPersisted } from '../src/client/persist.ts'

/** A full dsh-ads settings object with one placement on. */
function partiallyOn(): Record<string, unknown> {
  return { ...ADS_ALL_OFF, gutter: true }
}

beforeEach(() => {
  localStorage.clear()
  clearPersisted()
  resetRetireToken()
})

afterEach(() => {
  vi.restoreAllMocks()
})

describe('ADS_ALL_OFF', () => {
  it('has every placement switch off and sound muted', () => {
    expect(ADS_ALL_OFF.gutter).toBe(false)
    expect(ADS_ALL_OFF.feed).toBe(false)
    expect(ADS_ALL_OFF.popup).toBe(false)
    expect(ADS_ALL_OFF.speed).toBe(false)
    expect(ADS_ALL_OFF.scare).toBe(false)
    expect(ADS_ALL_OFF.poster).toBe(false)
    expect(ADS_ALL_OFF.muted).toBe(true)
  })
})

describe('adsSettingsAreOff', () => {
  it('is true for the all-off object', () => {
    expect(adsSettingsAreOff(ADS_ALL_OFF)).toBe(true)
  })

  it('is false when any placement is on', () => {
    expect(adsSettingsAreOff(partiallyOn())).toBe(false)
  })

  it('is false for null and non-objects', () => {
    expect(adsSettingsAreOff(null)).toBe(false)
    expect(adsSettingsAreOff(undefined)).toBe(false)
    expect(adsSettingsAreOff('[]')).toBe(false)
  })

  it('is false for a partial object missing keys', () => {
    expect(adsSettingsAreOff({ gutter: false })).toBe(false)
  })
})

describe('writeAdsSettingsOff', () => {
  it('writes the all-off object to dsh-ads\'s storage key', () => {
    writeAdsSettingsOff()
    const stored = localStorage.getItem(ADS_SETTINGS_KEY)
    expect(stored).not.toBeNull()
    expect(adsSettingsAreOff(JSON.parse(stored as string))).toBe(true)
  })

  it('broadcasts dsh-ads\'s event with its settings detail', () => {
    const listener = vi.fn()
    addEventListener(ADS_CHANGED_EVENT, listener)
    writeAdsSettingsOff()
    expect(listener).toHaveBeenCalledTimes(1)
    const event = listener.mock.calls[0]?.[0] as CustomEvent<string>
    expect(event.detail).toBe(ADS_SETTINGS_DETAIL)
  })

  it('overwrites a partially-on stored object', () => {
    localStorage.setItem(ADS_SETTINGS_KEY, JSON.stringify(partiallyOn()))
    writeAdsSettingsOff()
    expect(adsSettingsAreOff(JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string))).toBe(true)
  })

  it('tolerates unwritable storage but still broadcasts', () => {
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new Error('quota')
    })
    const listener = vi.fn()
    addEventListener(ADS_CHANGED_EVENT, listener)
    expect(() => writeAdsSettingsOff()).not.toThrow()
    expect(listener).toHaveBeenCalledTimes(1)
  })
})

describe('broadcastAdsRetired', () => {
  it('dispatches dsh-ads\'s retire event', () => {
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    broadcastAdsRetired()
    expect(listener).toHaveBeenCalledTimes(1)
    // The contract is the event name: dsh-ads's `useRetired` listens on
    // `dsh-ads:retired` and reads nothing else off the event.
    const event = listener.mock.calls[0]?.[0] as CustomEvent<unknown>
    expect(event.type).toBe(ADS_RETIRED_EVENT)
  })

  it('dispatches without detail when no Token has been captured', () => {
    // Before dsh-ads's own retireAds() has run, the Token is unknown and the
    // broadcast is a bare event — dsh-ads 0.2's listener will ignore it, but
    // it costs nothing and keeps the semantic for older dsh-ads.
    expect(hasRetireToken()).toBe(false)
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    broadcastAdsRetired()
    const event = listener.mock.calls[0]?.[0] as CustomEvent<unknown>
    // CustomEvent.detail defaults to null (not undefined) per the DOM spec
    // when no detail is provided. dsh-ads's listener checks `!== TOKEN`, so
    // null is rejected just as undefined would be.
    expect(event.detail).toBeNull()
  })

  it('dispatches with the captured Token when one is available', () => {
    // Simulate dsh-ads's own retireAds(): create a CustomEvent with a Symbol
    // detail. The CustomEvent patch in settings.ts captures the Symbol.
    const token = Symbol('dsh-ads:retired')
    new CustomEvent(ADS_RETIRED_EVENT, { detail: token })
    expect(hasRetireToken()).toBe(true)
    expect(getRetireToken()).toBe(token)
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    broadcastAdsRetired()
    const event = listener.mock.calls[0]?.[0] as CustomEvent<unknown>
    // The dispatched event carries the exact Symbol reference — the one
    // dsh-ads's `useRetired` listener checks against its own TOKEN.
    expect(event.detail).toBe(token)
  })
})

describe('retire Token capture', () => {
  it('captures the Token from a real dsh-ads:retired CustomEvent', () => {
    const token = Symbol('dsh-ads:retired')
    new CustomEvent(ADS_RETIRED_EVENT, { detail: token })
    expect(hasRetireToken()).toBe(true)
    expect(getRetireToken()).toBe(token)
  })

  it('does not capture from events of other types', () => {
    const token = Symbol('other')
    new CustomEvent('some-other-event', { detail: token })
    expect(hasRetireToken()).toBe(false)
  })

  it('does not capture from a retire event with a non-Symbol detail', () => {
    new CustomEvent(ADS_RETIRED_EVENT, { detail: 'not-a-symbol' })
    expect(hasRetireToken()).toBe(false)
  })

  it('does not capture from a retire event with no detail', () => {
    new CustomEvent(ADS_RETIRED_EVENT)
    expect(hasRetireToken()).toBe(false)
  })

  it('keeps the first Token when multiple are seen', () => {
    const first = Symbol('dsh-ads:retired')
    const second = Symbol('dsh-ads:retired')
    new CustomEvent(ADS_RETIRED_EVENT, { detail: first })
    new CustomEvent(ADS_RETIRED_EVENT, { detail: second })
    expect(getRetireToken()).toBe(first)
  })
})

describe('useAntiAdsSettings', () => {
  it('defaults to everything on', () => {
    const settings = { ...DEFAULT_ANTI_ADS_SETTINGS } as AntiAdsSettings
    expect(settings.enabled).toBe(true)
    expect(settings.aggressive).toBe(true)
    expect(settings.blockDynamic).toBe(true)
    expect(settings.deep).toBe(true)
  })
})

describe('useAdsGuard', () => {
  it('writes all-off once on mount when enabled', () => {
    function Harness() {
      useAdsGuard(true, true)
      return null
    }
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(Harness)))
    expect(adsSettingsAreOff(JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string))).toBe(true)
    act(() => reactRoot.unmount())
  })

  it('broadcasts the retire event once on mount when deep is on', () => {
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    function Harness() {
      useAdsGuard(true, true)
      return null
    }
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(Harness)))
    expect(listener).toHaveBeenCalledTimes(1)
    act(() => reactRoot.unmount())
  })

  it('does not broadcast the retire event when deep is off', () => {
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    function Harness() {
      useAdsGuard(true, false)
      return null
    }
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(Harness)))
    expect(listener).not.toHaveBeenCalled()
    act(() => reactRoot.unmount())
  })

  it('re-suppresses when dsh-ads settings come back on', () => {
    let changed = false
    addEventListener(ADS_CHANGED_EVENT, () => { changed = true })
    function Harness() {
      useAdsGuard(true, true)
      return null
    }
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(Harness)))
    // Simulate dsh-ads's own store: write an on-state and broadcast.
    localStorage.setItem(ADS_SETTINGS_KEY, JSON.stringify(partiallyOn()))
    dispatchEvent(new CustomEvent(ADS_CHANGED_EVENT, { detail: ADS_SETTINGS_DETAIL }))
    expect(adsSettingsAreOff(JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string))).toBe(true)
    expect(changed).toBe(true)
    act(() => reactRoot.unmount())
  })

  it('re-broadcasts the retire event when settings come back on and deep is on', () => {
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    function Harness() {
      useAdsGuard(true, true)
      return null
    }
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(Harness)))
    expect(listener).toHaveBeenCalledTimes(1)
    localStorage.setItem(ADS_SETTINGS_KEY, JSON.stringify(partiallyOn()))
    dispatchEvent(new CustomEvent(ADS_CHANGED_EVENT, { detail: ADS_SETTINGS_DETAIL }))
    // One on mount, one on the re-arm.
    expect(listener).toHaveBeenCalledTimes(2)
    act(() => reactRoot.unmount())
  })

  it('does not re-broadcast retire when deep is off but settings come back on', () => {
    const listener = vi.fn()
    addEventListener(ADS_RETIRED_EVENT, listener)
    function Harness() {
      useAdsGuard(true, false)
      return null
    }
    const root = document.createElement('div')
    document.body.appendChild(root)
    const reactRoot = createRoot(root)
    act(() => reactRoot.render(React.createElement(Harness)))
    localStorage.setItem(ADS_SETTINGS_KEY, JSON.stringify(partiallyOn()))
    dispatchEvent(new CustomEvent(ADS_CHANGED_EVENT, { detail: ADS_SETTINGS_DETAIL }))
    // The write-through still re-arms; only the broadcast is gated off.
    expect(adsSettingsAreOff(JSON.parse(localStorage.getItem(ADS_SETTINGS_KEY) as string))).toBe(true)
    expect(listener).not.toHaveBeenCalled()
    act(() => reactRoot.unmount())
  })
})
