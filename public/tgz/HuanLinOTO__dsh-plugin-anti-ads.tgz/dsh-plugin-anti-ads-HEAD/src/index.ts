/**
 * dsh-anti-ads, node half.
 *
 * A stub. Every defence this plugin performs — settings write-through, DOM
 * scrub, fetch short-circuit — lives in the browser half, because every one
 * of them acts on dsh-ads's *client* surface. The node half exists so the
 * bundle's `main` resolves cleanly and so a future version that wants to
 * shadow `/dsh-ads/registry.json` from the host side has somewhere to land;
 * for now, applying it does nothing.
 *
 * @module @huanlin/dsh-plugin-anti-ads
 */

/** Plugin configuration; intentionally empty — every knob lives client-side. */
export interface Config {}

/** No host services are required. */
export const inject: readonly string[] = []

/**
 * Apply the (empty) node half.
 * @param _ctx - host context, unused.
 * @param _config - see {@link Config}.
 */
export function apply(_ctx: unknown, _config: Config = {}): void {
  // Intentionally empty. See module doc.
}
