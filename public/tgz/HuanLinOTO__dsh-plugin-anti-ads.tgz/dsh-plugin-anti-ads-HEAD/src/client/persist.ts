/**
 * Anti-ads's own persistence.
 *
 * Mirror of dsh-ads's persist module, deliberately: the two plugins live in
 * the same document as separate React trees — anti-ads's dock badge and its
 * settings page are different slot entries — and the native `storage` event
 * only fires in *other* tabs. A same-document broadcast event with a
 * memory-first read keeps the two halves of this plugin agreeing the way
 * dsh-ads's own two halves agree, and reuses the exact mechanism anti-ads
 * defends against.
 *
 * @module
 */

import { useCallback, useEffect, useState } from 'react'

/** Same-document change notification, scoped so it can never be mistaken for dsh-ads's. */
const CHANGED = 'dsh-anti-ads:persist-changed'

/**
 * Last written value per key, kept in memory.
 *
 * Same reasoning as dsh-ads: storage can be unwritable (private-mode Safari,
 * sandboxed frames, jsdom), and without a memory mirror the broadcast would
 * hand every listener the stored value — i.e. roll a preference back to its
 * default the instant it changed. Durability across reloads is the only thing
 * lost when storage fails.
 */
const memory = new Map<string, unknown>()

/**
 * A `useState` that mirrors into `localStorage` under `dsh-anti-ads:<key>`.
 *
 * @param key - suffix of the storage key.
 * @param initial - value used when nothing is stored or storage is unavailable.
 * @returns the current value and a setter, same shape as `useState`.
 */
export function usePersisted<T>(key: string, initial: T): [T, (next: T) => void] {
  const read = useCallback((): T => {
    if (memory.has(key)) return memory.get(key) as T
    try {
      const raw = localStorage.getItem(`dsh-anti-ads:${key}`)
      return raw === null ? initial : (JSON.parse(raw) as T)
    } catch {
      // Swallowed: unavailable or corrupt storage means "no preference yet".
      return initial
    }
    // `initial` is intentionally not a dependency: re-reading because a caller
    // passed a fresh object literal would clobber the stored value.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])
  const [value, setValue] = useState<T>(read)
  const store = useCallback((next: T) => {
    memory.set(key, next)
    setValue(next)
    try {
      localStorage.setItem(`dsh-anti-ads:${key}`, JSON.stringify(next))
    } catch {
      // Swallowed: the preference stays in memory for this tab.
    }
    dispatchEvent(new CustomEvent(CHANGED, { detail: key }))
  }, [key])
  // Follow writes made by other hook instances on the same key.
  useEffect(() => {
    const onChanged = (event: Event) => {
      if ((event as CustomEvent<string>).detail === key) setValue(read())
    }
    addEventListener(CHANGED, onChanged)
    return () => removeEventListener(CHANGED, onChanged)
  }, [key, read])
  return [value, store]
}

/**
 * Forget every stored preference.
 *
 * The honest counterpart to {@link usePersisted}'s setter: without it there is
 * no way back to a clean slate, because the in-memory mirror survives even
 * where storage does not. Tests need one, and so does any future reset
 * control.
 */
export function clearPersisted(): void {
  for (const key of memory.keys()) {
    try {
      localStorage.removeItem(`dsh-anti-ads:${key}`)
    } catch {
      // Swallowed: storage that cannot be written cannot be holding anything
      // to clear either.
    }
  }
  memory.clear()
  dispatchEvent(new CustomEvent(CHANGED, { detail: '' }))
}
