/**
 * Anti-ads settings, and the settings write-through against dsh-ads.
 *
 * dsh-ads exposes its placement switches as a persisted object under
 * `localStorage['dsh-ads:settings']`, synchronised across its own React trees
 * by a same-document broadcast event (`dsh-ads:persist-changed`). Every
 * placement — gutters, in-feed ads, pop-ups, the benchmark, the fake security
 * alert, the poster — reads that object on every render and hides itself when
 * its switch is off. Writing the all-off object and broadcasting the event is
 * therefore "using dsh-ads's own switch to switch dsh-ads off", and it is the
 * primary defence this plugin performs.
 *
 * One caveat is accepted by design: dsh-ads's persistence keeps a memory
 * mirror that is only refreshed when *its own* setter runs, so once the user
 * has personally toggled a placement, the write-through stops reaching its
 * live state until the next page load. That is what the DOM scrub (L2) is
 * for — see [scrub.ts](./scrub.ts) — and the localStorage is kept in the
 * all-off state regardless, so the very next load starts silent.
 *
 * L4 is a second, newer handle dsh-ads itself added: since 480882a its
 * "关闭所有广告" state is module-scope in `retire.ts` and reached by the
 * `dsh-ads:retired` same-document event. That flag is checked before any
 * render (`if (retired) return null`), so broadcasting it retires the whole
 * layer for the page load even if a future dsh-ads stops reading its own
 * settings — the one control the write-through cannot express.
 *
 * ## TOKEN defeat (dsh-ads 0.2)
 *
 * Since dsh-ads 0.2 (commit d49ed5a) the retire event carries a
 * module-private `Symbol('dsh-ads:retired')` as its `detail`, and the
 * `useRetired` listener rejects any event whose `detail` is not that exact
 * Symbol reference. A Symbol created with `Symbol()` (not `Symbol.for()`) is
 * unique per call and cannot be recreated by name, so a forged event
 * carrying no detail — or any detail that is not the same Symbol object — is
 * silently ignored. This defeats the previous `broadcastAdsRetired`, which
 * dispatched a bare event.
 *
 * The counter: {@link installRetireTokenCapture} patches the global
 * `CustomEvent` constructor so that the first time dsh-ads's own
 * `retireAds()` creates a real `dsh-ads:retired` event, the Symbol is
 * captured from the constructor's `init.detail` argument. Once captured,
 * {@link broadcastAdsRetired} dispatches with that exact Symbol reference,
 * and the listener accepts it. The capture is installed at module load and
 * is transparent — it only reads events of that one type, and creates them
 * unchanged.
 *
 * The Token is only available after `retireAds()` has run at least once
 * (dsh-ads calls it from its "关闭所有广告" button). Until then,
 * `broadcastAdsRetired` dispatches without detail (harmlessly ignored), and
 * L1–L3 carry the load. [AntiAdLayer.tsx](./AntiAdLayer.tsx) runs a
 * MutationObserver that auto-clicks dsh-ads's retire button the moment it
 * appears in the DOM (e.g. when the user opens the settings dialog), which
 * triggers `retireAds()` through dsh-ads's own code path — capturing the
 * Token and retiring the layer in one step.
 *
 * @module
 */

import { useEffect } from 'react'
import { usePersisted } from './persist.ts'

/** Anti-ads's own switches. */
export interface AntiAdsSettings {
  /** Master switch: when off, nothing below runs and dsh-ads is left alone. */
  readonly enabled: boolean
  /** L2: remove dsh-ads portal elements from the DOM as they appear. */
  readonly aggressive: boolean
  /** L3: short-circuit the dynamic-tier registry fetch. */
  readonly blockDynamic: boolean
  /** L4: broadcast dsh-ads's own retire event, retiring its layer for the page load. */
  readonly deep: boolean
}

/** Everything on: an installed plugin that does not run is just dead weight. */
export const DEFAULT_ANTI_ADS_SETTINGS: AntiAdsSettings = {
  enabled: true,
  aggressive: true,
  blockDynamic: true,
  deep: true,
}

/** Storage key holding {@link AntiAdsSettings}. */
const SETTINGS_KEY = 'settings'

/**
 * dsh-ads's own persistence contract — mirrored, not imported. The client
 * bundle is wrapped by the loader and exposes no internals, so these are
 * written by hand from dsh-ads's source (`settings.ts` + `persist.ts`).
 */
export const ADS_SETTINGS_KEY = 'dsh-ads:settings'

/** dsh-ads's same-document broadcast event. */
export const ADS_CHANGED_EVENT = 'dsh-ads:persist-changed'

/** The value dsh-ads's persistence keys its broadcast under. */
export const ADS_SETTINGS_DETAIL = 'settings'

/**
 * dsh-ads's module-scope retire event, since its 480882a. Any listener on
 * this retires the whole layer for the rest of the page load — see
 * `retire.ts` in the dsh-ads client bundle. Mirrored, not imported: the
 * bundle is loader-wrapped and exposes no internals.
 */
export const ADS_RETIRED_EVENT = 'dsh-ads:retired'

/**
 * The module-private Symbol dsh-ads 0.2 stamps onto retire events as their
 * `detail`, and checks in its `useRetired` listener. We cannot recreate it
 * (a `Symbol()` call returns a fresh symbol every time), but we can capture
 * the real reference from dsh-ads's own `CustomEvent` construction — see
 * {@link installRetireTokenCapture}.
 *
 * `undefined` until captured; once set, it persists for the page load.
 */
let capturedRetireToken: symbol | undefined

/**
 * Whether the retire Token has been captured from a real dsh-ads event.
 * Exposed for tests and for the badge to report L4's readiness.
 * @returns true once dsh-ads's own `retireAds()` has been observed.
 */
export function hasRetireToken(): boolean {
  return capturedRetireToken !== undefined
}

/**
 * The captured Token, or `undefined` if no real retire event has been seen.
 * Used by {@link broadcastAdsRetired} to forge an event dsh-ads's listener
 * will accept.
 */
export function getRetireToken(): symbol | undefined {
  return capturedRetireToken
}

/**
 * Reset the captured Token. Test-only — the Token is page-load lifetime in
 * production.
 */
export function resetRetireToken(): void {
  capturedRetireToken = undefined
}

/** Idempotency guard for {@link installRetireTokenCapture}. */
let captureInstalled = false

/** Saved original `CustomEvent` for {@link uninstallRetireTokenCapture}. */
let originalCustomEvent: typeof CustomEvent | undefined

/**
 * Patch the global `CustomEvent` constructor to capture dsh-ads's retire
 * Token.
 *
 * dsh-ads 0.2 creates its retire event as
 * `new CustomEvent('dsh-ads:retired', { detail: TOKEN })` where `TOKEN` is a
 * module-private `Symbol()`. The Symbol never leaves the module through any
 * other channel, so the only way to obtain a reference is to intercept the
 * `CustomEvent` constructor at the moment dsh-ads's own `retireAds()` calls
 * it.
 *
 * The patch is transparent: it creates the event via the original constructor
 * unchanged, and only reads `init.detail` when `type === 'dsh-ads:retired'`
 * and the detail is a Symbol. No other event type is affected. Installed once
 * at module load; safe to call again (no-op).
 *
 * The Token is only available after `retireAds()` has run — i.e. after
 * dsh-ads's "关闭所有广告" button has been pressed (the badge's
 * MutationObserver presses it automatically when it appears). Before that,
 * `broadcastAdsRetired` dispatches without detail and L1–L3 carry the load.
 */
export function installRetireTokenCapture(): void {
  if (captureInstalled) return
  if (typeof globalThis === 'undefined' || typeof globalThis.CustomEvent !== 'function') return
  captureInstalled = true
  originalCustomEvent = globalThis.CustomEvent
  const Original = originalCustomEvent

  // Wrap the constructor: capture the Token from the init.detail, then
  // delegate to the original. Returning an object from a constructor replaces
  // `this`, so `new patched(...)` yields the original-constructed event.
  const patched = function (type: string, init?: CustomEventInit) {
    const event = new Original(type, init)
    if (type === ADS_RETIRED_EVENT) {
      const detail = init?.detail
      // Only capture the first Token: dsh-ads's Symbol is unique per page
      // load, so the first one seen is the one its listener checks against.
      // Subsequent retire events carry the same Symbol, and a forged event
      // from elsewhere is not a Symbol and is ignored by the typeof guard.
      if (typeof detail === 'symbol' && capturedRetireToken === undefined) {
        capturedRetireToken = detail
      }
    }
    return event
  } as unknown as typeof CustomEvent

  // Preserve identity: `event instanceof CustomEvent` and static properties.
  patched.prototype = Original.prototype
  Object.setPrototypeOf(patched, Original)
  globalThis.CustomEvent = patched
}

/**
 * Restore the original `CustomEvent`. Test-only — in production the patch
 * lives for the page load.
 */
export function uninstallRetireTokenCapture(): void {
  if (!captureInstalled) return
  captureInstalled = false
  if (originalCustomEvent !== undefined && typeof globalThis !== 'undefined') {
    globalThis.CustomEvent = originalCustomEvent
  }
  originalCustomEvent = undefined
  capturedRetireToken = undefined
}

// Install at module load: the patch must be in place before dsh-ads's
// `retireAds()` is ever called (button click), and module load is strictly
// before any UI interaction. Transparent if no `CustomEvent` exists (SSR).
installRetireTokenCapture()

/**
 * The all-off settings object. Every key is one of dsh-ads's placement
 * switches; `muted` is not a placement but carrying it keeps the object
 * equivalent to what dsh-ads itself would store.
 */
export const ADS_ALL_OFF = {
  gutter: false,
  feed: false,
  popup: false,
  speed: false,
  scare: false,
  poster: false,
  muted: true,
} as const

/** Stored-shape of dsh-ads's settings, for reading back. */
interface StoredAdsSettings {
  readonly [key: string]: unknown
}

/**
 * Whether the stored dsh-ads settings already equal the all-off object.
 *
 * This is the loop-breaker for the write-through: the broadcast event this
 * plugin dispatches reaches its own listener too, and without the check every
 * event would trigger a fresh write, which would dispatch another event, and
 * so on. Writing only when something is actually on keeps the chain one hop
 * long — and the listener fires again, it reads all-off, and stops.
 *
 * @param raw - the stored value, already parsed; undefined when absent.
 * @returns true when every placement switch is already off.
 */
export function adsSettingsAreOff(raw: unknown): boolean {
  if (typeof raw !== 'object' || raw === null) return false
  const stored = raw as StoredAdsSettings
  for (const [key, off] of Object.entries(ADS_ALL_OFF)) {
    if (stored[key] !== off) return false
  }
  return true
}

/**
 * Write the all-off settings into dsh-ads's storage and announce it.
 *
 * Dispatch happens even when storage throws: dsh-ads's in-memory mirror may
 * still pick the value up via its own read path, and a same-document announce
 * costs nothing. Both writes are guarded separately, mirroring dsh-ads's own
 * tolerance for unwritable storage.
 */
export function writeAdsSettingsOff(): void {
  try {
    localStorage.setItem(ADS_SETTINGS_KEY, JSON.stringify(ADS_ALL_OFF))
  } catch {
    // Swallowed: the broadcast below is the part that reaches live state.
  }
  dispatchEvent(new CustomEvent(ADS_CHANGED_EVENT, { detail: ADS_SETTINGS_DETAIL }))
}

/**
 * Broadcast dsh-ads's own retire event.
 *
 * Since dsh-ads's 480882a its retire flag is module-scope and one-way, and
 * the whole layer (`AdLayer`) returns null the moment it is set — checked
 * before every placement, settings read or spawn timer. Dispatching the
 * event is therefore "pressing dsh-ads's own 关闭所有广告 button" the way the
 * write-through presses its switches, and it stays effective against a
 * future dsh-ads that stops reading its stored settings.
 *
 * One-way by design: dsh-ads has no un-retire, so a broadcast is never
 * reversed this page load — which is exactly the semantics anti-ads wants,
 * and why disabling the master switch restores defaults but the layer stays
 * hidden until the next reload.
 *
 * ## TOKEN (dsh-ads 0.2)
 *
 * Since dsh-ads 0.2 the listener checks `event.detail !== TOKEN` where TOKEN
 * is a module-private Symbol. A bare event (no detail) is silently ignored.
 * When the Token has been captured (via {@link installRetireTokenCapture},
 * after dsh-ads's own `retireAds()` has run at least once), this function
 * dispatches with that exact Symbol reference and the listener accepts it.
 * Before the Token is captured, the broadcast is a no-op on dsh-ads's side
 * — L1–L3 carry the load until the badge's MutationObserver auto-clicks the
 * retire button and captures it.
 */
export function broadcastAdsRetired(): void {
  if (capturedRetireToken !== undefined) {
    dispatchEvent(new CustomEvent(ADS_RETIRED_EVENT, { detail: capturedRetireToken }))
  } else {
    // No Token yet: dispatch bare. dsh-ads 0.2 will ignore this (its
    // listener checks `detail !== TOKEN`), but it costs nothing and keeps
    // the broadcast semantic for any older dsh-ads that has no Token check.
    dispatchEvent(new CustomEvent(ADS_RETIRED_EVENT))
  }
}

/**
 * Read and write anti-ads's own settings.
 * @returns the settings and a setter, same shape as `useState`.
 */
export function useAntiAdsSettings(): [AntiAdsSettings, (next: AntiAdsSettings) => void] {
  const [stored, store] = usePersisted<Partial<AntiAdsSettings>>(SETTINGS_KEY, DEFAULT_ANTI_ADS_SETTINGS)
  return [{ ...DEFAULT_ANTI_ADS_SETTINGS, ...stored }, store]
}

/**
 * Keep dsh-ads's stored settings suppressed while enabled.
 *
 * Runs a write-through on mount and then listens for dsh-ads's own broadcast:
 * every time dsh-ads's state changes — a toggle on its settings page, a
 * future version writing defaults back — and something is switched on, this
 * writes the all-off object again. The loop-breaker in
 * {@link adsSettingsAreOff} bounds the chain at one hop; see its doc.
 *
 * When `deep` is on, the retire event is broadcast on the same mount and on
 * the same re-arm: the write-through and the retire broadcast are two
 * handles on the same suppression, and re-dispatching an idempotent event
 * costs nothing. The broadcast is deliberately one-way — see
 * {@link broadcastAdsRetired} for why.
 *
 * Deliberately a passive guard, not a poller: the same listener that fires on
 * dsh-ads's writes is the only write this plugin does, so storage stays quiet
 * when nothing happens.
 *
 * @param enabled - whether suppression is active; when false, the guard
 * unsubscribes and dsh-ads's settings are left alone.
 * @param deep - whether the retire event is broadcast alongside the
 * write-through; independent of `enabled` only in the direction that matters
 * — toggling `deep` off leaves the write-through running.
 */
export function useAdsGuard(enabled: boolean, deep: boolean): void {
  useEffect(() => {
    if (!enabled) return
    writeAdsSettingsOff()
    if (deep) broadcastAdsRetired()
    const onChanged = (event: Event) => {
      if ((event as CustomEvent<string>).detail !== ADS_SETTINGS_DETAIL) return
      let raw: unknown = null
      try {
        raw = localStorage.getItem(ADS_SETTINGS_KEY)
      } catch {
        // Swallowed: unreadable storage means the write path below will
        // decide; the broadcast is what reaches live state either way.
      }
      if (raw === null || raw === undefined) return
      let parsed: unknown
      try {
        parsed = JSON.parse(raw as string)
      } catch {
        return
      }
      if (adsSettingsAreOff(parsed)) return
      writeAdsSettingsOff()
      if (deep) broadcastAdsRetired()
    }
    addEventListener(ADS_CHANGED_EVENT, onChanged)
    return () => removeEventListener(ADS_CHANGED_EVENT, onChanged)
  }, [enabled, deep])
}
