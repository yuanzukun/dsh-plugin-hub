/**
 * dsh-anti-ads, browser half. Two registrations, both mirroring dsh-ads's
 * own, one order later so the write-through runs after its layer is live:
 *
 * - The composer's input dock mounts the badge and the three defences. Like
 *   dsh-ads's own dock entry it renders nothing inline — everything visible
 *   is portalled onto `document.body` under a `data-dsh-anti-ads` marker the
 *   scrub skips.
 * - The settings dialog gets a page of its own, which is where the switches
 *   live in full; the badge panel is a shortcut to the same stored state.
 *
 * The turn-tail chain is deliberately left alone: dsh-ads's in-transcript ad
 * reads `settings.feed` on every render, so the write-through hides it with
 * no chain involvement at all.
 *
 * @module @huanlin/dsh-plugin-anti-ads
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the ctx.locale Context merge (LocaleRuntime) so the
// apply body can register/bind the plugin's own namespace.
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the `conversation.input.dock` SlotMap declaration.
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
// Type-only: pulls the `settings.section` SlotMap declaration.
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { AntiAdLayer } from './AntiAdLayer.tsx'
import { AntiAdsSection } from './AntiAdsSection.tsx'
import { dicts } from './dictionaries.ts'
import { NS, en, zh } from './locales.ts'

export const name = 'dsh-anti-ads'

export const inject = ['slots', 'locale']

/** Structural view of better-locale's override store (optional; no runtime dep). */
interface BetterLocaleOverrideStore {
  register(ns: string, dicts: Record<string, Record<string, string>>): () => void
}

/**
 * Register both mount points.
 *
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  // The plugin's own copy namespace, following DSH's native zh/en.
  ctx.effect(
    () => ctx.locale.register(NS, { zh, en }),
    'dsh-anti-ads: own copy namespace',
  )
  const t = ctx.locale.bind(NS)

  // One order later than dsh-ads's own dock entry (90), so the write-through
  // lands after its layer is mounted and its usePersisted listeners are live.
  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register(
    { name: 'conversation.input.dock', id: 'dsh-anti-ads', order: 100, locale: NS },
    AntiAdLayer,
  ))
  // A page of its own, labelled third-party exactly like dsh-ads's page is.
  ctx.slots.inject('settings.section', () => ctx.slots.register(
    { name: 'settings.section', id: 'dsh-anti-ads', order: 100, label: () => t('navLabel'), locale: NS },
    AntiAdsSection,
  ))

  // better-locale override: register the 19-language dicts so a selected
  // override language (with DSH on 'en') replaces the plugin's copy. The
  // service is optional — no better-locale, no dicts.
  // Activation-order-safe: re-check ctx.get('betterLocale') on every locale
  // revision bump (better-locale bumps on activation + override switch).
  ctx.effect(() => {
    let dispose: (() => void) | undefined
    const sync = (): void => {
      dispose?.()
      dispose = undefined
      const store = ctx.get('betterLocale') as BetterLocaleOverrideStore | undefined
      if (store !== undefined) {
        dispose = store.register(NS, dicts)
      }
    }
    sync()
    const unsubscribe = ctx.locale.subscribe(sync)
    return () => {
      unsubscribe()
      dispose?.()
    }
  }, 'dsh-plugin-anti-ads: better-locale override dicts')
}
