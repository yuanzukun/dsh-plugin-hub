/**
 * The plugin's own copy dictionaries plus the shared vocabulary of its UI.
 *
 * The strings are the whole user-visible surface: the settings page, the
 * badge chip, the badge panel, and the settings nav label. `en` / `zh` are
 * registered with DSH's locale service and follow DSH's native zh/en;
 * the 19-language override dicts in [dictionaries.ts](./dictionaries.ts)
 * are handed to better-locale (when installed) so a selected override
 * language replaces them.
 *
 * The component default (`makeT(zh)`) is only a direct-mount fallback so
 * the components stay usable outside the slot system (tests, quick mounts);
 * inside DSH the slot renderer always binds the locale-provided `t`.
 */

import type { Translate } from '@deepseek-ai/dsh-client-ui-slots'

/** All copy keys for the dsh-anti-ads namespace. */
export type AntiAdsKey =
  | 'navLabel'
  | 'introBefore'
  | 'introAfter'
  | 'scopeNote'
  | 'methodNote'
  | 'enabledTitle'
  | 'enabledDesc'
  | 'enabledAria'
  | 'aggressiveTitle'
  | 'aggressiveDesc'
  | 'blockDynamicTitle'
  | 'blockDynamicDesc'
  | 'deepTitle'
  | 'deepDesc'
  | 'masterDisclaimer'
  | 'toggleAggressive'
  | 'toggleBlockDynamic'
  | 'toggleDeep'
  | 'blockedCount'
  | 'blockedAll'
  | 'panelTitle'
  | 'panelEnabled'
  | 'panelNoteBefore'
  | 'panelNoteAfter'

/** Locale namespace id (matches the cordis.patch.yml plugin id). */
export const NS = 'dsh-anti-ads'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'dsh-anti-ads': AntiAdsKey
  }
}

/** English dictionary. */
export const en: Record<AntiAdsKey, string> = {
  navLabel: 'Ad blocking (unofficial)',
  introBefore: 'This page is provided by the community plugin',
  introAfter: 'and is not an official DeepSeek feature.',
  scopeNote: 'Only affects dsh-ads; this plugin does nothing when dsh-ads is not installed.',
  methodNote: 'Blocks ads by writing dsh-ads\'s own settings to disable every ad slot, broadcasting its "turn off" event, and clearing leftover pop-ups.',
  enabledTitle: '🛡 Block ads',
  enabledDesc: 'Turning this off restores dsh-ads\'s defaults and the ads come back',
  enabledAria: 'Block ads',
  aggressiveTitle: '🧹 Sweep leftover ads',
  aggressiveDesc: 'Watches page changes and removes ad pop-ups that bypass the settings',
  blockDynamicTitle: '📡 Block dynamic ad sources',
  blockDynamicDesc: 'Intercepts dsh-ads\'s community-plugin ad directory requests',
  deepTitle: '🧯 Deep blocking (broadcast turn-off)',
  deepDesc: 'Broadcasts dsh-ads\'s own "turn off for this session" event; the whole ad layer stays hidden until refresh',
  masterDisclaimer: 'Turning off "Block ads" also restores dsh-ads\'s defaults; if deep blocking has already broadcast its session turn-off, dsh-ads\'s ad layer only comes back after a page refresh.',
  toggleAggressive: 'Sweep leftover ads',
  toggleBlockDynamic: 'Block dynamic ad sources',
  toggleDeep: 'Deep blocking (broadcast turn-off)',
  blockedCount: '{count} blocked',
  blockedAll: 'Ads blocked',
  panelTitle: 'Ad blocking (dsh-anti-ads)',
  panelEnabled: 'Block ads (disable to restore ads)',
  panelNoteBefore: 'Turns off every ad slot through dsh-ads\'s own settings and its session turn-off broadcast, and clears leftover pop-ups.',
  panelNoteAfter: 'Nothing happens when dsh-ads is not installed.',
}

/** Chinese dictionary. */
export const zh: Record<AntiAdsKey, string> = {
  navLabel: '广告拦截（非官方）',
  introBefore: '本页由社区插件',
  introAfter: '提供，非 DeepSeek 官方功能。',
  scopeNote: '仅对 dsh-ads 生效；未安装 dsh-ads 时本插件无任何效果。',
  methodNote: '拦截方式：写入 dsh-ads 自身的设置使其关闭全部广告位，广播其「本次关闭」事件，并清理残留弹层。',
  enabledTitle: '🛡 启用拦截',
  enabledDesc: '关闭后恢复 dsh-ads 的默认设置，广告回到页面',
  enabledAria: '启用拦截',
  aggressiveTitle: '🧹 兜底清理残留广告',
  aggressiveDesc: '监听页面变化，自动移除绕过设置的广告弹层',
  blockDynamicTitle: '📡 屏蔽动态广告源',
  blockDynamicDesc: '拦截 dsh-ads 的社区插件广告目录请求',
  deepTitle: '🧯 深层拦截（广播本次关闭）',
  deepDesc: '向 dsh-ads 广播其自身的「本次会话关闭」事件，整个广告层隐藏到刷新',
  masterDisclaimer: '关闭「启用拦截」会同时把 dsh-ads 的设置恢复为默认；若「深层拦截」已广播过本次关闭，dsh-ads 的广告层要到刷新页面后才会回来。',
  toggleAggressive: '兜底清理残留广告',
  toggleBlockDynamic: '屏蔽动态广告源',
  toggleDeep: '深层拦截（广播本次关闭）',
  blockedCount: '已拦截 {count} 条',
  blockedAll: '广告已拦截',
  panelTitle: '广告拦截（dsh-anti-ads）',
  panelEnabled: '启用拦截（关闭即恢复广告）',
  panelNoteBefore: '通过 dsh-ads 自身的设置开关与「本次关闭」广播关闭全部广告位，并清理其残留弹层。',
  panelNoteAfter: '未安装 dsh-ads 时本插件无任何效果。',
}

/**
 * Build a translate function over one bundled dictionary. Interpolates
 * `{name}` params so a missing param leaves the placeholder in place.
 * @param dict - the dictionary to read from.
 * @returns a keyed translate function.
 */
export function makeT(dict: Record<AntiAdsKey, string>): Translate<string> {
  return (key: string, params?: Record<string, unknown>): string => {
    const template = dict[key as AntiAdsKey]
    if (params === undefined) return template
    return template.replace(/\{(\w+)\}/g, (match: string, name: string) =>
      params[name] === undefined ? match : String(params[name]))
  }
}