/**
 * DOM scrub: identify and remove dsh-ads's portalled layer.
 *
 * The settings write-through in [settings.ts](./settings.ts) is the primary
 * defence — it flips every placement switch off through dsh-ads's own
 * persistence contract, so the layer renders nothing on its own. This module
 * is the secondary defence: when dsh-ads upgrades to a version that adds a
 * placement ignoring those settings, or when something writes the settings
 * back on between ticks, the MutationObserver driven from [AntiAdLayer.tsx]
 * (./AntiAdLayer.tsx) catches the portal by shape and pulls it.
 *
 * Identification is by inline style rather than class name: the shell's class
 * names are per-build CSS-module hashes, and dsh-ads's own classNames are not
 * a contract. The inline styles React writes at mount are stable, unique
 * enough to be unambiguous, and cheap to read.
 *
 * ## Self-identification: DOM reference, not attribute
 *
 * An earlier version skipped subtrees carrying the {@link ANTIADS_ATTR}
 * attribute (presence-only check). dsh-ads 0.2 copies that attribute onto its
 * own root — a honeypot that makes any attribute-based scrub skip the ads
 * themselves. The scrub now identifies the badge by **DOM node reference**
 * ({@link scrubAds}'s `skip` parameter): dsh-ads can copy any attribute, but
 * it cannot make its root *be* the badge node. The attribute stays on the
 * badge for semantic markup only; the scrub does not read it.
 *
 * @module
 */

/** z-index of dsh-ads's portalled root container; see AdLayer.tsx:476. */
export const ADS_ROOT_Z_INDEX = 2_147_400_000

/**
 * Lower bound of dsh-ads's z-index band. AdBanner rows add a small integer to
 * the base; every other placement (ToastPopup, VirusToast, SpeedToast,
 * GamePoster, Lightbox) sits at or above it. 2^31 − 1 is the legal maximum
 * for the CSS property, which makes a tidy upper bound.
 */
export const ADS_Z_INDEX_MIN = ADS_ROOT_Z_INDEX

/** Upper bound of dsh-ads's z-index band; 2^31 − 1, the CSS maximum. */
export const ADS_Z_INDEX_MAX = 2_147_483_647

/**
 * Floor of the loose full-viewport overlay signature, {@link isAdsOverlay}.
 *
 * The root portal is caught by its exact z-index, but a future dsh-ads could
 * restyle the same element — serialise `inset` as four longs, drop below
 * `2_147_400_000` to dodge the band. The fallback therefore matches by
 * *shape* instead: a full-viewport, click-through (`pointer-events: none`)
 * overlay is the shape of an ad layer and of nothing in the shell — the
 * shell's own overlays (modals, menus, tooltips) sit at z 1100 or below and
 * are interactive, so the million floor keeps them out with a four-order
 * margin.
 */
export const ADS_OVERLAY_Z_FLOOR = 1_000_000

/**
 * Marker this plugin puts on its own portalled root. **Semantic markup only** —
 * the scrub no longer reads this attribute (dsh-ads copies it onto its own
 * root as a honeypot; see the module doc). Self-identification is by DOM node
 * reference via {@link scrubAds}'s `skip` parameter. Kept on the badge for
 * debugging, CSS targeting, and tests that need to find the portal.
 */
export const ANTIADS_ATTR = 'data-dsh-anti-ads'

/**
 * Whether an element carries this plugin's marker, or sits inside one that
 * does.
 *
 * **Not used by the scrub** since the honeypot defeat — kept for external
 * callers and tests that want to locate the badge by attribute. The scrub
 * itself uses {@link scrubAds}'s `skip` parameter (DOM reference) instead.
 *
 * @param el - the element to test.
 * @returns true when the element or any ancestor is marked.
 */
export function hasAntiAdsAncestor(el: Element): boolean {
  let cur: Element | null = el
  while (cur !== null) {
    if (cur.hasAttribute(ANTIADS_ATTR)) return true
    cur = cur.parentElement
  }
  return false
}

/**
 * Whether an element sits inside a skip scope — the badge node or any of its
 * descendants. Replaces the attribute-based {@link hasAntiAdsAncestor} in the
 * scrub: dsh-ads can copy the `data-dsh-anti-ads` attribute onto its own root,
 * but it cannot make its root *be* the badge node.
 *
 * @param el - the element to test.
 * @param skip - the badge root to skip, or null/undefined for no skip.
 * @returns true when the element is the skip node or inside it.
 */
export function isInsideScope(el: Element, skip: Element | null | undefined): boolean {
  if (skip == null) return false
  return el === skip || skip.contains(el)
}

/**
 * Whether an element is dsh-ads's portalled root container.
 *
 * The signature is the four inline properties React sets at mount:
 * `position: fixed`, `inset: 0` (serialised by React as `'0px'`), the magic
 * z-index, and `pointer-events: none`. Together they describe a full-viewport
 * overlay that passes clicks through — a shape no first-party shell surface
 * has, and the only place dsh-ads mounts a portal onto `document.body`.
 *
 * @param el - any element.
 * @returns true when the element matches the root portal signature.
 */
export function isAdsRoot(el: Element): boolean {
  if (!(el instanceof HTMLElement)) return false
  const s = el.style
  return s.position === 'fixed'
    && s.inset === '0px'
    && s.zIndex === String(ADS_ROOT_Z_INDEX)
    && s.pointerEvents === 'none'
}

/**
 * Whether an element is a full-viewport, click-through overlay at a
 * z-index no first-party surface uses.
 *
 * The root's exact signature ({@link isAdsRoot}) pins all four inline
 * styles React writes at mount. A dsh-ads that changes any one of them —
 * serialising `inset: 0` as four longs, using a different z-index, adding a
 * wrapping div with the styles moved one level up — drops out of that
 * signature while still being the same thing: a layer that covers the
 * viewport, lets clicks pass through, and sits far above every real UI.
 *
 * The combination is what makes this safe to match loosely: `position:
 * fixed` + `pointer-events: none` + full viewport + z-index above a million
 * describes an invisible click-through ceiling. The shell's dialogs and
 * menus are interactive (auto), its loading surfaces cap out around
 * z 1100, and nothing first-party floats above a million — so the floor
 * cannot collide, and the rest of the signature makes an ad layer's root
 * the only plausible inhabitant of that space.
 *
 * @param el - any element.
 * @returns true when the element matches the loose overlay signature.
 */
export function isAdsOverlay(el: Element): boolean {
  if (!(el instanceof HTMLElement)) return false
  const s = el.style
  if (s.position !== 'fixed' || s.pointerEvents !== 'none') return false
  const z = Number(s.zIndex)
  if (!Number.isInteger(z) || z < ADS_OVERLAY_Z_FLOOR) return false
  // React serialises `inset: 0` as '0px'; a hand-written or restyled root
  // could instead spell out the four edges.
  if (s.inset === '0px') return true
  return s.top === '0px' && s.left === '0px'
    && (s.width === '100vw' || s.width === '100%')
    && (s.height === '100vh' || s.height === '100%')
}

/**
 * Whether an element is a dsh-ads placement sitting loose on `document.body`
 * rather than inside the root portal.
 *
 * The root is what AdLayer mounts, but every individual placement (AdBanner,
 * ToastPopup, VirusToast, SpeedToast, GamePoster, Lightbox) also renders with
 * `position: fixed` and a z-index in the band. A future dsh-ads version could
 * portal one of those directly — or the root could be removed while its
 * children are mid-render — and catching them by band is what makes the scrub
 * robust against structural changes that keep the styling contract.
 *
 * @param el - any element.
 * @returns true when the element matches a standalone placement signature.
 */
export function isAdsChild(el: Element): boolean {
  if (!(el instanceof HTMLElement)) return false
  const s = el.style
  if (s.position !== 'fixed') return false
  const z = Number(s.zIndex)
  return Number.isInteger(z) && z >= ADS_Z_INDEX_MIN && z <= ADS_Z_INDEX_MAX
}

/**
 * Remove every dsh-ads element under a root.
 *
 * Two passes, both by static `querySelectorAll` so removals during iteration
 * are safe: roots first (their removal orphans any children already drawn),
 * then standalone placements for the structural-change case above. Returns
 * the count removed, which the badge reports as "已拦截" — the only feedback
 * the user gets that the secondary defence did anything.
 *
 * The `skip` parameter is the badge's own DOM node: the scrub must not remove
 * itself. This is by **reference**, not by attribute — dsh-ads 0.2 copies the
 * `data-dsh-anti-ads` attribute onto its own root as a honeypot, so any
 * attribute-based skip would spare the ads too. A DOM node reference cannot
 * be forged.
 *
 * @param root - where to scan; defaults to `document` for the live DOM.
 * @param skip - the badge root to leave alone (and whose subtree to skip);
 * pass the badge's DOM node from the caller's ref. Defaults to null (no skip).
 * @returns the number of elements removed.
 */
export function scrubAds(root: ParentNode = document, skip: Element | null = null): number {
  const candidates: HTMLElement[] = []
  for (const el of root.querySelectorAll<HTMLElement>('*')) {
    if (isInsideScope(el, skip)) continue
    if (isAdsRoot(el) || isAdsOverlay(el) || isAdsChild(el)) candidates.push(el)
  }
  let count = 0
  for (const el of candidates) {
    // A candidate collected as a child may sit inside one collected as a
    // root; removing the root orphans it, and calling `.remove()` on an
    // already-detached element is a no-op but the count would lie. Skip
    // anything that lost its connection during the sweep — checked with
    // `isConnected` because jsdom keeps a detached element's `parentElement`
    // pointing at its removed parent.
    if (!el.isConnected) continue
    el.remove()
    count += 1
  }
  return count
}
