/**
 * The plugin's page in the host's own settings dialog.
 *
 * Sits beside dsh-ads's own page in the settings nav and writes the same
 * anti-ads state the badge panel does — the two stay in step through the
 * persistence layer's same-document broadcast. This is the *only* place to
 * turn blocking back on once the badge has been switched off (the badge
 * unmounts when disabled), which is why the master switch lives here first
 * and the badge mirrors it.
 *
 * Styled with inline rules rather than the shell's CSS modules, whose class
 * names are per-build hashes and not importable from outside. Every colour is
 * either inherited or a neutral alpha, so the page follows the host's light
 * and dark themes without knowing which one is on — same convention as
 * dsh-ads's own section.
 *
 * @module
 */

import type { CSSProperties } from 'react'
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import { useAntiAdsSettings } from './settings.ts'
import { makeT, zh } from './locales.ts'

const REPO_URL = 'https://github.com/huanlinoto/dsh-plugin-anti-ads'

const rowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 24,
  padding: '14px 0',
  borderTop: '1px solid rgba(128, 128, 128, 0.22)',
}

const labelStyle: CSSProperties = { fontSize: 15, lineHeight: 1.4 }

const blurbStyle: CSSProperties = { fontSize: 13, lineHeight: 1.5, opacity: 0.55, marginTop: 2 }

const sourceStyle: CSSProperties = {
  marginBottom: 14,
  padding: '10px 12px',
  borderRadius: 8,
  background: 'rgba(128, 128, 128, 0.12)',
  fontSize: 13,
  lineHeight: 1.6,
  opacity: 0.8,
}

const linkStyle: CSSProperties = { color: 'inherit', textDecoration: 'underline', textUnderlineOffset: 2 }

/** A pill switch, same shape as dsh-ads's own section uses. */
function Toggle({ on, label, onToggle }: { readonly on: boolean; readonly label: string; readonly onToggle: () => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onToggle}
      style={{
        flex: '0 0 auto',
        position: 'relative',
        width: 44,
        height: 26,
        padding: 0,
        border: 0,
        borderRadius: 13,
        background: on ? '#2f6fed' : 'rgba(128, 128, 128, 0.35)',
        transition: 'background 160ms ease',
        cursor: 'pointer',
      }}
    >
      <span
        aria-hidden="true"
        style={{
          position: 'absolute',
          top: 3,
          left: on ? 21 : 3,
          width: 20,
          height: 20,
          borderRadius: '50%',
          background: '#fff',
          boxShadow: '0 1px 3px rgba(0, 0, 0, 0.3)',
          transition: 'left 160ms ease',
        }}
      />
    </button>
  )
}

/**
 * Draw the settings page.
 * @param props - the slot-provided locale seat (`t`), defaulting to the
 * bundled zh dict for direct mounts outside the slot system.
 * @returns the section content column.
 */
export function AntiAdsSection({ t = makeT(zh) }: { t?: PropsLocale<'dsh-anti-ads'>['t'] }) {
  const [settings, setSettings] = useAntiAdsSettings()
  const set = (patch: Partial<typeof settings>) => setSettings({ ...settings, ...patch })
  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      <div style={sourceStyle}>
        <div>
          {t('introBefore')}{' '}
          <a href={REPO_URL} target="_blank" rel="noreferrer noopener" style={linkStyle}>
            @huanlin/dsh-plugin-anti-ads
          </a>{' '}
          {t('introAfter')}
        </div>
        <div style={{ marginTop: 2 }}>{t('scopeNote')}</div>
      </div>
      <div style={{ ...blurbStyle, marginBottom: 6, opacity: 0.6 }}>
        {t('methodNote')}
      </div>
      <div style={rowStyle}>
        <div>
          <div style={labelStyle}>{t('enabledTitle')}</div>
          <div style={blurbStyle}>{t('enabledDesc')}</div>
        </div>
        <Toggle on={settings.enabled} label={t('enabledAria')} onToggle={() => set({ enabled: !settings.enabled })} />
      </div>
      <div style={rowStyle}>
        <div>
          <div style={labelStyle}>{t('aggressiveTitle')}</div>
          <div style={blurbStyle}>{t('aggressiveDesc')}</div>
        </div>
        <Toggle on={settings.aggressive} label={t('toggleAggressive')} onToggle={() => set({ aggressive: !settings.aggressive })} />
      </div>
      <div style={rowStyle}>
        <div>
          <div style={labelStyle}>{t('blockDynamicTitle')}</div>
          <div style={blurbStyle}>{t('blockDynamicDesc')}</div>
        </div>
        <Toggle on={settings.blockDynamic} label={t('toggleBlockDynamic')} onToggle={() => set({ blockDynamic: !settings.blockDynamic })} />
      </div>
      <div style={rowStyle}>
        <div>
          <div style={labelStyle}>{t('deepTitle')}</div>
          <div style={blurbStyle}>{t('deepDesc')}</div>
        </div>
        <Toggle on={settings.deep} label={t('toggleDeep')} onToggle={() => set({ deep: !settings.deep })} />
      </div>
      <div style={{ ...blurbStyle, marginTop: 18 }}>
        {t('masterDisclaimer')}
      </div>
    </div>
  )
}
