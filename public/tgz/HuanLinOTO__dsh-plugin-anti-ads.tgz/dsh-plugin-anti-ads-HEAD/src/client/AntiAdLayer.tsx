/**
 * The anti-ads layer: four defences, one badge.
 *
 * Mounted on the composer's input dock, same slot dsh-ads's layer uses but at
 * a later order, so its write-through runs after dsh-ads's layer is live.
 *
 *  - L1, settings write-through: flips every dsh-ads placement switch off
 *    through dsh-ads's own storage contract, and keeps it off by listening to
 *    dsh-ads's own broadcast.
 *  - L2, DOM scrub: a MutationObserver catches anything that renders anyway
 *    (a placement dsh-ads switches on outside its settings, a future version
 *    that stops reading them) and removes it by shape. The scrub identifies
 *    its own badge by **DOM node reference** (`badgeRef`), not by the
 *    `data-dsh-anti-ads` attribute — dsh-ads 0.2 copies that attribute onto
 *    its own root as a honeypot, so any attribute-based skip would spare the
 *    ads too.
 *  - L3, fetch short-circuit: the dynamic-tier registry request is answered
 *    with an empty list before it leaves the page.
 *  - L4, retire broadcast: dispatches dsh-ads's own `dsh-ads:retired` event,
 *    the module-scope "关闭所有广告" state its 480882a introduced. The layer
 *    checks that flag before rendering anything at all, so the broadcast
 *    retires it wholesale — the one suppression the write-through cannot
 *    express, and the one that survives dsh-ads ignoring its own settings.
 *
 *    dsh-ads 0.2 stamps the retire event with a module-private `Symbol()`
 *    Token that the listener checks, defeating a bare forged event. L4 has
 *    two answers: (a) a `CustomEvent` constructor patch (installed at module
 *    load in [settings.ts](./settings.ts)) captures the Token the first time
 *    dsh-ads's own `retireAds()` runs, after which `broadcastAdsRetired`
 *    forges events the listener accepts; (b) a MutationObserver (this file,
 *    gated on `deep`) auto-clicks dsh-ads's own "关闭所有广告" button the
 *    moment it appears in the DOM — triggering `retireAds()` through
 *    dsh-ads's own code path, which retires the layer and captures the Token
 *    in one step. Before the Token is captured, L1–L3 carry the load.
 *
 * All four are independent: any one failing leaves the other three standing,
 * and disabling one (from the badge or the settings page) leaves the others
 * running.
 *
 * The badge is deliberately minimal — a corner chip with a count and four
 * switches. No fake antivirus windows, no decoy close buttons: the joke of
 * dsh-ads is excess, and the point of this plugin is that the joke stops.
 */

import { useEffect, useRef, useState, type CSSProperties } from 'react'
import { createPortal } from 'react-dom'
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import { scrubAds } from './scrub.ts'
import { hasRetireToken, useAdsGuard, useAntiAdsSettings } from './settings.ts'
import { makeT, zh } from './locales.ts'

/**
 * dsh-ads's registry route, mirrored from its `protocol.ts`. Used to answer
 * the dynamic-tier fetch with an empty list instead of letting it through.
 */
export const REGISTRY_ROUTE = '/dsh-ads/registry.json'

/** The empty payload dsh-ads's client accepts; `plugins` must be an array. */
const EMPTY_REGISTRY = JSON.stringify({
  generated: new Date(0).toISOString(),
  source: 'blocked',
  freshDays: 0,
  plugins: [],
})

/**
 * Text that identifies dsh-ads's "关闭所有广告" button in the DOM. Two
 * variants exist: the settings-page button ("立刻关闭所有广告（刷新后恢复）")
 * and the poster's ⚙ menu button ("关闭所有广告"). Matching on the shared
 * substring catches both without coupling to either button's exact label or
 * location — and the text is a user-facing string dsh-ads is unlikely to
 * change without a major version.
 */
const RETIRE_BUTTON_TEXT = '关闭所有广告'

/**
 * Find and click dsh-ads's own "关闭所有广告" button, if one is currently in
 * the DOM and enabled.
 *
 * This triggers `retireAds()` through dsh-ads's own code path — the only way
 * to obtain the module-private Symbol Token its listener checks (see
 * [settings.ts](./settings.ts) for the Token capture). The click also retires
 * the layer directly: `retireAds()` sets the module flag and dispatches the
 * event with the real Token, the `useRetired` listener accepts it, and the
 * AdLayer returns null.
 *
 * @returns true when a button was found and clicked.
 */
function clickRetireButton(): boolean {
  const buttons = document.querySelectorAll<HTMLButtonElement>('button[type="button"]')
  for (const btn of buttons) {
    if (btn.disabled) continue
    if (!btn.textContent?.includes(RETIRE_BUTTON_TEXT)) continue
    // Skip our own badge panel: its buttons never carry this text, but the
    // guard is cheap insurance against a future label collision.
    if (btn.closest('[data-dsh-anti-ads]') !== null) continue
    btn.click()
    return true
  }
  return false
}

/** z-index of the badge: above every dsh-ads placement, and the CSS maximum. */
const BADGE_Z_INDEX = 2_147_483_647

const chipStyle: CSSProperties = {
  position: 'fixed',
  right: 12,
  bottom: 12,
  zIndex: BADGE_Z_INDEX,
  display: 'flex',
  alignItems: 'center',
  gap: 6,
  padding: '5px 10px',
  borderRadius: 999,
  background: 'rgba(38, 38, 38, 0.92)',
  color: '#e5e5e5',
  fontSize: 12,
  fontFamily: 'system-ui, sans-serif',
  lineHeight: '16px',
  whiteSpace: 'nowrap',
  border: '1px solid rgba(255, 255, 255, 0.18)',
  boxShadow: '0 1px 4px rgba(0, 0, 0, 0.35)',
  cursor: 'pointer',
  userSelect: 'none',
}

const panelStyle: CSSProperties = {
  position: 'absolute',
  right: 0,
  bottom: 'calc(100% + 6px)',
  width: 224,
  background: '#fff',
  color: '#333',
  borderRadius: 6,
  border: '1px solid rgba(0, 0, 0, 0.18)',
  boxShadow: '0 4px 16px rgba(0, 0, 0, 0.18)',
  fontFamily: 'system-ui, sans-serif',
  overflow: 'hidden',
}

const panelHeadStyle: CSSProperties = {
  padding: '7px 10px',
  fontSize: 11,
  fontWeight: 700,
  letterSpacing: 0.5,
  color: '#666',
  borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
}

const rowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  padding: '6px 10px',
  border: 0,
  borderBottom: '1px solid rgba(0, 0, 0, 0.06)',
  background: 'transparent',
  color: '#333',
  fontSize: 12,
  fontFamily: 'system-ui, sans-serif',
  textAlign: 'left',
  width: '100%',
  cursor: 'pointer',
}

const noteStyle: CSSProperties = {
  padding: '6px 10px 8px',
  fontSize: 10,
  lineHeight: '14px',
  color: '#999',
}

/** One switch row. */
function Switch({ checked, label, onClick }: {
  readonly checked: boolean
  readonly label: string
  readonly onClick: () => void
}) {
  return (
    <button type="button" style={rowStyle} onClick={onClick} aria-pressed={checked}>
      <span aria-hidden="true" style={{ width: 12, color: checked ? '#2e7d32' : '#bbb' }}>{checked ? '☑' : '☐'}</span>
      {label}
    </button>
  )
}

/**
 * Mount the layer.
 * @param props - the slot-provided locale seat (`t`), defaulting to the
 * bundled zh dict for direct mounts outside the slot system.
 * @returns a portal carrying the badge and panel, or null when suppressed.
 */
export function AntiAdLayer({ t = makeT(zh) }: { t?: PropsLocale<'dsh-anti-ads'>['t'] }) {
  const [settings, setSettings] = useAntiAdsSettings()
  const { enabled, aggressive, blockDynamic, deep } = settings
  // How many elements L2 has removed this page load. Not persisted: a counter
  // that survives reloads would be a claim nobody can check.
  const [scrubbed, setScrubbed] = useState(0)
  const [open, setOpen] = useState(false)
  const scrubbedRef = useRef(0)
  // The badge's own DOM root. Passed to scrubAds as the `skip` scope so the
  // scrub never removes itself — by DOM reference, not by attribute (dsh-ads
  // 0.2 copies `data-dsh-anti-ads` onto its own root as a honeypot).
  const badgeRef = useRef<HTMLDivElement>(null)
  const setter = (patch: Partial<typeof settings>) => setSettings({ ...settings, ...patch })

  // L1 + L4: write-through on mount, and re-suppress whenever dsh-ads's own
  // storage contract announces a change back to on — writing the all-off
  // object and re-broadcasting the retire event (idempotent, so re-dispatch
  // is free).
  useAdsGuard(enabled, deep)

  // When the master switch is turned off, restore dsh-ads's defaults so the
  // ads come back. This must run *after* the guard above has unsubscribed —
  // its broadcast would otherwise be caught by the still-active guard
  // listener and suppressed again. React runs cleanups before later effects
  // in the same commit, and `useAdsGuard` is declared first, so by the time
  // this effect runs the listener is gone.
  const prevEnabled = useRef(enabled)
  useEffect(() => {
    if (prevEnabled.current && !enabled) restoreAdsDefaults()
    prevEnabled.current = enabled
  }, [enabled])

  // L2: watch for anything dsh-ads renders despite the write-through. The
  // observer fires on every removal too, so the callback must be idempotent —
  // scrubAds returning zero on a clean tree is what keeps this from looping.
  // The badge node is passed as `skip` so the scrub never removes itself:
  // dsh-ads 0.2 copies the `data-dsh-anti-ads` attribute onto its own root, so
  // attribute-based self-identification is no longer safe (see scrub.ts).
  useEffect(() => {
    if (!enabled || !aggressive) return
    const scrub = () => {
      const removed = scrubAds(document, badgeRef.current)
      if (removed > 0) {
        scrubbedRef.current += removed
        setScrubbed(scrubbedRef.current)
      }
    }
    scrub()
    const observer = new MutationObserver(scrub)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [enabled, aggressive])

  // L3: answer the dynamic-tier registry request with an empty list. dsh-ads's
  // client treats a broken response the same as an absent one, so the whole
  // route can be short-circuited without touching the built-in banners' code
  // path. Matched on the path after stripping any query/hash — a cache-buster
  // appended by the shell or a future dsh-ads must not dodge the block.
  // Restored on teardown; skipped entirely where fetch is absent.
  useEffect(() => {
    if (!enabled || !blockDynamic) return
    const original = window.fetch
    if (typeof original !== 'function') return
    const patched: typeof fetch = (input, init) => {
      const href = typeof input === 'string' ? input : (input instanceof URL ? input.href : input.url)
      const path = href.split(/[?#]/, 1)[0] ?? href
      if (path.endsWith(REGISTRY_ROUTE)) {
        return Promise.resolve(new Response(EMPTY_REGISTRY, {
          status: 200,
          headers: { 'content-type': 'application/json' },
        }))
      }
      return original.call(window, input, init)
    }
    window.fetch = patched
    return () => { window.fetch = original }
  }, [enabled, blockDynamic])

  // L4 (Token capture): dsh-ads 0.2 stamps its retire event with a
  // module-private Symbol that the listener checks — a bare forged event is
  // silently ignored. The Token can only be obtained by intercepting
  // `new CustomEvent('dsh-ads:retired', { detail: TOKEN })` at the moment
  // dsh-ads's own `retireAds()` runs. This observer watches for dsh-ads's
  // "关闭所有广告" button appearing in the DOM (the settings page's, or the
  // poster's ⚙ menu's) and clicks it the instant it shows up — triggering
  // `retireAds()` through dsh-ads's own code path, which retires the layer
  // (the listener sees its own real Token) and lets the CustomEvent patch in
  // settings.ts capture the Token for future `broadcastAdsRetired` calls.
  //
  // Runs only while the Token has not yet been captured: once the Token is
  // in hand, `broadcastAdsRetired` forges events the listener accepts, and
  // the auto-click is no longer needed. Gated on `deep` — the same switch
  // that gates the broadcast — so the user can opt out of both together.
  useEffect(() => {
    if (!enabled || !deep) return
    if (hasRetireToken()) return
    const scan = () => {
      if (hasRetireToken()) return
      clickRetireButton()
    }
    scan()
    const observer = new MutationObserver(scan)
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [enabled, deep])

  // Disabling the master switch is the honest "恢复广告" control: the effect
  // above restores dsh-ads's defaults once the guard has unsubscribed. One
  // caveat — if L4 had already broadcast the retire event, dsh-ads's layer
  // stays retired until the next reload: that flag is deliberately one-way.

  if (!enabled) return null
  return createPortal(
    <div data-dsh-anti-ads ref={badgeRef}>
      <div
        style={chipStyle}
        role="button"
        tabIndex={0}
        aria-expanded={open}
        onClick={() => setOpen(!open)}
        onKeyDown={(event) => {
          if (event.key === 'Enter' || event.key === ' ') setOpen(!open)
        }}
      >
        <span aria-hidden="true">🛡</span>
        {scrubbed > 0 ? t('blockedCount', { count: scrubbed }) : t('blockedAll')}
      </div>
      {open && (
        <div style={panelStyle}>
          <div style={panelHeadStyle}>{t('panelTitle')}</div>
          <Switch checked={enabled} label={t('panelEnabled')} onClick={() => setter({ enabled: false })} />
          <Switch checked={aggressive} label={t('toggleAggressive')} onClick={() => setter({ aggressive: !aggressive })} />
          <Switch checked={blockDynamic} label={t('toggleBlockDynamic')} onClick={() => setter({ blockDynamic: !blockDynamic })} />
          <Switch checked={deep} label={t('toggleDeep')} onClick={() => setter({ deep: !deep })} />
          <div style={noteStyle}>
            {t('panelNoteBefore')}
            {t('panelNoteAfter')}
          </div>
        </div>
      )}
    </div>,
    document.body,
  )
}

/**
 * Restore dsh-ads's default (all-on) settings through its own storage
 * contract. Called when the master switch is turned off, so "disable
 * blocking" and "bring the ads back" are one action.
 */
function restoreAdsDefaults(): void {
  const defaults = {
    gutter: true,
    feed: true,
    popup: true,
    speed: true,
    scare: true,
    poster: true,
    muted: false,
  }
  try {
    localStorage.setItem('dsh-ads:settings', JSON.stringify(defaults))
  } catch {
    // Swallowed: the broadcast below is the part that reaches live state.
  }
  dispatchEvent(new CustomEvent('dsh-ads:persist-changed', { detail: 'settings' }))
}
