# AGENTS.md — dsh-catppuccin

> ⏸ **可选改动：做之前必须先让维护者选**。issue #28 有两条路，**只有 A 被批准做了**：
>
> - **A（已实施并转正：`0.6.3-beta.3` 首发 → `0.6.3` 进 `latest`，`0ce81ff`）**：给输入卡下方的 dock 行
>   （模型 / 统计 / 上下文用量）补一条地面色背板带，解决滚动正文穿透状态栏。文档
>   `docs/issue-28-composer-dock-backdrop.md`。
>   **issue #29 起（`0.6.4-beta.0`）材质改磨砂**：同色 α70~84% + `blur` + 顶部 18px `mask` 淡入，几何未变，
>   已随 **`0.6.4` 转正进 `latest`**（2026-10-21）；见 `docs/issue-29-dock-glass-veil.md`。
>   **α 的 70% 下限别动**——出厂 clear 预设是 `blur: 0`，再低就是 #28 复发。
> - **B（只是方案，未实施、不得自行开工）**：把输入卡与 dock 合成**一个** 24px 圆角框、中间加一条
>   发丝分割线，并做成设置里的开关（默认关 = A 的观感）。全量方案在
>   `docs/issue-28-fused-composer-plan.md`（CSS 草案 / 8 处改点 / 测试与变异 / 风险 / 约 3–4 小时）。
>
> **硬规矩**：B 属于特性（`0.7.0`），**动手前必须让维护者明确回答「做 / 不做」**。没点头就只读方案，
> 不要改代码、不要 commit、不要顺手「顺便把开关加上」。同样地，B 的文档更新不等于批准实施。
>
> ⚠️ **issue #28 已于 2026-10-19 由报告人 `TWFU-wcy` 自行关闭**（`stateReason=COMPLETED`，关闭前 0 条评论）
> **——关闭只代表「报告人认为 A 对他有效」，不代表 B 被批准或否决，也不代表维护者验收过。**
> 别把「issue 关了」当成 B 可以开工作或者可以删方案文档的信号。#29 同样由该报告人于 2026-10-20 自行关闭。

给本仓库的 Agent（以及人类维护者）的项目速览与发版 SOP。开始改代码前请先读「项目定位与核心目标」与「项目身份速览」，**惯例是这里踩过坑的集结点**；文末「与报告人协作」「本机测量资产」两节是本轮（issue #12 / #13）新增的。

## 项目定位与核心目标（判断「该不该做」的准绳）

**核心目标是「适配」，不是「设计配色」**：按 [Catppuccin 官方源配色](https://github.com/catppuccin/catppuccin)（色板 v1.8.0——上游 2.0.0 起根目录 `palette.json` 已删，现取自 npm `@catppuccin/palette@1.8.0`，见下）把 DeepSeek Harness 的官方 `--dsw-*` token 体系**完整**映射成四个风味。**官方色板是准绳，不是教条**——官方取值在 DSH 的实际用法下真不成立时（有证据）可以改，走规则 1；**玻璃质感（Glassmorphism）是叠加在正确配色之上的视觉皮肤，属附带目标**——它只改材质，不改配色。

权威数据源（由 `scripts/generate-palettes.mjs` 读取，均在仓库外的缓存）：

| 文件 | 作用 |
|---|---|
| `<缓存>/.cache/dsh-ref/dsw-tokens.json` | 官方 design-platform.css 解析出的 `--dsw-*` token 全表——**要全覆盖，不许漏 token** |
| `<缓存>/.cache/dsh-ref/catppuccin-palette.json` | 官方 Catppuccin 色板 v1.8.0——**默认取色来源**（官方取值在 DSH 下确实不成立时按规则 1 的例外流程偏离） |
| 产物 `src/client/palettes.ts` | 生成物；同源产物还有 `themes/`（`pnpm gen:themes`）与 shiki token 表 |

> 路径基准：脚本里写的是 `join(__dirname, '..', '..', '.cache', 'dsh-ref')`（**相对 `scripts/`，往上两级**），
> 本机实测 = `D:\Vibe-Coding\.cache\dsh-ref\`（含 `dsw-tokens.json`、`catppuccin-palette.json` 与各 tag 的
> `design-platform-*.css`）。换机器时改成自己的缓存盘即可。
>
> ⚠️ **缓存不在仓库里 ⇒ 重建时必须钉住上游 SHA，否则「换了上游 tag」与「正常改配色」在 `git diff` 里长得一样。**
> 这个目录被清掉过一次（2026-10-08 才发现 `pnpm gen:palettes` 报 ENOENT），重建配方写在 `generate-palettes.mjs`
> 头部注释里。**重生成一律带 `--pin <上游 commit SHA>`**，它把 `// UPSTREAM_PIN: <sha>` 写进 `palettes.ts` 头部
> 当审计锚点；⚠️ 这行是**一次性**的——下次不带 `--pin` 再生成就会消失，所以它是个人守的约定，不是持久配置。
> 当前锚点：**`dsh-v0.2.0-rc.2` = `639ed015397290b3745d163aafe02ffee4aa3f84`**（2026-10-08 重建：190 token/方案，
> 与出厂包快照交叉校验 380/380 语义一致）。另：上游色板仓库 2.0.0 重组后根目录 `palette.json` 已删，
> 改从 npm 包 `@catppuccin/palette@1.8.0` 的 `esm/palette.js` 取（同一份 v1.8.0 数据）。

> **两层「官方」不要混淆**：(a) **Catppuccin 源色板** —— 取色来源；(b) **DSH 官方 token 的取值与语义** —— 被适配对象。改 (b) 是本插件存在的理由（例如整族重映射 `brand-primary` 到风味蓝），不需要理由；改 (a) 才需要证据（规则 1）。

### 由此推出的六条硬规则

1. **以官方色板为默认来源，偏离需要证据。** 每个 `--dsw-*` 的取值默认是官方 26 色本身、或由它们 `color-mix` 出来的中间值；**不得凭观感发明色相**（「这个蓝有点闷，换 sapphire」不是理由）。但当官方取值**在 DSH 的实际用法下确实不成立**时——例如该色被 DSH 用在对比度不达标的场景、或该 token 在 DSH 里被用在官方设计没有的场景——**可以改**，过下面三条即可：
   - ① 有可复核的证据（实测对比度数字 / 用户 issue / 上游设计差异）；
   - ② 已穷尽「不换色相」的手段（混色目标、层级档位）仍不达标；
   - ③ 在代码注释 + CHANGELOG 写明**与官方取值的差异及理由**，并补上锁定该决定的断言。
2. **改颜色只改映射表。** 调 `scripts/generate-palettes.mjs` → `node scripts/generate-palettes.mjs --pin <上游 SHA>`（**必须带 `--pin`**，理由见上）→ 提交生成物；手改 `palettes.ts` 下次生成即被覆盖。
3. **对比度问题先换手段，再换颜色**：第一步永远是不换色相的调整——混色目标（`base` → `crust`）与层级档位（先例：issue #7、issue #11、VV）。仍不达标时按规则 1 的例外流程偏离并记录：已有两个**记录在案的有意偏离**——① Latte `--dsw-static-blue-900`：该步被 DSH 当作浅色徽章（hero「预览版」）上的**文字**用，通用浅色计划把它混向 `base` 会洗成淡色，故改混向 `text`（`generate-palettes.mjs` 内有完整注释）；② `brand-primary` 整族：DSH 官方品牌蓝与 Catppuccin 主题冲突，直接重映射为风味蓝（生成器头部注释说明）。
4. **玻璃层不得改变配色语义。** 玻璃只动 alpha / blur / rim / shadow，外加 #25 起的**地面氛围场**（同色系 wash + 柔光斑，纯 CSS、token 生成、随开关进出——它靠半透明填充「透出」被感知，不是 blur）；开关关闭时必须回到与官方色板逐 token 一致的纯色形态。**推论（issue #13 实测，issue #25 修订前提）**：本皮肤把页面地面画成受控的**低频场**（#13 时纯色；#25 起为 wash + 光斑——周期几百 px 的渐变，`blur(≤40px)` 对它仍是**近似恒等**），所以「背后只有地面」的玻璃面上加 `backdrop-filter` 依旧没有收益——填充逐像素不变（隐藏该面内容后 A/B：气泡 **0/19184 像素**，测于纯色时代），代价却是 Chromium 每帧回读 backdrop（**半径不参与**；`will-change` / `contain` 绕不开，只有 `none` 免提升）。**新增 blur 前先问一句「这个面背后是不是只有『地面』这一层内容（纯色或低频氛围场）」**，`tests/glass-css.spec.ts` 双向锁定（地面之上的面不得有 blur、覆盖移动内容的必须保留）。唯一已知的可见副作用不是降级：面变成合成层后，**面内文字会重抗锯齿**（≤16/255 侧栏、≤64/255 气泡）。
   **#25 附带陷阱（2026-10-15 实测）：`--dsh-glass-ambience` 的加权表达式必须内联在 `background` 里，不能只存进中间 custom property。** CDP 实测（`.debug/issue-25/probe-amb.js`）：亮度变量变化时，`background` 中**直用**的表达式（光斑、wash 末端）正确塌缩，而经过中间变量的 wash 加权**保持旧值不重算**（Chromium 的失效传播在此不可靠）。亮度拉满 ⇒ ambience = 0 ⇒ 整个氛围场塌缩回纯白 / 纯黑，这条承诺靠的就是「直用」。护栏 = `tests/glass-css.spec.ts` 的 `ground ambience (issue #25)` 三组。
   **推论二（issue #19 实测，同样必须记）：不要把 blur 加在「托管浮层」的容器上。** 带 `backdrop-filter` 的元素会成为其后代的 **backdrop root**，后代只能读到**该元素自己画的那层**（页面内容不在其中）；命令面板 `[data-trigger-menu]` 就挂在 `[data-composer-card]` 的 `conversation.input.overlay` 锚点里，且整块**悬在卡盒之外**，于是它自带的 `blur(40px)` 读空 ⇒ 底下的转录原样透出。**推论：材质必须整体搬到容器内部的 `::before` 材质面（填充 + blur 都要，别只搬 blur），容器本体保持零绘制**——这正是上游 `MenuSurface.module.css` 的做法（`isolation: isolate` 外壳 + `z-index:-1` 材质面，其注释原话就是「keeps nested menus free of an ancestor backdrop root」）。`isolation: isolate` **不是** backdrop root，可以放心用。护栏 = `tests/glass-css.spec.ts` 的 `backdrop-root hygiene` 一组；判定手法与实测数字见技能 `css-backdrop-root-probe`（在 `~/.workbuddy/skills/`，**不在本仓库**）与 `docs/issue-19-palette-blur.md`。
   **推论三（issue #22 实测）：`role='menu'` 不是菜单表面的身份。** 菜单座位的真源 = **`data-menu-material='translucent'`**（MenuSurface 自带钩子，0.1.7-rc.2 与 0.2.0-rc.2 皆有）；且填充/blur 一律**不画在表面上**，而是覆写它自带材质面读的两个 token：`--dsw-menu-surface-fill` 与 `--dsw-menu-backdrop-filter`（stock：58%/45% 填充 + `blur(40px) saturate(150%)`）。理由是 0.2.0 起模型弹层**翻转了 role**（外表面 `role=group`，内层滚动列表 `.groups` 拿了 `role=menu`，出处 `dsh-client-ui-model-selection/lib/client.js` 的 `pane === "model" ? "group" : "menu"`）——把配方挂在 role 上会画到列表上（双框 + 贴底），挂在表面上则是推论二的 backdrop root 形状。**凡 `[role='menu']` 选择器必须带守卫对** `:not([data-menu-material]):not([data-menu-material] *)`（前者跳过表面、后者跳过表面内部的一切，如模型列表；二者保留给手写菜单，如 `dsh-client-ui-schedule` 的 TaskMenu）。rim 用 `outline`（画在负 z 子元素之上、不改盒模型）。同族陷阱：MenuGroup 的分组标题钩子是 `[data-menu-group-heading]`（`> :first-child` 会被 0.2.0 前置的 1×1 哨兵 `span[data-menu-group-start]` 吃掉）。护栏 = `tests/glass-css.spec.ts` 的 `menu seat + un-stroked highlights (issue #22)` 一组。
5. **boot 关键路径上的注册一律走 `tolerantRegistration`（issue #23）。** entry 的 `apply()` 一同步抛错 → entry FAILED → 整个 `web boot` 中止（`web boot: N entry(s) did not activate`）→ 官方壳崩溃救援 `disableAllPlugins()` 把**所有**第三方插件关停；而 `ctx.effect` 是同步执行并原样 rethrow 的（`ctx.slots.inject` 在槽已声明时同样同步）。⇒ **凡在 apply 同步路径上调用外部注册表**（`ctx.locale.register/addLanguage`、`theme.register`、`ctx.slots.register`、宿主 `webServer.register`）都必须经 `src/registration-tolerance.ts` 的 `tolerantRegistration`：已知「他方已占用」形态（语言包抢 BCP 47 ID、双份安装抢路由/slot/theme id）静默跳过，其余 warn 后同样跳过——没有任何一项注册值得用户的全套插件陪葬。⚠️ **漏包在本地测不出来**：`tests/registration-tolerance.spec.ts` 只穿过已包好的调用路径，全仓库没有任何用例扫 `src/client/index.ts` 的调用点（2026-10-14 核实，此前此处写的「变异检查会红」不成立）——漏包只会在真机 boot 上暴露，所以新增注册点时必须手工对照上面这份调用面。6. **「文档优先」的采纳必须先问「本地有没有更晚、还没落盘的意图」（issue #31）。** 持久状态是三层：
   ① localStorage 即时缓存 ② ThemeRuntime 偏好 ③ 官方 settings 文档（权威）。三者靠
   「本地改 → 300 ms 防抖 → 写文档 → 文档回声 → 采纳」收敛，**回声永远可能晚于下一次本地改**。
   `applyScopeSnapshot()` 的既有判据只有「本地 == 文档 → 跳过」，它不知道本地还有一次变更在队列里或在途
   ⇒ 真机实测：点风味后 0.1–1.4 s，旧回声把 localStorage 与运行时一起回滚，随后的 flush 再把回滚值写进
   `cordis.patch.yml`，**连冲突横幅都没有**（判成 `written`/`noop` 而非 `stale`）。所以任何新增/修改的采纳
   路径都必须过两道闸：**① `pendingLocalSection`**（本地最新未落盘意图，flush 结清才清）**② revision 高水位**
   （revision 倒退 = 过期视图）。真正采纳时还要 `cancelDurablePersist()` + 丢 base revision，否则排队的
   flush 会把回滚值写盘。⚠️ 同一族的两个陷阱：`reapplyThemePrefs()` **不得 dispose-all**（上游 disposer 会把
   当前偏好重置成默认值，见 §5 的注记），以及 **restore 不是一次 pick**（记录 `liveBuiltinPick` 会让
   `builtinPickWins()` 之后否决所有风味恢复）。护栏 = `tests/reentrancy.spec.ts` 的
   `issue #31: a late document echo…` 一组（5 条，五组变异都验证过会红），方案与真机取证见
   `docs/issue-31-theme-switch-echo-race.md`。

### 用这条准绳做过的判定（可引用的先例）

- 2026-09-15 **驳回** MM（暗色主 accent 提亮）：驳回理由**不是「官方色不许动」**，而是它拿不出「官方取值在 DSH 下不成立」的证据（`#89b4fa` / `#8caaee` 在 `crust` 上远高于 AA，属审美偏好而非缺陷），且 `brand-primary` 已被 `tests/palettes.spec.ts` 的断言锁成契约（不再写行号——行号会随文件漂）。想要更亮的主操作色走 **K（token 覆盖）**，不走 palette。
- 2026-09-15 **立项** VV（success / warn tertiary 对比度）：实测 3.18~4.37 低于 AA，就是「官方取值在本项目不成立」的那类证据；修法仍走第一步（只换混色目标、色相不变）——规则 1 与规则 3 各占一半。

两次判定的完整理由见 `docs/plugin-improvements.md`（「六、2026-09-15 复核」）。

## 项目身份速览：三套名字，不要混淆

这个仓库同时存在三套不同的「名字」，改动前必须先分清（2026-08 仓库改名时踩过一次坑）：

| 名字 | 值 | 说明 |
|---|---|---|
| GitHub 仓库名 | `NoNameLeGo/dsh-catppuccin-theme` | 已从 `dsh-catppuccin` 301 改名，GitHub 自动跳转旧链接 |
| npm 包名 | `@nonamelego/dsh-catppuccin` | **不要改成 `-theme`**——安装/更新检查代码都依赖它（`src/update-check.ts` 的 `PACKAGE_NAME`、`cordis.patch.yml` 的 `name`、README 里的安装/升级命令） |
| 插件 ID / 显示名 | `dsh-catppuccin` | `src/index.ts` 的 `export const name`；运行时的 Cordis 插件身份，不可改 |

- 代码/配置里 `grep dsh-catppuccin` 命中的大多数**都不该改**。只有**完整的 GitHub URL**（`github.com/NoNameLeGo/dsh-catppuccin`，不带 `-theme`）才需要更新为新仓库名。
- npm 包名、插件 ID、本地路径 `link:D:\Vibe-Coding\dsh-catppuccin`（README 里的本地开发命令）一律保持原样。
- `git remote` 的 `origin` 指向 `https://github.com/NoNameLeGo/dsh-catppuccin-theme.git`。

## 上游形态与维护核心（2026-09-22 定）

**维护核心 = 官方的 web + desktop。** 官方上游是 monorepo
[`deepseek-ai/deepseek-harness`](https://github.com/deepseek-ai/deepseek-harness)：

| 上游位置 | 是什么 | 与本插件的关系 |
|---|---|---|
| `apps/web` | Web GUI（`dsh web` / `web` profile） | **核心**：`--dsw-*` token 体系与玻璃层的适配对象 |
| `apps/desktop` + `apps/desktop-host` | 官方 Electron 桌面壳（`private: true`；**已作为客户端发行**，2026-10-02 本机装机版 = `@deepseek-ai/dsh-desktop@0.2.0-rc.2`，**2026-10-17 起已升到 `0.2.1-rc.2`**，仍在开发迭代），启动 `$DSH_HOME/profiles/desktop` | **核心**：装/升走**应用内插件界面**（见下「两个壳两条路」），**不是** `--profile desktop` 那条命令 |
| `apps/cli` → npm `@deepseek-ai/dsh` | CLI：profile 启动 / `dsh plugin` 转发 pnpm | 安装与更新检查的宿主；⚠️ **对 `desktop` 这个 profile 名会硬拒**（见下） |
| （社区）`anywhere-labs/dsh-desktop`（原名 `deepseek-harness-desktop`） | 第三方桌面壳，**同一个 `profiles/desktop` 路径**；yarn workspace 含 `dsh-plugin-desktop` / `dsh-desktop-next` / `dsh-community-market`（内置插件市场）等 | 兼容保留，非核心；装/升**走应用内 DSH 终端的命令**（见下） |

**两个桌面壳都不是「另一个 DSH」**（2026-09-24 核对，别按印象写）：

|  | 官方壳（`apps/desktop-host`） | 社区壳（`anywhere-labs/dsh-desktop`） |
|---|---|---|
| 自带的 DSH 版本 | 与官方 monorepo 同步（`app.asar` 内 `dsh/package.json` = `@deepseek-ai/dsh-desktop-runtime`，2026-09-30 实测 **0.2.0-rc.2**；这个 app 自 0.1.7-alpha.1 起存在，**未发 npm**） | 无自带版本，启动**用户自己装的** `@deepseek-ai/dsh` |
| Web 端口 | 固定 `--port 19387`（`src/index.ts` 写死） | 默认 `43120`（`DESKTOP_DEFAULT_WEB_PORT`），仅绑定冲突时顺序 +1（≤32 次）；2026-08-21 起「prefer a stable loopback port」 |
| 识别信号 | ⚠️ **profile 进程里没有专用信号**（2026-09-24 证伪，见下）：`DSH_DESKTOP_NODE_EXECUTABLE` 只注入给包安装子进程；可用替代信号 `process.versions.electron` | `desktopProfiles` 服务；**`dsh-desktop-next` 重写版同时也会设 `DSH_DESKTOP_NODE_EXECUTABLE`** |

⇒ 结论：**settings seam 的适配与「哪个壳」无关**，只取决于该壳启动的那份 DSH 提供哪个服务（官方壳自带 0.2.x 运行时 → `configForms`；
社区壳跟随用户所装版本）。两路识别信号则同时覆盖两个壳，且官方壳那条路在 `dsh-desktop-next` 上也成立。

### 官方桌面壳的插件相关契约（2026-09-30 在 0.2.0-rc.2 上复核，全文见 `docs/desktop-0.2.0-adaptation-audit.md`）

> **2026-10-17 在 0.2.1-rc.2 上复核（`docs/desktop-0.2.1-adaptation-audit.md`）**：下表逐条仍成立
> （窗口材质、标题栏取色 token、`dsh-app://` origin、`ELECTRON_RUN_AS_NODE` 识别、外链转发都未变）。
> 0.2.1 新增的只有两条**契约级**变化，改设置/发布前必看：
> ① **settings 快照不再带 `mode`**（上游删掉了「按页面本地性选存储」的分支，`memory` 模式不存在了）
> —— 判可用性只能写成「`status === 'ready'` 且**没有**显式 `memory`」，写回 `mode === 'host'` 会让
> 持久化在 0.2.1 上**静默关闭**；② **插件兼容判定正在从 `peerDependencies` 迁到 `engines.dsh`**
> （有 `engines.dsh` 就只认它、忽略 peer；缺失才回落 peer），我们目前靠回落「永远兼容」。

本机官方壳自带 `@deepseek-ai/dsh-desktop-runtime`（写这份表时是 `0.2.0-rc.2`，**2026-10-17 已升到
`0.2.1-rc.2`**；下表是 0.2.0.rc.2 时的快照，2.1 上逐条复核仍成立），它与插件耦合的面就这几条，
改动玻璃/设置/持久化前先对一遍：

| 契约 | 位置（0.2.0-rc.2） | 插件侧 |
|---|---|---|
| 页面 origin 是自定义协议 `dsh-app://app/`，Web host 仍在 `http://127.0.0.1:19387`（**写死**） | `lib/main.js` 的 `SCHEME`；`dsh-desktop-host/lib/index.js` 的 `runProfile({ args: ['--no-open','--port','19387'] })` | 不依赖 origin 做持久化（走 host 侧文档） |
| Host 由 **Electron 以 node 模式**起（`ELECTRON_RUN_AS_NODE=1`，`DSH_DESKTOP_NODE_EXECUTABLE` 仍只给包安装子进程） | `lib/main.js` `DesktopHostProcess.start()` → `desktopNodeEnvironment(this.node, void 0, …)` | `isElectronRuntime()`（`process.versions.electron`）仍是唯一 profile 进程信号 |
| Windows：preload 给 `<html>` 挂 `data-windows-titlebar` + `--dsh-windows-titlebar-height: 40px`，`ui-layout` 据此在所有列上方预留标题栏 | `apps/desktop/src/preload-windows.ts` / `windows-layout.ts` | 顶部渐隐在该标记下 `display:none`（`glass.module.css`）——那条里没有滚动内容，模糊是恒等读取 |
| Windows 标题栏取色：preload 插探针读 `--dsw-specific-sidebar-fill`（填充）与 `--dsw-alias-label-primary`（符号），经 1×1 canvas 折算成 `rgba()` 交 `setTitleBarOverlay` | 同上 | 两个 token 必须解析成不透明色（`tests/palettes.spec.ts` 的护栏用例）；2026-09-30 真机实测发到主进程的是 `rgba(24,24,37,1)` / `rgba(205,214,244,1)`，窗口 `y≥32` 像素正好 `#181825` |
| Windows 标题栏菜单（应用/编辑）用 shadow DOM 挂在 `[data-shell-overlay]` 之后，消费 4 个 `--dsw-alias-*` token + `--dsw-font-family` | `apps/desktop/src/preload-menu.ts` | 全在映射表内；插件不碰 `[data-shell-overlay]` |
| `html[data-ds-theme-source]` → 主进程 `nativeTheme.themeSource`（原生 chrome / Platform 登录页 / macOS vibrancy 跟随） | `apps/desktop/src/preload-theme.ts` | 插件用 `theme.setTheme()` 强制亮暗，实测桌面下 `themeSource=dark` 与风味一致 |
| macOS：`html[data-platform='darwin'] body` 把 `--dsw-specific-menu` 覆写成 94% 不透明；主窗口 `vibrancy: sidebar` | `design-platform.css` 的 darwin 块；`lib/main.js` `createWindow()` | ⚠️ **未适配**：我们无条件覆写该 token，macOS 上的近不透明变体丢失；本机无法验证 |
| **外链一律交系统浏览器**：主窗口 `setWindowOpenHandler` 对 `http(s)` 协议调 `shell.openExternal`（壳内 deny）；`will-navigate` 拦下非 `dsh-app:` 且非同源的导航，`http(s)` 同样转发 `shell.openExternal` | `app.asar` 的 main（2026-10-11 逐条 grep 取证，共三处 handler：工作区 view / guest / 主窗口） | `LinksRow`（反馈/star 行）的 `target="_blank"` 链接在官方壳里 = 打开系统默认浏览器；**不带 target 也不会把 UI 导航走**（同样被 `will-navigate` 转发），但带上是显式契约 |

> 桌面壳专属 token `--dsw-desktop-window-tint` 只被欢迎窗口（`renderer/welcome.html`）消费，那份窗口自带整套字面量 token
> ⇒ **不需要插件映射**（2026-09-30 由出厂包逐文件扫描确认）。
> 另：`cordis_inspect_query` 的 client Service **目录不是全集**（`configForms` 就不在里面，但 0.2.0 里一堆官方包在用它）
> ⇒ 别拿目录当「服务不存在」的证据。
>
> **⚠️ 桌面版装/升插件：两个壳两条路，互不通用（2026-10-02 复核 + 维护者实测）**
> - **官方壳（Electron）**：**安装** = 应用内**插件界面**填包名 `@nonamelego/dsh-catppuccin`；
>   **升级** = 在插件界面里**先删除、再重新填一遍同一个包名安装**（v0.2.0 既无升级入口也无版本选择器，
>   上游 UI 自己的话是「插件安装后暂不支持自动更新：升级需先卸载再安装新版」）。
> - **社区壳（`anywhere-labs/dsh-desktop`，仓库已从 `deepseek-harness-desktop` 改名）**：
>   **安装/升级都走命令**——应用内 **Open DSH Terminal** 里 `dsh plugin --profile desktop add|update @nonamelego/dsh-catppuccin`
>   （壳在终端里生成私有 `dsh`/`pnpm`/`node` shim，PATH 只对该终端生效）；图形侧还有内置的
>   Community Market（只有「安装/卸载」，没有升级）。
> - **系统 PATH 上的普通 `dsh` 两个壳都管不了 `desktop`**：`@deepseek-ai/dsh/lib/bin.js` 的
>   `parseDshArgs(argv, version, manageDesktopProfile = false)` 在 `manageDesktopProfile` 为 false 时调
>   `rejectElectronProfile()` → `error: profile "desktop" is managed exclusively by the Electron application`
>   （按名字硬拒、大小写不敏感）。实测：`node <0.2.0-rc.2>/lib/bin.js plugin --profile desktop list` 报上面这句，
>   `--profile web list` 正常。**只有桌面壳自己的 CLI 入口会传 `manageDesktopProfile: true`**
>   （官方壳 = `resources/runtime/cli/bin/dsh.cmd` → `dsh-desktop-host/lib/cli.js` 的 `runDesktopCli()`，
>   同时把自带的 pnpm 11.7.0 作为 `packageManager` 传下去）。⚠️ **但维护者实测两个壳的路径互不通用**，
>   所以 README 里**不要**给官方壳写 CLI 指令、也不要给社区壳写「删掉重装」。
> - **壳的判别（2026-10-03 定，取代早先「插件分辨不出是哪个壳」那句）**：`classifyShell()`
>   （`src/profile-detect.ts`）把宿主分成 `web` / `community-desktop` / `official-desktop`——
>   **先判两条社区信号，剩下的 Electron 运行时就当官方**：
>
>   | 信号（在 profile / host 进程里） | 官方壳 | 社区壳 Stable/Beta | 社区壳 Next | 纯 node |
>   |---|---|---|---|---|
>   | `DSH_DESKTOP_NODE_EXECUTABLE`（host env） | ❌ | ❌ | ✅ | ❌ |
>   | `desktopProfiles` 服务（`current.name`） | ❌ | ✅ | ❌ | ❌ |
>   | `process.versions.electron` | ✅ | ✅ | ✅ | ❌ |
>   | **⇒ 判定** | `official-desktop` | `community-desktop` | `community-desktop` | `web` |
>
>   官方侧证据（2026-10-03，`resources/app.asar` 直接 grep）：该变量在壳内**只有 3 处命中，且全部在
>   `packageManager.env` 里**——即交给 **pnpm 包安装 / CLI 子进程**的那份 env
>   （`runCli({ manageDesktopProfile: true, packageManager: { env } })`）——host 子进程走的是
>   `desktopNodeEnvironment(this.node, void 0, this.environment)`，`bin === undefined` 取
>   `{...壳 env, ELECTRON_RUN_AS_NODE: '1'}`，**不设**那个 marker；`desktopProfiles` 在官方 0.2.0-rc.2
>   出厂包集合里 **0 命中**。社区侧：`dsh-desktop-next/src/host/index.ts` 给 host 设
>   `DSH_DESKTOP_NODE_EXECUTABLE`，`dsh-plugin-desktop/src/profile-service.ts` 注册 `desktopProfiles`。
>   顺序是判据的一部分：社区信号先判，否则跑新版 Electron 的社区壳会被官方分支吃掉。
> - **升级文案按壳分流**（设置页「检查更新」）：`web` / `community-desktop` 给 CLI 命令
>   （`updateCommandFor()` → payload 的 `updateCommand`）；`official-desktop` **不给命令**，
>   改给 `pkg@tag` 包名（`pluginSpecFor()` → payload 的 `updateSpec`）+ 「插件界面里先删除、再重装」
>   的指引（= README「桌面版」那条官方升级路径）。理由：官方壳用户**没有可达的终端入口**
>   （`resources/runtime/cli/bin/dsh.cmd` 代码上允许 `manageDesktopProfile: true`，但壳 UI 不给终端）。
>   护栏：`tests/profile-detect.spec.ts`（6 条判定）、`tests/e2e/update-check.e2e.spec.ts`（三种壳各一条
>   真路由断言，含 `updateCommand`/`updateSpec` 的互斥）、`tests/rows.spec.tsx`（三种壳的渲染文案与按钮名）。
>   三条支路都做过变异验证（删 desktopProfiles 分支 / Electron 恒返回 web / 客户端忽略 `official-desktop`）⇒ 会红。
> - ⚠️ 缓存陷阱：e2e 里那三条壳断言**共用一个 cache bucket**，必须按 mock 时钟**递增**推进
>   （30 / 60 / 90 分钟）。推同样的量会正好落在上一条自己 stamp 的未来时间点上，静默复用它的裁决 ⇒
>   即使把分支删掉断言也绿（2026-09-24 实测到这个假绿，2026-10-03 把顺序写进注释）。
> - 回答用户「升到最新版了吗」之前，先问清是哪个壳 + 走的哪条路。

**⚠️ 别再写「Desktop 每次启动用随机端口」**：两个壳都是固定端口，localStorage 的 origin 跨重启稳定。持久存储的理由是
「localStorage 是 per-browser / per-origin，DSH home 才是机器级真源」（多浏览器、清站点数据、第二个实例落到 43121 这类
情形），不是「每次启动都空」。这条错误叙述在注释/README 里存活了三个版本，2026-09-24 更正。

**桌面识别：社区壳那一路有效，官方壳那一路 2026-09-24 被证伪**（`src/profile-detect.ts`）：

- 社区壳：`ctx.get('desktopProfiles')` 服务（`src/update-check/host.ts` 探测）——**仍然有效**；
- ~~官方壳：环境变量 `DSH_DESKTOP_NODE_EXECUTABLE`~~ **❌ 不成立**。上游架构说明原话：「Host 继承调用者的 PATH，
  不加入 Desktop 私有的 `bin` 目录，因此 PTC 和 agent shell 不会通过该目录解析内部启动器。**`DSH_DESKTOP_NODE_EXECUTABLE`
  仅为包安装注入。**」（`.agents/notes/implemented/architecture/2026-09-11-desktop-electron-node-runtime.zh.md`）。
  代码印证：`apps/desktop/src/host-process.ts` 用 `desktopNodeEnvironment(this.node, undefined, …)` 起 host，
  而 `bin === undefined` 时**不设**该变量（`apps/desktop/src/node-environment.ts`）；`apps/desktop-host/src/index.ts`
  只在 `runProfile({ packageManager: { env: { … } } })` 里给它——那是**包安装子进程**的环境，不是 profile 进程的。
  ⇒ **官方桌面壳下 `isDesktopShellEnv()` 恒为 false**（更新行退化成纯 web 文案；profile 名仍对，靠扫 `profiles/` 目录命中 `desktop`）。
  **已实测的替代信号**：Electron 以 node 模式跑时 `process.versions.electron` 有值（本机实测 `37.10.3`），纯 node 下是 `undefined`。
  现有两路断言锁的是**旧假设**，改判据时要一并改：`tests/profile-detect.spec.ts`（纯函数）+
  `tests/e2e/update-check.e2e.spec.ts`（真路由，曾变异验证会红）。

**推论**：新增依赖上游形状的判断时，上游的 `apps/*` 是唯一事实来源——用 `gh api repos/deepseek-ai/deepseek-harness/contents/<path>`
直接读源码（`desktopProfiles` 这类服务名就是这么做出来的对照），别按印象写。

## 插件卡片图标契约（Plugins 页，2026-10-02 在 0.2.0-rc.2 上取证）

Plugins 页每个 bundle 卡片的图标来自 **Host 读取的包元数据**，不是客户端自带资源——没声明就回落成默认图案。
判定链全部落在 `@deepseek-ai/dsh-app-boot`（`lib/index.js` 的 `package-meta.js` 区段 → `iconOf()`）：

| 环节 | 位置 | 规则 |
|---|---|---|
| 声明 | `package.json` 的 **`icon`** 字段 | 必须是**相对路径**（绝对路径或带 `scheme:` 一律 throw），且必须留在 manifest 目录内 |
| 格式 | 同上 | 扩展名白名单：`.svg` `.png` `.jpg` `.jpeg` `.webp` |
| 体量 | `MAX_ICON_BYTES` | 原始字节 **≤ 256 KiB**（超了 throw，不是降级渲染） |
| 读取 | `iconOf()` | `readFileSync` → `data:<mime>;base64,…` 内联；**不缩放、不裁切、不改色** |
| 渲染 | `dsh-client-ui-plugin-manager` 的 `.cardIcon` | 容器 **48×48**、`.5px solid var(--dsw-alias-border-l3)`、`border-radius: var(--dsw-radius-lg)`（16px）；内部 `<img class="packageImage">` 是 **36×36 + `object-fit:contain`** |

- **`files` 必须带上图标文件**：Host 读的是**安装后**的包目录，漏进 `files` 就是「仓库里有、tarball 里没有」。
- 取值路径：`metaOf(name, base)` → `pluginPackages` 服务（`dsh-app-boot` 注册）；客户端只消费 `pkg.meta.icon`。
- **别指望圆角是圆形的**：容器恒为「圆角方 + 描边」。透明四角的 PNG ⇒ 读感是「方框里悬着一枚圆」（36px，距框边 6px）；
  想要「方形满幅」得让**资源本身**是满幅方形——`dsh-context` 的 `icon.svg` 就是 1024×1024 满幅图形，所以它看起来是实色方块。
- 护栏：`tests/plugin-icon.spec.ts` 逐条镜像上面五条（相对路径 / 白名单扩展名 / ≤256 KiB / `files` 收录 / PNG 魔数）。
  两条变异（从 `files` 移除、扩展名改 `.bmp`）都实测会红。
- 选型对照脚本：`.debug/icon-preview/gen.mjs`（按**真实 `cardIcon` 取值**渲染候选牌面 + 3× 放大图）。**不入库**。

## 插件详情页的设置区（`plugins.bundle.config`，2026-10-04 在 0.2.0-rc.2 上取证）

插件自身详情页（点开插件卡片那页）中间那块「标签 + 下拉」的设置区**不是自动表单，是插槽**——**谁注册谁显示**，
不注册整块不渲染（我们此前的状态）。机制全部在 `dsh-client-ui-plugin-manager` 内：

| 环节 | 事实 |
|---|---|
| 渲染点 | `PackageDetail`（组合包页）：`renderSlot("plugins.bundle.config", { view: "page" }, { entryKey: pkg.name })`，**仅当** config ledger 的 `bundles` 集合里有该包名；下面才是 `RowsSection`（「包含的组件」） |
| 另两个兄弟插槽 | `plugins.item`（官方插件卡片 + summary/page，官方 `ui-settings-agent-loop` / `-shell` 走这条）与 `plugins.row.config`（key = `` `${bundle}#${rowId}` ``） |
| **key 是什么** | **bundle 的 npm 包名**（`entryKey: pkg.name`）。本插件 = `@nonamelego/dsh-catppuccin`（= `update-check.ts` 的 `PACKAGE_NAME`），**不是** profile 条目 id `dsh-catppuccin` |
| 注册式样 | `configForms.whileServed([ns], () => slots.inject('plugins.bundle.config', () => slots.register({ name, key, locale, inject }, Card)))`；`whileServed` 保证命名空间不再被服务时**撤掉**区块，而不是留一个空块 |
| 插槽组件拿到什么 | 页面把 `form`（= `configForms.get(entryId)` 控制器）作为 prop 传进来（`plugins.item` 明确带 `form`；本插件自绘，走自己的 `DurableScope`，不依赖该 prop） |
| `slots.inject` 语义 | 等**插槽被声明**（`subscribeDeclaration` + `declarationEpoch`）；未声明就永不触发，**不抛错也不挂起** ⇒ 没有 Plugin manager 的宿主上天然静默 |
| ⚠️ `autoGenerate` 是惰性的 | Host 的 `describe()` 只把 `autoGenerate`（`presentations.get(fiber)?.auto ?? true`）写进 descriptor，**不过滤** `namespaces`；客户端唯一消费点是该页的 `formFor(id)`，它只查 `ns` 在不在。⇒ **去掉 `configure({ auto: false })` 不会让详情页长出表单**（上游文档原话：默认开启，供按 schema 生成页面的客户端使用，目前没有已发布的客户端这样做） |
| 参照实现 | 本机 `~/.dsh/profiles/desktop/node_modules/dsh-context/lib/client.js`（`plugins.bundle.config`，key = 自己的包名）与壳内 `ui-settings-agent-loop`（`plugins.item`） |

- 本插件落地：`src/client/detail-card.tsx`（复用四条行组件，含 2026-10-11 新增的纯静态「反馈与支持」行 `LinksRow`）+ `src/client/index.ts` 末尾的注册；**数据层零改动**（两个入口共用
  `CATPPUCCIN_ENTRY_ID` 那一份 durable section）。SlotMap 成员在 `detail-card.tsx` 内**本地声明**——我们只依赖 `dsh-client-ui-slots` 的类型，并不依赖 `dsh-client-ui-plugin-manager` 这个包（devDep 已升到 `0.2.1-rc.2`，但那个包仍不在依赖里）；
  将来若把它加进依赖，同形状会合并、异形状会编译报错（那就是删掉本地声明的信号）。
- 护栏：`tests/reentrancy.spec.ts` 的「Plugins-page card」一组 5 条（key = `PACKAGE_NAME`、`whileServed` 的 gate、无 `whileServed` 的宿主、旧 seam 上不注册、key 等于 manifest `name`）
  + `tests/rows.spec.tsx` 的组成断言（四条行 + schema 表单渲染不出的那些控件）。
- 相关配置（Host 侧，别混）：`src/index.ts` 仍 `configure({ auto: false })` —— 它表达的是「本插件自带 UI」，与详情页区块是否出现无关。

## DSH STORE 上架状态与契约（2026-09-24 核实，issue #1106）

商城（[`AI-Scarlett/DSH-Store`](https://github.com/AI-Scarlett/DSH-Store)）里我们的条目 `id = dsh-catppuccin` 是
**`status: blocked` + `updatePolicy: external-only`**：商城不提供安装按钮，但**保留 GitHub 手动安装入口和风险原因**，
已有用户仍可 `dsh plugin add`。每 8 小时自动复检一次，会跟随默认分支的新 Commit 自动刷新版本与元数据。

- **自动批准（`source-verified`）对本插件结构性不可达**，别再去试。`registry/automation-policy.json` 的
  `automaticApproval` 要求：无 `preinstall/install/postinstall/prepare`、无 `dependencies`、显式 `files`、
  声明 DSH 与 Node 兼容，**且**运行时代码里 `files/network/commands/credentials/protectedDsh/nativeOrExecutableArtifacts`
  信号**全为零**。扫描面 = 仓库里除 `node_modules|vendor|test|tests|docs|examples|fixtures|benchmarks|coverage|.github`
  之外的所有 `.ts/.tsx/.js/.mjs/.cjs/.json/.yml/.sh/.py`（**`scripts/` 也算运行时源码**；`*.map` 不算）。
  ⇒ 我们读 `$DSH_HOME`、写 `~/.dsh-tui/themes/`、fetch npm registry，**必然红灯**。
- **兼容窗口的算法**（`src/dsh-release-policy.mjs`+`dsh-release-policy.js`）：取 dist-tag 里**除 `next` 外**的最高
  支持版本作 target，再取 ≤ target 的最高三版。**窗口会随上游 dist-tag 移动，不是常量**：
  - 2026-09-24 实测 `{0.1.7-alpha.1, 0.1.7-alpha.2, 0.1.7-rc.1}`（当时 target = `alpha` 的 `0.1.7-alpha.2`）；
  - **2026-09-30 实测 `{0.1.7-rc.2, 0.2.0-rc.1, 0.2.0-rc.2}`**（target = `latest` 的 `0.2.0-rc.2`；`next` 也是 0.2.0-rc.2、
    `alpha` 反而退到 0.1.7-alpha.2）——**声明没跟上的那两天，窗口内 `compatible` 命中为 0**，所以每次上游发版后
    用 `.debug/dsh-store/verify-manifest.mjs` 复算一遍，别只看记忆里的窗口。
  - **2026-10-14 复算 `{0.2.1-alpha.1, 0.2.1-alpha.2, 0.2.1-alpha.3}`（target `0.2.1-alpha.3`）⇒ 窗口内命中
    `compatible` = 0**—— `package.json` 声明里最高的两条仍是 `0.1.7-rc.1` / `0.2.0-rc.2`，都没进新窗口。
    这不影响已安装用户（商城条目本来就是 `blocked` + `external-only`），但**要让商城窗口里重新出现一条 `compatible`
    命中，得先实测上游新版再把结果写进声明**；没测过就不要为了凑窗口凭空标 `compatible`。
  规则：**窗口内 ≥1 条 `compatible` 即可**；`approved` 条目三者全非 `compatible` 会转 `unlisted`。
- **声明写在 `package.json` 的 `dsh.compatibility`**（`dsh` 范围字符串 + `dshReleases` 逐版本 + `dshOperations` 逐版本
  `install/start/uninstall/rollback`，值 `passed|failed|unknown`）。这是 **store 专有**字段：上游
  `@deepseek-ai/dsh-package-manifest` 的 `DshManifest` 里没有 `compatibility`，上游也不解析它。
  ⚠️ **绝不能用 `peerDependencies` 里的 `@deepseek-ai/dsh` 范围声明兼容**：上游 `dsh-app-boot` 的
  `evaluatePluginCompatibility` 会据此判定，不满足就**跳过整个 bundle**（`>=0.1.5` 对 `0.1.5-rc.3` 为假）。
- 复现工具：`.debug/dsh-store/`（对方策略源码副本 + `probe-exact.mjs` 逐文件跑信号 + `probe-window.mjs` 算窗口 +
  `verify-manifest.mjs` 用对方函数校验本仓库 manifest）。**不入库**。
- 顺带发现：商城条目名/分类是错的（「用量统计看板（DSH Catppuccin）」/ `experimental`，应为 themes），
  他们的本地化把 stats line 误读成了用量看板。
- 若要真正上架：提交 `lib/` 构建产物（去掉 `prepare`）+ 去 DSH-Store 提 PR 申请 `user-reviewed`（人工通道），
  并接受对方「高权限项目可能仍需保持 guarded」的判定。

## 下次发版 SOP

发布走 GitHub Actions 的 OIDC **Trusted Publisher** 自动发 npm。正常流程**不要手动 `npm publish`**（手动只是 CI 故障时的紧急回退，见下）。

> ⚠️ **推 tag 前必须先问维护者**：tag 一推就自动发 npm、**撤不回来**（`npm unpublish` 会留下公开痕迹，还可能断掉已安装者的 lockfile）。Agent 可以把准备工作全做完——版本号、CHANGELOG 落节、本地全量验证、release commit——但 `git push origin main --tags` 这一步要等维护者点头。（2026-09-21 教训："继续未完成的工作" 被理解成含发版，于是自行发了 v0.5.5；版本内容没问题，但流程错了。）

### 发布前检查（一次性配置，已就绪但请复核）
- npmjs.com → 包 `@nonamelego/dsh-catppuccin` → Settings → **Trusted Publisher**：Repository 必须为 `dsh-catppuccin-theme`（当前已配好）。若与仓库名不一致，CI 的 `Publish to npm` 步会失败。

### 0. 选版本号（决定发布渠道）
- 正式版（版本号**不含** `-`）：`0.x.y` → 发布后进 `latest` 标签
- 预发布（**含** `-`）：`0.x.y-beta.n` → 发布后进 `beta` 标签
- `publish.yml` 用 `require('./package.json').version.includes('-')` 自动判断 `latest`/`beta`，无需手动指定。

> ⚠️ **发版版本号**：`latest` = **`0.6.4`**（2026-10-21；Publish run `39614662496` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.4` 带 provenance、tag 显式 `latest`；CI `39614583168` 的 check +
> boot-e2e 双绿）= **`0.6.4-beta.0` 转正** + **框语言 ⑤ 的第二半修复**（顶栏补 `width: 100%`：
> `margin-inline: auto` 把块级盒降成 fit-content，`max-width` 撑不开，真机顶栏只有 266px 而卡 856px
> ⇒ 修后 856 = 856）+ **首次真机验收**（官方壳 `0.2.1-rc.2`：issue #29 的 α / blur / mask / 几何逐项
> 实测、#19 命令面板祖先链 `backdrop-filter` 命中 0、框语言 ①②③⑦ 与 issue #27 设置分区目视过）+
> **玻璃预览图重拍**（旧图顶栏正是 ⑤ 的塌陷态，且侧栏展开露了工作区名）。**测试 352 全绿**（20 文件；
> 现为 **353**——`572bbec` 给 ⑤ 补了一条「两份宽度上限必须一致」的漂移护栏。该提交在 `0.6.4` tag 之后，
> **未随 `0.6.4` 发出，将随下一版**；纯测试，不影响已发产物的行为）。
> 仍未跑：四风味 × mica/compat 全矩阵、`signature` 回归。⑤ 的折叠分支 2026-10-21 已用「临时加
> `data-sidebar-collapsed`」的方式验过 CSS 分支（1383.3 = 列 − 44、右边缘 −16 无溢出、还原一致），
> 但**真按钮触发折叠**仍没走过。
>
> 上一版 `latest` = **`0.6.3`**（2026-10-19；Publish run `39143921957` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.3` 带 provenance、tag 显式 `latest`；CI `39143719780` 的 check +
> boot-e2e 双绿）= `0.6.3-beta.0/.1/.2/.3` 全链**转正** + **issue #27**（设置收敛到独立分区、控件换官方
> 原子件）+ **issue #28**（输入卡下方状态栏补背板）+ **上游 DSH 0.2.1 适配**（settings seam 的 `mode`
> 被上游删除，插件一度改设置不落盘）。**测试 336 全绿**（20/20 文件）。兼容下限同时抬到 DSH
> `0.1.7-rc.1`（`engines.dsh` 与商城元数据同步；`dshReleases` 已清掉低于下限的三条）。
> 上一版 `latest` = **`0.6.2`**（2026-10-13；Publish run `38373767687` success 30 s、日志
> `+ @nonamelego/dsh-catppuccin@0.6.2` 带 provenance；CI `38373498824` check + boot-e2e 双绿 1 m 37 s）
> = `0.6.2-beta.0/.1/.2` 全链**转正** + **issue #22 第三轮 ①②③**（选中行色统一 / 一级弹层去实线框 /
> 供应商胶囊去描边；CDP 四风味 + 玻璃关 + compat 复测）+ issue #22 追评（rim-strong）与「拆融合」+
> issue #23 注册容错。**测试 289 全绿**（20/20 文件）。原计划的 `0.6.2-beta.3` 未单独发布、内容并入本版。
> 上一版 `latest` = **`0.6.1`**（2026-10-08；Publish run `37651773918` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.1` 带 provenance；CI `37651749540` 的 check + boot-e2e 双绿）
> = `0.6.1-beta.0` **转正** + **修复 issue #21**（玻璃层三处裸 `header` 元素选择器误命中插件页的页面头，
> 收窄为 `[data-phase] header`；CDP 真页实测：工具条对卡片的上/下距 **11px / 29px → 0 / 20**，
> 即恢复上游 stock，且会话顶栏几何不变）。**测试 269 全绿**（267 + 本次新增 2 条护栏）。
> 上一版 `latest` = **`0.6.0`**（2026-10-04；与 `0.5.10-beta.1` **零代码差异**，
> Publish run `37181444425` success 33 s、日志 `+ @nonamelego/dsh-catppuccin@0.6.0` 带 provenance；
> CI `37181444159` check + boot-e2e 双绿 1 m 49 s）= 插件详情页加上设置区 + 插件卡片图标 + 「检查更新」
> 按宿主分流 + README 修缮与四风味预览关玻璃重拍（完整条目见 CHANGELOG 的 `## [0.6.0]` 节）。
> **`beta` = 暂无**（`0.6.4-beta.0` 已被 `0.6.4` 吸收）。上一版 `beta` = **`0.6.4-beta.0`**（2026-10-19；
> Publish run `39248943503` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.4-beta.0` 带 provenance、tag 显式 `beta`；CI `39248943583`
> check + boot-e2e 双绿）= **issue #29 状态栏背板改磨砂幕布**（同色 α70~84% + blur + 顶部 18px mask
> 淡入，几何沿用 #28；`docs/issue-29-dock-glass-veil.md`）+ 框语言审计 P1~P3（四条框规则统一 /
> 顶栏与轨迹面板跟随输入卡宽度 / 设置项加真值样本与「看一眼主界面」出口）。**测试 352 全绿**（20 文件）。
> 当时的「真机 CDP 像素探针未跑」已在 2026-10-21 补跑，数字见 `docs/issue-29-dock-glass-veil.md` §5.1。
> 上一版 `beta` = **`0.6.3-beta.3`**（2026-10-18；Publish run `39109687611` success 33 s、日志
> `+ @nonamelego/dsh-catppuccin@0.6.3-beta.3` 带 provenance；CI `39109564288` check + boot-e2e
> 双绿，boot **22/22 项通过（3 项跳过）**）= **issue #27 设置独立分区**（`settings.section` 导航项
> 「Catppuccin」+ 控件换官方 primitives，删掉 4 条 general 行）+ **issue #28 dock 背板**（卡外
> 状态栏不再被滚动正文穿透）+ **上游 DSH 0.2.1 适配**（settings 快照删掉 `mode`，原判据恒假 ⇒
> 改设置不落盘；现为「`ready` 且非显式 `memory`」）+ **兼容下限抬到 `0.1.7-rc.1`**（设置页消费
> primitives 的 `SegmentedControl`，该导出自 0.1.7-alpha.1 才有；`engines.dsh` 与
> `dsh.compatibility.dsh` 同步）+ boot-e2e 适配设置分区 / 0.2.x 模态面板 / `role=tab` 分段并把
> 宿主从 `0.1.5-rc.1` 升到 `0.2.1-rc.2`。**测试 336 全绿**（20 文件）。
> 上一版 `beta` = **`0.6.3-beta.2`**（2026-10-16，commit `78def86`；Publish run `38898451200` success、
> CI `38898451227` check + boot-e2e 双绿）= 桌面壳主区放开（centerCol 不再是不透明板）+ 原生标题栏
> 改吃侧栏面 + 产物块锚点 P0 + 「继续执行目标」通知卡玻璃座位；未单独落节，内容并入 CHANGELOG 的
> `0.6.3` 条目。
> 上一版 `beta` = **`0.6.3-beta.1`**（2026-10-16；Publish run `38869618718` success ~40 s、日志
> `+ @nonamelego/dsh-catppuccin@0.6.3-beta.1` 带 provenance；CI `38869601455` check 29 s + boot-e2e
> 1 m 21 s 双绿、boot 21/21 项通过）= **产物块（官方 `dsh-client-ui-deliverables`）改用与侧栏同一张
> `--dsh-glass-card` 面**（卡头/文件行/交付文件卡全落同一 token，rim-soft、14px、分隔线换主题发线；
> 仅 mica，不加 blur；实测 #141420 / Latte #edeff3 ≈ 侧栏 #151520 / #eff0f4）+ **地面光斑转开关
> （issue #26，默认关）** + **侧栏 rim 降档（issue #26 追办 ②）** + 接线护栏（durable section 每个字段
> 必须进写操作）+ 构建加固（样式表解析失败即构建失败）+ 新会话空玻璃框修复（`headerBlank` 守卫）+
> 思考卡玻璃座位。**测试 311 全绿**（307 → 311：产物块 4 条护栏，**8 组变异全部验证会红**）。
> 两个实现陷阱写进了代码注释：上游暗色覆盖 `body[data-ds-dark-theme] .…_card` 是 (0,2,1)，
> 选择器必须锚在 `body` 上；交付文件卡自带 `background: var(--deliverable-fill)`，只改变量不够。
> 上一版 `beta` = **`0.6.3-beta.0`**（2026-10-15；Publish run `38737646305` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.3-beta.0` 带 provenance；CI `38737619544` check + boot-e2e 双绿）
> = **地面氛围层（issue #25，方案 L2）**：纯色地面 → 同色系 wash + 两枚静态柔光斑（全部取自已映射
> token、四风味自动跟随；亮度拉满整体塌缩回纯白 / 纯黑）+ **issue #24 修复**（删除会话根入场动画，
> 切换会话不再闪；`918f18b`）。CDP 实测：光斑中心 ΔRGB = 25（Mocha）/ 19（Latte）、无光斑区 Δ = 0。
> **测试 292 全绿**（289 → 292；新增 ground ambience 3 条，变异验证过）。实施与两处实测偏差见
> `docs/issue-25-ambient-ground.md` §10。
> 上一版 `beta` = **`0.6.2-beta.2`**（2026-10-13；Publish run `38287525195` success 32 s、日志
> `+ @nonamelego/dsh-catppuccin@0.6.2-beta.2` 带 provenance；CI `38287240048` check + boot-e2e 全绿，
> **测试 289 全绿**（281 → 289））= 输入区「拆融合」（玻璃卡只包输入区、统计行回卡外）+ 主输入面双重
> 影 + 标准预设默认模糊度 2 → 5px + **issue #23 注册容错**（与语言包共存不再炸 boot）+
> issue #22 追评（主输入面 rim-strong 档）+ 反馈行文案点身份。首轮 CI `38286922335` 抓到一处漏改断言
> （glass-layer.spec 的 shipped default 仍为 2），修复后全绿。
> 上一版 `beta` = **`0.6.2-beta.1`**（2026-10-11；Publish run `38122408831` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.2-beta.1` 带 provenance；CI `38122409040` check 24 s + boot-e2e 1 m 19 s 双绿）
> = 「反馈与支持」行（LinksRow）+ **issue #22 三修**（模型弹层换座到 MenuSurface 材质面 / 侧栏右侧蓝线移除 /
> 选中态去 1px 内环；顺带复活分组标题胶囊），真页 CDP 验证（reporter 同款 Latte + mica + blur 12 + frost 45）。
> **测试 281 全绿**（274 + LinksRow 2 + glass-css 新增 5）。
> 上一版 `beta` = **`0.6.2-beta.0`**（2026-10-10；Publish run `38039861018` success 40 s、日志
> `+ @nonamelego/dsh-catppuccin@0.6.2-beta.0` 带 provenance；CI `38039848400` check 24 s + boot-e2e 1 m 29 s 双绿）
> = 2026-10-10 全量审查（`docs/code-review-2026-10-10.md`，无 Blocker/Critical）后的 **P1 三修**：
> R3 更新检查客户端 fetch 补 15 s 超时、R1 `setTheme` 包装卸载守卫、R2 boot 窗口防回滚；
> **测试 274 全绿**（269 + 5 条，三组经变异验证）。再上一版 `beta` = **`0.6.1-beta.0`**（2026-10-07；
> Publish run `37621692087` success 45 s、CI `37621692252` 全绿 1 m 41 s）= 玻璃模式下选中会话行的
> 定位器重设计。
> 当前 dist-tags = `latest: 0.6.4` / `beta: 0.6.6-beta.0`（2026-10-27 复核，`curl
> https://registry.npmjs.org/-/package/@nonamelego%2Fdsh-catppuccin/dist-tags`；**权威信号始终是 run
> 日志里的 `+ …@<version>`**，dist-tags 端点这次 1 分钟内就翻新、上一轮却要 3 分钟——别拿它当发布成功的判据）。
> `0.6.6-beta.0`（2026-10-27）= **issue #30 补充**——首屏不再先闪官方深色：Host 经
> `webserver/index-inject` 把当前持久化风味的整张 `--dsw-*` 表注入 index（`html body` 选择器 + body script
> 对齐 `data-ds-dark-theme`），Client 在风味真正生效时摘除。方案与实测见
> `docs/issue-30-first-paint-flash.md`。Publish run `40481414068` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.6-beta.0`、显式 `tag beta`；CI `40481413311`（check + boot-e2e）双绿；
> **测试 373 全绿**（22 文件）。⚠️ 真机首帧像素采样**未跑**（文档 §7）。
> `0.6.5-beta.0`（2026-10-27）= **issue #30**——新 origin 首次加载把配置重置为出厂默认的修复
> （`replayLocalChanges` 只回放真正动过的字段；arming 只在有增量时；玻璃订阅只在持久化字段变化时才排写入），
> 方案与三组变异见 `docs/issue-30-boot-pending-push.md`。Publish run `40477610164` success、日志
> `+ @nonamelego/dsh-catppuccin@0.6.5-beta.0` 带 provenance、显式 `tag beta`；CI `40477609960`
> （check + boot-e2e）双绿；**测试 360 全绿**（20 文件）。⚠️ 真机验收**未跑**（本机限制，步骤在文档 §9）。
> **`0.6.0`（正式版）= 插件详情页加上设置区 + 插件卡片图标 + 「检查更新」按宿主分流 + README 修缮与
> 四风味预览关玻璃重拍**——四条完整条目见 CHANGELOG 的 `## [0.6.0] - 2026-10-04` 节。⚠️ 真机 e2e **未跑**
> （本机 Playwright 不可用，属环境限制；详情页设置区可由维护者在官方壳内自测）。
> 上一版 `latest` = **`0.5.9`**（2026-10-02）。
> 上一版 `beta` = **`0.5.10-beta.1`**（2026-10-04；Publish run `37179583576` success，日志
> `+ @nonamelego/dsh-catppuccin@0.5.10-beta.1` 带 provenance；CI `37179583423` check + boot-e2e 双绿；
> dist-tags 约 45 s 内生效）= 插件详情页加上设置区（预发布按仓库惯例不单独落节，转正后落成 `## [0.6.0]`）：
> 新增 `src/client/detail-card.tsx` + `plugins.bundle.config` 插槽注册（key = **npm 包名**），把「设置 → 通用」
> 那三条行也挂到插件自己的详情页上；数据层零改动（两个入口共用 `CATPPUCCIN_ENTRY_ID` 那份 section）。
> 机制取证与护栏见「## 插件详情页的设置区」一节。**测试 267 全绿**，三条变异实测会红（key 换成条目 id /
> 去掉 `whileServed` / 卡片里删掉更新行）。⚠️ 真机 e2e **未跑**（本机 Playwright 不可用，属环境限制）。
> 上一版 `beta` = **`0.5.10-beta.0`**（2026-10-03）= 插件卡片图标 + 「检查更新」按宿主分流：
> 前者给仓库根加 `icon.png`（`package.json` 的 `icon` + 进 `files`；Host 读包元数据内联成 data URI，
> 卡片容器 48×48 + 内部 `<img>` 36×36 + `object-fit:contain`）；后者新增 `classifyShell()` 把宿主判成
> `web` / `community-desktop` / `official-desktop`，官方桌面版不再给**无处可跑**的
> `dsh plugin --profile desktop …`，改给 `包名@渠道` + 「插件界面里先删除再重新安装」。**测试 260 全绿**，
> 三条分流支路均变异验证过。⚠️ 真机 e2e **未跑**（本机 Playwright 不可用，属环境限制）。
> 上一版 `beta` = **`0.5.9-beta.1`**（0.5.9 的最后一个预发布，2026-10-01）。
> **`0.5.9`（2026-10-02，当时的 latest）= 上游 0.2.0 线适配 + 玻璃模式切换两条修复 + 命令面板毛玻璃**：前两项随 `0.5.9-beta.0`
> （补 18 个漏映射 token 至 190/190 全覆盖、兼容声明跟进 0.2.0、Windows 标题栏顶部渐隐、「切云母/兼容会闪一下」
> 与「切得快时第二次被回滚」），第三项随 `0.5.9-beta.1`（issue #19：composer 的材质搬到 `::before` 材质面，
> 让 `[data-trigger-menu]` 脱离 backdrop root，实测面板区 stdev 31.58 → 0.00）。**转正时与 `0.5.9-beta.1` 零代码差异**，
> 唯一新增改动是 `vitest.config.ts` 的 `hookTimeout: 60_000`（本机满载时 `tests/tui-themes.spec.ts` 的 `afterAll`
> 清临时目录会超默认 10s，把整轮 `pnpm test` 的退出码弄成非零）。⚠️ **issue #19 那条的真机 e2e 未跑**
> （`docs/issue-19-palette-blur.md` §10 列了三条待补）；维护者自测口径 = 敲 `/` 看面板毛玻璃 + 分栏态（右侧栏打开）
> 再敲一次看输入栏内有无位移。上一版 `beta` = **`0.5.7-beta.0`**（2026-09-24 下半场，内容为 `0.5.7` 的真子集：
> **官方桌面壳改用 Electron 运行时识别**——`process.versions.electron`，因为上游明确「`DSH_DESKTOP_NODE_EXECUTABLE`
> 仅为包安装注入」；+5 断言 / 231 用例，单元与 e2e 两条路径都做了变异验证，另附一批文档与仓库卫生修正）。
> **`0.5.8`（2026-09-28，上一版 latest）= issue #17 的三族子串选择器退场**：`[class*='panel']` 与 `[role='tooltip']`
> 从 compat 的三条规则里移除，`[class*='card']` 收窄到 `[data-composer-card]`（离线扫描 `0.1.7-rc.2` 全套客户端包
> 957 个文件里的 **20 个 `*_card` 类名**：18 个自绘 `background` ⇒ blur 被自己的底色盖住、我们的填充等于替换设计 token；
> 2 个无任何 `background` 声明 ⇒ 规则是唯一把它们画出来的东西，正是报告人的灰纹与孤线）。**未采纳**「加 `compatExclude`
> 配置项」（真正贵的不是配置面：两套 settings schema 出自同一张 `catppuccinSchemaFields()`，加字段是**一次**编辑，
> 成本落在 `stateToMutateOps` / `settingsSectionsEqual` / `sanitizeState` / Host schema / 设置行 UI 这几处；贵在
> **排除语义**——2026-10-27 实测：`!important + initial` 式排除会把宿主自己的底色一起抹成透明，`@layer` 式排除会让
> 材质在所有宿主声明过 `background` 的地方集体失效，两者都做不到「回到宿主原值」，只能新开一条按元素重算/注入的通道）
> 与「行级尺寸豁免」（纯 CSS 没有高度判据；改走运行时等于在幂等 stamper 里每帧强制布局）。真机 e2e 在 `0.1.7-rc.2` 上
> **19/19**。顺带在**上游 + 本插件范围内**查明没有「通用自定义 CSS」入口（两版本全套包 + 前端 bundle + profile patch
> 全 0 命中；⚠️ **范围只到这里**，别读成「这台机器上没有」，见下条），README 因此改用「只读取证脚本 + 外部注入 + 提 issue」三步。
> ⚠️ **2026-09-29 报告人更正（issue #17 末条评论）**：上面这条结论的**扫描范围只有 DSH 上游 + 本插件**，别读成「这台机器上没有样式入口」——
> **第三方插件可以自带**：`dsh-better-sidebar@0.21.1` 就有 `customCss` 配置项，gate 在它自己的 `titleBarScheme === 'custom'` 上
> （`const customCss = scheme === "custom" ? snapshot.prefs.customCss : ""`），以 `data-dsh-custom-css` 注入，写在 profile patch 里该插件条目的
> `config:` 下。当时我们在 issue 里据此断言「你们本地的 `customCss` 应该是自制的」是**错的**（已由报告人纠正）。
> **`0.5.7` 在此之上加了 issue #16**：compat 模式不再给 DSH 原生右侧栏的**布局壳**加模糊——`[class*='panel']` 的子串匹配命中 `P3OORG_panel` / `P3OORG_panelBody`（透明布局壳：`absolute + pointer-events:none`、无 `background`，关闭右栏后仍留在 DOM，blur 于是继续绘制成右缘约 300×518 的磨砂残带）；改为排除该容器**整棵子树**（按 `data-sidebar-right-panel`）并用 `data-sidebar-right-open` 回填展开态 ⇒ 打开观感不变。真机 e2e 在 `0.1.7-rc.2` 上 **19/19**（含同页 A/B），影响面审计的差集正好是那两个容器、反向为 **0**。同批还修了 e2e harness 三处会产**假绿**的坑（向导步骤切换脱离 `role=dialog` 且残留 `_mask_*` 吃点击、mode 与总开关的点击静默不生效、浏览器 fallback 到系统 Chrome + `--no-proxy-server`）。
> 上一版 `0.5.6`（2026-09-24 发布：**issue #15 —— DSH 0.1.7 的 settings seam 双通道适配**：客户端 `inject` 去掉 `settingsScope` 硬依赖、两个 seam 各一次软注入由 `DurableScope` 适配、Host 新增 volatile `Config` 并保留 `installSection` 分支、`.volatile()` 加 schemastery 3.18 能力守卫、迁移延迟重试；+23 断言 / 215 用例全绿。**已在本机真机验证通过**——维护者把 DSH Desktop 升到 DSH `0.1.7-rc.1` 后，用该运行时启动 `web` profile 逐项过关（无 pending / 四条设置行 / 点 Mocha 后 patch 落盘 / 重启后从文档 hydrate 回 Mocha），过程与结论见 `docs/issue-15-settings-seam-0.1.7.md` §0.1）；同批还修了两处只在这一批之后才暴露的缺陷——真机跑出来的 `scheduleLegacyMigration` 并发竞态（三次机会之间只挡了 `settled`，第二个尝试在第一个写提交前读到同一 revision，撞栅栏后被记成 `legacy state migration failed`，而迁移其实成功了）与 `web-platform.ts` 平台模块表的漂移，两者都有断言钉住（去掉守卫即变红）。`beta` = **`0.5.6-beta.2`**（0.5.6 的最后一个预发布，内容为其真子集）。上一版 beta.1（2026-09-23）是上游 0.1.7 适配复核（带 alpha 的静态色不再被抹成实心、菜单半透明只在宿主声明 `--dsw-menu-backdrop-filter` 时启用、新增的 `--dsw-alias-link` 暗色达到 AA、文档预览浅色标签不再糊在深底、右侧栏玻璃钩子改指 `data-sidebar-right-panel`；+15 条断言 / 191 用例，5 条经变异验证会红）。beta.0（2026-09-22）是审计 F1~F9 那批修复（跨窗口旋钮同步、读侧陈旧写保护补真、预设组键盘可达、跨窗口关闭风味落地、草稿行 key、重试通道、override 垃圾键收敛等），**它已在两个本地 profile 上装过（`web` 与 `desktop` 均为 `0.5.6-beta.0`**，desktop 用 `~/.dsh/profiles/node_modules/pnpm` 的 11.8.0 装，pnpm 会自动把该版本加进 `minimumReleaseAgeExclude`）；**beta.1 未实测**（beta.2 与 `0.5.6` 已在真机实测通过）。下次按常规 semver 判断：**修复走 `0.5.x`，新特性走 `0.6.0`**；预发布仍用 `-beta.n` 后缀。发版前先在 CHANGELOG.md 的 `## [Unreleased]` 节写好条目、发版时落成 `## [<version>] - <日期>`（publish.yml 校验正式版必须已有对应条目；该节缺失时 `pnpm changelog:gen -- --write` 会自动补建；**预发布按仓库惯例留在 `[Unreleased]` 里，只把该链路的比较基线指到新 tag**）。发布后顺手把这句话的版本号改掉——它已经落后过两次（还写着 0.5.1 时已经发到 0.5.2/0.5.3，写 0.5.3 时已经发到 0.5.4）。

### 1. 升版本 + 本地验证
1. 编辑 `package.json` 的 `version`（连同本次要发布的代码改动）
2. **更新 CHANGELOG.md**：在 `## [Unreleased]` 追加条目，或发版时把草稿生成后润色成 `## [<version>] - <日期>` 节。生成草稿：
   ```bash
   pnpm changelog:gen            # 打印 上一 tag..HEAD 的草稿（按 conventional 分组）
   pnpm changelog:gen -- --write # 直接写入 [Unreleased] 节
   ```
   然后人工润色（补日期、合并条目、删噪音）。**正式版发版前必须已有对应 `## [<version>]` 条目**——publish.yml 的 `Verify changelog entry` 步会拦截缺失（预发布跳过该校验）。
3. 本地自测：`pnpm typecheck && pnpm typecheck:tests && pnpm build && pnpm test`（CI 也会跑同样步骤，但先自查）

### 2. 提交 + 打 tag + 推送（触发发布）
```bash
git add . && git commit -m "chore(release): 发布 v<version> ..."
git tag v<version>            # tag 名 = "v" + package.json 的 version，例如 v0.2.7
git push origin main --tags   # publish.yml 监听 v* tag 推送
```

### 3. 验证发布成功
- GitHub → Actions → `Publish Package` run 应为 `success`（`gh run watch <id> --exit-status` 可以直接等结果）。日志里出现 `+ @nonamelego/dsh-catppuccin@<version>` 就是发出去了（还会带 provenance 签名）。
- **确认版本号时必须绕开仓库的 `.npmrc`**：本仓库的 `.npmrc` 指向 `npmmirror`，所以裸跑的 `npm view` 读的是**镜像**，而镜像滞后没有上限——2026-09-21 发 v0.5.5 时，官方 registry 隔一分钟就有 `latest: 0.5.5`，而镜像过了 4 分钟仍显示 `0.5.4`（上一轮 v0.5.4 记的「约 3.5 分钟延迟」其实也是镜像滞后，不是 npm 的）。验证命令显式带 registry：
  ```bash
  npm view @nonamelego/dsh-catppuccin dist-tags --registry=https://registry.npmjs.org
  ```
  权威信号是 `Publish to npm` 步日志里的 `+ @nonamelego/dsh-catppuccin@<version>`（带 provenance 签名）；`npm notice ... may take a few minutes` 只是 npm 的常规提示，不代表要等。
- `git push` 偶发 GitHub **502**，直接重试即可（不要改 remote、不要 `--force`）。

### 4. 发布后
- **⚠️ 刚发完版，自己（或用户）立刻去装会发现「装到的是上一个版本」——这不是没发出去，是 pnpm 11 的
  `minimumReleaseAge`。** 2026-10-03 实测：pnpm 11.7.0 的配置 schema 里内置
  `"minimum-release-age": 24 * 60`（**= 24 小时**，`pnpm config get` 查不到，因为它来自默认值而非配置），
  `pnpm add <pkg>@beta` 会把窗口内的新版本**静默过滤**掉、解析到**上一个**符合窗口的版本
  （实测 `@beta` → 装到 `0.5.9-beta.1`，而镜像元数据里 `beta` 明明是 `0.5.10-beta.0`），
  而插件界面自己查 tag 得到的是新版本 ⇒ **界面显示新版本、实际装的是旧版本**（本次的症状就是
  「0.5.10-beta.0 装上了但卡片没有图标」，因为旧版本没有 `icon` 字段）。
  三条出路：① **指名精确版本**（`@nonamelego/dsh-catppuccin@0.5.10-beta.0`）——pnpm 会自动把该版本写进
  profile 的 `minimumReleaseAgeExclude`；② 在该 profile 的 `pnpm-workspace.yaml` 里给本包**整包豁免**
  （`minimumReleaseAgeExclude:` + `  - '@nonamelego/dsh-catppuccin'`，本次已给
  `~/.dsh/profiles/desktop` 加上，之后每个 beta 都能立刻装）；③ 等发布满 24 小时。
  诊断口诀：**先看 lockfile 的 `specifier:` 与已装 `package.json` 的版本，再看 `pnpm view <pkg>@<tag>`**——
  两者不一致就是撞上了这个窗口，别去查「是不是没发出去」。
- **把上面 `> ⚠️ 发版版本号` 那句的版本号改掉**（历史：写 0.5.1 时已到 0.5.2/0.5.3、写 0.5.3 时已到 0.5.4 —— 所以把它当成发版流程的最后一步，别指望“下次顺手”）。
- **误发了版本号怎么办**（2026-10-27 踩过：并行会话把 beta 发成 `0.6.6-beta.0`，维护者裁定该号归位到 `0.6.5-beta.2`）：
  npm **不允许改名**，只能二选一——① `npm deprecate <pkg>@<ver> "说明"`（保留可安装性、装的人会看到警告，推荐）；
  ② 72 小时内 `npm unpublish <pkg>@<ver>`（彻底移除，但同版本 24h 内不可再用）。
  ⚠️ **两件事都做不了走 CI**：`publish.yml` 用的是 OIDC 可信发布，连 token 都不存（`gh secret list` 为空），
  而 **npm 的可信发布只覆盖 `npm publish`，不覆盖 deprecate/unpublish** ⇒ 只能本机做，且必须先把
  `~/.npmrc` 里那个 `//registry.npmjs.org/:_authToken` 换成新的（2026-10-27 实测旧 classic token 回 401，
  `npm whoami` 直接 Unauthorized）。做完把 dist-tag 指回正确的版本，并核对
  `https://registry.npmjs.org/-/package/@nonamelego%2Fdsh-catppuccin/dist-tags`（该端点不缓存）。
- **CHANGELOG 底部的链接引用**也要顺手维护：`[Unreleased]` 指向新 tag（`compare/v<new>...HEAD`），并给新版本补一行 `[<version>]: compare/v<prev>...v<new>`。上个版本漏了，导致它停在 `v0.5.1...HEAD`。
- 若插件已收录于 awesome-dsh-plugin，收录条目无需随发版改动。
- 正式版发完如 README 需要同步变化点，并入本次 release commit。

## 故障排查（发版失败）

**背景**：`Publish to npm` 步骤历史上**连续失败多次**（v0.1.2 ~ v0.2.5），而 `0.2.6` / `0.2.6-beta.0` 是绕过 CI、本地手动 `npm publish` 发出的——原因是 Trusted Publisher 的 Repository 与（改名前的）仓库名不匹配。改名并同步配置后，下次发版是 CI 通道的首次验证点。

- 失败在 **pnpm/action-setup** 步（`Multiple versions of pnpm specified`）→ workflow 的 `version` 与 `package.json` 的 `packageManager` **字符串必须完全相等**，否则 action 直接抛错。本仓库只保留 `packageManager`（workflow 不传 `version`，官方推荐用法）——2026-09-15 加 `packageManager` 时踩过一次，差点让发版在第二步失败。
- 失败在 **Typecheck** 步、本地却过（`TS2307: Cannot find module '@deepseek-ai/...'`）→ **本地过 ≠ CI 过**：TS 会向上逐层查找 `node_modules`，本仓库位于 `D:\Vibe-Coding` 下，父目录的 `node_modules` 里有什么就能解析什么（幽灵依赖）。未声明的 `@deepseek-ai/*` 类型包必须写进 `devDependencies`；拿不准时把仓库复制到**工作区之外**（如 `%TEMP%`）跑一遍 `pnpm install --frozen-lockfile && pnpm typecheck && pnpm typecheck:tests && pnpm test`——2026-09-15 的 `@deepseek-ai/dsh-api-remotes` 就是这样被 CI 抓到的。

- 失败在 **install / build / test** 步 → 本地构建问题，先在本地重跑 `pnpm install && pnpm build && pnpm test`。
- 只失败在 **Publish to npm** 步：
  1. 首选怀疑 **Trusted Publisher 与仓库名不匹配** → npmjs 网页确认 Repository = `dsh-catppuccin-theme`。
  2. 打开该 run 的日志，看 `npm publish` 的具体报错（`errCode` / 401 / 403 / E401 等）。
- **紧急回退**（确信 CI 短时间修不好时）：本地手动发，必须显式走 npmjs registry——仓库 `.npmrc` 指向 npmmirror，直接 `npm publish` 会发错仓库/失败：
  ```bash
  npm publish --registry=https://registry.npmjs.org --tag latest   # 正式版
  npm publish --registry=https://registry.npmjs.org --tag beta     # 预发布
  ```

## 其它项目约定
- **文档里引用代码位置一律用符号名，不写字面行号**（写 `export const name` / `GLASS_PRESETS` / 断言名 / token 名，不写 `index.ts:54`）。行号写完当天就开始腐坏——2026-10-09 体检时 `AGENTS.md` 两处行号已分别漂了 3 行与 58 行。`docs/` 下的历史档（`code-audit-*` / `issue-*` / `locale-review`）已在开头统一标注「行号为写作当时快照」，活文档（本文件 / README）请直接写符号名。
- 提交信息用中文 conventional 风格：`feat(...)` / `fix(...)` / `chore(release): ...` 等。
- **CHANGELOG 双语**：希望 changelog 条目附带英文摘要时，在 commit 正文里写一行 `EN: <英文摘要>`（大小写不敏感）；`pnpm changelog:gen` 会自动把它渲染为 `- **中文标题**（EN: 英文）`。没有 `EN:` 行的 commit 只输出中文——双语是可选增强，不强制每条都要写英文。
- 玻璃质感（玻璃拟态）皮肤代码在 `src/client/glass/`；主题调色板由 `pnpm gen:palettes` 生成（`scripts/generate-palettes.mjs`）。
- dsh-TUI 主题文件在 `themes/`（四个风味各一个 `~/.dsh-tui/themes/` 用 JSON），由 `pnpm gen:themes` 生成（`scripts/generate-tui-themes.mjs`，读同一份官方色板缓存）；改键映射后重跑并核对 dsh-TUI `src/theme.ts` 的 Theme 键。
- TUI 安装入口是 `src/tui-themes.ts`（子路径导出 `./tui-themes`，cordis.patch.yml 第二行）：激活时幂等同步主题到 `~/.dsh-tui/themes/`；dsh-TUI 没有主题注册 API，目录是唯一接缝，`catppuccin-*.json` 命名空间归本插件所有、同步即覆盖。
- 插件预览图（README 专用，存在 `assets/previews/`）：`scripts/screenshot-previews.cjs` 出四风味图、`scripts/screenshot-glass.cjs` 出玻璃图、`scripts/combine-previews.py` 合成斜切大图（输出 `combined.png` / `glass-combined.png`，`hero-mocha.png` 是中间产物、已入 `.gitignore`）。三者都要求本地 GUI 跑在 `http://127.0.0.1:3080`；`screenshot-previews.cjs` 已修好并端到端跑通（2026-09-18/21），但**必须把 `dsh web` 打印的 token 传进去**：`node scripts/screenshot-previews.cjs <token>`。不带 token 时 bare origin 回 401 空白页，脚本会以 `openSettings` 90s 超时的形式失败——这是它长期卡住的真因（其余两个：行标题 `?` 徽标让 exact 文本匹配恒为 0；弹窗内「跟随系统」有两处）。**每张风味图都在关闭设置弹窗后拍**：弹窗遮罩会把整页压暗（实测侧栏读成 `182,183,186` 而非 Latte 的 `239,241,245`），脚本会断言弹窗确已关闭，否则直接报错而不是交出一张暗图；出图后跑一遍 `combine-previews.py` 同步 `combined.png`。
- **`assets/` 不进 npm 包**（`package.json` 的 `files` 不含它，图片只在 README 用），所以 README 里的图片一律写**绝对** `raw.githubusercontent.com` URL——别改回相对路径，否则 npm 页面会失去图。
- 对外 API 文档：`pnpm docs:api`（typedoc）→ `docs/api/`。**该目录不入库**（已 `git rm --cached` + 进 `.gitignore`，见 WW），本地按需生成即可；生成物当前是旧的（本次已重生成，但以后只在需要时重建）。重跑时 typedoc 会打一条 `origin` remote "not valid" 的警告——**实测是虚警**：链接照样生成，且指向当前 commit 的 permalink（`blob/<sha>/src/...`），无需改配置。真要自己写模板就用 `disableGit` + `sourceLinkTemplate`，注意 `{path}` **不含 `src/` 前缀**（否则生成 404 链接）。
- `src/profile-detect.ts`：更新检查里「自动探测当前 profile 名」的实现（探测失败回退 `web`）。
- CI 配置：`.github/workflows/ci.yml`（push main / PR，只读权限）——两个 job：`check`（install + typecheck + build + test）与 `boot-e2e`（**启动级 e2e**，见下一条；独立 job 是因为它要装宿主 + 下载 Chromium，且与 `check` 并行，实测 +54~73 s）；发布另有 `.github/workflows/publish.yml`（`v*` tag / 手动 dispatch，OIDC 可信发布，无 token 入库）。**普通提交只靠 ci.yml 把关**——发布链路里才跑检查的旧格局已经让两次发版失败（幽灵类型依赖、跨测试污染）。
- **启动级 e2e**：`scripts/e2e-boot-check.cjs`（**在仓库里**，不是本机探针目录）。做法：临时 `DSH_HOME` → `dsh plugin --profile web add link:<repo>` → `dsh web --no-open --port 0`（token 在 stdout）→ 走掉宿主首次运行引导（2 步：内测声明「继续」、API Key「稍后配置」）→ 打开设置、进入插件的 **Catppuccin 分区**（issue #27；断言 scope 到 `[data-catppuccin-settings]`）断言行/风味/玻璃开关（**2026-10-18 起**：宿主钉 `0.2.1-rc.2`，设置入口按宿主形态分流——≤0.2.0 是侧栏脚独立「设置」按钮，0.2.1 起是「账号菜单」→「设置」；`0.2.x` 设置面板是覆盖全屏的 modal，页面级采样前先 Escape），并采样**级联后**的关键计算样式（侧栏玻璃片不得有 `backdrop-filter`、composer 卡必须保留、compat 下浮动面有 rim 而 `panel` 不被描边、**issue #16：右侧栏容器关闭态不得有 blur**——真会话下查宿主渲染出来的 `[data-sidebar-right-panel]`，新 `DSH_HOME` 无会话时跳过；另有**不依赖会话**的合成 markup 版本，往真页里塞一份 `P3OORG_panel` + `P3OORG_panelBody` 读计算样式，真 Chromium 真样式表，带「容器外的同名类仍必须被模糊」的对照组）。本地跑法：`pnpm build` 后 `NODE_PATH="$APPDATA/npm/node_modules/@playwright/cli/node_modules" node scripts/e2e-boot-check.cjs`（想验证某个具体 DSH 版本就加 `DSH_BIN=<该版本>/node_modules/@deepseek-ai/dsh/lib/bin.js`）。**刻意不做整图 diff**（理由与方案取舍见 `docs/plugin-improvements.md` §3.9）。已知边界：新 `DSH_HOME` 没有工作区/会话 ⇒ PP 选中行采样**会跳过并打印 skipped**（不会假绿）；改过视觉后仍应手动重出四风味预览（上一条）。**2026-09-27 在 `0.1.7-rc.2` 上实测的三个坑都已在脚本里修掉**（别再改回去）：① 首次运行向导是多包拼的多步流程，**步骤切换的间隙整棵子树会短暂脱离 `role=dialog[aria-modal]`**，只看 dialog 会在第一步「继续」后就收工，之后每次点击都被残留的 `_mask_*` 遮罩拦下（30s 超时）⇒ 找不到 dialog 时按按钮文案在全页找、并轮询到遮罩消失；② **「兼容模式」那一次点击会静默不生效**，于是它下面所有 compat 断言都在「compat 其实没开」的状态下取样（rim 找不到 / `panel` 没描边 / 右侧栏没 blur 一起假绿）⇒ 必须轮询到 html 真挂上 `data-dsh-glass-compat` 再往下，并把这个切换本身也断出来；③ 本机 `%LOCALAPPDATA%\ms-playwright` 被清空时退到**系统 Chrome** 并加 `--no-proxy-server`（本机沙箱的 `HTTP_PROXY` 会吃掉 localhost）。另外：临时 `DSH_HOME` **可能会自动建出一个默认会话**（本机 rc.2 实测有），所以右侧栏那条真机断言不一定跳过——它跳过时说 skipped，跑到了就给出真数字。
- **「已实现」≠「接线正确」（2026-09-22 审计教训）**：那轮两个 P1——跨窗口旋钮不同步、读侧陈旧写保护恒不成立——都通过了类型检查与当时全部 158 条用例，因为缺陷恰好落在**没有事件穿过的分支**（`event.key in NUMERIC_KEYS` 判的是属性名）和**时序假设**（两次 `getSnapshot()` 在同一同步块）上，只读代码看不出来。改交互/持久化代码时补两类测试：**接线测试**（每个 `if`/`switch` 分支至少被一个真实事件穿过——例：`tests/glass-layer.spec.ts` 把 `storage` 处理器的每个分支各走一遍）与**时序测试**（用可注入的 revision 模拟「防抖窗口内先被外部改过」——例：`createBaseRevisionTracker` 的用例）。修 bug 时**默认用变异测试证明新断言会红**（改回旧写法跑一遍），完整清单见 `docs/code-audit-2026-09-22.md`。
- 本机 `bash` 环境缺 coreutils（`ls`/`sed`/`grep`/`sleep` 都可能 not found），要跑脚本请走 PowerShell 工具或 `node -e`；`git` / `gh` 可用。**`rm` 也被 shim 拦**：删文件用 `node -e "require('node:fs').unlinkSync('x')"`。

- **可选改动项要先问维护者**：`docs/issue-28-fused-composer-plan.md`（issue #28 的 **B 方案**——输入卡与 dock 合成一个圆角框 + 中间分割线 + 设置里的开关，默认关，特性 / `0.7.0`）**只是方案，未批准实施**。任何会话都不要自行开工、不要「顺手把开关加上」，先让维护者明确回答「做 / 不做」。同一 issue 的 **A 方案**（dock 补背板，修复 / `0.6.x`）已实施（`0ce81ff`）并随 `0.6.3-beta.3` 预发布带上。

## 与报告人协作（issue / 评论 / 关闭）

- **对外发言必须先经维护者同意**：issue 评论、关闭、任何公开文字都先问（用户明确要求过两次）。内部动作（读、改代码、本地测量）不必问。
- **评论里每个数字都要可复核**（实测值 + 口径），并且写成「**预期 + 依据 + 不达标怎么办**」三段式；不要承诺没有证据的效果。已发布 ≠ 已验收。
- **关闭时写明重开条件与下一手**。症状若是「收益 / 占用」这类只有报告人硬件能测的东西，先例（#13）是：写清已修内容 + 代理证据 + 「若不降请重开，我立刻上批次 B（退顶栏 `-95px` 自造重叠）」。不要为了看板干净而提前关。（**后续**：2026-09-21 维护者判断无需复测，批次 B 也随之不排期——该先例本身仍成立，只是这一单的下一手被主动放弃了。）
- **关闭者是谁，决定「关闭」能证明什么（2026-10-22 补，踩过）**：`gh issue list --state closed` 只给 `stateReason=COMPLETED`，**看不到 actor**——必须查 timeline 的 `ClosedEvent.actor`（GraphQL `timelineItems(itemTypes:[CLOSED_EVENT])` 或 `/issues/<n>/timeline`）。实测：`#14` 由报告人 `Thytheiu` 关，`#24`–`#29` 由报告人 `TWFU-wcy` 关（其中 `#27` / `#28` / `#29` 关闭前 **0 条评论**），其余为维护者关闭。**报告人自行关闭 ≠ 维护者验收**：它只说明「他那边看起来好了」或「他不再跟进」，验收结论仍只能来自真机实测 / 测试。⇒ 进度文档里凡报告人关闭的 issue，必须同时注明**关闭者**与**关闭前是否有我方回复**。
- **回复稿要真的贴出去（2026-10-22 补）**：`.debug/issue-<n>/reply.md` 只是草稿，**贴到 issue 才算数**。#27 / #28 / #29 的稿子都写好了，但关闭前 issue 里 0 条评论——报告人是在没看到任何说明的情况下自己关的。发版修好后的顺序应是：**先贴修复说明（版本号 + 升级方式）→ 再关 / 等报告人关**；草稿留在 `.debug/` 不算完成。
- **审报告人的判据**：先分清他给的每个读数能证明什么。先例（#12）：白底 `#fff` **不能**证明「当时用的是官方主题」——本插件亮度旋钮 100 也给白底（`--dsh-glass-brightness-white: 1`）；能当判据的只有**文字 token**（官方 caption `173,178,184` / secondary `97,102,107` vs Latte `#7c7f93` / `#5c5f77`）。
- **反过来：我们给他的判断也要先实测再发（2026-10-27 复盘）**。三条规矩，先例见
  `docs/issue-audit-reporter-vs-agent.md`：
  1. **评审他给的补丁 → 重建可运行变体跑测试，再下结论**。读 diff 摘录判断分支位置本轮错了两次
     （#30「两处必须修」全部撤回）；重建时注意单文件 bundle 里本来可见的 import 要补，否则异常被
     cordis notify 吞掉 → **测试假红**，看起来像补丁失效。
  2. **说「成本高 / 做不到」之前跑最小实测**。#17 的两处成本论：通用的 CSS 排除（`!important + initial`）
     实测会把**宿主自己的**底色一起抹掉，`@layer` 又会让材质在所有宿主声明过 `background` 的地方失效
     ⇒ 机制判断成立；但「两套设置 API 各写一遍」**是错的**——两套 schema 出自同一张
     `catppuccinSchemaFields()`，真实成本在 `stateToMutateOps` / `settingsSectionsEqual` / Host schema /
     设置行 UI 四处。
  3. **写「没有 X」前先问「我的 grep 覆盖了谁」**。#17 那句「DSH 与本插件都没有通用自定义 CSS 入口」源于
     只扫上游 + 本插件，被报告人用 `dsh-better-sidebar@0.21.1` 的 `customCss` 当场纠正（gate =
     `titleBarScheme === 'custom'`，注入属性 `data-dsh-custom-css`）。范围不够就写「在本插件与上游范围内
     未发现」，别写成「不存在」。
  另记一条**部分成立**的：#17 ②「`:where()` 只降权重、不阻止规则生效」——实测它**能**救回宿主自己也声明
  过的属性（代码块底色），但救不了「宿主没声明」的元素、也去不掉 blur 成本；正确说法是「只修 A2 那一类」。
- 报告的机制推断**逐条核对**后再回：本轮 #13 的两处表格错（边缘渐变条、composer 卡片都不是 mica 独有）就是这样查出来的——**自己代码注释里的同类说法也要一起改**。

## 本机测量资产（真页 A/B 与面积账）

### 真机验证某个具体 DSH 版本（2026-09-24 打通，issue #15 用过）

社区桌面壳（`D:\PROGRAM\DSH`）**不自带 DSH**：它按版本把运行时下到
`%APPDATA%\DSH\data\versions\<ver>\node_modules\@deepseek-ai\`（该目录**自带整套 0.1.7 包 + schemastery 3.18.4**），
`%APPDATA%\DSH\data\config.json` 的 `versions` 列出已装版本。所以「验证 0.1.7」不需要动全局 CLI（那里还是 0.1.5-rc.2）：

```bash
V="C:/Users/<you>/AppData/Roaming/DSH/data/versions/0.1.7-rc.1/node_modules/@deepseek-ai/dsh/lib/bin.js"
node "$V" --version                                              # 0.1.7-rc.1
node "$V" plugin --profile web add @nonamelego/dsh-catppuccin@beta
node "$V" --profile web --no-open --port 19411                   # 前台跑，token 在 stdout 的 URL 里
```

- **host 侧**：插件 host 半区日志只走 stdout（`console.info/warn`），直接在启动日志里 grep。
- **client 侧**（`pending (waiting for service: …)` 这类）**只在浏览器控制台**，stdout 看不到 ⇒ 必须起页面。
- 起页面：Playwright + **系统 Chrome**（`C:/Program Files/Google/Chrome/Application/chrome.exe`，无需下载浏览器），
  `NODE_PATH="$APPDATA/npm/node_modules/@playwright/cli/node_modules"`，**必须加 `args:['--no-proxy-server']`**
  ——本机沙箱有 `HTTP_PROXY=127.0.0.1:1793`，localhost 请求会被代理吃掉（报 502/连接被拒）。
- ⚠️ **别用 `(node ... &)` 起宿主**：Bash 调用结束时进程会被清掉，日志为空。要长期存活就用后台任务方式起（前台 node 包在后台任务里）。
- 落盘位置（0.1.7 新 seam）＝ `$DSH_HOME/profiles/<profile>/cordis.patch.yml` 里该条目的 `config:`
  ——改一个旋钮后 `grep -A13 'id: dsh-catppuccin'` 就能确认写通。

- **官方桌面壳也能直接驱动（2026-10-21 打通，⑤ / #29 的真机测量就是这么做出来的）**：
  `env -u ELECTRON_RUN_AS_NODE -u NODE_OPTIONS "D:/PROGRAM/DeepSeek Harness/DeepSeek Harness.exe" --remote-debugging-port=9222`
  ⇒ `curl --noproxy '*' http://127.0.0.1:9222/json/list` 拿到 `dsh-app://app/` 的 `webSocketDebuggerUrl`，
  再用 `Runtime.evaluate` 在真页面里跑探针。⚠️ **坑**：agent shell 常带着 `ELECTRON_RUN_AS_NODE=1`
  （WorkBuddy 自己的 Electron 运行时会把该变量传下去），不清掉 exe 会被当 node 跑，报
  `bad option: --remote-debugging-port` 并立即退出 —— `docs/issue-24-switch-flicker.md` 曾据此误判
  「壳从工具上下文拉不起来」。现成资产：`.debug/frame-audit/cdp-run.cjs`（Node 22 内置 fetch + WebSocket，
  无依赖，用法 `node cdp-run.cjs <探针.js>`）+ `probe-header-width.js` / `probe-drag-recompute.js`。
  桌面壳的 `desktop` profile 已 `link:` 本仓库 ⇒ 改完 `pnpm build` 重启壳即生效，不需要改 `cordis.patch.yml`。

- **配置真源**（版本相关，issue #15 起）：**≤ 0.1.6-alpha.2** 是 `~/.dsh/settings.yaml` 的 `catppuccin:` 段（插件 `installSection` 注册的命名空间）；**≥ 0.1.7-alpha.1** 改成 profile patch `$DSH_HOME/profiles/<profile>/cordis.patch.yml` 里 `dsh-catppuccin` 条目的 `config:`，即插件 volatile `Config` 表单，Client 用 `ctx.configForms.get('dsh-catppuccin')` 读写——表单 ns **就是 profile 条目 id**，与 `cordis.patch.yml` 的 insert id 是硬契约（`CATPPUCCIN_ENTRY_ID`，有断言钉住）。两套 seam 由 `src/client/state-sync.ts` 的通道适配层同时支持，**任何一侧都不能写进硬依赖 `inject`**（写进去会在另一侧永久 pending，这就是 #15 的现象）。`~/.dsh/catppuccin-state.json` 自 0.5.0 起只是**一次性迁移源、此后不再跟踪**（2026-09-24 复核：该文件与 `settings.yaml.imported` 的 `glass.brightness` **都是 `50`**，与 `DEFAULT_GLASS.brightness` 一致——早先记的「真值 100」自 9-21 起已不成立；引用旧文件仍会误导，因为它不含 `updateChannel` / `shikiStyle` 等后加字段）——引用旧文件会把玻璃参数写错。方案与实测判定见 `docs/issue-15-settings-seam-0.1.7.md`。
- **起 GUI**：`node <npm>/node_modules/@deepseek-ai/dsh/lib/bin.js web --no-open`（**token 在 `dsh web` 的 stdout**——`%TEMP%\dsh-web.log` 会过期，引用它会让浏览器/探针打开一个 401 空白页；`dsh web` 默认会弹浏览器，加 `--no-open`）。
- **探针目录**（**未入库**；原在 `D:\Vibe-Coding\.cache\glass-blur-probes\`，**2026-09-24 复核：已随缓存清理丢失**，需要再做测量时按下列用途重建）：`area.cjs`（面积账：4px 栅格取**可见面积并集** + compat 选择器模拟）、`uniform.cjs`（判定「填充变了」还是「文字重栅格化」）、`diag2.cjs`（稳定性 / 合成栈 / 注入是否生效）、`bubble.cjs`、`real.cjs`、`probe12.cjs`、`probe-ground.cjs`、`gpuverify.cjs`（负结果）。入库的同类证据只剩 `.debug/compat-probe.mjs`（交叉版本 seam 探针，8 组判定）与 `.debug/probe-017.cjs`（真机 0.1.7 探针）。
- **跑法**：`NODE_PATH="$APPDATA/npm/node_modules/@playwright/cli/node_modules" node <x>.cjs <token>`——必须 `.cjs` / `require`（`NODE_PATH` 只对 CJS 生效），Chromium 显式给 `executablePath = %LOCALAPPDATA%\ms-playwright\chromium-1228\chrome-win64\chrome.exe`。
- **三条硬要求**：① **噪声底线先收敛**（轮询到两张连续截图完全一致再测；首轮 UNSTABLE 时的数字不可引用，本轮首轮 2.79% 就这么来的）；② **A/B 双向显式注入**并核对 `getComputedStyle` 实际值（本机装的可能还是旧版，只注入一侧等于测空气）；③ **控制项必须 DIFFERS**（把地面换成高对比条纹，差异必须巨大），否则全零的 A/B 什么都没证明。
- **已知无效方向，别再花时间**：**「占用率」不能靠 trace 的时间自证**——headful + CDP trace（`devtools.timeline,cc,gpu`）在 6s 滚动负载下 blur 开/关的 composite 时间差落在噪声里（3178 vs 3254 ms，同配置漂移 50 ms），负载已把合成管线压满；报告人测的占用率在本机不可复现。（另：`Tracing.start` 后必须 `Tracing.end`，否则 `tracingComplete` 不触发、下一次 start 会报 "already been started"。）
