# Changelog

本项目的所有重要变更都记录在此文件。

格式遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)（`0.x.y` 正式版，
`0.x.y-beta.n` 预发布 → `beta` npm 标签）。

## [Unreleased]

> 本节 = **`0.6.5-beta.0`** + **`0.6.6-beta.0`** + **`0.6.5-beta.2`**（预发布按仓库惯例不单独落版本节）。
> `0.6.5-beta.2`：**issue #31**——快速切换风味偶发失败的修复（迟到的文档回声不再回滚更新的本地选择）；
> 同时把误发的 `0.6.6-beta.0` 版本号归位（该预发布的内容已全量包含在本版里）。
> `0.6.6-beta.0`：**issue #30 补充**——首屏不再先闪官方深色（pre-paint 调色板注入），
> 方案与取证见 `docs/issue-30-first-paint-flash.md`。
> `0.6.5-beta.0`：**issue #30**——新 origin（新端口 / 清站点数据 / webview 分区）首次加载把配置
> 重置为出厂默认的修复，方案见 `docs/issue-30-boot-pending-push.md`。

### 修复

- **快速切换配色不再被迟到的文档回声回滚（issue #31，2026-10-27）**。症状：连续点几个风味，最后一次
  **偶发不生效**——界面先切过去、零点几秒后被切回上一个，且没有任何「另一窗口已更新」提示；真机实测
  （官方桌面壳 + CDP + 给 `Storage.prototype.setItem` 打栈定位写入者）拿到的是
  `select() → writeFlavor(新值)` 之后 0.1–1.4 s 出现
  `applyScopeSnapshot → writeFlavor(旧值)`，随后排队的防抖 flush 又把这个被回滚的值写进
  `cordis.patch.yml`，于是用户的选择在屏幕和磁盘上同时丢失，连冲突横幅都没有。根因：采纳路径的
  「回声判据」只有一条「本地 == 文档 → 跳过」，它不知道**本地还有一次更晚的变更没落盘**（在防抖队列里
  或在途）——于是把自己早先那笔写的回声当成外部真相，按「文档优先」覆盖了更新的本地选择。写侧
  （`persistStateToScope`）有 `baseRevision` + `ourOwnEcho` 两道护栏，读侧一直没有，两侧不对称。
  修法四条：① `queuePersist()` 在同一处记录 `pendingLocalSection`（本地最新意图，flush 结清才清空），
  采纳前若「有未落盘意图且快照 section ≠ 该意图」则**不采纳**；② 增加命名空间 revision 高水位，
  **快照 revision 倒退**即判为过期视图（迟到的 describe 读、被后写覆盖的答复），不采纳；③ 真正采纳时
  `cancelDurablePersist()` 并丢弃已捕获的 base revision（否则排队的 flush 会把回滚值写盘）；
  ④ 主题侧 `reapplyThemePrefs()` 不再 dispose-all —— 上游 `register()` 的 disposer 会把**当前**偏好
  重置成默认值，原来全靠一个 microtask 拉回，丢一次就是「点了没反应」；现在只回收活跃风味并在**同一个
  同步块**里 `setTheme` 补回。顺带：restore 不再经过 `setTheme` 包装器（否则「关掉风味」会被记成
  「本次会话显式选了 dark」，`builtinPickWins()` 之后会否决所有风味恢复）；`select()` 里 `setTheme`
  失败不再静默（强制重注册重试一次，仍失败则回滚缓存 + 报冲突）；`scheduleRestore` 的合并改为记住
  **最后一个** desired（原来丢弃后来的意图）。
  **测试 373 → 378**：`tests/reentrancy.spec.ts` 新增 5 条（回声不覆盖 / 过期视图不采纳但新编辑仍采纳 /
  回收注册时偏好不掉 / off 恢复不算一次 pick / 注册被跳过时的重试与回滚）。**五组变异全部验证会红**：
  去掉 pending 闸门 ⇒ 首条红；去掉 revision 高水位 ⇒ 第 2 条红；`reapplyThemePrefs` 改回 dispose-all ⇒
  第 3 条红；off 恢复改成记录 ⇒ 第 4 条红；去掉强制重注册 ⇒ 第 5 条红。
  方案与真机取证：`docs/issue-31-theme-switch-echo-race.md`。⚠️ **未跑**：前台窗口下的真机复测
  （本轮实测窗口是隐藏的，定时器被节流到 ~1 s，竞态窗口被拉宽，3 次里复现 2 次）。

- **首屏不再先闪官方深色（issue #30 补充，2026-10-27）**。症状：`flavor` 已持久化为
  `catppuccin-frappe`，页面首帧仍是官方深色（报告人实测首帧中心像素 `#151517`），随后才切到风味。
  原因不是持久化：官方 `dsh-client-ui-theme` 的 Host half 经 `webserver/index-inject` prepend 两条
  启动行（head `:root{color-scheme:dark}body{background-color:#151517;--dsh-boot-bg}` + body script 设
  `data-ds-dark-theme`），而口味主题只能在 Client bundle 执行后 `register` + `setTheme`，必然晚于首帧。
  修法（与官方同一接缝）：Host 新增 `src/boot-palette.ts`，`webserver/index-inject` 时把**当前持久化
  风味**的整张 `--dsw-*` token 表（190 条/风味，含用户 overrides，过滤掉能逃出 `<style>` 的字符）
  作为 head 行注入，并补一条 body script 把 `data-ds-dark-theme` 对齐到该风味的 `colorScheme`；
  选择器用 `html body` / `html body[data-ds-dark-theme]`（压过 Client bundle 里以 `body` 声明的官方
  表，**不靠行顺序**）。Client 侧 `src/client/boot-palette.ts` 在**风味真正生效时**摘掉这张表
  （`setTheme` 包装器 / `applyDesired` 的两处早退 / 显式 off / 10 s 兜底 / 插件卸载），留在 DOM 会
  钉住全部 token、让后续切 light/off 失效。
  **只在 DSH ≥ 0.1.7 注入**：legacy 宿主的 `config.flavor` 是 profile patch 的静态值而不是持久文档，
  照着画会画错（`bootPaletteRows` 只接受 volatile ref）。`flavor: off` 时**一行都不注入**。
  **测试 360 → 373**（22 文件）：Host 侧 8 条（off / 未知 id / legacy 闸 / 四风味整表 / 画布色可推导 /
  元素逃逸 / overrides 过滤与位置）+ Client 侧 5 条（摘除幂等 / 不碰别人的 `<style>` / 风味生效后摘除 /
  显式 off 摘除 / 无表 no-op）。两组变异验证会红：去掉 `setTheme` 里的摘除 ⇒ 摘除用例红；去掉 volatile
  闸 ⇒ legacy 用例红。另用**真实宿主渲染器**（rc.3 的 `renderIndexInjections`）交叉验证过：2 行、
  `html:head` + `script:body`、head 里 286 处 `--dsw-` 声明、整段 HTML 11.6 KB、`off` 时 0 行。
  ⚠️ **未跑**：真机首帧像素采样（步骤在 `docs/issue-30-first-paint-flash.md` §7）。

- **新 origin 首次加载不再把配置重置为默认值（issue #30，`0.6.5-beta.0`）**。症状：`cordis.patch.yml`
  的 `dsh-catppuccin.config` 被真实改写成 `flavor: off` / `glass.enabled: false` / `mode: mica`，页面
  退回官方深色。根因不是用户操作——`pendingLocalPush`（R2 机制：boot 窗口内的改动不能被首个快照回滚）在
  scope 还没 `ready` 时被**任何**一次 `queuePersist()` 置位，而 `GlassLayer` 在每次 `theme/change`
  上无条件 `publish()`（`ui-theme` 每次 boot 都会 `adopt()` 一次偏好）⇒ 正常加载就 arm；首个可用快照
  随即走"回写"分支，`stateToMutateOps` 一次写全 11 个字段，而在空 origin 上"本地状态"就是出厂默认。
  修法三条：① `src/state.ts` 新增纯函数 `replayLocalChanges()`，把"boot 窗口内改过的**字段**"叠到
  文档上，其余字段保留文档值——没有任何字段真的动过时（空 origin 的 boot publish 全属此类）**不写任何东西**，
  直接走原本的"文档优先"采纳路径；② `queuePersist()` 只在"本地 ≠ 上次同步点"时才 arm（滑杆热路径零成本：
  只在 scope 不可用时比较）；③ 玻璃层订阅只在**持久化字段**真的变化时才排持久化，`theme/change` 引起的
  republish 不再排一次无谓 flush（顺带掐掉它可能撞出的假"另一窗口已更新"横幅）。
  同时把 `settingsSectionsEqual` 里的 overrides 双向比较抽成 `sameOverrides()`，让两处规则只有一份。
  **测试 353 → 360**：`replayLocalChanges` 6 条（含"每个持久化字段必须有变异器"的漂移护栏）+ `apply()`
  级的 issue #30 回归 1 条（空 localStorage + 文档带 user layer + boot 期 `theme/change` ⇒ 0 次写入且采纳
  文档）。三组变异验证会红：删掉任一字段的搬运 ⇒ 漂移护栏红；把"只搬动过的字段"改回整段搬运 ⇒ 首条用例红；
  把 arming 与回放同时改回旧写法 ⇒ `apply()` 级回归红。
  **已知空洞（接受）**：增量法分不清"没动过"与"显式设成默认值"，boot 亚秒窗口内把某项改回默认值会被文档
  覆盖回去——方向是文档优先，不丢持久数据。
  另：报告人的补丁经**重建可运行变体跑测试**复核为有效（16/16 + 28/28），本人初稿列的"两处必须修"
  是误判，已在本节对应文档 §4.4 更正。


## [0.6.4] - 2026-10-21

> 本版 = `0.6.4-beta.0` **转正** + 顶栏宽度的第二半修复（框语言 ⑤）+ 首次真机验收 + 玻璃预览图重拍。
> 内容：issue #29 状态栏背板改磨砂幕布（同色 α70~84% + blur + 顶部 18px mask 淡入）＋ 框语言审计
> 四条框规则统一 ＋ ⑤ 顶栏 / 轨迹面板跟随输入卡宽度（**本版补上 `width: 100%`**，此前 `max-width`
> 撑不开 fit-content 盒，顶栏只有 266px 而卡 856px）＋ 玻璃预览图重拍（旧图顶栏正是 ⑤ 的塌陷态，
> 且侧栏展开了、露出真实工作区名）。**测试 352 全绿**（20 文件）。
> 真机验收（官方壳 `0.2.1-rc.2` / Electron 44.7.0）：#29 的 α / blur / mask / 几何逐项实测通过，
> #19 命令面板祖先链 `backdrop-filter` 命中 0，框语言 ①②③⑦ 与 issue #27 的设置分区目视通过；
> #29 的四风味全矩阵与 ⑤ 的折叠分支未能在真机触发（环境限制已写进对应文档）。

### 变更

- **顶栏宽度补回 `width: 100%`（2026-10-21 真机验收，框语言 ⑤ 的补丁）**。⑤（`4c4ff21`）给顶栏加了
  `max-width: min(卡宽, 100% - 32px)`，可同一条规则里的 `margin: 12px auto 0` 把块级盒降成了
  **fit-content**——`max-width` 只是上限，撑不开盒子。真机实测（官方壳 `0.2.1-rc.2`、mocha + mica、
  1280×822）：顶栏只有 **266px**，而它下面的输入卡 856px；把 `data-dsh-glass-float` 摘掉回 stock
  则是 **1000px 铺满整列**，证明缩水是本皮肤造成的。修法两行：展开态补 `width: 100%`（随后由既有
  `max-width` 收口到卡宽、`margin: auto` 保持居中），折叠分支 `[data-sidebar-collapsed]` 补
  `width: auto`（那一支的 margin 是固定 28/16，`100%` 会多出 44px 溢出）。修后顶栏 856 = 卡 856，
  左侧 352 vs 349——3px 是卡自身的 border/padding，未追（要抹平就得动 padding，与「只对齐宽度、
  不动布局」的前提冲突）。`tests/glass-css.spec.ts` 的 ⑤ 用例补两条断言；变异（删掉 `width: 100%`）
  已验证会红。顺带确认 ⑤ 的另一半（轨迹面板）本来就有显式 `width: calc(100% - 32px)`，没有同样的问题。

- **输入卡下方的状态栏换成磨砂幕布（issue #29，2026-10-19）**。`0.6.3` 给那条状态栏补的背板是
  **不透明的地面色**，报告人反馈它像「一块焊在输入卡下面的实色板」：质感与顶栏 / 侧栏割裂、
  滚动时正文被硬切、遮挡感重。改法保留几何（全宽出血、`z-index:-1`、不骑卡），只换材质：
  **同色 α70~84% + `blur(var(--dsh-glass-blur))` + 顶部 18px `mask-image` 淡入**。
  三条取舍：① 填充**仍然取地面色**而不是 `--dsh-glass-card`——这条带子是全宽出血的，任何比地面亮的
  面都会在页面底部画出一块矩形（正是 #28 决定 4 躲开的东西），而地面色在任意 alpha 下对纯地面
  逐像素不可见；② **α 有 70% 硬下限**，因为出厂「clear」预设是 `blur: 0`，再低正文就会从状态栏
  读数底下透出来（#28 原地复活）；③ blur 只上 `::before`，dock 元素保持零绘制，不让它变成模型弹层
  的 backdrop root（#19）。`mask-image` 会同时淡出填充与 blur 输出（与页面上下渐隐带同一机制），
  所以正文是「化开」而不是「被切断」。否决了「dock 变玻璃 pill」的替代方案：dock 是居中 flex、
  内容不满宽，pill 两侧会原样露出正文。全量与 A/B 对比见 `docs/issue-29-dock-glass-veil.md`。

- **把四个「框」的语言统一（2026-10-19，框语言审计）**。一张真机截图暴露出四类框各说各话，
  逐像素量完后改四条，**不动配色、不动布局**：
  - **设置对话框补上投影**（mica + compat 两处）：它浮在遮罩最上层，却只有内描边光、没有
    `--dsh-glass-drop`，比它下面的顶栏 / 侧栏 / 输入卡都平。
  - **模态圆角 14 → 20**：接近整屏高的面板比同一列上方 20px 的顶栏卡还方；小的 `role=dialog`
    弹层（上下文用量）仍是 14，不受影响。
  - **侧栏「新会话」按钮的描边降到 soft**：它原本拿 base rim（暗 24% / 浅 18%），比它所在的
    侧栏卡（soft，16% / 12%）更亮——容器不该比自己的内容还淡。由此定下「外框 ≥ 内框」。
  - **暗色菜单补回 1px soft 描边**（`outline` + 负 offset，不改盒模型）：这是第 3 轮为 Latte
    撤掉的框，**Latte 仍然不加**，只给暗色——弹层压在密集正文上时需要一条边才立得住。
  **输入卡刻意不动**：维护者确认「输入框亮一些」是本意（30% 强描边 + 双层影 = 主输入面），
  因此它保持 24px 圆角、保持比顶栏更强的描边。
  取证与全部实测数字见 `docs/frame-language-audit-2026-10-19.md`。真机四风味 × mica/compat
  的观感确认待补（本机 Playwright 不可用），`tests/glass-css.spec.ts` 新增 4 条护栏锁住这四条决定。

- **顶栏与轨迹面板跟随输入卡的宽度（2026-10-19，框语言审计 ⑤）**。上游有两套互不相干的定宽规则：
  顶栏 = 整列 − 32px，输入卡 = 阅读列 + 32px（阅读列由宽度手柄拖拽、上限 = 列 − 176px）。两张卡
  都有描边之后，这条错位成了「两个框没对齐」——实测每侧差 56px，未拖手柄时反而差 225px。
  现在顶栏与轨迹面板共用输入卡的宽度上限并居中（`min(calc(var(--dsh-chat-user-width, …) + 32px),
  100% - 32px)`，表达式内联、不经过中间变量——#25 的失效传播陷阱）；折叠侧栏时回退到原来的满宽，
  旧宿主（没有宽度手柄）回退到设计上限 952px。**代价**：顶栏变窄后标题与标签行会向内收，需要用
  窄窗口再看一眼。

## [0.6.3] - 2026-10-19

> 本版 = `0.6.3-beta.0/.1/.2/.3` 一路**转正** + issue #27（设置独立分区）+ issue #28
> （输入卡下方状态栏补背板）+ 上游 DSH 0.2.1 适配（settings seam 的 `mode` 被上游删除，
> 插件一度改设置不落盘）。

### 变更

- **兼容下限抬到 DSH `0.1.7-rc.1`（2026-10-18）**。issue #27 起设置页直接消费官方
  `@deepseek-ai/dsh-client-ui-primitives` 的 `Switch` / `SegmentedControl` / `Button`，
  其中 `SegmentedControl` 直到 **`0.1.7-alpha.1`** 才加入该包（0.1.5 / 0.1.6 线的 primitives
  没有它），旧宿主打开设置页会因组件未定义而渲染失败。因此 `engines.dsh` 与 store 用的
  `dsh.compatibility.dsh` 一并由 `>=0.1.5-rc.1` 抬到 `>=0.1.7-rc.1`，启动级 e2e 的宿主也从
  `0.1.5-rc.1` 换到 `0.2.1-rc.2`。⚠️ 兼容门由宿主自己实现：`0.2.1` 起读 `engines.dsh`，
  更老的宿主只读 `peerDependencies`（本包没有声明 dsh peer），所以这次收口主要在声明与
  商城元数据层面；0.1.5 / 0.1.6 宿主仍会装上，建议这类用户先升级宿主。

- **设置项从「通用设置」收敛到独立分区，控件改用官方原子件（issue #27，2026-10-17）**。
  报告人指出四条设置行平铺在「通用设置」里，与官方原生设置项混排——视觉割裂、层级混乱、
  可发现性差。改法不是"再多注册一个行"，而是**换座位**：注册 `settings.section`
  （导航项「**Catppuccin**」，`order 25`，排在官方节之后；页内标题「Catppuccin 外观设置」），
  同时**删掉**原来 4 条 `settings.general.item` 注册——两处入口并存会立刻回到"平铺"的问题。
  控件换成 `@deepseek-ai/dsh-client-ui-primitives` 的 `Switch` / `SegmentedControl` / `Button`
  （引官方件而不是另起一套仿制品，`docs/web-styling.zh.md` 的组件规则要求）；风味选择按官方
  theme cube 规格重绘；滑块上游没有原子件，保留 `range` 但右侧数值改成可手输的输入框。
  插件详情页（`plugins.bundle.config`）那张卡片保留，作为第二个入口。`settings.section`
  自 `0.1.5-rc.3`（本插件兼容下限）就存在，**不需要**为旧宿主做降级回退。
  取舍与取证见 `docs/issue-27-settings-section.md`。

- **地面氛围层：纯色底 → 同色系渐变 + 两枚静态柔光斑（issue #25）**（2026-10-15）。
  报告人（`TWFU-wcy`）指出「纯色背景下毛玻璃效果不明显，界面失去层次感」。根因两层：
  ① 地面纯色，玻璃没有内容可透 / 可模糊；② 卡填充与地面本来就同色——填充 = `bg-layer-1 × α`
  叠在 `bg-base` 上，暗色三风味 ΔRGB ≈ 2/255（默认 frost 20），**Latte 恒 0**
  （`layer-1 === bg-base`），每块玻璃都读作「和页面同一块颜色」。修法：`[data-dsh-glass] body`
  的多层背景——同色系 wash（light 混白 22% / dark 混 `bg-layer-1` 68%）+ 两枚低 alpha
  柔光斑（brand 12% / success 10%），全部取自已映射 token，四风味自动跟随。CDP 实测
  （Mocha / Latte，mica + frost 20，报告人同款配置）：光斑中心 ΔRGB = 25 / 19，无光斑区
  Δ = 0；亮度旋钮离中时氛围整体塌缩（`--dsh-glass-ambience` 纯 CSS 由亮度变量算出）——
  拉到两端即回到纯白 / 纯黑。**不新增任何 `backdrop-filter`**（低频渐变对 blur 仍近似
  恒等，issue #13 的判定不变）。护栏 = `tests/glass-css.spec.ts`「ground ambience
  (issue #25)」三组，经变异验证（回退即红）。

- **地面默认改为「wash 常驻 + 光斑可选」（issue #26，2026-10-16）**。报告人（`TWFU-wcy`，
  即 #25 的同一位）实测 0.6.3-beta.0 后指出：两枚光斑**固定在屏幕坐标**上，而玻璃面板散布在别处，
  于是每块面板透出的是光斑的不同部位——「三块玻璃读出三种底色」，像三块没对齐的玻璃贴在渐变纸上。
  本机复现（真页 1×1 采样，Mocha，mica + frost 20）：**同一张侧栏卡片自己**上端与下端读出
  ΔRGB **(12,15,21)**，顶栏左段与右段差 (7,10,15)，输入卡 Δ 0；把光斑去掉后跨面板极差降到
  **(4,4,5)**，而 wash 的水平不一致本来就 ≤2/255（165° 渐变的倾斜量级），所以**默认只留 wash**
  既消掉割裂又保住「上浅下深」的层次（报告人选项 A 会把 #25 的诉求一起退回，故选 C）。
  两枚光斑没有删除：玻璃质感里新增 **「地面光斑」开关**（默认**关**，`--dsh-glass-glow`，
  与 blur / frost / brightness 同一套持久化与跨窗口同步），打开即回到 0.6.3-beta.0 的观感——
  实测开/关的侧栏上下极差 **ΔRGB (4,4,5) ↔ (12,15,21)**，与旧版一致。
  实现要点：光斑 alpha 在 `background` 里**内联**乘 `--dsh-glass-glow`（#25 的失效传播陷阱：
  经中间变量不重算），wash 不读这个开关；亮度拉满仍使整场塌缩回纯白 / 纯黑。
  ⚠️ **默认值变更**：0.6.3-beta.0 的「有光斑」不再是默认观感；想要旧观感在
  设置 → Catppuccin → 玻璃质感里打开开关即可。

### 修复

- **适配上游 0.2.1：设置不再「改了不落盘」（2026-10-17）**。DSH **0.2.1-rc.2** 删掉了 settings
  快照里的 `mode` 字段——`fix(web): persist authenticated browser preferences on the Host`
  （PR #4201）把「按页面本地性选存储」整条分支拿掉了，官方 agent note 里明确写「表单快照不携带
  mode」，并**否决**了保留内存模式的替代方案。插件原判据是 `status === 'ready' && mode === 'host'`，
  在 0.2.1 上 `mode` 恒为 `undefined` ⇒ **可用性恒假**：改任何设置都只写进 localStorage，
  `cordis.patch.yml` 永不更新，启动时也不再采纳已保存的 section（单窗口下几乎无感，换窗口 /
  重装 profile / 清浏览器存储才暴露）。修法：`mode` 改可选，语义改成「缺失 = Host」，
  判据 `status === 'ready' && mode !== 'memory'`（显式 `memory` 仍不可用，兼容 ≤ 0.1.6 的
  `settingsScope` 通道）。护栏 = `tests/settings-seam.spec.ts` 的「snapshot shape across DSH
  versions」6 条（缺 `mode` / 显式 `memory` / 显式 `host` / 未就绪三态 / 读取 section 两个方向）。
  真机验收（0.2.1-rc.2 官方桌面壳）：修复前切「地面光斑」开关，DOM 与 localStorage 都变而
  `cordis.patch.yml` 的 mtime/md5 纹丝不动；修复后同一操作文件被改写（`glow: false → true`），
  重启后值仍在；再把文档手改回 `false` 重启，插件跟着回退（「文档胜出」的采纳语义同时验过）。
  审计全量见 `docs/desktop-0.2.1-adaptation-audit.md`。⚠️ **一次性提醒**：0.2.1 测试期内
  改过设置的话，升级后第一次启动会回到 profile 里最后成功保存的值（断链期间只写进了
  localStorage 的那部分会被文档覆盖）。

- **输入框下的状态栏不再「透明成一行」——滚动正文不再穿透（issue #28，2026-10-17）**。
  报告人指出：模型 / 上下文用量那一行（`InputBar` 的 dock）完全没有背景，往上滚历史消息时
  正文直接穿过它、两行字叠在一起。根因不是漏写样式，而是**删得太多**：座席
  （`[class*='composerSeat']`）的 `background: none` 抹掉了上游唯一的背板
  （`linear-gradient(0 → --dsw-alias-bg-base 36px)`），而座席在 active 相位是
  `sticky / absolute` + `z-index: 7`，正压在转录流上；卡本体有玻璃挡得住，**卡外的 dock 行
  （+ 卡下 4px 内边距）全部裸奔**。修法：给 dock 行挂一条**地面色渐变带**——锚 dock 自身
  （`[data-dsh-glass-inputbar] > [class*='dock']::before`，`z-index:-1`、全宽出血到座席边缘、
  向下 4px 盖住根节点的内边距、向上 8px 骑进卡底阴影里），只涂地面色、**不新增任何
  `backdrop-filter`**（填充本身就是上游做法，issue #13 的预算不为它付费）。
  三条边界：① 带子在**卡下方**，卡的磨砂与透字观感完全不变；② dock 为空（hero 视图的
  `:empty`）时带子只剩一条贴地细线，叠在地面上不可见；③ 关闭玻璃时整条规则不生效，仍是上游原样。
  填色取地面渐变自己的末端公式
  `color-mix(ground, #000 5% × ambience)`，避免在页面底部读出一块略亮的矩形。
  护栏 = `tests/glass-css.spec.ts`「composer dock backing (issue #28)」两条，已变异验证
  （把选择器改废即红）。

- **桌面壳的主区不再是一块不透明板 —— 左右色差消失（2026-10-16）**。报告人贴图（新会话页、
  Windows 壳、Mocha + mica）指出「还是有色差」。逐像素实读确认：标题栏 `#181825`、卡片上方地面
  rgb(20,20,32)、侧栏卡片 rgb(21,21,33)，而**主区自上而下恒为 rgb(17,17,27)**。根因不是配色：
  上游 `AppFrame.module.css` 在 `[data-windows-titlebar] .…_centerCol`（以及 `[data-platform=darwin]`
  同一条）把布局的 **center 列**画成 `--dsw-alias-bg-base`，而 Web 壳的同一列**没有背景**——
  所以本地夹具与 CI 的 boot 检查都看不见这块面板。我们早已放开 frame / 侧栏列 / 会话根
  （`[data-phase]`）三处，只漏了它 ⇒ 页面地面（含 #26 wash）能透过一切，**只有转录区是死的
  crust**，于是同一高度左侧读 20–21、右侧读 17，顶部差到 (4,4,6)。修法：
  `[data-dsh-glass-float] [data-dsh-glass-frame] > [class*='centerCol'] { background: transparent }`
  （锚 frame 直接子元素、只 gate mica，不动上游的 16px 内容圆角）。真页 A/B
  （`.debug/ui-adapt/pane-diff.mjs`，属性层次与桌面壳一致）：主区顶 **rgb(17,17,27) → rgb(21,21,32)**
  （= 卡片顶 rgb(21,21,33)，Δ1）、主区底 rgb(16,16,26)，左右极差 **6 → 1**；compat 保持官方面
  （实测 centerCol 仍 rgb(17,17,27)）。护栏 = `tests/glass-css.spec.ts`「center column: the desktop
  shell s last opaque pane」三条，**5 组变异全部验证会红**。

- **原生标题栏（Windows 标题栏条）改吃 mica 侧栏那张面（方案 C，2026-10-16）**。左右极差压到 1
  之后，剩下的就是**接缝本身**：Windows 的标题栏由壳进程按 `--dsw-specific-sidebar-fill` 上色
  （preload 的 `syncWindowsAppearance()` 往 `<body>` 塞一个隐藏 span，经 `getComputedStyle` + 1×1
  canvas 折算 `rgba()` → `setTitleBarOverlay`），而该 token 在 mica 下**已不是侧栏的颜色**
  （侧栏列的填充被放开、改用 52% frost 面）⇒ 标题栏保持 mantle `#181825`，其下的卡片是 `#151521`，
  差 3–4 档。修法：在 `[data-dsh-glass-float] body` 把该 token 覆写成**卡片自身的配方**——
  `--dsw-alias-bg-layer-1` 按 `52% × --dsh-glass-frost` 混进 wash 的 0% 停靠色（= 标题栏正下方
  那块地面），不新增任何颜色。两个必须：① **`!important` 不可省**——主题把整套调色板写在 `<body>`
  的**内联 style** 上，只有 important 声明压得住（实测：不加则 token 恒为 `#181825`）；
  ② `GlassLayer.applySettings()` 把旋钮变量**镜像到 `<body>`**——壳只在 `<body>[style]` / `<head>`
  变化时重读，而它第一次读发生在本插件 `<style>` 落地时（那时模式属性还没写）：镜像既是首次命中的
  前提，也是滑杆拖动传到底层标题栏的通道（卸载时移除，触发退回官方填充）。
  端到端实测（`.debug/ui-adapt/caption-accept.mjs`，完整复刻壳的探针 + 观察者 + 去重）：
  送进 `setTitleBarOverlay` 的序列 **`(22,22,34) → (24,24,37) → (22,22,34) → (23,23,35)`**；
  mica/frost20 标题栏 `rgba(22,22,34,1)` = 卡片顶 (21,21,33)（差 1），页面标题条像素与之相等；
  frost 20→45 标题栏跟着走；**compat 回落到官方 `rgba(24,24,37,1)`**（float 门控实测）。
  ⚠️ 同一 token 另有三处消费者（轨迹表头 / 计划通知条 / 会话列表底部渐隐）随之从 mantle 变成侧栏
  玻璃调，Mocha 实测 Δ(3,3,4) —— 与标题栏自己拿到的档位一致；侧栏列内部仍是 `transparent` 放开。
  **光斑开关（#26）未建模**：开了光斑后卡片顶会上浮，而标题栏仍是 wash 地板色。
  护栏 = `tests/glass-css.spec.ts`「native caption rides the mica sheet」三条 +
  `tests/glass-layer.spec.ts` 的镜像用例，**8 组变异全部验证会红**。

- **「继续执行目标」通知卡补上玻璃座位**（2026-10-16）。报告人贴图指出这一块「似乎没有被配色
  覆盖，也没有玻璃质感」。**不是漏映射**：该卡是上游 `@deepseek-ai/dsh-client-ui-chat` 的
  `TurnTriggerNodeView`（`<section class="…_root" data-turn-trigger>`，钩子是上游自己写的字面量），
  消费 `--dsw-alias-turn-trigger-bg`——而官方 token 表在**暗色三风味**把它定义成
  `--dsw-alias-interactive-bg-hover` = `rgba(255,255,255,.08)`（hover = `…-active` = `.14`），
  **一个中性白叠层**；我们逐字照搬了官方（不是偏离）。截图反解：卡内 rgb(51,51,59) 减地面
  rgb(17,17,27)（= Mocha `--dsw-alias-bg-base` `#11111b`）⇒ alpha ≈ 0.143 = **hover 态**，
  即截图时报告人刚点过展开。修法：补一条 mica 门控座位——填充取侧栏同一张 `--dsh-glass-card`、
  发线 `--dsh-glass-rim-soft`、圆角并到 14px，并**复述 `:hover`**（座位 (0,2,1) 会压过上游
  `.oE-XyW_root:hover` (0,2,0)，不复述则 hover 冻结）；不加 `backdrop-filter`（转录流里的面，
  背后只有低频地面，issue #13）。真 Chromium 实测（Mocha，frost 45）：**rgb(35,35,44) →
  rgb(20,20,31) = `#141420`**，与侧栏 / 产物块同族；Latte 侧填充落回地面色
  （`layer-1 === bg-base`），只剩发线可读——与侧栏在 Latte 的表现一致，属预期而非缺陷。
  护栏 = `tests/glass-css.spec.ts`「official transcript surface: the turn-trigger notice」四条
  （座位形状 / 无 blur 无写死色 / hover 档 / 通用锚点禁令），**4 组变异全部验证会红**；
  前后对照图 `.debug/ui-adapt/out/notice-preview.png`（不入库）。

- **[P0] 产物块座位的选择器锚点 `body[…]` → `html[…]`（0.6.3-beta.1 里那 10 条规则是死代码）**
  （2026-10-16）。上一条产物块座位锚的是 `body[data-dsh-glass-float]`，但
  `GlassLayer.applySettings()` 是用 `document.documentElement.toggleAttribute(...)` 写这三个
  模式属性的（`data-ds-dark-theme` 才是唯一挂在 `<body>` 上的）⇒ **该选择器在真机上永远不匹配**，
  产物块在 0.6.3-beta.1 实际仍是 stock 板。之所以完全没被发现：验收夹具恰好把属性放在 `<body>`
  （`.debug/ui-adapt/artifacts-page.mjs`）⇒「夹具绿、真机死」，而 `glass-css.spec.ts` 里那条断言
  还用 `toContain('body[data-dsh-glass-float]')` 把错误锚点写死。真 Chromium 三变体对照
  （`.debug/ui-adapt/notice-lab.mjs`）：同一条规则，属性在 `<html>` ⇒ 毫无变化，在 `<body>` ⇒ 命中。
  修法：10 条规则全部改锚 `html[data-dsh-glass-float]`（权重仍是 (0,2,1)，靠源序压过上游
  `body[data-ds-dark-theme] .…_card`），那条断言改为正向锁 `html[…]`，并新增一条**通用禁令**：
  样式表（剥注释后）与所有规则选择器里都不得出现 `body[data-dsh-glass-(float|compat)]`。
  变异验证：锚点改回 `body[…]` ⇒ 红。

- **产物块（「已编辑 N 个文件」+ 交付文件卡）改用与侧栏同一张玻璃面**（2026-10-16）。
  报告人指出转录里的产物块「和侧边栏不像一套配色」。它不是第三方 UI，而是官方
  `@deepseek-ai/dsh-client-ui-deliverables`（0.2.0-rc.2，桌面壳 `app.asar` 内同版本）：
  卡身 `--dsw-alias-bg-layer-1`（Mocha #181825）、卡头与交付文件卡 `--changes-fill`
  / `--deliverable-fill` = `--dsw-static-neutral-850`（Mocha #1e1e2e、Latte #e6e9ef）、
  文件行不画底 ⇒ **一层不透明三台阶的板子**，而 mica 侧栏是一张 52% `--dsh-glass-card`
  半透明面——浅色侧最刺眼（卡头比近白地面还深）。修法（用户选定的 B 方案）：卡根 / 卡头 /
  文件行 / 交付文件卡全部落到**侧栏同一个 token**（`--dsh-glass-card`，frost 继续驱动），
  发线换 `--dsh-glass-rim-soft`、圆角并到 14px、列表自带的白 12% 分隔线换成主题发线，
  卡头与行背景清成透明（卡头 60px 几何不变），小图标砖抬到 `--dsh-glass-card-raised` 档；
  仍**不加 `backdrop-filter`**（转录流里的面背后只有低频地面，issue #13）。仅 mica 生效
  （compat 下侧栏是官方面，单改产物块会反过来更不统一）。渲染实测（真 Chromium 2×，
  mica/frost 20）：卡头 / 卡身 / 文件行 / 文件卡 **全部 `#141420`（Latte `#edeff3`）**，
  与侧栏玻璃片 `#151520` / `#eff0f4` 同一张面。
  两个实现陷阱都写进了注释与护栏：① 上游暗色覆盖 `body[data-ds-dark-theme] .…_card`
  （0,2,1）会压过 `[data-dsh-glass-float] [data-changed-files]`（0,2,0），**暗色下只改到边框、
  填充静默回退**——选择器因此要在类型选择器上多一档，即 `html[…]`（**不是** `body[…]`；
  0.6.3-beta.1 原实现锚的 `body[data-dsh-glass-float]` 是死代码，见本版 P0 条目）；② 交付文件卡自己声明
  `background: var(--deliverable-fill)`，**只改变量不够**，填充要写在元素上。
  护栏 = `tests/glass-css.spec.ts`「official artifact rows: the deliverables block」四条
  （含特异性锚点与「填充写在元素上」两条），**8 组变异全部验证会红**。样张与读数见
  `.debug/ui-adapt/out/art-compare-<风味>.png`（不入库）。

- **左上角侧栏卡片描边降到 `--dsh-glass-rim-soft`（issue #26 追办 ②）**（2026-10-16）。
  报告人反馈窗口左上角「过于突兀」：那里是三道台阶叠加——原生标题栏条、被光斑抬亮的地面、
  以及浮空侧栏卡的亮描边弧。光斑一默认关闭（上一条）就只剩描边这一层，故把侧栏卡从 18%
  的基准 rim 降到 soft 档（其余消费面一律不变）。真页实测（Mocha，mica）：卡片上边缘像素
  **rgb(73,78,98) → rgb(51,52,67)**；Latte 侧同向变淡（rgb(195,202,221) → rgb(222,223,230)，
  浅色下 rim 比底暗，数值变大即更淡）。选型前渲染并对比过另外三种方案（完全去描边 /
  贴住标题栏 / 不再浮空），对比图见 `.debug/ui-adapt/out/combo-CB-*.png`。护栏 =
  `glass-css.spec.ts` 的两条 rim 断言（侧栏 soft、顶栏仍基准档），变异验证会红。

- **接线护栏：durable section 的每个字段都必须出现在持久化写操作里**（2026-10-16）。
  实现「地面光斑」开关时踩到仓库反复强调的那类坑——state / layer / 设置行 / Host schema / CSS
  全部接好，唯独 `stateToMutateOps()` 的逐字段列表漏了新字段：**没有任何测试变红**，表现是
  点一下开关、一秒后自己弹回（写操作不带该字段 ⇒ 文档保持 schema 默认 ⇒ 客户端下一次采纳
  把它重置）。修掉之后补了一条**系统性**护栏：`tests/client.spec.ts` 的
  「covers EVERY field of the durable section」从 `defaultSettingsSection()` 自身推导叶子路径，
  与写操作的 path 集合求差——以后新增字段漏接线会直接红，而不是留一个「点了没用」的 UI。
  变异验证：删掉 `glass.glow` 那一行 op ⇒ 该用例红。

- **新会话（hero）顶端不再出现空白玻璃框**（2026-10-16）。上游把会话顶栏分两种状态渲染，
  只有一种是我们该画卡的：`[data-phase]` 的 `<header>` 在「无 session」或「会话还是 blank」时
  带 `…_headerBlank`（上游自己的「无 chrome」信号：`border-bottom:none; min-height:0;
  padding-bottom:0`，非 darwin 下再加 `padding-top:0`），**stock 完全不画**——它的子节点只有
  一个 30px 的 `headerLeading` 槽（内含右上角折叠图标）和一个空 titleRow。我们那条
  `[data-dsh-glass-float] [data-phase] header` 是裸元素选择器，于是把它画成了高 50px、
  带 1px 描边 / 20px 圆角 / `blur(5px)` 的空卡（真页实测 0.2.0-rc.2 + mica：`background:
  color(srgb .094 .094 .145 / .208)`）。修法：卡片配方 + `::after` 装饰 + 侧栏折叠位移规则
  三条一起加 `:not([class*='headerBlank'])` 守卫，blank 顶栏回到与 stock 逐项一致
  （实测四风味：`border 0px` / `radius 0px` / `margin 0px` / 背景透明 / 无 blur，高度 40px），
  而**会话态顶栏仍是玻璃卡**（h=85、1px 描边）——守卫精确，不是关掉整个族。该后缀在两条支持
  线上都存在（2026-10-16 复核 `dsh-client-ui-conversation` 0.1.7-rc.2 与 0.2.0-rc.2）。
  护栏 = `tests/glass-css.spec.ts` 的「keeps the whole top-bar family off BLANK headers」
  等三条，经变异验证（去掉 `:not()` 即红）。

- **第三方「思考」卡片（dsh-better-display）接入玻璃语言**（2026-10-16）。报告人指出思考
  部分看着不适配。根因：那块面板来自第三方插件 `dsh-better-display`（`ReasoningCard`，钩子
  `data-reader-reasoning-card`），其自带材质是全转录里**唯一的不透明板**——
  `background: var(--dsw-alias-bg-module-platform)`（Mocha #313244，真页实测 rgb(49,50,68)）
  + 白 12% 发线（`--dsw-alias-border-l2`）+ 12px 圆角，而本皮肤每一块转录面都是半透明玻璃 +
  主题 rim。修法：新增座位，**只改 alpha / 发线 / 圆角**——填充用**插件自己的 token**
  `color-mix(bg-module-platform × 52% × frost, transparent)`（规则 4：不换色相，四风味自动
  跟随，frost 旋钮继续生效）、边框换 `--dsh-glass-rim-soft`、圆角并到 14px 面档；mica 与
  compat 同一配方，**两模式都不加 `backdrop-filter`**（卡片背后只有低频地面，issue #13 判据）。
  必带守卫 `:not([data-overflow='false'][data-expanded='false'])`：插件在「短且折叠」时自己
  会把卡片降级成无框行内文本，我们不能把它重新画成板子。四风味实测（合成后正文对比度）：
  Mocha 5.65 → 7.89、Latte 5.14 → 5.44、Frappé **4.26 → 6.23**、Macchiato 5.03 → 7.25
  （顺序 = 实色 → 玻璃；Frappé 原实色**低于 AA**，本改动顺带修好）；compat 模式活体验收同值。
  护栏 = `tests/glass-css.spec.ts`「third-party surfaces: dsh-better-display's reasoning
  card」三条，变异验证（换错 token / 加 blur / 去掉状态守卫各自即红）。

- **构建链加固：不可解析的样式表不再静默降级**（2026-10-16）。`scripts/gen-glass-css.mjs`
  原本把「lightningcss 缺失」与「解析失败」合在一个 try/catch 里，于是语法错误会静默回落到
  未压缩原文——而浏览器是第一个真正的解析器，遇到错误会从错误点起丢弃**其后所有规则**。
  这正是本轮踩到的坑：新规则的块注释里嵌了一个 `/* … */` 标记，注释提前闭合，顶栏族在运行时
  整族消失，而 `pnpm build`、typecheck 与既有测试全绿。现在可用性与解析结果分开处理：
  模块缺失仍回落（并告警），**解析失败直接让构建失败**；并加两条护栏
  （`stylesheet integrity`：同一解析器必须解析通过 + 禁止注释内再出现注释标记），变异验证会红。

- **修复 issue #24 —— 切换会话时顶栏 / 对话框的毛玻璃「闪烁」**（2026-10-15）。
  上游按 session 世代 key 重挂载整个会话子树（`main.conversation` = `session-maybe` 槽位，
  `useMaybeIncarnation`），而本皮肤给 `[data-phase='hero'|'active']` 挂了入场动画
  `dsh-glass-in`，新挂载元素自动重播 ⇒ 每次切会话整列（含顶栏卡与输入卡）从 opacity 0
  淡入 300ms。修法：删除两条 phase 根动画（它们由切换驱动，不是入场驱动；其余三条
  入场动画保留）。CDP 实测（web GUI）：修前 `animationstart` 在点击后 39~63ms、随后整列
  空白（帧亮度 18.0 对常态 22.7~25.0）；对照（只注入 `animation: none`）opacity 恒 1.000、
  零动画事件。护栏 = `glass-css.spec.ts`「the conversation roots must never animate」
  断言。根因与取证详见 `docs/issue-24-switch-flicker.md`。

### 其他

- **工具链与兼容声明对齐上游 0.2.1 线**（2026-10-17）。`devDependencies` 里的 11 个
  `@deepseek-ai/dsh-*` 全部由 `0.2.0-rc.2` 升到 `0.2.1-rc.2`（含 issue #27 新引入的
  `dsh-client-ui-primitives`），`pnpm typecheck` / `typecheck:tests` 在**新版类型**下零漂移。
  删掉 `@deepseek-ai/dsh-invariants`——这是**补 0.2.0 的作业**：官方
  `docs/upgrade-guide/v0.2.0-rc.2/remove-runtime-invariants` 的迁移第 3 条就要求从 `package.json`
  移除，当时漏读；0.2.1 不再发布该版本，全仓库也没有任何 import。新增 `engines.dsh`
  声明（`>=0.1.5-rc.1`，与 `dsh.compatibility.dsh` 同口径）：上游
  `docs/upgrade-guide/v0.2.1-alpha.3/plugin-engines-dsh` 说明兼容判定正从 `peerDependencies`
  迁到 `engines.dsh`——有它就只认它、忽略 peer，缺失才回落 peer（我们本来靠回落"永远兼容"，
  但回落迟早会消失）。`dsh.compatibility` 补 `0.2.1-rc.2` 的 `compatible` 与操作记录
  （`install` / `start` 已过，`uninstall` / `rollback` 仍未实测，照旧标 `unknown`）。

## [0.6.2] - 2026-10-13

> 本版 = `0.6.2-beta.0/.1/.2` 一路**转正** + 一批新修复；原计划的 `0.6.2-beta.3`
> **未单独发布**，内容并入本版。五个批次：① 2026-10-10 代码审查（`docs/code-review-2026-10-10.md`）
> 的 P1 修复（R1~R3，三条均有**变异验证**过的回归测试——把修复回退即变红，见
> `tests/reentrancy.spec.ts` 的三个新 describe/用例）= `0.6.2-beta.0`；② 「反馈与支持」行 +
> issue #22 三修（菜单换座 / 侧栏右线 / 选中态去环）+ 分组标题胶囊复活 = `0.6.2-beta.1`；
> ③ issue #23 注册容错（与语言包共存不再炸 boot）+ issue #22 追评（主输入面 rim-strong 档）+
> 反馈行文案点身份修订 = `0.6.2-beta.2`；④ 会话输入区观感调整——拆除融合带（玻璃卡只包输入区、
> 统计行回卡外）+ 主输入面双层影 + 标准预设默认模糊度 2 → 5px = `0.6.2-beta.2`；
> ⑤ issue #22 第三轮 ①②③（选中行色统一 / 一级弹层去实线框 / 供应商胶囊去描边）= 本版新增。
> ⚠️ 真机 e2e **未跑**（本机 Playwright 不可用，属环境限制）；③④⑤ 已在本机 CDP 真页取证
> （四风味 Latte / Frappé / Macchiato / Mocha + 玻璃关 + compat + 报告人同款配置）。

### 新增

- **设置区新增「反馈与支持」行**（2026-10-11）。设置页与插件详情页底部各多一行、两枚 GitHub
  链接——「对 Catppuccin 外观插件有问题或建议？欢迎在 GitHub 提 Issue」与「喜欢这个 Catppuccin
  外观插件？点一个 Star ⭐」（2026-10-12 修订：两句都点名插件身份，7 语言同步），
  分别指向 `NoNameLeGo/dsh-catppuccin-theme` 的 `/issues` 与仓库主页。实现：
  `src/client/LinksRow.tsx`（纯静态链接，无注入面，URL 常量就在该文件里），注册 `order: 23`
  （「检查更新」之后），文案随 7 语言字典；两枚链接都是 `target="_blank"` +
  `rel="noreferrer noopener"`——官方桌面壳实测（`app.asar` 的 `setWindowOpenHandler`）：
  http/https 外链一律交给系统浏览器打开，应用自身不被导航走。
  护栏：`tests/rows.spec.tsx` 的「LinksRow (feedback & support)」两条 + 详情卡组成断言。

### 变更

- **标准预设默认模糊度 `2` → `5`（px）**（2026-10-13）。维护者实机试看后定：2px 在浅色
  风味下读感偏「透」。`DEFAULT_GLASS.blur` 一处改全（「标准」预设、恢复默认、新装同源）；
  `清透`（0）与 `磨砂`（12）两档不动。

### 修复

- **修复 issue #22 第三轮 ①②③ —— 选中行色统一 / 弹层去实线框 / 供应商胶囊去描边**（2026-10-13）。
  报告人追报三条：① 侧栏会话列表选中色深比其它位置深一档、且带一圈灰色柔光（读作「阴影边框」）；
  ② 模型/推理等级一级弹窗有一条实线边框；③ 模型子弹窗的「供应商」分组被描边胶囊包住。修法
  （只动玻璃层、不碰配色语义）：① 选中行改骑上游同款 token `--dsw-alias-interactive-bg-hover`
  （与「插件」等行同值同形），删掉 40% mix 填充与 12% 品牌柔光——选中态与 hover 同一词汇、
  且与玻璃关时的 stock 外观逐字节一致；② mica 与 compat 两处菜单座位的 `outline` 全删
  （上游自带 elevation——0.5px 环 + 双层影——完整呈现）；③ 分组标题胶囊删 1px 描边、保留填充
  与毛玻璃（sticky 防叠字是功能件）。真页复核（CDP 四风味）：① Latte `rgba(38,49,72,.06)`、
  Frappé/Macchiato/Mocha `rgba(255,255,255,.08)`，阴影全 none；② `outline: none`（双路径）；
  ③ 五个分组 `border: 0`、填充与 blur 在。护栏 = `tests/glass-css.spec.ts` 三组断言（选中行
  token / 席位零描边 / 胶囊无 border），回退即变红。
- **修复 issue #22 第三轮 ④「性能与用量下移」—— 会话输入区拆除「融合带」**（2026-10-13）。
  报告人在 `0.6.2-beta.1` 上追报统计行「整体向下位移」。取证（web GUI + CDP）结论：融合带
  （自 issue #19 起把 composer 与统计行包进同一块玻璃）在 0.2.0 上本就半残——slot 发线画在
  0×0 的 `display:contents` 槽位上（CSS 命中、物理上永远画不出），统计行实际按上游 stock
  的贴底布局走，视觉缝合从未真正成立。本版**整体拆除融合带**：玻璃卡只包输入区
  （placeholder + 工具栏；30% rim + 24px 圆角），统计行回到卡外（stock 位置）；hero 与会话
  输入共用同一条卡规则。主输入面同时换上**双层影**（近场 `1px/2px` + 外围 `8px/24px` 晕，
  替掉实测 ≈ 无感的单层 drop）：Latte 下卡底缘影 Δ7 → Δ22（约 3 倍），Mocha 可辨不过重。
  护栏随 `tests/glass-css.spec.ts` 的 issue #22 组同步更新（消费点 / 材质面 / 无分隔线）。
- **修复 issue #22 追评 —— 主输入面的边界在浅色风味下不可见（rim-strong 档）**。报告人追评
  「输入区与地面无边界、状态栏文字洗白」；真页取证（web GUI + CDP，报告人同款 Latte + mica +
  blur 12 + frost 45 + brightness 50）表明 footer 文字色与 stock 逐项一致（不是配色回归），
  根因是主输入面的通用 18% rim 在近白地面上不成立：rim 实测 `rgb(210,212,220)` vs 地面
  `rgb(239,241,245)`，ΔRGB ≤ 31，1x 不可辨。修法：新增 rim 档位 `--dsh-glass-rim-strong`
  （30%，浅/暗同值，暗色不低于浅色），**只**作用于主输入面（hero 输入卡与会话输入卡，
  同一条 `[data-composer-card]` 规则）——其余 rim 消费点（侧栏/顶栏/菜单/弹窗等）一律
  不动。复核（同一 CDP 链路）：Latte 下卡边框实测 30%（渲染像素 `rgb(191,193,203)`，
  ΔRGB ≈ 48）、Mocha 下 30% 可辨不过重、关玻璃后输入区完全回到 stock（零 border）。
  护栏 = `tests/glass-css.spec.ts` 的 issue #22 组（档位定义且暗色不低于浅色、消费点、
  其余 rim 仍走 18%），把改动回退即变红。
- **修复 issue #23 —— 注册冲突不再炸掉整个 boot（与语言包共存）**。与 `dsh-locale-pack`
  等注册同批 BCP 47 ID 的语言包共存时，上游 `locale.addLanguage` 抛
  `locale "ja" is already registered`；`ctx.effect` 同步执行并原样 rethrow → 本 entry
  变 FAILED → 整个 `web boot` 中止 → 官方桌面壳的崩溃救援 `disableAllPlugins()`
  把**全部**第三方插件一起关停。修法：新增 `src/registration-tolerance.ts` 的
  `tolerantRegistration`，boot 关键路径上的全部注册改走容错——语言字典与语言定义 ×11、
  `theme.register`、设置行 slot ×4、插件详情卡 slot、宿主 `webServer.register`；
  已知「他方已占用」形态静默跳过（与生态惯例一致），其余 warn 后同样跳过。
  同一排查顺带修掉三处：`settings.configure` 丢弃 disposer（宿主 fiber 重启后子 fiber
  必抛「presentation already configured」）、更新检查路由的 `void` 调用无 catch、
  行 `select()` 的两处 `setTheme` 未包。护栏：`tests/registration-tolerance.spec.ts`
  5 例，把容错回退即全红（变异验证过）；全量排查（A/B/C 三档）与上游报错文案速查见
  `docs/issue-23-registration-tolerance.md`。
- **更新检查的客户端 fetch 补 15 秒超时（审查 R3）**。宿主进程假死时，「检查更新」的
  同行 fetch 会无限悬挂、按钮卡在 `检查中…` 的禁用态且点不动（此前只有宿主侧 8 秒超时兜底，
  挡不住宿主本身不响应）。手动检查与 3 秒启动自动检查两处都改用
  `AbortSignal.timeout(UPDATE_CHECK_CLIENT_TIMEOUT_MS)`（15s，比宿主预算宽，不会裁掉
  慢但活着的 registry 查询）；中止落进既有 catch，归 `network.local`。
- **卸载不再无条件还原 `theme.setTheme`（审查 R1）**。包装恢复前先校验「这个方法还是我们的
  包装」；若已被第三方扩展替换，保留对方的包装并输出一条警告，不再把别人的拦截链无声摘掉。
- **boot 窗口内的设置改动不再被首个文档快照回滚（审查 R2）**。settings 服务迟到（或首个
  快照还在路上）时，用户改动没有推送通道；服务一到，水合逻辑按「文档优先」把它静默回滚。
  现在 `queuePersist` 在 scope 尚不可用时打 `pendingLocalPush` 标记，首个可用快照到来时
  改为把本地状态推上去（与文档相等时自然退化为 noop，普通启动路径零成本）。
- **修复 issue #22：模型弹层「双层边框 + 末项贴底」**（2026-10-11）。根因是 **0.2.0 上游翻转了
  模型弹层的 ARIA role**（`dsh-client-ui-model-selection/lib/client.js` 的
  `pane === "model" ? "group" : "menu"`）：外层 MenuSurface 变成 `role=group`，而**内层滚动
  列表 `.groups` 反而拿了 `role=menu`**（0.1.7 线没有这翻转）。玻璃配方挂在 `[role='menu']` 上，
  于是 1px 边框 + 14px 圆角画进了卡片内部；`.groups` 无下内边距 ⇒ 末项胶囊贴着内框底。
  修法：菜单座位改挂 MenuSurface 自带的稳定钩子 `[data-menu-material='translucent']`
  （0.1.7-rc.2 / 0.2.0-rc.2 皆有），且**不再在表面上画填充/blur**——改为覆写自带材质面
  （`z-index:-1` 的 `.material`）读的两个 token：`--dsw-menu-surface-fill`（→ 我们的
  raised 填充）与 `--dsw-menu-backdrop-filter`（→ 我们的 blur 旋钮；stock 为 blur(40px)
  saturate(150%)），保持 issue #19 的 backdrop-root 卫生；rim 改用 outline（画在负 z 子元素
  之上、不改盒模型）。手工菜单（如 `dsh-client-ui-schedule` 的 TaskMenu）留在
  `[role='menu']:not([data-menu-material]):not([data-menu-material] *)` 兜底臂上。
  真页实测（reporter 同款配置：Latte + mica + blur 12 + frost 45，1440×900@2x）：
  表面 `backdrop-filter: none`、outline = rim-soft、材质面 `blur(12px)` + layer-2@70%、
  内层列表 `border: none 0px` + 透明 + 圆角 0。
- **修复 issue #22：侧栏右侧的「半截残缺框」**（2026-10-11）。`[class*='sidebarCol']` 曾单独
  覆盖 `border-right-color` 为品牌蓝 40%（注释里的 "luminous right edge"）：Latte 下其余三边
  的 18% 墨线实测 (210,212,220) ≈ 不可见，右边却是 (155,186,245)，且圆角处两邻边混色让蓝线
  在右上/右下拐弯 ⇒ 读作画了一半的方框。修法：删掉该覆盖（连带暗色 22% 那条），四边统一回
  `--dsh-glass-rim`。真页实测四边色值完全一致（label-primary @18%）。
- **修复 issue #22：选中/高亮态统一为「无描边」**（2026-10-11）。删除会话行的 1px 内环
  （保留 40% 填充与 12% 柔光；填充档位 40% vs hover 6% 仍可辨）与按钮/菜单项 hover 的 1px
  内环（保留柔光），对齐报告人给出的参照物（侧栏「插件」的纯色胶囊）。真页实测选中行
  box-shadow 无 inset。
- **顺带修复：模型分组标题胶囊在 0.2.0 失效**（2026-10-11）。0.2.0 给每个 MenuGroup 的
  section 前置了一个 1×1 隐形哨兵 `span[data-menu-group-start]`（`opacity:0`），旧的
  `> :first-child` 命中哨兵，标题一直渲染成纯文本；改挂 `[data-menu-group-heading]`。
  真页实测标题 `display: inline-flex` + `border-radius: 999px`。
- 护栏：`tests/glass-css.spec.ts` 新增「menu seat + un-stroked highlights (issue #22)」一组
  5 条（双模式席位 + `[role='menu']` 守卫对 + 侧栏统一描边 + 无 inset 环 + 胶囊钩子），
  19 用例全绿；全量 281 用例全绿。⚠️ 真机 e2e 仅在 web profile 上以 CDP 跑通（桌面壳未重启）。

## [0.6.1] - 2026-10-08

> 本版 = 预发布 `0.6.1-beta.0`（玻璃模式下选中会话边框重设计）**转正** + 一项新修复（issue #21）。
> 两条都在下面列出；`beta` 渠道里 `0.6.1-beta.0` 是本版内容的真子集。
> ⚠️ 真机 e2e **未跑**（本机 Playwright 不可用，属环境限制）；issue #21 的修复另用 CDP 在真页上做了修前/修后对比取证。

### 修复

- **修复 issue #21：云母模式下插件页顶部的「添加插件」工具条被挤到卡片上边缘**（2026-10-08）。
  根因是 `glass.module.css` 里三处**裸 `header` 元素选择器**——会话顶栏的玻璃卡片配方原本写作
  `[data-dsh-glass-float] header`，而应用里一共只有两个 `<header>`：会话顶栏（`wSkVaW_header`，挂在
  `[data-phase='hero'|'active'|'plain']` 内）与**页面头**（`X_2TxG_pageHead`，来自
  `dsh-client-ui-plugin-manager`，`dsh-client-ui-schedule` 的页面壳同理）。页面头是**布局元素**不是卡片，
  上游只声明 `padding-top: calc(28px + var(--dsh-frame-top-clearance, 0px))`、无边框无底色，也被这套配方
  打中：`padding` 被换成 `10px 16px 8px`、外加 12px 外边距与 1px 描边。
  真机实测（mocha + mica，1440×900@2x）：卡片 y 12→84，工具条 y 23→55 ⇒ **上距 11px、下距 29px**。
  注意上下不对称是上游自身的几何（标题块 52px 高于 32px 的工具条，`align-items: flex-start` 必然在其下方留
  20px），玻璃加的是**可见的描边**，把这段留白变成了卡片内的空隙——运行时摘掉 `data-dsh-glass*` 复测即为
  上游原样（y 0、无描边、`padding-top 28px`、按钮与标题齐平）。
  修法：三处选择器收窄为 `[data-phase] header`（会话顶栏几何逐像素不变）。顺带修掉同源的两个连带问题——
  侧栏收起时页面头被推 `margin-left: 28px`，以及页面头丢失 `--dsh-frame-top-clearance`
  （Windows 标题栏 40px / macOS 全屏 48px）的让位。护栏见 `tests/glass-css.spec.ts` 的
  「the top-bar card selector stays off the page head (issue #21)」两条。
  用户可见变化：**插件页（以及任何使用同款页面头的页面）在玻璃模式下恢复上游版式**；会话顶栏不受影响。

### 变更

- **重设计玻璃模式下选中会话的边框**（2026-10-07）。旧样式是 `inset 2px 0 0` 左侧竖条 +
  16px 品牌色外发光：accent token 在四个风味里都是贴近地面的暗色（Mocha = `#313244`），竖条贴着行圆角
  读作一截「豁口括号」，发光又把轮廓晕开。换成与按钮悬停同一套语汇（内环 + 柔光）加强版：1px 内环用
  风味蓝、沿行自身圆角形成一整圈干净的圆角矩形边框，柔光退到环后。环透明度定在 **24%**（初版 38% 太深：
  品牌蓝是浓墨色，Latte `#1e66f5` 在浅填充上读作一条硬深色描线）、柔光 12%。40% 选中填充不动
  （12px 时间戳对比度 4.62 已达 AA，是实测上限）；纯 alpha/rim/shadow 改动，玻璃关闭时零影响。
  改动集中在 `glass.module.css`「Sidebar rows」一条。

## [0.6.0] - 2026-10-04

> 与 **`0.5.10-beta.1` 零代码差异**（功能代码一行未动；本版新增的是版本号、CHANGELOG 落节、用户文档与预览资产）：
> 功能分两批走完 `beta` 渠道——**`0.5.10-beta.0`**（插件卡片图标 + 「检查更新」按宿主分流）与
> **`0.5.10-beta.1`**（插件详情页的设置区，`plugins.bundle.config` 插槽），本版转正进 `latest`。
> 另含 README 四处修缮与四风味预览图「关玻璃」重拍（见「文档」节第一条：那条同时修掉了一个
> **资产错误**——旧的四张风味预览其实是在云母模式下拍的）。
> ⚠️ 这两批的**真机 e2e 均未跑**（本机 Playwright 不可用，属环境限制；详情页设置区可由维护者在官方壳内自测）。

### 新增

- **插件自己的详情页也有设置区了**（2026-10-04）。此前点开 Plugins 页里我们那张卡片，中间是空的——只有标题、
  描述和「包含的组件」。现在那块会列出**与「设置 → 通用」相同的三行**：Catppuccin 主题（含代码高亮风格与 token 覆盖）、
  玻璃质感、检查更新。数据层零改动，两个入口共用同一份持久化 section。
  - 机制（在 `0.2.0-rc.2` 上取证，全文见 `AGENTS.md`「插件详情页的设置区」）：那块区域**不是自动表单，是插槽**
    `plugins.bundle.config`，**谁注册谁显示**；渲染点是 `PackageDetail` 的
    `renderSlot("plugins.bundle.config", { view: "page" }, { entryKey: pkg.name })`，**key = bundle 的 npm 包名**
    （本插件 = `@nonamelego/dsh-catppuccin`），与我们 `configure({ auto: false })` 抑制的那个 schema 表单无关。
  - 注册走上游自己的两个守卫：`configForms.whileServed([ns], …)`（命名空间不再被服务时**撤掉**区块，而不是留空块）
    与 `slots.inject`（等插槽被**声明**，未声明就永不触发、不抛错）⇒ 没有 Plugin manager 的宿主、以及旧
    `settingsScope` 线上的宿主都天然静默。
  - 参照实现：本机 `dsh-context` 0.60.0（同一个插槽，key = 自己的包名）与壳内官方 `ui-settings-agent-loop`（改走
    `plugins.item`）；两者都包在 `whileServed` 里。
  - 护栏新增：`tests/reentrancy.spec.ts` 的「Plugins-page card」一组 5 条（key = `PACKAGE_NAME`、`served: false` 时撤回、
    宿主无 `whileServed` 时不注册且不抛错、旧 seam 上不注册、key 必须等于 manifest 的 `name`），
    `tests/rows.spec.tsx` 2 条组成断言（三条行都在、且保留 schema 表单渲染不出的控件：风味色板按钮、三档预设、检查更新按钮）。
    三条变异实测会红（key 换成条目 id / 去掉 `whileServed` 门禁 / 卡片里删掉更新行）。用例数 260 → 267。

- **插件卡片有了自己的图标**（2026-10-02）。此前 Plugins 页我们那张卡片画的是默认图案，而 `dsh-context` 等插件
  已有专属图标——差异的原因是**我们没在 `package.json` 里声明 `icon`**，不是上游不支持。
  - 机制（在 `0.2.0-rc.2` 上取证）：Host 的 `@deepseek-ai/dsh-app-boot` 读包元数据，把 `icon` 指向的
    **相对路径**文件内联成 `data:` URI 交给客户端（`dsh-client-ui-plugin-manager` 消费 `pkg.meta.icon`）。
    准入规则：仅限相对路径、扩展名限 `.svg` / `.png` / `.jpg` / `.jpeg` / `.webp`、原始字节 **≤ 256 KiB**、
    且必须留在 manifest 目录内；任一条不满足直接 throw（不是降级渲染）。
  - 本次先按**圆形**试：`icon: "icon.png"` 指向 README 首图那张 Catppuccin 官方圆标
    （`1544x1544_circle.png`，**103.8 KiB**，在 256 KiB 之内），原图直接用、未做二次处理。
  - 一条已知的观感权衡：卡片容器是「48×48 圆角方 + `.5px` 描边」，但内部图片只有 **36×36 且 `object-fit:contain`**
    ⇒ 透明四角的圆图读起来是「描边方框里悬着一枚圆」（距框边 6px）。想要 `dsh-context` 那种「实色方块」读感，
    得让资源**本身**是满幅方形。四种候选的牌面复刻见 `.debug/icon-preview/gen.mjs`（本地脚本，不入库）。
  - 护栏新增 `tests/plugin-icon.spec.ts`，镜像 Host 的五条准入规则（相对路径 / 扩展名白名单 / ≤256 KiB /
    `files` 收录 / PNG 魔数）；「从 `files` 移除」与「扩展名改 `.bmp`」两条变异实测会红。用例数 245 → 250。

### 修复

- **「检查更新」在官方桌面版里给出的命令无效 —— 改为按宿主分流**（2026-10-03）。此前无论跑在哪个壳里，
  这一行都照发 `dsh plugin --profile <profile> add …`，但**官方 Electron 壳**（DeepSeek Harness 客户端）
  的用户没有可达的终端入口，那条命令复制出来无处可跑。
  - **判别方法（新增 `classifyShell()`，`src/profile-detect.ts`）**：**先判两条社区信号**——社区启动器的
    `desktopProfiles` 服务（Stable / Beta 通道）与 host env 里的 `DSH_DESKTOP_NODE_EXECUTABLE`
    （Next 通道）——**剩下的 Electron 运行时就判为官方壳**；两条都不中且非 Electron 才是纯 node 的 `web`。
    顺序本身就是判据：社区信号先判，否则跑新版 Electron 的社区壳会被官方分支吃掉。
  - 取证（2026-10-03，`resources/app.asar` 直接 grep）：官方壳 host 子进程的 env 由
    `desktopNodeEnvironment(this.node, void 0, this.environment)` 生成，走 `bin === undefined` 分支 ⇒
    只有 `{...壳 env, ELECTRON_RUN_AS_NODE: '1'}`，**不设**那个 marker；`desktopProfiles` 在官方
    0.2.0-rc.2 出厂包集合里 **0 命中**。社区侧：`dsh-desktop-next/src/host/index.ts` 给 host 设 marker，
    `dsh-plugin-desktop/src/profile-service.ts` 注册 `desktopProfiles`。
  - **文案分流**：`web` / `community-desktop` 仍给 CLI 命令（`updateCommand`）；
    `official-desktop` 改给 `包名@渠道`（新字段 `updateSpec`，由 `pluginSpecFor()` 生成）+
    「在**插件界面**里先删除、再重新安装」的指引（= README「桌面版」那条官方升级路径），
    复制按钮相应改名为「复制包名」。payload 新增 `shell` 字段供界面判断。
  - 顺带纠正一处**错误叙述**：`tests/e2e/update-check.e2e.spec.ts` 曾把
    `DSH_DESKTOP_NODE_EXECUTABLE` 说成「官方壳的信号」（2026-09-22 的假设），它其实是**社区壳**的信号
    —— 已按 2026-09-24 的取证改名，并补上三种壳各自的真路由断言。
  - 用例 250 → **260**（`profile-detect` +6 / e2e +1 / 客户端渲染 +3）。三条支路都做过变异验证
    （删 `desktopProfiles` 分支 → 2 条红；Electron 分支恒返回 `web` → 3 条红；客户端忽略
    `official-desktop` → 1 条红）。另记一条 e2e 坑：三条壳断言共用一个 cache bucket，mock 时钟必须
    **递增**推进（30 / 60 / 90 分钟），推同样的量会落在上一条自己 stamp 的未来时间点上、静默复用它的
    裁决 ⇒ 即使把分支删掉断言也绿。

### 文档

- **README 修缮 + 四风味预览图重拍为「关玻璃」**（2026-10-04）。维护者一次点了四处，中英两版同步：
  - **目录改横向**：由竖排 `- [x](#x)` 列表改成居中内联导航（`<p align="center">` + `·` 分隔）。顺带修掉
    三个**坏锚点**：`#常见问题` → `#-常见问题`、`#致谢` → `#-致谢`、`#dsh-tui-终端版主题` → `#dsh-tui终端版主题`
    （GitHub 的 slugger 会把全角括号删掉且**不留连字符**，旧链接点了不跳）。
  - **文首第二张大图默认折叠**：`glass-combined.png`（2 风味玻璃斜切图）包进 `<details>`，
    `combined.png`（4 风味）保持展开。
  - **补 dsh-TUI 链接**：`https://github.com/ccch1mneyyy/dsh-TUI` 加到简介、特性行与
    「安装 · dsh-TUI」小节（并写明需先自行装好 dsh-TUI）。
  - **四风味预览图重拍为关玻璃——这是资产错误，不是观感**：`scripts/screenshot-previews.cjs`
    从头到尾**没碰过玻璃开关**，四张图继承了运行机器的玻璃状态（本机常开）⇒ 四张「风味预览」其实全是
    云母模式，与 `glass-*.png` 重复。判据：旧图侧栏是**内缩圆角卡片**且会话标题被截断成 `…`；关玻璃后
    侧栏贴边、标题完整。在 `dsh web` 真页上按 1440×900@2x 重拍四张并重建 `combined.png`
    （校验值 bodyBg：latte `#eff1f5` / frappe `#232634` / macchiato `#181926` / mocha `#11111b`，
    且 `[data-dsh-glass-surface]` 计数 0、侧栏 `border-radius: 0px`）。
    顺带修掉根因：脚本新增 `setGlass(page, false)`（复用 `screenshot-glass.cjs` 的 `总开关` 写法）+
    拍前 `glassOn()` 断言 + 收工还原用户原玻璃状态。⚠️ 这段 patch 在本机**无法执行验证**
    （Playwright 起不来；重拍实际是走 CDP 完成的），重拍链路已固化为技能 `dsh-preview-shots-cdp`。

- **补一条「刚发版后装到的是上一个版本」的排查指南**（2026-10-03）。现象：发 `0.5.10-beta.0` 当天
  在官方壳插件界面升级，界面显示 `0.5.10-beta.0`，实际装上的却是 `0.5.9-beta.1`（因此卡片没有图标——
  旧版本没有 `icon` 字段），容易误判成「没发出去」或「图标没生效」。
  根因 = **pnpm 11 内置的最小发布年龄**：`dist/pnpm.mjs` 的配置 schema 里写着
  `"minimum-release-age": 24 * 60`（**默认 24 小时**，`pnpm config get` 查不到，因为它来自默认值），
  `pnpm add <pkg>@beta` 会把窗口内的新版本**静默过滤**、解析到上一个符合窗口的版本。
  实测三条出路：① 指名精确版本（`@0.5.10-beta.0`）——pnpm 会把该版本自动写进 profile 的
  `minimumReleaseAgeExclude`；② 在该 profile 的 `pnpm-workspace.yaml` 里给本包整包豁免
  （本次已给 `~/.dsh/profiles/desktop` 加上，之后每个 beta 都能立刻装）；③ 等发布满 24 小时。
  `README.md` / `README.en.md` 的 FAQ 各加一条（含自查方法），`AGENTS.md` 的「4. 发布后」记下诊断口诀
  （先看 lockfile 的 `specifier:` 与已装包版本，再对 `pnpm view <pkg>@<tag>`）。
  顺带把 CHANGELOG 的 `[Unreleased]` 比较基线指到新 tag（SOP 的发布后步骤）。

- **README 精简：把内部取证与开发向内容搬出用户文档**（2026-10-02，`README.md` 469 → 394 行、
  `README.en.md` 500 → 429 行）。搬走的只有维护者才需要的东西，**用户须知一字未动**：
  - 新建 **`docs/glass-mis-hits.md`**：兼容模式误命中的成因、只读取证探针脚本、临时止血的
    `!important` 方案、反馈口径，以及 #16 / #17 / #19 三次收窄的历史表。README 的对应小节
    压成「命中族表格 + 三步索引」（60 → 17 行），小节标题改为「兼容模式误命中了别的面？」。
  - `## 开发` 与 `### 本地链接调试` 的命令清单、生成器（`generate-palettes.mjs` / `changelog:gen`）、
    typedoc、本地 `link:` 调试步骤并入 **`CONTRIBUTING.md`** 新增的「常用命令」「本地链接调试」两节；
    README 只留 5 条命令 + 两个指针（49 → 14 行）。
  - 取舍说明：`package.json.files` 只含 `lib / themes / cordis.patch.yml / README.md / LICENSE`，
    所以 `docs/` 与 `CONTRIBUTING.md` **不进 npm 包**——搬走的必须是开发者/取证类内容，
    用户须知不能挪出 README。中英两版逐节对齐。

- **重写「桌面版」段：官方桌面壳与社区桌面壳的安装/升级是两条互不通用的路径**（2026-10-02）。
  原段落写的是「把 `web` 换成 `desktop` 即可」，那是官方壳还没发布时读 monorepo 源码得出的结论，**已作废**：
  - **官方壳（DeepSeek Harness 客户端）**：安装 = 应用内**插件界面**填包名 `@nonamelego/dsh-catppuccin`；
    升级 = 在界面里**先删除、再重新填一遍包名安装**（v0.2.0 没有升级入口、也没有版本选择器，上游 UI 原话
    「插件安装后暂不支持自动更新：升级需先卸载再安装新版」）。
  - **社区壳（[DSH Desktop](https://github.com/anywhere-labs/dsh-desktop)，仓库已从 `deepseek-harness-desktop` 改名）**：
    安装/升级都走命令 —— 应用内 **Open DSH Terminal** 里 `dsh plugin --profile desktop add|update @nonamelego/dsh-catppuccin`。
  - 补充一条避免踩坑的事实：**系统 PATH 上的普通 `dsh` 两个壳都管不了 `desktop`**，会直接报
    `error: profile "desktop" is managed exclusively by the Electron application`
    （`@deepseek-ai/dsh/lib/bin.js` 的 `rejectElectronProfile()`，只有桌面壳自己的 CLI 入口才传
    `manageDesktopProfile: true`）；想用 CLI 就用 `web` / `headless` / `dsh-tui` 等其他 profile 名。
  `README.md` / `README.en.md` 的安装段（两壳对照表）与 FAQ「怎么升级」都已改写；`AGENTS.md` 的
  「官方桌面壳的插件相关契约」节记下了完整判定链与取证方法。顺带把仓库里 5 处指向社区壳旧仓库名的链接
  改到 `anywhere-labs/dsh-desktop`。

## [0.5.9] - 2026-10-02

> 与 **`0.5.9-beta.1` 零代码差异**（只改了版本号与本 CHANGELOG 落节）：预发布阶段走了 `beta` 渠道，
> 本版转正进 `latest`。三批内容——前两批（2026-09-30 官方桌面壳 0.2.0 线适配 + 2026-10-01 玻璃模式切换
> 两条修复）随 **`0.5.9-beta.0`**，第三批（2026-10-01 命令面板毛玻璃修复，issue #19）随 **`0.5.9-beta.1`**：
> 补齐 18 个漏映射 token 并退役一条已被上游修掉的浅色偏离、兼容声明跟进 0.2.0、Windows 标题栏顶部渐隐、
> 「设置里切云母/兼容会闪一下」与「切得快时第二次被回滚」两条修复，以及命令面板恢复毛玻璃。
> ⚠️ 命令面板那条的**真机 e2e 仍未跑**（离线整页 A/B 已给出实测数字，见该条与
> `docs/issue-19-palette-blur.md` §10 列的三条待补）。

### 修复

- **命令面板（敲 `/` 弹出的候选菜单）恢复毛玻璃**（2026-10-01 报告，issue #19）。面板 `[data-trigger-menu]`
  挂在 `[data-composer-card]` 的 `conversation.input.overlay` 锚点里，而它整块**悬在卡片盒子之外**
  （`bottom: calc(100% + 4px)`，只盖转录）。本皮肤给 composer 卡（云母）或 `[data-dsh-glass-inputbar]`
  （分栏态）加了 `backdrop-filter` ⇒ 那个祖先成为面板的 **backdrop root**，面板自带的上游
  `--dsw-menu-backdrop-filter: blur(40px) saturate(150%)` 只能读到祖先自己画的那层、而面板区域在卡盒之外
  **什么都没画** ⇒ 读空 = 恒等，于是剩下 58%/45% 的透明填充，底下转录原样透出。
  改法照抄上游 `MenuSurface` 自己的做法（其注释原话就是「keeps nested menus free of an ancestor backdrop root」）：
  把材质整体搬到 **`::before` 材质面**（填充 + blur + 内侧高光都搬，容器本体改成零绘制 + `isolation: isolate`），
  云母卡 / 云母分栏态输入栏 / 兼容模式卡三处各一份。实测（真实样式表 + 上游菜单 CSS 的整页 fixture，
  报告人配置 mica + blur 2 + frost 20 + Latte）：面板区条纹 stdev **31.58 → 0.00**（分栏态 33.03 → 0.54），
  同页裸转录对照恒为 **76.32**，把面板自身的 blur 关掉则回弹 **32.06**（证明是模糊在画，不是不透明填充）；
  面板的祖先链 computed `backdrop-filter` 全部为 `none`。顺带把 `[data-trigger-menu]` 纳入 14px 浮层圆角族
  （它没有 `role`，此前落在家族之外）。护栏：`tests/glass-css.spec.ts` 新增 `backdrop-root hygiene` 一组
  （容器不得自带 blur、材质面必须同时拥有填充），真机脚本新增「面板的每个祖先都不得有 backdrop-filter」。
  全文见 `docs/issue-19-palette-blur.md`。
  （EN: move the composer's material onto a `::before` plane so the trigger palette is not under a backdrop root —
  a filtered ancestor silently turns the palette's own `blur(40px)` into an identity read. Measured 31.58 → 0.00
  stripe stdev inside the palette, with the bare-transcript control unchanged at 76.32.）

- **设置里切换「云母效果 / 兼容模式」不再闪一下**（2026-10-01 报告）：入口动画原本挂在
  `[data-dsh-glass-float]` 上，而模式切换正好会增删这个属性——属性一回来，屏幕上**已经存在**的元素其
  `animation-name` 就从 `none` 变成关键帧，于是整页连同**正开着的设置弹窗**重播一遍入场淡入。实测
  （真实 Chromium + shipped `glass-css.gen.ts`，翻转后 50ms）：弹窗 opacity **0.149**、active 相位
  **0.085**。改法：动画门控换成模式无关的 `[data-dsh-glass]`，兼容模式改用一个**时钟**变量
  `--dsh-glass-entry-scale`（mica `1` / compat `0`）把时长归零——改 `animation-duration` 不会重启动画，
  实测来回切换后两者都停在 **1.000** 且无 running 动画；compat 下新挂载的视图仍不播动画，
  mica 下新挂载的视图照常播（0.252 / running）。代价写进注释：compat 下这五处以零长度配方**顶掉了宿主
  自己的入场动画**（宿主 Modal 的 `.dialog` 自带 0.2s `modalEnter`，其遮罩自身的淡入不受影响）——
  「compat 不动骨架」与「保住宿主入场动画」不可兼得，保守模式取前者。
- **快速连点模式开关不再被回滚**（2026-10-01 报告）：持久化写回把「本轮防抖**开始时**采到的 revision」
  当写入栅栏回传，而自己这笔写若落在同一轮里就会把文档推过那个 revision ⇒ 宿主按栅栏拒写 ⇒ 我们把它
  读成「另一窗口改过文档」并采纳远端状态 ⇒ 用户最新一次切换被静默还原。改为**不回传栅栏**，由通道自己
  解析 `pendingRevision ?? snapshot.revision`（既更新、又认得自己排队中的写）；读侧守卫仍是冲突检测的
  唯一入口，真正的外部改动依旧被丢弃。
- **对齐上游 0.2.0 线：补 18 个漏映射 token，并退役一条已被上游修掉的浅色偏离**（官方桌面壳审计
  2026-09-30，全文见 `docs/desktop-0.2.0-adaptation-audit.md`）。本机官方 DSH Desktop 自带
  `@deepseek-ai/dsh-desktop-runtime@0.2.0-rc.2`（= 上游 HEAD、npm `latest`），token 快照按
  `dsh-v0.2.0-rc.2` 的 `design-platform.css` 重建：static 77 / alias **84 → 101** / specific 11，
  外加非三族的 `--dsw-*` 新桶 `other`（`--dsw-menu-surface-fill`），**每方案总量 172 → 190**，
  覆盖 **190/190**（`scripts/parse-dsh-tokens.cjs` 扩桶 + `pnpm gen:palettes`）。
  - **8 个字面量 token**（6 个 `--dsw-alias-file-diff-*` + `--dsw-alias-menu-group-header-fill` +
    `--dsw-menu-surface-fill`）是「只覆盖静态阶梯、别名自动跟随」机制唯一够不到的形态 ⇒ 新增
    `aliasLiteralOverrides` / `otherOverrides`：文件对比的底色与行号槽复用 0.1.7 起就有的
    `green-500-a08/a12`、`red-600-a08`/`red-400-a12` 洗色（行号槽半强度，复刻上游「槽比行弱、
    浅色更浅浅、深色更深」的关系），标记条用整色 accent，菜单分组标题与菜单材质都指回
    `bg-layer-3`（94% / 58%·45%，后者是上游 0.2.0 的新 alpha）。
  - **`--dsw-specific-menu` 跟随上游改为 `var(--dsw-menu-surface-fill)`**：材质由我们自己的基础 token
    提供，两个名字解析到同一个可见面（测试辅助 `resolveSurface` 同步支持一层 var 间接）。
  - **Latte 文档预览配对**：0.2.0 把浅色端翻成「近白面 + 中深字」（官方 4.84:1）。旧补丁（把 label 钉到
    bluish-00）在新配对下会变成近白字压浅面（1.05:1），必须退役；但直接跟随官方 label 档也不行——我们的
    浅色阶梯把官方 bluish-100 映射到 surface1（188,192,204，比官方 rgb(235,238,242) 深 47 级），配对只剩
    3.44:1。按规则 3 **换档不换色**：把**面**钉到官方亮度最接近的 bluish-50（Latte mantle），label 保持
    官方 bluish-700，实测 **5.14:1**。
- **Windows 桌面壳顶部渐隐**（官方壳 2026-09-17 新增的 `data-windows-titlebar` 几何）：preload 给 `<html>`
  挂标记并设 `--dsh-windows-titlebar-height: 40px`，ui-layout 因此在所有列上方预留该条；那条里没有滚动
  内容，13px 顶部渐隐的模糊是恒等读取（issue #13 的形态），而壳用**同一个** `--dsw-specific-sidebar-fill`
  画保留条与原生标题栏 ⇒ 渐隐只会在标题栏上留一道缝。现为
  `[data-dsh-glass][data-windows-titlebar] [data-dsh-glass-fade='top'] { display: none }`，底部渐隐不动。

### 其他

- 测试基建（2026-10-02）：`vitest.config.ts` 显式设 `hookTimeout: 60_000`。默认 10s 在本机满载时不够用——
  `tests/tui-themes.spec.ts` 的 `afterAll` 清理临时目录超时会让**整轮 `pnpm test` 退出码非零**（该文件单独跑
  2.9s 通过、紧接着复跑整轮 7.97s 全绿，属清理慢而非用例失败），放宽后不再把这种情况记成失败。
- 测试（2026-10-01 两条修复的护栏，**均做过变异验证**）：`tests/glass-css.spec.ts` 新增一条——五条入口
  动画不得再挂 `data-dsh-glass-float`、compat 必须把时钟归零、reduced-motion 必须落在同一门控上（把任一
  条改回 float 即红）；`tests/client.spec.ts` 新增两条，`fencedScopeDouble` 按 0.1.7 `ConfigFormController`
  的真实语义搭台（`expectedRevision ?? pendingRevision ?? snapshot.revision` + 宿主等值拒写 + 接受后回折
  mirror），分别锁「自己的回显不得触发回滚」与「真正的外部改动仍被丢弃」（把栅栏改回回传即红：
  `expected 'stale' to be 'written'`）。`scripts/e2e-boot-check.cjs` 新增真页面断言「切回云母不重播入口
  动画」——**在翻转后 80ms 采样** running 动画（重播只有 0.24~0.32s，旧写法的 800ms 等待会让它假绿），
  并打印采样到的门控元素数以防空断。真机 e2e **21/21**（把 dialog 那条动画改回 float 后为 **20/21**，
  失败详情 `div:dsh-glass-dialog-in@73ms`），单测 **243/243**，`pnpm build` / 两个 typecheck 正常。
- **兼容声明与类型面跟进 0.2.0**：`dsh.compatibility` 增补 `0.2.0-rc.2`（`install`/`start` = passed）
  与 `desktop` profile；11 个 `@deepseek-ai/dsh-*` devDependencies 从 `0.1.7-rc.1` 对齐到 `0.2.0-rc.2`
  （`pnpm typecheck` / `pnpm typecheck:tests` 零漂移）。商店窗口按 `.debug/dsh-store/verify-manifest.mjs`
  复算：`{0.1.7-rc.2, 0.2.0-rc.1, 0.2.0-rc.2}` 内现在命中 `compatible`。
- 测试：`tests/palettes.spec.ts` 新增一节（18 个新 token 全覆盖、四风味同 token 集合、字面量 token 必须
  解析成 palette 色、文件 diff 与 code diff 同洗色且行号槽更弱、菜单分组标题与菜单同材质）+ 一条
  **Windows 标题栏探针护栏**（`--dsw-specific-sidebar-fill` 与 `--dsw-alias-label-primary` 必须解析成
  不透明 hex 且 ≥4.5:1——壳会把这两个值经 1×1 canvas 折算后交给 `setTitleBarOverlay`，解析不出来就是
  原生标题栏变透明）；`tests/glass-css.spec.ts` 新增一条锁定「顶部渐隐只在 Windows 标记下消失，通用与
  底部规则不动」；`scripts/e2e-boot-check.cjs` 新增一条真浏览器断言，让**浏览器**去解析
  `--dsw-specific-menu → var(--dsw-menu-surface-fill)` 这条两层引用（解析失败会退成 `transparent`，
  菜单与浮层会集体丢材质），并在详情里打印实际值：0.2.0 上是 `color(srgb 0.192157 0.196078 0.266667 / 0.45)`
  （= Mocha `bg-layer-3` @ 上游新 alpha 0.45），0.1.5-rc.1 上是 `rgb(49, 50, 68)`（该宿主没有
  `--dsw-menu-backdrop-filter`，走的是 `menuSurfaceFor(false)` 的不透明回退）。单测 **240/240**，
  `pnpm build` 正常。
- **真机取证**（未入库资产在 `.debug/desktop-audit/`）：启动级 e2e 指向桌面自带 0.2.0-rc.2 运行时
  **20/20**（含上面那条菜单材质断言）；真机桌面窗口像素 `y≥32` 恰为 `#181825`（= 我们的
  `--dsw-specific-sidebar-fill`），说明壳的标题栏探针拿到的就是我们的颜色；同时确认 `configForms` seam、
  `process.versions.electron` 判据、固定端口 19387 在 0.2.0 上都没变。旧宿主回归按 **CI 的口径**
  （`npm i --prefix <tmp> @deepseek-ai/dsh@0.1.5-rc.1 --before=2026-09-21`，不动全局树）复跑也 **19/19**。
  ⚠️ 本机**全局** `dsh`（0.1.5-rc.2）当前自己起不来（干净 `DSH_HOME`、不装插件也报
  `@deepseek-ai/dsh-sandbox-local` 解析失败），与本次改动无关，已记进审计文档。
- **文档：补一节「环境限制：玻璃需要宿主提供可透出的底色」**（2026-10-02，issue #18 报告人自行排查到根因）。
  `README.md` / `README.en.md` 的玻璃拟文章节各加一个小节：玻璃层的 `backdrop-filter` 读的是**背后真被画出来的像素**，
  本插件只加材质、不给宿主造透明底；宿主若把窗口与自绘容器刷成不透明色，玻璃只能退化为**半透明叠色**（无悬浮层次）。
  已知触发面 = 第三方 `dsh-plugin-desktop` `2.0.17`：Windows 上**静默把窗口材质强制为 `off`**（设置里的 Mica/纯色选项
  选了不生效），同时把侧栏表面与自绘容器刷成不透明面板色（`--dsh-desktop-frame-fill` / `.dshDesktopSidebarSurface`
  取 `--dsw-alias-bg-layer-1`）。文档同时写明**本插件不为此加 `!important` 覆写**（那等于让插件接管宿主容器结构，
  宿主一改就碎，且偏离「只改材质」定位），并保留「宿主将来提供 `backgroundMaterial: mica/acrylic` 时本实现无需改动
  即可受益」。附自查脚本，且点明一个反直觉点：**「正常」与「观感平」两种环境返回的 computed 值可能完全相同**
  （`blur(12px)` / 带 alpha 的背景 / `14px` / roots 含 `data-dsh-glass-float`），该脚本只能证明插件侧规则生效，
  透明底只能靠肉眼层次或对宿主容器取 `backgroundColor` 的 alpha 判断。更早的第三方壳版本无可靠对照，不下结论。

## [0.5.8] - 2026-09-28

### 修复

- **兼容模式摘掉三族「子串选择器」的误命中（issue #17）**：`[class*='card']` / `[class*='panel']` /
  `[role='tooltip']` 都是宽泛子串匹配，**无法区分「面」与「面里的行级容器」**，报告人在 DSH `0.1.7-rc.2` +
  `0.5.7` 上给了 5 组可复现实例（含只读取证脚本与逐元素 computed 对照）。这次按证据逐族处理，三者都是
  「规则画出了宿主没画的东西」，不是审美偏好：
  - **`[class*='panel']` 从 compat 的三条规则里整体移除**（#16 时只是加了
    `:not([data-sidebar-right-panel], [data-sidebar-right-panel] *)` 把宿主右栏容器摘出去）。panel 在本皮肤里
    **从不被填充**（panel 会嵌套，填充会叠出宿主没要的内矩形），所以「只 blur」在**纯色地面**上是恒等变换、
    零像素收益（issue #13 实测）；它唯一的可见效果落在「背后不是地面」的场景，也就是第三方插件的**行级**
    `*panel*` 元素——报告人实测 better-sidebar 的行高亮背景值前后逐字节相同，只多出一层把 8% 平滑高亮渲染成
    硬边灰块的 blur。唯一有证据需要模糊的 panel 是宿主自己的右侧栏**展开态**，#16 已为它写了专用规则
    （按 `data-sidebar-right-panel` + `data-sidebar-right-open`）⇒ 整族删除后该场景观感不变。
  - **`[role='tooltip']` 从 compat 的三条规则里移除**：原生 tooltip 自带 `--dsw-alias-tooltip-bg` 配色，
    填充它是**替换**设计已经拥有的 token（违反本项目「玻璃层不得改变配色语义」），且大面档套在 40×26px
    的侧栏悬停气泡上读作「文字压着一块灰底」。
  - **`[class*='card']` 收窄到 `[data-composer-card]`**（composer 卡）。离线扫描本机 `0.1.7-rc.2` 全套客户端包
    （957 个文件）里全部 **20 个 `*_card` 类名**，18 个**自绘 `background`**（`--dsw-specific-input-major` /
    `--card-fill` / `--dsw-alias-settings-card-fill` / `--plan-card-fill` / `--dsw-alias-bg-layer-1` …）⇒ 对它们
    我们是**替换**了设计自己拥有的 token（与 A2 代码块同一个缺陷），而它们自己的近不透明底色已经把模糊盖住
    （零收益，纯成本）；剩下 2 个（`CY-8Ka_card` / `cvtE3a_card`，外加 SkillRow 的 `iWrAna_card`）**没有任何
    background 声明** ⇒ 这条规则是唯一把它们画出来的东西，正是报告人的整行灰纹与凭空孤线（A1/A3）。
    唯一既有稳定钩子、又真的浮在滚动内容之上的 card 是 composer 卡（`InputBar` 渲染 `data-composer-card`，
    issue #13 实测约 76k px² 模糊面）⇒ 它保留完整配方（填充 + rim + blur）。代码块不再需要单独排除：
    子串没了，它自然进不了这个族。设置页的卡不受影响——它们的玻璃来自 `[data-dsh-glass-settings]` 下的
    **token 重映射**，不走这条规则。
  - 测试：`tests/glass-css.spec.ts` 新增一条**按族锁定**的用例（panel 只允许出现在宿主右栏展开态规则里、
    tooltip 在 compat 下彻底消失、compat 下不得再出现 `[class*='card']` 且 `[data-composer-card]` 必须出现在
    三条规则里），**三条断言各自做了变异验证**（回退任一族分别报
    `the generic panel family came back` / `compat frosts tooltips again` / `the card substring came back`）；
    #16 那条用例里「容器外 panel 仍必须被模糊」的对照组 `#outside` **反向**（现在必须**不**被模糊），
    另一条对照组从 `class="abc123_card"` 换成 `data-composer-card`，`scripts/e2e-boot-check.cjs` 的合成
    markup 对照组与 rim 采样选择器同步更新。单测 233/233、`typecheck` 通过。
    **真机 e2e 已复跑通过**：DSH `0.1.7-rc.2` + 系统 Chrome，**19/19**（49 s），其中这次改动的三条直接证据是
    ——合成 markup 的 `{"closedPanel":"none","closedBody":"none","openPanel":"blur(12px)","controlPanel":"none"}`
    （`controlPanel` 就是本次反转的对照）、宿主右栏真页采样闭态 `{"open":false,"blur":"none","bodyBlur":"none","size":"648x900"}`
    （同页 A/B 插回旧规则立刻变 `blur(12px)`、撤掉回 `none`，证明读数敏感），以及 rim 采样这次落在
    `uV2eYG_card`（composer 卡）上 ⇒ 新锚点 `[data-composer-card]` 在真页确实生效。
  （EN: compat drops three substring families — the generic `[class*='panel']` blur, `[role='tooltip']`, and the
  `card` substring (narrowed to the composer card's own `data-composer-card` hook). Each removal is justified by
  "the rule painted something the host never drew": panels are never filled, so a blur-only rule had zero payoff
  over the solid ground and only ever showed up on third-party row-level `*panel*` containers; the native tooltip
  owns `--dsw-alias-tooltip-bg`; and an offline sweep of all 20 `*_card` classes in the shipped client packages
  found 18 declaring their own `background` (so the skin was replacing a design token while their own fill
  already covered the blur) and 2 declaring none (the reported grey row stripes). Locked by a per-family jsdom
  case whose three assertions are each mutation-verified, with the #16 controls reversed/aligned and the
  boot-check e2e matching. The live-GUI e2e was re-run on DSH `0.1.7-rc.2` with system Chrome:
  **19/19 in 49 s**, including the reversed synthetic-markup control
  (`{"closedPanel":"none","closedBody":"none","openPanel":"blur(12px)","controlPanel":"none"}`), the
  host right-sidebar sample in its closed state (`none`, with an on-page A/B showing the old rule
  flips it back to `blur(12px)`), and the rim sample now landing on `uV2eYG_card` — the composer card,
  i.e. the new `[data-composer-card]` anchor really matches in the live page.)

## [0.5.7] - 2026-09-27

> 本节含两批：2026-09-24 下半场那批（曾以 **`0.5.7-beta.0`** 单独发到 npm 的 `beta` 渠道，`latest` 当时仍是 `0.5.6`）
> 与 2026-09-27 的 **issue #16** 修复。整节作为 **`0.5.7`** 发到 `latest`（提交 `bbba077`、`4b3fa59`、`1b44822`）。

### 修复

- **兼容模式不再给 DSH 原生右侧栏的「布局壳」加模糊（issue #16）**：`[class*='panel']` 是宽泛子串匹配，
  命中了宿主自己的右侧栏容器 `P3OORG_panel` 与其 `P3OORG_panelBody`
  （`@deepseek-ai/dsh-client-ui-sidebar-right`）。两者都是**透明布局壳**（`position:absolute;
  pointer-events:none`，没有任何 `background` 声明），关闭右栏时宿主只把**子节点** dock
  `translateX(...)` 移出并 `visibility:hidden`，容器本身仍停在窗口右缘 ⇒ 它身上的 `backdrop-filter`
  继续绘制；右 300px 下方是正文内容（**不是**纯色地面），模糊不是恒等变换，于是残留一条约
  **300×518px** 的磨砂带（报告人在 DSH `0.1.7-rc.2` 实测 `x=1156 y=0 w=300 h=518`、computed
  `blur(12px)`，与其配置的 `blur: 8` 不符——12px 正是这条规则的硬编码字面量，容器与 body 在同一矩形上
  各报一次）。现在按稳定钩子 `data-sidebar-right-panel` 把该容器**及其整棵子树**排除，只用
  `[data-sidebar-right-open]` 在**展开态**把模糊加回来 ⇒ 打开时观感不变，关闭后残带消失。
  `tests/glass-css.spec.ts` 新增一条**选择器级**用例（拿宿主真实 markup 跑 `querySelectorAll`，含
  「容器外的 panel 仍必须被模糊」的对照组，防 `:not()` 被引擎静默忽略），**两层变异都验证会红**
  （回退成裸子串 / 只删子树那半，分别报 `wrapper blur, open=false` 与 `panelBody blur, open=false`）；
  `scripts/e2e-boot-check.cjs` 加了 compat 下的**真页级联**采样（真会话里读宿主渲染出来的
  `[data-sidebar-right-panel]`；新 `DSH_HOME` 无会话时记 `skipped`，不假绿）与一条**不依赖会话**的
  合成 markup 版本（往真页塞 `P3OORG_panel` + `P3OORG_panelBody` 读计算样式——真 Chromium + 真样式表，
  带「容器外的同名类仍必须被模糊」的对照组），外加**同页 A/B**：把修复前那条选择器插回 `<style>`，
  同一个真宿主元素必须立刻从 `none` 变 `blur(12px)`、撤掉再回 `none`。**在 DSH `0.1.7-rc.2` + 系统
  Chrome 上实跑 19/19 通过**（临时 `DSH_HOME` 自动建了会话，那条真机断言没跳过：闭态容器 648×900、
  `backdrop-filter: none`；A/B 实测 `{withOldRule:"blur(12px)", bodyWithOldRule:"blur(12px)",
  afterRemoval:"none"}` ⇒ 读数敏感，且旧规则正是成因）。
  顺带更正 `glass.module.css` 里把 `P3OORG_panel` 称作 "opaque" 的旧注释——0.1.7-rc.1/rc.2 实测无 `background`。
  （EN: compat mode no longer frosts the host's right-sidebar *layout* wrapper — that
  `[class*='panel']` substring match hit `P3OORG_panel`/`P3OORG_panelBody`, which stay in the DOM after the
  panel closes, so the blur kept painting a ~300x518px band at the window's right edge; the wrapper and its
  whole subtree are now excluded via the stable `data-sidebar-right-panel` hook and re-frosted only while
  `data-sidebar-right-open` is present, locked by a selector-level jsdom case whose two halves are both
  mutation-verified）

- **官方桌面版现在能被正确识别（`process.versions.electron`）**：上一节把识别信号改成了「官方壳注入的
  `DSH_DESKTOP_NODE_EXECUTABLE`」，但 2026-09-24 取证发现官方壳**根本不注入它**（上游说明：
  「**`DSH_DESKTOP_NODE_EXECUTABLE` 仅为包安装注入**」），于是官方桌面版会退化成纯 web 文案。
  现在 `isDesktopShellEnv()` 认**两路信号**：社区壳的环境标记，或 Electron-as-node 运行时
  （`process.versions.electron`，实测 Electron 37.10.3 有值、纯 node 为 `undefined`）——
  官方壳的 Host 正是 Electron 以 node 模式 spawn 的。`tests/profile-detect.spec.ts` 新增 5 条断言，
  `tests/e2e/update-check.e2e.spec.ts` 新增一条走 Electron 分支的真路由用例，**两条路径都做了变异验证**
  （拆掉 Electron 分支分别变红；e2e 那条起初推进 30 分钟会命中上一条写入的未来时间戳缓存而**假绿**，
  改成 60 分钟后才真正验证到）。**只影响提示文案与 profile 探测的 `env` 字段**，持久化与 profile 名不受影响。
  （EN: the official desktop shell does not expose the env marker either, so it is now recognized through
  the Electron-as-node runtime; both branches are mutation-verified, and the e2e case needed a longer clock
  advance to stop passing off the previous case's cached verdict）

### 其他

- **启动级 e2e 在 DSH `0.1.7-rc.2` 上跑得通了（顺手修的是 harness，不是插件）**：
  ① 向导是多包拼的多步流程（`settings-account` 的「继续 / 进入应用 / 跳过」+ `settings-models` 的
  「稍后配置」），**步骤切换的间隙整棵子树会短暂脱离 `role=dialog[aria-modal]`**，旧写法按 dialog 找，
  按完第一步「继续」就以为做完了 —— 之后每次点击都被残留的 `_mask_*` 遮罩拦下（本机实测 30s 超时）。
  现在 dialog 找不到就按按钮文案在全页找，并且**轮询到遮罩真的消失**才算走完。
  ② 「兼容模式」那一次点击实测会**静默不生效**，于是它下面**所有** compat 断言都在「compat 其实没开」
  的状态下取样（rim 找不到、`panel` 没描边、右侧栏没 blur 一起变成假绿，本机一轮就撞上了）——现在轮询到
  html 真挂上 `data-dsh-glass-compat` 再往下，并把这个切换本身也断出来。
  ③ 本机 `%LOCALAPPDATA%\ms-playwright` 被清空时退到**系统 Chrome**（省一次浏览器下载），并按
  AGENTS.md 给 launch 加 `--no-proxy-server`（本机沙箱的 `HTTP_PROXY` 会吃掉 localhost 请求）。

- **更正「官方桌面壳靠 `DSH_DESKTOP_NODE_EXECUTABLE` 识别」这条假设（2026-09-24 取证）**：上游架构说明的原话是
  「`DSH_DESKTOP_NODE_EXECUTABLE` **仅为包安装注入**」（`.agents/notes/implemented/architecture/2026-09-11-desktop-electron-node-runtime.zh.md`），
  代码印证：`apps/desktop/src/host-process.ts` 以 `desktopNodeEnvironment(this.node, undefined, …)` 起 host，
  `bin === undefined` 时**不设**该变量；`apps/desktop-host/src/index.ts` 只在 `runProfile({ packageManager: { env } })` 里给它。
  ⇒ 官方 Electron 桌面版（`apps/desktop` + `apps/desktop-host`，`private: true`、**未发 npm**）的 **profile 进程里没有它**，
  `isDesktopShellEnv()` 在官方壳下恒为 false、更新行会退化成纯 web 文案。**profile 名与设置读写不受影响**
  （前者靠扫 `profiles/` 目录命中 `desktop`，后者走 0.1.7 的 `configForms` seam，与壳无关）。
  已实测的替代信号：Electron 以 node 模式运行时 `process.versions.electron` 有值（本机实测 `37.10.3`），纯 node 下为 `undefined`。
  本轮**只改注释与文档**（`src/profile-detect.ts`、`AGENTS.md`、`README.md` / `README.en.md`），运行行为未动。
  （EN: the official desktop shell does not mark its profile process at all — upstream injects
  `DSH_DESKTOP_NODE_EXECUTABLE` into package-install children only — so the desktop probe is a no-op there;
  comments and docs now say so, behaviour unchanged）

> **2026-09-24 追加：补齐 DSH STORE 的兼容性声明（`AI-Scarlett/DSH-Store` issue #1106）。** 以下变更在
> `0.5.7-beta.0` 之后，**尚未发版**。

### 其他

- **`package.json` 补上 `dsh.compatibility`（issue #1106 的第一条整改项）**：此前 manifest 里没有任何兼容声明，
  DSH STORE 的自动策略因此把条目判成 `blocked`（原因之一「DSH compatibility is not explicitly declared」）。
  现在显式声明 `dsh: ">=0.1.5-rc.1"`、逐版本 `dshReleases`（`0.1.5-rc.3`、`0.1.7-alpha.1`、`0.1.7-alpha.2`、
  `0.1.7-rc.1` 均为 `compatible`）与 `dshOperations`（`0.1.7-rc.1` 的 `install`/`start` 记为 `passed`，
  依据是 2026-09-24 的真机验证；`uninstall`/`rollback` 如实留 `unknown`）。声明值用**对方自己的判定代码**对跑校验过：
  `inferredCompatibility` 不再为 `null`、`sourceDeclaredCompatibility` 归一化不抛错，
  且当前官方窗口 `{0.1.7-alpha.1, 0.1.7-alpha.2, 0.1.7-rc.1}`（target `0.1.7-rc.1`）内三条全部命中。
  **注意这里不能用 `peerDependencies` 声明 DSH 兼容**：上游 `dsh-app-boot` 的 `evaluatePluginCompatibility`
  会据此判定并**跳过整个 bundle**（`>=0.1.5` 对 `0.1.5-rc.3` 为假），`dsh.compatibility` 才是 store 专有、上游不解析的字段。
  （EN: declare DSH compatibility in `dsh.compatibility` — never via a `@deepseek-ai/dsh` peer range, which makes
  upstream skip the whole bundle; the declaration was validated with the store's own resolution code）
- **README 增加「兼容性、权限与失败边界」小节（中英双语）**：如实披露文件读写边界（`$DSH_HOME/profiles/` 只读、
  `~/.dsh-tui/themes/` 只写、一次性读旧状态文件）、唯一的外部服务（`registry.npmjs.org` 的更新检查，无遥测）、
  无命令 / 无凭据、以及失败边界（更新检查失败不阻塞启动）与唯一的安装期脚本 `prepare`。
  这是 DSH STORE 上架契约要求、也是用户安装前该看到的信息。
  （EN: a new "Compatibility, permissions and failure bounds" section in both READMEs）
- **记录（未做）：DSH STORE 的自动批准门禁对本插件结构性不可达** —— 它要求运行时代码里 files / network /
  commands / credentials 信号全为零且无生命周期脚本，而本插件的 profile 探测（读 `$DSH_HOME`）、TUI 主题同步
  （写 `~/.dsh-tui/themes`）与更新检查（fetch npm registry）都是核心功能。条目保持 `blocked`（商城不提供安装按钮，
  但保留 GitHub 手动安装入口）是预期状态；若要真正上架需提交构建产物并走人工 PR 申请 `user-reviewed`。
  取证脚本与对方策略代码副本在 `.debug/dsh-store/`（不入库）。
  （EN: automatic store approval stays out of reach by design; the entry remains `blocked` with a manual-install entry）

## [0.5.6] - 2026-09-24

> 本节节内各批都先在 npm 的 `beta` 渠道发过一轮（`0.5.6-beta.0` → `beta.2`），本版本起整节进 `latest`。
>
> 第一批来自 2026-09-22 的全量代码审计（`docs/code-audit-2026-09-22.md`）：9 条缺陷 F1~F9 同日修完，
> 新增 15 条断言（173 用例全绿），其中 F1/F2/F3/F5/F6 逐条用变异测试验证过「改回旧写法即变红」。

> **2026-09-23 追加：上游 0.1.7 适配复核（含跨版本兼容）。** 按 `AGENTS.md`「上游形态与维护核心」核对，官方 token 表自
> 0.1.6 / 0.1.7 起**新增 9 个 token**（static 73→77、alias 79→84，取值变更只有 2 处），其中两个会直接把配色改坏（带 alpha
> 的静态色被抹成实心、菜单底色退成官方灰），另有一处 DOM 钩子自 0.1.5-rc.2 起就指错了元素。核对用的上游快照为
> `dsh-v0.1.7-alpha.2`（master，2026-09-22），并逐项对 **0.1.5-rc.2 / rc.3 / 0.1.6-alpha.1 / 0.1.7-alpha.2** 四个 tag 复核
> （`register()` 契约、DOM 钩子、token 差异）。生成物重出，**新增 15 条断言（5 条经变异验证会红），191 用例全绿**。
> **未做真机复核**——本机 profile 的依赖树不完整（`@deepseek-ai/dsh-sandbox-local` 解析失败），起不来服务。
> 本批（连同 `0.5.6-beta.0` 之后的官方桌面壳识别、CI 树冻结）随 **`0.5.6-beta.1`** 发到 npm 的 `beta` 渠道；
> `latest` 仍是 `0.5.5`。

> **2026-09-24 追加：DSH 0.1.7 换掉 settings seam 的适配（issue #15）。** 上游 `0.1.7-alpha.1` 删掉了客户端的
> `settingsScope` 服务与 Host 的 `settings.installSection`，改成「插件声明带 `.volatile()` 的 `Config`，设置服务按
> **profile 条目 id** 投影成表单，客户端用 `ctx.configForms.get(id)` 读写」。本插件把旧服务写进了**硬依赖 `inject`**，
> 于是 0.1.7 上整条插件永久 `pending`（主题、四条设置行、更新检查全不加载）；Host 侧的 `installSection` 调用同时失效。
> 因为 `latest`（`0.1.5-rc.3`）仍是旧 seam 且在售，本次改为**双通道**：两个服务各走一次**可选注入**，谁在就用谁，
> 三处语义差异（「还没有用户层」的判据、写栅栏、拒绝信号）全部收敛在通道内部，调用方看不到；`settings.general.item`
> 槽位与全部 UI 不动。跨版本的关键守卫是 `.volatile()` 的 `typeof` 检测——该方法是 schemastery **3.18.3** 才有的，
> 而 0.1.5/0.1.6 宿主锁 `3.18.2`，无条件调用会在**模块求值期**抛错（把「不激活」升级成「加载失败」）。
> **新增 23 条断言（215 用例全绿）**；8 条跨版本判定（含软注入永不出现、3.18.2 下守卫成立、旧宿主不会多出表单）
> 用一次性探针实测过，0.1.7 侧的表单投影用 0.1.7-rc.1 的 `volatileForm`/`isVolatilePath` 原逻辑对跑验证。
> **当时未做真机复核**（本机 CLI 是 `0.1.5-rc.2`、`web` profile 依赖树不完整）——**已于同日补做并通过**，见本节下方。
> 详见 `docs/issue-15-settings-seam-0.1.7.md`。
> 本批经 `0.5.6-beta.2` 在 `beta` 渠道试跑后，随本版本进入 `latest`。
>
> **2026-09-24（beta.2 之后）：修正客户端平台模块表的镜像。** `web-platform.ts` 是上游 `packages/client/web/src/platform.ts`
> 的**镜像**，此前多写了两个**已退役**的 specifier（`dsh-client-web-react`、`dsh-client-schema-form`，两者都停在 `0.1.0-rc.7`，
> 在任何版本的上游表里都不存在）、漏了两个**现役**的（`dsh-client-store`、`dsh-client-ui-dockkit`）。逐 tag 核对
> `v0.1.2-rc.1 / v0.1.5-rc.3 / v0.1.6-alpha.2 / v0.1.7-alpha.1 / v0.1.7-rc.1 / master`：修好后的表在我们支持的全部版本上一致
> （只有 `v0.1.2-rc.1` 早于 dockkit）。**此前不致命**——客户端只从这张表取一个值导入（`react` / `react/jsx-runtime`）——
> 但表错着，一旦以后要从 `dsh-client-store` / `dsh-client-ui-dockkit` 取值就会被 bundle 纯度门拒掉，
> 而引用那两个退役名字会产出一个真实表答不上来的 `require()`。新增 5 条断言把表钉住（含「产物只 require 表内 specifier」
> 与「tsdown 仍从表派生 externals」），两条经变异验证会红。
>
> 同日 **真机验证了 beta.2 在 DSH `0.1.7-rc.1` 上确实修好**（维护者把 DSH Desktop 升到 0.1.7 后，用该运行时启动 `web` profile）：
> 装 beta.1 时页面一字不差地复现 `pending (waiting for service: settingsScope)`；换 beta.2 后无 pending、四条设置行齐全、
> 点 Mocha 后 profile patch 的 `flavor` 落成 `catppuccin-mocha`、重启后用全新浏览器会话仍从文档 hydrate 回 Mocha。
> **真机还抓出一个单测与假宿主都没暴露的缺陷**：`scheduleLegacyMigration` 的三次机会之间只挡了「已完成」标志，
> 于是首次启动跑了两个并发迁移——先写的成功，后写的在它提交前读到同一个 revision、撞栅栏被拒，日志里出现
> `legacy state migration failed: SettingsConflictError`（迁移其实成功了，观感像出错）。改为入口**同步认领**槽位
> （仅在 outcome 为「暂不可寻址」时释放），并加 `tests/migrate-legacy.spec.ts` 并发用例（用跨 tick 的写延迟复现；
> 去掉守卫即变红）。详见 `docs/issue-15-settings-seam-0.1.7.md` §0.1。
>
> 同日顺带更正一处沿用了三个版本的错误叙述：注释与 README 一直写着「DSH Desktop 每次启动用随机回环端口 ⇒
> localStorage 本来就空」，实测**两个桌面壳都早已是固定端口**（官方壳 `apps/desktop-host` 传 `--port 19387`；
> `anywhere-labs/dsh-desktop` 默认 `43120`，仅绑定冲突时顺序 +1，且 2026-08-21 就提交了 "prefer a stable loopback
> port"）。持久存储的设计理由因此改写为「localStorage 是 per-browser / per-origin，DSH home 才是机器级真源」——
> **代码与行为一字未改**，只改叙述。另记一处已知缺口：0.1.7 会一次性把 `settings.yaml` 按同名条目导入后改名
> `.imported`，我们旧的 `catppuccin:` 段匹配不到条目、被拒；捞回它要读 YAML 而 host 半区是零依赖产物，本次未做，
> 影响面仅限于「偏好只在旧持久存储里、当前浏览器 localStorage 里没有」这一种情形（固定端口的 origin 是稳定的，
> 正常升级会把 localStorage 的选择推回新文档）。

### 修复

- **DSH 0.1.7 上插件不再永久 pending（issue #15）**：客户端 `inject` 从 `['slots','locale','theme','settingsScope']` 改为
  `['slots','locale','theme']`，两套设置服务（`configForms` / `settingsScope`）各走一次可选注入，由 `src/client/state-sync.ts`
  的 `DurableScope` 适配层绑定「宿主要在的那一个」。副作用是**注入时机提前**（不再等设置服务）：本地缓存先渲染、设置服务
  到达时再补一次 hydration，这正是原有的 boot 语义。3 条断言钉住「任一 seam 都不在硬依赖里」「两条软注入都在」
  「服务晚于 apply 出现时仍能补水」。（EN: the client no longer hard-depends on either settings service — the plugin used to
  wait forever on `settingsScope`, which 0.1.7-alpha.1 removed; both seams are now bound optionally behind one adapter）

- **Host 半区同时支持两套设置服务**：新增 `Config`（volatile 字段表，由 `cordis.patch.yml` 条目 id 寻址）供 0.1.7 投影表单；
  `installSection` 分支保留并加 `typeof` 守卫，旧宿主行为逐字节不变（注册、`catppuccin` 命名空间、落点、迁移栅栏策略都未动）。
  一次性迁移搬到 `src/migrate-legacy.ts`：新通道下**必须延迟 + 重试**——`ctx.inject(['settings'])` 在服务已就绪时会同步回调，
  那一刻本条目的 fiber 还没 ACTIVE，`describe()` 看不到自己，迁移会被静默跳过。表单默认值与 `defaultSettingsSection()`
  逐字段一致（客户端把「等于默认」当作「尚无用户选择」），并有断言防止漂移。（EN: one field table feeds both schemas; the
  migration is deferred on the new seam because the entry is not addressable until its own fiber is ACTIVE）

- **`.volatile()` 做了能力检测（跨版本兼容）**：`.volatile()` 仅存在于 schemastery 3.18.3+，而 0.1.5/0.1.6 宿主锁 3.18.2，
  且本插件的 lib 产物把 `@deepseek-ai/schemastery` 保持外置（用宿主那一份）——无条件调用会在模块求值期抛
  `TypeError: ...volatile is not a function`，把「插件不激活」升级成「插件加载失败」。`maybeVolatile()` 在无该能力时返回原节点，
  于是旧宿主上条目不含 volatile 元信息、不产生任何表单（等价于 0.1.7 之前的现状），新宿主上才是可编辑表单。
  3 条断言覆盖守卫的两个分支、Config 每个叶子都带 volatile、以及旧 schema 一个都不带。（EN: `.volatile()` is
  feature-detected because the old hosts load this module with schemastery 3.18.2, where the method does not exist — calling it
  unconditionally would turn "plugin pending" into "plugin failed to load"）

- **`.volatile()` 加上「两个 schema 不复用节点」的约束**：`.volatile()` 是原地改 `meta` 并返回 this，旧命名空间 schema 与新
  volatile `Config` 因此各自从字段工厂取一套全新节点。（EN: the two schemas never share node instances, since `.volatile()`
  mutates the node in place）

- **菜单底色的半透明只在「宿主真会模糊它」时启用（跨版本兼容）**：`--dsw-specific-menu` 从 `var(--dsw-alias-bg-layer-3)` 变成
  58%/50% 半透明，是**和** `--dsw-menu-backdrop-filter: blur(40px) saturate(150%)` 同一次改动引入的（0.1.7-alpha.1；0.1.6-alpha.1
  仍是不透明阶梯步、也没有该 blur token）。`latest` 线（0.1.5-rc.2 / rc.3）上没有那个 blur，同一份 58% 填充就只是**纯透明**——
  聊天内容会直接透过菜单，而该 token 还画着带文字的面板（队列 dock、待办、目标条、任务列表、统计弹窗…）。因此注册主题时
  探测宿主是否声明了该 blur（读 `<body>` 计算样式；先用 `--dsw-mask-blur` 做机制自检，读不到就保守按「无 blur」处理），
  据此决定注入半透明填充还是不透明的 `bg-layer-3`；该补丁位于用户覆盖项**之下**，显式 override 仍然最高优先。5 条断言覆盖
  四种宿主形态（有/无 blur、样式表未入级联、无 body、无计算样式），并已用变异验证（永远返回 `{}` 即红）。（EN: the translucent
  menu fill only stands where the host actually blurs it — upstream introduced the fill and `--dsw-menu-backdrop-filter` in the
  same 0.1.7-alpha.1 release, so on the 0.1.5 latest line the same value would be plain transparency over the transcript; the
  theme registration now probes the host and falls back to the opaque ladder step, below user overrides）

- **官方 0.1.7 新增的带 alpha 静态色不再被抹成实心**：`--dsw-static-green-500-a08` / `-a12` 与 `--dsw-static-red-400-a12` / `--dsw-static-red-600-a08` 是「这一步 8%/12% 透明度」，不是阶梯步号——旧生成器把它们当未知步号落进家族默认档（100%），于是 `--dsw-alias-code-diff-added` / `-deleted` 这对 diff 底纹会渲染成不透明色块。新增 `splitAlpha()`（剥离后缀）与 `withAlpha()`（还原上游 alpha），并用 `flattenMix()` 把 `red-400` 这类先混色再上 alpha 的值算成单个 hex，产物保持 `color-mix(in srgb, #hex N%, transparent)` 一种形式。配套 5 条断言：4 个 token × 4 风味的 alpha 数值、fill 必须解析到 hex、以及两个 diff 别名的引用关系；已用变异验证（`withAlpha` 退回直返原值即红）。（EN: the alpha-suffixed statics added in 0.1.7 are "this step at N%", not ladder steps — the old table fell through to the family default and painted both code-diff surfaces fully opaque; the suffix is now split off and re-applied, and pre-mixed fills are flattened so the value stays a single `color-mix`）

- **菜单与浮层底色重新跟住 Catppuccin**：官方 0.1.7 把 `--dsw-specific-menu` 从 `var(--dsw-alias-bg-layer-3)` 改成字面半透明灰（浅 `rgba(248,249,250,.58)` / 深 `rgba(48,49,54,.5)`，配新 token `--dsw-menu-backdrop-filter: blur(40px) saturate(150%)`，macOS 走 94%）。生成器对 specific 层是「原样保留」⇒ 10 余个消费方（MenuView、PopupSelectView、QueueDock、ContextMeter、TodoPanel、GoalBar、JobListAction、ModelSelect、dockkit…）会一起退成官方灰。改为**保留上游的 alpha、把色相放回 `bg-layer-3`**。实测顺带发现收益：暗色三风味的菜单叠在更深的页面底色上，弱标签对比度反而**上升**（Frappé 的 tertiary 3.48→4.41、caption 2.80→3.54、dimmed 2.20→2.79），Latte 因页面与菜单同色而不变；三处依赖「菜单色」的既有断言随之改为按半透明合成后再算对比度（新增 `resolveSurface()` / `over()`）。（EN: upstream stopped deriving `--dsw-specific-menu` from the ladder and hard-codes a translucent neutral for its own backdrop-filter; keeping the literal would drop the flavour from every menu and popover, so the token keeps upstream's alpha but is re-pointed at `bg-layer-3` — and the translucent menu actually lifts dark weak-label contrast, so the menu-based assertions now composite before measuring）

- **新增的 `--dsw-alias-link` 在暗色下达到 AA**：官方暗色 `link` 用亮蓝 deepseek-400 `rgb(122,170,255)`（对页面 7.83:1），而我们的暗色蓝梯 400 步是 66% 混向页面，实测只有 3.94（Frappé）/ 4.38（Macchiato）/ 4.79（Mocha）——正文链接低于 AA。改为指向满档 accent（与 issue #11 的 `state-business-primary` 同款做法：不换色相、只换档位），实测 6.51 / 7.77 / 8.91:1。Latte 保持官方 500 步不动：我们 4.34:1 本就高于官方自己的 4.23:1，没有可偏离的证据。（EN: `--dsw-alias-link` is new in 0.1.7 and upstream's dark value is a bright blue (7.83:1); our dark blue ladder's 400 step is a 66% mix that leaves link text under AA, so the token now reads the full accent step — Latte keeps the official step because ours already beats upstream's own ratio）

- **文档 / PDF 预览的浅色标签不再糊在深底上**：0.1.7 新增的 `bg-document-preview`（浅→bluish-750、深→bluish-950）与 `label-document-preview`（浅→bluish-200、深→bluish-300）是「深底 + 浅字」组合，官方浅色自己实测 9.27:1；Latte 的阶梯按浅端读底，bluish-200 落在 overlay0，这对只剩 3.07:1。新增 Latte 专属 override 指向阶梯最浅步（`bluish-00`），实测 7.06:1，并把「暗色标签表」重构成「按方案分表」（新增 `lightLabelReadabilityOverrides`）。暗色维持 4.45~5.07:1 不动（已贴近 AA）。（EN: upstream's document-preview pair is a dark surface with a light label (9.27:1 on its own pair); Latte reads the ladder light-end-first, which collapsed it to 3.07:1, so the light label now points at the ladder's lightest step）

- **右侧栏的玻璃钩子改指面板本体（统计行经复核：原本是对的）**：详情栏接缝原写 `[class*="detailsCol"] [class*="root"]`，但该列在 **0.1.5-rc.2 已改名 `rightbarCol`**（`ui-layout/AppFrame.module.css`）；而右侧栏**面板自己**（`.session` / `.panel`）没有 `root` 类——带 `root` 的是它托管的内容视图（ui-sidebar-files / browser / terminal），文档预览视图连 `root` 都没有。⇒ 这个接缝此前命中的是**当时打开的那个内容视图**，或干脆什么也不命中，而不是样式表真正想透明化的那个面板。改为命中稳定属性 `data-sidebar-right-panel`（`SidebarRight.tsx`），旧写法保留作 0.1.2-rc.1 布局的兜底。统计行的接缝经复核**本来是正确的**（`StatsPills` 的根正是 `<div class="…root…" data-composer-stats>`，0.1.5-rc.2 与 0.1.7 一致），顺手补一个按位置的 `> *` 兜底——今天它与类名分支指向同一个元素、stamp 幂等，只是免得上游某天改掉那个类名就静默失效。新增 4 条 jsdom 断言（新属性命中 / 旧列兜底 / 真实 root 形态 / 无 root 形态），其中 2 条已用变异验证（改回旧选择器即红）。**注**：无真机复核，且右侧栏透明化的对象从「内容视图」变成了「面板本身」，观感必然有变化，需要视觉确认。（EN: the right-panel seam keyed off `detailsCol`, renamed to `rightbarCol` back in 0.1.5-rc.2, and off a `root` class the *panel* never had — the `root`-classed elements are the tab views it hosts, so the stamp used to land on whichever view was open (or nowhere, for the document preview); it now hooks the panel's own `data-sidebar-right-panel`. The stats seam turned out to be correct already — StatsPills' root is a `root`-classed div in both hosts — so it only gained a position-based `> *` fallback. Visuals still need a real-machine check）

> 以下条目来自 2026-09-22 的全量代码审计（F1~F9）批次，已随 `0.5.6-beta.0` 发布。

- **官方桌面版（Electron）也能被识别成 desktop（2026-09-22）**：官方上游 monorepo 已经带上 `apps/desktop` / `apps/desktop-host`（Electron 壳，启动 `$DSH_HOME/profiles/desktop`），但它**不提供**社区桌面包那个 `desktopProfiles` 服务（在官方仓搜该名字命中 0），只注入环境变量 `DSH_DESKTOP_NODE_EXECUTABLE`；而 `src/update-check/host.ts` 原先只探测服务 ⇒ 在官方桌面版里更新行会退化成纯 web 文案（升级命令提示与重启提示都按命令行给，尽管探测到的 profile 名已经是 `desktop`）。新增 `isDesktopShellEnv()` 作为第二路信号，`tests/profile-detect.spec.ts` 与 `tests/e2e/update-check.e2e.spec.ts` 各有断言（后者已用变异测试验证：去掉该分支即红）。维护核心同时明确为**官方 web + desktop**，社区桌面壳保持兼容（见 `AGENTS.md`「上游形态与维护核心」）。（EN: the official Electron desktop shell is now recognized too — it boots the same `desktop` profile but marks itself only through the `DSH_DESKTOP_NODE_EXECUTABLE` env var, since the official repo has no `desktopProfiles` service, so the update row used to fall back to plain-web copy there）

- **跨窗口改玻璃旋钮终于会同步（审计 F1）**：`glass-layer.ts` 的跨标签 `storage` 处理器用 `event.key in NUMERIC_KEYS` 判数字旋钮，而 `in` 查的是对象的**属性名**（`blur`/`frost`/`brightness`），事件带来的却是 localStorage 键（`dsh.catppuccin.glass.blur`）——该分支**恒为 false**：A 窗口拖模糊/磨砂/亮度滑块时，B 窗口既不重绘玻璃也不刷新设置行快照（模式键用的是 `===` 比较，一直正常，恰好掩盖了这个洞）。改用 `Object.values(NUMERIC_KEYS).includes(...)`；新增 `tests/glass-layer.spec.ts`，把 `storage` 处理器的每个分支（三个旋钮、模式、开关、`key: null` 全量重载、无关键）各走一遍。（EN: cross-tab glass-knob sync was dead — the handler matched the knob object's property names instead of the localStorage keys the event carries, so blur/frost/brightness changed in one window never reached the other)

- **多窗口的陈旧写不再静默覆盖，冲突横幅也能真的出现了（审计 F2，台账 `C`/`X`）**：读侧陈旧写保护此前**恒不成立**——`client/index.ts` 是在 **flush 时**才取 `baseRevision`，而 `persistStateToScope` 内部又 `getSnapshot()` 一次，两次读取落在同一个同步块 ⇒ 版本永远相等，`'stale'` 成了死代码（后果：另一窗口在防抖窗口内提交的新选择会被本窗口的旧状态覆盖，而 `emitConflict()` 只挂在 `'stale'` 上，所以「另一窗口已更新」横幅从未真正出现过）。现在新增 `createBaseRevisionTracker()`——**调度时**捕获（`??=` 只固 burst 首版）、flush 时消费，8 处调度点收拢为一个 `queuePersist()`。`tests/client.spec.ts` 用「防抖窗口内被外部改动」的时序用例锁住，并附反事实断言（flush 时取 base 会写成 `'written'`）。（EN: the read-side staleness guard was a tautology — the base revision was sampled at flush time instead of schedule time, so an external edit inside the debounce window was silently overwritten and the conflict banner could never fire)

- **另一窗口「关闭风味」现在真的会落地（审计 F4）**：`storage` 处理器只在目标不是 `off` 时切主题，而 `applyDesired` 读到 `off` 又直接 return ⇒ 另一个窗口关掉风味后，本窗口继续渲染 Catppuccin（要刷新才一致）。新增 `readExplicitFlavorOff()` 区分「从未存过」（Desktop 每次启动都是空 localStorage，此时权威是设置文档，不能当成 off）与「显式 off」，两条路径都经 issue #10 的微任务延迟回退到用户原来的内建偏好。（EN: an "off" chosen in another window now lands here too — the explicit-off check keeps Desktop's empty storage from fighting the settings document at boot）

- **预设档位重新可用键盘到达（审计 F3）**：旋钮被手调成非预设组合时 `activePreset` 是空串，roving tabindex 于是把三格全设成 `-1`——整个预设组掉出 Tab 顺序，键盘用户无法应用预设。现在无匹配时锚定第一格，组内恒有 1 个 tab stop；两条断言覆盖「命中预设」与「自定义档位」。（EN: the preset group lost its tab stop whenever the knobs matched no preset — the roving tabindex anchored on an empty value, leaving every cell at -1)

- **自动重试用的是当前通道（审计 F6）**：`UpdateRow` 的 `check` 默认取渲染闭包里的通道，失败后 30 s 的单次重试因此会查用户已经离开的那个通道；改为调用期解析。（EN: the single 30s auto-retry queried the render-time channel instead of the one the user had since picked）

- **覆盖编辑器删掉中间一行草稿不再串行（审计 F5）**：草稿行用数组下标当 React key，而键/值输入框是非受控的——删除首行后 React 复用其 DOM 节点，输入框继续显示被删那行的文本（与状态不一致）。改为稳定 `id` 作 key。（EN: draft override rows keyed by array index made an uncontrolled input keep the deleted row's text after a delete）

- **文档里的非法 override 键会被清掉，而不是每轮白跑一次（审计 F7）**：`overrides` 的 schema 只校验「字符串字典」，手改文档可能留下非 `--` 的键；客户端读时丢弃却从不写回，于是每次设置发布都会因为这份永远清不掉的差异再跑一轮「文档胜出」。新增 `hasUnpersistableOverrides()`，采用后回写一次使文档收敛。（EN: unpersistable override entries in the document are now cleaned instead of re-triggering the "document wins" adoption on every publish）

### 其他

- **重建仓库外快照，并把解析脚本入库（2026-09-23）**：本轮发现 `.cache/dsh-ref/`（`dsw-tokens.json` / `catppuccin-palette.json`）已被清掉，生成器因此跑不起来；同时官方 Catppuccin 色板**已不在 `catppuccin/catppuccin` 仓库根**（`palette.json` 随 2.0 的仓库改造消失，旧地址返回 404）。新增 `scripts/parse-dsh-tokens.cjs`（把 `design-platform.css` 解析成 `light_static` / `dark_alias` / … 六段快照）并写入仓库，生成器头部补上两条刷新命令与新色板来源（`@catppuccin/palette@1.8.0` 的 `esm/palette.js`，与 v1.8.0 同源同数据）。顺带确认仓库快照此前还落后于 `0.1.5-rc.2`（缺 `--dsw-alias-link`、`markdown-inline-code` 的取值停在旧版），本轮已对齐到 `0.1.7-alpha.2`。（EN: the out-of-repo token/palette snapshots had been wiped — and the official palette no longer lives at catppuccin/catppuccin's repo root (404) — so the parser is now vendored as scripts/parse-dsh-tokens.cjs and the refresh commands are documented in the generator header; the snapshot was also still behind 0.1.5-rc.2 and is now aligned to 0.1.7-alpha.2）

- 删除仓库根残留的临时副本 `.client-043.tmp.ts`（被 `.gitignore` 覆盖，但会污染文本搜索与 `grep` 结果）。（EN: drop the leftover `.client-043.tmp.ts` scratch copy）
- `scripts/gen-glass-css.mjs` 在缺 `lightningcss` 时的降级路径从静默改为 `console.warn`：该分支会产出**未压缩**的另一种产物。（EN: warn instead of silently shipping the unminified stylesheet when lightningcss is missing）

## [0.5.5] - 2026-09-21

### 修复

- **更新检查的「检查时间」改用 DSH 的语言格式化，不再跟浏览器走**：`UpdateRow.tsx` 里是 `new Date(x).toLocaleString()`——**不带参数 = JS 运行时默认 locale = 浏览器语言**，而界面语言是 DSH 自己的 locale 偏好，两者从用户在设置里选语言那一刻起就可能分道（浏览器 en-US + 选日本語 → 「日语标签 + 美式时间」）。现在插件把 active locale 注进行内（`activeLocale` + `subscribeLocale`，走 `ctx.locale.getLocale()` / `ctx.locale.subscribe()`）并用 `useSyncExternalStore` 订阅，切语言即时重排。`tests/rows.spec.tsx` 新增 RTL 断言：必须带 locale 参数调用，且切语言后会以新 locale 重排（该断言已用变异测试验证会红）。（EN: the update check's timestamp now formats with the DSH locale — `toLocaleString()` with no argument silently used the browser locale, which drifts from the interface language as soon as the user picks one; the row subscribes to locale switches and re-formats live）

- **语言字典删掉 6 个死键，并加一条死键守卫（YY 附带发现）**：`glass.on` / `glass.off` 在 `eeb8096` 把总开关改成「磨砂轨道 + ✓」时就失去了渲染点（那次删掉了 `{enabled ? t('glass.on') : t('glass.off')}`），**词条留着**，随后的 `bfa2f91`（加语言的提交）又把这两条复制进了 5 种语言；`flavor.latte/frappe/macchiato/mocha` 则**从未被引用**——风味按钮渲染的是 palette 里的品牌专名。共 **6 键 × 7 语言 = 42 条**，现已删除（键集 78 → 72）。`tests/locales.spec.ts` 新增死键守卫：遍历 `src` 下除字典本身以外的所有 `ts`/`tsx`，确认每个键都有字面引用，4 个模板拼接的 `flavor.<id>.subtitle` 走显式清单；**守卫已用变异测试验证会红**（临时塞一个没人引用的键即失败）。（EN: drop six dead dictionary keys — `glass.on`/`glass.off` lost their render site when the master switch became a track + check mark and were then copied into five more languages, and `flavor.<id>` was never used because the buttons render the palette's brand names — plus a dead-key guard test that walks the sources）

- **ja / ko 的「磨砂」旋钮与预设不再各说各词（YY）**：`glass.frost`（磨砂度）与 `glass.presetFrosted`（磨砂预设）在同一语言里用了两个词——日语旋钮 `曇り` / 预设 `フォグ`（fog），韩语 `프로스트` / `포그`（fog）。现各自统一为 `曇り` / `프로스트`（不引入新词，只收拢到已经在用的那个），并同步两语言 `glass.help` 里的预设列表（否则 tooltip 会指着一个不存在的预设名）。`tests/locales.spec.ts` 新增两条断言：旋钮与预设必须同词根（归一化后前缀关系，容忍 fr Givre/Givré 与 en Frost/Frosted）、`glass.help` 必须列出三个预设名。同时把 zh 的引号统一为「」（原 `row.overridesEmpty` / `update.help` 用 “”）。**本项不假装完成母语复核**：复核清单（9 条长文案 + 长度膨胀 + 遗留的 ja `すりガラス` vs `曇り` 选择）已落到 `docs/locale-review.md`，触发条件=有对应语言的用户反馈。（EN: the frost knob and its preset no longer use two different words in ja/ko — unified on the term already in use, the help tooltips now name the current preset labels, and two assertions lock the wording family plus the help/preset coupling; zh quote style unified too; the native-review checklist lives in docs/locale-review.md）

### 其他

- **预览图脚本改为关闭设置弹窗后拍摄**：此前每张风味图都是在设置弹窗打开时拍的，弹窗遮罩把整页压暗（实测侧栏读成 `182,183,186`，而 Latte 地面是 `239,241,245`）——四张预览图都是暗的。现在拍每张前先关弹窗（点关闭 → Escape 兜底 → 仍开着就直接报错，不交出暗图），再为下一风味重开；四张风味图随之重出（**图本身在本版本才提交**）。（EN: flavour previews are shot with the settings dialog closed — its mask dimmed every shot before — and the script now asserts the dialog is gone instead of shipping a dim image）

- **新增启动级 e2e 检查（CI job `boot-e2e`）**：建一个临时 `DSH_HOME`、把本仓库 `link:` 进它的 web profile、真起 `dsh web`，然后断言「插件真被加载 / 风味真生效 / 玻璃真能切」，并读取**级联后**的关键计算样式（侧栏玻璃片不得有 `backdrop-filter`、composer 卡必须保留、compat 模式下浮动面有 hairline rim 而 `panel` 不被描边）。刻意**不做整图像素对比**：断言式采样不随字体/渲染器漂移，而仓库已有的样式级断言已覆盖大半（取舍与可行性实测见 `docs/plugin-improvements.md` §3.9）。实测 CI 成本 **+54~73 s**（独立 job，与 `check` 并行，Chromium 与 pnpm store 都带缓存）。（EN: a startup-level e2e check boots a throwaway DSH_HOME with this repo linked, runs a real `dsh web` and asserts behaviour plus key-region computed styles — no image diffing; it runs as its own cached CI job）

- **语言字典审计与复核清单（YY）**：见 `docs/locale-review.md`。结论：结构层（键集 / 空值 / 占位符 `{profile}`、`{s}`）全部通过；「与 en 逐字相同」的命中项均为合法同源词（Mica / Mode / Standard / Stable / Beta / Frost），**没有漏翻**；真正需要人读的只有 9 条长文案。（EN: locale audit + checklist in docs/locale-review.md）

## [0.5.4] - 2026-09-21

### 修复

- **兼容模式的玻璃材质终于画得出来了（OO）**：`compat` 分支此前只给 `menu` / `card` / `popover` 等家族加 `blur(12px)`，**填充却是不透明的原生色**——而本皮肤把页面地面画成纯色，纯色地面上的 blur 一个像素都不变（issue #13 的同款结论），于是兼容模式读起来≈原生界面，用户以为插件没生效（真页 computed style 实测：composer 卡 `rgb(30,30,46)` 实色）。现在这些浮动家族带上皮肤自己的材质：`--dsh-glass-card-raised` 半透明填充 + `outline` 画的 hairline rim。三个刻意取舍：① **`panel` 不填**——面板会嵌套（`panel` 里是透明的 `panelBody`），两个都填会叠出宿主没有的内框（真页实测发现），它只保留 blur；② **rim 用 `outline` + 负 offset，不用 `border` / `box-shadow`**——border 会挤动 `box-sizing:content-box` 的宿主面、box-shadow 会盖掉宿主自己的投影，`outline` 两样都不碰，再加 `:not(:focus-visible)` 让共享焦点环继续生效；③ **Latte 下让它「看得出玻璃」的是 rim 而不是填充**——那里 `--dsw-alias-bg-layer-1` === `--dsw-alias-bg-base`（官方映射），填充合成后与页面地面同色，和 PP 踩的是同一个坑。`tests/glass-css.spec.ts` 新增断言锁住「浮动家族有填充 + rim」与「panel 不得被填」。（EN: compat mode finally shows a material — the blur alone painted nothing over the solid ground, so these floating families now carry this skin's translucent fill plus an `outline`-drawn hairline rim; panels are deliberately excluded because they nest panel > transparent panelBody and filling both stacks an inner rectangle the host never asked for, and no new backdrop-filter is added）

- **会话列表的选中行终于有底色了（PP）**：真页实测发现上游 **hover 与选中的行用的是同一个 6% tint**（`rgba(38,49,72,.06)`），用户只能靠那根 2px accent 条分辨「点中的是哪一行」。选中行改用 DSH 自己的选中态 token `--dsw-specific-sidebar-nav-item-active` 的 40% 填充：`card-hover` 那一族试过但**隐形**（该 recipe 与页面地面同色，铺上去逐像素不变——同一个坑）。40% 是**对比度天花板**不是审美：该行的 12px 时间戳是 `label-secondary`，对填充的对比度在 40% 时是 4.62、到 50% 掉到 4.41（低于 AA）。四风味实测标题（14px `label-primary`）对合成后填充为 Latte **5.89** / Frappé 8.29 / Macchiato 10.07 / Mocha 11.38。上游的 hover 有意保留不动（它的 6% 与面板填充差得开；改成 `card` 档会与面板同值、又变隐形）。（EN: the selected sidebar row now gets a real fill from DSH's own selected-nav token at 40% — upstream gives hover and selected the same 6% tint, so a row could only be located by the accent bar; 40% is the contrast ceiling because the row's 12px timestamp drops below AA at 50%）

- **插件市场对话框里的卡片不再是实色块（AAA，已随 `0.5.4-beta.0` 发布）**：设置 → 插件市场的插件卡片用 `--dsw-alias-bg-layer-1` 上色，而设置弹窗作用域的玻璃化重写**漏了这一档**（只重写了 `layer-2` / `layer-3` / `module-platform`），于是四五个设置页里只有插件卡片读起来像贴在玻璃上的实色板子。补上 `layer-1` 的半透明重写（用 `soft` 档，因 layer-1 低于 layer-2/3）。（EN: the plugin-market cards inside the settings dialog were left opaque because the settings-scope glass re-pointing covered layer-2/-3/module-platform but not layer-1）

- **覆盖编辑器的新建行不再在键入第一个字符时丢焦点（XX）**：草稿行按「先键名、再值」填，键名一旦是合法 `--` token，值的**第一个字符**就把草稿行转成持久化行（行被卸载、光标丢失），靠粘贴整串时无感。现在键名与值都改为非受控 + `onBlur` 提交（与已持久化行对称），打字期间输入框保持稳定。（EN: a new override row no longer loses focus on the first character typed into its value field — both draft fields now commit on blur, symmetric with the persisted rows）

### 其他

- **预览图脚本修好并端到端跑通（FF）**：`scripts/screenshot-previews.cjs` 卡了很久，此前记的「风味切换断言失败」只是表象，真因有三个：① **`page.goto('http://127.0.0.1:3080')` 没带 token** → 401 空白页 → `openSettings` 等 90s 超时（这才是那个「`设置` 定位器超时」）；② 行标题自 J 项加了 `?` 帮助徽标后，`getByText('Catppuccin 主题', { exact: true })` **恒为 0 命中**；③ 「跟随系统」在设置弹窗里有两处（外观分段 + Catppuccin 行），原 `.first()` 恢复的是错的那个。现在：token 支持 argv / `DSH_WEB_TOKEN` / 旧日志文件三路回退并在 401 时立刻给出明确报错，行内作用域改用角色定位，且**读取并恢复本机真实的原风味**、等 300ms 防抖持久化落地。四风味 + hero 图可一键重出。（EN: the preview script was actually blocked by a missing web token (401 page -> a confusing 90s timeout), an exact-text locator broken by the `?` help badge, and a duplicated follow-system control; it now resolves the token, scopes the row, and restores the user's real flavour preference）

## [0.5.3] - 2026-09-16

### 修复

- **玻璃层删掉 4 处「画不出像素」的背景模糊（issue #13）**：本皮肤把页面地面强制成纯色（`bg-base` 实色 + 亮度混合），于是**背后只有地面的玻璃面，`backdrop-filter` 就是恒等变换**——一个像素都不变，Chromium 照样提升合成层并**每帧回读** backdrop（半径 0 px 一样计费，只有 `none` 才免提升，`will-change` / `contain` 绕不开）。这正是 issue #13 实测「云母 ≈80% GPU、兼容 <30%、模糊半径无效」的机制。按面积核对后删掉 4 处纯浪费：**侧栏 `::before`**（实测 **222,996 px²** 可见模糊并集，占全页 mica 模糊面积 61%（首屏）/ 48%（会话视图），全区最大单块，列浮起后背后只有地面）、**聊天气泡**（float 与 compat 各一处——数量最多且在流式重绘区，背后同样是纯色地面）、**轨迹视图面板**（overlay 是滚动容器内的并列视图，背后不是聊天流）。保留下来的都是**确实盖住移动内容**的面（顶栏、输入框、浮动菜单、页面边缘渐变条）——删那些才是真的降级。视觉预期是**玻璃填充逐像素不变，动的只是字形抗锯齿**：磨砂观感来自半透明填充而非 blur。两轮实测（headless Chromium / playwright）：① 隔离构图（纯色地面 + 半透明填充 + 圆角，A/B 只差一条 `backdrop-filter`）内部平整区**逐像素相同**，差异仅在元素自身抗锯缘外缘——侧栏 **24/96000 像素（0.03%）、最大差 1/255**，气泡 **24/48000、最大差 1**；对照组（同样材质但确实盖住文字）**89.53% 像素不同、最大差 100/255**，说明该测法能看出差异。② 真页 A/B（本机 `dsh web`；A/B = 加回/摘掉这 4 条声明）：把玻璃面内容 `visibility:hidden` 后，气泡 **0/19184 像素（精确恒等）**、侧栏只剩 **0.3%** 且全在板子自身边缘；内容可见时侧栏 **2.81%、最大 16/255**、气泡 **15.17%、最大 64/255**——差异**全部是玻璃面上文字的重抗锯齿**（把地面换成高对比条纹的对照组达 98.28%/99.22%，证明测法有效；侧栏 blur 半径放大 12 倍而板内零变化，说明背后没有可失的结构）。**面积账**（真页 1440×900，4px 栅格取可见模糊面积的并集）：mica 由 **459,760 px² 降到 235,504 px²（−48.8%）**，mica/compat 的模糊面积比由 **4.32× 降到 2.22×**；剩下的最大 mica 独有面是**顶栏 ~95,880 px²（占 21%）**。新增 `tests/glass-css.spec.ts` 锁两条不变量（地面之上的面不得有 blur、覆盖移动内容的必须保留，并核对 composer 板内卡片保持 `backdrop-filter:none` 以免同一片像素读两遍），7 语言 `glass.modeHint` / `glass.help` 与双语 README 补上性能提示（兼容模式 = 稳妥档、清透预设最省）。**有意未做**：顶栏那句「内容从磨砂条下穿过」是本插件自己用负 margin `-95px` 造的（DSH 原版 header 在滚动容器上方、不重叠），退掉它能把顶栏的 blur 也变成静态地面（成本归零、但失去该效果）——留作 issue #13 复测不达标时的第二手。（EN: drop 4 backdrop-filters that painted nothing — the page ground is solid, so blurring it is an identity transform still billed every frame; measured on the live GUI, the frosted fill is pixel-identical with the blur removed (0/19184 with the surface's content hidden) and the only pixels that move are glyph re-antialiasing above the surface, while the sidebar sheet, chat bubbles and the trajectory panel lose a no-op blur and the top bar / composer / menus keep theirs, with a regression test locking both halves and per-language performance notes in the settings row; the visible blurred area drops from 459,760 to 235,504 px², i.e. the mica/compat surface ratio falls from 4.32× to 2.22×）

- **删掉一条永不命中的输入框占位色规则（issue #12）**：`[data-dsh-glass-float] [data-composer-card] textarea::placeholder`（`color-mix(label-primary 45%, transparent)`）从来画不出像素——DSH 的 composer 是 contenteditable，占位提示是 `div[data-composer-placeholder]`，颜色由 DSH 自己的 `--dsw-alias-label-caption` 决定；实测 `[data-composer-card]` 内 textarea 数量在两版 DSH（0.1.2-rc.1、0.1.5-rc.2）都是 **0**。它不生效却在注释里自称 "scheme-adaptive"，是个陷阱：浅色片上 45% 的 `label-primary` 只有 **2.1:1**（深色片 3.2:1），正是 issue #12 里被误读成「玻璃把提示洗掉」的数值。删掉后实测 Latte + 云母下提示色 = Latte caption `#7c7f93` on `#eff1f5` = **3.5:1**；报告人截图里的 2.1:1 来自**官方浅色主题**自己的 caption `#adb2b8` on `#fff`（与 Catppuccin 调色板、与玻璃层都无关）。（EN: drop the unreachable `textarea::placeholder` rule from the glass layer — DSH's composer is a contenteditable + `div[data-composer-placeholder]`, so the rule painted nothing while claiming a scheme-adaptive tint it never applied）

- **Latte 弱标签阶梯补上断言（issue #12 附带发现）**：`tests/palettes.spec.ts` 的 WCAG 下限只跑深色三风味（`DARK_FLAVORS`），Latte 完全没覆盖。实测 Latte 弱标签在 `#eff1f5` 上：primary 7.06 / primary-dimmed 7.06 / secondary 5.53 / tertiary 5.53 / caption **3.49** / dimmed **2.30**。评估过「把 caption 抬到 AA」：bluish-500 `#6c6f85` 只到 4.37:1，要过 4.5 必须用 bluish-600 `#5c5f77`（5.53，正是 secondary/tertiary 的值）→ 会压平两级阶梯；而官方浅色主题自己的 caption 是 `#adb2b8`（2.14:1 on 它自己的纯白输入框），Latte 的总实映射已经比上游强 1.6 倍——按规则 1「拿不出『官方取值在 DSH 下不成立』的证据就不偏离」，**结论：保持现状**，改为落地断言：锁住每个别名的官方步进 + 实测减余量的下限（变浅或压平都会被打回）。（EN: add the missing light-flavour label ladder test — Latte keeps the official step mapping because its caption already beats upstream's own light caption 3.49:1 vs 2.14:1; reaching AA would flatten two ladder levels, so the test locks the ladder instead）

- **覆盖编辑器的值输入改为失焦提交（TT）**：此前值输入受控 + 逐键提交，而「空值 = 删除」→ 想改颜色时逐字符清空会在中途把整行（含正在打字的输入框）卸载、光标丢失；同时**每个字符都会 dispose 并重新注册一次主题**（700 个 token 的表），中间态（如 `#89b4`）还是无效 CSS。现在键名与值都是非受控 + 失焦提交：清空后失焦才删除，打字期间行稳定、主题不再逐键重建；7 语言的 `row.overridesHint` 已同步为「失焦生效」。**有意接受的取舍**：不再「边打边变色」（粘贴完整色值不受影响）、焦点未离开就关弹窗时最后一笔不提交、其它标签页 / settings 文档写入的值需重开弹窗才刷新——三者与既有键名输入完全一致。（EN: the override editor's value field now commits on blur like the key field — clearing a value no longer unmounts the row mid-typing and typing no longer re-registers the theme per keystroke）

- **普通提交现在也有 CI 了**：新增 `.github/workflows/ci.yml`（push main / PR → install + typecheck + build + test，只读权限）。此前只有 `publish.yml`、且只在 `v*` tag 上触发，所以 main 上的提交从来没人验证——`0.5.2` 当天两次发版失败（未声明的幽灵类型依赖、跨测试污染）都是本地恰好过、到 tag 才暴露。（EN: CI now runs on every push to main and on PRs, so regressions no longer wait for a release tag）

- **补了行级组件测试骨架**：引入 `@testing-library/react`（配 `react-dom` 18，与 peer 范围一致），新增 `tests/rows.spec.tsx`：覆盖编辑器（TT 的失焦提交语义、清空后失焦才删、未改动不写入、键名重命名与非 token 键）与玻璃旋钮的 `aria-valuetext`（Z）。两个 row 的依赖都是 props，所以用注入面 fake 渲染，不需要模块全局。（EN: component-level test harness for the settings rows）

## [0.5.2] - 2026-09-15

### 修复

- **自定义 token 覆盖的非法键名不再被静默清除**：`readOverrides()` 现在与 settings 文档走同一个 `sanitizeOverrides`，localStorage 与持久化文档永远同形状——此前键名不以 `--` 开头（例如漏了短横线的 `dsw-static-blue-500`）只存在于 localStorage，hydration 比对时两边不等，走「文档胜出」分支把整份覆盖回写为空，用户刚输入的那行约 300ms 后自行消失。设置行的键名输入改为失焦提交并要求 `--` 前缀（中间态不再被逐键重写成非法键）。（EN: sanitize token overrides on read too — localStorage and the settings document share one shape, so a key typed without the `--` prefix is no longer wiped by the hydration's "document wins" branch）

- **更新检查失败的自动重试真的只重试一次**：此前只要检查失败就排 30s 定时器，重试再失败又排一次——断网时设置行每 30s 打一次宿主路由（宿主失败不缓存，等于每 30s 真打一次 npm），倒计时永不消失。现在每次用户发起的检查只带一次自动重试预算（手动点击复位），并补上倒计时 ticker 在卸载时的 `clearInterval`。（EN: the failure auto-retry now stops after one retry as documented, and the countdown ticker is cleared on unmount）

- **暗色下 success / warn 芯片的标签对比度不足（VV）**：`state-success-tertiary` / `state-warn-tertiary` 是**标签下面的着色表面**（官方 `contextGreen` / `warn-label` 芯片），但 `greenPlan` / `amberPlan` 的 900 步只能混向 `base`，暗色三风味实测标签对为 **3.67/4.37/5.02（success）与 3.18/3.79/4.34（warn）**——既低于 AA，也低于上游官方同对（**5.25 / 5.53**，本次用 `dsw-tokens.json` 实测）。现按 issue #11 的同款机制给 900 步加**混色目标**：暗色混向 `crust` 取 **18%**（扫描 10→30%：14% 过冲到 6.3~9.3、22% 时 Frappé 琥珀只剩 4.54:1，18% 落在上游比值带 4.96~8.30），Latte 保持原样（它的 900 步是浅色芯片配深标签，官方本身 2.09 / 2.58，属上游设计特性）。新增 `tests/palettes.spec.ts` 的 `dark status tint readability (VV)` 两条断言（旧表失败、新表通过）。（EN: repaint the dark success/warn chip tints toward crust — 3.18–4.37:1 before, 4.96–8.30:1 after, matching upstream's ratio band instead of overshooting）

- **玻璃接缝 stamper 的 dispose 契约补严**：`dispose` 能断开 MutationObserver、取消已排的帧，但**已经作为微任务排队的 observer 回调收不回来**——该回调会在 dispose 之后重新排帧并 stamp。加 `disposed` 守卫（`schedule()` 先查）让 dispose 成为终局；同时修掉 `tests/glass-seams.spec.ts` 里的**跨测试污染**（一个用例开了 stamper 从不 dispose、另一个的 `setAttribute` spy 不还原，残留的全局 observer 会去 stamp 后续用例的按钮）——那才是全量 / 干净环境下该用例间歇失败的真正原因。（EN: tighten the seam stamper's dispose contract and fix the cross-test observer/spy leak that made the dispose case flaky）

### 改进

- **设置弹窗玻璃化的 seam 不再依赖宿主构建哈希**：`[class*="VOzbGW_overlay"]`（dsh-client-ui-settings-general 的 CSS Module 哈希，宿主改样式即失效且无声）换成 `:has(> [role="dialog"][aria-modal="true"])`——命中同一个覆盖层元素，键的是稳定的无障碍属性。测试同步改为断言真实属性组合，并断言无 `aria-modal` 的普通 dialog 不被命中。（EN: the settings-dialog glass seam keys off role/aria-modal instead of the host's CSS-module hash）
- **`pnpm changelog:gen -- --write` 不再因缺少 `[Unreleased]` 节中止**：发版会把该节落成版本节，脚本现在在缺失时自动补建在最新版本节之上（此前直接 `exit 1`，而 AGENTS.md 的 SOP 正是让 Agent 跑这条命令）。（EN: the changelog writer recreates the [Unreleased] section instead of aborting after a release consumed it）

- **测试类型检查链路接上（UU）**：`tsconfig.vitest.json` 的注释承诺「src + tests 一起类型检查」，但三条链路都不跑它：`pnpm typecheck` 的 include 只有 `src`、vitest 用 esbuild 转译不做类型检查、CI 只有 install/build/test——4 处既有类型错误因此长期隐形。现在修掉这四处（**不动生产签名**：`builtinPickWins` 是 issue #6 的回归守卫，改在测试内取它的参数类型；`reentrancy` 的 double 用 `as unknown as ThemeSnapshot` 并注明它只建模插件读取的字段；`versions` 用可选链），新增 `pnpm typecheck:tests`，并在 CI 里加 `Typecheck` 步同时跑 `typecheck` 与 `typecheck:tests`（src 侧此前同样从未被检查过——不接 CI 必然再次腐烂）。**接上链路后的第一次 CI 运行就抓到一个真问题**：`state-sync.ts` 从 `@deepseek-ai/dsh-api-remotes/client` 引类型，但该包从未声明——本地能解析只因为 TS 会向上找到工作区父目录的 `node_modules`（幽灵依赖），干净安装直接 `TS2307`。现已补进 devDependencies（仅类型引用，运行时不需要）；`0.5.2` 的 tag 也因此重指到修好后的提交。（EN: wire the test type-check chain — the 4 latent errors are fixed, CI runs both typechecks, and the first run caught an undeclared phantom type dependency）

- **CI 的 pnpm 版本只留一处**：上一批给 `package.json` 加了 `packageManager: pnpm@10.33.3`，而 workflow 里还留着 `version: 10`——两者字符串不等，`pnpm/action-setup` 会直接抛 `Multiple versions of pnpm specified`，**发版会在第二步就失败**（发版前检查时发现）。按官方用法删掉 workflow 的 `version`，pnpm 版本由 `packageManager` 单点决定；AGENTS.md 的故障排查补上了这条坑。（EN: single source of truth for the pnpm version — the workflow no longer duplicates packageManager）

- **无障碍：玻璃旋钮的滑杆补 `aria-valuetext`（Z）**：`<input type="range">` 此前只播报裸数字（「20」）且不带单位。按评估后的**零文案版**补 `aria-valuetext={`${value}${unit}`}` → 屏幕阅读器念「20%」/「14px」，与视力用户所见一致；**不为 3 个旋钮 × 7 语言新增 21 条档位文案**，定性档位名（「中等磨砂」）保留为可选后续，只在真有屏幕阅读器用户反馈时再做。（EN: range knobs announce their unit via aria-valuetext without adding 21 locale strings）

## [0.5.1] - 2026-09-13

### 修复

- **修复深色模式下分段选择器选中项不可读（issue #11）**：设置页三处选中态药丸（代码高亮风格 / 更新渠道 / 玻璃质感模式）标签实测对比度仅 **1.26:1**（Macchiato `#7181b1` on `#63719a`）——暗色蓝梯把该对两端都混在中灰蓝：`state-business-tertiary`(=deepseek-800) 混 base 52%、`state-business-primary`(=deepseek-400) 混 66%，官方暗色的 `#34415b`/`#679efe`(4.6:1) 动态范围被压扁。修复：`blueDarkPlan` 深端（800/900/950）改为朝最深表层 `crust` 混且压到 18%/14%/10%（`generate-palettes.mjs` 新增每步可选混色目标，未指定仍为 base），并按 issue #7 的既有机制把 `state-business-primary` 钉到纯 accent（`deepseek-500`）。改后标签对 tint 为 Frappé 4.60:1 / Macchiato 5.49:1 / Mocha 6.40:1（AA 通过），同 token 兼作填充的开关轨道、焦点环、活动页签也从 3.7:1 提到 6.5~8.9:1；宿主轨迹视图的 `user` 徽标用的是同一对，一并修复。新增 `tests/palettes.spec.ts` 的 `dark blue tint readability (issue #11)` 断言（旧表失败、新表通过）。（EN: repaint the dark blue tint at the deepest surface and pin the business label to the accent — fixes the ~1.26:1 selected-segment text in all three settings rows and the host trajectory badge）

> 待办（同批测量，未纳入本次修复）：`state-success-tertiary` / `state-warn-tertiary` 有同型配对（官方 `contextGreen` / `warn-label` 芯片），当前 3.5~3.8:1，同样可用 crust 目标收尾；Latte 的 business 对为 3.23:1（官方 3.74:1，属上游设计特性）。（2026-09-15 复核：已立为跟踪项 **VV** 并实测——green-500/green-900 = 3.67/4.37/5.02、amber-600/amber-900 = 3.18/3.79/4.34，改 `crust` 目标后预测 ≥5.4；见 `docs/plugin-improvements.md` 六、跟踪表。）

### 改进（设置弹窗玻璃化）

- **设置弹窗内的卡片/选择器统一为玻璃质感**：设置对话框的面板本身早已是玻璃（`--dsh-glass-card-raised` + blur），但面板**内部**的一切都用不透明的抬升表层 token 上色（`bg-module-platform` 用于选择器/步进器/卡片、`bg-layer-3` 用于插件卡片、`bg-layer-2` 用于展开的卡片、侧栏的 nav token 用于弹窗自己的导航），于是四五个设置页里的行读起来像贴在玻璃上的纯色 `#313244` 板子。现在在弹窗作用域内把这几个 token 重新指向「同一阶梯 + 半透明」：卡片保住自己的层级身份（仍比面板高一档），而遮罩的模糊从底下透上来——玻璃叠玻璃，且不需要任何按宿主类名的选择器，插件自带的设置卡片（终端 / Agent 循环 / Subagent / 网页搜索）自动继承。alpha 跟随磨砂旋钮（`--dsh-glass-frost`），深色读阶梯上端（bluish-800/850/750），Latte 读下端（bluish-60/00/100/75），两套实测均正确。新增 `data-dsh-glass-settings` seam（`glass-seams.ts`）与 `tests/glass-seams.spec.ts` 断言。实测（Mocha，frost 20）：面板 `#0c0c13`、卡片 `#20212d`（升一档可见）；Latte：面板 `#c5c6ca`、卡片 `#b6b7ba`。（EN: settings-dialog rows become glass on glass — the raised-surface tokens are re-pointed to translucent mixes of the same ladder step inside the dialog seam, dark and light ladders both）

### 回退

- **撤销 0.5.1-beta.1 的设置 UI 外观统一，恢复旧设计**：该版把三个设置行的分段控件、开关与 "?" 帮助徽标收敛到新的 `src/client/controls.tsx`，并调整了选中态写法、卡片刻度与 placeholder 取值。观感未通过，按要求整体回退——`src/client/controls.tsx` 与 `tests/controls.spec.ts` 删除，`CatppuccinRow` / `UpdateRow` / `glass-row` / `GlassRow.module.css` 恢复原实现（本版这些文件与 `0.5.1-beta.0` 逐字节一致）。issue #11 的深色可读性修复属调色板层，不受影响，仍然生效。（EN: revert the 0.5.1-beta.1 settings-UI unification back to the previous design — the shared controls module is gone and the rows are identical to beta.0; the issue #11 palette fix stays）

## [0.5.0] - 2026-09-07

### 修复（2026-09-07）

- **修复设置行崩溃（React #185，随改进批次引入）**：`overrides` 的 `useSyncExternalStore` getSnapshot 每次返回新对象导致无限重渲染，Catppuccin 设置行崩溃不渲染。新增 `overridesSnapshot()` 稳定引用快照（内容不变时返回同一对象），并加单测锁定。（EN: stable-reference overrides snapshot — fixes the settings-row crash）
- **修复刷新/重启后风味回退（issue #10）**：`theme/change` 监听器内的风味恢复改为微任务延迟执行——原实现同步调用 `theme.setTheme(flavor)` 会重入 `publish()`，导致展示层（ThemePresenter，注册晚于插件）最后应用外层分发携带的过期设置文档快照（dark/system），DOM 回退为官方深色而运行时 preference 仍是风味。延迟后风味的 `setTheme` 成为分发结束后的最后一条事件，展示层最终应用风味；执行时重查 `preference` / `liveBuiltinPick`，用户本会话显式选择的 light/dark 仍优先。新增 `tests/reentrancy.spec.ts` 回归测试（旧代码失败、修复后通过）。（EN: defer flavour restore out of the theme/change dispatch; fixes the stale-snapshot re-apply on refresh/restart）

### 非视觉改进批次（2026-09-06，按 docs/plugin-improvements.md 实施）

> 只实施无视觉判断的改进项；视觉项（预览图/skin 调优等）由视觉模型或人工复核收尾，见 `docs/plugin-improvements.md` 跟踪表。

- **持久化读侧一致性（C/X）**：`persistStateToScope` 写回前比对 snapshot revision——文档在防抖窗口内被外部推进且非本方回显时放弃本地写并重采纳远端状态；UpdateRow 显示「另一窗口已更新，本地改动未保存」横幅。写侧 fencing 仍由 `scope.mutate` 负责，未重复造乐观锁。（EN: read-side durability guard + conflict banner）
- **glass seam stamper 防抖（N）**：MutationObserver 回调按 `requestAnimationFrame` 合批，每帧最多一次 stamp、无变更帧零开销。（EN: rAF-batched seam stamping）
- **glass CSS 懒加载（II）**：`glass.module.css` 不再随 bundle 急切注入——构建脚本生成 `glass-css.gen.ts` 文本，`GlassLayer` 启用时才挂 `<style>`、关闭即移除。（EN: lazy-mounted glass stylesheet）
- **host half 拆分（A）**：update-check 路由迁出 `src/index.ts` 到 `src/update-check/host.ts`（index ≤120 行）。（EN: extracted update-check host module）
- **更新检查增强（H/I/U/V/W）**：`autoCheck` 开关（启动 + 每 6h 自动检查）；渠道 segmented（latest/beta，`selectNewest` 三态 + 按渠道分桶缓存）；错误码细分为 `network.local` / `network.upstream`；失败 30s 后自动重试一次；ETag 条件请求（304 复用缓存）。（EN: auto-check, channel pick, error-code split, one retry, ETag caching）
- **token 覆盖与懒注册（K/JJ/M）**：`overrides` KV 覆盖（CatppuccinRow 折叠编辑器，注册时合并）；主题改懒注册——只注册当前风味、选中时按需注册；`shikiStyle` 二维表（default / italic-comments）+ 选择器。（EN: token overrides, lazy theme registration, shiki style pick）
- **TUI 同步加固（R/S/T）**：owned 文件漂移默认 `.bak` 备份后再写（可选 overwrite/preserve）；`dryRun` 只报告 planned writes；`catppuccin-community/` 子目录 write-if-missing 同步。（EN: backup-on-conflict, dry-run, community themes）
- **契约与迁移（Y）**：`src/state.ts` 新增 `migrate(raw)` 版本迁移入口，`docs/state-migrations.md` 记录约定。（EN: state migration entry + doc）
- **e2e（EE）**：`tests/e2e/update-check.e2e.spec.ts` 用真 cordis + 真 HTTP 服务断言路由契约/渠道/缓存/304/502 与 settings 注册。（EN: real-cordis e2e for the update route）
- **palette 锁定（L）**：`generate-palettes.mjs --pin <sha>` 把上游 commit 写进 `palettes.ts` 头部 `// UPSTREAM_PIN`。（EN: upstream pin flag）
- **国际化与可访问性（CC/DD/J/AA）**：新增 ja/ko/es/fr/de 字典（key 集合同步由 `tests/locales.spec.ts` 锁定）；风味副标题；row 帮助徽标（上游无 tooltip API，原生 title 落地）；glass segmented roving tabindex + 方向键。（EN: 5 new locales, flavour subtitles, help affordance, segmented keyboard nav）
- **DX（GG/HH/KK）**：`CONTRIBUTING.md` 贡献指南；typedoc 生成 `docs/api/`（`pnpm docs:api`）；host 侧构建开 sourcemap 并发布 `*.map`。（EN: contributing guide, typedoc, sourcemaps）

### 持久化重构到官方 settings 机制

> **决策（2026-08-29）**：先发 0.4.3（兼容修复）。0.5.0 重构**非必需**——0.4.3 后插件在 0.1.1-rc.2 与 0.1.2-alpha.1 均正常，自建持久化稳定运行。重构是工程质量优化（少维护一套自建持久化），等 DSH 0.1.2 正式发布、官方 settings 机制稳定后再实施，届时 devDeps 同步对齐并移除 runtime 类型 bridge。
> **进展（2026-09-05）**：调研确认 DSH 0.1.2 尚在 rc 阶段（最新 `0.1.2-rc.1`，2026-09-03 发布，API 已冻结）；rc.1 实际 API 与下列计划有两处出入，已按实际 API 实施：① host 侧 0.1.2 系列**已无独立函数 `installSettingsSection`**（0.1.1-rc.2 还有），改为 provider 方法 `ctx.settings.installSection(owner, ns, schema, entry, hooks)`（optional wiring：settings 服务存在时注册、消失时回退 entry config）；② **`settings.plugin.item` 槽位不存在**——实测 0.1.1-rc.2 与 0.1.2-rc.1 的 slots 表完全一致（`settings.trigger/header/action/close/section/plugins.tab/onboarding/general.item`），原"迁到 plugin.item 卡片槽"可选项作废，设置行继续用 `settings.general.item`。另实测 `dsh-host-apiproxy` 0.1.1-rc.2（最新）的 `settings.describe` 已无 allowlist 过滤，"注册即暴露"成立；0.1.2-rc.1 的 `dsh-client-ui-settings` 不再从 `dsh-client-runtime` 导入类型（自含 `settings-contract.ts`），renderer 自带 `ctx.slots` merge，故 runtime 类型 bridge 已随 devDeps 对齐一并移除。

- **持久化迁移到官方 settings 机制**：删除自建的 `/catppuccin/state` GET/PUT 路由、`src/host-state.ts`、`src/state-sync.ts` 的 fetch 包装与 `$DSH_HOME/catppuccin-state.json` 的写入，改用官方文档持久化（同样跨 Desktop 重启）。
  - host 侧 `src/index.ts` 用 `ctx.inject(['settings'])` + `ctx.settings.installSection(ctx, 'catppuccin', schema, defaultSettingsSection, hooks)` 注册命名空间（optional wiring：无 settings 服务的 profile 静默跳过、保持 composition 纯值运行）；顶部的过时 allowlist 注释同步更新为"注册即暴露"事实。schema 定义在 `src/settings-catppuccin.ts`（schemastery，与 `src/state.ts` 共享 `CatppuccinSettingsSection` 契约）。
  - client 侧 `src/client/index.ts` 改用 `ctx.settingsScope.bind({ namespace: 'catppuccin' })`：scope 快照就绪且 `mode === 'host'` 时以文档为源 hydrate（回声写跳过、外部编辑文档胜出），`user` 层为空时把本会话 localStorage 选择推入文档；`snapshot status` 非 `ready`/mode 非 `host` 时降级 localStorage 兜底（仅影响跨重启持久）。
  - **老用户迁移**：`src/legacy-state.ts` 只读 `catppuccin-state.json`，启动时若文档尚无 user 层则一次性 `settings.update` 迁入；文件保留作回退，迁移失败非致命。
  - 玻璃质感层持久化同样改走 settings 文档（`glass-layer.ts` 的 `getRemoteState`/`applyRemote` 接口不变，`src/client/state-sync.ts` 改为 scope mutate 全量原子写 + debounce）。
  - **devDeps 对齐 `0.1.2-rc.1`**：cordis `^4.0.1 → ^4.0.2`，全部 `dsh-client-*` / `dsh-*` 类型包升 `0.1.2-rc.1`（含 dsh-brand/dsh-session/dsh-scope/dsh-invariants peer），新增 `@deepseek-ai/dsh-settings` + `@deepseek-ai/schemastery` 类型依赖，删除 `@deepseek-ai/dsh-client-runtime`（0.1.2 起移除，类型 bridge 不再需要）；`tsdown.config.ts` 的 lib external 修正为 `@deepseek-ai/schemastery`（原名写错导致被打进 host bundle，50.6kB→21.0kB）。
- **测试同步**：`tests/host-state.spec.ts` → `tests/legacy-state.spec.ts`（只读迁移源）；`tests/client.spec.ts` 的 fetch 包装测试 → `isScopeUsable` / `durableStateFromSnapshot` / `persistStateToScope`（mutate ops 全量原子写）/ debounce；`tests/state.spec.ts` 移除 `STATE_ROUTE_PATH` 断言、新增 settings section 辅助函数测试（共 91 个测试全绿）。

## [0.4.3] - 2026-08-29

### 修复

- **兼容 DSH 0.1.2-alpha.1（dsh-client-runtime 移除）**：0.1.2 起
  `@deepseek-ai/dsh-client-runtime` 包被整体移除（slots 职责并入
  `dsh-client-ui-renderer`，新版 web 组合不再提供该服务）。插件 client 半区
  的 `dsh.client.inject` 声明了已不存在的 runtime 服务，会导致 client 半区
  永久等待、主题与设置行不生效。现将 inject 目标改为
  `@deepseek-ai/dsh-client-ui-renderer`，`ClientContext` 类型改从
  `@deepseek-ai/cordis` 导入，并移除 tsdown 中对已废弃 runtime /client 的
  external 豁免（该豁免现会生成运行时无法解析的 require，改为由纯度门在
  构建期拦截）；devDeps 的 client 类型包从 `^0.1.0-rc.6` 升至
  `^0.1.1-rc.2`（npm 当前可用版本，0.1.2 发布后再对齐）。
  **注（临时类型 bridge）**：devDeps 中保留
  `@deepseek-ai/dsh-client-runtime@^0.1.1-rc.2` 仅用于类型编译——0.1.1-rc.2
  的 `dsh-client-ui-settings` / `ctx.slots` Context merge 仍由该包类型提供
  （`dsh-client-ui-renderer` 自带 `ctx.slots` merge 是从 0.1.2 才开始的）。
  运行时不注入该服务，0.1.2 发布、devDeps 对齐后即可移除。
- 其余 API 经验证兼容：ThemeRuntime（register/setTheme/getTheme/theme/change）、
  `--dsw-*`/`--dsw-alias-*`/`--shiki-*` token（名称与值零差异）、webServer
  路由注册、slots/locale 注册、`settings.general.item` 槽位、React 18、
  `dsh plugin --profile` CLI、cordis 4.0.1 均未变化。

## [0.4.2] - 2026-08-29

### 修复

- **玻璃态下侧边栏 fixed 弹层被裁切的通用修复**：`sidebarCol` 上的
  `backdrop-filter` 会把 `position: fixed` 后代（任意插件从 `sidebar.*`
  slot 弹出的菜单 / dialog / 看板，例如 dsh-cost-dashboard 的
  `.cd-footerPanel`/`.cd-footerMask` 纯 div 弹层）的 containing block 从
  视口改签到侧边栏列，再被列上 `overflow: hidden` 裁成窄条，遮罩也只盖
  侧边栏。原有 `:has([role='dialog'])` 守卫只认 `role='dialog'`，对这种
  无角色的弹层完全漏防。
- **实现**：把磨砂填充 + `backdrop-filter` 模糊 + 顶缘高光从列元素移到
  `[class*='sidebarCol']::before` 子层（`z-index: -1; pointer-events: none`）。
  伪元素不是内容后代的祖先，其背景模糊只作用于页面背景，对任何
  fixed 后代**不再构成 containing block**——结构性根治，无需逐插件
  写选择器，所有从侧边栏 slot 弹 fixed 层的插件一次性恢复视口锚定。
  删除已失效的 `:has([role='dialog'])` 守卫。视觉（玻璃片填充/描边/
  圆角/阴影/折叠 rail）保持不变，关闭玻璃态完全还原原生界面。

## [0.4.1] - 2026-08-28

### 修复

- 深色 flavor（Frappé / Macchiato / Mocha）下弱层级文字（
  `label-secondary` / `label-tertiary` / `caption` / `dimmed`）对比度过低，
  改指更亮的调色档位，采纳 PR #8 的 `label-primary-dimmed` 层级改进
  （bluish-100 → bluish-75, subtext1）。(closes #7)
- 设置页文档显式指定 light/dark 时，刷新 / 重启后主题丢失（issue #6）。

## [0.4.0] - 2026-08-25

### 新增

- **dsh-TUI 终端主题支持**：一条命令装进 dsh-tui profile，启动时自动把
  四套 Catppuccin 主题同步到 `~/.dsh-tui/themes/`，`/theme` 切换；Web 端
  启动时若目录已存在也会自动同步。
- 新增 dsh-TUI 四风味主题静态资产（`themes/`）。

## [0.3.1] - 2026-08-23

### 变更

- 移除设置页的自动检查更新，回到纯手动按钮，避免未经用户动作的网络请求。

## [0.3.0] - 2026-08-23

### 新增

- 玻璃质感新增**清透 / 标准 / 磨砂**三档一键预设（滑条保留微调）。
- 设置行挂载时自动静默检查一次插件更新；Host 侧检查结果缓存 5 分钟。
- 关闭 Catppuccin 风味时**还原用户原有的官方主题偏好**，不再强制重置为
  「跟随系统」。

### 其他

- 玻璃旋钮默认值单一来源化（从 `DEFAULT_GLASS` 派生）。

## [0.2.11] - 2026-08-23

### 修复

- 收窄 `[class*='bubble']` 玻璃选择器到会话容器内，避免误伤第三方
  widget（如 dsh-whale-widget 的 `.dshwv-bubble`）。

## [0.2.10] - 2026-08-23

### 修复

- Latte 下「预览版」徽章文字对比度过低。(closes #4)

## [0.2.9] - 2026-08-22

### 修复

- 切换模型后 Catppuccin 主题被重置的问题。(closes #3)

## [0.2.8] - 2026-08-21

### 修复

- 顶栏圆角处玻璃轮廓线断开。(closes #2)

### 新增

- 语法高亮对齐 Catppuccin 官方配色（amber-400 改回 peach 系）。

## [0.2.7] - 2026-08-18

### 修复

- **DSH Desktop 持久化**：主题 / 玻璃偏好持久化到 DSH home 文件，
  桌面端随机端口重启不再回退默认配色。
- 更新检查适配 DSH Desktop，升级命令随环境自动变化。

### 新增

- 模型选择弹层分组名改为贴合文字的胶囊标签（参考新会话按钮），弹层背景
  提浓至主题 layer-2 @70%，提升可读性（原约 9% 近透明）。

## [0.2.5] - 2026-08-17

### 新增

- **玻璃质感皮肤**（云母 / 兼容双模式，模糊度 / 磨砂度 / 背景亮度可调），
  配色自动跟随当前 Catppuccin 主题。
- **检查 Catppuccin 插件更新**设置行：查询 npm dist-tags，通道感知
  （latest/beta）semver 比较并给出可复制升级命令。
- 页面边缘渐变模糊、气泡与新会话按钮玻璃化、折叠栏悬浮玻璃等玻璃细节。

### 修复

- 统计行宽度恢复为受容器约束，修复玻璃模式下溢出检测失效导致悬浮全文
  tooltip 不出现的问题。

## [0.2.0] - 2026-08-16

### 新增

- Catppuccin 四个风味主题（Latte / Frappé / Macchiato / Mocha）接入官方
  主题系统，全界面配色覆盖。
- 四主题斜切合成预览图。

## [0.1.x] - 2026-08-15/16

### 修复

- 0.1.2：将 `schemastery` 移入 dependencies（runtime 使用，
  devDependencies 在安装时不生效）。
- 0.1.1：补充 repository / homepage / keywords 字段。

[0.6.3-beta.2]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.3-beta.1...v0.6.3-beta.2
[0.6.3-beta.1]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.3-beta.0...v0.6.3-beta.1
[0.6.3-beta.3]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.3-beta.2...v0.6.3-beta.3
[0.6.3-beta.2]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.3-beta.1...v0.6.3-beta.2
[Unreleased]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.6-beta.0...HEAD
[0.6.4]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.3...v0.6.4
[0.6.3-beta.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.2...v0.6.3-beta.0
[0.6.2]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.1...v0.6.2
[0.6.2-beta.2]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.2-beta.1...v0.6.2-beta.2
[0.6.2-beta.1]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.2-beta.0...v0.6.2-beta.1
[0.6.2-beta.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.1...v0.6.2-beta.0
[0.6.1]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.9...v0.6.0
[0.5.9]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.8...v0.5.9
[0.5.8]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.7...v0.5.8
[0.5.7]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.6...v0.5.7
[0.5.6]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.5...v0.5.6
[0.5.6-beta.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.5...v0.5.6-beta.0
[0.5.5]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.4...v0.5.5
[0.5.4]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.3...v0.5.4
[0.5.3]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.4.3...v0.5.0
[0.4.2]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.3.1...v0.4.0
[0.3.1]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.2.11...v0.3.0
[0.2.11]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.2.10...v0.2.11
[0.2.10]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.2.9...v0.2.10
[0.2.9]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.2.8...v0.2.9
[0.2.8]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.2.7...v0.2.8
[0.2.7]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.2.5...v0.2.7
[0.2.5]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.2.0...v0.2.5
[0.2.0]: https://github.com/NoNameLeGo/dsh-catppuccin-theme/compare/v0.1.2...v0.2.0