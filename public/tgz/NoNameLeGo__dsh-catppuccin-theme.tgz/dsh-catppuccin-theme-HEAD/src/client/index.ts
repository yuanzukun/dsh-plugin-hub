/**
 * Catppuccin themes for the DeepSeek Harness web GUI — browser half.
 *
 * Registers the four Catppuccin flavours (Latte light / Frappé, Macchiato,
 * Mocha dark) into the official ThemeRuntime, so they become selectable
 * themes whose --dsw-* token overrides fully remap the UI palette. The
 * official Appearance row persists only the built-in light/dark/system
 * preferences, so this plugin also owns a settings row ("Catppuccin") that
 * lists the four flavours; selecting one switches the theme and persists the
 * flavour.
 *
 * Persistence is two-tier since 0.5.0. The choice lives in two stores:
 *  - localStorage keys (`dsh.catppuccin.*`) — the in-browser cache: instant
 *    restore at boot, the cross-tab `storage` event bus, and the fallback
 *    when the settings transport is unavailable;
 *  - the official settings seam (registered/declared by the Host half in
 *    `src/index.ts`) — the source of truth, bound here through
 *    `createDurableScope`, which adapts whichever seam the host serves
 *    (`ctx.settingsScope` up to 0.1.6-alpha.2, `ctx.configForms` from
 *    0.1.7-alpha.1 — see `src/client/state-sync.ts`). It exists because
 *    localStorage is per-browser and per-origin while the DSH home is the
 *    machine-wide truth (full rationale in `src/state.ts`). The pre-0.5.0
 *    Host file + `/catppuccin/state` route are gone — the Host migrates the
 *    old file into the store once.
 * At boot the plugin fast-applies localStorage, then hydrates from the scope
 * snapshot once it resolves and mirrors it back into localStorage; if the
 * document holds nothing while this browser session already chose something,
 * that choice is pushed to the document. Every user change is written to
 * localStorage immediately and pushed to the scope (debounced) so it
 * survives the next Desktop restart. Without a usable scope (memory mode /
 * absent transport) everything degrades to localStorage alone. The debounced
 * write is read-side guarded (item C/X): a flush whose base revision the
 * document has moved past abandons the stale write, re-adopts the remote
 * state, and tells the update row "另一窗口已更新，本地改动未保存".
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type { ThemeRuntime, ThemeTokens } from '@deepseek-ai/dsh-client-ui-theme/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the renderer's Context merge (ctx.slots) — since DSH
// 0.1.2 the slots registry lives in dsh-client-ui-renderer (the old
// dsh-client-runtime package is gone).
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
// Type-only: pulls the settings-surface SlotMap merge (settings.general.item)
// and, on 0.1.7+, the configForms Context merge the durable scope binds.
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { CatppuccinRowInjected } from './CatppuccinRow.tsx'
import { CatppuccinDetailCard, type CatppuccinDetailCardInjected } from './detail-card.tsx'
import { CatppuccinSettingsPage, type CatppuccinSettingsPageInjected } from './settings-section.tsx'
import { de, en, es, fr, ja, ko, zh, type CatppuccinKey } from './locales.ts'
import { CATPPUCCIN_FLAVORS, type CatppuccinFlavorId, type CatppuccinFlavorInfo } from './palettes.ts'
import { clearBootPalette } from './boot-palette.ts'
import { SHIKI_TOKENS } from './shiki-tokens.ts'
import { GlassLayer } from './glass/glass-layer.ts'
import type { GlassRowInjected } from './glass/glass-row.tsx'
import type { UpdateRowInjected } from './UpdateRow.tsx'
import type { UpdateCheckPayload } from '../update-check.ts'
import { PACKAGE_NAME, UPDATE_CHECK_CLIENT_TIMEOUT_MS, UPDATE_ROUTE_PATH } from '../update-check.ts'
import { tolerantRegistration } from '../registration-tolerance.ts'
import {
  CATPPUCCIN_ENTRY_ID,
  DEFAULT_AUTO_CHECK,
  DEFAULT_SHIKI_STYLE,
  DEFAULT_UPDATE_CHANNEL,
  hasUnpersistableOverrides,
  isDefaultState,
  replayLocalChanges,
  sanitizeOverrides,
  settingsSectionFromState,
  settingsSectionsEqual,
  STATE_VERSION,
  type CatppuccinSettingsSection,
  type CatppuccinState,
  type FlavorValue,
  type ShikiStyle,
  type UpdateChannel,
} from '../state.ts'
import {
  createDurableScope,
  cancelDurablePersist,
  createBaseRevisionTracker,
  durableStateFromSnapshot,
  isScopeUsable,
  persistStateToScope,
  scheduleDurablePersist,
} from './state-sync.ts'
// The glass stylesheet is intentionally NOT imported here: it ships as the
// generated `GLASS_CSS_TEXT` string (`glass-css.gen.ts`, built by
// scripts/gen-glass-css.mjs) and `GlassLayer` mounts/removes the <style>
// tag on enable/disable — item II (lazy glass CSS).

/** Locale namespace owned by this plugin. */
export const NS = 'catppuccin'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The Catppuccin settings row's copy. */
    catppuccin: CatppuccinKey
  }
}

/** localStorage key carrying the persisted flavour choice. */
export const FLAVOR_STORAGE_KEY = 'dsh.catppuccin.flavor'

/** localStorage key recording the last built-in theme preference. */
export const RESTORE_STORAGE_KEY = 'dsh.catppuccin.restore'

/** localStorage key carrying the auto-check update preference (item H). */
export const AUTO_CHECK_KEY = 'dsh.catppuccin.autoCheck'

/** localStorage key carrying the update channel preference (item I). */
export const UPDATE_CHANNEL_KEY = 'dsh.catppuccin.updateChannel'

/** localStorage key carrying the user token overrides JSON (item K). */
export const OVERRIDES_KEY = 'dsh.catppuccin.overrides'

/** localStorage key carrying the shiki style preference (item M). */
export const SHIKI_STYLE_KEY = 'dsh.catppuccin.shikiStyle'

/** Accepted flavour values — the four registered theme ids plus `off`. These
 *  MUST stay in sync with the registered themes (guarded by
 *  tests/palettes.spec.ts) because the persisted value is the theme id. */
export const CATPPUCCIN_FLAVOR_VALUES = [
  ...CATPPUCCIN_FLAVORS.map((f) => f.themeId),
  'off',
] as const

/** `off` means: fall back to the official theme (default). */
export type FlavorChoice = (typeof CATPPUCCIN_FLAVOR_VALUES)[number]

/** The flavour whose themeId this is, or `off`. */
export function flavorFromThemeId(themeId: string): FlavorChoice {
  return CATPPUCCIN_FLAVORS.some((f) => f.themeId === themeId) ? themeId as FlavorChoice : 'off'
}

/** The flavour registered for a theme id, or undefined when not a Catppuccin theme. */
export function flavorInfo(themeId: string): CatppuccinFlavorInfo | undefined {
  return CATPPUCCIN_FLAVORS.find((f) => f.themeId === themeId)
}

/** Read the persisted flavour (absent / unknown values mean the default `off`). */
export function readFlavor(): FlavorChoice {
  try {
    const raw = localStorage.getItem(FLAVOR_STORAGE_KEY)
    return raw !== null && (CATPPUCCIN_FLAVOR_VALUES as readonly string[]).includes(raw)
      ? raw as FlavorChoice
      : 'off'
  } catch {
    return 'off'
  }
}

/** Whether localStorage carries an EXPLICIT `off` flavour choice.
 *
 * `readFlavor()` maps both "no value" and "off" to `off`, and the two are not
 * the same thing: an absent value only means THIS browser/origin never chose
 * (a first visit, cleared site data, or a second Desktop instance that landed
 * on the next free loopback port), while the durable store — which may
 * legitimately hold a flavour picked elsewhere — is machine-wide. Only a
 * literal `off` in storage proves the user (or another window) actually turned
 * the flavour off, which is the case the cross-tab restore must act on
 * (audit F4). */
export function readExplicitFlavorOff(): boolean {
  try {
    return localStorage.getItem(FLAVOR_STORAGE_KEY) === 'off'
  } catch {
    return false
  }
}

/** Persist the flavour choice (storage failures keep the in-memory state). */
export function writeFlavor(choice: FlavorChoice): void {
  try {
    localStorage.setItem(FLAVOR_STORAGE_KEY, choice)
  } catch {
    /* in-memory state still applies for this tab */
  }
}

/** Remember a built-in preference (system/light/dark) whenever the runtime is
 *  not on a Catppuccin flavour, so switching the plugin off restores the
 *  user's pre-plugin choice instead of dropping them onto 'system'. The boot
 *  preference is the settings-document value, so this survives Desktop's
 *  per-launch port churn without joining the durable state schema. */
export function rememberBuiltinPreference(preference: string): void {
  if ((CATPPUCCIN_FLAVOR_VALUES as readonly string[]).includes(preference)) return
  try {
    localStorage.setItem(RESTORE_STORAGE_KEY, preference)
  } catch {
    /* nothing to restore later — 'off' falls back to 'system' */
  }
}

/** The preference to restore when turning the flavour off (default: system). */
export function readRestoredPreference(): 'system' | 'light' | 'dark' {
  try {
    const raw = localStorage.getItem(RESTORE_STORAGE_KEY)
    return raw === 'light' || raw === 'dark' ? raw : 'system'
  } catch {
    return 'system'
  }
}

/** Read the persisted auto-check flag (absent means the shipped default: on). */
export function readAutoCheck(): boolean {
  try {
    const raw = localStorage.getItem(AUTO_CHECK_KEY)
    return raw === null ? DEFAULT_AUTO_CHECK : raw === 'true'
  } catch {
    return DEFAULT_AUTO_CHECK
  }
}

/** Persist the auto-check flag. */
export function writeAutoCheck(value: boolean): void {
  try {
    localStorage.setItem(AUTO_CHECK_KEY, String(value))
  } catch {
    /* in-memory state still applies */
  }
}

/** Read the persisted update channel (absent means `latest`). */
export function readUpdateChannel(): UpdateChannel {
  try {
    return localStorage.getItem(UPDATE_CHANNEL_KEY) === 'beta' ? 'beta' : DEFAULT_UPDATE_CHANNEL
  } catch {
    return DEFAULT_UPDATE_CHANNEL
  }
}

/** Persist the update channel. */
export function writeUpdateChannel(value: UpdateChannel): void {
  try {
    localStorage.setItem(UPDATE_CHANNEL_KEY, value)
  } catch {
    /* in-memory state still applies */
  }
}

/** Read the persisted token overrides (unparseable/absent → empty map).
 *
 * Sanitized on read (`sanitizeOverrides`, the same guard the settings document
 * goes through) so localStorage and the durable section always have the SAME
 * shape. Without it a key that is not a `--` token (e.g. `dsw-static-blue-500`
 * typed without the dashes) lives in localStorage only: the hydration compares
 * the two shapes, sees a difference, and "the document wins" overwrites the
 * entry — the user's row vanished a debounce-beat after it was typed. */
export function readOverrides(): Record<string, string> {
  try {
    const raw = localStorage.getItem(OVERRIDES_KEY)
    if (raw === null) return {}
    return sanitizeOverrides(JSON.parse(raw))
  } catch {
    return {}
  }
}

/** Persist the token overrides (storage failures keep the in-memory state). */
export function writeOverrides(value: Record<string, string>): void {
  try {
    localStorage.setItem(OVERRIDES_KEY, JSON.stringify(value))
  } catch {
    /* in-memory state still applies */
  }
}

let overridesSnapshotCache: Record<string, string> | null = null

/** Stable-reference snapshot of the token overrides for `useSyncExternalStore`.
 * `readOverrides()` parses localStorage and returns a NEW object per call —
 * a React store whose getSnapshot returns a fresh reference every time loops
 * forever ("Maximum update depth exceeded") and the settings row crashes.
 * This accessor returns the SAME object while the persisted map is unchanged
 * and swaps only when the content actually differs. */
export function overridesSnapshot(): Record<string, string> {
  const next = readOverrides()
  const cached = overridesSnapshotCache
  if (cached !== null && JSON.stringify(cached) === JSON.stringify(next)) return cached
  overridesSnapshotCache = next
  return next
}

/** Read the persisted shiki style (absent means the shipped default). */
export function readShikiStyle(): ShikiStyle {
  try {
    return localStorage.getItem(SHIKI_STYLE_KEY) === 'italic-comments' ? 'italic-comments' : DEFAULT_SHIKI_STYLE
  } catch {
    return DEFAULT_SHIKI_STYLE
  }
}

/** Persist the shiki style. */
export function writeShikiStyle(value: ShikiStyle): void {
  try {
    localStorage.setItem(SHIKI_STYLE_KEY, value)
  } catch {
    /* in-memory state still applies */
  }
}

/**
 * Does this host ship the menu blur that makes a translucent menu surface work?
 *
 * `--dsw-specific-menu` only became translucent together with the blur: upstream
 * 0.1.7-alpha.1 changed it from `var(--dsw-alias-bg-layer-3)` to a literal
 * 58%/50% neutral AND introduced `--dsw-menu-backdrop-filter: blur(40px)
 * saturate(150%)` in the same release (checked against the 0.1.6-alpha.1 tag,
 * which still has the opaque ladder step and no blur token). On an older host —
 * `latest` is still the 0.1.5 line — the same fill would be *plain*
 * transparency: the transcript would show through the menu with nothing to
 * soften it, and the token also paints panels that carry text (queue dock, todo
 * panel, goal bar, job list, stat dialog, …).
 *
 * Read through <body>'s computed style, where ui-theme declares both tokens.
 * `--dsw-mask-blur` is probed first as a sanity check: it exists in every host
 * we support, so an empty read means the theme stylesheet is not in the cascade
 * yet (or the environment exposes no computed styles). Answering "false" then
 * is the safe side — the opaque fill is correct for every host that predates
 * the blur.
 */
export function hostHasMenuBlur(): boolean {
  if (typeof getComputedStyle !== 'function') return false
  const body = document.body
  if (body === null) return false
  const styles = getComputedStyle(body)
  if (styles.getPropertyValue('--dsw-mask-blur').trim() === '') return false
  return styles.getPropertyValue('--dsw-menu-backdrop-filter').trim() !== ''
}

/**
 * Token patch for `--dsw-specific-menu`: the flavour's translucent fill stands
 * where the host declares the matching blur (the value lives in palettes.ts),
 * and the opaque pre-0.1.7 ladder step is injected everywhere else. Applied
 * BEFORE the user overrides, so an explicit `--dsw-specific-menu` in the
 * overrides editor still wins.
 */
export function menuSurfaceFor(hostHasBlur: boolean): Record<string, string> {
  return hostHasBlur ? {} : { '--dsw-specific-menu': 'var(--dsw-alias-bg-layer-3)' }
}

/** Built-in preferences the Appearance row can explicitly pick. */
const BUILTIN_PREFERENCES = ['light', 'dark', 'system'] as const
type BuiltinPreference = (typeof BUILTIN_PREFERENCES)[number]

function isBuiltinPreference(value: string): value is BuiltinPreference {
  return (BUILTIN_PREFERENCES as readonly string[]).includes(value)
}

/** Whether an observed built-in preference wins over the persisted flavour.
 *  Only a light/dark value the user explicitly picked in THIS session — the
 *  recorded `liveBuiltinPick` from the setTheme wrapper — wins. Values adopted
 *  from the settings document at boot/reload (`livePick` null) never win
 *  (issue #6: a doc persisted as `ui-theme.preference: light` was mistaken for
 *  a user choice and buried the flavour on every refresh/restart), and
 *  "system" never wins: while a flavour is on, the Catppuccin row is the
 *  active controller and the Appearance row must not bury the persisted
 *  choice. A user's explicit light/dark pick still wins immediately (matching
 *  livePick) and choosing "off" in the Catppuccin row restores it. */
export function builtinPickWins(
  preference: string,
  livePick: BuiltinPreference | null,
): boolean {
  if (preference !== 'light' && preference !== 'dark') return false
  return preference === livePick
}

/** Required services: slots + locale (settings rows) and theme (register +
 *  switch). The durable settings transport is NOT a hard dependency: which
 *  service provides it depends on the host version (issue #15 — 0.1.7-alpha.1
 *  replaced `settingsScope` with `configForms`), so `createDurableScope`
 *  binds whichever one appears through its own optional injections. Listing
 *  either name here would leave the plugin permanently pending on the other
 *  half of the installed base. */
export const inject = ['slots', 'locale', 'theme']

/**
 * Register the Catppuccin dictionaries, the flavour themes (lazy — item JJ:
 * only the active flavour is registered, the rest on first selection), and
 * the settings rows.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  // Bilingual balance is enforced by the typed register call (zh + en);
  // ja/ko/es/fr/de ride the untyped language-pack form and are registered
  // as selectable languages (fallback chain → en) so the dictionaries are
  // reachable without an external language pack (item CC).
  //
  // Every call rides `tolerantRegistration` (issue #23): a peer language pack
  // (dsh-locale-pack, …) that already owns a BCP 47 id makes `addLanguage`
  // throw `locale "ja" is already registered`, and a raw throw here fails
  // THIS entry → the whole web boot aborts → the desktop's crash rescue
  // disables every third-party plugin. A skipped registration costs nothing:
  // our dictionaries still land (they register into our OWN namespace), and
  // the id collision only means the peer's language entry already stands.
  ctx.effect(() => {
    const disposers = [
      tolerantRegistration(() => ctx.locale.register(NS, { zh, en })),
      tolerantRegistration(() => ctx.locale.register(NS, 'ja', ja)),
      tolerantRegistration(() => ctx.locale.register(NS, 'ko', ko)),
      tolerantRegistration(() => ctx.locale.register(NS, 'es', es)),
      tolerantRegistration(() => ctx.locale.register(NS, 'fr', fr)),
      tolerantRegistration(() => ctx.locale.register(NS, 'de', de)),
      tolerantRegistration(() => ctx.locale.addLanguage({ id: 'ja', label: '日本語', fallback: 'en' })),
      tolerantRegistration(() => ctx.locale.addLanguage({ id: 'ko', label: '한국어', fallback: 'en' })),
      tolerantRegistration(() => ctx.locale.addLanguage({ id: 'es', label: 'Español', fallback: 'en' })),
      tolerantRegistration(() => ctx.locale.addLanguage({ id: 'fr', label: 'Français', fallback: 'en' })),
      tolerantRegistration(() => ctx.locale.addLanguage({ id: 'de', label: 'Deutsch', fallback: 'en' })),
    ]
    return () => {
      for (const dispose of disposers) dispose()
    }
  }, 'catppuccin: dictionaries')

  const theme = ctx.get('theme') as ThemeRuntime

  // Lazy theme registration (item JJ): at most the flavour currently in use
  // is registered; selecting a flavour registers it on demand and the fiber
  // disposer releases every registration. Overrides (item K) and the shiki
  // style (item M) are read at registration time, so a preference change
  // re-registers the active flavour with the merged tokens.
  const themeDisposers = new Map<string, () => void>()
  const registerThemeFor = (flavor: CatppuccinFlavorInfo): void => {
    if (themeDisposers.has(flavor.themeId)) return
    // Flavour id for the shiki token lookup: themeId is "catppuccin-latte"
    // → key is "latte".
    const flavorId = flavor.themeId.replace('catppuccin-', '') as CatppuccinFlavorId
    const shiki = SHIKI_TOKENS[flavorId][readShikiStyle()]
    // Tolerant (issue #23): `theme.register` throws `theme "…" is already
    // registered` when another instance of this plugin owns the id (a
    // duplicate install). One reachable path runs it synchronously
    // (applyScopeSnapshot → reapplyThemePrefs, inside the boot effect), so a
    // raw throw could fail the entry; the others (the deferred restore
    // microtask, the storage event) would turn into uncaught errors. A skip
    // is right either way: the theme exists (the peer's copy), `setTheme`
    // below still works, and the no-op disposer memoizes the skip so we do
    // not re-attempt on every override change.
    const disposer = tolerantRegistration(() => theme.register({
      id: flavor.themeId,
      colorScheme: flavor.colorScheme,
      tokens: {
        ...flavor.tokens,
        ...shiki,
        // Host-shape patch (0.1.7 vs the 0.1.5 latest line): keep the menu
        // surface readable on hosts without the menu blur. Below the user
        // overrides on purpose — see menuSurfaceFor().
        ...menuSurfaceFor(hostHasMenuBlur()),
        ...readOverrides(),
      } as ThemeTokens,
    }))
    themeDisposers.set(flavor.themeId, disposer)
  }
  const ensureThemeRegistered = (themeId: string): void => {
    const flavor = flavorInfo(themeId)
    if (flavor !== undefined) registerThemeFor(flavor)
  }
  const disposeThemeRegistrations = (): void => {
    for (const dispose of themeDisposers.values()) dispose()
    themeDisposers.clear()
  }
  ctx.effect(() => disposeThemeRegistrations, 'catppuccin: flavour theme disposers')

  // The glass layer: a toggleable glassmorphism skin on top of the Catppuccin
  // themes. It owns its lifecycle (enable flag + knobs persist in
  // localStorage as the in-browser cache; the durable copy is the settings
  // document hydrated/pushed below; every effect is released with this fiber).
  // It is created before the boot-restore effect so hydration can overlay the
  // persisted glass state onto the layer.
  const glass = new GlassLayer(ctx)

  // The official settings transport for the Catppuccin durable state. Which
  // seam it is depends on the host version (0.1.7-alpha.1 replaced the
  // `settingsScope` namespace binding with the `configForms` entry form), so
  // the facade picks whichever service the host provides and never blocks
  // this fiber on it. The document is the source of truth; the scope derives
  // from the shared mirror and never blocks on the transport.
  const scope = createDurableScope(ctx)

  // The current durable snapshot: flavour from the localStorage cache (the
  // authoritative write target of the settings row) plus the glass layer's
  // remote state and the preference fields. Passed to the debounced scope
  // persist by reference so the flush always captures the freshest values.
  const buildLocalState = (): CatppuccinState => ({
    version: STATE_VERSION,
    // `FlavorChoice` widens to `string` (palettes carry `themeId: string`), but
    // the runtime value is always one of the four theme ids or `off` — the
    // same set as `FlavorValue`, guarded by tests/state.spec.ts.
    flavor: readFlavor() as FlavorValue,
    glass: glass.getRemoteState(),
    autoCheck: readAutoCheck(),
    updateChannel: readUpdateChannel(),
    overrides: readOverrides(),
    shikiStyle: readShikiStyle(),
  })

  // Preference pub/sub: the settings rows read/write autoCheck, channel,
  // overrides and shikiStyle through localStorage; any change re-renders the
  // rows (emitPrefs) and the conflict counter feeds the update row's
  // "另一窗口已更新" banner (item X).
  const prefsListeners = new Set<() => void>()
  const emitPrefs = (): void => {
    for (const listener of prefsListeners) listener()
  }
  let conflictCount = 0
  const conflictListeners = new Set<() => void>()
  const emitConflict = (): void => {
    conflictCount += 1
    for (const listener of conflictListeners) listener()
  }

  // Re-register the active flavour after an override/shiki-style change so
  // the new token mix applies (the disposed registration is replaced by one
  // carrying the merged overrides).
  //
  // Issue #31: this used to dispose EVERY registration and then re-register the
  // active one. The ThemeRuntime's disposer resets `preference` to its default
  // when the disposed theme is the ACTIVE one ("Disposing the theme backing the
  // active preference resets the preference to the default", ui-theme
  // `register()`), so the whole UI dropped to the official theme and only a
  // deferred microtask brought the flavour back — one dropped microtask and the
  // user's flavour was gone while the row still showed it. Now only the active
  // flavour is recycled, and the preference is put back in the SAME synchronous
  // block, so no observer can read the intermediate `system`.
  const reapplyThemePrefs = (): void => {
    const active = theme.getTheme().preference
    const flavor = flavorInfo(active)
    if (flavor === undefined) return
    const dispose = themeDisposers.get(flavor.themeId)
    if (dispose === undefined) return
    themeDisposers.delete(flavor.themeId)
    dispose()
    registerThemeFor(flavor)
    try {
      // Re-assert synchronously: `dispose()` above already published a snapshot
      // whose preference is the default.
      theme.setTheme(flavor.themeId)
    } catch {
      /* unregistered — the deferred restore below retries on the next event */
    }
  }

  // Debounced push of the current local state into the settings document.
  // When the scope is not usable (memory mode / absent transport) the write
  // is skipped entirely — localStorage stays the only store, exactly the
  // pre-0.5.0 route-missing fallback. The write is read-side guarded (item
  // C/X): a flush whose base revision the document moved past returns
  // `stale`, the local change is abandoned, and the remote state is
  // re-adopted + surfaced in the update row.
  let lastWrittenSection: CatppuccinSettingsSection | undefined
  let handleStaleConflict: (() => void) | undefined
  // Issue #31: the un-recording setTheme entry point (see `commitTheme`),
  // published by the restore effect for the `off` paths that live outside it.
  let applyRestoredPreference: ((id: string) => void) | undefined
  // R2 (2026-10-10 review): whether a local change was made while the durable
  // scope was NOT yet usable — the boot window, when the settings service
  // lands late or its first snapshot is still in flight. Such a change has no
  // channel to be pushed through yet, and the FIRST snapshot the scope later
  // resolves may describe an OLDER document — without this flag the hydration
  // below would "adopt the document" and silently roll the change back. The
  // flag makes the first usable snapshot push the local state instead; a
  // section that already equals the local state makes the queued write a
  // noop, so the ordinary boot path pays nothing.
  let pendingLocalPush = false
  // Issue #31 (echo race, 2026-10-27): the local section as of the newest change
  // this window made and has NOT yet committed, or null when there is nothing
  // owed. It is ARMED on the same predicate as `pendingLocalPush` (local moved
  // away from `syncedSection`) and DISARMED when a flush settles — the read
  // side needs it because a snapshot may arrive while a change is still sitting
  // in the debounce queue or on the wire, carrying the document as it was
  // BEFORE that change. Adopting such a snapshot silently reverts the user's
  // pick (measured on the live desktop shell: a flavour click was overwritten
  // 1.4 s later by `applyScopeSnapshot`, and the queued flush then persisted the
  // reverted value). `pendingLocalPush` covers only the window where the scope
  // is not usable yet; this one covers the ordinary, usable-scope case.
  let pendingLocalSection: CatppuccinSettingsSection | null = null
  // Issue #31, second guard: the highest namespace revision this window has
  // seen. A snapshot that reports a LOWER revision is a stale view (a describe
  // read that resolved late, a superseded write's answer), never a newer
  // document, so it must not be adopted. `revisionKind` resets the high-water
  // mark when the durable channel is re-bound (the two seams number their
  // revisions independently).
  let maxSeenRevision: number | undefined
  let revisionKind: string | undefined
  // Issue #31: the last document section this window actually accepted. A queued
  // flush whose local section already equals it is not "a change the document
  // does not hold yet", so it must not arm `pendingLocalSection` — the adoption
  // path itself re-publishes through the glass layer, and arming on that
  // self-inflicted publish would block the NEXT external edit for a whole
  // debounce beat.
  let lastDocumentSection: CatppuccinSettingsSection | null = null

  // Issue #30: the local section as of the last moment this window knew it was
  // IN SYNC with the durable document — boot, or the last adoption / successful
  // write below. `pendingLocalPush` is armed only when the local state has
  // actually moved away from this baseline, and the replay carries only the
  // moved fields: on a fresh origin (empty localStorage) the "local state" is
  // nothing but the shipped defaults, and replaying it whole rewrote the
  // document to `flavor: off` / `glass: off` / `mica`.
  let syncedSection = settingsSectionFromState(buildLocalState())
  // The revision the pending write is based on, captured when the change is
  // SCHEDULED (audit F2): reading it at flush time made the read-side staleness
  // guard compare a revision with itself — both reads sit in one synchronous
  // block — so `'stale'` was unreachable and an external edit inside the
  // debounce window was silently overwritten. One capture per burst.
  const baseRevisionTracker = createBaseRevisionTracker()
  const queuePersist = (): void => {
    // Marked at SCHEDULE time, not at flush time: the dangerous window is
    // "change happened before the scope first became usable", which includes
    // the debounce beat BEFORE the flush runs (a scope that turns ready
    // inside that beat would hydrate and roll the change back before the
    // flush ever sees it).
    //
    // Issue #30: armed only on a REAL change. The boot path queues persists on
    // its own — the glass layer republishes on every `theme/change` (ui-theme
    // adopts its preference at boot) and on `sync()` — and on a fresh origin
    // none of those carries a user choice. Arming on them was the bug: the
    // first usable snapshot then replayed the shipped defaults over the
    // document. The comparison only runs while the scope is unusable, so the
    // hot path (a slider drag) pays nothing.
    //
    // Issue #31: the same "did a real change happen?" predicate also arms
    // `pendingLocalSection`, which the adoption guard below reads — so it is
    // computed once and shared.
    const localSection = settingsSectionFromState(buildLocalState())
    const pendingVsDocument = lastDocumentSection === null
      || !settingsSectionsEqual(localSection, lastDocumentSection)
    if (pendingVsDocument && !settingsSectionsEqual(localSection, syncedSection)) {
      pendingLocalSection = localSection
      if (!isScopeUsable(scope.getSnapshot())) pendingLocalPush = true
    }
    baseRevisionTracker.capture(() => scope.getSnapshot().revision)
    scheduleDurablePersist(persistLocal)
  }
  const persistLocal = (): void => {
    // Consume the base first: a bail-out (unusable scope) must not leave it
    // behind for the next burst.
    const baseRevision = baseRevisionTracker.take()
    const snapshot = scope.getSnapshot()
    if (!isScopeUsable(snapshot)) {
      // Nothing can be pushed, so localStorage is the only store again and the
      // pending intent must not keep blocking adoption (see `pendingLocalSection`).
      pendingLocalSection = null
      return
    }
    const state = buildLocalState()
    const flushed = settingsSectionFromState(state)
    void persistStateToScope(scope, state, { baseRevision, lastWrittenSection }).then((outcome) => {
      // Only disarm the intent this flush actually carried: a newer change may
      // have re-armed it while the write was on the wire, and THAT one still
      // owes a write.
      const settled = pendingLocalSection !== null && settingsSectionsEqual(pendingLocalSection, flushed)
      if (outcome === 'written') {
        lastWrittenSection = flushed
        // The local cache and the document agree again — a new sync point.
        syncedSection = flushed
        if (settled) pendingLocalSection = null
      } else if (outcome === 'noop') {
        // The document already equals the local state (the normal echo of our
        // own committed write), so this is a sync point too — without moving the
        // baseline here a later adoption would compare against a stale one.
        syncedSection = flushed
        if (settled) pendingLocalSection = null
      } else if (outcome === 'stale') {
        // The document moved past us and the movement is NOT our own echo, so
        // the local change is abandoned: the intent must stop guarding the
        // adoption below, or the conflict path could never adopt.
        if (settled) pendingLocalSection = null
        emitConflict()
        handleStaleConflict?.()
      }
      // 'error' (transport failure / refused mutation) keeps the intent armed on
      // purpose: the choice is still newer than the document and the next flush
      // retries it. Adopting on a failed write is exactly the silent revert this
      // guard exists to stop.
    })
  }

  // Auto-check (item H): the last verdict the periodic checker stored (the
  // update row surfaces it on mount) plus the arm hook the preference
  // setter re-invokes on toggle (the timers themselves live in the restore
  // effect below, so they die with the fiber).
  const AUTO_CHECK_BOOT_DELAY_MS = 3000
  const AUTO_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000
  /** How long the Host's pre-paint palette may survive before it is removed
   *  unconditionally (issue #30 补充). Generous on purpose: removing it EARLY
   *  re-exposes the official palette for one frame, which is the bug. */
  const BOOT_PALETTE_FALLBACK_MS = 10_000
  let lastAutoResult: UpdateCheckPayload | null = null
  let armAutoCheck: (() => void) | undefined

  // Restore the persisted choice and defend it against the built-in
  // Appearance scope's `adopt()`. Two stores feed the desired flavour:
  // localStorage (the in-browser cache — instant at boot and the cross-tab
  // `storage` bus) and the durable store (the source of truth — required
  // because localStorage is per-browser and per-origin while the DSH home is
  // machine-wide; see `src/state.ts`).
  //
  // The re-assert is not a fixed boot window. The built-in ThemeRuntime's
  // `adopt()` re-applies the settings-document preference on every settings
  // reload — and switching the model always reloads the settings document —
  // writing "system" when `ui-theme.preference` was never written, or the
  // persisted light/dark when the document holds one. adopt() writes the
  // runtime preference directly and bypasses setTheme, so the setTheme wrapper
  // below is the one seam that tells explicit picks apart: we restore our
  // flavour whenever the runtime preference is NOT a built-in value the user
  // clicked in the Appearance row THIS session, and choosing "off" in the
  // Catppuccin row clears the persisted flavour before the switch so this
  // guard does not fight it.
  ctx.effect(() => {
    // Session-live record of the user's last EXPLICIT built-in pick, kept by
    // the setTheme wrapper below. The wrapper is the only seam that
    // distinguishes "the user clicked light/dark/system in the Appearance
    // row" from "ThemeRuntime.adopt() copied the settings document's value
    // at boot/reload" — adopt() writes the preference directly and never goes
    // through setTheme, so a doc-adopted light/dark leaves this null and the
    // guard below cannot mistake it for a user choice. Picking a Catppuccin
    // flavour (or the wrapper's own flavour restore) clears the record.
    let liveBuiltinPick: BuiltinPreference | null = null
    // Issue #30 补充: last-resort removal of the Host's pre-paint palette. Its
    // `html body` selector outranks the official `body` block, so a sheet left
    // behind would pin every token and defeat later theme switches — it must
    // never outlive the boot interval even if every other removal point is
    // skipped (an unknown host shape, a restore that never runs).
    const bootPaletteFallback = window.setTimeout(() => { clearBootPalette() }, BOOT_PALETTE_FALLBACK_MS)
    const originalSetTheme = theme.setTheme
    // Issue #31: an internal restore is NOT an explicit pick. It used to go
    // through the wrapper below, which recorded `liveBuiltinPick` — so a restore
    // to `dark` made the plugin believe the user had clicked dark in the
    // Appearance row THIS session, and `builtinPickWins()` then refused every
    // later flavour restore (turn the flavour off, another window turns it back
    // on ⇒ this window never follows). Only a call from OUTSIDE (the Appearance
    // row) records now.
    const commitTheme = (id: string, record: boolean): void => {
      if (record) liveBuiltinPick = isBuiltinPreference(id) ? id : null
      originalSetTheme.call(theme, id)
      // Issue #30 补充: the ThemePresenter applies the new tokens inside the
      // call above, so the pre-paint sheet is spent by the time it returns —
      // and a built-in pick means a flavour sheet must not survive at all.
      clearBootPalette()
    }
    // Named on purpose (R1, 2026-10-10 review): the cleanup below may only
    // restore the original while the method is still OUR wrapper. Another
    // extension replacing it afterwards owns the slot by then, and an
    // unconditional write-back of the original would silently unhook it.
    const restoreGuardSetTheme = (id: string): void => { commitTheme(id, true) }
    theme.setTheme = restoreGuardSetTheme
    // The `off` / cross-window paths live outside this effect; they need the
    // un-recording entry point.
    applyRestoredPreference = (id: string) => { commitTheme(id, false) }

    // Issue #10: a synchronous setTheme inside a theme/change dispatch
    // re-enters publish() — the ThemePresenter (registered after us) then
    // applies the STALE snapshot carried by the OUTER dispatch last, so the
    // DOM ends up dark/system while the runtime preference is the flavour.
    // Defer the restore out of the current dispatch (microtask) and re-check
    // at run time, so the flavour's setTheme is always the LAST event the
    // presenter sees. A single in-flight restore coalesces repeated
    // observations (boot, adopt() reloads, storage echoes).
    let restorePending = false
    // Issue #31: the LATEST desired value of the burst, not the first one. The
    // old coalescing dropped every later observation (`if (restorePending)
    // return`), so two different intents inside one task left the stale one
    // applied — and with no further theme/change to correct it.
    let pendingDesired: string | undefined
    // `desired` is widened to string on purpose: the SAME deferred path also
    // carries the built-in restore (audit F4) — when the persisted choice went
    // 'off' somewhere else, the theme to apply is a built-in preference
    // (`system`/`light`/`dark`), not a flavour id.
    const scheduleRestore = (desired: string): void => {
      pendingDesired = desired
      if (restorePending) return
      restorePending = true
      queueMicrotask(() => {
        restorePending = false
        const wanted = pendingDesired as string
        pendingDesired = undefined
        const preference = theme.getTheme().preference
        if (preference === wanted) {
          // The flavour is ALREADY the active theme — no setTheme will run, so
          // this is the only chance to retire the pre-paint sheet (issue #30
          // 补充). Nothing is painted between here and the presenter's own
          // work, so removing it cannot flash.
          clearBootPalette()
          return
        }
        // Re-check the guard at run time: a newer explicit built-in pick
        // (or a newer event) still wins over the persisted flavour.
        if (builtinPickWins(preference, liveBuiltinPick)) return
        // Lazy registration (item JJ): the theme must exist before setTheme.
        ensureThemeRegistered(wanted)
        try {
          // Records nothing (issue #31): a restore is not a user pick.
          commitTheme(wanted, false)
        } catch {
          // Theme not registered yet — a later theme/change re-runs applyDesired.
        }
      })
    }

    const applyDesired = (): void => {
      // Record the built-in preference on every non-flavour observation (boot,
      // adopt() reloads, explicit Appearance changes) BEFORE any re-assert, so
      // 'off' below can hand the user back exactly what they had.
      rememberBuiltinPreference(theme.getTheme().preference)
      const desired = readFlavor()
      if (desired === 'off') {
        // The persisted choice is off — but this session may still be rendering
        // a Catppuccin flavour (another window or the settings document turned
        // it off). Hand the user back their built-in preference, exactly like
        // the row's own `select('off')` path. Gated on an EXPLICIT 'off' in
        // localStorage (audit F4): an empty storage may just mean this
        // browser/origin never chose, so the absence of a value is NOT a choice
        // and the durable store — which may legitimately restore a flavour — is
        // authoritative. Without that gate we would fight the document on every
        // boot of a fresh origin.
        const preference = theme.getTheme().preference
        if (readExplicitFlavorOff()) {
          // An explicit 'off' means no flavour is wanted, so a sheet injected
          // for one (this page may have been rendered while the document still
          // held a flavour) must go — otherwise it would pin every token.
          clearBootPalette()
          if (flavorFromThemeId(preference) !== 'off') scheduleRestore(readRestoredPreference())
        }
        return
      }
      const preference = theme.getTheme().preference
      if (preference === desired) {
        // Already rendering this flavour — retire the pre-paint sheet (see the
        // same case in scheduleRestore).
        clearBootPalette()
        return
      }
      // A built-in preference only wins if the user explicitly picked it in
      // THIS session (matching liveBuiltinPick). "system" and boot/adopt()
      // values adopted from the settings document (liveBuiltinPick null) are
      // stale for the plugin — the Catppuccin row choice is newer than the
      // document's light/dark, so restore the flavour then.
      if (builtinPickWins(preference, liveBuiltinPick)) return
      scheduleRestore(desired)
    }
    applyDesired()
    const disposer = ctx.on('theme/change', applyDesired)
    const onStorage = (event: StorageEvent): void => {
      if (event.key !== FLAVOR_STORAGE_KEY) return
      const next = readFlavor()
      if (next !== 'off') {
        ensureThemeRegistered(next)
        try {
          theme.setTheme(next)
        } catch {
          /* unknown persisted value — keep the current theme */
        }
        return
      }
      // Another window turned the flavour off (audit F4): this tab must land on
      // the built-in preference too, or it keeps rendering Catppuccin while the
      // persisted choice — and the settings row of the other window — say off.
      if (flavorFromThemeId(theme.getTheme().preference) === 'off') return
      try {
        // Not an Appearance pick (issue #31), so it must not be recorded.
        commitTheme(readRestoredPreference(), false)
      } catch {
        /* keep the current theme rather than dropping the user into nothing */
      }
    }
    window.addEventListener('storage', onStorage)

    // Any glass change (enable flag or knob) coalesces into one durable write.
    // Issue #30: only when a PERSISTED field actually moved. The layer also
    // republishes on `theme/change` (Appearance switch, `ui-theme` adopt() at
    // boot) where nothing durable changed — those publishes used to queue a
    // pointless flush that could land as a false "another window changed it".
    const offGlass = glass.subscribe(() => {
      queuePersist()
    })

    // Hydrate the durable source of truth without blocking paint. The scope
    // derives from the shared settings mirror (no wire read of its own), so
    // this is sync once the mirror has resolved; if it arrives later, the
    // subscription below catches it — the localStorage fast path keeps
    // working in the meantime.
    //
    // The hydration is echo-safe: the Host folds our own committed writes
    // back into the mirror, and when the echoed section equals the local
    // state (the normal case after a change we just persisted) we skip the
    // write-back. A section that differs is an external edit (another
    // surface, a hand-edited document, a reload) — the document wins.
    const applyScopeSnapshot = (): void => {
      const snapshot = scope.getSnapshot()
      const state = durableStateFromSnapshot(snapshot)
      if (state === null) return // loading / memory / absent — localStorage-only
      // Issue #31, guard 2: revision monotonicity. Writes only ever move the
      // namespace revision forward, so a snapshot reporting an OLDER revision is
      // a stale view (a describe read that resolved late, a superseded write's
      // answer folded after a newer one) — adopting it rewinds the document the
      // user is looking at.
      const revision = snapshot.revision
      if (revision !== undefined) {
        if (revisionKind !== scope.kind) {
          revisionKind = scope.kind
          maxSeenRevision = undefined
        }
        if (maxSeenRevision !== undefined && revision < maxSeenRevision) return
        maxSeenRevision = Math.max(maxSeenRevision ?? revision, revision)
      }
      const local = buildLocalState()
      // R2: a change made before the scope first became usable wins over the
      // first usable snapshot (see `pendingLocalPush`) — but only the FIELDS
      // that actually moved since the last sync point (issue #30). A whole
      // state replay from a fresh origin carries nothing but the shipped
      // defaults and wiped the document.
      if (pendingLocalPush) {
        pendingLocalPush = false
        const replayed = replayLocalChanges(state, syncedSection, settingsSectionFromState(local))
        if (replayed.changed) {
          // The boot-window change is newer than the document: adopt the
          // MERGED state into the local cache, then let the debounced flush
          // carry it out (`persistLocal` rebuilds from the cache, so it writes
          // exactly these values).
          writeFlavor(replayed.state.flavor)
          glass.applyRemote(replayed.state.glass)
          writeAutoCheck(replayed.state.autoCheck)
          writeUpdateChannel(replayed.state.updateChannel)
          writeOverrides(replayed.state.overrides)
          writeShikiStyle(replayed.state.shikiStyle)
          emitPrefs()
          reapplyThemePrefs()
          applyDesired()
          syncedSection = settingsSectionFromState(replayed.state)
          // The snapshot still describes the OLDER document this replay just
          // beat, so the queued push below must stay armed (issue #31).
          lastDocumentSection = settingsSectionFromState(state)
          queuePersist()
          return
        }
        // Nothing of ours moved (the ordinary fresh-origin boot publish) —
        // fall through to the adoption path below, exactly as if the flag had
        // never been armed.
      }
      // The channel owns the "does the document hold a user layer yet?" test:
      // the new form's `user` is an empty object until someone writes, while
      // the legacy document omits it entirely.
      if (!scope.hasUserLayer(snapshot)) {
        // No user layer in the document yet: this session's localStorage
        // choice is newer than the shipped defaults the document resolves
        // to, so push it into the document (the upgrade path for a
        // localStorage-only session predating the settings migration).
        if (!isDefaultState(local)) queuePersist()
        return
      }
      // A document holding unpersistable override entries (a hand-edited key
      // that is not a `--` token) can never compare equal to the sanitized
      // local shape, so every publish would re-run this adoption forever.
      // Adopt, then push the cleaned map back once so the document converges
      // (audit F7). The push is queued AFTER the adoption below, because the
      // adoption cancels the queued flush (issue #31).
      const pushCleaned = hasUnpersistableOverrides((snapshot.value as { overrides?: unknown } | undefined)?.overrides)
      // A document the user wrote wins over the local cache, but echoes of
      // our own committed writes are skipped (they equal the local state).
      const localSection = settingsSectionFromState(local)
      const documentSection = settingsSectionFromState(state)
      if (settingsSectionsEqual(localSection, documentSection)) {
        // Our own echo. Recording the section is what keeps `queuePersist` from
        // arming a pending intent for it (issue #31).
        lastDocumentSection = documentSection
        return
      }
      // Issue #31, guard 1 (THE measured bug): this window has a change the
      // document does not hold yet — it is sitting in the debounce queue or on
      // the wire. The snapshot therefore describes the document as it was
      // BEFORE that change, and adopting it silently reverts the user's pick
      // (and the queued flush then persists the reverted value, so the loss
      // becomes durable). Keep the local state; the flush carries it out.
      if (pendingLocalSection !== null && !settingsSectionsEqual(pendingLocalSection, documentSection)) return
      // Committing to the document: the queued flush would now only write the
      // pre-adoption state back, so drop it (and the revision it captured — a
      // stale base would be read as a conflict by the next burst). Both sync
      // points move BEFORE the writes below, because `glass.applyRemote`
      // republishes and that publish runs `queuePersist` (issue #31).
      cancelDurablePersist()
      baseRevisionTracker.take()
      pendingLocalSection = null
      lastDocumentSection = documentSection
      syncedSection = documentSection
      writeFlavor(state.flavor)
      glass.applyRemote(state.glass)
      writeAutoCheck(state.autoCheck)
      writeUpdateChannel(state.updateChannel)
      writeOverrides(state.overrides)
      writeShikiStyle(state.shikiStyle)
      emitPrefs()
      reapplyThemePrefs()
      applyDesired()
      // `syncedSection` / `lastDocumentSection` were already moved onto the
      // document above (before the writes), so the boot replay below compares
      // against the fresh baseline.
      if (pushCleaned) queuePersist()
    }
    applyScopeSnapshot()
    const offScope = scope.subscribe(applyScopeSnapshot)

    // Auto-check (item H): warm the Host's verdict cache at boot and every
    // 6 hours while the preference is on. The row surfaces the last result
    // and the Host cache keeps re-opens instant; failures stay uncached so
    // the next cycle retries for real.
    const runAutoCheck = async (): Promise<void> => {
      try {
        const response = await fetch(`${UPDATE_ROUTE_PATH}?channel=${readUpdateChannel()}`, {
          headers: { accept: 'application/json' },
          // R3: same client-side cap as the manual check — a periodic probe
          // must never pile up behind a wedged host.
          signal: AbortSignal.timeout(UPDATE_CHECK_CLIENT_TIMEOUT_MS),
        })
        if (response.ok) lastAutoResult = await response.json() as UpdateCheckPayload
      } catch {
        /* best-effort; the row's retry discipline covers the user-visible UX */
      }
    }
    let bootTimer: number | undefined
    let intervalTimer: number | undefined
    const armAutoCheckImpl = (): void => {
      window.clearTimeout(bootTimer)
      window.clearInterval(intervalTimer)
      if (!readAutoCheck()) return
      bootTimer = window.setTimeout(() => { void runAutoCheck() }, AUTO_CHECK_BOOT_DELAY_MS)
      intervalTimer = window.setInterval(() => { void runAutoCheck() }, AUTO_CHECK_INTERVAL_MS)
    }
    armAutoCheck = armAutoCheckImpl
    armAutoCheckImpl()

    handleStaleConflict = () => applyScopeSnapshot()

    return () => {
      offScope()
      offGlass()
      disposer()
      window.removeEventListener('storage', onStorage)
      window.clearTimeout(bootPaletteFallback)
      // A stopped plugin must not leave the sheet pinned over the official
      // theme (issue #30 补充).
      clearBootPalette()
      window.clearTimeout(bootTimer)
      window.clearInterval(intervalTimer)
      cancelDurablePersist()
      handleStaleConflict = undefined
      applyRestoredPreference = undefined
      armAutoCheck = undefined
      // Undo the setTheme wrapper so a stopped plugin leaves the runtime as
      // it found it — but only while the wrapper is still ours (R1): if
      // another extension replaced it after us, that replacement is the
      // current owner and force-writing the original back would unhook it
      // without a trace.
      if (theme.setTheme === restoreGuardSetTheme) {
        theme.setTheme = originalSetTheme
      } else {
        console.warn('[dsh-catppuccin] theme.setTheme was replaced by another extension; leaving it in place')
      }
    }
  }, 'catppuccin: theme restore')

  const injected = (): CatppuccinRowInjected => ({
    themes: CATPPUCCIN_FLAVORS.map((flavor) => ({
      id: flavor.themeId,
      label: flavor.label,
      accent: flavor.accent,
    })),
    current: () => {
      const pref = theme.getTheme().preference
      return flavorFromThemeId(pref)
    },
    subscribe: (listener) => ctx.on('theme/change', listener),
    select: (choice: FlavorChoice) => {
      if (choice === 'off') {
        // Restore the built-in preference the user had before the flavour
        // ('system' when nothing was recorded). Persist the abandoned choice
        // BEFORE setTheme: setTheme emits theme/change synchronously, so the
        // restore guard must already read `off` here and not re-assert the
        // previous flavour.
        writeFlavor('off')
        // Wrapped like every other setTheme call (issue #23 audit): a throw
        // here used to escape into the row's click handler; keep the current
        // theme instead of dropping the user into nothing. Issue #31: goes
        // through the UN-recording entry point — turning the flavour off is not
        // an Appearance pick, and recording it would veto every later restore.
        try {
          if (applyRestoredPreference !== undefined) applyRestoredPreference(readRestoredPreference())
          else theme.setTheme(readRestoredPreference())
        } catch {
          /* keep the current theme rather than dropping the user into nothing */
        }
        queuePersist()
        return
      }
      const flavor = flavorInfo(choice)
      if (!flavor) return
      // Persist first so the restore guard (a theme/change listener) sees the
      // new flavour when setTheme below emits synchronously. Lazy
      // registration: the theme must exist before setTheme (item JJ).
      const previous = readFlavor()
      writeFlavor(flavor.themeId)
      ensureThemeRegistered(flavor.themeId)
      // Issue #31: a throw here used to be swallowed, leaving the cache on the
      // NEW flavour and the runtime on the OLD one — "I clicked it and nothing
      // happened", with no retry and no notice. Retry once after forgetting the
      // registration memo (a tolerated duplicate skip or a recycled
      // registration can leave the memo pointing at a dead registrant), and if
      // it still fails put the cache back so the two stores never disagree.
      try {
        theme.setTheme(flavor.themeId)
      } catch {
        themeDisposers.get(flavor.themeId)?.()
        themeDisposers.delete(flavor.themeId)
        registerThemeFor(flavor)
        try {
          theme.setTheme(flavor.themeId)
        } catch {
          writeFlavor(previous)
          emitPrefs()
          emitConflict()
          return
        }
      }
      queuePersist()
    },
    overrides: overridesSnapshot,
    setOverrides: (overrides: Record<string, string>) => {
      writeOverrides(overrides)
      emitPrefs()
      reapplyThemePrefs()
      queuePersist()
    },
    shikiStyle: () => readShikiStyle(),
    setShikiStyle: (style: ShikiStyle) => {
      writeShikiStyle(style)
      emitPrefs()
      reapplyThemePrefs()
      queuePersist()
    },
    subscribePrefs: (listener: () => void) => {
      prefsListeners.add(listener)
      return () => { prefsListeners.delete(listener) }
    },
  })

  // Every row registration rides `tolerantRegistration` (issue #23): the
  // callback runs SYNCHRONOUSLY when the slot is already declared (the
  // renderer's documented contract), so a duplicate id at the same priority
  // (`list slot "…" already has an entry with id "…"`, e.g. a duplicate
  // install) would otherwise throw straight through apply() and fail the
  // boot. A skipped row costs nothing: the occupant is the same row.
  const glassInjected = (): GlassRowInjected => ({
    getState: () => glass.getSnapshot(),
    subscribe: (listener) => glass.subscribe(listener),
    setEnabled: (enabled) => { glass.setEnabled(enabled) },
    setMode: (mode) => { glass.setMode(mode) },
    setBlur: (blur) => { glass.setBlur(blur) },
    setFrost: (frost) => { glass.setFrost(frost) },
    setBrightness: (brightness) => { glass.setBrightness(brightness) },
    setGlow: (glow) => { glass.setGlow(glow) },
    resetDefaults: () => { glass.resetDefaults() },
  })

  // Update check: the Host owns the npm lookup (Node fetch, no CORS); the row
  // only fetches the same-origin route and renders the verdict. Upgrade stays
  // a terminal action — the row just surfaces the CLI command.
  const updateInjected = (): UpdateRowInjected => ({
    check: async (channel: UpdateChannel) => {
      try {
        const response = await fetch(`${UPDATE_ROUTE_PATH}?channel=${channel}`, {
          headers: { accept: 'application/json' },
          // R3 (2026-10-10 review): cap the host hop. The route's own registry
          // lookup is capped at 8s (UPDATE_FETCH_TIMEOUT_MS), so this budget
          // only bites when the host process itself stopped answering —
          // without it the row's `checking` phase (and its disabled button)
          // could stay pinned forever. The abort lands in the catch below as
          // the same `network.local` as any other failed hop.
          signal: AbortSignal.timeout(UPDATE_CHECK_CLIENT_TIMEOUT_MS),
        })
        return await response.json() as UpdateCheckPayload
      } catch {
        return { ok: false, code: 'network.local', error: 'network.local' }
      }
    },
    autoCheck: () => readAutoCheck(),
    setAutoCheck: (value: boolean) => {
      writeAutoCheck(value)
      emitPrefs()
      queuePersist()
      armAutoCheck?.() // re-arm the boot/periodic timers on toggle
    },
    channel: () => readUpdateChannel(),
    setChannel: (channel: UpdateChannel) => {
      writeUpdateChannel(channel)
      emitPrefs()
      queuePersist()
    },
    subscribePrefs: (listener: () => void) => {
      prefsListeners.add(listener)
      return () => { prefsListeners.delete(listener) }
    },
    lastAutoResult: () => lastAutoResult,
    subscribeConflict: (listener: () => void) => {
      conflictListeners.add(listener)
      return () => { conflictListeners.delete(listener) }
    },
    conflictCount: () => conflictCount,
    // Timestamps must follow the interface language, not the browser locale
    // (`toLocaleString()` with no argument silently uses the latter).
    activeLocale: () => ctx.locale.getLocale().active,
    subscribeLocale: (listener: () => void) => ctx.locale.subscribe(listener),
  })

  // The plugin's OWN settings page (issue #27). One nav entry, and every
  // preference row lives on it instead of being spliced into General. Two
  // contracts, both load-bearing:
  //  - `tolerantRegistration`: with the slot already declared the callback runs
  //    SYNCHRONOUSLY, so a duplicate install (same section id) would otherwise
  //    throw straight through apply() and fail the boot (issue #23 / AGENTS.md
  //    rule 5). A skipped registration costs nothing: the occupant is the same
  //    page.
  //  - `label` is a THUNK: the shell resolves it on every read, so switching the
  //    interface language re-renders the nav row without re-registering.
  // `order: 25` keeps the official sections (account -10 / general 0 /
  // models 10 / plugins 15 / agent-presets 20) ahead of ours.
  const t = ctx.locale.bind(NS)
  const sectionInjected = (): CatppuccinSettingsPageInjected => ({
    flavor: injected(),
    glass: glassInjected(),
    update: updateInjected(),
  })

  ctx.slots.inject('settings.section', () => tolerantRegistration(() => ctx.slots.register({
    name: 'settings.section',
    id: 'catppuccin',
    order: 25,
    label: () => t('nav.title'),
    locale: NS,
    inject: sectionInjected,
  }, CatppuccinSettingsPage)))
  // Plugins-page card: the settings section on this plugin's OWN detail page in
  // the Plugin manager (DSH >= 0.2.0-rc.2). Three things about this
  // registration are contracts, not style (see `src/client/detail-card.tsx`):
  //  - `key` is the BUNDLE PACKAGE NAME, because the page dispatches with
  //    `{ entryKey: pkg.name }` — NOT `CATPPUCCIN_ENTRY_ID`, which keys the
  //    settings namespace;
  //  - the section exists only while this registration does, so `whileServed`
  //    withdraws it with the namespace instead of leaving an empty block;
  //  - the face is the SAME three factories the General rows use, so the second
  //    home shares the durable section rather than a copy of it.
  // `whileServed` is guarded because not every host past 0.1.7 serves it, and
  // `slots.inject` waits for the slot's DECLARATION — a host without the Plugin
  // manager never fires it (no throw, no pending state).
  const detailInjected = (): CatppuccinDetailCardInjected => ({
    flavor: injected(),
    glass: glassInjected(),
    update: updateInjected(),
  })

  ctx.inject(['configForms'], (formsCtx) => {
    const forms = formsCtx.configForms
    if (typeof forms.whileServed !== 'function') return
    return forms.whileServed([CATPPUCCIN_ENTRY_ID], () => ctx.slots.inject(
      'plugins.bundle.config',
      () => tolerantRegistration(() => ctx.slots.register({
        name: 'plugins.bundle.config',
        key: PACKAGE_NAME,
        locale: NS,
        inject: detailInjected,
      }, CatppuccinDetailCard)),
    ))
  })
}