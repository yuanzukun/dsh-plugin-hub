/**
 * Update-check settings row — one General-section preference row that asks
 * the Host's `/catppuccin/check-update` route for the latest published npm
 * version and reports whether this install is current. Detection is Host-side
 * (Node fetch, no CORS, profile probe included); the row renders the verdict
 * and, when an update is available, offers the copyable CLI upgrade command
 * whose profile name the Host already probed. Upgrading itself stays a
 * terminal action (`dsh plugin … add @latest`) — the row never touches the
 * profile workspace.
 *
 * Beyond the check button the row carries:
 *  - the auto-check switch (item H) and the release-channel segmented pick
 *    (item I), both persisted through the durable state;
 *  - an automatic retry 30s after a failed check (item V) with a countdown;
 *  - a conflict banner (item C/X) when a durable write from another window
 *    superseded a local change ("另一窗口已更新，本地改动未保存");
 *  - the latest auto-check verdict (item H) surfaced on mount;
 *  - a "?" help affordance (item J, native `title` tooltip).
 */
import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { Button, SegmentedControl, Switch } from '@deepseek-ai/dsh-client-ui-primitives'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { UpdateCheckPayload, UpdateErrorCode, UpdateChannel } from '../update-check.ts'
import type { CatppuccinKey } from './locales.ts'
import { HelpBadge } from './HelpBadge.tsx'
import rowCss from './settings-row.module.css'

/** Auto-retry scheduled after a failed check (item V): one retry after 30s,
 *  then it stops — the discipline lives here in the row, never in a hanging
 *  route request. */
export const UPDATE_RETRY_AFTER_MS = 30_000

/** Injected business face of the row (assembled in apply). */
export interface UpdateRowInjected {
  /** Ask the Host for the update verdict (same-origin fetch of the route).
   *  The channel preference rides the query string (item I). */
  check: (channel: UpdateChannel) => Promise<UpdateCheckPayload>
  /** Whether automatic checks are on (item H). */
  autoCheck: () => boolean
  /** Set the auto-check preference (persists durably + re-arms timers). */
  setAutoCheck: (value: boolean) => void
  /** The persisted release channel (item I). */
  channel: () => UpdateChannel
  /** Set the release channel (persists durably). */
  setChannel: (channel: UpdateChannel) => void
  /** Subscribe to preference changes (auto-check / channel). */
  subscribePrefs: (listener: () => void) => () => void
  /** The latest auto-check verdict, or null before the first one (item H). */
  lastAutoResult: () => UpdateCheckPayload | null
  /** Subscribe to durable-write conflict notices (item C/X). */
  subscribeConflict: (listener: () => void) => () => void
  /** Number of conflicts this session has seen (item C/X). */
  conflictCount: () => number
  /** The active DSH locale id — for locale-aware formatting (timestamps).
   *  `toLocaleString()` with no argument uses the BROWSER locale, which drifts
   *  from the interface language as soon as the user picks one in Settings. */
  activeLocale: () => string
  /** Subscribe to locale switches, so a language change re-formats the row. */
  subscribeLocale: (listener: () => void) => () => void
}

/** Full component props: runtime share + locale seat + injected face. */
export type UpdateRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'catppuccin'> & UpdateRowInjected

/** One phase of the row's interaction. */
type Phase = 'idle' | 'checking' | 'done'

/** Copy the upgrade command; falls back to no-op when the clipboard is unavailable. */
async function copyCommand(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    return false
  }
}

/** Map a stable error code to its locale key (unknown codes fall back to the generic message). */
function errorKey(code: UpdateErrorCode | undefined): CatppuccinKey {
  switch (code) {
    case 'registry-unreachable': return 'update.err.registry'
    case 'registry-http': return 'update.err.http'
    case 'no-dist-tags': return 'update.err.noTags'
    case 'invalid-response': return 'update.err.invalid'
    case 'network.local': return 'update.err.networkLocal'
    case 'network.upstream': return 'update.err.networkUpstream'
    default: return 'update.failed'
  }
}

/**
 * Render the update-check row: title, description, auto-check switch,
 * channel pick, a check button, and the verdict once checked.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export function UpdateRow({
  t,
  check,
  autoCheck,
  setAutoCheck,
  channel,
  setChannel,
  subscribePrefs,
  lastAutoResult,
  subscribeConflict,
  conflictCount,
  activeLocale,
  subscribeLocale,
}: UpdateRowProps): React.JSX.Element {
  const [phase, setPhase] = useState<Phase>('idle')
  const [payload, setPayload] = useState<UpdateCheckPayload | null>(null)
  const [copied, setCopied] = useState(false)
  const autoCheckOn = useSyncExternalStore(subscribePrefs, autoCheck)
  const channelValue = useSyncExternalStore(subscribePrefs, channel)
  const conflicts = useSyncExternalStore(subscribeConflict, conflictCount)
  // The timestamp follows the DSH locale, not the browser: the two only agree
  // until the user picks a language in Settings (2026-09-21 audit).
  const locale = useSyncExternalStore(subscribeLocale, activeLocale)
  const [dismissedConflicts, setDismissedConflicts] = useState(0)
  // Item V: ONE automatic retry after a failure, 30s later ("仍失败则停").
  const [retryRemaining, setRetryRemaining] = useState<number | null>(null)
  const retryTimer = useRef<number | undefined>(undefined)
  const tickerTimer = useRef<number | undefined>(undefined)
  // Auto-retries already spent since the last user-initiated check. The retry
  // itself calls `runCheck` (not `runManualCheck`), so a retry that fails
  // again hits this guard and stops instead of re-scheduling forever.
  const retriesUsed = useRef(0)
  const mounted = useRef(true)

  /** Drop a pending auto-retry (its timeout and its countdown ticker). */
  const cancelRetry = (): void => {
    if (retryTimer.current !== undefined) {
      window.clearTimeout(retryTimer.current)
      retryTimer.current = undefined
    }
    if (tickerTimer.current !== undefined) {
      window.clearInterval(tickerTimer.current)
      tickerTimer.current = undefined
    }
    setRetryRemaining(null)
  }

  // The channel is resolved at CALL time (audit F6): the default used to be the
  // render-closure's `channelValue`, so the 30 s auto-retry — and any check
  // fired from a stale render — queried the channel that was current when the
  // handler was created, not the one the user has since picked.
  const runCheck = async (withChannel?: UpdateChannel): Promise<void> => {
    cancelRetry()
    setPhase('checking')
    setCopied(false)
    let next: UpdateCheckPayload
    try {
      next = await check(withChannel ?? channel())
    } catch {
      next = { ok: false, code: 'network.local', error: 'network.local' }
    }
    setPayload(next)
    setPhase('done')
    if (!next.ok && retriesUsed.current === 0) {
      retriesUsed.current = 1
      const target = Date.now() + UPDATE_RETRY_AFTER_MS
      setRetryRemaining(UPDATE_RETRY_AFTER_MS / 1000)
      const ticker = window.setInterval(() => {
        const remaining = Math.max(0, Math.ceil((target - Date.now()) / 1000))
        setRetryRemaining(remaining)
        if (remaining <= 0) {
          window.clearInterval(ticker)
          tickerTimer.current = undefined
        }
      }, 1000)
      tickerTimer.current = ticker
      retryTimer.current = window.setTimeout(() => {
        if (mounted.current) void runCheck()
        else cancelRetry()
      }, UPDATE_RETRY_AFTER_MS)
    }
  }

  /** A user-initiated check: re-arms the one auto-retry budget (item V). */
  const runManualCheck = (): void => {
    retriesUsed.current = 0
    void runCheck()
  }

  useEffect(() => {
    mounted.current = true
    return () => {
      mounted.current = false
      if (retryTimer.current !== undefined) window.clearTimeout(retryTimer.current)
      if (tickerTimer.current !== undefined) window.clearInterval(tickerTimer.current)
    }
  }, [])

  const autoResult = lastAutoResult()
  const localInstall = payload?.ok === true && payload.installSource !== undefined
    && payload.installSource !== 'registry'
  // DSH Desktop adapts the copy: its target profile comes from the Desktop
  // service and the hint/restart text says so, while standard dsh web keeps
  // the terminal copy.
  const isDesktop = payload?.ok === true && payload.env === 'desktop'
  // The official Electron shell has no CLI path a user can reach (its Plugins
  // page is the only way: delete → re-add the package name), so it gets the
  // bare `pkg@tag` spec plus the page instructions instead of a shell command.
  const officialDesktop = payload?.ok === true && payload.shell === 'official-desktop'
  const upgradeValue = payload?.ok === true
    ? (officialDesktop ? payload.updateSpec : payload.updateCommand)
    : undefined
  const showConflict = conflicts > dismissedConflicts

  return (
    <div className={rowCss.row} data-catppuccin-row="update">
      <div className={rowCss.title}>
        {t('update.title')}
        <HelpBadge label={t('update.helpLabel')} help={t('update.help')} />
      </div>
      <div className={rowCss.desc}>{t('update.description')}</div>

      {/* Conflict banner (item C/X): another window's durable write won. */}
      {showConflict && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center', padding: '6px 10px', borderRadius: 8, border: '0.5px solid var(--dsw-alias-border-l2)', background: 'var(--dsw-alias-state-business-tertiary)' }}>
          <span style={{ color: 'var(--dsw-alias-label-primary)', fontSize: 12, lineHeight: '18px' }}>
            {t('update.conflict')}
          </span>
          <Button
            size="sm"
            variant="ghost"
            aria-label={t('update.conflictDismiss')}
            onClick={() => { setDismissedConflicts(conflicts) }}
          >
            ✕
          </Button>
        </div>
      )}

      {/* Auto-check + channel preferences (items H/I). */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ color: 'var(--dsw-alias-label-secondary)', fontSize: 12, lineHeight: '18px' }}>
            {t('update.autoCheck')}
          </span>
          <Switch checked={autoCheckOn} onChange={(next) => { setAutoCheck(next) }} label={t('update.autoCheck')} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ color: 'var(--dsw-alias-label-secondary)', fontSize: 12, lineHeight: '18px' }}>
            {t('update.channel')}
          </span>
          <SegmentedControl
            id="catppuccin-update-channel"
            label={t('update.channel')}
            value={channelValue}
            options={[
              { value: 'latest' as UpdateChannel, label: t('update.channelLatest') },
              { value: 'beta' as UpdateChannel, label: t('update.channelBeta') },
            ]}
            onChange={(next) => { setChannel(next) }}
          />
        </div>
      </div>

      {/* Auto-check verdict surfaced at mount (item H). */}
      {autoResult?.ok === true && autoResult.outdated === true && autoResult.latest !== undefined && (
        <div style={{ color: 'var(--dsw-alias-label-primary)', fontSize: 12, lineHeight: '18px' }}>
          {t('update.autoAvailable')} <strong>{autoResult.latest}</strong>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
          <Button size="sm" variant="outline" disabled={phase === 'checking'} onClick={runManualCheck}>
            {phase === 'checking' ? t('update.checking') : t('update.check')}
          </Button>
          {payload?.ok === true && payload.current !== undefined && (
            <span style={{ color: 'var(--dsw-alias-label-secondary)', fontSize: 12, lineHeight: '18px' }}>
              {t('update.current')} {payload.current}
            </span>
          )}
          {payload?.ok === true && payload.checkedAt !== undefined && (
            <span style={{ color: 'var(--dsw-alias-label-tertiary)', fontSize: 11, lineHeight: '18px' }}>
              {t('update.checkedAt')} {new Date(payload.checkedAt).toLocaleString(locale)}
            </span>
          )}
        </div>

        {phase === 'done' && payload !== null && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {payload.ok === true ? (
              payload.outdated === true && payload.latest !== undefined ? (
                <>
                  <div style={{ color: 'var(--dsw-alias-label-primary)', fontSize: 12, lineHeight: '18px' }}>
                    {t('update.available')} <strong>{payload.latest}</strong>
                  </div>
                  {upgradeValue !== undefined && (
                    <>
                      <div style={{ color: 'var(--dsw-alias-label-tertiary)', fontSize: 12, lineHeight: '18px' }}>
                        {officialDesktop
                          ? t('update.commandHintOfficialDesktop')
                          : isDesktop
                            ? t('update.commandHintDesktop').replace('{profile}', payload.profile ?? '')
                            : payload.profileDetected === true && payload.profile !== undefined
                              ? t('update.commandHintDetected').replace('{profile}', payload.profile)
                              : t('update.commandHint')}
                      </div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
                        <code style={{
                          flex: '1 1 260px',
                          padding: '6px 10px',
                          borderRadius: 8,
                          border: '1px solid var(--dsw-alias-border-l1)',
                          background: 'var(--dsw-alias-bg-layer-1)',
                          color: 'var(--dsw-alias-label-primary)',
                          fontSize: 12,
                          lineHeight: '18px',
                          whiteSpace: 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
                        }}>
                          {upgradeValue}
                        </code>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => { void copyCommand(upgradeValue).then(setCopied) }}
                        >
                          {copied ? t('update.copied') : t(officialDesktop ? 'update.copySpec' : 'update.copy')}
                        </Button>
                      </div>
                      {localInstall && (
                        <div style={{ color: 'var(--dsw-alias-label-warning, var(--dsw-alias-label-tertiary))', fontSize: 12, lineHeight: '18px' }}>
                          {t('update.localInstall')}
                        </div>
                      )}
                      <div style={{ color: 'var(--dsw-alias-label-tertiary)', fontSize: 12, lineHeight: '18px' }}>
                        {t(isDesktop ? 'update.restartHintDesktop' : 'update.restartHint')}
                      </div>
                    </>
                  )}
                </>
              ) : (
                <div style={{ color: 'var(--dsw-alias-label-primary)', fontSize: 12, lineHeight: '18px' }}>
                  {t('update.upToDate')}
                </div>
              )
            ) : (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
                <span style={{ color: 'var(--dsw-alias-label-tertiary)', fontSize: 12, lineHeight: '18px' }}>
                  {t(errorKey(payload.code))}
                </span>
                {retryRemaining !== null && retryRemaining > 0 && (
                  <span style={{ color: 'var(--dsw-alias-label-tertiary)', fontSize: 12, lineHeight: '18px' }}>
                    {t('update.retryHint').replace('{s}', String(retryRemaining))}
                  </span>
                )}
                <Button size="sm" variant="outline" onClick={runManualCheck}>
                  {t('update.retry')}
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}