# 框语言审计：七个「框」对不上的地方（2026-10-19）

> ⚠️ **行号为写作当时快照**（§1 表格的「出处」列）：之后 `glass.module.css` 有增删，行号已漂；
> 按**选择器 / 符号名**检索，不要按行号跳。结论与量测数字不受影响。

- 触发：维护者 2026-10-19 真机截图提问「当前插件有哪些框是不统一、或你觉得需要改的」。
- 状态：**①②③⑤⑦ 已实施**（`27fd88f` 四条框语言 + `4c4ff21` ⑤ 宽度对齐；闸门全绿，346 测试），
  **已随 `0.6.4` 发布**（2026-10-21；发版时 352 测试，当前树 353）。
  其中 ③ 只动**模态**圆角，**输入卡保持 24 不动**——维护者确认「输入框亮一些」是本意
  （30% 强描边 + 双层影 = 主输入面），所以 24 与 30% 都保留；⑤ 让顶栏与轨迹面板跟随输入卡的
  宽度上限，折叠侧栏回退满宽。**⑥ 复核后撤回**（量测错误，四边都是 12px）；
  **④ 仍只有截图取证**（控件归属未查）。①②③⑦ 已**真机复验通过**（2026-10-21）；
  **⑤ 复验不合格 → 已补 `width: 100%`**（`max-width` 撑不开 fit-content 盒，见该节末尾）。
- 取证环境：官方桌面壳 `0.2.1-rc.2`，Mocha + mica（float），Windows 标题栏在位，截屏 2560×1528，
  设备像素 / CSS px = **1.5**（三点标定，全部逐像素吻合：侧栏左距 12px→18、上距 40+12px→78、
  下距 12px→1528−18=1510；另侧栏列宽 279 ≈ 上游默认 280、顶栏 margin 16→444）。
- 取证方法：逐行扫像素取**描边峰值 RGB** 与圆弧轨迹拟合，再对 CSS 逐条核对。出图
  `.debug/frame-audit/AUDIT_annotated.png`（**不入库**，同目录另有 8 张裁切件）。描边亮度可直接横向比：
  同一 Mocha 地面 `rgb(16,16,26)` 上，alpha 越高峰值越亮。

## 1. 现在的框长什么样

**alpha 有两个口径，别混**（这条 2026-10-19 复核时更正过）：三档 rim 在**浅色**分支是
18 / 12 / 30%（`glass.module.css` 57–59 行），在**暗色**分支是 **24 / 16 / 30%**（111–117 行）——
暗地面上同 alpha 读起来更弱，所以整体抬了一档。下表「rim」列按 `暗 / 浅` 写（截图是 Mocha，取暗色那档）。

| 面 | 圆角 | rim（暗 / 浅） | 峰值 RGB（Mocha） | 投影 | 出处 |
|---|---|---|---|---|---|
| 会话顶栏 | 20 | 24 / 18% | `(65,67,82)` | edge + drop | 759–767 |
| 侧栏卡 | 20 | **16 / 12% soft** | `(51,52,67)` | **只 drop，无 edge** | 799–828（#26 软化） |
| 轨迹面板 | 20 | 24 / 18% | —（本图未开） | edge + drop | 926–935 |
| 输入卡 | **24** | **30 / 30% strong** | `(74,77,93)` | input-shadow 双层 | 973–995（#22 加强） |
| 消息气泡 | 14 | 16 / 12% soft | `(47,49,64)` | 无 | 436–451 |
| 菜单（MenuSurface） | 14 | **0（撤了）** | — | 上游自己的 | 1104–1107（#22 ③） |
| 对话框 | **20（模态）/ 14（小弹层）** | 24 / 18% | —（本图未开） | **edge + drop（2026-10-19 补）** | 1167–1172 / 1467–1471 |
| 控件（按钮 /「＋」珠） | 10 | 24 / 18% | `(61,63,78)` / `(62,64,80)` | edge | 376–383、400–419 |
| 胶囊 / 分组标题 | 8 | 无 | — | 无 | 370–374、1149 |
| 折叠栏 | 16 | 16 / 12% soft | — | drop | 905–910 |

实测峰值与声明 alpha 逐条对得上：16% → 51、24% → 61~65、30% → 74~77（地面 `(16,16,26)`、
`label-primary` = `#cdd6f4`），所以这张表不是「看图的印象」，是可复算的。

## 1.1 每条的证据等级（复核 2026-10-19）

| 条目 | 等级 | 依据 |
|---|---|---|
| ① 对话框无 drop | **源码确认** | 生成的 `GLASS_CSS_TEXT` 里 `[role=dialog][aria-modal=true]` 只有 `box-shadow:var(--dsh-glass-edge)`，mica/compat 两处都无 drop |
| ② 容器 rim 比内部控件淡 | **源码确认** | `glass-seams.ts:33` 把 `data-dsh-glass-surface` 打在 `button[class*="newSession"]`；该元素拿 `--dsh-glass-rim`（24/18%），侧栏卡是 `rim-soft`（16/12%） |
| ③ 输入卡 24 vs 大面 20 | **源码确认** | 975 vs 763 / 825 / 931 |
| ⑦ 菜单无框 vs 对话框有框 | **源码确认** | 1104–1107 只设两个 token；1167 有 `border: 1px solid var(--dsh-glass-rim)` |
| ④ 顶栏右侧三控件形态不一 | **仅截图取证** | 本插件对它们只有圆角规则（`iconButton` 8px / `button` 10px），**没设过描边或图标色**；白框与黄 emoji 归属未查（stock 或第三方），要改必须先取 DOM |
| ⑤ 左右边不齐 | **源码确认（2026-10-19 查清）** | 上游两条独立定宽规则：顶栏 = 列 − 32；输入卡 = `--dsh-composer-card-max-width` = 正文列 + 32，而正文列由宽度手柄写内联变量、上限 = 列 − 176。实测 1251.3 / 1283 / 1395 与公式逐项吻合 |
| ⑥ 侧栏底边留白 | **撤回：量测错误** | 三点标定（左 18 / 上 78 / 下 1510 设备像素）全部等于 12px 边距；原来的 8px 是窗口边缘亮带 + 卡片投影，不是页面边界 |

## 2. 七条不一致

### ① 设置对话框没有投影 —— 确定性遗漏（源码确认 · 已实施 2026-10-19）

`[role='dialog'][aria-modal='true']` 在 mica（1167）与 compat（1467）两处都只写了
`background` / `border` / `box-shadow: var(--dsh-glass-edge)`（内描边光） / `backdrop-filter`，
**没有 `--dsh-glass-drop`**。层级最高的模态（浮在遮罩之上）反而比顶栏、侧栏、输入卡都平。

- 修法：两处都补 `box-shadow: var(--dsh-glass-edge), var(--dsh-glass-drop);`
- 成本：2 行。风险：无（只在 mask 上多一层影）。
- 需真机看：暗色 mask（很暗）+ 深色影是否读得出来；Latte 需另看一次（浅地面上影更明显）。

### ② 容器 rim 比容器内的控件还淡 —— 层级倒挂（已实施 2026-10-19）

同一块侧栏卡里：卡的 rim 是 `rim-soft`（暗 16% / 浅 12%，实测 `(51,52,67)`），里面「新会话」按钮的 rim 是
`--dsh-glass-rim`（暗 24% / 浅 18%，实测 `(61,63,78)`），**按钮比它所在的框更亮**。
按钮的这层 border 来自 `[data-dsh-glass-surface]`（414–419 行），而接缝 `glass-seams.ts:33`
确实把它打在了 `button[class*="newSession"]` 上。输入卡那条是对的（卡 30% → 内部「＋」珠 24%），
说明这不是配方错误，而是没立过「外框 ≥ 内框」这条规则。

- 修法：把「新会话」按钮（`[data-dsh-glass-surface]`）的 border 降到 `--dsh-glass-rim-soft`，
  与卡同档；或反过来给侧栏回 18%（**不建议**：#26 有实测说 Latte 下太实、会被读成贴上去的相框）。
- 成本：1 行。风险：按钮的「主操作」辨识度下降，靠 `card-raised` 填充（64%）撑着。

### ③ 圆角 24 vs 20 —— 语言本身的分歧（源码确认 · 已实施 2026-10-19）

输入卡 24（975），顶栏 / 侧栏 / 轨迹都是 20，而且三者与输入卡同列并排、差距一眼可见。
整套语言目前是 24 / 20 / 14 / 10 / 8（+ 折叠栏 16），20 与 24 两个大面档位同时存在。

- 选项 A（推荐，改动最小）：输入卡回 20，大面统一 20。
- 选项 B：四个大面全抬 24（顶栏下面就是正文，24 会吃掉一点标题块的对齐感）。
- ⚠️ **`docs/issue-28-fused-composer-plan.md` 把 24 当作既定前提**（「卡与 dock 共用一个 24px 圆角外框」），
  选 A 必须同步改那份方案；选 B 则不用动。
- 成本：1 行 + 文档同步。

### ④ 顶栏右侧三个控件三种形态（仅截图取证）

同一行里并排：① 分段按钮（文件夹 + chevron）有 1px **中性白**描边 `(66,66,75)`——和皮肤偏蓝的
label rim `(62,64,80)` 不同源，也不是 `--dsh-glass-*` 系列；里面是**未主题化的黄 emoji** `(220,156,0)`，
全窗口唯一的饱和色；② 旁边的「…」无框；③ 最右的面板图标用 stock 白线 `(139,145,168)`，比 rim 亮一倍。

**归属未确认**：本插件对这三个元素只可能命中过圆角规则（`[class*='iconButton']` 8px、
`button[class*='button']` 10px），**没有设过描边、填充或图标色**——那条白框与黄 emoji 都是上游（或第三方插件）画的。
所以这条不是「皮肤画歪了」，而是「皮肤没管它们」；要动先取 DOM 确认归属。

- 修法：统一成「裸图标 + hover 玻璃珠」（与 #22 ③ 的 no-outline 词汇一致），emoji 换 token 着色图标。
- 成本：0.5–1h，**前提是这三个控件有稳定 hook**——没 hook 就只能挂 class 子串，属脆弱选择器，
  得先按 `docs/glass-mis-hits.md` 的方式核一遍再决定做不做。

### ⑤ 左右边不齐 —— 上游两条定宽规则（源码确认 · 已实施 2026-10-19）

**成因查到了，不是本表写错，也不是随机数**：上游给顶栏和输入卡**各用了一条宽度规则**，两者互不参照。

| 面 | 宽度规则 | 出处（`dsh-client-ui-conversation/lib/client.js`，0.2.1-rc.2） |
|---|---|---|
| 顶栏 | 整列铺满，两侧各留 16px（本表 `margin: 12px 16px 0`） | `glass.module.css` 760 |
| 输入卡 | `max-width: var(--dsh-composer-card-max-width)`，居中 | `uV2eYG_card` |
| 而 | `--dsh-composer-card-max-width: calc(var(--dsh-chat-content-width) + 32px)` | `wSkVaW_body` |
| 而 | `--dsh-chat-content-width: var(--dsh-chat-user-width, clamp(680px, 列宽 × .64, 920px))` | 同上 |

`--dsh-chat-user-width` 是**正文列宽度手柄**写进内联样式的值，且**有上限**：

```js
resolveContentWidth(column, preference) {
  max = Math.max(CONTENT_MIN, column - CONTENT_EDGE_BUDGET);  // EDGE_BUDGET = 176
  return preference ? clamp(preference, CONTENT_MIN, max)
                    : Math.max(680, Math.min(column * .64, 920));
}
```

实测（列宽 1427.3）：正文列 1251.3 = **1427.3 − 176**，即手柄已拖到上限；输入卡 1283 = 1251 + 32；
顶栏 1395 = 1427 − 32。**每侧差 56px**（实测左 79 / 右 89 设备像素 = 53 / 59 CSS，那 6px 的左右
不对称来自 `scrollBody` 的 `scrollbar-gutter: stable`——卡在滚动容器里，顶栏不在）。

⚠️ 反直觉的一点：**不拖反而更不齐**。默认（无手柄偏好）正文列 = min(0.64 × 列宽, 920) =
913 → 卡 945，每侧差 **225px**。是「拖到最大」把差距从 225 缩到 56。

**已实施（2026-10-19，提交 `4c4ff21`）**。落地时发现原方案里的选择器读不到那个变量：
`--dsh-composer-card-max-width` 定义在 `.body` 上，而顶栏是 `.body` 的**兄弟**（`.root > header + .body`），
自定义属性只向下继承 ⇒ 原写法会永远命中外面的 fallback，等于没改。真正可读的源变量是
`--dsh-chat-user-width` / `--dsh-conversation-column-width`——`publishWidths()` 用
`container.parentElement` 把它们写在 `[data-phase]`（顶栏的父节点）上，于是顶栏可以自己再算一次：

```css
[data-dsh-glass-float] [data-phase] header:not([class*='headerBlank']) {
  margin: 12px auto 0;
  max-width: min(
    calc(var(--dsh-chat-user-width,
           clamp(680px, calc(var(--dsh-conversation-column-width, 1500px) * .64), 920px)) + 32px),
    calc(100% - 32px)
  );
}
```

- 表达式**内联在两个消费者里**，不抽成中间 custom property：#25 的失效传播陷阱——`--dsh-chat-user-width`
  在拖拽时每一帧都在变。
- 轨迹面板 `[data-dsh-glass-trajectory]` 上同一条上限并居中，否则一开「轨迹」tab 立刻又出现同款错位。
- 折叠侧栏那条回退成 `max-width: none; margin-right: 16px`——护栏状态需要硬左缩进 28px，
  `margin-inline: auto` 表达不了，这里保持改动前的满宽。
- 兜底：旧宿主（没有宽度手柄）用 `1500px` 哨兵让 clamp 落到 920 ⇒ **952**，正好是设计上限；
  窄列时 `min(…, 100% - 32px)` 保住原来的几何。
- ~~⚠️ **真机未验**：顶栏变窄后标题与标签行会向内收，窄窗口下要看一眼会不会挤。~~ → 见下节，
  真机一验就发现**⑤ 只做到了一半**。

#### 2026-10-21 真机复验：`max-width` 没有撑开盒子（已修 `width: 100%`）

**现象**（官方壳 `0.2.1-rc.2` / Electron 44.7.0 / mocha + mica / 1280×822 @ dpr 1.5，CDP 取证）：

| 状态 | 顶栏 | 输入卡 |
|---|---|---|
| 玻璃开（本皮肤） | **266px** @ left 647 | 856px @ left 349 |
| 玻璃关（摘掉 `data-dsh-glass-float`，= stock） | **1000px** @ left 280（整列铺满） | 856px |

⇒ 顶栏缩到只剩**内容宽度**，而且摘掉玻璃属性就恢复 1000px，证明是本皮肤造成的。

**根因**：上面那条规则里的 `margin: 12px auto 0`。`margin-inline: auto` 会把块级盒从
**stretch（铺满整列）** 降级成 **fit-content（包裹内容 + 居中）**；此时 `max-width` 只是**上限**，
永远不会把元素撑开。所以 ⑤ 只交付了「不许超过卡宽」，没交付「等于卡宽」。

**误判记录（值得留）**：复验第一轮我在 900 / 1280 都量到「顶栏 856 = 卡 856」，据此差点判定通过。
那两次命中的是**折叠分支**——`[data-sidebar-collapsed]` 下规则是 `margin: 28/16` + `max-width: none`，
固定 margin 不会触发 fit-content，块级盒照样 stretch，于是顶栏满宽（900 − 44 = 856），
看着「跟视口走」。**量顶栏宽度必须先确认 `[data-dsh-glass-frame]` 上有没有 `data-sidebar-collapsed`**，
两种状态的宽度机制完全不同。

**修法（两行，已实施）**：

```css
/* 展开态 */
width: 100%;          /* 恢复 stretch；随后被既有 max-width 收口到卡宽，margin:auto 保持居中 */
/* 折叠分支 [data-sidebar-collapsed] */
width: auto;          /* 那一支 margin 是固定 28/16，100% 会多出 44px 溢出 */
```

修后实测：1280 下顶栏 **856 @ left 352** vs 卡 856 @ 349；卡宽 756 的会话下同样 756 = 756。折叠分支保持原行为。

> **那 3px 的成因（2026-10-21 真机实测，已定案）**：原先记作「卡自身 border/padding」，**不成立**——
> 居中的 border box 不会因自带 border/padding 平移，而且两盒**同宽**（856 那次；1427px 列下都是 1283），
> 说明宿主是 border-box，没有内容盒膨胀。真因就是本节前半段自己记过的量测：卡在滚动容器里，
> `scrollBody` 宽 1425.3 / clientWidth 1421（`scrollbar-gutter: stable`，滚动条 4px），
> 卡在**窄 6.3px 的容器**里居中 ⇒ 比顶栏左移 3.4px。四条边都量了：
>
> | 量 | 顶栏 | 输入卡 | Δ |
> |---|---|---|---|
> | left | 352.2 | 348.8 | **+3.4** |
> | right | 1635.2 | 1631.8 | **+3.4** |
> | width | 1283 | 1283 | 0 |
>
> ⇒ **宽度是对的，只有居中基准差 3.4px**（卡在滚动容器里，顶栏不在）。stock 下卡相对列本来也偏这 3.4px，
> 只是没有第二条框可比。1283px 宽上 3.4px 不追。
>
> 同一会话同一壳（`0.2.1-rc.2` / Electron 44.7.0 / **Chromium 152.0.7977.130**）另测三条：
> ① **拖拽重算**：改 `--dsh-chat-user-width` 1283 → 732 → 1283，`max-width` 同步变，还原精确；
> ② **兜底分支**（摘掉该变量，等价 hero）：两盒都是 945.3，Δ 仍是 +3.3；
> ③ **折叠分支**（只临时加 `data-sidebar-collapsed`，不点 UI）：顶栏 1383.3 = 列 − 44，右边缘 −16 无溢出，
> `max-width: none` 生效，还原后与展开态完全一致。
> 探针：`.debug/frame-audit/probe-header-width.js`、`probe-drag-recompute.js`。

`tests/glass-css.spec.ts` 的
`⑤ sizes the top bar like the input card` 补两条断言（展开态必须有 `width: 100%`、折叠态必须
`width: auto`），**变异已验证**（删掉 `width: 100%` ⇒ 该用例红）。

轨迹面板不受影响：它本来就有显式 `width: calc(100% - 32px)`，不依赖 stretch。

### ⑥ 侧栏卡底边留白 —— **撤回，是量测错误**（2026-10-19 复核）

原来记的是「左 18 / 上 18 / 下 8 设备像素」。**8 是错的**：当时把窗口底部那条 8px 的亮边
（Windows 窗口边缘，不是页面内容）当成了内容边界。用三个已知量做标定后，底边其实是满的：

| 已知量 | 期望（设备像素） | 实测 |
|---|---|---|
| 侧栏左外边距 12px | 18 | 18 |
| 上边距 = 标题栏 40 + 12 = 52px | 78 | **78** |
| 下边距 12px（窗口高 1528） | 1528 − 18 = 1510 | **1510** |

三处全部逐像素吻合（标定比 = 1.5 设备像素/CSS px），所以**四边都是 12px，没有问题**。
卡片下缘外面那 8px 暗带是 `--dsh-glass-drop` 的投影，不是「更贴边」。
**不做任何改动**——按截图去补 bottom margin 反而会把另外三边一起推下去。

### ⑦ 菜单无框 vs 对话框有框 —— 同级浮层的语言分裂（源码确认 · 已实施 2026-10-19）

`#22 ③` 把菜单表面的 1px 框撤了（理由：Latte 下读成实框），但对话框保留 `--dsh-glass-rim`
（暗 24 / 浅 18%），气泡/产物块/turn-trigger 保留 `rim-soft`（暗 16 / 浅 12%）。于是「真浮层（菜单）」裸奔，
「流里的块」有边。

- 修法：只给暗色补回 `--dsh-glass-rim-soft`（`body[data-ds-dark-theme]` 分支），Latte 保持无框。
- 成本：1 条规则 + CDP 验 Latte 逐像素不变（否则就是重犯 #22 ③）。

## 3. 建议收敛成的阶梯

| 层级 | 圆角 | rim（暗 / 浅） | 投影 |
|---|---|---|---|
| 大面（顶栏 / 侧栏 / 轨迹 / 输入卡） | 20 | 16–30 / 12–30%（各有 CDP 证据，不动） | edge + drop |
| 模态对话框 | **20** | 24 / 18% | **edge + drop（补上）** |
| 浮层（菜单 / 气泡 / 产物块 / turn-trigger） | 14 | 16 / 12% soft（暗色菜单补回） | 无 |
| 控件（按钮 / 圆珠） | 10 | **≤ 该容器同档（不得亮于所在容器）** | edge |
| 原子（胶囊 / chip） | 8 | 无 | 无 |

一句话：①②③⑦ 已收口，剩下的 24（输入卡）是维护者确认的「主输入面亮一档」，属有意为之，不是破格。

## 4. 明确不要动的

- **dock 背板（#28 A）**：实测该带与地面 Δ2/255，肉眼不可见，符合「隐形背板」的设计意图，改它会破坏 #28 的结论。
- **输入卡 30% / 侧栏 16%（暗，浅色 12%）两个 rim 档**：各有 #22-follow-up 与 #26 的实测数字支撑，属于「看起来不统一但都有据」。
- **气泡无 backdrop-filter**（#13 模糊预算）、**菜单无框**（#22 ③ Latte 证据）：重开会推翻已结案的 issue。

## 5. 验证方式（真改了以后）

1. `pnpm typecheck && pnpm typecheck:tests && pnpm build`，再跑 `pnpm vitest run --no-file-parallelism`（基线已到 **346** 条）。
2. 改动只要落进 `glass-css.spec.ts` 锁过的选择器族（dialog / menu / composer / bubble），补一条护栏断言。
3. 真机 A/B：同一状态截两张（开/关该条），差异只应出现在该框自身，不牵动相邻面。
4. 四个风味 × mica/compat 各看一次 `rim` 与影（Latte 的影最明显，Mocha 的影最容易被吃掉）。
5. 没有真机也能先看**配方 A/B**：本机 Playwright 不可用，但 `chrome.exe --headless=new
   --screenshot=… --force-device-scale-factor=2 --window-size=… file:///…html` 可用（一次性截图，
   不需要 CDP、不需要装依赖）。规格页与出图：`.debug/frame-audit/ab-preview.html` /
   `ab-preview-trim.png`（**不入库**）。它按真实 token 复刻配方，能看几何与材质，**不替代真机**。

## 6. 实施记录（2026-10-19，提交 `27fd88f`）

| 条 | 改了什么 | 位置 |
|---|---|---|
| ① | mica 与 compat 的模态都补 `var(--dsh-glass-drop)`（与 edge 并列） | `glass.module.css` 对话框两处 |
| ③ | 模态 `border-radius: 20px`；**只限 `aria-modal='true'`**，通用 `[role='dialog']` 仍 14 | 同上 |
| ② | `[data-dsh-glass-surface]` 的 border 从 `--dsh-glass-rim` 降到 `--dsh-glass-rim-soft` | 新会话按钮座位 |
| ⑦ | 新增 `body[data-ds-dark-theme] [data-menu-material='translucent']:not(:focus-visible) { outline: 1px solid var(--dsh-glass-rim-soft); outline-offset: -1px }` | 菜单座位之后 |
| ⑤ | 顶栏与轨迹面板改用 `min(calc(var(--dsh-chat-user-width, …) + 32px), 100% - 32px)` + 居中；折叠栏回退满宽 | 顶栏 / 轨迹 / 折叠栏三条规则 |

护栏（`tests/glass-css.spec.ts` → `frame language: one rim ladder, one shadow language`）：

1. 两个模式的模态都必须带 edge **和** drop；
2. 模态在 20px 档、通用 dialog 仍在 14px 档（防「一刀切把弹层也抬高」）；
3. `[data-dsh-glass-surface]` 的 border 只能是 soft，且**必须存在**（防止反向退化成无框）；
4. 暗色菜单必须有一条 soft outline + `-1px` offset。同时原来的 `menuSeat` 守卫从「一律不许描边」
   放宽为「**只有暗色分支许描边，且必须是 soft**」——第 3 轮 Latte 的证据继续有效。

闸门：`pnpm typecheck` / `pnpm typecheck:tests` / `pnpm build` 全绿，
`vitest run --no-file-parallelism` → **346 passed（20 files）**（当时；2026-10-21 补 ⑤ 的护栏后为 **352 passed**）。

**真机验收（2026-10-21，官方壳 0.2.1-rc.2，Mocha + Latte × mica）**：上面点名的三处逐一过——
Latte 菜单 `outline: none`（逐像素不变，与『第 3 轮撤框』的结论一致）、Mocha 菜单
`1px solid soft(0.16) + offset -1px`（在密集代码正文上不显重）、Latte 模态投影不脏
（`inset 白 0.42 + 0 10px 32px`，截图见 `.debug/real-verify/settings-latte-crop.png`，不入库）。
**仍未跑**：Frappé / Macchiato × compat 的观感（只覆盖两风味 × mica 一模式）。

遗留：**④ 顶栏右侧三控件**（要先取 DOM 确认归属）；**⑥ 已撤回**（四边都是 12px，量测错误）。
⑤ 已实施并**真机复验**（2026-10-21）——复验发现它只做到一半，已补 `width: 100%`，见该节末尾。
