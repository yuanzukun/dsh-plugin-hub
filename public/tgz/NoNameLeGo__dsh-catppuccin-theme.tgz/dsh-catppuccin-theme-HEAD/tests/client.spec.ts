// @vitest-environment jsdom
/**
 * Client-side pure logic: flavour choice read/write fallbacks, the
 * built-in-preference restore pair (the "off restores what you had" fix),
 * and the settings-scope adapter (bind/read/persist + debounced writer).
 * The host-side mirror of the contract lives in the other specs; this file
 * only covers what the browser half owns.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  FLAVOR_STORAGE_KEY,
  RESTORE_STORAGE_KEY,
  builtinPickWins,
  flavorFromThemeId,
  flavorInfo,
  hostHasMenuBlur,
  menuSurfaceFor,
  overridesSnapshot,
  readExplicitFlavorOff,
  readFlavor,
  readOverrides,
  readRestoredPreference,
  rememberBuiltinPreference,
  writeFlavor,
  writeOverrides,
} from '../src/client/index.ts'
import {
  cancelDurablePersist,
  createBaseRevisionTracker,
  durableStateFromSnapshot,
  isScopeUsable,
  persistStateToScope,
  scheduleDurablePersist,
  type DurableScope,
  type DurableSnapshot,
  type WriteOutcome,
} from '../src/client/state-sync.ts'
import type { SettingsPathOpView } from '@deepseek-ai/dsh-api-remotes/client'
import { STATE_VERSION, defaultSettingsSection, defaultState, settingsSectionFromState } from '../src/state.ts'
import type { CatppuccinSettingsSection, CatppuccinState } from '../src/state.ts'

beforeEach(() => {
  localStorage.clear()
  vi.unstubAllGlobals()
  vi.useRealTimers()
})
afterEach(() => cancelDurablePersist())

describe('flavour choice', () => {
  it('maps registered theme ids to themselves and everything else to off', () => {
    expect(flavorFromThemeId('catppuccin-mocha')).toBe('catppuccin-mocha')
    expect(flavorFromThemeId('catppuccin-latte')).toBe('catppuccin-latte')
    expect(flavorFromThemeId('system')).toBe('off')
    expect(flavorFromThemeId('dark')).toBe('off')
    expect(flavorFromThemeId('')).toBe('off')
  })

  it('flavorInfo returns the registered entry only', () => {
    expect(flavorInfo('catppuccin-mocha')?.themeId).toBe('catppuccin-mocha')
    expect(flavorInfo('dark')).toBeUndefined()
  })

  it('reads back a persisted flavour; absent or unknown values mean off', () => {
    expect(readFlavor()).toBe('off')
    writeFlavor('catppuccin-frappe')
    expect(readFlavor()).toBe('catppuccin-frappe')
    localStorage.setItem(FLAVOR_STORAGE_KEY, 'not-a-flavour')
    expect(readFlavor()).toBe('off')
  })
})

describe('built-in preference restore', () => {
  it('remembers built-in preferences and ignores Catppuccin ones', () => {
    rememberBuiltinPreference('light')
    expect(localStorage.getItem(RESTORE_STORAGE_KEY)).toBe('light')
    // A flavour observation must not clobber the recorded built-in choice.
    rememberBuiltinPreference('catppuccin-mocha')
    expect(localStorage.getItem(RESTORE_STORAGE_KEY)).toBe('light')
    rememberBuiltinPreference('system')
    expect(localStorage.getItem(RESTORE_STORAGE_KEY)).toBe('system')
  })

  it('restores only a recorded light/dark, otherwise system', () => {
    expect(readRestoredPreference()).toBe('system')
    localStorage.setItem(RESTORE_STORAGE_KEY, 'dark')
    expect(readRestoredPreference()).toBe('dark')
    localStorage.setItem(RESTORE_STORAGE_KEY, 'junk')
    expect(readRestoredPreference()).toBe('system')
  })
})

describe('builtinPickWins (issue #6 restore guard)', () => {
  it('never lets "system" win over the persisted flavour', () => {
    expect(builtinPickWins('system', null)).toBe(false)
    expect(builtinPickWins('system', 'system')).toBe(false)
    expect(builtinPickWins('system', 'light')).toBe(false)
  })

  it('lets light/dark win only when explicitly picked this session', () => {
    expect(builtinPickWins('light', 'light')).toBe(true)
    expect(builtinPickWins('dark', 'dark')).toBe(true)
    // Boot/adopt-acquired values (no live pick recorded) never win — the
    // settings document's persisted light/dark must not bury the flavour.
    expect(builtinPickWins('light', null)).toBe(false)
    expect(builtinPickWins('dark', null)).toBe(false)
    // A live pick of the OTHER built-in value is not this preference.
    expect(builtinPickWins('light', 'dark')).toBe(false)
    expect(builtinPickWins('dark', 'light')).toBe(false)
  })

  it('non built-in preferences (flavour ids) never win', () => {
    // The runtime can hand the guard a flavour id as the live pick. Its second
    // parameter is typed narrowly (BuiltinPreference) on purpose — the test
    // reaches for that parameter type instead of widening production.
    type LivePick = Parameters<typeof builtinPickWins>[1]
    expect(builtinPickWins('catppuccin-latte', 'catppuccin-latte' as LivePick)).toBe(false)
    expect(builtinPickWins('catppuccin-mocha', null)).toBe(false)
  })
})

describe('overridesSnapshot stability', () => {
  it('keeps the same reference while unchanged and swaps only on content change', () => {
    writeOverrides({ '--a': '1' })
    const first = overridesSnapshot()
    expect(overridesSnapshot()).toBe(first) // stable reference (React store)
    writeOverrides({ '--a': '1' }) // same content — reference stays
    expect(overridesSnapshot()).toBe(first)
    writeOverrides({ '--a': '2' }) // content changed — new reference
    const second = overridesSnapshot()
    expect(second).not.toBe(first)
    expect(second).toEqual({ '--a': '2' })
  })

  it('drops keys that are not `--` tokens — one shape with the settings document', () => {
    // Regression: an unsanitized read left the non-token key in localStorage
    // only, so the hydration compared two different shapes, "the document wins"
    // overwrote the entry, and the user's row vanished one debounce-beat later.
    writeOverrides({ 'dsw-static-blue-500': 'red', '--dsw-static-blue-500': 'blue' })
    expect(readOverrides()).toEqual({ '--dsw-static-blue-500': 'blue' })
    expect(overridesSnapshot()).toEqual({ '--dsw-static-blue-500': 'blue' })
  })

  it('falls back to the same empty-map reference when absent', () => {
    const first = overridesSnapshot()
    expect(first).toEqual({})
    expect(overridesSnapshot()).toBe(first)
  })
})

/** Build a settings snapshot fixture (host-mode, resolved). */
function hostSnapshot(value: CatppuccinSettingsSection, user?: unknown): DurableSnapshot<CatppuccinSettingsSection> {
  return {
    status: 'ready',
    value,
    base: defaultSettingsSection(),
    user,
    revision: 1,
    writable: true,
    mode: 'host',
  }
}

/** Minimal scope double recording writes. The channel differences the real
 *  adapter hides (user-layer predicate, write fence) are irrelevant here: this
 *  double stands in for the bound channel itself. */
function scopeDouble(options: {
  snapshot?: DurableSnapshot<CatppuccinSettingsSection>
  write?: () => Promise<WriteOutcome>
} = {}): { scope: DurableScope<CatppuccinSettingsSection>; mutations: unknown[][] } {
  const mutations: unknown[][] = []
  return {
    mutations,
    scope: {
      kind: 'configForms',
      getSnapshot() { return options.snapshot ?? hostSnapshot(defaultSettingsSection()) },
      subscribe() { return () => {} },
      hasUserLayer: (snapshot) => snapshot.user !== undefined,
      write(ops: readonly SettingsPathOpView[]) {
        mutations.push(ops as never)
        return options.write !== undefined ? options.write() : Promise.resolve('accepted' as const)
      },
    },
  }
}

describe('isScopeUsable', () => {
  it('accepts only a resolved host-mode snapshot', () => {
    expect(isScopeUsable(hostSnapshot(defaultSettingsSection()))).toBe(true)
    expect(isScopeUsable({ ...hostSnapshot(defaultSettingsSection()), mode: 'memory' })).toBe(false)
    expect(isScopeUsable({ ...hostSnapshot(defaultSettingsSection()), status: 'loading' })).toBe(false)
    expect(isScopeUsable({ ...hostSnapshot(defaultSettingsSection()), status: 'unavailable' })).toBe(false)
  })
})

describe('durableStateFromSnapshot', () => {
  it('returns null unless the scope is usable and resolved', () => {
    expect(durableStateFromSnapshot({ ...hostSnapshot(defaultSettingsSection()), status: 'loading' })).toBeNull()
    expect(durableStateFromSnapshot({ ...hostSnapshot(undefined as never), status: 'unavailable' })).toBeNull()
    expect(durableStateFromSnapshot({ ...hostSnapshot(defaultSettingsSection()), mode: 'memory' })).toBeNull()
  })

  it('lifts a resolved section into the full state contract (re-sanitized)', () => {
    const snapshot = hostSnapshot(settingsSectionFromState(
      defaultState(),
    ), undefined)
    const state = durableStateFromSnapshot(snapshot)
    expect(state?.version).toBe(STATE_VERSION)
    expect(state?.flavor).toBe('off')
  })
})

describe('persistStateToScope', () => {
  it('writes one atomic mutation covering the whole section', async () => {
    const { scope, mutations } = scopeDouble()
    const state = { ...defaultState(), flavor: 'catppuccin-latte' as never, glass: { ...defaultState().glass, blur: 77 } }
    expect(await persistStateToScope(scope, state)).toBe('written')
    expect(mutations).toHaveLength(1)
    const ops = mutations[0] as { op: string; path: string[]; value: unknown }[]
    const byPath = Object.fromEntries(ops.map((op) => [op.path.join('.'), op.value]))
    expect(byPath['flavor']).toBe('catppuccin-latte')
    expect(byPath['glass.blur']).toBe(77)
    expect(byPath['glass.enabled']).toBe(false)
    expect(byPath['autoCheck']).toBe(true)
    expect(byPath['updateChannel']).toBe('latest')
    expect(byPath['overrides']).toEqual({})
    expect(byPath['shikiStyle']).toBe('default')
  })

  it('covers EVERY field of the durable section — a dropped op resets that knob', async () => {
    // Issue #26 post-mortem (2026-10-16): the ground-glow switch was wired
    // through the state type, the layer, the settings row, the Host schema and
    // the CSS — but NOT through `stateToMutateOps`. Nothing failed loudly: the
    // write simply omitted the field, the document kept its schema default, and
    // the client's next adoption reset the switch (measured on the live page:
    // the settings toggle flipped back within a second). This guard derives the
    // expected paths from the section ITSELF, so a new field cannot be silently
    // dropped again — a missing op shows up as a missing path, not as a UI bug.
    const { scope, mutations } = scopeDouble()
    const state = {
      ...defaultState(),
      flavor: 'catppuccin-latte' as const,
      glass: { ...defaultState().glass, glow: true },
    }
    expect(await persistStateToScope(scope, state)).toBe('written')
    const written = new Set(
      (mutations[0] as { path: string[] }[]).map((op) => op.path.join('.')),
    )
    /** Leaf paths of a plain nested object (an empty object counts as a leaf). */
    const leavesOf = (value: unknown, prefix = ''): string[] => {
      if (typeof value !== 'object' || value === null || Array.isArray(value)) return [prefix]
      const entries = Object.entries(value)
      if (entries.length === 0) return [prefix]
      return entries.flatMap(([key, child]) => leavesOf(child, prefix === '' ? key : `${prefix}.${key}`))
    }
    const expected = leavesOf(defaultSettingsSection())
    expect(
      expected.filter((path) => !written.has(path)),
      'these durable fields are never written, so the next adoption resets them',
    ).toEqual([])
    // Sanity: the derivation really does reach the new knob.
    expect(expected).toContain('glass.glow')
  })

  it('reports error when the write fails at the transport layer', async () => {
    const local = { ...defaultState(), flavor: 'catppuccin-mocha' as never }
    const flaky = scopeDouble({
      snapshot: hostSnapshot(defaultSettingsSection()),
      write: () => Promise.resolve('failed'),
    }).scope
    expect(await persistStateToScope(flaky, local)).toBe('error')
  })

  it('reports stale when the channel reports a refused write (item C/X)', async () => {
    // Only the 0.1.7+ channel can report this: the legacy controller resolves
    // a refused write silently, which is why the read-side guard exists.
    const local = { ...defaultState(), flavor: 'catppuccin-mocha' as never }
    const scope = scopeDouble({
      snapshot: hostSnapshot(defaultSettingsSection()),
      write: () => Promise.resolve('refused'),
    }).scope
    expect(await persistStateToScope(scope, local)).toBe('stale')
  })

  it('is a noop when the local state already equals the document', async () => {
    const local = { ...defaultState(), flavor: 'catppuccin-mocha' as never }
    const { scope, mutations } = scopeDouble({ snapshot: hostSnapshot(settingsSectionFromState(local)) })
    expect(await persistStateToScope(scope, local)).toBe('noop')
    expect(mutations).toHaveLength(0)
  })

  it('writes when the base revision matches the snapshot (no remote movement)', async () => {
    const { scope, mutations } = scopeDouble({ snapshot: { ...hostSnapshot(defaultSettingsSection()), revision: 7 } })
    const state = { ...defaultState(), flavor: 'catppuccin-mocha' as never }
    expect(await persistStateToScope(scope, state, { baseRevision: 7 })).toBe('written')
    expect(mutations).toHaveLength(1)
  })

  it('abandons a stale write-back when the document moved past the base revision (item C/X)', async () => {
    // Tab B committed a newer document: the snapshot revision moved from the
    // base (3) our local state was derived from to 4, and the remote section
    // is NOT our own last-written echo — the local write would clobber it.
    const remote = settingsSectionFromState({ ...defaultState(), flavor: 'catppuccin-mocha' as never })
    const { scope, mutations } = scopeDouble({
      snapshot: { ...hostSnapshot(remote), revision: 4 },
    })
    const state = { ...defaultState(), flavor: 'catppuccin-latte' as never }
    const outcome = await persistStateToScope(scope, state, { baseRevision: 3 })
    expect(outcome).toBe('stale')
    expect(mutations).toHaveLength(0)
  })

  it('still writes when the revision moved but the remote equals our own last write (echo)', async () => {
    // Our own just-committed write folded back into the mirror: remote is
    // the very section we wrote last, so the movement is not a conflict.
    const ours = settingsSectionFromState({ ...defaultState(), flavor: 'catppuccin-latte' as never })
    const { scope, mutations } = scopeDouble({
      snapshot: { ...hostSnapshot(ours), revision: 4 },
    })
    const state = { ...defaultState(), flavor: 'catppuccin-mocha' as never }
    const outcome = await persistStateToScope(scope, state, { baseRevision: 3, lastWrittenSection: ours })
    expect(outcome).toBe('written')
    expect(mutations).toHaveLength(1)
  })

  it('reports error for a not-ready or memory-mode snapshot', async () => {
    const scope = scopeDouble({
      snapshot: { ...hostSnapshot(defaultSettingsSection()), status: 'loading' },
    }).scope
    expect(await persistStateToScope(scope, defaultState())).toBe('error')
  })
})

describe('createBaseRevisionTracker (audit F2)', () => {
  it('keeps the FIRST revision of a burst and clears it on take', () => {
    const tracker = createBaseRevisionTracker()
    let revision = 3
    tracker.capture(() => revision)
    revision = 4 // the document moved on while the burst was still open
    tracker.capture(() => revision)
    expect(tracker.take()).toBe(3)
    expect(tracker.take()).toBeUndefined() // consumed — the next burst starts fresh
  })

  it('captures nothing when the scope has no revision yet', () => {
    const tracker = createBaseRevisionTracker()
    tracker.capture(() => undefined)
    tracker.capture(() => 5) // still unset → this one lands
    expect(tracker.take()).toBe(5)
  })

  it('turns an external edit inside the debounce window into a conflict, not an overwrite', async () => {
    // Timeline: we scheduled at revision 3, tab B committed a newer document
    // (revision 4) before the debounce elapsed. With the base captured at
    // SCHEDULE time the flush is abandoned as stale.
    const remote = settingsSectionFromState({ ...defaultState(), flavor: 'catppuccin-latte' as never })
    const { scope, mutations } = scopeDouble({ snapshot: { ...hostSnapshot(remote), revision: 4 } })
    const tracker = createBaseRevisionTracker()
    let revision = 3
    tracker.capture(() => revision) // ← schedule time
    revision = 4 // ← tab B's write lands during the debounce

    const state = { ...defaultState(), flavor: 'catppuccin-mocha' as never }
    expect(await persistStateToScope(scope, state, { baseRevision: tracker.take() })).toBe('stale')
    expect(mutations).toHaveLength(0)

    // Counter-factual (the old behaviour): a base sampled at FLUSH time is 4 —
    // identical to the guard's own read — so the stale write lands silently.
    const blind = scopeDouble({ snapshot: { ...hostSnapshot(remote), revision: 4 } })
    expect(await persistStateToScope(blind.scope, state, { baseRevision: 4 })).toBe('written')
    expect(blind.mutations).toHaveLength(1)
  })
})

/**
 * A channel double that models the 0.1.7 `ConfigFormController` fence instead of
 * stubbing it away (`dsh-client-ui-settings` `client.js`, `mutate`):
 *   revision = expectedRevision ?? pendingRevision ?? snapshot.revision,
 * the Host REFUSES when that revision is not the document's, an accepted write
 * folds its answer into the mirror, and a superseded write parks its revision in
 * `pendingRevision` for its queued successor. `scopeDouble` above ignores the
 * fence — which is exactly why the fast-switching bug could not show up in it.
 */
function fencedScopeDouble(initialRevision: number): {
  scope: DurableScope<CatppuccinSettingsSection>
  /** The revision each write actually committed under (or was refused at). */
  fences: number[]
} {
  let documentRevision = initialRevision
  let mirrorRevision = initialRevision
  let mirrorSection = defaultSettingsSection()
  let pendingRevision: number | undefined
  let generation = 0
  const fences: number[] = []
  /** Decode the atomic op list the way the Host folds it back. */
  const sectionFromOps = (ops: readonly SettingsPathOpView[]): CatppuccinSettingsSection => {
    const draft = JSON.parse(JSON.stringify(defaultSettingsSection())) as Record<string, unknown>
    for (const op of ops) {
      if (op.op !== 'set') continue
      const [head, ...rest] = op.path
      if (head === undefined) continue
      if (rest.length === 0) draft[head] = op.value
      else (draft[head] as Record<string, unknown>)[rest.join('.')] = op.value
    }
    return draft as unknown as CatppuccinSettingsSection
  }
  return {
    fences,
    scope: {
      kind: 'configForms',
      getSnapshot: () => ({
        status: 'ready',
        value: mirrorSection,
        base: defaultSettingsSection(),
        user: { glass: { mode: 'mica' } },
        revision: mirrorRevision,
        writable: true,
        mode: 'host',
      }),
      subscribe: () => () => {},
      hasUserLayer: () => true,
      write: async (ops, baseRevision) => {
        const current = ++generation
        const revision = baseRevision ?? pendingRevision ?? mirrorRevision
        fences.push(revision)
        if (revision !== documentRevision) return 'refused'
        documentRevision += 1
        mirrorSection = sectionFromOps(ops)
        if (current === generation) {
          pendingRevision = undefined
          mirrorRevision = documentRevision
        } else {
          pendingRevision = documentRevision
        }
        return 'accepted'
      },
    },
  }
}

describe('persistStateToScope — the write fence (fast switching, 2026-10-01)', () => {
  const withGlassMode = (mode: 'mica' | 'compat'): CatppuccinState => ({
    ...defaultState(),
    glass: { ...defaultState().glass, enabled: true, mode },
  })

  it('does not fence with a base revision our own write already moved past', async () => {
    // Reported: "switching mica/compat quickly sometimes fails". The base is
    // captured when the burst is SCHEDULED; a write of ours that lands inside
    // the burst moves the document on, so the captured base is stale by flush
    // time. Fencing with it makes the Host refuse a write that must succeed →
    // `stale` → the caller adopts the remote state → the newest switch is
    // silently reverted. The channel must resolve the fence itself.
    const { scope, fences } = fencedScopeDouble(5)
    const compat = withGlassMode('compat')
    const mica = withGlassMode('mica')

    // Burst 1 (the user picks compat): base captured at schedule time = 5.
    expect(await persistStateToScope(scope, compat, { baseRevision: 5 })).toBe('written')

    // The write committed under revision 6 and folded back into the mirror. The
    // user switches to mica at once; this burst captured its base BEFORE that
    // echo (still 5) while the document is already at 6. The movement is our
    // own echo, so the guard passes it — and the write must land.
    const outcome = await persistStateToScope(scope, mica, {
      baseRevision: 5,
      lastWrittenSection: settingsSectionFromState(compat),
    })
    expect(outcome, 'the fast second switch was reverted as a conflict').toBe('written')
    // Old behaviour forwarded the stale base twice ([5, 5]) and the second was
    // refused at the Host's fence; now the channel fences with what it knows.
    expect(fences).toEqual([5, 6])
  })

  it('still abandons a write whose movement is NOT our own echo', async () => {
    // The guard must stay a conflict detector: revision 6 holds someone else's
    // section, so the local change is stale and must not be written at all.
    const { scope, fences } = fencedScopeDouble(5)
    const theirs = withGlassMode('compat')
    expect(await persistStateToScope(scope, theirs, { baseRevision: 5 })).toBe('written')
    const local = withGlassMode('mica')
    const outcome = await persistStateToScope(scope, local, {
      baseRevision: 4, // a base from before THEIR write, and not our echo
      lastWrittenSection: settingsSectionFromState(defaultState()),
    })
    expect(outcome).toBe('stale')
    expect(fences, 'a stale write must never reach the wire').toEqual([5])
  })
})

describe('readExplicitFlavorOff (audit F4)', () => {
  it('is true only for a literal off — an absent value is not a choice', () => {
    expect(readExplicitFlavorOff()).toBe(false)
    writeFlavor('catppuccin-mocha')
    expect(readExplicitFlavorOff()).toBe(false)
    writeFlavor('off')
    expect(readExplicitFlavorOff()).toBe(true)
  })
})

describe('scheduleDurablePersist debounce', () => {
  it('coalesces a burst into one flush of the freshest write', async () => {
    vi.useFakeTimers()
    const writes: string[] = []
    let value = 'catppuccin-latte'
    scheduleDurablePersist(() => { writes.push(value) }, 300)
    value = 'catppuccin-mocha'
    scheduleDurablePersist(() => { writes.push(value) }, 300)
    await vi.advanceTimersByTimeAsync(299)
    expect(writes).toHaveLength(0)
    await vi.advanceTimersByTimeAsync(1)
    expect(writes).toEqual(['catppuccin-mocha'])
  })

  it('cancelDurablePersist drops the queued write', async () => {
    vi.useFakeTimers()
    const writes: string[] = []
    scheduleDurablePersist(() => { writes.push('x') }, 300)
    cancelDurablePersist()
    await vi.advanceTimersByTimeAsync(1000)
    expect(writes).toHaveLength(0)
  })
})

describe('host menu blur probe (0.1.7 vs the 0.1.5 latest line)', () => {
  // `--dsw-specific-menu` only became translucent in the release that also
  // introduced `--dsw-menu-backdrop-filter: blur(40px) saturate(150%)`
  // (0.1.7-alpha.1 — the 0.1.6-alpha.1 tag still carries the opaque ladder step
  // and no blur token). On a host without the blur the generated 58%/50% fill
  // would be plain transparency over the transcript, so registration injects
  // the opaque ladder step there — never the literal upstream grey.
  function stubComputedStyle(map: Record<string, string>): void {
    vi.spyOn(window, 'getComputedStyle').mockReturnValue({
      getPropertyValue: (name: string) => map[name] ?? '',
    } as CSSStyleDeclaration)
  }

  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('keeps the flavour translucent fill when the host declares the menu blur', () => {
    stubComputedStyle({
      '--dsw-mask-blur': 'blur(2px)',
      '--dsw-menu-backdrop-filter': 'blur(40px) saturate(150%)',
    })
    expect(hostHasMenuBlur()).toBe(true)
    // {} means "leave palettes.ts alone" — the translucent Catppuccin fill.
    expect(menuSurfaceFor(true)).toEqual({})
  })

  it('falls back to the opaque ladder step on hosts without it', () => {
    stubComputedStyle({ '--dsw-mask-blur': 'blur(2px)' })
    expect(hostHasMenuBlur()).toBe(false)
    expect(menuSurfaceFor(false)).toEqual({
      '--dsw-specific-menu': 'var(--dsw-alias-bg-layer-3)',
    })
  })

  it('distrusts a host whose theme stylesheet is not in the cascade', () => {
    // The sanity probe (`--dsw-mask-blur` exists in every supported host) fails,
    // so the safe answer wins even though the blur token happens to read back.
    stubComputedStyle({ '--dsw-menu-backdrop-filter': 'blur(40px) saturate(150%)' })
    expect(hostHasMenuBlur()).toBe(false)
  })

  it('is inert before a body exists', () => {
    // The DOM types say body is always an element, but it is genuinely null
    // while the document is still parsing — hence the cast.
    vi.spyOn(document, 'body', 'get').mockReturnValue(null as unknown as HTMLElement)
    expect(hostHasMenuBlur()).toBe(false)
  })

  it('is inert without computed styles at all', () => {
    vi.stubGlobal('getComputedStyle', undefined)
    expect(hostHasMenuBlur()).toBe(false)
  })
})
