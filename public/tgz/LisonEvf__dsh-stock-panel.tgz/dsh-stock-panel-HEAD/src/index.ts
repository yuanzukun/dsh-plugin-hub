/**
 * @lisonevf/dsh-stock-panel — host 半入口（Cordis fiber）。
 *
 * 由 `dsh.bundle.patch`（cordis.patch.yml）在宿主启动时加载，把本插件注册成
 * Cordis entry。host 半只做业务侧三件事：
 *
 *   1. 暴露插件元数据（视图槽 / 视图 id / 排序）给宿主与 browser 半；
 *   2. 注册内置 TDX 桥接路由（POST /api/stock-panel/call，进程内 node-tdx 直连）；
 *   3. 注册对话行情工具（ctx.tools，当前对话助手可直接取数分析）。
 *
 * **host 半不再触碰宿主的任何文件。** v1.1 及以前这里会同步运行 ui-layout 布局
 * 补丁引擎（self-heal 打「stock 第四列」并落 pristine 备份）；v1.2 起界面注入
 * 全部改走官方槽位（browser 半注册 `conversation.view`），补丁引擎、锚点表、
 * CLI 与 `$DSH_HOME/patches` 备份均已删除。
 *
 * 真正的 React UI 由 browser 半（src/client.ts）通过官方
 * `conversation.view` 槽在浏览器端渲染。
 */
import { getOwnPropertySafe, registerEmbeddedTdxBridge, type HostCtx } from './host-util'
import { registerStockTools } from './host-tools'
import { registerBuildInfoRoute } from './host/build-info'
import {
  closeStateDomain,
  initStateDomain,
  noteStateInjectDeclared,
  noteStateInjectFired,
  registerStateBridge,
} from './host/state'
import { disposeTdxClient, callEmbeddedTool } from './host/tdx-data'
import { aiAvailability, registerAiBridge, resolveAiRuntime, resolveModelRoute, type AiRuntime } from './host-ai'
import { registerNamingBridge } from './host/naming/route'
import type { NamingRuntime } from './host/naming/run'

/** 本插件注册的会话视图身份（与 src/client.ts 的 VIEW_* 常量保持一致）。 */
export const VIEW_SLOT = 'conversation.view'
export const VIEW_ID = 'stock-panel'
export const VIEW_ORDER = 6

/** 插件契约（host 半暴露给 browser 半和宿主）。 */
export interface StockPanelContract {
  /** 视图宿主槽位（ui-conversation 声明）。 */
  readonly viewSlot: 'conversation.view'
  /** 视图 id（被 ui-conversation 持久化为会话首选视图）。 */
  readonly viewId: 'stock-panel'
  /** 视图标签页排序键。 */
  readonly viewOrder: number
}

/**
 * Cordis entry 元数据（loader 按此装配 fiber）：
 *   - name：entry 名（patch insert 引用的包名）
 *   - inject：声明需要的运行时服务 → ctx.webServer / ctx.tools 才会被注入
 *     （注册 /api/stock-panel/call 内置 TDX 桥接路由与对话工具的前提；缺了它
 *     getOwnPropertySafe 永远拿到 undefined，桥接静默不注册）。
 */
export const name = '@lisonevf/dsh-stock-panel'
export const inject = ['webServer', 'tools']

/** host 半插件体。ctx 由 Cordis host 运行时注入。 */
export function apply(ctx: HostCtx): (() => void) | void {
  // 暴露插件元数据给宿主和 browser 半。
  ctx.provide('stock-panel-host', {
    name: '@lisonevf/dsh-stock-panel',
    viewSlot: VIEW_SLOT,
    viewId: VIEW_ID,
    viewOrder: VIEW_ORDER,
  })

  // 内置 TDX 桥接：host 半在服务端进程内用 node-tdx 直连 TDX（无远端 MCP、
  // 无外部进程）。browser 半通过同源 route 调用：
  // 路由：POST /api/stock-panel/call  body: {"tool": name, "args": {...}}
  // 注意：ctx.webServer 是 Cordis 服务，未注入时访问会抛异常，用 getOwnPropertySafe 安全访问。
  const ws = getOwnPropertySafe(ctx, 'webServer')
  if (ws) {
    registerEmbeddedTdxBridge(ws as NonNullable<HostCtx['webServer']>)
    // 构建信息（版本 + 构建 id）：浏览器据此检出「跑着旧构建」。
    registerBuildInfoRoute(ws as NonNullable<HostCtx['webServer']>)
    // host 侧持久化（A1）：GET/POST /api/stock-panel/state。
    registerStateBridge(ws as NonNullable<HostCtx['webServer']>)
  }

  // host 侧持久化（A1）：**不能**把 `storageDomain` 写进静态 inject —— 那是可选增强（同 llm 立场），
  // 缺存储时若整个插件不激活，行情链路会一起死。
  // 但**必须**用声明感知的 `ctx.inject(['storageDomain'], cb)`：真机两轮实测证明
  //   ① cordis 的服务只有被声明过才在该 ctx 上可见（未声明 → 读不到，惰性重试也没用）；
  //   ② 回调**必须使用它给的 scoped ctx** —— 服务挂在 scoped ctx 上，外层 ctx 依然没有它。
  // 另加请求路径惰性重试（state.ts 的 ensureStateReady），覆盖服务晚挂的情况。
  initStateDomain(ctx)
  const injectFn = getOwnPropertySafe(ctx, 'inject')
  if (typeof injectFn === 'function') {
    // 只有真的能声明时才标记「已声明」——诊断字段必须如实（否则排查会被自己误导）。
    noteStateInjectDeclared()
    ;(injectFn as (deps: string[], cb: (scoped: unknown) => void | (() => void)) => unknown)(
      ['storageDomain'],
      (scoped) => {
        noteStateInjectFired()
        // ⚠️ 用 scoped ctx（不是外层 ctx）：服务只在该作用域上可见。
        initStateDomain(scoped ?? ctx)
      },
    )
  }

  // 对话行情工具（chat 联动，零 FastAPI）：当前对话助手可直接调用取数分析。
  // ctx.tools 经 inject 声明就绪；仍做安全兜底，失败不影响桥接。
  registerStockTools(getOwnPropertySafe(ctx, 'tools') as HostCtx['tools'] | undefined)

  // 一键问模型（AI 视角）：host 半直调官方 ctx.llm，把结构化结论回给视图。
  // llm / agentDefaultModel **刻意不列进 inject**——它们是可选增强，缺了只是按钮置灰，
  // 不该拖累 TDX 桥接与对话工具的加载（见 host-ai.ts 顶部说明）。
  const aiRuntimeOf = (): AiRuntime => resolveAiRuntime(ctx)
  if (ws) {
    registerAiBridge(ws as NonNullable<HostCtx['webServer']>, aiRuntimeOf)
    const avail = aiAvailability(aiRuntimeOf())
    if (avail.available) {
      console.log(`[stock-panel] AI 直调可用：${avail.provider}/${avail.model}`)
    } else {
      console.log(`[stock-panel] AI 直调不可用（${avail.reason}）——面板「AI 研判」按钮将置灰，不影响行情。`)
    }
  }

  // 自挖类命名（A2b）：host 半移植 cluster-namer 口径，用同一份 ctx.llm 直调。
  // 与 AI 直调同立场：llm 缺省只是「命名」不可用，不影响行情与个股视角。
  if (ws) {
    registerNamingBridge(ws as NonNullable<HostCtx['webServer']>, () => namingRuntimeOf(ctx))
  }

  // 卸载（fiber dispose / 进程退出 / 插件被移除）：释放内置 TDX 长连接 + 关闭持久化域。
  return () => {
    disposeTdxClient().catch(() => undefined)
    closeStateDomain().catch(() => undefined)
  }
}

/**
 * 命名运行时（A2b）：复用 AI 直调的模型解析，另外提供
 *   ① 工具调用 = 内置 TDX（进程内，无远端依赖）；
 *   ② `ensureToday` = 用 `server_info.today` 取当前交易日（决定实时源能否代表 as_of）。
 * `server_info` 结果按 60s 缓存：命名按钮是人工动作，不需要每次打一次数据层。
 */
let todayCache: { value: string; at: number } | null = null
async function currentTradingDay(): Promise<string | undefined> {
  if (todayCache !== null && Date.now() - todayCache.at < 60_000) return todayCache.value
  try {
    const info = (await callEmbeddedTool('server_info', {})) as { today?: unknown } | null
    const t = info?.today
    if (typeof t === 'string' && t.length >= 10) {
      todayCache = { value: t.slice(0, 10), at: Date.now() }
      return todayCache.value
    }
  } catch {
    /* 取不到就返回 undefined：采集层会保守地不采实时源，并说明原因 */
  }
  return todayCache?.value
}

function namingRuntimeOf(ctx: HostCtx): NamingRuntime {
  const ai = resolveAiRuntime(ctx)
  const route = resolveModelRoute(ai)
  return {
    callTool: (name, args) => callEmbeddedTool(name, args),
    llm: ai.llm as NamingRuntime['llm'],
    route: route ?? undefined,
    ensureToday: currentTradingDay,
  }
}

/** 暴露给 browser 半的 host 服务实现（供后续服务端代理场景使用）。 */export const hostService = {
  name: '@lisonevf/dsh-stock-panel',
  viewSlot: VIEW_SLOT,
  viewId: VIEW_ID,
  viewOrder: VIEW_ORDER,
}

// 内置 TDX 服务导出（脚本/冒烟/诊断复用同一实现）。
export { callEmbeddedTool, tdxEmbeddedDiagnostics, disposeTdxClient } from './host/tdx-data'
// HIST 引擎直调（脚本/冒烟复用：`callHistTool(fn, name, args)` 可注入假数据钩子离线跑，
// 见 scripts/smoke-concept-classes.mjs —— 类列表的「强度/涨幅/涨停数」就是在这条链路上补的）。
export { callHistTool } from './host/hist-data'

// AI 直调导出（诊断/脚本复用）。
export { runAiTask, aiAvailability, resolveAiRuntime, registerAiBridge } from './host-ai'
// 自挖类命名（A2b）导出：脚本/冒烟复用同一实现（依赖注入，可离线跑）。
export {
  DEFAULT_BATCH,
  DEFAULT_NAMING_PARAMS,
  clearNamingCache,
  nameClass,
  nameClasses,
  namingAvailability,
  namingCacheStats,
  // 素材源清单（单一真源）：冒烟脚本按它核对"每个源都给出了状态"，
  // 而不是把 4/5 这种数字各自写一遍（README 的"19 工具"就是这么漂移的）。
  NAMING_SOURCES,
} from './host/naming/run'
export { registerNamingBridge } from './host/naming/route'
export { DEFAULT_NAMING_GUARD } from './host/naming/types'
// 构建信息导出（诊断/脚本复用）。
export { hostBuildInfo, registerBuildInfoRoute } from './host/build-info'
// 工具清单唯一定义源：冒烟脚本按它核对"是否每个工具都被覆盖"（此前 README 说 19 工具冒烟、
// 脚本只跑 12 个，两边长期不一致）。
export {
  CONVERSATION_TOOLS,
  CONVERSATION_TOOL_NAMES,
  EMBEDDED_TOOLS,
  EMBEDDED_TOOL_NAMES,
  EXTENDED_MARKET_TOOLS,
} from './lib/tool-names'
// host 侧持久化导出（诊断/脚本复用）。
export {
  buildStateSpec,
  closeStateDomain,
  decodeStateKey,
  encodeStateKey,
  initStateDomain,
  markMigrated,
  registerStateBridge,
  stateDelete,
  statePut,
  stateSnapshot,
  stateStatus,
} from './host/state'
// 持久化表清单导出：验收脚本按它核对"服务端的表 = 本仓库声明的表"，
// 而不是各自写死 8/9 张（实测已经漂移过：代码 9 张、verify-live 断言 8 张 → 真机必失败）。
export { STATE_TABLES, STATE_TABLE_MAP } from './lib/state-tables'
// AI 契约（prompt 组装 / 容错解析 / 上下文裁剪）导出：供 scripts/smoke-ai-contract.mjs 离线回归。
export { buildAiPrompt, parseAiResult, extractJsonObject, contextBytes, shrinkContext } from './lib/ai-contract'
