#!/usr/bin/env node
/**
 * check-bundle-size.mjs — client.js 体积护栏（M11，CI 用）。
 *
 * 说明：client.js **默认 minify**（B2 决策，2026-09-12）；同时产出 `lib/client.js.map`
 * 补偿可调试性 —— 宿主 client-modules 层会读取该 map 并校验为 Source Map v3，
 * 再盖章自己的组合 map URL（map 缺失不影响插件执行）。逃生阀：`CLIENT_MINIFY=0`。
 * 阈值默认 665KB（env CLIENT_MAX_KB 可覆盖）。
 *
 * 体积账：
 *   665KB   1.1.x 基线（窄列版：10 个页面全内联，未压缩）
 *   ≈687KB  1.2.0（官方 conversation.view 化）
 *   ≈757KB  1.3.0（宽视图重排：三段式骨架 + 盯盘工作区 + AI 双通道 + 跟随 DSH 主题）
 *           其中 CSS 字符串 45.6KB（压缩前 ≈69KB，minifyCss 已回收 23KB）
 *   796.7KB 1.4.0 合并发布（+ 构建可见性 / ladder 共享缓存 / B6 修复）
 *   814.0KB 1.4.0+A1（host 侧持久化）→ 当时阈值 820 → 840KB（余量只剩 2%）
 *   825.8KB 1.4.0+B5③（诊断面板）
 *   **530.8KB 1.4.0+B2（开启 minify；−35.7%）→ 阈值 840 → 600KB（余量 69KB）**
 *   605.4KB 1.4.0+UX-B2（令牌收口 / 单位单一入口 / 图表主题 / 三态组件）
 *           → 阈值 600 → **620KB**（余量 14.6KB）。这是一次**有意识的**加预算：
 *           新增的都是"减少重复"的共享模块（`lib/theme-colors` `lib/chart-theme`
 *           `components/Num` `components/StateView`），它们替换掉的是散在 20+ 文件里的
 *           重复实现；下一轮减重仍按下面的杠杆（退役旧页面 / 删过渡重映射层）。
 *   632.1KB 1.4.0+UX-B3（草稿持久化 / ErrorBar / hotkeys 纯函数 / ConfirmButton）
 *           → 阈值 620 → **650KB**（余量 17.9KB）。同样是有意识加预算：本批新增的是
 *           「切换/点票不再丢草稿」「错误可分类可重试」「键盘可达」这三类体验修复的载体。
 *           ⚠️ 体积棘轮已连续两批上调（600→620→650），下一批应优先做**减重**（退役
 *           被新骨架取代的旧页面是最直接的杠杆），而不是继续加预算。
 *   620.1KB 未提交的自挖板块 / 行情页批次之后（本批的起点，工作树实测值）
 *   651.2KB 1.6.0 作战板块重做（模型给作战思路：素材组装 + 素材护栏 + 思路卡片 + 采纳写回）
 *           → 阈值 650 → **665KB**（余量 ~14KB）。这一笔账必须写清三件事：
 *           ① 净增 ~31KB，其中 **9KB 是本批自己找回来的**：client 侧对 `ai-contract`
 *              的**值**引用（一个 `emptyWarPlanGuard()` / `contextBytes()` 就把四个任务的
 *              prompt 模板整份打进包）与 `war-plan-guard`（护栏只需 host 侧权威执行）
 *              都已清除 —— 前者是本批引入的错，后者是顺手纠正的架构错位；清理口径：
 *              client 只引 `ai-contract` 的**类型**，上下文体积由 host 经
 *              `AiCallMeta.contextBytes` 回传；
 *           ② 剩下的 ~22KB 是"作战页主产物"本身：把行情/自挖板块/选股/复盘/竞价/持仓
 *              组装成素材、把护栏剔除的东西显示出来、思路卡片、以及"模型给默认 + 人可改"
 *              的写回 —— 它是本页唯一会指挥下单的输出，不许靠省字节来省掉透明度；
 *           ③ **下一批必须减重**（棘轮已连续三批上调）。真杠杆按大小排：
 *              ReviewPage（60KB）/ ConceptClassesCard（40KB）/ CSS 过渡重映射层；
 *              注意 StockDetailPage / WatchlistPage 当前**已无引用、不在包内** ——
 *              删它们只是卫生，不是减重手段。
 *
 * 成分（`node scripts/bundle-report.mjs`，未压缩口径 822.5KB）：
 *   lightweight-charts 216.8KB(26%) · src/pages 175.9KB(22%；ReviewPage 单文件 51.8KB)
 *   · src/components 136KB(17%) · src/lib 125.7KB(16%) · 内联 CSS 44.6KB(5.5%)
 *   压缩口径：minify 527.4KB（64.1%）· gzip(未压缩) 179.8KB · gzip(minify) 141.8KB
 * 结论：体积大头是「我们的代码 + 图表库」，不是可随手砍的零碎 —— 先用 minify 拿回
 * 35% 的确定收益；后续减重靠 A5（token 迁移、退役旧页面）与死代码清理。
 *
 * ⚠️ 逃生阀 `CLIENT_MINIFY=0` 下体积会**超护栏**（≈825.8KB）：这是预期行为，护栏卡的是
 * 「随包分发的体积」。本地要读产物时用 `CLIENT_MAX_KB=900 CLIENT_MINIFY=0 pnpm build`。
 *
 * 为什么不能靠"拆分"瘦身：插件契约要求 client bundle 是**单模块**（flat module
 * graph，见 README §技术要点），esbuild 无法 code splitting —— 视图不能动态 import。
 * 因此唯一有效杠杆是**减少内联代码**：
 *   1. 退役被新骨架取代的旧页面（StockDetailPage / WatchlistPage 等），逐个删除；
 *   2. 迁移页面到 --dc-* token 后删掉 index.css.txt 的过渡重映射层；
 *   3. 控制新依赖（lucide 已按需 tree-shake；不要再引入图表库/动效库）。
 * 护栏的作用是拦住"顺手引入大依赖"，而不是限制正常功能增长——但每次上调阈值
 * 都要在这里留一行账。
 */
import { existsSync, statSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const file = join(resolve(__dirname, '..'), 'lib', 'client.js')
const maxKb = Number(process.env.CLIENT_MAX_KB ?? 665)

if (!existsSync(file)) {
  console.error('[check-bundle] 缺 lib/client.js —— 请先 pnpm build')
  process.exit(1)
}
const kb = statSync(file).size / 1024
console.log(`[check-bundle] lib/client.js = ${kb.toFixed(1)} KB（护栏 ${maxKb} KB）`)
if (kb > maxKb) {
  console.error(`[check-bundle] ✗ 超限 ${(kb - maxKb).toFixed(1)} KB —— 见本文件顶部的体积账与瘦身杠杆`)
  process.exit(1)
}
console.log('[check-bundle] ✓ 通过')
