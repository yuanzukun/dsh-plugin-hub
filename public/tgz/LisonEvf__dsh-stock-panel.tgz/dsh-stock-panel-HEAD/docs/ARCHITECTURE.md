# ARCHITECTURE — 架构与数据流

> **@lisonevf/dsh-stock-panel** 的实际架构与关键约定。定位与界面见 `README.md`，待做项见 `docs/ROADMAP.md`，历史计划见 `docs/archive/`。
> ✅=现状已实现；⏳=规划中（带对应 ROADMAP 编号）。

## 1. 双半结构与构建

```
@lisonevf/dsh-stock-panel
├── host 半（Node，tsdown/rolldown → lib/index.js）
│   ├── src/index.ts        Cordis entry：inject ['webServer','tools']；provide 视图元数据（槽/ID/order）+
│   │                       registerEmbeddedTdxBridge(/call)、registerStockTools(8)、registerAiBridge(/ai)、registerStateBridge(/state)、
│   │                       registerBuildInfoRoute(/build)、registerNamingBridge(/naming)
│   ├── src/host/tdx-data.ts   内置 node-tdx 服务：连接管理 + serial 串行队列 + 19 工具分发
│   ├── src/host/hist-data.ts  内置 HIST 自挖概念引擎（惰性单例，快照 TTL 3600s）
│   ├── src/host/naming/       自挖类命名（A2b，移植 cluster-namer）：guard/prompt/parse/fingerprint/materials/collect/run/route —— 纯函数 + 依赖注入，可离线跑全链路
│   ├── src/host-ai.ts         一键问模型：官方 ctx.llm + agentDefaultModel + 自愈重试
│   ├── src/host-tools.ts      对话工具定义（**8 个**：行情 4 + HIST 4；raw ToolDefinition）
│   ├── src/host/state.ts      host 侧持久化（DSH 存储子系统 stock_panel 领域 + /state）
│   └── src/host-util.ts       ctx 安全访问 + 桥接路由注册
└── browser 半（esbuild + tailwind → lib/client.js，**必须单模块**）
    ├── src/client.ts        apply(ctx)：注入样式 + slots.inject('conversation.view') + 诊断句柄
    ├── src/panel/           三段式骨架（AppShell/StatusStrip/WatchList/AiPanel/use-ai/hooks）
    ├── src/views/           一级入口落地（ViewHost 单页渲染 / StageReviewView / StageWarView / WatchView / StageHead）
    ├── src/pages/components 页面与组件
    └── src/lib/             领域逻辑与状态层（selection/cache/market/ladder/…）
```

约束（契约级，不能违反）：

| 约束 | 原因 |
| --- | --- |
| host 半不得 import 浏览器专用模块；client 半不得 import Node 模块 | 两个 bundle 分别在 Node 与浏览器执行 |
| client bundle 必须 flat module graph（**不能 code splitting**） | 插件运行时契约 → 体积只能靠减少内联代码，见 `scripts/check-bundle-size.mjs` 头部体积账 |
| 视图注册只用 `ctx.slots.inject('conversation.view', …)` | 声明感知：宿主 apply 早晚都成立，声明消失/HMR 自动装卸 |
| `llm` / `agentDefaultModel` **刻意不列进 inject** | 它们是可选增强：宿主没挂 LLM 服务时只置灰按钮，不拖累行情链路 |

产物与体积（2026-09-12 实测；client 半默认 minify，B2）

| 产物 | 大小 | 护栏 / 说明 |
| --- | --- | --- |
| `lib/client.js` | 见 `node scripts/check-bundle-size.mjs` 输出（随批次变） | 护栏 **650 KB**（`CLIENT_MAX_KB` 可覆盖）——**护栏数字单一来源 = 该脚本** |
| `lib/client.js.map` | 1.65 MB | 不随 npm 包发布（`files` 未列）；宿主 client-modules 会读取它做 sourcemap |
| `lib/index.js` | 232,618 B（227.2 KB） | 无护栏（ROADMAP B2 待补；A2b 命名模块 +50 KB） |
| `lib/index.js.map` | 489,372 B | 不随包发布 |

成分（`node scripts/bundle-report.mjs`，未压缩 822.5 KB）：`lightweight-charts` 216.8 KB(26%) · `src/pages` 175.9 KB(22%) · `src/components` 136 KB(17%) · `src/lib` 125.7 KB(16%) · 内联 CSS 44.6 KB(5.5%)。minify 后 527.4 KB（64.1%）；gzip：未压缩 179.8 KB / minify 141.8 KB。

## 2. 数据链路 ✅

```
Browser                        host 半（dsh web 进程内）              行情源
invokeTool(name,args)  ──POST──▶ /api/stock-panel/call
  （src/lib/mcp.ts，25s 超时）    └─ callEmbeddedTool(name,args) → serial() 串行队列 ──▶ node-tdx（opentdx.js）
                                     · TDX 长连接 TCP 7709/7727 · 19 工具分发 + 输出归一化
                                     · hist_concept_* → HistEngine（惰性重建）
```

- **错误语义**：业务错 → `{ok:false, kind:'business'}`；未知工具 → `kind:'unsupported'`；连接不可达/禁用 → `kind:'unavailable'`。前端**如实展示**，不回退任何远端服务。
- **遗留 http 模式**：`window.__DSH_TDX_TRANSPORT__='http'` 时改走自建 python 网关（`gateway/`，默认 `127.0.0.1:8017`，15s 超时）。默认 embedded；`DSH_TDX_EMBEDDED=0` 可在 host 侧禁用内置。
- **单一配置源**：端点/模式全部收口在 `src/lib/endpoints.ts`（host env + client window 两个入口）。
- 排障与字段语义见 `MCP-SETUP.md`；诊断句柄见 §8。

### 2.1 自挖概念管道（HIST → 命名 → UI）✅ A2

| 阶段 | 事实 |
| --- | --- |
| ① 发现（内置） | `src/host/hist-data.ts` → HistEngine：池 = 全 A 成交额榜前 `pool_n`（默认 200）→ QFQ 日线 → 60 日残差收益 → Pearson 相关 → 聚类（有 scipy 走 hclust，纯 JS 路径自动降级阈值图）。输出 `classes[]`（class_id/size/mean_intra_corr/members）+ `isolated[]` |
| ② 命名（✅ A2b） | `src/host/naming/` + GET/POST `/api/stock-panel/naming`。素材 = 成员的涨停/异动（unusual/market_monitor）+ 所属板块（belong_board）+ 日K推导的封板状态；约束：素材**只用于解释，不进聚类输入**（否则退化回「按官方花名册分组」）。模型复用 `ctx.llm`（缺 LLM 只置灰命名，不影响行情）。护栏：证据必须可反查（引文比对 + 时间窗 + 覆盖度 + 可计算证据分）→ 不达标即降级。verdict 三态：named / no_common / insufficient（+降级成因分层）。缓存：进程内 key=`asOf:classId:fingerprint`（指纹含模型/窗口/源集合/提示词版本/阈值） |
| ② 批量（★ 类列表默认路径 `nameClasses`） | 一次**并集**采集 → 按成员数分批问模型（`maxMembersPerCall`）→ 逐组独立过护栏。批次只影响请求次数，**不放松任何一组的严格性**（跨组借证据会被拒；模型漏给某组结论 → 如实降级，不替它补）；整批另有 memo，重复打开 = 只再读一次类表（`llmCalls: 0`）。批量与单类提示词版本不同 → 缓存互不冒充 |
| ②b 强度（✅ 2026-09-12） | `hist_concept_classes` 出来时已带**成员 + 均涨幅 + 涨停数 + 强度**（`host/hist-data.ts` 的 `enrichClasses`；纯函数在 `lib/concept-strength.ts`）：涨停 = 收盘触及涨停价（`buy_price_limit`，与状态带广度同法；无涨跌幅限制的新股不计入）；强度 = 均涨幅% + 6×涨停数（权重是显式常数，单测钉住），排序与显示**同源**；成本 = 每类一次 `classMembers` + 一次全A快照（与引擎 `snapshotA` **共用 60s memo**，不重复拉 ≥2MB） |
| ②c 可采信判据（✅ 2026-09-14） | `lib/concept-quality.ts`（host/client 共用纯函数）：引擎的 `weak_chain` 之外再拦一类**传递链巨类**（实测漏网样本：52 只 / 类内相关 0.428 / 强边密度 0.14 而 `weak_chain=false`）。判据 = `强边密度 < 0.5` **且** `类内相关 < 实际切边阈值` 两条同时成立（单看任一条会误杀真小班）。界面按它过滤并**计数**、命名路径按它拒绝（`reason: "pseudo_class"`，与 `weak_chain` 分开报）—— 两条路径必须同一判据，否则会出现"列表里看不到、但它有名字" |
| ②d 结构标签（✅ 2026-09-14） | `host/naming/structure.ts`（纯函数）：成员所属官方行业/概念板块里被 **≥2 只成员**共享的词 → 「这个班像什么」。**不经模型、不依赖新闻、任何 `as_of` 都成立**；从批量命名**已采到的语料**里算（0 额外请求、0 额外模型调用），与模型看到的素材逐字同源。与模型主题名**并列**回传（不塞进 `NamingResult.result`：那个字段受护栏约束，模型不可用时会连 theme 一起清空，而这正是它要解决的场景），界面永远标出来源 + 覆盖度 |
| ③ 呈现（✅ A2b，版面重做 ✅ 2026-09-14） | 类列表 `ConceptClassesCard` 是「自挖板块」**一级入口**（打开即自动批量命名归类、按强度降序、行内给涨幅/涨停数/成员，并显示本轮模型调用次数与缓存命中）。版面：一行三列骨架（左 强度数值+相对强度条+排名 │ 中 名称+来源胶囊+覆盖度+指标行+成员网格 │ 右 证据/重命名），成员默认截断 12 只 + 「+N 只」展开、按当日涨幅降序，颜色全走 `--dc-*` token（跟随宿主明暗主题；收口前是 tailwind 固定色阶，暗色下是一块刺眼补丁）。结论展示共用 `NamingResultPanel`（三态 + 证据分 + 逐条引文 + 采集口径偏差 + **结构标签对照**）。⚠️ **个股卡 `StockConceptCard`（"这只票今天跟谁一起动"）当前没有挂载点** —— 它只被 `StockDetailPage` 引用，而 A6 已摘掉该整页的入口（文件留着但**不进 bundle**，tree-shaking 实测确认：`lib/client.js` 里搜不到它的任何字符串）。**数据源是通的**（真机实测 `hist_concept_query` 可用、冷启动 ~6s），缺的只是一个挂载点 —— 挂回「工作台」要把它连同 `NamingResultPanel` 拉进 client bundle，体积只剩 ~13KB 余量，属独立一批（见 ROADMAP A2）。**不做**：与官方行业的重合度对照（v0 边界） |

**⚠️ 时间性**：异动/主力监控是**当日实时列表（无历史接口）** → 仅当 as_of = 当前交易日才采；板块归属是当前快照（照用但标注）；封板状态由日K推导（可回放）。

**前置门槛（✅ A2a 已完成，2026-09-12）**：默认参数输出退化（`min_corr=0.45` 切出一个 ~141 只的「传递链」巨类、类内相关仅 0.027）→ 已完成**参数校准 + 弱链过滤 + 跨日稳定性**取证，**推荐默认 `pool_n=200 · window=90 · min_corr=0.6` 且无条件过滤 `weak_chain=true`**；校准后语义自洽（电力/地产/工程机械/面板/白酒…，类内相关 0.57–0.81），相邻交易日 9 个类 Jaccard=1.00。完整证据与对 A2b 的形态约束见 **`docs/CONCEPT-CALIBRATION.md`**。

## 3. 前端状态层 ✅

| 层 | 位置 | 职责 | 约定 |
| --- | --- | --- | --- |
| **当前标的 + UI 状态** | `src/lib/selection.ts` | 唯一真源：selection / view / 栏显隐 / K 线窗口 / 阶段覆盖 | 模块级 store + localStorage（`stock-panel:ui:v4`，含 v3/v2/v1 迁移）+ 订阅 + `useUi()` |
| **SWR 缓存** | `src/lib/cache.ts` | `useSwr(key, fetcher, {ttl, refreshInterval, enabled})`：fresh 命中零请求 / stale 先回后刷 / 失败驱逐 + 重试冷却 / in-flight 去重 | key 全部由 `swrKey` 工厂生成；**不提供 AbortSignal**（已知限制） |
| **全 A 快照** | `src/lib/market.ts` | `fetchAllA(force)`：20s TTL，`force=true` 绕过 | ✅ 与 `cache.ts` 已统一为 `swrFetch`（B5） |
| **领域 store** | `watchlist-store` / `review-store` / `dayrun` / `positions` / `alerts` / `event-stream` / `ai` | 各自 localStorage + 订阅（**已迁 host 域，见 §5.2**；localStorage 今为镜像/降级兜底） | 键表见 §5.1 |
| **派生纯函数** | `ladder` / `regime` / `situation` / `strength` / `review-metrics` / `screener` / `chips` / `indicators` | 无 IO，阈值全部是「可配置初值 + 自校准」 | 方法论要求：**禁止把阈值当常数用** |

### 3.1 轮询与请求预算（⚠️ 已知架构债）

轮询点共 21 处（13 个 SWR `refreshInterval` + 8 个 `setInterval`）。按代码常量推算（非实测采样）：

| 来源 | 频率 | 量级 |
| --- | --- | --- |
| 常驻基线（指数 15s ×9 / 全A 30s / 时钟 60s / 异动 30s×3 / 当前标的 12s） | — | **≈50 次/分** |
| 作战页每轮：server_info + captureOnce(6) + 全A + **ladder（≤1 + ≤160）** + 板块脉冲(≤8) | 30s | **≤177 次/轮 → ≤354 次/分** |
| 监控规则（AlertWatcher，12s，≤10 只） | 12s | ≤50 次/分 |

**合计 ≈200–400 次/分（3.4–6.7 req/s），其中约 90% 是 ladder。** 三个成因：① `src/lib/ladder.ts` 原**无缓存**却被 3 个调用方各自重算（作战页 30s / 梯队页 30s / 复盘页一次性）；② 指数曾用 **3 个独立 15s 定时器**共享同一 SWR key（状态带 / AI 上下文 / 指数页）；③ 除 `AlertWatcher` 外无轮询检查 `document.hidden`，左右栏 HTML `hidden` 收起时组件仍挂载 → 轮询照跑。三者均已修（见 §9 第 1/3/4 条），对策与验收锚点见 `docs/ROADMAP.md` B3。

## 4. 视图与导航（A6 后）✅

- **一级导航 = 复盘 / 作战 + 各板块平铺**（`PRIMARY_VIEWS`：复盘、作战、行情、自挖板块、选股筛选、监控规则、外盘）。A4 的「工具」中间层已拆除：板块本就各自独立取数、各自有轮询节拍。主区渲染在 `views/ViewHost.tsx`（`switch(view)` 单页挂载）。
- **默认入口 = 行情**（`DEFAULT_VIEW`）：无落盘状态（首次安装 / 清过浏览器状态）时首屏就停在「行情」；已落盘的 `view` 优先。默认值**必须在 `PRIMARY_VIEWS` 里** —— 否则首屏状态带没有任何一项高亮（`tests/selection.test.ts` 钉住）。时段边界仍会自动跟随（`AppShell` 的时段驱动）。
- **「工作台」（原「看盘」）不在导航栏上**（`WORKBENCH_VIEW`）：它是"点左栏任一行 / 任意页面点股票"落到的默认主区（`openStockAndWatch` → `view: 'watch'`），所以**没有键位、也不占导航**。
- **宿主会话列外壳适配**（`lib/host-chrome.ts`）：宿主 `ui-conversation` 在插件视图**之上**画了两样东西 —— ① 两条贯穿全屏高度的「正文栏宽度」拖拽条（`.wSkVaW_widthHandle`，`position:absolute;top:0;bottom:0;z-index:8;cursor:col-resize`，用途是拖 `--dsh-chat-user-width`）；② 底部对话输入框座位（`[data-composer-seat]`，`position:sticky;bottom:0;z-index:7`）。它们对**满宽**的工作台不成立（拖拽条会压住面板左右边缘并接管点击/拖拽，且宿主渲染它只判 `phase === 'active'`）。处置（用户决策：两样都不要）：**视图挂载期间**给 `<body>` 打标记 `data-dc-workbench`（挂载 ⟺ 选中：ui-renderer 按 `only: active.id` 过滤视图条目），由 `index.css.txt` §9 的 CSS 把那两条拖拽条与底部对话输入框一起隐藏（后者让出的高度归主区；输入框只 `display:none`、不卸载，插件「深入对话」的 `setDraft + submit` 照常能发并给回执）。宿主文件一个字节都不改；依赖的宿主钩子（`[data-width-handle]` / `[data-composer-seat]`）失效时只退化为"什么都没隐藏"，`window.__STOCK_PANEL__.chrome()` 会报出实况。
- **左栏两组 = 自选 / 个股**（手工观察池 + 最近看过，`viewed-store` 自动积累上限 30）。自选与个股**不再各有整页**（旧「自选盘」「个股明细」两个工具页已下线）：左栏就是它们的入口，点行即看 —— 涨停/异动分组同样早已下线（涨停走「行情」页的涨停梯队块、异动走「行情」页的市场异动块）。
- **点行 = 看它**：`openStockAndWatch()`（设标的 + 切到工作台）→ 主区立刻是这只票的个股信息（报价头 / 日K⇄分时 / 自挖板块 / 资金·逐笔·竞价 / 右栏 AI）。
- **行情页是一屏仪表盘**（A4 合并 → 2026-09-14 重排）：`MarketPage` 把「环境 / 指数 / 涨停梯队 / 榜单 / 异动」组合成一屏，整页不滚动、各块内部滚动。三个旧 id（`overview`/`indices`/`ladder`）由 `viewIdOf()`/`LEGACY_VIEW_IDS` **就地映射到 `market`**（否则老用户落盘的旧值会被静默丢弃 → "页面打不开"）。
  - **为什么重排**（真机测量，主区 780px）：旧的三块并排（总览 4 / 指数 5 / 梯队 3）落到 2 列、只有两行 395px，逐块量「内容高 / 可视高」= 总览 **1391/363（藏 74%）**、梯队 **2174/363（藏 83%）**、指数 363/363（0%，图自适应）。也就是说"一屏看完"当时只对指数成立，另外两块各是一个独立滚动条；而同一个数出现两三遍（总览 2×2、梯队 2×2、状态带各一份），实测整页 innerText 里「涨停」出现 **19 次**。重排后：藏 0% / 19% / 0% / 0%，「涨停」5 次。
  - **组合**：① **环境带**（全宽 6 格 KPI + 一条涨跌分布横条）——把两个 2×2 的并集合成一处；② 主行：**指数**（含图）│ **涨停梯队**；③ 底行：**榜单**（4 张 2×2）│ **市场异动**。环境带与底行按内容给高度，主行吃剩余（图表自适应）。
  - **列数按容器实测宽度**（`ResizeObserver`）而非视口断点：DSH 左栏 + 右 AI 栏都在时，视口 2560px 的面板可用宽度可能只有 600px。≥1120 → 三列（指数 │ 梯队 │ 榜单，异动横跨整行）；≥760 → 两列；否则单列（改回整页滚动 + 每块最小高度）。栅格位次写在 `index.css.txt` §4c（`.dc-mkt-grid.is-{1,2,3}col`），不在组件里拼 `col-span-*`。
  - **数据归属只有一处**：全 A / 异动由**页面**持有（环境带与榜单要的是同一份全 A），涨停梯队的连板统计只由 `LadderPage` 算并经 `onStats` 上报（页面**不重算** —— 那是最贵的一段）；指数与梯队各自取自己的数。
  - **每块自带**：本块刷新时间（`onUpdatedAt` 回传）+ 单块刷新 + 折叠开关（折叠即卸载 → 该块轮询立刻停止）。
- **A2b 落点（已定）**：自挖板块的主视角**设计上是个股卡**（"这只票今天跟谁一起动"直接可用），类列表是「自挖板块」一级入口（`PRIMARY_VIEWS` 里紧跟行情）。之所以这么分：校准后绝大多数票是孤立票，「类列表」信息量薄。⚠️ **现状**：A6 摘掉「个股明细」整页后个股卡失去挂载点（见 §2.1 ③，真机实测确认不可达）；**当前唯一可达的呈现是类列表**。
- **持久化要求**：视图被卸载（切到「对话」）后回来必须保持标的/视图位置 —— 所有 UI 状态都在 `selection.ts` 落盘（`stock-panel:ui:v4`；旧 `limit`/`unusual` 分组值由 `leftGroupOf()` 收敛到「自选」，旧工具页值由 `viewIdOf()` 收敛到对应入口）。**唯一一次例外是 v3 → v4 的落点重置**（`initialViewOf(persisted, fromLegacy)`：读到旧键时统一落到 `DEFAULT_VIEW`（行情），因为 A6 换了 IA 与默认入口）；写回 v4 之后不再重置。「个股」历史列表在 `viewed-store`（表 `viewed`）。
- **请求预算纪律**：A6 之后**一次只有一个一级入口被挂载**（`ViewHost` 的 `switch`，不是一排 `hidden` 容器 —— `display:none` 不停轮询，只有卸载才停）。任何"把多个重页面拼在一屏"的改动都要先算这笔账（涨停梯队单轮 ≤177 次调用）—— 行情仪表盘为此定了五条纪律（写在 `MarketPage` 头注释）：① **全页只有一个节拍器**（15/20/30/60s 或暂停，由 `tick` 驱动各块强制验证）—— 这一条**曾经是假的**（审计项 I-b：三块自带的 20/15/30s 定时器都没关，实测 4 个定时器同时在跑，页头却在说"共用一个节拍器"），现在由 `MarketPage` 给各块传 `pollMs={0}` 兑现，并由 `scripts/ux-contract.mjs` 的 `market-single-metronome` 钉住；② **块可折叠**，折叠即卸载 → 该块轮询立刻停止；③ **离开视野停轮询**（`enabled=false`）+ **滚到可见才挂载**（`IntersectionObserver`，`rootMargin 240px` 预热），单列退化态下这一条真正省请求；④ 页面自己持有的数据源用 `refreshInterval: 0` 而不是 `enabled:false` —— 后者会让 `useSwr` 的调度 effect 直接 return，连 `refresh()` 也失效（手动刷新会静默失灵）；⑤ 默认节拍取 **30s**，页头把「轮询中 N/4 + 节拍 + 上次刷新时间」摊开显示，让代价可见。涨停梯队即使被更快节拍驱动也走自己的 30s 共享缓存 → 实际仍是 ~30s 一轮。

## 5. 持久化

### 5.1 localStorage（18 键；现为镜像 / 离线兜底）✅

| 键 | 归属 | 版本/迁移 | 校验 |
| --- | --- | --- | --- |
| `stock-panel:ui:v4`（+ v3 / v2 / view:v1 旧键） | `selection.ts` | ✅ v3→v4（**落点重置**为行情）、v2→v3、v1→v3 | 逐字段 |
| `stock-panel:nav` | `selection.ts`（`UI_KEY_GUARD`） | — | 存在性守卫（防"清了状态还装作记得"） |
| `dsh-stock-panel:review:v3`（+ v2 旧键） | `review-store.ts` | ✅ v2→v3（非破坏） | sanitize + 60 日截断 |
| `dsh-stock-panel:review-draft:v1` | `review-draft.ts` | — | 逐字段 |
| `dsh-stock-panel:ai-verdict:v1` | `ai.ts` | — | 形状校验 + 80 条上限 |
| `dsh-stock-panel:watchlist:v1` | `watchlist-store.ts` | — | 市场白名单 + ≤60 |
| `dsh-stock-panel:viewed:v1` | `viewed-store.ts` | — | 市场白名单 + ≤30 |
| `dsh-stock-panel:alerts:rules:v1` / `:hits:v1` | `alerts.ts` | — | 过滤 + ≤200 |
| `dsh-stock-panel:events:v1` | `event-stream.ts` | — | 去重 + ≤500 |
| `dsh-stock-panel:dayrun:v1` | `dayrun.ts` | — | 过滤 + ≤60 日 |
| `dsh-stock-panel:positions:v1` / `:tradelog:v1` | `positions.ts` | — | ⚠️ 仅 `Array.isArray` |
| `stock-info-bar-fields` | `stock-info-fields.ts` | ⚠️ 无版本 | 非空 |

问题：3 种命名空间、只有 2 个键有迁移、`removeItem` 全仓只出现 1 次（无「清空/重置」）、无导出导入、清缓存即失忆、跨设备不同步。

### 5.2 host 侧持久化（DSH 存储子系统）✅ A1

DSH 的 `dsh-base` 已挂载存储栈（**本 profile 直接可用，无需额外安装**）：

| 行 | 包 | 作用 |
| --- | --- | --- |
| `storage` | `@deepseek-ai/dsh-storage` | 枢纽 `ctx.storage`（后端注册 + 数据形式挂载） |
| `storage-json` | `@deepseek-ai/dsh-storage-json` | json 后端，root = `$DSH_HOME/storages` |
| `storage-domain` | `@deepseek-ai/dsh-storage-domain` | 领域数据形式 `ctx.storageDomain`（backend: json） |

**用法**（host 半，`src/host/state.ts`，✅ 已实现）：`initStateDomain(ctx)` → `ctx.inject(['storageDomain'], scoped => initStateDomain(scoped))` → `registerStateBridge(ws)`（GET/POST `/api/stock-panel/state`）。`storageDomain` **不写进静态 inject**（可选增强，同 `llm` 立场：缺服务时只降级为 localStorage，不该让整个插件不激活）。

**⚠️ 服务访问的两条真机教训**（各踩了一轮）：① cordis 的服务只有被 `inject` 声明过才在该 ctx 上可见 —— 最初改用 `getOwnPropertySafe(ctx,'storageDomain')` 完全不声明，真机永远读不到、惰性重试也救不了；官方消费方 `dsh-session-projection-cache` 用静态 `inject:['storageDomain',…]`，我们改用 `ctx.inject([...], cb)` 达到同样效果并保留"缺存储不连带禁用行情"的韧性。② 回调**必须使用它给的作用域 ctx** —— 服务挂在 scoped ctx 上，外层 ctx 依然没有它（第一轮只因传了外层 ctx 而真机仍 `available:false`）。另保留**请求路径惰性重试**（`ensureStateReady()`，不缓存否定结论），覆盖服务晚挂。

回归用例：`smoke-host-state.mjs` `[6]`（服务晚到自愈）`[7]`（挂在 hub 上）`[8]`（**只挂在 scoped ctx 上**也必须可用 —— 模拟真实 cordis 作用域语义）`[9]`（不可用时必须交代 inject 声明与回调触发情况）。辅助解析：`ctx.storageDomain`，兜底 `ctx.storage.domain`（文档：两者是同一个对象）。

**两条硬约束（实测确认，踩过）**：① 领域名/表名必须匹配 `UNIT_NAME_RE = ^[a-z][a-z0-9_]*$` —— **不能有连字符**，所以领域名是 `stock_panel`（不是 `stock-panel`）；② 公开 npm 上的 `@deepseek-ai/dsh-storage-domain` 只有 `0.0.1-rc.1`，而宿主跑 `0.1.2-rc.1` → **不 import 它**（`defineDomain` 只是「校验 + 身份函数」）。运行期契约实测只有三处：`descriptorOf(spec)`（读 name/version/tables 键/hasGlobal/layout）、`spec.tables[t].valueSchema.parse(raw)`、`spec.global.schema.parse(stored)` / `initial`。因此**手搓 spec** + 一个只需 `parse`/`safeParse` 的极简 schema，零依赖、不与宿主 zod 副本耦合。

**领域形态**：`name: 'stock_panel'`、`version: 1`（**固定**）、`layout: 'per-record'`（事件流追加频繁，逐记录文档避免「每次写重发整个 unit」）、`invalidRecords: 'backup-and-skip'`（单条脏记录被移开并跳过，**不让整域打不开**）、`global = { schemaVersion, migratedFromLocalStorage, updatedAt }`。

**版本与 schema 演进策略**（前两条是**用宿主真实存储栈跑出来的**，见 §8 校验脚本）：

| # | 策略 |
| --- | --- |
| 1 | `version` **固定为 1**，绝不因字段变更上调。⚠️ 实测语义与直觉不同：per-record 布局下每条记录落盘为 `{ "version": N, "record": {...} }`，**version 不一致不会报错，而是把旧记录静默丢弃**（打开成功、记录数为 0）—— 静默丢数据比报错更糟，所以这是硬要求 |
| 2 | 真要升版本，必须同时声明 `compatibleVersions: [旧版本…]`（官方逃生口，实测有效：`version: 2 + compatibleVersions: [1]` 打开仍能读到 version=1 的记录） |
| 3 | 日常演进用 global 的 `schemaVersion` + 启动迁移遍历（版本保持不变） |
| 4 | 记录校验只做**介质边界最小校验**（必须是 JSON 对象 + 关键字段是字符串），语义校验留在各 store 载入时 —— 严 schema 会让「加字段」变成「老记录被拒 → 整域打不开」 |
| 5 | 破坏性变更 = 换**表名**（如 `review_v2`），启动时把老表读出来重写后删除 |
| 6 | **记录键必须编码**：per-record 布局把键当文件名，要求匹配 `^[a-zA-Z0-9_-]+$`，不匹配直接抛错。我们的自然键含 `:` 与中文（事件流的 `SH-600519-10:03-封涨停板`）→ host 层用 `encodeStateKey()` 做 base64url 编解码，对客户端完全透明 |

**12 张表**（清单单一来源 `src/lib/state-tables.ts`，host/client 共用）：`watchlist`（自选）、`review`（复盘存档，键=交易日）、`review_draft`（复盘草稿）、`dayrun`（当日运行/Q1-Q3/竞价判定）、`positions`（持仓）、`tradelog`（交易日志）、`verdicts`（AI 结论，键=`day:SYMBOL`）、`war_plans`（**作战思路，键=`day:stage`** —— 它是"用户按它下单"的那份东西、也是单价最高的一次模型调用，只留内存等于每次回作战页都重烧一次）、`events`（事件流，键=事件指纹）、`viewed`（看过的个股，A4 左栏「个股」分组的数据源）、`alert_rules`（监控规则）、`alert_hits`（监控命中记录）。

**前端接入（✅ 已实现，`src/lib/host-state.ts`；各 store 的对外 API 零改动）**：

```
浏览器                                           host 半
启动（client.ts 的 apply）：GET /api/stock-panel/state
  → 域里有记录 → 覆盖 localStorage 镜像 + 记指纹；该表为空而本地有数据 → 一次性首迁上传（POST {records}）
  → 通知各 store 重载（onHostHydrated）        ─▶ 域是权威，镜像只是缓存
读：  同步内存读（沿用 getWatchlist() 等原 API，UI 零改动）
写：  ① 内存立即更新 + notify  ② localStorage 镜像（离线可读）
      ③ syncTable(表, 值)：与上次指纹**差量**比对 → POST {table, records?, deletes?} ─▶ domain.table(t).put/delete
降级：路由 503 / 无 storageDomain / 网络错 → 只写 localStorage；底栏显示「持久化：本地」+ 悬浮给原因（`hostStateInfo()`）
```

- **差量同步**：按表维护 `记录键 → JSON 指纹`；只推新增/变化/删除。事件流（上限 500 条）每 30s 有一次捕获，全量重推等于每轮 500 个请求 —— 差量后通常只有几条。推送失败会把指纹回滚，下一轮重试仍带上这批差异。
- **写入形状**：`state-tables.ts` 的 `shape`（`array` = 逐条拆记录；`keyed` = 本就是键值表，如 AI 结论存档），记录键由 `keyOfRecord()` 从记录自身推导（复用各 store 的自然键）。
- **首次迁移**：域为空 + 本地有数据 → 上传并置 `global.migratedFromLocalStorage=true`。
- **仍在 localStorage**：UI 偏好与信息条列配置（「这台机器的界面状态」，不属于跨日资产）。
- **已知限制**：`domain/changed` 只在本进程内；多标签页/多设备以 host 为权威但**无实时推送**（同机多标签各自持有内存态，最后写入者胜）。跨标签一致性留待后续（可选：SSE 推 `domain/changed`）。
- **收益**：数据随 DSH 家目录（`$DSH_HOME/storages`）存活，清缓存/换设备不失忆；为「复盘校准」「自挖概念命名缓存」这类跨日资产提供可靠底座。
- **离线门禁**：`scripts/smoke-host-state.mjs`（host 半：路由 / spec 契约 / 读写闭环 / 降级）与 `smoke-client-view.mjs` 的 `[3b]`（客户端降级路径）都已进 CI。

## 6. AI 契约 ✅

| 环节 | 位置 | 约定 |
| --- | --- | --- |
| 路由解析 | `host-ai.ts` | 优先宿主的 `ctx.agentDefaultModel.currentSelection()`，插件侧兜底；无 LLM → `{available:false, reason}` |
| prompt + 解析 | `lib/ai-contract.ts`（host/client 共用） | 任务化：`stock-verdict` / `review-plan` / `scout-rank` / **`war-plan`（作战思路）**；模型只回一个 JSON；解析做去围栏/配平/夹取；**原文永不丢** |
| **素材护栏**（仅 `war-plan`） | `lib/war-plan-guard.ts`（host 半执行） | 模型只能点名**素材里出现过的票**（`positions`/`watchlist`/`ladder`/`myPlan`/`concepts.members`/`boards.rep`）、只能用**逐字取自素材的板块名**（`sectorUniverse`）、引文要能逐字/数字反查；越界的**剔除并回传**（`plan.guard`），不静默丢弃 |
| 上下文压缩 | `lib/ai.ts` | 报价 + 近 90 根日 K + 资金流 + 广度 + 指数 → 小 JSON（四舍五入 + 截尾），>24KB 先自愈裁剪；作战思路的素材由 `lib/war-plan-collect.ts` 组装（行情 / 自挖板块 / 选股 / 复盘 / 竞价 / 持仓 / 自选 → ≤24KB，条数上限见 `MATERIAL_CAPS`） |
| 自愈重试 | `host-ai.ts` | `maxTokens` 是 reasoning+正文共享预算（≥6000）；`finish=max-tokens` 或超限 → 裁一档重试（≤3 调用 / ≤3 裁剪，分开计数），`meta.shrunk` 回传并由 UI 提示 |
| 通道 B | `client.ts` slot props | `inputActions.setDraft + submit()` 注入当前对话；输入框有草稿时置灰（不覆盖用户内容） |
| 落点 | `panel/AiPanel.tsx` 等 | 只读参考区 + 逐条采纳；**绝不静默改写用户草稿** |
| 作战思路的落点 | `lib/war-plan.ts` 的 `adoptWarPlan` | 三问/持仓动作/竞价判定按**只填空位**写进 `dayrun`，全部标 `from:'ai'`；人工答案一律保留；驳回走 `dayrun.clearAiAnswers` |

⚠️ **client 只引 `ai-contract` 的类型**：一个值引用（例如 `emptyWarPlanGuard()` / `contextBytes()`）
就会把四个任务的 prompt 模板整份打进 client bundle（体积护栏实测抓到过 ≈9KB）。上下文体积由
host 经 `AiCallMeta.contextBytes` 回传给 UI。

✅ 已修（B6）：`panel/use-ai.ts` 的 AbortController 现在把 `signal` 一路传进 `lib/ai.ts`（`fetch(..., { signal })`），AI 请求可中断。

## 7. 设计立场（不可违背）

1. **时段驱动**：界面回答「现在该干什么」，而不是「有哪些功能」；跨过 9:15 / 14:30 / 15:10 自动切入口，用户手动干预后本会话不再跟随。
2. **主区四层信息**：① 环境 ② 主线 ③ 标的 ④ 动作——归不进这四层的进工具页（`PRODUCT-DESIGN.md` §6c）。
3. **AI 不覆盖用户草稿**：排序/命名/研判都是只读参考，采纳必须用户点一下。
4. **不假装精度**：实算 vs 近似的口径必须标在界面上（复盘盘眼的琥珀小字是范例）；裁剪/降级要显式告知。
5. **阈值即初值**：所有方法论阈值（温度分档、强度判定、凯利分数）都是可配置初值 + 自校准，禁止当常数。
6. **不引入重依赖**：client 半单模块且体积只剩 2.9% 余量——新增依赖必须在 PR 说明体积成本。

## 8. 诊断与可观测

| 手段 | 位置 |
| --- | --- |
| `window.__STOCK_PANEL__`（version / viewRegistered / transport / endpoints / listTools / callTool / watchlist / hostState / **chrome**） | `src/client.ts`（`chrome()` = 宿主外壳适配实况：标记有没有打上、两条宽度拖拽条还剩几条/藏掉几条、对话框座位在不在） |
| `GET /api/stock-panel/ai` | AI 可用性与解析出的路由 |
| `GET /api/stock-panel/naming` | 命名能力与**口径**：模型路由 / 提示词版本 / 默认参数（window·min_corr·pool_n）/ 护栏阈值 / 采集预算 / 缓存条数 / 当前交易日 |
| host 日志 | `[stock-panel] embedded TDX bridge registered at /api/stock-panel/call`、AI 可用性行、`命名桥接已注册：/api/stock-panel/naming` |
| 冒烟脚本 | `scripts/smoke-{client-view,host-state,ai-contract,naming}.mjs`（离线、已进 CI）+ `scripts/smoke-embedded.mjs`（需真机行情） |
| **实机验收** | `node scripts/verify-live.mjs [baseUrl]`：对**运行中**的 dsh web 做端到端验收 —— ① host 半新鲜度（运行 buildId vs 源码 buildId，不等即提示重启）② 持久化 `available` + 全表 + 服务来源 ③ 往 `viewed` 写 canary → 读回 → 删除 ④ 自挖板块：GET 口径 + 挑一个非弱链类**真的命名一次** ⑤ AI·行情信息项。host 半是进程内加载的，改完必须重启；client 半只需硬刷新 |
| **真实存储栈校验** | `node scripts/verify-state-domain.mjs`：用宿主安装的 cordis + dsh-storage + storage-json + storage-domain **真跑一遍**手搓 spec（16 项断言：open 接受 / 12 张表 / 键编码必要性 / 落盘持久性 / version 语义 / compatibleVersions 逃生口）。不进 CI（CI 无 DSH 安装），改契约后必跑 |
| **诊断面板** | ✅ B5-③ 已实现：`src/panel/DiagnosticsPanel.tsx`，底栏 🩺 按钮 —— 构建一致性 / 持久化 / 数据链路 / 缓存底账 / AI 与 HIST，五类状态一处可查 |

## 9. 已知架构债（对应 ROADMAP 编号）

| # | 债 | 状态 | 编号 |
| --- | --- | --- | --- |
| 1 | ladder 无缓存 + 3 处重算 | ✅ 已修（30s 共享缓存 + in-flight 去重） | B3 |
| 2 | 双缓存（`cache.ts` 与 `market.ts`） | ✅ 已修（`swrFetch` 收口，全仓唯一数据缓存） | B5 |
| 3 | 收起栏 / 后台标签页不停轮询 | ✅ 已修（`document.hidden` 跳过 + 左栏收起 `enabled:false`） | B3 |
| 4 | `cache.ts` 的 `refreshInterval` 变更不生效 | ✅ 已修（deps 补项） | B3 |
| 5 | AI 请求不可中断（signal 未透传） | ✅ 已修（三处包装透传 signal） | B6 |
| 6 | HTTP-only 端点残留在 embedded 部署（关键价位） | 🟡 已**显式提示不可用**并给出替代做法（模型价位线）；真正的 TS 端价位计算仍未做 | B2 |
| 7 | 存储无抽象、无重置/导出 | 🟡 已迁 host 领域（A1）；**导出/导入/重置**仍待做 | A1 |
| 8 | 样式双轨（7 个新文件用 `--dc-*`，28 个旧文件 1,000+ 处硬编码色 + 64 条暗色重映射） | ⏳ 未动 | A5 |
| 9 | 无 ESLint、无单测；`tsc` 只看 `src`（`noUnusedLocals:false`） | ✅ 已修（ESLint **0 error / 0 warning** + 棘轮 `--max-warnings 0`；单测 + 离线冒烟，**数量以 `pnpm test` 输出为准**）。**残留**：测试文件不在 `tsc` 的 include 内，断言靠运行保证 | B4 |
| 10 | client.js 体积 814KB / 护栏 840KB（单模块不可拆分） | ✅ 已修（默认 minify + sourcemap；护栏 **665KB**，数字单一来源 = `scripts/check-bundle-size.mjs`）。**残留**：余量只剩 ~13KB（实测 651.7KB），再减重需换图库或砍内联代码；**下一批若要挂回个股卡必须先算这笔账** | B2 |
| 11 | 命名缓存只在 host 进程内存（重启即失效，不跨进程） | 🟡 有意为之：跨进程要新增存储表 + 版本迁移；等真实使用反馈再决定。命中缓存不产生第二次 LLM 调用（已测） | A2b |
