# Project overview and naming

## Name

`dsh-ui-preset-enhance` is intentionally descriptive:

- **dsh** — the target plugin ecosystem.
- **ui** — the project operates primarily in the WebUI/client plane.
- **preset** — reusable prompts are a first-class feature and a likely future extension point.
- **enhance** — the project adds capabilities around the existing product rather than replacing the DSH core.

The name is meant to communicate an additive, reversible enhancement rather than a fork or core rewrite.

## Scope

The project currently focuses on three categories:

1. **Personalization** — background and theme controls.
2. **Efficiency** — reusable prompt presets.
3. **Visibility** — token/context readouts and a compact shortcut.

It intentionally avoids adding backend tools or altering Agent-Loop behavior.

## Architectural principles

### Client first

Features that are fundamentally browser UI preferences stay in the browser whenever possible.

### Non-invasive integration

The plugin prefers DSH extension seams instead of patching DSH source files. In the current implementation, appearance uses `theme.overrideTokens`, settings/sidebar use slots, token values come from the current Session summary's `projectionValues`, and manual compaction goes through the current Session's public `command()` face.

### Reversible behavior

UI settings can be changed or disabled, and the package itself can be removed through the DSH plugin command.

### Practical over decorative

Visual customization is only one part of the project. Prompt reuse and context visibility are included because they address repeated workflow friction during longer DSH sessions.

## File naming and responsibilities

- `package.json` — npm package metadata plus DSH bundle/client declarations.
- `cordis.patch.yml` — profile-bundle patch that mounts the package.
- `src/index.ts` — host entry; intentionally no-op for the current client-only design.
- `src/client.tsx` — browser UI implementation.
- `src/ambient.d.ts` — minimal declarations used for standalone TypeScript checking.
- `scripts/build.mjs` — deterministic TypeScript-based build for `dsh/client.js` and `dsh/index.js`.
- `dsh/` — committed runtime output used by Git-based installation.

## Runtime boundaries

Current responsibilities:

```text
DSH host/profile
    ↓
package + Cordis patch
    ↓
DSH client module loader
    ↓
client-side UI enhancement
```

Out of scope for this release:

- model request protocol changes;
- Agent-Loop rewrites;
- session-log mutation;
- permission bypasses;
- replacing the entire DSH WebUI.

## Preset terminology

The UI feature in this repository is a **Prompt Preset**, not a full Agent Preset.

A Prompt Preset is reusable text loaded toward the normal composer and copied to the clipboard. It does not change the session's system prompt through a dedicated DSH API.

If the project later integrates true agent profiles, the naming should distinguish:

```text
PromptPreset
AgentPreset
ThemePreset
WorkspacePreset
```

## Versioning

The project uses semantic-version-style releases:

- `0.1.x` — preview fixes and compatibility adjustments.
- `0.x` — evolving feature/API surface.
- `1.0.0` — only after the runtime integration and installation path are considered stable enough for normal users.

## Current validation boundary

The repository includes package/loader/runtime smoke checks, JavaScript syntax checks, a deterministic rebuild check, and a GitHub Actions job that installs the package into a clean DSH `0.1.0-rc.6` Web Profile through the official `dsh plugin` path. The client integration was also reviewed against the corresponding public DSH source contracts.

This still does not replace broad real-browser testing across user machines and future DSH preview builds. The `0.1.x` line should therefore remain marked Preview until enough end-to-end field testing has been collected.

## Client activation dependencies

`package.json > dsh.client.inject` is intentionally limited to DSH packages that are themselves browser plugin entries and that provide services this plugin needs before activation:

- `@deepseek-ai/dsh-client-runtime`
- `@deepseek-ai/dsh-client-locale`
- `@deepseek-ai/dsh-client-ui-theme`

It is **not** a list of every JavaScript module referenced by the source. Pure helper/runtime-table modules such as `@deepseek-ai/dsh-client-web-react` or `@deepseek-ai/dsh-client-ui-slots` must not be added merely because source code imports/types mention them; DSH treats this manifest field as client-plugin graph dependency metadata.
