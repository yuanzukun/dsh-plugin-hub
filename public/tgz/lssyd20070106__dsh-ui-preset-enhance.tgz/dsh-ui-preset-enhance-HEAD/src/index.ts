// Host entry for dsh-ui-preset-enhance.
//
// This is a PURE client-side UI plugin: every capability lives in the browser
// bundle (src/client.tsx) and rides the Cordis client event bus. The host entry
// is intentionally a no-op — it only exists so the package can join the profile
// bundle stack (via cordis.patch.yml) and so the client-module scanner serves
// `./client` to the WebUI. Nothing here touches the Agent-Loop kernel and no
// backend tool is registered.
//
// TUI/headless profiles never mount this package's client bundle (it declares
// `dsh.client.platform = "web"`), and this no-op apply keeps the host plane
// completely inert.

/** Stable Cordis plugin name. */
export const name = "dsh-ui-preset-enhance";

/** No host-plane services required. */
export const inject: string[] = [];

/**
 * No-op host plugin body. The real work is the web client bundle.
 * @param _ctx - host cordis context (unused).
 */
export function apply(_ctx: unknown): void {
  // Intentionally empty — client-only feature.
}
