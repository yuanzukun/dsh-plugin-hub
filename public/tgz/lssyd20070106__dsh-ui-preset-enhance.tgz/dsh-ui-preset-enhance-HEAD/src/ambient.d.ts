// Ambient runtime-module declarations so `tsc --noEmit` works in a standalone
// checkout. At runtime these modules are resolved from the DSH shell's frozen
// module table / fetched client bundles, not from this package's node_modules.

declare module "@deepseek-ai/dsh-client-web-react" {
  export function bindSnapshotSelector<S>(
    store: { getSnapshot(): S; subscribe(listener: () => void): () => void }
  ): <T>(selector: (state: S) => T) => T;
}

interface Window {
  __ModuleLoader__?: {
    load(entry: {
      id: string;
      factory: (require: (id: string) => unknown) => unknown;
    }): void;
  };
}
