# dsh-ui-preset-enhance

[简体中文](README.md) · [English](README.en.md) · [Beginner Windows guide](INSTALL-GUIDE.md)

A third-party **DeepSeek Harness (DSH) WebUI enhancement plugin** for backgrounds, theme colors, reusable prompts, token/context visibility, and manual context compaction.

> **v0.1.0 Preview.** This is not an official DeepSeek component. The source has been reviewed against the public DSH `0.1.0-rc.6` client contracts and the repository includes build, loader/runtime smoke, package, and clean-profile installation checks. Keep the Preview label while broader real-browser compatibility feedback is collected.

## Preview

<p align="center"><img src="assets/preview-home.png" alt="DSH WebUI background preview" width="100%" /></p>
<p align="center"><img src="assets/preview-settings.png" alt="Appearance settings prototype" width="100%" /></p>

> These screenshots are from the early visual prototype. The packaged plugin exposes the same direction of features in a dedicated **Settings → Enhance** section; exact control placement may differ.

## Install

Prerequisites: Node.js and pnpm.

```powershell
npx --yes @deepseek-ai/dsh plugin --profile web add github:lssyd20070106/dsh-ui-preset-enhance
```

Restart DSH Web, hard-refresh the browser, then open **Settings → Enhance**.

Windows users who prefer a guided install can download and extract the repository ZIP, then double-click:

```text
INSTALL-WINDOWS.cmd
```

The Chinese [`INSTALL-GUIDE.md`](INSTALL-GUIDE.md) contains step-by-step troubleshooting for first-time users.

## Features

- Custom image URL/upload and five gradient wallpapers
- Interface surface opacity and wallpaper blur
- Primary/secondary theme colors and generated accent scale
- Seven built-in prompt presets plus browser-local user presets
- Current-session context pressure, context window and token breakdown
- Manual `/compact` through the current DSH Session command interface

## Runtime model

This is intentionally a Web client enhancement. It does not register a backend tool or replace the Agent Loop.

User UI preferences and custom prompt presets are stored in browser `localStorage`. Custom wallpaper URLs are limited to HTTP(S) and image data URLs; arbitrary script/CSS URL schemes are rejected.

## Verification

`npm run verify` performs typecheck, rebuild, package smoke, runtime-loader smoke, and JavaScript syntax checks. The runtime smoke validates slot registration, projection bridging, Session command compaction, and persisted appearance restoration using a mocked DSH client surface.

GitHub Actions additionally verifies a clean DSH `0.1.0-rc.6` web-profile installation with the official `dsh plugin` command and checks that committed `dsh/` output matches a fresh build.

The repository intentionally commits `dsh/client.js` and `dsh/index.js`, so end users do not need to build TypeScript during plugin installation.

## Uninstall

```powershell
npx --yes @deepseek-ai/dsh plugin --profile web remove dsh-ui-preset-enhance
```

Or double-click `UNINSTALL-WINDOWS.cmd` from a downloaded checkout.

## Recommended companion: Skills manager

For DSH Skills management, see **Fishquito7's** third-party project:

- [Fishquito7/dsh-skill-viewer](https://github.com/Fishquito7/dsh-skill-viewer)

It is not created by, bundled with, or maintained as part of this project.

## Development

Node.js 20+:

```powershell
npm install
npm run verify
```

The client source is a single-file entry and the build uses TypeScript transpilation before wrapping the output in DSH's `window.__ModuleLoader__.load(...)` format.

## License

MIT — see [LICENSE](LICENSE).
