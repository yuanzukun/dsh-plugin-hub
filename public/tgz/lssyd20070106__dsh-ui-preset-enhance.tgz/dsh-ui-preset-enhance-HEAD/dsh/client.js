window.__ModuleLoader__.load({
	id: "dsh-ui-preset-enhance",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		"use strict";
		Object.defineProperty(exports, "__esModule", { value: true });
		exports.name = exports.inject = void 0;
		exports.apply = apply;
		const jsx_runtime_1 = require("react/jsx-runtime");
		// dsh-ui-preset-enhance — browser client bundle (WebUI-only).
		//
		// Pure client-side UI plugin riding the Cordis client event bus. It does NOT
		// modify the Agent-Loop kernel and registers no backend tool. Four features:
		//   1. Custom background (upload / URL / gradient presets, opacity, blur, toggle)
		//   2. UI theme colors (primary + secondary via ctx.theme.overrideTokens)
		//   3. Agent preset prompt templates (built-in + user-saved, one-click load)
		//   4. Real-time token stats + manual compaction (/compact through the current Session face)
		const react_1 = require("react");
		const dsh_client_web_react_1 = require("@deepseek-ai/dsh-client-web-react");
		/* eslint-disable @typescript-eslint/no-explicit-any */
		// ─────────────────────────────────────────────────────────────────────────────
		// Constants
		// ─────────────────────────────────────────────────────────────────────────────
		const PLUGIN_ID = "dsh-ui-preset-enhance";
		const LOCALE_NS = "settings.enhance";
		const STORAGE_BACKGROUND = "dsh-upe:background:v1";
		const STORAGE_COLORS = "dsh-upe:colors:v1";
		const STORAGE_PRESETS = "dsh-upe:presets:v1";
		const DEFAULT_BACKGROUND = { enabled: false, src: "", opacity: 0.85, blur: 0 };
		const DEFAULT_COLORS = { primary: "#4176e6", secondary: "#10a37f" };
		const WALLPAPER_PRESETS = [
		    { id: "preset:aurora", name: "Aurora", css: "linear-gradient(135deg, #0f2027 0%, #203a43 45%, #2c5364 100%)" },
		    { id: "preset:ocean", name: "Ocean", css: "linear-gradient(160deg, #0a1128 0%, #143a5c 55%, #0f4c5c 100%)" },
		    { id: "preset:ember", name: "Ember", css: "linear-gradient(150deg, #1a0f0a 0%, #3d1f14 45%, #5c2a16 100%)" },
		    { id: "preset:violet", name: "Violet", css: "linear-gradient(140deg, #141022 0%, #2b1a4d 50%, #43275f 100%)" },
		    { id: "preset:graphite", name: "Graphite", css: "linear-gradient(160deg, #0d0d0f 0%, #1d1d22 50%, #0a0a0c 100%)" }
		];
		const BUILTIN_TEMPLATES = [
		    {
		        id: "ops",
		        name: "🔧 运维排错",
		        prompt: "你是资深运维工程师。优先：1.先收集关键信息（报错、日志、环境：操作系统、面板类型、是否反向代理）；2.给出分步可复制执行操作；3.区分「排查步骤」和「最终解决方案」；4.不要大段理论，输出操作优先。遇到SSL、Nginx、DNS故障优先定位根因，不做无意义猜测。"
		    },
		    {
		        id: "debug",
		        name: "💻 代码调试重构",
		        prompt: "你是高级开发工程师。拿到代码：1.先说明现存问题；2.给出修改之后完整可运行代码片段；3.标注修改位置；4.提供极简复现步骤；拒绝只讲理论不给可运行代码。尽量保持原有代码架构，不随意重写全部逻辑。"
		    },
		    {
		        id: "markdown",
		        name: "📝 Markdown 文档整理",
		        prompt: "你是文档整理助手。输出严格标准Markdown语法。合理分级标题、列表、表格；重要信息加粗；输出干净无多余闲聊。适合做技术笔记、故障复盘、资料总结。不要输出```markdown外层代码块，直接输出正文内容。"
		    },
		    {
		        id: "plugin",
		        name: "🧩 DSH 插件开发",
		        prompt: "你熟悉DeepSeek-Harness插件开发体系。区分UI插件 / Tool工具插件 / Agent-Loop内核插件；优先给出最小可运行TS代码骨架；说明依赖事件总线、生命周期钩子；明确哪些修改会破坏底座稳定性，给出风险提示。尽量复用官方组件，不要造轮子。"
		    },
		    {
		        id: "polish",
		        name: "🌐 文案去AI腔",
		        prompt: "你负责改写文字，去除AI模板感。语言自然口语，符合普通人发帖、朋友圈、论坛求助帖风格；保留全部原始关键信息；不要华丽空洞修饰；逻辑清晰流畅。"
		    },
		    {
		        id: "study",
		        name: "📚 学习答疑",
		        prompt: "回答技术、理科知识点，用通俗语言；优先结论在前，之后补充解释；必要使用简单表格；不要堆砌教科书长篇文字。如果涉及计算机原理，可以简单类比生活实物辅助理解。"
		    },
		    {
		        id: "post",
		        name: "🗜️ 故障求助帖",
		        prompt: "帮我整理网络/程序故障的求助帖子：1.标题精炼；2.环境说明；3.已经尝试过哪些操作；4.当前报错现象；5.我的预期；自动脱敏隐私信息，适合发布技术论坛。"
		    }
		];
		// ─────────────────────────────────────────────────────────────────────────────
		// CSS injection (background layers + panel chrome)
		// ─────────────────────────────────────────────────────────────────────────────
		const PLUGIN_CSS = `/* dsh-ui-preset-enhance */
		body[data-upe-bg] {
		  position: relative;
		  isolation: isolate;
		  background: transparent !important;
		}
		body[data-upe-bg]::before {
		  content: "";
		  position: fixed;
		  inset: -60px;
		  z-index: 0;
		  pointer-events: none;
		  background-image: var(--upe-bg-image, none);
		  background-size: cover;
		  background-position: center;
		  background-repeat: no-repeat;
		  filter: blur(var(--upe-bg-blur, 0px));
		}
		body[data-upe-bg]::after {
		  content: "";
		  position: fixed;
		  inset: 0;
		  z-index: 0;
		  pointer-events: none;
		  background: rgba(8, 8, 10, var(--upe-bg-overlay, 0.04));
		}
		body[data-upe-bg] #root { position: relative; z-index: 1; }
		.upe-panel { display: flex; flex-direction: column; gap: 14px; max-width: 720px; color: var(--dsw-alias-label-primary); }
		.upe-card { border: 1px solid var(--dsw-alias-border-l2); background: var(--dsw-alias-bg-layer-3); border-radius: 12px; padding: 14px 16px; display: flex; flex-direction: column; gap: 10px; }
		.upe-h { margin: 0; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px; }
		.upe-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
		.upe-input { flex: 1; min-width: 0; background: var(--dsw-specific-input-major); border: 1px solid var(--dsw-alias-border-l2); border-radius: 8px; color: var(--dsw-alias-label-primary); padding: 6px 10px; font: inherit; font-size: 13px; }
		.upe-input:focus { outline: 2px solid var(--dsw-static-deepseek-400); outline-offset: -1px; }
		.upe-btn { background: var(--dsw-alias-button-ghost-active-fill); border: 1px solid var(--dsw-alias-border-l2); color: var(--dsw-alias-label-primary); border-radius: 8px; padding: 6px 12px; font: inherit; font-size: 13px; cursor: pointer; white-space: nowrap; }
		.upe-btn:hover { background: var(--dsw-alias-button-ghost-active-hover); }
		.upe-btn-primary { background: var(--dsw-alias-button-primary-fill); color: var(--dsw-alias-label-primary-foreground); border-color: transparent; }
		.upe-btn-primary:hover { filter: brightness(1.05); }
		.upe-btn:disabled { opacity: 0.5; cursor: not-allowed; }
		.upe-sw { width: 30px; height: 30px; border-radius: 50%; border: 2px solid var(--dsw-alias-border-l2); cursor: pointer; padding: 0; flex: none; }
		.upe-sw[data-selected="true"] { outline: 2px solid var(--dsw-alias-label-primary); outline-offset: 2px; }
		.upe-color { width: 34px; height: 34px; border-radius: 50%; border: 2px solid var(--dsw-alias-border-l2); padding: 0; background: none; cursor: pointer; overflow: hidden; flex: none; }
		.upe-color::-webkit-color-swatch-wrapper { padding: 0; }
		.upe-color::-webkit-color-swatch { border: none; border-radius: 50%; }
		.upe-color::-moz-color-swatch { border: none; border-radius: 50%; }
		.upe-slider { width: 100%; accent-color: var(--dsw-static-deepseek-400); }
		.upe-slider-row { display: flex; flex-direction: column; gap: 4px; }
		.upe-slider-label { display: flex; justify-content: space-between; color: var(--dsw-alias-label-secondary); font-size: 12px; }
		.upe-list { display: flex; flex-direction: column; gap: 6px; }
		.upe-preset { display: flex; gap: 8px; align-items: center; justify-content: space-between; border: 1px solid var(--dsw-alias-border-l2); border-radius: 8px; padding: 8px 10px; }
		.upe-preset-name { font-size: 13px; font-weight: 500; }
		.upe-preset-prompt { color: var(--dsw-alias-label-secondary); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 320px; }
		.upe-mono { font-family: var(--ds-font-family-code); font-size: 13px; }
		.upe-stat-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 8px; }
		.upe-stat { border: 1px solid var(--dsw-alias-border-l2); border-radius: 10px; padding: 8px 10px; }
		.upe-stat-k { color: var(--dsw-alias-label-secondary); font-size: 11px; }
		.upe-stat-v { font-size: 16px; font-weight: 600; font-variant-numeric: tabular-nums; }
		.upe-note { color: var(--dsw-alias-label-tertiary); font-size: 12px; }
		`;
		let cssInjected = false;
		function injectCss() {
		    if (cssInjected || typeof document === "undefined")
		        return;
		    cssInjected = true;
		    const id = `${PLUGIN_ID}/style.css`;
		    if (document.querySelector(`style[data-plugin-css="${id}"]`))
		        return;
		    const tag = document.createElement("style");
		    tag.dataset.plugin = PLUGIN_ID;
		    tag.dataset.pluginCss = id;
		    tag.textContent = PLUGIN_CSS;
		    document.head.appendChild(tag);
		}
		// ─────────────────────────────────────────────────────────────────────────────
		// Storage helpers
		// ─────────────────────────────────────────────────────────────────────────────
		function readJson(key, fallback) {
		    try {
		        const raw = localStorage.getItem(key);
		        if (raw)
		            return { ...fallback, ...JSON.parse(raw) };
		    }
		    catch {
		        /* ignore */
		    }
		    return { ...fallback };
		}
		function writeJson(key, value) {
		    try {
		        localStorage.setItem(key, JSON.stringify(value));
		    }
		    catch {
		        /* ignore */
		    }
		}
		function clampNum(value, min, max, fallback) {
		    const n = Number(value);
		    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
		}
		// ─────────────────────────────────────────────────────────────────────────────
		// Background
		// ─────────────────────────────────────────────────────────────────────────────
		function resolveBackgroundImage(src) {
		    const value = (src || "").trim();
		    if (!value)
		        return "none";
		    if (value.startsWith("preset:")) {
		        const preset = WALLPAPER_PRESETS.find((p) => p.id === value);
		        return preset ? preset.css : "none";
		    }
		    // Limit user-provided values to image sources that browsers can safely use
		    // here. This intentionally rejects javascript:, file:, and arbitrary CSS.
		    if (!/^(?:https?:\/\/|data:image\/)/i.test(value))
		        return "none";
		    return `url("${value.replace(/["\\]/g, "\\$&")}")`;
		}
		function normalizeBackgroundState(value) {
		    return {
		        enabled: Boolean(value.enabled),
		        src: typeof value.src === "string" ? value.src : "",
		        opacity: clampNum(value.opacity, 0.4, 1, DEFAULT_BACKGROUND.opacity),
		        blur: clampNum(value.blur, 0, 40, DEFAULT_BACKGROUND.blur)
		    };
		}
		function applyBackgroundToDom(rawState) {
		    if (typeof document === "undefined")
		        return;
		    const state = normalizeBackgroundState(rawState);
		    const body = document.body;
		    const image = state.enabled ? resolveBackgroundImage(state.src) : "none";
		    body.style.setProperty("--upe-bg-image", image);
		    body.style.setProperty("--upe-bg-blur", `${state.blur}px`);
		    // Surface opacity is handled through DSH theme tokens. Keep only a light
		    // readability veil over the wallpaper itself.
		    body.style.setProperty("--upe-bg-overlay", image === "none" ? "0" : "0.04");
		    body.toggleAttribute("data-upe-bg", image !== "none");
		}
		function clearBackgroundDom() {
		    if (typeof document === "undefined")
		        return;
		    const body = document.body;
		    body.removeAttribute("data-upe-bg");
		    body.style.removeProperty("--upe-bg-image");
		    body.style.removeProperty("--upe-bg-blur");
		    body.style.removeProperty("--upe-bg-overlay");
		}
		function fileToDataUrl(file) {
		    return new Promise((resolve, reject) => {
		        const reader = new FileReader();
		        reader.onload = () => {
		            const img = new Image();
		            img.onload = () => {
		                try {
		                    const max = 1920;
		                    const scale = Math.min(1, max / img.width, max / img.height);
		                    const w = Math.max(1, Math.round(img.width * scale));
		                    const h = Math.max(1, Math.round(img.height * scale));
		                    const canvas = document.createElement("canvas");
		                    canvas.width = w;
		                    canvas.height = h;
		                    const c = canvas.getContext("2d");
		                    if (!c) {
		                        resolve(String(reader.result));
		                        return;
		                    }
		                    c.drawImage(img, 0, 0, w, h);
		                    resolve(canvas.toDataURL("image/jpeg", 0.85));
		                }
		                catch {
		                    resolve(String(reader.result));
		                }
		            };
		            img.onerror = () => reject(new Error("image load failed"));
		            img.src = String(reader.result);
		        };
		        reader.onerror = () => reject(new Error("file read failed"));
		        reader.readAsDataURL(file);
		    });
		}
		// ─────────────────────────────────────────────────────────────────────────────
		// Theme colors (primary / secondary) via ctx.theme.overrideTokens
		// ─────────────────────────────────────────────────────────────────────────────
		const ACCENT_VARS = [
		    "--dsw-static-deepseek-50",
		    "--dsw-static-deepseek-100",
		    "--dsw-static-deepseek-200",
		    "--dsw-static-deepseek-300",
		    "--dsw-static-deepseek-400",
		    "--dsw-static-deepseek-450",
		    "--dsw-static-deepseek-500",
		    "--dsw-static-deepseek-600",
		    "--dsw-static-deepseek-800",
		    "--dsw-static-deepseek-900"
		];
		function hexToRgb(hex) {
		    const m = /^#?([0-9a-f]{6})$/i.exec((hex || "").trim());
		    if (!m)
		        return null;
		    const n = parseInt(m[1], 16);
		    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
		}
		function rgbToHex(r, g, b) {
		    const c = (v) => Math.max(0, Math.min(255, Math.round(v)));
		    return "#" + [c(r), c(g), c(b)].map((v) => v.toString(16).padStart(2, "0")).join("");
		}
		function accentScale(hex) {
		    const base = hexToRgb(hex) || [65, 118, 230];
		    const mix = (t, target) => rgbToHex(base[0] + (target[0] - base[0]) * t, base[1] + (target[1] - base[1]) * t, base[2] + (target[2] - base[2]) * t);
		    const white = [255, 255, 255];
		    const black = [12, 12, 16];
		    return {
		        "--dsw-static-deepseek-50": mix(0.93, white),
		        "--dsw-static-deepseek-100": mix(0.84, white),
		        "--dsw-static-deepseek-200": mix(0.68, white),
		        "--dsw-static-deepseek-300": mix(0.42, white),
		        "--dsw-static-deepseek-400": mix(0.2, white),
		        "--dsw-static-deepseek-450": mix(0.08, white),
		        "--dsw-static-deepseek-500": rgbToHex(base[0], base[1], base[2]),
		        "--dsw-static-deepseek-600": mix(0.22, black),
		        "--dsw-static-deepseek-800": mix(0.55, black),
		        "--dsw-static-deepseek-900": mix(0.72, black)
		    };
		}
		function applyColorsToTheme(theme, colors) {
		    const primary = accentScale(colors.primary);
		    const overrides = {};
		    for (const name of ACCENT_VARS) {
		        overrides[name] = { light: primary[name], dark: primary[name] };
		    }
		    // Secondary color → success/business accent states.
		    const sec = { light: colors.secondary, dark: colors.secondary };
		    overrides["--dsw-alias-state-success-primary"] = sec;
		    overrides["--dsw-alias-state-success-secondary"] = sec;
		    overrides["--dsw-alias-state-business-primary"] = { light: colors.primary, dark: colors.primary };
		    try {
		        return theme.overrideTokens(`${PLUGIN_ID}:colors`, overrides);
		    }
		    catch {
		        return () => { };
		    }
		}
		function applyBackgroundToTheme(theme, rawState) {
		    const state = normalizeBackgroundState(rawState);
		    const image = state.enabled ? resolveBackgroundImage(state.src) : "none";
		    if (image === "none")
		        return () => { };
		    const alpha = clampNum(state.opacity, 0.4, 1, DEFAULT_BACKGROUND.opacity);
		    const raised = Math.min(0.98, alpha + 0.08);
		    const nested = Math.min(0.99, alpha + 0.12);
		    const overlay = Math.min(0.995, alpha + 0.14);
		    const rgba = (rgb, a) => `rgba(${rgb}, ${a.toFixed(3)})`;
		    const pair = (light, dark) => ({ light, dark });
		    const overrides = {
		        "--dsw-alias-bg-base": pair(rgba("249, 250, 251", alpha), rgba("17, 17, 16", alpha)),
		        "--dsw-specific-sidebar-fill": pair(rgba("247, 248, 249", raised), rgba("21, 21, 22", raised)),
		        "--dsw-alias-bg-layer-1": pair(rgba("255, 255, 255", raised), rgba("27, 27, 29", raised)),
		        "--dsw-alias-bg-layer-2": pair(rgba("255, 255, 255", nested), rgba("31, 31, 34", nested)),
		        "--dsw-alias-bg-layer-3": pair(rgba("255, 255, 255", nested), rgba("35, 35, 38", nested)),
		        "--dsw-alias-bg-overlay": pair(rgba("255, 255, 255", overlay), rgba("27, 27, 29", overlay))
		    };
		    try {
		        return theme.overrideTokens(`${PLUGIN_ID}:background`, overrides);
		    }
		    catch {
		        return () => { };
		    }
		}
		// ─────────────────────────────────────────────────────────────────────────────
		// Preset templates
		// ─────────────────────────────────────────────────────────────────────────────
		function loadUserPresets() {
		    try {
		        const raw = localStorage.getItem(STORAGE_PRESETS);
		        if (raw) {
		            const arr = JSON.parse(raw);
		            if (Array.isArray(arr))
		                return arr.filter((p) => p && typeof p.name === "string" && typeof p.prompt === "string");
		        }
		    }
		    catch {
		        /* ignore */
		    }
		    return [];
		}
		function saveUserPresets(presets) {
		    writeJson(STORAGE_PRESETS, presets);
		}
		// ─────────────────────────────────────────────────────────────────────────────
		// Token stat formatting
		// ─────────────────────────────────────────────────────────────────────────────
		function fmtTokens(n) {
		    if (n === undefined || n === null)
		        return "—";
		    if (n >= 1000000)
		        return (n / 1000000).toFixed(1) + "M";
		    if (n >= 1000)
		        return (n / 1000).toFixed(1) + "k";
		    return String(n);
		}
		// ─────────────────────────────────────────────────────────────────────────────
		// i18n
		// ─────────────────────────────────────────────────────────────────────────────
		const zh = {
		    nav: "界面增强",
		    bgTitle: "🖼️ 自定义背景",
		    bgEnable: "启用背景",
		    bgUpload: "上传图片",
		    bgUrl: "粘贴图片链接（http/https）",
		    bgApply: "应用",
		    bgClear: "清除",
		    bgOpacity: "界面不透明度",
		    bgBlur: "背景模糊",
		    colorTitle: "🎨 主题颜色",
		    colorPrimary: "主色",
		    colorSecondary: "辅助色",
		    colorCustom: "自定义",
		    presetTitle: "📑 预设模板",
		    presetLoad: "加载到输入框",
		    presetCopy: "复制",
		    presetAdd: "新增模板",
		    presetName: "模板名称",
		    presetPrompt: "Prompt 内容",
		    presetSave: "保存",
		    presetDelete: "删除",
		    tokenTitle: "📊 Token 统计",
		    tokenContext: "上下文占用",
		    tokenWindow: "上下文窗口",
		    tokenInput: "输入",
		    tokenOutput: "输出",
		    tokenSystem: "系统提示词",
		    tokenTools: "工具定义",
		    tokenMessages: "消息",
		    compactBtn: "🔄 手动压缩上下文",
		    compactRunning: "压缩中…",
		    compactNote: "压缩仅替换传给模型的视图，原始 session.jsonl 日志不会删除。",
		    loadHint: "已加载提示词到输入框"
		};
		const en = {
		    nav: "Enhance",
		    bgTitle: "🖼️ Custom Background",
		    bgEnable: "Enable background",
		    bgUpload: "Upload image",
		    bgUrl: "Paste image URL (http/https)",
		    bgApply: "Apply",
		    bgClear: "Clear",
		    bgOpacity: "Interface opacity",
		    bgBlur: "Background blur",
		    colorTitle: "🎨 Theme Colors",
		    colorPrimary: "Primary",
		    colorSecondary: "Secondary",
		    colorCustom: "Custom",
		    presetTitle: "📑 Preset Templates",
		    presetLoad: "Load to input",
		    presetCopy: "Copy",
		    presetAdd: "New template",
		    presetName: "Template name",
		    presetPrompt: "Prompt content",
		    presetSave: "Save",
		    presetDelete: "Delete",
		    tokenTitle: "📊 Token Stats",
		    tokenContext: "Context used",
		    tokenWindow: "Context window",
		    tokenInput: "Input",
		    tokenOutput: "Output",
		    tokenSystem: "System prompt",
		    tokenTools: "Tool schemas",
		    tokenMessages: "Messages",
		    compactBtn: "🔄 Compact context",
		    compactRunning: "Compacting…",
		    compactNote: "Compaction only replaces the model-facing view; the original session.jsonl log is preserved.",
		    loadHint: "Prompt loaded to the input"
		};
		function BackgroundCard({ t, onAppearanceChange }) {
		    const [state, setState] = (0, react_1.useState)(() => readJson(STORAGE_BACKGROUND, DEFAULT_BACKGROUND));
		    const [urlDraft, setUrlDraft] = (0, react_1.useState)("");
		    const fileRef = (0, react_1.useRef)(null);
		    (0, react_1.useEffect)(() => {
		        const normalized = normalizeBackgroundState(state);
		        applyBackgroundToDom(normalized);
		        onAppearanceChange(normalized);
		        writeJson(STORAGE_BACKGROUND, normalized);
		    }, [state, onAppearanceChange]);
		    const update = (patch) => setState((s) => ({ ...s, ...patch }));
		    const onPick = (e) => {
		        const f = e.target.files && e.target.files[0];
		        if (!f)
		            return;
		        fileToDataUrl(f).then((url) => update({ src: url, enabled: true })).catch(() => { });
		        if (fileRef.current)
		            fileRef.current.value = "";
		    };
		    return ((0, jsx_runtime_1.jsxs)("section", { className: "upe-card", children: [(0, jsx_runtime_1.jsx)("h3", { className: "upe-h", children: t("bgTitle") }), (0, jsx_runtime_1.jsxs)("label", { className: "upe-row", style: { cursor: "pointer" }, children: [(0, jsx_runtime_1.jsx)("input", { type: "checkbox", checked: state.enabled, onChange: (e) => update({ enabled: e.target.checked }) }), (0, jsx_runtime_1.jsx)("span", { children: t("bgEnable") })] }), (0, jsx_runtime_1.jsx)("div", { className: "upe-row", children: WALLPAPER_PRESETS.map((p) => ((0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-sw", "data-selected": state.src === p.id ? "true" : "false", style: { backgroundImage: p.css }, title: p.name, onClick: () => update({ src: p.id, enabled: true }) }, p.id))) }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-row", children: [(0, jsx_runtime_1.jsx)("input", { className: "upe-input", type: "text", placeholder: t("bgUrl"), value: urlDraft, onChange: (e) => setUrlDraft(e.target.value), onKeyDown: (e) => { if (e.key === "Enter") {
		                            const v = urlDraft.trim();
		                            if (v)
		                                update({ src: v, enabled: true });
		                            setUrlDraft("");
		                        } } }), (0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn", onClick: () => { const v = urlDraft.trim(); if (v)
		                            update({ src: v, enabled: true }); setUrlDraft(""); }, children: t("bgApply") })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-row", children: [(0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn", onClick: () => fileRef.current && fileRef.current.click(), children: t("bgUpload") }), (0, jsx_runtime_1.jsx)("input", { ref: fileRef, type: "file", accept: "image/*", style: { display: "none" }, onChange: onPick }), state.src ? (0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn", onClick: () => update({ src: "", enabled: false }), children: t("bgClear") }) : null] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-slider-row", children: [(0, jsx_runtime_1.jsxs)("div", { className: "upe-slider-label", children: [(0, jsx_runtime_1.jsx)("span", { children: t("bgOpacity") }), (0, jsx_runtime_1.jsxs)("span", { children: [Math.round(state.opacity * 100), "%"] })] }), (0, jsx_runtime_1.jsx)("input", { className: "upe-slider", type: "range", min: 0.4, max: 1, step: 0.05, value: state.opacity, onChange: (e) => update({ opacity: Number(e.target.value) }) })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-slider-row", children: [(0, jsx_runtime_1.jsxs)("div", { className: "upe-slider-label", children: [(0, jsx_runtime_1.jsx)("span", { children: t("bgBlur") }), (0, jsx_runtime_1.jsxs)("span", { children: [state.blur, "px"] })] }), (0, jsx_runtime_1.jsx)("input", { className: "upe-slider", type: "range", min: 0, max: 40, step: 1, value: state.blur, onChange: (e) => update({ blur: Number(e.target.value) }) })] })] }));
		}
		function ColorsCard({ t, onAppearanceChange }) {
		    const [colors, setColors] = (0, react_1.useState)(() => readJson(STORAGE_COLORS, DEFAULT_COLORS));
		    (0, react_1.useEffect)(() => {
		        onAppearanceChange(colors);
		        writeJson(STORAGE_COLORS, colors);
		    }, [colors, onAppearanceChange]);
		    const swatches = ["#4176e6", "#10a37f", "#8b5cf6", "#f43f5e", "#f59e0b", "#9c845c"];
		    return ((0, jsx_runtime_1.jsxs)("section", { className: "upe-card", children: [(0, jsx_runtime_1.jsx)("h3", { className: "upe-h", children: t("colorTitle") }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-row", children: [(0, jsx_runtime_1.jsx)("span", { className: "upe-note", children: t("colorPrimary") }), (0, jsx_runtime_1.jsx)("input", { className: "upe-color", type: "color", value: colors.primary, onChange: (e) => setColors((c) => ({ ...c, primary: e.target.value })), title: t("colorCustom") }), swatches.map((hex) => ((0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-sw", "data-selected": colors.primary === hex ? "true" : "false", style: { backgroundColor: hex }, onClick: () => setColors((c) => ({ ...c, primary: hex })) }, hex)))] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-row", children: [(0, jsx_runtime_1.jsx)("span", { className: "upe-note", children: t("colorSecondary") }), (0, jsx_runtime_1.jsx)("input", { className: "upe-color", type: "color", value: colors.secondary, onChange: (e) => setColors((c) => ({ ...c, secondary: e.target.value })), title: t("colorCustom") }), swatches.map((hex) => ((0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-sw", "data-selected": colors.secondary === hex ? "true" : "false", style: { backgroundColor: hex }, onClick: () => setColors((c) => ({ ...c, secondary: hex })) }, hex)))] })] }));
		}
		function PresetsCard({ t, onLoad }) {
		    const [userPresets, setUserPresets] = (0, react_1.useState)(() => loadUserPresets());
		    const [showAdd, setShowAdd] = (0, react_1.useState)(false);
		    const [name, setName] = (0, react_1.useState)("");
		    const [prompt, setPrompt] = (0, react_1.useState)("");
		    const all = [...BUILTIN_TEMPLATES, ...userPresets];
		    const addPreset = () => {
		        const n = name.trim();
		        const p = prompt.trim();
		        if (!n || !p)
		            return;
		        const next = [...userPresets, { id: `u-${Date.now()}`, name: n, prompt: p }];
		        setUserPresets(next);
		        saveUserPresets(next);
		        setName("");
		        setPrompt("");
		        setShowAdd(false);
		    };
		    const removePreset = (id) => {
		        const next = userPresets.filter((p) => p.id !== id);
		        setUserPresets(next);
		        saveUserPresets(next);
		    };
		    return ((0, jsx_runtime_1.jsxs)("section", { className: "upe-card", children: [(0, jsx_runtime_1.jsx)("h3", { className: "upe-h", children: t("presetTitle") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-list", children: all.map((p) => ((0, jsx_runtime_1.jsxs)("div", { className: "upe-preset", children: [(0, jsx_runtime_1.jsxs)("div", { style: { minWidth: 0 }, children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-preset-name", children: p.name }), (0, jsx_runtime_1.jsx)("div", { className: "upe-preset-prompt", children: p.prompt })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-row", style: { flex: "none" }, children: [(0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn upe-btn-primary", onClick: () => onLoad(p.prompt), children: t("presetLoad") }), !BUILTIN_TEMPLATES.some((b) => b.id === p.id) ? ((0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn", onClick: () => removePreset(p.id), children: t("presetDelete") })) : null] })] }, p.id))) }), showAdd ? ((0, jsx_runtime_1.jsxs)("div", { className: "upe-list", children: [(0, jsx_runtime_1.jsx)("input", { className: "upe-input", type: "text", placeholder: t("presetName"), value: name, onChange: (e) => setName(e.target.value) }), (0, jsx_runtime_1.jsx)("textarea", { className: "upe-input", rows: 3, placeholder: t("presetPrompt"), value: prompt, onChange: (e) => setPrompt(e.target.value) }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-row", children: [(0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn upe-btn-primary", onClick: addPreset, children: t("presetSave") }), (0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn", onClick: () => setShowAdd(false), children: t("presetDelete") })] })] })) : ((0, jsx_runtime_1.jsx)("div", { className: "upe-row", children: (0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn", onClick: () => setShowAdd(true), children: t("presetAdd") }) }))] }));
		}
		function TokenCard({ t, useProjection, useCurrentSessionId, compact }) {
		    const pressure = useProjection("contextPressure");
		    const usage = useProjection("tokenUsage");
		    const breakdown = useProjection("contextBreakdown");
		    const sessionId = useCurrentSessionId();
		    const [compacting, setCompacting] = (0, react_1.useState)(false);
		    const doCompact = (0, react_1.useCallback)(async () => {
		        if (!sessionId || compacting)
		            return;
		        setCompacting(true);
		        try {
		            await compact(sessionId);
		        }
		        finally {
		            setCompacting(false);
		        }
		    }, [sessionId, compacting, compact]);
		    return ((0, jsx_runtime_1.jsxs)("section", { className: "upe-card", children: [(0, jsx_runtime_1.jsx)("h3", { className: "upe-h", children: t("tokenTitle") }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-stat-grid", children: [(0, jsx_runtime_1.jsxs)("div", { className: "upe-stat", children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-stat-k", children: t("tokenContext") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-stat-v", children: fmtTokens(pressure?.projectedTokens) })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-stat", children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-stat-k", children: t("tokenWindow") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-stat-v", children: fmtTokens(pressure?.contextWindow) })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-stat", children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-stat-k", children: t("tokenInput") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-stat-v", children: fmtTokens(usage?.uncachedInputTokens) })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-stat", children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-stat-k", children: t("tokenOutput") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-stat-v", children: fmtTokens(usage?.outputTokens) })] })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-stat-grid", children: [(0, jsx_runtime_1.jsxs)("div", { className: "upe-stat", children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-stat-k", children: t("tokenSystem") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-stat-v", children: fmtTokens(breakdown?.systemTokens) })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-stat", children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-stat-k", children: t("tokenTools") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-stat-v", children: fmtTokens(breakdown?.toolsTokens) })] }), (0, jsx_runtime_1.jsxs)("div", { className: "upe-stat", children: [(0, jsx_runtime_1.jsx)("div", { className: "upe-stat-k", children: t("tokenMessages") }), (0, jsx_runtime_1.jsx)("div", { className: "upe-stat-v", children: fmtTokens(breakdown?.messageTokens) })] })] }), (0, jsx_runtime_1.jsx)("div", { className: "upe-row", children: (0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn upe-btn-primary", disabled: !sessionId || compacting, onClick: doCompact, children: compacting ? t("compactRunning") : t("compactBtn") }) }), (0, jsx_runtime_1.jsx)("p", { className: "upe-note", children: t("compactNote") })] }));
		}
		function EnhanceSection(props) {
		    const { t, onLoadPreset, onBackgroundState, onColorState, ...rest } = props;
		    return ((0, jsx_runtime_1.jsxs)("div", { className: "upe-panel", children: [(0, jsx_runtime_1.jsx)(TokenCard, { t: t, ...rest }), (0, jsx_runtime_1.jsx)(BackgroundCard, { t: t, onAppearanceChange: onBackgroundState }), (0, jsx_runtime_1.jsx)(ColorsCard, { t: t, onAppearanceChange: onColorState }), (0, jsx_runtime_1.jsx)(PresetsCard, { t: t, onLoad: onLoadPreset })] }));
		}
		function SidebarTokenAction({ t, wide, useProjection, useCurrentSessionId, compact }) {
		    const pressure = useProjection("contextPressure");
		    const sessionId = useCurrentSessionId();
		    const [busy, setBusy] = (0, react_1.useState)(false);
		    const run = (0, react_1.useCallback)(async () => {
		        if (!sessionId || busy)
		            return;
		        setBusy(true);
		        try {
		            await compact(sessionId);
		        }
		        finally {
		            setBusy(false);
		        }
		    }, [sessionId, busy, compact]);
		    return ((0, jsx_runtime_1.jsx)("button", { type: "button", className: "upe-btn", style: { width: wide ? "100%" : undefined }, onClick: run, disabled: !sessionId || busy, title: `${t("tokenContext")} ${fmtTokens(pressure?.projectedTokens)}`, children: busy ? "…" : wide ? `${t("compactBtn")} · ${fmtTokens(pressure?.projectedTokens)}` : "🔄" }));
		}
		// ─────────────────────────────────────────────────────────────────────────────
		// Plugin apply
		// ─────────────────────────────────────────────────────────────────────────────
		exports.inject = ["slots", "locale", "theme", "sessions"];
		exports.name = PLUGIN_ID;
		function apply(ctx) {
		    injectCss();
		    ctx.effect(() => ctx.locale.register(LOCALE_NS, { zh, en }), `${PLUGIN_ID}: dictionaries`);
		    const theme = ctx.theme;
		    const sessions = ctx.sessions;
		    // Keep appearance overrides alive for the whole plugin lifetime. Settings
		    // sections unmount when the modal closes, so component-owned disposers would
		    // otherwise make the user's chosen theme disappear.
		    let disposeBackgroundTheme = () => { };
		    let disposeColorTheme = () => { };
		    const setBackgroundTheme = (state) => {
		        disposeBackgroundTheme();
		        disposeBackgroundTheme = applyBackgroundToTheme(theme, state);
		    };
		    const setColorTheme = (colors) => {
		        disposeColorTheme();
		        disposeColorTheme = applyColorsToTheme(theme, colors);
		    };
		    ctx.effect(() => {
		        const background = normalizeBackgroundState(readJson(STORAGE_BACKGROUND, DEFAULT_BACKGROUND));
		        const colors = readJson(STORAGE_COLORS, DEFAULT_COLORS);
		        applyBackgroundToDom(background);
		        setBackgroundTheme(background);
		        setColorTheme(colors);
		        return () => {
		            disposeBackgroundTheme();
		            disposeColorTheme();
		            clearBackgroundDom();
		        };
		    }, `${PLUGIN_ID}: restore persisted appearance`);
		    // Create the session-list selector hook once (a store-bound hook must not be
		    // re-created on every render). SessionSummary carries the current host
		    // projection values, so root-scoped settings/sidebar slots can react to
		    // token-meter projections without relying on a non-existent ctx.useProjection.
		    const useSessions = (0, dsh_client_web_react_1.bindSnapshotSelector)(sessions.list);
		    const useCurrentSessionId = () => useSessions((s) => s.current);
		    const useProjection = (key) => useSessions((s) => {
		        const id = s.current;
		        return id ? s.byId?.[id]?.projectionValues?.[key] : undefined;
		    });
		    const compact = async (sessionId) => {
		        try {
		            const session = sessions.binding(sessionId)?.session;
		            if (!session)
		                throw new Error("current session is unavailable");
		            const result = await session.command("/compact");
		            if (!result.ok)
		                throw new Error(result.error?.message || "compact command failed");
		        }
		        catch (err) {
		            console.error(`[${PLUGIN_ID}] compact failed`, err);
		        }
		    };
		    const loadToInput = (prompt) => {
		        // Best-effort: insert into the composer when present. Always also copy to
		        // clipboard so the prompt remains usable when DSH changes its composer DOM.
		        const root = document.querySelector("#root");
		        const candidates = Array.from(root?.querySelectorAll("textarea, [contenteditable='true']") || []);
		        const target = candidates.find((el) => !el.closest("[role='dialog']")) || null;
		        if (target instanceof HTMLTextAreaElement) {
		            const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
		            if (setter)
		                setter.call(target, prompt);
		            else
		                target.value = prompt;
		            target.dispatchEvent(new Event("input", { bubbles: true }));
		            target.focus();
		        }
		        else if (target) {
		            target.textContent = prompt;
		            target.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: prompt }));
		            target.focus();
		        }
		        if (typeof navigator !== "undefined" && navigator.clipboard) {
		            navigator.clipboard.writeText(prompt).catch(() => { });
		        }
		    };
		    const sectionInjected = () => ({
		        useProjection,
		        useCurrentSessionId,
		        compact,
		        onBackgroundState: setBackgroundTheme,
		        onColorState: setColorTheme,
		        onLoadPreset: loadToInput
		    });
		    ctx.slots.inject("settings.section", () => ctx.slots.register({
		        name: "settings.section",
		        id: "enhance",
		        order: 30,
		        label: () => ctx.locale.bind(LOCALE_NS)("nav"),
		        locale: LOCALE_NS,
		        inject: sectionInjected
		    }, EnhanceSection));
		    const footerInjected = () => ({
		        useProjection,
		        useCurrentSessionId,
		        compact
		    });
		    ctx.slots.inject("sidebar.footer.action", () => ctx.slots.register({
		        name: "sidebar.footer.action",
		        id: "enhance-token",
		        order: 10,
		        locale: LOCALE_NS,
		        inject: footerInjected
		    }, SidebarTokenAction));
		}

		return module.exports;
	}
});
