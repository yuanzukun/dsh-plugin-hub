# dsh-ui-preset-enhance — beginner-friendly Windows installer
# Installs this downloaded folder into DSH's `web` profile using the official
# `dsh plugin` command. It does not delete sessions or unrelated settings.
$ErrorActionPreference = "Stop"

$PackageName = "dsh-ui-preset-enhance"
$Profile = "web"

function Step([string]$Text) { Write-Host "[1/1] $Text" -ForegroundColor Cyan }
function Fail([string]$Text) {
  Write-Host ""
  Write-Host "安装没有完成：$Text" -ForegroundColor Red
  Write-Host "请打开 INSTALL-GUIDE.md，找到“安装失败怎么办”一节。" -ForegroundColor Yellow
  exit 1
}
function Has([string]$Name) { return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

Write-Host ""
Write-Host "====================================================" -ForegroundColor DarkGray
Write-Host " dsh-ui-preset-enhance  Windows 安装向导" -ForegroundColor Magenta
Write-Host "====================================================" -ForegroundColor DarkGray
Write-Host ""

# 1) Node / npm / npx
Write-Host "[1/5] 检查 Node.js" -ForegroundColor Cyan
if (-not (Has "node")) { Fail "没有找到 Node.js。请先安装 Node.js 20 或更高版本。" }
if (-not (Has "npm"))  { Fail "没有找到 npm。正常安装 Node.js 后会自带 npm。" }
if (-not (Has "npx"))  { Fail "没有找到 npx。正常安装 Node.js 后会自带 npx。" }
$nodeVersion = (& node -p "process.versions.node").Trim()
$nodeMajor = [int](($nodeVersion -split '\.')[0])
Write-Host "      Node.js $nodeVersion" -ForegroundColor Green
if ($nodeMajor -lt 20) {
  Write-Host "      当前 Node.js 版本偏旧，建议升级到 Node.js 20+。" -ForegroundColor Yellow
}

# 2) pnpm — DSH's plugin command forwards to pnpm internally.
Write-Host "[2/5] 检查 pnpm" -ForegroundColor Cyan
if (-not (Has "pnpm")) {
  Write-Host "      DSH 安装插件需要 pnpm，但你的电脑还没有。" -ForegroundColor Yellow
  $answer = Read-Host "      是否现在自动安装 pnpm？直接按回车 = 是；输入 N = 否"
  if ($answer -match '^[Nn]$') { Fail "缺少 pnpm。你可以稍后运行：npm install -g pnpm" }
  & npm install -g pnpm
  if ($LASTEXITCODE -ne 0 -or -not (Has "pnpm")) { Fail "pnpm 自动安装失败。请手动运行：npm install -g pnpm" }
}
$pnpmVersion = (& pnpm --version).Trim()
Write-Host "      pnpm $pnpmVersion" -ForegroundColor Green

# 3) Verify the downloaded package itself before touching the profile.
Write-Host "[3/5] 检查插件文件" -ForegroundColor Cyan
$required = @(
  "package.json",
  "cordis.patch.yml",
  "dsh\client.js",
  "dsh\index.js"
)
foreach ($item in $required) {
  $path = Join-Path $PSScriptRoot $item
  if (-not (Test-Path $path)) { Fail "安装包不完整，缺少：$item" }
}
& node --check (Join-Path $PSScriptRoot "dsh\client.js")
if ($LASTEXITCODE -ne 0) { Fail "dsh/client.js 语法检查失败。请重新下载完整安装包。" }
& node --check (Join-Path $PSScriptRoot "dsh\index.js")
if ($LASTEXITCODE -ne 0) { Fail "dsh/index.js 语法检查失败。请重新下载完整安装包。" }
Write-Host "      插件运行文件完整" -ForegroundColor Green

# 4) Check DSH CLI and install as file: so the extracted folder can be removed
# later without leaving a live directory symlink behind.
Write-Host "[4/5] 安装到 DSH Web Profile" -ForegroundColor Cyan
& npx --yes @deepseek-ai/dsh --version | Out-Host
if ($LASTEXITCODE -ne 0) { Fail "无法运行 @deepseek-ai/dsh。请检查网络连接，然后重试。" }

$normalized = $PSScriptRoot -replace '\\', '/'
$fileSpec = "file:$normalized"
Write-Host "      正在安装，请不要关闭窗口……" -ForegroundColor Gray
& npx --yes @deepseek-ai/dsh plugin --profile $Profile add $fileSpec
if ($LASTEXITCODE -ne 0) { Fail "DSH 返回安装失败。上方错误信息请保留，用于排查。" }

# 5) Verify pnpm's installed dependency list.
Write-Host "[5/5] 验证安装结果" -ForegroundColor Cyan
$verifyText = (& npx --yes @deepseek-ai/dsh plugin --profile $Profile list $PackageName --depth 0 2>&1 | Out-String)
if ($LASTEXITCODE -ne 0 -or $verifyText -notmatch [regex]::Escape($PackageName)) {
  Write-Host $verifyText
  Fail "安装命令成功返回，但没有在 Web Profile 中确认到插件。"
}
Write-Host "      已在 Web Profile 中找到 $PackageName" -ForegroundColor Green

Write-Host ""
Write-Host "====================================================" -ForegroundColor DarkGray
Write-Host " 安装完成" -ForegroundColor Green
Write-Host "====================================================" -ForegroundColor DarkGray
Write-Host "接下来只做两件事：" -ForegroundColor White
Write-Host "  1. 完全关闭并重新启动 DSH Web。" -ForegroundColor White
Write-Host "  2. 浏览器按 Ctrl + F5，然后打开：设置 -> 界面增强。" -ForegroundColor White
Write-Host ""
Write-Host "如果看不到“界面增强”，请运行 VERIFY-WINDOWS.cmd 或查看 INSTALL-GUIDE.md。" -ForegroundColor Yellow
