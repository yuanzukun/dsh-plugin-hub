@echo off
chcp 65001 >nul
title dsh-ui-preset-enhance uninstaller
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
echo.
echo Press any key to close this window...
pause >nul
