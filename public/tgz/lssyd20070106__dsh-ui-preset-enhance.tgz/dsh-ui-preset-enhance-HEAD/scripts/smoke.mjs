import { readFile, stat } from "node:fs/promises";

const fail = (message) => { throw new Error(`[smoke] ${message}`); };
const pkg = JSON.parse(await readFile("package.json", "utf8"));
if (pkg.name !== "dsh-ui-preset-enhance") fail("unexpected package name");
if (pkg.dsh?.bundle?.patch !== "./cordis.patch.yml") fail("missing dsh.bundle.patch");
if (pkg.dsh?.client?.platform !== "web") fail("client platform must be web");
const expectedInject = [
  "@deepseek-ai/dsh-client-runtime",
  "@deepseek-ai/dsh-client-locale",
  "@deepseek-ai/dsh-client-ui-theme"
];
if (JSON.stringify(pkg.dsh?.client?.inject) !== JSON.stringify(expectedInject)) {
  fail("dsh.client.inject must contain only client-plugin activation dependencies");
}
if (pkg.exports?.["./client"] !== "./dsh/client.js") fail("./client export mismatch");

for (const path of ["cordis.patch.yml", "dsh/client.js", "dsh/index.js"]) {
  const info = await stat(path).catch(() => undefined);
  if (!info?.isFile()) fail(`missing ${path}`);
}

const patch = await readFile("cordis.patch.yml", "utf8");
if (!patch.includes("dsh-ui-preset-enhance")) fail("bundle patch does not name plugin");

const client = await readFile("dsh/client.js", "utf8");
if (!client.startsWith("window.__ModuleLoader__.load({")) fail("client loader wrapper missing");
if (!client.includes('id: "dsh-ui-preset-enhance"')) fail("client loader id mismatch");
if (!client.includes('exports.apply = apply')) fail("client apply export missing");
if (/\b[A-Z]:\\/i.test(client)) fail("Windows absolute path leaked into client bundle");

const host = await readFile("dsh/index.js", "utf8");
if (!host.includes('export const name = "dsh-ui-preset-enhance"')) fail("host name export missing");
if (!host.includes("export function apply")) fail("host apply export missing");

console.log("[smoke] package structure and runtime entry checks passed");
