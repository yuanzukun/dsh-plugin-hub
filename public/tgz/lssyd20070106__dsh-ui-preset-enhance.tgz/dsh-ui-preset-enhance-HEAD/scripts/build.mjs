// Reproducible build without native bundler binaries.
//
// src/client.tsx is intentionally a single-file client entry whose imports are
// all provided by DSH's frozen module table. TypeScript transpiles it to CJS,
// then this script wraps it in DSH's window.__ModuleLoader__.load(...) format.
import ts from "typescript";
import { mkdir, readFile, writeFile } from "node:fs/promises";

const CLIENT_ID = "dsh-ui-preset-enhance";

function formatDiagnostics(diagnostics) {
  if (!diagnostics?.length) return "";
  return diagnostics
    .map((diagnostic) => ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"))
    .join("\n");
}

async function transpile(path, compilerOptions) {
  const source = await readFile(path, "utf8");
  const result = ts.transpileModule(source, {
    fileName: path,
    compilerOptions,
    reportDiagnostics: true
  });
  const errors = (result.diagnostics ?? []).filter((d) => d.category === ts.DiagnosticCategory.Error);
  if (errors.length) throw new Error(formatDiagnostics(errors));
  return result.outputText;
}

async function buildClient() {
  const body = await transpile("src/client.tsx", {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.CommonJS,
    jsx: ts.JsxEmit.ReactJSX,
    esModuleInterop: true,
    sourceMap: false,
    removeComments: false
  });

  const wrapped =
    `window.__ModuleLoader__.load({\n` +
    `\tid: ${JSON.stringify(CLIENT_ID)},\n` +
    `\tfactory: (require) => {\n` +
    `\t\tvar module = { exports: {} };\n` +
    `\t\tvar exports = module.exports;\n` +
    `\t\tObject.defineProperty(exports, Symbol.toStringTag, { value: "Module" });\n` +
    body
      .split("\n")
      .map((line) => (line.length ? "\t\t" + line : line))
      .join("\n") +
    `\n\t\treturn module.exports;\n` +
    `\t}\n` +
    `});\n`;

  await mkdir("dsh", { recursive: true });
  await writeFile("dsh/client.js", wrapped, "utf8");
  console.log("[build] wrote dsh/client.js");
}

async function buildHost() {
  const body = await transpile("src/index.ts", {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.ES2020,
    sourceMap: false,
    removeComments: false
  });
  await mkdir("dsh", { recursive: true });
  await writeFile("dsh/index.js", body, "utf8");
  console.log("[build] wrote dsh/index.js");
}

await buildClient();
await buildHost();
