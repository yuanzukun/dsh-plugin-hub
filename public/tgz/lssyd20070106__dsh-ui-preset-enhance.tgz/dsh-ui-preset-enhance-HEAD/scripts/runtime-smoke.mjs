import { readFile } from "node:fs/promises";
import vm from "node:vm";

const fail = (message) => { throw new Error(`[runtime-smoke] ${message}`); };
const storage = new Map([
  ["dsh-upe:background:v1", JSON.stringify({ enabled: true, src: "preset:aurora", opacity: 0.7, blur: 3 })]
]);

globalThis.localStorage = {
  getItem: (key) => storage.get(key) ?? null,
  setItem: (key, value) => storage.set(key, String(value)),
  removeItem: (key) => storage.delete(key)
};

const bodyVars = new Map();
const bodyAttrs = new Set();
globalThis.document = {
  head: { appendChild() {} },
  body: {
    style: {
      setProperty: (key, value) => bodyVars.set(key, String(value)),
      removeProperty: (key) => bodyVars.delete(key)
    },
    toggleAttribute: (key, force) => { if (force) bodyAttrs.add(key); else bodyAttrs.delete(key); },
    removeAttribute: (key) => bodyAttrs.delete(key)
  },
  querySelector: () => null,
  createElement: () => ({ dataset: {}, textContent: "" })
};

let loaded;
const reactStub = new Proxy({}, { get: () => () => { throw new Error("React hook/render invoked during apply smoke"); } });
const jsxStub = { jsx: () => null, jsxs: () => null, Fragment: Symbol("Fragment") };
const snapshot = {
  current: "session-1",
  byId: {
    "session-1": {
      projectionValues: {
        contextPressure: { projectedTokens: 1234, contextWindow: 64000 },
        tokenUsage: { uncachedInputTokens: 100, outputTokens: 50, cacheReadTokens: 0, cacheWriteTokens: 0 },
        contextBreakdown: { systemTokens: 10, toolsTokens: 20, messageTokens: 30 }
      }
    }
  }
};
const requireMock = (id) => {
  if (id === "react") return reactStub;
  if (id === "react/jsx-runtime") return jsxStub;
  if (id === "@deepseek-ai/dsh-client-web-react") {
    return { bindSnapshotSelector: (store) => (selector) => selector(store.getSnapshot()) };
  }
  throw new Error(`unexpected require: ${id}`);
};

globalThis.window = {
  __ModuleLoader__: {
    load(entry) { loaded = { id: entry.id, exports: entry.factory(requireMock) }; }
  }
};

vm.runInThisContext(await readFile("dsh/client.js", "utf8"), { filename: "dsh/client.js" });
if (!loaded) fail("ModuleLoader.load was not called");
if (loaded.id !== "dsh-ui-preset-enhance") fail("wrong client module id");
if (typeof loaded.exports?.apply !== "function") fail("apply export missing");

const effects = [];
const tokenCalls = [];
const registrations = [];
const commands = [];
const ctx = {
  locale: {
    register: () => () => {},
    bind: () => (key) => key
  },
  theme: {
    overrideTokens: (source, tokens) => { tokenCalls.push({ source, tokens }); return () => {}; }
  },
  sessions: {
    list: { getSnapshot: () => snapshot, subscribe: () => () => {} },
    binding: (id) => id === "session-1" ? { session: { command: async (line) => { commands.push(line); return { ok: true, value: { matched: true } }; } } } : undefined
  },
  effect: (fn) => { const cleanup = fn(); if (typeof cleanup === "function") effects.push(cleanup); return cleanup; },
  slots: {
    inject: (_name, registerFn) => registerFn(),
    register: (config, component) => { registrations.push({ config, component }); return () => {}; }
  }
};

loaded.exports.apply(ctx);
if (registrations.length !== 2) fail(`expected 2 slot registrations, got ${registrations.length}`);
const settings = registrations.find((r) => r.config.id === "enhance");
const footer = registrations.find((r) => r.config.id === "enhance-token");
if (!settings || !footer) fail("settings/sidebar slot registration missing");
const injected = settings.config.inject();
if (injected.useProjection("contextPressure")?.projectedTokens !== 1234) fail("projection bridge did not read current session projectionValues");
await injected.compact("session-1");
if (commands[0] !== "/compact") fail("compact did not use current Session command face");
if (!tokenCalls.some((call) => call.source === "dsh-ui-preset-enhance:background")) fail("background token override missing");
if (!tokenCalls.some((call) => call.source === "dsh-ui-preset-enhance:colors")) fail("color token override missing");
if (!bodyAttrs.has("data-upe-bg")) fail("persisted background was not restored");
if (!String(bodyVars.get("--upe-bg-image") ?? "").includes("linear-gradient")) fail("background preset did not resolve");

for (const cleanup of effects.reverse()) cleanup();
console.log("[runtime-smoke] loader, slots, projections, compact, and appearance boot checks passed");
