# 小白安装手册｜dsh-ui-preset-enhance

如果你不懂 Node.js、pnpm、PowerShell，也可以按这份手册安装。

> **最推荐的方法：先用“一行命令安装”。失败了，再用“下载 ZIP + 双击安装”。**

## 安装后你会得到什么

插件安装成功后，重新打开 DSH Web，在 **设置 → 界面增强** 中可以使用：

- 自定义壁纸、渐变背景、模糊和界面透明度
- 主色 / 辅助色
- 常用 Prompt 预设
- Token / Context 信息
- 手动 `/compact` 快捷操作

---

## 方法 A：一行命令安装（最省事）

### 第 1 步：确认 Node.js

打开 Windows Terminal、PowerShell 或 CMD，输入：

```powershell
node --version
```

如果能看到类似 `v20.x.x`、`v22.x.x`，继续下一步。

如果提示“不是内部或外部命令”，先安装 **Node.js 20 或更高版本**，安装后重新打开终端。

### 第 2 步：确认 pnpm

输入：

```powershell
pnpm --version
```

如果找不到 pnpm，运行：

```powershell
npm install -g pnpm
```

安装完成后再运行一次：

```powershell
pnpm --version
```

### 第 3 步：安装插件

复制下面整行命令：

```powershell
npx --yes @deepseek-ai/dsh plugin --profile web add github:lssyd20070106/dsh-ui-preset-enhance
```

等待命令结束。没有红色报错，并回到命令提示符，就可以继续。

### 第 4 步：重启 DSH

把正在运行的 DSH Web **完全关闭并重新启动**。

然后浏览器按：

```text
Ctrl + F5
```

打开：

```text
设置 → 界面增强
```

看到“自定义背景 / 主题颜色 / 预设模板 / Token 统计”即可。

---

## 方法 B：完全不会命令行？下载 ZIP 后双击安装

这个方法适合一行命令失败，或者不想处理 GitHub 安装协议的用户。

### 第 1 步：下载项目

在 GitHub 仓库页面点击：

```text
Code → Download ZIP
```

把 ZIP 解压到一个普通文件夹，例如：

```text
D:\Downloads\dsh-ui-preset-enhance
```

**不要直接在压缩包里双击脚本。一定先解压。**

### 第 2 步：双击安装

在解压后的文件夹里找到：

```text
INSTALL-WINDOWS.cmd
```

双击它。

安装程序会自动：

1. 检查 Node.js；
2. 检查 pnpm；
3. 如果没有 pnpm，会询问是否自动安装；
4. 检查插件运行文件有没有损坏；
5. 安装到 DSH 的 `web` Profile；
6. 再检查一次插件是否真的进入 Profile。

看到绿色的“安装完成”即可。

### 第 3 步：重启

重新启动 DSH Web，浏览器按 `Ctrl + F5`，然后进入：

```text
设置 → 界面增强
```

---

## 安装失败怎么办

### 情况 1：提示 `node not found` / 找不到 node

原因：没有安装 Node.js，或者安装后终端没有重新打开。

处理：安装 Node.js 20+，然后重新打开 CMD / PowerShell。

检查：

```powershell
node --version
npm --version
```

---

### 情况 2：提示 `pnpm not found`

运行：

```powershell
npm install -g pnpm
```

然后：

```powershell
pnpm --version
```

再重新安装插件。

> DSH 的 `plugin` 命令内部会调用 pnpm，所以 pnpm 是必要条件。

---

### 情况 3：PowerShell 提示“禁止运行脚本”

不要直接双击 `install.ps1`。

请双击：

```text
INSTALL-WINDOWS.cmd
```

这个启动器会只对本次安装使用 `ExecutionPolicy Bypass`，不会永久修改你的系统策略。

---

### 情况 4：GitHub 一行命令安装失败

先不要反复改 DSH 配置。

直接改用 **方法 B：Download ZIP → 解压 → 双击 `INSTALL-WINDOWS.cmd`**。

本项目已经提交预构建的：

```text
dsh/client.js
dsh/index.js
```

因此普通用户安装时不需要自己编译源码。

---

### 情况 5：显示安装成功，但设置里没有“界面增强”

按这个顺序检查：

1. 完全关闭 DSH Web；
2. 重新启动 DSH Web；
3. 浏览器按 `Ctrl + F5`；
4. 运行 `VERIFY-WINDOWS.cmd`；
5. 再打开“设置”。

如果 `VERIFY-WINDOWS.cmd` 全部显示 `[OK]`，但 UI 仍不出现，请到 GitHub Issues 提交：

- DSH 版本
- Windows 版本
- 安装命令的完整输出
- 浏览器开发者工具 Console 中的红色报错

**不要提交 API Key、Cookie、Token、私有 Prompt 或其他个人信息。**

---

### 情况 6：壁纸看不到 / 透明度没变化

先确认“启用背景”已经勾选，并选择了渐变、上传图片或有效的 `http/https` 图片地址。

然后尝试：

1. 把界面不透明度调到 70% 左右；
2. 按 `Ctrl + F5`；
3. 重新打开设置页。

`file://`、`javascript:` 等地址会被插件主动拒绝。

---

## 如何检查是否安装成功

下载版用户直接双击：

```text
VERIFY-WINDOWS.cmd
```

也可以手动运行：

```powershell
npx --yes @deepseek-ai/dsh plugin --profile web list dsh-ui-preset-enhance --depth 0
```

输出中出现：

```text
dsh-ui-preset-enhance
```

说明插件已经进入 DSH Web Profile。

---

## 如何卸载

### 命令行

```powershell
npx --yes @deepseek-ai/dsh plugin --profile web remove dsh-ui-preset-enhance
```

### 下载版

双击：

```text
UNINSTALL-WINDOWS.cmd
```

卸载后重新启动 DSH Web，并按 `Ctrl + F5`。

插件卸载不会删除你的 DSH 会话或项目。浏览器里已经保存的插件 UI 偏好可能继续保留在 `localStorage` 中。

---

## 推荐搭配：Skills 管理“技巧”插件

如果你还希望在 Web 界面管理 Skills，可以查看原作者 **Fishquito7** 的项目：

**https://github.com/Fishquito7/dsh-skill-viewer**

它不是本项目的一部分，也不是由本项目作者制作。请以原作者仓库里的最新安装说明为准。

---

## 项目作者：第一次把项目上传到 GitHub

如果你拿到的是 ChatGPT 整理后的完整发布 ZIP，并且 GitHub 上已经建好了空仓库，可以直接双击：

```text
PUBLISH-TO-GITHUB-WINDOWS.cmd
```

它只用于项目作者首次发布，会把当前文件夹提交并推送到：

```text
https://github.com/lssyd20070106/dsh-ui-preset-enhance
```

如果 GitHub 要求登录，按浏览器提示登录即可。这个发布助手已经写进 `.gitignore`，**不会上传到公开仓库**。
