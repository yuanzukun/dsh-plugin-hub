# Non-destructive installation verifier for Windows.
$ErrorActionPreference = "Continue"
$PackageName = "dsh-ui-preset-enhance"
$Profile = "web"
$failed = $false

function Check([string]$Label, [bool]$Ok, [string]$Hint) {
  if ($Ok) { Write-Host "[OK]   $Label" -ForegroundColor Green }
  else { Write-Host "[FAIL] $Label" -ForegroundColor Red; if ($Hint) { Write-Host "       $Hint" -ForegroundColor Yellow }; $script:failed = $true }
}

Write-Host ""
Write-Host "== dsh-ui-preset-enhance 安装检查 ==" -ForegroundColor Magenta
Check "Node.js" ($null -ne (Get-Command node -ErrorAction SilentlyContinue)) "请安装 Node.js 20+"
Check "npx" ($null -ne (Get-Command npx -ErrorAction SilentlyContinue)) "Node.js 正常安装后会自带 npx"
Check "pnpm" ($null -ne (Get-Command pnpm -ErrorAction SilentlyContinue)) "运行：npm install -g pnpm"
Check "本地 dsh/client.js" (Test-Path (Join-Path $PSScriptRoot "dsh\client.js")) "请重新下载完整项目 ZIP"
Check "本地 dsh/index.js" (Test-Path (Join-Path $PSScriptRoot "dsh\index.js")) "请重新下载完整项目 ZIP"

if (Get-Command node -ErrorAction SilentlyContinue) {
  & node --check (Join-Path $PSScriptRoot "dsh\client.js") 2>$null
  Check "client.js JavaScript 语法" ($LASTEXITCODE -eq 0) "运行文件可能损坏"
  & node --check (Join-Path $PSScriptRoot "dsh\index.js") 2>$null
  Check "index.js JavaScript 语法" ($LASTEXITCODE -eq 0) "运行文件可能损坏"
}

if ((Get-Command npx -ErrorAction SilentlyContinue) -and (Get-Command pnpm -ErrorAction SilentlyContinue)) {
  $text = (& npx --yes @deepseek-ai/dsh plugin --profile $Profile list $PackageName --depth 0 2>&1 | Out-String)
  Check "DSH Web Profile 已安装插件" (($LASTEXITCODE -eq 0) -and ($text -match [regex]::Escape($PackageName))) "重新运行 INSTALL-WINDOWS.cmd"
}

Write-Host ""
if ($failed) {
  Write-Host "检查发现问题。按 INSTALL-GUIDE.md 的故障排查步骤处理。" -ForegroundColor Yellow
  exit 1
}
Write-Host "基础安装检查全部通过。" -ForegroundColor Green
Write-Host "最后请人工确认：重启 DSH Web -> Ctrl+F5 -> 设置 -> 界面增强。" -ForegroundColor Green
