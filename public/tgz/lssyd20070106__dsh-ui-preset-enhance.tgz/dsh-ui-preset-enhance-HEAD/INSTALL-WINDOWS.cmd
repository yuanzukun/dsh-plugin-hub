@echo off
chcp 65001 >nul
title dsh-ui-preset-enhance installer
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
echo Press any key to close this window...
pause >nul
