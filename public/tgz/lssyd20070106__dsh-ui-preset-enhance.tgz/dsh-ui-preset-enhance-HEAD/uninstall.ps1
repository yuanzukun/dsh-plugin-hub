# dsh-ui-preset-enhance — Windows uninstaller
$ErrorActionPreference = "Stop"
$PackageName = "dsh-ui-preset-enhance"
$Profile = "web"

function Fail([string]$Text) { Write-Host "[error] $Text" -ForegroundColor Red; exit 1 }
function Has([string]$Name) { return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

Write-Host ""
Write-Host "== dsh-ui-preset-enhance 卸载 ==" -ForegroundColor Magenta
if (-not (Has "npx")) { Fail "没有找到 npx。" }
if (-not (Has "pnpm")) { Fail "没有找到 pnpm。先运行：npm install -g pnpm" }

& npx --yes @deepseek-ai/dsh plugin --profile $Profile remove $PackageName
if ($LASTEXITCODE -ne 0) { Fail "DSH 卸载命令失败。" }

Write-Host "[done] 插件已从 Web Profile 移除。" -ForegroundColor Green
Write-Host "请重新启动 DSH Web，并在浏览器按 Ctrl + F5。" -ForegroundColor Green
Write-Host "注意：浏览器 localStorage 中的个人壁纸/颜色/Prompt 设置不会主动删除。" -ForegroundColor Yellow
