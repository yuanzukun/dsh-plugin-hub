/**
 * dsh-exam-countdown — Chinese exam countdown for DeepSeek Harness.
 *
 * Ports the exam countdown app (https://github.com/zimai233/china-exam-countdown)
 * into two agent-callable tools:
 *
 *   - exam_countdown   : query the built-in 64-exam dataset by id, name or
 *                        category and get days-until computed from pure date
 *                        math. Fixed-date exams and rule-based exams
 *                        (CET-4/6 = 2nd Saturday, JLPT = 1st Sunday) roll to
 *                        the next year once the date has passed.
 *   - exam_categories  : list the unique categories with exam counts.
 *
 * Pure ESM, zero build step — the published package is the runtime code.
 * The dataset + date math live as pure named exports so tests can import
 * them without loading a cordis runtime.
 */

import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'dsh-exam-countdown'
export const inject = ['tools']

// ---------------------------------------------------------------- dataset

/**
 * Built-in Chinese exam dataset (64 entries).
 *
 * @typedef {object} Exam
 * @property {string} id   Stable slug (e.g. "gaokao")
 * @property {string} name Chinese name (e.g. "高考")
 * @property {number} m    Month (1-12)
 * @property {number} [d]  Day of month (omitted when `rule` is present)
 * @property {"1st-sun"|"2nd-sat"} [rule] Weekday-based date rule
 * @property {string} cat  Category (e.g. "升学考试")
 * @property {string} note  Disclaimer / helpful note
 */
export const EXAMS = [
  // ── 升学考试 ──
  { id: 'gaokao', name: '高考', m: 6, d: 7, cat: '升学考试', note: '全国统一 6 月 7-8 日' },
  { id: 'zhongkao', name: '中考', m: 6, d: 15, cat: '升学考试', note: '各省不同，多在 6 月' },
  { id: 'kaoyan', name: '考研初试', m: 12, d: 21, cat: '升学考试', note: '通常在 12 月' },
  { id: 'kaoyan-2', name: '考研复试', m: 3, d: 20, cat: '升学考试', note: '各校不同，约 3-4 月' },
  { id: 'chengkao', name: '成人高考', m: 10, d: 19, cat: '升学考试', note: '通常在 10 月' },
  { id: 'zikao-4', name: '自学考试（4月）', m: 4, d: 12, cat: '升学考试', note: '4 月与 10 月各一次' },
  { id: 'zikao-10', name: '自学考试（10月）', m: 10, d: 25, cat: '升学考试', note: '4 月与 10 月各一次' },
  { id: 'zsb', name: '专升本考试', m: 4, d: 19, cat: '升学考试', note: '各省不同，多在 4 月' },

  // ── 公务员 ──
  { id: 'guokao', name: '国考（笔试）', m: 11, d: 26, cat: '公务员', note: '通常在 11 月底-12 月初' },
  { id: 'shengkao', name: '省考（多省联考）', m: 3, d: 15, cat: '公务员', note: '多在 3-4 月' },
  { id: 'wendui', name: '军队文职笔试', m: 12, d: 14, cat: '公务员', note: '以当年公告为准' },
  { id: 'xuanxiao', name: '选调生考试', m: 11, d: 15, cat: '公务员', note: '各省不同' },
  { id: 'shiye', name: '事业单位统考', m: 5, d: 10, cat: '公务员', note: '多地 5 月统考，时间不一' },

  // ── 英语考试 ──
  { id: 'cet-6', name: '英语四六级（6月）', rule: '2nd-sat', m: 6, cat: '英语考试', note: '每年 6 月第二个周六' },
  { id: 'cet-12', name: '英语四六级（12月）', rule: '2nd-sat', m: 12, cat: '英语考试', note: '每年 12 月第二个周六' },
  { id: 'tem4', name: '专四 TEM-4', m: 6, d: 15, cat: '英语考试', note: '通常 6 月' },
  { id: 'tem8', name: '专八 TEM-8', m: 4, d: 27, cat: '英语考试', note: '通常 4 月底' },
  { id: 'pets-3', name: 'PETS 英语等级（3月）', m: 3, d: 22, cat: '英语考试', note: '3 月与 9 月各一次' },
  { id: 'pets-9', name: 'PETS 英语等级（9月）', m: 9, d: 20, cat: '英语考试', note: '3 月与 9 月各一次' },
  { id: 'putonghua', name: '普通话水平测试', m: 6, d: 15, cat: '英语考试', note: '各地每月安排，以测试站为准' },
  { id: 'jlpt-7', name: 'JLPT 日语（7月）', rule: '1st-sun', m: 7, cat: '英语考试', note: '每年 7 月第一个周日' },
  { id: 'jlpt-12', name: 'JLPT 日语（12月）', rule: '1st-sun', m: 12, cat: '英语考试', note: '每年 12 月第一个周日' },
  { id: 'topik', name: 'TOPIK 韩语（4月）', m: 4, d: 13, cat: '英语考试', note: '每年多次，以公告为准' },

  // ── 教师资格 ──
  { id: 'jzb-3', name: '教师资格证笔试（3月）', m: 3, d: 8, cat: '教师资格', note: '3 月与 9 月各一次' },
  { id: 'jzb-9', name: '教师资格证笔试（9月）', m: 9, d: 13, cat: '教师资格', note: '3 月与 9 月各一次' },
  { id: 'jzm-1', name: '教师资格证面试（1月）', m: 1, d: 4, cat: '教师资格', note: '1 月与 5 月各一次' },
  { id: 'jzm-5', name: '教师资格证面试（5月）', m: 5, d: 17, cat: '教师资格', note: '1 月与 5 月各一次' },

  // ── 会计金融 ──
  { id: 'chuji', name: '初级会计职称', m: 5, d: 17, cat: '会计金融', note: '通常 5 月' },
  { id: 'gaoji', name: '高级会计职称', m: 5, d: 17, cat: '会计金融', note: '与初级会计同期' },
  { id: 'zhongji', name: '中级会计职称', m: 9, d: 6, cat: '会计金融', note: '通常 9 月上旬' },
  { id: 'cpa', name: '注册会计师 CPA', m: 8, d: 23, cat: '会计金融', note: '通常 8 月下旬' },
  { id: 'sws', name: '税务师', m: 11, d: 15, cat: '会计金融', note: '通常 11 月' },
  { id: 'jjs', name: '经济师（初中级）', m: 11, d: 15, cat: '会计金融', note: '通常 11 月' },
  { id: 'zcpg', name: '资产评估师', m: 9, d: 20, cat: '会计金融', note: '通常 9 月' },
  { id: 'sjs', name: '审计师', m: 9, d: 28, cat: '会计金融', note: '通常 9 月' },
  { id: 'yinhang', name: '银行从业资格', m: 6, d: 7, cat: '会计金融', note: '6 月与 10 月，以公告为准' },
  { id: 'jijin', name: '基金从业资格', m: 7, d: 12, cat: '会计金融', note: '每年多次，以公告为准' },
  { id: 'zq', name: '证券从业资格', m: 6, d: 28, cat: '会计金融', note: '每年多次，以公告为准' },

  // ── 法律工程 ──
  { id: 'fakao-k', name: '法考（客观题）', m: 9, d: 13, cat: '法律工程', note: '通常 9 月' },
  { id: 'fakao-z', name: '法考（主观题）', m: 10, d: 12, cat: '法律工程', note: '通常 10 月' },
  { id: 'yjzs', name: '一级建造师', m: 9, d: 20, cat: '法律工程', note: '通常 9 月下旬' },
  { id: 'ejzs', name: '二级建造师', m: 6, d: 7, cat: '法律工程', note: '各省不同，多在 6 月' },
  { id: 'zjzs', name: '一级造价工程师', m: 10, d: 18, cat: '法律工程', note: '通常 10 月' },
  { id: 'xf', name: '一级消防工程师', m: 11, d: 8, cat: '法律工程', note: '通常 11 月' },
  { id: 'jzs', name: '一级注册建筑师', m: 5, d: 10, cat: '法律工程', note: '5 月与 10 月' },
  { id: 'ytjg', name: '注册岩土/结构工程师', m: 11, d: 1, cat: '法律工程', note: '通常 11 月初' },
  { id: 'jl', name: '监理工程师', m: 5, d: 17, cat: '法律工程', note: '通常 5 月' },
  { id: 'zx', name: '咨询工程师', m: 4, d: 12, cat: '法律工程', note: '通常 4 月' },
  { id: 'gh', name: '城乡规划师', m: 9, d: 20, cat: '法律工程', note: '通常 9 月' },

  // ── 医学健康 ──
  { id: 'yishi-b', name: '执业医师（笔试）', m: 8, d: 22, cat: '医学健康', note: '通常 8 月' },
  { id: 'yishi-j', name: '执业医师（技能）', m: 6, d: 14, cat: '医学健康', note: '通常 6 月' },
  { id: 'hushi', name: '护士执业资格', m: 4, d: 26, cat: '医学健康', note: '通常 4 月底' },
  { id: 'yaoshi', name: '执业药师', m: 10, d: 18, cat: '医学健康', note: '通常 10 月' },
  { id: 'weish', name: '卫生专业技术资格', m: 4, d: 12, cat: '医学健康', note: '通常 4 月' },
  { id: 'sg', name: '社会工作师', m: 6, d: 14, cat: '医学健康', note: '通常 6 月' },

  // ── 计算机 ──
  { id: 'rk-5', name: '软考（5月）', m: 5, d: 24, cat: '计算机', note: '5 月与 11 月各一次' },
  { id: 'rk-11', name: '软考（11月）', m: 11, d: 8, cat: '计算机', note: '5 月与 11 月各一次' },
  { id: 'ncre-3', name: '计算机等级（3月）', m: 3, d: 29, cat: '计算机', note: '3 月与 9 月各一次' },
  { id: 'ncre-9', name: '计算机等级（9月）', m: 9, d: 20, cat: '计算机', note: '3 月与 9 月各一次' },

  // ── 其他 ──
  { id: 'catti-6', name: 'CATTI 翻译（6月）', m: 6, d: 21, cat: '其他', note: '6 月与 11 月各一次' },
  { id: 'catti-11', name: 'CATTI 翻译（11月）', m: 11, d: 1, cat: '其他', note: '6 月与 11 月各一次' },
  { id: 'chuban', name: '出版专业技术资格', m: 10, d: 11, cat: '其他', note: '通常 10 月' },
  { id: 'zhuanli', name: '专利代理师', m: 7, d: 5, cat: '其他', note: '通常 7 月' },
  { id: 'daoyou', name: '导游资格考试', m: 11, d: 22, cat: '其他', note: '通常 11 月' },
]

// ---------------------------------------------------------------- date math

/** Normalize a date to local midnight. */
export function startOfDay(d) {
  const x = new Date(d)
  x.setHours(0, 0, 0, 0)
  return x
}

/**
 * Resolve a weekday-based date rule to an actual Date for (year, month).
 * `"1st-sun"` = the first Sunday of the month; `"2nd-sat"` = the second Saturday.
 */
export function ruleDate(rule, year, month) {
  const first = new Date(year, month - 1, 1)
  const dow = first.getDay() // 0 = Sunday
  let day
  if (rule === '1st-sun') day = 1 + ((7 - dow) % 7)
  if (rule === '2nd-sat') day = 1 + ((6 - dow + 7) % 7) + 7
  return new Date(year, month - 1, day)
}

/**
 * Find the next occurrence of an exam after `today`. If this year's date has
 * already passed (or is today), roll forward to next year — dates recur yearly.
 */
export function nextOccurrence(exam, today) {
  const y = today.getFullYear()
  let c
  if (exam.rule) {
    c = ruleDate(exam.rule, y, exam.m)
    if (c < today) c = ruleDate(exam.rule, y + 1, exam.m)
  } else {
    c = new Date(y, exam.m - 1, exam.d)
    if (c < today) c = new Date(y + 1, exam.m - 1, exam.d)
  }
  return c
}

/** Whole days between two dates (b - a), rounded. */
export function daysBetween(a, b) {
  return Math.round((b - a) / 86400000)
}

/** Format a Date as `YYYY-MM-DD` for stable JSON output. */
export function fmtDate(d) {
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}

/**
 * Decorate an exam with its next occurrence, day count and date label.
 * Pure — no I/O, safe to import from tests without a cordis runtime.
 */
export function decorate(exam, today) {
  const next = nextOccurrence(exam, today)
  const days = daysBetween(today, next)
  return {
    id: exam.id,
    name: exam.name,
    cat: exam.cat,
    dateLabel: `${next.getMonth() + 1}月${next.getDate()}日`,
    days,
    nextOccurrence: fmtDate(next),
  }
}

/**
 * Pure query logic behind the `exam_countdown` tool.
 *
 * @param {{id?: string, query?: string, category?: string, limit?: number}} args
 * @param {Date} [today]  Optional reference date (defaults to now).
 * @returns {string} Pretty-printed JSON array of { id, name, cat, dateLabel,
 *   days, nextOccurrence }, sorted by days ascending, upcoming only.
 */
export function queryExams(args = {}, today = new Date()) {
  const t = startOfDay(today)
  const lim = Number.isFinite(Number(args.limit)) && Number(args.limit) > 0
    ? Math.floor(Number(args.limit))
    : 10

  if (args.id) {
    const ex = EXAMS.find((e) => e.id === String(args.id))
    if (!ex) return JSON.stringify({ error: `No exam found with id "${args.id}"` }, null, 2)
    return JSON.stringify([decorate(ex, t)], null, 2)
  }

  let pool = EXAMS
  if (args.query) {
    const q = String(args.query).toLowerCase()
    pool = pool.filter((e) =>
      e.name.toLowerCase().includes(q) ||
      e.id.toLowerCase().includes(q) ||
      (e.note || '').toLowerCase().includes(q),
    )
  }
  if (args.category) {
    pool = pool.filter((e) => e.cat === String(args.category))
  }

  const rows = pool
    .map((e) => decorate(e, t))
    .filter((e) => e.days >= 0)
    .sort((a, b) => a.days - b.days || a.name.localeCompare(b.name, 'zh'))
    .slice(0, lim)

  return JSON.stringify(rows, null, 2)
}

/**
 * Pure query logic behind the `exam_categories` tool.
 * @returns {string} Pretty-printed JSON array of { category, count }.
 */
export function examCategories() {
  const counts = new Map()
  for (const e of EXAMS) counts.set(e.cat, (counts.get(e.cat) ?? 0) + 1)
  const rows = [...counts.entries()]
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count || a.category.localeCompare(b.category, 'zh'))
  return JSON.stringify(rows, null, 2)
}

// ---------------------------------------------------------------- tools

const renderText = (_args, value) => [{ type: 'text', text: value }]

export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'exam_countdown',
    description:
      'Query the built-in Chinese exam dataset (64 exams) and get days-until countdowns. ' +
      'Filter by `id` (exact slug, e.g. "gaokao", "kaoyan", "cpa", "cet-6"), by `query` ' +
      '(substring match against Chinese name / slug / note), or by `category` ' +
      '(e.g. "升学考试", "公务员", "英语考试", "教师资格", "会计金融", "法律工程", ' +
      '"医学健康", "计算机", "其他"). Results are sorted by days ascending, include only ' +
      'upcoming occurrences (days >= 0), and roll to next year once a date has passed. ' +
      'Rule-based dates are computed exactly: 英语四六级/CET uses the 2nd Saturday, ' +
      'JLPT uses the 1st Sunday of the month. Each result: { id, name, cat, dateLabel, ' +
      'days, nextOccurrence }. Dates are typical yearly dates for reference only — ' +
      'always confirm with official announcements.',
    parameters: {
      id: { type: 'string', description: 'Exact exam slug to look up, e.g. "gaokao". Overrides query/category.' },
      query: { type: 'string', description: 'Search text matched against exam name, id or note (case-insensitive).' },
      category: { type: 'string', description: 'Category name to filter by, e.g. "公务员".' },
      limit: { type: 'number', description: 'Maximum number of results to return (default 10).' },
    },
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute(args) {
      return queryExams(args, new Date())
    },
  }))

  ctx.tools.register(defineTool({
    name: 'exam_categories',
    description:
      'List the exam categories available in the built-in dataset with the number of ' +
      'exams in each (e.g. 升学考试, 公务员, 英语考试, 教师资格, 会计金融, 法律工程, ' +
      '医学健康, 计算机, 其他). Returns JSON: [{ category, count }] sorted by count ' +
      'descending. Use this to discover valid `category` values for exam_countdown.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute() {
      return examCategories()
    },
  }))
}
