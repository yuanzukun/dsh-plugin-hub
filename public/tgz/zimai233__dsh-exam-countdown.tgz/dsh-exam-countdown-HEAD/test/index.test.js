import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  EXAMS,
  ruleDate,
  nextOccurrence,
  daysBetween,
  queryExams,
  examCategories,
} from '../src/index.js'

test('ruleDate computes the 2nd Saturday of June 2026 as June 13', () => {
  const d = ruleDate('2nd-sat', 2026, 6)
  assert.equal(d.getFullYear(), 2026)
  assert.equal(d.getMonth(), 5) // 0-indexed
  assert.equal(d.getDate(), 13)
  assert.equal(d.getDay(), 6) // Saturday
})

test('ruleDate computes the 1st Sunday of July 2026 as July 5', () => {
  const d = ruleDate('1st-sun', 2026, 7)
  assert.equal(d.getFullYear(), 2026)
  assert.equal(d.getMonth(), 6) // 0-indexed
  assert.equal(d.getDate(), 5)
  assert.equal(d.getDay(), 0) // Sunday
})

test('nextOccurrence rolls to next year when this year\'s date has passed', () => {
  // Gaokao = June 7. "Today" is July 1 2026 → next is June 7 2027.
  const gaokao = EXAMS.find((e) => e.id === 'gaokao')
  const today = new Date(2026, 6, 1) // July 1 2026
  const next = nextOccurrence(gaokao, today)
  assert.equal(next.getFullYear(), 2027)
  assert.equal(next.getMonth(), 5)
  assert.equal(next.getDate(), 7)
  assert.ok(daysBetween(today, next) > 0)
})

test('nextOccurrence rolls rule-based exams (2nd-sat) across years', () => {
  // CET-4/6 in June 2026 = June 13. After that, next is June 12 2027.
  const cet = EXAMS.find((e) => e.id === 'cet-6')
  const today = new Date(2026, 6, 1) // July 1 2026
  const next = nextOccurrence(cet, today)
  assert.equal(next.getFullYear(), 2027)
  assert.equal(next.getDate(), 12) // 2nd Saturday of June 2027
  assert.equal(next.getDay(), 6)
})

test('queryExams returns the gaokao entry when id="gaokao"', () => {
  const out = queryExams({ id: 'gaokao' }, new Date(2026, 6, 1))
  const rows = JSON.parse(out)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].id, 'gaokao')
  assert.equal(rows[0].name, '高考')
  assert.equal(rows[0].cat, '升学考试')
  assert.equal(typeof rows[0].days, 'number')
  assert.ok(rows[0].days >= 0)
  assert.match(rows[0].dateLabel, /^\d+月\d+日$/)
  assert.match(rows[0].nextOccurrence, /^\d{4}-\d{2}-\d{2}$/)
})

test('queryExams searches by query and sorts by days ascending', () => {
  const out = queryExams({ query: '会计', limit: 5 }, new Date(2026, 6, 1))
  const rows = JSON.parse(out)
  assert.ok(rows.length > 0 && rows.length <= 5)
  for (const r of rows) assert.ok(r.days >= 0)
  for (let i = 1; i < rows.length; i++) assert.ok(rows[i - 1].days <= rows[i].days)
})

test('queryExams filters by category and reports unknown id as error', () => {
  const out = queryExams({ category: '计算机' }, new Date(2026, 6, 1))
  const rows = JSON.parse(out)
  assert.ok(rows.length > 0)
  for (const r of rows) assert.equal(r.cat, '计算机')

  const missing = JSON.parse(queryExams({ id: 'nope' }, new Date(2026, 6, 1)))
  assert.ok(missing.error)
})

test('examCategories returns unique categories with counts summing to the dataset size', () => {
  const cats = JSON.parse(examCategories())
  assert.ok(cats.length >= 5)
  const total = cats.reduce((s, c) => s + c.count, 0)
  assert.equal(total, EXAMS.length)
  for (const c of cats) assert.ok(c.count > 0)
})

test('dataset contains at least 60 exams with the expected flagship entry', () => {
  assert.ok(EXAMS.length >= 60)
  const ids = new Set(EXAMS.map((e) => e.id))
  assert.equal(ids.size, EXAMS.length) // unique ids
  const gaokao = EXAMS.find((e) => e.id === 'gaokao')
  assert.equal(gaokao.name, '高考')
  assert.equal(gaokao.m, 6)
  assert.equal(gaokao.d, 7)
  for (const e of EXAMS) {
    assert.ok(e.id && e.name && e.m && e.cat, `entry missing required fields: ${e.id}`)
    assert.ok(e.d >= 1 || e.rule, `entry missing day or rule: ${e.id}`)
  }
})
