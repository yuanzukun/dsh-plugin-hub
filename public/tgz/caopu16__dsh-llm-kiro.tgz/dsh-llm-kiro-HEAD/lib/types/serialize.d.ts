/**
 * Serialize harness messages into a Kiro `generateAssistantResponse` request.
 *
 * Three properties of the wire operation drive the whole translation:
 *
 * - There is no system slot. The system prompt is prepended to the content of
 *   the first user turn, which is also where the thinking-mode markers go.
 * - The last user turn is `currentMessage`, not a history entry, and
 *   `conversationState.history` must strictly alternate user, assistant, user,
 *   …, so gaps are filled with continuation placeholders.
 * - Tool results are per-turn context on the user message that carries them,
 *   and the service rejects a result whose `toolUseId` no history entry
 *   issued, so unmatched results degrade to text.
 *
 * @module dsh-llm-kiro/serialize
 */
import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { WireRequest } from './types.ts';
/** Adapter-level request defaults resolved from plugin config. */
export interface RequestDefaults {
    /** Deployment thinking policy; `disabled` refuses every request-level enable. */
    thinking?: 'enabled' | 'disabled' | undefined;
    /** Default thinking effort when a request names none. */
    reasoningEffort?: 'off' | 'low' | 'medium' | 'high' | undefined;
}
/**
 * Reverse {@link assertToolName} for one turn's tool set.
 *
 * The model answers with the wire name, but the harness dispatches on its own.
 * ponytail: last alias wins on collision (`a-b` and `a_b` offered together);
 * the MCP bridge upstream already hashes distinct identities apart, so add a
 * disambiguating suffix only if a real collision appears.
 * @param names - the harness tool names offered on this turn.
 * @returns wire name to harness name, only for names an alias changed.
 */
export declare function kiroToolAliases(names: readonly string[]): Map<string, string>;
/**
 * Build the complete wire request.
 *
 * The final user turn becomes `currentMessage` and carries the tool schemas;
 * everything before it becomes alternating history. A conversation whose last
 * turn is the assistant's (a resumed session, a compaction boundary) gets a
 * continuation user turn so there is something to answer.
 * @param options - the harness request.
 * @param defaults - adapter-level thinking defaults.
 * @param conversationId - identifier for this request's conversation.
 * @param profileArn - CodeWhisperer profile the account bills against.
 * @returns the request body.
 * @throws `LlmError` when the request carries images, an unusable tool name,
 *   an unsupported effort, or no messages at all.
 */
export declare function serializeRequest(options: GenerateOptions, defaults: RequestDefaults, conversationId: string, profileArn?: string): WireRequest;
