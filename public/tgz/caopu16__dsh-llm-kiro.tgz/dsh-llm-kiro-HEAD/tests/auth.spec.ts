import { mkdir, mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { beforeEach, describe, expect, it } from "vitest";
import { clearTokenCache, discoverProfileArn, resolveToken } from "../src/auth.ts";

/** The globalStorage path each Kiro client writes its active profile to. */
const SERVER_PROFILE = [".kiro-server", "data", "User", "globalStorage", "kiro.kiroagent"];
const IDE_PROFILE = [".kiro", "data", "User", "globalStorage", "kiro.kiroagent"];

/** Write one profile file under a fake home. */
async function writeProfile(
  home: string,
  parts: readonly string[],
  contents: string,
): Promise<void> {
  const directory = join(home, ...parts);
  await mkdir(directory, { recursive: true });
  await writeFile(join(directory, "profile.json"), contents);
}

describe("discoverProfileArn", () => {
  let home: string;

  beforeEach(async () => {
    home = await mkdtemp(join(tmpdir(), "kiro-auth-"));
  });

  it("reads the ARN the remote-server client recorded", async () => {
    const arn = "arn:aws:codewhisperer:us-east-1:864899876375:profile/XQRWKPX7Y9KY";
    await writeProfile(
      home,
      SERVER_PROFILE,
      JSON.stringify({ arn, name: "KiroProfile-us-east-1" }),
    );
    expect(await discoverProfileArn(home)).toBe(arn);
  });

  it("falls back to the desktop IDE layout", async () => {
    const arn = "arn:aws:codewhisperer:us-west-2:1:profile/DESKTOP";
    await writeProfile(home, IDE_PROFILE, JSON.stringify({ arn }));
    expect(await discoverProfileArn(home)).toBe(arn);
  });

  it("prefers the remote-server layout when both are present", async () => {
    await writeProfile(home, SERVER_PROFILE, JSON.stringify({ arn: "arn:server" }));
    await writeProfile(home, IDE_PROFILE, JSON.stringify({ arn: "arn:ide" }));
    expect(await discoverProfileArn(home)).toBe("arn:server");
  });

  it("reports absence rather than failing, since a personal account needs no profile", async () => {
    expect(await discoverProfileArn(home)).toBeUndefined();
  });

  it("skips a malformed or empty file instead of failing the request", async () => {
    await writeProfile(home, SERVER_PROFILE, "{not json");
    expect(await discoverProfileArn(home)).toBeUndefined();

    await writeProfile(home, SERVER_PROFILE, JSON.stringify({ arn: "" }));
    expect(await discoverProfileArn(home)).toBeUndefined();

    // A broken first candidate must not hide a usable second one.
    await writeProfile(home, IDE_PROFILE, JSON.stringify({ arn: "arn:ide" }));
    expect(await discoverProfileArn(home)).toBe("arn:ide");
  });
});

describe("resolveToken", () => {
  let cacheDir: string;
  let home: string;

  /** Refuse to be called; every case here resolves from disk. */
  const noRefresh = () => Promise.reject(new Error("unexpected refresh"));

  beforeEach(async () => {
    clearTokenCache();
    cacheDir = await mkdtemp(join(tmpdir(), "kiro-cache-"));
    home = await mkdtemp(join(tmpdir(), "kiro-home-"));
    await writeFile(
      join(cacheDir, "kiro-auth-token.json"),
      JSON.stringify({
        accessToken: "live-token",
        refreshToken: "refresh",
        expiresAt: new Date(Date.now() + 3_600_000).toISOString(),
        clientIdHash: "hash",
        region: "us-east-1",
      }),
    );
  });

  it("carries the discovered profile ARN on the token", async () => {
    const arn = "arn:aws:codewhisperer:us-east-1:1:profile/FOUND";
    await writeProfile(home, SERVER_PROFILE, JSON.stringify({ arn }));
    const token = await resolveToken({
      cacheDir,
      homeDir: home,
      expiryBufferMs: 0,
      fetchJson: noRefresh,
    });
    expect(token).toMatchObject({
      accessToken: "live-token",
      region: "us-east-1",
      profileArn: arn,
    });
  });

  it("omits the ARN entirely when no client recorded one", async () => {
    const token = await resolveToken({
      cacheDir,
      homeDir: home,
      expiryBufferMs: 0,
      fetchJson: noRefresh,
    });
    expect("profileArn" in token).toBe(false);
  });
});
