/**
 * Client-side notification rendering: the pure parts (title/body/gating) split
 * out for unit tests, while the `Notification` construction stays in the thin
 * runner wired by the plugin body.
 */
import type { NotificationReason, PendingKind } from '../contract.ts'

/** The reason title key for one turn-end reason. */
export function titleKey(reason: NotificationReason): 'notify.titleCompleted' | 'notify.titleError' | 'notify.titleAborted' | 'notify.titleBlocked' | 'notify.titleMaxTokens' {
  switch (reason) {
    case 'completed': return 'notify.titleCompleted'
    case 'error': return 'notify.titleError'
    case 'aborted': return 'notify.titleAborted'
    case 'blocked': return 'notify.titleBlocked'
    case 'max-tokens': return 'notify.titleMaxTokens'
  }
}

/** The title key for one pending interaction. */
export function pendingTitleKey(kind: PendingKind): 'notify.titleApproval' | 'notify.titleQuestion' | 'notify.titlePlanReview' {
  switch (kind) {
    case 'approval': return 'notify.titleApproval'
    case 'question': return 'notify.titleQuestion'
    case 'plan-review': return 'notify.titlePlanReview'
  }
}

/** The notification body: the reply snippet, or the empty-body fallback. */
export function bodyText(body: string, emptyBody: string): string {
  const trimmed = body.trim()
  return trimmed === '' ? emptyBody : trimmed
}

/**
 * Whether a completion should surface a desktop notification, given the browser
 * permission, the background-only preference, page visibility, and whether
 * the completed session is the one currently in view.
 */
export function shouldShow(
  permission: NotificationPermission,
  backgroundOnly: boolean,
  documentHidden: boolean,
  completedSessionId?: string,
  currentSessionId?: string,
): boolean {
  if (permission !== 'granted') return false
  if (backgroundOnly && !documentHidden && completedSessionId === currentSessionId) return false
  return true
}

/**
 * The grouping tag: one notification slot per session per turn. Turn-scoped
 * (not session-scoped): the browser replaces same-tag notifications, and a
 * stale same-tag entry lingering in the Windows notification center silently
 * swallows every later notification with that tag — a per-turn tag guarantees
 * each completed turn's toast always shows.
 */
export function notificationTag(sessionId: string, turn: number): string {
  return `dsh-notification-${sessionId}-${turn}`
}

/** A unique tag for each pending interaction notification in one session. */
export function pendingNotificationTag(sessionId: string, sequence: number): string {
  return `dsh-notification-pending-${sessionId}-${sequence}`
}

/** The surface this code may show notifications on (absent in insecure contexts). */
export function notificationsApi(): typeof Notification | undefined {
  return typeof Notification === 'undefined' ? undefined : Notification
}

/** The result of asking the browser to construct one system notification. */
export type NotificationCreationResult =
  | { readonly ok: true; readonly notification: Notification }
  | { readonly ok: false; readonly message: string }

/** Construct one notification without allowing browser failures to disappear silently. */
export function createBrowserNotification(
  api: typeof Notification | undefined,
  title: string,
  options: NotificationOptions,
): NotificationCreationResult {
  if (api === undefined) return { ok: false, message: 'The Notification API is unavailable in this browser context.' }
  if (api.permission !== 'granted') return { ok: false, message: 'Notification permission is not granted.' }
  try {
    return { ok: true, notification: new api(title, options) }
  } catch (error) {
    /* v8 ignore next -- browsers throw Error objects for constructor failures. */
    const message = error instanceof Error ? error.message : String(error)
    return { ok: false, message }
  }
}
