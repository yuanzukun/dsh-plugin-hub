// broken-window-heal.test.mjs — 破窗复位（宿主侧结构入口）的结构回归锁（2026-09-21）
// ---------------------------------------------------------------------------
// 被锁定的结构：**破窗不是会话死锁** —— 止损态必须有一条从外部（宿主机）复位它的线。
//
// 为什么这条线必须有（结构理由，不是便利功能）：
//   破窗一旦成立，`pre-execute` 拒绝**一切**调用 —— **连同"修复动作本身"** ⇒ 宿主侧若无复位入口，
//   破窗即会话级死锁（唯一出路＝重启进程）。引擎里 `healWindow()` 早已存在，但只经
//   `resolveBug()`（闭环验证通过）/ `settleWindow()`（阶段到期）到达，二者在 DSH 会话里都不由被
//   审计的模型触达 ⇒ 缺的是**线**，不是**能力**。
//
// 结构纪律（本组同时锁住的第二条）：
//   · 复位入口是**模块级 API，不是工具** ⇒ 模型调不到 ⇒ **结构上不可能自我解锁**
//     （与 `setPrincipalScope` 同源：主体分离由位置保证，不靠内容判别）。
//   · 复位必须**如实记数**（先读复位前状态再治）——报告不得把"没破的"也算成"治过的"。
import test from 'node:test';
import assert from 'node:assert/strict';
import { apply, healBrokenWindow } from '../src/index.js';

function mockCtx() {
  const handlers = {};
  const tools = [];
  const ctx = {
    on: (ev, cb) => { handlers[ev] = cb; },
    tools: { register: (t) => { tools.push(t); } },
  };
  return { ctx, handlers, tools };
}

const exec = (name, args) => ({ token: 't', callId: 'c1', name, arguments: args, signal: null });
const badReceipt = (t = 'prior failure') => ({ content: [{ type: 'text', text: t }], isError: true, error: { message: t } });
const NEXT = 'NEXT';
const next = async () => NEXT;
const toolNamed = (tools, n) => tools.find((t) => t.name === n);
const accrueFailures = (handlers, n) => { for (let i = 0; i < n; i += 1) handlers['tools/result'](exec('read', {}), badReceipt()); };
const streakOf = async (tools) => (await toolNamed(tools, 'query_steady_state').execute({}, {})).failureStreak;
const probeCall = () => exec('read', { file_path: '/tmp/ok.txt' });   // 无害调用：唯一可能被拒的理由只有破窗

// 🔴 [2026-10-29 · identity layer (xiaoD #45 §6 · the trustee's definition)] A reset must be triggered by
//   the **decider**: host = the executing AI (executor) | the decider and the reset authority = the user
//   (decider). ⇒ the reset entry now takes an actor; no actor = treated as the executor = **refused**
//   (fail-closed). Every reset in this group is made **as the decider** (the host acting for the user).
const DECIDER = 'decider';

// 这一条先跑：到此刻为止本进程内不应有任何实例处于破窗态（后面的用例自会制造，并各自收尾）。
test('复位如实记数：无实例破窗时 wereBroken = 0（不虚报"治了"）', () => {
  const rec = healBrokenWindow('cleanup check: nothing should be broken yet', DECIDER);
  assert.equal(rec.kind, 'heal-window');
  assert.equal(rec.wereBroken, 0, '未破窗不得报成治好（先读后治）');
  assert.equal(rec.note, 'cleanup check: nothing should be broken yet', '复位必须留痕（何时因何解除）');
  assert.equal(rec.actor, DECIDER, 'the reset record must carry the actor (who cleared it)');
});

test('🔴 越权复位被拒：执行方（被审的 AI）不能给自己签复位', () => {
  const denied = healBrokenWindow('executor self-reset', 'executor');
  assert.equal(denied.kind, 'heal-window-denied', 'the executor (the audited AI) cannot sign its own reset');
  assert.match(denied.reason, /reset belongs to the decider/, 'the refusal must state the ownership');
  const noActor = healBrokenWindow('no actor declared', undefined);
  assert.equal(noActor.kind, 'heal-window-denied', 'no actor declared ⇒ fail-closed (treated as the executor ⇒ refused)');
});

test('破窗成立 ⇒ pre-execute 拒绝一切调用；宿主复位后同一调用被放行（止损不是死锁）', async () => {
  const { ctx, handlers, tools } = mockCtx();
  apply(ctx);
  accrueFailures(handlers, 5);   // 偏离累积 = cap
  assert.equal(await streakOf(tools), 5, '入账走公开钩子面（按契约参数位）');

  const denied = await handlers['tools/pre-execute'](probeCall(), next);
  assert.equal(denied?.kind, 'deny', '破窗成立后未达终局的调用必须在执行前被拒');
  assert.ok(/broken-window|破窗/.test(String(denied.reason)), '拒绝理由须点名破窗止损（可归因，不是笼统 deny；中英话术均须点名）');

  const rec = healBrokenWindow('fault fixed and verified (test)', DECIDER);
  assert.ok(rec.wereBroken >= 1, '复位报告须承认此前确有实例在破窗态');

  const released = await handlers['tools/pre-execute'](probeCall(), next);
  assert.equal(released, NEXT, '复位后必须真的放行——否则破窗即会话级死锁，无从修复');

  const cleared = await streakOf(tools);
  assert.equal(cleared, 0, '复位须归零累积（真解除窗口，而不是只改一个读数）');
});

test('复位入口不是工具：模型面看不到它（结构入口 ≠ 工具面，自我解锁结构上不可能）', () => {
  const { ctx, tools } = mockCtx();
  apply(ctx);
  const leaked = tools.find((t) => t.name === 'healBrokenWindow' || t.name === 'heal_broken_window');
  assert.equal(leaked, undefined, '复位入口一旦成为工具，被审计方即可自我解锁');
});

test('复位留痕：同一入口多次调用持续可溯（不静默清空）', () => {
  healBrokenWindow('trace check #1', DECIDER);
  const rec = healBrokenWindow('trace check #2', DECIDER);
  assert.equal(rec.note, 'trace check #2');
  assert.ok(rec.at, '留痕须带时间（"何时解除的"必须查得出）');
});
