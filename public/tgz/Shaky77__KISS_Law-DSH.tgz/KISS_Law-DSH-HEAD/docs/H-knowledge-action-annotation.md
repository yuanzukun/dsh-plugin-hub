# Concept Annotation: H and the "Unity of Knowing & Acting"

> **Author's insight** (Shaky77, 2026-08-28):
> "Inner-H resembles *knowing* (知); outer-H resembles *acting* (行). The unity of knowing and acting is the maximum leverage — and this is precisely why H is the only variable, the only sovereignty, and the leverage point. Because in the common world, there is a vast gap between knowing and acting."

This is a conceptual bridge for understanding H's special status within R→S→D→H→M. It **does not enter the `law.mjs` definition layer** and does not modify engine logic.

---

## 1. Mapping

| Weiwen's Law H | Knowing/Acting | Meaning |
| --- | --- | --- |
| **Inner H** (thoughts / decisions / free will, seat of agency) | **knowing (知)** | the agent's inner "knowing, recognizing, intending" — cognition and intent |
| **Outer H** (external variables grounded in objective observable facts / behavior) | **acting (行)** | the agent's outer "carrying out, landing" — behavior and observable result |
| **H as a whole** (inner + outer adjudicated together) | **unity of knowing & acting (知行合一)** | knowing and acting share one agent, one causal chain, undivided |

---

## 2. Why H is the only variable

In R→S→D→H→M, R / S / D / M are the fixed scaffolding of how causality runs — the world's given structure. Only H carries the agent's own will (knowing) and action (acting).

- R, S, D, M belong to the *environment*;
- H belongs to the *agent*.

Hence along the whole chain, the only thing the agent can vary is H — it is the only variable.

---

## 3. Why H is the only sovereignty

Sovereignty = what belongs to the agent, for which the agent is responsible, and which no external system may decide on its behalf.

- R / S / D / M are objective causal structure (belonging to no one);
- only H (your *knowing* and your *acting*) is your sovereign domain.

This is exactly why Iron Law ① "**inner H cannot be invaded**" holds — your *knowing* is sovereign territory; no external system may overwrite or decide it for you. The framework guards inner H precisely because it guards sovereignty.

---

## 4. Why H is the leverage point

The leverage point is where a small input moves a large output. When *knowing* (inner H) and *acting* (outer H) are unified, the agent's intent and action become one coherent, non-dissipating force — that unity is maximum leverage. The common gap between knowing and acting dissipates the agent's force.

The framework renders H **white-box**: inner H (knowing) and outer H (acting) are queryable / auditable, making the knowing–acting gap *visible, measurable, and closeable* — turning "unity of knowing and acting" from philosophy into an engineerable closed loop.

---

## 5. The gap

"In the common world, a vast gap lies between knowing and acting" — the universal source of inefficiency. Most systems split knowing and acting (optimizing cognition alone, or bolting on behavior guardrails alone).

Weiwen's Law, by splitting H into inner / outer, structurally recognizes that knowing and acting are **two faces of one sovereign variable**, and that **closing that gap is itself the leverage**.

---

## 6. The common external misread: "bigger is better"? The opposite

External readers of H easily make an intuitive error: **treating H as a "bigger-is-better" capacity dial** — assuming that since H is "the only variable / the only sovereignty / the leverage point", one should crank it up and max out both knowing and acting.

But the opposite is true:

- H's leverage **lies not in magnitude but in unity**. The leverage comes from the degree of "knowing = acting" alignment, not from H's absolute size.
- An H that is large in volume but carries a large gap between knowing and acting is **not "more leverage" but "more dissipation"** — knowing without acting, acting without knowing; the force leaks away, and the bigger the volume, the more it leaks.
- So the real goal is not "make H big" but "make H unified": **smaller but unified beats larger but split**.

This is isomorphic with the rest of the framework: First-Bug Halt is "sever to preserve continuity" (severing is the means, surviving is the end); inner-H inviolability guards the sovereign boundary — the framework's point of force is **constraint and alignment, not expansion**. Treating H as "bigger is better" and cranking it up turns the direction exactly backwards.

### 6.1 Why this is a *root-cause* misread — the misattribution trap

Treating H as "bigger is better" and cranking it is not a mere misunderstanding; it is a **root-cause misusage that directly produces wrong results**:

1. **Wrong direction**: assuming bigger H = more leverage, one maxes out inner-H (knowing) and outer-H (acting) without closing the knowing–acting gap.
2. **Wrong results**: the larger the volume, the larger the gap — force dissipates, adjudication noise rises; worse, the S reserve gets misled by the false "big H" and misjudges the system as safe.
3. **Attribution flip (the most dangerous step)**: facing wrong results, outsiders do not first suspect "I used H wrong"; they intuitively blame "this Weiwen's Law framework itself is flawed / doesn't work".

**The framework is not the problem — the usage is turned backwards.** The white-box H is designed to make the gap *visible, measurable, and closeable* — it gives you an *alignment tool*, not a *magnitude dial*. Whenever things get messier the more you use it, the first move is to check H's knowing–acting unity, not to doubt the framework.

> **One-line guardrail**: H's leverage lies in *unity*, not *volume*; if it gets messier the more you use it, you cranked H *bigger* instead of *unified* — that is not Weiwen's Law's fault.

---

### 7. H's sole realization in the engine — the BUG-circuit human-handoff fallback (⚠️ PROVISIONAL)

> **⚠️ PROVISIONAL note**: The "H = human adjudication" described here is a **provisional convention of the current version**. The author (Shaky77) explicitly stated "H is, for now, set to human adjudication" and it may be upgraded in future iterations. This note only describes the engine's *current* realization of H; it is **not a terminal definition**. If any evolution rewrites how H is realized, this section must be updated in step.

The previous sections' "H three-uniqueness" and "bigger is better is exactly backwards" are conceptual. A natural question: **what does H actually look like in code?** The answer — it currently has **no magnitude dial**; its sole realization is the circuit "BUG threshold reached → return adjudication to the human".

**Circuit body (implemented in `src/core/engine.mjs`, mark-based escalation)**
- `mHumanCap` defaults to 9 (the author's cap value).
- The same BUG refused-and-repeated → `mBugForce` accumulates; or the same system re-appearing in disguise → `mSystemMarks` accumulates.
- **When either accumulator hits the cap `mHumanCap` → `human = true`**.
- On hit, `_toHuman` runs → returns `kind:'review', humanDecision:true`, with reason "the AI stops deliberating and hands the adjudication right back to the human".

**This is exactly the code-level bridge for "H is, for now, set to human adjudication"**
- H's "variability" in the engine is **not a numerical magnitude** but the **sovereign question of "who adjudicates"**: the AI runs the full R→S→D→H→M derivation within its own authority; when it hits the cap (`mHumanCap`) and cannot close the loop itself, it hands the adjudication right back to the human.
- That handed-back "human adjudication" *is* H's present form — **H = the sovereign domain guarded by inner-H inviolability, realized in the engine as the single outlet "adjudication right resides with the human"**.
- It also closes the gap found when auditing the code earlier ("H is not yet a quantified variable in the engine"): H's current realization is the sovereign act of "who decides", not a quantified volume.

**Isomorphic with the three-uniqueness and with "bigger is better is backwards"**
- Unique sovereignty: the adjudication right is handed to the human only at the cap; normally the engine does not decide for H (guards the boundary).
- Unique variable: what varies is not H's "size" but "whether it is H's turn to adjudicate" (AI before the cap / H after the cap).
- Unique leverage point: severing infinite recursion / dissipation at the cap and handing it to the sovereign party is exactly the maximal leverage (sever to preserve continuity).
- And because H has **no "magnitude" field to crank** in code, the "bigger is better" misread is blocked at the root.

**Future iteration direction (provisional, pending upgrade)**
- Currently H's realization = human-adjudication fallback only; if H is later allowed to truly participate in adjudication (e.g. letting "knowing–acting unity" weight the decision), the interface **must be modeled on "unity", not "volume"** — otherwise it would itself create the "bigger is better" inducement opening.
- When that happens, this section's provisional "H = human adjudication" wording will be rewritten with the evolution.

---

> **(AI collaborator note)** This section bridges "H is, for now, set to human adjudication" to its code realization (BUG-circuit human-handoff fallback), and follows the previous section's correction of the "bigger is better" misread; it does not enter the `law.mjs` definition layer; marked "⚠️ PROVISIONAL", may be upgraded in future iterations and is not terminal. Isomorphic with "Integrity & Steady State": Integrity ≈ knowing and acting are one true thing (not split); Steady State ≈ after closing the gap, the agent's causal force persists stably.
