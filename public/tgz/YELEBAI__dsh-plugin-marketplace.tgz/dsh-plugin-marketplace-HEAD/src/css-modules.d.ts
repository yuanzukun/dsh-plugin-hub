declare module '*.module.css' {
  const classes: { readonly [key: string]: string }
  export default classes
}
declare module 'katex/dist/katex.min.css'
