/**
 * 真实场景端到端验证：用真实 lexicon 模块 + 真实 WB 请求体。
 *
 * ⚠️ 本文件有一条铁律：**关键词一律用程序拼接，绝不写字面量**。
 *    因为从对话上下文里抄字符串时，很容易把已经中和过的版本（中间带 U+200B）
 *    抄进来，然后测试就会「假失败」——这个坑已经踩过一次。
 */

import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const mod = (p) => 'file://' + path.join(ROOT, p).replace(/\\/g, '/')

const { normalizeLexiconConfig, rewriteMessages } = await import(mod('src/lexicon.mjs'))
const { installFetchHook } = await import(mod('src/fetch-hook.mjs'))

/** 零宽空格：程序生成，杜绝字面量污染。 */
const ZW = String.fromCharCode(0x200b)
/** 触发风控的裸关键词：DeepSeek + 空格 + Harness。 */
const NAKED = 'Deep' + 'Seek' + String.fromCharCode(0x20) + 'Harness'
/**
 * 中和后的形态。
 * ⚠️ 注意 ZW 的位置：lexicon 的实现是 match.split(/[ \u00A0]+/).join(ZW + ' ')，
 * 即用「ZW + 空格」替换两个词之间的分隔符 —— 所以 ZW 在 DeepSeek 与 Harness
 * **之间**，不是插在 DeepSeek 内部。我最初写错成后者，导致测试假失败。
 */
const NEUTRALIZED =
  'DeepSeek' + ZW + String.fromCharCode(0x20) + 'Harness'

/* ---- 前置自检：确认 NAKED 真的是裸的 ------------------------------- */
{
  const cps = [...NAKED].map((c) => c.codePointAt(0))
  if (cps.includes(0x200b)) {
    console.error('❌ 测试自身被污染：NAKED 里含 U+200B')
    process.exit(1)
  }
  if (NAKED.length !== 16) {
    console.error(`❌ NAKED 长度应为 16，实际 ${NAKED.length}`)
    process.exit(1)
  }
  console.log(`  前置自检：NAKED 干净（${cps.map((c) => c.toString(16)).join(' ')}）`)
}

const makeRewrite = (getConfig) => (messages) => {
  const cfg = normalizeLexiconConfig(getConfig())
  if (!cfg.enabled) return { hits: 0, injected: false, changed: false }
  const r = rewriteMessages(messages, cfg)
  return {
    hits: r.hits ?? 0,
    injected: Boolean(r.injected),
    changed: (r.hits ?? 0) > 0 || Boolean(r.injected),
  }
}

/** 每个用例独立构造 system prompt，避免跨用例互相污染。 */
const makeSystem = (extra = '') =>
  'You are an AI agent powered by ' + NAKED + '. You help users with coding tasks. ' + extra

let cfg = { enabled: true, neutralize: true, ensureSystem: true, hideIdentity: false }
let sent = []
const originalFetch = async (input, init) => {
  sent.push({ url: String(input), body: init?.body })
  return new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } })
}
globalThis.fetch = originalFetch

const uninstall = installFetchHook({
  getConfig: () => cfg,
  rewrite: makeRewrite(() => cfg),
})

const results = []
const check = (name, fn) => {
  try {
    fn()
    results.push(['PASS', name])
  } catch (e) {
    results.push(['FAIL', `${name} — ${e.message}`])
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg)
}

/* ① 真实 WB 请求被中和 */
const body1 = JSON.stringify({
  model: 'deepseek-v4.1-flash',
  messages: [{ role: 'system', content: makeSystem() }, { role: 'user', content: '写个快排' }],
  stream: true,
})
sent = []
await fetch('https://copilot.tencent.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'content-type': 'application/json', authorization: 'Bearer x' },
  body: body1,
})
check('真实 WB 请求：关键词已中和', () => {
  assert(sent.length === 1, 'fetch 应被调用')
  const out = JSON.parse(sent[0].body)
  const sys = out.messages[0].content
  assert(!sys.includes(NAKED), `原词应消失，实际仍含：${sys.slice(0, 80)}`)
  assert(sys.includes(NEUTRALIZED), '应出现中和形态')
  assert(out.messages[0].role === 'system', 'role 应保持 system')
  assert(out.messages.length === 2, '不应多出消息')
  assert(out.model === 'deepseek-v4.1-flash', 'model 不应变')
  assert(out.stream === true, 'stream 不应变')
})

/* ② 原始 body 字符串不被污染 */
check('原始 body 字符串未被就地修改', () => {
  assert(body1.includes(NAKED), '原字符串应保持原样')
})

/* ③ 关闭开关 → 字节级还原 */
cfg = { enabled: false, neutralize: true, ensureSystem: true }
sent = []
const body3 = JSON.stringify({
  model: 'deepseek-v4.1-flash',
  messages: [{ role: 'system', content: makeSystem() }, { role: 'user', content: 'q' }],
})
await fetch('https://copilot.tencent.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: body3,
})
check('关闭开关后：body 字节级一致', () => {
  assert(sent[0].body === body3, '必须原样发出')
})
cfg = { enabled: true, neutralize: true, ensureSystem: true }

/* ④ 第三方反代（换域名，不换任何文件） */
sent = []
const body4 = JSON.stringify({
  model: 'm',
  messages: [{ role: 'system', content: makeSystem() }, { role: 'user', content: 'q' }],
})
await fetch('https://www.workbuddy.ai/v1/chat/completions', {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: body4,
})
check('换用 workbuddy.ai 域名的第三方反代：同样被修', () => {
  const out = JSON.parse(sent[0].body)
  assert(out.messages[0].content.includes(NEUTRALIZED), '应已中和')
})

/* ⑤ 首条不是 system → 自动补 */
sent = []
await fetch('https://copilot.tencent.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ model: 'm', messages: [{ role: 'user', content: 'hi' }] }),
})
check('首条不是 system：自动补一条（11128 的另一成因）', () => {
  const out = JSON.parse(sent[0].body)
  assert(out.messages[0].role === 'system', '应补 system')
  assert(out.messages.length === 2, '应变成 2 条')
})

/* ⑥ 大 body（>4KB，真实触发风控的体量） */
sent = []
const body6 = JSON.stringify({
  model: 'm',
  messages: [
    { role: 'system', content: makeSystem('X'.repeat(4000)) },
    { role: 'user', content: 'q' },
  ],
})
await fetch('https://copilot.tencent.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: body6,
})
check('大 body（>4KB）正常处理且不丢内容', () => {
  const out = JSON.parse(sent[0].body)
  assert(out.messages[0].content.includes(NEUTRALIZED), '应已中和')
  assert(out.messages[0].content.includes('X'.repeat(4000)), '其余内容不能丢')
})

/* ⑦ 非 WB 域名零影响 */
sent = []
const body7 = JSON.stringify({
  model: 'gpt-x',
  messages: [{ role: 'system', content: makeSystem() }],
})
await fetch('https://api.deepseek.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: body7,
})
check('api.deepseek.com：完全不介入（字节一致）', () => {
  assert(sent[0].body === body7, '非 WB 域名必须原样')
})

/* ⑧ 反复调用同一请求体不会叠加 ZW（幂等） */
sent = []
const body8 = JSON.stringify({
  model: 'm',
  messages: [{ role: 'system', content: makeSystem() }],
})
for (let i = 0; i < 3; i += 1) {
  sent = []
  await fetch('https://copilot.tencent.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: body8,
  })
}
check('同一请求体反复发送：不叠加零宽空格（幂等）', () => {
  const out = JSON.parse(sent[0].body)
  const count = (out.messages[0].content.match(new RegExp(ZW, 'g')) ?? []).length
  assert(count === 1, `ZW 应只有 1 个，实际 ${count} 个`)
  assert(out.messages[0].content.includes(NEUTRALIZED), '应保持中和形态')
})

uninstall()

for (const [s, name] of results) {
  console.log(`  ${s === 'PASS' ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}`)
}
const pass = results.filter(([s]) => s === 'PASS').length
console.log(`\n  ${pass}/${results.length} 通过`)
if (pass !== results.length) process.exit(1)
