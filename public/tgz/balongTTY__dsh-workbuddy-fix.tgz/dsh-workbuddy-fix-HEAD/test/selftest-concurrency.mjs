/* 高并发不被误判为环路 —— 2026-10-22 抓到的真缺陷的回归测试。
 *
 * ## 缺陷
 * 环保护最初用「整个调用期间」的深度计数。但 wrapper 是 async，
 * `await handleRequest()` 期间深度一直 >0，于是**同时有 N 个请求在飞时
 * 深度峰值 ≈ N**。N 一旦超过阈值（20），后来的请求就被判成「环路」，
 * 丢给原生 fetch 跳过改写。
 *
 * 症状：**高并发下改写静默失效** —— 不崩、不报错、日志也没有，
 * 只是部分请求的关键词没被中和，然后被上游 400 拦截。
 * 这比崩溃更难查，因为「偶发」且「看起来插件在工作」。
 *
 * 实测数据（修复前 / 200 并发）：
 *   rewrite 调用 = 20 / 200，上游收到未改写 = 180
 *
 * ## 修法
 * 只统计**同步**进入次数：wrapper 本身不做 await（同步返回 Promise），
 * 在 finally 里立刻递减。真正环路是纯同步调用，计数会瞬间冲顶。
 *
 * ## 本测试断言
 *   ① N 并发全部走完 rewrite（一个都不能漏）
 *   ② 上游收到的 body 全部已改写
 *   ③ 并发结束后不能残留计数（否则下一次会被误判）
 */

import { installFetchHook } from '../src/fetch-hook.mjs'

let pass = 0
let fail = 0
const ok = (name, cond, detail) => {
  if (cond) { pass += 1; console.log('  ✓', name) }
  else { fail += 1; console.log('  ✗', name, detail ? '— ' + detail : '') }
}

const noop = { debug: () => {}, info: () => {}, warn: () => {} }
const ZW = String.fromCharCode(0x200b)
const NAKED = 'Deep' + 'Seek' + ' ' + 'Harness'
const MASKED = 'Deep' + 'Seek' + ZW + ' ' + 'Harness'

const native = globalThis.fetch
const CONCURRENCY = 200

let upstreamBodies = []
globalThis.fetch = async (i, n) => {
  upstreamBodies.push(n?.body ?? null)
  // 故意慢一点，确保请求真的同时「在飞」
  await new Promise((r) => setTimeout(r, 15))
  return new Response('{}')
}

let rewriteCalls = 0
const u = installFetchHook({
  getConfig: () => ({ enabled: true }),
  rewrite: (messages) => {
    rewriteCalls += 1
    let hits = 0
    for (const m of messages) {
      if (typeof m.content === 'string' && m.content.includes(NAKED)) {
        m.content = m.content.split(NAKED).join(MASKED)
        hits += 1
      }
    }
    return { hits, injected: false, changed: hits > 0 }
  },
  onStats: () => {},
  extraHosts: ['127.0.0.1'],
  logger: noop,
})

console.log(`\n[s] 并发压测：${CONCURRENCY} 个请求同时发出`)

const reqs = []
for (let i = 0; i < CONCURRENCY; i += 1) {
  reqs.push(
    globalThis.fetch('http://127.0.0.1:9/v1/chat/completions', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ messages: [{ role: 'system', content: `#${i} ${NAKED}` }] }),
    }).then(() => 'ok').catch((e) => 'err:' + e.message),
  )
}
const results = await Promise.all(reqs)
const errs = results.filter((r) => r !== 'ok')
const rewritten = upstreamBodies.filter((b) => typeof b === 'string' && b.includes(ZW)).length
const missed = upstreamBodies.length - rewritten

ok(`${CONCURRENCY} 个并发请求全部成功`, errs.length === 0, errs.slice(0, 3).join('; '))
ok('每个请求都走了 rewrite', rewriteCalls === CONCURRENCY,
  `rewriteCalls=${rewriteCalls}，应为 ${CONCURRENCY}（少了说明被误判为环路）`)
ok('上游收到的 body 全部已改写', missed === 0,
  `有 ${missed} 个漏改写（这就是「高并发下改写静默失效」）`)

/* ── 并发结束后不能残留计数 ──────────────────────────────────────── */
{
  upstreamBodies = []
  rewriteCalls = 0
  await globalThis.fetch('http://127.0.0.1:9/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'system', content: NAKED }] }),
  }).catch(() => {})
  ok('并发结束后单发一个请求仍能正常改写', rewriteCalls === 1,
    `rewriteCalls=${rewriteCalls}（残留深度会让它被跳过）`)
}

/* ── 反转检查：真环路必须仍被拦住（不能为了并发而放过环路） ──────── */
{
  u()
  await new Promise((r) => setTimeout(r, 0))
  globalThis.fetch = async () => new Response('{}')

  const u2 = installFetchHook({
    getConfig: () => ({ enabled: true }),
    rewrite: () => ({ hits: 0, injected: false, changed: false }),
    onStats: () => {},
    extraHosts: [],
    logger: noop,
  })
  const w = globalThis.fetch

  // 纯同步环路：wrapper → 对方 → wrapper → …（没有 await 让出点）
  let hops = 0
  const cyclic = (i, n) => {
    hops += 1
    if (hops > 10_000) return new Response('{}') // 兜底防测试自身挂死
    return w('SENTINEL', n)
  }
  globalThis.fetch = cyclic

  let threw = null
  try {
    // 直接调 cyclic，它会进 w；w 的 tail 是 cyclic → 应当被 depth 拦住
    await cyclic('x').catch(() => {})
  } catch (e) {
    threw = e
  }
  ok('真同步环路仍被拦住（没有栈溢出）', threw === null || !/Maximum call stack/.test(threw.message),
    threw && threw.message)
  ok('环路被拦时跳数没有爆炸', hops < 10_000, `hops=${hops}`)

  u2()
}

globalThis.fetch = native
console.log(`\n  ${pass} 通过 / ${fail} 失败`)
process.exit(fail === 0 ? 0 : 1)
