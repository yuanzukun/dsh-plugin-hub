/**
 * 验证白名单新增 workbuddy.cn —— 用真实 fetch 拦截验证，不依赖内部导出。
 */
import http from 'node:http'
import { installFetchHook } from '../src/fetch-hook.mjs'

const ZW = String.fromCharCode(0x200b)
const NAKED  = 'Deep' + 'Seek' + String.fromCharCode(0x20) + 'Harness'
const NEUTRAL = 'DeepSeek' + ZW + String.fromCharCode(0x20) + 'Harness'

const received = []
const server = http.createServer((req, res) => {
  const c = []
  req.on('data', x => c.push(x))
  req.on('end', () => {
    received.push({ host: req.headers.host, path: req.url, body: Buffer.concat(c).toString('utf8') })
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end('{"ok":true}')
  })
})
await new Promise(r => server.listen(0, '127.0.0.1', r))
const port = server.address().port

const uninstall = installFetchHook({
  // 只放行本地测试服务器，同时把它当作 WB 域
  getConfig: () => ({ enabled: true, neutralize: true, ensureSystem: true }),
  rewrite: (messages) => {
    let hits = 0
    for (const m of messages) {
      if (typeof m.content === 'string' && m.content.includes(NAKED)) {
        m.content = m.content.split(NAKED).join(NEUTRAL)
        hits++
      }
    }
    return { hits, injected: false, changed: hits > 0 }
  },
  extraHosts: ['127.0.0.1'],
  logger: {},
})

const mkBody = () => JSON.stringify({
  model: 'deepseek-v4.1-flash',
  messages: [{ role: 'system', content: 'powered by ' + NAKED + '.' }],
})

const cases = [
  ['/v2/chat/completions', true,  'buddy 渠道路径'],
  ['/v1/chat/completions', true,  'WB 标准路径'],
  ['/v1/models',           false, '非 chat 路径'],
]

let pass = 0
for (const [path, shouldRewrite, label] of cases) {
  received.length = 0
  await fetch(`http://127.0.0.1:${port}${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: mkBody(),
  })
  const got = received.length > 0 && received[0].body.includes(NEUTRAL)
  const ok = got === shouldRewrite
  if (ok) pass++
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${label.padEnd(20)} 被改写=${got}（期望 ${shouldRewrite}）`)
}

// 收尾顺序很重要：先卸载钩子，再等 server 真正关闭，最后才退出。
// 若在 server.close() 的回调前就 process.exit()，libuv 会在
// uv_async 关闭途中断言（Windows 上表现为 exit code 1，测试"假失败"）。
uninstall()
await new Promise((resolve) => server.close(resolve))

console.log(`\n  ${pass}/${cases.length} 通过`)
process.exitCode = pass === cases.length ? 0 : 1
