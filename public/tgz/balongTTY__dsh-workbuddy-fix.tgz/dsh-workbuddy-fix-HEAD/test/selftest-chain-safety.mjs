/* 深度链路安全测试 —— 验证「退役 wrapper + 新 tail」不会成环。
 *
 * 这是 2026-10-22 崩溃的**完整现场**，比 selftest-cycle-guard 更进一步：
 * 那里只验证「不崩」，这里验证「链条形状正确」——
 * 每一次请求都必须有明确的终点，且终点是真正发网络的原生 fetch。
 *
 * 事故链条（真实复现）：
 *   ① 别的插件包在我们外面：const p = fetch; fetch = (i,n) => p(i,n)
 *   ② 热重载：uninstall 发现 globalThis.fetch !== shared.wrapped（最外层是对方）
 *      → 不还原，对方继续包着旧 wrapper
 *   ③ 重装：original = globalThis.fetch = 对方 → 新一代 tail = 对方
 *   ④ 旧 wrapper 若读 shared.pristine（= 对方）→ 旧→对方→旧… ∞ 栈溢出
 */
import { installFetchHook } from '../src/fetch-hook.mjs'

let pass = 0
let fail = 0
const ok = (name, cond, detail) => {
  if (cond) { pass += 1; console.log('  ✓', name) }
  else { fail += 1; console.log('  ✗', name, detail ? '— ' + detail : '') }
}

const noop = { debug: () => {}, info: () => {}, warn: () => {} }
const mk = () => ({
  getConfig: () => ({ enabled: true }),
  rewrite: () => ({ hits: 0, injected: false, changed: false }),
  onStats: () => {},
  extraHosts: [],
  logger: noop,
})

const nativeFetch = globalThis.fetch

/* ── 场景 A：对方包着我们 + 反复热重载 20 轮，统计原生 fetch 被调用次数 ──
 * 若成环，原生 fetch 永远不会被调用（还在递归里就栈溢出了）。
 * 若链条正确，每次请求都恰好调用原生 fetch 一次。
 */
let nativeCalls = 0
globalThis.fetch = async function countingNative(input, init) {
  nativeCalls += 1
  if (input === 'SENTINEL_OTHER') return new Response('other')
  return new Response('{"ok":true,"from":"native"}')
}

let u = installFetchHook(mk())
const gen1 = globalThis.fetch

// 对方插件：捕获当
// 前 fetch（我们的 gen1）再转发，之后永不更新
const otherPlugin = async (i, n) => gen1(i, n)
globalThis.fetch = otherPlugin

let threw = null
try {
  for (let round = 0; round < 20; round += 1) {
    u()
    await new Promise((r) => setTimeout(r, 0))
    u = installFetchHook(mk())
    await new Promise((r) => setTimeout(r, 0))
    // 每轮发一次请求
    await globalThis.fetch('data:application/json,{}')
  }
} catch (e) {
  threw = e
}

ok('20 轮热重载全程不抛错（无栈溢出）', threw === null, threw && threw.message)
ok('原生 fetch 确实被调用过（说明链条有终点）', nativeCalls > 0, `nativeCalls=${nativeCalls}`)
ok('原生 fetch 调用次数合理（每轮至多几次，不是成千上万）',
  nativeCalls <= 100, `nativeCalls=${nativeCalls} —— 过大多半是重试/环路`)

/* ── 场景 B：并发请求不能被误判为环路 ────────────────────────────
 * 布尔 entering 会把「第一个请求还没结束、第二个进来」当成环路，
 * 把第二个请求直接丢给 pristine（跳过改写）。用 depth 计数后不会。
 */
{
  u()
  await new Promise((r) => setTimeout(r, 0))
  globalThis.fetch = async () => new Response('{}')

  let rewriteCalls = 0
  const u2 = installFetchHook({
    ...mk(),
    // ⚠️ 必须把 127.0.0.1 加进白名单，否则 isWorkBuddyUrl 直接判「非目标域」，
    //    rewrite 根本不会被调用 —— 那是测试写错，不是产品缺陷。
    extraHosts: ['127.0.0.1'],
    rewrite: () => {
      rewriteCalls += 1
      return { hits: 1, injected: false, changed: true }
    },
  })

  // 同时发 5 个请求（不 await，让它们在飞）
  const reqs = []
  for (let i = 0; i < 5; i += 1) {
    reqs.push(globalThis.fetch('http://127.0.0.1:9/v1/chat/completions', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ messages: [{ role: 'system', content: 'x' }] }),
    }).catch(() => null))
  }
  await Promise.all(reqs)

  ok('5 个并发请求全部走完改写（无被误判为环路而跳过）',
    rewriteCalls === 5, `rewriteCalls=${rewriteCalls}（应为 5）`)
  u2()
  await new Promise((r) => setTimeout(r, 0))
}

/* ── 场景 C：卸载后 globalThis.fetch 必须干净还原 ─────────────── */
{
  const beforeUninstall = globalThis.fetch
  u()
  await new Promise((r) => setTimeout(r, 0))
  // 我们没有在最外层（被 otherPlugin 或者场景 B 的 stub 包着），所以不该被改
  ok('卸载不破坏别人的 wrapper（只在最外层时才还原）',
    globalThis.fetch === beforeUninstall,
    '卸载后 fetch 被意外改动')
}

globalThis.fetch = nativeFetch

console.log(`\n  ${pass} 通过 / ${fail} 失败`)
process.exit(fail === 0 ? 0 : 1)
