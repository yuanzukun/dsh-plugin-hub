/**
 * 环保护回归测试 —— 2026-10-21 宿主崩溃事故的防线。
 *
 * ## 事故经过
 * v1.2.1 加了个 `reassertFetchHook()`：发现我们的 wrapper 不在
 * `globalThis.fetch` 上，就把当前 fetch 记成 `__wbFixPrev`、
 * 再把我们的 wrapper 抢回最外层。它被 `status` 路由调用，
 * 也就是**每打开一次设置面板就执行一次**。
 *
 * 若对方插件的写法是「先抓住当前的 fetch，之后转发给它」：
 * ```js
 * const prev = globalThis.fetch      // ← 抓住的是我们的 wrapper
 * globalThis.fetch = (i, n) => prev(i, n)
 * ```
 * 自愈后链条变成：
 * ```txt
 * 我们的 wrapper → __wbFixPrev(对方) → prev(还是我们的 wrapper) → …
 * ```
 * **无限递归 → RangeError: Maximum call stack size exceeded → 宿主崩溃。**
 *
 * ## 现在的保证
 * 1. 没有自愈了 —— status 路由只读，不改 `globalThis.fetch`。
 * 2. wrapper 有环保护：重入时直接走原始 fetch，宁可漏改一次也不崩。
 * 3. 钩子被别的插件包到内层时，功能仍然正常（链式转发照常经过我们）。
 */

import {
  installFetchHook,
  isFetchHookInstalled,
  getFetchHookStatus,
} from '../src/fetch-hook.mjs'

let pass = 0
const results = []
const check = async (name, fn) => {
  try { await fn(); results.push(['PASS', name]); pass += 1 }
  catch (e) { results.push(['FAIL', `${name} — ${e.message}`]) }
}
const assert = (c, m) => { if (!c) throw new Error(m) }

const noop = { debug: () => {}, info: () => {}, warn: () => {} }
const mk = (rewrite) => ({
  getConfig: () => ({ enabled: true, neutralize: true, ensureSystem: true }),
  rewrite: rewrite ?? (() => ({ hits: 0, injected: false, changed: false })),
  onStats: () => {},
  extraHosts: ['127.0.0.1'],
  logger: noop,
})

const SP = String.fromCharCode(0x20)
const ZW = String.fromCharCode(0x200b)
const NAKED = 'Deep' + 'Seek' + SP + 'Harness'
const MASKED = 'Deep' + 'Seek' + ZW + SP + 'Harness'

// 前置自检：确认测试样本本身没被污染
assert(!NAKED.includes(ZW), `NAKED 不应含零宽空格，实际码点：${[...NAKED].map(c => c.charCodeAt(0)).join(',')}`)
assert(MASKED.includes(ZW), 'MASKED 应含零宽空格')

const base = globalThis.fetch

/* ── 1. 正常安装 ───────────────────────────────────────────────── */
let uninstall = installFetchHook(mk())

await check('安装后 installed=true / reason=active', () => {
  const s = getFetchHookStatus()
  assert(s.installed === true, '应 installed=true')
  assert(s.reason === 'active', `reason 应为 active，实际 ${s.reason}`)
})

/* ── 2. ★核心回归：对方抓住我们再转发，绝不能栈溢出 ───────────── */
await check('对方捕获我们的 wrapper 再转发 → 不递归、不崩溃', async () => {
  const ourWrapper = globalThis.fetch

  // 模拟真实世界里最常见的那种「先存旧的再转发」写法。
  // 这正是当初压垮宿主的形态。
  let depth = 0
  globalThis.fetch = async (input, init) => {
    depth += 1
    if (depth > 50) throw new Error('检测到无限递归（depth>50）—— 环保护失效')
    return ourWrapper(input, init)
  }

  // 用 data: URL，不产生真实网络请求
  const res = await globalThis.fetch('data:application/json,{}')
  assert(res !== undefined, '应返回结果而不是崩溃')
  // 恢复
  globalThis.fetch = ourWrapper
})

/* ── 3. 被包到内层时，改写功能仍然正常 ────────────────────────── */
await check('被别的插件包到内层 → 改写依然生效（链式转发）', async () => {
  uninstall()
  await new Promise((r) => setTimeout(r, 0))

  // 「上游」= 真正发请求的那一层，我们改写后的 body 只有它能看见
  // （我们重建了一个新的 init，外层看到的是原始 body，这是设计如此）。
  let upstreamBody = null
  globalThis.fetch = async (input, init) => {
    upstreamBody = init?.body ?? null
    return new Response('{"ok":true}')
  }

  uninstall = installFetchHook(mk((messages) => {
    let hits = 0
    for (const m of messages) {
      if (typeof m.content === 'string' && m.content.includes(NAKED)) {
        m.content = m.content.split(NAKED).join(MASKED)
        hits += 1
      }
    }
    return { hits, injected: false, changed: hits > 0 }
  }))

  const ourWrapper = globalThis.fetch
  // 别的插件把我们包到内层（它在外面）
  globalThis.fetch = async (input, init) => ourWrapper(input, init)

  await globalThis.fetch('http://127.0.0.1:9/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'system', content: `by ${NAKED}` }] }),
  })

  assert(upstreamBody !== null, '上游应被调用到')
  assert(upstreamBody.includes(ZW), `上游收到的 body 应已改写，实际: ${upstreamBody}`)
  assert(!upstreamBody.includes(NAKED), '改写后不应再有裸关键词')
})

/* ── 4. 状态查询是只读的（不许再出现自愈那种副作用）──────────── */
await check('getFetchHookStatus 只读，不修改 globalThis.fetch', () => {
  const before = globalThis.fetch
  getFetchHookStatus()
  getFetchHookStatus()
  getFetchHookStatus()
  assert(globalThis.fetch === before, '状态查询不得替换 globalThis.fetch')
})

/* ── 5. 不在最外层时如实报告，不谎称 active ──────────────────── */
await check('不在最外层时 installed=false 且 reason=chained', () => {
  const ourWrapper = globalThis.fetch
  globalThis.fetch = async (i, n) => ourWrapper(i, n)
  const s = getFetchHookStatus()
  assert(s.installed === false, 'installed 应为 false')
  assert(s.reason === 'chained', `reason 应为 chained，实际 ${s.reason}`)
  globalThis.fetch = ourWrapper
})

/* ── 6. 卸载后彻底干净 ───────────────────────────────────────── */
await check('卸载后 uninstalled，且 globalThis.fetch 复原', async () => {
  uninstall()
  await new Promise((r) => setTimeout(r, 0))
  const s = getFetchHookStatus()
  assert(s.installed === false, '卸载后不应 installed')
  assert(s.reason === 'never-installed', `reason 应为 never-installed，实际 ${s.reason}`)
  assert(isFetchHookInstalled() === false, 'isFetchHookInstalled 应为 false')
})

/* ── 7. depth 必须在异常后复位 ─────────────────────────────────── */
await check('rewrite 抛异常后 depth 复位（不会卡死后续请求）', async () => {
  uninstall()
  await new Promise((r) => setTimeout(r, 0))

  globalThis.fetch = async () => new Response('{}')

  // 第一轮：rewrite 抛错 —— wrapper 必须吞掉异常并原样放行
  const u1 = installFetchHook(mk(() => { throw new Error('boom') }))
  await globalThis.fetch('data:application/json,{}').catch(() => {})
  u1()
  await new Promise((r) => setTimeout(r, 0))

  // 第二轮：如果 depth 没复位，这次改写会被静默跳过（hits 保持 0）
  let hits = 0
  globalThis.fetch = async () => new Response('{}')
  const u2 = installFetchHook(mk(() => {
    hits += 1
    return { hits: 1, injected: false, changed: true }
  }))

  await globalThis.fetch('http://127.0.0.1:9/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'system', content: NAKED }] }),
  }).catch(() => {})

  assert(hits === 1, `depth 卡住会让改写被静默跳过（hits 应为 1，实际 ${hits}）`)
  u2()
  await new Promise((r) => setTimeout(r, 0))
})

/* ── 8. ★★ 2026-10-22 崩溃的真实场景：反复热重载 ─────────────────
 *
 * 事故：`installFetchHook` 的**复用分支**里还藏着一段「抢回最外层」：
 *   shared.wrapped.__wbFixPrev = globalThis.fetch
 *   globalThis.fetch = shared.wrapped
 * v1.2.2 只删了 `reassertFetchHook()`，没发现同一段逻辑在这个分支里。
 * 热重载每 apply 一次就走一次，`__wbFixPrev` 被反复改写成别的插件，
 * 最终形成「我们 → 对方 → 我们」的环 → 每次 fetch 都栈溢出 → 宿主崩溃。
 *
 * 这个用例完整复现那个现场：先装好，再让别的插件包在外面（捕获我们转发的
 * 写法），然后**反复热重载 10 次**，每次之后都必须能安全发起请求。
 */
await check('★反复热重载 10 次 + 对方包在外层 → 永不栈溢出（崩溃现场复现）', async () => {
  uninstall()
  await new Promise((r) => setTimeout(r, 0))

  // 干净的上游
  let upstreamCalls = 0
  const realFetch = async () => { upstreamCalls += 1; return new Response('{"ok":true}') }
  globalThis.fetch = realFetch

  // 首次安装
  let u = installFetchHook(mk())
  const ours1 = globalThis.fetch
  assert(ours1.__wbFixWrapped === true, '首次安装后最外层应是我们')

  // 对方插件用「捕获当前 fetch 再转发」的写法包住我们 —— 正是压垮宿主的形态。
  // 关键：对方**只捕获一次**，之后不再更新（这是真实插件最常见写法）。
  const dshOtherPlugin = async (i, n) => {
    if (i === 'SENTINEL_OTHER') return new Response('other-ran')
    return ours1(i, n)
  }
  globalThis.fetch = dshOtherPlugin

  // 反复热重载：每次 dispose + apply，共 10 轮
  for (let round = 0; round < 10; round += 1) {
    u()                                    // dispose（引用计数 -1）
    await new Promise((r) => setTimeout(r, 0))
    u = installFetchHook(mk())             // 重新 apply（走复用分支）
    await new Promise((r) => setTimeout(r, 0))

    // 每轮都必须能安全发起请求。若复用分支抢回最外层且改写 __wbFixPrev，
    // 这一行会 RangeError: Maximum call stack size exceeded。
    try {
      const res = await globalThis.fetch('data:application/json,{}')
      assert(res !== undefined, `第 ${round + 1} 轮请求应返回结果`)
    } catch (e) {
      throw new Error(`第 ${round + 1} 轮热重载后栈溢出/抛错：${e.message}`)
    }
  }

  // 我们的 wrapper 仍在链上被调用（对方包在外层，转发进来）
  assert(upstreamCalls > 0, '上游应被调用到（链式转发正常工作）')
  // 关键断言：我们的 ___wbFixPrev 从未被改成「对方」
  assert(
    shared_WrapperPrevNotOurs(ours1),
    '__wbFixPrev 不得被改写成外部函数（那是环路载体）',
  )
  u()
  await new Promise((r) => setTimeout(r, 0))
})

/* 辅助：确认没有任何 wrapper 把「外部函数」记在自己的 __wbFixPrev 上。
 * 现在我们完全不写这个属性，所以只要有人写了就是 bug 回归。 */
function shared_WrapperPrevNotOurs(w) {
  return w.__wbFixPrev === undefined
}

/* ── 收尾 ─────────────────────────────────────────────────────── */
try { uninstall() } catch { /* 已卸载 */ }
globalThis.fetch = base

for (const [s, n] of results) {
  console.log(`  ${s === 'PASS' ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${n}`)
}
console.log(`\n  ${pass}/${results.length} 通过`)
process.exitCode = pass === results.length ? 0 : 1
