/**
 * fetch-hook 的端到端自检。
 *
 * 用一个假的 fetch 记录「实际发出去的 body」，验证：
 *   ① WB 请求被拦截并改写
 *   ② 其它域名请求原样透传（零影响）
 *   ③ 关闭开关后完全恢复原样（字节级）
 *   ④ 非 JSON body 不崩
 *   ⑤ 可卸载
 */

import assert from 'node:assert/strict'
import { installFetchHook, isFetchHookInstalled } from '../src/fetch-hook.mjs'

const FALLBACK_SYSTEM = 'You are a helpful assistant.'

/** 极简 rewrite：只做「DeepSeek Harness → DeepSeek\u200B Harness」+ 补 system。 */
function makeRewrite(getConfig) {
  return (messages) => {
    const cfg = getConfig()
    if (!cfg.enabled) return { hits: 0, injected: false, changed: false }
    let hits = 0
    for (const m of messages) {
      if (typeof m?.content === 'string' && m.content.includes('DeepSeek Harness')) {
        m.content = m.content.replaceAll('DeepSeek Harness', 'DeepSeek\u200B Harness')
        hits += 1
      }
    }
    let injected = false
    if (cfg.ensureSystem && messages[0]?.role !== 'system') {
      messages.unshift({ role: 'system', content: FALLBACK_SYSTEM })
      injected = true
    }
    return { hits, injected, changed: hits > 0 || injected }
  }
}

let cfg = { enabled: true, ensureSystem: true }

/** 记录原始 fetch 被调用的参数。 */
let calls = []
const originalFetch = async (input, init) => {
  calls.push({ url: String(input), body: init?.body ?? null })
  return new Response(JSON.stringify({ ok: true }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })
}
globalThis.fetch = originalFetch
globalThis.Headers = globalThis.Headers ?? Headers

const uninstall = installFetchHook({
  getConfig: () => cfg,
  rewrite: makeRewrite(() => cfg),
  onStats: () => {},
})

const results = []
const t = async (name, fn) => {
  try {
    await fn()
    results.push(['PASS', name])
  } catch (e) {
    results.push(['FAIL', `${name} — ${e.message}`])
  }
}

/* ① WB 请求被拦截改写 */
await t('WB 请求被拦截并改写', async () => {
  calls = []
  const body = JSON.stringify({
    model: 'deepseek-v4.1-flash',
    messages: [{ role: 'user', content: 'You are an AI agent powered by DeepSeek Harness.' }],
  })
  await fetch('https://copilot.tencent.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body,
  })
  assert.equal(calls.length, 1, 'fetch 应被调用一次')
  const sent = JSON.parse(calls[0].body)
  assert.equal(sent.messages[0].role, 'system', '应补上 system')
  assert.ok(
    sent.messages[1].content.includes('DeepSeek\u200B Harness'),
    '应插入零宽空格',
  )
  assert.ok(!sent.messages[1].content.includes('DeepSeek Harness'), '原词应已消失')
})

/* ② 非 WB 域名原样透传 */
await t('非 WB 域名原样透传（零影响）', async () => {
  calls = []
  const body = JSON.stringify({ messages: [{ role: 'user', content: 'DeepSeek Harness' }] })
  await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body,
  })
  assert.equal(calls.length, 1)
  assert.equal(calls[0].body, body, 'body 必须字节一致')
})

/* ③ 关闭开关后完全恢复 */
await t('关闭开关后 body 字节一致', async () => {
  cfg = { enabled: false, ensureSystem: true }
  calls = []
  const body = JSON.stringify({
    messages: [{ role: 'user', content: 'You are an AI agent powered by DeepSeek Harness.' }],
  })
  await fetch('https://copilot.tencent.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body,
  })
  assert.equal(calls[0].body, body, '关掉后必须原样发出')
  cfg = { enabled: true, ensureSystem: true }
})

/* ④ 非 JSON body 不崩 */
await t('非 JSON body 原样放行', async () => {
  calls = []
  await fetch('https://copilot.tencent.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'text/plain' },
    body: 'not json at all',
  })
  assert.equal(calls[0].body, 'not json at all')
})

/* ⑤ GET 请求不介入 */
await t('GET 请求不介入', async () => {
  calls = []
  await fetch('https://copilot.tencent.com/v1/chat/completions')
  assert.equal(calls.length, 1)
})

/* ⑥ rewrite 抛错时原样放行 */
await t('rewrite 抛错时原样放行（不拖垮插件）', async () => {
  const u2 = installFetchHook({
    getConfig: () => ({ enabled: true }),
    rewrite: () => {
      throw new Error('boom')
    },
  })
  // 上面因已包装会被跳过，直接验证原钩子对异常 body 的韧性
  calls = []
  await fetch('https://copilot.tencent.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: '{"messages":"not-an-array"}',
  })
  assert.equal(calls[0].body, '{"messages":"not-an-array"}', 'messages 非数组应原样放行')
  u2()
})

/* ⑦ 卸载后恢复原函数 */
await t('卸载后恢复原始 fetch', async () => {
  uninstall()
  assert.equal(isFetchHookInstalled(), false, '卸载后不应再标记为已包装')
  assert.equal(globalThis.fetch, originalFetch, '应恢复原函数引用')
})

/* 输出 */
const pass = results.filter(([s]) => s === 'PASS').length
for (const [s, name] of results) {
  console.log(`  ${s === 'PASS' ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}`)
}
console.log(`\n  ${pass}/${results.length} 通过`)
if (pass !== results.length) process.exit(1)
