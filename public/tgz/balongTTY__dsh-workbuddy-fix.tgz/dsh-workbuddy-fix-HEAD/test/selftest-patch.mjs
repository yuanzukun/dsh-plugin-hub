import { findLexiconInsertPoint, LEXICON_ANCHOR } from '../src/patch.mjs'

const ANCHOR = LEXICON_ANCHOR
let pass = 0, total = 0

function test(name, source, expectContains) {
  total++
  const r = findLexiconInsertPoint(source)
  const ok = r.ok && source.slice(0, r.index).includes(expectContains)
  if (ok) pass++
  console.log(`  ${ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}`)
  if (!ok) console.log(`      ok=${r.ok} reason=${r.reason} index=${r.index}`)
}

// ① 基础：块内无字面量花括号
test('基础场景', `function f() {\n  ${ANCHOR}\n    a();\n  }\n  next();\n}`, 'a();')

// ② 块内有字符串 "}"
test('块内字符串含 }', `function f() {\n  ${ANCHOR}\n    x({ content: "}" });\n  }\n  next();\n}`, 'x({')

// ③ 块内有模板串
test('块内模板串含 }', 'function f() {\n  ' + ANCHOR + '\n    y(`a } b`);\n  }\n  next();\n}', 'y(`a')

// ④ 块内有行注释含 }
test('块内行注释含 }', `function f() {\n  ${ANCHOR}\n    // 这里有个 } 注释\n    z();\n  }\n  next();\n}`, 'z();')

// ⑤ 块内有块注释
test('块内块注释含 }', `function f() {\n  ${ANCHOR}\n    /* } */ w();\n  }\n  next();\n}`, 'w();')

console.log(`\n  ${pass}/${total} 通过`)
process.exitCode = pass === total ? 0 : 1
