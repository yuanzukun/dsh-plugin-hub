/**
 * v1.2.0 三组功能的验证 —— 重点是**可复原性**。
 *
 * 用户明确要求：「提示词必须能做到复原」。
 * 所以每个用例除了验证「开了生效」，还必须验证「关了完全复原」——
 * 逐字符比对，不是「看起来差不多」。
 */

import {
  LEXICON_DEFAULTS,
  PERSONA_MARKER,
  PERSONA_TEMPLATE,
  normalizeLexiconConfig,
  neutralizeText,
  rewriteMessages,
} from '../src/lexicon.mjs'

const ZW = String.fromCharCode(0x200b)
const SP = String.fromCharCode(0x20)
const NAKED = 'Deep' + 'Seek' + SP + 'Harness'
const ZW_MARK = 'Deep' + 'Seek' + ZW + SP + 'Harness'

let pass = 0
const results = []
const check = (name, fn) => {
  try { fn(); results.push(['PASS', name]); pass += 1 }
  catch (e) { results.push(['FAIL', `${name} — ${e.message}`]) }
}
const assert = (c, m) => { if (!c) throw new Error(m) }

const cfg = (over = {}) => normalizeLexiconConfig({ ...LEXICON_DEFAULTS, ...over })

/** 造一份「像 DSH 真实请求」的 messages */
const mkMessages = () => ([
  { role: 'system', content: `You are an AI agent powered by ${NAKED}.\nWorking dir: D:\\10_COD\\${NAKED}\\resources` },
  { role: 'user', content: 'hello' },
])

/* ══ 前置自检 ══════════════════════════════════════════════════════ */
results.push(['PASS', `前置自检：NAKED 干净（${Buffer.from(NAKED).toString('hex')}）`])
pass += 1
if (NAKED.includes(ZW)) {
  console.error('  ✗ NAKED 含 U+200B，测试不可信')
  process.exit(1)
}

/* ══ 一、可复原性 ★最重要 ═══════════════════════════════════════ */

check('总开关关闭：字节级完全复原（三种新功能全开也是一字不改）', () => {
  const before = JSON.stringify(mkMessages())
  const m = mkMessages()
  rewriteMessages(m, cfg({
    enabled: false,
    neutralize: true, hideIdentity: true,
    brandReplace: true, replacement: 'CodeBuddy',
    persona: true,
  }))
  assert(JSON.stringify(m) === before, '关闭总开关后必须一个字节都不变')
})

check('浅复原：只开 neutralize，关掉后没有零宽空格残留', () => {
  const m = mkMessages()
  rewriteMessages(m, cfg({ neutralize: true }))
  assert(m[0].content.includes(ZW_MARK), '开启时应插入零宽空格')

  const m2 = mkMessages()
  rewriteMessages(m2, cfg({ neutralize: false }))
  assert(!m2[0].content.includes(ZW), '关闭后不应有任何零宽空格')
  assert(m2[0].content.includes(NAKED), '关闭后原文应完整')
})

check('复原不依赖「上一次的状态」—— 每次请求都是重新读原文再改', () => {
  // 真实场景：每次请求都是全新的 messages 对象（从 DSH 那边重新构造），
  // 所以「上次改成什么」不会影响这次。这里验证两次独立请求结果一致。
  const a = mkMessages()
  rewriteMessages(a, cfg({ brandReplace: true, replacement: 'CodeBuddy' }))
  const b = mkMessages()
  rewriteMessages(b, cfg({ brandReplace: true, replacement: 'CodeBuddy' }))
  assert(a[0].content === b[0].content, '两次独立请求应得到相同结果')

  // 关掉后再来一次，应与从未开过时完全一致。
  // ⚠️ 必须把 neutralize 也关掉 —— 它默认是 true，会插零宽空格，
  //    那样内容就不是「原文」了（这不是 bug，是默认行为）。
  const c = mkMessages()
  rewriteMessages(c, cfg({ brandReplace: false, neutralize: false }))
  const pristine = mkMessages()
  assert(c[0].content === pristine[0].content, '全关后应与原文完全一致')
})

/* ══ 二、无损中和（A 路径）═════════════════════════════════════ */

check('无损中和：只改正文，路径不受影响', () => {
  const r = neutralizeText(`a ${NAKED} b, path D:\\x\\${NAKED}\\y`, cfg())
  assert(r.text.includes(ZW_MARK), '正文应插入零宽空格')
  assert(r.text.includes(`D:\\x\\${NAKED}\\y`), '路径必须原样保留')
  assert(r.hits === 1, `hits 应为 1，实际 ${r.hits}`)
})

check('无损中和：语义不变（去掉零宽空格后与原文一致）', () => {
  const src = `powered by ${NAKED}.`
  const r = neutralizeText(src, cfg())
  const restored = r.text.split(ZW).join('')
  assert(restored === src, `去掉零宽后应等于原文，实际 ${restored}`)
})

/* ══ 三、品牌替换（B 路径）═════════════════════════════════════ */

check('品牌替换：整段换成指定词', () => {
  const r = neutralizeText(`powered by ${NAKED}.`, cfg({ brandReplace: true, replacement: 'CodeBuddy' }))
  assert(r.text === 'powered by CodeBuddy.', `实际: ${r.text}`)
  assert(!r.text.includes(ZW), '替换模式不应插零宽空格')
})

check('品牌替换：路径仍然受保护', () => {
  const p = `D:\\10_COD\\${NAKED}\\resources`
  const r = neutralizeText(`cwd = ${p}`, cfg({ brandReplace: true }))
  assert(r.text.includes(p), `路径被改坏了: ${r.text}`)
})

check('品牌替换：replacement 为空时回落到默认值，不会把词删掉', () => {
  const c = cfg({ brandReplace: true, replacement: '   ' })
  assert(c.replacement === LEXICON_DEFAULTS.replacement,
    `空 replacement 应回落默认，实际 "${c.replacement}"`)
})

check('品牌替换与无损中和互斥：开启后者不生效', () => {
  const c = cfg({ brandReplace: true, neutralize: true, replacement: 'CodeBuddy' })
  const r = neutralizeText(`x ${NAKED} y`, c)
  assert(r.text.includes('CodeBuddy'), '应走替换路径')
  assert(!r.text.includes(ZW), '替换模式下不应有零宽空格')
})

/* ══ 四、人格注入 ══════════════════════════════════════════════ */

check('人格注入：追加到 system 末尾，且带识别标记', () => {
  const m = mkMessages()
  const r = rewriteMessages(m, cfg({ persona: true }))
  assert(r.personaApplied === true, 'personaApplied 应为 true')
  assert(m[0].content.includes(PERSONA_MARKER), '应含识别标记')
  assert(m[0].content.includes(PERSONA_TEMPLATE.slice(0, 40)), '应含模板内容')
  assert(m[0].content.startsWith('You are an AI agent powered by'), '原有内容必须保留在最前面')
})

check('人格注入：幂等 —— 同一条消息不会被注入两次', () => {
  const m = mkMessages()
  rewriteMessages(m, cfg({ persona: true }))
  const once = m[0].content
  rewriteMessages(m, cfg({ persona: true }))
  assert(m[0].content === once, '第二次注入不应叠加')
  const cnt = (m[0].content.match(new RegExp(PERSONA_MARKER.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) ?? []).length
  assert(cnt === 1, `标记应只有 1 个，实际 ${cnt}`)
})

check('人格注入：关掉后完全复原（整份 messages 逐字节比对）', () => {
  const pristine = JSON.stringify(mkMessages())

  const on = mkMessages()
  rewriteMessages(on, cfg({ persona: true }))
  assert(JSON.stringify(on) !== pristine, '开启后应有变化')

  // 关掉开关后的请求 = 全新的 messages 经过 rewrite。
  // ⚠️ neutralize 默认 true，要一并关掉才是「完全复原」。
  const off = mkMessages()
  rewriteMessages(off, cfg({ persona: false, neutralize: false }))
  assert(JSON.stringify(off) === pristine, '全关后整份 messages 应与原文逐字节相同')
  assert(!off[0].content.includes(PERSONA_MARKER), '不应残留标记')
})

check('人格注入：自定义文本优先于模板', () => {
  const m = mkMessages()
  rewriteMessages(m, cfg({ persona: true, personaText: 'CUSTOM-PERSONA-TEXT' }))
  assert(m[0].content.includes('CUSTOM-PERSONA-TEXT'), '应用自定义文本')
  assert(!m[0].content.includes('# Doing tasks'), '不应再含模板内容')
})

check('人格注入：超长文本被截断到上限', () => {
  const c = cfg({ persona: true, personaText: 'x'.repeat(20000) })
  assert(c.personaText.length === 8000, `应截到 8000，实际 ${c.personaText.length}`)
})

check('人格注入：没有 system 消息时新建一条', () => {
  const m = [{ role: 'user', content: 'hi' }]
  const r = rewriteMessages(m, cfg({ persona: true }))
  assert(r.personaApplied === true, '应注入')
  assert(m[0].role === 'system', '首条应变成 system')
  assert(m[0].content.includes(PERSONA_MARKER), '应含标记')
})

/* ══ 五、三路叠加 ══════════════════════════════════════════════ */

check('三路全开：换词 + 人格同时生效', () => {
  const m = mkMessages()
  const r = rewriteMessages(m, cfg({
    neutralize: true, hideIdentity: true,
    brandReplace: true, replacement: 'CodeBuddy',
    persona: true,
  }))
  assert(r.hits > 0, '应有替换命中')
  assert(r.personaApplied === true, '应注入人格')
  // ⚠️ 路径里的同名词组受保护、必须原样保留，所以只能断言「路径之外无残留」。
  //    把路径替换成占位符再检查。
  const withoutPath = m[0].content.replace(/D:\\10_COD\\[^\n]*/g, '')
  assert(!withoutPath.includes(NAKED), `路径之外的正文不应残留关键词，实际: ${withoutPath.slice(0, 120)}`)
  assert(m[0].content.includes('D:\\10_COD\\' + NAKED + '\\resources'), '路径必须原样保留')
  assert(m[0].content.includes('CodeBuddy'), '应已换成 CodeBuddy')
  assert(m[0].content.includes(PERSONA_MARKER), '应含人格标记')
})

check('三路全关：与 LEXICON_DEFAULTS 之外的新增项全部不生效', () => {
  const c = cfg({ brandReplace: false, persona: false, hideIdentity: false })
  assert(c.brandReplace === false, 'brandReplace 应关')
  assert(c.persona === false, 'persona 应关')
  assert(c.hideIdentity === false, 'hideIdentity 应关')
})

/* ══ 输出 ══════════════════════════════════════════════════════ */
for (const [status, name] of results) {
  console.log(`  ${status === 'PASS' ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}`)
}
console.log(`\n  ${pass}/${results.length} 通过`)
process.exitCode = pass === results.length ? 0 : 1
