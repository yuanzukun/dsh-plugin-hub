/* i18n 键集审计 —— 抓住「界面显示原始 key」这类静默缺陷。
 *
 * 背景（真实缺陷）：
 *   本插件 `inject: ['slots']` 且**从不调 ctx.locale.register()**，所以
 *   `locale/*.json` 是死键，全靠 client.js 内嵌的 ZH / EN 字典。
 *   一旦某个 `t('xxx')` 引用的 key 两边都没抄，界面就直接显示 `status.fetchOk`
 *   这样的原始 key —— 不报错、测试全绿、只有肉眼能看见。
 *
 * 本测试做三件事，全部双向对账：
 *   ① 代码里出现的每个 t('...') key 都必须同时存在于 ZH 与 EN
 *   ② ZH 与 EN 的键集必须完全一致（漏抄一边会导致语言切换时露 key）
 *   ③ {n} / {m} 这类占位符必须两边一致（漏了会显示 "undefined" 或空白）
 */

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const CLIENT = path.join(here, '..', 'client.js')
const src = fs.readFileSync(CLIENT, 'utf8')

let pass = 0
let fail = 0
function ok(name, cond, detail) {
  if (cond) { pass++; console.log('  ✅', name) }
  else { fail++; console.log('  ❌', name, detail ? '— ' + detail : '') }
}

/* ── 提取字典：定位 `const ZH = {` … 到匹配的 `}` ─────────────────── */
function extractDict(name) {
  const start = src.indexOf('const ' + name + ' = {')
  if (start < 0) return null
  let i = src.indexOf('{', start)
  let depth = 0
  let end = -1
  for (; i < src.length; i++) {
    const ch = src[i]
    if (ch === '{') depth++
    else if (ch === '}') { depth--; if (depth === 0) { end = i; break } }
  }
  if (end < 0) return null
  const body = src.slice(start + ('const ' + name + ' = ').length, end + 1)
  // 用 Function 真求值（字典里只有纯字符串字面量，安全且比正则可靠）
  // eslint-disable-next-line no-new-func
  return new Function('return (' + body + ')')()
}

const ZH = extractDict('ZH')
const EN = extractDict('EN')

console.log('\n[i] i18n 键集审计')

ok('ZH 字典可解析', ZH && typeof ZH === 'object', '解析失败')
ok('EN 字典可解析', EN && typeof EN === 'object', '解析失败')
if (!ZH || !EN) { console.log(`\n  i18n 审计：${pass} 通过 / ${fail} 失败`); process.exit(1) }

const zhKeys = new Set(Object.keys(ZH))
const enKeys = new Set(Object.keys(EN))

/* ── ① 代码里引用的 key 必须两边都有 ───────────────────────────────
 * 只扫 t('...') 与 t("...")；字典定义区本身要先剔除，否则 key 字面量
 * 会被当成「引用」。
 */
const codeOnly = src.slice(src.indexOf('const STYLES'))
const used = new Set()
{
  const re = /\bt\(\s*['"]([A-Za-z0-9_.\-]+)['"]/g
  let m
  while ((m = re.exec(codeOnly))) used.add(m[1])
}
ok('代码里有 t() 引用', used.size > 30, '只找到 ' + used.size + ' 个')

const missingZH = [...used].filter((k) => !zhKeys.has(k))
const missingEN = [...used].filter((k) => !enKeys.has(k))
ok('所有引用 key 在 ZH 中都存在', missingZH.length === 0,
  missingZH.length ? '缺失: ' + missingZH.join(', ') : '')
ok('所有引用 key 在 EN 中都存在', missingEN.length === 0,
  missingEN.length ? '缺失: ' + missingEN.join(', ') : '')

/* ── ② ZH / EN 键集必须完全一致 ──────────────────────────────────── */
const onlyZH = [...zhKeys].filter((k) => !enKeys.has(k))
const onlyEN = [...enKeys].filter((k) => !zhKeys.has(k))
ok('ZH 与 EN 键数一致', zhKeys.size === enKeys.size, `ZH=${zhKeys.size} EN=${enKeys.size}`)
ok('无「只有 ZH 有」的键', onlyZH.length === 0, onlyZH.join(', '))
ok('无「只有 EN 有」的键', onlyEN.length === 0, onlyEN.join(', '))

/* ── ③ 占位符必须一致 ─────────────────────────────────────────────
 * t('stats.label', { n, m }) 依赖 {n}/{m}；某一边漏写会导致该语言下
 * 数字直接不显示（不是报错，是静默丢内容）。
 */
const phOf = (s) => {
  const set = new Set()
  const re = /\{([A-Za-z][A-Za-z0-9_]*)\}/g
  let m
  while ((m = re.exec(String(s)))) set.add(m[1])
  return set
}
const phMismatch = []
for (const key of zhKeys) {
  if (!enKeys.has(key)) continue
  const zh = phOf(ZH[key])
  const en = phOf(EN[key])
  const diff = [...zh].filter((x) => !en.has(x)).concat([...en].filter((x) => !zh.has(x)))
  if (diff.length) phMismatch.push(key + '(' + diff.join('/') + ')')
}
ok('占位符两边一致', phMismatch.length === 0, phMismatch.join(', '))

/* ── ④ 字典里不该有「未被引用」的孤儿键（提示未清理的残留） ────────
 * 这条不判失败，只报告 —— 孤儿键不影响功能，但会掩盖真正的漏抄。
 */
const orphan = [...zhKeys].filter((k) => !used.has(k))

console.log(`\n  统计：t() 引用 ${used.size} 个，ZH ${zhKeys.size} 键，EN ${enKeys.size} 键`)
if (orphan.length) console.log('  ℹ 未被引用的键（' + orphan.length + '）：' + orphan.join(', '))
console.log(`\n  i18n 审计：${pass} 通过 / ${fail} 失败`)
process.exit(fail === 0 ? 0 : 1)
