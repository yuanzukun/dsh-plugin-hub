/* ★HMR 模块重估回归测试 —— 2026-10-22 抓到的灾难性回归。
 *
 * ## 缺陷
 * HMR 会**重新评估模块**：新的 `shared` 是空对象，但 `globalThis.fetch`
 * 仍指向**上一个模块代**的 wrapper。此时：
 *
 *   original = globalThis.fetch = 旧 wrapper（带 __wbFixWrapped 标记）
 *   旧的 pickSafeTail: "带标记 → 返回 null"
 *   → 本代 tail = null → handleRequest 里 upstream 为 null
 *   → **所有 WB 请求返回 502，插件完全不可用**
 *
 * 用户侧表现：「请求被拦截 Illegal API invocation from an unapproved
 * channel」—— 看起来像插件没生效，实际是请求根本没发出去。
 *
 * ## 修法
 * `pickSafeTail` 遇到带标记的 wrapper 时，**穿透**到它捕获的
 * `__wbFixTail`（immutable 闭包值），一路走到真正的终点。
 *
 * ## 本测试的做法
 * 用 `?gen=N` 查询串强制 Node **重新求值模块**，得到全新的 `shared`，
 * 这才是真实 HMR 的时序（只清变量是不够的）。
 */

import { pathToFileURL, fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const HOOK = pathToFileURL(path.join(here, '..', 'src', 'fetch-hook.mjs')).href

let pass = 0
let fail = 0
const ok = (name, cond, detail) => {
  if (cond) { pass += 1; console.log('  ✓', name) }
  else { fail += 1; console.log('  ✗', name, detail ? '— ' + detail : '') }
}

const noop = { debug: () => {}, info: () => {}, warn: () => {} }
const ZW = String.fromCharCode(0x200b)
const NAKED = 'Deep' + 'Seek' + ' ' + 'Harness'
const MASKED = 'Deep' + 'Seek' + ZW + ' ' + 'Harness'

const mk = () => ({
  getConfig: () => ({ enabled: true }),
  rewrite: (messages) => {
    let hits = 0
    for (const m of messages) {
      if (typeof m.content === 'string' && m.content.includes(NAKED)) {
        m.content = m.content.split(NAKED).join(MASKED)
        hits += 1
      }
    }
    return { hits, injected: false, changed: hits > 0 }
  },
  onStats: () => {},
  extraHosts: ['127.0.0.1'],
  logger: noop,
})

const native = globalThis.fetch

async function wbRequest() {
  return globalThis.fetch('http://127.0.0.1:9/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'system', content: `sys ${NAKED}` }] }),
  })
}

console.log('\n[s] HMR 模块重估回归测试')

/* ── 用例 1：单次重估后请求必须仍能发出，且返回 200（不是 502） ──── */
{
  let upstreamHits = 0
  let upstreamBody = null
  globalThis.fetch = async (i, n) => {
    upstreamHits += 1
    upstreamBody = n?.body ?? null
    return new Response('{"ok":true}')
  }

  const m1 = await import(HOOK + '?gen=1')
  const u1 = m1.installFetchHook(mk())
  ok('第 1 代安装后我们是最外层', globalThis.fetch.__wbFixWrapped === true)

  // 不调 u1 —— 直接重估模块，模拟 HMR 在不先卸载的情况下换模块代
  const m2 = await import(HOOK + '?gen=2')
  const u2 = m2.installFetchHook(mk())

  let res = null
  let threw = null
  try { res = await wbRequest() } catch (e) { threw = e }

  ok('第 2 代请求不抛错', threw === null, threw && threw.message)
  ok('第 2 代返回 200（不是 502）', res && res.status === 200,
    res ? `实际 HTTP ${res.status} —— tail 为 null 时会 502` : '无响应')
  ok('第 2 代上游真的被调用', upstreamHits >= 1, `upstreamHits=${upstreamHits}`)
  ok('第 2 代改写仍然生效', typeof upstreamBody === 'string' && upstreamBody.includes(ZW),
    upstreamBody ? '上游 body 未改写' : '上游没收到 body')

  try { u2?.() } catch { /* */ }
  try { u1?.() } catch { /* */ }
  await new Promise((r) => setTimeout(r, 0))
}

/* ── 用例 2：连续 5 代重估（每代都不先卸载）都要能发请求 ────────── */
{
  globalThis.fetch = async () => new Response('{"ok":true}')
  let u

  for (let gen = 1; gen <= 5; gen += 1) {
    const m = await import(HOOK + `?genChain=${gen}`)
    u = m.installFetchHook(mk())
    let res = null
    let err = null
    try { res = await wbRequest() } catch (e) { err = e }
    ok(`第 ${gen} 代重估后能正常请求`, !err && res && res.status === 200,
      err ? err.message : res ? `HTTP ${res.status}` : '无响应')
  }
  try { u?.() } catch { /* */ }
  await new Promise((r) => setTimeout(r, 0))
}

/* ── 用例 3：穿透不能吞掉「别人的包装」（tail 应指到最外层真实上游） ─
 * 场景：别人包着我们 → 我们被替换 → 重估 → 新一代 tail 应穿透到「别人」
 * 而不是退货给原生 fetch（否则别人的功能被我们关掉了）。
 */
{
  let otherCalls = 0
  globalThis.fetch = async () => { otherCalls += 1; return new Response('{"a":1}') }

  const m1 = await import(HOOK + '?genOther=1')
  const u1 = m1.installFetchHook(mk())
  const ourWrapper = globalThis.fetch

  // 别人包在我们外面
  const otherWrapper = async (i, n) => ourWrapper(i, n)
  otherWrapper.__isOther = true
  globalThis.fetch = otherWrapper

  // 重估模块（新一代 original = otherWrapper）
  const m2 = await import(HOOK + '?genOther=2')
  const u2 = m2.installFetchHook(mk())

  otherCalls = 0
  try { await wbRequest() } catch { /* */ }
  ok('穿透后仍经过别人的包装（没把别人功能关掉）', otherCalls >= 1,
    `otherCalls=${otherCalls} —— 0 说明我们绕过了对方`)

  try { u2?.() } catch { /* */ }
  try { u1?.() } catch { /* */ }
  await new Promise((r) => setTimeout(r, 0))
}

/* ── 用例 4：多代穿透后卸载，globalThis.fetch 必须回到可用的上游 ──── */
{
  globalThis.fetch = async () => new Response('{"ok":true}')
  const m1 = await import(HOOK + '?genUn=1')
  const u1 = m1.installFetchHook(mk())
  const m2 = await import(HOOK + '?genUn=2')
  const u2 = m2.installFetchHook(mk())

  try { u2() } catch { /* */ }
  try { u1() } catch { /* */ }
  await new Promise((r) => setTimeout(r, 0))

  let res = null
  let err = null
  try {
    res = await globalThis.fetch('data:application/json,{}')
  } catch (e) { err = e }
  ok('卸载后 globalThis.fetch 仍可调用', !err && res !== undefined,
    err ? err.message : '无响应')
}

globalThis.fetch = native
console.log(`\n  ${pass} 通过 / ${fail} 失败`)
process.exit(fail === 0 ? 0 : 1)
