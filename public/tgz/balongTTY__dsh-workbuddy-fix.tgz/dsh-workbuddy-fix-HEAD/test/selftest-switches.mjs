/**
 * 非默认开关的**端到端生效**验证。
 *
 * 为什么单独一个文件：之前的测试集全绿，但全部是「默认开关组合下的正常路径」。
 * 审计发现 `hideIdentity` 这个开关**从来没有真正生效过** ——
 * `neutralizeText` 改了文本却不递增 hits，而调用方用 `hits > 0` 决定写回，
 * 于是改动被静默丢弃。表现是「时灵时不灵」：文本恰好也含关键词组合时才顺带生效。
 *
 * 这类 bug 的共性是「改写发生了但结果被丢弃」，只有断言**最终可观察结果**
 * （而不是中间函数的返回值）才能抓到。
 */

import {
  neutralizeText,
  neutralizeMessage,
  rewriteMessages,
} from '../src/lexicon.mjs'

const ZW = String.fromCharCode(0x200b)
const SP = String.fromCharCode(0x20)
const NAKED = 'Deep' + 'Seek' + SP + 'Harness'
const BRAND = 'Deep' + 'Seek'
const BRAND_HIDDEN = 'Deep' + ZW + 'Seek'

let pass = 0
const results = []
const check = (name, fn) => {
  try {
    fn()
    results.push(['PASS', name])
    pass += 1
  } catch (e) {
    results.push(['FAIL', `${name} — ${e.message}`])
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg)
}

const cfg = (over = {}) => ({
  enabled: true,
  neutralize: true,
  hideIdentity: false,
  ensureSystem: false,
  keywords: [NAKED],
  ...over,
})

/* ── 前置自检：关键词必须是干净的裸文本，不含零宽空格 ───────────────── */
results.push(['PASS', `前置自检：NAKED 干净（${Buffer.from(NAKED).toString('hex')}）`])
pass += 1
if (NAKED.includes(ZW)) {
  console.error('  ✗ NAKED 被污染了，含 U+200B，测试结果不可信')
  process.exit(1)
}

/* ── ① hideIdentity 单独生效（这是被漏掉的那个 bug）──────────────────── */
check('hideIdentity：纯品牌词（不含关键词组合）也会被改写', () => {
  const msg = { role: 'user', content: `Vendor: ${BRAND} makes it.` }
  const r = neutralizeMessage(msg, cfg({ hideIdentity: true }))
  assert(msg.content.includes(BRAND_HIDDEN), '文本应含 Deep<ZW>Seek，实际未改')
  assert(r.changed === true, 'changed 应为 true')
  assert(r.hits === 0, 'hits 应仍为 0（hideIdentity 不计入关键词命中）')
})

/* ── ② 同样的改动必须能走到 rewriteMessages 的返回值 ─────────────────── */
check('hideIdentity：rewriteMessages 报 changed=true', () => {
  const msgs = [{ role: 'system', content: 'sys' }, { role: 'user', content: `${BRAND} rocks` }]
  const r = rewriteMessages(msgs, cfg({ hideIdentity: true }))
  assert(r.changed === true, `changed 应为 true，实际 ${JSON.stringify(r)}`)
  assert(msgs[1].content.includes(BRAND_HIDDEN), '消息体应已被改写')
})

/* ── ③ 不变的内容不能误报 changed ─────────────────────────────────── */
check('没有任何可改内容时 changed 必须为 false', () => {
  const msgs = [{ role: 'system', content: 'plain text, nothing to do' }]
  const r = rewriteMessages(msgs, cfg())
  assert(r.changed === false, `不应报 changed，实际 ${JSON.stringify(r)}`)
  assert(r.hits === 0, 'hits 应为 0')
})

/* ── ④ 关闭开关后一个字都不能变 ───────────────────────────────────── */
check('enabled=false 时字节级不变', () => {
  const before = `Vendor: ${BRAND} and ${NAKED}`
  const msgs = [{ role: 'user', content: before }]
  const r = rewriteMessages(msgs, cfg({ enabled: false, hideIdentity: true }))
  assert(msgs[0].content === before, '关闭后不应改动任何字符')
  assert(r.changed === false, 'changed 应为 false')
  assert(r.skipped === true, '应报 skipped')
})

/* ── ⑤ 路径保护仍然有效（hideIdentity 不能改到路径里的词）──────────── */
check('路径里的 DeepSeek 不被 hideIdentity 改写', () => {
  const p = 'D:\\10_COD\\' + BRAND + ' Harness\\resources\\app.asar'
  const r = neutralizeText(`cwd = ${p}`, cfg({ hideIdentity: true }))
  assert(r.text.includes(p), `路径被改坏了：${r.text}`)
  assert(!r.text.includes('Deep' + ZW + 'Seek'), '路径里不应插入零宽空格')
})

/* ── ⑥ 多模态 parts 数组里的 hideIdentity ─────────────────────────── */
check('多模态 parts 里的品牌词也会被改写', () => {
  const msg = {
    role: 'user',
    content: [
      { type: 'text', text: `about ${BRAND}` },
      { type: 'image', source: { data: 'x' } },
    ],
  }
  const r = neutralizeMessage(msg, cfg({ hideIdentity: true }))
  assert(msg.content[0].text.includes(BRAND_HIDDEN), 'parts 里的文本应被改写')
  assert(r.changed === true, 'changed 应为 true')
})

/* ── ⑦ 关键词 + hideIdentity 同时开：两者都要生效 ──────────────────── */
check('关键词命中与 hideIdentity 同时生效', () => {
  const msg = { role: 'user', content: `by ${NAKED}, by ${BRAND} Inc.` }
  const r = neutralizeMessage(msg, cfg({ hideIdentity: true }))
  assert(msg.content.includes(BRAND_HIDDEN + ZW + SP + 'Harness'), '关键词应被中和')
  assert(msg.content.includes(`by ${BRAND_HIDDEN} Inc.`), '品牌词应被隐藏')
  assert(r.hits === 1, `hits 应为 1（只有关键词组合计一次），实际 ${r.hits}`)
})

/* ── ⑧ 幂等：反复处理不叠加零宽空格 ──────────────────────────────── */
check('反复处理不叠加零宽空格', () => {
  const msg = { role: 'user', content: `x ${NAKED} y` }
  const c = cfg()
  neutralizeMessage(msg, c)
  const once = msg.content
  neutralizeMessage(msg, c)
  neutralizeMessage(msg, c)
  assert(msg.content === once, '多次处理结果应稳定')
  const zwCount = (msg.content.match(new RegExp(ZW, 'g')) ?? []).length
  assert(zwCount === 1, `零宽空格应为 1 个，实际 ${zwCount}`)
})

/* ── 输出 ─────────────────────────────────────────────────────────── */
for (const [status, name] of results) {
  console.log(`  ${status === 'PASS' ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}`)
}
console.log(`\n  ${pass}/${results.length} 通过`)
process.exitCode = pass === results.length ? 0 : 1
