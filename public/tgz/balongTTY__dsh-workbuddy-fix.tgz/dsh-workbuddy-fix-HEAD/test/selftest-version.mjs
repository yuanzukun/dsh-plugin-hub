import { currentVersion, resolveRepoSlug, compareSemver, checkForUpdate } from "../src/version.mjs"

let pass = 0
const results = []
const check = async (name, fn) => {
  try { await fn(); results.push(["PASS", name]); pass += 1 }
  catch (e) { results.push(["FAIL", name + " — " + e.message]) }
}
const assert = (c, m) => { if (!c) throw new Error(m) }

await check("currentVersion 不是硬编码的 unknown", () => {
  const v = currentVersion()
  assert(/^\d+\.\d+\.\d+/.test(v), "版本号应形如 x.y.z，实际 " + v)
})
await check("resolveRepoSlug 从 repository 解析出 owner/repo", () => {
  assert(resolveRepoSlug() === "balongTTY/dsh-workbuddy-fix", "实际 " + resolveRepoSlug())
})
await check("compareSemver 数值比较（1.2.10 > 1.2.9）", () => {
  assert(compareSemver("1.2.10", "1.2.9") === 1, "字符串比较会错判")
  assert(compareSemver("v1.3.0", "1.2.9") === 1, "应处理 v 前缀")
  assert(compareSemver("1.2.2", "1.2.2") === 0, "相等应返回 0")
})
await check("checkForUpdate 失败时返回 ok:false 且不抛错", async () => {
  const r = await checkForUpdate({ timeoutMs: 1 })
  assert(typeof r.ok === "boolean", "必须有 ok 字段")
  assert(r.current === currentVersion(), "必须回显当前版本")
  assert(r.hasUpdate === false, "查不到时 hasUpdate 必须是 false 而不是 undefined")
})
await check("checkForUpdate 结果结构稳定（界面依赖这些字段）", async () => {
  const r = await checkForUpdate({ timeoutMs: 1 })
  for (const k of ["ok", "current", "hasUpdate"]) {
    assert(k in r, "缺字段 " + k)
  }
})

for (const [s, n] of results) console.log("  " + (s === "PASS" ? "\x1b[32m✓\x1b[0m" : "\x1b[31m✗\x1b[0m") + " " + n)
console.log("\n  " + pass + "/" + results.length + " 通过")
process.exitCode = pass === results.length ? 0 : 1
