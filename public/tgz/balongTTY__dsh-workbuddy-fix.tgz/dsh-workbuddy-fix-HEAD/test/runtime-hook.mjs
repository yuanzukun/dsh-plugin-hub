/**
 * 真实运行时验证（**不 mock fetch**）。
 *
 * 与 selftest-*.mjs 的区别：
 *   selftest 用假 fetch 验证「逻辑正确」；
 *   本文件用**真 undici fetch + 真 HTTP 服务器**验证「真的能拦住」。
 *   只有后者能排除这些风险：
 *     - 宿主/依赖提前缓存了 fetch 引用
 *     - 改写后 body 与 content-length 不一致导致服务端读不满
 *     - Request 形态读体把原 body 消费掉
 *
 * 用法：node test/runtime-hook.mjs
 */

import http from 'node:http'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const mod = (p) => 'file://' + path.join(ROOT, p).replace(/\\/g, '/')

const { normalizeLexiconConfig, rewriteMessages } = await import(mod('src/lexicon.mjs'))
const { installFetchHook } = await import(mod('src/fetch-hook.mjs'))

const ZW = String.fromCharCode(0x200b)
const NAKED = 'Deep' + 'Seek' + String.fromCharCode(0x20) + 'Harness'
const NEUTRALIZED = 'DeepSeek' + ZW + String.fromCharCode(0x20) + 'Harness'

/* 前置自检：确认 NAKED 真裸 */
{
  const cps = [...NAKED].map((c) => c.codePointAt(0))
  if (cps.includes(0x200b)) {
    console.error('❌ 测试自身被污染：NAKED 含 U+200B')
    process.exit(1)
  }
}

/* ---- 本地服务器：记录真实收到的 body ------------------------------ */
const received = []
const server = http.createServer((req, res) => {
  const chunks = []
  req.on('data', (c) => chunks.push(c))
  req.on('end', () => {
    received.push({
      method: req.method,
      path: req.url,
      headers: req.headers,
      body: Buffer.concat(chunks).toString('utf8'),
    })
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end('{"ok":true}')
  })
})
await new Promise((r) => server.listen(0, '127.0.0.1', r))
const port = server.address().port
const URL_BASE = `http://127.0.0.1:${port}`

/* ---- 装 hook，把 127.0.0.1 当作 WB 域名 --------------------------- */
let cfg = { enabled: true, neutralize: true, ensureSystem: true }

const uninstall = installFetchHook({
  getConfig: () => cfg,
  rewrite: (messages) => {
    const c = normalizeLexiconConfig(cfg)
    if (!c.enabled) return { hits: 0, injected: false, changed: false }
    const r = rewriteMessages(messages, c)
    return {
      hits: r.hits ?? 0,
      injected: Boolean(r.injected),
      changed: (r.hits ?? 0) > 0 || Boolean(r.injected),
    }
  },
  extraHosts: ['127.0.0.1'],
  logger: {},
})

const results = []
const check = (name, fn) => {
  try {
    fn()
    results.push(['PASS', name])
  } catch (e) {
    results.push(['FAIL', `${name} — ${e.message}`])
  }
}
const assert = (c, m) => {
  if (!c) throw new Error(m)
}
const mkBody = (extra = '') =>
  JSON.stringify({
    model: 'm',
    messages: [
      { role: 'system', content: 'You are an AI agent powered by ' + NAKED + '.' + extra },
      { role: 'user', content: 'hi' },
    ],
  })

/* ① 真实 fetch 被拦截，服务端收到改写后的 body */
received.length = 0
await fetch(`${URL_BASE}/v1/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: mkBody(),
})
check('真实 fetch：服务端收到的 body 已被改写', () => {
  assert(received.length === 1, `应收到 1 个请求，实际 ${received.length}`)
  const got = received[0].body
  assert(!got.includes(NAKED), '服务端仍收到裸关键词')
  assert(got.includes(NEUTRALIZED), '服务端未收到中和形态')
})

/* ② content-length 被正确更新（否则 body 会被截断） */
check('content-length 已随 body 更新（服务端能收全）', () => {
  const got = received[0].body
  const declared = Number(received[0].headers['content-length'])
  assert(declared === Buffer.byteLength(got), `声明 ${declared} 实际 ${Buffer.byteLength(got)}`)
  assert(() => JSON.parse(got), 'body 应是合法 JSON')
  JSON.parse(got) // 真解析，不合法会抛
})

/* ③ 关闭开关 → 服务端收到原样 */
cfg = { enabled: false, neutralize: true, ensureSystem: true }
received.length = 0
const rawBody = mkBody()
await fetch(`${URL_BASE}/v1/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: rawBody,
})
check('关闭开关后：服务端收到的 body 字节一致', () => {
  assert(received[0].body === rawBody, 'body 应原样')
})
cfg = { enabled: true, neutralize: true, ensureSystem: true }

/* ④ Request 对象形态（body 被 Request 持有，容易踩「已消费」错误） */
received.length = 0
const req = new Request(`${URL_BASE}/v1/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: mkBody(),
})
await fetch(req)
check('Request 对象形态：也能正确改写', () => {
  assert(received.length === 1, '请求应到达')
  const got = received[0].body
  assert(got.includes(NEUTRALIZED), '应被改写')
  assert(!got.includes(NAKED), '不应残留裸关键词')
})

/* ⑤ 大 body（>4KB）：content-length 变更后仍完整 */
received.length = 0
await fetch(`${URL_BASE}/v1/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: mkBody('X'.repeat(6000)),
})
check('大 body（>6KB）：完整到达且已改写', () => {
  const got = received[0].body
  assert(got.includes(NEUTRALIZED), '应被改写')
  assert(got.includes('X'.repeat(6000)), 'payload 不能丢')
  JSON.parse(got)
})

/* ⑥ 非 chat/completions 路径不介入 */
received.length = 0
const nonChat = JSON.stringify({ messages: [{ role: 'user', content: NAKED }] })
await fetch(`${URL_BASE}/v1/models`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: nonChat,
})
check('同域非 chat 路径：原样透传', () => {
  assert(received[0].body === nonChat, 'body 应原样')
})

/* ⑦ 未命中域名时零开销透传（用 extraHosts 之外的真实域名不方便，改用 GET） */
received.length = 0
await fetch(`${URL_BASE}/v1/chat/completions`)
check('GET 请求不介入', () => {
  assert(received.length === 1, 'GET 应正常到达')
  assert(received[0].body === '', 'GET 无 body')
})

/* ⑧ 卸载后服务端收到原样 */
uninstall()
received.length = 0
const afterBody = mkBody()
await fetch(`${URL_BASE}/v1/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: afterBody,
})
check('卸载后：恢复原样（服务端收到原始 body）', () => {
  assert(received[0].body === afterBody, '卸载后不应再改写')
})

server.close()

for (const [s, name] of results) {
  console.log(`  ${s === 'PASS' ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}`)
}
const pass = results.filter(([s]) => s === 'PASS').length
console.log(`\n  ${pass}/${results.length} 通过`)
if (pass !== results.length) process.exit(1)
