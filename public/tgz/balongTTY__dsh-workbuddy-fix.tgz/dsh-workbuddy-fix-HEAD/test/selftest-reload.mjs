/**
 * HMR / 插件重载场景下的钩子存活验证。
 *
 * 这是审计抓出的一个真缺陷：
 *   新实例发现 original.__wbFixWrapped === true → 返回**空卸载函数**
 *   旧实例卸载时 globalThis.fetch === 旧wrapped 成立 → 把 fetch 还原成原始
 *   → 新实例以为装好了，实际什么都没装
 *
 * 触发条件：apply 新实例 → 再 dispose 旧实例（Cordis 的 dispose/apply 顺序不保证）。
 * 热重载（removeBundle → installBundle）落到这个顺序时，关键词中和会静默失效，
 * 400 复现，而面板只显示一盏红灯、没有自愈。
 */

import http from 'node:http'
import { installFetchHook } from '../src/fetch-hook.mjs'

const ZW = String.fromCharCode(0x200b)
const SP = String.fromCharCode(0x20)
const NAKED = 'Deep' + 'Seek' + SP + 'Harness'
const NEUTRAL = 'Deep' + 'Seek' + ZW + SP + 'Harness'

let pass = 0
const results = []
const check = (name, fn) => {
  try {
    fn()
    results.push(['PASS', name])
    pass += 1
  } catch (e) {
    results.push(['FAIL', `${name} — ${e.message}`])
  }
}
const assert = (c, m) => {
  if (!c) throw new Error(m)
}

/* 本地服务器：记录服务端实际收到的 body */
const received = []
const server = http.createServer((req, res) => {
  const chunks = []
  req.on('data', (c) => chunks.push(c))
  req.on('end', () => {
    received.push(Buffer.concat(chunks).toString('utf8'))
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end('{"ok":true}')
  })
})
await new Promise((r) => server.listen(0, '127.0.0.1', r))
const port = server.address().port

const mkRewrite = (tag) => (messages) => {
  let hits = 0
  for (const m of messages) {
    if (typeof m.content === 'string' && m.content.includes(NAKED)) {
      m.content = m.content.split(NAKED).join(NEUTRAL)
      hits += 1
    }
  }
  return { hits, injected: false, changed: hits > 0, tag }
}

const install = (tag) =>
  installFetchHook({
    getConfig: () => ({ enabled: true, neutralize: true, ensureSystem: true }),
    rewrite: mkRewrite(tag),
    extraHosts: ['127.0.0.1'],
    logger: {},
  })

const send = async () => {
  received.length = 0
  await fetch(`http://127.0.0.1:${port}/v2/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      model: 'm',
      messages: [{ role: 'system', content: `powered by ${NAKED}.` }],
    }),
  })
  return received[0] ?? ''
}

/* ── 场景 1：正常顺序（dispose 旧 → apply 新）────────────────────── */
const uA = install('A')
const beforeA = await send()
uA()
const uB = install('B')
const afterB = await send()
uB()
results.push([
  (beforeA.includes(NEUTRAL) && afterB.includes(NEUTRAL)) ? 'PASS' : 'FAIL',
  '顺序 A（先卸载旧、再装新）：两次都改写',
])
if (beforeA.includes(NEUTRAL) && afterB.includes(NEUTRAL)) pass += 1

/* ── 场景 2：反序（apply 新 → dispose 旧）★这是 bug 的场景 ───────── */
const uOld = install('old')
const uNew = install('new') // 此时发现已包装，返回空卸载函数
uOld() // 旧实例卸载：globalThis.fetch === oldWrapped → 还原成原始 fetch
const afterReverse = await send()
const stillHooked = await (async () => {
  const { isFetchHookInstalled } = await import('../src/fetch-hook.mjs')
  return isFetchHookInstalled()
})()
uNew()

results.push([
  afterReverse.includes(NEUTRAL) ? 'PASS' : 'FAIL',
  `反序 A（apply 新 → dispose 旧）：钩子应存活 —— 实际${afterReverse.includes(NEUTRAL) ? '存活' : '**已消失**'}（isFetchHookInstalled=${stillHooked}）`,
])
if (afterReverse.includes(NEUTRAL)) pass += 1

/* ── 场景 3：卸载后再装，必须重新生效 ────────────────────────────── */
const u3 = install('C')
u3()
const u4 = install('D')
const after4 = await send()
u4()
results.push([
  after4.includes(NEUTRAL) ? 'PASS' : 'FAIL',
  '卸载后重新安装：钩子重新生效',
])
if (after4.includes(NEUTRAL)) pass += 1

/* ── 输出 ─────────────────────────────────────────────────────── */
await new Promise((r) => server.close(r))
for (const [status, name] of results) {
  console.log(`  ${status === 'PASS' ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m'} ${name}`)
}
console.log(`\n  ${pass}/${results.length} 通过`)
process.exitCode = pass === results.length ? 0 : 1
