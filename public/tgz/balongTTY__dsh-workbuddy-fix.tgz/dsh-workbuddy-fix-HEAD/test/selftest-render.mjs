/* 真实渲染自检 —— 补上「node --check 通过 ≠ 面板能渲染」这个缺口。
 *
 * 背景（血泪）：
 *   v1.3.0 初版给面板加了「检查更新」UI，插入时用了脚本改文件，锚点写错
 *   导致「声明 update/setUpdate/runUpdateCheck」的那段没插进去，只有引用
 *   插进去了。`node --check client.js` 依然通过（未声明标识符是运行时错误，
 *   不是语法错误），`status` 路由 RPC 也正常（那是 host 侧），
 *   所以我的全部测试都是绿的 —— 但用户一打开设置面板就崩。
 *
 * 做法：把 client.js 在假 window 里加载，拿到注册进来的 React 组件，
 * **真的把它渲染出来**（函数组件要真的调用、树要真的展开），让组件函数体
 * 完整执行一遍。任何未声明标识符、任何 h() 参数结构错误都会当场抛出。
 */

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const CLIENT = path.join(here, '..', 'client.js')

let pass = 0
let fail = 0
function ok(name, cond, detail) {
  if (cond) { pass++; console.log('  ✅', name) }
  else { fail++; console.log('  ❌', name, detail ? '— ' + detail : '') }
}

const src = fs.readFileSync(CLIENT, 'utf8')

/* ── React 桩 ─────────────────────────────────────────────────────────
 * createElement 与 React 同构（children 展平进数组）；useState 用可控队列，
 * 让每个用例喂不同的 state 组合。
 */
function makeReact(stateQueue) {
  let stateIdx = 0
  const React = {
    createElement: (type, props, ...children) => ({ type, props: props || {}, children }),
    useState: (init) => {
      const given = stateQueue && stateIdx < stateQueue.length ? stateQueue[stateIdx] : undefined
      stateIdx++
      const value = given !== undefined ? given : (typeof init === 'function' ? init() : init)
      return [value, () => {}]
    },
    useEffect: () => {},
    useCallback: (fn) => fn,
    useMemo: (fn) => fn(),
    useRef: (v) => ({ current: v }),
  }
  React.default = React
  return React
}

/* ── 加载 client.js，取回注册的 settings.section 组件 ── */
function loadClient(stateQueue) {
  let loaded = null
  const win = { __ModuleLoader__: { load: (def) => { loaded = def } } }
  const React = makeReact(stateQueue)
  const requireStub = (name) => (name === 'react' || name === 'react-dom' ? React : {})
  const fn = new Function('window', 'require', 'module', 'exports', src)
  fn(win, requireStub, { exports: {} }, {})

  if (!loaded || !loaded.factory) throw new Error('client.js 未通过 __ModuleLoader__.load 注册 factory')
  const body = loaded.factory(requireStub)
  if (!body || typeof body.apply !== 'function') throw new Error('factory 未返回带 apply() 的对象')

  let sectionComponent = null
  const ctx = {
    slots: {
      inject: (_key, cb) => { cb() },
      register: (_def, component) => { sectionComponent = component; return () => {} },
    },
    locale: undefined,
    logger: { debug: () => {}, info: () => {}, warn: () => {}, error: () => {} },
  }
  body.apply(ctx)
  if (typeof sectionComponent !== 'function') throw new Error('apply() 未注册 settings.section 组件')
  return { component: sectionComponent }
}

/* ── 真渲染：展开 React 元素树。函数组件必须被调用（这是关键）。 ──
 * 不用 React 也能验：我们自己展开 + 调用。深度上限防死循环。
 */
function render(el, depth = 0) {
  if (depth > 200) throw new Error('渲染深度超限（疑似无限递归）')
  if (el === null || el === undefined || el === false || el === true) return null
  if (typeof el === 'string' || typeof el === 'number') return String(el)
  if (Array.isArray(el)) return el.map((c) => render(c, depth + 1)).filter((x) => x !== null)
  if (typeof el !== 'object') return null
  if (typeof el.type === 'function') {
    // ★函数组件：真的执行它的函数体
    return render(el.type({ ...(el.props || {}), children: el.children }), depth + 1)
  }
  const kids = (el.children || []).map((c) => render(c, depth + 1)).filter((x) => x !== null)
  return { tag: el.type, props: el.props || {}, kids }
}

function collect(node, out) {
  if (node === null || node === undefined) return
  if (typeof node === 'string') { out.texts.push(node); return }
  if (Array.isArray(node)) { for (const c of node) collect(c, out); return }
  if (typeof node !== 'object') return
  out.count++
  if (node.tag === 'style') out.styleLen += String(node.kids || '').length
  if (node.tag === 'a' && node.props && node.props.href) out.links.push(node.props.href)
  if (node.tag === 'button') out.buttons++
  if (node.tag && typeof node.tag === 'string') out.tags.add(node.tag)
  for (const c of node.kids || []) collect(c, out)
}

function freshOut() {
  return { texts: [], count: 0, styleLen: 0, tags: new Set(), links: [], buttons: 0 }
}
function runCase(stateQueue, label) {
  const { component } = loadClient(stateQueue)
  let threw = null
  let tree = null
  try { tree = render(component({})) } catch (error) { threw = error }
  const out = freshOut()
  if (tree) collect(tree, out)
  return { threw, tree, out, text: out.texts.join(' ') }
}

function reportThrow(label, threw) {
  if (!threw) return
  console.log('       ' + label + ' 抛错: ' + threw.message)
  const stack = (threw.stack || '').split('\n').slice(1, 5)
  for (const line of stack) console.log('       ' + line.trim())
}

const FAKE_STATUS = {
  version: '1.3.0',
  enabled: true,
  config: { enabled: true, neutralize: true, brandReplace: 'CodeBuddy', persona: false },
  stats: { rewrites: 3, hits: 9, injected: 0 },
  fetchHookInstalled: true,
  patchPresent: false,
  meterPresent: false,
  hookStatus: { installed: true, chained: true, reason: 'active' },
}
const readyState = (over) => ({ status: 'ready', value: { ...FAKE_STATUS, ...(over || {}) }, error: null })

console.log('\n[s] 渲染自检：真实执行 FixPanel 组件体')

/* ── 用例 1：加载中（state.value = null） ─────────────────────────── */
{
  const r = runCase([{ status: 'loading', value: null, error: null }], 'loading')
  ok('加载中状态可渲染', r.threw === null); reportThrow('loading', r.threw)
  ok('加载中渲染出节点', r.out.count > 0, 'count=' + r.out.count)
  ok('样式表已内联', r.out.styleLen > 1500, 'styleLen=' + r.out.styleLen)
}

/* ── 用例 2：就绪（state.value 有真实 status 形状）★核心用例 ─────────
 * 这条能抓住「update 未声明」：updateTone/updateText 在 return 之前无条件
 * 求值，任何未声明都会在这里抛 ReferenceError。
 */
{
  const r = runCase([
    readyState(),                 // ① state
    false,                        // ② busy
    null,                         // ③ preview
    { phase: 'idle', result: null }, // ④ update
  ], 'ready')
  ok('就绪状态可渲染（含检查更新行）', r.threw === null); reportThrow('ready', r.threw)
  ok('显示版本号 1.3.0', r.text.includes('1.3.0'), '文本片段: ' + r.text.slice(0, 200))
  ok('出现「检查更新」按钮', r.text.includes('检查更新') || r.text.includes('Check for updates'),
    '文本片段: ' + r.text.slice(0, 200))
  ok('渲染节点数合理', r.out.count > 40, 'count=' + r.out.count)
  ok('含按钮元素', r.out.buttons >= 1, 'buttons=' + r.out.buttons)
  ok('含主通道状态文案', r.text.includes('主通道') || r.text.includes('Main channel'))
}

/* ── 用例 3：检查更新进行中（按钮应消失） ─────────────────────────── */
{
  const r = runCase([readyState(), false, null, { phase: 'checking', result: null }], 'checking')
  ok('检查更新中可渲染', r.threw === null); reportThrow('checking', r.threw)
  ok('检查中显示「检查中」文案', r.text.includes('检查中') || r.text.includes('Checking'))
  const rIdle = runCase([readyState(), false, null, { phase: 'idle', result: null }], 'idle')
  ok('检查中比 idle 少一个按钮', r.out.buttons === rIdle.out.buttons - 1,
    `checking=${r.out.buttons} idle=${rIdle.out.buttons}`)
}

/* ── 用例 4：查到新版本（走 warn tone + 去看看链接） ──────────────── */
{
  const r = runCase([
    readyState(), false, null,
    { phase: 'done', result: { ok: true, current: '1.3.0', latest: '1.4.0', hasUpdate: true, url: 'https://example.test/r' } },
  ], 'hasUpdate')
  ok('有新版本时可渲染', r.threw === null); reportThrow('hasUpdate', r.threw)
  ok('显示新版本号', r.text.includes('1.4.0'), '文本片段: ' + r.text.slice(0, 200))
  ok('提供「去看看」链接', r.out.links.includes('https://example.test/r'), 'links=' + JSON.stringify(r.out.links))
}

/* ── 用例 5：查不到更新（ok:false，必须中性文案而非报错） ─────────── */
{
  const r = runCase([
    readyState(), false, null,
    { phase: 'done', result: { ok: false, reason: 'network' } },
  ], 'failed')
  ok('查不到更新时可渲染', r.threw === null); reportThrow('failed', r.threw)
  ok('走「查不到」中性文案', r.text.includes('查不到') || r.text.includes('Could not check'),
    '文本片段: ' + r.text.slice(0, 200))
  ok('「查不到」不产生链接', r.out.links.length === 0)
}

/* ── 用例 6：主通道被别的插件包在内层但已有改写计数 ──────────────── */
{
  const r = runCase([
    readyState({
      fetchHookInstalled: false,
      stats: { rewrites: 12, hits: 40, injected: 0 },
      hookStatus: { installed: false, chained: true, reason: 'chained' },
    }), false, null, { phase: 'idle', result: null },
  ], 'chained')
  ok('内层运行态可渲染', r.threw === null); reportThrow('chained', r.threw)
  ok('内层运行态不显示故障提示', !r.text.includes('没跑起来'),
    '文本片段: ' + r.text.slice(0, 240))
  ok('内层运行态显示计数', r.text.includes('40'), '文本片段: ' + r.text.slice(0, 240))
}

/* ── 用例 7：从未安装（真故障，必须显式报错样式） ────────────────── */
{
  const r = runCase([
    readyState({
      fetchHookInstalled: false,
      stats: { rewrites: 0, hits: 0, injected: 0 },
      hookStatus: { installed: false, chained: false, reason: 'never-installed' },
    }), false, null, { phase: 'idle', result: null },
  ], 'never-installed')
  ok('未安装态可渲染', r.threw === null); reportThrow('never-installed', r.threw)
  ok('未安装态给出重启提示', r.text.includes('没跑起来') || r.text.includes('not running'),
    '文本片段: ' + r.text.slice(0, 240))
}

/* ── 用例 8：加载失败（state.status = 'error'） ──────────────────── */
{
  const r = runCase([{ status: 'error', value: null, error: 'boom' }, false, null,
    { phase: 'idle', result: null }], 'error')
  ok('加载失败态可渲染', r.threw === null); reportThrow('error', r.threw)
  ok('加载失败显示原因', r.text.includes('boom'), '文本片段: ' + r.text.slice(0, 200))
}

/* ── 用例 9：静态兜底 —— 剔除字符串与注释后再查未声明标识符 ─────────
 * 渲染用例已能抓到大部分，这条是补偿：渲染用例只覆盖了被喂到的 state
 * 组合，静态扫描能覆盖未执行到的分支。
 */
{
  const body = src.slice(src.indexOf('function FixPanel'), src.indexOf('function errorText'))
  // 先剔除注释与字符串字面量，避免把 t('option.neutralize') 里的 option 当标识符
  const stripped = body
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/\/\/[^\n]*/g, ' ')
    .replace(/`(?:\\[\s\S]|[^`\\])*`/g, '""')
    .replace(/'(?:\\[\s\S]|[^'\\])*'/g, '""')
    .replace(/"(?:\\[\s\S]|[^"\\])*"/g, '""')

  const suspects = new Set()
  // 关键：`(?<![.\w])` 排除「属性访问里的名字」（upd.hasUpdate 里的 hasUpdate
  // 不是自由标识符，它只是 v.version / config.personaTemplate 这类属性名）。
  const re = /(?<![.\w$])([a-z][A-Za-z0-9_]{2,})\s*(?:\.|===|!==|&&|\|\||\?)/g
  let m
  while ((m = re.exec(stripped))) suspects.add(m[1])

  const builtins = new Set([
    'typeof', 'null', 'true', 'false', 'undefined', 'string', 'number', 'boolean',
    'globalThis', 'console', 'window', 'document', 'fetch', 'JSON', 'Number', 'String',
    'Array', 'Object', 'Promise', 'Math', 'Date', 'AbortController', 'setTimeout',
    'clearTimeout', 'URL', 'encodeURIComponent', 'decodeURIComponent',
  ])
  const undeclared = [...suspects].filter((id) => {
    if (builtins.has(id)) return false
    // 局部声明（const/let/var/function）
    if (new RegExp('(?:const|let|var|function)\\s+' + id + '\\b').test(stripped)) return false
    // 解构数组声明：[ update, setUpdate ]
    if (new RegExp('\\[\\s*' + id + '\\s*,').test(stripped)) return false
    // 对象解构：const { a, b } = ...
    if (new RegExp('[\\{,]\\s*' + id + '\\s*(?=[,}=:])').test(stripped)) return false
    // 函数参数
    if (new RegExp('\\(\\s*(?:[^)]*,\\s*)?' + id + '\\s*(?:,[^)]*)?\\)\\s*=>').test(stripped)) return false
    if (new RegExp('\\(([^)]*\\b' + id + '\\b[^)]*)\\)\\s*\\{').test(stripped)) return false
    return true
  })
  ok('面板内无未声明的自由标识符', undeclared.length === 0,
    undeclared.length ? '疑似未声明: ' + undeclared.join(', ') : '')
}

console.log(`\n  渲染自检：${pass} 通过 / ${fail} 失败`)
process.exit(fail === 0 ? 0 : 1)
