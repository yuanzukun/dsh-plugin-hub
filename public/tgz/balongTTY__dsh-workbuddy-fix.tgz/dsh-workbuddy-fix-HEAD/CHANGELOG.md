# Changelog

本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [1.1.3] - 2026-10-21

### 文档：OFM 版本兼容矩阵可视化

新增 `docs/ofm-version-matrix.svg`（960×452，13.5 KB，自包含无外部依赖），在 README 的
「兼容通道」段落直接展示 14 个版本的兼容状态。

图里包含四层信息：
1. **14 个方块**：绿 = 支持，红 = 无锚点，橙 = 渠道下线
2. **块内 `wb N`**：pack.js 里 `workbuddy` 字符串的出现次数
   - 39 次（v2.0.0~v2.5.1，无补 system 逻辑）
   - 41 次（v2.5.2~v2.5.7，有锚点）
   - **4 次**（v2.5.8，渠道被移除）← 最直观的终止信号
3. **两个关键标注**：v2.5.2 分界线、v2.5.8 终止
4. **底部两条通道对比** + 稳健判据 `plain == PROBE + anchor`

技术选择：用**手写 SVG** 而非截图/GIF ——
- 3 KB 级体积 vs 几百 KB 图片
- GitHub 原生支持 SVG 渲染，深浅色模式都清晰
- 文字可被搜索、可被屏幕阅读器读取
- 矢量无级缩放，Retina 屏不糊

## [1.1.2] - 2026-10-21

### 文档：补全 OFM 版本兼容矩阵（14 个版本全量实测）

README 的「已知边界」从模糊的「OFM 大版本升级后锚点可能消失」改为**明确的版本区间**：

| OFM 版本 | pack.js 锚点 | 说明 |
|---|---:|---|
| v2.0.0 ~ v2.5.1 | ❌ | 锚点代码尚未引入 |
| **v2.5.2 ~ v2.5.7** | ✅ | **唯一支持区间（6 个版本）** |
| **v2.5.8+** | ❌ | **上游移除 WorkBuddy 渠道** |

**v2.5.2 是第一个支持版本**：pack.js 2.62MB → 2.64MB（+13KB），新增这段：

```js
if (this.product.id === "workbuddy" && (messages.length === 0 || messages[0].role !== "system")) {
  messages.unshift({ role: "system", content: "You are a helpful assistant." });
}
```

**v2.5.8 是终止点**：GitHub release 原文「移除 WorkBuddy 国内版和国际版渠道入口，保留历史账号、凭据及用户数据。」
物证：`workbuddy` 提及 41→4、锚点 1→0、pack.js 2.65MB→2.50MB（−148KB）。

### 新增的稳健判据（不依赖锚点精确字符串）

`"You are a helpful assistant"` 在 pack.js 里有两个来源，必须分开计数：
1. `PROBE_SYSTEM` 常量（account-probe.ts，探测用）—— 所有版本都有 1 处
2. workbuddy 补 system 分支（带锚点）—— v2.5.2 起才有第 2 处

**14/14 个版本都满足 `plain === PROBE + anchor`** —— 可用于判断「OFM 是否支持本插件」而不必匹配锚点原文。

### 副产物
- 矩阵数据：`matrix.json`（含每版 pack.js 的 sha256）
- 人读版：`MATRIX.md`

## [1.1.1] - 2026-10-21

### 修复
- **`dry-run` 默认示例文本被 U+200B 污染**：该文本原是硬编码字面量，写作时从上下文抄到的是「已中和」版本，导致面板「效果预览」显示「改前 == 改后」，用户以为功能失效。现在改从 `LEXICON_DEFAULTS.keywords[0]` 程序拼接。
- **`readOfmVersion()` 路径算错**：从 pack.js 目录只上跳 2 级（应为 3 级才到 `<ofm>/package.json`），导致诊断永远显示 `OFM version=unknown`。

### 文档/诊断增强
- `src/patch.mjs` 的 `LEXICON_ANCHOR` 补上**版本依赖说明**（见下）。
- `diagnose.mjs` 在「锚点不匹配」时直接输出**版本分界线与两种解法**，不再只说「OFM 版本变了」。

### 已实测的版本分界线（三份 npm tarball 逐字节比对）
| OFM 版本 | 锚点 `LEXICON_ANCHOR` | 说明 |
|---|---|---|
| 2.0.0（npm） | **0 次** | 连 `workbuddy`+`system` 的行都没有 |
| 2.1.0（npm latest） | **0 次** | npm 上能直接装到的最新版 |
| 2.5.6（GitHub） | **1 次** | 锚点存在 |

→ 「workbuddy 补 system」这段代码是 **2.1.0 之后才加的，且只发在 GitHub**。
用户装 npm 版（2.0/2.1）时锚点必然不存在，表现为「补打钩子也没用」。

**v1.1.0 起主通道已改为 fetch 层，不依赖该锚点** —— 本模块仅为「非 fetch 请求」兜底。

## [1.1.0] - 2026-10-21

### 架构改动（重要）

**不再依赖 dsh-our-free-model 的文件结构。** 旧版必须往 OFM 的
`vendor/channel-pack/pack.js` 插一行钩子 —— 这意味着 OFM 升级改结构、
用户装的不是 OFM（而是别的 WB 反代插件）、或者插件与 OFM 不在同一个
profile，钩子就插不进去，表现为面板一直显示「pack.js 未打钩子」且
点「补打钩子」也无效。

v1.1.0 把主通道改成**包 `globalThis.fetch`**：在 `chat/completions`
请求发出前改写 body。不修改任何文件，因此对**任何走 fetch 发 WB 请求的
反代插件**都有效，与 OFM 版本/路径/profile 无关。

- 新增 `src/fetch-hook.mjs`
- 命中范围：`copilot.tencent.com` / `workbuddy.ai` / `codebuddy.ai` / `codebuddy.cn`
  的 `chat/completions`
- 安全边界：非 WB 域名/非 POST/非 JSON/解析失败/rewrite 抛错 → 一律原样透传
- 关掉总开关后 body 与原请求字节级一致
- pack.js 行钩子降级为**可选兼容通道**（兜底非 fetch 请求），打不上不再算故障，
  面板显示「旧版钩子未打上（不影响使用）」

### 自检
- 新增 `_out/selftest-fetch-hook.mjs`：7 项全通过（拦截改写 / 非 WB 透传 /
  关闭后字节一致 / 非 JSON 放行 / GET 不介入 / rewrite 异常不拖垮 / 可卸载）

## [1.0.1] - 2026-10-21

### 修复
- **面板不再吞掉错误原因**：之前「pack.js 未打钩子」只显示结论，不显示为什么，用户只能盲点「补打钩子」。现在会直接显示具体原因（OFM 未安装 / pack.js 路径不存在 / 锚点不匹配），并区分「OFM 升版导致锚点消失」这种补打也修不了的情况。
- **运行时钩子缺失时给出可操作提示**，而不是只报状态。

### 新增
- `diagnose.mjs` 独立诊断脚本：逐项检查 DSH_HOME、profile、OFM 安装、pack.js、钩子与锚点，并明确告知卡在哪一步、怎么修。只读，不改文件。

## [1.0.0] — 2026-10-21

首个公开版本。

### 新增

- **一键修复 WorkBuddy / CodeBuddy 400 错误**（`Illegal API invocation from an
  unapproved channel` / code `11128`）。
  - 真因是上游对 system prompt 做**关键词**内容风控，命中 `DeepSeek Harness` 即拒；
  - 修法是在两个词之间插入零宽空格 `U+200B` —— 语义不变、上下文不丢、完全无损；
  - 实测：原文 **0/5 失败** → 中和后 **5/5 通过**（真实 DSH 请求形状）。
- **设置页独立面板**（`settings.section`，导航名 `wb400修复`），4 个开关：
  总开关 / 中和身份关键词 / 补首条 system / 隐藏品牌词。
- **文件路径保护**：匹配器带前后负向断言 `(?<![\\/])…(?![\\/])`，
  不会把 `D:\...\DeepSeek Harness\...` 这类真实路径改坏。
- **与 dsh-workbuddy-meter 联动**：共享状态文件
  `~/.dsh/workbuddy-meter/lexicon.json`，任一方改开关另一方立即跟随。
  两个插件可同时安装，也可只装其一。
- **补丁自愈**：pnpm 重装 OFM 会冲掉 `pack.js` 里的钩子行，插件启动时自动重打。

### 修复（开发过程中踩到并修掉的四个真 bug）

1. **宿主白屏**：给 `slots.register` 传 `locale` 选项，namespace 未在宿主
   `LocaleNamespaceMap` 中注册 → 校验同步抛错 → 整个 client 半身加载失败
   → `Failed to load plugins`。已移除该选项，并给所有注册点加 `try/catch`，
   保证最坏只是「这一页打不开」，绝不拖垮宿主 UI。
2. **路由全 400**：`connection.fetch` 的 handler 必须返回**标准 `Response`**；
   返回 `{ status, headers, body }` 普通对象会被宿主判为无效请求。
3. **文案显示成 key**：内嵌字典用扁平点号键，而 `pick()` 只按下钻查找
   → 全部回退成 `state.on` 这种原始 key。已改为两种风格都支持。
4. `apply()` 中段曾因清理脚本的正则误删导致 `ReferenceError`，已重写。

### 验证

- Host 侧路由与联动：**10/10**
- 钩子端到端（散文中和 / 路径保护 / 统计 / 关开关不改写）：**6/6**
- 设置页面板：真浏览器渲染确认，4 个开关 + 中文文案
- 旧插件 `dsh-workbuddy-meter`：自测通过、路由 200，未受影响
