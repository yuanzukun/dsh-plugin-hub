# Changelog

## [1.3.2] - 2026-10-22

> 🔴 **紧急修复：v1.3.0 / v1.3.1 会导致宿主崩溃 + 插件完全不可用。请直接升级到本版。**
>
> v1.3.0 与 v1.3.1 **从未发布过正式 Release**，只在本机运行过。本版把它们的内容
> （版本号显示 + 检查更新）与全部稳定性修复一起发布。

### 新增

- **面板显示版本号** —— 设置页标题右侧显示当前版本（如 `v1.3.2`），一眼能看出装的是哪版。
- **检查更新** —— 面板内「检查更新」按钮，读 GitHub Releases 最新版并与当前版本比较。
  网络不通时显示中性灰提示，**不会报红**（查不到更新是正常情况：本机无代理时
  `github.com` 经常超时，不是故障）。
- **新路由** `POST /workbuddy-fix/update-check`，6 秒超时，任何异常都收敛成
  `{ok:false, reason}`，绝不抛错。

### 崩溃事故复盘（第三次 —— 同一 bug 的第二个副本）

**症状**：2026-10-22 00:13:30 与 00:15:11 连续两次宿主崩溃，与 v1.2.2 修过的形态完全一致：
```
RangeError: Maximum call stack size exceeded
dsh: fatal uncaught exception: RangeError: Maximum call stack size exceeded
```

**我犯的错**：v1.2.2 我删掉了独立的 `reassertFetchHook()`，就以为清干净了。
**同一段逻辑还藏在 `installFetchHook` 的复用分支里**：

```js
// 旧代码（v1.3.1 仍存在）
if (globalThis.fetch !== shared.wrapped) {
  shared.wrapped.__wbFixPrev = globalThis.fetch   // ← 把外部函数记成上游
  globalThis.fetch = shared.wrapped               // ← 抢回最外层
}
```

热重载每 `apply` 一次就走一遍这个分支。若某个插件是
`const p = fetch; fetch = (i,n) => p(i,n)` 这种写法，抢回最外层 + 改写
`__wbFixPrev` 之后链条变成：

```
我们的 wrapper → __wbFixPrev(对方) → p(仍是我们的 wrapper) → …∞
```

**为什么是「延迟崩溃」**：单次热重载只是把 `__wbFixPrev` 指向对方，环还没闭合；
连续几次之后环才成形。那天为了调试连续热重载了七八次 —— 正好把它逼出来。

### 修复（5 项，全部有实测证据）

**1. 复用分支彻底不再碰 `globalThis.fetch`**
复用已有 wrapper 时只更新回调与引用计数，一个字节都不改全局。
别人的包装留在外层也没关系：它转发时会进到我们，改写照常生效。

**2. 每代 wrapper 捕获自己的不可变 `tail`，并新增退役机制**
旧 wrapper 若继续读 `shared.pristine`，重装后读到的是「新一代的上游」，
而那个上游内部又转回旧 wrapper → 环路。现在：

- 每代 wrapper 闭包捕获自己那份 `tail`（不可变）
- `shared.retired`（WeakSet）标记退役，退役后**只走自己的 tail，绝不读 shared**

**3. `entering` 布尔 → `syncDepth` 同步计数（修「改写时灵时不灵」）**

环形保护原来用布尔标志。但 wrapper 是 async，`await` 期间它会一直为 true ——
**正常并发请求被误判成环路**，直接丢给原生 fetch 跳过改写。

实测（200 并发、同一批请求）：

| | rewrite 调用 | 上游收到未改写 |
|---|---:|---:|
| 修复前（布尔） | **20 / 200** | **180** |
| 修复后（同步计数） | **200 / 200** | **0** |

关键点：只统计**同步**进入次数。wrapper 本身不 await（同步返回 promise），
`finally` 里立刻递减 —— 正常并发互不重叠（深度恒为 1），真环路是纯同步调用，
计数瞬间冲顶。

**4. `pickSafeTail` 穿透 `__wbFixTail`（修 HMR 后全 502 的灾难性回归）**

HMR 会**重新评估模块**：新的 `shared` 是空对象，但 `globalThis.fetch` 仍指向
**上一个模块代**的 wrapper。此时 `original` 带我们的标记，旧逻辑直接返回 `null`
→ `tail = null` → `handleRequest` 里 upstream 为 null → **所有 WB 请求返回 502**。

实测：修复前 HMR 后 HTTP **502**、上游调用 **0** 次；修复后 **200**、上游调用 **1** 次。

修法：遇到带标记的 wrapper 就沿它的 `__wbFixTail` 往下穿透（最多 8 层），
一路走到真正的终点。

**5. `shared.native` 作为环路兜底终点（只写一次，永不覆盖）**

它是「本进程第一次安装钩子之前」的 fetch —— 捕获它时我们的 wrapper 还不存在，
所以结构上**不可能**指向我们。环路的唯一可靠出口。

⚠️ 关键：**卸载时不能清空 `native`**。清了的话下次安装时
`globalThis.fetch` 可能已是别人的包装（甚至转回我们的旧 wrapper），就失去安全出口了。

### 新增测试（6 个文件，全部验证过「改坏后会变红」）

| 文件 | 断言数 | 覆盖 |
|---|---:|---|
| `test/selftest-hmr-reeval.mjs` | 12 | 用 `import(HOOK + '?gen=N')` **真实重估模块**，5 代连续重载；断言不是 502 |
| `test/selftest-concurrency.mjs` | 6 | 200 并发必须**全部**走改写；并发结束后不残留计数 |
| `test/selftest-chain-safety.mjs` | 5 | 20 轮热重载 + 原生 fetch 调用次数合理（不成环） |
| `test/selftest-render.mjs` | 26 | **真调用**面板组件并递归展开元素树，断言渲染文本 |
| `test/selftest-i18n.mjs` | 9 | 中英键集双向差集、占位符一致 |
| `test/selftest-version.mjs` | 7 | 版本比较、更新检查失败路径不抛错 |

`test/selftest-cycle-guard.mjs` 补了「反复热重载 10 次 + 对方包在外层」的现场复现用例（8 项）。

**`selftest-hmr-reeval.mjs` 值得单独说**：它用查询串 `?gen=N` 强制 Node 重新求值模块，
拿到全新的 `shared` 实例 —— 这才是真实 HMR 的时序。只清变量是测不出这个 bug 的。

### 真实宿主实测证据

| 验证 | 结果 |
|---|---|
| `npm test`（15 个文件） | **exit 0，全绿** |
| 40 次 `status` 压测 | **40 / 40**，结果完全一致（无副作用、无漂移） |
| 6 轮热重载 + 20 次调用 | **6/6 重载成功、20/20 调用成功**，`hookStatus` 恒为 `active` |
| 崩溃日志 | 00:15 之后**无新增** crash |

### 排查过程留档（避免下次重复踩）

- **`node --check` 查不出未声明标识符** —— 那是运行时错误。所有 UI 改动必须有真渲染测试。
- **测试全绿 ≠ 功能正确** —— 这次 15 个文件全绿的同时，HMR 后插件是全 502 的。
  必须跑「真实重载时序」的测试。
- **`bundles` 缺条目会导致插件完全不加载**：Vite 插件在 `dependencies` 里但没有
  `bundles` 条目时，`fiberPhase` 为空、所有路由 404。排查时先看
  `~/.dsh/profiles/desktop/package.json` 的 `dsh.profile.bundles`。
- **`installBundle` 报 `already-installed` 时**：说明依赖还在但 bundle 条目不在了 ——
  必须先 `removeBundle` 再 `installBundle`，直接 install 会既不改 bundles 也不报真错。

### 回滚

```bash
git checkout v1.2.2 -- . && npm test
# 或恢复备份目录 .backup_2026-10-22_before_fix-reassert-in-reuse-branch/
```

## [1.2.2] - 2026-10-21

> 🔴 **紧急修复：v1.2.1 会导致宿主崩溃。已确认两次实际崩溃，请立刻升级。**

### 崩溃事故复盘

**症状**：打开「wb3xx修复」设置面板 → DSH 整个崩溃退出。
崩溃日志（`%APPDATA%\@deepseek-ai\dsh-desktop\logs\crash-*.log`）：
```
RangeError: Maximum call stack size exceeded
RangeError: Maximum call stack size exceeded   ← 连续多次
dsh: fatal uncaught exception: RangeError: Maximum call stack size exceeded
```

**根因**：v1.2.1 加了个 `reassertFetchHook()`「自愈」机制 ——
发现我们的 wrapper 不在 `globalThis.fetch` 最外层时，就把当前 fetch 记成
`__wbFixPrev`、再把我们的 wrapper 抢回最外层。它被 `status` 路由调用，
**每打开一次设置面板就执行一次**。

若某个插件的包装写法是「先抓住当前 fetch、之后转发给它」：
```js
const prev = globalThis.fetch          // ← 抓住的是我们的 wrapper
globalThis.fetch = (i, n) => prev(i, n)
```
自愈之后链条变成：
```
我们的 wrapper → __wbFixPrev(对方) → prev(还是我们的 wrapper) → …∞
```
**无限递归 → 栈溢出 → 宿主崩溃。**

更糟的是 v1.2.1 里连「环保护」的回退目标也不安全：它退到
`shared.original`，而那个引用在链式场景下本身就可能是我们的上游包装，
**照旧死循环**。我在自己的测试输出里亲眼看到过这个
`RangeError`，却没意识到它会在真实宿主上被触发 —— 这是我的判断失误。

### Fixed

- **彻底移除 `reassertFetchHook()`** —— 打开面板这种只读操作
  **绝不允许有副作用**。现在 status 路由只查询、不修改。

- **新增 `pristine` 兜底引用**：装钩子那一刻把「原始 fetch」定下来，
  之后**只读不改**，也不会从 `globalThis` 重新读取。环保护唯一可信的出口。

- **wrapper 加环保护**：检测到重入（同一次调用又绕回自己）时，
  只走 `pristine`；连 `pristine` 都缺失就返回 500 错误响应。
  **宁可这次请求失败，也绝不让宿主栈溢出。**

- **`upstream` 解析加防环判断**：`__wbFixPrev` 若等于我们自己（异常状态），
  退回 `pristine` 而不是形成环路。

- **新增 `getFetchHookStatus()`**：只读诊断，报告
  `{installed, chained, reason}`，让面板能说清
  「我们不在最外层但功能仍然正常」，而不是含糊地报「未接管」。

### Added (tests)

- `test/selftest-cycle-guard.mjs` —— 7 例，专门守住这次事故：
  1. 安装后 `installed=true`
  2. **对方捕获我们的 wrapper 再转发 → 不递归、不崩溃**（核心回归）
  3. 被包到内层时改写依然生效（链式转发）
  4. `getFetchHookStatus` 只读，不替换 `globalThis.fetch`
  5. 不在最外层时如实报 `chained`，不谎称 active
  6. 卸载后彻底复原
  7. `rewrite` 抛异常后 `entering` 复位（不会卡死后续请求）

### Verified

- 全量测试 **68/68**（9 个文件），退出码 0
- **真实宿主压测**：连打 `status` 路由 **40 次，0 失败，宿主存活**
  （这正是崩溃的触发路径）
- 桌面版安装目录与源码 sha256 逐一比对一致

### 教训

1. **只读接口不能有副作用** —— 尤其不能改全局对象。
2. **「自愈」类逻辑必须有环路检测**，否则会把对方的包装变成无限递归。
3. **兜底引用必须是「装钩子之前就冻结的值」**，不能是可能指回自己的引用。
4. **测试输出里出现的异常，哪怕测试"通过"了，也必须当回事。**
5. **改了源码必须核对装好的那份**：桌面版是**实体副本**不是符号链接，
   我修完源码却没同步过去，导致用户又崩了一次。

## [1.2.1] - 2026-10-21

> 反馈驱动的文案与布局优化。功能没变，但**说明文字全部重写** ——
> 原文案偏技术、术语多，读者要停下来想「这个词是什么意思」。

### Changed

- **面板文案整体重写**（中英各 65 个 key，完全对称）。

  标题：`关键词风控中和` → **`关键词风控修复`**
  副标题改为说人话：*「绕过上游对系统提示词的关键词拦截，顺便让这个 agent 换个身份」*

  三组标题从冷编号改成有递进感的描述：

  | 原 | 新 |
  |---|---|
  | ① 绕过检测 | **第一步 · 绕过拦截** |
  | ② 彻底换词 | **第二步 · 换掉品牌** |
  | ③ 人格注入 | **第三步 · 换个身份** |

  具体项也从「术语」改成「动作」：

  | 原 | 新 |
  |---|---|
  | 中和身份关键词 | **拆开关键词** |
  | 隐藏品牌词 | **品牌名也拆开** |
  | 补首条 system | **补一条开头消息** |
  | 替换成指定词 | **启用品牌替换** |
  | 替换目标 | **换成** |
  | 注入人格段 | **追加工作准则** |
  | 内置模板 / 编辑 / 恢复模板 | **内置模板 / 改一改 / 还原成模板** |
  | 随时可复原 | **随时可以反悔** |

  状态行也去掉了技术黑话：`主通道已接管（fetch 层）` → **`主通道已接管`**；
  `本机已中和 N 处` → **`已处理 N 处关键词`**。

### Fixed

- **`追加约 0 字符` 的显示问题**。当 Host 半身是旧版（尚未重启）拿不到
  模板长度时，原来回落成 `0`，看起来像功能坏了。现在分三种情况处理：
  有自定义 → 显示自定义长度；有模板长度 → 显示真实长度；
  都拿不到 → **不提数字**，只说「追加一套 CodeBuddy 风格的行为规范」。

- **人格模板预览默认折叠**。1,664 字符全展开会把下面的状态行挤出视野，
  现在只露两行 + 「展开全文」按钮。

### 测试

`npm test` → **61/61**（8 个文件），退出码 0
Playwright 真实浏览器验证：所有新文案正确渲染，`0 字符` 已消失。

## [1.2.0] - 2026-10-21

> 从「只做一件事」升级成「三类可组合能力」，并把面板重做成三组结构。
> 核心约束：**任何一项都能随时关掉、关掉即完全复原**。

### Added

- **② 彻底替换品牌词**（`brandReplace` + `replacement`，默认关）

  与原来的「无损中和」是两条互斥路径：

  | 模式 | 做法 | 效果 |
  |---|---|---|
  | 无损中和 | 插零宽空格 | 原文完整保留、语义不变、肉眼可辨 |
  | 彻底替换 | 把词换成 `replacement` | 视觉上也变了 |

  实测：`powered by DeepSeek Harness.` → `powered by CodeBuddy.`
  **路径里的同名词组仍然受保护**（`D:\10_COD\DeepSeek Harness\` 原样保留）。

- **③ 人格注入**（`persona` + `personaText`，默认关）

  在系统提示词末尾**追加**一段行为准则（内置 1,664 字符，从 CodeBuddy
  的提示词里挑出的通用工程约束：反过度工程 / 谨慎执行 / 输出效率）。

  三个关键设计：
  - **只追加、不替换** —— DSH 原有指令一条不动
  - **带识别标记**（`PERSONA_MARKER`）—— 幂等，同一条消息不会被注入两次
  - **可自定义** —— 面板里能编辑，留空则用内置模板

- **面板重做成三组结构**：① 绕过检测 / ② 彻底换词 / ③ 人格注入。
  每组带说明，按功能归类而不是平铺 6 个开关。

- **复原横幅**：面板底部常驻，说清「为什么能复原」（只改发出去的请求，
  不碰磁盘文件）。有功能开着时变成警示黄色。

### Verified

**可复原性是本版第一优先级**，用逐字节比对验证：

| 场景 | 结果 |
|---|---|
| 总开关关闭（三功能全开状态） | `JSON.stringify` 完全相等 |
| 人格注入关闭 | 整份 messages 逐字节相同，无标记残留 |
| 无损中和关闭 | 无任何零宽空格残留 |
| 反复开关 | 每次都从原文重新改，不累积 |

**端到端证据**（真实 HTTP 服务器收到的 body）：

```
伪装模式 → You are an AI agent powered by CodeBuddy.
           <!-- wb400-fix:persona -->
           You are CodeBuddy, a coding agent...
           原始关键词零残留

全关模式 → You are an AI agent powered by DeepSeek Harness.
           与原文逐字节相同
```

### Fixed

- `pack.js` 备份轮转：只保留最近 2 份（每份 2.9 MB，之前会无限累积）。
- `dry-run` 的 `mode` 字段在总开关关闭时如实报 `off`，不再显示 `neutralize`。

### Added (tests)

- `test/selftest-v12.mjs` —— 18 例，重点验证可复原性（不是「看起来差不多」，
  是逐字节比对）。

### 测试

`npm test` → **61/61**（8 个文件：3+9+18+3+5+7+8+8），退出码 0
真实浏览器（Playwright）验证：面板三组标题、6 个开关、复原横幅全部正常渲染。

## [1.1.6] - 2026-10-21

> 修完 v1.1.5 的 4 个后，继续把审计剩下的问题修掉。这一版重点是
> **「热重载后功能静默消失」** 和 **「可能改坏用户文件」** 这两类。

### Fixed

- **[中] HMR / 插件重载后 fetch 钩子可能彻底消失。**
  这是本机最高频的日常操作（`removeBundle → installBundle`），而 Cordis 的
  dispose/apply 顺序**不保证**。落到反序时：

  ```
  新实例看到已包装 → 返回空卸载函数（以为自己不用管）
  旧实例 dispose  → globalThis.fetch === 旧 wrapper → 还原成原始 fetch
  → 结果：新实例以为装好了，实际什么都没装，功能静默失效
  ```

  实测复现：`isFetchHookInstalled=false`，改写全部失效，400 复现，
  而面板只显示一盏红灯、没有任何自愈。

  **修法**：改成**模块级单例 + 引用计数**。
  - 所有实例共享同一个 wrapper，后 apply 的实例更新回调（热重载后自动走新代码）
  - `dispose` 只减计数，**归零才真正还原**
  - 卸载函数幂等（同一个调两次不会减两次计数）

- **[中] `pack.js` 补丁插入点用裸花括号计数，可能把用户的 OFM 改坏。**
  原实现直接数 `{` / `}`，不识别字符串/模板串/注释里的括号。
  若将来 OFM 在锚点块内出现 `content: "}"` 之类字面量，插入点会落到
  **语句中间**，把 2.9 MB 的 pack.js 写成非法 JS —— 而写后复验只数 marker
  是否存在，语法坏掉照样报「成功」，用户的 OFM 直接起不来。

  **修法**（两道）：
  1. 改成**词法感知**的扫描，跳过 `'…'` / `"…"` / 反引号串 / `//` / `/*…*/`
  2. 写后加**语法检查**（`new Function` 编译一遍），失败立即用备份回滚

  实测 5 个场景全过（块内含字符串 `}`、模板串、行注释、块注释）。

- **[低] `meterPresent` 恒为假阳性。**
  原判据是「`~/.dsh/workbuddy-meter/` 目录存在」，但这个目录**本插件自己
  保存配置时也会 mkdir** —— 从没装过 meter 的用户也会看到「与计量插件联动中」。
  改为查 meter 的特征文件（`plugin-state.json` 等）+ 退化查 profile 依赖。

- **[低] 每个 fetch 都同步读盘，且在 URL 判定之前。**
  `getConfig()` 约 0.068 ms/次，宿主**所有**插件的每一次 fetch（含完全无关的
  域名）都白付这个开销。改为先做零成本的 URL/method 判定，命中目标后才读配置。

- **[低] 面板乐观更新失败不回滚。**
  注释写着「失败再回滚」，但 `.catch` 只设 error、没还原 config ——
  `/set` 失败时开关停在翻转过的新状态，用户以为已生效。

### Changed

- README 顶部的 DSH badge 原本链到 `dsh-workbuddy-meter`（复制没改），
  改为指向本仓库，并补一个版本 badge。

### Added

- `test/selftest-reload.mjs` —— 3 例，验证三种 dispose/apply 顺序下钩子都存活。
- `test/selftest-patch.mjs` —— 5 例，验证词法感知的括号定位
  （字符串/模板串/行注释/块注释里的 `}` 都不误判）。

### 测试

`npm test` → **43/43**（7 个文件：3+9+3+5+7+8+8），退出码 0

## [1.1.5] - 2026-10-21

> 这一版全部来自一次**独立对抗性代码审计** —— 测试 26 项全绿的情况下，
> 审计仍抓出 10 个真实缺陷。核心教训：**「测试全绿」只说明测过的路径没问题**，
> 这个测试集此前只覆盖「默认开关组合下的正常路径」。

### Fixed

- **[高] `hideIdentity`（隐藏品牌词）开关从未真正生效。**
  `neutralizeText()` 做了 `DeepSeek → Deep<ZW>Seek` 的改写，但**不递增 hits**；
  而调用方用 `r.hits > 0` 决定是否写回 → 纯 `hideIdentity` 的改动被静默丢弃。

  更坏的是它**时灵时不灵**：当文本恰好也含关键词组合时，`hits` 被置为 1，
  整段改写就被「顺带」写回了。所以表现是「有时有用、有时没用」，最难排查。

  修法：`neutralizeMessage()` 改返回 `{ hits, changed }`，写回判据从
  `hits > 0` 改为「文本真的变了」；`rewriteMessages()` 与 `index.js` 同步透传
  `changed`，不再用 hits 重算。

- **[中] `Request` 对象形态丢失 `AbortSignal`，取消/超时失效。**
  改写后用 `original(url, rebuilt)` 重新发起，但 `signal` 挂在 `request.signal`
  上、从未复制进 `rebuilt`。后果：用户点「停止生成」或 `AbortSignal.timeout`
  对改写过的 WorkBuddy 请求**完全无效** —— 请求继续跑完，继续烧上游额度。

- **[中] 面板把 4 个 i18n key 原样显示给用户。**
  `status.fetchOk` / `status.fetchMissing` / `status.fetchMissingHint` /
  `status.patchOptional` 在内嵌字典里缺失（`locale/*.json` 里有，但本插件
  从未调用 `ctx.locale.register()`，那些是死键）。

  后果特别严重：README 让用户「看顶部有没有『主通道已接管（fetch 层）』」
  来确认安装成功 —— 而用户看到的是 `status.fetchOk` 这串英文，会误判装错、
  反复重装。**v1.1.4 的核心验收路径被这个 bug 切断。**

- **[低] `content-type` 被无条件覆盖，丢失 charset。**
  改为仅在头不存在时才补设。

### Added

- `test/selftest-switches.mjs` —— 9 例，专门验证**非默认开关真的生效**，
  断言「最终可观察结果」而非中间函数返回值。这个文件的存在本身就是对
  「测试全绿但功能是坏的」这类盲点的防线。

### Changed

- `diagnose.mjs` 重写：按用户踩坑概率排序，**先查版本再查一切**。
  旧版只查 pack.js（可选兜底），对「装了旧版 / 文件缺失 / bundle 没注册」
  这三个高频问题一个都查不出来。

## [1.1.4] - 2026-10-21

### Fixed

- **白名单漏了 workbuddy.cn，补上。** 这个域名是从第三方反代插件
  dsh-connect-workbuddy@4.11.0 的产物里实测扫出来的：它同时打
  www.workbuddy.cn 和 copilot.tencent.com。此前 WB_HOSTS 只写了
  workbuddy.ai，按后缀匹配覆盖不到 .cn 这个独立后缀。
  （本次实测未因此漏拦——它的 chat 走 copilot.tencent.com——但属于真实缺口。）

- **WB_HOSTS 改为导出**，方便测试与诊断核对实际生效的白名单。

### Added

- `test/selftest-hosts.mjs` —— 用**真实 fetch + 真实 HTTP 服务器**验证域名/路径
  匹配，而不是断言内部常量。覆盖 buddy 渠道路径、WB 标准路径、非 chat 路径。

- `test/selftest-switches.mjs` —— 验证**非默认开关确实生效**（9 例）。
  补这个是因为审计抓出一个真 bug：`hideIdentity` 从实现以来**从未真正生效过**
  （详见 1.1.5）。

### Verified

跨反代插件通用性实测（验证报告在作者工作区，未随仓库发布）：

| 插件 | 版本 | 请求路径 | 凭据来源 | fetch 钩子 |
|---|---|---|---|---|
| dsh-our-free-model | 2.5.6 | `/v1/chat/completions` | 自有账号池 | ✅ `rewrites 0→1` |
| dsh-connect-workbuddy | 4.11.0 | `/v2/chat/completions` | 桌面 App 登录态 | ✅ `rewrites 1→2, hits 6→12` |

两个插件的 provider 名、渠道命名、请求路径、凭据来源**全部不同**，钩子均生效
—— 这是「fetch 层与实现无关」的直接证据。

## [1.1.3] - 2026-10-21

### 文档：OFM 版本兼容矩阵可视化

新增 `docs/ofm-version-matrix.svg`（960×452，13.5 KB，自包含无外部依赖），在 README 的
「兼容通道」段落直接展示 14 个版本的兼容状态。

图里包含四层信息：
1. **14 个方块**：绿 = 支持，红 = 无锚点，橙 = 渠道下线
2. **块内 `wb N`**：pack.js 里 `workbuddy` 字符串的出现次数
   - 39 次（v2.0.0~v2.5.1，无补 system 逻辑）
   - 41 次（v2.5.2~v2.5.7，有锚点）
   - **4 次**（v2.5.8，渠道被移除）← 最直观的终止信号
3. **两个关键标注**：v2.5.2 分界线、v2.5.8 终止
4. **底部两条通道对比** + 稳健判据 `plain == PROBE + anchor`

技术选择：用**手写 SVG** 而非截图/GIF ——
- 3 KB 级体积 vs 几百 KB 图片
- GitHub 原生支持 SVG 渲染，深浅色模式都清晰
- 文字可被搜索、可被屏幕阅读器读取
- 矢量无级缩放，Retina 屏不糊

## [1.1.2] - 2026-10-21

### 文档：补全 OFM 版本兼容矩阵（14 个版本全量实测）

README 的「已知边界」从模糊的「OFM 大版本升级后锚点可能消失」改为**明确的版本区间**：

| OFM 版本 | pack.js 锚点 | 说明 |
|---|---:|---|
| v2.0.0 ~ v2.5.1 | ❌ | 锚点代码尚未引入 |
| **v2.5.2 ~ v2.5.7** | ✅ | **唯一支持区间（6 个版本）** |
| **v2.5.8+** | ❌ | **上游移除 WorkBuddy 渠道** |

**v2.5.2 是第一个支持版本**：pack.js 2.62MB → 2.64MB（+13KB），新增这段：

```js
if (this.product.id === "workbuddy" && (messages.length === 0 || messages[0].role !== "system")) {
  messages.unshift({ role: "system", content: "You are a helpful assistant." });
}
```

**v2.5.8 是终止点**：GitHub release 原文「移除 WorkBuddy 国内版和国际版渠道入口，保留历史账号、凭据及用户数据。」
物证：`workbuddy` 提及 41→4、锚点 1→0、pack.js 2.65MB→2.50MB（−148KB）。

### 新增的稳健判据（不依赖锚点精确字符串）

`"You are a helpful assistant"` 在 pack.js 里有两个来源，必须分开计数：
1. `PROBE_SYSTEM` 常量（account-probe.ts，探测用）—— 所有版本都有 1 处
2. workbuddy 补 system 分支（带锚点）—— v2.5.2 起才有第 2 处

**14/14 个版本都满足 `plain === PROBE + anchor`** —— 可用于判断「OFM 是否支持本插件」而不必匹配锚点原文。

### 副产物
- 矩阵数据：`matrix.json`（含每版 pack.js 的 sha256）
- 人读版：`MATRIX.md`

## [1.1.1] - 2026-10-21

### 修复
- **`dry-run` 默认示例文本被 U+200B 污染**：该文本原是硬编码字面量，写作时从上下文抄到的是「已中和」版本，导致面板「效果预览」显示「改前 == 改后」，用户以为功能失效。现在改从 `LEXICON_DEFAULTS.keywords[0]` 程序拼接。
- **`readOfmVersion()` 路径算错**：从 pack.js 目录只上跳 2 级（应为 3 级才到 `<ofm>/package.json`），导致诊断永远显示 `OFM version=unknown`。

### 文档/诊断增强
- `src/patch.mjs` 的 `LEXICON_ANCHOR` 补上**版本依赖说明**（见下）。
- `diagnose.mjs` 在「锚点不匹配」时直接输出**版本分界线与两种解法**，不再只说「OFM 版本变了」。

### 已实测的版本分界线（三份 npm tarball 逐字节比对）
| OFM 版本 | 锚点 `LEXICON_ANCHOR` | 说明 |
|---|---|---|
| 2.0.0（npm） | **0 次** | 连 `workbuddy`+`system` 的行都没有 |
| 2.1.0（npm latest） | **0 次** | npm 上能直接装到的最新版 |
| 2.5.6（GitHub） | **1 次** | 锚点存在 |

→ 「workbuddy 补 system」这段代码是 **2.1.0 之后才加的，且只发在 GitHub**。
用户装 npm 版（2.0/2.1）时锚点必然不存在，表现为「补打钩子也没用」。

**v1.1.0 起主通道已改为 fetch 层，不依赖该锚点** —— 本模块仅为「非 fetch 请求」兜底。

## [1.1.0] - 2026-10-21

### 架构改动（重要）

**不再依赖 dsh-our-free-model 的文件结构。** 旧版必须往 OFM 的
`vendor/channel-pack/pack.js` 插一行钩子 —— 这意味着 OFM 升级改结构、
用户装的不是 OFM（而是别的 WB 反代插件）、或者插件与 OFM 不在同一个
profile，钩子就插不进去，表现为面板一直显示「pack.js 未打钩子」且
点「补打钩子」也无效。

v1.1.0 把主通道改成**包 `globalThis.fetch`**：在 `chat/completions`
请求发出前改写 body。不修改任何文件，因此对**任何走 fetch 发 WB 请求的
反代插件**都有效，与 OFM 版本/路径/profile 无关。

- 新增 `src/fetch-hook.mjs`
- 命中范围：`copilot.tencent.com` / `workbuddy.ai` / `codebuddy.ai` / `codebuddy.cn`
  的 `chat/completions`
- 安全边界：非 WB 域名/非 POST/非 JSON/解析失败/rewrite 抛错 → 一律原样透传
- 关掉总开关后 body 与原请求字节级一致
- pack.js 行钩子降级为**可选兼容通道**（兜底非 fetch 请求），打不上不再算故障，
  面板显示「旧版钩子未打上（不影响使用）」

### 自检
- 新增 `_out/selftest-fetch-hook.mjs`：7 项全通过（拦截改写 / 非 WB 透传 /
  关闭后字节一致 / 非 JSON 放行 / GET 不介入 / rewrite 异常不拖垮 / 可卸载）

## [1.0.1] - 2026-10-21

### 修复
- **面板不再吞掉错误原因**：之前「pack.js 未打钩子」只显示结论，不显示为什么，用户只能盲点「补打钩子」。现在会直接显示具体原因（OFM 未安装 / pack.js 路径不存在 / 锚点不匹配），并区分「OFM 升版导致锚点消失」这种补打也修不了的情况。
- **运行时钩子缺失时给出可操作提示**，而不是只报状态。

### 新增
- `diagnose.mjs` 独立诊断脚本：逐项检查 DSH_HOME、profile、OFM 安装、pack.js、钩子与锚点，并明确告知卡在哪一步、怎么修。只读，不改文件。

## [1.0.0] — 2026-10-21

首个公开版本。

### 新增

- **一键修复 WorkBuddy / CodeBuddy 400 错误**（`Illegal API invocation from an
  unapproved channel` / code `11128`）。
  - 真因是上游对 system prompt 做**关键词**内容风控，命中 `DeepSeek Harness` 即拒；
  - 修法是在两个词之间插入零宽空格 `U+200B` —— 语义不变、上下文不丢、完全无损；
  - 实测：原文 **0/5 失败** → 中和后 **5/5 通过**（真实 DSH 请求形状）。
- **设置页独立面板**（`settings.section`，导航名 `wb400修复`），4 个开关：
  总开关 / 中和身份关键词 / 补首条 system / 隐藏品牌词。
- **文件路径保护**：匹配器带前后负向断言 `(?<![\\/])…(?![\\/])`，
  不会把 `D:\...\DeepSeek Harness\...` 这类真实路径改坏。
- **与 dsh-workbuddy-meter 联动**：共享状态文件
  `~/.dsh/workbuddy-meter/lexicon.json`，任一方改开关另一方立即跟随。
  两个插件可同时安装，也可只装其一。
- **补丁自愈**：pnpm 重装 OFM 会冲掉 `pack.js` 里的钩子行，插件启动时自动重打。

### 修复（开发过程中踩到并修掉的四个真 bug）

1. **宿主白屏**：给 `slots.register` 传 `locale` 选项，namespace 未在宿主
   `LocaleNamespaceMap` 中注册 → 校验同步抛错 → 整个 client 半身加载失败
   → `Failed to load plugins`。已移除该选项，并给所有注册点加 `try/catch`，
   保证最坏只是「这一页打不开」，绝不拖垮宿主 UI。
2. **路由全 400**：`connection.fetch` 的 handler 必须返回**标准 `Response`**；
   返回 `{ status, headers, body }` 普通对象会被宿主判为无效请求。
3. **文案显示成 key**：内嵌字典用扁平点号键，而 `pick()` 只按下钻查找
   → 全部回退成 `state.on` 这种原始 key。已改为两种风格都支持。
4. `apply()` 中段曾因清理脚本的正则误删导致 `ReferenceError`，已重写。

### 验证

- Host 侧路由与联动：**10/10**
- 钩子端到端（散文中和 / 路径保护 / 统计 / 关开关不改写）：**6/6**
- 设置页面板：真浏览器渲染确认，4 个开关 + 中文文案
- 旧插件 `dsh-workbuddy-meter`：自测通过、路由 200，未受影响
