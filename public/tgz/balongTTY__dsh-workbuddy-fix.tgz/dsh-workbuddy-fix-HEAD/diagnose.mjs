/**
 * dsh-workbuddy-fix 诊断脚本 —— 给「面板显示 pack.js 未打钩子」用的。
 *
 * 用法（Windows PowerShell）：
 *   node diagnose.mjs
 *
 * 它会逐项检查，并明确告诉你卡在哪一步、怎么修。只读，不改任何文件。
 */

import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

const MARKER = '__wbLexicon'
const ANCHOR =
  'if (this.product.id === "workbuddy" && (messages.length === 0 || messages[0].role !== "system")) {'

const ok = (s) => console.log(`  \x1b[32m✓\x1b[0m ${s}`)
const bad = (s) => console.log(`  \x1b[31m✗\x1b[0m ${s}`)
const info = (s) => console.log(`    ${s}`)
const head = (s) => console.log(`\n\x1b[36m${s}\x1b[0m`)

const count = (text, needle) => {
  let c = 0
  let i = 0
  while ((i = text.indexOf(needle, i)) !== -1) {
    c += 1
    i += needle.length
  }
  return c
}

head('1. 定位 DSH_HOME')
const dshHome = String(process.env.DSH_HOME ?? '').trim() || path.join(os.homedir(), '.dsh')
if (fs.existsSync(dshHome)) {
  ok(`DSH_HOME = ${dshHome}`)
} else {
  bad(`DSH_HOME 不存在：${dshHome}`)
  info('说明 DSH 没装好，或环境变量指错了。')
  process.exit(1)
}

head('2. 列出所有 profile')
const profilesDir = path.join(dshHome, 'profiles')
if (!fs.existsSync(profilesDir)) {
  bad(`没有 profiles 目录：${profilesDir}`)
  process.exit(1)
}
const profiles = fs
  .readdirSync(profilesDir, { withFileTypes: true })
  .filter((d) => d.isDirectory())
  .map((d) => d.name)
ok(`发现 profile：${profiles.join(' / ') || '(空)'}`)

head('3. 逐个 profile 检查 dsh-our-free-model 与 pack.js')
const found = []
for (const pf of profiles) {
  const ofmDir = path.join(profilesDir, pf, 'node_modules', 'dsh-our-free-model')
  const packFile = path.join(ofmDir, 'vendor', 'channel-pack', 'pack.js')

  console.log(`\n  [${pf}]`)
  if (!fs.existsSync(ofmDir)) {
    bad('未安装 dsh-our-free-model')
    info('→ 本插件依赖它。先装：dsh plugin --profile ' + pf + ' add dsh-our-free-model')
    continue
  }
  ok('dsh-our-free-model 已安装')

  if (!fs.existsSync(packFile)) {
    bad(`pack.js 不存在：${packFile}`)
    info('→ OFM 版本可能变了（vendor/channel-pack/pack.js 路径改了）')
    continue
  }
  const size = fs.statSync(packFile).size
  ok(`pack.js 存在（${(size / 1024 / 1024).toFixed(2)} MB）`)
  found.push({ pf, packFile })
}

if (found.length === 0) {
  head('结论：找不到任何可用的 pack.js')
  info('本插件的工作方式是往 pack.js 插一行钩子。没有 pack.js 就打不上钩子。')
  info('请先装好 dsh-our-free-model，并确认它至少能正常跑起来。')
  process.exit(1)
}

head('4. 检查钩子与锚点')
for (const { pf, packFile } of found) {
  console.log(`\n  [${pf}]`)
  const text = fs.readFileSync(packFile, 'utf8')
  const markers = count(text, MARKER)
  const anchors = count(text, ANCHOR)

  if (markers > 0) {
    ok(`钩子已在位（${MARKER} 出现 ${markers} 次）`)
    const line = text.split('\n').find((l) => l.includes(MARKER))
    info(`实际内容：${(line ?? '').trim()}`)
  } else {
    bad(`钩子不存在（${MARKER} 出现 0 次）`)
  }

  if (anchors === 1) {
    ok('插入锚点匹配（OFM 结构正常）')
  } else if (anchors === 0) {
    bad('插入锚点不匹配 → OFM 版本变了，本插件认不出该往哪插')
    info('这是「补打钩子」也修不好的情况。请把下面这行贴给开发者：')
    info('  anchors=0, OFM version=' + readOfmVersion(packFile))
    const wbLines = text
      .split('\n')
      .map((l, i) => [i + 1, l])
      .filter(([, l]) => l.includes('workbuddy') && l.includes('system'))
    if (wbLines.length) {
      info('  含 workbuddy+system 的行（供对照）：')
      wbLines.slice(0, 3).forEach(([n, l]) => info(`    L${n}: ${l.trim().slice(0, 160)}`))
    }
  } else {
    bad(`插入锚点出现 ${anchors} 次（期望 1）→ OFM 结构异常`)
  }

  // ★ 2026-10-21 实测的版本分界线：锚点是 2.1.0 之后才有的，且只在 GitHub 发布。
  //   用户装 2.0/2.1（npm 上能直接装到的最新）时锚点必然不存在。
  if (anchors === 0) {
    const ver = readOfmVersion(packFile)
    info('')
    info(`本机 OFM 版本：${ver}`)
    info('已验证的版本分界（三份 tarball 逐字节比对）：')
    info('  OFM 2.0.0 / 2.1.0（npm，含 latest）→ 锚点不存在')
    info('  OFM 2.5.x（GitHub）              → 锚点存在')
    info('')
    info('→ 结论：这个版本根本没有锚点代码，补打钩子也打不上。两种解法：')
    info('  A. 升级 OFM 到 GitHub 的 2.5.x（不是 npm 上的 2.1.0）')
    info('  B. 不用管它 —— v1.1.0 起主通道是 fetch 层，不依赖 pack.js 结构，')
    info('     只要面板显示「主通道已接管（fetch 层）」功能就正常。')
  }
}

/**
 * 从 pack.js 的绝对路径推 OFM 版本。
 * 目录结构：<ofm>/vendor/channel-pack/pack.js  →  <ofm>/package.json
 * 所以从「包含 pack.js 的目录」往上 3 级才是 package.json。
 * （早期版本这里只上跳 2 级，导致永远返回 unknown。）
 */
function readOfmVersion(packFilePath) {
  try {
    const ofmDir = path.resolve(path.dirname(packFilePath), '..', '..')
    const pkg = JSON.parse(fs.readFileSync(path.join(ofmDir, 'package.json'), 'utf8'))
    return pkg.version ?? 'unknown'
  } catch {
    return 'unknown'
  }
}

head('5. 结论')

// v1.1.0 起：主通道是 fetch 层钩子（不碰文件），pack.js 只是可选兜底。
// 所以「没有钩子」不再等于「功能不可用」——只要能确认 fetch 钩子装上即可。
console.log('\n  ℹ️  v1.1.0 起主通道改为 fetch 层拦截，不再依赖 pack.js。')
console.log('     下面这一步只能检查「可选兜底」是否就位，不能判断主功能。')
console.log('     要确认主通道，请看插件面板的「主通道已接管（fetch 层）」，')
console.log('     或跑本目录下的 test/runtime-hook.mjs（真 fetch + 真服务器验证）。')

const anyPatched = found.some(({ packFile }) =>
  fs.readFileSync(packFile, 'utf8').includes(MARKER),
)
if (anyPatched) {
  ok('可选兜底钩子已就位（非 fetch 请求也能拦）')
} else {
  info('可选兜底钩子未打上 —— 这不影响主功能（fetch 层已经覆盖绝大多数请求）。')
  info('如果面板显示「主通道已接管（fetch 层）」，就说明一切正常。')
}
