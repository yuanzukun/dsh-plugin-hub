/**
 * dsh-workbuddy-fix 诊断脚本。
 *
 * 用法（Windows PowerShell）：
 *   node diagnose.mjs
 *
 * 设计原则：**只读，不改任何文件**。
 *
 * 检查顺序按「用户实际踩坑的概率」排：
 *   1. 本插件到底装没装、装的什么版本   ← 最常见的问题
 *   2. 面板能不能显示（client 半身是否OK）
 *   3. fetch 主通道是否可能生效（反代插件在不在、走不走 fetch）
 *   4. pack.js 兜底通道（可选，旧方案）
 *
 * v1.1.x 起主通道是 fetch 层，**pack.js 已降级为可选兜底**，
 * 所以「钩子没打上」不再等于「功能不可用」。
 */

import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

const PKG_NAME = '@balong/dsh-workbuddy-fix'
const MARKER = '__wbLexicon'
const ANCHOR =
  'if (this.product.id === "workbuddy" && (messages.length === 0 || messages[0].role !== "system")) {'

/** 需要 v1.1.0+ 才有 fetch 通道；低于这个版本对多数用户无效。 */
const MIN_GOOD_MAJOR = 1
const MIN_GOOD_MINOR = 1

const ok = (s) => console.log(`  \x1b[32m✓\x1b[0m ${s}`)
const bad = (s) => console.log(`  \x1b[31m✗\x1b[0m ${s}`)
const warn = (s) => console.log(`  \x1b[33m!\x1b[0m ${s}`)
const info = (s) => console.log(`    ${s}`)
const head = (s) => console.log(`\n\x1b[36m${s}\x1b[0m`)

const count = (text, needle) => {
  let c = 0
  let i = 0
  while ((i = text.indexOf(needle, i)) !== -1) {
    c += 1
    i += needle.length
  }
  return c
}

/** 解析 semver，返回 [major, minor, patch]；失败返回 null。 */
function parseSemver(v) {
  const m = String(v ?? '').match(/^(\d+)\.(\d+)\.(\d+)/)
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null
}

/** 版本是否带 fetch 通道（v1.1.0+）。 */
function hasFetchChannel(ver) {
  const p = parseSemver(ver)
  if (!p) return null // 未知
  return p[0] > MIN_GOOD_MAJOR || (p[0] === MIN_GOOD_MAJOR && p[1] >= MIN_GOOD_MINOR)
}

// ─────────────────────────────────────────────────────────────────────────────

head('1. 定位 DSH_HOME')
const dshHome = String(process.env.DSH_HOME ?? '').trim() || path.join(os.homedir(), '.dsh')
if (!fs.existsSync(dshHome)) {
  bad(`DSH_HOME 不存在：${dshHome}`)
  info('说明 DSH 没装好，或环境变量 DSH_HOME 指错了。')
  process.exit(1)
}
ok(`DSH_HOME = ${dshHome}`)

head('2. 列出所有 profile')
const profilesDir = path.join(dshHome, 'profiles')
if (!fs.existsSync(profilesDir)) {
  bad(`没有 profiles 目录：${profilesDir}`)
  process.exit(1)
}
const profiles = fs
  .readdirSync(profilesDir, { withFileTypes: true })
  .filter((d) => d.isDirectory())
  .map((d) => d.name)
ok(`发现 profile：${profiles.join(' / ') || '(空)'}`)

// ── 3. 本插件装在哪、什么版本 ★最重要的一步 ────────────────────────────────
head('3. 本插件安装情况（★先看这一步）')
const installed = []
for (const pf of profiles) {
  const dir = path.join(profilesDir, pf, 'node_modules', PKG_NAME)
  if (!fs.existsSync(dir)) continue

  console.log(`\n  [${pf}]`)
  let ver = 'unknown'
  try {
    ver = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).version ?? 'unknown'
  } catch {}
  installed.push({ pf, dir, ver })

  const good = hasFetchChannel(ver)
  if (good === true) {
    ok(`版本 ${ver} —— 含 fetch 主通道 ✅`)
  } else if (good === false) {
    bad(`版本 ${ver} —— **太旧，没有 fetch 通道**`)
    info('v1.0.x 只支持 workbuddy 渠道，走 buddy/CodeBuddy 的用户完全不受益，')
    info('而且它依赖 OFM 的 pack.js 结构，版本不对就打不上钩子。')
    info('→ 请重装到 v1.1.4+：')
    info(`    dsh plugin --profile ${pf} remove ${PKG_NAME}`)
    info(`    dsh plugin --profile ${pf} add github:balongTTY/dsh-workbuddy-fix`)
  } else {
    warn('版本号无法解析，跳过版本判断')
  }

  // 关键文件是否齐全
  const must = ['index.js', 'client.js', 'src/fetch-hook.mjs', 'src/lexicon.mjs', 'package.json']
  const missing = must.filter((f) => !fs.existsSync(path.join(dir, f)))
  if (missing.length === 0) {
    ok(`关键文件齐全（${must.length} 个）`)
  } else {
    bad(`**文件缺失**：${missing.join(', ')}`)
    info('安装不完整。卸载后重装：')
    info(`    dsh plugin --profile ${pf} remove ${PKG_NAME}`)
    info(`    dsh plugin --profile ${pf} add github:balongTTY/dsh-workbuddy-fix`)
  }

  // package.json 的 dependencies 里不该有 @deepseek-ai/*（会遮蔽宿主包 → 启动崩溃）
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'))
    const deps = Object.keys(pkg.dependencies ?? {})
    const bad_ = deps.filter((d) => d.startsWith('@deepseek-ai/'))
    if (bad_.length > 0) {
      bad(`**依赖里含宿主核心包**：${bad_.join(', ')}`)
      info('这会让 pnpm 把旧版核心包平铺到 profile 根部，遮蔽 app.asar 内置版本，')
      info('典型症状是启动即崩（required plugin did not activate）。')
      info('→ 这是插件的 bug，请反馈给作者。')
    } else {
      ok('依赖声明干净（不含 @deepseek-ai/* 宿主包）')
    }
  } catch {}
}

if (installed.length === 0) {
  bad('**本插件根本没装**')
  info('→ 安装命令：')
  info('    <DSH目录>\\resources\\runtime\\cli\\bin\\dsh.cmd plugin --profile desktop add github:balongTTY/dsh-workbuddy-fix')
  info('  或从 Release 下 .tgz 附件后：')
  info('    ... add .\\balong-dsh-workbuddy-fix-1.1.4.tgz')
  process.exit(1)
}

// ── 4. bundle 注册（决定插件会不会被加载）────────────────────────────────────
head('4. bundle 注册状态')
for (const { pf } of installed) {
  const pkgFile = path.join(profilesDir, pf, 'package.json')
  try {
    const pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf8'))
    const bundles = pkg.dsh?.profile?.bundles ?? []
    if (bundles.includes(PKG_NAME)) {
      ok(`[${pf}] 已在 bundles 里，DSH 启动时会加载`)
    } else {
      bad(`[${pf}] **不在 bundles 里** → 即使装了也不会被加载`)
      info(`当前 bundles：${bundles.join(', ')}`)
      info('→ 重新执行一次安装命令即可补上。')
    }
  } catch {
    warn(`[${pf}] 读不到 profile 的 package.json`)
  }
}

// ── 5. 反代插件与 fetch 通道 ────────────────────────────────────────────────
head('5. WorkBuddy 反代插件（fetch 通道需要它发请求）')
/** 已知的 WB 反代插件包名。不是白名单 —— 只是给个提示，别的也能用。 */
const KNOWN_PROXIES = [
  'dsh-our-free-model',
  'dsh-connect-workbuddy',
  'dsh-xdpool',
  'dsh-workbuddy-hub',
  'dsh-workbuddy-bridge',
  '@axiaohungry/dsh-llm-workbuddy',
  '@shatyuka/dsh-llm-codebuddy',
]

for (const { pf } of installed) {
  console.log(`\n  [${pf}]`)
  const nm = path.join(profilesDir, pf, 'node_modules')
  const foundProxies = []
  for (const name of KNOWN_PROXIES) {
    const d = path.join(nm, name)
    if (fs.existsSync(d)) {
      let v = '?'
      try {
        v = JSON.parse(fs.readFileSync(path.join(d, 'package.json'), 'utf8')).version
      } catch {}
      foundProxies.push(`${name}@${v}`)
    }
  }
  if (foundProxies.length > 0) {
    ok(`发现反代插件：${foundProxies.join(', ')}`)
  } else {
    warn('没发现已知的 WB 反代插件')
    info('如果你用的是其它反代插件，忽略这条 —— 只要它用 fetch 发')
    info('chat/completions 请求，本插件就能拦住。')
  }

  // OFM 是否已装（旧兜底通道需要它）
  const ofmDir = path.join(nm, 'dsh-our-free-model')
  if (fs.existsSync(ofmDir)) {
    info('（检测到 OFM，pack.js 兜底通道可能可用）')
  }
}

// ── 6. pack.js 兜底通道（可选）─────────────────────────────────────────────
head('6. pack.js 兜底通道（可选，不是主功能）')
console.log('  ℹ️  v1.1.0 起主通道是 fetch 层拦截，**不依赖 pack.js**。')
console.log('      下面这些只影响「不走 globalThis.fetch 的请求」能否被兜住。')

let checkedPack = 0
for (const { pf } of installed) {
  const packFile = path.join(profilesDir, pf, 'node_modules', 'dsh-our-free-model', 'vendor', 'channel-pack', 'pack.js')
  if (!fs.existsSync(packFile)) continue
  checkedPack += 1

  console.log(`\n  [${pf}]`)
  const text = fs.readFileSync(packFile, 'utf8')
  const markers = count(text, MARKER)
  const anchors = count(text, ANCHOR)
  const ofmVer = readOfmVersion(packFile)

  info(`OFM 版本：${ofmVer}，pack.js ${(fs.statSync(packFile).size / 1024 / 1024).toFixed(2)} MB`)
  if (markers > 0) {
    ok(`兜底钩子已在位（${MARKER} × ${markers}）`)
  } else {
    info(`兜底钩子未打上（${MARKER} × 0）—— 不影响主功能`)
  }
  if (anchors === 1) {
    ok('锚点匹配（OFM 结构可识别）')
  } else if (anchors === 0) {
    info('锚点不存在 → OFM 版本不在支持区间 [v2.5.2, v2.5.7]')
    info('这是产品决策不是 bug，详见 README「已知边界」节。')
  }
}

if (checkedPack === 0) {
  info('\n  未安装 dsh-our-free-model，pack.js 通道不适用。')
  info('  如果你用的是其它反代插件 —— 这正是 v1.1.x 的设计目标：不需要它。')
}

// ── 7. 结论 ────────────────────────────────────────────────────────────────
head('7. 结论')

const newest = installed
  .map((x) => ({ ...x, sv: parseSemver(x.ver) }))
  .filter((x) => x.sv)
  .sort((a, b) => b.sv[0] - a.sv[0] || b.sv[1] - a.sv[1] || b.sv[2] - a.sv[2])[0]

if (!newest) {
  warn('版本号都解析不出来，无法给结论。请把上面的输出贴给开发者。')
} else if (hasFetchChannel(newest.ver)) {
  ok(`安装的是 v${newest.ver}，含 fetch 主通道。`)
  console.log('')
  console.log('  👉 最终确认方法：打开 DSH 的「设置 → wb400修复」面板，')
  console.log('     顶部应显示 **「主通道已接管（fetch 层）」**。')
  console.log('     看到这行 = 一切正常；没有这行 = 装的还是旧版。')
  console.log('')
  console.log('     发几条对话后，面板的「介入次数 / 改写处数」应该增长。')
  console.log('     这两个数字只可能来自真实请求，是最硬的证据。')
} else {
  bad(`安装的是 v${newest.ver}，**没有 fetch 主通道**，对多数用户无效。`)
  console.log('')
  console.log('  👉 请重装到 v1.1.4+：')
  console.log(`     dsh plugin --profile ${newest.pf} remove ${PKG_NAME}`)
  console.log(`     dsh plugin --profile ${newest.pf} add github:balongTTY/dsh-workbuddy-fix`)
}

console.log('')
console.log('  遇到问题请带这三项去反馈：')
console.log('    1. 本脚本的完整输出')
console.log('    2. 报错前缀是 `buddy:` 还是 `workbuddy:`')
console.log('    3. 面板截图（或是否有「主通道已接管（fetch 层）」这行）')
console.log('')

/**
 * 从 pack.js 的绝对路径推 OFM 版本。
 * 目录结构：<ofm>/vendor/channel-pack/pack.js  →  <ofm>/package.json
 * 所以从「包含 pack.js 的目录」往上 3 级才是 package.json。
 * （早期版本这里只上跳 2 级，导致永远返回 unknown。）
 */
function readOfmVersion(packFilePath) {
  try {
    const ofmDir = path.resolve(path.dirname(packFilePath), '..', '..')
    const pkg = JSON.parse(fs.readFileSync(path.join(ofmDir, 'package.json'), 'utf8'))
    return pkg.version ?? 'unknown'
  } catch {
    return 'unknown'
  }
}
