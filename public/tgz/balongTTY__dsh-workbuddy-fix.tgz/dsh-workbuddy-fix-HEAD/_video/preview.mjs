/**
 * 单帧预览 —— 只渲染指定的几帧，用来快速验证布局。
 * 用法：node _video/preview.mjs 45 240 420 600
 */
import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const W = 1920, H = 1080
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'
const CDP_PORT = 9402
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const frames = process.argv.slice(2).map(Number).filter((n) => Number.isFinite(n))
if (frames.length === 0) { console.error('用法: node preview.mjs <帧号...>'); process.exit(1) }

// 复用 render.mjs 的页面构建逻辑
const tpl = fs.readFileSync(path.join(__dirname, 'stage.html'), 'utf8')
const shotPath = path.join(ROOT, '_out', 'ui-panel2.png')
const dataUrl = 'data:image/png;base64,' + fs.readFileSync(shotPath).toString('base64')
const built = tpl.replace('<script>', `<script>window.__SHOT_DATA_URL__=${JSON.stringify(dataUrl)};</script>\n<script>`)
const pagePath = path.join(__dirname, 'out', 'stage.preview.html')
fs.mkdirSync(path.dirname(pagePath), { recursive: true })
fs.writeFileSync(pagePath, built, 'utf8')

const userDataDir = path.join(process.env.TEMP || '/tmp', 'wb400-preview-profile')
fs.rmSync(userDataDir, { recursive: true, force: true })
const proc = spawn(EDGE, [
  '--headless=new', `--remote-debugging-port=${CDP_PORT}`,
  `--user-data-dir=${userDataDir}`, '--no-first-run', '--hide-scrollbars',
  `--window-size=${W},${H}`, 'about:blank',
], { stdio: 'ignore' })

let page
for (let i = 0; i < 60; i += 1) {
  try {
    const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json()
    page = list.find((t) => t.type === 'page')
    if (page) break
  } catch { /* wait */ }
  await sleep(250)
}
if (!page) { proc.kill(); throw new Error('CDP 未就绪') }

const ws = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej })
let id = 0
const pending = new Map()
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data)
  if (m.id && pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result) }
}
const send = (method, params = {}) => new Promise((resolve, reject) => {
  const i = ++id; pending.set(i, { resolve, reject }); ws.send(JSON.stringify({ id: i, method, params }))
})

await send('Page.enable'); await send('Runtime.enable')
await send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 1, mobile: false })
await send('Page.navigate', { url: pathToFileURL(pagePath).href })
await sleep(1500)

for (const f of frames) {
  await send('Runtime.evaluate', { expression: `window.renderAt(${f})`, returnByValue: true })
  await sleep(80)
  const shot = await send('Page.captureScreenshot', { format: 'png' })
  const out = path.join(__dirname, `preview-${f}.png`)
  fs.writeFileSync(out, Buffer.from(shot.data, 'base64'))
  console.log('✅', out)
}

ws.close(); proc.kill()
