/**
 * 把你自己找的背景音乐混进成片。
 *
 * 用法：
 *   1. 把音乐文件放进 _video/bgm/（支持 mp3 / m4a / wav / flac / ogg / aac / opus）
 *   2. node _video/mix-bgm.mjs
 *
 * 它会自动做这几件事（都是「讲解视频配乐」必须的）：
 *   - 音量压低到背景级（默认 -26 LUFS 附近），不会盖过画面理解
 *   - 首尾淡入淡出（2s / 3.5s），避免突然起停
 *   - 循环补齐或裁剪到视频长度（音乐短了就 loop，长了就淡出截断）
 *   - 视频流直接复制（-c:v copy），不重新编码，几秒完成
 *
 * 想调音量：改下面的 MUSIC_GAIN_DB（负值更轻）。默认 -18 dB。
 * 换成无配乐版：node _video/mix-bgm.mjs --mute
 */

import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const BGM_DIR = path.join(__dirname, 'bgm')
const SRC_MP4 = path.join(__dirname, 'wb400-intro.mp4')
const TMP_MP4 = path.join(__dirname, 'wb400-intro.mixed.mp4')
const FFMPEG = path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', 'ffmpeg.exe')
const FFPROBE = path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', 'ffprobe.exe')
const ff = fs.existsSync(FFMPEG) ? FFMPEG : 'ffmpeg'
const ffprobe = fs.existsSync(FFPROBE) ? FFPROBE : 'ffprobe'

/** 音乐相对画面压低多少 dB。讲解视频一般 -16 ~ -22，越负越轻。 */
const MUSIC_GAIN_DB = -8
/** 从音乐的第几秒开始取（0 = 从头）。用于跳过过于安静的前奏。 */
const MUSIC_START_AT = Number(process.env.BGM_START || 0)
const FADE_IN = 2.0
const FADE_OUT = 3.5

const AUDIO_EXT = new Set(['.mp3', '.m4a', '.wav', '.flac', '.ogg', '.aac', '.opus', '.wma'])

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] })
    let out = ''
    let err = ''
    p.stdout.on('data', (d) => { out += d })
    p.stderr.on('data', (d) => { err += d })
    p.on('error', reject)
    p.on('close', (code) => code === 0 ? resolve(out) : reject(new Error(err.split('\n').slice(-6).join('\n'))))
  })
}

function probeDuration(file) {
  return run(ffprobe, [
    '-v', 'error', '-show_entries', 'format=duration',
    '-of', 'default=noprint_wrappers=1:nokey=1', file,
  ]).then((s) => parseFloat(s.trim()))
}

/* ------------------------------------------------------------------ */

async function main() {
  const mute = process.argv.includes('--mute')

  if (!fs.existsSync(SRC_MP4)) {
    throw new Error(`找不到源视频：${SRC_MP4}\n先跑 node _video/render.mjs`)
  }

  const videoDur = await probeDuration(SRC_MP4)
  console.log(`源视频: ${videoDur.toFixed(2)} 秒`)

  /* ---------- 无配乐版 ---------- */
  if (mute) {
    console.log('\n模式: 无配乐')
    const outNoAudio = path.join(__dirname, 'wb400-intro.silent.mp4')
    await run(ff, [
      '-y', '-i', SRC_MP4,
      '-c:v', 'copy', '-an',
      '-movflags', '+faststart', outNoAudio,
    ])
    console.log(`✅ ${outNoAudio}`)
    return
  }

  /* ---------- 找音乐文件 ---------- */
  fs.mkdirSync(BGM_DIR, { recursive: true })
  const files = fs.readdirSync(BGM_DIR)
    .filter((f) => AUDIO_EXT.has(path.extname(f).toLowerCase()))
    .map((f) => path.join(BGM_DIR, f))

  if (files.length === 0) {
    console.log(`\n⚠️  ${BGM_DIR} 里没有音频文件。`)
    console.log('   把音乐放进去再跑一次；或加 --mute 出无配乐版。')
    console.log(`   支持的格式: ${[...AUDIO_EXT].join(' ')}`)
    process.exit(1)
  }
  if (files.length > 1) {
    console.log(`\n⚠️  发现 ${files.length} 个音频文件，只用第一个：${path.basename(files[0])}`)
    files.forEach((f, i) => console.log(`   ${i === 0 ? '▶' : ' '} ${path.basename(f)}`))
  }

  const music = files[0]
  const musicDur = await probeDuration(music)
  console.log(`音乐: ${path.basename(music)}  (${musicDur.toFixed(2)} 秒)`)

  /* ---------- 组装滤镜 ---------- */
  // 音乐比视频短 → loop 补齐；比视频长 → 靠 -shortest 截断
  const needLoop = musicDur < videoDur - 0.5
  if (needLoop) {
    console.log(`  → 音乐比视频短，循环补齐（${Math.ceil(videoDur / musicDur)} 遍）`)
  }

  const fadeOutStart = Math.max(0, videoDur - FADE_OUT)
  const af = [
    // 循环时每次接缝会有咔哒声，用一个极短的交叉淡化抹掉
    `volume=${MUSIC_GAIN_DB}dB`,
    `afade=t=in:st=0:d=${FADE_IN}`,
    `afade=t=out:st=${fadeOutStart.toFixed(2)}:d=${FADE_OUT}`,
    // 保险：拉齐采样率，避免某些 mp3 是 48k 导致音画不同步的观感
    'aresample=44100',
  ].join(',')

  const args = ['-y']
  if (MUSIC_START_AT > 0 && !needLoop) args.push('-ss', String(MUSIC_START_AT))
  if (needLoop) args.push('-stream_loop', '-1')
  args.push('-i', music)
  args.push('-i', SRC_MP4)
  args.push(
    '-filter_complex', `[0:a]${af}[a]`,
    '-map', '1:v:0', '-map', '[a]',
    '-c:v', 'copy',
    '-c:a', 'aac', '-b:a', '192k',
    '-shortest',
    '-movflags', '+faststart',
    TMP_MP4,
  )

  console.log(`\n混音中（画面不重编码，很快）…`)
  await run(ff, args)

  // 音量核对
  const volOut = await run(ff, ['-hide_banner', '-i', TMP_MP4, '-af', 'volumedetect', '-f', 'null', 'NUL'])
  const mean = /mean_volume:\s*([-\d.]+)\s*dB/.exec(volOut)
  const max = /max_volume:\s*([-\d.]+)\s*dB/.exec(volOut)
  if (mean && max) {
    console.log(`\n音量: 平均 ${mean[1]} dB / 峰值 ${max[1]} dB`)
    const m = parseFloat(mean[1])
    if (m > -18) console.log('  ⚠️  偏响，可能盖住画面。把 MUSIC_GAIN_DB 调更负（如 -24）')
    else if (m < -34) console.log('  ⚠️  偏轻，几乎听不见。把 MUSIC_GAIN_DB 调大（如 -14）')
    else console.log('  ✓ 在背景音乐合理区间')
  }

  fs.renameSync(TMP_MP4, SRC_MP4)
  const size = (fs.statSync(SRC_MP4).size / 1048576).toFixed(2)
  console.log(`\n✅ 已覆盖 ${SRC_MP4}  (${size} MB)`)

  // 有配乐就同步刷新 README 用的 gif 里没有音频，无需重生成；
  // 但 mp4 变了，release 附件要重新传（见 README 的发布步骤）
  console.log('\n下一步：')
  console.log('  git add -A && git commit -m "video: 换配乐" && git push')
  console.log('  gh release upload v1.0.0 _video/wb400-intro.mp4 --clobber')
}

main().catch((e) => {
  console.error('\n❌ 失败:', e.message)
  process.exit(1)
})
