/**
 * 逐帧渲染器 —— 纯 CDP（Chrome DevTools Protocol）+ ffmpeg，零第三方依赖。
 *
 * 为什么不用 Remotion / HyperFrames：
 *   两者都要装成吨的 node_modules（React + 渲染器）。这个插件的定位就是「轻、
 *   零依赖」，给它的介绍视频也不该引入一大堆东西。而它们底层做的事情其实一样：
 *   **写代码做动画 → 无头浏览器按帧截图 → ffmpeg 合成**。这里把中间那层省掉，
 *   直接自己驱动，20 秒视频约 730 帧，完全跑得动。
 *
 * 用法：
 *   node _video/render.mjs
 * 产物：
 *   _video/out/frames/*.png      逐帧
 *   _video/wb400-intro.mp4       成片
 */

import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')

const W = 1920
const H = 1080
const FPS = 30

const FRAMES_DIR = path.join(__dirname, 'out', 'frames')
const OUT_MP4 = path.join(ROOT, '_video', 'wb400-intro.mp4')
const BGM_WAV = path.join(__dirname, 'bgm.wav')
const OUT_GIF = path.join(ROOT, '_video', 'wb400-intro.gif')

const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'
const CDP_PORT = Number(process.env.CDP_PORT || 9401)

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

/* ------------------------------------------------------------------ *
 * 1. 准备：清帧目录、把面板截图内联进页面
 * ------------------------------------------------------------------ */

function prepareFramesDir() {
  fs.rmSync(FRAMES_DIR, { recursive: true, force: true })
  fs.mkdirSync(FRAMES_DIR, { recursive: true })
  console.log('帧目录:', FRAMES_DIR)
}

/** 把真实面板截图转成 data URL，避免 file:// 下跨目录读取被拦 */
function buildPage() {
  const tpl = fs.readFileSync(path.join(__dirname, 'stage.html'), 'utf8')
  const shotPath = path.join(ROOT, '_out', 'ui-panel2.png')
  if (!fs.existsSync(shotPath)) {
    throw new Error(`缺少面板截图：${shotPath}（先跑一遍 UI 验证脚本）`)
  }
  const b64 = fs.readFileSync(shotPath).toString('base64')
  const dataUrl = `data:image/png;base64,${b64}`
  const injected = tpl.replace(
    '<script>',
    `<script>window.__SHOT_DATA_URL__ = ${JSON.stringify(dataUrl)};</script>\n<script>`,
  )
  const outPath = path.join(__dirname, 'out', 'stage.build.html')
  fs.mkdirSync(path.dirname(outPath), { recursive: true })
  fs.writeFileSync(outPath, injected, 'utf8')
  return outPath
}

/* ------------------------------------------------------------------ *
 * 2. CDP 客户端（Node 25 自带全局 WebSocket，无需 ws 包）
 * ------------------------------------------------------------------ */

async function launchEdge() {
  const userDataDir = path.join(process.env.TEMP || '/tmp', 'wb400-video-profile')
  fs.rmSync(userDataDir, { recursive: true, force: true })
  const proc = spawn(EDGE, [
    '--headless=new',
    `--remote-debugging-port=${CDP_PORT}`,
    `--user-data-dir=${userDataDir}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-extensions',
    '--hide-scrollbars',
    '--force-device-scale-factor=1',
    `--window-size=${W},${H}`,
    'about:blank',
  ], { stdio: 'ignore' })

  // 等 CDP 端口就绪
  for (let i = 0; i < 60; i += 1) {
    try {
      const r = await fetch(`http://127.0.0.1:${CDP_PORT}/json/version`)
      if (r.ok) return { proc, version: await r.json() }
    } catch { /* not up yet */ }
    await sleep(250)
  }
  throw new Error('Edge CDP 未在 15 秒内就绪')
}

async function connectPage() {
  const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json()
  const page = list.find((t) => t.type === 'page')
  if (!page) throw new Error('找不到 page target')
  const ws = new WebSocket(page.webSocketDebuggerUrl)
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej })

  let nextId = 0
  const pending = new Map()
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id)
      pending.delete(msg.id)
      if (msg.error) reject(new Error(JSON.stringify(msg.error)))
      else resolve(msg.result)
    }
  }

  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++nextId
    pending.set(id, { resolve, reject })
    ws.send(JSON.stringify({ id, method, params }))
  })

  return { ws, send }
}

const evaluate = async (send, expression) => {
  const r = await send('Runtime.evaluate', {
    expression, returnByValue: true, awaitPromise: true,
  })
  if (r.exceptionDetails) {
    throw new Error('页面执行出错: ' + JSON.stringify(r.exceptionDetails).slice(0, 300))
  }
  return r.result?.value
}

/* ------------------------------------------------------------------ *
 * 3. 主流程
 * ------------------------------------------------------------------ */

async function main() {
  prepareFramesDir()
  const pagePath = buildPage()
  console.log('页面:', pagePath)

  const { proc, version } = await launchEdge()
  console.log('浏览器:', version.Browser)

  const { ws, send } = await connectPage()

  try {
    await send('Page.enable')
    await send('Runtime.enable')

    // 固定视口，保证 1920×1080 且不受窗口装饰影响
    await send('Emulation.setDeviceMetricsOverride', {
      width: W, height: H, deviceScaleFactor: 1, mobile: false,
    })

    await send('Page.navigate', { url: pathToFileURL(pagePath).href })
    // 等页面与字体就绪
    await sleep(1200)

    const total = await evaluate(send, 'window.TOTAL_FRAMES')
    const fps = await evaluate(send, 'window.FPS')
    if (!total) throw new Error('页面没有暴露 TOTAL_FRAMES')
    console.log(`总帧数: ${total} @ ${fps}fps  (${(total / fps).toFixed(1)} 秒)`)

    // 确认字体已加载，避免首帧字体闪变
    await evaluate(send, 'document.fonts ? document.fonts.ready.then(()=>true) : true')

    const t0 = Date.now()
    for (let f = 0; f < total; f += 1) {
      const info = await evaluate(send, `window.renderAt(${f})`)
      const shot = await send('Page.captureScreenshot', {
        format: 'png',
        captureBeyondViewport: false,
      })
      const name = String(f).padStart(5, '0') + '.png'
      fs.writeFileSync(path.join(FRAMES_DIR, name), Buffer.from(shot.data, 'base64'))

      if (f % 30 === 0 || f === total - 1) {
        const el = ((Date.now() - t0) / 1000).toFixed(1)
        const pct = ((f + 1) / total * 100).toFixed(0)
        console.log(`  帧 ${f + 1}/${total} (${pct}%)  ${el}s  场景=${info?.scene ?? '?'}`)
      }
    }

    console.log(`\n截图完成，用时 ${((Date.now() - t0) / 1000).toFixed(1)}s`)
  } finally {
    try { ws.close() } catch { /* ignore */ }
    try { proc.kill() } catch { /* ignore */ }
  }

  /* ---------- ffmpeg 合成 ---------- */
  await encode()
}

function run(cmd, args, label) {
  return new Promise((resolve, reject) => {
    console.log(`\n$ ${label || cmd} ${args.join(' ')}`)
    const p = spawn(cmd, args, { stdio: 'inherit' })
    p.on('error', reject)
    p.on('close', (code) => code === 0 ? resolve() : reject(new Error(`${cmd} 退出码 ${code}`)))
  })
}

async function encode() {
  const FFMPEG = path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', 'ffmpeg.exe')
  const ff = fs.existsSync(FFMPEG) ? FFMPEG : 'ffmpeg'

  // H.264 MP4：网络/微信分享友好
  // 有 bgm.wav 就混音（-shortest 保证以视频长度收尾），没有就出无声版
  const hasBgm = fs.existsSync(BGM_WAV)
  const mp4Args = [
    '-y',
    '-framerate', String(FPS),
    '-i', path.join(FRAMES_DIR, '%05d.png'),
  ]
  if (hasBgm) {
    mp4Args.push('-i', BGM_WAV)
    mp4Args.push('-map', '0:v:0', '-map', '1:a:0')
  }
  mp4Args.push(
    '-c:v', 'libx264',
    '-preset', 'slow',
    '-crf', '18',
    '-pix_fmt', 'yuv420p',
  )
  if (hasBgm) {
    mp4Args.push('-c:a', 'aac', '-b:a', '192k', '-shortest')
  }
  mp4Args.push('-movflags', '+faststart', OUT_MP4)
  await run(ff, mp4Args, hasBgm ? 'ffmpeg(mp4+bgm)' : 'ffmpeg(mp4, 无声)')

  const mp4Size = (fs.statSync(OUT_MP4).size / 1048576).toFixed(2)
  console.log(`\n✅ ${OUT_MP4}  (${mp4Size} MB)`)

  // GIF：README 里能直接动图展示，15fps 降采样控制体积
  await run(ff, [
    '-y',
    '-framerate', String(FPS),
    '-i', path.join(FRAMES_DIR, '%05d.png'),
    '-vf', 'fps=15,scale=960:-1:flags=lanczos,split[a][b];[a]palettegen=max_colors=128[p];[b][p]paletteuse=dither=bayer:bayer_scale=3',
    '-loop', '0',
    OUT_GIF,
  ], 'ffmpeg(gif)')

  const gifSize = (fs.statSync(OUT_GIF).size / 1048576).toFixed(2)
  console.log(`✅ ${OUT_GIF}  (${gifSize} MB)`)
}

main().catch((err) => {
  console.error('\n❌ 渲染失败:', err.message)
  process.exit(1)
})
