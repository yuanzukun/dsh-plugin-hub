/**
 * 发布博客到 blog.balong.in（Halo 2.25）
 *
 * Halo 2.x 的正文不在 Post 里，而在 Snapshot 里，且 Snapshot 通过 subjectRef
 * 反向指回 Post —— 所以顺序必须是：
 *
 *   ① POST /posts         创建 Post（只有元数据，正文为空）
 *   ② POST /snapshots     创建 Snapshot（正文在这里，subjectRef 指向 ① 的 name）
 *   ③ PUT  /posts/<name>  把 spec.headSnapshot / baseSnapshot / releaseSnapshot
 *                         都指向 ② 的 name
 *   ④ PUT  /posts/<name>/publish   发布
 *
 * 直接给 Post 传 content/html 会被静默忽略或 500 —— 我踩过。
 *
 * 用法：
 *   $env:HALO_USER="..."; $env:HALO_PASS="..."; node _video/publish-halo.mjs
 *   默认 dry-run，加 --publish 才落库。
 */

import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')

const BASE = 'https://blog.balong.in'
const PUBLISH = process.argv.includes('--publish')

const USER = process.env.HALO_USER
const PASS = process.env.HALO_PASS
if (!USER || !PASS) {
  console.error('请先设置 HALO_USER / HALO_PASS')
  process.exit(1)
}

/* ------------------------------------------------------------------ *
 * 登录：RSA 加密密码 + CSRF
 * ------------------------------------------------------------------ */

function publicKeyToPem(rawB64) {
  // 登录页里是 JS 字符串字面量，斜杠被转义成 \/ —— 不还原会报
  // error:1E08010C:DECODER routines::unsupported
  const b64 = rawB64.split('\\/').join('/').replace(/[^A-Za-z0-9+/=]/g, '')
  return `-----BEGIN PUBLIC KEY-----\n${b64.match(/.{1,64}/g).join('\n')}\n-----END PUBLIC KEY-----\n`
}

function rsaEncrypt(plain, rawB64) {
  return crypto.publicEncrypt(
    { key: publicKeyToPem(rawB64), padding: crypto.constants.RSA_PKCS1_PADDING },
    Buffer.from(plain, 'utf8'),
  ).toString('base64')
}

const getSetCookies = (res) =>
  typeof res.headers.getSetCookie === 'function'
    ? res.headers.getSetCookie()
    : (res.headers.get('set-cookie') || '').split(/,(?=[^;]+=)/)

async function login() {
  const pageRes = await fetch(`${BASE}/login`, { redirect: 'manual' })
  const html = await pageRes.text()
  const jar = getSetCookies(pageRes).map((c) => c.split(';')[0])

  const pk = html.match(/const publicKey = "([^"]+)"/)?.[1]
  const csrf = html.match(/name="_csrf" value="([^"]+)"/)?.[1]
  if (!pk || !csrf) throw new Error('登录页结构变了，没找到 publicKey/_csrf')

  const body = new URLSearchParams({
    _csrf: csrf,
    username: USER,
    password: rsaEncrypt(PASS, pk),
    'remember-me': 'true',
  })

  const res = await fetch(`${BASE}/login`, {
    method: 'POST',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      cookie: jar.join('; '),
      origin: BASE,
      referer: `${BASE}/login`,
    },
    body: body.toString(),
    redirect: 'manual',
  })

  const loc = res.headers.get('location') || ''
  if (loc.includes('error') || loc.includes('/login')) {
    throw new Error(`登录失败（→ ${loc}），账号或密码不对`)
  }
  const cookie = [...jar, ...getSetCookies(res).map((c) => c.split(';')[0])].join('; ')
  console.log(`登录成功 → ${loc}`)
  return cookie
}

/* ------------------------------------------------------------------ *
 * API 封装
 * ------------------------------------------------------------------ */

function api(cookie) {
  const call = async (method, path, body) => {
    const res = await fetch(BASE + path, {
      method,
      headers: { 'content-type': 'application/json', cookie, accept: 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    const text = await res.text()
    let json = null
    try { json = JSON.parse(text) } catch { /* 非 JSON */ }
    if (!res.ok) {
      const detail = json?.detail || json?.title || text.slice(0, 300)
      throw new Error(`${method} ${path} → HTTP ${res.status}\n${detail}`)
    }
    return json
  }
  return { call }
}

/* ------------------------------------------------------------------ *
 * frontmatter 解析
 * ------------------------------------------------------------------ */

function parseFrontmatter(md) {
  const m = md.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/)
  if (!m) throw new Error('缺少 frontmatter')
  const meta = {}
  for (const line of m[1].split(/\r?\n/)) {
    const kv = line.match(/^(\w+):\s*(.*)$/)
    if (!kv) continue
    let v = kv[2].trim()
    if (v.startsWith('[') && v.endsWith(']')) {
      v = v.slice(1, -1).split(',').map((s) => s.trim()).filter(Boolean)
    } else if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
      v = v.slice(1, -1)
    }
    meta[kv[1]] = v
  }
  return { meta, body: m[2] }
}

/** 极简 markdown → HTML（Halo 的 content 字段接受 HTML，rawType=html） */
function mdToHtml(md) {
  const lines = md.split(/\r?\n/)
  const out = []
  let inCode = false
  let codeBuf = []
  let listBuf = []
  let tableBuf = []

  const flushList = () => {
    if (listBuf.length) {
      out.push('<ul>\n' + listBuf.map((li) => `  <li>${li}</li>`).join('\n') + '\n</ul>')
      listBuf = []
    }
  }
  const flushTable = () => {
    if (!tableBuf.length) return
    const rows = tableBuf.filter((r) => !/^\|[\s:|-]+\|$/.test(r))
    const cells = rows.map((r) => r.replace(/^\||\|$/g, '').split('|').map((c) => c.trim()))
    if (cells.length) {
      const head = cells[0]
      const body = cells.slice(1)
      let html = '<table>\n<thead>\n<tr>' + head.map((c) => `<th>${inline(c)}</th>`).join('') + '</tr>\n</thead>\n<tbody>\n'
      for (const row of body) {
        html += '<tr>' + row.map((c) => `<td>${inline(c)}</td>`).join('') + '</tr>\n'
      }
      html += '</tbody>\n</table>'
      out.push(html)
    }
    tableBuf = []
  }

  const inline = (s) => s
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>')

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i]

    if (line.startsWith('```')) {
      if (!inCode) { inCode = true; codeBuf = []; continue }
      inCode = false
      out.push('<pre><code>' + codeBuf.join('\n').replace(/</g, '&lt;') + '</code></pre>')
      continue
    }
    if (inCode) { codeBuf.push(line); continue }

    if (/^\|/.test(line)) { flushList(); tableBuf.push(line); continue }
    flushTable()

    if (/^\s*[-*]\s+/.test(line)) { listBuf.push(inline(line.replace(/^\s*[-*]\s+/, ''))); continue }
    flushList()

    if (!line.trim()) { continue }

    const h = line.match(/^(#{1,6})\s+(.*)$/)
    if (h) { out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`); continue }

    if (/^>\s?/.test(line)) { out.push(`<blockquote><p>${inline(line.replace(/^>\s?/, ''))}</p></blockquote>`); continue }
    if (/^---+$/.test(line)) { out.push('<hr>'); continue }

    out.push(`<p>${inline(line)}</p>`)
  }
  flushList(); flushTable()
  if (inCode && codeBuf.length) out.push('<pre><code>' + codeBuf.join('\n') + '</code></pre>')

  return out.join('\n')
}

/* ------------------------------------------------------------------ *
 * 主流程
 * ------------------------------------------------------------------ */

async function main() {
  const cookie = await login()
  const { call } = api(cookie)

  const raw = fs.readFileSync(path.join(ROOT, 'docs', 'blog-400-fix.md'), 'utf8')
  const { meta, body } = parseFrontmatter(raw)
  console.log(`草稿：${meta.title}`)
  console.log(`  正文 ${body.length} 字符（markdown，交给 Halo 自己渲染）`)

  // 查重：同一 slug 已存在就不重复发
  const existing = await call('GET', '/apis/api.console.halo.run/v1alpha1/posts?page=0&size=50')
  const dup = (existing.items || []).find((it) => it.post?.spec?.slug === meta.slug)
  if (dup) {
    console.log(`\n⚠️  已存在同 slug 的文章：${dup.post.spec.title}`)
    console.log(`   name=${dup.post.metadata.name}`)
    console.log(`   地址：${BASE}/archives/${dup.post.spec.slug}`)
    if (!process.argv.includes('--force')) {
      console.log('\n未做任何修改。要覆盖请加 --force（会另发一篇同 slug 的）。')
      return
    }
  }

  const postName = crypto.randomUUID()
  const snapName = crypto.randomUUID()
  const now = new Date().toISOString()

  // ① Post（只放元数据）
  const post = {
    apiVersion: 'content.halo.run/v1alpha1',
    kind: 'Post',
    metadata: {
      name: postName,
      annotations: {
        'content.halo.run/preferred-editor': 'default',
        'content.halo.run/permalink-pattern': '/archives/{slug}',
      },
      labels: {},
    },
    spec: {
      title: meta.title,
      slug: meta.slug,
      categories: [],
      tags: [],
      owner: USER,
      cover: '',
      deleted: false,
      publish: false,
      pinned: false,
      allowComment: true,
      visible: 'PUBLIC',
      priority: 0,
      publishTime: now,
      template: '',
      htmlMetas: [],
      excerpt: { autoGenerate: true, raw: '' },
      baseSnapshot: '',
      headSnapshot: '',
      releaseSnapshot: '',
    },
  }

  // ② Snapshot（正文，subjectRef 指回 Post）
  const snapshot = {
    apiVersion: 'content.halo.run/v1alpha1',
    kind: 'Snapshot',
    metadata: {
      name: snapName,
      annotations: { 'content.halo.run/keep-raw': 'true' },
    },
    spec: {
      // ⚠️ 实测结论：Halo 2.25 不会在服务端把 markdown 渲染成 HTML。
      // 只给 rawPatch 的话页面正文是空的（contentPatch 长度为 0）。
      // 必须客户端自己渲染好塞进 contentPatch —— 编辑器也是这么做的。
      rawType: 'markdown',
      rawPatch: body,
      contentPatch: mdToHtml(body),
      parentSnapshotName: '',
      owner: USER,
      contributors: [USER],
      lastModifyTime: now,
      subjectRef: {
        group: 'content.halo.run',
        version: 'v1alpha1',
        kind: 'Post',
        name: postName,
      },
    },
  }

  if (!PUBLISH) {
    console.log('\n[DRY-RUN] 不落库。计划：')
    console.log(`  Post.name     = ${postName}`)
    console.log(`  Snapshot.name = ${snapName}`)
    console.log(`  title         = ${post.spec.title}`)
    console.log(`  slug          = ${post.spec.slug}`)
    console.log(`  rawType       = ${snapshot.spec.rawType}`)
    console.log(`  rawPatch      = ${snapshot.spec.rawPatch.length} 字符`)
    console.log('\n加 --publish 真正发布。')
    return
  }

  console.log('\n① 创建 Post…')
  await call('POST', '/apis/content.halo.run/v1alpha1/posts', post)
  console.log('   OK')

  console.log('② 创建 Snapshot（正文）…')
  const created = await call('POST', '/apis/content.halo.run/v1alpha1/snapshots', snapshot)
  console.log(`   OK  name=${created?.metadata?.name}`)

  console.log('③ 把 Post 指向 Snapshot…')
  // ⚠️ 必须重新读一次拿最新 metadata.version —— 拿 POST 时的旧对象直接 PUT 会 500。
  // 这是本次排查最耗时的一步（POST 成功、Snapshot 成功、只有这一步 500）。
  const fresh = await call('GET', `/apis/content.halo.run/v1alpha1/posts/${postName}`)
  fresh.spec.baseSnapshot = snapName
  fresh.spec.headSnapshot = snapName
  fresh.spec.releaseSnapshot = snapName
  fresh.spec.publish = true
  fresh.spec.publishTime = new Date().toISOString()
  await call('PUT', `/apis/content.halo.run/v1alpha1/posts/${postName}`, fresh)
  console.log('   OK')

  console.log('④ 发布…')
  try {
    await call('PUT', `/apis/api.console.halo.run/v1alpha1/posts/${postName}/publish`)
    console.log('   OK')
  } catch (e) {
    console.log(`   publish 接口返回：${e.message.split('\n')[0]}（Post 已带 publish=true，多半已生效）`)
  }

  console.log(`\n✅ 完成：${BASE}/archives/${meta.slug}`)
}

main().catch((e) => {
  console.error('\n❌', e.message)
  process.exit(1)
})
