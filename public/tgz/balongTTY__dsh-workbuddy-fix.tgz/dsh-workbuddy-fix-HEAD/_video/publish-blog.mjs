/**
 * 把博客草稿发布到 blog.balong.in（Halo 2.25.4）
 *
 * Halo 的登录不是简单 POST 表单 —— 有两个坎：
 *   ① 密码必须用页面里的 RSA 公钥加密（JSEncrypt 加密后的 base64），
 *      直接发明文会登录失败。
 *   ② 需要 CSRF token（_csrf 隐藏字段），且 cookie 要跟着走。
 *
 * 用法：
 *   $env:HALO_USER="admin"; $env:HALO_PASS="****"; node _video/publish-blog.mjs
 *
 *   加 --dry-run 只登录 + 校验，不发布（默认就是 dry-run）。
 *   加 --publish 才真正创建文章。
 */

import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')

const BASE = 'https://blog.balong.in'
const DRY_RUN = !process.argv.includes('--publish')

const USER = process.env.HALO_USER
const PASS = process.env.HALO_PASS
if (!USER || !PASS) {
  console.error('请先设置 HALO_USER 与 HALO_PASS 环境变量')
  process.exit(1)
}

/* ------------------------------------------------------------------ *
 * 1. 极简 RSA 加密（Node 内置 crypto，不需要 JSEncrypt）
 *    Halo 登录页用 JSEncrypt 加密，其输出是 PKCS#1 v1.5 填充的 base64。
 *    Node 的 publicEncrypt + RSA_PKCS1_PADDING 产出完全一致。
 * ------------------------------------------------------------------ */

function pemFromB64Der(rawB64) {
  // HTML 里是 JS 字符串字面量，斜杠被转义成 \/ —— 直接当 base64 解码会失败
  // （报 error:1E08010C:DECODER routines::unsupported）
  const b64 = rawB64.split('\\/').join('/').replace(/[^A-Za-z0-9+/=]/g, '')
  // 从 login 页拿到的是一整段 base64（无 PEM 头尾），是 SubjectPublicKeyInfo
  const wrapped = b64.match(/.{1,64}/g).join('\n')
  return `-----BEGIN PUBLIC KEY-----\n${wrapped}\n-----END PUBLIC KEY-----\n`
}

function encryptPassword(plain, publicKeyB64) {
  const pem = pemFromB64Der(publicKeyB64)
  if (!/^[A-Za-z0-9+/=]+$/.test(pem.replace(/-----[^-]+-----/g, '').replace(/\s/g, ''))) {
    throw new Error('公钥 base64 非法（可能含未还原的转义字符）')
  }
  const buf = Buffer.from(plain, 'utf8')
  const out = crypto.publicEncrypt(
    { key: pem, padding: crypto.constants.RSA_PKCS1_PADDING },
    buf,
  )
  return out.toString('base64')
}

/* ------------------------------------------------------------------ *
 * 2. 抓登录页 → 取公钥与 CSRF → 提交登录
 * ------------------------------------------------------------------ */

function parseSetCookies(res) {
  // Node fetch 的 headers.getSetCookie() 在 Node 20+ 可用
  const list = typeof res.headers.getSetCookie === 'function'
    ? res.headers.getSetCookie()
    : (res.headers.get('set-cookie') || '').split(/,(?=[^;]+=)/)
  return list.map((c) => c.split(';')[0].trim()).filter(Boolean)
}

async function login() {
  console.log('① 抓登录页…')
  const pageRes = await fetch(`${BASE}/login`, { redirect: 'manual' })
  const html = await pageRes.text()
  const cookies = parseSetCookies(pageRes)

  const pkMatch = html.match(/const publicKey = "([^"]+)"/)
  const csrfMatch = html.match(/name="_csrf" value="([^"]+)"/)
  if (!pkMatch || !csrfMatch) {
    throw new Error('登录页里没找到 publicKey / _csrf，Halo 版本可能变了')
  }
  console.log(`   公钥长度 ${pkMatch[1].length}，CSRF 已取，cookie ${cookies.length} 个`)

  const encPwd = encryptPassword(PASS, pkMatch[1])
  console.log(`② 密码已 RSA 加密（${encPwd.length} 字符）`)

  const form = new URLSearchParams()
  form.set('_csrf', csrfMatch[1])
  form.set('username', USER)
  form.set('password', encPwd)
  form.set('remember-me', 'true')

  const loginRes = await fetch(`${BASE}/login`, {
    method: 'POST',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      cookie: cookies.join('; '),
      origin: BASE,
      referer: `${BASE}/login`,
    },
    body: form.toString(),
    redirect: 'manual',
  })

  const newCookies = parseSetCookies(loginRes)
  const all = [...cookies, ...newCookies].join('; ')
  const loc = loginRes.headers.get('location') || ''

  // 登录成功：302 到 /console 或 /；失败：302 回 /login?error
  if (loc.includes('error') || loc.includes('/login')) {
    throw new Error(`登录失败（location=${loc}）；账号或密码不对`)
  }
  console.log(`③ 登录成功（${loginRes.status} → ${loc || '(no redirect)'}）`)
  return all
}

/* ------------------------------------------------------------------ *
 * 3. 解析 markdown 的 frontmatter → Halo 文章 payload
 * ------------------------------------------------------------------ */

function splitFrontmatter(md) {
  const m = md.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/)
  if (!m) throw new Error('markdown 缺少 frontmatter')
  const meta = {}
  for (const line of m[1].split(/\r?\n/)) {
    const kv = line.match(/^(\w+):\s*(.*)$/)
    if (!kv) continue
    let v = kv[2].trim()
    if (v.startsWith('[') && v.endsWith(']')) {
      v = v.slice(1, -1).split(',').map((s) => s.trim()).filter(Boolean)
    } else if (v.startsWith('"') && v.endsWith('"')) {
      v = v.slice(1, -1)
    }
    meta[kv[1]] = v
  }
  return { meta, body: m[2] }
}

/** 极简 markdown → HTML（Halo 的 content 字段接受 HTML，rawType=html） */
function mdToHtml(md) {
  const lines = md.split(/\r?\n/)
  const out = []
  let inCode = false
  let codeBuf = []
  let listBuf = []
  let tableBuf = []

  const flushList = () => {
    if (listBuf.length) {
      out.push('<ul>\n' + listBuf.map((li) => `  <li>${li}</li>`).join('\n') + '\n</ul>')
      listBuf = []
    }
  }
  const flushTable = () => {
    if (!tableBuf.length) return
    const rows = tableBuf.filter((r) => !/^\|[\s:|-]+\|$/.test(r))
    const cells = rows.map((r) => r.replace(/^\||\|$/g, '').split('|').map((c) => c.trim()))
    if (cells.length) {
      const head = cells[0]
      const body = cells.slice(1)
      let html = '<table>\n<thead>\n<tr>' + head.map((c) => `<th>${inline(c)}</th>`).join('') + '</tr>\n</thead>\n<tbody>\n'
      for (const row of body) {
        html += '<tr>' + row.map((c) => `<td>${inline(c)}</td>`).join('') + '</tr>\n'
      }
      html += '</tbody>\n</table>'
      out.push(html)
    }
    tableBuf = []
  }

  const inline = (s) => s
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>')

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i]

    if (line.startsWith('```')) {
      if (!inCode) { inCode = true; codeBuf = []; continue }
      inCode = false
      out.push('<pre><code>' + codeBuf.join('\n').replace(/</g, '&lt;') + '</code></pre>')
      continue
    }
    if (inCode) { codeBuf.push(line); continue }

    if (/^\|/.test(line)) { flushList(); tableBuf.push(line); continue }
    flushTable()

    if (/^\s*[-*]\s+/.test(line)) { listBuf.push(inline(line.replace(/^\s*[-*]\s+/, ''))); continue }
    flushList()

    if (!line.trim()) { continue }

    const h = line.match(/^(#{1,6})\s+(.*)$/)
    if (h) { out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`); continue }

    if (/^>\s?/.test(line)) { out.push(`<blockquote><p>${inline(line.replace(/^>\s?/, ''))}</p></blockquote>`); continue }
    if (/^---+$/.test(line)) { out.push('<hr>'); continue }

    out.push(`<p>${inline(line)}</p>`)
  }
  flushList(); flushTable()
  if (inCode && codeBuf.length) out.push('<pre><code>' + codeBuf.join('\n') + '</code></pre>')

  return out.join('\n')
}

/* ------------------------------------------------------------------ *
 * 4. 发布
 * ------------------------------------------------------------------ */

async function publish(cookie) {
  const mdPath = path.join(ROOT, 'docs', 'blog-400-fix.md')
  const raw = fs.readFileSync(mdPath, 'utf8')
  const { meta, body } = splitFrontmatter(raw)
  const html = mdToHtml(body)
  console.log(`④ 草稿解析完成：标题「${meta.title}」，正文 ${body.length} 字符 → ${html.length} 字符 HTML`)

  // 取分类（没有就跳过）
  let categories = []
  try {
    const catRes = await fetch(`${BASE}/apis/api.content.halo.run/v1alpha1/categories`, { headers: { cookie } })
    if (catRes.ok) {
      const c = await catRes.json()
      categories = (c.items || []).slice(0, 2).map((x) => ({
        apiVersion: 'content.halo.run/v1alpha1',
        kind: 'Category',
        name: x.metadata.name,
      }))
      console.log(`   分类：${categories.length} 个可选（${(c.items || []).map((x) => x.spec.displayName).join(', ') || '无'}）`)
    }
  } catch { /* 忽略 */ }

  const slug = 'workbuddy-unapproved-channel-400-fix'
  const postName = `post-${crypto.randomBytes(4).toString('hex')}`

  const payload = {
    apiVersion: 'content.halo.run/v1alpha1',
    kind: 'Post',
    metadata: {
      name: postName,
      labels: {},
      annotations: {
        'content.halo.run/preferred-editor': 'default',
      },
    },
    spec: {
      title: meta.title,
      slug,
      categories,
      tags: Array.isArray(meta.tags) ? meta.tags : [],
      html,
      content: html,
      raw: html,
      rawType: 'html',
      excerpt: {
        autoGenerate: true,
        raw: meta.description || '',
      },
      cover: '',
      deleted: false,
      publish: true,
      pinned: false,
      allowComment: true,
      visible: 'PUBLIC',
      priority: 0,
      publishTime: new Date().toISOString(),
    },
  }

  if (DRY_RUN) {
    console.log('\n[DRY-RUN] 不实际发布。payload 摘要：')
    console.log('  title:', payload.spec.title)
    console.log('  slug :', payload.spec.slug)
    console.log('  html :', payload.spec.html.length, '字符')
    console.log('  tags :', payload.spec.tags.join(', '))
    console.log('\n加 --publish 真正发布。')
    return
  }

  console.log('⑤ 提交到 Halo…')
  const res = await fetch(`${BASE}/apis/api.console.halo.run/v1alpha1/posts`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', cookie },
    body: JSON.stringify(payload),
  })

  const text = await res.text()
  if (!res.ok) {
    console.error(`❌ 发布失败 HTTP ${res.status}`)
    console.error(text.slice(0, 800))
    return
  }
  const created = JSON.parse(text)
  const name = created.metadata?.name || postName

  // 发布（content API 的 Post 创建后需经 console 的 publish 动作）
  console.log(`   已创建 draft: ${name}`)
  const pubRes = await fetch(
    `${BASE}/apis/api.console.halo.run/v1alpha1/posts/${name}/publish`,
    { method: 'PUT', headers: { 'content-type': 'application/json', cookie } },
  )
  console.log(`   发布动作: HTTP ${pubRes.status}`)

  console.log(`\n✅ 原文地址：${BASE}/archives/${slug}`)
}

/* ------------------------------------------------------------------ */

const cookie = await login()
await publish(cookie)
