/**
 * dsh-workbuddy-fix — Client half.
 *
 * 在「设置」面板里注册一个独立的 section（`settings.section`），
 * 让遇到 WorkBuddy 400 错误的人一眼看到开关，不用先装整套计量面板。
 *
 * 与 dsh-workbuddy-meter 的关系：
 *   - 两个插件**互不依赖**，可单独装、可同时装；
 *   - 共享同一个状态文件 `~/.dsh/workbuddy-meter/lexicon.json`，
 *     所以任一方改了开关，另一方立即跟随（这就是「联动」）。
 *
 * 取数走插件自己的 /api/workbuddy-fix/* 同源路由（与 dsh-our-free-model 一致）。
 */
window.__ModuleLoader__.load({
  id: '@balong/dsh-workbuddy-fix',
  factory(require) {
    'use strict'

    const React = require('react')
    const h = React.createElement
    const useState = React.useState
    const useEffect = React.useEffect
    const useCallback = React.useCallback

    const NS = 'workbuddy-fix'
    const SECTION_ID = 'workbuddy-fix'

    /* ------------------------------------------------------------------ *
     * 文案：优先用宿主 locale 服务，取不到则回落到内置字典
     * ------------------------------------------------------------------ */

    /* ------------------------------------------------------------------ *
     * 同源 RPC：与本包 Host 半身通信
     *
     * 走插件自己的 /api/workbuddy-fix/* 路由（与 dsh-our-free-model 相同的
     * 做法），不依赖 host.call —— 后者需要额外的 Host 侧方法声明，未在此验证。
     * ------------------------------------------------------------------ */

    function apiBase() {
      try { return new URL('api/workbuddy-fix', document.baseURI).pathname }
      catch { return '/api/workbuddy-fix' }
    }

    function postJSON(path, body) {
      const ctrl = typeof AbortController === 'function' ? new AbortController() : null
      const timer = setTimeout(() => ctrl && ctrl.abort(), 15000)
      return fetch(apiBase() + path, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body || {}),
        redirect: 'error',
        signal: ctrl ? ctrl.signal : undefined,
      })
        .then((res) => res.json())
        .then((json) => {
          if (!json || json.ok !== true) {
            throw new Error((json && json.error && json.error.message) || 'request failed')
          }
          return json.value
        })
        .finally(() => clearTimeout(timer))
    }

    const ZH = {
      'nav': 'wb400修复',
      'title': '关键词风控修复',
      'subtitle': '绕过上游对系统提示词的关键词拦截，顺便让这个 agent 换个身份',
      'state.on': '已生效',
      'state.off': '已停用',

      'master.label': '总开关',
      'master.hint': '一键全部停用。停用后下一个请求就恢复原样，不留任何痕迹',

      'group.bypass': '第一步 · 绕过拦截',
      'group.bypassNote': '解决 400 报错本身。改的是发送前的副本，原文含义一字不动。',
      'group.replace': '第二步 · 换掉品牌',
      'group.replaceNote': '不止要能发出去，还要看不出是谁。把品牌名换成另一个产品的名字。',
      'group.persona': '第三步 · 换个身份',
      'group.personaNote': '光换名字还不够，行为方式也要像。在提示词末尾追加一套工作准则。',

      'option.neutralize': '拆开关键词',
      'option.neutralizeHint': '在上游会拦的那个词组中间插入看不见的字符。屏幕上还是原样，但不再命中拦截规则',
      'option.hideIdentity': '品牌名也拆开',
      'option.hideIdentityHint': '连单独出现的 DeepSeek 一起拆。比上面更彻底，但也更容易看出被动过手脚',
      'option.ensureSystem': '补一条开头消息',
      'option.ensureSystemHint': '有些渠道要求第一条必须是 system 消息。缺了会自动补一条',

      'option.brandReplace': '启用品牌替换',
      'option.brandReplaceHint': '把品牌名整段换成下面这个词。开启后上一步的「拆开关键词」自动让位给这里',
      'option.replacement': '换成',
      'option.replacementHint': '填你想让它自称的名字。文件路径里的同名文字不会被误改',

      'option.persona': '追加工作准则',
      'option.personaHint': '在提示词末尾追加 {n} 字符的行为规范（CodeBuddy 风格）',
      'option.personaHintCustom': '使用你自定义的 {n} 字符规范',
      'option.personaHintNoSize': '在提示词末尾追加一套 CodeBuddy 风格的行为规范',

      'persona.builtin': '内置模板',
      'persona.custom': '自定义内容',
      'persona.chars': '{n} 字符',
      'persona.edit': '改一改',
      'persona.save': '保存',
      'persona.cancel': '取消',
      'persona.reset': '还原成模板',
      'persona.expand': '展开全文',
      'persona.collapse': '收起',

      'status.patchOk': '兼容钩子已就位',
      'status.patchMissing': '兼容钩子未打上',
      'status.fetchOk': '主通道已接管',
      'status.fetchMissing': '主通道未接管',
      'status.fetchMissingHint': '插件的后台部分没跑起来。先确认插件是启用状态，再重启 DSH。',
      'status.fetchChained': '主通道运行中（位于其他插件内层）',
      'status.fetchChainedHint': '有别的插件也包装了 fetch 并排在我们外面。这不是故障——改写照常生效，上面的计数在增长就是证据。',
      'status.fetchIdle': '主通道已就绪，还没被调用',
      'version.label': 'v{n}',
      'update.check': '检查更新',
      'update.checking': '检查中…',
      'update.latest': '已是最新版',
      'update.available': '有新版本 v{n}',
      'update.open': '去看看',
      'update.failed': '查不到（网络不通或被墙，不影响插件使用）',
      'status.patchOptional': '旧版钩子未打上（不影响使用）',
      'status.hookOk': '运行时钩子已安装',
      'status.hookMissing': '运行时钩子未安装',
      'status.repair': '补打钩子',
      'status.repairing': '处理中…',
      'status.meterLinked': '正与「用量计量」插件共用同一份开关',
      'status.standalone': '独立运行（没装用量计量插件）',

      'stats.label': '已处理 {n} 处关键词，补开头消息 {m} 次',
      'stats.idle': '还没有需要处理的请求',

      'restore.title': '随时可以反悔',
      'restore.body': '这里所有改动只发生在「准备发出去的那一刻」，磁盘上的文件一个都没动。把总开关一关，下一个请求就一字不差地恢复原样；再打开又立刻生效。反复开关也不会留下任何残留。',

      'preview.title': '效果预览',
      'preview.before': '改之前',
      'preview.after': '改之后',
      'preview.hits': '命中 {n} 处',
      'why.title': '这个报错到底是怎么回事',
      'why.body': '上游返回 400，报文写着 Illegal API invocation from an unapproved channel，看起来像渠道问题——其实跟渠道、域名、客户端身份、请求头都无关。真正的原因是上游在检查 system prompt 里有没有出现特定词组。',
      'why.selfCheck': '60 秒自证',
      'why.selfCheckBody': '用同一个 token 打两次，只改 system prompt 里的一个词。含关键词那次失败、去掉关键词那次成功，就说明是这个原因。',
      'why.intermittent': '为什么时好时坏',
      'why.intermittentBody': '关键词要配合请求体够大（约超过 1KB）才稳定触发。短 prompt 即使含关键词也会放过，这是最容易误判成「偶发故障」的地方。',
      'preview.note': '示例文本，用来演示当前开关的实际效果。',
      'error.loadFailed': '读取配置失败：{reason}',

      'preview.none': '这段示例没有需要改的地方',
    }

    const EN = {
      'nav': 'wb400 Fix',
      'title': 'Keyword filter fix',
      'subtitle': 'Get past the upstream keyword check, and give this agent a different identity',
      'state.on': 'Active',
      'state.off': 'Stopped',

      'master.label': 'Master switch',
      'master.hint': 'Stops everything at once. The next request is back to the original, with nothing left behind',

      'group.bypass': 'Step 1 · Get past the check',
      'group.bypassNote': 'Solves the 400 itself. Only the outgoing copy is touched — the meaning is unchanged.',
      'group.replace': 'Step 2 · Change the brand',
      'group.replaceNote': 'Getting through is not enough — it should not look like DSH either. Swap the brand for another product name.',
      'group.persona': 'Step 3 · Change the identity',
      'group.personaNote': 'A different name is not enough if it still behaves the same. Append a set of working principles.',

      'option.neutralize': 'Split the keyword',
      'option.neutralizeHint': 'Insert invisible characters inside the phrase the upstream looks for. Looks identical on screen, but no longer matches',
      'option.hideIdentity': 'Split the brand too',
      'option.hideIdentityHint': 'Also splits standalone mentions of DeepSeek. More thorough, but easier to notice',
      'option.ensureSystem': 'Add a leading message',
      'option.ensureSystemHint': 'Some channels require the first message to be a system message. One is added when missing',

      'option.brandReplace': 'Enable brand replacement',
      'option.brandReplaceHint': 'Replaces the whole brand phrase with the word below. Takes over from "split the keyword" above',
      'option.replacement': 'Replace with',
      'option.replacementHint': 'What it should call itself. Identical text inside file paths is left alone',

      'option.persona': 'Append working principles',
      'option.personaHint': 'Appends {n} characters of CodeBuddy-style guidelines to the prompt',
      'option.personaHintCustom': 'Using your custom {n}-character guidelines',
      'option.personaHintNoSize': 'Appends a set of CodeBuddy-style working principles to the prompt',

      'persona.builtin': 'Built-in template',
      'persona.custom': 'Custom',
      'persona.chars': '{n} chars',
      'persona.edit': 'Edit',
      'persona.save': 'Save',
      'persona.cancel': 'Cancel',
      'persona.reset': 'Reset to template',
      'persona.expand': 'Show all',
      'persona.collapse': 'Collapse',

      'status.patchOk': 'Legacy hook in place',
      'status.patchMissing': 'Legacy hook not applied',
      'status.fetchOk': 'Main channel active',
      'status.fetchMissing': 'Main channel inactive',
      'status.fetchMissingHint': 'The background half is not running. Make sure the plugin is enabled, then restart DSH.',
      'status.fetchChained': 'Main channel running (nested under another plugin)',
      'status.fetchChainedHint': 'Another plugin also wraps fetch and sits outside us. Not a fault — rewriting still works; the counter above is the proof.',
      'status.fetchIdle': 'Main channel ready, not called yet',
      'version.label': 'v{n}',
      'update.check': 'Check for updates',
      'update.checking': 'Checking…',
      'update.latest': 'Up to date',
      'update.available': 'v{n} available',
      'update.open': 'View release',
      'update.failed': 'Could not check (offline or blocked — plugin still works)',
      'status.patchOptional': 'Legacy hook not applied (not required)',
      'status.hookOk': 'Runtime hook installed',
      'status.hookMissing': 'Runtime hook missing',
      'status.repair': 'Reinstall hook',
      'status.repairing': 'Working…',
      'status.meterLinked': 'Sharing one config with the usage-meter plugin',
      'status.standalone': 'Standalone (usage-meter plugin not installed)',

      'stats.label': 'Handled {n} keyword hits, added {m} leading messages',
      'stats.idle': 'No requests needed changing yet',

      'restore.title': 'Always reversible',
      'restore.body': 'Everything here happens at the moment a request is sent — no file on disk is touched. Switch the master switch off and the very next request is byte-for-byte original; switch it back on and it applies again. Toggling leaves nothing behind.',

      'preview.title': 'Preview',
      'preview.before': 'Before',
      'preview.after': 'After',
      'preview.hits': '{n} hits',
      'why.title': 'What is this error, really',
      'why.body': 'The upstream returns 400 with "Illegal API invocation from an unapproved channel", which looks like a channel problem — but channel, domain, client identity and headers are all irrelevant. The real cause is that the upstream checks the system prompt for a particular phrase.',
      'why.selfCheck': 'Prove it in 60 seconds',
      'why.selfCheckBody': 'Send the same token twice, changing one word in the system prompt. If the one containing the phrase fails and the other succeeds, that is the cause.',
      'why.intermittent': 'Why it seems intermittent',
      'why.intermittentBody': 'The phrase only triggers reliably when the body is large enough (roughly over 1KB). Short prompts pass even with the phrase, which is why this is so easily mistaken for a flaky failure.',
      'preview.note': 'Sample text showing what the current switches actually do.',
      'error.loadFailed': 'Failed to read config: {reason}',

      'preview.none': 'Nothing to change in this sample',
    }

    // 两种字典风格都要支持：
    //   ① 嵌套（locale/*.json 的形态）：{ state: { on: "已修复" } }
    //   ② 扁平点号键（内嵌字典为了紧凑）：{ "state.on": "已修复" }
    // 先查扁平键，再按点号逐层下钻 —— 只做一种会静默回退成 key。
    function pick(dict, key) {
      if (dict === null || typeof dict !== 'object') return undefined
      const flat = dict[key]
      if (typeof flat === 'string') return flat
      const parts = String(key).split('.')
      let node = dict
      for (const part of parts) {
        if (node === null || typeof node !== 'object') return undefined
        node = node[part]
      }
      return typeof node === 'string' ? node : undefined
    }

    function interpolate(text, vars) {
      if (!vars) return text
      return String(text).replace(/\{(\w+)\}/g, (all, name) =>
        Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : all)
    }

    function makeT(ctx) {
      let bound = null
      try {
        if (ctx && ctx.locale && typeof ctx.locale.bind === 'function') bound = ctx.locale.bind(NS)
      } catch { bound = null }
      return function t(key, vars) {
        if (typeof bound === 'function') {
          try {
            const value = bound(key, vars)
            if (typeof value === 'string' && value !== '' && value !== key) return value
          } catch { /* fall through */ }
        }
        let text = pick(ZH, key)
        if (text === undefined) text = pick(EN, key)
        if (text === undefined) return String(key)
        return interpolate(text, vars)
      }
    }

    /* ------------------------------------------------------------------ *
     * 样式（只用主题 token，跟随明暗）
     * ------------------------------------------------------------------ */

    const STYLES = `
      .wbfix{display:flex;flex-direction:column;gap:14px;padding:2px 2px 24px;font-size:13px;color:var(--dsw-alias-label-primary)}
      .wbfix-head{display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap}
      .wbfix-headtext{display:flex;flex-direction:column;gap:3px;min-width:0;flex:1 1 auto}
      .wbfix-h1{font-size:16px;font-weight:600;margin:0;line-height:1.3}
      .wbfix-sub{font-size:12px;color:var(--dsw-alias-label-tertiary);line-height:1.4}
      .wbfix-meta[data-tone="warn"] span{color:var(--dsw-alias-state-warn-primary)}
      .wbfix-ver{font-size:11px;font-weight:500;margin-left:6px;padding:1px 6px;border-radius:5px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums;vertical-align:2px}
      .wbfix-badge{flex:none;font-size:11px;font-weight:700;letter-spacing:.03em;padding:3px 10px;border-radius:999px;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-tertiary)}
      .wbfix-badge[data-on="true"]{color:var(--dsw-alias-state-success-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 45%,var(--dsw-alias-border-l2));background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 12%,transparent)}
      .wbfix-card{border:1px solid var(--dsw-alias-border-l2);border-radius:12px;padding:14px 16px;background:var(--dsw-alias-bg-layer-2);display:flex;flex-direction:column;gap:11px}
      .wbfix-row{display:flex;align-items:center;gap:12px}
      .wbfix-rowtext{display:flex;flex-direction:column;gap:2px;min-width:0;flex:1 1 auto}
      .wbfix-rowlabel{font-size:13px;font-weight:600;line-height:1.35}
      .wbfix-rowhint{font-size:11.5px;color:var(--dsw-alias-label-tertiary);line-height:1.45}
      .wbfix-row[data-disabled="true"]{opacity:.45}
      .wbfix-switch{appearance:none;flex:none;position:relative;width:38px;height:21px;border-radius:999px;border:1px solid var(--dsw-alias-border-l3);background:var(--dsw-alias-bg-layer-4);cursor:pointer;padding:0;transition:background .18s ease,border-color .18s ease}
      .wbfix-switch[data-on="true"]{background:var(--dsw-alias-state-success-primary);border-color:transparent}
      .wbfix-switch[data-locked="true"]{cursor:not-allowed}
      .wbfix-knob{position:absolute;top:50%;left:2px;width:15px;height:15px;border-radius:50%;background:var(--dsw-alias-bg-layer-1);transform:translateY(-50%);transition:left .18s cubic-bezier(.4,0,.2,1);box-shadow:0 1px 2px color-mix(in srgb,var(--dsw-alias-label-primary) 28%,transparent)}
      .wbfix-switch[data-on="true"] .wbfix-knob{left:20px;background:var(--dsw-alias-bg-layer-4)}
      .wbfix-sep{height:1px;background:var(--dsw-alias-border-l2);margin:1px 0}
      /* ── v1.2.0：功能分组 ─────────────────────────────────────── */
      .wbfix-group{display:flex;flex-direction:column;gap:2px;padding:14px 0 6px;border-top:1px solid var(--dsw-alias-border-l2);margin-top:4px}
      .wbfix-grouptitle{font-size:12px;font-weight:700;letter-spacing:.02em;color:var(--dsw-alias-label-primary)}
      .wbfix-groupnote{font-size:11px;line-height:1.5;color:var(--dsw-alias-label-tertiary)}
      .wbfix-input{flex:none;width:170px;font:inherit;font-size:12px;padding:5px 9px;border-radius:7px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary)}
      .wbfix-input:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}
      .wbfix-persona{display:flex;flex-direction:column;gap:8px;padding:10px 12px;border-radius:10px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);margin:6px 0 2px}
      .wbfix-personahead{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
      .wbfix-personalabel{display:flex;align-items:baseline;gap:7px;font-size:11.5px;font-weight:600;color:var(--dsw-alias-label-secondary)}
      .wbfix-personachars{font-weight:400;font-size:10.5px;color:var(--dsw-alias-label-tertiary)}
      .wbfix-personaactions{display:flex;gap:6px}
      .wbfix-btn-ghost{background:transparent}
      .wbfix-textarea{width:100%;box-sizing:border-box;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;line-height:1.6;padding:9px 11px;border-radius:8px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);resize:vertical}
      .wbfix-textarea:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}
      .wbfix-personapreview{margin:0;overflow:auto;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11px;line-height:1.6;white-space:pre-wrap;word-break:break-word;color:var(--dsw-alias-label-secondary)}
      /* 默认折叠：只露三行。模板有 1600+ 字符，全展开会把下面的状态行挤出视野。 */
      .wbfix-personapreview[data-collapsed="true"]{max-height:4.8em;overflow:hidden;-webkit-mask-image:linear-gradient(180deg,var(--dsw-alias-label-primary) 45%,transparent);mask-image:linear-gradient(180deg,var(--dsw-alias-label-primary) 45%,transparent)}
      .wbfix-personapreview[data-collapsed="false"]{max-height:240px}
      .wbfix-expand{appearance:none;font:inherit;font-size:11px;padding:0;border:0;background:none;color:var(--dsw-alias-brand-primary);cursor:pointer;align-self:flex-start}
      .wbfix-expand:hover{text-decoration:underline}
      .wbfix-restore{display:flex;flex-direction:column;gap:5px;padding:11px 13px;border-radius:10px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);margin:4px 0 2px}
      .wbfix-restore[data-on="true"]{border-color:var(--dsw-alias-state-warn-primary);background:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 8%,var(--dsw-alias-bg-layer-2))}
      .wbfix-restorehead{display:flex;align-items:center;gap:7px}
      .wbfix-restoreicon{flex:none;font-size:13px;line-height:1;color:var(--dsw-alias-state-success-primary)}
      .wbfix-restore[data-on="true"] .wbfix-restoreicon{color:var(--dsw-alias-state-warn-primary)}
      .wbfix-restoretitle{font-size:11.5px;font-weight:700;color:var(--dsw-alias-label-primary)}
      .wbfix-restorebody{margin:0;font-size:11px;line-height:1.65;color:var(--dsw-alias-label-secondary)}
      .wbfix-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:11.5px;color:var(--dsw-alias-label-tertiary)}
      .wbfix-dot{flex:none;width:7px;height:7px;border-radius:50%}
      .wbfix-dot[data-ok="true"]{background:var(--dsw-alias-state-success-primary)}
      .wbfix-dot[data-ok="false"]{background:var(--dsw-alias-state-warn-primary)}
      .wbfix-note-soft{font-size:11px;line-height:1.5;color:var(--dsw-alias-label-tertiary);word-break:break-word}
      .wbfix-err{font-size:11.5px;line-height:1.5;color:var(--dsw-alias-state-error-primary);word-break:break-word}
          .wbfix-hint{font-size:11.5px;line-height:1.5;color:var(--dsw-alias-label-tertiary);word-break:break-word}
      .wbfix-btn{appearance:none;font:inherit;font-size:11.5px;font-weight:600;padding:4px 11px;border-radius:7px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);cursor:pointer}
      .wbfix-btn:hover{border-color:var(--dsw-alias-brand-primary)}
      .wbfix-btn:disabled{opacity:.5;cursor:not-allowed}
      .wbfix-why{border:1px solid var(--dsw-alias-border-l2);border-radius:12px;padding:14px 16px;background:var(--dsw-alias-bg-layer-1);display:flex;flex-direction:column;gap:9px}
      .wbfix-why-title{margin:0;font-size:12.5px;font-weight:700;color:var(--dsw-alias-label-primary)}
      .wbfix-why-body{margin:0;font-size:12px;line-height:1.65;color:var(--dsw-alias-label-secondary)}
      .wbfix-why-sub{font-size:11.5px;font-weight:600;color:var(--dsw-alias-label-secondary);margin:3px 0 0}
      .wbfix-pre{display:flex;flex-direction:column;gap:5px}
      .wbfix-pre-label{font-size:10.5px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--dsw-alias-label-tertiary)}
      .wbfix-pre-code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11px;line-height:1.55;padding:8px 10px;border-radius:8px;background:var(--dsw-alias-bg-layer-3);border:1px solid var(--dsw-alias-border-l2);white-space:pre-wrap;word-break:break-word;color:var(--dsw-alias-label-secondary)}
      .wbfix-note{font-size:11px;color:var(--dsw-alias-label-tertiary);margin:0;line-height:1.5}
      .wbfix-err{font-size:11.5px;color:var(--dsw-alias-state-error-primary);margin:0}
      @media (prefers-reduced-motion:reduce){.wbfix-switch,.wbfix-knob{transition:none}}
    `

    /* ------------------------------------------------------------------ *
     * 小组件
     * ------------------------------------------------------------------ */

    /** 功能分组标题 —— 把 6 个开关按「绕过 / 换词 / 人格」三类分开。 */
    function GroupHeader(props) {
      return h('div', { className: 'wbfix-group' },
        h('span', { className: 'wbfix-grouptitle' }, props.title),
        props.note ? h('span', { className: 'wbfix-groupnote' }, props.note) : null)
    }

    /** 单行文本输入（失焦或回车才提交，避免每敲一个字就发请求）。 */
    function TextRow(props) {
      const [draft, setDraft] = React.useState(props.value ?? '')
      React.useEffect(() => { setDraft(props.value ?? '') }, [props.value])
      const commit = () => {
        const next = String(draft ?? '').trim()
        if (next && next !== (props.value ?? '')) props.onCommit(next)
      }
      return h('div', { className: 'wbfix-row', 'data-disabled': props.disabled ? 'true' : 'false' },
        h('div', { className: 'wbfix-rowtext' },
          h('span', { className: 'wbfix-rowlabel' }, props.label),
          h('span', { className: 'wbfix-rowhint' }, props.hint)),
        h('input', {
          className: 'wbfix-input',
          type: 'text',
          value: draft,
          placeholder: props.placeholder ?? '',
          disabled: props.disabled || props.busy,
          onChange: (e) => setDraft(e.target.value),
          onBlur: commit,
          onKeyDown: (e) => { if (e.key === 'Enter') { e.currentTarget.blur() } },
        }))
    }

    /** 人格段编辑器：默认显示内置模板，用户可改写；留空 = 用模板。 */
    function PersonaEditor(props) {
      const isCustom = String(props.value ?? '').trim().length > 0
      const [editing, setEditing] = React.useState(false)
      const [expanded, setExpanded] = React.useState(false)
      const [draft, setDraft] = React.useState(isCustom ? props.value : props.template)
      React.useEffect(() => {
        setDraft(String(props.value ?? '').trim() ? props.value : props.template)
      }, [props.value, props.template])

      const shown = editing ? draft : (isCustom ? props.value : props.template)
      const chars = String(shown ?? '').length

      return h('div', { className: 'wbfix-persona' },
        h('div', { className: 'wbfix-personahead' },
          h('span', { className: 'wbfix-personalabel' },
            isCustom ? props.t('persona.custom') : props.t('persona.builtin'),
            h('span', { className: 'wbfix-personachars' },
              props.t('persona.chars', { n: chars }))),
          h('div', { className: 'wbfix-personaactions' },
            editing
              ? [
                  h('button', {
                    key: 'save', type: 'button', className: 'wbfix-btn',
                    disabled: props.busy || props.disabled,
                    onClick: () => { props.onCommit(draft); setEditing(false) },
                  }, props.t('persona.save')),
                  h('button', {
                    key: 'cancel', type: 'button', className: 'wbfix-btn wbfix-btn-ghost',
                    onClick: () => { setDraft(shown); setEditing(false) },
                  }, props.t('persona.cancel')),
                ]
              : [
                  h('button', {
                    key: 'edit', type: 'button', className: 'wbfix-btn',
                    disabled: props.busy || props.disabled,
                    onClick: () => setEditing(true),
                  }, props.t('persona.edit')),
                  isCustom
                    ? h('button', {
                        key: 'reset', type: 'button', className: 'wbfix-btn wbfix-btn-ghost',
                        disabled: props.busy || props.disabled,
                        onClick: () => { props.onCommit(''); setEditing(false) },
                      }, props.t('persona.reset'))
                    : null,
                ])),
        editing
          ? h('textarea', {
              className: 'wbfix-textarea',
              value: draft,
              rows: 12,
              spellCheck: false,
              disabled: props.busy || props.disabled,
              onChange: (e) => setDraft(e.target.value),
            })
          : [
              h('pre', {
                key: 'p',
                className: 'wbfix-personapreview',
                'data-collapsed': expanded ? 'false' : 'true',
              }, shown),
              h('button', {
                key: 'e',
                type: 'button',
                className: 'wbfix-expand',
                onClick: () => setExpanded(!expanded),
              }, expanded ? props.t('persona.collapse') : props.t('persona.expand')),
            ])
    }

    function ToggleRow(props) {
      return h(
        'div',
        { className: 'wbfix-row', 'data-disabled': props.disabled ? 'true' : 'false' },
        h('div', { className: 'wbfix-rowtext' },
          h('span', { className: 'wbfix-rowlabel' }, props.label),
          h('span', { className: 'wbfix-rowhint' }, props.hint)),
        h('button', {
          type: 'button',
          className: 'wbfix-switch',
          role: 'switch',
          'aria-checked': props.checked ? 'true' : 'false',
          'aria-label': props.label,
          'data-on': props.checked ? 'true' : 'false',
          'data-locked': props.disabled || props.busy ? 'true' : 'false',
          onClick: () => {
            if (props.disabled || props.busy) return
            props.onChange(!props.checked)
          },
        }, h('span', { className: 'wbfix-knob' }))
      )
    }

    function WhyCard(props) {
      const t = props.t
      return h('div', { className: 'wbfix-why' },
        h('h3', { className: 'wbfix-why-title' }, t('why.title')),
        h('p', { className: 'wbfix-why-body' }, t('why.body')),
        h('p', { className: 'wbfix-why-sub' }, t('why.selfCheck')),
        h('p', { className: 'wbfix-why-body' }, t('why.selfCheckBody')),
        h('p', { className: 'wbfix-why-sub' }, t('why.intermittent')),
        h('p', { className: 'wbfix-why-body' }, t('why.intermittentBody')))
    }

    function PreviewCard(props) {
      const t = props.t
      const pre = props.preview
      if (!pre) return null
      return h('div', { className: 'wbfix-why' },
        h('h3', { className: 'wbfix-why-title' }, t('preview.title')),
        h('div', { className: 'wbfix-pre' },
          h('span', { className: 'wbfix-pre-label' }, t('preview.before')),
          h('code', { className: 'wbfix-pre-code' }, pre.before)),
        h('div', { className: 'wbfix-pre' },
          h('span', { className: 'wbfix-pre-label' },
            t('preview.after') + (pre.hits > 0 ? ' · ' + t('preview.hits', { n: pre.hits }) : '')),
          h('code', { className: 'wbfix-pre-code' }, pre.after)),
        h('p', { className: 'wbfix-note' }, t('preview.note')))
    }

    /* ------------------------------------------------------------------ *
     * 设置页面板
     * ------------------------------------------------------------------ */

    function FixPanel(props) {
      const t = props.t

      const [state, setState] = useState({ status: 'loading', value: null, error: null })
      const [busy, setBusy] = useState(false)
      const [preview, setPreview] = useState(null)

      /* 检查更新：与 config 无关的独立状态，不写回配置文件。
       * phase 三态：idle（还没查）/ checking（查询中）/ done（有结果）。
       * ⚠️ 声明必须真的存在 —— 只加 UI 引用不加声明，整块面板渲染时会抛
       *    ReferenceError（v1.3.0 初版就犯了这个错，被用户当场撞到）。
       */
      const [update, setUpdate] = useState({ phase: 'idle', result: null })
      const runUpdateCheck = useCallback(() => {
        setUpdate({ phase: 'checking', result: null })
        postJSON('/update-check', {})
          .then((res) => setUpdate({ phase: 'done', result: res || { ok: false, reason: 'empty' } }))
          .catch(() => setUpdate({ phase: 'done', result: { ok: false, reason: 'request-failed' } }))
      }, [])

      const load = useCallback(() => {
        postJSON('/status', {})
          .then((value) => setState({ status: 'ready', value, error: null }))
          .catch((error) => setState({ status: 'error', value: null, error: errorText(error) }))
      }, [])

      useEffect(() => { load() }, [load])

      const apply = useCallback((patch) => {
        setBusy(true)
        // 乐观更新：先动 UI，失败再回滚，避免开关看起来「点了没反应」。
        // ⚠️ 回滚必须有真实作用 —— 只设 error 会让开关停在翻转过的新状态，
        //    用户以为已生效。所以先记下改动前的 config。
        let prevConfig = null
        setState((prev) => {
          if (!prev.value) return prev
          prevConfig = prev.value.config
          return { ...prev, value: { ...prev.value, config: { ...prev.value.config, ...patch } } }
        })
        postJSON('/set', { patch, resetStats: true })
          .then((res) => {
            setState((prev) => prev.value
              ? { ...prev, value: { ...prev.value, config: res.config, stats: { rewrites: 0, hits: 0, injected: 0 } } }
              : prev)
            // 刷新预览，让用户立刻看到改写效果
            return postJSON('/dry-run', { patch })
          })
          .then((res) => { if (res) setPreview(res) })
          .catch((error) => setState((prev) => (prev.value && prevConfig
            ? { ...prev, value: { ...prev.value, config: prevConfig }, error: errorText(error) }
            : { ...prev, error: errorText(error) })))
          .finally(() => setBusy(false))
      }, [])

      const repair = useCallback(() => {
        setBusy(true)
        postJSON('/repair-patch', {})
          .then((res) => {
            setState((prev) => prev.value
              ? { ...prev, value: { ...prev.value, patchPresent: res.patchPresent === true } }
              : prev)
          })
          .catch((error) => setState((prev) => ({ ...prev, error: errorText(error) })))
          .finally(() => setBusy(false))
      }, [])

      const v = state.value
      const config = v ? v.config || {} : {}
      const enabled = config.enabled !== false
      const stats = v ? v.stats || {} : {}

      /* 主通道是否「真的在工作」——不能只看是不是在最外层。
       *
       * 背景：DSH 启动时十几个插件按顺序包装 globalThis.fetch。任何在我们
       * 之后包装的插件都会把我们挤到内层。只要对方是「先存旧的、调用时转发」
       * 的写法（绝大多数都是），我们的 wrapper 仍在链上、改写照常生效。
       *
       * 所以判据是三重：
       *   ① installed（我们在最外层）→ 明确在工作
       *   ② 已经改动过请求（stats.rewrites > 0）→ 铁证：确实在工作
       *   ③ reason === 'chained' 但还没被调用过 → 就绪待命，不算故障
       * 只有 reason 表明「从未安装」/「已卸载」才是真故障。
       */
      const hookStatus = v ? (v.hookStatus || {}) : {}
      const rewrites = Number(stats.rewrites) || 0
      const hookInstalled = Boolean(v && v.fetchHookInstalled)
      const hookReason = hookStatus.reason
      const hookOk = hookInstalled
        || rewrites > 0
        || hookReason === 'active'
        || hookReason === 'chained'
      const hookLabel = hookInstalled || rewrites > 0
        ? t('status.fetchOk')
        : (hookReason === 'chained' ? t('status.fetchChained') : t('status.fetchIdle'))

      /* 检查更新的三态文案。
       *
       * 设计原则：**「查不到」不算错误**。用户不开代理时 github.com 常常超时，
       * 这是常态而不是故障 —— 所以失败时用中性灰字，绝不用红色错误样式。
       * 只有真的查到新版本才用醒目色。
       */
      const upd = update.result
      const updateTone = update.phase === 'checking'
        ? 'idle'
        : (upd && upd.ok && upd.hasUpdate ? 'warn' : (upd && upd.ok ? 'ok' : 'muted'))
      const updateText = update.phase === 'checking'
        ? t('update.checking')
        : !upd
          ? null
          : upd.ok
            ? (upd.hasUpdate ? t('update.available', { n: upd.latest || '' }) : t('update.latest'))
            : t('update.failed')
      const updateOpen = upd && upd.ok && upd.hasUpdate ? (upd.url || null) : null

      const badge = v ? (enabled ? t('state.on') : t('state.off')) : '…'

      return h('div', { className: 'wbfix' },
        h('style', null, STYLES),

        h('div', { className: 'wbfix-head' },
          h('div', { className: 'wbfix-headtext' },
            h('h2', { className: 'wbfix-h1' },
              t('title'),
              v && v.version
                ? h('span', { className: 'wbfix-ver' }, t('version.label', { n: v.version }))
                : null),
            h('span', { className: 'wbfix-sub' }, t('subtitle'))),
          h('span', { className: 'wbfix-badge', 'data-on': enabled ? 'true' : 'false' }, badge)),

        state.status === 'error'
          ? h('p', { className: 'wbfix-err' }, t('error.loadFailed', { reason: state.error || '' }))
          : null,

        v
          ? h('div', { className: 'wbfix-card' },
              // ── 总开关 ──────────────────────────────────────────────
              h(ToggleRow, {
                label: t('master.label'),
                hint: t('master.hint'),
                checked: enabled,
                busy,
                disabled: false,
                onChange: (next) => apply({ enabled: next }),
              }),

              // ── 第 1 组：绕过检测 ───────────────────────────────────
              h(GroupHeader, {
                title: t('group.bypass'),
                note: t('group.bypassNote'),
              }),
              h(ToggleRow, {
                label: t('option.neutralize'),
                hint: t('option.neutralizeHint'),
                checked: config.neutralize !== false,
                busy,
                disabled: !enabled,
                onChange: (next) => apply({ neutralize: next }),
              }),
              h(ToggleRow, {
                label: t('option.hideIdentity'),
                hint: t('option.hideIdentityHint'),
                checked: config.hideIdentity === true,
                busy,
                disabled: !enabled,
                onChange: (next) => apply({ hideIdentity: next }),
              }),
              h(ToggleRow, {
                label: t('option.ensureSystem'),
                hint: t('option.ensureSystemHint'),
                checked: config.ensureSystem !== false,
                busy,
                disabled: !enabled,
                onChange: (next) => apply({ ensureSystem: next }),
              }),

              // ── 第 2 组：彻底换词 ───────────────────────────────────
              h(GroupHeader, {
                title: t('group.replace'),
                note: t('group.replaceNote'),
              }),
              h(ToggleRow, {
                label: t('option.brandReplace'),
                hint: t('option.brandReplaceHint'),
                checked: config.brandReplace === true,
                busy,
                disabled: !enabled,
                onChange: (next) => apply({ brandReplace: next }),
              }),
              config.brandReplace
                ? h(TextRow, {
                    label: t('option.replacement'),
                    hint: t('option.replacementHint'),
                    value: config.replacement || '',
                    placeholder: 'CodeBuddy',
                    busy,
                    disabled: !enabled,
                    onCommit: (next) => apply({ replacement: next }),
                  })
                : null,

              // ── 第 3 组：人格注入 ───────────────────────────────────
              h(GroupHeader, {
                title: t('group.persona'),
                note: t('group.personaNote'),
              }),
              h(ToggleRow, {
                label: t('option.persona'),
                hint: (() => {
                  const custom = config.personaText && config.personaText.trim()
                  if (custom) return t('option.personaHintCustom', { n: config.personaText.length })
                  // 拿不到模板长度（旧版 Host 半身 / 请求还没回来）时，
                  // 不能显示「0 字符」—— 那会让人以为功能是坏的。
                  const n = v.personaTemplateChars
                  return n > 0 ? t('option.personaHint', { n }) : t('option.personaHintNoSize')
                })(),
                checked: config.persona === true,
                busy,
                disabled: !enabled,
                onChange: (next) => apply({ persona: next }),
              }),
              config.persona
                ? h(PersonaEditor, {
                    t,
                    busy,
                    disabled: !enabled,
                    template: v.personaTemplate || '',
                    templateChars: v.personaTemplateChars || 0,
                    value: config.personaText || '',
                    onCommit: (next) => apply({ personaText: next }),
                  })
                : null,

              h('div', { className: 'wbfix-sep' }),

              h('div', { className: 'wbfix-meta' },
                h('span', { className: 'wbfix-dot', 'data-ok': hookOk ? 'true' : 'false' }),
                h('span', null, hookLabel),
                h('span', { className: 'wbfix-dot', 'data-ok': v.patchPresent ? 'true' : 'false' }),
                h('span', null, v.patchPresent ? t('status.patchOk') : t('status.patchOptional')),
                !v.patchPresent
                  ? h('button', {
                      type: 'button',
                      className: 'wbfix-btn',
                      disabled: busy,
                      onClick: repair,
                    }, busy ? t('status.repairing') : t('status.repair'))
                  : null),
              // ⚠️ 只有「确实没在工作」才是故障。
              //    v1.2.2 之前这里只看 v.fetchHookInstalled（是不是在最外层），
              //    导致被别的插件包到内层时误报「后台部分没跑起来，重启 DSH」——
              //    而实际上改写一直在正常工作。判断依据要用「有没有真的改过东西」。
              hookOk
                ? (hookInstalled || rewrites > 0
                    ? null
                    // 处于内层但还没被调用过：给一句中性说明，不用红色、不算故障。
                    : h('div', { className: 'wbfix-meta' },
                        h('span', { className: 'wbfix-hint' }, t('status.fetchChainedHint'))))
                : h('div', { className: 'wbfix-meta' },
                    h('span', { className: 'wbfix-err' }, t('status.fetchMissingHint'))),
              // 兼容通道没打上不算故障 —— 只是「非 fetch 请求拦不到」。有原因就显示。
              !v.patchPresent && v.patchError
                ? h('div', { className: 'wbfix-meta' },
                    h('span', { className: 'wbfix-note-soft' }, v.patchError))
                : null,

              h('div', { className: 'wbfix-meta' },
                h('span', null,
                  stats.rewrites > 0
                    ? t('stats.label', { n: stats.hits || 0, m: stats.injected || 0 })
                    : t('stats.idle'))),

              h('div', { className: 'wbfix-meta' },
                h('span', null, v.meterPresent ? t('status.meterLinked') : t('status.standalone'))),

              h('div', { className: 'wbfix-meta', 'data-tone': updateTone },
                h('span', { className: 'wbfix-dot', 'data-ok': updateTone === 'ok' ? 'true' : 'false' }),
                h('span', null, updateText),
                update.phase === 'checking'
                  ? null
                  : h('button', {
                      type: 'button',
                      className: 'wbfix-btn',
                      onClick: runUpdateCheck,
                    }, t('update.check')),
                updateOpen
                  ? h('a', {
                      className: 'wbfix-btn',
                      href: updateOpen,
                      target: '_blank',
                      rel: 'noreferrer noopener',
                    }, t('update.open'))
                  : null),

              // 复原保障：这是本插件最重要的承诺，要显眼。
              // 说清「为什么能复原」—— 用户最怕的是改了回不去。
              h('div', { className: 'wbfix-restore', 'data-on': (config.brandReplace || config.persona) ? 'true' : 'false' },
                h('div', { className: 'wbfix-restorehead' },
                  h('span', { className: 'wbfix-restoreicon' }, '⟲'),
                  h('span', { className: 'wbfix-restoretitle' }, t('restore.title'))),
                h('p', { className: 'wbfix-restorebody' }, t('restore.body')))
            )
          : null,

        v ? h(PreviewCard, { t, preview }) : null,
        h(WhyCard, { t })
      )
    }

    function errorText(error) {
      if (error === null || error === undefined) return ''
      if (typeof error === 'string') return error
      if (typeof error.message === 'string') return error.message
      return String(error)
    }

    /* ------------------------------------------------------------------ *
     * 注册到 settings.section
     * ------------------------------------------------------------------ */

    return {
      inject: ['slots'],
      apply(ctx) {
        // ⚠️ 两个必须避开的坑（都会让宿主白屏 "Failed to load plugins"）：
        //
        // ① 不要给 slots.register 传 `locale` 选项。
        //    它的类型是 keyof LocaleNamespaceMap，未在该 map 里注册的
        //    namespace 会被宿主校验拒绝，而 slots.inject 的回调错误是
        //    **同步抛出**的 → 整个 client 半身加载失败 → 白屏。
        //
        // ② 不要在 inject 回调里做可能抛错的事（同上）。
        //
        // 文案改用本模块自带的字典（makeT 优先问宿主 locale，取不到就用
        // 内嵌 ZH/EN），因此完全不依赖宿主 locale 注册。

        const t = makeT(ctx)

        ctx.slots.inject('settings.section', () => {
          try {
            return ctx.slots.register({
              name: 'settings.section',
              // 独立 id：新条目会「加在」现有条目旁边。
              // 若复用已发布的 id 会替换掉那个页面 —— 绝不能撞车。
              id: SECTION_ID,
              order: 36,
              label: () => t('nav'),
            }, (props) => h(FixPanel, { ...props, t }))
          } catch (error) {
            // 注册失败只影响本插件这一页，绝不能让宿主 UI 挂掉
            console.error('[workbuddy-fix] slot registration failed:', error)
            return () => {}
          }
        })
      },
    }
  },
})
