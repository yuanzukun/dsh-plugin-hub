/**
 * 版本与更新检查。
 *
 * ## 为什么需要单独一层
 *
 * 「本插件是哪个版本」必须**从磁盘上的 package.json 读**，不能硬编码：
 * 硬编码会在发版时忘记同步，用户看到的是错版本，排查时全被带偏。
 *
 * 「有没有新版」走 GitHub Releases API。这里刻意做三件事：
 *   1. **失败不算错** —— 网络不通/被墙/限流都只报「查不到」，绝不抛给界面；
 *   2. **带上超时** —— 默认 6 秒，避免界面卡在 loading；
 *   3. **只认 prerelease=false** —— 预发布版不提示用户升级。
 *
 * 仓库地址从 package.json 的 `repository` 字段取，避免两处写死不一致。
 */

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

/** 读本包的 package.json（缓存一次；进程生命周期内不会变）。 */
let cachedManifest = null
export function readOwnManifest() {
  if (cachedManifest) return cachedManifest
  try {
    // 本文件位于包根的 src/ 下，所以上跳一级就是 package.json
    const here = path.dirname(fileURLToPath(import.meta.url))
    const file = path.join(here, '..', 'package.json')
    cachedManifest = JSON.parse(fs.readFileSync(file, 'utf8'))
  } catch {
    // 读不到就返回最小占位，绝不因此让插件挂掉
    cachedManifest = { name: 'dsh-workbuddy-fix', version: 'unknown' }
  }
  return cachedManifest
}

/** 当前版本号。 */
export function currentVersion() {
  return String(readOwnManifest().version ?? 'unknown')
}

/**
 * 从 repository 字段解析出 `owner/repo`。
 * 支持 `owner/repo`、`https://github.com/owner/repo.git`、`git+https://...` 三种写法。
 */
export function resolveRepoSlug() {
  const raw = readOwnManifest().repository
  const text = typeof raw === 'string' ? raw : (raw && raw.url) || ''
  const m = String(text).match(/github\.com[/:]([^/]+)\/([^/.#?]+)/i)
  if (m) return `${m[1]}/${m[2]}`
  // 已经就是 owner/repo 形态
  if (/^[\w.-]+\/[\w.-]+$/.test(text)) return text
  return null
}

/**
 * 比较两个 semver（只处理 x.y.z，够本项目用）。
 * @returns {number} a<b 返回 -1，相等 0，a>b 返回 1
 */
export function compareSemver(a, b) {
  const parse = (v) => String(v).replace(/^v/i, '').split('.').map((x) => parseInt(x, 10) || 0)
  const pa = parse(a)
  const pb = parse(b)
  for (let i = 0; i < 3; i += 1) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0)
    if (d !== 0) return d > 0 ? 1 : -1
  }
  return 0
}

/**
 * 查 GitHub 最新 release。
 *
 * 任何异常都收敛成 `{ ok:false, reason }` —— 更新检查失败绝不能
 * 让面板报错或卡住。用户不开代理时 github.com 常常直接超时，
 * 这是**常态**，不是故障。
 *
 * @param {{timeoutMs?:number}} [opts]
 * @returns {Promise<{
 *   ok:boolean, reason?:string,
 *   current:string, latest?:string|null, hasUpdate?:boolean,
 *   url?:string|null, publishedAt?:string|null, name?:string|null
 * }>}
 */
export async function checkForUpdate(opts = {}) {
  const timeoutMs = Number(opts.timeoutMs) > 0 ? Number(opts.timeoutMs) : 6000
  const current = currentVersion()
  const repo = resolveRepoSlug()

  if (!repo) {
    return { ok: false, reason: 'no-repo', current, latest: null, hasUpdate: false }
  }

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, {
      headers: {
        accept: 'application/vnd.github+json',
        // GitHub API 要求 UA，缺失会 403
        'user-agent': `dsh-workbuddy-fix/${current}`,
      },
      signal: controller.signal,
    })
    if (!res.ok) {
      return { ok: false, reason: `http-${res.status}`, current, latest: null, hasUpdate: false }
    }
    const data = await res.json()
    const latest = String(data.tag_name ?? data.name ?? '').replace(/^v/i, '') || null
    return {
      ok: true,
      current,
      latest,
      hasUpdate: latest ? compareSemver(current, latest) < 0 : false,
      url: data.html_url ?? null,
      publishedAt: data.published_at ?? null,
      name: data.name ?? null,
    }
  } catch (error) {
    const reason = error && error.name === 'AbortError' ? 'timeout' : 'network'
    return { ok: false, reason, current, latest: null, hasUpdate: false }
  } finally {
    clearTimeout(timer)
  }
}
