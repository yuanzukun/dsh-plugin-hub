/**
 * OFM pack.js 关键词钩子补丁 —— dsh-workbuddy-fix 自带的独立实现。
 *
 * 本插件**不依赖** dsh-workbuddy-meter，所以这里自带一份最小补丁逻辑
 * （只有「插入一行钩子」这一个能力，没有 meter 的采集补丁）。
 *
 * 两个插件装同一个钩子、同一个锚点、同一个标记。先后打补丁会命中
 * 「已打」直接返回，不会重复插入；先卸载一方也不影响另一方。
 */

import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'

/** 证明钩子那行在位。 */
export const LEXICON_MARKER = '__wbLexicon'

/** 插入锚点：workbuddy 专属的首条 system 兜底块。
 *
 * ⚠️ 版本依赖（2026-10-21 实测，三份 tarball 逐字节比对）：
 *   OFM 2.0.0（npm）      → 锚点命中 0 次，连 `workbuddy`+`system` 的行都是 0 处
 *   OFM 2.1.0（npm 最新）  → 锚点命中 0 次
 *   OFM 2.5.6（GitHub）    → 锚点命中 1 次 ✅
 *
 * 也就是说「workbuddy 补 system」这段代码是 2.1.0 之后才加的，而且**只发在
 * GitHub**（npm 的 latest 停在 2.1.0）。用户装到 2.0/2.1 时，这个锚点根本
 * 不存在 —— 表现为面板一直显示「未打钩子」、点「补打钩子」也无效。
 *
 * 这正是 v1.1.0 把主通道改成 fetch 层的原因：fetch 钩子不依赖任何文件的
 * 结构，OFM 什么版本都能用。本模块保留仅为「非 fetch 请求」兜底。
 */
export const LEXICON_ANCHOR =
  'if (this.product.id === "workbuddy" && (messages.length === 0 || messages[0].role !== "system")) {'

const HOOK_LINE = ';globalThis.__wbLexicon?.rewrite?.(messages);'

/** 保留最近几份 pack.js 备份。每份约 2.9 MB，多了会白占几百 MB。 */
const BACKUPS_TO_KEEP = 2

/**
 * 清理旧的 pack.js 备份，只保留最近 `keep` 份。
 *
 * 为什么需要：每次 pnpm 重装 OFM 都会把 pack.js 换成原始版本，自愈再打一次补丁
 * → 每轮留下一份 2.9 MB 的 `pack.js.wbfix-backup-<时间戳>`，长期累积很可观。
 * 出问题时只需要最近那一份就够回滚了。
 */
function pruneBackups(packFile, keep) {
  try {
    const dir = path.dirname(packFile)
    const base = path.basename(packFile) + '.wbfix-backup-'
    const backups = fs
      .readdirSync(dir)
      .filter((name) => name.startsWith(base))
      .map((name) => ({ name, full: path.join(dir, name) }))
      .sort((a, b) => (a.name < b.name ? 1 : -1)) // 时间戳在文件名里，降序 = 最新在前
    for (const old of backups.slice(keep)) {
      try {
        fs.unlinkSync(old.full)
      } catch { /* 删不掉就算了，不影响主流程 */ }
    }
  } catch { /* 目录读不到也不影响打补丁 */ }
}

export function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex')
}

export function resolveDshHome() {
  const env = String(process.env.DSH_HOME ?? '').trim()
  return env.length > 0 ? env : path.join(os.homedir(), '.dsh')
}

export function resolveOfmDir({ dshHome, profile = 'desktop' } = {}) {
  const home = dshHome ?? resolveDshHome()
  const name = String(profile ?? 'desktop').trim() || 'desktop'
  return path.join(home, 'profiles', name, 'node_modules', 'dsh-our-free-model')
}

export function resolvePackFile(options = {}) {
  return path.join(resolveOfmDir(options), 'vendor', 'channel-pack', 'pack.js')
}

export function countOccurrences(text, needle) {
  let count = 0
  let index = 0
  while ((index = text.indexOf(needle, index)) !== -1) {
    count += 1
    index += needle.length
  }
  return count
}

/** 只读检查，不改文件。 */
export function inspectLexicon(packFile) {
  let text
  try {
    text = fs.readFileSync(packFile, 'utf8')
  } catch (error) {
    return {
      ok: false,
      reason: `pack.js 读取失败：${error instanceof Error ? error.message : String(error)}`,
      patched: false,
      markers: 0,
      anchors: 0,
      sha256: '',
    }
  }
  const markers = countOccurrences(text, LEXICON_MARKER)
  const anchors = countOccurrences(text, LEXICON_ANCHOR)
  return { ok: true, patched: markers > 0, markers, anchors, sha256: sha256(text), text }
}

/**
 * 从 `start` 开始找「花括号配平回到 0」的位置，**跳过字符串/模板串/注释里的括号**。
 *
 * 为什么不能裸数 `{` / `}`：OFM 的 pack.js 是打包产物，锚点块内可能出现
 * `content: "}"`、`` `a ${x} } b` ``、注释里的 `}` 之类的字面量。
 * 裸计数会把它们当成结构括号，导致插入点落到**语句中间**，
 * 把 2.9 MB 的 pack.js 写成非法 JS —— 而写后复验只数 marker 是否存在，
 * 语法坏掉也照样报「成功」。
 *
 * @returns {number} 闭合 `}` 之后的下标；找不到返回 -1
 */
function findBlockEnd(text, start) {
  let depth = 0
  let seen = false
  // 词法状态
  let inLineComment = false
  let inBlockComment = false
  let quote = '' // 当前字符串的引号：' " `
  let escaped = false

  for (let i = start; i < text.length; i += 1) {
    const ch = text[i]
    const next = text[i + 1]

    if (inLineComment) {
      if (ch === '\n') inLineComment = false
      continue
    }
    if (inBlockComment) {
      if (ch === '*' && next === '/') { inBlockComment = false; i += 1 }
      continue
    }
    if (quote !== '') {
      // 字符串内部：只关心闭合引号与转义
      if (escaped) { escaped = false; continue }
      if (ch === '\\') { escaped = true; continue }
      if (ch === quote) { quote = ''; continue }
      // 模板串里的 ${...} 理论上可能嵌套括号，但那个复杂度和风险
      // 远大于收益 —— 真实 OFM 的锚点块内没有这种情况。
      continue
    }

    // 非字符串/注释状态
    if (ch === '/' && next === '/') { inLineComment = true; i += 1; continue }
    if (ch === '/' && next === '*') { inBlockComment = true; i += 1; continue }
    if (ch === "'" || ch === '"' || ch === '`') { quote = ch; continue }

    if (ch === '{') { depth += 1; seen = true } else if (ch === '}') {
      depth -= 1
      if (seen && depth === 0) return i + 1
    }
  }
  return -1
}

/** 找到锚点块的闭合位置，返回插入点。 */
export function findLexiconInsertPoint(text) {
  const anchors = countOccurrences(text, LEXICON_ANCHOR)
  if (anchors !== 1) {
    return { ok: false, reason: `锚点命中 ${anchors} 次（期望 1）—— OFM 版本可能已变` }
  }
  const anchorAt = text.indexOf(LEXICON_ANCHOR)

  // 用词法感知的扫描（跳过字符串/注释里的括号）
  const blockEnd = findBlockEnd(text, anchorAt)
  if (blockEnd < 0) return { ok: false, reason: '无法定位锚点块闭合位置' }

  const lineEnd = text.indexOf('\n', blockEnd)
  const insertAt = lineEnd < 0 ? text.length : lineEnd
  const lineStart = text.lastIndexOf('\n', anchorAt) + 1
  const indent = (text.slice(lineStart).match(/^\s*/) ?? [''])[0]
  return { ok: true, index: insertAt, indent }
}

/**
 * 打钩子。默认 dryRun，显式传 dryRun: false 才落盘。
 * @returns {{applied:boolean, reason?:string, backupPath?:string, sha256Before?:string, sha256After?:string}}
 */
export function applyLexiconPatch({ packFile, dryRun = true } = {}) {
  const file = packFile ?? resolvePackFile()
  const state = inspectLexicon(file)
  if (!state.ok) return { applied: false, reason: state.reason }
  if (state.patched) {
    return { applied: false, reason: 'already-patched', sha256Before: state.sha256, sha256After: state.sha256 }
  }
  const where = findLexiconInsertPoint(state.text)
  if (!where.ok) return { applied: false, reason: where.reason }

  const hook = where.indent + HOOK_LINE
  const nextText = state.text.slice(0, where.index) + '\n' + hook + state.text.slice(where.index)

  if (dryRun) {
    return { applied: false, reason: 'dry-run', sha256Before: state.sha256, sha256After: sha256(nextText) }
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const backupPath = `${file}.wbfix-backup-${stamp}`
  fs.copyFileSync(file, backupPath)
  // 轮转：只保留最近 N 份。pack.js 是 2.9 MB，每装一次 pnpm 就会多一份，
  // 长期累积能吃掉几百 MB。
  pruneBackups(file, BACKUPS_TO_KEEP)
  const tmp = `${file}.wbfix-tmp`
  fs.writeFileSync(tmp, nextText, 'utf8')
  fs.renameSync(tmp, file)

  const after = inspectLexicon(file)
  if (!after.ok || !after.patched) {
    fs.copyFileSync(backupPath, file)
    return { applied: false, reason: '写入后复验失败，已回滚', backupPath }
  }
  // ⚠️ 只数 marker 不够：插入点算错时 marker 还在，但 JS 已经语法非法
  //    （插入点落到语句中间）。这种 pack.js 会让用户的 OFM 直接起不来，
  //    而上面的复验照样通过 —— 必须真做语法检查。
  const syntax = checkSyntax(nextText)
  if (!syntax.ok) {
    fs.copyFileSync(backupPath, file)
    return {
      applied: false,
      reason: `写入后语法检查失败，已回滚：${syntax.reason}`,
      backupPath,
    }
  }
  return { applied: true, backupPath, sha256Before: state.sha256, sha256After: after.sha256 }
}

/**
 * 粗粒度语法检查：用 `new Function` 编一遍。
 *
 * 为什么可用：pack.js 是 ESM 打包产物，但内部大量使用普通函数体；
 * 用 Function 包一层能捕获「括号不配平 / 语句断裂」这类结构性错误。
 * 若真遇到合法的 ESM-only 语法（import/export）导致误报，
 * 会走 `try/catch` 返回 ok（宁可漏报也不阻塞用户）。
 */
function checkSyntax(source) {
  try {
    // 只做解析，不执行。import/export 会让 Function 报错 —— 先剥掉再试。
    const probe = source
      .replace(/^\s*import\s.+$/gm, '')
      .replace(/^\s*export\s+(default\s+)?/gm, '')
    // eslint-disable-next-line no-new-func
    new Function(probe)
    return { ok: true }
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error)
    // 若错误来自 ESM 语法残留（而非本次改写），放行避免误伤
    if (/import|export|await is only valid|Cannot use 'import/.test(msg)) return { ok: true }
    return { ok: false, reason: msg.slice(0, 200) }
  }
}

/**
 * 移除钩子。
 *
 * ⚠️ 只有在本插件是唯一使用者时才该调用：dsh-workbuddy-meter 也依赖同一行，
 * 删掉它会让 meter 的关键词中和失效（虽然 meter 启动时会自愈重打）。
 * 面板上不暴露这个按钮，只在 README 里作为应急手段说明。
 */
export function revertLexiconPatch({ packFile } = {}) {
  const file = packFile ?? resolvePackFile()
  const state = inspectLexicon(file)
  if (!state.ok) return { reverted: false, reason: state.reason }
  if (!state.patched) return { reverted: false, reason: 'not-patched' }
  const nextText = state.text.split('\n').filter((line) => !line.includes(LEXICON_MARKER)).join('\n')
  const tmp = `${file}.wbfix-rev-tmp`
  fs.writeFileSync(tmp, nextText, 'utf8')
  fs.renameSync(tmp, file)
  const after = inspectLexicon(file)
  return { reverted: true, patched: after.ok ? after.patched : true, sha256: after.ok ? after.sha256 : '' }
}
