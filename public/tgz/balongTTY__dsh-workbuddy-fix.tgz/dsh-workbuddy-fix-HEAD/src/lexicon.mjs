/**
 * 关键词风控中和 —— 与 dsh-workbuddy-meter 中的实现**保持逐字节等价**。
 *
 * ## 为什么这里有一份副本
 * 本插件（dsh-workbuddy-fix）刻意**不依赖** dsh-workbuddy-meter：
 * 遇到问题的人应该能只装这个小插件解决，不必先装一整套计量面板。
 *
 * 两个插件通过**共享同一个状态文件**实现联动：
 *   ~/.dsh/workbuddy-meter/lexicon.json
 * 任一方改开关，另一方读到的是同一份配置 —— 一个开，另一个也开。
 * 文件不存在时用默认值（默认开启，符合「装了就想修好」的直觉）。
 *
 * ## 上游为什么拦
 * 腾讯 WorkBuddy / CodeBuddy 网关对 system prompt 做**关键词**内容风控：
 * 命中「DeepSeek Harness」就回 HTTP 400 / code 11128，报文却写成
 * `Illegal API invocation from an unapproved channel`（与渠道无关，纯误导）。
 *
 * 实测（真实 DSH 请求形状：316 tools + effort=max + max_tokens=128000）：
 *   含 "DeepSeek Harness" 原样          → 0/5 全失败
 *   含 "DeepSeek\u200B Harness"（零宽） → 5/5 全通过
 *
 * ## 不能碰文件路径
 * 运行时上下文有 `D:\10_COD\DeepSeek Harness\resources\app.asar\dsh\`。
 * 路径里插零宽字符会让模型把坏路径传给工具调用。用负向断言跳过路径语境。
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

/** 零宽空格：渲染无差别，但上游子串匹配不再命中。 */
export const ZERO_WIDTH_SPACE = '\u200B'

/** 默认配置 —— 与 meter 插件一致。 */
export const LEXICON_DEFAULTS = {
  enabled: true,
  neutralize: true,
  hideIdentity: false,
  ensureSystem: true,
  keywords: ['DeepSeek Harness'],
  // ── v1.2.0 新增 ──────────────────────────────────────────────
  /** 彻底替换关键词（与 neutralize 互斥，开启后优先生效） */
  brandReplace: false,
  /** 替换成什么 */
  replacement: 'CodeBuddy',
  /** 注入人格段（把 agent 伪装成别的产品风格） */
  persona: false,
  /** 人格段内容；空串 = 用内置模板 */
  personaText: '',
}

/**
 * 内置人格模板 —— 从 CodeBuddy 的提示词里挑出的**通用工程行为约束**。
 *
 * 选材原则：只挑跨产品通用的行为准则（减少过度工程、谨慎执行、输出效率），
 * 不抄它跟自身实现耦合的部分（比如它自己的 todo 工具语义）——
 * 后者会在 DSH 里描述不存在的工具行为，反而制造幻觉。
 *
 * 这些段是**追加**在系统提示词末尾的，不替换 DSH 任何既有指令。
 * 所以关掉开关后，下一条请求就完全复原，不会残留任何东西。
 */
export const PERSONA_TEMPLATE = [
  'You are CodeBuddy, a coding agent. The following working principles apply to every task.',
  '',
  '# Tone and style',
  '- Be concise and direct. Answer the question that was asked.',
  '- No preamble ("Great question!", "I will now...") and no postamble ("Let me know if...").',
  '- Use tool calls, not narration, to make progress. One short sentence before a call is enough.',
  '- When referencing code, cite file:line so the user can jump straight there.',
  '- Never claim something works unless you actually ran it or read it.',
  '',
  '# Doing tasks',
  '- Do the simplest thing that fully solves the stated problem.',
  '- Do not add abstractions, config layers, compatibility shims, or one-off helpers that were not asked for.',
  '- Do not add error handling for conditions that cannot happen. Handle the failures that are real.',
  '- Do not refactor adjacent code while fixing a bug. Keep the diff to the problem.',
  '- If the request is ambiguous, make the smallest reasonable assumption and state it in one line.',
  '- Prefer editing existing files over creating new ones.',
  '',
  '# Executing actions with care',
  '- Read a file before editing it. Understand the surrounding code before changing it.',
  '- Never run destructive commands (recursive delete, force push, dropping data) without explicit approval.',
  '- Prefer reversible operations. When an action cannot be undone, say so before taking it.',
  '- After a change, verify it: run the tests, re-read the output, or check the rendered result.',
  '',
  '# Output efficiency',
  '- Lead with the result. Conclusion first, then the evidence.',
  '- Do not paste large blocks of code back to the user. Cite the location instead.',
  '- When a task is done, say what changed and how it was verified. Nothing else.',
].join('\n')

/** 人格段的识别标记 —— 用于幂等（同一条消息不重复注入）。 */
export const PERSONA_MARKER = '<!-- wb400-fix:persona -->'

/** 保底 system：上游要求首条必须是 system prompt。 */
export const FALLBACK_SYSTEM = 'You are a helpful assistant.'

/**
 * 共享状态文件路径。
 * 刻意与 dsh-workbuddy-meter 用同一个文件：这就是两个插件联动的机制。
 */
export function lexiconStatePath(dshHome) {
  const home = dshHome ?? resolveDshHome()
  return path.join(home, 'workbuddy-meter', 'lexicon.json')
}

export function resolveDshHome() {
  const env = String(process.env.DSH_HOME ?? '').trim()
  return env.length > 0 ? env : path.join(os.homedir(), '.dsh')
}

/** 规范化配置，永不抛错（钩子跑在 SSE 流里，抛错会中断请求）。 */
export function normalizeLexiconConfig(raw) {
  const input = typeof raw === 'object' && raw !== null ? raw : {}
  const keywords = Array.isArray(input.keywords)
    ? input.keywords.filter((k) => typeof k === 'string' && k.trim().length > 0).map((k) => k.trim())
    : LEXICON_DEFAULTS.keywords
  return {
    enabled: input.enabled !== false,
    neutralize: input.neutralize !== false,
    hideIdentity: input.hideIdentity === true,
    ensureSystem: input.ensureSystem !== false,
    keywords: keywords.length > 0 ? keywords : LEXICON_DEFAULTS.keywords,
    brandReplace: input.brandReplace === true,
    replacement: typeof input.replacement === 'string' && input.replacement.trim().length > 0
      ? input.replacement.trim()
      : LEXICON_DEFAULTS.replacement,
    persona: input.persona === true,
    // 人格段有长度上限：塞太长会挤占上游上下文预算
    personaText: typeof input.personaText === 'string'
      ? input.personaText.slice(0, 8000)
      : '',
  }
}

/** 读共享配置；文件不存在或损坏时回落默认值。 */
export function readLexiconConfig(dshHome) {
  try {
    return normalizeLexiconConfig(JSON.parse(fs.readFileSync(lexiconStatePath(dshHome), 'utf8')))
  } catch {
    return normalizeLexiconConfig(LEXICON_DEFAULTS)
  }
}

/**
 * 写共享配置（原子落盘）。
 * 用 tmp + rename，避免另一个插件恰好读到半截 JSON。
 */
export function writeLexiconConfig(dshHome, next) {
  const normalized = normalizeLexiconConfig(next)
  const file = lexiconStatePath(dshHome)
  fs.mkdirSync(path.dirname(file), { recursive: true })
  const tmp = `${file}.fix-tmp`
  fs.writeFileSync(tmp, `${JSON.stringify(normalized, null, 2)}\n`, 'utf8')
  fs.renameSync(tmp, file)
  return normalized
}

function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

/**
 * 关键词匹配器：关键词内部允许任意空白，
 * 但**前后不能是路径分隔符** —— 否则会把 `D:\...\DeepSeek Harness\...` 改坏。
 */
export function buildKeywordPattern(keyword) {
  const parts = keyword.split(/\s+/).filter(Boolean).map(escapeRegExp)
  if (parts.length === 0) return null
  return new RegExp(`(?<![\\\\/])${parts.join('[ \\u00A0]+')}(?![\\\\/])`, 'g')
}

/** 中和单个字符串。
 *
 * 两条**互斥**的路径，由 `brandReplace` 决定走哪条：
 *
 *   A. 无损中和（brandReplace=false，默认）
 *      插零宽空格。原文完整保留、语义不变、肉眼可辨 —— 只是为了绕过子串匹配。
 *
 *   B. 彻底替换（brandReplace=true）
 *      把关键词整段换成 `config.replacement`（默认 CodeBuddy）。
 *      视觉上也变了，适用于「让这个 agent 看起来就不像 DSH」的场景。
 *
 * 两者都只作用于**本次请求的内存副本**，磁盘上什么都没有改 ——
 * 关掉开关，下一条请求就完全复原。
 */
export function neutralizeText(text, config) {
  if (typeof text !== 'string' || text.length === 0) return { text, hits: 0 }
  let out = text
  let hits = 0

  // B 路径：彻底替换
  if (config.brandReplace) {
    for (const keyword of config.keywords) {
      const pattern = buildKeywordPattern(keyword)
      if (pattern === null) continue
      out = out.replace(pattern, () => {
        hits += 1
        return config.replacement
      })
    }
    // 单独出现的 DeepSeek 也一起换掉（否则「powered by DeepSeek」还留着痕迹）
    if (config.hideIdentity) {
      out = out.replace(/(?<![\\/])DeepSeek(?![\\/])/g, () => {
        hits += 1
        return config.replacement
      })
    }
    return { text: out, hits }
  }

  // A 路径：无损中和
  for (const keyword of config.keywords) {
    const pattern = buildKeywordPattern(keyword)
    if (pattern === null) continue
    out = out.replace(pattern, (match) => {
      hits += 1
      return match.split(/[ \u00A0]+/).join(ZERO_WIDTH_SPACE + ' ')
    })
    if (config.hideIdentity) {
      out = out.replace(/(?<![\\/])DeepSeek(?![\\/])/g, 'Deep' + ZERO_WIDTH_SPACE + 'Seek')
    }
  }
  return { text: out, hits }
}

/** 递归改写一条 message 的所有字符串字段（content 可能是 string 或 parts 数组）。
 *
 * 返回 `{ hits, changed }`：
 *   - `hits`    只统计关键词命中数（面板显示用，语义不变）
 *   - `changed` 表示是否真的改动了文本
 * 两者必须分开：`hideIdentity`（把 DeepSeek 拆成 Deep<ZW>Seek）不递增 hits，
 * 但确实改了文本。早先用 `hits > 0` 决定写回，导致纯 hideIdentity 的改动被
 * 静默丢弃 —— 表现为该开关「时灵时不灵」（文本恰好也含关键词组合时才顺带生效）。
 */
export function neutralizeMessage(message, config) {
  if (message === null || typeof message !== 'object') return { hits: 0, changed: false }
  let hits = 0
  let changed = false
  for (const key of Object.keys(message)) {
    const value = message[key]
    if (typeof value === 'string') {
      const r = neutralizeText(value, config)
      if (r.text !== value) { message[key] = r.text; hits += r.hits; changed = true }
    } else if (Array.isArray(value)) {
      for (let i = 0; i < value.length; i += 1) {
        const item = value[i]
        if (typeof item === 'string') {
          const r = neutralizeText(item, config)
          if (r.text !== item) { value[i] = r.text; hits += r.hits; changed = true }
        } else if (item !== null && typeof item === 'object') {
          const sub = neutralizeMessage(item, config)
          hits += sub.hits
          if (sub.changed) changed = true
        }
      }
    } else if (value !== null && typeof value === 'object') {
      const sub = neutralizeMessage(value, config)
      hits += sub.hits
      if (sub.changed) changed = true
    }
  }
  return { hits, changed }
}

/** 对整份 messages 做中和 + 首条 system 兜底 + 人格注入。永不抛错。 */
export function rewriteMessages(messages, rawConfig) {
  const config = normalizeLexiconConfig(rawConfig)
  if (!config.enabled) return { hits: 0, injected: false, personaApplied: false, changed: false, skipped: true }
  if (!Array.isArray(messages)) return { hits: 0, injected: false, personaApplied: false, changed: false }

  // `hits` 只统计「关键词命中数」（面板要显示这个语义）。
  // `changed` 单独判断 —— hideIdentity 这类改写不增加 hits，但确实改了文本，
  // 只看 hits 会让它的改动被下游（fetch-hook）当成没改而丢弃。
  let hits = 0
  let changed = false
  if (config.neutralize) {
    for (let i = 0; i < messages.length; i += 1) {
      const r = neutralizeMessage(messages[i], config)
      hits += r.hits
      if (r.changed) changed = true
    }
  }

  // 人格注入：追加到第一条 system 消息末尾。
  // ⚠️ 只**追加**，不替换 DSH 的任何既有指令 —— 所以关掉开关后完全复原。
  //    用固定分隔标记，方便识别「这条消息已经被注入过」（幂等，不重复叠加）。
  let personaApplied = false
  if (config.persona) {
    const text = (config.personaText && config.personaText.trim()) || PERSONA_TEMPLATE
    const marker = PERSONA_MARKER
    const first = messages[0]
    if (first && typeof first === 'object' && first.role === 'system'
        && typeof first.content === 'string' && !first.content.includes(marker)) {
      first.content = first.content + '\n\n' + marker + '\n' + text
      personaApplied = true
      changed = true
    } else if (!first || first.role !== 'system') {
      // 没有 system 头：新建一条（后面 ensureSystem 不会再插）
      messages.unshift({ role: 'system', content: marker + '\n' + text })
      personaApplied = true
      changed = true
    }
  }

  let injected = false
  if (config.ensureSystem) {
    const head = messages[0]
    if (head === undefined || head === null || head.role !== 'system') {
      messages.unshift({ role: 'system', content: FALLBACK_SYSTEM })
      injected = true
    }
  }
  return { hits, injected, personaApplied, changed: changed || injected }
}

/**
 * 安装 `globalThis.__wbLexicon`。
 *
 * 与 dsh-workbuddy-meter 用**同一个全局名与同一个方法签名** `rewrite(messages)`，
 * 所以 pack.js 里那一行钩子对两个插件都有效。两个插件同时安装时：
 *   - 后装的会覆盖先装的；
 *   - 但两者都读同一个配置文件，行为完全一致，谁在都一样；
 *   - 卸载时会检查 `=== hook` 才删除，不会把对方的钩子误删。
 */
export function installLexiconHook({ getConfig, onStats, logger }) {
  const hook = {
    rewrite(messages) {
      try {
        const config = normalizeLexiconConfig(getConfig())
        if (!config.enabled) return
        const result = rewriteMessages(messages, config)
        if (result.hits > 0 || result.injected) onStats?.(result)
      } catch (error) {
        logger?.debug?.(`workbuddy-fix: rewrite failed (${error instanceof Error ? error.message : String(error)})`)
      }
    },
  }
  globalThis.__wbLexicon = hook
  return () => {
    if (globalThis.__wbLexicon === hook) delete globalThis.__wbLexicon
  }
}
