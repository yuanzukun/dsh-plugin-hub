/**
 * fetch 层钩子 —— 不依赖 OFM 的 pack.js，直接包 globalThis.fetch。
 *
 * 为什么不用 pack.js：
 *   pack.js 的钩子需要「插一行到别人打包产物里」，任何 OFM 升级改结构、
 *   换打包工具、或用户装了别的 WB 反代插件（不是 OFM），那行就插不进去。
 *   对接方反馈的「一直显示钩子没打上」就是这种情况。
 *
 * 这个实现只做一件事：在 fetch 发出前，把 chat/completions 请求体里的
 * messages 交给 rewrite()。它不看 OFM 版本、不碰任何第三方文件，
 * 所以对「任何走 fetch 打 WorkBuddy/CodeBuddy 的插件」都成立。
 *
 * 安全边界（重要）：
 *   ① 只在 URL 命中 WB 域名时介入，其它请求原样透传（零开销、零影响）
 *   ② 只处理 POST + JSON body，其它形态完全不碰
 *   ③ body 解析失败就原样放行，绝不让插件因本插件而崩
 *   ④ rewrite 抛错也原样放行
 *   ⑤ 可完整卸载（restore 原 fetch 引用）
 */

/** 命中这些主机名才算 WB 系请求。
 *
 * 清单来源：2026-10-21 从两个第三方反代插件的产物里扫出实际端点，不是猜的。
 *   dsh-our-free-model 2.5.6 → copilot.tencent.com / www.workbuddy.ai /
 *                              www.codebuddy.ai / www.codebuddy.cn
 *   dsh-connect-workbuddy 4.11.0 → 上述四个 + **www.workbuddy.cn**
 *
 * 按后缀匹配（见 isWorkBuddyUrl），所以写 'workbuddy.ai' 可覆盖
 * www./api./任意子域，但**不覆盖 .cn** —— 那是独立后缀，必须单列。
 */
const WB_HOSTS = [
  'copilot.tencent.com',
  'workbuddy.ai',
  'workbuddy.cn',
  'codebuddy.ai',
  'codebuddy.cn',
]

/** 导出供测试与诊断核对实际生效的白名单。 */
export { WB_HOSTS }

/** 只看这些路径，避免误伤同域其它接口。 */
const CHAT_PATHS = ['/chat/completions', '/v1/chat/completions', '/completions']

function hostOf(url) {
  try {
    return new URL(url).hostname.toLowerCase()
  } catch {
    return ''
  }
}

function isWorkBuddyUrl(url, hosts = WB_HOSTS) {
  const host = hostOf(url)
  if (!host) return false
  if (!hosts.some((h) => host === h || host.endsWith(`.${h}`))) return false
  const lower = String(url).toLowerCase()
  return CHAT_PATHS.some((p) => lower.includes(p))
}

/** 把 input 归一成 { url, init }。fetch(input, init) 两种形态都要支持。 */
function normalize(input, init) {
  if (typeof input === 'string') return { url: input, init: init ?? {} }
  if (input instanceof URL) return { url: input.toString(), init: init ?? {} }
  if (input && typeof input === 'object' && typeof input.url === 'string') {
    // Request 对象：method/body 都挂在它自己身上
    return { url: input.url, init: init ?? {}, request: input }
  }
  return { url: '', init: init ?? {} }
}

/**
 * 装钩子。
 * @param {object} opts
 * @param {() => any} opts.getConfig   返回 { enabled, neutralize, ensureSystem, hideIdentity }
 * @param {(messages:any[]) => any} opts.rewrite  真正做改写的函数
 * @param {(r:{hits:number,injected:boolean}) => void} [opts.onStats]
 * @param {object} [opts.logger]
 * @param {string[]} [opts.extraHosts]  额外的 WB 主机名（测试用，或适配新域名）
 * @param {boolean} [opts.cloneBodyForRequest]  Request 形态是否强制 clone 读体（默认 true）
 * @returns {() => void} 卸载函数
 */
/**
 * 模块级单例：同一个进程里只允许存在**一个** wrapper。
 *
 * 为什么必须是单例（这是修过的一个真 bug）：
 *   HMR / removeBundle→installBundle 会让「新实例 apply」与「旧实例 dispose」
 *   交叠，而且顺序不保证。若每个实例各自造 wrapper：
 *     新实例看到已包装 → 返回空卸载函数（以为自己不用管）
 *     旧实例 dispose  → globalThis.fetch === 旧 wrapper 成立 → 还原成原始 fetch
 *     → 结果：新实例以为装好了，实际 fetch 已经没人包装，功能静默失效。
 *
 * 用「共享 wrapper + 引用计数」后，无论 dispose/apply 什么顺序：
 *   apply  → 计数 +1，把共享 wrapper 挂上去（幂等）
 *   dispose→ 计数 -1，只有归零时才真正还原
 * 而且所有实例共享**同一份**回调，后 apply 的实例会更新回调（热重载后走新代码）。
 */
const shared = {
  /** 原始 fetch（第一次安装时捕获） */
  original: null,
  /**
   * 「原始之上」的兜底 fetch —— **永不从全局重新读取**。
   *
   * 环保护必须有一个不会被别的插件改写、也不会指回我们自己的终点引用。
   * `globalThis.fetch` 和 `shared.original` 都不可靠（前者随时被换，
   * 后者在链式场景下可能本身就是我们的上游包装）。这个字段在装钩子那一刻
   * 定下，之后只读不改，是唯一的「安全出口」。
   */
  pristine: null,
  /** 当前挂上去的共享 wrapper */
  wrapped: null,
  /** 活跃实例数 */
  refs: 0,
  /** 当前生效的回调（最后一次 apply 的实例获胜） */
  handlers: null,
  /**
   * 当前**同步嵌套深度**。
   *
   * ⚠️ 单独用它**不足以**防住环路（2026-10-22 对抗测试抓到）：
   * 环路上的每一跳是先 `depth += 1` 再「返回 tail」，而 `finally` 的
   * `-= 1` 在返回到同一帧时就执行了 —— 深度会在阈值附近来回振荡，
   * 但**同步调用栈本身仍在无限加高**。所以必须配合下面的 `chain`。
   */
  depth: 0,
  /**
   * ★★环路兜底的**唯一可靠终点**：本进程里有史以来第一次安装钩子之前
   * 的那份 `globalThis.fetch`。
   *
   * 为什么它一定安全：
   *   捕获它的那一刻，我们的任何一个 wrapper 都还不存在，所以它**不可能**
   *   是我们的 wrapper（也不可能是转发到我们的包装，因为那时没我们）。
   *   它只在 `shared.native === null` 时写入一次，之后**永不覆盖**。
   *
   * 这是 2026-10-22 对抗测试的结论：环形成后，`tail`、`shared.pristine`
   * 都可能就在环上（重装时它们都是「当前全局 fetch」，而当前全局 fetch
   * 可能正是那个转回我们的包装）。只有 `native` 不在环上。
   */
  native: null,
  /**
   * ★环路判据：**同步**递归深度。
   *
   * 关键：只在**同步段**累加，一旦遇到 `await` 就先把计数还回去，让出
   * 控制权期间不计入。这样：
   *   - 正常并发：N 个请求各自 await，同步段互不重叠 → 深度永远是 1。
   *   - 真环路：`wrapper → tail → wrapper → …` 全是同步调用，
   *     没有 await 让出点 → 深度瞬间冲到上限。
   *
   * 2026-10-22 实测教训：上一版把「整个 await 期间」都算进深度，
   * 200 并发时深度峰值 = 200 > 20 → 180 个请求被误判成环路、丢给原生
   * fetch 跳过改写 = **高并发下改写静默失效**（比崩溃更隐蔽）。
   */
  syncDepth: 0,
  /**
   * 已退役的 wrapper 集合。
   *
   * 热重载会造出**新的** wrapper，但旧的仍然活着 —— 别的插件可能在自己的
   * 闭包里抓着它（`const p = fetch; fetch = (i,n) => p(i,n)`）。旧 wrapper
   * 如果继续读 `shared.pristine`，就会读到「新一轮」的上游，而那个上游
   * 内部又转回旧 wrapper → 环路 → 栈溢出（2026-10-22 真实崩溃）。
   *
   * 退役后旧 wrapper 只走它**自己安装时捕获的那份 tail**，永不再读共享状态，
   * 因此结构上不可能成环。
   */
  retired: new WeakSet(),
}

/**
 * 环保护阈值。正常并发最多 3~5 个在建请求，真正的环路一秒能堆几万层，
 * 20 层既不会误判并发、也不会放过环路。
 */
const MAX_DEPTH = 20

export function installFetchHook({
  getConfig,
  rewrite,
  onStats,
  logger = {},
  extraHosts = [],
}) {
  const hosts = extraHosts.length > 0 ? [...WB_HOSTS, ...extraHosts] : WB_HOSTS

  // 已经初始化过：复用同一个 wrapper，只更新回调 + 加引用计数
  if (shared.wrapped !== null) {
    shared.refs += 1
    shared.handlers = { getConfig, rewrite, onStats, logger, hosts }

    /* 🔴 绝不在复用分支里「抢回最外层」。
     *
     * 这是 2026-10-22 第三次真实崩溃的根因（前两次见 CHANGELOG v1.2.2）。
     * v1.2.2 删掉了独立的 reassertFetchHook()，但**同一段逻辑还藏在这里**：
     *   if (globalThis.fetch !== shared.wrapped) {
     *     shared.wrapped.__wbFixPrev = globalThis.fetch   // ← 把外部函数记成上游
     *     globalThis.fetch = shared.wrapped               // ← 抢回最外层
     *   }
     *
     * 为什么必然炸：热重载每 apply 一次就走一遍。若别的插件是
     *   const p = globalThis.fetch            // ← 抓到我们的 wrapper
     *   globalThis.fetch = (i,n) => p(i,n)
     * 那么抢回最外层 + 改写 __wbFixPrev 之后：
     *   我们的 wrapper → __wbFixPrev(对方) → p(仍是我们的 wrapper) → …∞
     *
     * 现在这个分支**一个字节都不碰 globalThis.fetch**，只更新回调与计数。
     * 别人的包装留在外面也无妨：它在链上转发时会进到我们，改写照常生效。
     */
    logger.debug?.(`workbuddy-fix: 复用已有 fetch 钩子（refs=${shared.refs}，不改写 globalThis.fetch）`)
    return makeUninstall(logger)
  }

  const original = globalThis.fetch
  if (typeof original !== 'function') {
    logger.warn?.('workbuddy-fix: globalThis.fetch 不存在，跳过 fetch 钩子')
    return () => {}
  }

  /* ★每一代 wrapper 都捕获**自己这一代**的上游 tail（不可变闭包）。
   *
   * 这是 2026-10-22 崩溃的根治点。事故链条：
   *   ① 别的插件包在我们外面，闭包抓着旧 wrapper：
   *        const p = fetch;  fetch = (i,n) => p(i,n)
   *   ② 热重载 → uninstall 时 `globalThis.fetch === shared.wrapped` 为假
   *      （最外层是对方），所以**不还原**；对方继续包着旧 wrapper。
   *   ③ 重装时 `original = globalThis.fetch` 抓到的是**对方**，
   *      于是新一代的 pristine = 对方。
   *   ④ 旧 wrapper 仍读 `shared.pristine` → 读到「对方」，
   *      而对方闭包里是旧 wrapper → 旧→对方→旧… ∞ 栈溢出。
   *
   * 修法：wrapper 只认自己那份 `tail`，退役后连 `shared` 都不读。
   */
  const tail = pickSafeTail(original, shared.retired)

  const wrapped = function wbFixFetch(input, init) {
    /* 已退役（被热重载换掉）：只走自己捕获的 tail。
     * 绝不读 shared.* —— 读了就可能连到新一代而闭环。 */
    if (shared.retired.has(wrapped)) {
      if (typeof tail === 'function') return tail(input, init)
      return Promise.resolve(
        new Response(
          JSON.stringify({ error: { message: 'workbuddy-fix: 已退役的钩子无可用上游' } }),
          { status: 502, headers: { 'content-type': 'application/json' } },
        ),
      )
    }

    /* ★环路保护：只统计**同步**进入次数。
     *
     * 为什么必须是同步：wrapper 返回 Promise，`await` 期间控制权让出，
     * 并发请求会叠加在「在飞计数」上。上一版把整个 await 期都算进深度，
     * 200 并发时深度峰值 200 > 阈值 20 → 180 个请求被误判成环路、
     * 丢给原生 fetch 跳过改写 = **高并发下改写静默失效**（2026-10-22 实测）。
     *
     * 现在的做法：本函数**同步执行到 return**（不 await），所以计数器
     * 在返回 Promise 前就已归零。真正的环路是纯同步调用（没有 await 让出点），
     * 计数器会瞬间冲到上限。
     */
    if (shared.syncDepth >= MAX_DEPTH) {
      return Promise.resolve(loopFallback(input, init))
    }

    // 每次调用都读最新的 handlers —— 热重载后自动走新代码
    const h = shared.handlers
    if (h === null) {
      if (typeof tail === 'function') return tail(input, init)
      return Promise.resolve(new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }))
    }

    shared.syncDepth += 1
    try {
      /* ⚠️ 注意这里是**同步**调用 handleRequest（它内部才 await）。
       * 在 finally 里立刻 decrement —— 此时 handleRequest 已经返回了
       * Promise、控制权即将让出，同步段结束。 */
      return handleRequest(input, init, h, tail)
    } finally {
      shared.syncDepth -= 1
    }
  }

  /**
   * 环路兜底：只用 `native`（第一次安装前的原始 fetch）。
   *
   * 它不在环上，也永远不会成为环的一部分。哪怕它已经被别的插件换掉、
   * 甚至已经是别的插件包装 —— 那也是"别人的正常包装"，不会转回我们，
   * 因为我们的 wrapper 在捕获 native 时还不存在。
   */
  function loopFallback(input, init) {
    if (typeof shared.native === 'function') return shared.native(input, init)
    return new Response(
      JSON.stringify({ error: { message: 'workbuddy-fix: fetch 调用链出现环路，已中止以避免崩溃' } }),
      { status: 500, headers: { 'content-type': 'application/json' } },
    )
  }

  /** 真正的处理逻辑（拆出来是为了让上面那个环保护能优雅地包住它）。 */
  const handleRequest = async function (input, init, h, tail) {
    /* 上游 fetch：只用这一代 wrapper 自己的 tail（闭包捕获，不可变）。
     *
     * 历史教训（2026-10-22 崩溃）：上一版读 `shared.pristine`，而 pristine
     * 在重装时会被改写成「当前全局 fetch」—— 热重载后全局 fetch 可能就是
     * 抓着旧 wrapper 的别人的包装 → 环路。
     * tail 与 shared 完全解耦，结构上不可能连到别的代。
     */
    const upstream = tail
    if (typeof upstream !== 'function') {
      /* 绝不 throw —— 这个函数是 async 的，throw 会变成 rejected promise；
       * 宿主若没接住就是 unhandledRejection，而崩溃日志里
       * `Exception in PromiseRejectCallback` 正是这个模式。 */
      return new Response(
        JSON.stringify({ error: { message: 'workbuddy-fix: 上游 fetch 不可用，已跳过' } }),
        { status: 502, headers: { 'content-type': 'application/json' } },
      )
    }

    // ⚠️ 顺序很重要：先做「零成本」的 URL/method 判定，命中目标后才读配置。
    //   getConfig() 每次都同步读盘（实测 0.068 ms/次），
    //   放在最前面会让宿主所有插件的**每一次** fetch（含完全无关的域名）
    //   都白付这个开销。
    let url = ''
    let nextInit = init
    let request = null
    try {
      const n = normalize(input, init)
      url = n.url
      nextInit = n.init
      request = n.request
    } catch {
      return upstream(input, init)
    }

    if (!isWorkBuddyUrl(url, h.hosts)) return upstream(input, init)

    // 只处理 POST + JSON
    const method = String((nextInit?.method ?? request?.method ?? 'GET')).toUpperCase()
    if (method !== 'POST') return upstream(input, init)

    // 到这里才值得读配置（开销只落在真正的 WB chat 请求上）
    let cfg
    try {
      cfg = h.getConfig()
    } catch {
      cfg = null
    }
    if (!cfg || cfg.enabled === false) return upstream(input, init)

    // 取 body 文本
    let bodyText = null
    try {
      if (typeof nextInit?.body === 'string') {
        bodyText = nextInit.body
      } else if (request && typeof request.clone === 'function') {
        bodyText = await request.clone().text()
      }
    } catch {
      return upstream(input, init)
    }
    if (typeof bodyText !== 'string' || bodyText.length === 0) {
      return upstream(input, init)
    }

    // 解析 + 改写
    let payload
    try {
      payload = JSON.parse(bodyText)
    } catch {
      return upstream(input, init) // 不是 JSON，原样放行
    }
    if (!payload || !Array.isArray(payload.messages)) return upstream(input, init)

    let result
    try {
      result = h.rewrite(payload.messages)
    } catch (error) {
      h.logger.debug?.(
        `workbuddy-fix: rewrite 抛错，原样放行（${error instanceof Error ? error.message : String(error)}）`,
      )
      return upstream(input, init)
    }
    if (!result || (!result.changed && !result.injected)) return upstream(input, init)

    try {
      h.onStats?.({ hits: result.hits ?? 0, injected: Boolean(result.injected) })
    } catch {
      /* 统计失败不影响主流程 */
    }

    // 重建 init：body 换成改写后的文本，Content-Length 必须去掉（长度变了）
    const headers = new Headers(nextInit?.headers ?? request?.headers ?? undefined)
    headers.delete('content-length')
    // 只在调用方没指定 charset 时才补 content-type，避免无谓改写原有头
    if (!headers.has('content-type')) headers.set('content-type', 'application/json')

    const rebuilt = {
      ...(nextInit ?? {}),
      method: 'POST',
      headers,
      // ⚠️ 这里必须用 rewrite 就地改过的 payload.messages —— h.rewrite() 是原地修改
      // 传入数组的，所以 payload.messages 已经是改写后的内容。整包重新序列化即可。
      body: JSON.stringify(payload),
    }
    // ⚠️ Request 形态下 signal 挂在 request.signal 上，不在 init 里。
    // 不复制过去的话，「停止生成」/AbortSignal.timeout 对改写后的请求完全失效
    // —— 请求会继续跑完、继续烧上游额度。init 显式传的 signal 优先。
    if (rebuilt.signal === undefined && request?.signal) rebuilt.signal = request.signal
    // Request 形态下原始 body 已被读走，必须用 url 重新发起
    return request ? upstream(url, rebuilt) : upstream(input, rebuilt)
  }

  // 首次安装：初始化单例
  shared.original = original
  /* ★native 只写一次，永不覆盖。
   *
   * 它是「本进程第一次装钩子之前的 fetch」= 绝对不在我们任何环路上的
   * 终点。热重载时 globalThis.fetch 可能已被别的插件换成转回我们的包装，
   * 所以**不能**每次安装都刷它（刷了就等于把环路终点变成环上节点）。
   * 这正是 2026-10-22 崩溃的教训。
   */
  if (shared.native === null && typeof original === 'function') {
    shared.native = original
  }
  // pristine = 这一代的直接上游（可能被别的插件包着，但不会是「未来」的包装）
  shared.pristine = typeof original === 'function' ? original : null
  shared.wrapped = wrapped
  shared.refs = 1
  shared.handlers = { getConfig, rewrite, onStats, logger, hosts }

  wrapped.__wbFixWrapped = true
  /* ★把本代的 tail 也挂在 wrapper 上（只读标记，之后永不改写）。
   *
   * 用途：HMR 重新评估模块后，下一代 `original` 会是我们这一个 wrapper；
   * 下一代靠读这个字段才能穿透到真正的上游，否则 tail=null →
   * 所有请求 502（2026-10-22 实测复现的灾难性回归）。
   *
   * ⚠️ 与已废弃的 `__wbFixPrev` 的关键区别：
   *   `__wbFixPrev` 曾被**反复改写成当前全局 fetch**，于是指向了会转回
   *   我们的包装 → 环路。这个 `__wbFixTail` 是**闭包捕获的 immutable 值**，
   *   写完就再也不动，而且都指向「安装时那一刻」的上游，结构上更早、
   *   不可能包含我们。
   */
  wrapped.__wbFixTail = tail

  globalThis.fetch = wrapped
  logger.info?.('workbuddy-fix: fetch 层钩子已安装（不依赖 pack.js）')

  return makeUninstall(logger)
}

/**
 * 挑一个安全的上游 tail（能穿透「我们自己的旧 wrapper」）。
 *
 * ## 为什么必须"穿透"
 *
 * HMR 会**重新评估模块**：新的 `shared` 是空对象，但 `globalThis.fetch`
 * 仍指向**上一个模块代**的 wrapper。此时：
 *   original = globalThis.fetch = 旧 wrapper（带 __wbFixWrapped 标记）
 *
 * 如果这时直接返回 null，本代 `tail = null` → handleRequest 里 upstream 为
 * null → **所有 WB 请求返回 502**。2026-10-22 实测复现：HMR 之后插件
 * 完全不可用，用户侧表现为「请求被拦截 Illegal API invocation」。
 *
 * 正确做法：旧 wrapper 自带 `__wbFixTail`（它自己安装时捕获的上游），
 * 顺着它往下走到真正的终点。旧 wrapper 退役后走的也正是这条，
 * 所以穿透到的是同一条链，**不会重复改写、也不会成环**（每跳都检查标记）。
 *
 * @param {any} candidate 候选上游
 * @param {WeakSet} retiredSet 已退役集合
 * @param {number} depth 递归保护，最多穿透 8 层（正常最多 2~3 代）
 */
function pickSafeTail(candidate, retiredSet, depth = 0) {
  if (typeof candidate !== 'function') return null
  if (depth > 8) return null // 防御：异常的深层嵌套

  // 这是我们自己的 wrapper（任意代）→ 穿透到它捕获的 tail
  if (candidate.__wbFixWrapped === true) {
    const inner = candidate.__wbFixTail
    if (inner === candidate) return null // 自指，绝不跟随
    return pickSafeTail(inner, retiredSet, depth + 1)
  }
  if (retiredSet && retiredSet.has(candidate)) {
    // 已退役但没有标记（理论上不该出现）→ 同样尝试穿透
    const inner = candidate.__wbFixTail
    if (typeof inner !== 'function' || inner === candidate) return null
    return pickSafeTail(inner, retiredSet, depth + 1)
  }
  return candidate
}

/**
 * 生成卸载函数：只减引用计数，归零才真正还原 fetch。
 *
 * 这样无论 dispose/apply 以什么顺序交错，都不会出现
 * 「新实例以为装好了、旧实例把它拆了」的死区。
 */
function makeUninstall(logger) {
  let done = false
  return () => {
    if (done) return // 幂等：同一个卸载函数调两次不该减两次计数
    done = true
    shared.refs -= 1
    if (shared.refs > 0) {
      logger.debug?.(`workbuddy-fix: 还有 ${shared.refs} 个实例在用，保留钩子`)
      return
    }
    /* ★关键：先把这一代 wrapper 标记为退役，再清共享状态。
     *
     * 退役后旧 wrapper 只走它自己捕获的 tail，绝不读 shared.* ——
     * 这样即使别的插件仍在闭包里抓着它，也不会连到下一代形成环路。
     * （2026-10-22 崩溃正是「旧 wrapper 读 shared.pristine → 读到新一代」
     *   造成的无限递归。）
     */
    if (shared.wrapped !== null) shared.retired.add(shared.wrapped)

    // 最后一个实例退出：真正还原。
    // 只用 original，不再看 `__wbFixPrev` —— 后者已废弃（是环路的载体）。
    if (globalThis.fetch === shared.wrapped) {
      globalThis.fetch = shared.original
    }
    shared.original = null
    shared.pristine = null
    shared.wrapped = null
    shared.handlers = null
    shared.syncDepth = 0
    shared.refs = 0
    /* ⚠️ **不清 shared.native**。
     * 它是「本进程第一次安装前的原始 fetch」，是环路唯一的可靠终点。
     * 清掉的话，下一次安装时 globalThis.fetch 可能已是别人的包装
     * （甚至转回我们的旧 wrapper），就没有安全出口了。
     * 它只写一次、只读，留着无任何副作用。 */
    logger.info?.('workbuddy-fix: fetch 层钩子已卸载')
  }
}

/**
 * 供诊断用：当前 fetch 是否被本插件包装在最外层。
 *
 * ⚠️ 返回 false **不代表改写失效**。
 *
 * DSH 启动时十几个插件按各自顺序 apply，任何在我们之后覆盖
 * `globalThis.fetch` 的插件都会把我们挤到内层 —— 但绝大多数包装都是
 * 「先存旧的、调用时再转发」的链式实现，所以我们的 wrapper 仍然在链上、
 * 仍然会被调用，改写照常生效。只有 `fetchHookInstalled` 这个"是不是最外层"
 * 的观测值会变成 false。
 *
 * v1.2.2 之前这里有个 `reassertFetchHook()` 想把它抢回最外层，
 * 结果造成 **栈溢出崩溃**（2026-10-21 实测）：若对方是 `const p = fetch;
 * fetch = (i,n) => p(i,n)` 这种捕获我们之后再转发的写法，抢回最外层会让
 * `我们的 wrapper → 对方 → 我们的 wrapper` 无限递归。已彻底移除。
 */
export function isFetchHookInstalled() {
  return globalThis.fetch?.__wbFixWrapped === true
}

/**
 * 诊断快照：主通道当前处于什么状态。
 *
 * 用途是让面板能说清「为什么显示未接管但功能其实是好的」，
 * 而不是让用户以为坏了。
 *
 * @returns {{
 *   installed:boolean,     // 我们是否在最外层
 *   chained:boolean,       // 我们不在最外层，但仍在调用链上（功能正常）
 *   reason:'active'|'chained'|'disposed'|'never-installed'
 * }}
 */
export function getFetchHookStatus() {
  if (shared.wrapped === null) {
    return { installed: false, chained: false, reason: 'never-installed' }
  }
  if (globalThis.fetch === shared.wrapped) {
    return { installed: true, chained: true, reason: 'active' }
  }
  // 不在最外层：可能被别的插件包了一层（链式，功能仍然正常），
  // 也可能被彻底替换掉了（真的失效）。两种都无法从外部区分，
  // 只能报告「不在最外层」这个事实，不猜测。
  return { installed: false, chained: false, reason: 'chained' }
}
