# WorkBuddy 400 错误修复 · unapproved channel (code 11128) · DSH 插件

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](./LICENSE)
[![fix](https://img.shields.io/badge/fix-unapproved%20channel%20400-orange)](#-如果你是因为这个报错搜到这里)
[![DSH](https://img.shields.io/badge/DeepSeek%20Harness-plugin-5B8DEF)](https://github.com/balongTTY/dsh-workbuddy-meter)

> **一键修复** WorkBuddy / CodeBuddy 的
> `Illegal API invocation from an unapproved channel`（HTTP **400** / code **11128**）。
>
> 装进 DSH，在「设置」页开关。**提示词无损**绕过 —— 语义不变、上下文不丢、可随时关闭。
>
> **关键词**：`unapproved channel` · `Illegal API invocation` · `code 11128` ·
> `11140` · WorkBuddy 400 · CodeBuddy 400 · 请求被拦截 · 提示词风控 ·
> 关键词过滤绕过 · 零宽空格 · DeepSeek Harness · prompt filter bypass

![wb400修复 演示](docs/wb400-intro.gif)

<sub>24 秒看完：前情提要 → 报错长什么样 → 为什么不是渠道问题 → 真因与解法 → 装好后的开关</sub>

<sub>背景音乐：*Peaceful Instrumental Background Music* by Peaceful Peach — [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)，来自 [Internet Archive](https://archive.org/details/peaceful-tracks)</sub>

---

## 常见报错速查

| 你看到的报错 | 真实原因 | 本插件能修吗 |
|---|---|---|
| `Illegal API invocation from an unapproved channel` | 上游按**关键词**风控 system prompt | ✅ 能（这就是本插件） |
| `code 11128` / `code 11140` / HTTP 400 | 同一错误族 | ✅ 能 |
| `first message is not system prompt` | 首条消息不是 `system` 角色 | ✅ 能（「补首条 system」开关） |
| `code 11133 integer_below_min_value` | `max_tokens` 太小 | ❌ 调大 max_tokens |
| `code 6004 usage exceeds frequency limit` | 上游限流 | ❌ 换账号或等冷却 |
| `EMPTY_RESPONSE` / 有思考无正文 | 推理模型把 max_tokens 吃光 | ❌ max_tokens ≥ 4096 |

---

## 如果你是因为这个报错搜到这里

```
buddy: 请求被拦截，请重新发送 Illegal API invocation from an unapproved channel
```

```
Illegal API invocation from an unapproved channel
```

HTTP `400` · 上游 code `11128`（有时 `11140`）

### 这个报错在骗你

文案说 "unapproved channel"（未获批准的渠道），**但它跟渠道一点关系都没有**。

我逐项实测排除过：换账号、换域名（`copilot.tencent.com` / `www.workbuddy.ai`）、
换客户端身份（CodeBuddy / WorkBuddy）、补齐 13 个缺失请求头、调 `reasoning_effort`、
调 `max_tokens`、减少工具数量（316→少量）、换网络、降并发 —— **全都不是原因**。

真因：**上游在对 system prompt 做关键词内容风控**。
只要 prompt 里出现 `DeepSeek Harness` 这个词组，请求就被拒。

### 60 秒自证

用同一个 token 打两次，**只改 system prompt 里的一个词**：

| system prompt | 结果 |
|---|---|
| `You are an AI agent powered by DeepSeek Harness.` | ❌ 400 / 11128 |
| `You are an AI agent.` | ✅ 200 |

符合这个规律，就是这个原因。

> 💡 **为什么它时好时坏**：关键词要配合**请求体够大**（约 >1KB）才稳定触发。
> 短 prompt 即使含关键词也会放过 —— 这是最容易误判成「偶发故障」的地方。

### 修法：零宽空格

在 `DeepSeek` 与 `Harness` 之间插一个不可见字符 `U+200B`：

```js
// 改前
"You are an AI agent powered by DeepSeek Harness."
// 改后
"You are an AI agent powered by DeepSeek\u200B Harness."
```

- 模型看到的语义**完全不变**
- 上游的子串匹配不再命中
- **无损**：没有裁剪、没有改写、没有丢上下文

实测（真实 DSH 请求形状：316 tools + `effort=max` + `max_tokens=128000`）：

```
原文   → ❌ 0/5 全部失败
中和后 → ✅ 5/5 全部成功
```

### ⚠️ 文件路径不能被改写

运行时上下文里有真实路径：

```
D:\10_COD\DeepSeek Harness\resources\app.asar\dsh\
```

在路径里插零宽字符，会让模型把坏路径传给工具调用，直接失败。
所以匹配器带**前后负向断言**，跳过路径语境：

```js
/(?<![\\/])(DeepSeek)[ \u00A0]+(Harness)(?![\\/])/gi
```

---

## 前置条件

| 项 | 要求 |
|---|---|
| **DSH 桌面版** | 已在用（本插件是 DSH 插件，不是独立程序） |
| **任一 WorkBuddy/CodeBuddy 反代插件** | dsh-our-free-model 或其它同类插件，已登录账号 |
| **Node.js** | `^22.19.0` 或 `>=24.0.0` |

不需要：官方客户端后台常驻、额外 API Key、管理员权限。

> **兼容性说明**：旧版要求必须装 `dsh-our-free-model`（因为它要往 OFM 的 `pack.js`
> 插一行钩子）。**v1.1.0 起不再依赖任何第三方文件** —— 主通道改在 `globalThis.fetch`
> 层拦截，只要你的 WB 反代插件用 fetch 发 `chat/completions` 请求就生效，
> 不管它是 OFM 还是别的实现、哪个版本、装在哪个 profile。

---

## 安装

在 DSH 里说：

> 把 `C:\Users\你的用户名\Documents\...\dsh-workbuddy-fix` 装成插件

或让 agent 调用 `plugin_manager` 的 `install_bundle`，`target` 传本目录绝对路径。

装完**重启一次 DSH**（首次安装需要加载新的 Host 模块），然后在「设置」里能看到
**wb400修复**。

---

## 使用

打开 **设置 → wb400修复**，看到 4 个开关：

| 开关 | 默认 | 作用 |
|---|---|---|
| 总开关 | 开 | **关掉即完全恢复原始请求**（一个字节都不改） |
| 中和身份关键词 | 开 | 上面说的零宽空格替换 |
| 补首条 system | 开 | 首条非 system 时注入保底 system（11128 的另一个成因） |
| 隐藏品牌词 | 关 | 更激进：连 `DeepSeek` 也打散 |

面板还会显示：

- 补丁状态（钩子是否在位）+ **补打钩子**按钮
- 本机已中和多少处
- 改写效果预览（前后对照）
- 是否与「用量计量」插件联动

**改完即时生效，不需要重启。**

---

## 与 dsh-workbuddy-meter 的关系

本插件是 [`dsh-workbuddy-meter`](https://github.com/balongTTY/dsh-workbuddy-meter) 里
「关键词中性化」功能的**独立精简版**。

| | 本插件 | dsh-workbuddy-meter |
|---|---|---|
| 解决 400 错误 | ✅ | ✅ |
| 积分/token 计量面板 | ❌ | ✅ |
| 体积 | ~40 KB | ~300 KB |
| 设置页入口 | ✅ 独立页面 | 侧栏「用量」面板内 |

### 两个插件**可以同时装**，而且开关是**联动**的

它们共享同一个状态文件：

```
~/.dsh/workbuddy-meter/lexicon.json
```

任一方改了开关，另一方立即跟随 —— **一个打开，另一个也打开**。
不会冲突，不会重复改写（钩子名相同，后装的覆盖先装的，但行为一致）。

**只装其中一个也完全正常**：
- 只装本插件 → 有修复功能，没有计量面板
- 只装 meter → 两者都有（meter 内置了同样功能）
- 都装 → 修复逻辑一致，开关双向同步

---

## 它对你的代码做了什么

**主通道：fetch 层拦截（v1.1.0 起，不碰任何文件）**

包装 `globalThis.fetch`，在请求真正发出前改写 body：

```
POST https://copilot.tencent.com/v1/chat/completions
  ↓
命中 WB 域名 → 读 body → 改写 messages → 重新序列化 → 发出
```

- **不修改任何第三方文件**，所以 OFM 升级、换插件、换 profile 都不会失效
- 只命中 `copilot.tencent.com` / `workbuddy.ai` / `codebuddy.ai` / `codebuddy.cn`
  的 `chat/completions`，其它请求**原样透传**（已测：非 WB 域名 body 字节一致）
- 只处理 POST + JSON；body 解析失败、`rewrite` 抛错、`messages` 非数组 —— 一律原样放行
- 关掉总开关后，发出的 body 与原请求**字节级一致**

**兼容通道：pack.js 行钩子（可选，不再是依赖）**

旧方案仍保留，在 `pack.js` 里插一行：

```js
;globalThis.__wbLexicon?.rewrite?.(messages);
```

它的作用变成「兜底拦截非 fetch 请求」（比如插件自己起的 undici 实例）。
**装不上不影响使用** —— 面板会显示「旧版钩子未打上（不影响使用）」，
而不是像以前那样报「未打钩子」让人以为坏了。

**安全边界**

- 判定顺序：先看总开关 → 再看 URL 是否 WB → 再看 method 是否 POST → 才碰 body
- 任何一步不满足就 `return original(...)`，开销是一条 URL 字符串匹配
- 可完整卸载（恢复原 fetch 引用），测试里验证过引用相等

### 手动控制（可选）

```powershell
# 只检查，不改文件
node -e "import('./src/patch.mjs').then(m=>console.log(m.inspectLexicon(m.resolvePackFile())))"

# 打钩子（默认 dry-run，这里显式落盘）
node -e "import('./src/patch.mjs').then(m=>console.log(m.applyLexiconPatch({dryRun:false})))"

# 移除钩子（⚠️ meter 插件也依赖这行，会由它的自愈重打回来）
node -e "import('./src/patch.mjs').then(m=>console.log(m.revertLexiconPatch()))"
```

---

## 已知边界

- 只对**本机 OFM 进程内**的请求生效（服务器上反代的流量要单独装）
- 上游如果换关键词（不再拦 `DeepSeek Harness`），本插件就不需要了 —— 关掉总开关即可
### 主通道（fetch）：与 OFM 版本无关

只要目标插件用 `globalThis.fetch` 发 `chat/completions`，任何 OFM 版本都能拦。

### 兼容通道（pack.js 钩子）：**只支持 OFM v2.5.2 ~ v2.5.7**

![OFM 版本兼容矩阵](docs/ofm-version-matrix.svg)

这是 14 个版本全量实测的结论：

| OFM 版本 | 锚点 | 说明 |
|---|---:|---|
| v2.0.0 ~ v2.5.1 | ❌ | 锚点代码尚未引入 |
| **v2.5.2 ~ v2.5.7** | ✅ | **唯一支持区间（6 个版本）** |
| **v2.5.8+** | ❌ | **上游移除 WorkBuddy 渠道**（release note 原文：「移除 WorkBuddy 国内版和国际版渠道入口」）|

> 图里的 `wb` 是 pack.js 中 `workbuddy` 字符串的出现次数：正常 41 次，v2.5.8 骤降到 **4 次** ——
> 这是「渠道被移除」最直观的信号。

所以如果你的 OFM 是 2.5.1 及以下，面板会显示「旧版钩子未打上」——
**这不影响主功能**，fetch 通道照常工作。若想用上兜底，需升级到 v2.5.2~v2.5.7 区间内。

⚠️ **不要把 OFM 升到 v2.5.8+**：那个版本移除了 WorkBuddy 渠道，
本插件的所有通道都会失去意义（没有 WorkBuddy 请求可拦了）。

- 如果某个反代插件用 `undici` 直连（不经 `globalThis.fetch`），fetch 钩子拦不到，
  这时才需要 pack.js 那行；两者都失效时面板会明确显示原因

## 许可

[MIT](./LICENSE) © 2026 balong
