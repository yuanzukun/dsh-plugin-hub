# WorkBuddy 400 错误修复 · `unapproved channel` (code 11128) · DSH 插件

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](./LICENSE)
[![fix](https://img.shields.io/badge/fix-unapproved%20channel%20400-orange)](#如果你是因为这个报错搜到这里)
[![DSH](https://img.shields.io/badge/DeepSeek%20Harness-plugin-5B8DEF)](#安装)
[![version](https://img.shields.io/badge/version-1.3.2-brightgreen)](https://github.com/balongTTY/dsh-workbuddy-fix/releases/latest)
[![tests](https://img.shields.io/badge/tests-15%20files%20passing-success)](#测试)

> **一键修复** WorkBuddy / CodeBuddy 的
> `Illegal API invocation from an unapproved channel`（HTTP **400** / code **11128**）。
>
> 装进 DSH，在设置页开关。**提示词无损**绕过 —— 语义不变、上下文不丢、可随时关闭、**不修改任何第三方文件**。
>
> **关键词**：`unapproved channel` · `Illegal API invocation` · `code 11128` · `code 11140` ·
> WorkBuddy 400 · CodeBuddy 400 · 请求被拦截 · 提示词风控 · 关键词过滤绕过 ·
> 零宽空格 · prompt filter bypass · DeepSeek Harness

📺 **[看 24 秒演示](https://github.com/balongTTY/dsh-workbuddy-fix/releases/download/v1.0.0/wb400-intro.mp4)**
（1080p MP4 · 2.4 MB · 报错长什么样 → 为什么不是渠道问题 → 真因与解法 → 装好后的开关）

<sub>背景音乐：*Peaceful Instrumental Background Music* by Peaceful Peach — [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)，来自 [Internet Archive](https://archive.org/details/peaceful-tracks)。
视频放 Release 附件而不是仓库内 —— 仓库只装插件本体，避免拖慢每个人的 `git clone`。</sub>

---

## 目录

- [它修什么](#它修什么)
- [常见报错速查](#常见报错速查)
- [如果你是因为这个报错搜到这里](#如果你是因为这个报错搜到这里)
- [面板功能](#面板功能)
- [安装](#安装)
- [怎么确认装对了](#怎么确认装对了)
- [装了没用？先看这里](#装了没用先看这里)
- [稳定性记录](#稳定性记录)
- [它对你的代码做了什么](#它对你的代码做了什么)
- [兼容性](#兼容性)
- [与 dsh-workbuddy-meter 的关系](#与-dsh-workbuddy-meter-的关系)
- [常见问题](#常见问题)
- [测试](#测试)
- [许可](#许可)

---

## 它修什么

DSH 通过 WorkBuddy / CodeBuddy 的账号池调用模型时，**上游会对 system prompt 做关键词内容风控**。
提示词里出现特定词组，请求直接被拒：

```
buddy: 请求被拦截，请重新发送 Illegal API invocation from an unapproved channel
```

这个插件在请求发出前，把触发词用**不可见字符（零宽空格 U+200B）**打断，
让上游的子串匹配不再命中，而模型读到的语义完全不变。

**核心特性**

| 特性 | 说明 |
|---|---|
| **无损** | 不裁剪、不改写、不丢上下文，只插不可见字符 |
| **不碰第三方文件** | 拦截点在 `globalThis.fetch`，与反代插件版本/实现无关 |
| **可逆** | 关掉总开关 → 发出的请求与原始请求**字节级一致** |
| **路径安全** | 带负向断言，`D:\...\DeepSeek Harness\...` 这类真实路径**不会被改坏** |
| **实时生效** | 改完开关立即生效，不用重启 |

---

## 常见报错速查

| 你看到的报错 | 真实原因 | 本插件能修吗 |
|---|---|---|
| `Illegal API invocation from an unapproved channel` | 上游按**关键词**风控 system prompt | ✅ 能（这就是本插件） |
| `code 11128` / `code 11140` / HTTP 400 | 同一错误族 | ✅ 能 |
| `first message is not system prompt` | 首条消息不是 `system` 角色 | ✅ 能（「补首条 system」开关） |
| `code 11133 integer_below_min_value` | `max_tokens` 太小 | ❌ 调大 max_tokens |
| `code 6004 usage exceeds frequency limit` | 上游限流 | ❌ 换账号或等冷却 |
| `EMPTY_RESPONSE` / 有思考无正文 | 推理模型把 max_tokens 吃光 | ❌ max_tokens ≥ 4096 |
| `model returned a completed response with no content` | 模型侧空响应 | ❌ 与本插件无关 |

---

## 如果你是因为这个报错搜到这里

HTTP `400` · 上游 code `11128`（有时 `11140`）

### 这个报错在骗你

文案说 "unapproved channel"（未获批准的渠道），**但它跟渠道一点关系都没有**。

我逐项实测排除过：换账号、换域名（`copilot.tencent.com` / `www.workbuddy.ai`）、
换客户端身份（CodeBuddy / WorkBuddy）、补齐 13 个缺失请求头、调 `reasoning_effort`、
调 `max_tokens`、减少工具数量（316→少量）、换网络、降并发 —— **全都不是原因**。

真因：**上游在对 system prompt 做关键词内容风控**。
只要 prompt 里出现某个特定词组，请求就被拒。

### 60 秒自证

用同一个 token 打两次，**只改 system prompt 里的一个词**：

| system prompt | 结果 |
|---|---|
| `You are an AI agent powered by DeepSeek Harness.` | ❌ 400 / 11128 |
| `You are an AI agent.` | ✅ 200 |

符合这个规律，就是这个原因。

> 💡 **为什么它时好时坏**：关键词要配合**请求体够大**（约 >1KB）才稳定触发。
> 短 prompt 即使含关键词也会放过 —— 这是最容易误判成「偶发故障」的地方。
>
> ⚠️ **触发词会变**。如果你的插件开着但照样报 11128，说明上游换了词，
> 在面板的「关键词」里加上新词即可（不用升级插件）。

### 修法：零宽空格

在触发词中间插一个不可见字符 `U+200B`：

```js
// 改前
"You are an AI agent powered by DeepSeek Harness."
// 改后
"You are an AI agent powered by DeepSeek\u200B Harness."
```

- 模型看到的语义**完全不变**
- 上游的子串匹配不再命中
- **无损**：没有裁剪、没有改写、没有丢上下文

实测（真实 DSH 请求形状：316 tools + `effort=max` + `max_tokens=128000`）：

```
原文   → ❌ 0/5 全部失败
中和后 → ✅ 5/5 全部成功
```

### ⚠️ 文件路径不能被改写

运行时上下文里有真实路径：

```
D:\10_COD\DeepSeek Harness\resources\app.asar\dsh\
```

在路径里插零宽字符，会让模型把坏路径传给工具调用，直接失败。
所以匹配器带**前后负向断言**，跳过路径语境：

```js
/(?<![\\/])(DeepSeek)[ \u00A0]+(Harness)(?![\\/])/gi
```

---

## 面板功能

设置页入口：**设置 → wb400修复**

**顶部状态**

| 显示 | 含义 |
|---|---|
| `v1.3.2` 版本徽标 | 当前版本，可据此判断装的是哪版 |
| 主通道运行中 | ✅ 正常（无论是否在最外层） |
| 主通道未接管 | ⚠️ 看下方「补打钩子」或诊断信息 |

> 💡 **「不在最外层」不代表失效**。DSH 启动时十几个插件按各自顺序包装 fetch，
> 我们的 wrapper 被夹在内层是**完全正常**的 —— 只要它在链上被调用，改写照常生效。
> 面板用「已处理 N 处关键词」这个**实际计数**证明它在工作，而不是靠「是不是最外层」判断。

**四个开关**

| 开关 | 默认 | 作用 |
|---|---|---|
| 总开关 | 开 | **关掉即完全恢复原始请求**（一个字节都不改） |
| 中和身份关键词 | 开 | 上面说的零宽空格替换 |
| 补首条 system | 开 | 首条非 system 时注入保底 system（11128 的另一个成因） |
| 隐藏品牌词 | 关 | 更激进：连 `DeepSeek` 也打散 |
| 彻底换词 | 关 | 把关键词整体替换成别的词（默认 `CodeBuddy`） |
| 人格注入 | 关 | 追加一段 CodeBuddy 风格的工程行为约束 |

**检查更新**

面板内有「检查更新」按钮，读 GitHub Releases 最新版并与当前版本比对。

- 有新版 → 显示版本号对比 + Release 链接
- 已是最新 → 中性灰提示
- 网络不通 → **中性灰「查不到」**，不会报红

> 查不到更新是**正常情况**：本机无代理时 `github.com` 经常超时，这不是故障。

**实时统计**

- 已处理多少处关键词（**这个是「是否真的在工作」的权威判据**）
- 改写效果预览（前后对照）

---

## 安装

> **版本要求**：请装 **v1.3.2 或更新**。
> v1.3.0 / v1.3.1 有稳定性缺陷（会导致宿主崩溃 + 插件不可用），**不要用**。
> v1.0.x 没有 fetch 通道，对大部分人无效。

### 方式一：从 GitHub 直接装（推荐）

在 DSH 里说：

> 我装了 `github:balongTTY/dsh-workbuddy-fix`
> 把 `github:balongTTY/dsh-workbuddy-fix` 装成插件

或自己执行（把 `<DSH目录>` 换成本机实际路径）：

```powershell
<DSH目录>\resources\runtime\cli\bin\dsh.cmd plugin --profile desktop add github:balongTTY/dsh-workbuddy-fix
```

装完**重启一次 DSH**。实测约 30 秒（要拉 GitHub）。

> ⚠️ 网络不通时这条会失败（GitHub 直连不稳）。用方式二。

### 方式二：下载 Release 附件（网络不好时用这个）

1. 打开 **[最新 Release](https://github.com/balongTTY/dsh-workbuddy-fix/releases/latest)**
2. 下载 `balong-dsh-workbuddy-fix-1.3.2.tgz`（约 42 KB）
3. 执行：

```powershell
<DSH目录>\resources\runtime\cli\bin\dsh.cmd plugin --profile desktop add .\balong-dsh-workbuddy-fix-1.3.2.tgz
```

> ⚠️ **只下 `.tgz` 附件**。v1.0.0 的 Release 里的 `wb400-intro.mp4` 是演示视频，不是插件包。

### 方式三：克隆后装（要改代码时用）

```powershell
git clone https://github.com/balongTTY/dsh-workbuddy-fix.git
cd <DSH安装目录>\resources\runtime\cli\bin
.\dsh.cmd plugin --profile desktop add <克隆下来的目录绝对路径>
```

### 卸载

```powershell
<DSH目录>\resources\runtime\cli\bin\dsh.cmd plugin --profile desktop remove @balong/dsh-workbuddy-fix
```

卸载**不会**动你的关键词配置（`~/.dsh/workbuddy-meter/lexicon.json`），重装后开关状态还在。

---

## 怎么确认装对了

重启 DSH 后打开 **设置 → wb400修复**，应该看到：

1. 标题右侧有 **`v1.3.2`** 版本徽标
2. 状态行显示 **主通道运行中**
3. 正常对话几轮后，「已处理」计数**大于 0**

**三条都满足 = 真的在工作。**
如果版本徽标不是 1.3.x，说明装的是旧版。

### 只显示「主通道运行中」但没有计数？

说明钩子在位但**没有命中过 WB 请求**。可能原因：

- 你还没发过对话（去发一条）
- 你用的反代插件没走 `globalThis.fetch`（见[排查](#-反代插件没有走-globalthisfetch)）

---

## 装了没用？先看这里

按顺序排查，通常第 1 或第 2 条就是原因。

### ① 版本装错了（最常见）

| 面板显示 | 说明 |
|---|---|
| `v1.3.x` + 主通道运行中 | ✅ 正常 |
| `v1.0.x` / 没有版本徽标 | ❌ 旧版，重装 |

### ② 报错前缀能区分渠道

| 报错 | 渠道 | 本插件支持 |
|---|---|---|
| `buddy: 请求被拦截…` | CodeBuddy / copilot.tencent.com | ✅ |
| `workbuddy: 请求被拦截…` | WorkBuddy 国际版 | ✅ |

两个渠道都覆盖了（`WB_HOSTS` 里的 5 个域名）。

### ③ 触发词变了

上游换了风控词，本插件的中和词表没覆盖。

**修法**：面板「关键词」里加上新词，不用升级插件。

### ④ 反代插件没有走 `globalThis.fetch`

极少见，但如果你的反代插件用 `undici` 直连或 `node:http`，fetch 层拦不到。
判断方法：在面板看「介入次数」是否随对话增长。

```powershell
node diagnose.mjs
```

会打印当前 OFM 版本、锚点情况，以及该用哪条通道。

### ⑤ 装了但一次都没触发

如果你用的是 **[dsh-connect-workbuddy](https://github.com/dingminhua/dsh-connect-workbuddy)**，注意它有个特性：
它会在 system prompt 丢失时补一句 `"You are a helpful assistant."` —— 那句里没有关键词，
所以**本来就不需要本插件介入**（这种情况你也不会看到 400）。这不是 bug。

### 装完 DSH 起不来怎么办

先卸载，DSH 就能恢复：

```powershell
<DSH目录>\resources\runtime\cli\bin\dsh.cmd plugin --profile desktop remove @balong/dsh-workbuddy-fix
```

然后去 [Issues](https://github.com/balongTTY/dsh-workbuddy-fix/issues) 反馈，带上：

1. 装的是**哪个版本**（看面板徽标）
2. 用的**哪种方式**（方式一 / 二 / 三）
3. DSH 崩溃日志原文
   - 位置：`%APPDATA%\@deepseek-ai\dsh-desktop\logs\crash-<时间>-*.log`

---

## 稳定性记录

> 这一节如实记录本插件走过的弯路。**崩溃过的插件不值得被信任，除非它把根因和修法都摊开写清。**

### 它崩过 4 次宿主

| # | 版本 | 根因 | 已修 |
|---|---|---|---:|
| 1-2 | v1.2.1 | `reassertFetchHook()` 把 wrapper 抢回最外层，形成 `我们 → 对方 → 我们` 环路 | v1.2.2 |
| 3-4 | v1.3.0 / v1.3.1 | **同一段逻辑的第二个副本**藏在复用分支里 | v1.3.2 |

症状全部相同：

```
RangeError: Maximum call stack size exceeded
dsh: fatal uncaught exception: RangeError: Maximum call stack size exceeded
```

### 为什么难查

崩溃不是「装了立刻炸」，而是**依赖热重载累积**：单次重载只是把上游指针改成「对方」，
连续几次之后环才闭合。所以「装了能用」不等于「安全」—— 它会在某次插件更新后突然崩。

### v1.3.2 修了什么

| # | 缺陷 | 修法 |
|---|---|---|
| 1 | 复用分支里「抢回最外层」 | 该分支**一个字节都不碰 `globalThis.fetch`** |
| 2 | 旧 wrapper 读共享状态 → 跨代成环 | 每代 wrapper 闭包捕获**自己的不可变 `tail`**；退役后只走自己的 tail |
| 3 | 环保护用布尔标志 → **并发被误判为环路** | 改**同步深度计数**（只在同步段累加） |
| 4 | HMR 重估模块后 `tail=null` → **所有请求 502** | `pickSafeTail` **穿透** `__wbFixTail` 走到真正终点 |
| 5 | 环路兜底终点本身可能在环上 | 新增 `shared.native`（第一次安装前的 fetch，只写一次永不覆盖） |

**第 3 条的实测数据**（200 并发同一批请求）：

| | rewrite 调用 | 上游收到未改写 |
|---|---:|---:|
| 修复前 | **20 / 200** | **180** |
| 修复后 | **200 / 200** | **0** |

这解释了很多人反馈的「改写时灵时不灵」——高并发下有 90% 的请求被静默跳过。

**第 4 条的实测数据**：

| | 热重载后 HTTP | 上游被调用 |
|---|---:|---:|
| 修复前 | **502** | **0** 次 |
| 修复后 | **200** | **1** 次 |

### 现在的验证标准

每次改动必须同时满足：

1. `npm test`（15 个测试文件）全绿
2. **200 并发全部走改写**（不是「大部分」）
3. **HMR 重估后仍返回 200**（不是 502）
4. 真实宿主 **6 轮热重载 + 20 次调用**全成功
5. **40 次 status 压测**结果完全一致（无副作用）

其中第 2、3 条是**这次事故之后才加的** —— 之前 15 个测试全绿的同时，
插件在 HMR 后是全 502 的。「测试全绿」从来不等于「功能正确」。

### 如果你遇到崩溃

**立刻卸载**（命令见上一节），然后带崩溃日志开 Issue。
日志里 `RangeError: Maximum call stack size exceeded` 就是这个问题族。

---

## 它对你的代码做了什么

**主通道：fetch 层拦截（v1.1.0 起，不碰任何文件）**

包装 `globalThis.fetch`，在请求真正发出前改写 body：

```
POST https://copilot.tencent.com/v1/chat/completions
  ↓
命中 WB 域名 → 读 body → 改写 messages → 重新序列化 → 发出
```

- **不修改任何第三方文件**，所以 OFM 升级、换插件、换 profile 都不会失效
- 只命中 `copilot.tencent.com` / `workbuddy.ai` / `workbuddy.cn` / `codebuddy.ai` / `codebuddy.cn`
  的 `chat/completions`，其它请求**原样透传**（已测：非 WB 域名 body 字节一致）
- 只处理 POST + JSON；body 解析失败、`rewrite` 抛错、`messages` 非数组 —— 一律原样放行
- 关掉总开关后，发出的 body 与原请求**字节级一致**

**兼容通道：pack.js 行钩子（可选，不再是依赖）**

旧方案仍保留，在 `pack.js` 里插一行：

```js
;globalThis.__wbLexicon?.rewrite?.(messages);
```

它的作用变成「兜底拦截非 fetch 请求」。**装不上不影响使用** ——
面板会显示「旧版钩子未打上（不影响使用）」。

**安全边界**

- 判定顺序：先看总开关 → 再看 URL 是否 WB → 再看 method 是否 POST → 才碰 body
- 任何一步不满足就 `return original(...)`，开销是一条 URL 字符串匹配
- 环路保护：同步深度超阈值时落到 `native`（结构上不可能指向自己的终点）
- 可完整卸载（恢复原 fetch 引用），测试里验证过引用相等

### 手动控制（可选）

```powershell
# 只检查，不改文件
node -e "import('./src/patch.mjs').then(m=>console.log(m.inspectLexicon(m.resolvePackFile())))"

# 打钩子（默认 dry-run，这里显式落盘）
node -e "import('./src/patch.mjs').then(m=>console.log(m.applyLexiconPatch({dryRun:false})))"

# 移除钩子（⚠️ meter 插件也依赖这行，会由它的自愈重打回来）
node -e "import('./src/patch.mjs').then(m=>console.log(m.revertLexiconPatch()))"
```

---

## 兼容性

### 主通道（fetch）：与 OFM 版本无关

只要目标插件用 `globalThis.fetch` 发 `chat/completions`，任何 OFM 版本都能拦。

### 兼容通道（pack.js 钩子）：**只支持 OFM v2.5.2 ~ v2.5.7**

![OFM 版本兼容矩阵](docs/ofm-version-matrix.svg)

这是 14 个版本全量实测的结论：

| OFM 版本 | 锚点 | 说明 |
|---|---:|---|
| v2.0.0 ~ v2.5.1 | ❌ | 锚点代码尚未引入 |
| **v2.5.2 ~ v2.5.7** | ✅ | **唯一支持区间（6 个版本）** |
| **v2.5.8+** | ❌ | **上游移除 WorkBuddy 渠道**（release note 原文：「移除 WorkBuddy 国内版和国际版渠道入口」）|

> 图里的 `wb` 是 pack.js 中 `workbuddy` 字符串的出现次数：正常 41 次，v2.5.8 骤降到 **4 次** ——
> 这是「渠道被移除」最直观的信号。

所以如果你的 OFM 是 2.5.1 及以下，面板会显示「旧版钩子未打上」——
**这不影响主功能**，fetch 通道照常工作。

⚠️ **不要把 OFM 升到 v2.5.8+**：那个版本移除了 WorkBuddy 渠道，
本插件的所有通道都会失去意义（没有 WorkBuddy 请求可拦了）。

### 已知边界

- 只对**本机进程内**的请求生效（服务器上反代的流量要单独装）
- 上游如果彻底不拦关键词了，本插件就不需要了 —— 关掉总开关即可

---

## 与 dsh-workbuddy-meter 的关系

本插件是 [`dsh-workbuddy-meter`](https://github.com/balongTTY/dsh-workbuddy-meter) 里
「关键词中性化」功能的**独立精简版**。

| | 本插件 | dsh-workbuddy-meter |
|---|---|---|
| 解决 400 错误 | ✅ | ✅ |
| 积分/token 计量面板 | ❌ | ✅ |
| 体积 | ~42 KB | ~300 KB |
| 设置页入口 | ✅ 独立页面 | 侧栏「用量」面板内 |

### 两个插件**可以同时装**，而且开关是**联动**的

它们共享同一个状态文件：

```
~/.dsh/workbuddy-meter/lexicon.json
```

任一方改了开关，另一方立即跟随 —— **一个打开，另一个也打开**。
不会冲突，不会重复改写。

**只装其中一个也完全正常**：

- 只装本插件 → 有修复功能，没有计量面板
- 只装 meter → 两者都有（meter 内置了同样功能）
- 都装 → 修复逻辑一致，开关双向同步

---

## 常见问题

<details>
<summary><b>装完还是 400，怎么办？</b></summary>

按顺序看：

1. 面板有没有 `v1.3.x` 版本徽标？没有 → 装的是旧版
2. 「已处理」计数有没有增长？没有 → 钩子没命中请求
3. 上游是不是换了风控词？→ 面板里加新词

三条都排除了再开 Issue。
</details>

<details>
<summary><b>「主通道未接管」是坏了吗？</b></summary>

**不是。** DSH 里十几个插件都会包装 fetch，我们在内层是正常的。
真正的判据是「已处理」计数是否增长 —— 那个数字只能来自真实调用。

v1.2.1 曾经为了「抢回最外层」去改写全局 fetch，结果导致宿主崩溃。
现在彻底不做这件事了。
</details>

<details>
<summary><b>关掉插件后请求真的完全恢复吗？</b></summary>

是。关掉总开关后走的是**原始 payload 路径**，我们只做判断不碰 body。
测试里断言了「关闭后与原始 body 字节一致」。
</details>

<details>
<summary><b>会不会改坏我文件路径里的关键词？</b></summary>

不会。匹配器带前后负向断言 `(?<![\\/])…(?![\\/])`，
`D:\10_COD\DeepSeek Harness\resources\...` 这类路径会被跳过。
</details>

<details>
<summary><b>为什么「查不到更新」？</b></summary>

正常。本机无代理时 `github.com` 经常超时。
面板用中性灰显示，不是故障。
</details>

<details>
<summary><b>支持服务器端的 DSH 吗？</b></summary>

插件本身通用，但只对**它所在进程内**的 fetch 生效。
如果你在服务器上跑 DSH，装在那台机上即可。
</details>

---

## 测试

```bash
npm test
```

15 个测试文件，覆盖：

| 文件 | 断言数 | 覆盖 |
|---|---:|---|
| `selftest-hosts.mjs` | — | 域名匹配、非 WB 域名透传 |
| `selftest-switches.mjs` | — | 各开关单独生效 |
| `selftest-v12.mjs` | — | v1.2 三组能力（换词/人格/可复原）|
| `selftest-reload.mjs` | — | 重载后钩子存活 |
| `selftest-hmr-reeval.mjs` | 12 | **真实重估模块**，5 代连续重载不 502 |
| `selftest-cycle-guard.mjs` | 8 | 崩溃现场复现（对方包外层 + 反复重载）|
| `selftest-chain-safety.mjs` | 5 | 20 轮重载 + 原生 fetch 调用次数合理 |
| `selftest-concurrency.mjs` | 6 | **200 并发全部走改写** |
| `selftest-version.mjs` | 7 | 版本比较、更新检查失败不抛错 |
| `selftest-patch.mjs` | — | pack.js 钩子打/撤 |
| `selftest-fetch-hook.mjs` | — | fetch 钩子核心逻辑 |
| `selftest-realworld.mjs` | — | 真 HTTP 服务器，断言 content-length |
| `selftest-render.mjs` | 26 | **真调用面板组件**并展开元素树 |
| `selftest-i18n.mjs` | 9 | 中英键集双向差集 |
| `runtime-hook.mjs` | 8 | 真实运行时 |

**关键测试都验证过「改坏后会变红」** —— 不是摆设。

---

## 仓库体积

代码本体不到 100 KB。演示视频（MP4 2.4 MB / GIF 3.1 MB）**不在仓库里，也不在 git 历史里**。

v1.1.5 期间做过一次 `git filter-repo` 历史清理，把早期误提交的视频从**整条历史**中移除。
如果你在此前 clone 过，请重新 clone。

重新生成演示视频的源码在 `_video/`（`render.mjs` / `mix-bgm.mjs` 等）。

---

## 许可

[MIT](./LICENSE) © 2026 balong
