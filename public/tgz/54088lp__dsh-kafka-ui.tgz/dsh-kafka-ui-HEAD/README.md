# dsh-卡芙卡-ui

《崩坏：星穹铁道》**卡芙卡（Kafka · 星核猎手）** 主题皮肤，用于 [DeepSeek Harness](https://github.com/deepseek-ai)（DSH）Web GUI。

以深紫、洋红与幽黑构成星核猎手调色板，用蛛网、彼岸花与幽光粒子作为装饰母题，提供浅色 / 深色双主题的玻璃卡片、角色立绘、粒子背景与「卡芙卡」配色面板。

> 图片素材版权归 © miHoYo / HoYoverse 所有，本仓库仅作界面主题用途。
>
## 展示图
<img width="1574" height="1031" alt="主页面" src="https://github.com/user-attachments/assets/037098e7-a30d-4c55-9da5-4763ace011f8" />


## 特性

- 双主题：浅色 / 深色（跟随 DSH 深色模式自动切换）
- 玻璃拟态卡片与半透明面板
- 卡芙卡角色立绘（侧边栏下部 4/5 区域，半透明不遮挡）
- 幽光粒子、蛛网、彼岸花装饰元素
- 设置页内「卡芙卡 · 星核猎手」配色面板 +「背景可见度」滑块
- 深红 / 灰棕聊天输入框、灰紫正文文字、渐变标题
- 新会话欢迎界面（卡芙卡标题 + 副标题 + 台词）

## 安装

### 方式一：dsh 命令（推荐，发布后可用）

```bash
dsh plugin --profile web add https://github.com/54088lp/dsh-client-ui-skin-kafka.git
```

安装完成后**重启 DSH** 生效。

### 方式二：手动安装

1. 克隆本仓库到本地（路径中不要包含空格，否则 `dsh plugin add` 会解析失败）：

   ```bash
   git clone https://github.com/54088lp/dsh-client-ui-skin-kafka.git
   ```

2. 编辑 `~/.dsh/profiles/web/package.json`，在 `dependencies` 中加入本地链接：

   ```json
   "dependencies": {
     "dsh-client-ui-skin-kafka": "link:C:/Users/54088lp/dsh-client-ui-skin-kafka"
   }
   ```

3. 在 `dsh.profile.bundles` 数组末尾加入 `"dsh-client-ui-skin-kafka"`。

4. 在 `~/.dsh/profiles/web` 目录执行 `pnpm install`，然后重启 DSH。

## 配置

- **背景可见度**：DSH 设置页 →「卡芙卡 · 星核猎手」面板 → 拖动滑块。
- **浅色 / 深色**：跟随 DSH 右上角的主题切换（本皮肤已修复切换后自动弹回浅色的问题）。

## 目录结构

```
dsh-client-ui-skin-kafka/
├── lib/
│   ├── client.js   # 浏览器端皮肤（内嵌 base64 图片，自包含）
│   └── index.js    # 宿主端空实现（纯浏览器皮肤）
├── skin.json       # 皮肤元信息（id / 强调色 / 接线）
├── cordis.patch.yml # 插入插件清单的补丁
├── package.json    # dsh.client 插件包声明
├── preview/        # 皮肤预览图（浅色 / 深色）
├── LICENSE
└── README.md
```

## 许可

- 皮肤代码与配置按 [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) 授权。
- 卡芙卡角色与相关美术素材版权归 © miHoYo / HoYoverse 所有，仅供个人学习与非商业用途。
