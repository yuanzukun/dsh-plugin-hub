/**
 * The decisions the compatibility pipeline makes, pinned without a network:
 * which versions a sweep covers, which peers refuse a version under which
 * rule, how a feed and a shell bundle are read, how the boot audit is split,
 * when a train is incomplete rather than failed, and when a drift issue is
 * opened, left alone or closed. The npm-backed paths run against a registry
 * served from this process, never the real one.
 */

import assert from 'node:assert/strict'
import { execFile, spawnSync } from 'node:child_process'
import { cpSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { createRequire } from 'node:module'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { after, before, describe, it } from 'node:test'
import { fileURLToPath } from 'node:url'
import semver from 'semver'
import { FLOOR, graphEvidence, graphFailed, npmErrorCode, pinToolchain, planCells, parseFeed, refusals, registryFailed, sweepStart, tupleHeads } from '../scripts/harness-lib.mjs'
import {
  blamesPlugin, bootGraphOf, bootPageState, classifyDiagnostics, exportedNames, laterHarnessVersions, maskTokens, membersRead, moduleLines,
  moduleTableOf, modulesServedBy, refusedAsUnpublished, releaseCutoff, strayPackages, unmetPeers,
} from '../scripts/smoke-lib.mjs'

const require = createRequire(import.meta.url)
const verdict = require('../scripts/harness-verdict.cjs')
const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
const lock = JSON.parse(readFileSync(new URL('../package-lock.json', import.meta.url), 'utf8'))
const peers = Object.entries(pkg.peerDependencies as Record<string, string>).filter(([name]) => name.startsWith('@deepseek-ai/dsh'))

const PUBLISHED = [
  '0.0.1-rc.1', '0.0.1-rc.2', '0.0.1-rc.5',
  '0.1.0-rc.2', '0.1.0-rc.3', '0.1.0-rc.6', '0.1.0-rc.7', '0.1.0-rc.8',
  '0.1.1-rc.1', '0.1.1-rc.2',
  '0.1.2-alpha.2', '0.1.2-alpha.3', '0.1.2-alpha.4', '0.1.2-alpha.5', '0.1.2-rc.1',
  '0.1.3-alpha.2',
  '0.1.5-alpha.1', '0.1.5-alpha.2', '0.1.5-rc.1', '0.1.5-rc.2', '0.1.5-rc.3',
  '0.1.6-alpha.1', '0.1.6-alpha.2',
  '0.1.7-alpha.1', '0.1.7-alpha.2', '0.1.7-rc.1', '0.1.7-rc.2',
  '0.2.0-rc.1', '0.2.0-rc.2',
  '0.2.1-alpha.1',
]
describe('peer admission', () => {
  it('admits every published train under both semver rules, 0.0.1-rc.1 included', () => {
    for (const version of PUBLISHED) {
      assert.deepEqual(refusals(version, peers), [], version)
    }
  })

  it('refuses the tuples nobody published, and the next, unverified one', () => {
    for (const version of ['0.0.0', '0.0.2-rc.1', '0.1.4-rc.0', '0.1.8-alpha.1', '0.1.8', '0.2.2-alpha.1']) {
      const refused = refusals(version, peers)
      assert.equal(refused.length, peers.length, version)
      assert.ok(refused.every((r: { runtime: boolean; installer: boolean }) => !r.runtime && !r.installer), `${version} must fail both rules`)
    }
  })

  it('names the rule that refuses: a broad range fails npm on prereleases but passes dsh', () => {
    const [refused] = refusals('0.1.7-rc.2', [['@deepseek-ai/dsh-tools', '>=0.1.0 <0.2.0']])
    assert.deepEqual(refused, { name: '@deepseek-ai/dsh-tools', runtime: true, installer: false })
  })
})

describe('sweep plan', () => {
  const facts = { published: PUBLISHED, sweepFrom: sweepStart(peers), pinned: '0.1.7-rc.2', resolved: { desktop: '0.1.7-rc.2', latest: '0.1.5-rc.3', next: '0.1.7-rc.2', alpha: '0.1.7-alpha.2' } }

  it('starts where the peer ranges start admitting: below the first published version', () => {
    assert.equal(sweepStart(peers), '0.0.1-rc.0')
  })

  it('covers every published version from 0.0.1-rc.1, and a newly published one without a code change', () => {
    // planCells emits the published versions in ascending order, so one published
    // below the newest tuple lands before it, not at the end of the list.
    const published = [...PUBLISHED, '0.1.8-alpha.1']
    const rows = planCells(['sweep'], { ...facts, published })
    assert.deepEqual(rows.map((r: { cell: string }) => r.cell), [...published].sort(semver.compare))
  })

  it('smokes the floor, each tuple head and every dist-tag or desktop version by default', () => {
    const smoked = planCells(['sweep'], facts).filter((r: { smoke: boolean }) => r.smoke).map((r: { cell: string }) => r.cell)
    assert.deepEqual(smoked, ['0.0.1-rc.5', '0.1.0-rc.8', FLOOR, '0.1.2-rc.1', '0.1.3-alpha.2', '0.1.5-rc.3', '0.1.6-alpha.2', '0.1.7-alpha.2', '0.1.7-rc.2', '0.2.0-rc.2', '0.2.1-alpha.1'])
    assert.equal(planCells(['sweep'], facts, 'none').some((r: { smoke: boolean }) => r.smoke), false)
  })

  it('smokes every row for the weekly sweep and the release gate', () => {
    const release = planCells(['pinned', 'floor', 'desktop', 'sweep'], facts, 'all')
    assert.equal(release.every((r: { smoke: boolean }) => r.smoke), true)
    // Every published version is a row or a named cell; the smoke stands down at run time where a train does not install.
    assert.equal(release.length, 3 + PUBLISHED.length - 2)
    assert.ok(release.some((r: { cell: string }) => r.cell === '0.0.1-rc.1') && release.some((r: { cell: string }) => r.cell === '0.1.0-rc.2'))
  })

  it('does not repeat a version a named cell in the same plan covers', () => {
    const rows = planCells(['pinned', 'floor', 'desktop', 'sweep'], facts).map((r: { cell: string }) => r.cell)
    assert.deepEqual(rows.slice(0, 3), ['pinned', 'floor', 'desktop'])
    assert.ok(!rows.includes(FLOOR) && !rows.includes('0.1.7-rc.2'))
    assert.ok(rows.includes('0.1.7-rc.1'))
  })

  it('rejects an unknown cell or smoke policy', () => {
    assert.throws(() => planCells(['nightly'], facts), /unknown cell/)
    assert.throws(() => planCells(['sweep'], facts, 'some'), /unknown smoke policy/)
  })

  it('knows the head of each tuple', () => {
    assert.deepEqual([...tupleHeads(['0.1.2-alpha.5', '0.1.2-rc.1', '0.1.3-alpha.2'])].sort(), ['0.1.2-rc.1', '0.1.3-alpha.2'])
  })
})

describe('repointed cells', () => {
  const toolchain = Object.keys(pkg.devDependencies).filter((name) => !name.startsWith('@deepseek-ai/'))

  it('keep the toolchain the lockfile resolved, so only the harness moves', () => {
    // Also runs inside repointed cells, whose manifest is already pinned.
    const before = structuredClone(pkg)
    const pinned = pinToolchain(pkg, lock)
    assert.ok(toolchain.includes('typescript') && toolchain.includes('@types/node'))
    for (const name of toolchain) assert.equal(pinned.devDependencies[name], lock.packages[`node_modules/${name}`].version, name)
    for (const [name, range] of Object.entries(pkg.devDependencies as Record<string, string>)) {
      if (name.startsWith('@deepseek-ai/')) assert.equal(pinned.devDependencies[name], range, name)
    }
    assert.deepEqual(pkg, before, 'the manifest it was given is left alone')
  })

  it('refuse a lockfile that does not resolve a devDependency', () => {
    const { ['node_modules/typescript']: _gone, ...packages } = lock.packages
    assert.throws(() => pinToolchain(pkg, { ...lock, packages }), /no exact version of devDependency typescript/)
  })
})

describe('release notes', () => {
  const script = fileURLToPath(new URL('../scripts/release-notes.mjs', import.meta.url))
  const asset = 'a'.repeat(64)
  function notes(cells: Record<string, object[]>) {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-viewer-notes-'))
    try {
      for (const [cell, rows] of Object.entries(cells)) {
        mkdirSync(join(dir, `harness-${cell}`))
        writeFileSync(join(dir, `harness-${cell}`, 'smoke.jsonl'), rows.map((r) => JSON.stringify(r)).join('\n') + '\n')
      }
      return spawnSync(process.execPath, [script, dir, '--sha256', asset], { encoding: 'utf8' })
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  }
  const smoked = (dsh: string, extra: object = {}) => ({ dsh, outcome: 'passed', strict: true, tarballSha256: asset, ...extra })

  it('names the smoked tarball and every version it passed on', () => {
    const r = notes({ floor: [smoked('0.1.1-rc.2')], pinned: [smoked('0.1.7-rc.2')], 'desktop-bytes': [smoked('0.1.7-rc.2')] })
    assert.equal(r.status, 0, r.stderr)
    assert.match(r.stdout, new RegExp(`sha256 \`${asset}\``))
    assert.match(r.stdout, /\| desktop-bytes \| 0\.1\.7-rc\.2 \| passed \|\n\| floor \| 0\.1\.1-rc\.2 \| passed \|\n\| pinned \|/)
  })

  it('refuses to claim a smoke of the release when a cell smoked other bytes, none, or not strictly', () => {
    const other = notes({ floor: [smoked('0.1.1-rc.2')], pinned: [smoked('0.1.7-rc.2', { tarballSha256: 'b'.repeat(64) })] })
    assert.equal(other.status, 1)
    assert.match(other.stderr, /smoked a different tarball.*pinned/)
    assert.match(notes({ pinned: [smoked('0.1.7-rc.2', { tarballSha256: undefined })] }).stderr, /pinned \(no digest\)/)
    assert.match(notes({}).stderr, /no smoke results/)
    assert.match(notes({ floor: [smoked('0.1.1-rc.2', { strict: false })] }).stderr, /did not pass a strict smoke: floor/)
  })
})

describe('desktop feed', () => {
  it('reads the folded scalars electron-builder writes', () => {
    const feed = parseFeed([
      'version: 0.1.7-rc.2',
      'files:',
      '  - url: >-',
      '      https://download.deepseek.com/dsh-desk/bin/mac-arm64/deepseek-harness-0.1.7-rc.2-mac-arm64.zip',
      '    sha512: >-',
      '      aOfxtRvFqTRRp3zqu6nXNgILgVdHDPyfslhUVNnU1wMYw1dY1vTelptJeAmUDt7G822SCqHzxtPwMmvCGekveA==',
      '    size: 372794444',
      'path: >-',
      '  https://download.deepseek.com/dsh-desk/bin/mac-arm64/deepseek-harness-0.1.7-rc.2-mac-arm64.zip',
      'sha512: >-',
      '  aOfxtRvFqTRRp3zqu6nXNgILgVdHDPyfslhUVNnU1wMYw1dY1vTelptJeAmUDt7G822SCqHzxtPwMmvCGekveA==',
      "releaseDate: '2026-09-24T14:10:00.562Z'",
    ].join('\n'))
    assert.deepEqual(feed, {
      version: '0.1.7-rc.2',
      path: 'https://download.deepseek.com/dsh-desk/bin/mac-arm64/deepseek-harness-0.1.7-rc.2-mac-arm64.zip',
      sha512: 'aOfxtRvFqTRRp3zqu6nXNgILgVdHDPyfslhUVNnU1wMYw1dY1vTelptJeAmUDt7G822SCqHzxtPwMmvCGekveA==',
      releaseDate: '2026-09-24T14:10:00.562Z',
      size: 372794444,
    })
  })
})

describe('boot smoke parsing', () => {
  it('reads the shell module table of 0.1.1 and of 0.1.7', () => {
    const v011 = 'function Jd(){return{react:e6,"react/jsx-runtime":i6,"react-dom":a6,"react-dom/client":d6,"@deepseek-ai/cordis":H5,"@deepseek-ai/dsh-client-ui-slots":g6,"@deepseek-ai/dsh-client-ui-primitives":Kd}}const h1={PENDING:0}'
    const v017 = 'async function BS(e,n){await e.inject(["uiRenderer"],o=>{})}function WS(){return{react:yf,"react/jsx-runtime":jf,"react-dom":Lf,"react-dom/client":Tf,"@deepseek-ai/cordis":Jd,"@deepseek-ai/dsh-client-store":th,"@deepseek-ai/dsh-client-ui-slots":lh,"@deepseek-ai/dsh-client-ui-primitives":qb,"@deepseek-ai/dsh-client-ui-dockkit":FS}}'
    assert.equal(moduleTableOf(v011).length, 7)
    assert.ok(!moduleTableOf(v011).includes('@deepseek-ai/dsh-client-store'))
    assert.deepEqual(moduleTableOf(v017).slice(-2), ['@deepseek-ai/dsh-client-ui-primitives', '@deepseek-ai/dsh-client-ui-dockkit'])
    assert.equal(moduleTableOf('const a={b:1}'), undefined)
  })

  it('holds a skipped bundle and an audit line naming this package against it, and nothing else', () => {
    const name = '@crosery/dsh-viewer'
    const skipped = classifyDiagnostics(`dsh: skipping profile bundle "${name}": peer @deepseek-ai/dsh-tools@<0.1.6-0 does not admit 0.1.7-rc.2\n`, name)
    assert.equal(skipped.ours.length, 1)
    const audit017 = classifyDiagnostics(`dsh: warning: 2 entries did not activate\nviewer (${name}): pending (waiting for service: sessions)\nremote-x (@deepseek-ai/dsh-remote-x): boom\n\nlater`, name)
    assert.deepEqual(audit017.ours, [`viewer (${name}): pending (waiting for service: sessions)`])
    assert.deepEqual(audit017.others, ['remote-x (@deepseek-ai/dsh-remote-x): boom'])
    const audit011 = classifyDiagnostics(`Error: dsh: 1 entry did not activate\n${name}: TypeError: x is not a function\n`, name)
    assert.equal(audit011.ours.length, 1)
    assert.deepEqual(classifyDiagnostics('dsh web: http://127.0.0.1:1/?token=abc\n', name), { ours: [], others: [] })
    const rejected = classifyDiagnostics(`dsh: installation rejected: Plugin ${name}@0.1.1 is incompatible with dsh 0.1.7-rc.2: peerDependencies {}\nPlugin ${name}@0.1.1 is incompatible with dsh 0.1.7-rc.2: peerDependencies {}\n`, name)
    assert.equal(rejected.ours.length, 1)
  })

  it('reads the boot graph in the 0.1.0 and the 0.1.1+ spelling', () => {
    const graph = { entries: [{ id: '@crosery/dsh-viewer', url: '/plugins/x/client.js?rev=1' }] }
    assert.deepEqual(bootGraphOf(`<head><script>globalThis["__DSH_BOOT__"] = ${JSON.stringify(graph)}</script></head>`), graph)
    assert.deepEqual(bootGraphOf(`<script src="/a.js"></script><script>window.__DSH_BOOT__ = ${JSON.stringify(graph)}</script>`), graph)
    assert.equal(bootGraphOf('<html></html>'), undefined)
  })

  it('installs a train as of its own release, not the next one', () => {
    const times = {
      created: '2026-08-01T00:00:00.000Z', modified: '2026-09-26T00:00:00.000Z',
      '0.1.6-alpha.1': '2026-09-15T03:23:13.750Z', '0.1.6-alpha.2': '2026-09-17T13:52:10.201Z', '0.1.7-alpha.1': '2026-09-22T06:23:31.522Z',
    }
    // One second after its own @deepseek-ai/dsh: 0.1.6-alpha.2's dsh-app-boot went out at 13:39, before the cutoff the next harness gave.
    assert.equal(releaseCutoff(times, '0.1.6-alpha.1'), '2026-09-15T03:23:14.750Z')
    assert.deepEqual([...laterHarnessVersions(times, '0.1.6-alpha.1')].sort(), ['0.1.6-alpha.2', '0.1.7-alpha.1'])
    assert.equal(releaseCutoff(times, '0.1.7-alpha.1'), undefined)
    assert.throws(() => releaseCutoff(times, '0.1.4-rc.0'), /not on npm/)
    const later = laterHarnessVersions(times, '0.1.6-alpha.1')
    assert.deepEqual(strayPackages([['@deepseek-ai/dsh', '0.1.6-alpha.1'], ['@deepseek-ai/dsh-app-boot', '0.1.6-alpha.2'], ['@deepseek-ai/cordis', '0.1.6-alpha.2'], ['react', '0.1.7-alpha.1']], later), [['@deepseek-ai/dsh-app-boot', '0.1.6-alpha.2']])
  })

  it('names the package a train published after the cutoff, in both of npm\'s refusals', () => {
    const late = 'npm error notarget No matching version found for @deepseek-ai/dsh-client-ui-sidebar-documentpreview@^0.1.5-rc.3 with a date before 2026/9/22 14:23:31.'
    assert.deepEqual(refusedAsUnpublished(late), { name: '@deepseek-ai/dsh-client-ui-sidebar-documentpreview', version: '0.1.5-rc.3' })
    assert.deepEqual(refusedAsUnpublished('npm error code ENOVERSIONS\nnpm error No versions available for @deepseek-ai/dsh-shell\n'), { name: '@deepseek-ai/dsh-shell' })
    assert.equal(refusedAsUnpublished('npm error code ERESOLVE'), undefined)
  })

  it('never lets a session token through', () => {
    assert.equal(maskTokens('dsh web: http://127.0.0.1:8/?token=Zx-9_a.b~c%2F'), 'dsh web: http://127.0.0.1:8/?token=***')
  })

  it('finds the peers a legacy install left unmet, the way Node would resolve them', () => {
    const modules = join(mkdtempSync(join(tmpdir(), 'dsh-viewer-peers-')), 'node_modules')
    const put = (dir: string, manifest: object) => {
      mkdirSync(join(modules, dir), { recursive: true })
      writeFileSync(join(modules, dir, 'package.json'), JSON.stringify(manifest))
    }
    try {
      put('@deepseek-ai/dsh', { name: '@deepseek-ai/dsh', peerDependencies: { react: '^18.3.1', '@deepseek-ai/cordis': '^4.0.0', 'left-out': '^2.0.0' }, peerDependenciesMeta: { 'left-out': { optional: true } } })
      put('react', { name: 'react' })
      put('@deepseek-ai/dsh-tools', { name: '@deepseek-ai/dsh-tools', peerDependencies: { '@deepseek-ai/dsh-scope': '0.1.1-rc.2', '@deepseek-ai/cordis': '^4.0.2' } })
      put('@deepseek-ai/dsh-tools/node_modules/nested', { name: 'nested', peerDependencies: { own: '1.x', react: '*' } })
      put('@deepseek-ai/dsh-tools/node_modules/own', { name: 'own' })
      assert.deepEqual([...unmetPeers(modules)].sort(), [['@deepseek-ai/cordis', '^4.0.0'], ['@deepseek-ai/dsh-scope', '0.1.1-rc.2']])
      put('@deepseek-ai/cordis', { name: '@deepseek-ai/cordis' })
      put('@deepseek-ai/dsh-scope', { name: '@deepseek-ai/dsh-scope' })
      assert.equal(unmetPeers(modules).size, 0)
    } finally {
      rmSync(join(modules, '..'), { recursive: true, force: true })
    }
  })

  it('tells a mounted app from the boot page of every shell', () => {
    // #root before the shell script ran, the early React boot page, the 0.1.0-rc.8+ splash.
    assert.equal(bootPageState({ text: '', children: 0 }), 'loading')
    assert.equal(bootPageState({ text: 'HARNESS\nLoading plugins…', children: 1 }), 'loading')
    assert.equal(bootPageState({ text: 'HARNESS\nFailed to load plugins\n@crosery/dsh-viewer\nweb boot: 1 entry did not activate\n@crosery/dsh-viewer: pending (waiting for service: slots)', children: 1 }), 'failed')
    assert.equal(bootPageState({ text: 'New session\nWorkspaces', children: 1 }), 'settled')
  })

  it('reads which plugin modules a script URL serves, alone or in a combo', () => {
    assert.deepEqual(modulesServedBy('http://127.0.0.1:9/plugins/@crosery/dsh-viewer/client.js?rev=e328d723ba0b'), ['@crosery/dsh-viewer'])
    assert.deepEqual(modulesServedBy('http://127.0.0.1:9/plugins/??@crosery/dsh-viewer/client.js&rev=1'), ['@crosery/dsh-viewer'])
    assert.deepEqual(modulesServedBy('http://127.0.0.1:9/plugins/??@crosery/dsh-viewer/client.js,@deepseek-ai/dsh-typert-registry/client.js&rev=1'), ['@crosery/dsh-viewer', '@deepseek-ai/dsh-typert-registry'])
    assert.deepEqual(modulesServedBy('http://127.0.0.1:9/assets/index-Q6zc2uHV.js'), [])
    assert.deepEqual(modulesServedBy('not a url'), [])
    const combo = ['window.__ModuleLoader__.load({ id: "@deepseek-ai/a", factory: (require) => {', '}});', 'window.__ModuleLoader__.load({ id: "@crosery/dsh-viewer", factory: (require) => {', 'x', '}});', 'window.__ModuleLoader__.load({ id: "@deepseek-ai/b", factory: 1 });'].join('\n')
    assert.deepEqual(moduleLines(combo, '@crosery/dsh-viewer'), [3, 5])
    assert.deepEqual(moduleLines(combo, '@deepseek-ai/b'), [6, 6])
    assert.equal(moduleLines(combo, '@deepseek-ai/c'), undefined)
  })

  it('holds a browser report against this plugin only when it is about this plugin', () => {
    const name = '@crosery/dsh-viewer'
    const own = 'http://127.0.0.1:9/plugins/@crosery/dsh-viewer/client.js?rev=1'
    const combo = 'http://127.0.0.1:9/plugins/??@crosery/dsh-viewer/client.js,@deepseek-ai/dsh-typert-registry/client.js&rev=2'
    const lines = (url: string) => (url === combo ? [1, 1200] as [number, number] : undefined)
    // A frame in this plugin's own script, or in its lines of a combo.
    assert.ok(blamesPlugin({ texts: ['TypeError: x is not a function', `    at apply (${own}:1081:28)`] }, name))
    assert.ok(blamesPlugin({ texts: ['Error: boom', `    at ${combo}:1081:28`] }, name, lines))
    // Another module's frame in the same combo is not this plugin's.
    assert.ok(!blamesPlugin({ texts: ['Error: boom', `    at ${combo}:1500:3`] }, name, lines))
    assert.ok(!blamesPlugin({ texts: ['Error: boom', `    at ${combo}:1081:28`] }, name))
    // A request for a script that carries this plugin failing is this plugin failing to load.
    assert.ok(blamesPlugin({ texts: [combo, 'net::ERR_CONNECTION_RESET'], request: true }, name))
    assert.ok(!blamesPlugin({ texts: ['http://127.0.0.1:9/plugins/??@deepseek-ai/dsh-typert-registry/client.js&rev=2'], request: true }, name))
    // The package named in the text: the boot page, the plugin's own warnings.
    assert.ok(blamesPlugin({ texts: ['HARNESS\nFailed to load plugins\n@crosery/dsh-viewer\nweb boot: 1 entry did not activate'] }, name))
    assert.ok(blamesPlugin({ texts: ['[dsh-viewer] could not register into "tool.call.toolview"; the rest of the viewer is unaffected Error: refused', undefined] }, name))
    assert.ok(blamesPlugin({ texts: ['cannot load %40crosery%2Fdsh-viewer'] }, name))
    assert.ok(!blamesPlugin({ texts: ['Failed to load resource: the server responded with a status of 404 (Not Found)', 'http://127.0.0.1:9/favicon.ico:1:1'] }, name))
  })

  it('finds the seed members a bundle reads and the names a module exports', () => {
    const bundle = 'var import_dsh_client_ui_primitives = require("x"); import_dsh_client_ui_primitives.IconCloseOutline16; import_dsh_client_ui_primitives2.Button'
    assert.deepEqual([...membersRead(bundle, 'dsh_client_ui_primitives')].sort(), ['Button', 'IconCloseOutline16'])
    assert.deepEqual([...exportedNames('export { a, b as Button, c as IconCloseRegular16 };')].sort(), ['Button', 'IconCloseRegular16', 'a'])
    assert.equal(exportedNames('export * from "./x.js"'), undefined)
  })
})

describe('verdict', () => {
  type Issue = { number: number; title: string; state: string; comments: string[] }
  type Job = { name: string; conclusion: string | null; steps?: { name: string; conclusion: string | null }[] }
  function fakeGithub(issues: Issue[], jobs: Job[] = []) {
    const calls: string[] = []
    const github = {
      paginate: async (fn: unknown, args: { issue_number?: number }) => {
        if (fn === github.rest.actions.listJobsForWorkflowRun) return jobs
        if (fn === github.rest.issues.listComments) return issues.find((i) => i.number === args.issue_number)!.comments.map((body) => ({ body }))
        return issues.filter((i) => i.state === 'open')
      },
      rest: {
        actions: { listJobsForWorkflowRun: () => undefined },
        issues: {
          listForRepo: () => undefined,
          listComments: () => undefined,
          getLabel: async () => ({}),
          createLabel: async () => { calls.push('createLabel') },
          create: async ({ title, body }: { title: string; body: string }) => { calls.push(`create ${title}`); issues.push({ number: issues.length + 1, title, state: 'open', comments: [body] }) },
          createComment: async ({ issue_number, body }: { issue_number: number; body: string }) => { calls.push(`comment #${issue_number}`); issues.find((i) => i.number === issue_number)!.comments.push(body) },
          update: async ({ issue_number, state }: { issue_number: number; state: string }) => { calls.push(`${state} #${issue_number}`); issues.find((i) => i.number === issue_number)!.state = state },
        },
      },
    }
    return { github, calls }
  }
  const context = { serverUrl: 'https://github.com', repo: { owner: 'Crosery', repo: 'dsh-viewer' }, runId: 1 }
  function fakeCore() {
    const state = { failed: '' }
    const summary = { addHeading: () => summary, addList: () => summary, write: async () => undefined }
    return { core: { summary, setFailed: (m: string) => { state.failed = m } }, state }
  }
  const stages = (o: Record<string, string>) => Object.fromEntries(Object.entries(o).map(([k, v]) => [`STAGE_${k}`, v]))

  it('closes issue #10 on the first fully green run of its cell', async () => {
    const issues = [{ number: 10, title: 'Harness compatibility broken against @alpha', state: 'open', comments: [] }]
    const { github, calls } = fakeGithub(issues)
    const { core, state } = fakeCore()
    const env = { CELL: 'alpha', VERSION: '0.1.7-alpha.2', REPORT: 'true', INCOMPLETE: 'false', EXPECTED: 'types,tests,admission,smoke', ...stages({ resolve: 'success', install: 'success', types: 'success', tests: 'success', admission: 'success', smoke: 'success' }) }
    const result = await verdict({ github, context, core, env })
    assert.equal(result.green, true)
    assert.deepEqual(calls, ['comment #10', 'closed #10'])
    assert.equal(state.failed, '')
  })

  it('opens one issue per failing cell, then comments on it', async () => {
    const issues: Issue[] = []
    const { github, calls } = fakeGithub(issues)
    const env = { CELL: 'desktop', VERSION: '0.1.8-rc.1', REPORT: 'true', INCOMPLETE: 'false', EXPECTED: 'types,tests,admission,smoke', ...stages({ types: 'success', tests: 'success', admission: 'failure', smoke: 'failure' }) }
    const first = fakeCore()
    await verdict({ github, context, core: first.core, env })
    await verdict({ github, context, core: fakeCore().core, env })
    assert.deepEqual(calls, ['create Harness compatibility broken against @desktop', 'comment #1'])
    assert.match(issues[0]!.comments[0]!, /admission.*dsh ≥0\.1\.7 refuses/s)
    assert.match(first.state.failed, /admission, smoke/)
  })

  it('leaves the issue alone on an incomplete train or a cancelled run', async () => {
    const issues = [{ number: 3, title: 'Harness compatibility broken against @alpha', state: 'open', comments: [] }]
    const { github, calls } = fakeGithub(issues)
    await verdict({ github, context, core: fakeCore().core, env: { CELL: 'alpha', REPORT: 'true', INCOMPLETE: 'true', EXPECTED: 'types,tests,admission', ...stages({ resolve: 'success', types: '', tests: '', admission: 'success' }) } })
    const { core, state } = fakeCore()
    const result = await verdict({ github, context, core, env: { CELL: 'alpha', REPORT: 'true', INCOMPLETE: 'false', JOB_STATUS: 'cancelled', EXPECTED: 'types,tests,admission,smoke', ...stages({ types: 'success', tests: 'success', admission: 'success', smoke: 'cancelled' }) } })
    assert.deepEqual(calls, [])
    assert.equal(result.cancelled, true)
    assert.equal(state.failed, '')
  })

  it('counts a stage cancelled by a time limit as failed, and a setup failure too', async () => {
    const issues: Issue[] = []
    const { github, calls } = fakeGithub(issues)
    const { core, state } = fakeCore()
    const result = await verdict({ github, context, core, env: { CELL: 'next', VERSION: '0.1.7-rc.2', REPORT: 'true', INCOMPLETE: 'false', JOB_STATUS: 'success', EXPECTED: 'types,tests,admission,smoke', ...stages({ setup: 'success', types: 'success', tests: 'success', admission: 'success', smoke: 'cancelled' }) } })
    assert.deepEqual(result.failed, ['smoke'])
    assert.deepEqual(calls, ['create Harness compatibility broken against @next'])
    assert.match(issues[0]!.comments[0]!, /smoke\*\* \(cancelled, which counts as failed\)/)
    assert.match(state.failed, /smoke/)
    const setup = await verdict({ github, context, core: fakeCore().core, env: { CELL: 'next', REPORT: 'false', EXPECTED: 'types', ...stages({ setup: 'failure', types: '' }) } })
    assert.deepEqual(setup.failed, ['setup'])
  })

  it('names the cell of a job, called or not', () => {
    assert.equal(verdict.cellOf('harness@floor'), 'floor')
    assert.equal(verdict.cellOf('harness / harness@0.1.2-rc.1'), '0.1.2-rc.1')
    assert.equal(verdict.cellOf('gate / plan'), 'plan')
    assert.equal(verdict.cellOf('harness@desktop-bytes'), 'desktop-bytes')
    assert.equal(verdict.cellOf('node 24'), undefined)
    assert.equal(verdict.cellOf('unreported'), undefined)
  })

  it('files every failed job whose verdict did not report this run, and nothing twice', async () => {
    const run = 'https://github.com/Crosery/dsh-viewer/actions/runs/1'
    const issues: Issue[] = [
      { number: 4, title: 'Harness compatibility broken against @alpha', state: 'open', comments: ['old', `failed: types\n\nRun: ${run}`] },
      { number: 5, title: 'Harness compatibility broken against @next', state: 'open', comments: ['from an earlier run'] },
      { number: 6, title: 'Harness compatibility run could not plan its cells', state: 'open', comments: ['earlier'] },
    ]
    const jobs: Job[] = [
      { name: 'plan', conclusion: 'success' },
      { name: 'harness@alpha', conclusion: 'failure' },
      { name: 'harness@next', conclusion: 'cancelled', steps: [{ name: 'Install that train', conclusion: 'cancelled' }] },
      { name: 'harness@desktop-bytes', conclusion: 'failure', steps: [{ name: 'Run actions/checkout@v4', conclusion: 'failure' }] },
      { name: 'harness@latest', conclusion: 'success' },
      { name: 'unreported', conclusion: null },
    ]
    const { github, calls } = fakeGithub(issues, jobs)
    const { filed } = await verdict.unreported({ github, context, core: fakeCore().core })
    assert.deepEqual(filed, ['next', 'desktop-bytes'])
    assert.deepEqual(calls, ['comment #6', 'closed #6', 'comment #5', 'create Harness compatibility broken against @desktop-bytes'])
    assert.match(issues[1]!.comments.at(-1)!, /ended cancelled before its verdict could report[\s\S]*`Install that train` \(cancelled\)/)

    const planFailed = fakeGithub([], [{ name: 'plan', conclusion: 'failure' }])
    await verdict.unreported({ github: planFailed.github, context, core: fakeCore().core })
    assert.deepEqual(planFailed.calls, ['create Harness compatibility run could not plan its cells'])
  })

  it('reports an incomplete train whose version the peer ranges refuse', async () => {
    const issues: Issue[] = []
    const { github, calls } = fakeGithub(issues)
    const { core, state } = fakeCore()
    const result = await verdict({ github, context, core, env: { CELL: 'desktop', VERSION: '0.1.8-rc.1', REPORT: 'true', INCOMPLETE: 'true', EXPECTED: 'types,tests,admission,smoke', ...stages({ resolve: 'success', install: '', types: '', tests: '', admission: 'failure', smoke: '' }) } })
    assert.deepEqual(result.failed, ['admission'])
    assert.deepEqual(calls, ['create Harness compatibility broken against @desktop'])
    assert.match(state.failed, /admission/)
  })

  it('fails the job but files nothing when not reporting', async () => {
    const { github, calls } = fakeGithub([])
    const { core, state } = fakeCore()
    await verdict({ github, context, core, env: { CELL: 'floor', REPORT: 'false', EXPECTED: 'types', ...stages({ types: 'failure' }) } })
    assert.deepEqual(calls, [])
    assert.match(state.failed, /types/)
  })
})

describe('registry failures are failures, not incomplete trains', () => {
  const repo = fileURLToPath(new URL('..', import.meta.url))
  /** A copy of what the scripts need, so no run can rewrite this checkout's manifest. */
  let copy = ''
  let cache = ''
  const servers: Server[] = []

  /**
   * A registry that knows `packuments` and answers 404 for anything else, or
   * 500 for everything. `manifests` adds fields to one `name@version`.
   */
  async function registry(mode: '500' | Record<string, string[]>, manifests: Record<string, object> = {}): Promise<string> {
    const server = createServer((req, res) => {
      const name = decodeURIComponent((req.url ?? '/').slice(1).split('?')[0]!)
      res.setHeader('content-type', 'application/json')
      if (mode === '500') { res.statusCode = 500; res.end('{"error":"boom"}'); return }
      const versions = mode[name]
      if (versions === undefined) { res.statusCode = 404; res.end('{"error":"Not found"}'); return }
      res.end(JSON.stringify({
        name,
        'dist-tags': { latest: versions.at(-1) },
        versions: Object.fromEntries(versions.map((version) => [version, { name, version, ...manifests[`${name}@${version}`] }])),
      }))
    })
    servers.push(server)
    await new Promise<void>((ok) => server.listen(0, '127.0.0.1', ok))
    return `http://127.0.0.1:${(server.address() as AddressInfo).port}/`
  }
  /** Nothing listens on the discard port: every request is refused. */
  const DOWN = 'http://127.0.0.1:9/'

  function node(args: string[], registryUrl: string): Promise<{ code: number; stdout: string; stderr: string }> {
    const env = {
      ...process.env,
      npm_config_registry: registryUrl, npm_config_cache: cache, npm_config_fetch_retries: '0',
      npm_config_update_notifier: 'false', GITHUB_OUTPUT: '', GITHUB_STEP_SUMMARY: '',
    }
    return new Promise((ok) => {
      execFile(process.execPath, args, { cwd: copy, env, encoding: 'utf8', timeout: 60_000 }, (error, stdout, stderr) => {
        ok({ code: error === null ? 0 : typeof error.code === 'number' ? error.code : 1, stdout, stderr })
      })
    })
  }
  /** Run a snippet against harness-lib; it prints one JSON line. */
  const lib = (code: string, registryUrl: string) =>
    node(['--input-type=module', '-e', `import * as lib from ${JSON.stringify(join(copy, 'scripts/harness-lib.mjs'))}\n${code}`], registryUrl)

  before(() => {
    copy = mkdtempSync(join(tmpdir(), 'dsh-viewer-registry-'))
    cache = join(copy, '.npm-cache')
    mkdirSync(join(copy, 'scripts'))
    for (const file of ['harness-lib.mjs', 'harness-target.mjs', 'sweep-trains.mjs']) cpSync(join(repo, 'scripts', file), join(copy, 'scripts', file))
    for (const file of ['package.json', 'package-lock.json']) cpSync(join(repo, file), join(copy, file))
    symlinkSync(join(repo, 'node_modules'), join(copy, 'node_modules'), 'dir')
  })
  after(() => {
    for (const server of servers) server.close()
    rmSync(copy, { recursive: true, force: true })
  })

  it('tells a registry that did not answer from a graph that does not resolve', () => {
    assert.ok(registryFailed('npm error code ECONNREFUSED\nnpm error errno ECONNREFUSED'))
    assert.ok(registryFailed('npm error code E503\nnpm error 503 Service Unavailable - GET https://registry.npmjs.org/x'))
    assert.ok(registryFailed('npm error code EAI_AGAIN'))
    assert.ok(!registryFailed('npm error code ERESOLVE\nnpm error ERESOLVE could not resolve'))
    assert.ok(graphFailed('npm error code ETARGET\nnpm error notarget No matching version found for x@9.9.9.'))
    assert.ok(graphFailed('npm error code E404\nnpm error 404 Not Found - GET http://127.0.0.1/x'))
    assert.equal(graphEvidence('noise\nnpm error code E404\nnpm error 404 Not Found - GET https://registry.npmjs.org/@deepseek-ai%2fdsh-agent-tool-mode - Not found\nnpm error 404\nnpm error A complete log'),
      'npm error code E404\nnpm error 404 Not Found - GET https://registry.npmjs.org/@deepseek-ai%2fdsh-agent-tool-mode - Not found\nnpm error 404')
    assert.ok(!graphFailed('npm error code ECONNRESET'))
    assert.equal(npmErrorCode('{"error":{"code":"E404","summary":"Not found"}}', ''), 'E404')
    assert.equal(npmErrorCode('', 'npm error code ECONNREFUSED\n'), 'ECONNREFUSED')
  })

  it('reads E404 as "does not exist" and anything else as a registry error', async () => {
    const known = await registry({ '@deepseek-ai/dsh': ['0.1.7-rc.2'] })
    const probe = `
      const out = {}
      for (const [key, spec, field] of [['missing', '@crosery/surely-not-published', 'versions'], ['version', '@deepseek-ai/dsh@9.9.9', 'version'], ['list', '@deepseek-ai/dsh', 'versions']]) {
        try { out[key] = lib.view(spec, field) ?? null } catch (error) { out[key] = error.constructor.name }
      }
      console.log(JSON.stringify(out))`
    assert.deepEqual(JSON.parse((await lib(probe, known)).stdout), { missing: null, version: null, list: ['0.1.7-rc.2'] })
    for (const url of [DOWN, await registry('500')]) {
      const { stdout } = await lib(`try { lib.versionsOf('@deepseek-ai/dsh'); console.log('"answered"') } catch (error) { console.log(JSON.stringify(error.constructor.name)) }`, url)
      assert.equal(JSON.parse(stdout), 'RegistryError', url)
    }
  })

  it('fails a cell when the registry is down instead of calling the train incomplete', async () => {
    for (const url of [DOWN, await registry('500')]) {
      const r = await node(['scripts/harness-target.mjs', '0.1.7-rc.2', '--admits'], url)
      assert.equal(r.code, 1, `${url}: ${r.stdout}${r.stderr}`)
      assert.doesNotMatch(r.stdout, /incomplete=true/)
      assert.match(r.stderr, /npm registry did not answer/)
    }
  })

  it('calls a version npm does not have incomplete, but never the floor or an empty harness', async () => {
    const url = await registry({ '@deepseek-ai/dsh': ['0.1.7-rc.1', '0.1.7-rc.2'] })
    const absent = await node(['scripts/harness-target.mjs', '9.9.9'], url)
    assert.equal(absent.code, 3, absent.stderr)
    assert.match(absent.stdout, /incomplete=true/)

    const floor = await node(['scripts/harness-target.mjs', 'floor'], url)
    assert.equal(floor.code, 1, floor.stdout)
    assert.match(floor.stderr, /claims \(the floor\)/)
    // The install step names the floor by its version.
    assert.equal((await node(['scripts/harness-target.mjs', FLOOR], url)).code, 1)

    const nothing = await registry({})
    const plan = await node(['scripts/harness-target.mjs', '--plan', 'sweep'], nothing)
    assert.equal(plan.code, 1, plan.stdout)
    assert.doesNotMatch(plan.stdout, /matrix=/)
    assert.match(plan.stderr, /lists no version of @deepseek-ai\/dsh/)
  })

  it('installs through the train only on a graph failure, and calls it incomplete only when upstream fails too', async () => {
    const install = (url: string) => lib(`
      const dir = ${JSON.stringify(join(copy, 'train'))}
      const { mkdirSync } = await import('node:fs')
      mkdirSync(dir, { recursive: true })
      const manifest = { name: 'probe', version: '0.0.0', private: true, devDependencies: { 'not-published-anywhere': '1.0.0' } }
      try {
        const r = lib.installTrain(dir, manifest, '0.1.7-rc.2')
        console.log(JSON.stringify({ ok: r.ok, incomplete: r.incomplete, via: r.via }))
      } catch (error) { console.log(JSON.stringify(error.constructor.name)) }`, url)
    const empty = JSON.parse((await install(await registry({}))).stdout)
    assert.deepEqual(empty, { ok: false, incomplete: true, via: '@deepseek-ai/dsh@0.1.7-rc.2 graph (the peer graph named a package npm cannot find)' })
    assert.equal(JSON.parse((await install(DOWN)).stdout), 'RegistryError')
  })

  it('repoints only the harness and pins the toolchain from the lockfile', async () => {
    const harness = Object.keys(pkg.devDependencies).filter((name) => name.startsWith('@deepseek-ai/dsh-'))
    const url = await registry(Object.fromEntries(['@deepseek-ai/dsh', ...harness].map((name) => [name, ['0.1.7-rc.2', '0.1.7-rc.9']])))
    const r = await node(['scripts/harness-target.mjs', '0.1.7-rc.9', '--repoint'], url)
    assert.equal(r.code, 0, r.stderr)
    const written = JSON.parse(readFileSync(join(copy, 'package.json'), 'utf8'))
    cpSync(join(repo, 'package.json'), join(copy, 'package.json'))
    for (const [name, range] of Object.entries(written.devDependencies as Record<string, string>)) {
      const expected = name.startsWith('@deepseek-ai/dsh-') ? '0.1.7-rc.9'
        : name.startsWith('@deepseek-ai/') ? pkg.devDependencies[name]
          : lock.packages[`node_modules/${name}`].version
      assert.equal(range, expected, name)
    }
  })

  /**
   * Every harness devDependency at `versions` and at this checkout's pin,
   * except `absent`, published at the pin only; plus `extra` packages. Built
   * from the manifest, because the sweep runs these tests in copies pinned to
   * every train.
   */
  function train(versions: string[], absent: string[] = [], extra: Record<string, string[]> = {}): Record<string, string[]> {
    const harness = Object.keys(pkg.devDependencies).filter((name) => name.startsWith('@deepseek-ai/dsh-'))
    return {
      '@deepseek-ai/dsh': versions,
      ...Object.fromEntries(harness.map((name) => [name, absent.includes(name) ? [pkg.devDependencies[name]] : [...versions, pkg.devDependencies[name]]])),
      ...extra,
    }
  }
  const escape = (text: string) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const RENDERER = '@deepseek-ai/dsh-client-ui-renderer'
  const HOME_PATHS = '@deepseek-ai/dsh-home-paths'
  const RUNTIME = '@deepseek-ai/dsh-client-runtime'
  const NEVER = { '@deepseek-ai/dsh@0.0.1-rc.1': { dependencies: { '@deepseek-ai/dsh-agent-tool-mode': '^0.0.1-rc.1' } } }

  it('keeps the pin for a package the train never published, and pins dsh-client-runtime where it has it', async () => {
    const url = await registry(train(['0.0.1-rc.5'], [RENDERER], { [RUNTIME]: ['0.0.1-rc.5', '0.1.1-rc.2'] }))
    const r = await node(['scripts/harness-target.mjs', '0.0.1-rc.5', '--repoint'], url)
    const written = JSON.parse(readFileSync(join(copy, 'package.json'), 'utf8'))
    cpSync(join(repo, 'package.json'), join(copy, 'package.json'))
    assert.equal(r.code, 0, `${r.stdout}${r.stderr}`)
    assert.doesNotMatch(r.stdout, /incomplete=true/)
    assert.match(r.stdout, new RegExp(`kept=${escape(`${RENDERER}@${pkg.devDependencies[RENDERER]} (predates at 0.0.1-rc.5)`)}`))
    assert.equal(written.devDependencies[RENDERER], pkg.devDependencies[RENDERER])
    assert.equal(written.devDependencies['@deepseek-ai/dsh-tools'], '0.0.1-rc.5')
    assert.equal(written.devDependencies[RUNTIME], '0.0.1-rc.5')
  })

  it('calls a train whose own harness does not install incomplete, with npm\'s evidence, and never the floor', async () => {
    const url = await registry(train(['0.0.1-rc.1', FLOOR], [RENDERER, HOME_PATHS]), { ...NEVER, [`@deepseek-ai/dsh@${FLOOR}`]: NEVER['@deepseek-ai/dsh@0.0.1-rc.1'] })
    const r = await node(['scripts/harness-target.mjs', '0.0.1-rc.1', '--repoint'], url)
    cpSync(join(repo, 'package.json'), join(copy, 'package.json'))
    assert.equal(r.code, 3, `${r.stdout}${r.stderr}`)
    assert.match(r.stdout, /incomplete=true/)
    assert.match(r.stdout, /does not install on its own[\s\S]*E404[\s\S]*dsh-agent-tool-mode/)
    // Two packages it compiles against are missing, so types and tests stand down too.
    assert.doesNotMatch(r.stdout, /compiles=true/)
    // Peer admission still runs on it, and admits it.
    const admits = await node(['scripts/harness-target.mjs', '0.0.1-rc.1', '--admits'], url)
    assert.equal(admits.code, 0, `${admits.stdout}${admits.stderr}`)

    const floor = await node(['scripts/harness-target.mjs', 'floor', '--repoint'], url)
    cpSync(join(repo, 'package.json'), join(copy, 'package.json'))
    assert.equal(floor.code, 1, floor.stdout)
    assert.match(floor.stderr, /claims \(the floor\)/)
  })

  it('still runs types and tests on an uninstallable train that published every package they need', async () => {
    const url = await registry(train(['0.0.1-rc.1']), NEVER)
    const r = await node(['scripts/harness-target.mjs', '0.0.1-rc.1', '--repoint'], url)
    cpSync(join(repo, 'package.json'), join(copy, 'package.json'))
    assert.equal(r.code, 3, `${r.stdout}${r.stderr}`)
    assert.match(r.stdout, /incomplete=true\ncompiles=true/)
  })

  it('sweeps an uninstallable train as incomplete upstream without failing', async () => {
    const url = await registry(train(['0.0.1-rc.1'], [RENDERER, HOME_PATHS]), NEVER)
    const r = await node(['scripts/sweep-trains.mjs', '--versions', '0.0.1-rc.1', '--work', join(copy, 'sweep-incomplete')], url)
    assert.equal(r.code, 0, `${r.stdout}${r.stderr}`)
    const kept = [RENDERER, HOME_PATHS].sort().map((name) => `${name.replace('@deepseek-ai/', '')}@${pkg.devDependencies[name]} (predates)`).join(', ')
    assert.match(r.stdout, new RegExp(`${escape(`| 0.0.1-rc.1 | yes | incomplete upstream | — | — | — | ${kept} | @deepseek-ai/dsh@0.0.1-rc.1 does not install on its own: `)}.*dsh-agent-tool-mode.*types and tests not run`))
  })

  it('fails the sweep on a registry error instead of passing the version as out of scope', async () => {
    const r = await node(['scripts/sweep-trains.mjs', '--versions', '0.1.7-rc.2', '--work', join(copy, 'sweep')], DOWN)
    assert.equal(r.code, 1, r.stdout)
    assert.match(r.stdout, /\| 0\.1\.7-rc\.2 \| yes \| registry error \|/)
  })
})
