// Regressions for inputs that used to take memory, or the host, down with them.
import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, writeFile, readFile, utimes } from 'node:fs/promises'
import { join } from 'node:path'
import { setTimeout as sleep } from 'node:timers/promises'
import { workspace, memoryService, crashCanary } from './helpers.js'
import { withAbort } from '../lib/core/async.js'
import { SecretScanner, redact } from '../lib/core/secrets.js'
import { encodeNote, decodeNote, scopeOf } from '../lib/stores/note.js'
import { efficiencyProjection, isSvgCreation } from '../lib/efficiency.js'

const put = async (w, key, body) => {
  const dir = join(w.vault, 'projects', scopeOf(w.project), 'facts')
  await mkdir(dir, { recursive: true })
  const path = join(dir, `${key}.md`)
  await writeFile(path, encodeNote({ title: key, dsh_key: key, dsh_project: w.project, dsh_updated_at: Date.now(),
    dsh_status: 'verified', dsh_kind: 'fact', dsh_files: [] }, body))
  return path
}

test('work abandoned by an already-cancelled caller never rejects unobserved', async t => {
  crashCanary(t)
  const cancelled = AbortSignal.abort(new Error('cancelled'))
  await assert.rejects(withAbort(Promise.reject(new Error('late failure')), cancelled), /cancelled/)
  // The real path: the first use of a configured scanner that cannot start, by a cancelled turn.
  const scanner = new SecretScanner(join(import.meta.dirname, 'no-such-scanner'))
  t.after(() => scanner.close())
  await assert.rejects(scanner.policy(cancelled), /cancelled/)
  await assert.rejects(scanner.policy(), { code: 'SCANNER_NOT_FOUND' })
})

test('a note whose last line invites a credential value does not make the project unreadable', async t => {
  const w = await workspace(t), service = memoryService(t, w, 'markdown')
  await put(w, 'aaa-rotation', 'Rotation checklist for the quokka deploy.\n\nRemember to set the password:')
  await put(w, 'zzz-marmot', 'Quokka marmot conclusion.')
  await sleep(150)
  const found = await service.search(w.project, 'zzz-marmot')
  assert.equal(found.status, 'ok', JSON.stringify(found.diagnostics))
  assert.equal(found.records[0].key, 'zzz-marmot')
  assert.match(found.records[0].summary, /Quokka marmot conclusion/)
  assert.equal((await service.search(w.project, 'aaa-rotation')).records[0].key, 'aaa-rotation')
})

test('notes dated in the future are read immediately instead of being treated as still changing', async t => {
  const w = await workspace(t), service = memoryService(t, w, 'markdown')
  const future = new Date(Date.now() + 3_600_000)
  for (let i = 0; i < 3; i++) await utimes(await put(w, `future-${i}`, `Quokka future note ${i}.`), future, future)
  const started = Date.now()
  const found = await service.search(w.project, 'future-1')
  assert.equal(found.status, 'ok', JSON.stringify(found.diagnostics))
  assert.equal(found.records[0].key, 'future-1')
  assert.ok(Date.now() - started < 900, 'no stability wait is spent on future-dated notes')
})

test('redaction is stable when a bearer token was already omitted', () => {
  const once = redact('Authorization: Bearer sk-abcdefghijklmnopqrstuvwx')
  assert.equal(once, 'Authorization: Bearer [credential omitted]')
  assert.equal(redact(once), once)
  assert.equal(redact('Authorization: Bearer opaque-token-value'), 'Authorization=[credential omitted]')
})

test('a task record for a request that starts with a blank line still gets a title', async t => {
  const w = await workspace(t), service = memoryService(t, w, 'markdown')
  const { path } = await service.storeFor(w.project).writeJournal(w.project, { prompt: '\n\nInvestigate the quokka cache', reply: 'done',
    status: 'completed', tools: [], sessionId: 'session-a', turn: 1, endSeq: 3, time: Date.now() })
  assert.equal(decodeNote(await readFile(path, 'utf8')).meta.title, 'Investigate the quokka cache')
})

test('SVG admission tolerates any message shape and a turn without a number keeps a valid checkpoint', () => {
  const user = { source: { kind: 'user' } }
  assert.equal(isSvgCreation([null, user, { ...user, content: 'draw an svg' }, { ...user, content: [null, { type: 'text' }, { type: 'text', text: 7 }] }]), false)
  assert.equal(isSvgCreation([{ ...user, content: [null, { type: 'text', text: 'Draw an SVG fox' }] }]), true)
  for (const data of [undefined, {}, { turn: 'x' }, { turn: -1 }]) {
    const state = efficiencyProjection.apply(efficiencyProjection.init({}, 0), { seq: 1, type: 'turn/start', time: 1000, data })
    assert.equal(state.turn, 0)
    assert.equal(efficiencyProjection.stateSchema.safeParse(state).success, true)
  }
})
