/**
 * 校验一个 tgz「装盘包」是否完好：能解出 package.json、版本号对得上、关键产物在。
 *
 * 为什么需要它（2026-09-13）：用户要求"把当前版本存档"。存档的前提是**这个包本身是好的** ——
 * 而本项目的 tgz 是靠内容指纹验证的，从来没有"打开包检查一遍"的步骤。
 * 一个字节损坏的 tarball 只有到 `dsh plugin add` 那一刻才会暴露，
 * 到那时用户可能已经重启过一次 DSH 了（代价很高）。
 *
 * 做法：零依赖读 gzip + tar 头（tar 格式足够简单，只需要前 512 字节的头部），
 * 不做完整解包，只核对：① gzip 能解；② tar 里能找到 package.json；③ 版本与期望一致；
 * ④ lib/client.js 与 lib/index.js 都在且非空；⑤ 内置角色库（`assets/personas/**`）在包里。
 *
 * ⚠️ tar 读取必须认 **PAX 扩展头**（长路径），实现见 `scripts/lib/tarReader.mjs`，
 * 判据见 `test/tarReader.test.mjs` —— 不认它会让长路径条目被静默漏掉（2026-10-01 实测）。
 *
 * 用法：node scripts/check-tgz.mjs <tgz路径> [期望版本]
 */
import { createGunzip } from 'node:zlib'
import { createReadStream, statSync } from 'node:fs'
import { basename } from 'node:path'
import { listTarEntries } from './lib/tarReader.mjs'

/**
 * ⚠️ tgz 路径**必须显式给**（2026-09-13 改）。
 *
 * 原先是 `process.argv[2] ?? 'dely0-dsh-personal-workbench-1.14.45.tgz'` ——
 * 一个写死的旧版本号默认值。它有两重坑：
 * 1. 忘了传参时会去校验一个跟当前版本无关的老包（甚至可能静默"通过"）；
 * 2. 整理归档后 tgz 已不在仓库根（历史包在 `_local-archive/tgz/`），
 *    那个默认值只会报"文件不存在"，把排查方向带偏。
 */
const tgz = process.argv[2]
if (tgz === undefined) {
  console.error('用法：node scripts/check-tgz.mjs <tgz路径> [期望版本]')
  console.error('  （tgz 由仓库根跑 `pnpm pack` 生成；历史包见 _local-archive/tgz/）')
  process.exit(2)
}
const expectedVersion = process.argv[3]

/**
 * 本仓库的 GitHub 身份。dsh-market 认这个 npm 包的唯一依据就是包内
 * `repository` 能不能指回它（见下面 ①b 的说明）。
 */
const EXPECTED_REPO = 'Dely0/dsh-personal-workbench'

/** 把 gzip 流解成 Buffer（tar 是顺序格式，整份读进来最简单）。 */
async function gunzip(file) {
  const chunks = []
  await new Promise((resolve, reject) => {
    const gunzipStream = createGunzip()
    createReadStream(file)
      .pipe(gunzipStream)
      .on('data', (chunk) => chunks.push(chunk))
      .on('end', resolve)
      .on('error', reject)
  })
  return Buffer.concat(chunks)
}

/**
 * tar 读取器已抽到 `scripts/lib/tarReader.mjs`（**可单测**，不再内联在脚本里）：
 * 它认 PAX 扩展头这件事必须有会失败的判据 —— 旧的静默漏条目 bug 就是"看不出来"。
 */
let buffer
try {
  buffer = await gunzip(tgz)
  console.log(`✅ gzip 解压成功（${statSync(tgz).size} 字节 → ${buffer.length} 字节 tar）`)
} catch (error) {
  console.error(`❌ gzip 解压失败：${error instanceof Error ? error.message : String(error)}`)
  process.exit(1)
}

const entries = listTarEntries(buffer)

const problems = []
console.log(`✅ tar 条目数：${entries.length}`)

/** ① package.json 必须能解析出版本号 */
const pkgEntry = entries.find((entry) => entry.name === 'package/package.json')
if (pkgEntry === undefined) {
  problems.push('包里没有 package/package.json')
} else {
  const text = buffer.subarray(pkgEntry.dataOffset, pkgEntry.dataOffset + pkgEntry.size).toString('utf8')
  try {
    const pkg = JSON.parse(text)
    console.log(`✅ package.json 可解析：${pkg.name}@${pkg.version}`)
    if (expectedVersion !== undefined && pkg.version !== expectedVersion) {
      problems.push(`版本不符：包内 ${pkg.version} ≠ 期望 ${expectedVersion}`)
    }
    /**
     * ①b dsh-market 认这个 npm 包的唯一依据（2026-09-15 事故）：包内 package.json 的
     * `repository` 必须指回同一个 GitHub 仓库，否则上游 `probe-npm.mjs` 判定为
     * "不是这个仓库的包" → 市场退回 `github:owner/repo` 源码安装（pnpm 解析成
     * `git+ssh://…`，没配 GitHub SSH 的用户直接 `Host key verification failed`），
     * 且 `downloads` 恒为 null（它的下载量普查只覆盖已映射到 npm 的条目）。
     */
    const repoField = typeof pkg.repository === 'string' ? pkg.repository : pkg.repository?.url ?? ''
    if (!repoField.toLowerCase().includes(EXPECTED_REPO.toLowerCase())) {
      problems.push(
        `repository 缺失或没指回 ${EXPECTED_REPO}（当前：${repoField === '' ? '(空)' : repoField}）`
        + ' —— dsh-market 会认不出这个 npm 包：退回 github: 源码安装、且不统计下载量',
      )
    } else {
      console.log(`✅ repository 指回 ${EXPECTED_REPO}（市场能把这个包映射到仓库）`)
    }
  } catch (error) {
    problems.push(`package.json 解析失败：${String(error)}`)
  }
}

/** ② 关键产物必须在且非空（这两个是插件的主体与客户端半边） */
for (const required of ['package/lib/client.js', 'package/lib/index.js']) {
  const entry = entries.find((item) => item.name === required)
  if (entry === undefined) problems.push(`缺少 ${required}`)
  else if (entry.size <= 0) problems.push(`${required} 是空文件`)
  else console.log(`✅ ${required}（${entry.size} 字节）`)
}

/** ③ 顺手确认 cordis.patch.yml 也打进去了（没有它插件不会被 loader 装上） */
if (entries.some((entry) => entry.name === 'package/cordis.patch.yml')) {
  console.log('✅ package/cordis.patch.yml 存在')
} else {
  problems.push('缺少 cordis.patch.yml（插件不会被 loader 装上）')
}

/**
 * ④ 内置角色库必须**真的在包里**（ADR 0005 / requirements §6.1）。
 *
 * 为什么要在"打包检查"这一层拦它：`files` 少写一行时，本地开发全绿、
 * 测试全绿（测试读的是仓库里的 `assets/`），只有**发布出去的包**里没有默认人格 ——
 * 用户装完发现"角色库是空的"，而我们在本机永远复现不出来。
 * 这与 `repository` 那条（①b）是同一类事故：**只有包本身才能证伪**。
 */
const personaEntries = entries.filter((entry) => /^package\/assets\/personas\/.+\.md$/i.test(entry.name) && entry.typeFlag !== '5')
if (personaEntries.length === 0) {
  problems.push('包里没有 assets/personas/**.md —— package.json 的 files 漏了内置角色库，发布出去的包会是"没有默认人格"的')
} else {
  console.log(`✅ 内置角色库：${personaEntries.length} 篇（assets/personas/**）`)
  const empty = personaEntries.filter((entry) => entry.size <= 0)
  if (empty.length > 0) problems.push(`内置角色文件为空：${empty.map((entry) => entry.name).join(', ')}`)
}
/** README 是说明而不是角色：它被排除（需求 §6.1），所以包里也不该有。 */
if (entries.some((entry) => /^package\/assets\/personas\/README\.md$/i.test(entry.name))) {
  console.log('ℹ️ assets/personas/README.md 在包里（会被发现逻辑按 README 排除，不影响角色数量）')
}

console.log(`\n包名：${basename(tgz)}`)
if (problems.length === 0) {
  console.log('✅ 存档包完好，可安全用于 dsh plugin add')
  process.exit(0)
}
console.log('❌ 存档包有问题：')
for (const problem of problems) console.log(`   - ${problem}`)
process.exit(1)
