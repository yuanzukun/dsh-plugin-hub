/**
 * 工作台全部样式（从 index.tsx 抽出，便于维护）。
 *
 * 颜色策略（v1.14.5 起）：**先映射到我们自己的 `--wb-*` 令牌层，再由它引用宿主
 * `--dsw-alias-*`**。原先直接写 `var(--dsw-alias-xxx, <深色回退>)`，令牌拿不到时
 * 会回退成深黑 —— 这是本插件最严重的一次视觉事故的成因，细节见
 * `entryContract.ts` 的 `tokenLayerCss()`。
 *
 * 令牌层函数放在 `entryContract.ts`：那边进构建产物、能被 `node --test` 直接断言；
 * 本文件只在打包进浏览器 bundle 时参与，测不到。
 *
 * 结构：令牌层 → 宿主注入钩子 → 布局 → 组件 → 弹窗/toast → 响应式。
 */
import { ACTIVE_ATTR, OFFICIAL_ATTR, PENDING_ATTR, VIEW_ATTR } from './constants.js'
import { panelContainerCss, toWorkbenchTokens, tokenLayerCss } from './entryContract.js'

const RAW_CSS = `[data-pane='conversation'], [class*='centerCol'] { position: relative; }
[${VIEW_ATTR}] {
  position: absolute; inset: 0; display: none; z-index: 60;
  background: var(--dsw-alias-bg-base, #111); color: var(--dsw-alias-label-primary, #eee);
  font-family: var(--dsw-font-family, system-ui); overflow: hidden;
}
/* ---------------------------------------------------------------------------
   面板容器的可见性（v1.14.0；2026-09-12「点工作台→整片空白」事故的直接修复）
   ---------------------------------------------------------------------------
   规则本体在 entryContract.ts 的 panelContainerCss()：那里可被单测锁住，
   而本文件的 CSS 只进浏览器 bundle、测不到。这里只负责拼接。
   v1.14.53：DOM 降级腿已删除，容器只剩官方 shell.overlay 一个 ——
   "两份容器二选一"那套门控（含 BLOCKED_ATTR）随之消失。
   --------------------------------------------------------------------------- */
${panelContainerCss({ view: VIEW_ATTR, official: OFFICIAL_ATTR, active: ACTIVE_ATTR }).join('\n')}
/* 面板容器（挂在**始终存在**的 shell.overlay 里）：由自己的 data-open 决定显隐。
   为什么不用宿主给的高度链：宿主 main 容器外面套了一层 display:contents 中转节点，
   它可能在组件挂载之后才定高，依赖 height 会偶发 0 高度（面板"挂上了却看不见"）。
   为什么是 fixed 而不是填满格子：需要一个不依赖宿主布局的稳定容器。

   ⚠️ 两条硬约束（2026-09-15 用户实测踩到）：
   1. **不能盖住左侧导航栏**。容器本身 pointer-events:none、只有面板本体 auto，
      点击直接穿透到 DSH 侧栏；同时从 --wb-sidebar-w（运行时量出的侧栏宽度）开始铺，
      视觉上也不压住侧栏。改造前的覆盖层贴在会话列里，左侧栏一直是可用的。
   2. **开合只切 display，不卸载组件** —— 草稿弹框要跨页面常驻，
      依赖 useEffect 拉数据的区块（今日容量）也不能被反复重建。 */
.wb-panel-host {
  /* 左边界 = 运行时量出的侧栏宽度（--wb-sidebar-w，见 index.tsx 的 syncSidebarWidth）。
     ⚠️ 兜底值**不能是 0**（v1.14.54 真实事故）：一旦量宽失败，left: 0 会让面板从视口
     最左边铺起、把整个 DSH（含侧栏）盖住 —— 用户"侧边栏都没有了"。
     用 DSH 侧栏的默认宽度 280px 兜底：最坏情况是边界偏一点，而不是遮住导航。
     v1.15.5：侧栏**收起**时这个变量会被明确写成 0px（判据见 panelGeometry.ts），
     于是面板跟着铺满 —— 收起后铺不满正是旧口径把 0 当成"量取失败"造成的。 */
  position: fixed; top: var(--wb-top-inset, 0px); right: 0; bottom: 0; left: var(--wb-sidebar-w, 280px);
  z-index: 55; overflow: hidden; display: none;
  background: var(--wb-bg-base);
  pointer-events: none;
}
.wb-panel-host[data-open='1'] { display: block; }
/* 面板本体恢复接收事件（容器保持穿透，保证左侧栏可点）。 */
.wb-panel-host > .wb-app-scope { pointer-events: auto; }
/* 样式作用域包装层：组件样式按 [data-...-view] 后代作用域书写，这里必须撑满并可见
   （它**不能**同时是 .wb-panel-host，否则会命中 [data-...-view] 的 display:none 基线规则）。 */
.wb-panel-host .wb-app-scope { height: 100%; min-height: 0; }
/* 兜底：**内容为空时绝不拦点击**（v1.14.28）。
   2026-09-13 真实事故：宿主面板状态读不到时容器被永久置为 data-open="1"，
   一张 2280×1377 的空层盖住会话区与 task-board，用户"除左栏外什么都点不了"。
   这条规则保证"空层"即使处于显示态也不会吃掉点击。 */
.wb-panel-host > .wb-app-scope:empty { pointer-events: none; }
.wb-panel-host > [${VIEW_ATTR}] { position: static; inset: auto; z-index: auto; height: 100%; }
.wb-panel-fill { height: 100%; min-height: 0; }
/* v1.14.53 删掉了「自建入口行上的红点」规则（html[pending] [entry]::after）：
   DOM 降级腿删除后没有自建入口行了，待确认计数改由工作台内的「待处理」胶囊显示
   （见 index.tsx 的 wb-pending-pill）。PENDING_ATTR 仍用于草稿浮卡的定位。 */
.wb-app { height:100%; display:flex; flex-direction:column; }
.wb-h { flex:none; display:flex; align-items:center; gap:12px; padding:14px 18px; border-bottom:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.22)); background:var(--dsw-alias-bg-layer-1, rgba(255,255,255,.02)); }
.wb-title { display:flex; align-items:center; gap:8px; font-size:16px; font-weight:700; letter-spacing:.02em; white-space:nowrap; }
.wb-title svg { width:19px; height:19px; color:var(--dsw-alias-state-business-primary, #8fa8c8); }
.wb-segmented { display:inline-flex; padding:3px; border-radius:10px; background:var(--dsw-alias-bg-base, #111); border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.20)); }
.wb-seg { display:inline-flex; align-items:center; gap:6px; border:none; background:transparent; color:var(--dsw-alias-label-secondary); padding:7px 16px; border-radius:8px; cursor:pointer; font:inherit; font-weight:600; font-size:13.5px; }
.wb-seg svg { width:15px; height:15px; }
.wb-seg.on { background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent); color:var(--dsw-alias-label-primary); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 32%, transparent); }
.wb-sub-segmented { padding:2px; }
.wb-sub-segmented .wb-seg { padding:6px 14px; font-size:12.5px; }
.wb-sub-segmented .count { min-width:17px; height:17px; padding:0 5px; border-radius:9px; background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent); color: var(--dsw-alias-label-primary); font-size:11px; display:inline-flex; align-items:center; justify-content:center; }
/* 日期面板的任务页签（计划/逾期/未排期 + 已完成/报告）与下方内容之间必须留呼吸。
   ⚠️ 2026-10-01 用户实测反馈：'计划/已完成/报告"这三个Tab切换控件和下面控件的间隔几乎没有，有点丑'。
   间距加在**页签的 margin-bottom**（而不是内容的 margin-top）：页签共用同一处间距 ——
   否则"计划"（下面先是一行排序按钮）与"已完成"（下面直接是列表）会走出两种间距。
   ⚠️ 2026-10-02 加到五个页签后必须允许换行：窄面板上挤出去的那一个会**整块消失**
   （用户看不到"报告"却不报错），换行只是变两行。 */
.wb-segmented[data-day-tabs] { margin-bottom: 10px; flex-wrap: wrap; }
.wb-btn { display:inline-flex; align-items:center; gap:6px; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.26)); background:var(--dsw-alias-bg-layer-1, transparent); color:var(--dsw-alias-label-secondary); border-radius:9px; padding:7px 11px; cursor:pointer; font:inherit; font-size:13px; }
.wb-btn svg { width:15px; height:15px; }
.wb-btn:hover { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 6%, transparent); color:var(--dsw-alias-label-primary); }
.wb-btn.primary { background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 16%, transparent); border:1px solid color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 38%, transparent); color:var(--dsw-alias-label-primary); }
.wb-body { flex:1; min-height:0; display:flex; }
.wb-nav { flex:0 0 min(56%, 880px); min-width:420px; overflow:auto; padding:0 18px 16px; box-sizing:border-box; border-right:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.14)); }
.wb-nav > :first-child:not(.wb-stats-sticky) { margin-top:16px; }
.wb-detail { flex:1; min-width:0; overflow:auto; padding:16px 18px; box-sizing:border-box; }
.wb-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin-bottom:12px; }
.wb-stat { border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.20)); background:var(--dsw-alias-bg-layer-1, rgba(255,255,255,.03)); border-radius:12px; padding:12px 14px; box-shadow:0 2px 8px rgba(0,0,0,.06); }
.wb-stat b { font-size:20px; }
.wb-stat span { display:block; color:var(--dsw-alias-label-secondary); font-size:12px; }
.wb-stats-sticky { position:sticky; top:0; z-index:12; margin:0 -18px 12px; padding:12px 18px 14px; background:var(--dsw-alias-bg-base,#111); box-shadow:none; border-bottom:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.24)); }
.wb-card { border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.26)); background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,.03)); border-radius:14px; padding:16px; margin-bottom:14px; box-shadow:0 6px 18px rgba(0,0,0,.08); }
.wb-card h4 { margin:0 0 10px; padding-bottom:10px; border-bottom:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.16)); display:flex; align-items:center; gap:8px; font-size:14px; font-weight:700; }
.wb-card h4 svg { width:16px; height:16px; color:var(--dsw-alias-state-business-primary, #8fa8c8); flex:none; }
.wb-plan { border-left:4px solid var(--dsw-alias-state-business-primary, #8fa8c8); background: linear-gradient(90deg, color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 9%, transparent), color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 3%, transparent) 45%, var(--dsw-alias-bg-layer-1, rgba(255,255,255,.03)) 100%); }
.wb-plan-item { display:flex; align-items:center; margin:7px 0; font-size:13.5px; }
.wb-plan-num { display:inline-flex; width:20px; height:20px; border-radius:50%; background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 16%, transparent); border:1px solid color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 40%, transparent); color:var(--dsw-alias-label-primary); font-size:11px; font-weight:700; align-items:center; justify-content:center; margin-right:8px; flex:none; }
.wb-plan-note { color:var(--dsw-alias-label-secondary); margin-left:8px; font-size:12.5px; }
.wb-plan-scroll { max-height:min(27vh,280px); overflow-y:auto; overscroll-behavior:contain; scrollbar-width:thin; scrollbar-color: color-mix(in srgb, var(--dsw-alias-label-primary, #888) 38%, transparent) transparent; padding-right:4px; }
.wb-plan-scroll::-webkit-scrollbar { width:8px; }
.wb-plan-scroll::-webkit-scrollbar-track { background:transparent; }
.wb-plan-scroll::-webkit-scrollbar-thumb { background: color-mix(in srgb, var(--dsw-alias-label-primary, #888) 38%, transparent); border-radius:4px; }
.wb-plan-expanded .wb-plan-scroll { max-height:min(70vh,720px); }
.wb-plan-footer { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-top:10px; padding-top:10px; border-top:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.14)); font-size:12px; color:var(--dsw-alias-label-secondary); }
.wb-plan-item { min-width:0; gap:6px; }
.wb-plan-item b, .wb-plan-item .wb-plan-note { min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-plan-item b { flex:0 1 auto; }
.wb-plan-item .wb-plan-note { flex:1 1 36%; }
.wb-plan-item-actions { display:inline-flex; gap:4px; flex:none; margin-left:auto; }
.wb-plan-act { display:inline-flex; align-items:center; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.22)); background:color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 3%, transparent); color:var(--dsw-alias-label-secondary); border-radius:6px; padding:2px 7px; font-size:11px; cursor:pointer; line-height:1.5; }
.wb-plan-act:hover { color:var(--dsw-alias-label-primary); border-color:color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 35%, transparent); }
.wb-plan-act:disabled { opacity:.45; cursor:default; }
.wb-plan-act.done { color:color-mix(in srgb, #2E9B7B 85%, #fff); border-color:color-mix(in srgb, #2E9B7B 45%, transparent); }
.wb-plan-act.defer { color:color-mix(in srgb, #d9a03f 85%, #fff); border-color:color-mix(in srgb, #d9a03f 45%, transparent); }
.wb-plan-item.closed { opacity:.55; }
.wb-plan-item.closed b { text-decoration:line-through; }
.wb-plan-edit-note { flex:1 1 36%; min-width:0; background:var(--dsw-alias-bg-base,#17171a); border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.18)); color:inherit; border-radius:6px; padding:3px 7px; font-size:12px; }
/* 计划投入（T2/D07）：显示态的按钮与编辑态的输入框都刻意窄，避免把标题挤没 */
.wb-plan-minutes { flex:none; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.22)); background:color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 4%, transparent); color:var(--dsw-alias-label-secondary); border-radius:999px; padding:1px 8px; font-size:11px; cursor:pointer; font-variant-numeric:tabular-nums; white-space:nowrap; }
.wb-plan-minutes:hover { color:var(--dsw-alias-label-primary); border-color:color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 35%, transparent); }
.wb-plan-minutes:disabled { opacity:.5; cursor:default; }
.wb-plan-minutes-static { flex:none; color:var(--dsw-alias-label-secondary); font-size:11px; font-variant-numeric:tabular-nums; white-space:nowrap; }
.wb-plan-minutes-input, .wb-plan-edit-minutes { flex:none; width:76px; background:var(--dsw-alias-bg-base,#17171a); border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.18)); color:inherit; border-radius:6px; padding:2px 6px; font-size:11.5px; font-variant-numeric:tabular-nums; }
.wb-plan-effort-done { flex:none; font-size:11px; border-radius:999px; padding:1px 8px; color:color-mix(in srgb, #2E9B7B 88%, #fff); border:1px solid color-mix(in srgb, #2E9B7B 42%, transparent); background:color-mix(in srgb, #2E9B7B 12%, transparent); white-space:nowrap; }
.wb-plan-act.effort { color:color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 88%, #fff); border-color:color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 45%, transparent); }
.wb-plan-act.effort.on { color:var(--dsw-alias-label-secondary); }
/* 结束投入后的进度建议：非自动、不默认勾选，所以视觉上刻意弱于主动作 */
.wb-plan-progress-hint { flex:1 1 100%; display:flex; align-items:center; gap:6px; margin-top:2px; font-size:11px; color:var(--dsw-alias-label-secondary); }
.wb-plan-progress-hint .wb-btn { padding:1px 8px; font-size:11px; }
.wb-plan-item.effort-done b { color:color-mix(in srgb, #2E9B7B 70%, var(--dsw-alias-label-primary, #eee)); }
.wb-plan-unreadable { border-color:color-mix(in srgb, #d9534f 42%, transparent); }
.wb-plan-edit-actions { display:inline-flex; gap:4px; flex:none; margin-left:auto; }
.wb-plan-edit-actions .wb-btn { padding:2px 7px; font-size:11px; }
.wb-row-title { display:flex; align-items:center; gap:6px; min-width:0; }
/* 标题文字自己的节点（徽标是它的兄弟节点）：截断在这一层做，否则会把徽标一起截掉。
   ⚠️ 别把徽标放回 .wb-row-title 的文字流里 —— 那会污染"标题"这个定位点（见 TaskList.tsx 的长注释）。 */
.wb-row-title-text { min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
/* 日期面板的行来源徽标（批次2 D15）：到期 / 计划 / 进行中，可多来源并列 */
.wb-src { flex:none; font-size:10px; font-weight:600; padding:1px 6px; border-radius:6px; letter-spacing:.2px;
  background:color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent);
  color:var(--dsw-alias-state-business-primary, #8fa8c8);
  border:1px solid color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 38%, transparent); }
/* 行内「排入今日」（2026-10-02）：只在日期面板的**逾期 / 未排期**页签、且**今天**这一实例上出现。
   它是行内动作，必须比整行小一号且不与右侧固定列抢宽度（flex:none + 小字号内边距）。
   ⚠️ 这段在 JS 模板串里，注释中**不能出现反引号**（会提前结束模板串 —— 本次已踩过一次）。 */
.wb-schedule { flex:none; padding:3px 9px; font-size:11.5px; border-radius:8px; white-space:nowrap; }
.wb-schedule:disabled { opacity:.5; cursor:default; }
.wb-plan-add { max-width:220px; background:var(--dsw-alias-bg-base,#17171a); border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.18)); color:inherit; border-radius:8px; padding:5px 8px; font-size:12px; }
/* 文档/目录弹窗（LocalDocModal）的遮罩。
   ⚠️ z-index 必须夹在 .wb-overlay(300) 与对话框内浮层（.wb-model-scrim 329 / .wb-model-menu 330）之间。
   原来是 200 —— 低于 .wb-overlay，于是当这个弹窗**从另一个弹窗里**打开时（批次2 #2：快速录入 /
   新建任务里的工作区「浏览…」），它整个被对话框盖住：真实鼠标点在「选择此文件夹」的坐标上，
   命中的是对话框里的元素，表现为"点了没反应、值也不落进去"。这个 bug 是
   scripts/verify/suites/workspace-picker.mjs 的 elementFromPoint 诊断抓出来的。
   ⚠️ 本段在模板字符串里，**不能出现反引号**。 */
.wb-modal-mask { position:fixed; inset:0; z-index:320; background:rgba(0,0,0,.55); display:flex; align-items:center; justify-content:center; }
.wb-modal { width:min(520px, 92vw); background:var(--dsw-alias-bg-layer-2, #1c1c1f); border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.25)); border-radius:14px; padding:18px; box-shadow:0 18px 50px rgba(0,0,0,.4); color:var(--dsw-alias-label-primary, #eee); font-family:var(--dsw-font-family, system-ui); }
.wb-modal h4 { margin:0 0 8px; }
.wb-modal p { margin:0 0 12px; font-size:12.5px; color:var(--dsw-alias-label-secondary); }
.wb-modal textarea { width:100%; min-height:110px; box-sizing:border-box; background:var(--dsw-alias-bg-base,#17171a); border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.2)); color:inherit; border-radius:10px; padding:10px; font:inherit; resize:vertical; }
.wb-modal-actions { display:flex; justify-content:flex-end; gap:8px; margin-top:12px; }
/* 技能选择器（AI 会话前的提示词弹窗内） */
.wb-skill-picker { margin-top:12px; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.22)); border-radius:10px; padding:10px; background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 3%, transparent); }
.wb-skill-picker-head { display:flex; align-items:center; justify-content:space-between; font-size:12.5px; color:var(--dsw-alias-label-primary); margin-bottom:8px; }
.wb-skill-picker-head svg { width:13px; height:13px; vertical-align:-2px; margin-right:4px; }
.wb-skill-count { font-size:11px; color:var(--dsw-alias-label-secondary); }
.wb-skill-search { width:100%; box-sizing:border-box; background:var(--dsw-alias-bg-base,#17171a); border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.18)); color:inherit; border-radius:8px; padding:6px 9px; font:inherit; font-size:12.5px; }
.wb-skill-selected { display:flex; flex-wrap:wrap; gap:5px; margin-top:7px; }
.wb-skill-tag { display:inline-flex; align-items:center; gap:4px; border:1px solid color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 42%, transparent); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent); color:var(--dsw-alias-label-primary); border-radius:999px; padding:2px 9px; font-size:11.5px; font:inherit; font-size:11.5px; cursor:pointer; }
.wb-skill-tag:hover { background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 22%, transparent); }
.wb-skill-list { margin-top:7px; max-height:190px; overflow:auto; display:flex; flex-direction:column; gap:3px; }
.wb-skill-item { display:flex; align-items:center; gap:8px; padding:6px 8px; border-radius:8px; cursor:pointer; border:1px solid transparent; }
.wb-skill-item:hover { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 5%, transparent); }
.wb-skill-item.on { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 40%, transparent); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 10%, transparent); }
.wb-skill-item input { flex:none; margin:0; }
.wb-skill-body { flex:1; min-width:0; display:flex; flex-direction:column; gap:1px; }
.wb-skill-name { font-size:12.5px; color:var(--dsw-alias-label-primary); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-skill-desc { font-size:11px; color:var(--dsw-alias-label-secondary); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-skill-provider { flex:none; font-size:10.5px; color:var(--dsw-alias-label-secondary); opacity:.75; }
.wb-skill-hint { padding:8px 4px; font-size:12px; color:var(--dsw-alias-label-secondary); }
/* 技能目录拿不到时的**可见故障态**（v1.15.6）：旧实现是整块隐藏，用户看到的是"功能没了"。 */
.wb-skill-problem { margin-top:12px; display:flex; align-items:center; gap:10px; justify-content:space-between; padding:8px 10px; border-radius:8px; font-size:12px; line-height:1.6; color:var(--dsw-alias-label-secondary); background: color-mix(in srgb, #f5b83d 12%, transparent); border-left:3px solid #f5b83d; }
.wb-skill-problem svg { width:13px; height:13px; vertical-align:-2px; margin-right:4px; }
.wb-skill-problem .wb-btn { flex:none; display:inline-flex; align-items:center; gap:4px; }
.wb-skill-foot { margin-top:7px; font-size:11px; color:var(--dsw-alias-label-secondary); opacity:.85; }
/* 角色选择器（D13-B）：与技能选择器并列的**普通文档流**区块 —— 不用绝对定位、不加遮罩，
   所以它下面的技能选择器照常展开，两者不遮挡（AX-R07）。 */
.wb-persona-picker { margin-top:12px; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.22)); border-radius:10px; padding:10px; background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 3%, transparent); }
.wb-persona-head { display:flex; align-items:center; justify-content:space-between; gap:8px; font-size:12.5px; color:var(--dsw-alias-label-primary); }
.wb-persona-head svg { width:13px; height:13px; vertical-align:-2px; margin-right:4px; }
.wb-persona-current { font-size:11.5px; color:var(--dsw-alias-label-secondary); max-width:62%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-persona-hint { margin-top:6px; font-size:11px; line-height:1.6; color:var(--dsw-alias-label-secondary); }
/* 搜索常驻（与「加载 Skill」同形）：一行放搜索框 + 「只看收藏」筛选 */
.wb-persona-toolbar { margin-top:8px; display:flex; align-items:center; gap:6px; }
.wb-persona-toolbar .wb-skill-search { flex:1; min-width:0; margin:0; }
.wb-persona-toolbar .wb-btn { flex:none; white-space:nowrap; }
.wb-persona-admin { margin-top:8px; }
/**
 * 管理列表**不再自带滚动区**（2026-10-01 实测截图暴露的缺陷）。
 *
 * 拆成独立页签后这一页有整幅高度，而原来那条 max-height:300px + overflow:auto 会在
 * 列表中间切一刀：截图里第 4 行从中间被截断、第 5 行完全看不见 ——
 * 用户要"少滚"，结果变成"弹窗里再滚一层"，比不滚更难用（还看不出下面还有内容）。
 *
 * 选择器（弹窗里那个窄条）**保留** max-height：那里确实需要一个上限。
 */
.wb-persona-admin-list { margin-top:8px; display:flex; flex-direction:column; gap:2px; }
.wb-persona-admin-list .wb-persona-name { max-width:26%; }
.wb-persona-foot { margin-top:8px; font-size:11px; line-height:1.6; color:var(--dsw-alias-label-secondary); }
.wb-persona-list { margin-top:8px; display:flex; flex-direction:column; gap:4px; max-height:320px; overflow:auto; }
.wb-persona-item { display:flex; align-items:center; gap:8px; text-align:left; width:100%; box-sizing:border-box; padding:6px 8px; border-radius:8px; cursor:pointer; border:1px solid transparent; background:transparent; color:inherit; font:inherit; }
.wb-persona-item:hover:not(:disabled) { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 5%, transparent); }
.wb-persona-item.on { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 40%, transparent); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 10%, transparent); }
.wb-persona-item:disabled { opacity:.55; cursor:not-allowed; }
.wb-persona-item.grow { flex:1; min-width:0; }
/* ---- 角色：名称 / 描述 / 来源 三层（2026-10-01 用户报"层级分布不明显、全挤在一起"）----
   改之前三类信息是**同一个灰、同一个字重**，只差 0.5px 字号（分组名 11、描述 11、来源 10.5），
   所以视觉上糊成一片。下面按"字号 + 字重 + 颜色深浅"拉开三层：
     ① 分组标题 14/600/主色 + 上分割线 + 计数
     ② 角色名 12.5/600/主色；描述 11.5/次色（管理页两行截断，选择器仍单行省略）
     ③ 来源｜分组 10.5/最淡色
*/
.wb-persona-name { flex:none; font-size:12.5px; font-weight:600; color:var(--dsw-alias-label-primary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:52%; }
.wb-persona-desc { flex:1; min-width:0; font-size:11px; color:var(--dsw-alias-label-secondary); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-persona-source { flex:none; font-size:10.5px; color:var(--dsw-alias-label-secondary); opacity:.7; }
.wb-persona-more-head { margin-top:8px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.wb-persona-more { margin-top:8px; border-top:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.16)); padding-top:8px; max-height:300px; overflow:auto; }
/**
 * 分组标题 = **章节级**（两处共用：设置页的角色库管理 + 弹窗里的角色选择器）。
 * 上分割线把它和上一组分开，计数让它自带规模信息 —— 这两样是"看得出分组"的关键，
 * 只靠字号（改前 11px vs 12.5px）区分不出来。
 */
.wb-persona-group { margin-top:12px; }
.wb-persona-group:first-child { margin-top:0; }
.wb-persona-group-name {
  display:flex; align-items:center; gap:8px;
  margin:0 0 6px; padding-top:8px;
  border-top:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.2));
  font-size:14px; font-weight:600; color:var(--dsw-alias-label-primary);
  letter-spacing:.2px;
}
.wb-persona-group-count { font-size:10.5px; font-weight:400; color:var(--dsw-alias-label-secondary); opacity:.8; }
.wb-persona-row { display:flex; align-items:flex-start; gap:10px; padding:6px 4px; border-radius:8px; }
.wb-persona-row:hover { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 4%, transparent); }
.wb-persona-row.off { opacity:.6; }
.wb-persona-info { flex:1; min-width:0; display:flex; flex-direction:column; gap:2px; }
/* 管理页的描述给两行（单行截断在宽栏里浪费空间）；选择器里仍是单行省略。
   为什么只给管理页：选择器每行只有 300px 上下，两行会让列表长一倍。 */
.wb-persona-admin .wb-persona-desc {
  display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; white-space:normal; line-height:1.45;
}
.wb-persona-admin .wb-persona-name { max-width:100%; }
.wb-persona-admin-list .wb-persona-name { max-width:100%; }
.wb-persona-actions { flex:none; display:flex; align-items:center; gap:6px; padding-top:2px; }
.wb-persona-star { margin-left:5px; font-size:11px; color:#e8b339; }
.wb-persona-off-tag {
  margin-left:6px; padding:0 5px; border-radius:4px; font-size:10px; font-weight:400;
  color:var(--dsw-alias-label-secondary); border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.3));
}
.wb-persona-flag { flex:none; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.28)); background:transparent; color:var(--dsw-alias-label-secondary); border-radius:7px; padding:3px 7px; font:inherit; font-size:10.5px; cursor:pointer; }
.wb-persona-flag.on { color:#e8b339; border-color: color-mix(in srgb, #e8b339 45%, transparent); background: color-mix(in srgb, #e8b339 12%, transparent); }
.wb-persona-flag:hover:not(:disabled) { color:var(--dsw-alias-label-primary); border-color: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 30%, transparent); }
.wb-persona-flag:disabled { opacity:.5; cursor:not-allowed; }
/* 列表里的"读取中 / 无匹配"提示：不参与行布局，也不是 .wb-hint（那带 margin）。 */
.wb-persona-note { padding:8px 4px; font-size:12px; color:var(--dsw-alias-label-secondary); }
/**
 * 默认折叠的「使用说明」块（2026-10-01 用户要求把"到处都有的解释性段落"收起来）。
 *
 * 口径：**页面默认只留可操作的控件**；要看"这个东西是什么/为什么这样"就点开。
 * 要点一条都不删（源文件里原文保留），只是不再各占一行把页面撑满。
 */
.wb-notes { margin:12px 0 0; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.22)); border-radius:10px; background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 3%, transparent); }
.wb-notes > summary {
  cursor:pointer; list-style:none; padding:8px 11px;
  font-size:12px; color:var(--dsw-alias-label-secondary);
  display:flex; align-items:center; gap:6px;
}
.wb-notes > summary::-webkit-details-marker { display:none; }
.wb-notes > summary::before { content:'▸'; font-size:10px; opacity:.8; }
.wb-notes[open] > summary::before { content:'▾'; }
.wb-notes > summary:hover { color:var(--dsw-alias-label-primary); }
.wb-notes-body { padding:0 12px 10px; font-size:11.5px; line-height:1.7; color:var(--dsw-alias-label-secondary); }
.wb-notes-body p { margin:0 0 6px; }
.wb-notes-body p:last-child { margin-bottom:0; }
.wb-notes-body b { color:var(--dsw-alias-label-primary); font-weight:650; }
.wb-notes-body code { font-size:11px; padding:1px 4px; border-radius:4px; background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 8%, transparent); }
.wb-notes-body .wb-notes-warn { color:#c8892f; }
.wb-list { border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.24)); border-radius:12px; overflow:hidden; background:var(--dsw-alias-bg-layer-1, rgba(255,255,255,.03)); }
.wb-row { display:flex; align-items:center; gap:8px; padding:11px 12px; border-bottom:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.12)); cursor:pointer; transition:background .12s ease; }
.wb-row:last-child { border-bottom:none; }
.wb-row:hover { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 5%, transparent); }
.wb-row.selected { background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 12%, transparent); box-shadow:inset 3px 0 0 var(--dsw-alias-state-business-primary, #8fa8c8); }
.wb-row-context { opacity:.55; }
.wb-row-context .wb-row-title { color: var(--dsw-alias-label-secondary); }
.wb-card { transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease; }
.wb-card.selected { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 65%, transparent) !important; box-shadow: 0 0 0 1px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 35%, transparent), 0 6px 18px rgba(0,0,0,.10); transform: translateY(-1px); }
.wb-row-title { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-row-meta { flex:none; display:grid; grid-template-columns:68px 46px 56px 88px; align-items:center; gap:6px; }
.wb-row-meta .wb-chip { display:inline-flex; align-items:center; justify-content:center; width:100%; padding-left:0; padding-right:0; text-align:center; }
.wb-due { text-align:right; color:var(--dsw-alias-label-secondary); font-size:12px; font-variant-numeric:tabular-nums; white-space:nowrap; }
.wb-chip { display:inline-flex; align-items:center; justify-content:center; border-radius:6px; padding:2px 7px; font-size:11px; white-space:nowrap; }

/* ---- 任务进度（S4）：列表行的紧凑条 + 详情页的完整卡片 ---- */
/* 行内形态：**在自己的网格格子里**伸缩（2026-10-01）。
   旧写法是网格外的 flex 兄弟 + max-width:46%，进度条一长就压窄左边的到期列，
   同一屏里几行对不齐（用户截图点名的就是它）。
   现在它占第 4 列固定 96px：0% 与 >10% 的行左右边界完全一致。 */
.wb-progress-compact { display:inline-flex; align-items:center; gap:5px; min-width:0; width:100%; justify-content:flex-end; }
.wb-progress { position:relative; height:6px; width:100%; min-width:38px; border-radius:999px; background:color-mix(in srgb, var(--dsw-alias-label-secondary, #8a9aa8) 22%, transparent); overflow:hidden; }
.wb-progress-fill { height:100%; border-radius:999px; background:var(--dsw-alias-state-business-primary, #4f8ef7); transition:width .18s ease; }
.wb-progress-num { font-size:11px; color:var(--dsw-alias-label-secondary); font-variant-numeric:tabular-nums; flex:none; }
.wb-progress-badge.pending { color:#f5b83d; border-color:color-mix(in srgb, #f5b83d 45%, transparent); background:color-mix(in srgb, #f5b83d 14%, transparent); }
.wb-progress-badge.deferred { color:#8b7be8; border-color:color-mix(in srgb, #8b7be8 45%, transparent); background:color-mix(in srgb, #8b7be8 14%, transparent); }
/* 详情卡：**一行**（2026-10-01 用户报"进度页面太高、把详情页撑丑了"）。
   旧的六块竖排（标题/条/旁证/提示/五档/输入框）已合并；旁证与黄色提示改用 title 悬停，
   用一个小图标表示"这里有话可说"。窄屏自动换行，不再有固定高度。 */
.wb-progress-card { padding:6px 10px; margin-bottom:10px; }
/* ⚠️ 进度卡里的 h4 只是"这一个控件叫什么"，不是卡片标题：
   .wb-card h4 自带 padding-bottom:10px + border-bottom，而用户截图里的
   "进度下面有个下划线、比其他元素高"正是它。这里清掉，让整条与徽标/状态行同高。 */
.wb-progress-card h4, .wb-card h4.wb-progress-title {
  margin:0; padding:0; border-bottom:none;
  font-size:12.5px; font-weight:600; color:var(--dsw-alias-label-secondary);
}
.wb-progress-row { display:flex; align-items:center; gap:8px; flex-wrap:wrap; min-height:24px; }
.wb-progress-title { margin:0; font-size:12.5px; font-weight:600; flex:none; }
/* 进度条槽位：**先收缩、不抢宽度**。
   ⚠️ 别写 flex:1 1 120px：那个 120px 的 flex-basis 在窄右栏里会让整条宽度超出容器，
   于是"0% 25% 50% 75% 完成任务"和输入框被换到**第二行**（2026-10-01 用户截图：
   进度卡分了两行，下面还多个下划线，比旁边元素高一截）。
   现在 basis=0：其余控件先占位，进度条吃剩下的；min-width 兜住"再挤也看得见"。 */
.wb-progress-bar-slot { flex:1 1 0; min-width:56px; display:flex; align-items:center; }
.wb-progress-card .wb-progress { height:6px; margin:0; }
.wb-progress-child, .wb-progress-hint { font-size:12px; color:var(--dsw-alias-label-secondary); margin:0; display:inline-flex; align-items:center; flex:none; }
.wb-progress-hint { color:#f5b83d; }
.wb-progress-note { font-size:12px; color:var(--dsw-alias-label-secondary); margin:0; }
.wb-progress-error { font-size:12px; color:#e7634c; margin-top:6px; }
.wb-progress-presets { display:inline-flex; align-items:center; gap:6px; flex:none; }
.wb-progress-input { display:inline-flex; align-items:center; gap:6px; flex:none; }
.wb-progress-input input { width:70px; }
.wb-cal-nav { display:flex; align-items:center; gap:8px; margin-bottom:10px; }
.wb-week { display:grid; grid-template-columns:repeat(7,1fr); gap:6px; margin-bottom:10px; }
.wb-day { border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.18)); background:var(--dsw-alias-bg-layer-1, rgba(255,255,255,.03)); border-radius:12px; min-height:92px; padding:8px; cursor:pointer; transition:border-color .12s ease, background .12s ease; }
.wb-day.today { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 50%, transparent); }
.wb-day.selected { border-color:var(--dsw-alias-state-business-primary, #8fa8c8); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 10%, transparent); }
.wb-month { display:grid; grid-template-columns:repeat(7,1fr); gap:6px; margin-bottom:10px; }
.wb-mday { min-height:52px; border:1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.16)); background:var(--dsw-alias-bg-layer-1, rgba(255,255,255,.03)); border-radius:10px; padding:5px; cursor:pointer; color:var(--dsw-alias-label-secondary); }
.wb-mday.other { opacity:.35; }
.wb-mday.today { border-color: var(--dsw-alias-state-business-primary, #4f8ef7); }
.wb-mday.selected { background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 12%, transparent); }
.wb-form { display:grid; grid-template-columns:1fr 1fr; gap:10px; border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.12)); border-radius:10px; padding:12px; }
.wb-form-panel { border:1px solid color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 45%, transparent) !important; border-left:4px solid var(--dsw-alias-state-business-primary, #8fa8c8) !important; border-radius:14px !important; padding:16px !important; background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #8fa8c8) 8%, var(--dsw-alias-bg-base, #111)) !important; box-shadow:0 10px 28px rgba(0,0,0,.15); margin-bottom:12px; }
.wb-form-panel h4 { margin:0 0 10px; font-size:15px; color:var(--dsw-alias-label-primary); display:flex; align-items:center; gap:8px; }
.wb-form-panel h4 svg { width:16px; height:16px; color:var(--dsw-alias-state-business-primary, #8fa8c8); }
.wb-btn.lg { padding:8px 16px; font-size:14px; font-weight:600; }
.wb-form label { display:flex; flex-direction:column; gap:4px; font-size:12px; color:var(--dsw-alias-label-secondary); }
.wb-form input, .wb-form select, .wb-form textarea { background: var(--dsw-alias-bg-base,#17171a); border:1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.15)); color:inherit; border-radius:8px; padding:7px 10px; font:inherit; }
.wb-form .full { grid-column:1 / -1; }
.wb-empty { padding:24px; text-align:center; color:var(--dsw-alias-label-secondary); }
.wb-banner { border:1px solid rgba(127,127,127,.35); border-left:6px solid #8fa8c8; border-radius:14px; padding:16px; margin:10px 14px 0; box-shadow:0 10px 28px rgba(0,0,0,.18); }
.wb-banner.draft { border-color:rgba(143,168,200,.45); border-left-color:#8fa8c8; background:color-mix(in srgb, #8fa8c8 10%, transparent); }
.wb-banner.review { border-color:rgba(143,168,200,.6); border-left-color:#8fa8c8; background:color-mix(in srgb, #8fa8c8 12%, transparent); }
.wb-banner.completion { border-color:rgba(245,184,61,.55); border-left-color:#f5b83d; background:color-mix(in srgb, #f5b83d 10%, transparent); }
.wb-banner.reminder { border-color:rgba(245,184,61,.5); border-left-color:#f5b83d; background:color-mix(in srgb, #f5b83d 9%, transparent); }
.wb-banner.error { border-color:rgba(231,76,60,.55); border-left-color:#e74c3c; background:color-mix(in srgb, #e74c3c 10%, transparent); }
.wb-banner.notice { border-color:rgba(143,168,200,.5); border-left-color:#8fa8c8; background:color-mix(in srgb, #8fa8c8 8%, transparent); }
.wb-banner h4 { margin:0 0 8px; font-size:15px; }

/* 边界增强：用主题文字色计算边框，亮/暗主题都保证对比；不改卡片底色 */
.wb-app { --wb-border: color-mix(in srgb, var(--dsw-alias-label-primary, #888) 26%, transparent); --wb-border-soft: color-mix(in srgb, var(--dsw-alias-label-primary, #888) 15%, transparent); }
.wb-card, .wb-list, .wb-stat { border-color: var(--wb-border) !important; }
.wb-card h4 { border-bottom-color: var(--wb-border-soft) !important; }
.wb-row { border-bottom-color: var(--wb-border-soft) !important; }
.wb-h { border-bottom-color: var(--wb-border) !important; }
.wb-nav { border-right-color: var(--wb-border-soft) !important; }
.wb-day, .wb-mday, .wb-form { border-color: var(--wb-border-soft) !important; }
/* 今日卡片高亮：周/月视图统一加亮边框 + 浅色背景 + 日期数字高亮 */
.wb-day.today { border-color: var(--dsw-alias-state-business-primary, #4f8ef7) !important; background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 12%, transparent) !important; }
.wb-day.today .wb-day-date { color: var(--dsw-alias-state-business-primary, #4f8ef7); font-weight: 700; }
.wb-day.today.selected { box-shadow: inset 0 0 0 2px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 70%, transparent); }
.wb-mday.today { border-color: var(--dsw-alias-state-business-primary, #4f8ef7) !important; background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent) !important; color: var(--dsw-alias-label-primary); }
.wb-mday.today .wb-mday-date { color: var(--dsw-alias-state-business-primary, #4f8ef7); font-weight: 700; }
.wb-mday.today.selected { box-shadow: inset 0 0 0 2px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 70%, transparent); }
.wb-mday.other.today { opacity: 1; }

/* ---- UI 美化：统一卡片/列表/表单视觉，强化 hover/selected/focus 态 ---- */
.wb-card { transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease; }
.wb-card:hover { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 42%, transparent); box-shadow: 0 10px 26px rgba(0,0,0,.12); }
.wb-card.selected { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 70%, transparent) !important; box-shadow: 0 0 0 1px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 35%, transparent), 0 10px 26px rgba(0,0,0,.14); transform: translateY(-1px); }
.wb-stat { transition: border-color .16s ease, box-shadow .16s ease; }
.wb-stat:hover { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 42%, transparent); box-shadow: 0 4px 14px rgba(0,0,0,.10); }
.wb-row { transition: background .14s ease, box-shadow .14s ease; }
.wb-row.done { opacity: .58; }
.wb-row.done .wb-row-title { text-decoration: line-through; }
.wb-row.selected { box-shadow: inset 3px 0 0 var(--dsw-alias-state-business-primary, #4f8ef7); }
.wb-form input:focus, .wb-form select:focus, .wb-form textarea:focus { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 65%, transparent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 16%, transparent); outline: none; }
.wb-idea-card { display: flex; flex-direction: column; margin-bottom: 0; padding: 12px; cursor: pointer; }
.wb-idea-card .wb-idea-summary { font-size: 12px; color: var(--dsw-alias-label-secondary); line-height: 1.5; min-height: 36px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.wb-idea-card .wb-idea-foot { display: flex; gap: 5px; flex-wrap: wrap; align-items: center; margin-top: 8px; }
.wb-file-chip { display: inline-flex; align-items: center; gap: 6px; border: 1px solid var(--wb-border, rgba(127,127,127,.22)); background: color-mix(in srgb, var(--dsw-alias-label-primary, #888) 5%, transparent); border-radius: 99px; padding: 3px 10px; font-size: 12px; color: var(--dsw-alias-label-secondary); }
.wb-file-chip code { background: transparent; border: none; padding: 0; }
.wb-cluster-meta { font-size: 12px; color: var(--dsw-alias-label-secondary); margin-top: 2px; }
.wb-empty { border: 1px dashed var(--wb-border-soft, rgba(127,127,127,.16)); border-radius: 12px; margin: 4px; }
/* ---- P0: 任务详情摘要 + Tabs + 吸顶操作条 ---- */
.wb-detail-actions { position: sticky; top: 0; z-index: 16; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; padding: 9px 12px; border: 1px solid var(--wb-border-soft, rgba(127,127,127,.18)); border-radius: 12px; background: color-mix(in srgb, var(--dsw-alias-bg-base, #111) 88%, transparent); backdrop-filter: blur(8px); box-shadow: 0 6px 18px rgba(0,0,0,.08); }
.wb-detail-tabs { display: flex; gap: 4px; margin: 4px 0 12px; border-bottom: 1px solid var(--wb-border-soft, rgba(127,127,127,.16)); }
.wb-detail-tab { border: none; background: transparent; color: var(--dsw-alias-label-secondary); font: inherit; font-size: 13px; font-weight: 600; padding: 7px 13px; border-radius: 8px 8px 0 0; cursor: pointer; white-space: nowrap; }
.wb-detail-tab:hover { color: var(--dsw-alias-label-primary); background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 6%, transparent); }
.wb-detail-tab.on { color: var(--dsw-alias-label-primary); box-shadow: inset 0 -2px 0 var(--dsw-alias-state-business-primary, #4f8ef7); }
.wb-detail-tab .count { margin-left: 4px; font-size: 11px; opacity: .8; }
/* ---- P1: 会话 Chip + 事件时间线 ---- */
.wb-session-chip { display: inline-flex; align-items: center; gap: 7px; border: 1px solid var(--wb-border-soft, rgba(127,127,127,.18)); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 6%, transparent); border-radius: 99px; padding: 5px 11px; font-size: 12px; color: var(--dsw-alias-label-secondary); cursor: pointer; margin: 0 6px 6px 0; transition: border-color .12s ease, background .12s ease; }
.wb-session-chip:hover { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 55%, transparent); color: var(--dsw-alias-label-primary); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 12%, transparent); }
.wb-session-role { font-weight: 600; color: var(--dsw-alias-state-business-primary, #4f8ef7); }
.wb-session-id { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; opacity: .75; }
.wb-session-open { opacity: .6; }
.wb-session-list { display: flex; flex-direction: column; gap: 6px; }
.wb-session-row { display: flex; align-items: center; gap: 10px; width: 100%; padding: 9px 12px; border: 1px solid var(--wb-border-soft, rgba(127,127,127,.16)); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 5%, transparent); border-radius: 10px; text-align: left; cursor: pointer; font: inherit; font-size: 13px; color: var(--dsw-alias-label-primary); transition: border-color .12s ease, background .12s ease; }
.wb-session-row:hover { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 55%, transparent); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 10%, transparent); }
.wb-session-role { flex: none; font-size: 12px; font-weight: 600; color: var(--dsw-alias-state-business-primary, #4f8ef7); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 10%, transparent); border: 1px solid color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 30%, transparent); border-radius: 6px; padding: 2px 7px; white-space: nowrap; }
.wb-session-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wb-session-open { flex: none; font-size: 12px; opacity: .65; }
.wb-session-picker { margin-top: 10px; border: 1px solid var(--wb-border, rgba(127,127,127,.18)); border-radius: 12px; padding: 10px; background: color-mix(in srgb, var(--dsw-alias-bg-base, #111) 90%, transparent); }
.wb-session-picker-bar { display: flex; gap: 8px; margin-bottom: 8px; }
.wb-session-search { flex: 1; min-width: 0; background: var(--dsw-alias-bg-base,#17171a); border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.16)); color: inherit; border-radius: 8px; padding: 7px 10px; font: inherit; font-size: 13px; }
.wb-session-search:focus { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 65%, transparent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent); outline: none; }
.wb-session-role-select { background: var(--dsw-alias-bg-base,#17171a); border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.16)); color: inherit; border-radius: 8px; padding: 7px 10px; font: inherit; font-size: 13px; }
.wb-session-picker-list { display: flex; flex-direction: column; gap: 4px; max-height: 260px; overflow: auto; overscroll-behavior: contain; scrollbar-width: thin; }
.wb-session-option { display: flex; align-items: center; gap: 8px; width: 100%; padding: 8px 10px; border: 1px solid transparent; background: color-mix(in srgb, var(--dsw-alias-label-primary, #888) 4%, transparent); border-radius: 8px; text-align: left; cursor: pointer; font: inherit; font-size: 13px; color: var(--dsw-alias-label-primary); transition: border-color .12s ease, background .12s ease; }
.wb-session-option:hover:not(:disabled) { border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 45%, transparent); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 9%, transparent); }
.wb-session-option:disabled { opacity: .5; cursor: default; }
.wb-session-cwd { flex: none; max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; color: var(--dsw-alias-label-secondary); opacity: .8; }
.wb-session-add { flex: none; font-size: 12px; font-weight: 600; color: var(--dsw-alias-state-business-primary, #4f8ef7); }
.wb-session-option:disabled .wb-session-add { color: var(--dsw-alias-label-secondary); }
/* ---- P3: 快速录入附件与模型选择器（v1.15.1） ---- */
.wb-quick-attach-rail { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px; }
.wb-quick-attach-item { position: relative; display: flex; align-items: center; gap: 6px; max-width: 240px; padding: 6px 26px 6px 8px; border: 1px solid var(--wb-border, rgba(127,127,127,.18)); border-radius: 8px; background: color-mix(in srgb, var(--dsw-alias-label-primary, #888) 5%, transparent); font-size: 12px; color: var(--dsw-alias-label-primary); }
.wb-quick-attach-item img { width: 36px; height: 36px; object-fit: cover; border-radius: 6px; flex: none; }
.wb-quick-attach-name { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wb-quick-attach-remove { position: absolute; top: 2px; right: 2px; width: 18px; height: 18px; line-height: 1; border: 0; border-radius: 50%; background: transparent; color: var(--dsw-alias-label-secondary); cursor: pointer; font-size: 14px; }
.wb-quick-attach-remove:hover { background: color-mix(in srgb, #e74c3c 22%, transparent); color: inherit; }
.wb-quick-attach-note { margin-top: 6px; font-size: 12px; color: #e0a030; }
.wb-quick-actions { display: flex; align-items: center; gap: 8px; margin-top: 10px; }
.wb-quick-actions .wb-spacer { flex: 1; }
/* ---------------------------------------------------------------------------
   模型选择浮层（v1.15.2 修「被遮挡」）
   ---------------------------------------------------------------------------
   ⚠️ 必须 position: fixed + **由 JS portal 到 document.body**：
   浮层原来用 position:absolute + bottom: calc(100% + 4px) 挂在触发按钮的
   position:relative 包装盒里，而那个盒子在 .wb-dialog-body（overflow: auto）
   **里面** —— 于是只会朝上开、不看可用空间，多出来的部分被滚动容器裁掉
   （实测常见窗口下只有 48% 可见，「跟随 DSH 默认模型」和前几个模型正好在被裁掉的那一段），
   窗口小一点时甚至画到视口外面。
   left/top/width/max-height 由 popoverPlacement.ts 的 placePopover() 算好写 inline style；
   这里的值是"拿不到量取结果"时的兜底（见该项目规范第 9 条：兜底值要选最坏情况可接受的）。
   ⚠️ box-sizing 必须是 border-box：placePopover() 把 max-height 当"整块菜单的高度"用，
   默认的 content-box 会让 border+padding（这里共 14px）额外顶出去 ——
   实测 1000x400 就因此有 3% 被挤出视口（这正是本次要修的"被裁"）。
   层叠：.wb-overlay 是 300，浮层要压住它；--wb-* 令牌由令牌层提供。
   ⚠️ 本段在模板字符串里，**不能出现反引号**。
   --------------------------------------------------------------------------- */
.wb-model-menu { position: fixed; z-index: 330; box-sizing: border-box; width: 320px; max-height: min(60vh, 360px); overflow-y: auto; padding: 6px; border: 1px solid var(--wb-border, rgba(127,127,127,.22)); border-radius: 10px; background: var(--dsw-alias-bg-layer-2, #1c1c1f); box-shadow: 0 12px 32px rgba(0,0,0,.45); overscroll-behavior: contain; scrollbar-width: thin; }
/* 浮层打开时的"点外面关掉"层：必须**在弹窗之上**（300）才能接住落在弹窗任意位置的第一次点击 */
.wb-model-scrim { position: fixed; inset: 0; z-index: 329; }
.wb-model-group-title { padding: 4px 8px; font-size: 11px; font-weight: 700; color: var(--dsw-alias-label-secondary); }
.wb-model-option { display: flex; align-items: center; gap: 8px; width: 100%; padding: 8px 9px; border: 1px solid transparent; border-radius: 8px; background: transparent; color: inherit; font: inherit; font-size: 13px; text-align: left; cursor: pointer; }
.wb-model-option:hover { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 7%, transparent); }
.wb-model-option.selected { background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent); border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 34%, transparent); }
.wb-model-option-main { min-width: 0; flex: 1; }
.wb-model-option-name { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wb-model-option-note { display: block; font-size: 11px; color: var(--dsw-alias-label-secondary); }
.wb-model-option-note.warn { color: #e0a030; }
.wb-model-menu-empty { padding: 8px 10px; font-size: 12px; color: var(--dsw-alias-label-secondary); }
.wb-model-menu-error { padding: 8px 10px; font-size: 12px; color: #e74c3c; }
.wb-event-group-date { display: flex; align-items: center; gap: 8px; margin: 10px 0 4px; font-size: 12px; font-weight: 700; color: var(--dsw-alias-label-secondary); }
.wb-event-group-date::after { content: ''; flex: 1; height: 1px; background: var(--wb-border-soft, rgba(127,127,127,.16)); }
.wb-event-row { display: flex; align-items: flex-start; gap: 8px; padding: 5px 0; font-size: 12px; color: var(--dsw-alias-label-secondary); }
.wb-event-icon { flex: none; width: 18px; text-align: center; line-height: 1.4; }
.wb-event-main { flex: 1; min-width: 0; }
.wb-event-title { color: var(--dsw-alias-label-primary); font-weight: 600; }
.wb-event-meta { opacity: .8; margin-top: 1px; word-break: break-all; }
/* ---- P2: 顶栏窄屏自适应 ---- */
@media (max-width: 1100px) {
  .wb-h { gap: 8px; padding: 10px 12px; }
  .wb-h .wb-label { display: none; }
  .wb-h > .wb-btn { width: 34px; height: 34px; padding: 0; justify-content: center; }
  .wb-h .wb-segmented { flex-wrap: wrap; }
  .wb-h .wb-seg { padding: 6px 9px; font-size: 12.5px; }
  .wb-h .wb-title { font-size: 14px; letter-spacing: 0; }
}
/* ---- P2: Markdown 代码块复制 ---- */
.wb-code-block { position: relative; margin: 8px 0; }
.wb-code-block pre { background: rgba(127,127,127,.10); padding: 10px 12px; border-radius: 8px; overflow: auto; font-size: 12px; margin: 0; }
.wb-code-copy { position: absolute; top: 6px; right: 6px; border-radius: 6px; padding: 2px 7px; font-size: 11px; opacity: .75; }
.wb-blockquote { border-left: 3px solid var(--dsw-alias-state-business-primary, #4f8ef7); background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 7%, transparent); border-radius: 0 8px 8px 0; padding: 6px 12px; margin: 8px 0; }

/* ==========================================================================
   弹窗（Modal）：替代"内联面板挤压任务列表"的旧形态。
   签名元素 = 两栏悬浮工作台面板：左分区导航 / 右独立滚动 / 粘性底栏。
   ========================================================================== */
/* 非模态浮卡：**不铺遮罩、不拦点击**（草稿弹框用它，避免"弹框一出什么都干不了"）。
   容器本身 pointer-events:none，只有卡片本体接收事件 —— 点卡片外面照样能操作 DSH。 */
.wb-dock {
  position: fixed; right: 18px; bottom: 18px; z-index: 300;
  pointer-events: none; display: flex; justify-content: flex-end;
}
.wb-dock > .wb-dialog {
  pointer-events: auto;
  max-height: min(70vh, 640px);
  width: min(560px, calc(100vw - 36px));
  box-shadow: 0 18px 48px rgba(0,0,0,.38);
  animation: wb-dialog-in .18s cubic-bezier(.2,.9,.3,1);
}
.wb-overlay {
  position: fixed; inset: 0; z-index: 300;
  display: flex; align-items: center; justify-content: center; padding: 24px;
  background: rgba(0,0,0,.52);
  backdrop-filter: blur(2px);
  animation: wb-overlay-in .16s ease-out;
}
@keyframes wb-overlay-in { from { opacity: 0 } to { opacity: 1 } }
@keyframes wb-dialog-in { from { opacity: 0; transform: translateY(6px) } to { opacity: 1; transform: none } }

.wb-dialog {
  display: flex; flex-direction: column;
  max-height: min(88vh, 900px); width: 100%;
  background: var(--dsw-alias-bg-layer-2, #1c1c1f);
  border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.22));
  border-radius: 16px;
  box-shadow: 0 24px 64px rgba(0,0,0,.45);
  color: var(--dsw-alias-label-primary, #eee);
  font-family: var(--dsw-font-family, system-ui);
  overflow: hidden;
  animation: wb-dialog-in .18s cubic-bezier(.2,.9,.3,1);
}
.wb-dialog:focus { outline: none; }
.wb-dialog-sm { max-width: 460px; }
.wb-dialog-md { max-width: 620px; }
.wb-dialog-lg { max-width: 860px; }
.wb-dialog-xl { max-width: min(1080px, 94vw); }

.wb-dialog-head {
  flex: none; display: flex; align-items: center; gap: 10px;
  padding: 14px 16px; border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.18));
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,.02));
}
.wb-dialog-head h3 { margin: 0; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
.wb-dialog-head h3 svg { width: 16px; height: 16px; color: var(--dsw-alias-state-business-primary, #8fa8c8); }
.wb-dialog-head-extra { flex: 1; display: flex; align-items: center; justify-content: flex-end; gap: 8px; font-size: 12px; color: var(--dsw-alias-label-secondary); }
.wb-dialog-close {
  flex: none; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;
  border: 1px solid transparent; border-radius: 8px; background: transparent;
  color: var(--dsw-alias-label-secondary); cursor: pointer;
}
.wb-dialog-close:hover { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 8%, transparent); color: var(--dsw-alias-label-primary); }
.wb-dialog-body { flex: 1; min-height: 0; overflow: auto; padding: 16px; }
.wb-dialog-foot {
  flex: none; display: flex; align-items: center; justify-content: flex-end; gap: 8px;
  padding: 12px 16px; border-top: 1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.18));
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,.02));
}
.wb-dialog-foot .wb-foot-note { margin-right: auto; font-size: 12px; color: var(--dsw-alias-label-secondary); }

/* 设置面板：左分区导航 + 右内容 */
.wb-settings { display: grid; grid-template-columns: 168px 1fr; gap: 16px; min-height: 340px; }
.wb-settings-nav { display: flex; flex-direction: column; gap: 2px; align-content: start; }
.wb-settings-nav button {
  display: flex; align-items: center; gap: 8px; width: 100%; text-align: left;
  border: none; background: transparent; color: var(--dsw-alias-label-secondary);
  padding: 8px 10px; border-radius: 8px; cursor: pointer; font: inherit; font-size: 13px;
}
.wb-settings-nav button:hover { background: color-mix(in srgb, var(--dsw-alias-label-primary, #fff) 6%, transparent); color: var(--dsw-alias-label-primary); }
.wb-settings-nav button.on {
  background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 14%, transparent);
  color: var(--dsw-alias-label-primary); font-weight: 600;
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 30%, transparent);
}
.wb-settings-nav button .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--dsw-alias-state-business-primary, #4f8ef7); margin-left: auto; flex: none; }
.wb-settings-pane { min-width: 0; }
.wb-settings-pane > section + section { margin-top: 18px; padding-top: 16px; border-top: 1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.14)); }
.wb-settings-pane h5 { margin: 0 0 10px; font-size: 13px; font-weight: 700; color: var(--dsw-alias-label-primary); }
.wb-settings-pane .wb-hint { font-size: 12px; color: var(--dsw-alias-label-secondary); margin: 6px 0 0; line-height: 1.6; }
/* ---------------------------------------------------------------------------
   弹框里的提示文字（v1.14.0 修复「提示被上方输入框遮挡」）
   ---------------------------------------------------------------------------
   原来只有 .wb-settings-pane .wb-hint 这一条，于是弹框里的 .wb-hint
   **完全没有样式**：字号继承、行高默认、上下无间距，紧贴着一个行内 input
   渲染，看起来就被输入框压住了。这里补一条全局基线。
   --------------------------------------------------------------------------- */
.wb-hint { font-size: 12px; color: var(--dsw-alias-label-secondary); margin: 6px 0 0; line-height: 1.6; }
/* 字段名右边的小字说明（例如「使用默认工作区」）。inline-flex + 基线对齐，避免与标题挤在一行时错位。 */
.wb-field-note { display: inline-flex; align-items: center; margin-left: 8px; font-size: 11.5px; color: var(--dsw-alias-label-secondary); opacity: .85; }
/* 弹框里的行内勾选项：图标与文字垂直居中，不参与 .wb-field 的列布局。 */
.wb-inline-check { display: flex; align-items: flex-start; gap: 6px; margin: 8px 0 0; font-size: 12.5px; line-height: 1.6; color: var(--dsw-alias-label-secondary); cursor: pointer; }
.wb-inline-check input { margin: 2px 0 0; flex: none; }
.wb-field-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; }
.wb-field { display: flex; flex-direction: column; gap: 5px; font-size: 12.5px; color: var(--dsw-alias-label-secondary); }
/**
 * 字段里"输入框 + 一个按钮"同排（2026-10-01 用户要求："不再记住"按钮与输入框放一行）。
 *
 * 为什么按钮要 flex:none：输入框自带 width:100%，若让它在 flex 里自由伸缩，
 * 长路径会把按钮挤出弹窗（或反过来把输入框压到看不清）。
 * 现在输入框吃剩余宽度（min-width:0 允许收缩）、按钮保持自身宽度不被压扁。
 */
.wb-field-row { display: flex; align-items: center; gap: 8px; }
.wb-field-row > input, .wb-field-row > select { flex: 1 1 auto; min-width: 0; }
.wb-field-row > .wb-btn { flex: none; white-space: nowrap; }
.wb-field > span { font-size: 12px; }
.wb-field input, .wb-field select, .wb-field textarea {
  background: var(--dsw-alias-bg-base, #17171a); color: inherit; font: inherit; font-size: 13px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.18)); border-radius: 9px; padding: 7px 10px; width: 100%; box-sizing: border-box;
}
.wb-field input:focus, .wb-field select:focus, .wb-field textarea:focus {
  outline: none; border-color: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 60%, transparent);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8ef7) 16%, transparent);
}
.wb-switch-row { display: flex; align-items: flex-start; gap: 9px; padding: 8px 0; font-size: 13px; }
.wb-switch-row input { margin-top: 2px; flex: none; }
.wb-switch-row .wb-switch-desc { display: block; font-size: 12px; color: var(--dsw-alias-label-secondary); margin-top: 2px; line-height: 1.5; }

/* --------------------------------------------------------------------------
   知识库召回：可观测回执（v1.15.3）
   日志行是等宽的数字+中文混排，必须允许换行（不换行会把设置弹窗撑出横向滚动）。
   -------------------------------------------------------------------------- */
.wb-recall-log { margin-top: 14px; border-top: 1px solid var(--dsw-alias-border-l2, rgba(255,255,255,.12)); padding-top: 10px; }
.wb-recall-log-head { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 6px; }
.wb-recall-log-head span { font-size: 12px; color: var(--dsw-alias-label-secondary); }
.wb-recall-log-head .wb-btn { margin-left: auto; }
.wb-recall-log-lines {
  list-style: none; margin: 0; padding: 10px 12px; max-height: 260px; overflow: auto;
  border-radius: 10px; background: var(--dsw-alias-bg-layer-3, rgba(255,255,255,.04));
  font-family: ui-monospace, SFMono-Regular, Consolas, monospace; font-size: 11.5px; line-height: 1.7;
}
.wb-recall-log-lines li { white-space: pre-wrap; overflow-wrap: anywhere; color: var(--dsw-alias-label-secondary); }
.wb-recall-sessions { margin-top: 12px; font-size: 12px; }
.wb-recall-sessions ul { list-style: none; margin: 6px 0 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
.wb-recall-sessions li { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.wb-recall-sessions code { font-size: 11.5px; opacity: .85; overflow-wrap: anywhere; }

/* ==========================================================================
   Toast：浮在右上角，不参与布局
   ========================================================================== */
.wb-toasts { position: fixed; top: 16px; right: 16px; z-index: 320; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
.wb-toast {
  pointer-events: auto; display: flex; align-items: flex-start; gap: 9px;
  min-width: 220px; max-width: min(380px, 82vw);
  padding: 10px 12px; border-radius: 12px;
  background: var(--dsw-alias-bg-layer-2, #1c1c1f);
  border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.2));
  box-shadow: 0 10px 30px rgba(0,0,0,.35);
  color: var(--dsw-alias-label-primary, #eee); font-size: 13px; line-height: 1.5;
  animation: wb-toast-in .18s cubic-bezier(.2,.9,.3,1);
}
.wb-toast.leaving { animation: wb-toast-out .18s ease-in forwards; }
@keyframes wb-toast-in { from { opacity: 0; transform: translateX(10px) } to { opacity: 1; transform: none } }
@keyframes wb-toast-out { to { opacity: 0; transform: translateX(10px) } }
.wb-toast-icon { flex: none; width: 18px; height: 18px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; }
.wb-toast-msg { flex: 1; min-width: 0; word-break: break-word; }
.wb-toast-close { flex: none; border: none; background: transparent; color: var(--dsw-alias-label-secondary); cursor: pointer; font-size: 11px; padding: 2px 4px; border-radius: 6px; }
.wb-toast-close:hover { color: var(--dsw-alias-label-primary); }
.wb-toast-info { border-left: 3px solid #8fa8c8; }
.wb-toast-info .wb-toast-icon { background: color-mix(in srgb, #8fa8c8 22%, transparent); color: #8fa8c8; }
.wb-toast-success { border-left: 3px solid #2E9B7B; }
.wb-toast-success .wb-toast-icon { background: color-mix(in srgb, #2E9B7B 22%, transparent); color: #2E9B7B; }
.wb-toast-warning { border-left: 3px solid #f5b83d; }
.wb-toast-warning .wb-toast-icon { background: color-mix(in srgb, #f5b83d 22%, transparent); color: #f5b83d; }
.wb-toast-error { border-left: 3px solid #e74c3c; }
.wb-toast-error .wb-toast-icon { background: color-mix(in srgb, #e74c3c 22%, transparent); color: #e74c3c; }

/* 待处理入口（替代常驻横幅）：标题栏右上角的小药丸 */
.wb-pending-pill {
  display: inline-flex; align-items: center; gap: 6px; border-radius: 999px; padding: 4px 10px;
  border: 1px solid color-mix(in srgb, #f5b83d 45%, transparent);
  background: color-mix(in srgb, #f5b83d 12%, transparent);
  color: var(--dsw-alias-label-primary); font-size: 12px; cursor: pointer;
}
.wb-pending-pill:hover { background: color-mix(in srgb, #f5b83d 20%, transparent); }
.wb-pending-pill .count { font-weight: 700; }

/* 弹窗内滚动区域（草稿确认等长内容） */
.wb-scroll-area { max-height: min(46vh, 420px); overflow: auto; padding-right: 4px; }
/* 草稿弹框的字段行（v1.14.0：补齐信息量，让用户能判断 AI 建得对不对） */
.wb-draft-field { display: flex; gap: 8px; font-size: 12px; line-height: 1.7; margin: 2px 0; }
.wb-draft-field-k { flex: none; min-width: 76px; color: var(--dsw-alias-label-secondary); }
.wb-draft-field-v { flex: 1; min-width: 0; word-break: break-all; }
/* 确认草稿时「本该创建但没创建」的告警条（绝不静默丢件的界面侧防线） */
.wb-draft-problems {
  margin-top: 10px; padding: 8px 10px; border-radius: 8px; font-size: 12px; line-height: 1.7;
  border-left: 3px solid #f5b83d; background: color-mix(in srgb, #f5b83d 12%, transparent);
}
.wb-draft-problems h5 { margin: 0 0 4px; font-size: 12px; font-weight: 700; }

/* ===========================================================================
   视觉层 v2（v1.13.0）
   ---------------------------------------------------------------------------
   目标：在**不改变信息架构**的前提下统一视觉语言。
   - 令牌一律映射回宿主 --dsw-alias-*，浅色/深色跟随外壳，不引入自有配色；
   - 边框保持"中档"强度（≈宿主 --dsw-alias-border-l1 的中灰口径）：这是用户
     明确要求的可读性底线，白卡叠白底必须能看出模块边界，不允许再调淡；
   - 唯一强调色用深墨绿（--wb-accent），取代原先到处混用的蓝色；
   - 字号收敛为三档，分割线统一 1px 发丝，卡片圆角 12px + 轻阴影。
   =========================================================================== */
[data-dsh-personal-workbench-view] {
  --wb-accent: color-mix(in srgb, #2E9B7B 62%, #14493A);
  --wb-accent-soft: color-mix(in srgb, var(--wb-accent) 12%, transparent);
  --wb-accent-line: color-mix(in srgb, var(--wb-accent) 38%, transparent);
  --wb-ink-1: var(--dsw-alias-label-primary, #eee);
  --wb-ink-2: var(--dsw-alias-label-secondary, #a9a9ad);
  --wb-ink-3: color-mix(in srgb, var(--dsw-alias-label-secondary, #a9a9ad) 68%, transparent);
  --wb-line: var(--dsw-alias-border-l1, rgba(127,127,127,.26));
  --wb-line-soft: color-mix(in srgb, var(--dsw-alias-border-l1, rgba(127,127,127,.26)) 62%, transparent);
  --wb-surface: var(--dsw-alias-bg-layer-1, rgba(255,255,255,.03));
  --wb-sunk: var(--dsw-alias-bg-base, rgba(127,127,127,.08));
  --wb-sh-1: 0 1px 2px rgba(0,0,0,.05);
  --wb-sh-2: 0 2px 8px rgba(0,0,0,.06);
  --wb-r-1: 8px; --wb-r-2: 12px;
  --wb-p0: #E74C3C; --wb-p1: #F39C12; --wb-p2: #3498DB; --wb-p3: #95A5A6; --wb-ok: #2E9B7B;
}

/* 顶栏：低频操作图标化后不再抢注意力，标题与分段导航是唯一入口 */
[data-dsh-personal-workbench-view] .wb-h {
  padding: 10px 14px; gap: 9px;
  border-bottom: 1px solid var(--wb-line);
  background: var(--dsw-alias-bg-layer-2, var(--wb-surface));
}
[data-dsh-personal-workbench-view] .wb-title { font-size: 14px; font-weight: 650; }
[data-dsh-personal-workbench-view] .wb-title svg { color: var(--wb-accent); }
[data-dsh-personal-workbench-view] .wb-segmented {
  padding: 2px; border-radius: 999px;
  background: var(--wb-sunk); border: 1px solid var(--wb-line-soft);
}
[data-dsh-personal-workbench-view] .wb-seg { padding: 5px 12px; border-radius: 999px; font-size: 12.5px; font-weight: 500; gap: 5px; }
[data-dsh-personal-workbench-view] .wb-seg.on {
  background: var(--wb-surface); color: var(--wb-ink-1); font-weight: 600;
  box-shadow: var(--wb-sh-1);
}
[data-dsh-personal-workbench-view] .wb-seg.on svg { color: var(--wb-accent); }
[data-dsh-personal-workbench-view] .wb-sub-segmented .wb-seg { padding: 4px 11px; font-size: 12px; }

/* 按钮：统一 8px 圆角；主操作走强调色 */
[data-dsh-personal-workbench-view] .wb-btn {
  border-radius: var(--wb-r-1); padding: 6px 11px; font-size: 12.5px;
  border: 1px solid var(--wb-line); background: var(--wb-surface);
}
[data-dsh-personal-workbench-view] .wb-btn:hover { background: color-mix(in srgb, var(--wb-ink-1) 6%, transparent); }
[data-dsh-personal-workbench-view] .wb-btn.primary {
  background: var(--wb-accent); border-color: transparent; color: #fff;
}
[data-dsh-personal-workbench-view] .wb-btn.primary:hover { background: color-mix(in srgb, var(--wb-accent) 88%, #000); }
[data-dsh-personal-workbench-view] .wb-h > .wb-btn:not(.primary) { border-color: transparent; background: transparent; }
[data-dsh-personal-workbench-view] .wb-h > .wb-btn:not(.primary):hover { background: color-mix(in srgb, var(--wb-ink-1) 7%, transparent); }
[data-dsh-personal-workbench-view] .wb-h > .wb-btn:not(.primary) .wb-label { display: none; }
[data-dsh-personal-workbench-view] .wb-h > .wb-btn:not(.primary) { padding: 6px 8px; }
@media (min-width: 1200px) {
  [data-dsh-personal-workbench-view] .wb-h > .wb-btn:not(.primary) .wb-label { display: inline; }
}

/* 统计卡：保持卡片与边框（可读性底线），只收敛字号与留白 */
[data-dsh-personal-workbench-view] .wb-stats { gap: 10px; margin-bottom: 12px; }
[data-dsh-personal-workbench-view] .wb-stats-sticky {
  background: var(--dsw-alias-bg-base, var(--wb-sunk));
  border-bottom: 1px solid var(--wb-line); padding: 12px 18px 13px; margin: 0 -18px 12px;
}
[data-dsh-personal-workbench-view] .wb-stat {
  border: 1px solid var(--wb-line); border-radius: var(--wb-r-2); background: var(--wb-surface);
  box-shadow: var(--wb-sh-1); padding: 12px 14px;
}
[data-dsh-personal-workbench-view] .wb-stat b { font-size: 24px; font-variant-numeric: tabular-nums; letter-spacing: -.01em; }
[data-dsh-personal-workbench-view] .wb-stat span { font-size: 11.5px; }

/* 今日容量条（新增元素：把"今天投得进多少时间"显式化） */
[data-dsh-personal-workbench-view] .wb-cap {
  border: 1px solid var(--wb-line); border-radius: var(--wb-r-2); background: var(--wb-surface);
  box-shadow: var(--wb-sh-1); padding: 13px 14px; margin-bottom: 12px;
}
[data-dsh-personal-workbench-view] .wb-cap-head { display: flex; align-items: baseline; gap: 10px; margin-bottom: 9px; }
[data-dsh-personal-workbench-view] .wb-cap-head h3 { margin: 0; font-size: 12.5px; font-weight: 650; }
[data-dsh-personal-workbench-view] .wb-cap-meta {
  margin-left: auto; display: flex; gap: 12px; font-size: 11.5px; color: var(--wb-ink-3);
  font-variant-numeric: tabular-nums;
}
[data-dsh-personal-workbench-view] .wb-cap-meta b { color: var(--wb-ink-1); font-weight: 650; }
[data-dsh-personal-workbench-view] .wb-cap-edit { border-bottom: 1px dashed var(--wb-line); cursor: pointer; }
[data-dsh-personal-workbench-view] .wb-cap-bar {
  display: flex; gap: 2px; height: 9px; border-radius: 999px; overflow: hidden;
  background: color-mix(in srgb, var(--wb-ink-1) 9%, transparent);
}
[data-dsh-personal-workbench-view] .wb-cap-bar i { display: block; height: 100%; border-radius: 2px; }
[data-dsh-personal-workbench-view] .wb-cap-bar i.p0 { background: var(--wb-p0); }
[data-dsh-personal-workbench-view] .wb-cap-bar i.p1 { background: var(--wb-p1); }
[data-dsh-personal-workbench-view] .wb-cap-bar i.p2 { background: var(--wb-p2); }
[data-dsh-personal-workbench-view] .wb-cap-bar i.p3 { background: var(--wb-p3); }
[data-dsh-personal-workbench-view] .wb-cap-bar i.free { background: color-mix(in srgb, var(--wb-ok) 36%, transparent); }
[data-dsh-personal-workbench-view] .wb-cap-legend { display: flex; align-items: center; gap: 12px; margin-top: 8px; font-size: 11.5px; color: var(--wb-ink-2); flex-wrap: wrap; }
[data-dsh-personal-workbench-view] .wb-cap-legend span { display: inline-flex; align-items: center; gap: 5px; }
[data-dsh-personal-workbench-view] .wb-cap-legend i { width: 7px; height: 7px; border-radius: 2px; flex: none; }
[data-dsh-personal-workbench-view] .wb-cap-legend b { color: var(--wb-ink-1); font-weight: 650; font-variant-numeric: tabular-nums; }

/* ── 今日容量：规则与账本（v1.15.1）──────────────────────────────────────────
   目标：用户看到的每个数字都能在账本里找到出处，且规则写在界面上而不是只写在代码里。
   小屏可滚动（不挤坏上面的容量条 —— 布局类缺陷由 harness 的像素断言守）。 */
[data-dsh-personal-workbench-view] .wb-cap-rule { margin-top: 10px; border-top: 1px dashed var(--wb-line); padding-top: 8px; }
[data-dsh-personal-workbench-view] .wb-cap-rule-head { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
[data-dsh-personal-workbench-view] .wb-cap-rule-toggle {
  background: none; border: 1px solid var(--wb-line); border-radius: var(--wb-r-1, 6px);
  color: var(--wb-ink-2); font: inherit; font-size: 11.5px; padding: 2px 8px; cursor: pointer; flex: none;
  /* 两态等宽：内容是固定的「箭头 + 规则」，宽度不随开合变化 */
  display: inline-flex; align-items: center; gap: 3px;
}
[data-dsh-personal-workbench-view] .wb-cap-rule-toggle:hover { color: var(--wb-ink-1); border-color: var(--wb-ink-3); }
/* 箭头按展开态旋转：
   Icon name="chevron" 的字形是**左向**（‹），所以折叠态先转 -90° 变成"下"（⌄），
   展开态再转 +90° 变成"上"（⌃）。两态之间正好差 180°，且**字形与占位都不变**，
   按钮盒子尺寸因此逐像素一致。 */
[data-dsh-personal-workbench-view] .wb-cap-rule-arrow { display: inline-flex; transform: rotate(-90deg); transition: transform .15s ease; }
[data-dsh-personal-workbench-view] .wb-cap-rule[data-cap-expanded='1'] .wb-cap-rule-arrow { transform: rotate(90deg); }

/**
 * 内联模式：把「规则」块**拆开**——头部那个开关留在容量图例那一行，展开体拿到全宽下方。
 *
 * 'display: contents' 让 '.wb-cap-rule' 这个壳不生成盒子，它的两个孩子直接成为图例 flex 行的成员：
 * 头部（含开关）就落在图例行里，展开体（'flex-basis:100%'）被挤到下一行、横跨整幅宽度。
 * 这比"把整块塞进图例行"正确得多：早期版本一展开，长内容全挤在那条窄行里，
 * 连带把开关推来推去（用户原话："打开、收起规则的按钮还不在同一个位置"）。
 */
[data-dsh-personal-workbench-view] .wb-cap-legend {
  display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
  font-size: 11.5px; color: var(--wb-ink-2); font-variant-numeric: tabular-nums;
}
[data-dsh-personal-workbench-view] .wb-cap-legend .wb-cap-legend-item { display: inline-flex; align-items: center; gap: 4px; }
/**
 * 展开时图例项**保留占位、只是看不见**（visibility:hidden，不是 display:none）。
 *
 * 为什么不能用 display:none：那样整行会变窄，右推的按钮就**从右端滑到左端**
 * （2026-10-01 实测：折叠态按钮 x=593，展开态变成 x=313 —— 正是用户说的
 * "打开、收起规则的按钮不在同一个位置"）。保留占位后按钮横向位置一个像素都不动。
 * 语义上也没问题：图例是"容量条的分段说明"，展开规则时把它视觉上让位即可。
 */
[data-dsh-personal-workbench-view] .wb-cap-legend[data-cap-expanded='1'] .wb-cap-legend-item { visibility: hidden; }
[data-dsh-personal-workbench-view] .wb-cap-legend .wb-cap-rule { display: contents; margin: 0; border: 0; padding: 0; }
[data-dsh-personal-workbench-view] .wb-cap-legend .wb-cap-rule-sum { display: none; }
/* 按钮永远贴在**右端**：两态（含展开态图例项被让位）位置都一致 */
[data-dsh-personal-workbench-view] .wb-cap-legend .wb-cap-rule-head { display: inline-flex; align-items: center; gap: 0; flex: none; margin-left: auto; }
[data-dsh-personal-workbench-view] .wb-cap-legend .wb-cap-rule-body { flex-basis: 100%; margin-top: 6px; }
[data-dsh-personal-workbench-view] .wb-cap-rule-sum { font-size: 11.5px; color: var(--wb-ink-3); font-variant-numeric: tabular-nums; }
[data-dsh-personal-workbench-view] .wb-cap-rule-sum b { color: var(--wb-ink-1); font-weight: 650; }
[data-dsh-personal-workbench-view] .wb-cap-rule-body { margin-top: 9px; display: flex; flex-direction: column; gap: 10px; }
[data-dsh-personal-workbench-view] .wb-cap-rules {
  margin: 0; padding-left: 20px; font-size: 12px; line-height: 1.75; color: var(--wb-ink-2);
}
[data-dsh-personal-workbench-view] .wb-cap-rules b { color: var(--wb-ink-1); font-weight: 650; }
[data-dsh-personal-workbench-view] .wb-cap-audit-wrap, [data-dsh-personal-workbench-view] .wb-cap-overdue, [data-dsh-personal-workbench-view] .wb-cap-unscheduled {
  border: 1px solid var(--wb-line); border-radius: var(--wb-r-2); overflow: hidden;
}
[data-dsh-personal-workbench-view] .wb-cap-audit-title, [data-dsh-personal-workbench-view] .wb-cap-overdue-head {
  font-size: 11.5px; font-weight: 650; color: var(--wb-ink-2);
  padding: 7px 10px; background: color-mix(in srgb, var(--wb-ink-1) 4%, transparent);
}
[data-dsh-personal-workbench-view] .wb-cap-overdue-head b { color: var(--wb-warn, #d9a03f); font-weight: 650; }
[data-dsh-personal-workbench-view] .wb-cap-audit-empty { font-size: 11.5px; color: var(--wb-ink-3); padding: 9px 10px; }
[data-dsh-personal-workbench-view] .wb-cap-audit { width: 100%; border-collapse: collapse; font-size: 11.5px; }
[data-dsh-personal-workbench-view] .wb-cap-audit th {
  text-align: left; font-weight: 600; color: var(--wb-ink-3); padding: 5px 10px;
  border-bottom: 1px solid var(--wb-line);
}
[data-dsh-personal-workbench-view] .wb-cap-audit td { padding: 5px 10px; border-bottom: 1px solid color-mix(in srgb, var(--wb-line) 60%, transparent); vertical-align: top; }
[data-dsh-personal-workbench-view] .wb-cap-audit tr:last-child td { border-bottom: none; }
[data-dsh-personal-workbench-view] .wb-cap-audit td.t { max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
[data-dsh-personal-workbench-view] .wb-cap-audit td.p, [data-dsh-personal-workbench-view] .wb-cap-audit td.m { font-variant-numeric: tabular-nums; white-space: nowrap; }
[data-dsh-personal-workbench-view] .wb-cap-audit td.s { display: flex; flex-wrap: wrap; gap: 4px; }
[data-dsh-personal-workbench-view] .wb-cap-audit .tag {
  font-size: 10.5px; padding: 1px 6px; border-radius: 999px; white-space: nowrap;
  border: 1px solid var(--wb-line); color: var(--wb-ink-3);
}
[data-dsh-personal-workbench-view] .wb-cap-audit-total {
  font-size: 11.5px; font-weight: 650; color: var(--wb-ink-1);
  padding: 7px 10px; border-top: 1px solid var(--wb-line);
  background: color-mix(in srgb, var(--wb-ink-1) 4%, transparent);
}
[data-dsh-personal-workbench-view] .wb-cap-switch {
  display: flex; align-items: center; gap: 7px; font-size: 12px; color: var(--wb-ink-2); cursor: pointer;
}
[data-dsh-personal-workbench-view] .wb-cap-switch input { flex: none; }
[data-dsh-personal-workbench-view] .wb-cap-switch .hint {
  width: 15px; height: 15px; border-radius: 999px; border: 1px solid var(--wb-line);
  display: inline-flex; align-items: center; justify-content: center; font-size: 10px; color: var(--wb-ink-3); cursor: help;
}
[data-dsh-personal-workbench-view] .wb-cap-foot { font-size: 11px; color: var(--wb-ink-3); }

/* 卡片 / 列表 / 计划：统一边框强度与阴影，行分割线改发丝 */
[data-dsh-personal-workbench-view] .wb-card {
  border: 1px solid var(--wb-line); border-radius: var(--wb-r-2); background: var(--wb-surface);
  box-shadow: var(--wb-sh-1); padding: 13px 14px; margin-bottom: 12px;
}
[data-dsh-personal-workbench-view] .wb-card h4 { font-size: 13px; padding-bottom: 9px; border-bottom: 1px solid var(--wb-line-soft); }
/**
 * ⚠️ 进度卡里的 h4 **不是卡片标题**，不该继承上面那条"标题下划线"。
 *
 * 为什么必须写在**这里**而不是上面那条 .wb-progress-card h4 里：
 * 上面那条选择器带 [data-dsh-personal-workbench-view]，**特异性更高**，
 * 后来者再写 .wb-progress-card h4 也压不过它 —— 2026-10-01 实测踩到：
 * 我先把覆盖规则写在 233 行，跑真机一看下划线还在、padding-bottom 仍是 9px。
 * 规矩：皮肤层的覆盖要写在**同层且更靠后**（或用等特异性 + 更靠后）。
 */
[data-dsh-personal-workbench-view] .wb-progress-card { padding: 6px 10px; }
[data-dsh-personal-workbench-view] .wb-progress-card h4 {
  margin: 0; padding-bottom: 0; border-bottom: none;
  font-size: 12.5px; font-weight: 600; color: var(--wb-ink-3);
}
[data-dsh-personal-workbench-view] .wb-list {
  border: 1px solid var(--wb-line); border-radius: var(--wb-r-2); background: var(--wb-surface);
  box-shadow: var(--wb-sh-1); overflow: hidden;
}
[data-dsh-personal-workbench-view] .wb-row { padding: 10px 12px; border-bottom: 1px solid var(--wb-line-soft); }
[data-dsh-personal-workbench-view] .wb-row.selected {
  background: var(--wb-accent-soft); box-shadow: inset 2px 0 0 var(--wb-accent);
}
[data-dsh-personal-workbench-view] .wb-plan {
  border: 1px solid var(--wb-line); border-left: 1px solid var(--wb-line);
  border-radius: var(--wb-r-2); background: var(--wb-surface); box-shadow: var(--wb-sh-1); overflow: hidden;
}
[data-dsh-personal-workbench-view] .wb-plan-item { font-size: 13px; }

/* 日历：日期卡保留边框，选中/今天用强调色描边而非整块填色 */
[data-dsh-personal-workbench-view] .wb-day {
  border: 1px solid var(--wb-line); border-radius: var(--wb-r-2); background: var(--wb-surface);
  box-shadow: var(--wb-sh-1); min-height: 82px;
}
[data-dsh-personal-workbench-view] .wb-day.today { border-color: var(--wb-accent-line); background: var(--wb-accent-soft); }
[data-dsh-personal-workbench-view] .wb-day.selected { border-color: var(--wb-accent); box-shadow: 0 0 0 1px var(--wb-accent-line), var(--wb-sh-1); }
[data-dsh-personal-workbench-view] .wb-mday {
  border: 1px solid var(--wb-line); border-radius: 10px; background: var(--wb-surface); box-shadow: var(--wb-sh-1);
}
[data-dsh-personal-workbench-view] .wb-mday.today { border-color: var(--wb-accent-line); background: var(--wb-accent-soft); }
[data-dsh-personal-workbench-view] .wb-mday.selected { background: var(--wb-accent-soft); border-color: var(--wb-accent); }

/* 待处理入口：与整体强调色一致，不再单独用黄色 */
[data-dsh-personal-workbench-view] .wb-pending-pill {
  border-color: var(--wb-accent-line); background: var(--wb-accent-soft); color: var(--wb-ink-1);
}
[data-dsh-personal-workbench-view] .wb-pending-pill:hover { background: color-mix(in srgb, var(--wb-accent) 20%, transparent); }

/* 表单控件：统一边框强度，避免"浅色下看不见输入框" */
[data-dsh-personal-workbench-view] .wb-form label { font-size: 12px; }
[data-dsh-personal-workbench-view] .wb-form input,
[data-dsh-personal-workbench-view] .wb-form select,
[data-dsh-personal-workbench-view] .wb-form textarea,
[data-dsh-personal-workbench-view] .wb-skill-search,
[data-dsh-personal-workbench-view] .wb-plan-edit-note,
[data-dsh-personal-workbench-view] .wb-plan-add {
  border: 1px solid var(--wb-line); border-radius: var(--wb-r-1);
}
[data-dsh-personal-workbench-view] .wb-form input:focus,
[data-dsh-personal-workbench-view] .wb-form select:focus,
[data-dsh-personal-workbench-view] .wb-form textarea:focus,
[data-dsh-personal-workbench-view] .wb-skill-search:focus {
  outline: none; border-color: var(--wb-accent-line); box-shadow: 0 0 0 2px var(--wb-accent-soft);
}

/* 行内操作：静息态保持干净，hover / 选中才出现 */
[data-dsh-personal-workbench-view] .wb-row-acts { display: flex; gap: 5px; opacity: 0; transition: opacity .12s ease; flex: none; }
[data-dsh-personal-workbench-view] .wb-row:hover .wb-row-acts,
[data-dsh-personal-workbench-view] .wb-row.selected .wb-row-acts,
[data-dsh-personal-workbench-view] .wb-row:focus-within .wb-row-acts { opacity: 1; }

/* 空态：从灰底占位改为邀请式文案 */
[data-dsh-personal-workbench-view] .wb-empty { padding: 26px 18px; }
[data-dsh-personal-workbench-view] .wb-empty-ic {
  width: 34px; height: 34px; margin: 0 auto 9px; border-radius: 10px;
  display: grid; place-items: center; background: var(--wb-accent-soft); color: var(--wb-accent);
}

/* 点子文件夹（v1.13.0 新增：文件夹优先） */
[data-dsh-personal-workbench-view] .wb-idea-crumb {
  display: flex; align-items: center; gap: 7px; font-size: 12.5px; color: var(--wb-ink-3); margin-bottom: 11px;
}
[data-dsh-personal-workbench-view] .wb-idea-crumb b { color: var(--wb-ink-1); font-weight: 650; }
[data-dsh-personal-workbench-view] .wb-folder-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(238px, 1fr)); gap: 11px; margin-bottom: 18px;
}
[data-dsh-personal-workbench-view] .wb-folder {
  position: relative; border: 1px solid var(--wb-line); border-radius: var(--wb-r-2);
  background: var(--wb-surface); box-shadow: var(--wb-sh-1); padding: 12px 13px; cursor: pointer;
  transition: border-color .12s ease, background .12s ease;
}
[data-dsh-personal-workbench-view] .wb-folder:hover { border-color: color-mix(in srgb, var(--wb-line) 60%, var(--wb-ink-2)); }
[data-dsh-personal-workbench-view] .wb-folder.selected { border-color: var(--wb-accent-line); background: var(--wb-accent-soft); }
[data-dsh-personal-workbench-view] .wb-folder-head { display: flex; align-items: center; gap: 8px; margin-bottom: 9px; }
[data-dsh-personal-workbench-view] .wb-folder-ic {
  width: 25px; height: 25px; border-radius: 8px; flex: none; display: grid; place-items: center;
  background: var(--wb-accent-soft); color: var(--wb-accent);
}
[data-dsh-personal-workbench-view] .wb-folder-head h4 {
  margin: 0; flex: 1; min-width: 0; font-size: 13.5px; font-weight: 600;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
[data-dsh-personal-workbench-view] .wb-folder-cnt {
  flex: none; font-size: 11px; font-weight: 650; font-variant-numeric: tabular-nums;
  background: var(--wb-sunk); border: 1px solid var(--wb-line-soft); border-radius: 999px; padding: 3px 7px; color: var(--wb-ink-2);
}
[data-dsh-personal-workbench-view] .wb-folder-mini { display: flex; flex-direction: column; gap: 4px; }
[data-dsh-personal-workbench-view] .wb-folder-mini span {
  font-size: 12px; color: var(--wb-ink-2); background: var(--wb-sunk); border-radius: 6px; padding: 5px 8px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
[data-dsh-personal-workbench-view] .wb-folder-mini span.more { background: transparent; color: var(--wb-ink-3); padding-left: 0; }
[data-dsh-personal-workbench-view] .wb-folder.new {
  border-style: dashed; box-shadow: none; display: grid; place-items: center; text-align: center;
  color: var(--wb-ink-3); font-size: 12.5px; min-height: 116px;
}
[data-dsh-personal-workbench-view] .wb-folder-acts {
  position: absolute; top: 8px; right: 8px; display: flex; gap: 4px; opacity: 0; transition: opacity .12s ease;
}
[data-dsh-personal-workbench-view] .wb-folder:hover .wb-folder-acts { opacity: 1; }
[data-dsh-personal-workbench-view] .wb-icon-btn {
  width: 24px; height: 24px; border-radius: 6px; display: grid; place-items: center;
  border: 1px solid var(--wb-line); background: var(--dsw-alias-bg-layer-2, var(--wb-surface)); color: var(--wb-ink-2);
}
[data-dsh-personal-workbench-view] .wb-icon-btn:hover { color: var(--wb-ink-1); background: var(--wb-sunk); }
[data-dsh-personal-workbench-view] .wb-member {
  display: flex; align-items: center; gap: 9px; padding: 9px 13px;
  border-bottom: 1px solid var(--wb-line-soft); font-size: 12.5px;
}
[data-dsh-personal-workbench-view] .wb-member:last-child { border-bottom: none; }
[data-dsh-personal-workbench-view] .wb-member .t { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* 会话标题栏入口（官方槽位 conversation.session.header.actions） */
.wb-header-entry {
  display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 10px;
  border-radius: 8px; border: 1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.26));
  background: transparent; color: var(--dsw-alias-label-secondary, inherit);
  font: inherit; font-size: 12px; cursor: pointer;
}
.wb-header-entry:hover { color: var(--dsw-alias-label-primary, inherit); background: color-mix(in srgb, currentColor 8%, transparent); }
.wb-header-entry svg { width: 14px; height: 14px; }
.wb-header-entry[data-active] {
  border-color: color-mix(in srgb, #2E9B7B 40%, transparent);
  background: color-mix(in srgb, #2E9B7B 14%, transparent);
  color: var(--dsw-alias-label-primary, inherit); font-weight: 600;
}

@media (max-width: 900px) {
  .wb-overlay { padding: 12px; }
  .wb-dialog { max-height: 92vh; }
  .wb-settings { grid-template-columns: 1fr; gap: 12px; }
  .wb-settings-nav { flex-direction: row; flex-wrap: wrap; }
  .wb-settings-nav button { width: auto; }
  [data-dsh-personal-workbench-view] .wb-folder-grid { grid-template-columns: 1fr 1fr; }
}
@media (prefers-reduced-motion: reduce) {
  .wb-overlay, .wb-dialog, .wb-toast, .wb-toast.leaving { animation: none; }
}

/* ===========================================================================
   知识库（打样 2 号）：密集列表 + 自适应时间分组 + 编号分页
   判定全在 listPresentation.ts；这里只负责长什么样。
   =========================================================================== */
/* 知识库工具栏：**一行**放完 —— 左半搜索/排序/命中数，右半三个按钮。
   宽度不够时只缩搜索框（唯一可缩项）；按钮一律 flex:none + nowrap，
   否则会被父级 flex 压成竖排文字（本项目踩过一次：缺 flex-shrink/min-width/white-space 三重保护）。 */
.wb-kb-bar { display:flex; gap:8px; align-items:center; margin-bottom:9px; }
.wb-kb-bar > * { flex:none; white-space:nowrap; }
.wb-kb-search { flex:1 1 auto; min-width:110px; background:var(--wb-sunk); border:1px solid var(--wb-line); color:inherit;
  border-radius:var(--wb-r-1); padding:7px 10px; font:inherit; font-size:12.5px; }
.wb-kb-spacer { flex:1 1 auto !important; min-width:0; }
.wb-kb-sortkey, .wb-kb-pagesize { background:var(--wb-sunk); border:1px solid var(--wb-line); color:inherit;
  border-radius:var(--wb-r-1); padding:7px 9px; font:inherit; font-size:12.5px; }
.wb-kb-hit { font-size:11.5px; color:var(--wb-ink-3); font-variant-numeric:tabular-nums; }
/* 排序方向只留箭头（排序键名在下拉里已有）：把这一行的宽度预算让给搜索框 */
.wb-kb-sortdir { padding-left:9px; padding-right:9px; font-variant-numeric:tabular-nums; }

/* 通用分类 Tab 条（知识库与任务页共用；组件在 components/TabBar.tsx） */
.wb-tabs { display:flex; gap:2px; overflow-x:auto; border-bottom:1px solid var(--wb-line); margin-bottom:9px; }
.wb-tab { border:none; background:transparent; color:var(--wb-ink-3); font:inherit; font-size:12.5px;
  padding:8px 11px 9px; border-bottom:2px solid transparent; cursor:pointer; white-space:nowrap;
  display:inline-flex; align-items:center; gap:6px; }
.wb-tab:hover { color:var(--wb-ink-1); }
.wb-tab.on { color:var(--wb-ink-1); font-weight:600; border-bottom-color:var(--wb-accent); }
.wb-tab-dot { width:7px; height:7px; border-radius:50%; display:inline-block; flex:none; }
.wb-tab-cnt { font-size:10.5px; background:color-mix(in srgb, var(--wb-ink-1) 8%, transparent);
  border-radius:999px; padding:1px 6px; color:var(--wb-ink-3); font-variant-numeric:tabular-nums; }
.wb-tab.on .wb-tab-cnt { color:var(--wb-ink-1); background:var(--wb-accent-soft); }

/* 标签筛选：**单行**（横向滚动），不再 flex-wrap 铺开——标签一多就吃好几行高度。
   超出 VISIBLE_TAG_LIMIT 的收进「更多 ▾」浮层（TagFilter.tsx）。 */
.wb-kb-tags { display:flex; gap:5px; flex-wrap:nowrap; overflow-x:auto; margin-bottom:10px;
  padding-bottom:2px; scrollbar-width:thin; }
.wb-kb-tags::-webkit-scrollbar { height:5px; }
.wb-kb-tags::-webkit-scrollbar-thumb { background:color-mix(in srgb, var(--wb-ink-1) 16%, transparent); border-radius:3px; }
.wb-kb-tag { flex:none; border:1px solid var(--wb-line); background:transparent; color:var(--wb-ink-3);
  border-radius:999px; padding:2px 9px; font:inherit; font-size:11px; cursor:pointer; white-space:nowrap; }
.wb-kb-tag:hover { color:var(--wb-ink-1); }
.wb-kb-tag.on { color:var(--wb-ink-1); border-color:var(--wb-accent-line); background:var(--wb-accent-soft); font-weight:600; }
.wb-kb-tagcnt { margin-left:5px; opacity:.7; font-variant-numeric:tabular-nums; }
.wb-kb-tag-more { border-style:dashed; }

/* 「更多标签」浮层：portal 到 document.body（工具栏在滚动容器里，留在里面会被裁）。
   与 .wb-idea-foldmenu 同一套：容器 pointer-events:none 防继承、z-index 高于面板宿主 55。 */
.wb-tagmenu { position:fixed; z-index:60; min-width:210px; max-width:280px; padding:6px;
  background:var(--dsw-alias-bg-layer-2, #1c1c1f); border:1px solid var(--wb-line);
  border-radius:10px; box-shadow:0 12px 32px rgba(0,0,0,.45); pointer-events:none; }
.wb-tagmenu > * { pointer-events:auto; }
.wb-tagmenu-search { width:100%; box-sizing:border-box; background:var(--wb-sunk); border:1px solid var(--wb-line);
  color:inherit; border-radius:var(--wb-r-1); padding:6px 8px; font:inherit; font-size:12px; margin-bottom:5px; }
.wb-tagmenu-list { max-height:220px; overflow-y:auto; display:flex; flex-direction:column; gap:1px; }
.wb-tagmenu-item { display:flex; align-items:center; gap:7px; width:100%; text-align:left; border:none;
  background:transparent; color:var(--wb-ink-1); font:inherit; font-size:12.5px; padding:6px 8px;
  border-radius:7px; cursor:pointer; }
.wb-tagmenu-item:hover { background:color-mix(in srgb, var(--wb-ink-1) 8%, transparent); }
.wb-tagmenu-item.on { background:var(--wb-accent-soft); font-weight:600; }
.wb-tagmenu-check { width:12px; flex:none; color:var(--wb-accent); }
.wb-tagmenu-name { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-tagmenu-cnt { flex:none; font-size:11px; color:var(--wb-ink-3); font-variant-numeric:tabular-nums; }
.wb-tagmenu-empty { padding:10px 8px; font-size:12px; color:var(--wb-ink-3); text-align:center; }
.wb-tagmenu-foot { display:flex; gap:6px; align-items:center; margin-top:5px; padding-top:5px;
  border-top:1px solid var(--wb-line-soft); }

/* 「AI 总结本地文档」弹窗（LocalDocModal.tsx）：路径 + 浏览 + 执行收在一处，
   工具栏因此只留一个按钮（原先三个裸控件横在工具栏里占一整行）。 */
.wb-doc-modal { width:min(680px, 94vw); }
.wb-doc-path { display:flex; gap:6px; align-items:center; margin-bottom:8px; }
.wb-doc-path input { flex:1; min-width:0; background:var(--wb-sunk); border:1px solid var(--wb-line); color:inherit;
  border-radius:var(--wb-r-1); padding:7px 10px; font:inherit; font-size:12.5px; }
.wb-doc-nav { display:flex; gap:6px; align-items:center; margin-bottom:8px; }
.wb-doc-crumb { flex:1; min-width:0; font-size:12px; word-break:break-all; color:var(--wb-ink-3);
  background:var(--wb-sunk); border:1px solid var(--wb-line); border-radius:6px; padding:4px 8px; }
.wb-doc-error { color:#E74C3C; font-size:12px; margin-bottom:6px; }
.wb-doc-loading { padding:16px; color:var(--wb-ink-3); font-size:13px; }
.wb-doc-list { max-height:320px; overflow:auto; border:1px solid var(--wb-line); border-radius:8px; }
.wb-doc-empty { padding:12px; color:var(--wb-ink-3); font-size:12px; }
.wb-doc-row { display:flex; align-items:center; gap:8px; padding:6px 8px; cursor:pointer;
  border-bottom:1px solid var(--wb-line-soft); }
.wb-doc-row:last-child { border-bottom:none; }
.wb-doc-row:hover { background:color-mix(in srgb, var(--wb-ink-1) 5%, transparent); }
.wb-doc-name { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:13px;
  display:inline-flex; align-items:center; gap:6px; }
.wb-doc-acts { display:flex; gap:6px; flex:none; }

.wb-kb-list { border:1px solid var(--wb-line-soft); border-radius:var(--wb-r-2); overflow:hidden; background:var(--wb-surface); }
.wb-kb-group { display:block; }
.wb-kb-ghead { display:flex; align-items:center; gap:8px; padding:9px 12px 4px; font-size:11px;
  font-weight:600; color:var(--wb-ink-3); letter-spacing:.3px; }
.wb-kb-gcnt { font-variant-numeric:tabular-nums; }
.wb-kb-gline { flex:1; height:1px; background:var(--wb-line-soft); }
.wb-kb-row { display:flex; align-items:flex-start; gap:10px; padding:8px 12px 8px 10px; cursor:pointer;
  border-left:3px solid transparent; transition:background .12s ease; }
.wb-kb-row:hover { background:color-mix(in srgb, var(--wb-ink-1) 5%, transparent); }
.wb-kb-row.sel { background:var(--wb-accent-soft); border-left-color:var(--wb-accent); }
.wb-kb-dot-sm { width:7px; height:7px; border-radius:50%; flex:none; margin-top:6px; }
.wb-kb-body { flex:1; min-width:0; }
.wb-kb-title { font-size:13px; font-weight:550; line-height:1.4; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-kb-sum { font-size:11.5px; color:var(--wb-ink-3); line-height:1.5; margin-top:2px;
  overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.wb-kb-meta { display:flex; gap:6px; align-items:center; flex-wrap:wrap; margin-top:4px; }
.wb-kb-chip { display:inline-flex; align-items:center; border-radius:5px; padding:1px 6px; font-size:10.5px; font-weight:600; white-space:nowrap; }
.wb-kb-tg { font-size:11px; color:var(--wb-ink-3); }
.wb-kb-stamp { flex:none; font-size:11px; color:var(--wb-ink-3); font-variant-numeric:tabular-nums; padding-top:2px; }

.wb-kb-pager { display:flex; align-items:center; gap:9px; flex-wrap:wrap; padding:10px 2px 2px;
  font-size:11.5px; color:var(--wb-ink-3); }
.wb-kb-pages { display:flex; gap:3px; }
.wb-kb-pnum { border:1px solid var(--wb-line); background:transparent; color:var(--wb-ink-2);
  border-radius:7px; min-width:27px; padding:3px 6px; font:inherit; font-size:11.5px; cursor:pointer; }
.wb-kb-pnum:hover:not(:disabled) { background:color-mix(in srgb, var(--wb-ink-1) 7%, transparent); }
.wb-kb-pnum.on { border-color:var(--wb-accent-line); color:var(--wb-ink-1); background:var(--wb-accent-soft); font-weight:600; }
.wb-kb-pnum:disabled { opacity:.35; cursor:default; }

/* ===========================================================================
   点子页（打样 1 号）：卡片瀑布。文件夹区沿用原有样式，未改。
   =========================================================================== */
.wb-idea-cards { display:grid; grid-template-columns:1fr 1fr; gap:11px; }
.wb-idea-card2 { position:relative; display:flex; flex-direction:column; gap:8px; cursor:pointer;
  padding:12px 13px 11px; border:1px solid var(--wb-line-soft); border-left:3px solid var(--wb-idea-color, var(--wb-ink-3));
  border-radius:11px; background:var(--wb-surface); box-shadow:var(--wb-sh-1);
  transition:border-color .14s ease, transform .14s ease, background .14s ease; }
.wb-idea-card2:hover { background:color-mix(in srgb, var(--wb-ink-1) 5%, var(--wb-surface)); transform:translateY(-1px); }
.wb-idea-card2.sel { border-color:var(--wb-accent-line); box-shadow:0 0 0 1px var(--wb-accent-line), var(--wb-sh-2); }
.wb-idea-card2.picked { border-color:var(--wb-accent-line); background:var(--wb-accent-soft); }
.wb-idea-title { font-size:13.5px; font-weight:600; line-height:1.45; padding-right:26px;
  display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
.wb-idea-sum2 { font-size:11.5px; color:var(--wb-ink-3); line-height:1.6;
  display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
.wb-idea-foot2 { display:flex; align-items:center; gap:6px; flex-wrap:wrap; margin-top:auto; padding-top:2px; }
.wb-idea-stamp { color:var(--wb-ink-3); font-size:11px; font-variant-numeric:tabular-nums; white-space:nowrap; margin-left:auto; }
.wb-idea-pick { position:absolute; top:9px; right:9px; width:19px; height:19px; border-radius:6px;
  border:1px solid var(--wb-line); background:var(--wb-sunk); color:transparent; font-size:11px; line-height:1;
  cursor:pointer; opacity:0; transition:opacity .12s ease, background .12s ease; padding:0; }
.wb-idea-card2:hover .wb-idea-pick,
.wb-idea-card2.picked .wb-idea-pick,
/* 键盘用户：Tab 焦点落在 ☑ 上时必须看得见（只靠 hover 显形 = 焦点落在隐形控件上） */
.wb-idea-pick:focus-visible,
.wb-idea-card2:focus-within .wb-idea-pick { opacity:1; }
.wb-idea-pick:focus-visible { outline:2px solid var(--wb-accent); outline-offset:1px; }
.wb-idea-pick[aria-pressed="true"] { color:var(--wb-ink-1); border-color:var(--wb-accent); background:var(--wb-accent); }
.wb-idea-foldbtn { border:1px solid var(--wb-line); background:transparent; color:var(--wb-ink-3);
  border-radius:7px; padding:2px 8px; font:inherit; font-size:11px; cursor:pointer; white-space:nowrap; }
.wb-idea-foldbtn:hover:not(:disabled) { color:var(--wb-ink-1); background:color-mix(in srgb, var(--wb-ink-1) 7%, transparent); }
.wb-idea-foldbtn:disabled { opacity:.45; cursor:default; }
.wb-idea-empty { padding:22px; text-align:center; color:var(--wb-ink-3); font-size:12.5px;
  border:1px dashed var(--wb-line); border-radius:11px; grid-column:1 / -1; }
/* 菜单 portal 到 document.body（见 IdeaCardGrid.tsx）：网格/卡片/面板的 overflow 与层叠都裁不到它。
   ⚠️ 两条坑都是 scripts/repro/harness-real-browser.mjs 的命中测试抓出来的（都是"看得见、点不动"）：
   1. pointer-events 是**继承**属性：面板宿主 .wb-panel-host 是 pointer-events:none
      （为了让左侧导航栏在面板铺开时仍可点）→ portal 到 body 的菜单连点击都收不到。
      按「容器 none + 菜单本体 auto」两段写，与 .wb-toasts / .wb-toast 同一套办法。
   2. z-index 必须**高于 .wb-panel-host 的 55**：否则面板里的卡片会盖在菜单上面，
      菜单看得见但点到的还是卡片（实测 z-index:40 时 elementFromPoint 命中的是 .wb-idea-card2）。 */
.wb-idea-foldmenu { position:fixed; z-index:60; min-width:200px; padding:4px;
  background:var(--dsw-alias-bg-layer-2, #1c1c1f); border:1px solid var(--wb-line);
  border-radius:10px; box-shadow:0 12px 32px rgba(0,0,0,.45);
  pointer-events:none; overflow-y:auto; }
.wb-idea-foldmenu > * { pointer-events:auto; }
.wb-idea-foldmenu button { display:flex; align-items:center; gap:7px; width:100%; text-align:left;
  border:none; background:transparent; color:var(--wb-ink-1); font:inherit; font-size:12.5px;
  padding:7px 9px; border-radius:7px; cursor:pointer; }
.wb-idea-foldmenu button:hover { background:color-mix(in srgb, var(--wb-ink-1) 8%, transparent); }
.wb-idea-foldic { flex:none; }
.wb-idea-foldnote { padding:5px 9px 7px; font-size:11px; color:var(--wb-ink-3); border-top:1px solid var(--wb-line-soft); margin-top:3px; }
@media (max-width: 720px) {
  .wb-idea-cards { grid-template-columns:1fr; }
}
`

/**
 * 对外导出的最终样式表：**令牌层 + 令牌化后的主体**。
 *
 * 两步的意义：主体里所有 '--dsw-*' 引用都被换成 '--wb-*'，而 '--wb-*' 在
 * 'tokenLayerCss()' 里以 'light-dark()' 兜底 —— 这样即使宿主主题令牌
 * 没有被继承到我们的节点（Modal portal 到 body、面板跨出主题子树），
 * 也只会跟随明暗，而不会退化成一片深黑。
 */
export const WORKBENCH_CSS = `${tokenLayerCss()}\n${toWorkbenchTokens(RAW_CSS)}`