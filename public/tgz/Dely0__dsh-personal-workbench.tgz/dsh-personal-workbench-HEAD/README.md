# dsh-personal-workbench

[![npm version](https://img.shields.io/npm/v/@dely0/dsh-personal-workbench)](https://www.npmjs.com/package/@dely0/dsh-personal-workbench)
[![license](https://img.shields.io/npm/l/@dely0/dsh-personal-workbench)](./LICENSE)

**DSH（DeepSeek Harness）个人工作台插件**：把 DSH 变成「日历 + 层级任务 + AI 助手」的工作台。
自然语言录入任务，AI 澄清 / 拆解 / 执行 / 复盘，数据全部留在本机。

[English](#english) · 简体中文

![今日](screenshot/%E4%BB%8A%E6%97%A5%E4%BB%BB%E5%8A%A1.PNG)

| 日历 | 快速录入 | 知识库 |
|---|---|---|
| ![日历](screenshot/%E6%97%A5%E5%8E%86%E5%8A%9F%E8%83%BD.png) | ![快速录入](screenshot/%E5%BF%AB%E9%80%9F%E5%BD%95%E5%85%A5.png) | ![知识库](screenshot/%E7%9F%A5%E8%AF%86%E5%BA%93.png) |

## 亮点

- 📅 **日历（周/月）+ 树状任务列表**；「今日」「日历」「任务」三视图，筛选排序可组合、保留父子层级
- ✨ **自然语言快速录入** → AI 澄清后生成任务；支持贴图与 PDF/DOCX 附件，不收的文件逐条给原因
- 🧠 **每个任务关联多个 AI 会话**：澄清 / 咨询 / 拆解 / 执行 / 复盘
- 🎭 **专家人格（角色库）**：三级来源（用户库 > 外部目录 > 内置 15 篇）；会话前选定，正文按需加载、不进提示词
- ✅ **「AI 申请完成 → 用户验收」闭环**；进度是显式值，AI 不能靠进度把任务标完成（ADR 0003/0004）
- 🗓️ **每日计划 + 容量账本**：AI 排序提案 → 确认才生效；「今日投入结束」≠ 任务完成（ADR 0007）
- 🎯 **会话前选 Skill / 模型 / 角色**，提示词自动注入「加载这些技能」
- ⏰ **到期提醒**：页内横幅 + 系统通知；可选微信通道（需 `@xmanrui/dsh-im`）
- 🌐 **界面语言**：自动 / 中文 / English（设置 → 语言）；顶栏、设置、角色库/专家、快速录入、任务表单、知识库与选择器已支持英文，深层说明文案增量迁移
- 🔒 **数据只在本机** `~/.dsh/workbench`，不上传任何服务器

## 安装

前置：**DSH ≥ `0.1.5-rc.1`**（Web 版）、Node `^22.19.0` 或 `>=24.0.0`、pnpm `>=11.7.0 <12`。

```sh
dsh plugin --profile web add @dely0/dsh-personal-workbench
```

> ⚠️ **装完必须重启 `dsh web`，只刷新浏览器不够**：客户端 bundle 由宿主在**启动时**读进内存，
> 刷新拿到的是旧代码。升级/回退同理。

其它装法：

```sh
# GitHub 源码
dsh plugin --profile web add git+https://github.com/Dely0/dsh-personal-workbench.git
# Release tarball
dsh plugin --profile web add file:/path/to/dsh-personal-workbench-<version>.tgz
```

## 快速上手

1. 侧栏点「工作台」打开面板；
2. 「快速录入」说一句话 → AI 澄清 → 确认建任务；
3. 任务详情点「AI 执行」→ 在会话里干活 → 完成后回面板**验收**；
4. 「今日」看待办与容量，需要时点「AI 智能排序」排今天的顺序；「日历」按天回看与排期。

## 兼容性

| 项 | 要求 | 拿不到时 |
|---|---|---|
| **面板本体**（官方槽位 + `layout.selectPanel`） | **DSH `0.1.5-rc.1+`** | **面板整块不启动**并打一条可读日志（刻意不降级） |
| 服务端能力：任务/日历/知识库/点子、提醒、日报周报、`workbench_*` 工具 | `0.1.0-rc.6+` | — |
| 会话绑定 `sessions.retain()` | `0.1.7-rc.2+` | 旧宿主自动回落 `sessions.binding()` |
| Skill 选择器 | 宿主 `skills` 注册表 | 选择器隐藏 |
| 微信提醒 | 可选插件 `@xmanrui/dsh-im` | 静默降级为页内提醒 + 系统通知 |

**最低支持版本是 `0.1.5-rc.1`，这是硬边界。** 为什么低于它选择"明确不启动"而不是降级、
以及 0.2.0 引入的插件兼容性预检（peer 区间为什么写成并列区间）：
见 [`docs/releases/v1.15.8.md`](docs/releases/v1.15.8.md) 与
[`docs/design/2026-09-13-client-architecture-official-only.md`](docs/design/2026-09-13-client-architecture-official-only.md)。

## 开发

```sh
git clone https://github.com/Dely0/dsh-personal-workbench.git
cd dsh-personal-workbench
pnpm install
pnpm check                 # 类型检查 + 构建
pnpm test                  # 全量回归（跑构建产物）
pnpm build && pnpm dev:install   # 装盘到本机 profile（装完重启 dsh web）
```

| 文档 | 用途 |
|---|---|
| [`.dsh/skills/dsh-plugin-change/`](.dsh/skills/dsh-plugin-change/SKILL.md) | **改代码前先读**：架构硬约束、本项目的编码规范与回归防线 |
| [`.dsh/skills/dsh-release/`](.dsh/skills/dsh-release/SKILL.md) | **发版前先读**：公开发布的硬门禁与命令序列（范围表、变异探针、PII 两面、tag/npm/Release、**发布成功判据**） |
| [`docs/release-checklist.md`](docs/release-checklist.md) | 发版前自检清单（可勾选版） |
| [`scripts/release-preflight.mjs`](scripts/release-preflight.mjs) | **发布门禁一键跑**：typecheck → 单测 → 全探针（每步 build）→ PII 两面 → 版本/文档；`--phase post` 做 tarball 与 sha1 对账、用户视角安装、Release 复核 |
| [`scripts/dev-verify.mjs`](scripts/dev-verify.mjs) | 研发版本验收链：构建 → 装盘 → 隔离实例重启 → 浏览器套件 → 证据包 |
| [`docs/issues/`](docs/issues/) | 滚动维护的已知问题与待办 |
| [`docs/adr/`](docs/adr/) | 已冻结的口径决策（容量、进度、角色、验收链、每日投入） |

## 版本历史

| 版本 | 要点 |
|---|---|
| **1.17.2** | **两处「点开就废」的可用性修复**：① **模型选择器一个模型都列不出来**（[issue #19](https://github.com/Dely0/dsh-personal-workbench/issues/19) / PR [#20](https://github.com/Dely0/dsh-personal-workbench/pull/20)，[@SnowNight777](https://github.com/SnowNight777)）—— DSH 0.2.1-rc.3 上宿主 `directoryFor(sessionId)` 先查 `sessions.scope()`，scope 只在有人 `retain()` 之后才物化，而 `ModelPicker` 自己挑会话却从不 retain ⇒ 先报 `ui-model-selection: session "…" resolved no scope`，补掉后首次建目录再报 `cannot get property "remote.session" without inject`（cordis traceable 服务把服务实例 `ctx` 影射成调用方 ctx）。本版取目录前按契约 retain（引用计数、卸载/切会话释放）、挑会话口径收敛到 `pickDirectorySessionId()`、调用宿主服务改走 `ctx.inject(['remote.session'])` 的子 ctx（可选依赖，不把没装该 provider 的机器整块面板 pending），重试判据只认 `resolved no scope` / `resolved no binding`。② **「AI 执行」弹窗拿不到「开始」**（[issue #17](https://github.com/Dely0/dsh-personal-workbench/issues/17) / PR [#21](https://github.com/Dely0/dsh-personal-workbench/pull/21)，[@WUWAN01](https://github.com/WUWAN01) 报告）—— `.wb-modal` 无高度上限、操作栏走普通文档流，1080p/150% 下弹窗高于视口、底部「取消/开始」被推到屏幕外且整页滚动救不回来（`task_sessions` 0 行）；本版加 `max-height:min(88vh,900px)`、`overflow-y:auto`、`overscroll-behavior:contain`，底栏改 `position:sticky` 并补图层底色，附「缺一条规则就红」的 CSS 判据与实机双相位探针 `scripts/repro/repro-issue17-modal-overflow.mjs`。同版合入 i18n 深度翻译二轮（[PR #18](https://github.com/Dely0/dsh-personal-workbench/pull/18)，[@Chewbacca96](https://github.com/Chewbacca96)）。详见 [docs/releases/v1.17.2.md](docs/releases/v1.17.2.md) |
| **1.17.1** | **修复 issue #15：点子页「新建 / 重命名文件夹」点了没反应**（v1.16.3 客户端拆分的残留）—— 五个「新建文件夹」入口与卡片 hover 的 ✎ 从 1.16.3 起只改 `folderForm` 状态、**没有任何组件读它**，于是没弹窗、没请求、没报错；本版按拆分前的 DOM 恢复文件夹弹窗（新建/重命名两模式、Enter 提交、Esc/遮罩取消、空标题禁用），并让 `Modal` 优先聚焦 `[data-autofocus]` 主字段（否则焦点落在关闭按钮上，打字没反应）。同版新增 `test/ideasFolderForm.test.mjs`（hook 暴露的状态/动作必须有渲染层读者，防"只写不读"静默丢失回归），并修掉验收链在英文界面下的两处假红（「返回对话」定位改共享表达式、expert 真实模型跳过显式登记）。详见 [`docs/releases/v1.17.1.md`](docs/releases/v1.17.1.md) |
| **1.17.0** | **角色库/专家 UI 可用性 + 英文界面（i18n）+ 宿主浮层挂载**：修掉专家草稿预览一字一行/横向溢出、设置页「继续修改」后弹窗不关、「查看草稿」被设置弹窗遮挡、界面露出 `**` 与角色来源标签重复；设置新增**语言**（自动/中文/English），顶栏、设置、角色库/专家、快速录入、任务表单与知识库等顶层界面支持英文，语言保存后重启仍保留；浮层改为优先挂宿主 `[data-shell-overlay]` 层并补 `pointer-events`，修复桌面端设置弹窗与模型列表被面板盖住（[issue #14](https://github.com/Dely0/dsh-personal-workbench/issues/14)）。英文界面见 [issue #12](https://github.com/Dely0/dsh-personal-workbench/issues/12)。详见 [`docs/releases/v1.17.0.md`](docs/releases/v1.17.0.md) |
| **1.16.5** | **合入外部贡献：工作台样式节点丢失后的自愈**（[issue #9](https://github.com/Dely0/dsh-personal-workbench/issues/9) / [PR #10](https://github.com/Dely0/dsh-personal-workbench/pull/10)，[@SnowNight777](https://github.com/SnowNight777)）—— 插件活动期间 `style[data-dsh-personal-workbench-style]` 被删掉后约 **600ms** 内自动重建，关闭态面板不再"无样式弹出并覆盖界面"；观察者挂在**插件实例**上（不是模块级），`cleanup()` 先 `disposed = true` 再 `disconnect()`。同版修掉 **main 连续 33 次红的 CI**：`test/db.test.mjs` 那条"同链计划项"断言的**场景**从 2026-10-01 起就写错了、且 `finally` 里的清理异常会顶替断言失败（正是它被长期读成"Windows EPERM 假失败"的原因），CI run **#84** 双绿。详见 [`docs/releases/v1.16.5.md`](docs/releases/v1.16.5.md) |
| **1.16.4** | **「排入今日」的父子口径定案**：计划项必须是**可执行叶子**，在**父任务**上点一次 = 按树序**展开它下面所有未完成叶子**（各自带自己的投入），父任务自己不是计划项、在「计划」页签作**分组行**（「已排 N / 共 M 个子任务 · 合计 X 分钟」）；候选池只收叶子、AI 侧口径同步「只排可执行叶子」（含父任务的提案整份被拒）。同版修掉「**清除今日计划不刷新**」与两处验收链套件假红。口径见 [`docs/adr/0010-plan-items-are-executable-leaves.md`](docs/adr/0010-plan-items-are-executable-leaves.md)，详见 [`docs/releases/v1.16.4.md`](docs/releases/v1.16.4.md) |
| **1.16.3** | **客户端入口拆分**：`src/client/index.tsx` **5725 → 1972 行**、`WorkbenchApp` **4197 → 631 行**；117 个 state 按域收进 16 个 hook，五个视图与任务详情区各自成组件（`hooks/` + `views/` + `app/` 装配四段）；ADR-0008 结构硬门（体内 `useState`/`api`/`fetch`/定时器 = 0、单个顶层块 ≤80 行）落成扫描判据。**纯结构重构、零行为变化**。详见 [`docs/releases/v1.16.3.md`](docs/releases/v1.16.3.md) |
| **1.16.2** | 日期面板补**「逾期」/「未排期」两个任务页签**（无截止、没排期、非进行中的任务终于有归宿，「未排期」= 补集：三页签并集恰好是全部未完成）+ 这两个页签的行内**「排入今日」**；统计卡「逾期」口径统一到**当日 00:00**（与页签同一把尺子）。详见 [`docs/releases/v1.16.2.md`](docs/releases/v1.16.2.md) |
| 1.16.1 | AI 会话工作区**双模式**（已有工作区下拉 + 文件夹弹框）；「今日」与「日历」收敛为**同一个日期面板**（计划/已完成/报告三页签，树口径＝当日到期 ∪ 当日计划项 ∪ 进行中，逐条标来源）；构建期类型源对齐 DSH `0.2.0-rc.2`。详见 [`docs/releases/v1.16.1.md`](docs/releases/v1.16.1.md) |
| 1.16.0 | 任务进度（显式值、AI 不能靠进度完成）+ 专家人格角色库（三级来源 / 15 篇内置）+ 研发版本验收链。⚠️ schema 18 → 19。详见 [`docs/releases/v1.16.0.md`](docs/releases/v1.16.0.md) |
| 1.15.8 | 适配 DSH `0.2.0-rc.1` 的插件兼容性预检（peer 改**并列区间**，下界不动） |
| 1.15.7 | 快速录入模型选择死锁 + rc.2 系统通知失败被吞（两处 P0） |
| 1.15.6 | 补齐 `0.1.7-rc.2` 上「当前会话」读取的三处静默 `undefined` |
| 1.15.5 | 适配 `0.1.7-rc.2`：会话绑定/打开、标题栏让位、侧栏量宽、工作区静默丢件 |
| 1.15.3 | 合入社区三项修复（提醒漏建 / 投递目标缓存 / 复用会话陈旧引用） |
| 1.15.2 | 模型浮层遮挡、默认工作区被任务污染、容量账本透明化、知识库 Tab 化、知识自动召回 |
| 1.15.1 | 任务资料夹改 `<任务ID>-<标题片段>`、快录附件（图片/PDF/DOCX）、模型选择器、`/workbench` 命令 |
| 1.14.57 | 架构重构：面板可见性唯一权威源、删除 DOM 降级腿、能力门槛「明确不启动」 |
| 更早 | 完整发行说明见 [`docs/releases/`](docs/releases/) |

## 路线图

- [ ] 客户端 `WorkbenchApp` 拆分（施工图待重写）
- [ ] 任务拖拽排序、数据导入导出
- [ ] 定时自动化、多端同步（各自单独立项）

## 致谢

- **[@Guojing6](https://github.com/Guojing6)** —— v1.15.1 的多项能力源自其 fork
  [`Guojing6/dsh-workbench`](https://github.com/Guojing6/dsh-workbench)：任务资料夹改用任务 ID、
  快录附件、模型选择器、`/workbench` 斜杠命令、请求围栏加固；并定位了两个我们一直带着的真 bug。
- **[@SnowNight777](https://github.com/SnowNight777)** —— v1.15.3 的三项修复全部来自其报告
  （issue [#4](https://github.com/Dely0/dsh-personal-workbench/issues/4) /
  [#5](https://github.com/Dely0/dsh-personal-workbench/issues/5) /
  [#7](https://github.com/Dely0/dsh-personal-workbench/issues/7) 与 PR
  [#6](https://github.com/Dely0/dsh-personal-workbench/pull/6) /
  [#8](https://github.com/Dely0/dsh-personal-workbench/pull/8)）；**v1.16.5 的工作台样式自愈**同样来自其
  issue [#9](https://github.com/Dely0/dsh-personal-workbench/issues/9)（含故障注入最小复现与只读状态采集脚本）
  与 PR [#10](https://github.com/Dely0/dsh-personal-workbench/pull/10)（样式节点丢失后的自动恢复 + 生命周期清理 + 7 例回归）。
- **[@Chewbacca96](https://github.com/Chewbacca96)** —— v1.17.0 的 UI localization（issue [#12](https://github.com/Dely0/dsh-personal-workbench/issues/12)）需求与边界定义。
- **[@SnowNight777](https://github.com/SnowNight777)** —— v1.17.0 的宿主浮层挂载修复（issue [#14](https://github.com/Dely0/dsh-personal-workbench/issues/14)）提供了真实测量、`elementFromPoint` 证据与可直接落地的方案；此前 v1.15.3 / v1.16.5 的贡献见下。
- [@tujunwenjie](https://github.com/tujunwenjie)、[@lhmhz](https://github.com/lhmhz) —— issue 诊断报告。
- **[@SnowNight777](https://github.com/SnowNight777)** —— **v1.17.2 的模型选择器修复**（issue
  [#19](https://github.com/Dely0/dsh-personal-workbench/issues/19) / PR
  [#20](https://github.com/Dely0/dsh-personal-workbench/pull/20)）：报告自带两条根因（`retain()` 之后 scope 才物化；
  cordis traceable 服务把服务实例 `ctx` 影射成调用方 ctx，于是宿主里那句 `this.ctx.remote.session` 要求调用方 inject），
  并先划清「不能把可选 provider 写进 `inject`」的边界；PR 在 DSH 0.2.1-rc.3 桌面端实测通过。
  此前 v1.15.3 / v1.16.5 / v1.17.0 的贡献见下。
- **[@WUWAN01](https://github.com/WUWAN01)** —— **v1.17.2 的「AI 执行」弹窗视口缺陷**（issue
  [#17](https://github.com/Dely0/dsh-personal-workbench/issues/17)）：报告含完整 DOM 结构、`lib/client.js:155` 的
  `.wb-modal-mask` 规则位置、`task_sessions` 0 行证据与可直接落地的修补建议（高度上限 / 内部滚动 / sticky 底栏），
  并指出 `lib/client/styles.js` 运行时并未被加载。
- **[@Chewbacca96](https://github.com/Chewbacca96)** —— v1.17.2 的 **i18n 深度翻译二轮**（PR
  [#18](https://github.com/Dely0/dsh-personal-workbench/pull/18)）：面板入口、草稿横幅、设置、容量规则、任务详情与点子 Tab。
- **内置角色库**含两个 MIT 上游（`novotnyllc/dotnet-artisan`、`K-Dense-AI/scientific-agents`）的领域角色，
  完整署名与「我们改了什么」见 [`THIRD_PARTY_NOTICES.md`](./THIRD_PARTY_NOTICES.md)。

逐项来源与许可证见 [`THIRD_PARTY_NOTICES.md`](./THIRD_PARTY_NOTICES.md)。

## 免责声明

社区项目，与 DeepSeek 官方无关，不提供任何担保。安装即表示你信任该代码会以你的 DSH 用户权限在本机运行；执行类 AI 操作可能修改工作区文件、消耗 API 额度，请先阅读代码并谨慎使用。

## License

[MIT](./LICENSE)。部分 DOM 挂载模式与客户端构建包装参考了 `dsh-task-board`（BSD-3-Clause）与 `dsh-genui`（MIT），详见 [`THIRD_PARTY_NOTICES.md`](./THIRD_PARTY_NOTICES.md)。

---

# English

**A personal workbench plugin for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (DSH)** —
turn DSH into a calendar + hierarchical task list + AI assistant workbench. All data stays on your machine.

## Highlights

- 📅 Calendar (week/month) + tree task list; Today / Calendar / Tasks views with combinable filters that keep parent-child structure
- ✨ Natural-language quick capture → AI clarification → task created; images and PDF/DOCX attachments supported
- 🧠 Multiple AI sessions per task: clarify / consult / breakdown / execute / review
- 🎭 **Personas**: three-tier library (user > external dir > 15 built-ins), picked per session, loaded on demand (never inlined into the prompt)
- ✅ "AI requests completion → you accept" loop; progress is an explicit value the AI cannot use to complete a task
- 🗓️ Daily plan + capacity ledger: AI proposes an order, only your confirmation applies it; "done for today" ≠ task completed
- 🎯 Pick Skill / model / persona before each AI session; prompt gets a "load these skills" instruction
- ⏰ Due reminders (in-panel banner + system notification), optional WeChat channel via `@xmanrui/dsh-im`
- 🌐 **UI language**: auto / 中文 / English (Settings → Language); top-level chrome, settings, personas/experts, quick capture, task forms, knowledge view and pickers are translated, with deeper copy migrated incrementally
- 🔒 Local-only storage at `~/.dsh/workbench`

## Install

Requires **DSH ≥ `0.1.5-rc.1`** (web), Node `^22.19.0` or `>=24.0.0`, pnpm `>=11.7.0 <12`.

```sh
dsh plugin --profile web add @dely0/dsh-personal-workbench
# or: dsh plugin --profile web add git+https://github.com/Dely0/dsh-personal-workbench.git
```

> ⚠️ **You must restart `dsh web` after installing** — the client bundle is read into memory at host startup, so a browser refresh keeps serving the old code.

## Compatibility

| | Requirement | If missing |
|---|---|---|
| **Panel** (official slots + `layout.selectPanel`) | **DSH `0.1.5-rc.1+`** | Panel **refuses to start** and logs a readable reason (deliberately not degraded) |
| Server-side features (tasks, reminders, reports, `workbench_*` tools) | `0.1.0-rc.6+` | — |
| Session binding via `sessions.retain()` | `0.1.7-rc.2+` | Falls back to `sessions.binding()` on older hosts |
| WeChat reminders | optional `@xmanrui/dsh-im` | Falls back to in-panel + system notifications |

## Development

```sh
pnpm install && pnpm check && pnpm test
```

Read [`.dsh/skills/dsh-plugin-change/`](.dsh/skills/dsh-plugin-change/SKILL.md) before changing code and
[`.dsh/skills/dsh-release/`](.dsh/skills/dsh-release/SKILL.md) before publishing; a tick-box version of the
release checklist lives in [`docs/release-checklist.md`](docs/release-checklist.md), and the automated
verification chain in [`scripts/dev-verify.mjs`](scripts/dev-verify.mjs).

## Credits & License

Community project, not affiliated with DeepSeek; provided as-is. **v1.17.2** ships fixes and translations
from [@SnowNight777](https://github.com/SnowNight777) (model picker, #19/#20),
[@WUWAN01](https://github.com/WUWAN01) (AI-run modal viewport, #17) and
[@Chewbacca96](https://github.com/Chewbacca96) (deeper i18n pass, #18). External contributions and bundled
MIT-licensed persona sources are listed in [`THIRD_PARTY_NOTICES.md`](./THIRD_PARTY_NOTICES.md).
Licensed under [MIT](./LICENSE).
