import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { pathToFileURL } from 'url';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { analyzeImage, composeChain, removeWorkdir, resolveInput, runCommand } from './analyzer.ts';
import {
    buildCooldownController,
    cooldownStateKey,
    DEFAULT_COOLDOWN_MS,
    emptyCooldownState,
    loadCooldownState,
    MONTHLY_COOLDOWN_MS,
    recordQuotaCooldown,
} from './cooldown.ts';
import { ApiKeyFailureError } from './util/apiKeys.ts';

// Production apiFetch always uses npm undici fetch. Tests bridge it back to
// the global fetch so the existing vi.stubGlobal('fetch') doubles keep working.
vi.mock('undici', async (importOriginal) => {
    const real = await importOriginal<typeof import('undici')>();
    return {
        ...real,
        fetch: (...args: Parameters<typeof globalThis.fetch>) => globalThis.fetch(...args),
    };
});

const onWindows = process.platform === 'win32';

describe('resolveInput', () => {
    it('resolves local paths to absolute paths', () => {
        const resolved = resolveInput('some/dir/img.png');
        expect(resolved.kind).toBe('local');
        expect(path.isAbsolute(resolved.source)).toBe(true);
        expect(resolved.source.endsWith(path.join('some', 'dir', 'img.png'))).toBe(true);
    });

    it('keeps https URLs as remote sources', () => {
        const resolved = resolveInput('https://example.com/demo.png');
        expect(resolved).toEqual({ source: 'https://example.com/demo.png', kind: 'remote' });
    });

    it('unwraps file:// URLs into local paths', () => {
        const filePath = path.join(os.tmpdir(), 'shot.png');
        const resolved = resolveInput(pathToFileURL(filePath).href);
        expect(resolved).toEqual({ source: path.resolve(filePath), kind: 'local' });
    });

    it('decodes escaped characters in file:// URLs', () => {
        const filePath = path.join(os.tmpdir(), 'modlens shot #1.png');
        const resolved = resolveInput(pathToFileURL(filePath).href);
        expect(resolved).toEqual({ source: path.resolve(filePath), kind: 'local' });
    });

    it('rejects empty input', () => {
        expect(() => resolveInput('  ')).toThrow('Input path is required.');
    });
});

// These exercise real subprocess lifecycle (pipe draining, SIGTERM/SIGKILL) with
// `#!/bin/sh` fake providers, which a POSIX shell has to run. Windows has no
// equivalent for `trap '' TERM` or a backgrounded `sleep`, so the suite is scoped
// to POSIX; the CLI's argument wiring is covered cross-platform in main.test.ts.
describe('composeChain preferences', () => {
    const discovery = {
        cachedAt: new Date().toISOString(),
        fromCache: false,
        probes: [
            {
                harness: 'codex' as const,
                cliFound: true,
                loggedIn: true,
                visionModels: ['default'],
                source: 'builtin-table' as const,
                elapsedMs: 0,
            },
        ],
    };

    function binDir(bins: string[]): string {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-bin-'));
        for (const bin of bins) {
            fs.writeFileSync(path.join(dir, bin), '#!/bin/sh\n', { mode: 0o755 });
        }
        return dir;
    }

    it('keeps a preferred claude-cli ahead of reused agents', () => {
        const dir = binDir(['claude', 'codex']);
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-home-'));
        const chain = composeChain(
            'local',
            { provider: 'claude-cli', reuse: { codex: true } },
            { env: { PATH: dir }, home, discovery },
        );
        expect(chain.map((p) => p.name)).toEqual(['claude-cli', 'codex-cli']);
        fs.rmSync(dir, { recursive: true, force: true });
        fs.rmSync(home, { recursive: true, force: true });
    });

    it('keeps a preferred agent ahead of reused inline keys when no base inline exists', () => {
        const dir = binDir(['agy', 'pi']);
        fs.writeFileSync(path.join(dir, 'pi'), '#!/bin/sh\necho k\n', { mode: 0o755 });
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-home-'));
        fs.mkdirSync(path.join(home, '.pi', 'agent'), { recursive: true });
        fs.writeFileSync(
            path.join(home, '.pi', 'agent', 'models-store.json'),
            JSON.stringify({
                openai: {
                    models: [
                        {
                            id: 'gpt-5.6-sol',
                            provider: 'openai',
                            api: 'openai-completions',
                            baseUrl: 'https://x.example/v1',
                            input: ['text', 'image'],
                        },
                    ],
                },
            }),
        );
        fs.writeFileSync(
            path.join(home, '.pi', 'agent', 'auth.json'),
            JSON.stringify({ openai: { type: 'api_key' } }),
        );
        const chain = composeChain(
            'local',
            { provider: 'antigravity-cli', reuse: { pi: true } },
            { env: { PATH: dir }, home },
        );
        expect(chain.map((p) => p.name)).toEqual(['antigravity-cli', 'pi:openai']);
        fs.rmSync(dir, { recursive: true, force: true });
        fs.rmSync(home, { recursive: true, force: true });
    });
});

describe('composeChain remote security boundary', () => {
    it('keeps reused inline keys ahead of a preferred agent for remote URLs', () => {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-bin-'));
        fs.writeFileSync(path.join(dir, 'agy'), '#!/bin/sh\n', { mode: 0o755 });
        fs.writeFileSync(path.join(dir, 'pi'), '#!/bin/sh\necho k\n', { mode: 0o755 });
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-home-'));
        fs.mkdirSync(path.join(home, '.pi', 'agent'), { recursive: true });
        fs.writeFileSync(
            path.join(home, '.pi', 'agent', 'models-store.json'),
            JSON.stringify({
                openai: {
                    models: [
                        {
                            id: 'gpt-5.6-sol',
                            provider: 'openai',
                            api: 'openai-completions',
                            baseUrl: 'https://x.example/v1',
                            input: ['text', 'image'],
                        },
                    ],
                },
            }),
        );
        fs.writeFileSync(
            path.join(home, '.pi', 'agent', 'auth.json'),
            JSON.stringify({ openai: { type: 'api_key' } }),
        );
        const chain = composeChain(
            'remote',
            { provider: 'antigravity-cli', reuse: { pi: true } },
            { env: { PATH: dir }, home },
        );
        // Only the inline path runs the SSRF guards, so the reused key leads
        // even though the user preferred the agent.
        expect(chain.map((p) => p.name)).toEqual(['pi:openai', 'antigravity-cli']);
        fs.rmSync(dir, { recursive: true, force: true });
        fs.rmSync(home, { recursive: true, force: true });
    });

    it('keeps a cooling inline provider ahead of agents on a remote URL', () => {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-bin-'));
        fs.writeFileSync(path.join(dir, 'agy'), '#!/bin/sh\n', { mode: 0o755 });
        const stateDir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-cd-'));
        const statePath = path.join(stateDir, 'state.json');
        const now = new Date('2026-08-06T00:00:00.000Z');
        recordQuotaCooldown(
            emptyCooldownState(),
            'gemini-api',
            new ApiKeyFailureError('out of credits', { quotaCooldown: 'default' }),
            now,
            statePath,
            undefined,
            0,
        );
        const chain = composeChain(
            'remote',
            { providers: { 'gemini-api': { apiKey: 'only-key' } } },
            { env: { PATH: dir } },
            buildCooldownController({}, { now, statePath }),
        );
        expect(chain.map((p) => p.name)).toEqual(['gemini-api', 'antigravity-cli']);
        fs.rmSync(dir, { recursive: true, force: true });
        fs.rmSync(stateDir, { recursive: true, force: true });
    });

    it('keeps reused inline keys ahead of agents when the file gemini-api is cooling', () => {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-bin-'));
        fs.writeFileSync(path.join(dir, 'agy'), '#!/bin/sh\n', { mode: 0o755 });
        fs.writeFileSync(path.join(dir, 'pi'), '#!/bin/sh\necho k\n', { mode: 0o755 });
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-home-'));
        fs.mkdirSync(path.join(home, '.pi', 'agent'), { recursive: true });
        fs.writeFileSync(
            path.join(home, '.pi', 'agent', 'models-store.json'),
            JSON.stringify({
                openai: {
                    models: [
                        {
                            id: 'gpt-5.6-sol',
                            provider: 'openai',
                            api: 'openai-completions',
                            baseUrl: 'https://x.example/v1',
                            input: ['text', 'image'],
                        },
                    ],
                },
            }),
        );
        fs.writeFileSync(
            path.join(home, '.pi', 'agent', 'auth.json'),
            JSON.stringify({ openai: { type: 'api_key' } }),
        );
        const stateDir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-chain-cd-'));
        const statePath = path.join(stateDir, 'state.json');
        const now = new Date('2026-08-06T00:00:00.000Z');
        recordQuotaCooldown(
            emptyCooldownState(),
            'gemini-api',
            new ApiKeyFailureError('out of credits', { quotaCooldown: 'default' }),
            now,
            statePath,
            undefined,
            0,
        );
        recordQuotaCooldown(
            emptyCooldownState(),
            'gemini-api',
            new ApiKeyFailureError('out of credits', { quotaCooldown: 'default' }),
            now,
            statePath,
            undefined,
            1,
        );
        const chain = composeChain(
            'remote',
            {
                providers: { 'gemini-api': { apiKey: 'g1,g2' } },
                reuse: { pi: true },
            },
            { env: { PATH: dir }, home },
            buildCooldownController({}, { now, statePath }),
        );
        expect(chain.map((p) => p.name)).toEqual(['pi:openai', 'gemini-api', 'antigravity-cli']);
        fs.rmSync(dir, { recursive: true, force: true });
        fs.rmSync(home, { recursive: true, force: true });
        fs.rmSync(stateDir, { recursive: true, force: true });
    });
});

describe.skipIf(onWindows)('provider subprocess handling', () => {
    const cleanups: Array<() => void> = [];

    afterEach(() => {
        while (cleanups.length > 0) {
            cleanups.pop()?.();
        }
    });

    /** Fake provider binary plus a throwaway image to analyze. */
    function fakeProvider(script: string) {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-proc-'));
        const bin = path.join(dir, 'fake-agy');
        fs.writeFileSync(bin, script, { mode: 0o755 });
        const image = path.join(dir, 'image.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        return { bin, image };
    }

    // A full instance of the contract: analyzeImage now verifies the shape of
    // every provider result, so a partial structured_output would be rejected.
    const VALID_RESULT = {
        summary: 'ok',
        ocr: { full_text: '', lines: [] },
        layout: { regions: [] },
        semantics: { scene: '', entities: [] },
        visual: {},
        uncertainty: [],
    };
    const SUCCESS_ENVELOPE = JSON.stringify({
        status: 'SUCCESS',
        structured_output: VALID_RESULT,
    });

    it('returns as soon as the provider exits, even when a descendant holds the stdout pipe open', async () => {
        // agy leaves a language server running that inherited the pipe, so the
        // child's 'close' event never fires and the run used to hang until the
        // timeout killed it (issue #1).
        const { bin, image } = fakeProvider(
            `#!/bin/sh\necho '${SUCCESS_ENVELOPE}'\nsleep 30 &\nexit 0\n`,
        );

        const startedAt = Date.now();
        const result = await analyzeImage({
            input: image,
            providerBin: bin,
            timeoutMs: 20_000,
            config: {},
        });

        expect((result.result as { summary: string }).summary).toBe('ok');
        expect(Date.now() - startedAt).toBeLessThan(10_000);
    }, 30_000);

    it('still reports a non-zero exit with its stderr', async () => {
        const { bin, image } = fakeProvider('#!/bin/sh\necho "boom" >&2\nsleep 30 &\nexit 3\n');

        await expect(
            analyzeImage({ input: image, providerBin: bin, timeoutMs: 20_000, config: {} }),
        ).rejects.toThrow(/failed with code 3.*boom/s);
    }, 30_000);

    it('rejects a provider result that is missing schema fields', async () => {
        // The provider succeeded and returned JSON, but it is only half the
        // contract. Every provider goes through the same shape check now.
        const partial = JSON.stringify({
            status: 'SUCCESS',
            structured_output: { summary: 'ok' },
        });
        const { bin, image } = fakeProvider(`#!/bin/sh\necho '${partial}'\nexit 0\n`);

        await expect(
            analyzeImage({ input: image, providerBin: bin, timeoutMs: 20_000, config: {} }),
        ).rejects.toThrow(
            /antigravity-cli returned a result that does not match the vision schema/,
        );
    }, 30_000);

    it('drops empty optionals before returning, on a non-openai route (#37)', async () => {
        // The normalization lives at the shared boundary, so a CLI provider
        // gets it too: a model with nothing to note writes null there, and
        // what reaches the caller must never be a null where the contract
        // promises a string or an array.
        const nulls = JSON.stringify({
            status: 'SUCCESS',
            structured_output: {
                summary: 'ok',
                ocr: { full_text: '', lines: [{ text: 'a', language: null }] },
                layout: { regions: [] },
                semantics: {
                    scene: '',
                    intent: null,
                    entities: [{ name: 'e', type: 't', evidence: null }],
                    relations: null,
                },
                visual: { dominant_colors: null, style: null, notes: null },
                uncertainty: [],
                vendor_extra: null,
            },
        });
        const { bin, image } = fakeProvider(`#!/bin/sh\necho '${nulls}'\nexit 0\n`);

        const analyzed = await analyzeImage({
            input: image,
            providerBin: bin,
            timeoutMs: 20_000,
            config: {},
        });

        expect(JSON.stringify(analyzed.result)).not.toContain('null');
        const result = analyzed.result as {
            visual: Record<string, unknown>;
            semantics: Record<string, unknown>;
            ocr: { lines: Array<Record<string, unknown>> };
        };
        // All seven optional positions the contract has, one by one.
        expect('language' in result.ocr.lines[0]).toBe(false);
        expect('intent' in result.semantics).toBe(false);
        expect('relations' in result.semantics).toBe(false);
        const entity = (result.semantics.entities as Array<Record<string, unknown>>)[0];
        expect('evidence' in entity).toBe(false);
        expect('dominant_colors' in result.visual).toBe(false);
        expect('style' in result.visual).toBe(false);
        expect('notes' in result.visual).toBe(false);
        // And the required neighbours are untouched.
        expect(result.ocr.lines[0].text).toBe('a');
        expect(entity.name).toBe('e');
    }, 30_000);

    it('runs a subprocess provider in an isolated workdir holding only the image', async () => {
        // An injection in the image should not be able to read siblings of the
        // original file, so the agent runs in a throwaway dir of one image.
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-iso-'));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        const image = path.join(dir, 'shot.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        fs.writeFileSync(path.join(dir, 'secret.txt'), 'do not read me');
        const record = path.join(dir, 'record.txt');
        const bin = path.join(dir, 'fake-agy');
        // Record the cwd and its listing, then emit a valid envelope.
        fs.writeFileSync(
            bin,
            `#!/bin/sh\npwd > "${record}"\nls >> "${record}"\necho '${SUCCESS_ENVELOPE}'\n`,
            { mode: 0o755 },
        );

        await analyzeImage({ input: image, providerBin: bin, timeoutMs: 20_000, config: {} });

        const recorded = fs.readFileSync(record, 'utf-8');
        const cwd = recorded.trim().split('\n')[0];
        expect(cwd).not.toBe(dir); // not the original directory
        expect(recorded).toContain('shot.png'); // the image came along
        expect(recorded).not.toContain('secret.txt'); // the sibling did not
        expect(fs.existsSync(cwd)).toBe(false); // cleaned up after the run
    }, 30_000);

    it('hands the provider a real copy, so writing the temp image never mutates the original', async () => {
        // The isolated image used to be a hardlink sharing the original's
        // inode, so a provider writing "its" temp file rewrote the user's file.
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-mut-'));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        const image = path.join(dir, 'shot.png');
        fs.writeFileSync(image, 'original-bytes');
        const bin = path.join(dir, 'fake-agy');
        // Overwrite every file in the cwd (the isolated copy), then answer.
        fs.writeFileSync(
            bin,
            `#!/bin/sh\nfor f in *; do echo MUTATED > "$f"; done\necho '${SUCCESS_ENVELOPE}'\n`,
            { mode: 0o755 },
        );

        await analyzeImage({ input: image, providerBin: bin, timeoutMs: 20_000, config: {} });

        expect(fs.readFileSync(image, 'utf-8')).toBe('original-bytes');
    }, 30_000);

    it('runs a remote image in an empty throwaway cwd, not the caller directory', async () => {
        // A remote image has no local file to isolate, but the agent must still
        // not inherit the caller's directory, which it used to fall back to.
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-rem-'));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        const record = path.join(dir, 'record.txt');
        const bin = path.join(dir, 'fake-agy');
        fs.writeFileSync(
            bin,
            `#!/bin/sh\npwd > "${record}"\nls -A >> "${record}"\necho '${SUCCESS_ENVELOPE}'\n`,
            { mode: 0o755 },
        );

        await analyzeImage({
            input: 'https://example.com/shot.png',
            providerBin: bin,
            timeoutMs: 20_000,
            config: {},
        });

        const recorded = fs.readFileSync(record, 'utf-8').trim();
        const lines = recorded.split('\n');
        const cwd = lines[0];
        expect(cwd).not.toBe(process.cwd()); // never the caller's directory
        expect(lines).toHaveLength(1); // ls -A printed nothing: the cwd is empty
        expect(fs.existsSync(cwd)).toBe(false); // cleaned up after the run
    }, 30_000);

    it('reports a timeout when the provider never exits', async () => {
        // Straight at runCommand: analyzeImage adds a 30s kill backstop on top
        // of the caller's timeout, which would make this test crawl.
        const { bin } = fakeProvider('#!/bin/sh\nsleep 30\n');

        await expect(
            runCommand('fake', { command: bin, args: [], cwd: os.tmpdir() }, 1_000),
        ).rejects.toThrow(/timed out after 1000 ms/);
    }, 20_000);

    it('escalates to SIGKILL when the child ignores SIGTERM', async () => {
        // The real failure mode: a process that traps SIGTERM. child.killed goes
        // true the instant SIGTERM is delivered, so the old !child.killed guard
        // never fired SIGKILL and this process would outlive the timeout.
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-kill-'));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        const bin = path.join(dir, 'stubborn');
        const pidFile = path.join(dir, 'pid');
        // trap '' TERM ignores SIGTERM outright; only SIGKILL can end this.
        fs.writeFileSync(
            bin,
            `#!/bin/sh\ntrap '' TERM\necho $$ > "$1"\nwhile true; do sleep 1; done\n`,
            { mode: 0o755 },
        );

        await expect(
            runCommand('fake', { command: bin, args: [pidFile], cwd: dir }, 500),
        ).rejects.toThrow(/timed out after 500 ms/);

        const pid = await waitFor(() => {
            const raw = fs.existsSync(pidFile) ? fs.readFileSync(pidFile, 'utf-8').trim() : '';
            return raw ? Number(raw) : null;
        });
        // The caller already has its timeout error; the process itself must still
        // be gone, killed by the SIGKILL backstop rather than left running.
        await waitFor(() => (isAlive(pid) ? null : true));
        expect(isAlive(pid)).toBe(false);
    }, 15_000);

    it('redacts a getter-only describeFailure message without replacing the Error (issue #85)', async () => {
        const { bin } = fakeProvider('#!/bin/sh\necho "boom" >&2\nexit 1\n');
        const described = new Error('placeholder');
        Object.defineProperty(described, 'message', {
            get: () => 'leaked sk-proj-abcdefghijklmnopqrstuvwxyz1234',
            configurable: true,
        });

        let rejected: unknown;
        try {
            await runCommand(
                'fake',
                { command: bin, args: [], cwd: os.tmpdir() },
                5_000,
                () => described,
            );
        } catch (error) {
            rejected = error;
        }
        expect(rejected).toBe(described);
        expect(described.message).toContain('[redacted]');
        expect(described.message).not.toContain('sk-proj-');
    }, 15_000);
});

function isAlive(pid: number): boolean {
    try {
        process.kill(pid, 0);
        return true;
    } catch {
        return false;
    }
}

async function waitFor<T>(probe: () => T | null | undefined, timeoutMs = 8_000): Promise<T> {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
        const value = probe();
        if (value !== null && value !== undefined && value !== false) {
            return value;
        }
        await new Promise((resolve) => setTimeout(resolve, 50));
    }
    throw new Error('waitFor timed out');
}

// Failover drives real subprocess fakes for agy plus a stubbed fetch for the
// inline providers, so the scenarios run offline and POSIX-only.
describe.skipIf(onWindows)('provider failover', () => {
    const cleanups: Array<() => void> = [];
    afterEach(() => {
        vi.unstubAllGlobals();
        vi.unstubAllEnvs();
        while (cleanups.length > 0) {
            cleanups.pop()?.();
        }
    });

    const CONTRACT_RESULT = {
        summary: 'ok',
        ocr: { full_text: '', lines: [] },
        layout: { regions: [] },
        semantics: { scene: '', entities: [] },
        visual: {},
        uncertainty: [],
    };

    /** A directory on PATH holding a fake agy with the given script, plus an image. */
    function fakeAgyDir(script: string) {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-fo-'));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        fs.writeFileSync(path.join(dir, 'agy'), script, { mode: 0o755 });
        const image = path.join(dir, 'shot.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        return { dir, image };
    }

    const geminiOk = () =>
        new Response(
            JSON.stringify({
                candidates: [{ content: { parts: [{ text: JSON.stringify(CONTRACT_RESULT) }] } }],
                usageMetadata: { totalTokenCount: 9 },
            }),
            { status: 200 },
        );

    const GEMINI_KEYED = { providers: { 'gemini-api': { apiKey: 'g-key' } } };
    // The default local chain is inline-first, so these failover scenarios pin
    // agy to the front via the provider preference to make it fail first.
    const AGY_FIRST = { ...GEMINI_KEYED, provider: 'antigravity-cli' };

    it('fails over from a broken agy to gemini-api and records both attempts', async () => {
        const { dir, image } = fakeAgyDir('#!/bin/sh\necho "agy exploded" >&2\nexit 1\n');
        vi.stubEnv('PATH', dir);
        vi.stubGlobal('fetch', async () => geminiOk());

        const result = await analyzeImage({
            input: image,
            config: AGY_FIRST,
            timeoutMs: 20_000,
        });

        expect(result.provider).toBe('gemini-api');
        expect(result.meta.attempts).toHaveLength(2);
        expect(result.meta.attempts[0]).toMatchObject({ provider: 'antigravity-cli', ok: false });
        expect(result.meta.attempts[1]).toMatchObject({ provider: 'gemini-api', ok: true });
        expect(result.meta.warnings.join(' ')).toContain('Failed over to gemini-api');
    }, 30_000);

    it('a schema-violating result also fails over, with the violation in the attempt', async () => {
        const partial = JSON.stringify({ status: 'SUCCESS', structured_output: { summary: 'x' } });
        const { dir, image } = fakeAgyDir(`#!/bin/sh\necho '${partial}'\nexit 0\n`);
        vi.stubEnv('PATH', dir);
        vi.stubGlobal('fetch', async () => geminiOk());

        const result = await analyzeImage({
            input: image,
            config: AGY_FIRST,
            timeoutMs: 20_000,
        });

        expect(result.provider).toBe('gemini-api');
        expect(result.meta.attempts[0].error).toMatch(/does not match the vision schema/);
    }, 30_000);

    it('an explicit -p pins the provider: original error, no fallback', async () => {
        const { dir, image } = fakeAgyDir('#!/bin/sh\necho "agy exploded" >&2\nexit 1\n');
        vi.stubEnv('PATH', dir);
        vi.stubGlobal('fetch', async () => geminiOk());

        let thrown: Error | null = null;
        try {
            await analyzeImage({
                input: image,
                provider: 'antigravity-cli',
                config: GEMINI_KEYED,
                timeoutMs: 20_000,
            });
        } catch (error) {
            thrown = error as Error;
        }
        expect(thrown).not.toBeNull();
        expect(thrown?.message).not.toContain('Every configured vision provider failed');
        expect(thrown?.message).toMatch(/agy|antigravity-cli/);
    }, 30_000);

    it('aggregates every failure when the whole chain is exhausted', async () => {
        const { dir, image } = fakeAgyDir('#!/bin/sh\necho "agy exploded" >&2\nexit 1\n');
        vi.stubEnv('PATH', dir);
        vi.stubGlobal('fetch', async () => new Response('quota exceeded', { status: 429 }));

        await expect(
            analyzeImage({ input: image, config: AGY_FIRST, timeoutMs: 20_000 }),
        ).rejects.toThrow(/Every configured vision provider failed.*antigravity-cli.*gemini-api/s);
    }, 30_000);

    it('a lone failing provider still hints at never-asked reusable vision', async () => {
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-auto-e2e-'));
        cleanups.push(() => fs.rmSync(home, { recursive: true, force: true }));
        fs.mkdirSync(path.join(home, '.codex'));
        fs.writeFileSync(path.join(home, '.codex', 'auth.json'), '{}');
        const { dir, image } = fakeAgyDir('#!/bin/sh\necho "agy exploded" >&2\nexit 1\n');
        fs.writeFileSync(path.join(dir, 'codex'), '#!/bin/sh\nexit 0\n', { mode: 0o755 });
        vi.stubEnv('PATH', dir);

        await expect(
            analyzeImage({
                input: image,
                config: {},
                autoOptions: { home, env: { PATH: dir } },
                timeoutMs: 20_000,
            }),
        ).rejects.toThrow(/not yet allowed to reuse/);
    }, 30_000);

    it('auto mode prepends borrowed routes: a discovered codex answers first and is accounted for', async () => {
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-auto-e2e-'));
        cleanups.push(() => fs.rmSync(home, { recursive: true, force: true }));
        fs.mkdirSync(path.join(home, '.codex'));
        fs.writeFileSync(path.join(home, '.codex', 'config.toml'), 'approval_policy = "never"\n');
        fs.writeFileSync(path.join(home, '.codex', 'auth.json'), '{}');
        const events = [
            JSON.stringify({ type: 'thread.started', thread_id: 't-auto' }),
            JSON.stringify({
                type: 'item.completed',
                item: { type: 'agent_message', text: JSON.stringify(CONTRACT_RESULT) },
            }),
            JSON.stringify({ type: 'turn.completed', usage: { input_tokens: 1 } }),
        ].join('\n');
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-fo-'));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        // PATH holds only the fake bin dir, so the script sticks to shell
        // builtins (no cat) and the events carry no single quotes (JSON).
        fs.writeFileSync(
            path.join(dir, 'codex'),
            `#!/bin/sh\n${events
                .split('\n')
                .map((line) => `echo '${line}'`)
                .join('\n')}\n`,
            { mode: 0o755 },
        );
        const image = path.join(dir, 'shot.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        vi.stubEnv('PATH', dir);

        const result = await analyzeImage({
            input: image,
            config: { reuse: { codex: true } },
            autoOptions: { home, env: { PATH: dir } },
            timeoutMs: 20_000,
        });
        expect(result.provider).toBe('codex-cli');
        expect(result.meta.attempts[0]).toMatchObject({ provider: 'codex-cli', ok: true });
        expect(result.meta.warnings.join(' ')).toContain('reused');
    }, 30_000);

    it('without the auto switch the same machine has no chain at all', async () => {
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-auto-e2e-'));
        cleanups.push(() => fs.rmSync(home, { recursive: true, force: true }));
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-fo-'));
        cleanups.push(() => fs.rmSync(dir, { recursive: true, force: true }));
        fs.writeFileSync(path.join(dir, 'codex'), '#!/bin/sh\nexit 0\n', { mode: 0o755 });
        const image = path.join(dir, 'shot.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        vi.stubEnv('PATH', dir);

        await expect(
            analyzeImage({
                input: image,
                config: {},
                autoOptions: { home, env: { PATH: dir } },
                timeoutMs: 20_000,
            }),
        ).rejects.toThrow(/No vision provider is set up/);
    });

    it('an explicit -p pin ignores auto routes entirely', async () => {
        const home = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-auto-e2e-'));
        cleanups.push(() => fs.rmSync(home, { recursive: true, force: true }));
        fs.mkdirSync(path.join(home, '.codex'));
        fs.writeFileSync(path.join(home, '.codex', 'config.toml'), 'approval_policy = "never"\n');
        fs.writeFileSync(path.join(home, '.codex', 'auth.json'), '{}');
        const { dir, image } = fakeAgyDir('#!/bin/sh\necho "agy exploded" >&2\nexit 1\n');
        fs.writeFileSync(path.join(dir, 'codex'), '#!/bin/sh\nexit 0\n', { mode: 0o755 });
        vi.stubEnv('PATH', dir);

        let thrown: Error | null = null;
        try {
            await analyzeImage({
                input: image,
                provider: 'antigravity-cli',
                config: { reuse: { codex: true } },
                autoOptions: { home, env: { PATH: dir } },
                timeoutMs: 20_000,
            });
        } catch (error) {
            thrown = error as Error;
        }
        expect(thrown?.message).toMatch(/agy|antigravity-cli/);
        expect(thrown?.message).not.toContain('codex');
    }, 30_000);

    it('sends extraBody from config, and --extra-body replaces it for the run', async () => {
        const { dir, image } = fakeAgyDir('#!/bin/sh\nexit 1\n');
        vi.stubEnv('PATH', dir);
        const bodies: string[] = [];
        vi.stubGlobal('fetch', async (_url: string, init: RequestInit) => {
            bodies.push(String(init.body));
            return geminiOk();
        });

        const config = {
            providers: {
                'gemini-api': {
                    apiKey: 'g-key',
                    extraBody: { generationConfig: { thinkingConfig: { thinkingLevel: 'LOW' } } },
                },
            },
        };

        await analyzeImage({ input: image, provider: 'gemini-api', config, timeoutMs: 20_000 });
        expect(JSON.parse(bodies[0]).generationConfig.thinkingConfig).toEqual({
            thinkingLevel: 'LOW',
        });

        await analyzeImage({
            input: image,
            provider: 'gemini-api',
            config,
            extraBody: { generationConfig: { thinkingConfig: { thinkingLevel: 'HIGH' } } },
            timeoutMs: 20_000,
        });
        expect(JSON.parse(bodies[1]).generationConfig.thinkingConfig).toEqual({
            thinkingLevel: 'HIGH',
        });
    }, 30_000);

    it('warns instead of pretending when a CLI provider gets an extraBody', async () => {
        const payload = JSON.stringify({ status: 'SUCCESS', structured_output: CONTRACT_RESULT });
        const { dir, image } = fakeAgyDir(`#!/bin/sh\necho '${payload}'\nexit 0\n`);
        vi.stubEnv('PATH', dir);

        const result = await analyzeImage({
            input: image,
            provider: 'antigravity-cli',
            extraBody: { thinking: { type: 'disabled' } },
            config: {},
            timeoutMs: 20_000,
        });

        expect(result.meta.warnings.join(' ')).toContain('extraBody was ignored');
    }, 30_000);

    it('reports how to set up when nothing is configured at all', async () => {
        const empty = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-none-'));
        cleanups.push(() => fs.rmSync(empty, { recursive: true, force: true }));
        const image = path.join(empty, 'shot.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        vi.stubEnv('PATH', empty);

        await expect(analyzeImage({ input: image, config: {}, timeoutMs: 5_000 })).rejects.toThrow(
            /No vision provider is set up/,
        );
    }, 20_000);
});

describe('the retired endpoint binding reaches the named provider (#42)', () => {
    it('refuses instead of dropping that provider as unconfigured', async () => {
        // Without this the missing baseUrl reads as "not set up", the named
        // provider is filtered out of the chain, and the person who exported
        // the variable never learns why their engine stopped being chosen.
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-retired-'));
        const image = path.join(dir, 'x.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        const before = process.env.OPENAI_BASE_URL;
        process.env.OPENAI_BASE_URL = 'https://gateway.example/v1';
        try {
            await expect(
                analyzeImage({
                    input: image,
                    timeoutMs: 5000,
                    config: { provider: 'openai', providers: { openai: { apiKey: 'k' } } },
                }),
            ).rejects.toThrow(/OPENAI_BASE_URL.*one place/s);
        } finally {
            if (before === undefined) delete process.env.OPENAI_BASE_URL;
            else process.env.OPENAI_BASE_URL = before;
            fs.rmSync(dir, { recursive: true, force: true });
        }
    });

    it('says nothing when the variable belongs to a provider this run never names', async () => {
        // Exporting ANTHROPIC_BASE_URL for Claude Code is ordinary and has
        // nothing to do with a run that names another engine. The named
        // provider is the only one checked, so this one gets past the guard
        // and fails later for its own reason.
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-retired-'));
        const image = path.join(dir, 'x.png');
        fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        const before = process.env.ANTHROPIC_BASE_URL;
        process.env.ANTHROPIC_BASE_URL = 'https://gateway.example/v1';
        try {
            await analyzeImage({
                input: image,
                timeoutMs: 1000,
                config: { provider: 'gemini-api', providers: { 'gemini-api': { apiKey: 'k' } } },
            });
            throw new Error('expected the run to fail on its own terms');
        } catch (error) {
            expect((error as Error).message).not.toMatch(/one place/);
        } finally {
            if (before === undefined) delete process.env.ANTHROPIC_BASE_URL;
            else process.env.ANTHROPIC_BASE_URL = before;
            fs.rmSync(dir, { recursive: true, force: true });
        }
    }, 30_000);
});

describe('a throwaway directory never costs the answer (#50)', () => {
    // On Windows the isolated directory is the provider's cwd, and a cwd
    // cannot be deleted while a process still holds it. kimi lingers there
    // writing its session state, so rmSync threw EPERM out of the `finally`
    // and replaced a successful 45-second read with a failed attempt. The
    // reproduction here is the POSIX equivalent: the provider makes its own
    // working directory unwritable on the way out, so the recursive remove
    // genuinely fails instead of being mocked into failing.
    const VALID = {
        summary: 'ok',
        ocr: { full_text: '', lines: [] },
        layout: { regions: [] },
        semantics: { scene: '', entities: [] },
        visual: {},
        uncertainty: [],
    };

    it.skipIf(process.platform === 'win32')(
        'returns the result when the directory cannot be removed',
        async () => {
            const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-cleanup-'));
            const bin = path.join(dir, 'fake-agy');
            const envelope = JSON.stringify({ status: 'SUCCESS', structured_output: VALID });
            fs.writeFileSync(bin, `#!/bin/sh\necho '${envelope}'\nchmod 500 .\nexit 0\n`, {
                mode: 0o755,
            });
            const image = path.join(dir, 'x.png');
            fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));

            try {
                const result = await analyzeImage({
                    input: image,
                    providerBin: bin,
                    timeoutMs: 20_000,
                    config: {},
                });
                // The read succeeded. A temp directory nobody can delete is
                // not a reason to throw the answer away.
                expect((result.result as { summary: string }).summary).toBe('ok');
            } finally {
                // The fake provider left its own cwd at 0500, which is the
                // whole point, so this test cleans up what the runtime is now
                // allowed to give up on.
                for (const leftover of fs.readdirSync(os.tmpdir())) {
                    if (!leftover.startsWith('modlens-work-')) continue;
                    const full = path.join(os.tmpdir(), leftover);
                    try {
                        fs.chmodSync(full, 0o700);
                        fs.rmSync(full, { recursive: true, force: true });
                    } catch {
                        // Another run's directory, or already gone.
                    }
                }
                fs.rmSync(dir, { recursive: true, force: true });
            }
        },
        30_000,
    );
});

describe('an isolation that fails to set up leaves nothing behind', () => {
    it.skipIf(onWindows)(
        'removes the fresh workdir when the image cannot be copied in',
        async () => {
            // The run's finally only cleans directories that were returned, so a
            // copy failure between mkdtemp and the return used to leak one
            // directory per failover attempt.
            const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-leak-'));
            const image = path.join(dir, 'x.png');
            fs.writeFileSync(image, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
            fs.chmodSync(image, 0o000);
            const before = fs
                .readdirSync(os.tmpdir())
                .filter((name) => name.startsWith('modlens-work-')).length;

            await expect(
                analyzeImage({
                    input: image,
                    providerBin: '/bin/true',
                    timeoutMs: 5_000,
                    config: {},
                }),
            ).rejects.toThrow();
            // The removal is awaited inside the catch before the throw travels,
            // so the count is stable by the time the rejection lands.
            const after = fs
                .readdirSync(os.tmpdir())
                .filter((name) => name.startsWith('modlens-work-')).length;

            expect(after).toBe(before);
            fs.chmodSync(image, 0o600);
            fs.rmSync(dir, { recursive: true, force: true });
        },
    );
});

describe('cleaning up a throwaway directory never aborts the process (#58)', () => {
    // On Node 24.0.0 through 24.13.0, fs.rmSync reaches a C++ path that aborts
    // the process outright (0xC0000409) instead of throwing, when the top-level
    // path handed to it holds non-ASCII characters (nodejs/node#58759, fixed in
    // 24.13.1). The directory removed here is created under os.tmpdir(), so any
    // Windows machine whose temp path or one of its ancestors is non-ASCII
    // walks into it. An abort cannot be caught, so the defence is not to reach
    // that binding at all, which is what the first test pins down. Nothing here
    // uses rmSync, including the fixtures: on an affected Node the setup would
    // be as capable of aborting the run as the code under test.

    it('asks rimraf for the removal rather than the binding that aborts', async () => {
        // The only assertion that can distinguish the two implementations off
        // Windows or on a patched Node, and the one that stops a later edit
        // back to the sync form from passing a green suite to a user.
        const root = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-spy-'));
        const rm = vi.spyOn(fs.promises, 'rm');

        try {
            await removeWorkdir(root);

            expect(rm).toHaveBeenCalledWith(root, {
                recursive: true,
                force: true,
                maxRetries: 1,
                retryDelay: 500,
            });
        } finally {
            rm.mockRestore();
            await fs.promises.rm(root, { recursive: true, force: true });
        }
    });

    it('removes a directory whose path holds non-ASCII characters', async () => {
        const root = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-i18n-'));
        // The upstream reproduction's own characters.
        const workdir = path.join(root, '速_dir');
        fs.mkdirSync(workdir);
        fs.writeFileSync(path.join(workdir, '思.png'), 'bytes');

        await removeWorkdir(workdir);

        expect(fs.existsSync(workdir)).toBe(false);
        await fs.promises.rm(root, { recursive: true, force: true });
    });

    it('resolves rather than throwing when the directory is already gone', async () => {
        const root = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-gone-'));
        await fs.promises.rm(root, { recursive: true, force: true });

        await expect(removeWorkdir(root)).resolves.toBeUndefined();
    });

    it.skipIf(onWindows)('swallows a removal that genuinely cannot be done', async () => {
        const root = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-held-'));
        const workdir = path.join(root, 'inner');
        fs.mkdirSync(workdir);
        fs.writeFileSync(path.join(workdir, 'file.txt'), 'x');
        // An unwritable parent makes the removal fail for real rather than by
        // mock. It fails as EACCES, which rimraf does not retry, so this covers
        // the promise that a failure never costs the answer (#50) and not the
        // 500ms retry: that path needs the EPERM only Windows produces here.
        fs.chmodSync(root, 0o500);

        try {
            await expect(removeWorkdir(workdir)).resolves.toBeUndefined();
            expect(fs.existsSync(workdir)).toBe(true);
        } finally {
            fs.chmodSync(root, 0o700);
            await fs.promises.rm(root, { recursive: true, force: true });
        }
    });
});

describe('per-provider API key rotation', () => {
    const CONTRACT_RESULT = {
        summary: 'ok',
        ocr: { full_text: '', lines: [] },
        layout: { regions: [] },
        semantics: { scene: '', entities: [] },
        visual: {},
        uncertainty: [],
    };

    let image: string;
    const dirs: string[] = [];

    const geminiOk = () =>
        new Response(
            JSON.stringify({
                candidates: [{ content: { parts: [{ text: JSON.stringify(CONTRACT_RESULT) }] } }],
                usageMetadata: { totalTokenCount: 9 },
            }),
            { status: 200 },
        );

    function bearerKey(init: RequestInit | undefined): string {
        const headers = init?.headers;
        let auth = '';
        if (headers instanceof Headers) {
            auth = headers.get('Authorization') ?? headers.get('authorization') ?? '';
        } else if (headers && typeof headers === 'object' && !Array.isArray(headers)) {
            const rec = headers as Record<string, string>;
            auth = rec.Authorization ?? rec.authorization ?? '';
        }
        return auth.replace(/^Bearer\s+/i, '');
    }

    function googKey(init: RequestInit | undefined): string {
        const headers = init?.headers;
        if (headers instanceof Headers) {
            return headers.get('x-goog-api-key') ?? '';
        }
        if (headers && typeof headers === 'object' && !Array.isArray(headers)) {
            return (headers as Record<string, string>)['x-goog-api-key'] ?? '';
        }
        return '';
    }

    afterEach(() => {
        vi.unstubAllGlobals();
        while (dirs.length > 0) {
            fs.rmSync(dirs.pop() as string, { recursive: true, force: true });
        }
    });

    function tmpImage(): string {
        const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-rot-'));
        dirs.push(dir);
        const file = path.join(dir, 'shot.png');
        fs.writeFileSync(file, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        image = file;
        return file;
    }

    it.each([401, 403, 429])(
        'tries comma-separated keys in order after a key-related HTTP %i failure',
        async (status) => {
            tmpImage();
            const sentKeys: string[] = [];
            vi.stubGlobal(
                'fetch',
                vi.fn(async (_url: string, init: RequestInit) => {
                    sentKeys.push(googKey(init));
                    if (sentKeys.length === 1) {
                        return new Response('invalid API key', { status });
                    }
                    return geminiOk();
                }),
            );

            const result = await analyzeImage({
                input: image,
                provider: 'gemini-api',
                config: { providers: { 'gemini-api': { apiKey: ' first-key, ,second-key ' } } },
                timeoutMs: 20_000,
            });

            expect(sentKeys).toEqual(['first-key', 'second-key']);
            expect(result.meta.attempts).toMatchObject([
                { provider: 'gemini-api', keyIndex: 0, ok: false },
                { provider: 'gemini-api', keyIndex: 1, ok: true },
            ]);
            expect(result.meta.warnings.join(' ')).toContain('Rotated to gemini-api API key 2');
            expect(result.meta.warnings.join(' ')).not.toContain('Failed over to gemini-api');
        },
    );

    it('still rotates when the 401 body stream throws', async () => {
        tmpImage();
        const sentKeys: string[] = [];
        vi.stubGlobal(
            'fetch',
            vi.fn(async (_url: string, init: RequestInit) => {
                sentKeys.push(googKey(init));
                return {
                    ok: false,
                    status: 401,
                    text: async () => {
                        throw new Error('stream closed');
                    },
                };
            }),
        );

        await expect(
            analyzeImage({
                input: image,
                provider: 'gemini-api',
                config: {
                    providers: { 'gemini-api': { apiKey: 'first-key-aaaa,second-key-bbbb' } },
                },
                timeoutMs: 20_000,
            }),
        ).rejects.toBeTruthy();
        expect(sentKeys).toEqual(['first-key-aaaa', 'second-key-bbbb']);
    });

    it('rotates and cools a 402 whose quota flag sits past the 300-char display clip', async () => {
        tmpImage();
        const p = path.join(
            fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-late-quota-')),
            'state.json',
        );
        dirs.push(path.dirname(p));
        const now = new Date('2026-08-06T00:00:00.000Z');
        const lateQuota = `${'x'.repeat(350)} insufficient balance`;
        const sentKeys: string[] = [];
        const openaiOk = () =>
            new Response(
                JSON.stringify({
                    choices: [{ message: { content: JSON.stringify(CONTRACT_RESULT) } }],
                }),
                { status: 200 },
            );
        vi.stubGlobal(
            'fetch',
            vi.fn(async (_url: string, init: RequestInit) => {
                sentKeys.push(bearerKey(init));
                if (sentKeys.length === 1) {
                    return new Response(lateQuota, { status: 402 });
                }
                return openaiOk();
            }),
        );
        const controller = buildCooldownController({}, { now, statePath: p });

        const result = await analyzeImage({
            input: image,
            provider: 'openai',
            config: {
                providers: {
                    openai: {
                        apiKey: 'first-key-aaaa,second-key-bbbb',
                        baseUrl: 'https://gw.example.com/v1',
                        model: 'vision-model',
                    },
                },
            },
            timeoutMs: 20_000,
            cooldown: controller,
        });

        expect(sentKeys).toEqual(['first-key-aaaa', 'second-key-bbbb']);
        expect(result.meta.attempts[0]).toMatchObject({
            provider: 'openai',
            keyIndex: 0,
            ok: false,
        });
        expect(result.meta.attempts[0].error).not.toContain('insufficient balance');
        expect(result.meta.attempts[0].error?.length).toBeLessThanOrEqual(300);
        expect(result.meta.warnings.join(' ')).toContain('Rotated to openai API key 2');
        const entry = loadCooldownState(p).engineCooldowns[cooldownStateKey('openai', 0)];
        expect(entry).toBeDefined();
        expect(Date.parse(entry.until) - now.getTime()).toBe(DEFAULT_COOLDOWN_MS);
    });

    it('does not try another key after a network failure', async () => {
        tmpImage();
        const fetchMock = vi.fn(async () => {
            throw new Error('network unavailable');
        });
        vi.stubGlobal('fetch', fetchMock);

        await expect(
            analyzeImage({
                input: image,
                provider: 'gemini-api',
                config: { providers: { 'gemini-api': { apiKey: 'first-key,second-key' } } },
                timeoutMs: 20_000,
            }),
        ).rejects.toThrow(/network unavailable/);
        expect(fetchMock).toHaveBeenCalledTimes(1);
    });

    it('does not try another key after a 5xx response, even when its body mentions quota', async () => {
        tmpImage();
        const fetchMock = vi.fn(
            async () => new Response('quota service temporarily unavailable', { status: 503 }),
        );
        vi.stubGlobal('fetch', fetchMock);

        await expect(
            analyzeImage({
                input: image,
                provider: 'gemini-api',
                config: { providers: { 'gemini-api': { apiKey: 'first-key,second-key' } } },
                timeoutMs: 20_000,
            }),
        ).rejects.toThrow(/Gemini API error 503/);
        expect(fetchMock).toHaveBeenCalledTimes(1);
    });

    it('does not record cooldown for a 503 whose body mentions quota', async () => {
        tmpImage();
        const p = path.join(
            fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-503-state-')),
            'state.json',
        );
        dirs.push(path.dirname(p));
        const now = new Date('2026-08-06T00:00:00.000Z');
        vi.stubGlobal(
            'fetch',
            vi.fn(
                async () => new Response('quota service temporarily unavailable', { status: 503 }),
            ),
        );
        const controller = buildCooldownController({}, { now, statePath: p });

        await expect(
            analyzeImage({
                input: image,
                provider: 'gemini-api',
                config: { providers: { 'gemini-api': { apiKey: 'only-key-aaaa' } } },
                timeoutMs: 20_000,
                cooldown: controller,
            }),
        ).rejects.toThrow(/Gemini API error 503/);
        expect(fs.existsSync(p)).toBe(false);
        expect(controller?.state.engineCooldowns).toEqual({});
    });

    it('records a 24-hour cooldown for HTTP 432 even when the message has no letters HTTP', async () => {
        tmpImage();
        const p = path.join(
            fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-432-state-')),
            'state.json',
        );
        dirs.push(path.dirname(p));
        const now = new Date('2026-08-06T00:00:00.000Z');
        vi.stubGlobal(
            'fetch',
            vi.fn(async () => new Response('plan cap', { status: 432 })),
        );
        const controller = buildCooldownController({}, { now, statePath: p });

        await expect(
            analyzeImage({
                input: image,
                provider: 'gemini-api',
                config: { providers: { 'gemini-api': { apiKey: 'only-key-aaaa' } } },
                timeoutMs: 20_000,
                cooldown: controller,
            }),
        ).rejects.toThrow(/Gemini API error 432/);
        const entry = loadCooldownState(p).engineCooldowns[cooldownStateKey('gemini-api', 0)];
        expect(entry).toBeDefined();
        expect(Date.parse(entry.until) - now.getTime()).toBe(MONTHLY_COOLDOWN_MS);
    });

    it('does not treat unrelated 4xx wording as a quota failure', async () => {
        tmpImage();
        const fetchMock = vi.fn(
            async () => new Response('requested result count is out of range', { status: 400 }),
        );
        vi.stubGlobal('fetch', fetchMock);

        await expect(
            analyzeImage({
                input: image,
                provider: 'gemini-api',
                config: { providers: { 'gemini-api': { apiKey: 'first-key,second-key' } } },
                timeoutMs: 20_000,
            }),
        ).rejects.toThrow(/Gemini API error 400/);
        expect(fetchMock).toHaveBeenCalledTimes(1);
    });

    it('does not leak a sibling key through the rethrown lastError', async () => {
        tmpImage();
        vi.stubGlobal(
            'fetch',
            vi.fn(async () => new Response('rejected second-key-bbbb as invalid', { status: 401 })),
        );

        const error = await analyzeImage({
            input: image,
            provider: 'gemini-api',
            config: {
                providers: { 'gemini-api': { apiKey: 'first-key-aaaa,second-key-bbbb' } },
            },
            timeoutMs: 20_000,
        }).catch((caught: unknown) => caught);

        expect(error).toBeInstanceOf(ApiKeyFailureError);
        expect((error as Error).message).not.toContain('second-key-bbbb');
        expect((error as Error).message).not.toContain('first-key-aaaa');
    });

    it('does not leak a sibling key into cooldown state or doctor output', async () => {
        tmpImage();
        const p = path.join(
            fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-leak-state-')),
            'state.json',
        );
        dirs.push(path.dirname(p));
        const now = new Date('2026-08-06T00:00:00.000Z');
        vi.stubGlobal(
            'fetch',
            vi.fn(
                async () =>
                    new Response('insufficient balance for second-key-bbbb', { status: 402 }),
            ),
        );
        const controller = buildCooldownController({}, { now, statePath: p });

        const error = await analyzeImage({
            input: image,
            provider: 'gemini-api',
            config: {
                providers: { 'gemini-api': { apiKey: 'first-key-aaaa,second-key-bbbb' } },
            },
            timeoutMs: 20_000,
            cooldown: controller,
        }).catch((caught: unknown) => caught);

        expect(error).toBeInstanceOf(ApiKeyFailureError);
        expect((error as Error).message).not.toContain('second-key-bbbb');
        const persisted = fs.readFileSync(p, 'utf-8');
        expect(persisted).not.toContain('second-key-bbbb');
        expect(persisted).not.toContain('first-key-aaaa');

        const { buildDoctorReport, renderDoctorReport } = await import('./doctor.ts');
        const report = buildDoctorReport({
            config: {
                providers: { 'gemini-api': { apiKey: 'first-key-aaaa,second-key-bbbb' } },
            },
            env: {},
            statePath: p,
            now,
        });
        expect(JSON.stringify(report.cooldown)).not.toContain('second-key-bbbb');
        expect(renderDoctorReport(report)).not.toContain('second-key-bbbb');
    });

    it('records quota cooldown only for the key that failed', async () => {
        tmpImage();
        const p = path.join(
            fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-key-state-')),
            'state.json',
        );
        dirs.push(path.dirname(p));
        const now = new Date('2026-08-06T00:00:00.000Z');
        let call = 0;
        vi.stubGlobal(
            'fetch',
            vi.fn(async () => {
                call += 1;
                if (call === 1) {
                    return new Response('insufficient balance for first-key and second-key', {
                        status: 402,
                    });
                }
                return geminiOk();
            }),
        );
        const controller = buildCooldownController({}, { now, statePath: p });

        await analyzeImage({
            input: image,
            provider: 'gemini-api',
            config: { providers: { 'gemini-api': { apiKey: 'first-key,second-key' } } },
            timeoutMs: 20_000,
            cooldown: controller,
        });

        const state = loadCooldownState(p);
        expect(state.engineCooldowns[cooldownStateKey('gemini-api', 0)]).toBeDefined();
        expect(state.engineCooldowns[cooldownStateKey('gemini-api', 1)]).toBeUndefined();
        expect(state.engineCooldowns['gemini-api']).toBeUndefined();
        const persisted = fs.readFileSync(p, 'utf-8');
        expect(persisted).not.toContain('first-key');
        expect(persisted).not.toContain('second-key');
    });

    it('tries healthy keys before a cooling key in the same provider', async () => {
        tmpImage();
        const p = path.join(
            fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-key-order-')),
            'state.json',
        );
        dirs.push(path.dirname(p));
        const now = new Date('2026-08-06T00:00:00.000Z');
        recordQuotaCooldown(
            emptyCooldownState(),
            'gemini-api',
            new ApiKeyFailureError('out of credits', { quotaCooldown: 'default' }),
            now,
            p,
            undefined,
            0,
        );
        const sentKeys: string[] = [];
        vi.stubGlobal(
            'fetch',
            vi.fn(async (_url: string, init: RequestInit) => {
                sentKeys.push(googKey(init));
                return geminiOk();
            }),
        );

        const result = await analyzeImage({
            input: image,
            provider: 'gemini-api',
            config: { providers: { 'gemini-api': { apiKey: 'first-key,second-key' } } },
            timeoutMs: 20_000,
            cooldown: buildCooldownController({}, { now, statePath: p }),
        });

        expect(sentKeys).toEqual(['second-key']);
        expect(result.meta.attempts).toMatchObject([{ keyIndex: 1, ok: true }]);
        expect(
            loadCooldownState(p).engineCooldowns[cooldownStateKey('gemini-api', 0)],
        ).toBeDefined();
    });

    it('omits keyIndex on a single-key success so the JSON stays compatible', async () => {
        tmpImage();
        vi.stubGlobal(
            'fetch',
            vi.fn(async () => geminiOk()),
        );
        const result = await analyzeImage({
            input: image,
            provider: 'gemini-api',
            config: { providers: { 'gemini-api': { apiKey: 'only-key' } } },
            timeoutMs: 20_000,
        });
        expect(result.meta.attempts).toHaveLength(1);
        expect(result.meta.attempts[0].ok).toBe(true);
        expect(result.meta.attempts[0].keyIndex).toBeUndefined();
        expect(JSON.stringify(result.meta.attempts[0])).not.toContain('keyIndex');
    });

    it('fails over from a getter-only AbortError instead of crashing on error.message (issue #85)', async () => {
        tmpImage();
        const openaiOk = () =>
            new Response(
                JSON.stringify({
                    choices: [{ message: { content: JSON.stringify(CONTRACT_RESULT) } }],
                }),
                { status: 200 },
            );

        // Throw a real AbortError. A parse or schema failure would pass today
        // without hitting the getter-only assignment (issue #85).
        vi.stubGlobal(
            'fetch',
            vi.fn(async (url: string) => {
                const href = String(url);
                if (href.includes('gw.example.com') || href.includes('/chat/completions')) {
                    return openaiOk();
                }
                throw new DOMException('The operation was aborted.', 'AbortError');
            }),
        );

        const result = await analyzeImage({
            input: image,
            config: {
                providers: {
                    'gemini-api': { apiKey: 'gemini-key-aaaa' },
                    openai: {
                        apiKey: 'openai-key-aaaa',
                        baseUrl: 'https://gw.example.com/v1',
                        model: 'vision-model',
                    },
                },
            },
            timeoutMs: 20_000,
        });

        expect(result.provider).toBe('openai');
        expect(result.meta.attempts[0]).toMatchObject({ provider: 'gemini-api', ok: false });
        expect(result.meta.attempts[0].error).not.toContain('Cannot set property message');
    });
});
