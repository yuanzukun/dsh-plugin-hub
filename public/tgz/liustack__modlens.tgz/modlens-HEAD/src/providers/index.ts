import type { ProviderSettings } from '../config.ts';
import { anthropicApiProvider } from './anthropicApi.ts';
import { antigravityCliProvider } from './antigravity.ts';
import { claudeCliProvider } from './claudeCli.ts';
import { geminiApiProvider } from './geminiApi.ts';
import { kimiCliProvider } from './kimiCli.ts';
import { openaiCompatProvider } from './openaiCompat.ts';

export interface ProviderInvocation {
    command: string;
    args: string[];
    cwd: string;
    /** Extra variables for the child, merged over the inherited environment. */
    env?: Record<string, string>;
}

export interface BuildProviderInvocationOptions {
    imageSource: string;
    imageKind: 'local' | 'remote';
    model?: string;
    extraPrompt?: string;
    providerBin?: string;
    workdir?: string;
    timeoutMs: number;
    settings?: ProviderSettings;
    /** Every configured key for this provider, so sibling keys can be redacted. */
    apiKeySecrets?: readonly string[];
}

export interface ProviderParsedOutput {
    result: unknown;
    meta: {
        conversationId: string | null;
        durationSeconds: number | null;
        usage: unknown | null;
    };
}

/** Everything a provider needs to explain a non-zero exit. */
export interface ProviderFailureContext {
    stdout: string;
    stderr: string;
    code: number | null;
    /** When this run started, so log evidence can be scoped to it. */
    startedAt?: number;
}

export interface VisionProvider {
    name: string;
    defaultModel: string;
    // Subprocess providers implement buildInvocation + parseOutput.
    // In-process API providers implement execute instead.
    buildInvocation?: (options: BuildProviderInvocationOptions) => ProviderInvocation;
    parseOutput?: (stdout: string) => ProviderParsedOutput;
    execute?: (options: BuildProviderInvocationOptions) => Promise<ProviderParsedOutput>;
    /** Turn a non-zero exit into an actionable message, or null to use the default. */
    describeFailure?: (context: ProviderFailureContext) => string | Error | null;
    /** True when the CLI enforces its own deadline, so we add a kill backstop. */
    hasInternalTimeout?: boolean;
    /**
     * True for subprocess agents that read a path with broad permissions: the
     * analyzer runs them in a throwaway directory holding only the one image, so
     * a prompt injection in the image cannot steer them into sibling files. An
     * explicit --workdir opts out.
     */
    isolateWorkdir?: boolean;
    /**
     * Set on auto-mode routes borrowed from another harness. The analyzer
     * surfaces it as a warning when this route answers, so spending that
     * account's quota is never silent.
     */
    reuseNote?: string;
}

const PROVIDERS: Record<string, VisionProvider> = {
    'antigravity-cli': antigravityCliProvider,
    antigravity: antigravityCliProvider,
    agy: antigravityCliProvider,
    'gemini-api': geminiApiProvider,
    gemini: geminiApiProvider,
    openai: openaiCompatProvider,
    'openai-compat': openaiCompatProvider,
    anthropic: anthropicApiProvider,
    claude: anthropicApiProvider,
    'claude-cli': claudeCliProvider,
    'claude-code': claudeCliProvider,
    'kimi-cli': kimiCliProvider,
    kimi: kimiCliProvider,
    'kimi-code': kimiCliProvider,
};

export function resolveProvider(providerName = 'antigravity-cli'): VisionProvider {
    const normalized = providerName.trim().toLowerCase();
    // Own properties only: a bare lookup walks the prototype chain, so the
    // name "constructor" came back as Object's constructor, truthy, and
    // passed for a provider all the way into config writes.
    const provider = Object.hasOwn(PROVIDERS, normalized) ? PROVIDERS[normalized] : undefined;

    if (!provider) {
        throw new Error(
            `Unsupported provider: ${providerName}. Available: ${listProviders().join(', ')}`,
        );
    }

    return provider;
}

/**
 * Every accepted spelling mapped to the canonical provider name. Exported so
 * the config layer reads settings saved under an alias without keeping its own
 * copy of this table, which drifted the moment it was duplicated.
 */
export function providerAliases(): Record<string, string> {
    return Object.fromEntries(
        Object.entries(PROVIDERS).map(([alias, provider]) => [alias, provider.name]),
    );
}

export function listProviders(): string[] {
    return [...new Set(Object.values(PROVIDERS).map((provider) => provider.name))];
}
