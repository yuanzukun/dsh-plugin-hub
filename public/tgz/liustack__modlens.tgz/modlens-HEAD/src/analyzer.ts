import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { discoverAuto } from './auto/discover.ts';
import { type AutoRouteOptions, reuseProviders } from './auto/routes.ts';
import {
    assertNoRetiredEndpointBinding,
    assertReadableConfig,
    loadConfigFile,
    type ModlensConfig,
    type ProviderSettings,
    resolveProviderSettings,
} from './config.ts';
import {
    type CooldownController,
    type CooldownView,
    coolingEngineEntry,
    coolingEntry,
} from './cooldown.ts';
import { providerChain } from './providers/availability.ts';
import {
    type ProviderFailureContext,
    type ProviderInvocation,
    type ProviderParsedOutput,
    resolveProvider,
    type VisionProvider,
} from './providers/index.ts';
import { missingSchemaFields, normalizeVisionResult } from './schema.ts';
import { isApiKeyFailure, splitApiKeys } from './util/apiKeys.ts';
import { setErrorMessage } from './util/error.ts';
import { redactSecrets } from './util/redact.ts';
import { spawnHidden } from './util/spawnHidden.ts';
import { resolveSpawnPlan } from './util/winExec.ts';

export interface AnalyzeOptions {
    input: string;
    provider?: string;
    model?: string;
    prompt?: string;
    timeoutMs?: number;
    providerBin?: string;
    workdir?: string;
    /** --extra-body: replaces the configured extraBody for this run. */
    extraBody?: Record<string, unknown>;
    config?: ModlensConfig;
    /** Auto-mode discovery overrides (home, env, discovery), mainly for tests. */
    autoOptions?: AutoRouteOptions;
    /**
     * Quota cooldown for this run. Absent means the cooldown is off (the
     * switch, or a caller that does not use it), and routing is exactly as it
     * was before cooldowns existed.
     */
    cooldown?: CooldownController;
}

export interface AnalyzeAttempt {
    provider: string;
    /** Zero-based configured key index. Present only when a provider has multiple keys. */
    keyIndex?: number;
    ok: boolean;
    durationSeconds: number;
    error?: string;
}

export interface AnalyzeResult {
    image: string;
    provider: string;
    result: unknown;
    meta: {
        generatedAt: string;
        /** null when the provider ran a model it never named (kimi-cli). */
        model: string | null;
        conversationId: string | null;
        durationSeconds: number | null;
        usage: unknown | null;
        /** Every provider tried this run, in order, successes and failures. */
        attempts: AnalyzeAttempt[];
        /** Routing notices: failovers and what they mean for the answer. */
        warnings: string[];
    };
}

interface CommandResult {
    stdout: string;
    stderr: string;
}

interface ResolvedInput {
    source: string;
    kind: 'local' | 'remote';
}

const DEFAULT_TIMEOUT_MS = 180_000;
// Give the provider's own timeout a chance to fire first; SIGTERM is the backstop.
const KILL_GRACE_MS = 30_000;
// After the provider exits, how long to keep draining stdout before giving up
// on the pipe closing. Reset whenever more output arrives.
const DRAIN_GRACE_MS = 500;
// How long a killed child gets before SIGKILL.
const SIGKILL_GRACE_MS = 2_000;

export async function analyzeImage(options: AnalyzeOptions): Promise<AnalyzeResult> {
    const resolvedInput = resolveInput(options.input);
    if (resolvedInput.kind === 'local') {
        validateInputFile(resolvedInput.source);
    }

    const config = options.config ?? loadConfigFile();
    // The config file is hand-editable input; a wrong shape fails here in a
    // sentence instead of as a raw TypeError deep inside a provider.
    assertReadableConfig(config);
    // An explicit -p pins exactly one provider with no fallback (like
    // modsearch's -e). The providerBin test double pins the agent the same
    // way. Otherwise the failover chain: every provider that is set up on
    // this machine plus the borrowed routes the user granted, merged by
    // region so a borrowed engine gets speed-class placement, not priority.
    const controller = options.cooldown;
    const chain = options.provider
        ? [resolveProvider(options.provider)]
        : options.providerBin
          ? [resolveProvider('antigravity-cli')]
          : composeChain(resolvedInput.kind, config, options.autoOptions, controller);
    // A provider the user named carries the retired-binding check before the
    // chain is filtered. Otherwise the missing baseUrl reads as "not set up",
    // that provider is quietly dropped, and the person who exported the
    // variable never learns why their engine stopped being chosen. Only the
    // named one: exporting ANTHROPIC_BASE_URL for Claude Code is common and
    // has nothing to do with a run that never touches the anthropic route.
    const named = options.provider ?? config.provider?.trim();
    if (named) {
        try {
            const canonical = resolveProvider(named).name;
            assertNoRetiredEndpointBinding(canonical, resolveProviderSettings(canonical, config));
        } catch (error) {
            if (
                error instanceof Error &&
                error.message.includes('takes its settings from one place')
            ) {
                throw error;
            }
            // An unknown name is not this check's business.
        }
    }

    if (chain.length === 0) {
        throw new Error(
            'No vision provider is set up on this machine. Install Antigravity CLI (curl -fsSL https://antigravity.google/cli/install.sh | bash, then run agy once to sign in), or configure a key: modlens config set gemini-api.apiKey <key>. Run modlens doctor for the full picture.' +
                reuseHint(config, options.autoOptions),
        );
    }

    const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const attempts: AnalyzeAttempt[] = [];
    const warnings: string[] = [];
    if (controller && !options.provider && !options.providerBin) {
        for (const provider of chain) {
            const keyCount = splitApiKeys(
                resolveProviderSettings(provider.name, config).apiKey,
            ).length;
            const entry = coolingEngineEntry(
                controller.state,
                provider.name,
                keyCount,
                controller.now,
            );
            if (entry) {
                warnings.push(
                    `The ${provider.name} provider is cooling until ${entry.until}, so it moves to the back of the fallback chain.`,
                );
            }
        }
    }
    let lastError: unknown;

    for (const provider of chain) {
        const configured = resolveProviderSettings(provider.name, config);
        const settingsBase = options.extraBody
            ? { ...configured, extraBody: options.extraBody }
            : configured;
        // An explicit -m names one provider's model, so it applies to every
        // key of the first provider; a failover provider runs its own default.
        const firstProvider = attempts.every((attempt) => attempt.provider === provider.name);
        const model =
            (firstProvider ? options.model : undefined) ||
            settingsBase.model ||
            provider.defaultModel;
        const apiKeys = splitApiKeys(settingsBase.apiKey);
        const configuredKeyRuns =
            apiKeys.length > 0
                ? apiKeys.map((apiKey, keyIndex) => ({ apiKey, keyIndex }))
                : [
                      {
                          apiKey: undefined as string | undefined,
                          keyIndex: undefined as number | undefined,
                      },
                  ];
        const keyRuns = controller
            ? [
                  ...configuredKeyRuns.filter(
                      (run) =>
                          run.keyIndex === undefined ||
                          !coolingEntry(
                              controller.state,
                              provider.name,
                              controller.now,
                              run.keyIndex,
                          ),
                  ),
                  ...configuredKeyRuns.filter(
                      (run) =>
                          run.keyIndex !== undefined &&
                          coolingEntry(
                              controller.state,
                              provider.name,
                              controller.now,
                              run.keyIndex,
                          ),
                  ),
              ]
            : configuredKeyRuns;

        let parsed: ProviderParsedOutput | undefined;
        let successfulStartedAt = 0;
        let successfulKeyIndex: number | undefined;
        for (let runIndex = 0; runIndex < keyRuns.length; runIndex += 1) {
            const keyRun = keyRuns[runIndex];
            const startedAt = Date.now();
            try {
                parsed = await runProvider(
                    provider,
                    model,
                    options,
                    resolvedInput,
                    timeoutMs,
                    { ...settingsBase, apiKey: keyRun.apiKey },
                    warnings,
                    apiKeys,
                );
                successfulStartedAt = startedAt;
                successfulKeyIndex = keyRun.keyIndex;
                break;
            } catch (error) {
                const message = redactSecrets(
                    error instanceof Error ? error.message : String(error),
                    apiKeys,
                );
                if (error instanceof Error) {
                    setErrorMessage(error, message);
                }
                lastError = error;
                attempts.push({
                    provider: provider.name,
                    ...(apiKeys.length > 1 ? { keyIndex: keyRun.keyIndex } : {}),
                    ok: false,
                    durationSeconds: (Date.now() - startedAt) / 1000,
                    error: message.slice(0, 300),
                });
                if (controller) {
                    const entry = controller.record(provider.name, error, keyRun.keyIndex, apiKeys);
                    if (entry) {
                        const keyNote =
                            keyRun.keyIndex === undefined ? '' : ` API key ${keyRun.keyIndex + 1}`;
                        warnings.push(
                            `The ${provider.name} provider${keyNote} hit its quota and is now cooling until ${entry.until}.`,
                        );
                    }
                }
                const hasNextKey = runIndex + 1 < keyRuns.length;
                if (hasNextKey && isApiKeyFailure(error)) {
                    continue;
                }
                break;
            }
        }

        if (!parsed) {
            continue;
        }

        attempts.push({
            provider: provider.name,
            ...(apiKeys.length > 1 ? { keyIndex: successfulKeyIndex } : {}),
            ok: true,
            durationSeconds: (Date.now() - successfulStartedAt) / 1000,
        });
        controller?.clear(provider.name, successfulKeyIndex);
        if (provider.reuseNote) {
            warnings.push(provider.reuseNote);
        }
        warnings.push(...(controller?.warnings ?? []));
        const failed = attempts.filter((attempt) => !attempt.ok);
        if (failed.length > 0) {
            const rotatedWithinProvider =
                failed.every((attempt) => attempt.provider === provider.name) &&
                successfulKeyIndex !== undefined;
            if (rotatedWithinProvider && successfulKeyIndex !== undefined) {
                warnings.push(
                    `Rotated to ${provider.name} API key ${successfulKeyIndex + 1} after: ${failed
                        .map(
                            (attempt) =>
                                `${attempt.provider}${
                                    attempt.keyIndex === undefined
                                        ? ''
                                        : ` (API key ${attempt.keyIndex + 1})`
                                }: ${attempt.error}`,
                        )
                        .join(' | ')}`,
                );
            } else {
                warnings.push(
                    `Failed over to ${provider.name} after: ${failed
                        .map((attempt) => `${attempt.provider} (${attempt.error})`)
                        .join('; ')}.`,
                );
                if (options.model) {
                    warnings.push(
                        `The explicit model applied to ${failed[0].provider} only; ${provider.name} ran its own default.`,
                    );
                }
            }
        }
        return {
            image: resolvedInput.source,
            provider: provider.name,
            result: parsed.result,
            meta: {
                generatedAt: new Date().toISOString(),
                // Empty means the provider ran whatever it was already
                // configured with and never told us which (kimi-cli), so
                // the field says unknown rather than naming nothing.
                model: model === '' ? null : model,
                conversationId: parsed.meta.conversationId,
                durationSeconds: parsed.meta.durationSeconds,
                usage: parsed.meta.usage,
                attempts,
                warnings,
            },
        };
    }

    // A pinned or lone provider keeps its original, actionable error (agy's
    // sign-in guidance, a provider's own fix text). Only a real multi-provider
    // exhaustion gets the aggregate.
    if (chain.length === 1) {
        // A pinned provider keeps its error untouched; a lone auto-assembled
        // provider still deserves the reuse hint, since more vision may exist.
        if (!options.provider && !options.providerBin && lastError instanceof Error) {
            const hint = reuseHint(config, options.autoOptions);
            if (hint) {
                lastError.message += hint;
            }
        }
        throw lastError;
    }
    throw new Error(
        `Every configured vision provider failed for this image. ${attempts
            .map((attempt) => `${attempt.provider}: ${attempt.error}`)
            .join(' | ')}${reuseHint(config, options.autoOptions)}`,
    );
}

const INLINE_REGION = new Set(['gemini-api', 'openai', 'anthropic']);

/**
 * Merge granted borrowed routes into the base chain by region: borrowed keys
 * join the inline region after the user's own, borrowed agents slot in before
 * claude-cli (which spends the Claude subscription and stays last). The base
 * order is preserved, so a `config set provider` preference keeps its place.
 */
export function composeChain(
    kind: 'local' | 'remote',
    config: ModlensConfig,
    autoOptions: AutoRouteOptions | undefined,
    cooldown?: CooldownView,
): VisionProvider[] {
    const chain = [...providerChain(kind, config, autoOptions?.env ?? process.env)];
    const borrowed = reuseProviders(kind, config, autoOptions);
    let preferredName: string | null = null;
    if (config.provider?.trim()) {
        try {
            preferredName = resolveProvider(config.provider.trim()).name;
        } catch {
            preferredName = null;
        }
    }
    if (borrowed.inline.length > 0) {
        const lastInline = chain.map((p) => INLINE_REGION.has(p.name)).lastIndexOf(true);
        // With no inline members in the base chain, reused keys still queue
        // behind a provider the user explicitly preferred to the front, but
        // only for local images: for remote URLs inline-first is a security
        // boundary (only the inline download path runs the SSRF guards), so
        // even a preferred agent stays behind reused keys there.
        const insertAt =
            lastInline >= 0
                ? lastInline + 1
                : kind === 'local' && preferredName === chain[0]?.name
                  ? 1
                  : 0;
        chain.splice(insertAt, 0, ...borrowed.inline);
    }
    if (borrowed.agents.length > 0) {
        // claude-cli keeps its natural last place, but when the user preferred
        // it to the front (or it is the whole chain) nothing cuts ahead of it.
        const last = chain[chain.length - 1];
        const beforeClaude = last?.name === 'claude-cli' && preferredName !== 'claude-cli';
        chain.splice(beforeClaude ? chain.length - 1 : chain.length, 0, ...borrowed.agents);
    }
    if (!cooldown) {
        return chain;
    }
    return reorderByCooldown(chain, cooldown, config, autoOptions?.env ?? process.env);
}

/**
 * After borrowed routes have joined, move a fully-cooling provider to the
 * back of its own region (inline vs agent). A flat whole-chain partition
 * would let a cooling gemini-api fall behind antigravity-cli, and a remote
 * URL would then be fetched by the agent, skipping the inline SSRF guards.
 */
function reorderByCooldown(
    chain: VisionProvider[],
    cooldown: CooldownView,
    config: ModlensConfig,
    env: NodeJS.ProcessEnv,
): VisionProvider[] {
    const tagged = chain.map((provider) => {
        const keyCount = splitApiKeys(
            resolveProviderSettings(provider.name, config, env).apiKey,
        ).length;
        return {
            provider,
            inline: !provider.isolateWorkdir,
            cooling: Boolean(
                coolingEngineEntry(cooldown.state, provider.name, keyCount, cooldown.now),
            ),
        };
    });
    const healthyThenCooling = (items: typeof tagged) => [
        ...items.filter((item) => !item.cooling),
        ...items.filter((item) => item.cooling),
    ];
    const inline = healthyThenCooling(tagged.filter((item) => item.inline));
    const agents = healthyThenCooling(tagged.filter((item) => !item.inline));
    const lead = tagged[0];
    if (lead && !lead.inline && !lead.cooling) {
        const restAgents = agents.filter((item) => item.provider.name !== lead.provider.name);
        return [
            lead.provider,
            ...inline.map((item) => item.provider),
            ...restAgents.map((item) => item.provider),
        ];
    }
    return [...inline.map((item) => item.provider), ...agents.map((item) => item.provider)];
}

const REUSE_KEY_BY_HARNESS: Record<string, 'codex' | 'opencode' | 'pi' | 'grok'> = {
    codex: 'codex',
    opencode: 'opencode',
    pi: 'pi',
    grok: 'grok',
};

/**
 * When everything failed (or nothing was set up), say so if this machine has
 * borrowable vision the user was never asked about. A hint only: nothing is
 * enabled without an explicit grant.
 */
function reuseHint(config: ModlensConfig, autoOptions: AutoRouteOptions | undefined): string {
    try {
        const grants = config.reuse ?? {};
        const discovery =
            autoOptions?.discovery ??
            discoverAuto({ env: autoOptions?.env, home: autoOptions?.home });
        const unasked: string[] = [];
        const dead: string[] = [];
        for (const probe of discovery.probes) {
            const key = REUSE_KEY_BY_HARNESS[probe.harness];
            if (key === undefined) {
                continue;
            }
            const usable =
                probe.cliFound && probe.visionModels.length > 0 && probe.loggedIn !== false;
            if (grants[key] === undefined && usable) {
                unasked.push(probe.harness);
            } else if (grants[key] === true && !usable) {
                // Granted but currently unusable: signed out, uninstalled, or
                // its vision models went away. Name it instead of pretending
                // the grant never existed.
                dead.push(probe.harness);
            }
        }
        const parts: string[] = [];
        if (unasked.length > 0) {
            parts.push(
                ` Hint: this machine has vision reachable through ${unasked.join(', ')}, which modlens is not yet allowed to reuse. Ask the user, then: modlens config set reuse.<harness> true.`,
            );
        }
        if (dead.length > 0) {
            parts.push(
                ` Note: reuse is granted for ${dead.join(', ')} but it is currently unusable (signed out, uninstalled, or no vision model); check that CLI's login.`,
            );
        }
        return parts.join('');
    } catch {
        return '';
    }
}

/** One provider, one attempt: execute (or spawn), parse, and verify the shape. */
async function runProvider(
    provider: VisionProvider,
    model: string,
    options: AnalyzeOptions,
    resolvedInput: ResolvedInput,
    timeoutMs: number,
    settings: ProviderSettings,
    warnings: string[],
    apiKeySecrets: readonly string[] = [],
): Promise<ProviderParsedOutput> {
    // The passthrough is a request-body field, so the two CLI agents have
    // nowhere to put it. Saying so beats letting the user believe thinking is
    // off when nothing was sent.
    if (settings.extraBody && !provider.execute) {
        warnings.push(
            `${provider.name} is a CLI provider and takes no request body, so extraBody was ignored for this run.`,
        );
    }
    const providerOptions = {
        imageSource: resolvedInput.source,
        imageKind: resolvedInput.kind,
        model,
        extraPrompt: options.prompt,
        providerBin: options.providerBin,
        workdir: options.workdir,
        timeoutMs,
        settings,
        apiKeySecrets,
    };

    let parsed: ProviderParsedOutput;
    if (provider.execute) {
        parsed = await provider.execute(providerOptions);
    } else if (provider.buildInvocation && provider.parseOutput) {
        const buildInvocation = provider.buildInvocation;
        const parseOutput = provider.parseOutput;
        // Run the agent in a throwaway directory holding only this one image, so
        // an injection in the image cannot steer it into siblings of the
        // original file. A remote image has no local file to copy, but the agent
        // still must not run in the caller's directory, so it gets an empty
        // throwaway cwd instead. An explicit --workdir opts out.
        const isolation =
            !options.workdir && provider.isolateWorkdir
                ? resolvedInput.kind === 'local'
                    ? await isolateImage(resolvedInput.source)
                    : emptyWorkdir()
                : null;
        try {
            const invocation = buildInvocation({
                ...providerOptions,
                imageSource: isolation?.imageSource ?? providerOptions.imageSource,
                workdir: isolation?.workdir ?? providerOptions.workdir,
            });
            // The grace exists for engines with their own internal deadline (agy
            // gets --print-timeout). Engines without one must honour the caller's
            // number as given.
            const backstop = provider.hasInternalTimeout ? timeoutMs + KILL_GRACE_MS : timeoutMs;
            const commandResult = await runCommand(
                provider.name,
                invocation,
                backstop,
                provider.describeFailure,
            );
            parsed = parseOutput(commandResult.stdout);
        } finally {
            // Output goes over stdout, so nothing here needs to outlive the run.
            await isolation?.cleanup();
        }
    } else {
        throw new Error(
            `Provider ${provider.name} implements neither execute nor buildInvocation.`,
        );
    }

    // Server-side schema enforcement is uneven across providers, and even the
    // routes that have it can return a shell that only looks right. Verify the
    // shape here so a structurally broken result fails loudly for every
    // provider, and a failover peer gets its turn at a compliant answer.
    // A model with nothing to say for an optional field writes null there,
    // which means the same as leaving it out; dropping it before the check
    // keeps the read alive and keeps null out of what callers receive.
    parsed.result = normalizeVisionResult(parsed.result);
    const missing = missingSchemaFields(parsed.result);
    if (missing.length > 0) {
        throw new Error(
            `${provider.name} returned a result that does not match the vision schema (wrong or missing: ${missing.join(', ')}).`,
        );
    }

    return parsed;
}

export function resolveInput(input: string): ResolvedInput {
    const trimmed = input.trim();
    if (!trimmed) {
        throw new Error('Input path is required.');
    }

    if (isRemoteSource(trimmed)) {
        return { source: trimmed, kind: 'remote' };
    }

    if (/^file:\/\//i.test(trimmed)) {
        return { source: path.resolve(fileURLToPath(trimmed)), kind: 'local' };
    }

    return { source: path.resolve(trimmed), kind: 'local' };
}

function isRemoteSource(value: string): boolean {
    return /^https?:\/\//i.test(value.trim());
}

function validateInputFile(filePath: string): void {
    if (!fs.existsSync(filePath)) {
        throw new Error(`Input image not found: ${filePath}`);
    }

    const stat = fs.statSync(filePath);
    if (!stat.isFile()) {
        throw new Error(`Input is not a file: ${filePath}`);
    }
}

interface IsolatedImage {
    imageSource?: string;
    workdir: string;
    cleanup: () => Promise<void>;
}

/**
 * Remove a throwaway directory without ever failing the run over it.
 *
 * On Windows a directory that is a live process's current directory cannot be
 * deleted, and this directory IS the provider's cwd. A child that lingers for
 * a moment after its output arrives, as kimi does while it writes its session
 * state, leaves that handle held, removal fails with EPERM, and because cleanup
 * runs in a `finally` the error replaced a perfectly good result: the read
 * succeeded, took its full 45 seconds, and was then reported as a failed
 * attempt (issue #50). `force` suppresses ENOENT, never EPERM.
 *
 * Asynchronous `rm`, never `rmSync`: on Node 24.0.0 through 24.13.0 the sync
 * call reaches a C++ path that aborts the process outright (0xC0000409) instead
 * of throwing, when the top-level path handed to it holds non-ASCII characters
 * (nodejs/node#58759, fixed in 24.13.1). This path is built from `os.tmpdir()`,
 * so a Windows machine whose temp directory or any ancestor of it is non-ASCII
 * takes that abort right here, and no `try`/`catch` catches an abort. The async
 * call runs the JS rimraf, which never reaches that binding (issue #58).
 *
 * rimraf's own `maxRetries`/`retryDelay` stand in for the retry this used to
 * do by hand: it waits `retryDelay` and tries once more on EBUSY, EMFILE,
 * ENFILE, ENOTEMPTY and EPERM, which covers the held Windows cwd above. Errors
 * outside that set now fail on the first attempt rather than after a pointless
 * second, and either way removal stays best effort: what is left stays in the
 * system temp directory, which is where a leftover belongs and what the OS
 * already cleans. Losing a temp directory is not worth losing the answer.
 */
export async function removeWorkdir(workdir: string): Promise<void> {
    try {
        await fs.promises.rm(workdir, {
            recursive: true,
            force: true,
            maxRetries: 1,
            retryDelay: 500,
        });
    } catch {
        // Still held. A temp directory is the right thing to leak here.
    }
}

/**
 * Place the input image, and nothing else, into a fresh temp directory the agent
 * runs in. Subprocess providers are handed a path and broad permissions, so text
 * inside the image could otherwise point them at neighbouring files; a directory
 * of one removes that reach.
 */
async function isolateImage(source: string): Promise<IsolatedImage> {
    const workdir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-work-'));
    try {
        const imageSource = path.join(workdir, path.basename(source));
        // Always a real copy, never a hardlink: a hardlink shares the inode,
        // so a provider writing to its temp path would mutate the user's
        // original file.
        fs.copyFileSync(source, imageSource);
        fs.chmodSync(imageSource, 0o600);
        return {
            imageSource,
            workdir,
            cleanup: () => removeWorkdir(workdir),
        };
    } catch (error) {
        // The cleanup in the run's finally only knows directories that were
        // returned, so a copy that fails (an unreadable source, a full disk)
        // must not leave the fresh directory behind, once per failover
        // attempt. Awaited, so the directory is gone before the error
        // travels; the error itself still does.
        await removeWorkdir(workdir);
        throw error;
    }
}

/**
 * An empty throwaway cwd for a remote image: there is no local file to copy,
 * but the agent still must not run in the caller's directory, where an
 * injection in the image could read whatever project the user happens to be in.
 */
function emptyWorkdir(): IsolatedImage {
    const workdir = fs.mkdtempSync(path.join(os.tmpdir(), 'modlens-work-'));
    return {
        workdir,
        cleanup: () => removeWorkdir(workdir),
    };
}

/** Exported for tests: the timeout path is otherwise behind a 30s backstop. */
export function runCommand(
    providerName: string,
    invocation: ProviderInvocation,
    timeoutMs: number,
    describeFailure?: (context: ProviderFailureContext) => string | Error | null,
): Promise<CommandResult> {
    const runStartedAt = Date.now();
    return new Promise((resolve, reject) => {
        // A provider may mark its own child, which is how kimi-cli tells a
        // modlens started by kimi that running kimi again would loop.
        const childEnv = invocation.env ? { ...process.env, ...invocation.env } : undefined;
        // On Windows the bare CLI name resolves to the real file and a .cmd
        // shim is rewritten to a direct `node <entry>` spawn (issue #31);
        // POSIX passes through.
        // Built before planning, not after: on Windows the plan can depend on
        // the environment and the working directory (which `node` a shim's
        // branch resolves), and a planner reading one environment while the
        // child receives another is its own way for the plan and the shell to
        // disagree (issue #43).
        const plan = resolveSpawnPlan(
            invocation.command,
            invocation.args,
            childEnv ?? process.env,
            invocation.cwd,
        );
        // A shim that edits the environment hands back the whole thing.
        const spawnEnv = plan.env ?? childEnv;
        const child = spawnHidden(plan.command, plan.args, {
            cwd: invocation.cwd,
            stdio: ['ignore', 'pipe', 'pipe'],
            // A provider may mark its own child, which is how kimi-cli tells a
            // modlens started by kimi that running kimi again would loop.
            ...(spawnEnv ? { env: spawnEnv } : {}),
        });

        // Decoders keep state across chunks: a multi-byte character split down the
        // middle used to come out as replacement characters.
        const outDecoder = new TextDecoder('utf-8');
        const errDecoder = new TextDecoder('utf-8');
        let stdout = '';
        let stderr = '';
        let timedOut = false;
        let settled = false;
        let drainTimer: NodeJS.Timeout | undefined;
        let killTimer: NodeJS.Timeout | undefined;

        const timer = setTimeout(() => {
            timedOut = true;
            child.kill('SIGTERM');
            // A child that ignores SIGTERM used to keep the caller waiting for
            // as long as it liked, so report the timeout now and make sure it
            // dies.
            settle(null);
            // Deliberately ref'd: an unref'd escalation timer dies with the
            // event loop, and after settle() nothing else keeps a standalone
            // CLI alive, so a SIGTERM-ignoring provider survived its parent.
            // The cost is bounded: the child's own 'exit' clears this, so only
            // the stubborn case holds the process the full grace window.
            killTimer = setTimeout(() => {
                // child.killed only means a signal was delivered, not that the
                // process left, so a child ignoring SIGTERM read as "killed" and
                // never got SIGKILL. Escalate on "has not exited yet" instead.
                if (!exited) {
                    child.kill('SIGKILL');
                }
            }, SIGKILL_GRACE_MS);
        }, timeoutMs);

        // 'close' waits for every stdio pipe to close, but agy leaves a
        // language server running that inherited the pipe, so its write end
        // never closes and 'close' never fires (issue #1). Settle on 'exit'
        // plus a drain window instead, and drop the pipes afterwards so the
        // lingering descendant cannot keep this process alive either.
        const settle = (code: number | null) => {
            if (settled) {
                return;
            }
            settled = true;
            clearTimeout(timer);
            clearTimeout(drainTimer);
            // Flush the decoders: trailing bytes of a split character were dropped.
            stdout += outDecoder.decode();
            stderr += errDecoder.decode();
            child.stdout?.destroy();
            child.stderr?.destroy();
            child.unref();

            if (timedOut) {
                reject(new Error(`${providerName} provider timed out after ${timeoutMs} ms.`));
                return;
            }
            if (code !== 0) {
                // The provider knows what its own error output means; a bare
                // exit code tells the user nothing actionable (issue #3).
                const explained =
                    describeFailure?.({ stdout, stderr, code, startedAt: runStartedAt }) ?? null;
                // Both branches can quote subprocess stderr, and a CLI in a
                // broken auth state loves to print its token there.
                // Keep an Error from describeFailure so instanceof (quota
                // classification) survives; only wrap a string into a new Error.
                if (explained instanceof Error) {
                    setErrorMessage(explained, redactSecrets(explained.message));
                    reject(explained);
                    return;
                }
                reject(
                    new Error(
                        redactSecrets(
                            explained ??
                                `${providerName} provider failed with code ${code}.${stderr ? ` stderr: ${stderr.trim()}` : ''}`,
                        ),
                    ),
                );
                return;
            }
            resolve({ stdout, stderr });
        };

        let exitCode: number | null = null;
        let exited = false;
        const restartDrain = () => {
            if (!exited || settled) {
                return;
            }
            clearTimeout(drainTimer);
            drainTimer = setTimeout(() => settle(exitCode), DRAIN_GRACE_MS);
        };

        child.stdout.on('data', (chunk: Buffer) => {
            stdout += outDecoder.decode(chunk, { stream: true });
            restartDrain();
        });

        child.stderr.on('data', (chunk: Buffer) => {
            stderr += errDecoder.decode(chunk, { stream: true });
            restartDrain();
        });

        child.on('error', (error) => {
            if (settled) {
                return;
            }
            settled = true;
            clearTimeout(timer);
            clearTimeout(drainTimer);
            clearTimeout(killTimer);
            const code = (error as NodeJS.ErrnoException).code;
            if (code === 'ENOENT') {
                // spawn reports ENOENT for a missing cwd too, and naming the
                // wrong cause sent people installing software they already had.
                const missingCwd = !fs.existsSync(invocation.cwd);
                reject(
                    new Error(
                        missingCwd
                            ? `Working directory does not exist: ${invocation.cwd}`
                            : `Provider CLI not found: ${invocation.command} (spawn ENOENT). Install it and sign in first.`,
                    ),
                );
                return;
            }
            // A spawn-level failure that is not "missing": name the provider
            // and the command, keep the real code (EINVAL, EACCES, ...) — a
            // bare "spawn EINVAL" cost a Windows user a debugging session
            // (issue #31).
            reject(
                new Error(
                    `${providerName} provider could not start \`${invocation.command}\`: ${error.message}`,
                ),
            );
        });

        child.on('exit', (code) => {
            exitCode = code;
            exited = true;
            clearTimeout(killTimer);
            restartDrain();
        });

        // Normal providers close their pipes right after exiting: settle at once.
        child.on('close', (code) => settle(code));
    });
}
