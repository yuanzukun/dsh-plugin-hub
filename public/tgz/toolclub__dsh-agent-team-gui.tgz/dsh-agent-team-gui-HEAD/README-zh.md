# dsh-agent-team-gui

[English](README.md) | [简体中文](README-zh.md)

[![CI](https://github.com/toolclub/dsh-agent-team-gui/actions/workflows/ci.yml/badge.svg)](https://github.com/toolclub/dsh-agent-team-gui/actions/workflows/ci.yml)
[![GitHub release](https://img.shields.io/github/v/release/toolclub/dsh-agent-team-gui?include_prereleases&style=flat-square)](https://github.com/toolclub/dsh-agent-team-gui/releases)
[![GitHub stars](https://img.shields.io/github/stars/toolclub/dsh-agent-team-gui?style=flat-square)](https://github.com/toolclub/dsh-agent-team-gui/stargazers)
[![MIT license](https://img.shields.io/github/license/toolclub/dsh-agent-team-gui?style=flat-square)](LICENSE)

**把规划、实现和审核保存为一支小队，在 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的普通对话中反复使用。**
每个成员可选自己的模型与工具权限。发送一个任务后，查看分工、依赖、成员输出、审核结果和
Provider 上报的 Token 用量；下一次继续使用同一套小队配置。

[80 秒界面导览](https://github.com/toolclub/dsh-agent-team-gui/blob/main/assets/promotion-walkthrough-zh.mp4) · [安装](#安装) · [跑通第一个任务](docs/first-team.zh-CN.md) ·
[示例配方](examples/full-stack-delivery.recipe.json) ·
[发布版本](https://github.com/toolclub/dsh-agent-team-gui/releases) ·
[反馈问题](https://github.com/toolclub/dsh-agent-team-gui/issues/new/choose)

如果你也想复用自己的多模型工作流，欢迎点一个
[Star](https://github.com/toolclub/dsh-agent-team-gui)，方便回来继续试用。

[![多模型小队配置、运行中心与配方复用的界面导览](https://raw.githubusercontent.com/toolclub/dsh-agent-team-gui/main/assets/promotion-walkthrough-preview.gif)](https://github.com/toolclub/dsh-agent-team-gui/blob/main/assets/promotion-walkthrough-zh.mp4)

*导览基于实际产品截图与预置示例数据制作，配中文合成旁白；状态、耗时和用量不是实际任务测试或性能基准。[素材来源与字幕](docs/promotion/demo-guide.md)。*

## 为什么需要这个插件

小队是可以长期复用的产品对象，不是一次性的派单表单。在 **Settings → 小队** 中创建一次，
以后可以跨项目、跨对话使用。

| 能力 | 给用户带来的价值 |
| --- | --- |
| 每个成员独立模型和工具策略 | 规划、实现、审核或领域专家可以使用不同路由，不必共用一套配置 |
| 默认动态工作流编排 | 当前对话的模型根据这次请求，为成员生成聚焦任务和依赖关系 |
| 小队 / 单人 / 继承三态 | 清楚地区分对话覆盖、项目默认和仅下一条消息的临时选择 |
| 有界 DAG、重试、质量门禁、后台运行 | 长任务可观察、可取消、不会无限递归，重启后也有明确状态 |
| 官方 Provider Token 用量 | 查看输入、缓存读取、缓存写入和输出，并明确完整/部分/无计量，绝不伪造价格 |
| 版本、配方和定义备份 | 可复现、无凭证分享、应用前预览影响，并先重映射模型路由 |

## 安装

| 插件版本 | DSH 版本 | 升级建议 |
| --- | --- | --- |
| **1.3.0** | `>=0.1.5-rc.1 <0.1.6-0` | 推荐版本，可选择按需派工，并完善模式边界 |
| 1.2.0 | `>=0.1.5-rc.1 <0.1.6-0` | 失败诊断和主 Agent 受控继续派工 |
| 1.1.1 | `>=0.1.5-rc.1 <0.1.6-0` | 修复早期工作流问题，自动重试仍复用原任务 |
| 1.1.0 | `>=0.1.5-rc.1 <0.1.6-0` | 首个 0.1.5 适配版本，建议更新插件到 1.3.0 |
| 1.0.1 | 已验证 `0.1.1-rc.2` | 旧版集成；需要同时升级 DSH 和插件 |

已有导览提供[英文字幕](https://github.com/toolclub/dsh-agent-team-gui/blob/main/docs/promotion/demo-captions.en.srt)
和[中文字幕](https://github.com/toolclub/dsh-agent-team-gui/blob/main/docs/promotion/demo-captions.zh-CN.srt)，可在支持字幕的播放器中手动加载 SRT；GitHub 不会自动叠加字幕。

从 DSH 0.1.1 升级时，请搭配 **插件 v1.3.0 + DSH 0.1.5**。新版修复了加载时的
`source.subscribe` 报错，并适配连接恢复和 Session API；现有小队定义与运行记录继续保留。
升级后重启 DSH 并刷新浏览器。CLI 可能显示 `0.1.5-rc.1`，内部兼容包实际解析为 `0.1.5-rc.2`。

需要已安装的 DeepSeek Harness `>=0.1.5-rc.1 <0.1.6-0`、**Web** profile、Node.js
`>=22.19.0 <23` 或 `>=24.0.0`（不支持 Node.js 23）、pnpm，以及至少一条已经配置好的
DSH provider/model 路由。仓库 CI 当前使用 DSH `0.1.5-rc.1`。

直接安装 **v1.3.0 预编译发布包**：

```sh
dsh plugin --profile web add https://github.com/toolclub/dsh-agent-team-gui/releases/download/v1.3.0/dsh-agent-team-gui-1.3.0.tgz
dsh --profile web
```

这个发布包已包含 Host 和浏览器代码，不需要为插件授权 Git `prepare` 构建。
如果 DSH Web 已经运行，安装或更新后重启该进程，再刷新页面。打开 **Settings → 小队**
即可看到**小队 / 成员库 / 配方与数据**三个页签。

DSH `0.1.7-rc.2` 超出此版本声明的宿主范围；其安装器会因 v1.3.0 的 peer 范围不兼容而拒绝并回滚安装（已在 macOS arm64、Node 26.5.0、pnpm 12.6.0 复现）。更换安装源不代表支持该宿主。Node engines 的范围也不代表所有更新的 Node/DSH 组合均已验证。

使用 DSH Plugin Hub 时，建议 **1.5.2** 或更高版本并刷新目录；Hub 1.4.8 没有预编译 Release 安装通道。若目录仍选择 Git，请直接执行上面的命令。Hub 目录缓存为一小时，刷新失败时还可能继续使用旧缓存。

> [!TIP]
> 如果终端找不到 `dsh`，克隆 Harness 源码不会自动安装全局命令。在 Harness 仓库中
> 使用 `pnpm dsh --version`，并把本文的 `dsh ...` 替换为
> `pnpm --dir /absolute/path/to/deepseek-harness dsh ...`。

安装排错见[首次体验指南](docs/first-team.zh-CN.md#安装或首跑遇到问题)；需要从源码安装时，
使用下方[固定 Git tag](#固定-git-tag)方式。

## 跑通第一个任务

从仓库自带的 [Full-stack delivery 配方](examples/full-stack-delivery.recipe.json)开始，
它包含 **Product planner → Implementation engineer → Quality reviewer** 三种角色；
实际分工和依赖由当前对话模型规划。

1. 保存配方 JSON 到本地。在 **Settings → 小队 → 配方与数据** 点击**选择配方文件**，
   文件读取后会自动预览；也可以粘贴到**配方 JSON**，再点击**预览**。
2. 为三名成员把 `your-provider / your-model` 映射为已配置的路由。保持**导入策略 →
   创建副本**，等到**配方校验通过**后，点击**确认导入配方**。到**成员库**核对各自模型，
   可以使用不同模型，也可以先全部使用同一个可用模型。
3. 在**小队**页选中导入的小队，将**小队使用方式**设为**Host 强制派工**、**派工策略**设为**执行已派任务**、**成员选择**设为
   **全部成员**并保存。示例原本使用智能选择，这样调整便于观察完整的首次协作。
4. 在空临时项目中新建对话，打开输入框旁的小队控件，选择导入的小队，并选中
   **本对话选择小队**。发送下面的任务。
5. 打开对话的**小队运行**，展开记录查看计划、成员交付和审核；在**洞察**中查看本次
   使用的模型与 Token 计量情况。

```text
请在当前空临时项目中实现一个无外部依赖的待办清单。
交付 index.html、app.mjs、app.test.mjs、README.md。
支持新增非空任务、完成/取消完成、删除、剩余计数，提供空列表提示和键盘可用的操作。
规划成员先写验收标准；实现成员只改当前项目；审核成员核对代码和实际测试输出。
用 node --test 验证新增、拒绝空白、切换完成、删除及计数，给出浏览器人工检查步骤。
不需要持久化、登录或后端；不要安装依赖、访问外部服务、提交 Git 或发布。
最终报告交付文件、实际执行的检查、未验证项和剩余问题，不要把未执行的测试写成通过。
```

临时目录创建方式、工具权限、首次模型配置、验收清单和排错步骤都在
[完整首次体验指南](docs/first-team.zh-CN.md)。这是供你复现的任务说明，目前未附真实模型
完成此任务的实测结果，也不承诺固定耗时或节省比例。

![在普通输入框旁选择小队、单人或继承](assets/v0.5-composer-mode.png)

*输入框控件演示，使用预置示例数据。*

## 编排是怎样工作的

```mermaid
flowchart TD
    U[用户消息] --> M{有效模式与下一条选择}
    M -->|单人或仅手动| L[主 Agent 直接处理]
    M -->|按需使用| J{主 Agent 判断协作是否有价值}
    J -->|不需要| L
    J -->|缺少信息| A[询问用户]
    J -->|需要：调用小队工具| D[校验并受理一次首次派工]
    M -->|Host 强制或下一条 Team| D
    D --> P[使用已有计划或启动有界规划器]
    P -->|智能跳过| L
    P --> W[按依赖执行成员、失败策略和可选质量门]
    W --> R[持久化结果、诊断和已报告用量]
    R --> L
    R -->|主 Agent 复核剩余任务| C[受控继续派工]
    C -->|复用成功成果、共用预算、最多继续一次| W
```

新建小队和内置模板默认“主 Agent 按需使用”；选择小队代表可供使用，简单回答不启动规划器或成员。
已有配置、导入配置以及旧记录的默认行为保持不变。后台运行在运行中心结算，模型工具派工等待结果。
[完整流程图与边界说明](docs/on-demand-flow.md)。

真正派工后，没有显式分工/顺序且没有固定顺序时，插件会使用当前对话的 provider/model 路由启动一个有界、无工具的规划
子任务。它读取所有成员的角色，并返回结构化分工和无环依赖图。规划器不会让第一个成员替代
整个小队。计划不可用、无效或有环时，会回退到确定性的角色专属任务。

所有已就绪 DAG 节点最多按 `maxConcurrency` 并发执行；依赖成员只接收有界的结构化交接，
完整输出保存在持久运行历史中。固定成员顺序是明确的串行覆盖，它不会执行 DAG 规划。

### 触发和成员选择

- **执行已派任务**：已经决定派工后要求执行，不会强迫按需模式为每条消息派工。
- **智能**：有界规划器可以跳过不适合或太简单的任务。
- **手动**：普通消息不能自动或通过模型工具派工；显式选择下一条 Team，或使用手动运行操作。
- **全部成员**：每个已配置成员恰好获得一次任务。
- **自适应**：智能规划选择最小但非空的合适成员子集。

### 对话模式

- **小队**：这个对话持久地显式使用某个小队。
- **单人**：这个对话持久地显式退出，即使项目设置了默认小队也不启用。
- **继承**：删除对话覆盖；如果项目有默认小队就跟随它。
- **下一条消息**：独立、崩溃安全的一次性小队或单人选择，只消费一次。

刷新页面、Host 冷启动和在线重连后，这些状态仍然可以立即操作。目录暂时为空或请求失败时，
插件不会擅自删除已经保存的选择。

### 安全边界

- 规划、成员、审核和返工提示词会把角色范围与禁止委派放在前面，用户内容只提供有界摘录。
- 被委派的 Session 不能再次派小队。插件会识别并禁止小队子成员中的 DSH subagent 工具，
  包括重命名后的注册项。
- 自动路径和模型工具共同使用“最新人类消息”的持久原子 claim；重复工具调用不会创建几百个
  重复小队。
- 成员超时、并发、一次重试、软 Token 预算和质量轮次都有明确上限。
- 重试会创建有链接的不可变运行，并重放原来的分工、顺序和 DAG，不会悄悄让模型重新发明流程。

## 运行中心和 Token 用量

![查看 DAG、成员状态、审核轮次和 Token 桶](assets/v0.5-run-center.png)

*运行中心演示，状态与 Token 来自预置示例数据，不代表实际任务表现。*

每次执行都会在规划前写入持久记录。运行中心展示前台/后台状态、实时阶段、耗时、child ID、
完整输出、有界交接、停止、有链接的整次或单成员重试、导出、筛选以及受保留策略保护的清理。

如果 DSH 子运行在交付非空纯文本后以 `stopReason: "error"` 结束，该成员会按**已完成**处理，
不会把有效的长文本交付误判为失败。停止原因仍会持久化，运行中心会显示协议交付警告；空输出、
Promise 拒绝、清理失败、超时以及 `max-tokens` 等其他非完成原因仍然算失败。

每个成员的交接摘要默认最多保留 16,000 个字符。小队可通过 `handoffSummaryMaxChars` 配置
1,000–32,000 个字符。完整原始输出仍持久保存在运行中心；依赖成员和主模型 Prompt 继续使用
独立的聚合边界，避免单个长交付无限扩大模型上下文。

插件复用 DSH 官方 `tokenUsage` projection，并保留四个桶：

- 非缓存输入；
- 缓存读取；
- 缓存写入；
- 输出。

规划、成员、审核和返工用量可以分别归因。每次运行和重试尝试都明确显示**完整 / 部分 /
无计量**。Provider 第一次上报前，UI 显示**正在计量…**，不会显示假的 0。Token 不是金钱；
Harness provider 没有通过稳定价格契约发布价格时，插件不会猜测费用。

![查看持久用量与完成洞察，不伪造价格](assets/v0.5-insights.png)

*洞察界面演示，图中用量和完成率来自预置示例数据。*

## 质量门禁和后台运行

可选质量门禁需要明确指定审核人、返工负责人、审核标准和 `0..2` 次返工。未通过时只能重跑
这个返工负责人，再交给指定审核人复查；它不能随意创建 Agent 或递归。

前台运行完成后，主 Agent 才综合有界交接。后台运行立即返回简短确认，并持续显示在插件运行
中心；如果 DSH 官方 Jobs service 存在，同一次运行也会注册到官方界面并共享取消逻辑。如果
缺少这个可选 service，插件使用进程内后台执行；Host 重启后，未完成记录会被统一标为
**已中断**，不会伪装成成功。

## 版本、配方和定义备份

![预览配方、冲突、受影响小队以及主/备用路由重映射](assets/v0.5-recipes.png)

*配方导入演示，使用预置示例数据。*

- 每个小队版本都包含所有引用成员的不可变快照。
- 恢复前必须预览；共享成员会影响其他小队时会明确警告。
- 配方只包含一个小队及其成员，不包含 provider 凭证。导入支持**复制 / 合并**、冲突预览，
  并可分别重映射主路由和备用路由。
- 定义备份导出 Agent 和小队。导入先预览，再选择**合并 / 替换**；替换会在确认前列出删除、
  悬空模式/项目默认清理以及受影响小队。
- 跨表写入会串行执行；验证失败、取消或存储故障时执行补偿回滚。读者只能看到旧定义图或
  已提交的新定义图，不会读到半个导入。
- v0.5 禁止从 URL 拉取配方。请导入已经审查的本地 JSON；这是为了避免提供没有完整 SSRF
  防护的 Host 网络请求面。

可以从不含凭证的
[全栈交付配方](examples/full-stack-delivery.recipe.json)开始：先预览，再把其中的
`your-provider / your-model` 占位路由映射到你自己的 DSH 配置。

定义导出包含成员 system prompt 和模型路由名；运行导出还包含用户任务和成员输出。分享前请
自行检查这些文件。

## Settings 字段说明

### 成员

| 字段 | 含义 |
| --- | --- |
| 名称和角色提示词 | 这个成员的持久身份和专属工作范围 |
| 主 provider/model | 现有 DSH 路由；凭证仍由 DSH 保管 |
| 备用 provider/model | 可选配对路由，供一次重试使用 |
| `maxTokens` | 传给 provider 的单次硬输出上限 |
| 工具允许/禁止 | 已注册 DSH 工具的最小权限；递归小队/subagent 工具仍会被禁止 |

### 小队

| 字段 | 含义 |
| --- | --- |
| 成员和协作说明 | 可复用成员定义以及小队级协作指导 |
| 固定顺序 | 完整串行排列；关闭时使用动态分工和 DAG 依赖 |
| 执行/上下文 | 串行或有界并行；`spawn`、`fork` 或仅串行可用的 `chain` |
| 触发/选择 | 始终、智能或手动；全部成员或自适应子集 |
| 响应 | 前台综合或可观察的后台运行 |
| 规划器 | 当前/最近/完整上下文以及有界的规划 Token 上限 |
| 恢复 | 继续、停止或一次重试；成员超时和备用路由 |
| 限制 | 最大并发以及基于 provider 上报的软小队 Token 预算 |
| 交接摘要 | 每名成员的摘要字符上限；留空使用 16,000，可配置 1,000–32,000 |
| 质量 | 指定审核人、返工负责人、标准和最多两次返工 |

![窄屏下仍然能够完成主要操作](assets/v0.5-narrow.png)

*窄屏界面演示，使用预置示例数据。*

## Host 配置

Web bundle 只插入一条唯一 Host row；它复用 Web profile 已有的 storage、Connection RPC、
模型、Session 和浏览器模块 service。

```yaml
- id: agent-team-gui
  name: dsh-agent-team-gui
  config:
    defaultProvider: spawn
    defaultExecutionMode: serial
    defaultContextMode: spawn
    historyMaxRuns: 0
    historyMaxAgeDays: 0
    versionMaxPerSquad: 0
```

| 字段 | 默认值 | 含义 |
| --- | --- | --- |
| `defaultProvider` | `spawn` | 已注册的 DSH subagent provider |
| `defaultExecutionMode` | `serial` | 小队省略配置时的实际执行模式 |
| `defaultContextMode` | `spawn` | 小队省略配置时的实际上下文模式 |
| `historyMaxRuns` | `0` | 按数量保留；`0` 关闭自动删除运行历史 |
| `historyMaxAgeDays` | `0` | 按天保留；`0` 关闭自动删除运行历史 |
| `versionMaxPerSquad` | `0` | 每个小队的版本保留数；`0` 关闭自动删除版本 |

如果在 profile patch 中覆盖这条 row，必须重新写出所有需要的字段：DSH patch row 会替换
整个 `config` 对象，不会深度合并。`chain` 只能和串行执行一起使用。
历史保留默认明确关闭：升级到 v0.5 不会静默删除既有运行历史或小队版本。只有当你确实希望
自动清理时，才为相应字段设置正数。

## 其他安装方式

### 固定 Git tag

如果希望从已审查的源码构建，可以安装固定 tag：

```sh
dsh plugin --profile web add -w github:toolclub/dsh-agent-team-gui#v1.3.0
dsh --profile web
```

Git 依赖会执行仓库自带的 `prepare` 构建。pnpm 10 或更高版本第一次可能要求授权构建。
只把这个包加入 pnpm 提示的 Web profile 文件（通常是
`~/.dsh/profiles/web/pnpm-workspace.yaml`），保留文件中的其他配置，然后重复安装命令：

复制 pnpm 错误中打印的**准确包键**到 `allowBuilds`；该键可能包含解析后的完整 revision。
只授权这一条，并保留文件中已有配置。

`allowBuilds` 允许选中的 Git 依赖在本机执行构建。请先审查源码，并固定 tag 或完整 commit
SHA；不需要源码构建时，使用上方的预编译发布包即可。

### 固定 commit

解析并审查完整 commit SHA，然后使用和 tag 安装相同的 `allowBuilds` 规则：

```sh
dsh plugin --profile web add -w github:toolclub/dsh-agent-team-gui#<full-commit-sha>
```

这是可复现性最好的源码安装方式。Release CI 也会对准确的已推送 revision 执行全新 profile
安装检查。

### 本地 checkout

在本仓库中执行：

```sh
pnpm install --frozen-lockfile
pnpm run preflight
dsh plugin --profile web add -w .
```

`preflight` 会检查 Host、Client 和测试类型；运行 Host/渲染 Client 测试；从空输出目录构建；
检查 tarball 与敏感信息；并启动隔离的临时 DSH Web profile。

### 在本地打包 tarball

```sh
mkdir -p dist
pnpm pack --pack-destination dist
dsh plugin --profile web add -w ./dist/dsh-agent-team-gui-1.3.0.tgz
```

包检查会验证运行时和声明闭包、示例、治理文件、截图、source map、外部依赖声明、绝对路径、
符号链接以及常见凭证模式。

### 让有终端权限的 Agent 安装

可以在 DeepSeek Harness 中直接发送这一句话：

> 按照 https://github.com/toolclub/dsh-agent-team-gui 的安装说明，把 v1.3.0 预编译发布包
> 安装到 Web profile；重启 Web，验证组合配置，并汇报实际安装的插件和 DSH 版本。

## 模型工具和公开 Service

`dispatch_to_squad` 继续支持明确的手动/模型驱动调用。它接受小队 ID 或不重名的大小写不敏感
名称、任务、可选分工/顺序，以及小队允许的执行/上下文覆盖。返回给模型的内容有界；完整规范
运行会持久化，并可通过运行中心或导出读取。

包还会导出 `AgentTeamService`、记录/结果类型、Zod schema，以及进程内定义、派单、版本、
配方和运行 API。DSH 本身仍处于预稳定阶段，请把这些 API 也视为 developer preview。

## 安全和隐私

- RPC 使用 `/api/agentTeamGui`，受 DSH 的浏览器会话 Cookie 认证及 Host/Origin 校验保护，
  同时验证请求和响应；不再注册独立的未认证通道。
- Provider 凭证不会被复制进插件记录、配方、示例、日志或导出。
- 本地持久存储会包含小队角色提示词、所选路由名、对话/项目标识、用户任务、运行输出、错误和
  Token 用量。请保护 DSH home 目录。
- 按最小权限配置成员工具；模型可以执行所有被允许 DSH 工具所授权的操作。
- URL 配方拉取已禁用。安装脚本是额外的机器代码权限；请审查并固定 Git 依赖，或使用已编译
  tarball。
- 安全问题请按照 [SECURITY.md](SECURITY.md) 私下报告，不要在公开 Issue 中粘贴凭证或私密
  提示词。

## 兼容范围和限制

依赖交接与返工交接共享独立的 12,000 字符序列化 JSON 预算，质量审核链为 32,000 字符；
它们与单成员存储摘要上限相互独立。交接会保留成员身份、分配内容空间，并用
`chainTruncated` / `omittedHandoffs` 明示缩减或省略，完整输出仍保存在运行中心。
审核阶段遵循审核成员设置的 `maxTokens`；只有未设置时才默认使用 2,048。

`retry-once` 会先分析失败原因：明确的余额/额度耗尽、取消或已配置的预算耗尽会停止恢复。
系统诊断角色使用主 Agent 的模型路由，无工具权限，分析失败证据、已有进展和不确定性。
仅有证据支持的临时故障会原地有限重试；任务范围等结构性问题交给主 Agent 决定修订方案。

失败或部分成功的本轮运行结束后，主 Agent 可以调用 `continue_squad_run`，引用原运行 ID
和执行链版本继续派工。第一版每条执行链**最多继续一次**，共用原配置的软 Token 预算。
独立成功任务复用，受影响的下游重新执行；原计划、失败证据和后续结果分别保存。
重复提交返回已受理结果，改写任务文本不会重置次数；同一消息的首次派工仍只允许一次。
运行中心的手动重试仍是用户主动发起的独立计划重放。

当前保留“一个已有成员对应一个任务节点”，可把剩余任务写成有序步骤，暂不支持同一成员
拆出多个独立节点或更换整支小队。详细边界见[执行链与失败恢复](docs/execution-chains.md)。

DSH 0.1.5 下，deny 名称按全局工具注册表筛选，局部 allow 列表原样保留；被标记的进程内
小队成员还有执行拦截，阻止已识别的委派工具及成员显式禁止的工具。DSH 尚无通用委派能力
标签；任意自定义工具和外部程序不能据此视为具备操作系统级沙箱隔离。

- 只提供 Web profile UI；没有 headless Settings。其他进程内插件仍可在提供必要 service 后使用
  导出的 Host service。
- 声明兼容范围为 DSH `>=0.1.5-rc.1 <0.1.6-0`，当前 CI 使用 `0.1.5-rc.1`。DSH 和本插件都未
  稳定，请固定版本。
- 旧 v0.4 持久定义和 v1 导出仍可读取/导入；编辑旧记录时必须满足 v0.5 更安全的新写入上限。
  没有保存原计划的旧运行无法忠实重试，会得到明确拒绝原因。
- Provider Token projection 是可选能力；部分或无计量属于正常、明确的状态。
- 软小队 Token 预算只阻止后续调度，不能在准确阈值停止正在运行的 provider；成员
  `maxTokens` 才是 provider 硬上限。
- DSH 暂时没有注册自定义持久 `squad/*` Session 事件的受支持 seam。插件使用自己的持久运行
  存储、标准 child Session/tool 事件、Jobs 和日志。
- 模型工具触发是 best-effort，因为 DSH 没有暴露 `toolChoice`；普通发送的 Guaranteed 模式由
  Host 驱动，并且按持久消息幂等。

## 验证与项目健康度

```sh
pnpm run typecheck
pnpm run test
pnpm run build
pnpm run audit:pack
pnpm run smoke:install
pnpm run smoke:browser
```

CI 覆盖 Node 22.19 和 Node 24、全新 DSH `0.1.5-rc.1` Web profile、浏览器键盘/无障碍/重连路径、
准确 Git revision 安装以及社区插件 doctor。详细产品契约和证据矩阵见
[docs/v0.5-product-spec.md](docs/v0.5-product-spec.md) 与
[docs/v0.5-acceptance.md](docs/v0.5-acceptance.md)。

## 贡献

请先阅读 [CONTRIBUTING.md](CONTRIBUTING.md)、[行为准则](CODE_OF_CONDUCT.md) 和
[SECURITY.md](SECURITY.md)。中文短教程
[从零开发一个 DeepSeek Harness 插件](docs/developing-a-deepseek-harness-plugin.zh-CN.md)
结合官方 Harness 资料讲解 `apply`、Service 插件、profile/bundle 接线、本地验证和 GitHub 安装。

Issue 应附准确 DSH/插件版本和已经脱敏的最小复现。Pull Request 应添加聚焦回归证据，并同时
考虑兼容性、有界执行、无障碍、隐私和发布包闭包。

如果这个工作流对你有用，一个 [GitHub Star](https://github.com/toolclub/dsh-agent-team-gui)
能让更多 DSH 用户发现它。真实配方、截图和诚实的 Bug 反馈更有价值。

## 卸载

```sh
dsh plugin --profile web remove dsh-agent-team-gui
```

删除包不会自动删除 DSH 存储后端中的持久插件表。

## License

使用 [MIT License](LICENSE) 发布。
