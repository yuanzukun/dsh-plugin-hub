# Asset Sources

Lookseek ships no third-party model until its source, license, attribution, texture provenance, and animation compatibility are recorded here. The published plugin contains converted `.glb` derivatives only after this review.

## Chosen Pipeline

Use a Blender source scene for assembly, then export one static `workshop.glb`, a shared `worker.glb`, and an `animations.glb`. Keep the original source beside the build recipe outside the runtime bundle. Use `gltfpack` to produce web variants and KTX2 for opaque texture atlases.

The worker must retain one 18-bone-compatible humanoid armature and the clips `Walk`, `Idle`, `Sit`, `Type`, `Read`, `Inspect`, `Carry`, `Stamp`, `Repair`, and `Wait`. Do not buy or download separate characters with incompatible rigs.

## Approved Candidates

| Use | Source | License and release obligation | Review result |
| --- | --- | --- | --- |
| Primary modular worker and animation base | [Quaternius Ultimate Modular Men Pack](https://quaternius.com/packs/ultimatemodularcharacters.html) | The source page states glTF/Blend formats and free personal/commercial use. Preserve the source-page notice in the release record. | Preferred. Eleven modular characters, twenty-four animation clips, one coherent style. Convert selected components to GLB; do not start from placeholder geometry. |
| Office layout reference / reusable furniture extraction | [Isometric office by Companion_Cube](https://sketchfab.com/3d-models/isometric-office-d31464eed8044190911b221648aca432) | CC BY 4.0. Attribution to `Companion_Cube`, link to source and CC BY 4.0 must ship in `ATTRIBUTIONS.md`. Commercial use is allowed. | Candidate only. At 156,981 faces it needs selective extraction and reduction; do not load it as one runtime mesh. |
| Desk, chair, shelf, lamps and small office props | [Office Props Pack by crazyshroomz](https://sketchfab.com/3d-models/office-props-pack-260ff7a37a674505903708a0dc513e7e) | CC BY 4.0. Attribution to `crazyshroomz`, link to source and CC BY 4.0 must ship in `ATTRIBUTIONS.md`. | Good source for the shared workshop. The pack is 27,524 faces before pruning and can be atlased. |
| Computer / screen detail | [Office Computer by sebodeweb](https://sketchfab.com/3d-models/office-computer-9403093258264563a89d708b906f1b47) | CC BY 4.0. Attribution to `sebodeweb`, link to source and CC BY 4.0 must ship in `ATTRIBUTIONS.md`. | Optional. Use only if the prop-pack screens are insufficient. |

The Sketchfab records above were verified as downloadable and CC Attribution (not NonCommercial) on 2026-08-14. Downloading through Sketchfab may require an account. Never include an asset labelled `CC Attribution-NonCommercial`, `Editorial`, or `Free Standard` in this open plugin release.

## Excluded Sources

- Mixamo characters and clips: useful during private prototyping, but not selected for an open asset bundle because its redistribution terms need a separate release review.
- Arbitrary Sketchfab search results: an open preview is not enough. The model must be downloadable and carry a license that permits redistribution.
- High-poly office scenes: a full office mesh is neither a diorama nor a mobile-safe runtime asset. Extract approved props, build the 14m x 10m room in Blender, and use instancing for repeated books, notes, cables, and test boxes.

## Acceptance Gate

Before merging an asset, verify its source URL, downloadable state, license, author, attribution text, triangle count, texture size, skeleton naming, and clip list. The first release target is under 90k visible triangles for the room plus four workers, with one 2048px atlas for static props and no runtime reflections.
