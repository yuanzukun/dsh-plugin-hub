import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import { Jimp, JimpMime } from 'jimp'

const [input, output, maxSizeArgument] = process.argv.slice(2)
if (input === undefined || output === undefined) throw new Error('Usage: node scripts/resize-gltf-textures.mjs <input.glb> <output.glb> [max-size]')
const maxSize = Number(maxSizeArgument ?? '1024')
if (!Number.isInteger(maxSize) || maxSize < 1) throw new Error('max-size must be a positive integer')

const inputBytes = await readFile(input)
if (inputBytes.readUInt32LE(0) !== 0x46546c67) throw new Error('Input must be a binary glTF (.glb) file')
const jsonLength = inputBytes.readUInt32LE(12)
const jsonStart = 20
const jsonEnd = jsonStart + jsonLength
const document = JSON.parse(new TextDecoder().decode(inputBytes.subarray(jsonStart, jsonEnd)))
const binStart = jsonEnd + 8
const imageViews = new Set((document.images ?? []).flatMap(image => image.bufferView === undefined ? [] : [image.bufferView]))
const views = document.bufferViews ?? []

const chunks = []
let byteOffset = 0
for (const [index, view] of views.entries()) {
  const source = inputBytes.subarray(binStart + (view.byteOffset ?? 0), binStart + (view.byteOffset ?? 0) + view.byteLength)
  let bytes = source
  if (imageViews.has(index)) {
    const image = await Jimp.read(source)
    const scale = Math.min(1, maxSize / image.bitmap.width, maxSize / image.bitmap.height)
    if (scale < 1) image.resize({ w: Math.round(image.bitmap.width * scale), h: Math.round(image.bitmap.height * scale) })
    bytes = await image.getBuffer(JimpMime.png)
  }
  const padding = (4 - (byteOffset % 4)) % 4
  if (padding > 0) {
    chunks.push(Buffer.alloc(padding))
    byteOffset += padding
  }
  view.byteOffset = byteOffset
  view.byteLength = bytes.length
  chunks.push(bytes)
  byteOffset += bytes.length
}

const binBytes = Buffer.concat(chunks)
document.buffers[0].byteLength = binBytes.length
const jsonBytes = Buffer.from(JSON.stringify(document), 'utf8')
const paddedJsonLength = Math.ceil(jsonBytes.length / 4) * 4
const paddedBinLength = Math.ceil(binBytes.length / 4) * 4
const totalLength = 12 + 8 + paddedJsonLength + 8 + paddedBinLength
const outputBytes = Buffer.alloc(totalLength, 0x20)
outputBytes.writeUInt32LE(0x46546c67, 0)
outputBytes.writeUInt32LE(2, 4)
outputBytes.writeUInt32LE(totalLength, 8)
outputBytes.writeUInt32LE(paddedJsonLength, 12)
outputBytes.writeUInt32LE(0x4e4f534a, 16)
jsonBytes.copy(outputBytes, 20)
const binHeader = 20 + paddedJsonLength
outputBytes.writeUInt32LE(paddedBinLength, binHeader)
outputBytes.writeUInt32LE(0x004e4942, binHeader + 4)
binBytes.copy(outputBytes, binHeader + 8)

await mkdir(dirname(output), { recursive: true })
await writeFile(output, outputBytes)
console.log(`Resized ${imageViews.size} textures to a maximum of ${maxSize}px.`)
