import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'

const [input, output] = process.argv.slice(2)
if (input === undefined || output === undefined) throw new Error('Usage: node scripts/extract-workroom.mjs <input.glb> <output.glb>')

const inputBytes = await readFile(input)
if (inputBytes.readUInt32LE(0) !== 0x46546c67) throw new Error('Input must be a binary glTF (.glb) file')

const jsonLength = inputBytes.readUInt32LE(12)
const jsonStart = 20
const jsonEnd = jsonStart + jsonLength
const document = JSON.parse(new TextDecoder().decode(inputBytes.subarray(jsonStart, jsonEnd)))
const nodes = document.nodes ?? []
const rootIndex = nodes.findIndex(node => node.name === 'MainOffice')
if (rootIndex < 0) throw new Error('The supplied office scene does not have its expected MainOffice root')
const excludedShellNodes = new Set([17, 28, 29, 30, 172, 186])
const bathroomNode = /(?:Bathroom|Sink|Soap|PaperTowel|Toilet|Urinal)/i
const wallOrAttachedNode = /^(?:SM_Bld_(?:Door|FeatureWall|Pillar|Wall)|SM_Prop_(?:AirVent_Wall|Clock|CorkBoard|Darkboard|Fire(?:Alarm|_Detector|_Extinguisher)|HandDryer|PaperTowel|Security_Camera|Sign_|Soap|Socket_Wall|WallDressing|Wall_Electronics))/i

const workstationNodes = (nodes[rootIndex].children ?? []).filter((index) => {
  const node = nodes[index]
  const name = node?.name ?? ''
  const [x = 0, y = 0] = node?.translation ?? []
  // Only office carpet joins the retained work area. Tile floors belong to the removed service rooms.
  const floor = /^SM_Bld_Floor_Carpet_/.test(name)
  const extraFloor = /^SM_Bld_Floor_/.test(name) && !floor
  const foregroundFloor = /^SM_Bld_Floor_/.test(name) && y <= 550
  // The left service wing is removed, except for its continuous floor.
  const leftServiceWing = x < 1_300 && !floor
  return !excludedShellNodes.has(index) && !bathroomNode.test(name)
    && !leftServiceWing && !extraFloor && !foregroundFloor && !wallOrAttachedNode.test(name)
    && x >= 1_000 && x <= 2_500 && y >= 450 && y <= 1_500
})
if (workstationNodes.length === 0) throw new Error('The selected workstation room contains no scene nodes')

document.scenes[document.scene ?? 0].nodes = [rootIndex]
document.nodes[rootIndex].children = workstationNodes

const jsonBytes = Buffer.from(JSON.stringify(document), 'utf8')
const paddedJsonLength = Math.ceil(jsonBytes.length / 4) * 4
const binChunk = inputBytes.subarray(jsonEnd)
const totalLength = 12 + 8 + paddedJsonLength + binChunk.length
const outputBytes = Buffer.alloc(totalLength, 0x20)
outputBytes.writeUInt32LE(0x46546c67, 0)
outputBytes.writeUInt32LE(2, 4)
outputBytes.writeUInt32LE(totalLength, 8)
outputBytes.writeUInt32LE(paddedJsonLength, 12)
outputBytes.writeUInt32LE(0x4e4f534a, 16)
jsonBytes.copy(outputBytes, 20)
binChunk.copy(outputBytes, 20 + paddedJsonLength)

await mkdir(dirname(output), { recursive: true })
await writeFile(output, outputBytes)
console.log(`Selected ${workstationNodes.length} top-level office nodes.`)
