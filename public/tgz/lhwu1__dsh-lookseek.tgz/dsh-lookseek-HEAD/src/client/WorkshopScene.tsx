import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { CSS2DObject, CSS2DRenderer } from 'three/examples/jsm/renderers/CSS2DRenderer.js'
import type { LayoutRoute, LookseekLayout } from '../shared/layout.ts'
import { activityLabel, memberStateLabel, type WorkspaceMember } from './model.ts'

interface RouteDraftView {
  mode: LayoutRoute['mode']
  startId: string | null
  controlPoints: readonly (readonly [number, number, number])[]
}

interface SceneEditor {
  selectedPointId: string
  selectedRouteId: string | null
  routeDraft: RouteDraftView
  phase: 'scale' | 'points' | 'routes'
  activePointId?: string
  calibratedPointIds?: readonly string[]
  routeGuide?: { fromId: string, toId: string }
  onSelectPoint: (id: string) => void
  onSelectRoute: (id: string) => void
  onMovePoint: (id: string, position: readonly [number, number, number]) => void
  onMoveWaypoint: (routeId: string, index: number, position: readonly [number, number, number]) => void
  onAddCurvePoint: (position: readonly [number, number, number]) => void
}

interface WorkshopSceneProps {
  members: readonly WorkspaceMember[]
  selectedId: string | null
  onSelect: (id: string) => void
  label: string
  layout: LookseekLayout
  editor?: SceneEditor
  resetCameraToken: number
}

const palette = [0x2e8b7b, 0x3f7ec1, 0xc76d55, 0xd29a42]

const pointLabelText: Record<string, string> = {
  receive: '收到任务', plan: '整理计划', read: '查看资料', edit: '修改文件', shell: '执行命令',
  web: '检查网页', verify: '验证变更', approval: '等待确认', repair: '正在修复', idle: '待命', complete: '任务完成',
}

const pointStationText: Record<string, string> = {
  intake: '收件台', planning: '计划墙', library: '资料架', code: '代码桌', terminal: '终端台',
  window: '观察窗', validation: '验证台', approval: '确认灯', repair: '维修台', lounge: '休息角', delivery: '交付柜',
}

function vector(position: readonly [number, number, number]): THREE.Vector3 {
  return new THREE.Vector3(position[0], position[1], position[2])
}

interface RobotMaterials {
  shell: THREE.MeshPhysicalMaterial
  chrome: THREE.MeshPhysicalMaterial
  glass: THREE.MeshPhysicalMaterial
  dark: THREE.MeshStandardMaterial
  accent: THREE.MeshPhysicalMaterial
  light: THREE.MeshStandardMaterial
}

interface RobotScreen {
  id: string
  context: CanvasRenderingContext2D
  texture: THREE.CanvasTexture
  eyes: THREE.Group
  eyelids: THREE.Group
  sleep: THREE.Sprite
  frame: number
  working: boolean
}

interface WorkerOverlay {
  card: CSS2DObject
  cardName: HTMLSpanElement
  cardActivity: HTMLSpanElement
  cardState: HTMLSpanElement
  speech: CSS2DObject
  speechText: HTMLSpanElement
  status: THREE.Sprite
  statusContext: CanvasRenderingContext2D
  statusTexture: THREE.CanvasTexture
  phrase: string
}

interface RobotRig {
  torso: THREE.Mesh
  head: THREE.Mesh
  paper: THREE.Mesh
  deskProps: THREE.Group
}

interface WorkerActor {
  group: THREE.Group
  screen: RobotScreen
  overlay: WorkerOverlay
  rig: RobotRig
  destination: THREE.Vector3
  route: THREE.Vector3[]
  routeIndex: number
  stationId: string
  travelTarget: string | null
  completionDelivered: boolean
  wasRunning: boolean
  lastActivity: string
}

const workPhrases = {
  plan: ['先把任务拆成几步。', '我在整理这一步的顺序。'],
  edit: ['这一处改动正在落盘。', '我在对照文件调整。'],
  read: ['我在核对相关资料。', '这份内容值得再看一遍。'],
  shell: ['命令正在稳定执行。', '我在等这一轮结果。'],
  verify: ['验证流程正在跑。', '我在检查结果是否一致。'],
  web: ['我在核对网页信息。', '这个页面还在检查中。'],
  default: ['我在处理当前任务。', '这一步正在推进。'],
} as const

const interactionPhrases = {
  hover: [
    '别盯太久，我会紧张地多敲两下。', '状态正常，咖啡也正常。', '这盏灯亮着，说明我还在。', '进度在走，我也在走。',
    '这一行不是装饰，它真的在工作。', '先别急，正在把细节归位。', '我把复杂的部分放在队列前面。', '键盘声不大，结果声会更响。',
    '任务已收到，手部动作已同步。', '我没有摸鱼，屏幕可以作证。', '这一步过了，下一步就顺了。', '今天的错误也会按流程处理。',
    '别担心，日志正在替我记笔记。', '我在和问题讲道理。', '这个角落的效率一直在线。', '先把路径走对，再谈速度。',
    '屏幕亮着，是因为事情还没讲完。', '我正在给答案做最后检查。', '这份任务比看起来更有条理。', '收到注视，专注度上调一点点。',
    '刚才那一下，是认真不是卡顿。', '我会把每一步放在该在的位置。', '进度条很诚实，只是话不多。', '资料已翻开，重点正在靠近。',
    '我先把麻烦分类，再逐个解决。', '别催，好的结果需要落到实处。', '终端没有情绪，我有一点耐心。', '这台工位只生产可靠的下一步。',
    '当前状态：看起来平静，实际很忙。', '我在等一个值得等待的结果。', '任务纸没丢，流程也没断。', '这一段走完，就离交付更近了。',
    '我在把不确定变成可验证。', '今天的待办，正在逐项变短。', '不是魔法，是按顺序完成。', '有问题就修，有结果就交。',
    '我的工具腰包里装着下一步。', '保持观察，事情正在推进。', '这次点击已被认真接收。', '请放心，路线没有偷懒。',
  ],
  click: ['收到围观，继续把这一步做完。', '点击确认：仍在认真工作。', '这次交互已记入我的专注清单。', '指令已收到，继续推进。'],
} as const

function safeText(text: string, maximum: number): string {
  return text.length > maximum ? `${text.slice(0, maximum - 1)}…` : text
}

function canvasSprite(width: number, height: number): { sprite: THREE.Sprite, context: CanvasRenderingContext2D, texture: THREE.CanvasTexture } {
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const context = canvas.getContext('2d')
  if (context === null) throw new Error('Unable to create worker overlay canvas')
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.minFilter = THREE.LinearFilter
  texture.magFilter = THREE.LinearFilter
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false }))
  return { sprite, context, texture }
}

function drawCard(overlay: WorkerOverlay, member: WorkspaceMember): void {
  overlay.cardName.textContent = safeText(member.name, 10)
  overlay.cardActivity.textContent = activityLabel(member.intent)
  overlay.cardState.textContent = memberStateLabel(member)
  overlay.card.element.dataset.running = String(member.running)
}

function drawSpeech(overlay: WorkerOverlay, phrase: string): void {
  overlay.speechText.textContent = safeText(phrase, 28)
}

function drawStatus(overlay: WorkerOverlay, member: WorkspaceMember, phase: number): void {
  const { statusContext: context, statusTexture: texture } = overlay
  context.clearRect(0, 0, 70, 70)
  if (!member.running) {
    texture.needsUpdate = true
    return
  }
  const slow = Date.now() - member.intent.at > 45_000
  if (slow && phase % 2 === 1) {
    texture.needsUpdate = true
    return
  }
  context.font = '48px sans-serif'
  context.fillText(slow ? '⚡' : '☕', 10, 50)
  texture.needsUpdate = true
}

function overlaysFor(member: WorkspaceMember): WorkerOverlay {
  const cardElement = document.createElement('div')
  cardElement.className = 'lookseekWorkerTag'
  const cardPanel = document.createElement('div')
  cardPanel.className = 'lookseekWorkerTagPanel'
  const cardName = document.createElement('span')
  cardName.className = 'lookseekWorkerTagName'
  const cardActivity = document.createElement('span')
  cardActivity.className = 'lookseekWorkerTagActivity'
  const cardState = document.createElement('span')
  cardState.className = 'lookseekWorkerTagState'
  cardPanel.append(cardName, cardActivity, cardState)
  cardElement.append(cardPanel)
  const card = new CSS2DObject(cardElement)
  card.position.set(0, 2.06, 0.04)
  const speechElement = document.createElement('div')
  speechElement.className = 'lookseekWorkerSpeech'
  const speechText = document.createElement('span')
  speechText.className = 'lookseekWorkerSpeechText'
  speechText.style.cssText = 'position:relative;display:block;width:228px;box-sizing:border-box;transform:translate(-50%,-116%);padding:8px 11px;border:1px solid #2d7464;border-radius:6px;background:#f8fcfa;box-shadow:0 4px 12px rgb(0 0 0 / .22);color:#142e28;font:650 14px/1.45 system-ui,sans-serif;overflow-wrap:anywhere;text-align:left;'
  speechElement.append(speechText)
  const speech = new CSS2DObject(speechElement)
  speech.position.set(0, 2.76, 0.04)
  speech.visible = false
  const status = canvasSprite(70, 70)
  status.sprite.position.set(0.67, 1.92, 0.06)
  status.sprite.scale.set(0.33, 0.33, 1)
  const overlay = {
    card,
    cardName,
    cardActivity,
    cardState,
    speech,
    speechText,
    status: status.sprite,
    statusContext: status.context,
    statusTexture: status.texture,
    phrase: '',
  }
  drawCard(overlay, member)
  drawSpeech(overlay, '')
  drawStatus(overlay, member, 0)
  return overlay
}

function phraseFor(member: WorkspaceMember, serial: number): string {
  if (serial % 2 === 0 && member.intent.summary !== '') {
    return `${activityLabel(member.intent)}：${safeText(member.intent.summary, 18)}`
  }
  const activity = member.intent.activity
  const phrases = workPhrases[activity === 'plan' || activity === 'edit' || activity === 'read' || activity === 'shell' || activity === 'verify' || activity === 'web' ? activity : 'default']
  return phrases[serial % phrases.length] ?? ''
}

function materialsFor(accent: number): RobotMaterials {
  return {
    shell: new THREE.MeshPhysicalMaterial({ color: 0xdfe9e8, metalness: 0.7, roughness: 0.2, clearcoat: 1, clearcoatRoughness: 0.11 }),
    chrome: new THREE.MeshPhysicalMaterial({ color: 0x52616b, metalness: 0.96, roughness: 0.16 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0x020a12, metalness: 0.78, roughness: 0.08, clearcoat: 1 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x10191d, metalness: 0.62, roughness: 0.3 }),
    accent: new THREE.MeshPhysicalMaterial({ color: accent, metalness: 0.58, roughness: 0.18, clearcoat: 0.8 }),
    light: new THREE.MeshStandardMaterial({ color: 0x168cff, emissive: 0x0769ff, emissiveIntensity: 2.8, roughness: 0.22 }),
  }
}

function limb(from: THREE.Vector3, to: THREE.Vector3, material: THREE.Material, radius = 0.075): THREE.Mesh {
  const vector = to.clone().sub(from)
  const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(radius, Math.max(vector.length() - radius * 2, 0.01), 8, 16), material)
  mesh.position.copy(from).add(to).multiplyScalar(0.5)
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), vector.normalize())
  return mesh
}

function sleepBadge(): THREE.Sprite {
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 64
  const context = canvas.getContext('2d')
  if (context === null) throw new Error('Unable to create the sleep indicator canvas')
  context.fillStyle = '#f4cb5c'
  context.beginPath()
  context.moveTo(35, 4)
  context.lineTo(12, 35)
  context.lineTo(29, 35)
  context.lineTo(23, 60)
  context.lineTo(52, 23)
  context.lineTo(35, 23)
  context.closePath()
  context.fill()
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthWrite: false }))
  sprite.position.set(0, 1.95, 0.08)
  sprite.scale.set(0.32, 0.32, 1)
  return sprite
}

function drawMonitor(screen: RobotScreen, working: boolean): void {
  const { context } = screen
  context.fillStyle = '#020609'
  context.fillRect(0, 0, 128, 72)
  if (!working) {
    screen.texture.needsUpdate = true
    return
  }
  const offset = screen.frame % 5
  context.fillStyle = '#071d25'
  context.fillRect(5, 6, 118, 12)
  context.fillStyle = '#1ee6c8'
  context.font = '8px monospace'
  context.fillText('BUILD  RUNNING', 10, 15)
  const lines = ['> verify workspace', '> write changes', '> test status ok', '> sync results', '> package output']
  for (let index = 0; index < 4; index += 1) {
    context.fillStyle = index === 3 ? '#54a8ff' : '#a5d8ce'
    context.fillText(lines[(index + offset) % lines.length] ?? '', 9, 30 + index * 9)
  }
  context.fillStyle = '#1ee6c8'
  context.fillRect(8, 61, 80 + (offset % 3) * 12, 3)
  screen.frame += 1
  screen.texture.needsUpdate = true
}

function seatedRobot(id: string, accent: number): { group: THREE.Group, screen: RobotScreen, rig: RobotRig } {
  const group = new THREE.Group()
  group.name = id
  const materials = materialsFor(accent)

  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.43, 24, 18), materials.shell)
  torso.scale.set(1, 0.9, 0.74)
  torso.position.y = 0.82
  const chest = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.035, 12, 28, Math.PI * 1.45), materials.accent)
  chest.rotation.set(Math.PI / 2, 0, Math.PI * 0.78)
  chest.position.set(0, 0.82, 0.33)
  group.add(torso, chest)

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.48, 32, 22), materials.shell)
  head.scale.set(1.08, 0.78, 0.8)
  head.position.y = 1.35
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.29, 0.08), materials.glass)
  visor.position.set(0, 1.35, 0.39)
  const earGeometry = new THREE.CylinderGeometry(0.13, 0.13, 0.075, 20)
  const leftEar = new THREE.Mesh(earGeometry, materials.chrome)
  leftEar.rotation.z = Math.PI / 2
  leftEar.position.set(-0.52, 1.35, 0)
  const rightEar = leftEar.clone()
  rightEar.position.x = 0.52
  group.add(head, visor, leftEar, rightEar)

  const eyes = new THREE.Group()
  for (const x of [-0.15, 0.15]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.065, 16, 12), materials.light)
    eye.position.set(x, 1.37, 0.45)
    eyes.add(eye)
  }
  const eyelids = new THREE.Group()
  for (const x of [-0.15, 0.15]) {
    const lid = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.018, 0.025), materials.chrome)
    lid.position.set(x, 1.37, 0.45)
    eyelids.add(lid)
  }
  group.add(eyes, eyelids)

  for (const side of [-1, 1]) {
    const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 12), materials.chrome)
    shoulder.position.set(side * 0.42, 0.95, 0.03)
    const elbow = new THREE.Vector3(side * 0.34, 0.68, 0.2)
    const hand = new THREE.Vector3(side * 0.18, 0.54, 0.38)
    group.add(shoulder, limb(shoulder.position, elbow, materials.shell), limb(elbow, hand, materials.shell, 0.06))
    const palm = new THREE.Mesh(new THREE.SphereGeometry(0.075, 12, 10), materials.shell)
    palm.position.copy(hand)
    group.add(palm)
    const hip = new THREE.Vector3(side * 0.2, 0.63, -0.05)
    const knee = new THREE.Vector3(side * 0.2, 0.39, 0.11)
    const foot = new THREE.Vector3(side * 0.2, 0.19, 0.24)
    group.add(limb(hip, knee, materials.shell), limb(knee, foot, materials.shell, 0.07))
    const shoe = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), materials.chrome)
    shoe.scale.set(0.8, 0.45, 1.35)
    shoe.position.copy(foot)
    group.add(shoe)
  }

  const keyboard = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.035, 0.18), materials.dark)
  keyboard.position.set(0, 0.49, 0.39)
  const monitorCase = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.39, 0.06), materials.chrome)
  monitorCase.position.set(0, 0.79, 0.58)
  const canvas = document.createElement('canvas')
  canvas.width = 128
  canvas.height = 72
  const context = canvas.getContext('2d')
  if (context === null) throw new Error('Unable to create the workstation monitor canvas')
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  const screenMaterial = new THREE.MeshBasicMaterial({ map: texture })
  const monitor = new THREE.Mesh(new THREE.PlaneGeometry(0.58, 0.33), screenMaterial)
  monitor.position.set(0, 0.79, 0.616)
  const deskProps = new THREE.Group()
  deskProps.add(keyboard, monitorCase, monitor)
  const paper = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.018, 0.2), new THREE.MeshStandardMaterial({ color: 0xf1cf6b, roughness: 0.72 }))
  paper.position.set(0.32, 0.57, 0.34)
  paper.rotation.y = -0.24
  group.add(deskProps, paper)
  const sleep = sleepBadge()
  group.add(sleep)
  const screen = { id, context, texture, eyes, eyelids, sleep, frame: 0, working: false }
  drawMonitor(screen, false)
  return { group, screen, rig: { torso, head, paper, deskProps } }
}

/** Render the licensed GLB workshop once and update only worker transforms afterwards. */
export function WorkshopScene({ members, selectedId, onSelect, label, layout, editor, resetCameraToken }: WorkshopSceneProps) {
  const host = useRef<HTMLDivElement>(null)
  const membersRef = useRef(members)
  const selectedIdRef = useRef(selectedId)
  const layoutRef = useRef(layout)
  const editorRef = useRef(editor)
  const renderRef = useRef<(() => void) | null>(null)
  const resetCameraRef = useRef<(() => void) | null>(null)
  const memberKey = members.map(member => member.id).join('\u0000')
  membersRef.current = members
  selectedIdRef.current = selectedId
  layoutRef.current = layout
  editorRef.current = editor

  useEffect(() => { renderRef.current?.() }, [members, selectedId, layout, editor])
  useEffect(() => { resetCameraRef.current?.() }, [resetCameraToken])

  useEffect(() => {
    const container = host.current
    if (container === null) return
    const scene = new THREE.Scene()
    const camera = new THREE.OrthographicCamera(-8, 8, 6, -6, 0.1, 80)
    camera.position.set(12, 15, 15)
    camera.lookAt(0, 0, 0)
    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true, powerPreference: 'low-power' })
    renderer.shadowMap.enabled = false
    renderer.setPixelRatio(1)
    renderer.setClearColor(0x000000, 0)
    const labelRenderer = new CSS2DRenderer()
    labelRenderer.domElement.className = 'lookseekLabels'
    container.replaceChildren(renderer.domElement, labelRenderer.domElement)
    const controls = new OrbitControls(camera, renderer.domElement)
    controls.enablePan = false
    controls.enableDamping = false
    controls.minZoom = 0.75
    controls.maxZoom = 1.65
    controls.rotateSpeed = 0.48
    controls.zoomSpeed = 0.7
    const homeCameraPosition = camera.position.clone()
    let homeZoom = camera.zoom
    scene.add(new THREE.HemisphereLight(0x9fc4bb, 0x584338, 2.1))
    const key = new THREE.DirectionalLight(0xffd29c, 2.4)
    key.position.set(-6, 11, 5)
    key.castShadow = true
    scene.add(key)

    let disposed = false

    const people = new Map<string, THREE.Group>()
    const screens = new Map<string, RobotScreen>()
    const overlays = new Map<string, WorkerOverlay>()
    const actors = new Map<string, WorkerActor>()
    const pointFor = (member: WorkspaceMember): LookseekLayout['points'][number] | undefined => {
      const activity = member.intent.activity === 'handoff' ? 'complete' : member.intent.activity
      return layoutRef.current.points.find(point => point.activity === activity)
        ?? layoutRef.current.points.find(point => point.id === member.intent.target)
    }
    for (const [index, member] of members.entries()) {
      const point = pointFor(member)
      const departurePoint = !member.running && (member.completed || member.intent.activity === 'complete')
        ? layoutRef.current.points.find(value => value.activity === 'idle') ?? point
        : point
      const { group: person, screen, rig } = seatedRobot(member.id, palette[index % palette.length] ?? 0x2e8b7b)
      person.position.copy(departurePoint === undefined ? new THREE.Vector3(0, 0.05, 0) : vector(departurePoint.position))
      person.rotation.y = departurePoint?.facing ?? 0
      const overlay = overlaysFor(member)
      person.add(overlay.card, overlay.speech, overlay.status)
      scene.add(person)
      people.set(member.id, person)
      screens.set(member.id, screen)
      overlays.set(member.id, overlay)
      actors.set(member.id, {
        group: person, screen, overlay, rig, destination: person.position.clone(),
        route: [person.position.clone()], routeIndex: 1, stationId: departurePoint?.id ?? '', travelTarget: null,
        completionDelivered: !member.running && (member.completed || member.intent.activity === 'complete'),
        // A mounted active session is treated as a fresh visual turn. Its
        // first visible position is always the intake station.
        wasRunning: false, lastActivity: '',
      })
    }

    const raycaster = new THREE.Raycaster()
    const pointer = new THREE.Vector2()
    const editorGroup = new THREE.Group()
    const editorTargets: THREE.Object3D[] = []
    const ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.06)
    const groundHit = new THREE.Vector3()
    let editorSignature = ''
    let previewPoint: THREE.Vector3 | undefined
    const scenePosition = (event: PointerEvent): THREE.Vector3 | undefined => {
      const bounds = renderer.domElement.getBoundingClientRect()
      pointer.x = ((event.clientX - bounds.left) / bounds.width) * 2 - 1
      pointer.y = -((event.clientY - bounds.top) / bounds.height) * 2 + 1
      raycaster.setFromCamera(pointer, camera)
      return raycaster.ray.intersectPlane(ground, groundHit) === null ? undefined : groundHit.clone()
    }
    const routeVectors = (route: LayoutRoute): THREE.Vector3[] => {
      return route.points.map(vector)
    }
    const syncEditor = (): void => {
      const activeEditor = editorRef.current
      const activeLayout = layoutRef.current
      const signature = activeEditor === undefined ? '' : JSON.stringify([activeLayout, activeEditor.selectedPointId, activeEditor.selectedRouteId, activeEditor.routeDraft, previewPoint?.toArray()])
      if (signature === editorSignature) return
      editorSignature = signature
      editorGroup.clear()
      editorTargets.length = 0
      if (activeEditor === undefined) return
      const editablePoints = activeEditor.phase === 'points'
        ? activeLayout.points.filter(point => activeEditor.calibratedPointIds?.includes(point.id))
        : activeLayout.points
      for (const point of editablePoints) {
        const selected = point.id === activeEditor.selectedPointId || point.id === activeEditor.routeDraft.startId
        const isRouteStart = point.id === activeEditor.routeGuide?.fromId
        const isRouteEnd = point.id === activeEditor.routeGuide?.toId
        const marker = new THREE.Mesh(new THREE.SphereGeometry(selected || isRouteStart || isRouteEnd ? 0.15 : 0.1, 16, 12), new THREE.MeshBasicMaterial({ color: selected || isRouteStart ? 0xffd25e : isRouteEnd ? 0x53d8c5 : 0x739e94, transparent: true, opacity: selected || isRouteStart || isRouteEnd ? 0.95 : 0.46, depthTest: false }))
        marker.position.copy(vector(point.position)).setY(point.position[1] + 0.12)
        marker.renderOrder = 4
        marker.userData = { kind: 'point', pointId: point.id }
        editorGroup.add(marker)
        editorTargets.push(marker)
        const labelElement = document.createElement('div')
        labelElement.className = `lookseekRoutePointLabel${selected ? ' lookseekRoutePointLabelActive' : ''}`
        labelElement.textContent = `${isRouteStart ? '起点 · ' : isRouteEnd ? '下一点 · ' : ''}${pointStationText[point.id] ?? point.id} · ${pointLabelText[point.activity] ?? point.activity}`
        labelElement.style.cssText = `transform:translate(-50%,-100%);padding:4px 7px;border:1px solid ${selected || isRouteStart ? '#ffd468' : isRouteEnd ? '#6ee3d0' : 'rgb(222 247 240 / .68)'};border-radius:4px;background:${selected || isRouteStart ? 'rgb(71 51 13 / .92)' : 'rgb(12 33 29 / .88)'};color:${selected || isRouteStart ? '#fff5cf' : '#edf9f5'};box-shadow:0 3px 10px rgb(0 0 0 / .24);font:700 12px/1.2 system-ui,sans-serif;white-space:nowrap;pointer-events:none;`
        const pointLabel = new CSS2DObject(labelElement)
        pointLabel.position.copy(vector(point.position)).setY(point.position[1] + 0.34)
        editorGroup.add(pointLabel)
      }
      for (const route of activeEditor.phase === 'routes' ? activeLayout.routes : []) {
        const selected = route.id === activeEditor.selectedRouteId
        const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(routeVectors(route)), new THREE.LineBasicMaterial({ color: selected ? 0xffcc5d : 0x78d8c0, transparent: true, opacity: selected ? 1 : 0.7, depthTest: false }))
        line.renderOrder = 3
        line.userData = { kind: 'route', routeId: route.id }
        editorGroup.add(line)
        for (let index = 1; index < route.points.length - 1; index += 1) {
          const waypoint = new THREE.Mesh(new THREE.OctahedronGeometry(0.08), new THREE.MeshBasicMaterial({ color: 0xf8fbfa, depthTest: false }))
          waypoint.position.copy(vector(route.points[index]!)).setY(route.points[index]![1] + 0.1)
          waypoint.renderOrder = 5
          waypoint.userData = { kind: 'waypoint', routeId: route.id, index }
          editorGroup.add(waypoint)
          editorTargets.push(waypoint)
        }
      }
      const draft = activeEditor.routeDraft
      const start = draft.startId === null ? undefined : activeLayout.points.find(point => point.id === draft.startId)
      if (start !== undefined && previewPoint !== undefined) {
        const preview = [vector(start.position), ...draft.controlPoints.map(vector), previewPoint]
        const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(draft.mode === 'spline' && preview.length > 2 ? new THREE.CatmullRomCurve3(preview).getPoints(24) : preview), new THREE.LineDashedMaterial({ color: 0xffd25e, dashSize: 0.11, gapSize: 0.08, transparent: true, opacity: 0.9, depthTest: false }))
        line.computeLineDistances()
        line.renderOrder = 6
        editorGroup.add(line)
      }
    }
    scene.add(editorGroup)
    const personAt = (event: PointerEvent): string | undefined => {
      const bounds = renderer.domElement.getBoundingClientRect()
      pointer.x = ((event.clientX - bounds.left) / bounds.width) * 2 - 1
      pointer.y = -((event.clientY - bounds.top) / bounds.height) * 2 + 1
      raycaster.setFromCamera(pointer, camera)
      const hit = raycaster.intersectObjects([...people.values()], true)[0]
      let target = hit?.object
      while (target !== undefined && target.parent !== null && !people.has(target.name)) target = target.parent
      return target !== undefined && people.has(target.name) ? target.name : undefined
    }
    let speak = (_id: string, _kind: keyof typeof interactionPhrases): void => undefined
    const click = (event: PointerEvent): void => {
      const target = personAt(event)
      if (target === undefined) return
      onSelect(target)
      speak(target, 'click')
    }
    let pointerDown: readonly [number, number] | undefined
    let dragged: { kind: 'point', pointId: string } | { kind: 'waypoint', routeId: string, index: number } | undefined
    const editorAt = (event: PointerEvent): THREE.Object3D | undefined => {
      if (editorRef.current === undefined) return undefined
      const bounds = renderer.domElement.getBoundingClientRect()
      pointer.x = ((event.clientX - bounds.left) / bounds.width) * 2 - 1
      pointer.y = -((event.clientY - bounds.top) / bounds.height) * 2 + 1
      raycaster.setFromCamera(pointer, camera)
      return raycaster.intersectObjects(editorTargets, false)[0]?.object
    }
    let hoveredId: string | undefined
    const beginPointer = (event: PointerEvent): void => {
      const activeEditor = editorRef.current
      if (activeEditor !== undefined) {
        if (event.button === 2) {
          const hit = scenePosition(event)
          if (hit !== undefined) activeEditor.onAddCurvePoint([hit.x, hit.y, hit.z])
          event.preventDefault()
          return
        }
        const hit = editorAt(event)
        if (hit?.userData.kind === 'point') {
          activeEditor.onSelectPoint(hit.userData.pointId as string)
          dragged = { kind: 'point', pointId: hit.userData.pointId as string }
          controls.enabled = false
          event.preventDefault()
          return
        }
        if (hit?.userData.kind === 'waypoint') {
          activeEditor.onSelectRoute(hit.userData.routeId as string)
          dragged = { kind: 'waypoint', routeId: hit.userData.routeId as string, index: hit.userData.index as number }
          controls.enabled = false
          event.preventDefault()
          return
        }
      }
      pointerDown = [event.clientX, event.clientY]
    }
    const endPointer = (event: PointerEvent): void => {
      if (dragged !== undefined) {
        dragged = undefined
        controls.enabled = true
        return
      }
      const start = pointerDown
      pointerDown = undefined
      if (start !== undefined && Math.hypot(event.clientX - start[0], event.clientY - start[1]) < 6) click(event)
    }
    const movePointer = (event: PointerEvent): void => {
      const activeEditor = editorRef.current
      if (dragged !== undefined && activeEditor !== undefined) {
        const hit = scenePosition(event)
        if (hit !== undefined) {
          const position: readonly [number, number, number] = [hit.x, Math.max(0.05, hit.y), hit.z]
          if (dragged.kind === 'point') activeEditor.onMovePoint(dragged.pointId, position)
          else activeEditor.onMoveWaypoint(dragged.routeId, dragged.index, position)
        }
        return
      }
      if (activeEditor !== undefined) {
        previewPoint = scenePosition(event)
        renderer.domElement.style.cursor = editorAt(event) === undefined ? 'crosshair' : 'grab'
        renderRef.current?.()
        return
      }
      const target = personAt(event)
      renderer.domElement.style.cursor = target === undefined ? 'grab' : 'pointer'
      if (target !== undefined && target !== hoveredId && Math.random() < 0.8) speak(target, 'hover')
      hoveredId = target
    }
    renderer.domElement.addEventListener('pointerdown', beginPointer)
    renderer.domElement.addEventListener('pointerup', endPointer)
    renderer.domElement.addEventListener('pointermove', movePointer)
    renderer.domElement.addEventListener('contextmenu', event => { if (editorRef.current !== undefined) event.preventDefault() })

    const focus = new THREE.Vector3()
    let focusedId: string | null = null
    const initialMember = members.find(member => member.running) ?? members[0]
    const initialActor = initialMember === undefined ? undefined : actors.get(initialMember.id)
    if (initialActor !== undefined && initialMember !== undefined) {
      focus.copy(initialActor.group.position)
      controls.target.copy(focus)
      focusedId = initialMember.id
    }
    let statusPhase = 0
    let focusFrame: number | undefined
    let motionFrame: number | undefined
    let motionAt = performance.now()
    const renderScene = (): void => {
      syncEditor()
      renderer.render(scene, camera)
      labelRenderer.render(scene, camera)
    }
    resetCameraRef.current = () => {
      camera.position.copy(homeCameraPosition)
      camera.zoom = homeZoom
      controls.target.set(0, 0, 0)
      camera.updateProjectionMatrix()
      controls.update()
      renderScene()
    }
    const routeBetween = (from: string, to: string): THREE.Vector3[] | undefined => {
      if (layoutRef.current.routesNeedCalibration) return undefined
      interface Edge { from: string, to: string, points: THREE.Vector3[] }
      const forwardEdges: Edge[] = []
      const reverseEdges: Edge[] = []
      for (const route of layoutRef.current.routes) {
        // The authored points are a physical corridor. Sampling a smooth
        // curve between them can cut a corner through the imported model.
        const points = route.points.map(vector)
        forwardEdges.push({ from: route.from, to: route.to, points })
        reverseEdges.push({ from: route.to, to: route.from, points: [...points].reverse() })
      }
      const findPath = (edges: readonly Edge[]): THREE.Vector3[] | undefined => {
      const previous = new Map<string, Edge>()
      const pending = [from]
      const visited = new Set(pending)
      while (pending.length > 0) {
        const current = pending.shift()!
        if (current === to) break
        for (const edge of edges) {
          if (edge.from !== current || visited.has(edge.to)) continue
          previous.set(edge.to, edge)
          visited.add(edge.to)
          pending.push(edge.to)
        }
      }
      if (!visited.has(to)) return undefined
      const segments: THREE.Vector3[][] = []
      for (let current = to; current !== from;) {
        const edge = previous.get(current)
        if (edge === undefined) return undefined
        segments.unshift(edge.points)
        current = edge.from
      }
      return segments.flatMap((points, index) => index === 0 ? points : points.slice(1))
      }
      // The authoring order describes the normal work flow. Do not let a
      // reverse corridor turn an intake-to-delivery trip into a shortcut.
      return findPath(forwardEdges) ?? findPath([...forwardEdges, ...reverseEdges])
    }
    const updateActors = (time: number): boolean => {
      const deltaSeconds = Math.min((time - motionAt) / 1_000, 0.1)
      motionAt = time
      let moving = false
      for (const [id, actor] of actors) {
        const member = membersRef.current.find(value => value.id === id)
        if (member === undefined) continue
        const reportedPoint = pointFor(member)
        const intakePoint = layoutRef.current.points.find(point => point.activity === 'receive')
        const beginsTurn = member.running && (!actor.wasRunning || (member.intent.activity === 'receive' && actor.lastActivity !== 'receive'))
        if (beginsTurn && intakePoint !== undefined) {
          // Starting a turn has no inherited physical route. The user sees
          // the worker receive it at the intake desk, then later movements
          // follow only the authored route graph.
          actor.group.position.copy(vector(intakePoint.position))
          actor.group.rotation.y = intakePoint.facing
          actor.route = [actor.group.position.clone()]
          actor.routeIndex = 1
          actor.stationId = intakePoint.id
          actor.travelTarget = null
          actor.completionDelivered = false
        }
        const completionPoint = layoutRef.current.points.find(point => point.activity === 'complete')
        const idlePoint = layoutRef.current.points.find(point => point.activity === 'idle')
        const completing = member.completed || member.intent.activity === 'complete'
        if (!completing) actor.completionDelivered = false
        if (completing && !member.running && completionPoint !== undefined && actor.stationId === completionPoint.id && actor.travelTarget === null) {
          actor.completionDelivered = true
        }
        const nextPoint = completing && actor.completionDelivered && idlePoint !== undefined ? idlePoint : reportedPoint
        if (nextPoint === undefined) continue
        if (actor.travelTarget === null && actor.stationId !== nextPoint.id) {
          const route = routeBetween(actor.stationId, nextPoint.id)
          if (route !== undefined) {
            actor.route = route
            actor.routeIndex = 1
            actor.travelTarget = nextPoint.id
          }
        }
        actor.destination.copy(actor.route[actor.routeIndex] ?? actor.group.position)
        const offset = actor.destination.clone().sub(actor.group.position)
        offset.y = 0
        const distance = offset.length()
        let isMoving = actor.routeIndex < actor.route.length || distance > 0.025
        if (isMoving) {
          // Movement is bounded in time. A finished conversation must never
          // wait for an old visual transition to converge.
          const speed = member.running ? 8 : 14
          const travel = speed * deltaSeconds
          if (distance <= travel) {
            actor.group.position.copy(actor.destination)
            actor.routeIndex += 1
          } else {
            actor.group.position.addScaledVector(offset.normalize(), travel)
          }
          actor.group.position.y = actor.destination.y
          isMoving = actor.routeIndex < actor.route.length
          if (!isMoving && actor.travelTarget !== null) {
            actor.stationId = actor.travelTarget
            actor.travelTarget = null
          }
          actor.group.rotation.y = isMoving
            ? THREE.MathUtils.damp(actor.group.rotation.y, Math.atan2(offset.x, offset.z), 10, deltaSeconds)
            : nextPoint.facing
          moving = true
        } else {
          actor.group.position.copy(actor.route.at(-1) ?? actor.group.position)
          actor.group.rotation.y = nextPoint.facing
        }
        const active = member.running && !isMoving
        const rhythm = active ? Math.sin(time / (member.intent.activity === 'shell' ? 115 : 220)) : 0
        actor.rig.head.rotation.x = active && member.intent.activity === 'read' ? rhythm * 0.16 : rhythm * 0.055
        actor.rig.torso.rotation.z = active && member.intent.activity === 'edit' ? rhythm * 0.035 : 0
        actor.rig.deskProps.visible = !isMoving
        actor.rig.paper.visible = member.running && ['receive', 'plan', 'read', 'handoff', 'complete'].includes(member.intent.activity)
        if (isMoving) actor.rig.paper.visible = true
        actor.wasRunning = member.running
        actor.lastActivity = member.intent.activity
      }
      return moving
    }
    const scheduleMotion = (): void => {
      if (motionFrame !== undefined) return
      motionAt = performance.now()
      const animate = (time: number): void => {
        const moving = updateActors(time)
        renderScene()
        if (moving) motionFrame = window.requestAnimationFrame(animate)
        else motionFrame = undefined
      }
      motionFrame = window.requestAnimationFrame(animate)
    }
    const render = (): void => {
      const activeId = selectedIdRef.current ?? initialMember?.id ?? null
      const selected = activeId === null ? undefined : people.get(activeId)
      if (activeId !== focusedId) {
        const priorFocus = focus.clone()
        const nextFocus = selected?.position.clone() ?? new THREE.Vector3()
        const priorCamera = camera.position.clone()
        const nextCamera = priorCamera.clone().add(nextFocus.clone().sub(priorFocus))
        if (focusFrame !== undefined) window.cancelAnimationFrame(focusFrame)
        focus.copy(nextFocus)
        focusedId = activeId
        const startedAt = performance.now()
        const animateFocus = (time: number): void => {
          const progress = Math.min(1, (time - startedAt) / 260)
          const eased = 1 - (1 - progress) ** 3
          camera.position.lerpVectors(priorCamera, nextCamera, eased)
          controls.target.lerpVectors(priorFocus, nextFocus, eased)
          controls.update()
          renderScene()
          if (progress < 1) focusFrame = window.requestAnimationFrame(animateFocus)
          else focusFrame = undefined
        }
        focusFrame = window.requestAnimationFrame(animateFocus)
      }
      for (const [id, person] of people) {
        const screen = screens.get(id)
        const overlay = overlays.get(id)
        const member = membersRef.current.find(value => value.id === id)
        if (screen !== undefined && member !== undefined) {
          const working = member?.running ?? false
          screen.eyes.visible = working
          screen.eyelids.visible = !working
          screen.sleep.visible = !working
          if (screen.working !== working) {
            screen.working = working
            drawMonitor(screen, working)
          }
        }
        if (overlay !== undefined && member !== undefined) {
          drawCard(overlay, member)
          drawStatus(overlay, member, statusPhase)
        }
        person.visible = editorRef.current === undefined
        person.scale.setScalar(id === activeId ? 0.66 : 0.58)
      }
      scheduleMotion()
      renderScene()
    }
    speak = (id, kind): void => {
      const overlay = overlays.get(id)
      if (overlay === undefined) return
      const phrases = interactionPhrases[kind]
      overlay.phrase = phrases[Math.floor(Math.random() * phrases.length)] ?? ''
      overlay.speech.visible = overlay.phrase !== ''
      drawSpeech(overlay, overlay.phrase)
      render()
    }
    // Orbiting the camera only repaints the scene. It must never advance
    // actor state or recompute a worker's facing direction.
    controls.addEventListener('change', renderScene)
    renderRef.current = render
    const resize = (): void => {
      const bounds = container.getBoundingClientRect()
      const width = Math.max(1, Math.min(Math.floor(bounds.width), 1_920))
      const height = Math.max(1, Math.min(Math.floor(bounds.height), 1_080))
      const aspect = width / Math.max(height, 1)
      camera.left = -5.5 * aspect
      camera.right = 5.5 * aspect
      // Wide dashboard layouts otherwise make the workshop look like a tiny thumbnail.
      camera.zoom = THREE.MathUtils.clamp(aspect / 1.65, 1, 1.45)
      homeZoom = camera.zoom
      camera.updateProjectionMatrix()
      renderer.setSize(width, height, false)
      labelRenderer.setSize(width, height)
      render()
    }
    const observer = new ResizeObserver(resize)
    observer.observe(container)
    resize()

    const loader = new GLTFLoader()
    const sceneUrl = layoutRef.current.sceneAsset === 'custom'
      ? `/dsh-lookseek/assets/custom-scene.glb?revision=${encodeURIComponent(layoutRef.current.sceneAssetName ?? 'custom')}`
      : '/dsh-lookseek/assets/office-workstations.glb?revision=workroom-20'
    loader.load(sceneUrl, ({ scene: workshop }) => {
      if (disposed) return
      const bounds = new THREE.Box3().setFromObject(workshop)
      const size = bounds.getSize(new THREE.Vector3())
      workshop.scale.setScalar((11 / Math.max(size.x, size.z, 0.01)) * (layoutRef.current.modelScale ?? 1))
      const scaled = new THREE.Box3().setFromObject(workshop)
      const center = scaled.getCenter(new THREE.Vector3())
      workshop.position.set(-center.x, -scaled.min.y, -center.z)
      scene.add(workshop)
      render()
    }, undefined, () => {
      // The worker markers and roster still present a usable static workspace when the optional asset is unavailable.
      render()
    })
    const tickScreens = (): void => {
      let updated = false
      statusPhase += 1
      for (const [id, screen] of screens) {
        const member = membersRef.current.find(value => value.id === id)
        if (member?.running) {
          drawMonitor(screen, true)
          updated = true
        }
      }
      if (updated) render()
    }
    const interval = window.setInterval(tickScreens, 750)
    let phraseSerial = 0
    const tickSpeech = (): void => {
      const active = membersRef.current.filter(member => member.running)
      for (const overlay of overlays.values()) {
        overlay.phrase = ''
        overlay.speech.visible = false
        drawSpeech(overlay, '')
      }
      const speaker = active[phraseSerial % active.length]
      if (speaker !== undefined) {
        const overlay = overlays.get(speaker.id)
        if (overlay !== undefined) {
          overlay.phrase = phraseFor(speaker, phraseSerial)
          overlay.speech.visible = true
          drawSpeech(overlay, overlay.phrase)
        }
      }
      phraseSerial += 1
      render()
    }
    const speechStart = window.setTimeout(tickSpeech, 1_600)
    const speechInterval = window.setInterval(tickSpeech, 8_000)
    return () => {
      disposed = true
      window.clearInterval(interval)
      if (focusFrame !== undefined) window.cancelAnimationFrame(focusFrame)
      window.clearTimeout(speechStart)
      window.clearInterval(speechInterval)
      observer.disconnect()
      controls.removeEventListener('change', renderScene)
      controls.dispose()
      renderer.domElement.removeEventListener('pointerdown', beginPointer)
      renderer.domElement.removeEventListener('pointerup', endPointer)
      renderer.domElement.removeEventListener('pointermove', movePointer)
      renderRef.current = null
      resetCameraRef.current = null
      renderer.dispose()
      container.replaceChildren()
    }
  // Static review mode mounts one renderer. Live Agent synchronization will
  // update object transforms inside this renderer rather than remounting it.
  }, [memberKey, layout.sceneAsset, layout.sceneAssetName, layout.modelScale])

  return <div ref={host} className="lookseekScene" aria-label={label} role="img" />
}
