import type { VisualIntent } from '../host/visual-intent.ts'

export type WorkspaceRole = NonNullable<VisualIntent['role']>

/** Display model deliberately separate from server-side visual-intent protocol. */
export interface WorkspaceMember {
  id: string
  name: string
  presetId?: string
  role: WorkspaceRole
  running: boolean
  completed: boolean
  intent: VisualIntent
}

export type MemberState = 'running' | 'complete' | 'incomplete' | 'error'

const activityLabels: Record<VisualIntent['activity'], string> = {
  receive: '收到任务',
  plan: '整理计划',
  read: '查看资料',
  edit: '修改文件',
  shell: '执行命令',
  web: '检查网页',
  verify: '验证变更',
  approval: '等待确认',
  repair: '正在修复',
  handoff: '提交结果',
  complete: '任务完成',
  idle: '待命',
  'external-wait': '等待外部结果',
}

const roleLabels: Record<WorkspaceRole, string> = {
  coordinator: '协调者',
  engineer: '工程师',
  researcher: '研究员',
  tester: '测试员',
  reviewer: '审查员',
  designer: '设计师',
  operator: '运维员',
}

/** Convert every visual event to a fixed Chinese activity label. */
export function activityLabel(intent: VisualIntent): string {
  return activityLabels[intent.activity]
}

/** Convert configured roles to stable Chinese labels for the visual workspace. */
export function roleLabel(role: WorkspaceRole): string {
  return roleLabels[role]
}

/** Classify the latest public event without exposing the model's raw text. */
export function memberState(member: WorkspaceMember): MemberState {
  if (member.completed) return 'complete'
  if (member.intent.activity === 'complete') return 'complete'
  if (member.intent.activity === 'repair' || /(?:error|failed|failure|失败|异常|出错)/i.test(member.intent.summary)) return 'error'
  return member.running ? 'running' : 'complete'
}

/** Chinese badge copy shared by the roster and the scene labels. */
export function memberStateLabel(member: WorkspaceMember): string {
  switch (memberState(member)) {
    case 'running': return '进行中'
    case 'complete': return '已完成'
    case 'incomplete': return '未完成'
    case 'error': return '出错'
  }
}

export const stationNames = {
  intake: '收件台', planning: '计划墙', library: '资料架', code: '代码桌',
  terminal: '终端台', window: '观察窗', validation: '验证台', approval: '确认灯',
  repair: '维修台', lounge: '休息角', delivery: '交付柜', review: '评审桌',
} as const

/** Fixed room positions in meters, read by both the scene and the member list. */
export const stationPositions = {
  intake: [-5.5, -2.8], planning: [0, -2.7], library: [-5.4, 1.8], code: [-1.7, 1.7],
  terminal: [1.7, 1.7], window: [5.4, 1.8], validation: [4.8, -1.8], approval: [4.8, -3.3],
  repair: [1.8, -3.0], lounge: [-4.7, -3.5], delivery: [0, 3.2], review: [-1.4, 3.1],
} as const

const roleStations: Record<WorkspaceRole, VisualIntent['target']> = {
  coordinator: 'planning', engineer: 'code', researcher: 'library', tester: 'validation',
  reviewer: 'review', designer: 'code', operator: 'terminal',
}

/** Infer a stable, explainable role only when no configured role was reported. */
export function roleFromPreset(presetId: string | undefined, main: boolean): WorkspaceRole {
  if (main) return 'coordinator'
  const key = (presetId ?? '').toLowerCase()
  if (/(test|qa|verify)/.test(key)) return 'tester'
  if (/(research|doc|search)/.test(key)) return 'researcher'
  if (/(review|audit)/.test(key)) return 'reviewer'
  if (/(design|ui|ux)/.test(key)) return 'designer'
  if (/(ops|deploy|infra)/.test(key)) return 'operator'
  return 'engineer'
}

/** Create a quiet fallback status for sessions that have not emitted a rich visual event yet. */
export function fallbackIntent(role: WorkspaceRole, running: boolean): VisualIntent {
  return running
    ? { agentId: '', activity: 'plan', target: roleStations[role], summary: '正在组织下一步', at: Date.now() }
    : { agentId: '', activity: 'idle', target: 'lounge', summary: '待命', at: 0 }
}

/** Sort every real worker for a readable shared workspace. */
export function visibleMembers(members: readonly WorkspaceMember[]): readonly WorkspaceMember[] {
  return [...members]
    .sort((a, b) => Number(b.running) - Number(a.running) || b.intent.at - a.intent.at)
}

/** Format elapsed time without turning a long task into fake typing animation. */
export function elapsed(at: number, now: number): string {
  const seconds = Math.max(0, Math.floor((now - at) / 1000))
  if (seconds < 60) return `${seconds} 秒`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes} 分钟`
  return `${Math.floor(minutes / 60)} 小时 ${minutes % 60} 分钟`
}
