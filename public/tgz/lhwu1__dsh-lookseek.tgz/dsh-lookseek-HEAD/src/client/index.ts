import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { en, NS, zh, type LookseekLocaleKey } from './locales.ts'
import { WorkshopView, WorkspacePulse } from './WorkshopView.tsx'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap { lookseek: LookseekLocaleKey }
}

export { fallbackIntent, roleFromPreset, stationNames, visibleMembers } from './model.ts'
export type { WorkspaceMember } from './model.ts'
export { WorkshopView, WorkspacePulse } from './WorkshopView.tsx'

/** Services needed to mount the conversation-view and header contributions. */
export const inject = ['slots', 'locale', 'connection']

/** Register the visual workspace without replacing the standard conversation experience. */
export function apply(ctx: ClientContext): void {
  const { api } = ctx.get('connection') as ConnectionHandle
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-lookseek: dictionaries')
  const t = ctx.locale.bind(NS)
  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view', id: 'lookseek-workshop', order: 15,
    label: () => t('view'), locale: NS, inject: () => ({ api }),
  }, WorkshopView))
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions', id: 'lookseek-pulse', order: 15, locale: NS,
  }, WorkspacePulse))
}
