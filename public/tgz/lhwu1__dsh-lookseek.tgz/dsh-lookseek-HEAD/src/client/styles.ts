const STYLE_ID = 'dsh-lookseek-workshop-styles'

const styles = `
.lookseekRoot { width: 100%; height: min(620px, calc(100dvh - 148px)); min-height: 440px; box-sizing: border-box; position: relative; margin: 0 0 28px; overflow: hidden; color-scheme: light dark; background: color-mix(in srgb, Canvas 82%, transparent); color: CanvasText; }
.lookseekRoot::before { position: absolute; z-index: -1; inset: 0; background: color-mix(in srgb, Canvas 70%, transparent); content: ''; backdrop-filter: blur(22px) saturate(1.15); }
.lookseekCommandBar { position: absolute; z-index: 5; top: 14px; right: 18px; left: 18px; height: 46px; box-sizing: border-box; display: grid; grid-template-columns: minmax(190px, 1fr) minmax(0, 2fr) minmax(120px, 1fr); align-items: center; gap: 16px; min-width: 0; padding: 0 16px; border: 1px solid color-mix(in srgb, CanvasText 17%, transparent); border-radius: 7px; background: color-mix(in srgb, Canvas 72%, #1d7d68 5%); box-shadow: 0 10px 28px color-mix(in srgb, CanvasText 12%, transparent), inset 0 1px 0 color-mix(in srgb, Canvas 76%, transparent); font-size: 11px; letter-spacing: 0; backdrop-filter: blur(20px) saturate(1.12); }
.lookseekCommandIdentity, .lookseekCommandState { display: flex; align-items: center; gap: 9px; min-width: 0; }
.lookseekCommandIdentity { color: color-mix(in srgb, CanvasText 80%, transparent); font-weight: 780; }
.lookseekSignal { width: 8px; height: 8px; border-radius: 50%; background: #37b68c; box-shadow: 0 0 0 4px color-mix(in srgb, #37b68c 16%, transparent); animation: lookseek-pulse 2.4s ease-in-out infinite; }
.lookseekCommandState { overflow: hidden; color: color-mix(in srgb, CanvasText 66%, transparent); white-space: nowrap; }
.lookseekCommandState > span:not(:last-child) { padding-right: 9px; border-right: 1px solid color-mix(in srgb, CanvasText 16%, transparent); }
.lookseekCommandState > span:first-child { color: #14724d; font-weight: 760; }
.lookseekCommandState .lookseekCommandAlert { color: #b54139; }
.lookseekCommandSummary { overflow: hidden; text-overflow: ellipsis; }
.lookseekCommandTarget { display: flex; align-items: center; justify-content: flex-end; gap: 9px; overflow: hidden; color: color-mix(in srgb, CanvasText 63%, transparent); font-weight: 700; text-align: right; text-overflow: ellipsis; white-space: nowrap; }
.lookseekSceneSettings { display: grid; width: 28px; height: 28px; flex: 0 0 auto; place-items: center; border: 1px solid color-mix(in srgb, CanvasText 20%, transparent); border-radius: 5px; background: color-mix(in srgb, Canvas 78%, transparent); color: CanvasText; font-size: 17px; line-height: 1; cursor: pointer; }
.lookseekSceneSettings:hover, .lookseekSceneSettings:focus-visible { border-color: #2d9a70; color: #167a61; outline: 2px solid color-mix(in srgb, #2d9a70 32%, transparent); outline-offset: 2px; }
.lookseekSceneWrap { position: absolute; inset: 0; min-width: 0; min-height: 0; background-image: linear-gradient(color-mix(in srgb, CanvasText 3%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in srgb, CanvasText 3%, transparent) 1px, transparent 1px); background-color: color-mix(in srgb, Canvas 58%, transparent); background-size: 28px 28px; }
.lookseekSceneFrame, .lookseekScene { width: 100%; height: 100%; min-height: 0; overflow: hidden; }
.lookseekScene canvas { display: block; width: 100%; height: 100%; cursor: grab; touch-action: none; }
.lookseekScene canvas:active { cursor: grabbing; }
.lookseekLabels { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
.lookseekWorkerTag { position: absolute; left: 0; top: 0; pointer-events: none; }
.lookseekWorkerTagPanel { width: 188px; transform: translate(-50%, -112%); box-sizing: border-box; padding: 7px 9px 8px; border: 1px solid #75ead0; border-radius: 6px; background: rgb(7 18 21 / .97); box-shadow: 0 4px 12px rgb(0 0 0 / .28); color: #f5f8f5; font-family: system-ui, sans-serif; line-height: 1.35; }
.lookseekWorkerTag[data-running="false"] .lookseekWorkerTagPanel { border-color: #aab9b4; }
.lookseekWorkerTagName, .lookseekWorkerTagActivity, .lookseekWorkerTagState { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.lookseekWorkerTagName { font-size: 13px; font-weight: 750; }
.lookseekWorkerTagName::before { display: inline-block; width: 7px; height: 7px; margin: 0 6px 1px 0; border-radius: 50%; background: #f6cb68; content: ''; }
.lookseekWorkerTagActivity { margin-top: 3px; color: #c2d8d1; font-size: 12px; font-weight: 600; }
.lookseekWorkerTagState { margin-top: 3px; color: #70dac4; font-size: 11px; font-weight: 750; }
.lookseekWorkerTag[data-running="false"] .lookseekWorkerTagState { color: #b4c4bf; }
.lookseekWorkerSpeech { position: absolute; left: 0; top: 0; pointer-events: none; }
.lookseekWorkerSpeechText { position: relative; display: block; width: min(240px, 42vw); box-sizing: border-box; transform: translate(-50%, -116%); padding: 8px 11px; border: 1px solid #2d7464; border-radius: 6px; background: #f8fcfa; box-shadow: 0 4px 12px rgb(0 0 0 / .22); color: #142e28; font: 650 14px/1.45 system-ui, sans-serif; overflow-wrap: anywhere; text-align: left; }
.lookseekWorkerSpeechText::after { position: absolute; bottom: -7px; left: 24px; width: 12px; height: 12px; border-right: 1px solid #2d7464; border-bottom: 1px solid #2d7464; background: #f8fcfa; content: ''; transform: rotate(45deg); }
.lookseekLegend { display: none; }
.lookseekRoster, .lookseekTasks { position: absolute; z-index: 4; top: 76px; bottom: 18px; width: clamp(224px, 18vw, 292px); box-sizing: border-box; overflow: auto; padding: 16px; border: 1px solid color-mix(in srgb, CanvasText 17%, transparent); border-radius: 8px; background: color-mix(in srgb, Canvas 76%, #2b8b75 4%); box-shadow: 0 16px 42px color-mix(in srgb, CanvasText 13%, transparent), inset 0 1px 0 color-mix(in srgb, Canvas 80%, transparent); backdrop-filter: blur(22px) saturate(1.12); }
.lookseekRoster::before, .lookseekTasks::before { display: block; width: 42px; height: 2px; margin-bottom: 12px; background: #42b896; box-shadow: 0 0 14px color-mix(in srgb, #42b896 70%, transparent); content: ''; }
.lookseekRoster { left: 18px; }
.lookseekTasks { right: 18px; }
.lookseekTasksHeading { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; margin-bottom: 12px; }
.lookseekTasksHeading .lookseekHeading { margin: 0; }
.lookseekTaskList { display: grid; gap: 7px; margin: 0; padding: 0; list-style: none; }
.lookseekTask { display: grid; grid-template-columns: 10px minmax(0, 1fr); gap: 8px; align-items: start; padding: 9px 0; border-bottom: 1px solid color-mix(in srgb, CanvasText 12%, transparent); }
.lookseekTaskMarker { width: 7px; height: 7px; margin-top: 5px; border: 1px solid color-mix(in srgb, CanvasText 46%, transparent); border-radius: 50%; }
.lookseekTask-in_progress .lookseekTaskMarker { border-color: #b57700; background: #e0a83b; }
.lookseekTask-completed .lookseekTaskMarker { border-color: #14724d; background: #2d9a70; }
.lookseekTaskContent { min-width: 0; overflow-wrap: anywhere; font-size: 13px; line-height: 1.45; }
.lookseekTaskState { grid-column: 2; color: color-mix(in srgb, CanvasText 60%, transparent); font-size: 11px; }
.lookseekTask-in_progress .lookseekTaskState { color: #8b5900; }
.lookseekTask-completed .lookseekTaskState { color: #14724d; }
.lookseekTaskAgent { grid-column: 2; color: color-mix(in srgb, CanvasText 54%, transparent); font-size: 11px; }
.lookseekRosterHeading { display: flex; align-items: start; justify-content: space-between; gap: 12px; margin-bottom: 12px; }
.lookseekNow { margin: 0 0 14px; padding: 10px; border: 1px solid color-mix(in srgb, CanvasText 13%, transparent); border-radius: 6px; background: color-mix(in srgb, Canvas 92%, #70b5a1); }
.lookseekMetricGrid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 7px; margin: 0 0 14px; }
.lookseekMetricGrid div { min-width: 0; padding: 8px 6px; border: 1px solid color-mix(in srgb, CanvasText 12%, transparent); background: color-mix(in srgb, Canvas 64%, transparent); text-align: center; }
.lookseekMetricGrid strong, .lookseekMetricGrid span { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.lookseekMetricGrid strong { color: #168364; font-size: 17px; line-height: 1; }
.lookseekMetricGrid span { margin-top: 5px; color: color-mix(in srgb, CanvasText 61%, transparent); font-size: 10px; }
.lookseekNowHeading { display: flex; justify-content: space-between; gap: 8px; }
.lookseekNowHeading span { color: color-mix(in srgb, CanvasText 55%, transparent); font-size: 10px; }
.lookseekNow > p { margin: 0; color: color-mix(in srgb, CanvasText 58%, transparent); font-size: 11px; }
.lookseekNow h3 { margin: 0 0 7px; font-size: 12px; font-weight: 750; }
.lookseekNow ol { display: grid; gap: 6px; margin: 0; padding: 0; list-style: none; }
.lookseekNow li { display: grid; gap: 2px; min-width: 0; font-size: 11px; line-height: 1.35; }
.lookseekNow li span:first-child { color: #14724d; font-weight: 720; }
.lookseekNow li span:last-child { overflow: hidden; color: color-mix(in srgb, CanvasText 68%, transparent); text-overflow: ellipsis; white-space: nowrap; }
.lookseekHeading { margin: 0 0 16px; font-size: 16px; font-weight: 650; }
.lookseekRosterHeading .lookseekHeading { margin: 0; }
.lookseekCount { margin: 4px 0 0; color: color-mix(in srgb, CanvasText 62%, transparent); font-size: 12px; }
.lookseekCreate { min-width: 48px; border: 1px solid color-mix(in srgb, CanvasText 24%, transparent); border-radius: 5px; background: color-mix(in srgb, Canvas 78%, #8fcab5); color: CanvasText; font: inherit; font-size: 12px; line-height: 28px; cursor: pointer; }
.lookseekMember { width: 100%; display: grid; grid-template-columns: 11px minmax(0, 1fr); gap: 10px; padding: 11px 4px; border: 0; border-bottom: 1px solid color-mix(in srgb, CanvasText 12%, transparent); color: inherit; text-align: left; background: transparent; cursor: pointer; }
.lookseekMember:hover, .lookseekMember:focus-visible, .lookseekSelected { background: color-mix(in srgb, CanvasText 7%, transparent); outline: none; }
.lookseekDot { width: 8px; height: 8px; margin-top: 5px; border-radius: 50%; background: #7d9786; }
.lookseekDotRunning { background: #d6ad55; box-shadow: 0 0 0 3px rgba(214, 173, 85, .16); }
.lookseekName { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; font-weight: 650; }
.lookseekPreset { display: block; margin-top: 2px; color: #347b6b; font-size: 11px; }
.lookseekState { display: inline-block; margin-top: 6px; padding: 2px 6px; border-radius: 3px; font-size: 11px; font-weight: 650; line-height: 1.3; }
.lookseekState-running { background: color-mix(in srgb, #e0a83b 20%, transparent); color: #8b5900; }
.lookseekState-complete { background: color-mix(in srgb, #2d9a70 18%, transparent); color: #14724d; }
.lookseekState-incomplete { background: color-mix(in srgb, CanvasText 10%, transparent); color: color-mix(in srgb, CanvasText 70%, transparent); }
.lookseekState-error { background: color-mix(in srgb, #ce5d56 18%, transparent); color: #a83d37; }
.lookseekSummary { display: -webkit-box; overflow: hidden; margin-top: 4px; color: color-mix(in srgb, CanvasText 68%, transparent); font-size: 12px; line-height: 1.4; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.lookseekMeta { display: block; margin-top: 5px; color: color-mix(in srgb, CanvasText 56%, transparent); font-size: 11px; }
.lookseekEmpty, .lookseekNotice { margin: 12px 0; color: color-mix(in srgb, CanvasText 66%, transparent); font-size: 12px; line-height: 1.55; }
.lookseekPulse { display: inline-flex; align-items: center; gap: 4px; max-width: 126px; overflow: hidden; color: #718078; font-size: 12px; white-space: nowrap; }
.lookseekAvatars { display: inline-flex; }
.lookseekAvatar { display: grid; width: 18px; height: 18px; margin-right: -4px; place-items: center; border: 1px solid #202924; border-radius: 50%; background: #477b70; color: #fff; font-size: 9px; }
.lookseekDialogBackdrop { position: fixed; z-index: 1000; inset: 0; display: grid; place-items: center; padding: 20px; background: rgb(10 18 15 / .42); }
.lookseekEditing { position: fixed !important; z-index: 1000; inset: 0; width: 100vw; height: 100dvh !important; margin: 0; overflow: hidden; background: Canvas; }
.lookseekEditing .lookseekCommandBar, .lookseekEditing .lookseekRoster, .lookseekEditing .lookseekTasks { display: none; }
.lookseekEditing .lookseekSceneWrap { position: absolute; inset: 0; border: 0; }
.lookseekEditing .lookseekSceneFrame { position: absolute; inset: 0; }
.lookseekEditorBackdrop { z-index: 1001; pointer-events: none; justify-items: start; align-items: start; padding: 20px; background: transparent; }
.lookseekEditorGuide { position: fixed; z-index: 1002; top: 18px; left: 50%; display: grid; gap: 4px; width: min(680px, calc(100vw - 80px)); transform: translateX(-50%); padding: 10px 14px; border: 1px solid rgb(115 210 184 / .56); border-radius: 6px; background: rgb(10 29 25 / .9); color: #f1fbf7; box-shadow: 0 8px 28px rgb(0 0 0 / .24); text-align: center; pointer-events: none; }
.lookseekEditorGuide strong { color: #83e2c4; font-size: 13px; }
.lookseekEditorGuide span { color: rgb(241 251 247 / .86); font-size: 12px; line-height: 1.45; }
.lookseekTutorialHelp { position: absolute; top: 50%; right: 12px; display: grid; width: 24px; height: 24px; place-items: center; transform: translateY(-50%); border: 1px solid rgb(201 246 232 / .72); border-radius: 50%; background: rgb(83 188 154 / .18); color: #f4fffb; font: 750 14px/1 system-ui, sans-serif; cursor: pointer; pointer-events: auto; }
.lookseekTutorialHelp:hover, .lookseekTutorialHelp:focus-visible { background: rgb(83 188 154 / .4); outline: 2px solid #8be4c8; outline-offset: 2px; }
.lookseekTutorial { position: fixed; z-index: 1003; inset: 32px; display: grid; grid-template-rows: auto minmax(0, 1fr); max-width: 860px; margin: auto; overflow: hidden; border: 1px solid color-mix(in srgb, CanvasText 20%, transparent); border-radius: 8px; background: Canvas; color: CanvasText; box-shadow: 0 26px 76px rgb(0 0 0 / .36); pointer-events: auto; }
.lookseekTutorial header { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 18px 22px; border-bottom: 1px solid color-mix(in srgb, CanvasText 13%, transparent); background: color-mix(in srgb, Canvas 92%, #4da98d); }
.lookseekTutorial header p { margin: 0 0 3px; color: #168364; font-size: 11px; font-weight: 750; }
.lookseekTutorial h2 { margin: 0; font-size: 18px; }
.lookseekTutorial header button { min-height: 34px; border: 1px solid color-mix(in srgb, CanvasText 22%, transparent); border-radius: 5px; background: Canvas; color: CanvasText; padding: 0 12px; font: inherit; cursor: pointer; }
.lookseekTutorialDocument { overflow: auto; padding: clamp(20px, 4vw, 42px); }
.lookseekTutorialDocument h1 { margin: 0 0 24px; font-size: 25px; }
.lookseekTutorialDocument h2 { margin: 28px 0 10px; color: #126b57; font-size: 17px; }
.lookseekTutorialDocument p { max-width: 700px; margin: 10px 0; color: color-mix(in srgb, CanvasText 78%, transparent); font-size: 14px; line-height: 1.75; }
.lookseekTutorialItem { padding-left: 16px; border-left: 2px solid #54b89a; }
.lookseekTutorialState { margin: 28px; color: color-mix(in srgb, CanvasText 65%, transparent); }
.lookseekEditorBackdrop .lookseekRouteEditor { width: min(430px, calc(100vw - 40px)); max-height: calc(100dvh - 40px); pointer-events: auto; box-shadow: 0 20px 70px rgb(0 0 0 / .28); }
.lookseekEditorBackdrop .lookseekRouteGrid { grid-template-columns: 1fr; gap: 10px; }
.lookseekEditorBackdrop .lookseekRouteGrid section { padding: 10px; }
.lookseekEditorBackdrop .lookseekRouteList { max-height: 96px; }
.lookseekDialog { width: min(540px, 100%); max-height: min(78dvh, 720px); overflow: auto; padding: 20px; border: 1px solid color-mix(in srgb, CanvasText 18%, transparent); border-radius: 8px; background: Canvas; color: CanvasText; box-shadow: 0 20px 70px rgb(0 0 0 / .24); }
.lookseekDialogTitle { display: flex; align-items: start; justify-content: space-between; gap: 16px; }
.lookseekDialogTitle h2 { margin: 0; font-size: 18px; }
.lookseekDialogTitle p { margin: 5px 0 0; color: color-mix(in srgb, CanvasText 62%, transparent); font-size: 12px; }
.lookseekClose { width: 30px; height: 30px; border: 0; border-radius: 4px; background: transparent; color: CanvasText; font-size: 24px; line-height: 1; cursor: pointer; }
.lookseekDetailGrid { display: grid; grid-template-columns: 72px minmax(0, 1fr); gap: 9px 12px; margin: 20px 0 14px; font-size: 13px; }
.lookseekDetailGrid dt { color: color-mix(in srgb, CanvasText 55%, transparent); }
.lookseekDetailGrid dd { min-width: 0; margin: 0; overflow-wrap: anywhere; }
.lookseekDescription { margin: 12px 0; color: color-mix(in srgb, CanvasText 72%, transparent); font-size: 13px; line-height: 1.5; }
.lookseekPresetContent { max-height: 200px; overflow: auto; padding: 12px; border: 1px solid color-mix(in srgb, CanvasText 13%, transparent); background: color-mix(in srgb, Canvas 94%, #659787); color: CanvasText; font: 11px/1.5 ui-monospace, SFMono-Regular, Consolas, monospace; white-space: pre-wrap; }
.lookseekDialogActions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; margin-top: 18px; }
.lookseekDialogActions button { min-height: 32px; border: 1px solid color-mix(in srgb, CanvasText 21%, transparent); border-radius: 5px; background: Canvas; color: CanvasText; padding: 0 11px; font: inherit; font-size: 13px; cursor: pointer; }
.lookseekDialogActions .lookseekPrimary { border-color: #267b69; background: #2d8e78; color: #fff; }
.lookseekDialogActions button:disabled { opacity: .5; cursor: not-allowed; }
.lookseekSceneSettingsDialog { width: min(480px, 100%); }
.lookseekSceneUpload { display: grid; gap: 8px; margin-top: 22px; padding: 14px; border: 1px dashed color-mix(in srgb, CanvasText 28%, transparent); border-radius: 6px; background: color-mix(in srgb, Canvas 87%, #4c9c85 8%); font-size: 13px; font-weight: 700; }
.lookseekSceneUpload input { max-width: 100%; font: inherit; font-weight: 400; }
.lookseekSceneUpload small, .lookseekSceneCurrent { color: color-mix(in srgb, CanvasText 62%, transparent); font-size: 12px; font-weight: 400; line-height: 1.5; }
.lookseekSceneCurrent { margin: 14px 0 0; }
.lookseekCreator label { display: grid; gap: 6px; margin-top: 14px; color: color-mix(in srgb, CanvasText 70%, transparent); font-size: 12px; }
.lookseekCreator input, .lookseekCreator select { min-height: 36px; box-sizing: border-box; border: 1px solid color-mix(in srgb, CanvasText 22%, transparent); border-radius: 4px; background: Canvas; color: CanvasText; padding: 0 9px; font: inherit; }
.lookseekRouteEditor { width: min(780px, 100%); }
.lookseekLayoutPath { overflow: auto; margin: 12px 0; padding: 8px; border: 1px solid color-mix(in srgb, CanvasText 13%, transparent); background: color-mix(in srgb, Canvas 94%, #529986); color: color-mix(in srgb, CanvasText 64%, transparent); font: 11px/1.45 ui-monospace, SFMono-Regular, Consolas, monospace; white-space: nowrap; }
.lookseekRouteGrid { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 16px; }
.lookseekRouteGrid section { min-width: 0; padding: 12px; border: 1px solid color-mix(in srgb, CanvasText 14%, transparent); background: color-mix(in srgb, Canvas 94%, #529986); }
.lookseekRouteGrid h3 { margin: 0 0 10px; font-size: 14px; }
.lookseekRouteGrid label { display: grid; gap: 4px; margin: 9px 0; color: color-mix(in srgb, CanvasText 66%, transparent); font-size: 11px; }
.lookseekRouteGrid input, .lookseekRouteGrid select { min-height: 32px; box-sizing: border-box; width: 100%; border: 1px solid color-mix(in srgb, CanvasText 18%, transparent); border-radius: 4px; background: Canvas; color: CanvasText; padding: 0 8px; font: inherit; }
.lookseekRouteGrid button { min-height: 32px; border: 1px solid #267b69; border-radius: 4px; background: color-mix(in srgb, Canvas 82%, #2d8e78); color: CanvasText; padding: 0 10px; font: inherit; font-size: 12px; cursor: pointer; }
.lookseekRouteModes { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 7px; }
.lookseekRouteSelected { border-color: #d49a2a !important; background: color-mix(in srgb, #d49a2a 24%, Canvas) !important; color: CanvasText !important; }
.lookseekCoordinates { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0 8px; margin-top: 10px; }
.lookseekRouteHint { margin: 12px 0 0; color: color-mix(in srgb, CanvasText 58%, transparent); font-size: 11px; line-height: 1.5; }
.lookseekRouteList { display: grid; gap: 6px; max-height: 140px; overflow: auto; margin: 12px 0 0; padding: 0; list-style: none; }
.lookseekRouteList li { padding: 0; border: 1px solid color-mix(in srgb, CanvasText 12%, transparent); color: color-mix(in srgb, CanvasText 72%, transparent); font-size: 11px; }
.lookseekRouteList button { width: 100%; border: 0; border-radius: 0; text-align: left; }
.lookseekWizard { width: min(400px, 100%); padding: 14px; border: 1px solid color-mix(in srgb, CanvasText 14%, transparent); background: color-mix(in srgb, Canvas 94%, #529986); }
.lookseekWizardStep { margin: 0 0 8px; color: #14724d; font-size: 12px; font-weight: 700; }
.lookseekWizard h3 { margin: 0 0 8px; font-size: 16px; }
.lookseekWizard p:not(.lookseekWizardStep) { margin: 8px 0; color: color-mix(in srgb, CanvasText 70%, transparent); font-size: 13px; line-height: 1.5; }
.lookseekScaleControl { display: grid; gap: 8px; margin-top: 18px; color: color-mix(in srgb, CanvasText 82%, transparent); font-size: 13px; font-weight: 650; }
.lookseekScaleControl > span { display: flex; align-items: center; justify-content: space-between; }
.lookseekScaleControl output { color: #14724d; font-variant-numeric: tabular-nums; }
.lookseekScaleControl input { width: 100%; accent-color: #188260; }
.lookseekRoutePointLabel { transform: translate(-50%, -100%); padding: 4px 7px; border: 1px solid rgb(222 247 240 / .68); border-radius: 4px; background: rgb(12 33 29 / .88); color: #edf9f5; box-shadow: 0 3px 10px rgb(0 0 0 / .24); font: 700 12px/1.2 system-ui, sans-serif; white-space: nowrap; pointer-events: none; }
.lookseekRoutePointLabelActive { border-color: #ffd468; background: rgb(71 51 13 / .92); color: #fff5cf; }
@keyframes lookseek-pulse { 0%, 100% { opacity: .65; transform: scale(.88); } 50% { opacity: 1; transform: scale(1); } }
@media (prefers-reduced-motion: reduce) { .lookseekSignal { animation: none; } }
@media (max-width: 1220px) { .lookseekRoot { height: min(720px, calc(100dvh - 112px)); display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); grid-template-rows: 54px minmax(260px, 1fr) minmax(200px, .72fr); } .lookseekCommandBar { position: relative; inset: auto; grid-column: 1 / -1; width: auto; height: 42px; margin: 6px 10px; } .lookseekSceneWrap { position: relative; inset: auto; grid-column: 1 / -1; grid-row: 2; border-bottom: 1px solid color-mix(in srgb, CanvasText 15%, transparent); } .lookseekRoster, .lookseekTasks { position: relative; top: auto; right: auto; bottom: auto; left: auto; width: auto; border-radius: 0; box-shadow: none; } .lookseekRoster { grid-column: 1; grid-row: 3; } .lookseekTasks { grid-column: 2; grid-row: 3; } }
@media (max-width: 760px) { .lookseekRoot { height: auto !important; min-height: 0; grid-template-columns: 1fr; grid-template-rows: 54px clamp(330px, 56dvh, 460px) auto auto; margin-bottom: 168px; overflow: visible; } .lookseekCommandBar { grid-template-columns: minmax(0, 1fr) auto; gap: 8px; padding: 0 12px; } .lookseekCommandState { display: none; } .lookseekSceneWrap { grid-column: auto; grid-row: 2; height: auto; min-height: 0; border-left: 0; border-bottom: 1px solid color-mix(in srgb, CanvasText 15%, transparent); } .lookseekRoster, .lookseekTasks { grid-column: auto; max-height: none; overflow: visible; border-right: 0; border-left: 0; border-bottom: 1px solid color-mix(in srgb, CanvasText 15%, transparent); } .lookseekRoster { grid-row: 3; } .lookseekTasks { grid-row: 4; } .lookseekLegend { left: 10px; bottom: 10px; max-width: calc(100% - 20px); } .lookseekWorkerTagPanel { width: 144px; padding: 5px 7px; } .lookseekWorkerTagName { font-size: 11px; } .lookseekWorkerTagActivity, .lookseekWorkerTagState { font-size: 10px; } .lookseekWorkerSpeechText { width: min(190px, 56vw) !important; font-size: 12px !important; } }
`

/** Install the plugin stylesheet because Harness loads external client bundles as JavaScript only. */
export function ensureWorkshopStyles(): void {
  const existing = document.getElementById(STYLE_ID)
  if (existing !== null) return
  const element = document.createElement('style')
  element.id = STYLE_ID
  element.textContent = styles
  document.head.appendChild(element)
}
