import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { IApiClient } from '@deepseek-ai/dsh-api-remotes/client'
import type { SessionSummary } from '@deepseek-ai/dsh-client-runtime/client'
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { VisualIntent } from '../host/visual-intent.ts'
import { defaultLayout, validateLayout, type LookseekLayout, type LayoutPoint, type LayoutRoute } from '../shared/layout.ts'
import { activityLabel, fallbackIntent, memberState, memberStateLabel, roleLabel, roleFromPreset, stationNames, visibleMembers, type WorkspaceMember } from './model.ts'
import { WorkshopScene } from './WorkshopScene.tsx'
import { ensureWorkshopStyles } from './styles.ts'

type WorkshopApi = Pick<IApiClient, 'agentPresets'>

interface WorkshopInjected { api: WorkshopApi }

interface RosterPreset {
  id: string
  trust: 'system' | 'user'
  isDefault: boolean
  name?: string
  description?: string
  broken?: string
}

interface PresetRoster {
  presets: readonly RosterPreset[]
  authorable: boolean
}

type TodoStatus = 'pending' | 'in_progress' | 'completed'

interface WorkspaceTodo {
  content: string
  status: TodoStatus
  agentName?: string
}

interface RouteDraft {
  mode: LayoutRoute['mode']
  startId: string | null
  controlPoints: readonly (readonly [number, number, number])[]
}

function TutorialDocument({ source }: { source: string }) {
  return <article className="lookseekTutorialDocument">{source.split(/\r?\n/).filter(line => line.trim() !== '').map((line, index) => {
    if (line.startsWith('# ')) return <h1 key={index}>{line.slice(2)}</h1>
    if (line.startsWith('## ')) return <h2 key={index}>{line.slice(3)}</h2>
    if (line.startsWith('- ')) return <p key={index} className="lookseekTutorialItem">{line.slice(2)}</p>
    return <p key={index}>{line.replaceAll('`', '')}</p>
  })}</article>
}

const pointInstructions: Record<string, string> = {
  receive: '收件台：用户消息进入工作间时的落点。',
  plan: '计划墙：整理任务与拆分下一步时的站位。',
  read: '资料架：读取文件、文档或本地资料时的站位。',
  edit: '代码桌：修改文件和编写代码时的站位。',
  shell: '终端台：执行命令、构建或运行子进程时的站位。',
  web: '观察窗：检查网页或检索外部资料时的站位。',
  verify: '验证台：测试、类型检查或构建验证时的站位。',
  approval: '确认灯：等待你的批准或回答时的站位。',
  repair: '维修台：工具失败后调整或重试时的站位。',
  idle: '休息角：没有运行任务时的待命位置。',
  complete: '交付柜：任务完成并交付结果时的站位。',
}

function sessionsFor(sessionId: string, summaries: readonly SessionSummary[]): readonly SessionSummary[] {
  const included = new Set<string>([sessionId])
  let changed = true
  while (changed) {
    changed = false
    for (const session of summaries) {
      if (session.parentId !== undefined && included.has(session.parentId) && !included.has(session.id)) {
        included.add(session.id)
        changed = true
      }
    }
  }
  return summaries.filter(session => included.has(session.id))
}

function membersFrom(
  sessionId: string,
  summaries: readonly SessionSummary[],
  intents: readonly VisualIntent[],
  defaultPreset: string | undefined,
): readonly WorkspaceMember[] {
  const byAgentId = new Map(intents.map(intent => [intent.agentId, intent]))
  return sessionsFor(sessionId, summaries).map((session) => {
    const intent = byAgentId.get(session.id)
    const presetId = session.agentPreset ?? defaultPreset
    const role = intent?.role ?? roleFromPreset(presetId, session.id === sessionId)
    return {
      id: session.id,
      name: intent?.agentName ?? session.displayTitle,
      ...(presetId === undefined ? {} : { presetId }),
      role,
      running: session.running,
      completed: session.completed === true,
      intent: intent ?? { ...fallbackIntent(role, session.running), agentId: session.id },
    }
  })
}

function tasksFrom(sessionId: string, summaries: readonly SessionSummary[]): readonly WorkspaceTodo[] {
  const statuses = new Set<TodoStatus>(['pending', 'in_progress', 'completed'])
  const team = sessionsFor(sessionId, summaries)
  return team.flatMap((session) => {
    const candidate = (session.projectionValues as { todos?: unknown } | undefined)?.todos
    if (!Array.isArray(candidate)) return []
    return candidate.flatMap((todo): WorkspaceTodo[] => {
      if (typeof todo !== 'object' || todo === null) return []
      const value = todo as { content?: unknown, status?: unknown }
      if (typeof value.content !== 'string' || typeof value.status !== 'string' || !statuses.has(value.status as TodoStatus)) return []
      return [{ content: value.content, status: value.status as TodoStatus, ...(team.length > 1 ? { agentName: session.displayTitle } : {}) }]
    })
  }).sort((a, b) => Number(b.status === 'in_progress') - Number(a.status === 'in_progress') || Number(b.status === 'pending') - Number(a.status === 'pending'))
}

function taskStatusLabel(status: TodoStatus): string {
  switch (status) {
    case 'pending': return '待处理'
    case 'in_progress': return '进行中'
    case 'completed': return '已完成'
  }
}

function completedDuration(member: WorkspaceMember, intents: readonly VisualIntent[]): string | undefined {
  if (memberState(member) !== 'complete') return undefined
  const finish = intents.find(intent => intent.agentId === member.id && intent.activity === 'complete')
  if (finish === undefined) return undefined
  const start = intents.slice(intents.indexOf(finish) + 1).find(intent => intent.agentId === member.id && intent.activity === 'receive')
  if (start === undefined || start.at > finish.at) return undefined
  const seconds = Math.max(0, Math.round((finish.at - start.at) / 1_000))
  return seconds < 60 ? `${seconds} 秒` : `${Math.floor(seconds / 60)} 分 ${seconds % 60} 秒`
}

function responseMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

/** Workspace tab bound to the real session tree and the official preset roster. */
export function WorkshopView({ sessionId, useSessions, t, api }: ConvViewProps & PropsLocale<'lookseek'> & WorkshopInjected) {
  const summaries = useSessions(state => Object.values(state.byId))
  const root = useRef<HTMLDivElement>(null)
  const [intents, setIntents] = useState<readonly VisualIntent[]>([])
  const [recentIntents, setRecentIntents] = useState<readonly VisualIntent[]>([])
  const [layout, setLayout] = useState<LookseekLayout>(defaultLayout)
  const [layoutPath, setLayoutPath] = useState('')
  const [layoutEditorOpen, setLayoutEditorOpen] = useState(false)
  const [sceneSettingsOpen, setSceneSettingsOpen] = useState(false)
  const [cameraResetToken, setCameraResetToken] = useState(0)
  const [sceneUploadMessage, setSceneUploadMessage] = useState<string | null>(null)
  const [pendingSceneName, setPendingSceneName] = useState<string | null>(null)
  const [layoutBeforeEditor, setLayoutBeforeEditor] = useState<LookseekLayout | null>(null)
  const [editingPendingScene, setEditingPendingScene] = useState(false)
  const [uploadingScene, setUploadingScene] = useState(false)
  const [editorStep, setEditorStep] = useState<'scale' | 'points' | 'routes'>('scale')
  const [pointIndex, setPointIndex] = useState(0)
  const [routeIndex, setRouteIndex] = useState(0)
  const [layoutDirty, setLayoutDirty] = useState(false)
  const [tutorialOpen, setTutorialOpen] = useState(false)
  const [tutorialText, setTutorialText] = useState<string | null>(null)
  const [tutorialError, setTutorialError] = useState<string | null>(null)
  const [selectedPointId, setSelectedPointId] = useState(defaultLayout.points[0]?.id ?? '')
  const [routeMode, setRouteMode] = useState<LayoutRoute['mode']>('polyline')
  const [routeDraft, setRouteDraft] = useState<RouteDraft>({ mode: 'polyline', startId: null, controlPoints: [] })
  const [layoutMessage, setLayoutMessage] = useState<string | null>(null)
  const [roster, setRoster] = useState<PresetRoster>({ presets: [], authorable: false })
  const [rosterError, setRosterError] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [detailId, setDetailId] = useState<string | null>(null)
  const [presetContent, setPresetContent] = useState<string | null>(null)
  const [detailMessage, setDetailMessage] = useState<string | null>(null)
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(null)
  const [height, setHeight] = useState(520)

  useEffect(() => { ensureWorkshopStyles() }, [])

  const loadRoster = useCallback(async (): Promise<void> => {
    try {
      const response = await api.agentPresets.list({})
      if (!response.result.ok) {
        setRosterError(response.result.error.message)
        return
      }
      const value = response.result.value
      setRoster({ presets: value.presets, authorable: value.authorable })
      setRosterError(null)
    } catch (error) {
      setRosterError(responseMessage(error))
    }
  }, [api])

  useEffect(() => { void loadRoster() }, [loadRoster])

  useEffect(() => {
    void fetch('/dsh-lookseek/layout.json', { cache: 'no-store' }).then(async response => {
      if (!response.ok) throw new Error('无法读取场景布局')
      return await response.json() as { path: string, layout: LookseekLayout }
    }).then(value => {
      setLayout(value.layout)
      setLayoutPath(value.path)
      setSelectedPointId(value.layout.points[0]?.id ?? '')
    }).catch(error => { setLayoutMessage(responseMessage(error)) })
  }, [])

  useEffect(() => {
    void fetch('/dsh-lookseek/scene-draft.json', { cache: 'no-store' }).then(async response => {
      if (!response.ok) throw new Error('无法读取待编排场景')
      return await response.json() as { draft?: { name?: unknown } }
    }).then(value => {
      setPendingSceneName(typeof value.draft?.name === 'string' ? value.draft.name : null)
    }).catch(error => { setSceneUploadMessage(responseMessage(error)) })
  }, [])

  useEffect(() => {
    let cancelled = false
    const loadIntents = async (): Promise<void> => {
      try {
        const response = await fetch('/dsh-lookseek/intents.json', { cache: 'no-store' })
        if (!response.ok) return
        const value: unknown = await response.json()
        if (!cancelled && typeof value === 'object' && value !== null && Array.isArray((value as { agents?: unknown }).agents)) {
          const snapshot = value as { agents: readonly VisualIntent[], recent?: unknown }
          setIntents(snapshot.agents)
          setRecentIntents(Array.isArray(snapshot.recent) ? snapshot.recent as readonly VisualIntent[] : [])
        }
      } catch {
        // The team tree remains useful before an Agent first reports an intent.
      }
    }
    void loadIntents()
    // This local, tiny snapshot is deliberately polled quickly: a visual
    // activity must begin and finish with the corresponding Agent event.
    const timer = window.setInterval(() => { void loadIntents() }, 400)
    return () => { cancelled = true; window.clearInterval(timer) }
  }, [])

  useEffect(() => {
    const element = root.current
    if (element === null) return
    let scrollBody = element.parentElement
    while (scrollBody !== null && getComputedStyle(scrollBody).overflowY !== 'auto') scrollBody = scrollBody.parentElement
    if (scrollBody === null) return
    // The conversation composer overlays the bottom of its scroll surface.
    // Reserve its full footprint so the workshop never sits beneath it.
    const update = (): void => { setHeight(Math.max(360, Math.min(540, Math.floor(scrollBody.clientHeight - 184)))) }
    const observer = new ResizeObserver(update)
    observer.observe(scrollBody)
    update()
    return () => { observer.disconnect() }
  }, [])

  const defaultPreset = roster.presets.find(preset => preset.isDefault)?.id
  const members = useMemo(
    () => membersFrom(sessionId, summaries, intents, defaultPreset),
    [defaultPreset, intents, sessionId, summaries],
  )
  const visible = useMemo(() => visibleMembers(members), [members])
  const tasks = useMemo(() => tasksFrom(sessionId, summaries), [sessionId, summaries])
  const leadIntent = recentIntents[0] ?? visible.find(member => member.running)?.intent ?? visible[0]?.intent
  const selected = selectedId === null ? null : members.find(member => member.id === selectedId) ?? null
  const calibrationPoint = layout.points[pointIndex]
  const detail = detailId === null ? null : members.find(member => member.id === detailId) ?? null
  const detailPreset = detail?.presetId === undefined ? undefined : roster.presets.find(preset => preset.id === detail.presetId)
  const stateCounts = useMemo(() => members.reduce<Record<'running' | 'complete' | 'incomplete' | 'error', number>>((counts, member) => {
    counts[memberState(member)] += 1
    return counts
  }, { running: 0, complete: 0, incomplete: 0, error: 0 }), [members])

  const select = useCallback((id: string): void => { setSelectedId(id) }, [])
  const updatePoint = useCallback((id: string, change: (point: LayoutPoint) => LayoutPoint): void => {
    setLayoutDirty(true)
    setLayout(current => {
      const prior = current.points.find(point => point.id === id)
      if (prior === undefined) return current
      const next = change(prior)
      return {
        ...current,
        routesNeedCalibration: true,
        points: current.points.map(point => point.id === id ? next : point),
        routes: current.routes.map(route => route.from !== id && route.to !== id ? route : {
          ...route,
          points: route.points.map((position, index) => index === 0 && route.from === id ? next.position : index === route.points.length - 1 && route.to === id ? next.position : position),
        }),
      }
    })
  }, [])
  useEffect(() => {
    if (!layoutEditorOpen || selectedPointId === '') return
    const move = (event: KeyboardEvent): void => {
      const target = event.target
      if (target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement) return
      const distance = event.altKey ? 0.01 : 0.1
      const delta: readonly [number, number, number] | undefined = event.code === 'KeyW' ? [0, 0, -distance]
        : event.code === 'KeyS' ? [0, 0, distance]
          : event.code === 'KeyA' ? [-distance, 0, 0]
            : event.code === 'KeyD' ? [distance, 0, 0]
              : event.code === 'Space' ? [0, distance, 0]
                : event.code === 'ShiftLeft' || event.code === 'ShiftRight' ? [0, -distance, 0]
                  : undefined
      if (delta === undefined) return
      event.preventDefault()
      updatePoint(selectedPointId, point => ({ ...point, position: [point.position[0] + delta[0], point.position[1] + delta[1], point.position[2] + delta[2]] }))
    }
    window.addEventListener('keydown', move)
    return () => { window.removeEventListener('keydown', move) }
  }, [layoutEditorOpen, selectedPointId, updatePoint])
  useEffect(() => {
    if (!layoutEditorOpen || !layoutDirty) return
    const confirmLeave = (event: BeforeUnloadEvent): void => {
      event.preventDefault()
      event.returnValue = ''
    }
    window.addEventListener('beforeunload', confirmLeave)
    return () => { window.removeEventListener('beforeunload', confirmLeave) }
  }, [layoutDirty, layoutEditorOpen])
  const saveLayout = useCallback(async (): Promise<void> => {
    try {
      const output = { ...layout, routesNeedCalibration: false }
      const validation = validateLayout(output)
      if (!validation.valid) throw new Error(validation.errors.join('；'))
      const response = await fetch('/dsh-lookseek/layout.json', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(output) })
      if (!response.ok) {
        const failure = await response.json().catch(() => undefined) as { error?: unknown } | undefined
        throw new Error(typeof failure?.error === 'string' ? failure.error : '保存场景路线失败')
      }
      const value = await response.json() as { path: string, layout: LookseekLayout }
      setLayout(value.layout)
      setLayoutPath(value.path)
      setLayoutDirty(false)
      setEditingPendingScene(false)
      setLayoutBeforeEditor(null)
      setPendingSceneName(null)
      setLayoutMessage('路线已保存并启用。')
    } catch (error) { setLayoutMessage(responseMessage(error)) }
  }, [layout])
  const openLayoutEditor = useCallback((): void => {
    setLayoutEditorOpen(true)
    setEditorStep('scale')
    setPointIndex(0)
    setSelectedPointId(layout.points[0]?.id ?? '')
    setSelectedRouteId(null)
    setRouteIndex(0)
    setRouteDraft({ mode: 'polyline', startId: null, controlPoints: [] })
    setLayoutDirty(false)
    setLayoutMessage(null)
  }, [layout.points])
  const uploadScene = useCallback(async (file: File | undefined): Promise<void> => {
    if (file === undefined) return
    if (!file.name.toLowerCase().endsWith('.glb')) {
      setSceneUploadMessage('请选择 .glb 场景文件。')
      return
    }
    if (file.size > 30 * 1024 * 1024) {
      setSceneUploadMessage('场景文件不能超过 30MB。')
      return
    }
    setUploadingScene(true)
    setSceneUploadMessage(null)
    try {
      const upload = await fetch('/dsh-lookseek/scene.glb', { method: 'POST', headers: { 'content-type': 'model/gltf-binary', 'x-lookseek-scene-name': file.name }, body: file })
      if (!upload.ok) {
        const failure = await upload.json().catch(() => undefined) as { error?: unknown } | undefined
        throw new Error(typeof failure?.error === 'string' ? failure.error : '导入场景失败')
      }
      setPendingSceneName(file.name)
      setSceneUploadMessage(`已导入 ${file.name}。完成编排并保存后，才会替换当前工作间。`)
    } catch (error) { setSceneUploadMessage(responseMessage(error)) } finally { setUploadingScene(false) }
  }, [])
  const beginEditorFromSettings = useCallback((): void => {
    if (pendingSceneName === null) return
    setLayoutBeforeEditor(layout)
    setEditingPendingScene(true)
    setLayout(current => ({ ...current, sceneAsset: 'custom', sceneAssetName: pendingSceneName, modelScale: 1, routesNeedCalibration: true }))
    setSceneSettingsOpen(false)
    openLayoutEditor()
  }, [layout, openLayoutEditor, pendingSceneName])
  const advanceScale = useCallback((): void => {
    setEditorStep('points')
    setSelectedPointId(layout.points[0]?.id ?? '')
  }, [layout.points])
  const advancePoint = useCallback((): void => {
    if (pointIndex >= layout.points.length - 1) {
      setEditorStep('routes')
      setLayout(current => ({ ...current, routesNeedCalibration: true, routes: [] }))
      setRouteIndex(0)
      setLayoutDirty(true)
      setLayoutMessage('全部工作点已确认。现在按需要绘制有向路线。')
      return
    }
    const next = pointIndex + 1
    setPointIndex(next)
    setSelectedPointId(layout.points[next]?.id ?? '')
  }, [layout.points, pointIndex])
  const retreatPoint = useCallback((): void => {
    const prior = Math.max(0, pointIndex - 1)
    setPointIndex(prior)
    setSelectedPointId(layout.points[prior]?.id ?? '')
  }, [layout.points, pointIndex])
  const closeLayoutEditor = useCallback((): void => {
    if (layoutDirty && !window.confirm('您的操作还没保存，确认退出？')) return
    if (editingPendingScene && layoutBeforeEditor !== null) setLayout(layoutBeforeEditor)
    setEditingPendingScene(false)
    setLayoutBeforeEditor(null)
    setLayoutEditorOpen(false)
  }, [editingPendingScene, layoutBeforeEditor, layoutDirty])
  const openTutorial = useCallback((): void => {
    setTutorialOpen(true)
    setTutorialError(null)
    if (tutorialText !== null) return
    void fetch('/dsh-lookseek/docs/scene-editor.zh.md', { cache: 'no-store' })
      .then(async response => {
        if (!response.ok) throw new Error('无法加载操作教程')
        return await response.text()
      })
      .then(setTutorialText)
      .catch((error: unknown) => { setTutorialError(responseMessage(error)) })
  }, [tutorialText])
  const beginRoute = useCallback((mode: LayoutRoute['mode']): void => {
    setRouteMode(mode)
    setRouteDraft({ mode, startId: null, controlPoints: [] })
    setLayoutMessage(mode === 'polyline' ? '直线模式：在场景中左键点击起点，再左键点击终点。' : '曲线模式：左键点击起点，右键添加弯曲点，再左键点击终点。')
  }, [])
  const selectRoutePoint = useCallback((pointId: string): void => {
    setSelectedPointId(pointId)
    setRouteDraft(current => {
      const expectedFrom = layout.points[routeIndex]
      const expectedTo = layout.points[routeIndex + 1]
      if (expectedFrom === undefined || expectedTo === undefined) {
        setLayoutMessage('所有顺序路线已绘制完成，可以保存并启用。')
        return current
      }
      if (current.startId === null) {
        if (pointId !== expectedFrom.id) setLayoutMessage(`请先选择起点：${expectedFrom.id}。`)
        return pointId === expectedFrom.id ? { ...current, startId: pointId } : current
      }
      if (current.startId === pointId) return current
      if (pointId !== expectedTo.id) {
        setLayoutMessage(`当前路线终点应为：${expectedTo.id}。`)
        return current
      }
      const routeId = `${current.startId}-${pointId}`
      if (layout.routes.some(route => route.from === current.startId && route.to === pointId)) {
        setLayoutMessage('这条有向路线已经存在。')
        return { ...current, startId: null, controlPoints: [] }
      }
      const from = layout.points.find(point => point.id === current.startId)
      const to = layout.points.find(point => point.id === pointId)
      if (from === undefined || to === undefined) return current
      setLayout(value => ({ ...value, routesNeedCalibration: true, routes: [...value.routes, { id: routeId, from: from.id, to: to.id, mode: current.mode, points: [from.position, ...current.controlPoints, to.position] }] }))
      setLayoutDirty(true)
      setSelectedRouteId(routeId)
      setRouteIndex(index => index + 1)
      setLayoutMessage('路线已绘制，保存并启用后才会被机器人使用。')
      return { ...current, startId: null, controlPoints: [] }
    })
  }, [layout.points, layout.routes, routeIndex])
  const addCurvePoint = useCallback((position: readonly [number, number, number]): void => {
    setRouteDraft(current => {
      if (current.startId === null || current.mode === 'polyline') return current
      setLayoutDirty(true)
      return { ...current, controlPoints: [...current.controlPoints, position] }
    })
  }, [])
  const openDetail = useCallback((member: WorkspaceMember): void => {
    setSelectedId(member.id)
    setDetailId(member.id)
    setPresetContent(null)
    setDetailMessage(null)
    if (member.presetId === undefined) return
    void api.agentPresets.read({ agentPreset: member.presetId }).then((response: Awaited<ReturnType<WorkshopApi['agentPresets']['read']>>) => {
      if (response.result.ok) setPresetContent(response.result.value.content)
      else setDetailMessage(response.result.error.message)
    }).catch((error: unknown) => { setDetailMessage(responseMessage(error)) })
  }, [api])
  const openPresetEditor = useCallback(async (): Promise<void> => {
    if (detail?.presetId === undefined) return
    try {
      const response = await api.agentPresets.openDocument({ agentPreset: detail.presetId })
      if (!response.result.ok) throw new Error(response.result.error.message)
      setDetailMessage(response.result.value.opened ? '已打开该智能体预设的编辑位置。' : `预设目录：${response.result.value.path}`)
    } catch (error) {
      setDetailMessage(responseMessage(error))
    }
  }, [api, detail?.presetId])

  return (
    <div ref={root} className={`lookseekRoot${layoutEditorOpen ? ' lookseekEditing' : ''}`} style={{ height }}>
      <header className="lookseekCommandBar" aria-label="运行概览">
        <div className="lookseekCommandIdentity"><span className="lookseekSignal" aria-hidden="true" /><span>LOOKSEEK / 工作间</span></div>
        <div className="lookseekCommandState">
          <span className={stateCounts.error > 0 ? 'lookseekCommandAlert' : ''}>{stateCounts.running > 0 ? '执行中' : '待命'}</span>
          <span>{stateCounts.running} 活跃</span>
          <span>{stateCounts.complete} 已完成</span>
          {leadIntent !== undefined && leadIntent.summary !== activityLabel(leadIntent) && <span className="lookseekCommandSummary">{activityLabel(leadIntent)} · {leadIntent.summary}</span>}
        </div>
        <div className="lookseekCommandTarget"><button type="button" className="lookseekSceneSettings" onClick={() => { setCameraResetToken(value => value + 1) }} aria-label="复位视角" title="复位视角">&#8634;</button><button type="button" className="lookseekSceneSettings" onClick={() => { setSceneSettingsOpen(true); setSceneUploadMessage(null) }} aria-label="场景设置" title="场景设置">&#9881;</button>{leadIntent === undefined ? '未分配工位' : stationNames[leadIntent.target]}</div>
      </header>
      <section className="lookseekSceneWrap" aria-label={t('sceneLabel')}>
        <div className="lookseekSceneFrame">
          <WorkshopScene
            members={visible}
            selectedId={selectedId}
            onSelect={select}
            label={t('sceneLabel')}
            layout={layout}
            resetCameraToken={cameraResetToken}
            editor={layoutEditorOpen ? {
              selectedPointId,
              selectedRouteId,
              routeDraft,
              phase: editorStep,
              activePointId: editorStep === 'points' ? layout.points[pointIndex]?.id ?? '' : undefined,
              calibratedPointIds: editorStep === 'points' ? layout.points.slice(0, pointIndex + 1).map(point => point.id) : undefined,
              routeGuide: editorStep === 'routes' && layout.points[routeIndex + 1] !== undefined ? { fromId: layout.points[routeIndex]?.id ?? '', toId: layout.points[routeIndex + 1]?.id ?? '' } : undefined,
              onSelectPoint: editorStep === 'points' ? setSelectedPointId : selectRoutePoint,
              onSelectRoute: setSelectedRouteId,
              onMovePoint: (id, position) => updatePoint(id, point => ({ ...point, position })),
              onMoveWaypoint: (routeId, index, position) => {
                setLayoutDirty(true)
                setLayout(current => ({
                  ...current,
                  routesNeedCalibration: true,
                  routes: current.routes.map(route => route.id !== routeId ? route : {
                    ...route,
                    points: route.points.map((point, pointIndex) => pointIndex === index ? position : point),
                  }),
                }))
              },
              onAddCurvePoint: addCurvePoint,
            } : undefined}
          />
        </div>
        <p className="lookseekLegend">
          {selected === null ? t('title') : `${selected.name} · ${stationNames[selected.intent.target]}`}
        </p>
      </section>
      <aside className="lookseekRoster" aria-label={t('members')}>
        <div className="lookseekRosterHeading">
          <div>
            <h2 className="lookseekHeading">当前智能体</h2>
            <p className="lookseekCount">进行中 {stateCounts.running} · 已完成 {stateCounts.complete} · 未完成 {stateCounts.incomplete}{stateCounts.error > 0 ? ` · 出错 ${stateCounts.error}` : ''}</p>
          </div>
        </div>
        <section className="lookseekMetricGrid" aria-label="实时运行指标">
          <div><strong>{stateCounts.running}</strong><span>活跃智能体</span></div>
          <div><strong>{tasks.filter(task => task.status === 'in_progress').length}</strong><span>执行任务</span></div>
          <div><strong>{recentIntents.length}</strong><span>真实事件</span></div>
        </section>
        {members.length === 0 && <p className="lookseekEmpty">当前会话还没有可展示的智能体。</p>}
        {members.map(member => (
          <button
            key={member.id}
            type="button"
            className={`lookseekMember ${member.id === selectedId ? 'lookseekSelected' : ''}`}
            onClick={() => { openDetail(member) }}
          >
            <span className={`lookseekDot ${member.running ? 'lookseekDotRunning' : ''}`} />
            <span>
              <span className="lookseekName">{member.name}</span>
              <span className="lookseekPreset">{member.presetId ?? '宿主默认组成'}</span>
              <span className={`lookseekState lookseekState-${memberState(member)}`}>{memberStateLabel(member)}</span>
              <span className="lookseekSummary">{activityLabel(member.intent)}</span>
              <span className="lookseekMeta">
                {t('station', { station: stationNames[member.intent.target] })}
                {completedDuration(member, recentIntents) === undefined ? '' : ` · 本轮耗时 ${completedDuration(member, recentIntents)}`}
              </span>
            </span>
          </button>
        ))}
        {rosterError !== null && <p className="lookseekNotice">预设列表暂不可用：{rosterError}</p>}
      </aside>
      <aside className="lookseekTasks" aria-label="计划任务">
        <div className="lookseekTasksHeading">
          <h2 className="lookseekHeading">计划任务</h2>
          <p className="lookseekCount">{tasks.length} 项</p>
        </div>
        {tasks.length === 0 && <p className="lookseekEmpty">当前会话还没有计划任务。</p>}
        {tasks.length > 0 && <ol className="lookseekTaskList">
          {tasks.map((task, index) => <li key={`${task.content}\u0000${index}`} className={`lookseekTask lookseekTask-${task.status}`}>
            <span className="lookseekTaskMarker" aria-hidden="true" />
            <span className="lookseekTaskContent">{task.content}</span>
            <span className="lookseekTaskState">{taskStatusLabel(task.status)}</span>
            {task.agentName !== undefined && <span className="lookseekTaskAgent">{task.agentName}</span>}
          </li>)}
        </ol>}
        <section className="lookseekNow" aria-label="最近工具事件">
          <div className="lookseekNowHeading"><h3>最近执行事件</h3><span>{recentIntents.length} 条</span></div>
          {recentIntents.length === 0 && <p>暂无可公开展示的工具事件。</p>}
          {recentIntents.length > 0 && <ol>
            {recentIntents.slice(0, 3).map(intent => <li key={`${intent.agentId}\u0000${intent.at}`}>
              <span>{activityLabel(intent)}</span>
              <span>{intent.summary}</span>
            </li>)}
          </ol>}
        </section>
      </aside>
      {detail !== null && (
        <div className="lookseekDialogBackdrop" role="presentation" onMouseDown={() => { setDetailId(null) }}>
          <section className="lookseekDialog" role="dialog" aria-modal="true" aria-label={`${detail.name} 的详情`} onMouseDown={event => { event.stopPropagation() }}>
            <div className="lookseekDialogTitle"><div><h2>{detail.name}</h2><p>{memberStateLabel(detail)} · {activityLabel(detail.intent)}</p></div><button type="button" className="lookseekClose" onClick={() => { setDetailId(null) }} aria-label="关闭">×</button></div>
            <dl className="lookseekDetailGrid"><dt>角色</dt><dd>{roleLabel(detail.role)}</dd><dt>工位</dt><dd>{stationNames[detail.intent.target]}</dd><dt>预设</dt><dd>{detailPreset?.name ?? detail.presetId ?? '宿主默认组成'}</dd><dt>状态</dt><dd>{memberStateLabel(detail)} · {activityLabel(detail.intent)}</dd></dl>
            {detailPreset?.description !== undefined && <p className="lookseekDescription">{detailPreset.description}</p>}
            {presetContent !== null && <pre className="lookseekPresetContent">{presetContent}</pre>}
            <div className="lookseekDialogActions">
              {detailPreset?.trust === 'user' && <button type="button" onClick={() => { void openPresetEditor() }}>编辑预设</button>}
            </div>
            {detailMessage !== null && <p className="lookseekNotice">{detailMessage}</p>}
          </section>
        </div>
      )}
      {sceneSettingsOpen && <div className="lookseekDialogBackdrop" role="presentation" onMouseDown={() => { setSceneSettingsOpen(false) }}>
        <section className="lookseekDialog lookseekSceneSettingsDialog" role="dialog" aria-modal="true" aria-label="场景设置" onMouseDown={event => { event.stopPropagation() }}>
          <div className="lookseekDialogTitle"><div><h2>场景设置</h2><p>先导入自己的场景 GLB，再在该模型上编排工作点与路线。</p></div><button type="button" className="lookseekClose" onClick={() => { setSceneSettingsOpen(false) }} aria-label="关闭">×</button></div>
          <label className="lookseekSceneUpload"><span>场景 GLB</span><input type="file" accept=".glb,model/gltf-binary" disabled={uploadingScene} onChange={event => { void uploadScene(event.currentTarget.files?.[0]) }} /><small>仅支持 .glb，最大 30MB。导入后需完成编排并保存，才会替换当前工作间。</small></label>
          <p className="lookseekSceneCurrent">{layout.sceneAsset === 'custom' ? `当前场景：${layout.sceneAssetName ?? '已导入场景'}` : '当前场景：内置办公区。'}</p>
          {pendingSceneName !== null && <p className="lookseekSceneCurrent">待编排场景：{pendingSceneName}</p>}
          {sceneUploadMessage !== null && <p className="lookseekNotice">{sceneUploadMessage}</p>}
          <div className="lookseekDialogActions"><button type="button" onClick={() => { setSceneSettingsOpen(false) }}>取消</button><button type="button" className="lookseekPrimary" disabled={pendingSceneName === null || uploadingScene} onClick={beginEditorFromSettings}>进入编排</button></div>
        </section>
      </div>}
      {layoutEditorOpen && (
        <div className="lookseekDialogBackdrop lookseekEditorBackdrop" role="presentation">
          <div className="lookseekEditorGuide" aria-live="polite" style={{ position: 'fixed', zIndex: 1002, top: 18, left: '50%', display: 'grid', gap: 4, width: 'min(680px, calc(100vw - 80px))', transform: 'translateX(-50%)', padding: '10px 44px 10px 14px', border: '1px solid rgb(115 210 184 / .56)', borderRadius: 6, background: 'rgb(10 29 25 / .9)', color: '#f1fbf7', boxShadow: '0 8px 28px rgb(0 0 0 / .24)', textAlign: 'center', pointerEvents: 'none' }}>
            {editorStep === 'scale'
              ? <><strong>步骤 0 / 2 · 调整模型比例</strong><span>先让导入模型与机器人和工作区尺寸协调，再开始放置工作点。</span></>
              : editorStep === 'points' && calibrationPoint !== undefined
                ? <><strong>步骤 1 / 2 · 校准工作点 {pointIndex + 1} / {layout.points.length}</strong><span>{pointInstructions[calibrationPoint.activity] ?? '为当前工作点指定站位。'} 左键选中金色点，再用 W/A/S/D、空格和 Shift 调整位置。</span></>
                : <><strong>步骤 2 / 2 · 绘制路线 {routeIndex + 1} / {Math.max(0, layout.points.length - 1)}</strong><span>{layout.points[routeIndex + 1] === undefined ? '所有顺序路线已完成，可以保存并启用。' : routeDraft.startId === null ? `先左键选择起点：${layout.points[routeIndex]?.id}。` : routeDraft.mode === 'polyline' ? `移动鼠标预览，再左键点击下一点：${layout.points[routeIndex + 1]?.id}。` : `右键添加弯曲点，左键点击下一点：${layout.points[routeIndex + 1]?.id}。`}</span></>}
            <button type="button" className="lookseekTutorialHelp" onClick={openTutorial} aria-label="查看操作教程">?</button>
          </div>
          <section className="lookseekDialog lookseekRouteEditor" role="dialog" aria-modal="true" aria-label="自定义路线编辑器" onMouseDown={event => { event.stopPropagation() }}>
            <div className="lookseekDialogTitle"><div><h2>自定义路线编辑器</h2><p>保存后才会作为机器人可用路线。</p></div><button type="button" className="lookseekClose" onClick={closeLayoutEditor} aria-label="关闭">×</button></div>
            {editorStep === 'scale' && <section className="lookseekWizard" aria-live="polite">
              <p className="lookseekWizardStep">步骤 0 / 2 · 调整模型比例</p>
              <h3>先让场景大小合适</h3>
              <p>拖动比例条观察模型。模型偏小就调大，模型过大就调小；确认后再开始布置第一个工作点。</p>
              <label className="lookseekScaleControl"><span>模型比例 <output>{Math.round((layout.modelScale ?? 1) * 100)}%</output></span><input type="range" min="0.25" max="3" step="0.05" value={layout.modelScale ?? 1} onChange={event => { const modelScale = Number(event.target.value); setLayout(current => ({ ...current, modelScale })); setLayoutDirty(true) }} /></label>
              <div className="lookseekDialogActions"><button type="button" onClick={closeLayoutEditor}>取消</button><button type="button" className="lookseekPrimary" onClick={advanceScale}>比例确认，开始放点</button></div>
            </section>}
            {editorStep === 'points' && (() => {
              const point = layout.points[pointIndex]
              if (point === undefined) return null
              return <section className="lookseekWizard" aria-live="polite">
                <p className="lookseekWizardStep">步骤 1 / 2 · 校准工作点 · {pointIndex + 1} / {layout.points.length}</p>
                <h3>{point.id} · {point.activity}</h3>
                <p>{pointInstructions[point.activity] ?? '为此可信活动指定机器人到达后的站位。'}</p>
                <p>请在模型中左键选中高亮点，再用 W/A/S/D 调整平面位置；空格上移、Shift 下移，按住 Alt 可细调。</p>
                <div className="lookseekDialogActions"><button type="button" disabled={pointIndex === 0} onClick={retreatPoint}>上一个点</button><button type="button" className="lookseekPrimary" onClick={advancePoint}>{pointIndex === layout.points.length - 1 ? '确认并开始绘制路线' : '确认此点并继续'}</button></div>
              </section>
            })()}
            {editorStep === 'routes' && <div className="lookseekRouteGrid">
              <section><h3>活动节点</h3><select value={selectedPointId} onChange={event => { setSelectedPointId(event.target.value) }}>{layout.points.map(point => <option key={point.id} value={point.id}>{point.id} · {point.activity}</option>)}</select>
                {layout.points.filter(point => point.id === selectedPointId).map(point => <div key={point.id} className="lookseekCoordinates">
                  {(['X', 'Y', 'Z'] as const).map((axis, index) => <label key={axis}>{axis}<input type="number" step="0.01" value={point.position[index]} onChange={event => { const value = Number(event.target.value); if (Number.isFinite(value)) updatePoint(point.id, current => ({ ...current, position: index === 0 ? [value, current.position[1], current.position[2]] : index === 1 ? [current.position[0], value, current.position[2]] : [current.position[0], current.position[1], value] })) }} /></label>)}
                  <label>朝向<input type="number" step="0.1" value={point.facing} onChange={event => { const value = Number(event.target.value); if (Number.isFinite(value)) updatePoint(point.id, current => ({ ...current, facing: value })) }} /></label>
                </div>)}
                <p className="lookseekRouteHint">场景中直接拖动彩色节点。选中节点后：W/A/S/D 移动平面位置，空格上移，Shift 下移，按住 Alt 精细移动。</p>
              </section>
              <section><h3>绘制连接</h3><div className="lookseekRouteModes"><button type="button" className={routeMode === 'polyline' ? 'lookseekRouteSelected' : ''} onClick={() => { beginRoute('polyline') }}>直线</button><button type="button" className={routeMode === 'spline' ? 'lookseekRouteSelected' : ''} onClick={() => { beginRoute('spline') }}>曲线</button></div><p className="lookseekRouteHint">{routeDraft.startId === null ? '选择模式后，在场景中点击起始节点。' : routeDraft.mode === 'polyline' ? `已选 ${routeDraft.startId}，移动鼠标预览并左键点击终点。` : `已选 ${routeDraft.startId}，右键添加弯曲点，左键点击终点。`}</p><ol className="lookseekRouteList">{layout.routes.map(route => <li key={route.id}><button type="button" className={route.id === selectedRouteId ? 'lookseekRouteSelected' : ''} onClick={() => { setSelectedRouteId(route.id) }}>{route.from} → {route.to} · {route.mode}</button></li>)}</ol><p className="lookseekRouteHint">已绘制路线的白色控制点可拖动。必连：intake → planning。重复路线、同点连接、越界坐标和未绑定端点无法保存。</p></section>
            </div>}
            {layout.routesNeedCalibration && <p className="lookseekNotice">当前改动尚未保存，机器人不会使用这些路线。</p>}
            {layoutMessage !== null && <p className="lookseekNotice">{layoutMessage}</p>}
            <div className="lookseekDialogActions">{editorStep === 'routes' && <><button type="button" onClick={() => { setEditorStep('points'); setPointIndex(layout.points.length - 1); setSelectedPointId(layout.points.at(-1)?.id ?? '') }}>返回工作点</button><button type="button" className="lookseekPrimary" onClick={() => { void saveLayout() }}>保存并启用路线</button></>}</div>
          </section>
          {tutorialOpen && <section className="lookseekTutorial" role="dialog" aria-modal="true" aria-label="路线编排教程"><header><div><p>LookSeek</p><h2>场景路线编排教程</h2></div><button type="button" onClick={() => { setTutorialOpen(false) }}>返回编排</button></header>{tutorialText === null && tutorialError === null && <p className="lookseekTutorialState">正在加载教程…</p>}{tutorialError !== null && <p className="lookseekTutorialState">{tutorialError}</p>}{tutorialText !== null && <TutorialDocument source={tutorialText} />}</section>}
        </div>
      )}
    </div>
  )
}

/** Compact header presence signal; it remains absent for a one-agent session. */
export function WorkspacePulse({ useSessions, sessionId, t }: PropsRuntime<'conversation.session.header.actions'> & PropsLocale<'lookseek'>) {
  const summaries = useSessions(state => Object.values(state.byId))
  const team = sessionsFor(sessionId, summaries)
  const active = team.filter(session => session.running)
  if (team.length < 2) return null
  return (
    <span className="lookseekPulse" title={t('teamStatus')} aria-label={t('teamStatus')}>
      <span className="lookseekAvatars" aria-hidden="true">
        {team.slice(0, 4).map(session => <span key={session.id} className="lookseekAvatar">{session.displayTitle.slice(0, 1)}</span>)}
      </span>
      <span>{active.length > 0 ? `${active.length} ${t('working')}` : t('idle')}</span>
    </span>
  )
}
