export const NS = 'lookseek'

export const zh = {
  'view': '工作间',
  'title': '团队工作间',
  'sceneLabel': '等距工作间场景',
  'members': '成员',
  'idle': '待命',
  'more': '+{count} 名成员在团队地图中',
  'empty': '还没有可显示的 Agent。开始一次任务后，成员会出现在这里。',
  'working': '工作中',
  'station': '工位：{station}',
  'teamStatus': '团队状态',
} as const

export const en = {
  'view': 'Workshop',
  'title': 'Team Workshop',
  'sceneLabel': 'Isometric workshop scene',
  'members': 'Members',
  'idle': 'Idle',
  'more': '+{count} members on the team map',
  'empty': 'No agents are visible yet. Start a task to populate the workshop.',
  'working': 'Working',
  'station': 'Station: {station}',
  'teamStatus': 'Team status',
} as const

export type LookseekLocaleKey = keyof typeof zh
