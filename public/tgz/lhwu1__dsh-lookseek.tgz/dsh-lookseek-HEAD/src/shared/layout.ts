/** A point placed by the user inside the active scene. */
export interface LayoutPoint {
  id: string
  activity: string
  position: readonly [number, number, number]
  facing: number
}

/** A user-authored route between two activity points. */
export interface LayoutRoute {
  id: string
  from: string
  to: string
  mode: 'polyline' | 'rounded' | 'spline'
  points: readonly (readonly [number, number, number])[]
}

/** Durable LookSeek scene layout stored in the user's Harness home. */
export interface LookseekLayout {
  version: 1
  sceneAsset: 'builtin' | 'custom'
  sceneAssetName?: string
  modelScale?: number
  robotAsset: 'builtin' | 'custom'
  routesNeedCalibration: boolean
  points: readonly LayoutPoint[]
  routes: readonly LayoutRoute[]
}

export interface LayoutValidation {
  valid: boolean
  errors: readonly string[]
}

const WORKSPACE_LIMIT = 8
const REQUIRED_CONNECTIONS: readonly (readonly [string, string])[] = [['intake', 'planning']]

/** Validate a user-authored route graph before it can animate a worker. */
export function validateLayout(layout: LookseekLayout): LayoutValidation {
  const errors: string[] = []
  const points = new Map(layout.points.map(point => [point.id, point]))
  const routePairs = new Set<string>()
  for (const route of layout.routes) {
    const key = `${route.from}\u0000${route.to}`
    if (!points.has(route.from) || !points.has(route.to) || route.from === route.to) errors.push(`路线 ${route.id} 的端点无效`)
    if (routePairs.has(key)) errors.push(`路线 ${route.from} 到 ${route.to} 重复`)
    routePairs.add(key)
    if (route.points.length < 2) errors.push(`路线 ${route.from} 到 ${route.to} 至少需要起点和终点`)
    const start = points.get(route.from)?.position
    const end = points.get(route.to)?.position
    if (start !== undefined && JSON.stringify(route.points[0]) !== JSON.stringify(start)) errors.push(`路线 ${route.from} 的起点未绑定节点`)
    if (end !== undefined && JSON.stringify(route.points.at(-1)) !== JSON.stringify(end)) errors.push(`路线 ${route.to} 的终点未绑定节点`)
    for (const position of route.points) {
      if (position.some(value => !Number.isFinite(value) || Math.abs(value) > WORKSPACE_LIMIT)) {
        errors.push(`路线 ${route.from} 到 ${route.to} 超出工作区范围`)
        break
      }
    }
  }
  for (const [from, to] of REQUIRED_CONNECTIONS) {
    if (points.has(from) && points.has(to) && !routePairs.has(`${from}\u0000${to}`)) errors.push(`必须连接 ${from} 到 ${to}`)
  }
  return { valid: errors.length === 0, errors }
}

/** The bundled office starts as an editable, conservative route graph. */
export const defaultLayout: LookseekLayout = {
  version: 1,
  sceneAsset: 'builtin',
  modelScale: 1,
  robotAsset: 'builtin',
  routesNeedCalibration: false,
  points: [
    { id: 'intake', activity: 'receive', position: [1.327, 0.06, 1.837], facing: Math.PI },
    { id: 'planning', activity: 'plan', position: [0.511, 0.06, -0.16], facing: Math.PI },
    { id: 'library', activity: 'read', position: [0.387, 0.06, 3.197], facing: Math.PI / 2 },
    { id: 'code', activity: 'edit', position: [-2.902, 0.06, 1.66], facing: Math.PI / 2 },
    { id: 'terminal', activity: 'shell', position: [-2.897, 0.06, -0.212], facing: Math.PI },
    { id: 'window', activity: 'web', position: [0.608, 0.06, -2.714], facing: Math.PI },
    { id: 'validation', activity: 'verify', position: [-2.75, 0.06, 3.314], facing: Math.PI },
    { id: 'approval', activity: 'approval', position: [-1.089, 0.06, -0.943], facing: Math.PI },
    { id: 'repair', activity: 'repair', position: [-2.92, 0.06, -1.887], facing: Math.PI / 2 },
    { id: 'lounge', activity: 'idle', position: [3.435, 0.06, 3.012], facing: Math.PI },
    { id: 'delivery', activity: 'complete', position: [3.767, 0.06, -0.169], facing: Math.PI },
  ],
  routes: [
    { id: 'intake-planning', from: 'intake', to: 'planning', mode: 'spline', points: [[1.327, 0.06, 1.837], [-0.559, 0.06, 1.342], [-0.092, 0.06, -0.276], [0.511, 0.06, -0.16]] },
    { id: 'planning-library', from: 'planning', to: 'library', mode: 'spline', points: [[0.511, 0.06, -0.16], [0.049, 0.06, -0.716], [-0.889, 0.06, 1.127], [0.387, 0.06, 3.197]] },
    { id: 'library-code', from: 'library', to: 'code', mode: 'spline', points: [[0.387, 0.06, 3.197], [-1.254, 0.06, 1.756], [-2.902, 0.06, 1.66]] },
    { id: 'code-terminal', from: 'code', to: 'terminal', mode: 'spline', points: [[-2.902, 0.06, 1.66], [-1.179, 0.06, 1.519], [-1.167, 0.06, 0.138], [-2.897, 0.06, -0.212]] },
    { id: 'terminal-window', from: 'terminal', to: 'window', mode: 'spline', points: [[-2.897, 0.06, -0.212], [-0.604, 0.06, -0.253], [0.928, 0.06, -2.011], [0.608, 0.06, -2.714]] },
    { id: 'window-validation', from: 'window', to: 'validation', mode: 'spline', points: [[0.608, 0.06, -2.714], [-0.853, 0.06, 0.21], [-1.094, 0.06, 3.566], [-2.75, 0.06, 3.314]] },
    { id: 'validation-approval', from: 'validation', to: 'approval', mode: 'spline', points: [[-2.75, 0.06, 3.314], [-0.589, 0.06, 3.068], [-1.089, 0.06, -0.943]] },
    { id: 'approval-repair', from: 'approval', to: 'repair', mode: 'spline', points: [[-1.089, 0.06, -0.943], [-0.623, 0.06, -2.432], [-2.24, 0.06, -2.627], [-2.92, 0.06, -1.887]] },
    { id: 'repair-lounge', from: 'repair', to: 'lounge', mode: 'spline', points: [[-2.92, 0.06, -1.887], [-0.216, 0.06, -3.24], [4.287, 0.06, -2.06], [4.829, 0.06, 1.941], [4.776, 0.06, 3], [3.435, 0.06, 3.012]] },
    { id: 'lounge-delivery', from: 'lounge', to: 'delivery', mode: 'spline', points: [[3.435, 0.06, 3.012], [4.96, 0.06, 2.072], [5.042, 0.06, -0.439], [3.767, 0.06, -0.169]] },
    { id: 'delivery-lounge', from: 'delivery', to: 'lounge', mode: 'spline', points: [[3.767, 0.06, -0.169], [5.042, 0.06, -0.439], [4.96, 0.06, 2.072], [3.435, 0.06, 3.012]] },
    { id: 'lounge-intake', from: 'lounge', to: 'intake', mode: 'spline', points: [[3.435, 0.06, 3.012], [4.95, 0.06, 2.05], [4.86, 0.06, 0.18], [3.44, 0.06, 0.04], [1.327, 0.06, 1.837]] },
  ],
}

/** Reject malformed layout JSON before it controls the visual scene. */
export function isLayout(value: unknown): value is LookseekLayout {
  if (typeof value !== 'object' || value === null) return false
  const layout = value as Partial<LookseekLayout>
  return layout.version === 1
    && (layout.sceneAsset === 'builtin' || layout.sceneAsset === 'custom')
    && (layout.robotAsset === 'builtin' || layout.robotAsset === 'custom')
    && (layout.modelScale === undefined || (typeof layout.modelScale === 'number' && Number.isFinite(layout.modelScale) && layout.modelScale >= 0.25 && layout.modelScale <= 3))
    && typeof layout.routesNeedCalibration === 'boolean'
    && Array.isArray(layout.points)
    && Array.isArray(layout.routes)
}
