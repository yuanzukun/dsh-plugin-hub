import type { VisualIntent } from './visual-intent.ts'

/** In-memory latest intent per Agent plus a bounded recent-event log. */
export class VisualIntentStore {
  private readonly latest = new Map<string, VisualIntent>()
  private recent: VisualIntent[] = []

  public constructor(private readonly maxIntents: number) {}

  /** Record one intent and replace the Agent's visible state atomically. */
  public publish(intent: VisualIntent): void {
    this.latest.set(intent.agentId, intent)
    this.recent = [intent, ...this.recent].slice(0, this.maxIntents)
  }

  /** Return a serializable snapshot; callers cannot mutate the store's collections. */
  public snapshot(): { agents: readonly VisualIntent[]; recent: readonly VisualIntent[] } {
    return { agents: [...this.latest.values()], recent: [...this.recent] }
  }
}
