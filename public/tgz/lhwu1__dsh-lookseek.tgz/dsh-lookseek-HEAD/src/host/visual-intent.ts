/** Safe, display-only summary of one agent's current activity. */
export type VisualActivity =
  | 'receive' | 'plan' | 'read' | 'edit' | 'shell' | 'web' | 'verify'
  | 'approval' | 'repair' | 'handoff' | 'complete' | 'idle' | 'external-wait'

/** Workstation ids shared by the host event adapter and the browser scene. */
export type StationId =
  | 'intake' | 'planning' | 'library' | 'code' | 'terminal' | 'window'
  | 'validation' | 'approval' | 'repair' | 'lounge' | 'delivery' | 'review'

/** A sanitized event the browser may use to animate an Agent. */
export interface VisualIntent {
  agentId: string
  agentName?: string
  presetId?: string
  role?: 'coordinator' | 'engineer' | 'researcher' | 'tester' | 'reviewer' | 'designer' | 'operator'
  activity: VisualActivity
  target: StationId
  summary: string
  at: number
  sessionId?: string
}

const SENSITIVE = /(?:[a-z]:\\|\/home\/|\/users\/|\b(?:api[_-]?key|token|password|secret)\b|sk-[\w-]{8,})/i
const MAX_SUMMARY = 96

/** Remove values that should never reach a visual status surface. */
export function safeSummary(value: string): string {
  const compact = value.replace(/\s+/g, ' ').trim()
  if (SENSITIVE.test(compact)) return '正在处理受保护的工作内容'
  return compact.slice(0, MAX_SUMMARY) || '正在处理任务'
}

/** Keep rendering targets coherent when a reporter submits mismatched input. */
export function stationFor(activity: VisualActivity, target?: StationId): StationId {
  if (target !== undefined) return target
  switch (activity) {
    case 'receive': return 'intake'
    case 'plan': return 'planning'
    case 'read': return 'library'
    case 'edit': return 'code'
    case 'shell': return 'terminal'
    case 'web': return 'window'
    case 'verify': return 'validation'
    case 'approval': return 'approval'
    case 'repair': return 'repair'
    case 'handoff': return 'review'
    case 'complete': return 'delivery'
    case 'idle': return 'lounge'
    case 'external-wait': return 'window'
  }
}

/** Normalize untrusted reporting-tool arguments into the public visual protocol. */
export function toVisualIntent(input: {
  agentId: string
  agentName?: string
  presetId?: string
  role?: VisualIntent['role']
  activity: VisualActivity
  target?: StationId
  summary: string
  sessionId?: string
}): VisualIntent {
  return {
    agentId: input.agentId.slice(0, 80),
    ...(input.agentName === undefined ? {} : { agentName: safeSummary(input.agentName) }),
    ...(input.presetId === undefined ? {} : { presetId: input.presetId.slice(0, 80) }),
    ...(input.role === undefined ? {} : { role: input.role }),
    activity: input.activity,
    target: stationFor(input.activity, input.target),
    summary: safeSummary(input.summary),
    at: Date.now(),
    ...(input.sessionId === undefined ? {} : { sessionId: input.sessionId.slice(0, 80) }),
  }
}
