import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import type { IncomingMessage } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { visualIntents } from './index.ts'
import { activateSceneDraft, customScenePath, layoutPath, readLayout, readSceneDraft, sceneDraftPath, writeLayout, writeSceneDraft } from './layout-store.ts'

export const name = 'dsh-lookseek-web'
export const inject = ['webServer']

const MAX_LAYOUT_BODY = 512 * 1024
const MAX_SCENE_BYTES = 30 * 1024 * 1024

async function readJson(request: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of request) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += bytes.length
    if (size > MAX_LAYOUT_BODY) throw new RangeError('LookSeek layout request exceeds 512 KiB')
    chunks.push(bytes)
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'))
}

async function readGlb(request: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of request) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += bytes.length
    if (size > MAX_SCENE_BYTES) throw new RangeError('场景文件不能超过 30MB')
    chunks.push(bytes)
  }
  const file = Buffer.concat(chunks)
  if (file.length < 12 || file.toString('ascii', 0, 4) !== 'glTF') throw new TypeError('请选择有效的 .glb 文件')
  return file
}

/** Expose only the sanitized in-memory snapshot on the Harness origin. */
export function apply(ctx: Context): void {
  const sceneAsset = fileURLToPath(new URL('../../assets/office-workstations.glb', import.meta.url))
  const tutorial = fileURLToPath(new URL('../../docs/scene-editor.zh.md', import.meta.url))
  ctx.effect(() => {
    const intents = ctx.webServer.register({
      kind: 'exact', path: '/dsh-lookseek/intents.json',
      handler(_request, response) {
        response.writeHead(200, {
          'content-type': 'application/json; charset=utf-8',
          'cache-control': 'no-store',
        })
        response.end(JSON.stringify(visualIntents.snapshot()))
      },
    })
    const layout = ctx.webServer.register({
      kind: 'exact', path: '/dsh-lookseek/layout.json',
      async handler(request, response) {
        if (request.method === 'GET') {
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ path: layoutPath(), layout: await readLayout() }))
          return
        }
        if (request.method !== 'PUT') {
          response.writeHead(405, { allow: 'GET, PUT' })
          response.end()
          return
        }
        try {
          const saved = await writeLayout(await readJson(request))
          if (saved.sceneAsset === 'custom') await activateSceneDraft()
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ path: layoutPath(), layout: saved }))
        } catch (error) {
          response.writeHead(400, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ error: error instanceof Error ? error.message : String(error) }))
        }
      },
    })
    const sceneDraft = ctx.webServer.register({
      kind: 'exact', path: '/dsh-lookseek/scene-draft.json',
      async handler(request, response) {
        if (request.method !== 'GET') {
          response.writeHead(405, { allow: 'GET' })
          response.end()
          return
        }
        response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
        response.end(JSON.stringify({ draft: await readSceneDraft() }))
      },
    })
    const documentation = ctx.webServer.register({
      kind: 'exact', path: '/dsh-lookseek/docs/scene-editor.zh.md',
      async handler(_request, response) {
        response.writeHead(200, { 'content-type': 'text/markdown; charset=utf-8', 'cache-control': 'no-store' })
        response.end(await readFile(tutorial))
      },
    })
    const sceneUpload = ctx.webServer.register({
      kind: 'exact', path: '/dsh-lookseek/scene.glb',
      async handler(request, response) {
        if (request.method !== 'POST') {
          response.writeHead(405, { allow: 'POST' })
          response.end()
          return
        }
        try {
          const file = await readGlb(request)
          const name = request.headers['x-lookseek-scene-name']
          if (typeof name !== 'string' || name.length === 0 || name.length > 255) throw new TypeError('场景文件名无效')
          await writeSceneDraft(file, name)
          response.writeHead(201, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ accepted: true }))
        } catch (error) {
          response.writeHead(400, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ error: error instanceof Error ? error.message : String(error) }))
        }
      },
    })
    const asset = ctx.webServer.register({
      kind: 'prefix', path: '/dsh-lookseek/assets',
      async handler(_request, response) {
        try {
          const body = await readFile(_request.url?.includes('draft-scene.glb') ? sceneDraftPath() : _request.url?.includes('custom-scene.glb') ? customScenePath() : sceneAsset)
          response.writeHead(200, {
            'content-type': 'model/gltf-binary',
            'cache-control': 'public, max-age=86400',
          })
          response.end(body)
        } catch (error) {
          response.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' })
          response.end(error instanceof Error ? error.message : 'Lookseek scene asset is unavailable')
        }
      },
    })
    return () => { intents(); layout(); sceneDraft(); documentation(); sceneUpload(); asset() }
  }, 'dsh-lookseek: visual workspace routes')
}
