import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { defaultLayout, isLayout, validateLayout, type LookseekLayout } from '../shared/layout.ts'

const MAX_LAYOUT_BYTES = 512 * 1024

/** Scene file waiting for route calibration before it replaces the active scene. */
export interface SceneDraft {
  name: string
}

/** Resolve the per-user JSON path without relying on a browser-local cache. */
export function layoutPath(): string {
  const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
  return resolve(home, 'lookseek', 'layout.json')
}

/** Resolve the user-provided GLB file without exposing an arbitrary path. */
export function customScenePath(): string {
  return resolve(dirname(layoutPath()), 'custom-scene.glb')
}

/** Resolve the staged GLB path used only by the route editor. */
export function sceneDraftPath(): string {
  return resolve(dirname(layoutPath()), 'scene-draft.glb')
}

function sceneDraftMetadataPath(): string {
  return resolve(dirname(layoutPath()), 'scene-draft.json')
}

/** Read the staged scene metadata, if a scene is waiting for calibration. */
export async function readSceneDraft(): Promise<SceneDraft | undefined> {
  try {
    const value: unknown = JSON.parse(await readFile(sceneDraftMetadataPath(), 'utf8'))
    if (typeof value !== 'object' || value === null || typeof (value as Partial<SceneDraft>).name !== 'string') throw new TypeError('LookSeek scene draft metadata has an unsupported format')
    return { name: (value as SceneDraft).name }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined
    throw error
  }
}

/** Persist a GLB as a route-editor draft without replacing the active scene. */
export async function writeSceneDraft(file: Buffer, name: string): Promise<SceneDraft> {
  const draft: SceneDraft = { name }
  const directory = dirname(layoutPath())
  await mkdir(directory, { recursive: true, mode: 0o700 })
  const filePath = sceneDraftPath()
  const metadataPath = sceneDraftMetadataPath()
  await writeFile(`${filePath}.${process.pid}.tmp`, file, { mode: 0o600 })
  await rename(`${filePath}.${process.pid}.tmp`, filePath)
  await writeFile(`${metadataPath}.${process.pid}.tmp`, `${JSON.stringify(draft)}\n`, { mode: 0o600 })
  await rename(`${metadataPath}.${process.pid}.tmp`, metadataPath)
  return draft
}

/** Promote the calibrated scene draft after its layout has been saved. */
export async function activateSceneDraft(): Promise<void> {
  if (await readSceneDraft() === undefined) throw new TypeError('LookSeek scene draft is unavailable')
  await rename(sceneDraftPath(), customScenePath())
  await unlink(sceneDraftMetadataPath())
}

/** Read the saved layout, falling back to the editable bundled default. */
export async function readLayout(): Promise<LookseekLayout> {
  try {
    const text = await readFile(layoutPath(), 'utf8')
    const value: unknown = JSON.parse(text)
    if (!isLayout(value)) throw new TypeError('LookSeek layout JSON has an unsupported format')
    return value
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return defaultLayout
    throw error
  }
}

/** Validate and atomically replace the user-owned layout file. */
export async function writeLayout(value: unknown): Promise<LookseekLayout> {
  if (!isLayout(value)) throw new TypeError('LookSeek layout JSON has an unsupported format')
  const validation = validateLayout(value)
  if (!validation.valid) throw new TypeError(`LookSeek layout cannot be enabled: ${validation.errors.join('；')}`)
  const output = `${JSON.stringify(value, null, 2)}\n`
  if (Buffer.byteLength(output) > MAX_LAYOUT_BYTES) throw new RangeError('LookSeek layout exceeds 512 KiB')
  const path = layoutPath()
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  const temporary = `${path}.${process.pid}.tmp`
  await writeFile(temporary, output, { mode: 0o600 })
  await rename(temporary, path)
  return value
}
