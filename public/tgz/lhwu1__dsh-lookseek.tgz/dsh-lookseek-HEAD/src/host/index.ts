import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { VisualIntentStore } from './store.ts'
import { toVisualIntent, type StationId, type VisualActivity, type VisualIntent } from './visual-intent.ts'

export const name = 'dsh-lookseek'
export const inject = ['tools']

/** Deployment options for the event cache. */
export interface Config { maxIntents?: number }

/** Shared process-local store consumed by the web-only half. */
export const visualIntents = new VisualIntentStore(80)

const activities: readonly VisualActivity[] = [
  'receive', 'plan', 'read', 'edit', 'shell', 'web', 'verify', 'approval',
  'repair', 'handoff', 'complete', 'idle', 'external-wait',
]
const stations: readonly StationId[] = [
  'intake', 'planning', 'library', 'code', 'terminal', 'window', 'validation',
  'approval', 'repair', 'lounge', 'delivery', 'review',
]

function activityForTool(name: string): VisualActivity {
  const normalized = name.toLowerCase()
  if (/(?:read|glob|list|stat|search.*file)/.test(normalized)) return 'read'
  if (/(?:write|edit|patch|apply)/.test(normalized)) return 'edit'
  if (/(?:web|browser|fetch|search)/.test(normalized)) return 'web'
  if (/(?:test|lint|typecheck|build|verify)/.test(normalized)) return 'verify'
  if (/(?:shell|bash|terminal|process|command)/.test(normalized)) return 'shell'
  return 'plan'
}

function publishActivity(store: VisualIntentStore, agentId: string, activity: VisualActivity, summary: string): void {
  store.publish(toVisualIntent({ agentId, activity, summary }))
}

/**
 * Installs a narrow reporting tool. Event adapters may call `publishVisualIntent`
 * directly; the tool gives third-party Agent presets an explicit, safe integration.
 */
export function apply(ctx: Context, config: Config = {}): void {
  const store = config.maxIntents === undefined || config.maxIntents === 80
    ? visualIntents
    : new VisualIntentStore(Math.max(10, Math.min(config.maxIntents, 500)))
  ctx.effect(() => {
    const received = ctx.on('agent/pre-step', ({ agent }, next) => {
      publishActivity(store, agent.id, 'receive', '收到新的任务')
      return next()
    })
    const request = ctx.on('agent/request', ({ agent }, next) => {
      publishActivity(store, agent.id, 'plan', '正在整理下一步')
      return next()
    })
    const tool = ctx.on('tools/pre-execute', (execution, next) => {
      if (execution.agent !== undefined && execution.name !== 'lookseek_report') {
        const activity = activityForTool(execution.name)
        publishActivity(store, execution.agent.id, activity, `正在使用 ${activity === 'read' ? '资料工具' : activity === 'edit' ? '编辑工具' : activity === 'web' ? '网页工具' : activity === 'verify' ? '验证工具' : activity === 'shell' ? '命令工具' : '任务工具'}`)
      }
      return next()
    })
    const stopping = ctx.on('agent/turn-stopping', ({ agent }) => {
      publishActivity(store, agent.id, 'complete', '本轮任务已完成')
    })
    const report = ctx.tools.register(defineTool({
    name: 'lookseek_report',
    description: 'Report a concise, non-sensitive work status to the Lookseek visual workspace.',
    parameters: {
      agentId: { type: 'string', required: true, description: 'Stable agent or session identifier.' },
      agentName: { type: 'string', description: 'Short visible agent name.' },
      presetId: { type: 'string', description: 'Configured agent preset identifier.' },
      role: { type: 'string', enum: ['coordinator', 'engineer', 'researcher', 'tester', 'reviewer', 'designer', 'operator'] },
      activity: { type: 'string', required: true, enum: activities },
      target: { type: 'string', enum: stations },
      summary: { type: 'string', required: true, description: 'One safe, user-facing summary. Never include paths, commands, secrets, or raw parameters.' },
      sessionId: { type: 'string', description: 'Optional parent session identifier.' },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { accepted: { type: 'boolean' } } },
      render: () => [{ type: 'text', text: '工作间状态已更新。' }],
    },
    async execute(args) {
      store.publish(toVisualIntent(args as Parameters<typeof toVisualIntent>[0]))
      return { accepted: true }
    },
    }))
    return () => { received(); request(); tool(); stopping(); report() }
  }, 'dsh-lookseek: observe public agent activity')
}

/** Host adapters can use this function after converting a durable session event. */
export function publishVisualIntent(intent: VisualIntent): void {
  visualIntents.publish(intent)
}
