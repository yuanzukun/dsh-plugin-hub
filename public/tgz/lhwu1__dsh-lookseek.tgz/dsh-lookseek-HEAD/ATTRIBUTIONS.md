# Scene Asset

## Multi-workstation office

- Source: repository-owner-provided `未命名.glb`
- Runtime file: `assets/office-workstations.glb`
- Processing: isolated the multi-workstation room, removed the washroom wing, and resized embedded textures to 1024px maximum.

The MIT license in this repository covers the plugin code, not this model. The repository owner supplied the model for this distribution. Anyone who forks or republishes the project must confirm that they have permission to redistribute the model, or replace it with an asset they are allowed to distribute.
