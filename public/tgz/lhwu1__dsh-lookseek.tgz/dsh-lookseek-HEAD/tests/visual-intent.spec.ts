import { describe, expect, it } from 'vitest'
import { safeSummary, stationFor } from '../src/host/visual-intent.ts'
import { activityLabel, memberStateLabel, roleFromPreset, visibleMembers, type WorkspaceMember } from '../src/client/model.ts'

describe('visual intent safety', () => {
  it('does not place sensitive values in the visible scene', () => {
    expect(safeSummary('run with API_KEY=abc')).toBe('正在处理受保护的工作内容')
    expect(safeSummary('正在检查网页状态')).toBe('正在检查网页状态')
  })

  it('maps activities to readable stations', () => {
    expect(stationFor('shell')).toBe('terminal')
    expect(stationFor('complete')).toBe('delivery')
  })
})

describe('workspace members', () => {
  it('keeps every real worker in the diorama and uses Chinese state labels', () => {
  const make = (id: string, running: boolean, completed = false): WorkspaceMember => ({
      id, name: id, role: 'engineer', running, completed,
      intent: { agentId: id, activity: 'edit', target: 'code', summary: '正在修改文件', at: Number(id) },
    })
    expect(visibleMembers([make('1', false), make('2', true), make('3', true), make('4', false), make('5', true)]).map(x => x.id))
      .toEqual(['5', '3', '2', '4', '1'])
    expect(activityLabel(make('2', true).intent)).toBe('修改文件')
    expect(memberStateLabel(make('1', false))).toBe('已完成')
    expect(memberStateLabel(make('6', false, true))).toBe('已完成')
    expect(roleFromPreset('reviewer', false)).toBe('reviewer')
  })
})
