/**
 * dsh-side-session build: single-file client + ESM host.
 *
 * Self-contained: esbuild and typescript resolve from this package's own
 * devDependencies (run `pnpm install` first) — no harness checkout or shared
 * tool directory is required.
 *
 * The web server serves one file per plugin (/plugins/<pkg>/client.js), so the
 * client half is one CJS bundle wrapped in the ModuleLoader factory handshake;
 * @deepseek-ai/dsh-* and react stay external (provided by the app's module
 * system). The host half is plain ESM for Node, externalizing @deepseek-ai/*
 * and cordis.
 */
import { build } from 'esbuild'
import { mkdirSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(fileURLToPath(import.meta.url))
const out = (name) => join(root, 'lib', name)

mkdirSync(join(root, 'lib'), { recursive: true })

const dshExternal = ['@deepseek-ai/cordis', '@deepseek-ai/dsh-*']

await build({
  entryPoints: [join(root, 'src/index.ts')],
  outfile: out('index.js'),
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: ['node22'],
  sourcemap: true,
  external: dshExternal,
  logLevel: 'info',
})

await build({
  entryPoints: [join(root, 'src/client/index.ts')],
  outfile: out('client.js'),
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: ['es2022'],
  sourcemap: true,
  jsx: 'automatic',
  external: [...dshExternal, 'react', 'react-dom', 'react/jsx-runtime', 'react/jsx-dev-runtime', 'scheduler'],
  banner: {
    js: "window.__ModuleLoader__.load({ id: 'dsh-side-session', factory: (require) => { var module = { exports: {} }; var exports = module.exports;",
  },
  footer: {
    js: 'return module.exports; } });',
  },
  logLevel: 'info',
})

const tsc = join(root, 'node_modules', '.bin', process.platform === 'win32' ? 'tsc.cmd' : 'tsc')
execFileSync(tsc, ['-p', 'tsconfig.json'], { cwd: root, stdio: 'inherit' })
