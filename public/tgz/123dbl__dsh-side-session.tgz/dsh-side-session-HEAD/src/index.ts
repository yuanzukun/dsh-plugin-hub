/**
 * dsh-side-session host half: registers one host slash command, `/side-chat`
 * (旁会话), that spawns a durable, continuable subagent side-session under
 * the calling agent — with zero UI of its own.
 *
 * Why a host command and not a browser RPC:
 *  - The GUI's "＋" menu is the `/` command source. A host command with no
 *    input descriptor appears there and, when picked, runs *detached* (no
 *    argument claim, no popup — the dispatch table's bare-host-command arm).
 *  - `ctx.commands` already mounts in dsh-base, and the command handler
 *    receives the LIVE parent `agent`, which is exactly what
 *    `ctx.subagents.startContinuable` requires. No Typert Remote, no panel,
 *    no header button needed.
 *
 * The child gets a fixed "ready" opening prompt and an auto timestamp label;
 * the browser half listens for `command/executed` and jumps straight into the
 * child's official chat view, where the user takes over the conversation.
 * The main session is never prompted or touched.
 *
 * @module dsh-side-session
 */

import type { Context } from '@deepseek-ai/cordis'
// Type-only: brings the ctx.subagents Context merge into this program.
import type {} from '@deepseek-ai/dsh-subagent'
// Type-only: brings the ctx.commands Context merge into this program.
import type {} from '@deepseek-ai/dsh-commands'
import type { CommandResult } from '@deepseek-ai/dsh-commands/types'

/** Cordis plugin name (the Loader entry and client bundle id). */
export const name = 'dsh-side-session'

/** Services required before load: the command registry and the subagent runtime. */
export const inject = ['commands', 'subagents']

/** Fixed opening prompt delivered to a freshly spawned side session. */
const OPENING_PROMPT = [
  '这是一个新的旁会话。请用一两句话确认你已经就绪，并等待我输入第一个问题。',
  'This is a new side session. Confirm in a sentence or two that you are ready, then wait for my first question.',
].join('\n')

/** Short timestamp used as the child's display label, e.g. `旁会话 14:32`. */
function labelFor(now: Date): string {
  const hh = String(now.getHours()).padStart(2, '0')
  const mm = String(now.getMinutes()).padStart(2, '0')
  return `旁会话 ${hh}:${mm}`
}

/**
 * Mount the side-chat command.
 * @param ctx - host cordis context.
 */
export function apply(ctx: Context): void {
  ctx.effect(() => ctx.commands.register({
    name: 'side-chat',
    description: '新建一个独立的旁会话（可继续对话的子代理），不影响当前会话',
    handler: async ({ agent, signal }): Promise<CommandResult> => {
      try {
        const subagents = ctx.get('subagents')
        if (subagents === undefined) {
          return { kind: 'error', text: '旁会话服务未就绪' }
        }
        const result = await subagents.startContinuable({
          provider: 'spawn',
          label: labelFor(new Date()),
          request: {
            parent: agent,
            prompt: [{ type: 'text', text: OPENING_PROMPT }],
          },
          signal,
        })
        return { kind: 'success', text: '已创建旁会话' }
      } catch {
        return { kind: 'error', text: '创建旁会话失败' }
      }
    },
  }), 'dsh-side-session: /side-chat command')
}
