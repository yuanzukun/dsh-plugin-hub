/**
 * dsh-side-session client plugin: the browser half of the `/side-chat`
 * (旁会话) command.
 *
 * There is deliberately no panel, no popup, no header button: the host
 * command appears in the composer's "＋" command menu; picking it spawns the
 * side-session child on the host. This half only watches for the successful
 * execution and then jumps the UI into the newly created child's OFFICIAL
 * conversation view (`openSubagent`), where the full composer stays
 * available and the user takes over the conversation themselves.
 *
 * The jump needs the new child's session id, which the command result does
 * not carry, so this half diffs the live direct-children catalog: it keeps
 * the last-seen child set per parent, refreshes the catalog on success, and
 * opens the first continuable child that was not there before.
 *
 * @module dsh-side-session/client
 */

// Type-only merges: session standard kit and the command/executed event.
import type {} from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-commands/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { ISessions } from '@deepseek-ai/dsh-client-runtime/client'
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client'
import type { CommandResult } from '@deepseek-ai/dsh-commands/types'

/** Required services: session store (catalog refresh + openSubagent). */
export const inject = ['sessions']

/** Last-seen direct-child id sets, per parent session, from the live list feed. */
const seenByParent = new Map<SessionId, Set<SessionId>>()

/** Poll a few times after a refresh for the catalog to settle (defensive). */
async function settleChild(
  sessions: ISessions,
  parentId: SessionId,
  before: Set<SessionId>,
  attempts = 6,
): Promise<SessionId | undefined> {
  for (let i = 0; i < attempts; i += 1) {
    await sessions.refreshSubagents(parentId)
    const snapshot = sessions.list.getSnapshot()
    const catalog = snapshot.subagentsByParent[parentId]
    if (catalog && catalog.state === 'ready') {
      // Prefer a continuable child that was not there before the command ran.
      let fallback: SessionId | undefined
      for (const entry of catalog.entries) {
        if (entry.kind !== 'child' || entry.mode !== 'continuable') continue
        if (!before.has(entry.id)) return entry.id
        fallback = entry.id
      }
      // The feed had never warmed (empty `before`): fall back to the last
      // continuable child, which is the most recently created one.
      if (fallback !== undefined && before.size === 0) return fallback
    }
    if (i < attempts - 1) {
      await new Promise(resolve => setTimeout(resolve, 150))
    }
  }
  return undefined
}

/**
 * Mount the browser half: track the catalog and auto-open a fresh side
 * session after `/side-chat` succeeds.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  const sessions = ctx.get('sessions') as unknown as ISessions

  // Keep the last-seen child set fresh for every visible parent. The feed
  // updates on catalog membership frames, so the set reflects the state the
  // user last saw (before a command run added a child).
  const unlisten = sessions.list.subscribe(() => {
    const snapshot = sessions.list.getSnapshot()
    for (const parentId of Object.keys(snapshot.subagentsByParent)) {
      const catalog = snapshot.subagentsByParent[parentId as SessionId]
      if (!catalog || catalog.state !== 'ready') continue
      const ids = new Set<SessionId>()
      for (const entry of catalog.entries) {
        if (entry.kind === 'child') ids.add(entry.id)
      }
      seenByParent.set(parentId as SessionId, ids)
    }
  })

  ctx.on('command/executed', async (sessionId: SessionId, name: string, result: CommandResult) => {
    if (name !== 'side-chat') return
    if (result.kind !== 'success') return
    const before = seenByParent.get(sessionId) ?? new Set<SessionId>()
    const childId = await settleChild(sessions, sessionId, before)
    if (childId === undefined) return
    sessions.openSubagent({ parentSessionId: sessionId, childSessionId: childId, mode: 'continuable' })
  })

  ctx.effect(() => unlisten, 'dsh-side-session: catalog subscription')
}
