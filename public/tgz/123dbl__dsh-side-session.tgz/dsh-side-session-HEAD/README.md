# dsh-side-session

Side-chat (旁会话) plugin for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (`dsh`).

While your main session is running, pick **side-chat** from the composer's "＋" command menu to open a fresh, independent, continuable session in parallel — the main session is never prompted or touched.

主会话进行中，从输入框的「＋」命令菜单选 **side-chat（旁会话）**，即可一键新开一个独立、可继续对话的并行会话——主会话不受任何影响。

## What it does / 功能

- Registers one host command, `/side-chat` (旁会话), shown in the composer's "＋" command menu. / 注册一个宿主命令 `/side-chat`（旁会话），出现在输入框「＋」命令菜单。
- Picking it spawns a **continuable subagent** under the calling session, with a fixed ready-to-go opening prompt and an auto timestamp label (`旁会话 14:32`). / 选中后在当前会话下派生一个可继续对话的子代理，附带就绪开场白与自动时间戳标签。
- The browser half then jumps straight into the new child's official chat view, where you take over the conversation. / 前端随即自动跳转到新旁会话的对话视图，由你接管对话。
- No panel, no popup, no settings: the command menu entry *is* the whole UI. / 无面板、无弹窗、无设置——命令菜单入口即全部 UI。

## Install / 安装

From this repository (no build step: the client and host halves are prebuilt and committed under `lib/`):

```sh
dsh plugin --profile web add github:123dbl/dsh-side-session
```

or, once listed, one-click from the plugin market (Settings → plugins).

Local development link (already used by the author's `web` profile):

```sh
dsh plugin --profile web add link:/path/to/dsh-side-session
```

## Usage / 使用

1. In the conversation composer, click **＋** (or type `/`) and pick **side-chat**.
2. The host spawns a side session; the UI auto-opens it in a new chat view.
3. Ask your question there. The side session runs independently of the main one — both can keep going in parallel.

## Requirements

- A `dsh` host whose subagent runtime supports continuable children (`ctx.subagents.startContinuable`).
- Web client (the browser half listens for the `command/executed` event and opens the child's official session view).

## How it works / 原理

- Host half (`src/index.ts`): mounts `/side-chat` via `ctx.commands`; the handler calls `ctx.subagents.startContinuable({ provider: 'spawn', ... })` with the live parent `agent`. No Typert Remote, no panel.
- Client half (`src/client/index.ts`): keeps the last-seen direct-child set per parent from the live catalog feed, and after a successful `side-chat` run diffs the refreshed catalog to find and open the newly created child.

## Development / 开发

```sh
pnpm install
pnpm run build     # esbuild host+client bundles + tsc declarations into lib/
pnpm run typecheck
```

`lib/` is committed so repository installs work without a build step; regenerate and commit it after changing `src/`.

## License / 许可证

MIT © 2026 123dbl
