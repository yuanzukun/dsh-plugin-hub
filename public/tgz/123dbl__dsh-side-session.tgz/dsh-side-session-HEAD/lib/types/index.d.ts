/**
 * dsh-side-session host half: registers one host slash command, `/side-chat`
 * (旁会话), that spawns a durable, continuable subagent side-session under
 * the calling agent — with zero UI of its own.
 *
 * Why a host command and not a browser RPC:
 *  - The GUI's "＋" menu is the `/` command source. A host command with no
 *    input descriptor appears there and, when picked, runs *detached* (no
 *    argument claim, no popup — the dispatch table's bare-host-command arm).
 *  - `ctx.commands` already mounts in dsh-base, and the command handler
 *    receives the LIVE parent `agent`, which is exactly what
 *    `ctx.subagents.startContinuable` requires. No Typert Remote, no panel,
 *    no header button needed.
 *
 * The child gets a fixed "ready" opening prompt and an auto timestamp label;
 * the browser half listens for `command/executed` and jumps straight into the
 * child's official chat view, where the user takes over the conversation.
 * The main session is never prompted or touched.
 *
 * @module dsh-side-session
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis plugin name (the Loader entry and client bundle id). */
export declare const name = "dsh-side-session";
/** Services required before load: the command registry and the subagent runtime. */
export declare const inject: string[];
/**
 * Mount the side-chat command.
 * @param ctx - host cordis context.
 */
export declare function apply(ctx: Context): void;
