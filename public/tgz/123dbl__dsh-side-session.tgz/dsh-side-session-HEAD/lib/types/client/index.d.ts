/**
 * dsh-side-session client plugin: the browser half of the `/side-chat`
 * (旁会话) command.
 *
 * There is deliberately no panel, no popup, no header button: the host
 * command appears in the composer's "＋" command menu; picking it spawns the
 * side-session child on the host. This half only watches for the successful
 * execution and then jumps the UI into the newly created child's OFFICIAL
 * conversation view (`openSubagent`), where the full composer stays
 * available and the user takes over the conversation themselves.
 *
 * The jump needs the new child's session id, which the command result does
 * not carry, so this half diffs the live direct-children catalog: it keeps
 * the last-seen child set per parent, refreshes the catalog on success, and
 * opens the first continuable child that was not there before.
 *
 * @module dsh-side-session/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required services: session store (catalog refresh + openSubagent). */
export declare const inject: string[];
/**
 * Mount the browser half: track the catalog and auto-open a fresh side
 * session after `/side-chat` succeeds.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
