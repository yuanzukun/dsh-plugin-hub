/**
 * _selftest_v2.mjs —— dsh-grow 2026-11-01 改版自测
 *
 * 只测纯逻辑，不碰 DSH 运行时。跑法：
 *   node _selftest_v2.mjs
 *
 * 覆盖：
 *   1. 参数漂移真的会动（旧算法 396 轮不动，新算法 96 轮必须走出明显差异）
 *   2. 说话方式分档会跨档（值变了，注入文本也要变）
 *   3. 日记清理 / 兜底 / 时间戳
 *   4. 人格：两套内置、首次可选、选完锁死
 *   5. 日记节奏：5~10 轮随机、写完重抽
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert'

import { evaluate, snapshotView, describeTrait, BOUNDS } from './lib/traits.js'
import { defaultTraits } from './lib/state.js'
import { createState } from './lib/state.js'
import { createPersonaStore } from './lib/persona.js'
import { createDiary, cleanDiary, fallbackDiary, nowStamp, rollNextGap, DIARY_MIN_GAP, DIARY_MAX_GAP } from './lib/diary.js'

const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'grow-test-'))
let passed = 0
let failed = 0

function check(name, fn) {
  try {
    const detail = fn()
    passed += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    failed += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

function log2() {
  return () => {}
}

// ---------------------------------------------------------------------------
// 1. 漂移幅度：旧算法 396 轮只动了 0.0136，新算法 96 轮要明显得多
// ---------------------------------------------------------------------------

check('参数漂移：96 轮好话，撒娇必须涨 ≥ 0.10', () => {
  let traits = defaultTraits()
  const start = traits.clinginess
  for (let batch = 0; batch < 12; batch += 1) {
    const signals = {
      warm: 6,
      praise: 5,
      cold: 0,
      complain: 0,
      rush: 0,
      asksShort: 0,
      asksDetail: 2,
      safetyTouched: 0,
      turnsSeen: 8,
      toolCalls: 24,
      toolFails: 0,
    }
    const res = evaluate(traits, signals, { turns: 8 })
    traits = res.next
  }
  const delta = traits.clinginess - start
  assert.ok(delta >= 0.1, `撒娇只涨了 ${delta.toFixed(3)}`)
  return `撒娇 ${start.toFixed(2)} → ${traits.clinginess.toFixed(2)}（${delta >= 0 ? '+' : ''}${delta.toFixed(2)}）`
})

check('参数漂移：96 轮挨批，撒娇必须跌 ≥ 0.10', () => {
  let traits = defaultTraits()
  const start = traits.clinginess
  for (let batch = 0; batch < 12; batch += 1) {
    const signals = {
      warm: 0,
      praise: 0,
      cold: 6,
      complain: 5,
      rush: 4,
      asksShort: 3,
      asksDetail: 0,
      safetyTouched: 0,
      turnsSeen: 8,
      toolCalls: 20,
      toolFails: 6,
    }
    const res = evaluate(traits, signals, { turns: 8 })
    traits = res.next
  }
  const delta = start - traits.clinginess
  assert.ok(delta >= 0.1, `撒娇只跌了 ${delta.toFixed(3)}`)
  return `撒娇 ${start.toFixed(2)} → ${traits.clinginess.toFixed(2)}（-${delta.toFixed(2)}）`
})

check('参数漂移：安全话题一律跳过', () => {
  const traits = defaultTraits()
  const res = evaluate(traits, { warm: 10, cold: 10, safetyTouched: 1, turnsSeen: 8 }, { turns: 8 })
  assert.strictEqual(res.skipped, 'safety')
  assert.strictEqual(res.changes.length, 0)
  return 'skipped=safety'
})

check('参数漂移：不会越界', () => {
  let traits = defaultTraits()
  for (let batch = 0; batch < 60; batch += 1) {
    const res = evaluate(traits, { warm: 8, praise: 8, turnsSeen: 8, toolCalls: 10, toolFails: 0 }, { turns: 8 })
    traits = res.next
  }
  for (const key of Object.keys(BOUNDS)) {
    const [lo, hi] = BOUNDS[key]
    assert.ok(traits[key] >= lo - 1e-9 && traits[key] <= hi + 1e-9, `${key} 越界：${traits[key]}`)
  }
  return `撒娇封顶 ${traits.clinginess.toFixed(2)}（上限 ${BOUNDS.clinginess[1]}）`
})

// ---------------------------------------------------------------------------
// 2. 分档：值跨档时注入文本必须换
// ---------------------------------------------------------------------------

check('说话方式：0.30 和 0.80 的描述必须不同', () => {
  const low = describeTrait('clinginess', 0.3)
  const high = describeTrait('clinginess', 0.8)
  assert.notStrictEqual(low, high)
  return `${low} ↔ ${high}`
})

check('说话方式：六项都有描述且不含 undefined', () => {
  const view = snapshotView(defaultTraits())
  assert.strictEqual(view.length, 6)
  for (const item of view) {
    assert.ok(typeof item.text === 'string' && item.text.length > 4, `${item.key} 描述异常`)
    assert.ok(!item.text.includes('undefined'), `${item.key} 含 undefined`)
    assert.ok(item.position >= 0 && item.position <= 1, `${item.key} position 越界`)
  }
  return view.map((i) => i.label).join('/')
})

// ---------------------------------------------------------------------------
// 3. 日记：清理、兜底、时间戳
// ---------------------------------------------------------------------------

check('日记清理：去掉标题、日期行、代码块', () => {
  const raw = '```text\n# 今天的日记\n2026-11-01\n今天主人让我改插件，有点累但还行。\n- 第一件事\n- 第二件事\n```'
  const out = cleanDiary(raw)
  assert.ok(!out.includes('#'), '标题没去掉')
  assert.ok(!out.includes('```'), '代码块没去掉')
  assert.ok(!out.includes('2026-11-01'), '日期行没去掉')
  assert.ok(out.includes('今天主人'), '正文丢了')
  return `${out.length} 字`
})

check('日记兜底：没模型也要写出东西', () => {
  const text = fallbackDiary({
    signals: { warm: 3, praise: 2, cold: 1, complain: 1, rush: 2, toolFails: 2 },
    turnsCount: 8,
    turnsFrom: 389,
    turnsTo: 396,
  })
  assert.ok(text.length >= 80, `兜底太短：${text.length}`)
  assert.ok(text.includes('389'), '没写轮次')
  return `${text.length} 字`
})

check('日记时间戳格式：YYYY-MM-DD HH:MM', () => {
  const stamp = nowStamp(new Date(2026, 10, 1, 15, 30).getTime())
  assert.strictEqual(stamp, '2026-11-01 15:30')
  return stamp
})

check('日记随机间隔：始终落在 5~10', () => {
  const seen = new Set()
  for (let i = 0; i < 300; i += 1) {
    const gap = rollNextGap()
    assert.ok(gap >= DIARY_MIN_GAP && gap <= DIARY_MAX_GAP, `间隔越界：${gap}`)
    seen.add(gap)
  }
  assert.ok(seen.size >= 4, `随机性不足，只出现 ${seen.size} 种间隔`)
  return `出现 ${seen.size} 种：${[...seen].sort((a, b) => a - b).join(',')}`
})

// ---------------------------------------------------------------------------
// 4. 人格：两套内置 + 锁定
// ---------------------------------------------------------------------------

check('人格：内置两套且都能选', () => {
  const dir = path.join(tmpRoot, 'persona-1')
  const store = createPersonaStore({ dir, log: log2() })
  store.load()
  const summary = store.summary()
  assert.strictEqual(summary.locked, false, '新装不该是锁定的')
  assert.ok(summary.items.length >= 2, `内置只有 ${summary.items.length} 套`)
  const names = summary.items.map((i) => i.name)
  assert.ok(names.includes('大肥鱼'), '缺大肥鱼')
  assert.ok(names.includes('普鲸'), '缺普鲸')
  return names.join(' / ')
})

check('人格：选定后锁定，再选被拒绝', () => {
  const dir = path.join(tmpRoot, 'persona-2')
  const store = createPersonaStore({ dir, log: log2() })
  store.load()
  const first = store.select('dafeiyu')
  assert.strictEqual(first.ok, true, `首次选择失败：${first.reason}`)
  assert.strictEqual(store.locked(), true, '选完没锁')
  const second = store.select('pujing')
  assert.strictEqual(second.ok, false, '居然还能改')
  assert.ok(second.reason.includes('不能'), `拒绝理由不对：${second.reason}`)
  return `第一次 OK → 第二次拒绝：${second.reason.slice(0, 24)}…`
})

check('人格：选定后重启依然是锁定的', () => {
  const dir = path.join(tmpRoot, 'persona-3')
  const a = createPersonaStore({ dir, log: log2() })
  a.load()
  a.select('pujing')
  const b = createPersonaStore({ dir, log: log2() })
  b.load()
  assert.strictEqual(b.locked(), true, '重启后锁丢了')
  assert.strictEqual(b.selected(), 'pujing', '重启后选择丢了')
  const again = b.select('dafeiyu')
  assert.strictEqual(again.ok, false, '重启后又能改了')
  return `锁恢复：${b.selected()}`
})

check('人格：自定义只在选之前可用', () => {
  const dir = path.join(tmpRoot, 'persona-4')
  const store = createPersonaStore({ dir, log: log2() })
  store.load()
  const added = store.addCustom({ name: '测试人格', text: '你是一个说话很慢的人，每次只讲一句话。' })
  assert.strictEqual(added.ok, true, `加自定义失败：${added.reason}`)
  const chosen = store.select(added.id)
  assert.strictEqual(chosen.ok, true, '选自定义失败')
  const later = store.addCustom({ name: '再来一套', text: '这套应该加不进去。' })
  assert.strictEqual(later.ok, false, '锁定后居然还能加')
  return `自定义 ${added.id} → 选完拒绝再加`
})

// ---------------------------------------------------------------------------
// 5. 日记节奏：state 里那一套
// ---------------------------------------------------------------------------

check('日记节奏：8 轮内不会触发，5 轮后可能触发', () => {
  const dir = path.join(tmpRoot, 'state-1')
  let clock = 1700000000000
  const state = createState({ dir, log: log2(), now: () => clock })
  state.load()
  // 头几轮 settleTurn
  for (let i = 0; i < 4; i += 1) {
    clock += 1000
    state.observe('s1', { type: 'turn/start', seq: i * 10 + 1 })
    state.settleTurn('s1', { kind: 'completed' })
  }
  const early = state.diaryState()
  assert.strictEqual(early.due, false, '4 轮就触发了？')
  assert.ok(early.remaining >= 1, `剩余轮数 ${early.remaining}`)
  return `4 轮后：还差 ${early.remaining} 轮（间隔抽到 ${early.nextGap}）`
})

check('日记节奏：到点触发，写完重抽', () => {
  const dir = path.join(tmpRoot, 'state-2')
  let clock = 1700000000000
  const state = createState({ dir, log: log2(), now: () => clock })
  state.load()
  let guard = 0
  while (state.diaryState().due !== true && guard < 30) {
    guard += 1
    clock += 1000
    state.observe('s1', { type: 'turn/start', seq: guard * 10 })
    state.settleTurn('s1', { kind: 'completed' })
  }
  assert.strictEqual(state.diaryState().due, true, '30 轮都没触发')
  const before = state.diaryState()
  state.diaryWritten()
  const after = state.diaryState()
  assert.strictEqual(after.turnsSince, 0, '写完后计数没清零')
  assert.ok(after.nextGap >= DIARY_MIN_GAP && after.nextGap <= DIARY_MAX_GAP, '重抽间隔越界')
  assert.strictEqual(after.count, before.count + 1, '篇数没加')
  return `第 ${guard} 轮触发 → 重抽 ${after.nextGap} 轮`
})

check('日记落盘：写进去能读回来', () => {
  const dir = path.join(tmpRoot, 'diary-1')
  const store = createDiary({ dir, log: log2() })
  store.load()
  const row = store.append({
    at: new Date(2026, 10, 1, 15, 30).getTime(),
    turnsFrom: 389,
    turnsTo: 396,
    turnsCount: 8,
    mood: '被夸了',
    text: '今天主人让我改插件，中间卡了两次，最后跑通了，挺开心的。',
    source: 'model',
  })
  assert.ok(row !== undefined, '没写进去')
  const again = createDiary({ dir, log: log2() })
  again.load()
  const list = again.list()
  assert.strictEqual(list.length, 1, `读回 ${list.length} 条`)
  assert.strictEqual(list[0].stamp, '2026-11-01 15:30')
  return `${list[0].stamp} · ${list[0].turnsFrom}~${list[0].turnsTo} 轮 · ${list[0].text.length} 字`
})

check('日记落盘：坏行不炸，好行照读', () => {
  const dir = path.join(tmpRoot, 'diary-2')
  fs.mkdirSync(dir, { recursive: true })
  const file = path.join(dir, 'diary.jsonl')
  fs.writeFileSync(
    file,
    [
      JSON.stringify({ id: 'a', at: 1, stamp: '2026-01-01 00:00', text: '第一条' }),
      '这不是 JSON{{{',
      JSON.stringify({ id: 'b', at: 2, stamp: '2026-01-02 00:00', text: '第二条' }),
    ].join('\n'),
    'utf8',
  )
  const store = createDiary({ dir, log: log2() })
  store.load()
  const list = store.list()
  assert.strictEqual(list.length, 2, `只读回 ${list.length} 条`)
  return `跳过坏行，读回 ${list.length} 条`
})

// ---------------------------------------------------------------------------

console.log('')
console.log(`通过 ${passed} / 失败 ${failed}`)
try {
  fs.rmSync(tmpRoot, { recursive: true, force: true })
} catch {
  // 临时目录删不掉不影响结论
}
process.exit(failed === 0 ? 0 : 1)
