/**
 * _selftest_fresh.mjs —— 「别人第一次装」验收
 *
 * 这是主人最在意的一条：**不管上一个人谈过多少轮，新装必须是一张白纸。**
 *
 * 做法：把 USERPROFILE 指到一个全新的空临时目录 → 跑 apply() → 读 status.json，
 * 逐项确认轮数 0、关系 50%、六个参数都是初始值、五套人格未选、记忆和日记全空。
 *
 *   node _selftest_fresh.mjs
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert'

// ★ 必须在 import 插件之前改 —— 插件的所有数据目录都来自 os.homedir()
const sandboxHome = fs.mkdtempSync(path.join(os.tmpdir(), 'grow-fresh-'))
const realHome = os.homedir()
process.env.USERPROFILE = sandboxHome
process.env.HOME = sandboxHome

const { apply } = await import('./lib/index.js')

// ---------------------------------------------------------------------------
// 最小宿主环境
// ---------------------------------------------------------------------------

const sections = []
const contexts = []
const routes = new Map()
const listeners = new Map()
const tools = new Map()

/**
 * 假 agent：状态段（grow:live）是挂在**会话**上的，不是全局的。
 * apply() 会遍历 ctx.get('agents').list() 补挂已有会话 —— 这里给一个。
 */
const mockAgent = {
  id: 'fresh-session',
  ctx: {
    effect(fn) {
      return fn()
    },
    systemPrompt: {
      context(d) {
        contexts.push(d)
        return () => {}
      },
    },
  },
}

const ctx = {
  logger: { debug() {}, info() {}, warn() {}, error() {} },
  on(type, fn) {
    if (!listeners.has(type)) listeners.set(type, [])
    listeners.get(type).push(fn)
    return () => {}
  },
  effect(fn) {
    return fn()
  },
  inject(deps, fn) {
    if (deps.includes('tools')) {
      fn({
        tools: {
          register: (def) => {
            tools.set(def.name, def)
            return () => {}
          },
          schemas: () => [],
          execute: async () => ({ content: [] }),
        },
        effect: ctx.effect,
      })
    } else if (deps.includes('webServer')) {
      fn({
        webServer: {
          register: ({ path: p, handler }) => {
            routes.set(p, handler)
            return () => {}
          },
        },
        effect: ctx.effect,
      })
    } else {
      fn({ effect: ctx.effect })
    }
  },
  get(name) {
    // 全新环境：没有配置模型；给一个已存在的会话，好让状态段挂上去
    if (name === 'llm') return undefined
    if (name === 'agents') return { list: () => [mockAgent] }
    return undefined
  },
  systemPrompt: {
    context(d) {
      contexts.push(d)
      return () => {}
    },
    section(d) {
      sections.push(d)
      return () => {}
    },
  },
}

let bootError = null
try {
  apply(ctx, {})
} catch (error) {
  bootError = error
}

function call(routePath) {
  return new Promise((resolve, reject) => {
    const handler = routes.get(routePath)
    if (handler === undefined) return reject(new Error(`路由没注册：${routePath}`))
    const timer = setTimeout(() => reject(new Error(`路由超时：${routePath}`)), 3000)
    const res = {
      code: 200,
      writeHead(code) {
        this.code = code
        return this
      },
      end(payload) {
        clearTimeout(timer)
        try {
          resolve({ code: this.code, body: JSON.parse(String(payload)) })
        } catch (error) {
          reject(error)
        }
      },
    }
    const req = {
      socket: { remoteAddress: '127.0.0.1' },
      headers: { host: '127.0.0.1:1' },
      url: routePath,
      method: 'GET',
      on() {},
      destroy() {},
    }
    try {
      Promise.resolve(handler(req, res)).catch(reject)
    } catch (error) {
      reject(error)
    }
  })
}

let pass = 0
let fail = 0

async function check(name, fn) {
  try {
    const detail = await fn()
    pass += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    fail += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

// ---------------------------------------------------------------------------

await check('apply() 在全新空目录里能跑起来', () => {
  assert.strictEqual(bootError, null, String(bootError?.message ?? bootError))
  return '启动干净'
})

const res = await call('/grow/status.json')
const status = res.body

await check('全新安装：轮数 = 0', () => {
  assert.strictEqual(status.soul.totalTurns, 0, `实际 ${status.soul.totalTurns} 轮`)
  return '0 轮'
})

await check('全新安装：亲近 50% / 信任 50%', () => {
  assert.strictEqual(status.soul.closeness, 0.5, `亲近 ${status.soul.closeness}`)
  assert.strictEqual(status.soul.trust, 0.5, `信任 ${status.soul.trust}`)
  return '50% / 50%'
})

await check('全新安装：完成 0 件 / 失败 0 次 / 会话 0 个', () => {
  assert.strictEqual(status.soul.wins, 0, `wins=${status.soul.wins}`)
  assert.strictEqual(status.soul.fails, 0, `fails=${status.soul.fails}`)
  assert.strictEqual(status.soul.sessions, 0, `sessions=${status.soul.sessions}`)
  return '0 / 0 / 0'
})

await check('全新安装：六个参数全是初始值', () => {
  const want = { 撒娇: 0.28, 话量: 0.45, 幽默: 0.22, 依赖: 0.55, 认真: 0.62, 情绪外化: 0.15 }
  for (const item of status.traits) {
    assert.strictEqual(item.value, want[item.label], `${item.label} = ${item.value}，期望 ${want[item.label]}`)
  }
  return Object.entries(want)
    .map(([k, v]) => `${k}${v}`)
    .join(' ')
})

await check('全新安装：五套人格都在，且未选未锁', () => {
  assert.strictEqual(status.persona.items.length, 5, `实际 ${status.persona.items.length} 套`)
  assert.strictEqual(status.persona.locked, false, '一上来就锁定了')
  assert.strictEqual(status.persona.selected, '', `selected=${status.persona.selected}`)
  return status.persona.items.map((i) => i.name).join(' / ')
})

await check('全新安装：记忆 0 条 / 日记 0 篇', () => {
  assert.strictEqual(status.stats.live, 0, `记忆 ${status.stats.live} 条`)
  assert.strictEqual(status.diary.stats.count, 0, `日记 ${status.diary.stats.count} 篇`)
  return '全空'
})

await check('全新安装：没有「刚才调整过」这类历史漂移', () => {
  assert.strictEqual(status.drift, null, `drift=${JSON.stringify(status.drift)}`)
  return 'drift = null'
})

await check('全新安装：关系阶段是「刚认识」、第 0 轮', () => {
  const section = sections.find((s) => s.name === 'grow:style')
  assert.ok(section !== undefined, '说话方式段没注册')
  const text = section.text()
  assert.ok(text.includes('刚认识'), '阶段不是「刚认识」')
  assert.ok(text.includes('第 0 轮'), '轮数不是第 0 轮')
  return '刚认识 / 第 0 轮'
})

await check('全新安装：人格段为空（还没选）', () => {
  const section = sections.find((s) => s.name === 'grow:persona')
  assert.ok(section !== undefined, '人格段没注册')
  assert.strictEqual(section.text(), '', `没选却有内容：${section.text().slice(0, 40)}`)
  return '空'
})

await check('全新安装：状态段渲染正常', () => {
  const context = contexts.find((c) => c.name === 'grow:live')
  assert.ok(context !== undefined, '状态段没注册')
  const text = context.text()
  assert.ok(text.includes('亲近'), '状态段缺亲近')
  return `${text.length} 字`
})

await check('全新安装：5 个工具都注册了', () => {
  for (const wanted of ['grow_remember', 'grow_recall', 'grow_forget', 'grow_feel', 'grow_status']) {
    assert.ok(tools.has(wanted), `缺 ${wanted}`)
  }
  return [...tools.keys()].join(' / ')
})

await check('全新安装：数据目录里没有任何绝对路径残留', () => {
  const dir = path.join(sandboxHome, '.dsh', 'grow')
  assert.ok(fs.existsSync(dir), '数据目录没建')
  const files = fs.readdirSync(dir)
  const leaks = []
  for (const name of files) {
    if (name === 'boot.log') continue // 诊断日志，内容是时间戳
    const full = path.join(dir, name)
    if (!fs.statSync(full).isFile()) continue
    const content = fs.readFileSync(full, 'utf8')
    // 数据文件里不该出现任何盘符绝对路径（那会把本机目录结构带出去）
    if (/[A-Za-z]:[\\/]/.test(content)) leaks.push(`${name}:绝对路径`)
  }
  assert.strictEqual(leaks.length, 0, `残留：${leaks.join(', ')}`)
  return `${files.length} 个文件，无绝对路径`
})

await check('全新安装：连跑一段对话后，号码从 1 开始而不是接着上次', () => {
  const emit = (type, data, seq) => {
    const list = listeners.get('session/event') ?? []
    for (const fn of list) fn({ id: 'fresh-session' }, { type, data, seq })
  }
  emit('turn/start', undefined, 1)
  emit('user/message', { content: '你好' }, 2)
  emit('turn/end', { reason: { kind: 'completed' } }, 3)
  const soul = status.soul // 这是之前抓的快照，重新拉一次才准
  return '已发一轮事件（下面的断言会重新读）'
})

const after = (await call('/grow/status.json')).body
await check('跑完一轮之后：轮数 = 1（不是 401）', () => {
  assert.strictEqual(after.soul.totalTurns, 1, `实际 ${after.soul.totalTurns}`)
  return '1 轮'
})

// ---------------------------------------------------------------------------

console.log('')
console.log(`通过 ${pass} / 失败 ${fail}`)

process.env.USERPROFILE = realHome
process.env.HOME = realHome
try {
  fs.rmSync(sandboxHome, { recursive: true, force: true })
} catch {
  // 删不掉不影响结论
}
process.exit(fail === 0 ? 0 : 1)
