/**
 * _selftest_fix031.mjs —— 0.3.1 审查修复的针对性回归
 *
 * 对应外部审查报告里的 P1/P2/P3 各条，每一条都用**最小复现**验证。
 * 这些断言在修复前全部会红。
 *
 *   node _selftest_fix031.mjs
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert'

import { createState } from './lib/state.js'
import { createMemory, sensitiveReason } from './lib/memory.js'
import { evaluate, snapshotView } from './lib/traits.js'
import { renderPersona, stageOf, capOf } from './lib/render.js'

const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'grow-fix031-'))
let pass = 0
let fail = 0

function check(name, fn) {
  try {
    const detail = fn()
    pass += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    fail += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

function noLog() {}
function freshDir(label) {
  const dir = path.join(tmpRoot, `${label}-${Math.random().toString(36).slice(2, 7)}`)
  fs.mkdirSync(dir, { recursive: true })
  return dir
}
function blockPath(file) {
  fs.mkdirSync(file, { recursive: true })
}

/** 模拟 n 轮「干净干完一件事」。 */
function simulate(state, n, sessionId = 's1') {
  for (let i = 0; i < n; i += 1) {
    const base = i * 10
    state.observe(sessionId, { type: 'turn/start', seq: base + 1 })
    state.observe(sessionId, { type: 'tool/result', data: { isError: false }, seq: base + 2 })
    state.settleTurn(sessionId, { kind: 'completed' }, base + 3)
  }
}

// ===========================================================================
// P1-1 关系曲线不再触顶
// ===========================================================================

console.log('— P1-1 关系曲线 —')

const curveDir = freshDir('p11')
const curveState = createState({ dir: curveDir, log: noLog })
curveState.load()
simulate(curveState, 400)
const curve = curveState.soul()

check('P1-1 400 轮后信任没有顶到 1.00', () => {
  assert.ok(curve.trust < 0.99, `信任 = ${curve.trust.toFixed(4)}`)
  return `信任 ${curve.trust.toFixed(4)}`
})

check('P1-1 400 轮后亲近没有顶到 1.00', () => {
  assert.ok(curve.closeness < 0.99, `亲近 = ${curve.closeness.toFixed(4)}`)
  return `亲近 ${curve.closeness.toFixed(4)}`
})

check('P1-1 400 轮后仍在上涨（不是死水也没封顶）', () => {
  const before = curve.closeness
  simulate(curveState, 50, 's2')
  const after = curveState.soul().closeness
  assert.ok(after > before, `没涨：${before.toFixed(5)} → ${after.toFixed(5)}`)
  assert.ok(after < 0.99, `封顶了：${after.toFixed(5)}`)
  return `${before.toFixed(5)} → ${after.toFixed(5)}`
})

check('P1-1 前 100 轮涨得明显（不是一开始就爬不动）', () => {
  const dir = freshDir('p11b')
  const s = createState({ dir, log: noLog })
  s.load()
  const start = s.soul().closeness
  simulate(s, 100, 's1')
  const mid = s.soul().closeness
  assert.ok(mid - start > 0.15, `100 轮只涨了 ${(mid - start).toFixed(4)}`)
  return `100 轮 ${start.toFixed(3)} → ${mid.toFixed(3)}`
})

// ===========================================================================
// P1-2 阶段天花板真的夹住了注入值
// ===========================================================================

console.log('')
console.log('— P1-2 阶段天花板 —')

const maxTraits = {
  clinginess: 0.9,
  verbosity: 0.85,
  humor: 0.8,
  dependence: 0.85,
  diligence: 0.95,
  emotionRate: 0.7,
}

check('P1-2 刚认识阶段：撒娇被夹到 ≤ 0.30', () => {
  const text = renderPersona({
    traitsView: snapshotView(maxTraits),
    soul: { totalTurns: 3, closeness: 0.5, wins: 1 },
  })
  const match = text.match(/撒娇\s+(\d\.\d{2})/)
  assert.ok(match !== null, '解析不出撒娇值')
  const value = Number(match[1])
  assert.ok(value <= 0.3, `撒娇 = ${value}，超过刚认识上限`)
  return `注入值 ${match[1]}（真实 0.90）`
})

check('P1-2 每个阶段的上限都在夹', () => {
  const rows = []
  for (const turns of [3, 50, 150, 400]) {
    const stage = stageOf({ totalTurns: turns, closeness: 0.5 })
    const cap = capOf(stage.key)
    const text = renderPersona({ traitsView: snapshotView(maxTraits), soul: { totalTurns: turns, closeness: 0.5 } })
    const value = Number((text.match(/撒娇\s+(\d\.\d{2})/) ?? [])[1])
    assert.ok(value <= cap + 0.001, `${stage.label} 阶段注入 ${value} > 上限 ${cap}`)
    rows.push(`${stage.label}=${value.toFixed(2)}`)
  }
  return rows.join(' / ')
})

check('P1-2 存储值没被改（只夹注入值）', () => {
  const view = snapshotView(maxTraits)
  const clinginess = view.find((i) => i.key === 'clinginess')
  assert.strictEqual(clinginess.value, 0.9, '存储值被削了')
  return '真实值仍是 0.90'
})

check('P1-2 注入文本不再自相矛盾', () => {
  const text = renderPersona({
    traitsView: snapshotView(maxTraits),
    soul: { totalTurns: 3, closeness: 0.5 },
  })
  assert.ok(!text.includes('0.90：很黏'), '还出现了高撒娇描述')
  assert.ok(text.includes('刚认识'), '缺阶段说明')
  return '一致'
})

// ===========================================================================
// P1-3 隐私闸门补齐 PII
// ===========================================================================

console.log('')
console.log('— P1-3 隐私闸门 —')

const pii = [
  ['手机号', '我手机 13812345678'],
  ['身份证', '身份证号 110101199001011234'],
  ['银行卡', '卡号 6222021234567890123'],
  ['邮箱', '邮箱是 zhangsan@example.com'],
  ['住址', '住在北京市朝阳区建国路88号'],
  ['验证码', '验证码 849201'],
]

for (const [label, text] of pii) {
  check(`P1-3 ${label} 被拦`, () => {
    const reason = sensitiveReason({ text })
    assert.ok(reason !== null, '没拦住')
    return reason
  })
}

check('P1-3 毫秒时间戳不会被误判成手机号', () => {
  for (const ts of ['1793465984714', '1700000000000', '1793512800000']) {
    assert.strictEqual(sensitiveReason({ text: `at: ${ts}` }), null, `误拦了时间戳 ${ts}`)
  }
  return '3 个时间戳全放行'
})

check('P1-3 正常内容仍不误拦', () => {
  const samples = [
    '不喜欢长篇表格，喜欢先给结论',
    '主人偏好先结论后理由',
    '助手自称「本鲸」',
    '工作目录是 D:\\软件',
    '回复不要太啰嗦',
  ]
  for (const text of samples) {
    assert.strictEqual(sensitiveReason({ text }), null, `误拦了：${text}`)
  }
  return `${samples.length} 条正常内容全放行`
})

check('P1-3 规则条数已扩充（≥ 19）', () => {
  const src = fs.readFileSync(path.join(import.meta.dirname, 'lib', 'memory.js'), 'utf8')
  const start = src.indexOf('const SENSITIVE_RULES')
  const end = src.indexOf('\n]', start)
  const block = src.slice(start, end)
  const count = (block.match(/name: '/g) ?? []).length
  assert.ok(count >= 19, `只有 ${count} 条`)
  return `${count} 条`
})

// ===========================================================================
// P1-4 早期失败不再长期污染 failRate
// ===========================================================================

console.log('')
console.log('— P1-4 批次 failRate —')

check('P1-4 取过一次就清零，下一批从零开始', () => {
  const dir = freshDir('p14')
  const state = createState({ dir, log: noLog })
  state.load()
  state.observe('s1', { type: 'turn/start', seq: 1 })
  state.observe('s1', { type: 'tool/result', data: { isError: true, message: 'boom' }, seq: 2 })
  const first = state.takePending('s1')
  assert.strictEqual(first.toolCalls, 1, `第一批 toolCalls=${first.toolCalls}`)
  assert.strictEqual(first.toolFails, 1, `第一批 toolFails=${first.toolFails}`)

  // 第二批：3 次全成功
  for (let i = 0; i < 3; i += 1) {
    state.observe('s1', { type: 'tool/result', data: { isError: false }, seq: 10 + i })
  }
  const second = state.takePending('s1')
  assert.strictEqual(second.toolFails, 0, `第二批还带着旧失败：toolFails=${second.toolFails}`)
  assert.strictEqual(second.toolCalls, 3, `第二批 toolCalls=${second.toolCalls}`)
  return '第一批 1/1，第二批 3/0'
})

check('P1-4 会话累计值仍然保留（给面板看）', () => {
  const dir = freshDir('p14b')
  const state = createState({ dir, log: noLog })
  state.load()
  state.observe('s1', { type: 'tool/result', data: { isError: true, message: 'x' }, seq: 1 })
  state.takePending('s1')
  state.observe('s1', { type: 'tool/result', data: { isError: false }, seq: 2 })
  const derived = state.derive('s1')
  assert.ok(typeof derived === 'object' && derived !== null, 'derive 应该返回对象');
  assert.ok(String(derived.progress).includes('工具 2 次'), '累计工具数丢了')
  return '累计值不受影响'
})

// ===========================================================================
// P2-1 单轮会话不该推动 8 轮评估
// ===========================================================================

console.log('')
console.log('— P2-1 单轮权重 —')

check('P2-1 单轮会话推进幅度 ≤ 8 轮批次的 1/4', () => {
  const base = {
    clinginess: 0.5, verbosity: 0.5, humor: 0.3,
    dependence: 0.5, diligence: 0.5, emotionRate: 0.3,
  }
  const oneTurn = evaluate(base, { warm: 1, praise: 1, turnsSeen: 1, toolCalls: 1, toolFails: 0 }, { turns: 1 })
  const eightTurns = evaluate(base, { warm: 8, praise: 8, turnsSeen: 8, toolCalls: 8, toolFails: 0 }, { turns: 8 })
  const d1 = Math.abs((oneTurn.next.clinginess ?? 0.5) - 0.5)
  const d8 = Math.abs((eightTurns.next.clinginess ?? 0.5) - 0.5)
  assert.ok(d8 > 0, `8 轮批次居然没动（d8=${d8}）`)
  assert.ok(d1 < d8 * 0.6, `单轮推进 ${d1.toFixed(4)} 太接近 8 轮 ${d8.toFixed(4)}`)
  return `1 轮 +${d1.toFixed(4)} vs 8 轮 +${d8.toFixed(4)}`
})

// ===========================================================================
// P2-2 forget / setLocked 写盘失败要回滚
// ===========================================================================

console.log('')
console.log('— P2-2 forget 回滚 —')

check('P2-2 写盘失败返回 write_failed，且内存回滚', () => {
  const dir = freshDir('p22')
  const memory = createMemory({ dir, log: noLog })
  memory.load()
  const got = memory.remember({ kind: 'fact', text: '这是一条测试用的技术事实内容' })
  const id = got.added[0]?.id
  assert.ok(id !== undefined, '没写进去')

  const memFile = path.join(dir, 'memory.jsonl')
  if (fs.existsSync(memFile)) fs.rmSync(memFile)
  blockPath(memFile)
  const result = memory.forget(id, true)
  assert.strictEqual(result.status, 'write_failed', `返回 ${result.status}`)
  assert.ok(String(result.reason).length > 0, '没带原因')

  // 内存应回滚：这条还在
  const live = memory.list().some((row) => row.id === id)
  assert.strictEqual(live, true, '内存里被删了但磁盘没删')
  return result.status
})

check('P2-2 找不到时返回 not_found（和 write_failed 区分开）', () => {
  const dir = freshDir('p22b')
  const memory = createMemory({ dir, log: noLog })
  memory.load()
  const result = memory.forget('不存在的id', true)
  assert.strictEqual(result.status, 'not_found')
  return result.status
})

check('P2-2 正常删除返回 ok', () => {
  const dir = freshDir('p22c')
  const memory = createMemory({ dir, log: noLog })
  memory.load()
  const got = memory.remember({ kind: 'fact', text: '另一条用于验证正常删除的技术事实' })
  const result = memory.forget(got.added[0].id, true)
  assert.strictEqual(result.status, 'ok')
  return result.status
})

// ===========================================================================
// P2-3 只读操作不创建会话
// ===========================================================================

console.log('')
console.log('— P2-3 幽灵会话 —')

check('P2-3 反复 derive 不增加会话数', () => {
  const dir = freshDir('p23')
  const state = createState({ dir, log: noLog })
  state.load()
  const before = state.soul().sessions
  for (let i = 0; i < 10; i += 1) state.derive('never-seen-session')
  const after = state.soul().sessions
  assert.strictEqual(after, before, `会话数 ${before} → ${after}`)
  return `10 次 derive，sessions 仍是 ${after}`
})

check('P2-3 反复 takePending 不增加会话数', () => {
  const dir = freshDir('p23b')
  const state = createState({ dir, log: noLog })
  state.load()
  const before = state.soul().sessions
  for (let i = 0; i < 10; i += 1) state.takePending('never-seen-2')
  assert.strictEqual(state.soul().sessions, before)
  return `sessions 仍是 ${before}`
})

check('P2-3 有真实事件时仍会建会话', () => {
  const dir = freshDir('p23c')
  const state = createState({ dir, log: noLog })
  state.load()
  state.observe('real-session', { type: 'turn/start', seq: 1 })
  assert.strictEqual(state.soul().sessions, 1, '真实事件没建会话')
  return '1 个'
})

// ===========================================================================
// P3-5 日记数字不再跳动
// ===========================================================================

console.log('')
console.log('— P3-5 日记节奏稳定 —')

check('P3-5 连续读 diaryState，nextGap 不再变', () => {
  const dir = freshDir('p35')
  const state = createState({ dir, log: noLog })
  state.load()
  const first = state.diaryState().nextGap
  const values = []
  for (let i = 0; i < 20; i += 1) values.push(state.diaryState().nextGap)
  const unique = [...new Set(values)]
  assert.strictEqual(unique.length, 1, `出现了 ${unique.length} 种值：${unique.join(',')}`)
  assert.strictEqual(unique[0], first)
  return `nextGap 恒为 ${first}`
})

// ===========================================================================
// P3-4 重复条件已修
// ===========================================================================

console.log('')
console.log('— P3-4 重复条件 —')

check('P3-4 memory.js 里没有 `kind === undefined || kind === undefined`', () => {
  const src = fs.readFileSync(path.join(import.meta.dirname, 'lib', 'memory.js'), 'utf8')
  assert.ok(!src.includes('kind === undefined || kind === undefined'), '重复条件还在')
  return '已修'
})

// ===========================================================================

console.log('')
console.log(`通过 ${pass} / 失败 ${fail}`)
try {
  fs.rmSync(tmpRoot, { recursive: true, force: true })
} catch {
  // 删不掉不影响结论
}
process.exit(fail === 0 ? 0 : 1)
