/**
 * _privacy_scrub.mjs —— 记忆库隐私清洗（一次性 + 可复跑）
 *
 * 为什么需要它：记忆是「模型从对话里抽出来的」，它会把人名、IP、key
 * 这些本不该落盘的东西一起写进去；而记忆每轮都会注入上下文，
 * 等于每次请求都在往外送。
 *
 * 原则：
 *   · 只删「值」，不删「规则」 —— "不许出现真名"这种偏好要留着，真名本身要删；
 *   · 先备份再动手，删完复查；
 *   · 只报条数与 id，绝不把内容打印出来（打印一次就又落进会话记录）。
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const file = path.join(os.homedir(), '.dsh', 'grow', 'memory.jsonl')

/** 命中即删：真实值类。 */
const VALUE_PATTERNS = [
  /名字是\s*[\u4e00-\u9fa5]{2,4}/, // 直呼其名
  /真名是\s*[\u4e00-\u9fa5]{2,4}/,
  /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/, // 公网/内网 IP
  /\bsk-[A-Za-z0-9_-]{12,}/, // API key
  /\b[A-Fa-f0-9]{32,}\b/, // 长 hex（token / 哈希）
  /密码\s*[:：=]\s*\S+/, // 密码赋值
  /\bghp_[A-Za-z0-9]{20,}\b/,
  /\bark-[A-Za-z0-9-]{12,}\b/,
]

/** 命中即删：整条就是敏感记录（标题直接点明的）。 */
const SUBJECT_PATTERNS = [/^(姓名|真名|API\s*key|密钥|token)$/i]

function hits(row) {
  const text = String(row?.text ?? '')
  const subject = String(row?.subject ?? '')
  for (const pattern of VALUE_PATTERNS) {
    if (pattern.test(text) || pattern.test(subject)) return pattern.source.slice(0, 24)
  }
  for (const pattern of SUBJECT_PATTERNS) {
    if (pattern.test(subject)) return `subject:${subject}`
  }
  return null
}

if (!fs.existsSync(file)) {
  console.log('没有 memory.jsonl，跳过')
  process.exit(0)
}

const raw = fs.readFileSync(file, 'utf8')
const lines = raw.split('\n').filter((line) => line.trim() !== '')

const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const backup = path.join(path.dirname(file), `memory.backup-${stamp}.jsonl`)
fs.writeFileSync(backup, raw, 'utf8')
console.log(`原文件 ${lines.length} 行，已备份到 ${path.basename(backup)}`)

const kept = []
const dropped = []

for (const line of lines) {
  let row
  try {
    row = JSON.parse(line)
  } catch {
    dropped.push({ id: '(bad-json)', reason: 'unparsable' })
    continue
  }
  const reason = hits(row)
  if (reason === null) {
    kept.push(row)
  } else {
    dropped.push({ id: String(row?.id ?? '?'), kind: String(row?.kind ?? '?'), subject: String(row?.subject ?? ''), reason })
  }
}

if (dropped.length === 0) {
  console.log('没有命中，文件未改动')
  process.exit(0)
}

const body = kept.map((row) => JSON.stringify(row)).join('\n')
fs.writeFileSync(file, body === '' ? '' : `${body}\n`, 'utf8')

console.log(`删除 ${dropped.length} 条，保留 ${kept.length} 条`)
for (const item of dropped) {
  console.log(`  - ${item.id} [${item.kind}] subject="${item.subject}" 原因=${item.reason}`)
}

// 复查：重新读一遍，确认 0 命中
const after = fs.readFileSync(file, 'utf8').split('\n').filter((line) => line.trim() !== '')
let still = 0
for (const line of after) {
  try {
    if (hits(JSON.parse(line)) !== null) still += 1
  } catch {
    still += 1
  }
}
console.log(still === 0 ? '复查：干净 ✓' : `复查：仍有 ${still} 条命中 ✗`)
process.exit(still === 0 ? 0 : 1)
