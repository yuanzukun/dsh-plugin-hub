/**
 * _selftest_regress.mjs —— 0.2.1 回归测试（外部审查提出的问题逐条复现）
 *
 * 背景：0.2.0 的 117 项自测全过，但**只覆盖正常路径**，异常路径一条没测。
 * 外部审查补了 8 个异常复现用例，8/8 全部命中。这个文件把它们固化下来，
 * 以后谁改坏了会立刻红。
 *
 * 每一条都对应审查报告里的编号，方便对照。
 *
 *   node _selftest_regress.mjs
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert'

import { createState, defaultTraits, localDay } from './lib/state.js'
import { createPersonaStore } from './lib/persona.js'
import { createMemory, sensitiveReason } from './lib/memory.js'
import { createDiary } from './lib/diary.js'
import { readJsonl, readJson, writeJsonAtomic, quarantine } from './lib/store.js'
import { resolveConfig } from './lib/index.js'

const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'grow-regress-'))
let passed = 0
let failed = 0

function check(name, fn) {
  try {
    const detail = fn()
    passed += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    failed += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

function noLog() {}

function freshDir(label) {
  const dir = path.join(tmpRoot, `${label}-${Math.random().toString(36).slice(2, 7)}`)
  fs.mkdirSync(dir, { recursive: true })
  return dir
}

/**
 * 让某个路径「不可写」的通用手法：先在目标位置建一个**目录**。
 * 写文件时的 renameSync(tmp, target) 遇到已存在的目录必然失败，
 * 而且不依赖 chmod（Windows 上不可靠）。
 */
function blockPath(file) {
  fs.mkdirSync(file, { recursive: true })
}

// ===========================================================================
// P0-1 隐私闸门覆盖不足
// ===========================================================================

console.log('— P0-1 隐私闸门 —')

check('P0-1 英文 password= 被拦', () => {
  const reason = sensitiveReason({ text: '数据库连接串是 password=Hunter2xyz' })
  assert.ok(reason !== null, '没拦住')
  return reason
})

check('P0-1 JWT 被拦', () => {
  const jwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U'
  const reason = sensitiveReason({ text: `token 是 ${jwt}` })
  assert.ok(reason !== null, '没拦住')
  return reason
})

check('P0-1 AWS AKIA 被拦', () => {
  const reason = sensitiveReason({ text: 'AKIAIOSFODNN7EXAMPLE' })
  assert.ok(reason !== null, '没拦住')
  return reason
})

check('P0-1 api_key=/secret= 被拦', () => {
  assert.ok(sensitiveReason({ text: 'api_key=abcdef1234567890' }) !== null, 'api_key 没拦')
  assert.ok(sensitiveReason({ text: 'client_secret: s3cr3tVALUE99' }) !== null, 'secret 没拦')
  return '两类都拦住'
})

check('P0-1 Bearer 令牌被拦', () => {
  const reason = sensitiveReason({ text: 'Authorization: Bearer abcdefghijklmnop1234567890' })
  assert.ok(reason !== null, '没拦住')
  return reason
})

check('P0-1 URL 内嵌凭据被拦', () => {
  const reason = sensitiveReason({ text: '连接 postgres://admin:Pa55w0rd@10.0.0.1/db' })
  assert.ok(reason !== null, '没拦住')
  return reason
})

check('P0-1 私钥块被拦', () => {
  const reason = sensitiveReason({ text: '-----BEGIN RSA PRIVATE KEY-----\nMIIE...' })
  assert.ok(reason !== null, '没拦住')
  return reason
})

check('P0-1 正常内容不误拦', () => {
  const samples = [
    '不喜欢长篇表格，喜欢先给结论',
    '主人偏好先结论后理由',
    '助手自称「本鲸」',
    '工作目录是 D:\\软件',
    '项目在开发一个记忆插件',
    '回复不要太啰嗦',
  ]
  for (const text of samples) {
    assert.strictEqual(sensitiveReason({ text }), null, `误拦了：${text}`)
  }
  return `${samples.length} 条正常内容全放行`
})

check('P0-1 闸门在入库前生效（不写进 memory.jsonl）', () => {
  const dir = freshDir('p01')
  const memory = createMemory({ dir, log: noLog })
  memory.load()
  const result = memory.remember({ kind: 'fact', text: 'password=Hunter2xyz', subject: '配置' })
  assert.strictEqual(result.added.length, 0, '居然写进去了')
  assert.strictEqual(result.rejected.length, 1, '没标记为拒绝')
  const text = fs.existsSync(path.join(dir, 'memory.jsonl')) ? fs.readFileSync(path.join(dir, 'memory.jsonl'), 'utf8') : ''
  assert.ok(!text.includes('Hunter2xyz'), '密钥落盘了')
  return `拒绝原因：${result.rejected[0].reason}`
})

// ===========================================================================
// P0-2 写盘失败仍返回成功
// ===========================================================================

console.log('')
console.log('— P0-2 写盘失败 —')

check('P0-2 persona.select 写盘失败 → ok:false', () => {
  const dir = freshDir('p02a')
  const store = createPersonaStore({ dir, log: noLog })
  store.load()
  blockPath(path.join(dir, 'personas.json')) // 把目标位置变成目录，写不进去
  const result = store.select('pujing')
  assert.strictEqual(result.ok, false, '写不进去却报成功')
  assert.ok(String(result.reason).includes('没'), `理由不对：${result.reason}`)
  return result.reason.slice(0, 40)
})

check('P0-2 select 失败后内存状态回滚（不会假装锁定）', () => {
  const dir = freshDir('p02b')
  const store = createPersonaStore({ dir, log: noLog })
  store.load()
  blockPath(path.join(dir, 'personas.json'))
  store.select('pujing')
  assert.strictEqual(store.selected(), '', '失败了却把内存里的 selected 改了')
  assert.strictEqual(store.locked(), false, '失败了却锁住了')
  return '已回滚'
})

check('P0-2 state.flush 失败 → ok:false 且 dirty 保留', () => {
  const dir = freshDir('p02c')
  const state = createState({ dir, log: noLog })
  state.load()
  blockPath(path.join(dir, 'state.json'))
  state.observe('s1', { type: 'turn/start', seq: 1 })
  state.observe('s1', { type: 'user/message', data: { content: '你好' }, seq: 2 })
  const first = state.flush()
  assert.strictEqual(first.ok, false, '写失败却报成功')
  // dirty 还亮着 → 再 flush 一次仍然是失败（说明没被静默清掉）
  const second = state.flush()
  assert.strictEqual(second.ok, false, 'dirty 被清掉了（第二次居然成功）')
  return '两次 flush 都如实报失败'
})

check('P0-2 diary.append 写盘失败 → 返回 undefined 且内存不留', () => {
  const dir = freshDir('p02d')
  const diary = createDiary({ dir, log: noLog })
  diary.load()
  blockPath(path.join(dir, 'diary.jsonl'))
  const row = diary.append({ text: '这条写不进去' })
  assert.strictEqual(row, undefined, '写不进去却返回了条目')
  assert.strictEqual(diary.list().length, 0, '内存里还留着一条磁盘上没有的日记')
  return '拒绝且回滚'
})

check('P0-2 memory 写盘失败会带出 persisted:false', () => {
  const dir = freshDir('p02e')
  const memory = createMemory({ dir, log: noLog })
  memory.load()
  blockPath(path.join(dir, 'memory.jsonl'))
  const result = memory.remember({ kind: 'fact', text: '这是一条正常的技术事实，应该能写' })
  assert.strictEqual(result.persisted, false, '没标记写盘失败')
  assert.ok(result.persistError !== null, '没带错误原因')
  return `persisted=false（${String(result.persistError).slice(0, 30)}）`
})

// ===========================================================================
// P1-1 历史工具结果被重复计入每一轮
// ===========================================================================

console.log('')
console.log('— P1-1 轮次语义 —')

check('P1-1 第二轮纯聊天不再被算成「干成事」', () => {
  const dir = freshDir('p11')
  const state = createState({ dir, log: noLog })
  state.load()

  // 第一轮：调了工具且成功
  // 注意：observe() 只负责累积计数；真正结算走 settleTurn（和 index.js 里一样）
  state.observe('s1', { type: 'turn/start', seq: 1 })
  state.observe('s1', { type: 'tool/result', data: { isError: false }, seq: 2 })
  state.settleTurn('s1', { kind: 'completed' }, 3)
  const afterFirst = state.soul().wins
  assert.strictEqual(afterFirst, 1, `第一轮 wins 应该是 1，实际 ${afterFirst}`)

  // 第二轮：纯聊天，一个工具都没调
  state.observe('s1', { type: 'turn/start', seq: 4 })
  state.observe('s1', { type: 'user/message', data: { content: '随便聊聊' }, seq: 5 })
  state.settleTurn('s1', { kind: 'completed' }, 6)

  assert.strictEqual(state.soul().wins, 1, `第二轮纯聊天也被算成成功了（wins=${state.soul().wins}）`)
  assert.strictEqual(state.soul().totalTurns, 2, '轮数不对')
  return `wins 1→1，轮数 2`
})

check('P1-1 本轮工具失败要算到本轮头上', () => {
  const dir = freshDir('p11b')
  const state = createState({ dir, log: noLog })
  state.load()
  state.observe('s1', { type: 'turn/start', seq: 1 })
  state.observe('s1', { type: 'tool/result', data: { isError: true, message: 'boom' }, seq: 2 })
  state.settleTurn('s1', { kind: 'completed' }, 3)
  assert.strictEqual(state.soul().wins, 0, '本轮有失败却算成功了')
  return '本轮失败 → 不算 win'
})

check('P1-1 上一轮的失败不会连累下一轮', () => {
  const dir = freshDir('p11c')
  const state = createState({ dir, log: noLog })
  state.load()
  // 第一轮失败
  state.observe('s1', { type: 'turn/start', seq: 1 })
  state.observe('s1', { type: 'tool/result', data: { isError: true, message: 'boom' }, seq: 2 })
  state.settleTurn('s1', { kind: 'completed' }, 3)
  // 第二轮干净
  state.observe('s1', { type: 'turn/start', seq: 4 })
  state.observe('s1', { type: 'tool/result', data: { isError: false }, seq: 5 })
  state.settleTurn('s1', { kind: 'completed' }, 6)
  assert.strictEqual(state.soul().wins, 1, `第二轮应该算成 1 件，实际 ${state.soul().wins}`)
  assert.strictEqual(state.soul().totalTurns, 2)
  return '上一轮失败不影响本轮判定'
})

check('边界 turn/end 重放不重复结算', () => {
  const dir = freshDir('replay')
  const state = createState({ dir, log: noLog })
  state.load()
  state.observe('s1', { type: 'turn/start', seq: 1 })
  const a = state.settleTurn('s1', { kind: 'completed' }, 5)
  const b = state.settleTurn('s1', { kind: 'completed' }, 5) // 同一个 seq 重放
  assert.strictEqual(a.changed, true, '第一次没结算')
  assert.strictEqual(b.changed, false, '重放又结算了一次')
  assert.strictEqual(b.reason, 'duplicate-turn-end')
  assert.strictEqual(state.soul().totalTurns, 1, `轮数变成 ${state.soul().totalTurns}`)
  return '同一 seq 只结算一次'
})

// ===========================================================================
// P1-2 多实例可覆盖人格锁
// ===========================================================================

console.log('')
console.log('— P1-2 人格锁 —')

check('P1-2 另一个实例不能覆盖已锁定的人格', () => {
  const dir = freshDir('p12')
  const a = createPersonaStore({ dir, log: noLog })
  a.load()
  const b = createPersonaStore({ dir, log: noLog })
  b.load() // 两个实例都读到「未选」

  const first = a.select('dafeiyu')
  assert.strictEqual(first.ok, true, `A 选择失败：${first.reason}`)

  const second = b.select('pujing') // B 拿着旧快照来抢
  assert.strictEqual(second.ok, false, 'B 用旧快照覆盖了 A 的锁')
  assert.ok(String(second.reason).includes('别处'), `理由不对：${second.reason}`)
  return second.reason.slice(0, 30)
})

check('P1-2 重启后锁和选择都还在', () => {
  const dir = freshDir('p12b')
  const a = createPersonaStore({ dir, log: noLog })
  a.load()
  a.select('dafeiyu')
  const c = createPersonaStore({ dir, log: noLog })
  c.load()
  assert.strictEqual(c.locked(), true, '锁丢了')
  assert.strictEqual(c.selected(), 'dafeiyu', '选择丢了')
  return `${c.selected()} 仍锁定`
})

// ===========================================================================
// P1-3 损坏恢复可能覆盖原数据
// ===========================================================================

console.log('')
console.log('— P1-3 损坏文件 —')

check('P1-3 state.json 损坏 → 原文件被留档，不就地覆盖', () => {
  const dir = freshDir('p13a')
  const file = path.join(dir, 'state.json')
  fs.writeFileSync(file, '{这不是 JSON', 'utf8')
  const state = createState({ dir, log: noLog })
  state.load()
  assert.ok(!fs.existsSync(file) || fs.readFileSync(file, 'utf8').includes('这不是'), '原文件被覆盖了？')
  const backups = fs.readdirSync(dir).filter((name) => name.includes('.corrupt-'))
  assert.ok(backups.length >= 1, '没有留档文件')
  const saved = fs.readFileSync(path.join(dir, backups[0]), 'utf8')
  assert.ok(saved.includes('这不是 JSON'), '留档内容不对')
  return `留档：${backups[0].slice(0, 32)}…`
})

check('P1-3 personas.json 损坏 → 原文件被留档', () => {
  const dir = freshDir('p13b')
  fs.writeFileSync(path.join(dir, 'personas.json'), 'broken{', 'utf8')
  const store = createPersonaStore({ dir, log: noLog })
  store.load()
  const backups = fs.readdirSync(dir).filter((name) => name.includes('.corrupt-'))
  assert.ok(backups.length >= 1, '没有留档文件')
  return `留档 ${backups.length} 个`
})

check('P1-3 readJsonl 读失败返回 error，不当成空库', () => {
  const dir = freshDir('p13c')
  const target = path.join(dir, 'memory.jsonl')
  blockPath(target) // 变成目录 → readFileSync 抛 EISDIR
  const got = readJsonl(target)
  assert.ok(got.error !== null, 'error 是 null（被当成空库了）')
  return String(got.error).slice(0, 40)
})

check('P1-3 读不出来的 memory 进入只读保护，不覆盖', () => {
  const dir = freshDir('p13d')
  const target = path.join(dir, 'memory.jsonl')
  blockPath(target)
  const memory = createMemory({ dir, log: noLog })
  memory.load()
  assert.strictEqual(memory.readOnly(), true, '没进只读保护')
  const result = memory.remember({ kind: 'fact', text: '这条不该被写进去' })
  assert.strictEqual(result.persisted, false, '只读状态居然写成功了')
  return '只读保护生效'
})

check('quarantine 只改名不删除', () => {
  const dir = freshDir('p13e')
  const file = path.join(dir, 'x.json')
  fs.writeFileSync(file, 'original', 'utf8')
  const backup = quarantine(file)
  assert.ok(backup !== null && fs.existsSync(backup), '备份文件不存在')
  assert.strictEqual(fs.readFileSync(backup, 'utf8'), 'original', '备份内容变了')
  assert.ok(!fs.existsSync(file), '原文件还应被移走')
  return path.basename(backup)
})

// ===========================================================================
// P1-4 异常重启后旧记忆复活
// ===========================================================================

console.log('')
console.log('— P1-4 旧记忆复活 —')

check('P1-4 取代后不调 dispose 直接重开，旧条目不会复活', () => {
  const dir = freshDir('p14')
  const first = createMemory({ dir, log: noLog })
  first.load()
  first.remember({ kind: 'preference', subject: '回复长度', text: '不喜欢长篇大论，喜欢先给结论' })
  assert.strictEqual(first.stats().live, 1, '第一条没写进去')

  // 第二条同主题但更细 → 应该取代第一条
  const result = first.remember({
    kind: 'preference',
    subject: '回复长度',
    text: '不喜欢长篇大论，喜欢先给结论，尤其不要表格',
  })
  assert.ok(result.superseded.length + result.ignored.length >= 1, '没有触发取代或去重')

  // ★ 关键：不调用 dispose()，直接新建实例读盘
  const second = createMemory({ dir, log: noLog })
  second.load()
  const live = second.stats().live
  assert.strictEqual(live, 1, `重开后 live=${live}，旧条目复活了`)
  return `重开后 live=1（不是 2）`
})

// ===========================================================================
// P2 学习预算
// ===========================================================================

console.log('')
console.log('— P2 学习预算 —')

check('P2 maxPerDay:0 解析成 0（不是 40）', () => {
  const cfg = resolveConfig({ maxPerDay: 0 })
  assert.strictEqual(cfg.maxPerDay, 0, `被解析成了 ${cfg.maxPerDay}`)
  return 'maxPerDay=0 生效'
})

check('P2 maxPerDay 缺省仍是 40', () => {
  assert.strictEqual(resolveConfig({}).maxPerDay, 40)
  assert.strictEqual(resolveConfig({ maxPerDay: -5 }).maxPerDay, 0, '负数没被夹到 0')
  return '40 / 负数夹到 0'
})

check('P2 reserveLearn 先扣后用，超额被拒', () => {
  const dir = freshDir('p2a')
  const state = createState({ dir, log: noLog })
  state.load()
  const first = state.reserveLearn(2)
  const second = state.reserveLearn(2)
  const third = state.reserveLearn(2)
  assert.strictEqual(first.granted, true, '第一次就拒了')
  assert.strictEqual(second.granted, true, '第二次就拒了')
  assert.strictEqual(third.granted, false, '超额居然给了')
  return `2 次授予，第 3 次拒绝（used=${third.used}）`
})

check('P2 refundLearn 能把额度退回', () => {
  const dir = freshDir('p2b')
  const state = createState({ dir, log: noLog })
  state.load()
  state.reserveLearn(1)
  assert.strictEqual(state.reserveLearn(1).granted, false, '用完了还给了额度')
  state.refundLearn()
  assert.strictEqual(state.reserveLearn(1).granted, true, '退回后应该能再申请')
  return '退回可用'
})

check('P2 预算按本地日切换', () => {
  const stamp = new Date(2026, 10, 1, 23, 30).getTime()
  assert.strictEqual(localDay(stamp), '2026-11-01', '本地日算错了（别用 UTC）')
  return '2026-11-01（本地 23:30）'
})

// ===========================================================================
// 边界：数值校验
// ===========================================================================

console.log('')
console.log('— 边界：状态文件数值 —')

check('边界 state.json 里的 Infinity / 负数被夹回合法范围', () => {
  const dir = freshDir('num')
  fs.writeFileSync(
    path.join(dir, 'state.json'),
    JSON.stringify({
      version: 1,
      soul: { closeness: Infinity, trust: -999, totalTurns: -50, wins: 1e99, fails: NaN },
      traits: { clinginess: Infinity, verbosity: -3 },
      lastEval: { turns: Infinity, at: -1 },
      learnCounters: { day: 'not-a-date', count: Infinity },
      diary: { turnsSince: -10, nextGap: Infinity, lastAt: Infinity, count: -5 },
    }),
    'utf8',
  )
  const state = createState({ dir, log: noLog })
  state.load()
  const snap = state.snapshot()
  assert.ok(Number.isFinite(snap.soul.closeness), `closeness=${snap.soul.closeness}`)
  assert.ok(snap.soul.closeness >= 0.05 && snap.soul.closeness <= 1, `closeness 越界 ${snap.soul.closeness}`)
  assert.ok(Number.isFinite(snap.soul.trust) && snap.soul.trust >= 0.05, `trust=${snap.soul.trust}`)
  assert.ok(Number.isFinite(snap.soul.totalTurns) && snap.soul.totalTurns >= 0, `totalTurns=${snap.soul.totalTurns}`)
  assert.ok(Number.isFinite(snap.traits.clinginess), 'traits 里有非有限值')
  assert.ok(Number.isFinite(snap.lastEval.turns), 'lastEval.turns 非有限')
  assert.strictEqual(snap.learnCounters.day, '', '非法日期没被清掉')
  assert.ok(Number.isFinite(snap.diary.nextGap), 'diary.nextGap 非有限')
  assert.ok(Number.isFinite(snap.diary.turnsSince) && snap.diary.turnsSince >= 0, 'diary.turnsSince 越界')
  return `closeness=${snap.soul.closeness.toFixed(2)} totalTurns=${snap.soul.totalTurns}`
})

// ===========================================================================

console.log('')
console.log(`通过 ${passed} / 失败 ${failed}`)
try {
  fs.rmSync(tmpRoot, { recursive: true, force: true })
} catch {
  // 删不掉不影响结论
}
process.exit(failed === 0 ? 0 : 1)
