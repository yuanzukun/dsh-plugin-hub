/**
 * _selftest_client.mjs —— 前端组件自测
 *
 * client.js 跑在宿主的模块加载器里（window.__ModuleLoader__ + 注入的 React），
 * 本地没有可用的 react 包，所以这里造一个**最小 React 替身**：
 *
 *   createElement / useState / useEffect / useCallback
 *
 * 然后把 GrowSection 在三种数据下各渲染一遍，检查：
 *   1. 不抛错（字段少一个就崩的那种，这里能抓到）
 *   2. 该出现的文案都出现了（仪表盘 / 日记本 / 亲近 / 信任 / 时间戳）
 *   3. 不该出现的没出现（undefined / NaN / [object Object]）
 *   4. 分支正确：没人格 → 选择界面；有人格 → 仪表盘 + 日记
 *
 *   node _selftest_client.mjs
 */

import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert'

const CLIENT = path.join(import.meta.dirname, 'lib', 'client.js')

let passed = 0
let failed = 0

function check(name, fn) {
  try {
    const detail = fn()
    passed += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    failed += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

async function checkAsync(name, fn) {
  try {
    const detail = await fn()
    passed += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    failed += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

// ---------------------------------------------------------------------------
// 最小 React 替身
// ---------------------------------------------------------------------------

function makeFakeReact() {
  const runtime = { states: [], index: 0, effects: [] }

  function createElement(type, props, ...children) {
    const flat = []
    const push = (child) => {
      if (child === null || child === undefined || child === false || child === true) return
      if (Array.isArray(child)) {
        child.forEach(push)
        return
      }
      flat.push(child)
    }
    push(children)
    return { __el: true, type, props: props ?? {}, children: flat }
  }

  function useState(initial) {
    const slot = runtime.index
    runtime.index += 1
    if (!(slot in runtime.states)) {
      runtime.states[slot] = typeof initial === 'function' ? initial() : initial
    }
    const setter = (next) => {
      runtime.states[slot] = typeof next === 'function' ? next(runtime.states[slot]) : next
    }
    return [runtime.states[slot], setter]
  }

  function useEffect(fn) {
    runtime.effects.push(fn)
  }

  function useCallback(fn) {
    return fn
  }

  // 依赖 useRef 的写法也兜一下
  function useRef(initial) {
    const slot = runtime.index
    runtime.index += 1
    if (!(slot in runtime.states)) runtime.states[slot] = { current: initial }
    return runtime.states[slot]
  }

  return {
    React: { createElement, useState, useEffect, useCallback, useRef },
    runtime,
    /** 重置 hook 游标，准备下一次渲染 */
    begin() {
      runtime.index = 0
      runtime.effects = []
    },
  }
}

/** 把渲染树压成纯文本，方便做包含判断。 */
function textOf(node, out = []) {
  if (node === null || node === undefined) return out
  if (typeof node === 'string' || typeof node === 'number') {
    out.push(String(node))
    return out
  }
  if (Array.isArray(node)) {
    for (const child of node) textOf(child, out)
    return out
  }
  if (node.__el === true) {
    // ★ 组件的 title / label / hint / placeholder 都在 props 里，
    //   只扫 children 会漏掉「仪表盘」「日记本」这种标题。
    for (const [key, value] of Object.entries(node.props)) {
      if (key === 'children' || key === 'style') continue
      if (typeof value === 'string' || typeof value === 'number') out.push(String(value))
    }
    textOf(node.children, out)
    return out
  }
  return out
}

function allText(node) {
  return textOf(node).join('\n')
}

/** 收集所有元素类型，检查树结构。 */
function typesOf(node, out = new Set()) {
  if (node === null || node === undefined) return out
  if (Array.isArray(node)) {
    for (const child of node) typesOf(child, out)
    return out
  }
  if (node.__el === true) {
    out.add(typeof node.type === 'function' ? (node.type.name || 'anon') : node.type)
    typesOf(node.children, out)
  }
  return out
}

// ---------------------------------------------------------------------------
// 加载 client.js
// ---------------------------------------------------------------------------

async function loadClient() {
  const source = fs.readFileSync(CLIENT, 'utf8')
  const fake = makeFakeReact()

  let captured = null
  const window = {
    __ModuleLoader__: {
      load(definition) {
        captured = definition
      },
    },
  }

  // client.js 是 IIFE 风格的脚本，不是 ESM —— 用 Function 构造器跑，注入 window
  // 注意：内部 fetch 走闭包，所以这里必须转发到 globalThis.fetch（测试里会被替换）
  const runner = new Function('window', 'fetch', `${source}\n;return window;`)
  runner(window, (input, init) => globalThis.fetch(input, init))

  assert.ok(captured !== null, 'client.js 没有调用 __ModuleLoader__.load')
  assert.strictEqual(captured.id, 'dsh-grow')

  const factory = captured.factory
  const component = factory((name) => {
    if (name === 'react') return fake.React
    throw new Error(`意外的 require：${name}`)
  })

  return { component, fake, window }
}

// ---------------------------------------------------------------------------
// 渲染辅助
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------

const loaded = await loadClient()
const { component, fake } = loaded
assert.ok(component.inject.includes('slots'), 'inject 声明不对')

let registeredSection = null
const ctx = {
  slots: {
    inject(name, fn) {
      assert.strictEqual(name, 'settings.section')
      fn()
    },
    register(meta, Comp) {
      registeredSection = { meta, Comp }
    },
  },
}
component.apply(ctx)

check('组件注册到 settings.section', () => {
  assert.ok(registeredSection !== null, '没注册')
  assert.strictEqual(registeredSection.meta.id, 'grow')
  assert.strictEqual(registeredSection.meta.label, '成长')
  return `order=${registeredSection.meta.order}`
})

const GrowSection = registeredSection.Comp

/** 造一份假的接口数据。 */
function makeData({ locked = true, withDiary = true } = {}) {
  const traits = [
    { key: 'clinginess', label: '撒娇', value: 0.649, lo: 0.15, hi: 0.9, text: '黏一点：每轮至少一次主动关心或撒娇', position: 0.66 },
    { key: 'verbosity', label: '话量', value: 0.536, lo: 0.2, hi: 0.85, text: '正常长度：该展开就展开，不硬凑', position: 0.52 },
    { key: 'humor', label: '幽默', value: 0.452, lo: 0.1, hi: 0.8, text: '会接梗：合适的时机插一句', position: 0.5 },
    { key: 'dependence', label: '依赖', value: 0.48, lo: 0.2, hi: 0.85, text: '拿不准会确认一下再动', position: 0.43 },
    { key: 'diligence', label: '认真', value: 0.6, lo: 0.4, hi: 0.95, text: '会核对关键数字', position: 0.36 },
    { key: 'emotionRate', label: '情绪外化', value: 0.402, lo: 0.1, hi: 0.7, text: '情绪可见：会说自己累、开心或紧张', position: 0.5 },
  ]
  const status = {
    ok: true,
    soul: { closeness: 0.769, trust: 1, totalTurns: 396, wins: 336, fails: 2, sessions: 82 },
    traits,
    stats: { live: 473, total: 569, stale: 96, counts: { relation: 40, preference: 80, fact: 197, episode: 156 }, file: 'C:\\x\\memory.jsonl' },
    digest: '- 助手自称「本鲸」',
    lastEval: { turns: 388, at: 1793465984714 },
    learn: { day: '2026-11-01', count: 3 },
    diary: {
      turnsSince: 3,
      nextGap: 7,
      remaining: 4,
      due: false,
      count: 12,
      stats: { count: 12, days: 5, file: 'C:\\x\\diary.jsonl' },
    },
    drift: {
      turns: 388,
      at: 1793465984714,
      changes: [
        { key: 'clinginess', label: '撒娇', from: 0.6, to: 0.649, why: '被夸 0.8' },
        { key: 'humor', label: '幽默', from: 0.4, to: 0.452, why: '关系松' },
      ],
    },
    persona: {
      selected: locked ? 'dafeiyu' : '',
      locked,
      lockedAt: locked ? 1793465984714 : 0,
      name: locked ? '大肥鱼' : '',
      items: [
        { id: 'dafeiyu', name: '大肥鱼', description: '叫主人、自称本鲸', text: '## 聊天人设：大肥鱼\n- 自称本鲸', chars: 24, selected: locked },
        { id: 'pujing', name: '普鲸', description: '不寒暄、直接给结论', text: '## 说话方式：普鲸\n- 直接给结论', chars: 20, selected: false },
      ],
      file: 'C:\\x\\personas.json',
      note: '',
    },
  }
  const diaryItems = withDiary
    ? [
        {
          id: 'd-abc',
          at: 1793512800000,
          stamp: '2026-11-01 15:20',
          turnsFrom: 389,
          turnsTo: 396,
          turnsCount: 8,
          mood: '被夸了',
          text: '今天主人让我把成长插件整个重做。一开始我还有点慌，怕又做错方向。',
          source: 'model',
        },
        {
          id: 'd-def',
          at: 1793426400000,
          stamp: '2026-10-31 15:20',
          turnsFrom: 381,
          turnsTo: 388,
          turnsCount: 8,
          mood: '主人一直在催',
          text: '被催了一天，手上三件事都没收干净，有点累。',
          source: 'rule',
        },
      ]
    : []
  return { status, diaryItems }
}

/** 把 useEffect 里的 fetch 换成一问一答。 */
function installFetch(status, diaryItems) {
  globalThis.fetch = async (url) => {
    const pathname = String(url)
    const payload = pathname.includes('diary')
      ? { ok: true, items: diaryItems, stats: { count: diaryItems.length, days: 2 } }
      : status
    return {
      ok: true,
      status: 200,
      json: async () => payload,
    }
  }
}

/**
 * 渲染：跑一遍拿到效果 → 执行 effect（填 state）→ 再跑一遍。
 * 假的 useState 会把状态留在 runtime.states 里，所以第二遍能读到。
 */
async function renderScenario(status, diaryItems) {
  installFetch(status, diaryItems)
  globalThis.fetch = globalThis.fetch

  fake.begin()
  const first = GrowSection() // status=null → 加载中
  const firstText = allText(first)

  // 跑 effect（reload 是 async 的）
  for (const effect of fake.runtime.effects.slice()) {
    await effect()
  }
  // reload 内部是 async，等一轮微任务
  await new Promise((resolve) => setTimeout(resolve, 30))

  fake.begin()
  const second = GrowSection()
  return { first, firstText, second, secondText: allText(second), types: typesOf(second) }
}

// ---------------------------------------------------------------------------
// 场景 1：已选人格 + 有日记（正常态）
// ---------------------------------------------------------------------------

const normal = makeData({ locked: true, withDiary: true })
const main = await renderScenario(normal.status, normal.diaryItems)

check('正常态：第一遍是「加载中」', () => {
  assert.ok(main.firstText.includes('加载中'), `第一遍不是加载中：${main.firstText.slice(0, 60)}`)
  return '加载中…'
})

check('正常态：渲染不抛错', () => {
  assert.ok(main.second !== null && main.second !== undefined)
  return `${main.types.size} 种元素`
})

check('正常态：标题 + 仪表盘 + 日记本都在', () => {
  const text = main.secondText
  for (const wanted of ['成长', '仪表盘', '日记本', '亲近', '信任', '一起走过', '做完', '说话方式']) {
    assert.ok(text.includes(wanted), `缺「${wanted}」`)
  }
  return '标题/仪表盘/日记本齐'
})

check('正常态：关系数字显示正确', () => {
  const text = main.secondText
  assert.ok(text.includes('77%'), '亲近 77% 没显示')
  assert.ok(text.includes('100%'), '信任 100% 没显示')
  assert.ok(text.includes('396'), '轮数没显示')
  assert.ok(text.includes('336'), '完成数没显示')
  return '77% / 100% / 396 轮 / 336 件'
})

check('正常态：六个说话参数都列出来了', () => {
  const text = main.secondText
  for (const label of ['撒娇', '话量', '幽默', '依赖', '认真', '情绪外化']) {
    assert.ok(text.includes(label), `缺 ${label}`)
  }
  assert.ok(text.includes('0.65'), '撒娇值没显示')
  return '6 项齐全'
})

check('正常态：显示「最近一次调整」', () => {
  const text = main.secondText
  assert.ok(text.includes('最近一次调整'), '没有调整记录行')
  assert.ok(text.includes('0.6'), '调整数字没显示')
  return '有调整记录'
})

check('正常态：日记时间戳和正文都在', () => {
  const text = main.secondText
  assert.ok(text.includes('2026-11-01 15:20'), '第一篇时间戳没显示')
  assert.ok(text.includes('2026-10-31 15:20'), '第二篇时间戳没显示')
  assert.ok(text.includes('今天主人让我把成长插件整个重做'), '日记正文没显示')
  return '2 篇日记'
})

check('正常态：日记带轮次和心情标签', () => {
  const text = main.secondText
  assert.ok(text.includes('第 389~396 轮'), '轮次标签没显示')
  assert.ok(text.includes('被夸了'), '心情标签没显示')
  assert.ok(text.includes('兜底'), '兜底标记没显示')
  return '轮次/心情/兜底标记齐'
})

check('正常态：人格锁定状态显示出来了', () => {
  const text = main.secondText
  assert.ok(text.includes('大肥鱼'), '人格名没显示')
  assert.ok(text.includes('已锁定'), '锁定标记没显示')
  return '大肥鱼 · 已锁定'
})

check('正常态：没有任何 undefined / NaN / [object Object]', () => {
  const text = main.secondText
  for (const bad of ['undefined', 'NaN', '[object Object]', 'null']) {
    assert.ok(!text.includes(bad), `文本里出现了「${bad}」：\n${text.slice(0, 400)}`)
  }
  return '干净'
})

check('正常态：没有可编辑控件（滑条 / 删除按钮都不该有）', () => {
  const collect = (node, out = []) => {
    if (node === null || node === undefined) return out
    if (Array.isArray(node)) {
      node.forEach((c) => collect(c, out))
      return out
    }
    if (node.__el === true) {
      out.push(node.type)
      collect(node.children, out)
    }
    return out
  }
  const types = collect(main.second)
  assert.ok(!types.includes('input'), '出现了 input（参数不该能改）')
  assert.ok(!types.includes('textarea'), '出现了 textarea')
  assert.ok(!types.includes('range'), '出现了滑条')
  const text = main.secondText
  assert.ok(!text.includes('作废'), '出现了「作废」按钮')
  assert.ok(!text.includes('回滚'), '出现了「回滚」按钮')
  assert.ok(!text.includes('滑到哪就是哪'), '还是旧版的滑条文案')
  return '只读'
})

// ---------------------------------------------------------------------------
// 场景 2：没选人格（选择界面）
// ---------------------------------------------------------------------------

const fresh = makeData({ locked: false, withDiary: false })
const picker = await renderScenario(fresh.status, fresh.diaryItems)

check('没人格：显示选择界面而不是仪表盘', () => {
  const text = picker.secondText
  assert.ok(text.includes('先定一下她是谁'), '没有选择界面')
  assert.ok(text.includes('大肥鱼'), '缺大肥鱼卡片')
  assert.ok(text.includes('普鲸'), '缺普鲸卡片')
  assert.ok(!text.includes('日记本'), '没选人格就露出日记本了')
  return '两套可选'
})

check('没人格：**没有**自定义入口（主人要求只留 5 套预设）', () => {
  const text = picker.secondText
  assert.ok(!text.includes('写一套自己的'), '「写一套自己的」按钮还在')
  assert.ok(!text.includes('或者自己写一套'), '自定义卡片还在')
  assert.ok(!text.includes('先存起来'), '自定义保存按钮还在')
  return '已移除'
})

check('没人格：说明「只能选一次」', () => {
  const text = picker.secondText
  assert.ok(text.includes('只能选一次') || text.includes('选完就锁死'), '没说明锁定')
  return '有说明'
})

// ---------------------------------------------------------------------------
// 场景 3：有人格但还没写过日记（空状态）
// ---------------------------------------------------------------------------

const empty = makeData({ locked: true, withDiary: false })
const blank = await renderScenario(empty.status, empty.diaryItems)

check('空日记本：给出解释而不是空白', () => {
  const text = blank.secondText
  assert.ok(text.includes('还没有日记'), `空态文案缺失：${text.slice(-200)}`)
  assert.ok(text.includes('5~10 轮'), '没说明节奏')
  return '有引导文案'
})

check('空日记本：仪表盘照常显示', () => {
  const text = blank.secondText
  assert.ok(text.includes('仪表盘'), '仪表盘没了')
  assert.ok(text.includes('77%'), '数字没了')
  return '仪表盘正常'
})

// ---------------------------------------------------------------------------

console.log('')
console.log(`通过 ${passed} / 失败 ${failed}`)
process.exit(failed === 0 ? 0 : 1)
