# 校验说明 —— dsh-grow 0.2.0

给帮忙看后端的朋友。

这是一份 **DSH（DeepSeek Harness）插件**，不是独立程序。它挂在宿主里跑，给聊天助手加一层「会记事、会长大、会写日记」的心智。

**它不联网、不需要 API key、不启动任何外部进程。** 所有模型调用都走宿主自己的通道（`ctx.llm`）。

---

## 一、先跑测试

不需要装 DSH，不需要联网，纯 Node：

```powershell
cd <解压出来的目录>
node _selftest.mjs           # 59 项：各模块单体逻辑
node _selftest_v2.mjs        # 18 项：0.2.0 改动点（漂移 / 日记 / 人格锁定）
node _selftest_regress.mjs   # 32 项：异常路径回归（审查看这里）
node _selftest_apply.mjs     # 31 项：模拟 DSH 运行时把 apply() 完整跑一遍
node _selftest_client.mjs    # 17 项：假 React 渲染前端组件树
node _selftest_fresh.mjs     # 15 项：全新安装验收（从 0 轮 / 参数全初值）
node _selftest_fix031.mjs  # 28 项：0.3.2 审查修复回归（每条都有最小复现）
```

**期望结果：七份全部 0 失败，合计 200 项。**

| 脚本 | 验证什么 | 怎么隔离 |
|---|---|---|
| `_selftest.mjs` | 记忆库增删改查、隐私闸门、词表、JSON 解析、漂移边界 | 临时目录 |
| `_selftest_v2.mjs` | 参数真的会动、分档跨档、日记清理/兜底、人格锁定、日记节奏 | 临时目录 |
| **`_selftest_regress.mjs`** | **写盘失败、隐私绕过、轮次重复、人格锁竞争、损坏文件、旧记忆复活、预算、CSRF** | 临时目录 + **故意制造 I/O 失败** |
| `_selftest_apply.mjs` | `apply()` 启动、提示词段落、工具注册、6 个路由、12 轮对话、CSRF 令牌 | **改 `USERPROFILE` 到临时目录** |
| `_selftest_client.mjs` | 组件树渲染三种数据状态、只读性、字段缺失不崩 | 全内存 |
| **`_selftest_fresh.mjs`** | **全新安装是白纸：0 轮 / 50% / 六参数初值 / 五套未选 / 记忆日记全空 / 无绝对路径残留** | **改 `USERPROFILE` 到全新空目录** |

> ⚠ 七个脚本都**只写临时目录**，跑完自己删。不会读也不会改真实数据。
> `_selftest_regress.mjs` 会把目标路径**故意变成一个目录**来制造写盘失败，这是它验证「失败路径」的手段，不是 bug。

---

## 一·五、0.2.1 相对 0.2.0 改了什么

上一版（0.2.0）交出去之后，外部审查专门做了**异常路径**测试，8 个复现用例**全部命中**。
也就是说：0.2.0 的 117 项自测全绿，但异常路径一条都没覆盖。

这一版逐条修了，并且把每个问题都固化成了 `_selftest_regress.mjs` 里的用例。

| 级别 | 问题 | 修复要点 | 回归用例 |
|---|---|---|---|
| P0 | 隐私闸门能绕过 | 规则按「凭据形态」重写（password / JWT / AKIA / Bearer / 私钥 / URL 凭据） | P0-1 × 9 |
| P0 | 写盘失败仍返回成功 | `flush` 写成功才清 dirty；`select/append/remember` 失败回滚内存 + 如实返回 | P0-2 × 5 |
| P1 | 历史工具结果重复计入每轮 | 改成本轮增量，结算后归零 | P1-1 × 3 |
| P1 | 多实例覆盖人格锁 | 选之前重读磁盘，已锁就拒 | P1-2 × 2 |
| P1 | 损坏恢复覆盖原数据 | `quarantine()` 改名留档 + I/O 失败进只读保护 | P1-3 × 5 |
| P1 | 旧记忆异常重启复活 | 墓碑也追加，load 按 id 去重（后写生效） | P1-4 × 1 |
| P1 | 日记异步竞争 | 全局互斥 + 只清已消费缓冲 | apply × 2 |
| P2 | 学习预算不可靠 | `numeric()` 解析 / 先扣后用 + 失败退回 / 本地日 | P2 × 5 |
| 边界 | turn/end 重放重复结算 | 按 seq 去重 | P1-1 × 1 |
| 边界 | 被闸门拒了还回「记下了」 | 优先判 `rejected` | apply × 2 |
| 边界 | Infinity / 负数进状态 | `finite()` 逐个夹到合法范围 | 边界 × 1 |
| 边界 | 写接口 CSRF | Origin 校验 + `X-Grow-Token` | apply × 3 |

**这一版最值得复核的三处**：

1. **`lib/store.js` 的 `readJsonl`** —— 现在把「文件不存在」和「读失败」分开报，调用方据此进只读保护。旧版两者都返回空数组，这是「损坏后覆盖原数据」的根源。
2. **`lib/state.js` 的 `flush()`** —— 写成功才清 `dirty`。旧版顺序反了：先清再写，写失败后连 `dispose()` 都不会重试。
3. **`lib/index.js` 的 `isTrustedWrite()`** —— CSRF 防线。注意 `panelToken` 只在 `/grow/status.json` 返回，其他接口不给。

---

## 二、建议重点看的四处

### 1. 参数漂移的幅度（`lib/traits.js`）

这是 0.2.0 的核心改动，也是最值得质疑的地方 —— **我把单次步长放大了 3 倍**。

旧算法（0.1.0）实际效果：396 轮里六个参数**五个一动没动**。

```
初始:  0.60 / 0.55 / 0.40 / 0.50 / 0.60 / 0.35
396轮: 0.60 / 0.536 / 0.40 / 0.50 / 0.60 / 0.35
```

旧漏法的链条：

```
perTurn() 除以轮数  →  每轮平均 0.1~0.3
→  0.12 门限滤掉大半
→  BASE_STEP 0.02 × 0.7 阻尼
→  20 轮一次
```

新参数：

| 项 | 旧 | 新 |
|---|---|---|
| 归一化 | `value / turns` | `value / max(1.5, turns * 0.5)` |
| 门限 `DEAD_ZONE` | 0.12 | 0.05 |
| `BASE_STEP` | 0.02 | 0.06 |
| `DAMP` | 0.7 | 0.3 |
| `evalEvery` | 20 | 8 |

**请重点看 `evaluate()` 和 `stepToward()`**：

- 边界 `BOUNDS` 没改，最大最小值仍然是硬的。
- 越靠近边界，`damping` 越小（`1 - 0.3 * (1 - remaining)`），所以是渐进的，不是匀速撞墙。
- 安全话题（`safetyTouched > 0`）当轮整批跳过，这是 0.1.0 就有的硬约束，保留了。

**可能的质疑点**：96 轮纯正向信号就能把撒娇从 0.60 推到 0.90（封顶）。我判断这在真实对话里不会发生（真实信号是混合的），但如果你觉得太快，`BASE_STEP` 和 `DAMP` 是两个旋钮，改小就行。

### 2. 日记的触发与失败处理（`lib/diary.js` + `lib/index.js` 的 `runDiary`）

- 触发：`state.settleTurn()` 每轮 `diary.turnsSince += 1`，到 `nextGap`（5~10 随机）就 `due = true`。
- 写：`runDiary()` 走模型；模型不可用就 `fallbackDiary()` 用规则兜底，并在条目里标 `source: 'rule'`。
- 失败：**不重试**。`diaryRetry()` 只把计数压回去一轮，不会无限重试。
- 缓冲：`diaryEntries` 和学习的 `entries` 是**两个独立缓冲** —— 因为学习会 `splice` 掉 `entries`，共用会导致日记读到空。

**可能的质疑点**：

- 模型返回的日记没有长度校验（只要 ≥40 字就收），300 字是 prompt 软目标。要不要加硬校验？
- `cleanDiary()` 只是剥标题/日期行/代码块，没有做内容审查。

### 3. 只读边界（`lib/index.js` 的 `registerPanelRoutes`）

`/grow/act` 现在只剩两个动作：

```js
case 'selectPersona'     // 首次选择，选完 lockedAt > 0
case 'addCustomPersona'  // 首次自定义
default: 一律拒绝
```

**已撤销的写接口**：`setTrait`（改参数）、`rollback`（回滚人格）、`forget`（删记忆）、`lock`（锁定记忆）。

所有路由都有 `isLocal()` 检查：`remoteAddress` 必须是 `127.0.0.1`/`::1`，且 `Host` 头必须是 localhost。测试里有一条专门验这个（用 `10.1.2.3` + `evil.example.com` 请求，期望 403）。

**可能的质疑点**：`isLocal()` 只检查 `Host` 头和 socket 地址，没有防 DNS rebinding 的随机 token。

### 4. 数据文件的向后兼容（`lib/state.js` / `lib/persona.js` 的 `load()`）

三处兼容处理：

| 情况 | 处理 |
|---|---|
| `state.json` 没有 `diary` 字段 | 用默认值 `{ turnsSince: 0, nextGap: 0, lastAt: 0, count: 0 }` |
| `personas.json` 有 `selected` 但**没有** `lockedAt` | 视为「早就选过了」，补上锁并**落盘**（否则每次重启都重新算时间） |
| `personas.json` 是坏 JSON | 回落「未选」+ 内置五套，插件照常启动 |

**请重点看第 2 条** —— 它有副作用：`load()` 里会调 `save()` 写盘。这是唯一一个「读的时候顺手写」的地方。

---

## 三、代码结构

```
dsh-grow/
├── package.json          # 插件清单，dsh.bundle.patch 指向 cordis.patch.yml
├── cordis.patch.yml      # 往宿主里插一行 host 配置（含默认 config）
├── icon.svg
├── README.md             # 面向使用者的说明
├── VERIFY.md             # 本文件
├── lib/
│   ├── index.js          # 主入口：apply()、事件订阅、工具注册、面板路由  ← 最大，44KB
│   ├── client.js         # 前端组件（跑在宿主 web 侧，非 Node）
│   ├── state.js          # 层 A：会话事件 → 情绪/关系数值；日记节奏计数
│   ├── memory.js         # 层 B：结构化记忆条目 + 隐私闸门
│   ├── diary.js          # 层 D：日记生成（0.2.0 新增）
│   ├── traits.js         # 层 C：六个参数漂移（0.2.0 重写）
│   ├── render.js         # 把数字渲染成给模型看的文本
│   ├── persona.js        # 人格库 + 锁定（0.2.0 重写）
│   ├── summarize.js      # 调宿主模型做结构化总结
│   ├── store.js          # 原子写 / JSONL 读写
│   └── lexicon.js        # 中文情绪词表（纯规则，零成本）
├── locale/{zh,en}.json
└── _selftest*.mjs        # 四份测试
```

### 数据流向

```
会话事件 ──→ state.observe()  ──→ 每轮处境（插入 runtime-context）
   │                │
   │                └──→ 累积信号 ──→ 每 8 轮 traits.evaluate() ──→ 六个参数
   │                                                              ↓
   │                                                    render.renderPersona()
   │                                                              ↓
   │                                                    （插入 system prompt）
   │
   └──→ 消息缓冲 ──┬──→ memory（每 6 条总结一次结构化记忆）
                   └──→ diary（每 5~10 轮写一篇 300 字日记）
```

### 两条硬约束（写在多处注释里）

1. **只读会话事件，绝不 append 新事件类型** —— 加新类型会让会话文件打不开。
2. **所有统计/学习/日记失败一律静默** —— 不许因为记忆出问题拖垮聊天本身。

---

## 四、宿主接口依赖

它只用宿主已有的服务，**没有引入任何新 API**：

| 服务 | 用法 |
|---|---|
| `ctx.on('session/event')` | 读事件（只读） |
| `ctx.systemPrompt.section({ name, order, interpolate, text })` | 注册人格段、说话方式段 |
| `agent.ctx.systemPrompt.context({ ... })` | 注册每轮状态段 |
| `ctx.inject(['tools'])` 后 `tools.register(definition)` | 注册 6 个 `grow_*` 工具 |
| `ctx.inject(['webServer'])` 后 `webServer.register({ kind:'exact', path, handler })` | 注册面板路由 |
| `ctx.get('llm')` → `llm.stream(...)` | 调模型写记忆/日记 |
| `ctx.effect(fn, label)` | 生命周期清理 |

**如果你要核对宿主 API 是否被正确使用**，重点是 `index.js` 里 `installForAgent()` 那段 —— 它用「双重 `ctx.effect`」包住 agent 侧注册，防止热加载时重复挂载。注释里写了为什么。

---

## 五、已知限制

1. **日记没有长度硬校验**。prompt 写 300 字，模型可能写 150 或 500。
2. **参数漂移的单次上限是 6%**，理论上 20 次连续同向评估就能走到边界。真实对话不会这么纯，但没有额外的「降温」机制。
3. **`isLocal()` 没有防 DNS rebinding 的 token**。
4. **`persona.load()` 会写盘**（补 `lockedAt`），这是个读操作带副作用的例外。
5. **前端用 `window.__ModuleLoader__` + 宿主注入的 React**，本地没有独立 react 包，所以 `_selftest_client.mjs` 用的是手写的假 React —— 它验证的是**组件树结构和字段引用**，不验证真实 DOM 渲染。
6. **没有 TypeScript**，纯 JS + JSDoc 注释。

---

## 六、如果你是纯静态审代码

从这三个文件开始就够覆盖 80% 的风险：

1. **`lib/index.js`** —— 看 `apply()` 的启动顺序、`runDiary()`、`registerPanelRoutes()`
2. **`lib/traits.js`** —— 看 `evaluate()` 和 `stepToward()` 的边界处理
3. **`lib/diary.js`** —— 看 `writeDiaryWithModel()` 的失败路径和 `cleanDiary()`

---

## 七、怎么装

如果要在真实 DSH 里跑：

1. `npm pack` 得到 `.tgz`（或者直接用源码目录）
2. 宿主插件管理 → 从本地包安装
3. **装完必须重启 DSH**（host 侧代码不会热加载）

数据目录：`~/.dsh/grow/`（Windows 是 `%USERPROFILE%\.dsh\grow\`）

| 文件 | 内容 |
|---|---|
| `state.json` | 关系账本 + 参数 + 日记节奏 |
| `memory.jsonl` | 结构化记忆 |
| `diary.jsonl` | 日记 |
| `personas.json` | 人设库 |
| `persona-history.jsonl` | 每次参数变更记录 |

删掉整个目录 = 重新认识。
