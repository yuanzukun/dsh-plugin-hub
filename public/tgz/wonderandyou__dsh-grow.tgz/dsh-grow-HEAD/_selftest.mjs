/**
 * _selftest.mjs —— 离线自测（不装进 DSH 就能跑）
 *
 * 目的：在动真实环境之前，先把「逻辑对不对」验证掉。
 * 只用临时目录，绝不碰 ~/.dsh/grow。
 *
 * 跑法：node _selftest.mjs
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createState } from './lib/state.js'
import { createMemory, sensitiveReason } from './lib/memory.js'
import { evaluate, BOUNDS, snapshotView } from './lib/traits.js'
import { renderLive, renderPersona, renderTrace } from './lib/render.js'
import { parsePayload, buildTranscript } from './lib/summarize.js'
import { createPersonaStore } from './lib/persona.js'
import { readUtterance, readToolOutcome } from './lib/lexicon.js'
import { readJsonl, writeJsonlAtomic, readJson, writeJsonAtomic } from './lib/store.js'

const tmpRoot = path.join(os.tmpdir(), `grow-selftest-${process.pid}`)
fs.rmSync(tmpRoot, { recursive: true, force: true })

let pass = 0
let fail = 0

function check(label, condition, detail = '') {
  if (condition) {
    pass += 1
    console.log(`  ✓ ${label}`)
  } else {
    fail += 1
    console.log(`  ✗ ${label}${detail !== '' ? ` — ${detail}` : ''}`)
  }
}

function section(title) {
  console.log(`\n[${title}]`)
}

// ---------------------------------------------------------------------------
section('store：原子写 / JSONL 坏行跳过')

{
  const dir = path.join(tmpRoot, 'store')
  fs.mkdirSync(dir, { recursive: true })
  const jsonFile = path.join(dir, 'a.json')
  writeJsonAtomic(jsonFile, { hello: '世界', n: 1 })
  const gotJson = readJson(jsonFile, null)
  check('JSON 往返一致', gotJson.ok === true && gotJson.value?.hello === '世界')

  const jsonlFile = path.join(dir, 'b.jsonl')
  writeJsonlAtomic(jsonlFile, [{ a: 1 }, { a: 2 }])
  fs.appendFileSync(jsonlFile, '{坏行}\n{"a":3}\n', 'utf8')
  const gotJsonl = readJsonl(jsonlFile)
  check('坏行被跳过、好行全在', gotJsonl.rows.length === 3 && gotJsonl.bad === 1, `rows=${gotJsonl.rows.length} bad=${gotJsonl.bad}`)

  const missing = readJson(path.join(dir, 'nope.json'), { fallback: true })
  check('文件不存在回落默认值', missing.ok === true && missing.value?.fallback === true)
}

// ---------------------------------------------------------------------------
section('lexicon：一句话读成信号')

{
  const warm = readUtterance('谢谢主人，太好了，本鲸喜欢这个！')
  check('正反馈能被识别', warm.signal.warm > 0.5 && warm.tone > 0.4, `warm=${warm.signal.warm.toFixed(2)} tone=${warm.tone.toFixed(2)}`)

  const cold = readUtterance('不对，还是不行，算了')
  check('负反馈能被识别', cold.signal.cold > 0.4 && cold.tone < 0, `cold=${cold.signal.cold.toFixed(2)} tone=${cold.tone.toFixed(2)}`)

  const short = readUtterance('太长了，简短点')
  check('「嫌长」能被识别', short.signal.asksShort > 0.5, `asksShort=${short.signal.asksShort.toFixed(2)}`)

  const ok = readToolOutcome({ message: { content: [{ type: 'text', text: 'ok [exit code: 2]' }] } })
  check('工具失败能被识别', ok.failed === true)
}

// ---------------------------------------------------------------------------
section('state：事件 → 状态，且重启不清零')

const stateDir = path.join(tmpRoot, 'state')
fs.mkdirSync(stateDir, { recursive: true })

function feed(handle, sessionId, events) {
  for (const event of events) handle.observe(sessionId, event)
}

{
  const state = createState({ dir: stateDir, log: () => {} })
  state.load()

  const sid = 'session-A'
  let seq = 1
  const mk = (type, data) => ({ type, data, seq: seq++, time: Date.now() })

  feed(state, sid, [
    mk('turn/start', { turn: 1 }),
    mk('step/start', { turn: 1, step: 1 }),
    mk('user/message', { role: 'user', content: [{ type: 'text', text: '谢谢主人！太好了，本鲸喜欢这个' }] }),
    mk('assistant/message', { message: { role: 'assistant', content: [{ type: 'text', text: '好呀主人' }, { type: 'tool-call', id: 't1', name: 'x', arguments: '{}' }] } }),
    mk('tool/result', { message: { role: 'tool', content: [{ type: 'text', text: 'done' }] } }),
  ])

  const before = state.derive(sid)
  check('效价为正（刚被夸）', before.valence > 0.2, `valence=${before.valence.toFixed(2)}`)
  check('情绪词是「开心」或「稳」', ['开心', '稳'].includes(before.mood), `mood=${before.mood}`)

  const settled = state.settleTurn(sid, { kind: 'completed' })
  check('结算记了一轮', settled.changed === true && state.soul().totalTurns === 1)
  check('干净完成计入 wins', state.soul().wins === 1, `wins=${state.soul().wins}`)

  // 再灌一批负面
  feed(state, sid, [
    mk('turn/start', { turn: 2 }),
    mk('user/message', { role: 'user', content: [{ type: 'text', text: '不对，还是不行，算了' }] }),
    mk('tool/result', { message: { role: 'tool', content: [{ type: 'text', text: 'err [exit code: 1]' }] } }),
  ])
  const after = state.derive(sid)
  check('负反馈把效价拉下来', after.valence < before.valence, `${before.valence.toFixed(2)} → ${after.valence.toFixed(2)}`)

  state.soulDelta({ closeness: 0.83 })
  state.flush()

  // 关键：模拟「重启」
  const reopened = createState({ dir: stateDir, log: () => {} })
  reopened.load()
  check('重启后亲近度不清零', Math.abs(reopened.soul().closeness - 0.83) < 0.001, `closeness=${reopened.soul().closeness}`)
  check('重启后轮数还记得', reopened.soul().totalTurns === 1, `totalTurns=${reopened.soul().totalTurns}`)
}

// ---------------------------------------------------------------------------
section('memory：合并决策（新增 / 取代 / 无视）')

const memDir = path.join(tmpRoot, 'memory')
fs.mkdirSync(memDir, { recursive: true })

{
  const memory = createMemory({ dir: memDir, log: () => {} })
  memory.load()

  const first = memory.mergeBatch([
    { kind: 'preference', subject: '回复长度', text: '不喜欢长篇大论，喜欢先给结论', importance: 0.8, confidence: 0.9 },
  ])
  check('第一次是新增', first.added.length === 1 && memory.stats().live === 1)

  const dup = memory.mergeBatch([
    { kind: 'preference', subject: '回复长度', text: '不喜欢长篇大论，喜欢先给结论', importance: 0.8, confidence: 0.9 },
  ])
  check('一模一样的内容不重复写', dup.added.length === 0 && dup.ignored.length === 1 && memory.stats().live === 1)

  const newer = memory.mergeBatch([
    { kind: 'preference', subject: '回复长度', text: '不喜欢长篇大论，喜欢先给结论，尤其不要表格', importance: 0.85, confidence: 0.9 },
  ])
  check('更细的新版本取代旧条目', newer.superseded.length === 1 && memory.stats().live === 1, `live=${memory.stats().live}`)

  const other = memory.mergeBatch([
    { kind: 'fact', subject: '输入法', text: '主人不用拼音输入法', importance: 0.7, confidence: 0.9 },
    { kind: 'relation', subject: '称呼', text: '主人叫我大肥鱼，自称本鲸', importance: 0.9, confidence: 0.95 },
  ])
  check('不同主题各自新增', other.added.length === 2 && memory.stats().live === 3)

  const found = memory.search({ query: '输入法', limit: 5 })
  check('关键词能搜到', found.length >= 1 && found[0].text.includes('拼音'), `hits=${found.length}`)

  const digest = memory.digest({ chars: 800 })
  check('摘要非空且有内容', digest !== '' && digest.text.length > 10 && digest.text.length <= 820, `chars=${digest?.chars}`)

  // 自述降权
  const selfItem = memory.mergeBatch([
    { kind: 'fact', subject: '习惯', text: '我猜主人喜欢深夜写代码', importance: 0.9, confidence: 0.4, self: true },
  ])
  check('模型自述被降权', selfItem.added.length === 1 && selfItem.added[0].importance < 0.6, `importance=${selfItem.added[0]?.importance}`)

  memory.saveAll()
  const reopened = createMemory({ dir: memDir, log: () => {} })
  reopened.load()
  check('重启后记忆还在', reopened.stats().total >= 4, `total=${reopened.stats().total}`)
}

// ---------------------------------------------------------------------------
section('traits：漂移有方向、有边界、安全话题不动')

{
  const base = {
    clinginess: 0.6,
    verbosity: 0.55,
    humor: 0.4,
    dependence: 0.5,
    diligence: 0.6,
    emotionRate: 0.35,
  }

  const scolded = evaluate(base, { asksShort: 4, cold: 2, turnsSeen: 10 }, { turns: 10 })
  check('被嫌长 → 话量下降', scolded.next.verbosity < base.verbosity, `${base.verbosity} → ${scolded.next.verbosity.toFixed(3)}`)
  check('被否定 → 更认真', scolded.next.diligence > base.diligence, `${base.diligence} → ${scolded.next.diligence.toFixed(3)}`)
  check('这次评估确实推动了参数', scolded.changes.length > 0, `changes=${scolded.changes.length}`)
  // ★ 0.2.0：单次上限由 2% 放到 6% —— 旧值 396 轮几乎没动过（主人反馈）
  check('单次变化不超过 6%', scolded.changes.every((item) => Math.abs(item.to - item.from) <= 0.061))

  const praised = evaluate(base, { warm: 5, praise: 3, turnsSeen: 10 }, { turns: 10 })
  check('被夸 → 更愿意撒娇', praised.next.clinginess > base.clinginess, `${base.clinginess} → ${praised.next.clinginess.toFixed(3)}`)

  const safety = evaluate(base, { warm: 3, safetyTouched: 1, turnsSeen: 2 }, { turns: 2 })
  check('安全话题不计入演化', safety.skipped === 'safety' && safety.changes.length === 0)

  // 边界：反复往同一方向推，永远不越界
  let probe = { ...base }
  for (let i = 0; i < 200; i += 1) {
    probe = evaluate(probe, { asksShort: 9, turnsSeen: 5 }, { turns: 5 }).next
  }
  check(
    '话量不会跌破下限',
    probe.verbosity >= BOUNDS.verbosity[0] - 1e-9,
    `verbosity=${probe.verbosity.toFixed(4)} lo=${BOUNDS.verbosity[0]}`,
  )
  check('所有参数都在边界内', snapshotView(probe).every((item) => item.value >= item.lo && item.value <= item.hi))
}

// ---------------------------------------------------------------------------
section('render：注入文本可用')

{
  const state = createState({ dir: path.join(tmpRoot, 'state'), log: () => {} })
  state.load()
  const memory = createMemory({ dir: path.join(tmpRoot, 'memory'), log: () => {} })
  memory.load()

  const derived = state.derive('session-A')
  const live = renderLive({
    derived: { ...derived, progress: '第 3 轮 / 12 步 · 工具 5 次' },
    soul: state.soul(),
    digest: memory.digest({ chars: 600 }),
    options: { intensity: 1, showMemory: true },
  })
  check('状态块非空', typeof live === 'string' && live.length > 120, `len=${live.length}`)
  check('状态块含关系与心情', live.includes('亲近') && live.includes('心情'))
  check('状态块含记忆小节', live.includes('我记得的事'))

  const persona = renderPersona({ traitsView: snapshotView(state.getTraits()), soul: state.soul() })
  check('人格段非空', persona.length > 80 && persona.includes('说话方式'))
  check('人格段声明表达层边界', persona.includes('照原样'))

  const trace = renderTrace(derived, snapshotView(state.getTraits()))
  check('一行摘要可用', trace.includes('亲近') && trace.includes('信任'))
}

// ---------------------------------------------------------------------------
section('summarize：模型输出解析')

{
  const fenced = parsePayload('好的，结果如下：\n```json\n{"items":[{"kind":"preference","subject":"称呼","text":"主人叫我大肥鱼","importance":0.9,"confidence":0.9,"from":"user"}],"mood":"轻松"}\n```\n以上。')
  check('能剥掉 markdown 代码块', fenced !== null && fenced.items.length === 1 && fenced.items[0].from === 'user')

  const bare = parsePayload('{"items":[{"kind":"fact","text":"显卡是 5060","importance":7,"confidence":9}],"mood":""}')
  check('裸 JSON 能解析', bare !== null && bare.items.length === 1)
  check('10 分制会被换算', bare.items[0].importance === 0.7 && bare.items[0].confidence === 0.9, `imp=${bare.items[0].importance} conf=${bare.items[0].confidence}`)

  check('胡话返回 null', parsePayload('我不知道该说什么') === null)

  const transcript = buildTranscript(
    [
      { role: 'user', text: '记住我不用拼音输入法' },
      { role: 'assistant', text: '好的主人' },
    ],
    { chars: 1000 },
  )
  check('对话能拼成文本', transcript.includes('主人：') && transcript.includes('助手：'))
}

// ---------------------------------------------------------------------------
section('persona：人格库（从 dsh-soul 并过来的能力）')

{
  const dir = path.join(tmpRoot, 'persona')
  fs.mkdirSync(dir, { recursive: true })

  // ★ 0.3.0：内置**五套**预设，默认**未选**
  const store = createPersonaStore({ dir, log: () => {} })
  store.load()
  check(
    '没有文件时内置五套人格',
    store.list().length === 5 &&
      store.list().some((item) => item.id === 'dafeiyu') &&
      store.list().some((item) => item.id === 'ojingjing') &&
      store.list().some((item) => item.id === 'yinhuifeiyu') &&
      store.list().some((item) => item.id === 'shenjing') &&
      store.list().some((item) => item.id === 'pujing'),
    `实际 ${store.list().length} 套：${store.list().map((i) => i.name).join('/')}`,
  )
  check('默认未选（等主人第一次挑）', store.selected() === '' && store.locked() === false)
  check('未选时人格文本为空', store.text() === '')

  // 模拟从 dsh-soul 迁移过来的老文件（没有 lockedAt）
  fs.writeFileSync(
    path.join(dir, 'personas.json'),
    JSON.stringify({
      selected: 'whale',
      items: [
        { id: 'whale', name: '鲸鲸', description: '测试用', text: '## 人设\n自称本鲸' },
        { id: 'pujing', name: '普鲸', description: '', text: '直接给结论。' },
      ],
    }),
    'utf8',
  )

  const reloaded = createPersonaStore({ dir, log: () => {} })
  reloaded.load()
  check('文件里的人格被读出来', reloaded.list().some((item) => item.id === 'whale'))
  check('选中的是文件里那个', reloaded.selected() === 'whale')
  check('人格文本能取到', reloaded.text().includes('自称本鲸'), reloaded.text())
  check(
    '内置两套仍然保留',
    reloaded.list().some((item) => item.id === 'pujing') && reloaded.list().some((item) => item.id === 'dafeiyu'),
  )

  // ★ 0.2.0：老文件没有 lockedAt → 视为「早就选过了」，自动补锁
  check('老文件自动补上锁定', reloaded.locked() === true)

  const switched = reloaded.select('pujing')
  check('锁定后不能再切人格', switched.ok === false, switched.reason ?? '')
  check('锁定后文本保持原样', reloaded.text().includes('自称本鲸'), reloaded.text())

  const persisted = createPersonaStore({ dir, log: () => {} })
  persisted.load()
  check('锁定状态写进了文件', persisted.selected() === 'whale' && persisted.locked() === true)

  check('切到不存在的人格会被拒', persisted.select('nope').ok === false)

  // 坏文件不能让插件起不来
  fs.writeFileSync(path.join(dir, 'personas.json'), '{这不是 JSON', 'utf8')
  const broken = createPersonaStore({ dir, log: () => {} })
  broken.load()
  check('文件坏了也能起来（回落未选 + 内置五套）', broken.selected() === '' && broken.list().length === 5)
}

// ---------------------------------------------------------------------------
section('memory：隐私闸门（写入前拦截，不靠事后清理）')

{
  const dir = path.join(tmpRoot, 'privacy')
  fs.mkdirSync(dir, { recursive: true })
  const memory = createMemory({ dir, log: () => {} })
  memory.load()

  const leaked = memory.mergeBatch([
    { kind: 'fact', subject: '姓名', text: '主人名字是张三', importance: 0.9, confidence: 0.95 },
    { kind: 'fact', subject: '服务器', text: '那台机器 192.168.1.10 上跑着服务', importance: 0.8, confidence: 0.9 },
    { kind: 'fact', subject: '密钥', text: '用这个 sk-abcdefghijklmnop 调用', importance: 0.8, confidence: 0.9 },
    { kind: 'fact', subject: '令牌', text: '令牌是 0123456789abcdef0123456789abcdef', importance: 0.8, confidence: 0.9 },
  ])
  check(
    '内含真名 / IP / 密钥 / 令牌的条目全部被拦',
    leaked.added.length === 0 && leaked.rejected.length === 4,
    `added=${leaked.added.length} rejected=${leaked.rejected.length}`,
  )

  const asRule = memory.mergeBatch([
    { kind: 'preference', subject: '真名保护', text: '绝不允许自己的真名出现在任何文件里，发现即清除', importance: 0.9, confidence: 0.95 },
  ])
  check('「规则」不被误拦（只拦值、不拦规则）', asRule.added.length === 1, `added=${asRule.added.length}`)

  check('隐私条目确实没进库', memory.stats().live === 1, `live=${memory.stats().live}`)
  check('sensitiveReason 能给原因名', sensitiveReason({ text: '主人名字是张三' }) === '人名')
  check('正常内容不误报', sensitiveReason({ text: '主人喜欢先给结论' }) === null)
}

// ---------------------------------------------------------------------------
console.log(`\n结果：${pass} 通过 / ${fail} 失败`)
fs.rmSync(tmpRoot, { recursive: true, force: true })
process.exit(fail === 0 ? 0 : 1)
