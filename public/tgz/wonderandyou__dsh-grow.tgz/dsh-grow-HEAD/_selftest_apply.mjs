/**
 * _selftest_apply.mjs —— 集成自测：模拟 DSH 运行时把 apply() 整个跑一遍
 *
 * 纯逻辑测试（_selftest_v2.mjs）只验算法，验不出「插件到底能不能装起来」。
 * 这个脚本造一个假的 ctx（事件总线 / 提示词注册表 / webServer / tools / llm），
 * 把 index.js 的 apply() 完整跑一遍，然后：
 *
 *   1. 检查有没有抛错
 *   2. 检查注入段落是否注册、渲染文本是否合理
 *   3. 模拟 16 轮对话，检查人格漂移、日记触发、日记落盘
 *   4. 直接调用 /grow/* 路由，检查返回结构（这就是面板拿到的数据）
 *
 * 数据目录指到临时目录，绝不碰主人的 ~/.dsh/grow。
 *
 *   node _selftest_apply.mjs
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert'

// ★ 必须在 import 插件之前改 USERPROFILE —— 插件的数据目录来自 os.homedir()
const sandboxHome = fs.mkdtempSync(path.join(os.tmpdir(), 'grow-apply-'))
const realHome = os.homedir()
process.env.USERPROFILE = sandboxHome
process.env.HOME = sandboxHome

const { apply } = await import('./lib/index.js')

let passed = 0
let failed = 0

function check(name, fn) {
  try {
    const detail = fn()
    passed += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    failed += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

async function checkAsync(name, fn) {
  try {
    const detail = await fn()
    passed += 1
    console.log(`[PASS] ${name}${detail === undefined ? '' : `  → ${detail}`}`)
  } catch (error) {
    failed += 1
    console.log(`[FAIL] ${name}\n       ${String(error?.message ?? error)}`)
  }
}

// ---------------------------------------------------------------------------
// 假的 DSH 运行时
// ---------------------------------------------------------------------------

const logLines = []
function makeLogger() {
  const push = (level) => (message) => logLines.push(`${level}: ${message}`)
  return { debug: push('debug'), info: push('info'), warn: push('warn'), error: push('error') }
}

const sections = []
const contexts = []
const routes = new Map()
const listeners = new Map()
const registeredTools = new Map()
const effects = []

let llmReply = ''
let llmCalls = 0

const mockLlm = {
  listProviders: () => [{ id: 'deepseek-official' }, { id: 'other' }],
  listModels: async () => [{ id: 'deepseek-chat' }],
  stream: (options) => {
    llmCalls += 1
    const text = llmReply
    return {
      async *[Symbol.asyncIterator]() {
        // 分块吐，模拟真实流
        for (let i = 0; i < text.length; i += 40) {
          yield { type: 'text-delta', text: text.slice(i, i + 40) }
        }
        yield { type: 'finish', reason: { kind: 'stop' } }
      },
    }
  },
}

const mockTools = {
  register: (definition) => {
    registeredTools.set(definition.name, definition)
    return () => registeredTools.delete(definition.name)
  },
  schemas: () => [],
  execute: async () => ({ content: [] }),
}

const mockWebServer = {
  register: ({ kind, path: routePath, handler }) => {
    routes.set(routePath, { kind, handler })
    return () => routes.delete(routePath)
  },
}

/**
 * 假的 agent：状态段（grow:live）是挂在**会话**上的，不是全局的。
 * apply() 会遍历 ctx.get('agents').list() 补挂已有会话 —— 这里给一个，
 * 不然测不到状态段。
 */
const mockAgent = {
  id: 'selftest-session',
  ctx: {
    effect(fn) {
      const dispose = fn()
      effects.push(dispose)
      return dispose
    },
    systemPrompt: {
      context(definition) {
        contexts.push(definition)
        return () => {}
      },
    },
  },
}

const ctx = {
  logger: makeLogger(),
  on(type, fn) {
    if (!listeners.has(type)) listeners.set(type, [])
    listeners.get(type).push(fn)
    return () => {}
  },
  effect(fn, label) {
    const dispose = fn()
    effects.push(dispose)
    return dispose
  },
  inject(deps, fn) {
    if (deps.includes('tools')) fn({ tools: mockTools, effect: ctx.effect })
    else if (deps.includes('webServer')) fn({ webServer: mockWebServer, effect: ctx.effect })
    else fn({ effect: ctx.effect })
  },
  get(name) {
    if (name === 'llm') return mockLlm
    if (name === 'agents') return { list: () => [mockAgent] }
    return undefined
  },
  systemPrompt: {
    context(definition) {
      contexts.push(definition)
      return () => {}
    },
    section(definition) {
      sections.push(definition)
      return () => {}
    },
  },
}

// ---------------------------------------------------------------------------
// 路由调用辅助
// ---------------------------------------------------------------------------

function callRoute(routePath, query = '', body = undefined, headers = {}) {
  return new Promise((resolve, reject) => {
    const route = routes.get(routePath)
    if (route === undefined) return reject(new Error(`路由没注册：${routePath}`))
    const timer = setTimeout(() => reject(new Error(`路由超时：${routePath}`)), 3000)
    const res = {
      code: 200,
      writeHead(code) {
        this.code = code
        return this
      },
      end(payload) {
        clearTimeout(timer)
        try {
          resolve({ code: this.code, body: JSON.parse(String(payload)) })
        } catch (error) {
          reject(error)
        }
      },
    }
    const extra = {}
    for (const [key, value] of Object.entries(headers)) {
      if (key.startsWith('x-test-')) continue
      extra[key.toLowerCase()] = value
    }
    const req = {
      socket: { remoteAddress: headers['x-test-remote'] ?? '127.0.0.1' },
      headers: { host: headers['x-test-host'] ?? '127.0.0.1:56665', ...extra },
      url: routePath + (query === '' ? '' : `?${query}`),
      method: body === undefined ? 'GET' : 'POST',
      on(event, fn) {
        if (event === 'data' && body !== undefined) fn(Buffer.from(JSON.stringify(body)))
        if (event === 'end') setTimeout(fn, 0)
      },
      destroy() {},
    }
    try {
      Promise.resolve(route.handler(req, res)).catch(reject)
    } catch (error) {
      reject(error)
    }
  })
}

function emit(type, data, seq) {
  const list = listeners.get('session/event') ?? []
  for (const fn of list) fn({ id: 'selftest-session' }, { type, data, seq })
}

/** 模拟一轮完整对话。 */
function runTurn(index, userText, replyText) {
  const base = index * 10
  emit('turn/start', undefined, base + 1)
  emit('user/message', { content: userText }, base + 2)
  emit('assistant/message', { message: { content: [{ type: 'text', text: replyText }] } }, base + 3)
  emit('turn/end', { reason: { kind: 'completed' } }, base + 4)
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

// ---------------------------------------------------------------------------
// 开跑
// ---------------------------------------------------------------------------

console.log(`沙箱 HOME：${sandboxHome}`)
console.log('')

let bootError = null
try {
  apply(ctx, {})
} catch (error) {
  bootError = error
}

// ---------------------------------------------------------------------------
// 1. 启动
// ---------------------------------------------------------------------------

check('apply() 不抛错', () => {
  assert.strictEqual(bootError, null, String(bootError?.message ?? bootError))
  return '启动干净'
})

check('启动日志里有启用信息', () => {
  const hit = logLines.find((line) => line.includes('已启用'))
  assert.ok(hit !== undefined, `日志里没有「已启用」：\n${logLines.join('\n')}`)
  return hit.slice(0, 90)
})

check('提示词段落注册齐了：人格 / 说话方式 / 状态', () => {
  const names = sections.map((item) => item.name)
  assert.ok(names.includes('grow:persona'), `缺人格段，现有：${names.join(',')}`)
  assert.ok(names.includes('grow:style'), `缺说话方式段，现有：${names.join(',')}`)
  const ctxNames = contexts.map((item) => item.name)
  assert.ok(ctxNames.includes('grow:live'), `缺状态段，现有：${ctxNames.join(',')}`)
  return `${names.join(' + ')} + ${ctxNames.join(' + ')}`
})

check('工具注册齐了 5 个', () => {
  const names = [...registeredTools.keys()].sort()
  for (const wanted of ['grow_remember', 'grow_recall', 'grow_forget', 'grow_feel', 'grow_status']) {
    assert.ok(names.includes(wanted), `缺工具 ${wanted}`)
  }
  return names.join(' / ')
})

check('面板路由注册齐了', () => {
  const wanted = ['/grow/status.json', '/grow/memory.json', '/grow/history.json', '/grow/personas.json', '/grow/diary.json', '/grow/act']
  for (const routePath of wanted) {
    assert.ok(routes.has(routePath), `缺路由 ${routePath}`)
  }
  return wanted.join(' ')
})

// ---------------------------------------------------------------------------
// 2. 渲染文本
// ---------------------------------------------------------------------------

check('说话方式段渲染正常', () => {
  const section = sections.find((item) => item.name === 'grow:style')
  const text = section.text()
  assert.ok(text.includes('此刻的说话方式'), '标题丢了')
  assert.ok(text.includes('撒娇'), '缺撒娇')
  assert.ok(text.includes('照原样'), '缺「表达层不影响事实」那句')
  for (const label of ['撒娇', '话量', '幽默', '依赖', '认真', '情绪外化']) {
    assert.ok(text.includes(label), `缺 ${label}`)
  }
  return `${text.length} 字`
})

check('人格段：还没选的时候是空的', () => {
  const section = sections.find((item) => item.name === 'grow:persona')
  const text = section.text()
  assert.strictEqual(text, '', `没选人格却有内容：${text.slice(0, 40)}`)
  return '空（未选）'
})

check('状态段渲染正常', () => {
  const context = contexts.find((item) => item.name === 'grow:live')
  const text = context.text()
  assert.ok(text.includes('此刻的状态'), '标题丢了')
  assert.ok(text.includes('亲近'), '缺亲近')
  return `${text.length} 字`
})

// ---------------------------------------------------------------------------
// 3. 买人格（首次选择 → 锁定）
// ---------------------------------------------------------------------------

await checkAsync('第一次打开：人格未锁定，可以选', async () => {
  const res = await callRoute('/grow/personas.json')
  assert.strictEqual(res.body.ok, true)
  assert.strictEqual(res.body.locked, false, '一上来就锁定了？')
  assert.ok(res.body.items.length >= 2, `内置只有 ${res.body.items.length} 套`)
  return `${res.body.items.map((i) => i.name).join(' / ')}`
})

// ★ 0.2.1：写接口要令牌，先从 status.json 拿（和面板行为一致）
let panelToken = ''
await checkAsync('status.json 带出写接口令牌', async () => {
  const res = await callRoute('/grow/status.json')
  panelToken = String(res.body.panelToken ?? '')
  assert.ok(panelToken.length >= 8, `令牌异常：${panelToken}`)
  return `${panelToken.slice(0, 8)}…（${panelToken.length} 字符）`
})

await checkAsync('CSRF：不带令牌的写请求被拒', async () => {
  const res = await callRoute('/grow/act', '', { action: 'selectPersona', id: 'dafeiyu' })
  assert.strictEqual(res.code, 403, `居然放行了：${res.code}`)
  assert.strictEqual(res.body.ok, false)
  return String(res.body.reason).slice(0, 40)
})

await checkAsync('CSRF：错误令牌被拒', async () => {
  const res = await callRoute('/grow/act', '', { action: 'selectPersona', id: 'dafeiyu' }, { 'x-grow-token': 'wrong-token-xxxx' })
  assert.strictEqual(res.code, 403, `错误令牌居然放行：${res.code}`)
  return String(res.body.reason).slice(0, 40)
})

await checkAsync('CSRF：跨站 Origin 被拒', async () => {
  const res = await callRoute(
    '/grow/act',
    '',
    { action: 'selectPersona', id: 'dafeiyu' },
    { 'x-grow-token': panelToken, origin: 'https://evil.example.com' },
  )
  assert.strictEqual(res.code, 403, `跨站 Origin 居然放行：${res.code}`)
  return String(res.body.reason).slice(0, 40)
})

await checkAsync('选定「大肥鱼」→ 立刻锁定', async () => {
  const pick = await callRoute('/grow/act', '', { action: 'selectPersona', id: 'dafeiyu' }, { 'x-grow-token': panelToken })
  assert.strictEqual(pick.body.ok, true, `选择失败：${pick.body.reason}`)
  const after = await callRoute('/grow/personas.json')
  assert.strictEqual(after.body.locked, true, '选完没锁')
  assert.strictEqual(after.body.selected, 'dafeiyu')
  return `锁定于 ${new Date(after.body.lockedAt).toLocaleString('zh-CN')}`
})

await checkAsync('再想换人格 → 被拒绝', async () => {
  const again = await callRoute('/grow/act', '', { action: 'selectPersona', id: 'pujing' }, { 'x-grow-token': panelToken })
  assert.strictEqual(again.body.ok, false, '居然还能换')
  assert.ok(String(again.body.reason).includes('不能'), `拒绝理由不对：${again.body.reason}`)
  return again.body.reason.slice(0, 40) + '…'
})

await checkAsync('参数改不了（setTrait 已撤）', async () => {
  const res = await callRoute('/grow/act', '', { action: 'setTrait', key: 'clinginess', value: 0.9 }, { 'x-grow-token': panelToken })
  assert.strictEqual(res.body.ok, false, 'setTrait 居然还能用')
  return res.body.reason
})

await checkAsync('回滚也撤了（rollback 已删）', async () => {
  const res = await callRoute('/grow/act', '', { action: 'rollback', index: 0 }, { 'x-grow-token': panelToken })
  assert.strictEqual(res.body.ok, false, 'rollback 居然还能用')
  return res.body.reason
})

// ---------------------------------------------------------------------------
// 3b. grow_remember 的拒绝路径（外部审查边界项）
// ---------------------------------------------------------------------------

await checkAsync('grow_remember：被隐私闸门拒绝时不再回「记下了」', async () => {
  const tool = registeredTools.get('grow_remember')
  assert.ok(tool !== undefined, '工具没注册')
  const result = await tool.execute({ text: 'password=Hunter2xyz', kind: 'fact' })
  assert.strictEqual(result.ok, false, `被拒了却回成功：${result.text}`)
  assert.ok(!String(result.text).includes('记下了'), `文案还在骗人：${result.text}`)
  assert.ok(String(result.text).includes('没记'), `文案不对：${result.text}`)
  return result.text.slice(0, 40)
})

await checkAsync('grow_remember：正常内容照常记', async () => {
  const tool = registeredTools.get('grow_remember')
  const result = await tool.execute({ text: '主人偏好先给结论后给理由', kind: 'preference', subject: '回复顺序' })
  assert.strictEqual(result.ok, true, `正常内容被误拒：${result.text}`)
  return result.text
})

check('人格段现在有内容了', () => {
  const section = sections.find((item) => item.name === 'grow:persona')
  const text = section.text()
  assert.ok(text.includes('大肥鱼'), '人格文本没接上')
  return `${text.length} 字`
})

// ---------------------------------------------------------------------------
// 4. 跑 12 轮对话：漂移 + 日记
// ---------------------------------------------------------------------------

llmReply = [
  '今天主人一上来就让我改那个成长插件，说用了这么久根本没看出我变过。',
  '我当时有点心虚，因为确实——我翻了翻自己的参数，好几个数字从装好那天到现在一动没动。',
  '查下来是算法太保守了，每二十轮才动一点，还被门限吃掉了。',
  '改完重跑测试，十八项全过，那一下是真的松一口气。',
  '主人又补了一句要日记本，我就把日记也做上了。',
  '现在能自己写日记了，感觉有点像真的在过日子。',
].join('')

console.log('')
console.log('— 模拟 12 轮对话（全被夸，看参数会不会动）—')

for (let i = 0; i < 12; i += 1) {
  runTurn(i, '太棒了，这个完美，谢谢你辛苦啦', '收到，我接着弄。')
}

await sleep(1500)

await checkAsync('12 轮之后：状态接口能拿到漂移结果', async () => {
  const res = await callRoute('/grow/status.json')
  assert.strictEqual(res.body.ok, true)
  assert.ok(Array.isArray(res.body.traits) && res.body.traits.length === 6, '参数列表不对')
  return res.body.traits.map((t) => `${t.label}${t.value.toFixed(2)}`).join(' ')
})

check('12 轮之后：参数真的动了（不是 0.60 纹丝不动）', () => {
  const section = sections.find((item) => item.name === 'grow:style')
  const text = section.text()
  const match = text.match(/撒娇[^\n]*?(\d\.\d{2})/)
  assert.ok(match !== null, '解析不出撒娇值')
  const value = Number(match[1])
  assert.ok(Math.abs(value - 0.6) > 0.01, `撒娇还是 ${value}，没动`)
  return `撒娇 ${match[1]}`
})

check('12 轮之后：注入里出现了「刚才调整过」', () => {
  const section = sections.find((item) => item.name === 'grow:style')
  const text = section.text()
  assert.ok(text.includes('刚才调整过'), `注入文本里没有调整记录：\n${text}`)
  const line = text.split('\n').find((l) => l.includes('刚才调整过')) ?? ''
  return line.slice(0, 80)
})

await checkAsync('日记：12 轮里至少写了一篇', async () => {
  const res = await callRoute('/grow/diary.json', 'limit=20')
  assert.strictEqual(res.body.ok, true)
  assert.ok(res.body.items.length >= 1, `一篇都没有（12 轮里有 1~2 次该写）`)
  const first = res.body.items[0]
  assert.ok(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(first.stamp), `时间戳格式不对：${first.stamp}`)
  assert.ok(first.text.length >= 80, `日记太短：${first.text.length}`)
  return `${res.body.items.length} 篇 · 最新 ${first.stamp} · ${first.text.length} 字`
})

await checkAsync('日记：正文是第一人称日记，不是流水账', async () => {
  const res = await callRoute('/grow/diary.json', 'limit=5')
  const first = res.body.items[0]
  assert.ok(first.source === 'model', `这篇是兜底的（${first.source}），模型没调通`)
  assert.ok(!first.text.includes('主人：'), '把对话原文贴进去了')
  assert.ok(!first.text.includes('助手：'), '把对话原文贴进去了')
  return `source=${first.source}`
})

await checkAsync('日记：模型确实被调用过', async () => {
  assert.ok(llmCalls >= 1, `模型一次都没调：${llmCalls}`)
  return `${llmCalls} 次调用`
})

await checkAsync('P1-5 日记：各篇覆盖的轮次不重叠（并发没写出重复篇）', async () => {
  const res = await callRoute('/grow/diary.json', 'limit=50')
  // 接口返回的是最新在前，翻回时间正序
  const items = (res.body.items ?? []).slice().reverse()
  assert.ok(items.length >= 1, '一篇都没有')
  for (let i = 1; i < items.length; i += 1) {
    const prev = items[i - 1]
    const now = items[i]
    assert.ok(
      now.turnsFrom > prev.turnsTo,
      `第 ${i} 篇和上一篇轮次重叠：[${prev.turnsFrom}~${prev.turnsTo}] vs [${now.turnsFrom}~${now.turnsTo}]`,
    )
  }
  return `${items.length} 篇，轮次区间互不重叠`
})

await checkAsync('P1-5 日记：篇数与状态里的 count 一致', async () => {
  const status = await callRoute('/grow/status.json')
  const list = await callRoute('/grow/diary.json', 'limit=400')
  assert.strictEqual(
    status.body.diary.stats.count,
    list.body.items.length,
    `状态说 ${status.body.diary.stats.count} 篇，实际 ${list.body.items.length} 篇`,
  )
  return `${status.body.diary.stats.count} 篇对得上`
})

// ---------------------------------------------------------------------------
// 5. 面板数据完整性
// ---------------------------------------------------------------------------

await checkAsync('status.json：面板要的字段一个不缺', async () => {
  const res = await callRoute('/grow/status.json')
  const body = res.body
  for (const key of ['soul', 'traits', 'stats', 'diary', 'persona', 'drift']) {
    assert.ok(body[key] !== undefined, `缺字段 ${key}`)
  }
  assert.ok(body.soul.closeness !== undefined, 'soul 里缺 closeness')
  assert.ok(body.diary.stats !== undefined, 'diary 里缺 stats')
  assert.ok(body.persona.locked === true, 'persona 没锁')
  return `soul${Object.keys(body.soul).length}项 / traits${body.traits.length}项 / diary${body.diary.stats.count}篇`
})

await checkAsync('status.json：日记节奏字段齐全', async () => {
  const res = await callRoute('/grow/status.json')
  const d = res.body.diary
  for (const key of ['turnsSince', 'nextGap', 'remaining', 'due', 'count']) {
    assert.ok(d[key] !== undefined, `缺 ${key}`)
  }
  assert.ok(d.nextGap >= 5 && d.nextGap <= 10, `间隔越界：${d.nextGap}`)
  return `已过 ${d.turnsSince} 轮 / 下篇还要 ${d.remaining} 轮`
})

await checkAsync('非本机请求一律拒绝', async () => {
  const route = routes.get('/grow/status.json')
  const result = await new Promise((resolve) => {
    const res = {
      code: 200,
      writeHead(code) {
        this.code = code
        return this
      },
      end(payload) {
        resolve({ code: this.code, body: JSON.parse(String(payload)) })
      },
    }
    route.handler(
      { socket: { remoteAddress: '10.1.2.3' }, headers: { host: 'evil.example.com' }, url: '/grow/status.json', on() {}, destroy() {} },
      res,
    )
  })
  assert.strictEqual(result.code, 403, `外网请求居然过了：${result.code}`)
  return 'status 403'
})

// ---------------------------------------------------------------------------

console.log('')
console.log(`通过 ${passed} / 失败 ${failed}`)
if (failed > 0) {
  console.log('')
  console.log('— 最近日志 —')
  for (const line of logLines.slice(-25)) console.log(`  ${line}`)
}

process.env.USERPROFILE = realHome
process.env.HOME = realHome
try {
  fs.rmSync(sandboxHome, { recursive: true, force: true })
} catch {
  // 删不掉不影响结论
}
process.exit(failed === 0 ? 0 : 1)
