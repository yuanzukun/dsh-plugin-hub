/**
 * Runs every test file in its own process and prints a summary.
 * Exit code is non-zero when any test fails.
 * Run: node tests/run-all.mjs
 */
import { spawn } from 'node:child_process'
import { mkdtempSync as mkdtempBackup } from 'node:fs'
import { tmpdir as tmpdirBackup } from 'node:os'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const here = dirname(fileURLToPath(import.meta.url))
const files = [
  'test-timeline.mjs',
  'test-keys-dotenv.mjs', 'test-env-backup.mjs',
  'test-retry-status.mjs',
  'test-nonascii-home.mjs',
  'test-macos.mjs',
  'test-no-double-retain.mjs',
  'test-sidebar-card.mjs',
  'test-fixes.mjs',
  'test-config-bank.mjs',
  'test-default-bank-migration.mjs', 'test-new-bank-join.mjs', 'test-restart-keepalive.mjs',
  'test-lifecycle.mjs',
  'test-client-http.mjs',
  'test-hooks.mjs',
  'test-panel-local.mjs',
  'test-panel-v2.mjs',
  'test-dotenv-deploy.mjs', 'test-sidebar.mjs',
  'test-v011.mjs', 'test-v012.mjs', 'test-llmprobe.mjs', 'test-v013.mjs', 'test-logfiles.mjs', 'test-banknames.mjs', 'test-retain-content.mjs', 'test-v014.mjs',
  'test-dimension.mjs', 'test-broken-python.mjs', 'test-childenv-embhealth.mjs', 'test-log-false-positive.mjs', 'test-bank-scope-migration.mjs', 'test-setup-durable.mjs',
  'test-integration.mjs',
  'test-e2e-banks.mjs'
]

function runOne(file) {
  return new Promise((resolve) => {
    // Keep the plugin.env backup (lib/dotenv.js) out of the real home during tests.
    const env = { ...process.env, DSH_HINDSIGHT_ENV_BACKUP: join(mkdtempBackup(join(tmpdirBackup(), 'hs-envbak-')), 'plugin.env') }
    const child = spawn(process.execPath, [join(here, file)], { stdio: ['ignore', 'pipe', 'pipe'], env })
    let out = ''
    child.stdout.on('data', (chunk) => {
      out += chunk
    })
    child.stderr.on('data', (chunk) => {
      out += chunk
    })
    child.on('close', (code) => resolve({ file, code, out }))
  })
}

const results = []
for (const file of files) {
  const result = await runOne(file)
  results.push(result)
  const status = result.code === 0 ? 'OK  ' : 'FAIL'
  const passes = (result.out.match(/^PASS /gm) || []).length
  const skips = (result.out.match(/^SKIP /gm) || []).length
  console.log(`${status} ${file.padEnd(24)} ${passes} pass${skips ? `, ${skips} skip` : ''}`)
  if (result.code !== 0) {
    console.log(result.out.split('\n').slice(-40).join('\n'))
  }
}

const failed = results.filter((r) => r.code !== 0)
console.log(`\n${results.length - failed.length}/${results.length} test files passed`)
process.exit(failed.length === 0 ? 0 : 1)
