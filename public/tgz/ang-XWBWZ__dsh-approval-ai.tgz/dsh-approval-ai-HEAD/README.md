# @llangtop/dsh-approval-ai

English | [中文](README.zh.md)

AI approval answerer for `approval/request`. DSH creates and routes the approval request; this plugin only answers that already-created request with a minimal `ctx.llm` assessment. It adds no path, workspace, shell, sandbox, or risk trigger of its own. The default route is provider `deepseek-official` with model `deepseek-v4-flash`; the adapter owns credentials and provider protocol.

## Configuration

```yaml
- id: approval-ai
  name: '@llangtop/dsh-approval-ai'
  config:
    provider: deepseek-official
    model: deepseek-v4-flash
    mode: ai-only
    currentPath: /workspace/project
    projectArchitecture: 'Configuration-supplied summary; the plugin never reads project files.'
    implementationArchitecture: 'Approval policy plugin over approval/request and ctx.llm.'
    agentsMd: 'Configuration-supplied guidance; the plugin never reads AGENTS.md.'
    securityApprovalPrompt: 'Assess only this approval request; do not read files or call tools.'
    timeoutMs: 3000
    failClosed: true
```

`mode` is `ai-only`, `ai-then-human`, or `human-only`. The plugin receives every approval request that reaches its listener; it does not decide whether an approval request should exist. `human-only` delegates every request. `ai-only` maps valid `allow` assessments to `allowed-once`; `deny`, high/critical risk, review, malformed output, missing routes, cancellation, timeout, and provider errors fail closed. `ai-then-human` maps `review` to the configured `reviewOutcome` because listener order is not a priority mechanism.

## Page operations

In the Web composition, the client bundle contributes a card to the native settings page and the host registers the `approval-ai` settings namespace. The card can be used at `Settings → Plugins → Plugin configuration → AI Approval` when the DSH Web settings API exposes that namespace; `Save` writes the namespace, `Discard` drops page-local edits, and `Reset` removes user overrides. Version `0.1.0-rc.5` did not include the client card, so install `0.1.0-rc.6` or later and restart Web after updating the profile.

The current DSH Web host filters settings namespaces through a fixed allowlist before `/api/settings.describe` responds. `approval-ai` is registered by this plugin but is not currently in that host allowlist, so the expected result can be that the package is installed and the client bundle is loaded while the settings card is absent. This is a host API exposure limitation, not a slot-order, npm-scope, or client-export problem. A third-party package cannot add a namespace to the fixed host allowlist by itself; use `/approval-ai` below until the host provides an extensible settings registration mechanism.

The plugin registers the native DSH `/approval-ai` slash command. Open the Web `/` command menu or type a command directly; changes are written to the `approval-ai` settings namespace and take effect live, so users do not need to edit `cordis.patch.yml`:

```text
/approval-ai                 Show provider, model, mode, and failClosed
/approval-ai enable          Enable automatic AI approval (ai-only)
/approval-ai disable         Disable AI approval and delegate to a human (human-only)
/approval-ai mode ai-only
/approval-ai mode ai-then-human
/approval-ai mode human-only
/approval-ai provider <id>   Select a registered LLM provider route
/approval-ai model <id>      Select a model ID on that route
/approval-ai reset           Clear this plugin's user overrides
```

`provider` must be a route currently registered by DSH, and `model` must be served by that route. `disable` does not unload the plugin; it switches it to `human-only` so DSH's existing human approval page handles requests. Command results are shown directly in the session and are not sent to the model.

The model receives the DSH approval request fields plus explicitly configured background: the current path, architecture summaries, mounted `AGENTS.md` guidance, and the security-approval prompt. These are configuration values, not files the plugin reads. The plugin never reads the project, session history, tool schemas, credentials, or the main system prompt, and does not write the model request or response to the agent session. Arguments and response reasons are byte-bounded and model output is runtime-validated JSON.

## Local development and DSH testing

Run these commands from this repository:

```sh
pnpm install --frozen-lockfile
pnpm run typecheck
pnpm run build
npm pack --dry-run
```

To mount the checkout into a local DSH profile, run the DSH CLI from its own repository and use an absolute path:

```sh
cd /path/to/deepseek-harness
pnpm dsh plugin --profile approval-ai-local add /mnt/data/demo/dsh插件/approval-ai
pnpm dsh --profile approval-ai-local --dump-config
pnpm dsh --profile approval-ai-local
```

The profile should show an `approval-ai` entry inserted beside the existing approval service. The default patch uses provider `deepseek-official`, so the profile must have a working DSH LLM configuration and credentials before an approval request can receive an AI answer. `pnpm dsh plugin --profile <profile> why @llangtop/dsh-approval-ai` proves only that the package is in the profile dependency graph; it does not prove that the patch was applied or that the current Web process loaded the package. Stop and restart `pnpm dsh web` after changing the profile. Remove the local installation with `pnpm dsh plugin --profile approval-ai-local remove @llangtop/dsh-approval-ai`.

To test the exact npm artifact without publishing it, build and pack the repository, then install the generated `.tgz` path with `dsh plugin --profile <name> add /absolute/path/to/package.tgz`.

## Release and installation

The source repository is [github.com/ang-XWBWZ/dsh-approval-ai](https://github.com/ang-XWBWZ/dsh-approval-ai). The public npm package is `@llangtop/dsh-approval-ai`; the current `0.1.0-rc.6` version is a prerelease and should use the `next` dist-tag.

Publish from this repository after logging in with an npm account that can publish the `@llangtop` scope:

```sh
npm login
npm whoami
npm publish --access public --tag next
```

Install the published bundle into a DSH profile:

```sh
cd /path/to/deepseek-harness
pnpm dsh plugin --profile approval-ai add @llangtop/dsh-approval-ai@next
pnpm dsh --profile approval-ai --dump-config
```

`dsh plugin` reads the package's `dsh.bundle.patch` entry, adds the package to the profile, and applies `cordis.patch.yml` during composition. The patch inserts the `approval-ai` row beside DSH's existing approval service; no change to the DSH source tree is required. The package's peer versions target DSH `0.1.0-rc.6`, Cordis `4.0.1`, and Schemastery `3.18.1`.

For a release candidate that is not yet on npm, create a tarball and install that file instead:

```sh
pnpm pack
pnpm dsh plugin --profile approval-ai add /absolute/path/to/llangtop-dsh-approval-ai-0.1.0-rc.6.tgz
```

The GitHub repository is the source and release workspace; npm and a local tarball are the supported runtime distribution paths because `prepack` builds the published `lib/` artifacts.

## Model Experience

### Approval assessment

#### What the model sees

The auxiliary model sees a fixed classifier instruction and a JSON user payload constructed from the already-created DSH approval request. It must return `decision`, `risk`, and `reason`; no tool calls are available. The plugin does not add approval triggers or read project content.

#### Token effect

Each approval request creates one bounded auxiliary request. The request is independent of the main conversation and is not added to the main transcript.

#### KV Cache effect

The auxiliary request does not alter the main conversation cache. Provider adapters may apply their own transport caching.

## Known Limitations and Deferred Work

- No approval-result cache, permanent authorization, or multi-model arbitration is provided. The Web settings card, when exposed by the host settings API, edits only this plugin's four runtime settings; it does not replace DSH's approval interaction page. The `/approval-ai` command remains the supported control surface when the host allowlist hides the card.
- The current `ApprovalRequest` carries tool arguments but not a provider-specific workspace resolver; callers must provide optional context when available.
- A human review handoff is represented by `reviewOutcome`; a separate human answerer remains responsible for interactive handling.
