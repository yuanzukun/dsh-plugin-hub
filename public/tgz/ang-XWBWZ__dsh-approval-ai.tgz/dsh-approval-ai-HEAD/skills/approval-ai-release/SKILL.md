---
name: approval-ai-release
description: Build, publish, install, and verify the third-party @llangtop/dsh-approval-ai package. Use when preparing an npm release, testing a tarball or checkout in a DSH profile, updating the Web profile, or diagnosing a stale Web plugin bundle.
---

# Approval AI release

Release only from the independent checkout containing this skill. Resolve `$PLUGIN_ROOT` to that checkout; resolve `$DSH_ROOT` to the local `deepseek-harness` checkout used for profile commands. Do not publish from or modify the DSH source tree.

## Prepare the artifact

1. Confirm the version in `$PLUGIN_ROOT/package.json` is new and compatible with the DSH rc line. The package version must be changed before publishing because npm versions are immutable.
2. Confirm `exports["./client"]`, `dsh.client`, `cordis.patch.yml`, and the `files` list include both Host and browser artifacts. The package must contain `lib/index.js`, `lib/client.js`, client declarations, and the patch file.
3. Run the release checks:

   ```sh
   cd "$PLUGIN_ROOT"
   pnpm install --frozen-lockfile
   pnpm run typecheck
   pnpm run build
   npm pack --dry-run
   git diff --check
   ```

4. Inspect the dry-run file list. Do not publish if `lib/client.js` or the `skills/` directory is missing.

## Test locally before npm

Build the exact package artifact and install the tarball into the target DSH profile:

```sh
cd "$PLUGIN_ROOT"
pnpm pack

cd "$DSH_ROOT"
pnpm dsh plugin --profile web add "$PLUGIN_ROOT/llangtop-dsh-approval-ai-<version>.tgz"
pnpm dsh plugin --profile web why @llangtop/dsh-approval-ai
pnpm dsh web
```

Stop an existing Web process before starting it again. The client boot graph is composed when the Web process starts, so refreshing a page without restarting the server can continue serving the old plugin roster. In the browser, verify `Settings → Plugins → Plugin configuration → AI Approval`, then test `/approval-ai` and one approval request using a provider route that is actually registered in DSH.

For a checkout-only test, use the absolute plugin directory instead of a tarball:

```sh
pnpm dsh plugin --profile web add "$PLUGIN_ROOT"
```

For an isolated Web smoke test, set a temporary task-specific `DSH_HOME`, install the package into its `web` profile, start `dsh web --port 0`, and inspect the injected `window.__DSH_BOOT__` for `/plugins/@llangtop/dsh-approval-ai/client.js`. Do not alter the user's real `web` profile during an isolated check.

## Publish to npm

Use the user's authenticated npm session; never put a token in a file or command argument:

```sh
cd "$PLUGIN_ROOT"
npm whoami
npm publish --access public --tag next
```

The public package is `@llangtop/dsh-approval-ai`. Use the `next` tag for prereleases. After publishing, verify the registry before updating a profile:

```sh
npm view @llangtop/dsh-approval-ai@next version
npm view @llangtop/dsh-approval-ai dist-tags --json
npm view @llangtop/dsh-approval-ai dist.tarball
```

Install the published version with:

```sh
cd "$DSH_ROOT"
pnpm dsh plugin --profile web add @llangtop/dsh-approval-ai@next
pnpm dsh plugin --profile web why @llangtop/dsh-approval-ai
pnpm dsh web
```

If npm returns `E404` after `npm publish`, inspect `npm whoami`, the package scope, the package version, and the registry. Do not republish the same version or infer success from the local tarball output.

## Report evidence

Report separately: source validation, tarball contents, profile dependency/version, Web boot URL, browser card visibility, and actual approval behavior. A successful profile install proves package resolution only; it does not prove that the browser rendered the card or that the selected provider completed an AI decision.
