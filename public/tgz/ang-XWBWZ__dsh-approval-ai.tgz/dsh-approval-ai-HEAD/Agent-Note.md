# Agent Note: AI approval answerer stays a bounded approval plugin

Status: implemented

## Problem

Approval requests need a configurable model decision without adding provider-specific HTTP code, changing the agent loop, or allowing the approval classifier to inspect the project. Deployments also need to provide stable approval background such as the current path and local architecture guidance.

## Decision

`@llangtop/dsh-approval-ai` is a host-side Cordis plugin mounted beside `dsh-user-approval`. It listens on `approval/request`, applies local hard-deny rules, and calls the configured `ctx.llm` route with `prepareCall()` and `prepared.stream()`. The default model is `deepseek-v4-flash` on the `deepseek-official` provider.

The plugin configuration accepts `currentPath`, project and implementation architecture summaries, mounted `AGENTS.md` guidance, and a security-approval prompt. The default current path is `process.cwd()`. These values are serialized into the bounded assessment request; the plugin does not read project files or `AGENTS.md`. The classifier has no tools, MCP access, agent creation path, or secondary approval path.

The plugin supports `ai-only`, `ai-then-human`, and `human-only`. Invalid model output, missing routes, cancellation, timeout, provider failure, and input/output limit violations fail closed. A valid `allow` with low or medium risk is the only automatic grant, and the result is always `allowed-once`.

## Alternatives considered

**Changing the agent loop** was rejected because approval is already an extensible waterfall and loop changes would couple policy to the core driver.

**Reading architecture files from the plugin** was rejected because approval evaluation must not inspect the project. Deployments provide bounded summaries as configuration instead.

**Implementing a Quick AI client** was rejected because provider protocol, credentials, retries, and transport belong to the existing LLM adapter seam.

**Using listener order for AI/human priority** was rejected because Cordis registration order is not a policy contract; the explicit mode and review outcome own the behavior.

## Consequences

The feature is available to headless and Web compositions through one ordinary plugin row and preserves `approval/asked` and `approval/decided` auditing. Settings can update the plugin namespace live through the standard settings service. The client contributes a native settings card for the four runtime settings, but the current DSH Web settings API filters namespaces through a fixed host allowlist that does not include `approval-ai`; therefore the plugin can be loaded while the card remains absent. This is a host exposure limitation and cannot be fixed by changing the third-party slot order. Web and other command-capable compositions can operate the plugin with `/approval-ai`, which reports status and updates mode, provider, or model without editing YAML. The current approval request carries arguments but does not persist them in the approval audit event. The plugin has no approval-result cache, permanent authorization, or multi-model arbitration.
