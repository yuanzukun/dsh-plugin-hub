/** Package invariant companion; the approval service owns audit pairing. */

import type { Context } from '@deepseek-ai/cordis'
import type { InvariantFailure, InvariantInstaller } from '@deepseek-ai/dsh-invariants'

export const name = 'approval-ai-invariant'
export const inject = ['invariants']
const install: InvariantInstaller = (_ctx: Context, _fail: InvariantFailure) => {
  // No additional durable relation is owned by this answerer.
}
export const apply = (ctx: Context): Promise<() => void> => Promise.resolve(ctx.invariants.register('@llangtop/dsh-approval-ai', install))
