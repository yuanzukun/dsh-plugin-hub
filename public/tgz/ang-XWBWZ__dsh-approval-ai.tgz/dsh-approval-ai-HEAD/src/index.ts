/** AI approval answerer for the `approval/request` waterfall. */

import { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-commands'
import type { CommandResult } from '@deepseek-ai/dsh-commands/types'
import type { ApprovalRequest } from '@deepseek-ai/dsh-user-approval'
import type { Config as ApprovalConfig } from './types.ts'
import { resolveConfig, decide } from './policy.ts'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'

export type { ApprovalAssessment, ApprovalAssessmentInput, ApprovalAiDecision, ApprovalAiMode, ApprovalAiRisk } from './types.ts'
export { parseAssessment } from './output.ts'
export { resolveConfig, decide } from './policy.ts'

export const name = 'approval-ai'
export const inject = ['llm', 'approval']
export const APPROVAL_AI_SETTINGS_NAMESPACE = settingsNamespace('approval-ai')

const MODES = ['ai-only', 'ai-then-human', 'human-only'] as const
type ApprovalMode = typeof MODES[number]

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function statusText(config: ApprovalConfig): string {
  const resolved = resolveConfig(config)
  return `approval-ai: mode=${resolved.mode}, provider=${resolved.provider}, model=${resolved.model}, failClosed=${String(resolved.failClosed)}`
}

function helpText(): string {
  return [
    '/approval-ai — 查看当前 provider、model、mode 和 failClosed',
    '/approval-ai enable — 开启 AI 自动审批（ai-only）',
    '/approval-ai disable — 关闭 AI 审批并交给人工（human-only）',
    '/approval-ai mode <ai-only|ai-then-human|human-only>',
    '/approval-ai provider <provider-id>',
    '/approval-ai model <model-id>',
    '/approval-ai reset — 清除本插件的用户覆盖，恢复组合配置',
  ].join('\n')
}

async function updateSettings(ctx: Context, patch: object, source: () => ApprovalConfig): Promise<CommandResult> {
  const settings = ctx.get('settings')
  if (settings === undefined) return { kind: 'error', text: 'approval-ai: settings service is unavailable' }
  try {
    await settings.update(APPROVAL_AI_SETTINGS_NAMESPACE, patch)
    return { kind: 'success', text: statusText(source()) }
  } catch (error: unknown) {
    return { kind: 'error', text: `approval-ai: ${errorText(error)}` }
  }
}

async function runCommand(ctx: Context, rawInput: string, source: () => ApprovalConfig): Promise<CommandResult> {
  const tokens = rawInput.trim().split(/\s+/u)
  const verb = tokens[0] ?? ''
  const value = tokens.slice(1).join(' ')
  if (verb === '' || verb === 'status') return { kind: 'success', text: statusText(source()) }
  if (verb === 'help') return { kind: 'success', text: helpText() }
  if (verb === 'enable' || verb === 'on') return updateSettings(ctx, { mode: 'ai-only' }, source)
  if (verb === 'disable' || verb === 'off') return updateSettings(ctx, { mode: 'human-only' }, source)
  if (verb === 'reset') {
    const settings = ctx.get('settings')
    if (settings === undefined) return { kind: 'error', text: 'approval-ai: settings service is unavailable' }
    try {
      await settings.replace(APPROVAL_AI_SETTINGS_NAMESPACE, {})
      return { kind: 'success', text: statusText(source()) }
    } catch (error: unknown) {
      return { kind: 'error', text: `approval-ai: ${errorText(error)}` }
    }
  }
  if (verb === 'mode') {
    if (!(MODES as readonly string[]).includes(value)) {
      return { kind: 'error', text: `approval-ai: mode must be one of ${MODES.join(', ')}` }
    }
    return updateSettings(ctx, { mode: value as ApprovalMode }, source)
  }
  if (verb === 'provider' || verb === 'model') {
    if (value.length === 0 || /\s/u.test(value)) {
      return { kind: 'error', text: `approval-ai: ${verb} requires a non-empty id without spaces` }
    }
    return updateSettings(ctx, { [verb]: value }, source)
  }
  return { kind: 'error', text: `approval-ai: unknown operation "${verb}". Use /approval-ai help` }
}

export const apply = (ctx: Context, config: ApprovalConfig = {}): void => {
  let current: () => ApprovalConfig = () => config
  let resolved = resolveConfig(config)
  installSettingsSection(ctx, APPROVAL_AI_SETTINGS_NAMESPACE, Config, config, {
    setSource: (source) => { current = source },
    onChange: () => { resolved = resolveConfig(current()) },
    validate: resolveConfig,
  })
  ctx.inject(['commands'], (commandCtx) => {
    commandCtx.effect(() => commandCtx.commands.register({
      name: 'approval-ai',
      description: 'View and control AI approval settings',
      input: { hint: '[status|enable|disable|mode|provider|model|reset|help]' },
      handler: ({ rawInput }) => runCommand(ctx, rawInput, current),
    }), 'approval-ai: human command')
  })
  ctx.on('approval/request', async (request: ApprovalRequest, next) => {
    if (resolved.mode === 'human-only') return next()
    const result = await decide(ctx.llm, resolved, {
      toolName: request.toolName,
      arguments: (request as ApprovalRequest & { arguments?: unknown }).arguments,
      ...request.reason === undefined ? {} : { reason: request.reason },
      ...((request as ApprovalRequest & { workspace?: string }).workspace === undefined ? {} : { workspace: (request as ApprovalRequest & { workspace?: string }).workspace }),
      ...((request as ApprovalRequest & { sandboxMode?: string }).sandboxMode === undefined ? {} : { sandboxMode: (request as ApprovalRequest & { sandboxMode?: string }).sandboxMode }),
    }, request.signal ?? new AbortController().signal)
    if (result !== undefined) return result
    return next()
  })
}

export const Config: z<ApprovalConfig> = z.object({
  provider: z.string().default('deepseek-official'),
  model: z.string().default('deepseek-v4-flash'),
  mode: z.union(['ai-only', 'ai-then-human', 'human-only'] as const).default('ai-only'),
  currentPath: z.string().default(process.cwd()),
  projectArchitecture: z.string().default(''),
  implementationArchitecture: z.string().default(''),
  agentsMd: z.string().default(''),
  securityApprovalPrompt: z.string().default('仅判断当前审批请求的风险，不读取项目文件，不执行工具，不调用 MCP，不创建 Agent。'),
  timeoutMs: z.number().default(3000),
  failClosed: z.boolean().default(true),
  maxInputBytes: z.number().default(16384),
  maxOutputBytes: z.number().default(4096),
  maxReasonLength: z.number().default(512),
  reviewOutcome: z.union(['rejected', 'unavailable'] as const).default('rejected'),
})

export default apply
