/** Browser half of the approval-ai settings surface. */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import { ApprovalAiCard } from './ApprovalAiCard.tsx'
import { ApprovalAiCardController } from './approval-ai-card-controller.ts'
import type { PluginsSettingsItemOwnerProps } from './slot-contract.ts'

const NS = 'approval-ai'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    'settings.plugin.item': { kind: 'list'; scope: 'root'; owner: PluginsSettingsItemOwnerProps }
  }
  interface LocaleNamespaceMap {
    'approval-ai': ApprovalAiLocaleKey
  }
}

/** Locale keys owned by the approval-ai settings card. */
export type ApprovalAiLocaleKey =
  | 'title' | 'description' | 'provider' | 'providerHint' | 'model' | 'modelHint'
  | 'mode' | 'modeHint' | 'failClosed' | 'failClosedHint' | 'invalidProvider'
  | 'invalidModel' | 'invalidMode' | 'overridden' | 'reset' | 'readOnly' | 'save'
  | 'saving' | 'discard' | 'unsaved' | 'saveFailed'

const en: Record<ApprovalAiLocaleKey, string> = {
  title: 'AI Approval',
  description: 'Classifies tool approval requests with the configured LLM route.',
  provider: 'Provider route',
  providerHint: 'An LLM provider route already registered by DSH.',
  model: 'Model',
  modelHint: 'A model ID served by the selected provider route.',
  mode: 'Mode',
  modeHint: 'AI-only decides automatically; human-only delegates to the normal approval page.',
  failClosed: 'Fail closed',
  failClosedHint: 'Reject when the route, response, timeout, or output validation fails.',
  invalidProvider: 'Enter a provider route ID.',
  invalidModel: 'Enter a model ID.',
  invalidMode: 'Choose one of the supported modes.',
  overridden: 'Overridden',
  reset: 'Reset',
  readOnly: 'This deployment stores settings read-only.',
  save: 'Save',
  saving: 'Saving…',
  discard: 'Discard',
  unsaved: 'Unsaved',
  saveFailed: 'The deployment did not accept these values.',
}

const zh: Record<ApprovalAiLocaleKey, string> = {
  title: 'AI 审批',
  description: '使用已配置的 LLM 路由判断工具审批请求。',
  provider: 'Provider 路由',
  providerHint: '填写 DSH 当前已经注册的 LLM provider 路由 ID。',
  model: '模型',
  modelHint: '填写所选 provider 提供的模型 ID。',
  mode: '运行模式',
  modeHint: 'ai-only 自动判断；human-only 交给原有审批页面。',
  failClosed: '失败时拒绝',
  failClosedHint: '路由、响应、超时或输出校验失败时拒绝请求。',
  invalidProvider: '请输入 provider 路由 ID。',
  invalidModel: '请输入模型 ID。',
  invalidMode: '请选择支持的运行模式。',
  overridden: '已覆盖',
  reset: '恢复默认',
  readOnly: '本部署的设置为只读。',
  save: '保存',
  saving: '保存中…',
  discard: '放弃修改',
  unsaved: '未保存',
  saveFailed: '本部署没有接受这些设置。',
}

/** Required client services for the settings card. */
export const inject = ['slots', 'locale', 'settingsScope']

/** Register the approval-ai card in the shared Web Plugins settings page. */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'approval-ai: card dictionaries')
  const card = new ApprovalAiCardController(ctx.settingsScope.bind({ namespace: NS }))
  ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
    name: 'settings.plugin.item',
    id: 'approval-ai',
    order: 30,
    locale: NS,
    inject: () => card.inject(),
  }, ApprovalAiCard))
}
