/** Staged Web settings form for the approval-ai Host namespace. */

import type { SettingsScope, SettingsScopeSnapshot, SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client'
import { createSnapshotStore } from '@deepseek-ai/dsh-client-runtime/client'

/** The modes accepted by the Host plugin. */
export const APPROVAL_AI_MODES = ['ai-only', 'ai-then-human', 'human-only'] as const
export type ApprovalAiMode = typeof APPROVAL_AI_MODES[number]

/** The settings section exposed by the Host plugin. */
export interface ApprovalAiSettings {
  provider?: string
  model?: string
  mode?: ApprovalAiMode
  failClosed?: boolean
}

/** One text/select field in the staged card. */
export interface ApprovalAiFieldState {
  text: string
  overridden: boolean
  invalid: boolean
}

/** Snapshot rendered by the approval-ai settings card. */
export interface ApprovalAiCardState {
  available: boolean
  writable: boolean
  dirty: boolean
  invalid: boolean
  saving: boolean
  failed: boolean
  provider: ApprovalAiFieldState
  model: ApprovalAiFieldState
  mode: ApprovalAiFieldState
  failClosed: { checked: boolean; overridden: boolean }
}

type EditableField = 'provider' | 'model' | 'mode' | 'failClosed'
type DraftValue = string | boolean

/** Actions and store exposed to the card slot. */
export interface ApprovalAiCardFace {
  hooks: { approvalAiCard: SnapshotStore<ApprovalAiCardState> }
  edit: (field: EditableField, value: string | boolean) => void
  resetField: (field: EditableField) => void
  save: () => void
  discard: () => void
}

/** Bridges the browser settings surface to the Host settings namespace. */
export class ApprovalAiCardController {
  private readonly staged = new Map<EditableField, DraftValue>()
  private readonly reset = new Set<EditableField>()
  private readonly listeners = new Set<() => void>()
  private readonly store: SnapshotStore<ApprovalAiCardState>
  private saving = false
  private failed = false

  /**
   * @param scope - the browser binding for the Host-owned approval-ai section.
   */
  constructor(private readonly scope: SettingsScope<ApprovalAiSettings>) {
    scope.subscribe(() => { this.publish() })
    this.store = createSnapshotStore(this.project())
    this.listeners.add(() => { this.store.set(this.project()) })
  }

  /** @returns the slot face consumed by the card renderer. */
  inject(): ApprovalAiCardFace {
    return {
      hooks: { approvalAiCard: this.store },
      edit: (field, value) => { this.stage(field, value) },
      resetField: (field) => { this.resetField(field) },
      save: () => { void this.save() },
      discard: () => { this.discard() },
    }
  }

  private projectField(field: 'provider' | 'model' | 'mode'): ApprovalAiFieldState {
    const snapshot = this.scope.getSnapshot()
    const staged = this.staged.get(field)
    const value = (snapshot.value as ApprovalAiSettings | undefined)?.[field]
    const text = staged === undefined ? this.format(value) : String(staged)
    const invalid = staged !== undefined && this.parse(field, text) === undefined
    return {
      text,
      invalid,
      overridden: staged !== undefined ? !invalid : this.stored(snapshot, field),
    }
  }

  private project(): ApprovalAiCardState {
    const snapshot = this.scope.getSnapshot()
    const stagedFailClosed = this.staged.get('failClosed')
    const value = (snapshot.value as ApprovalAiSettings | undefined)?.failClosed
    const failClosed = stagedFailClosed === undefined ? value ?? true : stagedFailClosed === true
    return {
      available: snapshot.status === 'ready',
      writable: snapshot.writable,
      dirty: this.staged.size > 0 || this.reset.size > 0,
      invalid: this.projectField('provider').invalid || this.projectField('model').invalid || this.projectField('mode').invalid,
      saving: this.saving,
      failed: this.failed,
      provider: this.projectField('provider'),
      model: this.projectField('model'),
      mode: this.projectField('mode'),
      failClosed: {
        checked: failClosed,
        overridden: stagedFailClosed !== undefined ? true : this.stored(snapshot, 'failClosed'),
      },
    }
  }

  private format(value: unknown): string {
    return typeof value === 'string' ? value : ''
  }

  private parse(field: 'provider' | 'model' | 'mode', text: string): string | undefined {
    const value = text.trim()
    if (value.length === 0) return undefined
    if (field === 'mode' && !(APPROVAL_AI_MODES as readonly string[]).includes(value)) return undefined
    return value
  }

  private stored(snapshot: SettingsScopeSnapshot<ApprovalAiSettings>, field: EditableField): boolean {
    const user = snapshot.user as ApprovalAiSettings | undefined
    return user !== undefined && Object.hasOwn(user, field)
  }

  private stage(field: EditableField, value: DraftValue): void {
    this.staged.set(field, value)
    this.reset.delete(field)
    this.failed = false
    this.publish()
  }

  private resetField(field: EditableField): void {
    this.staged.delete(field)
    this.reset.add(field)
    this.failed = false
    this.publish()
  }

  private discard(): void {
    this.staged.clear()
    this.reset.clear()
    this.failed = false
    this.publish()
  }

  private async save(): Promise<void> {
    const state = this.project()
    if (!state.dirty || state.invalid || state.saving || !state.writable) return
    this.saving = true
    this.failed = false
    this.publish()
    let landed = true
    for (const field of [...this.reset]) {
      await this.scope.unset(field)
      landed = this.stored(this.scope.getSnapshot(), field) === false && landed
    }
    for (const [field, value] of this.staged) {
      const parsed = field === 'failClosed' ? value : this.parse(field, String(value))
      if (parsed === undefined) {
        landed = false
        continue
      }
      const next = field === 'failClosed' ? parsed === true : parsed
      await this.scope.set(field, next)
      const user = this.scope.getSnapshot().user as ApprovalAiSettings | undefined
      landed = user !== undefined && user[field] === next && landed
    }
    if (landed) {
      this.staged.clear()
      this.reset.clear()
    }
    this.saving = false
    this.failed = !landed
    this.publish()
  }

  private publish(): void {
    for (const listener of this.listeners) listener()
  }
}
