/** Approval-ai settings card rendered inside DSH's Plugins settings page. */

import { useState } from 'react'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { ApprovalAiCardFace, ApprovalAiCardState } from './approval-ai-card-controller.ts'
import { APPROVAL_AI_MODES } from './approval-ai-card-controller.ts'

/** Props supplied by the settings plugin-item slot. */
export type ApprovalAiCardProps =
  PropsRuntime<'settings.plugin.item'>
  & PropsLocale<'approval-ai'>
  & InjectFace<ApprovalAiCardFace>

const cardStyle = { listStyle: 'none', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 12, background: 'var(--dsw-alias-bg-layer-3)' } as const
const headerStyle = { width: '100%', border: 0, background: 'none', color: 'inherit', textAlign: 'left' as const, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 12 } as const
const bodyStyle = { borderTop: '1px solid var(--dsw-alias-border-l2)', margin: '0 16px', padding: '4px 0 12px' } as const
const fieldStyle = { padding: '10px 0', borderBottom: '1px solid var(--dsw-alias-border-l2)' } as const
const labelStyle = { display: 'block', marginBottom: 5, fontSize: 13, fontWeight: 600 } as const
const hintStyle = { margin: '5px 0 0', fontSize: 12, lineHeight: 1.5, color: 'var(--dsw-alias-label-tertiary)' } as const
const inputStyle = { width: '100%', boxSizing: 'border-box' as const, border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 7, background: 'var(--dsw-alias-bg-layer-2)', color: 'inherit', padding: '7px 9px', font: 'inherit' } as const
const footerStyle = { display: 'flex', justifyContent: 'flex-end', gap: 8, paddingTop: 12 } as const

function Field(props: {
  id: string
  label: string
  hint: string
  state: ApprovalAiCardState['provider']
  disabled: boolean
  onEdit: (value: string) => void
  onReset: () => void
  resetLabel: string
  overriddenLabel: string
  invalidLabel: string
}) {
  return (
    <div style={fieldStyle}>
      <label htmlFor={props.id} style={labelStyle}>{props.label}</label>
      {props.state.overridden ? <button type="button" disabled={props.disabled} onClick={props.onReset}>{props.overriddenLabel} · {props.resetLabel}</button> : null}
      <input id={props.id} type="text" value={props.state.text} disabled={props.disabled} aria-invalid={props.state.invalid || undefined} style={inputStyle} onChange={(event) => { props.onEdit(event.target.value) }} />
      <p style={hintStyle}>{props.state.invalid ? props.invalidLabel : props.hint}</p>
    </div>
  )
}

function ModeField(props: {
  state: ApprovalAiCardState['mode']
  disabled: boolean
  label: string
  hint: string
  invalidLabel: string
  onEdit: (value: string) => void
  onReset: () => void
  resetLabel: string
  overriddenLabel: string
}) {
  return (
    <div style={fieldStyle}>
      <label htmlFor="approval-ai-mode" style={labelStyle}>{props.label}</label>
      {props.state.overridden ? <button type="button" disabled={props.disabled} onClick={props.onReset}>{props.overriddenLabel} · {props.resetLabel}</button> : null}
      <select id="approval-ai-mode" value={props.state.text} disabled={props.disabled} aria-invalid={props.state.invalid || undefined} style={inputStyle} onChange={(event) => { props.onEdit(event.target.value) }}>
        {APPROVAL_AI_MODES.map(mode => <option key={mode} value={mode}>{mode}</option>)}
      </select>
      <p style={hintStyle}>{props.state.invalid ? props.invalidLabel : props.hint}</p>
    </div>
  )
}

/** Render the approval-ai settings card. */
export function ApprovalAiCard(props: ApprovalAiCardProps) {
  const [open, setOpen] = useState(false)
  const state = props.useApprovalAiCard((snapshot) => snapshot)
  if (!state.available) return null
  const disabled = !state.writable || state.saving
  return (
    <li style={cardStyle}>
      <button type="button" aria-expanded={open} style={headerStyle} onClick={() => { setOpen(!open) }}>
        <span style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <span style={{ fontSize: 15, fontWeight: 600 }}>{props.t('title')}</span>
          <span style={{ fontSize: 13, color: 'var(--dsw-alias-label-tertiary)' }}>{props.t('description')}</span>
        </span>
        {state.dirty ? <span>{props.t('unsaved')}</span> : null}
        <span aria-hidden="true">{open ? '⌃' : '⌄'}</span>
      </button>
      {open ? (
        <div style={bodyStyle}>
          {!state.writable ? <p role="status">{props.t('readOnly')}</p> : null}
          <Field
            id="approval-ai-provider"
            label={props.t('provider')}
            hint={props.t('providerHint')}
            invalidLabel={props.t('invalidProvider')}
            resetLabel={props.t('reset')}
            overriddenLabel={props.t('overridden')}
            disabled={disabled}
            state={state.provider}
            onEdit={(value) => { props.edit('provider', value) }}
            onReset={() => { props.resetField('provider') }}
          />
          <Field
            id="approval-ai-model"
            label={props.t('model')}
            hint={props.t('modelHint')}
            invalidLabel={props.t('invalidModel')}
            resetLabel={props.t('reset')}
            overriddenLabel={props.t('overridden')}
            disabled={disabled}
            state={state.model}
            onEdit={(value) => { props.edit('model', value) }}
            onReset={() => { props.resetField('model') }}
          />
          <ModeField
            state={state.mode}
            disabled={disabled}
            label={props.t('mode')}
            hint={props.t('modeHint')}
            invalidLabel={props.t('invalidMode')}
            onEdit={(value) => { props.edit('mode', value) }}
            onReset={() => { props.resetField('mode') }}
            resetLabel={props.t('reset')}
            overriddenLabel={props.t('overridden')}
          />
          <div style={fieldStyle}>
            <label htmlFor="approval-ai-fail-closed" style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 13, fontWeight: 600 }}>
              <input id="approval-ai-fail-closed" type="checkbox" checked={state.failClosed.checked} disabled={disabled} onChange={(event) => { props.edit('failClosed', event.target.checked) }} />
              {props.t('failClosed')}
            </label>
            {state.failClosed.overridden ? <button type="button" disabled={disabled} onClick={() => { props.resetField('failClosed') }}>{props.t('overridden')} · {props.t('reset')}</button> : null}
            <p style={hintStyle}>{props.t('failClosedHint')}</p>
          </div>
          <div style={footerStyle}>
            {state.failed ? <span role="status">{props.t('saveFailed')}</span> : null}
            <button type="button" disabled={!state.dirty || state.saving} onClick={props.discard}>{props.t('discard')}</button>
            <button type="button" disabled={!state.dirty || state.invalid || state.saving || !state.writable} onClick={props.save}>{state.saving ? props.t('saving') : props.t('save')}</button>
          </div>
        </div>
      ) : null}
    </li>
  )
}
