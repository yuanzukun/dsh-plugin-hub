/** Local copy of the settings-card slot owner marker used by DSH Web. */

/** The shared Plugins settings section supplies no props to one card. */
export interface PluginsSettingsItemOwnerProps {
  children?: never
}
