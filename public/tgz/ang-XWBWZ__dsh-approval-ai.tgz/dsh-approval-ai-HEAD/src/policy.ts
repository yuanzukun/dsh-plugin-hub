import type { ApprovalAssessmentInput, Config } from './types.ts'
import { assess } from './model.ts'
import type { LlmRuntime } from '@deepseek-ai/dsh-llm'
import type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval'

export function resolveConfig(config: Config): Required<Config> {
  if (config.provider === undefined || config.provider.length === 0) throw new Error('approval-ai provider is required')
  if (config.model === undefined || config.model.length === 0) throw new Error('approval-ai model is required')
  const resolved = {
    provider: config.provider,
    model: config.model,
    mode: config.mode ?? 'ai-only',
    timeoutMs: config.timeoutMs ?? 3000,
    failClosed: config.failClosed ?? true,
    maxInputBytes: config.maxInputBytes ?? 16384,
    maxOutputBytes: config.maxOutputBytes ?? 4096,
    maxReasonLength: config.maxReasonLength ?? 512,
    reviewOutcome: config.reviewOutcome ?? 'rejected',
    currentPath: config.currentPath ?? process.cwd(),
    projectArchitecture: config.projectArchitecture ?? '',
    implementationArchitecture: config.implementationArchitecture ?? '',
    agentsMd: config.agentsMd ?? '',
    securityApprovalPrompt: config.securityApprovalPrompt ?? '仅判断当前审批请求，不读取项目文件，不执行工具，不调用 MCP，不创建 Agent。',
  }
  if (resolved.timeoutMs <= 0 || resolved.maxInputBytes <= 0 || resolved.maxOutputBytes <= 0 || resolved.maxReasonLength <= 0) throw new Error('approval-ai limits must be positive')
  return resolved
}

/** Answer one request that the DSH approval service has already admitted. */
export async function decide(llm: LlmRuntime, config: Required<Config>, input: ApprovalAssessmentInput, signal: AbortSignal): Promise<ApprovalOutcome> {
  const controller = new AbortController()
  const onAbort = () => controller.abort()
  signal.addEventListener('abort', onAbort, { once: true })
  const timer = setTimeout(() => controller.abort(), config.timeoutMs)
  try {
    const result = await assess(llm, config, input, controller.signal)
    if (result === undefined) return config.failClosed ? 'rejected' : 'unavailable'
    if (result.decision === 'deny' || result.risk === 'high' || result.risk === 'critical') return 'rejected'
    if (result.decision === 'review') return config.reviewOutcome
    return 'allowed-once'
  } catch {
    return config.failClosed ? 'rejected' : 'unavailable'
  } finally {
    clearTimeout(timer)
    signal.removeEventListener('abort', onAbort)
  }
}
