/** Public configuration and assessment types for the AI approval answerer. */

export type ApprovalAiMode = 'ai-only' | 'ai-then-human' | 'human-only'
export type ApprovalAiDecision = 'allow' | 'deny' | 'review'
export type ApprovalAiRisk = 'low' | 'medium' | 'high' | 'critical'

export interface ApprovalAssessmentInput {
  readonly toolName: string
  readonly arguments: unknown
  readonly reason?: string
  /** Active workspace root used only to classify external path requests. */
  readonly workspace?: string
  /** DSH-resolved sandbox mode; ordinary workspace access remains DSH-owned. */
  readonly sandboxMode?: string
}

export interface ApprovalAssessment {
  readonly decision: ApprovalAiDecision
  readonly risk: ApprovalAiRisk
  readonly reason: string
}

export interface ApprovalContextConfig {
  /** Current workspace path; the plugin records this value but never reads it. */
  readonly currentPath?: string
  /** Optional architecture summary supplied by composition or settings. */
  readonly projectArchitecture?: string
  /** Optional implementation architecture summary supplied by composition or settings. */
  readonly implementationArchitecture?: string
  /** Optional AGENTS.md guidance supplied by composition or settings. */
  readonly agentsMd?: string
  /** Preset security-approval prompt shown in settings and sent as policy context. */
  readonly securityApprovalPrompt?: string
}

export interface Config extends ApprovalContextConfig {
  readonly provider?: string
  readonly model?: string
  readonly mode?: ApprovalAiMode
  readonly timeoutMs?: number
  readonly failClosed?: boolean
  readonly maxInputBytes?: number
  readonly maxOutputBytes?: number
  readonly maxReasonLength?: number
  readonly reviewOutcome?: 'rejected' | 'unavailable'
}
