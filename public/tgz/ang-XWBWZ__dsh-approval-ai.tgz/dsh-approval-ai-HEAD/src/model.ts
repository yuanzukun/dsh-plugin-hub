import { BlockAssembler, createUserMessage, type GenerateOptions, type LlmRuntime } from '@deepseek-ai/dsh-llm'
import type { ApprovalAssessmentInput, ApprovalAssessment, Config } from './types.ts'
import { parseAssessment } from './output.ts'
function stringifyArguments(value: unknown, maxBytes: number): string | undefined {
  try {
    const text = JSON.stringify(value)
    if (text === undefined || Buffer.byteLength(text, 'utf8') > maxBytes) return undefined
    return text
  } catch {
    return undefined
  }
}

const SYSTEM = 'You are a permission risk classifier. Return only JSON with decision (allow, deny, or review), risk (low, medium, high, or critical), and reason. You only assess the supplied approval request. Do not read project files, call tools, call MCP, create agents, or request another approval.'

export async function assess(llm: LlmRuntime, config: Required<Config>, input: ApprovalAssessmentInput, signal: AbortSignal): Promise<ApprovalAssessment | undefined> {
  const args = stringifyArguments(input.arguments, config.maxInputBytes)
  if (args === undefined) return undefined
  const payload = JSON.stringify({
    toolName: input.toolName,
    arguments: JSON.parse(args),
    reason: input.reason,
    workspace: input.workspace,
    sandboxMode: input.sandboxMode,
    approvalBackground: {
      currentPath: config.currentPath,
      projectArchitecture: config.projectArchitecture,
      implementationArchitecture: config.implementationArchitecture,
      agentsMd: config.agentsMd,
      securityApprovalPrompt: config.securityApprovalPrompt,
      filesAreNotRead: true,
    },
  })
  if (Buffer.byteLength(payload, 'utf8') > config.maxInputBytes) return undefined
  const prepared = await llm.prepareCall({ provider: config.provider, model: config.model, maxTokens: 256 }, signal)
  const request: GenerateOptions = {
    ...prepared.config,
    messages: [createUserMessage({ source: { kind: 'plugin', plugin: 'approval-ai' }, content: [{ type: 'text', text: payload }] })],
    system: SYSTEM,
    signal,
  }
  const assembler = new BlockAssembler()
  for await (const chunk of prepared.stream(request)) {
    assembler.push(chunk)
  }
  const text = assembler.blocks().find(block => block.type === 'text')?.text
  if (text === undefined || Buffer.byteLength(text, 'utf8') > config.maxOutputBytes) return undefined
  return parseAssessment(text, config.maxReasonLength)
}
