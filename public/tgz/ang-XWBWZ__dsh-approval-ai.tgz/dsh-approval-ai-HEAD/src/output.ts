import type { ApprovalAssessment, ApprovalAiDecision, ApprovalAiRisk } from './types.ts'

const DECISIONS: readonly ApprovalAiDecision[] = ['allow', 'deny', 'review']
const RISKS: readonly ApprovalAiRisk[] = ['low', 'medium', 'high', 'critical']

export function parseAssessment(text: string, maxReasonLength: number): ApprovalAssessment | undefined {
  let value: unknown
  try { value = JSON.parse(text) } catch { return undefined }
  if (value === null || typeof value !== 'object') return undefined
  const record = value as Record<string, unknown>
  if (!DECISIONS.includes(record.decision as ApprovalAiDecision)
    || !RISKS.includes(record.risk as ApprovalAiRisk)
    || typeof record.reason !== 'string'
    || record.reason.length === 0
    || record.reason.length > maxReasonLength) return undefined
  return {
    decision: record.decision as ApprovalAiDecision,
    risk: record.risk as ApprovalAiRisk,
    reason: record.reason,
  }
}
