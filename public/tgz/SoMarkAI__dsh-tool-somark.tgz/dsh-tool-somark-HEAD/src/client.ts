/**
 * SoMark document-parsing API client: multipart task submission, status
 * polling, option normalization, metadata extraction, and output capping.
 * Pure against the network — every HTTP call goes through the global `fetch`,
 * which tests stub; nothing here touches `ctx` or the filesystem.
 * @module @deepseek-ai/dsh-tool-somark/client
 */

import { HarnessError } from '@deepseek-ai/dsh-llm'
import type {
  SomarkElementFormatKey,
  SomarkElementFormatOverrides,
  SomarkElementFormats,
  SomarkErrorCode,
  SomarkFeatureConfig,
  SomarkFeatureConfigOverrides,
  SomarkOutputCaps,
  SomarkOutputFormat,
  SomarkParseOutput,
  SomarkTaskOutputs,
  SomarkToolResult,
} from './types.ts'

/** Public SoMark API base; the parse endpoints append their paths. */
export const SOMARK_DEFAULT_BASE_URL = 'https://somark.tech/api/v1'
/** Multipart task-submission endpoint. */
export const SOMARK_PARSE_PATH = '/parse/async'
/** Task-status polling endpoint. */
export const SOMARK_CHECK_PATH = '/parse/async_check'
/** Formats requested per parse when config omits them. */
export const DEFAULT_OUTPUT_FORMATS: readonly SomarkOutputFormat[] = ['markdown', 'json']
/** Default per-element rendering formats (the SoMark workbench defaults). */
export const DEFAULT_ELEMENT_FORMATS: SomarkElementFormats = {
  image: 'url',
  formula: 'latex',
  table: 'html',
  cs: 'image',
}
/** Default feature switches (the SoMark workbench defaults). */
export const DEFAULT_FEATURE_CONFIG: SomarkFeatureConfig = {
  enable_text_cross_page: false,
  enable_table_cross_page: false,
  enable_title_level_recognition: false,
  enable_inline_image: true,
  enable_table_image: true,
  enable_image_understanding: true,
  keep_header_footer: false,
}
/** Allowed rendering values per element-format key. */
export const SUPPORTED_ELEMENT_FORMAT_VALUES: Record<SomarkElementFormatKey, readonly string[]> = {
  image: ['url', 'base64', 'none'],
  formula: ['latex', 'mathml', 'ascii'],
  table: ['html', 'image', 'markdown'],
  cs: ['image'],
}
/** Default delay between status polls (2 seconds). */
export const DEFAULT_POLL_INTERVAL_MS = 2_000
/** Default poll attempts at the default interval (≈ 33 minutes). */
export const DEFAULT_MAX_POLL_ATTEMPTS = 1_000
/** Default upload cap — SoMark's documented 200 MB file limit. */
export const DEFAULT_MAX_FILE_BYTES = 200 * 1024 * 1024
/** Default cap on the markdown returned in one tool result. */
export const DEFAULT_MARKDOWN_CAP_CHARS = 200_000
/** Default cap on the stringified JSON returned in one tool result. */
export const DEFAULT_JSON_CAP_CHARS = 200_000
/** File extensions the SoMark API accepts, lowercased. */
export const SUPPORTED_DOCUMENT_EXTENSIONS: ReadonlySet<string> = new Set([
  '.pdf',
  '.png',
  '.jpg',
  '.jpeg',
  '.bmp',
  '.tiff',
  '.jp2',
  '.dib',
  '.ppm',
  '.pgm',
  '.pbm',
  '.gif',
  '.heic',
  '.heif',
  '.webp',
  '.xpm',
  '.tga',
  '.dds',
  '.xbm',
  '.doc',
  '.docx',
  '.ppt',
  '.pptx',
])

/**
 * Typed SoMark failure extending {@link HarnessError}, so the tool registry
 * exposes the stable machine-routable code on `error.info.code`.
 */
export class SomarkError extends HarnessError {
  override readonly code: SomarkErrorCode

  constructor(code: SomarkErrorCode, message: string, options?: ErrorOptions) {
    super(message, code, options)
    this.code = code
  }
}

/**
 * The lowercase extension of a path, or `undefined` when it has none.
 * @param path - the path to inspect.
 * @returns the extension without its dot, lowercased, or undefined.
 */
export function documentExtension(path: string): string | undefined {
  const lastDot = path.lastIndexOf('.')
  if (lastDot < 0 || lastDot === path.length - 1) return undefined
  return path.slice(lastDot + 1).toLowerCase()
}

/**
 * Whether an extension (lowercased, no dot) is accepted by the SoMark API.
 * @param extension - the extension to test, as returned by {@link documentExtension}.
 * @returns true when the API accepts the extension.
 */
export function isSupportedDocumentExtension(extension: string | undefined): boolean {
  return extension !== undefined && SUPPORTED_DOCUMENT_EXTENSIONS.has(`.${extension}`)
}

/**
 * Merge partial element-format overrides onto the defaults and reject unknown
 * keys or values. Deployment config passes through here at plugin load so a
 * typo fails the load instead of a later parse. A `null` value unsets a key
 * and keeps its default.
 * @param partial - the configured overrides, if any.
 * @returns the complete element formats sent with every request.
 */
export function normalizeElementFormats(partial?: SomarkElementFormatOverrides): SomarkElementFormats {
  const normalized: Record<string, unknown> = { ...DEFAULT_ELEMENT_FORMATS }
  const allowedByKey = SUPPORTED_ELEMENT_FORMAT_VALUES as Record<string, readonly string[]>
  for (const [key, value] of Object.entries(partial ?? {}) as [string, unknown][]) {
    const allowed = allowedByKey[key]
    if (allowed === undefined) {
      throw new SomarkError(
        'CONFIG_INVALID',
        `Unsupported element format key "${key}". Allowed keys: ${Object.keys(SUPPORTED_ELEMENT_FORMAT_VALUES).join(', ')}`,
      )
    }
    if (value === null) continue
    if (typeof value !== 'string' || !allowed.includes(value)) {
      throw new SomarkError(
        'CONFIG_INVALID',
        `Unsupported element format "${key}: ${JSON.stringify(value)}". Allowed values: ${JSON.stringify(allowed)}`,
      )
    }
    normalized[key] = value
  }
  return normalized as unknown as SomarkElementFormats
}

/**
 * Merge partial feature-config overrides onto the defaults and reject unknown
 * keys or non-boolean values. Deployment config passes through here at plugin
 * load so a typo fails the load instead of a later parse. A `null` value
 * unsets a key and keeps its default.
 * @param partial - the configured overrides, if any.
 * @returns the complete feature config sent with every request.
 */
export function normalizeFeatureConfig(partial?: SomarkFeatureConfigOverrides): SomarkFeatureConfig {
  const normalized: SomarkFeatureConfig = { ...DEFAULT_FEATURE_CONFIG }
  if (partial !== undefined) {
    for (const [key, value] of Object.entries(partial) as [string, unknown][]) {
      if (!(key in DEFAULT_FEATURE_CONFIG)) {
        throw new SomarkError('CONFIG_INVALID', `Unknown feature config "${key}"`)
      }
      if (value === null) continue
      if (typeof value !== 'boolean') {
        throw new SomarkError('CONFIG_INVALID', `Feature config "${key}" must be a boolean, got ${typeof value}`)
      }
      normalized[key as keyof SomarkFeatureConfig] = value
    }
  }
  return normalized
}

/**
 * Validate a requested output-format list (at least one, all supported).
 * @param values - the formats to request.
 * @returns the same formats in order.
 */
export function normalizeOutputFormats(values: readonly string[]): SomarkOutputFormat[] {
  if (values.length === 0) {
    throw new SomarkError('CONFIG_INVALID', 'At least one output format is required')
  }
  const normalized: SomarkOutputFormat[] = []
  for (const format of values) {
    if (format !== 'markdown' && format !== 'json') {
      throw new SomarkError('CONFIG_INVALID', `Unsupported output format "${format}"; supported: markdown, json`)
    }
    normalized.push(format)
  }
  return normalized
}

/** Options for {@link submitParseTask}. */
export interface SubmitParseTaskOptions {
  /** Endpoint base; the parse path appends. */
  baseURL: string
  /** SoMark API key, sent as the multipart `api_key` field. */
  apiKey: string
  /** The document bytes to upload. */
  file: Uint8Array
  /** The document file name, sent as the multipart `file` filename. */
  fileName: string
  /** Formats to request. */
  outputFormats: readonly SomarkOutputFormat[]
  /** Complete per-element rendering formats. */
  elementFormats: SomarkElementFormats
  /** Complete feature switches. */
  featureConfig: SomarkFeatureConfig
  /** Cancels the submission request. */
  signal?: AbortSignal
}

/**
 * Submit one document to the SoMark async parse API and return the task id.
 * @param options - submission parameters.
 * @returns the `task_id` SoMark assigned.
 */
export async function submitParseTask(options: SubmitParseTaskOptions): Promise<string> {
  const form = new FormData()
  form.append('api_key', options.apiKey)
  form.append('file', new Blob([options.file as unknown as BlobPart]), options.fileName)
  for (const format of options.outputFormats) form.append('output_formats', format)
  form.append('element_formats', JSON.stringify(options.elementFormats))
  form.append('feature_config', JSON.stringify(options.featureConfig))
  const response = await fetchWithAbort(
    `${options.baseURL}${SOMARK_PARSE_PATH}`,
    {
      method: 'POST',
      body: form,
      ...options.signal !== undefined ? { signal: options.signal } : {},
    },
    'SoMark task submission failed',
  )
  const body = await parseJsonResponse(
    response,
    'SUBMIT_FAILED',
    `SoMark task submission failed (HTTP ${response.status})`,
  )
  const taskId = (body.data as { task_id?: unknown } | undefined)?.task_id
  if (typeof taskId !== 'string' || taskId.length === 0) {
    throw new SomarkError('INVALID_RESPONSE', 'SoMark task submission response carried no task_id')
  }
  return taskId
}

/** Options for {@link pollParseTask}. */
export interface PollParseTaskOptions {
  /** Endpoint base; the check path appends. */
  baseURL: string
  /** SoMark API key. */
  apiKey: string
  /** The task id returned by {@link submitParseTask}. */
  taskId: string
  /** Maximum number of polls before giving up. */
  maxAttempts: number
  /** Delay between polls, in milliseconds. */
  intervalMs: number
  /** Cancels the wait between polls and the in-flight check. */
  signal?: AbortSignal
}

/**
 * Poll a SoMark parse task until it succeeds or fails. A failed check HTTP
 * status or an unparseable body counts as one attempt and is retried; only an
 * explicit `FAILED` status, an abort, or the attempt cap stops the loop.
 * @param options - polling parameters.
 * @returns the task `outputs` on success.
 */
export async function pollParseTask(options: PollParseTaskOptions): Promise<SomarkParseOutput> {
  for (let attempt = 0; attempt < options.maxAttempts; attempt++) {
    await sleep(options.intervalMs, options.signal)
    let body: { data?: unknown }
    try {
      const response = await fetchWithAbort(
        `${options.baseURL}${SOMARK_CHECK_PATH}`,
        {
          method: 'POST',
          headers: { 'content-type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ api_key: options.apiKey, task_id: options.taskId }),
          ...options.signal !== undefined ? { signal: options.signal } : {},
        },
        'SoMark status check failed',
      )
      if (!response.ok) continue
      body = await response.json() as { data?: unknown }
    } catch (error) {
      // An abort during the check is terminal; every other transient failure
      // (network blip, gateway 5xx, malformed body) is one more attempt.
      if (error instanceof SomarkError && error.code === 'ABORTED') throw error
      continue
    }
    const data = body.data as { status?: unknown; result?: unknown } | undefined
    if (data?.status === 'FAILED') {
      throw new SomarkError('TASK_FAILED', `SoMark parsing task failed: ${JSON.stringify(data)}`)
    }
    if (data?.status === 'SUCCESS') {
      const result = data.result as { outputs?: unknown } | undefined
      const outputs = (result?.outputs ?? result) as SomarkParseOutput
      return outputs
    }
  }
  throw new SomarkError(
    'POLL_TIMEOUT',
    `SoMark task ${options.taskId} did not finish within ${options.maxAttempts} polls`,
  )
}

/**
 * Extract the markdown, JSON payload, and metadata page/token counts from a
 * successful task's outputs. Counts default to 0 when the JSON metadata is
 * missing or malformed, so the result stays a typed value.
 * @param outputs - the outputs returned by the API.
 * @returns normalized task outputs.
 */
export function extractParseOutputs(outputs: SomarkParseOutput): SomarkTaskOutputs {
  const markdown = typeof outputs.markdown === 'string' ? outputs.markdown : ''
  const json = outputs.json
  let pageCount = 0
  let tokenCount = 0
  if (json !== null && typeof json === 'object') {
    const metadata = (json as { metadata?: unknown }).metadata
    if (metadata !== null && typeof metadata === 'object') {
      const page = (metadata as { page_count?: unknown }).page_count
      const tokens = (metadata as { token_count?: unknown }).token_count
      if (typeof page === 'number') pageCount = page
      if (typeof tokens === 'number') tokenCount = tokens
    }
  }
  return { markdown, ...json !== undefined ? { json } : {}, pageCount, tokenCount }
}

/**
 * Apply the configured output caps to a parsed task's outputs. Markdown is
 * sliced with a `truncated` flag; JSON is dropped with a `jsonOmitted` flag
 * when its stringified form exceeds the JSON cap.
 * @param outputs - the parsed task outputs.
 * @param caps - the configured caps.
 * @returns the canonical tool result.
 */
export function capParseOutputs(outputs: SomarkTaskOutputs, caps: SomarkOutputCaps): SomarkToolResult {
  const truncated = outputs.markdown.length > caps.markdownCapChars
  const markdown = truncated ? outputs.markdown.slice(0, caps.markdownCapChars) : outputs.markdown
  const base: SomarkToolResult = {
    markdown,
    truncated,
    pageCount: outputs.pageCount,
    tokenCount: outputs.tokenCount,
  }
  if (outputs.json === undefined) return base
  if (JSON.stringify(outputs.json).length <= caps.jsonCapChars) return { ...base, json: outputs.json }
  return { ...base, jsonOmitted: true }
}

/**
 * Render the model-facing text for a completed parse result.
 * @param value - the canonical tool result.
 * @returns the text the model sees.
 */
export function formatParseResult(value: SomarkToolResult): string {
  const lines = [
    `Parsed ${value.pageCount} page(s), ${value.tokenCount} token(s).`,
    '',
    value.markdown,
  ]
  if (value.truncated) lines.push('', '[Markdown truncated at the configured output cap; the parse itself is complete.]')
  if (value.jsonOmitted) lines.push('', '[JSON omitted: larger than the configured output cap.]')
  return lines.join('\n')
}

/** True for a fetch/`AbortSignal` abort, surfaced as `ABORTED`. */
function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === 'AbortError'
}

/** Fetch one request, mapping aborts to `ABORTED` and other failures to `REQUEST_FAILED`. */
async function fetchWithAbort(input: string, init: RequestInit, failureMessage: string): Promise<Response> {
  try {
    return await fetch(input, init)
  } catch (error) {
    if (isAbortError(error)) throw new SomarkError('ABORTED', 'SoMark request aborted', { cause: error })
    throw new SomarkError('REQUEST_FAILED', `${failureMessage}: ${String(error)}`, { cause: error })
  }
}

/** Parse a response body as JSON, mapping a non-2xx status to `code` and a bad body to `INVALID_RESPONSE`. */
async function parseJsonResponse(
  response: Response,
  code: SomarkErrorCode,
  httpMessage: string,
): Promise<{ data?: unknown }> {
  if (!response.ok) throw new SomarkError(code, httpMessage)
  try {
    return await response.json() as { data?: unknown }
  } catch (error) {
    throw new SomarkError('INVALID_RESPONSE', 'SoMark returned a non-JSON response body', { cause: error })
  }
}

/** Wait `ms` milliseconds, rejecting with `ABORTED` when `signal` fires. */
function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new SomarkError('ABORTED', 'SoMark request aborted'))
      return
    }
    const onAbort = (): void => {
      clearTimeout(timer)
      reject(new SomarkError('ABORTED', 'SoMark request aborted'))
    }
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort)
      resolve()
    }, ms)
    signal?.addEventListener('abort', onAbort, { once: true })
  })
}
