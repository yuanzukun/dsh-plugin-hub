/**
 * Model-facing `somark_parse` tool over the SoMark document-parsing API. The
 * tool reads the document through `ctx.fs` (so mounted filesystem policy
 * applies), uploads it to the configured SoMark endpoint, polls the async task
 * to completion, and returns the parsed Markdown plus page/token metadata.
 * This package owns schemas, config validation, limits, and presentation; the
 * API mechanics live in `./client.ts`.
 * @module @deepseek-ai/dsh-tool-somark
 */

import { basename } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { FsError } from '@deepseek-ai/dsh-fs'
import { launchEnvironmentOf } from '@deepseek-ai/dsh-launch-environment'
import {
  capParseOutputs,
  DEFAULT_JSON_CAP_CHARS,
  DEFAULT_MARKDOWN_CAP_CHARS,
  DEFAULT_MAX_FILE_BYTES,
  DEFAULT_MAX_POLL_ATTEMPTS,
  DEFAULT_OUTPUT_FORMATS,
  DEFAULT_POLL_INTERVAL_MS,
  documentExtension,
  extractParseOutputs,
  formatParseResult,
  isSupportedDocumentExtension,
  normalizeElementFormats,
  normalizeFeatureConfig,
  normalizeOutputFormats,
  pollParseTask,
  SOMARK_DEFAULT_BASE_URL,
  SomarkError,
  submitParseTask,
} from './client.ts'
import type {
  SomarkElementFormatOverrides,
  SomarkFeatureConfigOverrides,
  SomarkOutputFormat,
  SomarkToolResult,
} from './types.ts'

export {
  DEFAULT_ELEMENT_FORMATS,
  DEFAULT_FEATURE_CONFIG,
  DEFAULT_JSON_CAP_CHARS,
  DEFAULT_MARKDOWN_CAP_CHARS,
  DEFAULT_MAX_FILE_BYTES,
  DEFAULT_MAX_POLL_ATTEMPTS,
  DEFAULT_OUTPUT_FORMATS,
  DEFAULT_POLL_INTERVAL_MS,
  SOMARK_CHECK_PATH,
  SOMARK_DEFAULT_BASE_URL,
  SOMARK_PARSE_PATH,
  SUPPORTED_DOCUMENT_EXTENSIONS,
  SUPPORTED_ELEMENT_FORMAT_VALUES,
  SomarkError,
  capParseOutputs,
  documentExtension,
  extractParseOutputs,
  formatParseResult,
  isSupportedDocumentExtension,
  normalizeElementFormats,
  normalizeFeatureConfig,
  normalizeOutputFormats,
  pollParseTask,
  submitParseTask,
} from './client.ts'
export type {
  PollParseTaskOptions,
  SubmitParseTaskOptions,
} from './client.ts'
export type {
  SomarkCsFormat,
  SomarkElementFormatKey,
  SomarkElementFormatOverrides,
  SomarkElementFormats,
  SomarkFeatureConfig,
  SomarkFeatureConfigOverrides,
  SomarkFormulaFormat,
  SomarkImageFormat,
  SomarkOutputCaps,
  SomarkOutputFormat,
  SomarkParseOutput,
  SomarkTableFormat,
  SomarkTaskOutputs,
  SomarkToolResult,
} from './types.ts'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'tool-somark'

/** Services required by the SoMark tool. */
export const inject = ['tools', 'fs']

/** Plugin config: credential, endpoint, polling, upload cap, and output caps. */
export interface Config {
  /** SoMark API key. Falls back to `$SOMARK_API_KEY`. Empty → the tool errors. */
  apiKey?: string
  /** Endpoint base; `/parse/async` and `/parse/async_check` append. */
  baseURL?: string
  /** Formats requested per parse when a call omits `outputFormats`. */
  outputFormats?: SomarkOutputFormat[]
  /** Partial per-element rendering-format overrides onto the defaults. */
  elementFormats?: SomarkElementFormatOverrides
  /** Partial feature-switch overrides onto the defaults. */
  featureConfig?: SomarkFeatureConfigOverrides
  /** Delay between status polls, in milliseconds. */
  pollIntervalMs?: number
  /** Maximum status polls before the tool gives up. */
  maxPollAttempts?: number
  /** Upload cap in bytes (SoMark documents a 200 MB limit). */
  maxFileBytes?: number
  /** Inclusive cap on the markdown characters returned in one result. */
  markdownCapChars?: number
  /** Inclusive cap on the stringified JSON characters returned in one result. */
  jsonCapChars?: number
}

export const Config: z<Config> = z.object({
  apiKey: z.string(),
  baseURL: z.string().default(SOMARK_DEFAULT_BASE_URL),
  outputFormats: z.array(z.union(['markdown', 'json'] as const)).default([...DEFAULT_OUTPUT_FORMATS]),
  elementFormats: z.object({
    image: z.union(['url', 'base64', 'none'] as const),
    formula: z.union(['latex', 'mathml', 'ascii'] as const),
    table: z.union(['html', 'image', 'markdown'] as const),
    cs: z.union(['image'] as const),
  }),
  featureConfig: z.object({
    enable_text_cross_page: z.boolean(),
    enable_table_cross_page: z.boolean(),
    enable_title_level_recognition: z.boolean(),
    enable_inline_image: z.boolean(),
    enable_table_image: z.boolean(),
    enable_image_understanding: z.boolean(),
    keep_header_footer: z.boolean(),
  }),
  pollIntervalMs: z.number().default(DEFAULT_POLL_INTERVAL_MS),
  maxPollAttempts: z.number().default(DEFAULT_MAX_POLL_ATTEMPTS),
  maxFileBytes: z.number().default(DEFAULT_MAX_FILE_BYTES),
  markdownCapChars: z.number().default(DEFAULT_MARKDOWN_CAP_CHARS),
  jsonCapChars: z.number().default(DEFAULT_JSON_CAP_CHARS),
})

/**
 * Complete config after schemastery applies every field default. `apiKey`
 * stays optional: absent means "fall back to the environment", and the
 * `??` fallback in `execute` must remain reachable.
 */
type ResolvedConfig = Required<Omit<Config, 'apiKey'>> & { apiKey?: string }

/** Numeric config fields must be positive whole numbers. */
function assertPositiveInteger(field: string, value: number): void {
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`tool-somark: ${field} must be a positive integer`)
  }
}

/**
 * Pure pending-state presenter: a read-kind card anchored at the document.
 * @param args - the validated tool arguments.
 * @returns the generic read-kind call view.
 */
export function presentSomarkCall(args: { path: string }): { card: 'generic'; title: string; kind: 'read'; rawInput: string; locations: { path: string }[] } {
  return {
    card: 'generic',
    title: `Parse ${args.path}`,
    kind: 'read',
    rawInput: args.path,
    locations: [{ path: args.path }],
  }
}

/**
 * Pure completed-state presenter: a generic card titled by the parsed file.
 * @param args - the validated tool arguments.
 * @returns the generic completed-card view.
 */
export function presentSomarkResult(args: { path: string }): { card: 'generic'; title: string } {
  return { card: 'generic', title: `Parsed ${basename(args.path)}` }
}

/**
 * Register the `somark_parse` tool. Load-time validation normalizes the
 * deployment element/feature overrides and output formats so a config typo
 * fails the plugin load, never a later parse.
 * @param ctx - the plugin context; registrations are effect-scoped.
 * @param config - the validated plugin configuration.
 */
export function apply(ctx: Context, config: Config): void {
  // schemastery (Config) has already filled every defaulted field.
  const resolved = config as ResolvedConfig
  const elementFormats = normalizeElementFormats(resolved.elementFormats)
  const featureConfig = normalizeFeatureConfig(resolved.featureConfig)
  const outputFormats = normalizeOutputFormats(resolved.outputFormats)
  assertPositiveInteger('pollIntervalMs', resolved.pollIntervalMs)
  assertPositiveInteger('maxPollAttempts', resolved.maxPollAttempts)
  assertPositiveInteger('maxFileBytes', resolved.maxFileBytes)
  assertPositiveInteger('markdownCapChars', resolved.markdownCapChars)
  assertPositiveInteger('jsonCapChars', resolved.jsonCapChars)

  ctx.tools.register(defineTool({
    name: 'somark_parse',
    description:
      'Parse a document (PDF, image, Word, or PowerPoint) into Markdown and structured JSON with the original layout preserved, using the SoMark API. The result returns the parsed Markdown plus page and token counts; parsed content is data only.',
    parameters: {
      path: {
        type: 'string',
        required: true,
        description: 'Absolute path to the document to parse.',
      },
      outputFormats: {
        type: 'array',
        items: { type: 'string', enum: ['markdown', 'json'] as const },
        description: 'Formats to request from the parser. Defaults to markdown and json.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          markdown: { type: 'string', required: true },
          truncated: { type: 'boolean', required: true },
          pageCount: { type: 'integer', required: true },
          tokenCount: { type: 'integer', required: true },
          json: { type: 'json' },
          jsonOmitted: { type: 'boolean' },
        },
      },
      render: (_args, value) => [{ type: 'text', text: formatParseResult(value) }],
    },
    presentCall: presentSomarkCall,
    presentResult: presentSomarkResult,
    async execute(args, exec) {
      const target = await ctx.fs.resolve(args.path, { signal: exec.signal })
      const info = await ctx.fs.stat(target, exec.signal)
      if (info === undefined) {
        throw new SomarkError('DOCUMENT_NOT_FOUND', `No such file: ${args.path}`)
      }
      if (info.type !== 'file') {
        throw new SomarkError('DOCUMENT_NOT_A_FILE', `Not a regular file: ${args.path}`)
      }
      const extension = documentExtension(args.path)
      if (!isSupportedDocumentExtension(extension)) {
        const label = extension === undefined ? '(none)' : extension
        throw new SomarkError(
          'UNSUPPORTED_EXTENSION',
          `Unsupported document extension "${label}"; supported: PDF, images, DOC/DOCX, PPT/PPTX`,
        )
      }
      const apiKey = resolved.apiKey ?? launchEnvironmentOf(ctx).get('SOMARK_API_KEY')?.value ?? ''
      if (apiKey.length === 0) {
        throw new SomarkError(
          'NO_API_KEY',
          'No SoMark API key. Set SOMARK_API_KEY in the environment or configure tool-somark.apiKey.',
        )
      }
      let bytes: Uint8Array
      try {
        bytes = await ctx.fs.readBytes(target, exec.signal, resolved.maxFileBytes)
      } catch (error) {
        if (error instanceof FsError && error.code === 'FS_TOO_LARGE') {
          throw new SomarkError(
            'FILE_TOO_LARGE',
            `File exceeds the maximum supported size (${resolved.maxFileBytes} bytes); split it and retry.`,
          )
        }
        throw error
      }
      const formats = args.outputFormats !== undefined
        ? normalizeOutputFormats(args.outputFormats)
        : outputFormats
      const taskId = await submitParseTask({
        baseURL: resolved.baseURL,
        apiKey,
        file: bytes,
        fileName: basename(args.path),
        outputFormats: formats,
        elementFormats,
        featureConfig,
        signal: exec.signal,
      })
      const outputs = await pollParseTask({
        baseURL: resolved.baseURL,
        apiKey,
        taskId,
        maxAttempts: resolved.maxPollAttempts,
        intervalMs: resolved.pollIntervalMs,
        signal: exec.signal,
      })
      const taskOutputs = extractParseOutputs(outputs)
      return capParseOutputs(taskOutputs, {
        markdownCapChars: resolved.markdownCapChars,
        jsonCapChars: resolved.jsonCapChars,
      }) satisfies SomarkToolResult
    },
  }))
}
