/**
 * Type vocabulary for `@deepseek-ai/dsh-tool-somark`: the SoMark request
 * options, parse outputs, canonical tool result, and error codes.
 * @module @deepseek-ai/dsh-tool-somark/types
 */

import type { JsonValue } from '@deepseek-ai/dsh-session'

/** One format the SoMark parser can produce per document. */
export type SomarkOutputFormat = 'markdown' | 'json'

/** Allowed rendering value for the `image` element key. */
export type SomarkImageFormat = 'url' | 'base64' | 'none'
/** Allowed rendering value for the `formula` element key. */
export type SomarkFormulaFormat = 'latex' | 'mathml' | 'ascii'
/** Allowed rendering value for the `table` element key. */
export type SomarkTableFormat = 'html' | 'image' | 'markdown'
/** Allowed rendering value for the `cs` element key. */
export type SomarkCsFormat = 'image'

/** Keys of the per-element rendering-format option. */
export type SomarkElementFormatKey = 'image' | 'formula' | 'table' | 'cs'

/** Per-element rendering formats sent with every parse request. */
export interface SomarkElementFormats {
  /** Rendering format for images: `url` (SoMark-hosted), `base64`, or `none`. */
  image: SomarkImageFormat
  /** Rendering format for formulas: `latex`, `mathml`, or `ascii`. */
  formula: SomarkFormulaFormat
  /** Rendering format for tables: `html`, `image`, or `markdown`. */
  table: SomarkTableFormat
  /** Rendering format for chemical expressions; SoMark supports `image`. */
  cs: SomarkCsFormat
}

/** Feature switches sent with every parse request. */
export interface SomarkFeatureConfig {
  /** Merge text content across page boundaries. */
  enable_text_cross_page: boolean
  /** Merge tables across page boundaries. */
  enable_table_cross_page: boolean
  /** Recognize heading and title levels. */
  enable_title_level_recognition: boolean
  /** Include inline image output. */
  enable_inline_image: boolean
  /** Include table image output. */
  enable_table_image: boolean
  /** Enable image understanding features. */
  enable_image_understanding: boolean
  /** Preserve header and footer content. */
  keep_header_footer: boolean
}

/**
 * Config-facing element-format overrides: each key accepts its allowed value,
 * or `null` to unset it (schemastery's object-field vocabulary) and fall back
 * to the default.
 */
export type SomarkElementFormatOverrides = Partial<{
  /** Override for `image`; `null` keeps the default. */
  image: SomarkImageFormat | null
  /** Override for `formula`; `null` keeps the default. */
  formula: SomarkFormulaFormat | null
  /** Override for `table`; `null` keeps the default. */
  table: SomarkTableFormat | null
  /** Override for `cs`; `null` keeps the default. */
  cs: SomarkCsFormat | null
}>

/** Config-facing feature-switch overrides: booleans, or `null` to unset. */
export type SomarkFeatureConfigOverrides = Partial<{
  /** Override for `enable_text_cross_page`; `null` keeps the default. */
  enable_text_cross_page: boolean | null
  /** Override for `enable_table_cross_page`; `null` keeps the default. */
  enable_table_cross_page: boolean | null
  /** Override for `enable_title_level_recognition`; `null` keeps the default. */
  enable_title_level_recognition: boolean | null
  /** Override for `enable_inline_image`; `null` keeps the default. */
  enable_inline_image: boolean | null
  /** Override for `enable_table_image`; `null` keeps the default. */
  enable_table_image: boolean | null
  /** Override for `enable_image_understanding`; `null` keeps the default. */
  enable_image_understanding: boolean | null
  /** Override for `keep_header_footer`; `null` keeps the default. */
  keep_header_footer: boolean | null
}>

/** The `outputs` object a successful SoMark task returns. */
export interface SomarkParseOutput {
  /** Parsed Markdown, present when `markdown` was requested. */
  markdown?: string
  /** Parsed structured JSON, present when `json` was requested. */
  json?: JsonValue
}

/** Normalized parse output plus the metadata extracted from the JSON payload. */
export interface SomarkTaskOutputs {
  /** Parsed Markdown (empty string when SoMark returned none). */
  markdown: string
  /** Parsed structured JSON, when requested and returned. */
  json?: JsonValue
  /** Page count reported in the JSON metadata, or 0 when absent. */
  pageCount: number
  /** Token count reported in the JSON metadata, or 0 when absent. */
  tokenCount: number
}

/** The canonical value `somark_parse` returns after output caps apply. */
export interface SomarkToolResult {
  /** Parsed Markdown, capped at the configured markdown cap. */
  markdown: string
  /** True when the markdown cap cut the returned content. */
  truncated: boolean
  /** Page count reported in the JSON metadata, or 0 when absent. */
  pageCount: number
  /** Token count reported in the JSON metadata, or 0 when absent. */
  tokenCount: number
  /** Parsed structured JSON, when requested and within the JSON cap. */
  json?: JsonValue
  /** True when JSON was requested but omitted because it exceeded the cap. */
  jsonOmitted?: boolean
}

/** Output caps applied to one canonical tool result. */
export interface SomarkOutputCaps {
  /** Inclusive cap on the returned markdown characters. */
  markdownCapChars: number
  /** Inclusive cap on the stringified returned JSON characters. */
  jsonCapChars: number
}

/** Stable, machine-routable failure codes for the SoMark tool. */
export type SomarkErrorCode =
  | 'NO_API_KEY'
  | 'DOCUMENT_NOT_FOUND'
  | 'DOCUMENT_NOT_A_FILE'
  | 'UNSUPPORTED_EXTENSION'
  | 'FILE_TOO_LARGE'
  | 'CONFIG_INVALID'
  | 'SUBMIT_FAILED'
  | 'TASK_FAILED'
  | 'POLL_TIMEOUT'
  | 'ABORTED'
  | 'REQUEST_FAILED'
  | 'INVALID_RESPONSE'
