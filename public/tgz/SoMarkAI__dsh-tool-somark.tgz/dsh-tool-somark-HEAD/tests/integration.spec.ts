/**
 * Real-composition integration: the local filesystem backend (`dsh-fs-local`)
 * + the real tool registry (`dsh-tools`) + the SoMark tool plugin, exercised
 * through `ctx.tools.execute()` with only the external SoMark HTTP service
 * replaced by a loopback server. Nothing bypasses the tool registry; the
 * multipart upload and the poll round-trip run against real fetch and real
 * FormData, and the file read runs against the real filesystem.
 */

import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { createServer, type Server, type ServerResponse } from 'node:http'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { AddressInfo } from 'node:net'
import { Context } from '@deepseek-ai/cordis'
import { CallId } from '@deepseek-ai/dsh-llm'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime, { type ToolExecutionResult } from '@deepseek-ai/dsh-tools'
import LocalFileSystem from '@deepseek-ai/dsh-fs-local'
import * as ToolSomark from '../src/index.ts'

const testToolSignal = new AbortController().signal

let server: Server
let base: string
let uploadBody: Buffer | undefined
let uploadCount: number
let checkCount: number
let checkStatus: 'SUCCESS' | 'FAILED' | 'PENDING'
let ctx: Context
let fiber: Awaited<ReturnType<Context['plugin']>>
let tmpDir: string

function sendJson(res: ServerResponse, body: unknown): void {
  res.writeHead(200, { 'content-type': 'application/json' })
  res.end(JSON.stringify(body))
}

beforeEach(async () => {
  uploadBody = undefined
  uploadCount = 0
  checkCount = 0
  checkStatus = 'SUCCESS'
  server = createServer((req, res) => {
    const chunks: Buffer[] = []
    req.on('data', chunk => chunks.push(chunk as Buffer))
    req.on('end', () => {
      const body = Buffer.concat(chunks)
      if (req.url === '/parse/async') {
        uploadCount += 1
        uploadBody = body
        sendJson(res, { data: { task_id: 't-1' } })
      } else if (req.url === '/parse/async_check') {
        checkCount += 1
        if (checkStatus === 'SUCCESS') {
          sendJson(res, {
            data: {
              status: 'SUCCESS',
              result: {
                outputs: {
                  markdown: 'parsed markdown',
                  json: { metadata: { page_count: 2, token_count: 7 } },
                },
              },
            },
          })
        } else {
          sendJson(res, { data: { status: checkStatus, reason: 'boom' } })
        }
      } else {
        res.writeHead(404)
        res.end()
      }
    })
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`

  tmpDir = mkdtempSync(join(tmpdir(), 'dsh-somark-'))
  writeFileSync(join(tmpDir, 'sample.pdf'), 'hello from somark')

  ctx = new Context()
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(LocalFileSystem)
  fiber = await ctx.plugin(ToolSomark, { apiKey: 'k', baseURL: base, pollIntervalMs: 1 })
})

afterEach(async () => {
  await fiber.dispose()
  rmSync(tmpDir, { recursive: true, force: true })
  await new Promise<void>(resolve => server.close(() => { resolve() }))
})

let counter = 0
function call(name: string, args: unknown): Promise<ToolExecutionResult> {
  return ctx.tools.execute({ signal: testToolSignal, callId: CallId(`call-${++counter}`), name, arguments: args })
}

describe('somark_parse integration over the real stack', () => {
  it('uploads the document, polls to completion, and renders the parse result', async () => {
    const out = await call('somark_parse', { path: join(tmpDir, 'sample.pdf') })
    expect(out.isError).toBe(false)
    const text = out.content.map(b => b.type === 'text' ? b.text : '').join('')
    expect(text).toContain('Parsed 2 page(s), 7 token(s).')
    expect(text).toContain('parsed markdown')

    // The real multipart upload reached the server with the file and the key.
    expect(uploadCount).toBe(1)
    expect(checkCount).toBe(1)
    expect(uploadBody!.includes(Buffer.from('name="api_key"'))).toBe(true)
    expect(uploadBody!.includes(Buffer.from('name="file"'))).toBe(true)
    expect(uploadBody!.includes(Buffer.from('hello from somark'))).toBe(true)
    expect(uploadBody!.includes(Buffer.from('sample.pdf'))).toBe(true)
  })

  it('surfaces a SoMark task failure through the real stack', async () => {
    checkStatus = 'FAILED'
    const out = await call('somark_parse', { path: join(tmpDir, 'sample.pdf') })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('TASK_FAILED')
  })

  it('surfaces a missing file through the real filesystem backend', async () => {
    const out = await call('somark_parse', { path: join(tmpDir, 'missing.pdf') })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('DOCUMENT_NOT_FOUND')
  })
})
