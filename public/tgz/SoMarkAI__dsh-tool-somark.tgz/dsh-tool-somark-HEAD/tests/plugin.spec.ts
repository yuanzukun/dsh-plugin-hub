/**
 * Tool-level tests for `somark_parse` over a fake `ctx.fs` provider and the
 * real tool registry: schema shape, execution flow, error codes, config
 * validation, and the env-var API key fallback. The external SoMark service
 * boundary (global `fetch`) is the only thing stubbed.
 */

import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { CallId } from '@deepseek-ai/dsh-llm'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime, { type ToolExecutionResult } from '@deepseek-ai/dsh-tools'
import { FileSystem, FsError, FsTargetKey, FsVersion } from '@deepseek-ai/dsh-fs'
import type { FsInfo, FsTarget } from '@deepseek-ai/dsh-fs'
import * as ToolSomark from '../src/index.ts'
import {
  DEFAULT_ELEMENT_FORMATS,
  DEFAULT_FEATURE_CONFIG,
  presentSomarkCall,
  presentSomarkResult,
} from '../src/index.ts'
import type { SomarkElementFormatOverrides } from '../src/index.ts'

const testToolSignal = new AbortController().signal

/** An in-memory fake `ctx.fs` provider for the tool under test. */
class FakeFs extends FileSystem {
  files = new Map<string, string>()
  dirs = new Set<string>()
  readError?: Error

  override async resolve(path: string): Promise<FsTarget> {
    return { targetKey: FsTargetKey(path), displayPath: path }
  }
  override processPath(target: FsTarget): string { return String(target.targetKey) }
  override fileUrl(target: FsTarget): string { return `file://${target.targetKey}` }
  override contains(parent: FsTarget, child: FsTarget): boolean {
    return child.targetKey === parent.targetKey || String(child.targetKey).startsWith(`${parent.targetKey}/`)
  }
  override async stat(target: FsTarget): Promise<FsInfo | undefined> {
    if (this.dirs.has(target.targetKey)) return { version: FsVersion('v1'), type: 'directory' }
    if (!this.files.has(target.targetKey)) return undefined
    return { version: FsVersion('v1'), type: 'file', size: this.files.get(target.targetKey)!.length }
  }
  override async lstat(): Promise<undefined> { return undefined }
  override async readText(target: FsTarget): Promise<string> {
    return this.files.get(target.targetKey) ?? ''
  }
  override async streamText(_target: FsTarget): Promise<AsyncIterable<string>> {
    return (async function* () {})()
  }
  override async readBytes(target: FsTarget, _signal: AbortSignal | undefined, maxBytes: number): Promise<Uint8Array> {
    if (this.readError !== undefined) throw this.readError
    const bytes = new TextEncoder().encode(this.files.get(target.targetKey) ?? '')
    if (bytes.length > maxBytes) {
      throw new FsError(`too large: ${target.displayPath}`, 'FS_TOO_LARGE')
    }
    return bytes
  }
  override async listDir(): Promise<never> { throw new Error('unused') }
  override async writeText(): Promise<never> { throw new Error('unused') }
  override async editText(): Promise<never> { throw new Error('unused') }
}

/** A Response whose `json()` resolves to the given body. */
function jsonResponse(body: unknown, ok = true, status = 200): Response {
  return { ok, status, json: async () => body } as unknown as Response
}

/** The two-call happy-path fetch sequence: submit then SUCCESS. */
function happyFetch(): ReturnType<typeof vi.fn> {
  return vi.fn(async (_input: string) => {
    if (_input.endsWith('/parse/async')) return jsonResponse({ data: { task_id: 't-1' } })
    return jsonResponse({
      data: {
        status: 'SUCCESS',
        result: { outputs: { markdown: 'parsed content', json: { metadata: { page_count: 3, token_count: 50 } } } },
      },
    })
  })
}

/** Mount the registry, fake fs, and tool plugin; return an executor helper. */
async function mount(config?: ToolSomark.Config) {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(FakeFs)
  const fiber = await ctx.plugin(ToolSomark, config ?? {})
  let counter = 0
  const call = (name: string, args: unknown): Promise<ToolExecutionResult> =>
    ctx.tools.execute({ signal: testToolSignal, callId: CallId(`call-${++counter}`), name, arguments: args })
  return { ctx, fiber, fs: ctx.fs as FakeFs, call }
}

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('somark_parse registration', () => {
  it('registers the tool with a required path and optional outputFormats', async () => {
    const { ctx, fiber } = await mount()
    const schema = ctx.tools.schemas().find(s => s.name === 'somark_parse')
    expect(schema).toBeDefined()
    const parameters = schema!.parameters as { properties: Record<string, unknown>; required?: string[] }
    expect(Object.keys(parameters.properties)).toEqual(['path', 'outputFormats'])
    expect(parameters.required).toContain('path')
    await fiber.dispose()
  })

  it('presents the call as a read-kind card with the file location', () => {
    expect(presentSomarkCall({ path: '/tmp/doc.pdf' })).toEqual({
      card: 'generic',
      title: 'Parse /tmp/doc.pdf',
      kind: 'read',
      rawInput: '/tmp/doc.pdf',
      locations: [{ path: '/tmp/doc.pdf' }],
    })
    expect(presentSomarkResult({ path: '/tmp/doc.pdf' })).toEqual({ card: 'generic', title: 'Parsed doc.pdf' })
  })
})

describe('somark_parse execution', () => {
  it('parses a document end-to-end and renders the summary', async () => {
    const fetchMock = happyFetch()
    vi.stubGlobal('fetch', fetchMock)
    const { fiber, fs, call } = await mount({ apiKey: 'k', baseURL: 'https://somark.test/v1' })
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(false)
    const text = out.content.map(b => b.type === 'text' ? b.text : '').join('')
    expect(text).toContain('Parsed 3 page(s), 50 token(s).')
    expect(text).toContain('parsed content')
    expect(fetchMock).toHaveBeenCalledTimes(2)
    const submitInit = fetchMock.mock.calls[0]![1] as RequestInit
    const form = submitInit.body as FormData
    expect(form.get('api_key')).toBe('k')
    expect((form.get('file') as File).name).toBe('doc.pdf')
    expect(form.get('element_formats')).toBe(JSON.stringify(DEFAULT_ELEMENT_FORMATS))
    expect(form.get('feature_config')).toBe(JSON.stringify(DEFAULT_FEATURE_CONFIG))
    await fiber.dispose()
  })

  it('honors a per-call outputFormats override', async () => {
    const fetchMock = vi.fn(async (input: string, init: RequestInit) => {
      if (input.endsWith('/parse/async')) {
        const form = init.body as FormData
        expect(form.getAll('output_formats')).toEqual(['markdown'])
        return jsonResponse({ data: { task_id: 't-1' } })
      }
      return jsonResponse({ data: { status: 'SUCCESS', result: { outputs: { markdown: 'md' } } } })
    })
    vi.stubGlobal('fetch', fetchMock)
    const { fiber, fs, call } = await mount({ apiKey: 'k' })
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf', outputFormats: ['markdown'] })
    expect(out.isError).toBe(false)
    await fiber.dispose()
  })

  it('reads the API key from the environment when config omits it', async () => {
    const fetchMock = vi.fn(async (input: string, init: RequestInit) => {
      if (input.endsWith('/parse/async')) {
        const form = init.body as FormData
        expect(form.get('api_key')).toBe('env-key')
        return jsonResponse({ data: { task_id: 't-1' } })
      }
      return jsonResponse({ data: { status: 'SUCCESS', result: { outputs: { markdown: 'md' } } } })
    })
    vi.stubGlobal('fetch', fetchMock)
    vi.stubEnv('SOMARK_API_KEY', 'env-key')
    const { fiber, fs, call } = await mount()
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(false)
    await fiber.dispose()
  })

  it('fails with NO_API_KEY when neither config nor env provides one', async () => {
    vi.stubEnv('SOMARK_API_KEY', '')
    const { fiber, fs, call } = await mount()
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('NO_API_KEY')
    await fiber.dispose()
  })

  it('fails with NO_API_KEY when the variable is absent from the environment', async () => {
    const hadKey = Object.hasOwn(process.env, 'SOMARK_API_KEY')
    const saved = process.env.SOMARK_API_KEY
    delete process.env.SOMARK_API_KEY
    try {
      const { fiber, fs, call } = await mount()
      fs.files.set('/tmp/doc.pdf', 'pdf bytes')
      const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
      expect(out.isError).toBe(true)
      expect(out.error?.info?.code).toBe('NO_API_KEY')
      await fiber.dispose()
    } finally {
      if (hadKey) process.env.SOMARK_API_KEY = saved
    }
  })

  it('fails with DOCUMENT_NOT_FOUND for a missing path', async () => {
    const { fiber, call } = await mount({ apiKey: 'k' })
    const out = await call('somark_parse', { path: '/tmp/missing.pdf' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('DOCUMENT_NOT_FOUND')
    await fiber.dispose()
  })

  it('fails with DOCUMENT_NOT_A_FILE for a directory', async () => {
    const { fiber, fs, call } = await mount({ apiKey: 'k' })
    fs.dirs.add('/tmp/folder')
    const out = await call('somark_parse', { path: '/tmp/folder' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('DOCUMENT_NOT_A_FILE')
    await fiber.dispose()
  })

  it('fails with UNSUPPORTED_EXTENSION for an unknown extension', async () => {
    const { fiber, fs, call } = await mount({ apiKey: 'k' })
    fs.files.set('/tmp/notes.txt', 'text')
    const out = await call('somark_parse', { path: '/tmp/notes.txt' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('UNSUPPORTED_EXTENSION')
    await fiber.dispose()
  })

  it('fails with UNSUPPORTED_EXTENSION for a path without an extension', async () => {
    const { fiber, fs, call } = await mount({ apiKey: 'k' })
    fs.files.set('/tmp/notes', 'text')
    const out = await call('somark_parse', { path: '/tmp/notes' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('UNSUPPORTED_EXTENSION')
    expect(out.content.map(b => b.type === 'text' ? b.text : '').join('')).toContain('(none)')
    await fiber.dispose()
  })

  it('passes through a non-size filesystem read failure', async () => {
    const { fiber, fs, call } = await mount({ apiKey: 'k' })
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    fs.readError = new Error('backend exploded')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(true)
    expect(out.content.map(b => b.type === 'text' ? b.text : '').join('')).toContain('backend exploded')
    await fiber.dispose()
  })

  it('fails with FILE_TOO_LARGE when the read exceeds the upload cap', async () => {
    const { fiber, fs, call } = await mount({ apiKey: 'k', maxFileBytes: 5 })
    fs.files.set('/tmp/big.pdf', 'way more than five bytes')
    const out = await call('somark_parse', { path: '/tmp/big.pdf' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('FILE_TOO_LARGE')
    await fiber.dispose()
  })

  it('surfaces a rejected submission as SUBMIT_FAILED', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => jsonResponse({}, false, 500)))
    const { fiber, fs, call } = await mount({ apiKey: 'k' })
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('SUBMIT_FAILED')
    await fiber.dispose()
  })

  it('surfaces a SoMark FAILED status as TASK_FAILED', async () => {
    vi.stubGlobal('fetch', vi.fn(async (input: string) => {
      if (input.endsWith('/parse/async')) return jsonResponse({ data: { task_id: 't-1' } })
      return jsonResponse({ data: { status: 'FAILED', reason: 'corrupt' } })
    }))
    const { fiber, fs, call } = await mount({ apiKey: 'k' })
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('TASK_FAILED')
    await fiber.dispose()
  })

  it('fails with POLL_TIMEOUT when the task never completes', async () => {
    vi.stubGlobal('fetch', vi.fn(async (input: string) => {
      if (input.endsWith('/parse/async')) return jsonResponse({ data: { task_id: 't-1' } })
      return jsonResponse({ data: { status: 'PENDING' } })
    }))
    const { fiber, fs, call } = await mount({ apiKey: 'k', maxPollAttempts: 2, pollIntervalMs: 1 })
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(true)
    expect(out.error?.info?.code).toBe('POLL_TIMEOUT')
    await fiber.dispose()
  })

  it('caps the returned markdown and flags truncation', async () => {
    vi.stubGlobal('fetch', vi.fn(async (input: string) => {
      if (input.endsWith('/parse/async')) return jsonResponse({ data: { task_id: 't-1' } })
      return jsonResponse({ data: { status: 'SUCCESS', result: { outputs: { markdown: 'long markdown body', json: { metadata: { page_count: 1, token_count: 2 } } } } } })
    }))
    const { fiber, fs, call } = await mount({ apiKey: 'k', markdownCapChars: 5, jsonCapChars: 4 })
    fs.files.set('/tmp/doc.pdf', 'pdf bytes')
    const out = await call('somark_parse', { path: '/tmp/doc.pdf' })
    expect(out.isError).toBe(false)
    const text = out.content.map(b => b.type === 'text' ? b.text : '').join('')
    expect(text).toContain('long ')
    expect(text).toContain('[Markdown truncated at the configured output cap; the parse itself is complete.]')
    expect(text).toContain('[JSON omitted: larger than the configured output cap.]')
    await fiber.dispose()
  })
})

describe('somark_parse config validation', () => {
  it.each([
    ['an empty outputFormats list', { outputFormats: [] }, /At least one output format/],
    ['an unsupported element format', { elementFormats: { image: 'bogus' } as unknown as SomarkElementFormatOverrides }, /invalid config/],
    ['an unknown feature key', { featureConfig: { bogus: true } as never }, /Unknown feature config/],
    ['a non-integer pollIntervalMs', { pollIntervalMs: 1.5 }, /pollIntervalMs must be a positive integer/],
    ['a zero maxPollAttempts', { maxPollAttempts: 0 }, /maxPollAttempts must be a positive integer/],
    ['a zero maxFileBytes', { maxFileBytes: 0 }, /maxFileBytes must be a positive integer/],
    ['a zero markdownCapChars', { markdownCapChars: 0 }, /markdownCapChars must be a positive integer/],
    ['a zero jsonCapChars', { jsonCapChars: 0 }, /jsonCapChars must be a positive integer/],
  ])('rejects %s at load', async (_label, config, message) => {
    const ctx = new Context()
    await ctx.plugin(SystemPrompt)
    await ctx.plugin(ToolRuntime)
    await ctx.plugin(FakeFs)
    await expect(ctx.plugin(ToolSomark, config)).rejects.toThrow(message)
  })
})
