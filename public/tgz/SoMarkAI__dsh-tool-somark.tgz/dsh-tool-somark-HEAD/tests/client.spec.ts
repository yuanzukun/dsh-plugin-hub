/**
 * Unit tests for the SoMark API client: option normalization, multipart
 * submission, status polling, metadata extraction, output capping, and result
 * formatting. The global `fetch` is stubbed per test; nothing here touches a
 * real network or the Cordis context.
 */

import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  capParseOutputs,
  DEFAULT_ELEMENT_FORMATS,
  DEFAULT_FEATURE_CONFIG,
  documentExtension,
  extractParseOutputs,
  formatParseResult,
  isSupportedDocumentExtension,
  normalizeElementFormats,
  normalizeFeatureConfig,
  normalizeOutputFormats,
  pollParseTask,
  SOMARK_CHECK_PATH,
  SOMARK_PARSE_PATH,
  SomarkError,
  submitParseTask,
} from '../src/index.ts'
import type { SomarkElementFormatOverrides } from '../src/index.ts'

afterEach(() => {
  vi.unstubAllGlobals()
})

/** A Response whose `json()` resolves to the given body. */
function jsonResponse(body: unknown, ok = true, status = 200): Response {
  return { ok, status, json: async () => body } as unknown as Response
}

/** A Response whose `json()` throws (a non-JSON body). */
function brokenJsonResponse(ok = true, status = 200): Response {
  return { ok, status, json: async () => { throw new SyntaxError('not json') } } as unknown as Response
}

/** A fetch stub that serves queued responses (or throwing thunks) in order. */
function queuedFetch(...entries: (Response | (() => never))[]): ReturnType<typeof vi.fn> {
  let index = 0
  return vi.fn(async () => {
    const entry = entries[index++]
    if (typeof entry === 'function') return entry()
    return entry
  })
}

describe('documentExtension', () => {
  it('returns the lowercased extension of a path', () => {
    expect(documentExtension('/tmp/Report.PDF')).toBe('pdf')
    expect(documentExtension('notes.docx')).toBe('docx')
  })

  it('returns undefined for a path without an extension', () => {
    expect(documentExtension('notes')).toBeUndefined()
  })

  it('returns undefined for a trailing dot', () => {
    expect(documentExtension('notes.')).toBeUndefined()
  })
})

describe('isSupportedDocumentExtension', () => {
  it('accepts the documented formats', () => {
    expect(isSupportedDocumentExtension('pdf')).toBe(true)
    expect(isSupportedDocumentExtension('png')).toBe(true)
    expect(isSupportedDocumentExtension('pptx')).toBe(true)
  })

  it('rejects undefined and unknown extensions', () => {
    expect(isSupportedDocumentExtension(undefined)).toBe(false)
    expect(isSupportedDocumentExtension('exe')).toBe(false)
  })
})

describe('normalizeElementFormats', () => {
  it('returns the defaults when nothing is configured', () => {
    expect(normalizeElementFormats()).toEqual(DEFAULT_ELEMENT_FORMATS)
  })

  it('merges partial overrides onto the defaults', () => {
    expect(normalizeElementFormats({ table: 'markdown' })).toEqual({
      ...DEFAULT_ELEMENT_FORMATS,
      table: 'markdown',
    })
  })

  it('rejects an unsupported value for a known key', () => {
    expect(() => normalizeElementFormats({ image: 'bogus' } as unknown as SomarkElementFormatOverrides))
      .toThrow(/Unsupported element format/)
  })

  it('rejects a non-string value for a known key', () => {
    expect(() => normalizeElementFormats({ image: 42 } as unknown as SomarkElementFormatOverrides))
      .toThrow(/Unsupported element format/)
  })

  it('rejects an unknown key', () => {
    expect(() => normalizeElementFormats({ bogus: 'x' } as never)).toThrow(/Unsupported element format/)
  })

  it('keeps the default for a null override', () => {
    expect(normalizeElementFormats({ image: null })).toEqual(DEFAULT_ELEMENT_FORMATS)
  })
})

describe('normalizeFeatureConfig', () => {
  it('returns the defaults when nothing is configured', () => {
    expect(normalizeFeatureConfig()).toEqual(DEFAULT_FEATURE_CONFIG)
  })

  it('merges partial overrides onto the defaults', () => {
    expect(normalizeFeatureConfig({ enable_inline_image: false })).toEqual({
      ...DEFAULT_FEATURE_CONFIG,
      enable_inline_image: false,
    })
  })

  it('rejects an unknown key', () => {
    expect(() => normalizeFeatureConfig({ bogus: true } as never)).toThrow(/Unknown feature config/)
  })

  it('rejects a non-boolean value', () => {
    expect(() => normalizeFeatureConfig({ keep_header_footer: 'yes' as unknown as boolean }))
      .toThrow(/must be a boolean/)
  })

  it('keeps the default for a null override', () => {
    expect(normalizeFeatureConfig({ enable_inline_image: null })).toEqual(DEFAULT_FEATURE_CONFIG)
  })
})

describe('normalizeOutputFormats', () => {
  it('validates and preserves a supported list', () => {
    expect(normalizeOutputFormats(['json', 'markdown'])).toEqual(['json', 'markdown'])
  })

  it('rejects an empty list', () => {
    expect(() => normalizeOutputFormats([])).toThrow(/At least one output format/)
  })

  it('rejects an unsupported format', () => {
    expect(() => normalizeOutputFormats(['html'])).toThrow(/Unsupported output format/)
  })
})

describe('submitParseTask', () => {
  const options = {
    baseURL: 'https://somark.test/v1',
    apiKey: 'k',
    file: new Uint8Array([1, 2, 3]),
    fileName: 'doc.pdf',
    outputFormats: ['markdown', 'json'] as const,
    elementFormats: DEFAULT_ELEMENT_FORMATS,
    featureConfig: DEFAULT_FEATURE_CONFIG,
  }

  it('uploads a multipart form and returns the task id', async () => {
    const fetchMock = vi.fn(async (_input: string, init: RequestInit) => {
      const form = init.body as FormData
      expect(init.method).toBe('POST')
      expect(_input).toBe(`https://somark.test/v1${SOMARK_PARSE_PATH}`)
      expect(form.get('api_key')).toBe('k')
      const file = form.get('file') as File
      expect(file.name).toBe('doc.pdf')
      expect(form.getAll('output_formats')).toEqual(['markdown', 'json'])
      expect(form.get('element_formats')).toBe(JSON.stringify(DEFAULT_ELEMENT_FORMATS))
      expect(form.get('feature_config')).toBe(JSON.stringify(DEFAULT_FEATURE_CONFIG))
      return jsonResponse({ data: { task_id: 't-1' } })
    })
    vi.stubGlobal('fetch', fetchMock)
    await expect(submitParseTask(options)).resolves.toBe('t-1')
  })

  it('fails with SUBMIT_FAILED on a non-2xx status', async () => {
    vi.stubGlobal('fetch', queuedFetch(jsonResponse({}, false, 500)))
    const promise = submitParseTask(options)
    await expect(promise).rejects.toMatchObject({ code: 'SUBMIT_FAILED' })
    await expect(promise).rejects.toThrow(/HTTP 500/)
  })

  it('fails with INVALID_RESPONSE on a non-JSON body', async () => {
    vi.stubGlobal('fetch', queuedFetch(brokenJsonResponse()))
    await expect(submitParseTask(options)).rejects.toMatchObject({ code: 'INVALID_RESPONSE' })
  })

  it('fails with INVALID_RESPONSE when the body carries no task_id', async () => {
    vi.stubGlobal('fetch', queuedFetch(jsonResponse({ data: {} })))
    await expect(submitParseTask(options)).rejects.toMatchObject({ code: 'INVALID_RESPONSE' })
  })

  it('surfaces an abort as ABORTED', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new DOMException('aborted', 'AbortError') }))
    await expect(submitParseTask(options)).rejects.toMatchObject({ code: 'ABORTED' })
  })

  it('surfaces a network failure as REQUEST_FAILED', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('connection refused') }))
    await expect(submitParseTask(options)).rejects.toMatchObject({ code: 'REQUEST_FAILED' })
  })
})

describe('pollParseTask', () => {
  const options = {
    baseURL: 'https://somark.test/v1',
    apiKey: 'k',
    taskId: 't-1',
    maxAttempts: 5,
    intervalMs: 1,
  }

  it('returns the outputs on SUCCESS', async () => {
    const fetchMock = vi.fn(async (input: string, init: RequestInit) => {
      expect(input).toBe(`https://somark.test/v1${SOMARK_CHECK_PATH}`)
      const body = init.body as URLSearchParams
      expect(body.get('api_key')).toBe('k')
      expect(body.get('task_id')).toBe('t-1')
      return jsonResponse({ data: { status: 'SUCCESS', result: { outputs: { markdown: 'md', json: { a: 1 } } } } })
    })
    vi.stubGlobal('fetch', fetchMock)
    await expect(pollParseTask(options)).resolves.toEqual({ markdown: 'md', json: { a: 1 } })
  })

  it('falls back to the result object when it has no outputs key', async () => {
    vi.stubGlobal('fetch', queuedFetch(jsonResponse({ data: { status: 'SUCCESS', result: { markdown: 'md' } } })))
    await expect(pollParseTask(options)).resolves.toEqual({ markdown: 'md' })
  })

  it('throws TASK_FAILED when SoMark reports FAILED', async () => {
    vi.stubGlobal('fetch', queuedFetch(jsonResponse({ data: { status: 'FAILED', reason: 'bad file' } })))
    await expect(pollParseTask(options)).rejects.toMatchObject({ code: 'TASK_FAILED' })
  })

  it('keeps polling across PENDING and transient check failures', async () => {
    const fetchMock = queuedFetch(
      jsonResponse({ data: { status: 'PENDING' } }),
      jsonResponse({}, false, 502),
      brokenJsonResponse(),
      jsonResponse({ data: { status: 'SUCCESS', result: { outputs: { markdown: 'md' } } } }),
    )
    vi.stubGlobal('fetch', fetchMock)
    await expect(pollParseTask(options)).resolves.toEqual({ markdown: 'md' })
    expect(fetchMock).toHaveBeenCalledTimes(4)
  })

  it('retries a transient network failure', async () => {
    vi.stubGlobal('fetch', queuedFetch(
      () => { throw new Error('blip') },
      jsonResponse({ data: { status: 'SUCCESS', result: { outputs: { markdown: 'md' } } } }),
    ))
    await expect(pollParseTask(options)).resolves.toEqual({ markdown: 'md' })
  })

  it('throws POLL_TIMEOUT when the task never finishes', async () => {
    vi.stubGlobal('fetch', queuedFetch(
      jsonResponse({ data: { status: 'PENDING' } }),
      jsonResponse({ data: { status: 'PENDING' } }),
    ))
    const promise = pollParseTask({ ...options, maxAttempts: 2 })
    await expect(promise).rejects.toMatchObject({ code: 'POLL_TIMEOUT' })
    await expect(promise).rejects.toThrow(/t-1/)
  })

  it('surfaces an abort during the check request as ABORTED', async () => {
    vi.stubGlobal('fetch', queuedFetch(
      () => { throw new DOMException('aborted', 'AbortError') },
    ))
    await expect(pollParseTask({ ...options, maxAttempts: 2 })).rejects.toMatchObject({ code: 'ABORTED' })
  })

  it('surfaces an abort during the wait as ABORTED', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => jsonResponse({ data: { status: 'PENDING' } })))
    const controller = new AbortController()
    const promise = pollParseTask({ ...options, maxAttempts: 5, intervalMs: 50, signal: controller.signal })
    setTimeout(() => { controller.abort() }, 5)
    await expect(promise).rejects.toMatchObject({ code: 'ABORTED' })
  })

  it('rejects immediately for an already-aborted signal', async () => {
    const controller = new AbortController()
    controller.abort()
    await expect(pollParseTask({ ...options, maxAttempts: 1, intervalMs: 1000, signal: controller.signal }))
      .rejects.toMatchObject({ code: 'ABORTED' })
  })
})

describe('extractParseOutputs', () => {
  it('extracts markdown, json, and numeric metadata', () => {
    expect(extractParseOutputs({
      markdown: 'md',
      json: { metadata: { page_count: 3, token_count: 100 } },
    })).toEqual({ markdown: 'md', json: { metadata: { page_count: 3, token_count: 100 } }, pageCount: 3, tokenCount: 100 })
  })

  it('defaults markdown to an empty string when it is not a string', () => {
    expect(extractParseOutputs({ markdown: 42 as never })).toEqual({ markdown: '', pageCount: 0, tokenCount: 0 })
  })

  it('omits json when the payload carries none', () => {
    expect(extractParseOutputs({ markdown: 'md' })).toEqual({ markdown: 'md', pageCount: 0, tokenCount: 0 })
  })

  it('treats a json payload without metadata as zero counts', () => {
    expect(extractParseOutputs({ markdown: 'md', json: { text: 'x' } }))
      .toEqual({ markdown: 'md', json: { text: 'x' }, pageCount: 0, tokenCount: 0 })
  })

  it('treats non-numeric metadata as zero counts', () => {
    expect(extractParseOutputs({ markdown: 'md', json: { metadata: { page_count: 'x', token_count: null } } }))
      .toEqual({ markdown: 'md', json: { metadata: { page_count: 'x', token_count: null } }, pageCount: 0, tokenCount: 0 })
  })

  it('keeps a null json payload', () => {
    expect(extractParseOutputs({ markdown: 'md', json: null }))
      .toEqual({ markdown: 'md', json: null, pageCount: 0, tokenCount: 0 })
  })
})

describe('capParseOutputs', () => {
  it('passes outputs through when both are within their caps', () => {
    expect(capParseOutputs({ markdown: 'md', json: { a: 1 }, pageCount: 1, tokenCount: 2 }, {
      markdownCapChars: 100,
      jsonCapChars: 100,
    })).toEqual({ markdown: 'md', truncated: false, pageCount: 1, tokenCount: 2, json: { a: 1 } })
  })

  it('truncates markdown over the cap and flags it', () => {
    expect(capParseOutputs({ markdown: 'abcdef', pageCount: 0, tokenCount: 0 }, {
      markdownCapChars: 3,
      jsonCapChars: 100,
    })).toEqual({ markdown: 'abc', truncated: true, pageCount: 0, tokenCount: 0 })
  })

  it('drops json over the cap and flags it', () => {
    expect(capParseOutputs({ markdown: 'md', json: { a: 1 }, pageCount: 0, tokenCount: 0 }, {
      markdownCapChars: 100,
      jsonCapChars: 1,
    })).toEqual({ markdown: 'md', truncated: false, pageCount: 0, tokenCount: 0, jsonOmitted: true })
  })

  it('omits json entirely when the payload carried none', () => {
    expect(capParseOutputs({ markdown: 'md', pageCount: 0, tokenCount: 0 }, {
      markdownCapChars: 100,
      jsonCapChars: 100,
    })).toEqual({ markdown: 'md', truncated: false, pageCount: 0, tokenCount: 0 })
  })
})

describe('formatParseResult', () => {
  it('renders the summary and markdown', () => {
    expect(formatParseResult({ markdown: 'md', truncated: false, pageCount: 3, tokenCount: 40 }))
      .toBe('Parsed 3 page(s), 40 token(s).\n\nmd')
  })

  it('notes markdown truncation', () => {
    expect(formatParseResult({ markdown: 'md', truncated: true, pageCount: 0, tokenCount: 0 }))
      .toContain('[Markdown truncated at the configured output cap; the parse itself is complete.]')
  })

  it('notes json omission', () => {
    expect(formatParseResult({ markdown: 'md', truncated: false, pageCount: 0, tokenCount: 0, jsonOmitted: true }))
      .toContain('[JSON omitted: larger than the configured output cap.]')
  })

  it('notes both truncation and json omission', () => {
    const out = formatParseResult({ markdown: 'md', truncated: true, pageCount: 0, tokenCount: 0, jsonOmitted: true })
    expect(out).toContain('[Markdown truncated at the configured output cap; the parse itself is complete.]')
    expect(out).toContain('[JSON omitted: larger than the configured output cap.]')
  })
})

describe('SomarkError', () => {
  it('carries the code and a HarnessError name', () => {
    const error = new SomarkError('NO_API_KEY', 'set a key')
    expect(error.code).toBe('NO_API_KEY')
    expect(error.name).toBe('SomarkError')
    expect(error).toBeInstanceOf(Error)
  })
})
