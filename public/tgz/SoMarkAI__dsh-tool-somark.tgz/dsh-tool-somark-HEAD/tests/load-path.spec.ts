/**
 * Real Loader-path guard for the injected namespace plugin. A default export
 * would make `unwrapExports` collapse the namespace and drop `inject`, causing
 * access to `ctx.fs` to fail; see postmortem 0001.
 */

import { describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import { FileSystem, FsTargetKey, FsVersion } from '@deepseek-ai/dsh-fs'
import type { FsInfo, FsTarget } from '@deepseek-ai/dsh-fs'
import * as ToolSomark from '../src/index.ts'

/** Minimal inert `ctx.fs` provider so the unwrapped plugin can mount. */
class InertFs extends FileSystem {
  override async resolve(path: string): Promise<FsTarget> {
    return { targetKey: FsTargetKey(path), displayPath: path }
  }
  override processPath(target: FsTarget): string { return String(target.targetKey) }
  override fileUrl(target: FsTarget): string { return `file://${target.targetKey}` }
  override contains(parent: FsTarget, child: FsTarget): boolean { return child.targetKey === parent.targetKey }
  override async stat(_target: FsTarget): Promise<FsInfo | undefined> {
    return { version: FsVersion('v1'), type: 'file', size: 0 }
  }
  override async lstat(): Promise<undefined> { return undefined }
  override async readText(): Promise<string> { return '' }
  override async streamText(): Promise<AsyncIterable<string>> { return (async function* () {})() }
  override async readBytes(): Promise<Uint8Array> { return new Uint8Array() }
  override async listDir(): Promise<never> { throw new Error('unused') }
  override async writeText(): Promise<never> { throw new Error('unused') }
  override async editText(): Promise<never> { throw new Error('unused') }
}

describe('dsh-tool-somark real-load-path guard', () => {
  it('has no default export and keeps name/inject/Config through unwrapExports', () => {
    expect('default' in ToolSomark).toBe(false)

    const loader = Object.create(Loader.prototype) as Loader
    const unwrapped = loader.unwrapExports(ToolSomark) as Record<string, unknown>
    expect(unwrapped).toBe(ToolSomark)
    expect(unwrapped.name).toBe('tool-somark')
    expect(unwrapped.inject).toEqual(['tools', 'fs'])
    expect(typeof unwrapped.apply).toBe('function')
  })

  it('boots over ctx.fs through the unwrapped module without an inject error', async () => {
    const ctx = new Context()
    await ctx.plugin(SystemPrompt)
    await ctx.plugin(ToolRuntime)
    await ctx.plugin(InertFs)

    const loader = Object.create(Loader.prototype) as Loader
    const unwrapped = loader.unwrapExports(ToolSomark) as Parameters<Context['plugin']>[0]
    const fiber = await ctx.plugin(unwrapped)
    expect(ctx.tools.schemas().map(s => s.name)).toContain('somark_parse')
    await fiber.dispose()
  })
})
