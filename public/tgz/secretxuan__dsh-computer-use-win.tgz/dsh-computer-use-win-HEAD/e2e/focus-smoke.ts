import { focusWindow, listWindows } from '../src/windows.ts'

const before = (await listWindows()).find(w => w.isActive)
console.log('active before:', before?.process, JSON.stringify(before?.title.slice(0, 40)))
const r = await focusWindow('Notepad')
console.log('focus:', r)
const after = (await listWindows()).find(w => w.isActive)
console.log('active after:', after?.process, JSON.stringify(after?.title.slice(0, 40)))
process.exit(0)
