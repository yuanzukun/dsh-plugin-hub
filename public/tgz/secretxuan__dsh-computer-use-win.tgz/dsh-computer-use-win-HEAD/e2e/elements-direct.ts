import { listElements, screenMetrics } from '../src/elements.ts'
import { listWindows } from '../src/windows.ts'

console.log('screen:', await screenMetrics())
console.log('\n--- name search "开始" (whole screen) ---')
const found = await listElements({ name: '开始' })
for (const e of found.slice(0, 6)) {
  console.log(`${e.controlType} "${e.name}" [${e.className}] pid=${e.pid} rect=(${e.left},${e.top} ${e.width}x${e.height}) click=(${e.centerX},${e.centerY})`)
}
console.log('\n--- window list (should be physical 1920x1080 space, no mojibake) ---')
for (const w of (await listWindows()).slice(0, 6)) {
  console.log(`pid=${w.pid} [${w.process}] "${w.title.slice(0, 40)}" (${w.left},${w.top} ${w.width}x${w.height})`)
}
process.exit(0)
