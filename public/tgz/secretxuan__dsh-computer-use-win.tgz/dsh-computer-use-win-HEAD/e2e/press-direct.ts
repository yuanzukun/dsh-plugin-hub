import { focusWindow } from '../src/windows.ts'
import { pressKey, typeText } from '../src/input.ts'

console.log('focusing...')
console.log(await focusWindow('agent-loop-tech-share'))
await new Promise(r => setTimeout(r, 600))
console.log(await pressKey('end', { ctrl: true }, undefined))
await new Promise(r => setTimeout(r, 400))
console.log(await typeText('SENDKEYS-PRESS-OK-ABC', undefined))
process.exit(0)
