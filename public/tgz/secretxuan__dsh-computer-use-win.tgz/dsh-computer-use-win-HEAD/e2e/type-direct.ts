import { focusWindow } from '../src/windows.ts'
import { typeText } from '../src/input.ts'

console.log('focusing...')
const f = await focusWindow('agent-loop-tech-share')
console.log('focus result:', f)
await new Promise(r => setTimeout(r, 800))
console.log('typing marker...')
const t = await typeText('E2E-CLIP-OK-555', undefined)
console.log('type result:', t)
process.exit(0)
