/**
 * Headless end-to-end verification of the dsh-computer-use-win plugin.
 *
 * Boots profile cu-test through the same runProfile path the CLI uses,
 * then verifies every computer_* tool is registered and executes the
 * non-destructive ones (list_windows, screenshot) through the real
 * ToolRuntime pipeline. Input tools are verified via the runtime too,
 * with the profile's approval config driving the expected denial.
 */
import { runProfile } from 'file:///C:/workspace/deepseek-harness/apps/cli/src/profile-boot.ts'
import { loadLayeredEnv } from '@deepseek-ai/dsh-app-boot'

const controller = new AbortController()
setTimeout(() => controller.abort(), 120_000).unref?.()

const failures: string[] = []
function check(label: string, ok: boolean, detail = ''): void {
  const mark = ok ? 'PASS' : 'FAIL'
  console.log(`[${mark}] ${label}${detail ? ` — ${detail}` : ''}`)
  if (!ok) failures.push(label)
}

const { ctx, shutdown } = await runProfile({
  environment: loadLayeredEnv('dsh'),
  profile: 'cu-test',
  patchFiles: [],
  args: [],
})

try {
  const tools = ctx.get('tools')
  if (tools === undefined) throw new Error('no tools service mounted')

  const expected = [
    'computer_screenshot', 'computer_list_windows', 'computer_list_elements',
    'computer_ocr_image', 'computer_ocr_window', 'computer_observe_image', 'computer_observe_window',
    'computer_observe_media_controls', 'computer_search_in_window',
    'computer_locate_text', 'computer_click_text',
    'computer_open_settings', 'computer_click',
    'computer_type_text', 'computer_press_key', 'computer_scroll',
    'computer_drag', 'computer_move_mouse',
  ]
  for (const name of expected) {
    check(`registered: ${name}`, tools.get(name) !== undefined)
  }

  // Model-facing schema projection: what the LLM would actually receive.
  const schemas = tools.schemas().filter(s => s.name.startsWith('computer_'))
  check(`model-visible schemas: ${schemas.length}/18`, schemas.length === 18)
  const shotSchema = schemas.find(s => s.name === 'computer_screenshot')
  check('screenshot schema has parameters', shotSchema !== undefined
    && JSON.stringify(shotSchema).includes('window'))

  const mkExec = (name: string, args: unknown, agent?: unknown) => ({
    callId: `e2e-${name}` as const,
    name,
    arguments: args,
    signal: controller.signal,
    ...agent !== undefined ? { agent } : {},
  })

  // 1. list_windows — pure read
  const listRes = await tools.execute(mkExec('computer_list_windows', {}))
  check('execute list_windows ok', !listRes.isError, listRes.isError ? String(listRes.error.message) : '')
  if (!listRes.isError) {
    const windows = listRes.value?.windows ?? []
    check(`list_windows returned ${windows.length} windows`, windows.length > 0)
    const active = windows.filter(w => w.isActive).length
    check(`at most one active window (got ${active})`, active <= 1)
  }

  // 2. screenshot — exercises PowerShell capture + attachments.saveImage + render
  const shotRes = await tools.execute(mkExec('computer_screenshot', {}))
  check('execute computer_screenshot ok', !shotRes.isError, shotRes.isError ? String(shotRes.error.message).slice(0, 200) : '')
  if (!shotRes.isError) {
    const img = shotRes.value?.image
    const file = shotRes.value?.file
    check('screenshot produced image or file', img !== undefined || file !== undefined)
    check(`screenshot dims ${img?.width ?? file?.width}x${img?.height ?? file?.height}`,
      (img?.width ?? file?.width ?? 0) > 0 && (img?.height ?? file?.height ?? 0) > 0)
    check('screenshot output has bytes', (img?.bytes ?? file?.bytes ?? 0) > 0)
    const hasRenderable = shotRes.content.some(b => b.type === 'image' || b.type === 'text')
    check('rendered content includes model-safe output', hasRenderable)
    if (file !== undefined) {
      const observeRes = await tools.execute(mkExec('computer_observe_image', { path: file.path, originX: file.left, originY: file.top }))
      check('execute computer_observe_image ok', !observeRes.isError,
        observeRes.isError ? String(observeRes.error.message).slice(0, 200) : '')
      if (!observeRes.isError) {
        check('observe_image returned regions', (observeRes.value?.regions?.length ?? 0) >= 4)
        check('observe_image returned warnings', (observeRes.value?.warnings?.length ?? 0) > 0)
        check('observe_image returned suggested actions', Array.isArray(observeRes.value?.suggestedActions))
      }
    }
  }

  // 3. approval-gated input tool. The approval seam requires a live agent with
  //    an open turn. First with no answerer (default 'ask' policy, headless):
  //    the request must fail closed. Then with an auto-allow listener: the
  //    click must actually execute against the real screen.
  const agents = ctx.get('agents')
  const approval = ctx.get('approval')
  if (agents === undefined || approval === undefined) {
    check('agents + approval services mounted', false)
  } else {
    const { SessionId } = await import('@deepseek-ai/dsh-session')
    const handle = await agents.create({
      sessionId: SessionId(crypto.randomUUID()),
      meta: { cwd: process.cwd() },
    })
    const agent = handle.agent
    check('created live agent for approval flow', agent !== undefined)
    if (agent !== undefined) {
      agent.session.append('turn/start', { turn: 1 })
      const noAnswer = await tools.execute(mkExec('computer_click', { x: 400, y: 300 }, agent))
      const denied = noAnswer.isError && /denied by approval policy/.test(String(noAnswer.error.message ?? ''))
      check('computer_click denied with no approval answerer', denied,
        noAnswer.isError ? String(noAnswer.error.message).slice(0, 120) : 'click executed without approval!')

      const offApprove = ctx.on('approval/request', () => Promise.resolve('allowed-once'))
      const clickRes = await tools.execute(mkExec('computer_click', { x: 500, y: 400 }, agent))
      check('computer_click approved + executed', !clickRes.isError,
        clickRes.isError ? String(clickRes.error.message).slice(0, 160) : String(clickRes.value))
      offApprove()

      // 3b. Full-Access preset semantics: approval policy 'never' + sandbox
      //     danger-full-access must NOT auto-deny input (the "never ask"
      //     promise of the preset), while 'never' + confined sandbox must.
      const sandboxPolicy = ctx.get('sandboxPolicy')
      const { setApprovalPolicy } = await import('@deepseek-ai/dsh-user-approval')
      const { setSandboxMode } = await import('@deepseek-ai/dsh-sandbox-policy')
      if (sandboxPolicy === undefined) {
        check('sandboxPolicy service mounted (full-access approval test)', false)
      } else {
        agent.session.append('turn/start', { turn: 2 })
        setApprovalPolicy(agent.session, 'never')
        setSandboxMode(agent.session, 'danger-full-access')
        const fullAccessClick = await tools.execute(mkExec('computer_move_mouse', { x: 600, y: 500 }, agent))
        check('full-access preset: input executes without asking', !fullAccessClick.isError,
          fullAccessClick.isError ? String(fullAccessClick.error.message).slice(0, 160) : String(fullAccessClick.value))
        const fullAccessSettings = await tools.execute(mkExec('computer_open_settings', {}, agent))
        check('full-access preset: open Settings executes without asking', !fullAccessSettings.isError,
          fullAccessSettings.isError ? String(fullAccessSettings.error.message).slice(0, 160) : String(fullAccessSettings.value))
        setSandboxMode(agent.session, 'workspace-write')
        const confinedClick = await tools.execute(mkExec('computer_move_mouse', { x: 700, y: 500 }, agent))
        const confinedDenied = confinedClick.isError && /denied by approval policy/.test(String(confinedClick.error.message ?? ''))
        check("never + confined sandbox: input denied (fail-closed)", confinedDenied,
          confinedClick.isError ? String(confinedClick.error.message).slice(0, 120) : 'input executed despite confined sandbox!')
        setApprovalPolicy(agent.session, 'ask')
        setSandboxMode(agent.session, 'danger-full-access')
        agent.session.append('turn/end', { turn: 2 })
      }
      agent.session.append('turn/end', { turn: 1 })
      await handle.dispose().catch(() => {})
    }
  }
} finally {
  await shutdown.shutdown(0).catch(() => {})
}

console.log('')
if (failures.length === 0) {
  console.log('E2E RESULT: ALL CHECKS PASSED')
} else {
  console.log(`E2E RESULT: ${failures.length} FAILURES:`)
  for (const f of failures) console.log(`  - ${f}`)
  process.exitCode = 1
}
