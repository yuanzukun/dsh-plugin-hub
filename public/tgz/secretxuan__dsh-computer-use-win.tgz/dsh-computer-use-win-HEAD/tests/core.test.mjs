import assert from 'node:assert/strict'
import test from 'node:test'
import { keyComboFromNames, locateOcrText, routeAcceptsImages } from '../lib/index.mjs'

test('key combinations preserve modifiers and the requested key', () => {
  assert.deepEqual(keyComboFromNames('a', { ctrl: true, shift: true }), [0x11, 0x10, 0x41])
})

test('OCR text lookup supports contains and exact matching', () => {
  const line = {
    text: 'Open Settings',
    words: [],
    left: 10,
    top: 20,
    width: 100,
    height: 30,
    centerX: 60,
    centerY: 35,
  }
  const result = {
    path: 'screen.png',
    originX: 0,
    originY: 0,
    width: 1920,
    height: 1080,
    lines: [line],
    text: line.text,
  }

  assert.deepEqual(locateOcrText(result, 'settings'), [line])
  assert.deepEqual(locateOcrText(result, 'open', 'exact'), [])
  assert.deepEqual(locateOcrText(result, 'OPEN SETTINGS', 'exact'), [line])
})

test('DeepSeek vision routes receive screenshot image blocks', async () => {
  const calls = []
  const context = {
    get(name) {
      if (name !== 'llm') return undefined
      return {
        async resolveModelInfo(provider, model) {
          calls.push({ provider, model })
          return {
            provider,
            id: model,
            name: 'DeepSeek-V4-Flash-Vision-Exp',
            inputModalities: ['text', 'image'],
          }
        },
      }
    },
  }
  const execution = {
    signal: new AbortController().signal,
    agent: {
      options: { provider: 'fallback-provider', model: 'fallback-model' },
      session: {
        requestHeader() {
          return {
            config: {
              provider: 'deepseek-official',
              model: 'deepseek-v4-flash-vision-exp',
            },
          }
        },
      },
    },
  }

  assert.equal(await routeAcceptsImages(context, execution), true)
  assert.deepEqual(calls, [{
    provider: 'deepseek-official',
    model: 'deepseek-v4-flash-vision-exp',
  }])
})

test('text-only and unresolved routes keep the OCR-compatible file fallback', async () => {
  const execution = {
    signal: new AbortController().signal,
    agent: {
      options: { provider: 'deepseek-official', model: 'deepseek-v4-flash' },
      session: { requestHeader: () => undefined },
    },
  }
  const textContext = {
    get: () => ({
      resolveModelInfo: async () => ({
        provider: 'deepseek-official',
        id: 'deepseek-v4-flash',
        name: 'DeepSeek-V4-Flash',
        inputModalities: ['text'],
      }),
    }),
  }

  assert.equal(await routeAcceptsImages(textContext, execution), false)
  assert.equal(await routeAcceptsImages({ get: () => undefined }, execution), false)
})
