# dsh-computer-use-win 0.7.0 发布文案

## 中文短版

dsh-computer-use-win 0.7.0 发布：接入 DeepSeek Harness 新的原生视觉模型链路，让 DeepSeek 在 Windows 上真正看到并操作桌面。

选择 `DeepSeek-V4-Flash-Vision-Exp` 后，截图会作为原生图片内容交给模型，DSH 负责像素/体积预算、Files API 上传和内联回退；纯文本模型仍可使用 OCR 与结构化观察。插件共提供 18 个 computer-use 工具，覆盖截图、窗口枚举、UI Automation 和带审批的鼠标键盘操作。

```powershell
dsh plugin --profile web add https://github.com/secretxuan/dsh-computer-use-win/releases/download/v0.7.0/dsh-computer-use-win-0.7.0.tgz
```

项目：https://github.com/secretxuan/dsh-computer-use-win

说明：npm 上未加 scope 的同名包不是本项目，请使用上面的 GitHub Release 安装。输入操作默认经过 DSH 审批，Windows 输入注入仍是全局操作，使用后应再次观察确认结果。

## English

dsh-computer-use-win 0.7.0 connects DeepSeek Harness's native vision route to practical Windows desktop perception and control.

With `DeepSeek-V4-Flash-Vision-Exp`, screenshots reach the model as native image content while DSH handles pixel/byte budgets, Files API upload, and inline fallback. Text-only models retain OCR and structured observation. The plugin provides 18 screenshot, discovery, UI Automation, OCR, and approval-gated input tools.

```powershell
dsh plugin --profile web add https://github.com/secretxuan/dsh-computer-use-win/releases/download/v0.7.0/dsh-computer-use-win-0.7.0.tgz
```

Project: https://github.com/secretxuan/dsh-computer-use-win

The unscoped npm package with the same name is unrelated; install this implementation from its GitHub Release. Input injection remains approval-gated by default and affects the global Windows desktop, so agents should observe again after acting.
