# dsh-computer-use-win

中文 | [English](README.md)

面向 [DeepSeek Harness (dsh)](https://github.com/deepseek-ai/deepseek-harness) 的 Windows computer-use 插件。它为 Agent 提供截图、窗口和 UI Automation 控件发现、OCR、面向纯文本模型的界面观察，以及经过审批的鼠标键盘操作。

从 DSH 0.1.1-rc.2 开始，内置的 `deepseek-v4-flash-vision-exp` 路由会直接收到 `computer_screenshot` 产生的图片内容。DSH 会按模型的像素与体积预算规范化截图，优先通过 DeepSeek Files API 发送，并在 Files API 不可用时回退到内联图片。纯文本路由继续使用可接 OCR 的文件流程。

macOS 方向可参考 [Anionex/dsh-computer-use](https://github.com/Anionex/dsh-computer-use)；本项目补上 Windows 支持。

## 快速安装

前置条件：Windows、Node.js 22.19 或更新版本、pnpm，以及已安装的 dsh CLI。

如果通过 [Oh My DSH](https://github.com/secretxuan/oh-my-dsh) 使用 Agent Teams，一条命令即可安装并接入本插件：

```powershell
oh-my-dsh setup --computer-use
```

推荐直接安装预构建的 GitHub Release：

```powershell
dsh plugin --profile web add https://github.com/secretxuan/dsh-computer-use-win/releases/download/v0.7.0/dsh-computer-use-win-0.7.0.tgz
```

确认插件层已经加载，然后启动 dsh：

```powershell
dsh --profile web --dump-config | Select-String computer-use
dsh --profile web
```

npm 上未加 scope 的同名包来自另一个仓库，不是本项目。请使用上面的 GitHub Release 地址安装。

## 提供的能力

插件注册 18 个 `computer_*` 工具，覆盖以下工作流：

- `computer_screenshot`、`computer_list_windows`：截图并枚举可见窗口。
- `computer_list_elements`：通过 Windows UI Automation 获取控件名称、类型、屏幕坐标和点击中心。
- `computer_ocr_image`、`computer_ocr_window`：使用 Windows.Media.Ocr 识别图片或窗口中的文字及坐标。
- `computer_observe_image`、`computer_observe_window`、`computer_observe_media_controls`：把界面转换成纯文本模型可用的区域、候选控件和建议操作。
- `computer_search_in_window`、`computer_locate_text`、`computer_click_text`：完成搜索、定位文字和按文字点击。
- `computer_open_settings`：通过 `ms-settings:` 打开 Windows 设置。
- `computer_click`、`computer_type_text`、`computer_press_key`、`computer_scroll`、`computer_drag`、`computer_move_mouse`：执行鼠标和键盘输入。

所有会注入输入的工具默认都需要 DSH 审批。Full access 模式已经代表用户授权，因此插件不会再发起必然被拒绝的重复审批；受限 sandbox 中仍然保持拒绝优先。

## 推荐工作流

视觉模型推荐直接观察真实截图：

```text
在 DSH 中选择 DeepSeek-V4-Flash-Vision-Exp
-> computer_screenshot(window: "目标应用")
-> 根据返回的图片决定操作
-> computer_click / computer_type_text / computer_press_key
-> 再次 computer_screenshot 验证结果
```

纯文本模型不应猜测坐标。优先使用结构化观察：

```text
computer_list_windows
-> computer_list_elements(window: "目标应用")
-> UIA 能力受限时，computer_observe_window(window: "目标应用")
-> 使用 suggestedActions，或 computer_locate_text / computer_click_text
-> computer_type_text / computer_press_key
-> 再次观察，确认操作结果
```

## 配置

在 profile 的 `cordis.patch.yml` 中覆盖 `computer-use-win`：

```yaml
- id: computer-use-win
  config:
    requireApproval: true
    maxScreenshotBytes: 8388608
```

只有在无人值守测试或可随时丢弃的环境中，才应设置 `requireApproval: false`。

## 实现与限制

插件不需要原生二进制依赖。截图、Win32 窗口访问、UI Automation、Windows OCR 和输入注入都通过有超时限制的 PowerShell 子进程执行，并统一使用 DPI-aware 的物理像素坐标和 UTF-8 输出。

- Windows 输入注入是全局操作，点击会落到坐标当前覆盖的窗口。
- 非管理员进程可能无法操作以管理员权限运行的窗口。
- UI Automation 的效果取决于目标应用的无障碍信息。CEF、Chromium、Electron 或自绘界面可能只暴露外壳，应改用观察或 OCR 工具。
- 纯文本 DeepSeek 路由不能直接理解截图像素，应使用 OCR 和观察工具把图像转换为文本与坐标。
- 视觉候选来自启发式分析，不等同于视觉模型；操作后应再次观察确认。

## 从源码开发

```powershell
git clone https://github.com/secretxuan/dsh-computer-use-win.git
cd dsh-computer-use-win
pnpm install
pnpm test
dsh plugin --profile web add .
```

## 许可证

MIT。
