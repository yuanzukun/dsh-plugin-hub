/**
 * Text-model visual observation helpers.
 * @module dsh-computer-use-win/src/observe
 */

import { type OcrLineInfo, ocrImage } from './ocr.ts'
import { runPowershell } from './powershell.ts'

export interface UiRegionInfo {
  kind: string
  label: string
  left: number
  top: number
  width: number
  height: number
  centerX: number
  centerY: number
}

export interface VisualCandidateInfo {
  kind: string
  label: string
  confidence: number
  left: number
  top: number
  width: number
  height: number
  centerX: number
  centerY: number
  evidence: string
}

export interface SuggestedActionInfo {
  action: string
  target: string
  purpose: string
  x: number
  y: number
  confidence: number
  tool: string
  verifyWith: string
}

export interface MediaControlsInfo {
  state: string
  meaning: string
  hasToggle: boolean
  toggle?: VisualCandidateInfo
}

export type ObserveRegionName = 'top-bar' | 'left-sidebar' | 'main-content' | 'bottom-bar'

export interface ObserveRegion {
  name?: ObserveRegionName
  left?: number
  top?: number
  width?: number
  height?: number
}

export interface ObserveResult {
  path: string
  originX: number
  originY: number
  width: number
  height: number
  regions: UiRegionInfo[]
  texts: OcrLineInfo[]
  icons: VisualCandidateInfo[]
  clickables: VisualCandidateInfo[]
  mediaControls: MediaControlsInfo
  suggestedActions: SuggestedActionInfo[]
  warnings: string[]
  suggestions: string[]
}

function psText(value: string): string {
  return value.replaceAll("'", "''")
}

/** Build a generic text-model view of an image using OCR plus simple visual detectors. */
export async function observeImage(path: string, originX = 0, originY = 0, signal?: AbortSignal, requestedRegion?: ObserveRegion): Promise<ObserveResult> {
  const baseSize = await readImageSize(path, signal).catch(() => ({ width: 0, height: 0 }))
  const crop = requestedRegion === undefined
    ? undefined
    : await cropImage(path, resolveRegion(requestedRegion, baseSize.width, baseSize.height), signal)
  const observedPath = crop?.path ?? path
  const observedOriginX = originX + (crop?.left ?? 0)
  const observedOriginY = originY + (crop?.top ?? 0)
  const observedSize = crop === undefined ? baseSize : { width: crop.width, height: crop.height }

  const [ocrSettled, iconsSettled] = await Promise.allSettled([
    ocrImage(observedPath, observedOriginX, observedOriginY, signal),
    detectVisualCandidates(observedPath, observedOriginX, observedOriginY, signal),
  ])
  const ocr = ocrSettled.status === 'fulfilled'
    ? ocrSettled.value
    : { path: observedPath, originX: observedOriginX, originY: observedOriginY, width: observedSize.width, height: observedSize.height, lines: [], text: '' }
  const icons = iconsSettled.status === 'fulfilled' ? iconsSettled.value : []
  const regions = inferRegions(ocr.width, ocr.height, observedOriginX, observedOriginY)
  const inferred = inferCandidatesFromOcr(ocr.lines, observedOriginX, observedOriginY, ocr.width, ocr.height)
  const textClickables = ocr.lines.slice(0, 80).map((line): VisualCandidateInfo => ({
    kind: 'ocr-text',
    label: line.text,
    confidence: 0.9,
    left: line.left,
    top: line.top,
    width: line.width,
    height: line.height,
    centerX: line.centerX,
    centerY: line.centerY,
    evidence: 'Windows OCR text line',
  }))
  const clickables = [...icons, ...inferred, ...textClickables]
  const mediaControls = inferMediaControls([...icons, ...inferred], observedOriginY, ocr.height)
  const suggestedActions = actionsFor([...icons, ...inferred], mediaControls, observedOriginY, ocr.height)
  return {
    path: observedPath,
    originX: observedOriginX,
    originY: observedOriginY,
    width: ocr.width,
    height: ocr.height,
    regions,
    texts: ocr.lines,
    icons,
    clickables,
    mediaControls,
    suggestedActions,
    warnings: [
      'text-model-visual-proxy: this is structured OCR and heuristic icon detection, not true image understanding.',
      'prefer-suggested-actions: if a suggested action matches the user task, execute it and verify instead of writing custom screenshot-analysis scripts.',
      'verify-after-action: for icon-only targets, click candidates with high confidence first and verify with another observation.',
      ...requestedRegion === undefined ? [] : [`region-observation: this result only covers ${requestedRegion.name ?? 'the requested rectangle'}; use the original screenshot/window for full context.`],
      ...ocrSettled.status === 'rejected' ? [`ocr-unavailable: ${shortMessage(ocrSettled.reason)}; visual candidates may still be usable.`] : [],
      ...iconsSettled.status === 'rejected' ? [`visual-detector-unavailable: ${shortMessage(iconsSettled.reason)}; OCR text may still be usable.`] : [],
    ],
    suggestions: suggestionsFor(suggestedActions),
  }
}

async function readImageSize(path: string, signal?: AbortSignal): Promise<{ width: number; height: number }> {
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile('${psText(path)}')
try {
  ([ordered]@{ width = [int]$bmp.Width; height = [int]$bmp.Height }) | ConvertTo-Json -Compress
} finally {
  $bmp.Dispose()
}
`.trim()
  const out = await runPowershell(script, signal, 30_000)
  return JSON.parse(out) as { width: number; height: number }
}

function shortMessage(cause: unknown): string {
  const message = cause instanceof Error ? cause.message : String(cause)
  return message.replace(/\s+/g, ' ').slice(0, 180)
}

function resolveRegion(region: ObserveRegion, width: number, height: number): { left: number; top: number; width: number; height: number } {
  if (region.name !== undefined) {
    const topHeight = Math.max(72, Math.round(height * 0.11))
    const bottomHeight = Math.max(80, Math.round(height * 0.11))
    const sideWidth = Math.max(160, Math.round(width * 0.18))
    const mainHeight = Math.max(1, height - topHeight - bottomHeight)
    if (region.name === 'top-bar') return { left: 0, top: 0, width, height: topHeight }
    if (region.name === 'bottom-bar') return { left: 0, top: Math.max(0, height - bottomHeight), width, height: bottomHeight }
    if (region.name === 'left-sidebar') return { left: 0, top: topHeight, width: sideWidth, height: mainHeight }
    return { left: sideWidth, top: topHeight, width: Math.max(1, width - sideWidth), height: mainHeight }
  }
  const left = clampInt(region.left ?? 0, 0, Math.max(0, width - 1))
  const top = clampInt(region.top ?? 0, 0, Math.max(0, height - 1))
  return {
    left,
    top,
    width: clampInt(region.width ?? width - left, 1, Math.max(1, width - left)),
    height: clampInt(region.height ?? height - top, 1, Math.max(1, height - top)),
  }
}

function clampInt(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, Math.round(value)))
}

async function cropImage(path: string, region: { left: number; top: number; width: number; height: number }, signal?: AbortSignal): Promise<{ path: string; left: number; top: number; width: number; height: number }> {
  const outPath = `${path.replace(/\.[^.\\/:]+$/, '')}-crop-${Date.now()}.png`
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$src = [System.Drawing.Bitmap]::FromFile('${psText(path)}')
try {
  $left = ${region.left}
  $top = ${region.top}
  $width = [Math]::Min(${region.width}, $src.Width - $left)
  $height = [Math]::Min(${region.height}, $src.Height - $top)
  $crop = New-Object System.Drawing.Bitmap($width, $height)
  try {
    $g = [System.Drawing.Graphics]::FromImage($crop)
    try {
      $g.DrawImage($src,
        (New-Object System.Drawing.Rectangle(0, 0, $width, $height)),
        (New-Object System.Drawing.Rectangle($left, $top, $width, $height)),
        [System.Drawing.GraphicsUnit]::Pixel)
    } finally {
      $g.Dispose()
    }
    $crop.Save('${psText(outPath)}', [System.Drawing.Imaging.ImageFormat]::Png)
  } finally {
    $crop.Dispose()
  }
} finally {
  $src.Dispose()
}
`.trim()
  await runPowershell(script, signal, 30_000)
  return { path: outPath, ...region }
}

function inferRegions(width: number, height: number, originX: number, originY: number): UiRegionInfo[] {
  const topHeight = Math.max(72, Math.round(height * 0.11))
  const bottomHeight = Math.max(80, Math.round(height * 0.11))
  const sideWidth = Math.max(160, Math.round(width * 0.18))
  const mainTop = originY + topHeight
  const mainHeight = Math.max(1, height - topHeight - bottomHeight)
  return [
    region('top-bar', 'top navigation / title bar area', originX, originY, width, topHeight),
    region('left-sidebar', 'left navigation/sidebar area', originX, originY + topHeight, sideWidth, mainHeight),
    region('main-content', 'main content area', originX + sideWidth, mainTop, Math.max(1, width - sideWidth), mainHeight),
    region('bottom-bar', 'bottom/status/player bar area', originX, originY + height - bottomHeight, width, bottomHeight),
  ]
}

function region(kind: string, label: string, left: number, top: number, width: number, height: number): UiRegionInfo {
  return {
    kind,
    label,
    left,
    top,
    width,
    height,
    centerX: Math.round(left + width / 2),
    centerY: Math.round(top + height / 2),
  }
}

function inferCandidatesFromOcr(lines: OcrLineInfo[], originX: number, originY: number, width: number, height: number): VisualCandidateInfo[] {
  const candidates: VisualCandidateInfo[] = []
  for (const line of lines) {
    const nearTop = line.top < originY + Math.max(120, height * 0.18)
    const looksLikeSearch = nearTop && (/^(Q|O|0|🔍)\s*\S+/i.test(line.text.trim()) || /搜索|search/i.test(line.text))
    if (looksLikeSearch) {
      candidates.push({
        kind: 'search-field',
        label: `possible search field: ${line.text}`,
        confidence: 0.62,
        left: Math.max(originX, line.left - 36),
        top: Math.max(originY, line.top - 18),
        width: Math.min(width, line.width + 90),
        height: Math.max(36, line.height + 24),
        centerX: Math.round(line.left + line.width / 2),
        centerY: Math.round(line.top + line.height / 2),
        evidence: 'OCR line near the top resembles a search box or text inside one',
      })
    }
  }
  return candidates
}

function inferMediaControls(candidates: VisualCandidateInfo[], originY: number, height: number): MediaControlsInfo {
  const bottomStart = originY + height * 0.72
  const bottom = candidates.filter(c => c.centerY >= bottomStart)
  const pause = bottom.find(c => c.kind === 'pause-button') ?? candidates.find(c => c.kind === 'pause-button')
  if (pause !== undefined) return { state: 'playing', meaning: 'pause icon is visible, so media is likely playing', hasToggle: true, toggle: pause }
  const play = bottom.find(c => c.kind === 'play-button') ?? candidates.find(c => c.kind === 'play-button')
  if (play !== undefined) return { state: 'paused', meaning: 'play icon is visible, so media is likely paused', hasToggle: true, toggle: play }
  const media = bottom.find(c => c.kind === 'round-media-control') ?? candidates.find(c => c.kind === 'round-media-control')
  if (media !== undefined) return { state: 'unknown', meaning: 'a round media control is visible but icon state is uncertain', hasToggle: true, toggle: media }
  return { state: 'unknown', meaning: 'no reliable media toggle candidate found', hasToggle: false }
}

function actionsFor(candidates: VisualCandidateInfo[], mediaControls: MediaControlsInfo, originY: number, height: number): SuggestedActionInfo[] {
  const actions: SuggestedActionInfo[] = []
  if (mediaControls.toggle !== undefined) {
    actions.push({
      action: 'click',
      target: 'media-toggle',
      purpose: mediaControls.state === 'playing' ? 'pause currently playing media' : 'toggle media playback',
      x: mediaControls.toggle.centerX,
      y: mediaControls.toggle.centerY,
      confidence: mediaControls.toggle.confidence,
      tool: 'computer_click',
      verifyWith: 'computer_observe_media_controls',
    })
  }
  const search = candidates.find(c => c.kind === 'search-field')
  if (search !== undefined) {
    actions.push({
      action: 'search',
      target: 'search-field',
      purpose: 'focus the search box, type the query, then press Enter',
      x: search.centerX,
      y: search.centerY,
      confidence: search.confidence,
      tool: 'computer_search_in_window',
      verifyWith: 'computer_observe_window',
    })
  }
  if (actions.length === 0) {
    const bottomStart = originY + height * 0.72
    const icon = candidates.find(c => c.centerY >= bottomStart) ?? candidates[0]
    if (icon !== undefined) {
      actions.push({
        action: 'click',
        target: icon.kind,
        purpose: 'click a high-confidence visual candidate, then verify',
        x: icon.centerX,
        y: icon.centerY,
        confidence: icon.confidence,
        tool: 'computer_click',
        verifyWith: 'computer_observe_window',
      })
    }
  }
  return actions
}

function suggestionsFor(actions: SuggestedActionInfo[]): string[] {
  if (actions.length === 0) return ['Use OCR text click centers for text targets; use high-confidence visual candidates for icon-only targets, then observe again.']
  return actions.map(action =>
    `${action.purpose}: use ${action.tool} at (${action.x},${action.y}); target=${action.target}, confidence=${action.confidence}; verify with ${action.verifyWith}.`)
}

async function detectVisualCandidates(path: string, originX: number, originY: number, signal?: AbortSignal): Promise<VisualCandidateInfo[]> {
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$path = '${psText(path)}'
$originX = ${Math.round(originX)}
$originY = ${Math.round(originY)}
$bmp = [System.Drawing.Bitmap]::FromFile($path)
try {
  $stride = 4
  $mergeGap = 12
  $components = New-Object System.Collections.ArrayList
  for ($y = 0; $y -lt $bmp.Height; $y += $stride) {
    for ($x = 0; $x -lt $bmp.Width; $x += $stride) {
      $c = $bmp.GetPixel($x, $y)
      $isRed = $c.R -gt 205 -and $c.G -lt 135 -and $c.B -lt 165 -and ($c.R - $c.G) -gt 55
      if (-not $isRed) { continue }
      $hit = $null
      foreach ($comp in $components) {
        if ($x -ge ($comp.MinX - $mergeGap) -and $x -le ($comp.MaxX + $mergeGap) -and $y -ge ($comp.MinY - $mergeGap) -and $y -le ($comp.MaxY + $mergeGap)) {
          $hit = $comp
          break
        }
      }
      if ($null -eq $hit) {
        [void]$components.Add([ordered]@{ MinX = $x; MinY = $y; MaxX = $x; MaxY = $y; Count = 1 })
      } else {
        $hit.MinX = [Math]::Min($hit.MinX, $x)
        $hit.MinY = [Math]::Min($hit.MinY, $y)
        $hit.MaxX = [Math]::Max($hit.MaxX, $x)
        $hit.MaxY = [Math]::Max($hit.MaxY, $y)
        $hit.Count += 1
      }
    }
  }

  $changed = $true
  while ($changed) {
    $changed = $false
    for ($i = 0; $i -lt $components.Count; $i++) {
      for ($j = $i + 1; $j -lt $components.Count; $j++) {
        $a = $components[$i]
        $b = $components[$j]
        $overlap = $b.MinX -le ($a.MaxX + $mergeGap) -and $b.MaxX -ge ($a.MinX - $mergeGap) -and $b.MinY -le ($a.MaxY + $mergeGap) -and $b.MaxY -ge ($a.MinY - $mergeGap)
        if (-not $overlap) { continue }
        $a.MinX = [Math]::Min($a.MinX, $b.MinX)
        $a.MinY = [Math]::Min($a.MinY, $b.MinY)
        $a.MaxX = [Math]::Max($a.MaxX, $b.MaxX)
        $a.MaxY = [Math]::Max($a.MaxY, $b.MaxY)
        $a.Count += $b.Count
        $components.RemoveAt($j)
        $changed = $true
        break
      }
      if ($changed) { break }
    }
  }

  $items = New-Object System.Collections.ArrayList
  foreach ($comp in $components) {
    $left = [int]$comp.MinX
    $top = [int]$comp.MinY
    $right = [int][Math]::Min($bmp.Width - 1, $comp.MaxX + $stride)
    $bottom = [int][Math]::Min($bmp.Height - 1, $comp.MaxY + $stride)
    $w = $right - $left + 1
    $h = $bottom - $top + 1
    if ($comp.Count -lt 8 -or $w -lt 18 -or $h -lt 18) { continue }
    $ratio = $w / [double]$h
    $kind = 'red-region'
    $label = 'red visual element'
    $confidence = 0.45
    if ($w -ge 34 -and $h -ge 34 -and $w -le 100 -and $h -le 100 -and [Math]::Abs($ratio - 1.0) -lt 0.45) {
      $leftBand = 0
      $rightBand = 0
      $whiteTotal = 0
      for ($yy = [int]($top + $h * 0.20); $yy -le [int]($top + $h * 0.80); $yy += 2) {
        for ($xx = [int]($left + $w * 0.25); $xx -le [int]($left + $w * 0.75); $xx += 2) {
          $p = $bmp.GetPixel($xx, $yy)
          $white = $p.R -gt 230 -and $p.G -gt 230 -and $p.B -gt 230
          if (-not $white) { continue }
          $whiteTotal += 1
          $rel = ($xx - $left) / [double]$w
          if ($rel -ge 0.34 -and $rel -le 0.45) { $leftBand += 1 }
          if ($rel -ge 0.55 -and $rel -le 0.66) { $rightBand += 1 }
        }
      }
      if ($leftBand -ge 4 -and $rightBand -ge 4) {
        $kind = 'pause-button'
        $label = 'possible pause button'
        $confidence = 0.78
      } elseif ($whiteTotal -ge 6) {
        $kind = 'play-button'
        $label = 'possible play button'
        $confidence = 0.68
      } else {
        $kind = 'round-red-button'
        $label = 'round red button'
        $confidence = 0.55
      }
    } elseif ($w -ge 50 -and $h -ge 24) {
      $kind = 'primary-red-button'
      $label = 'red primary button'
      $confidence = 0.58
    }
    [void]$items.Add([ordered]@{
      kind = $kind
      label = $label
      confidence = [Math]::Round($confidence, 2)
      left = [int]($originX + $left)
      top = [int]($originY + $top)
      width = [int]$w
      height = [int]$h
      centerX = [int]($originX + $left + $w / 2)
      centerY = [int]($originY + $top + $h / 2)
      evidence = "red-component $($w)x$($h), sampledPixels=$($comp.Count)"
    })
  }
  @($items | Sort-Object @{ Expression = 'confidence'; Descending = $true }, @{ Expression = 'top'; Ascending = $true }) |
    ConvertTo-Json -Depth 6 -Compress
} finally {
  $bmp.Dispose()
}
`.trim()
  const out = await runPowershell(script, signal, 60_000)
  if (out.length === 0) return []
  const parsed = JSON.parse(out) as VisualCandidateInfo[] | VisualCandidateInfo
  return Array.isArray(parsed) ? parsed : [parsed]
}
