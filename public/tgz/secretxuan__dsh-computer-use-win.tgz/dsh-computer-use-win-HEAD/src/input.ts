/**
 * Mouse and keyboard injection via SetCursorPos + SendInput P/Invoke.
 * @module dsh-computer-use-win/src/input
 */

import { runPowershell } from './powershell.ts'

/** The P/Invoke type block shared by every input script. */
const NATIVE_TYPES = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class NativeInput {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
  public const uint LEFTDOWN = 0x02, LEFTUP = 0x04, RIGHTDOWN = 0x08, RIGHTUP = 0x10, MIDDLEDOWN = 0x20, MIDDLEUP = 0x40, WHEEL = 0x800;
  [DllImport("user32.dll", EntryPoint = "VkKeyScanW")]
  public static extern short VkKeyScan(char ch);
  public static ushort VkOf(char c) {
    ushort vk = (ushort)VkKeyScan(c);
    if ((vk & 0xFF00) != 0) return 0;
    return (ushort)(vk & 0xFF);
  }
}
"@
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class NativeKeys {
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int size);
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] public struct INPUT { public int type; public KEYBDINPUT ki; }
  public static void Key(ushort vk, bool down) {
    INPUT[] inp = new INPUT[1];
    inp[0].type = 1;
    inp[0].ki.wVk = vk;
    inp[0].ki.dwFlags = down ? 0u : 2u; // 0 = keydown, 2 = KEYEVENTF_KEYUP
    SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
  }
  public static void Char(char c, bool up) {
    INPUT[] inp = new INPUT[1];
    inp[0].type = 1;
    inp[0].ki.wScan = c;
    inp[0].ki.dwFlags = 0x0004u | (up ? 0x0002u : 0u); // KEYEVENTF_UNICODE [+ KEYEVENTF_KEYUP]
    SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
  }
}
"@
`.trim()

/** Virtual-key codes for named keys. */
const VK: Record<string, number> = {
  backspace: 0x08, tab: 0x09, enter: 0x0D, return: 0x0D, shift: 0x10, ctrl: 0x11, control: 0x11,
  alt: 0x12, menu: 0x12, capslock: 0x14, escape: 0x1B, esc: 0x1B, space: 0x20, pageup: 0x21,
  pagedown: 0x22, end: 0x23, home: 0x24, left: 0x25, up: 0x26, right: 0x27, down: 0x28,
  insert: 0x2D, delete: 0x2E, win: 0x5B, lwin: 0x5B, rwin: 0x5C, apps: 0x5D,
  f1: 0x70, f2: 0x71, f3: 0x72, f4: 0x73, f5: 0x74, f6: 0x75, f7: 0x76, f8: 0x77,
  f9: 0x78, f10: 0x79, f11: 0x7A, f12: 0x7B,
  f13: 0x7C, f14: 0x7D, f15: 0x7E, f16: 0x7F, f17: 0x80, f18: 0x81,
  f19: 0x82, f20: 0x83, f21: 0x84, f22: 0x85, f23: 0x86, f24: 0x87,
  numlock: 0x90, scrolllock: 0x91, volumeup: 0xAF, volumedown: 0xAE, volumemute: 0xAD,
}

/** Resolve a key name (letter, digit, or named key) to a virtual-key code. */
export function vkCode(key: string): number {
  const lower = key.toLowerCase()
  if (VK[lower] !== undefined) return VK[lower]
  if (/^[a-z]$/.test(lower)) return 0x41 + (lower.charCodeAt(0) - 'a'.charCodeAt(0))
  if (/^[0-9]$/.test(lower)) return 0x30 + Number(lower)
  throw new Error(`unsupported key name: "${key}"`)
}

/** Resolve a modifier key name to a virtual-key code (for combos). */
export function modifierVk(mod: 'ctrl' | 'shift' | 'alt' | 'win'): number {
  return vkCode(mod)
}

/** Build the list of virtual-key codes for a key plus modifiers. */
export function keyComboFromNames(key: string, mods: { ctrl?: boolean; shift?: boolean; alt?: boolean; win?: boolean }): number[] {
  const codes: number[] = []
  if (mods.ctrl) codes.push(modifierVk('ctrl'))
  if (mods.shift) codes.push(modifierVk('shift'))
  if (mods.alt) codes.push(modifierVk('alt'))
  if (mods.win) codes.push(modifierVk('win'))
  codes.push(vkCode(key))
  return codes
}

const BUTTON_FLAGS: Record<string, { down: number; up: number }> = {
  left: { down: 0x02, up: 0x04 },
  right: { down: 0x08, up: 0x10 },
  middle: { down: 0x20, up: 0x40 },
}

/** Rewrite all NativeKeys:: calls in a script with the shared type block prepended. */
function withTypes(body: string): string {
  return `${NATIVE_TYPES}\n${body}`.trim()
}

/** Move the cursor and click. */
export async function clickMouse(x: number, y: number, button: string, clicks: number, signal?: AbortSignal): Promise<string> {
  const flags = BUTTON_FLAGS[button]
  if (flags === undefined) throw new Error(`button must be left, right, or middle (got "${button}")`)
  const body = `
[void][NativeInput]::SetCursorPos(${Math.round(x)}, ${Math.round(y)})
Start-Sleep -Milliseconds 40
${Array.from({ length: Math.max(1, clicks) }, () =>
    `[void][NativeInput]::mouse_event(${flags.down}, 0, 0, 0, [UIntPtr]::Zero)
Start-Sleep -Milliseconds 30
[void][NativeInput]::mouse_event(${flags.up}, 0, 0, 0, [UIntPtr]::Zero)`).join('\nStart-Sleep -Milliseconds 60\n')}
Write-Output "clicked ${button} at ${Math.round(x)},${Math.round(y)}"
`.trim()
  return runPowershell(withTypes(body), signal)
}

/** Type literal text. Clipboard+paste is the primary path (reliable under VDI/RDP input filtering and the only way CJK survives every layout); per-key SendInput is the fallback when the clipboard is unavailable. */
export async function typeText(text: string, signal?: AbortSignal): Promise<string> {
  if (text.length === 0) throw new Error('text must be non-empty')
  // A single-quoted PS here-string: only a line reading '@ can terminate it,
  // and "'" needs no escaping inside.
  const lines = text.split(/\r?\n/)
  const body = `
Add-Type -AssemblyName System.Windows.Forms
$s = @'
${lines.join('\n')}
'@
[System.Windows.Forms.Clipboard]::SetText($s)
Start-Sleep -Milliseconds 60
[System.Windows.Forms.SendKeys]::SendWait('^v')
Start-Sleep -Milliseconds 120
Write-Output "pasted $($s.Length) characters"
`.trim()
  try {
    return await runPowershell(body, signal, Math.max(30_000, Math.min(120_000, text.length * 20)))
  } catch (error) {
    // Clipboard path failed — fall back to per-character SendInput.
    const escaped = text.replaceAll("'", "''")
    const fallback = `
$s = '${escaped}'
foreach ($ch in $s.ToCharArray()) {
  $vk = [NativeInput]::VkOf($ch)
  if ($vk -ne 0) {
    [void][NativeKeys]::Key($vk, $true)
    Start-Sleep -Milliseconds 5
    [void][NativeKeys]::Key($vk, $false)
  } else {
    [void][NativeKeys]::Char($ch, $false)
    Start-Sleep -Milliseconds 5
    [void][NativeKeys]::Char($ch, $true)
  }
  Start-Sleep -Milliseconds 15
}
Write-Output "typed $($s.Length) characters"
`.trim()
    return runPowershell(withTypes(fallback), signal, 60_000)
  }
}

/** Map a key name + modifiers to a SendKeys token, or undefined when SendKeys has no spelling for it. */
function sendKeysToken(key: string, mods: { ctrl?: boolean; shift?: boolean; alt?: boolean; win?: boolean }): string | undefined {
  const lower = key.toLowerCase()
  // SendKeys spellings for named keys; letters/digits pass through verbatim.
  const NAMED: Record<string, string> = {
    backspace: '{BACKSPACE}', bs: '{BACKSPACE}', tab: '{TAB}', enter: '{ENTER}', return: '{ENTER}',
    escape: '{ESC}', esc: '{ESC}', space: ' ', pageup: '{PGUP}', pagedown: '{PGDN}',
    end: '{END}', home: '{HOME}', left: '{LEFT}', up: '{UP}', right: '{RIGHT}', down: '{DOWN}',
    insert: '{INS}', delete: '{DEL}', capslock: '{CAPSLOCK}', numlock: '{NUMLOCK}',
    scrolllock: '{SCROLLLOCK}', help: '{HELP}', f1: '{F1}', f2: '{F2}', f3: '{F3}', f4: '{F4}',
    f5: '{F5}', f6: '{F6}', f7: '{F7}', f8: '{F8}', f9: '{F9}', f10: '{F10}', f11: '{F11}',
    f12: '{F12}', f13: '{F13}', f14: '{F14}', f15: '{F15}', f16: '{F16}',
  }
  const core = NAMED[lower] ?? (/^[a-z0-9]$/.test(lower) ? lower : (/^[+%.^(){}[\]]$/.test(key) ? `{${key}}` : undefined))
  if (core === undefined) return undefined
  let prefix = ''
  if (mods.ctrl) prefix += '^'
  if (mods.shift) prefix += '+'
  if (mods.alt) prefix += '%'
  if (mods.win) return undefined // SendKeys has no Windows-key spelling; caller falls back to SendInput.
  return prefix + core
}

/** Press a key combination. SendKeys is primary (survives VDI/RDP input filtering); SendInput is the fallback for Win-key combos. */
export async function pressKey(key: string, mods: { ctrl?: boolean; shift?: boolean; alt?: boolean; win?: boolean }, signal?: AbortSignal): Promise<string> {
  const label = [mods.ctrl && 'Ctrl', mods.shift && 'Shift', mods.alt && 'Alt', mods.win && 'Win', key].filter(Boolean).join('+')
  const token = sendKeysToken(key, mods)
  if (token !== undefined) {
    const body = `
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.SendKeys]::SendWait('${token.replaceAll("'", "''")}')
Write-Output "pressed ${label}"
`.trim()
    return runPowershell(body, signal)
  }
  const codes = keyComboFromNames(key, mods)
  const downs = codes.map(code => `[void][NativeKeys]::Key(${code}, $true)`).join('\nStart-Sleep -Milliseconds 10\n')
  const ups = [...codes].reverse().map(code => `[void][NativeKeys]::Key(${code}, $false)`).join('\nStart-Sleep -Milliseconds 10\n')
  const body = `
${downs}
Start-Sleep -Milliseconds 30
${ups}
Write-Output "pressed ${label}"
`.trim()
  return runPowershell(withTypes(body), signal)
}

/** Scroll the wheel, optionally after moving the cursor. */
export async function scrollWheel(amount: number, x?: number, y?: number, signal?: AbortSignal): Promise<string> {
  const move = x !== undefined && y !== undefined ? `[void][NativeInput]::SetCursorPos(${Math.round(x)}, ${Math.round(y)})
Start-Sleep -Milliseconds 40` : ''
  // WHEEL_DELTA is 120 per notch.
  const data = Math.round(amount) * 120
  const body = `
${move}
[void][NativeInput]::mouse_event(0x800, 0, 0, ${data}, [UIntPtr]::Zero)
Write-Output "scrolled ${amount} notches"
`.trim()
  return runPowershell(withTypes(body), signal)
}

/** Move the cursor without clicking. */
export async function moveMouse(x: number, y: number, signal?: AbortSignal): Promise<string> {
  const body = `
[void][NativeInput]::SetCursorPos(${Math.round(x)}, ${Math.round(y)})
Write-Output "moved to ${Math.round(x)},${Math.round(y)}"
`.trim()
  return runPowershell(withTypes(body), signal)
}

/** Left-button drag between two points. */
export async function dragMouse(fromX: number, fromY: number, toX: number, toY: number, signal?: AbortSignal): Promise<string> {
  const body = `
[void][NativeInput]::SetCursorPos(${Math.round(fromX)}, ${Math.round(fromY)})
Start-Sleep -Milliseconds 50
[void][NativeInput]::mouse_event(0x02, 0, 0, 0, [UIntPtr]::Zero)
Start-Sleep -Milliseconds 50
[void][NativeInput]::SetCursorPos(${Math.round(toX)}, ${Math.round(toY)})
Start-Sleep -Milliseconds 120
[void][NativeInput]::mouse_event(0x04, 0, 0, 0, [UIntPtr]::Zero)
Write-Output "dragged (${Math.round(fromX)},${Math.round(fromY)}) to (${Math.round(toX)},${Math.round(toY)})"
`.trim()
  return runPowershell(withTypes(body), signal)
}
