/**
 * Visible top-level window enumeration and activation helpers.
 * @module dsh-computer-use-win/src/windows
 */

import { runPowershell } from './powershell.ts'

export interface WindowInfo {
  pid: number
  process: string
  className: string
  title: string
  left: number
  top: number
  width: number
  height: number
  isActive: boolean
}

/** List visible top-level windows with process, class, title, and screen rectangle. */
export async function listWindows(signal?: AbortSignal): Promise<WindowInfo[]> {
  const script = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class Win32List {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lp);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll", EntryPoint="GetWindowTextW", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder sb, int max);
  [DllImport("user32.dll", EntryPoint="GetClassNameW", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, System.Text.StringBuilder sb, int max);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  public struct RECT { public int Left, Top, Right, Bottom; }
}
"@
$rows = New-Object System.Collections.ArrayList
$fg = [Win32List]::GetForegroundWindow()
$cb = {
  param($hWnd, $lp)
  if (-not [Win32List]::IsWindowVisible($hWnd)) { return $true }
  $sb = New-Object System.Text.StringBuilder 512
  [void][Win32List]::GetWindowText($hWnd, $sb, 512)
  $title = $sb.ToString()
  if ($title.Length -eq 0) { return $true }
  $r = New-Object Win32List+RECT
  [void][Win32List]::GetWindowRect($hWnd, [ref]$r)
  if (($r.Right - $r.Left) -le 10 -or ($r.Bottom - $r.Top) -le 10) { return $true }
  $procId = 0
  [void][Win32List]::GetWindowThreadProcessId($hWnd, [ref]$procId)
  $proc = ""
  try { $proc = (Get-Process -Id $procId -ErrorAction Stop).ProcessName } catch {}
  $csb = New-Object System.Text.StringBuilder 256
  [void][Win32List]::GetClassName($hWnd, $csb, 256)
  $className = $csb.ToString()
  $active = ($hWnd -eq $fg)
  [void]$rows.Add((($procId, $proc, $className, $title, $r.Left, $r.Top, ($r.Right - $r.Left), ($r.Bottom - $r.Top), $active) -join [string][char]9))
  return $true
}
[Win32List]::EnumWindows($cb, [IntPtr]::Zero) | Out-Null
$rows | ForEach-Object { $_ }
`.trim()
  const out = await runPowershell(script, signal, 30_000)
  return out.split(/\r?\n/).filter(line => line.includes('\t')).map((line) => {
    const [pid, process, className, title, left, top, width, height, active] = line.split('\t')
    return {
      pid: Number(pid),
      process,
      className,
      title,
      left: Number(left),
      top: Number(top),
      width: Number(width),
      height: Number(height),
      isActive: active === 'True',
    }
  })
}

const FOCUS_TYPES = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Focus {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lp);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
  [DllImport("user32.dll", EntryPoint="GetWindowTextW", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder sb, int max);
  [DllImport("user32.dll", EntryPoint="GetClassNameW", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, System.Text.StringBuilder sb, int max);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
}
"@
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32FocusRect {
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
  public struct RECT { public int Left, Top, Right, Bottom; }
}
"@
`.trim()

function psText(value: string): string {
  return value.replaceAll("'", "''")
}

function windowActivationScript(match: string, clickTitleBar: boolean): string {
  const clickTypes = clickTitleBar ? `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32FocusClick {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
}
"@` : ''
  const clickBody = clickTitleBar ? `
[void][Win32FocusClick]::SetCursorPos($cx, $cy)
Start-Sleep -Milliseconds 80
[void][Win32FocusClick]::mouse_event(2, 0, 0, 0, [UIntPtr]::Zero)
Start-Sleep -Milliseconds 40
[void][Win32FocusClick]::mouse_event(4, 0, 0, 0, [UIntPtr]::Zero)
Start-Sleep -Milliseconds 150
Write-Output "focused pid=$targetPid [$targetProc] {$targetClass} $targetTitle at ($cx,$cy)"` : `
Write-Output "activated pid=$targetPid [$targetProc] {$targetClass} $targetTitle"`

  return `
${FOCUS_TYPES}
${clickTypes}
$m = '${psText(match)}'
$target = [IntPtr]::Zero
$targetTitle = ""
$targetProc = ""
$targetPid = 0
$targetClass = ""
$candidates = New-Object System.Collections.ArrayList
$cb = {
  param($hWnd, $lp)
  if (-not [Win32Focus]::IsWindowVisible($hWnd)) { return $true }
  $sb = New-Object System.Text.StringBuilder 512
  [void][Win32Focus]::GetWindowText($hWnd, $sb, 512)
  $title = $sb.ToString()
  if ($title.Length -eq 0) { return $true }
  $r0 = New-Object Win32FocusRect+RECT
  [void][Win32FocusRect]::GetWindowRect($hWnd, [ref]$r0)
  if (($r0.Right - $r0.Left) -le 10 -or ($r0.Bottom - $r0.Top) -le 10) { return $true }
  $pid2 = 0
  [void][Win32Focus]::GetWindowThreadProcessId($hWnd, [ref]$pid2)
  $proc = ""
  try { $proc = (Get-Process -Id $pid2 -ErrorAction Stop).ProcessName } catch {}
  $csb = New-Object System.Text.StringBuilder 256
  [void][Win32Focus]::GetClassName($hWnd, $csb, 256)
  $className = $csb.ToString()
  if ($candidates.Count -lt 8) { [void]$candidates.Add(("pid=$pid2 [$proc] {$className} $title")) }
  if ($title -like "*$m*" -or $proc -like "*$m*" -or ([string]$pid2) -eq $m -or $className -like "*$m*") {
    $script:target = $hWnd
    $script:targetTitle = $title
    $script:targetProc = $proc
    $script:targetPid = $pid2
    $script:targetClass = $className
    return $false
  }
  return $true
}
[void][Win32Focus]::EnumWindows($cb, [IntPtr]::Zero)
if ($target -eq [IntPtr]::Zero) { throw "no visible window matches '$m'. Try one of: $($candidates -join '; ')" }
if ([Win32Focus]::IsIconic($target)) { [void][Win32Focus]::ShowWindow($target, 9) }
Start-Sleep -Milliseconds 150
[void][Win32Focus]::SetForegroundWindow($target)
Start-Sleep -Milliseconds 250
$r = New-Object Win32FocusRect+RECT
[void][Win32FocusRect]::GetWindowRect($target, [ref]$r)
$cx = [int](($r.Left + $r.Right) / 2)
$cy = [int]($r.Top + 12)
${clickBody}
`.trim()
}

/** Bring a matching window to the foreground and click its title bar. */
export async function focusWindow(match: string, signal?: AbortSignal): Promise<string> {
  return runPowershell(windowActivationScript(match, true), signal)
}

/** Bring a matching window to the foreground without moving mouse focus. */
export async function activateWindow(match: string, signal?: AbortSignal): Promise<string> {
  return runPowershell(windowActivationScript(match, false), signal)
}
