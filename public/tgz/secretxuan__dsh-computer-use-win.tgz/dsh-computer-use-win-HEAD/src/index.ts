/**
 * Windows computer-use bundle for DeepSeek Harness (dsh).
 *
 * Contributes model-facing tools for screenshot capture (full screen or a
 * specific window), window enumeration, and mouse/keyboard control. All
 * input-injecting actions go through the dsh approval seam before executing.
 *
 * Implementation note: everything runs through PowerShell (.NET) so the plugin
 * has zero native dependencies: System.Drawing for screen capture,
 * SetCursorPos/SendInput P/Invoke for pointer and keyboard injection.
 * @module dsh-computer-use-win
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import { AttachmentId } from '@deepseek-ai/dsh-attachment'
import type { ImageAttachmentRef, ImageMediaType } from '@deepseek-ai/dsh-attachment'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolExecution } from '@deepseek-ai/dsh-tools'
import { runPowershell, pwshPath } from './powershell.ts'
import { captureScreen, captureWindow } from './screenshot.ts'
import { activateWindow, listWindows, focusWindow } from './windows.ts'
import { listElements, screenMetrics } from './elements.ts'
import { locateOcrText, ocrImage } from './ocr.ts'
import { observeImage, type ObserveRegion } from './observe.ts'
import { openSettings } from './apps.ts'
import { clickMouse, typeText, pressKey, scrollWheel, moveMouse, dragMouse, keyComboFromNames } from './input.ts'

const execFileAsync = promisify(execFile)

export const name = 'dsh-computer-use-win'
export const inject = ['tools', 'attachments']

export interface Config {
  /** Ask approval before every input-injecting action (click/type/key/scroll/drag). */
  requireApproval?: boolean
  /** Maximum screenshot PNG bytes kept inline. */
  maxScreenshotBytes?: number
}

export const Config: z<Config> = z.object({
  requireApproval: z.boolean().default(true),
  maxScreenshotBytes: z.number().default(8 * 1024 * 1024),
})

/** Ask the approval seam for a one-use grant; returns false when denied. */
async function askApproval(ctx: Context, exec: ToolExecution, action: string): Promise<boolean> {
  const approval = ctx.get('approval')
  if (approval === undefined) return false
  const outcome = await approval.request({
    agent: exec.agent,
    toolName: exec.name,
    callId: exec.callId,
    reason: `Computer Use (Windows): ${action}`,
    signal: exec.signal,
  })
  return outcome === 'allowed-once'
}

/**
 * Decide whether one input-injecting action needs an approval ask.
 *
 * The plugin never escapes dsh's own permission model: it reads the same two
 * knobs the permission presets write:
 *
 * - Approval policy `'never'` + sandbox `danger-full-access` is exactly the
 *   "Full Access" preset: the user has already consented to unconstrained
 *   execution AND told the session to stop asking. `approval.request()` would
 *   deterministically return 'rejected' (the policy's meaning is "never ask,
 *   fail closed"), so asking is not caution; it is a guaranteed denial that
 *   makes every input tool unusable. Treat the action as pre-authorized.
 * - `'never'` while still sandboxed stays a denial: fail-closed is the right
 *   reading of "unattended and not fully granted".
 * - `'ask'` asks; denial or an unavailable answerer denies.
 */
function shouldAskApproval(ctx: Context, exec: ToolExecution, requireApproval: boolean): boolean {
  if (!requireApproval) return false
  const approval = ctx.get('approval')
  if (approval === undefined) return true
  if (exec.agent === undefined) return true
  const policy = approval.overrideOf(exec.agent.session) ?? approval.config?.policy ?? 'ask'
  if (policy === 'ask') return true
  // 'never': authorized only when the session also runs with full access.
  const sandboxPolicy = ctx.get('sandboxPolicy')
  if (sandboxPolicy === undefined) return true
  const mode = sandboxPolicy.resolve({ session: exec.agent.session }).mode
  return mode !== 'danger-full-access'
}

/** Resolve whether the calling route's model accepts image input. */
export async function routeAcceptsImages(ctx: Context, exec: ToolExecution): Promise<boolean> {
  try {
    const routed = exec.agent?.session.requestHeader()?.config
    const provider = routed?.provider ?? exec.agent?.options.provider
    const model = routed?.model ?? exec.agent?.options.model
    const llm = ctx.get('llm')
    if (provider === undefined || model === undefined || llm === undefined) return false
    const info = await llm.resolveModelInfo(provider, model, exec.signal)
    return info.inputModalities?.includes('image') ?? false
  } catch {
    return false
  }
}

export function apply(ctx: Context, config: Config) {
  const requireApproval = config.requireApproval ?? true
  const maxBytes = config.maxScreenshotBytes ?? 8 * 1024 * 1024

  // 鈹€鈹€ computer_screenshot 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€
  ctx.tools.register(defineTool({
    name: 'computer_screenshot',
    description:
      'Capture a Windows screenshot. Vision-capable routes receive an image block. Text-only routes receive a saved PNG path only; the model cannot inspect pixels from that path by itself. '
      + 'Use computer_ocr_window/computer_ocr_image or an image-capable model when you need text or coordinates from the screenshot. '
      + 'Captures the full virtual screen by default, or a specific window by title substring, process name, PID, or class name.',
    parameters: {
      window: { type: 'string', description: 'Title substring, process name, PID, or class name of the window to capture; omit for the full screen.' },
      monitor: { type: 'number', description: 'Monitor index (0-based) for full-screen capture; defaults to the primary monitor.' },
    },
    output: {
      schema: {
        oneOf: [
          {
            type: 'object',
            additionalProperties: false,
            properties: {
              image: {
                type: 'object',
                additionalProperties: false,
                required: true,
                properties: {
                  attachmentId: { type: 'string', required: true },
                  mediaType: { type: 'string', enum: ['image/png'], required: true },
                  bytes: { type: 'integer', required: true },
                  width: { type: 'integer', required: true },
                  height: { type: 'integer', required: true },
                  name: { type: 'string' },
                },
              },
            },
          },
          {
            type: 'object',
            additionalProperties: false,
            properties: {
              file: {
                type: 'object',
                additionalProperties: false,
                required: true,
                properties: {
                  path: { type: 'string', required: true },
                  left: { type: 'integer', required: true },
                  top: { type: 'integer', required: true },
                  width: { type: 'integer', required: true },
                  height: { type: 'integer', required: true },
                  bytes: { type: 'integer', required: true },
                },
              },
            },
          },
        ],
      },
      render: (_args, value) => imageContent('file' in value && value.file !== undefined
        ? value.file
        : (value as { image: Parameters<typeof imageContent>[0] }).image),
    },
    async execute(args, exec) {
      const attachments = ctx.get('attachments')
      if (attachments === undefined) throw new Error('computer_screenshot: no attachment service is mounted')

      // Pure-text models cannot carry an image block; persist the PNG and
      // return its path so the call still succeeds instead of breaking the
      // route with UNSUPPORTED_CONTENT on the next model request.
      const imageRoute = await routeAcceptsImages(ctx, exec)

      const dir = await mkdtemp(join(tmpdir(), 'dsh-cu-'))
      const png = join(dir, args.window !== undefined ? 'window.png' : 'screen.png')
      try {
        const captureArgs = args.window !== undefined
          ? await captureWindow(png, args.window, exec.signal)
          : await captureScreen(png, args.monitor ?? 0, exec.signal)
        const data = await readFile(png)
        if (data.byteLength > maxBytes) {
          throw new Error(`computer_screenshot: screenshot is ${data.byteLength} bytes, over the ${maxBytes} limit`)
        }
        if (!imageRoute) {
          const kept = join(tmpdir(), `dsh-cu-shot-${Date.now()}.png`)
          const { writeFile } = await import('node:fs/promises')
          await writeFile(kept, data)
          return { file: {
            path: kept,
            left: captureArgs.left,
            top: captureArgs.top,
            width: captureArgs.width,
            height: captureArgs.height,
            bytes: data.byteLength,
          } }
        }
        const ref = await attachments.saveImage({ data, mediaType: 'image/png', name: args.window !== undefined ? `${args.window}.png` : 'screen.png' })
        const value: { image: { attachmentId: string; mediaType: 'image/png'; bytes: number; width: number; height: number; name?: string } } = { image: {
          attachmentId: ref.attachmentId,
          mediaType: 'image/png',
          bytes: ref.bytes,
          width: ref.width,
          height: ref.height,
          ...ref.name === undefined ? {} : { name: ref.name },
        } }
        return value
      } finally {
        await rm(dir, { recursive: true, force: true }).catch(() => {})
      }
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: args.window !== undefined ? `Screenshot window "${args.window}"` : 'Screenshot screen',
        kind: 'read',
      }
    },
  }))

  // 鈹€鈹€ computer_list_windows 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€
  ctx.tools.register(defineTool({
    name: 'computer_list_windows',
    description: 'List visible top-level windows on Windows with process name, window title, and screen rectangle. Use before targeting a window for capture or input.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          windows: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                pid: { type: 'integer', required: true },
                process: { type: 'string', required: true },
                className: { type: 'string', required: true },
                title: { type: 'string', required: true },
                left: { type: 'integer', required: true },
                top: { type: 'integer', required: true },
                width: { type: 'integer', required: true },
                height: { type: 'integer', required: true },
                isActive: { type: 'boolean', required: true },
              },
            },
          },
        },
      },
      render: (_args, value) => {
        const windows = value.windows ?? []
        const lines = windows.map(w =>
          `${w.isActive ? '* ' : '  '}pid=${w.pid} [${w.process}] {${w.className}} "${w.title}" (${w.left},${w.top} ${w.width}x${w.height})`)
        return [{ type: 'text' as const, text: lines.length > 0 ? lines.join('\n') : 'no visible windows' }]
      },
    },
    async execute() {
      return { windows: await listWindows() }
    },
    presentCall() {
      return { card: 'generic', title: 'List windows', kind: 'search' }
    },
  }))

  // computer_list_elements
  // UI Automation exposes native/accessibility-aware controls. CEF and custom
  // rendered apps often expose only a host pane, so OCR is the fallback.
  const elementRows = (elements: ElementRow[]) => {
    if (elements.length === 0) return 'no matching elements'
    return elements.map(e =>
      `${e.focused ? '* ' : '  '}${e.controlType} "${e.name}"${e.className !== '' ? ` [${e.className}]` : ''}`
      + `${e.automationId !== '' ? ` automationId=${e.automationId}` : ''} pid=${e.pid} [${e.process}]`
      + ` rect=(${e.left},${e.top} ${e.width}x${e.height}) click=(${e.centerX},${e.centerY})${e.enabled ? '' : ' [disabled]'}`)
      .join('\n')
  }

  const elementDiagnostics = (args: { name?: string; window?: string }, elements: ElementRow[]): string[] => {
    const diagnostics: string[] = []
    if (args.name !== undefined && args.window === undefined) {
      diagnostics.push('global-name-search: results may include unrelated windows; pass window when you know the target app.')
      const processes = new Set(elements.map(e => `${e.pid}:${e.process}`))
      if (processes.size > 1) diagnostics.push(`multiple-processes: matched ${processes.size} processes; scope the next call with window/process/pid before clicking.`)
    }
    const cefShell = elements.some(e => /Chrome_RenderWidgetHostHWND|Cef|Chrome Legacy Window|OrpheusBrowserHost/i.test(`${e.className} ${e.name}`))
    const shallow = args.window !== undefined && elements.length <= 3
    if (cefShell || shallow) {
      diagnostics.push('uia-limited: this looks like a CEF/Chromium/custom-rendered window. UI Automation may not expose internal controls; use computer_ocr_window/computer_click_text or a vision-capable route.')
    }
    return diagnostics
  }

  ctx.tools.register(defineTool({
    name: 'computer_list_elements',
    description:
      'List controls exposed through Windows UI Automation. This works well for native/accessibility-aware apps, but CEF/Chromium/Electron/custom-rendered apps may expose only a shell pane. '
      + 'Pass window (title substring, process name, PID, or class name) to scope the dump. Pass name to search labels/ClassName/AutomationId; without window it searches the whole desktop and may include unrelated apps. '
      + 'Each result includes a physical-pixel rect and click=(x,y) center for computer_click. If diagnostics say UIA is limited, use computer_ocr_window/computer_click_text or a vision-capable route.',
    parameters: {
      name: { type: 'string', description: 'Substring of the control label (Name), ClassName, or AutomationId, e.g. "Start", "Settings", "Save", "搜索".' },
      window: { type: 'string', description: 'Title substring, process name, PID, or class name of a top-level window to dump or search within; omit with name to search the whole desktop, omit both for the focused window.' },
      maxDepth: { type: 'number', description: 'Tree depth for window dumps (1-8, default 4). Ignored in name-search mode (search is always full-depth).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          screen: {
            type: 'object',
            additionalProperties: false,
            required: true,
            properties: {
              left: { type: 'integer', required: true },
              top: { type: 'integer', required: true },
              width: { type: 'integer', required: true },
              height: { type: 'integer', required: true },
              dpiScale: { type: 'number', required: true },
            },
          },
          elements: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                name: { type: 'string', required: true },
                controlType: { type: 'string', required: true },
                className: { type: 'string', required: true },
                automationId: { type: 'string', required: true },
                pid: { type: 'integer', required: true },
                process: { type: 'string', required: true },
                left: { type: 'integer', required: true },
                top: { type: 'integer', required: true },
                width: { type: 'integer', required: true },
                height: { type: 'integer', required: true },
                centerX: { type: 'integer', required: true },
                centerY: { type: 'integer', required: true },
                focused: { type: 'boolean', required: true },
                enabled: { type: 'boolean', required: true },
              },
            },
          },
          diagnostics: {
            type: 'array',
            required: true,
            items: { type: 'string' },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text' as const,
        text: `virtual screen (${value.screen.left},${value.screen.top}) ${value.screen.width}x${value.screen.height} @${value.screen.dpiScale}x\n`
          + (value.diagnostics.length > 0 ? `diagnostics:\n${value.diagnostics.map(d => `- ${d}`).join('\n')}\n` : '')
          + elementRows(value.elements),
      }],
    },
    async execute(args, exec) {
      if (args.name === undefined && args.window === undefined) {
        // Default: focused window dump: the "what am I looking at" call.
      }
      const [screen, elements] = await Promise.all([
        screenMetrics(exec.signal),
        listElements({ window: args.window, name: args.name, maxDepth: args.maxDepth, signal: exec.signal }),
      ])
      return { screen, elements, diagnostics: elementDiagnostics(args, elements) }
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: args.name !== undefined ? `Find elements "${args.name}"` : `Element tree${args.window !== undefined ? ` of "${args.window}"` : ' (focused)'}`,
        kind: 'search',
      }
    },
  }))

  const ocrWordSchema = {
    type: 'object',
    additionalProperties: false,
    properties: {
      text: { type: 'string', required: true },
      left: { type: 'integer', required: true },
      top: { type: 'integer', required: true },
      width: { type: 'integer', required: true },
      height: { type: 'integer', required: true },
      centerX: { type: 'integer', required: true },
      centerY: { type: 'integer', required: true },
    },
  } as const
  const ocrLineSchema = {
    type: 'object',
    additionalProperties: false,
    properties: {
      text: { type: 'string', required: true },
      left: { type: 'integer', required: true },
      top: { type: 'integer', required: true },
      width: { type: 'integer', required: true },
      height: { type: 'integer', required: true },
      centerX: { type: 'integer', required: true },
      centerY: { type: 'integer', required: true },
      words: { type: 'array', required: true, items: ocrWordSchema },
    },
  } as const
  const ocrResultSchema = {
    type: 'object',
    additionalProperties: false,
    properties: {
      path: { type: 'string', required: true },
      originX: { type: 'integer', required: true },
      originY: { type: 'integer', required: true },
      width: { type: 'integer', required: true },
      height: { type: 'integer', required: true },
      text: { type: 'string', required: true },
      lines: { type: 'array', required: true, items: ocrLineSchema },
    },
  } as const
  const ocrRows = (lines: OcrLineRow[]) => {
    if (lines.length === 0) return 'no OCR text found'
    return lines.map(line => `"${line.text}" rect=(${line.left},${line.top} ${line.width}x${line.height}) click=(${line.centerX},${line.centerY})`).join('\n')
  }
  const visualCandidateSchema = {
    type: 'object',
    additionalProperties: false,
    properties: {
      kind: { type: 'string', required: true },
      label: { type: 'string', required: true },
      confidence: { type: 'number', required: true },
      left: { type: 'integer', required: true },
      top: { type: 'integer', required: true },
      width: { type: 'integer', required: true },
      height: { type: 'integer', required: true },
      centerX: { type: 'integer', required: true },
      centerY: { type: 'integer', required: true },
      evidence: { type: 'string', required: true },
    },
  } as const
  const uiRegionSchema = {
    type: 'object',
    additionalProperties: false,
    properties: {
      kind: { type: 'string', required: true },
      label: { type: 'string', required: true },
      left: { type: 'integer', required: true },
      top: { type: 'integer', required: true },
      width: { type: 'integer', required: true },
      height: { type: 'integer', required: true },
      centerX: { type: 'integer', required: true },
      centerY: { type: 'integer', required: true },
    },
  } as const
  const observeResultSchema = {
    type: 'object',
    additionalProperties: false,
    properties: {
      path: { type: 'string', required: true },
      originX: { type: 'integer', required: true },
      originY: { type: 'integer', required: true },
      width: { type: 'integer', required: true },
      height: { type: 'integer', required: true },
      regions: { type: 'array', required: true, items: uiRegionSchema },
      texts: { type: 'array', required: true, items: ocrLineSchema },
      icons: { type: 'array', required: true, items: visualCandidateSchema },
      clickables: { type: 'array', required: true, items: visualCandidateSchema },
      mediaControls: {
        type: 'object',
        additionalProperties: false,
        required: true,
        properties: {
          state: { type: 'string', required: true },
          meaning: { type: 'string', required: true },
          hasToggle: { type: 'boolean', required: true },
          toggle: visualCandidateSchema,
        },
      },
      suggestedActions: {
        type: 'array',
        required: true,
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            action: { type: 'string', required: true },
            target: { type: 'string', required: true },
            purpose: { type: 'string', required: true },
            x: { type: 'integer', required: true },
            y: { type: 'integer', required: true },
            confidence: { type: 'number', required: true },
            tool: { type: 'string', required: true },
            verifyWith: { type: 'string', required: true },
          },
        },
      },
      warnings: { type: 'array', required: true, items: { type: 'string' } },
      suggestions: { type: 'array', required: true, items: { type: 'string' } },
    },
  } as const
  const observeRows = (value: {
    path: string
    originX: number
    originY: number
    width: number
    height: number
    icons: Array<{ kind: string; label: string; confidence: number; left: number; top: number; width: number; height: number; centerX: number; centerY: number; evidence: string }>
    texts: OcrLineRow[]
    mediaControls: { state: string; meaning: string; hasToggle: boolean; toggle?: { centerX: number; centerY: number; confidence: number; label: string } }
    suggestedActions: Array<{ action: string; target: string; purpose: string; x: number; y: number; confidence: number; tool: string; verifyWith: string }>
    warnings: string[]
    suggestions: string[]
  }) => {
    const icons = value.icons.slice(0, 20).map(c =>
      `${c.kind} "${c.label}" confidence=${c.confidence} rect=(${c.left},${c.top} ${c.width}x${c.height}) click=(${c.centerX},${c.centerY}) evidence=${c.evidence}`)
    const actions = value.suggestedActions.slice(0, 8).map(a =>
      `${a.action} target=${a.target} purpose="${a.purpose}" confidence=${a.confidence} tool=${a.tool} click=(${a.x},${a.y}) verify=${a.verifyWith}`)
    const texts = value.texts.slice(0, 30)
    return `visual observation ${value.width}x${value.height} origin=(${value.originX},${value.originY}) from ${value.path}\n`
      + `warnings:\n${value.warnings.map(w => `- ${w}`).join('\n')}\n`
      + `media controls: state=${value.mediaControls.state}; ${value.mediaControls.meaning}`
      + `${value.mediaControls.toggle !== undefined ? `; toggle=(${value.mediaControls.toggle.centerX},${value.mediaControls.toggle.centerY}) confidence=${value.mediaControls.toggle.confidence}` : ''}\n`
      + `suggested actions:\n${actions.length > 0 ? actions.join('\n') : 'none'}\n`
      + `suggestions:\n${value.suggestions.map(s => `- ${s}`).join('\n')}\n`
      + `visual candidates:\n${icons.length > 0 ? icons.join('\n') : 'none'}\n`
      + `ocr text:\n${ocrRows(texts)}`
  }
  const regionFromArgs = (args: { region?: string; left?: number; top?: number; width?: number; height?: number }): ObserveRegion | undefined => {
    if (args.region !== undefined) return { name: args.region as ObserveRegion['name'] }
    if (args.left !== undefined || args.top !== undefined || args.width !== undefined || args.height !== undefined) {
      return { left: args.left, top: args.top, width: args.width, height: args.height }
    }
    return undefined
  }
  const keepOcrWindowPng = async (window: string, signal?: AbortSignal) => {
    const png = join(tmpdir(), `dsh-cu-ocr-${Date.now()}.png`)
    await focusWindow(window, signal)
    const capture = await captureWindow(png, window, signal)
    return { png, capture }
  }

  ctx.tools.register(defineTool({
    name: 'computer_ocr_image',
    description:
      'Run Windows OCR on an existing image file and return recognized text with absolute physical-pixel boxes. '
      + 'Use this after computer_screenshot on text-only routes. Pass originX/originY when the image is a window crop so boxes map back to screen coordinates.',
    parameters: {
      path: { type: 'string', required: true, description: 'PNG/JPEG/BMP path to OCR.' },
      originX: { type: 'number', description: 'Screen X coordinate of the image left edge; defaults to 0.' },
      originY: { type: 'number', description: 'Screen Y coordinate of the image top edge; defaults to 0.' },
      region: { type: 'string', enum: ['top-bar', 'left-sidebar', 'main-content', 'bottom-bar'], description: 'Optional named image region to OCR for faster targeted text extraction.' },
      left: { type: 'number', description: 'Optional image-relative crop left. Use with top/width/height instead of region.' },
      top: { type: 'number', description: 'Optional image-relative crop top. Use with left/width/height instead of region.' },
      width: { type: 'number', description: 'Optional image-relative crop width.' },
      height: { type: 'number', description: 'Optional image-relative crop height.' },
    },
    output: {
      schema: ocrResultSchema,
      render: (_args, value) => [{
        type: 'text' as const,
        text: `OCR ${value.width}x${value.height} origin=(${value.originX},${value.originY}) from ${value.path}\n${ocrRows(value.lines)}`,
      }],
    },
    async execute(args, exec) {
      const region = regionFromArgs(args)
      if (region === undefined) return ocrImage(args.path, args.originX ?? 0, args.originY ?? 0, exec.signal)
      const observed = await observeImage(args.path, args.originX ?? 0, args.originY ?? 0, exec.signal, region)
      return {
        path: observed.path,
        originX: observed.originX,
        originY: observed.originY,
        width: observed.width,
        height: observed.height,
        text: observed.texts.map(line => line.text).join('\n'),
        lines: observed.texts,
      }
    },
    presentCall(args) {
      return { card: 'generic', title: `OCR image ${args.path}`, kind: 'read' }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_ocr_window',
    description:
      'Focus a target window, capture it, and run Windows OCR on it. Returns text lines/words with absolute physical-pixel boxes and click centers. '
      + 'Use this when UI Automation reports a CEF/Chromium/custom-rendered shell or when a text-only model needs screen text coordinates.',
    parameters: {
      window: { type: 'string', required: true, description: 'Title substring, process name, PID, or class name of the window to capture and OCR.' },
      region: { type: 'string', enum: ['top-bar', 'left-sidebar', 'main-content', 'bottom-bar'], description: 'Optional named window region to OCR for faster targeted text extraction.' },
      left: { type: 'number', description: 'Optional window-relative crop left. Use with top/width/height instead of region.' },
      top: { type: 'number', description: 'Optional window-relative crop top. Use with left/width/height instead of region.' },
      width: { type: 'number', description: 'Optional window-relative crop width.' },
      height: { type: 'number', description: 'Optional window-relative crop height.' },
    },
    output: {
      schema: ocrResultSchema,
      render: (_args, value) => [{
        type: 'text' as const,
        text: `OCR window ${value.width}x${value.height} origin=(${value.originX},${value.originY}) saved=${value.path}\n${ocrRows(value.lines)}`,
      }],
    },
    async execute(args, exec) {
      const { png, capture } = await keepOcrWindowPng(args.window, exec.signal)
      const region = regionFromArgs(args)
      if (region === undefined) return ocrImage(png, capture.left, capture.top, exec.signal)
      const observed = await observeImage(png, capture.left, capture.top, exec.signal, region)
      return {
        path: observed.path,
        originX: observed.originX,
        originY: observed.originY,
        width: observed.width,
        height: observed.height,
        text: observed.texts.map(line => line.text).join('\n'),
        lines: observed.texts,
      }
    },
    presentCall(args) {
      return { card: 'generic', title: `OCR window "${args.window}"`, kind: 'read' }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_observe_image',
    description:
      'Create a generic text-model UI map from an existing PNG/JPEG/BMP: OCR text boxes, coarse UI regions, clickable text centers, and heuristic visual candidates such as red primary buttons or round media controls. '
      + 'Use this when the current route is text-only and needs basic perception from a screenshot path. This does not make the model truly see pixels; visual candidates are best-effort and include confidence/evidence.',
    parameters: {
      path: { type: 'string', required: true, description: 'PNG/JPEG/BMP path to observe.' },
      originX: { type: 'number', description: 'Screen X coordinate of the image left edge; defaults to 0.' },
      originY: { type: 'number', description: 'Screen Y coordinate of the image top edge; defaults to 0.' },
      region: { type: 'string', enum: ['top-bar', 'left-sidebar', 'main-content', 'bottom-bar'], description: 'Optional named region. Use bottom-bar for player/status controls and top-bar for search/navigation.' },
      left: { type: 'number', description: 'Optional image-relative crop left. Use with top/width/height instead of region.' },
      top: { type: 'number', description: 'Optional image-relative crop top. Use with left/width/height instead of region.' },
      width: { type: 'number', description: 'Optional image-relative crop width.' },
      height: { type: 'number', description: 'Optional image-relative crop height.' },
    },
    output: {
      schema: observeResultSchema,
      render: (_args, value) => [{ type: 'text' as const, text: observeRows(value) }],
    },
    async execute(args, exec) {
      return observeImage(args.path, args.originX ?? 0, args.originY ?? 0, exec.signal, regionFromArgs(args))
    },
    presentCall(args) {
      return { card: 'generic', title: `Observe image ${args.path}`, kind: 'read' }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_observe_window',
    description:
      'Focus a window, capture it, and create a generic text-model UI map: OCR text boxes, coarse UI regions, clickable text centers, and heuristic visual candidates such as red primary buttons or round media controls. '
      + 'Use this for custom-rendered apps when UI Automation is shallow and the task involves icon-only controls, search boxes, or visual button placement. Coordinates are absolute physical virtual-desktop pixels.',
    parameters: {
      window: { type: 'string', required: true, description: 'Title substring, process name, PID, or class name of the window to observe.' },
      region: { type: 'string', enum: ['top-bar', 'left-sidebar', 'main-content', 'bottom-bar'], description: 'Optional named region. Use bottom-bar for player/status controls and top-bar for search/navigation.' },
      left: { type: 'number', description: 'Optional window-relative crop left. Use with top/width/height instead of region.' },
      top: { type: 'number', description: 'Optional window-relative crop top. Use with left/width/height instead of region.' },
      width: { type: 'number', description: 'Optional window-relative crop width.' },
      height: { type: 'number', description: 'Optional window-relative crop height.' },
    },
    output: {
      schema: observeResultSchema,
      render: (_args, value) => [{ type: 'text' as const, text: observeRows(value) }],
    },
    async execute(args, exec) {
      const { png, capture } = await keepOcrWindowPng(args.window, exec.signal)
      return observeImage(png, capture.left, capture.top, exec.signal, regionFromArgs(args))
    },
    presentCall(args) {
      return { card: 'generic', title: `Observe window "${args.window}"`, kind: 'read' }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_locate_text',
    description:
      'Locate visible text in a window using OCR and return matching text boxes with click centers, without moving the mouse. '
      + 'Use this before clicking inside custom/CEF apps when UI Automation cannot see internal controls.',
    parameters: {
      window: { type: 'string', required: true, description: 'Title substring, process name, PID, or class name of the window to OCR.' },
      text: { type: 'string', required: true, description: 'Text to find in OCR output.' },
      match: { type: 'string', enum: ['contains', 'exact'], description: 'contains (default) or exact line match.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ocr: { ...ocrResultSchema, required: true },
          matches: { type: 'array', required: true, items: ocrLineSchema },
          diagnostics: { type: 'array', required: true, items: { type: 'string' } },
        },
      },
      render: (_args, value) => [{
        type: 'text' as const,
        text: `${value.matches.length} OCR text match(es)\n`
          + (value.diagnostics.length > 0 ? `diagnostics:\n${value.diagnostics.map(d => `- ${d}`).join('\n')}\n` : '')
          + ocrRows(value.matches),
      }],
    },
    async execute(args, exec) {
      const { png, capture } = await keepOcrWindowPng(args.window, exec.signal)
      const ocr = await ocrImage(png, capture.left, capture.top, exec.signal)
      const matches = locateOcrText(ocr, args.text, args.match ?? 'contains')
      const diagnostics = matches.length === 0
        ? [`text-not-found: OCR did not find "${args.text}". Review the OCR text summary before guessing coordinates.`]
        : []
      return { ocr, matches, diagnostics }
    },
    presentCall(args) {
      return { card: 'generic', title: `Locate text "${args.text}" in "${args.window}"`, kind: 'search' }
    },
  }))

  // 鈹€鈹€ input-injecting tools (approval-gated) 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€
  // Every input tool accepts an optional `focus` substring: the window whose
  // title or process matches is brought to the foreground FIRST, because
  // SendInput goes to whatever has focus; typing into a background window
  // silently lands in the wrong place.
  const gated = async (exec: ToolExecution, action: string, focus: string | undefined, run: () => Promise<string>, focusMode: 'title-click' | 'activate' = 'title-click'): Promise<string> => {
    if (shouldAskApproval(ctx, exec, requireApproval) && !(await askApproval(ctx, exec, action))) {
      throw new Error(`computer-use action denied by approval policy: ${action}`)
    }
    if (focus !== undefined && focus.length > 0) {
      if (focusMode === 'activate') await activateWindow(focus, exec.signal)
      else await focusWindow(focus, exec.signal)
    }
    return run()
  }

  ctx.tools.register(defineTool({
    name: 'computer_observe_media_controls',
    description:
      'Observe the bottom/status/player area of a window and return the best generic media toggle state. '
      + 'Use this instead of custom pixel-scanning scripts when a task needs to know whether a play/pause control is showing pause bars, a play triangle, or an uncertain media button.',
    parameters: {
      window: { type: 'string', required: true, description: 'Title substring, process name, PID, or class name of the window to observe.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          observation: { ...observeResultSchema, required: true },
          state: { type: 'string', required: true },
          meaning: { type: 'string', required: true },
          hasToggle: { type: 'boolean', required: true },
          x: { type: 'integer' },
          y: { type: 'integer' },
          confidence: { type: 'number' },
          message: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text' as const, text: value.message }],
    },
    async execute(args, exec) {
      const { png, capture } = await keepOcrWindowPng(args.window, exec.signal)
      const observation = await observeImage(png, capture.left, capture.top, exec.signal, { name: 'bottom-bar' })
      const toggle = observation.mediaControls.toggle
      const message = toggle === undefined
        ? `media controls: state=${observation.mediaControls.state}; ${observation.mediaControls.meaning}`
        : `media controls: state=${observation.mediaControls.state}; ${observation.mediaControls.meaning}; toggle=(${toggle.centerX},${toggle.centerY}) confidence=${toggle.confidence}. If this matches the task, click it and verify with computer_observe_media_controls.`
      return {
        observation,
        state: observation.mediaControls.state,
        meaning: observation.mediaControls.meaning,
        hasToggle: observation.mediaControls.hasToggle,
        ...(toggle === undefined ? {} : { x: toggle.centerX, y: toggle.centerY, confidence: toggle.confidence }),
        message,
      }
    },
    presentCall(args) {
      return { card: 'generic', title: `Observe media controls in "${args.window}"`, kind: 'read' }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_search_in_window',
    description:
      'Generic search flow for desktop apps: observe the top bar, find a likely search field, click it, optionally Ctrl+A existing text, type the query, and optionally press Enter. '
      + 'Use this instead of manually chaining click/type/enter when a task asks to search inside an app. If no search field candidate is found, the tool fails with a short actionable message rather than guessing coordinates.',
    parameters: {
      window: { type: 'string', required: true, description: 'Title substring, process name, PID, or class name of the window to search in.' },
      query: { type: 'string', required: true, description: 'Text to type into the search field.' },
      pressEnter: { type: 'boolean', description: 'Press Enter after typing; defaults to true.' },
      selectExisting: { type: 'boolean', description: 'Press Ctrl+A before typing; defaults to true.' },
      purpose: { type: 'string', description: 'Why this search helps the task.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          searched: { type: 'boolean', required: true },
          x: { type: 'integer', required: true },
          y: { type: 'integer', required: true },
          query: { type: 'string', required: true },
          observation: { ...observeResultSchema, required: true },
          message: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text' as const, text: value.message }],
    },
    async execute(args, exec) {
      const { png, capture } = await keepOcrWindowPng(args.window, exec.signal)
      const observation = await observeImage(png, capture.left, capture.top, exec.signal, { name: 'top-bar' })
      const action = observation.suggestedActions.find(a => a.target === 'search-field')
      const candidate = action ?? observation.clickables.find(c => c.kind === 'search-field')
      if (candidate === undefined) {
        const summary = observation.texts.slice(0, 12).map(line => line.text).join(' | ')
        throw new Error(`No search field candidate found in the top bar of "${args.window}". Recognized top-bar text: ${summary || '(none)'}. Use computer_observe_window if the search field is elsewhere.`)
      }
      const x = 'x' in candidate ? candidate.x : candidate.centerX
      const y = 'y' in candidate ? candidate.y : candidate.centerY
      const purpose = args.purpose ?? `search "${args.query}" in "${args.window}"`
      const message = await gated(exec, `search "${args.query}" in "${args.window}" for: ${purpose}`, args.window, async () => {
        await clickMouse(x, y, 'left', 1, exec.signal)
        if (args.selectExisting ?? true) await pressKey('a', { ctrl: true }, exec.signal)
        await typeText(args.query, exec.signal)
        if (args.pressEnter ?? true) await pressKey('enter', {}, exec.signal)
        return `searched "${args.query}" at (${x},${y})`
      })
      return {
        searched: true,
        x,
        y,
        query: args.query,
        observation,
        message: `${message}; verify results with computer_observe_window or computer_ocr_window.`,
      }
    },
    presentCall(args) {
      return { card: 'generic', title: `Search "${args.query}" in "${args.window}"` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_click_text',
    description:
      'Click visible text in a target window by OCR. This is the safest text-only way to click inside CEF/Chromium/custom-rendered apps when UI Automation cannot see internal controls. '
      + 'The purpose field should state why the click is needed, so failures stay tied to the task instead of becoming coordinate guessing.',
    parameters: {
      window: { type: 'string', required: true, description: 'Title substring, process name, PID, or class name of the window to OCR and click within.' },
      text: { type: 'string', required: true, description: 'Visible text to click.' },
      match: { type: 'string', enum: ['contains', 'exact'], description: 'contains (default) or exact line match.' },
      purpose: { type: 'string', required: true, description: 'Why this click helps the user task, e.g. "focus the NetEase search box before typing".' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          clicked: { type: 'boolean', required: true },
          x: { type: 'integer', required: true },
          y: { type: 'integer', required: true },
          matchedText: { type: 'string', required: true },
          message: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text' as const, text: value.message }],
    },
    async execute(args, exec) {
      const { png, capture } = await keepOcrWindowPng(args.window, exec.signal)
      const ocr = await ocrImage(png, capture.left, capture.top, exec.signal)
      const matches = locateOcrText(ocr, args.text, args.match ?? 'contains')
      if (matches.length === 0) {
        const summary = ocr.lines.slice(0, 20).map(line => line.text).join(' | ')
        throw new Error(`OCR text "${args.text}" was not found in window "${args.window}". Recognized text: ${summary || '(none)'}`)
      }
      const target = matches[0]
      const message = await gated(exec, `click OCR text "${target.text}" at (${target.centerX}, ${target.centerY}) for: ${args.purpose}`, args.window, () =>
        clickMouse(target.centerX, target.centerY, 'left', 1, exec.signal))
      return {
        clicked: true,
        x: target.centerX,
        y: target.centerY,
        matchedText: target.text,
        message: `${message}; clicked OCR text "${target.text}" for: ${args.purpose}`,
      }
    },
    presentCall(args) {
      return { card: 'generic', title: `Click text "${args.text}" in "${args.window}"` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_open_settings',
    description:
      'Open the Windows Settings app directly using the Windows ms-settings: URI. '
      + 'Use this for tasks that ask to open Settings, especially on text-only routes where Start-menu visual navigation is unreliable.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          message: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text' as const, text: value.message }],
    },
    async execute(_args, exec) {
      const message = await gated(exec, 'open Windows Settings', undefined, () => openSettings(exec.signal))
      return { message }
    },
    presentCall() {
      return { card: 'generic', title: 'Open Windows Settings' }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_click',
    description: 'Move the mouse to absolute screen coordinates and click. Use computer_list_windows or computer_screenshot to determine coordinates first. Pass focus to bring the target window to the foreground first.',
    parameters: {
      x: { type: 'number', required: true, description: 'Absolute screen X coordinate.' },
      y: { type: 'number', required: true, description: 'Absolute screen Y coordinate.' },
      button: { type: 'string', description: 'left (default), right, or middle.' },
      clicks: { type: 'number', description: 'Click count; 2 for double-click. Defaults to 1.' },
      focus: { type: 'string', description: 'Title substring or process name of the window to bring to the foreground before clicking.' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => [{ type: 'text', text: v }] },
    async execute(args, exec) {
      return gated(exec, `click ${args.button ?? 'left'} at (${args.x}, ${args.y})`, args.focus, () =>
        clickMouse(args.x, args.y, args.button ?? 'left', args.clicks ?? 1, exec.signal))
    },
    presentCall(args) {
      return { card: 'generic', title: `Click ${args.button ?? 'left'} at (${args.x}, ${args.y})` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_type_text',
    description: 'Type text into the control that currently has keyboard focus. If focus is passed, the window is activated without a mouse click, so an input box selected by the previous click stays selected. For search flows: click the search box, type text, then press Enter.',
    parameters: {
      text: { type: 'string', required: true },
      focus: { type: 'string', description: 'Title substring, process name, PID, or class name of the window to activate before typing. This does not click the window.' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => [{ type: 'text', text: v }] },
    async execute(args, exec) {
      return gated(exec, `type ${JSON.stringify(args.text.slice(0, 60))}${args.text.length > 60 ? '...' : ''}`, args.focus, () =>
        typeText(args.text, exec.signal), 'activate')
    },
    presentCall(args) {
      return { card: 'generic', title: `Type "${args.text.slice(0, 40)}${args.text.length > 40 ? '...' : ''}"` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_press_key',
    description: 'Press a single key or key combination, delivered to the control with keyboard focus. If focus is passed, the window is activated without a mouse click, preserving the selected input field.',
    parameters: {
      key: { type: 'string', required: true, description: 'Key name, e.g. enter, escape, tab, a, f5, up.' },
      ctrl: { type: 'boolean', description: 'Hold Ctrl.' },
      shift: { type: 'boolean', description: 'Hold Shift.' },
      alt: { type: 'boolean', description: 'Hold Alt.' },
      win: { type: 'boolean', description: 'Hold Windows key.' },
      focus: { type: 'string', description: 'Title substring, process name, PID, or class name of the window to activate before pressing. This does not click the window.' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => [{ type: 'text', text: v }] },
    async execute(args, exec) {
      return gated(exec, `press ${[args.ctrl && 'Ctrl', args.shift && 'Shift', args.alt && 'Alt', args.win && 'Win', args.key].filter(Boolean).join('+')}`, args.focus, () =>
        pressKey(args.key, { ctrl: args.ctrl, shift: args.shift, alt: args.alt, win: args.win }, exec.signal), 'activate')
    },
    presentCall(args) {
      return { card: 'generic', title: `Press ${args.key}` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_scroll',
    description: 'Scroll the mouse wheel at the current cursor position (optionally move to coordinates first).',
    parameters: {
      amount: { type: 'number', required: true, description: 'Wheel notches; positive scrolls up, negative scrolls down.' },
      x: { type: 'number', description: 'Move to this screen X before scrolling; omit to scroll in place.' },
      y: { type: 'number', description: 'Move to this screen Y before scrolling; omit to scroll in place.' },
      focus: { type: 'string', description: 'Title substring or process name of the window to bring to the foreground before scrolling.' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => [{ type: 'text', text: v }] },
    async execute(args, exec) {
      return gated(exec, `scroll ${args.amount}`, args.focus, () =>
        scrollWheel(args.amount, args.x, args.y, exec.signal))
    },
    presentCall(args) {
      return { card: 'generic', title: `Scroll ${args.amount > 0 ? 'up' : 'down'} ${Math.abs(args.amount)}` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_drag',
    description: 'Drag with the left mouse button from one screen point to another.',
    parameters: {
      fromX: { type: 'number', required: true },
      fromY: { type: 'number', required: true },
      toX: { type: 'number', required: true },
      toY: { type: 'number', required: true },
      focus: { type: 'string', description: 'Title substring or process name of the window to bring to the foreground before dragging.' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => [{ type: 'text', text: v }] },
    async execute(args, exec) {
      return gated(exec, `drag (${args.fromX}, ${args.fromY}) -> (${args.toX}, ${args.toY})`, args.focus, () =>
        dragMouse(args.fromX, args.fromY, args.toX, args.toY, exec.signal))
    },
    presentCall(args) {
      return { card: 'generic', title: `Drag to (${args.toX}, ${args.toY})` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'computer_move_mouse',
    description: 'Move the mouse cursor to absolute screen coordinates without clicking.',
    parameters: {
      x: { type: 'number', required: true },
      y: { type: 'number', required: true },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => [{ type: 'text', text: v }] },
    async execute(args, exec) {
      return gated(exec, `move mouse to (${args.x}, ${args.y})`, undefined, () => moveMouse(args.x, args.y, exec.signal))
    },
    presentCall(args) {
      return { card: 'generic', title: `Move mouse to (${args.x}, ${args.y})` }
    },
  }))

  ctx.logger.info('dsh-computer-use-win loaded: 18 computer_* tools registered')
}

interface ElementRow {
  name: string
  controlType: string
  className: string
  automationId: string
  pid: number
  process: string
  left: number
  top: number
  width: number
  height: number
  centerX: number
  centerY: number
  focused: boolean
  enabled: boolean
}

interface OcrLineRow {
  text: string
  left: number
  top: number
  width: number
  height: number
  centerX: number
  centerY: number
}

/** Format an image or file outcome into text[+ image] content blocks. */
function imageContent(outcome: {
  attachmentId: string
  mediaType: ImageMediaType
  bytes: number
  width: number
  height: number
  name?: string
} | {
  path: string
  left?: number
  top?: number
  width: number
  height: number
  bytes: number
}): ContentBlock[] {
  if ('path' in outcome) {
    return [{
      type: 'text',
      text: `Screenshot saved to ${outcome.path} (PNG ${outcome.width}x${outcome.height} px, ${outcome.bytes} bytes`
        + `${outcome.left !== undefined && outcome.top !== undefined ? `, origin=(${outcome.left},${outcome.top})` : ''}). `
        + 'The current model cannot view images directly from this path. Use computer_ocr_image on this file for text/coordinates, or use an image-capable route.',
    }]
  }
  return [
    { type: 'text', text: `Screenshot captured: image/png ${outcome.width}x${outcome.height} px, ${outcome.bytes} bytes` },
    { type: 'image', attachment: {
      attachmentId: AttachmentId(outcome.attachmentId),
      mediaType: outcome.mediaType,
      bytes: outcome.bytes,
      width: outcome.width,
      height: outcome.height,
      ...outcome.name === undefined ? {} : { name: outcome.name },
    } },
  ]
}

// Re-export so bundlers keep tree-shaking honest about what this entry uses.
export { captureScreen, captureWindow, listWindows, focusWindow, activateWindow, listElements, screenMetrics, locateOcrText, ocrImage, observeImage, clickMouse, typeText, pressKey, scrollWheel, moveMouse, dragMouse, pwshPath, runPowershell, keyComboFromNames, execFileAsync }
