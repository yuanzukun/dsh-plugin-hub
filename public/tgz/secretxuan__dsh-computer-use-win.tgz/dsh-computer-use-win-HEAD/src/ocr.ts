/**
 * OCR perception through Windows.Media.Ocr.
 * @module dsh-computer-use-win/src/ocr
 */

import { runPowershell } from './powershell.ts'

export interface OcrWordInfo {
  text: string
  left: number
  top: number
  width: number
  height: number
  centerX: number
  centerY: number
}

export interface OcrLineInfo {
  text: string
  words: OcrWordInfo[]
  left: number
  top: number
  width: number
  height: number
  centerX: number
  centerY: number
}

export interface OcrResult {
  path: string
  originX: number
  originY: number
  width: number
  height: number
  lines: OcrLineInfo[]
  text: string
}

function psText(value: string): string {
  return value.replaceAll("'", "''")
}

/** Run OCR on a PNG/JPEG/BMP file and return text boxes in absolute pixels. */
export async function ocrImage(path: string, originX = 0, originY = 0, signal?: AbortSignal): Promise<OcrResult> {
  const script = `
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$ErrorActionPreference = 'Stop'
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Media.Ocr, ContentType=WindowsRuntime]

function AwaitOp($op, [Type]$resultType) {
  $method = [System.WindowsRuntimeSystemExtensions].GetMethods() |
    Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and $_.GetParameters().Count -eq 1 } |
    Select-Object -First 1
  $task = $method.MakeGenericMethod($resultType).Invoke($null, @($op))
  $task.Wait()
  return $task.Result
}

$path = '${psText(path)}'
$originX = ${Math.round(originX)}
$originY = ${Math.round(originY)}
$file = AwaitOp ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
$stream = AwaitOp ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = AwaitOp ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = AwaitOp ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { throw "Windows OCR is unavailable for the current user language profile" }
$ocr = AwaitOp ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
$items = New-Object System.Collections.ArrayList
foreach ($line in $ocr.Lines) {
  $words = New-Object System.Collections.ArrayList
  $minX = [double]::PositiveInfinity; $minY = [double]::PositiveInfinity
  $maxX = 0.0; $maxY = 0.0
  foreach ($word in $line.Words) {
    $r = $word.BoundingRect
    $x = [int][Math]::Round($originX + $r.X)
    $y = [int][Math]::Round($originY + $r.Y)
    $w = [int][Math]::Round($r.Width)
    $h = [int][Math]::Round($r.Height)
    [void]$words.Add([ordered]@{
      text = $word.Text
      left = $x
      top = $y
      width = $w
      height = $h
      centerX = [int][Math]::Round($x + $w / 2)
      centerY = [int][Math]::Round($y + $h / 2)
    })
    $minX = [Math]::Min($minX, $x); $minY = [Math]::Min($minY, $y)
    $maxX = [Math]::Max($maxX, $x + $w); $maxY = [Math]::Max($maxY, $y + $h)
  }
  if ($words.Count -eq 0) { continue }
  [void]$items.Add([ordered]@{
    text = $line.Text
    left = [int][Math]::Round($minX)
    top = [int][Math]::Round($minY)
    width = [int][Math]::Round($maxX - $minX)
    height = [int][Math]::Round($maxY - $minY)
    centerX = [int][Math]::Round(($minX + $maxX) / 2)
    centerY = [int][Math]::Round(($minY + $maxY) / 2)
    words = @($words)
  })
}
$stream.Dispose()
([ordered]@{
  path = $path
  originX = $originX
  originY = $originY
  width = [int]$bitmap.PixelWidth
  height = [int]$bitmap.PixelHeight
  text = $ocr.Text
  lines = @($items)
}) | ConvertTo-Json -Depth 12 -Compress
`.trim()
  const out = await runPowershell(script, signal, 60_000)
  return JSON.parse(out) as OcrResult
}

/** Locate OCR lines matching text. */
export function locateOcrText(result: OcrResult, text: string, match: 'contains' | 'exact' = 'contains'): OcrLineInfo[] {
  const needle = text.toLocaleLowerCase()
  return result.lines.filter((line) => {
    const haystack = line.text.toLocaleLowerCase()
    return match === 'exact' ? haystack === needle : haystack.includes(needle)
  })
}
