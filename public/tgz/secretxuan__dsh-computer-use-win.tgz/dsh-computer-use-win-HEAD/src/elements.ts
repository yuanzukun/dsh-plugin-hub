/**
 * Accessibility-tree perception via UI Automation.
 * @module dsh-computer-use-win/src/elements
 */

import { runPowershell } from './powershell.ts'

export interface ElementInfo {
  name: string
  controlType: string
  className: string
  automationId: string
  pid: number
  process: string
  left: number
  top: number
  width: number
  height: number
  /** Control center in absolute screen pixels — the exact point to click. */
  centerX: number
  centerY: number
  focused: boolean
  enabled: boolean
}

function psText(value: string): string {
  return value.replaceAll("'", "''")
}

/**
 * Enumerate UI Automation elements as text rows. One PowerShell run covers
 * both modes: when `name` is given, search the whole desktop subtree for
 * elements whose Name/ClassName/AutomationId contains it; otherwise dump the
 * first `maxDepth` levels under the window matching `window` (or the focused
 * window when neither is given).
 */
export async function listElements(opts: {
  window?: string
  name?: string
  maxDepth?: number
  signal?: AbortSignal
}): Promise<ElementInfo[]> {
  const depth = Math.max(1, Math.min(8, opts.maxDepth ?? 4))
  const script = `
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$ErrorActionPreference = 'Stop'
$root = [System.Windows.Automation.AutomationElement]::RootElement

function Emit($el, $focused) {
  $c = $el.Current
  $r = $c.BoundingRectangle
  if ([double]::IsInfinity($r.X) -or [double]::IsInfinity($r.Y) -or [double]::IsInfinity($r.Width) -or [double]::IsInfinity($r.Height)) { return $null }
  $rw = [Math]::Round($r.Width); $rh = [Math]::Round($r.Height)
  $rx = [Math]::Round($r.X); $ry = [Math]::Round($r.Y)
  if ($rw -le 0 -or $rh -le 0) { return $null }
  $proc = ""
  try { $proc = (Get-Process -Id $c.ProcessId -ErrorAction Stop).ProcessName } catch {}
  $parts = @(
    $c.ControlType.ProgrammaticName,
    $c.Name,
    $c.ClassName,
    $c.AutomationId,
    [string]$c.ProcessId,
    $proc,
    ($rx.ToString() + "," + $ry.ToString() + " " + $rw.ToString() + "x" + $rh.ToString()),
    [string][Math]::Round($rx + $rw/2),
    [string][Math]::Round($ry + $rh/2),
    [string]$focused,
    [string]$c.IsEnabled
  )
  Write-Output ($parts -join [string][char]9)
}
`.trim()

  // Name-search mode: walk the desktop subtree, prune by name substrings.
  if (opts.name !== undefined) {
    const windowMatch = opts.window
    const body = `
${script}
$needle = '${psText(opts.name)}'
$searchRoot = $root
${windowMatch !== undefined ? `
$wm = '${psText(windowMatch)}'
$wins = $root.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)
$candidates = New-Object System.Collections.ArrayList
foreach ($w in $wins) {
  $c = $w.Current
  $proc = ""
  try { $proc = (Get-Process -Id $c.ProcessId -ErrorAction Stop).ProcessName } catch {}
  if ($candidates.Count -lt 8) { [void]$candidates.Add(("pid=$($c.ProcessId) [$proc] {$($c.ClassName)} $($c.Name)")) }
  if ($c.Name -like "*$wm*" -or $c.ClassName -like "*$wm*" -or ([string]$c.ProcessId) -eq $wm -or $proc -like "*$wm*") { $searchRoot = $w; break }
}
if ($searchRoot -eq $root) { throw "no top-level window matches '$wm'. Try one of: $($candidates -join '; ')" }` : ''}
$results = New-Object System.Collections.ArrayList
function Walk($el, $depth) {
  if ($depth -gt ${depth * 3}) { return }
  $c = $el.Current
  $hit = $false
  try {
    if ($c.Name -like "*$needle*" -or $c.ClassName -like "*$needle*" -or $c.AutomationId -like "*$needle*") { $hit = $true }
  } catch {}
  if ($hit) {
    $focused = $false
    try { $focused = ($el -eq [System.Windows.Automation.AutomationElement]::FocusedElement) } catch {}
    $row = Emit $el $focused
    if ($null -ne $row) { [void]$results.Add($row) }
  }
  $kids = $el.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)
  foreach ($k in $kids) { Walk $k ($depth + 1) }
}
Walk $searchRoot 0
$results | ForEach-Object { $_ }
`.trim()
    return parseRows(await runPowershell(body, opts.signal, 45_000))
  }

  // Window-dump mode: resolve the target top-level window, then BFS to depth.
  const windowMatch = opts.window
  const body = `
${script}
$target = $null
${windowMatch !== undefined ? `
$wm = '${psText(windowMatch)}'
$wins = $root.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)
$candidates = New-Object System.Collections.ArrayList
foreach ($w in $wins) {
  $c = $w.Current
  $proc = ""
  try { $proc = (Get-Process -Id $c.ProcessId -ErrorAction Stop).ProcessName } catch {}
  if ($candidates.Count -lt 8) { [void]$candidates.Add(("pid=$($c.ProcessId) [$proc] {$($c.ClassName)} $($c.Name)")) }
  if ($c.Name -like "*$wm*" -or $c.ClassName -like "*$wm*" -or ([string]$c.ProcessId) -eq $wm -or $proc -like "*$wm*") { $target = $w; break }
}
if ($null -eq $target) { throw "no top-level window matches '$wm'. Try one of: $($candidates -join '; ')" }` : `
$target = [System.Windows.Automation.AutomationElement]::FocusedElement
# Walk up to the top-level window under the desktop root.
$walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
while ($true) {
  $parent = $null
  try { $parent = $walker.GetParent($target) } catch {}
  if ($null -eq $parent -or $parent -eq [System.Windows.Automation.AutomationElement]::RootElement) { break }
  $target = $parent
}`}
$rows = New-Object System.Collections.ArrayList
$queue = New-Object System.Collections.Queue
$queue.Enqueue(@($target, 0))
while ($queue.Count -gt 0) {
  $pair = $queue.Dequeue()
  $el = $pair[0]; $d = $pair[1]
  $focused = $false
  try { $focused = ($el -eq [System.Windows.Automation.AutomationElement]::FocusedElement) } catch {}
  $row = Emit $el $focused
  if ($null -ne $row) { [void]$rows.Add($row) }
  if ($d -lt ${depth}) {
    $kids = $el.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)
    foreach ($k in $kids) { $queue.Enqueue(@($k, $d + 1)) }
  }
}
$rows | ForEach-Object { $_ }
`.trim()
  return parseRows(await runPowershell(body, opts.signal, 45_000))
}

function parseRows(out: string): ElementInfo[] {
  return out.split(/\r?\n/).filter(line => line.includes('\t')).map((line) => {
    const [controlType, name, className, automationId, pid, process, rect, centerX, centerY, focused, enabled] = line.split('\t')
    const [leftTop, size] = rect.split(' ')
    const [left, top] = leftTop.split(',').map(Number)
    const [width, height] = size.split('x').map(Number)
    return {
      name,
      controlType: controlType.replace(/^ControlType\./, ''),
      className,
      automationId,
      pid: Number(pid),
      process,
      left, top, width, height,
      centerX: Number(centerX),
      centerY: Number(centerY),
      focused: focused === 'True',
      enabled: enabled === 'True',
    }
  })
}

/** Report the physical screen size (post-DPI-fix ground truth for coordinates). */
export async function screenMetrics(signal?: AbortSignal): Promise<{ left: number; top: number; width: number; height: number; dpiScale: number }> {
  const script = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class DpiMetrics {
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int idx);
  [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
  [DllImport("gdi32.dll")] public static extern int GetDeviceCaps(IntPtr h, int idx);
  [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
}
"@
$left = [DpiMetrics]::GetSystemMetrics(76); $top = [DpiMetrics]::GetSystemMetrics(77)
$w = [DpiMetrics]::GetSystemMetrics(78); $h = [DpiMetrics]::GetSystemMetrics(79)
$dc = [DpiMetrics]::GetDC([IntPtr]::Zero)
$dpi = [DpiMetrics]::GetDeviceCaps($dc, 88)
[void][DpiMetrics]::ReleaseDC([IntPtr]::Zero, $dc)
Write-Output "$left $top $w $h $dpi"
`.trim()
  const out = await runPowershell(script, signal)
  const [left, top, width, height, dpi] = out.split(/\s+/).map(Number)
  return { left, top, width, height, dpiScale: Math.round((dpi / 96) * 100) / 100 }
}
