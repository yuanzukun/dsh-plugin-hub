/**
 * Screen and window capture via System.Drawing CopyFromScreen.
 * @module dsh-computer-use-win/src/screenshot
 */

import { runPowershell } from './powershell.ts'

/**
 * Capture one monitor to a PNG file.
 * @returns the captured dimensions.
 */
export async function captureScreen(pngPath: string, monitor: number, signal?: AbortSignal): Promise<{ left: number; top: number; width: number; height: number }> {
  const script = `
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
$b = [System.Windows.Forms.Screen]::AllScreens
if (${monitor} -ge $b.Length) { throw "monitor index ${monitor} out of range (have $($b.Length))" }
$s = $b[${monitor}]
$w = [Math]::Abs($s.Bounds.Right - $s.Bounds.Left)
$h = [Math]::Abs($s.Bounds.Bottom - $s.Bounds.Top)
$bmp = New-Object System.Drawing.Bitmap($w, $h)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($s.Bounds.Left, $s.Bounds.Top, 0, 0, $bmp.Size)
$bmp.Save('${psEscape(pngPath)}', [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Output "$($s.Bounds.Left) $($s.Bounds.Top) $w $h"
`.trim()
  const out = await runPowershell(script, signal, 60_000)
  const [left, top, width, height] = out.split(/\s+/).map(Number)
  return { left, top, width, height }
}

/**
 * Capture the first visible top-level window whose title or process name
 * matches `match` (case-insensitive substring) to a PNG file.
 * @returns the captured dimensions.
 */
export async function captureWindow(pngPath: string, match: string, signal?: AbortSignal): Promise<{ left: number; top: number; width: number; height: number }> {
  const script = `
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class Win32Enum {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lp);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll", EntryPoint="GetWindowTextW", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder sb, int max);
  [DllImport("user32.dll", EntryPoint="GetClassNameW", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, System.Text.StringBuilder sb, int max);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
  public struct RECT { public int Left, Top, Right, Bottom; }
}
"@
$target = $null
$candidates = New-Object System.Collections.ArrayList
$cb = {
  param($hWnd, $lp)
  if (-not [Win32Enum]::IsWindowVisible($hWnd)) { return $true }
  $sb = New-Object System.Text.StringBuilder 512
  [void][Win32Enum]::GetWindowText($hWnd, $sb, 512)
  $title = $sb.ToString()
  if ($title.Length -eq 0) { return $true }
  $r0 = New-Object Win32Enum+RECT
  [void][Win32Enum]::GetWindowRect($hWnd, [ref]$r0)
  if (($r0.Right - $r0.Left) -le 10 -or ($r0.Bottom - $r0.Top) -le 10) { return $true }
  $pid2 = 0
  [void][Win32Enum]::GetWindowThreadProcessId($hWnd, [ref]$pid2)
  $proc = ""
  try { $proc = (Get-Process -Id $pid2 -ErrorAction Stop).ProcessName } catch {}
  $csb = New-Object System.Text.StringBuilder 256
  [void][Win32Enum]::GetClassName($hWnd, $csb, 256)
  $className = $csb.ToString()
  if ($candidates.Count -lt 8) { [void]$candidates.Add(("pid=$pid2 [$proc] {$className} $title")) }
  if ($title -like "*${psWildcard(match)}*" -or $proc -like "*${psWildcard(match)}*" -or ([string]$pid2) -eq '${psEscape(match)}' -or $className -like "*${psWildcard(match)}*") {
    $script:target = $hWnd
    return $false
  }
  return $true
}
[Win32Enum]::EnumWindows($cb, [IntPtr]::Zero) | Out-Null
if ($null -eq $script:target) { throw "no visible window matches '${psEscape(match)}'. Try one of: $($candidates -join '; ')" }
if ([Win32Enum]::IsIconic($script:target)) { [void][Win32Enum]::ShowWindow($script:target, 9) }
[void][Win32Enum]::SetForegroundWindow($script:target)
Start-Sleep -Milliseconds 250
if ([Win32Enum]::GetForegroundWindow() -ne $script:target) { throw "window '${psEscape(match)}' could not be brought to the foreground; screenshot/OCR would capture an occluding window instead" }
$r = New-Object Win32Enum+RECT
[void][Win32Enum]::GetWindowRect($script:target, [ref]$r)
$w = $r.Right - $r.Left; $h = $r.Bottom - $r.Top
if ($w -le 0 -or $h -le 0) { throw "window '${psEscape(match)}' has empty bounds $($r.Left),$($r.Top) $($w)x$($h)" }
$bmp = New-Object System.Drawing.Bitmap($w, $h)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($r.Left, $r.Top, 0, 0, $bmp.Size)
$bmp.Save('${psEscape(pngPath)}', [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Output "$($r.Left) $($r.Top) $w $h"
`.trim()
  const out = await runPowershell(script, signal, 60_000)
  const [left, top, width, height] = out.split(/\s+/).map(Number)
  return { left, top, width, height }
}

/** Escape a path for embedding inside a single-quoted PowerShell string. */
function psEscape(value: string): string {
  return value.replaceAll("'", "''").replaceAll('\\', '/')
}

/** Escape user text into a PowerShell -like wildcard pattern (literal match). */
function psWildcard(value: string): string {
  return value.replaceAll('[', '[[]').replaceAll(']', '[]]').replaceAll('*', '[*]').replaceAll('?', '[?]').replaceAll("'", "''")
}
