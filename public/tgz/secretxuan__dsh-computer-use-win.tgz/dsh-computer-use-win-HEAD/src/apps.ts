/**
 * Small Windows shell launches for common system surfaces.
 * @module dsh-computer-use-win/src/apps
 */

import { runPowershell } from './powershell.ts'

/** Open the Windows Settings app through its documented URI scheme. */
export async function openSettings(signal?: AbortSignal): Promise<string> {
  const script = `
Start-Process 'ms-settings:'
Start-Sleep -Milliseconds 500
Write-Output "opened Windows Settings"
`.trim()
  return runPowershell(script, signal, 30_000)
}
