/**
 * PowerShell invocation helper: one place that knows how to run a script
 * block on Windows with bounded output and abort support.
 * @module dsh-computer-use-win/src/powershell
 */

import { execFile } from 'node:child_process'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

/** Resolve the PowerShell executable (pwsh preferred, Windows PowerShell fallback). */
export function pwshPath(): string {
  return 'powershell.exe'
}

/**
 * Prologue every plugin script runs before its own code: declare the process
 * DPI-aware so Windows stops virtualizing coordinates. On a 1920x1080 @125%
 * display a DPI-unaware process sees a fake 1536x864 desktop — screenshots
 * come out 1536x864, window rects and SetCursorPos targets get scaled — while
 * UI Automation reports physical 1920x1080. Mixing the two spaces makes every
 * coordinate the model derives from UIA land ~25% off when replayed through
 * these tools. Physical pixels everywhere, always.
 */
const DPI_AWARE_PROLOGUE = `
Add-Type @"
using System.Runtime.InteropServices;
public class DpiAwareness {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
"@
[void][DpiAwareness]::SetProcessDPIAware()
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
`.trim()

/**
 * Run a PowerShell script and return its stdout as a UTF-8 string. Non-zero
 * exit or stderr output containing an error record rejects. Stdout decoding
 * is forced to UTF-8 to match the [Console]::OutputEncoding set in the
 * prologue — the system ANSI codepage would otherwise mojibake every
 * non-ASCII window title or control name.
 */
export async function runPowershell(script: string, signal?: AbortSignal, timeoutMs = 30_000): Promise<string> {
  try {
    const { stdout } = await execFileAsync(pwshPath(), [
      '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', `${DPI_AWARE_PROLOGUE}\n${script}`,
    ], { signal, timeout: timeoutMs, windowsHide: true, maxBuffer: 16 * 1024 * 1024, encoding: 'utf8' })
    return stdout.trim()
  } catch (cause) {
    throw new Error(`PowerShell action failed: ${shortPowerShellMessage(cause)}`)
  }
}

function shortPowerShellMessage(cause: unknown): string {
  if (typeof cause !== 'object' || cause === null) return String(cause)
  const record = cause as { message?: string; stderr?: string; stdout?: string; code?: unknown; signal?: unknown; killed?: unknown }
  const raw = firstUsefulLine(record.stderr) ?? firstUsefulLine(record.stdout) ?? firstUsefulLine(record.message) ?? 'unknown error'
  const timeout = record.killed === true || record.signal != null ? ' timed out or was aborted' : ''
  const code = record.code === undefined ? '' : ` exit=${String(record.code)}`
  return `${raw}${code}${timeout}`.slice(0, 500)
}

function firstUsefulLine(text: string | undefined): string | undefined {
  const line = text?.split(/\r?\n/)
    .map(part => part.trim())
    .find(part => part.length > 0 && !part.startsWith('At line:') && !part.startsWith('+ '))
  if (line === undefined) return undefined
  return line.replace(/\s+/g, ' ')
}
