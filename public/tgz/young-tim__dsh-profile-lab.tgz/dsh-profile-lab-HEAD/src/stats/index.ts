import type { Cell, Summary } from "../types.js";
export const quantile = (xs: number[], p: number): number => {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.max(0, Math.ceil(p * s.length) - 1))]!;
};
export const median = (xs: number[]) => quantile(xs, 0.5);
export const wilson = (success: number, total: number): [number, number] => {
  if (!total) return [0, 0];
  const z = 1.96,
    p = success / total,
    d = 1 + (z * z) / total,
    c = (p + (z * z) / (2 * total)) / d,
    m = (z * Math.sqrt((p * (1 - p) + (z * z) / (4 * total)) / total)) / d;
  return [c - m, c + m];
};
export const totalTokens = (c: Cell) =>
  c.input_tokens + c.output_tokens + c.reasoning_tokens;
export const summarize = (
  cells: Cell[],
  variant: string,
  caseName?: string,
): Summary => {
  const a = cells.filter(
    (c) => c.variant === variant && (!caseName || c.case === caseName),
  );
  const pass = a.filter((c) => c.status === "pass").length,
    error = a.filter(
      (c) => c.status === "error" || c.status === "cancelled",
    ).length,
    fail = a.filter((c) => c.status === "fail").length;
  const n = (f: (c: Cell) => number) => a.map(f);
  return {
    variant,
    ...(caseName ? { case: caseName } : {}),
    total: a.length,
    pass,
    fail,
    error,
    pass_rate: a.length ? pass / a.length : 0,
    error_rate: a.length ? error / a.length : 0,
    flaky: pass > 0 && pass < a.length,
    ...(a.length < 5
      ? { repetition_label: "insufficient-repetitions" as const }
      : {}),
    median_duration_ms: median(n((c) => c.duration_ms)),
    p95_duration_ms: quantile(
      n((c) => c.duration_ms),
      0.95,
    ),
    median_tokens: median(n(totalTokens)),
    p95_tokens: quantile(n(totalTokens), 0.95),
    median_steps: median(n((c) => c.steps)),
    p95_steps: quantile(
      n((c) => c.steps),
      0.95,
    ),
    wilson: wilson(pass, a.length),
  };
};
export const pct = (current: number, baseline: number) =>
  baseline === 0
    ? current === 0
      ? 0
      : Infinity
    : ((current - baseline) / baseline) * 100;
export const pareto = <T>(
  items: T[],
  quality: (x: T) => number,
  cost: (x: T) => number,
  latency: (x: T) => number,
) =>
  items.filter(
    (x) =>
      !items.some(
        (y) =>
          y !== x &&
          quality(y) >= quality(x) &&
          cost(y) <= cost(x) &&
          latency(y) <= latency(x) &&
          (quality(y) > quality(x) ||
            cost(y) < cost(x) ||
            latency(y) < latency(x)),
      ),
  );
