import { describe, expect, it } from "vitest";
import { mkdtemp, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { gate } from "../src/gate/index.js";
import {
  parseJsonl,
  projectCell,
  readSession,
} from "../src/dsh-adapter/index.js";
import { redact, report } from "../src/report/index.js";
import { sanitize } from "../src/security/index.js";
import type { Cell, Experiment, Summary } from "../src/types.js";
const summary = (pass_rate: number, error_rate = 0): Summary => ({
  variant: "x",
  total: 5,
  pass_rate,
  error_rate,
  flaky: false,
  median_duration_ms: 1,
  p95_duration_ms: 1,
  median_tokens: 1,
  p95_tokens: 1,
  median_steps: 1,
  p95_steps: 1,
  wilson: [0, 1],
});
const cell = (variant: string): Cell => ({
  id: variant,
  variant,
  case: "x",
  repetition: 1,
  status: "pass",
  attempts: 1,
  duration_ms: 1,
  steps: 1,
  tool_calls: 0,
  tool_errors: 0,
  input_tokens: 1,
  output_tokens: 2,
  reasoning_tokens: 0,
  cache_tokens: 0,
  final_output_hash: "x",
  evidence: "x",
});
describe("decision services", () => {
  it("projects tolerant session logs", async () => {
    const text =
      '{"type":"tool/call"}\ninvalid\n{"type":"assistant/final","text":"<ok>"}\n{"type":"turn/end","status":"ok","duration_ms":3,"steps":2,"usage":{"input":4,"output":5}}\n';
    const d = await mkdtemp(path.join(tmpdir(), "event-"));
    const f = path.join(d, "s.jsonl");
    await writeFile(f, text);
    expect(parseJsonl(text)).toHaveLength(3);
    expect(await readSession(f)).toHaveLength(3);
    const x = projectCell(
      { id: "id", variant: "v", case: "c", repetition: 1 },
      parseJsonl(text),
      "e",
    );
    expect(x).toMatchObject({
      status: "pass",
      duration_ms: 3,
      steps: 2,
      input_tokens: 4,
      output_tokens: 5,
      tool_calls: 1,
    });
  });
  it("returns all policy reasons", () => {
    expect(
      gate(summary(0.9), summary(0.2, 0.2), {
        min_candidate_pass_rate: 0.8,
        max_pass_rate_drop_pp: 5,
        max_error_rate: 0.1,
      }),
    ).toHaveLength(3);
    expect(gate(summary(1), summary(1), {})).toEqual([]);
  });
  it("writes deterministic escaped reports", async () => {
    const d = await mkdtemp(path.join(tmpdir(), "report-"));
    const e = {
      name: "<unsafe>",
      variants: [{ id: "base" }, { id: "candidate" }],
    } as unknown as Experiment;
    await report(d, e, [cell("base"), cell("candidate")]);
    const a = await Promise.all(
      ["report.json", "report.md", "report.html"].map((f) =>
        readFile(path.join(d, f), "utf8"),
      ),
    );
    await report(d, e, [cell("base"), cell("candidate")]);
    expect(await readFile(path.join(d, "report.html"), "utf8")).toBe(a[2]);
    expect(a[2]).toContain("&lt;unsafe&gt;");
    expect(a[1]).toContain("## Reproduce");
    expect(a[2]).toContain("Per-case comparisons");
    expect(JSON.parse(a[0]).compositions).toEqual([
      { variant: "base", profile: "unknown", patch: "unknown", layers: [] },
      {
        variant: "candidate",
        profile: "unknown",
        patch: "unknown",
        layers: [],
      },
    ]);
  });
});

describe("explicit pricing decisions", () => {
  it("redacts token and authorization values", () => {
    expect(
      redact("ds_abcdefghijklmnopqrstuvwxyz Authorization: secret-value"),
    ).toBe("[REDACTED] Authorization: [REDACTED]");
    expect(
      sanitize({ apiKey: "plain-value", nested: { token: "value" } }),
    ).toEqual({
      apiKey: "[REDACTED]",
      nested: { token: "[REDACTED]" },
    });
  });
  it("does not fabricate cost or Pareto members without pricing", async () => {
    const d = await mkdtemp(path.join(tmpdir(), "report-price-"));
    const e = {
      name: "pricing",
      baseline: "base",
      variants: [{ id: "base" }, { id: "candidate" }],
    } as unknown as Experiment;
    const result = await report(d, e, [cell("base"), cell("candidate")]);
    expect(result.pareto).toEqual([]);
    expect(result.per_case_comparisons).toHaveLength(1);
    expect(result.variants.every((x) => x.cost === "unavailable")).toBe(true);
  });
  it("computes explicit local pricing and Pareto members", async () => {
    const d = await mkdtemp(path.join(tmpdir(), "report-price-"));
    const e = {
      name: "pricing",
      baseline: "base",
      variants: [{ id: "base" }, { id: "candidate" }],
      pricing: {
        base: { input_per_million: 1_000_000, output_per_million: 0 },
        candidate: { input_per_million: 1_000_000, output_per_million: 0 },
      },
    } as unknown as Experiment;
    const result = await report(d, e, [cell("base"), cell("candidate")]);
    expect(result.variants.map((x) => x.cost)).toEqual([1, 1]);
    expect(result.pareto).toEqual(["base", "candidate"]);
  });
  it("reports zero-token deltas, failures, partial pricing and manifest hashes", async () => {
    const d = await mkdtemp(path.join(tmpdir(), "report-boundaries-"));
    const e = {
      schema_version: 1,
      name: "boundaries",
      baseline: "base",
      cases_dir: "cases",
      workspace_template: "repo",
      repetitions: 1,
      run: {
        concurrency: 1,
        timeout_ms: 1,
        max_runs: 2,
        max_total_tokens: 10,
        env_allowlist: ["TOKEN"],
      },
      variants: [
        { id: "base", profile: "headless", patch: "base.yml" },
        { id: "candidate", profile: "headless", patch: "candidate.yml" },
      ],
      pricing: {
        base: { input_per_million: 1, output_per_million: 1 },
      },
    } satisfies Experiment;
    await writeFile(
      path.join(d, "manifest.json"),
      JSON.stringify({
        input_hash: "input",
        workspace_hash: "workspace",
        patch_hashes: { base: "hash", ignored: 1 },
        case_hashes: { x: "hash", ignored: false },
      }),
    );
    await writeFile(
      path.join(d, "run-state.json"),
      JSON.stringify({ version: 1, incomplete: true, reason: "budget" }),
    );
    const base = { ...cell("base"), input_tokens: 0, output_tokens: 0 };
    const candidate = {
      ...cell("candidate"),
      status: "fail" as const,
      assertion_failures: ["output_contains"],
    };
    const result = await report(d, e, [base, candidate]);
    expect(result).toMatchObject({
      incomplete: true,
      comparisons: [{ median_token_delta_pct: null }],
      per_case_comparisons: [{ median_token_delta_pct: null }],
      manifest: { patch_hashes: { base: "hash" } },
    });
    expect(
      result.variants.find((row) => row.variant === "candidate")?.cost,
    ).toBe("unavailable");
    expect(await readFile(path.join(d, "report.md"), "utf8")).toContain(
      "output_contains",
    );

    candidate.input_tokens = 0;
    candidate.output_tokens = 0;
    const zero = await report(d, e, [base, candidate]);
    expect(zero.comparisons[0]?.median_token_delta_pct).toBe(0);
  });
});
describe("decision services", () => {
  it("projects tolerant session logs", async () => {
    const text =
      '{"type":"tool/call"}\ninvalid\n{"type":"assistant/final","text":"<ok>"}\n{"type":"turn/end","status":"ok","duration_ms":3,"steps":2,"usage":{"input":4,"output":5}}\n';
    const d = await mkdtemp(path.join(tmpdir(), "event-"));
    const f = path.join(d, "s.jsonl");
    await writeFile(f, text);
    expect(parseJsonl(text)).toHaveLength(3);
    expect(await readSession(f)).toHaveLength(3);
    const x = projectCell(
      { id: "id", variant: "v", case: "c", repetition: 1 },
      parseJsonl(text),
      "e",
    );
    expect(x).toMatchObject({
      status: "pass",
      duration_ms: 3,
      steps: 2,
      input_tokens: 4,
      output_tokens: 5,
      tool_calls: 1,
    });
    for (const status of ["cancelled", "fail", "weird"])
      expect(
        projectCell(
          { id: status, variant: "v", case: "c", repetition: 1 },
          [{ type: "turn/end", status }],
          "e",
        ).status,
      ).toBe(
        status === "cancelled"
          ? "cancelled"
          : status === "fail"
            ? "fail"
            : "error",
      );
  });
  it("returns all policy reasons", () => {
    expect(
      gate(summary(0.9), summary(0.2, 0.2), {
        min_candidate_pass_rate: 0.8,
        max_pass_rate_drop_pp: 5,
        max_error_rate: 0.1,
      }),
    ).toHaveLength(3);
    expect(gate(summary(1), summary(1), {})).toEqual([]);
  });
  it("writes deterministic escaped reports", async () => {
    const d = await mkdtemp(path.join(tmpdir(), "report-"));
    const e = {
      name: "<unsafe>",
      variants: [{ id: "base" }, { id: "candidate" }],
    } as unknown as Experiment;
    await report(d, e, [cell("base"), cell("candidate")]);
    const a = await Promise.all(
      ["report.json", "report.md", "report.html"].map((f) =>
        readFile(path.join(d, f), "utf8"),
      ),
    );
    await report(d, e, [cell("base"), cell("candidate")]);
    expect(await readFile(path.join(d, "report.html"), "utf8")).toBe(a[2]);
    expect(a[2]).toContain("&lt;unsafe&gt;");
  });
});
