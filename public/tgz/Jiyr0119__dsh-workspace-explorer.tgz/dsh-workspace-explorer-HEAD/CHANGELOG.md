# Changelog

## [v0.10.0] - 2026-10-12

### 新功能 Feature

- **插件自保护(崩溃隔离)** — 实测发现 DSH web boot 要求所有插件条目激活成功,任一 client 插件在 `apply` 抛错会让**整个前端启动失败**;因此客户端 `apply` 现整体 try/catch(异常只降级本插件并记录 `console.error`),四个挂载点(抽屉/面板/输入桥/设置页)均包渲染错误边界,插件内部异常不再可能拖垮 DSH / **Plugin self-protection (crash isolation)** — we verified that DSH's web boot requires every plugin entry to activate, so any client plugin throwing in `apply` takes down the entire frontend. The client `apply` is now fully wrapped in try/catch (failures degrade only this plugin and log `console.error`), and all four mount points (drawer / panel / input bridge / settings) are wrapped in render error boundaries — an internal exception can no longer bring DSH down.
- **打开文件 → 侧栏原生预览** — 行右键菜单新增「在侧栏预览」:按 DSH `fileAddressFor` 约定构造 `dsh-resource://file/session/<sessionId>/<path>` 地址并调用 `sidebarRight.openResource`,在右侧栏打开原生文件预览(与 chat 的 openFile / reference 的 openReference 落点一致);无活动会话或旧版 DSH 无 `sidebarRight` 服务时隐藏该项 / **Open file → native sidebar preview** — the row context menu gains "Preview in sidebar": it builds the `dsh-resource://file/session/<sessionId>/<path>` address per DSH's `fileAddressFor` convention and calls `sidebarRight.openResource`, opening the native file preview in the right sidebar (the same endpoint as chat's `openFile` / reference's `openReference`). The item is hidden when there is no active session or the host lacks the `sidebarRight` service.
- **复制路径 / 在文件管理器中显示** — 文件与目录行新增右键菜单:「复制路径」写入剪贴板并给出瞬时提示;「在访达/资源管理器中显示」经新路由 `/dsh-we/api/native` 调 `@deepseek-ai/dsh-native-command` 的 `revealNativePath` 在宿主桌面打开;客户端启动时探测 `status`,无桌面环境(如 headless Linux)自动隐藏 reveal 项 / **Copy path / Reveal in file manager** — file and directory rows now have a context menu: "Copy path" writes the absolute path to the clipboard with a transient toast; "Reveal in Finder/Explorer" goes through the new `/dsh-we/api/native` route into `@deepseek-ai/dsh-native-command`'s `revealNativePath` on the Host desktop. The client probes `status` on mount and hides the reveal item on desktop-less hosts (e.g. headless Linux).
- **宿主侧内容搜索** — 新增 `/dsh-we/api/search` 路由与 `searchContent`(大小写不敏感逐行子串匹配):面板搜索框现在同时做**文件名匹配**与**内容匹配**,内容命中行展示「文件名 :行号 + 命中高亮片段」,点击即插入引用;噪声目录永不进入、二进制与 >1MB 文件跳过,受「扫描文件数 / 命中数 / 单文件命中行数」三重上限保护 / **Host-side content search** — new `/dsh-we/api/search` route backed by `searchContent` (case-insensitive per-line substring matching). The panel search box now runs **file-name matching** and **content matching** side by side; content hits render as "file :line + highlighted snippet" rows and a click inserts the reference. Noise dirs are never walked, binary and >1MB files are skipped, and the scan is bounded by file-count / hit-count / per-file-hit caps.
- **面板设置持久化** — Host 入口导出 `Config`(`.volatile()` schema),面板五项设置(隐藏噪声目录 / 显示文件大小 / 路径样式 / 预览行数 / 面板宽度)经 DSH 0.1.7+ settings 域写入当前 Profile(`cordis.patch.yml`),重启后依然生效;客户端经 `configForms` 服务绑定 `workspace-explorer` 命名空间,与设置页共享同一份值 / **Persisted panel settings** — the host entry now exports a `Config` (`.volatile()` schema); all five panel settings (hide noise dirs / show file size / path style / preview lines / panel width) persist into the current profile through the DSH 0.1.7+ settings domain (`cordis.patch.yml`) and survive restarts. The client binds the `workspace-explorer` namespace via the `configForms` service, so the plugin settings page and the Host share one source of truth.
- **旧版自动回退** — 客户端经 `ctx.inject(['configForms'])` 接入;旧版 DSH / 零构建动态版没有该服务时自动退回内存级配置(与 0.9.0 行为一致),核心功能不受影响 / **Graceful fallback on older hosts** — the client opts in via `ctx.inject(['configForms'])`; on older DSH versions / the zero-build dynamic bundle where that service does not exist, it silently falls back to in-memory config (same behavior as 0.9.0) and core features are unaffected.

## [v0.9.0] - 2026-09-30

### 兼容 DSH 0.2.0 Compatibility with DSH 0.2.0

- **目录选择迁移** — 添加工作区改为 `ctx.get('uiWorkspace').pickDirectory()`(DSH 0.2.0 把 `workspaces.pickDirectory` 移到了 workspace 导航服务);仍保留 `workspaces.pickDirectory` 作为 0.1.5 回退 / **Directory picker migration** — "Add workspace" now calls `ctx.get('uiWorkspace').pickDirectory()` (DSH 0.2.0 moved `workspaces.pickDirectory` onto the workspace navigation service); the 0.1.5 `workspaces.pickDirectory` path is kept as a fallback.
- **当前会话读取** — 0.2.0 的 `SessionListState` 已无 `current`,改用 `uiSession.adapter.current` 的 `key` 取 sessionId,并同时订阅 `sessions.list` 与 `adapter.current` 更新输入桥 cwd;`@` 菜单与面板根目录因此不再需要面板先打开 / **Current session lookup** — 0.2.0's `SessionListState` no longer has `current`; the sessionId now comes from `uiSession.adapter.current`'s `key`, and both `sessions.list` and `adapter.current` are subscribed to refresh the input-bridge cwd, so the `@` menu and panel root no longer require the panel to be open first.
- **服务延迟解析** — `workspaces` / `uiWorkspace` 在 `apply()` 时可能尚未创建,改为调用时按需 `ctx.get` 并在就绪时打印诊断行 / **Lazy service resolution** — `workspaces` / `uiWorkspace` may not exist yet when `apply()` runs; they are now resolved via `ctx.get` at call time, with a diagnostic line logged once cordis reports them ready.
- **输入桥 fallback 修复** — 0.1.5 起 `inputFace.actions` 已不存在,回退桥改用 `inputFace.setDraft`,拖拽与 `@` 选择在 dock 未挂载时也能插入 / **Input bridge fallback fix** — `inputFace.actions` has not existed since 0.1.5; the fallback bridge now uses `inputFace.setDraft`, so drag-and-drop and `@` selection still insert when the dock is not mounted.
- **依赖与构建对齐 0.2.0** — `@deepseek-ai/*` devDependencies 升到 `0.2.0-rc.2`、`@deepseek-ai/cordis` 升到 `~4.0.4`;`dsh.client.inject` 改为 0.2.0 的 client 包集合(新增 ui-workspace / ui-session / api-workspace-controller,移除 dsh-client-runtime);tsdown platform seed 同步;`dsh.plugin.json` 新增 `engines.dsh: ">=0.2.0"` / **Dependencies and build aligned to 0.2.0** — `@deepseek-ai/*` devDependencies moved to `0.2.0-rc.2` and `@deepseek-ai/cordis` to `~4.0.4`; `dsh.client.inject` now lists the 0.2.0 client packages (adds ui-workspace / ui-session / api-workspace-controller, drops dsh-client-runtime); the tsdown platform seed matches; `dsh.plugin.json` declares `engines.dsh: ">=0.2.0"`.
- **会话工作区降级** — 0.2.0 没有 `recentWorkspaceId`,面板根目录按「会话 cwd → 第一个工作区」顺序取值 / **Session workspace fallback** — 0.2.0 has no `recentWorkspaceId`; the panel root falls back from the session cwd to the first workspace.

## [v0.6.3] - 2026-08-25

### 改进 Improvement

- **Star 提示精简** — 设置页 Star 好评区域去掉开发者名称,改用 CSS Module 类名替代内联样式,更简洁优雅 / **Streamlined Star prompt** — removed developer name from settings star section, switched from inline styles to CSS Module classes for a cleaner look.

## [v0.6.2] - 2026-08-25

### 新功能 Feature

- **Star 好评提示** — README 和插件设置页新增 GitHub Star 好评入口;徽章栏新增 Star 数量徽章;设置页顶部展示 Star 链接 / **Star prompt** — README and plugin settings page now show a GitHub Star call-to-action; badges include a Star count badge; settings page header displays Star link.

## [v0.6.1] - 2026-08-21

### 修复 Fix

- **`@` 触发源自动发现工作区** — `@` 文件菜单不再依赖面板打开;通过 sessions 服务自动获取当前会话的 cwd 作为工作区根目录 / **`@` trigger auto-discovers workspace** — the `@` file menu no longer requires the panel to be open; the current session's cwd is automatically used as the workspace root via the sessions service.
- **输入桥 fallback** — 当 `DockBridge` 组件未挂载时(会话未激活或 dock 槽位未渲染),通过 `conversation.input` 服务自动设置输入桥,确保拖拽和 `@` 选择能正常插入文本 / **Input bridge fallback** — when the `DockBridge` component is not mounted, the input bridge is automatically set via the `conversation.input` service, ensuring drag-and-drop and `@` selection can insert text.
- **文件引用格式统一** — `@` 菜单选择、拖拽文件/文件夹、面板点击、多选批量插入全部统一为 `@` 前缀 + `refStyle` 设置(相对/绝对路径) + 目录追加 `/`;拖拽文件夹从目录树格式改为 `@dir/` 引用 / **Unified file reference format** — `@` menu selection, drag-and-drop, panel click, and multi-select batch insert all use the same format: `@` prefix + `refStyle` setting (relative/absolute) + trailing `/` for directories; dragging a folder now inserts `@dir/` instead of a directory tree.

## [v0.6.0] - 2026-08-21

### 里程碑 M2 — 写路径 Write path

- **Split view 预览面板** — 预览从底部弹窗改为左侧滑出面板(340px),文件树被推向右侧,弹窗宽度自动撑宽并带平滑过渡动画 / **Split view preview panel** — preview moves from bottom popup to a left-side sliding panel (340px), the file tree is pushed right, and the popup width animates smoothly.
- **文件图标可点击** — 文件行新增👁预览按钮(在文件图标前),点击打开左侧预览面板;当前正在预览的文件行显示蓝色圆点指示器 / **Clickable preview icon** — a 👁 preview button appears before the file icon in each file row; clicking opens the left preview panel; the active file shows a blue dot indicator.
- **文件编辑模式** — 预览面板支持编辑:点击「编辑」按钮进入 textarea 编辑态,支持保存/放弃/取消;保存时检测文件外部修改(对比文件大小) / **File editing mode** — the preview panel supports editing: click "Edit" to enter textarea mode with save/discard/cancel; save detects external file changes (size comparison).
- **Host 写入路由** — 新增 `/dsh-we/api/write` 路由,支持文件写入与 change detection / **Host write route** — new `/dsh-we/api/write` route with file writing and change detection.
- **按钮样式统一** — 所有操作按钮(插入引用/插入内容/保存/放弃/编辑)使用统一样式 / **Unified button styles** — all action buttons (insert reference/insert content/save/discard/edit) use consistent styling.

### 开发体验 Developer experience

- **本地调试文档** — 新增 `docs/local-debugging.md`,完整记录 dev profile 搭建、symlink 链接、快捷脚本使用 / **Local debugging guide** — new `docs/local-debugging.md` documenting dev profile setup, symlink linking, and helper scripts.
- **dev profile 快捷脚本** — `~/.dsh/profiles/dev/add-plugin.sh` 和 `rm-plugin.sh` 支持一键添加/移除本地插件 / **Dev profile helper scripts** — one-click add/remove local plugins.

### 修复 Fix

- **按钮高度统一** — 所有 `dshwe-prevbtn` 按钮统一为 height:28px、padding:0 10px / **Unified button height** — all `dshwe-prevbtn` buttons now use height:28px, padding:0 10px.
- **分页按钮圆角统一** — `dshwe-pager-btn` border-radius 从 7px 改为 8px,与其他按钮一致 / **Unified pager border-radius** — `dshwe-pager-btn` border-radius changed from 7px to 8px.

## [v0.5.2] - 2026-08-19

### 单元测试接入 Unit tests

- 引入 **vitest**:新增 `test/format.test.ts`(12 例)与 `test/host.test.ts`(29 例)共 41 例,覆盖路径安全校验、目录列表、分页读取、二进制嗅探、目录树生成与格式化工具;host 内部函数(`resolveRel`/`listDir`/`readLinesPage`/`pageScanLarge`/`sniffBinary`/`buildTreeNodes`/`cfg`)标注 `@internal` 导出供测试断言,不构成公开 API / **vitest** is now wired in: 41 tests across `test/format.test.ts` (12) and `test/host.test.ts` (29) covering path-safety checks, listing, paging, binary sniffing, tree building and formatting; host internals are exported as `@internal` (not public API) for test assertions.
- `npm test` / `npm run test:watch` 脚本与 `vitest.config.ts` 就位 / `test` and `test:watch` scripts plus `vitest.config.ts` in place.

### Host 安全与性能 Security & performance

- **路径安全校验统一化**:新增 `resolveRel(root, rel)` 作为「工作区根目录 + 相对路径」唯一寻址入口,拒绝空根与含 `''/./..` 危险段的 rel,`/dsh-we/api/list|peek|tree` 全部走该校验,杜绝任意路径读取 / **Unified path safety**: new `resolveRel(root, rel)` is the single root+rel resolver rejecting empty roots and dangerous `''/./..` segments; all three `/dsh-we/api/list|peek|tree` routes route through it, closing arbitrary path reads.
- **大文件翻页提速**:新增行起始字节缓存(`lineIndexCache`,最多保留 64 个文件、缓存上限 200 万行),翻页复用已扫描结果而非每页从头重扫 O(n);文件完全扫描后可返回精确行数 / **Faster large-file paging**: a line-start byte-offset cache (`lineIndexCache`, ≤64 files, ≤2M lines) reuses prior scans instead of re-scanning O(n) per page; exact line counts once a file is fully scanned.
- peek 请求体从 `path` 改为 `root` + `rel`(兼容旧 `path` 字段)/ peek now takes `root` + `rel` (legacy `path` still accepted).

### Client

- 格式化工具抽为纯函数模块 `src/client/format.ts`(`fmtSize`/`basename`/`extOf`/`formatTreeBlock`),面板复用并在浏览器端单测 / formatting helpers extracted to pure `src/client/format.ts`, reused by the panel and unit-tested in Node.
- 原生包与动态粘贴版同步重建(`lib/client.js` 等)/ native bundle and paste-in client rebuilt in sync.

## [v0.5.1] - 2026-08-17

### 入口升级 Entry pill

- **会话头部入口改为「功能名称 + 图标」胶囊**,与 DSH 原生 **Session log 下载按钮**同款样式(描边圆角胶囊、名称在左、文件夹图标在右,高亮主题色):会话头部入口从纯图标按钮升级为「工作区文件 / Workspace Files」胶囊,打开面板时胶囊呈激活态 / The session-header entry is now a **feature-name + icon capsule** matching the native **Session log** download button (bordered pill, label left, folder icon right, business-primary active state): the entry reads "工作区文件 / Workspace Files" and lights up while the panel is open.
- 原生包(`src/client/index.tsx` + `lib/client.js`)与动态粘贴版(`dynamic/client.js`)同步更新;新增 `drawer.label` 词典键(zh/en) / Both the native bundle and the dynamic paste-in client were updated in sync; a new `drawer.label` locale key (zh/en) drives the button text.
- 演示页与 GIF 重录:`demo/index.html` 重构为与当前产品一致的模拟(会话头部胶囊入口 + Tab 栏 + 多选操作条 + 目录拖拽目录树 + 分页预览 + 设置页),`demo/preview.gif` 重新录制展示新入口与 M1 特性 / The interactive demo and GIF were rebuilt: `demo/index.html` now mirrors the current product (header pill entry, tabs, selection bar, folder-drag tree text, paginated preview, settings), and `demo/preview.gif` was re-recorded to show the new entry and the M1 read-path features.

## [v0.5.0] - 2026-08-17

### 里程碑 M1 — 读路径体验 Read-path UX

- **多选批量插入** — Shift 点击扩展选择区间、⌘/Ctrl 点击切换选择,选中后底部操作条一键插入:文件 → `[file: 路径]` 引用,目录 → 目录树文本 / **Multi-select & batch insert** — Shift extends the selection range, ⌘/Ctrl toggles; a bottom action bar batch-inserts files as references and folders as compact tree listings.
- **目录拖拽** — 目录行现在也可拖拽:落点处异步生成**限层数(默认 3 层)的紧凑目录树文本**(`name/` + `├──` 树形,噪声目录过滤、200 条上限),拖入输入框内同样拦截替换为树文本 / **Folder drag & drop** — folders are draggable; on drop the client fetches a depth-limited compact tree listing and inserts it, including drops inside the composer.
- **分页全量预览** — 预览不再截断在 60 行 / 200KB:上一页 / 下一页按行翻页(每页行数跟随「预览行数」设置),显示总行数与当前页;「插入内容」对小文件(≤32KB)改为整文件取回 / **Paginated full preview** — prev/next paging through the whole file (page size follows the "preview lines" setting) replaces the 60-line / 200 KB cap; "insert content" fetches the entire ≤32 KB file.

### Host

- `/dsh-we/api/peek` 支持 `offset` / `limit` / `whole`:小文件(≤4MB)整读、行数精确;大文件块扫描定位行区间(行数未知);二进制前 8KB 嗅探 / peek now takes offset/limit/whole; ≤4 MB files read whole for exact line counts, larger files page-scanned in chunks, binary sniffed on the first 8 KB.
- 新增 `/dsh-we/api/tree`:递归收集目录树节点(深度 ≤6、条目预算 ≤200 默认,噪声目录过滤)/ New `/dsh-we/api/tree` route: recursive tree nodes with depth/entry budgets.
- 动态版同步:新增 `ws-tree.tree` RPC;`ws-tree.peek` 支持 offset/limit/whole(动态备用路径无 offset 读取,>8MB 文件走 tooLarge 优雅降级)/ Dynamic host synced: new `ws-tree.tree` RPC; peek supports paging (the paste-in backup path pages within 8 MB, degrades gracefully beyond).

### 修复 Fix

- **构建顺序修复**:`npm run build` 改为 `tsdown && tsc -p tsconfig.build.json`——此前 tsc 先输出 `lib/types` 再被 tsdown 的 clean 清掉,导致包里 `exports.types` 悬空(TS 用户装包后类型引用报错)/ **Build-order fix**: build now runs `tsdown && tsc -p tsconfig.build.json` — previously tsc emitted `lib/types` and tsdown's clean then wiped it, leaving dangling `exports.types` for TS consumers.
- 动态 host:`fs.readText` 返回 string,去掉多余的 TextDecoder 解码(此前抛 "The list argument must be …")/ Dynamic host no longer TextDecoder-decodes `fs.readText` strings (it previously threw).
- 全链路公开链接统一为小写规范域名 `jiyr0119.github.io`(与 GitHub Pages canonical `html_url` 一致)/ All public links normalized to the lowercase canonical `jiyr0119.github.io`.
- **交互式预览已隐藏**:README 移除在线预览链接与 Pages 徽章,Pages 工作流改为仅手动触发;npm homepage 改指 GitHub 仓库 / **Interactive preview hidden**: the online preview link and the Pages badge were removed from the READMEs, the Pages workflow now runs manually only, and the npm homepage points at the GitHub repo.

## [v0.4.0] - 2026-08-17

### 交互重构 Interaction overhaul (popup + file-tree entry)

- 面板从「details 列抽屉」改为**浮动弹窗**:由会话头部(与 session log 同排)的**文件树图标**打开,带淡入/缩放展开动画 / Panel is now a **floating popup** opened by a **file-tree icon** in the session header (beside the session log), with a fade/scale-in animation.
- **弹窗位置实时测量**:位于会话头部底部与输入框(composer)顶部之间,绝不遮挡输入框;窗口缩放、header/composer 布局变化时自动跟随 / **Live-measured position** between the session header and the composer; follows window & layout changes automatically.
- 移除 `sidebar.footer.action` 侧边栏按钮(以空占位注册顶掉旧版原生包残留按钮),唯一入口为会话头部图标 / The sidebar footer button was removed (placeholder registration supersedes the legacy native bundle's button); the session-header icon is the single entry.
- 不再依赖壳的 `layout.openDetails/closeDetails` 与 details 列,避免抢占壳的「工具调用详情」功能 / No longer drives the shell's details column (`layout.openDetails/closeDetails`), so the shell's tool-details panel stays untouched.

### 修复 Fix

- 保留 v0.3.2 的 `webServer.register` 逐条注册修复与 v0.3.1 的 `cordis.patch.yml` 引号修复(原生安装路径) / Kept the v0.3.2 per-route `webServer.register` fix and the v0.3.1 quoted `cordis.patch.yml` fix (native install path).
- `DockBridge` 对 `useInput` 空值守卫,避免输入桥崩溃 / `DockBridge` guards a missing `useInput` prop.
- 弹窗动画尊重 `prefers-reduced-motion` / Popup animation respects `prefers-reduced-motion`.

## [v0.3.2] - 2026-08-17

### 修复 Fix

- **`webServer.register` 传数组导致路由全部静默失效**:真实 `register()` 只接受单个 route,数组被塞进前缀表(key=undefined),`/dsh-we/api/list|peek|config` 全部未注册 → 浏览器 `fetch().json()` 报 `Unexpected end of JSON input`。改为逐条注册(用真实 WebServer 服务验证:三路由全部注册 + list/config/peek 正常)/ `register()` was called with an array, which silently no-oped (routes never registered → empty responses). Now registered one by one and verified against the real WebServer service.

### 交互 Interaction

- 面板改为**右上角 dock 式侧边面板**(对标 dsh-web-ui 右侧面板):贴顶吸边、左边框 + 左阴影、左下圆角;左边缘 6px 拖把可拖宽(280–640px)/ Panel is now a **top-right docked side panel** (dsh-web-ui style): flush to the top-right corner, left edge + shadow, drag handle to resize (280–640px).

## [v0.3.1] - 2026-08-17

### 修复 Fix

- **`cordis.patch.yml` YAML 语法错误**:`name` 的作用域包名未加引号(`@` 不能作为 YAML 裸标量起始字符),导致 `dsh web` 启动解析补丁时报 `bad indentation of a mapping entry` 崩溃。已加引号并对齐官方格式 / Unquoted `@`-scoped package name in `cordis.patch.yml` broke `dsh web` boot; value is now quoted to match the official bundle patches.

## [v0.3.0] - 2026-08-17

### 交互改造 Interaction overhaul (dsh-better-sidebar style)

- 面板**顶部 Tab 栏**(文件 / 设置),点击顶部切换页面 / Top **tab bar** (Files / Settings) at the top of the panel.
- **设置页**逐项开关/下拉,实时生效:隐藏噪声目录、显示文件大小、引用格式(相对/绝对)、预览行数、面板宽度 / **Settings page** with live toggles & selects: hide noise dirs, show sizes, reference format, preview lines, panel width.
- 设置同步进 DSH 设置壳(`设置 → 工作区文件`)/ Settings also mirrored into the DSH Settings shell (Settings → Workspace Explorer).
- Host 新增 `ws-tree.config` RPC(动态版)与 `/dsh-we/api/config` 路由(原生版):噪声目录 / 预览行数可调 / New `ws-tree.config` RPC (dynamic) and `/dsh-we/api/config` route (native): noise dirs / preview lines tunable.
- **原生包同步新交互**:`src/client/index.tsx` 重写为顶部 Tab + 设置页,`lib/index.js` + `lib/client.js` 重建(56KB)/ Native bundle rebuilt with the new interaction.

## [v0.2.0] - 2026-08-17

### 原生化 Native package

- 重构为**原生单包**(仿 dsh-better-sidebar 模板):Host `src/index.ts`(webServer JSON 路由 `/dsh-we/api/list` + `/peek`)+ 浏览器 bundle `src/client/index.tsx`(`dsh.plugin.json` client.main,`__ModuleLoader__` 格式)
- 构建产物:`lib/index.js`(ESM host)+ `lib/client.js`(CJS browser,42KB)+ `lib/types`
- 动态版保留至 `dynamic/host.js` + `dynamic/client.js`(零构建粘贴路径)
- `dsh plugin --profile web add @jiyr0119/dsh-workspace-explorer@latest` 后浏览器面板可挂载(真实 DSH 挂载验证待完成)

## [v0.1.1] - 2026-08-17

### 新增 Added

- GitHub Pages 交互式预览 `demo/index.html`(面板打开时聊天区自动让位)/ Interactive GitHub Pages preview (`demo/index.html`; the chat area yields to the panel when opened).
- 演示 GIF `demo/preview.gif`,内嵌于两份 README / Demo GIF embedded in both READMEs.
- npm 可发布源码包 `@jiyr0119/dsh-workspace-explorer` / npm-publishable source package.
- 原生 DSH 包路线文档 `docs/native-package.md` / Native-package roadmap doc.
- 市场截图素材 `assets/screenshots/` / Storefront screenshot assets.
- 文件名搜索过滤(平铺结果 + 匹配计数)/ Filename search & filter (flat results + match count).
- 文件预览(前 60 行)与小文件内联插入(≤32KB)/ Inline preview (first 60 lines) + content insertion for small files (≤ 32 KB).
- 国际化:zh/en 词典,面板跟随 DSH 界面语言 / i18n: zh/en dictionaries via the DSH locale service, follows the DSH UI language.
- 预览/插入图标 hover 小手光标;面板顶部锚定限高,不遮挡底部输入框 / Pointer cursor on preview/insert icons; panel top-anchored with bounded height so the composer stays visible.
- 演示页支持中英切换 / Demo page language toggle (zh/en).
- `dsh.bundle` 可安装契约(`cordis.patch.yml` + `index.js`)/ `dsh.bundle` installability contract.

### 变更 Changed

- README 改为英文默认 + 中英切换(`README.md` / `README.zh.md`)/ READMEs restructured: English default with a language switch.
- 仓库迁移至 `~/workspaceforme` 根目录 / Repo moved to `~/workspaceforme`.

## [v0.1.0] - 2025-08-14

首个正式版本 / First official release。

### 功能 Features

- 右侧浮层面板展示工作区目录文件树,顶部可切换/添加工作区
  Right-side panel with the workspace file tree; switch or add workspaces from the top bar.
- 目录懒加载展开,自动隐藏 `node_modules` / `.git` / `dist` 等噪声目录
  Lazy-loading directories; noise dirs (`node_modules`, `.git`, `dist`, …) hidden automatically.
- 按扩展名着色的实心文件类型图标(TS / JS / Python / JSON / Markdown / 图片 / 配置 / 脚本等)
  Filled, color-coded file-type icons per extension (TS / JS / Python / JSON / Markdown / image / config / shell, …).
- 点击或拖拽文件,把 `[file: 路径]` 引用插入聊天输入框(拖入输入框内走原生光标插入)
  Click or drag a file to insert a `[file: path]` reference into the composer (native caret insert when dropped inside the textarea).
- 侧边栏底部「文件」开关按钮
  Sidebar footer "Files" toggle button.
- 视觉对齐 DSH 原生 UI:全部使用 `--dsw-alias-*` 设计 token,浅/深色自适应,24px 圆角 + lv3 阴影 + l3 头部分隔线
  Visuals aligned with DSH native UI: built on `--dsw-alias-*` design tokens, light/dark adaptive, 24px radius + lv3 shadow + l3 header rule.

### 修复与边界 Fixes & Edge Cases

- 根目录列表(`rel=''`)不再误报 `bad-rel`
  Root listings (`rel=''`) no longer trip the `bad-rel` validation.
- RPC 参数全部为纯字符串,规避 `host.call` 对非 JSON 值的拒绝
  RPC args are plain strings, avoiding `host.call` rejection of non-JSON values.
- 拖放:输入框内原生插入(光标精确),其他位置追加;拖拽提示尊重 `prefers-reduced-motion`
  Drag & drop: native caret insert inside the composer, append elsewhere; the drag hint respects `prefers-reduced-motion`.
