/**
 * Durable-preferences resolution: defaults, malformed input, and clamping.
 */
import { describe, expect, it } from 'vitest'
import {
  CURRENT_NOTIFICATION_MODES, DEFAULT_NOTIFICATION_SETTINGS, DEFAULT_SOUND, resolveNotificationSettings,
  type CurrentNotificationMode,
} from '../src/settings.ts'

describe('resolveNotificationSettings', () => {
  it('returns the defaults for an absent section', () => {
    const resolved = resolveNotificationSettings(undefined)
    expect(resolved).toEqual(DEFAULT_NOTIFICATION_SETTINGS)
  })

  it('keeps sound enabled and browser notifications disabled by default', () => {
    const resolved = resolveNotificationSettings(undefined)
    expect(resolved.soundEnabled).toBe(true)
    expect(resolved.browserEnabled).toBe(false)
    expect(resolved.currentNotificationMode).toBe('hidden')
  })

  it('defaults to main-session-only notifications after its subagents', () => {
    const resolved = resolveNotificationSettings(undefined)
    expect(resolved.notificationMode).toBe('main-wait')
  })

  it('resolves the current-session mode, migrating the legacy notifyCurrent boolean', () => {
    const modeOf = (raw: unknown): CurrentNotificationMode => resolveNotificationSettings(raw).currentNotificationMode
    for (const mode of CURRENT_NOTIFICATION_MODES) expect(modeOf({ currentNotificationMode: mode })).toBe(mode)
    expect(modeOf({ currentNotificationMode: 'invalid' })).toBe('hidden')
    expect(modeOf({ notifyCurrent: true })).toBe('always')
    expect(modeOf({ notifyCurrent: false })).toBe('hidden')
  })

  it('honors an explicit notification mode', () => {
    expect(resolveNotificationSettings({ notificationMode: 'all' }).notificationMode).toBe('all')
    expect(resolveNotificationSettings({ notificationMode: 'main' }).notificationMode).toBe('main')
    expect(resolveNotificationSettings({ notificationMode: 'nonsense' }).notificationMode).toBe('main-wait')
  })

  it('migrates the legacy mainOnly/waitForSubagents booleans onto modes', () => {
    expect(resolveNotificationSettings({ mainOnly: false }).notificationMode).toBe('all')
    expect(resolveNotificationSettings({ mainOnly: true, waitForSubagents: false }).notificationMode).toBe('main')
    expect(resolveNotificationSettings({ mainOnly: true, waitForSubagents: true }).notificationMode).toBe('main-wait')
  })

  it('assigns the default four sounds to the four kinds', () => {
    const resolved = resolveNotificationSettings(undefined)
    expect(resolved.types.completed.sound).toBe('chime')
    expect(resolved.types.failed.sound).toBe('fault')
    expect(resolved.types.question.sound).toBe('pop')
    expect(resolved.types.permission.sound).toBe('alert')
  })

  it('merges a partial section over the defaults', () => {
    const resolved = resolveNotificationSettings({
      volume: 0.3,
      types: { failed: { enabled: false, sound: 'alert' } },
    })
    expect(resolved.volume).toBe(0.3)
    expect(resolved.browserEnabled).toBe(false)
    expect(resolved.soundEnabled).toBe(true)
    expect(resolved.types.failed).toEqual({ enabled: false, sound: 'alert' })
    expect(resolved.types.completed).toEqual(DEFAULT_NOTIFICATION_SETTINGS.types.completed)
  })

  it('clamps the volume into [0, 1]', () => {
    expect(resolveNotificationSettings({ volume: 1.5 }).volume).toBe(1)
    expect(resolveNotificationSettings({ volume: -0.5 }).volume).toBe(0)
    expect(resolveNotificationSettings({ volume: Number.NaN }).volume).toBe(DEFAULT_NOTIFICATION_SETTINGS.volume)
  })

  it('drops malformed values back to the defaults', () => {
    const resolved = resolveNotificationSettings({
      browserEnabled: 'yes',
      soundEnabled: 1,
      volume: 'loud',
      types: 'broken',
      unknown: 'ignored',
    })
    expect(resolved).toEqual(DEFAULT_NOTIFICATION_SETTINGS)
  })

  it('rejects unknown sound ids per kind', () => {
    const resolved = resolveNotificationSettings({
      types: { question: { enabled: true, sound: 'megaphone' } },
    })
    expect(resolved.types.question.sound).toBe(DEFAULT_SOUND.question)
  })

  it('ignores array-shaped sections', () => {
    expect(resolveNotificationSettings([1, 2, 3])).toEqual(DEFAULT_NOTIFICATION_SETTINGS)
  })
})
