/**
 * Notification plugin, browser half: the Notifications settings section and
 * the event-driven notification engine. The engine watches the sessions list
 * for running and pending-interaction edges, classifies finished runs as
 * completed or failed from the session's conversation snapshot, and hands
 * events to a dispatcher that plays the kind's sound and shows a system
 * notification when browser notifications are enabled.
 *
 * The settings section follows the official row pattern (ui-theme): the
 * store declared at register is owned by the slot renderer, which hands its
 * bound actions to the inject factory; the apply world never creates a
 * second instance. The scope is the source of truth for reads (dispatcher,
 * engine) and writes; the bound actions mirror scope snapshots into the
 * renderer's store.
 *
 * Preferences are browser-local (localStorage, `createLocalSettingsScope`):
 * the plugin owns its namespace end to end and needs no host-side settings
 * exposure, so it runs against a pristine harness without touching
 * `packages/host/apiproxy` or any other host package.
 */
import type { BoundActions } from '@deepseek-ai/dsh-client-ui-slots'
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type { SessionId } from '@deepseek-ai/dsh-client-connection/client'
// Type-only: the SlotRegistry service merge (ctx.slots) — dsh 0.1.3 merged it
// through ui-renderer's client face (dsh-client-runtime was dissolved).
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
// Type-only: the settings surface's slot-name augmentation, which types the
// `settings.section` seat this plugin registers (a side effect of importing
// the face is the ctx.settingsScope Context merge, which the plugin no
// longer uses — preferences are browser-local).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: the sessions service (ctx.sessions) and the chat/pending
// surfaces the engine reads (ctx.uiConversation / ctx.uiSession).
import type {} from '@deepseek-ai/dsh-api-session-controller/client'
import type { SessionSnapshot } from '@deepseek-ai/dsh-api-session-controller/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {
  SessionStatusSnapshot,
} from '@deepseek-ai/dsh-client-ui-session/client'
// Type-only: the workspace navigation merge (ctx.uiWorkspace). Injected
// optionally so a composition without it keeps the plugin running.
import type {} from '@deepseek-ai/dsh-client-ui-workspace/client'
import type { CurrentNotificationMode, NotificationMode, NotificationSettings, NotificationType, SoundId } from '../settings.ts'
import { DEFAULT_NOTIFICATION_SETTINGS } from '../settings.ts'
import { createLocalSettingsScope } from './local-settings.ts'
import { createTabCoordinator } from './tab-coordinator.ts'
import { SoundPlayer } from './sounds.ts'
import {
  browserPermission, requestBrowserPermission, showBrowserNotification, NOTIFICATION_TAG_PREFIX,
} from './browser-notify.ts'
import { MAX_CUSTOM_AUDIO_BYTES, readCustomSound, readFileAsDataUrl, writeCustomSound } from './custom-audio.ts'
import {
  NotificationDispatcher, NotificationEngine, sessionDetailOf,
  type ChatSnapshotLike, type PendingFacts,
} from './notification-service.ts'
import { createNotificationsStore } from './settings-store.ts'
import {
  NotificationsSection, type NotificationsSectionInjected,
} from './NotificationsSection.tsx'
import { en, zh, type NotificationsKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The Notifications settings section's copy. */
    'notifications': NotificationsKey
  }
}

declare module '@deepseek-ai/dsh-api-session-controller/client' {
  interface SessionReferenceSourceMap {
    /** Reference held while one notification classification reads a session. */
    sessionNotification: unknown
  }
}

/** Dictionary namespace owned by this plugin. */
const NS = 'notifications'

/** How long a finished run waits for trailing wire frames before classification. */
const SETTLE_MS = 250

/** Required services: the slot registry, dictionaries, the session list, the
 *  alpha chat view (uiConversation), and the pending-interaction map
 *  (uiSession). */
export const inject = ['slots', 'locale', 'sessions', 'uiConversation', 'uiSession', 'uiWorkspace']

/**
 * Client plugin body: bind the browser-local preferences scope, register the
 * Notifications section, and watch the sessions list for notification events.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-session-notification: dictionaries')

  const scope = createLocalSettingsScope()
  const store = createNotificationsStore()
  let bound: BoundActions<typeof store> | undefined

  const currentSettings = (): NotificationSettings => {
    const snapshot = scope.getSnapshot()
    return snapshot.status === 'ready' && snapshot.value !== undefined
      ? snapshot.value
      : DEFAULT_NOTIFICATION_SETTINGS
  }

  // Scope → renderer store mirror. The renderer binds its own store instance
  // and hands it to the inject factory; until the section mounts, adopt is a
  // no-op (the inject factory performs the first sync on mount). The engine's
  // main-only filter is synced from the same subscription below, where the
  // engine already exists.
  ctx.effect(() => scope.subscribe(() => { bound?.adopt(scope.getSnapshot()) }), 'dsh-session-notification: scope adoption')

  const player = new SoundPlayer(() => currentSettings().volume)
  // Release the shared AudioContext (and any preview still holding it) when
  // the plugin unloads; a live context keeps a system audio stream open.
  ctx.effect(() => () => player.dispose(), 'dsh-session-notification: sound player')

  // Cross-tab arbiter: one open tab wins each event, so N tabs do not ring N
  // times; a visible tab takes the event ahead of a background one.
  const coordinator = createTabCoordinator()
  ctx.effect(() => () => coordinator.dispose(), 'dsh-session-notification: tab coordinator')
  const t = ctx.locale.bind(NS)
  const translate = (key: string): string => t(key as NotificationsKey)
  /** Play the effective sound: a custom audio when one is supplied, else the built-in. */
  const playEffective = (sound: SoundId, customUrl?: string): void => {
    if (sound === 'custom' && customUrl !== undefined) player.playCustom(customUrl)
    else player.play(sound)
  }

  const dispatcher = new NotificationDispatcher({
    settings: currentSettings,
    t: translate,
    playSound: (sound, customUrl) => { playEffective(sound, customUrl) },
    customSoundOf: (kind) => readCustomSound(kind),
    showBrowser: (title, body, tag, sessionId) => showBrowserNotification(title, body, tag, () => {
      try {
        ctx.uiWorkspace.openSession(sessionId)
      } catch (error) {
        console.warn('[dsh-session-notification] could not open the notification session', sessionId, error)
      }
    }),
    // dsh 0.1.7 dropped the list's `current` selection; the main view owns
    // selection through its reference source, so a session is "the one being
    // read" while the main-view reference retains it.
    isCurrent: (id) => (ctx.sessions.retainInfo(id).getSnapshot().retainedBy.mainView ?? 0) > 0,
    isHidden: () => (typeof document === 'undefined' ? false : document.visibilityState === 'hidden'),
    // `visibilityState` stays visible while another app is in front and this
    // window is still on screen; focus is the signal for that case.
    hasFocus: () => typeof document === 'undefined' || document.hasFocus(),
  })

  const engine = new NotificationEngine({
    detailOf: (id: SessionId) => {
      const binding = ctx.sessions.binding(id)
      if (binding === undefined) return undefined
      // The session snapshot carries no chat view: the conversation nodes
      // live in the uiConversation chat target, materialized only for opened
      // sessions. Absent it, classification still has lastAgentError.
      // (The chat target key and the session snapshot shape are surfaced
      // through their owning packages' type merges; the structural casts keep
      // this plugin independent of those augmentation orders.) A generation
      // that ends between the running edge and this read makes the binding
      // calls throw in 0.1.7, so a failed read degrades to "no detail".
      try {
        const conversation = ctx.uiConversation.binding(binding) as unknown as {
          activate(target: string): void
          target(key: string): { getSnapshot(): unknown }
        }
        // Reading a target source does not activate it in 0.1.7+; without
        // activation the chat nodes this classification needs stay absent for
        // every session the shell has not selected.
        conversation.activate('chat')
        const chat = conversation.target('chat').getSnapshot() as ChatSnapshotLike | undefined
        const session = binding.session.getSnapshot() as unknown as SessionSnapshot
        return sessionDetailOf(session, chat)
      } catch {
        return undefined
      }
    },
    // Open a session the UI never opened so its chat view can assemble the
    // final assistant text; skipped when no alert could use it.
    ensureDetail: async (id) => {
      const settings = currentSettings()
      if (!settings.browserEnabled && !settings.soundEnabled) return
      if (!Object.values(settings.types).some(type => type.enabled)) return
      try {
        await ctx.sessions.using(id, { source: 'sessionNotification' }, async () => {})
      } catch (error) {
        console.warn('[dsh-session-notification] could not load the notification session', id, error)
      }
    },
    titleOf: (id: SessionId) => ctx.sessions.list.getSnapshot().byId[id]?.displayTitle ?? id,
    // The host will resume this session by itself: a queued follow-up is
    // claimed as the next turn, and a goal round is queued once the driver sees
    // idle. The running bit is false in both gaps, so that idle edge is a
    // pause, not an end. Read from the list snapshot to cover unopened sessions.
    hasUnfinishedWork: (id) => {
      // Structural: the `inbox` and `goal` projection wire values, no host imports.
      const values = ctx.sessions.list.getSnapshot().projectionsBySession[id]?.values as {
        inbox?: { 'next-turn'?: readonly unknown[], 'next-step'?: readonly unknown[] }
        goal?: { goal: { phase: string, maxGoalRounds: number }, roundsStarted: number } | null
      } | undefined
      const inbox = values?.inbox
      if ((inbox?.['next-turn']?.length ?? 0) > 0 || (inbox?.['next-step']?.length ?? 0) > 0) return true
      const goal = values?.goal
      // A goal that reached its round cap is blocked by the driver, not continued.
      return goal?.goal.phase === 'active' && goal.roundsStarted < goal.goal.maxGoalRounds
    },
    settle: () => new Promise(resolve => setTimeout(resolve, SETTLE_MS)),
    // Subagents live in the same sessions list, flagged by their summary
    // origin; the main-only filter silences them.
    isSubagent: (id: SessionId) =>
      ctx.sessions.list.getSnapshot().byId[id]?.origin === 'subagent',
    // Walk the parentId chain so a nested subagent keeps its root's completion
    // held too (a subagent may itself fan out).
    hasRunningDescendants: (id: SessionId) => {
      const byId = ctx.sessions.list.getSnapshot().byId
      const seen = new Set<SessionId>([id])
      const queue: SessionId[] = [id]
      while (queue.length > 0) {
        const parent = queue.shift() as SessionId
        for (const summary of Object.values(byId)) {
          if (summary.parentId !== parent || seen.has(summary.id)) continue
          seen.add(summary.id)
          if (summary.running) return true
          queue.push(summary.id)
        }
      }
      return false
    },
    emit: (event) => {
      // One tab wins the event (a visible tab ahead of a background one); the
      // others stay silent for it. Without BroadcastChannel every tab claims
      // its own event, i.e. the pre-coordination behavior.
      void coordinator.claim(`${event.sessionId}:${event.kind}`).then((owned) => {
        if (owned) dispatcher.dispatch(event)
      })
    },
  })
  // Keep the engine's notification scope in lockstep with the preference.
  engine.setNotificationMode(currentSettings().notificationMode)
  // Re-sync on every scope change (including other tabs).
  ctx.effect(() => scope.subscribe(() => {
    engine.setNotificationMode(currentSettings().notificationMode)
  }), 'dsh-session-notification: mode sync')
  ctx.effect(() => {
    const unsubscribe = ctx.sessions.list.subscribe(() => engine.observe(ctx.sessions.list.getSnapshot()))
    // Establish the baseline so pre-existing state raises nothing.
    engine.seed(ctx.sessions.list.getSnapshot())
    return unsubscribe
  }, 'dsh-session-notification: session watch')

  // dsh 0.1.7 unified the pending-interaction map into the uiSession session
  // status source (running + pendingInteraction + completionUnread per
  // session): observe its pendingInteraction values for question/approval
  // edges.
  const pendingFactsOf = (statuses: SessionStatusSnapshot): Map<SessionId, PendingFacts> => {
    const out = new Map<SessionId, PendingFacts>()
    for (const [id, status] of statuses) {
      const interaction = status.pendingInteraction
      if (interaction === undefined) continue
      const kind = interaction.kind === 'approval'
        ? 'approval' as const
        : (interaction.kind === 'question' || interaction.kind === 'plan-review')
          ? 'question' as const
          : undefined
      if (kind === undefined) continue
      const questions = (interaction as unknown as { questions?: readonly { question?: string }[] }).questions
      const tool = (interaction as unknown as { toolName?: string }).toolName
      const detail = questions?.[0]?.question ?? tool ?? ''
      out.set(id, { key: interaction.key, kind, detail })
    }
    return out
  }
  ctx.effect(() => ctx.uiSession.sessionStatus.subscribe(() => {
    engine.observePending(pendingFactsOf(ctx.uiSession.sessionStatus.getSnapshot()))
  }), 'dsh-session-notification: pending watch')

  /** Persist one top-level preference through the scope, mirroring optimistically. */
  const persist = (field: 'browserEnabled' | 'currentNotificationMode' | 'notificationMode' | 'soundEnabled' | 'volume', value: unknown): void => {
    if (field === 'browserEnabled') bound?.setBrowserEnabled(value as boolean)
    else if (field === 'currentNotificationMode') bound?.setCurrentNotificationMode(value as CurrentNotificationMode)
    else if (field === 'notificationMode') bound?.setNotificationMode(value as NotificationMode)
    else if (field === 'soundEnabled') bound?.setSoundEnabled(value as boolean)
    else bound?.setVolume(value as number)
    void scope.set(field, value)
  }

  /** Persist one per-kind preference (the whole `types` section is one field). */
  const persistType = (kind: NotificationType, patch: Partial<{ enabled: boolean; sound: SoundId }>): void => {
    const next = { ...currentSettings().types[kind], ...patch }
    bound?.setType(kind, patch)
    void scope.set('types', { ...currentSettings().types, [kind]: next })
  }

  const injected = (actions: BoundActions<typeof store>): NotificationsSectionInjected => {
    bound = actions
    // First sync on mount: push the accepted scope value into the renderer's store.
    bound.adopt(scope.getSnapshot())
    return {
      setBrowserEnabled: async (enabled) => {
        if (enabled) {
          let permission = browserPermission()
          if (permission === 'default') {
            permission = await requestBrowserPermission()
            bound?.setPermission(permission)
          }
          if (permission !== 'granted') return
        }
        persist('browserEnabled', enabled)
      },
      setCurrentNotificationMode: (mode) => { persist('currentNotificationMode', mode) },
      setNotificationMode: (mode) => { persist('notificationMode', mode) },
      setSoundEnabled: (enabled) => { persist('soundEnabled', enabled) },
      setVolume: (volume) => { persist('volume', Math.min(1, Math.max(0, volume))) },
      setType: (kind, patch) => { persistType(kind, patch) },
      testSound: (sound, customUrl) => { playEffective(sound, customUrl) },
      requestPermission: async () => {
        bound?.setPermission(await requestBrowserPermission())
      },
      testBrowserNotification: () => {
        showBrowserNotification(t('test.notification.title'), t('test.notification.body'), `${NOTIFICATION_TAG_PREFIX}:test`)
      },
      uploadCustomSound: async (kind, file) => {
        if (file.size > MAX_CUSTOM_AUDIO_BYTES) return
        const dataUrl = await readFileAsDataUrl(file)
        writeCustomSound(kind, dataUrl)
        bound?.setCustomSound(kind, dataUrl)
        // Uploading from the 自定义 picker selection persists the selection too.
        persistType(kind, { sound: 'custom' })
      },
    }
  }

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'notifications',
    order: 40,
    label: () => t('nav'),
    store,
    locale: NS,
    inject: injected,
  }, NotificationsSection))
}
