# dsh-dual-checkin

![Release](https://img.shields.io/github/v/release/G57651/dsh-dual-checkin)
![平台](https://img.shields.io/badge/%E5%B9%B3%E5%8F%B0-macOS%20%7C%20Windows-2EA043)
![License](https://img.shields.io/github/license/G57651/dsh-dual-checkin)

DeepSeek Harness 签到插件：一个插件同时完成 **Trae**、**WorkBuddy** 与 **Qoder** 的每日签到，并在主页侧边栏提供签到状态与积分面板。登录态**只读本机文件**——不读取青龙环境变量里的 token / uid / 账号列表，也不把解出的 token 写入 settings 或状态文件。

> 包名与 entry id 沿用 `dsh-dual-checkin`：entry id 是加载层的稳定身份，状态文件也按旧名落盘，改名会让「当日已签」记忆失效、同日重复触发。三平台能力以 1.3.0 为准。

## 功能

- **三平台状态卡**：主页侧边栏新增「签到」图标入口（`sidebar.panellist`），点击打开全宽面板——Trae、WorkBuddy 与 Qoder 各一张状态卡（已签到 / 未签到徽标 + 24 小时制签到时间 + 最近备注）。
- **积分与到期跟踪**：常驻积分行（剩余 / 已使用 / 三天内到期，三列跨卡对齐）；三天内有积分到期时卡片内出现醒目提醒；「本次获得」直接显示在票据卡主数字上，签到前 / 签到后的积分基线以状态路由的 `creditsBefore` / `creditsAfter` 暴露（面板不单独成行）。积分快照按 TTL（默认 5 分钟，可用 `creditsTtlSeconds` 调整）自动重新查询，签到每天只发生一次。失败结果同样有 60 秒负缓存——上游故障时面板轮询不会再反复重打上游。
- **启动自动签到**：仅随 DSH 启动自动执行，幂等——当日已签自动跳过，无手动签到入口。
- **PAT 首次启用录入与到期提醒**：在插件配置（或 cordis.yml）里填 `qoderPat`（令牌）与 `qoderPatExpiresAt`（到期时间）即可启用；剩余 ≤ `qoderPatExpiringDays` 天（默认 7）时面板 Qoder 卡片显示黄色提醒、日志同步 warn，过期显示红色提醒。不填令牌时回退读取 `qoderCredentialRef` 指向的凭据。
- **互不阻塞**：`Promise.allSettled` 并行跑三个平台，一边失败 / 超时 / 未登录，另一边照常完成。
- **状态面板可刷新**：数据来自宿主路由 `/plugins/dsh-dual-checkin/status`，`GET` 读快照、`POST` 强制重查积分，页内刷新按钮走 `POST`。

## 安装

**CLI 从 GitHub 安装（推荐）**

```sh
dsh plugin --profile desktop add github:G57651/dsh-dual-checkin
```

**Web UI**：Plugins 页 → Git 填 `github:G57651/dsh-dual-checkin`；或下载 Release / `pnpm pack` 产出的 tarball 后：

```sh
dsh plugin --profile desktop add dsh-dual-checkin-1.3.12.tgz
```

**克隆后本地安装**

```sh
git clone https://github.com/G57651/dsh-dual-checkin.git
dsh plugin --profile desktop add ./dsh-dual-checkin
```

## 本机数据源

| 平台 | 登录态来源 |
|------|-----------|
| Trae | `~/Library/Application Support/TRAE SOLO CN/User/globalStorage/storage.json`（以及 Trae CN / Trae / TRAE SOLO、CLI 的 `trae-jwt-token`） |
| WorkBuddy | `~/Library/Application Support/CodeBuddyExtension/Data/Public/auth/workbuddy-desktop.info` |
| Qoder | **DSH 凭据服务里的 Qoder PAT**：首次启用可在插件配置直接填 `qoderPat` + `qoderPatExpiresAt`（到期时间，用于临期提醒）；不填则读取 `qoderCredentialRef`（默认 `QODER_MANAGED_CREDENTIAL`，与 dsh-provider-qoder 同一份凭据）；区域用 `qoderRegion` 切换 `cn` / `intl` |

WorkBuddy 的明文 JWT 直接使用；`$wbEncrypted` 信封按 dsh-buddy-checkin v0.2.0 的方式，拉起本机 `WorkBuddy.app` 的 Electron 取 at-rest key，再用 AES-256-GCM 解开。

Qoder **不读取任何本机登录文件、不访问系统钥匙串、零解密代码、零子进程**：直接复用你已在
DSH 配置好的 Qoder PAT，`POST /api/v1/jobToken/exchange` 换取短期 jobToken（进程内缓存、临期
5 分钟自动重换、401 自动重换一次再重试且不消耗重试次数）后调用签到接口。PAT 与 jobToken 只在
内存中使用，状态文件只存 uid / 昵称 / edition 与积分快照。未配置 PAT 时报可操作提示，不影响
Trae / WorkBuddy。

## 数据文件

- `~/.dsh/.dsh-dual-checkin-trae.json` — Trae 最近一次签到结果
- `~/.dsh/.dsh-dual-checkin-workbuddy.json` — WorkBuddy 最近一次签到结果
- `~/.dsh/.dsh-dual-checkin-qoder.json` — Qoder 最近一次签到结果

文件名带 profile 维度：profile 名（`DSH_PROFILE`）合法时写成 `…-trae-<profile>.json`，否则沿用上面的全局名。升级后首次运行会先按新名查找、找不到再回退读旧名，因此**不会**因为改名而多签一次；旧文件保持原样不被改写，可以自行删除。快照带 `schemaVersion`，并在写入与读回前都剔除名字像凭据的字段（`token` / `pat` / `authorization` / `cookie` / `secret` / `apiKey` 等，含嵌套）。

状态路由 `/plugins/dsh-dual-checkin/status`：`GET` 查看本次结果（当日已完成且快照在 TTL 内时无网络请求，超过 TTL 只重查积分、不重复签到）；`POST` 强制重查积分与状态（当日已签到的平台仍然跳过 claim，幂等）。

## 实现说明与已知限制

- **状态路由的访问守卫**：只服务回环对端（`127.0.0.0/8`、`::1`、`::ffff:127.x`）与回环 Host，`Origin` 限回环或桌面壳协议 `dsh-app:`；非法 authority（含 `@` 或 `/`、端口非纯数字，如 `localhost:80.evil.com`）一律 403。对端地址不可解析时失败关闭——宿主把 webserver 绑到非回环地址时，本插件路由不会被局域网访问。
- **凭据文件权限**：回退通道直读 `~/.dsh/.credentials.yaml` 前先校验权限，`mode & 0o077 !== 0` 时拒绝读取并提示 `chmod 600`（与宿主 credentials-local 的 `GROUP_OTHER_BITS` 语义一致）。`qoderCredentialRef` 只允许 `[A-Za-z0-9_.-]` 字符集并做逐行前缀匹配，不会把配置值当正则执行。
- **WorkBuddy 域名白名单**：`auth.domain` 必须匹配 `(^|\.)(workbuddy|codebuddy)\.cn$`，且 URL 不得携带用户名 / 密码 / 端口 / 路径 / 查询，否则该账号按未登录处理。Trae 与 Qoder 的出口为硬编码常量。
- **请求不跟随跳转**：三个平台的 `fetch` 都显式 `redirect: 'error'`——跨源 3xx 会让请求头与请求体落到新源。
- **积分口径**：Trae 余额取 `usage_summary`（`total_amount` − `consumed_amount`，权威口径），三天内到期按积分包 `expire_time` 逐包累加；WorkBuddy 走 `get-user-resource` 聚合——月度包看 `Cycle*` 字段（周期结束即重置），一次性包看 `Capacity*` 字段并剔除已过期 / 已用尽的（聚合规则与 dsh-connect-workbuddy 一致）；Qoder 走 `/sash/api/v2/me/usage`，聚合响应里的配额桶与资源包，字段缺失时对应项为 `null`。
- **签到状态检测**：WorkBuddy 先查 `checkin-activity-status` 的 `today_checked_in`（无副作用），只在未签时调 `daily-checkin`；Trae 的 `checked_in` 为账号级状态，claim 按北京日幂等；Qoder 先读 `me/campaigns` 里 `actionType=CLAIM_BENEFIT` 且时间窗开启的那一轮（`startAt/endAt` 为秒级时间戳），`claimStatus=CLAIMED` 视为已签，否则 POST `/claim`（上游幂等，重复领取返回 `replayed=true` 不再发币）。
- **Qoder 凭据失效**：PAT 无效 / 被撤销时 exchange 报错，备注明确提示「请在 DSH 设置 → 模型 → Qoder 凭据 更新 PAT」；接口 401 时先自动重换一次 jobToken 再试（不消耗重试次数），重换后仍 401 才判定登录失效。
- **Qoder 当前没有活动**：活动轮次约每日 00:40（UTC+8）滚动发放，窗口未开启时按「未完成」处理，DSH 下次启动自动重试，不会误标当日已签。
- **无设置页**：不注册 `settings.section`，无手动签到入口。
- **与同类插件不冲突**：entry id、路由和状态文件均独立于 `dsh-connect-trae`、`dsh-connect-workbuddy`、`dsh-connect-qoder`、`dsh-buddy-checkin`，可并存。
- 请通过标准渠道（GitHub / tarball）安装，不要把解包目录直接装进正在运行的 profile。

## 开发

```sh
pnpm i          # 只有 peerDependencies，用于让回归测试能加载 lib/index.mjs
pnpm test       # node --test "test/*.test.mjs"
```

回归用例把 `HOME` / `DSH_HOME` 重定向到临时目录并替换 `globalThis.fetch`，**不使用任何真实凭据、不发出任何真实请求**。

## 变更记录

详见 [CHANGELOG.md](./CHANGELOG.md)。
