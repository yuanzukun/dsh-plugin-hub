// recall 检索档(1.6 §7 步 1):范围限制(D6)+ 命中折行 + 渲染
//
// 为什么单独立一套:这条路的三个判据**出错了也不会有人喊** ——
//   ① 范围(D6 已拍:默认只搜"主人自己的会话")错了,会静默把子代理会话读进来;
//   ② 可见性过滤错了会**静默少给** ⇒ skipped 必须报出来,不许静默丢;
//   ③ 渲染错了模型只会看到 `${v.message}` 这种原样字符串 —— 本文件第一次跑就抓到过一处。
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const imp = (p) => import(pathToFileURL(join(root, p)).href);
const {
  clampSearchLimit, visibleIdSet, toSearchRows, renderSearch, searchDeepItems, adoptDeepItems,
  searchLocalTurns, SEARCH_LOCAL_TURNS_MAX,
  SEARCH_HITS_DEFAULT, SEARCH_HITS_MAX, SEARCH_DEEP_MAX, withTimeout, SEARCH_TIMEOUT_MS,
} = await imp('lib/host/recall-search.js');
const { checkRecall } = await imp('lib/host/tools.js');

let ok = true;
const check = (c, m) => { if (!c) { ok = false; console.log('✗', m); } };

// 1) 条数夹取
{
  check(clampSearchLimit(undefined) === SEARCH_HITS_DEFAULT, '缺省应给默认值');
  check(clampSearchLimit(3) === 3, '正常值原样通过');
  check(clampSearchLimit(0) === 1, '下限夹到 1');
  check(clampSearchLimit(9999) === SEARCH_HITS_MAX, '上限夹到 ' + SEARCH_HITS_MAX);
  check(clampSearchLimit('abc') === SEARCH_HITS_DEFAULT, '非数退回默认');
}

// 2) 可见集(D6 判据 = isMemoryEligibleHeader:顶层 + 分叉入,子代理不入)
{
  const recs = [
    { header: { id: 'top-1' } },
    { header: { id: 'fork-1', parentSession: 'top-1' } },
    { header: { id: 'sub-1', origin: 'subagent' } },
    { header: { id: 'sub-2', delegationDepth: 1 } },
    { header: { id: 'sub-3', parentSession: 'top-1', delegationDepth: 2 } },
    { header: null },
    {},
  ];
  const s = visibleIdSet(recs);
  check(s.has('top-1'), '顶层会话应可见');
  check(s.has('fork-1'), '分叉会话应可见(D9-a:分叉入枝)');
  check(!s.has('sub-1'), 'origin=subagent 不可见');
  check(!s.has('sub-2'), 'delegationDepth>0 不可见');
  check(!s.has('sub-3'), '带深度的分叉不可见(子代理判据优先)');
  check(s.size === 2, '可见集应恰好 2 条,实得 ' + s.size);
  check(visibleIdSet(null).size === 0, 'null 入参应得空集,不抛');
  check(visibleIdSet([{ id: 'x' }]).size === 0, '没有 header 的记录不放入(宁少不滥)');
}

// 3) 折行:范围过滤 + skipped 必须报出 + 摘要单行化
{
  const hits = [
    { header: { id: 'top-1' }, bestMatch: { type: 'user/message', seq: 113, time: 1759000000000, snippet: '第一行\n第二行' } },
    { header: { id: 'sub-1', origin: 'subagent' }, bestMatch: { type: 'assistant/message', seq: 7, time: 1759000000000, snippet: '子代理的话' } },
  ];
  const visible = visibleIdSet(hits);
  const r = toSearchRows(hits, { visible, callName: '用户' });
  check(r.rows.length === 1, '默认范围应只剩 1 条,实得 ' + r.rows.length);
  check(r.skipped === 1, '被挡掉的必须计数(skipped=1),实得 ' + r.skipped);
  check(r.rows[0].who === '用户', 'user/message 应显示称呼');
  check(!/\n/.test(r.rows[0].snippet), '摘要必须单行化');
  check(r.rows[0].seq === 113 && r.rows[0].time.length > 0, '序与时间应带出');
  const all = toSearchRows(hits, { all: true });
  check(all.rows.length === 2 && all.skipped === 0, 'all=true 应全放行');
  check(all.rows[1].who === '器灵', 'assistant/message 显示器灵');
  check(toSearchRows(null, {}).rows.length === 0, 'null hits 不抛');
}

// 4) 渲染:不许出现未插值的模板残句,任何形状都不许抛
{
  const good = renderSearch({
    ok: true, q: '记忆树 血缘', all: false, skipped: 2, hasMore: true,
    rows: [{ conv: 'session-x', seq: 113, time: '10-04 19:33', who: '用户', snippet: '先等等' }],
  });
  check(typeof good === 'string' && good.includes('记忆树 血缘'), '正常回执应含查询词');
  check(good.includes('主人自己的会话'), '默认范围要在回执里说明');
  check(good.includes('2 条被范围挡掉'), 'skipped 必须在回执里出现');
  check(!good.includes('${'), '回执里不许出现未插值的 ${');
  const empty = renderSearch({ ok: true, q: 'zzz', all: true, rows: [], skipped: 0 });
  check(empty.includes('没找到'), '空结果要有明确说法');
  check(empty.includes('未限定范围'), 'all=true 要说明范围');
  const bad = renderSearch({ ok: false, reason: 'search-unavailable', message: '没拿到服务' });
  check(bad.includes('没拿到服务'), '不可用回执要带上原因');
  check(!bad.includes('${'), '错误回执同样不许有未插值');
  for (const v of [null, undefined, {}, { ok: false, reason: 'search-failed' }, { ok: true, rows: [], q: '' }, { ok: true, q: 'x' }, { ok: true, q: 'x', rows: null }]) {
    let t = null;
    try { t = renderSearch(v); } catch (e) { t = 'THREW:' + e.message; }
    check(typeof t === 'string' && !t.startsWith('THREW:'), '渲染任何形状都不许抛:' + JSON.stringify(v));
  }
}

// 5) checkRecall 的检索档(且不破坏原有三档)
{
  const s = checkRecall({ q: '记忆树 血缘' });
  check(s.ok && s.action === 'search', 'q ⇒ 检索档');
  check(s.all === false, 'all 缺省 = false(默认只搜主人自己的会话)');
  check(s.limit === SEARCH_HITS_DEFAULT, 'limit 缺省走检索档默认');
  check(checkRecall({ q: 'x', all: true }).all === true, 'all=true 透传');
  const both = checkRecall({ q: 'x', conv: 'session-y' });
  check(both.ok === false && both.reason === 'q-xor-conv', 'q 与 conv 同给应被拒');
  check(checkRecall({ from: 1 }).reason === 'conv-required', '只给 from 仍要求 conv');
  check(checkRecall({}).action === 'map', '空参仍走地图档(没破坏旧行为)');
  check(checkRecall({ conv: 'x' }).action === 'outline', '给 conv 仍走目录档');
  check(checkRecall({ conv: 'x', from: 1, to: 3 }).action === 'read', '给范围仍走原文档');
  check(checkRecall({ q: '  ' }).action === 'map', '空白 q 不算检索(退地图档)');
}

// 6) 深层库条目检索(1.6 §7 步 4)
//    为什么必须有这一组:条目检索是**结论层**唯一的入口,而它的两个判据出错了都不会有人喊 ——
//    ① 多词语义若与宿主检索面不同解(那边是 AND),同一个问句会给出互相矛盾的结果;
//    ② `superseded_by` 若忘了过滤,会把"曾经成立、现已作废"的结论当成现行结论召回来。
{
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(':memory:');
  db.exec(`CREATE TABLE deep_item (id TEXT PRIMARY KEY, kind TEXT, text TEXT, at TEXT, conv_id TEXT,
    seq_from INTEGER, seq_to INTEGER, src TEXT, hit_count INTEGER DEFAULT 0, pinned INTEGER DEFAULT 0,
    superseded_by TEXT DEFAULT '', origin TEXT DEFAULT 'auto', branch_id TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT '')`);
  const ins = db.prepare('INSERT INTO deep_item (id,kind,text,conv_id,seq_from,seq_to,src,superseded_by,hit_count,pinned,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
  ins.run('di:1', '承诺', '器灵汇报必须基于自己实测的凭据', 'conv-a', 10, 12, 'dsh', '', 0, 0, '2026-10-04 01:00:00');
  ins.run('di:2', '偏好', '用户的原则：不投资股市、不盯盘', 'conv-b', 3, 3, 'dsh', '', 0, 0, '2026-10-04 02:00:00');
  ins.run('di:3', '决定', '记忆树血缘可溯', 'conv-a', 20, 20, 'dsweb', '', 0, 0, '2026-10-04 03:00:00');
  ins.run('di:4', '事实', '这条已被取代', 'conv-c', 1, 1, 'dsh', 'di:9', 0, 0, '2026-10-04 04:00:00');
  const mem = { db };
  check(searchDeepItems(mem, '凭据').length === 1, '单词命中 1 条');
  check(searchDeepItems(mem, '投资 股市').length === 1, '多词 AND 命中(两词在同一句里)');
  check(searchDeepItems(mem, '投资 记忆树').length === 0, 'AND 语义:两词不在同一条则 0(不是 OR)');
  check(searchDeepItems(mem, 'zzz不存在').length === 0, '无匹配=空');
  check(searchDeepItems(mem, '   ').length === 0, '空白查询=空');
  check(searchDeepItems(mem, '取代').length === 0, '已取代的条目不参与召回(只追不替)');
  check(searchDeepItems({}, '凭据').length === 0, 'memory 没有 db 时静默空,不抛');
  check(searchDeepItems(mem, '凭据', 0).length === 1, 'limit=0 退回默认而不是 0 条');
  check(searchDeepItems(mem, '%').length === 0, 'LIKE 通配符被剥掉(不误命中全部)');
  check(searchDeepItems(mem, '凭据', 99999).length === 1, '超大 limit 被夹取后仍正确');
  db.close();
  // 渲染:条目段必须出现、且两种命中能同屏
  const onlyDeep = renderSearch({
    ok: true, q: '凭据', all: false, skipped: 0, rows: [],
    deep: [{ kind: '承诺', text: '器灵汇报必须基于实测凭据', conv_id: 'conv-a', seq_from: 10, seq_to: 12, pinned: 0 }],
  });
  check(onlyDeep.includes('深层库条目'), '有条目时要出现条目段');
  check(onlyDeep.includes('[承诺]'), '条目要带 kind');
  check(onlyDeep.includes('conv-a'), '条目要带出处 conv');
  // ⚠️ 2026-10-04 改(红队 2 的 F1):这里原本断言 `from=10` —— 而**印 `from` 本身是错的**:
  //   条目的 `seq_from` 是**事件流 seq**,而 `recall(conv, from, to)` 收的是**对话轮序号 n**,
  //   实测 274 条可比条目里 **207 条(75.5%)**照这条指引会 `out-of-range`;偶有落在范围内的,
  //   读到的也是不相干的轮次,还会顺手给不相干条目计一次"采用"。
  //   ⇒ 回执改为"先 `recall(conv=…)` 拿轮次,再按目录里的 `#N` 取",并且**不许再印 `from=`**。
  check(onlyDeep.includes('recall(conv=') && onlyDeep.includes('拿轮次'),
    '条目要给出"取原话"的下一步(先看目录再取,不直接印 from)');
  check(!onlyDeep.includes('from='), '★ 不许再印 from=<seq>(坐标系错位:事件流 seq ≠ 对话轮序号 n)');
  // M2(1.7.2):「下一步」已收进工具 description —— 回执里**不再重复**印固定指令(那是噪音主体)。
  check(!onlyDeep.includes('下一步'), 'M2:固定「下一步」不再印在回执里(已收进 description)');
  check(!onlyDeep.includes('${'), '条目回执不许有未插值');
  check(renderSearch({
    ok: true, q: 'x', all: false, deep: [{ kind: '偏好', text: '一句话', conv_id: 'c' }],
    rows: [{ conv: 'c2', seq: 1, time: '10-04 20:08', who: '用户', snippet: 's' }],
  }).includes('会话原文层'), '条目会话双命中时两段都在');
  check(renderSearch({
    ok: true, q: 'x', all: false, deep: [], rows: [{ conv: 'c2', seq: 1, time: 't', who: '用户', snippet: 's' }],
  }).includes('找到 1 轮原文'), '无条目时也要有明确说法(口径:现在是"轮原文"而不是"个会话" —— 本地层按轮给)');
  check(renderSearch({
    ok: true, q: 'x', all: false, local: true, deep: [],
    rows: [{ conv: 'c2', seq: 1, time: 't', who: '用户', snippet: 's' }],
  }).includes('本机库内原文层'), '★ A方案:本地路回执必须标注来源(残的那份要说清,否则会被读成"库里只有这些")');
  check(renderSearch({ ok: true, q: 'x', all: false, deep: [], rows: [], skipped: 0 }).includes('没找到'), '都没命中时仍要明确说法');
  check(SEARCH_DEEP_MAX > 0 && SEARCH_DEEP_MAX <= 50, 'SEARCH_DEEP_MAX 在合理区间');
}

// 7) 采用信号(1.6 步 5):`recall` 取原文 ⇒ 与**所取区间相交**的条目 `hit_count` +1。
//    为什么这条必须有断言:`hit_count` 是"反复加固"判据唯一的信号来源,而它**出错了没人会喊** ——
//    加固多了会让条目自我强化(注入越多分越高),加固少了判据恒为空。两种都不会抛异常。
{
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(':memory:');
  db.exec(`CREATE TABLE deep_item (id TEXT PRIMARY KEY, kind TEXT, text TEXT, at TEXT, conv_id TEXT,
    seq_from INTEGER, seq_to INTEGER, src TEXT, hit_count INTEGER DEFAULT 0, pinned INTEGER DEFAULT 0,
    superseded_by TEXT DEFAULT '', origin TEXT DEFAULT 'auto', branch_id TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT '')`);
  const ins = db.prepare('INSERT INTO deep_item (id,kind,text,conv_id,seq_from,seq_to,src,superseded_by,hit_count) VALUES (?,?,?,?,?,?,?,?,?)');
  ins.run('di:1', '承诺', 'A', 'conv-a', 10, 12, 'dsh', '', 0);
  ins.run('di:2', '决定', 'B', 'conv-a', 30, 30, 'dsh', '', 0);
  ins.run('di:3', '事实', 'C', 'conv-b', 5, 5, 'dsweb', '', 0);
  ins.run('di:4', '事实', 'D', 'conv-a', 11, 11, 'dsh', 'di:9', 0); // 已取代 ⇒ 不该被加固
  const mem = {
    db,
    bumpDeepHit(id) {
      const r = db.prepare('UPDATE deep_item SET hit_count=hit_count+1 WHERE id=?').run(id);
      return { ok: r.changes > 0 };
    },
  };
  const hit = (id) => Number(db.prepare('SELECT hit_count n FROM deep_item WHERE id=?').get(id).n);
  check(adoptDeepItems(mem, 'conv-a', 11, 11) === 1, '区间相交的加固(已取代的那条不计)');
  check(hit('di:1') === 1, 'di:1 被加固一次');
  check(hit('di:4') === 0, '已取代的条目**不**被加固(它是"曾经成立"的留痕)');
  check(adoptDeepItems(mem, 'conv-a', 29, 31) === 1, '另一种相交(单点落在外层区间内)');
  check(hit('di:2') === 1, 'di:2 被加固一次');
  check(adoptDeepItems(mem, 'conv-a', 1, 2) === 0, '不相交 ⇒ 0,且不改任何行');
  check(hit('di:1') === 1 && hit('di:2') === 1, '不相交时两个计数都没动');
  check(adoptDeepItems(mem, 'conv-a', 12, 12) === 1, '边界:正好落在 seq_to 上算相交');
  check(adoptDeepItems(mem, 'conv-a', 13, 13) === 0, '边界:越过 seq_to 一格就不算');
  check(adoptDeepItems(mem, 'conv-b', 5, 5) === 1, '按 conv 隔离(dsweb 源同样可加固)');
  check(adoptDeepItems({}, 'conv-a', 10, 10) === 0, 'memory 没有 db ⇒ 0,不抛');
  check(adoptDeepItems({ db }, 'conv-a', 10, 10) === 0, 'memory 没有 bumpDeepHit ⇒ 0,不抛');
  check(adoptDeepItems(mem, 'conv-a', 0, 0) === 0, '区间非法(0)⇒ 0');
  check(adoptDeepItems(mem, '', 10, 10) === 0, 'conv 为空 ⇒ 0');
  check(adoptDeepItems(mem, 'conv-a', 'abc', 10) === 0, '非数区间 ⇒ 0');
  db.close();
}

// 8) 1.6.2:超时(把"不可中断"从根上消掉)+ 本会话排最后 + 超时回执
//
// 为什么这一节必须有断言:宿主的懒对账一旦卡住,`searchSessions` **不会返回**,而 GUI 没有中断入口
// (实测挂过约 30 分钟)。这里的判据**坏了不会有人喊** —— 工具只会静静地又挂一次,而那是
// "控制权被拿走"一级的问题。所以三条各自钉死:超时值、超时形态、超时时**条目照样交出去**。
{
  check(SEARCH_TIMEOUT_MS === 20000, '★ 超时上限是主人拍的 20 秒(改它要连注释与 README 一起改)');
  check(SEARCH_HITS_DEFAULT === 5, '★ 原文层默认 5 条(1.6.2 由 10 收窄:别让它淹掉条目层)');

  // 8a) 正常完成 ⇒ 原值透传
  const fast = await withTimeout(Promise.resolve('v'), 200, 'x');
  check(fast.ok === true && fast.value === 'v', 'withTimeout:正常完成 ⇒ 原值透传');

  // 8b) 超时 ⇒ 结构化结果,**不抛**
  const slow = await withTimeout(new Promise((r) => setTimeout(() => r('late'), 500)), 30, 'searchSessions');
  check(slow.ok === false && slow.reason === 'timeout' && slow.ms === 30,
    '★ withTimeout:超时 ⇒ {ok:false, reason:timeout}(同步 reject 或抛异常都会让模型那一步直接失败)');
  check(slow.label === 'searchSessions', '超时要带上是哪一路超的(排查时第一眼要看的就是这个)');

  // 8c) 底层后来完成了 ⇒ 结果被丢弃,但**不影响正确性**(检索是只读的)
  let landed = false;
  const got = await withTimeout(new Promise((r) => setTimeout(() => { landed = true; r('v'); }, 40)), 10, 'x');
  check(got.ok === false, 'withTimeout:到点就下结论(不等底层)');
  await new Promise((r) => setTimeout(r, 60));
  check(landed === true, '底层操作之后照旧跑完(只读 ⇒ 丢弃无害;别在这上面加"取消"的想象)');

  // 8d) 本会话排到最后 + 标 isSelf(不删)
  const hits = [
    { header: { id: 'me' }, bestMatch: { seq: 9, time: '2026-10-05 08:00:00', type: 'user/message', snippet: '刚说的话' } },
    { header: { id: 'old-1' }, bestMatch: { seq: 3, time: '2026-09-01 10:00:00', type: 'user/message', snippet: '当年的话' } },
  ];
  const r1 = toSearchRows(hits, { selfId: 'me' });
  check(r1.rows.length === 2, '两条都在(本会话**不删**,只挪位)');
  check(r1.rows[1].conv === 'me' && r1.rows[1].isSelf === true, '★ 本会话被排到最后并标 isSelf');
  check(r1.rows[0].conv === 'old-1' && r1.rows[0].isSelf === false, '历史命中保持在前(稳定排序,不打乱宿主原序)');
  const r2 = toSearchRows(hits, { selfId: '' });
  check(r2.rows[0].conv === 'me' && !r2.rows[0].isSelf, '不给 selfId ⇒ 顺序与标注都不动(旧调用点零影响)');

  // 8e) 回执:标注 + 超时文案(超时≠没找到,两者下一步动作不同)
  const withSelf = renderSearch({ ok: true, q: 'x', all: false, deep: [], skipped: 0, rows: r1.rows });
  check(withSelf.includes('← 本会话'), '★ 回执标出「← 本会话」(别把刚说的当成"当年说过的话"引用)');

  const timedOutDeep = renderSearch({
    ok: true, q: 'x', all: false, skipped: 0, rows: [], timedOut: true, timeoutMs: SEARCH_TIMEOUT_MS,
    deep: [{ kind: '承诺', text: '一条结论', conv_id: 'c1' }],
  });
  check(timedOutDeep.includes('原文层超时'), '★ 超时要明说(不许说成"没找到")');
  check(timedOutDeep.includes('条目层是本地库'), '★ 超时也要说清"条目层不受影响" —— 手上有东西可用');
  check(timedOutDeep.includes('一条结论'), '超时回执里条目照常给出来');

  const timedOutEmpty = renderSearch({ ok: true, q: 'x', all: false, skipped: 0, rows: [], deep: [], timedOut: true, timeoutMs: 20000 });
  check(timedOutEmpty.includes('没跑完'), '★ 两层都空 + 超时 ⇒ 说"没跑完",不许说成"没找到"');
  check(!timedOutEmpty.includes('按内容没找到'), '超时不许落进"没找到"的旧文案(那是另一种结论)');
}

// ── 9) 本地原文层 + **本会话默认排除**(2026-10-05 夜 · 主人拍板)──────────────────────
//   为什么值得单列一组:这是"①档默认走哪条路"与"谁的命中不算命中"两条**返回面语义**,
//   错了不会抛异常 —— 只会在主人眼前变成"前几条全是今天和昨天"(他截图报过的那个症状)。
{
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(':memory:');
  db.exec('CREATE TABLE dsh_turns_raw (session_id TEXT, seq INTEGER, role TEXT, ts TEXT, text TEXT)');
  const ins = db.prepare('INSERT INTO dsh_turns_raw VALUES (?,?,?,?,?)');
  ins.run('me', 1, 'user', '2026-10-05 20:00:00', '我在本会话说的检索');
  ins.run('me', 2, 'assistant', '2026-10-05 20:01:00', '本会话的另一句检索');
  ins.run('old', 5, 'user', '2026-09-01 10:00:00', '当年说过的检索');
  const mem = { db };

  const def = searchLocalTurns(mem, '检索', 10, { selfId: 'me' });
  check(def.rows.length === 1 && def.rows[0].conv === 'old',
    '★ 本会话**默认整条排除**(只剩历史那一条)—— 实际:' + JSON.stringify(def.rows.map((r) => r.conv)));
  check(def.selfExcluded === 2, '★ 被排除的条数如实报出(不然会被读成"库里只有这些")—— 实际:' + def.selfExcluded);

  const inc = searchLocalTurns(mem, '检索', 10, { selfId: 'me', includeSelf: true });
  check(inc.rows.length === 3 && inc.selfExcluded === 0, 'includeSelf=true ⇒ 全都在,且排除计数归零');
  check(inc.rows[2].conv === 'me' && inc.rows[2].isSelf === true, 'includeSelf 时本会话仍排在最后(顺序语义不变)');

  const noSelf = searchLocalTurns(mem, '检索', 10, {});
  check(noSelf.rows.length === 3 && noSelf.selfExcluded === 0, '不给 selfId ⇒ 谁都不排除(旧调用点零影响)');

  const txt = renderSearch({
    ok: true, q: '检索', all: false, local: true, deep: [], skipped: 0,
    rows: def.rows, selfExcluded: def.selfExcluded,
  });
  check(/另有 2 轮命中属于\*\*当前会话自己\*\*/.test(txt), '★ 回执说出"另有 N 轮是本会话、已排除"(不说就是假装搜过了)');
  const txt2 = renderSearch({
    ok: true, q: '检索', all: false, local: true, deep: [], skipped: 0, rows: def.rows, selfExcluded: 0,
  });
  check(!/另有/.test(txt2), '没有排除时不印那句(免得每次都多一段噪音)');

  check(SEARCH_LOCAL_TURNS_MAX >= SEARCH_HITS_MAX, '本地层上限不低于宿主层(否则同一个 limit 在两条路上含义不同)');

  // ⚠️ 2026-10-05 夜**真机抓到的疏漏**:**只有条目、原文 0 条**时 head 走另一支,那里漏了来源标注 ——
  //   而"原文被排除成 0 条"恰好是最容易落进这一支的情形(真机搜「检索」就是这样:7 条条目 + 0 轮原文)。
  const onlyDeep = renderSearch({
    ok: true, q: '检索', all: false, local: true, rows: [], skipped: 0, selfExcluded: 3,
    deep: [{ kind: '事实', text: 'x', conv_id: 'c' }],
  });
  check(/本机库内原文层/.test(onlyDeep), '★ 只有条目时也要标原文来源(否则默认路的覆盖范围无人知晓)');
  check(/另有 3 轮/.test(onlyDeep), '只有条目时"已排除 N 轮"照样要说');
  db.close();
}

// ── 10) 检索面:类目名(kind)也在扫描范围内(2026-10-06)─────────────────────────
//   与 l1lines 第 14 组同源:两个入口(开场选料 / 按内容检索)都曾经只扫正文 ⇒
//   查询里的类目词打不中它们自己的条目(实测搜「纪律」只回来 2/18 条)。
{
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(':memory:');
  db.exec(`CREATE TABLE deep_item (
    id TEXT, kind TEXT, text TEXT, conv_id TEXT, src TEXT,
    seq_from INTEGER DEFAULT 0, seq_to INTEGER DEFAULT 0,
    pinned INTEGER DEFAULT 0, hit_count INTEGER DEFAULT 0,
    superseded_by TEXT DEFAULT '', created_at TEXT, at TEXT)`);
  const ins = db.prepare('INSERT INTO deep_item (id,kind,text,conv_id,src,created_at,at) VALUES (?,?,?,?,?,?,?)');
  ins.run('d1', '纪律', '正文里没有那个类目词', 'c1', 'vein', '2026-10-06', '2026-10-06');
  ins.run('d2', '事实', '正文里没有那个类目词', 'c1', 'vein', '2026-10-06', '2026-10-06');
  const mem = { db };
  check(searchDeepItems(mem, '纪律', 10).length === 1, '★ 检索面能按**类目名**命中(纪律)');
  check(searchDeepItems(mem, '事实', 10).length === 1, '★ 同族:按「事实」命中事实类');
  check(searchDeepItems(mem, '纪律 事实', 10).length === 0, '★ 多词仍是 AND(两类互斥 ⇒ 0 条)');
  check(searchDeepItems(mem, '正文里', 10).length === 2, '正文关键词照旧命中(没被 kind 改动挤掉)');
  db.close();
}

// ── 11) 本地路的**范围**必须如实说(2026-10-06 · 外部文档核对抓到)────────────────────
//   本地路直查 `dsh_turns_raw` —— 那是**全量**(实测 11,296 行 / 1,647 会话,含 `source='dsweb'`
//   的 **1,523 个网页端导入会话** + 未标来源的 104 个)⇒ 它**不过可见集**。
//   而它曾硬写 `degraded:false` ⇒ 回执照旧印「已在主人自己的会话内(默认范围)」= **说假话**。
{
  const loc = renderSearch({
    ok: true, q: 'x', all: false, local: true, localScope: true, deep: [], rows: [], skipped: 0,
  });
  check(/本机库全量/.test(loc), '★ 本地路要如实说范围(不过可见集)');
  check(!/已在「\*\*主人自己的会话\*\*」内/.test(loc), '★ 本地路**不许**谎称"已在主人自己的会话内"');
  const host = renderSearch({ ok: true, q: 'x', all: false, deep: [], rows: [], skipped: 0 });
  check(/已在「\*\*主人自己的会话\*\*」内/.test(host), '宿主路(无 localScope)照旧印"已在主人自己的会话内"(没被误伤)');
}

// ── 12) F3:库**读不出来** ≠ 零命中(降级口径不对称 · 1.7 修复批次)───────────────────
//   病灶:`recall-search.js:113`/`:153` 两处 `catch { return [] }` 把**底层库读失败**归并成
//   **零命中**,而本地路**无条件回 ok:true** ⇒ 渲染成「按内容没找到」。同文件对**宿主那条路**
//   却是严格分开的(`search-unavailable` / 超时专用文案)—— 违反项目自己的口径「库不可用 ≠ 零命中」。
//   本节的判据要**双向**:① 库坏 ⇒ 必须说"不是库里没有";② 库**缺表** ⇒ 仍静默零命中(有意设计,不许改掉)。
{
  const { registerLingTools } = await imp('lib/host/tools.js');
  const mkRecall = (db) => {
    const specs = new Map();
    const ctx = { tools: { register: (spec) => { specs.set(spec.name, spec); return () => specs.delete(spec.name); } } };
    registerLingTools(ctx, {
      gate: { snapshotIds: () => [] }, memory: { db, kvSet() {}, kvGet: () => '' }, settings: { get: () => ({}) }, library: null,
    });
    return specs.get('recall');
  };
  // 走**工具的真实两段**(execute + render)—— 只调纯函数会漏掉"文案物理不可达"那一类
  // (renderRecall 曾在 `ok!==true` 时自己先拦,三句降级文案根本到不了模型眼前)。
  const receipt = async (db, args = { q: '记忆树' }) => {
    const tool = mkRecall(db);
    const v = await tool.execute(args, {});
    const text = tool.output.render([args], v).map((x) => x.text).join('\n');
    return { v, text };
  };

  const broken = { prepare() { throw new Error('database disk image is malformed'); } };
  const missing = { prepare() { throw new Error('no such table: dsh_turns_raw'); } };

  // ① 主判据:库损坏 ⇒ 明说"这不是库里没有"(修前是「按内容没找到(查询…)」⇒ 红)
  const b = await receipt(broken);
  check(b.v.ok === false && b.v.reason === 'local-unavailable',
    '★ 库读不出来 ⇒ ok:false + reason=local-unavailable(实际 ' + JSON.stringify(b.v.reason) + ')');
  check(/不是"库里没有"/.test(b.text),
    '★ 回执明说"这不是库里没有"(实际:' + b.text.slice(0, 140) + ')');
  check(!/没找到/.test(b.text), '★ 回执**不含**「没找到」 —— 那是另一种结论,两者的下一步动作不同');
  check(/recall\(\)/.test(b.text), '★ 给出替代动作:不带参数的 recall() 按时间翻清单');

  // ② 正对照:库**缺表** ⇒ 仍静默零命中、回执仍是"没找到"族(有意设计,不许被这次修复改掉)
  const m = await receipt(missing);
  check(m.v.ok === true, '★ 缺表 ⇒ 仍是"正常但零命中"(检索面不该因为某张表缺席而整体失败)');
  check(/按内容没找到/.test(m.text), '★ 缺表 ⇒ 回执仍是"没找到"族(有意行为)');
  check(!/不是"库里没有"/.test(m.text), '★ 缺表**不许**印"库读不出来"(那会变成另一种假话)');

  // ③ 收窄判据(纯函数层):两处 catch 只吞"表 / 列不存在",库损坏 / 被占用 / SQL 错必须往上冒
  //   ⚠️ 入参是 **memory**(函数从 `memory.db` 取连接),不是连接本身 —— 传错会静默走 `return []` 那条早退。
  const memBroken = { db: broken };
  const memMissing = { db: missing };
  let threwLocal = null;
  try { searchLocalTurns(memBroken, 'x', 5, {}); } catch (e) { threwLocal = e; }
  check(threwLocal && /malformed/.test(String(threwLocal.message)),
    '★ searchLocalTurns:库损坏**必须往上冒**(不再吞成零命中),实际 ' + threwLocal);
  check(searchLocalTurns(memMissing, 'x', 5, {}).rows.length === 0, '★ searchLocalTurns:缺表照旧静默空(有意设计未被破坏)');
  let threwDeep = null;
  try { searchDeepItems(memBroken, 'x', 5); } catch (e) { threwDeep = e; }
  check(threwDeep && /malformed/.test(String(threwDeep.message)),
    '★ searchDeepItems:库损坏**必须往上冒**,实际 ' + threwDeep);
  check(searchDeepItems(memMissing, 'x', 5).length === 0, '★ searchDeepItems:缺表照旧静默空');

  // ④ 条目层那一半也要包进去(它的调用点在旧 try **之外**):深层库读失败同样不许被读成零命中
  const localOkDeepBad = {
    prepare(sql) {
      if (/dsh_turns_raw/.test(String(sql))) return { all: () => [] };
      throw new Error('database disk image is malformed');
    },
  };
  const d = await receipt(localOkDeepBad);
  check(d.v.ok === false && d.v.reason === 'local-unavailable',
    '★ deep_item 那一半读失败也走同一条降级(不是只包了原文层半条路),实际 ' + JSON.stringify(d.v.reason));
}

console.log(ok ? '✓ recall-search 全部通过' : '✗ recall-search 有失败项');
process.exit(ok ? 0 : 1);
