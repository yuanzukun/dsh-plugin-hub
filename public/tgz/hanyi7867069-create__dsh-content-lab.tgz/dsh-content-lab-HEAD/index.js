/**
 * dsh-content-lab · 内容工坊
 *
 * A content production pipeline for DeepSeek Harness:
 *   content_topic_generator  — 爆款选题（领域 × 平台）
 *   content_title_rewriter   — 标题改写
 *   content_post_writer      — 按平台生成完整文案
 *   content_calendar         — 内容排期表
 *
 * Design notes:
 * - Zero external imports. Tools register through raw JSON-Schema
 *   `ctx.tools.register()`; LLM calls use `ctx.llm.stream()` with hand-built
 *   messages, so the bundle installs anywhere without @deepseek-ai/* resolution.
 * - provider/model come from the bundle row config (patch file) so each
 *   deployment can point at its own adapter route and model.
 */

export const name = 'dsh-content-lab'
export const inject = ['tools', 'llm']

/** Build one hand-constructed user message (zero-import message construction). */
export function userMessage(text) {
  return {
    id: crypto.randomUUID(),
    role: 'user',
    content: [{ type: 'text', text }],
    source: { kind: 'user' },
  }
}

/** One hand-built LLM call; returns the concatenated text. Throws on abort/error finishes. */
async function askLlm(ctx, exec, { provider, model, system, user, temperature = 0.8, maxTokens = 2048 }) {
  let text = ''
  let terminal = undefined
  const seen = []
  try {
    const stream = ctx.llm.stream({
      provider,
      model,
      system,
      messages: [userMessage(user)],
      temperature,
      maxTokens,
      signal: exec.signal,
    })
    if (stream == null) console.error('[content-lab] ctx.llm.stream() returned null/undefined')
    for await (const chunk of stream) {
      seen.push(chunk.type)
      if (chunk.type === 'text-delta') text += chunk.text
      else if (chunk.type === 'finish') terminal = chunk
    }
  } catch (error) {
    console.error('[content-lab] askLlm threw:', error?.message ?? error)
    throw error
  }
  const reason = terminal?.reason
  const kind = typeof reason === 'string' ? reason : reason?.kind
  if (kind === 'aborted') throw new Error('content-lab: LLM call aborted')
  if (kind === 'error') {
    const detail = typeof reason === 'object' && reason?.failure?.message ? reason.failure.message : 'unknown'
    throw new Error(`content-lab: LLM call failed — ${detail}`)
  }
  if (!text.trim()) throw new Error('content-lab: empty LLM response')
  return text
}

/** Extract the first JSON array or object from model output; fall back to raw text. */
export function parseJsonLoose(text) {
  const cleaned = text.replace(/```(?:json)?/g, '').trim()
  for (const start of ['[', '{']) {
    let depth = 0
    let inString = false
    let escape = false
    for (let i = 0; i < cleaned.length; i += 1) {
      const ch = cleaned[i]
      if (inString) {
        if (escape) escape = false
        else if (ch === '\\') escape = true
        else if (ch === '"') inString = false
        continue
      }
      if (ch === '"') inString = true
      else if (ch === start) depth += 1
      else if (ch === (start === '[' ? ']' : '}')) {
        depth -= 1
        if (depth === 0) {
          const candidate = cleaned.slice(0, i + 1)
          try { return JSON.parse(candidate) } catch { break }
        }
      }
    }
  }
  return text
}

function toolDef({ name: toolName, description, parameters, outputSchema, execute }) {
  return {
    name: toolName,
    description,
    parameters,
    output: {
      schema: outputSchema,
      render: (_args, value) => [{
        type: 'text',
        text: typeof value === 'string' ? value : JSON.stringify(value, null, 2),
      }],
    },
    execute,
  }
}

export function apply(ctx, config = {}) {
  const cfg = {
    provider: config.provider ?? 'deepseek-official',
    model: config.model ?? 'deepseek-v4-flash',
  }

  // ── 1. 爆款选题 ─────────────────────────────────────────────────────────
  ctx.tools.register(toolDef({
    name: 'content_topic_generator',
    description: '为指定领域和目标平台生成一批有爆款潜力的内容选题（标题、切入角度、开场钩子、火的原因）。适合做自媒体/内容营销时找选题。',
    parameters: {
      type: 'object',
      properties: {
        niche: { type: 'string', description: '内容领域，例如：宠物、职场、AI 工具、减肥、理财' },
        platform: { type: 'string', enum: ['小红书', '抖音', '公众号', 'B站', '通用'], description: '目标平台' },
        count: { type: 'integer', minimum: 1, maximum: 15, description: '生成选题数量' },
        model: { type: 'string', description: '可选的模型覆盖' },
      },
      required: ['niche'],
      additionalProperties: false,
    },
    outputSchema: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          angle: { type: 'string' },
          hook: { type: 'string' },
          why: { type: 'string' },
        },
        required: ['title', 'angle', 'hook', 'why'],
      },
    },
    async execute(args, exec) {
      const count = args.count ?? 10
      const user = [
        `领域：${args.niche}`,
        `平台：${args.platform ?? '通用'}`,
        `请生成 ${count} 个高潜力选题。`,
        '每个选题包含：title（具体选题标题）、angle（独特切入角度）、hook（开场钩子，一句话）、why（为什么能火，30 字以内）。',
        '只输出 JSON 数组，不要输出任何其他文字。',
      ].join('\n')
      const text = await askLlm(ctx, exec, {
        ...cfg,
        ...(args.model ? { model: args.model } : {}),
        system: '你是资深内容策划和爆款选题专家，熟悉小红书、抖音、公众号、B站的流量逻辑。你的选题要具体、有反差、有情绪价值，避免空泛。',
        user,
        temperature: 0.9,
      })
      return parseJsonLoose(text)
    },
  }))

  // ── 2. 标题改写 ─────────────────────────────────────────────────────────
  ctx.tools.register(toolDef({
    name: 'content_title_rewriter',
    description: '把原标题/主题改写成一批高点击率标题，支持不同风格（悬念、数字、情绪、反差、疑问）。',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string', description: '原标题或主题' },
        style: { type: 'string', enum: ['综合', '悬念', '数字', '情绪', '反差', '疑问'], description: '改写风格' },
        count: { type: 'integer', minimum: 1, maximum: 12, description: '生成标题数量' },
        model: { type: 'string', description: '可选的模型覆盖' },
      },
      required: ['title'],
      additionalProperties: false,
    },
    outputSchema: { type: 'array', items: { type: 'string' } },
    async execute(args, exec) {
      const count = args.count ?? 6
      const user = [
        `原标题/主题：${args.title}`,
        `风格：${args.style ?? '综合'}`,
        `请生成 ${count} 个改写标题，长短搭配，符合目标平台的标题习惯，不要偏离原意。`,
        '只输出 JSON 字符串数组，不要输出任何其他文字。',
      ].join('\n')
      const text = await askLlm(ctx, exec, {
        ...cfg,
        ...(args.model ? { model: args.model } : {}),
        system: '你是爆款标题专家，深谙标题心理学：数字、悬念、利益点、情绪词、反差感、具体化。',
        user,
        temperature: 0.9,
      })
      return parseJsonLoose(text)
    },
  }))

  // ── 3. 平台文案 ─────────────────────────────────────────────────────────
  const PLATFORM_BRIEFS = {
    小红书: '输出 JSON：{ title, body, hashtags }。body 用分段+emoji，口语化、真诚、有画面感，结尾引导互动；hashtags 是 5~8 个话题标签数组。',
    公众号: '输出 JSON：{ title, summary, body }。body 用标题层级和短段落，逻辑清晰，结尾给行动号召。',
    抖音: '输出 JSON：{ title, script }。script 是口播脚本，前 3 秒必须有钩子，包含停顿提示和镜头建议，结尾引导关注。',
    B站: '输出 JSON：{ title, outline, script }。outline 是分 P 大纲，script 是开场 60 秒口播稿。',
  }
  ctx.tools.register(toolDef({
    name: 'content_post_writer',
    description: '按平台风格生成完整内容文案（小红书笔记/公众号文章/抖音口播脚本/B站视频脚本），带标题、正文和话题标签。',
    parameters: {
      type: 'object',
      properties: {
        topic: { type: 'string', description: '内容主题' },
        platform: { type: 'string', enum: ['小红书', '公众号', '抖音', 'B站'], description: '目标平台' },
        tone: { type: 'string', description: '语气风格，例如：专业、幽默、治愈、犀利' },
        extra: { type: 'string', description: '补充信息：目标人群、卖点、素材、要求等' },
        model: { type: 'string', description: '可选的模型覆盖' },
      },
      required: ['topic'],
      additionalProperties: false,
    },
    outputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        body: { type: 'string' },
        hashtags: { type: 'array', items: { type: 'string' } },
        summary: { type: 'string' },
        script: { type: 'string' },
        outline: { type: 'array', items: { type: 'string' } },
      },
      required: ['title'],
    },
    async execute(args, exec) {
      const platform = args.platform ?? '小红书'
      const brief = PLATFORM_BRIEFS[platform] ?? PLATFORM_BRIEFS['小红书']
      const user = [
        `主题：${args.topic}`,
        `平台：${platform}`,
        args.tone ? `语气：${args.tone}` : '',
        args.extra ? `补充信息：${args.extra}` : '',
        brief,
        '只输出 JSON，不要输出任何其他文字。',
      ].filter(Boolean).join('\n')
      const text = await askLlm(ctx, exec, {
        ...cfg,
        ...(args.model ? { model: args.model } : {}),
        system: `你是${platform}平台资深内容创作者，懂流量、懂用户、懂平台规则。`,
        user,
        temperature: 0.85,
        maxTokens: 4096,
      })
      return parseJsonLoose(text)
    },
  }))

  // ── 4. 内容排期 ─────────────────────────────────────────────────────────
  ctx.tools.register(toolDef({
    name: 'content_calendar',
    description: '为一个内容账号生成未来 N 天的内容排期表（每天的主题、形式、钩子、目标）。',
    parameters: {
      type: 'object',
      properties: {
        niche: { type: 'string', description: '账号领域' },
        days: { type: 'integer', minimum: 1, maximum: 30, description: '排期天数' },
        platform: { type: 'string', enum: ['小红书', '抖音', '公众号', 'B站', '通用'], description: '平台' },
        focus: { type: 'string', description: '近期重点方向，例如：涨粉、带货、IP 人设' },
        model: { type: 'string', description: '可选的模型覆盖' },
      },
      required: ['niche'],
      additionalProperties: false,
    },
    outputSchema: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          day: { type: 'integer' },
          topic: { type: 'string' },
          format: { type: 'string' },
          hook: { type: 'string' },
          goal: { type: 'string' },
        },
        required: ['day', 'topic', 'format', 'hook', 'goal'],
      },
    },
    async execute(args, exec) {
      const days = args.days ?? 7
      const user = [
        `领域：${args.niche}`,
        `平台：${args.platform ?? '通用'}`,
        `天数：${days}`,
        args.focus ? `近期重点：${args.focus}` : '',
        `请生成 ${days} 天的内容排期，每天包含：day（第几天）、topic（选题）、format（内容形式）、hook（核心钩子）、goal（当天目标，如涨粉/互动/转化）。`,
        '排期要有节奏：类型穿插、避免同质化，第 1 天和第 4 天放最有爆款潜力的选题。',
        '只输出 JSON 数组，不要输出任何其他文字。',
      ].filter(Boolean).join('\n')
      const text = await askLlm(ctx, exec, {
        ...cfg,
        ...(args.model ? { model: args.model } : {}),
        system: '你是内容策略师，擅长为个人 IP 和品牌账号设计有节奏、可持续的内容排期。',
        user,
        temperature: 0.8,
        maxTokens: 4096,
      })
      return parseJsonLoose(text)
    },
  }))
}
