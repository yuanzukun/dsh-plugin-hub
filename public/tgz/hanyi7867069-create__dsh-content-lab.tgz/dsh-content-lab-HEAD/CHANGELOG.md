# Changelog

## 0.1.0 — 2026-08-17

- Initial release: content workshop tools for DeepSeek Harness.
- `content_topic_generator` — 选题生成（领域 × 平台）
- `content_title_rewriter` — 标题改写（悬念/数字/情绪/反差/疑问）
- `content_post_writer` — 按平台生成文案（小红书/公众号/抖音/B站）
- `content_calendar` — N 天内容排期表
- Zero external imports; provider/model configurable via the bundle row.
