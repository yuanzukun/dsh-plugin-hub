import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseJsonLoose, userMessage } from '../index.js'

test('parseJsonLoose extracts JSON from a fenced block', () => {
  const text = '```json\n[{"title": "A"}]\n```'
  assert.deepEqual(parseJsonLoose(text), [{ title: 'A' }])
})

test('parseJsonLoose parses plain objects', () => {
  assert.deepEqual(parseJsonLoose('{"title": "B", "body": "hi"}'), { title: 'B', body: 'hi' })
})

test('parseJsonLoose falls back to raw text when JSON is missing', () => {
  const text = '抱歉，模型没吐 JSON'
  assert.equal(parseJsonLoose(text), text)
})

test('parseJsonLoose handles nested brackets inside strings', () => {
  const text = '[{"hook": "a [b] c"}, {"hook": "x {y} z"}]'
  assert.deepEqual(parseJsonLoose(text), [{ hook: 'a [b] c' }, { hook: 'x {y} z' }])
})

test('userMessage builds a serializable user message', () => {
  const msg = userMessage('hello')
  assert.equal(msg.role, 'user')
  assert.equal(msg.content[0].type, 'text')
  assert.equal(msg.content[0].text, 'hello')
  assert.equal(msg.source.kind, 'user')
  assert.ok(msg.id)
})
