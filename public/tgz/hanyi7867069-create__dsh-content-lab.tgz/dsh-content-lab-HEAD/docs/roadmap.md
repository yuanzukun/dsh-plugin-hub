# Roadmap

## v0.2 — templates

Vertical template packs on top of the existing tools: 美妆号 / 带货号 /
知识付费 / 本地生活。Each pack tunes the system prompts and adds curated
example structures.

## v0.3 — images

Image-prompt generation plus optional AI image output for 小红书 posts
(requires an image API key, charged per call).

## v0.4 — scheduling

Batch generation on a schedule (DSH cron support) and a weekly content
calendar file export.
