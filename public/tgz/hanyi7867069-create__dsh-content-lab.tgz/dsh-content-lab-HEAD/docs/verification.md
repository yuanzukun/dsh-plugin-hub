# Local verification notes

Verified 2026-08-17 against `dsh 0.1.0-rc.6` with a real DeepSeek API key.

1. `dsh plugin --profile web add ./dsh-content-lab` — installs.
2. `dsh --profile web --dump-config` — shows the `# == dsh-content-lab` layer.
3. `dsh --profile web --port 3091` — boots, no console errors.
4. End-to-end in the Web UI:
   - `content_topic_generator` returned 3 structured topics (tool call 10.7s).
   - `content_post_writer` returned a full 小红书 note with hashtags.
5. `node --test` — 5/5 passing for the JSON parser and message builder.
6. `npm pack` produces the release tarball.

## Gotchas found along the way

- The built-in DeepSeek adapter's provider route is `deepseek-official`, not
  `deepseek` — the constant lives in `llm-deepseek` source, not the docs.
- An LLM stream's `finish` chunk carries `reason` as an object
  (`{ kind: 'error', failure }`), not a string; compare `reason.kind`.
- The model often wraps JSON output in fences or adds prose; `parseJsonLoose`
  extracts the first balanced JSON value and falls back to raw text.
