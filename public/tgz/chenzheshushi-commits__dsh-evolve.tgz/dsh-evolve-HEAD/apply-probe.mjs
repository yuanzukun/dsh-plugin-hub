// Host-instance apply() probe for dsh-evolve v0.3.0.
// Drives apply(ctx, cfg) with a record-only mock ctx that mimics the host's
// cordis service surface (storageDomain, tools, systemPrompt, llm, on/effect/get),
// then asserts every tool/section/hook the plugin promises actually registers.
// This is the reliable verification per the dsh skill (headless --patch boot has
// a storageDomain race that can silently skip the plugin; a mock ctx does not).
// Run: ~/.local/node22/bin/node apply-probe.mjs
import assert from 'node:assert';
import { mkdtempSync, rmSync, existsSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const home = mkdtempSync(join(tmpdir(), 'evolve-apply-'));
process.env.DSH_HOME = home; // resolveDshHome() -> this temp dir

// ── minimal in-memory storage-domain table (put/get/delete/entries/size) ──────
function makeTable() {
  const m = new Map();
  return {
    put(k, v) { m.set(k, v); return true; },
    get(k) { return m.get(k); },
    delete(k) { return m.delete(k); },
    entries() { return [...m.entries()]; },
    get size() { return m.size; },
  };
}
const openedDomains = new Map();
function makeDomain() {
  const tables = new Map();
  return { table(n) { if (!tables.has(n)) tables.set(n, makeTable()); return tables.get(n); }, close() {} };
}

// ── record-only mock ctx (captures every registration) ────────────────────────
const registered = { tools: [], sections: [], hooks: [], effects: 0, childPlugins: [], routes: [], routeObjects: [] };
const ctx = {
  logger: { info() {}, warn() {}, error() {} },
  storageDomain: {
    get: (name) => openedDomains.get(name),
    open: async (domainDecl) => { const d = makeDomain(); openedDomains.set(domainDecl.name, d); return d; },
  },
  tools: {
    register: (tool) => { registered.tools.push(tool.name); },
    get: () => undefined,
  },
  systemPrompt: {
    section: (s) => { registered.sections.push(s.name); },
    context() {}, variable() {},
  },
  on: (evt) => { registered.hooks.push(evt); },
  effect: () => { registered.effects += 1; },
  get: () => ({ currentInitiator: () => undefined }),
  // llm service (inject lists it as of v0.3.0). Not exercised at apply() time.
  llm: { stream: async function* () { /* not called at load */ } },
  // ctx.plugin: record child plugins. Fire a child's apply immediately only if
  // its declared inject deps are all present on this mock ctx (mimics cordis
  // resolving deps). webServer is present; settings is not -> routes child runs,
  // settings child defers (never runs here) — exactly the headless-vs-web split.
  plugin(child, cfg2) {
    registered.childPlugins.push(child?.name ?? '(anon)');
    const deps = child?.inject ?? [];
    const satisfied = deps.every((d) => ctx[d] !== undefined);
    if (satisfied && typeof child?.apply === 'function') { void child.apply(ctx, cfg2); }
  },
  // webServer present (web profile). Records registered route paths AND the
  // route objects, so a route can be driven for real (see the refusal-log
  // assertion below).
  webServer: { register: (route) => { registered.routes.push(route.path); registered.routeObjects.push(route); return () => {}; } },
};

const mod = await import('./lib/index.js');
await mod.apply(ctx, {}); // must NOT throw

// ── assert the full v0.3.0 surface ────────────────────────────────────────────
const expectTools = [
  'memory_remember', 'memory_recall', 'memory_index', 'memory_confirm', 'memory_auto_review', 'memory_profile', 'memory_budget', 'memory_promote', 'memory_forget',
  'crystallize_skill', 'refine_skill', 'skill_curator', 'archive_skill', 'restore_skill',
  'memory_stats', 'skill_stats', 'skill_rollback', 'memory_confirm_batch',
  'converge_skill', 'fold_skill', 'skill_style', 'evolve_maintain',
];
for (const t of expectTools) assert.ok(registered.tools.includes(t), `tool registered: ${t}`);
assert.equal(registered.tools.length, expectTools.length, `exactly ${expectTools.length} tools (got ${registered.tools.length}: ${registered.tools.join(',')})`);
assert.ok(registered.sections.includes('evolve-protocol'), 'system-prompt section registered');

// hooks: pre-step recall, agent/error lessonize, and TWO session/event listeners
// (tool/call usage tracking + turn/end crystallize/refine/curate).
const sessionEventHooks = registered.hooks.filter((h) => h === 'session/event').length;
assert.ok(registered.hooks.includes('agent/pre-step'), 'agent/pre-step hook');
assert.ok(registered.hooks.includes('agent/error'), 'agent/error hook');
assert.ok(sessionEventHooks >= 2, `>=2 session/event hooks (usage + turn/end); got ${sessionEventHooks}`);

// storage domain was opened with the schemastery-legal name.
assert.ok(openedDomains.has('evolve_memory'), 'evolve_memory storage domain opened');

// archive dir is created OUTSIDE the watched skills root.
assert.ok(existsSync(join(home, 'evolve-workspace', 'archived-skills')), 'archive dir scaffolded outside skills root');
assert.ok(existsSync(join(home, 'skills')), 'skills dir scaffolded');

// v0.3.0 web layer: two child plugins declared; routes child (inject webServer,
// present here) registered both control-plane routes; settings child (inject
// settings, absent here) correctly deferred and did NOT run.
assert.ok(registered.childPlugins.includes('dsh-evolve-web-routes'), 'web-routes child plugin declared');
assert.ok(registered.childPlugins.includes('dsh-evolve-web-settings'), 'web-settings child plugin declared');
assert.ok(registered.routes.includes('/api/evolve/state'), 'route /api/evolve/state registered (webServer present)');
assert.ok(registered.routes.includes('/api/evolve/action'), 'route /api/evolve/action registered (webServer present)');
// v0.4.2 prune routes
assert.ok(registered.routes.includes('/api/evolve/prune'), 'route /api/evolve/prune registered');
assert.ok(registered.routes.includes('/api/evolve/prune/preview'), 'route /api/evolve/prune/preview registered');
assert.ok(registered.routes.includes('/api/evolve/prune/execute'), 'route /api/evolve/prune/execute registered');
assert.ok(registered.routes.includes('/api/evolve/proposals'), 'proposal list route registered');
assert.ok(registered.routes.includes('/api/evolve/proposals/'), 'proposal prefix action route registered');
assert.ok(registered.routes.includes('/api/evolve/capability/mint'), 'capability mint route registered');
assert.ok(registered.routes.includes('/api/evolve/quarantine'), 'quarantine list route registered');
assert.ok(registered.routes.includes('/api/evolve/quarantine/'), 'quarantine action route registered');
assert.ok(registered.routes.includes('/api/evolve/memory/discard'));
assert.ok(registered.routes.includes('/api/evolve/memory/restore-rejected'));
// v0.6.0 skill operations + operator resolution.
assert.ok(registered.routes.includes('/api/evolve/skills/archives'), 'archive list route registered');
assert.ok(registered.routes.includes('/api/evolve/skills/'), 'skill ops action route registered');
assert.ok(registered.routes.includes('/api/evolve/operations'), 'frozen operation list route registered');
assert.ok(registered.routes.includes('/api/evolve/operations/'), 'operation resolve route registered');
// Pinned as an exact SET, not a count. A count catches an accidental addition but
// says nothing about which route appeared, and it silently passes when one route
// is removed while another is added -- the case where a privileged endpoint could
// go missing unnoticed.
assert.deepEqual([...registered.routes].sort(), [
  '/api/evolve/action',
  '/api/evolve/capability/mint',
  '/api/evolve/memory/discard',
  '/api/evolve/memory/restore-rejected',
  '/api/evolve/operations',
  '/api/evolve/operations/',
  '/api/evolve/proposals',
  '/api/evolve/proposals/',
  '/api/evolve/prune',
  '/api/evolve/prune/execute',
  '/api/evolve/prune/preview',
  '/api/evolve/quarantine',
  '/api/evolve/quarantine/',
  '/api/evolve/skills/',
  '/api/evolve/skills/archives',
  '/api/evolve/state',
].sort(), 'the registered route set must match exactly');

// ── the refusal log lands in the HARNESS HOME, driven through the real route ──
// v0.8.1 wrote it to $DSH_HOME only, so on a default install (the harness does
// not export that variable to plugin processes) it went NOWHERE. The home is
// now passed down from apply(). This drives the REAL route handler that
// apply() registered, so it pins the wiring end to end — a home that is the
// workspace instead of the harness home would put the log one level wrong.
{
  const actionRoute = registered.routeObjects.find((r) => r.path === '/api/evolve/action');
  assert.ok(actionRoute, 'the action route object was captured');
  const logPath = join(home, 'evolve-guard-debug.log');
  assert.equal(existsSync(logPath), false, 'no refusal log before a refusal happens');
  const res = { statusCode: 0, body: '', writeHead(s) { this.statusCode = s; }, end(b) { this.body = b ?? ''; } };
  await actionRoute.handler({
    method: 'POST',
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:3080', origin: 'dsh-app://evil', 'sec-fetch-site': 'same-origin', 'content-type': 'application/json' },
    [Symbol.asyncIterator]: async function* () { yield Buffer.from(JSON.stringify({ action: 'set-config', idleMinutes: 11 })); },
  }, res);
  assert.equal(res.statusCode, 403, 'a foreign app-scheme origin is refused');
  assert.ok(existsSync(logPath), `the refusal log must land in the harness home: ${logPath}`);
  assert.equal(existsSync(join(home, 'evolve-workspace', 'evolve-guard-debug.log')), false,
    'the log belongs to the harness home, not the plugin workspace');
  const text = readFileSync(logPath, 'utf8');
  assert.match(text, /origin=dsh-app:\/\/evil/, 'and it records the refused origin');
  assert.doesNotMatch(text, /token=/i, 'never a token');
  console.log('  refusal log ->', logPath, '(in the harness home, via the real route)');
}

rmSync(home, { recursive: true, force: true });
console.log('OK apply() probe:');
console.log('  tools    =', registered.tools.join(', '));
console.log('  sections =', registered.sections.join(', '));
console.log('  hooks    =', registered.hooks.join(', '), `(session/event x${sessionEventHooks})`);
console.log('  children =', registered.childPlugins.join(', '));
console.log('  routes   =', registered.routes.join(', '));
console.log('\nAPPLY PROBE PASSED');
