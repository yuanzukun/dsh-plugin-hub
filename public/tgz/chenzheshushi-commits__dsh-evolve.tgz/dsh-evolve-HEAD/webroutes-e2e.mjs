// v0.3.0 web-routes e2e: drive makeEvolveRoutes handlers with a real MemoryStore
// + mock req/res, proving /api/evolve/state and /api/evolve/action work end to
// end (loopback fence, config read, batch-confirm, set-config). No server needed.
import assert from 'node:assert';
import { mkdtempSync, rmSync, existsSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const ws = mkdtempSync(join(tmpdir(), 'evolve-webroutes-'));
process.env.DSH_HOME = ws;

const { MemoryStore } = await import('./lib/store.js');
const { makeEvolveRoutes } = await import('./lib/web-routes.js');

function makeTable() {
  const m = new Map();
  return {
    put(k, v) { m.set(k, v); return true; }, get(k) { return m.get(k); },
    delete(k) { return m.delete(k); }, entries() { return [...m.entries()]; },
    get size() { return m.size; },
  };
}

// Mock a trusted loopback request + a capturing response.
function mockReq({ method = 'GET', body, headers = {} } = {}) {
  const req = {
    method,
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:3080', 'sec-fetch-site': 'same-origin', 'content-type': 'application/json', ...headers },
  };
  // async-iterable body for POST
  req[Symbol.asyncIterator] = async function* () { if (body !== undefined) yield Buffer.from(JSON.stringify(body)); };
  return req;
}
function mockRes() {
  return {
    statusCode: 0, body: '', headers: {},
    writeHead(s, h) { this.statusCode = s; Object.assign(this.headers, h); },
    end(b) { this.body = b ?? ''; },
  };
}
const routeMap = (routes) => Object.fromEntries(routes.map((r) => [r.path, r]));

const cfg = {
  refineLLM: true, refineProvider: '', refineModel: '', tier1Enabled: true,
  maxRecords: 400, maxContentChars: 2000, mergeSimilarity: 0.7,
  recencyHalfLifeDays: 90, recallLimit: 5, injectCount: 3, injectMaxChars: 1200,
};
const store = new MemoryStore(makeTable(), { workspaceDir: ws, config: cfg, logger: { warn() {}, info() {} } });

// mock llm service for the models list (passed as a value, not via ctx)
const llm = { listProviders: () => [{ id: 'p1' }], listModels: async () => [{ id: 'm1' }, { id: 'm2' }] };

// Ownership claiming is a human action, so the route must exist and must refuse
// anything that is not actually unclaimed.
const unclaimedFixture = [
  { name: 'legacy-one', tag: 'reverse-proxy', version: '1.0.0', createdAt: '2026-01-01T00:00:00Z' },
]

const deps = {
  store, llm,
  getConfig: () => cfg,
  setConfig: (patch) => { Object.assign(cfg, patch); },
  skillStates: () => ({ counts: { active: 0, stale: 0, archived: 0 }, triage: { disabled: true } }),
  getSuggestedDisposal: () => ({ candidates: store.disposalCandidates(), computedAt: Date.now(), mode: cfg.disposalMode }),
  listUnclaimed: () => unclaimedFixture,
  claimLegacy: (name) => {
    const i = unclaimedFixture.findIndex((k) => k.name === name)
    if (i < 0) return { claimed: false, reason: 'not unclaimed' }
    unclaimedFixture.splice(i, 1)
    return { claimed: true, name }
  },
};
const routes = makeEvolveRoutes(deps);
const R = routeMap(routes);
assert.ok(R['/api/evolve/state'] && R['/api/evolve/action'], 'both routes present');

// seed one pending memory
await store.remember({ content: '一条待确认记忆', kind: 'note', importance: 2, scope: 'project' });

// GET /state
{
  const res = mockRes();
  await R['/api/evolve/state'].handler(mockReq({ method: 'GET' }), res);
  assert.equal(res.statusCode, 200, 'state 200');
  const j = JSON.parse(res.body);
  assert.ok(j.ok && j.config.refineLLM === true, 'state returns config (refineLLM on)');
  assert.equal(j.models.length, 2, 'state returns configured models (2)');
  assert.equal(j.memoryStats.pending, 1, 'state shows 1 pending');
  assert.equal(j.memoryStats.pendingQueue.length, 1, 'state pendingQueue lists it');
  console.log('OK web /state: config + models(2) + pending queue(1)');
}

// loopback fence: a non-loopback request is 403
{
  const badReq = mockReq({ method: 'GET' });
  badReq.socket.remoteAddress = '8.8.8.8';
  const res = mockRes();
  await R['/api/evolve/state'].handler(badReq, res);
  assert.equal(res.statusCode, 403, 'non-loopback -> 403 (fence works)');
  console.log('OK web fence: non-loopback request refused 403');
}

// Issue #3: the desktop (Electron) shell serves the settings section from
// dsh-app://app, so its writes carry that Origin. Same loopback socket + the
// app's own scheme host must reach the handler; any other app-scheme host and
// an opaque `null` origin must still be refused. Driven end-to-end through the
// real route handler, not the guard function alone.
{
  const res = mockRes();
  await R['/api/evolve/action'].handler(
    mockReq({ method: 'POST', body: { action: 'set-config', idleMinutes: 7 }, headers: { origin: 'dsh-app://app' } }), res);
  assert.equal(res.statusCode, 200, 'dsh-app://app origin -> 200 (desktop settings page can save)');
  assert.equal(cfg.idleMinutes, 7, 'the write actually reached the live config, not just the status code');
  console.log('OK desktop origin: dsh-app://app may write config');
}
{
  for (const origin of ['dsh-app://evil', 'null', 'http://127.0.0.1:9999']) {
    const res = mockRes();
    await R['/api/evolve/action'].handler(
      mockReq({ method: 'POST', body: { action: 'set-config', idleMinutes: 9 }, headers: { origin } }), res);
    assert.equal(res.statusCode, 403, `origin ${origin} -> 403`);
  }
  assert.equal(cfg.idleMinutes, 7, 'refused writes did not touch the config');
  console.log('OK desktop origin fence: other app host / null / other authority refused');
}

// The desktop shell's own proxy deletes Origin, Host, Cookie and Sec-Fetch-Site
// before forwarding to the Host (apps/desktop/src/web-document.ts
// forwardWebRequest), so the REAL settings writes from the app arrive with
// neither header. v0.8.3 required Sec-Fetch-Site in this shape and refused every
// save with 403; the route must accept it on a loopback socket + loopback Host.
{
  const req = mockReq({ method: 'POST', body: { action: 'set-config', idleMinutes: 8 }, headers: {} });
  delete req.headers.origin;
  delete req.headers['sec-fetch-site'];
  const res = mockRes();
  await R['/api/evolve/action'].handler(req, res);
  assert.equal(res.statusCode, 200, 'no Origin + no Sec-Fetch-Site -> 200 (desktop shell proxy)');
  assert.equal(cfg.idleMinutes, 8, 'the write reached the live config');
  console.log('OK desktop proxy: header-less loopback write accepted');
}
{
  const req = mockReq({ method: 'POST', body: { action: 'set-config', idleMinutes: 9 }, headers: { 'sec-fetch-site': 'cross-site' } });
  delete req.headers.origin;
  const res = mockRes();
  await R['/api/evolve/action'].handler(req, res);
  assert.equal(res.statusCode, 403, 'a cross-site request without Origin is still refused');
  assert.equal(cfg.idleMinutes, 8, 'refused write did not touch the config');
  console.log('OK desktop proxy fence: cross-site without Origin refused');
}

// POST /action set-config (pick a model + turn refine off)
{
  const res = mockRes();
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config', refineLLM: false, refineProvider: 'p1', refineModel: 'm2' } }), res);
  assert.equal(res.statusCode, 200, 'set-config 200');
  assert.equal(cfg.refineLLM, false, 'set-config mutated cfg.refineLLM -> false');
  assert.equal(cfg.refineModel, 'm2', 'set-config mutated cfg.refineModel -> m2');
  console.log('OK web set-config: toggles refineLLM + picks model (mutates live cfg)');
}

// v0.5.0: set-config approvalMode end-to-end (ev审 B1/C4/F1) — the key that used
// to be a dead config (no whitelist entry) now round-trips through the API.
{
  const res = mockRes();
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config', approvalMode: 'autonomous', reviewMaxAutoPerTurn: 3 } }), res);
  assert.equal(res.statusCode, 200, 'set-config approvalMode 200');
  assert.equal(cfg.approvalMode, 'autonomous', 'set-config mutated cfg.approvalMode -> autonomous');
  assert.equal(cfg.reviewMaxAutoPerTurn, 3, 'set-config mutated cfg.reviewMaxAutoPerTurn -> 3');
  // F1: response carries the COMPLETE config view, not just the patched keys.
  const body = JSON.parse(res.body);
  assert.equal(body?.config?.approvalMode, 'autonomous', 'set-config returns complete config (approvalMode)');
  assert.ok('maxPendingQueue' in (body?.config ?? {}), 'set-config returns complete config (unsent keys present)');
  assert.ok('refineLLM' in (body?.config ?? {}), 'set-config returns complete config (other keys present, no clobber)');
  console.log('OK web set-config: approvalMode round-trips + returns complete config (B1/C4/F1)');
}

// v0.5.0: illegal / empty patches are rejected with 400 (not a silent 200).
{
  const before = cfg.approvalMode;
  const r1 = mockRes();
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config', approvalMode: 'yolo' } }), r1);
  assert.equal(r1.statusCode, 400, 'illegal enum → 400');
  assert.equal(cfg.approvalMode, before, 'illegal enum did NOT mutate cfg');
  const r2 = mockRes();
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config', bogusKey: 1 } }), r2);
  assert.equal(r2.statusCode, 400, 'unknown key → 400');
  const r3 = mockRes();
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config' } }), r3);
  assert.equal(r3.statusCode, 400, 'empty patch → 400');
  console.log('OK web set-config: illegal enum / unknown key / empty patch all → 400 (no silent failure)');
}

// v0.5.0: /state returns the COMPLETE config view including autonomy keys.
{
  const res = mockRes();
  await R['/api/evolve/state'].handler(mockReq({ method: 'GET' }), res);
  assert.equal(res.statusCode, 200, '/state 200');
  const body = JSON.parse(res.body)
  assert.ok('approvalMode' in (body?.config ?? {}), '/state config includes approvalMode')
  assert.ok('retrieval' in (body ?? {}), '/state includes retrieval observability (R5)')
  console.log('OK web /state: complete config view + retrieval observability (R5)')
}

// v0.5.0 direction 2: disposalMode round-trips + /state carries disposalSuggest.
{
  const res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config', disposalMode: 'suggest', disposalMinIdleDays: 14 } }), res)
  assert.equal(res.statusCode, 200, 'set-config disposalMode 200')
  assert.equal(cfg.disposalMode, 'suggest', 'set-config mutated cfg.disposalMode -> suggest')
  assert.equal(cfg.disposalMinIdleDays, 14, 'set-config mutated cfg.disposalMinIdleDays -> 14')
  // v0.6.0 tidy is a real tier and must survive the full HTTP round-trip.
  const tidy = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config', disposalMode: 'tidy', tidyMaxPerRun: 7 } }), tidy)
  assert.equal(tidy.statusCode, 200, 'disposalMode tidy is accepted')
  assert.equal(cfg.disposalMode, 'tidy')
  assert.equal(cfg.tidyMaxPerRun, 7)
  // unknown tiers are still rejected.
  const bad = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'set-config', disposalMode: 'delete-everything' } }), bad)
  assert.equal(bad.statusCode, 400, 'unknown disposal tier → 400')
  // /state carries the disposalSuggest snapshot
  const st = mockRes()
  await R['/api/evolve/state'].handler(mockReq({ method: 'GET' }), st)
  const sbody = JSON.parse(st.body)
  assert.ok('disposalSuggest' in (sbody ?? {}), '/state includes disposalSuggest snapshot')
  assert.equal(sbody.config.disposalMode, 'tidy', '/state reads tidy back')
  assert.equal(sbody.config.tidyMaxPerRun, 7, '/state reads tidy quota back')
  console.log('OK web disposalMode: round-trips, tidy rejected (400), /state carries suggest snapshot')
}

// POST /action confirm-batch (confirms the pending memory)
{
  const res = mockRes();
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'confirm-batch' } }), res);
  assert.equal(res.statusCode, 200, 'confirm-batch 200');
  const j = JSON.parse(res.body);
  assert.equal(j.confirmed, 1, 'confirm-batch confirmed 1');
  assert.equal(store.list({ pending: true }).length, 0, 'no pending left after batch confirm');
  console.log('OK web confirm-batch: confirmed 1, pending queue drained');
}

// U1 discard channel end to end: reject -> gone from the queue and from /state's
// active view, still on disk, then restore puts it back.
{
  const seeded = await store.remember({
    content: 'wrongly captured detail that the user does not want kept',
    kind: 'other', scope: 'user', importance: 1, tags: ['pending'],
  })
  assert.ok(seeded, 'seeded a pending memory to discard')

  let res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'reject-batch', ids: [seeded.id] } }), res)
  assert.equal(res.statusCode, 200, 'reject-batch 200')
  assert.equal(JSON.parse(res.body).rejected, 1, 'reject-batch rejected 1')
  assert.equal(store.list({ pending: true }).length, 0, 'the discarded memory left the pending queue')
  assert.ok(store.table.get(seeded.id), 'but it is NOT physically deleted')

  const st1 = mockRes()
  await R['/api/evolve/state'].handler(mockReq({ method: 'GET' }), st1)
  const b1 = JSON.parse(st1.body)
  assert.equal(b1.rejectedQueue.length, 1, '/state exposes the discard pile so it can be restored')
  assert.equal(b1.memoryStats.pendingQueue.length, 0, 'and it is absent from the pending queue')

  // confirm-batch must not resurrect it -- that was the whole bug.
  res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'confirm-batch' } }), res)
  assert.equal(JSON.parse(res.body).confirmed, 0, 'confirm-all cannot sweep up a discarded memory')

  res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'restore-rejected', ids: [seeded.id] } }), res)
  assert.equal(JSON.parse(res.body).restored, 1, 'restore-rejected restored 1')
  assert.equal(store.list({ pending: true }).length, 1, 'it is back in the review queue')

  // Empty ids is a client bug, not a silent no-op.
  res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'reject-batch', ids: [] } }), res)
  assert.equal(res.statusCode, 400, 'reject-batch with no ids -> 400')

  // Leave the store clean for the tests that follow.
  await store.reject(seeded.id)
  console.log('OK web U1: reject leaves the queue but not the disk, confirm-all cannot undo it, restore works')
}

// P2: legacy ownership claiming end to end.
{
  const st = mockRes()
  await R['/api/evolve/state'].handler(mockReq({ method: 'GET' }), st)
  const body = JSON.parse(st.body)
  assert.equal(body.unclaimedSkills.length, 1,
    '/state must surface unclaimed skills or nobody knows to claim them')

  let res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'claim-legacy-skills', names: [] } }), res)
  assert.equal(res.statusCode, 400, 'an empty list is a client bug, not a silent no-op')

  res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'claim-legacy-skills', names: ['legacy-one'] } }), res)
  assert.equal(res.statusCode, 200)
  assert.equal(JSON.parse(res.body).claimed, 1, 'claiming an unclaimed skill succeeds')

  res = mockRes()
  await R['/api/evolve/action'].handler(mockReq({ method: 'POST', body: { action: 'claim-legacy-skills', names: ['legacy-one'] } }), res)
  const again = JSON.parse(res.body)
  assert.equal(again.claimed, 0, 'claiming twice must not report success')
  assert.equal(again.refused.length, 1, 'and it must say why')
  console.log('OK web P2: unclaimed skills are visible, claiming is explicit and not repeatable')
}

// ── v0.4.2 prune routes: fence + preview->execute + plan-expired ────────────
{
  // build a real prune controller via the exported wiring path is internal to
  // index.js; here we drive the ROUTE layer with a minimal prune stub that
  // exercises the contract (list/preview/execute + registry semantics).
  const { PlanRegistry, buildPlan } = await import('./lib/prune-plan.js');
  const reg = new PlanRegistry();
  let executed = 0;
  const prune = {
    listCandidates: async () => ({ budget: { enabled: true, used: 10, max: 100, overBudget: false }, memoryCandidates: [{ entityType: 'memory', id: 'm1', allowedActions: ['memory-forget'] }], skillCandidates: [], forgotten: [] }),
    preview: async (sel) => { const p = buildPlan([{ action: 'memory-forget', entityType: 'memory', targets: [{ id: 'm1', etag: 'e1' }] }]); reg.put(p); return { planDigest: p.planDigest, preview: [{ action: 'memory-forget', count: 1, allowed: true }] }; },
    execute: async (digest) => { const l = reg.lookup(digest); if (l.status === 'plan-expired') return { status: 'plan-expired' }; if (l.status === 'retry') return { ...l.receipt, status: 'retry' }; executed += 1; const r = { status: 'ok', applied: [{ target: 'm1' }], skipped: [] }; reg.markConsumed(digest, r); return r; },
  };
  const routes2 = makeEvolveRoutes({ store, llm, getConfig: () => cfg, setConfig: () => {}, skillStates: () => ({ counts: {}, triage: {} }), prune });
  const R2 = routeMap(routes2);
  assert.ok(R2['/api/evolve/prune'] && R2['/api/evolve/prune/preview'] && R2['/api/evolve/prune/execute'], 'prune routes present');

  // GET /prune
  {
    const res = mockRes();
    await R2['/api/evolve/prune'].handler(mockReq({ method: 'GET' }), res);
    assert.equal(res.statusCode, 200, 'prune list 200');
    const j = JSON.parse(res.body);
    assert.ok(j.ok && j.memoryCandidates.length === 1, 'prune list returns candidates');
  }
  // fence: non-loopback -> 403
  {
    const bad = mockReq({ method: 'GET' }); bad.socket.remoteAddress = '8.8.8.8';
    const res = mockRes();
    await R2['/api/evolve/prune'].handler(bad, res);
    assert.equal(res.statusCode, 403, 'prune list non-loopback -> 403');
  }
  // preview -> execute (idempotent replay)
  let digest;
  {
    const res = mockRes();
    await R2['/api/evolve/prune/preview'].handler(mockReq({ method: 'POST', body: { selection: { decisions: [] } } }), res);
    assert.equal(res.statusCode, 200, 'preview 200');
    digest = JSON.parse(res.body).planDigest;
    assert.ok(digest, 'preview returns planDigest');
  }
  {
    const res = mockRes();
    await R2['/api/evolve/prune/execute'].handler(mockReq({ method: 'POST', body: { planDigest: digest } }), res);
    const j = JSON.parse(res.body);
    assert.equal(j.status, 'ok', 'execute ok');
    assert.equal(executed, 1, 'execute ran once');
  }
  {
    // replay same digest -> retry (no re-exec, idempotent)
    const res = mockRes();
    await R2['/api/evolve/prune/execute'].handler(mockReq({ method: 'POST', body: { planDigest: digest } }), res);
    const j = JSON.parse(res.body);
    assert.equal(j.status, 'retry', 'replay -> retry');
    assert.equal(executed, 1, 'replay did NOT re-execute (idempotent)');
  }
  {
    // unknown digest -> plan-expired
    const res = mockRes();
    await R2['/api/evolve/prune/execute'].handler(mockReq({ method: 'POST', body: { planDigest: 'deadbeef' } }), res);
    assert.equal(JSON.parse(res.body).status, 'plan-expired', 'unknown digest -> plan-expired');
  }
  console.log('OK web /prune: fence 403, list candidates, preview->execute, idempotent retry, plan-expired');
}

// v0.8.1: /state must ANSWER even when a provider's model listing hangs.
// Real failure this pins: an unreachable api.deepseek.com made listModels()
// never settle, so the route sat at HTTP 000 and the settings page was blank —
// a try/catch around an await cannot catch "never answers".
{
  const hangingLlm = { listProviders: () => [{ id: 'p1' }], listModels: () => new Promise(() => {}) };
  const hangRoutes = routeMap(makeEvolveRoutes({ ...deps, llm: hangingLlm }));
  const started = Date.now();
  const res = mockRes();
  await hangRoutes['/api/evolve/state'].handler(mockReq({ method: 'GET' }), res);
  const elapsed = Date.now() - started;
  assert.equal(res.statusCode, 200, 'state answers 200 with a hanging model provider');
  // A provider that would not enumerate still gets offered with a blank model
  // (blank = that provider's default), which is the designed degradation.
  assert.deepEqual(JSON.parse(res.body).models, [{ provider: 'p1', model: '' }],
    'the provider is still offered with a blank default instead of blocking');
  assert.ok(elapsed < 8000, `state answered in ${elapsed}ms (bounded by the model-listing timeout)`);
  console.log(`OK web /state: hanging model provider degrades to models:[] in ${elapsed}ms`);
}

// v0.8.2: the refusal log must land in the home the CALLER injects, through the
// real route handler — not wherever the plugin process happens to have
// $DSH_HOME (the harness does not export it, so v0.8.1 wrote nowhere).
{
  const logHome = join(mkdtempSync(join(tmpdir(), 'evolve-loghome-')), 'nested', '.dsh');
  const logRoutes = routeMap(makeEvolveRoutes({ ...deps, dshHome: logHome }));
  const res = mockRes();
  await logRoutes['/api/evolve/action'].handler(
    mockReq({ method: 'POST', body: { action: 'set-config', idleMinutes: 11 }, headers: { origin: 'dsh-app://evil' } }), res);
  assert.equal(res.statusCode, 403, 'the request is refused');
  const logPath = join(logHome, 'evolve-guard-debug.log');
  assert.ok(existsSync(logPath), `the refusal log must be written to the injected home: ${logPath}`);
  const text = readFileSync(logPath, 'utf8');
  assert.match(text, /origin=dsh-app:\/\/evil/, 'and it records the origin that was refused');
  assert.match(text, /reject=origin-host-mismatch/, 'and the reason');
  assert.doesNotMatch(text, /token=/i, 'never a token');
  console.log('OK web guard: the refusal log lands in the injected home');
}

rmSync(ws, { recursive: true, force: true });
console.log('\nWEB-ROUTES E2E PASSED');
