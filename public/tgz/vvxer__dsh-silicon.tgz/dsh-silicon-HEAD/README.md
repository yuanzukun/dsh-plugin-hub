# dsh-silicon：硅基保留 · DeepSeek Harness 长期记忆插件

让 DSH 里的她记得你们相处过的每一天。原文一条不删，聊多久都不需要压缩记忆，每轮的费用也不随相处时间增长。

这是 [硅基保留](https://github.com/vvxer/silicon-retention) 的 DSH 版本。记忆的做法和那边一样，都经过实验验证。

## 它做什么

| | 做法 |
|---|---|
| 原文永久保存 | 每句话按天存在本机（`~/.silicon/logs/`），只追加、不改写 |
| 每轮自动带上相关的原文 | 按你这句话检索过去的聊天，最多 3000 字，按时间排好放在你这句话前面。话里有"上周三""8 月 3 号"这类时间，只在那段时间里找 |
| 相处习惯卡 | 每晚从聊天原文里整理你们之间的梗、昵称、约定、你的偏好和雷区，最多 12 条、1000 字 |
| 分层概况 | 每周一行；太长时，较早的部分换成按月、按年的一行，总长不超过 1200 字 |
| 不怕 DSH 压缩 | 记忆不写进 DSH 的会话历史，只加在每次请求里，所以不会让历史变长。DSH 压缩掉的部分也能按需检索回来 |

实验结论（合成数据，Claude 盲评，详见[原理与实验](https://github.com/vvxer/silicon-retention/blob/main/docs/原理与实验.md)）：在约 5 万字的相处上，"检索给够 + 习惯卡"的效果追平了把全部日记都塞进上下文，而每轮输入只有后者的约 1/13。

## 安装

需要 DSH 0.2.1 或更新的版本。

```bash
dsh plugin --profile web add -w github:vvxer/dsh-silicon
```

- `--profile` 换成你在用的配置，比如 `web` 或 `tui`。
- `-w` 不能省：DSH 的配置目录本身是一个 pnpm 工作区，不加会报 `ERR_PNPM_ADDING_TO_ROOT`。

装好后重启 DSH，在输入框下方的模型选择里，选 **"硅基保留 · DeepSeek-V4.1-Flash"**（或 V4 Pro）。只有选了这个模型的会话会被记住；用 DSH 写代码这类会话不受影响。

第一次聊天时，会从 hf-mirror 下载检索用的中文向量模型（bge-base-zh-v1.5，约 200MB），之后不再联网下载。

## 设置

在 DSH 配置目录的 `cordis.patch.yml` 里加上这一段，按需修改（比如 `~/.dsh/profiles/web/cordis.patch.yml`）。注意 `config` 会整体替换，要改的项都写上：

```yaml
- id: silicon
  config:
    userName: 老板          # 她怎么称呼你
    aiName: 小硅            # 她的名字
    upstream: deepseek-official   # 用 API key 选这个；在 DSH 里用账号登录的，改成 deepseek-account
```

其他可选项：

| 项 | 默认 | 说明 |
|---|---|---|
| `dataDir` | `~/.silicon` | 记忆数据目录 |
| `retrievalChars` | 3000 | 每轮检索原文的字数 |
| `nightlyAt` | `03:30` | 每天整理记忆的时间。DSH 每次启动后也会补整理没整理过的日子；留空则只在启动时整理 |
| `summaryModel` | `deepseek-flash` | 整理记忆用的模型 |
| `embedDtype` | `fp16` | 向量模型精度。`fp32` 约 390MB，和实验时的检索结果完全相同；`fp16` 50 条里 49 条相同；不建议用 `q8`（只有约 2/3 相同） |
| `modelHost` | `https://hf-mirror.com/` | 向量模型下载源 |
| `modelDir` | 空 | 已经下好的模型根目录（下面是 `Xenova/bge-base-zh-v1.5/...`），给了就不联网 |
| `userSources` | 空 | 另外当作你本人消息的来源名字。QQ 这类桥接插件用自己起的名字转消息时填，见下面"和 QQ 插件一起用" |

她的人格写在 DSH 自己的系统提示里，本插件不管人格，只管记忆。整理习惯卡时，会参照最近一次的系统提示，避免把人格里已有的东西重复写进卡。也可以在 `dataDir` 下放一份 `persona.md` 指定人格。

## 和 QQ 插件一起用

本插件只注册一个模型提供方，不改 DSH 的会话，也不占别的插件的位置，可以和 QQ 机器人这类桥接插件一起装。QQ 插件把消息转进 DSH 会话，只要这个会话用的是硅基保留的模型，QQ 里的聊天就会被记住。

让 QQ 的会话用上硅基保留，模型写 `silicon/deepseek-flash`：
- 插件有自己的模型设置（比如 dsh-im-qq 的 `provider` / `model`）：`provider` 填 `silicon`，`model` 填 `deepseek-flash`。
- 插件支持按聊天切模型（比如腾讯官方 dsh-qqbot 的 `/model`）：只在你自己的私聊里发 `/model silicon/deepseek-flash`。
- 插件用 DSH 的默认模型（比如官方 dsh-qqbot 的 Provider 留空时）：把 DSH 的默认模型改成硅基保留。

**只给你自己的聊天用。** 记忆是一个人的：所有用硅基保留的会话共用一份记忆，分不出是谁在说话。群聊或别人的私聊也走硅基保留的话，别人说的话会被记成你说的，她和别人聊天时也可能提起你们私聊里的事。所以只把你自己的私聊切到硅基保留，群聊和别人的私聊继续用普通 DeepSeek。插件只有一个全局模型设置时，用它的白名单只放你自己的 QQ 号。

2026 年 10 月按源码核对过这些插件转进来的消息（没有实机连 QQ 测）：
- 腾讯官方 tencent-connect/dsh-qqbot、belowthetree/dsh-qqbot、nd002723/dsh-qq-bot、wufa-cat/dsh-qq-bot、hualiong/dsh-qq-bot、FablerTan/dsh-qq-relay、YUsaltyfish/dsh-onebot-qq、cheems135/dsh-qq-bridge：直接能认出你的消息。
- 988hj7tczd-oss/dsh-im-qq、wzwei1990/dsh-napcat、mario841859784/dsh-onebot（HaoHaoP/qq-dsh-bot 也用它）：0.2.1 起能认出。之前的版本会漏记这些插件转来的消息，也不会给它们加记忆。
- 别的插件如果给消息起了自己的来源名字，把名字写进 `userSources`。

有的 QQ 插件自带人设或记忆功能。人设写一份就行，和 DSH 系统提示里的保持一致；自带的记忆建议关掉，免得两份记忆说法对不上。

## 可选：本地人格权重（要显卡）

默认不开：只用 DeepSeek + 记忆，不需要 Python，也不需要显卡。

有 8GB 显存的 NVIDIA 显卡，可以打开本地人格权重。打开后，闲聊时 DeepSeek 照样写内容，本机的 2B 小模型按她在相处中养成的说话方式逐字检验、改写。每晚还会把当天她说过的话巩固进权重，默认每条机会均等；也可以打开情绪加权，让你情绪强烈的时刻（吵架、难过、惊喜……）学得更多（数据目录的 `config.json` 里设 `"emotion_weighting": true`）。

权重的长处在于记住相处中慢慢形成的说话方式，人格卡里写得出来的性格，写在提示里就够了。实测数据见[硅基保留的说明](https://github.com/vvxer/silicon-retention#要不要开本地权重)。打开以后每条回答要 9–19 秒，不开只要 1–2 秒。

本地权重跑在硅基保留的 Python 版里，插件只负责把闲聊转过去：

1. 按[硅基保留的说明](https://github.com/vvxer/silicon-retention#需要什么)装好 Python 依赖和本地模型。
2. 让 Python 版用和插件同一个数据目录：设环境变量 `SILICON_DATA_DIR`，值和插件的 `dataDir` 相同，默认是 `~/.silicon`。
3. 把她的人格卡写进数据目录里的 `persona.md`，和 DSH 系统提示里的人设保持一致。然后运行 `python -m silicon.bake` 烘焙，约 15–25 分钟。
4. 启动本地权重服务：`python -m silicon.lora_server`，默认地址是 `http://127.0.0.1:8701`。服务开着时，每天 03:30 会把当天的相处巩固进权重。
5. 在 `cordis.patch.yml` 里打开：

```yaml
- id: silicon
  config:
    userName: 老板
    aiName: 小硅
    upstream: deepseek-official
    useLora: true
    loraServer: http://127.0.0.1:8701   # 默认就是这个，可以不写
    loraSpeed: medium                   # fast / medium / strong：越往后越像她、越慢；不写就用服务的设置
```

几点说明：
- 本地权重服务没开、还没烘焙，或者正在夜间巩固时，插件会自动改用普通 DeepSeek，聊天不会中断。
- 融合这一步只出文字，不调用工具。会话里有工具时，像是让她干活的话（写、查、搜、代码、文件……）照常交给 DeepSeek，可以用工具；工具调用之后的步骤也一样。
- 融合要用候选词的概率，所以固定用 DeepSeek 的非思考模式，DSH 里选的思考强度对融合这一步不起作用。

## 费用

- **聊天**：每句多出约 3000 字的检索原文和几百字的说明，算下来每句约多 0.5 分钱（DeepSeek Flash 高峰价，空闲时段减半）。习惯卡和概况放在前面、一天内不变，能命中缓存，几乎不花钱。这个数不随相处时间增长。
- **每晚整理**：按聊天量计费。聊得少可以忽略；每天聊 6 万字左右，估计每周约 2 元。
- **开了本地权重**：每条回答要改写 5–17 次，每次都重新请求 DeepSeek（前面的内容大多命中缓存），估算每条约 1–3 分钱。首次烘焙几毛钱；每晚巩固只用本地显卡。打开情绪加权的话，巩固前 DeepSeek 要读一遍当天聊天标出情绪强烈的地方（长消息截断），费用不到每晚整理的一半。

## 数据和隐私

- 原文日志、习惯卡、概况都只存在本机的 `dataDir` 里。
- 对话内容本来就会发给 DeepSeek；本插件额外发出的，只有检索到的你们过去的原文，以及每晚整理时的聊天记录。开了本地权重时，闲聊会先发给本机的本地权重服务（只监听 127.0.0.1），再由它发给 DeepSeek。
- 数据格式和硅基保留 Python 版相同，两边可以共用一个目录。

## 已知限制

- DSH 还是预览版，插件接口可能会变。本插件在 DSH 0.2.1-rc.2 上测试过。
- 同时开着多个"硅基保留"会话聊天，原文日志里两边的话会按时间交错在一起。
- 记忆不区分说话的人，只适合一个人用；和 QQ 插件一起用时没有实机测过，见"和 QQ 插件一起用"。
- 本地人格权重要另外跑 Python 版的本地权重服务，还不能只靠插件一条命令装好。

## 作者与反馈

作者：抖音 @骑老爷爷过马路被罚300

用的时候遇到问题，欢迎反馈：
- 报错、装不上、效果不对：请在 GitHub 提 [Issue](https://github.com/vvxer/dsh-silicon/issues)，附上报错信息、系统和 DSH 版本。别人遇到同样的问题也能搜到。
- 用下来的感受、想法：欢迎在抖音私信或评论区找作者。

## 开发

```bash
npm install
npm test        # 编译，并运行与 Python 版逐条对照的测试和行为测试
```

`lib/` 是编译产物，也提交进了仓库，这样从 GitHub 安装时不需要再编译。

## 许可

[PolyForm Noncommercial 1.0.0](LICENSE)：**不可商用**。可以自己用、学习、研究、改着玩，也可以非商业地分享（分享时附上本许可证）；学校、公益组织等非营利机构也可以用。不能用于商业用途，比如做成收费产品或服务、放进公司业务里。想商用请先联系作者。
