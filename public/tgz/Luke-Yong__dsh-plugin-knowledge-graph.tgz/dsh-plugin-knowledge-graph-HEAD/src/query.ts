// ── Knowledge Graph Query ──
// Adapted from H (server/agent.ts runGraphQuery). Runs structural/dependency
// queries against an in-memory KnowledgeGraph instead of re-parsing a .kg file.

import { canParseExports, type KnowledgeGraph } from "./knowledgeGraph.js";

interface IndexedNode {
  type: string;
  parentId: string;
  name: string;
  kind: string;
}

export function runGraphQuery(graph: KnowledgeGraph, query: string): string {
  const nodes = new Map<string, IndexedNode>();
  for (const [id, n] of graph.nodes) {
    nodes.set(id, {
      type: n.type,
      parentId: n.parentId,
      name: n.name,
      kind: n.ext, // file: extension; symbol: kind
    });
  }

  // ── Build O(1) indexes ──
  const fromIndex = new Map<string, Array<{ to: string; type: string }>>();
  const toIndex = new Map<string, string[]>();
  function indexEdge(fromId: string, toId: string, type: string): void {
    const fk = type + "|" + fromId;
    let arr = fromIndex.get(fk);
    if (!arr) { arr = []; fromIndex.set(fk, arr); }
    arr.push({ to: toId, type });
    const tk = type + "|" + toId;
    let tarr = toIndex.get(tk);
    if (!tarr) { tarr = []; toIndex.set(tk, tarr); }
    tarr.push(fromId);
  }
  for (const edge of graph.edges) {
    indexEdge(edge.fromId, edge.toId, edge.type);
  }

  // ── Pre-resolve all paths (recursive walk, cached) ──
  const pathCache = new Map<string, string>();
  const resolvePath = (id: string): string => {
    const cached = pathCache.get(id);
    if (cached !== undefined) return cached;
    const node = nodes.get(id);
    if (!node) { pathCache.set(id, ""); return ""; }
    if (!node.parentId) { pathCache.set(id, node.name); return node.name; }
    const parentPath = resolvePath(node.parentId);
    const p = parentPath ? parentPath + "/" + node.name : node.name;
    pathCache.set(id, p);
    return p;
  };

  // ── File path lookup (lowercased) ──
  const filePaths = new Map<string, string>();
  for (const [id, node] of nodes) {
    if (node.type === "file") filePaths.set(id, resolvePath(id).toLowerCase());
  }

  // ── Symbol name index ──
  const symbolIndex = new Map<string, Array<{ id: string; parentId: string; name: string; kind: string }>>();
  for (const [id, node] of nodes) {
    if (node.type !== "symbol") continue;
    const key = node.name.toLowerCase();
    let arr = symbolIndex.get(key);
    if (!arr) { arr = []; symbolIndex.set(key, arr); }
    arr.push({ id, parentId: node.parentId, name: node.name, kind: node.kind });
  }

  const qLower = (s: string) => s.toLowerCase();
  const findFileId = (target: string): string | null => {
    const t = qLower(target);
    for (const [id, fpath] of filePaths) {
      if (fpath.includes(t)) return id;
    }
    return null;
  };

  // ── Parse query ──
  const trimmed = query.trim();
  const spaceIdx = trimmed.indexOf(" ");
  const qType = spaceIdx >= 0 ? trimmed.slice(0, spaceIdx).toLowerCase() : trimmed.toLowerCase();
  const qTarget = spaceIdx >= 0 ? trimmed.slice(spaceIdx + 1).trim() : "";

  if (qType === "structure") {
    const dirPaths: string[] = [];
    for (const [id, node] of nodes) {
      if (node.type === "dir" || node.type === "file") dirPaths.push(resolvePath(id));
    }
    dirPaths.sort();
    return `Directory tree (${dirPaths.length} entries):\n${dirPaths.join("\n")}`;
  }

  if (qType === "exports") {
    const fileId = findFileId(qTarget);
    if (!fileId) return `File not found in graph: ${qTarget}`;
    const fileNode = nodes.get(fileId);
    const symEdges = fromIndex.get("EXPORTS|" + fileId) || [];
    if (symEdges.length === 0) {
      const ext = fileNode ? fileNode.kind : "";
      if (canParseExports(ext)) return `${resolvePath(fileId)} exports nothing.`;
      return `${resolvePath(fileId)} exports nothing (no symbol parser for .${ext || "?"} files).`;
    }
    const syms = symEdges.map((e) => {
      const sym = nodes.get(e.to);
      return sym ? `${sym.name}:${sym.kind}` : "?";
    });
    return `${resolvePath(fileId)} exports:\n${syms.join("\n")}`;
  }

  if (qType === "exporters_of") {
    const matches = symbolIndex.get(qLower(qTarget));
    if (!matches || matches.length === 0) return `No symbol named '${qTarget}' found in the graph.`;
    const results = matches.map((s) => `${resolvePath(s.parentId)} → ${s.name}:${s.kind}`);
    return `Files exporting '${qTarget}':\n${results.join("\n")}`;
  }

  if (qType === "imports_of") {
    const fileId = findFileId(qTarget);
    if (!fileId) return `File not found in graph: ${qTarget}`;
    const parts: string[] = [];
    for (const imp of graph.imports || []) {
      if (imp.fromId !== fileId) continue;
      const src = imp.targetFileId ? resolvePath(imp.targetFileId) : imp.module;
      const tag = imp.classification === "local" ? "" : ` [${imp.classification}]`;
      if (imp.names.length === 0) {
        parts.push(`  ${src}${tag}`);
      } else {
        for (const name of imp.names) {
          parts.push(`  ${name.local} from ${src}${tag}`);
        }
      }
    }
    if (parts.length === 0) return `${resolvePath(fileId)} imports nothing.`;
    return `${resolvePath(fileId)} imports:\n${parts.join("\n")}`;
  }

  if (qType === "unused_imports" || qType === "unused") {
    const fileId = findFileId(qTarget);
    if (!fileId) return `File not found in graph: ${qTarget}`;
    const unused: string[] = [];
    for (const imp of graph.imports || []) {
      if (imp.fromId !== fileId) continue;
      for (const name of imp.unused) unused.push(`  ${name} (from ${imp.module})`);
    }
    if (unused.length === 0) return `${resolvePath(fileId)} has no unused imports.`;
    return `${resolvePath(fileId)} unused imports:\n${unused.join("\n")}`;
  }

  if (qType === "dependents") {
    const fileId = findFileId(qTarget);
    if (!fileId) return `File not found in graph: ${qTarget}`;
    const allDeps = new Set<string>();
    // Direct file-level & symbol-level imports where target file is the TO
    for (const key of ["IMPORTS|" + fileId, "IMPORTS_SYMBOL|" + fileId]) {
      for (const fromId of toIndex.get(key) || []) allDeps.add(fromId);
    }
    // Indirect: files that import symbols exported by the target file
    const exportedEdges = fromIndex.get("EXPORTS|" + fileId) || [];
    for (const e of exportedEdges) {
      for (const fromId of toIndex.get("IMPORTS_SYMBOL|" + e.to) || []) {
        allDeps.add(fromId);
      }
    }
    if (allDeps.size === 0) return `No files depend on ${resolvePath(fileId)}.`;
    const depList = [...allDeps].map((id) => resolvePath(id)).sort();
    return `${resolvePath(fileId)} is imported by:\n${depList.join("\n")}`;
  }

  return `Unknown query type '${qType}'. Valid types: 'structure', 'exports <file>', 'imports_of <file>', 'exporters_of <symbol>', 'dependents <file>', 'unused_imports <file>'.`;
}
