// ── dsh knowledge-graph plugin ──
// Exposes a `read_graph` tool backed by a codebase knowledge graph.
// Replicates H's knowledge-graph builder/query and adapts it to DeepSeek
// Harness's "everything is a plugin" model: a single tool registered on
// `ctx.tools` via `defineTool`.

import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import path from 'node:path'
import { buildKnowledgeGraph, computeWorkspaceFingerprint, type KnowledgeGraph } from './knowledgeGraph.js'
import { runGraphQuery } from './query.js'

export const name = 'knowledge-graph'
export const inject = ['tools']

// One graph per resolved workspace root, invalidated when the tree changes.
const graphCache = new Map<string, { graph: KnowledgeGraph; fingerprint: string }>()

function getGraph(root: string): KnowledgeGraph {
  const abs = path.resolve(root)
  const fingerprint = computeWorkspaceFingerprint(abs)
  const cached = graphCache.get(abs)
  if (cached && cached.fingerprint === fingerprint) return cached.graph
  const graph = buildKnowledgeGraph(abs)
  graphCache.set(abs, { graph, fingerprint })
  return graph
}

export function apply(ctx: Context) {
  ctx.tools.register(defineTool({
    name: 'read_graph',
    description:
      'Query the codebase knowledge graph. The graph tracks every file, directory, exported symbol '
      + '(functions, classes, types, etc.), and their relationships (CONTAINS, EXPORTS, IMPORTS, IMPORTS_SYMBOL). '
      + 'Symbols are parsed from TypeScript/JavaScript and Python (top-level def/class/module-level bindings). '
      + 'Use this for structural/dependency questions — it is faster than grepping or reading files. '
      + 'For file contents, use a read tool. For content search, use a grep/search tool. '
      + 'Query types:\n'
      + "- 'structure' — print the full directory tree. Use this FIRST for architecture/overview questions.\n"
      + "- 'exports <file>' — list all symbols exported by a file (functions, classes, consts, types, interfaces, enums).\n"
      + "- 'imports_of <file>' — list all symbols imported by a file (with their source files; stdlib/third-party imports are tagged).\n"
      + "- 'exporters_of <symbol>' — find which files export a symbol with this name.\n"
      + "- 'dependents <file>' — find which files import from this file.\n"
      + "- 'unused_imports <file>' — list imports that are never referenced in the file.",
    parameters: {
      query: {
        type: 'string',
        required: true,
        description: "Query string in the format '<query_type> <target>'. Examples: 'exports src/index.ts', 'exporters_of buildKnowledgeGraph', 'imports_of src/query.ts', 'unused_imports app.py'.",
      },
      root: {
        type: 'string',
        description:
          'Absolute workspace root to graph. Defaults to process.cwd() (the directory the dsh harness was launched from). '
          + 'This default may be a parent of several independent projects, so ALWAYS pass an explicit `root` '
          + 'pointing at the single workspace you are working in to avoid graphing sibling trees.',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      if (exec.signal?.aborted) throw new Error('read_graph aborted')
      const root = args.root || process.cwd()
      const graph = getGraph(root)
      const result = runGraphQuery(graph, args.query)
      if (exec.signal?.aborted) throw new Error('read_graph aborted')
      return result
    },
  }))
}
