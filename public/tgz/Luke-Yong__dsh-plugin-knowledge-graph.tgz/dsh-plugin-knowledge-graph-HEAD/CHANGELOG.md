# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2026-08-17

### Added

- Graph cache invalidation: the per-root graph is now rebuilt when the workspace tree changes (file-count + latest-mtime fingerprint), so source edits are reflected without restarting the harness.

### Fixed

- Python imports are now only parsed at module level (column 0); indented imports inside functions/classes no longer produce duplicate `IMPORTS`/`IMPORTS_SYMBOL` edges.
- Python private/dunder module-level names (leading `_`) are no longer exported as symbols.
- Python relative imports (`from .mod import y`) now resolve to the correct local file instead of a literal `.mod` path.
- `unused_imports` no longer counts names that appear only in comments or docstrings as used.

## [0.2.0] - 2026-08-17

### Added

- Python symbol extraction: module-level `def`, `class`, and `name = value` bindings are now parsed into symbol nodes and `EXPORTS` edges, making `exports <file>` and `exporters_of <symbol>` work for `.py`/`.pyi`/`.pyx` files.
- Symbol-level import edges for Python: `from X import a, b` and `import X` resolve into named symbols, so `imports_of <file>` lists imported names with their source.
- Import classification: import targets are tagged `local`, `stdlib`, or `third-party` (Python stdlib and Node.js builtins are recognized).
- Multi-name import handling: `import os, json` and `import re, csv` record each name as its own import record/edge.
- `unused_imports <file>` query: surfaces imports that are never referenced outside their import statements (e.g. `from flask import url_for` where `url_for` is unused).

### Changed

- `imports_of <file>` output now lists named imports (including external ones) with their classification tags.

### Fixed

- The misleading `exports nothing (or is not a TypeScript file)` message no longer conflates "no symbols" with "unsupported language"; Python and TypeScript/JavaScript files report accurately, and only unsupported extensions mention a missing parser.
- Documented the `root` parameter default (`process.cwd()`) and its risk of graphing sibling trees; users are advised to pass an explicit `root`.
