# Contributing

Thanks for your interest in contributing to `dsh-plugin-knowledge-graph`.

> **Status: infancy.** This project is in its infancy stage. Execution behavior,
> the query surface, and compatibility may change while the project is iterated
> on and tested by the open source community. Please be patient with API changes.

## Ways to contribute

- Report bugs or unexpected behavior
- Suggest new query types or graph features
- Improve documentation
- Submit code changes

## Getting started

Requirements: Node.js `>=22.19`.

```bash
git clone https://github.com/Luke-Yong/dsh-plugin-knowledge-graph.git
cd dsh-plugin-knowledge-graph
npm install
npm run build
```

`npm run build` compiles `src/` to `dist/` with `tsc` and also serves as the
type check.

## Project layout

```
src/
  index.ts          Plugin entry — registers the read_graph tool
  knowledgeGraph.ts Graph builder (walk, import/export parsing, serialization)
  query.ts          Query engine (runGraphQuery)
```

## Pull requests

1. Fork the repository and create a branch.
2. Make your change. Keep it focused and minimal.
3. Run `npm run build` and ensure it passes.
4. Open a pull request with a clear description of what and why.

## Style

- TypeScript, ES2022, NodeNext modules.
- Match the existing comment style and file structure.
- Prefer small, focused changes over large rewrites.
