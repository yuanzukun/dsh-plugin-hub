# Architecture

This document describes the internal architecture of `dsh-plugin-knowledge-graph`.

## Overview

The plugin follows DeepSeek Harness's "everything is a plugin" model: a single tool (`read_graph`) is registered on `ctx.tools` via `defineTool`. The plugin builds an in-memory knowledge graph from a workspace root and answers structural/dependency queries against it.

```text
┌──────────────┐   build   ┌──────────────────┐   query   ┌───────────────┐
│ filesystem    │ ───────► │ KnowledgeGraph     │ ────────► │ runGraphQuery  │
│ (workspace)   │          │ nodes + edges      │           │ (query.ts)     │
└──────────────┘          └──────────────────┘           └───────┬───────┘
                                 (knowledgeGraph.ts)             │
                                                                 ▼
                                                          result string
```

## Components

### `src/index.ts` — plugin entry

- Exports `name` (`knowledge-graph`), `inject` (`['tools']`), and `apply`.
- `apply(ctx)` registers the `read_graph` tool.
- Maintains a per-root `graphCache` (`Map<string, { graph, fingerprint }>`) keyed by resolved root. Each query recomputes a lightweight tree fingerprint and rebuilds the graph only when the tree changes.
- The tool's `execute` resolves the root, builds/retrieves the graph, runs the query, and returns a string. It checks `exec.signal.aborted` before and after work.

### `src/knowledgeGraph.ts` — builder

Builds the graph from the filesystem:

1. **Walk** (`walkDir`) the workspace recursively, creating `dir` and `file` nodes and `CONTAINS` edges. Applies ignore rules for dependency directories, build output, secrets, and non-code files.
2. **Parse exports** (`parseExports` → `parseTsExports` / `parsePythonExports`) for TypeScript/JavaScript and Python files, creating `symbol` nodes and `EXPORTS` edges.
3. **Parse imports** (`extractImports` → `extractPythonImports` / `extractJsImports`, `resolveImportTarget`, `classifyImport`) for importable source files, producing `IMPORTS` edges, precise `IMPORTS_SYMBOL` edges (when an imported name matches a target file's exported symbol), and `NamedImport` records tagged `local` / `stdlib` / `third-party`.

Also provides:

- `computeWorkspaceFingerprint` — returns a lightweight tree fingerprint (file count + latest mtime) used for cache invalidation.
- `serializeGraph` — emits the compact `.kg` format (edge-list derivative).
- `visualizeGraph` — renders a human-readable nested tree with per-file export/import annotations.

### `src/query.ts` — query engine

`runGraphQuery(graph, query)`:

1. Builds a lightweight `IndexedNode` map from the graph.
2. Builds O(1) indexes: forward/backward edge indexes, a cached path resolver, a lowercased file-path index, and a symbol-name index.
3. Parses the query into `query_type` and `target`.
4. Dispatches to the appropriate handler (`structure`, `exports`, `imports_of`, `exporters_of`, `dependents`, `unused_imports`) and returns a human-readable string.

## Language support

| Language | Symbol (export) parsing | Import parsing | Import classification |
| --- | --- | --- | --- |
| TypeScript / JavaScript (`.ts`, `.tsx`, `.mts`, `.cts`, `.js`, `.jsx`, `.mjs`, `.cjs`) | Yes — TypeScript compiler API | Yes — named / default / namespace / `require` / dynamic | `local` / `stdlib` (Node builtins) / `third-party` |
| Python (`.py`, `.pyi`, `.pyx`) | Yes — regex: `def` / `class` / module-level bindings | Yes — `import`, `from … import` | `local` / `stdlib` (Python stdlib) / `third-party` |

Extensions listed in `IMPORTABLE_EXTS` beyond the two rows above (Rust, Go, Java/Kotlin, C#, Ruby, PHP, Swift, Scala, Dart, Vue/Svelte) are walked into the tree as file nodes but do not yet have a dedicated import/export parser.

## Data model

```ts
type NodeType = 'dir' | 'file' | 'symbol'
type EdgeType = 'CONTAINS' | 'IMPORTS' | 'EXPORTS' | 'IMPORTS_SYMBOL'

interface KGNode {
  id: string
  type: NodeType
  parentId: string
  name: string
  ext: string   // file: extension; symbol: kind
  absPath: string
}

interface KGEdge {
  id: string
  fromId: string
  toId: string
  type: EdgeType
}

interface KnowledgeGraph {
  rootAbsPath: string
  nodes: Map<string, KGNode>
  edges: KGEdge[]
  imports: NamedImport[]  // named imports (local + external) per file, with classification
}
```

Node and edge IDs are assigned sequentially (`n0`, `n1`, … / `e0`, `e1`, …) via module-level sequences reset at the start of each build.

Each parsed import is recorded in `imports` as a `NamedImport` (`fromId`, `module`, `names`, `classification`, `targetFileId`, `targetNames`, `unused`). `classification` is `local` | `stdlib` | `third-party`; `unused` lists imported names never referenced outside import statements.

## Serialization format (`.kg`)

```text
# comment
n<id>|<type>|<parent_id>||<name>|<kind>
e<id>|<from_id>|<to_id>|<type>
```

- `type`: `dir` | `file` | `symbol`
- `kind`: for files the extension (`ts`, `py`, …); for symbols the kind (`function` | `class` | `const` | `type` | `interface` | `enum` | `default`)

## Caching and lifecycle

- The graph is cached per resolved root (`path.resolve(root)`).
- On each query, `computeWorkspaceFingerprint` recomputes a lightweight tree fingerprint (file count + latest mtime); when it changes, the graph is rebuilt. Edits, additions, and deletions are reflected without restarting the harness.

## Extension points

- Add a new query type in `query.ts` and document it in the tool's `description` in `index.ts`.
- Extend import/export parsing for additional languages in `knowledgeGraph.ts` (`IMPORTABLE_EXTS`, `extractImports`, `parseExports`).
- Adjust ignore rules via `IGNORE_DIR_NAMES`, `IGNORE_FILE_NAMES`, `IGNORE_FILE_SUFFIXES`, and the `ALLOWED_*` allowlists.
