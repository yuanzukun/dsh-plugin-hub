# DSH Watch 首次连接

[返回项目](../README.md) · [English](INSTALL.en.md) · [使用帮助](HELP.zh.md)

## 准备

- 电脑上运行 DeepSeek Harness，手表支持 Android 11 或更新版本。小米手表 5 使用智能模式。
- 电脑和手表连接同一个局域网。首次设置时保持手表亮屏、解锁。
- 电脑需要 ADB。Windows x64 可在向导中按提示从 Google 下载。其他环境先安装 [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools)，让启动 DSH 的环境能找到 `adb`。

## 1. 在电脑上安装插件

### 在 DSH「发现」添加项目索引

在你正在使用的 DSH 中打开「插件 → 实验性插件」，启用「自定义插件索引」。DSH 自带的「发现」需要先添加索引源。在「发现 → 添加索引源」粘贴：

```text
https://raw.githubusercontent.com/cyuni1996/dsh-watch/main/plugin-market.json
```

切换到 **DSH Watch** 索引，选中 DSH Watch 并核对安装来源是 `cyuni1996/dsh-watch`。安装后到「已安装」确认插件开关已开启，按提示重载 DSH。

### 没有「自定义插件索引」时

从 [GitHub Releases](https://github.com/cyuni1996/dsh-watch/releases) 下载 `dsh-watch.tgz`，在当前 DSH 的插件管理器中添加本地包或输入下载地址。自行管理 Web 配置时也可用命令行：

```sh
dsh plugin --profile web add https://github.com/cyuni1996/dsh-watch/releases/latest/download/dsh-watch.tgz
```

执行后重启同一个 Web 配置。使用 DSH Desktop 时，在它自己的插件管理器里安装。Web 和 Desktop 各自管理插件。

[dsh-market](https://dshmarket.com/zh/) 使用独立的社区目录。能在该目录搜到 DSH Watch 时，也可以从那里安装。

## 2. 打开安装向导

进入「设置 → 手表连接」。在「监听地址」选择手表能访问的电脑局域网地址，点击「保存连接设置」。默认端口为 `8767`。打开「手表安装向导」，确认显示「调试工具已就绪」。

## 3. 配对无线调试并安装

1. 在手表的「关于本机」或「我的设备」连续点击系统版本，开启开发者选项。
2. 在「开发者选项 → 无线调试」允许当前网络。选择「使用配对码配对设备」，保留弹窗。
3. 在桌面向导输入 **配对弹窗**里的 IP 和端口，以及手表显示的 **六位系统配对码**。点「无线调试配对」。
4. 点「刷新设备」，选择目标手表，然后点「安装 / 更新 DSH Watch」。已能看到目标手表时直接执行这一步。
5. 若无线调试已配对但列表仍为空，在向导输入 **无线调试主页面**显示的 IP 和端口，点「连接手表」。主页面和配对弹窗的端口可能不同。

![无线调试配对表单，画面中的地址为示例](media/wireless-pairing.png)

## 4. 连接 DSH 并验证

向导中选择刚才保存的电脑地址，点「连接 DSH 并打开」。向导会验证手表连接并打开应用。手表顶部显示「在线」后，先发一条简单消息，再到电脑确认同一条会话已收到它。验证成功后可关闭无线调试。

向导会自动授权当前手表。**桌面生成的十位码用于应用内手动配对**，日常使用安装向导时用不到。手动与外网方式见 [使用帮助](HELP.zh.md)。

## 更新

- **桌面插件**。在原来的 DSH 配置中打开「发现」，切换到 DSH Watch 项目索引。点击插件标题，在「版本」中对推荐的新版本点「安装」，按提示重载 DSH。用发布包安装的用户也可以添加新版 `dsh-watch.tgz` 覆盖更新。
- **手表应用**。如果发布包含新版手表应用，重新开启无线调试，在向导选择原设备并点「安装 / 更新 DSH Watch」。签名一致时会覆盖更新并保留应用数据。
- **遇到签名冲突**。先保留现有应用，确认新旧包来自同一签名来源。不同签名无法覆盖，卸载会清除手表端配对、草稿与本地设置。

发布页的 `SHA256SUMS` 可用于核对下载包。PowerShell 可运行 `Get-FileHash .\dsh-watch.tgz -Algorithm SHA256`。
