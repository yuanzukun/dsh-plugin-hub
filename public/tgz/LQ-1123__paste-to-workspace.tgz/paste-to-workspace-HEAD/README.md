# paste-to-workspace

[![Release v0.8.1](https://img.shields.io/badge/release-v0.8.1-5B4CF0?style=flat-square)]()
[![GitHub](https://img.shields.io/badge/GitHub-LQ1123%2Fpaste--to--workspace-181717?style=flat-square&logo=github)](https://github.com/LQ-1123/paste-to-workspace)
[![License: MIT](https://img.shields.io/badge/license-MIT-0B7285?style=flat-square)](LICENSE)
[![DSH: Web Profile](<https://img.shields.io/badge/DSH-Web%20Profile-5B4CF0?style=flat-square>)](cordis.patch.yml)

**把粘贴或拖入聊天框的图片与任意文件保存为会话工作区文件**，发送时以
`[Image: source: <绝对路径>]` / `[File: source: <绝对路径>]` 文本注入消息——
图片由 modlens 读图，其他文件由模型按路径直接读取。输入框保持干净，预览条
与对话气泡内直接渲染缩略图 / 文件卡片。

## ✨ 功能一览

- **🖼️ 任意文件拖放**：从 Finder / 微信 / QQ / 网页把**任意类型文件**拖到窗口
  任意位置即保存到工作区 `.dsh-paste/`，进入待发预览条（纯文本/链接拖放仍走
  原生行为）
- **📋 图片粘贴**：Cmd/ctrl+V 粘贴截图/图片同样进入待发列表
- **🎨 类型图标渲染**：图片显示缩略图；其他文件显示 RemixIcon line 图标 +
  原始文件名 + 大小（PDF/Word/Excel/PPT/TXT/Markdown/压缩包/音视频/代码/
  字体/电子书等 15 组），未知格式用**代码图标兜底**，样式随浅/深主题
- **⬇️ 点击即下载**：点文件卡片唤起浏览器另存为（保留原始文件名），不再打开
  预览页
- **🚀 纯文件发送**：只上传文件、不输入任何文字也能发送（Enter 或发送按钮
  均可），一次调用 = 一个回合，文字与文件不拆消息
- **🧵 一回合双气泡**：文字留在原气泡、图片/文件卡片移到独立用户行（显示层
  拆分，模型侧始终是一条消息）
- **🌓 主题适配**：卡片底色/边框/文字/图标全部走宿主设计 token，深浅主题
  自动切换
- **✏️ 官方提示文案改写**：拖放时宿主全页提示"图片拖动到此处即可添加"自动
  改写为"文件拖动到此处即可添加"，限制行替换为任意文件说明
- **🧹 30 天自动清理**：超期文件自动清扫（只动插件自己的 `pasted-*` 文件）

## 🚀 安装

**前置**：已装好 DSH（`dsh web` 可正常运行），`dsh plugin` 可用（依赖 pnpm）。

从 **GitHub 安装**（推荐，一行命令，产物已入库无需构建）：

```sh
dsh plugin --profile web add "github:LQ-1123/paste-to-workspace"
# 验证 bundle 已挂载
dsh --profile web --dump-config | grep paste-to-workspace
```

也可以本地路径（开发调试时）或 npm 包名安装：

```sh
dsh plugin --profile web add /path/to/paste-to-workspace
```

安装后**重启 dsh web** 生效：宿主在进程启动时通过 `package.json` 的
`dsh.client` 声明发现浏览器端 bundle，浏览器端无需额外配置。

### 禁用与重新启用

在 Profile patch 或 overlay 中把 bundle 行设为 `disabled: true`：

```yaml
- id: paste-to-workspace
  disabled: true
```

删除该字段或设为 `false` 即可重新启用。

### 卸载

```sh
dsh plugin --profile web remove @dsh-user/paste-to-workspace
```

## 📖 使用

重启 GUI 后：

1. **拖入**任意文件（.txt / .md / .pdf / .doc / .zip …）或**粘贴图片**：输入框
   上方出现预览条——图片为缩略图、其他文件为图标卡片（点击卡片**下载**、
   点灰色 × 移除）；
2. **发送**（Enter 或发送按钮，不输入文字也可以）：**一次回合**——有文字时
   显示两个气泡（文字一条、媒体一条），纯文件只有一条；
3. 模型侧收到 `[Image: source: /Users/.../.dsh-paste/pasted-*.png]`（modlens
   自动读图）或 `[File: source: /Users/.../pasted-*.txt]`（模型按路径读取
   文件内容）；
4. 文件落在工作区 `.dsh-paste/` 目录，历史消息里点击文件卡片可随时重新下载。

## 🧩 工作原理

- **浏览器侧**（`lib/client.js`）：捕获阶段拦截图片粘贴与任意文件拖放 →
  POST 到宿主路由 → 路径进入**旁路待发列表**（草稿零改动）；
  `conversation.input.dock` 预览条渲染待发项；发送时包装 `sendSession` 把
  路径拼成 token 追加到消息（**一次调用 = 一个回合**）；MutationObserver 把
  已发送消息里的 token 显示层替换为图片/文件卡片并拆成两个气泡；拖放期间
  改写宿主"图片…"提示文案。
- **宿主侧**（`lib/index.js`）：`POST /save` 保存任意类型文件到
  `<会话工作区>/.dsh-paste/pasted-<时间戳>-<随机>.<扩展名>`（扩展名取自原始
  文件名，无扩展名文件按原名保存）；`GET /file?path=…[&meta=1]` 回读文件 /
  返回原始文件名与大小；`DELETE /file?path=…` 移除未发送文件。路径校验严格
  （必须位于已知粘贴根目录内且匹配插件命名格式），跨站请求 403。

## ⚠️ 已知限制

- 粘贴（Cmd+V）只拦截聊天输入框内的**图片**；文件请用拖放
- 不支持拖入**文件夹**（请打包成 zip 再拖）
- 单文件上限约 24 MB（base64 后 32 MB JSON 体）
- 发送过的文件在 `.dsh-paste/` 保留 30 天后自动清理，历史卡片点击下载可能
  404（预期行为）
- 待发文件是全局列表：未发送前切换会话，文件会跟着下一次发送走
- 拖放提示文案改写仅作用于拖放进行时；宿主 UI 若有其他"图片"字样不在本
  插件职责范围

## 📜 许可

MIT。文件图标来自 [RemixIcon](https://remixicon.com)（Apache-2.0），path 数据
内嵌于客户端 bundle。

## 🕒 更新历史

- **v0.8.1**：官方拖放提示"图片"→"文件"运行时改写；限制行替换为任意文件说明
- **v0.8.0**：点击文件卡片直接下载（保留原始文件名）；图片缩略图仍为预览
- **v0.7.9**：纯文件发送（空草稿占位符保持发送按钮可用，Enter/按钮均可）
- **v0.7.8**：移除按钮改灰色 ×、置于卡片内部，卡片加高至 48px
- **v0.7.7**：修复 `.ts` 被解析为视频的冲突（TypeScript 优先）
- **v0.7.6**：中性单色图标（随主题），未知格式改用代码图标兜底
- **v0.7.5**：改用 RemixIcon line 图标（内嵌 SVG，无网络依赖）
- **v0.7.4**：全格式覆盖，无扩展名文件按原名保存
- **v0.7.3**：图标瓦片加宽（更"胖"）
- **v0.7.2**：文件卡片/图标紧凑化
- **v0.7.1**：样式随宿主主题 token 切换
- **v0.7.0**：拖放支持所有文件类型 + 文件图标渲染
- **v0.6.x**：30 天自动清理、串行保存、流式输出、拖放接管全局化
- **v0.3 ~ v0.5**：输入框保持干净、缩略图预览条、一回合双气泡