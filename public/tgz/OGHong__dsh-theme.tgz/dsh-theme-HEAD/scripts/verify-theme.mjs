/**
 * Regression guard for the palette ↔ surface boundary.
 *
 * Two facts this file pins down, both learned the hard way and both measured in a
 * real Blink engine rather than reasoned about:
 *
 *  1. A dialog floats over the conversation, so it is pinned to stock neutrals —
 *     and the pin must cover EVERY alias its panes read, because custom
 *     properties are substituted where they are declared: by the time
 *     `--dsw-alias-settings-card-fill: var(--dsw-alias-bg-layer-2)` (declared on
 *     body) reaches a dialog it is already a resolved colour, so re-pinning only
 *     `--dsw-alias-bg-layer-2` fixes some surfaces and leaves others tinted.
 *  2. A page is not a dialog. The community plugin market must follow the palette
 *     like every other page; pinning it neutral turned it into an opaque slab on
 *     a tinted glass window.
 */
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import esbuild from "esbuild";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

const compiled = esbuild.buildSync({
	entryPoints: [join(root, "src/theme.ts")],
	bundle: true,
	platform: "node",
	format: "cjs",
	write: false,
	logLevel: "silent",
}).outputFiles[0].text;

const themeModule = { exports: {} };
new Function("module", "exports", "require", compiled)(themeModule, themeModule.exports, () => {
	throw new Error("theme.ts must not have runtime imports");
});
const { buildSettingsCss, buildThemeOverrides } = themeModule.exports;

/** Colour aliases the shipped dshmarket bundle reads. Keep in sync with it. */
const MARKET_TOKENS = [
	"--dsw-alias-bg-base", "--dsw-alias-bg-layer-1", "--dsw-alias-bg-layer-2",
	"--dsw-alias-bg-layer-3", "--dsw-alias-bg-module-platform", "--dsw-alias-bg-overlay",
	"--dsw-alias-border-l1", "--dsw-alias-border-l2", "--dsw-alias-border-l3",
	"--dsw-alias-border-l4", "--dsw-alias-brand-primary", "--dsw-alias-button-primary-fill",
	"--dsw-alias-interactive-bg-hover", "--dsw-alias-label-dimmed", "--dsw-alias-label-primary",
	"--dsw-alias-label-primary-foreground", "--dsw-alias-label-secondary",
	"--dsw-alias-label-tertiary", "--dsw-alias-link", "--dsw-alias-settings-card-fill",
	"--dsw-alias-settings-card-stroke", "--dsw-alias-state-business-primary",
	"--dsw-alias-state-error-primary", "--dsw-alias-state-success-primary",
	"--dsw-alias-state-success-tertiary", "--dsw-alias-state-warn-primary",
	"--dsw-alias-state-warn-tertiary",
];

const css = buildSettingsCss();

// ---- stage 1: static -------------------------------------------------------
const lightBlock = css.slice(0, css.indexOf("body[data-ds-dark-theme]"));
const darkBlock = css.slice(css.indexOf("body[data-ds-dark-theme]"));
assert(lightBlock.length > 0 && darkBlock.length > 0, "expected both a light and a dark block");

for (const [name, block] of [["light", lightBlock], ["dark", darkBlock]]) {
	for (const scope of ['[data-shortcut-modal="settings"]', '[aria-modal="true"]']) {
		if (!block.includes(scope)) assert.fail(name + " block is missing scope " + scope);
	}
	// The market is a page: pinning it neutral is the regression this guards.
	for (const forbidden of ["[data-dsh-market-root]", "[data-dsh-market-portal]"]) {
		if (block.includes(forbidden)) assert.fail(name + " block must not pin the market (" + forbidden + ")");
	}
	for (const token of MARKET_TOKENS) {
		if (!new RegExp(token + ":\\s*[^;]+;").test(block)) {
			assert.fail(name + " block is missing a pin for " + token);
		}
	}
}

// ---- stage 2: real cascade -------------------------------------------------
const chrome = [
	"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
	"/usr/bin/google-chrome",
].find(existsSync);

if (chrome === undefined) {
	console.log("theme scope: static assertions OK; Blink stage skipped (no Chrome)");
	process.exit(0);
}

const shell = `
body {
  --dsw-static-neutral-bluish-00:#fff; --dsw-static-neutral-bluish-50:#f9fafb;
  --dsw-static-neutral-bluish-200:#e1e5ee; --dsw-static-neutral-bluish-300:#cfd3d6;
  --dsw-static-neutral-bluish-400:#adb2b8; --dsw-static-neutral-bluish-600:#81858c;
  --dsw-static-neutral-bluish-700:#61666b; --dsw-static-neutral-bluish-750:#43454a;
  --dsw-static-neutral-bluish-800:#353638; --dsw-static-neutral-bluish-850:#2c2c2e;
  --dsw-static-neutral-bluish-875:#232324; --dsw-static-neutral-bluish-950:#151517;
  --dsw-static-neutral-bluish-1000:#0f1115;
  --dsw-alias-bg-layer-1: var(--dsw-static-neutral-bluish-00);
  --dsw-alias-bg-layer-2: var(--dsw-static-neutral-bluish-00);
  --dsw-alias-border-l4:#00000029;
  --dsw-alias-settings-card-fill: var(--dsw-alias-bg-layer-2);
  --dsw-alias-settings-card-stroke: var(--dsw-alias-border-l4);
}
body[data-ds-dark-theme] {
  --dsw-alias-bg-layer-1: var(--dsw-static-neutral-bluish-875);
  --dsw-alias-bg-layer-2: var(--dsw-static-neutral-bluish-850);
  --dsw-alias-border-l4:#fff3;
}
/* what overrideTokens composes onto body for a glass palette */
body[data-palette] {
  --dsw-alias-bg-layer-1: color-mix(in srgb, #2d1d26 96%, transparent);
  --dsw-alias-bg-layer-2: color-mix(in srgb, #412b38 96%, transparent);
  --dsw-alias-brand-primary:#ff7ea8;
}`;

const page = `<!doctype html><html><head><meta charset="utf-8"><style>
${shell}
${css}
.probe{width:8px;height:8px;background:var(--dsw-alias-settings-card-fill)}
</style></head><body data-ds-dark-theme data-palette>
<div id="main" class="probe"></div>
<div data-dsh-market-root><div id="market" class="probe"></div></div>
<div data-shortcut-modal="settings"><div id="modal" class="probe"></div></div>
<script>
const bg=id=>getComputedStyle(document.getElementById(id)).backgroundColor;
document.title=JSON.stringify({main:bg("main"),market:bg("market"),modal:bg("modal")});
</script></body></html>`;

const dir = mkdtempSync(join(tmpdir(), "sharks-theme-"));
const file = join(dir, "cascade.html");
writeFileSync(file, page, "utf8");

const dom = execFileSync(chrome, [
	"--headless=new", "--disable-gpu", "--no-sandbox",
	"--virtual-time-budget=3000", "--dump-dom", "file://" + file,
], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });

const measured = JSON.parse(
	dom.match(/<title>([\s\S]*?)<\/title>/)[1].replace(/&quot;/g, '"').replace(/&amp;/g, "&"),
);

const NEUTRAL = "rgb(44, 44, 46)"; // #2c2c2e stock dark layer-2
assert(/color\(srgb/.test(measured.main), "main window should carry the palette, got " + measured.main);
assert.equal(measured.market, measured.main, "the market page must match the shell, got " + measured.market);
assert.notEqual(measured.market, NEUTRAL, "the market must not be pinned neutral, got " + measured.market);
assert.equal(measured.modal, NEUTRAL, "the settings dialog must stay neutral, got " + measured.modal);

const baseConfig = {
	themeEnabled: true, palette: "rose", accent: "", glass: true, glassAmount: 0.55,
	enabled: true, interactive: false, randomSpecies: false, strength: 0.5, opacity: 0.7, sharks: ["orca"],
};
const palette = buildThemeOverrides(baseConfig);
assert(palette["--dsw-alias-bg-layer-2"].dark.includes("color-mix"), "palette must still tint the shell");

// ---- stage 3: one alpha across page surfaces -------------------------------
// Every surface level used to carry its own alpha (40% base / 46% card / 50%
// raised), so each level boundary let a different fraction of the wallpaper
// through and drew a horizontal seam — measured 14 (black backdrop) vs 18
// (white backdrop) at one boundary, i.e. a jump that tracked the wallpaper.
// Hierarchy must come from lightness at a single alpha instead.
const PAGE_SURFACES = [
	"--dsw-alias-bg-base",
	"--dsw-alias-bg-layer-1",
	"--dsw-alias-bg-layer-2",
	"--dsw-alias-bg-overlay",
	"--dsw-specific-sidebar-fill",
	"--dsw-specific-input-major",
];

const alphaOf = (value) => {
	const match = value.match(/([\d.]+)%,\s*transparent/);
	return match === null ? 100 : Number(match[1]);
};

for (const amount of [0.2, 0.55, 1]) {
	const tokens = buildThemeOverrides({ ...baseConfig, glassAmount: amount });
	for (const token of PAGE_SURFACES) assert(token in tokens, "glass mode must publish " + token);
	const pageAlphas = ["--dsw-alias-bg-base", "--dsw-specific-sidebar-fill", "--dsw-specific-input-major"].map(
		(token) => alphaOf(tokens[token].dark),
	);
	assert.equal(
		[...new Set(pageAlphas)].length,
		1,
		"page-level surfaces must share one alpha at glassAmount=" + amount + ", got " + pageAlphas.join("/"),
	);
	// The page is glass; the raising levels that float over it are opaque, because a
	// see-through popover (the file preview card) is unreadable.
	const base = tokens["--dsw-alias-bg-base"].dark;
	assert(base.includes("transparent"), "the page background stays glass");
	for (const token of ["--dsw-specific-sidebar-fill", "--dsw-specific-input-major"]) {
		assert.equal(tokens[token].dark, base, token + " must stay flush with the page");
	}
	for (const token of ["--dsw-alias-bg-layer-1", "--dsw-alias-bg-layer-2", "--dsw-alias-bg-overlay"]) {
		assert(!tokens[token].dark.includes("transparent"), token + " must be opaque — it carries floating sheets");
		assert.notEqual(tokens[token].dark, base, token + " must sit above the page");
	}
}

const built = readFileSync(join(root, "lib/client.js"), "utf8");
assert(built.includes('[data-shortcut-modal="settings"]'), "shipped bundle lost the dialog pin");

// ---- stage 4: no stacked translucency on the market's sticky layers ---------
// Those headers paint the background token to hide content scrolling under them.
// With an opaque token that is free; with a translucent one the paints composite
// (two 43% layers -> 67%) and the overlap reads as a band that drifts while
// scrolling. They must be transparent and carry a blur instead.
const { buildGlassCss } = themeModule.exports;
const glass = buildGlassCss({ themeEnabled: true, glass: true, glassAmount: 0.55 });
for (const selector of [
	'[data-dsh-market-root] [class*="_head"]',
	'[data-dsh-market-root] [class*="_stickyHead"]',
]) {
	assert(glass.includes(selector), "glass css must de-paint " + selector);
}
assert(
	/\[class\*="_head"\][^{]*\{[^}]*background:\s*transparent/.test(glass),
	"the market's sticky head must paint nothing",
);
assert(
	/\[class\*="_stickyHead"\][^{]*\{[^}]*backdrop-filter:\s*blur/.test(glass),
	"the market's sticky head must blur what passes under it",
);
assert(
	/\[class\*="_stickyHead"\]::before\s*\{[^}]*background:\s*transparent/.test(glass),
	"the 14px overhang must paint nothing either",
);
assert(
	/header\[data-window-drag\][^{]*\{[^}]*border-bottom-color:\s*transparent/.test(glass),
	"the frame header's rule must be removed in glass mode",
);
assert(
	/\[data-dockkit-pane\][^{]*\{[^}]*background:\s*var\(--dsh-ascii-solid-base/.test(glass),
	"dock panes must be opaque, or the diff reads through them",
);
assert(
	/\[data-code-wrap\][^{]*\{[^}]*background-color:\s*var\(--dsw-alias-markdown-code-block/.test(glass),
	"code blocks must paint the opaque code-block token (not the flat page colour)",
);
for (const token of ["--dsw-alias-markdown-code-block", "--dsw-alias-markdown-code-block-banner"]) {
	const tokens = buildThemeOverrides({ ...baseConfig, glassAmount: 0.55 });
	assert(token in tokens, "glass mode must publish " + token);
	assert(!tokens[token].dark.includes("transparent"), token + " must be opaque");
}

console.log(
	"theme scope OK — dialog neutral (" + measured.modal + "), market follows palette (" +
	measured.market + "), main window " + measured.main,
);
