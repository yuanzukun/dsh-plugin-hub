/**
 * Copyright (c) 2026 OG Hong — MIT. See LICENSE at the repository root.
 *
 * The settings surface, in two seats.
 *
 * `SettingsRow` is the block inside the General section — the quick switch most
 * readers want. `OceanSection` is this plugin's own page in the settings nav,
 * which is where the full control set lives. Both render the same fields from
 * the same store, so no value can disagree between the two seats.
 *
 * Layout: an intentionally quiet one — two switch-headed groups, no row rules,
 * inline sliders with their value, and colour dots instead of text pills. The
 * shell supplies the type scale and tokens; this file only arranges them.
 * @module ascii-sharks/settings-row
 */

import { useEffect, useState, useSyncExternalStore } from "react";
import type { ConfigStore, OceanConfig } from "./store";
import { PALETTE_IDS, paletteSwatch } from "./theme";
import type { SharkKind } from "./world";

/** Species a pod can be made of. */
const KINDS: readonly SharkKind[] = [
	"orca", "classic", "greathammer", "hammerhead", "mako",
	"nurse", "thresher", "tiger", "zebra",
];

/** What the shell passes in, plus this plugin's own face. */
export interface RowProps {
	readonly store: ConfigStore;
	readonly t: (key: string) => string;
}

// The settings dialog's .options column is ~564px wide (800px panel minus the
// 188px nav and 24px padding each side); 540 + border-box keeps every card
// inside it with no horizontal scrollbar. The wrap centres the cards in that
// column, the way the shell's own grouped settings are centred.
const WRAP: React.CSSProperties = {
	display: "flex",
	flexDirection: "column",
	width: "100%",
	maxWidth: 540,
	boxSizing: "border-box",
	margin: "0 auto",
	gap: 12,
};

/**
 * One card per group. The whole Settings panel is pinned to the shell's stock
 * neutral greys by buildSettingsCss(), so these alias-token references resolve
 * to a fixed, theme-independent palette — no per-card ink overrides needed.
 */
const CARD: React.CSSProperties = {
	width: "100%",
	boxSizing: "border-box",
	padding: "4px 16px 8px",
	borderRadius: 12,
	border: "0.5px solid var(--dsw-alias-border-l2)",
	background: "var(--dsw-alias-bg-module-platform)",
};

/**
 * One setting row, with a hairline dashed rule beneath — the rhythm used by the
 * shell's own Appearance page. Rules sit between rows, not under the header, so
 * the card reads as one list rather than a stack of boxes.
 */
function Row({ children, last }: { children: React.ReactNode; last?: boolean }) {
	return (
		<div
			style={{
				display: "flex",
				alignItems: "center",
				justifyContent: "space-between",
				gap: 16,
				minHeight: 36,
				padding: "5px 0",
				borderBottom: last ? "none" : "0.5px dashed var(--dsw-alias-border-l2)",
			}}
		>
			{children}
		</div>
	);
}

/** A card's title bar: name on the left, its master switch on the right, with a rule beneath. */
function GroupHead({ name, on, onToggle }: { name: string; on: boolean; onToggle: () => void }) {
	return (
		<div
			style={{
				display: "flex",
				alignItems: "center",
				justifyContent: "space-between",
				padding: "12px 0 10px",
				borderBottom: "0.5px solid var(--dsw-alias-border-l2)",
				marginBottom: 2,
			}}
		>
			<span style={{ fontSize: 14, fontWeight: 600, lineHeight: "20px", color: "var(--dsw-alias-label-primary)" }}>
				{name}
			</span>
			<Switch on={on} onChange={onToggle} />
		</div>
	);
}

/** A titled card: one card per group, with the header inside it. */
function GroupCard({ name, on, onToggle, children }: {
	name: string; on: boolean; onToggle: () => void; children: React.ReactNode;
}) {
	return (
		<section style={CARD}>
			<GroupHead name={name} on={on} onToggle={onToggle} />
			{children}
		</section>
	);
}

function Label({ children }: { children: React.ReactNode }) {
	return (
		<span style={{ fontSize: 12.5, lineHeight: "18px", color: "var(--dsw-alias-label-secondary)" }}>
			{children}
		</span>
	);
}

/** A compact switch, sized to sit beside a row label without dominating it. */
function Switch({ on, onChange }: { on: boolean; onChange: () => void }) {
	return (
		<button
			type="button"
			role="switch"
			aria-checked={on}
			onClick={onChange}
			style={{
				position: "relative",
				flex: "none",
				width: 34,
				height: 19,
				borderRadius: 999,
				border: "none",
				cursor: "pointer",
				padding: 0,
				background: on ? "var(--dsw-alias-brand-primary)" : "var(--dsw-alias-border-l3)",
				transition: "background 140ms ease",
			}}
		>
			<span
				style={{
					position: "absolute",
					top: 2,
					left: on ? 17 : 2,
					width: 15,
					height: 15,
					borderRadius: 999,
					background: "var(--dsw-alias-bg-base)",
					boxShadow: "0 0 0 0.5px var(--dsw-alias-border-l3)",
					transition: "left 140ms ease",
				}}
			/>
		</button>
	);
}

/**
 * Inline slider: a hairline track and a small brand thumb, drawn by us so it
 * stays thin on every platform (a native range is far heavier). The invisible
 * range on top keeps native keyboard and pointer behaviour intact.
 */
function Slider({
	value, min, max, label, onChange,
}: { value: number; min: number; max: number; label: string; onChange: (v: number) => void }) {
	const pct = ((value - min) / (max - min)) * 100;
	return (
		<div style={{ display: "flex", alignItems: "center", gap: 10, flex: 1, maxWidth: 230 }}>
			<div style={{ position: "relative", flex: 1, height: 16, display: "flex", alignItems: "center" }}>
				<div
					style={{
						position: "absolute",
						left: 0,
						right: 0,
						height: 3,
						borderRadius: 99,
						background: `linear-gradient(to right, var(--dsw-alias-brand-primary) ${pct}%, var(--dsw-alias-border-l2) ${pct}%)`,
					}}
				/>
				<div
					style={{
						position: "absolute",
						left: `calc(${pct}% - 5px)`,
						width: 10,
						height: 10,
						borderRadius: 99,
						background: "var(--dsw-alias-brand-primary)",
						boxShadow: "0 0 0 1px var(--dsw-alias-bg-layer-1)",
					}}
				/>
				<input
					type="range"
					min={min}
					max={max}
					step={(max - min) / 20}
					value={value}
					aria-label={label}
					onChange={(event) => onChange(Number(event.currentTarget.value))}
					style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0, margin: 0, cursor: "pointer" }}
				/>
			</div>
			<span
				style={{
					font: "500 11px/1 var(--ds-font-family-code, ui-monospace, Menlo, monospace)",
					color: "var(--dsw-alias-label-secondary)",
					minWidth: 34,
					textAlign: "right",
					fontVariantNumeric: "tabular-nums",
				}}
			>
				{Math.round(pct)}%
			</span>
		</div>
	);
}

/** A palette as a colour dot; the current one wears a brand ring. */
function Swatch({ id, on, onClick, title }: { id: string; on: boolean; onClick: () => void; title: string }) {
	return (
		<button
			type="button"
			aria-label={title}
			aria-pressed={on}
			title={title}
			onClick={onClick}
			style={{
				width: 20,
				height: 20,
				padding: 0,
				borderRadius: 99,
				cursor: "pointer",
				border: `2px solid ${on ? "var(--dsw-alias-bg-layer-1)" : "transparent"}`,
				background: paletteSwatch(id),
				boxShadow: `0 0 0 1px ${on ? "var(--dsw-alias-brand-primary)" : "var(--dsw-alias-border-l2)"}`,
			}}
		/>
	);
}

function StepButton({ label, onClick, disabled }: { label: string; onClick: () => void; disabled: boolean }) {
	return (
		<button
			type="button"
			onClick={onClick}
			disabled={disabled}
			aria-label={label === "+" ? "one more" : "one fewer"}
			style={{
				width: 22,
				height: 22,
				borderRadius: 6,
				cursor: disabled ? "default" : "pointer",
				opacity: disabled ? 0.35 : 1,
				border: "0.5px solid var(--dsw-alias-border-l2)",
				background: "transparent",
				color: "var(--dsw-alias-label-primary)",
				font: "500 13px/1 var(--ds-font-family-code, ui-monospace, Menlo, monospace)",
			}}
		>
			{label}
		</button>
	);
}

/** Whether the OS asked for reduced motion. */
function useReducedMotion(): boolean {
	return useSyncExternalStore(
		(listener) => {
			if (typeof matchMedia !== "function") return () => undefined;
			const mq = matchMedia("(prefers-reduced-motion: reduce)");
			mq.addEventListener("change", listener);
			return () => mq.removeEventListener("change", listener);
		},
		() => (typeof matchMedia === "function" ? matchMedia("(prefers-reduced-motion: reduce)").matches : false),
		() => false,
	);
}

/** Ocean fields, shared by both seats. No header — the caller supplies it. */
function OceanFields({ store, t }: RowProps) {
	const config: OceanConfig = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);
	const patch = (next: Partial<OceanConfig>) => store.set({ ...config, ...next });
	return (
		<>
			<Row>
				<Label>{t("opacity")}</Label>
				<Slider value={config.opacity} min={0.1} max={1} label={t("opacity")} onChange={(v) => patch({ opacity: v })} />
			</Row>
			<Row>
				<Label>{t("strength")}</Label>
				<Slider value={config.strength} min={0.2} max={1} label={t("strength")} onChange={(v) => patch({ strength: v })} />
			</Row>
			<Row>
				<Label>{t("count")}</Label>
				<div style={{ display: "flex", alignItems: "center", gap: 8 }}>
					<StepButton label="−" disabled={config.sharks.length <= 1} onClick={() => patch({ sharks: config.sharks.slice(0, -1) })} />
					<span style={{ font: "500 12px/1 var(--ds-font-family-code, ui-monospace, Menlo, monospace)", color: "var(--dsw-alias-label-primary)", minWidth: 14, textAlign: "center" }}>
						{config.sharks.length}
					</span>
					<StepButton
						label="+"
						disabled={config.sharks.length >= 5}
						onClick={() => {
							const last = config.sharks[config.sharks.length - 1] ?? "orca";
							patch({ sharks: [...config.sharks, last] });
						}}
					/>
				</div>
			</Row>
			<Row>
				<Label>{t("sharks")}</Label>
				<select
					value={config.randomSpecies ? "__random" : (config.sharks[0] ?? "orca")}
					aria-label={t("sharks")}
					onChange={(event) => {
						const v = event.currentTarget.value;
						if (v === "__random") patch({ randomSpecies: true });
						else patch({ randomSpecies: false, sharks: Array.from({ length: config.sharks.length }, () => v as SharkKind) });
					}}
					style={{
						font: "500 11.5px/1 var(--ds-font-family-code, ui-monospace, Menlo, monospace)",
						padding: "5px 22px 5px 9px",
						borderRadius: 6,
						border: "0.5px solid var(--dsw-alias-border-l2)",
						background: "var(--dsw-alias-bg-layer-1)",
						color: "var(--dsw-alias-label-primary)",
						cursor: "pointer",
					}}
				>
					<option value="__random">{t("random")}</option>
					{KINDS.map((kind) => <option key={kind} value={kind}>{t(`kind_${kind}`)}</option>)}
				</select>
			</Row>
			<Row last>
				<Label>{t("interactive")}</Label>
				<Switch on={config.interactive} onChange={() => patch({ interactive: !config.interactive })} />
			</Row>
		</>
	);
}

/** Appearance fields, shared by both seats. No header. */
function AppearanceFields({ store, t }: RowProps) {
	const config: OceanConfig = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);
	const patch = (next: Partial<OceanConfig>) => store.set({ ...config, ...next });
	return (
		<>
			<Row>
				<Label>{t("palette")}</Label>
				<div style={{ display: "flex", gap: 10 }}>
					{PALETTE_IDS.map((id) => (
						<Swatch key={id} id={id} title={t(`p_${id}`)} on={config.palette === id} onClick={() => patch({ palette: id })} />
					))}
				</div>
			</Row>
			<Row>
				<Label>{t("accent")}</Label>
				<div style={{ display: "flex", alignItems: "center", gap: 10 }}>
					<input
						type="color"
						value={config.accent || "#1f7fb8"}
						aria-label={t("accent")}
						onChange={(event) => patch({ accent: event.currentTarget.value })}
						style={{ width: 22, height: 22, padding: 0, border: "0.5px solid var(--dsw-alias-border-l2)", borderRadius: 6, background: "transparent", cursor: "pointer" }}
					/>
					<button type="button" onClick={() => patch({ accent: "" })} style={{ font: "500 11px/1 var(--ds-font-family-code, ui-monospace, Menlo, monospace)", color: config.accent === "" ? "var(--dsw-alias-brand-primary)" : "var(--dsw-alias-label-secondary)", background: "none", border: "none", cursor: "pointer", padding: 0, textDecoration: "underline" }}>
						{t("accentReset")}
					</button>
				</div>
			</Row>
			<Row last={!config.glass}>
				<Label>{t("glass")}</Label>
				<Switch on={config.glass} onChange={() => patch({ glass: !config.glass })} />
			</Row>
			{config.glass ? (
				<Row last>
					<Label>{t("glassAmount")}</Label>
					<Slider value={config.glassAmount} min={0} max={1} label={t("glassAmount")} onChange={(v) => patch({ glassAmount: v })} />
				</Row>
			) : null}
		</>
	);
}

/**
 * This plugin's own settings page: two switch-headed groups, no duplication.
 * The status line stays — a background that silently fails to mount is the
 * hardest kind of bug to report, so the page says which condition is in effect.
 */
export function OceanSection({ store, t }: RowProps) {
	const config: OceanConfig = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);
	const reduced = useReducedMotion();
	const [hero, setHero] = useState<boolean | null>(null);

	useEffect(() => {
		const read = () => setHero(document.querySelector("[data-phase=\"hero\"]") !== null);
		read();
		const timer = window.setInterval(read, 900);
		return () => window.clearInterval(timer);
	}, []);

	const state = !config.enabled
		? t("stateOff")
		: reduced
			? t("stateReduced")
			: hero === true
				? t("stateLive")
				: hero === null
					? t("stateUnknown")
					: t("stateIdle");

	return (
		<div data-ascii-sharks-section="" style={WRAP}>
			<div style={{ display: "flex", alignItems: "baseline", gap: 7, padding: "2px 2px 0" }}>
				<span style={{ fontSize: 11, color: "var(--dsw-alias-label-tertiary)" }}>{t("stateLabel")}</span>
				<span
					style={{
						fontSize: 11,
						color: state === t("stateLive") ? "var(--dsw-alias-state-success-primary)" : "var(--dsw-alias-label-secondary)",
					}}
				>
					{state}
				</span>
			</div>

			<GroupCard name={t("groupOcean")} on={config.enabled} onToggle={() => store.set({ ...config, enabled: !config.enabled })}>
				{config.enabled ? <OceanFields store={store} t={t} /> : null}
			</GroupCard>

			<GroupCard name={t("themeTitle")} on={config.themeEnabled} onToggle={() => store.set({ ...config, themeEnabled: !config.themeEnabled })}>
				{config.themeEnabled ? <AppearanceFields store={store} t={t} /> : null}
			</GroupCard>
		</div>
	);
}
