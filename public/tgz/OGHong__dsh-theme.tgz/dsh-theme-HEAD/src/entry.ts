/**
 * Copyright (c) 2026 OG Hong — MIT. See LICENSE at the repository root.
 *
 * `dsh-theme` — registration only.
 *
 * Two contributions and nothing else:
 *
 *   - `shell.overlay` — the ocean canvas, behind the New Session hero;
 *   - `settings.section` — the Appearance page holding every control.
 *
 * Both read one shared store, so the settings and the water can never disagree.
 * @module ascii-sharks/entry
 */

import { OceanSeat } from "./surface";
import { OceanSection } from "./settings-row";
import { AppearanceIcon } from "./icon";
import { createConfigStore } from "./store";
import { applyTheme } from "./theme";

/** Locale namespace owning this plugin's copy. */
const NS = "ascii-sharks";

/** Every string this plugin shows, so the shell's language switch covers it. */
const DICTS = {
	en: {
		title: "Appearance",
		groupOcean: "Ocean",
		description: "An ASCII ocean behind the New Session screen.",
		show: "Show the ocean",
		opacity: "Transparency",
		strength: "Density",
		sharks: "Species of the pod",
		count: "How many",
		countHint: "1 to 5 whales in the water",
		random: "random",
		randomHint: "each whale rolls its own species, fresh every time the ocean comes back",
		interactive: "Scatter the fish with the pointer",
		reduced: "Idle: the OS asked for reduced motion",
		sectionTitle: "Appearance",
		stateLabel: "Status",
		stateLive: "live behind New Session",
		stateIdle: "paused: no New Session on screen",
		stateOff: "switched off",
		stateReduced: "idle: the OS asked for reduced motion",
		stateUnknown: "checking…",
		themeTitle: "Appearance",
		themeHint: "Tint DSH with the shell's own theme service.",
		themeEnabled: "Customize the DSH theme",
		palette: "Colour palette",
		accent: "Accent colour",
		accentReset: "Use palette",
		glass: "macOS glass",
		glassHint: "Let the desktop wallpaper show through every surface",
		glassAmount: "Glass intensity",
		p_default: "Default",
		p_ocean: "Ocean",
		p_midnight: "Midnight",
		p_forest: "Forest",
		p_rose: "Rose",
		kind_orca: "Orca",
		kind_classic: "Requiem shark",
		kind_greathammer: "Great hammerhead",
		kind_hammerhead: "Hammerhead",
		kind_mako: "Mako",
		kind_nurse: "Nurse shark",
		kind_thresher: "Thresher",
		kind_tiger: "Tiger shark",
		kind_zebra: "Zebra shark",
	},
	zh: {
		title: "外观",
		groupOcean: "海洋",
		description: "新建会话页的背景里有一片 ASCII 海。",
		show: "显示海洋",
		opacity: "透明度",
		strength: "浓淡",
		sharks: "整群种类",
		count: "数量",
		countHint: "水里有几只（1–5）",
		random: "随机",
		randomHint: "每只各自抽，每次回到新建会话页重新抽过",
		interactive: "鼠标划过时驱散鱼群",
		reduced: "已静止：系统开启了减弱动效",
		sectionTitle: "外观",
		stateLabel: "状态",
		stateLive: "正在新建会话页后面运行",
		stateIdle: "已暂停：当前没有新建会话页",
		stateOff: "已关闭",
		stateReduced: "已静止：系统开启了减弱动效",
		stateUnknown: "检查中…",
		themeTitle: "外观",
		themeHint: "通过 DSH 自身的主题服务给界面换色。",
		themeEnabled: "自定义 DSH 主题",
		palette: "配色",
		accent: "强调色",
		accentReset: "跟随配色",
		glass: "macOS 玻璃质感",
		glassHint: "让桌面壁纸透过整个窗口，输入框带毛玻璃模糊",
		glassAmount: "玻璃强度",
		p_default: "默认",
		p_ocean: "海洋蓝",
		p_midnight: "午夜紫",
		p_forest: "森林绿",
		p_rose: "玫瑰红",
		kind_orca: "虎鲸",
		kind_classic: "真鲨",
		kind_greathammer: "大锤头鲨",
		kind_hammerhead: "锤头鲨",
		kind_mako: "灰鲭鲨",
		kind_nurse: "护士鲨",
		kind_thresher: "长尾鲨",
		kind_tiger: "虎鲨",
		kind_zebra: "斑纹鲨",
	},
} as const;

/**
 * Wire the plugin's settings page.
 * @param ctx - The client context this package's half was given.
 */
export function apply(ctx: any) {
	const slots = ctx.get("slots");
	if (slots === undefined || slots === null) {
		// Unreachable while the `inject` below is declared, and deliberately loud if
		// it happens anyway: returning quietly here is how a contribution goes
		// missing for the life of the page with nothing in the console.
		const message = "dsh-theme: the slots service is unavailable; nothing was registered";
		ctx.logger?.warn?.(message);
		console.warn(message);
		return;
	}

	/**
	 * Register the dictionaries *when the locale service is there*.
	 *
	 * `ctx.get("locale")` at apply time answers undefined on a cold page load — this
	 * bundle activates before the locale plugin does — and a one-shot `ctx.effect`
	 * that gives up at that point leaves the namespace unregistered for the life of
	 * the page. The symptom is subtle and ugly: every label renders as its own key.
	 * `ctx.inject` instead runs the registration the moment the service appears, and
	 * disposes it again if the service goes away.
	 */
	ctx.inject(["locale"], (localeCtx: any) => {
		const locale = localeCtx.get("locale");
		if (locale === undefined || locale === null) return;
		localeCtx.effect(() => {
			try {
				locale.register(NS, { zh: DICTS.zh, en: DICTS.en });
			} catch (error) {
				console.warn("dsh-theme: could not register the dictionaries", error);
			}
		}, "ascii-sharks: locale dictionaries");
	});

	/** Copy, preferring the shell's live locale over this build's own dictionary. */
	const t = (key: string) => {
		try {
			const locale = ctx.get("locale");
			if (locale !== undefined && locale !== null) {
				const translated = locale.bind(NS)(key);
				// A missing namespace entry comes back as the key itself; fall back to
				// the bundled English rather than showing `strength` to the reader.
				if (translated !== key) return translated;
			}
		} catch {
			/* No locale service yet: the bundled dictionary is the whole answer. */
		}
		return (DICTS.en as Record<string, string>)[key] ?? key;
	};

	const store = createConfigStore();

	// Theme overrides are a separate seat from the ocean: they live on DSH's own
	// theme service and must keep working even when the canvas is switched off.
	applyTheme(ctx, store);

	/**
	 * The shell-owned face both seats are handed.
	 *
	 * The configuration itself is *not* passed down as a prop: the slot renderer
	 * copies an injected face into plain props once, at render, so a value read here
	 * would be frozen at mount. Both seats read the live store through
	 * `useSyncExternalStore` instead, and this face only hands them the store.
	 */
	const face = () => ({ store, t, ctx });

	try {
		ctx.effect(
			() =>
				slots.inject("shell.overlay", () =>
					slots.register(
						{ name: "shell.overlay", id: "ascii-ocean", inject: face },
						OceanSeat,
					),
				),
			"ascii-sharks: ocean surface",
		);
	} catch (error) {
		console.warn(`dsh-theme: could not register the ocean (${String(error)})`);
	}

	// The plugin's own page in the settings nav.
	//
	// The shell's Plugins page lists only its own shipped bundles, so a third-party
	// client plugin has no entry anywhere in that list. This page is where it can
	// be found by name — the single home for every ocean + appearance control.
	try {
		ctx.effect(
			() =>
				slots.inject("settings.section", () =>
					slots.register(
						{
							name: "settings.section",
							id: "ascii-ocean",
							// Right after General (0), before Models (10). The reader
							// asked for Appearance to sit directly under General.
							order: 1,
							label: () => t("sectionTitle"),
							locale: NS,
							inject: face,
						},
						OceanSection,
					),
				),
			"ascii-sharks: settings section",
		);
	} catch (error) {
		console.warn(`dsh-theme: could not register the settings section (${String(error)})`);
	}

	// Replace the section's default gear with the tilted-diamond appearance glyph.
	// The id must match the section id above; the shell renders this icon only on
	// that row (renderSlot passes `only: row.id`).
	try {
		ctx.effect(
			() =>
				slots.inject("settings.section.icon", () =>
					slots.register(
						{ name: "settings.section.icon", id: "ascii-ocean", order: 1 },
						AppearanceIcon,
					),
				),
			"ascii-sharks: settings section icon",
		);
	} catch (error) {
		console.warn(`dsh-theme: could not register the settings icon (${String(error)})`);
	}

	// Deliberately no settings.general.item row: the ocean + appearance controls
	// live only on this plugin's own Appearance page. Duplicating them inside
	// General made that page scroll and buried its own settings.
}

/**
 * Required client services.
 *
 * The slots service owns the registry both seats register into, and on a cold page
 * load it activates *after* this bundle does. Declaring it parks the entry until
 * the service exists and applies it then.
 */
export const inject = ["slots"];
