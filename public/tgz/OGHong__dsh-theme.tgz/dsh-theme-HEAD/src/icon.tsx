/**
 * Copyright (c) 2026 OG Hong — MIT. See LICENSE at the repository root.
 *
 * The nav icon for this plugin's Appearance settings section: a classic artist's
 * palette (🎨) — a kidney-shaped board with a thumb hole and three dabs of paint,
 * one of them a square brush stroke. Hand-drawn to match DSH's icon language:
 * 16×16, 1.15 stroke, round joins, currentColor so it follows the nav theme.
 * @module ascii-sharks/icon
 */

export interface AppearanceIconProps {
	/** Square size in px; the slot passes 16. */
	readonly size?: number;
	/** Whether the parent nav row is selected (kept for slot parity). */
	readonly active?: boolean;
}

export function AppearanceIcon({ size = 16 }: AppearanceIconProps) {
	return (
		<svg
			width={size}
			height={size}
			viewBox="0 0 16 16"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.15"
			strokeLinejoin="round"
			strokeLinecap="round"
			aria-hidden="true"
			style={{ display: "block", flex: "none" }}
		>
			{/* kidney-shaped board with thumb notch at lower-right */}
			<path d="M8 1.9c3.5 0 6.2 2.4 6.2 5.5 0 1.7-1 3-2.4 3.7-.7.3-1.1.8-1.1 1.5 0 .9-.7 1.5-1.6 1.5-3.7 0-6.7-2.8-6.7-6.3C2.4 4.5 4.8 1.9 8 1.9Z" />
			{/* thumb hole */}
			<circle cx="10.5" cy="9.6" r="1.05" />
			{/* three dabs of paint: two round, one square brush stroke */}
			<path d="M4.2 4.6c.5-.5 1.3-.5 1.8 0s.5 1.3 0 1.8-1.3.5-1.8 0-.5-1.3 0-1.8Z" fill="currentColor" stroke="none" />
			<circle cx="8" cy="3.8" r=".85" fill="currentColor" stroke="none" />
			<circle cx="10.7" cy="5.1" r=".85" fill="currentColor" stroke="none" />
		</svg>
	);
}
