/**
 * Copyright (c) 2026 OG Hong — MIT. See LICENSE at the repository root.
 *
 * DSH theme controls, built on the shell's own theme service.
 *
 * Two things are deliberately kept apart:
 *
 *   - **Colour** goes through `ctx.theme.overrideTokens()`. That is the supported
 *     seam: the theme service folds named layers over the active palette, and the
 *     layout presenter writes the composed alias tokens onto `body`. We never set
 *     a `--dsw-*` variable ourselves, so a layer we remove leaves no residue and
 *     the shell's light/dark switch keeps working underneath ours.
 *   - **Glass** needs a `backdrop-filter` the token service cannot express. A small
 *     owned `<style>` in `document.head` carries it, scoped to the stable
 *     `data-composer-card` seat the conversation shell publishes. It is installed
 *     and removed with the plugin's fiber.
 *
 * Why the first version looked opaque, and what changed:
 *
 * DSH's desktop window is created with `vibrancy: "sidebar"` and a fully
 * transparent `backgroundColor`. Wallpaper can only show where the DOM paints
 * nothing. The center column paints `--dsw-alias-bg-base`, the composer paints
 * `--dsw-specific-input-major`, and the sidebar paints its tint — so writing
 * **solid** hex into any of those tokens blocks the wallpaper outright and leaves
 * three unrelated hues behind (purple centre, blue whale, grey card). The fix is
 * to keep every structural surface in one palette hue and give it alpha, so the
 * same wallpaper and ocean read through all of them.
 * @module ascii-sharks/theme
 */

import type { ConfigStore, OceanConfig } from "./store";

/** One token's two mandatory palette values, as the theme service requires. */
interface TokenPair {
	readonly light: string;
	readonly dark: string;
}

/** A named palette: the hue for surfaces, the accent, and its border colours. */
export interface Palette {
	readonly id: string;
	/** Structural surface colour in each mode. Never written as a solid in glass mode. */
	readonly base: TokenPair;
	/** One step raised above `base`, for nested surfaces. */
	readonly layer1: TokenPair;
	/** Two steps raised above `base`. */
	readonly layer2: TokenPair;
	/** Brand accent — buttons, switches, focus rings. */
	readonly accent: TokenPair;
	/** Subtle and strong borders. */
	readonly border1: TokenPair;
	readonly border2: TokenPair;
	/** RGB channels for the sidebar's top/bottom wash. */
	readonly wash: string;
}

export const PALETTES: readonly Palette[] = [
	{
		id: "default",
		base: { light: "#ffffff", dark: "#151517" },
		layer1: { light: "#f9fafb", dark: "#2c2c2e" },
		layer2: { light: "#f5f6f7", dark: "#3a3a3c" },
		accent: { light: "#3150e8", dark: "#7d9aff" },
		border1: { light: "#e5e7eb", dark: "#3a3a3c" },
		border2: { light: "#d1d5db", dark: "#55555a" },
		wash: "122 155 240",
	},
	{
		id: "ocean",
		base: { light: "#eef4fa", dark: "#0c1420" },
		layer1: { light: "#f8fbff", dark: "#16243a" },
		layer2: { light: "#e6f0fa", dark: "#203452" },
		accent: { light: "#1f7fb8", dark: "#4fc3f7" },
		border1: { light: "#d4e3ef", dark: "#233447" },
		border2: { light: "#b9d2e5", dark: "#33516a" },
		wash: "122 155 240",
	},
	{
		id: "midnight",
		base: { light: "#f3f1fb", dark: "#141120" },
		layer1: { light: "#fbfaff", dark: "#221d35" },
		layer2: { light: "#ebe6f7", dark: "#30294a" },
		accent: { light: "#6650d9", dark: "#a99bff" },
		border1: { light: "#ded7f0", dark: "#3a3357" },
		border2: { light: "#c8bde8", dark: "#514874" },
		wash: "143 137 184",
	},
	{
		id: "forest",
		base: { light: "#f0f7f1", dark: "#0e1712" },
		layer1: { light: "#f9fdfa", dark: "#1a2c21" },
		layer2: { light: "#e7f1e9", dark: "#28402f" },
		accent: { light: "#1f8a5b", dark: "#5fd6a0" },
		border1: { light: "#d5e8d9", dark: "#24402f" },
		border2: { light: "#b9d9c0", dark: "#345240" },
		wash: "110 180 130",
	},
	{
		id: "rose",
		base: { light: "#faf1f4", dark: "#1a1016" },
		layer1: { light: "#fff8fa", dark: "#2d1d26" },
		layer2: { light: "#f7e9ed", dark: "#412b38" },
		accent: { light: "#c1446b", dark: "#ff7ea8" },
		border1: { light: "#edd8df", dark: "#4a2f3c" },
		border2: { light: "#e0bcc8", dark: "#684455" },
		wash: "224 130 160",
	},
];

/** Palette ids, for the picker. */
export const PALETTE_IDS = PALETTES.map((p) => p.id);

/** Representative swatch colour for a palette dot in the picker. */
export function paletteSwatch(id: string): string {
	if (id === "default") return "#e8eaed";
	const p = PALETTES.find((x) => x.id === id);
	return p === undefined ? "#8a8a92" : p.accent.dark;
}

/** The only token a custom accent changes; everything else stays with the palette. */
const ACCENT_TOKEN = "--dsw-alias-brand-primary";

/** `color-mix` keeps the palette hue while letting the window's vibrancy through. */
const translucent = (hex: string, percent: number) =>
	`color-mix(in srgb, ${hex} ${percent}%, transparent)`;

/**
 * Build the complete override layer for one configuration.
 *
 * Without glass the palette is applied as solid colours — a normal theme change.
 * With glass, every surface that would otherwise hide the wallpaper is rewritten
 * as a translucent mix of that same palette hue, so the centre, the composer card
 * and the sidebar all read as one glass sheet over the desktop and the ocean.
 *
 * The dividing line the glass work settled on: **the frame is glass, the work is
 * not.** Navigation chrome, the sidebar and page backgrounds may let the wallpaper
 * through; anything you read — the diff reviewer, a terminal, a dialog, a code
 * block — gets an opaque surface, because a translucent page behind text is
 * unreadable. Four surfaces needed pinning for that rule to actually hold: dock
 * panes, code blocks (two separate paints — the block body token and the banner
 * wrapper), dialogs, and the frame header's hairline.
 *
 * Opaque is necessary but not sufficient: a code block painted the *same* colour
 * as the page is technically solid and visually invisible, which reads to a reader
 * as "still transparent". Anything that must look like a sheet needs a lightness
 * step away from the page, not just an alpha of 1.
 *
 * The split that finally settled it is by *role*, not by element:
 *
 *   - `bg-base`, the sidebar fill and the input fill are the page. They stay glass,
 *     because the wallpaper showing through is the whole point of the theme.
 *   - `bg-layer-1`, `bg-layer-2` and `bg-overlay` are everything that floats above
 *     the page: cards, popovers, menus, the file preview sheet. They are opaque and
 *     step up in lightness (3% / 7% / 11% white). A translucent popover has text
 *     from the page running through it, which is unreadable, not stylish.
 *
 * Note that this is a token split and not a selector list. The preview sheet the
 * reader kept seeing through carried a build-hashed class nobody could target
 * reliably; the token it painted had a name that could.
 */
export function buildThemeOverrides(config: OceanConfig): Record<string, TokenPair> {
	if (!config.themeEnabled) return {};
	const tokens: Record<string, TokenPair> = {};
	const palette = PALETTES.find((p) => p.id === config.palette) ?? PALETTES[0]!;

	// The accent is a control colour (buttons, switches, focus rings), so it stays
	// solid. The two hairline border levels do NOT: painting them solid turns every
	// 1px divider into a visible stroke. Stock DSH draws these at 6% and 12% white,
	// which reads as a whisper; a solid #514874 is roughly three times brighter and
	// makes a stray rule under a header stand out as a floating line. Glass mode
	// therefore keeps them as faint alpha strokes, and only strengthens them to the
	// palette hue in the opaque (non-glass) mode where a hard edge is wanted.
	tokens[ACCENT_TOKEN] = { ...palette.accent };

	const custom = /^#[0-9a-fA-F]{6}$/.test(config.accent) ? config.accent : undefined;
	if (custom !== undefined) tokens[ACCENT_TOKEN] = { light: custom, dark: custom };

	const mode = (pair: TokenPair, fn: (color: string) => string): TokenPair => ({
		light: fn(pair.light),
		dark: fn(pair.dark),
	});

	if (config.glass) {
		const a = config.glassAmount;
		// A linear map feels dead: at a=0.5 the surface is still 65% opaque, so
		// nothing visibly changes until the knob is nearly at the end. Ease the
		// response in fast — a=0.15 already reaches roughly half the full effect —
		// so the first third of the slider clearly shows the wallpaper.
		const eased = 1 - Math.pow(1 - a, 2.2);
		// 0 -> 88% (almost solid); 1 -> 30% (clearly glass). Most of the travel
		// happens early now, where the reader actually drags.
		const surface = Math.round(88 - eased * 58);
		// Sidebar tint thins fast for the same reason: heavy tint buries the
		// native vibrancy and reads as flat grey. At a=0.5 it is already ~14%.
		const tint = Math.round(34 - eased * 28);

		// **Two groups, split by role.**
		//
		// The page — base, sidebar fill, input fill — is one flat translucent colour.
		// Nothing in that group gets its own alpha: an earlier version stepped alpha
		// per level (40 / 46 / 50%), and because each step let a different fraction of
		// the wallpaper through, every level boundary drew a horizontal band over a
		// gradient backdrop (measured 14 → 18 in one tab bar). One alpha, no bands.
		//
		// Everything that floats above the page — layer-1, layer-2, overlay — is
		// opaque and steps up in *lightness* instead (3% / 7% / 11% white). This is
		// the part that several rounds of this work got wrong: those tokens are
		// shared, so keeping them translucent for a "flush" page turned every card,
		// popover and the file preview sheet into a window onto the text behind it.
		// A floating sheet has to be solid to be readable; it reads as a sheet
		// because it is lighter than the page, not because it is hard-edged.
		const flat = (colour: string) => translucent(colour, surface);
		const raised = (percent: number) => (colour: string) =>
			`color-mix(in srgb, #ffffff ${percent}%, ${colour})`;

		tokens["--dsw-alias-bg-base"] = mode(palette.base, flat);
		tokens["--dsw-alias-bg-layer-1"] = mode(palette.base, raised(3));
		tokens["--dsw-alias-bg-layer-2"] = mode(palette.base, raised(7));
		tokens["--dsw-alias-bg-overlay"] = mode(palette.base, raised(11));
		tokens["--dsw-specific-sidebar-fill"] = mode(palette.base, flat);

		// Code blocks and diffs are pages you read, so they are never glass. Their
		// colour also has to be published here and not left to the shell: the block
		// body reads a token that is translucent in dark mode, and its sticky banner
		// reuses the background token — which is the 40% mix below. Both would let the
		// conversation behind the block show through the code.
		tokens["--dsw-alias-markdown-code-block"] = mode(palette.base, (c) => `color-mix(in srgb, #000 26%, ${c})`);
		tokens["--dsw-alias-markdown-code-block-banner"] = mode(palette.base, (c) => `color-mix(in srgb, #000 26%, ${c})`);

		// Hairlines: the stock whisper. Levels 3 and 4 stay with the shell — card
		// strokes use l4, which must remain visible now that page surfaces are flat.
		tokens["--dsw-alias-border-l1"] = { light: "rgb(0 0 0 / 0.04)", dark: "rgb(255 255 255 / 0.04)" };
		tokens["--dsw-alias-border-l2"] = { light: "rgb(0 0 0 / 0.07)", dark: "rgb(255 255 255 / 0.07)" };
		tokens["--dsw-specific-input-major"] = mode(palette.base, flat);

		// Sidebar: DSH already blurs it natively. Just thin the tint and washes so
		// the material shows instead of being buried under an opaque fill.
		tokens["--dsw-specific-sidebar-tint"] = mode(palette.base, (c) => translucent(c, tint));
		tokens["--dsw-specific-sidebar-glass-fill"] = {
			light: `rgb(255 255 255 / ${(0.1 + a * 0.25).toFixed(2)})`,
			dark: `rgb(255 255 255 / ${(0.05 + a * 0.2).toFixed(2)})`,
		};
		tokens["--dsw-specific-sidebar-glass-hover"] = {
			light: `rgb(255 255 255 / ${(0.16 + a * 0.24).toFixed(2)})`,
			dark: `rgb(255 255 255 / ${(0.1 + a * 0.2).toFixed(2)})`,
		};
		tokens["--dsw-specific-sidebar-wash-top"] = {
			light: `rgb(${palette.wash} / ${(0.05 + a * 0.05).toFixed(2)})`,
			dark: `rgb(${palette.wash} / ${(0.04 + a * 0.06).toFixed(2)})`,
		};
		tokens["--dsw-specific-sidebar-wash-bottom"] = {
			light: `rgb(${palette.wash} / ${(0.04 + a * 0.05).toFixed(2)})`,
			dark: `rgb(${palette.wash} / ${(0.03 + a * 0.05).toFixed(2)})`,
		};
		const blur = Math.round(eased * 14);
		tokens["--dsh-ascii-glass-blur"] = {
			light: `${blur}px`,
			dark: `${blur}px`,
		};

		// One solid palette colour published as a custom property for the rules that
		// cannot be expressed as a token: the dock panes and the code-block fallback
		// in buildGlassCss read it. Dialogs do not — buildSettingsCss pins those to
		// the shell's stock neutrals with its own table, so a dialog stays neutral
		// regardless of the palette.
		tokens["--dsh-ascii-solid-base"] = { ...palette.base };
	} else {
		// Plain palette: solid surfaces, the ordinary "recolour the app" behaviour.
		tokens["--dsw-alias-bg-base"] = { ...palette.base };
		tokens["--dsw-alias-bg-layer-1"] = { ...palette.layer1 };
		tokens["--dsw-alias-bg-layer-2"] = { ...palette.layer2 };
		tokens["--dsw-specific-sidebar-fill"] = { ...palette.base };
		tokens["--dsw-alias-border-l1"] = { ...palette.border1 };
		tokens["--dsw-alias-border-l2"] = { ...palette.border2 };
	}
	return tokens;
}

/**
 * One alias token's stock DSH value in each mode.
 *
 * Values are lifted verbatim from DSH's own token sheets: the dark column is
 * `body[data-ds-dark-theme]`, the light column is the plain `body` block, and
 * every entry points at a `--dsw-static-*` entry or a literal alpha so the pin
 * follows the shell's light/dark switch instead of freezing one mode.
 */
interface NeutralToken {
	/** The alias the shell publishes. */
	readonly token: string;
	/** Stock value in light mode. */
	readonly light: string;
	/** Stock value in dark mode. */
	readonly dark: string;
}

/**
 * Every alias a shell pane reads, at its stock value, per mode.
 *
 * **Why the list is this long.** Custom properties are substituted where they
 * are *declared*, not where they are read. The shell declares
 * `--dsw-alias-settings-card-fill: var(--dsw-alias-bg-layer-2)` on `body`, so by
 * the time that value inherits into a dialog it is already a resolved colour:
 * re-pinning `--dsw-alias-bg-layer-2` alone changes nothing for a card that reads
 * `settings-card-fill`. A pin that only covers the tokens the palette happens to
 * override therefore leaves derived surfaces tinted while their neighbours go
 * stock. Covering the whole set is what makes a pinned dialog read as stock in
 * every part, not just where the palette reached.
 */
const NEUTRAL_TOKENS: readonly NeutralToken[] = [
	{ token: "--dsw-alias-bg-base", light: "var(--dsw-static-neutral-bluish-00)", dark: "var(--dsw-static-neutral-bluish-950)" },
	{ token: "--dsw-alias-bg-layer-1", light: "var(--dsw-static-neutral-bluish-00)", dark: "var(--dsw-static-neutral-bluish-875)" },
	{ token: "--dsw-alias-bg-layer-2", light: "var(--dsw-static-neutral-bluish-00)", dark: "var(--dsw-static-neutral-bluish-850)" },
	{ token: "--dsw-alias-bg-layer-3", light: "var(--dsw-static-neutral-bluish-00)", dark: "var(--dsw-static-neutral-bluish-800)" },
	{ token: "--dsw-alias-bg-module-platform", light: "var(--dsw-static-neutral-bluish-60)", dark: "var(--dsw-static-neutral-bluish-800)" },
	{ token: "--dsw-alias-bg-overlay", light: "var(--dsw-static-neutral-bluish-150)", dark: "var(--dsw-static-neutral-bluish-700)" },
	{ token: "--dsw-alias-border-l1", light: "#0000000a", dark: "#ffffff0f" },
	{ token: "--dsw-alias-border-l2", light: "#0000001a", dark: "#ffffff1f" },
	{ token: "--dsw-alias-border-l3", light: "#0000001f", dark: "#ffffff29" },
	{ token: "--dsw-alias-border-l4", light: "#00000029", dark: "#fff3" },
	{ token: "--dsw-alias-brand-primary", light: "var(--dsw-static-neutral-bluish-1000)", dark: "var(--dsw-static-neutral-bluish-50)" },
	{ token: "--dsw-alias-button-primary-fill", light: "var(--dsw-alias-brand-primary)", dark: "var(--dsw-alias-brand-primary)" },
	{ token: "--dsw-alias-interactive-bg-hover", light: "#2631480f", dark: "#ffffff14" },
	{ token: "--dsw-alias-label-dimmed", light: "var(--dsw-static-neutral-bluish-200)", dark: "var(--dsw-static-neutral-bluish-750)" },
	{ token: "--dsw-alias-label-primary", light: "var(--dsw-static-neutral-bluish-1000)", dark: "var(--dsw-static-neutral-bluish-50)" },
	{ token: "--dsw-alias-label-primary-foreground", light: "var(--dsw-static-neutral-bluish-00)", dark: "var(--dsw-static-neutral-bluish-1000)" },
	{ token: "--dsw-alias-label-secondary", light: "var(--dsw-static-neutral-bluish-700)", dark: "var(--dsw-static-neutral-bluish-300)" },
	{ token: "--dsw-alias-label-tertiary", light: "var(--dsw-static-neutral-bluish-600)", dark: "var(--dsw-static-neutral-bluish-400)" },
	{ token: "--dsw-alias-link", light: "var(--dsw-static-deepseek-500)", dark: "var(--dsw-static-deepseek-400)" },
	{ token: "--dsw-alias-settings-card-fill", light: "var(--dsw-alias-bg-layer-2)", dark: "var(--dsw-alias-bg-layer-2)" },
	{ token: "--dsw-alias-settings-card-stroke", light: "var(--dsw-alias-border-l4)", dark: "var(--dsw-alias-border-l4)" },
	{ token: "--dsw-alias-state-business-primary", light: "var(--dsw-static-deepseek-500)", dark: "var(--dsw-static-deepseek-400)" },
	{ token: "--dsw-alias-state-error-primary", light: "var(--dsw-static-red-600)", dark: "var(--dsw-static-red-400)" },
	{ token: "--dsw-alias-state-success-primary", light: "var(--dsw-static-green-500)", dark: "var(--dsw-static-green-500)" },
	{ token: "--dsw-alias-state-success-tertiary", light: "var(--dsw-static-green-100)", dark: "var(--dsw-static-green-900)" },
	{ token: "--dsw-alias-state-warn-primary", light: "var(--dsw-static-amber-500)", dark: "var(--dsw-static-amber-500)" },
	{ token: "--dsw-alias-state-warn-tertiary", light: "var(--dsw-static-amber-100)", dark: "var(--dsw-static-amber-900)" },
];

/**
 * Surfaces pinned to stock neutrals: the Settings panel and every blocking dialog.
 *
 * These are the only surfaces that must not take the palette, and the reason is
 * physical rather than stylistic — a modal sits on top of the conversation, so a
 * translucent dialog would show the transcript scrolling behind it. Opaque stock
 * chrome is what makes it readable.
 *
 * **The community plugin market is deliberately NOT here.** It is a page, not a
 * dialog: pinning it neutral made it an opaque near-black slab (measured
 * #151517/#2c2c2e) pasted onto a window whose glass surfaces read the wallpaper
 * through the palette (measured #20181 b tinted). Measured pixel jump across the
 * panel edge: 21→32 in red with no shared hue. A page has to take the same
 * material as its neighbours, so it follows the palette like the rest of the
 * shell. Lighter popovers are also left out.
 *
 * If a future surface is added here, ask first whether it floats over content
 * (pin it) or scrolls as a page (leave it to the palette).
 */
const NEUTRAL_SCOPES: readonly string[] = [
	'[data-shortcut-modal="settings"]',
	'[aria-modal="true"]',
];

/**
 * Neutralise the management surfaces against whatever the palette did to `body`.
 *
 * Two blocks, because the stock values differ per mode and the shell marks dark
 * with `body[data-ds-dark-theme]`. The dark block is emitted second so it wins
 * on the same zero-specificity `:where()` scheme.
 */
export function buildSettingsCss(): string {
	const block = (dark: boolean): string => {
		const scopePrefix = dark ? ":where(body[data-ds-dark-theme]) " : ":where(html) ";
		const selectors = NEUTRAL_SCOPES.map((scope) => scopePrefix + scope).join(",\n");
		const decls = NEUTRAL_TOKENS.map(
			({ token, light, dark: darkValue }) => `  ${token}: ${dark ? darkValue : light};`,
		).join("\n");
		return `${selectors} {\n${decls}\n}\n`;
	};
	return block(false) + block(true);
}

/** CSS the token service cannot express: the frosted-glass blur on the card. */
export function buildGlassCss(config: OceanConfig): string {
	if (!config.themeEnabled || !config.glass || config.glassAmount <= 0) return "";
	return `:where(html) [data-composer-card] {
  -webkit-backdrop-filter: blur(var(--dsh-ascii-glass-blur, 8px)) saturate(1.4);
  backdrop-filter: blur(var(--dsh-ascii-glass-blur, 8px)) saturate(1.4);
}
/* The sidebar column is the frame's first DOM child (DocumentTitle renders
   nothing; the drawer mask only exists in drawer mode, which we exclude). The
   frame is the parent of the stable [data-shell-overlay]. Blurring this column
   makes the wallpaper read through even when Electron's native vibrancy is
   unavailable or renders as flat grey. */
:where(html) :has(> [data-shell-overlay]):not([data-sidebar-drawer]) > :first-child {
  -webkit-backdrop-filter: blur(var(--dsh-ascii-glass-blur, 8px)) saturate(1.3);
  backdrop-filter: blur(var(--dsh-ascii-glass-blur, 8px)) saturate(1.3);
}
/* The community market paints the background token on every sticky layer
   (.head, .stickyHead, and a 14px ::before overhang) so content scrolling under
   them is hidden. That works while the token is opaque — stacked opaque paints are
   identical — but a translucent palette STACKS: two 43% layers composite to 67%,
   so wherever they overlap a denser band appears, and because the layers stick at
   different thresholds the band drifts against the content while scrolling. Drop
   their paint and let a backdrop blur do the hiding instead: one surface, no
   doubling, and what passes underneath stays unreadable. */
:where(html) [data-dsh-market-root] [class*="_head"],
:where(html) [data-dsh-market-root] [class*="_stickyHead"] {
  background: transparent;
  -webkit-backdrop-filter: blur(var(--dsh-ascii-glass-blur, 8px)) saturate(1.2);
  backdrop-filter: blur(var(--dsh-ascii-glass-blur, 8px)) saturate(1.2);
}
:where(html) [data-dsh-market-root] [class*="_stickyHead"]::before {
  background: transparent;
}
/* The conversation frame's top header carries a half-pixel bottom border in
   the level-3 border token. It spans the
   conversation column only — not the window — so once the page reads as one surface the
   rule reads as a stray line that stops in mid-air; and since the plugin market's
   sticky header slides beneath it, the line and the content drift apart while
   scrolling. Glass separates that header through the window chrome above it, not
   through a rule, so the rule goes. The data-window-drag attribute is its own
   semantic marker (it is what makes the strip draggable), which keeps this from
   depending on a hashed class name. */
:where(html) header[data-window-drag] {
  border-bottom-color: transparent;
}
/* Dock panes carry things you read: the file preview, the diff reviewer, terminals.
   They paint no background of their own and lean on the sidebar fill, so with a
   translucent sidebar the conversation behind them reads straight through the code
   — the diff becomes unreadable. Give every pane the palette's solid base. Glass is
   for the frame around the work, not for the page you are trying to read. */
:where(html) [data-dockkit-pane],
:where(html) [data-dockkit-float],
:where(html) [data-dockkit-content] {
  background: var(--dsh-ascii-solid-base, var(--dsw-alias-bg-base));
}
/* Code blocks and diffs inside a message.
   Two things were wrong before: the block body reads a token that is translucent,
   and its sticky banner wrapper repaints --dsw-alias-bg-base — the 40% glass mix —
   on top of it. Both are forced here. Note the fallback order: the *token* comes
   first on purpose. Painting these the flat page colour made the card technically
   opaque and visually invisible — same colour as the page, so no edge, and the code
   looked like it was sitting straight on the wallpaper. The token is deliberately
   darker than the page, which is what makes the sheet read as a sheet.
   isolation:isolate keeps any blend mode inside from picking up the page behind. */
:where(html) [data-code-wrap],
:where(html) [data-code-block-banner] {
  background-color: var(--dsw-alias-markdown-code-block, var(--dsh-ascii-solid-base, var(--dsw-alias-bg-base)));
  isolation: isolate;
}
@media (prefers-reduced-transparency: reduce) {
  :where(html) [data-composer-card],
  :where(html) :has(> [data-shell-overlay]):not([data-sidebar-drawer]) > :first-child {
    -webkit-backdrop-filter: none;
    backdrop-filter: none;
  }
}
`;
}

/**
 * Install the theme layer on the client context.
 *
 * `ctx.inject` matches the locale pattern in `entry.ts`: the theme service is
 * provided by DSH's own plugin and can activate after this one, so waiting for it
 * here avoids a one-shot miss on a cold page load. The returned disposer is kept
 * by the owning fiber, which removes the layer and the style tag together.
 */
export function applyTheme(ctx: any, store: ConfigStore): void {
	ctx.inject(["theme"], (themeCtx: any) => {
		const theme = themeCtx.get("theme");
		if (theme === undefined || theme === null) return;

		let disposeLayer: (() => void) | undefined;
		let glassStyle: HTMLStyleElement | undefined;

		// The settings-panel neutral pin is unconditional and installed once.
		const settingsStyle = document.createElement("style");
		settingsStyle.dataset.plugin = "dsh-theme";
		settingsStyle.dataset.pluginCss = "dsh-theme/settings";
		settingsStyle.textContent = buildSettingsCss();
		document.head.appendChild(settingsStyle);

		const apply = (config: OceanConfig) => {
			// Replacing a layer with the same source restacks it; disposing first
			// keeps the number of live layers at one even during rapid slider drags.
			disposeLayer?.();
			disposeLayer = undefined;
			const tokens = buildThemeOverrides(config);
			if (Object.keys(tokens).length > 0) {
				try {
					disposeLayer = theme.overrideTokens("dsh-theme", tokens);
				} catch (error) {
					console.warn("dsh-theme: theme override rejected", error);
				}
			}

			const css = buildGlassCss(config);
			if (css !== "") {
				if (glassStyle === undefined) {
					glassStyle = document.createElement("style");
					glassStyle.dataset.plugin = "dsh-theme";
					glassStyle.dataset.pluginCss = "dsh-theme/glass";
					document.head.appendChild(glassStyle);
				}
				glassStyle.textContent = css;
			} else {
				glassStyle?.remove();
				glassStyle = undefined;
			}
		};

		apply(store.getSnapshot());
		const unsubscribe = store.subscribe(() => apply(store.getSnapshot()));
		return () => {
			unsubscribe();
			disposeLayer?.();
			glassStyle?.remove();
			settingsStyle.remove();
		};
	});
}
