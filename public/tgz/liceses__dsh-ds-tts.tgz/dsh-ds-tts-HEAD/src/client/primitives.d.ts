/**
 * `@deepseek-ai/dsh-client-ui-primitives` 的类型 shim。
 *
 * 为什么还留着它：这个包是**运行时由壳提供的平台模块**（client 基线模块表的静态键），
 * 本仓库刻意不把它写进 dependencies（见 package.json 的 `dsh._note` 与 .npmrc），
 * 类型只能靠 `npm run link-sdk` / `tools/link-sdk-all.mjs` 在 node_modules 下落的副本。
 * 早期它在本机是**悬空 junction**（有目录、无 package.json），磁盘上没有实体可解析类型；
 * 这份 shim 保证在"还没链 SDK"的 checkout 里也能让 tsc 把图标名当模块导出解析。
 *
 * 名字真值表来自 0.1.7-rc.2 的 `upgrade/icons-0.1.7.json`：
 * 0.1.7 **整族改名** `Icon<名><Outline|Fill><尺寸>` → `Icon<名>Regular`（1px）/ `Icon<名>Medium`（1.3px），
 * **没有任何带尺寸后缀的导出幸存**（实测 legacySizedExports = []，188 个导出 / 88 个字形）。
 * 下面五个的 defaultSize 都是 16，与旧 `*16` 后缀一致，所以调用处不需要 `size` 补偿。
 *
 * 运行时仍做存在性检查（见 icons.tsx 的 `pick()`）：名字一旦对不上就退到内联图标，
 * 绝不因一个图标名白屏。但 `pick()` 是**静默回退**，所以"名字是否真的存在"这件事
 * 由 `test/ui-tokens.test.mjs` 真正断言（读已安装包的 `lib/types/icons/index.d.ts`）。
 *
 * 顺带记录：官方图标集**没有**喇叭/音量类图标；朗读那两个图标改用 DS 网页端自带的素材（见 icons.tsx 的 SpeakerGlyph / PlayingBars）。
 */
declare module '@deepseek-ai/dsh-client-ui-primitives' {
  import type { ReactElement, SVGProps } from 'react'

  /** 官方图标组件的 props（本插件只当普通 svg 属性用）。 */
  export type OfficialIconProps = SVGProps<SVGSVGElement>

  /** 一个官方图标组件。 */
  export type OfficialIcon = (props: OfficialIconProps) => ReactElement

  export const IconStopFillRegular: OfficialIcon
  export const IconLoadingOutlineRegular: OfficialIcon
  export const IconDownloadOutlineRegular: OfficialIcon
  export const IconRefreshOutlineRegular: OfficialIcon
  export const IconCloseOutlineRegular: OfficialIcon
}
