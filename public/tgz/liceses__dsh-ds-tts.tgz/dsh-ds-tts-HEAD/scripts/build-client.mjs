/**
 * 构建浏览器半：src/client/index.ts → lib/client.js。
 *
 * 产物形态必须与 dsh-client-modules 的加载契约一致：
 *   window.__ModuleLoader__.load({ id: <包名>, factory: (require) => { ... } })
 * 其中 `id` 必须**严格等于 package.json 的包名**（dsh-client-modules 用包名作为
 * 图行 id 与 /plugins/<id>/client.js 的 id，不匹配会在启动时报
 * "bundle ... loaded without registering ..."）。
 *
 * 平台模块（react / slots / renderer / primitives）保持 external —— 由浏览器侧冻结的
 * 模块表（client 基线 PLATFORM_MODULES）提供。
 */
import { build } from 'esbuild'
import { fileURLToPath } from 'node:url'
import { readFileSync, mkdirSync } from 'node:fs'

const root = fileURLToPath(new URL('..', import.meta.url))
mkdirSync(root + 'lib', { recursive: true })

const pkg = JSON.parse(readFileSync(root + 'package.json', 'utf8'))
const PLUGIN_ID = pkg.name

const PLATFORM_MODULES = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  // 0.1.7：`@deepseek-ai/dsh-client-runtime` 整个包已不存在（最后发布 0.1.1-rc.2）。
  // 它的 Web 客户端继任者是 `@deepseek-ai/dsh-client-ui-renderer` 的 `/client` 半边
  // （把 ctx.slots / ctx.uiRenderer 挂到 cordis 的 Context 上）。
  // 本插件对它是 **type-only** import，产物里不会出现 require；列在这里是为了将来真的
  // 运行时 import 时依旧保持 external。
  '@deepseek-ai/dsh-client-ui-renderer/client',
  '@deepseek-ai/dsh-client-ui-slots',
  // 官方图标在这个平台模块里（官方 bundle 也是以该说明符从模块表取它）。
  // 它是 client 基线模块表的静态键，所以**不需要**写进 package.json 的 dsh.client.external。
  // 本机类型见 src/client/primitives.d.ts 的 shim，
  // 运行时在 icons.tsx 里做存在性检查 + 内联兜底。
  '@deepseek-ai/dsh-client-ui-primitives',
]

const result = await build({
  entryPoints: [root + 'src/client/index.ts'],
  outfile: root + 'lib/client.js',
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: ['es2020'],
  sourcemap: true,
  logLevel: 'warning',
  external: PLATFORM_MODULES,
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
  },
  banner: {
    js:
      `window.__ModuleLoader__.load({ id: ${JSON.stringify(PLUGIN_ID)}, factory: (require) => {\n` +
      'var module = { exports: {} }; var exports = module.exports;',
  },
  footer: {
    js: 'return module.exports; } });',
  },
})

if (result.errors.length > 0) process.exit(1)
console.log(`client bundle written to lib/client.js (id=${PLUGIN_ID})`)
