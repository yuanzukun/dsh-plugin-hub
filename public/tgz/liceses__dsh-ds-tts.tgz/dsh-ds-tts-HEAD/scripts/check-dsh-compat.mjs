#!/usr/bin/env node
/**
 * check-dsh-compat.mjs — 用**真实运行时的闸门函数**判定本插件还能不能被 DSH 加载。
 *
 * ## 为什么需要它
 *
 * DSH 启动期会调用 `evaluatePluginCompatibility(manifest)`，把插件 `peerDependencies`
 * 里的 `@deepseek-ai/dsh-*` 范围与**运行时版本**比对，不满足就**拒绝加载**（profile 里
 * 那句 `dsh: skipping profile bundle "…": Plugin … is incompatible with dsh …`）。
 *
 * 这个检查有两个反直觉的地方，踩过一次就会记牢：
 *
 *   1. `engines.dsh` **不参与**闸门 —— 只有 `peerDependencies` 里的 `@deepseek-ai/dsh-*` 算数。
 *   2. **caret + 预发布版会踩上界**：`^0.1.7-rc.1` 的语义是 `>=0.1.7-rc.1 <0.2.0`，
 *      所以运行时一旦是 `0.2.x` 就必然失败。跨小版本要写**显式区间** `>=A <B`。
 *
 * 所以这里直接**复用 dsh 自己的判定函数**，而不是自己重写一套 semver 逻辑 ——
 * 自己写的实现一旦与上游不一致，就会给出"能过"的假承诺。
 *
 * ## 用法
 *
 *   npm run check:dsh
 *
 * 退出码 0 = 兼容；1 = 会被拒（或找不到 dsh）。
 */
import { existsSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const root = resolve(fileURLToPath(new URL('..', import.meta.url)))
const require = createRequire(join(root, 'package.json'))

/**
 * 找到本机安装的 `dsh-app-boot`（闸门函数 + 运行时版本常量都在里面）。
 * @returns {string | undefined} 绝对路径。
 */
function locateAppBoot() {
  const candidates = []
  // ① 从本仓库解析（SDK 镜像链接进来时可能命中）
  try {
    candidates.push(require.resolve('@deepseek-ai/dsh-app-boot/lib/index.js'))
  } catch {
    /* 没装就是没有 */
  }
  // ② npm 全局安装的 dsh
  for (const prefix of [process.env.APPDATA, process.env.LOCALAPPDATA]) {
    if (prefix === undefined || prefix === '') continue
    candidates.push(
      join(prefix, 'npm', 'node_modules', '@deepseek-ai', 'dsh', 'node_modules', '@deepseek-ai', 'dsh-app-boot', 'lib', 'index.js'),
    )
  }
  // ③ $DSH_HOME 下的运行时副本
  const dshHome = process.env.DSH_HOME ?? join(process.env.USERPROFILE ?? '', '.dsh')
  candidates.push(join(dshHome, 'dsh-runtimes', 'dsh-primary-runtime', 'node_modules', '@deepseek-ai', 'dsh-app-boot', 'lib', 'index.js'))
  return candidates.find((c) => existsSync(c))
}

const appBoot = locateAppBoot()
if (appBoot === undefined) {
  console.error('[check-dsh] 找不到本机安装的 @deepseek-ai/dsh-app-boot，无法判定兼容性。')
  console.error('            请先安装 dsh（或设置 APPDATA / DSH_HOME 指向它）。')
  process.exit(1)
}

const { evaluatePluginCompatibility } = await import(pathToFileURL(appBoot).href)
if (typeof evaluatePluginCompatibility !== 'function') {
  console.error(`[check-dsh] ${appBoot} 没有导出 evaluatePluginCompatibility —— 上游 API 变了，请更新本脚本。`)
  process.exit(1)
}

const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))

// 运行时版本：优先用 dsh 自己的 package.json（与闸门里的常量同源）
let runtimeVersion
try {
  // appBoot = <dsh>/node_modules/@deepseek-ai/dsh-app-boot/lib/index.js
  // 往上四层才是 <dsh>/package.json：lib → dsh-app-boot → @deepseek-ai → node_modules → dsh
  const dshPkgPath = join(dirname(appBoot), '..', '..', '..', '..', 'package.json')
  runtimeVersion = JSON.parse(readFileSync(dshPkgPath, 'utf8')).version
} catch {
  runtimeVersion = undefined
}

const issue = evaluatePluginCompatibility(pkg, {}, runtimeVersion)

if (issue === undefined) {
  console.log(`[check-dsh] ✅ ${pkg.name}@${pkg.version} 与 dsh ${runtimeVersion ?? '(运行时默认)'} 兼容`)
  process.exit(0)
}

console.error(`[check-dsh] ❌ ${issue.name}@${issue.version} 与 dsh ${issue.runtimeVersion} 不兼容`)
for (const [name, range] of Object.entries(issue.requirements)) {
  console.error(`             ✗ ${name} 要求 ${range}`)
}
console.error('')
console.error('  修法：把这些范围改成**显式区间**，例如')
console.error('        ">=0.1.7-rc.1 <0.3"')
console.error('        （不要用 caret —— 预发布版的上界会卡住下一个次版本）')
process.exit(1)
