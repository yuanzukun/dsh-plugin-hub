/**
 * 补全端点的注册与提供方解析。
 *
 * 单独成模块而不是塞进 routes.ts：这条链路有自己的提供方选择与流式收尾，放在一起会让两边都变难读。
 * 复用 routes.ts 已有的 authorize / readBody / send 辅助函数，由调用方传进来，不重复实现。
 */
import { normalize } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { DEFAULT_COMPLETION_PARAMS, type CompletionParams } from './params.ts'
import { encodeSseEvent, type CompletionEvent, type CompletionRequest } from './protocol.ts'
import { dshProvider, type DshDefaultModelService, type DshLlmService } from './dshProvider.ts'
import type { CompletionProvider } from './provider.ts'
import { INSTRUCTION_PROMPT_PROFILE, type PromptProfile } from './prompt.ts'
import { runCompletion } from './service.ts'
import { noteCompletion } from './diagnostics.ts'
import { WorkspaceIndex } from './workspaceIndex.ts'
import type { SecurityHit } from './security.ts'
import { groupForSession, paramsForGroup } from './experiment.ts'
import { TelemetryAggregator } from './telemetry.ts'
import { appendFile } from 'node:fs/promises'
import path from 'node:path'

/** 只是把 cordis 的可选服务读取收窄到本模块需要的形状。 */
interface CompletionContextLike { get(name: string): unknown }

interface ResolvedCompletionProvider {
  provider: CompletionProvider
  profile: PromptProfile
  source: 'dsh'
  model: string
}

/**
 * 补全只有一条路：DSH 的当前默认模型。
 *
 * 自定义路由、OpenAI 兼容端点与本地兜底都已移除。模型不可用时直接报错，由用户自己在 DSH 里换模型；
 * 插件不做静默降级，也不猜哪条路还能用。
 */
export function resolveProvider(ctx: CompletionContextLike, params: CompletionParams = DEFAULT_COMPLETION_PARAMS): ResolvedCompletionProvider {
  const llm = ctx.get('llm') as DshLlmService | undefined
  const defaultModel = ctx.get('agentDefaultModel') as DshDefaultModelService | undefined
  if (llm === undefined || defaultModel === undefined) throw new Error('DSH 模型服务不可用，请先在 DSH 设置里选择模型')
  const provider = dshProvider(llm, defaultModel, { params })
  return { provider, profile: INSTRUCTION_PROMPT_PROFILE, source: 'dsh', model: provider.model }
}


/** 客户端从请求体里取出的必要字段；缺一不可，缺就按 400 处理。 */
function readRequest(body: unknown): CompletionRequest {
  if (typeof body !== 'object' || body === null) throw new Error('request body must be an object')
  const candidate = body as Partial<CompletionRequest>
  const cursor = candidate.cursor
  if (cursor === undefined || typeof cursor.document !== 'string' || typeof cursor.filePath !== 'string') throw new Error('cursor.document and cursor.filePath are required')
  if (typeof candidate.language !== 'string' || candidate.language === '') throw new Error('language is required')
  if (cursor.rewriteAt === undefined || typeof cursor.rewriteAt.line !== 'number' || typeof cursor.rewriteAt.column !== 'number') throw new Error('cursor.rewriteAt is required')
  return {
    sessionId: typeof candidate.sessionId === 'string' ? candidate.sessionId : '',
    environment: candidate.environment ?? { ideVersion: '', extensionVersion: '', region: '', channel: '', repository: '' },
    language: candidate.language,
    trigger: candidate.trigger === 'other' ? 'other' : 'inline',
    edits: Array.isArray(candidate.edits) ? candidate.edits : [],
    cursor: { filePath: cursor.filePath, rewriteAt: cursor.rewriteAt, document: cursor.document, ...(cursor.lastEdit === undefined ? {} : { lastEdit: cursor.lastEdit }) },
    diagnostics: Array.isArray(candidate.diagnostics) ? candidate.diagnostics : [],
    forceRewrite: candidate.forceRewrite === true,
    ...(candidate.intent === undefined ? {} : { intent: candidate.intent }),
    ...(candidate.security === undefined ? {} : { security: candidate.security }),
  }
}

interface CompletionRouteHelpers {
  /** 复用宿主 connection 服务的认证结果；返回 false 时已经写好 401/403 响应。 */
  authorize(req: IncomingMessage, res: ServerResponse): boolean
  readBody(req: IncomingMessage): Promise<unknown>
  send(res: ServerResponse, status: number, payload: unknown): void
  sendError(res: ServerResponse, error: unknown): void
  /** 把会话解析成工作区根目录：索引按项目分库，检索要按同一个根目录进行。 */
  cwdFor(sessionId: string): string
}

/**
 * 注册 `POST /dsh-vscode/completion`。
 *
 * 事件以 SSE 写出：meta → output* → done。客户端断开时中止上游 —— 这是文档 4.1 的硬要求，
 * 否则用户在连续输入时会把在途连接堆起来。
 */
export function registerCompletionRoute(ctx: CompletionContextLike & { effect(run: () => void, label?: string): void; webServer: { register(route: { kind: 'exact'; path: string; handler(req: IncomingMessage, res: ServerResponse): void | Promise<void> }): () => void } }, helpers: CompletionRouteHelpers, params: CompletionParams = DEFAULT_COMPLETION_PARAMS): void {
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: '/dsh-vscode/completion',
    handler: async (req, res) => {
      if (!helpers.authorize(req, res)) return
      if (req.method !== 'POST') return helpers.send(res, 405, { ok: false, error: { code: 'method', message: 'POST required' } })
      let request: CompletionRequest
      try {
        request = readRequest(await helpers.readBody(req))
      } catch (error) {
        return helpers.send(res, 400, { ok: false, error: { code: 'bad-request', message: error instanceof Error ? error.message : String(error) } })
      }

      const controller = new AbortController()
      req.once('aborted', () => controller.abort())
      // 流式响应下 'close' 才是可靠的断开信号：客户端取消、切页、关标签都会走到这里。
      res.once('close', () => controller.abort())

      // 分组由服务端决定并按会话稳定分配（文档 4.3、七）：写回环境元数据后再往下走，
      // 这样 meta 事件、埋点与日志看到的是同一个分组。
      noteCompletion(`请求到达 session=${request.sessionId.slice(0, 20)} language=${request.language} file=${request.cursor.filePath}`)
      const experiment = groupForSession(request.sessionId)
      const tuned = { ...request, environment: { ...request.environment, experiment } }
      const groupParams = paramsForGroup(experiment)
      let resolved: ResolvedCompletionProvider
      try {
        resolved = resolveProvider(ctx, groupParams)
      } catch (error) {
        return helpers.send(res, 503, { ok: false, error: { code: 'ai-unavailable', message: error instanceof Error ? error.message : String(error) } })
      }
      const cwd = safeCwd(ctx, helpers, request.sessionId)
      // 解析不到工作区就不注入片段（文档把检索列为可选上下文来源）：好过索引错目录。
      //
      // 索引加载/构建可能要几十毫秒（大工作区首次 open 要解析 index.json）。响应头不该等它：
      // 先把 SSE 头送出去，再在响应内部等索引；事件序列保持 meta → output* → done 不变，
      // 也不额外插入心跳事件（客户端解析只认这几种事件）。
      const indexPromise: Promise<WorkspaceIndex> | undefined = cwd === undefined ? undefined : completionIndexFor(cwd, groupParams)
      res.writeHead(200, {
        'content-type': 'text/event-stream; charset=utf-8',
        'cache-control': 'no-cache, no-transform',
        connection: 'keep-alive',
        'x-accel-buffering': 'no',
      })
      try {
        res.flushHeaders()
      } catch {
        // 连接在下发响应头前就断了：没有可写的对端，直接结束这次请求。
        return
      }
      let index: WorkspaceIndex | undefined
      if (indexPromise !== undefined) {
        try {
          index = await indexPromise
        } catch (error) {
          // 索引不可用时按「没有片段」继续：检索本来就是可选上下文，不能让它拖垮补全。
          noteCompletion(`索引不可用，按无检索上下文继续：${error instanceof Error ? error.message : String(error)}`)
        }
      }
      try {
        let candidateCount = 0
        let firstByteMs: number | undefined
        for await (const event of runCompletion(tuned, {
          provider: resolved.provider, params: groupParams, profile: resolved.profile, signal: controller.signal,
          // 索引没就绪就先不注入片段：刷新在后台跑，补全不等它。
          ...(index === undefined ? {} : { retrieve: (current: CompletionRequest) => index.retrieve(current) }),
          // 解析不到工作区时不写审计文件：不要往未知目录里落东西。
          ...(cwd === undefined ? {} : { onSecurityHit: (hit: SecurityHit, current: CompletionRequest) => { appendSecurityAudit(cwd, hit, current) } }),
        })) {
          if (event.type === 'output') {
            for (const candidate of event.candidates) {
              candidateCount = Math.max(candidateCount, candidate.index + 1)
              firstByteMs ??= candidate.elapsedMs
            }
          }
          if (res.writableEnded) break
          res.write(encodeSseEvent(event))
        }
        // 给出过候选才算一次「展示」：采纳率的分母是它。
        if (candidateCount > 0) {
          noteCompletion(`产出候选 ${candidateCount} 条，首字节 ${firstByteMs ?? -1} ms，模型=${resolved.model}`)
          completionTelemetry.record({ kind: 'shown', sessionId: request.sessionId, language: request.language, model: resolved.model, experiment, ...(firstByteMs === undefined ? {} : { firstByteMs }), candidateCount })
        }
      } catch (error) {
        noteCompletion(`失败 ${error instanceof Error ? error.message : String(error)}`)
        const failure: CompletionEvent = { type: 'error', code: 'completion-failed', message: error instanceof Error ? error.message : String(error) }
        if (!res.writableEnded) res.write(encodeSseEvent(failure))
      } finally {
        if (!res.writableEnded) res.end()
      }
    },
  }), 'dsh-aide: inline completion')
}

/** 补全埋点聚合器（文档七：采纳率为主指标）。进程内保存，重启即清零。 */
export const completionTelemetry = new TelemetryAggregator()

/**
 * 内容安全审计（文档 6.4：拦截与脱敏两种动作都要写入审计日志）。
 *
 * 写在索引同一个工作区目录下（那里已经被索引自带的 .gitignore 排除），一行一条，便于事后追查。
 * 落盘失败不影响补全：审计是旁路，不能因为它把补全拖垮。
 */
function appendSecurityAudit(cwd: string, hit: SecurityHit, request: CompletionRequest): void {
  const line = JSON.stringify({ at: new Date().toISOString(), action: hit.action, ruleId: hit.ruleId, ruleName: hit.ruleName, sessionId: request.sessionId, filePath: request.cursor.filePath, language: request.language }) + '\n'
  void appendFile(path.join(cwd, '.dsh-workbench', 'audit.jsonl'), line, 'utf8').catch(() => undefined)
}

/** 每个工作区一份索引，进程内复用；索引文件本身由 WorkspaceIndex 落到工作区里。 */
const indexes = new Map<string, Promise<WorkspaceIndex>>()

export function completionIndexFor(cwd: string, params: CompletionParams = DEFAULT_COMPLETION_PARAMS): Promise<WorkspaceIndex> {
  const existing = indexes.get(cwd)
  if (existing !== undefined) return existing
  let created: Promise<WorkspaceIndex>
  created = WorkspaceIndex.open({ root: cwd, params }).then(index => {
    // 首次或过期时在后台刷新，补全请求不等它。
    void index.ensureFresh()?.catch(() => undefined)
    return index
  }).catch(error => {
    // 失败的 promise 不能永久留在缓存里：否则这个工作区之后的每次请求都会拿到同一个失败。
    if (indexes.get(cwd) === created) indexes.delete(cwd)
    throw error
  })
  indexes.set(cwd, created)
  return created
}

/**
 * 解析这次补全该在哪个工作区里检索。
 *
 * 优先用请求里的会话；会话号对不上（例如接口探针传的是占位值）时退到任一已知会话的工作区；
 * 都拿不到就返回 undefined，由调用方跳过检索。**不能退到进程目录**：桌面端进程的工作目录是
 * 应用自己的目录，索引它既白扫一遍，又会让检索永远命中无关内容。
 */
function safeCwd(ctx: CompletionContextLike, helpers: CompletionRouteHelpers, sessionId: string): string | undefined {
  const sessions = ctx.get('sessions') as
    | { get(id: string): { header?: { cwd?: string } } | undefined; list(): readonly { header?: { cwd?: string } }[] }
    | undefined
  const own = sessions?.get(sessionId)?.header?.cwd
  if (own !== undefined && own !== '') {
    try {
      return helpers.cwdFor(sessionId)
    } catch {
      return normalize(own)
    }
  }
  for (const session of sessions?.list() ?? []) {
    const cwd = session?.header?.cwd
    if (cwd !== undefined && cwd !== '') return normalize(cwd)
  }
  return undefined
}
