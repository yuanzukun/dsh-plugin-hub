import type { TerminalInfo, TerminalProfile } from '../terminal.ts'
import { ApiError, currentHostBase, normalizeHostBase, withSessionRetry } from './api.ts'

interface TerminalConnection {
  write(data: string): void
  resize(cols: number, rows: number): void
  close(): void
  subscribe(listener: (output: { sequence: number; data: string; replay?: boolean }) => void): () => void
}

interface TerminalWorkspaceSnapshot { terminals: readonly TerminalInfo[]; loading: boolean; error?: string }

/** 一次「新建终端」的请求：可带工作区相对目录（在终端中打开）与 shell 档位。 */
export interface TerminalRequest { directory?: string; profile?: string; title?: string }

/**
 * 待处理的新建请求。
 *
 * 为什么需要排队：菜单里点「在终端中打开」时底部面板可能还没挂载（React 的状态更新是异步的），
 * 同步派发的事件会落在空处，表现为「点了没反应」。队列让「请求」与「谁来执行」解耦：
 * 面板挂载后先 drain 一次，之后的请求由事件唤醒。
 */
const pendingTerminalRequests: TerminalRequest[] = []

/**
 * 请求新建一个终端；面板不在时先排队，挂载后自动补建。
 *
 * 同时派发两个事件：
 *   - `dvw-terminal-show`：让工作台把底部面板切到终端（这一层由 Workbench 负责，它持有 overlay 状态）；
 *   - `dvw-terminal-new`：通知已挂载的终端面板去取队列。
 * 分开是因为「把面板打开」与「建终端」在被调用方眼里是两件事：面板没挂载时，后一个事件没人听。
 */
export function requestTerminal(request: TerminalRequest = {}): void {
  pendingTerminalRequests.push(request)
  window.dispatchEvent(new Event('dvw-terminal-show'))
  window.dispatchEvent(new Event('dvw-terminal-new'))
}

/** 取走当前排队的请求（由终端面板在挂载后与每次事件时调用）。 */
export function takeTerminalRequests(): TerminalRequest[] { return pendingTerminalRequests.splice(0) }

/** Browser client for the workbench's local terminal transport. */
interface TerminalWorkspace {
  refresh(): Promise<void>
  /** `directory` 是工作区相对路径：新的 shell 直接在该目录里启动（「在终端中打开」）。 */
  create(options?: { title?: string; profile?: string; directory?: string }): Promise<TerminalInfo>
  /**
   * 预热默认 shell。
   *
   * 面板打开时先把 shell 起好（宿主侧，见 TerminalManager.prewarm），点「新建终端」时它已经
   * 在回放缓冲里放着提示符了 —— shell 自身的 0.5s 级启动成本被提前到用户看面板的空档里。
   * 失败无所谓：下一次 create 会照常现起一个 shell。
   */
  prewarm(): Promise<void>
  close(id: string): Promise<void>
  rename(id: string, title: string): Promise<void>
  connect(id: string): TerminalConnection
  getSnapshot(): TerminalWorkspaceSnapshot
  subscribe(listener: () => void): () => void
}

/**
 * 拼出终端 WebSocket 的地址（地址来源与回退规则见 api.ts 的 hostWebSocketUrl）。
 *
 * 保留 `wsBase` 入参：终端 API 自己也会带回一次地址，优先用它，免得依赖"之前有没有别的
 * API 调用过"。两条来源最终都进同一个归一化逻辑。
 */
function webSocketUrl(sessionId: string, id: string, wsBase?: string): string {
  const base = normalizeHostBase(wsBase) ?? normalizeHostBase(currentHostBase())
  const search = `sessionId=${encodeURIComponent(sessionId)}&id=${encodeURIComponent(id)}`
  if (base !== undefined) return `${base}/dsh-vscode-terminal/ws?${search}`
  const protocol = location.protocol === 'https:' ? 'wss' : 'ws'
  return `${protocol}://${location.host}/dsh-vscode-terminal/ws?${search}`
}

interface HostAnswer<T> { ok?: boolean; value?: T; wsBase?: string; error?: { code?: string; message?: string } }

/**
 * 终端请求。会话刚创建时宿主可能还没登记（启动期竞态），与文件树同一策略重试；
 * 因此这里必须保留错误码，否则那条竞态会被当成普通错误直接显示给用户。
 */
async function request<T>(method: string, body: Record<string, unknown>): Promise<{ value: T; wsBase?: string }> {
  return withSessionRetry(async () => {
    const response = await fetch(`/dsh-vscode-terminal/api/${method}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
    const text = await response.text()
    let answer: HostAnswer<T>
    try { answer = JSON.parse(text) as HostAnswer<T> } catch { throw new Error(`terminal request returned invalid JSON (${response.status})`) }
    if (!response.ok || answer.ok !== true) throw new ApiError(answer.error?.code ?? 'request-failed', answer.error?.message ?? 'terminal request failed')
    return { value: answer.value as T, wsBase: typeof answer.wsBase === 'string' ? answer.wsBase : undefined }
  })
}

/**
 * 取宿主探测到的可选 shell 列表。
 *
 * 独立于控制器导出，因为「新建终端」菜单在面板头部，那里没有控制器的实例；
 * 而这份列表只取决于机器上装了什么，与当前终端集合无关。
 */
export async function terminalProfiles(sessionId: string): Promise<TerminalProfile[]> {
  const answer = await request<TerminalProfile[]>('profiles', { sessionId })
  return answer.value
}

class SocketConnection implements TerminalConnection {
  private readonly socket: WebSocket
  private readonly listeners = new Set<(output: { sequence: number; data: string; replay?: boolean }) => void>()
  private queue: string[] = []

  constructor(sessionId: string, id: string, wsBase?: string) {
    this.socket = new WebSocket(webSocketUrl(sessionId, id, wsBase))
    this.socket.onopen = () => { for (const value of this.queue) this.socket.send(value); this.queue = [] }
    this.socket.onmessage = event => {
      try {
        const value = JSON.parse(String(event.data)) as { type?: unknown; sequence?: unknown; data?: unknown }
        if (typeof value.sequence !== 'number' || typeof value.data !== 'string') return
        for (const listener of this.listeners) listener({ sequence: value.sequence, data: value.data, replay: value.type === 'replay' })
      } catch { /* Ignore malformed WebSocket messages from a disconnected server. */ }
    }
  }

  private send(value: unknown): void { const text = JSON.stringify(value); if (this.socket.readyState === WebSocket.OPEN) this.socket.send(text); else this.queue.push(text) }
  write(data: string): void { this.send({ type: 'input', data }) }
  resize(cols: number, rows: number): void { this.send({ type: 'resize', cols, rows }) }
  close(): void { this.socket.close() }
  subscribe(listener: (output: { sequence: number; data: string; replay?: boolean }) => void): () => void { this.listeners.add(listener); return () => this.listeners.delete(listener) }
}

/** Identify automatic terminal-emulator replies that must not be echoed during replay. */
export function isTerminalProtocolReply(data: string): boolean {
  return /^\x1b\](?:10|11|12);(?:rgb:[\da-f]{4}\/[\da-f]{4}\/[\da-f]{4}|#[\da-f]{6})(?:\x07|\x1b\\)$/i.test(data)
    || /^\x1b\[\??[\d;]*[cR]$/.test(data)
}

// ---------------------------------------------------------------------------
// 预热意图（悬停/聚焦「新建终端」）
// ---------------------------------------------------------------------------

/** 按钮派发、终端面板监听的「预热意图」事件名。 */
export const TERMINAL_PREWARM_EVENT = 'dvw-terminal-prewarm'
/**
 * 意图的有效期。
 *
 * 悬停后这么久之内，「新建终端」都算有明确意图（指针离开**不**清除意图：用户可能移开又移回来）。
 * 超过这个窗口，之后终端数量变化就不再自动预热 —— 避免「很久以前悬停过一次」导致后来每次
 * 开关终端都凭空多起一个 shell。
 */
export const PREWARM_INTENT_TTL_MS = 60_000
/**
 * 两次真正发出预热请求的最小间隔。
 *
 * 连续 pointerenter/focus（鼠标扫过、Tab 反复聚焦）只发一次 HTTP：宿主虽然会复用同一个预热 shell，
 * 但每次请求仍然是一次往返 + 一次 `prewarm` 调用（重复调用会杀掉旧 warm shell 再起新的）。1s 足够
 * 盖住「扫过」的抖动，又不影响「先开一个、过一会儿再开一个」的正常节奏。
 */
export const PREWARM_REQUEST_COOLDOWN_MS = 1_000

/** 派发一次「悬停/聚焦 新建终端」的预热意图（按钮调用；抽成函数便于单测/静态断言）。 */
export function requestTerminalPrewarm(): void {
  window.dispatchEvent(new CustomEvent(TERMINAL_PREWARM_EVENT))
}

/** 预热真值表的输入。`intentAt` 与 `now` 显式传入，便于单测覆盖边界。 */
export interface PrewarmDecision {
  visible: boolean
  terminalCount: number
  /** 最近一次「悬停/聚焦新建终端」的时间；undefined = 从没表达过意图。 */
  intentAt?: number
  now: number
}

/**
 * 要不要预热当前工作区。
 *
 * - 面板不可见：不预热（用户看不见终端，起了也是白起）；
 * - 可见且**一个终端都没有**：预热（打开面板就能点「新建」，这是原有行为）；
 * - 可见且**已有终端**：只有用户悬停/聚焦过「新建终端」（意图还在有效期内）才预热 ——
 *   仅仅打开面板看已有终端不应该多起一个 shell。
 */
export function shouldPrewarm(input: PrewarmDecision): boolean {
  if (!input.visible) return false
  if (input.terminalCount === 0) return true
  return input.intentAt !== undefined && input.now - input.intentAt <= PREWARM_INTENT_TTL_MS
}

/** 这次意图要不要真的发请求：距上次真正发出预热请求不足冷却时间就跳过。 */
export function prewarmRequestDue(lastRequestAt: number | undefined, now: number): boolean {
  return lastRequestAt === undefined || now - lastRequestAt >= PREWARM_REQUEST_COOLDOWN_MS
}

/** Maintain one terminal collection for a DSH session. */
export class TerminalWorkspaceController implements TerminalWorkspace {
  private snapshot: TerminalWorkspaceSnapshot = { terminals: [], loading: false }
  private readonly listeners = new Set<() => void>()

  constructor(private readonly sessionId: string) {}

  /** 宿主给的规范地址；每次 API 响应都会带回，用于拼 WebSocket 的绝对地址。 */
  private wsBase: string | undefined

  async refresh(): Promise<void> {
    this.set({ ...this.snapshot, loading: true, error: undefined })
    try {
      const answer = await request<TerminalInfo[]>('list', { sessionId: this.sessionId })
      this.wsBase = answer.wsBase ?? this.wsBase
      this.set({ terminals: answer.value, loading: false })
    } catch (error) { this.set({ ...this.snapshot, loading: false, error: error instanceof Error ? error.message : String(error) }) }
  }

  /**
   * 新建终端。
   *
   * 宿主已经把新终端的信息随应答带回来了，直接并进本地快照 —— 原先这里再 await 一次
   * list，于是「点新建」要等两个串行往返才开始渲染窗格；而列表顺序就是宿主的插入顺序，
   * 追加到末尾与刷新结果一致。
   */
  async create(options: { title?: string; profile?: string; directory?: string } = {}): Promise<TerminalInfo> {
    const answer = await request<TerminalInfo>('create', { sessionId: this.sessionId, ...(options.title === undefined ? {} : { title: options.title }), ...(options.profile === undefined ? {} : { profile: options.profile }), ...(options.directory === undefined || options.directory === '' ? {} : { directory: options.directory }) })
    this.wsBase = answer.wsBase ?? this.wsBase
    this.set({ terminals: [...this.snapshot.terminals, answer.value], loading: false })
    return answer.value
  }
  /**
   * 预热默认 shell。宿主起好之后会留在回放缓冲里，下一次默认新建直接认领。
   * 这里只发请求、不做任何本地状态变更：预热出来的 shell 不属于终端列表。
   */
  async prewarm(): Promise<void> {
    const answer = await request<unknown>('prewarm', { sessionId: this.sessionId })
    this.wsBase = answer.wsBase ?? this.wsBase
  }

  /** 关闭终端。宿主带回了关闭之后的完整列表，直接采用，不再补一次 refresh。 */
  async close(id: string): Promise<void> {
    const answer = await request<TerminalInfo[]>('close', { sessionId: this.sessionId, id })
    this.wsBase = answer.wsBase ?? this.wsBase
    this.set({ terminals: answer.value, loading: false })
  }
  /** 重命名：就地替换快照里的同 id 条目。 */
  async rename(id: string, title: string): Promise<void> {
    const answer = await request<TerminalInfo>('rename', { sessionId: this.sessionId, id, title })
    this.wsBase = answer.wsBase ?? this.wsBase
    this.set({ terminals: this.snapshot.terminals.map(value => value.id === answer.value.id ? answer.value : value), loading: false })
  }
  connect(id: string): TerminalConnection { return new SocketConnection(this.sessionId, id, this.wsBase) }
  getSnapshot(): TerminalWorkspaceSnapshot { return this.snapshot }
  subscribe(listener: () => void): () => void { this.listeners.add(listener); return () => this.listeners.delete(listener) }
  private set(snapshot: TerminalWorkspaceSnapshot): void { this.snapshot = snapshot; for (const listener of this.listeners) listener() }
}
