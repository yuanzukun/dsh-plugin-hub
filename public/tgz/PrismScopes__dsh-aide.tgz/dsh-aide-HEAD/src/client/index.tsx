import type { Context as ClientContext } from '@deepseek-ai/cordis'
import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-working-directory'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import { Icon } from './Icon.tsx'
import type { VscodeWorkbench } from './service.ts'
import { WorkbenchController } from './service.ts'
import { TerminalPanel } from './TerminalPanel.tsx'
import { ProblemsPanel } from './ProblemsPanel.tsx'
import { OutputPanel } from './OutputPanel.tsx'
import { DebugConsolePanel } from './DebugConsolePanel.tsx'
import { ReviewPanel } from './ReviewPanel.tsx'
import { SettingsPanel } from './SettingsPanel.tsx'
import { activeLanguageEditor, installLanguageActions } from './language/actions.ts'
import { requestInlineEdit, snapshotOfEditor } from './inlineEdit.ts'
import { Workbench } from './Workbench.tsx'
import { NoSessionPrompt } from './NoSessionPrompt.tsx'
import { installStyles } from './styles.ts'
import { installContextCards } from './contextCards.ts'
import { handleTerminalShortcut } from './shortcuts.ts'
import { bindingMatches, bindingOf } from './keybindings.ts'
import { mainViewSession } from './session.ts'
import type { MenuEntry } from './ContextMenu.tsx'
import type { EditorMenuTarget } from './editorMenuRegistry.ts'
import type { DshAskKind, DshActionResult, DshSelection } from './dshChat.ts'
import { addSelectionToConversation, askDsh, dshChatStatus, formatSnippetQuote } from './dshChat.ts'
import { dshMenuEntries } from './dshMenus.ts'
import { copyText } from './clipboard.ts'
import { requestContextCard } from './contextRequest.ts'

export type { BottomPanelContribution, BottomPanelProps, VscodeWorkbench, WorkbenchCommand, WorkbenchSnapshot, WorkbenchView } from './service.ts'

/**
 * 侧栏“全局面板”行的 id，同时用作 main 面板的 key。
 * 两者必须配对注册：layout.selectPanel 会校验 hasMainPanel(id)，缺任一侧点击即抛错。
 */
const PANEL_ID = 'dsh-aide'

declare module '@deepseek-ai/cordis' { interface Context { vscodeWorkbench: VscodeWorkbench } }

/**
 * 打开 DSH 自己的设置面板，工作台保持打开。
 *
 * 不再去点侧栏入口，也不伪造键盘事件 —— 两者在桌面端都不成立：
 *   - 那个入口在**已登录时是二级菜单**（账户菜单：设置 / 意见反馈 / 退出登录），由 primitives 的
 *     Menu 渲染并 portal 到 body，role / class / 可点元素都不是稳定契约；
 *   - 伪造的 KeyboardEvent 带 isTrusted: false，而桌面端走的是 window.dshDesktop.keyboard
 *     原生键盘桥（见 dsh-client-shortcuts 的 ShortcutsService），不认这种合成事件。
 *     **web 端能过、桌面端过不去，正是这个原因。**
 *
 * 直接用 DSH 的 shortcuts 服务执行它自己注册的命令：
 *   ShortcutRegistry.invoke(id, context) —— 从命令表取 settings.open 并 run()，
 *   context.modal 为 null 时不做模态门控。与平台无关，也不碰 DOM。
 * registry 是该服务的内部字段，取不到时回退到派发组合键（web 端仍有效）。
 *
 * 工作台**不收起**：设置面板是 z-index 1000（wCInkW_overlay）、工作台 overlay 是 100，
 * 设置会浮在工作台之上，两者共存 —— 用户要的就是这个。
 */
function openDshSettings(): void {
  const registry = (shortcutsService as { registry?: { invoke?(id: string, context: unknown): unknown } } | undefined)?.registry
  if (typeof registry?.invoke === 'function') {
    console.info('[dvw] 打开 DSH 设置：走 shortcuts.registry.invoke')
    registry.invoke(SETTINGS_COMMAND, { modal: null, source: 'dsh-aide' })
    return
  }
  console.warn('[dvw] 打开 DSH 设置：shortcuts.registry.invoke 不可用，回退到派发组合键（桌面端此回退无效）')
  dispatchSettingsKeys()
}

/** DSH 为设置面板注册的命令 id（dsh-client-ui-settings-general 里 ctx.shortcuts.register）。 */
const SETTINGS_COMMAND = 'settings.open'

/**
 * 回退路径：派发设置快捷键。
 *
 * DSH 的绑定写的是 modifiers: ["primary"]，即 mac 是 Cmd、其余平台是 Ctrl，所以修饰键要按
 * 平台给，不能一律用 Ctrl。平台取自 DSH 自己的判定方式（见 dsh-client-shortcuts 的
 * detectEnvironment）：html[data-platform] 存在即桌面端，其值用于区分 macos / windows / linux；
 * 不存在则退回 navigator.platform。
 *
 * web 端还有一个 Alt 变体（defaults 里 web:windows 是 primary+alt），所以两种都派发。
 * 桌面端不认合成事件，这条回退只在 web 端有效 —— 桌面端依赖上面的 registry.invoke。
 */
function dispatchSettingsKeys(): void {
  const raw = document.documentElement.dataset.platform ?? navigator.platform ?? ''
  const isMac = /darwin|mac|iphone|ipad/i.test(raw)
  const primary = isMac ? { metaKey: true } : { ctrlKey: true }
  for (const altKey of [false, true]) {
    window.dispatchEvent(new KeyboardEvent('keydown', {
      key: ',', code: 'Comma', ...primary, altKey, bubbles: true, cancelable: true
    }))
  }
}

/** 由 apply 注入，供 openDshSettings 使用。 */
let shortcutsService: unknown

/** layout 服务的最小结构面（不 import 官方类型；旧版缺失时降级为 no-op）。 */
interface LayoutLike { selectPanel(id: string | null): void }

/**
 * 工作台显示期间，DSH 侧栏底部那个账户/设置入口整行会被收起来。
 *
 * 它的行位于 (10, 948)–(270, 990)，伸进工作台活动栏（x 0–48）的区域。被 overlay 盖住之后
 * 它既收不到点击（命中测试落在活动栏上），里面的图标又会从活动栏与侧栏的缝隙里透出来 ——
 * 表现为「两个图标重叠、其中一个点了没反应」。工作台活动栏的设置按钮提供的是同一个入口。
 *
 * **实现方式是 CSS（见 styles.ts 的 body:has(.dvw-overlay) [class*=_triggerRow]），不是在这里
 * 移除节点。** 早前用 effect + row.remove() 做过，并且在 visible 变化时把节点插回去；问题是
 * DSH 在会话切换、重新渲染时会重建那一行 —— 新建的节点不在那次 effect 记录里，effect 也不会
 * 重跑，于是移除失效、那行又露出来。样式是声明式的，重建多少次都照样生效。
 *
 * 为什么收起整行而不是只删 svg：那一行里放什么取决于登录状态 —— 未登录是省略号图标，
 * 已登录是头像（可能是 <img>）。只删 svg 会在已登录时漏掉头像。
 */

/**
 * 全局工作台 overlay。
 *
 * 导出是为了让回归测试直接验证「没有主视图会话」时的渲染分支（见 tests/no-session-prompt.spec.tsx）：
 * DSH 归档会话后归档动作不能把已经关闭的工作台弹出来。
 */
export const Overlay = ({ service, useSessions }: PropsRuntime<'shell.overlay'> & { service: VscodeWorkbench }) => {
  // DSH 0.2.1 起 sessions store 不再提供 state.current：主视图由 retainedBy.mainView 标记，
  // 取法与 shell 的 DocumentTitle 一致。后台保活的会话不算主视图。
  const session = useSessions(mainViewSession)
  // 工作目录以 workingDirectory 投影为准（会话可切换工作区），旧字段 cwd 作为回退。
  const cwd = session?.projectionValues?.workingDirectory ?? session?.cwd
  const [visible, setVisible] = useState(() => service.getSnapshot().visible)
  useEffect(() => service.subscribe(() => setVisible(service.getSnapshot().visible)), [service])
  // 侧栏入口的收起由 CSS 负责（body:has(.dvw-overlay) [class*=_triggerRow]），不在这里动 DOM ——
  // 详见该规则的注释：DSH 重建那行时，effect 里的 remove() 会失效。
  useEffect(() => {
    service.setSettingsOpener(openDshSettings)
    return () => { service.setSettingsOpener(() => {}) }
  }, [service])
  // 没有会话就不渲染工作台：文件树与文件读写都以会话工作区为根，会话未就绪时取到的内容不可信。
  // DSH 启动时并不默认选中会话，此时打开工作台要给一句明确提示，留白会被当成加载失败。
  // 但提示层必须自己看 visible —— DSH 归档会话后 mainViewSession 会变成 undefined，
  // 旧实现无条件渲染提示，导致工作台明明关着也被「弹」出来，而且「返回 DSH」关不掉（见 NoSessionPrompt）。
  if (session === undefined || session.id === '') {
    return <NoSessionPrompt visible={visible} onBack={() => service.hide()}/>
  }
  return <Workbench key={`${session.id}:${cwd ?? ''}`} service={service} sessionId={session.id} cwd={cwd}/>
}

/**
 * 侧栏面板行的图标。renderSlot 只把它渲染进行内的 glyph 位置，但这里额外铺满整行作为命中层：
 * DSH 的面板行被点击会调 layout.selectPanel，把主区域换成插件注册的空面板；那一次切换会卸载
 * 整个会话视图——连同 dsh-context、dsh-recall-plugin 这类挂在 conversation slot 上的组件一起——
 * 再重新挂载。每次打开工作台都要付这个代价（在装了这类插件的实例上是约 1 秒的整屏冻结）。
 * 在冒泡阶段吃掉点击，selectPanel 就不会执行，主区域保持原样。
 */
const PanelIcon = ({ service }: { service: VscodeWorkbench }) => {
  const hit = useRef<HTMLSpanElement>(null)
  useLayoutEffect(() => {
    // 面板行本身是 static 定位，命中层要铺满它，得先给它一个定位上下文。
    const row = hit.current?.closest('button') ?? null
    if (row === null) return
    row.style.position = 'relative'
    return () => { row.style.removeProperty('position') }
  }, [])
  const open = (event: { stopPropagation: () => void; preventDefault: () => void }) => {
    event.stopPropagation()
    event.preventDefault()
    service.show()
  }
  return <>
    {/* 图标必须是正常的 flex 项：宿主 glyph 席位是 display:contents，绝对定位的子元素会脱离流，
        那样图标不占位，行文字会顶到行首把图标压住。 */}
    <span className="dvw-panel-icon"><Icon name="code"/></span>
    {/* 命中层单独一个绝对定位元素：铺满整行，在冒泡阶段吃掉点击。 */}
    <span ref={hit} className="dvw-panel-hit" role="button" tabIndex={0} title="AIDE"
      onClick={open}
      onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') open(event) }}/>
  </>
}

/**
 * 面板行被点击后 DSH 会把主区域切到本组件。工作台是全屏 overlay、会盖住主区域，
 * 所以主区域不需要留内容——但**不能**在这里立刻切回会话：那会让每次打开都多一次
 * 主区域往返（切到空面板、再切回会话），会话越长代价越大。
 * 改成等用户关闭工作台后再交还主区域，打开路径只剩一次切换。
 *
 * layout 取 unknown：插件绑定的旧类型里 ILayout 还没有 selectPanel（0.2.0 才加），
 * 声明成具体形状会与 slot 推导出的 ILayout 不兼容，因此运行时收窄后再调用。
 */
const PanelPage = ({ service, layout }: { service: VscodeWorkbench; layout?: unknown }) => {
  useEffect(() => {
    // 这里不调用 show()：DSH 恢复主区域时也会挂载本组件，那样工作台会在启动时自动弹出。
    // 打开工作台只有一条路径 —— 侧栏入口（见 PanelIcon）。
    const release = () => {
      const select = (layout as LayoutLike | undefined)?.selectPanel
      if (typeof select === 'function') select.call(layout, null)
    }
    // 工作台关闭后主区域仍停在空白面板上，这一刻才把会话视图交还回去。
    return service.subscribe(() => { if (!service.getSnapshot().visible) release() })
  }, [service, layout])
  return null
}

/** DSH 对话动作的结果反馈：失败时给一句可读提示，成功不打扰。 */
function reportDshResult(result: DshActionResult): void {
  if (!result.ok && result.message !== undefined && result.message !== '') window.alert(result.message)
}

/** 打开菜单那一刻的编辑器状态 → DSH 选区结构。 */
function toDshSelection(target: EditorMenuTarget): DshSelection {
  return {
    text: target.selectionText,
    ...(target.filePath === undefined ? {} : { filePath: target.filePath }),
    language: target.language,
    lineStart: target.lineStart,
    lineEnd: target.lineEnd,
  }
}

/**
 * 「DeepSeek Harness」右键子菜单。
 *
 * 用户要求：**选中文本时它在编辑区菜单最顶上**。所以注册成 `place:'top'` 的菜单贡献，
 * 且没有选区时返回空数组 —— 菜单里不会留一条孤零零的分隔线。
 *
 * 所有动作都只**把文本插入 DSH 对话输入框**（不直接发送，用户可以再补一句再自己发）：
 * 「添加至对话」插入引用，「询问/解释/修复…」插入对应指令 + 引用；「复制为引用」只走剪贴板。
 */
function dshHarnessEntry(target: EditorMenuTarget): MenuEntry {
  const selection = toDshSelection(target)
  const ask = (kind: DshAskKind) => {
    // 「询问 DSH…」让用户当场输入问题；取消（null）就什么都不做。
    // 其余几项是一键动作，按预置指令生成要插入对话栏的文本。
    if (kind !== 'ask') { void askDsh(kind, selection).then(reportDshResult); return }
    const question = window.prompt('向 DSH 询问这段代码（留空则按默认指令分析）：')
    if (question === null) return
    const extra = question.trim() === '' ? undefined : question.trim()
    void askDsh('ask', selection, extra).then(reportDshResult)
  }
  /** 上下文卡片：优先作为 DSH 引用 chip 插入；没有 composer 服务时回落到旧的文本插入。 */
  const addContextCard = () => {
    void requestContextCard({
      kind: 'selection',
      ...(target.filePath === undefined ? {} : { path: target.filePath }),
      ...(target.language === undefined ? {} : { language: target.language }),
      lineStart: target.lineStart,
      lineEnd: target.lineEnd,
      text: target.selectionText,
      title: target.filePath?.split(/[\\/]/).at(-1),
    }).then(ok => { if (!ok) void addSelectionToConversation(selection).then(reportDshResult) })
  }
  return {
    kind: 'item',
    id: 'dsh-harness',
    label: 'DeepSeek Harness',
    // 带 submenu 的父项不会执行 onSelect，但字段是必填的。
    onSelect: () => {},
    submenu: dshMenuEntries({
      hasSelection: target.hasSelection,
      available: dshChatStatus().available,
      actions: {
        addToConversation: () => { void addSelectionToConversation(selection).then(reportDshResult) },
        addContextCard,
        ask,
        copyQuote: () => { void copyText(formatSnippetQuote(selection)) },
      },
    }),
  }
}

// layout 是跨插件面板动作契约（layout.selectPanel）。必须声明注入：cordis 拒绝访问未注入的
// 服务，此前用 `as unknown as` 绕过类型读取 ctx.layout，运行时直接让整个插件激活失败。
// shortcuts 同样必须声明：openDshSettings 要经它执行 settings.open 命令（桌面端唯一可行的路径）。
export const inject = ['slots', 'layout', 'shortcuts']
export function apply(ctx: ClientContext): void {
  const service = new WorkbenchController()
  const layout = ctx.layout
  // shortcuts 服务的类型在绑定的旧版官方类型里还没有，按运行时形状取（同 layout 的做法）。
  shortcutsService = (ctx as unknown as { shortcuts?: unknown }).shortcuts
  ctx.effect(() => installStyles(), 'dsh-aide: styles')
  // 输入框上下文卡片：注册 DSH `@` 源并准备 composer chip 通路（服务缺失时自动回落到文本插入）。
  // installContextCards 自己用 ctx.effect 注册/清理 source，这里不需要再包一层。
  installContextCards(ctx as unknown as Parameters<typeof installContextCards>[0])
  ctx.effect(() => { const dispose = ctx.reflect.provide('vscodeWorkbench', service); return () => { void dispose() } }, 'dsh-aide: service')
  // 编辑器右键菜单的「DeepSeek Harness」子菜单：注册成置顶贡献。
  // 它的动作只把引用/指令插入 DSH 对话输入框（不直接发送），因此不需要注入任何 DSH 客户端服务；
  // 找不到输入框时会回退到剪贴板并提示。其它插件也能通过
  // ctx.get('vscodeWorkbench').registerEditorMenuContribution(...) 使用同一扩展点。
  ctx.effect(() => service.registerEditorMenuContribution({
    id: 'dsh-harness', place: 'top', order: -100,
    entries: target => target.hasSelection ? [dshHarnessEntry(target)] : [],
  }), 'dsh-aide: dsh editor menu')
  // 「用 AI 修改选中代码」：与 Ctrl+K 同一入口，菜单只是给鼠标用户的第二条路。
  // 快照在点击时现取（编辑器实例可能已经换过焦点/选区），不在菜单构建时缓存。
  ctx.effect(() => service.registerEditorMenuContribution({
    id: 'inline-edit', place: 'top', order: -90,
    entries: target => target.hasSelection ? [{
      kind: 'item', id: 'inline-edit', label: '用 AI 修改选中代码', shortcut: 'Ctrl+K',
      onSelect() {
        const entry = activeLanguageEditor()
        if (entry === undefined) return
        const snapshot = snapshotOfEditor(entry.editor, entry.path)
        if (snapshot !== undefined) requestInlineEdit(snapshot)
      },
    }] : [],
  }), 'dsh-aide: inline edit menu')
  ctx.effect(() => service.registerBottomPanel({ id: 'terminal', title: '终端', component: TerminalPanel }), 'dsh-aide: terminal panel')
  // 「问题」面板：语言服务把诊断推到客户端 store，面板只负责渲染与跳转。
  ctx.effect(() => service.registerBottomPanel({ id: 'problems', title: '问题', component: ProblemsPanel }), 'dsh-aide: problems panel')
  // 「输出」面板：语言服务 LSP 日志与 Git 命令记录（通道切换见 OutputPanel）。
  ctx.effect(() => service.registerBottomPanel({ id: 'output', title: '输出', component: OutputPanel }), 'dsh-aide: output panel')
  // 「调试控制台」面板：没有活动栏入口，只能从面板标题栏的「更多操作」菜单打开（见 Workbench）。
  ctx.effect(() => service.registerBottomPanel({ id: 'debug', title: '调试控制台', component: DebugConsolePanel }), 'dsh-aide: debug console panel')
  // 「改动」面板：工作区改动审查与检查点（Agent 写入与手改都写同一批文件，按工作区语义呈现）。
  ctx.effect(() => service.registerBottomPanel({ id: 'review', title: '改动', component: ReviewPanel }), 'dsh-aide: review panel')
  // 语言服务的全局按键与 Ctrl+点击。装在 window 捕获阶段，才能压过 Monaco 内置的 F12 / Ctrl+点击。
  ctx.effect(() => installLanguageActions(), 'dsh-aide: language actions')
  ctx.effect(() => service.registerCommand({ id: 'terminal.new', run() { window.dispatchEvent(new Event('dvw-terminal-new')) } }), 'dsh-aide: terminal command')
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({ name: 'shell.overlay', id: 'dsh-aide-overlay', inject: () => ({ service }) }, Overlay))
  // 侧栏“全局面板”入口：与下方 main 面板成对注册。
  ctx.slots.inject('main', () => ctx.slots.register({ name: 'main', key: PANEL_ID, inject: () => ({ service, layout }) }, PanelPage))
  ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({ name: 'sidebar.panellist', id: PANEL_ID, order: 20, label: 'AIDE', inject: () => ({ service }) }, PanelIcon))
  // DSH 设置导航里的「AIDE 工作台」页。order 取较大值，排在「插件市场」下面。
  // 设置页自己读写偏好（客户端 localStorage + 宿主的补全设置端点），不需要注入 workbench 服务。
  ctx.slots.inject('settings.section', () => ctx.slots.register({ name: 'settings.section', id: PANEL_ID, order: 1000, label: 'AIDE', inject: () => ({}) }, SettingsPanel))
  /**
   * 全局导航快捷键。
   *
   * 键位一律从设置页可改的注册表里实时读取（`keybindings.ts`）：设置页改完不用刷新，
   * 且与 DSH 的设置项（可改 / 固定）共用同一份定义。
   */
  ctx.effect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (handleTerminalShortcut(event, service)) return
      if (event.isComposing) return
      // 搜索结果的「下一个 / 上一个匹配」：只有停在搜索视图时才响应（命令由搜索面板在挂载期注册）。
      const next = bindingOf('search.next')
      const previous = bindingOf('search.previous')
      if ((next !== null && bindingMatches(event, next)) || (previous !== null && bindingMatches(event, previous))) {
        const snapshot = service.getSnapshot()
        if (snapshot.visible && snapshot.view === 'search') {
          event.preventDefault()
          service.runCommand(previous !== null && bindingMatches(event, previous) ? 'search.previous' : 'search.next')
        }
        return
      }
      // 搜索并聚焦输入框 / 同时展开替换行。视图首次打开时组件还没挂载，等到这一帧提交之后再发命令。
      const focusSearch = bindingOf('view.search')
      const openReplace = bindingOf('search.replace')
      const wantsSearch = focusSearch !== null && bindingMatches(event, focusSearch)
      const wantsReplace = openReplace !== null && bindingMatches(event, openReplace)
      if (wantsSearch || wantsReplace) {
        event.preventDefault()
        service.show('search')
        window.setTimeout(() => service.runCommand(wantsReplace ? 'search.replace' : 'search.focus'), 30)
        return
      }
      // 资源管理器 / 源代码管理。
      const explorer = bindingOf('view.explorer')
      const git = bindingOf('view.git')
      const wantsExplorer = explorer !== null && bindingMatches(event, explorer)
      const wantsGit = git !== null && bindingMatches(event, git)
      if (wantsExplorer || wantsGit) {
        event.preventDefault()
        service.show(wantsExplorer ? 'explorer' : 'git')
      }
    }
    window.addEventListener('keydown', onKey, true); return () => window.removeEventListener('keydown', onKey, true)
  }, 'dsh-aide: navigation shortcuts')
}
