import type { IncomingMessage, ServerResponse } from 'node:http'
import type { WorkbenchConnection } from './context.ts'

export class WorkbenchError extends Error {
  constructor(public code: string, message: string, public status = 400) { super(message) }
}

export async function readBody(req: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const value = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += value.length
    if (size > 2 * 1024 * 1024) throw new WorkbenchError('too-large', 'request body is too large', 413)
    chunks.push(value)
  }
  try {
    const value: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')
    if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('object expected')
    return value as Record<string, unknown>
  } catch { throw new WorkbenchError('bad-json', 'request body must be a JSON object') }
}

/** Read a binary upload while enforcing a fixed request limit. */
export async function readBinaryBody(req: IncomingMessage, limit = 100 * 1024 * 1024): Promise<Buffer> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const value = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += value.length
    if (size > limit) throw new WorkbenchError('too-large', 'uploaded file is too large', 413)
    chunks.push(value)
  }
  return Buffer.concat(chunks)
}

export function stringField(body: Record<string, unknown>, key: string): string {
  const value = body[key]
  if (typeof value !== 'string') throw new WorkbenchError('bad-request', `${key} must be a string`)
  return value
}

export function send(res: ServerResponse, status: number, value: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(JSON.stringify(value))
}

export function sendError(res: ServerResponse, error: unknown): void {
  const known = error instanceof WorkbenchError ? error : new WorkbenchError('internal', error instanceof Error ? error.message : String(error), 500)
  send(res, known.status, { ok: false, error: { code: known.code, message: known.message } })
}

/**
 * 复用 Harness 自己的连接认证与部署感知的 Host/Origin 防线。
 *
 * 0.2.1 起 webRuntime.trustedHosts 随 runtime 服务一起移除，认证统一由 connection 服务提供；
 * 这里不再自建 host 白名单，否则会与宿主（尤其是远程/反代部署）的判断分叉。
 * 返回 false 时已经写好响应，调用方直接 return 即可。
 */
export function authorize(req: IncomingMessage, res: ServerResponse, connection: WorkbenchConnection): boolean {
  const rejection = connection.requestRejection(req)
  if (rejection === undefined) return true
  const code = rejection === 401 ? 'unauthorized' : 'forbidden'
  send(res, rejection, { ok: false, error: { code, message: code } })
  return false
}
