/**
 * cc-import — host half entry.
 *
 * Loaded by a composition row `{ id: cc-import, name: 'cc-import' }`.
 * Composes the CLAUDE.md memory loader (as dynamic runtime context,
 * NOT a system-prompt section; AGENTS.md is natively auto-loaded by newer
 * DSH versions), the Claude Code import provider, and the
 * `/init` command that scaffolds an AGENTS.md; registers model-facing tools so
 * the import is also drivable from the model (the client UI uses RPC added in
 * the UI milestone).
 */
import { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { createMemoryLoader } from './memory'
import { registerInitCommand } from './init'
import { createClaudeCodeProvider } from './import/claude-code'
import type { ImportProvider } from './import/provider'
import { registerRpcRoutes } from './rpc'

export const name = 'cc-import'
export const inject = ['systemPrompt', 'sandboxPolicy', 'tools', 'webServer'] as const

const MEMORY_CONTEXT_ORDER = 50

export function apply(ctx: Context) {
  // Session cwd (the real project root for CLAUDE.md) must be resolved per
  // assembly, not once at apply: in a global host composition the agent only
  // exists during assembly, where `AssembleContext.scope` IS the agent
  // (dsh-agent-loop does `createScope(loopCtx, this)`).
  const agents = ctx.get('agents') as any
  const fallbackRoot: string | undefined = ctx.sandboxPolicy.workspaceRoot

  // ---- 1. CLAUDE.md memory (per-session-cwd cache) -------------------
  const memoryLoader = createMemoryLoader(ctx)
  // 按会话 cwd 缓存记忆文本；设置上限 + LRU 淘汰，避免长期运行的 host 无限增长。
  const memoryCache = new Map<string, string>()
  const MEMORY_CACHE_MAX = 64
  const loading = new Set<string>()
  function trimMemoryCache() {
    while (memoryCache.size > MEMORY_CACHE_MAX) {
      const oldest = memoryCache.keys().next().value
      if (oldest === undefined) break
      memoryCache.delete(oldest)
    }
  }
  function memoryFor(cwd: string): string {
    const hit = memoryCache.get(cwd)
    if (hit !== undefined) {
      // LRU：把命中项移到队尾（Map 迭代顺序即插入顺序）。
      memoryCache.delete(cwd)
      memoryCache.set(cwd, hit)
      return hit
    }
    if (!loading.has(cwd)) {
      loading.add(cwd)
      memoryLoader
        .load(cwd)
        .then((t) => { memoryCache.set(cwd, t); trimMemoryCache() })
        .catch(() => { memoryCache.set(cwd, ''); trimMemoryCache() })
        .finally(() => { loading.delete(cwd) })
    }
    return ''
  }
  // 记忆文件用 `context()` 注入，而不是 `section()`：`section()` 把内容拼进
  // 系统提示词（角色/工具定义区），而 CLAUDE.md 是「项目/任务知识」，
  // 属于用户消息层。`context()` 正好贡献有序动态上下文，随附循环成为带来源的
  // user-role 快照，与系统提示词分离——避免污染系统提示词缓存、稀释其权威性，
  // 且每次组装按会话 cwd 重新求值，切换项目/分支后新快照自然取代旧快照。
  ctx.systemPrompt.context({
    name: 'cc-import:memory',
    order: MEMORY_CONTEXT_ORDER,
    text: (assembleCtx: any) => {
      const cwd: string | undefined =
        assembleCtx?.scope?.session?.header?.cwd ??
        (typeof agents?.currentInitiator === 'function' ? agents.currentInitiator()?.session?.header?.cwd : undefined) ??
        fallbackRoot
      return cwd ? memoryFor(cwd) : ''
    },
  })

  // ---- 2. import providers (extensible) ------------------------------
  const providers: ImportProvider[] = [createClaudeCodeProvider(ctx)]

  // ---- 2b. /init command (scaffold an AGENTS.md) ------------------------
  registerInitCommand(ctx)

  // ---- 2b. client-facing HTTP RPC -------------------------------------
  registerRpcRoutes(ctx, providers)

  // ---- 3. model-facing tools -----------------------------------------
  const listTool = defineTool({
    name: 'cc_history_list',
    description: 'List Claude Code conversation sessions available under ~/.claude/projects (read-only).',
    parameters: {
      limit: { type: 'integer', description: 'Maximum sessions to return (default 100).' },
      filter: { type: 'string', description: 'Optional case-insensitive substring filter.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          count: { type: 'integer' },
          truncated: { type: 'boolean' },
          sessions: {
            type: 'array',
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                provider: { type: 'string' },
                fileName: { type: 'string' },
                relPath: { type: 'string' },
                projectDir: { type: 'string' },
                size: { type: 'integer' },
              },
            },
          },
        },
      },
      render: (_args, value) => {
        const lines = [`Claude Code sessions (${value.count} shown):`]
        for (const s of value.sessions) lines.push(`- ${s.relPath}${s.size ? ` (${s.size} bytes)` : ''}`)
        if (value.truncated) lines.push('(more available — raise `limit` or use `filter`)')
        if (value.count === 0) lines.push('No sessions found. Check that ~/.claude/projects exists.')
        lines.push('Import one with cc_import using its fileName or relPath.')
        return [{ type: 'text', text: lines.join('\n') }]
      },
    },
    async execute(args: any) {
      const all: any[] = []
      for (const p of providers) all.push(...(await p.listSessions()))
      let sessions = all
      if (args && typeof args.filter === 'string' && args.filter.trim()) {
        const f = args.filter.trim().toLowerCase()
        sessions = sessions.filter((s: any) => `${s.projectDir} ${s.fileName} ${s.relPath}`.toLowerCase().includes(f))
      }
      let limit = 100
      if (args && typeof args.limit === 'number' && args.limit > 0) limit = Math.floor(args.limit)
      const truncated = sessions.length > limit
      return { count: Math.min(sessions.length, limit), truncated, sessions: sessions.slice(0, limit) }
    },
  } as any)
  ctx.tools.register(listTool)

  const importTool = defineTool({
    name: 'cc_import',
    description: 'Import one Claude Code conversation (.jsonl) as a resumable DSH session.',
    parameters: {
      sessionId: { type: 'string', required: true, description: 'Session file name or relPath from cc_history_list.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          sessionId: { type: 'string' },
          eventCount: { type: 'integer' },
          listed: { type: 'boolean' },
          inspectError: { type: 'string' },
          error: { type: 'string' },
          subagentCount: { type: 'integer' },
          reimported: { type: 'boolean' },
        },
      },
      render: (_args, value) => {
        const text = value.error
          ? `Import failed: ${value.error}`
          : `Imported ${value.sessionId} (${value.eventCount} events). listed=${value.listed}${value.reimported ? ' [re-imported: prior session was archived]' : ''}${value.inspectError ? ` inspectError=${value.inspectError}` : ' inspect=OK'}`
        return [{ type: 'text', text }]
      },
    },
    async execute(args: any) {
      const sid = args && typeof args.sessionId === 'string' ? args.sessionId.trim() : ''
      if (!sid) return { sessionId: '', eventCount: 0, listed: false, error: 'sessionId is required' }
      // claude-code is the only provider for now; route by provider later.
      return providers[0].importSession(sid)
    },
  } as any)
  ctx.tools.register(importTool)
}
