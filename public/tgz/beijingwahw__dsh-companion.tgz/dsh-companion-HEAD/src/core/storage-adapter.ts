/**
 * 存储适配层：桥接插件内部存储契约与真实 Harness 存储 API。
 *
 * 插件内部使用的存储接口（Domain / KvTable / defineDomain）与
 * `@deepseek-ai/dsh-storage-domain` 的真实 API 存在以下差异：
 * - 表名：插件使用连字符（如 'usage-daily'），真实 API 要求 UNIT_NAME_RE（仅小写字母/数字/下划线）
 * - keys()/entries()：插件期望数组，真实 API 返回迭代器
 * - delete()：插件期望 Promise<void>，真实 API 返回 Promise<boolean>
 * - update()：插件回调为原子读改写 `(prev: V|undefined) => V|undefined`（undefined=删除），
 *   真实 API 回调只接受 `(prev: V) => V` 且键不存在时抛错——经同键写串行化队列适配（见下）
 * - Domain.global：插件期望 KvTable，真实 API 是 DomainGlobal<G>
 * - defineDomain：插件仅传 name/version，真实 API 要求声明所有表及 zod schema
 *
 * 本模块提供适配函数，使插件代码无需修改即可运行在真实 Harness 上。
 */
import {
  defineDomain as realDefineDomain,
  domainTable,
  type Domain as RealDomain,
  type DomainSpec as RealDomainSpec,
  type KvTable as RealKvTable,
} from '@deepseek-ai/dsh-storage-domain'
import { z } from 'zod'

// ---------------------------------------------------------------------------
// 插件内部存储契约类型（与原 storage.d.ts 一致）
// ---------------------------------------------------------------------------

/** 存储域规格：名称 + 单调递增的 schema 版本。 */
export interface DomainSpec {
  readonly name: string
  readonly version: number
  readonly description?: string
}

/** 类型化键值表：读同步（权威内存状态），写排入每域写链。 */
export interface KvTable<V = unknown> {
  get(key: string): V | undefined
  keys(): string[]
  entries(): [string, V][]
  readonly size: number
  put(key: string, value: V): Promise<void>
  delete(key: string): Promise<void>
  /** 原子读-改-写；回调返回 undefined 表示删除该键。 */
  update(key: string, fn: (prev: V | undefined) => V | undefined): Promise<void>
}

/** 打开后的存储域。 */
export interface Domain {
  readonly spec: DomainSpec
  table<V = unknown>(name: string): KvTable<V>
  readonly global: KvTable
}

/** 域设施（ctx.storageDomain）。 */
export interface DomainFacility {
  open(spec: DomainSpec): Promise<Domain>
  get(name: string): Domain | undefined
  closeAll(): Promise<void>
}

// ---------------------------------------------------------------------------
// 表名转换：连字符 → 下划线（满足 UNIT_NAME_RE）
// ---------------------------------------------------------------------------

/** 将插件内部表名（可含连字符）转换为 Harness 合法表名（仅下划线）。 */
function toUnitName(name: string): string {
  return name.replace(/-/g, '_')
}

// ---------------------------------------------------------------------------
// 插件使用的全部表名清单（用于 defineDomain 声明）
// ---------------------------------------------------------------------------

/** 插件所有模块使用的表名（连字符形式）；导出供发布契约测试做静态守卫。 */
export const ALL_TABLE_NAMES = [
  // core
  'vault-meta', 'vault', 'usage-daily',
  // handoff
  'templates', 'handoff-armed', 'handoff-receipts',
  'handoff-chunks', 'handoff-lineage',
  // cost
  'cost-extra', 'budget-state',
  // search
  'tags',
  // retrieval
  'retrieval-index',
  // retrieval（轴线 11：点击反馈画像）
  'retrieval-feedback',
  // retrieval（轴线 19：零命中查询日志——检索盲区分析的原料）
  'retrieval-misses',
  // retrieval（轴线 28：FTRL-Proximal 在线排序模型）
  'retrieval-ranker',
  // knowledge（轴线 4：对话知识资产实体倒排索引）
  'knowledge-entities',
  // knowledge（轴线 20–25：意图、片段、复习调度与个体节律）
  'knowledge-intentions', 'knowledge-episodes', 'knowledge-review', 'knowledge-rhythm',
  // insights（仅存指纹与反馈元数据，不保存卡片正文）
  'proactive-insights',
  // trace
  'traces', 'trace-stats-daily',
  // prompt
  'prompt-versions', 'prompt-templates', 'prompt-ratings',
  // orchestrator
  'pipelines', 'pipeline-runs', 'queue-tasks', 'scheduled-jobs', 'scheduled-runs',
  // team
  'team-prefs', 'team-snapshots', 'experience-cards',
  'review-requests', 'review-comments', 'review-decisions',
  // security
  'named-keys', 'audit-log', 'dlp-rules', 'dlp-builtin-overrides',
  'dlp-settings', 'dlp-blocks-daily', 'audit-alerts',
] as const

// ---------------------------------------------------------------------------
// defineDomain：创建真实 Harness DomainSpec
// ---------------------------------------------------------------------------

/**
 * 声明存储域规格。内部将所有表以 z.unknown() schema 注册到真实 DomainSpec，
 * 使 Harness 存储层能正确打开域。插件自行负责记录级校验。
 */
export function defineDomain(spec: DomainSpec): DomainSpec {
  return spec
}

/**
 * 从插件 DomainSpec 构建真实 Harness DomainSpec（含全部表声明）。
 * 在 openDomain 时调用。
 */
function buildRealSpec(spec: DomainSpec): RealDomainSpec {
  const tables: Record<string, ReturnType<typeof domainTable>> = {}
  for (const name of ALL_TABLE_NAMES) {
    tables[toUnitName(name)] = domainTable(z.unknown())
  }
  return realDefineDomain({
    name: spec.name,
    version: spec.version,
    tables,
  })
}

// ---------------------------------------------------------------------------
// KvTable 适配
// ---------------------------------------------------------------------------

/**
 * 同键写串行化队列：保证「读-改-写」在同进程内原子。
 *
 * 真实 API 的 `update(key, fn)` 回调只接受 `(prev: V) => V`（键不存在时
 * 整体抛错，回调也不能返回 undefined 表示删除），因此无法直接承载插件
 * 契约的 `(prev: V | undefined) => V | undefined`。此前适配层在写链之外
 * 预读快照再写入，导致并发更新互相覆盖（丢增量）。
 *
 * 现改为：本插件对同一键的全部写操作（put/delete/update）都排入该键的
 * 串行队列，任务在队首执行时才同步读取权威内存值并计算结果——同进程内
 * 任意并发的读改写不再交错，键的创建竞态也随之消除。
 */
const writeChains = new Map<string, Promise<unknown>>()

function serializeWrite<T>(key: string, job: () => Promise<T>): Promise<T> {
  const prev = writeChains.get(key) ?? Promise.resolve()
  // 前序任务失败不阻塞本任务。
  const run = prev.then(job, job)
  const tail = run.then(
    () => undefined,
    () => undefined,
  )
  writeChains.set(key, tail)
  // 队列归零后清理，避免 Map 随键数无界增长（新任务入队时跳过清理）。
  void tail.then(() => {
    if (writeChains.get(key) === tail) writeChains.delete(key)
  })
  return run
}

/** 将真实 KvTable 包装为插件期望的 KvTable 接口。 */
function wrapTable<V>(real: RealKvTable<string, unknown>, namespace: string): KvTable<V> {
  const queueKey = (key: string): string => `${namespace}:${key}`
  return {
    get: (key) => real.get(key) as V | undefined,
    keys: () => [...real.keys()],
    entries: () => [...real.entries()] as [string, V][],
    get size() { return real.size },
    put: (key, value) => serializeWrite(queueKey(key), () => real.put(key, value)),
    delete: (key) => serializeWrite(queueKey(key), async () => { await real.delete(key) }),
    update: (key, fn) =>
      serializeWrite(queueKey(key), async () => {
        // 队首执行：此刻的同步读即权威内存状态，并发调用不会互相覆盖。
        const current = real.get(key) as V | undefined
        const next = fn(current)
        if (next === undefined) {
          if (current !== undefined) await real.delete(key)
          return
        }
        await real.put(key, next)
      }),
  }
}

// ---------------------------------------------------------------------------
// Domain 适配
// ---------------------------------------------------------------------------

/** 将真实 Domain 包装为插件期望的 Domain 接口。 */
function wrapDomain(real: RealDomain<RealDomainSpec>, spec: DomainSpec): Domain {
  const tableCache = new Map<string, KvTable<unknown>>()
  return {
    spec,
    table<V>(name: string): KvTable<V> {
      if (!tableCache.has(name)) {
        tableCache.set(name, wrapTable<V>(real.table(toUnitName(name)), `${spec.name}/${name}`))
      }
      return tableCache.get(name) as KvTable<V>
    },
    get global(): KvTable {
      // 插件未使用 domain.global；提供空实现以满足接口。
      throw new Error('companion storage: domain.global is not used by this plugin')
    },
  }
}

// ---------------------------------------------------------------------------
// DomainFacility 适配
// ---------------------------------------------------------------------------

/** 真实 DomainFacility 的类型（来自 @deepseek-ai/dsh-storage-domain）。 */
export interface RealDomainFacility {
  open<S extends RealDomainSpec>(spec: S): Promise<RealDomain<S>>
  get(name: string): unknown
  closeAll(): Promise<void>
}

/**
 * 将真实 DomainFacility 包装为插件期望的 DomainFacility 接口。
 * 在 CompanionCoreService 初始化时调用。
 */
export function wrapFacility(real: RealDomainFacility): DomainFacility {
  const openDomains = new Map<string, Domain>()
  return {
    async open(spec: DomainSpec): Promise<Domain> {
      const realSpec = buildRealSpec(spec)
      const realDomain = await real.open(realSpec)
      const wrapped = wrapDomain(realDomain as RealDomain<RealDomainSpec>, spec)
      openDomains.set(spec.name, wrapped)
      return wrapped
    },
    get(name: string): Domain | undefined {
      return openDomains.get(name)
    },
    async closeAll(): Promise<void> {
      await real.closeAll()
      openDomains.clear()
    },
  }
}
