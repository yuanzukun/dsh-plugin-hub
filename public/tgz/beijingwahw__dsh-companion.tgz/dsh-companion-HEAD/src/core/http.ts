/**
 * 插件私有 HTTP API 路由器。
 *
 * 根插件在 ctx.webServer 上注册唯一的前缀路由 `/companion`
 * （docs/subsystems/web-server.md），各功能模块通过
 * `ctx.companion.http.add(method, path, handler)` 挂载自己的端点；
 * 浏览器侧客户端（src/client）通过同源 fetch 调用这些端点。
 *
 * CSRF / DNS-rebinding 防线（createRouter.handle 内实施）：
 * 变更类方法（POST/DELETE）若携带 Origin 或 Referer 头，则必须与请求
 * Host 同源（主机名+端口一致）。浏览器对跨站表单 POST 与 no-cors fetch
 * 同样会发送 Origin，攻击页伪造的 Origin/Referer 与本机 Host 不符即被
 * 403 拒绝；DNS rebinding 下 Origin 是攻击者域名，同样被拒。两个头
 * 均缺失（curl 等非浏览器客户端）放行——本服务无 Cookie/会话，非
 * 浏览器客户端不受 CSRF 模型威胁，不设虚假防线。
 */
import type { IncomingMessage, ServerResponse } from 'node:http'

export interface HttpRequestContext {
  query: URLSearchParams
  /** POST/DELETE 请求的 JSON 正文（GET 为 undefined）。 */
  body: unknown
}

export type HttpHandler = (
  req: IncomingMessage,
  res: ServerResponse,
  ctx: HttpRequestContext,
) => void | Promise<void>

/** 带状态码的业务错误。 */
export class HttpError extends Error {
  constructor(
    message: string,
    readonly status: number = 400,
  ) {
    super(message)
    this.name = 'HttpError'
  }
}

export interface CompanionRouter {
  /** 挂载端点；返回注销 disposer。重复 (method, path) 抛错。 */
  add(method: 'GET' | 'POST' | 'DELETE', path: string, handler: HttpHandler): () => void
  /** 由 webServer 前缀路由委派的统一入口。 */
  handle(req: IncomingMessage, res: ServerResponse): Promise<void>
}

/**
 * 创建路由器。
 * @param basePath 前缀路径（默认 /companion）。
 */
export function createRouter(basePath: string = '/companion'): CompanionRouter {
  const routes = new Map<string, HttpHandler>()
  return {
    add(method, path, handler) {
      const key = `${method} ${path}`
      if (routes.has(key)) throw new Error(`companion http: duplicate route ${key}`)
      routes.set(key, handler)
      return () => {
        // 身份比对：仅当当前注册的仍是同一个 handler 时才注销，
        // 避免误删注销期间被重新注册到同一 key 的新 handler。
        if (routes.get(key) === handler) routes.delete(key)
      }
    },
    async handle(req, res) {
      let url: URL
      try {
        url = new URL(req.url ?? '/', 'http://localhost')
      } catch {
        return sendJson(res, 400, { error: 'bad request url' })
      }
      // 前缀匹配要求完全相等，或其后紧跟 '/'（防止 /companion-x 被误匹配）。
      if (url.pathname !== basePath && !url.pathname.startsWith(`${basePath}/`)) {
        return sendJson(res, 404, { error: 'not found' })
      }
      const sub = url.pathname.slice(basePath.length) || '/'
      const key = `${req.method ?? 'GET'} ${sub}`
      const handler = routes.get(key)
      if (!handler) {
        return sendJson(res, 404, { error: `no route: ${key}` })
      }
      // 变更类方法的同源校验（详见文件头注释）：在读 body 前快速失败。
      const method = req.method ?? 'GET'
      if (method === 'POST' || method === 'DELETE') {
        const sourceHeader = req.headers.origin ?? req.headers.referer
        const hostHeader = req.headers.host
        if (typeof sourceHeader === 'string' && sourceHeader !== '' && typeof hostHeader === 'string') {
          if (!isSameOrigin(sourceHeader, hostHeader)) {
            return sendJson(res, 403, { error: 'cross-origin request rejected' })
          }
        }
      }
      try {
        const body =
          req.method === 'GET' || req.method === 'HEAD' ? undefined : await readJsonBody(req)
        await handler(req, res, { query: url.searchParams, body })
      } catch (error) {
        // 错误响应本身也可能失败（如连接已断开）：兜底销毁连接，杜绝未处理 rejection。
        try {
          if (error instanceof HttpError) {
            sendJson(res, error.status, { error: error.message })
          } else {
            sendJson(res, 500, {
              error: error instanceof Error ? error.message : 'internal error',
            })
          }
        } catch {
          res.destroy()
        }
      }
    },
  }
}

/** 解析 Host 头为主机名与端口（小写；IPv6 字面量 `[::1]:3000` 正确处理）。 */
function parseHostHeader(host: string): { hostname: string; port: string } {
  const trimmed = host.trim().toLowerCase()
  if (trimmed.startsWith('[')) {
    // IPv6 字面量：] 之前是主机名，其后可有 :port。
    const close = trimmed.indexOf(']')
    if (close !== -1) {
      const rest = trimmed.slice(close + 1)
      return {
        hostname: trimmed.slice(1, close),
        port: rest.startsWith(':') ? rest.slice(1) : '',
      }
    }
    return { hostname: trimmed, port: '' }
  }
  // IPv4 / 域名：最后一个冒号是端口分隔（多个冒号说明是裸 IPv6，无端口）。
  const colon = trimmed.lastIndexOf(':')
  if (colon !== -1 && trimmed.indexOf(':') === colon) {
    return { hostname: trimmed.slice(0, colon), port: trimmed.slice(colon + 1) }
  }
  return { hostname: trimmed, port: '' }
}

/**
 * Origin/Referer 值与请求 Host 是否同源（主机名与端口一致）。
 * Origin 形如 `http://127.0.0.1:3210`；Referer 是完整 URL，URL 解析通吃。
 * 缺省端口按协议补齐（http→80、https→443）；解析失败按不同源处理。
 *
 * Host 头未携带显式端口（经反向代理/TLS 终止器部署在 443，或裸 80）：
 * 接受来源协议的任一默认端口（80/443）——此时端口无从比对，主机名才是
 * 有效判据；来源端口非默认（如 8080）仍拒绝，跨端口重绑定防线不变。
 */
function isSameOrigin(sourceValue: string, hostHeader: string): boolean {
  let source: URL
  try {
    source = new URL(sourceValue)
  } catch {
    return false
  }
  const host = parseHostHeader(hostHeader)
  const sourcePort = source.port || (source.protocol === 'https:' ? '443' : '80')
  if (host.port === '') {
    return source.hostname === host.hostname && (sourcePort === '80' || sourcePort === '443')
  }
  return source.hostname === host.hostname && sourcePort === host.port
}

/** 发送 JSON 响应。 */
export function sendJson(res: ServerResponse, status: number, payload: unknown): void {
  if (res.writableEnded) return
  if (res.headersSent) {
    // 响应头已发出（handler 已开始写 body）：无法再改写状态行，直接结束响应。
    res.end()
    return
  }
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(payload))
}

/** 请求体读取默认超时（毫秒）。 */
const BODY_READ_TIMEOUT_MS = 30_000

/**
 * 读取并解析 JSON 请求体（大小上限默认 8 MB；空正文返回 {}）。
 * @param req 请求对象。
 * @param limitBytes 大小上限（字节）。
 * @param timeoutMs 读取超时（默认 30 秒）：慢速/停滞的 body 不会无限挂起，超时抛 408。
 */
export async function readJsonBody(
  req: IncomingMessage,
  limitBytes: number = 8 * 1024 * 1024,
  timeoutMs: number = BODY_READ_TIMEOUT_MS,
): Promise<unknown> {
  const chunks = await new Promise<Buffer[]>((resolve, reject) => {
    const buffer: Buffer[] = []
    let size = 0
    let settled = false
    const timer = setTimeout(() => {
      fail(new HttpError('request body read timeout', 408))
      req.destroy()
    }, timeoutMs)
    const fail = (error: Error): void => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(error)
    }
    req.on('data', (chunk: Buffer) => {
      if (settled) return
      size += chunk.byteLength
      if (size > limitBytes) {
        fail(new HttpError('request body too large', 413))
        req.destroy()
        return
      }
      buffer.push(chunk)
    })
    req.on('end', () => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve(buffer)
    })
    req.on('error', (error: Error) => fail(error))
    req.on('close', () => {
      // 正常结束时 close 在 end 之后到达，settled 已置位；此处只处理提前断开。
      fail(new HttpError('request body stream closed early', 400))
    })
  })
  if (chunks.length === 0) return {}
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'))
  } catch {
    throw new HttpError('request body is not valid JSON', 400)
  }
}
