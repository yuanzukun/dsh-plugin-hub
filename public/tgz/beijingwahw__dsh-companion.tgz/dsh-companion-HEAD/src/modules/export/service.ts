/**
 * 模块 A 导出服务函数：HTTP 端点与命令面板共用（DESIGN.md 第 5 节纪律）。
 *
 * 管线：sessionQuery.readSession → transcriptFromLog →（可选）按选中回合下标过滤 →
 * （可选）逐轮 redactText 脱敏 → 按格式渲染（markdown / json / pdf / png）。
 *
 * 回合级选择导出（能力吸收自 dsh-conv-export）：GET /export/turns 提供回合
 * 预览列表（角色 + 折叠截断纯文本），POST /export/run 携带 turns 下标数组
 * 仅导出选中回合（如剔除失败的尝试或跑题的段落）。
 *
 * PDF/PNG 光栅路径（能力吸收自 dsh-conv-export）：
 * - PDF 全文 Latin-1 安全时直接生成结构化 PDF（kind:'file'）；
 * - 调用方具备客户端光栅能力（raster=true，浏览器 canvas）时：
 *   PNG 长图与含非 Latin-1 字符的 PDF 一律返回 kind:'raster' 载荷，
 *   由客户端光栅化为 PNG / 免打印多页 PDF，全程无 window.print() 对话框；
 * - 无光栅能力（命令面板）时：含非 Latin-1 字符的 PDF 退回打印友好 HTML
 *   路径（kind:'print'），PNG 不支持（HttpError 400）。
 * 响应形状严格对应 DESIGN.md 第 4 节：kind:'file'（base64）、kind:'print'（html）
 * 或 kind:'raster'（html + target）。
 */
import { HttpError } from '../../core/http.js'
import { buildPrintHtml, buildSimplePdf, escapeHtml, isLatin1Safe } from '../../core/pdf.js'
import { redactText } from '../../core/privacy.js'
import { beijingDayKey, formatBeijingTime } from '../../core/time.js'
import {
  transcriptFromLog,
  transcriptToJson,
  transcriptToMarkdown,
  type TranscriptTurn,
} from '../../core/transcript.js'
import { buildZip, sanitizeFileName, type ZipEntry } from '../../core/zip.js'
import type {
  SessionHeader,
  SessionLogSnapshot,
  SessionQueryEngine,
  SessionId,
} from '../../types/harness.js'

/** 导出格式。 */
export type ExportFormat = 'markdown' | 'pdf' | 'json' | 'png'

/** 单次导出选项。 */
export interface ExportOptions {
  /** 目标格式。 */
  format: ExportFormat
  /** 转录是否附带北京时间时间戳（缺省 true）。 */
  timestamps?: boolean
  /** 导出前是否对每轮文本执行隐私脱敏（缺省 false）。 */
  redact?: boolean
  /**
   * 调用方是否具备客户端光栅能力（浏览器 canvas，缺省 false）。
   * true：PNG 长图与含非 Latin-1 字符的 PDF 返回 kind:'raster' 载荷，
   * 由客户端光栅化，全程无打印对话框；
   * false（命令面板等无 canvas 环境）：PNG 不支持（HttpError 400），
   * 含非 Latin-1 字符的 PDF 退回 kind:'print' 打印页。
   */
  raster?: boolean
  /**
   * 仅导出选中的回合（回合在 GET /export/turns 列表中的下标，0 起）。
   * 缺省/undefined = 导出全部回合；越界下标静默忽略
   * （append-only 日志下旧回合下标稳定，宽容处理列表与导出间的漂移）；
   * 过滤后无可导出回合时抛 400。
   */
  turns?: readonly number[]
}

/** 文件类导出载荷：字节内容一律 base64（DESIGN.md 第 4 节）。 */
export interface ExportFilePayload {
  kind: 'file'
  fileName: string
  mimeType: string
  contentBase64: string
}

/** 打印类导出载荷：无光栅能力时 PDF 含非 Latin-1 字符的浏览器打印回退。 */
export interface ExportPrintPayload {
  kind: 'print'
  fileName: string
  html: string
}

/**
 * 光栅类导出载荷：客户端以 canvas 将打印 HTML 光栅化为成品
 * （PNG 长图或免打印多页 PDF），全程无 window.print() 对话框。
 */
export interface ExportRasterPayload {
  kind: 'raster'
  /** 目标成品：png=长图，pdf=免打印多页 PDF。 */
  target: 'png' | 'pdf'
  fileName: string
  html: string
}

/** 导出载荷联合（POST /export/run 的响应形状）。 */
export type ExportPayload = ExportFilePayload | ExportPrintPayload | ExportRasterPayload

/** 批量导出会话数上限（去重后计数）。 */
export const MAX_BATCH_SESSIONS = 100

/** 回合预览长度上限（折叠空白后的字符数；吸收自 dsh-conv-export 的面板预览）。 */
export const TURN_PREVIEW_CHARS = 160

/** 回合选择面板的单回合预览（GET /export/turns 响应项）。 */
export interface ExportTurnSummary {
  /** 回合在列表中的下标（0 起），导出请求的 turns 数组引用该值。 */
  index: number
  role: TranscriptTurn['role']
  /** 回合事件时间（毫秒时间戳）。 */
  time: number
  /** 折叠空白后截断的纯文本预览（仅面板展示用，不参与导出内容）。 */
  preview: string
}

/** GET /export/turns 响应形状。 */
export interface ExportTurnsPayload {
  turns: readonly ExportTurnSummary[]
}

/**
 * 单会话读取失败（会话不存在等）：批量导出时可跳过，
 * 其余条目照常入包；HTTP 语义为 404。
 * 与之相对，非本类型的错误视为系统性错误（存储介质/渲染管线等），
 * 批量导出不再吞掉，直接上抛（HTTP 层收敛为 500）。
 */
export class SessionReadError extends HttpError {
  constructor(sessionId: string) {
    super(`会话不存在或读取失败：${sessionId}`, 404)
    this.name = 'SessionReadError'
  }
}

/** 导出生成中间产物（字节未 base64，便于批量打包复用）。 */
type BuiltExport =
  | { kind: 'file'; fileName: string; mimeType: string; bytes: Uint8Array }
  | { kind: 'print'; fileName: string; html: string }
  | { kind: 'raster'; target: 'png' | 'pdf'; fileName: string; html: string }

/** 文本编码器（导出字节统一 UTF-8）。 */
const encoder = new TextEncoder()

/**
 * 导出单个会话（供 HTTP 与命令复用）。
 * @param sessionQuery Harness 会话查询服务（对 ctx 的唯一依赖）。
 * @param sessionId 目标会话品牌 id。
 * @param options 格式与开关（timestamps 缺省 true，redact 缺省 false）。
 * @returns DESIGN.md 第 4 节规定的响应形状。
 */
export async function buildSingleExport(
  sessionQuery: SessionQueryEngine,
  sessionId: SessionId,
  options: ExportOptions,
): Promise<ExportPayload> {
  const built = await buildExport(sessionQuery, sessionId, options)
  if (built.kind === 'print') {
    return { kind: 'print', fileName: built.fileName, html: built.html }
  }
  if (built.kind === 'raster') {
    return { kind: 'raster', target: built.target, fileName: built.fileName, html: built.html }
  }
  return {
    kind: 'file',
    fileName: built.fileName,
    mimeType: built.mimeType,
    contentBase64: toBase64(built.bytes),
  }
}

/**
 * 批量导出多个会话并打包为 ZIP（PDF 非 Latin-1 的条目以 .html 入包）。
 * @param sessionQuery Harness 会话查询服务。
 * @param sessionIds 会话 id 列表：先经 Set 去重，去重后数量不得超过
 * MAX_BATCH_SESSIONS；单个会话读取失败（SessionReadError）会被跳过，
 * 系统性错误（存储介质/渲染管线等）则上抛，不再无差别吞掉。
 * @param options 格式与开关（统一作用于全部会话）。
 * @returns ZIP 文件载荷，文件名含打包当日北京日期。
 */
export async function buildBatchExport(
  sessionQuery: SessionQueryEngine,
  sessionIds: readonly SessionId[],
  options: ExportOptions,
): Promise<ExportFilePayload> {
  if (sessionIds.length === 0) throw new HttpError('sessionIds 不能为空', 400)
  if (options.format === 'png') {
    throw new HttpError('PNG 长图需客户端逐张光栅化，不支持批量 ZIP 导出', 400)
  }
  // 去重：避免同一会话被重复导出打包。
  const uniqueIds = [...new Set(sessionIds)]
  if (uniqueIds.length > MAX_BATCH_SESSIONS) {
    throw new HttpError(`批量导出一次最多支持 ${MAX_BATCH_SESSIONS} 个会话`, 400)
  }
  // 批量打包在服务端完成：强制关闭客户端光栅（非 Latin-1 PDF 以 .html 入包）。
  const batchOptions: ExportOptions = { ...options, raster: false }
  const entries: ZipEntry[] = []
  const usedNames = new Set<string>()
  for (const sessionId of uniqueIds) {
    let built: BuiltExport
    try {
      built = await buildExport(sessionQuery, sessionId, batchOptions)
    } catch (error) {
      // 单会话读取失败：跳过，其余照常入包；
      // 其余错误视为系统性错误，上抛由 HTTP 层收敛为 500。
      if (error instanceof SessionReadError) continue
      throw error
    }
    const name = uniqueEntryName(usedNames, built.fileName)
    // 批量打包强制 raster:false，产物只会是 file 或 print（print 以 .html 入包）。
    const data = built.kind === 'file' ? built.bytes : encoder.encode(built.html)
    entries.push({ name, data })
  }
  if (entries.length === 0) throw new HttpError('没有可导出的会话', 404)
  return {
    kind: 'file',
    fileName: `deepseek-conversations-${beijingDayKey(Date.now())}.zip`,
    mimeType: 'application/zip',
    contentBase64: toBase64(buildZip(entries)),
  }
}

/**
 * 列出会话的回合预览（回合选择面板数据源，吸收自 dsh-conv-export）。
 *
 * 下标语义：与 transcriptFromLog 的输出顺序一致（按 seq 稳定排序），
 * append-only 日志下旧回合下标不漂移；新回合只追加在列表末尾。
 */
export async function listTurns(
  sessionQuery: SessionQueryEngine,
  sessionId: SessionId,
): Promise<ExportTurnsPayload> {
  let snapshot: SessionLogSnapshot
  try {
    snapshot = await sessionQuery.readSession(sessionId)
  } catch (error) {
    // 与 buildExport 同一错误分级：仅「会话不存在」归 404，
    // 系统性错误原样上抛（HTTP 层收敛为 500），不被伪装成 404。
    if (isSessionMissingError(error)) throw new SessionReadError(sessionId)
    throw error
  }
  const turns = transcriptFromLog(snapshot)
  return {
    turns: turns.map((turn, index) => ({
      index,
      role: turn.role,
      time: turn.time,
      preview: turnPreview(turn.text),
    })),
  }
}

/**
 * 回合预览文本：折叠全部空白为单空格后截断（吸收自 dsh-conv-export
 * 的 previewOf 语义——先折叠后截断，超长以省略号收尾）。
 */
function turnPreview(text: string): string {
  const collapsed = text.replace(/\s+/g, ' ').trim()
  return collapsed.length > TURN_PREVIEW_CHARS
    ? `${collapsed.slice(0, TURN_PREVIEW_CHARS)}…`
    : collapsed
}

/**
 * 将错误收敛为用户安全的 HttpError：
 * HttpError 原样透传；其余错误以通用文案包装，避免泄漏内部细节。
 */
export function toSafeHttpError(error: unknown, fallbackMessage: string): HttpError {
  if (error instanceof HttpError) return error
  return new HttpError(fallbackMessage, 500)
}

/** 提取命令面板可用的用户可读错误文本（不泄漏内部细节）。 */
export function userFacingMessage(error: unknown, fallbackMessage: string): string {
  if (error instanceof HttpError) return error.message
  return fallbackMessage
}

/**
 * 判定读取异常是否为「会话不存在」类：harness 的 readSession 未提供
 * 类型化错误，以消息特征启发式归类（not found / no such / ENOENT /
 * 不存在 / 无会话）。其余（存储 I/O、日志校验失败等）视为系统性错误：
 * 不得伪装成 404 被批量导出静默跳过，须原样上抛（HTTP 层收敛为 500）。
 */
function isSessionMissingError(error: unknown): boolean {
  return (
    error instanceof Error && /not\s*found|no\s*such|enoent|不存在|无会话|无此会话/i.test(error.message)
  )
}

/** 读取会话并渲染为导出中间产物。 */
async function buildExport(
  sessionQuery: SessionQueryEngine,
  sessionId: SessionId,
  options: ExportOptions,
): Promise<BuiltExport> {
  let snapshot: SessionLogSnapshot
  try {
    snapshot = await sessionQuery.readSession(sessionId)
  } catch (error) {
    // 仅「会话不存在」归类为 SessionReadError（批量可跳过、HTTP 404）；
    // 存储故障等系统性错误原样上抛（HTTP 500 / 批量整体失败），
    // 与 buildBatchExport 的错误分级注释语义对齐。
    if (isSessionMissingError(error)) throw new SessionReadError(sessionId)
    throw error
  }

  const timestamps = options.timestamps ?? true
  const session = snapshot.session
  const title = session.title || session.id
  let turns = transcriptFromLog(snapshot)
  // 回合级选择导出：仅保留选中下标的回合（越界下标静默忽略）。
  if (options.turns) {
    const keep = new Set(options.turns)
    turns = turns.filter((_, index) => keep.has(index))
    if (turns.length === 0) {
      throw new HttpError('所选回合没有可导出的内容，请至少勾选一个回合', 400)
    }
  }
  if (options.redact ?? false) {
    turns = turns.map((turn) => ({ ...turn, text: redactText(turn.text).text }))
  }
  const baseName = sanitizeFileName(title)

  if (options.format === 'markdown') {
    return {
      kind: 'file',
      fileName: `${baseName}.md`,
      mimeType: 'text/markdown; charset=utf-8',
      bytes: encoder.encode(transcriptToMarkdown(session, turns, { timestamps })),
    }
  }
  if (options.format === 'json') {
    return {
      kind: 'file',
      fileName: `${baseName}.json`,
      mimeType: 'application/json; charset=utf-8',
      bytes: encoder.encode(transcriptToJson(session, turns, { timestamps })),
    }
  }

  // PNG 长图：服务端无 canvas，必须由客户端光栅化（raster=true）。
  if (options.format === 'png') {
    if (!(options.raster ?? false)) {
      throw new HttpError('PNG 长图导出需要客户端界面（浏览器 canvas），命令面板暂不支持', 400)
    }
    return {
      kind: 'raster',
      target: 'png',
      fileName: `${baseName}.png`,
      html: buildPrintHtml(title, buildPrintBody(session, turns, timestamps)),
    }
  }

  // PDF：全文（标题 + 正文行）可 Latin-1 编码时直接生成 PDF，否则走光栅/打印 HTML。
  const lines = buildPdfLines(turns, timestamps)
  if (isLatin1Safe([title, ...lines].join('\n'))) {
    return {
      kind: 'file',
      fileName: `${baseName}.pdf`,
      mimeType: 'application/pdf',
      bytes: buildSimplePdf(title, lines),
    }
  }
  const html = buildPrintHtml(title, buildPrintBody(session, turns, timestamps))
  // 有客户端光栅能力：返回 raster 载荷，客户端生成免打印多页 PDF（无 window.print() 冻结）。
  if (options.raster ?? false) {
    return { kind: 'raster', target: 'pdf', fileName: `${baseName}.pdf`, html }
  }
  return { kind: 'print', fileName: `${baseName}.html`, html }
}

/** 说话人展示名。 */
function speakerLabel(role: TranscriptTurn['role']): string {
  if (role === 'user') return '用户'
  if (role === 'assistant') return '助手'
  return role
}

/**
 * PDF 正文行的说话人标签（ASCII）。
 * buildSimplePdf 只能编码 Latin-1，该快路径仅在全文 Latin-1 安全时启用，
 * 用 ASCII 标签保证纯英文对话能真正走直出 PDF，而不是被中文标签误判
 * 为不可编码、永远退回打印/光栅路径。
 */
function pdfSpeakerLabel(role: TranscriptTurn['role']): string {
  if (role === 'user') return 'User'
  if (role === 'assistant') return 'Assistant'
  return role
}

/**
 * PDF 正文行（标题由 buildSimplePdf 单独渲染，不含在内）。
 * 时间戳使用 ASCII 括号，避免 Latin-1 安全的全角字符把纯英文对话误判为不可编码。
 */
function buildPdfLines(turns: readonly TranscriptTurn[], timestamps: boolean): string[] {
  const lines: string[] = []
  for (const turn of turns) {
    const stamp = timestamps ? ` (${formatBeijingTime(turn.time)})` : ''
    lines.push(`${pdfSpeakerLabel(turn.role)}${stamp}`, '')
    lines.push(...turn.text.split('\n'))
    lines.push('')
  }
  return lines
}

/** 打印友好页的正文 HTML（全部经转义，元信息头与 Markdown 导出对齐）。 */
function buildPrintBody(
  session: SessionHeader,
  turns: readonly TranscriptTurn[],
  timestamps: boolean,
): string {
  const meta = [
    `会话 ID：${session.id}`,
    `创建时间：${formatBeijingTime(session.createdAt)}`,
    `导出时间：${formatBeijingTime(Date.now())}`,
    `消息轮次：${turns.length}`,
  ]
    .map((item) => escapeHtml(item))
    .join(' · ')
  const parts: string[] = [
    `<h1>${escapeHtml(session.title || '未命名对话')}</h1>`,
    `<p class="meta">${meta}</p>`,
  ]
  for (const turn of turns) {
    const stamp = timestamps ? `（${formatBeijingTime(turn.time)}）` : ''
    parts.push(`<h3>${escapeHtml(`${speakerLabel(turn.role)}${stamp}`)}</h3>`)
    parts.push(`<pre>${escapeHtml(turn.text)}</pre>`)
  }
  return parts.join('\n')
}

/** 字节内容 base64 编码（HTTP 响应中字节一律 base64）。 */
function toBase64(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString('base64')
}

/** ZIP 条目名去重：重名时在扩展名前插入 -2/-3… 序号，防止覆盖。 */
function uniqueEntryName(used: Set<string>, name: string): string {
  if (!used.has(name)) {
    used.add(name)
    return name
  }
  const dot = name.lastIndexOf('.')
  const stem = dot > 0 ? name.slice(0, dot) : name
  const ext = dot > 0 ? name.slice(dot) : ''
  for (let suffix = 2; ; suffix += 1) {
    const candidate = `${stem}-${suffix}${ext}`
    if (!used.has(candidate)) {
      used.add(candidate)
      return candidate
    }
  }
}
