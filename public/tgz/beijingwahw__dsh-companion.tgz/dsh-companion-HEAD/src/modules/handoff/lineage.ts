/**
 * 会话继承图谱（轴线 2：上下文血缘）：追踪交接摘要跨会话的传播链路。
 *
 * 概念模型：有向无环图。
 * - 节点 = 会话；边 = 一次摘要交接（source → target）；
 * - 边在 `POST /handoff/import` 时记录（携带 sourceSessionId 时）：
 *   指定 target 会话的武装直接落边；pending 武装先落「悬边」
 *   （target = null），待 pending 被消费（投递回执）时解析为真实目标；
 * - pending 被解除/过期时删除悬边，避免后续 pending 消费误认领；
 * - ancestorsOf / descendantsOf 做环安全图遍历（visited 集合），
 *   按「跳数」升序返回（近源优先）。
 *
 * 存储域：companion `handoff-lineage` 表；键 = `${source}>${target}:${linkedAt}`
 * （target 为悬边时用 `pending` 占位）。摘要摘录（首行 ≤80 字）随边存储，
 * 供客户端展示「经由什么内容传播」。
 */
import type { Domain } from '@deepseek-ai/dsh-storage'

/** 悬边（pending）的目标占位符。 */
const PENDING_TARGET = 'pending'

/** 摘录最大长度（超出截断）。 */
const EXCERPT_LIMIT = 80

/** 图谱滚动保留边数上限（超出按 linkedAt 淘汰最旧）。 */
const EDGE_KEEP_LIMIT = 500

/** 继承边记录。 */
export interface LineageEdge {
  /** 摘要来源会话 id。 */
  sourceSessionId: string
  /** 摘要去向会话 id；null = 悬边（pending 待解析）。 */
  targetSessionId: string | null
  /** 摘要首行摘录（展示用）。 */
  excerpt: string
  /** 边建立时间（毫秒）。 */
  linkedAt: number
  /** 悬边所属 pending 世代；只有相同 armedAt 的消费/过期才能改写或删除。 */
  pendingArmedAt?: number
}

/** 图遍历结果条目（含跳数）。 */
export interface LineageNode {
  sessionId: string
  /** 距查询起点的跳数（1 = 直接相邻）。 */
  depth: number
  /** 传播所用摘要摘录。 */
  excerpt: string
  linkedAt: number
}

/** 从摘要正文提取首行摘录（≤80 字符）。 */
function firstLineExcerpt(summary: string): string {
  const line = summary
    .split('\n')
    .map((l) => l.trim())
    .find((l) => l.length > 0)
  if (line === undefined) return ''
  return line.length > EXCERPT_LIMIT ? `${line.slice(0, EXCERPT_LIMIT)}…` : line
}

/** 会话继承图谱存储。 */
export class LineageStore {
  private readonly table

  /** 在已打开的 companion 存储域上创建。 */
  constructor(domain: Domain) {
    this.table = domain.table<LineageEdge>('handoff-lineage')
  }

  /** 存储键：source>target:linkedAt（悬边 target 用 pending 占位）。 */
  private keyOf(source: string, target: string | null, linkedAt: number): string {
    return `${source}>${target ?? PENDING_TARGET}:${linkedAt}`
  }

  /**
   * 记录一条继承边；target 为 null 表示悬边（pending 待解析）。
   * 写入后滚动修剪到 EDGE_KEEP_LIMIT 条。
   */
  async recordEdge(
    source: string,
    target: string | null,
    summary: string,
    pendingArmedAt?: number,
  ): Promise<void> {
    const linkedAt = Date.now()
    const edge: LineageEdge = {
      sourceSessionId: source,
      targetSessionId: target,
      excerpt: firstLineExcerpt(summary),
      linkedAt,
      pendingArmedAt: target === null ? pendingArmedAt : undefined,
    }
    await this.table.put(this.keyOf(source, target, linkedAt), edge)
    const entries = this.table.entries()
    if (entries.length <= EDGE_KEEP_LIMIT) return
    const stale = entries
      .sort((a, b) => a[1].linkedAt - b[1].linkedAt)
      .slice(0, entries.length - EDGE_KEEP_LIMIT)
    for (const [key] of stale) await this.table.delete(key)
  }

  /**
   * 按 armedAt 世代解析悬边；重复武装留下的旧悬边不会被新投递误认领。
   * 同时保留原 linkedAt（血缘时间 = 武装时刻）。
   */
  async resolvePendingTargets(target: string, armedAt: number): Promise<void> {
    const pending = this.table
      .entries()
      .filter(([, edge]) => edge.targetSessionId === null && edge.pendingArmedAt === armedAt)
    for (const [key, edge] of pending) {
      if (edge.sourceSessionId === target) {
        // 自环（摘要武装回来源会话）：删除而非改写，保持 DAG 语义。
        await this.table.delete(key)
        continue
      }
      await this.table.delete(key)
      await this.table.put(this.keyOf(edge.sourceSessionId, target, edge.linkedAt), {
        ...edge,
        targetSessionId: target,
      })
    }
  }

  /** 删除悬边；传入 armedAt 时只清理对应世代，显式解除则清理全部。 */
  async deletePendingEdges(armedAt?: number): Promise<void> {
    const pending = this.table
      .entries()
      .filter(
        ([, edge]) =>
          edge.targetSessionId === null &&
          (armedAt === undefined || edge.pendingArmedAt === armedAt),
      )
    for (const [key] of pending) await this.table.delete(key)
  }

  /**
   * 祖先链：沿 source 方向向上遍历（谁的内容流入了本会话）。
   * 环安全（visited 去重）；按跳数升序、同跳数按时间升序。
   */
  ancestorsOf(sessionId: string, maxDepth = 10): LineageNode[] {
    const edges = this.table.entries().map(([, edge]) => edge)
    const visited = new Set<string>([sessionId])
    let frontier = [sessionId]
    const result: LineageNode[] = []
    for (let depth = 1; depth <= maxDepth && frontier.length > 0; depth += 1) {
      const next: string[] = []
      const found: LineageNode[] = []
      for (const node of frontier) {
        for (const edge of edges) {
          if (edge.targetSessionId !== node) continue
          if (visited.has(edge.sourceSessionId)) continue
          visited.add(edge.sourceSessionId)
          next.push(edge.sourceSessionId)
          found.push({
            sessionId: edge.sourceSessionId,
            depth,
            excerpt: edge.excerpt,
            linkedAt: edge.linkedAt,
          })
        }
      }
      found.sort((a, b) => a.linkedAt - b.linkedAt)
      result.push(...found)
      frontier = next
    }
    return result
  }

  /**
   * 后代链：沿 target 方向向下遍历（本会话的内容流向了哪些会话）。
   * 环安全（visited 去重）；按跳数升序、同跳数按时间升序。
   */
  descendantsOf(sessionId: string, maxDepth = 10): LineageNode[] {
    const edges = this.table.entries().map(([, edge]) => edge)
    const visited = new Set<string>([sessionId])
    let frontier = [sessionId]
    const result: LineageNode[] = []
    for (let depth = 1; depth <= maxDepth && frontier.length > 0; depth += 1) {
      const next: string[] = []
      const found: LineageNode[] = []
      for (const node of frontier) {
        for (const edge of edges) {
          if (edge.sourceSessionId !== node) continue
          if (edge.targetSessionId === null || visited.has(edge.targetSessionId)) continue
          visited.add(edge.targetSessionId)
          next.push(edge.targetSessionId)
          found.push({
            sessionId: edge.targetSessionId,
            depth,
            excerpt: edge.excerpt,
            linkedAt: edge.linkedAt,
          })
        }
      }
      found.sort((a, b) => a.linkedAt - b.linkedAt)
      result.push(...found)
      frontier = next
    }
    return result
  }

  /** 图谱总览：全部已解析边（悬边除外），按时间降序（调试/面板用）。 */
  listEdges(): LineageEdge[] {
    return this.table
      .entries()
      .map(([, edge]) => edge)
      .filter((edge) => edge.targetSessionId !== null)
      .sort((a, b) => b.linkedAt - a.linkedAt)
  }
}
