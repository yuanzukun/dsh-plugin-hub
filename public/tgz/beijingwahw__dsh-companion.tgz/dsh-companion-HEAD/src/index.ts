/**
 * DeepSeek Companion — DeepSeek Harness 官方伴侣插件（宿主入口）。
 *
 * 一切皆插件：本入口只做两件事——
 * 1. 挂载 CompanionCore 根服务（存储域 / 保险库 / 记账 / HTTP 路由）；
 * 2. 按配置分别挂载七个功能模块（A 导出 / B 交接摘要 / C 成本优化 /
 *    D 检索 / E 语义检索 / F 知识资产 / G 跨会话合成），
 *    每个模块是独立子插件，可单独启停、互不影响。
 */
import type { Context } from '@deepseek-ai/cordis'
import { Config } from './config.js'
import type { Config as ConfigShape } from './config.js'
import { CompanionCoreService } from './core/service.js'
import * as exportModule from './modules/export/index.js'
import * as handoffModule from './modules/handoff/index.js'
import * as costModule from './modules/cost/index.js'
import * as searchModule from './modules/search/index.js'
import * as retrievalModule from './modules/retrieval/index.js'
import * as knowledgeModule from './modules/knowledge/index.js'
import * as synthesisModule from './modules/synthesis/index.js'

export const name = 'deepseek-companion'

export { Config }
export type { ConfigShape }

export function apply(ctx: Context, config: ConfigShape): void {
  ctx.plugin(CompanionCoreService, config)

  if (config.enableExport) {
    ctx.plugin(exportModule)
  }
  if (config.enableHandoff) {
    ctx.plugin(handoffModule)
  }
  if (config.enableCost) {
    ctx.plugin(costModule)
  }
  if (config.enableSearch) {
    ctx.plugin(searchModule)
  }
  if (config.enableRetrieval) {
    ctx.plugin(retrievalModule)
  }
  if (config.enableKnowledge) {
    ctx.plugin(knowledgeModule)
  }
  if (config.enableSynthesis) {
    ctx.plugin(synthesisModule)
  }
}
