# dsh-calculator

DeepSeek Harness plugin (desktop 0.2.x): shows your **DeepSeek API spend**
and **account balance** in a top-right overlay card, with a live pill in the
conversation header (left of the session-log button).

- **当前会话费用** — per-model token spend of the session you are looking at
- **当天全部会话累计** — today's total across all sessions (local timezone)
- **胶囊实时费用** — collapsed pill shows today's spend live
- **账户余额** — live balance from the DeepSeek API (`GET /user/balance`)
- **网页搜索计费** — DeepSeek Search API calls bill **¥5 / 1000 successful
  requests (¥0.005 each)** from **2026-11-01 00:00 Beijing time**; each
  `web/deepseek-search-llm-request` event counts one call. Local `web_fetch`
  (HTTP provider) is free and not counted.
- **峰谷计价** — peak 09:00–12:00 & 14:00–18:00 Mon–Fri Beijing; weekends
  off-peak all day since 2026-08-23
- **中英文界面** — follows the browser language (`zh` / `en`)

## Install (desktop)

```bash
bash install.sh
```

The installer copies the package to `~/.dsh/vendor/dsh-calculator`, adds it as
a `file:` dependency of the `desktop` profile, activates it as a profile
bundle, and links it with the app's bundled pnpm. **Restart DeepSeek Harness**
after installing; the pill appears in the conversation header and the card
opens below the header.

Manual install: put the package in `~/.dsh/vendor/dsh-calculator`, then in
`~/.dsh/profiles/desktop/package.json` set
`"dependencies": { "dsh-calculator": "file:../../vendor/dsh-calculator" }` and
add `"dsh-calculator"` to `dsh.profile.bundles`, then run
`pnpm install` in that profile.

## Pricing

CNY per 1M tokens (official DeepSeek rates, api-docs.deepseek.com 2026-10-19):

| 模型 | 缓存命中输入（高峰/半价） | 缓存未命中输入（高峰/半价） | 输出（高峰/半价） |
|---|---|---|---|
| deepseek-flash / deepseek-v4.1-flash（2026-10-17 起） | ¥0.04 / ¥0.02 | ¥2.0 / ¥1.0 | ¥8.0 / ¥4.0 |
| deepseek-v4-flash / vision-exp（2026-10-17 前） | ¥0.10 / ¥0.05 | ¥3.0 / ¥1.5 | ¥9.0 / ¥4.5 |
| deepseek-v4-pro | ¥0.30 / ¥0.15 | ¥9.0 / ¥4.5 | ¥27.0 / ¥13.5 |

- 2026-08-17 之前的会话事件按当时费率计费；2026-09-10 12:00 起 flash 系列按
  V2 价（peak = 2x off-peak）；2026-10-17 起 V4.1-Flash 新价（上表首行）
- Search/Fetch API：¥5 / 1000 次成功请求，2026-11-01 00:00（北京）起计费；
  `web_fetch` 走本地 HTTP，不计费
- 计价按 **每个事件发生时的时段**（高峰/空闲）与价目版本分桶计算，不同时段
  的 token 不会混算
- 费用为估算值，与官方账单可能存在差异

## 数据来源

- 费用：host 半订阅会话事件（`assistant/message` 的 `usage` +
  `message.source`），按 `(provider, model, period, 价格版本)` 记账；fork
  子会话按 `message.id` 去重
- 搜索：`web/deepseek-search-llm-request` 事件计数
- 余额：`GET https://api.deepseek.com/user/balance`（30 秒缓存）

## 卸载

```bash
rm -rf ~/.dsh/vendor/dsh-calculator
# 并从 ~/.dsh/profiles/desktop/package.json 移除 dsh-calculator 依赖与 bundle
# 然后在该 profile 目录运行 pnpm install
```

## 免责声明

本项目与 DeepSeek 官方无任何关联，价格与余额为接口实时数据，费用为估算。
