#!/usr/bin/env bash
# dsh-calculator installer for DeepSeek Harness desktop (0.2.x).
#
# Installs the package as the desktop profile's pnpm dependency (file: link
# from $DSH_HOME/vendor/dsh-calculator) and activates it as a profile bundle.
# Idempotent: safe to re-run.
set -euo pipefail

DSH_HOME="${DSH_HOME:-$HOME/.dsh}"
PROFILE="$DSH_HOME/profiles/desktop"
VENDOR="$DSH_HOME/vendor/dsh-calculator"
SRC="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"

APP="/Applications/DeepSeek Harness.app"
PNPM="$APP/Contents/Resources/runtime/primary-runtime/dependencies/pnpm/bin/pnpm.mjs"
ELECTRON="$APP/Contents/MacOS/DeepSeek Harness"

if [ ! -f "$PNPM" ]; then
  echo "dsh-calculator: DeepSeek Harness.app not found at $APP" >&2
  exit 1
fi
if [ ! -f "$PROFILE/package.json" ]; then
  echo "dsh-calculator: desktop profile not found at $PROFILE" >&2
  exit 1
fi

echo "Installing dsh-calculator into $VENDOR"
mkdir -p "$VENDOR"
cp -R "$SRC/lib" "$SRC/package.json" "$SRC/cordis.patch.yml" "$VENDOR"/

python3 - "$PROFILE/package.json" <<'PY'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d.setdefault("dependencies", {})["dsh-calculator"] = "file:../../vendor/dsh-calculator"
profile = d.setdefault("dsh", {}).setdefault("profile", {})
bundles = profile.setdefault("bundles", [])
if "dsh-calculator" not in bundles:
    bundles.append("dsh-calculator")
json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
print("  updated", p)
PY

echo "Linking the package with the app's pnpm"
cd "$PROFILE"
ELECTRON_RUN_AS_NODE=1 "$ELECTRON" --expose-internals "$PNPM" install --no-frozen-lockfile 2>&1 | tail -4

echo "Done. Restart DeepSeek Harness to load the plugin."
