// ════════════════════════════════════════════════════════════════════
// dsh-ryoshu-slash · Host half
// 良秀「天殺拔刀斬」：带斩击特效的文件删除工具
// 默认 mode = review（审查确认）——强制审查，防误删
// 跨平台：Windows 走 PowerShell（Remove-Item / WPF 缩略图 / 系统图标）；
//         其他平台（macOS/Linux）走 Node 原生 fs.rm 永久删除，图标用内置静态图标兜底
// ════════════════════════════════════════════════════════════════════
import { defineTool } from '@deepseek-ai/dsh-tools'
import { fileURLToPath } from 'node:url'
import { rm } from 'node:fs/promises'
import z from '@deepseek-ai/schemastery'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'

export const name = 'dsh-ryoshu-slash'

// Windows 才有 PowerShell / System.Drawing / WPF（PresentationCore）
// 非 Windows 平台降级：fs.rm 永久删除 + 静态图标
const IS_WIN = process.platform === 'win32'

export const inject = ['tools', 'webServer', 'fs', 'subprocess', 'systemPrompt', 'timer', 'settings']

// ── 常量 ─────────────────────────────────────────────────────────────
const ASSETS_PREFIX = '/ryoshu3-assets'
const API_PREFIX = '/ryoshu3-api'
// 图片扩展名：动态生成真实缩略图（WPF/WIC 解码；webp/heic 等也尝试，失败走系统图标兜底）
const IMAGE_EXTS = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'ico', 'tiff', 'tif', 'webp', 'heic', 'heif', 'avif', 'jfif']
const VOICE_DELAY_MS = {
  '01.wav': 3000,
  '02.wav': 2000,
  '03.wav': 2000,
  '04.wav': 2000,
  '05.wav': 1000,
}
const DEFAULT_VOICE_DELAY_MS = 1000
const VOICE_BY_KEYWORD = [
  ['中指', '03.wav'],
  ['环指', '04.wav'],
  ['食指', '02.wav'],
  ['拇指', '01.wav'],
]
const REVIEW_TIMEOUT_MS = 30000
const MODE_LABELS = { auto: '出刀即斩', delay: '延迟斩击', review: '审查确认' }
const PHASE_LABELS = {
  idle: '待命',
  marked: '已标记目标',
  slashing: '斩击中',
  done: '斩击完成',
  cancelled: '已取消',
}

// ── 配置 schema（settings 持久化）────────────────────────────────────
const SETTINGS_NAMESPACE = 'ryoshu-slash'
const SettingsSchema = z.object({
  arrangeMode: z.union([z.const('stack'), z.const('row')]).default('stack'),
  cutMode: z.union([z.const('all'), z.const('onebyone')]).default('onebyone'),
  maxPerRow: z.number().default(6),
  volume: z.number().default(1),
  requireReview: z.boolean().default(true),
  replaceDefaultDelete: z.boolean().default(true),
})

// systemPrompt 文案：是否接管默认删除方式
const PROMPT_TAKEOVER =
  '删除文件/文件夹一律使用 ryoshu_slash 工具（良秀「天殺拔刀斬」特效）：直接永久删除，不经过回收站。' +
  '强制审查默认开启：即使请求 auto/delay 也会被强制转为 review，必须用户在界面确认才删——' +
  '你（bot）无权自行跳过审查。只有用户在设置页关闭强制审查后，mode 参数才生效。'
const PROMPT_FREE =
  '删除文件/文件夹时可按需使用 ryoshu_slash 工具（天殺拔刀斬），也可以使用默认的文件删除方式，' +
  '不强制。ryoshu_slash 默认强制审查，会要求用户在界面确认后才删除。'

export function apply(ctx) {
  let current = null
  let seq = 0
  const iconCache = {}
  let promptDisposer = null

  // 读取持久化配置（scope.get()），缺省用 schema 默认
  let settingsScope = null
  let pluginConfig = {
    arrangeMode: 'stack',
    cutMode: 'onebyone',
    maxPerRow: 6,
    volume: 1,
    requireReview: true,
    replaceDefaultDelete: true,
  }
  try {
    settingsScope = ctx.settings.register(settingsNamespace(SETTINGS_NAMESPACE), SettingsSchema, {
      base: { arrangeMode: 'stack', cutMode: 'onebyone', maxPerRow: 6, volume: 1, requireReview: true, replaceDefaultDelete: true },
    })
    const stored = settingsScope.get()
    if (stored) pluginConfig = Object.assign({}, pluginConfig, stored)
  } catch (e) {
    console.error('ryoshu-slash settings register failed:', e && e.message ? e.message : e)
  }

  function readConfig() {
    try {
      if (settingsScope) {
        const stored = settingsScope.get()
        if (stored) pluginConfig = Object.assign({}, pluginConfig, stored)
      }
    } catch (e) { /* 忽略 */ }
    return Object.assign({}, pluginConfig)
  }

  // 按「接管默认删除方式」开关动态注册 systemPrompt section
  function applyPromptSection() {
    if (promptDisposer) { promptDisposer(); promptDisposer = null }
    const cfg = readConfig()
    const takeover = cfg.replaceDefaultDelete !== false
    const text = takeover ? PROMPT_TAKEOVER : PROMPT_FREE
    try {
      promptDisposer = ctx.systemPrompt.section({ name: 'tool:ryoshu-slash', order: 150, text })
    } catch (e) { /* 忽略 */ }
    return takeover
  }

  function sleep(ms) {
    return new Promise((resolve) => {
      ctx.timeout(resolve, ms)
    })
  }

  function pickVoices(fileNames) {
    const hit = []
    for (const [keyword, voice] of VOICE_BY_KEYWORD) {
      for (const fileName of fileNames) {
        if (fileName && fileName.includes(keyword)) {
          if (!hit.includes(voice)) hit.push(voice)
        }
      }
    }
    return hit.length ? hit : null
  }

  function pickRandomVoice() {
    const voices = Object.keys(VOICE_DELAY_MS)
    return voices[Math.floor(Math.random() * voices.length)]
  }

  function voiceDelayOf(voice) {
    return voice ? (VOICE_DELAY_MS[voice] ?? DEFAULT_VOICE_DELAY_MS) : DEFAULT_VOICE_DELAY_MS
  }

  async function validatePaths(rawPaths) {
    const fs = ctx.fs
    const valid = []
    const rejected = []
    for (const raw of rawPaths) {
      try {
        const target = await fs.resolve(String(raw))
        const abs = fs.processPath(target)
        const info = await fs.stat(target)
        if (!info) throw new Error('not exist')
        const driveMatch = /^[A-Za-z]:[\\/]?$/.exec(abs)
        if (driveMatch) throw new Error('root')
        if (abs === '/' || abs === '\\') throw new Error('root')
        valid.push(abs)
      } catch (e) {
        rejected.push(String(raw))
      }
    }
    return { valid, rejected }
  }

  // 直接永久删除（不经过回收站）
  // Windows：Remove-Item（保留原有链路）；其他平台：Node 原生 fs.rm（recursive+force 永删）
  async function deletePaths(paths) {
    const deleted = []
    const failed = []
    if (IS_WIN) {
      const subprocess = ctx.subprocess
      if (!subprocess) {
        console.error('subprocess service unavailable; cannot delete')
        return { deleted, failed: [...paths] }
      }
      for (const p of paths) {
        try {
          const quoted = `'${String(p).replace(/'/g, "''")}'`
          const script = `Remove-Item -LiteralPath ${quoted} -Force -Recurse -ErrorAction Stop`
          const handle = subprocess.spawn({
            argv: ['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
            cwd: 'C:\\',
            stdio: { stdin: 'ignore', stdout: { maxBytes: 4096 }, stderr: { maxBytes: 4096 } },
            graceMs: 8000,
          })
          const outcome = await handle.done
          if (outcome.exitCode === 0) deleted.push(p)
          else failed.push(p)
        } catch (e) {
          console.error(`delete failed: ${p}`, e && e.message ? e.message : e)
          failed.push(p)
        }
      }
      return { deleted, failed }
    }
    // 非 Windows：fs.rm 永久删除（force 不存在不报错，recursive 删文件夹）
    for (const p of paths) {
      try {
        await rm(String(p), { recursive: true, force: true })
        deleted.push(p)
      } catch (e) {
        console.error(`delete failed: ${p}`, e && e.message ? e.message : e)
        failed.push(p)
      }
    }
    return { deleted, failed }
  }

  // 读取 collect 模式的输出流（DSH subprocess：done 不含 stdout，需用 handle.collected 读）
  function readCollected(handle, stream) {
    try {
      const col = handle && handle.collected && handle.collected[stream]
      if (!col) return ''
      return String(col.readFrom(0).text || '')
    } catch (e) {
      return ''
    }
  }

  // 标准 base64 → bytes（不能用 atob：DSH 的 atob 按 UTF-8 文本解码，会破坏二进制）
  function b64ToBytes(b64) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    const lut = {}
    for (let i = 0; i < 64; i++) lut[chars[i]] = i
    const bytes = []
    let buffer = 0
    let bits = 0
    for (const c of b64) {
      if (c === '=') break
      const v = lut[c]
      if (v === undefined) continue
      buffer = (buffer << 6) | v
      bits += 6
      if (bits >= 8) {
        bits -= 8
        bytes.push((buffer >> bits) & 0xff)
      }
    }
    return bytes
  }

  // 提取 exe/文件 的真实关联图标（base64 PNG）——仅 Windows（System.Drawing）
  async function extractIcon(path) {
    if (!IS_WIN) return null // 非 Windows：无关联图标 API，走 client 静态图标兜底
    const subprocess = ctx.subprocess
    if (!subprocess) return null
    try {
      const script =
        `Add-Type -AssemblyName System.Drawing; ` +
        `try { $i = [System.Drawing.Icon]::ExtractAssociatedIcon('${String(path).replace(/'/g, "''")}'); ` +
        `if ($i) { $b = $i.ToBitmap(); $ms = New-Object System.IO.MemoryStream; ` +
        `$b.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); ` +
        `[Convert]::ToBase64String($ms.ToArray()) } else { 'ERR' } } catch { 'ERR' }`
      const handle = subprocess.spawn({
        argv: ['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
        cwd: 'C:\\',
        stdio: { stdin: 'ignore', stdout: { maxBytes: 64 * 1024 }, stderr: { maxBytes: 4096 } },
        graceMs: 8000,
      })
      const outcome = await handle.done
      const out = readCollected(handle, 'stdout').trim()
      if (outcome.exitCode === 0 && out && out !== 'ERR' && out.length > 100) {
        return out
      }
    } catch (e) { /* 忽略 */ }
    return null
  }

  // 图片文件缩略图（base64 PNG，最长边 96px，等比缩放）——仅 Windows
  // 用 WPF BitmapDecoder（比 System.Drawing 更健壮：GDI+ 对部分 png/jpg 解码会抛异常；
  // WIC 支持 webp/heic 等更多格式）。非 Windows 无 WPF，返回 null 走静态图标兜底。
  async function thumbnailIcon(path) {
    if (!IS_WIN) return null
    const subprocess = ctx.subprocess
    if (!subprocess) return null
    try {
      const script =
        `Add-Type -AssemblyName PresentationCore; Add-Type -AssemblyName WindowsBase; ` +
        `try { $stream = [System.IO.File]::OpenRead('${String(path).replace(/'/g, "''")}'); ` +
        `$decoder = [System.Windows.Media.Imaging.BitmapDecoder]::Create($stream, [System.Windows.Media.Imaging.BitmapCreateOptions]::IgnoreColorProfile, [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad); ` +
        `$frame = $decoder.Frames[0]; ` +
        `$max = 96; $scale = [Math]::Min(1.0, $max / [Math]::Max($frame.PixelWidth, $frame.PixelHeight)); ` +
        `$tb = New-Object System.Windows.Media.Imaging.TransformedBitmap($frame, (New-Object System.Windows.Media.ScaleTransform($scale, $scale))); ` +
        `$enc = New-Object System.Windows.Media.Imaging.PngBitmapEncoder; ` +
        `$enc.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($tb)); ` +
        `$ms = New-Object System.IO.MemoryStream; ` +
        `$enc.Save($ms); $stream.Dispose(); ` +
        `[Convert]::ToBase64String($ms.ToArray()) } catch { 'ERR' }`
      const handle = subprocess.spawn({
        argv: ['powershell.exe', '-STA', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
        cwd: 'C:\\',
        stdio: { stdin: 'ignore', stdout: { maxBytes: 256 * 1024 }, stderr: { maxBytes: 4096 } },
        graceMs: 8000,
      })
      const outcome = await handle.done
      const out = readCollected(handle, 'stdout').trim()
      if (outcome.exitCode === 0 && out && out.startsWith('iVBOR') && out.length > 64) {
        return out
      }
    } catch (e) { /* 忽略 */ }
    return null
  }

  function snapshot() {
    if (
      current &&
      current.mode === 'review' &&
      current.phase === 'marked' &&
      !current.cancelRequested &&
      Date.now() - current.startedAt > REVIEW_TIMEOUT_MS
    ) {
      current.cancelRequested = true
      current.phase = 'cancelled'
    }
    if (!current) {
      return {
        seq: 0, phase: 'idle', mode: 'review', permanent: true,
        platform: IS_WIN ? 'win32' : process.platform,
        paths: [], rejected: [], voices: [], voice: null, delayMs: 0,
        deleted: [], failed: [], cancelled: false, pending: false,
        config: readConfig(),
      }
    }
    return {
      seq: current.seq,
      phase: current.phase,
      phaseLabel: PHASE_LABELS[current.phase] || current.phase,
      mode: current.mode,
      modeLabel: MODE_LABELS[current.mode] || current.mode,
      permanent: true,
      platform: IS_WIN ? 'win32' : process.platform,
      paths: current.paths,
      rejected: current.rejected || [],
      voices: current.voices || [],
      voice: current.voices && current.voices.length ? current.voices[0] : null,
      delayMs: current.delayMs,
      deleted: current.deleted || [],
      failed: current.failed || [],
      cancelled: current.cancelRequested,
      pending: current.mode === 'review' && current.phase === 'marked',
      config: readConfig(),
    }
  }

  // ── webServer：静态资源 + 动态图标 + API ──────────────────────────
  const webServer = ctx.webServer
  const fsService = ctx.fs

  if (webServer && fsService) {
    // 资源与动态图标路由（/ryoshu3-assets/*）
    ctx.effect(() => webServer.register({
      kind: 'prefix',
      path: ASSETS_PREFIX,
      handler: async (req, res) => {
        try {
          const raw = String(req.url || '').split('?')[0].split('#')[0]
          const rel = raw.replace(new RegExp('^' + ASSETS_PREFIX.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/?'), '')
          if (!rel || rel.includes('..') || rel.includes('\\')) {
            res.statusCode = 400
            res.end('bad path')
            return
          }
          // 动态图标：/icon/<encodeURIComponent路径>.png
          if (rel.startsWith('icon/')) {
            const encoded = rel.slice(5).replace(/\.png$/, '')
            let path = ''
            try { path = decodeURIComponent(encoded) } catch (e) { /* 忽略 */ }
            if (path && !path.includes('..')) {
              let b64 = iconCache[path]
              if (!b64) {
                // 图片文件 → 真实缩略图；缩略图失败（格式不支持等）→ 系统关联图标兜底
                // 其他（exe/文本/压缩包等）→ 系统关联图标
                const ext = path.split('.').pop().toLowerCase()
                const isImage = IMAGE_EXTS.includes(ext)
                b64 = isImage ? await thumbnailIcon(path) : null
                if (!b64) b64 = await extractIcon(path)
                if (b64) iconCache[path] = b64
              }
              if (b64) {
                try {
                  const arr = b64ToBytes(b64)
                  if (!arr.length) throw new Error('empty decode')
                  const bytes = Uint8Array.from(arr)
                  res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=3600' })
                  res.end(bytes)
                  return
                } catch (e) {
                  res.statusCode = 500
                  res.end('b64 decode failed')
                  return
                }
              }
              res.statusCode = 404
              res.end('icon extract failed')
              return
            }
            res.statusCode = 404
            res.end('bad icon path')
            return
          }
          const target = await fsService.resolve(fileURLToPath(new URL('./assets/' + rel, import.meta.url)))
          const info = await fsService.stat(target)
          if (!info) {
            res.statusCode = 404
            res.end('not found')
            return
          }
          const bytes = await fsService.readBytes(target, undefined, 32 * 1024 * 1024)
          const ext = rel.split('.').pop().toLowerCase()
          const mime =
            ext === 'wav' ? 'audio/wav'
            : ext === 'mp3' ? 'audio/mpeg'
            : ext === 'png' ? 'image/png'
            : ext === 'ico' ? 'image/x-icon'
            : 'application/octet-stream'
          res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'public, max-age=3600' })
          res.end(bytes)
        } catch (e) {
          res.statusCode = 404
          res.end('not found')
        }
      },
    }))

    // API 路由（/ryoshu3-api/*）：client 半经 HTTP 通信
    ctx.effect(() => webServer.register({
      kind: 'prefix',
      path: API_PREFIX,
      handler: async (req, res) => {
        const sendJson = (code, obj) => {
          res.writeHead(code, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify(obj))
        }
        try {
          const raw = String(req.url || '').split('?')[0].split('#')[0]
          const rel = raw.replace(new RegExp('^' + API_PREFIX.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/?'), '')
          if (rel === 'state' || rel === '') {
            sendJson(200, snapshot())
            return
          }
          if (rel === 'config') {
            if (req.method === 'POST') {
              let body = ''
              for await (const chunk of req) body += chunk
              let patch = {}
              try { patch = JSON.parse(body || '{}') } catch (e) { /* 忽略 */ }
              try {
                const next = Object.assign({}, readConfig(), patch)
                await ctx.settings.update(settingsNamespace(SETTINGS_NAMESPACE), next)
                pluginConfig = next
                // 接管开关变化 → 刷新 systemPrompt 文案
                applyPromptSection()
                sendJson(200, { ok: true, config: readConfig() })
              } catch (e) {
                sendJson(400, { ok: false, message: String(e && e.message ? e.message : e) })
              }
              return
            }
            sendJson(200, { ok: true, config: readConfig() })
            return
          }
          if (rel === 'confirm') {
            const s = current
            if (!s || s.phase !== 'marked' || s.mode !== 'review') {
              sendJson(400, { ok: false, message: '当前没有待审查的斩击' })
              return
            }
            if (s.cancelRequested) {
              s.phase = 'cancelled'
              sendJson(400, { ok: false, message: '斩击已取消，未删除任何文件。' })
              return
            }
            if (s.confirmed) {
              sendJson(400, { ok: false, message: '已确认出刀，正在删除…' })
              return
            }
            // 只打确认标记：真正的删除由工具 execute 统一执行，
            // 保证 tool-result 与动画/结果同步（不在 API 里删，避免双重删除）
            s.confirmed = true
            s.confirmedAt = Date.now()
            s.phase = 'slashing'
            sendJson(200, { ok: true, pending: false, message: '已确认出刀，正在删除…' })
            return
          }
          if (rel === 'cancel') {
            const s = current
            if (!s || (s.phase !== 'marked' && s.phase !== 'slashing')) {
              sendJson(400, { ok: false, message: '当前没有可取消的斩击' })
              return
            }
            s.cancelRequested = true
            // 立即终止：review 模式把 phase 置为 cancelled（client 隐藏面板并结束动画）
            if (s.phase === 'marked') {
              s.phase = 'cancelled'
            }
            sendJson(200, { ok: true })
            return
          }
          sendJson(404, { ok: false, message: 'unknown api' })
        } catch (e) {
          sendJson(500, { ok: false, message: String(e && e.message ? e.message : e) })
        }
      },
    }))

    console.log('ryoshu3-assets / ryoshu3-api routes registered (effect-owned)')
  }

  // ── systemPrompt：是否接管默认删除方式（跟随设置开关动态更新）────
  ctx.effect(() => {
    applyPromptSection()
    return () => {
      if (promptDisposer) { promptDisposer(); promptDisposer = null }
    }
  })

  // ── 工具：ryoshu_slash ────────────────────────────────────────────
  const tool = defineTool({
    name: 'ryoshu_slash',
    description:
      '良秀「天殺拔刀斬」：斩击并删除文件/文件夹（永久删除，不经过回收站）。' +
      '强制审查已开启（默认）：即使请求 mode=auto/delay 也会被强制转为 review，' +
      '标记后必须用户在界面确认才删，防止误删；用户可在设置页关闭强制审查。' +
      'mode=review 审查确认（默认）；mode=delay 延迟斩击（标记后可取消）；mode=auto 出刀即斩（仅当强制审查关闭时生效）。' +
      '删除文件请优先使用本工具。',
    parameters: {
      paths: {
        type: 'array',
        items: { type: 'string' },
        required: true,
        description: '要删除的文件/文件夹绝对路径列表；多个路径一刀全斩。',
      },
      mode: {
        type: 'string',
        enum: ['auto', 'delay', 'review'],
        description: 'review=审查确认；delay=延迟后删且可中途取消；auto=出刀即斩。注意：强制审查开启时一律按 review 处理，此参数仅当用户在设置页关闭强制审查后生效。',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          mode: { type: 'string', required: true },
          phase: { type: 'string', required: true },
          pending: { type: 'boolean', required: true },
          cancelled: { type: 'boolean', required: true },
          deleted: { type: 'array', items: { type: 'string' }, required: true },
          failed: { type: 'array', items: { type: 'string' }, required: true },
          message: { type: 'string', required: true },
        },
      },
      render: (args, value) => {
        const v = value || {}
        const lines = []
        lines.push('[天殺拔刀斬]')
        lines.push(`模式：${MODE_LABELS[v.mode] || v.mode} ｜ 状态：${PHASE_LABELS[v.phase] || v.phase}`)
        if (v.pending) {
          lines.push('[待确认] 等待用户在界面确认后才删除。')
        }
        if (v.cancelled) {
          lines.push('[已取消] 斩击已取消，未删除任何文件。')
        }
        if (Array.isArray(v.deleted) && v.deleted.length) {
          lines.push('[成功] 已删除：')
          for (const p of v.deleted) lines.push(`  - ${p}`)
        }
        if (Array.isArray(v.failed) && v.failed.length) {
          lines.push('[失败]：')
          for (const p of v.failed) lines.push(`  - ${p}`)
        }
        if (v.message) lines.push(`[信息] ${v.message}`)
        return [{ type: 'text', text: lines.join('\n') }]
      },
      presentationMeta: (args, value) => {
        const v = value || {}
        return {
          mode: v.mode,
          phase: v.phase,
          pending: v.pending,
          cancelled: v.cancelled,
          deleted: v.deleted || [],
          failed: v.failed || [],
          message: v.message,
        }
      },
    },
    isConcurrencySafe: () => false,
    async execute(args) {
      // 强制审查：requireReview 开启时（默认），无视 bot 传入的 mode 一律 review——
      // 防止 bot 用 auto 绕过审查乱删。用户可在设置页关闭此开关。
      const requireReview = readConfig().requireReview !== false
      const rawPaths = Array.isArray(args.paths) ? args.paths.filter((x) => typeof x === 'string' && x.trim()) : []
      const requestedMode = ['auto', 'delay', 'review'].includes(args.mode) ? args.mode : 'review'
      const mode = requireReview ? 'review' : requestedMode
      const modeForced = requireReview && requestedMode !== 'review'

      if (rawPaths.length === 0) {
        return {
          mode,
          phase: 'done',
          pending: false,
          cancelled: false,
          deleted: [],
          failed: [],
          message: '没有传入要删除的路径。',
        }
      }

      const { valid, rejected } = await validatePaths(rawPaths)
      if (valid.length === 0) {
        return {
          mode,
          phase: 'done',
          pending: false,
          cancelled: false,
          deleted: [],
          failed: rejected,
          message: '所有路径均未通过安全校验（不存在或为文件系统根目录），未删除任何文件。',
        }
      }

      const baseNames = valid.map((p) => p.replace(/\\/g, '/').split('/').pop() || '')
      const voices = pickVoices(baseNames) || [pickRandomVoice()]
      let delayMs = 0
      for (const v of voices) {
        delayMs = Math.max(delayMs, voiceDelayOf(v))
      }

      const session = {
        seq: ++seq,
        phase: 'marked',
        mode,
        permanent: true,
        paths: valid,
        rejected,
        voices,
        delayMs,
        cancelRequested: false,
        confirmed: false,
        confirmedAt: 0,
        deleted: [],
        failed: [],
        startedAt: Date.now(),
      }
      current = session

      // review 模式：挂起等待用户在界面确认/取消（client 轮询 /state 后 POST confirm）
      // 不能立即返回——否则 DSH 立刻生成 tool-result，卡片会误显示「已完成」，
      // 而实际还在等确认/砍杀。挂起期间取消返回 cancelled；确认后删除并等动画收尾。
      if (mode === 'review') {
        const deadline = Date.now() + REVIEW_TIMEOUT_MS
        while (!session.confirmed && !session.cancelRequested && Date.now() < deadline) {
          await sleep(120)
        }
        if (session.cancelRequested) {
          session.phase = 'cancelled'
          return {
            mode,
            phase: 'cancelled',
            pending: false,
            cancelled: true,
            deleted: [],
            failed: rejected,
            message: '斩击已被取消，未删除任何文件。',
          }
        }
        if (!session.confirmed) {
          session.cancelRequested = true
          session.phase = 'cancelled'
          return {
            mode,
            phase: 'cancelled',
            pending: false,
            cancelled: true,
            deleted: [],
            failed: rejected,
            message: '等待确认超时（30 秒），已自动取消，未删除任何文件。',
          }
        }
        session.phase = 'slashing'
        const confirmedAt = session.confirmedAt || Date.now()
        const cutMode = readConfig().cutMode
        const n = session.paths.length
        // 动画总时长估算（与 client/src.js 的 ANIM 常量同步，多留 600ms 尾巴）：
        // onebyone 最后一张卡片 cutDelay=(n-1)*900；单卡 cut 周期 ≈ 350+650+500+260+420=2180
        const animTotal = (cutMode === 'onebyone' ? Math.max(0, n - 1) * 900 : 0) + 2180 + 600
        const result = await deletePaths(session.paths)
        const remain = Math.max(0, animTotal - (Date.now() - confirmedAt))
        if (remain > 0) await sleep(remain)
        session.deleted = result.deleted
        session.failed = [...result.failed, ...rejected]
        session.phase = 'done'
        return {
          mode,
          phase: 'done',
          pending: false,
          cancelled: false,
          deleted: result.deleted,
          failed: session.failed,
          message: `天殺拔刀斬：${result.deleted.length} 个文件已永久删除。`,
        }
      }

      if (mode === 'auto') {
        await sleep(delayMs)
      } else {
        const deadline = Date.now() + delayMs
        while (Date.now() < deadline) {
          if (session.cancelRequested) break
          await sleep(40)
        }
      }

      if (session.cancelRequested) {
        session.phase = 'cancelled'
        return {
          mode,
          phase: 'cancelled',
          pending: false,
          cancelled: true,
          deleted: [],
          failed: [],
          message: '斩击已被取消，未删除任何文件。',
        }
      }

      session.phase = 'slashing'
      const result = await deletePaths(session.paths)
      session.deleted = result.deleted
      session.failed = [...result.failed, ...rejected]
      session.phase = 'done'
      return {
        mode,
        phase: 'done',
        pending: false,
        cancelled: false,
        deleted: result.deleted,
        failed: session.failed,
        message: `天殺拔刀斬：${result.deleted.length} 个文件已永久删除。`,
      }
    },
  })

  ctx.tools.register(tool)
  console.log('dsh-ryoshu-slash host half active (review by default)')
}
