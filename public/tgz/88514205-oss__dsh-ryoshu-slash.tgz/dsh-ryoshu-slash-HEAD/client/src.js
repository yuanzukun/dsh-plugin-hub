// ════════════════════════════════════════════════════════════════════
// dsh-ryoshu-slash · Client half（源码，经 build-client.mjs 包装构建）
// 动画与 ryoshu-slash-test.html 一模一样；通信走 HTTP API（fetch）
// ════════════════════════════════════════════════════════════════════

const React = require('react')

// 开源图标：Lucide（ISC 许可）内联 SVG，避免表情符号
// 图标：sword（剑）、slash（斩击）、settings（齿轮）、alert（警告）、check（勾）、x（叉）
function IconSword(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('polyline', { points: '14.5 17.5 3 6 3 3 6 3 17.5 14.5' }),
    React.createElement('line', { x1: '13', y1: '19', x2: '19', y2: '13' }),
    React.createElement('line', { x1: '16', y1: '16', x2: '20', y2: '20' }),
    React.createElement('line', { x1: '19', y1: '21', x2: '21', y2: '19' }),
  )
}
function IconSlash(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('circle', { cx: '12', cy: '12', r: '10' }),
    React.createElement('path', { d: 'M4.9 19.1 19.1 4.9' }),
  )
}
function IconSettings(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('path', { d: 'M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z' }),
    React.createElement('circle', { cx: '12', cy: '12', r: '3' }),
  )
}
function IconAlert(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('path', { d: 'm21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z' }),
    React.createElement('path', { d: 'M12 9v4' }),
    React.createElement('path', { d: 'M12 17h.01' }),
  )
}
function IconCheck(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('path', { d: 'M20 6 9 17l-5-5' }),
  )
}
function IconX(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('path', { d: 'M18 6 6 18' }),
    React.createElement('path', { d: 'm6 6 12 12' }),
  )
}
function IconGrid(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('rect', { width: '7', height: '7', x: '3', y: '3', rx: '1' }),
    React.createElement('rect', { width: '7', height: '7', x: '14', y: '3', rx: '1' }),
    React.createElement('rect', { width: '7', height: '7', x: '14', y: '14', rx: '1' }),
    React.createElement('rect', { width: '7', height: '7', x: '3', y: '14', rx: '1' }),
  )
}
function IconRows(props) {
  const size = props.size || 18
  const color = props.color || 'currentColor'
  return React.createElement('svg', {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
    style: props.style,
  },
    React.createElement('rect', { width: '18', height: '6', x: '3', y: '4', rx: '1' }),
    React.createElement('rect', { width: '18', height: '6', x: '3', y: '14', rx: '1' }),
  )
}

const DEFAULT_SETTINGS = {
  arrangeMode: 'stack',
  cutMode: 'onebyone',
  maxPerRow: 6,
  volume: 1,
  requireReview: true,
  replaceDefaultDelete: true,
}
let SETTINGS = Object.assign({}, DEFAULT_SETTINGS)
// 运行平台（host /state 下发）：win32 才请求动态系统图标/缩略图，
// 其他平台（macOS/Linux）host 无图标 API，直接用内置静态图标，避免无谓的 404 请求
let PLATFORM = 'win32'

function injectCss(css) {
  try {
    const style = document.createElement('style')
    style.setAttribute('data-ryoshu2', '1')
    style.textContent = css
    document.head.appendChild(style)
  } catch (e) { /* 忽略 */ }
}

injectCss(`
.ryoshu2-stage {
  position: fixed;
  inset: 0;
  z-index: 2147483000;
  pointer-events: none;
  overflow: hidden;
  font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif;
}
.ryoshu2-stage canvas.stage {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: block;
}
.ryoshu2-toolcard {
  border: 1px solid rgba(255, 120, 80, 0.45);
  border-radius: 10px;
  background: linear-gradient(135deg, rgba(30, 18, 26, 0.92), rgba(40, 22, 30, 0.92));
  color: #f0e0d0;
  padding: 10px 14px;
  margin: 4px 0;
  font-size: 12.5px;
  line-height: 1.7;
  box-shadow: 0 0 18px rgba(255, 90, 40, 0.18);
}
.ryoshu2-toolcard .head {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 800;
  color: #ffcf8a;
  letter-spacing: 1px;
  margin-bottom: 6px;
}
.ryoshu2-toolcard .head img { width: 22px; height: 22px; }
.ryoshu2-toolcard .badge {
  font-size: 11px;
  font-weight: 600;
  border-radius: 4px;
  padding: 1px 7px;
  margin-left: auto;
}
.ryoshu2-toolcard .badge.auto { background: rgba(200, 40, 40, 0.35); color: #ffb0b0; }
.ryoshu2-toolcard .badge.delay { background: rgba(220, 150, 30, 0.3); color: #ffd990; }
.ryoshu2-toolcard .badge.review { background: rgba(60, 120, 220, 0.32); color: #a8c8ff; }
.ryoshu2-toolcard .badge.done { background: rgba(60, 160, 80, 0.3); color: #a0e0b0; }
.ryoshu2-toolcard .badge.cancelled { background: rgba(140, 140, 140, 0.3); color: #ccc; }
.ryoshu2-toolcard ul { margin: 0; padding-left: 18px; max-height: 160px; overflow: auto; }
.ryoshu2-toolcard ul li { word-break: break-all; }
.ryoshu2-toolcard .foot {
  margin-top: 6px; font-size: 11.5px; color: #c0a890;
  border-top: 1px dashed rgba(255, 200, 150, 0.25); padding-top: 5px;
}
.ryoshu2-panel {
  position: fixed; top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2147483002; pointer-events: auto;
  background: rgba(18, 14, 24, 0.92);
  border: 1px solid rgba(255, 200, 120, 0.35);
  border-radius: 12px; padding: 18px 22px; color: #f0e6d8;
  box-shadow: 0 0 40px rgba(255, 120, 40, 0.25);
  min-width: 360px; max-width: 560px;
}
.ryoshu2-panel h3 { margin: 0 0 10px; font-size: 17px; color: #ffcf8a; letter-spacing: 2px; }
.ryoshu2-panel ul { margin: 0 0 14px; padding-left: 18px; max-height: 200px; overflow: auto; font-size: 12.5px; line-height: 1.8; }
.ryoshu2-panel ul li { word-break: break-all; }
.ryoshu2-panel .hint { font-size: 12px; color: #b8a898; margin-bottom: 12px; }
.ryoshu2-panel .btns { display: flex; gap: 10px; justify-content: flex-end; }
.ryoshu2-btn {
  border: 1px solid rgba(255, 255, 255, 0.25); border-radius: 6px;
  padding: 7px 18px; font-size: 13px; cursor: pointer; color: #fff; background: transparent;
}
.ryoshu2-btn:hover { filter: brightness(1.2); }
.ryoshu2-btn.confirm { background: #a02020; border-color: #ff8080; }
.ryoshu2-btn.cancel { background: #333; border-color: #888; }
.ryoshu2-flash {
  position: fixed; inset: 0; z-index: 2147482999;
  background: #fff; opacity: 0; pointer-events: none;
}
.ryoshu2-settings {
  display: flex; flex-direction: column; gap: 12px;
  font-size: 13px; color: #dce8f4;
}
.ryoshu2-settings .row {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 8px 10px; background: rgba(255,255,255,0.04); border-radius: 8px;
}
.ryoshu2-settings .row label { color: #9fc0d8; }
.ryoshu2-settings select, .ryoshu2-settings input[type=number] {
  background: #0e1e2e; color: #dce8f4; border: 1px solid rgba(120,180,230,0.4);
  border-radius: 6px; padding: 4px 8px; font-size: 12.5px;
}
.ryoshu2-settings h3 { margin: 4px 0 2px; color: #8fd4ff; font-size: 14px; letter-spacing: 1px; }
`)

function rand(a, b) { return a + Math.random() * (b - a) }
function randInt(a, b) { return a + Math.floor(Math.random() * (b - a + 1)) }

const EASING = {
  easeOutCubic: (t) => 1 - Math.pow(1 - t, 3),
  easeOutQuart: (t) => 1 - Math.pow(1 - t, 4),
  easeOutBack: (t) => { const c1 = 1.4, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2) },
  easeOutQuad: (t) => 1 - (1 - t) * (1 - t),
}
const ANIM = {
  popDur: 1500, popStagger: 420, popWobble: 6, settleBreath: 0.012,
  chargeDur: 350, bladeLife: 26, splitDur: 650, pauseAfterCut: 500,
  whiteHold: 260, fadeDur: 420, splitDist: 62, cutOneByOneGap: 900,
}

function sliceRect(rad) {
  const CW = 84, CH = 98
  const CORNERS = [[0, 0], [CW, 0], [CW, CH], [0, CH]]
  const cx = CW / 2, cy = CH / 2
  const dX = Math.cos(rad), dY = -Math.sin(rad)
  const nX = -dY, nY = dX
  const interp = (a, b, da, db) => {
    const t = da / (da - db)
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]
  }
  const clip = (keepAbove) => {
    const out = []
    const n = CORNERS.length
    for (let i = 0; i < n; i++) {
      const a = CORNERS[i], b = CORNERS[(i + 1) % n]
      const da = (a[0] - cx) * nX + (a[1] - cy) * nY
      const db = (b[0] - cx) * nX + (b[1] - cy) * nY
      const keepA = keepAbove ? da >= 0 : da < 0
      const keepB = keepAbove ? db >= 0 : db < 0
      if (keepA) out.push(a)
      if (keepA !== keepB) out.push(interp(a, b, da, db))
    }
    return out
  }
  return { a: clip(true), b: clip(false) }
}

const ICONS = {}
const ICON_LIST = ['txt', 'md', 'doc', 'pdf', 'zip', 'img', 'exe', 'py', 'js', 'folder']
function loadIcons() {
  for (const k of ICON_LIST) {
    const img = new Image()
    img.src = `/ryoshu3-assets/icons/${k}.png`
    ICONS[k] = img
  }
}
loadIcons()
// 静态 fallback 图标（动态系统图标加载失败/未加载完时兜底）
function staticIconFor(ext) {
  if (ext === 'exe') return ICONS.exe
  if (['jpg', 'jpeg', 'gif', 'bmp', 'png', 'ico', 'tiff', 'tif', 'webp'].includes(ext)) return ICONS.img
  if (ICONS[ext]) return ICONS[ext]
  if (ext === 'docx') return ICONS.doc
  if (['rar', '7z'].includes(ext)) return ICONS.zip
  if (['ts', 'json', 'yml', 'yaml', 'log', 'css', 'html'].includes(ext)) return ICONS.js
  if (['txt', 'log', 'ini', 'cfg', 'conf'].includes(ext)) return ICONS.txt
  return ICONS.folder || ICONS.doc
}

function iconFor(name, path) {
  const ext = (name.split('.').pop() || '').toLowerCase()
  const fallback = staticIconFor(ext)
  // 仅 Windows 请求动态系统图标/缩略图；其他平台直接静态图标
  if (path && PLATFORM === 'win32') {
    // 所有文件类型都请求系统图标/缩略图（图片→缩略图，其他→Windows 关联图标）
    const key = 'dyn:' + path
    let img = ICONS[key]
    if (!img) {
      img = new Image()
      img.onerror = () => { ICONS[key] = fallback } // 加载失败 → 永久回退静态图标
      try {
        img.src = '/ryoshu3-assets/icon/' + encodeURIComponent(path) + '.png'
      } catch (e) {
        ICONS[key] = fallback
        return fallback
      }
      ICONS[key] = img
    }
    if (img && img.complete && img.naturalWidth > 0) return img
    return fallback // 未加载完或失败时先显示静态图标，避免占位蓝块
  }
  return fallback
}

function drawFileIcon(g, cx, cy, size, name, path, alpha, rot, white) {
  const img = iconFor(name, path)
  g.save()
  if (rot) {
    g.translate(cx, cy)
    g.rotate((rot * Math.PI) / 180)
    g.translate(-cx, -cy)
  }
  g.globalAlpha = Math.max(0, Math.min(1, alpha))
  if (white > 0.5) {
    g.filter = 'brightness(0) invert(1)'
  }
  const w = size * 0.86
  const h = size * 1.0
  if (img && img.complete && img.naturalWidth > 0) {
    // 保持宽高比，适配 size 框（真实缩略图/图标不变形）
    const iw = img.naturalWidth, ih = img.naturalHeight
    const sc = Math.min(w / iw, h / ih)
    const dw = iw * sc, dh = ih * sc
    g.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh)
  } else {
    g.fillStyle = '#7fa8d9'
    g.fillRect(cx - w / 2, cy - h / 2, w, h)
  }
  g.filter = 'none'
  g.restore()
}

function drawHalf(g, c, poly, offX, offY, name, alpha, white, scale) {
  const s = scale || 1
  g.save()
  g.translate(c.x + offX, c.y + offY)
  g.scale(s, s)
  g.beginPath()
  poly.forEach((p, i) => {
    const px = p[0] - 42, py = p[1] - 49
    if (i === 0) g.moveTo(px, py)
    else g.lineTo(px, py)
  })
  g.closePath()
  g.clip()
  drawFileIcon(g, 0, 0, 84, name, c.basePath, alpha, 0, white)
  g.restore()
}

function FileCard(name, basePath) {
  this.name = name
  this.basePath = basePath
  this.x = 0; this.y = 0
  this.fromX = 0; this.fromY = 0
  this.curX = 0; this.curY = 0
  this.t = 0
  this.delay = 0
  this.spin = 0
  this.scale = 1
  this.restRot = Math.random() * Math.PI * 2
  this.wobbleSeed = Math.random() * Math.PI * 2
  this.angle = 0
  this.cutT = 0
  this.cutDelay = 0
  this.slashed = false
  this.phase = 'spawn'
  this.dead = false
}

function drawSlashBlade(g, p1, p2, scale) {
  const x1 = p1[0]; const y1 = p1[1]
  const x2 = p2[0]; const y2 = p2[1]
  const dx = x2 - x1; const dy = y2 - y1
  const length = Math.hypot(dx, dy)
  if (length < 1 || scale <= 0.01) return
  const nx = -dy / length; const ny = dx / length
  const mx = (x1 + x2) / 2; const my = (y1 + y2) / 2
  const layers = [
    [110, [200, 200, 220, 38], true, 1.0],
    [94, [212, 212, 228, 55], true, 1.0],
    [78, [228, 228, 240, 75], true, 1.0],
    [62, [244, 244, 252, 120], true, 1.0],
    [46, [255, 255, 255, 210], true, 1.0],
    [16, [12, 12, 16, 180], false, 0.82],
  ]
  for (const layer of layers) {
    const fullWidth = layer[0]; const rgb = layer[1]
    const additive = layer[2]; const lengthScale = layer[3]
    const half = (fullWidth * scale) / 2
    const alpha = Math.floor(rgb[3] * scale)
    if (half < 0.5 || alpha <= 0) continue
    const startX = mx - (dx * lengthScale) / 2
    const startY = my - (dy * lengthScale) / 2
    const endX = mx + (dx * lengthScale) / 2
    const endY = my + (dy * lengthScale) / 2
    g.save()
    g.globalCompositeOperation = additive ? 'lighter' : 'source-over'
    g.globalAlpha = 1
    g.fillStyle = `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${alpha / 255})`
    g.beginPath()
    g.moveTo(startX, startY)
    g.quadraticCurveTo(mx + nx * half, my + ny * half, endX, endY)
    g.quadraticCurveTo(mx - nx * half, my - ny * half, startX, startY)
    g.closePath()
    g.fill()
    g.restore()
  }
}

function drawParticles(g, particles) {
  for (const p of particles) {
    const ratio = p.life / p.maxLife
    if (ratio <= 0) continue
    g.globalAlpha = ratio
    g.fillStyle = p.color
    g.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size)
  }
}

function Ryoshu2Stage(props) {
  const ctx = props.ctx
  const [state, setState] = React.useState(null)
  const canvasRef = React.useRef(null)
  const flashRef = React.useRef(null)
  const cardsRef = React.useRef([])
  const seqRef = React.useRef('')
  const animTimerRef = React.useRef(null)
  const audioRef = React.useRef({ bgm: null, voices: [] })
  const slashesRef = React.useRef([])
  const particlesRef = React.useRef([])
  let lastSfx = 0

  async function fetchState() {
    try {
      const resp = await fetch('/ryoshu3-api/state', { cache: 'no-store' })
      if (!resp.ok) return null
      return await resp.json()
    } catch (e) {
      return null
    }
  }

  React.useEffect(() => {
    const timerId = window.setInterval(async () => {
      const s = await fetchState()
      if (!s) return
      // 同步持久化配置（host settings → client SETTINGS）与平台
      if (s.config && typeof s.config === 'object') {
        SETTINGS = Object.assign({}, DEFAULT_SETTINGS, s.config)
      }
      if (typeof s.platform === 'string') PLATFORM = s.platform
      const key = `${s.seq}:${s.phase}`
      if (key !== seqRef.current) {
        seqRef.current = key
        setState(s)
      }
    }, 80)
    return () => { window.clearInterval(timerId) }
  }, [])

  React.useEffect(() => {
    if (!state) return
    const phase = state.phase
    if (phase === 'marked') {
      const viewW = (typeof window !== 'undefined' && window.innerWidth) || 1280
      const viewH = (typeof window !== 'undefined' && window.innerHeight) || 800
      const paths = Array.isArray(state.paths) ? state.paths : []
      const cards = paths.map((p) => {
        const base = p.replace(/\\/g, '/').split('/').pop() || p
        return new FileCard(base, p)
      })
      const N = cards.length
      const cx = viewW / 2, cy = viewH * 0.42
      const arrange = SETTINGS.arrangeMode
      const cutMode = SETTINGS.cutMode
      const maxPerRow = Math.max(1, SETTINGS.maxPerRow || 6)
      const cardW = 100
      // 网格矩阵布局：多行多列整齐排列（列数 = min(maxPerRow, N)，行数自适应）
      const rows = Math.max(1, Math.ceil(N / maxPerRow))
      const cols = Math.min(maxPerRow, N)
      const gapX = Math.max(cardW * 1.15, Math.min(220, viewW * 0.72 / Math.max(cols, 1)))
      const gapY = 118
      const gridTop = cy - ((rows - 1) * gapY) / 2
      cards.forEach((c, i) => {
        c.fromX = viewW * (0.14 + (i % 4) * 0.06)
        c.fromY = viewH * 0.97
        const row = Math.floor(i / cols)
        const col = i % cols
        const xOff = (col - (cols - 1) / 2) * gapX
        const yOff = gridTop - cy + row * gapY
        if (cutMode === 'onebyone') {
          // 逐个砍：网格矩阵，每行从左到右，行间整齐
          c.x = cx + xOff
          c.y = cy + yOff
          c.spin = -30 + Math.random() * 60
          c.scale = rows > 3 ? 0.7 : rows === 3 ? 0.8 : rows === 2 ? 0.9 : 1
        } else if (arrange === 'stack') {
          // 堆叠(抽卡)：网格矩阵但相邻卡片轻微错位堆叠感
          c.x = cx + xOff + (i % 2) * 8 - 4
          c.y = cy + yOff + (i % 3) * 6 - 6
          c.spin = -20 + Math.random() * 40
          c.scale = rows > 3 ? 0.7 : rows === 3 ? 0.8 : rows === 2 ? 0.9 : 1
        } else {
          // 排列一排：严格网格
          c.x = cx + xOff
          c.y = cy + yOff
          c.spin = -15 + Math.random() * 30
          c.scale = rows > 3 ? 0.7 : rows === 3 ? 0.8 : rows === 2 ? 0.9 : 1
        }
        c.delay = i * ANIM.popStagger
        c.phase = 'spawn'
      })
      cardsRef.current = cards
      playVoices(state)
      startAnim()
    } else if (phase === 'slashing') {
      const cards = cardsRef.current
      const cutMode = SETTINGS.cutMode
      const viewW = (typeof window !== 'undefined' && window.innerWidth) || 1280
      const viewH = (typeof window !== 'undefined' && window.innerHeight) || 800
      const commonAngle = rand(-70, 70)
      cards.forEach((c, i) => {
        c.angle = cutMode === 'all' ? commonAngle : rand(-70, 70)
        c.phase = 'cut'
        c.cutT = 0
        c.cutDelay = cutMode === 'onebyone' ? i * ANIM.cutOneByOneGap : 0
        c.slashed = false
      })
      slashesRef.current = []
      particlesRef.current = []
      for (let i = 0; i < 50; i++) {
        particlesRef.current.push({
          x: viewW / 2 + rand(-30, 30), y: viewH * 0.42 + rand(-30, 30),
          vx: rand(-6, 6), vy: rand(-6, 6),
          life: randInt(30, 70), maxLife: 70,
          size: randInt(2, 6),
          color: Math.random() < 0.6 ? '#20242c' : '#ffffff',
        })
      }
      startAnim()
    } else if (phase === 'done') {
      fadeBgmOut()
    } else if (phase === 'cancelled') {
      fadeBgmOut()
      window.setTimeout(() => {
        cardsRef.current.forEach((c) => { c.dead = true })
      }, 300)
    }
  }, [state])

  function playVoices(s) {
    const a = audioRef.current
    if (!a.bgm) {
      try {
        const bgm = new Audio('/ryoshu3-assets/music/araya.mp3')
        bgm.loop = true; bgm.volume = 0; bgm.play().catch(() => {})
        a.bgm = bgm
        let v = 0
        const bgmTarget = 0.12 * (SETTINGS.volume ?? 1)
        const fadeId = window.setInterval(() => {
          v = Math.min(bgmTarget, v + 0.008); bgm.volume = v
          if (v >= bgmTarget) window.clearInterval(fadeId)
        }, 60)
      } catch (e) { /* 忽略 */ }
    }
    const voices = Array.isArray(s.voices) && s.voices.length ? s.voices : (s.voice ? [s.voice] : [])
    const vn = voices[0]
    if (!vn) return
    for (const v of a.voices) { try { v.pause() } catch (e) { /* 忽略 */ } }
    a.voices = []
    try {
      const au = new Audio(`/ryoshu3-assets/voice/${vn}`)
      au.volume = 0.9 * (SETTINGS.volume ?? 1)
      au.play().catch(() => {})
      a.voices.push(au)
    } catch (e) { /* 忽略 */ }
  }

  function playSfx() {
    const now = Date.now()
    if (now - lastSfx < 300) return
    lastSfx = now
    try {
      const sfxNames = [
        'gakryoshu_1_1.wav', 'gakryoshu_2_2.wav', 'gakryoshu_3_2.wav', 'gakryoshu_3_3.wav',
        'gakryoshu_4_2-1.wav', 'gakryoshu_4_2-2.wav', 'gakryoshu_4_2-3.wav', 'gakryoshu_4_2.wav',
        'gakryoshu_6_5.wav',
      ]
      const name = sfxNames[Math.floor(Math.random() * sfxNames.length)]
      const sfx = new Audio(`/ryoshu3-assets/sfx/${name}`)
      sfx.volume = 0.8 * (SETTINGS.volume ?? 1)
      sfx.play().catch(() => {})
    } catch (e) { /* 忽略 */ }
  }

  function fadeBgmOut() {
    const bgm = audioRef.current.bgm
    if (!bgm) return
    let v = bgm.volume
    const fadeId = window.setInterval(() => {
      v = Math.max(0, v - 0.01)
      bgm.volume = v
      if (v <= 0) { try { bgm.pause() } catch (e) { /* 忽略 */ }; window.clearInterval(fadeId) }
    }, 60)
  }

  function startAnim() {
    if (animTimerRef.current) return
    const canvas = canvasRef.current
    if (!canvas) return
    const g = canvas.getContext('2d')
    const viewW = (typeof window !== 'undefined' && window.innerWidth) || 1280
    const viewH = (typeof window !== 'undefined' && window.innerHeight) || 800
    canvas.width = viewW
    canvas.height = viewH
    let last = Date.now()
    animTimerRef.current = window.setInterval(() => {
      const now = Date.now()
      const dt = Math.min(64, now - last)
      last = now
      const alive = tick(g, dt, now, viewW, viewH)
      if (!alive) {
        window.clearInterval(animTimerRef.current)
        animTimerRef.current = null
        try { g.clearRect(0, 0, viewW, viewH) } catch (e) { /* 忽略 */ }
      }
    }, 16)
  }

  function tick(g, dt, now, viewW, viewH) {
    const cards = cardsRef.current
    g.clearRect(0, 0, viewW, viewH)

    for (const c of cards) {
      if (c.dead) continue
      if (c.phase === 'spawn') {
        c.t += dt
        const p = Math.min(1, Math.max(0, (c.t - c.delay) / ANIM.popDur))
        if (p <= 0) continue
        const e = EASING.easeOutBack(p)
        const wobAmp = ANIM.popWobble * (1 - Math.min(1, p * 2))
        const wob = Math.sin(c.t * 0.012 + c.wobbleSeed) * wobAmp
        const x = c.fromX + (c.x - c.fromX) * e + wob
        const y = c.fromY + (c.y - c.fromY) * e + Math.sin(c.t * 0.009 + c.wobbleSeed) * wobAmp * 0.5
        const sc = 0.35 + 0.65 * e
        const rotNow = c.spin * (1 - Math.min(1, p * 1.8))
        const alpha = Math.min(1, p * 2.2)
        const scFull = sc * (c.scale || 1)
        c.curX = x; c.curY = y
        drawFileIcon(g, x, y, 84 * scFull, c.name, c.basePath, alpha, rotNow, 0)
        drawLabel(g, c.name, x, y + 44 * scFull, alpha)
        if (p >= 1) c.phase = 'settle'
      } else if (c.phase === 'settle') {
        const bx = Math.sin(now * 0.0009 + c.restRot) * 2.4
        const by = Math.cos(now * 0.0008 + c.restRot) * 1.8
        const br = Math.sin(now * 0.001 + c.restRot * 2) * ANIM.settleBreath
        const brot = Math.sin(now * 0.0008 + c.restRot) * 1.1
        const scS = 1 * (c.scale || 1)
        c.curX = c.x + bx; c.curY = c.y + by
        drawFileIcon(g, c.x + bx, c.y + by, 84 * (1 + br) * scS, c.name, c.basePath, 1, brot, 0)
        drawLabel(g, c.name, c.x + bx, c.y + by + 44 * scS, 1)
      } else if (c.phase === 'cut') {
        c.cutT += dt
        const t0 = Math.max(0, c.cutT - c.cutDelay)
        const rad = (c.angle * Math.PI) / 180
        const nX = Math.sin(rad), nY = Math.cos(rad)
        if (!c.slashed && t0 >= ANIM.chargeDur) {
          c.slashed = true
          slashesRef.current.push({ active: true, life: ANIM.bladeLife, maxLife: ANIM.bladeLife, x: c.x, y: c.y, angle: c.angle })
          playSfx()
        }
        const charge = Math.min(1, t0 / ANIM.chargeDur)
        if (charge < 1) {
          const sh = Math.sin(t0 * 0.05) * 2.2 * (1 - charge)
          c.curX = c.x; c.curY = c.y + sh * 0.4
          drawFileIcon(g, c.x, c.y + sh * 0.4, 84 * (c.scale || 1), c.name, c.basePath, 1, 0, 0)
          drawLabel(g, c.name, c.x, c.y + 44 * (c.scale || 1), 1)
          continue
        }
        const sepT = t0 - ANIM.chargeDur
        const sep = Math.min(1, sepT / ANIM.splitDur)
        const eSep = EASING.easeOutQuart(sep)
        const poly = sliceRect(rad)
        const dist = eSep * ANIM.splitDist
        const flashP = Math.min(1, sepT / 180)
        const flashWhite = Math.min(1, flashP * 1.8)
        const holdP = Math.max(0, sepT - ANIM.splitDur)
        const canWhite = holdP >= ANIM.pauseAfterCut
        const whiteHoldP = Math.max(0, holdP - ANIM.pauseAfterCut)
        const hold = canWhite ? Math.min(1, whiteHoldP / ANIM.whiteHold) : 0
        const holdWhite = hold * 0.95
        const fadeP = Math.max(0, whiteHoldP - ANIM.whiteHold)
        const fade = Math.min(1, fadeP / ANIM.fadeDur)
        const fadeE = EASING.easeOutQuad(fade)
        const white = Math.max(flashWhite, holdWhite) * (1 - fadeE)
        const alpha = Math.max(0, 1 - fadeE)
        c.curX = c.x; c.curY = c.y
        drawHalf(g, c, poly.a, nX * dist, nY * dist, c.name, alpha, white, c.scale || 1)
        drawHalf(g, c, poly.b, -nX * dist, -nY * dist, c.name, alpha, white, c.scale || 1)
        if (fade >= 1) c.dead = true
      }
    }

    const sls = slashesRef.current
    for (const s of sls) {
      if (!s.active) continue
      s.life -= 1
      const scale = Math.max(0, s.life / s.maxLife)
      const rad = (s.angle * Math.PI) / 180
      const len = 430
      const dx = Math.cos(rad) * len
      const dy = -Math.sin(rad) * len
      drawSlashBlade(g, [s.x - dx, s.y - dy], [s.x + dx, s.y + dy], scale)
      if (s.life <= 0) s.active = false
    }
    slashesRef.current = sls.filter((s) => s.active)

    const ps = particlesRef.current
    for (const p of ps) {
      p.x += p.vx; p.y += p.vy; p.life -= 1
      p.vx *= 0.97; p.vy *= 0.97
    }
    const livePs = ps.filter((p) => p.life > 0)
    drawParticles(g, livePs)
    particlesRef.current = livePs

    const flash = flashRef.current
    if (flash && parseFloat(flash.style.opacity || '0') > 0) {
      const next = Math.max(0, parseFloat(flash.style.opacity) - 10 / 255)
      flash.style.opacity = String(next)
    }

    const anyAlive = cards.some((c) => !c.dead) || livePs.length > 0 || slashesRef.current.length > 0
    return anyAlive
  }

  function drawLabel(g, text, x, y, alpha) {
    g.save()
    g.globalAlpha = Math.max(0, Math.min(1, alpha))
    g.font = '11px "Microsoft YaHei", sans-serif'
    g.textAlign = 'center'
    const w = g.measureText(text).width + 12
    g.fillStyle = 'rgba(10, 14, 22, 0.72)'
    g.fillRect(x - w / 2, y - 8, w, 16)
    g.strokeStyle = 'rgba(140, 200, 255, 0.5)'
    g.lineWidth = 1
    g.strokeRect(x - w / 2, y - 8, w, 16)
    g.fillStyle = '#e8f4ff'
    g.fillText(text, x, y + 3)
    g.restore()
  }

  React.useEffect(() => {
    return () => {
      if (animTimerRef.current) window.clearInterval(animTimerRef.current)
      const a = audioRef.current
      for (const v of a.voices) { try { v.pause() } catch (e) { /* 忽略 */ } }
      if (a.bgm) { try { a.bgm.pause() } catch (e) { /* 忽略 */ } }
    }
  }, [])

  const reviewPending = state && state.mode === 'review' && state.phase === 'marked'
  const delayActive = state && state.mode === 'delay' && state.phase === 'marked'

  return React.createElement(
    'div',
    null,
    React.createElement('div', {
      className: 'ryoshu2-stage',
      style: { display: (state && (state.phase === 'marked' || state.phase === 'slashing' || state.phase === 'done')) ? 'block' : 'none' },
    },
      React.createElement('canvas', { ref: canvasRef, className: 'stage' })),
    React.createElement('div', { ref: flashRef, className: 'ryoshu2-flash', style: { opacity: 0 } }),
    reviewPending
      ? React.createElement('div', { className: 'ryoshu2-panel' },
          React.createElement('h3', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
            React.createElement(IconSword, { size: 20, color: '#ffcf8a' }),
            React.createElement('span', null, '天殺拔刀斬 · 审查确认')),
          React.createElement('ul', null, (state.paths || []).map((p) => React.createElement('li', { key: p }, p))),
          React.createElement('div', { className: 'hint' }, `将永久删除 ${(state.paths || []).length} 个文件。确认后出刀，取消则放弃。`),
          React.createElement('div', { className: 'btns' },
            React.createElement('button', { className: 'ryoshu2-btn confirm', onClick: () => postApi('confirm') }, '确认出刀'),
            React.createElement('button', { className: 'ryoshu2-btn cancel', onClick: () => postApi('cancel') }, '取消'),
          ),
        )
      : delayActive
        ? React.createElement('div', { className: 'ryoshu2-panel' },
            React.createElement('h3', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
              React.createElement(IconSword, { size: 20, color: '#ffcf8a' }),
              React.createElement('span', null, '天殺拔刀斬 · 延迟斩击')),
            React.createElement('div', { className: 'hint' }, `已标记 ${(state.paths || []).length} 个文件，即将永久删除。可点击取消终止。`),
            React.createElement('div', { className: 'btns' },
              React.createElement('button', { className: 'ryoshu2-btn cancel', onClick: () => postApi('cancel') }, '取消斩击'),
            ),
          )
        : null,
  )
}

async function postApi(name) {
  try {
    await fetch('/ryoshu3-api/' + name, { method: 'POST', cache: 'no-store' })
  } catch (e) { /* 忽略 */ }
}

function Ryoshu2ToolCard(props) {
  const block = props.block
  const toolName = props.toolName
  let argsRaw = null
  let settled = false
  let isError = false
  if (block && block.kind === 'tool-result') {
    settled = true
    isError = !!block.isError
    if (block.call && block.call.argsRaw) argsRaw = block.call.argsRaw
  } else if (block) {
    argsRaw = block.argsRaw
  }
  let args = {}
  try { if (argsRaw) args = JSON.parse(argsRaw) } catch (e) { /* 忽略 */ }
  const paths = Array.isArray(args.paths) ? args.paths : []
  const mode = ['auto', 'delay', 'review'].includes(args.mode) ? args.mode : 'review'
  const modeLabel = { auto: '出刀即斩', delay: '延迟斩击', review: '审查确认' }[mode] || mode

  // 未结束时轮询 host 状态机，徽标跟随真实阶段（待确认/斩击中…/已取消/已完成）
  const [livePhase, setLivePhase] = React.useState(null)
  React.useEffect(() => {
    if (settled) return
    let alive = true
    const poll = async () => {
      try {
        const resp = await fetch('/ryoshu3-api/state', { cache: 'no-store' })
        if (!resp.ok) return
        const s = await resp.json()
        if (alive && s && typeof s.phase === 'string') setLivePhase(s.phase)
      } catch (e) { /* 忽略 */ }
    }
    poll()
    const id = window.setInterval(poll, 250)
    return () => { alive = false; window.clearInterval(id) }
  }, [settled])

  let statusBadge
  let badgeClass
  if (settled) {
    let resultText = ''
    if (block && Array.isArray(block.content)) {
      for (const c of block.content) {
        if (c && c.type === 'text' && c.text) { resultText = c.text; break }
      }
    }
    if (isError) {
      statusBadge = '已失败'
      badgeClass = 'cancelled'
    } else if (resultText.includes('[已取消]')) {
      statusBadge = '已取消'
      badgeClass = 'cancelled'
    } else {
      statusBadge = '已完成'
      badgeClass = 'done'
    }
  } else if (livePhase === 'marked') {
    statusBadge = '待确认'
    badgeClass = 'review'
  } else if (livePhase === 'slashing') {
    statusBadge = '斩击中…'
    badgeClass = 'delay'
  } else if (livePhase === 'cancelled') {
    statusBadge = '已取消'
    badgeClass = 'cancelled'
  } else {
    statusBadge = '执行中…'
    badgeClass = 'auto'
  }
  let footText = `工具 ${toolName}`
  if (settled && block && Array.isArray(block.content)) {
    for (const c of block.content) {
      if (c && c.type === 'text' && c.text) { footText = c.text.slice(0, 200); break }
    }
  }
  return React.createElement('div', { className: 'ryoshu2-toolcard' },
    React.createElement('div', { className: 'head' },
      React.createElement('img', { src: '/ryoshu3-assets/effects/Target.png', alt: '', draggable: false }),
      React.createElement('span', null, '天殺拔刀斬'),
      React.createElement('span', { className: `badge ${badgeClass}` }, statusBadge),
    ),
    React.createElement('div', null, `模式：${modeLabel} ｜ 永久删除`),
    paths.length > 0
      ? React.createElement('ul', null, paths.map((p) => React.createElement('li', { key: p }, p)))
      : null,
    React.createElement('div', { className: 'foot' }, footText),
  )
}

function Ryoshu2Settings(props) {
  const [s, setS] = React.useState(Object.assign({}, SETTINGS))
  const [saving, setSaving] = React.useState(false)
  const [savedTip, setSavedTip] = React.useState('')

  async function persist(patch) {
    const next = Object.assign({}, SETTINGS, patch)
    SETTINGS = next
    setS(Object.assign({}, next))
    setSaving(true)
    try {
      const resp = await fetch('/ryoshu3-api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(next),
        cache: 'no-store',
      })
      if (resp.ok) {
        const data = await resp.json()
        if (data.config) {
          SETTINGS = Object.assign({}, DEFAULT_SETTINGS, data.config)
          setS(Object.assign({}, SETTINGS))
        }
        setSavedTip('✓ 已保存（持久化）')
      } else {
        setSavedTip('✗ 保存失败')
      }
    } catch (e) {
      setSavedTip('✗ 保存失败')
    }
    setSaving(false)
    window.setTimeout(() => setSavedTip(''), 2500)
  }

  const set = (k, v) => persist({ [k]: v })
  const row = (label, control) =>
    React.createElement('div', { className: 'row' },
      React.createElement('label', null, label),
      control,
    )
  const select = (k, options) =>
    React.createElement('select', { value: s[k], onChange: (e) => set(k, e.target.value) },
      options.map(([v, l]) => React.createElement('option', { key: v, value: v }, l)),
    )
  return React.createElement('div', { className: 'ryoshu2-settings' },
    React.createElement('h3', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
      React.createElement(IconSword, { size: 20, color: '#8fd4ff' }),
      React.createElement('span', null, '天殺拔刀斬')),
    React.createElement('div', { className: 'hint', style: { fontSize: '11.5px', color: '#b8a898', marginBottom: '8px' } },
      '配置即时保存到 DSH 设置，刷新不丢失。'),
    row('文件排列', select('arrangeMode', [['stack', '堆叠(抽卡)'], ['row', '排列一排']])),
    row('斩杀方式', select('cutMode', [['all', '一起砍'], ['onebyone', '逐个砍']])),
    row('每行最多文件数',
      React.createElement('input', {
        type: 'number', min: 1, max: 20, value: s.maxPerRow || 6,
        style: { width: '70px' },
        onChange: (e) => {
          const v = Math.max(1, Math.min(20, parseInt(e.target.value, 10) || 6))
          set('maxPerRow', v)
        },
      })),
    row('音效音量',
      React.createElement('input', {
        type: 'range', min: 0, max: 1, step: 0.1, value: s.volume ?? 1,
        style: { width: '120px' },
        onChange: (e) => set('volume', parseFloat(e.target.value)),
      })),
    row('强制审查（防 bot 乱删）',
      React.createElement('input', {
        type: 'checkbox', checked: s.requireReview !== false,
        onChange: (e) => set('requireReview', e.target.checked),
      })),
    React.createElement('div', { style: { fontSize: '11.5px', color: '#b8a898', marginTop: '2px' } },
      '开启后任何删除请求（含 auto/delay）都必须在界面确认后才执行。'),
    row('接管默认删除方式',
      React.createElement('input', {
        type: 'checkbox', checked: s.replaceDefaultDelete !== false,
        onChange: (e) => set('replaceDefaultDelete', e.target.checked),
      })),
    React.createElement('div', { style: { fontSize: '11.5px', color: '#b8a898', marginTop: '2px' } },
      '开启后 bot 删除文件一律走天杀（审查+特效）；大型项目开发可关闭，恢复默认删除方式提效。'),
    React.createElement('div', { style: { fontSize: '11.5px', color: saving ? '#8fd4ff' : '#a0e0b0', marginTop: '6px' } },
      saving ? '保存中…' : (savedTip || '')),
  )
}

module.exports = {
  name: 'dsh-ryoshu-slash',
  inject: ['slots'],
  apply(ctx) {
    const slots = ctx.slots
    if (slots === undefined) return
    slots.inject('shell.overlay', () =>
      slots.register(
        { name: 'shell.overlay', id: 'ryoshu2-slash', order: 100, label: '天殺拔刀斬 v2 特效层' },
        () => React.createElement(Ryoshu2Stage, { ctx }),
      ),
    )
    slots.inject('tool.call.toolview', () =>
      slots.register(
        { name: 'tool.call.toolview', key: 'ryoshu_slash' },
        (props) => React.createElement(Ryoshu2ToolCard, props),
      ),
    )
    slots.inject('settings.section', () =>
      slots.register(
        { name: 'settings.section', id: 'ryoshu2-settings', order: 30, label: '天殺拔刀斬' },
        (props) => React.createElement(Ryoshu2Settings, props),
      ),
    )
    // 插件管理列表卡片（设置 → 插件）：让别人能看到并了解这个插件
    slots.inject('settings.plugin.item', () =>
      slots.register(
        { name: 'settings.plugin.item', id: 'dsh-ryoshu-slash', order: 30, label: '天殺拔刀斬' },
        () => React.createElement(Ryoshu2PluginCard, null),
      ),
    )
  },
}

function Ryoshu2PluginCard(props) {
  return React.createElement('div', {
    style: {
      border: '1px solid rgba(255, 120, 80, 0.4)',
      borderRadius: '10px',
      padding: '14px 16px',
      margin: '8px 0',
      background: 'linear-gradient(135deg, rgba(30,18,26,0.9), rgba(40,22,30,0.9))',
      color: '#f0e0d0',
    },
  },
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' } },
      React.createElement(IconSword, { size: 22, color: '#ffcf8a' }),
      React.createElement('span', { style: { fontWeight: 800, color: '#ffcf8a', letterSpacing: '1px' } }, '天殺拔刀斬'),
      React.createElement('span', { style: { fontSize: '11px', color: '#8fd4ff', background: 'rgba(60,120,220,0.25)', borderRadius: '4px', padding: '2px 8px' } }, 'dsh-ryoshu-slash'),
    ),
    React.createElement('div', { style: { fontSize: '12.5px', lineHeight: 1.8, color: '#d8c8b8' } },
      '斩击特效文件删除工具：永久删除（不经过回收站），默认强制审查确认（mode=review），exe 显示真实图标，带动画/音效/语音。',
    ),
    React.createElement('div', { style: { marginTop: '10px', fontSize: '12px', color: '#9fc0d8' } },
      '配置入口：设置 → 天殺拔刀斬（排列方式 / 斩杀方式 / 每行文件数 / 音量）。',
    ),
  )
}
