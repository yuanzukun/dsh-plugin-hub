<h1 align="center">天殺拔刀斬 · dsh-ryoshu-slash</h1>

<p align="center">良秀「天殺拔刀斬」：带斩击特效的文件删除工具，替代 bot 原本的删除方式，强制审查确认防误删。</p>

<p align="center">
  <img alt="license" src="https://badgen.net/badge/license/MIT/blue">
  <img alt="dsh" src="https://badgen.net/badge/dsh/bundle-orange">
</p>

## 灵感来源与致谢

「天殺拔刀斬」的创意与特效灵感来自 [RyoshuSlashDeleter](https://github.com/2749478981/RyoshuSlashDeleter)（作者 B 站：[真夜中のloop](https://space.bilibili.com/478832252)，UID 478832252），**已获原作者在 B 站评论区的明确授权**（"当然可以，随便你"）。本项目在原作趣味删除插件的基础上重构为 DSH 插件形态，并加入强制审查等防误删机制；实现代码为独立编写，仅参考其创意与特效思路。

「良秀（Ryoshu）」及招式「天殺拔刀斬」为 Project Moon《边狱巴士》（Limbus Company）中的角色与 E.G.O 设定，版权归 Project Moon 所有。本项目为其同人致敬作品，与 Project Moon 无隶属关系；相关语音/音效素材仅供学习交流使用，请勿用于商业用途。

删除文件不再只是冷冰冰的 `Remove-Item`——天殺拔刀斬 把删除变成一场演出：文件从屏幕下方弹入、聚拢摆好姿势，逐刀斩下带刀光与音效，两截分离、变白、淡出。每个 exe 显示它自己的真实图标，语音与 BGM 烘托氛围。

**核心原则：强制审查，防 bot 乱删**——`requireReview` 默认开启：即使模型请求 `auto`/`delay` 也会被强制转为审查确认，标记后必须用户在界面点「确认出刀」才真删。用户可在设置页关闭此开关。

## 平台支持

| 平台 | 删除 | 图标/缩略图 | 说明 |
|---|---|---|---|
| **Windows** | ✅ PowerShell `Remove-Item` | ✅ 真实缩略图（WPF）+ 系统关联图标（System.Drawing） | 完整特效体验 |
| **macOS / Linux** | ✅ Node 原生 `fs.rm` 永久删除（不经过回收站） | ⚠️ 内置静态图标（host 无系统图标 API，自动降级） | 核心功能完整，审查/动画/音效不受影响 |

非 Windows 平台无需 PowerShell 或任何 .NET 组件，仅依赖 Node.js 内置能力；删除逻辑与 Windows 同样为永久删除（不经回收站）。

## 安装

官方 bundle 插件，git 源一行安装（产物已入库，无需构建）：

```sh
dsh plugin --profile web add github:88514205-oss/dsh-ryoshu-slash#main
```

> `--profile web` 表示安装到 web 配置档；headless 等其他档改成对应 profile 名即可。

### 前提：安装 pnpm

`dsh plugin` 是 DSH 原生命令，本质是 pnpm 转发器（在 profile 目录执行 `pnpm add` 并自动把声明了 `dsh.bundle` 的包加入层栈）。**需要先安装 pnpm 并确保在 PATH 中**：

```sh
npm install -g pnpm
```

> 如果 `dsh plugin` 报 `pnpm not found on PATH`，就是 pnpm 没装好。git 源插件在 pnpm ≥10 下若被阻止构建，按提示在 profile 的 `pnpm-workspace.yaml` 中 allowBuilds 放行即可。

### 装完重启 web

bundle 层栈在 boot 合成，装完必须**重启 web**：

```sh
dsh web
```

重启后：
- 设置 → 插件 → 可配置 tab 出现「天殺拔刀斬」卡片
- 设置侧边栏出现「天殺拔刀斬」配置分组
- 对话中删除文件自动走 `ryoshu_slash`（带斩击特效）

### 其他安装方式

```sh
# 本地开发安装（在插件仓库目录内）
cd dsh-ryoshu-slash && dsh plugin --profile web add .

# 查看已装插件
dsh plugin --profile web list
```

## 能力面

### Tools

| 工具 | 说明 |
|---|---|
| `ryoshu_slash` | 良秀「天殺拔刀斬」：斩击并永久删除文件/文件夹。强制审查开启时（默认）一律 review——界面确认才删，模型无法用 auto 绕过；用户关闭后可 auto/delay。 |

### Browser UI

| 部件 | 说明 |
|---|---|
| 斩击特效层 | 全屏动画：文件弹入→网格聚拢→逐刀斩→刀光→音效→变白→淡出 |
| 审查确认面板 | review 模式下弹出的确认/取消对话框 |
| 工具卡片 | 对话流中 ryoshu_slash 调用的状态卡片 |
| 设置分组 | 文件排列 / 斩杀方式 / 每行文件数 / 音量 / 强制审查开关（全部持久化） |
| 插件管理卡片 | 设置 → 插件列表中的插件介绍卡片 |

## 行为细节

- **永久删除**：Windows 用 `Remove-Item -Force -Recurse`；macOS/Linux 用 Node `fs.rm({ recursive, force })`——均不经过回收站。
- **强制审查**：`requireReview` 默认 true——无视模型传入的 mode，一律标记→界面确认→才删；用户可在设置页关闭。
- **exe 真实图标 / 图片缩略图**（仅 Windows）：运行时经 PowerShell `ExtractAssociatedIcon`（系统图标）与 WPF BitmapDecoder（图片缩略图，最长边 96px）提取，HTTP 路由返回 PNG，按路径缓存；其他平台自动使用内置静态图标。
- **语音/BGM**：标记时播放一句语音（文件名含 拇指/食指/中指/环指 触发对应语音），BGM 淡入，斩完淡出。
- **多文件布局**：网格矩阵排列，多行自动缩小图标防重叠（每行文件数可配置）。

## 配置

设置 → 天殺拔刀斬（持久化到 DSH settings，刷新/重启不丢）：

| 配置项 | 默认 | 说明 |
|---|---|---|
| 文件排列 | 堆叠(抽卡) | 网格堆叠 / 排列一排 |
| 斩杀方式 | 逐个砍 | 一起砍 / 逐个砍 |
| 每行最多文件数 | 6 | 多文件分行的列数上限 |
| 音效音量 | 1 | 语音/音效/BGM 音量 |
| 强制审查（防 bot 乱删） | 开 | 关闭后 auto/delay 才生效 |
| 接管默认删除方式 | 开 | 开启后 bot 删除文件一律走天杀；大型项目开发可关闭，恢复默认删除方式提效 |

## 插件管理

已装插件用 plugin-registry 的**薄控制台**管理（浏览器面板）：管理 profile 插件安装态（bundle 层栈 + insert 行 + 启停），无需手改配置。安装：

```sh
dsh plugin --profile web add github:vlln/plugin-registry#main&path:/packages/plugin/console
```

## 开发

```sh
node scripts/build-client.mjs            # 构建 client bundle（__ModuleLoader__.load 包装）
node scripts/build-client.mjs --check    # 门禁：client.js 新鲜度
node scripts/gates/run.mjs               # 完整门禁（10+ 项）
```

- `index.mjs` — Node half：工具注册、webServer 资源/API 路由、settings 注册、systemPrompt 引导
- `client/src.js` — Client half 源码（React + canvas 动画，HTTP fetch 通信）
- `client/client.js` — 构建产物（勿手改，由 build-client.mjs 生成）
- `assets/` — 图标 / 音效 / 语音 / BGM
- `scripts/` — 构建 / 门禁 / 同步脚本

改 Node half 需重启 web（ESM 缓存）；改 client 源码重建 + 刷新页面即可。
