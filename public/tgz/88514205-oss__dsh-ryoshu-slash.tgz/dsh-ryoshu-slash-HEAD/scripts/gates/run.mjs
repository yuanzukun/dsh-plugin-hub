// ════════════════════════════════════════════════════════════════════
// gates/run.mjs · 门禁：机械检查 + 自证测试
// 用法：node scripts/gates/run.mjs [--failing]  （--failing 演示拒绝路径）
// ════════════════════════════════════════════════════════════════════
import { readFileSync, existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = fileURLToPath(new URL('../..', import.meta.url))

let failures = 0
const fail = (msg) => {
  failures += 1
  console.error(`✗ ${msg}`)
}
const ok = (msg) => console.log(`✓ ${msg}`)

// ── 机械检查 ────────────────────────────────────────────────────────
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))

// 1. dsh.bundle 声明 → cordis.patch.yml 存在且含 insert 自身
if (pkg.dsh?.bundle?.patch !== './cordis.patch.yml') {
  fail('package.json#dsh.bundle.patch 应为 ./cordis.patch.yml')
} else {
  ok('dsh.bundle.patch → cordis.patch.yml')
}
const patch = readFileSync(join(root, 'cordis.patch.yml'), 'utf8')
if (!patch.includes(`id: ${pkg.name}`) || !patch.includes(`name: '${pkg.name}'`)) {
  fail(`cordis.patch.yml 必须 insert 自身（id/name: ${pkg.name}）`)
} else {
  ok('cordis.patch.yml insert 自身')
}

// 2. dsh.client 声明 + exports["./client"]
if (pkg.dsh?.client?.platform !== 'web') {
  fail('package.json#dsh.client.platform 应为 web')
} else {
  ok('dsh.client.platform = web')
}
if (pkg.exports?.['./client'] !== './client/client.js') {
  fail('exports["./client"] 应为 ./client/client.js')
} else {
  ok('exports["./client"] → ./client/client.js')
}

// 3. main/exports["."] → index.mjs
if (pkg.main !== './index.mjs' || pkg.exports?.['.'] !== './index.mjs') {
  fail('main/exports["."] 应为 ./index.mjs')
} else {
  ok('main/exports["."] → index.mjs')
}

// 4. client bundle 新鲜度（与 build-client.mjs --check 一致）
import { execFileSync } from 'node:child_process'
try {
  execFileSync(process.execPath, [join(root, 'scripts', 'build-client.mjs'), '--check'], { stdio: 'pipe' })
  ok('client.js 新鲜（--check 通过）')
} catch (e) {
  fail('client.js 过期——请运行 npm run build:client')
}

// 5. 资源完整
const needAssets = [
  'assets/icons/txt.png', 'assets/icons/exe.png',
  'assets/music/araya.mp3',
  'assets/sfx/gakryoshu_1_1.wav',
  'assets/voice/01.wav',
  'assets/effects/Target.png',
]
for (const a of needAssets) {
  if (!existsSync(join(root, a))) fail(`缺少资源 ${a}`)
}
if (needAssets.every((a) => existsSync(join(root, a)))) ok(`资源完整（${needAssets.length} 项抽查）`)

// 6. 强制审查：requireReview 开启时无视 bot 传入的 mode 一律 review
const host = readFileSync(join(root, 'index.mjs'), 'utf8')
if (!host.includes("const mode = requireReview ? 'review' : requestedMode")) {
  fail('ryoshu_slash 必须强制审查：requireReview 开启时一律 review（bot 无法用 auto 绕过）')
} else {
  ok('ryoshu_slash 强制审查（requireReview=true 时无视 mode）')
}
if (!host.includes('requireReview: z.boolean().default(true)')) {
  fail('settings schema 必须包含 requireReview 布尔开关（默认 true）')
} else {
  ok('settings schema 含 requireReview 开关（默认 true）')
}

// 7. 删除走 Remove-Item 永久删除（不经过回收站）
if (!host.includes('Remove-Item -LiteralPath')) {
  fail('删除必须使用 Remove-Item 永久删除')
} else {
  ok('删除 = Remove-Item 永久删除（无回收站）')
}

// 7b. 跨平台：非 Windows 走 Node fs.rm 永久删除，Windows 分支保留
if (!host.includes("import { rm } from 'node:fs/promises'") || !host.includes('await rm(String(p), { recursive: true, force: true })')) {
  fail('非 Windows 平台必须使用 fs.rm 永久删除（recursive+force）')
} else {
  ok('跨平台删除：非 Windows = fs.rm 永久删除')
}
if (!host.includes("const IS_WIN = process.platform === 'win32'") || !host.includes('if (!IS_WIN) return null')) {
  fail('必须按平台分流：IS_WIN 常量 + 非 Windows 图标/缩略图早退')
} else {
  ok('平台分流：IS_WIN 判断 + 非 Windows 图标降级')
}

// 8. 自证：无 dsh.bundle 声明的包应被拒绝（生成器契约）
const badPkg = JSON.stringify({ name: 'x', version: '0.0.0', dsh: {} })
if (badPkg.includes('"bundle"')) {
  fail('自证样例错误：badPkg 不应含 bundle')
} else {
  ok('自证：无 bundle 声明的包走纯 cordis 通道（insert 行）')
}

// ── 汇总 ────────────────────────────────────────────────────────────
if (failures > 0) {
  console.error(`\n门禁失败：${failures} 项`)
  process.exit(1)
}
console.log('\n门禁通过 ✓')
