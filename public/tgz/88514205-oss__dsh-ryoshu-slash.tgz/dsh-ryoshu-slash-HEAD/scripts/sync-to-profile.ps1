# ════════════════════════════════════════════════════════════════════
# sync-to-profile.ps1 · 构建 client + 同步到 profile 闭包
# 用法：powershell -File scripts/sync-to-profile.ps1
# ════════════════════════════════════════════════════════════════════
$ErrorActionPreference = 'Stop'

$src = 'D:\测试\dsh-ryoshu-slash-plugin'
$closures = @(
  'C:\Users\akimi\.dsh\profiles\node_modules\dsh-ryoshu-slash',
  'C:\Users\akimi\.dsh\profiles\web\node_modules\dsh-ryoshu-slash'
)

# 1. 构建 client bundle
Write-Host '[1/3] 构建 client bundle...'
Push-Location $src
node scripts/build-client.mjs
if ($LASTEXITCODE -ne 0) { Pop-Location; exit 1 }
Pop-Location

# 2. 门禁
Write-Host '[2/3] 跑门禁...'
Push-Location $src
node scripts/gates/run.mjs
if ($LASTEXITCODE -ne 0) { Pop-Location; exit 1 }
Pop-Location

# 3. 同步到所有闭包副本
Write-Host '[3/3] 同步到 profile 闭包...'
foreach ($c in $closures) {
  if (Test-Path $c) {
    # 保留 node_modules 等不复制（源无）
    Copy-Item "$src\*" $c -Recurse -Force
    Write-Host "  ✓ $c"
  } else {
    Copy-Item $src $c -Recurse -Force
    Write-Host "  ✓ (新建) $c"
  }
}

Write-Host ''
Write-Host '完成。改 Node half 后需重启 web（ESM 缓存）；改 client 刷新页面即可。'
