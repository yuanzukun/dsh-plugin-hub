# Security Policy

## Reporting a Vulnerability / 报告漏洞

Please **do not** open a public issue for security vulnerabilities. / 安全漏洞请勿公开提 issue。

- 私信 / Private message: [534119219](https://github.com/534119219)
- 邮箱 / Email: 通过 GitHub 主页联系信息

We will respond within 7 days and coordinate a fix before any public disclosure. /
我们会在 7 天内回复，并在公开披露前协调修复。

## Security notes / 安全说明

- 渠道配置（含 SendKey / Token / 授权码等密钥）明文存储在
  `$DSH_HOME/push/channels.json`，请确保该目录仅当前用户可读写。
- `/push/api/*` 接口有 fence 保护（仅同源 / loopback / 受信 host），
  请勿将该端口暴露到不可信网络。
- 邮件渠道的授权码只在调用时用于 SMTP 认证，不写入日志。
