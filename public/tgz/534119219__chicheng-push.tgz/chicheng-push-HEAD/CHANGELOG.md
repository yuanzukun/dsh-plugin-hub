# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-08-16

### Added

- 设置界面左侧栏「推送插件」入口（settings.section `chicheng-push`），支持添加、
  编辑、删除、启用/停用、测试多个推送渠道。
- 14 种推送渠道，实现参考 qinglong notify：
  Server酱 / PushPlus / Bark / 钉钉机器人 / 企业微信群机器人 / 企业微信应用 /
  Telegram / 飞书(Lark) / ntfy / iGot / PushDeer / Gotify / 自定义 Webhook / 邮件(SMTP)。
- host 侧 `pushNotifier` cordis 服务：其他插件通过
  `ctx.get("pushNotifier").send({ title, content, channels })` 调用。
- fenced HTTP API `/push/api/*`（list/types/save/remove/toggle/test/send），
  仅同源 / loopback / 受信 host 可访问。
- 渠道配置持久化于 `$DSH_HOME/push/channels.json`（原子写入：tmp + rename）。
- 集成测试 `smoke.mjs`（19 项断言，含真实 HTTP 发送链路）。
- 设置面板导航图标补丁（聊天气泡，与主侧栏「消息平台」一致）：
  修改官方 shell `dsh-client-ui-settings-general` 的 `navIcon()`，详见
  [docs/panel-icon-patch.md](docs/panel-icon-patch.md)。
