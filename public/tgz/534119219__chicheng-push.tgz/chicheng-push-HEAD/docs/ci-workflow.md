# CI workflow（参考）

本插件带一套 GitHub Actions CI：语法检查 + smoke 测试 + 渠道类型 schema 一致性测试。

> ⚠️ 本仓库未启用该 workflow——`chicheng-push-0.1.0.tgz` 发布时用的 PAT 没有
> `workflow` scope，GitHub 拒绝通过 API 创建/更新 `.github/workflows/` 文件。
> 配置已保留在 `docs/ci-workflow.yml`，需要时手动复制到
> `.github/workflows/ci.yml` 即可（在 GitHub 网页上添加文件不受 token scope 限制）。

## 启用步骤

1. 将 `docs/ci-workflow.yml` 的内容复制为 `.github/workflows/ci.yml`；
2. 提交并推送（或在 GitHub 网页直接创建该文件）；
3. Actions 会自动运行：语法检查、`test/smoke.mjs`（真实 HTTP 发送链路）、
   `test/types.test.mjs`（渠道类型 schema 一致性）。

## 本地等效命令

```sh
node --check lib/index.js
node --check lib/client.js
node test/smoke.mjs
node test/types.test.mjs
```
