# 设置面板图标补丁（官方 shell）

设置面板（齿轮弹窗）左侧栏的导航图标由官方 shell 包
`@deepseek-ai/dsh-client-ui-settings-general` 的 `navIcon(id)` 硬编码映射：
只有 `models` / `agent-presets` / `plugins` 三个官方 id 有专属图标，其余 section
一律回退为设置齿轮。settings.section slot 注册契约不支持自定义图标，因此要让
「推送插件」条目显示与主侧栏「消息平台」一致的聊天气泡图标，需要给 shell 打补丁。

## 补丁内容

在 `navIcon(id)` 的 `plugins` 分支之后插入：

```js
// chicheng-push: same filled chat-bubble glyph as the messaging-platform
// sidebar entry (messaging-core builds this path with createElementNS).
if (id === "chicheng-push") return (0, react_jsx_runtime.jsx)("svg", {
  className: SettingsRoot_module_css_default.navIcon,
  width: 16,
  height: 16,
  viewBox: "0 0 16 16",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  "aria-hidden": true,
  children: (0, react_jsx_runtime.jsx)("path", {
    d: "M3.25 1.75H12.75A2.25 2.25 0 0 1 15 4V9.5A2.25 2.25 0 0 1 12.75 11.75H8.4L5.9 14.4V11.75H3.25A2.25 2.25 0 0 1 1 9.5V4A2.25 2.25 0 0 1 3.25 1.75Z",
    fill: "currentColor"
  })
});
```

目标文件（dsh 安装目录下）：

```
node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-client-ui-settings-general/lib/client.js
```

改动前先备份（本机已留 `.chicheng-push.bak`）。修改后**刷新页面即可生效**
（bundle 由 `/plugins/<id>/client.js?rev=<hash>` 提供，rev 变化自动重取），无需重启。

## 升级后重新打补丁

升级 / 重装 `@deepseek-ai/dsh` 会覆盖该文件、图标退回齿轮。恢复步骤：

1. 定位上述目标文件；
2. 用备份 `.chicheng-push.bak` 对照，或直接按上面的片段在 `navIcon()` 的
   `plugins` 分支后插入；
3. `node --check` 校验语法后刷新页面。
