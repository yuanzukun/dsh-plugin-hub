# 定时执行插件集成示例

以 [dsh-cron-scheduler](../../../dsh-cron-scheduler) 为例：任务 run 落定后，
通过 `pushNotifier` 服务把执行结果推送到已配置渠道。

## 在任务完成后推送结果

在 `executeRun` 的 `finalize` 之后追加：

```js
// executeRun 的 finalize 之后
const push = ctx.get("pushNotifier");
if (push) {
  await push.send({
    title: `定时任务「${task.name}」完成`,
    content: [
      `状态：${record.status}（exit ${record.exitCode ?? "-"}）`,
      `耗时：${record.durationMs ?? "-"} ms`,
      `开始：${record.startedAt}`,
    ].join("\n"),
  }).catch((error) => console.warn("[cron] push failed:", error));
}
```

## 参数说明

| 参数 | 类型 | 说明 |
|---|---|---|
| `title` | string | 推送标题 |
| `content` | string | 推送正文（纯文本，各渠道自行排版） |
| `channels` | `"all"` \| string[] \| 省略 | 目标渠道：省略或 `"all"` = 全部启用渠道；数组 = 按渠道 id 或名称匹配 |

返回 `{ ok, total, sent, results }`，`results` 为每个渠道的
`{ id, name, type, ok, message | error }`。

## 按任务区分渠道

如果希望不同任务走不同渠道，可在任务上增加可选字段并在执行时传入：

```js
await push.send({
  title: `任务「${task.name}」完成`,
  content: "…",
  channels: task.pushChannels ?? "all",   // 任务级覆盖，默认全部启用渠道
});
```

## 其他调用方式

- **HTTP**：`POST /push/api/send`（`{ title, content, channels? }`），
  适合脚本 / agent / 非 host 进程，详见 README「方式二」。
- **服务 API**：`push.list()` / `push.types()` / `push.send()` /
  `push.sendText()` / `push.test(id)`。
