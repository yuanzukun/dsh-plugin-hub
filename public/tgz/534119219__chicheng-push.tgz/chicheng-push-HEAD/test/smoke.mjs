/**
 * chicheng-push smoke test (no dsh host): drives apply() with a fake ctx,
 * exercises the /push/api routes through real request/response objects, and
 * verifies webhook + serverChan-style sending against a local HTTP server.
 */
import { createServer } from "node:http";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Readable } from "node:stream";

// Set DSH_HOME BEFORE importing the plugin (its module top-level computes
// DATA_ROOT from process.env.DSH_HOME).
process.env.DSH_HOME = mkdtempSync(join(tmpdir(), "dsh-push-smoke-"));
const { apply } = await import(new URL("../lib/index.js", import.meta.url).href);

// ---------------------------------------------------------------- fake ctx

const registered = [];
const log = [];
const fakeCtx = {
  webServer: {
    register(entry) {
      registered.push(entry);
      return () => {};
    },
  },
  webRuntime: { trustedHosts: [] },
  logger: { info: (...args) => log.push(["info", ...args]) },
  effect(cb) {
    return cb();
  },
  provide(name, value) {
    fakeCtx._provided = fakeCtx._provided || {};
    fakeCtx._provided[name] = value;
    return () => {};
  },
};

// ---------------------------------------------------------------- helpers

let pendingHttpBodies = [];
const httpServer = createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    pendingHttpBodies.push({ url: req.url, headers: req.headers, body });
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ code: 0, ok: true }));
  });
});

function request(entry, method, path, payload, headers = {}) {
  const req = new Readable({ read() {} });
  req.method = method;
  req.url = path;
  req.headers = { host: "127.0.0.1:3080", ...headers };
  if (payload !== undefined) req.push(JSON.stringify(payload));
  req.push(null);
  const res = {
    _status: 0,
    _body: "",
    writeHead(status, h) { this._status = status; this._headers = h; },
    end(body) { this._body = body; },
  };
  return entry.handler(req, res).then(() => ({
    status: res._status,
    body: JSON.parse(res._body || "{}"),
  }));
}

// ---------------------------------------------------------------- run

let failures = 0;
const check = (label, cond, extra = "") => {
  console.log(`${cond ? "PASS" : "FAIL"} ${label}${extra ? " — " + extra : ""}`);
  if (!cond) failures += 1;
};

await new Promise((r) => httpServer.listen(0, "127.0.0.1", r));
const port = httpServer.address().port;

await apply(fakeCtx, {});

const pushEntry = registered.find((e) => e.path === "/push/api");
check("route registered at /push/api", !!pushEntry, pushEntry ? pushEntry.kind : "none");
check("pushNotifier service provided", !!fakeCtx._provided?.pushNotifier);

// fence: cross-site origin must be refused
const crossSite = await request(pushEntry, "POST", "/push/api/list", {}, { origin: "https://evil.example", "sec-fetch-site": "cross-site" });
check("cross-site request refused", crossSite.status === 403, `status=${crossSite.status}`);

// types
const types = await request(pushEntry, "POST", "/push/api/types", {});
check("types API returns >0 types", Array.isArray(types.body.value?.types) && types.body.value.types.length > 10);

// save webhook channel (points at our local server)
await request(pushEntry, "POST", "/push/api/save", {
  channel: {
    name: "本地测试 Webhook",
    type: "webhook",
    enabled: true,
    config: {
      webhookUrl: `http://127.0.0.1:${port}/hook$title`,
      webhookMethod: "POST",
      webhookContentType: "application/json",
      webhookBody: '{"title":"$title","content":"$content"}',
    },
  },
});

// save serverChan channel (missing required key -> must 400)
const bad = await request(pushEntry, "POST", "/push/api/save", {
  channel: { name: "坏渠道", type: "serverChan", config: {} },
});
check("required field enforced", bad.status === 400, `status=${bad.status}`);

const list1 = await request(pushEntry, "POST", "/push/api/list", {});
const channel = list1.body.value.channels[0];
check("channel persisted", list1.body.value.channels.length === 1, JSON.stringify(list1.body.value.channels.map((c) => c.name)));

// toggle off then on
await request(pushEntry, "POST", "/push/api/toggle", { id: channel.id, enabled: false });
const list2 = await request(pushEntry, "POST", "/push/api/list", {});
check("toggle disables channel", list2.body.value.channels[0].enabled === false);

// send with channels:"all" -> disabled channel skipped, webhook hits local server
const sendRes = await request(pushEntry, "POST", "/push/api/send", {
  title: "Smoke 标题",
  content: "Smoke 内容行1\n行2",
  channels: "all",
});
check("send ok when no enabled channel", sendRes.body.value.ok === false && sendRes.body.value.total === 0, JSON.stringify(sendRes.body.value));

await request(pushEntry, "POST", "/push/api/toggle", { id: channel.id, enabled: true });
const sendRes2 = await request(pushEntry, "POST", "/push/api/send", { title: "Smoke2", content: "内容", channels: "all" });
check("send hits enabled webhook", sendRes2.body.value.ok === true && sendRes2.body.value.sent === 1, JSON.stringify(sendRes2.body.value));
check("webhook received one POST", pendingHttpBodies.length === 1, `got=${pendingHttpBodies.length}`);
if (pendingHttpBodies[0]) {
  const hit = pendingHttpBodies[0];
  check("webhook URL variable substituted", hit.url === `/hookSmoke2`, hit.url);
  const parsed = JSON.parse(hit.body);
  check("webhook body variables substituted", parsed.title === "Smoke2" && parsed.content === "内容", hit.body);
  check("webhook content-type json", hit.headers["content-type"] === "application/json", hit.headers["content-type"]);
}

// simple text send via service
const svcSend = await fakeCtx._provided.pushNotifier.sendText("服务标题", "服务内容", "all");
check("pushNotifier.sendText works", svcSend.sent === 1 && svcSend.ok, JSON.stringify(svcSend.results));
check("second webhook POST captured", pendingHttpBodies.length === 2, `got=${pendingHttpBodies.length}`);

// remove
const rm = await request(pushEntry, "POST", "/push/api/remove", { id: channel.id });
check("remove ok", rm.body.value.deleted === true);
const list3 = await request(pushEntry, "POST", "/push/api/list", {});
check("channel gone after remove", list3.body.value.channels.length === 0);

// persisted store file exists (await the 150ms debounced flush)
await new Promise((r) => setTimeout(r, 400));
const storeRaw = readFileSync(join(process.env.DSH_HOME, "push", "channels.json"), "utf8");
check("store file persisted", storeRaw.includes('"channels"'));

httpServer.closeAllConnections?.();
httpServer.close();
console.log(failures === 0 ? "\nALL PASS" : `\n${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);