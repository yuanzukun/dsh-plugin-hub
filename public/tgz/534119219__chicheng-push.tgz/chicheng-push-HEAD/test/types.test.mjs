/**
 * chicheng-push registry consistency test (no dsh host, no network):
 * drives apply() with a fake ctx and verifies that every channel type's
 * schema (fields returned by /push/api/types) is well-formed and that the
 * store-level validation rejects incomplete payloads.
 */
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Readable } from "node:stream";

process.env.DSH_HOME = mkdtempSync(join(tmpdir(), "dsh-push-types-"));
const { apply } = await import(new URL("../lib/index.js", import.meta.url).href);

const registered = [];
const fakeCtx = {
  webServer: {
    register(entry) {
      registered.push(entry);
      return () => {};
    },
  },
  webRuntime: { trustedHosts: [] },
  logger: { info: () => {} },
  effect(cb) {
    return cb();
  },
  provide(name, value) {
    fakeCtx._provided = fakeCtx._provided || {};
    fakeCtx._provided[name] = value;
    return () => {};
  },
};

function request(entry, method, path, payload) {
  const req = new Readable({ read() {} });
  req.method = method;
  req.url = path;
  req.headers = { host: "127.0.0.1:3080" };
  if (payload !== undefined) req.push(JSON.stringify(payload));
  req.push(null);
  const res = {
    _status: 0,
    _body: "",
    writeHead(status) { this._status = status; },
    end(body) { this._body = body; },
  };
  return entry.handler(req, res).then(() => ({
    status: res._status,
    body: JSON.parse(res._body || "{}"),
  }));
}

let failures = 0;
const check = (label, cond, extra = "") => {
  console.log(`${cond ? "PASS" : "FAIL"} ${label}${extra ? " — " + extra : ""}`);
  if (!cond) failures += 1;
};

await apply(fakeCtx, {});
const pushEntry = registered.find((e) => e.path === "/push/api");
const typesRes = await request(pushEntry, "POST", "/push/api/types", {});
const types = typesRes.body.value?.types ?? [];

check("types API returns a non-empty list", types.length > 10, `count=${types.length}`);

const fieldKeys = new Set(["key", "label", "type"]);
const validFieldTypes = new Set(["text", "password", "textarea", "number", "select"]);
for (const t of types) {
  const idOk = typeof t.id === "string" && t.id !== "";
  check(`type ${t.id}: id`, idOk);
  check(`type ${t.id}: label`, typeof t.label === "string" && t.label !== "");
  check(`type ${t.id}: fields array`, Array.isArray(t.fields) && t.fields.length > 0);
  for (const f of t.fields ?? []) {
    check(`type ${t.id} field ${f.key}: keys`, Object.keys(f).every((k) => fieldKeys.has(k) || k === "options" || k === "placeholder" || k === "help" || k === "required" || k === "default"));
    check(`type ${t.id} field ${f.key}: type valid`, validFieldTypes.has(f.type), f.type);
    if (f.type === "select") {
      check(`type ${t.id} field ${f.key}: select options`, Array.isArray(f.options) && f.options.length > 0);
    }
  }
}

// save without a required field must be rejected
const bad = await request(pushEntry, "POST", "/push/api/save", {
  channel: { name: "缺字段", type: "serverChan", config: {} },
});
check("required field enforced (serverChan key)", bad.status === 400, `status=${bad.status}`);

const bad2 = await request(pushEntry, "POST", "/push/api/save", {
  channel: { name: "缺字段", type: "telegramBot", config: { telegramBotToken: "t" } },
});
check("required field enforced (telegram chat id)", bad2.status === 400, `status=${bad2.status}`);

console.log(failures === 0 ? "\nALL PASS" : `\n${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
