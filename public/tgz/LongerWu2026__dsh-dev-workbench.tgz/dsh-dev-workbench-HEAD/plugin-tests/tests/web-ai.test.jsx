import React from 'react'
import {JSDOM} from 'jsdom'
import {afterEach,describe,expect,it,vi} from 'vitest'
import {act,cleanup,fireEvent,render,screen,waitFor} from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import {webAIPageScript} from '../../src/shared/web-ai-page.ts'
import {loadClientBundle} from './load-plugin.mjs'
import {NativeWebsite} from '../../src/client/features/web-ai/NativeWebsite.tsx'
import {acquireWebsiteSession,browserSessionMode,browserSessionMessage,WEB_AI_BROWSER_NAMESPACE} from '../../src/client/features/web-ai/browser-session.ts'
afterEach(()=>{cleanup();vi.unstubAllGlobals()})

describe('智谱内嵌提交的焦点边界',()=>{
 it('隐藏且inert时不执行提交；可见后只在准备/发送阶段聚焦，并可释放焦点',async()=>{
  const release=vi.fn(async()=>{}),execute=vi.fn(async()=>({status:'prepared'}));vi.stubGlobal('dshDesktop',{protocolVersion:1,browser:{acquire:async()=>({lease:'glm-focus-test',partition:'glm-synthetic'}),release,onOpenRequested:()=>()=>{}}})
  let controller,current='about:blank#glm-focus-test';const original={};for(const key of ['loadURL','getURL','executeJavaScript'])original[key]=Object.getOwnPropertyDescriptor(HTMLElement.prototype,key)
  HTMLElement.prototype.loadURL=async function(url){current=url;queueMicrotask(()=>this.dispatchEvent(new Event('dom-ready')))};HTMLElement.prototype.getURL=()=>current;HTMLElement.prototype.executeJavaScript=execute
  const props={providerId:'glm',scope:'synthetic',url:'https://chatglm.cn/',onController:value=>{controller=value}}
  const view=render(<NativeWebsite {...props} visible={false}/> )
  try{
   await waitFor(()=>expect(view.container.querySelector('webview')).toBeTruthy());const guest=view.container.querySelector('webview');await act(async()=>guest.dispatchEvent(new Event('dom-ready')));await waitFor(()=>expect(controller?.execute).toBeTypeOf('function'))
   await expect(controller.execute('prepare','测试','id')).rejects.toThrow('可操作状态');expect(execute.mock.calls.filter(([script])=>!script.includes('observeWebAIAuthentication'))).toHaveLength(0)
   view.rerender(<NativeWebsite {...props} visible/>);guest.focus=vi.fn();guest.blur=vi.fn()
   await controller.execute('observe');expect(guest.focus).not.toHaveBeenCalled();await controller.execute('prepare','测试','id');await controller.execute('submit','测试','id');expect(guest.focus).toHaveBeenCalledTimes(2);controller.releaseInputFocus();expect(guest.blur).toHaveBeenCalledTimes(1)
  }finally{view.unmount();for(const key of Object.keys(original)){if(original[key])Object.defineProperty(HTMLElement.prototype,key,original[key]);else delete HTMLElement.prototype[key]}}
 },6000)
})
function website(html,url='https://www.kimi.com/',provider='kimi'){
 const dom=new JSDOM(html,{url,runScripts:'outside-only'});dom.window.HTMLElement.prototype.getClientRects=()=>[{}]
 return {dom,run:(action,question='',id='fixture-request')=>dom.window.eval(webAIPageScript(provider,action,question,id))}
}
describe('网页 AI 固定页面操作',()=>{
 it('只操作指定官网；不会在第三方登录页填写',()=>{const {dom,run}=website('<textarea></textarea>','https://example.org/');expect(run('prepare','测试').status).toBe('unsupported');expect(dom.window.document.querySelector('textarea').value).toBe('');dom.window.close()})
 it('保留已有人工草稿，输入框或发送按钮不唯一时停止自动操作',()=>{const {dom,run}=website('<textarea>人工草稿</textarea><button>发送</button>');expect(run('prepare','模型问题').status).toBe('unsupported');expect(dom.window.document.querySelector('textarea').value).toBe('人工草稿');dom.window.close();const a=website('<textarea></textarea><textarea></textarea>');expect(a.run('prepare','测试').status).toBe('unsupported');a.dom.window.close()})
 it('先填入，使用唯一官网发送按钮，重复提交不会再次点击',()=>{const {dom,run}=website('<textarea></textarea><button aria-label="Send">发送</button>');let count=0;dom.window.document.querySelector('button').onclick=()=>count++;expect(run('prepare','测试问题').status).toBe('prepared');expect(count).toBe(0);expect(run('submit','测试问题').status).toBe('generating');expect(count).toBe(1);expect(run('submit','测试问题').status).toBe('uncertain');expect(count).toBe(1);dom.window.close()})
 it('发送按钮不明确时保留已填写内容；不猜测坐标或按回车',()=>{const {dom,run}=website('<textarea></textarea><button>未知图标</button>');run('prepare','测试问题');expect(run('submit','测试问题').status).toBe('prepared');expect(dom.window.document.querySelector('textarea').value).toBe('测试问题');dom.window.close()})
 it('只读取回答容器，登录、侧栏和其他页面文本不作为模型回答',()=>{const {dom,run}=website('<nav><div data-message-author-role="assistant">导航</div></nav><textarea></textarea><div data-message-author-role="assistant"><div class="markdown">真正回答</div></div><div>其他网页内容</div>');expect(run('observe').answers).toEqual(['真正回答']);dom.window.close()})
 it('登录弹窗出现时停止自动发送',()=>{const {dom,run}=website('<div role="dialog">请登录<input type="tel"></div><textarea></textarea><button>发送</button>');expect(run('prepare','测试问题').status).toBe('needs_login');expect(dom.window.document.querySelector('textarea').value).toBe('');dom.window.close()})
 it('活动通知中的登录字样不误报认证失败，也不穿透弹窗填写',()=>{const {dom,run}=website('<div role="dialog">登录即可领取活动积分<button>我知道了</button></div><textarea></textarea>');expect(run('prepare','测试').status).toBe('unsupported');expect(run('observe').note).toContain('弹窗');expect(dom.window.document.querySelector('textarea').value).toBe('');dom.window.close()})
 it('不把透明隐藏的输入框、按钮和登录弹窗当作可操作内容',()=>{const {dom,run}=website('<div style="opacity:0"><textarea></textarea><button>发送</button><div role="dialog">登录<input type="tel"></div></div><textarea></textarea><button>发送</button>');expect(run('observe').status).toBe('ready');expect(run('prepare','可见问题').status).toBe('prepared');expect(dom.window.document.querySelectorAll('textarea')[0].value).toBe('');expect(run('submit','可见问题').status).toBe('generating');dom.window.close()})
 it('富文本占位提示不误判为人工草稿，真实草稿仍然保护',()=>{const {dom,run}=website('<div contenteditable="true" data-slate-editor="true"><span data-slate-placeholder="true">向千问提问</span><span>\ufeff</span></div>','https://www.qianwen.com/','qianwen');dom.window.document.execCommand=(_a,_b,value)=>{dom.window.document.querySelector('[contenteditable]').textContent=value;return true};expect(run('observe').hasDraft).toBe(false);expect(run('prepare','新的问题').status).toBe('prepared');expect(run('prepare','不同问题').status).toBe('unsupported');dom.window.close()})
 it('富文本编辑器只产生一次输入事件，相同问题重填保持幂等',()=>{const {dom,run}=website('<div contenteditable="true"></div>');const editor=dom.window.document.querySelector('div');let inputs=0;editor.addEventListener('input',()=>inputs++);dom.window.document.execCommand=(_name,_ui,value)=>{editor.textContent=value;editor.dispatchEvent(new dom.window.InputEvent('input',{bubbles:true,data:value}));return true};expect(run('prepare','富文本问题').status).toBe('prepared');expect(inputs).toBe(1);expect(editor.textContent).toBe('富文本问题');expect(run('prepare','富文本问题').status).toBe('prepared');expect(inputs).toBe(1);dom.window.close()})
})
describe('六家适配器隔离DOM回归',()=>{
 it('实机Kimi发送容器与ChatGPT新版Send标签可发送，仍只点击一次',()=>{
  for(const [provider,url,html,selector] of [
   ['kimi','https://kimi.com/','<div class="chat-editor"><div class="chat-input-editor" contenteditable="true" role="textbox"></div><div class="send-button-container"><svg class="send-icon"></svg></div></div>','.send-button-container'],
   ['chatgpt','https://chatgpt.com/','<div><section><div class="ProseMirror" contenteditable="true" role="textbox" aria-label="Ask ChatGPT"></div></section><footer><button aria-label="Send"><svg></svg></button></footer></div>','button'],
  ]){const {dom,run}=website(html,url,provider);dom.window.document.execCommand=(_a,_b,value)=>{dom.window.document.querySelector('[contenteditable]').textContent=value;return true};let count=0;dom.window.document.querySelector(selector).onclick=()=>count++;expect(run('prepare','合成测试').status).toBe('prepared');expect(run('submit','合成测试').status).toBe('generating');expect(run('submit','合成测试').status).toBe('uncertain');expect(count).toBe(1);dom.window.close()}
 })
 it('千问disabled样式变体不是禁用状态；真实disabled、aria-disabled和禁用class仍拦截',()=>{
  for(const attrs of ['', 'disabled', 'aria-disabled="true"', 'class="is-disabled"']){
   const styles=attrs.includes('class=')?'': 'class="text-primary disabled:cursor-not-allowed disabled:text-disabled disabled:hover:bg-transparent"'
   const {dom,run}=website('<textarea></textarea><button aria-label="发送消息" '+styles+' '+attrs+'></button>','https://www.qianwen.com/','qianwen');let count=0;dom.window.document.querySelector('button').onclick=()=>count++;run('prepare','千问合成问题');expect(run('submit','千问合成问题').status).toBe(attrs?'prepared':'generating');expect(count).toBe(attrs?0:1);dom.window.close()
  }
 })
 it('同一页有两个明确发送控件时停止，不选择第一个也不发送',()=>{const {dom,run}=website('<textarea></textarea><div class="chat-editor"><div class="send-button-container"></div></div><button class="send-button"></button>');let count=0;dom.window.document.querySelectorAll('.send-button-container,button').forEach(el=>el.onclick=()=>count++);run('prepare','不应发送');expect(run('submit','不应发送').status).toBe('prepared');expect(count).toBe(0);dom.window.close()})
 it('千问title发送属性可用，Kimi提问只读取正文而不混入编辑/重试操作',()=>{
  const q=website('<textarea></textarea><button title="发送消息" class="disabled:text-disabled"></button>','https://www.qianwen.com/','qianwen');let count=0;q.dom.window.document.querySelector('button').onclick=()=>count++;q.run('prepare','合成测试');expect(q.run('submit','合成测试').status).toBe('generating');expect(count).toBe(1);q.dom.window.close()
  const k=website('<textarea></textarea><div class="segment-user"><div class="segment-content"><span class="user-content__text">真正的问题</span></div><div class="segment-user-actions">编辑 重试</div></div>');expect(k.run('observe').lastQuestion).toBe('真正的问题');expect(k.run('observe').userCount).toBe(1);k.dom.window.close()
 })
 it('千问受控编辑器走粘贴事件，不重复execCommand；未启用按钮只提示等待，不点击',()=>{
  const {dom,run}=website('<div contenteditable="true" data-slate-editor="true"></div><button aria-label="发送消息" disabled></button>','https://qianwen.com/','qianwen');const w=dom.window,editor=w.document.querySelector('div'),button=w.document.querySelector('button');let pasted=0,clicked=0;
  w.DataTransfer=class{setData(_type,value){this.value=value}};w.ClipboardEvent=class extends w.Event{constructor(type,options){super(type,options);this.clipboardData=options.clipboardData}};
  editor.addEventListener('paste',event=>{event.preventDefault();pasted++;editor.textContent=event.clipboardData.value});w.document.execCommand=()=>{throw new Error('不得再次插入')};button.onclick=()=>clicked++;
  expect(run('prepare','受控合成问题').status).toBe('prepared');expect(pasted).toBe(1);expect(run('submit','受控合成问题').retryableBeforeSend).toBe(true);expect(clicked).toBe(0);button.removeAttribute('disabled');expect(run('submit','受控合成问题').status).toBe('generating');expect(clicked).toBe(1);expect(run('submit','受控合成问题').status).toBe('uncertain');dom.window.close()
 })
 it('智谱点击纸飞机图片而不是外层容器；同一按钮父子匹配不会误判两个按钮',()=>{const {dom,run}=website('<div id="search-input-box"><textarea></textarea><div class="enter-icon-container"><img class="enter_icon"></div></div>','https://chatglm.cn/','glm');let count=0;dom.window.document.querySelector('img').onclick=()=>count++;run('prepare','智谱合成问题');expect(run('submit','智谱合成问题').status).toBe('generating');expect(count).toBe(1);expect(run('submit','智谱合成问题').status).toBe('uncertain');dom.window.close()})
 it('智谱按下事件若已提交并清空输入，不再补一次click；完整鼠标事件含window和detail',()=>{const {dom,run}=website('<div id="search-input-box"><textarea></textarea><div class="enter-icon-container"><img class="enter_icon"></div></div>','https://chatglm.cn/','glm');let count=0;const d=dom.window.document,img=d.querySelector('img');img.onmousedown=event=>{expect(event.view).toBe(dom.window);expect(event.detail).toBe(1);count++;d.querySelector('textarea').value=''};img.onclick=()=>count++;run('prepare','只提交一次');expect(run('submit','只提交一次').status).toBe('generating');expect(count).toBe(1);dom.window.close()})
 it('智谱新版回答区域不混入其他markdown，停止对话控件能标记生成中',()=>{const {dom,run}=website('<textarea></textarea><div class="markdown-body">其他页面文本</div><div class="answer-content-wrap"><div class="markdown-body">OK</div></div><div aria-label="停止对话"></div>','https://chatglm.cn/','glm');expect(run('observe').answers).toEqual(['OK']);expect(run('observe').busy).toBe(true);dom.window.close()})
 it('千问新版回答只采集答案区，完成标记属于最后一条回答',()=>{const {dom,run}=website('<textarea></textarea><div class="message-card-wrap question">合成提问</div><div class="message-select-wrapper-answer-fixture"><div class="qk-markdown qk-markdown-complete">OK</div></div>','https://qianwen.com/','qianwen');let result=run('observe');expect(result.answers).toEqual(['OK']);expect(result.lastQuestion).toBe('合成提问');expect(result.complete).toBe(true);dom.window.document.body.insertAdjacentHTML('beforeend','<div class="message-select-wrapper-answer-another"><div class="qk-markdown">新回答</div></div>');expect(run('observe').complete).toBe(false);dom.window.close()})
 it('ChatGPT初始化占位框不作为可发送编辑器；真正编辑器不需要旧ID',()=>{const {dom,run}=website('<textarea id="pending-home-input"></textarea>','https://chatgpt.com/','chatgpt');expect(run('observe').editorCount).toBe(0);expect(run('prepare','合成提问').status).toBe('unsupported');expect(dom.window.document.querySelector('textarea').value).toBe('');dom.window.document.body.insertAdjacentHTML('beforeend','<div contenteditable="true" class="ProseMirror" role="textbox" aria-label="Ask ChatGPT">同一草稿</div>');expect(run('observe','同一草稿').draftMatchesQuestion).toBe(true);expect(run('observe','不同问题').draftMatchesQuestion).toBe(false);expect(run('observe').editorCount).toBe(1);dom.window.close()})
 const cases=[
  ['kimi','https://www.kimi.com/','<div contenteditable="true" class="chat-input-editor"></div><button class="send-button">发送</button>','<div class="segment-assistant" data-streaming="false"><div class="markdown">隔离回答</div></div>'],
  ['glm','https://chatglm.cn/','<div id="search-input-box"><textarea></textarea><div class="enter-icon-container">发送</div></div>','<div class="message-assistant" data-streaming="false"><div class="markdown-body">隔离回答</div></div>'],
  ['doubao','https://www.doubao.com/chat/','<textarea data-testid="chat_input_input"></textarea><button data-testid="chat_input_send_button">发送</button>','<div data-testid="receive_message" data-streaming="false"><div class="md-box-root">隔离回答</div><button data-testid="message_action_regenerate"></button></div>'],
  ['yuanbao','https://yuanbao.tencent.com/','<div contenteditable="true" class="ql-editor"></div><div id="yuanbao-send-btn">发送</div>','<div class="agent-chat__bubble--ai" data-streaming="false"><div class="hyc-content-md">隔离回答</div></div>'],
  ['qianwen','https://www.qianwen.com/','<div contenteditable="true" data-slate-editor="true"></div><button aria-label="发送消息">发送</button>','<div class="message-assistant" data-streaming="false"><div class="markdown">隔离回答</div></div>'],
  ['chatgpt','https://chatgpt.com/','<div id="prompt-textarea" contenteditable="true"></div><button data-testid="send-button">发送</button>','<div data-message-author-role="assistant" data-streaming="false"><div class="markdown">隔离回答</div></div>'],
 ]
 it.each(cases)('%s 填入、发送一次、按助手容器采集并识别完成标记',(provider,url,input,reply)=>{const {dom,run}=website(input,url,provider);const d=dom.window.document;d.execCommand=(_a,_b,value)=>{d.querySelector('[contenteditable]').textContent=value;return true};const send=d.querySelector('button,.enter-icon-container,#yuanbao-send-btn');let sent=0;send.onclick=()=>{sent++;d.body.insertAdjacentHTML('beforeend',reply)};expect(run('prepare','隔离测试问题').status).toBe('prepared');expect(run('submit','隔离测试问题').status).toBe('generating');expect(sent).toBe(1);const result=run('observe');expect(result.answers).toEqual(['隔离回答']);expect(result.answerCount).toBe(1);expect(result.complete).toBe(true);expect(run('submit','隔离测试问题').status).toBe('uncertain');expect(sent).toBe(1);dom.window.close()})
})
function setup(options={}){
 const {WB}=loadClientBundle();let App;const calls=[]
 let web={topics:[{id:'topic',title:'合成验收主题',createdAt:new Date().toISOString(),conversations:{}}],rounds:[{id:'round',topicId:'topic',requestId:'fixture',question:'合成问题',createdAt:new Date().toISOString(),answers:[{providerId:'kimi',status:'unsupported',text:'',url:null,note:'可粘贴官网回答',updatedAt:'2026-10-28T01:00:00Z'}]}],chatgptEnabled:false}
 if(options.empty)web={topics:[],rounds:[],chatgptEnabled:false}
 const data={version:2,revision:1,settings:{topics:[],feeds:[],automation:{enabled:false},aiExtract:{enabled:false}},projects:[],tasks:[],sources:[],radar:[],replies:[],analysisQueue:[],jobs:[],knowledge:[],connectors:[],runs:[],audit:[]}
 const call=async(_ch,endpoint,payload)=>{calls.push(endpoint);const req=payload.args?.request;let value=data;if(endpoint==='workbench/webAIState')value={state:web,capabilities:{chromeAvailable:false,storageScope:'fixture',attachmentsProtocol:options.legacyAttachments?undefined:1,historyProtocol:1}};if(endpoint==='workbench/webAIManageTopic'){web={...web,topics:web.topics.map(t=>t.id===req.topicId?{...t,title:req.title,version:(t.version||0)+1}:t)};value=web}if(endpoint==='workbench/webAIEditQuestion'){web={...web,rounds:web.rounds.map(r=>r.id===req.roundId?{...r,displayQuestion:req.text}:r)};value=web}if(endpoint==='workbench/webAIConfigure'){web={...web,chatgptEnabled:req.chatgptEnabled};value=web}if(endpoint==='workbench/webAIStart'){const id=req.topicId||'auto-topic';if(!req.topicId)web.topics.push({id,title:req.questions[0],createdAt:new Date().toISOString(),conversations:{}});web.rounds.push(...req.questions.map((question,i)=>({id:'auto-round-'+i,topicId:id,requestId:req.requestId,question,createdAt:new Date().toISOString(),answers:req.providers.map(providerId=>({providerId,status:'queued',text:'',note:'',url:null,updatedAt:new Date().toISOString()}))})));value=web}if(endpoint==='workbench/webAIClaim')value={executionId:'ui-execution'};if(endpoint==='workbench/webAIUpdate'){const row=web.rounds.find(r=>r.id===req.roundId)?.answers.find(a=>a.providerId===req.providerId);if(row)Object.assign(row,req);value=web}if(endpoint==='workbench/webAIRecord'){web={...web,rounds:[{...web.rounds[0],answers:[{...web.rounds[0].answers[0],text:req.text,status:'completed'}]}]};value=web}return {ok:true,value}}
 WB.store.set({data,status:'ready',page:'web-ai'});WB.apply({get(){},effect:fn=>fn(),connection:{rpc:{call}},slots:{inject(_n,fn){return fn()},register(d,c){if(d.name==='main')App=c;return()=>{}}},locale:{register:()=>()=>{},bind:()=>()=>''}});render(<App/>);return{WB,calls}
}
describe('网页 AI 独立工作台',()=>{
 it.each([1280,360])('会话折叠与窄屏抽屉保持当前会话、草稿、附件和厂商选择（%ipx）',async width=>{
  const previous=window.innerWidth;Object.defineProperty(window,'innerWidth',{configurable:true,value:width})
  try{
   const {calls}=setup(),user=userEvent.setup();await screen.findByRole('heading',{name:'合成验收主题',level:2});const editor=screen.getByRole('textbox',{name:'多 AI 对话问题'});await user.type(editor,'保留这份未发送草稿');await user.upload(screen.getByLabelText('选择问题附件'),new File(['local-draft'],'草稿资料.txt',{type:'text/plain'}));const providers=document.querySelector('.wb-chat-provider-picker summary').textContent
   if(width<=640)await user.click(screen.getByRole('button',{name:'展开会话列表',exact:true}));await user.type(screen.getByRole('textbox',{name:'搜索会话'}),'合成')
   if(width<=640){expect(document.querySelector('.wb-chat-main').getAttribute('aria-hidden')).toBe('true');await user.keyboard('{Escape}')}
   else await user.click(screen.getByRole('button',{name:'收起会话列表',exact:true}))
   expect(screen.getByRole('textbox',{name:'多 AI 对话问题'})).toBe(editor);expect(editor.value).toBe('保留这份未发送草稿');expect(screen.getByText('草稿资料.txt')).toBeTruthy();expect(document.querySelector('.wb-chat-provider-picker summary').textContent).toBe(providers)
   await user.click(screen.getByRole('button',{name:'展开会话列表',exact:true}));expect(screen.getByRole('textbox',{name:'搜索会话'}).value).toBe('合成');await user.click(screen.getByRole('button',{name:'选择会话 合成验收主题'}));expect(screen.getByRole('textbox',{name:'多 AI 对话问题'}).value).toBe('保留这份未发送草稿');expect(calls.some(call=>/webAIStart|webAIClaim|webAIUpdate/.test(call))).toBe(false)
  }finally{Object.defineProperty(window,'innerWidth',{configurable:true,value:previous})}
 })

 it('厂商与回答菜单点击外部关闭，Escape关闭，不影响菜单内选择',async()=>{
  setup();const user=userEvent.setup();await screen.findByRole('heading',{name:'合成验收主题',level:2})
  const picker=document.querySelector('.wb-chat-provider-picker');await user.click(picker.querySelector('summary'));expect(picker.open).toBe(true)
  await user.click(screen.getByRole('checkbox',{name:'豆包',exact:true}));expect(picker.open).toBe(true)
  fireEvent.pointerDown(screen.getByRole('heading',{name:'合成验收主题',level:2}));expect(picker.open).toBe(false)
  const more=screen.getByLabelText('回答更多操作');await user.click(more);expect(more.parentElement.open).toBe(true)
  fireEvent.pointerDown(screen.getByRole('textbox',{name:'多 AI 对话问题'}));expect(more.parentElement.open).toBe(false)
  await user.click(picker.querySelector('summary'));fireEvent.keyDown(document,{key:'Escape'});expect(picker.open).toBe(false)
 })
 it('右上角打开独立官网浮层，聊天留在背景，关闭后保留输入',async()=>{
  vi.stubGlobal('dshDesktop',{protocolVersion:1,browser:{acquire:async()=>({lease:'dialog-test',partition:'dialog-test'}),release:async()=>{},onOpenRequested:()=>()=>{}}})
  setup();const user=userEvent.setup();await screen.findByRole('heading',{name:'合成验收主题',level:2});const editor=screen.getByRole('textbox',{name:'多 AI 对话问题'});await user.type(editor,'未发送草稿')
  await user.click(screen.getByRole('button',{name:'登录 / 官网'}));const dialog=await screen.findByRole('dialog',{name:'登录与原对话'});expect(dialog.getAttribute('aria-modal')).toBe('true');expect(document.querySelector('.wb-chat-layout').hasAttribute('inert')).toBe(true)
  await user.click(screen.getByRole('button',{name:'返回聊天'}));expect(screen.queryByRole('dialog',{name:'登录与原对话'})).toBeNull();expect(editor.value).toBe('未发送草稿')
 })
 it('聊天输入支持回车发送，Shift回车和中文输入法确认不发送',async()=>{
  const {calls}=setup({empty:true}),user=userEvent.setup(),editor=screen.getByRole('textbox',{name:'多 AI 对话问题'})
  await user.type(editor,'输入中的问题');fireEvent.keyDown(editor,{key:'Enter',keyCode:229,isComposing:true});expect(calls.includes('workbench/webAIStart')).toBe(false)
  await user.keyboard('{Shift>}{Enter}{/Shift}');expect(editor.value).toContain('\n');expect(calls.includes('workbench/webAIStart')).toBe(false)
  await user.keyboard('{Enter}');await waitFor(()=>expect(calls.filter(value=>value==='workbench/webAIStart')).toHaveLength(1))
 })
 it('历史管理入口连接本地重命名、搜索和问题编辑，不向官网重新发送',async()=>{
  const {calls}=setup(),user=userEvent.setup();await screen.findByRole('heading',{name:'合成验收主题',level:2});await user.click(screen.getByRole('button',{name:'管理历史与回收站'}));await user.type(screen.getByRole('textbox',{name:'搜索历史问答'}),'合成问题');await user.click(screen.getByRole('button',{name:'重命名问答 合成验收主题'}));await user.clear(screen.getByRole('textbox',{name:'问答名称'}));await user.type(screen.getByRole('textbox',{name:'问答名称'}),'项目讨论');await user.click(screen.getByRole('button',{name:'确认',exact:true}));await waitFor(()=>expect(screen.getByRole('heading',{name:'项目讨论',level:2})).toBeTruthy());await user.click(screen.getByRole('button',{name:'打开问答 项目讨论'}));await user.click(screen.getByLabelText('回答更多操作'));await user.click(screen.getByRole('button',{name:'编辑本地问题'}));await user.clear(screen.getByRole('textbox',{name:'本地问题正文'}));await user.type(screen.getByRole('textbox',{name:'本地问题正文'}),'本地问题修订');await user.click(screen.getByRole('button',{name:'保存'}));await screen.findByRole('heading',{name:'本地问题修订',level:3});expect(calls.includes('workbench/webAIManageTopic')).toBe(true);expect(calls.includes('workbench/webAIEditQuestion')).toBe(true);expect(calls.includes('workbench/webAIStart')).toBe(false)
 })
 it('首次直接提问自动建立历史问答，官网默认收起且不请求手动创建主题',async()=>{const {calls}=setup({empty:true});const user=userEvent.setup();await user.type(screen.getByRole('textbox',{name:'多 AI 对话问题'}),'首次直接提问');await user.click(screen.getByRole('button',{name:'发送消息'}));await waitFor(()=>expect(screen.getByRole('heading',{name:'首次直接提问',level:2})).toBeTruthy());await waitFor(()=>expect(screen.getByRole('heading',{name:'首次直接提问',level:3})).toBeTruthy());expect(screen.queryByRole('region',{name:'登录与原对话'})).toBeNull();expect(calls.filter(c=>c==='workbench/webAIStart')).toHaveLength(1);expect(calls.includes('workbench/webAICreateTopic')).toBe(false);expect(calls.some(c=>/assistant|OpenExternal/.test(c))).toBe(false)})
 it('图片粘贴进入附件而非问题文本；文件选择与移除可用，纯附件提供明确默认提问',async()=>{
  setup({empty:true});await screen.findByRole('button',{name:'添加附件'});const user=userEvent.setup(),editor=screen.getByRole('textbox',{name:'多 AI 对话问题'}),image=new File(['synthetic'],'paste.png',{type:'image/png'}),text=new File(['marker'],'sample.txt',{type:'text/plain'})
  fireEvent.paste(editor,{clipboardData:{files:[image]}});expect(screen.getByText('paste.png')).toBeTruthy();expect(editor.value).toBe('');await user.upload(screen.getByLabelText('选择问题附件'),text);await user.click(screen.getByRole('button',{name:'移除附件 paste.png'}));expect(screen.queryByText('paste.png')).toBeNull();expect(screen.getByText('sample.txt')).toBeTruthy();await user.click(screen.getByRole('button',{name:'发送消息'}));await screen.findByRole('heading',{name:'请分析所附附件，并说明关键内容。',level:3})
 })
 it('旧Host没有附件协议时在传输前拦截，保留文件而不创建空附件问答',async()=>{
  const {calls}=setup({empty:true,legacyAttachments:true});await screen.findByRole('button',{name:'添加附件'});const user=userEvent.setup();await user.upload(screen.getByLabelText('选择问题附件'),new File(['test'],'legacy.txt',{type:'text/plain'}));await user.click(screen.getByRole('button',{name:'发送消息'}));expect((await screen.findByRole('alert')).textContent).toContain('附件后端尚未加载');expect(screen.getByText('legacy.txt')).toBeTruthy();expect(calls.includes('workbench/webAIStart')).toBe(false)
 })
 it('普通文本粘贴继续写入提问，不被附件入口吞掉',async()=>{
  setup({empty:true});const user=userEvent.setup(),editor=screen.getByRole('textbox',{name:'多 AI 对话问题'});await user.click(editor);await user.paste('普通文本提问');expect(editor.value).toBe('普通文本提问');expect(screen.queryByText(/KB/)).toBeNull()
 })
 it('默认五家国内厂商、ChatGPT可选，不调用原生助手或启动外部窗口',async()=>{const {calls}=setup();await screen.findByRole('heading',{name:'合成验收主题',level:2});await userEvent.setup().click(screen.getByText(/Kimi、智谱清言/));expect(screen.getByRole('checkbox',{name:'Kimi'})).toBeTruthy();expect(screen.queryByRole('checkbox',{name:'ChatGPT',exact:true})).toBeNull();const user=userEvent.setup();await user.click(screen.getByRole('checkbox',{name:'启用 ChatGPT'}));await screen.findByRole('checkbox',{name:'ChatGPT',exact:true});expect(calls.some(c=>/assistant|OpenExternal/.test(c))).toBe(false)})
 it('不提供另开浏览器入口，登录保留状态区分当前宿主真实能力',async()=>{setup();await screen.findByRole('heading',{name:'合成验收主题',level:2});expect(screen.queryByText(/备用专用浏览器/)).toBeNull();expect(screen.getByLabelText('登录保留状态').textContent).toContain('不支持内嵌官网');expect(screen.getByText('登录保留与兼容性')).toBeTruthy()})
 it('切换业务页面后统一输入草稿仍然保留，页面不重建',async()=>{const {WB}=setup();await screen.findByRole('heading',{name:'合成验收主题',level:2});const user=userEvent.setup();await user.type(screen.getByRole('textbox',{name:'多 AI 对话问题'}),'保留此草稿');await act(async()=>WB.go('dashboard'));await act(async()=>WB.go('web-ai'));expect(screen.getByRole('textbox',{name:'多 AI 对话问题'}).value).toBe('保留此草稿')})
 it('自动提取不兼容时可以人工保存并纳入对比',async()=>{setup();await screen.findByRole('heading',{name:'合成验收主题',level:2});const user=userEvent.setup();await user.click(screen.getByLabelText('回答更多操作'));await user.click(screen.getByRole('button',{name:'粘贴 / 编辑回答'}));await user.type(screen.getByRole('textbox',{name:'粘贴官网回答'}),'来自官网的人工回答');await user.click(screen.getByRole('button',{name:'保存'}));await waitFor(()=>expect(screen.getByText('来自官网的人工回答')).toBeTruthy());await user.click(screen.getByLabelText('回答更多操作'));expect(screen.getByRole('button',{name:'存为候选知识'})).toBeTruthy()})
})
describe('内嵌登录存储协商（本地宿主扩展的客户端模拟）',()=>{
 function bridge(persistence){return{acquire:vi.fn(async scope=>({lease:'memory-lease',partition:scope})),release:vi.fn(async()=>{}),onOpenRequested:()=>()=>{},...(persistence?{persistence}:{})}}
 it('当前官方接口明确显示仅本次启动保留；不自行制造persist分区',async()=>{const b=bridge();expect(browserSessionMode(b)).toBe('memory');expect(browserSessionMessage('memory')).toContain('完整退出后需要重新登录');expect(browserSessionMode(null)).toBe('unavailable');const value=await acquireWebsiteSession(b,'workbench-web-ai:fixture','kimi');expect(value.mode).toBe('memory');expect(value.partition.startsWith('persist:')).toBe(false);expect(b.acquire).toHaveBeenCalledWith('workbench-web-ai:fixture:kimi')})
 it('同一厂商跨话题复用存储范围，不同厂商使用不同内存范围',async()=>{const b=bridge();await acquireWebsiteSession(b,'synthetic','kimi');await acquireWebsiteSession(b,'synthetic','glm');await acquireWebsiteSession(b,'synthetic','kimi');expect(b.acquire.mock.calls.map(args=>args[0])).toEqual(['synthetic:kimi','synthetic:glm','synthetic:kimi'])})
 it('宿主明确支持v1时才请求固定命名空间和厂商，不发送路径或认证信息',async()=>{const persistence={protocolVersion:1,acquire:vi.fn(async request=>({lease:'host-issued',partition:'persist:host-approved',persistence:'persistent',providerId:request.providerId}))},b=bridge(persistence);const value=await acquireWebsiteSession(b,'synthetic','kimi');expect(value.mode).toBe('persistent');expect(persistence.acquire).toHaveBeenCalledWith({namespace:WEB_AI_BROWSER_NAMESPACE,providerId:'kimi'});expect(b.acquire).not.toHaveBeenCalled();expect(browserSessionMessage(value.mode,true)).toContain('登录是否有效由官网确认')})
 it('持久化申请失败不静默退回内存或外部浏览器',async()=>{const b=bridge({protocolVersion:1,acquire:vi.fn(async()=>{throw new Error('host unavailable')})});await expect(acquireWebsiteSession(b,'synthetic','kimi')).rejects.toThrow('host unavailable');expect(b.acquire).not.toHaveBeenCalled();expect(b.release).not.toHaveBeenCalled()})
 it('拒绝错厂商、伪持久化或不匹配的宿主返回并释放其lease',async()=>{for(const patch of [{providerId:'glm'},{partition:'memory-only'},{persistence:'memory'},{partition:''}]){const b=bridge({protocolVersion:1,acquire:async()=>({lease:'invalid-lease',partition:'persist:host-approved',persistence:'persistent',providerId:'kimi',...patch})});await expect(acquireWebsiteSession(b,'synthetic','kimi')).rejects.toThrow('不匹配');expect(b.release).toHaveBeenCalledWith('invalid-lease');expect(b.acquire).not.toHaveBeenCalled()}})
 it('未知版本不冒充持久化；普通接口也不接受未声明的持久化分区',async()=>{const b=bridge({protocolVersion:2,acquire:vi.fn()});expect(browserSessionMode(b)).toBe('memory');await acquireWebsiteSession(b,'synthetic','kimi');expect(b.persistence.acquire).not.toHaveBeenCalled();b.acquire.mockResolvedValue({lease:'unexpected-persist',partition:'persist:unexpected'});await expect(acquireWebsiteSession(b,'synthetic','kimi')).rejects.toThrow('不匹配');expect(b.release).toHaveBeenCalledWith('unexpected-persist')})
 it('拒绝无效厂商及客户端路径，申请之前停止',async()=>{const b=bridge();await expect(acquireWebsiteSession(b,'/arbitrary/profile','kimi')).rejects.toThrow('范围无效');await expect(acquireWebsiteSession(b,'synthetic','claude')).rejects.toThrow('不支持');expect(b.acquire).not.toHaveBeenCalled()})
})
describe('内嵌网页生命周期',()=>{
 it('子页面资源加载不把已就绪的主页面永久置为加载中，卸载释放自己的lease',async()=>{
  const release=vi.fn(async()=>{});vi.stubGlobal('dshDesktop',{protocolVersion:1,browser:{acquire:async()=>({lease:'test-lease',partition:'test-partition'}),release,onOpenRequested:()=>()=>{}}})
  let controller,current='about:blank#test-lease';const original={};for(const key of ['loadURL','getURL','executeJavaScript'])original[key]=Object.getOwnPropertyDescriptor(HTMLElement.prototype,key)
  HTMLElement.prototype.loadURL=async function(url){current=url;queueMicrotask(()=>this.dispatchEvent(new Event('dom-ready')))}
  const execution=vi.fn(async()=>({status:'ready',answers:[]}));HTMLElement.prototype.getURL=()=>current;HTMLElement.prototype.executeJavaScript=execution
  const view=render(<NativeWebsite providerId="kimi" scope="synthetic" url="https://www.kimi.com/" visible onController={value=>{controller=value}}/> )
  try{
   await waitFor(()=>expect(view.container.querySelector('webview')).toBeTruthy());const guest=view.container.querySelector('webview');await act(async()=>guest.dispatchEvent(new Event('dom-ready')));await waitFor(()=>expect(controller?.execute).toBeTypeOf('function'))
   await act(async()=>guest.dispatchEvent(new Event('did-start-loading')))
   const result=await controller.execute('observe');expect(result.status).toBe('ready');expect(execution.mock.calls.at(-1)[1]).toBe(false);await controller.execute('prepare','合成问题','synthetic');expect(execution.mock.calls.at(-1)[1]).toBe(true);await controller.execute('submit','合成问题','synthetic');expect(execution.mock.calls.at(-1)[1]).toBe(true);await controller.execute('inspect');expect(execution.mock.calls.at(-1)[1]).toBe(false);expect(screen.queryByText('正在加载官网…')).toBeNull();view.unmount();await waitFor(()=>expect(release).toHaveBeenCalledWith('test-lease'))
  }finally{view.unmount();for(const key of Object.keys(original)){if(original[key])Object.defineProperty(HTMLElement.prototype,key,original[key]);else delete HTMLElement.prototype[key]}}
 },4000)
})
