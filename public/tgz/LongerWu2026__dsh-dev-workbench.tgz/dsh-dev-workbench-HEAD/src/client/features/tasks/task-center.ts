import {WorkspaceRefresh} from '../../components/WorkspaceRefresh.js'
import {MessageSelectionBadges} from '../../components/MessageSelectionBadges.js'
import {Pagination,PAGE_SIZE,pageIndex} from '../../components/Pagination.js'
import {TaskMessageMetadata} from '../../components/TaskMessageMetadata.js'
import {messageSentTime,taskSource} from '../../../shared/message-display.js'
import {matchesTaskMessageDates,sortTasksByMessageTime,taskMessageTime} from './message-time.js'
import {taskReplyTarget} from '../../../shared/task-reply.js'
import {TaskReplyPanel} from './TaskReplyPanel.js'
import { Badge, Btn, Chip, Empty, Icon, IconBtn, Input, PageHead, Panel, Segmented, Select, Spinner, T, Tabs, WB, h } from '../../core/runtime.js'
import * as React from 'react'
/* ============================================================================
 * dev-workbench — 任务中心 (tasks)
 *
 * 一个页面覆盖任务的完整生命周期：搜索 / 状态 / 优先级 / 项目 / 标签 / 到期
 * 筛选，列表与看板两种视图，新建与编辑复用 shell 挂载的共享任务表单
 * (WB.openTaskForm)，完成 / 重开 / 删除走 Host 动作，来源证据从 data.sources
 * 展开。所有筛选状态只存在于本页 useState 中，不写回 Host。
 *
 * Cross-module note: on mount this page consumes (and clears) the transient
 * store field `taskPreset` set by 20-dashboard.js stat cards, and it honours
 * `state.focusTaskId` (set by WB.focusTask) by revealing that task once.
 * ========================================================================== */
/* ------------------------------------------------------------------ helpers */
function tcToneColor(tone?: any): any {
    if (tone === 'err')
        return T.err;
    if (tone === 'warn')
        return T.warn;
    if (tone === 'ok')
        return T.ok;
    if (tone === 'accent')
        return T.accent;
    return T.text2;
}
function tcPriorityOf(task?: any): any {
    return WB.TASK_PRIORITY[task.priority] || WB.TASK_PRIORITY.normal;
}
function tcDueValue(task?: any): any {
    const at = task.dueAt || task.meetingStart;
    if (!at)
        return Infinity;
    const value = new Date(at).getTime();
    return Number.isNaN(value) ? Infinity : value;
}
function tcEndOfToday(): any {
    const end = new Date();
    end.setHours(23, 59, 59, 999);
    return end.getTime();
}
function tcProjectName(data?: any, projectId?: any): any {
    if (!projectId)
        return '';
    const projects = (data && data.projects) || [];
    for (let index = 0; index < projects.length; index += 1) {
        if (projects[index].id === projectId)
            return projects[index].name || '';
    }
    return '';
}
function tcProjectColor(data?: any, projectId?: any): any {
    if (!projectId)
        return null;
    const projects = (data && data.projects) || [];
    for (let index = 0; index < projects.length; index += 1) {
        if (projects[index].id === projectId)
            return projects[index].color || null;
    }
    return null;
}
function tcProviderLabel(provider?: any): any {
    const key = String(provider || '').toLowerCase();
    if(key==='yunzhijia-calendar')return '云之家日历';
    if (key === 'yunzhijia' || key === 'yzj')
        return '云之家';
    if (key === 'git' || key === 'github' || key === 'gitlab')
        return 'Git';
    if (key === 'web' || key === 'rss' || key === 'http')
        return '网页';
    if (key === 'manual')
        return '手动';
    if (key === 'docker')
        return 'Docker';
    return provider ? String(provider) : '未知来源';
}
function tcFindSource(data?: any, task?: any): any {
    return taskSource(task,data?.sources || []);
}
function tcBoardStatuses(): any {
    return ['ready', 'running', 'completed'];
}
/** 未完成按到期时间升序（无截止靠后），已结束按最近更新降序。 */
function tcSortTasks(list?: any,order='default',sources:any[]=[]): any {
    const sorted=(list || []).slice().sort(function (a?: any, b?: any): any {
        const aDone = a.status === 'completed' || a.status === 'cancelled' ? 1 : 0;
        const bDone = b.status === 'completed' || b.status === 'cancelled' ? 1 : 0;
        if (aDone !== bDone)
            return aDone - bDone;
        if (aDone === 1) {
            return String(b.completedAt || b.updatedAt || '').localeCompare(String(a.completedAt || a.updatedAt || ''));
        }
        const ad = tcDueValue(a);
        const bd = tcDueValue(b);
        if (ad !== bd)
            return ad - bd;
        const ar = tcPriorityOf(a).rank || 0;
        const br = tcPriorityOf(b).rank || 0;
        if (ar !== br)
            return br - ar;
        return String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''));
    });
    return sortTasksByMessageTime(sorted,sources,order);
}
function tcFilterList(list?: any, filters?: any): any {
    const opts = filters || {};
    const query = opts.query ? String(opts.query).trim().toLowerCase() : '';
    const status = opts.status || 'all';
    const dueFilter = opts.dueFilter || 'all';
    const now = Date.now();
    const endOfDay = tcEndOfToday();
    const weekAhead = now + 7 * 86400000;
    return (list || []).filter(function (task?: any): any {
        if((opts.messageFrom||opts.messageTo)&&!matchesTaskMessageDates(taskMessageTime(task,opts.sources||[]),opts.messageFrom||'',opts.messageTo||''))return false;
        if (query) {
            const haystack = [task.title || '', task.description || '', (task.tags || []).join(' ')]
                .join(' ')
                .toLowerCase();
            if (haystack.indexOf(query) < 0)
                return false;
        }
        if (opts.priority && opts.priority !== 'all' && task.priority !== opts.priority)
            return false;
        if (opts.projectId && opts.projectId !== 'all') {
            if (opts.projectId === 'none') {
                if (task.projectId)
                    return false;
            }
            else if (task.projectId !== opts.projectId) {
                return false;
            }
        }
        if (opts.tag && (task.tags || []).indexOf(opts.tag) < 0)
            return false;
        if (dueFilter !== 'all') {
            /* 逾期 / 今日 / 7 天都描述“还要做的事”，已结束的任务不参与。 */
            if (task.status === 'completed' || task.status === 'cancelled')
                return false;
            const due = tcDueValue(task);
            if (due === Infinity)
                return false;
            if (dueFilter === 'overdue' && due >= now)
                return false;
            if (dueFilter === 'today' && (due < now || due > endOfDay))
                return false;
            if (dueFilter === 'week' && (due < now || due > weekAhead))
                return false;
        }
        if (status !== 'all') {
            if (status === 'open') {
                if (task.status === 'completed' || task.status === 'cancelled')
                    return false;
            }
            else if (task.status !== status) {
                return false;
            }
        }
        return true;
    });
}
function tcTabCounts(list?: any): any {
    const counts: any = { all: 0, open: 0, ready: 0, running: 0, completed: 0, overdue: 0 };
    const now = Date.now();
    (list || []).forEach(function (task?: any): any {
        counts.all += 1;
        if (task.status === 'completed')
            counts.completed += 1;
        else if (task.status !== 'cancelled')
            counts.open += 1;
        if (task.status === 'ready')
            counts.ready += 1;
        if (task.status === 'running')
            counts.running += 1;
        if (task.status !== 'completed' && task.status !== 'cancelled' && tcDueValue(task) < now)
            counts.overdue += 1;
    });
    return counts;
}
function tcTagCounts(tasks?: any): any {
    const counts: any = {};
    (tasks || []).forEach(function (task?: any): any {
        ;
        (task.tags || []).forEach(function (tag?: any): any {
            if (!tag)
                return;
            counts[tag] = (counts[tag] || 0) + 1;
        });
    });
    return Object.keys(counts)
        .map(function (tag?: any): any {
        return { tag: tag, count: counts[tag] };
    })
        .sort(function (a?: any, b?: any): any {
        if (b.count !== a.count)
            return b.count - a.count;
        return a.tag.localeCompare(b.tag);
    });
}
/* --------------------------------------------------------------------- views */
function TaskCenterEvidence(props?: any): any {
    const task = props.task;
    const data = props.data;
    const source = tcFindSource(data, task);
    const confidence = typeof task.confidence === 'number' ? Math.round(task.confidence * 100) + '%' : '未评估';
    return h('div', {
        style: {
            border: '1px solid ' + T.border1,
            borderRadius: 10,
            background: T.bg,
            padding: '9px 11px',
        },
    }, h('div', { className: 'wb-row', style: { gap: 6, marginBottom: 6, flexWrap: 'wrap' } }, h('span', { style: { display: 'inline-flex', color: T.text2 } }, h(Icon, { name: 'layers', size: 12 })), h('span', { className: 'wb-tiny', style: { fontWeight: 600, color: T.text } }, '来源证据'), task.aiExtracted
        ? h(Badge, { tone: 'accent' }, 'AI 提取 · 置信度 ' + confidence)
        : h(Badge, { tone: 'idle' }, '手动创建'), h('div', { className: 'wb-spacer' }), h('span', { className: 'wb-tiny wb-muted' }, '更新于 ' + WB.fmt.relative(task.updatedAt))), source
        ? h('div', { className: 'wb-stack', style: { gap: 5 } }, h('div', { className: 'wb-row wb-row--wrap', style: { gap: 7 } }, h(Badge, { tone: 'idle' }, tcProviderLabel(source.provider)), source.title ? h('span', { style: { fontSize: 12, fontWeight: 500, color: T.text } }, source.title) : null, source.url
            ? h('a', {
                className: 'wb-link wb-tiny',
                href: source.url,
                target: '_blank',
                rel: 'noreferrer noopener',
                style: { display: 'inline-flex', alignItems: 'center', gap: 3 },
            }, '打开原文', h(Icon, { name: 'external', size: 10 }))
            : null, h('div', { className: 'wb-spacer' }), source.provider==='yunzhijia' ? null : h('span', { className: 'wb-tiny wb-muted' }, '同步于 ' + WB.fmt.datetime(source.fetchedAt)), h(IconBtn, {
            name: 'trash',
            label: '删除这条来源证据',
            onClick: function (): any {
                if (!window.confirm('删除这条来源证据？引用它的候选会一并移除，待办只解除来源关联。'))
                    return;
                WB.actions.deleteSource(source.id).catch(function (): any { });
            },
        })), h(MessageSelectionBadges,{source:(data.sources||[]).find((s:any)=>s.id===task.sourceRefId),inbox:data.messageInbox}),h(TaskMessageMetadata,{task,data}), source.excerpt ? h('div', { className: 'wb-code' }, source.excerpt) : null, h('div', { className: 'wb-row wb-tiny wb-muted wb-row--wrap', style: { gap: 10 } }, h('span', { className: 'wb-mono' }, 'source ' + source.id), source.externalId ? h('span', null, '外部 ID ' + source.externalId) : null, source.payloadHash ? h('span', { className: 'wb-mono' }, '指纹 ' + String(source.payloadHash).slice(0, 12)) : null))
        : h('div', { className: 'wb-stack', style: { gap: 3 } }, h('span', { className: 'wb-tiny', style: { color: T.text } }, '无来源证据'), h('span', { className: 'wb-tiny wb-muted', style: { lineHeight: 1.6 } }, task.sourceRefId
            ? '这条待办引用了来源 ' + task.sourceRefId + '，但当前快照中没有对应记录。'
            : '手动创建的待办不会关联外部来源；接入云之家或网页来源后，原始消息会记录在这里。')));
}
function TaskCenterStatusSelect(props?: any): any {
    const task = props.task;
    const meta = WB.TASK_STATUS[task.status] || { label: task.status || '未知状态', tone: 'idle' };
    return h('span', { className: 'wb-select-wrap', style: { width: 106 } }, h('select', {
        className: 'wb-select',
        'aria-label': '状态 ' + task.title,
        title: '修改待办状态',
        value: task.status,
        disabled: props.busy,
        style: { color: tcToneColor(meta.tone), fontSize: 11.5 },
        onChange: (event: any) => props.onChange(event.target.value),
    }, !WB.TASK_STATUS[task.status] ? h('option', { value: task.status }, meta.label) : null,
    Object.keys(WB.TASK_STATUS).map(key => h('option', { key, value: key }, WB.TASK_STATUS[key].label))));
}
function TaskCenterRow(props?: any): any {
    const task = props.task;
    const data = props.data;
    const expanded = props.expanded;
    const highlighted = props.highlighted;
    const [busy, setBusy] = React.useState<any>(false);
    const [replyOpen,setReplyOpen]=React.useState(false);
    const done = task.status === 'completed' || task.status === 'cancelled';
    const priority = tcPriorityOf(task);
    const due = WB.fmt.due(task.dueAt);
    const projectName = tcProjectName(data, task.projectId);
    const projectColor = tcProjectColor(data, task.projectId);
    const source = tcFindSource(data, task);
    const tags = (Array.isArray(task.tags) ? task.tags : []).filter((tag:string)=>!task.aiExtracted||!/^AI\s*(识别|提取)$/i.test(tag));
    function updateStatus(status: string): any {
        if (busy || status === task.status)
            return;
        setBusy(true);
        WB.actions.updateTask(task.id, { status }).finally(() => setBusy(false)).catch(() => {});
    }
    function toggleDone(): any {
        updateStatus(done ? 'ready' : 'completed');
    }
    async function prepareWithAssistant():Promise<void> {
        if(busy)return;
        setBusy(true);
        const conversationId='task:'+task.id,requestId='task-assist-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);
        WB.assistant.openFor({kind:'task',id:task.id,title:task.title});
        try{
            const result=await WB.actions.assistantHub({action:'operate',conversationId,operation:'office.start',kind:'task_assist',input:{taskId:task.id},text:'整理待办处理方案',requestId});
            if(!['ok','confirmation_required'].includes(result?.status))throw Error(result?.note||'无法确认待办处理方案是否已启动，请在当前会话查看结果');
            if(WB.store.get().assistantConversationId===conversationId)WB.store.set((state:any)=>({assistantOpenSeq:(state.assistantOpenSeq||0)+1}));
        }catch(error){WB.toast(String(error.message||error),'err')}
        finally{setBusy(false)}
    }
    function remove(): any {
        if (busy)
            return;
        const confirmed = window.confirm('删除待办“' + task.title + '”？该操作不可撤销。');
        if (!confirmed)
            return;
        setBusy(true);
        WB.actions.deleteTask(task.id).catch(function (): any {
            setBusy(false);
        });
    }
    return h(React.Fragment, null, h('tr', {
        ref: props.rowRef || undefined,
        className:'wb-task-row'+(props.editing?' is-editing':''),
        'data-task-id':task.id,
        'aria-selected':props.editing?true:undefined,
        tabIndex:0,
        onClick:(event:any)=>{
            if(event.target?.closest?.('button,a,input,select,textarea,label,[role="button"],[role="combobox"]'))return;
            const selection=window.getSelection?.();
            if(selection?.toString()&&selection.anchorNode&&event.currentTarget.contains(selection.anchorNode))return;
            WB.openTaskForm(task);
        },
        onKeyDown:(event:any)=>{
            if(event.target!==event.currentTarget||!['Enter',' '].includes(event.key))return;
            event.preventDefault();WB.openTaskForm(task);
        },
        style: highlighted&&!props.editing
            ? {
                background: 'color-mix(in srgb, ' + T.accent + ' 7%, transparent)',
                boxShadow: 'inset 2px 0 0 ' + T.accent,
            }
            : undefined,
    } , h('td', {className:'wb-task-main'},
    h('button',{type:'button',className:'wb-item-title wb-task-title'+(done?' is-done':''),title:'编辑这条待办',onClick:()=>WB.openTaskForm(task)},task.title),
    h('div',{className:'wb-task-meta'},task.aiExtracted?h(Badge,{tone:'accent'},'AI 提取'):null,
        source&&!['yunzhijia','yunzhijia-calendar'].includes(source.provider)?h(Badge,{tone:'idle'},tcProviderLabel(source.provider)):null,
        task.assignee?h(Badge,{tone:'idle'},task.assignee):null,
        tags.map((tag:string,index:number)=>h('span',{key:tag+':'+index,className:'wb-task-tag'},'#'+tag)),
        h(MessageSelectionBadges,{source:(data.sources||[]).find((s:any)=>s.id===task.sourceRefId),inbox:data.messageInbox})),
    task.description?h('div',{className:'wb-tiny wb-muted wb-task-preview'},task.description):null,
    h(TaskMessageMetadata,{task,data,showTime:false})), h('td', {'data-label':'优先级'}, h(Badge, { tone: priority.tone }, priority.label)), h('td', {'data-label':'状态'}, h(TaskCenterStatusSelect, { task, busy, onChange: updateStatus })), h('td', {'data-label':'完成', style: { width: 56, textAlign: 'center', verticalAlign: 'middle' } }, h('button', {
        type: 'button',
        className: 'wb-check' + (done ? ' is-on' : ''),
        style: { margin: '0 auto' },
        title: done ? '重开（标记为待处理）' : '标记完成',
        'aria-label': (done ? '重开 ' : '完成 ') + task.title,
        disabled: busy,
        onClick: toggleDone,
    }, h(Icon, { name: 'check', size: 11 }))), h('td', {'data-label':'消息时间',className:'wb-tiny',style:{whiteSpace:'nowrap',fontVariantNumeric:'tabular-nums'},title:taskMessageTime(task,data.sources||[])===null?'无原消息时间':messageSentTime(source)},taskMessageTime(task,data.sources||[])===null?h('span',{className:'wb-muted'},'—'):h('time',{dateTime:source.locator.sentAt},messageSentTime(source).replace('（北京时间）',''))), h('td', {'data-label':'截止 / 会议'}, task.dueAt
        ? h('span', { style: { color: tcToneColor(due.tone), fontSize: 11.5, fontWeight: 600 } }, due.text)
        : task.meetingStart ? h('span',{className:'wb-tiny',title:'会议开始'},WB.fmt.datetime(task.meetingStart)) : h('span', { className: 'wb-tiny wb-muted' }, '—')), h('td', {'data-label':'项目'}, projectName
        ? h('div', { className: 'wb-row', style: { gap: 5, minWidth: 0 } }, h('span', {
            style: {
                flex: 'none',
                width: 7,
                height: 7,
                borderRadius: 999,
                background: projectColor || T.text2,
                opacity: projectColor ? 1 : 0.55,
            },
        }), h('span', { className: 'wb-ellipsis', style: { fontSize: 11.5 } }, projectName))
        : h('span', { className: 'wb-tiny wb-muted' }, '—')), h('td', {className:'wb-task-row-actions'}, h('div', { className: 'wb-row', style: { gap: 2, justifyContent: 'flex-end' } }, taskReplyTarget(data,task.id)?h(IconBtn,{name:'chat',label:'回复原会话 '+task.title,onClick:()=>setReplyOpen(!replyOpen)}):null,h(IconBtn, {
        name: expanded ? 'chevronDown' : 'chevronRight',
        label: expanded ? '收起来源证据' : '展开来源证据',
        onClick: props.onToggleEvidence,
    }), h(IconBtn, {
        name: 'edit',
        label: '编辑',
        onClick: function (): any {
            WB.openTaskForm(task);
        },
    }), h(IconBtn, { name: 'trash', label: '删除', onClick: remove, disabled: busy })))), replyOpen?h('tr',null,h('td',{colSpan:8,style:{padding:12}},h(TaskReplyPanel,{task,data,initialOpen:true}))):null,expanded
        ? h('tr', null, h('td', {
            colSpan: 8,
            style: {
                padding: '0 12px 12px',
                background: 'color-mix(in srgb, ' + T.accent + ' 3%, transparent)',
            },
        }, task.description?h('div',{className:'wb-task-full-description'},h('strong',null,'任务说明'),h('p',null,task.description)):null,h(Btn, {size:'sm',icon:'agent',disabled:busy,onClick:prepareWithAssistant,children:'AI 整理处理方案'}),h(TaskCenterEvidence, { task: task, data: data })))
        : null);
}
function TaskCenterBoardCard(props?: any): any {
    const task = props.task;
    const data = props.data;
    const [busy, setBusy] = React.useState<any>(false);
    const done = task.status === 'completed' || task.status === 'cancelled';
    const priority = tcPriorityOf(task);
    const due = WB.fmt.due(task.dueAt);
    const projectName = tcProjectName(data, task.projectId);
    const tags = Array.isArray(task.tags) ? task.tags : [];
    function open(): any {
        WB.openTaskForm(task);
    }
    function updateStatus(status: string): any {
        if (busy || status === task.status)
            return;
        setBusy(true);
        WB.actions.updateTask(task.id, { status }).finally(() => setBusy(false)).catch(() => {});
    }
    function toggleDone(): any {
        updateStatus(done ? 'ready' : 'completed');
    }
    return h('div', {
        role: 'button',
        className:'wb-task-board-card'+(props.editing?' is-editing':''),
        'data-task-id':task.id,
        'aria-current':props.editing?'true':undefined,
        tabIndex: 0,
        onClick: open,
        onKeyDown: function (event?: any): any {
            /* 卡片内的状态选择和勾选按钮自己处理键盘。 */
            if (event.target !== event.currentTarget)
                return;
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                open();
            }
        },
        title: '编辑“' + task.title + '”',
        style: {
            display: 'flex',
            flexDirection: 'column',
            gap: 5,
            minWidth: 0,
            padding: '8px 9px',
            border: '1px solid ' + T.border1,
            borderRadius: 11,
            background: props.editing?undefined:T.layer2,
            cursor: 'pointer',
        },
    }, h('div', { className: 'wb-row', style: { alignItems: 'flex-start', gap: 6 } }, h('span', { className: 'wb-item-title' + (done ? ' is-done' : ''), style: { fontSize: 12, lineHeight: 1.45 } }, task.title)), h('div', { className: 'wb-item-sub', style: { marginTop: 0, gap: 5 } }, h(Badge, { tone: priority.tone }, priority.label), task.dueAt ? h('span', { style: { color: tcToneColor(due.tone), fontWeight: 600 } }, due.text) : null, projectName ? h('span', { className: 'wb-ellipsis', style: { maxWidth: 110 } }, projectName) : null), tags.length > 0
        ? h('div', { className: 'wb-row wb-row--wrap', style: { gap: 3 } }, tags.slice(0, 3).map(function (tag?: any, index?: any): any {
            return h('span', { key: tag + ':' + index, className: 'wb-tiny wb-muted' }, '#' + tag);
        }))
        : null,h(MessageSelectionBadges,{source:(data.sources||[]).find((s:any)=>s.id===task.sourceRefId),inbox:data.messageInbox}),h(TaskMessageMetadata,{task,data}), h('div', {
            className: 'wb-row',
            style: { gap: 8, marginTop: 3 },
            onClick: (event: any) => event.stopPropagation(),
        }, h(TaskCenterStatusSelect, { task, busy, onChange: updateStatus }), h('button', {
        type: 'button',
        className: 'wb-check' + (done ? ' is-on' : ''),
        style: { width: 14, height: 14, marginTop: 2 },
        title: done ? '重开' : '标记完成',
        'aria-label': (done ? '重开 ' : '完成 ') + task.title,
        disabled: busy,
        onClick: toggleDone,
    }, h(Icon, { name: 'check', size: 10 }))),h(TaskReplyPanel,{task,data}));
}
function TaskCenterPage(): any {
    const state = WB.useStore();
    const data = state.data;
    const editingId=state.taskForm?.open&&!state.contextHidden&&!state.assistantOpen?state.taskForm.task?.id:null;
    const [page,setPage]=React.useState(0);
    const [view, setView] = React.useState<any>('list');
    const [filtersOpen,setFiltersOpen]=React.useState(false);
    const [search, setSearch] = React.useState<any>('');
    const [status, setStatus] = React.useState<any>('all');
    const [dueFilter, setDueFilter] = React.useState<any>('all');
    const [messageFrom,setMessageFrom]=React.useState('');
    const [messageTo,setMessageTo]=React.useState('');
    const [sortOrder,setSortOrder]=React.useState('default');
    const [priority, setPriority] = React.useState<any>('all');
    const [projectId, setProjectId] = React.useState<any>('all');
    const [tag, setTag] = React.useState<any>(null);
    const [expandedId, setExpandedId] = React.useState<any>(null);
    const [showAllTags, setShowAllTags] = React.useState<any>(false);
    const [pendingFocusId, setPendingFocusId] = React.useState<any>(null);
    const [candidateBusy, setCandidateBusy] = React.useState<any>(false);
    const [dragStatus, setDragStatus] = React.useState<any>(null);
    // Reply 在独立页面维护，任务中心只筛选实际事项类型。
    const [typeFilter, setTypeFilter] = React.useState<any>('all');
    React.useEffect(()=>{if(!pendingFocusId&&!state.focusTaskId)setPage(0)},[search,status,dueFilter,priority,projectId,tag,typeFilter,messageFrom,messageTo,sortOrder]);
    const focusRowRef = React.useRef<any>(null);
    const preset = state.taskPreset;
    const focusId = state.focusTaskId;
    React.useEffect(function (): any {
        if (!preset)
            return;
        WB.store.set({ taskPreset: null });
        if (preset.typeFilter)
            setTypeFilter(preset.typeFilter);
        if (preset.status)
            setStatus(preset.status);
        if (preset.dueFilter)
            setDueFilter(preset.dueFilter);
        if (preset.priority)
            setPriority(preset.priority);
        if (preset.projectId)
            setProjectId(preset.projectId);
        if (preset.view)
            setView(preset.view);
    }, [preset]);
    React.useEffect(function (): any {
        if (!focusId)
            return;
        /* Filters would hide the requested task, so reveal it in a clean view. */
        setView('list');
        setStatus('all');
        setDueFilter('all');
        setMessageFrom('');setMessageTo('');setSortOrder('default');
        setPriority('all');
        setProjectId('all');
        setTypeFilter('all');
        setTag(null);
        setSearch('');
        setExpandedId(focusId);
        setPendingFocusId(focusId);
        const ordered = tcSortTasks((data?.tasks || []).filter((row:any)=>!row.archivedAt));
        setPage(Math.floor(Math.max(0, ordered.findIndex((row:any)=>row.id===focusId))/PAGE_SIZE));
        WB.store.set({ focusTaskId: null });
    }, [focusId]);
    React.useEffect(function (): any {
        if (!pendingFocusId)
            return undefined;
        const timer = setTimeout(function (): any {
            const node = focusRowRef.current;
            if (node && typeof node.scrollIntoView === 'function') {
                try {
                    node.scrollIntoView({ block: 'center', behavior: 'smooth' });
                }
                catch (e) {
                    node.scrollIntoView();
                }
            }
            setPendingFocusId(null);
        }, 60);
        return function (): any {
            clearTimeout(timer);
        };
    }, [pendingFocusId, view]);
    if (!data) {
        return h('div', { className: 'wb-page' }, h('div', { className: 'wb-row', style: { gap: 9, color: T.text2, padding: '10px 0' } }, h(Spinner, { size: 16 }), h('span', null, '正在读取任务…')));
    }
    const tasks = Array.isArray(data.tasks) ? data.tasks.filter((row:any)=>!row.archivedAt) : [];
    const projects = Array.isArray(data.projects) ? data.projects : [];
    const counts = WB.taskCounts(data);
    const filterBase = tcFilterList(tasks, {
        query: search,
        priority: priority,
        projectId: projectId,
        tag: tag,
        dueFilter: dueFilter,
        sources:data.sources||[],messageFrom,messageTo,
        status: 'all',
    });
    const dutyTypeFilter = function (task?: any): any {
        if (typeFilter !== 'all' && task.eventType !== typeFilter)
            return false;
        return true;
    };
    const visible = tcSortTasks(tcFilterList(filterBase, { status: status }),sortOrder,data.sources||[]).filter(dutyTypeFilter);
    const tabCounts = tcTabCounts(filterBase);
    const tagCounts = tcTagCounts(tasks);
    const activeTagCount = tag && !tagCounts.some(function (item?: any): any {
        return item.tag === tag;
    })
        ? [{ tag: tag, count: 0 }]
        : [];
    const tagList = activeTagCount.concat(tagCounts);
    const tagsShown = showAllTags ? tagList : tagList.slice(0, 8);
    const filtersActive = search.trim().length > 0 ||
        status !== 'all' ||
        dueFilter !== 'all' ||
        priority !== 'all' ||
        projectId !== 'all' ||
        !!tag || typeFilter !== 'all' || !!messageFrom || !!messageTo || sortOrder!=='default';
    const projectOptions = [{ value: 'all', label: '全部项目' }, { value: 'none', label: '未归属项目' }].concat(projects.map(function (project?: any): any {
        return { value: project.id, label: project.name };
    }));
    const tabItems: any = [
        { value: 'all', label: '全部', count: tabCounts.all },
        { value: 'open', label: '未完成', count: tabCounts.open },
        { value: 'ready', label: '待处理', count: tabCounts.ready },
        { value: 'running', label: '执行中', count: tabCounts.running },
        { value: 'completed', label: '已完成', count: tabCounts.completed },
    ];
    const dueOptions: any = [
        { value: 'all', label: '全部时间' },
        { value: 'overdue', label: '已逾期' },
        { value: 'today', label: '今日到期' },
        { value: 'week', label: '7 天内' },
    ];
    const priorityOptions: any = [
        { value: 'all', label: '全部' },
        { value: 'urgent', label: '紧急' },
        { value: 'high', label: '高' },
        { value: 'normal', label: '普通' },
        { value: 'low', label: '低' },
    ];
    function resetFilters(): any {
        setSearch('');
        setStatus('all');
        setDueFilter('all');
        setMessageFrom('');setMessageTo('');setSortOrder('default');
        setPriority('all');
        setProjectId('all');
        setTypeFilter('all');
        setTag(null);
    }
    function newTask(): any {
        WB.openTaskForm(null);
    }
    const typeOptions=[{value:'all',label:'全部'},{value:'meeting',label:'会议'},{value:'feature',label:'功能开发'},{value:'logging',label:'登记填报'},{value:'other',label:'其他'}];
    const applied:any[]=[];
    if(dueFilter!=='all')applied.push({label:'到期：'+dueOptions.find((o:any)=>o.value===dueFilter)?.label,clear:()=>setDueFilter('all')});
    if(priority!=='all')applied.push({label:'优先级：'+priorityOptions.find((o:any)=>o.value===priority)?.label,clear:()=>setPriority('all')});
    if(projectId!=='all')applied.push({label:'项目：'+(projectOptions.find((o:any)=>o.value===projectId)?.label||'已移除项目'),clear:()=>setProjectId('all')});
    if(typeFilter!=='all')applied.push({label:'类型：'+typeOptions.find(o=>o.value===typeFilter)?.label,clear:()=>setTypeFilter('all')});
    if(tag)applied.push({label:'标签：'+tag,clear:()=>setTag(null)});
    if(messageFrom||messageTo)applied.push({label:'消息日期：'+(messageFrom||'不限')+' 至 '+(messageTo||'不限'),clear:()=>{setMessageFrom('');setMessageTo('');}});
    const choices=(options:any[],value:any,setValue:any)=>h('div',{className:'wb-row wb-row--wrap',style:{gap:6}},options.map(option=>h(Chip,{key:option.value,active:value===option.value,onClick:()=>setValue(option.value),children:option.label})));
    const group=(label:string,content:any)=>h('div',{className:'wb-task-filter-group'},h('span',{className:'wb-label'},label),content);
    const filterBar=h(Panel,{className:'wb-task-filters',style:{marginBottom:14},bodyStyle:{padding:'12px 14px'}},h('div',{className:'wb-stack',style:{gap:12}},
        h('div',{className:'wb-task-filter-toolbar'},
            h('div',{className:'wb-task-filter-search'},h(Input,{value:search,placeholder:'搜索标题、描述或标签','aria-label':'搜索待办',style:{paddingLeft:28},onChange:(e:any)=>setSearch(e.target.value)}),h('span',{style:{position:'absolute',left:9,top:8,color:T.text2,pointerEvents:'none'}},h(Icon,{name:'search',size:13}))),
            h('div',{style:{width:172,maxWidth:'100%'}},h(Select,{'aria-label':'待办排序',value:sortOrder,options:[{value:'default',label:'默认排序'},{value:'message-newest',label:'消息时间：最新在前'},{value:'message-oldest',label:'消息时间：最早在前'}],onChange:(e:any)=>setSortOrder(e.target.value)})),
            h('button',{type:'button',className:'wb-btn wb-btn--ghost','aria-expanded':filtersOpen,'aria-controls':'wb-task-advanced',onClick:()=>setFiltersOpen(!filtersOpen)},h(Icon,{name:'filter',size:13}),'筛选'+(applied.length?' · '+applied.length:'')),
            filtersActive?h(Btn,{size:'sm',kind:'subtle',onClick:resetFilters,children:'重置筛选'}):null),
        h('div',{className:'wb-task-filter-summary'},h(Tabs,{items:tabItems,value:status,onChange:setStatus}),filtersActive?h('span',{className:'wb-tiny wb-muted'},'筛选结果 '+visible.length+' 条'):null),
        applied.length?h('div',{className:'wb-task-applied','aria-label':'已选筛选条件'},applied.map(item=>h('button',{key:item.label,type:'button',className:'wb-chip is-active','aria-label':'移除筛选：'+item.label,onClick:item.clear},item.label,h(Icon,{name:'close',size:12})))):null,
        h('div',{id:'wb-task-advanced',className:'wb-task-advanced',hidden:!filtersOpen},
            group('到期',choices(dueOptions,dueFilter,setDueFilter)),group('优先级',choices(priorityOptions,priority,setPriority)),
            group('项目',h(Select,{'aria-label':'筛选项目',options:projectOptions,value:projectId,onChange:(e:any)=>setProjectId(e.target.value)})),
            group('事项类型',choices(typeOptions,typeFilter,setTypeFilter)),
            group('消息发出时间（北京时间）',h('div',{className:'wb-row wb-row--wrap'},h('label',{className:'wb-row wb-tiny'},'从',h(Input,{type:'date','aria-label':'消息发出日期起始',value:messageFrom,max:messageTo||undefined,style:{width:148},onChange:(e:any)=>setMessageFrom(e.target.value)})),h('label',{className:'wb-row wb-tiny'},'至',h(Input,{type:'date','aria-label':'消息发出日期截止',value:messageTo,min:messageFrom||undefined,style:{width:148},onChange:(e:any)=>setMessageTo(e.target.value)})),messageFrom&&messageTo&&messageFrom>messageTo?h('span',{role:'alert',className:'wb-tiny',style:{color:T.err}},'起始日期不能晚于截止日期'):null)),
            tagList.length?group('标签',h('div',{className:'wb-row wb-row--wrap',style:{gap:5}},tagsShown.map((item:any)=>h(Chip,{key:item.tag,active:tag===item.tag,onClick:()=>setTag(tag===item.tag?null:item.tag),children:'#'+item.tag+' · '+item.count})),tagList.length>8?h(Chip,{onClick:()=>setShowAllTags(!showAllTags),children:showAllTags?'收起标签':'更多标签 · '+(tagList.length-8)}):null)):null),
        ));
    let content;
    if (tasks.length === 0) {
        content = h(Panel, { flush: true }, h(Empty, {
            icon: 'tasks',
            title: '还没有待办',
            hint: '从一条手动待办开始；接入云之家后，@ 你的消息经确认也会进入这里，并保留原始来源。',
            action: h(Btn, {
                size: 'sm',
                kind: 'primary',
                icon: 'plus',
                onClick: newTask,
                children: '新建第一条待办',
            }),
        }));
    }
    else if (visible.length === 0) {
        content = h(Panel, { flush: true }, h(Empty, {
            icon: 'search',
            title: '没有匹配的待办',
            hint: '当前搜索与筛选没有命中任何任务；可以清空条件后重试。',
            action: h(Btn, {
                size: 'sm',
                icon: 'xCircle',
                onClick: resetFilters,
                children: '重置筛选',
            }),
        }));
    }
    else if (view === 'board') {
        const boardStatuses = tcBoardStatuses();
        const outside = visible.filter(function (task?: any): any {
            return boardStatuses.indexOf(task.status) < 0;
        });
        content = h('div', null, h('div', {
            style: {
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
                gap: 10,
                alignItems: 'start',
            },
        }, boardStatuses.map(function (key?: any): any {
            const meta = WB.TASK_STATUS[key];
            const columnTasks = visible.filter(function (task?: any): any {
                return task.status === key;
            });
            const dropActive = dragStatus === key;
            return h('div', {
                key: key,
                className: 'wb-card',
                style: dropActive
                    ? { borderColor: T.accent, boxShadow: 'inset 0 0 0 1px ' + T.accent }
                    : undefined,
                onDragOver: function (event?: any): any {
                    event.preventDefault();
                    if (dragStatus !== key)
                        setDragStatus(key);
                },
                onDragLeave: function (event?: any): any {
                    if (event.currentTarget.contains(event.relatedTarget))
                        return;
                    setDragStatus(function (previous?: any): any {
                        return previous === key ? null : previous;
                    });
                },
                onDrop: function (event?: any): any {
                    event.preventDefault();
                    setDragStatus(null);
                    const taskId = event.dataTransfer ? event.dataTransfer.getData('text/plain') : '';
                    if (!taskId)
                        return;
                    const target = visible.find(function (item?: any): any {
                        return item.id === taskId;
                    });
                    if (!target || target.status === key)
                        return;
                    WB.actions
                        .updateTask(taskId, { status: key })
                        .then(function (): any {
                        WB.toast('已移动到「' + meta.label + '」', 'ok');
                    })
                        .catch(function (): any {
                        /* settle() 已提示 */
                    });
                },
            }, h('div', {
                style: {
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '9px 11px',
                    borderBottom: '1px solid ' + T.border1,
                },
            }, h('span', {
                style: {
                    width: 7,
                    height: 7,
                    borderRadius: 999,
                    background: tcToneColor(meta.tone),
                    flex: 'none',
                },
            }), h('span', { style: { fontSize: 12, fontWeight: 600, color: T.text } }, meta.label), h('span', { className: 'wb-spacer' }), h('span', { className: 'wb-tiny wb-muted' }, String(columnTasks.length))), h('div', { style: { display: 'flex', flexDirection: 'column', gap: 7, padding: 8, minHeight: 64 } }, columnTasks.length > 0
                ? columnTasks.map(function (task?: any): any {
                    return h('div', {
                        key: task.id,
                        draggable: true,
                        style: { cursor: 'grab' },
                        title: '拖动到其它列可改状态',
                        onDragStart: function (event?: any): any {
                            if (event.dataTransfer) {
                                event.dataTransfer.setData('text/plain', task.id);
                                event.dataTransfer.effectAllowed = 'move';
                            }
                            setDragStatus(task.status);
                        },
                        onDragEnd: function (): any {
                            setDragStatus(null);
                        },
                    }, h(TaskCenterBoardCard, { task: task, data: data, editing:editingId===task.id }));
                })
                : h('div', { className: 'wb-tiny wb-muted', style: { textAlign: 'center', padding: '12px 0' } }, '暂无任务')));
        })), outside.length > 0
            ? h('div', {
                className: 'wb-row wb-tiny wb-muted wb-row--wrap',
                style: {
                    gap: 8,
                    marginTop: 10,
                    padding: '8px 10px',
                    border: '1px dashed ' + T.border1,
                    borderRadius: 10,
                },
            }, h(Icon, { name: 'info', size: 12 }), h('span', null, '另有 ' + outside.length + ' 条（草稿 / 失败 / 已取消）不在四个看板列中。'), h('div', { className: 'wb-spacer' }), h(Btn, {
                size: 'sm',
                kind: 'subtle',
                icon: 'tasks',
                onClick: function (): any {
                    setView('list');
                },
                children: '用列表查看',
            }))
            : null);
    }
    else {
        content = h('div', { className: 'wb-card wb-task-table', role: 'region', 'aria-label': '任务列表，可横向滚动查看操作', tabIndex: 0 }, h('table', { className: 'wb-table' }, h('colgroup',null,h('col'),...[70,116,58,168,110,110,98].map((width,index)=>h('col',{key:index,style:{width}}))),h('thead', null, h('tr', null, h('th', null, '任务'), h('th', null, '优先级'), h('th', null, '状态'), h('th', { style: { textAlign: 'center' } }, '完成'), h('th', {scope:'col','aria-sort':sortOrder==='message-newest'?'descending':sortOrder==='message-oldest'?'ascending':'none',style:{fontVariantNumeric:'tabular-nums'}},h('button',{type:'button','aria-label':'按消息发出时间排序',title:'点击切换最新 / 最早在前（北京时间）',onClick:()=>setSortOrder(sortOrder==='message-newest'?'message-oldest':'message-newest'),style:{display:'inline-flex',alignItems:'center',gap:5,border:0,padding:0,background:'transparent',font:'inherit',color:'inherit',cursor:'pointer'}},'消息发出时间',h('span',{'aria-hidden':true},sortOrder==='message-newest'?'↓':sortOrder==='message-oldest'?'↑':'↕'))), h('th', null, '截止 / 会议开始'), h('th', null, '项目'), h('th', { style: { textAlign: 'right' } }, '操作'))), h('tbody', null, visible.slice(pageIndex(page,visible.length)*PAGE_SIZE,(pageIndex(page,visible.length)+1)*PAGE_SIZE).map(function (task?: any): any {
            const isPending = pendingFocusId === task.id;
            return h(TaskCenterRow, {
                key: task.id,
                task: task,
                data: data,
                expanded: expandedId === task.id,
                highlighted: isPending || expandedId === task.id,
                editing:editingId===task.id,
                rowRef: isPending ? focusRowRef : null,
                onToggleEvidence: function (): any {
                    setExpandedId(expandedId === task.id ? null : task.id);
                },
            });
        }))));
    }
    // ---- AI 任务提取的「待确认」区（设计报告 §3.2：低置信度只做候选，人工确认后才建任务）
    const allCandidates = Array.isArray(data && data.candidates) ? data.candidates : [];
    const pendingCandidates = allCandidates.filter(function (candidate?: any): any {
        return candidate && candidate.status === 'pending';
    });
    const lastExtract = data && data.lastExtract ? data.lastExtract : null;
    function runExtract(): any {
        if (candidateBusy)
            return;
        setCandidateBusy(true);
        WB.actions
            .extractCandidates()
            .then(function (): any {
            setCandidateBusy(false);
        })
            .catch(function (): any {
            setCandidateBusy(false);
        });
    }
    function acceptCandidateItem(candidate?: any): any {
        if (candidateBusy)
            return;
        setCandidateBusy(true);
        WB.actions
            .acceptCandidate(candidate.id, {})
            .then(function (): any {
            setCandidateBusy(false);
        })
            .catch(function (): any {
            setCandidateBusy(false);
        });
    }
    function rejectCandidateItem(candidate?: any): any {
        if (candidateBusy)
            return;
        setCandidateBusy(true);
        WB.actions
            .rejectCandidate(candidate.id)
            .then(function (): any {
            setCandidateBusy(false);
        })
            .catch(function (): any {
            setCandidateBusy(false);
        });
    }
    const candidatesPanel = h(Panel, {
        icon: 'sparkles',
        title: '待确认',
        sub: pendingCandidates.length > 0
            ? '规则从 @我 消息里提取的候选，共 ' + pendingCandidates.length + ' 条；采纳后才变成待办'
            : lastExtract && lastExtract.at
                ? '上次提取 ' + WB.fmt.relative(lastExtract.at) + ' · 新增 ' + (lastExtract.added || 0) + ' 条'
                : '从未读、@本人、@全员消息里提取候选，人工确认后才建待办',
        badge: pendingCandidates.length > 0 ? h(Badge, { tone: 'warn' }, String(pendingCandidates.length)) : null,
        actions: h(Btn, {
            size: 'sm',
            kind: 'subtle',
            icon: 'sparkles',
            disabled: candidateBusy,
            onClick: runExtract,
            children: candidateBusy ? '处理中…' : '提取候选',
        }),
    }, pendingCandidates.length === 0
        ? h(Empty, {
            style: { padding: '16px 12px 14px' },
            icon: 'checkCircle',
            title: '没有待确认的候选',
            hint: '先在首页刷新「消息与会议」，再点右上角「提取候选」。规则只做确定性判断（行动词 / 时间线索 / 长度 / 指向性），置信度可解释；采纳前请人工核对。',
        })
        : h('div', { className: 'wb-list' }, pendingCandidates.slice(0, 8).map(function (candidate?: any): any {
            const due = candidate.dueAt ? WB.fmt.due(candidate.dueAt) : null;
            return h('div', { key: candidate.id, className: 'wb-item', style: { alignItems: 'flex-start' } }, h('div', { className: 'wb-item-main' }, h('div', { className: 'wb-item-title', style: { display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' } }, candidate.title, candidate.confidence !== null && candidate.confidence !== undefined
                ? h(Badge, { tone: candidate.confidence >= 0.7 ? 'ok' : candidate.confidence >= 0.5 ? 'warn' : 'idle' }, '置信度 ' + Math.round(candidate.confidence * 100) + '%')
                : null, due ? h(Badge, { tone: due.tone }, due.text) : null), h('div', { className: 'wb-item-sub wb-clamp2' }, candidate.excerpt || ''), h('div', { className: 'wb-item-sub' }, candidate.sourceTitle ? h('span', null, candidate.sourceTitle) : null, (candidate.reasons || []).slice(0, 2).map(function (reason?: any, index?: any): any {
                return h(Chip, { key: 'r' + index, children: reason });
            }))), h('div', { className: 'wb-item-actions', style: { opacity: 1 } }, h(Btn, {
                size: 'sm',
                kind: 'primary',
                icon: 'check',
                disabled: candidateBusy,
                onClick: function (): any {
                    acceptCandidateItem(candidate);
                },
                children: '采纳',
            }), h(Btn, {
                size: 'sm',
                kind: 'subtle',
                icon: 'close',
                disabled: candidateBusy,
                onClick: function (): any {
                    rejectCandidateItem(candidate);
                },
                children: '忽略',
            }), h(IconBtn, {
                name: 'trash',
                label: '彻底删除这条候选',
                onClick: function (): any {
                    if (!window.confirm('彻底删除这条候选记录？'))
                        return;
                    WB.actions.deleteCandidate(candidate.id).catch(function (): any { });
                },
            })));
        })));
    return h('div', {className:'wb-task-center'}, h(PageHead, {
        icon: 'tasks',
        title: '任务中心',
        sub: '共 ' +
            counts.total +
            ' 条 · 未完成 ' +
            counts.open +
            ' · 逾期 ' +
            counts.overdue +
            ' · 执行中 ' +
            counts.running,
        actions: h('div', { className: 'wb-row wb-row--wrap', style: { gap: 8 } }, h(WorkspaceRefresh,{scope:'tasks'}),h(Segmented, {
            items: [
                { value: 'list', label: '列表' },
                { value: 'board', label: '看板' },
            ],
            value: view,
            onChange: function (value?: any): any {
                setView(value);
            },
        }), h(Btn, {
            size: 'sm',
            kind: 'primary',
            icon: 'plus',
            onClick: newTask,
            children: '新建待办',
        })),
    }), tasks.length > 0 ? filterBar : null, content, view==='list'?h(Pagination,{page,total:visible.length,onChange:setPage}):null, h('details',{style:{marginTop:16}},h('summary',{className:'wb-tiny wb-muted'},'规则候选（备用） · '+pendingCandidates.length+' 条'),candidatesPanel));
}
WB.pages.tasks = TaskCenterPage;

export { tcToneColor, tcPriorityOf, tcDueValue, tcEndOfToday, tcProjectName, tcProjectColor, tcProviderLabel, tcFindSource, tcBoardStatuses, tcSortTasks, tcFilterList, tcTabCounts, tcTagCounts, TaskCenterEvidence, TaskCenterRow, TaskCenterBoardCard, TaskCenterPage }
