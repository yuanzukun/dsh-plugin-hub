import { ContextFormPane } from '../../components/ContextFormPane.js'
import { TaskEventFields } from '../../components/TaskEventFields.js'
import {TaskReplyPanel} from './TaskReplyPanel.js'
import { Btn, Field, Icon, Input, Modal, Select, T, Textarea, Toggle, WB, h, useStore, wbStore } from '../../core/runtime.js'
import * as React from 'react'
/* ============================================================================
 * dev-workbench shared task form
 *
 * One form for every entry point (toolbar quick-add, task center, dashboard,
 * focus view). The open state lives in the store as `taskForm`, so any module
 * can call `WB.openTaskForm(task)` without owning the dialog.
 *
 * Field rules come from the design report §3.2: a task keeps its source
 * evidence, and a due date / assignee produced by extraction is labelled as a
 * guess rather than presented as fact.
 * ========================================================================== */
const taskFormToLocalInput = WB.fmt.toLocalInput;
const taskFormFromLocalInput = WB.fmt.fromLocalInput;
function TaskFormHost(props?: {embedded?:boolean}): any {
    const state = useStore();
    const request = state.taskForm;
    const task = request && request.task ? request.task : null;
    const defaults = request && request.defaults ? request.defaults : {};
    const data = state.data;
    const [title, setTitle] = React.useState<any>('');
    const [description, setDescription] = React.useState<any>('');
    const [priority, setPriority] = React.useState<any>('normal');
    const [status, setStatus] = React.useState<any>('ready');
    const [dueInput, setDueInput] = React.useState<any>('');
    const [projectId, setProjectId] = React.useState<any>('');
    const [tags, setTags] = React.useState<any>('');
    const [assignee, setAssignee] = React.useState<any>('');
    const [needsReply, setNeedsReply] = React.useState<any>(false);
    const [replyStage, setReplyStage] = React.useState<any>('待答复');
    const [busy, setBusy] = React.useState<any>(false);
    const [error, setError] = React.useState<any>(null);
    const [eventFields, setEventFields] = React.useState<any>({eventType:'',deliverable:'',meetingStart:'',meetingEnd:'',meetingLocation:'',registrationTarget:''});
    React.useEffect(function (): any {
        if (!request)
            return;
        setTitle(task ? task.title : defaults.title || '');
        setDescription(task ? task.description || '' : defaults.description || '');
        setPriority(task ? task.priority || 'normal' : defaults.priority || 'normal');
        setStatus(task ? task.status || 'ready' : defaults.status || 'ready');
        setDueInput(taskFormToLocalInput(task ? task.dueAt : defaults.dueAt));
        setProjectId(task ? task.projectId || '' : defaults.projectId || '');
        setTags(task ? (task.tags || []).join(', ') : (defaults.tags || []).join(', '));
        setAssignee(task ? task.assignee || '' : defaults.assignee || '');
        setNeedsReply(task ? task.needsReply === true : false);
        setReplyStage(task && task.replyStage ? task.replyStage : '待答复');
        setEventFields(Object.fromEntries(['eventType','deliverable','meetingStart','meetingEnd','meetingLocation','registrationTarget'].map(key=>[key,task&&task[key]||''])));
        setError(null);
        setBusy(false);
    }, [request]);
    if (!request)
        return null;
    function close(): any {
        wbStore.set({ taskForm: null });
    }
    function submit(event?: any): any {
        if (event)
            event.preventDefault();
        const trimmed = title.trim();
        if (!trimmed) {
            setError('标题不能为空');
            return;
        }
        const payload: any = {
            title: trimmed,
            description: description.trim(),
            priority: priority,
            status: status,
            dueAt: task && dueInput === taskFormToLocalInput(task.dueAt)
                ? task.dueAt || null
                : taskFormFromLocalInput(dueInput),
            projectId: projectId || null,
            tags: task && tags === (task.tags || []).join(', ') ? [...(task.tags || [])] : tags
                .split(/[,，\s]+/)
                .map(function (tag?: any): any {
                return tag.trim();
            })
                .filter(Boolean),
            assignee: assignee.trim() || null,
            needsReply: needsReply === true,
            replyStage: null,
            ...eventFields,
            eventType: eventFields.eventType || null,
        };
        setBusy(true);
        setError(null);
        const operation = task ? WB.actions.updateTask(task.id, payload) : WB.actions.createTask(payload);
        operation
            .then(function (): any {
            setBusy(false);
            close();
        })
            .catch(function (e?: any): any {
            setBusy(false);
            setError(String((e && e.message) || e));
        });
    }
    const projects = (data && data.projects) || [];
    const projectOptions = [{ value: '', label: '未归属项目' }].concat(projects.map(function (project?: any): any {
        return { value: project.id, label: project.name };
    }));
    const statusOptions = Object.keys(WB.TASK_STATUS).map(function (key?: any): any {
        return { value: key, label: WB.TASK_STATUS[key].label };
    });
    const priorityOptions = ['urgent', 'high', 'normal', 'low'].map(function (key?: any): any {
        return { value: key, label: WB.TASK_PRIORITY[key].label };
    });
    const embedded = props?.embedded && request.presentation !== 'modal';
    const Container = embedded ? ContextFormPane : Modal;
    return h(Container, {
        open: !state.assistantOpen && !state.contextHidden,
        title: task ? embedded ? task.title : '编辑待办' : '新建待办',
        ariaLabel: task ? '编辑待办' : '新建待办',
        sub: task ? embedded ? null : task.title : '明确的事实与推测分开记录',
        onClose: close,
        width: 560,
        footer: h(React.Fragment, null, h(Btn, {
            kind: 'primary',
            disabled: busy,
            onClick: submit,
            children: busy ? '保存中…' : task ? '保存' : '创建待办',
        }), h(Btn, { onClick: close, children: '取消' })),
    }, h('form', { onSubmit: submit, className: 'wb-stack', style: { gap: 12 } }, h(Field, { label: '标题' }, h(Input, {
        value: title,
        autoFocus: true,
        placeholder: '例如：评审 @张三 提到的网关限流方案',
        onChange: function (event?: any): any {
            setTitle(event.target.value);
        },
    })), h(Field, { label: '描述', hint: '保留原始上下文，后续 Agent 读取的就是这段内容' }, h(Textarea, {
        value: description,
        placeholder: '背景、期望结果、相关链接…',
        onChange: function (event?: any): any {
            setDescription(event.target.value);
        },
    })), h('div', { className: 'wb-task-form-grid' }, h(Field, { label: '状态' }, h(Select, {
        options: statusOptions,
        value: status,
        onChange: function (event?: any): any {
            setStatus(event.target.value);
        },
    })), h(Field, { label: '优先级' }, h(Select, {
        options: priorityOptions,
        value: priority,
        onChange: function (event?: any): any {
            setPriority(event.target.value);
        },
    })), h(Field, { label: '截止时间' }, h(Input, {
        type: 'datetime-local',
        value: dueInput,
        onChange: function (event?: any): any {
            setDueInput(event.target.value);
        },
    })), h(Field, { label: '项目' }, h(Select, {
        options: projectOptions,
        value: projectId,
        onChange: function (event?: any): any {
            setProjectId(event.target.value);
        },
    })), h(Field, { label: '标签', hint: '逗号或空格分隔' }, h(Input, {
        value: tags,
        placeholder: '后端, 限流',
        onChange: function (event?: any): any {
            setTags(event.target.value);
        },
    })), h(Field, { label: '负责人', hint: '抽取得到的负责人属于推测，需人工确认' }, h(Input, {
        value: assignee,
        placeholder: '留空表示未指派',
        onChange: function (event?: any): any {
            setAssignee(event.target.value);
        },
    })), null, null), h(TaskEventFields, {value:eventFields,onChange:setEventFields}), task&&data?h(TaskReplyPanel,{key:task.id,task,data}):null, task && task.aiExtracted
        ? h('div', {
            style: {
                display: 'flex',
                gap: 8,
                alignItems: 'flex-start',
                padding: '8px 10px',
                borderRadius: 10,
                background: 'var(--dsw-alias-bg-layer-2)',
                fontSize: 11.5,
                color: T.text2,
            },
        }, h(Icon, { name: 'sparkles', size: 13 }), h('span', null, '这条待办由 AI 从消息中提取（置信度 ' +
            (task.confidence === null || task.confidence === undefined
                ? '未评估'
                : Math.round(task.confidence * 100) + '%') +
            '）。保存即确认，字段以你为准。'))
        : null, error ? h('div', { role: 'alert', style: { color: T.err, fontSize: 12 } }, error) : null, h('button', { type: 'submit', style: { display: 'none' } })));
}
WB.TaskForm = TaskFormHost;
WB.TaskFormHost = TaskFormHost;

export { taskFormToLocalInput, taskFormFromLocalInput, TaskFormHost }
