/* ============================================================================
 * 放置 —— 把背包里的方块放到某个坐标（`mc_act {mode:"place"}` / `mc_build` 的正文）
 *
 * 路线图第 ④ 条第三十九刀从 `src\core.mjs` 搬出来（`#placeRef` + `placeBlock`）。
 * 六条判据（都是 2026-10-08 那几轮实机换来的）：
 *   ① 选料只挑**整方块**（`pickPlaceItem`）：火把/门/半砖放下去站不住，别当填充块
 *   ② 创造模式背包没有就自动取（协议级 `set_creative_slot`，不需要 OP）
 *   ③ 够不着先走近（`self.walkTo` / 创造 `self.flyTo`）；接近失败**不许吞** ——
 *      服务端按**眼睛→方块中心** 4.5（生存）/ 5.0（创造）判，超了直接报"够不着"
 *   ④ 目标格必须 `canPlaceInto`（空气/液体/草花藤蔓）；悬空就先垫一块踩上去（"搭高"）
 *   ⑤ 上游 `place_block.js` 抛的英文 `Server refused to place …` 翻译成人话
 *   ⑥ 放完**必须复核** `b.blockAt`：旧版不管成没成都报 `placed`，真机被投诉"报假成功"
 *
 * 参数：`self` = McBot（读 `requireBot` / `giveItem` / `walkTo` / `flyTo` / `equip`，
 *       写 `_selfMovingAt`），`ctx` = `{ t }`（预算闸门 `#t`，唯一的私有件）。
 * 判据：模块不 import `core.mjs`、不 import 游戏库（只认 `b.blockAt` / `b.placeBlock` / `b.lookAt` / `b.entity`）。
 * ========================================================================== */

import vec3pkg from 'vec3'
const Vec3 = vec3pkg.Vec3 ?? vec3pkg

import { sleep } from './async-util.mjs'
import { isAir, isLiquid, canPlaceInto, isEntityItem } from './block-names.mjs'
import { pickPlaceItem, isFullBlockItem } from './place-items.mjs'
import { heldText } from './inventory.mjs'
import { standableY } from './movement.mjs'

/**
 * 在目标周围找一块**能站的地面**当落脚点（"走过去放"用）。找不到返回 `null`。
 *
 * 🔴 为什么不能直接朝 `pos.y` 走（用户 2026-10-13 实机报的"搭路一直搭到空气上"）：
 *    搭桥 / 搭高的目标 y 本来就在半空，而 `mc_map`/`mc_scan` 给的"地表高度"在树林里是树冠、
 *    山上是最高的石头 —— 朝那个 y 走过去，pathfinder 会一路**垫方块把自己顶上去**。
 *    改成"站到目标旁边的地面上，再伸手放"。
 */
function approachSpot (b, pos) {
  const cands = []
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      if (!dx && !dz) continue
      const x = pos.x + dx; const z = pos.z + dz
      const y = standableY(b, x, pos.y + 2, z)
      // `standableY` 找不到能站的地方会**原样返回**传进去的 y ⇒ 那种"半空"不算落脚点
      let under = null
      try { under = b.blockAt(new Vec3(x, y - 1, z)) } catch { under = null }
      if (!under || isAir(under.name) || isLiquid(under.name)) continue
      const d = Math.hypot(x + 0.5 - (pos.x + 0.5), y - pos.y, z + 0.5 - (pos.z + 0.5))
      if (d > 6.5) continue
      cands.push({ x, y, z, d })
    }
  }
  cands.sort((a, c) => a.d - c.d)
  return cands[0] ?? null
}

/** 找一个能对着放的相邻实体方块 */
export function placeRef (self, pos) {
  const b = self.requireBot()
  for (const [dx, dy, dz] of [[0, -1, 0], [0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
    const nb = b.blockAt(new Vec3(pos.x + dx, pos.y + dy, pos.z + dz))
    if (nb && nb.boundingBox === 'block') return { ref: nb, face: { x: -dx, y: -dy, z: -dz } }
  }
  return null
}

/**
 * 「跳起来再放」—— **原地搭高**的标准做法。
 *
 * 🔴 为什么必须先跳（用户 2026-10-17 报的「一直尝试放方块」）：
 *    想在自己脚下垫一块时，落点 `underFeet.position + (0,1,0)` 恰好是
 *    **机器人自己站着的那一格**。服务端不会把方块放进玩家身体里 ⇒ 必拒。
 *    站着放 = 每一轮都失败，而且上游抛的是英文
 *    （`mineflayer/lib/plugins/place_block.js:42` 的 `Server refused to place … the block is still air`），
 *    模型看不懂"报的坐标是我自己站的地方"，只会一遍遍重试同一个点位
 *    （用户的 AI 后来自己总结成「服务端不让在脚底下放」，只好改去挖台阶）。
 *    脚离地之后那一格就空了，才放得进去。
 *
 * 用"等真的离地"而不是死等固定毫秒：跳跃的滞空窗口只有几百毫秒，
 * 而 `bot.placeBlock` 内部还要先 `await bot.lookAt(...)` 再发包（`generic_place.js:37`）。
 */
export async function placeWhileJumping (b, refBlock, face, { tries = 3 } = {}) {
  let lastErr = null
  try { b.setControlState('jump', true) } catch {}
  try {
    for (let i = 0; i < tries; i++) {
      // 等脚真的离开整格（`position.y` 的小数部分不再是 0）
      const t0 = Date.now()
      while (Date.now() - t0 < 700) {
        const y = b.entity?.position?.y
        if (typeof y === 'number' && y - Math.floor(y) > 0.05) break
        await sleep(20)
      }
      try {
        await b.placeBlock(refBlock, new Vec3(face.x, face.y, face.z))
        return true
      } catch (e) { lastErr = e }
      await sleep(120)   // 落地了再跳一次
    }
    throw lastErr ?? new Error('跳起来也没放上')
  } finally {
    try { b.setControlState('jump', false) } catch {}
  }
}

/** 把背包里的方块放到某个坐标（先走近、必要时往上搭） */
export async function placeBlock (self, { x, y, z, name = null } = {}, ctx = {}) {
  const b = self.requireBot()
  const pos = new Vec3(Math.floor(x), Math.floor(y), Math.floor(z))
  const want = name ? String(name) : null
  /* 🔴 船 / 矿车 / 刷怪蛋 / 盔甲架 是**实体**，不是方块 —— 走 mineflayer 的 placeEntity 那套
   *    （见下面 `placeEntityItem`）。旧代码一律当方块放，服务端收到的是"对着水右键放方块"，
   *    永远不成：2026-10-20 实机在生存和创造下各试了 3 次，`/execute if entity @e[type=oak_boat]`
   *    一次都没命中。 */
  if (want && isEntityItem(want)) return await placeEntityItem(self, { x: pos.x, y: pos.y, z: pos.z, name: want }, ctx)
  // 选方块：指定名字就给那个；没指定就**只挑整方块**（旧版直接 items[0]，见 pickPlaceItem 注释）
  const pick = () => pickPlaceItem(b, want)
  let item = pick()

  // 创造模式：背包里没有就**自动取**（协议级 set_creative_slot，不需要 OP）。
  // 不这么做的话"给个方块名就能建"不成立——AI 得先想起来调 mc_give，
  // 否则 mc_build 直接报"背包是空的"。生存模式没这福利（得自己挖/合成）。
  if (!item && want && b.game?.gameMode === 'creative') {
    await self.giveItem({ name: want })
    item = pick()
  }
  if (!item) {
    if (want) {
      throw new Error(`背包里没有 ${want}（生存模式请先挖或合成；创造模式本应自动取物，若仍失败请看上一条错误）`)
    }
    let all = []
    try { all = b.inventory.items() } catch {}
    if (!all.length) {
      throw new Error('背包是空的——**给 name 指定要放哪种方块**（创造模式下会自动取物），或先挖方块')
    }
    // 能走到这里 = 背包里有东西，但没有"能当填充块的整方块"
    const junk = [...new Set(all.filter((i) => !isFullBlockItem(b, i.name)).map((i) => i.name))].slice(0, 6)
    const kept = [...new Set(all.filter((i) => isFullBlockItem(b, i.name)).map((i) => i.name))].slice(0, 6)
    throw new Error('背包里没有能当**实体方块**放的东西'
      + (junk.length ? `（只有 ${junk.join('、')} —— 火把/门/半砖这些放下去站不住）` : '')
      + (kept.length ? `（${kept.join('、')} 是家当，不拿来当填充块；真要放就显式给 name）` : '')
      + '。先 mc_dig 挖点泥土/圆石，或 mc_craft 做点木板。')
  }

  // 走/飞到够得着的位置（reach 约 4.5 格）
  /* 🔴 2026-10-08 第五份审计报告 ⑤：以前用"脚 → 方块角点"的距离、阈值 5.5 ——
   *    服务端是按**眼睛 → 方块中心**判的（生存 4.5 / 创造 5.0），角点到中心差最多 ~0.87 格
   *    ⇒ 4.6–5.5 格的方块能过我们的检查、然后被服务端拒（`place_block.js:42` 抛英文
   *    `Server refused to place …`，原样冒泡成工具错误）。现在按眼→中心算、阈值对齐服务端。 */
  const reachMax = b.game?.gameMode === 'creative' ? 5.0 : 4.5
  /* 🔴 2026-10-13 实机：眼睛位置原来只算**一次**（走路之前），走完还用那个旧坐标判距离
   *    ⇒ 明明已经走到跟前，仍然报"够不着 … 41.3 格"（报的是出发那一刻的距离）。
   *    必须**每次现算**。 */
  const eyeNow = () => {
    try {
      const p = b.entity.position
      return new Vec3(p.x, p.y + (b.entity.eyeHeight ?? 1.62), p.z)
    } catch { return b.entity.position }
  }
  const dist = () => eyeNow().distanceTo(pos.offset(0.5, 0.5, 0.5))
  let approachError = null
  if (dist() > 4) {
    self._selfMovingAt = Date.now()
    try {
      if (b.game?.gameMode === 'creative') await self.flyTo(pos.x + 2, pos.y + 1.5, pos.z + 2)
      else {
        // 站到目标旁边的**地面**上，别朝半空的 y 走（见 approachSpot 注释）
        const spot = approachSpot(b, pos)
        if (!spot) {
          throw new Error(`(${pos.x},${pos.y},${pos.z}) 周围 2 格内没有能站的地面（目标悬空）——`
            + '我不会朝半空一路垫方块爬过去。想搭桥 / 搭路请用 `mc_build`（它按范围一块块放），'
            + '想放这一块就先 `mc_move` 走到它旁边能站的地方。')
        }
        await self.walkTo({ x: spot.x, y: spot.y, z: spot.z }, { arrive: 2.5, budget: 25_000 })
      }
    } catch (e) { approachError = e.message }
    self._selfMovingAt = Date.now()
    await sleep(250)
  }
  // 🔴 够不着就别硬放。旧版把接近失败 `catch {}` 吞掉、照样往下走，
  //    结果服务端拒了放置，而工具还报"placed: X"——真机被投诉的"报假成功"。
  if (dist() > reachMax) {
    throw new Error(`够不着 (${pos.x},${pos.y},${pos.z})：眼睛到方块中心 ${dist().toFixed(1)} 格，`
      + `${b.game?.gameMode === 'creative' ? '创造 5' : '生存 4.5'} 格以内才放得下`
      + (approachError ? `（接近失败：${approachError}）` : '')
      + '。先用 mc_move 靠近，或换更近的点位。')
  }

  // 目标位置必须"能放"：不占空间才放得进去。
  // 判据是 canPlaceInto（boundingBox==='empty'）——覆盖空气三兄弟、**液体**、草/花/藤蔓等可替换物。
  const targetBlock = b.blockAt(pos)
  if (!targetBlock) {
    throw new Error(`(${pos.x},${pos.y},${pos.z}) 未加载（区块还没到）——先 mc_map 看看，或换近一点的点位`)
  }
  if (!canPlaceInto(targetBlock)) {
    throw new Error(`(${pos.x},${pos.y},${pos.z}) 已被 ${targetBlock.name} 占住，放不进去——`
      + '换个位置，或先 mc_act{mode:"break"} 清掉')
  }
  let ref = placeRef(self, pos)
  if (!ref) {
    /* 悬空：先在自己**脚下**垫一块、站上去，目标格就挨着这一块了（"原地搭高"）。
     * 🔴 2026-10-17 用户实机报「一直尝试放方块」：这一步原来**站着就放** ——
     *    落点 = `underFeet.position + (0,1,0)` = **机器人自己站着的那一格**。
     *    服务端不把方块放进玩家身体里 ⇒ 必拒；而那次调用**不在**下面的 try/catch 里
     *    ⇒ 英文原文 `Server refused to place cobblestone at (305,20,-653): the block is still air`
     *    直接冒泡给模型。模型看不懂"报的坐标是我自己站的地方"，只会一遍遍重试同一个点位
     *    （用户的 AI 后来自己总结成「服务端不让在脚底下放」，只好改去挖台阶）。 */
    const below = b.entity.position.floored().offset(0, -1, 0)
    const underFeet = b.blockAt(below)
    let padError = null
    if (underFeet && !isAir(underFeet.name)) {
      await ctx.t(b.equip(item, 'hand'), 'equip', '手持垫脚方块')
      await ctx.t(b.lookAt(below.offset(0.5, 0.5, 0.5), true), 'lookAt', '看向脚下')
      try {
        await ctx.t(placeWhileJumping(b, underFeet, { x: 0, y: 1, z: 0 }), 'place', '垫脚')
      } catch (e) { padError = e }
      await sleep(250)
    }
    ref = placeRef(self, pos)
    if (!ref) {
      const why = padError
        ? `在原地垫高一块也被拒了（${String(padError?.message ?? padError).slice(0, 120)}）`
        : (underFeet && !isAir(underFeet.name) ? '垫高之后那一格还是挨不着它' : '脚下也没有可垫的方块')
      throw new Error(`(${pos.x},${pos.y},${pos.z}) 悬空：它六面都没有可依附的方块，${why}。`
        + '**别再对着同一个点位试了** —— 要么先 `mc_act{mode:"place"}` 把它**下面那一格**填上，'
        + '要么 `mc_move` 走到紧挨着它的位置（上下左右差一格）再放。')
    }
  }
  await ctx.t(b.equip(item, 'hand'), 'equip', '手持方块')
  await ctx.t(b.lookAt(ref.ref.position.offset(0.5, 0.5, 0.5), true), 'lookAt', '看向放置面')
  /* 🔴 2026-10-17（用户实机：「`mc_act {mode:"place"}` 放不了自己脚下，经典 pillar-jump 做不成，
   *    这是我在竖井里爬不上去、反复淹死的直接原因」）：
   *    目标格正是**自己身体占着的那一格**（脚下 / 齐腰）时，站着放必被服务端拒 ——
   *    服务端不会把方块放进玩家碰撞箱。寻路器的自动垫脚能做，是因为它**先跳起来**；
   *    而水/岩浆这种可替换方块能过 `canPlaceInto` 那一关，所以以前是"预检放行、服务端拒"，
   *    报出来的还是英文原文，模型只会对着同一个点位重试。
   *    ⇒ 这种点位改走"跳起来再放"（脚离地那一瞬，那一格就空了）。 */
  const feetNow = (() => { try { return b.entity.position.floored() } catch { return null } })()
  const isOwnCell = Boolean(feetNow)
    && pos.x === feetNow.x && pos.z === feetNow.z
    && (pos.y === feetNow.y || pos.y === feetNow.y + 1)
  try {
    if (isOwnCell) await ctx.t(placeWhileJumping(b, ref.ref, ref.face), 'place', '跳起来放到自己脚下')
    else await ctx.t(b.placeBlock(ref.ref, new Vec3(ref.face.x, ref.face.y, ref.face.z)), 'place', '放置方块')
  } catch (e) {
    /* 🔴 报告⑤：上游 `place_block.js:42` 抛的是英文 `Server refused to place …`，
     *    以前原样冒泡给模型。翻译成它能用的话。 */
    const m = String(e?.message ?? '')
    if (/Server refused to place/i.test(m)) {
      throw new Error(`服务端拒了在 (${pos.x},${pos.y},${pos.z}) 的这次放置（太远 / 目标格被占 / 手上有别的 / 失步）——`
        + (isOwnCell
          ? '**那一格是我自己身体占着的**（脚下/齐腰），已经试过"跳起来放"也没成 —— '
            + '先 `mc_move` 挪开一格、或者把**下面那一格**填上再站上去。别对着同一个点位反复试。'
          : '先用 `mc_move` 靠近或**换一个点位**，别对着同一个点位反复试，**也别当成放成功了**。'))
    }
    throw e
  }
  await sleep(200)

  // 🔴 必须**验证**：旧版不管成没成都是 `placed: item.name` → 真机被投诉的"报假成功"
  //    （mc_build 说 placed，mc_scan 复查一格没放下）
  const now = b.blockAt(pos)?.name ?? null
  /* 🔴 2026-10-19（用户实机：连插两个火把，两次都回「❌ 动作失败 / 服务端可能拒了这次放置」，
   *    但 `now` 明明写着 `wall_torch` —— 火把**好端端贴在墙上**了）：
   *    这里原先死比 `now === item.name`。可**方块名会带变体**：火把贴墙变 `wall_torch`
   *    （灵魂火把变 `soul_wall_torch`），告示牌/旗帜也有同类朝向变体。
   *    判据必须是"**同一种方块**"，不是"同一个字符串" —— 两边都去掉 `wall_` 再比。
   *    跟踩坑 199（`outcomeOf` 白名单漏 `opened`/`toggled`）是同一类错：
   *    **判成功要认变体，别认字面**。 */
  const normName = (s) => String(s ?? '').replace(/wall_/g, '')
  const ok = Boolean(now) && (now === item.name || normName(now) === normName(item.name))
  return {
    placed: ok ? item.name : false,
    requested: item.name,
    at: { x: pos.x, y: pos.y, z: pos.z },
    now,
    held: heldText(b),
    /* 这一块是"跳起来放到自己脚下"放成的 ⇒ 报出来，模型才知道自己刚垫高了一格。 */
    ...(isOwnCell ? { pillar: true } : {}),
    ...(ok ? {} : {
      note: `方块**没有出现**（现在那里是 ${now ?? '未加载'}）——服务端可能拒了这次放置`
        + '（领地保护 / 权限 / 反作弊 / 失步）。不要当成放成功了。'
        + (isOwnCell ? '（这一格是我自己站的地方，已经跳过再放 —— 还是没成，说明不是"占着"的问题）' : ''),
    }),
  }
}

/* ---------------------------------------------------------------- 实体物品（船 / 矿车 / 蛋 / 盔甲架） */


/**
 * 放一个**实体**物品（船 / 矿车 / 刷怪蛋 / 盔甲架 / 末影水晶）。
 *
 * 🔴 为什么不能用 `placeBlock` / `activateBlock`（2026-10-20 实机踩的）：
 *    mineflayer 的 `lib/plugins/place_entity.js` 写得很清楚 —— 放船时它先 `_genericPlace()`
 *    （发 `use_item_on`/`block_place`：告诉服务端"我对着这一格用了"，服务端拿这个包判断
 *    **该往哪放实体**），**然后再补发一个 `use_item` 包**（`useItemWithOwnPacket` 特性，
 *    1.19+ 都是），最后监听 `entitySpawn` 确认。少发后面那个 `use_item`，服务端就当"空手右键"，
 *    什么都不会生成 —— 正好是用户报的"放不出来"。
 * @returns `{placed, entity, at, name, held}`；没生成就 `{placed:false, hint}`（不抛，好让模型看懂）
 */
export async function placeEntityItem (self, { x, y, z, name = null } = {}, ctx = {}) {
  const b = self.requireBot()
  const t = ctx.t ?? ((p) => p)
  const pos = new Vec3(Math.floor(x), Math.floor(y), Math.floor(z))
  const want = name ? String(name) : (b.heldItem?.name ?? null)
  if (!want) throw new Error('没说放什么，手上也是空的 —— 给 name（如 oak_boat / minecart / zombie_spawn_egg）')
  if (!isEntityItem(want)) {
    throw new Error(`${want} 不是"放下去变实体"的东西（船 / 矿车 / 刷怪蛋 / 盔甲架 / 末影水晶才是）—— 放方块用 mc_build 或 mc_act{mode:"place"} 的方块路径`)
  }
  const findAll = (n) => {
    try { return b.inventory.items().filter((i) => i.name === n) } catch { return [] }
  }
  if (!findAll(want).length && b.game?.gameMode === 'creative') {
    await self.giveItem({ name: want })
    await sleep(120)
  }
  const item = findAll(want)[0] ?? null
  if (!item) {
    throw new Error(`背包里没有 ${want}（生存模式要先合成/捡一个：船 = 5 个木板）`)
  }
  if (b.heldItem?.name !== want) {
    await t(Promise.resolve(b.equip(item, 'hand')), 'act', `把 ${want} 拿到手上`)
    await sleep(100)
  }
  /* 参考方块 = 目标格本身（水里 / 空气里都能点），朝向取"上面"：船就浮在这一格的水面上。
   * 目标格不是水、下面是水/陆地也行 —— 服务端按"点到的这一格 + 这个面"算落点。 */
  let ref = b.blockAt(pos) ?? b.blockAt(pos.offset(0, -1, 0))
  if (!ref) throw new Error(`${pos.x},${pos.y},${pos.z} 未加载 —— 先走过去或 mc_scan 看一眼`)
  /* 🔴 2026-10-20 实机：给的是"水面**上方**那一格"（空气）时，`blockAt(pos)` 拿到的是 air 方块，
   *    `block_place` 对着空气发 ⇒ 服务端直接忽略（不报错、也不生成）。玩家瞄准的永远是水面本身。
   *    所以参考格是空气就往下摸最多 3 格，摸到水/地面为止。 */
  const isAirName = (nm) => /^(air|cave_air|void_air)$/.test(String(nm ?? ''))
  if (isAirName(ref?.name)) {
    for (let dy = 1; dy <= 3; dy++) {
      const below = b.blockAt(pos.offset(0, -dy, 0))
      if (below && !isAirName(below.name)) { ref = below; break }
    }
  }
  const before = new Set(Object.keys(b.entities ?? {}).map(String))
  const face = new Vec3(0, 1, 0)
  /* ① 先"对着这一格用"（服务端靠它算落点） ② 再补 `use_item`（船/矿车必须补，见上面的注释） */
  try {
    if (typeof b._genericPlace === 'function') {
      await t(Promise.resolve(b._genericPlace(ref, face, {})), 'act', `对着 ${ref.name} 用 ${want}`)
    } else {
      await t(Promise.resolve(b.activateBlock(ref)), 'act', `对着 ${ref.name} 用 ${want}`)
    }
  } catch (e) {
    return { placed: false, name: want, at: { x: pos.x, y: pos.y, z: pos.z }, hint: `放的时候服务端/上游报错：${e?.message ?? e}` }
  }
  /* 🔴 **不要**补发 `use_item`（2026-10-20 实机踩的，两次被踢）：mineflayer 的 `place_entity.js` 里为船
   *    补发了 `bot._client.write('use_item', { hand })`，但那是老协议的形状 —— 这个服（1.21.10 /
   *    protocol 773，minecraft-data 的 `packet_play_use_item` = `hand + sequence:varint + rotation:vec2f`）
   *    少了 `sequence`/`rotation`。protodef 是"边写边抛"，只写了一半就异常 ⇒ 那条包在流里是**残的**，
   *    服务端读到脏字节，同一秒还能勉强活，几十秒后 `disconnect.timeout` 掉线（实机两次都是"放完船就掉"）。
   *    对照：刷怪蛋走同一条 `_genericPlace`（只发 block_place）一来就放出来了 ⇒ 现代协议下**一个
   *    block_place 就够**，别画蛇添足。 */
  /* 复核：新出现的实体里，4 格内、名字像不像 */
  const KEY = /boat|raft|minecart|armor_stand|armorstand|end_crystal|ender_crystal/i
  const fresh = () => Object.values(b.entities ?? {}).filter((e) => e && e !== b.entity && !before.has(String(e.id)))
  let hit = null
  const waitSpawn = async (ms) => {
    const t0 = Date.now()
    while (Date.now() - t0 < ms) {
      const cands = fresh().filter((e) => {
        try { return e.position.distanceTo(pos) <= 4 } catch { return false }
      })
      hit = cands.find((e) => KEY.test(String(e.name ?? ''))) ?? cands[0] ?? null
      if (hit) return hit
      await sleep(80)
    }
    return null
  }
  let via = 'block_place'
  await waitSpawn(700)
  /* ② 还不行就再用一次"手上的东西"：`bot.activateItem()` 自己会拼出正确形状的 `use_item`
   *    （`inventory.js:134`：`{hand, sequence, rotation}`）。用户 2026-10-20 说过「用 useitem 其实也能放」，
   *    而我们自己的 `mc_act {mode:"useitem"}` 实测没放出来 —— 两条路都试一遍，谁成就报谁。 */
  if (!hit) {
    try {
      await t(Promise.resolve(b.activateItem()), 'act', `用手上的 ${want} 试一次`)
      via = 'use_item'
    } catch (e) {
      /* 记下但不打断：下面统一报"两条都没成" */
      via = `block_place + use_item(${String(e?.message ?? e)})`
    }
    await waitSpawn(800)
  }
  if (!hit) {
    return {
      placed: false, name: want, at: { x: pos.x, y: pos.y, z: pos.z }, held: heldText(b),
      sent: via,
      hint: `${via} 都发了，但 1.5 秒内**没看到新实体** —— 常见原因：离得远（要 4.5 格内、眼睛看得见）、`
        + `目标格被占（船要放水里/水边，别对着自己脚下）、或者服务端把这次放置吞了。`
        + `先 mc_move 到水边换个点位再试，别对着同一点反复发。`,
    }
  }
  return {
    placed: true, name: want, entity: String(hit.name ?? ''),
    at: { x: Math.round(hit.position.x * 10) / 10, y: Math.round(hit.position.y * 10) / 10, z: Math.round(hit.position.z * 10) / 10 },
    held: heldText(b),
    hint: /boat|raft/i.test(String(hit.name ?? '')) ? '上船用 mc_act {mode:"use", who:"oak_boat"}' : undefined,
  }
}
