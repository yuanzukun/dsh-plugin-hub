## 0.3.6 — 修复启动阻塞 + 使用中崩溃（客户端 bundle 边界 / 容器 MIME / 大会话）

**最重要的一个 bug**：0.3.5 会让 **DSH 整个起不来**。

### 一、启动阻塞（P0）

客户端入口 `src/client/api.ts` 从 `../routes.ts` 导入 `API_BASE`，而 `routes.ts` 是宿主模块（`node:fs` / `node:path` / `node:os`）。tsdown 对 Node 内置模块只能保留成 `require("node:path")`，而 **DSH 的 client-modules 模块表没有 Node 内置模块**：

```text
web boot: 1 entry did not activate
dsh-record-replay: import failed: client-modules: require("node:path") missed the module table
```

→ 整个 web boot 失败，DSH 主界面进不去。

**修复**：新增零依赖模块 `src/api-base.ts` 只放 `API_BASE` 常量；`routes.ts` 改为从它导入并 re-export；客户端只从 `../api-base.ts` 导入。

### 二、录屏后约 4 秒 DSH 崩退

宿主 ffmpeg 抓屏输出 **MP4/H.264**，却落在 **WebM** 的存储 / 路由 / 播放路径上（固定 `Content-Type: video/webm` + `autoPlay`），Chromium 媒体管线异常退出（无崩溃栈，高概率推断）。

**修复**：
1. 抓屏改 **WebM/VP8**（`libvpx + yuv420p -b:v 1M`），输出 `.webm`
2. 视频路由**读文件头嗅探**真实容器：`ftyp`→`video/mp4`、WebM magic→`video/webm`（200/206 都正确）
3. 播放弹窗移除 `autoPlay`，改 `preload="metadata"`
4. 旧 MP4 录屏已就地转码为真 WebM（原文件留 `.mp4-orig-20261108` 备份）

### 三、大会话内存压力

会话列表原来**整文件读取**每个会话（本机有 93MB / 33MB / 15MB 压缩会话，host RSS 已到 1.87GB）。

**修复**：
- `>4MB` 只读前 1MB 解压取 header（列表 29 个 123ms）
- 压缩文件 `>24MB` 拒绝完整回放并提示

### 四、防复发门禁（本版新增）

`scripts/check-bundle.mjs` 已挂进 `npm run build`：构建后自动检查 `lib/client.js` 不含 `require(`、不含 Node 内置、含 API 常量，违规即 `exit 1`。**负向测试通过**（人为注入 `require("node:path")` 被正确拦截）。

> 规则：客户端只能 `import type` 或导入 `src/api-base.ts` 这类无依赖常量模块，绝不能导入 `routes.ts` / `paths.ts` / 各 store。

### 实测

- `npm run build` ✓（门禁 `bundle guard: ok (295 KB, no Node builtins)`）
- `npm run smoke` ✓（会话扫描 / 时间线 658 items / 回放包 / 录制 / 技能 全过）
- 抓屏 3 秒 → 213,638 B **WebM**（magic `1a45dfa3`）
- 现有录屏容器确认均为 WebM