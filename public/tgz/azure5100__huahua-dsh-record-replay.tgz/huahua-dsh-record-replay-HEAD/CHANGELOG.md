# 更新记录

## 0.3.7 — 明确 ffmpeg 版本要求（宿主录屏依赖）

宿主侧录屏依赖 `ffmpeg`，但**版本差异会导致录出空文件**：2018 年的 `N-92722` 在 `gdigrab` + `libvpx` 组合下会报
`not enough frames to estimate rate`，产物 0 字节。

### 本版

- README 增加「ffmpeg 版本要求」章节：**6.0+**，附检查命令与 Store 占位符排查
- 记录实测：8.0.1（gyan.dev essentials）正常，3 秒抓屏 → 272 KB WebM（VP8 / 1280×800）

### 本机环境处理（一次性，不属于代码）

| 位置 | 原状态 | 处理 |
| --- | --- | --- |
| `C:\Users\cosmo\bin\ffmpeg.exe` | 2018 `N-92722`（61 MB） | 用 8.0.1 覆盖，旧版留 `.bak-2018-N92722` |
| `C:\Users\cosmo\bin\ffprobe.exe` | 旧版 | 同步覆盖为 8.0.1 |
| `...\WindowsApps\ffmpeg.exe` | Store 占位符（119 MB，执行返回 null） | 改名为 `.disabled-20261108`，避免 PATH 顺序变化时被命中 |
| `C:\ProgramData\chocolatey\bin\ffmpeg.exe` | 8.0.1（PATH 首位） | 保持 |

处理后 `where ffmpeg` 只剩两个真实 8.0.1 副本，`spawn('ffmpeg')` 稳定命中新版。

## 0.3.6 — 修复启动阻塞 + 使用中崩溃（客户端 bundle 边界 / 容器 MIME / 大会话）

**最重要的一个 bug**：0.3.5 会让 **DSH 整个起不来**。

### 一、启动阻塞（P0）

客户端入口 `src/client/api.ts` 从 `../routes.ts` 导入 `API_BASE`，而 `routes.ts` 是宿主模块（`node:fs` / `node:path` / `node:os`）。tsdown 对 Node 内置模块只能保留成 `require("node:path")`，而 **DSH 的 client-modules 模块表没有 Node 内置模块**：

```text
web boot: 1 entry did not activate
dsh-record-replay: import failed: client-modules: require("node:path") missed the module table
```

→ 整个 web boot 失败，DSH 主界面进不去。

**修复**：新增零依赖模块 `src/api-base.ts` 只放 `API_BASE` 常量；`routes.ts` 改为从它导入并 re-export；客户端只从 `../api-base.ts` 导入。

### 二、录屏后约 4 秒 DSH 崩退

宿主 ffmpeg 抓屏输出 **MP4/H.264**，却落在 **WebM** 的存储 / 路由 / 播放路径上（固定 `Content-Type: video/webm` + `autoPlay`），Chromium 媒体管线异常退出（无崩溃栈，高概率推断）。

**修复**：
1. 抓屏改 **WebM/VP8**（`libvpx + yuv420p -b:v 1M`），输出 `.webm`
2. 视频路由**读文件头嗅探**真实容器：`ftyp`→`video/mp4`、WebM magic→`video/webm`（200/206 都正确）
3. 播放弹窗移除 `autoPlay`，改 `preload="metadata"`
4. 旧 MP4 录屏已就地转码为真 WebM（原文件留 `.mp4-orig-20261108` 备份）

### 三、大会话内存压力

会话列表原来**整文件读取**每个会话（本机有 93MB / 33MB / 15MB 压缩会话，host RSS 已到 1.87GB）。

**修复**：
- `>4MB` 只读前 1MB 解压取 header（列表 29 个 123ms）
- 压缩文件 `>24MB` 拒绝完整回放并提示

### 四、防复发门禁（本版新增）

`scripts/check-bundle.mjs` 已挂进 `npm run build`：构建后自动检查 `lib/client.js` 不含 `require(`、不含 Node 内置、含 API 常量，违规即 `exit 1`。**负向测试通过**（人为注入 `require("node:path")` 被正确拦截）。

> 规则：客户端只能 `import type` 或导入 `src/api-base.ts` 这类无依赖常量模块，绝不能导入 `routes.ts` / `paths.ts` / 各 store。

### 实测

- `npm run build` ✓（门禁 `bundle guard: ok (295 KB, no Node builtins)`）
- `npm run smoke` ✓（会话扫描 / 时间线 658 items / 回放包 / 录制 / 技能 全过）
- 抓屏 3 秒 → 213,638 B **WebM**（magic `1a45dfa3`）
- 现有录屏容器确认均为 WebM

## 0.3.5 — 桌面端真能录屏了（宿主侧 ffmpeg 抓屏）

**突破**：0.3.3/0.3.4 只是绕路（导入本地文件）。本版在**桌面端点「开始录屏」真的能录**——不走浏览器权限，改由**宿主进程（Node）直接调 ffmpeg 抓屏**。

### 新增

| 路由 | 作用 |
| --- | --- |
| `GET /api/dsh-record-replay/capture` | 探测宿主是否可录（ffmpeg 是否可用 + 平台） |
| `POST /api/dsh-record-replay/capture` | 让宿主录 N 秒（`{seconds, fps, width}`），返回产物路径 |
| `POST /api/dsh-record-replay/capture/import` | 把抓到的文件登记成 recording（后续抽帧/回放/生成技能照旧） |

- `src/capture.ts`：Windows `gdigrab` / macOS `avfoundation` / Linux `x11grab`，x264 `ultrafast` 编码，默认 1280 宽
- 界面：录屏栏加「录制秒数」输入；宿主可用时按钮走宿主录制，否则回落浏览器 `getDisplayMedia`
- ffmpeg 缺失时报错写明原因，不静默失败

### 实测（Windows）

- `captureSupported()` → `true`
- 录 3 秒 → 149 KB `mp4`（1280 宽，x264）✓
- ffmpeg `gdigrab` 抓全屏 2560×1600 正常；libvpx 编码 bgra 会失败，**必须 x264 + yuv420p**（已踩）

### 已知限制

- 需要 ffmpeg 在 PATH（本机已有 8.0.1）
- 录制期间是**全屏**（gdigrab desktop），不能只录某个窗口
- 录制时长由「录制秒数」决定，到点自动停止（不是点停止按钮）

## 0.3.4 — 桌面端新增「导入本地录屏」

**背景**：0.3.3 只是把「桌面端不能录屏」说清楚了，录屏能力仍然缺失。本版补上**真正可用的替代路径**。

桌面端 `getDisplayMedia` 被宿主白名单拒绝，但**读取本地视频文件不需要任何媒体权限**——本版用 `<input type=file accept="video/*">` 选一个系统录屏文件（Win+G / OBS / 手机录屏），在浏览器里纯本地解码抽帧，再上传到同一套 recording 存储。

**能力等价**：导入后与浏览器录屏的产物完全一致——`video.webm`（原文件直传，不重编码）+ 最多 240 张采样帧 → 「回放」「生成技能」都能用。

**抽帧策略**：按时长均分（`step = max(0.5s, duration/240)`），seek 到每个时间点抓一帧 960px 宽的 PNG。

**实测**（Chromium + 真实 1280×720 / 6s webm）：
- 抽帧 12 张、尺寸 1280×720、时长识别 6s ✓
- 无任何 `getDisplayMedia` / 媒体权限调用 ✓

**UI**：录屏不可用时，「录屏」按钮禁用，下方显示说明 + 「导入本地录屏（系统录屏文件）」按钮。

## 0.3.3 — 桌面端录屏权限被拒的明确降级

**问题**：桌面端点「录屏」报 `Permission denied`。根因不在插件——DSH 桌面端（Electron）主窗口的权限白名单**只放行麦克风**：

```js
// D:\DSH\resources\app\lib\main.js  installMicrophonePermissions()
session.setPermissionCheckHandler((contents, permission, origin, details) => {
  if (permission !== 'media') return true
  return ... details.mediaType === 'audio' ...   // video / display-capture 一律 false
})
```

`setDisplayMediaRequestHandler` 全文件只装了一处，而且挂在**侧边栏浏览器会话**上（`callback({})` 等于拒绝），主窗口根本没有。所以 `getDisplayMedia({video:true})` 在桌面端必然被拒——浏览器原生录屏这条路在 Electron 桌面壳里走不通。

**修复（明确降级，不再让用户看原始报错）**：
- 进「录屏」tab 先探测 `navigator.mediaDevices.getDisplayMedia`，不可用则**禁用按钮** + 显示说明条
- 捕获到权限类错误时改写成可执行指引：改用 dsh web 版录屏，或用系统录屏工具录好后从「回放包」导入
- 中英文案齐备（`record.unavailable`）

**桌面端可用的替代路径**：
1. 用 `dsh web`（浏览器）打开同一页面 → `getDisplayMedia` 可用，录屏正常
2. 用系统录屏（Win+G / OBS）录完 → 转成回放包导入
3. 会话回放/导出/复刻功能**完全不受影响**（这些走 HTTP 路由，不涉及浏览器录屏权限）

## 0.3.2 — 修复 Electron 下 window.prompt/confirm/alert 不支持

**问题**：桌面端（Electron）点「录屏」报 `prompt() is not supported.` —— Electron 渲染进程不实现阻塞式对话框，原代码用 `window.prompt` 取录屏标题，直接抛错，录屏入口不可用。同类问题还有 8 处（删除确认、导入成功提示、错误提示等）。

**修复**：新增 `src/client/dialog.ts` 提供 in-app 对话框（DOM overlay + Promise，不阻塞线程），替换全部 9 处阻塞调用：

| 原调用 | 替换 | 处数 |
| --- | --- | --- |
| `window.prompt` | `askText()` | 1（录屏标题） |
| `window.confirm` | `askConfirm()` | 2（删录屏 / 删回放包） |
| `window.alert` | `tell()` | 6（导入成功 / 各类错误提示 / 无消息可复刻） |

对话框支持 Enter 确定、Esc 取消、点遮罩取消、自动聚焦；样式跟随 DSH 主题变量（`--dsw-alias-*`）。

**实测**（Chromium 真实 DOM）：`askText` 输入→确定返回输入值 ✓；取消返回 `''` ✓；`askConfirm` 确定→`true`、取消→`false` ✓；DOM 用后零残留 ✓。

## 0.3.1 — 导出文件名兼容中文标题

**问题**：`GET /api/dsh-record-replay/export` 在会话标题含中文/emoji 时报
`500 Invalid character in header content ["content-disposition"]`——Node 拒绝把非 ISO-8859-1 字符放进 HTTP 头，导致导出回放包直接失败。中文标题在中文用户里是常态（实测本机 77 个会话中大量 `HOS专题｜抖音` 这类标题）。

**修复**：
- `packFileName()` 输出只保留 ASCII 可打印字符；标题无 ASCII 残留时回落到 `sourceSessionId`
- `content-disposition` 同时给出 RFC 5987 的 `filename*=UTF-8''…`，浏览器下载时仍显示原始中文名

**实测**：`HOS专题｜抖音` → `HOS.replay.json`（下载名 UTF-8 还原为中文）；`纯中文标题` → `session-<id>.replay.json`

## 0.3.0 — DSH 0.2.1-rc.2 适配（Windows 桌面端）

适配目标：**DeepSeek Harness 0.2.1-rc.2**（Windows 桌面端，`DSH_HOME=D:\DSH\dsh-home`）。
上一版（0.2.0）按 rc.5 编写，在 rc.2 上会出现「面板已挂载但会话库空白」，本版修复。

### 修复（4 处）

| # | 问题 | 现象 | 修复 |
|---|---|---|---|
| 1 | 会话文件名不匹配 | 面板打开但列表 0 条（78 个会话全部跳过） | `SessionStore` 的候选文件名加 `session.v4.jsonl.zstd`（rc.2 的持久化后端用该命名），保留旧名兜底 |
| 2 | `schemastery` 裸名不可解析 | 插件加载即 `ERR_MODULE_NOT_FOUND` | 改为 `@deepseek-ai/schemastery`（rc.2 profile 下唯一可解析路径）；devDependencies 同步替换 |
| 3 | `@deepseek-ai/dsh-settings` 静态 import 不可解析 | 插件加载即崩 | 去掉静态 import，改为运行时 `await import()` + try/catch 探测；rc.2 的该包也不导出 `installSettingsSection`，缺失时降级为使用组合项 config，主功能不受影响 |
| 4 | 系统提示词写死 `~/.dsh` 路径 | 与实际 `DSH_HOME` 不一致，误导 agent 去错目录 | 改为按 `DSH_HOME` 动态拼接 |

### 实测验证（Windows + DSH 0.2.1-rc.2）

- 会话扫描：**77 条**（`DSH_HOME=D:\DSH\dsh-home`），有标题 27 条；另在 `C:\Users\cosmo\.dsh` 下扫出 29 条
- 多帧 zstd 解码：单会话 7,741 帧 / 39 MB / 15,662 行零失败
- 事件结构：插件假设的 7 类事件（session/title、turn/start、step/start、user/message、assistant/message、tool/call、tool/result）与 rc.2 真实会话完全一致
- DOM 选择器：rc.2 用 hash 类名（`BynINW_centerCol`、`_2H3hWW_logoRow`），插件的 `[class*="centerCol"]` / `[class*="sidebarCol"]` / `[class*="logoRow"]` 均可命中
- 插件加载：在 profile 目录（无 `@deepseek-ai/dsh-settings`）下 `import` 成功 39 ms

### 已知限制

- 录屏 → 生成技能依赖浏览器 `getDisplayMedia` 与视觉模型（`describe_image`），需在真实 GUI 里验证
- 会话标题在部分会话为空（该会话本身没有 `session/title` 事件），非插件缺陷

## 0.2.0 — Windows / DSH rc.5 适配

```
src/client/mount.tsx            面板挂载双选择器 [data-pane="conversation"], [class*="centerCol"]
src/client/styles.ts            定位上下文同步双选择器
src/client/locales.ts           新增「关闭面板」文案
src/client/panel/ReplayPanel.tsx 面板头部加关闭按钮
```

## 0.1.0 及以前

原始功能：会话库 / 时间线回放 / 回放包导入导出 / 复刻执行 / 录屏 / 生成技能。
