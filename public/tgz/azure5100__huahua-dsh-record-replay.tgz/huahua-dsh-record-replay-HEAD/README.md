

<div align="center">

# 🐻 huahua 出品 · DSH Record & Replay

**DSH 录制回放插件 · 由 huahua 打造并持续维护**

| 品牌 | 项目 |
| --- | --- |
| 🐻 huahua | 本插件（录制回放） |
| 🐻 huahua | [huahua-dsh-plugin-orchestra](https://github.com/azure5100/huahua-dsh-plugin-orchestra) · 插件管理系统 |

*huahua 系列：为 DeepSeek Harness 打造实用、完整、可维护的插件。*

</div>

---


DSH Web GUI 的「录制回放」插件，两套能力：

1. **会话回放**：DSH 自动录制每一场会话（`~/.dsh/sessions/session.jsonl.zstd`），本插件把它变成可用资产——时间线回放、导出/导入可分享的回放包、一键复刻到全新会话重新执行。
2. **录屏 → 生成技能**（Codex Record & Replay 同款）：在浏览器里录下你的屏幕操作（computer use，`getDisplayMedia` → webm 视频 + 采样帧），回放查看，并让 agent 逐帧分析（`describe_image`）自动生成 `SKILL.md`，安装进 `~/.dsh/skills` 立即可用。

> 类似 Codex 的 record & replay：录制是自动的，本插件补齐「回放 / 分享 / 复刻」这一半。


> **衍生声明（Derivative notice）**：本仓库是 [kangshifu1/dsh-record-replay](https://github.com/kangshifu1/dsh-record-replay)（Apache-2.0）的适配衍生版。原项目作者：kangshifu1。本项目在此基础上做了 Windows / DSH rc.5 适配修复（见下方「Windows 适配」一节），其余功能与架构源自原项目。按 Apache-2.0 §4 注明来源与本项目改动。

---

## Windows 适配（Windows adaptation）

本项目在 Windows + DeepSeek Harness 0.1.0-rc.5 上实测通过，并为此做了 **4 处客户端源码适配**（原版按更新一代 DSH 外壳的 DOM 约定编写，在 rc.5 上不可用）：

| 文件 | 适配内容 |
| --- | --- |
| `src/client/mount.tsx` | 面板挂载选择器双匹配：`[data-pane="conversation"], [class*="centerCol"]`——适配 rc.5 外壳（无 data-pane，中央列为 CSS Module 类名 centerCol） |
| `src/client/styles.ts` | 定位上下文同步双选择器——修复「进入面板后左侧主界面被整个盖住」的问题（rc.5 无 data-pane 定位上下文，绝对定位会锚定到外层 frame） |
| `src/client/locales.ts` | 新增「关闭面板」文案（中英双语） |
| `src/client/panel/ReplayPanel.tsx` | 面板头部加「关闭面板」按钮——原版无关闭入口，界面被盖住时无法返回对话 |

**适配目标 DSH 版本**：DeepSeek Harness 0.1.0-rc.5（Windows 桌面版）。

## DSH 0.2.1-rc.2 适配（0.3.0 新增）

同一份代码现在也覆盖 **DSH 0.2.1-rc.2**（Windows 桌面端）。rc.2 与 rc.5 有三处结构性差异，0.2.0 在 rc.2 上会「面板挂载成功但会话库空白」：

| # | 差异 | rc.2 实际 | 修复 |
| --- | --- | --- | --- |
| 1 | 会话文件名 | `session.v4.jsonl.zstd`（不是 `session.jsonl.zstd`） | 候选名加 v4，旧名保留兜底 |
| 2 | schemastery 解析路径 | 只有 `@deepseek-ai/schemastery` 可解析 | 改用带 scope 的包名 |
| 3 | `@deepseek-ai/dsh-settings` | 不可解析，且不导出 `installSettingsSection` | 去掉静态 import，运行时探测 + 缺失降级 |
| 4 | 系统提示词路径 | `DSH_HOME` 可能不在 `~/.dsh` | 改为按 `DSH_HOME` 动态拼接 |

**Windows + rc.2 实测**：会话扫描 77 条（`DSH_HOME=D:\DSH\dsh-home`）/ 多帧 zstd 单会话 7,741 帧零失败 / 7 类事件结构完全吻合 / 插件在无 dsh-settings 的 profile 下 import 成功。
在带 `data-pane`/taskboard/ssh 面板的新版外壳上，双选择器保持向后兼容（老规则对不存在的元素是空操作）。

> 完整适配过程与踩坑记录见：`docs/适配修复报告.md`（Windows 环境构建：NTFS 目录联接、pnpm 11、Node ≥ 20）。

---

## 能力

| 功能 | 说明 |
| --- | --- |
| 会话库 | 侧边栏「录制回放」入口，列出本机全部已录制会话（标题 / 项目 / 时间 / 消息数） |
| 时间线回放 | 以可读时间线查看任意会话：用户消息、助手回复（推理过程可折叠）、工具调用与参数、工具结果（长文可展开），支持搜索过滤 |
| 导出回放包 | 把任意会话导出为单个 `dsh-replay-pack` JSON（`*.replay.json`），git 友好、体积小，可直接放到 GitHub 仓库分享 |
| 导入回放包 | 导入队友 / GitHub 上分享的 `.replay.json`，存到 `~/.dsh/replay-packs`，可查看、删除、复刻 |
| 复刻执行 | 把录制会话的**用户消息**按原顺序逐条发送到全新会话，让 agent 真实重新执行一遍（可用于复现、回归、教学、模板化流程） |
| 录屏 | 浏览器 `getDisplayMedia` 录制屏幕/窗口（webm + 每 2s 采样帧，存 `~/.dsh/recordings`），支持回放与删除 |
| 生成技能 | 一键让 agent 会话逐帧分析录屏（`describe_image`），输出 SKILL.md 并安装到 `~/.dsh/skills`——新技能被 skill 目录热监听发现，直接进入每个会话的技能目录 |

## 安装

```bash
# 本地路径安装（开发 / 自用，推荐）
dsh plugin --profile <profile名> add link:/path/to/dsh-record-replay
# Windows 桌面端 profile 是 desktop：
dsh plugin --profile desktop add link:D:/huahua-dsh-record-replay

# 或从 npm 安装（发布后）
dsh plugin --profile <profile名> add dsh-record-replay
```

安装后**重启桌面端 / dsh web GUI**（插件集会变更需要重启生效）。

> `DSH_HOME` 说明：本插件所有路径都从 `process.env.DSH_HOME` 推导（未设时回落到 `~/.dsh`）。Windows 桌面端通常是 `D:\DSH\dsh-home`；若插件读不到会话，先确认该环境变量在宿主进程里可见。侧边栏出现「录制回放」入口即成功。

> 原理：`dsh plugin` 是 pnpm 转发器——把包装进 profile 的 `node_modules`，检测到 `dsh.bundle` 声明后把 `cordis.patch.yml` 并入 bundle 层，插件行进入 roster；浏览器半区按 `dsh.client` 声明以 `/plugins/dsh-record-replay/client.js` 加载。

## 使用

1. 点侧边栏「录制回放」打开面板。
2. **会话** tab：任一会话可「回放」（时间线）、「导出」（下载回放包）、「复刻」（开新会话重新执行）。
3. **回放包** tab：导入 `.replay.json`，管理已导入的包。
4. **录屏** tab：点「开始录屏」选择屏幕/窗口录制操作；停止后自动上传视频与采样帧。对任意录屏可「回放」，或点「生成技能」——插件开一个 agent 会话，让它逐帧调用 `describe_image` 提炼工作流并产出 SKILL.md，写入 `~/.dsh/skills/<name>/SKILL.md` 后即成为可用技能。

## 回放包格式

```json
{
  "format": "dsh-replay-pack",
  "version": 1,
  "meta": { "title": "...", "cwd": "...", "createdAt": 0, "agentPreset": "code", "exportedAt": 0, "sourceSessionId": "session-..." },
  "items": [
    { "kind": "user", "turn": 1, "step": 1, "text": "...", "time": 0 },
    { "kind": "assistant", "turn": 1, "step": 1, "text": "...", "reasoning": "...", "time": 0 },
    { "kind": "tool", "turn": 1, "step": 1, "name": "run_code", "callId": "...", "argsText": "{...}", "time": 0 },
    { "kind": "result", "turn": 1, "step": 1, "callId": "...", "text": "...", "time": 0 }
  ]
}
```


## 客户端 bundle 边界（必读 · 2026-11-08 事故）

浏览器端 bundle **绝不能**导入宿主模块。0.3.5 因为 `src/client/api.ts` 从 `../routes.ts` 导入 `API_BASE`，把 `node:fs` / `node:path` / `node:os` 拖进客户端，构建成 `require("node:path")`；DSH 的 client-modules 模块表里没有 Node 内置模块 ⇒ **整个 web boot 失败，DSH 起不来**。

| 允许 | 禁止 |
| --- | --- |
| `import type`（纯类型） | 导入 `routes.ts` / `paths.ts` / 各 store |
| `src/api-base.ts`（零依赖常量） | 任何 `node:*` 内置模块 |
| React / 浏览器 API | 复用宿主端计算的常量（改为抽到 api-base 一类模块） |

**门禁**：`npm run build` 末尾自动跑 `scripts/check-bundle.mjs`，发现 `require(` 或 Node 内置即 `exit 1`。

```bash
node scripts/check-bundle.mjs   # 手动复查
```


## ffmpeg 版本要求（宿主录屏）

宿主侧录屏用 `ffmpeg`；**要求 6.0+**（本机实测 8.0.1 / gyan.dev essentials build 正常）。

- 老版本（如 2018 的 `N-92722`）在 `gdigrab` + `libvpx` 组合下偶发「not enough frames to estimate rate」，录出 0 字节文件
- 检查：`ffmpeg -version | head -1`；`where ffmpeg` 看是否被 Store 占位符（`WindowsApps\ffmpeg.exe`）抢先
- 缺 ffmpeg 时路由 `GET /api/dsh-record-replay/capture` 返回 `supported: false`，界面禁用录制按钮

## 数据与隐私

- **读取**：`~/.dsh/sessions/**/session.jsonl(.zstd)`（DSH 自动录制，本插件只读）。
- **写入**：`~/.dsh/replay-packs/`（导入的回放包）、`~/.dsh/recordings/`（录屏）、`~/.dsh/skills/`（生成的技能）。
- **录屏隐私**：录屏会捕获屏幕上的一切（含密码输入等），生成技能前请留意；录制全程仅在浏览器本地，上传存于本机 `~/.dsh/recordings`。
- **注意**：回放包含完整对话与工具输出，可能含密钥 / 敏感信息——分享前请自行脱敏。API 路由仅限 loopback（本机浏览器同源），LAN 暴露的 dsh web 部署不会提供服务。

## 开发

```bash
pnpm install
pnpm build        # tsc 编译宿主半区到 lib/，tsdown 打包浏览器半区到 lib/client.js
pnpm smoke        # 对本机真实会话跑一遍 扫描→解析→建包→解析→存库 冒烟测试
```

## 架构

双面插件（dsh-web-ui 家族约定）：

- **宿主半区**（`src/index.ts`，node）：`SessionStore` 扫描解码会话、`timeline.ts` 蒸馏时间线、`replay-pack.ts` / `pack-store.ts` 回放包、`recording-store.ts` 录屏存储（webm + 帧，视频带 Range 支持）、`skill-installer.ts` 技能安装（校验 frontmatter 与 skill 命名、写入 `~/.dsh/skills`）、`routes.ts` 提供 `/api/dsh-record-replay/*`，并向 agent 宣告插件存在（system-prompt section）。zstd 解码使用 vendored [fzstd](https://github.com/101arrowz/fzstd)（MIT，支持多帧流），无运行时第三方依赖。
- **浏览器半区**（`src/client/`）：侧边栏入口（DOM 级注入、自愈）+ 中央列面板（React，单占用者接管，与 task-board / ssh 面板互斥）。会话/回放包/录屏三个 tab；复刻执行与技能生成都复用官方 `sessions` / `workspaces` / `connection` 服务——技能生成会话用 `describe_image` 逐帧看录屏帧（宿主以 HTTP URL 提供），最后把 agent 输出的 SKILL.md 交给宿主安装。

## License

Apache-2.0。Vendored fzstd © 101arrowz, MIT（见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)）。


---

## 🐻 huahua 出品

**huahua**（花花的团队/个人）致力于为 DeepSeek Harness 打造高质量插件：

- **[huahua-dsh-plugin-orchestra](https://github.com/azure5100/huahua-dsh-plugin-orchestra)** — DSH 插件管理系统：清单 / 更新检测 / 一键升级 / 备份回滚
- **本插件（record-replay）** — DSH 录制回放：会话时间线 / 回放包 / 复刻 / 录屏生成技能

功能完整、Windows 实测可用、持续维护。有问题欢迎提 Issue / PR。

