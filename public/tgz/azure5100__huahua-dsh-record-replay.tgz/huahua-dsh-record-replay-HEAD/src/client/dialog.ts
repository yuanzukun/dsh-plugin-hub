/**
 * In-app dialogs. Electron (and sandboxed webviews) do not implement the
 * blocking window.prompt / window.confirm / window.alert: calling them throws
 * "prompt() is not supported." on this shell. These helpers render a small DOM
 * overlay and resolve a Promise instead of blocking the thread.
 */

interface DialogButton {
  label: string
  value: string
  danger?: boolean
}

interface DialogOptions {
  title: string
  message?: string
  /** Text field above the buttons (prompt mode). */
  input?: { value: string; placeholder?: string }
  buttons: DialogButton[]
}

interface DialogResult {
  button: string | null
  value: string
}

/** Render the overlay; resolve with the pressed button plus the field value. */
function showDialog(options: DialogOptions): Promise<DialogResult> {
  return new Promise(resolve => {
    const host = document.createElement('div')
    host.setAttribute('data-dsh-record-replay-dialog', '')
    host.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:2147483600',
      'display:flex', 'align-items:center', 'justify-content:center',
      'background:rgba(0,0,0,.45)', 'font:14px/1.5 system-ui,sans-serif',
    ].join(';')

    const card = document.createElement('div')
    card.style.cssText = [
      'min-width:320px', 'max-width:min(520px,92vw)', 'padding:20px 22px',
      'border-radius:12px', 'background:var(--dsw-alias-bg-base,#1f1f23)',
      'color:var(--dsw-alias-label-primary,#e8e8e9)',
      'box-shadow:0 18px 48px rgba(0,0,0,.45)',
      'border:1px solid var(--dsw-alias-border-l1,#33333a)',
    ].join(';')

    const title = document.createElement('div')
    title.textContent = options.title
    title.style.cssText = 'font-weight:600;font-size:15px;margin-bottom:10px'
    card.append(title)

    if (options.message !== undefined && options.message !== '') {
      const body = document.createElement('div')
      body.textContent = options.message
      body.style.cssText = 'opacity:.78;margin-bottom:14px;white-space:pre-wrap'
      card.append(body)
    }

    let input: HTMLInputElement | undefined
    if (options.input !== undefined) {
      input = document.createElement('input')
      input.type = 'text'
      input.value = options.input.value
      if (options.input.placeholder !== undefined) input.placeholder = options.input.placeholder
      input.style.cssText = [
        'width:100%', 'box-sizing:border-box', 'padding:8px 10px', 'margin-bottom:14px',
        'border-radius:8px', 'border:1px solid var(--dsw-alias-border-l1,#3a3a42)',
        'background:var(--dsw-alias-bg-l1,#17171a)', 'color:inherit', 'font:inherit',
      ].join(';')
      card.append(input)
    }

    const row = document.createElement('div')
    row.style.cssText = 'display:flex;gap:8px;justify-content:flex-end'

    // Capture the field before the overlay leaves the DOM.
    const settle = (button: string | null): void => {
      const value = input?.value ?? ''
      document.removeEventListener('keydown', onKey, true)
      host.remove()
      resolve({ button, value })
    }

    for (const [index, button] of options.buttons.entries()) {
      const el = document.createElement('button')
      el.type = 'button'
      el.textContent = button.label
      const primary = index === 0
      el.style.cssText = [
        'padding:7px 16px', 'border-radius:8px', 'cursor:pointer', 'font:inherit',
        primary
          ? 'border:1px solid transparent;background:var(--dsw-alias-brand-primary,#f23c83);color:#fff'
          : 'border:1px solid var(--dsw-alias-border-l1,#3a3a42);background:transparent;color:inherit',
        button.danger === true ? 'background:#c0392b;border-color:transparent;color:#fff' : '',
      ].join(';')
      el.addEventListener('click', () => { settle(button.value) })
      row.append(el)
    }
    card.append(row)
    host.append(card)

    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        event.stopPropagation()
        settle(null)
      }
      if (event.key === 'Enter') {
        event.stopPropagation()
        settle(options.buttons[0]?.value ?? null)
      }
    }
    document.addEventListener('keydown', onKey, true)
    host.addEventListener('click', event => { if (event.target === host) settle(null) })

    document.body.append(host)
    if (input !== undefined) {
      input.focus()
      input.select()
    } else {
      card.querySelector('button')?.focus()
    }
  })
}

/** Replacement for window.prompt — returns '' when dismissed (same contract). */
export async function askText(title: string, initial = '', message?: string): Promise<string> {
  const result = await showDialog({
    title,
    message,
    input: { value: initial },
    buttons: [{ label: '确定', value: 'ok' }, { label: '取消', value: 'cancel' }],
  })
  return result.button === 'ok' ? result.value : ''
}

/** Replacement for window.confirm. */
export async function askConfirm(
  title: string,
  message?: string,
  confirmLabel = '确定',
  danger = false,
): Promise<boolean> {
  const result = await showDialog({
    title,
    message,
    buttons: [{ label: confirmLabel, value: 'ok', danger }, { label: '取消', value: 'cancel' }],
  })
  return result.button === 'ok'
}

/** Replacement for window.alert. */
export async function tell(title: string, message?: string): Promise<void> {
  await showDialog({ title, message, buttons: [{ label: '好', value: 'ok' }] })
}
