import { useCallback, useEffect, useRef, useState } from 'react'
import type { ReplayApi } from '../api.ts'
import type { ReplayRuntimeFaces } from '../mount.tsx'
import type { RecordingSummary } from '../../types.ts'
import { fill, tt } from '../helpers.ts'
import { askConfirm, askText } from '../dialog.ts'
import { VideoModal } from './VideoModal.tsx'
import { SkillGenModal } from './SkillGenModal.tsx'

const MAX_FRAMES = 240
const FRAME_INTERVAL_MS = 2000

/** Live recording state (kept in a ref so async stop handlers see fresh state). */
interface ActiveRecording {
  title: string
  stream: MediaStream
  recorder: MediaRecorder
  videoEl: HTMLVideoElement
  canvas: HTMLCanvasElement
  ctx: CanvasRenderingContext2D
  chunks: BlobPart[]
  frames: Blob[]
  timer: ReturnType<typeof setInterval>
  clock: ReturnType<typeof setInterval>
  startedAt: number
  elapsed: number
}

function formatElapsed(seconds: number): string {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

function formatTime(value: number): string {
  const date = new Date(value)
  const pad = (n: number): string => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

export function RecordTab({ api, runtime }: { api: ReplayApi; runtime: ReplayRuntimeFaces }) {
  const [recordings, setRecordings] = useState<RecordingSummary[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [active, setActive] = useState<ActiveRecording | null>(null)
  const [uploading, setUploading] = useState(false)
  const [viewing, setViewing] = useState<RecordingSummary | null>(null)
  const [skillFor, setSkillFor] = useState<RecordingSummary | null>(null)
  const activeRef = useRef<ActiveRecording | null>(null)

  /** getDisplayMedia exists in every modern browser but Electron denies it. */
  const [captureSupported, setCaptureSupported] = useState<boolean | null>(null)
  /** Host-side capture (ffmpeg) works where the Electron renderer denies getDisplayMedia. */
  const [hostCapture, setHostCapture] = useState<boolean | null>(null)
  const [captureSeconds, setCaptureSeconds] = useState(20)
  useEffect(() => {
    if (typeof navigator === 'undefined' || navigator.mediaDevices === undefined
        || typeof navigator.mediaDevices.getDisplayMedia !== 'function') {
      setCaptureSupported(false)
      return
    }
    setCaptureSupported(true)
  }, [])

  useEffect(() => {
    void api.captureSupported()
      .then(result => { setHostCapture(result.supported) })
      .catch(() => { setHostCapture(false) })
  }, [api])



  const load = useCallback(async () => {
    setError(null)
    try { setRecordings(await api.listRecordings()) }
    catch (reason) { setError(String(reason)) }
  }, [api])

  useEffect(() => { void load() }, [load])

  /** Record via the host process (no browser permission involved). */
  const startHostRecording = useCallback(async () => {
    setError(null)
    setUploading(true)
    try {
      const title = await askText(tt('record.titlePrompt'))
      if (title === '') { setUploading(false); return }
      const captured = await api.captureScreen({ seconds: captureSeconds, fps: 10, width: 1280 })
      await api.importCapture(title, captured.path)
      await load()
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    }
    setUploading(false)
  }, [api, load, captureSeconds])

  const stopRecording = useCallback(async () => {
    const rec = activeRef.current
    if (rec === null) return
    activeRef.current = null
    setActive(null)
    setUploading(true)
    clearInterval(rec.timer)
    clearInterval(rec.clock)
    rec.stream.getTracks().forEach(track => { track.stop() })
    // Let the recorder flush its final chunk, then upload everything.
    const stopPromise = new Promise<void>(resolve => {
      if (rec.recorder.state === 'inactive') { resolve(); return }
      rec.recorder.onstop = () => resolve()
      rec.recorder.stop()
    })
    await stopPromise
    const videoBlob = new Blob(rec.chunks, { type: 'video/webm' })
    try {
      const meta = await api.createRecording(rec.title)
      if (videoBlob.size > 0) await api.uploadRecordingVideo(meta.id, videoBlob)
      for (let index = 0; index < rec.frames.length; index += 1) {
        const name = 'frame-' + String(index + 1).padStart(4, '0') + '.png'
        await api.uploadRecordingFrame(meta.id, name, rec.frames[index])
      }
      await load()
    } catch (reason) { setError(String(reason)) }
    setUploading(false)
  }, [api, load])


  /**
   * Import a locally recorded video (OS screen recorder) instead of browser
   * capture. Decoding a file needs no media-capture permission, so this path
   * works inside the Electron desktop shell where getDisplayMedia is denied.
   */
  const importVideo = useCallback(async (file: File) => {
    setError(null)
    setUploading(true)
    try {
      const title = file.name.replace(/\.[^.]+$/, '')
      const videoEl = document.createElement('video')
      videoEl.muted = true
      videoEl.playsInline = true
      videoEl.src = URL.createObjectURL(file)
      await new Promise<void>((resolve, reject) => {
        videoEl.onloadeddata = () => resolve()
        videoEl.onerror = () => reject(new Error('无法解码该视频文件'))
      })
      await videoEl.play().catch(() => undefined)
      const meta = await api.createRecording(title)
      // Frames: sample across the whole duration (up to MAX_FRAMES).
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      if (ctx === null) throw new Error('canvas 2d context unavailable')
      const duration = Number.isFinite(videoEl.duration) ? videoEl.duration : 0
      const step = duration > 0 ? Math.max(0.5, duration / MAX_FRAMES) : 2
      const times: number[] = []
      for (let at = 0; at < (duration || 1); at += step) times.push(at)
      if (times.length === 0) times.push(0)
      let index = 0
      for (const at of times.slice(0, MAX_FRAMES)) {
        await new Promise<void>(resolve => {
          const onSeeked = (): void => { videoEl.removeEventListener('seeked', onSeeked); resolve() }
          videoEl.addEventListener('seeked', onSeeked)
          videoEl.currentTime = Math.min(at, Math.max(0, (duration || 0.1) - 0.05))
        })
        if (videoEl.videoWidth === 0) continue
        const width = 960
        const height = Math.max(1, Math.round(videoEl.videoHeight * width / videoEl.videoWidth))
        canvas.width = width
        canvas.height = height
        ctx.drawImage(videoEl, 0, 0, width, height)
        const blob = await new Promise<Blob | null>(resolve => { canvas.toBlob(resolve, 'image/png') })
        if (blob === null) continue
        index += 1
        await api.uploadRecordingFrame(meta.id, 'frame-' + String(index).padStart(4, '0') + '.png', blob)
      }
      // The original file goes up as the video artifact (no re-encode).
      await api.uploadRecordingVideo(meta.id, file)
      URL.revokeObjectURL(videoEl.src)
      await load()
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    }
    setUploading(false)
  }, [api, load])

  const fileInput = useRef<HTMLInputElement | null>(null)

  const startRecording = useCallback(async () => {
    try {
      const title = await askText(tt('record.titlePrompt'))
      if (title === '') return
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 15 }, audio: false })
      // A detached <video> feeds the frame sampler (never shown on screen).
      const videoEl = document.createElement('video')
      videoEl.muted = true
      videoEl.playsInline = true
      videoEl.srcObject = stream
      await videoEl.play()
      let mimeType = 'video/webm;codecs=vp9'
      if (typeof MediaRecorder !== 'undefined' && !MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/webm'
      const recorder = new MediaRecorder(stream, { mimeType })
      const chunks: BlobPart[] = []
      recorder.ondataavailable = event => { if (event.data.size > 0) chunks.push(event.data) }
      recorder.start(500)
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      if (ctx === null) throw new Error('canvas 2d context unavailable')
      const frames: Blob[] = []
      const timer = setInterval(() => {
        if (frames.length >= MAX_FRAMES || videoEl.videoWidth === 0) return
        const width = 960
        const height = Math.max(1, Math.round(videoEl.videoHeight * width / videoEl.videoWidth))
        canvas.width = width
        canvas.height = height
        ctx.drawImage(videoEl, 0, 0, width, height)
        canvas.toBlob(blob => { if (blob !== null) frames.push(blob) }, 'image/png')
      }, FRAME_INTERVAL_MS)
      const clock = setInterval(() => {
        setActive(prev => prev === null ? null : { ...prev, elapsed: Math.floor((Date.now() - prev.startedAt) / 1000) })
      }, 1000)
      const rec: ActiveRecording = { title, stream, recorder, videoEl, canvas, ctx, chunks, frames, timer, clock, startedAt: Date.now(), elapsed: 0 }
      activeRef.current = rec
      setActive(rec)
      // The browser's own "Stop sharing" button also ends the recording.
      stream.getVideoTracks()[0]?.addEventListener('ended', () => { void stopRecording() })
    } catch (reason) {
      // Electron's desktop shell grants audio only, so getDisplayMedia is denied
      // with a bare "Permission denied"; name the real cause and the way out.
      const message = reason instanceof Error ? reason.message : String(reason)
      const denied = /permission|denied|notallowed/i.test(message)
      setError(denied ? tt('record.unavailable') : message)
    }
  }, [stopRecording])

  const remove = useCallback(async (recording: RecordingSummary) => {
    if (!(await askConfirm(tt('record.deleteConfirm'), undefined, '删除', true))) return
    try { await api.deleteRecording(recording.id); await load() }
    catch (reason) { setError(String(reason)) }
  }, [api, load])

  return (
    <div>
      {error !== null && <div className="rrp-error">{error}</div>}
      <div className="rrp-recordBar">
        {active === null ? (
          <>
          <span className="rrp-note">{tt('record.seconds')}</span>
          <input
            className="rrp-seconds"
            type="number"
            min={5}
            max={600}
            value={captureSeconds}
            onChange={event => { setCaptureSeconds(Math.min(600, Math.max(5, Number(event.target.value) || 20))) }}
            style={{ width: '64px' }}
          />
          {hostCapture === true ? (
            <button className="rrp-recordBtn" data-primary="" onClick={() => void startHostRecording()} disabled={uploading}>
              {tt('record.start')}
            </button>
          ) : (
            <button
              className="rrp-recordBtn"
              data-primary=""
              onClick={() => void startRecording()}
              disabled={uploading || captureSupported === false}
              title={captureSupported === false ? tt('record.unavailable') : undefined}
            >{tt('record.start')}</button>
          )}
          </>
        ) : (
          <>
            <span className="rrp-recordLive">{tt('record.recording')}</span>
            <span className="rrp-recordTimer">{formatElapsed(active.elapsed)}</span>
            <span className="rrp-recordFrames">{fill(tt('record.frames'), { frames: active.frames.length })}</span>
            <button className="rrp-recordBtn" onClick={() => void stopRecording()}>{tt('record.stop')}</button>
          </>
        )}
        {uploading && <span className="rrp-note">{tt('record.uploading')}</span>}
      </div>
      {captureSupported === false && (
        <>
        <div className="rrp-note" data-record-unsupported="">{tt('record.unavailable')}</div>
        <button className="rrp-recordBtn" onClick={() => fileInput.current?.click()} disabled={uploading}>
          {tt('record.import')}
        </button>
        <input
          ref={fileInput}
          type="file"
          accept="video/*"
          style={{ display: 'none' }}
          onChange={event => {
            const file = event.target.files?.[0]
            event.target.value = ''
            if (file !== undefined) void importVideo(file)
          }}
        />
              </>
      )}
      {recordings === null ? <div className="rrp-note">{tt('sessions.loading')}</div>
        : recordings.length === 0 ? <div className="rrp-empty">{tt('record.empty')}</div>
        : (
          <div className="rrp-list">
            {recordings.map(rec => (
              <div className="rrp-row" key={rec.id}>
                <div className="rrp-rowMain">
                  <div className="rrp-rowTitle">{rec.title}</div>
                  <div className="rrp-rowMeta">{formatTime(rec.createdAt)} · {fill(tt('record.frames'), { frames: rec.frames })} · {rec.videoBytes !== undefined ? fill(tt('record.video'), { size: formatBytes(rec.videoBytes) }) : tt('record.noVideo')}</div>
                </div>
                <div className="rrp-rowActions">
                  {rec.videoBytes !== undefined && <button className="rrp-btn" onClick={() => setViewing(rec)}>{tt('record.replay')}</button>}
                  <button className="rrp-btn" data-primary="" onClick={() => setSkillFor(rec)} disabled={rec.frames === 0}>{tt('record.genSkill')}</button>
                  <button className="rrp-btn" data-danger="" onClick={() => void remove(rec)}>{tt('record.delete')}</button>
                </div>
              </div>
            ))}
          </div>
        )}
      {viewing !== null && <VideoModal api={api} recording={viewing} onClose={() => setViewing(null)} />}
      {skillFor !== null && <SkillGenModal api={api} runtime={runtime} recording={skillFor} onClose={() => setSkillFor(null)} />}
    </div>
  )
}
