/**
 * API base path shared by the host route family and the browser client.
 * Kept in a dependency-free module so the client bundle never pulls in
 * the host-only route module (node:fs/node:path/node:os).
 */
export const API_BASE = '/api/dsh-record-replay'
