/**
 * Host-side screen capture. The desktop shell (Electron) denies
 * getDisplayMedia to the renderer, but the host process can drive the OS
 * screen recorder directly. This gives the desktop build a working recording
 * path without touching the shell's permission policy.
 *
 * Windows: ffmpeg -f gdigrab. macOS: avfoundation. Linux: x11grab.
 * ffmpeg must be on PATH; when it is missing the route reports that clearly.
 */
import { spawn } from 'node:child_process'
import { mkdir, rm, stat } from 'node:fs/promises'
import { join } from 'node:path'

export interface CaptureRequest {
  /** Seconds to record (clamped to 1..600). */
  seconds: number
  /** Frames per second (clamped to 1..30). */
  fps?: number
  /** Downscale the long edge to this width (clamped to 320..2560). */
  width?: number
}

export interface CaptureResult {
  path: string
  bytes: number
  seconds: number
  platform: string
}

/** Whether this host can record at all (ffmpeg present). */
export async function captureSupported(): Promise<boolean> {
  return await new Promise(resolve => {
    const child = spawn('ffmpeg', ['-version'], { stdio: 'ignore' })
    child.once('error', () => resolve(false))
    child.once('exit', code => resolve(code === 0))
  })
}

/** Recording arguments per platform. */
function argsFor(request: CaptureRequest, output: string): string[] {
  const seconds = Math.min(600, Math.max(1, Math.round(request.seconds)))
  const fps = Math.min(30, Math.max(1, Math.round(request.fps ?? 10)))
  const width = Math.min(2560, Math.max(320, Math.round(request.width ?? 1280)))
  const base = ['-y', '-hide_banner', '-loglevel', 'error']
  // The rest of the plugin stores/serves `video.webm` and the browser viewer
  // expects WebM. Encode VP8 so the host-captured file needs no container
  // relabeling or a fragile MP4-in-.webm playback path.
  const encode = ['-vf', `scale=${width}:-2`, '-c:v', 'libvpx', '-pix_fmt', 'yuv420p', '-b:v', '1M']
  if (process.platform === 'win32') {
    return [...base, '-f', 'gdigrab', '-framerate', String(fps), '-t', String(seconds), '-i', 'desktop', ...encode, output]
  }
  if (process.platform === 'darwin') {
    return [...base, '-f', 'avfoundation', '-framerate', String(fps), '-t', String(seconds), '-i', '1:none', ...encode, output]
  }
  return [...base, '-f', 'x11grab', '-framerate', String(fps), '-t', String(seconds), '-i', process.env.DISPLAY ?? ':0.0', ...encode, output]
}

/** Record the screen for `seconds` and return the produced file. */
export async function captureScreen(directory: string, request: CaptureRequest): Promise<CaptureResult> {
  await mkdir(directory, { recursive: true })
  const output = join(directory, 'capture-' + Date.now() + '.webm')
  const seconds = Math.min(600, Math.max(1, Math.round(request.seconds)))
  await new Promise<void>((resolve, reject) => {
    const child = spawn('ffmpeg', argsFor(request, output), { stdio: ['ignore', 'ignore', 'pipe'] })
    let stderr = ''
    child.stderr?.on('data', chunk => { stderr += String(chunk) })
    child.once('error', error => reject(new Error(`ffmpeg 不可用：${error.message}`)))
    child.once('exit', code => {
      if (code === 0) { resolve(); return }
      reject(new Error(`ffmpeg 录制失败（exit ${String(code)}）：${stderr.trim().slice(-400) || 'no output'}`))
    })
  })
  const info = await stat(output)
  if (info.size === 0) {
    await rm(output, { force: true })
    throw new Error('录制产物为空（可能是当前会话没有可见桌面）')
  }
  return { path: output, bytes: info.size, seconds, platform: process.platform }
}
