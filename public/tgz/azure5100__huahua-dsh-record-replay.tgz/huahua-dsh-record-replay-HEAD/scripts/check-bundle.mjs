#!/usr/bin/env node
/**
 * Bundle boundary guard. The browser half must never pull host-only modules:
 * DSH's client-modules table ships no Node builtins, so a stray
 * require("node:path") in lib/client.js blocks the whole web boot
 * (2026-11-08 incident: record-replay 0.3.5 failed to start DSH).
 *
 * Run after every build; exits non-zero so CI and pre-commit catch drift.
 */
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const bundle = join(root, 'lib', 'client.js')
const source = readFileSync(bundle, 'utf8')

const failures = []
const requires = source.match(/require\s*\(/g) ?? []
if (requires.length > 0) failures.push(`lib/client.js contains ${String(requires.length)} require() call(s)`)
const builtins = source.match(/node:(path|os|fs|child_process|http|crypto|stream|url|util)/g) ?? []
if (builtins.length > 0) failures.push(`lib/client.js references Node builtins: ${[...new Set(builtins)].join(', ')}`)

// The client must reach the API through the dependency-free constant module.
if (!source.includes('/api/dsh-record-replay')) failures.push('lib/client.js is missing the API base constant')

if (failures.length > 0) {
  console.error('bundle guard: FAILED')
  for (const failure of failures) console.error('  - ' + failure)
  console.error('\nClient half must not import host modules (routes.ts / paths.ts / stores).')
  console.error('Import type-only shapes or src/api-base.ts instead.')
  process.exit(1)
}
console.log('bundle guard: ok (' + String(Math.round(source.length / 1024)) + ' KB, no Node builtins)')
