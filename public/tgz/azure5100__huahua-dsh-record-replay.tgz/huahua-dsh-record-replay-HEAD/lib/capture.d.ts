export interface CaptureRequest {
    /** Seconds to record (clamped to 1..600). */
    seconds: number;
    /** Frames per second (clamped to 1..30). */
    fps?: number;
    /** Downscale the long edge to this width (clamped to 320..2560). */
    width?: number;
}
export interface CaptureResult {
    path: string;
    bytes: number;
    seconds: number;
    platform: string;
}
/** Whether this host can record at all (ffmpeg present). */
export declare function captureSupported(): Promise<boolean>;
/** Record the screen for `seconds` and return the produced file. */
export declare function captureScreen(directory: string, request: CaptureRequest): Promise<CaptureResult>;
//# sourceMappingURL=capture.d.ts.map