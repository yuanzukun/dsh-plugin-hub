/**
 * dsh-record-replay — host half. Scans the DSH session library (the JSONL
 * transcripts the persistence backend records automatically), serves the
 * /api/dsh-record-replay route family (library, timeline, replay-pack
 * export/import), keeps the imported-pack store under ~/.dsh/replay-packs,
 * and announces the capability to agents via a system-prompt section.
 * The browser half (./client) renders the replay panel. Everything rides
 * official SDK packages plus vendored fzstd — no dsh source changes.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Stable cordis plugin name. */
export declare const name = "record-replay";
/** Services required before the surfaces can mount. */
export declare const inject: string[];
/**
 * Settings namespace of the record-replay capability. Spelled here rather
 * than imported: the browser half spells the same value and must not depend
 * on a Host package.
 */
export declare const RECORD_REPLAY_SETTINGS_NAMESPACE = "dsh-record-replay";
/** Plugin config, validated by the same-named schemastery schema. */
export interface Config {
    /**
     * When true (default), a system-prompt section announces the plugin to
     * every agent. Set false to keep it silent.
     */
    announceToAgent?: boolean;
    /** Master switch for the plugin (routes + prompt section). */
    enabled?: boolean;
}
export declare const Config: z<Config>;
/** Model-facing announcement: plugin presence, capabilities, and limits. */
export declare const RECORD_REPLAY_GUIDANCE: string;
/**
 * Mount the session store, routes, and announcement.
 * @param ctx - host plugin context carrying webServer/systemPrompt.
 * @param config - resolved plugin config (schema defaults applied by the loader).
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map