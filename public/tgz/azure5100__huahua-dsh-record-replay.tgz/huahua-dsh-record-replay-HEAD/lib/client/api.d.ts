/**
 * Browser-side API client for the /api/dsh-record-replay route family.
 * Plain fetch, same origin. Types are shared from src/types.ts (pure types
 * only - safe for the client bundle).
 */
import type { InstalledSkill, PackSummary, RecordingMeta, RecordingSummary, ReplayPack, SessionMeta, SessionSummary, TimelineItem } from '../types.ts';
/** Error carrying the route JSON error message. */
export declare class ReplayApiError extends Error {
    constructor(message: string);
}
/** Timeline payload for one session (GET /session). */
export interface SessionTimeline {
    summary: SessionSummary;
    meta: SessionMeta;
    items: TimelineItem[];
}
/** The browser half data entry point. */
export declare class ReplayApi {
    /** Whether the host process can record the screen (ffmpeg present). */
    captureSupported(): Promise<{
        supported: boolean;
        platform: string;
    }>;
    /** Ask the host to record the screen for N seconds; returns the produced file path. */
    captureScreen(request: {
        seconds: number;
        fps?: number;
        width?: number;
    }): Promise<{
        path: string;
        bytes: number;
        seconds: number;
        platform: string;
    }>;
    /** Turn a host-recorded file into a recording entry (video uploaded, frames sampled in the browser). */
    importCapture(title: string, path: string): Promise<{
        recording: {
            id: string;
        };
    }>;
    createRecording(title: string): Promise<RecordingMeta>;
    uploadRecordingVideo(id: string, blob: Blob): Promise<void>;
    uploadRecordingFrame(id: string, name: string, blob: Blob): Promise<number>;
    listRecordings(): Promise<RecordingSummary[]>;
    getRecording(id: string): Promise<RecordingMeta>;
    deleteRecording(id: string): Promise<void>;
    /** URL of a recording's video (Range-enabled, for <video> playback). */
    videoUrl(id: string): string;
    /** URL of one sampled frame (usable by the describe_image tool). */
    frameUrl(id: string, name: string): string;
    installSkill(content: string): Promise<InstalledSkill>;
    listSkills(): Promise<InstalledSkill[]>;
    listSessions(): Promise<SessionSummary[]>;
    getSession(id: string): Promise<SessionTimeline>;
    /** Trigger a replay-pack download for one session (browser download). */
    exportPack(sessionId: string, notes?: string): void;
    listPacks(): Promise<PackSummary[]>;
    importPack(pack: ReplayPack): Promise<PackSummary>;
    getPack(id: string): Promise<ReplayPack>;
    deletePack(id: string): Promise<void>;
}
//# sourceMappingURL=api.d.ts.map