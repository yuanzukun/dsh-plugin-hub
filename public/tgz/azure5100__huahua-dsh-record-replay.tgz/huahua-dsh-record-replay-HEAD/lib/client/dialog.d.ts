/**
 * In-app dialogs. Electron (and sandboxed webviews) do not implement the
 * blocking window.prompt / window.confirm / window.alert: calling them throws
 * "prompt() is not supported." on this shell. These helpers render a small DOM
 * overlay and resolve a Promise instead of blocking the thread.
 */
/** Replacement for window.prompt — returns '' when dismissed (same contract). */
export declare function askText(title: string, initial?: string, message?: string): Promise<string>;
/** Replacement for window.confirm. */
export declare function askConfirm(title: string, message?: string, confirmLabel?: string, danger?: boolean): Promise<boolean>;
/** Replacement for window.alert. */
export declare function tell(title: string, message?: string): Promise<void>;
//# sourceMappingURL=dialog.d.ts.map