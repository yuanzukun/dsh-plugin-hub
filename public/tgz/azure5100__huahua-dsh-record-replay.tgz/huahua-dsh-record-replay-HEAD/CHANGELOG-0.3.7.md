## 0.3.7 — 明确 ffmpeg 版本要求（宿主录屏依赖）

宿主侧录屏依赖 `ffmpeg`，但**版本差异会导致录出空文件**：2018 年的 `N-92722` 在 `gdigrab` + `libvpx` 组合下会报
`not enough frames to estimate rate`，产物 0 字节。

### 本版

- README 增加「ffmpeg 版本要求」章节：**6.0+**，附检查命令与 Store 占位符排查
- 记录实测：8.0.1（gyan.dev essentials）正常，3 秒抓屏 → 272 KB WebM（VP8 / 1280×800）

### 本机环境处理（一次性，不属于代码）

| 位置 | 原状态 | 处理 |
| --- | --- | --- |
| `C:\Users\cosmo\bin\ffmpeg.exe` | 2018 `N-92722`（61 MB） | 用 8.0.1 覆盖，旧版留 `.bak-2018-N92722` |
| `C:\Users\cosmo\bin\ffprobe.exe` | 旧版 | 同步覆盖为 8.0.1 |
| `...\WindowsApps\ffmpeg.exe` | Store 占位符（119 MB，执行返回 null） | 改名为 `.disabled-20261108`，避免 PATH 顺序变化时被命中 |
| `C:\ProgramData\chocolatey\bin\ffmpeg.exe` | 8.0.1（PATH 首位） | 保持 |

处理后 `where ffmpeg` 只剩两个真实 8.0.1 副本，`spawn('ffmpeg')` 稳定命中新版。