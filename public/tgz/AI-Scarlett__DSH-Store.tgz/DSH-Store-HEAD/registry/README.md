# DSH-Store GitHub Plugin Registry

`catalog.json` 是旧版 DSH-Store 可读取的 schemaVersion 1 完整兼容目录：它为每个插件保留旧版
验证器、搜索、权限展示和固定来源操作所需的有界字段，并用 `indexPath`、`indexSha256`、
`indexBytes` 和 `indexEntryCount` 固定 `catalog-index.json`。
`catalog-index.json` 是 DSH-Store 与 GitHub Pages 市场页共同读取的轻量主索引；每个插件的完整记录
位于 `catalog/details/<插件编号>.json`。主索引通过插件编号把名称、版本、推荐状态、顺序和 GitHub
地址映射到对应详情，新商城验证兼容目录后加载索引，再按当前 20 条页面或详情请求懒加载详情。兼容目录和
主索引都保持在 2 MiB 内，单个详情文件保持在 512 KiB 内。
目录只接受 GitHub 仓库，不接受 npm-only、任意下载 URL、本地路径或浮动安装目标。

新增或更新插件必须通过 Pull Request 修改一个条目，并同时满足：

1. `repositoryUrl` 是公开的 `https://github.com/<owner>/<repo>`；
2. `manifestPath` 指向的 `package.json` 声明 `dsh.bundle.patch`；单仓库多包可同时声明
   `installPath`，安装时仍固定到同一个 Commit；
3. `commit` 是 40 位不可变 Git Commit；
4. `version` 与该 Commit 的 manifest 一致；
5. `entryIds` 与 Bundle Patch 插入的 DSH ID 一致；
6. 明确列出 `preinstall/install/postinstall/prepare` 生命周期脚本；
7. 不禁用、替换或重复安装任何 `@deepseek-ai/*` 官方组件；
8. `npm run validate:registry` 通过。

## GitHub 上架申请预检

[上架申请表](https://github.com/AI-Scarlett/DSH-Store/issues/new?template=plugin-submission.yml)
只要求一个公开 GitHub 项目地址。Issue 创建、编辑或重新打开后，
`.github/workflows/plugin-submission.yml` 会调用 `scripts/check-plugin-submission.mjs`，自动固定默认
分支当前 Commit，读取仓库树、`package.json`、README 和 Bundle Patch，并提取包名、版本、
许可证、入口 ID、生命周期脚本和已声明的兼容范围。若 monorepo 中发现多个 DSH 插件，
机器人会列出候选目录；提交者只需补充可选的 `Plugin path`。

同一工作流还会对固定 Commit 做一轮有界静态安全扫描：优先读取 manifest、Bundle Patch、
`src`/`lib`/运行时代码和脚本，最多扫描 150 个文本源码文件，单文件上限 400,000 字节；不下载
依赖，也不执行插件的 install、prepare、build、test 或运行时代码。硬编码密钥、常见临时外传
端点、针对系统/用户目录的破坏性命令以及挖矿特征会阻断提交；动态执行、子进程、Shell、远程
安装和混淆等常见 CLI 能力只产生警告并进入机器人清单。命中文件数、单文件体积、符号链接或
目录树上限时，回执必须明确显示“扫描面不完整”，不能把没读到的源码当成安全通过。

预检结果保存在 Actions 摘要和 Artifact。仅首次提交且该用户从未被联系过时，才通过全局人员台账发送一次结果；编辑、重开或另一个项目的提交不会重复评论或变更通知标签。

该门禁是固定源策略检查，不是安全审计或 DSH 运行验证。只有 canonical GitHub、完整 Commit、
manifest/repository/license 一致、明确文件清单、无生命周期脚本和运行依赖、Bundle/入口唯一，
并且完整有界运行时源码没有文件、网络、命令、凭据、原生制品或受保护 DSH 行为信号时，才会
自动生成 `source-verified` Catalog PR；现有检查与 CodeQL 通过后自动 squash 合并。其他项目自动
拒绝、隔离或以 `blocked` 展示，不会进入受保护安装通道，也不会要求所有者机械点击确认。

提交前建议使用 [`build-dsh-plugin`](https://github.com/AI-Scarlett/build-dsh-plugin) 制作标准
Bundle、生成 Catalog 候选或执行只读上架预检。它同样遵循“不修改 DSH 核心、不写真实
Profile、不用低层测试冒充运行验收”的边界。

## 提交者自检清单

- 公开 GitHub 仓库，且目标包能够固定到 40 位 Commit；
- `package.json` 具有合法包名、语义化版本和可解析的 `dsh.bundle.patch`；
- Bundle Patch 入口 ID 唯一，不禁用、遮蔽或冒充官方组件；
- manifest 与实际许可证、生命周期脚本、Node.js/DSH 兼容声明一致；
- README 说明用途、安装/启用方式、外部依赖、权限和已知风险；
- monorepo 能唯一定位插件目录；第三方包不使用 `@deepseek-ai/*` 命名空间；
- 高权限、原生构建或外部服务明确披露，并准备一次性 Profile 的安装与功能验收证据；
- 插件在“热门、有用、有趣”至少一个维度具有收录价值。

自动准入只证明固定源码策略门槛；一次性 Profile 安装、可见性、运行效果、独立安全审核和
作者认证仍是不同证据层级。自动化不得把未执行的运行验收写成 `passed`。

## 作者整改通知

每八小时扫描仍会复检所有项目并公开 Catalog、候选状态和确定性原因。
主动联系按**人**全局去重：先核实 GitHub 不变的数字用户 ID，一个人跨所有项目仅一次。
GitHub 用户名只作为别名；新仓库、新版本、改名、代码变化、关闭或重开 Issue、任务重试，
都不会恢复已使用的联系名额。组织或身份不明确的项目不猜测收件人。

历史 Issue、通知评论、提交预检回复和人工联系已导入
[历史记录](author-contact-history.json)。实时联系记录统一存放在
[author-contact-state 分支](https://github.com/AI-Scarlett/DSH-Store/blob/author-contact-state/contacts.json)。
发送前必须以文件 SHA 为条件原子登记名额，然后只执行一次消息请求；超时、失败、取消或
送达不确定均保留名额，禁止盲目重发。记录缺失、历史不完整或身份有歧义时不发送。

只有作者明确作出正向回复、提出具体继续沟通请求，才允许针对该请求继续回复。
致谢、表情、沉默、代码修复及新的项目申请均不是授权。人工处理必须把请求的用户 ID、
评论 ID、原文 SHA256、原文引用、请求范围与拟回复正文写入
`registry/author-replies/<request>.json`，经检查合并至 main 后使用
`node scripts/reply-author-contact.mjs --plan registry/author-replies/<request>.json`。
计划字段为 `schemaVersion: 1`、`operation: requested-author-reply`、`repository`、
`issueNumber`、`userId`、`requestCommentId`、`requestBodySha256`、
`review: { decision: explicit-request-to-continue, requestQuote, scope }` 和 `responseBody`。
回复命令回读 main 上的原计划，并核对作者最新原文；一次请求只消费一次，不构成永久豁免。
任何更晚的撤回请求都使旧许可失效；已记录停止联系的人不会收到自动回复。
解除停止状态需要另行核实对方新的明确请求并审查，不得回滚旧记录。

Catalog 通知和插件提交预检共用此记录及并发组。预检在编辑、重开时仍生成 Actions
报告和 Artifact，但不重复评论、改写旧通知或反复打标签。初始预检回复也消耗该用户的
全局名额。旧通知不再自动重开、刷新正文或发送关闭提醒；结果在商城与公开候选库查看。
人工 GitHub 评论、PR 沟通及其他渠道同样受此规则约束，不能通过换项目或渠道绕过。

作者通知完成后，Catalog 工作流会直接调用 `catalog-run-report.yml` 生成所有者报告。两个可复用
工作流都接收当前 Catalog Run ID 和 Run Attempt，并只读取同一次 Catalog Run 中的精确 Artifact，
不依赖 `workflow_run`。失败扫描也会报告失败阶段而不是静默跳过。报告通过固定 Issue 评论
`@AI-Scarlett`，按 Catalog Run ID 只发送一次普通报告；三小时看门狗补跑 Catalog 时，会先等待与
本轮唯一请求 ID 对应的新 Run 完成，再用该新 Run ID 直接补调用报告工作流，不能回退到上一次扫描。
若内联报告已经成功，补调用会按相同幂等标记跳过。报告列出 GitHub 整改消息
涉及的项目数和 GitHub 通知邮件触发项目数。GitHub 是否实际投递邮件取决于被提及维护者的个人
通知设置，仓库无法读取私人邮箱回执，因此必须显示“送达未验证”，不能把触发数量表述成实际送达数量。

作者在修复单中明确指出自动化、扫描或通知属于 DSH Store 问题时，`author-notifications.yml` 会先用
已核验的 GitHub 不变用户 ID 采集最新评论，再由 `catalog-run-report.yml` 在同一个所有者报告 Issue
中单独发送一次 `@AI-Scarlett` 站内评论。评论按 `dsh-author-feedback:v1` 加作者评论 ID、正文哈希
和 Issue 号去重；因此后续三小时报告更新不会重复触发通知。该评论只把问题交给仓库所有者人工处理，
不会自动回复作者，也不会改变“一位用户仅一次主动联系”的规则。GitHub 通知系统是否实际送达邮箱仍
无法由仓库验证。分类只检查该作者最新的非空评论，邮件转发的原机器人内容和 Markdown 引用会先剥离，
并且必须出现明确的问题、误报、重复通知、干扰、错误或修复请求信号；致谢、整改完成、接受 guarded
状态、普通复检请求和停止联系不会把历史评论重新升级为新的 Store 问题。

每轮计划会把 Candidate Registry 的全部 canonical 仓库逐一归入机器可读台账，去重后只能处于
`direct-remediation`、`public-reviewing`、`public-remediation`、`public-deferred` 或
`public-discovery-only` 之一；台账条目数、候选记录数和未覆盖数必须通过不变量校验，未覆盖不为 0
时拒绝执行。完整候选仍公开在 `registry/candidates.json` 和商城候选视图，因而不会从发现与复检链路遗漏。

全量覆盖不等于无差别群发。主动搜索中的普通项目不会因为关键词误命中而收到 `@mention`；GitHub
403/404/429、限流、超时、连接失败和默认分支移动等基础设施状态也不会归责给作者。凡是明确属于
DSH、状态为 `rejected`、并且已经有非基础设施类确定性整改原因的候选，不论来自用户提交、固定
Commit 复核还是自动雷达，只有通过全局人员联系门禁后才进入一次性直接通知队列；`reviewing`、仅发现记录和没有确定结论的
项目仍只公开展示。通知必须带具体整改原因、build-dsh-plugin 和商城状态入口，不发送纯推广消息，
也不在第三方仓库批量开 Issue。同一人跨所有 canonical 仓库仅联系一次。每轮最多
新建 10 单，以 `更新暂缓 → 兼容性下架 → 候选未通过 → Catalog blocked` 轮转选取。该流程只读
固定源码，不执行第三方代码，也不把修复后的再次通过承诺为真实 Profile 安装或运行验收。

Candidate Registry 只保留仍有单独复核价值的记录。`rejected` 候选按 canonical 仓库哈希分成
24 个批次，每次八小时扫描其中一批，并只读取记录内完整 Commit 的有界仓库树与 `package.json`。
如果候选已经存在其他确定性门禁失败，同时没有任何 manifest 对官方最新三个 DSH 版本给出精确
`compatible` 声明，就直接从候选库删除；当轮报告仍保留清理清单；仅未联系过且身份已核实的作者可能收到一次通知。
仅因最新三版兼容性不足而暂时下架的 Catalog 条目使用 `reviewing` 候选，不适用该删除规则。
GitHub 暂时失败、仓库树截断或 manifest 数量超出有界检查面时保留候选并稍后重试，不把“没读到”
冒充“不兼容”。24 个批次在正常八小时调度下约八天覆盖一轮，无需在候选文件中保存扫描游标。

## 八小时 Catalog 自动化与三小时自愈

- `catalog-automation.yml` 在 UTC 00:05、08:05、16:05 扫描新插件，并检查所有历史 Catalog
  条目的原项目版本；版本权威源是 canonical GitHub 仓库当前默认分支的完整 Commit，以及该
  Commit 下条目 `manifestPath` 指向的 `package.json`；
- 每轮从官方 npm Registry 完整元数据读取 `@deepseek-ai/dsh` 的 `latest` 标签及其之前最近两个
  未弃用发行版，组成最新三个版本窗口；权威源不可用、元数据异常或不足三个版本时整轮失败关闭，
  不使用 Catalog 推测值执行上下架；
- 最新三个官方版本是复核窗口。`compatibility.latestWindow` 标记 `current` 或
  `recheck-required`，保留同一固定 Commit 的历史精确记录和项目页面。所有版本均无精确兼容记录时
  转为可见 `blocked`，不再因窗口滚动直接隐藏项目；只恢复本策略产生的 hold，不恢复作者下架。
- 安装、更新、迁移必须匹配本机实际 DSH 完整版本的 `dshReleases: compatible`，宽泛范围和其他版本
  的成功记录均不能授权操作。计划和执行阶段分别只读本机官方 manifest；宿主改变时计划失效。
- DSH Alpha.4 优先读取 manifest 的 `engines.dsh`；缺少该字段时才检查全部 DSH peer。
  范围声明和逐版本 `dshReleases` 必须一致，不能以范围命中代替精确记录或真实运行验收。
- 作者在新固定 Commit 的 `dsh.compatibility.dshReleases` 补充声明无需升级 SemVer。源变更后不沿用
  旧 Commit 的验收或兼容结论，未声明版本仍是 `unknown`。
- 提交预检和自动收录共用 `bounded-source-v3`：最多 512 个运行源码文件，单文件 4194304 字节
  （4 MiB），总量 8388608 字节（8 MiB），包内树条目上限 1200。此前商城自身已有这组预算，现统一应用。
  超限按文件、总量、数量分别返回 rule、file、actual、limit 和责任方 `store-scanner`；不要求作者拆包、
  压缩或删除功能。继续扫描预算内文件，负面能力在覆盖不完整时保持未知，不能据此批准安装。
- 商城分表生成的 `registry/catalog/details/<插件编号>.json` 等已验证静态数据保留原有精确路径例外；
  不扩展到第三方，也不扩展到脚本、嵌套文件或未知 JSON。
- `exports` 单星号目标只在固定完整 Git 树中展开，检查每个命中文件已分发、非符号链接且不越界；
  未命中、复杂模式、截断和歧义保持阻止。
- Bundle 使用有界、不执行的 YAML 子集解析器。新增入口 ID 参与所有权冲突；`id + config` 是配置覆盖
  目标，不占有该 ID，必须单独审阅整段 config 替换影响。嵌套 config 内的 ID 不成为入口。
  删除、停用、未知选择器、别名、标签、重复键和歧义语法不能自动通过。
- 原项目 SemVer 高于商城版本，或版本相同但默认分支出现新 Commit 时，候选 Commit 都必须是
  旧 Commit 的有界直接后继，并在包名、仓库、manifest 路径、安装路径、Bundle 入口和许可证
  保持一致后进入同一套固定源更新审查；
- `source-verified` 更新必须继续满足完整低风险自动策略；`user-reviewed` 必须有新 Commit 的专项审阅记录才能更新安装目标，历史风险许可不会继承；`external-only`、blocked
  和 unlisted 条目只刷新可追溯的项目元数据，不会因此获得安装资格；
- 版本或固定 Commit 写入后，旧来源的安装、运行、安全和精确兼容证据全部重置为 `unknown`，
  不把历史验收沿用到新来源；同版本源码变化通过完整审查后移动 Catalog 固定 Commit，使未安装
  用户直接安装新 Commit，并允许新的精确兼容声明恢复可逆下架；已安装相同版本的用户不会获得
  商城更新计划，只能按界面提示使用 GitHub 完整 Commit 手动覆盖；
- Catalog 自动 PR 合并后，`catalog-automation.yml` 会绑定已验证的 merge Commit，立即调度并等待
  对应 `pages.yml` Run 成功；无 Catalog 变更时，Pages 仍按三小时窗口第 25 分钟兜底重建；
- 两台服务器的 systemd timer 仍按三小时窗口第 47 分钟校验清单、哈希、首页与 Catalog，必要时原子切换；
- `catalog-automation.yml` 直接调用作者通知与所有者报告可复用工作流，所有输入和 Artifact 均绑定当前 Run ID 与 Attempt；
- 作者通知每轮仍最多新建 10 个外部整改项；已有修复单的更新、源码追踪基线和关闭动作共享
  500 条有界计划上限，计划生成、维护者解析和实际写入使用同一常量，避免 Catalog 扩大后因旧的
  100 条解析器上限让成功的自动更新整轮标红；
- 已进入修复台账的仓库若在通知时已删除、迁移或因法律原因不可用（GitHub 404/410/451），
  维护者解析仅回退到台账中的仓库所有者名，不让一个失效仓库中断其他通知；403、429、5xx 和
  网络故障仍失败关闭并留待重试；
- `catalog-run-report.yml` 立即发布一次按 Catalog Run ID 去重的所有者 `@mention` 报告，不依赖 `workflow_run`；
- `marketplace-watchdog.yml` 仍按三小时窗口第 55 分钟核验 Catalog 以及 GitHub、Pages、国际站、国内站；补跑时等待精确的新 Run 完成并直接补调用其报告；
- 上一轮缺失、失败、超过九小时或公共目录不一致时，自动重跑 Catalog 或 Pages；
- 所有 Catalog 写入绑定 base Commit、文件 SHA-256、外部备份、机器计划 ID 和精确文件范围。

公开商城首页和插件目录会读取 GitHub Pages 上的 `automation-status.json`，分别显示最近一次
Catalog 扫描、四端巡检、扫描新增数、历史版本检查数、发现的高版本数，以及最近自动新增和
版本更新的插件名称、旧版本、新版本与审查策略，并链接到对应的 GitHub Actions 运行记录。
扫描成功但没有合格新增或版本更新时会明确显示 0，不把“运行成功”和“发生变更”混为一谈。
状态文件只承载公开运行证据，不进入 Catalog 权威文件，也不会触发服务器发布备份轮转。

## 中文名称与搜索

每个可信 Catalog 条目的 `name` 必须使用 `中文名（English Name）` 格式，`description` 必须包含
面向普通用户的中文用途说明，并通过 `searchTerms` 提供中文用途、常见说法、分类词和英文包名等
搜索别名。自动发现的新条目在写入 Catalog 前执行同一套本地化规则；格式或中文搜索词缺失时，
`npm run validate:registry` 失败关闭，不允许自动合并。

商城搜索同时匹配中文名、英文名、中文用途、中文别名、包名、仓库、分类和权限信息。名称与搜索词
是正式 Catalog 数据，不是浏览器临时翻译，因此 GitHub、Pages、国际站、国内站和 DSH 内商城会
读取到同一份结果。

## 详情元数据

商城详情由 GitHub 上与兼容桥、主索引同一提交的独立详情文件提供。主索引条目至少包含 `id`、
`nameZh`、`nameEn`、`version`、`featured`、`order`、`repositoryUrl` 和由编号确定的
`detailPath`；详情文件必须显式声明：

- `details.pluginType`、`installSource`、`license`；
- 文件、网络、命令与凭据访问，以及汇总后的权限等级；
- 外部运行依赖与审核状态；
- `compatibility` 中的 DSH、Node.js、系统和 Profile 范围。

版本矩阵只接受仍有公开发行物的历史别名 `rc.7`、`rc.8`；新增版本必须使用完整
SemVer 键，例如 `0.1.1-rc.2`，避免不同发布线的 `rc.1` 混淆。商城从官方 npm Registry
读取 `@deepseek-ai/dsh` 最新版本；读取超时或失败时退回目录已有版本，不影响插件列表加载。
目录中的精确 `dshReleases` 是兼容证据；新版本只有范围匹配而没有精确证据时显示
“范围支持·待验证”，不会自动标为兼容，也不公开不存在发行物的 rc.5/rc.6。`install`、`start`、`uninstall`、`rollback`
四项 `dshOperations` 也必须逐版本提供真实证据，缺少记录时保持 `unknown`。
自动上下架使用官方 `latest` 向前最近三个未弃用发行版作为滚动窗口；范围声明不能替代精确记录。
该规则只决定商城是否继续可安装；作者 manifest 的逐版本声明属于来源兼容声明，不把它解释为
真实 Profile 或运行时验收，`dshOperations` 仍需独立证据。

可信证据分为四种状态：`verified` 表示该道门已经有对应的完整证据，`partial` 表示只验证了明确边界内的一部分（例如一次性 Profile 安装、契约或固定源策略检查），`unknown` 表示尚未取得可引用证据，`failed` 表示检查未通过。`partial` 不得被解释为完整运行验收或独立安全审计；商城会把它单独显示为“部分验证”，避免把产品已有的可复核能力压成“未知”，也避免把局部证据夸大成完整结论。

为保证已安装的 0.8.2 能在商城内完成自举升级，schemaVersion 1 允许把 `partial` 编码为 `status: "unknown"` 与 `evidenceStatus: "partial"`。旧客户端会忽略新增字段并保守显示“未知”，当前客户端和官网使用 `evidenceStatus` 恢复“部分验证”语义。该兼容编码不能省略 `method`、`checkedAt` 或 `evidenceUrl`，也不能与 `verified` 等其他 wire status 组合。

权限值依据固定 Commit 的 manifest、README 与运行时代码信号保守填写。无法确认时必须
使用 `unknown` 或空兼容范围，不得把“未发现”写成“不访问”。`automated-scan` 和
`author-verified` 只描述来源核验层级，不代表完成安全审计。客户端优先显示 GitHub Raw
目录；随包副本只用于网络失败时的只读回退。

权限等级使用保守汇总：完全不访问文件、网络、命令和凭据时才标为 `low`；仅有范围
明确的只读、插件私有状态写入、指定服务或受限命令时可标为 `medium`；触及 Profile、
会话或其他敏感持久状态，可访问任意网络、任意 Shell、凭据，或承担插件生命周期管理
时标为 `high`。没有足够证据时使用 `unknown`，不能根据“代码中暂未搜索到”推断为
`none`。`installSource` 描述目录分发来源；已安装副本的 npm、GitHub 或本地 Bundle
来源由 Profile 扫描结果另行显示。

## 分类、推荐与上下架

- `categories` 必须引用 `registry.categories` 中已声明的分类；页面会自动生成分类筛选；
- `featured: true` 表示推荐，在每个分类中优先显示，但不会绕过来源和安全检查；
- `status: approved` 为正常上架；`blocked` 为商城不可安装，但保留 GitHub 手动安装入口
  和风险原因；手动安装不受商城事务、健康检查或回滚保护；
- `status: unlisted` 为下架：公共商城隐藏，已安装用户仍可停用或卸载；
- `installCount` 是可选聚合快照。客户端不得持有 GitHub 写令牌，自动计数必须通过
  独立的匿名计数服务汇总后再更新，不能让安装端直接写 `catalog.json`。

目录收录不等于完成安全审计。插件代码会以 DSH 进程权限运行，使用者必须在安装计划
中再次查看仓库、Commit、生命周期脚本和影响范围。


### 固定源码专项审阅与身份迁移

`registry/admission-reviews.json` 通过 CI PR 维护。每条记录绑定 canonical repository、完整 Commit、
scanner/policy、manifest 与包身份、入口与覆盖目标、全部已读源码摘要、能力信号和安全命中项。
有完整已知文件/网络/命令/凭据能力的项目可给出明确权限和理由，得到 `reviewed`；运行依赖仍须独立供应链审阅；安装脚本、
未界定动态加载、缺失源码或受保护 DSH 操作均不能靠“接受风险”跳过。拒绝与审阅要求独立于覆盖和源契约。
扫描器普通环境目录值（如 `DSH_HOME`）不再直接归类为凭据，动态环境访问仍需复核。
浏览器创建 script 元素并设置 src、或 HTML 引用外部 CDN 脚本，同样属于网络与动态运行代码边界；
不能因为没有 fetch/import/require 调用就当成自包含、零网络能力。此类代码加载需单独审阅。

合成密钥样本没有按 tests/docs 路径忽略的规则。只有匹配当前完整源码的 rule + file + line + SHA256
专项 disposition 才可排除该项；记录必须给出理由与证据链接。报告只保留位置和摘要，不输出密钥或源码片段。
这套记录不代表独立安全审计或真实运行验收。审阅只对绑定的固定 Commit 生效，不能凭策略升级批量批准旧条目。

`registry/catalog-migrations.json` 是明确的元数据迁移通道：绑定旧身份哈希、旧/新 Commit、from/to 包名、
manifest/install 路径与许可证、审阅人和证据；先解析批准的新 manifest 路径，再重跑全部收录门禁。
迁移不赋予安装资格；旧身份由 Git 历史和机器计划保留。没有记录时包名、路径和许可证变化继续阻止。

`npm run reassess:admission` 是覆盖完整 Catalog 的只读元数据排查，明确标记 sourceReview=not-performed，
不重新执行第三方代码、不改 Catalog，也不推断安装或安全结论。实际重新收录只能通过新鲜的策略工作流。
`npm run verify:admission-plan` 校验这次源变更的 base、scope 和文件哈希；回滚使用新的 CI PR，联系台账不回滚。
