#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { githubClient } from './author-contact-http.mjs'

const MAX_ISSUES = 2500
const MAX_ITEMS = 100
const MAX_COMMENT_PAGES = 20
const STORE_CONTEXT_PATTERNS = [
  /dsh[\s-]*store/i,
  /automaticFollowups/i,
  /自动(?:化|复检|更新|通知)/i,
  /扫描(?:器|逻辑)?|阻断条件/i,
  /@mention|recheck|follow[\s-]?up|workflow|catalog/i,
]
const EXPLICIT_STORE_PROBLEM_PATTERNS = [
  /\b(?:bug|problem|error|broken|wrong|incorrect|false[\s-]+positive|spam|interfer(?:e|ence)|disturb(?:ance)?|unwanted|violat(?:e|ion)|not\s+meant|re-?notify)\b/i,
  /问题|错误|误报|重复(?:的)?(?:通知|评论|消息|mention|@)|干扰|骚扰|不应|不该|不对|不正确|不一致|缺陷|故障|打扰/i,
  /(?:为什么|为何|能否|可否).{0,80}(?:改|修复|停止|更正|说明|避免|调整)/i,
  /(?:请|希望).{0,80}(?:修复|停止|更正|避免|调整)(?:这个|该|此)?(?:问题|错误|误报|通知|评论|扫描|工作流)?/i,
  /\b(?:please\s+(?:fix|stop|change|correct|avoid|adjust)|could\s+(?:the\s+recheck|you)|can\s+you|would\s+(?:the\s+recheck|you)|should(?:n't|\s+not))\b.{0,120}(?:fix|change|stop|avoid|correct|explain|adjust|instead|notify|mention|recheck|scan|workflow)\b/i,
]

function requiredString(value, name, maximum = 65_000) {
  if (typeof value !== 'string' || value.length === 0 || value.length > maximum) throw new Error(`${name} is invalid`)
  return value
}

function integer(value, name) {
  if (!Number.isSafeInteger(value) || value < 1) throw new Error(`${name} is invalid`)
  return value
}

function array(value) {
  return Array.isArray(value) ? value : []
}

export function sha256(value) {
  return createHash('sha256').update(value).digest('hex')
}

// GitHub email replies can include the previous bot notification below the
// author's text.  Classify only the author's visible message so quoted
// `automaticFollowups`/workflow language cannot create a false Store alert.
export function authorFeedbackText(body) {
  const text = String(body ?? '').replace(/\r\n?/g, '\n')
  const separator = /(?:^|\n)\s*----\s*(?:回复的原邮件|原邮件|Original Message|Forwarded message|转发邮件)\s*----\s*(?:\n|$)/i
  const unquoted = text.split(separator, 1)[0]
  return unquoted
    .split('\n')
    .filter(line => !/^\s*>/.test(line))
    .join('\n')
    .trim()
}

export function isDshStoreProblem(body) {
  const text = authorFeedbackText(body)
  return STORE_CONTEXT_PATTERNS.some(pattern => pattern.test(text))
    && EXPLICIT_STORE_PROBLEM_PATTERNS.some(pattern => pattern.test(text))
}

export function isAdmissionRecheckRequest(body) {
  const text = authorFeedbackText(body)
  if (/不要再|停止联系|撤回|不(?:请求|申请).{0,30}(?:复核|复检|审核)|无需.{0,20}(?:复核|复检)|do not contact|stop contacting|withdraw|\b(?:not|no)\s+(?:requesting|request)\b/i.test(text)) return false
  return /请.{0,40}(?:复核|复检|重新审核|重新入库|重新收录)|(?:please|could you).{0,40}(?:recheck|re-review|review.{0,20}(?:commit|version|release))|\brequesting\s+(?:re-review|recheck)\b|\bre-review\s+request\b|请安排复检/iu.test(text)
}

function safeUrl(value) {
  requiredString(value, 'URL', 2_000)
  if (!/^https:\/\/github\.com\/[A-Za-z0-9._-]+\/[A-Za-z0-9._-]+(?:\/|#|$)/.test(value)) throw new Error('GitHub URL is invalid')
  return value
}

function canonicalIssue(value) {
  return {
    number: integer(value?.number, 'issue number'),
    title: requiredString(value?.title ?? '', 'issue title', 256),
    url: safeUrl(value?.url ?? value?.html_url),
    body: typeof value?.body === 'string' ? value.body : '',
    comments: typeof value?.comments === 'number' ? value.comments : null,
    author: value?.author && {
      id: integer(value.author.id, 'issue author id'),
      login: requiredString(value.author.login, 'issue author login', 40),
      nodeId: requiredString(value.author.node_id, 'issue author node id', 256),
    },
  }
}

function noticeRepositoryKey(body) {
  const match = /<!--\s*dsh-author-notice:v1\s+key=([A-Za-z0-9-]{1,39}\/[A-Za-z0-9._-]{1,100})\b/.exec(String(body ?? ''))
  return match?.[1] ?? null
}

function notificationTarget(issue, notificationTargets) {
  if (notificationTargets === null) return issue.author ?? null
  const key = noticeRepositoryKey(issue.body)
  if (!key || !notificationTargets || typeof notificationTargets !== 'object' || Array.isArray(notificationTargets)) return null
  const target = notificationTargets[key]
    ?? Object.entries(notificationTargets).find(([candidate]) => candidate.toLowerCase() === key.toLowerCase())?.[1]
  return target?.type === 'User' && Number.isSafeInteger(target.id)
    && typeof target.login === 'string' && typeof target.node_id === 'string'
    ? { id: target.id, login: target.login, nodeId: target.node_id }
    : null
}

function commentTime(comment) {
  const value = Date.parse(comment?.updated_at ?? comment?.created_at ?? '')
  return Number.isFinite(value) ? value : 0
}

function isHumanAuthorComment(comment, recipient) {
  const user = comment?.user
  return user?.type === 'User'
    && Number(user.id) === recipient?.id
    && String(user.node_id) === recipient?.nodeId
}

function excerpt(body) {
  return String(body ?? '')
    .replace(/\r?\n/g, ' ')
    .replaceAll('@', '＠')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 360)
}

export function validateAuthorFeedback(value) {
  if (value?.schemaVersion !== 1 || value?.source?.repository !== 'AI-Scarlett/DSH-Store') {
    throw new Error('author feedback source is invalid')
  }
  requiredString(value.observedAt, 'observedAt', 64)
  if (!Array.isArray(value.items) || value.items.length > MAX_ITEMS) throw new Error('author feedback items are invalid')
  const seen = new Set()
  for (const item of value.items) {
    integer(item.issueNumber, 'feedback issue number')
    integer(item.commentId, 'feedback comment id')
    if (seen.has(item.commentId)) throw new Error('duplicate feedback comment')
    seen.add(item.commentId)
    safeUrl(item.issueUrl); safeUrl(item.commentUrl)
    integer(item.author?.id, 'feedback author id')
    requiredString(item.author?.login, 'feedback author login', 40)
    requiredString(item.author?.nodeId, 'feedback author node id', 256)
    if (!['dsh-store-problem', 'admission-recheck'].includes(item.category) || item.needsManualReview !== true) throw new Error('feedback category is invalid')
    if (item.category === 'admission-recheck' && item.requiresTerminalDecision !== true) throw new Error('admission recheck requires a final decision')
    requiredString(item.bodySha256, 'feedback body hash', 64)
    if (!/^[0-9a-f]{64}$/.test(item.bodySha256)) throw new Error('feedback body hash is invalid')
    requiredString(item.excerpt, 'feedback excerpt', 400)
  }
  if (value.summary?.storeProblems !== value.items.filter(i => i.category === 'dsh-store-problem').length || value.summary?.manualReview !== value.items.length
    || value.summary?.admissionRechecks !== undefined && value.summary.admissionRechecks !== value.items.filter(i => i.category === 'admission-recheck').length) {
    throw new Error('author feedback summary is invalid')
  }
  return value
}

export async function collectAuthorFeedback({ github, repository = 'AI-Scarlett/DSH-Store', issues, observedAt, notificationTargets = null, resolutions = [] }) {
  if (repository.toLowerCase() !== 'ai-scarlett/dsh-store') throw new Error('feedback authority must be AI-Scarlett/DSH-Store')
  if (!Array.isArray(issues) || issues.length > MAX_ISSUES) throw new Error('managed issue snapshot is invalid')
  const items = []
  for (const rawIssue of issues) {
    const issue = canonicalIssue(rawIssue)
    if (issue.comments === 0) continue
    const recipient = notificationTarget(issue, notificationTargets)
    if (!recipient) continue
    const comments = await github.paginate(`/repos/${repository}/issues/${issue.number}/comments`)
    if (comments.length > MAX_COMMENT_PAGES * 100) throw new Error('author feedback comment bound exceeded')
    const latest = comments
      .filter(comment => isHumanAuthorComment(comment, recipient) && String(comment.body ?? '').trim())
      .sort((left, right) => commentTime(left) - commentTime(right) || Number(left.id) - Number(right.id))
      .at(-1)
    if (!latest) continue
    const recheck = isAdmissionRecheckRequest(latest.body)
    if (!recheck && !isDshStoreProblem(latest.body)) continue
    if (resolutions.some(r => r.requestCommentId === latest.id && r.userId === recipient.id && r.requestBodySha256 === sha256(latest.body))) continue
    const author = latest.user
    const body = String(latest.body)
    items.push({
      issueNumber: issue.number,
      issueTitle: issue.title,
      issueUrl: issue.url,
      author: { id: integer(author.id, 'comment author id'), login: requiredString(author.login, 'comment author login', 40), nodeId: requiredString(author.node_id, 'comment author node id', 256) },
      commentId: integer(latest.id, 'feedback comment id'),
      commentUrl: safeUrl(latest.html_url),
      createdAt: requiredString(latest.updated_at ?? latest.created_at, 'feedback timestamp', 64),
      bodySha256: sha256(body),
      category: recheck ? 'admission-recheck' : 'dsh-store-problem',
      ...(recheck ? { requiresTerminalDecision: true } : {}),
      needsManualReview: true,
      excerpt: excerpt(body),
    })
  }
  items.sort((left, right) => left.commentId - right.commentId)
  const result = {
    schemaVersion: 1,
    observedAt: requiredString(observedAt ?? new Date().toISOString(), 'observedAt', 64),
    source: { repository, managedLabel: 'author-action-required', identity: 'issue-author-immutable-user-id' },
    items,
    summary: { storeProblems: items.filter(i => i.category === 'dsh-store-problem').length, admissionRechecks: items.filter(i => i.category === 'admission-recheck').length, manualReview: items.length },
  }
  return validateAuthorFeedback(result)
}

export function parseArgs(argv) {
  const args = {}
  for (let index = 0; index < argv.length; index += 1) {
    const flag = argv[index]
    if (!flag.startsWith('--')) throw new Error(`invalid argument: ${flag}`)
    const value = argv[index + 1]
    if (!value || value.startsWith('--')) throw new Error(`${flag} requires a value`)
    const key = flag.slice(2)
    if (Object.hasOwn(args, key)) throw new Error(`duplicate argument: ${flag}`)
    args[key] = value
    index += 1
  }
  return args
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  if (!args.issues || !args.output) throw new Error('--issues and --output are required')
  const issues = JSON.parse(await readFile(resolve(args.issues), 'utf8'))
  const notificationTargets = args['notification-targets']
    ? JSON.parse(await readFile(resolve(args['notification-targets']), 'utf8'))
    : null
  const feedback = await collectAuthorFeedback({
    github: githubClient(process.env.GITHUB_TOKEN),
    issues,
    observedAt: args['observed-at'],
    notificationTargets,
    resolutions: JSON.parse(await readFile(resolve('registry/author-resolutions.json'), 'utf8')).resolutions,
  })
  await writeFile(resolve(args.output), `${JSON.stringify(feedback, null, 2)}\n`, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
  process.stdout.write(`AUTHOR_FEEDBACK_OK store_problems=${feedback.summary.storeProblems} manual_review=${feedback.summary.manualReview}\n`)
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) await main()
