import { validateAdmissionReviews } from '../src/admission-review.mjs'
import { validateCatalogMigrations } from '../src/catalog-migration.mjs'
import { validateAuthorResolutions } from '../src/author-resolution.mjs'
import { readFile, readdir } from 'node:fs/promises'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { validateDiscoveryIndexSnapshot } from '../src/discovery-index-validation.mjs'
import { blockedAuthorFingerprints, withdrawnRepositoryFingerprints } from '../src/author-exclusions.mjs'
import { validateCandidateRegistry } from '../src/candidates.mjs'
import { validateCommunityRecommendations } from '../marketplace/lib/community-recommendations.js'
import { assertCatalogLocalization } from '../src/catalog-localization.mjs'
import {
  assertLegacyCatalogCompatibility, loadCatalogFromFiles, MAX_CATALOG_DETAIL_RESPONSE_BYTES,
  MAX_CATALOG_INDEX_RESPONSE_BYTES, validateCatalog, validateCatalogBridgeIndex,
} from '../src/catalog.mjs'

const root = resolve(fileURLToPath(new URL('..', import.meta.url)))
const discoveryBytes = await readFile(resolve(root, 'registry/discovery-index.json'))
const discoveryGzipBytes = await readFile(resolve(root, 'registry/discovery-index.json.gz'))
const discovery = validateDiscoveryIndexSnapshot(discoveryBytes, discoveryGzipBytes)
const bridgeBytes = await readFile(resolve(root, 'registry/catalog.json'))
const indexBytes = await readFile(resolve(root, 'registry/catalog-index.json'))
if (bridgeBytes.length >= MAX_CATALOG_INDEX_RESPONSE_BYTES) throw new Error('legacy Catalog bridge exceeds the historical 2 MiB ceiling')
if (indexBytes.length >= MAX_CATALOG_INDEX_RESPONSE_BYTES) throw new Error('Catalog index exceeds the 2 MiB ceiling')
const bridge = validateCatalog(JSON.parse(bridgeBytes))
const index = validateCatalogBridgeIndex(bridge, JSON.parse(indexBytes), indexBytes)
const detailDirectory = resolve(root, 'registry/catalog/details')
const detailNames = (await readdir(detailDirectory)).filter(name => name.endsWith('.json'))
if (detailNames.length !== index.entries.length) throw new Error('Catalog detail file count does not match the index')
for (const name of detailNames) {
  const bytes = await readFile(resolve(detailDirectory, name))
  if (bytes.length > MAX_CATALOG_DETAIL_RESPONSE_BYTES) throw new Error(`Catalog detail exceeds the byte ceiling: ${name}`)
}
const catalog = await loadCatalogFromFiles()
assertCatalogLocalization(catalog)
assertLegacyCatalogCompatibility(catalog)
process.stdout.write(`REGISTRY_OK entries=${catalog.entries.length} bridgeBytes=${bridgeBytes.length} indexBytes=${indexBytes.length} details=${detailNames.length} discoveryEntries=${discovery.recordCount} discoveryBytes=${discovery.rawBytes} discoveryGzipBytes=${discovery.gzipBytes}\n`)

validateAdmissionReviews(JSON.parse(await readFile(resolve(root, 'registry/admission-reviews.json'), 'utf8')))
validateCatalogMigrations(JSON.parse(await readFile(resolve(root, 'registry/catalog-migrations.json'), 'utf8')))
validateAuthorResolutions(JSON.parse(await readFile(resolve(root, 'registry/author-resolutions.json'), 'utf8')), catalog.entries)
const automationPolicy = JSON.parse(await readFile(resolve(root, 'registry/automation-policy.json'), 'utf8'))
blockedAuthorFingerprints(automationPolicy)
withdrawnRepositoryFingerprints(automationPolicy)
validateCandidateRegistry(JSON.parse(await readFile(resolve(root, 'registry/candidates.json'), 'utf8')))
validateCommunityRecommendations(JSON.parse(await readFile(resolve(root, 'registry/community-recommendations.json'), 'utf8')))
