import { createHash } from 'node:crypto'
import { cp, mkdir, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises'
import { dirname, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { compareCatalogEntries, compareVersions, loadCatalogFromFiles, MARKET_PAGE_SIZE } from '../src/catalog.mjs'
import { validateCandidateRegistry } from '../src/candidates.mjs'
import { buildAutomationStatus } from '../src/automation-status.mjs'
import { enrichRankingSnapshot } from './ranking-github-metadata.mjs'
import { applyRankingRefreshState, createRankingSnapshot, validateRankingSnapshot, rankingPage, renderRankingRows } from '../marketplace/rankings/model.js'
import { createKnownPluginDirectory, filterPluginDirectory } from '../marketplace/lib/plugin-directory.js'

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const args = process.argv.slice(2)
const argValue = name => {
  const index = args.indexOf(name)
  return index >= 0 ? args[index + 1] : undefined
}
const enrichGitHub = args.includes('--enrich-github')
const rankingRefreshMode = argValue('--ranking-refresh-mode') || 'reuse'
if (!['reuse', 'daily', 'weekly', 'baseline'].includes(rankingRefreshMode)) throw new Error('Unknown ranking refresh mode')
const previousRankingsPath = argValue('--previous-ranking-snapshot')
let previousRankings = null
if (previousRankingsPath) {
  const bytes = await readFile(resolve(projectRoot, previousRankingsPath))
  if (bytes.length > 1024 * 1024) throw new Error('Previous rankings snapshot exceeds the 1 MiB bound')
  previousRankings = validateRankingSnapshot(JSON.parse(bytes.toString('utf8')))
}
const refreshRankingStars = ['daily', 'weekly', 'baseline'].includes(rankingRefreshMode)
const outputRoot = resolve(projectRoot, argValue('--out') || '_site')
const sourceSha = argValue('--source-sha') || process.env.GITHUB_SHA || 'local-worktree'
async function collectRuntimeAssets(directory, prefix = '') {
  const files = []
  for (const entry of (await readdir(directory, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const path = prefix ? `${prefix}/${entry.name}` : entry.name
    const absolute = resolve(directory, entry.name)
    if (entry.isDirectory()) files.push(...await collectRuntimeAssets(absolute, path))
    else if (entry.isFile() && /\.(?:js|css)$/i.test(entry.name)) files.push({ path, absolute })
  }
  return files
}
async function localRuntimeAssetDigest() {
  const digest = createHash('sha256')
  for (const file of await collectRuntimeAssets(resolve(projectRoot, 'marketplace'))) {
    digest.update(file.path).update('\0').update(await readFile(file.absolute)).update('\0')
  }
  return digest.digest('hex')
}
const runtimeAssetVersion = /^[a-f0-9]{40}$/i.test(sourceSha)
  ? sourceSha.slice(0, 12)
  : (await localRuntimeAssetDigest()).slice(0, 12)
const automationRunsPath = argValue('--automation-runs')
const automationReportsPath = argValue('--automation-reports')
const siteOriginInput = argValue('--site-origin') || process.env.SITE_ORIGIN || 'https://dsh.store'
const siteOriginUrl = new URL(siteOriginInput)
if (siteOriginUrl.protocol !== 'https:' || siteOriginUrl.pathname !== '/' || siteOriginUrl.search || siteOriginUrl.hash) {
  throw new Error('The static site origin must be an HTTPS origin without a path, query, or hash')
}
const siteOrigin = siteOriginUrl.origin
const siteHost = siteOriginUrl.host
const alternateOriginInput = argValue('--alternate-origin') || process.env.ALTERNATE_ORIGIN || 'https://dsh-store.cn'
const alternateOriginUrl = new URL(alternateOriginInput)
if (alternateOriginUrl.protocol !== 'https:' || alternateOriginUrl.pathname !== '/' || alternateOriginUrl.search || alternateOriginUrl.hash) {
  throw new Error('The alternate site origin must be an HTTPS origin without a path, query, or hash')
}
const alternateOrigin = alternateOriginUrl.origin
if (alternateOrigin === siteOrigin) throw new Error('The alternate site origin must differ from the site origin')
const icpNumber = argValue('--icp') || process.env.ICP_NUMBER || ''
const baiduVerificationCode = siteOriginUrl.host === 'dsh-store.cn'
  ? (argValue('--baidu-verification') || process.env.BAIDU_SITE_VERIFICATION || '')
  : ''
if (baiduVerificationCode && !/^[A-Za-z0-9_-]{8,128}$/.test(baiduVerificationCode)) {
  throw new Error('The Baidu verification code contains unsupported characters')
}
const defaultLocale = siteOriginUrl.host === 'dsh.store' ? 'en' : 'zh'
const htmlLanguage = defaultLocale === 'en' ? 'en' : 'zh-CN'
const outputRelative = relative(projectRoot, outputRoot)

if (!outputRelative || outputRelative.startsWith('..')) {
  throw new Error('The static output directory must be a child of the repository root')
}

const catalog = await loadCatalogFromFiles({ indexUrl: new URL('../registry/catalog.json', import.meta.url) })
const catalogIndexBytes = await readFile(resolve(projectRoot, 'registry/catalog-index.json'))
const catalogIndex = JSON.parse(catalogIndexBytes.toString('utf8'))
const catalogIndexSha256 = createHash('sha256').update(catalogIndexBytes).digest('hex')
const catalogBridge = JSON.parse(await readFile(resolve(projectRoot, 'registry/catalog.json'), 'utf8'))
if (catalogIndex.schemaVersion !== 2 || !Array.isArray(catalogIndex.entries)
  || catalogIndex.entries.length !== catalog.entries.length
  || catalogIndex.registry?.updatedAt !== catalog.registry?.updatedAt
  || catalogIndex.registry?.repositoryUrl !== catalog.registry?.repositoryUrl
  || catalogBridge.registry?.indexSha256 !== catalogIndexSha256
  || catalogBridge.registry?.indexBytes !== catalogIndexBytes.byteLength
  || catalogBridge.registry?.indexEntryCount !== catalogIndex.entries.length) {
  throw new Error('The static build catalog index does not match the validated Catalog bridge')
}
const candidateRegistry = validateCandidateRegistry(JSON.parse(await readFile(resolve(projectRoot, 'registry/candidates.json'), 'utf8')))
const discoveryIndexBytes = await readFile(resolve(projectRoot, 'registry/discovery-index.json'))
if (discoveryIndexBytes.byteLength > 12 * 1024 * 1024) throw new Error('Public discovery index exceeds the static-build byte bound')
const discoveryIndex = JSON.parse(discoveryIndexBytes.toString('utf8'))
if (discoveryIndex?.schemaVersion !== 1 || discoveryIndex.source?.url !== 'https://www.dsh.so/plugins-index.json'
  || discoveryIndex.source?.license?.spdx !== 'CC-BY-4.0'
  || discoveryIndex.source?.license?.attribution !== 'dsh.so — DSH Developer Hub (https://www.dsh.so)'
  || !Number.isInteger(discoveryIndex.source?.recordCount)
  || discoveryIndex.source.recordCount !== discoveryIndex.entries?.length
  || !Number.isFinite(Date.parse(discoveryIndex.source?.generatedAt))) {
  throw new Error('Public discovery index metadata or source attribution is invalid')
}
const knownDirectoryEntries = createKnownPluginDirectory(catalogIndex.entries, candidateRegistry.entries, { discoveryIndex })
const directoryStats = {
  total: knownDirectoryEntries.length,
  listed: knownDirectoryEntries.filter(entry => entry.listingStatus === 'listed').length,
  categories: new Set(knownDirectoryEntries.flatMap(entry => entry.categories)).size,
}
directoryStats.unlisted = directoryStats.total - directoryStats.listed
const directoryPageEntries = filterPluginDirectory(knownDirectoryEntries).slice(0, MARKET_PAGE_SIZE)
const discoveryIndexSha256 = createHash('sha256').update(discoveryIndexBytes).digest('hex')

async function readAutomationRuns(path) {
  if (!path) return {}
  const bytes = await readFile(resolve(path))
  if (bytes.length > 1_000_000) throw new Error('automation run evidence exceeds the byte bound')
  return JSON.parse(bytes.toString('utf8'))
}

async function readAutomationReports(directory) {
  if (!directory) return []
  const root = resolve(directory)
  const reports = []
  async function visit(current, depth = 0) {
    if (depth > 4 || reports.length >= 32) return
    for (const entry of await readdir(current, { withFileTypes: true })) {
      const absolute = resolve(current, entry.name)
      if (entry.isDirectory()) await visit(absolute, depth + 1)
      else if (entry.isFile() && entry.name === 'catalog-automation-report.json') {
        const bytes = await readFile(absolute)
        if (bytes.length > 1_000_000) throw new Error('automation report exceeds the byte bound')
        const firstSegment = relative(root, absolute).split('/')[0]
        reports.push({ runId: /^\d+$/.test(firstSegment) ? Number(firstSegment) : null, report: JSON.parse(bytes.toString('utf8')) })
      }
    }
  }
  await visit(root)
  return reports
}

const automationRuns = await readAutomationRuns(automationRunsPath)
const automationReports = await readAutomationReports(automationReportsPath)

const snapshot = structuredClone(catalog)
const token = process.env.GITHUB_TOKEN || ''
if ((enrichGitHub || refreshRankingStars) && !token) {
  throw new Error('GITHUB_TOKEN is required for scheduled GitHub metadata enrichment')
}

function repositoryParts(repositoryUrl) {
  const match = /^https:\/\/github\.com\/([^/]+)\/([^/#]+?)(?:\.git)?$/.exec(repositoryUrl || '')
  if (!match) throw new Error(`Unsupported GitHub repository URL: ${repositoryUrl}`)
  return { owner: match[1], repository: match[2] }
}

function manifestUrl(entry) {
  const { owner, repository } = repositoryParts(entry.repositoryUrl)
  const manifestPath = String(entry.manifestPath || '').split('/').filter(Boolean).map(encodeURIComponent).join('/')
  if (!manifestPath || !/^[0-9a-f]{40}$/.test(entry.commit || '')) {
    throw new Error(`Catalog entry ${entry.id} does not have a pinned manifest source`)
  }
  return `https://raw.githubusercontent.com/${encodeURIComponent(owner)}/${encodeURIComponent(repository)}/${entry.commit}/${manifestPath}`
}

async function fetchJson(url, { authenticated = false } = {}) {
  const headers = {
    Accept: 'application/vnd.github+json',
    'User-Agent': 'dsh-store-static-builder',
    'X-GitHub-Api-Version': '2022-11-28',
  }
  if (authenticated && token) headers.Authorization = `Bearer ${token}`
  let lastError
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    try {
      const response = await fetch(url, { headers, signal: AbortSignal.timeout(20_000) })
      if (response.ok) return response.json()
      lastError = new Error(`${url} returned HTTP ${response.status}`)
      lastError.status = response.status
      lastError.rateLimited = response.status === 429
        || (response.status === 403 && response.headers.get('x-ratelimit-remaining') === '0')
      if (lastError.rateLimited && response.status === 403) throw lastError
      if (![429, 500, 502, 503, 504].includes(response.status)) throw lastError
    } catch (error) {
      lastError = error
      if (error.rateLimited && error.status === 403) throw error
    }
    if (attempt < 4) await new Promise(resolvePromise => setTimeout(resolvePromise, attempt * 750))
  }
  throw lastError
}

async function mapLimit(items, limit, worker) {
  const results = new Array(items.length)
  let next = 0
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const index = next++
      results[index] = await worker(items[index], index)
    }
  })
  await Promise.all(runners)
  return results
}

let githubMetadataComplete = false
let starsObservedAt = null
if (enrichGitHub) {
  let githubMetadataRateLimited = false
  const repositoryRequests = new Map()
  const repositoryMetadata = entry => {
    const { owner, repository } = repositoryParts(entry.repositoryUrl)
    const key = `${owner}/${repository}`.toLowerCase()
    if (!repositoryRequests.has(key)) {
      repositoryRequests.set(key, fetchJson(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repository)}`, { authenticated: true }))
    }
    return repositoryRequests.get(key)
  }

  await mapLimit(snapshot.entries.filter(entry => entry.status === 'approved'), 5, async entry => {
    const [repositoryResult, manifest] = await Promise.all([
      repositoryMetadata(entry).then(repository => ({ repository })).catch(error => ({ error })),
      fetchJson(manifestUrl(entry)),
    ])
    if (manifest.version !== entry.version) {
      throw new Error(`${entry.id} catalog version ${entry.version} does not match pinned manifest ${manifest.version}`)
    }
    if (repositoryResult.error) {
      if (!repositoryResult.error.rateLimited) throw repositoryResult.error
      githubMetadataRateLimited = true
      return
    }
    const { repository } = repositoryResult
    entry.github = {
      stars: repository.stargazers_count,
      forks: repository.forks_count,
      openIssues: repository.open_issues_count,
      archived: repository.archived,
      defaultBranch: repository.default_branch,
      description: repository.description,
      updatedAt: repository.updated_at,
      pushedAt: repository.pushed_at,
      license: repository.license?.spdx_id || 'UNKNOWN',
      manifestVersion: manifest.version,
    }
  })
  if (githubMetadataRateLimited) {
    process.stderr.write('GitHub repository metadata is rate-limited; publishing the fixed-Commit Catalog without mutable repository counters.\n')
  }
  githubMetadataComplete = !githubMetadataRateLimited
  starsObservedAt = new Date().toISOString()
}

// A scheduled build may run even when neither the catalog nor its GitHub
// metadata changed. Keep the published artifact reproducible in that case so
// the production sync can compare its signed file manifest and skip a needless
// release/backup cycle. The catalog's own update timestamp remains the
// canonical freshness marker for this snapshot.
const generatedAt = typeof snapshot.registry?.updatedAt === 'string' && snapshot.registry.updatedAt
  ? snapshot.registry.updatedAt
  : (process.env.SOURCE_DATE_EPOCH
      ? new Date(Number(process.env.SOURCE_DATE_EPOCH) * 1000).toISOString()
      : new Date(0).toISOString())
snapshot.generated = {
  generatedAt,
  sourceRepository: 'https://github.com/AI-Scarlett/DSH-Store',
  sourceCommit: sourceSha,
  catalogAuthority: 'registry/catalog.json',
  catalogIndexAuthority: 'registry/catalog-index.json',
  githubEnriched: enrichGitHub && githubMetadataComplete,
}

const manager = snapshot.entries.find(entry => entry.id === 'dsh-safe-plugin-manager')
if (!manager || !/^[0-9a-f]{40}$/.test(manager.commit || '')) {
  throw new Error('A fixed-Commit dsh-safe-plugin-manager catalog entry is required for the static build')
}
const managerInstallable = manager.status === 'approved'

const htmlEscape = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
})[character])
const jsonLdScript = value => JSON.stringify(value).replace(/</g, '\\u003c')
function renderArticleInline(markdown) {
  const held = []
  const hold = html => {
    const token = '@@DSH_ARTICLE_TOKEN_' + held.length + '@@'
    held.push(html)
    return token
  }
  let text = String(markdown)
  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (match, label, href) => {
    let safeHref
    try {
      const url = new URL(href)
      if (url.protocol === 'https:' || url.protocol === 'http:') safeHref = url.href
    } catch {}
    return safeHref
      ? hold('<a href="' + htmlEscape(safeHref) + '" target="_blank" rel="noopener noreferrer">' + htmlEscape(label) + '</a>')
      : label
  })
  text = text.replace(/\x60([^\x60]+)\x60/g, (match, value) => hold('<code>' + htmlEscape(value) + '</code>'))
  text = text.replace(/\*\*(.+?)\*\*/g, (match, value) => hold('<strong>' + htmlEscape(value) + '</strong>'))
  text = text.replace(/\*([^*]+)\*/g, (match, value) => hold('<em>' + htmlEscape(value) + '</em>'))
  text = htmlEscape(text).replace(/\n/g, '<br>')
  held.forEach((html, index) => { text = text.replaceAll('@@DSH_ARTICLE_TOKEN_' + index + '@@', html) })
  return text
}
function renderArticleMarkdown(markdown) {
  const lines = String(markdown).replace(/\r\n?/g, '\n').split('\n')
  const output = []
  let paragraph = []
  let listType = null
  let quote = []
  let fenced = false
  let code = []
  let skipFirstHeading = true
  const flushParagraph = () => {
    if (paragraph.length) output.push('<p>' + renderArticleInline(paragraph.join('\n')) + '</p>')
    paragraph = []
  }
  const closeList = () => {
    if (listType) output.push('</' + listType + '>')
    listType = null
  }
  const flushQuote = () => {
    if (quote.length) output.push('<blockquote><p>' + renderArticleInline(quote.join('\n')) + '</p></blockquote>')
    quote = []
  }
  for (const rawLine of lines) {
    const line = rawLine.trim()
    if (line.startsWith('\x60\x60\x60')) {
      flushParagraph(); closeList(); flushQuote()
      if (!fenced) { code = []; fenced = true }
      else { output.push('<pre><code>' + htmlEscape(code.join('\n')) + '</code></pre>'); fenced = false }
      continue
    }
    if (fenced) { code.push(rawLine); continue }
    if (!line) { flushParagraph(); closeList(); flushQuote(); continue }
    const heading = /^(#{1,6})\s+(.+)$/.exec(line)
    if (heading) {
      flushParagraph(); closeList(); flushQuote()
      if (heading[1].length === 1 && skipFirstHeading) { skipFirstHeading = false; continue }
      skipFirstHeading = false
      const level = Math.min(3, Math.max(2, heading[1].length))
      output.push('<h' + level + '>' + renderArticleInline(heading[2]) + '</h' + level + '>')
      continue
    }
    if (/^(---+|\*\*\*+)$/.test(line)) {
      flushParagraph(); closeList(); flushQuote(); output.push('<hr>')
      continue
    }
    if (line.startsWith('>')) {
      flushParagraph(); closeList()
      quote.push(line.replace(/^>\s?/, ''))
      continue
    }
    const item = /^(?:([-*+])|(\d+)[.)])\s+(.+)$/.exec(line)
    if (item) {
      flushParagraph(); flushQuote()
      const nextType = item[2] ? 'ol' : 'ul'
      if (listType !== nextType) { closeList(); output.push('<' + nextType + '>'); listType = nextType }
      output.push('<li>' + renderArticleInline(item[3]) + '</li>')
      continue
    }
    closeList(); flushQuote(); paragraph.push(line)
  }
  flushParagraph(); closeList(); flushQuote()
  if (fenced && code.length) output.push('<pre><code>' + htmlEscape(code.join('\n')) + '</code></pre>')
  return output.join('\n')
}
const palette = ['#6f83ff', '#ff6c4a', '#8c6ce8', '#00a991', '#e0568c', '#4385c6', '#a36c45', '#6a9f39']
const pluginColor = id => palette[[...String(id)].reduce((total, character) => total + character.charCodeAt(0), 0) % palette.length]
const initials = name => String(name || 'DSH').replace(/^DSH\s*/i, '').split(/[\s_-]+/).filter(Boolean).slice(0, 2).map(word => word[0]).join('').toUpperCase() || 'D'
const categories = snapshot.registry?.categories || {}
const categoryLabel = id => categories[id] || id
const riskLabels = { low: '低权限', medium: '中权限', high: '高权限', unknown: '未知权限' }

const visibleEntries = snapshot.entries
  .filter(entry => entry.status !== 'unlisted')
  .sort(compareCatalogEntries)

const anchorId = value => String(value || 'plugin').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'plugin'

function assuranceMarkup(entry) {
  const records = [
    ['已发现', entry.assurance?.discovery?.evidenceStatus || entry.assurance?.discovery?.status || 'verified'],
    ['可安装验证', entry.assurance?.installability?.evidenceStatus || entry.assurance?.installability?.status || 'unknown'],
    ['运行验证', entry.assurance?.runtime?.evidenceStatus || entry.assurance?.runtime?.status || 'unknown'],
    ['安全审查', entry.assurance?.securityReview?.evidenceStatus || entry.assurance?.securityReview?.status || 'unknown'],
  ]
  const label = status => ({ verified: '已验证', partial: '部分验证', failed: '未通过', unknown: '未知', 'not-applicable': '不适用' }[status] || '未知')
  return `<div class="assurance-rail">${records.map(([name, status]) => `<span class="assurance-item assurance-${htmlEscape(status)}"><b>${htmlEscape(name)}</b><em>${htmlEscape(label(status))}</em></span>`).join('')}</div>`
}

function pluginCard(entry) {
  const permissions = entry.details?.permissions || {}
  const topCategories = Array.isArray(entry.categories) ? entry.categories.slice(0, 2) : []
  return `<article id="plugin-${htmlEscape(anchorId(entry.id))}" class="plugin-card" style="--plugin-color:${pluginColor(entry.id)}" data-static-plugin-id="${htmlEscape(entry.id)}">
    <div class="plugin-card-top">
      <span class="plugin-card-icon" aria-hidden="true">${htmlEscape(initials(entry.name))}</span>
      <span class="status-tag${entry.status === 'approved' ? '' : ' blocked'}">${entry.status === 'approved' ? '可安装' : '仅展示'}</span>
    </div>
    <h3>${htmlEscape(entry.name)}</h3>
    <span class="package-line">${htmlEscape(entry.packageName)} · v${htmlEscape(entry.version)}</span>
    <p class="plugin-description">${htmlEscape(entry.description)}</p>
    <div class="plugin-badges">
      ${topCategories.map(id => `<span class="plugin-badge">${htmlEscape(categoryLabel(id))}</span>`).join('')}
      <span class="plugin-badge risk-${htmlEscape(permissions.level || 'unknown')}">${htmlEscape(riskLabels[permissions.level] || riskLabels.unknown)}</span>
    </div>
    ${assuranceMarkup(entry)}
    <footer class="plugin-card-footer">
      <button class="details-button" type="button" data-details-id="${htmlEscape(entry.id)}">查看插件详情 →</button>
      <a class="repo-link" href="${htmlEscape(entry.repositoryUrl)}" target="_blank" rel="noreferrer" aria-label="打开 GitHub 仓库: ${htmlEscape(entry.name)}" data-repo-id="${htmlEscape(entry.id)}">↗</a>
    </footer>
  </article>`
}

const directoryUi = defaultLocale === 'en'
  ? { listed: 'Listed', unlisted: 'Not listed', reason: 'No matching DSH STORE Catalog record was found.', noAction: 'Directory record only · no install action', github: 'GitHub repository' }
  : { listed: '已收录', unlisted: '未收录', reason: '尚未匹配到 DSH STORE Catalog 记录。', noAction: '仅展示目录记录 · 不提供安装', github: 'GitHub 仓库' }
const publicDiscoveryAttribution = 'dsh.so — DSH Developer Hub (https://www.dsh.so)'
const directoryCategoryLabels = {
  ai: ['AI 与智能体', 'AI & agents'], audio: ['音频', 'Audio'], automation: ['自动化', 'Automation'],
  browser: ['浏览器', 'Browser'], 'code-review': ['代码审查', 'Code review'], content: ['内容创作', 'Content'],
  creator: ['创作工具', 'Creator tools'], data: ['数据', 'Data'], database: ['数据库', 'Database'],
  desktop: ['桌面端', 'Desktop'], developer: ['开发工具', 'Developer tools'], file: ['文件处理', 'Files'],
  finance: ['金融', 'Finance'], game: ['游戏与娱乐', 'Games'], git: ['Git 工具', 'Git'], github: ['GitHub 集成', 'GitHub'],
  knowledge: ['知识管理', 'Knowledge'], launcher: ['启动器', 'Launcher'], markdown: ['Markdown', 'Markdown'],
  mcp: ['MCP 集成', 'MCP'], media: ['媒体', 'Media'], memory: ['记忆', 'Memory'], network: ['网络', 'Network'],
  notification: ['通知', 'Notifications'], notify: ['通知', 'Notifications'], ocr: ['OCR', 'OCR'], office: ['办公', 'Office'],
  pdf: ['PDF', 'PDF'], productivity: ['效率工具', 'Productivity'], proxy: ['代理', 'Proxy'], scheduler: ['定时任务', 'Scheduler'],
  search: ['搜索', 'Search'], security: ['安全与隐私', 'Security & privacy'], 'skin-theme': ['主题外观', 'Themes'],
  spreadsheet: ['表格', 'Spreadsheets'], storage: ['存储', 'Storage'], telegram: ['Telegram 集成', 'Telegram'],
  terminal: ['终端', 'Terminal'], ui: ['界面增强', 'UI'], uncategorized: ['未分类', 'Uncategorized'],
  video: ['视频', 'Video'], vision: ['视觉', 'Vision'], web: ['Web', 'Web'], 'web-search': ['网络搜索', 'Web search'],
  agent: ['智能体', 'Agents'], 'agent-orchestration': ['智能体编排', 'Agent orchestration'],
}
const directoryCategoryLabel = id => directoryCategoryLabels[id]?.[defaultLocale === 'en' ? 1 : 0] || id

function directoryCard(entry) {
  const name = defaultLocale === 'en' ? entry.nameEn : entry.nameZh
  const listed = entry.listingStatus === 'listed'
  const categories = entry.categories.slice(0, 3)
  const repoLink = entry.repositoryUrl
    ? `<a class="repo-link" href="${htmlEscape(entry.repositoryUrl)}" target="_blank" rel="noopener noreferrer" aria-label="${htmlEscape(directoryUi.github)}: ${htmlEscape(name)}">GitHub ↗</a>` : ''
  const detailLink = entry.detailUrl
    ? `<a class="repo-link" href="${htmlEscape(entry.detailUrl)}" target="_blank" rel="noopener noreferrer" aria-label="${htmlEscape(publicDiscoveryAttribution)}: ${htmlEscape(name)}">↗</a>` : ''
  return `<article id="plugin-${htmlEscape(anchorId(entry.id))}" class="plugin-card directory-entry-card" style="--plugin-color:${pluginColor(entry.id)}" data-static-plugin-id="${htmlEscape(entry.id)}">
    <div class="plugin-card-top"><span class="plugin-card-icon" aria-hidden="true">${htmlEscape(initials(name))}</span><span class="catalog-listing-tag ${listed ? 'listed' : 'unlisted'}">${listed ? directoryUi.listed : directoryUi.unlisted}</span></div>
    <h3>${htmlEscape(name)}</h3><span class="package-line">${htmlEscape(entry.alias || entry.sourceId || entry.id)}</span>
    <p class="plugin-description">${htmlEscape(entry.description || (defaultLocale === 'en' ? 'No public description.' : '暂无公开简介。'))}</p>
    <div class="plugin-badges">${categories.map(id => `<span class="plugin-badge">${htmlEscape(directoryCategoryLabel(id))}</span>`).join('')}${entry.stars ? `<span class="plugin-badge directory-stars">★ ${new Intl.NumberFormat(defaultLocale === 'en' ? 'en' : 'zh-CN', { notation: 'compact', maximumFractionDigits: 1 }).format(entry.stars)} Stars</span>` : ''}</div>
    ${listed ? '' : `<p class="catalog-listing-reason"><b>${defaultLocale === 'en' ? 'Listing status' : '收录状态'}</b>${directoryUi.reason}</p>`}
    <footer class="plugin-card-footer"><span class="candidate-no-install">${directoryUi.noAction}</span><span class="directory-entry-links">${repoLink}${detailLink}</span></footer>
  </article>`
}

function featuredCard(entry, index) {
  return `<article class="featured-card reveal visible" style="--plugin-color:${pluginColor(entry.id)}" data-static-featured-id="${htmlEscape(entry.id)}">
    <div class="featured-top"><span class="feature-number">PICK / 0${index + 1}</span><span class="dialog-badge">${htmlEscape(categoryLabel(entry.categories?.[0] || 'tools'))}</span></div>
    <span class="featured-icon" aria-hidden="true"><span>${htmlEscape(initials(entry.name))}</span></span>
    <h3>${htmlEscape(entry.name)}</h3>
    <p>${htmlEscape(entry.description)}</p>
    <button class="featured-link details-button" type="button" data-details-id="${htmlEscape(entry.id)}"><span>查看插件详情</span><i aria-hidden="true">↗</i></button>
  </article>`
}

function homePluginCard(entry) {
  const topCategory = Array.isArray(entry.categories) ? entry.categories[0] : ''
  const statusClass = entry.status === 'approved' ? '' : ' blocked'
  const status = entry.status === 'approved' ? '可安装' : '仅展示'
  return `<article class="home-plugin-card" data-static-home-plugin-id="${htmlEscape(entry.id)}">
    <div class="home-plugin-card-top"><span class="home-plugin-icon" aria-hidden="true" style="--plugin-color:${pluginColor(entry.id)}">${htmlEscape(initials(entry.name))}</span><span class="status-tag${statusClass}">${status}</span></div>
    <h3>${htmlEscape(entry.name)}</h3>
    ${topCategory ? `<p class="home-plugin-category">${htmlEscape(categoryLabel(topCategory))}</p>` : ''}
    <p class="home-plugin-description">${htmlEscape(entry.description || '打开详情查看插件信息。')}</p>
    <div class="home-plugin-package"><code>${htmlEscape(entry.packageName)}</code><span>v${htmlEscape(entry.version)}</span></div>
    <footer class="home-plugin-card-footer"><a class="home-plugin-detail" href="./plugins/#plugin-${htmlEscape(anchorId(entry.id))}">查看插件详情 →</a><a class="home-plugin-repo" href="${htmlEscape(entry.repositoryUrl)}" target="_blank" rel="noreferrer" aria-label="打开 GitHub 仓库: ${htmlEscape(entry.name)}">↗</a></footer>
  </article>`
}

function replaceRequired(source, search, replacement, label) {
  if (!source.includes(search)) throw new Error(`Static template marker is missing: ${label}`)
  return source.replace(search, replacement)
}

function replaceBetweenMarkers(source, begin, end, content, label) {
  const start = source.indexOf(begin)
  const finish = source.indexOf(end, start + begin.length)
  if (start < 0 || finish < 0) throw new Error(`Static template markers are missing: ${label}`)
  return source.slice(0, start) + begin + content + end + source.slice(finish + end.length)
}

function replaceElementText(source, id, value) {
  const escapedId = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const expression = new RegExp(`(<([a-z0-9]+)[^>]*\\bid="${escapedId}"[^>]*>)[\\s\\S]*?(<\\/\\2>)`, 'i')
  if (!expression.test(source)) throw new Error(`Static element is missing: #${id}`)
  return source.replace(expression, `$1${htmlEscape(value)}$3`)
}

const siteTextExtensions = new Set(['.html', '.js', '.json', '.txt', '.xml', '.webmanifest', '.css'])
async function rewriteSiteReferences(directory) {
  const entries = await readdir(directory, { withFileTypes: true })
  for (const entry of entries) {
    const absolutePath = resolve(directory, entry.name)
    if (entry.isDirectory()) {
      await rewriteSiteReferences(absolutePath)
      continue
    }
    if (!entry.isFile() || !siteTextExtensions.has(entry.name.slice(entry.name.lastIndexOf('.')).toLowerCase())) continue
    const source = await readFile(absolutePath, 'utf8')
    let rewritten = source.replaceAll('https://dsh.store', siteOrigin).replaceAll('dsh.store', siteHost)
    rewritten = rewritten
      .replace(/(<link\b[^>]*\bhref=")(?!https?:\/\/)([^"?]+\.css)(?:\?[^"]*)?(")/gi, `$1$2?v=${runtimeAssetVersion}$3`)
      .replaceAll('src="../app.js"', `src="../app.js?v=${runtimeAssetVersion}"`)
      .replaceAll('src="./app.js"', `src="./app.js?v=${runtimeAssetVersion}"`)
      .replaceAll("import('./lib/plugin-directory.js')", `import('./lib/plugin-directory.js?v=${runtimeAssetVersion}')`)
      .replaceAll("import('./lib/dsh-release-policy.js')", `import('./lib/dsh-release-policy.js?v=${runtimeAssetVersion}')`)
    if (rewritten !== source) await writeFile(absolutePath, rewritten)
  }
}

const externalCatalogMarker = `<meta name="dsh-catalog-delivery" content="external-json">
  <meta name="dsh-catalog-index-sha256" content="${catalogIndexSha256}">
  <meta name="dsh-catalog-index-bytes" content="${catalogIndexBytes.byteLength}">
  <meta name="dsh-catalog-index-count" content="${catalogIndex.entries.length}">`
const externalDiscoveryMarker = `<meta name="dsh-discovery-index-sha256" content="${discoveryIndexSha256}">
  <meta name="dsh-discovery-index-bytes" content="${discoveryIndexBytes.byteLength}">
  <meta name="dsh-discovery-index-count" content="${discoveryIndex.entries.length}">`
const featured = visibleEntries.filter(entry => entry.featured === true && entry.status === 'approved').slice(0, 4)
const categoryCount = new Set(visibleEntries.flatMap(entry => Array.isArray(entry.categories) ? entry.categories : [])).size
const installCommand = managerInstallable
  ? `dsh plugin --profile web add 'git+${manager.repositoryUrl}.git#${manager.commit}'`
  : (defaultLocale === 'en' ? 'Compatibility review pending; installation is unavailable.' : '兼容性待核验，暂不提供安装命令。')
const repairVersionComparison = compareVersions(manager.version, '0.8.10')
const repairAvailable = managerInstallable && repairVersionComparison !== null && repairVersionComparison >= 0
const repairPackageSpecifier = `git+${manager.repositoryUrl}.git#${manager.commit}`
const repairCommand = `pnpm --config.ignore-scripts=true dlx '${repairPackageSpecifier}' --profile web --target-version ${manager.version} --target-commit ${manager.commit}`
const approvedCount = visibleEntries.filter(entry => entry.status === 'approved').length
const staticCatalogEntries = visibleEntries.slice(0, MARKET_PAGE_SIZE)
const catalogItemList = {
  '@context': 'https://schema.org',
  '@type': 'ItemList',
  '@id': `${siteOrigin}/plugins/#catalog-items`,
  name: 'DSH STORE plugin catalog',
  description: 'A machine-readable first page of the DSH STORE third-party DeepSeek Harness plugin catalog.',
  numberOfItems: staticCatalogEntries.length,
  itemListOrder: 'https://schema.org/ItemListOrderAscending',
  itemListElement: staticCatalogEntries.map((entry, index) => ({
    '@type': 'ListItem',
    position: index + 1,
    url: `${siteOrigin}/plugins/#plugin-${anchorId(entry.id)}`,
    item: {
      '@type': 'SoftwareApplication',
      name: entry.name,
      description: entry.description,
      url: `${siteOrigin}/plugins/#plugin-${anchorId(entry.id)}`,
      applicationCategory: (Array.isArray(entry.categories) && entry.categories[0]) ? categoryLabel(entry.categories[0]) : 'DeepSeek Harness plugin',
      softwareVersion: entry.version,
      codeRepository: entry.repositoryUrl,
      isAccessibleForFree: true,
    },
  })),
}

await rm(outputRoot, { recursive: true, force: true })
await mkdir(outputRoot, { recursive: true })
const copyFilter = source => !/(^|\/)\._|(^|\/)\.DS_Store$/.test(source)
await cp(resolve(projectRoot, 'marketplace'), resolve(outputRoot, 'marketplace'), { recursive: true, filter: copyFilter })
await cp(resolve(projectRoot, 'registry'), resolve(outputRoot, 'registry'), { recursive: true, filter: copyFilter })
await rewriteSiteReferences(resolve(outputRoot, 'marketplace'))

const isDomestic = siteOriginUrl.host === 'dsh-store.cn'
if (!isDomestic) {
  await rm(resolve(outputRoot, 'marketplace/dsh-store-guide'), { recursive: true, force: true })
  await rm(resolve(outputRoot, 'marketplace/googled542dac4f5a6c169.html'), { force: true })
}

const articlePromoBegin = '<!-- DSH_ARTICLE_PROMO_BEGIN -->'
const articlePromoEnd = '<!-- DSH_ARTICLE_PROMO_END -->'
const aboutPagePath = resolve(outputRoot, 'marketplace/about/index.html')
let aboutPage = await readFile(aboutPagePath, 'utf8')
aboutPage = replaceRequired(aboutPage, articlePromoBegin, '', 'article promo begin')
aboutPage = replaceRequired(aboutPage, articlePromoEnd, '', 'article promo end')
await writeFile(aboutPagePath, aboutPage)

const domesticGuideMarker = '<!-- DSH_DOMESTIC_GUIDE -->'
const faqPagePath = resolve(outputRoot, 'marketplace/faq/index.html')
let faqPage = await readFile(faqPagePath, 'utf8')
const domesticGuideMarkup = `<section class="faq-cta section-shell reveal domestic-guide-cta" aria-labelledby="domestic-guide-title">
      <div><span>CHINA SITE / USE &amp; TROUBLESHOOTING</span><h2 id="domestic-guide-title">先分清问题在哪一层，再决定下一步。</h2><p>国内站指南将商城页面、Catalog、DSH CLI、Profile、插件依赖和运行时问题分开说明，并链接可复核的公开入口。</p></div>
      <div><a class="button button-primary" href="../dsh-store-guide/" data-analytics-event="domestic_guide_open" data-analytics-item="faq"><span>查看使用与排查指南</span><i>↗</i></a></div>
    </section>`
faqPage = replaceRequired(faqPage, domesticGuideMarker, isDomestic ? domesticGuideMarkup : '', 'domestic guide marker')
await writeFile(faqPagePath, faqPage)

const alternateIsDomestic = alternateOriginUrl.host === 'dsh-store.cn'
const alternateLabel = alternateIsDomestic ? '国内站' : '国际站'
const alternateCode = alternateIsDomestic ? 'CN' : 'INTL'
const alternateAriaLabel = alternateIsDomestic ? '切换到国内站 / Switch to China site' : '切换到国际站 / Switch to international site'
const alternateAnalyticsItem = alternateIsDomestic ? 'domestic' : 'international'
const alternateMarkup = `<a class="site-switch-link" href="${htmlEscape(`${alternateOrigin}/`)}" aria-label="${htmlEscape(alternateAriaLabel)}" data-analytics-event="alternate_site_open" data-analytics-item="${alternateAnalyticsItem}"><span>${alternateLabel}</span><small>${alternateCode}</small><i aria-hidden="true">↗</i></a>`
const friendSisterSiteMarkup = `<a href="${htmlEscape(`${alternateOrigin}/`)}" target="_blank" rel="noopener noreferrer">DSH STORE · ${alternateIsDomestic ? '国内站' : 'International'} ↗</a>`

const articleCollection = JSON.parse(await readFile(resolve(projectRoot, 'marketplace/articles/articles.json'), 'utf8'))
if (articleCollection.schemaVersion !== 1 || !Array.isArray(articleCollection.articles)
  || articleCollection.articles.length < 1 || articleCollection.articles.length > 100) {
  throw new Error('The article collection schema or size is invalid')
}
const articleSlugs = new Set()
for (const article of articleCollection.articles) {
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(article.slug || '')
    || articleSlugs.has(article.slug)
    || typeof article.title !== 'string' || article.title.length < 8 || article.title.length > 180
    || typeof article.summary !== 'string' || article.summary.length < 30 || article.summary.length > 420
    || !/^\d{4}-\d{2}-\d{2}$/.test(article.datePublished || '')
    || new Date(article.datePublished).toISOString().slice(0, 10) !== article.datePublished
    || article.language !== 'zh-CN'
    || typeof article.contentMarkdown !== 'string' || article.contentMarkdown.length < 500 || article.contentMarkdown.length > 50000) {
    throw new Error('An article entry is malformed or exceeds its bound')
  }
  articleSlugs.add(article.slug)
}
const articleRoute = article => '/articles/' + article.slug + '/'
const articleListMarkup = articleCollection.articles.map(article => {
  const date = new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' })
    .format(new Date(article.datePublished + 'T00:00:00Z'))
  return '<article class="article-card">'
    + '<div class="article-card-meta"><time datetime="' + htmlEscape(article.datePublished) + '">' + htmlEscape(date) + '</time><span>' + htmlEscape(article.category) + '</span></div>'
    + '<h3><a href="./' + htmlEscape(article.slug) + '/">' + htmlEscape(article.title) + '</a></h3>'
    + '<p>' + htmlEscape(article.summary) + '</p>'
    + '<a href="./' + htmlEscape(article.slug) + '/">阅读文章 <span aria-hidden="true">↗</span></a>'
    + '</article>'
}).join('\n')
const articleCollectionJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'CollectionPage',
  '@id': siteOrigin + '/articles/#collection',
  url: siteOrigin + '/articles/',
  name: articleCollection.collectionTitle,
  description: articleCollection.collectionDescription,
  inLanguage: 'zh-CN',
  isPartOf: { '@type': 'WebSite', '@id': siteOrigin + '/#website', name: 'DSH STORE', url: siteOrigin + '/' },
  mainEntity: {
    '@type': 'ItemList',
    itemListOrder: 'https://schema.org/ItemListOrderDescending',
    numberOfItems: articleCollection.articles.length,
    itemListElement: articleCollection.articles.map((article, index) => ({
      '@type': 'ListItem', position: index + 1, url: siteOrigin + articleRoute(article),
      name: article.title, description: article.summary,
    })),
  },
}
const articleIndexPath = resolve(outputRoot, 'marketplace/articles/index.html')
let articleIndexHtml = await readFile(articleIndexPath, 'utf8')
articleIndexHtml = replaceRequired(articleIndexHtml, '<!-- DSH_ARTICLE_COLLECTION_SCHEMA -->',
  '<script type="application/ld+json">' + jsonLdScript(articleCollectionJsonLd) + '</script>', 'article collection schema')
articleIndexHtml = replaceRequired(articleIndexHtml, '<!-- DSH_STATIC_ARTICLE_LIST -->', articleListMarkup, 'article list')
articleIndexHtml = replaceElementText(articleIndexHtml, 'article-count', String(articleCollection.articles.length))
await writeFile(articleIndexPath, articleIndexHtml)

const articleTemplate = await readFile(resolve(projectRoot, 'scripts/templates/dsh-article-page.html'), 'utf8')
const articleDetailPages = []
for (const article of articleCollection.articles) {
  const route = articleRoute(article)
  const url = siteOrigin + route
  const articleSchema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    '@id': url + '#article',
    headline: article.title,
    description: article.summary,
    datePublished: article.datePublished,
    inLanguage: article.language,
    articleSection: article.category,
    keywords: ['DeepSeek Harness', 'DSH', 'DSH 插件', article.category],
    isAccessibleForFree: true,
    mainEntityOfPage: { '@type': 'WebPage', '@id': url },
    publisher: { '@type': 'Organization', name: 'DSH STORE', url: siteOrigin + '/' },
  }
  let page = articleTemplate
  const replacements = [
    ['<!-- ARTICLE_DESCRIPTION -->', htmlEscape(article.summary)],
    ['<!-- ARTICLE_DATE -->', htmlEscape(article.datePublished)],
    ['<!-- ARTICLE_TITLE -->', htmlEscape(article.title)],
    ['<!-- ARTICLE_URL -->', htmlEscape(url)],
    ['<!-- ARTICLE_IMAGE -->', htmlEscape(siteOrigin + '/dsh-store-icon.png')],
    ['<!-- ARTICLE_CATEGORY -->', htmlEscape(article.category)],
    ['<!-- ARTICLE_SCHEMA -->', '<script type="application/ld+json">' + jsonLdScript(articleSchema) + '</script>'],
    ['<!-- ARTICLE_CONTENT -->', renderArticleMarkdown(article.contentMarkdown)],
    ['<!-- ASSET_VERSION -->', runtimeAssetVersion],
  ]
  for (const [marker, value] of replacements) {
    if (!page.includes(marker)) throw new Error('Article template marker is missing: ' + marker)
    page = page.replaceAll(marker, value)
  }
  const file = 'marketplace/articles/' + article.slug + '/index.html'
  const target = resolve(outputRoot, file)
  await mkdir(dirname(target), { recursive: true })
  await writeFile(target, page)
  articleDetailPages.push({ file, route })
}

const canonicalPages = [
  { file: 'marketplace/index.html', route: '/' },
  { file: 'marketplace/plugins/index.html', route: '/plugins/' },
  { file: 'marketplace/rankings/index.html', route: '/rankings/' },
  { file: 'marketplace/downloads/index.html', route: '/downloads/' },
  { file: 'marketplace/scans/index.html', route: '/scans/' },
  { file: 'marketplace/community/index.html', route: '/community/' },
  { file: 'marketplace/standards/index.html', route: '/standards/' },
  { file: 'marketplace/build/index.html', route: '/build/' },
  { file: 'marketplace/faq/index.html', route: '/faq/' },
  { file: 'marketplace/about/index.html', route: '/about/' },
  { file: 'marketplace/repair/index.html', route: '/repair/' },
  { file: 'marketplace/articles/index.html', route: '/articles/', fixedLocale: 'zh-CN', domesticOnly: true },
  ...articleDetailPages.map(({ file, route }) => ({ file, route, fixedLocale: 'zh-CN', domesticOnly: true })),
  {
    file: 'marketplace/about/deepseek-harness-guide/index.html',
    route: '/about/deepseek-harness-guide/',
    fixedLocale: 'zh-CN',
  },
  { file: 'marketplace/dsh-plugins/index.html', route: '/dsh-plugins/' },
  ...(isDomestic ? [{
    file: 'marketplace/dsh-store-guide/index.html',
    route: '/dsh-store-guide/',
    fixedLocale: 'zh-CN',
    domesticOnly: true,
  }] : []),
]
const hreflangMarkup = (route, domesticOnly = false) => {
  if (domesticOnly) return `<link rel="alternate" hreflang="zh-CN" href="${htmlEscape(`${siteOrigin}${route}`)}">`
  const intl = siteOriginUrl.host === 'dsh.store' ? siteOrigin : alternateOrigin
  const domestic = siteOriginUrl.host === 'dsh-store.cn' ? siteOrigin : alternateOrigin
  return [
    `<link rel="alternate" hreflang="en" href="${htmlEscape(`${intl}${route}`)}">`,
    `<link rel="alternate" hreflang="zh-CN" href="${htmlEscape(`${domestic}${route}`)}">`,
    `<link rel="alternate" hreflang="x-default" href="${htmlEscape(`${intl}${route}`)}">`,
  ].join('\n  ')
}
const sitemapDate = (() => {
  const candidate = new Date(snapshot.registry?.updatedAt || generatedAt)
  return Number.isNaN(candidate.valueOf()) ? generatedAt.slice(0, 10) : candidate.toISOString().slice(0, 10)
})()
const sitemapPriority = { '/rankings/': '0.9', '/': '1.0', '/plugins/': '0.9', '/downloads/': '0.9', '/scans/': '0.7', '/community/': '0.8', '/standards/': '0.9', '/dsh-plugins/': '0.9', '/build/': '0.8', '/repair/': '0.9', '/faq/': '0.8', '/about/': '0.7', '/about/deepseek-harness-guide/': '0.8', '/articles/': '0.8' }
const sitemapChangefreq = { '/rankings/': 'daily', '/': 'weekly', '/plugins/': 'daily', '/downloads/': 'weekly', '/scans/': 'daily', '/community/': 'weekly', '/standards/': 'weekly', '/dsh-plugins/': 'weekly', '/build/': 'weekly', '/repair/': 'daily', '/faq/': 'monthly', '/about/': 'monthly', '/about/deepseek-harness-guide/': 'monthly', '/articles/': 'weekly' }
for (const { route } of articleDetailPages) {
  sitemapPriority[route] = '0.7'
  sitemapChangefreq[route] = 'monthly'
}
if (isDomestic) {
  sitemapPriority['/dsh-store-guide/'] = '0.8'
  sitemapChangefreq['/dsh-store-guide/'] = 'monthly'
}
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:mobile="http://www.baidu.com/schemas/sitemap-mobile/1/">
${canonicalPages.map(({ route }) => `  <url><loc>${htmlEscape(`${siteOrigin}${route}`)}</loc><lastmod>${sitemapDate}</lastmod><changefreq>${sitemapChangefreq[route]}</changefreq><priority>${sitemapPriority[route]}</priority><mobile:mobile type="pc,mobile" /></url>`).join('\n')}
</urlset>
`
await writeFile(resolve(outputRoot, 'marketplace/sitemap.xml'), sitemap)

const icpMarkup = icpNumber
  ? `<a class="icp-link" href="https://beian.miit.gov.cn/" target="_blank" rel="noreferrer">${htmlEscape(icpNumber)}</a>`
  : ''
const baiduVerificationMarkup = baiduVerificationCode
  ? `<meta name="baidu-site-verification" content="${htmlEscape(baiduVerificationCode)}">`
  : ''
const baiduUnionVerificationMarkup = isDomestic
  ? '<meta name="baidu_union_verify" content="f7a5e80f6ec4d01cdfd011c771e7e706">'
  : ''
const baiduTongjiMarkup = isDomestic ? `<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?7c34f1fd076e8f052b6a6f746ab1135d";
  var s = document.getElementsByTagName("script")[0];
  s.parentNode.insertBefore(hm, s);
})();
</script>` : ''
const umamiWebsiteId = isDomestic
  ? '763ad43e-f5c9-4342-9a82-8366d1ea90df'
  : 'c0cf0ce3-b77c-4570-9573-59c07a583950'
const umamiMarkup = `<script>
(function () {
  if (navigator.doNotTrack === '1' || navigator.globalPrivacyControl === true) return;
  var script = document.createElement('script');
  script.src = 'https://aiaiai.help/umami/script.js';
  script.async = true;
  script.dataset.websiteId = '${umamiWebsiteId}';
  script.dataset.hostUrl = 'https://aiaiai.help/umami';
  script.dataset.domains = '${siteHost}';
  script.dataset.doNotTrack = 'true';
  script.dataset.excludeSearch = 'true';
  script.dataset.excludeHash = 'true';
  document.head.appendChild(script);
})();
</script>`
for (const { file: pagePath, route, fixedLocale, domesticOnly = false } of canonicalPages) {
  const absolutePath = resolve(outputRoot, pagePath)
  const page = await readFile(absolutePath, 'utf8')
  const articlesHref = relative(dirname(pagePath), 'marketplace/articles') || '.'
  const articlesLinkPath = articlesHref === '.' ? './' : articlesHref.replace(/\\/g, '/') + '/'
  const articleNavLabel = (fixedLocale === 'zh-CN' || defaultLocale === 'zh') ? 'DSH 实战与观察' : 'DSH Field Notes'
  const articleNavCurrent = route.startsWith('/articles/') ? ' aria-current="page"' : ''
  const articleNavMarkup = `<a href="${htmlEscape(articlesLinkPath)}" data-i18n="nav.articles"${articleNavCurrent}>${articleNavLabel}</a>`
  const withAlternate = replaceRequired(page, '<!-- DSH_ALTERNATE_SITE -->', `${articleNavMarkup}${alternateMarkup}`, `${pagePath} alternate site marker`)
  const withFriendLinks = replaceRequired(withAlternate, '<!-- DSH_FRIEND_SISTER_SITE -->', friendSisterSiteMarkup, `${pagePath} friend sister site marker`)
  const withHreflang = replaceRequired(withFriendLinks, '<!-- DSH_HREFLANG -->', hreflangMarkup(route, domesticOnly), `${pagePath} hreflang marker`)
  const withIcp = replaceRequired(withHreflang, '<!-- DSH_ICP -->', icpMarkup, `${pagePath} ICP marker`)
  const withBaiduVerification = replaceRequired(withIcp, '<!-- DSH_BAIDU_VERIFICATION -->', baiduVerificationMarkup, `${pagePath} Baidu verification marker`)
  const withBaiduUnionVerification = route === '/'
    ? replaceRequired(withBaiduVerification, '<!-- DSH_BAIDU_UNION_VERIFY -->', baiduUnionVerificationMarkup, `${pagePath} Baidu Union verification marker`)
    : withBaiduVerification
  const withBaiduTongji = baiduTongjiMarkup
    ? replaceRequired(withBaiduUnionVerification, '</head>', `${baiduTongjiMarkup}\n</head>`, `${pagePath} head`)
    : withBaiduUnionVerification
  const withUmami = replaceRequired(withBaiduTongji, '</head>', `${umamiMarkup}\n</head>`, `${pagePath} Umami head`)
  const pageLanguage = fixedLocale || htmlLanguage
  const pageDefaultLocale = fixedLocale === 'zh-CN' ? 'zh' : defaultLocale
  const fixedLocaleAttribute = fixedLocale ? ` data-fixed-locale="${fixedLocale}"` : ''
  const localizedDocument = withUmami.replace('<html lang="zh-CN">', `<html lang="${pageLanguage}" data-default-locale="${pageDefaultLocale}"${fixedLocaleAttribute}>`)
  if (localizedDocument === withUmami) throw new Error(`${pagePath} html language marker is missing`)
  await writeFile(absolutePath, localizedDocument)
}

let home = await readFile(resolve(outputRoot, 'marketplace/index.html'), 'utf8')
home = replaceRequired(home, '<!-- DSH_STATIC_CATALOG -->', externalCatalogMarker, 'home external catalog marker')
home = replaceRequired(home, '<!-- DSH_LEGACY_REPAIR_BANNER -->', repairAvailable
  ? `<aside class="legacy-repair-banner" aria-label="旧版商城安全修复"><strong>旧版商城更新被 pnpm 拦截？</strong><span>不要放开 prepare 权限，也不要手改 Profile。</span><a href="./repair/">打开官方安全修复入口 →</a></aside>`
  : '', 'home legacy repair banner')
home = replaceBetweenMarkers(home, '<!-- DSH_STATIC_FEATURED_BEGIN -->', '<!-- DSH_STATIC_FEATURED_END -->', featured.map(featuredCard).join(''), 'featured catalog')
home = replaceBetweenMarkers(home, '<!-- DSH_STATIC_HOME_CATALOG_BEGIN -->', '<!-- DSH_STATIC_HOME_CATALOG_END -->', visibleEntries.slice(0, 6).map(homePluginCard).join(''), 'homepage catalog preview')
home = home.replace(/"softwareVersion"\s*:\s*"[^"]*"/, `"softwareVersion": "${htmlEscape(manager.version)}"`)
home = replaceElementText(home, 'install-version', managerInstallable
  ? `v${manager.version} · SHA PINNED`
  : (defaultLocale === 'en' ? `v${manager.version} · COMPATIBILITY REVIEW` : `v${manager.version} · 兼容性待核验`))
home = replaceElementText(home, 'install-command', installCommand)
if (!managerInstallable) {
  home = replaceRequired(home, 'data-copy-target="install-command"', 'data-copy-target="install-command" disabled aria-disabled="true"', 'manager install copy button')
}
home = replaceElementText(home, 'manager-protocol', `STANDARD BUNDLE / v${manager.version}`)
home = replaceElementText(home, 'manager-commit-short', manager.commit.slice(0, 7))
home = replaceElementText(home, 'stat-total', String(visibleEntries.length).padStart(2, '0'))
home = replaceElementText(home, 'stat-approved', String(visibleEntries.filter(entry => entry.status === 'approved').length).padStart(2, '0'))
home = replaceElementText(home, 'stat-categories', String(categoryCount).padStart(2, '0'))
home = replaceElementText(home, 'stat-candidates', String(candidateRegistry.entries.length).padStart(2, '0'))
home = replaceElementText(home, 'catalog-date', `catalog-index.json · ${snapshot.registry.updatedAt}`)
await writeFile(resolve(outputRoot, 'marketplace/index.html'), home)

const repairPagePath = resolve(outputRoot, 'marketplace/repair/index.html')
let repairPage = await readFile(repairPagePath, 'utf8')
repairPage = repairPage.replace('data-repair-state="catalog-pending"', `data-repair-state="${repairAvailable ? 'active' : 'catalog-pending'}"`)
repairPage = replaceRequired(repairPage, 'DSH_REPAIR_COMMAND', htmlEscape(repairAvailable ? repairCommand : 'Catalog pin pending'), 'repair command')
await writeFile(repairPagePath, repairPage)
await writeFile(resolve(outputRoot, 'marketplace/repair/repair-manifest.json'), JSON.stringify({
  schemaVersion: 1,
  status: repairAvailable ? 'active' : 'catalog-pending',
  errorCode: 'ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED',
  affected: { minimumVersion: '0.8.5', versionsBelow: manager.version },
  target: { packageName: manager.packageName, version: manager.version, repositoryUrl: manager.repositoryUrl, commit: manager.commit },
  repairTool: repairAvailable ? { packageSpecifier: repairPackageSpecifier, command: repairCommand } : null,
  lifecyclePolicy: 'ignore-all-scripts',
  requiresInteractiveConfirmation: true,
  profileMutation: 'official-dsh-cli-only',
  generatedAt,
}, null, 2) + '\n')

let plugins = await readFile(resolve(outputRoot, 'marketplace/plugins/index.html'), 'utf8')
plugins = replaceRequired(plugins, '<!-- DSH_STATIC_CATALOG -->', externalCatalogMarker, 'plugins external catalog marker')
plugins = replaceRequired(plugins, '<!-- DSH_STATIC_DISCOVERY_INDEX -->', externalDiscoveryMarker, 'plugins discovery index marker')
const categoryCounts = new Map()
knownDirectoryEntries.forEach(entry => categoryCounts.set(entry.primaryCategory, (categoryCounts.get(entry.primaryCategory) || 0) + 1))
let previousDirectoryCategory = null
const staticCards = directoryPageEntries.map(entry => {
  const category = entry.primaryCategory || 'uncategorized'
  const heading = category === previousDirectoryCategory ? ''
    : `<div class="directory-category-heading"><span>${htmlEscape(directoryCategoryLabel(category))}</span><b>${categoryCounts.get(category) || 0}</b></div>`
  previousDirectoryCategory = category
  return `${heading}${directoryCard(entry)}`
}).join('')
plugins = plugins.replace(/<!-- DSH_STATIC_PLUGIN_CARDS_BEGIN -->[\s\S]*?<!-- DSH_STATIC_PLUGIN_CARDS_END -->/, `<!-- DSH_STATIC_PLUGIN_CARDS_BEGIN -->${staticCards}<!-- DSH_STATIC_PLUGIN_CARDS_END -->`)
plugins = replaceRequired(plugins, '<!-- DSH_STATIC_CATALOG_ITEMLIST -->', `<script type="application/ld+json">${JSON.stringify(catalogItemList, null, 2)}</script>`, 'plugins catalog ItemList marker')
plugins = replaceElementText(plugins, 'stat-total', new Intl.NumberFormat(defaultLocale === 'en' ? 'en' : 'zh-CN').format(directoryStats.total))
plugins = replaceElementText(plugins, 'stat-approved', new Intl.NumberFormat(defaultLocale === 'en' ? 'en' : 'zh-CN').format(directoryStats.listed))
plugins = replaceElementText(plugins, 'stat-categories', String(directoryStats.categories))
plugins = replaceElementText(plugins, 'stat-candidates', new Intl.NumberFormat(defaultLocale === 'en' ? 'en' : 'zh-CN').format(directoryStats.unlisted))
plugins = replaceElementText(plugins, 'catalog-date', `catalog-index.json · ${snapshot.registry.updatedAt}`)
plugins = replaceElementText(plugins, 'catalog-meta', `公开插件目录 · ${discoveryIndex.source.recordCount.toLocaleString(defaultLocale === 'en' ? 'en' : 'zh-CN')} 条来源记录`)
plugins = replaceRequired(plugins, '<!-- DSH_STATIC_DISCOVERY_NOTE -->', `<span>${new Intl.NumberFormat(defaultLocale === 'en' ? 'en' : 'zh-CN').format(discoveryIndex.source.recordCount)} ${defaultLocale === 'en' ? 'public records' : '条公开记录'}</span><span>${defaultLocale === 'en' ? 'Index generated' : '索引生成时间'} · ${htmlEscape(discoveryIndex.source.generatedAt)}</span><span>${defaultLocale === 'en' ? 'From public third-party records' : '来自第三方公开记录'}</span>`, 'discovery source attribution')
await writeFile(resolve(outputRoot, 'marketplace/plugins/index.html'), plugins)

const catalogUpdatedAt = typeof snapshot.registry?.updatedAt === 'string' && snapshot.registry.updatedAt
  ? snapshot.registry.updatedAt
  : generatedAt
const llmsFacts = [
  `Last updated: ${catalogUpdatedAt.slice(0, 10)}`,
  '',
  '## Current catalog snapshot',
  '',
  `- Listed plugins: ${visibleEntries.length}`,
  `- Approved for guarded access: ${approvedCount}`,
  `- Capability groups: ${categoryCount}`,
  `- Catalog snapshot updatedAt: ${catalogUpdatedAt}`,
  `- Website build source commit: ${sourceSha}`,
].join('\n')
let llms = await readFile(resolve(outputRoot, 'marketplace/llms.txt'), 'utf8')
llms = replaceRequired(llms, '<!-- DSH_DYNAMIC_CATALOG_FACTS -->', llmsFacts, 'dynamic llms catalog facts')
llms = replaceRequired(llms, domesticGuideMarker, isDomestic
  ? `Domestic product use and issue-boundary guide: ${siteOrigin}/dsh-store-guide/`
  : '', 'domestic llms guide marker')
await writeFile(resolve(outputRoot, 'marketplace/llms.txt'), llms)

// Derive a compact, read-only ranking snapshot independently from admission.
// Only bounded public repository counters are fetched for unlisted projects;
// never fetch their manifests or enlarge the main Catalog index.
let rankings = validateRankingSnapshot(createRankingSnapshot(snapshot, catalogIndex, { sourceCommit: sourceSha, candidates: candidateRegistry }))
if (refreshRankingStars) {
  const enriched = await enrichRankingSnapshot(rankings, { token })
  rankings = validateRankingSnapshot(enriched.snapshot)
  console.log(`RANKING_METADATA ${JSON.stringify(enriched.summary)}`)
}
rankings = applyRankingRefreshState(rankings, previousRankings, rankingRefreshMode)
const rankingsBytes = Buffer.from(JSON.stringify(rankings) + '\n')
if (rankingsBytes.length > 1024 * 1024) throw new Error('Rankings snapshot exceeds the 1 MiB bound')
await writeFile(resolve(outputRoot, 'marketplace/rankings/data.json'), rankingsBytes)
const rankingsPath = resolve(outputRoot, 'marketplace/rankings/index.html')
let rankingsHtml = await readFile(rankingsPath, 'utf8')
rankingsHtml = replaceRequired(rankingsHtml, '</head>', `<meta name="dsh-rankings-sha256" content="${createHash('sha256').update(rankingsBytes).digest('hex')}">\n</head>`, 'rankings digest')
rankingsHtml = replaceBetweenMarkers(rankingsHtml, '<!-- DSH_RANKINGS_START -->', '<!-- DSH_RANKINGS_END -->',
  renderRankingRows(rankingPage(rankings, 'popular').entries, { locale: defaultLocale }), 'rankings first page')
await writeFile(rankingsPath, rankingsHtml)

// Do not publish a second monolithic catalog snapshot. The copied registry
// contains the legacy bridge, small index, and independently cacheable detail records.
await rm(resolve(outputRoot, 'marketplace/catalog.snapshot.json'), { force: true })
await writeFile(resolve(outputRoot, 'automation-status.json'), JSON.stringify(buildAutomationStatus({
  catalog: snapshot,
  candidates: candidateRegistry,
  runs: automationRuns,
  reports: automationReports,
  generatedAt: new Date().toISOString(),
  sourceCommit: sourceSha,
}), null, 2) + '\n')
await writeFile(resolve(outputRoot, 'build-manifest.json'), JSON.stringify({
  schemaVersion: 1,
  generatedAt,
  sourceCommit: sourceSha,
  siteOrigin,
  alternateOrigin,
  icp: icpNumber || null,
  baiduSiteVerification: baiduVerificationCode ? 'configured' : null,
  baiduUnionVerification: isDomestic ? 'configured' : null,
  catalogUpdatedAt: snapshot.registry.updatedAt,
  entryCount: snapshot.entries.length,
  manager: { version: manager.version, commit: manager.commit, license: manager.details?.license, status: manager.status },
  githubEnriched: snapshot.generated.githubEnriched,
}, null, 2) + '\n')
await writeFile(resolve(outputRoot, 'index.html'), `<!doctype html>\n<meta charset="utf-8">\n<meta http-equiv="refresh" content="0; url=marketplace/">\n<title>DSH STORE</title>\n<a href="marketplace/">打开 DSH STORE</a>\n`)
await writeFile(resolve(outputRoot, '.nojekyll'), '')

async function artifactFiles(directory, prefix = '') {
  const entries = await readdir(directory, { withFileTypes: true })
  const files = []
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name
    const absolutePath = resolve(directory, entry.name)
    if (entry.isDirectory()) files.push(...await artifactFiles(absolutePath, relativePath))
    else if (entry.isFile() && !['release-manifest.json', 'automation-status.json'].includes(relativePath)) files.push({ relativePath, absolutePath })
    else if (!entry.isFile()) throw new Error(`Unsupported artifact entry: ${relativePath}`)
  }
  return files
}

const releaseFiles = {}
for (const file of await artifactFiles(outputRoot)) {
  const bytes = await readFile(file.absolutePath)
  const metadata = await stat(file.absolutePath)
  releaseFiles[file.relativePath] = {
    sha256: createHash('sha256').update(bytes).digest('hex'),
    size: metadata.size,
  }
}
await writeFile(resolve(outputRoot, 'release-manifest.json'), JSON.stringify({
  schemaVersion: 1,
  generatedAt,
  sourceCommit: sourceSha,
  files: releaseFiles,
}, null, 2) + '\n')

console.log(`STATIC_MARKETPLACE_OK entries=${snapshot.entries.length} manager=${manager.version} commit=${manager.commit} origin=${siteOrigin} enriched=${snapshot.generated.githubEnriched}`)
