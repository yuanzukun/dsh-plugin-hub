import { createOperationJournal } from './operation-journal.mjs'
import { diagnoseCommand } from './diagnostics.mjs'
import { createHash, randomUUID } from 'node:crypto'
import {
  appendFile, chmod, copyFile, mkdir, readFile, rename, rm, writeFile,
} from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { buildMarketplaceSnapshot, compareVersions, githubInstallSpecifier, verifyCatalogEntry } from './catalog.mjs'
import { checkProfileHealth } from './health.mjs'
import { readProfileInventory, resolveProfileDirectory, validateProfileName } from './inventory.mjs'
import { readManagedDisabledIds, setManagedDisabled } from './managed-patch.mjs'

const ACTIONS = new Set(['install', 'update', 'migrate', 'uninstall', 'disable', 'enable'])
const PROFILE_FILES = ['package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'cordis.patch.yml']
const CRITICAL_ENTRY_IDS = new Set([
  'loader', 'web-server', 'ui-settings-plugin-inventory', 'dsh-safe-plugin-manager',
])
const PLAN_TTL_MS = 5 * 60_000
const SOURCE_VERIFICATION_CACHE_TTL_MS = 30 * 60_000
const SOURCE_VERIFICATION_MESSAGES = new Map([
  ['SOURCE_VERIFICATION_TIMEOUT', 'GitHub 固定 Commit 校验超时，请稍后重新校验。'],
  ['SOURCE_VERIFICATION_NETWORK', 'GitHub 网络暂时不可用，请稍后重新校验固定 Commit。'],
  ['SOURCE_VERIFICATION_HTTP', 'GitHub 固定 Commit 文件返回 HTTP 错误，请检查目录中的 Commit 与文件路径。'],
  ['SOURCE_MANIFEST_INVALID', 'GitHub 固定 Commit 的 package.json 不是有效 JSON。'],
  ['SOURCE_MANIFEST_MISMATCH', 'GitHub package.json 与商城目录声明不一致。'],
  ['SOURCE_PATCH_REJECTED', 'GitHub Bundle Patch 触及受保护的 DSH 组件，已拒绝操作。'],
  ['SOURCE_PATCH_MISMATCH', 'GitHub Bundle Patch 与商城目录声明的入口不一致。'],
  ['SOURCE_VERIFICATION_FAILED', 'GitHub 固定 Commit 来源校验失败。'],
])

function digest(value) {
  return createHash('sha256').update(value).digest('hex')
}

function sourceVerificationKey(entry) {
  return digest(JSON.stringify({
    repositoryUrl: entry.repositoryUrl,
    commit: entry.commit,
    manifestPath: entry.manifestPath,
    installPath: entry.installPath ?? null,
    packageName: entry.packageName,
    version: entry.version,
    license: entry.details?.license ?? null,
    entryIds: [...entry.entryIds].sort(),
    installScripts: [...entry.risk.installScripts].sort(),
  }))
}

function publicSourceVerificationError(error) {
  const code = SOURCE_VERIFICATION_MESSAGES.has(error?.code)
    ? error.code
    : 'SOURCE_VERIFICATION_FAILED'
  return Object.assign(new Error(SOURCE_VERIFICATION_MESSAGES.get(code)), { code })
}

async function fileState(profileDir, relative) {
  const path = join(profileDir, relative)
  try {
    const content = await readFile(path)
    return { relative, exists: true, sha256: digest(content), size: content.length }
  } catch (error) {
    if (error?.code === 'ENOENT') return { relative, exists: false, sha256: null, size: 0 }
    throw error
  }
}

async function capturePreconditions(profileDir) {
  return Promise.all(PROFILE_FILES.map(relative => fileState(profileDir, relative)))
}

async function verifyPreconditions(profileDir, expected) {
  const current = await capturePreconditions(profileDir)
  if (JSON.stringify(current) !== JSON.stringify(expected)) {
    const error = new Error('Profile changed after the operation plan was created')
    error.code = 'PRECONDITION_CHANGED'
    throw error
  }
}

function publicPlan(plan) {
  const { privateData: _privateData, ...value } = plan
  return value
}

function pluginCommandError(result) {
  const pnpmUnavailable = result?.exitCode === 127
  const output = `${String(result?.stderr ?? '')}\n${String(result?.stdout ?? '')}`
  const pnpmCode = output.match(/\b(ERR_PNPM_[A-Z0-9_]+)\b/)?.[1] ?? null
  const diagnostic = diagnoseCommand(result)
  return Object.assign(new Error(pnpmUnavailable
    ? 'pnpm is unavailable in the DSH plugin runtime PATH'
    : 'official DSH plugin command failed'), {
    code: pnpmUnavailable ? 'DSH_PNPM_NOT_FOUND' : 'DSH_PLUGIN_COMMAND_FAILED',
    exitCode: result?.exitCode ?? null,
    diagnostic,
  })
}

function pluginAddArgs(entry, action) {
  const args = ['add']
  if (entry.risk.installScripts.length === 0) args.push('--ignore-scripts')
  else args.push(`--allow-build=${entry.packageName}`)
  args.push(githubInstallSpecifier(entry))
  return args
}

function assertManageable(entry, installed, action) {
  if (!entry) throw Object.assign(new Error('plugin is not present in the GitHub registry'), { code: 'NOT_IN_REGISTRY' })
  if (entry.status === 'blocked') throw Object.assign(new Error(entry.statusReason), { code: 'REGISTRY_BLOCKED' })
  if (entry.status === 'unlisted' && ['install', 'update', 'migrate'].includes(action)) {
    throw Object.assign(new Error(entry.statusReason), { code: 'REGISTRY_UNLISTED' })
  }
  if (entry.packageName.startsWith('@deepseek-ai/') || installed?.official) {
    throw Object.assign(new Error('official DSH components are permanently read-only'), { code: 'OFFICIAL_PROTECTED' })
  }
  const selfPackageAction = entry.packageName === 'dsh-safe-plugin-manager' && ['update', 'migrate'].includes(action)
  if (entry.packageName === 'dsh-safe-plugin-manager' && !selfPackageAction) {
    throw Object.assign(new Error('the manager only allows self-update'), { code: 'SELF_PROTECTED' })
  }
  if (!selfPackageAction && entry.entryIds.some(id => CRITICAL_ENTRY_IDS.has(id))) {
    throw Object.assign(new Error('plugin targets a protected DSH entry id'), { code: 'CRITICAL_ENTRY_PROTECTED' })
  }
}

async function readDisabled(profileDir) {
  try {
    return readManagedDisabledIds(await readFile(join(profileDir, 'cordis.patch.yml'), 'utf8'))
  } catch (error) {
    if (error?.code === 'ENOENT') return []
    throw error
  }
}

async function atomicWrite(path, content) {
  const temporary = `${path}.dsh-safe-plugin-manager-${randomUUID()}.tmp`
  await writeFile(temporary, content, { mode: 0o600 })
  await rename(temporary, path)
}

async function updateDisabledPatch(profileDir, entryIds, disabled) {
  const path = join(profileDir, 'cordis.patch.yml')
  let current
  try {
    current = await readFile(path, 'utf8')
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
    current = '[]\n'
  }
  const next = setManagedDisabled(current, entryIds, disabled)
  if (next !== current) await atomicWrite(path, next)
}

async function backupProfile(dshHome, profileDir, transactionId, preconditions) {
  const root = join(dshHome, 'dsh-safe-plugin-manager', 'backups', transactionId)
  await mkdir(root, { recursive: true, mode: 0o700 })
  for (const item of preconditions) {
    if (item.exists) {
      const destination = join(root, item.relative)
      await copyFile(join(profileDir, item.relative), destination)
      await chmod(destination, 0o600)
    }
  }
  await writeFile(join(root, 'manifest.json'), JSON.stringify({
    schemaVersion: 1, transactionId, createdAt: new Date().toISOString(), files: preconditions,
  }, null, 2) + '\n', { mode: 0o600 })
  return root
}

async function restoreBackup(profileDir, backupDir, preconditions) {
  for (const item of preconditions) {
    const target = join(profileDir, item.relative)
    if (item.exists) await atomicWrite(target, await readFile(join(backupDir, item.relative)))
    else await rm(target, { force: true })
  }
}

async function appendAudit(dshHome, event) {
  const dir = join(dshHome, 'dsh-safe-plugin-manager')
  await mkdir(dir, { recursive: true, mode: 0o700 })
  await appendFile(join(dir, 'history.jsonl'), JSON.stringify(event) + '\n', { mode: 0o600 })
}

async function acquireLock(dshHome, profile) {
  const parent = join(dshHome, 'dsh-safe-plugin-manager', 'locks')
  const path = join(parent, `${profile}.lock`)
  await mkdir(parent, { recursive: true, mode: 0o700 })
  try {
    await mkdir(path, { mode: 0o700 })
  } catch (error) {
    if (error?.code === 'EEXIST') {
      throw Object.assign(new Error('another plugin operation is already running for this Profile'), { code: 'PROFILE_LOCKED' })
    }
    throw error
  }
  return async () => rm(path, { recursive: true, force: true })
}

function planImpact(action, entry) {
  const packageOperation = ['install', 'update', 'migrate', 'uninstall'].includes(action)
  return {
    mayModify: packageOperation
      ? ['package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'node_modules', 'dsh.profile.bundles', 'guardian pending recovery record']
      : ['cordis.patch.yml managed block'],
    neverModify: ['DeepSeek Harness source', '@deepseek-ai/* packages', 'other Profiles', 'managed-block external content'],
    restartRequired: packageOperation,
    installScripts: ['install', 'update', 'migrate'].includes(action) ? entry.risk.installScripts : [],
    lifecyclePolicy: ['install', 'update', 'migrate'].includes(action)
      ? entry.risk.installScripts.length === 0 ? 'ignore-all-scripts' : 'exact-target-allow-build'
      : 'not-applicable',
    sourceReview: entry.sourceReview ?? null,
    sourceTransition: action === 'migrate'
      ? '仅将 Profile 依赖从本地链接切换为目录固定的 GitHub Commit，不删除或修改原本地目录'
      : null,
  }
}

export function createOperationService(options = {}) {
  const dshHome = options.dshHome
  const defaultProfile = validateProfileName(options.defaultProfile ?? 'web')
  const catalogService = options.catalogService
  const runner = options.runner
  const mutationsEnabled = options.mutationsEnabled === true
  const sourceVerifier = options.sourceVerifier ?? verifyCatalogEntry
  const sourceUpdateService = options.sourceUpdateService ?? null
  const telemetryClient = options.telemetryClient ?? { recordInstall: async () => ({ status: 'disabled' }) }
  const runtimeInstanceId = typeof options.runtimeInstanceId === 'string' ? options.runtimeInstanceId : null
  const planTtlMs = options.planTtlMs ?? PLAN_TTL_MS
  const sourceVerificationCacheTtlMs = options.sourceVerificationCacheTtlMs ?? SOURCE_VERIFICATION_CACHE_TTL_MS
  const journal = createOperationJournal({ dshHome, bootId: runtimeInstanceId ?? randomUUID() })
  const plans = new Map()
  const sourceVerificationCache = new Map()

  async function verifySource(entry) {
    const key = sourceVerificationKey(entry)
    const cached = sourceVerificationCache.get(key)
    if (cached && Date.now() - cached.cachedAt < sourceVerificationCacheTtlMs) {
      return { ...cached.value, cacheStatus: 'memory-cache', reusedAt: new Date().toISOString() }
    }
    const value = await sourceVerifier(entry)
    if (!value || value.status !== 'verified') {
      throw Object.assign(new Error('source verifier did not return a verified result'), {
        code: 'SOURCE_VERIFICATION_FAILED',
      })
    }
    sourceVerificationCache.set(key, { cachedAt: Date.now(), value })
    return { ...value, cacheStatus: 'fresh' }
  }

  async function createPlan(input = {}) {
    if (!mutationsEnabled) throw Object.assign(new Error('guarded write mode is disabled by configuration'), { code: 'MUTATIONS_DISABLED' })
    const action = typeof input.action === 'string' ? input.action : ''
    if (!ACTIONS.has(action)) throw Object.assign(new Error('unsupported operation action'), { code: 'INVALID_ACTION' })
    const profile = validateProfileName(input.profile ?? defaultProfile)
    const profileDir = resolveProfileDirectory(dshHome, profile)
    const inventory = await readProfileInventory({ dshHome, profile })
    const catalog = await catalogService.load()
    const entry = catalog.entries.find(item => item.id === input.pluginId) ?? null
    const installed = entry ? inventory.plugins.find(item => item.packageName === entry.packageName) ?? null : null
    assertManageable(entry, installed, action)
    let targetEntry = entry
    if (action === 'install' && installed) throw Object.assign(new Error('plugin is already installed'), { code: 'ALREADY_INSTALLED' })
    if (action !== 'install' && !installed) throw Object.assign(new Error('plugin is not installed'), { code: 'NOT_INSTALLED' })
    if (action === 'update') {
      if (['link', 'file', 'workspace'].includes(installed.source)) {
        throw Object.assign(new Error('use the explicit marketplace migration action for local development links'), { code: 'LOCAL_SOURCE_PROTECTED' })
      }
      if (typeof input.sourceCommit === 'string' && input.sourceCommit !== '') {
        if (!sourceUpdateService) throw Object.assign(new Error('source update service is unavailable'), { code: 'SOURCE_UPDATE_UNAVAILABLE' })
        targetEntry = sourceUpdateService.approvedCandidate(entry, input.sourceCommit, {
          userAcceptedRisk: input.sourceRiskAccepted === true,
        })
        if (targetEntry.id !== entry.id || targetEntry.packageName !== entry.packageName || targetEntry.repositoryUrl !== entry.repositoryUrl) {
          throw Object.assign(new Error('source update candidate identity does not match the registry'), { code: 'SOURCE_UPDATE_IDENTITY_MISMATCH' })
        }
        if (compareVersions(installed.version, targetEntry.version) !== -1) {
          throw Object.assign(new Error('source update candidate is not newer than the installed version'), { code: 'NO_UPDATE' })
        }
      } else {
        const market = buildMarketplaceSnapshot(catalog, inventory)
        const state = market.entries.find(item => item.id === entry.id)
        if (!state?.updateAvailable) throw Object.assign(new Error('registry does not contain a newer version'), { code: 'NO_UPDATE' })
      }
    }
    if (action === 'migrate' && !['link', 'file', 'workspace'].includes(installed.source)) {
      throw Object.assign(new Error('only local development links can be migrated to the marketplace source'), { code: 'MIGRATION_NOT_REQUIRED' })
    }
    let sourceVerification = { status: 'not-required', verifiedAt: null }
    if (['install', 'update', 'migrate'].includes(action)) {
      try {
        sourceVerification = await verifySource(targetEntry)
      } catch (error) {
        throw publicSourceVerificationError(error)
      }
    }
    const disabledIds = new Set(await readDisabled(profileDir))
    if (action === 'disable' && entry.entryIds.every(id => disabledIds.has(id))) {
      throw Object.assign(new Error('plugin is already disabled by this manager'), { code: 'ALREADY_DISABLED' })
    }
    if (action === 'enable' && entry.entryIds.every(id => !disabledIds.has(id))) {
      throw Object.assign(new Error('plugin is not disabled by this manager'), { code: 'ALREADY_ENABLED' })
    }
    const planId = randomUUID()
    const createdAt = new Date()
    const preconditions = await capturePreconditions(profileDir)
    const riskReviewed = targetEntry.sourceReview?.status === 'user-review-required'
    const confirmation = riskReviewed
      ? `UPDATE-RISK ${entry.packageName} ${profile} ${targetEntry.commit.slice(0, 12)}`
      : `${action.toUpperCase()} ${entry.packageName} ${profile}`
    const plan = {
      schemaVersion: 1,
      planId,
      operationId: planId,
      journalPath: `dsh-safe-plugin-manager/operations/${planId}.json`,
      action,
      profile,
      createdAt: createdAt.toISOString(),
      expiresAt: new Date(createdAt.getTime() + planTtlMs).toISOString(),
      plugin: {
        id: entry.id,
        packageName: entry.packageName,
        currentVersion: installed?.version ?? null,
        targetVersion: ['install', 'update', 'migrate'].includes(action) ? targetEntry.version : null,
        repositoryUrl: entry.repositoryUrl,
        commit: targetEntry.commit,
        manifestPath: targetEntry.manifestPath, installPath: targetEntry.installPath ?? null,
        entryIds: entry.entryIds,
        sourceUpdate: targetEntry.commit !== entry.commit,
        sourceReview: targetEntry.sourceReview ?? null,
      },
      confirmation,
      impact: planImpact(action, targetEntry),
      sourceVerification,
      preconditions,
      privateData: { entry: targetEntry, profileDir },
    }
    plans.set(planId, plan)
    return publicPlan(plan)
  }

  function claimPlan(input = {}) {
    const plan = plans.get(input.planId)
    if (!plan) throw Object.assign(new Error('operation plan is missing or already used'), { code: 'PLAN_NOT_FOUND' })
    plans.delete(input.planId)
    if (Date.now() > Date.parse(plan.expiresAt)) throw Object.assign(new Error('operation plan expired'), { code: 'PLAN_EXPIRED' })
    if (input.confirmation !== plan.confirmation) throw Object.assign(new Error('confirmation text does not match the operation plan'), { code: 'CONFIRMATION_MISMATCH' })
    return plan
  }

  async function executePlan(plan, transactionId = randomUUID()) {
    const release = await acquireLock(dshHome, plan.profile)
    let backupDir = null
    let packageCommandMayHaveMutated = false
    try {
      await verifyPreconditions(plan.privateData.profileDir, plan.preconditions)
      backupDir = await backupProfile(dshHome, plan.privateData.profileDir, transactionId, plan.preconditions)
      const { action } = plan
      const { entry } = plan.privateData
      if (action === 'install' || action === 'update' || action === 'migrate') {
        const result = await runner.plugin(plan.profile, pluginAddArgs(entry, action))
        packageCommandMayHaveMutated = result.ok || result.exitCode !== 127
        if (!result.ok) throw pluginCommandError(result)
      } else if (action === 'uninstall') {
        const result = await runner.plugin(plan.profile, ['remove', entry.packageName])
        packageCommandMayHaveMutated = result.ok || result.exitCode !== 127
        if (!result.ok) throw pluginCommandError(result)
        await updateDisabledPatch(plan.privateData.profileDir, entry.entryIds, false)
      } else {
        await updateDisabledPatch(plan.privateData.profileDir, entry.entryIds, action === 'disable')
      }
      const health = await checkProfileHealth({ dshHome, profile: plan.profile, runner })
      if (health.status === 'unhealthy') throw Object.assign(new Error('post-operation health check failed'), { code: 'HEALTH_CHECK_FAILED' })
      if (plan.impact.restartRequired) {
        const postconditions = await capturePreconditions(plan.privateData.profileDir)
        const recoveryDir = join(dshHome, 'dsh-safe-plugin-manager', 'guardian')
        await mkdir(recoveryDir, { recursive: true, mode: 0o700 })
        await atomicWrite(join(recoveryDir, 'pending-recovery.json'), `${JSON.stringify({
          schemaVersion: 1, transactionId, profile: plan.profile, packageName: entry.packageName,
          backupDir, preconditions: plan.preconditions, postconditions,
          authorizedByConfirmation: plan.confirmation, createdAt: new Date().toISOString(),
        }, null, 2)}\n`)
      }
      const value = {
        schemaVersion: 1, transactionId, status: 'applied', action,
        profile: plan.profile, packageName: entry.packageName, backupId: transactionId,
        restartRequired: plan.impact.restartRequired, runtimeInstanceId,
        targetVersion: plan.plugin.targetVersion, health,
      }
      if (action === 'install') value.installReceipt = await telemetryClient.recordInstall({ pluginId: entry.id, version: entry.version, receiptId: transactionId })
      await appendAudit(dshHome, { ...value, at: new Date().toISOString() })
      return value
    } catch (error) {
      let rollback = 'not-required'
      const rollbackDetails = { profileFiles: 'not-required', dependencies: 'not-required' }
      if (backupDir) {
        try {
          await restoreBackup(plan.privateData.profileDir, backupDir, plan.preconditions)
          rollbackDetails.profileFiles = 'succeeded'
        } catch {
          rollbackDetails.profileFiles = 'failed'
        }
        if (rollbackDetails.profileFiles === 'succeeded' && packageCommandMayHaveMutated) {
          try {
            const restoreInstall = await runner.plugin(plan.profile, ['install', '--offline', '--ignore-scripts'])
            if (!restoreInstall.ok) throw new Error('dependency restore command failed')
            rollbackDetails.dependencies = 'succeeded'
          } catch {
            rollbackDetails.dependencies = 'failed'
          }
        }
        rollback = rollbackDetails.profileFiles === 'succeeded'
          && rollbackDetails.dependencies !== 'failed' ? 'succeeded' : 'failed'
      }
      const value = {
        schemaVersion: 1, transactionId,
        status: rollback === 'succeeded' ? 'rolled-back' : rollback === 'failed' ? 'recovery-required' : 'failed',
        restartRequired: false, action: plan.action,
        profile: plan.profile, packageName: plan.plugin.packageName, backupId: backupDir ? transactionId : null,
        error: {
          code: error?.code ?? 'OPERATION_FAILED', message: String(error?.message ?? error),
          exitCode: error?.exitCode ?? null, diagnostic: error?.diagnostic ?? null,
        },
        rollback, rollbackDetails,
      }
      await appendAudit(dshHome, { ...value, at: new Date().toISOString() })
      return value
    } finally {
      await release()
    }
  }

  async function execute(input = {}) { return executePlan(claimPlan(input)) }

  async function start(input = {}) {
    const plan = claimPlan(input)
    const id = plan.operationId
    const queued = await journal.reserve(plan, id)
    // Reservation is durable before work is dispatched. Never replay from disk.
    setImmediate(() => { void (async () => {
      try {
        await journal.update(id, { state: 'running', phase: 'cli-and-health' })
        const value = await executePlan(plan, id)
        const state = value.status === 'applied' ? 'succeeded' : value.status
        await journal.update(id, { state, phase: 'complete', result: {
          schemaVersion: 1, transactionId: id, status: value.status, action: value.action,
          profile: value.profile, packageName: value.packageName, targetVersion: value.targetVersion,
          backupId: value.backupId, restartRequired: value.restartRequired === true,
          runtimeInstanceId: value.runtimeInstanceId, rollback: value.rollback,
          rollbackDetails: value.rollbackDetails,
          health: value.health ? { status: value.health.status } : null,
          error: value.error ? { code: value.error.code, message: value.error.diagnostic?.message ?? '操作失败，请检查恢复记录。', diagnostic: value.error.diagnostic } : null,
        }, restartRequired: value.restartRequired === true })
      } catch {
        await journal.update(id, { state: 'recovery-required', phase: 'execution-or-record-failed', restartRequired: false }).catch(() => {})
      }
    })() })
    return queued
  }
  return { createPlan, execute, start, journal }

}
