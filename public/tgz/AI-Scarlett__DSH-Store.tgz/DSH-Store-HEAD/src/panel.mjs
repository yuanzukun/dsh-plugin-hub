import { buildMarketplaceSnapshot, paginateMarketplaceSnapshot, selectMarketplaceIndexEntries } from './catalog.mjs'
import { checkProfileHealth } from './health.mjs'
import { readProfileInventory, validateProfileName } from './inventory.mjs'
import { readMarketplaceProvenance } from './provenance.mjs'

export const ROUTE_PATH = '/api2/dsh-safe-plugin-manager/inventory'
export const MARKET_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/market'
export const HEALTH_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/health'
export const SOURCE_UPDATE_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/source-update'
export const DSH_VERSION_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/dsh-version'
export const PLAN_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/plan'
export const EXECUTE_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/execute'
export const OPERATIONS_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/operations'
export const RUNTIME_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/runtime'
export const RESTART_PLAN_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/restart/plan'
export const RESTART_EXECUTE_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/restart/execute'
export const GUARDIAN_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/guardian'
export const GUARDIAN_PLAN_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/guardian/plan'
export const GUARDIAN_EXECUTE_ROUTE_PATH = '/api2/dsh-safe-plugin-manager/guardian/execute'
const MAX_BODY_BYTES = 16 * 1024

class HttpError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
  }
}

function header(req, name) {
  const value = req?.headers?.[name]
  return Array.isArray(value) ? value[0] : value
}

function assertSameOrigin(req) {
  const host = header(req, 'host')
  const origin = header(req, 'origin')
  if (typeof host !== 'string' || host === '') throw new HttpError(400, 'missing Host header')
  if (typeof origin !== 'string' || origin === '') return
  let originHost
  try {
    originHost = new URL(origin).host
  } catch {
    throw new HttpError(403, 'invalid Origin header')
  }
  if (originHost !== host) throw new HttpError(403, 'cross-origin request denied')
}

function assertIntent(req, expected) {
  if (header(req, 'x-dsh-safe-intent') !== expected) {
    throw new HttpError(403, `missing ${expected} operation intent`)
  }
}

async function readJsonBody(req) {
  const contentType = header(req, 'content-type')
  if (typeof contentType !== 'string' || !contentType.toLowerCase().startsWith('application/json')) {
    throw new HttpError(415, 'content-type must be application/json')
  }
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    const value = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk))
    size += value.length
    if (size > MAX_BODY_BYTES) throw new HttpError(413, 'request body too large')
    chunks.push(value)
  }
  const text = Buffer.concat(chunks).toString('utf8')
  if (text.trim() === '') return {}
  try {
    const body = JSON.parse(text)
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('body must be an object')
    return body
  } catch (error) {
    throw new HttpError(400, `invalid JSON body: ${String(error?.message || error)}`)
  }
}

function sendJson(res, status, payload, extraHeaders = {}) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...extraHeaders,
  })
  res.end(JSON.stringify(payload))
}

function requestedProfile(body, options) {
  const profile = validateProfileName(body.profile ?? options.defaultProfile ?? 'web')
  if (options.desktopMode === true && profile !== 'desktop') {
    throw Object.assign(new Error('Desktop 商城只能读取当前 Desktop Profile。'), {
      code: 'DESKTOP_PROFILE_MISMATCH', status: 409,
    })
  }
  return profile
}

function rejectDesktopMutation(options) {
  if (options.desktopMode === true) {
    throw Object.assign(new Error('官方 Desktop 的插件安装和重启由应用自身管理；请使用官方“插件”页。'), {
      code: 'DESKTOP_MUTATION_UNSUPPORTED', status: 409,
    })
  }
}

export async function handleInventoryRequest(req, res, options = {}) {
  try {
    if (req.method !== 'POST') {
      sendJson(res, 405, { ok: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'POST required' } }, { allow: 'POST' })
      return
    }
    assertSameOrigin(req)
    const body = await readJsonBody(req)
    const profile = requestedProfile(body, options)
    const value = await readProfileInventory({ dshHome: options.dshHome, profile })
    sendJson(res, 200, { ok: true, value })
  } catch (error) {
    const status = Number.isInteger(error?.status) ? error.status : 500
    const code = status === 500 ? 'INVENTORY_FAILED' : 'REQUEST_REJECTED'
    sendJson(res, status, { ok: false, error: { code, message: String(error?.message || error) } })
  }
}

async function handleJsonRequest(req, res, callback, intent = null) {
  try {
    if (req.method !== 'POST') {
      sendJson(res, 405, { ok: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'POST required' } }, { allow: 'POST' })
      return
    }
    assertSameOrigin(req)
    if (intent !== null) assertIntent(req, intent)
    const body = await readJsonBody(req)
    const value = await callback(body)
    sendJson(res, 200, { ok: true, value })
  } catch (error) {
    const known = typeof error?.code === 'string' && error.code !== ''
    const status = Number.isInteger(error?.status) ? error.status : known ? 409 : 500
    sendJson(res, status, {
      ok: false,
      error: {
        code: known ? error.code : status === 500 ? 'MANAGER_REQUEST_FAILED' : 'REQUEST_REJECTED',
        message: String(error?.message || error),
      },
    })
  }
}

export function handleMarketRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, async body => {
    const profile = requestedProfile(body, options)
    const inventory = await readProfileInventory({ dshHome: options.dshHome, profile })
    const view = body.view ?? 'market'
    // Load the small index first. With the split Catalog format only the
    // requested page's detail files are hydrated; v1 services remain fully
    // compatible for older fixtures and during a staged rollout.
    const catalogIndex = typeof options.catalogService.loadIndex === 'function'
      ? await options.catalogService.loadIndex({ force: body.refresh === true })
      : await options.catalogService.load({ force: body.refresh === true })
    const candidateRegistry = view === 'candidates'
      ? await (options.candidateService?.load({ force: body.refresh === true }) ?? Promise.resolve(null))
      : null
    const managedPackages = await readMarketplaceProvenance(options.dshHome, profile)
    const dshVersion = options.dshVersionService?.peek?.() ?? null
    if (catalogIndex.schemaVersion === 2 && view !== 'candidates') {
      const selection = selectMarketplaceIndexEntries(catalogIndex, {
        view, compatibleWith: body.compatibleWith, query: body.query, category: body.category, featuredOnly: body.featuredOnly === true,
        page: body.page, pageSize: body.pageSize, inventory,
      })
      try {
        const details = await options.catalogService.loadDetails(selection.entries.map(entry => entry.id), { index: catalogIndex })
        const snapshot = buildMarketplaceSnapshot({ ...catalogIndex, schemaVersion: 1, entries: details }, inventory, '', {
          managedPackages, candidateRegistry, dshVersion, catalogPackageNames: catalogIndex.entries.map(entry => entry.packageName),
        })
        const byId = new Map(snapshot.entries.map(entry => [entry.id, entry]))
        return {
          ...snapshot,
          entries: selection.entries.map(entry => byId.get(entry.id)).filter(Boolean),
          candidates: [],
          catalogPackageNames: catalogIndex.entries.map(entry => entry.packageName),
          filters: { categoryIds: selection.categoryIds, featuredOnly: selection.pagination.featuredOnly },
          pagination: selection.pagination,
        }
      } catch (error) {
        // A page must never combine a remote index with bundled detail files.
        // Ask the service for one complete atomic generation; it may return the
        // bundled bridge/index/details set after the remote detail failure.
        if (typeof options.catalogService.load !== 'function') throw error
        const fallback = await options.catalogService.load()
        if (fallback.source?.kind !== 'bundled') throw error
        const snapshot = buildMarketplaceSnapshot(fallback, inventory, '', {
          managedPackages, candidateRegistry, dshVersion,
        })
        return paginateMarketplaceSnapshot(snapshot, {
          view, compatibleWith: body.compatibleWith, query: body.query, category: body.category, featuredOnly: body.featuredOnly === true,
          page: body.page, pageSize: body.pageSize,
          catalogPackageNames: fallback.entries.map(entry => entry.packageName),
        })
      }
    }
    const catalog = catalogIndex.schemaVersion === 2
      ? { ...catalogIndex, schemaVersion: 1, entries: [] }
      : catalogIndex
    const snapshot = buildMarketplaceSnapshot(catalog, inventory, '', { managedPackages, candidateRegistry, dshVersion })
    return paginateMarketplaceSnapshot(snapshot, {
      view, compatibleWith: body.compatibleWith,
      query: body.query,
      category: body.category,
      featuredOnly: body.featuredOnly === true,
      includeRejected: view === 'candidates',
      page: body.page,
      pageSize: body.pageSize,
      catalogPackageNames: catalogIndex.entries?.map(entry => entry.packageName),
    })
  })
}

export function handleHealthRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, async body => {
    const profile = requestedProfile(body, options)
    const catalog = await options.catalogService.load({ force: body.refresh === true })
    return checkProfileHealth({
      dshHome: options.dshHome,
      profile,
      runner: options.desktopMode === true ? null : options.runner,
      catalog,
      permissionDecisions: body.permissionDecisions,
    })
  })
}

export function handleSourceUpdateRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, async body => {
    const profile = requestedProfile(body, options)
    const inventory = await readProfileInventory({ dshHome: options.dshHome, profile })
    const catalog = await options.catalogService.load({ force: body.refresh === true })
    const entry = catalog.entries.find(item => item.id === body.pluginId) ?? null
    if (!entry) throw Object.assign(new Error('plugin is not present in the GitHub registry'), { code: 'NOT_IN_REGISTRY' })
    const installed = inventory.plugins.find(item => item.packageName === entry.packageName) ?? null
    return options.sourceUpdateService.inspect(entry, installed)
  })
}

export function handleDshVersionRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, body => options.dshVersionService.inspect({ force: body.refresh === true }))
}

export function handlePlanRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, body => { rejectDesktopMutation(options); return options.operationService.createPlan(body) }, 'plan')
}

export function handleExecuteRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, body => { rejectDesktopMutation(options); return options.operationService.start(body) }, 'execute')
}

export function handleRuntimeRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, async body => {
    const profile = requestedProfile(body, options)
    if (!options.runtimeStatus || options.runtimeStatus.profile !== profile) {
      throw Object.assign(new Error('runtime status is unavailable for this Profile'), { code: 'RUNTIME_STATUS_UNAVAILABLE' })
    }
    return options.runtimeStatus
  })
}

export function handleRestartPlanRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, body => { rejectDesktopMutation(options); return options.restartService.createPlan(body) }, 'restart-plan')
}

export function handleRestartExecuteRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, body => { rejectDesktopMutation(options); return options.restartService.execute(body) }, 'restart-execute')
}

export function handleGuardianRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, () => options.desktopMode === true
    ? { supported: false, available: false, errorCode: 'OFFICIAL_DESKTOP_OWNS_HOST',
      message: '官方 Desktop 自行管理 Host；商城 Guardian 不适用于 Desktop。' }
    : options.guardianService.status())
}

export function handleGuardianPlanRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, body => { rejectDesktopMutation(options); return options.guardianService.createInstallPlan(body) }, 'guardian-plan')
}

export function handleGuardianExecuteRequest(req, res, options = {}) {
  return handleJsonRequest(req, res, body => { rejectDesktopMutation(options); return options.guardianService.executeInstall(body) }, 'guardian-execute')
}

export function registerInventoryRoute(webServer, options = {}) {
  return webServer.register({
    kind: 'exact',
    path: ROUTE_PATH,
    handler: authenticated(options, (req, res) => handleInventoryRequest(req, res, options)),
  })
}

// WebServer dispatches exact routes before Connection's /api prefix. Every
// route therefore delegates to the public Connection authority explicitly.
function authenticated(options, handler) {
  return async (req, res) => {
    let rejection = 503
    try {
      if (typeof options.connection?.requestRejection === 'function') {
        rejection = await options.connection.requestRejection(req)
      }
    } catch { /* Missing or failed authority never permits a request. */ }
    if (rejection !== undefined) {
      const status = rejection === 401 || rejection === 403 ? rejection : 503
      sendJson(res, status, { ok: false, error: {
        code: status === 503 ? 'AUTHORITY_UNAVAILABLE' : 'AUTHENTICATION_REQUIRED',
        message: status === 503 ? 'DSH authentication is unavailable' : 'DSH browser authentication required',
      } })
      return
    }
    return handler(req, res)
  }
}

export function registerManagerRoutes(webServer, options = {}) {
  const routes = [
    ['/api2/dsh-safe-plugin-manager/activation', (req, res) => handleJsonRequest(req, res, async () => options.activationService.inspect(await options.catalogService.load()))],
    [OPERATIONS_ROUTE_PATH, async (req, res) => {
      try {
        if (req.method !== 'GET') return sendJson(res, 405, { ok: false }, { allow: 'GET' })
        assertSameOrigin(req)
        const id = new URL(req.url, 'http://localhost').searchParams.get('id')
        const value = id ? await options.operationService.journal.get(id) : await options.operationService.journal.list()
        sendJson(res, 200, { ok: true, value })
      } catch { sendJson(res, 409, { ok: false, error: { code: 'JOURNAL_UNAVAILABLE', message: '操作记录不可用，请检查恢复状态。' } }) }
    }],
    [ROUTE_PATH, (req, res) => handleInventoryRequest(req, res, options)],
    [MARKET_ROUTE_PATH, (req, res) => handleMarketRequest(req, res, options)],
    [HEALTH_ROUTE_PATH, (req, res) => handleHealthRequest(req, res, options)],
    [SOURCE_UPDATE_ROUTE_PATH, (req, res) => handleSourceUpdateRequest(req, res, options)],
    [DSH_VERSION_ROUTE_PATH, (req, res) => handleDshVersionRequest(req, res, options)],
    [PLAN_ROUTE_PATH, (req, res) => handlePlanRequest(req, res, options)],
    [EXECUTE_ROUTE_PATH, (req, res) => handleExecuteRequest(req, res, options)],
    [RUNTIME_ROUTE_PATH, (req, res) => handleRuntimeRequest(req, res, options)],
    [RESTART_PLAN_ROUTE_PATH, (req, res) => handleRestartPlanRequest(req, res, options)],
    [RESTART_EXECUTE_ROUTE_PATH, (req, res) => handleRestartExecuteRequest(req, res, options)],
    [GUARDIAN_ROUTE_PATH, (req, res) => handleGuardianRequest(req, res, options)],
    [GUARDIAN_PLAN_ROUTE_PATH, (req, res) => handleGuardianPlanRequest(req, res, options)],
    [GUARDIAN_EXECUTE_ROUTE_PATH, (req, res) => handleGuardianExecuteRequest(req, res, options)],
  ]
  const disposers = routes.map(([path, handler]) => webServer.register({ kind: 'exact', path, handler: authenticated(options, handler) }))
  return () => {
    for (const dispose of disposers.reverse()) if (typeof dispose === 'function') dispose()
  }
}
