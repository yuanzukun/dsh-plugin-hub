import { compareVersions, DSH_RC_RELEASES, dshReleaseVersion } from './catalog.mjs'
import { COMPATIBILITY_HOLD_PREFIX } from './catalog-compatibility-policy.mjs'

const COMMIT_SHA = /^[0-9a-f]{40}$/
const SEMVER = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/
const PREFERRED_DSH_RELEASE_KEYS = new Map(
  DSH_RC_RELEASES.map(release => [dshReleaseVersion(release), release]),
)

function normalizedPath(value) {
  return value === undefined || value === null || value === '' ? null : String(value)
}

function sorted(values) {
  return [...(Array.isArray(values) ? values : [])].sort()
}

function unknownEvidence(summary) {
  return {
    status: 'unknown',
    method: null,
    checkedAt: null,
    evidenceUrl: null,
    dshRelease: null,
    systems: [],
    profiles: [],
    summary,
  }
}

function normalizedDshReleaseStatuses(value, label) {
  const statuses = new Map()
  for (const [release, status] of Object.entries(value ?? {})) {
    const version = dshReleaseVersion(release)
    if (version === null) throw new Error(`${label}.${release} is not a supported DSH release key`)
    if (!['compatible', 'incompatible', 'unknown'].includes(status)) {
      throw new Error(`${label}.${release} has an invalid compatibility status`)
    }
    if (statuses.has(version) && statuses.get(version) !== status) {
      throw new Error(`${label} declares conflicting aliases for ${version}`)
    }
    statuses.set(version, status)
  }
  return statuses
}

function normalizedDshOperationStatuses(value, label) {
  const statuses = new Map()
  const operations = ['install', 'start', 'uninstall', 'rollback']
  for (const [release, record] of Object.entries(value ?? {})) {
    const version = dshReleaseVersion(release)
    if (version === null) throw new Error(`${label}.${release} is not a supported DSH release key`)
    if (!record || typeof record !== 'object' || Array.isArray(record)
      || Object.keys(record).some(operation => !operations.includes(operation))) {
      throw new Error(`${label}.${release} must declare install, start, uninstall, and rollback`)
    }
    const normalized = Object.fromEntries(operations.map(operation => {
      const status = record[operation] ?? 'unknown'
      if (!['passed', 'failed', 'unknown'].includes(status)) {
        throw new Error(`${label}.${release}.${operation} must be passed, failed, or unknown`)
      }
      return [operation, status]
    }))
    if (statuses.has(version) && JSON.stringify(statuses.get(version)) !== JSON.stringify(normalized)) {
      throw new Error(`${label} declares conflicting operation aliases for ${version}`)
    }
    statuses.set(version, normalized)
  }
  return statuses
}

export function sourceDeclaredCompatibility(entry, candidate) {
  const releaseVersions = new Set([
    ...DSH_RC_RELEASES,
    ...Object.keys(entry.compatibility?.dshReleases ?? {}),
    ...Object.keys(entry.compatibility?.dshOperations ?? {}),
    ...Object.keys(candidate.compatibility?.dshReleases ?? {}),
    ...Object.keys(candidate.compatibility?.dshOperations ?? {}),
  ].map(release => {
    const version = dshReleaseVersion(release)
    if (version === null) throw new Error(`compatibility release ${release} is not a supported DSH release key`)
    return version
  }))
  const candidateStatuses = normalizedDshReleaseStatuses(
    candidate.compatibility?.dshReleases,
    'candidate compatibility.dshReleases',
  )
  const candidateOperations = normalizedDshOperationStatuses(
    candidate.compatibility?.dshOperations,
    'candidate compatibility.dshOperations',
  )
  const dshReleases = {}
  const dshOperations = {}
  for (const version of releaseVersions) {
    const release = PREFERRED_DSH_RELEASE_KEYS.get(version) ?? version
    dshReleases[release] = candidateStatuses.get(version) ?? 'unknown'
    dshOperations[release] = candidateOperations.get(version) ?? {
      install: 'unknown',
      start: 'unknown',
      uninstall: 'unknown',
      rollback: 'unknown',
    }
  }
  return {
    dsh: candidate.compatibility?.dsh ?? null,
    dshReleases,
    dshOperations,
    node: candidate.compatibility?.node ?? null,
    systems: sorted(candidate.compatibility?.systems),
    profiles: sorted(candidate.compatibility?.profiles),
  }
}

export function catalogUpdatePolicy(entry) {
  if (entry.updatePolicy === 'external-only') return 'external-only'
  if (entry.updatePolicy === 'user-reviewed') return 'user-reviewed'
  if (entry.updatePolicy === 'source-verified') return 'source-verified'
  const permissions = entry.details?.permissions ?? {}
  const credentials = permissions.credentials ?? ['unknown']
  // A latest-three compatibility hold is a reversible policy state, not a
  // permanent loss of the entry's previous installability class. Authors may
  // add exact compatibility evidence without changing package.version, so the
  // next fixed Commit must still receive the same bounded review an approved
  // entry would receive.
  const installableScope = entry.status === 'approved'
    || (['blocked', 'unlisted'].includes(entry.status) && String(entry.statusReason ?? '').startsWith(COMPATIBILITY_HOLD_PREFIX))
  const lowRisk = installableScope
    && (entry.risk?.installScripts?.length ?? 0) === 0
    && ['none', 'read-only'].includes(permissions.files)
    && permissions.network === 'none'
    && permissions.commands === 'none'
    && credentials.length === 1
    && credentials[0] === 'none'
  return lowRisk ? 'source-verified' : installableScope ? 'user-reviewed' : 'external-only'
}

export function catalogChangeReviewContract(versionAssessment) {
  if (versionAssessment?.status === 'newer-version') {
    return { reviewable: true, expectedVersionComparison: 1, changeKind: 'version-update' }
  }
  if (versionAssessment?.status === 'source-changed-without-version-bump') {
    return { reviewable: true, expectedVersionComparison: 0, changeKind: 'same-version-source-update' }
  }
  return { reviewable: false, expectedVersionComparison: null, changeKind: null }
}

export function assessUpstreamVersion(entry, source) {
  const commit = String(source?.commit ?? '').toLowerCase()
  if (!COMMIT_SHA.test(commit)) {
    return { status: 'update-blocked', reason: 'GitHub did not return a full immutable Commit' }
  }
  if (commit === entry.commit) {
    return { status: 'current', commit, catalogVersion: entry.version, upstreamVersion: entry.version }
  }
  const manifest = source?.manifest
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) {
    return { status: 'update-blocked', commit, reason: 'the fixed-Commit manifest is not a JSON object' }
  }
  if (manifest.name !== entry.packageName) {
    return { status: 'update-blocked', commit, reason: 'the upstream package name no longer matches the Catalog identity' }
  }
  const upstreamVersion = typeof manifest.version === 'string' ? manifest.version : ''
  if (!SEMVER.test(upstreamVersion)) {
    return { status: 'update-blocked', commit, upstreamVersion, reason: 'the upstream manifest does not declare a valid semantic version' }
  }
  const comparison = compareVersions(upstreamVersion, entry.version)
  if (comparison === null) {
    return { status: 'update-blocked', commit, upstreamVersion, reason: 'the upstream manifest does not declare a valid semantic version' }
  }
  if (comparison === 0) {
    return { status: 'source-changed-without-version-bump', commit, catalogVersion: entry.version, upstreamVersion }
  }
  if (comparison < 0) {
    return { status: 'upstream-version-behind', commit, catalogVersion: entry.version, upstreamVersion }
  }
  return { status: 'newer-version', commit, catalogVersion: entry.version, upstreamVersion }
}

export function catalogUpdateIdentityMatches(entry, candidate) {
  return candidate?.packageName === entry.packageName
    && candidate?.repositoryUrl === entry.repositoryUrl
    && candidate?.manifestPath === entry.manifestPath
    && normalizedPath(candidate?.installPath) === normalizedPath(entry.installPath)
    && (JSON.stringify(sorted(candidate?.entryIds)) === JSON.stringify(sorted(entry.entryIds))
      || (entry.entryIds.every(id => candidate.entryIds.includes(id) || candidate.configOverrides?.includes(id))
        && candidate.entryIds.every(id => entry.entryIds.includes(id))))
}

export function buildCatalogVersionUpdate(
  entry,
  candidate,
  analysis,
  observedAt,
  policy = catalogUpdatePolicy(entry),
) {
  const sameVersion = compareVersions(candidate.version, entry.version) === 0
  const releaseDescription = sameVersion ? 'same-version fixed Commit' : 'newer fixed Commit'
  const reason = policy === 'source-verified'
    ? `The ${releaseDescription} passed the complete automatic low-risk source policy.`
    : policy === 'user-reviewed'
      ? `The ${releaseDescription} passed Catalog identity and source-contract review; installation still requires a separate local risk review.`
      : 'The external-only or non-installable listing metadata was refreshed from a fixed Commit; no installability was inferred.'
  return {
    ...entry,
    entryIds: [...candidate.entryIds],
    configOverrides: [...(candidate.configOverrides ?? [])],
    defaultBranch: candidate.defaultBranch,
    commit: candidate.commit,
    version: candidate.version,
    compatibility: sourceDeclaredCompatibility(entry, candidate),
    source: {
      updatedAt: analysis?.sourceUpdatedAt ?? observedAt,
      observedAt,
      provenance: 'github-commit',
    },
    assurance: {
      discovery: {
        status: 'verified',
        method: 'automated-fixed-source-update-v3',
        checkedAt: observedAt,
        evidenceUrl: `${entry.repositoryUrl}/commit/${candidate.commit}`,
        dshRelease: null,
        systems: [],
        profiles: [],
        summary: reason,
      },
      installability: unknownEvidence('The updated fixed Commit was not installed or built by Catalog automation.'),
      runtime: unknownEvidence('No DSH runtime acceptance was carried forward after the source changed.'),
      securityReview: unknownEvidence('Automated fixed-source review is not an independent security audit.'),
    },
    risk: {
      ...entry.risk,
      installScripts: sorted(candidate.risk?.installScripts),
    },
  }
}

export function isAutomaticPolicyBlocked(entry) {
  return entry.status === 'blocked'
    && entry.updatePolicy === 'external-only'
    && entry.risk?.review === 'automatic-policy-blocked-not-installable'
    && String(entry.statusReason ?? '').startsWith('Automatic policy blocked installation:')
}

export function refreshAutomaticPolicyReview(entry, reviewed) {
  if (entry.status !== 'approved' && !isAutomaticPolicyBlocked(entry) && !String(entry.statusReason ?? '').startsWith(COMPATIBILITY_HOLD_PREFIX)) return entry
  if (!reviewed || reviewed.commit !== entry.commit && !/^[0-9a-f]{40}$/.test(reviewed.commit ?? '')) throw new Error('reviewed fixed Commit is required')
  if (reviewed.assurance?.discovery?.method !== 'automated-fixed-source-policy-v1') throw new Error('complete automatic source review is required')
  return { ...reviewed, id: entry.id, name: entry.name, description: entry.description,
    categories: entry.categories, searchTerms: entry.searchTerms, featured: entry.featured, installCount: entry.installCount }
}

export function holdExternalOnlyAfterDisconnectedHistory(entry, previousCommit, candidateCommit, reasons = []) {
  if (entry?.updatePolicy !== 'external-only'
    || !COMMIT_SHA.test(String(previousCommit ?? ''))
    || !COMMIT_SHA.test(String(candidateCommit ?? ''))
    || !Array.isArray(reasons)) {
    throw new Error('disconnected history may only refresh a fixed external-only entry')
  }
  const details = reasons.map(value => String(value).replace(/\s+/gu, ' ').trim()).filter(Boolean)
  const statusReason = [
    `Automatic policy blocked installation: the current fixed source ${candidateCommit.slice(0, 12)} has no common ancestor with the prior Catalog pin ${previousCommit.slice(0, 12)}; independent source history remains external-only.`,
    ...details,
  ].join(' ').slice(0, 600)
  return {
    ...entry,
    status: 'blocked',
    statusReason,
    updatePolicy: 'external-only',
    risk: { ...entry.risk, review: 'disconnected-history-external-only' },
  }
}
