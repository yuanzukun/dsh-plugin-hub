import { createActivationService } from './activation.mjs'
import { createCatalogService, DEFAULT_CATALOG_URL } from './catalog.mjs'
import { createCandidateService, DEFAULT_CANDIDATES_URL } from './candidates.mjs'
import { createDshRunner } from './dsh.mjs'
import { resolveDshHome, validateProfileName } from './inventory.mjs'
import { createOperationService } from './operations.mjs'
import { registerManagerRoutes } from './panel.mjs'
import { createRuntimeStatus } from './runtime.mjs'
import { createRestartService } from './restart.mjs'
import { createGuardianService } from './guardian.mjs'
import { createTelemetryClient } from './telemetry.mjs'
import { createSourceUpdateService } from './source-update.mjs'
import { createDshVersionService } from './dsh-version.mjs'
import { isAbsolute, join } from 'node:path'

export const name = 'dsh-safe-plugin-manager'
export const inject = []

function normalizeConfig(config = {}) {
  return {
    defaultProfile: validateProfileName(config.defaultProfile ?? 'web'),
    dshHome: resolveDshHome(config.dshHome),
    catalogUrl: config.catalogUrl === null ? null : (config.catalogUrl ?? DEFAULT_CATALOG_URL),
    candidateUrl: config.candidateUrl === null ? null : (config.candidateUrl ?? DEFAULT_CANDIDATES_URL),
    mutationsEnabled: config.mutationsEnabled === true,
    telemetryEnabled: config.telemetryEnabled === true,
    telemetryUrl: typeof config.telemetryUrl === 'string' ? config.telemetryUrl : null,
    installCountsUrl: typeof config.installCountsUrl === 'string' ? config.installCountsUrl : null,
    dshCliPath: typeof config.dshCliPath === 'string' && config.dshCliPath.trim() !== ''
      ? config.dshCliPath
      : process.argv[1],
  }
}

export function resolveHostOptions(ctx, config = {}) {
  const options = normalizeConfig(config)
  if (ctx?.profileContext?.name !== 'desktop') return { ...options, desktopMode: false }
  const { home, installAnchor } = ctx.profileContext
  if (typeof home !== 'string' || !isAbsolute(home)
    || typeof installAnchor !== 'string' || !isAbsolute(installAnchor)) {
    throw Object.assign(new Error('Desktop Profile context is incomplete'), { code: 'DESKTOP_PROFILE_CONTEXT_INVALID' })
  }
  return {
    ...options, defaultProfile: 'desktop', dshHome: home, dshCliPath: null,
    dshManifestPath: installAnchor, mutationsEnabled: false, desktopMode: true,
  }
}

export function apply(ctx, config = {}) {
  const options = resolveHostOptions(ctx, config)
  const catalogService = createCatalogService({
    catalogUrl: options.catalogUrl,
    installCountsUrl: options.installCountsUrl,
    cachePath: join(options.dshHome, 'dsh-safe-plugin-manager', 'catalog-cache.json'),
  })
  const candidateService = createCandidateService({ candidateUrl: options.candidateUrl })
  const runner = options.desktopMode ? null : createDshRunner({ cliPath: options.dshCliPath, environment: { ...process.env, DSH_HOME: options.dshHome } })
  const launchSpec = runner?.restartSpec(options.defaultProfile)
  const launchProfileArgs = options.defaultProfile === 'web' ? ['web'] : ['--profile', options.defaultProfile]
  const runtimeStatus = createRuntimeStatus({
    profile: options.defaultProfile,
    desktopMode: options.desktopMode,
    restartCommand: launchSpec ? [launchSpec.nodePath, ...launchSpec.runtimeArgs, launchSpec.cliPath, ...launchProfileArgs] : [],
    restartWorkingDirectory: launchSpec?.cwd ?? null,
  })
  const guardianService = createGuardianService({
    dshHome: options.dshHome, restartSpec: profile => runner?.restartSpec(profile),
  })
  const restartService = createRestartService({ runtimeStatus, guardianService })
  const telemetryClient = createTelemetryClient({ endpoint: options.telemetryUrl, enabled: options.telemetryEnabled })
  const sourceUpdateService = createSourceUpdateService()
  const dshVersionService = createDshVersionService({ cliPath: options.dshCliPath, manifestPath: options.dshManifestPath })
  const operationService = createOperationService({
    dshHome: options.dshHome,
    defaultProfile: options.defaultProfile,
    catalogService,
    runner,
    mutationsEnabled: options.mutationsEnabled,
    telemetryClient,
    sourceUpdateService,
    dshVersionService,
    runtimeInstanceId: runtimeStatus.bootId,
  })
  const activationService = createActivationService({ dshHome: options.dshHome, profile: options.defaultProfile, bootId: runtimeStatus.bootId,
    readRows: () => {
      if (typeof ctx.loader?.entries !== 'function') return null
      const rows = []
      for (const entry of ctx.loader.entries()) {
        if (rows.length >= 4096) return null
        rows.push({ id: entry.id, state: entry.fiber?.state })
      }
      return rows
    },
  })
  ctx.inject(['webServer', 'connection'], (webCtx) => {
    const dispose = registerManagerRoutes(webCtx.webServer, {
      ...options, catalogService, candidateService, runner, operationService, sourceUpdateService, dshVersionService,
      runtimeStatus, restartService, guardianService, activationService, connection: webCtx.connection,
    })
    if (typeof dispose === 'function' && typeof webCtx.effect === 'function') {
      webCtx.effect(() => dispose, 'dsh-safe-plugin-manager: inventory route')
    }
    webCtx.logger?.info?.(`dsh-safe-plugin-manager ready (${options.mutationsEnabled ? 'guarded-write' : 'read-only'})`)
  })
}
