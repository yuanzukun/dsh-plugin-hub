#!/usr/bin/env bash
set -Eeuo pipefail

umask 022

readonly pages_base="${DSH_STORE_PAGES_BASE:-https://ai-scarlett.github.io/DSH-Store}"
readonly deploy_root="${DSH_STORE_ROOT:-/opt/dsh-store}"
readonly current_link="$deploy_root/current"
readonly article_source="$deploy_root/content/articles/source"
readonly lock_file="${DSH_STORE_LOCK_FILE:-/run/lock/dsh-store-refresh.lock}"
readonly store_domain="${DSH_STORE_DOMAIN:-dsh.store}"
readonly pages_subdir="${DSH_STORE_PAGES_SUBDIR:-}"
readonly pages_path_prefix="${pages_subdir:+$pages_subdir/}"
readonly health_scheme="${DSH_STORE_HEALTH_SCHEME:-https}"
readonly site_prefix="${DSH_STORE_SITE_PREFIX:-}"
readonly download_jobs="${DSH_STORE_DOWNLOAD_JOBS:-12}"

case "$store_domain" in
  dsh.store|dsh-store.cn) ;;
  *) printf 'Unsupported DSH Store domain: %s\n' "$store_domain" >&2; exit 2 ;;
esac
case "$deploy_root" in
  /opt/dsh-store|/opt/dsh-store-cn) ;;
  *) printf 'Unsupported DSH Store root: %s\n' "$deploy_root" >&2; exit 2 ;;
esac
case "$pages_base" in
  https://ai-scarlett.github.io/DSH-Store) ;;
  *) printf 'Unsupported Pages authority: %s\n' "$pages_base" >&2; exit 2 ;;
esac
case "$store_domain:$pages_subdir" in
  dsh.store:|dsh-store.cn:domestic) ;;
  *) printf 'Unsupported Pages artifact path: %s %s\n' "$store_domain" "$pages_subdir" >&2; exit 2 ;;
esac
case "$store_domain:$health_scheme:$site_prefix" in
  dsh.store:http:/marketplace) readonly health_port=80 ;;
  dsh.store:https:) readonly health_port=443 ;;
  dsh-store.cn:https:) readonly health_port=443 ;;
  *) printf 'Unsupported DSH Store origin topology: %s %s %s\n' "$store_domain" "$health_scheme" "$site_prefix" >&2; exit 2 ;;
esac
case "$download_jobs" in
  ''|*[!0-9]*) printf 'Invalid DSH Store download concurrency: %s\n' "$download_jobs" >&2; exit 2 ;;
esac
if test "$download_jobs" -lt 1 || test "$download_jobs" -gt 16; then
  printf 'DSH Store download concurrency must be between 1 and 16: %s\n' "$download_jobs" >&2
  exit 2
fi
readonly health_resolve="$store_domain:$health_port:127.0.0.1"
readonly health_base="$health_scheme://$store_domain"

exec 9>"$lock_file"
if ! flock -n 9; then
  printf '%s\n' 'DSH_STORE_REFRESH_SKIPPED reason=already-running'
  exit 0
fi

install -d -o root -g root -m 0755 "$deploy_root/incoming" "$deploy_root/releases" "$deploy_root/backups"
incoming=$(mktemp -d "$deploy_root/incoming/pages-sync.XXXXXX")
candidate=''
backup=''
old_target=''
switched=0
published=0

cleanup_incoming() {
  case "$incoming" in
    "$deploy_root"/incoming/pages-sync.*) rm -rf -- "$incoming" ;;
    *) printf 'Refusing to remove unexpected incoming path: %s\n' "$incoming" >&2 ;;
  esac
}

origin_health() {
  curl -4 --http1.1 -fsS --resolve "$health_resolve" --connect-timeout 5 --max-time 30 \
    --retry 4 --retry-all-errors --retry-delay 1 "$@"
}

rollback_on_error() {
  rc=$?
  trap - ERR EXIT
  if test "$switched" -eq 1 && test -n "$old_target"; then
    ln -s "$old_target" "$current_link.rollback.$BASHPID"
    mv -Tf "$current_link.rollback.$BASHPID" "$current_link"
    rollback_health=0
    origin_health -o /dev/null "$health_base$site_prefix/" || rollback_health=1
    origin_health -o /dev/null "$health_base/registry/catalog.json" || rollback_health=1
    origin_health -o /dev/null "$health_base/registry/candidates.json" || rollback_health=1
    printf 'DSH_STORE_REFRESH_ROLLBACK restored=%s failed_candidate=%s\n' "$old_target" "$candidate" >&2
    test "$rollback_health" -eq 0 || printf 'DSH_STORE_REFRESH_ROLLBACK_HEALTH_FAILED domain=%s\n' "$store_domain" >&2
  fi
  if test "$published" -eq 0 && test -n "$candidate" && test -e "$candidate"; then
    case "$candidate" in
      "$deploy_root"/releases/*) rm -rf -- "$candidate" ;;
      *) printf 'Refusing to remove unexpected failed candidate: %s\n' "$candidate" >&2 ;;
    esac
  fi
  cleanup_incoming
  exit "$rc"
}
trap rollback_on_error ERR
trap cleanup_incoming EXIT

check_public() {
  local domestic_public_check=''
  if test "$store_domain" = dsh-store.cn; then
    domestic_public_check="usage-guide $site_prefix/dsh-store-guide/"
  fi
  while read -r label path; do
    test -n "$label" || continue
    code='000'
    for attempt in 1 2 3 4 5; do
      code=$(origin_health -o "$incoming/health-$label" -w '%{http_code}' "$health_base$path" || true)
      test "$code" = 200 && break
      sleep 1
    done
    test "$code" = 200
  done <<EOF
home $site_prefix/
plugins $site_prefix/plugins/
standards $site_prefix/standards/
build $site_prefix/build/
faq $site_prefix/faq/
about $site_prefix/about/
article $site_prefix/about/deepseek-harness-guide/
guide $site_prefix/dsh-plugins/
repair $site_prefix/repair/
repair-manifest $site_prefix/repair/repair-manifest.json
catalog /registry/catalog.json
candidates /registry/candidates.json
sitemap $site_prefix/sitemap.xml
robots $site_prefix/robots.txt
markdown $site_prefix/index.md
$domestic_public_check
EOF

  python3 - "$incoming/health-home" "$incoming/health-catalog" "$incoming/health-candidates" "$incoming/health-robots" "$incoming/health-markdown" "$incoming/health-repair-manifest" <<'PY'
import json,re,sys
home=open(sys.argv[1],encoding='utf-8').read()
catalog=json.load(open(sys.argv[2],encoding='utf-8'))
candidates=json.load(open(sys.argv[3],encoding='utf-8'))
robots=open(sys.argv[4],encoding='utf-8').read()
markdown=open(sys.argv[5],encoding='utf-8').read()
repair=json.load(open(sys.argv[6],encoding='utf-8'))
manager=next(item for item in catalog['entries'] if item.get('id') == 'dsh-safe-plugin-manager')
copy_disabled=bool(re.search(r'data-copy-target="install-command"[^>]*\bdisabled\b', home))
if manager['status'] == 'approved':
    if manager['commit'] not in home or copy_disabled:
        raise SystemExit('public homepage install identity mismatch')
else:
    if not copy_disabled or 'dsh plugin --profile web add' in home:
        raise SystemExit('public homepage exposes an unavailable manager install command')
    if repair.get('status') != 'catalog-pending' or repair.get('repairTool') is not None:
        raise SystemExit('public repair surface exposes an unavailable manager repair command')
boundary=candidates.get('registry', {}).get('trustBoundary', {})
if candidates.get('schemaVersion') != 1 or not isinstance(candidates.get('entries'), list) or not candidates['entries']:
    raise SystemExit('public Candidate Registry is invalid or empty')
if boundary != {'installActionsDisabled': True, 'catalogPromotionRequired': True, 'unknownIsNotVerified': True}:
    raise SystemExit('public Candidate Registry trust boundary is invalid')
for bot in (
    'GPTBot', 'ClaudeBot', 'PerplexityBot', 'Google-Extended',
    'Bytespider', 'KimiBot', 'Kimi-User', 'Kimi-SearchBot', 'DeepSeekBot',
    'YuanBaoBot', 'ChatGLM-Spider', 'MiniMaxBot', 'PetalBot', 'Baiduspider',
):
    if f'User-agent: {bot}\nAllow: /' not in robots:
        raise SystemExit(f'public robots policy is missing an explicit Allow rule for {bot}')
if len(markdown) <= 200 or '第三方插件商城' not in markdown:
    raise SystemExit('public homepage Markdown is missing or incomplete')
print('DSH_STORE_PUBLIC_OK', manager['version'], manager['commit'], manager['status'], manager['details']['license'], 'candidates', len(candidates['entries']))
PY

  if python3 - "$current_link/build-manifest.json" <<'PY'
import json,sys
build=json.load(open(sys.argv[1],encoding='utf-8'))
sys.exit(0 if isinstance(build.get('serverArticles',{}).get('builder'),dict) else 1)
PY
  then
    test -f "$current_link/server-state/articles-manifest.json"
    origin=$(python3 - "$current_link/build-manifest.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1],encoding='utf-8'))['siteOrigin'])
PY
)
    code='000'
    for attempt in 1 2 3 4 5; do
      code=$(origin_health -o "$incoming/health-articles-index" -w '%{http_code}' "$health_base$site_prefix/articles/" || true)
      test "$code" = 200 && break
      sleep 1
    done
    test "$code" = 200
    code='000'
    for attempt in 1 2 3 4 5; do
      code=$(origin_health -o "$incoming/health-articles-sitemap" -w '%{http_code}' "$health_base$site_prefix/articles/sitemap.xml" || true)
      test "$code" = 200 && break
      sleep 1
    done
    test "$code" = 200
    mapfile -t article_slugs < <(python3 - "$current_link/server-state/articles-manifest.json" <<'PY'
import json,re,sys
state=json.load(open(sys.argv[1],encoding='utf-8'))
slugs=state.get('articleSlugs')
if state.get('schemaVersion')!=1 or state.get('articleCount')!=len(slugs or []) or not isinstance(slugs,list) or not slugs:
    raise SystemExit('server article state is invalid')
for slug in slugs:
    if not isinstance(slug,str) or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',slug):
        raise SystemExit('server article state contains an unsafe slug')
    print(slug)
PY
)
    for slug in "${article_slugs[@]}"; do
      code='000'
      for attempt in 1 2 3 4 5; do
        code=$(origin_health -o "$incoming/health-article-$slug" -w '%{http_code}' "$health_base$site_prefix/articles/$slug/" || true)
        test "$code" = 200 && break
        sleep 1
      done
      test "$code" = 200
    done
    python3 - "$current_link" "$article_source" "$incoming/health-articles-index" "$incoming/health-articles-sitemap" "$incoming/health-sitemap" "$incoming/health-robots" "$origin" "${article_slugs[@]}" <<'PY'
import hashlib,json,pathlib,re,sys
release,source=pathlib.Path(sys.argv[1]),pathlib.Path(sys.argv[2])
index=pathlib.Path(sys.argv[3]).read_text(encoding='utf-8')
article_sitemap=pathlib.Path(sys.argv[4]).read_text(encoding='utf-8')
root_sitemap=pathlib.Path(sys.argv[5]).read_text(encoding='utf-8')
robots=pathlib.Path(sys.argv[6]).read_text(encoding='utf-8')
origin=sys.argv[7]; slugs=sys.argv[8:]
state=json.loads((release/'server-state/articles-manifest.json').read_text(encoding='utf-8'))
build=json.loads((release/'build-manifest.json').read_text(encoding='utf-8'))
source_manifest=json.loads((source/'migration-manifest.json').read_text(encoding='utf-8'))
expected={'articles.json','articles.css','index.template.html','article.template.html'}
if state.get('migrationPlanId')!='dsh-articles-to-server-20261029' or set(slugs)!=set(state.get('articleSlugs',[])):
    raise SystemExit('server article manifest does not match generated slugs')
if source_manifest.get('schemaVersion')!=1 or source_manifest.get('planId')!='dsh-articles-to-server-20261029' or set(source_manifest.get('files',{}))!=expected:
    raise SystemExit('server article source manifest is invalid')
if source.is_symlink() or {p.name for p in source.iterdir()}!=expected|{'migration-manifest.json'}:
    raise SystemExit('server article source has an unexpected file set')
digest=hashlib.sha256()
for name in ('articles.json','articles.css','index.template.html','article.template.html'):
    path=source/name
    if path.is_symlink() or not path.is_file(): raise SystemExit('server article source is unsafe')
    data=path.read_bytes()
    if name!='articles.json' and hashlib.sha256(data).hexdigest()!=source_manifest['files'][name]:
        raise SystemExit('server article template asset changed')
    digest.update(name.encode()); digest.update(b'\0'); digest.update(data); digest.update(b'\0')
if digest.hexdigest()!=state.get('sourceSetSha256'):
    raise SystemExit('current release was not generated from the current server article source')
if len(slugs)!=state.get('articleCount') or len(re.findall(r'<loc>',article_sitemap))!=len(slugs)+1:
    raise SystemExit('article sitemap count does not match the server article source')
if origin+'/articles/sitemap.xml' not in robots or '/articles/' in root_sitemap:
    raise SystemExit('article sitemap discovery or root sitemap separation is invalid')
if not re.search(r'<b id="article-count">'+str(len(slugs))+r'</b>',index):
    raise SystemExit('public article index count does not match the server article source')
for relative,metadata in state.get('files',{}).items():
    if not isinstance(relative,str) or not relative.startswith('marketplace/articles/') or '..' in pathlib.PurePosixPath(relative).parts:
        raise SystemExit('generated server article manifest contains an unsafe path')
    raw=release/relative
    if any(part.is_symlink() for part in (raw,*raw.parents) if part!=release):
        raise SystemExit('generated server article path contains a symlink')
    path=raw.resolve()
    if release.resolve() not in path.parents or not path.is_file():
        raise SystemExit('generated server article file is missing or unsafe')
    data=path.read_bytes()
    if len(data)!=metadata.get('size') or hashlib.sha256(data).hexdigest()!=metadata.get('sha256'):
        raise SystemExit('generated server article file hash does not match its manifest')
for slug in slugs:
    page=(pathlib.Path(sys.argv[1])/'marketplace/articles'/slug/'index.html')
    if page.is_symlink() or not page.is_file(): raise SystemExit('generated article page is missing')
    expected_url=origin+'/articles/'+slug+'/'
    if expected_url not in page.read_text(encoding='utf-8'):
        raise SystemExit('generated article canonical URL does not match its route')
print('DSH_STORE_ARTICLES_OK',len(slugs),state['sourceSetSha256'])
PY
  fi
}

curl -4 --http1.1 -fsSL --connect-timeout 10 --max-time 60 --retry 4 --retry-all-errors --retry-delay 2 \
  "$pages_base/${pages_path_prefix}release-manifest.json" -o "$incoming/release-manifest.json"

python3 - "$incoming/release-manifest.json" "$store_domain" > "$incoming/files.list" <<'PY'
import json, pathlib, re, sys

manifest = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))
domain = sys.argv[2]
if manifest.get('schemaVersion') != 1:
    raise SystemExit('unsupported release manifest')
source = manifest.get('sourceCommit', '')
if not re.fullmatch(r'[0-9a-f]{40}', source):
    raise SystemExit('release manifest source commit is not pinned')
files = manifest.get('files')
if not isinstance(files, dict):
    raise SystemExit('release manifest files are missing')
required = {
    'build-manifest.json',
    'marketplace/index.html',
    'marketplace/plugins/index.html',
    'marketplace/standards/index.html',
    'marketplace/build/index.html',
    'marketplace/faq/index.html',
    'marketplace/repair/index.html',
    'marketplace/repair/repair-manifest.json',
    'marketplace/about/index.html',
    'marketplace/dsh-plugins/index.html',
    'marketplace/robots.txt',
    'marketplace/index.md',
    'marketplace/sitemap.xml',
    'registry/catalog.json',
    'registry/candidates.json',
}
required.add('marketplace/about/deepseek-harness-guide/index.html')
if domain == 'dsh-store.cn':
    required.add('marketplace/dsh-store-guide/index.html')
if not required.issubset(files):
    raise SystemExit('release manifest is incomplete')
for path, metadata in sorted(files.items()):
    if not re.fullmatch(r'[A-Za-z0-9._/-]+', path) or path.startswith('/') or '..' in path.split('/'):
        raise SystemExit(f'unsafe release path: {path}')
    if not isinstance(metadata, dict) or not re.fullmatch(r'[0-9a-f]{64}', str(metadata.get('sha256', ''))):
        raise SystemExit(f'invalid release hash: {path}')
    if not isinstance(metadata.get('size'), int) or metadata['size'] < 0:
        raise SystemExit(f'invalid release size: {path}')
    print(path)
PY

source_sha=$(python3 - "$incoming/release-manifest.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1], encoding='utf-8'))['sourceCommit'])
PY
)

same_static_release=0
if test -f "$current_link/release-manifest.json" && cmp -s "$incoming/release-manifest.json" "$current_link/release-manifest.json"; then
  same_static_release=1
  if python3 - "$current_link" "$article_source" <<'PY'
import hashlib,json,pathlib,re,sys
release,source=pathlib.Path(sys.argv[1]),pathlib.Path(sys.argv[2])
build=json.loads((release/'build-manifest.json').read_text(encoding='utf-8'))
builder=build.get('serverArticles',{}).get('builder')
if not isinstance(builder,dict): raise SystemExit(0)  # legacy Pages release
if builder.get('path')!='scripts/build-server-articles.py' or not re.fullmatch(r'[a-f0-9]{64}',str(builder.get('sha256',''))):
    raise SystemExit(1)
state_path=release/'server-state/articles-manifest.json'
if not state_path.is_file() or source.is_symlink() or not source.is_dir(): raise SystemExit(1)
state=json.loads(state_path.read_text(encoding='utf-8'))
source_manifest=json.loads((source/'migration-manifest.json').read_text(encoding='utf-8'))
names=('articles.json','articles.css','index.template.html','article.template.html')
if source_manifest.get('planId')!='dsh-articles-to-server-20261029' or set(source_manifest.get('files',{}))!=set(names): raise SystemExit(1)
digest=hashlib.sha256()
for name in names:
    path=source/name
    if path.is_symlink() or not path.is_file(): raise SystemExit(1)
    data=path.read_bytes()
    if name!='articles.json' and hashlib.sha256(data).hexdigest()!=source_manifest['files'][name]: raise SystemExit(1)
    digest.update(name.encode()); digest.update(b'\0'); digest.update(data); digest.update(b'\0')
if digest.hexdigest()!=state.get('sourceSetSha256'): raise SystemExit(1)
if source.is_symlink() or {p.name for p in source.iterdir()}!=set(names)|{'migration-manifest.json'}: raise SystemExit(1)
for relative,metadata in state.get('files',{}).items():
    if not isinstance(relative,str) or not relative.startswith('marketplace/articles/') or '..' in pathlib.PurePosixPath(relative).parts: raise SystemExit(1)
    raw=release/relative
    if any(part.is_symlink() for part in (raw,*raw.parents) if part!=release): raise SystemExit(1)
    path=raw.resolve()
    if release.resolve() not in path.parents or not path.is_file(): raise SystemExit(1)
    data=path.read_bytes()
    if len(data)!=metadata.get('size') or hashlib.sha256(data).hexdigest()!=metadata.get('sha256'): raise SystemExit(1)
PY
  then
    check_public
    printf 'DSH_STORE_REFRESH_SKIPPED reason=already-current source=%s\n' "$source_sha"
    exit 0
  fi
fi

release_id="$(date -u +%Y%m%dT%H%M%SZ)-pages-${source_sha:0:12}"
if test "$same_static_release" -eq 1; then
  article_source_hash=$(python3 - "$article_source" <<'PY'
import hashlib,pathlib,sys
root=pathlib.Path(sys.argv[1])
d=hashlib.sha256()
for name in ('articles.json','articles.css','index.template.html','article.template.html'):
    p=root/name
    if p.is_symlink() or not p.is_file(): raise SystemExit('server article source is missing or unsafe')
    data=p.read_bytes(); d.update(name.encode()); d.update(b'\0'); d.update(data); d.update(b'\0')
print(d.hexdigest()[:12])
PY
)
  release_id="$release_id-articles-$article_source_hash"
fi
candidate="$deploy_root/releases/$release_id"
backup="$deploy_root/backups/$release_id-before"
test ! -e "$candidate"
test ! -e "$backup"
old_target=$(readlink -f "$current_link")
case "$old_target" in
  "$deploy_root"/releases/*) ;;
  *) printf 'Unexpected current release target: %s\n' "$old_target" >&2; exit 1 ;;
esac
test -d "$old_target"
test -f "$old_target/release-manifest.json"
old_manifest_sha=$(sha256sum "$old_target/release-manifest.json" | awk '{print $1}')
install -d -o root -g root -m 0755 "$candidate"

python3 - "$old_target" "$candidate" "$incoming/release-manifest.json" "$incoming/files.list" <<'PY'
import hashlib, json, pathlib, shutil, sys

old_root = pathlib.Path(sys.argv[1]).resolve()
candidate = pathlib.Path(sys.argv[2]).resolve()
manifest = json.loads(pathlib.Path(sys.argv[3]).read_text(encoding='utf-8'))
remaining = pathlib.Path(sys.argv[4])

def safe_path(root, relative):
    path = (root / relative).resolve()
    if root not in path.parents:
        raise SystemExit(f'unsafe artifact path: {relative}')
    return path

download = []
reused = 0
for relative, metadata in sorted(manifest['files'].items()):
    source = safe_path(old_root, relative)
    if source.is_file() and not source.is_symlink():
        digest = hashlib.sha256()
        with source.open('rb') as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
        if source.stat().st_size == metadata['size'] and digest.hexdigest() == metadata['sha256']:
            destination = safe_path(candidate, relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            reused += 1
            continue
    download.append(relative)
remaining.write_text(''.join(f'{path}\n' for path in download), encoding='utf-8')
print(f'DSH_STORE_REFRESH_REUSED reused={reused} download={len(download)}')
PY

download_artifact() {
  local path="$1"
  install -d -o root -g root -m 0755 "$candidate/$(dirname "$path")"
  if curl -4 --http1.1 --compressed -fsSL --connect-timeout 10 --max-time 300 --retry 4 --retry-all-errors --retry-delay 2 \
    "$pages_base/${pages_path_prefix}$path" -o "$candidate/$path"; then
    return 0
  fi
  case "$path" in
    registry/catalog.json|registry/catalog-index.json)
      # These two source files are also available at the exact Commit. Keep the
      # Pages manifest as the authority and let the final hash gate reject any
      # raw response that differs from the signed public artifact.
      rm -f -- "$candidate/$path"
      curl -4 --http1.1 --compressed -fsSL --connect-timeout 10 --max-time 90 --retry 3 --retry-all-errors --retry-delay 2 \
        "https://raw.githubusercontent.com/AI-Scarlett/DSH-Store/$source_sha/$path" -o "$candidate/$path"
      printf 'DSH_STORE_REFRESH_RAW_FALLBACK path=%s source=%s\n' "$path" "$source_sha"
      ;;
    *)
      return 1
      ;;
  esac
}

export pages_base pages_path_prefix candidate source_sha
export -f download_artifact
xargs -r -P "$download_jobs" -n 1 bash -Eeuo pipefail -c 'download_artifact "$1"' _ < "$incoming/files.list"
install -o root -g root -m 0644 "$incoming/release-manifest.json" "$candidate/release-manifest.json"

python3 - "$candidate" <<'PY'
import hashlib, json, os, pathlib, re, sys

root = pathlib.Path(sys.argv[1]).resolve()
manifest = json.loads((root / 'release-manifest.json').read_text(encoding='utf-8'))
for path, metadata in manifest['files'].items():
    target = (root / path).resolve()
    if root not in target.parents or not target.is_file() or target.is_symlink():
        raise SystemExit(f'unsafe or missing artifact: {path}')
    data = target.read_bytes()
    if len(data) != metadata['size'] or hashlib.sha256(data).hexdigest() != metadata['sha256']:
        raise SystemExit(f'artifact mismatch: {path}')

catalog = json.loads((root / 'registry/catalog.json').read_text(encoding='utf-8'))
candidates = json.loads((root / 'registry/candidates.json').read_text(encoding='utf-8'))
build = json.loads((root / 'build-manifest.json').read_text(encoding='utf-8'))
manager = next(item for item in catalog['entries'] if item.get('id') == 'dsh-safe-plugin-manager')
actual = (manager['version'], manager['commit'], manager['status'], manager['details']['license'])
expected = (build['manager']['version'], build['manager']['commit'], build['manager']['status'], build['manager']['license'])
if actual != expected or build['sourceCommit'] != manifest['sourceCommit']:
    raise SystemExit('catalog and static build identities do not match')
boundary = candidates.get('registry', {}).get('trustBoundary', {})
if candidates.get('schemaVersion') != 1 or not isinstance(candidates.get('entries'), list) or not candidates['entries']:
    raise SystemExit('Candidate Registry artifact is invalid or empty')
if boundary != {'installActionsDisabled': True, 'catalogPromotionRequired': True, 'unknownIsNotVerified': True}:
    raise SystemExit('Candidate Registry artifact trust boundary is invalid')
home = (root / 'marketplace/index.html').read_text(encoding='utf-8')
plugins = (root / 'marketplace/plugins/index.html').read_text(encoding='utf-8')
styles = (root / 'marketplace/styles.css').read_text(encoding='utf-8')
robots = (root / 'marketplace/robots.txt').read_text(encoding='utf-8')
markdown = (root / 'marketplace/index.md').read_text(encoding='utf-8')
repair = json.loads((root / 'marketplace/repair/repair-manifest.json').read_text(encoding='utf-8'))
usage_guide = root / 'marketplace/dsh-store-guide/index.html'
copy_disabled = bool(re.search(r'data-copy-target="install-command"[^>]*\bdisabled\b', home))
if manager['status'] == 'approved':
    if manager['commit'] not in home or copy_disabled:
        raise SystemExit('static homepage install identity mismatch')
else:
    if not copy_disabled or 'dsh plugin --profile web add' in home:
        raise SystemExit('static homepage exposes an unavailable manager install command')
    if repair.get('status') != 'catalog-pending' or repair.get('repairTool') is not None:
        raise SystemExit('static repair surface exposes an unavailable manager repair command')
visible_count = sum(entry.get('status') != 'unlisted' for entry in catalog['entries'])
approved_featured = any(entry.get('status') == 'approved' and entry.get('featured') is True for entry in catalog['entries'])
if 'name="dsh-catalog-delivery" content="external-json"' not in home:
    raise SystemExit('static homepage Catalog authority marker is missing')
if visible_count and 'data-static-plugin-id=' not in plugins:
    raise SystemExit('static plugin directory is incomplete')
if approved_featured and 'data-static-featured-id=' not in home:
    raise SystemExit('static featured catalog is incomplete')
if not re.search(r'\.load-error\[hidden\]\s*\{\s*display:\s*none;', styles):
    raise SystemExit('catalog error visibility guard is missing')
for bot in ('GPTBot', 'ClaudeBot', 'PerplexityBot', 'Google-Extended'):
    if f'User-agent: {bot}\nAllow: /' not in robots:
        raise SystemExit(f'AI bot policy is missing an explicit Allow rule for {bot}')
if len(markdown) <= 200 or '第三方插件商城' not in markdown:
    raise SystemExit('homepage Markdown artifact is missing or incomplete')
if build.get('siteOrigin') == 'https://dsh-store.cn':
    if not usage_guide.is_file() or '商城、CLI、Profile、依赖与 Catalog' not in usage_guide.read_text(encoding='utf-8'):
        raise SystemExit('domestic use and troubleshooting guide is missing or incomplete')
elif usage_guide.exists():
    raise SystemExit('domestic-only use and troubleshooting guide leaked into the international artifact')
builder = build.get('serverArticles', {}).get('builder')
if builder is not None:
    if builder.get('path') != 'scripts/build-server-articles.py' or not re.fullmatch(r'[a-f0-9]{64}', str(builder.get('sha256', ''))):
        raise SystemExit('server article builder identity is invalid')
    if any(path.startswith('marketplace/articles/') for path in manifest['files']):
        raise SystemExit('GitHub Pages release contains server-managed article routes')
    if '/articles/' in (root / 'marketplace/sitemap.xml').read_text(encoding='utf-8'):
        raise SystemExit('GitHub Pages root sitemap contains server-managed article routes')
    if '/articles/sitemap.xml' in robots:
        raise SystemExit('GitHub Pages robots.txt contains a server-managed article sitemap')
    for page in (root / 'marketplace').rglob('*.html'):
        if '/articles/' in page.read_text(encoding='utf-8'):
            raise SystemExit('GitHub Pages HTML contains a server-managed article URL')
for path in root.rglob('*'):
    if path.is_symlink() or path.name == '.git' or path.name.startswith('.env') or path.name.startswith('._'):
        raise SystemExit(f'forbidden artifact entry: {path.relative_to(root)}')
print('DSH_STORE_CANDIDATE_OK', build['sourceCommit'], *actual)
PY

if python3 - "$candidate/build-manifest.json" <<'PY'
import json,sys
build=json.load(open(sys.argv[1],encoding='utf-8'))
sys.exit(0 if isinstance(build.get('serverArticles',{}).get('builder'),dict) else 1)
PY
then
  builder_path="$incoming/build-server-articles.py"
  builder_sha=$(python3 - "$candidate/build-manifest.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1],encoding='utf-8'))['serverArticles']['builder']['sha256'])
PY
)
  curl -4 --http1.1 --compressed -fsSL --connect-timeout 10 --max-time 90 --retry 3 --retry-all-errors --retry-delay 2 \
    "https://raw.githubusercontent.com/AI-Scarlett/DSH-Store/$source_sha/scripts/build-server-articles.py" -o "$builder_path"
  test "$(sha256sum "$builder_path" | awk '{print $1}')" = "$builder_sha"
  python3 "$builder_path" --source-dir "$article_source" --site-root "$candidate/marketplace" --build-manifest "$candidate/build-manifest.json"
fi

chown -R root:root "$candidate"
find "$candidate" -type d -exec chmod 0755 {} +
find "$candidate" -type f -exec chmod 0644 {} +

test "$(readlink -f "$current_link")" = "$old_target"
test "$(sha256sum "$old_target/release-manifest.json" | awk '{print $1}')" = "$old_manifest_sha"
install -d -o root -g root -m 0750 "$backup"
cp -a "$old_target"/. "$backup"/
if test -f /etc/nginx/sites-available/dsh-store-pending.conf; then
  cp -a /etc/nginx/sites-available/dsh-store-pending.conf "$backup/dsh-store-pending.conf.before"
fi
printf 'backup_utc=%s\nold_target=%s\nnew_source_commit=%s\n' \
  "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$old_target" "$source_sha" > "$backup/BACKUP.txt"
(
  cd "$backup"
  find . -type f ! -name MANIFEST.sha256 -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > MANIFEST.sha256
  sha256sum -c MANIFEST.sha256 >/dev/null
)

ln -s "$candidate" "$current_link.next.$BASHPID"
mv -Tf "$current_link.next.$BASHPID" "$current_link"
switched=1

check_public

published=1
switched=0
printf 'DSH_STORE_REFRESH_OK source=%s release=%s backup=%s\n' "$source_sha" "$candidate" "$backup"
