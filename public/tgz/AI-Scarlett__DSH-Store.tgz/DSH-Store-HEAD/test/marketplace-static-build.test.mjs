import assert from 'node:assert/strict'
import { createNativeMarketIndex } from '../src/native-market-index.mjs'
import { gunzipSync } from 'node:zlib'
import { execFile } from 'node:child_process'
import { cp, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'
import test from 'node:test'
import { catalogBridgeBuffer, compareVersions, loadCatalogFromFiles, splitCatalogDocument } from '../src/catalog.mjs'
import { createRankingSnapshot, isDshDiscoveryCandidate, MAX_RANKING_DESCRIPTION_CHARS } from '../marketplace/rankings/model.js'
import { COMPATIBILITY_HOLD_PREFIX } from '../src/catalog-compatibility-policy.mjs'

const execFileAsync = promisify(execFile)
const root = new URL('../', import.meta.url)
const rootPath = fileURLToPath(root)
const staticBuilderPath = fileURLToPath(new URL('scripts/build-marketplace-static.mjs', root))
const sha256 = value => createHash('sha256').update(value).digest('hex')
function assertCompactFooterNavigation(page, { alternateUrl, label, code }) {
  const primaryNav = page.match(/<nav class="site-nav"[\s\S]*?<\/nav>/)?.[0]
  const footerNav = page.match(/<nav class="footer-nav"[\s\S]*?<\/nav>/)?.[0]
  const footerBottom = page.match(/<div class="footer-bottom">([\s\S]*?)<\/div>/)?.[1]
  assert.ok(primaryNav, 'primary navigation exists')
  assert.ok(footerNav, 'footer navigation exists')
  assert.ok(footerBottom, 'footer bottom exists')
  assert.doesNotMatch(primaryNav, /data-i18n="nav\.(?:faq|about|submit)"/)
  assert.doesNotMatch(primaryNav, /class="site-switch-link"/)
  assert.match(footerNav, /href="[^"]*faq\/"/)
  assert.match(footerNav, /href="[^"]*about\/"/)
  assert.match(footerNav, /data-i18n="nav\.submit"/)
  assert.match(footerBottom, new RegExp(`class="site-switch-link"[^>]*href="${alternateUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"`))
  assert.match(footerBottom, new RegExp(`<span>${label}</span><small>${code}</small>`))
}

test('all page locale dictionaries translate the generated article navigation link', async () => {
  const localeScripts = [
    'marketplace/app.js',
    'marketplace/about/about.js',
    'marketplace/build/build.js',
    'marketplace/community/community.js',
    'marketplace/downloads/downloads.js',
    'marketplace/faq/faq.js',
    'marketplace/rankings/rankings.js',
    'marketplace/scans/scans.js',
    'marketplace/standards/standards.js',
  ]
  for (const path of localeScripts) {
    const source = await readFile(new URL(`../${path}`, import.meta.url), 'utf8')
    assert.match(source, /'nav\.articles':\s*'DSH 实战与观察'/, `${path} has the Chinese label`)
    assert.match(source, /'nav\.articles':\s*'DSH Field Notes'/, `${path} has the English label`)
  }
})

async function runtimeAssetDigest(directory, prefix = '') {
  const digest = createHash('sha256')
  async function visit(folder, currentPrefix) {
    for (const entry of (await readdir(folder, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
      const relativePath = currentPrefix ? `${currentPrefix}/${entry.name}` : entry.name
      const absolutePath = join(folder, entry.name)
      if (entry.isDirectory()) await visit(absolutePath, relativePath)
      else if (entry.isFile() && /\.(?:js|css)$/i.test(entry.name)) {
        digest.update(relativePath).update('\0').update(await readFile(absolutePath)).update('\0')
      }
    }
  }
  await visit(directory, prefix)
  return digest.digest('hex').slice(0, 12)
}

test('GitHub Pages schedules distinct daily and weekly ranking refreshes while reusing scores on routine builds', async () => {
  const workflow = await readFile(new URL('.github/workflows/pages.yml', root), 'utf8')
  assert.match(workflow, /cron: "25 \*\/3 \* \* \*"/)
  assert.match(workflow, /cron: "15 2 \* \* \*"/)
  assert.match(workflow, /cron: "30 2 \* \* 0"/)
  assert.match(workflow, /"schedule:15 2 \* \* \*"\) mode=daily/)
  assert.match(workflow, /"schedule:30 2 \* \* 0"\) mode=weekly/)
  assert.match(workflow, /--ranking-refresh-mode "\$\{\{ steps\.ranking_state\.outputs\.mode \}\}"/)
  assert.match(workflow, /--ranking-refresh-mode reuse[\s\S]*current-rankings\.json/)
  assert.match(workflow, /cancel-in-progress: false/)
  assert.match(workflow, /7 \* 24 \* 60 \* 60 \* 1000/)
  assert.match(workflow, /24 \* 60 \* 60 \* 1000/)
  assert.match(workflow, /No valid public ranking snapshot was available; refusing to reset chart history/)
})

test('manifest validation stays approved-only; ranking metadata is independent and read-only', async () => {
  const builder = await readFile(new URL('scripts/build-marketplace-static.mjs', root), 'utf8')
  assert.match(builder, /mapLimit\(snapshot\.entries\.filter\(entry => entry\.status === 'approved'\), 5/)
  assert.match(builder, /enrichRankingSnapshot\(rankings, \{ token \}\)/)
  assert.match(builder, /applyRankingRefreshState\(rankings, previousRankings, rankingRefreshMode\)/)
  assert.match(builder, /rankingRefreshMode = argValue\('--ranking-refresh-mode'\) \|\| 'reuse'/)
  assert.match(builder, /candidates: candidateRegistry/)
  assert.match(builder, /response\.status === 403 && response\.headers\.get\('x-ratelimit-remaining'\) === '0'/)
  assert.match(builder, /if \(!repositoryResult\.error\.rateLimited\) throw repositoryResult\.error/)
  assert.match(builder, /if \(manifest\.version !== entry\.version\)/)
  assert.match(builder, /githubEnriched: enrichGitHub && githubMetadataComplete/)
  assert.match(builder, /enriched=\$\{snapshot\.generated\.githubEnriched\}/)
  assert.match(builder, /evidenceStatus \|\| entry\.assurance\?\.installability\?\.status/)
  assert.match(builder, /pnpm --config\.ignore-scripts=true dlx/)
})

test('static marketplace derives manager identity and catalog cards without mutating the authority file', async () => {
  const output = await mkdtemp(new URL('.tmp-marketplace-static-', root))
  const catalogPath = new URL('registry/catalog.json', root)
  const catalogIndexPath = new URL('registry/catalog-index.json', root)
  const catalogBefore = await readFile(catalogPath)
  const catalogIndexBefore = await readFile(catalogIndexPath)
  const catalog = await loadCatalogFromFiles()
  const manager = catalog.entries.find(entry => entry.id === 'dsh-safe-plugin-manager')
  assert.ok(manager)

  try {
    const outputArgument = relative(rootPath, output)
    const { stdout } = await execFileAsync(process.execPath, [
      staticBuilderPath,
      '--out', outputArgument,
      '--source-sha', 'test-source-sha',
    ], { cwd: rootPath })
    assert.match(stdout, /STATIC_MARKETPLACE_OK/)

    const catalogAfter = await readFile(catalogPath)
    const catalogIndexAfter = await readFile(catalogIndexPath)
    assert.equal(sha256(catalogAfter), sha256(catalogBefore))
    assert.equal(sha256(catalogIndexAfter), sha256(catalogIndexBefore))

    const home = await readFile(join(output, 'marketplace/index.html'), 'utf8')
    const plugins = await readFile(join(output, 'marketplace/plugins/index.html'), 'utf8')
    const runtimeApp = await readFile(join(output, 'marketplace/app.js'), 'utf8')
    const trafficRuntime = await readFile(join(output, 'marketplace/traffic.js'), 'utf8')
    const trafficModel = await readFile(join(output, 'marketplace/traffic-model.js'), 'utf8')
    const runtimeVersion = await runtimeAssetDigest(join(rootPath, 'marketplace'))
    const standards = await readFile(join(output, 'marketplace/standards/index.html'), 'utf8')
    const article = await readFile(join(output, 'marketplace/about/deepseek-harness-guide/index.html'), 'utf8')
    const articles = await readFile(join(output, 'marketplace/articles/index.html'), 'utf8')
    const articleSource = JSON.parse(await readFile(new URL('marketplace/articles/articles.json', root), 'utf8'))
    const firstArticle = articleSource.articles[0]
    const articleDetail = await readFile(join(output, 'marketplace/articles', firstArticle.slug, 'index.html'), 'utf8')
    const about = await readFile(join(output, 'marketplace/about/index.html'), 'utf8')
    const guide = await readFile(join(output, 'marketplace/dsh-plugins/index.html'), 'utf8')
    const faq = await readFile(join(output, 'marketplace/faq/index.html'), 'utf8')
    const repair = await readFile(join(output, 'marketplace/repair/index.html'), 'utf8')
    const scans = await readFile(join(output, 'marketplace/scans/index.html'), 'utf8')
    const scansStyles = await readFile(join(output, 'marketplace/scans/scans.css'), 'utf8')
    const rankings = await readFile(join(output, 'marketplace/rankings/index.html'), 'utf8')
    const rankingBytes = await readFile(join(output, 'marketplace/rankings/data.json'))
    const rankingData = JSON.parse(rankingBytes)
    assert.equal(rankingData.schemaVersion, 4)
    assert.equal(rankingData.sourceCommit, 'test-source-sha')
    const candidates = JSON.parse(await readFile(new URL('registry/candidates.json', root), 'utf8'))
    const catalogRepos = new Set(catalog.entries.map(entry => entry.repositoryUrl.toLowerCase()))
    const communityRecommendations = JSON.parse(await readFile(new URL('registry/community-recommendations.json', root), 'utf8'))
    const policy = JSON.parse(await readFile(new URL('registry/automation-policy.json', root), 'utf8'))
    const expectedRankings = createRankingSnapshot(catalog, JSON.parse(catalogIndexBefore), { candidates, communityRecommendations, excludedRepositories: policy.search.excludedRepositories })
    assert.deepEqual(new Set(rankingData.entries.map(entry => entry.id)), new Set(expectedRankings.entries.map(entry => entry.id)))
    assert.equal(rankingData.entries.filter(entry => entry.listingStatus === 'listed').length, catalog.entries.filter(entry => entry.status === 'approved' && /^[a-f0-9]{40}$/.test(entry.commit || '')).length)
    assert.ok(rankingData.entries.some(entry => entry.listingStatus === 'not-listed'))
    assert.ok(rankingData.entries.filter(entry => entry.listingStatus === 'not-listed').every(entry => typeof entry.listingReason === 'string' && entry.listingReason.length > 0))
    assert.ok(rankingData.entries.some(entry => entry.source === 'candidate'))
    assert.ok(rankingData.entries.every(entry => entry.stars === null), 'offline builds must not fabricate counters')
    assert.ok(rankingData.entries.every(entry => entry.weeklyStars === null), 'offline builds must not fabricate weekly counters')
    assert.match(rankings, new RegExp(`name="dsh-rankings-sha256" content="${sha256(rankingBytes)}"`))
    assert.match(rankings, /role="tablist"/)
    assert.match(rankings, /data-ranking-tab="listed"/)
    assert.match(rankings, /data-ranking-tab="essential"/)
    assert.match(rankings, /aria-current="page" data-rankings-nav/)
    assert.match(rankings, /https:\/\/dsh\.store\/rankings\//)
    assert.ok(rankingData.entries.every(entry => Array.from(entry.description).length <= MAX_RANKING_DESCRIPTION_CHARS))
    assert.ok(rankingBytes.length < 1024 * 1024)
    for (const page of [home, plugins, standards, article, articles, articleDetail, about, guide, faq, repair, scans]) {
      assert.match(page, /data-rankings-nav>榜单/)
      assert.match(page, /data-i18n="nav\.articles"/)
      assert.match(page, new RegExp(`type="module" src="(?:\\.\\./)*traffic\\.js\\?v=${runtimeVersion}"`))
    }
    assert.match(home, new RegExp(`src="traffic\\.js\\?v=${runtimeVersion}"`))
    assert.match(about, new RegExp(`src="\\.\\./traffic\\.js\\?v=${runtimeVersion}"`))
    assert.match(articleDetail, new RegExp(`src="\\.\\./\\.\\./traffic\\.js\\?v=${runtimeVersion}"`))
    assert.match(about, /id="traffic-weekly"/)
    assert.match(about, /data-traffic-chart/)
    assert.match(trafficRuntime, /credentials: 'omit'/)
    assert.match(trafficRuntime, /_public\/dsh-store-traffic\.json/)
    assert.match(trafficModel, /value\.today\?\.pv/)
    assert.doesNotMatch(trafficRuntime, /(?:payload|value)\s*(?:\?\.)?\.\s*(?:visitors|campaigns|referrers|raw_clicks|countries)\b/)
    assert.match(home, new RegExp(`href="articles/" data-i18n="nav\\.articles"`))
    assert.match(articles, /<html lang="zh-CN" data-default-locale="zh" data-fixed-locale="zh-CN">/)
    assert.match(articles, /<link rel="canonical" href="https:\/\/dsh\.store\/articles\/">/)
    assert.match(articles, /"@type":"CollectionPage"/)
    assert.match(articles, new RegExp(`href="\\./${firstArticle.slug}/"`))
    assert.match(articles, new RegExp(firstArticle.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))
    assert.match(articleDetail, /"@type":"Article"/)
    assert.match(articleDetail, new RegExp(`<h1>${firstArticle.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}</h1>`))
    assert.match(articleDetail, /本文保留原文发布时的产品版本、统计数据与观察结论/)
    assert.match(articleDetail, /<link rel="canonical" href="https:\/\/dsh\.store\/articles\//)
    assert.match(articleDetail, /href="\.\.\/" data-i18n="nav\.articles" aria-current="page"/)
    assert.doesNotMatch(articleDetail, /\/Users\/zhouxiaoming\/Documents\/JadeName/)
    assert.match(articles, new RegExp(`articles\\/${firstArticle.slug}\\/`))
    assert.equal(Number(articles.match(/<b id="article-count">(\d+)<\/b>/)?.[1]), articleSource.articles.length)
    const articleSitemap = await readFile(join(output, 'marketplace/sitemap.xml'), 'utf8')
    for (const item of articleSource.articles) {
      const detail = await readFile(join(output, 'marketplace/articles', item.slug, 'index.html'), 'utf8')
      const schemaJson = detail.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)?.[1]
      assert.ok(schemaJson, `Article JSON-LD exists for ${item.slug}`)
      assert.equal(JSON.parse(schemaJson)['@type'], 'Article')
      assert.equal(JSON.parse(schemaJson).headline, item.title)
      assert.ok(detail.includes('<article class="article-prose">'))
      assert.ok(articleSitemap.includes(`https://dsh.store/articles/${item.slug}/`))
      assert.doesNotMatch(detail, /\/Users\/zhouxiaoming\/Documents\/JadeName/)
    }

    const downloads = await readFile(join(output, 'marketplace/downloads/index.html'), 'utf8')
    const downloadsStyles = await readFile(join(output, 'marketplace/downloads/downloads.css'), 'utf8')
    const downloadsScript = await readFile(join(output, 'marketplace/downloads/downloads.js'), 'utf8')
    const navigationScript = await readFile(join(output, 'marketplace/scan-history-nav.js'), 'utf8')
    const manualScan = JSON.parse(await readFile(join(output, 'marketplace/scans/data/manual-baseline-20260925.json'), 'utf8'))
    const repairManifest = JSON.parse(await readFile(join(output, 'marketplace/repair/repair-manifest.json'), 'utf8'))
    const robots = await readFile(join(output, 'marketplace/robots.txt'), 'utf8')
    const markdown = await readFile(join(output, 'marketplace/index.md'), 'utf8')
    const sitemap = await readFile(join(output, 'marketplace/sitemap.xml'), 'utf8')
    const styles = await readFile(join(output, 'marketplace/styles.css'), 'utf8')
    const storeLayoutStyles = await readFile(join(output, 'marketplace/store-layout.css'), 'utf8')
    const manifest = JSON.parse(await readFile(join(output, 'build-manifest.json'), 'utf8'))
    const release = JSON.parse(await readFile(join(output, 'release-manifest.json'), 'utf8'))
    const nativeBytes = await readFile(join(output, 'marketplace/plugin-market.json'))
    assert.deepEqual(JSON.parse(nativeBytes), createNativeMarketIndex(await loadCatalogFromFiles()))
    assert.equal(release.files['marketplace/plugin-market.json'].sha256, sha256(nativeBytes))
    assert.match(faq, /id="native-market"/)
    assert.match(faq, /https:\/\/dsh\.store\/plugin-market\.json/)

    const automationStatus = JSON.parse(await readFile(join(output, 'automation-status.json'), 'utf8'))

    await assert.rejects(
      readFile(join(output, 'marketplace/googled542dac4f5a6c169.html'), 'utf8'),
      error => error?.code === 'ENOENT',
    )

    assert.equal(manifest.manager.version, manager.version)
    assert.equal(manifest.manager.commit, manager.commit)
    assert.equal(manifest.manager.license, manager.details.license)
    assert.equal(manifest.manager.status, manager.status)
    assert.equal(manifest.sourceCommit, 'test-source-sha')
    assert.equal(manifest.alternateOrigin, 'https://dsh-store.cn')
    assert.equal(manifest.githubEnriched, false)
    assert.equal(release.sourceCommit, 'test-source-sha')
    assert.equal(release.files['marketplace/googled542dac4f5a6c169.html'], undefined)
    assert.ok(release.files['marketplace/index.html'])
    assert.ok(release.files['marketplace/index.md'])
    assert.ok(release.files['marketplace/robots.txt'])
    assert.ok(release.files['marketplace/plugins/index.html'])
    assert.ok(release.files['marketplace/standards/index.html'])
    assert.ok(release.files['marketplace/about/deepseek-harness-guide/index.html'])
    assert.ok(release.files['marketplace/repair/index.html'])
    assert.ok(release.files['marketplace/repair/repair-manifest.json'])
    assert.ok(release.files['marketplace/scans/index.html'])
    for (const file of ['index.html', 'model.js', 'rankings.js', 'rankings.css', 'data.json']) assert.ok(release.files[`marketplace/rankings/${file}`])
    assert.ok(release.files['marketplace/scans/scans.js'])
    assert.ok(release.files['marketplace/scans/scans.css'])
    assert.ok(release.files['marketplace/scans/data/manual-baseline-20260925.json'])
    assert.ok(release.files['marketplace/downloads/index.html'])
    assert.ok(release.files['marketplace/downloads/downloads.css'])
    assert.ok(release.files['marketplace/downloads/downloads.js'])
    assert.ok(release.files['marketplace/scan-history-nav.js'])
    assert.ok(release.files['registry/catalog.json'])
    assert.ok(release.files['registry/catalog-index.json'])
    assert.ok(release.files['registry/catalog/details/dsh-safe-plugin-manager.json'])
    assert.equal(release.files['marketplace/catalog.snapshot.json'], undefined)
    assert.equal(release.files['automation-status.json'], undefined, 'run-only status must not rotate production releases')
    assert.equal(automationStatus.overall.status, 'unknown')
    assert.deepEqual(automationStatus.recentScanRuns, [])
    assert.equal(automationStatus.catalog.entries, catalog.entries.length)
    assert.ok(home.includes(`"softwareVersion": "${manager.version}"`))
    if (manager.status === 'approved') assert.match(home, new RegExp(manager.commit))
    else {
      assert.doesNotMatch(home, /dsh plugin --profile web add/)
      assert.match(home, /data-copy-target="install-command" disabled aria-disabled="true"/)
    }
    assert.match(home, /name="dsh-catalog-delivery" content="external-json"/)
    assert.match(home, /data-automation-overall/)
    assertCompactFooterNavigation(home, { alternateUrl: 'https://dsh-store.cn/', label: '国内站', code: 'CN' })
    assert.match(home, /href="\.\/scans\/" data-scan-history-nav/)
    assert.match(home, /src="\.\/scan-history-nav\.js\?v=20261003-rankings-1"/)
    assert.match(home, new RegExp(`src="\\.\\/app\\.js\\?v=${runtimeVersion}"`))
    assert.match(navigationScript, /data-desktop-download-menu/)
    assert.match(navigationScript, /headerTools\.insertBefore\(wrapper, localeSwitch\)/)
    assert.match(navigationScript, /new URL\('\.\.\/downloads\/', scanLink\.href\)/)
    assert.equal((navigationScript.match(/^\s{2}appendMenuOption\(panel,/gm) ?? []).length, 3)
    assert.match(navigationScript, /trigger: '下载 DSH'/)
    assert.match(navigationScript, /trigger: 'Get DSH'/)
    assert.doesNotMatch(home, /href="\.\/downloads\/"/)
    assert.match(navigationScript, /desktopDownloads\.mac/)
    assert.match(navigationScript, /desktopDownloads\.windows/)
    assert.match(navigationScript, /#web-ui/)
    assert.match(plugins, /href="\.\.\/scans\/" data-scan-history-nav/)
    assert.match(home, /<html lang="en" data-default-locale="en">/)
    assert.doesNotMatch(home, /baidu-site-verification/)
    assert.doesNotMatch(home, /baidu_union_verify/)
    assert.doesNotMatch(home, /hm\.baidu\.com\/hm\.js/)
    assert.match(home, /c0cf0ce3-b77c-4570-9573-59c07a583950/)
    assert.match(home, /https:\/\/aiaiai\.help\/umami\/script\.js/)
    assert.doesNotMatch(home, /763ad43e-f5c9-4342-9a82-8366d1ea90df/)
    assert.match(home, /DSH STORE \| DeepSeek Harness Plugin Marketplace/)
    assert.match(home, /name="applicable-device" content="pc,mobile"/)
    assert.match(home, /href="\.\/dsh-plugins\/"[^>]*data-analytics-event="guide_open"/)
    assert.match(home, /href="https:\/\/tracefence\.com\/"[^>]*>TraceFence/)
    assert.match(home, /href="https:\/\/aiaiai\.help\/"[^>]*>aiaiai\.help/)
    assert.doesNotMatch(home, /href="https:\/\/dsh-store\.cn\/"[^>]*>DSH STORE · 国内站/)
    assert.doesNotMatch(home, /href="https:\/\/dsh\.store\/"[^>]*>DSH STORE · International/)
    assert.match(home, /hreflang="en"[^>]*https:\/\/dsh\.store\//)
    assert.match(home, /hreflang="zh-CN"[^>]*https:\/\/dsh-store\.cn\//)
    assert.doesNotMatch(home, /DSH_ALTERNATE_SITE/)
    assert.doesNotMatch(home, /id="catalog-snapshot"/)
    assert.equal((plugins.match(/data-static-plugin-id=/g) || []).length, 20)
    assert.match(plugins, /name="dsh-catalog-delivery" content="external-json"/)
    assert.match(plugins, /name="dsh-discovery-index-sha256" content="[a-f0-9]{64}"/)
    assert.match(plugins, /name="dsh-discovery-index-count" content="19345"/)
    assert.match(plugins, /data-discovery-index-url="\.\.\/\.\.\/registry\/discovery-index\.json"/)
    assert.match(plugins, new RegExp(`src="\\.\\.\\/app\\.js\\?v=${runtimeVersion}"`))
    assert.match(plugins, new RegExp(`href="\\.\\.\\/store-layout\\.css\\?v=${runtimeVersion}"`))
    assert.match(articleDetail, new RegExp(`href="\\.\\.\\/articles\\.css\\?v=${runtimeVersion}"`))
    assert.match(runtimeApp, new RegExp(`import\\('./lib/plugin-directory\\.js\\?v=${runtimeVersion}'\\)`))
    assert.match(runtimeApp, new RegExp(`import\\('./lib/dsh-release-policy\\.js\\?v=${runtimeVersion}'\\)`))
    const sourceNote = plugins.match(/<p id="directory-source-note"[^>]*>([\s\S]*?)<\/p>/)?.[1] || ''
    assert.match(sourceNote, /From public third-party records/)
    assert.doesNotMatch(sourceNote, /dsh\.so|dsh-store\.cn|href=|CC BY/i)
    assert.match(plugins, /<summary data-i18n="directory\.sourceDisclosureTitle">关于来源与许可<\/summary>/)
    assert.match(plugins, /https:\/\/www\.dsh\.so\/plugins-index\.json/)
    assert.match(plugins, /CC BY 4\.0/)
    assert.match(plugins, />GitHub ↗<\/a>/)
    assert.doesNotMatch(plugins, />GH ↗<\/a>/)
    assert.match(plugins, /class="directory-category-heading"/)
    assert.match(storeLayoutStyles, /\.plugins-page \.directory-category-heading\s*\{[^}]*grid-column:\s*1 \/ -1/s)
    assert.match(plugins, /按分类浏览/)
    assert.match(plugins, /再按收录状态筛选/)
    const knownCount = Number(plugins.match(/id="stat-total">([0-9,]+)</)?.[1]?.replaceAll(',', ''))
    assert.ok(knownCount > 19_345, 'known directory count includes the complete source plus Store-only records')
    assert.match(plugins, /type="application\/json" href="https:\/\/dsh\.store\/registry\/catalog\.json"/)
    assert.match(plugins, /"@type": "SearchAction"/)
    assert.match(plugins, /"@type": "Dataset"/)
    assert.match(plugins, /"@type": "ItemList"/)
    const discoveryOutput = await readFile(join(output, 'registry/discovery-index.json'))
    const compressedDiscoveryOutput = await readFile(join(output, 'registry/discovery-index.json.gz'))
    assert.equal(JSON.parse(discoveryOutput).entries.length, 19_345)
    assert.deepEqual(gunzipSync(compressedDiscoveryOutput), discoveryOutput)
    const versionedOutput = await mkdtemp(new URL('.tmp-marketplace-versioned-assets-', root))
    try {
      const productionCommit = 'a'.repeat(40)
      await execFileAsync(process.execPath, [
        staticBuilderPath,
        '--out', relative(rootPath, versionedOutput),
        '--source-sha', productionCommit,
      ], { cwd: rootPath })
      const versionedHome = await readFile(join(versionedOutput, 'marketplace/index.html'), 'utf8')
      const versionedPlugins = await readFile(join(versionedOutput, 'marketplace/plugins/index.html'), 'utf8')
      const versionedApp = await readFile(join(versionedOutput, 'marketplace/app.js'), 'utf8')
      for (const page of [versionedHome, versionedPlugins]) {
        assert.match(page, new RegExp(`app\\.js\\?v=${productionCommit.slice(0, 12)}`))
      }
      assert.match(versionedApp, new RegExp(`plugin-directory\\.js\\?v=${productionCommit.slice(0, 12)}`))
      assert.match(versionedApp, new RegExp(`dsh-release-policy\\.js\\?v=${productionCommit.slice(0, 12)}`))
    } finally {
      await rm(versionedOutput, { recursive: true, force: true })
    }
    assert.match(plugins, /搜索中文名、用途、别名或英文包名/)
    assert.doesNotMatch(plugins, /id="catalog-snapshot"/)
    assert.ok(Buffer.byteLength(home) < 300_000, 'home HTML must not embed the complete catalog')
    assert.ok(Buffer.byteLength(plugins) < 500_000, 'directory HTML must contain only the first static page')
    assert.match(guide, /DSH 插件/)
    assert.match(guide, /DeepSeek Harness/)
    assert.match(guide, /build-dsh-plugin/)
    assert.match(guide, /hreflang="x-default"/)
    assert.doesNotMatch(faq, /查看使用与排查指南/)
    assert.match(standards, /Candidate Registry/)
    assert.match(standards, /installActionsDisabled = true/)
    assert.match(standards, /不会运行第三方 install、prepare、build、test 或运行时代码/)
    assert.match(standards, /href="\.\/" aria-current="page" data-i18n="nav\.standards"/)
    assert.match(standards, /hreflang="x-default"[^>]*https:\/\/dsh\.store\/standards\//)
    assert.match(article, /<html lang="zh-CN" data-default-locale="zh" data-fixed-locale="zh-CN">/)
    assert.match(article, /hreflang="en"[^>]*https:\/\/dsh\.store\/about\/deepseek-harness-guide\//)
    assert.match(article, /hreflang="x-default"[^>]*https:\/\/dsh\.store\/about\/deepseek-harness-guide\//)
    assert.match(article, /hreflang="zh-CN"[^>]*https:\/\/dsh-store\.cn\/about\/deepseek-harness-guide\//)
    assertCompactFooterNavigation(article, { alternateUrl: 'https://dsh-store.cn/', label: '国内站', code: 'CN' })
    assert.match(article, /作者：<a href="https:\/\/x\.com\/Russell3402"/)
    assert.match(article, /https:\/\/mp\.weixin\.qq\.com\/s\/oKppevLlwQOg8TfPG74rVw/)
    assert.match(about, /href="\.\/deepseek-harness-guide\/"/)
    assert.doesNotMatch(about, /DSH_ARTICLE_PROMO/)
    for (const bot of ['GPTBot', 'ClaudeBot', 'PerplexityBot', 'Google-Extended']) {
      assert.match(robots, new RegExp(`User-agent: ${bot}\\nAllow: /`))
    }
    for (const bot of [
      'Bytespider', 'KimiBot', 'Kimi-User', 'Kimi-SearchBot', 'DeepSeekBot',
      'YuanBaoBot', 'ChatGLM-Spider', 'MiniMaxBot', 'PetalBot', 'Baiduspider',
    ]) {
      assert.match(robots, new RegExp(`User-agent: ${bot}\\nAllow: /\\nDisallow: /_analytics/\\nDisallow: /_events/`))
    }
    assert.ok(markdown.length > 200, 'clean homepage Markdown must exceed 200 characters')
    assert.match(markdown, /第三方插件商城/)
    assert.match(markdown, /固定的完整 Git Commit/)
    assert.match(markdown, /收录或“可安装”状态不等于完整安全审计/)
    const llms = await readFile(join(output, 'marketplace/llms.txt'), 'utf8')
    assert.match(llms, /## Current catalog snapshot/)
    assert.match(llms, new RegExp(`- Listed plugins: ${catalog.entries.filter(entry => entry.status !== 'unlisted').length}`))
    assert.match(llms, /- Website build source commit: test-source-sha/)
    assert.doesNotMatch(llms, /Domestic product use and issue-boundary guide/)
    assert.match(sitemap, /https:\/\/dsh\.store\/dsh-plugins\//)
    assert.match(sitemap, /https:\/\/dsh\.store\/standards\//)
    assert.match(sitemap, /https:\/\/dsh\.store\/about\/deepseek-harness-guide\//)
    assert.match(sitemap, /https:\/\/dsh\.store\/repair\//)
    assert.match(sitemap, /https:\/\/dsh\.store\/scans\//)
    assert.match(sitemap, /https:\/\/dsh\.store\/rankings\//)
    assert.match(sitemap, /https:\/\/dsh\.store\/downloads\//)
    assert.match(sitemap, /https:\/\/dsh\.store\/articles\//)
    for (const item of articleSource.articles) assert.ok(sitemap.includes(`https://dsh.store/articles/${item.slug}/`))
    assert.doesNotMatch(sitemap, /dsh-store-guide/)
    assert.match(sitemap, /xmlns:mobile="http:\/\/www\.baidu\.com\/schemas\/sitemap-mobile\/1\//)
    assert.match(sitemap, /<mobile:mobile type="pc,mobile" \/>/)
    assert.match(sitemap, new RegExp(`<lastmod>${catalog.registry.updatedAt.slice(0, 10)}</lastmod>`))
    assert.match(styles, /\.load-error\[hidden\]\s*\{\s*display:\s*none;/)
    assert.match(styles, /\.site-nav a \{[\s\S]*font-size: 12px;/)
    assert.match(styles, /\.footer-bottom \{[\s\S]*font-size: 11px;/)
    assert.match(repair, /ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED/)
    assert.equal(manualScan.scanId, 'DSH-STORE-MANUAL-BASELINE-13739-20260925')
    assert.match(scans, /role="tablist"/)
    assert.match(scans, /aria-controls="panel-automatic"/)
    assert.match(scans, /data-automation-status-url="https:\/\/ai-scarlett\.github\.io\/DSH-Store\/automation-status\.json"/)
    assert.equal(manualScan.source.sourceCount, 13739)
    assert.equal(manualScan.source.processedCount, 13739)
    assert.deepEqual(manualScan.classificationCounts, {
      'store-auto-eligible': 3,
      'candidate-review-noninstallable': 13045,
      'rejected-hard-gate': 500,
      'unverified-deferred': 191,
    })
    assert.equal(manualScan.eligiblePackages.length, 3)
    assert.match(scansStyles, /\.scan-tabs button\[aria-selected="true"\]/)
    assert.match(downloads, /https:\/\/download\.deepseek\.com\/dsh-desk\/bin\/mac-arm64\/deepseek-harness-0\.1\.7-rc\.1\.20260924\.1-mac-arm64\.dmg/)
    assert.match(downloads, /https:\/\/download\.deepseek\.com\/dsh-desk\/bin\/win-x64\/deepseek-harness-0\.1\.7-rc\.1\.20260924\.1-win-x64\.exe/)
    assert.match(downloads, /0\.1\.7-rc\.1/)
    assert.match(downloads, /data-default-locale="en"/)
    assert.match(downloads, /https:\/\/deepseek\.com\/harness\//)
    assert.match(downloads, /developer preview|开发者预览版/i)
    assert.doesNotMatch(downloads, /data-desktop-download-nav/)
    assert.match(downloads, /id="web-ui" class="downloads-source"/)
    assert.match(downloads, /https:\/\/github\.com\/deepseek-ai\/deepseek-harness/)
    assert.match(downloads, /npx @deepseek-ai\/dsh web/)
    assert.match(downloads, /Node\.js/)
    assert.match(downloadsStyles, /\.downloads-grid\s*\{\s*display:\s*grid/)
    assert.match(downloadsStyles, /\.desktop-downloads-page \.system-status b \{ color: var\(--dsh-blue\) !important; background: transparent !important; \}/)
    assert.match(downloadsScript, /Apple Silicon ARM64 installer/)
    const repairActive = manager.status === 'approved' && compareVersions(manager.version, '0.8.10') >= 0
    if (repairActive) {
      assert.match(home, /legacy-repair-banner/)
      assert.match(repair, /data-repair-state="active"/)
      assert.match(repair, new RegExp(manager.commit))
      assert.equal(repairManifest.status, 'active')
      assert.equal(repairManifest.repairTool.packageSpecifier,
        `git+https://github.com/AI-Scarlett/DSH-Store.git#${manager.commit}`)
      assert.match(repairManifest.repairTool.command, /pnpm --config\.ignore-scripts=true dlx/)
      assert.match(repairManifest.repairTool.command, new RegExp(`--target-version ${manager.version}`))
      assert.match(repairManifest.repairTool.command, new RegExp(`--target-commit ${manager.commit}`))
    } else {
      assert.doesNotMatch(home, /legacy-repair-banner/)
      assert.match(repair, /data-repair-state="catalog-pending"/)
      assert.doesNotMatch(repair, /pnpm --config\.ignore-scripts=true dlx/)
      assert.equal(repairManifest.status, 'catalog-pending')
      assert.equal(repairManifest.repairTool, null)
    }
    assert.equal(repairManifest.target.version, manager.version)
    assert.equal(repairManifest.target.commit, manager.commit)
  } finally {
    await rm(output, { recursive: true, force: true })
  }
})

test('static build serializes only available automated scan evidence into the public run history', async () => {
  const output = await mkdtemp(new URL('.tmp-scan-history-build-', root))
  const fixture = await mkdtemp(join(tmpdir(), 'dsh-store-scan-history-fixture-'))
  const reportDir = join(fixture, '40')
  try {
    await mkdir(reportDir)
    await writeFile(join(fixture, 'automation-runs.json'), JSON.stringify({
      catalogAutomation: [
        { databaseId: 41, status: 'completed', conclusion: 'failure', event: 'schedule', createdAt: '2026-08-22T03:00:00Z', updatedAt: '2026-08-22T03:05:00Z', url: 'https://github.com/example/repo/actions/runs/41', headSha: 'b'.repeat(40) },
        { databaseId: 40, status: 'completed', conclusion: 'success', event: 'workflow_dispatch', createdAt: '2026-08-22T02:00:00Z', updatedAt: '2026-08-22T02:05:00Z', url: 'https://github.com/example/repo/actions/runs/40', headSha: 'c'.repeat(40) },
      ],
    }))
    await writeFile(join(reportDir, 'catalog-automation-report.json'), JSON.stringify({
      completed: true,
      observedAt: '2026-08-22T02:04:00Z',
      addedEntries: [],
      updatedEntries: [],
      compatibilityUnlisted: [],
      compatibilityRestored: [],
      prunedCandidates: [],
      rejectedCandidates: [],
      deferredUpdates: [],
      transientFailures: [],
      sourceVersionChecks: { checkedEntries: 25, sameVersionCatalogUpdates: 0 },
      // Real scanner reports now exceed 1 MB. Internal evidence stays out of
      // the public summary while its small, available statistics are retained.
      internalSourceEvidence: 'x'.repeat(1_100_000),
    }))

    const { stdout } = await execFileAsync(process.execPath, [
      staticBuilderPath,
      '--out', relative(rootPath, output),
      '--automation-runs', join(fixture, 'automation-runs.json'),
      '--automation-reports', fixture,
      '--source-sha', 'test-scan-history-sha',
    ], { cwd: rootPath })
    assert.match(stdout, /STATIC_MARKETPLACE_OK/)
    const status = JSON.parse(await readFile(join(output, 'automation-status.json'), 'utf8'))
    assert.equal(status.recentScanRuns.length, 2)
    assert.equal(status.recentScanRuns[0].runId, 41)
    assert.equal(status.recentScanRuns[0].event, 'schedule')
    assert.equal(status.recentScanRuns[0].reportAvailable, false)
    assert.equal(status.recentScanRuns[0].statisticsAvailable, false)
    assert.equal(status.recentScanRuns[0].added, null)
    assert.equal(status.recentScanRuns[1].runId, 40)
    assert.equal(status.recentScanRuns[1].event, 'workflow_dispatch')
    assert.equal(status.recentScanRuns[1].statisticsAvailable, true)
    assert.equal(status.recentScanRuns[1].added, 0)
    assert.equal(status.recentScanRuns[1].sourceVersionChecks.checkedEntries, 25)
    assert.ok((await readFile(join(output, 'automation-status.json'))).length < 64 * 1024)
    await writeFile(join(reportDir, 'catalog-automation-report.json'), ' '.repeat(4 * 1024 * 1024 + 1))
    await assert.rejects(execFileAsync(process.execPath, [
      staticBuilderPath, '--out', relative(rootPath, output), '--automation-reports', fixture,
    ], { cwd: rootPath }), /automation report exceeds the 4 MiB byte bound/)
  } finally {
    await rm(output, { recursive: true, force: true })
    await rm(fixture, { recursive: true, force: true })
  }
})

test('static marketplace publishes a compatibility-held manager without installation or repair commands', async () => {
  const fixture = await mkdtemp(join(tmpdir(), 'dsh-store-unlisted-manager-'))
  try {
    await mkdir(join(fixture, 'scripts/templates'), { recursive: true })
    await Promise.all([
      cp(join(rootPath, 'package.json'), join(fixture, 'package.json')),
      cp(join(rootPath, 'src'), join(fixture, 'src'), { recursive: true }),
      cp(join(rootPath, 'marketplace'), join(fixture, 'marketplace'), { recursive: true }),
      cp(join(rootPath, 'registry'), join(fixture, 'registry'), { recursive: true }),
      cp(staticBuilderPath, join(fixture, 'scripts/build-marketplace-static.mjs')),
      cp(join(rootPath, 'scripts/ranking-github-metadata.mjs'), join(fixture, 'scripts/ranking-github-metadata.mjs')),
      cp(join(rootPath, 'scripts/templates/dsh-article-page.html'), join(fixture, 'scripts/templates/dsh-article-page.html')),
    ])
    const catalog = await loadCatalogFromFiles()
    const manager = catalog.entries.find(entry => entry.id === 'dsh-safe-plugin-manager')
    assert.ok(manager)
    manager.status = 'unlisted'
    manager.statusReason = `${COMPATIBILITY_HOLD_PREFIX} test release window has no exact compatible result`
    const split = splitCatalogDocument(catalog)
    await Promise.all([
      writeFile(join(fixture, 'registry/catalog.json'), catalogBridgeBuffer(split.bridge)),
      writeFile(join(fixture, 'registry/catalog-index.json'), `${JSON.stringify(split.index, null, 2)}\n`),
      writeFile(join(fixture, 'registry/catalog/details/dsh-safe-plugin-manager.json'), `${JSON.stringify(manager, null, 2)}\n`),
    ])
    const { stdout } = await execFileAsync(process.execPath, [
      join(fixture, 'scripts/build-marketplace-static.mjs'), '--out', '_site', '--source-sha', 'held-manager-fixture',
    ], { cwd: fixture })
    assert.match(stdout, /STATIC_MARKETPLACE_OK/)
    const home = await readFile(join(fixture, '_site/marketplace/index.html'), 'utf8')
    const plugins = await readFile(join(fixture, '_site/marketplace/plugins/index.html'), 'utf8')
    const repair = await readFile(join(fixture, '_site/marketplace/repair/index.html'), 'utf8')
    const repairManifest = JSON.parse(await readFile(join(fixture, '_site/marketplace/repair/repair-manifest.json'), 'utf8'))
    assert.match(home, /Compatibility review pending; installation is unavailable/)
    assert.match(home, /data-copy-target="install-command" disabled aria-disabled="true"/)
    assert.doesNotMatch(home, /dsh plugin --profile web add/)
    assert.doesNotMatch(plugins, /data-static-plugin-id="dsh-safe-plugin-manager"/)
    assert.match(repair, /data-repair-state="catalog-pending"/)
    assert.equal(repairManifest.status, 'catalog-pending')
    assert.equal(repairManifest.repairTool, null)
  } finally {
    await rm(fixture, { recursive: true, force: true })
  }
})

test('static marketplace accepts a domestic origin and renders the ICP record', async () => {
  const output = await mkdtemp(new URL('.tmp-marketplace-domestic-', root))
  const icp = '鄂ICP备2026010180号-2'
  try {
    await execFileAsync(process.execPath, [
      staticBuilderPath,
      '--out', relative(rootPath, output),
      '--source-sha', 'domestic-test-sha',
      '--site-origin', 'https://dsh-store.cn',
      '--alternate-origin', 'https://dsh.store',
      '--icp', icp,
      '--baidu-verification', 'codeva-gZjUUScijx',
    ], { cwd: rootPath })

    const pagePaths = [
      'marketplace/index.html',
      'marketplace/plugins/index.html',
      'marketplace/community/index.html',
      'marketplace/standards/index.html',
      'marketplace/build/index.html',
      'marketplace/faq/index.html',
      'marketplace/about/index.html',
      'marketplace/repair/index.html',
      'marketplace/dsh-plugins/index.html',
      'marketplace/dsh-store-guide/index.html',
      'marketplace/about/deepseek-harness-guide/index.html',
    ]
    for (const pagePath of pagePaths) {
      const page = await readFile(join(output, pagePath), 'utf8')
      assert.match(page, /https:\/\/dsh-store\.cn/)
      assert.match(page, new RegExp(icp))
      assert.match(page, /<meta name="baidu-site-verification" content="codeva-gZjUUScijx">/)
      assert.equal((page.match(/https:\/\/hm\.baidu\.com\/hm\.js\?7c34f1fd076e8f052b6a6f746ab1135d/g) || []).length, 1)
      assert.equal((page.match(/763ad43e-f5c9-4342-9a82-8366d1ea90df/g) || []).length, 1)
      assert.match(page, /https:\/\/aiaiai\.help\/umami\/script\.js/)
      assert.doesNotMatch(page, /c0cf0ce3-b77c-4570-9573-59c07a583950/)
      assert.ok(page.indexOf('hm.baidu.com/hm.js?7c34f1fd076e8f052b6a6f746ab1135d') < page.indexOf('</head>'))
      assert.match(page, /<html lang="zh-CN" data-default-locale="zh"(?: data-fixed-locale="zh-CN")?>/)
      assertCompactFooterNavigation(page, { alternateUrl: 'https://dsh.store/', label: '国际站', code: 'INTL' })
      assert.match(page, /href="https:\/\/tracefence\.com\/"[^>]*>TraceFence/)
      assert.match(page, /href="https:\/\/aiaiai\.help\/"[^>]*>aiaiai\.help/)
      assert.doesNotMatch(page, /href="https:\/\/dsh\.store\/"[^>]*>DSH STORE · International/)
      assert.doesNotMatch(page, /href="https:\/\/dsh-store\.cn\/"[^>]*>DSH STORE · 国内站/)
      if (pagePath === 'marketplace/index.html') {
        assert.match(page, /<meta name="baidu_union_verify" content="f7a5e80f6ec4d01cdfd011c771e7e706">/)
      } else {
        assert.doesNotMatch(page, /baidu_union_verify/)
      }
    }
    const robots = await readFile(join(output, 'marketplace/robots.txt'), 'utf8')
    const markdown = await readFile(join(output, 'marketplace/index.md'), 'utf8')
    const domesticGuide = await readFile(join(output, 'marketplace/dsh-store-guide/index.html'), 'utf8')
    const sitemap = await readFile(join(output, 'marketplace/sitemap.xml'), 'utf8')
    const domesticFaq = await readFile(join(output, 'marketplace/faq/index.html'), 'utf8')
    const domesticLlms = await readFile(join(output, 'marketplace/llms.txt'), 'utf8')
    const manifest = JSON.parse(await readFile(join(output, 'build-manifest.json'), 'utf8'))
    const release = JSON.parse(await readFile(join(output, 'release-manifest.json'), 'utf8'))
    const nativeBytes = await readFile(join(output, 'marketplace/plugin-market.json'))
    assert.deepEqual(JSON.parse(nativeBytes), createNativeMarketIndex(await loadCatalogFromFiles()))
    assert.equal(release.files['marketplace/plugin-market.json'].sha256, sha256(nativeBytes))
    assert.match(domesticFaq, /id="native-market"/)
    assert.match(domesticFaq, /https:\/\/dsh-store\.cn\/plugin-market\.json/)

    const domesticAbout = await readFile(join(output, 'marketplace/about/index.html'), 'utf8')
    const domesticArticle = await readFile(join(output, 'marketplace/about/deepseek-harness-guide/index.html'), 'utf8')
    const domesticPlugins = await readFile(join(output, 'marketplace/plugins/index.html'), 'utf8')
    const domesticArticles = await readFile(join(output, 'marketplace/articles/index.html'), 'utf8')
    const domesticFieldNote = await readFile(join(output, 'marketplace/articles/session-flow-agent-session-archive/index.html'), 'utf8')
    const googleSiteVerification = await readFile(join(output, 'marketplace/googled542dac4f5a6c169.html'), 'utf8')
    assert.equal(googleSiteVerification, 'google-site-verification: googled542dac4f5a6c169.html')
    assert.match(robots, /Sitemap: https:\/\/dsh-store\.cn\/sitemap\.xml/)
    for (const bot of ['GPTBot', 'ClaudeBot', 'PerplexityBot', 'Google-Extended']) {
      assert.match(robots, new RegExp(`User-agent: ${bot}\\nAllow: /`))
    }
    for (const bot of [
      'Bytespider', 'KimiBot', 'Kimi-User', 'Kimi-SearchBot', 'DeepSeekBot',
      'YuanBaoBot', 'ChatGLM-Spider', 'MiniMaxBot', 'PetalBot', 'Baiduspider',
    ]) {
      assert.match(robots, new RegExp(`User-agent: ${bot}\\nAllow: /\\nDisallow: /_analytics/\\nDisallow: /_events/`))
    }
    assert.ok(markdown.length > 200, 'domestic clean homepage Markdown must exceed 200 characters')
    assert.match(markdown, /第三方插件商城/)
    assert.match(sitemap, /https:\/\/dsh-store\.cn\//)
    assert.match(sitemap, /https:\/\/dsh-store\.cn\/dsh-plugins\//)
    assert.match(sitemap, /https:\/\/dsh-store\.cn\/standards\//)
    assert.match(sitemap, /https:\/\/dsh-store\.cn\/about\/deepseek-harness-guide\//)
    assert.match(sitemap, /https:\/\/dsh-store\.cn\/repair\//)
    assert.match(sitemap, /https:\/\/dsh-store\.cn\/dsh-store-guide\//)
    assert.doesNotMatch(sitemap, /https:\/\/dsh\.store/)
    assert.match(domesticAbout, /href="\.\/deepseek-harness-guide\/"/)
    assert.match(domesticAbout, /Russell3402/)
    assert.doesNotMatch(domesticAbout, /DSH_ARTICLE_PROMO/)
    assert.ok(release.files['marketplace/about/deepseek-harness-guide/index.html'])
    assert.ok(release.files['marketplace/dsh-store-guide/index.html'])
    assert.ok(release.files['marketplace/googled542dac4f5a6c169.html'])
    assert.match(domesticGuide, /商城、CLI、Profile、依赖与 Catalog/)
    assert.match(domesticGuide, /https:\/\/raw\.githubusercontent\.com\/AI-Scarlett\/DSH-Store\/main\/registry\/catalog\.json/)
    assert.match(domesticFaq, /href="\.\.\/dsh-store-guide\/"/)
    assert.match(domesticLlms, /Domestic product use and issue-boundary guide: https:\/\/dsh-store\.cn\/dsh-store-guide\//)
    const domesticSourceNote = domesticPlugins.match(/<p id="directory-source-note"[^>]*>([\s\S]*?)<\/p>/)?.[1] || ''
    assert.match(domesticSourceNote, /来自第三方公开记录/)
    assert.doesNotMatch(domesticSourceNote, /dsh\.so|dsh-store\.cn|href=|CC BY/i)
    assert.match(domesticPlugins, /https:\/\/www\.dsh\.so\/plugins-index\.json/)
    assert.match(domesticPlugins, />GitHub ↗<\/a>/)
    assert.match(domesticArticles, /"@type":"CollectionPage"/)
    assert.match(domesticFieldNote, /"@type":"Article"/)
    assert.match(domesticFieldNote, /<link rel="canonical" href="https:\/\/dsh-store\.cn\/articles\/session-flow-agent-session-archive\/">/)
    assert.match(sitemap, /https:\/\/dsh-store\.cn\/articles\/session-flow-agent-session-archive\//)
    assert.match(domesticArticle, /<html lang="zh-CN" data-default-locale="zh" data-fixed-locale="zh-CN">/)
    assert.match(domesticArticle, /<link rel="canonical" href="https:\/\/dsh-store\.cn\/about\/deepseek-harness-guide\/">/)
    assert.match(domesticArticle, /hreflang="en"[^>]*https:\/\/dsh\.store\/about\/deepseek-harness-guide\//)
    assert.match(domesticArticle, /hreflang="zh-CN"[^>]*https:\/\/dsh-store\.cn\/about\/deepseek-harness-guide\//)
    assert.match(domesticArticle, /hreflang="x-default"[^>]*https:\/\/dsh\.store\/about\/deepseek-harness-guide\//)
    assertCompactFooterNavigation(domesticArticle, { alternateUrl: 'https://dsh.store/', label: '国际站', code: 'INTL' })
    assert.match(domesticArticle, /https:\/\/mp\.weixin\.qq\.com\/s\/oKppevLlwQOg8TfPG74rVw/)
    assert.equal(manifest.siteOrigin, 'https://dsh-store.cn')
    assert.equal(manifest.alternateOrigin, 'https://dsh.store')
    assert.equal(manifest.icp, icp)
    assert.equal(manifest.baiduSiteVerification, 'configured')
    assert.equal(manifest.baiduUnionVerification, 'configured')
  } finally {
    await rm(output, { recursive: true, force: true })
  }
})
