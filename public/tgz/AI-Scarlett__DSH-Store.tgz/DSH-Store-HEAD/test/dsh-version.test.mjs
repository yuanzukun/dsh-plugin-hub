import assert from 'node:assert/strict'
import { mkdtemp, mkdir, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import { createDshVersionService } from '../src/dsh-version.mjs'
import { DSH_RELEASES_URL } from '../src/dsh-release-policy.mjs'

async function fixture(version = '0.1.0-rc.7') {
  const root = await mkdtemp(join(tmpdir(), 'dsh-version-'))
  const cliRoot = join(root, 'apps', 'cli')
  const cliPath = join(cliRoot, 'src', 'bin.ts')
  await mkdir(join(cliRoot, 'src'), { recursive: true })
  await writeFile(join(cliRoot, 'package.json'), JSON.stringify({ name: '@deepseek-ai/dsh', version }))
  await writeFile(cliPath, '')
  return { root, cliPath }
}

test('GitHub-only release is visible without offering an unpublished npm command', async () => {
  const { root, cliPath } = await fixture('0.1.2-rc.1')
  try {
    const service = createDshVersionService({ cliPath, fetch: async url => Response.json(url === DSH_RELEASES_URL ? [{
      tag_name: 'dsh-v0.1.3-alpha.1', draft: false, published_at: '2026-09-04T11:34:32Z',
      html_url: 'https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.1.3-alpha.1',
    }] : { name: '@deepseek-ai/dsh', 'dist-tags': { latest: '0.1.2-rc.1' }, versions: { '0.1.2-rc.1': {} } }) })
    const value = await service.inspect()
    assert.equal(value.latestVersion, '0.1.3-alpha.1')
    assert.equal(value.status, 'update-available')
    assert.equal(value.latestSource, 'github-official:release')
    assert.equal(value.npmAvailable, false)
    assert.deepEqual(value.upgrade.command, [])
    assert.equal(value.upgrade.commandText, '')
    assert.match(value.upgrade.reason, /npm 当前可用版本仍为 0.1.2-rc.1/)
  } finally { await rm(root, { recursive: true, force: true }) }
})

test('official Desktop reads its bundled DSH manifest and never offers an npm upgrade command', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-desktop-version-'))
  try {
    const manifestPath = join(root, 'package.json')
    await writeFile(manifestPath, JSON.stringify({ name: '@deepseek-ai/dsh', version: '0.2.0-rc.2' }))
    const service = createDshVersionService({
      manifestPath,
      fetch: async url => Response.json(url === DSH_RELEASES_URL ? [] : {
        name: '@deepseek-ai/dsh',
        'dist-tags': { latest: '0.2.0-rc.2', alpha: '0.2.1-alpha.1' },
        versions: { '0.2.0-rc.2': {}, '0.2.1-alpha.1': {} },
      }),
    })
    const value = await service.inspect()
    assert.equal(value.currentVersion, '0.2.0-rc.2')
    assert.equal(value.installationKind, 'official-desktop')
    assert.deepEqual(value.upgrade.command, [])
    assert.match(value.upgrade.reason, /应用内“检查更新”/)
  } finally { await rm(root, { recursive: true, force: true }) }
})

test('DSH version check follows the official next channel when the release suffix changes', async () => {
  const { root, cliPath } = await fixture()
  let requests = 0
  try {
    const service = createDshVersionService({
      cliPath, now: () => Date.parse('2026-08-18T09:00:00Z'),
      fetch: async (url, options) => {
        requests += 1
        if (url === DSH_RELEASES_URL) return new Response('[]')
        assert.equal(url, 'https://registry.npmjs.org/@deepseek-ai%2Fdsh')
        assert.equal(options.headers.accept, 'application/vnd.npm.install-v1+json')
        return new Response(JSON.stringify({
          name: '@deepseek-ai/dsh',
          'dist-tags': { latest: '0.1.1-rc.2', next: '0.1.2-rc.1', alpha: '0.1.2-alpha.5' },
          versions: { '0.1.1-rc.2': {}, '0.1.2-alpha.5': {}, '0.1.2-rc.1': {} },
        }))
      },
    })
    assert.equal(service.peek(), null)
    const value = await service.inspect()
    assert.equal(value.currentVersion, '0.1.0-rc.7')
    assert.equal(value.latestVersion, '0.1.2-rc.1')
    assert.equal(value.stableVersion, '0.1.1-rc.2')
    assert.equal(value.releaseChannel, 'preview')
    assert.equal(value.releaseTag, 'next')
    assert.equal(value.status, 'update-available')
    assert.equal(value.installationKind, 'source-checkout')
    assert.equal(value.upgrade.executable, false)
    assert.deepEqual(value.upgrade.command, ['npm', 'install', '--global', '@deepseek-ai/dsh@0.1.2-rc.1'])
    assert.match(value.upgrade.reason, /不会修改 DSH 源码/)
    assert.equal(value.latestSource, 'npm-official:next')
    assert.equal(value.registryUrl, 'https://registry.npmjs.org/@deepseek-ai%2Fdsh')
    assert.equal(value.cacheTtlMs, 10 * 60_000)
    assert.equal(service.peek().latestVersion, '0.1.2-rc.1')
    assert.equal(service.peek().cacheStatus, 'peek')
    assert.equal((await service.inspect()).cacheStatus, 'hit')
    assert.equal(requests, 2)
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})


test('DSH version check uses published versions when a release has an unfamiliar dist-tag', async () => {
  const { root, cliPath } = await fixture('0.1.1-rc.2')
  try {
    const service = createDshVersionService({
      cliPath,
      fetch: async url => url === DSH_RELEASES_URL ? new Response('[]') : new Response(JSON.stringify({
        name: '@deepseek-ai/dsh',
        'dist-tags': { latest: '0.1.1-rc.2', rolling: '0.1.2-rc.1' },
        versions: { '0.1.1-rc.2': {}, '0.1.2-rc.1': {} },
      })),
    })
    const value = await service.inspect()
    assert.equal(value.latestVersion, '0.1.2-rc.1')
    assert.equal(value.releaseTag, 'version')
    assert.deepEqual(value.upgrade.command, ['npm', 'install', '--global', '@deepseek-ai/dsh@0.1.2-rc.1'])
    assert.equal(value.status, 'update-available')
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('DSH version check fails closed on an untrusted registry identity', async () => {
  const { root, cliPath } = await fixture('0.1.0-rc.7')
  try {
    const service = createDshVersionService({
      cliPath, fetch: async url => url === DSH_RELEASES_URL ? new Response('[]') : new Response(JSON.stringify({ name: 'other-package', 'dist-tags': {}, versions: {} })),
    })
    await assert.rejects(service.inspect(), error => error.code === 'DSH_VERSION_REGISTRY_INVALID')
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('DSH version check resolves a global launcher symlink before locating the package', async () => {
  const { root, cliPath } = await fixture('0.1.1-rc.2')
  try {
    const launcherDir = join(root, 'bin')
    const launcherPath = join(launcherDir, 'dsh')
    await mkdir(launcherDir)
    await symlink(cliPath, launcherPath)
    const service = createDshVersionService({
      cliPath: launcherPath,
      fetch: async url => url === DSH_RELEASES_URL ? new Response('[]') : new Response(JSON.stringify({
        name: '@deepseek-ai/dsh',
        'dist-tags': { latest: '0.1.1-rc.2' },
        versions: { '0.1.1-rc.2': {} },
      })),
    })
    const value = await service.inspect()
    assert.equal(value.currentVersion, '0.1.1-rc.2')
    assert.equal(value.status, 'current')
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('current host version reads local metadata afresh without network access', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'dsh-host-local-'))
  const manifestPath = join(directory, 'package.json')
  try {
    await writeFile(manifestPath, JSON.stringify({ name: '@deepseek-ai/dsh', version: '0.2.0-rc.2' }))
    const service = createDshVersionService({ manifestPath, fetch: async () => { throw new Error('network must not run') } })
    assert.equal((await service.current()).currentVersion, '0.2.0-rc.2')
    await writeFile(manifestPath, JSON.stringify({ name: '@deepseek-ai/dsh', version: '0.2.1-alpha.1' }))
    assert.equal((await service.current()).currentVersion, '0.2.1-alpha.1')
  } finally { await rm(directory, { recursive: true, force: true }) }
})
