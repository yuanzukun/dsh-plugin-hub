import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import {
  SUBMISSION_REPORT_MARKER,
  checkRepository,
  inferredCompatibility,
  checkSubmission,
  parseIssueForm,
  parseRepositoryInput,
  renderSubmissionReport,
  runCli,
  scanSubmissionRepository,
} from '../scripts/check-plugin-submission.mjs'
import { SUBMISSION_SCAN_BOUNDS, scanSubmissionSources } from '../src/submission-security-scan.mjs'
import { githubUserIdFingerprint } from '../src/author-exclusions.mjs'

const SHA = 'a'.repeat(40)

function issueBody(overrides = {}) {
  const fields = {
    'GitHub repository': 'https://github.com/example/dsh-demo',
    'Plugin path (optional)': '_No response_',
    'Notes (optional)': '_No response_',
    ...overrides,
  }
  return Object.entries(fields).map(([label, value]) => `### ${label}\n\n${value}`).join('\n\n')
}

function manifest(overrides = {}) {
  return {
    name: 'dsh-demo', version: '1.2.0', description: 'A useful DSH fixture plugin.', license: 'MIT',
    engines: { node: '^22.19.0 || >=24.0.0' },
    dsh: { bundle: { patch: './cordis.patch.yml' }, client: { platform: 'web' } },
    scripts: {}, ...overrides,
  }
}

function catalog(entries = []) {
  return {
    schemaVersion: 1,
    registry: {
      name: 'Fixture registry', repositoryUrl: 'https://github.com/example/registry',
      homepageUrl: 'https://example.test', updatedAt: '2026-08-18T00:00:00Z',
      categories: { experimental: '实验', tools: '工具' },
      trustPolicy: { candidateInstallDisabled: true, unknownIsNotVerified: true, promotionIndependentOfVerification: true },
    },
    entries,
  }
}

function sourceFetch(options = {}) {
  const packages = options.packages ?? { 'package.json': manifest(options.manifest) }
  const patches = options.patches ?? Object.fromEntries(Object.keys(packages).map(path => {
    const directory = path === 'package.json' ? '' : `${path.slice(0, -'package.json'.length)}`
    return [`${directory}cordis.patch.yml`, options.patch ?? `- insert:\n    - id: demo\n      name: ${packages[path].name}\n`]
  }))
  const sources = options.sources ?? {}
  const blobPaths = [...new Set([...Object.keys(packages), ...Object.keys(patches), ...Object.keys(sources)])]
  return async url => {
    const parsed = new URL(url)
    if (parsed.hostname === 'api.github.com' && parsed.pathname === '/repos/example/dsh-demo') {
      return new Response(JSON.stringify({
        private: options.private === true, archived: options.archived === true, default_branch: 'main',
        owner: { id: options.ownerUserId ?? 1234 },
      }))
    }
    if (parsed.hostname === 'api.github.com' && parsed.pathname.endsWith('/commits/main')) {
      return new Response(JSON.stringify({ sha: SHA }))
    }
    if (parsed.hostname === 'api.github.com' && parsed.pathname.includes('/git/trees/')) {
      return new Response(JSON.stringify({
        truncated: options.truncated === true,
        tree: blobPaths.map(path => {
          const content = Object.hasOwn(packages, path) ? JSON.stringify(packages[path])
            : Object.hasOwn(patches, path) ? patches[path] : sources[path]
        const bytes = Buffer.byteLength(content)
          return {
            type: options.treeTypes?.[path] ?? 'blob',
            mode: options.treeModes?.[path] ?? '100644',
            path,
          size: options.treeSizes?.[path] ?? bytes,
          sha: createHash('sha1').update(`blob ${bytes}\0`).update(content).digest('hex'),
          }
        }),
      }))
    }
    if (parsed.hostname === 'raw.githubusercontent.com') {
      const prefix = `/example/dsh-demo/${SHA}/`
      const path = decodeURIComponent(parsed.pathname.slice(prefix.length))
      if (Object.hasOwn(packages, path)) return new Response(JSON.stringify(packages[path]))
      if (Object.hasOwn(patches, path)) return new Response(patches[path])
      if (Object.hasOwn(sources, path)) return new Response(sources[path])
      if (path === 'README.md' || path.endsWith('/README.md')) {
        return new Response('# DSH Demo\n\nA fixture README description for the marketplace.\n')
      }
      return new Response('missing', { status: 404 })
    }
    throw new Error(`unexpected URL ${url}`)
  }
}

test('simple submission reads a fixed root package without executing it', async () => {
  const result = await checkSubmission(issueBody(), {
    catalogDocument: catalog(), fetch: sourceFetch(), retryDelaysMs: [],
  })
  assert.equal(result.status, 'passed')
  assert.equal(result.candidate.installPath, null)
  assert.equal(result.candidate.packageName, 'dsh-demo')
  assert.equal(result.candidate.commit, SHA)
  assert.equal(result.candidate.details.permissions.level, 'unknown')
  assert.equal(result.candidate.compatibility.node, '^22.19.0 || >=24.0.0')
  assert.deepEqual(result.candidate.compatibility.profiles, ['web'])
  assert.deepEqual(result.candidate.compatibility.dshReleases, {})
  assert.equal(result.discovery.publisher, 'example')
  const report = renderSubmissionReport(result)
  assert.ok(report.startsWith(SUBMISSION_REPORT_MARKER))
  assert.match(report, /没有执行第三方代码/)
  assert.match(report, /不是安全审计、运行验证或自动上架/)
})

test('submission accepts a second component exported by the same fixed package', async () => {
  const patch = '- insert:\n    - id: dsh-demo\n      name: dsh-demo\n    - id: dsh-demo-gate\n      name: dsh-demo/gate\n'
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(),
    fetch: sourceFetch({
      manifest: manifest({ files: ['index.js', 'lib/'], exports: { '.': './index.js', './gate': './lib/gate.js' } }),
      patch,
      sources: { 'lib/gate.js': 'export const gate = true\n' },
    }),
    retryDelaysMs: [],
  })
  assert.deepEqual(result.candidate.entryIds, ['dsh-demo', 'dsh-demo-gate'])
  assert.equal(result.candidate.packageName, 'dsh-demo')
  assert.equal(result.source.status, 'verified')
})

test('submission rejects a subpath without an exact safe manifest export', async () => {
  const patch = '- insert:\n    - id: dsh-demo\n      name: dsh-demo\n    - id: dsh-demo-gate\n      name: dsh-demo/gate\n'
  await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(),
    fetch: sourceFetch({ manifest: manifest({ exports: { '.': './index.js' } }), patch }),
    retryDelaysMs: [],
  }), { code: 'SOURCE_PATCH_REJECTED' })
})

test('submission rejects a package subpath unless its package root is in the same Patch', async () => {
  const patch = '- insert:\n    - id: dsh-demo-gate\n      name: dsh-demo/gate\n'
  await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(),
    fetch: sourceFetch({
      manifest: manifest({ files: ['index.js', 'lib/'], exports: { '.': './index.js', './gate': './lib/gate.js' } }),
      patch,
      sources: { 'lib/gate.js': 'export const gate = true\n' },
    }),
    retryDelaysMs: [],
  }), /package-root entry in the same Patch/)
})

test('bounded source scanning preserves a UTF-8 BOM for exact tree size and Git blob checks', async () => {
  const fetch = sourceFetch({ sources: {
    'index.js': '\uFEFFexport const ready = true\n',
    LICENSE: 'MIT License\n',
  } })
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(), fetch, retryDelaysMs: [],
  })
  const scan = await scanSubmissionRepository(result, { fetch, retryDelaysMs: [] })
  assert.equal(scan.complete, true)
  const index = scan.sourceEvidence.find(file => file.file === 'index.js')
  assert.ok(index)
  assert.equal(index.bytes, Buffer.byteLength('\uFEFFexport const ready = true\n'))
  assert.match(index.sha256, /^[a-f0-9]{64}$/)
  assert.deepEqual(scan.licenseEvidence.map(file => file.file), ['LICENSE'])
  assert.match(scan.licenseEvidence[0].sha256, /^[a-f0-9]{64}$/)
})

test('submission precheck hydrates the v2 Catalog before validating a candidate entry', async () => {
  const v2Catalog = JSON.parse(await readFile(new URL('../registry/catalog.json', import.meta.url), 'utf8'))
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: v2Catalog, fetch: sourceFetch(), retryDelaysMs: [],
  })
  assert.equal(result.status, 'passed')
  assert.equal(result.candidate.id, 'dsh-demo')
})

test('repository automation reuses the same fixed-source gate without an Issue form', async () => {
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(), fetch: sourceFetch(), retryDelaysMs: [],
  })
  assert.equal(result.status, 'passed')
  assert.equal(result.candidate.commit, SHA)
  assert.equal(result.candidate.packageName, 'dsh-demo')
  assert.equal(result.candidate.details.permissions.level, 'unknown')
})

test('submission rejects permanently blocked immutable author identities and unknown owner IDs', async () => {
  const authorPolicy = { blockedAuthors: [{
    userIdSha256: githubUserIdFingerprint(1234), reason: 'fixture permanent exclusion',
    requestRefSha256: '1'.repeat(64), requestBodySha256: '2'.repeat(64), blockedAt: '2026-10-01T00:00:00Z',
  }] }
  await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(), fetch: sourceFetch(), authorPolicy, retryDelaysMs: [],
  }), { code: 'SUBMISSION_AUTHOR_PERMANENTLY_BLOCKED' })
  await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(), fetch: sourceFetch({ ownerUserId: 0 }), retryDelaysMs: [],
  }), { code: 'SUBMISSION_OWNER_ID_UNKNOWN' })
})

test('an explicit author review stays at its full Commit while default HEAD has moved', async () => {
  const original = sourceFetch()
  const seen = []
  const fetch = async (url, options) => {
    seen.push(String(url))
    if (String(url).endsWith('/commits/' + SHA)) return new Response(JSON.stringify({ sha: SHA }))
    if (String(url).endsWith('/commits/main')) throw new Error('the newer HEAD is outside the requested review')
    return original(url, options)
  }
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    fixedCommit: SHA, catalogDocument: catalog(), fetch, retryDelaysMs: [],
  })
  assert.equal(result.candidate.commit, SHA)
  assert.equal(result.discovery.reviewTarget, 'explicit-fixed-commit')
  assert.ok(seen.some(url => url.endsWith('/commits/' + SHA)))
  assert.ok(!seen.some(url => url.endsWith('/commits/main')))
  for (const fixedCommit of ['main', 'v1.0.0', SHA.slice(0, 7)]) {
    await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '', { fixedCommit, fetch }), { code: 'SUBMISSION_COMMIT_INVALID' })
  }
  await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '', {
    fixedCommit: SHA, catalogDocument: catalog(), fetch: async url => String(url).endsWith('/commits/' + SHA)
      ? new Response(JSON.stringify({ sha: 'b'.repeat(40) })) : original(url), retryDelaysMs: [],
  }), { code: 'SUBMISSION_COMMIT_INVALID' })
})

test('GitHub submission scan reads bounded files from the same fixed commit', async () => {
  const fetch = sourceFetch({ sources: { 'src/index.mjs': 'export function activate() { return true }\n' } })
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(), fetch, retryDelaysMs: [],
  })
  const scan = await scanSubmissionRepository(result, { fetch, retryDelaysMs: [] })
  assert.equal(scan.verdict, 'pass')
  assert.equal(scan.complete, true)
  assert.equal(scan.filesScanned, 3)
  assert.equal(scan.eligibleFiles, 3)
  assert.equal(scan.engine, 'bounded-source-v3')
})

test('security scan warns for common CLI process capability but blocks high-risk secrets', () => {
  const warning = scanSubmissionSources([{ path: 'src/cli.mjs', source: "import { execFileSync } from 'node:child_process'\n" }])
  assert.equal(warning.verdict, 'warn')
  assert.equal(warning.counts.warning, 1)

  const token = `ghp_${'a'.repeat(36)}`
  const blocked = scanSubmissionSources([{ path: 'src/index.mjs', source: `const token = '${token}'\n` }])
  assert.equal(blocked.verdict, 'fail')
  assert.equal(blocked.counts.critical, 1)
  assert.doesNotMatch(JSON.stringify(blocked), new RegExp(token))
  assert.match(renderSubmissionReport({
    status: 'failed', code: 'SUBMISSION_SECURITY_HIGH_RISK', message: 'high risk', securityScan: blocked,
  }), /critical\/secrets\/github-token/)
})

test('oversize scan sources are reported as incomplete instead of silently treated as clean', async () => {
  const path = 'src/generated.mjs'
  const fetch = sourceFetch({
    sources: { [path]: 'not fetched' },
    treeSizes: { [path]: SUBMISSION_SCAN_BOUNDS.maxFileBytes + 1 },
  })
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(), fetch, retryDelaysMs: [],
  })
  const scan = await scanSubmissionRepository(result, { fetch, retryDelaysMs: [] })
  assert.equal(scan.verdict, 'warn')
  assert.equal(scan.complete, false)
  assert.equal(scan.skippedOversize, 1)
  assert.equal(scan.filesScanned, 2)
  assert.match(renderSubmissionReport({ ...result, securityScan: scan }), /扫描面不完整/)
})

test('CLI converts a high-risk scan into a failed Issue gate and persists the scan summary', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'dsh-submission-cli-'))
  try {
    const eventPath = join(directory, 'event.json')
    const reportPath = join(directory, 'report.md')
    const resultPath = join(directory, 'result.json')
    await writeFile(eventPath, JSON.stringify({ issue: { body: issueBody(), user: { id: 42424242 } } }), 'utf8')
    const code = await runCli([
      '--event', eventPath, '--report', reportPath, '--result', resultPath,
    ], {
      catalogDocument: catalog(), fetch: sourceFetch(), retryDelaysMs: [],
      scanRepository: async () => scanSubmissionSources([{
        path: 'src/index.mjs', source: `const token = 'ghp_${'b'.repeat(36)}'`,
      }]),
    })
    assert.equal(code, 1)
    const persisted = JSON.parse(await readFile(resultPath, 'utf8'))
    assert.equal(persisted.status, 'failed')
    assert.equal(persisted.code, 'SUBMISSION_SECURITY_HIGH_RISK')
    assert.equal(persisted.securityScan.verdict, 'fail')
    assert.match(await readFile(reportPath, 'utf8'), /安全启发式扫描：\*\*阻断\*\*/)
  } finally {
    await rm(directory, { recursive: true, force: true })
  }
})

test('submission preserves explicit operation evidence and marks other declared releases unknown', async () => {
  const result = await checkRepository('https://github.com/example/dsh-demo', '', {
    catalogDocument: catalog(),
    fetch: sourceFetch({ manifest: {
      dsh: {
        bundle: { patch: './cordis.patch.yml' },
        compatibility: {
          dsh: '>=0.1.0-rc.8 <0.2.0',
          dshReleases: { '0.1.1-rc.2': 'compatible' },
          dshOperations: {
            '0.1.1-rc.2': { install: 'passed', start: 'passed', uninstall: 'passed', rollback: 'passed' },
          },
        },
      },
    } }),
    retryDelaysMs: [],
  })
  assert.deepEqual(result.candidate.compatibility.dshReleases, { '0.1.1-rc.2': 'compatible' })
  for (const release of Object.keys(result.candidate.compatibility.dshReleases)) {
    assert.deepEqual(result.candidate.compatibility.dshOperations[release], release === '0.1.1-rc.2'
      ? { install: 'passed', start: 'passed', uninstall: 'passed', rollback: 'passed' }
      : { install: 'unknown', start: 'unknown', uninstall: 'unknown', rollback: 'unknown' })
  }
})

test('repository tree link supplies a monorepo plugin path automatically', async () => {
  const packages = { 'plugins/demo/package.json': manifest() }
  const result = await checkSubmission(issueBody({
    'GitHub repository': 'https://github.com/example/dsh-demo/tree/main/plugins/demo',
  }), { catalogDocument: catalog(), fetch: sourceFetch({ packages }), retryDelaysMs: [] })
  assert.equal(result.candidate.installPath, 'plugins/demo')
  assert.equal(result.candidate.manifestPath, 'plugins/demo/package.json')
})

test('multiple DSH packages ask only for an optional plugin path and then resolve deterministically', async () => {
  const packages = {
    'plugins/one/package.json': manifest({ name: 'dsh-one' }),
    'plugins/two/package.json': manifest({ name: 'dsh-two' }),
  }
  const fetch = sourceFetch({ packages })
  await assert.rejects(
    () => checkSubmission(issueBody(), { catalogDocument: catalog(), fetch, retryDelaysMs: [] }),
    error => error.code === 'SUBMISSION_PACKAGE_AMBIGUOUS' && /plugins\/one/.test(error.message),
  )
  const selected = await checkSubmission(issueBody({ 'Plugin path (optional)': 'plugins/two' }), {
    catalogDocument: catalog(), fetch, retryDelaysMs: [],
  })
  assert.equal(selected.candidate.packageName, 'dsh-two')
})

test('an explicit root path selects the root package in a multi-plugin repository', async () => {
  const packages = {
    'package.json': manifest({ name: 'dsh-root' }),
    'plugins/nested/package.json': manifest({ name: 'dsh-nested' }),
  }
  const result = await checkRepository('https://github.com/example/dsh-demo', '.', {
    catalogDocument: catalog(), fetch: sourceFetch({ packages }), retryDelaysMs: [],
  })
  assert.equal(result.candidate.packageName, 'dsh-root')
  assert.equal(result.candidate.manifestPath, 'package.json')
  assert.equal(result.candidate.installPath, null)
})

test('submission input rejects non-GitHub and escaping paths', async () => {
  assert.equal(parseRepositoryInput('https://github.com/example/dsh-demo').repositoryUrl, 'https://github.com/example/dsh-demo')
  assert.throws(() => parseRepositoryInput('https://example.test/dsh-demo'), error => error.code === 'SUBMISSION_REPOSITORY_INVALID')
  await assert.rejects(
    () => checkSubmission(issueBody({ 'Plugin path (optional)': '../secret' }), {
      catalogDocument: catalog(), fetch: sourceFetch(), retryDelaysMs: [],
    }),
    error => error.code === 'SUBMISSION_PATH_INVALID',
  )
  assert.equal(parseIssueForm(issueBody()).get('GitHub repository'), 'https://github.com/example/dsh-demo')
})

test('submission rejects private, archived, protected, and malformed plugin sources', async () => {
  await assert.rejects(
    () => checkSubmission(issueBody(), { catalogDocument: catalog(), fetch: sourceFetch({ private: true }), retryDelaysMs: [] }),
    error => error.code === 'SUBMISSION_REPOSITORY_PRIVATE',
  )
  await assert.rejects(
    () => checkSubmission(issueBody(), { catalogDocument: catalog(), fetch: sourceFetch({ archived: true }), retryDelaysMs: [] }),
    error => error.code === 'SUBMISSION_REPOSITORY_ARCHIVED',
  )
  await assert.rejects(
    () => checkSubmission(issueBody(), {
      catalogDocument: catalog(), fetch: sourceFetch({ manifest: { name: '@deepseek-ai/fake' } }), retryDelaysMs: [],
    }),
    error => error.code === 'SUBMISSION_PACKAGE_PROTECTED',
  )
  await assert.rejects(
    () => checkSubmission(issueBody(), {
      catalogDocument: catalog(), fetch: sourceFetch({ patch: '- insert:\n    - id: dsh-safe-plugin-manager\n      name: fake\n' }), retryDelaysMs: [],
    }),
    error => error.code === 'SUBMISSION_ENTRY_PROTECTED',
  )
})

test('submission derives lifecycle scripts and rejects existing entry collisions', async () => {
  const first = await checkSubmission(issueBody(), {
    catalogDocument: catalog(), fetch: sourceFetch({ manifest: { scripts: { prepare: 'node build.mjs' } } }), retryDelaysMs: [],
  })
  assert.deepEqual(first.candidate.risk.installScripts, ['prepare'])
  await assert.rejects(
    () => checkSubmission(issueBody(), {
      catalogDocument: catalog([{ ...first.candidate, id: 'existing', packageName: 'dsh-existing', repositoryUrl: 'https://github.com/example/existing' }]),
      fetch: sourceFetch({ manifest: { name: 'dsh-other' } }), retryDelaysMs: [],
    }),
    error => error.code === 'SUBMISSION_ENTRY_COLLISION',
  )
})

test('submission report escapes untrusted failure text', () => {
  const report = renderSubmissionReport({ status: 'failed', code: 'SUBMISSION_TEST', message: 'path\\`break\nnext' })
  assert.match(report, /path\\\\\\`break next/)
  assert.doesNotMatch(report, /break\nnext/)
})

test('GitHub workflow gates a one-required-field form with an artifact and a shared person contact gate', async () => {
  const workflow = await readFile(new URL('../.github/workflows/plugin-submission.yml', import.meta.url), 'utf8')
  const form = await readFile(new URL('../.github/ISSUE_TEMPLATE/plugin-submission.yml', import.meta.url), 'utf8')
  assert.match(workflow, /types: \[opened, edited, reopened\]/)
  assert.match(workflow, /contents: write/)
  assert.match(workflow, /issues: write/)
  assert.match(workflow, /GITHUB_TOKEN: \$\{\{ github\.token \}\}/)
  assert.match(workflow, /continue-on-error: true/)
  assert.match(workflow, /Check fixed source and bounded security heuristics without executing third-party code/)
  assert.match(workflow, /send-submission-result/)
  assert.doesNotMatch(workflow, /updateComment|addLabels|removeLabel/)
  assert.match(workflow, /plugin-submission-result/)
  assert.match(workflow, /author-notifications-global-contact/)
  assert.doesNotMatch(workflow, /npm (?:install|ci)|pnpm|yarn/)
  assert.equal((form.match(/required: true/g) || []).length, 1)
  assert.match(form, /label: GitHub repository/)
  assert.match(form, /label: Plugin path \(optional\)/)
  assert.doesNotMatch(form, /label: (?:Manifest path|Package name|Permission level|Immutable commit)/)
  assert.match(form, /不会.*运行第三方/)
})

test('explicit Catalog review snapshot remains authoritative after excluding the entry being updated', async () => {
  const document = catalog()
  document.registry = { ...document.registry, indexPath: 'catalog-index.json', indexSha256: 'b'.repeat(64), indexBytes: 100, indexEntryCount: 627 }
  const result = await checkRepository('https://github.com/example/dsh-demo', '.', { catalogDocument: document, fetch: sourceFetch(), retryDelaysMs: [] })
  assert.equal(result.candidate.packageName, 'dsh-demo')
})

test('different scoped packages sharing a basename get distinct Catalog IDs without weakening Bundle collisions', async () => {
  const first = await checkRepository('https://github.com/example/dsh-demo', '.', { catalogDocument: catalog(), fetch: sourceFetch(), retryDelaysMs: [] })
  const existing = { ...first.candidate, repositoryUrl: 'https://github.com/another/dsh-demo' }
  const options = { manifest: { name: '@mymeter/dsh-demo' }, patch: '- insert:\n    - id: mymeter\n      name: "@mymeter/dsh-demo"\n' }
  const result = await checkRepository('https://github.com/example/dsh-demo', '.', { catalogDocument: catalog([existing]), fetch: sourceFetch(options), retryDelaysMs: [] })
  assert.equal(result.candidate.id, 'mymeter-dsh-demo')
  await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '.', { catalogDocument: catalog([existing]), fetch: sourceFetch({ ...options, patch: `- insert:\n    - id: ${existing.entryIds[0]}\n      name: "@mymeter/dsh-demo"\n` }), retryDelaysMs: [] }), error => error.code === 'SUBMISSION_ENTRY_COLLISION')
})


test('manual submission scan uses package files and scans published test/minified entrypoints', async () => {
  const fetch = sourceFetch({ manifest: { files: ['cordis.patch.yml', 'dist', 'tests'] },
    sources: { 'dist/app.min.js': "import { execSync } from 'node:child_process'", 'tests/runtime.js': 'export const a = 1', 'scripts/deploy.py': 'not shipped' } })
  const result = await checkRepository('https://github.com/example/dsh-demo', '', { catalogDocument: catalog(), fetch })
  const scan = await scanSubmissionRepository(result, { fetch })
  assert.equal(scan.scope.kind, 'explicit-files-conservative-superset')
  assert.equal(scan.filesScanned, 4)
  assert.equal(scan.counts.warning, 1)
  assert.equal(scan.complete, true)
  const testWarning = scanSubmissionSources([{ path: 'tests/runtime.js', source: "import cp from 'node:child_process'" }], { packaged: true })
  assert.equal(testWarning.counts.warning, 1)
})

test('CLI cannot call an incomplete scan a passed precheck', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'dsh-scan-incomplete-'))
  t.after(() => rm(directory, { recursive: true, force: true }))
  const event = join(directory, 'event.json'), report = join(directory, 'report.md'), result = join(directory, 'result.json')
  await writeFile(event, JSON.stringify({ issue: { body: issueBody(), user: { id: 42424242 } } }))
  const code = await runCli(['--event', event, '--report', report, '--result', result], {
    catalogDocument: catalog(), fetch: sourceFetch(),
    scanRepository: async () => scanSubmissionSources([], { eligibleFiles: 4, capped: true }),
  })
  assert.equal(code, 1)
  assert.equal(JSON.parse(await readFile(result, 'utf8')).code, 'SUBMISSION_SCAN_INCOMPLETE')
  assert.match(await readFile(report, 'utf8'), /扫描面不完整/)
})


test('Bundle implementations cannot silently resolve to an unreviewed package', async () => {
  await assert.rejects(checkRepository('https://github.com/example/dsh-demo', '.', {
    catalogDocument: catalog(), fetch: sourceFetch({ patch: '- insert:\n    - id: demo\n      name: unrelated-package\n' }), retryDelaysMs: [],
  }), { code: 'SUBMISSION_PATCH_IDENTITY' })
})


test('official engines.dsh wins over peers and legacy declarations without inventing runtime evidence', () => {
  const value = inferredCompatibility({
    engines: { dsh: '0.2.1-alpha.4' },
    peerDependencies: { '@deepseek-ai/dsh': '0.1.0' },
    dsh: { compatibility: { dsh: '0.1.0', dshReleases: { '0.2.1-alpha.4': 'compatible', '0.2.1-alpha.3': 'compatible' } } },
  })
  const narrow = inferredCompatibility({ engines: { dsh: '^0.0.2' }, dsh: { compatibility: { dshReleases: { '0.0.3': 'compatible' } } } })
  assert.equal(narrow.dshReleases['0.0.3'], 'incompatible')
  assert.equal(value.dsh, '0.2.1-alpha.4')
  assert.deepEqual(value.dshReleases, { '0.2.1-alpha.4': 'compatible', '0.2.1-alpha.3': 'incompatible' })
  assert.deepEqual(value.dshOperations, {})
  const peers = inferredCompatibility({ peerDependencies: { '@deepseek-ai/dsh': '0.2.1-alpha.4', '@deepseek-ai/dsh-client-runtime': '0.2.1-alpha.3' },
    dsh: { compatibility: { dshReleases: { '0.2.1-alpha.4': 'compatible' } } } })
  assert.equal(peers.dshReleases['0.2.1-alpha.4'], 'incompatible')
  assert.equal(inferredCompatibility({ peerDependencies: { '@deepseek-ai/dsh': '0.2.1-alpha.4' } }).dsh, '0.2.1-alpha.4')
  for (const engines of [null, [], 'any', { dsh: null }, { dsh: '' }, { dsh: 'workspace:*' }]) {
    assert.throws(() => inferredCompatibility({ engines }), /engines/)
  }
  assert.throws(() => inferredCompatibility({ peerDependencies: { '@deepseek-ai/dsh': null } }), /peerDependencies/)
  assert.equal(inferredCompatibility({ engines: { dsh: '0.2.1-alpha.4' }, peerDependencies: null }).dsh, '0.2.1-alpha.4')
})
