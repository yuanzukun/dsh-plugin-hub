import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import test from 'node:test'
import { promisify } from 'node:util'
import { isGeneratedSelfManagerRegistryData, isNoCommonAncestorError, permissionSignals, dshInterfaceSignals } from '../src/automation-source-policy.mjs'
import { resolveTargets } from '../scripts/resolve-author-notice-targets.mjs'
import { updatePolicyForAdmission } from '../src/catalog-update-review.mjs'

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8')
const execFileAsync = promisify(execFile)
const rootPath = fileURLToPath(new URL('..', import.meta.url))
const catalogAutomationPath = fileURLToPath(new URL('../scripts/automate-catalog.mjs', import.meta.url))

test('only approved admission states enable Catalog update lanes', () => {
  assert.equal(updatePolicyForAdmission('reviewed', { protectedDsh: false }), 'user-reviewed')
  assert.equal(updatePolicyForAdmission('reviewed', { protectedDsh: null }), 'external-only')
  assert.equal(updatePolicyForAdmission('reviewed', {}), 'external-only')
  assert.equal(updatePolicyForAdmission('rejected', { protectedDsh: false }), 'external-only')
  assert.equal(updatePolicyForAdmission('incomplete', { protectedDsh: null }), 'external-only')
  assert.equal(updatePolicyForAdmission('review-required', { protectedDsh: false }), 'external-only')
  assert.equal(updatePolicyForAdmission('source-verified', { protectedDsh: false }), 'source-verified')
  assert.equal(updatePolicyForAdmission('reviewed', { protectedDsh: true }), 'external-only')
})

test('permission scan ignores inert Catalog metadata and ordinary identifiers', () => {
  const source = `
    const metadata = {
      repository: 'https://github.com/AI-Scarlett/dsh-settings-hub',
      network: 'none',
      credentials: ['none'],
    }
    function renameCustomTab() {}
    if (/network|browser|web|proxy/i.test(item.id)) return 'globe'
  `
  assert.deepEqual(permissionSignals(source), {
    files: false,
    network: false,
    commands: false,
    credentials: false,
    protectedDsh: false,
  })
})

test('protected DSH detection distinguishes direct mutations from static audit regexes', () => {
  const auditPattern = String.raw`const loaderFiberMutations = linesMatching(records, /(?:ctx\.(?:loader|fiber)|\b(?:Loader|Fiber))\.(?:insert|remove|patch|enable|disable|write|mutate)\s*\(/`
  assert.equal(permissionSignals(auditPattern).protectedDsh, false)
  assert.equal(permissionSignals(`ctx.fiber.remove('official-plugin')`).protectedDsh, true)
  assert.equal(permissionSignals(`Fiber.disable('official-plugin')`).protectedDsh, true)
  assert.equal(permissionSignals(`window.__ModuleLoader__.unload('official-plugin')`).protectedDsh, true)
  assert.equal(permissionSignals(`@deepseek-ai/dsh-web-app disabled: true`, 'cordis.patch.yml').protectedDsh, true)
  assert.equal(permissionSignals(`tool.call.toolview`).protectedDsh, false)
})

test('permission scan still fails closed on executable capability signals', () => {
  assert.equal(permissionSignals(`import { readFile } from 'node:fs/promises'`).files, true)
  assert.equal(permissionSignals(`const transport = require('node:https')`).network, true)
  assert.equal(permissionSignals(`await fetch(endpoint)`).network, true)
  assert.equal(permissionSignals(`import { spawn } from 'node:child_process'`).commands, true)
  assert.equal(permissionSignals(`process.env.API_KEY`).credentials, true)
  assert.equal(permissionSignals(`credentials.get('provider')`).credentials, true)
})

test('a disconnected GitHub history is recognized only from the exact compare response and immutable pair', () => {
  const base = 'a'.repeat(40)
  const candidate = 'b'.repeat(40)
  const error = { status: 404, message: `No common ancestor between ${base} and ${candidate}.` }
  assert.equal(isNoCommonAncestorError(error, base, candidate), true)
  assert.equal(isNoCommonAncestorError({ ...error, message: 'Not Found' }, base, candidate), false)
  assert.equal(isNoCommonAncestorError({ ...error, status: 403 }, base, candidate), false)
  assert.equal(isNoCommonAncestorError(error, 'short', candidate), false)
})

test('permission scan does not classify ordinary member exec methods as command execution', () => {
  assert.equal(permissionSignals(`const match = /"([^"]*)"/.exec(text)`).commands, false)
  assert.equal(permissionSignals(`const nested = parser.exec(text)`).commands, false)
  assert.equal(permissionSignals(`exec(command)`).commands, true)
  assert.equal(permissionSignals(`execFile(command)`).commands, true)
})

test('JavaScript permission scan ignores help strings, comments, regex literals, and template prose', () => {
  const source = String.raw`
    const summary = "scanned 277 session log(s), 94 fork(s), 0 unreadable"
    const help = "DSH home to read (default: $DSH_HOME, else ~/.dsh/profiles)"
    // spawn(command) and $DSH_HOME/.dsh/profiles are examples, not runtime behavior
    const matcher = /fork\(s\)|spawn\(command\)|\.dsh\/profiles/
    const template = ` + '`CLI says fork(s); default $DSH_HOME/.dsh/profiles`' + String.raw`
  `
  assert.deepEqual(permissionSignals(source, 'bin/cli.mjs'), {
    files: false,
    network: false,
    commands: false,
    credentials: false,
    protectedDsh: false,
  })
})

test('JavaScript permission scan retains executable calls and template expressions', () => {
  assert.equal(permissionSignals('const result = `${spawn(command)}`', 'src/run.ts').commands, true)
  assert.equal(permissionSignals('const result = `${parser.exec(text)}`', 'src/run.ts').commands, false)
  assert.equal(permissionSignals('const home = process.env.DSH_HOME', 'src/run.js').files, true)
  assert.equal(permissionSignals('import { readFile } from "node:fs/promises"', 'src/run.mjs').files, true)
  assert.equal(permissionSignals('const text = "import { readFile } from \'node:fs\'"', 'src/run.mjs').files, false)
  assert.equal(permissionSignals('const text = "import { readFile } from \'node:fs\'"; // 🧪\nimport { readFile } from "node:fs"', 'src/run.mjs').files, true)
})

test('self-manager generated Catalog details do not consume the executable source bound', () => {
  const manager = { id: 'dsh-safe-plugin-manager', repositoryUrl: 'https://github.com/AI-Scarlett/DSH-Store' }
  for (const path of ['registry/catalog.json', 'registry/catalog-index.json', 'registry/candidates.json', 'registry/catalog/details/example.json', 'registry/discovery-index.json', 'registry/discovery-index.json.gz']) {
    assert.equal(isGeneratedSelfManagerRegistryData(manager, path), true)
  }
  assert.equal(isGeneratedSelfManagerRegistryData(manager, 'registry/catalog/details/example.js'), false)
  assert.equal(isGeneratedSelfManagerRegistryData(manager, 'registry/catalog/details/nested/example.json'), false)
  assert.equal(isGeneratedSelfManagerRegistryData(manager, 'registry/automation-policy.json'), false)
  assert.equal(isGeneratedSelfManagerRegistryData(manager, 'registry/discovery-index-old.json'), false)
  assert.equal(isGeneratedSelfManagerRegistryData(manager, 'registry/discovery-index.json.gz/extra'), false)
  assert.equal(isGeneratedSelfManagerRegistryData(manager, 'registry/Discovery-index.json'), false)
  assert.equal(isGeneratedSelfManagerRegistryData({ ...manager, id: 'another-plugin' }, 'registry/catalog.json'), false)
  assert.equal(isGeneratedSelfManagerRegistryData({ ...manager, repositoryUrl: 'https://github.com/example/fork' }, 'registry/catalog.json'), false)
})

test('author target resolution suppresses deterministically unavailable repositories', async () => {
  const missing = async () => { throw Object.assign(new Error('missing'), { status: 404 }) }
  assert.equal(await resolveTargets(missing, 'example-owner/missing-plugin'), null)
  const transient = async () => { throw Object.assign(new Error('temporary'), { status: 503 }) }
  await assert.rejects(resolveTargets(transient, 'example-owner/plugin'), /temporary/)
})

test('automatic policy runs every eight hours and fails closed on permission or supply-chain signals', async () => {
  const policy = JSON.parse(await read('registry/automation-policy.json'))
  assert.equal(policy.scheduleHours, 8)
  assert.equal(policy.scheduledScanScope, 'catalog-only')
  assert.equal(policy.search.enabled, false)
  assert.equal(policy.discoveryFeeds.enabled, false)
  assert.equal(policy.updates.checkAllCatalogEntries, true)
  assert.equal(policy.updates.versionAuthority, 'canonical-github-default-branch-manifest-at-fixed-commit')
  assert.equal(policy.updates.concurrency, 8)
  assert.equal(policy.updates.maxCommitSpan, 200)
  assert.deepEqual(policy.compatibility, {
    authority: 'official-github-releases-and-npm-published-versions',
    registryUrl: 'https://registry.npmjs.org/@deepseek-ai%2Fdsh',
    latestReleaseCount: 3,
    requiredCompatibleReleases: 1,
    unsupportedCatalogStatus: 'blocked',
    candidateStatus: 'reviewing',
    failClosedOnAuthorityError: true,
  })
  assert.deepEqual(policy.candidateRetention, {
    authority: 'candidate-fixed-commit-package-manifests',
    pruneRejectedWithoutLatestThreeCompatibility: true,
    exactReleaseEvidenceRequired: true,
    scanBuckets: 24,
    maxCandidatesPerRun: 96,
    maxTreeEntries: 1200,
    maxManifestCandidates: 48,
    maxManifestBytes: 262144,
    concurrency: 8,
  })
  assert.equal(policy.automaticApproval.allowLifecycleScripts, false)
  assert.equal(policy.automaticApproval.allowRuntimeDependencies, false)
  assert.equal(policy.automaticApproval.requireManifestRepositoryMatch, true)
  assert.equal(policy.automaticApproval.requireRepositoryLicenseMatch, true)
  assert.ok(Object.values(policy.automaticApproval.permissionSignals).every(value => value === false))
  assert.deepEqual(policy.authorFeedback, {
    source: 'verified-authors-on-managed-issue-comments',
    classification: 'dsh-store-problem',
    ownerNotification: {
      channel: 'github-issue-comment',
      mention: '@AI-Scarlett',
      markerPrefix: 'dsh-author-feedback:v1',
      oncePerFeedbackComment: true,
      githubNotificationEmailDeliveryVerified: false,
    },
    automaticAuthorReplies: false,
    requiresVerifiedAuthorIdentity: true,
  })
  assert.equal(policy.publication.repository, 'AI-Scarlett/DSH-Store')
  assert.deepEqual(policy.publication.publicCatalogUrls, [
    'https://raw.githubusercontent.com/AI-Scarlett/DSH-Store/main/registry/catalog.json',
    'https://ai-scarlett.github.io/DSH-Store/registry/catalog.json',
    'https://dsh.store/registry/catalog.json',
    'https://dsh-store.cn/registry/catalog.json',
  ])
  assert.deepEqual(policy.publication.publicRepairUrls, [
    'https://ai-scarlett.github.io/DSH-Store/marketplace/repair/',
    'https://dsh.store/repair/',
    'https://dsh-store.cn/repair/',
  ])
})

test('scheduled automation uses a policy PR and never executes third-party package code', async () => {
  const reviewSource = await read('src/fixed-source-review.mjs')
  const [workflow, source] = await Promise.all([
    read('.github/workflows/catalog-automation.yml'),
    read('scripts/automate-catalog.mjs'),
  ])
  assert.match(workflow, /cron: "5 \*\/8 \* \* \*"/)
  assert.match(workflow, /pull-requests: write/)
  assert.match(workflow, /ref: main/)
  assert.match(workflow, /Pin the fresh main authority for this run/)
  assert.match(workflow, /CATALOG_BASE_COMMIT: \$\{\{ steps\.base\.outputs\.sha \}\}/)
  assert.doesNotMatch(workflow, /-f sha="\$GITHUB_SHA"|--arg head "\$GITHUB_SHA"/)
  assert.match(workflow, /gh workflow run registry\.yml --ref "\$branch"/)
  assert.match(workflow, /gh run watch "\$validation_run_id" --exit-status/)
  assert.match(workflow, /codeql_passed/)
  assert.match(workflow, /gh pr merge --squash --delete-branch/)
  assert.match(workflow, /--json state --jq \.state/)
  assert.match(workflow, /--json mergeCommit --jq '\.mergeCommit\.oid'/)
  assert.match(workflow, /Publish the merged Catalog immediately/)
  assert.match(workflow, /EXPECTED_MAIN_SHA: \$\{\{ steps\.pull_request\.outputs\.merge_sha \}\}/)
  assert.match(workflow, /gh workflow run pages\.yml --ref main/)
  assert.match(workflow, /gh run watch "\$pages_run_id" --exit-status/)
  assert.match(workflow, /CATALOG_BRANCH="\$branch" node scripts\/create-catalog-commit\.mjs/)
  assert.match(workflow, /--match-head-commit "\$commit_oid"/)
  assert.match(workflow, /test "\$CATALOG_BASE_COMMIT" = "\$\(gh api "repos\/\$GITHUB_REPOSITORY\/commits\/main" --jq \.sha\)"/)
  assert.match(workflow, /commit\.verification\.verified/)
  assert.match(workflow, /uses: \.\/\.github\/workflows\/author-notifications\.yml/)
  assert.match(workflow, /uses: \.\/\.github\/workflows\/catalog-run-report\.yml/)
  assert.match(workflow, /catalog_run_id: \$\{\{ github\.run_id \}\}/)
  assert.match(workflow, /catalog_run_attempt: \$\{\{ github\.run_attempt \}\}/)
  assert.match(workflow, /inline_catalog_run: true/)
  assert.match(workflow, /owner-report:[\s\S]+needs: \[update, author-notifications\][\s\S]+if: always\(\)/)
  assert.doesNotMatch(workflow, /git commit|git push/)
  assert.doesNotMatch(workflow, /npm (?:install|ci)|pnpm|yarn/)
  assert.match(workflow, /manual_scan_plan_branch/)
  assert.match(workflow, /manual_scan_plan_commit/)
  assert.match(workflow, /verify-manual-scan-plan\.mjs/)
  assert.match(workflow, /plan_type=\$\(jq -er '\.type'/)
  assert.match(workflow, /MANUAL_SCAN_PLAN_PATH: \$\{\{ steps\.manual_plan\.outputs\.path \}\}/)
  assert.match(workflow, /MANUAL_SCAN_PLAN_TYPE: \$\{\{ steps\.manual_plan\.outputs\.type \}\}/)
  assert.match(workflow, /if test "\$MANUAL_SCAN_PLAN_TYPE" = author-requested-catalog-recheck/)
  assert.match(workflow, /central contact-ledger CAS reservation/)
  assert.match(workflow, /manual_args=\(\)/)
  assert.match(workflow, /manual_args=\(--catalog-only\)/)
  assert.match(workflow, /Catalog-only policy workflow/)
  assert.match(workflow, /author-notifications:[\s\S]+inputs\.manual_scan_plan_branch == ''/)
  assert.match(workflow, /owner-report:[\s\S]+inputs\.manual_scan_plan_commit == ''/)
  assert.match(source, /if \(manualScanPlan\)/)
  assert.match(source, /manualWithdrawalDetailPaths/)
  assert.match(source, /type: manualScanPlan\.type === 'author-requested-catalog-recheck'/)
  assert.match(source, /bindFixedSourceLatestDshWindow\(updated, dshReleaseWindow\)/)
  assert.match(source, /scopePreconditions\[file\] = sha256\(existing\)/)
  assert.match(source, /scopePostconditions\[file\] = null/)
  assert.match(source, /prunePaths: manualWithdrawalDetailPaths/)
  assert.match(source, /author recheck detail path is missing from the current Catalog/)
  assert.match(source, /scheduled automation must be restricted to the Catalog/)
  assert.match(source, /select a verified --manual-scan-plan or the bounded --catalog-only scope/)
  assert.match(source, /mode: 'catalog-only-periodic-recheck', scanScope: 'catalog-only'/)
  assert.match(source, /\{ manageCandidates: false \}/)
  assert.match(source, /if \(policy\.search\?\.enabled !== true\) return \[\]/)
  const scheduledBranch = source.split('// The scheduled path is deliberately Catalog-only.')[1]?.split("if (!manualScanPlan)")[0]
  assert.ok(scheduledBranch, 'scheduled policy branch remains explicitly delimited')
  assert.doesNotMatch(scheduledBranch, /candidateIdentity|inspectDiscoveries|pruneHistoricalRejectedCandidates|pruneExcludedCandidates|pruneExcludedRecommendations/)
  assert.match(source, /async function inspectManualAdmissions\(catalog, candidates, policy,/)
  assert.match(source, /inspectManualAdmissions\(catalog, candidates, policy, github,/)
  assert.match(source, /const manualCompatibilityCandidates = createManualCompatibilityCandidateScope\(candidates\)/)
  assert.match(source, /applyLatestDshCompatibilityPolicy\([\s\S]+manualCompatibilityCandidates/)
  assert.match(source, /manualCompatibilityCandidates\.entries\.length !== 0/)
  assert.match(source, /supportsDshReleaseWindow\(entry, dshReleaseWindow\.releases\)/)
  assert.doesNotMatch(source, /from ['"]node:child_process['"]|require\(['"](?:node:)?child_process['"]\)/)
  assert.doesNotMatch(source, /npm (?:install|ci)|pnpm|yarn/)
  assert.match(source, /allowLifecycleScripts/)
  assert.match(reviewSource, /permissionSignals/)
  assert.match(source, /transientFailures/)
  assert.match(source, /skippedDiscoveries/)
  assert.match(source, /error\?\.status === 404 \|\| error\?\.status === 409/)
  const readerSource = await read('scripts/catalog-github-reader.mjs')
  assert.match(readerSource, /captureNoCommonAncestor === true/)
  assert.match(readerSource, /No common ancestor between \[a-f0-9\]/)
  assert.doesNotMatch(readerSource, /from ['"]node:child_process['"]|require\(['"](?:node:)?child_process['"]\)/)
  assert.match(source, /retryInfrastructure/)
  assert.match(reviewSource, /selected\.slice\(index, index \+ 8\)/)
  assert.match(reviewSource, /Promise\.all\(batch\.map/)
  assert.match(source, /catalog\.entries\.sort\(compareCatalogEntries\)/)
  assert.match(source, /baselineCatalog\.entries\.slice/)
  assert.match(source, /sourceVersionChecks\.checkedEntries/)
  assert.match(source, /sourceVersionChecks\.newerVersionsDeferred/)
  assert.match(source, /catalogChangeReviewContract/)
  assert.match(source, /sourceVersionChecks\.sameVersionCatalogUpdates/)
  assert.match(source, /catalog-repinned-same-version/)
  assert.match(source, /sourceVersionChecks\.unresolvedEntries/)
  assert.match(source, /fetchOfficialDshReleaseWindow/)
  assert.match(source, /applyLatestDshCompatibilityPolicy/)
  assert.match(source, /compatibilityPolicy\.catalogChanged/)
  assert.match(source, /dshReleaseWindowSha256/)
  assert.match(source, /pruneHistoricalRejectedCandidates/)
  assert.match(source, /inspectRejectedCandidateCompatibility/)
  assert.match(source, /isDurableRejectedCandidateDecision\(previous\)/)
  assert.match(source, /candidateRetention\.durableDecisionsPreserved/)
  assert.match(source, /candidateRetention\.registryRemovals/)
  assert.match(source, /candidatesChanged = !prospectiveCandidatesBuffer\.equals\(originalCandidates\)/)
  assert.match(source, /Candidate Registry serialization changed without a write decision/)
  assert.match(reviewSource, /sourceBudgetFindings/)
  assert.match(source, /CATALOG_AUTOMATION_UPDATE_REVIEW/)
  assert.match(source, /entry\.installPath \?\? ['"]\.['"]/)
  assert.match(source, /catalogUpdateIdentityMatches/)
  assert.match(source, /buildCatalogVersionUpdate/)
  assert.match(source, /sourcePolicy === 'external-only'\s*&&\s*isNoCommonAncestorError/)
  assert.match(source, /holdExternalOnlyAfterDisconnectedHistory\(reviewed, entry\.commit, candidate\.commit, analysis\.reasons\)/)
  assert.doesNotMatch(source, /isSafeSelfManagerUpdate|SELF_MANAGER_MAX_FILE_BYTES|SELF_MANAGER_MAX_TOTAL_RUNTIME_BYTES/)
  assert.match(source, /admissionDecision/)
  assert.match(source, /admissionReviewDigest/)
  assert.match(reviewSource, /isGeneratedSelfManagerRegistryData\(candidate, relativePath\)/)
  assert.doesNotMatch(reviewSource, /isTestSourceFile\(relativePath\)/)
  assert.match(source, /isSelfManagerEntry\(entry\)\s*&&\s*isBoundedSourceLineage\(lineage, maxCommitSpan, \{ allowDiverged: true \}\)/)
  assert.match(source, /bounded-self-manager-history-divergence/)
  assert.match(source, /allowProtectedManager/)
  assert.doesNotMatch(source, /entry\.status !== 'approved' \|\| entry\.updatePolicy !== 'source-verified'/)
  assert.match(source, /localizeCatalogEntry/)
  assert.match(source, /relocalizeCatalogEntries\(catalog\.entries, catalog\.registry\.categories\)/)
  assert.match(source, /report\.relocalizedEntries = localized\.changes/)
  assert.match(source, /report\.relocalizedEntries\.length > 0/)
  assert.match(source, /assertCatalogLocalization/)
  assert.match(source, /assertLegacyCatalogCompatibility/)
  assert.match(source, /automation precondition hash mismatch/)
  assert.match(source, /expectedCatalogIndexSha/)
  assert.match(source, /catalogIndexBackup/)
  assert.match(source, /atomicWrite\(catalogIndexPath, originalCatalogIndex\)/)
  assert.match(source, /automation base Commit must be a full Git SHA/)
  assert.match(source, /writeAutomationFailureReport/)
  assert.match(source, /statisticsAvailable: false/)
})

test('failed Catalog automation preserves a machine-readable failure report before any network scan', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'dsh-catalog-automation-failure-'))
  t.after(() => rm(directory, { recursive: true, force: true }))
  const reportPath = join(directory, 'catalog-automation-report.json')
  await assert.rejects(execFileAsync(process.execPath, [
    catalogAutomationPath,
    '--catalog-only',
    '--observed-at', '2026-08-25T10:00:00Z',
    '--report', reportPath,
  ], {
    cwd: rootPath,
    env: { ...process.env, CATALOG_BASE_COMMIT: 'not-a-full-commit' },
  }))
  const report = JSON.parse(await readFile(reportPath, 'utf8'))
  assert.equal(report.status, 'failed')
  assert.equal(report.completed, false)
  assert.equal(report.statisticsAvailable, false)
  assert.equal(report.failure.stage, 'validate-authority')
  assert.match(report.failure.message, /full Git SHA/)
  assert.equal(Object.hasOwn(report, 'postconditions'), false)
})

test('author remediation notifications are hash-bound, rate-limited, and use only the repository token', async () => {
  const [workflow, planner, resolver, apply, reportWorkflow] = await Promise.all([
    read('.github/workflows/author-notifications.yml'),
    read('scripts/plan-author-notices.mjs'),
    read('scripts/resolve-author-notice-targets.mjs'),
    read('scripts/apply-author-notice-plan.mjs'),
    read('.github/workflows/catalog-run-report.yml'),
  ])
  assert.match(workflow, /workflow_call:/)
  assert.match(workflow, /workflow_dispatch:/)
  assert.doesNotMatch(workflow, /workflow_run:/)
  assert.match(workflow, /Exact completed Catalog run ID to recover/)
  assert.match(workflow, /run-name: Author notifications for Catalog run \$\{\{ inputs\.catalog_run_id \}\}/)
  assert.match(workflow, /issues: write/)
  assert.match(workflow, /actions: read/)
  assert.match(workflow, /jq -r \.path/)
  assert.match(workflow, /\.github\/workflows\/catalog-automation\.yml/)
  assert.doesNotMatch(workflow, /jq -r \.name/)
  assert.match(workflow, /group: author-notifications/)
  assert.match(workflow, /catalog-automation-\$\{CATALOG_RUN_ID\}-\$\{CATALOG_RUN_ATTEMPT\}/)
  assert.match(workflow, /author-notification-plan-\$\{\{ inputs\.catalog_run_id \}\}-\$\{\{ inputs\.catalog_run_attempt \}\}/)
  assert.match(workflow, /--max-create 10/)
  assert.match(workflow, /--identity-only true/)
  assert.match(planner, /MAX_AUTHOR_NOTICE_ACTIONS = 500/)
  assert.match(resolver, /plan\.contactRepositoryKeys\.length > 2500/)
  assert.match(resolver, /identity-resolution-only/)
  assert.match(apply, /plan\.actions\.length > MAX_AUTHOR_NOTICE_ACTIONS/)
  assert.match(workflow, /候选记录覆盖/)
  assert.match(workflow, /candidate_unaccounted/)
  assert.match(workflow, /registry\/candidates\.json/)
  assert.match(workflow, /--catalog-run-id "\$\{\{ steps\.report\.outputs\.run_id \}\}"/)
  assert.match(workflow, /plan-author-notices\.mjs/)
  assert.match(workflow, /apply-author-notice-plan\.mjs/)
  assert.match(workflow, /resolve-author-notice-targets\.mjs/)
  assert.match(workflow, /--issues "\$RUNNER_TEMP\/author-notice-issues\.json"/)
  assert.match(workflow, /collect-author-feedback\.mjs/)
  assert.match(workflow, /author-feedback\.json/)
  assert.match(reportWorkflow, /--author-feedback/)
  assert.match(workflow, /GITHUB_TOKEN: \$\{\{ github\.token \}\}/)
  assert.doesNotMatch(workflow, /PAT|SMTP|npm (?:install|ci)|pnpm|yarn/)
  assert.match(planner, /ignoreInfrastructureFailures: true/)
  assert.match(planner, /deduplicateByCanonicalRepository: true/)
  assert.match(planner, /accountForEveryCandidateRepository: true/)
  assert.match(planner, /neverSendPromotionOnlyMessages: true/)
  assert.match(planner, /neverCreateIssuesInExternalRepositories: true/)
  assert.match(planner, /queueAllDeterministicCandidateRemediation: true/)
  assert.match(planner, /Candidate Registry coverage invariant failed/)
  assert.match(planner, /candidateCoverageFingerprint/)
  assert.match(planner, /candidate-rejected/)
  assert.match(planner, /queuedNewIssues/)
  assert.match(planner, /githubNotificationEmailTriggers/)
  assert.match(planner, /upstreamModifiedStillBlocked/)
  assert.match(planner, /github\.com\/AI-Scarlett\/build-dsh-plugin/)
  assert.match(planner, /https:\/\/dsh\.store\//)
  assert.doesNotMatch(planner, /from ['"]node:child_process['"]|require\(['"](?:node:)?child_process['"]\)/)
  assert.match(resolver, /humanIdentity\(repository\.owner\)/)
  assert.doesNotMatch(resolver, /commits\?per_page=20/)
  assert.doesNotMatch(resolver, /from ['"]node:child_process['"]|require\(['"](?:node:)?child_process['"]\)/)
  assert.match(apply, /remote main changed after planning/)
  assert.match(apply, /managed Issues changed after planning/)
  assert.match(apply, /candidate coverage summary invariant failed/)
  assert.match(apply, /candidate coverage fingerprint mismatch/)
  assert.match(apply, /source-update/)
  assert.match(apply, /baseline/)
  assert.doesNotMatch(apply, /from ['"]node:child_process['"]|require\(['"](?:node:)?child_process['"]\)/)
})

test('Catalog directly creates one exact and deduplicated owner report notification', async () => {
  const [workflow, delivery] = await Promise.all([
    read('.github/workflows/catalog-run-report.yml'),
    read('scripts/catalog-report-delivery.mjs'),
  ])
  assert.match(workflow, /workflow_call:/)
  assert.match(workflow, /workflow_dispatch:/)
  assert.doesNotMatch(workflow, /workflow_run:/)
  assert.match(workflow, /Exact completed Catalog run ID to report/)
  assert.match(workflow, /run-name: Owner report for Catalog run \$\{\{ inputs\.catalog_run_id \}\} \(\$\{\{ inputs\.request_id \}\}\)/)
  assert.match(workflow, /issues: write/)
  assert.match(workflow, /actions: read/)
  assert.match(workflow, /jq -r \.path/)
  assert.match(workflow, /\.github\/workflows\/catalog-automation\.yml/)
  assert.doesNotMatch(workflow, /jq -r \.name/)
  assert.match(workflow, /\.sourceCatalogRunId == \$catalog_run_id/)
  assert.doesNotMatch(workflow, /gh run list --workflow author-notifications\.yml/)
  assert.match(workflow, /author-notification-plan-\$\{CATALOG_RUN_ID\}-\$\{CATALOG_RUN_ATTEMPT\}/)
  assert.match(workflow, /catalog-automation-\$\{CATALOG_RUN_ID\}-\$\{CATALOG_RUN_ATTEMPT\}/)
  assert.match(workflow, /CATALOG_RUN_ID: \$\{\{ steps\.catalog\.outputs\.run_id \}\}/)
  assert.match(workflow, /--delivery-key "catalog-\$CATALOG_RUN_ID"/)
  assert.match(workflow, /catalog-report-delivery\.mjs snapshot/)
  assert.match(workflow, /catalog-report-delivery\.mjs plan/)
  assert.match(workflow, /catalog-report-delivery\.mjs apply/)
  assert.match(workflow, /AUTHOR_FEEDBACK_PATH: \$\{\{ steps\.author_report\.outputs\.feedback_path \}\}/)
  assert.match(workflow, /--author-feedback "\$AUTHOR_FEEDBACK_PATH"/)
  assert.match(workflow, /--mention "@\$GITHUB_REPOSITORY_OWNER"/)
  assert.doesNotMatch(workflow, /SMTP|RESEND|\bPAT\b|npm (?:install|ci)|pnpm|yarn/)
  assert.match(delivery, /reportBodySha256/)
  assert.match(delivery, /reportStateSha256/)
  assert.match(delivery, /remote main changed after the Catalog report delivery plan was created/)
  assert.match(delivery, /managed Catalog report Issue changed after the delivery plan was created/)
  assert.match(delivery, /dsh-catalog-report:v1:/)
  assert.match(delivery, /dsh-author-feedback:v1:/)
  assert.match(delivery, /AUTHOR_FEEDBACK_NOTIFICATION_APPLIED/)
  assert.match(delivery, /authorFeedbackSha256/)
  assert.match(delivery, /feedbackOwnerMention: '@AI-Scarlett'/)
  assert.match(delivery, /githubNotificationEmailDeliveryVerified: false/)
  assert.doesNotMatch(delivery, /from ['"]node:child_process['"]|require\(['"](?:node:)?child_process['"]\)/)
})

test('Pages publishes bounded public automation evidence and recent additions', async () => {
  const [workflow, builder, client] = await Promise.all([
    read('.github/workflows/pages.yml'),
    read('scripts/build-marketplace-static.mjs'),
    read('marketplace/app.js'),
  ])
  assert.match(workflow, /actions: read/)
  assert.match(workflow, /gh run list --workflow catalog-automation\.yml --limit 8/)
  assert.match(workflow, /gh run list --workflow marketplace-watchdog\.yml --limit 8/)
  assert.match(workflow, /gh run download "\$run_id"/)
  assert.match(workflow, /--automation-runs/)
  assert.match(workflow, /Build domestic marketplace artifact/)
  assert.match(workflow, /--site-origin https:\/\/dsh-store\.cn/)
  assert.match(workflow, /--baidu-verification codeva-gZjUUScijx/)
  assert.match(workflow, /cp -a _site-domestic\/. _site\/domestic\//)
  assert.match(builder, /automation-status\.json/)
  assert.match(builder, /\['release-manifest\.json', 'automation-status\.json'\]/)
  assert.match(client, /data-automation-additions/)
  assert.match(client, /data-automation-updates/)
  assert.match(client, /data-automation-source-checked/)
  assert.match(client, /data-automation-source-applied/)
  assert.match(client, /entry\.searchTerms/)
})

test('watchdog waits for its exact repair run, invokes its report, and checks every public surface', async () => {
  const [workflow, timer, service, international, intlPublic, domestic, refresh, verifier, governance] = await Promise.all([
    read('.github/workflows/marketplace-watchdog.yml'),
    read('deploy/dsh-store-refresh@.timer'),
    read('deploy/dsh-store-refresh@.service'),
    read('deploy/refresh-international.env'),
    read('deploy/refresh-intl-public.env'),
    read('deploy/refresh-domestic.env'),
    read('deploy/refresh-from-pages.sh'),
    read('scripts/verify-marketplace-public.mjs'),
    read('AGENTS.md'),
  ])
  assert.match(workflow, /cron: "10,40 \* \* \* \*"/)
  assert.match(workflow, /cancel-in-progress: false/)
  assert.match(workflow, /jobs:\s+cadence:[\s\S]*actions: read[\s\S]*contents: read/)
  assert.match(workflow, /needs: cadence[\s\S]*needs\.cadence\.outputs\.due == 'true'/)
  assert.match(workflow, /actions\/workflows\/marketplace-watchdog\.yml\/runs\?per_page=100&status=completed/)
  assert.match(workflow, /LAST_SUCCESSFUL_WATCHDOG_AT=.*node scripts\/marketplace-watchdog-cadence\.mjs/)
  assert.doesNotMatch(workflow, /steps\.base|Bind the current main authority/)
  assert.match(workflow, /32400/)
  assert.match(workflow, /issues: write/)
  assert.match(workflow, /request_id="watchdog-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}"/)
  assert.match(workflow, /gh run list --workflow catalog-automation\.yml --limit 100[\s\S]*--json databaseId,event,displayTitle[\s\S]*\.event == "schedule" or \.event == "workflow_dispatch"[\s\S]*startswith\("Catalog automation \("\)/)
  assert.match(workflow, /if test -n "\$latest" && test "\$\(jq -r '\.conclusion \/\/ ""' <<<"\$latest"\)" = cancelled; then[\s\S]*jq -c '\.\[1\] \/\/ empty'/)
  assert.match(workflow, /gh workflow run catalog-automation\.yml --ref main -f request_id="\$request_id"/)
  assert.match(workflow, /select\(\.displayTitle == \$expected\)/)
  assert.match(workflow, /repos\/\$GITHUB_REPOSITORY\/actions\/runs\/\$target_id/)
  assert.match(workflow, /Directly invoke the owner report for the repaired Catalog run/)
  assert.match(workflow, /gh workflow run catalog-run-report\.yml --ref main/)
  assert.match(workflow, /expected_title="Owner report for Catalog run \$\{CATALOG_RUN_ID\} \(\$\{REQUEST_ID\}\)"/)
  assert.match(workflow, /-f catalog_run_id="\$CATALOG_RUN_ID"/)
  assert.match(workflow, /-f catalog_run_attempt="\$CATALOG_RUN_ATTEMPT"/)
  assert.match(workflow, /gh workflow run pages\.yml --ref main/)
  assert.match(workflow, /render-catalog-automation-notification\.mjs/)
  assert.match(workflow, /Catalog and Candidate Registries/)
  assert.match(workflow, /Download the exact author notification record/)
  assert.match(workflow, /author-notification-plan-\$\{REPORT_RUN_ID\}-\$\{REPORT_RUN_ATTEMPT\}/)
  assert.doesNotMatch(workflow, /gh run list --workflow author-notifications\.yml/)
  assert.match(workflow, /--author-notice-plan/)
  assert.match(workflow, /id: catalog_report[\s\S]{0,160}continue-on-error: true/)
  assert.match(workflow, /catalog-report-delivery\.mjs snapshot/)
  assert.match(workflow, /catalog-report-delivery\.mjs plan/)
  assert.match(workflow, /git fetch --no-tags origin main[\s\S]*base_commit=\$\(git rev-parse FETCH_HEAD\)[\s\S]*--base-commit "\$base_commit"/)
  assert.match(workflow, /catalog-report-delivery\.mjs apply/)
  assert.match(workflow, /watchdog-alert/)
  assert.match(workflow, /catalog-report-state\.json/)
  assert.match(workflow, /\.issue\.comments\[\]\?\.body \| contains\(\$marker\)/)
  assert.doesNotMatch(workflow, /gh issue comment/)
  assert.match(timer, /00,03,06,09,12,15,18,21:47:00 UTC/)
  assert.match(service, /EnvironmentFile=\/etc\/dsh-store\/refresh-%i\.env/)
  assert.match(service, /ReadWritePaths=\/opt\/dsh-store -\/opt\/dsh-store-cn \/run\/lock/)
  assert.match(international, /DSH_STORE_DOMAIN=dsh\.store/)
  assert.match(international, /DSH_STORE_HEALTH_SCHEME=http/)
  assert.match(international, /DSH_STORE_SITE_PREFIX=\/marketplace/)
  assert.match(intlPublic, /DSH_STORE_DOMAIN=dsh\.store/)
  assert.match(intlPublic, /DSH_STORE_ROOT=\/opt\/dsh-store/)
  assert.match(intlPublic, /DSH_STORE_PAGES_SUBDIR=$/m)
  assert.match(intlPublic, /DSH_STORE_HEALTH_SCHEME=https/)
  assert.match(intlPublic, /DSH_STORE_SITE_PREFIX=$/m)
  assert.match(domestic, /DSH_STORE_DOMAIN=dsh-store\.cn/)
  assert.match(domestic, /DSH_STORE_PAGES_SUBDIR=domestic/)
  assert.match(domestic, /DSH_STORE_HEALTH_SCHEME=https/)
  assert.match(domestic, /DSH_STORE_SITE_PREFIX=$/m)
  assert.ok(refresh.indexOf('check_public\n  printf') < refresh.indexOf('reason=already-current'))
  assert.match(refresh, /DSH_STORE_DOMAIN/)
  assert.match(refresh, /pages_subdir/)
  assert.match(refresh, /pages_path_prefix/)
  assert.match(refresh, /data-static-featured-id=/)
  assert.match(refresh, /candidates \/registry\/candidates\.json/)
  assert.match(refresh, /'registry\/candidates\.json'/)
  assert.match(refresh, /Candidate Registry artifact trust boundary is invalid/)
  assert.doesNotMatch(refresh, /id="catalog-snapshot"/)
  assert.match(refresh, /Refusing to remove unexpected failed candidate/)
  assert.match(refresh, /download_jobs="\$\{DSH_STORE_DOWNLOAD_JOBS:-12\}"/)
  assert.match(refresh, /download concurrency must be between 1 and 16/)
  assert.match(refresh, /xargs -r -P "\$download_jobs" -n 1 bash -Eeuo pipefail/)
  assert.match(refresh, /curl -4 --http1\.1 --compressed -fsSL --connect-timeout 10 --max-time 300 --retry 4 --retry-all-errors --retry-delay 2/)
  assert.match(refresh, /curl -4 --http1\.1 --compressed -fsSL --connect-timeout 10 --max-time 90 --retry 3 --retry-all-errors --retry-delay 2/)
  assert.doesNotMatch(refresh, /--continue-at -/)
  assert.match(refresh, /curl -4 --http1\.1 -fsS --resolve/)
  assert.match(refresh, /curl -4 --http1\.1 -fsSL --connect-timeout 10/)
  assert.match(refresh, /DSH_STORE_REFRESH_REUSED reused=/)
  assert.match(refresh, /old_manifest_sha/)
  assert.match(refresh, /DSH_STORE_REFRESH_RAW_FALLBACK path=/)
  assert.match(refresh, /raw\.githubusercontent\.com\/AI-Scarlett\/DSH-Store\/\$source_sha/)
  assert.match(refresh, /dsh\.store:http:\/marketplace/)
  assert.match(refresh, /dsh\.store:https:/)
  assert.match(refresh, /dsh-store\.cn:https:/)
  assert.match(refresh, /dsh-store\.cn:domestic/)
  assert.doesNotMatch(refresh, /curl[^\n]+ -k(?:\s|$)/)
  assert.match(verifier, /validateCandidateRegistry/)
  assert.match(verifier, /candidateSurfaces/)
  assert.match(verifier, /Candidate Registry does not match GitHub main authority/)
  assert.match(governance, /does not require a human\s+confirmation for each scheduled run/)
  assert.match(governance, /Real DSH Profile\/package\/restart/)
})


test('tool views require key review rather than a blanket protected-component accusation', () => {
  const own = `ctx.slots.register({ name: 'tool.call.toolview', key: 'mcp__demo__search' }, View)`
  assert.deepEqual(dshInterfaceSignals(own, 'client.js'), { protectedDsh: false, toolViewExtension: true })
  assert.equal(dshInterfaceSignals(own.replace('mcp__demo__search', 'bash')).protectedDsh, true)
  assert.equal(dshInterfaceSignals(`const key = 'bash'; ctx.slots.register({ name: 'tool.call.toolview', key }, View)`).toolViewExtension, true)
  assert.equal(dshInterfaceSignals("ctx.slots.register({ name: 'tool.call.toolview', key: 'bash', ...unknown }, View)").protectedDsh, false)
  assert.equal(dshInterfaceSignals(`const unrelated = { key: 'read' }; ${own}`).protectedDsh, false)
  assert.deepEqual(dshInterfaceSignals(`// ${own}`), { protectedDsh: false, toolViewExtension: false })
  assert.equal(dshInterfaceSignals("register({ name: `tool.call.toolview`, key: unknown }, View)").toolViewExtension, true)
  assert.equal(dshInterfaceSignals("ctx['slots'].register({ name: 'tool.call.toolview', key: dynamic }, View)").toolViewExtension, true)
  assert.equal(dshInterfaceSignals(`const HELP = "ctx.fiber.remove('x')"`).protectedDsh, false)
  assert.equal(dshInterfaceSignals(`ctx.fiber['remove']('official')`).protectedDsh, true)
  assert.equal(dshInterfaceSignals(`ctx.fiber?.remove('official')`).protectedDsh, true)
  assert.equal(dshInterfaceSignals(`ctx.loader.unwrapExports(module)`).protectedDsh, false)
  assert.equal(dshInterfaceSignals(`window.__ModuleLoader__.load({ id: 'demo', factory })`).protectedDsh, false)
})

test('the fixed-source reviewer does not flag its own diagnostic prose as a tool-view registration', async () => {
  const reviewer = await read('src/fixed-source-review.mjs')
  assert.equal(dshInterfaceSignals(reviewer, 'fixed-source-review.mjs').toolViewExtension, false)
})
