import assert from 'node:assert/strict'
import test from 'node:test'
import { buildAutomationStatus } from '../src/automation-status.mjs'

const catalog = {
  registry: { updatedAt: '2026-08-22T00:00:00Z' },
  entries: [
    { id: 'new-plugin', name: '通知助手（Notify Helper）', description: '任务完成后发送通知。', packageName: 'dsh-notify-helper', version: '1.0.0', status: 'approved', repositoryUrl: 'https://github.com/example/dsh-notify-helper' },
    { id: 'blocked', name: '受限插件（Blocked Plugin）', description: '权限证据不足。', packageName: 'dsh-blocked', version: '1.0.0', status: 'blocked', repositoryUrl: 'https://github.com/example/dsh-blocked' },
  ],
}

test('public status separates successful execution from actual Catalog changes', () => {
  const status = buildAutomationStatus({
    catalog, candidates: { entries: [{ id: 'candidate' }] }, generatedAt: '2026-08-22T03:00:00Z', sourceCommit: 'a'.repeat(40),
    runs: {
      catalogAutomation: [{ databaseId: 42, status: 'completed', conclusion: 'success', createdAt: '2026-08-22T02:00:00Z', updatedAt: '2026-08-22T02:05:00Z', url: 'https://github.com/example/repo/actions/runs/42', headSha: 'b'.repeat(40) }],
      marketplaceWatchdog: [{ databaseId: 43, status: 'completed', conclusion: 'success', createdAt: '2026-08-22T02:50:00Z', updatedAt: '2026-08-22T02:55:00Z', url: 'https://github.com/example/repo/actions/runs/43', headSha: 'c'.repeat(40) }],
    },
    reports: [{ runId: 42, report: {
      observedAt: '2026-08-22T02:01:00Z',
      addedEntries: [{ id: 'new-plugin' }],
      updatedEntries: [{ id: 'new-plugin', fromVersion: '1.0.0', toVersion: '1.0.0', changeKind: 'same-version-source-update', policy: 'user-reviewed' }],
      compatibilityUnlisted: [{ id: 'blocked' }],
      compatibilityRestored: [{ id: 'new-plugin' }],
      prunedCandidates: [{ id: 'candidate-pruned' }],
      compatibilityPolicy: {
        authority: 'official-npm-registry-active-supported-channels-through-highest',
        latestVersion: '0.1.2-alpha.5',
        latestReleases: ['0.1.2-alpha.3', '0.1.2-alpha.4', '0.1.2-alpha.5'],
        checkedApprovedEntries: 1,
        managedHeldEntries: 1,
      },
      candidateRetention: {
        authority: 'candidate-fixed-commit-package-manifests',
        bucket: 7,
        bucketCount: 24,
        checkedCandidates: 55,
        retainedCompatible: 4,
        retainedUnknown: 3,
        prunedUnsupported: 48,
        durableDecisionsPreserved: 1,
        registryRemovals: 48,
      },
      rejectedCandidates: [],
      deferredUpdates: [],
      transientFailures: [],
      sourceVersionChecks: {
        authority: 'canonical-github-default-branch-manifest-at-fixed-commit',
        checkedEntries: 2,
        currentEntries: 1,
        newerVersionCandidates: 1,
        catalogUpdates: 1,
        newerVersionsDeferred: 0,
        sourceChangedWithoutVersionBump: 1,
        sameVersionCatalogUpdates: 1,
        sameVersionUpdatesDeferred: 0,
        upstreamVersionBehind: 0,
        unresolvedEntries: 0,
      },
    } }],
  })
  assert.equal(status.overall.status, 'passed')
  assert.equal(status.scheduleHours, 8)
  assert.deepEqual(status.latestChanges.added, ['new-plugin'])
  assert.deepEqual(status.latestChanges.updated, ['new-plugin'])
  assert.equal(status.latestChanges.sourceVersionChecks.checkedEntries, 2)
  assert.equal(status.latestChanges.sourceVersionChecks.catalogUpdates, 1)
  assert.equal(status.latestChanges.sourceVersionChecks.sameVersionCatalogUpdates, 1)
  assert.equal(status.latestChanges.sourceVersionChecks.sameVersionUpdatesDeferred, 0)
  assert.equal(status.latestChanges.sourceVersionChecks.unresolvedEntries, 0)
  assert.deepEqual(status.latestChanges.compatibilityUnlisted, ['blocked'])
  assert.deepEqual(status.latestChanges.compatibilityRestored, ['new-plugin'])
  assert.deepEqual(status.latestChanges.prunedCandidates, ['candidate-pruned'])
  assert.equal(status.latestChanges.candidateRetention.durableDecisionsPreserved, 1)
  assert.equal(status.latestChanges.candidateRetention.registryRemovals, 48)
  assert.deepEqual(status.latestChanges.compatibilityPolicy.latestReleases, ['0.1.2-alpha.3', '0.1.2-alpha.4', '0.1.2-alpha.5'])
  assert.equal(status.recentAdditions[0].name, '通知助手（Notify Helper）')
  assert.equal(status.recentAdditions[0].runUrl, 'https://github.com/example/repo/actions/runs/42')
  assert.equal(status.recentUpdates[0].fromVersion, '1.0.0')
  assert.equal(status.recentUpdates[0].toVersion, '1.0.0')
  assert.equal(status.recentUpdates[0].changeKind, 'same-version-source-update')
  assert.equal(status.recentUpdates[0].policy, 'user-reviewed')
  assert.deepEqual(status.catalog, { entries: 2, approved: 1, blocked: 1, unlisted: 0, candidates: 1, updatedAt: '2026-08-22T00:00:00.000Z' })
})

test('missing workflow evidence remains explicitly unknown', () => {
  const status = buildAutomationStatus({ catalog, candidates: { entries: [] }, generatedAt: '2026-08-22T03:00:00Z', sourceCommit: 'local' })
  assert.equal(status.overall.status, 'unknown')
  assert.equal(status.scanner, null)
  assert.equal(status.latestChanges.statisticsAvailable, false)
  assert.equal(status.latestChanges.added, null)
  assert.equal(status.latestChanges.sourceVersionChecks, null)
  assert.equal(status.recentAdditions.length, 0)
  assert.equal(status.recentUpdates.length, 0)
})

test('a failed latest scan exposes unavailable statistics while retaining completed historical changes', () => {
  const status = buildAutomationStatus({
    catalog, candidates: { entries: [] }, generatedAt: '2026-08-25T11:00:00Z', sourceCommit: 'a'.repeat(40),
    runs: {
      catalogAutomation: [
        { databaseId: 44, status: 'completed', conclusion: 'failure', createdAt: '2026-08-25T10:00:00Z', updatedAt: '2026-08-25T10:10:00Z', url: 'https://github.com/example/repo/actions/runs/44', headSha: 'd'.repeat(40) },
        { databaseId: 42, status: 'completed', conclusion: 'success', createdAt: '2026-08-25T02:00:00Z', updatedAt: '2026-08-25T02:10:00Z', url: 'https://github.com/example/repo/actions/runs/42', headSha: 'b'.repeat(40) },
      ],
      marketplaceWatchdog: [
        { databaseId: 45, status: 'completed', conclusion: 'failure', createdAt: '2026-08-25T10:55:00Z', updatedAt: '2026-08-25T10:56:00Z', url: 'https://github.com/example/repo/actions/runs/45', headSha: 'e'.repeat(40) },
      ],
    },
    reports: [
      { runId: 44, report: {
        status: 'failed', completed: false, statisticsAvailable: false,
        observedAt: '2026-08-25T10:01:00Z',
        sourceVersionChecks: { checkedEntries: 85, newerVersionCandidates: 12, catalogUpdates: 0 },
        addedEntries: [], updatedEntries: [],
        failure: { stage: 'apply-latest-dsh-compatibility-policy', message: 'compatibility alias conflict' },
      } },
      { runId: 42, report: {
        observedAt: '2026-08-25T02:01:00Z',
        addedEntries: [{ id: 'new-plugin' }], updatedEntries: [],
      } },
    ],
  })
  assert.equal(status.overall.status, 'failed')
  assert.equal(status.latestChanges.statisticsAvailable, false)
  assert.equal(status.latestChanges.added, null)
  assert.equal(status.latestChanges.updated, null)
  assert.equal(status.latestChanges.sourceVersionChecks, null)
  assert.equal(status.latestChanges.failure.stage, 'apply-latest-dsh-compatibility-policy')
  assert.equal(status.recentAdditions.length, 1)
  assert.equal(status.recentAdditions[0].id, 'new-plugin')
})

test('public scan history includes the latest eight runs and never invents missing report counts', () => {
  const runs = Array.from({ length: 10 }, (_, index) => ({
    databaseId: 100 + index,
    status: 'completed',
    conclusion: index === 9 ? 'failure' : 'success',
    event: index === 9 ? 'schedule' : 'workflow_dispatch',
    createdAt: `2026-08-${String(10 + index).padStart(2, '0')}T02:00:00Z`,
    updatedAt: `2026-08-${String(10 + index).padStart(2, '0')}T02:05:00Z`,
    url: `https://github.com/example/repo/actions/runs/${100 + index}`,
    headSha: 'b'.repeat(40),
  }))
  const status = buildAutomationStatus({
    catalog,
    candidates: { entries: [] },
    generatedAt: '2026-08-22T03:00:00Z',
    sourceCommit: 'a'.repeat(40),
    runs: { catalogAutomation: runs },
    reports: [
      { runId: 109, report: { status: 'failed', completed: false, statisticsAvailable: false, failure: { stage: 'internal-stage', message: 'must not be exposed in run summary' } } },
      { runId: 108, report: {
        completed: true,
        addedEntries: [],
        updatedEntries: [],
        compatibilityUnlisted: [],
        compatibilityRestored: [],
        prunedCandidates: [],
        rejectedCandidates: [],
        deferredUpdates: [],
        transientFailures: [],
        sourceVersionChecks: { checkedEntries: 12, sameVersionCatalogUpdates: 0 },
      } },
      { runId: 107, report: { completed: true } },
    ],
  })

  assert.equal(status.recentScanRuns.length, 8)
  assert.equal(status.recentScanRuns[0].runId, 109)
  assert.equal(status.recentScanRuns[0].event, 'schedule')
  assert.equal(status.recentScanRuns[0].reportAvailable, true)
  assert.equal(status.recentScanRuns[0].statisticsAvailable, false)
  assert.equal(status.recentScanRuns[0].added, null)
  assert.equal(status.recentScanRuns[0].sourceVersionChecks, null)
  assert.equal(JSON.stringify(status.recentScanRuns[0]).includes('internal-stage'), false)

  const success = status.recentScanRuns.find(run => run.runId === 108)
  assert.equal(success.statisticsAvailable, true)
  assert.equal(success.added, 0)
  assert.equal(success.updated, 0)
  assert.equal(success.sourceVersionChecks.checkedEntries, 12)
  assert.equal(success.sourceVersionChecks.sameVersionCatalogUpdates, 0)

  const partial = status.recentScanRuns.find(run => run.runId === 107)
  assert.equal(partial.statisticsAvailable, true)
  assert.equal(partial.added, null)
  assert.equal(partial.sourceVersionChecks, null)
})
