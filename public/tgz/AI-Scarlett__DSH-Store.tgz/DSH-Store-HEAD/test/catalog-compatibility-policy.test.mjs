import assert from 'node:assert/strict'
import test from 'node:test'
import {
  applyLatestDshCompatibilityPolicy,
  bindFixedSourceLatestDshWindow,
  createManualCompatibilityCandidateScope,
  COMPATIBILITY_CANDIDATE_SOURCE,
  COMPATIBILITY_HOLD_PREFIX,
  fetchOfficialDshReleaseWindow,
  officialDshReleaseWindow,
} from '../src/catalog-compatibility-policy.mjs'

const admissionAuthority = { policyDigest: 'c'.repeat(64), reviewRegistryDigest: 'd'.repeat(64) }
const admission = { engine: 'bounded-source-v3', binding: 'e'.repeat(64), ...admissionAuthority, state: 'source-verified', sourceContract: 'verified', coverage: 'complete', capabilities: 'low-risk-static' }

const observedAt = '2026-08-24T12:00:00.000Z'
const releaseWindow = {
  packageName: '@deepseek-ai/dsh',
  registryUrl: 'https://registry.npmjs.org/@deepseek-ai%2Fdsh',
  stableVersion: '0.1.1-rc.2',
  latestVersion: '0.1.2-alpha.5',
  releaseTag: 'alpha',
  releaseChannel: 'preview',
  releases: ['0.1.2-alpha.3', '0.1.2-alpha.4', '0.1.2-alpha.5'],
  releaseCount: 3,
  authority: 'official-npm-registry-active-supported-channels-through-highest',
}

function entry(overrides = {}) {
  return {
    id: 'dsh-example',
    name: '示例插件（Example Plugin）',
    description: '用于验证兼容策略的示例插件。',
    repositoryUrl: 'https://github.com/ExampleOwner/dsh-example',
    defaultBranch: 'main',
    commit: 'a'.repeat(40),
    version: '1.0.0',
    categories: ['tools'],
    status: 'approved',
    compatibility: {
      dsh: '>=0.1.0-rc.7',
      dshReleases: {
        'rc.7': 'unknown',
        'rc.8': 'incompatible',
        '0.1.1-rc.1': 'unknown',
        '0.1.1-rc.2': 'unknown',
      },
    },
    source: { updatedAt: '2026-08-23T00:00:00.000Z' },
    ...overrides,
  }
}

function documents(catalogEntry = entry(), candidateEntries = []) {
  return {
    catalog: { entries: [catalogEntry] },
    candidates: { entries: candidateEntries },
  }
}

test('official release window follows the highest supported channel and excludes newer next-only or deprecated releases', () => {
  const result = officialDshReleaseWindow({
    name: '@deepseek-ai/dsh',
    'dist-tags': { latest: '0.1.1-rc.2', next: '0.2.0-rc.1', alpha: '0.1.2-alpha.5' },
    versions: {
      '0.1.0-rc.7': {},
      '0.1.0-rc.8': {},
      '0.1.1-rc.1': {},
      '0.1.1-rc.2': {},
      '0.1.2-alpha.2': {},
      '0.1.2-alpha.3': {},
      '0.1.2-alpha.4': {},
      '0.1.2-alpha.5': {},
      '0.2.0-rc.1': {},
      '0.1.0-rc.6': { deprecated: 'do not use' },
    },
  }, 3)
  assert.equal(result.latestVersion, '0.1.2-alpha.5')
  assert.deepEqual(result.releases, releaseWindow.releases)
  assert.ok(!result.releases.includes('0.2.0-rc.1'))
})

test('official registry errors fail closed instead of using Catalog fallback releases', async () => {
  await assert.rejects(() => fetchOfficialDshReleaseWindow({
    fetch: async () => ({ ok: false, status: 503, text: async () => '' }),
    releaseCount: 3,
  }), /official DSH registry returned HTTP 503/)
  assert.throws(() => officialDshReleaseWindow({
    name: '@deepseek-ai/dsh',
    'dist-tags': { latest: '0.1.1-rc.2' },
    versions: { '0.1.1-rc.2': {} },
  }, 0), /window count is invalid/)
})

test('unknown compatibility stays visibly blocked and moved to a non-installable reviewing candidate', () => {
  const { catalog, candidates } = documents()
  const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt)
  assert.equal(catalog.entries[0].status, 'blocked')
  assert.match(catalog.entries[0].statusReason, new RegExp(`^${COMPATIBILITY_HOLD_PREFIX}`))
  assert.equal(candidates.entries.length, 1)
  assert.equal(candidates.entries[0].status, 'reviewing')
  assert.equal(candidates.entries[0].route, 'direct-review')
  assert.deepEqual(candidates.entries[0].discoverySources, [COMPATIBILITY_CANDIDATE_SOURCE])
  assert.equal(report.unlisted.length, 1)
  assert.equal(report.catalogChanged, true)
  assert.equal(report.candidatesChanged, true)
})

test('Catalog-only compatibility rechecks do not create, refresh, or remove Candidate Registry records', () => {
  const unrelatedManagedCandidate = {
    id: 'otherowner-old-plugin',
    name: 'Old plugin',
    description: 'A plugin retained for a separate Catalog review.',
    repositoryUrl: 'https://github.com/OtherOwner/old-plugin',
    defaultBranch: 'main',
    latestCommit: 'b'.repeat(40),
    sourceUpdatedAt: null,
    discoveredAt: observedAt,
    discoverySources: [COMPATIBILITY_CANDIDATE_SOURCE],
    topics: ['dsh-compatibility-review'],
    status: 'reviewing',
    route: 'direct-review',
    statusReason: `${COMPATIBILITY_HOLD_PREFIX} previous window`,
  }
  const catalog = { entries: [entry()] }
  const originalCandidate = structuredClone(unrelatedManagedCandidate)
  const candidateEntries = new Proxy([unrelatedManagedCandidate], {
    get(target, property, receiver) {
      if (property === Symbol.iterator) throw new Error('Catalog-only compatibility must not enumerate candidate records')
      return Reflect.get(target, property, receiver)
    },
  })
  const candidates = { entries: candidateEntries }
  const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt, null, { manageCandidates: false })

  assert.equal(catalog.entries[0].status, 'blocked')
  assert.equal(candidates.entries.length, 1)
  assert.deepEqual(candidates.entries[0], originalCandidate)
  assert.equal(report.candidatesChanged, false)
  assert.equal(report.managedCandidatesCreated, 0)
  assert.equal(report.managedCandidatesRefreshed, 0)
  assert.equal(report.managedCandidatesRemoved, 0)
  assert.equal(report.unlisted[0].candidateDisposition, 'candidate-registry-not-managed')
})

test('each policy run materializes the live latest-three fields without inventing evidence', () => {
  const value = entry({
    compatibility: {
      dsh: '>=0.1.0-rc.7',
      dshReleases: { '0.1.2-alpha.3': 'compatible' },
      dshOperations: {
        '0.1.2-alpha.3': { install: 'passed', start: 'passed', uninstall: 'unknown', rollback: 'unknown' },
      },
    },
  })
  const { catalog, candidates } = documents(value)
  const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt)
  assert.deepEqual(catalog.entries[0].compatibility.dshReleases, {
    '0.1.2-alpha.3': 'compatible', '0.1.2-alpha.4': 'unknown', '0.1.2-alpha.5': 'unknown',
  })
  assert.deepEqual(catalog.entries[0].compatibility.dshOperations['0.1.2-alpha.5'], {
    install: 'unknown', start: 'unknown', uninstall: 'unknown', rollback: 'unknown',
  })
  assert.equal(report.compatibilityRecordsAdded, 4)
  assert.deepEqual(report.compatibilityEntriesUpdated.map(item => item.id), ['dsh-example'])
  assert.equal(report.catalogChanged, true)
})

test('a fixed-source author recheck binds official latest-three evidence without changing blocked external-only status', () => {
  const value = entry({ status: 'blocked', updatePolicy: 'external-only', statusReason: 'permission review required' })
  const evidence = bindFixedSourceLatestDshWindow(value, releaseWindow)
  assert.equal(value.status, 'blocked')
  assert.equal(value.updatePolicy, 'external-only')
  assert.equal(evidence.compatibleReleasePresent, false)
  assert.deepEqual(evidence.releaseStatuses, {
    '0.1.2-alpha.3': 'unknown',
    '0.1.2-alpha.4': 'unknown',
    '0.1.2-alpha.5': 'unknown',
  })
  assert.deepEqual(value.compatibility.latestWindow, { state: 'recheck-required', releases: releaseWindow.releases })
  assert.equal(evidence.recordsAdded, 6)
  value.compatibility.dshReleases['0.1.2-alpha.4'] = 'compatible'
  const supported = bindFixedSourceLatestDshWindow(value, releaseWindow)
  assert.equal(supported.compatibleReleasePresent, true)
  assert.deepEqual(value.compatibility.latestWindow, { state: 'current', releases: releaseWindow.releases })
  assert.equal(value.status, 'blocked')
})

test('future official alpha releases advance the window without source constants', () => {
  const result = officialDshReleaseWindow({
    name: '@deepseek-ai/dsh',
    'dist-tags': { latest: '0.1.1-rc.2', alpha: '0.1.2-alpha.7' },
    versions: {
      '0.1.1-rc.2': {}, '0.1.2-alpha.3': {}, '0.1.2-alpha.4': {},
      '0.1.2-alpha.5': {}, '0.1.2-alpha.6': {}, '0.1.2-alpha.7': {},
    },
  }, 3)
  assert.deepEqual(result.releases, ['0.1.2-alpha.5', '0.1.2-alpha.6', '0.1.2-alpha.7'])
})

test('an exact compatible alias in any of the latest three releases keeps an approved entry listed', () => {
  const supported = entry({
    compatibility: {
      dsh: '>=0.1.0-rc.7',
      dshReleases: { '0.1.2-alpha.3': 'compatible', '0.1.2-alpha.4': 'unknown', '0.1.2-alpha.5': 'unknown' },
    },
  })
  const { catalog, candidates } = documents(supported)
  const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt)
  assert.equal(catalog.entries[0].status, 'approved')
  assert.equal(candidates.entries.length, 0)
  assert.equal(report.unlisted.length, 0)
  assert.equal(report.catalogChanged, true, 'missing operation records are materialized as unknown')
})

test('a managed hold with current complete admission restores and removes only its managed candidate', () => {
  const held = entry({
    status: 'unlisted', admission,
    statusReason: `${COMPATIBILITY_HOLD_PREFIX} prior window`,
    compatibility: {
      dsh: '>=0.1.0-rc.7',
      dshReleases: { '0.1.2-alpha.3': 'compatible', '0.1.2-alpha.4': 'unknown', '0.1.2-alpha.5': 'unknown' },
    },
  })
  const managed = {
    id: 'exampleowner-dsh-example',
    name: held.name,
    description: held.description,
    repositoryUrl: held.repositoryUrl,
    defaultBranch: held.defaultBranch,
    latestCommit: held.commit,
    sourceUpdatedAt: held.source.updatedAt,
    discoveredAt: observedAt,
    discoverySources: [COMPATIBILITY_CANDIDATE_SOURCE],
    topics: ['dsh-compatibility-review'],
    status: 'reviewing',
    route: 'direct-review',
    statusReason: `${COMPATIBILITY_HOLD_PREFIX} prior window`,
  }
  const { catalog, candidates } = documents(held, [managed])
  const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt, admissionAuthority)
  assert.equal(catalog.entries[0].status, 'approved')
  assert.equal(Object.hasOwn(catalog.entries[0], 'statusReason'), false)
  assert.equal(candidates.entries.length, 0)
  assert.equal(report.restored.length, 1)
  assert.equal(report.catalogChanged, true)
  assert.equal(report.candidatesChanged, true)
})

test('historical compatibility never restores unknown, incomplete, rejected or stale source admission', () => {
  const invalid = [undefined, { ...admission, state: 'incomplete' }, { ...admission, coverage: 'incomplete' },
    { ...admission, sourceContract: 'unverified' }, { ...admission, state: 'rejected' }, { ...admission, capabilities: 'prohibited' },
    { ...admission, policyDigest: 'f'.repeat(64) }, { ...admission, reviewRegistryDigest: 'f'.repeat(64) }, { ...admission, engine: 'old-policy' }]
  for (const record of invalid) {
    const held = entry({ status: 'unlisted', statusReason: `${COMPATIBILITY_HOLD_PREFIX} prior window`, admission: record,
      compatibility: { dshReleases: { '0.1.2-alpha.4': 'compatible' } } })
    const { catalog, candidates } = documents(held)
    const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt, admissionAuthority)
    assert.notEqual(held.status, 'approved'); assert.equal(report.restored.length, 0)
    assert.equal(report.restorationBlocked.length, 1); assert.equal(candidates.entries.length, 1)
    assert.match(held.statusReason, /current complete fixed-source admission/)
  }
  const { catalog, candidates } = documents(entry({ status: 'blocked', statusReason: `${COMPATIBILITY_HOLD_PREFIX} prior window`, admission,
    compatibility: { dshReleases: { '0.1.2-alpha.4': 'compatible' } } }))
  const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt)
  assert.equal(report.restored.length, 0, 'missing current policy authority fails closed')
})

test('a pre-existing candidate for the same repository is preserved byte-for-byte', () => {
  const historicalCandidate = {
    id: 'historical-candidate',
    name: 'Historical Candidate',
    description: 'A DeepSeek Harness plugin',
    repositoryUrl: entry().repositoryUrl,
    defaultBranch: 'main',
    latestCommit: 'b'.repeat(40),
    sourceUpdatedAt: null,
    discoveredAt: '2026-08-20T00:00:00.000Z',
    discoverySources: ['fixed-commit-review'],
    topics: ['dsh-plugin'],
    status: 'rejected',
    route: 'blocked',
    statusReason: 'Bundle entry collision from an earlier review',
  }
  const original = structuredClone(historicalCandidate)
  const { catalog, candidates } = documents(entry(), [historicalCandidate])
  const report = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt)
  assert.deepEqual(candidates.entries, [original])
  assert.equal(report.unlisted[0].candidateDisposition, 'existing-candidate-preserved')
  assert.equal(report.candidatesChanged, false)
})

test('manual partial Catalog compatibility checks cannot prune unrelated managed candidates', () => {
  const unrelatedManagedCandidate = {
    id: 'otherowner-old-plugin',
    name: 'Old plugin',
    description: 'A plugin retained for a separate Catalog review.',
    repositoryUrl: 'https://github.com/OtherOwner/old-plugin',
    defaultBranch: 'main',
    latestCommit: 'b'.repeat(40),
    sourceUpdatedAt: null,
    discoveredAt: observedAt,
    discoverySources: [COMPATIBILITY_CANDIDATE_SOURCE],
    topics: ['dsh-compatibility-review'],
    status: 'reviewing',
    route: 'direct-review',
    statusReason: `${COMPATIBILITY_HOLD_PREFIX} separate Catalog review`,
  }
  const candidates = {
    schemaVersion: 1,
    registry: { updatedAt: observedAt },
    entries: [unrelatedManagedCandidate],
  }
  const before = structuredClone(candidates)
  const compatibilityScope = createManualCompatibilityCandidateScope(candidates)
  const manualEntry = entry({
    compatibility: { dsh: '>=0.1.0-rc.7', dshReleases: { '0.1.2-alpha.3': 'compatible' } },
  })

  assert.deepEqual(compatibilityScope.entries, [])
  assert.notEqual(compatibilityScope.registry, candidates.registry)
  const report = applyLatestDshCompatibilityPolicy({ entries: [manualEntry] }, compatibilityScope, releaseWindow, observedAt)

  assert.equal(manualEntry.status, 'approved')
  assert.equal(report.candidatesChanged, false)
  assert.equal(report.managedCandidatesRemoved, 0)
  assert.deepEqual(candidates, before)
})

test('multiple held plugins from one repository share one candidate and partial restoration keeps it', () => {
  const first = entry({ id: 'dsh-example-one', admission })
  const second = entry({ id: 'dsh-example-two', commit: 'b'.repeat(40) })
  const catalog = { entries: [first, second] }
  const candidates = { entries: [] }
  const initial = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, observedAt)
  assert.equal(initial.unlisted.length, 2)
  assert.equal(candidates.entries.length, 1)
  assert.equal(candidates.entries[0].latestCommit, null)
  assert.match(candidates.entries[0].statusReason, /dsh-example-one, dsh-example-two/)

  first.compatibility.dshReleases['0.1.2-alpha.5'] = 'compatible'
  const followUp = applyLatestDshCompatibilityPolicy(catalog, candidates, releaseWindow, '2026-08-25T00:00:00.000Z', admissionAuthority)
  assert.equal(first.status, 'approved')
  assert.equal(second.status, 'blocked')
  assert.equal(followUp.restored.length, 1)
  assert.equal(candidates.entries.length, 1)
  assert.equal(candidates.entries[0].latestCommit, second.commit)
  assert.match(candidates.entries[0].statusReason, /dsh-example-two/)
  assert.doesNotMatch(candidates.entries[0].statusReason, /dsh-example-one/)
})
