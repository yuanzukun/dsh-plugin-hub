/** `pet` namespace dictionaries. */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'phase.idle': '休息中',
  'phase.thinking': '思考中',
  'phase.working': '工作中',
  'phase.error': '出错了',
  'chatter.idle': '嘿嘿，拍我一下？',
  'chatter.idle2': '今天也要加油哦！',
  'chatter.idle3': '需要我帮忙吗？',
  'chatter.idle4': '摸摸～',
  'chatter.thinking': '嘘——别打扰我',
  'chatter.thinking2': '这个问题有点意思',
  'chatter.thinking3': '快想出来了！',
  'chatter.working': '加油加油！',
  'chatter.working2': '细节我来搞定',
  'chatter.working3': '进度条走起～',
  'chatter.error': '我不服，再来一次！',
  'chatter.error2': '马上就好（大概）',
  'chatter.error3': '这点小挫折难不倒我',
  'chatter.dive': '呜哇！跳水啦～',
  'chatter.dive2': '噗通！',
  'chatter.dive3': '完美转体入水！',
  'chatter.low': '余额快见底啦…',
  'chatter.low2': '该充值了…',
  'chatter.low3': '快没电了…',
  'action.minimize': '最小化',
  'action.restore': '显示小助手',
} satisfies Record<string, string>

/** The pet namespace key union. */
export type PetKey = keyof typeof zh

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'phase.idle': 'Resting',
  'phase.thinking': 'Thinking',
  'phase.working': 'Working',
  'phase.error': 'Error',
  'chatter.idle': 'Hey, pet me?',
  'chatter.idle2': 'Let’s crush today!',
  'chatter.idle3': 'Need a hand?',
  'chatter.idle4': 'Pet me～',
  'chatter.thinking': 'Shh — don’t distract me',
  'chatter.thinking2': 'Now that’s interesting',
  'chatter.thinking3': 'Almost got it!',
  'chatter.working': 'Go go go!',
  'chatter.working2': 'I’ve got the details',
  'chatter.working3': 'Progress bar coming up～',
  'chatter.error': 'Let me try again!',
  'chatter.error2': 'Almost (maybe)',
  'chatter.error3': 'Small setbacks won’t stop me',
  'chatter.dive': 'Whoa! Dive!',
  'chatter.dive2': 'Splash!',
  'chatter.dive3': 'Perfect spinning entry!',
  'chatter.low': 'Balance is running low…',
  'chatter.low2': 'Time to top up…',
  'chatter.low3': 'Almost out of juice…',
  'action.minimize': 'Minimize',
  'action.restore': 'Show pet',
} satisfies Record<PetKey, string>

/** Dictionary namespace owned by this plugin. */
export const NS = 'pet'
