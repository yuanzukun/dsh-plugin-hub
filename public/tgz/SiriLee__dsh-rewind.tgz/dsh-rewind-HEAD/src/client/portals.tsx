/**
 * dsh-rewind portal half: the per-user-message ↶ rewind button, rendered as a
 * React portal inside the message's `MessageIconActions` row.
 *
 * Why portals (aligned with the copy button's own rendering): the copy button
 * is a React child of the actions row, painted in the same commit as the
 * bubble. A pure-DOM `appendChild` (the earlier approach) lands one microtask
 * later and re-runs a full-transcript scan on EVERY mutation, which can push
 * the paint of a newly sent bubble — the "occasional hiccup before the bubble
 * shows". Portals let React own the button lifecycle (mount/unmount with the
 * row, no orphaned buttons, no manual re-attach after harness re-renders),
 * and the target collection is coalesced (one refresh per mutation batch) and
 * diffed (no setState churn when nothing changed).
 *
 * Mount point: the plugin registers a session-scoped bridge into the harness's
 * `conversation.session.header.actions` list slot. The bridge renders NO
 * header UI — it only portals buttons into the user rows of the session the
 * harness mounts it for. That slot is the harness-native way to get a
 * per-session React mount without touching any source; the registration is
 * typed structurally (see `SlotsLike`) so the plugin never imports the
 * conversation UI package's types and survives its version drift.
 *
 * COUPLING NOTE — HIGH. There is no harness interface for a per-user-message
 * action (see docs/compat/audit.md): `MessageIconActions.extraActions` and the
 * `conversation.chat.assistant-actions` slot are wired for assistant messages
 * only, and no per-user-message action slot exists. So this portal targets
 * undocumented internal structure — the `data-chat-flow-kind`,
 * `data-chat-anchor-key`, `data-composer-input`, `data-composer-card` and
 * `data-pending-steering` attributes plus the `anchorSeq` field read in
 * `client/hidden.ts`. Those are harness-internal and may change with the UI;
 * this module (and `hidden.ts`) must be re-adapted to follow, and is the
 * migration target when a first-class user-action slot or an official renderer
 * hook surface appears. The coupling is accepted deliberately because a
 * standards-conformant alternative does not exist today; it is not a defect to
 * be removed while the DOM-portal approach stands.
 *
 * Re-verified against 0.1.6-alpha.2: the five remaining anchors still exist (the
 * anchor key and flow kind still come from `ChatNodeSeat`, values `user` /
 * `steering`); only `data-time-hover-root` is gone, and nothing read it.
 *
 * @module dsh-rewind/client/portals
 */

import {
  useEffect,
  useLayoutEffect,
  useReducer,
  useRef,
  useState,
  createElement,
  type MouseEvent as ReactMouseEvent,
  type ReactNode,
} from 'react'
import { createPortal } from 'react-dom'
import { Tooltip } from '@deepseek-ai/dsh-client-ui-primitives'
import type { SessionFace } from '@deepseek-ai/dsh-api-session-controller/client'
import type { UserMessageNode } from '@deepseek-ai/dsh-client-ui-conversation/client'
import { ENGINE_COMMAND, hiddenSeqsOf, isExecutedRewindCommand, messageAttachmentsAt, messageTextAt, type ChatOf, type ChatWatch, type HiddenChat, type MessageImageRef } from './hidden.ts'
import type { RewindKey } from './locales.ts'
import { messagePreviewOf } from './candidates.ts'
import { knownCommandSeqs, openPopover, waitForCommand } from './popover.ts'
import { matchPendingRows, retractSpan, steeringItemsOf, type InboxLike, type PendingSteeringItem } from './pending.ts'
import { rewindLog } from './log.ts'
import { CLASS, REWIND_ICON_SVG } from './styles.ts'

type Translate = (key: RewindKey, params?: Record<string, unknown>) => string

/** One portal target: the actions row of a user/steering seat + its durable node. */
export type PortalTarget =
  | {
      readonly kind: 'durable'
      /** The seat's chat node key (React reconciliation + diff identity). */
      readonly key: string
      /** The row's actions container (React portal target). */
      readonly container: HTMLElement
      readonly seq: number
      readonly time: number
      readonly preview: string
    }
  | {
      readonly kind: 'pending'
      /** `pending:${itemId}` — stable per inbox occurrence. */
      readonly key: string
      /** The row's actions container (React portal target). */
      readonly container: HTMLElement
      /** The host inbox occurrence the retract button addresses. */
      readonly itemId: string
      /** Complete editable text; null when the message contains no text block. */
      readonly text: string | null
      readonly preview: string
    }

/** Capabilities the session-scoped bridge receives from the plugin apply(). */
export interface RewindBridgeDeps {
  readonly sessionOf: (sessionId: string) => SessionFace | undefined
  /**
   * Chat reader on the `uiConversation` "chat" view: every chat
   * snapshot read goes through it. See `chatSnapshotOf` in hidden.ts.
   */
  readonly chatOf: ChatOf
  /**
   * Subscribe to one session's live chat-update signal, so the composer refill
   * waiting on an executed rewind's chat node can be woken when the chat
   * snapshot changes. Passed through to `waitForCommand`.
   */
  readonly watchChat: ChatWatch
  /**
   * Whether a session is the one the MAIN VIEW currently retains — the alpha.2
   * replacement for the removed `SessionListState.current` (see
   * `isMainViewSession` in index.ts). A predicate rather than "the current
   * session id", so a multi-window client can never refill the wrong composer.
   */
  readonly isMainViewSession: (sessionId: string) => boolean
  readonly t: Translate
  readonly subscribeLocale: (cb: () => void) => () => void
  /**
   * Session-aware composer writer (see `writeComposer`): the
   * `conversation.input` facade `setDraft` when reachable, else the DOM fill.
   * Session-scoped so the refill only lands in the session that just rewound.
   */
  readonly setComposerText: (sessionId: string, text: string) => boolean
  /**
   * Session-aware image restorer (see `restoreImages` in index.ts): re-adds
   * a withdrawn message's durable image references to that session's
   * composer draft so a rewind of an image-bearing message does not lose
   * the pictures. Optional — absent degrades to the text-only refill.
   */
  readonly restoreImages?: (sessionId: string, images: readonly MessageImageRef[]) => Promise<void>
}

/** Structural face of the runtime slot service (see the module doc). */
export interface SlotsLike {
  inject(key: string, install: () => () => void): () => void
  /**
   * One slot registration. `Face` is the injected business face the renderer
   * decomposes (its `hooks` compartment is rebound as a `use<Name>` selector
   * hook); `Props` is the COMPOSED props a component receives — the slot's
   * runtime owner share, the locale seat, and that face — which is what the
   * component is typed against, never the face alone.
   */
  register<P, Face = P>(
    entry: {
      readonly name: string
      readonly id?: string
      readonly order?: number
      readonly key?: string
      readonly locale?: string
      readonly inject?: () => Face
    },
    component: (props: P) => ReactNode,
  ): () => void
}

/**
 * The session input facade's write face (structural, so the plugin
 * never imports the conversation UI package). `setDraft` replaces the whole
 * composer draft through the harness's own Lexical editor — the correct way
 * to restore the withdrawn text.
 */
interface ComposerDraftWriter {
  setDraft(text: string): void
  /**
   * Return the keyboard to the composer with the caret it last held (the
   * facade's own `focus`). Optional so the DOM fallback and older faces still
   * restore the text.
   */
  focus?(): void
}

/**
 * Write `text` into the Lexical `contenteditable` composer
 * (`[data-composer-input]`) through the native editing pipeline: set a
 * full-content selection, then `insertText`. That fires `beforeinput`, which
 * the harness's plain-text Lexical editor adopts into its model, exactly like
 * a user typing. Falls back to a direct text-node write when `execCommand` is
 * unavailable (non-Chromium only); best-effort. This is the DOM fallback of
 * the composer write (the primary channel is the `setDraft` facade).
 */
function fillComposerEditable(text: string): boolean {
  const editable = document.querySelector<HTMLElement>(COMPOSER_EDITABLE_SELECTOR)
  if (editable === null) return false
  editable.focus()
  const selection = document.getSelection()
  if (selection !== null) {
    const range = document.createRange()
    range.selectNodeContents(editable)
    selection.removeAllRanges()
    selection.addRange(range)
  }
  let ok = false
  try {
    ok = document.execCommand('insertText', false, text)
  } catch {
    ok = false
  }
  if (ok) return true
  editable.textContent = text
  editable.dispatchEvent(new Event('input', { bubbles: true }))
  return true
}

/**
 * Fill the dsh composer with `text` through the `contenteditable`
 * DOM path. Used by `setComposerText` (the harness-facade-aware writer) as the
 * last-resort and by `runRewindAndFill` to put the withdrawn target message
 * back into the composer after a rewind. Best-effort — no composer match means
 * false, never a throw.
 */
export function fillComposer(text: string): boolean {
  return fillComposerEditable(text)
}

/**
 * Composer write: prefer the harness facade's `setDraft` (correct whole-draft
 * replace), then degrade to the DOM `fillComposer` (contenteditable). A facade
 * that throws (session teardown) is treated as absent so the DOM path still
 * restores the text. Never throws.
 * @param text - the withdrawn target message text.
 * @param facade - the session input draft writer, when reachable.
 * @returns whether a channel applied the text.
 */
export function writeComposer(text: string, facade: ComposerDraftWriter | undefined): boolean {
  if (facade !== undefined) {
    try {
      facade.setDraft(text)
      try {
        // The confirm popover held the keyboard; give it back, caret included.
        facade.focus?.()
      } catch {
        // Focus is presentation; the restored draft is what matters.
      }
      return true
    } catch {
      // Fall through to the DOM channel (the facade must never kill the refill).
    }
  }
  return fillComposer(text)
}

/** The durable user/steering node behind a seat key via the runtime snapshot. */
function userNodeOf(chat: HiddenChat | undefined, key: string): UserMessageNode | undefined {
  const node = chat?.nodes.get(key)
  if (node === undefined || (node.kind !== 'user' && node.kind !== 'steering')) return undefined
  // SteeringMessageNode carries the same seq/time/content/source fields.
  return node.data as UserMessageNode
}

/**
 * Execute one rewind from the popover and, when it settles successfully,
 * put the withdrawn target message's text back into the composer so the
 * user can edit and re-send.
 *
 * THE COMPOSER FILL IS EVENT-DRIVEN: it runs only when THIS page performed
 * the rewind (the user clicked confirm moments ago). It must NEVER scan
 * loaded history for rewind commands: a session window opens with only
 * the tail page and grows via loadOlder, so a "command already in the
 * snapshot" cannot be told apart from "command executed in this page" —
 * the old baseline heuristic refilled withdrawn text into the composer
 * after switching sessions or restarting dsh.
 */
export async function runRewindAndFill(
  session: SessionFace,
  seq: number,
  mode: 'chat' | 'both',
  isMainViewSession: (sessionId: string) => boolean,
  chatOf: ChatOf,
  watchChat: ChatWatch,
  setComposerText: (sessionId: string, text: string) => boolean,
  restoreImages?: (sessionId: string, images: readonly MessageImageRef[]) => Promise<void>,
): Promise<void> {
  // Exclude already-present executed-rewind nodes for this target BEFORE
  // issuing the command: a repeated rewind of the same message must wait
  // for THIS command's node, not settle on the previous one.
  const known = knownCommandSeqs(session, chatOf, node => isExecutedRewindCommand(node, seq))
  let result: Awaited<ReturnType<SessionFace['command']>>
  try {
    result = await session.command(`/${ENGINE_COMMAND} @${seq} ${mode}`)
  } catch (error) {
    // A command/teardown throw must never become a silent unhandled rejection
    // on the `void runRewindAndFill(...)` call site.
    rewindLog.warn('refill', `rewind command threw, skipping refill @${seq}`, error)
    return
  }
  if (!result.ok) {
    // The Host rejected the call before any handler ran — e.g. a
    // subagent-owned identity (`session/agent-busy`, "use subagent delivery"),
    // or a command this Host does not have. Nothing was rewound: say so in the
    // console instead of failing silently (SiriLee/dsh-rewind#26).
    rewindLog.warn('refill', `rewind command rejected for @${seq}`, result.error)
    return
  }
  if (result.value?.matched !== true) {
    rewindLog.warn('refill', `rewind command was not matched for @${seq}`)
    return
  }
  // The executed rewind lands as a CommandNode with a marker-carrying
  // success outcome; wait for exactly that (longer than the preview RPC
  // timeout: a running turn is cancelled first, which can take seconds).
  let outcome: Awaited<ReturnType<typeof waitForCommand>>
  try {
    outcome = await waitForCommand(session, chatOf, node => isExecutedRewindCommand(node, seq) && !known.has(node.seq), 20_000, cb => watchChat(session.sessionId, cb))
  } catch (error) {
    rewindLog.warn('refill', `waiting for rewind @${seq} outcome threw`, error)
    return
  }
  if (outcome === null) {
    rewindLog.warn('refill', `rewind @${seq} never settled within timeout, no refill`)
    return
  }
  if (outcome.kind !== 'success') {
    // The host rejected the rewind (e.g. the target was shadowed by
    // compaction and is no longer in the model context). The refusal is the
    // correct behavior, but it must not fail silently — surface the host's
    // reason instead.
    showHint(outcome.text ?? 'rewind failed')
    return
  }
  // The user may have switched sessions while the rewind ran — fill only
  // the composer of the session the rewind actually happened in.
  if (!isMainViewSession(session.sessionId)) {
    return
  }
  let text: string | undefined
  let images: readonly MessageImageRef[] | undefined
  try {
    const chat = chatOf(session)
    text = messageTextAt(chat, seq)
    images = messageAttachmentsAt(chat, seq)
  } catch (error) {
    rewindLog.warn('refill', `reading target content for @${seq} threw`, error)
    return
  }
  // Restore the withdrawn message's images FIRST: adding draft attachments
  // never clobbers an in-progress draft, so this is NOT gated by the
  // empty-composer guard below. Best-effort — a restore failure leaves the
  // text refill intact (the image stays in the hidden history message).
  if (restoreImages !== undefined && images !== undefined && images.length > 0) {
    try {
      await restoreImages(session.sessionId, images)
    } catch (error) {
      rewindLog.warn('refill', `image restore for @${seq} threw`, error)
    }
  }
  if (text === undefined || text === '') {
    return
  }
  // Empty-composer guard (Claude Code parity, matches retractPending): never
  // clobber a draft the user is already editing.
  if (composerText().trim() !== '') {
    return
  }
  try {
    setComposerText(session.sessionId, text)
  } catch (error) {
    rewindLog.warn('refill', `composer refill @${seq} threw`, error)
    return
  }
}

/**
 * The composer's text-holding element: the Lexical `contenteditable`
 * div `[data-composer-input]` (the facade `setDraft` is preferred in
 * `writeComposer`; this DOM path is the fallback).
 */
function composerSurface(): HTMLElement | null {
  return document.querySelector<HTMLElement>(COMPOSER_EDITABLE_SELECTOR)
}

/** Transient status toast above the composer (rewind-failure notification). */
function showHint(text: string): void {
  const surface = composerSurface()
  const hint = document.createElement('div')
  hint.className = CLASS.guardHint
  hint.setAttribute('role', 'status')
  hint.textContent = text
  document.body.appendChild(hint)
  if (surface !== null) {
    const card = surface.closest('[data-composer-card]')
    const rect = card instanceof HTMLElement ? card.getBoundingClientRect() : surface.getBoundingClientRect()
    hint.style.left = `${Math.round(rect.left)}px`
    hint.style.bottom = `${Math.round(window.innerHeight - rect.top + 8)}px`
  }
  window.setTimeout(() => hint.remove(), 3200)
}

/**
 * The composer's text surface: the `contenteditable` div
 * (`[data-composer-input]` uses a Lexical editor). The refill writes to this
 * node via the `setDraft` facade when reachable, else the DOM fallback.
 */
const COMPOSER_EDITABLE_SELECTOR = '[data-composer-input]'

/** Both durable user messages and durable steering inputs render user-style rows. */
const USER_SEAT_SELECTOR = '[data-chat-flow-kind="user"][data-chat-anchor-key], [data-chat-flow-kind="steering"][data-chat-anchor-key]'

/** Every conversation seat row (hidden rows included). */
const CHAT_SEAT_SELECTOR = '[data-chat-anchor-key]'

/**
 * Subtrees whose mutations cannot change this bridge's target set in the
 * targeted DSH line: the composer, the right-hand sidebar, and the host's
 * plugin page. The chat snapshot subscription is the authoritative trigger,
 * so ignoring these costs no update — it only stops every keystroke and the
 * ignored panels' animations from scheduling a whole-transcript scan.
 */
const IGNORED_PORTAL_SCOPE = [
  '[data-composer-seat]',
  '[data-composer-input]',
  '[data-sidebar-right-panel]',
  '[data-sidebar-chat]',
  '[data-plugin-panel]',
].join(', ')

/**
 * A step/process GROUP shell. It wraps its member rows and carries the
 * composite `group:<json>` anchor, which resolves to no chat node — the group
 * is a view construct, not a message — so it has to be judged by its members.
 */
const GROUP_SHELL_SELECTOR = '[data-chat-anchor-key^="group:"]'

/**
 * The snapshot seq a rendered seat stands for.
 *
 * A seat carries two keys: `data-chat-anchor-key` (the FLOW key, which for a
 * step/process part is the composite `["<nodeKey>", "<part>"]`) and
 * `data-chat-node-key` (always the plain node key). Resolving only the flow key
 * made every grouped process row — the "正在分析/已完成分析" step rows, tool
 * groups — unresolvable, so a withdrawn one could never be hidden and stayed on
 * screen after a rewind. This mirrors the official viewport's own identity read
 * (`anchorKey === key || nodeKey === key`).
 *
 * @param element - one rendered seat.
 * @param chat - the live chat snapshot the seat belongs to.
 * @returns the node's `anchorSeq`, or undefined when the seat has no resolvable node.
 */
export function resolveSeatAnchorSeq(
  element: HTMLElement,
  chat: HiddenChat | undefined,
): number | undefined {
  if (chat === undefined) return undefined
  const flowKey = element.dataset.chatAnchorKey
  const nodeKey = element.dataset.chatNodeKey
  const node = (flowKey !== undefined ? chat.nodes.get(flowKey) : undefined)
    ?? (nodeKey !== undefined ? chat.nodes.get(nodeKey) : undefined)
  return node?.anchorSeq
}

/** Pending steering bubble rows (Host-authoritative pre-admission projection). */
const PENDING_SEAT_SELECTOR = '[data-pending-steering]'

/** The message-attachment block shared by user, steering and pending bubbles. */
const MESSAGE_ATTACHMENT_SELECTOR = '[data-message-attachments]'

/**
 * Locate the actions container of a user/steering seat row — the element the
 * ↶ button portals into (the copy/branch IconActions row).
 *
 * The finder is STRUCTURAL on purpose: `MessageIconActions` marks this container
 * with `data-clock`, which names clock placement rather than the action row (the
 * old `data-time-hover-root` marker lived on the per-turn tail footer and is
 * gone in 0.1.6-alpha.2), so the container is located as the direct holder of
 * the copy `<button>` (the `MessageIconActions` container, which mounts that
 * button as a direct child).
 *
 * Returns undefined when no qualifying container is found; the caller refuses
 * to portal (never a crash, never a wrong attachment). Exported as a test seam
 * (see `collectTargets`) so the row-shape finder is exercised directly for
 * both durable and pending row shapes without a full React portal render.
 */
export function actionsContainerOf(row: HTMLElement | undefined): HTMLElement | undefined {
  // The copy button's own container (see the note
  // above): located by the LAST action `<button>`, NOT the first `<button>` in
  // the row — a user message with an image renders its thumbnail as a
  // `<button>` (MessageImage's frame, ui-attachment) inside the media gallery,
  // which precedes the actions row in document order — `row.querySelector('button')`
  // would portal the ↶ button into the gallery (pinned at the image's
  // top-right). The action row always comes LAST, so take the parent of the
  // last button-bearing element, skipping this plugin's own portal button so a
  // refresh never re-targets itself.
  const buttons = Array.from(row?.querySelectorAll<HTMLButtonElement>('button') ?? [])
  const lastButton = buttons.filter(button => !button.classList.contains(CLASS.button)).at(-1)
  const structural = lastButton?.parentElement
  if (structural instanceof HTMLElement && structural.querySelector('button') !== null) return structural
  return undefined
}

/**
 * Hide every rendered seat a rewind withdrew, plus the step/process GROUP shells
 * those seats empty.
 *
 * A seat's seq comes from `resolveSeatAnchorSeq`: `data-chat-anchor-key` (the
 * FLOW key, composite for a step/process part) with `data-chat-node-key` (always
 * the plain node key) as the fallback. A group shell is different: it carries
 * the composite `group:<json>` anchor, which resolves to no chat node — the
 * group is a view construct, not a message. It is therefore judged by its
 * members, which THIS batch already holds: a shell whose every member seat is
 * withdrawn has no live content left, so it is hidden too. That is what stops a
 * fully withdrawn "analysis completed" / "command executed" group from staying
 * on screen as an expandable empty row. A shell keeps one live member only if
 * that member is genuinely on the surface, in which case the shell stays; a
 * shell the batch carries no member of is left alone.
 *
 * A MEMBER is a real chat node seat — `ChatNodeSeat` is the one shape that
 * writes `data-chat-node-key` beside the anchor key. An anchor-only descendant
 * (the tool call tree's own `call:<callId>` row, or a third-party anchor) is
 * nested decoration: it resolves to no chat node, so it does NOT vote on the
 * shell's emptiness. Counting such a row as "still live" is what left a fully
 * withdrawn "command executed" tool group on screen as an empty expandable row
 * after every member below it had been hidden.
 *
 * Every hidden element carries `data-dsh-rewind-hidden` (see
 * `docs/contract/client-contract.md`).
 *
 * @param chat - the live chat snapshot the seats belong to.
 * @param seats - this refresh's seat batch (every `[data-chat-anchor-key]`).
 * @param hiddenSeqs - anchor seqs withdrawn by the executed rewinds.
 * @param hidden - elements this pass has hidden, so a re-created row is re-judged.
 */
export function hideWithdrawnSeats(
  chat: HiddenChat | undefined,
  seats: Iterable<HTMLElement>,
  hiddenSeqs: ReadonlySet<number>,
  hidden: Set<HTMLElement>,
): void {
  if (chat === undefined) return
  // Shell → "every member in this batch was withdrawn". A shell is only judged
  // through members the batch actually carries: an unobserved shell is left
  // alone, because hiding it could take live content off screen.
  const shells = new Map<HTMLElement, boolean>()
  for (const seat of seats) {
    // A group shell is ITSELF matched by the seat selector (it carries
    // `data-chat-anchor-key="group:<json>"`), but that composite key resolves to
    // no chat node. Running the seat branches on it made the two passes fight
    // over one element: the seat pass un-hid the shell the shell pass had just
    // hidden, which mutated `style` on every pass and kept the observer
    // re-entering refresh as a microtask — an unbounded microtask loop. Shells
    // are owned by the shell pass below only; members still feed its decision.
    if (seat.matches(GROUP_SHELL_SELECTOR)) continue
    const anchor = resolveSeatAnchorSeq(seat, chat)
    const withdrawn = anchor !== undefined && hiddenSeqs.has(anchor)
    if (withdrawn) {
      seat.style.display = 'none'
      seat.dataset.dshRewindHidden = 'true'
      hidden.add(seat)
    } else if (hidden.has(seat)) {
      seat.style.display = ''
      delete seat.dataset.dshRewindHidden
      hidden.delete(seat)
    }
    if (seat.dataset.chatNodeKey === undefined) continue
    const shell = seat.parentElement?.closest<HTMLElement>(GROUP_SHELL_SELECTOR)
    if (shell === null || shell === undefined) continue
    shells.set(shell, (shells.get(shell) ?? true) && withdrawn)
  }
  for (const [shell, allWithdrawn] of shells) {
    // Symmetric with the seat branches: the shell pass owns the shell, so it is
    // also the one that shows it again when it regains a live member.
    if (allWithdrawn) {
      shell.style.display = 'none'
      shell.dataset.dshRewindHidden = 'true'
      hidden.add(shell)
    } else if (hidden.has(shell)) {
      shell.style.display = ''
      delete shell.dataset.dshRewindHidden
      hidden.delete(shell)
    }
  }
}

/**
 * Undo every hide the given set recorded, so a live disable (or a session-slot
 * collapse) cannot leave the transcript truncated.
 *
 * The hide is the plugin's OWN mutation of host rows ({@link hideWithdrawnSeats}),
 * and nothing else would ever revert it: a disposed bridge runs no further
 * refresh, so rows it hid would stay hidden with no affordance to bring them
 * back.
 *
 * @param hidden - the elements this bridge currently hides; emptied.
 */
export function showHiddenSeats(hidden: Set<HTMLElement>): void {
  for (const element of hidden) {
    element.style.display = ''
    delete element.dataset.dshRewindHidden
  }
  hidden.clear()
}

/**
 * Collect the portal targets of one session: user rows × snapshot nodes.
 * Exported as a test seam — the DOM→targets pairing that drives the ↶ button
 * is otherwise only reachable through a full React portal render.
 */
export function collectTargets(chat: HiddenChat, hiddenSeqs: ReadonlySet<number>): readonly PortalTarget[] {
  const rows = new Map<string, HTMLElement>()
  for (const element of document.querySelectorAll<HTMLElement>(USER_SEAT_SELECTOR)) {
    const key = element.dataset.chatAnchorKey
    if (key !== undefined) rows.set(key, element)
  }
  const targets: PortalTarget[] = []
  for (const key of chat.order) {
    const node = chat.nodes.get(key)
    if (node === undefined || (node.kind !== 'user' && node.kind !== 'steering')) continue
    const user = node.data as UserMessageNode
    // A withdrawn row must not get a button (it is not part of the surface).
    if (hiddenSeqs.has(node.anchorSeq ?? user.seq)) continue
    const row = rows.get(key)
    const actions = actionsContainerOf(row)
    // The actions row is the last child of the user row and holds the
    // copy/branch IconActions; refuse to portal when the DOM does not match
    // (a layout change must not break the conversation).
    if (actions === undefined) continue
    targets.push({ kind: 'durable', key, container: actions, seq: user.seq, time: user.time, preview: messagePreviewOf(user) })
  }
  return targets
}

/**
 * The session-kind slice the durable-target gate reads — the session
 * snapshot's `subagent` cell, the Harness's own runtime signal for a
 * direct-subagent (child) session. Typed structurally so the plugin never
 * imports the session-controller snapshot contract.
 */
export interface SessionKindLike {
  /** Non-null exactly while this Session is addressed as a subagent child. */
  readonly subagent: unknown
}

/**
 * Whether a session is rewind-inert: a direct-subagent (child) session.
 *
 * The Harness refuses every generic Session RPC for a subagent-owned identity
 * (`session/agent-busy`, "use subagent delivery for this child session"), so
 * `/rewind` can never execute there — the command's own admission is the
 * refusal, before any handler runs. A wired-up ↶ button in such a session is
 * therefore dead UI that closes its popover and does nothing
 * (SiriLee/dsh-rewind#26). This mirrors the Harness's own slash-command
 * directory (which returns no commands for an addressed child), the pending
 * path's `collectPendingTargets` gate, and the Host's `isSubagentSession`
 * skips: a child session gets no rewind surface and records no snapshot.
 */
export function isRewindInertSession(snapshot: SessionKindLike): boolean {
  return snapshot.subagent !== null && snapshot.subagent !== undefined
}

/**
 * Collect the durable (sent-message) rewind targets of one session: none at all
 * for a rewind-inert subagent session, otherwise `collectTargets`' DOM→target
 * pairing. Kept separate from `collectTargets` so the session-kind gate is a
 * pure, directly testable decision.
 * @param snapshot - the session snapshot carrying the `subagent` cell.
 * @param chat - the session's chat snapshot, or undefined while unavailable.
 * @param hiddenSeqs - anchor seqs withdrawn by previous rewinds.
 */
export function collectDurableTargets(
  snapshot: SessionKindLike,
  chat: HiddenChat | undefined,
  hiddenSeqs: ReadonlySet<number>,
): readonly PortalTarget[] {
  if (chat === undefined || isRewindInertSession(snapshot)) return []
  return collectTargets(chat, hiddenSeqs)
}

/**
 * The session's `inbox` projection value — the agent's pending input, folded by
 * the session scope. `undefined` before the fold state exists (a session with no
 * agent-loop has no `inbox` key), which every reader treats as "no pending rows".
 *
 * DSH 0.1.6-alpha.2 removed the `SessionSnapshot.queue` mirror this module used
 * to read; the projection is the surviving host-owned source of the same rows.
 * The face's value is typed `unknown` on purpose (projection values are wire
 * data), so it is narrowed structurally here.
 */
function inboxOf(session: SessionFace): InboxLike | undefined {
  return session.projections.faceOf(INBOX_PROJECTION).getSnapshot() as InboxLike | undefined
}

/** The projection key the pending-target read and its subscription address. */
const INBOX_PROJECTION = 'inbox'

/**
 * The pending bubble row's compared text and its message-attachment block
 * count, read from a CLONE (the live row is never touched).
 *
 * Both the actions container and the message-attachment block are excluded from
 * the text: the copy button's Tooltip mounts its label inside that button, and
 * the attachment block renders text of its own (a file name/size, a lone
 * image's loading label) that no inbox row reproduces. The block is counted
 * instead, as the attachment half of the match key (`matchPendingRows`).
 *
 * The clone's counterpart is taken by query position, not by position among the
 * row's children: the harness renders the attachment block BEFORE the message
 * bubble, so "drop the first child" would drop the message text.
 *
 * @param row - one rendered `[data-pending-steering]` row.
 * @returns the compared text and the attachment block count.
 */
export function bubbleTextOf(row: HTMLElement): { readonly text: string; readonly attachments: number } {
  const clone = row.cloneNode(true) as HTMLElement
  // Drop the actions container: the copy button's Tooltip mounts its label
  // inside that button, so the row's text flips with the mouse. A future
  // harness structure change leaves extra text and the match then degrades to
  // no button — never to a wrong one.
  clone.lastElementChild?.remove()
  // Drop the message-attachment block for the same reason (a file name, an
  // image's loading label) and count it instead. Query position identifies the
  // clone's copies; the harness renders this block BEFORE the message bubble,
  // so "drop the first child" would drop the message text.
  const originals = row.querySelectorAll(MESSAGE_ATTACHMENT_SELECTOR)
  const copies = clone.querySelectorAll(MESSAGE_ATTACHMENT_SELECTOR)
  for (let index = 0; index < copies.length; index++) copies[index]?.remove()
  return { text: clone.textContent ?? '', attachments: originals.length }
}

/**
 * Collect the portal targets of one session's pending steering bubbles. The
 * retract button is the pre-sent window's counterpart of the durable rewind
 * button: it exists whenever the Host holds the message in its next-step
 * inbox (running or paused), and it retracts through the session's own
 * `updateQueue` channel — no DSH behavior changes, and no stop: an unclaimed
 * next-step message has never reached a request (see `retractPending`).
 * @param snapshot - the session snapshot slice carrying the `subagent` cell.
 * @param steering - the session's `next-step` inbox rows (see `steeringItemsOf`).
 */
function collectPendingTargets(snapshot: SessionKindLike, steering: readonly PendingSteeringItem[]): readonly PortalTarget[] {
  // Subagent sessions reject queue mutations host-side. The harness's own
  // QueueDock gate is wider (`subagent === null || address.mode === 'continuable'`),
  // but a subagent session is never a rewind target, so null is the right face.
  if (snapshot.subagent !== null) return []
  if (steering.length === 0) return []
  const rows = Array.from(document.querySelectorAll<HTMLElement>(PENDING_SEAT_SELECTOR))
  const matched = matchPendingRows(rows.map(bubbleTextOf), steering)
  const targets: PortalTarget[] = []
  for (let i = 0; i < matched.length; i++) {
    const itemId = matched[i]!
    if (itemId === null) continue
    const row = rows[i]
    if (row === undefined) continue
    // Unlike durable rows, the pending bubble row IS the hover/actions root
    // (no outer seat wrapper); its actions row is the last child and holds the
    // copy IconAction — refuse to portal when the DOM does not match. The same
    // structural finder is reused.
    const actions = actionsContainerOf(row)
    if (actions === undefined) continue
    const item = steering[i]!
    targets.push({
      kind: 'pending',
      key: `pending:${itemId}`,
      container: actions,
      itemId,
      text: item.text,
      preview: item.preview,
    })
  }
  return targets
}

/** Whether two target lists describe the same portals (order-sensitive). */
function sameTargets(left: readonly PortalTarget[], right: readonly PortalTarget[]): boolean {
  return left.length === right.length && left.every((target, index) => {
    const other = right[index]
    if (other === undefined || target.key !== other.key || target.container !== other.container) return false
    if (target.kind === 'durable') return other.kind === 'durable' && target.seq === other.seq
    return other.kind === 'pending' && target.itemId === other.itemId
  })
}

interface RewindPortalsProps extends RewindBridgeDeps {
  readonly sessionId: string
}

/**
 * Session-scoped portal bridge: renders the ↶ button of every user message
 * row of the session the harness mounts it for. The refresh is coalesced
 * (one pass per microtask window via queueMicrotask) and diffed (setState is
 * skipped when the target set is unchanged), so the plugin never runs a
 * synchronous full-transcript scan inside a commit microtask.
 *
 * The refresh is driven by the three inputs its targets are made of: the chat
 * snapshot (`hiddenSeqsOf`), the session's `inbox` projection (the pending
 * occurrences — see `syncInboxSubscription`), and the DOM (row/actions mounts,
 * via the scoped observer).
 */
export function RewindPortals({ sessionId, sessionOf, chatOf, isMainViewSession, watchChat, t, subscribeLocale, setComposerText, restoreImages }: RewindPortalsProps): ReactNode {
  const [targets, setTargets] = useState<readonly PortalTarget[]>([])
  // Rows this bridge has hidden; re-shown when they leave the withdrawn span.
  // A strong set (not a WeakSet) so the unmount can restore exactly what THIS
  // bridge hid — the `refresh` prunes detached nodes, so a long session cannot
  // retain the rows React has already discarded.
  const hidden = useRef(new Set<HTMLElement>())
  // Re-render when the active locale switches so injected button labels
  // keep following the dsh language preference (the popover and guard hint
  // are created fresh each time and already read the current locale).
  const [, forceRender] = useReducer((count: number) => count + 1, 0)
  useEffect(() => subscribeLocale(() => { forceRender() }), [subscribeLocale])

  useLayoutEffect(() => {
    let active = true
    let queued = false
    // The pending path's out-of-DOM data channel (`syncInboxSubscription`).
    let unsubscribeInbox: (() => void) | undefined
    let inboxOwner: SessionFace | undefined

    const refresh = (): void => {
      if (!active) return
      const session = sessionOf(sessionId)
      syncInboxSubscription(session)
      if (session === undefined) {
        // Session binding gone (teardown window): drop every portal.
        setTargets([])
        return
      }
      const snapshot = session.getSnapshot()
      // `chatOf` serves the `uiConversation` "chat" view; undefined
      // = no view registered yet: skip the durable path entirely (pending
      // targets stay collectible).
      const chat = chatOf(session)
      const hiddenSeqs = chat === undefined ? new Set<number>() : hiddenSeqsOf(chat)
      // Hide withdrawn rows (rewind markers, engine command rows, and every
      // message inside any executed rewind's [target, marker] span — the spans
      // stay separate, never one collapsed range) so the rendered transcript
      // matches the agent's context. React re-renders recreate rows, so this
      // runs on every refresh.
      //
      // Each hidden row also carries a semantic marker (`data-dsh-rewind-hidden`)
      // so DevTools, other DOM plugins and tests can tell a rewind-hide apart
      // from any collapse/filter hide. Purely observational: the marker is
      // kept in sync with the hide/show state on both branches (a recreated
      // row has no marker and is re-marked when it re-enters a hidden span).
      // Apply the hide to this batch's seats (and the group shells they empty):
      // `document.querySelectorAll(CHAT_SEAT_SELECTOR)` is the batch, re-read on
      // every refresh because React recreates rows.
      // The set is strong so the unmount can restore what this bridge hid: drop
      // the rows React has already discarded first, so it stays bounded to the
      // live transcript.
      for (const element of hidden.current) if (!element.isConnected) hidden.current.delete(element)
      // Nothing to withdraw and nothing this bridge already hid means the pass
      // would walk every row and change nothing: skip the whole-transcript
      // `querySelectorAll` that each refresh otherwise paid.
      if (hiddenSeqs.size > 0 || hidden.current.size > 0) {
        hideWithdrawnSeats(
          chat,
          chat === undefined ? [] : document.querySelectorAll<HTMLElement>(CHAT_SEAT_SELECTOR),
          hiddenSeqs,
          hidden.current,
        )
      }
      // Nothing is logged in this per-batch scan: printing a hide set here would
      // flood the console during streaming.
      const durable = collectDurableTargets(snapshot, chat, hiddenSeqs)
      const next = [...durable, ...collectPendingTargets(snapshot, steeringItemsOf(inboxOf(session)?.['next-step']))]
      // Diff: no change → no re-render. A refresh can run several times for one
      // target set (chat publication, inbox, DOM catch-up); only an actual
      // target-set change should touch React.
      setTargets(current => (sameTargets(current, next) ? current : next))
    }

    // Coalesce: any number of triggers in a batch collapse into ONE refresh
    // (microtask), instead of one synchronous full scan per trigger — this
    // is what keeps the plugin off the critical path of the frame that paints
    // a newly sent bubble.
    const queueRefresh = (): void => {
      if (queued || !active) return
      queued = true
      queueMicrotask(() => {
        queued = false
        refresh()
      })
    }

    /**
     * (Re)bind the inbox-projection subscription to the session being read. The
     * pending target cannot come from the DOM alone: the bubble is the harness's
     * local submission echo, which keeps rendering unchanged when the Host
     * occurrence lands (ChatView merges it by `rpcId`; the QueueDock only mirrors
     * `next-turn`), so that frame mutates nothing and a mutation-only refresh
     * would not mount the ↶ button until some later mutation re-ran the scan.
     *
     * The face is identity-stable per key, so tracking the session is enough to
     * notice a re-bind. A face that refuses subscription only costs this channel;
     * the DOM observer stays the catch-up one.
     */
    const syncInboxSubscription = (session: SessionFace | undefined): void => {
      if (session === inboxOwner) return
      unsubscribeInbox?.()
      unsubscribeInbox = undefined
      inboxOwner = session
      if (session === undefined) return
      try {
        unsubscribeInbox = session.projections.faceOf(INBOX_PROJECTION).subscribe(queueRefresh)
      } catch (error) {
        rewindLog.warn('portals', 'inbox projection subscribe failed', error)
      }
    }

    refresh()
    // The chat snapshot is the authority on what changed; the observer only
    // catches a host re-render of a row that arrives without one (virtual
    // scroll window, a reset `display`). Watching the whole body made every
    // composer keystroke and every sidebar animation schedule a scan.
    const unsubscribeChat = watchChat(sessionId, queueRefresh)
    const observer = new MutationObserver(records => {
      for (const record of records) {
        if (record.type === 'attributes') {
          // Only a row this bridge hid can need re-hiding. Any other restyle —
          // the composer's height variables, a sidebar resize, a third-party
          // panel — cannot change the target set.
          const target = record.target
          if (target instanceof HTMLElement && hidden.current.has(target) && target.style.display !== 'none') {
            queueRefresh()
            return
          }
          continue
        }
        const node = record.target instanceof Element ? record.target : record.target.parentElement
        if (node !== null && node.closest(IGNORED_PORTAL_SCOPE) !== null) continue
        queueRefresh()
        return
      }
    })
    // attributes: watch style so a harness re-render that resets display is
    // re-hidden on the next refresh instead of flickering back.
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] })
    return () => {
      active = false
      observer.disconnect()
      unsubscribeChat()
      // The hides are this bridge's own mutation of host rows: undo them, or a
      // live disable leaves the transcript truncated for good.
      showHiddenSeats(hidden.current)
      unsubscribeInbox?.()
      unsubscribeInbox = undefined
      inboxOwner = undefined
    }
  }, [sessionId, sessionOf, watchChat])

  return targets.map(target => createPortal(
    target.kind === 'pending'
      ? (
        <RetractButton
          key={target.key}
          target={target}
          sessionId={sessionId}
          sessionOf={sessionOf}
          setComposerText={setComposerText}
          t={t}
        />
      )
      : (
        <RewindButton
          key={target.key}
          target={target}
          sessionId={sessionId}
          sessionOf={sessionOf}
          chatOf={chatOf}
          watchChat={watchChat}
          isMainViewSession={isMainViewSession}
          setComposerText={setComposerText}
          restoreImages={restoreImages}
          t={t}
        />
      ),
    target.container,
    target.key,
  ))
}

interface RewindButtonProps {
  readonly target: Extract<PortalTarget, { kind: 'durable' }>
  readonly sessionId: string
  readonly sessionOf: (sessionId: string) => SessionFace | undefined
  readonly chatOf: ChatOf
  readonly watchChat: ChatWatch
  readonly isMainViewSession: (sessionId: string) => boolean
  readonly setComposerText: (sessionId: string, text: string) => boolean
  readonly restoreImages?: (sessionId: string, images: readonly MessageImageRef[]) => Promise<void>
  readonly t: Translate
}

/** The per-message ↶ button (28px, matching the harness IconActions). */
function RewindButton({ target, sessionId, sessionOf, chatOf, watchChat, isMainViewSession, setComposerText, restoreImages, t }: RewindButtonProps): ReactNode {
  const onClick = (event: ReactMouseEvent<HTMLButtonElement>): void => {
    event.stopPropagation()
    const session = sessionOf(sessionId)
    if (session === undefined) {
      // No session binding (transition): nothing to rewind, say so instead
      // of failing silently.
      rewindLog.warn('portals', 'rewind button clicked with no session binding')
      return
    }
    const node = userNodeOf(chatOf(session), target.key)
    if (node === undefined) return
    openPopover({
      session,
      seq: node.seq,
      time: node.time,
      preview: messagePreviewOf(node),
      anchor: event.currentTarget,
      t,
      onRewind: mode => { void runRewindAndFill(session, node.seq, mode, isMainViewSession, chatOf, watchChat, setComposerText, restoreImages) },
    })
  }

  return (
    <Tooltip label={t('button.title')} side="bottom">
      <button
        type="button"
        className={CLASS.button}
        aria-label={t('button.aria')}
        aria-haspopup="dialog"
        onClick={onClick}
        dangerouslySetInnerHTML={{ __html: REWIND_ICON_SVG }}
      />
    </Tooltip>
  )
}

/** The current composer draft: the contenteditable `textContent`.
 * Empty when the composer is absent. Exported as a test seam (the
 * empty-composer guard in `retractPending`). */
export function composerText(): string {
  const surface = composerSurface()
  if (surface === null) return ''
  return surface.textContent ?? ''
}

/**
 * Withdraw one pre-sent (pending steering) message and every steering message
 * after it (the rollback point's "future"), WITHOUT interrupting the run.
 *
 * The message is still in the agent's next-step inbox, so the loop has not
 * claimed it into any request: removing it cannot change what the model is
 * generating. Stopping the run first (the durable-rewind rule) would throw
 * away in-flight work — a long tool call, a partial answer — for an edit the
 * model can never observe (SiriLee/dsh-rewind#27). Only the durable rewind
 * needs a stop, because it cuts the model-visible surface.
 *
 * 1. Remove the target and its future (steering only; queued stays) through
 *    the session's own `updateQueue` channel, oldest first.
 * 2. Put the target's text back in the composer ONLY when the target was
 *    actually removed and the composer is empty (Claude Code's auto-restore
 *    guard, so a draft the user is typing is never clobbered).
 *
 * The realistic failure is `queue-item-not-found`: a step boundary claimed
 * the whole next-step batch a moment ago, so the message is now durable and
 * the durable row's regular rewind button takes over with no gap. Nothing is
 * removed then, and the composer is NOT refilled — refilling would invite a
 * duplicate send of a message the model has already received.
 */
export async function retractPending(
  session: SessionFace,
  itemId: string,
  text: string | null,
  setComposerText: (sessionId: string, text: string) => boolean,
): Promise<void> {
  // The item id comes from the inbox occurrence, which the harness brands as
  // MessageId; cast at this single boundary to avoid a new type dependency on
  // the branding package.
  const steering = steeringItemsOf(inboxOf(session)?.['next-step'])
  let removedTarget = false
  for (const id of retractSpan(steering, itemId)) {
    let accepted = false
    try {
      // Carrier failures resolve as `{ok:false}` (the RemoteResult contract);
      // only an assembly fault on an unmounted scope still rejects. That reject
      // must not become an unhandled rejection on the `void retractPending(...)`
      // call site.
      const result = await session.updateQueue(id as Parameters<SessionFace['updateQueue']>[0], { kind: 'remove' })
      accepted = result.ok
      // A lost race is expected, not an anomaly: the message is durable now.
      if (!result.ok) rewindLog.info('retract', `pending retract lost the race for ${id}`, result.error)
    } catch (error) {
      rewindLog.warn('retract', `pending retract remove threw for ${id}`, error)
    }
    // retractSpan is oldest-first, so the first failure means the remaining
    // batch was claimed together: a follow-up removal would only be futile.
    if (!accepted) break
    if (id === itemId) removedTarget = true
  }
  // Refill only on a confirmed removal (see the failure note above).
  if (removedTarget && text !== null && text !== '' && composerText().trim() === '') {
    setComposerText(session.sessionId, text)
  }
}

interface RetractButtonProps {
  readonly target: Extract<PortalTarget, { kind: 'pending' }>
  readonly sessionId: string
  readonly sessionOf: (sessionId: string) => SessionFace | undefined
  readonly setComposerText: (sessionId: string, text: string) => boolean
  readonly t: Translate
}

/** The per-pending-message ↶ button (same visual family as the durable button). */
function RetractButton({ target, sessionId, sessionOf, setComposerText, t }: RetractButtonProps): ReactNode {
  const onClick = (event: ReactMouseEvent<HTMLButtonElement>): void => {
    event.stopPropagation()
    const session = sessionOf(sessionId)
    if (session === undefined) return
    openPopover({
      session,
      preview: target.preview,
      anchor: event.currentTarget,
      t,
      retract: { itemId: target.itemId, text: target.text },
      onRetract: () => { void retractPending(session, target.itemId, target.text, setComposerText) },
    })
  }

  return (
    <Tooltip label={t('button.retract.title')} side="bottom">
      <button
        type="button"
        className={CLASS.button}
        aria-label={t('button.retract.aria')}
        aria-haspopup="dialog"
        onClick={onClick}
        dangerouslySetInnerHTML={{ __html: REWIND_ICON_SVG }}
      />
    </Tooltip>
  )
}

/**
 * Build the slot-entry component for the plugin apply(): a tiny bridge that
 * injects the apply-time capabilities (session resolution, locale, rewind
 * runner) into the module-level `RewindPortals`.
 */
export function createRewindBridge(deps: RewindBridgeDeps): (props: { readonly sessionId: string }) => ReactNode {
  return function RewindBridge({ sessionId }): ReactNode {
    return createElement(RewindPortals, { sessionId, ...deps })
  }
}
