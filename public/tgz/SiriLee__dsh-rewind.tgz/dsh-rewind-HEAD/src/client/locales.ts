/** `rewind` namespace dictionaries for the client plugin. */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'button.aria': '回退到此消息',
  'button.title': '回退',
  'button.retract.aria': '回退到此插话消息',
  'button.retract.title': '回退',
  'popover.title': '回退到这条消息',
  'popover.noText': '（无文本）',
  'popover.retract.title': '回退到这条插话消息',
  'popover.retract.target': '插话中 · {preview}',
  'popover.retract.hint': '撤回这条及之后的插话消息，不打断当前生成',
  'popover.retract.confirm': '确认回退',
  'popover.chat': '仅回退对话',
  'popover.chat.hint': '只回退模型上下文，不动工作区文件',
  'popover.both': '回退对话和代码',
  'popover.both.hint': '对话回退并还原工作区文件',
  'popover.checking': '正在检查文件变更…',
  'popover.noChanges': '此消息之后没有可还原的文件变更，仅可回退对话',
  'popover.cancel': '取消',
  'popover.impact.loading': '正在获取影响清单…',
  'popover.impact.failed': '无法获取影响清单：{message}',
  'popover.impact.none': '目标之后没有跟踪到的写类变更，无需还原文件。',
  'popover.impact.restore': '还原 {path}',
  'popover.impact.delete': '删除 {path}',
  'popover.confirm': '确认回退',
  'popover.back': '返回',
  'cleanup.auto': '自动清理',
  'cleanup.auto.on': '开启后按不活跃天数自动清理过期会话快照',
  'cleanup.auto.off': '关闭后保留全部快照，不自动清理',
  'cleanup.maxAge': '不活跃时间（天）',
  'cleanup.maxAge.hint': '超过该天数未活动的会话快照会被清理',
  'cleanup.invalid': '请填正整数；留空表示使用默认值',
  'cleanup.overridden': '已覆盖',
  'cleanup.reset': '恢复默认',
  'cleanup.save': '保存',
  'cleanup.saving': '保存中…',
  'cleanup.saveFailed': '本部署没有接受这些值，已保留供你修改',
  'cleanup.readonly': '本部署的设置为只读',
  'cleanup.unavailable': '该插件当前未加载，暂时无法配置',
} satisfies Record<string, string>

/** The rewind namespace key union. */
export type RewindKey = keyof typeof zh

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The in-place rewind controls' copy. */
    rewind: RewindKey
  }
}

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'button.aria': 'Rewind to this message',
  'button.title': 'Rewind',
  'button.retract.aria': 'Rewind to this pending message',
  'button.retract.title': 'Rewind',
  'popover.title': 'Rewind to this message',
  'popover.noText': '(no text)',
  'popover.retract.title': 'Rewind to this pending message',
  'popover.retract.target': 'Pending · {preview}',
  'popover.retract.hint': 'Retracts this pending message and the ones after it, without interrupting the run',
  'popover.retract.confirm': 'Confirm rewind',
  'popover.chat': 'Rewind conversation only',
  'popover.chat.hint': 'Cut the model context only; workspace files stay untouched',
  'popover.both': 'Rewind conversation and code',
  'popover.both.hint': 'Cut the context and restore workspace files',
  'popover.checking': 'Checking for file changes…',
  'popover.noChanges': 'No tracked file changes after this message; conversation-only rewind',
  'popover.cancel': 'Cancel',
  'popover.impact.loading': 'Fetching impact list…',
  'popover.impact.failed': 'Could not fetch the impact list: {message}',
  'popover.impact.none': 'No tracked file changes after the target; nothing to restore.',
  'popover.impact.restore': 'Restore {path}',
  'popover.impact.delete': 'Delete {path}',
  'popover.confirm': 'Confirm rewind',
  'popover.back': 'Back',
  'cleanup.auto': 'Auto cleanup',
  'cleanup.auto.on': 'When enabled, session snapshots idle past the cutoff are cleaned automatically',
  'cleanup.auto.off': 'When disabled, all snapshot backups are kept; nothing is cleaned automatically.',
  'cleanup.maxAge': 'Idle time (days)',
  'cleanup.maxAge.hint': 'Snapshot backups of sessions idle longer than this many days are cleaned',
  'cleanup.invalid': 'Enter a positive integer, or leave blank to use the default',
  'cleanup.overridden': 'Overridden',
  'cleanup.reset': 'Reset to default',
  'cleanup.save': 'Save',
  'cleanup.saving': 'Saving…',
  'cleanup.saveFailed': 'The deployment did not accept these values; they were left for you to correct',
  'cleanup.readonly': 'This deployment stores settings read-only',
  'cleanup.unavailable': 'This plugin is not loaded, so it cannot be configured right now',
} satisfies Record<RewindKey, string>
