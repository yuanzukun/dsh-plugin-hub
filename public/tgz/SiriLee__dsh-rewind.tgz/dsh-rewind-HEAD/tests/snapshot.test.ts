/**
 * Unit tests for the checkpoint store (src/snapshot.ts): disk-backed
 * before-backups grouped by anchor message seq, with real files under a
 * temporary directory — exactly the production restore path.
 */
import { mkdtemp, mkdir, readdir, rm, writeFile, readFile, utimes, symlink } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, isAbsolute, join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { reconcileTracked, SnapshotStore, isLinkEntry, defaultProbe, type ByteSource, type DiskProbe } from '../src/snapshot.ts'

let root: string
let store: SnapshotStore
const session = 'session-test'

const unlink = async (path: string): Promise<void> => {
  await rm(path, { force: true })
}

beforeEach(async () => {
  root = await mkdtemp(join(tmpdir(), 'dsh-rewind-snap-'))
  store = new SnapshotStore(root)
})

afterEach(async () => {
  await rm(root, { recursive: true, force: true })
})

async function touch(rel: string, content: string): Promise<string> {
  const abs = join(root, 'ws', rel)
  await mkdir(dirname(abs), { recursive: true })
  await writeFile(abs, content, 'utf8')
  return abs
}

describe('SnapshotStore', () => {
  it('restores a modified file to its pre-edit content', async () => {
    const file = await touch('a.txt', 'original')
    // Turn anchored at seq 5 edits a.txt; the before-capture is 'original'.
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    await writeFile(file, 'rewritten', 'utf8')

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(outcome.deleted).toEqual([])
    expect(outcome.failed).toEqual([])
    expect(await readFile(file, 'utf8')).toBe('original')
  })

  it('deletes files created at or after the target', async () => {
    const keep = await touch('keep.txt', 'x')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: keep, before: 'x' })
    const created = await touch('new.txt', 'n')
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: created, before: null })

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.deleted).toEqual([created])
    expect(await store.exists(created)).toBe(false)
    expect(await store.exists(keep)).toBe(true)
  })

  it('restores files deleted after the target (before-capture survives)', async () => {
    const file = await touch('gone.txt', 'content')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'content' })
    await rm(file, { force: true })

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('content')
  })

  it('applies the EARLIEST entry per file across multiple edits', async () => {
    const file = await touch('multi.txt', 'v1')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'v1' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: 'v2' })
    await store.recordEntry(session, { callId: 'c3', anchorSeq: 6, path: file, before: 'v3' })
    await writeFile(file, 'v4', 'utf8')

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('v1')
  })

  it('respects the anchor boundary: only entries at/after the target apply', async () => {
    const f1 = await touch('f1.txt', 'a')
    const f2 = await touch('f2.txt', 'b')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: f1, before: 'a' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 7, path: f2, before: 'b' })
    await writeFile(f1, 'a2', 'utf8')
    await writeFile(f2, 'b2', 'utf8')

    const outcome7 = await store.restoreAfter(session, 7, unlink)
    expect(outcome7.restored).toEqual([f2])
    expect(await readFile(f1, 'utf8')).toBe('a2') // untouched by a rewind to 7
    expect(await readFile(f2, 'utf8')).toBe('b')
  })

  it('previews impacts without mutating anything', async () => {
    const file = await touch('p.txt', 'a')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'a' })
    const created = await touch('q.txt', 'b')
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: created, before: null })
    // The file is edited after the backup so the preview sees a real diff
    // (identical content would reconcile to NO impact).
    await writeFile(file, 'changed', 'utf8')

    const impacts = await store.impactsAfter(session, 5)
    expect(impacts).toEqual([
      { path: file, action: 'restore' },
      { path: created, action: 'delete' },
    ])
    expect(await readFile(file, 'utf8')).toBe('changed') // preview never mutates
    expect(await readFile(created, 'utf8')).toBe('b')
  })

  it('prunes the oldest anchor groups beyond the keep bound', async () => {
    const file = await touch('k.txt', '0')
    for (let seq = 1; seq <= 5; seq++) {
      await store.recordEntry(session, { callId: `c${seq}`, anchorSeq: seq, path: file, before: '0' })
    }
    await store.prune(session, 2)
    expect(await store.entriesAfter(session, 1)).toHaveLength(2) // 1..3 pruned, 4..5 kept
    expect(await store.entriesAfter(session, 4)).toHaveLength(2) // 4..5 kept
  })

  it('survives a store re-instantiation (host restart)', async () => {
    const file = await touch('persist.txt', 'v1')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'v1' })
    await writeFile(file, 'v2', 'utf8')

    const reopened = new SnapshotStore(root)
    const outcome = await reopened.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('v1')
  })

  it('skips symbolic links without writing through them', async () => {
    const real = await touch('real.txt', 'original')
    const link = join(root, 'ws', 'link.txt')
    const { symlink } = await import('node:fs/promises')
    try {
      await symlink(real, link)
    } catch {
      return // filesystem without symlink support: nothing to assert
    }
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: link, before: 'original' })
    await writeFile(real, 'rewritten', 'utf8')

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.skipped).toEqual([link])
    expect(await readFile(real, 'utf8')).toBe('rewritten')
  })

  it('skips hard links without writing through them', async () => {
    const real = await touch('real.txt', 'original')
    const hard = join(root, 'ws', 'hard.txt')
    const { link } = await import('node:fs/promises')
    try {
      await link(real, hard)
    } catch {
      return // filesystem without hard-link support: nothing to assert
    }
    // The hard link shares the inode with `real`, so a restore through it
    // would clobber both names — it must be skipped like a symlink.
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: hard, before: 'original' })
    await writeFile(real, 'rewritten', 'utf8')

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.skipped).toEqual([hard])
    expect(await readFile(real, 'utf8')).toBe('rewritten')
  })

  it('creates a deleted parent directory when restoring', async () => {
    const file = await touch('sub/deep/a.txt', 'original')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    // The file's whole parent tree is gone after the backup.
    await rm(join(root, 'ws', 'sub'), { recursive: true, force: true })

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('original')
  })

  it('restores with no entries as an empty no-op', async () => {
    const outcome = await store.restoreAfter(session, 42, unlink)
    expect(outcome).toEqual({ restored: [], deleted: [], skipped: [], failed: [] })
    expect(await store.impactsAfter(session, 42)).toEqual([])
  })
})

describe('restore planning reconciles with the current disk (Claude Code behavior)', () => {
  it('reports no ghost impact for a creation entry whose file is already gone', async () => {
    // Regression for the repeated-rewind bug: a rewind to message 2 deletes
    // the created file, but its entry stays in the store. A later rewind to
    // message 1 must NOT re-report the delete — the disk already matches the
    // target state, so the option disappears and the restore is a no-op.
    const created = await touch('gone.txt', 'n')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 6, path: created, before: null })
    await rm(created, { force: true }) // e.g. applied by an earlier rewind

    expect(await store.impactsAfter(session, 5)).toEqual([])
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome).toEqual({ restored: [], deleted: [], skipped: [], failed: [] })
  })

  it('treats identical content as no impact (idempotent restore)', async () => {
    const file = await touch('same.txt', 'x')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'x' })
    // Disk already equals the recorded before state.
    expect(await store.impactsAfter(session, 5)).toEqual([])
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome).toEqual({ restored: [], deleted: [], skipped: [], failed: [] })
    expect(await readFile(file, 'utf8')).toBe('x')
  })

  it('tolerates a delete whose file is already absent (no ENOENT failure)', async () => {
    const created = await touch('missing.txt', 'n')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 6, path: created, before: null })
    // The injected deleteFile itself fails with ENOENT (production unlink on
    // an absent file): the pass must swallow it, not report a failure.
    const outcome = await store.restoreAfter(session, 5, async () => {
      throw Object.assign(new Error('ENOENT: no such file'), { code: 'ENOENT' })
    })
    expect(outcome).toEqual({ restored: [], deleted: [], skipped: [], failed: [] })
  })

  it('restores a missing file whose before content exists (recreates it)', async () => {
    const file = await touch('recreate.txt', 'content')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'content' })
    await writeFile(file, 'edited', 'utf8')
    await rm(file, { force: true })

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('content')
  })

  it('plans exactly the real differences (injected probe)', async () => {
    const a = await touch('a.txt', 'A0')
    const b = await touch('b.txt', 'B1')
    const c = await touch('c.txt', 'created')
    await store.recordEntry(session, { callId: 'a', anchorSeq: 5, path: a, before: 'A0' })
    await store.recordEntry(session, { callId: 'b', anchorSeq: 5, path: b, before: 'B0' })
    await store.recordEntry(session, { callId: 'c', anchorSeq: 5, path: c, before: null })
    // Byte-exact fake probe: decides by comparing the RECORDED bytes with the
    // live file, so the planner must hand it the right source.
    const probe: DiskProbe = {
      isLink: async () => false,
      matches: async (source, path) => {
        if (source === null) return false // the created file is back on disk
        if (source.kind === 'blob') return (await readFile(source.path)).equals(await readFile(path))
        if (source.kind === 'text') return (await readFile(path)).equals(source.bytes)
        return (await readFile(path)).toString('utf8') === source.text
      },
      copy: async () => ({ kind: 'absent' }),
    }
    expect(await store.impactsAfter(session, 5, probe)).toEqual([
      { path: b, action: 'restore' },
      { path: c, action: 'delete' },
    ])
  })

  it('conservatively plans a restore when the disk probe fails', async () => {
    const file = await touch('unreadable.txt', 'original')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    const failingProbe: DiskProbe = {
      isLink: async () => false,
      matches: async () => {
        throw Object.assign(new Error('EACCES: permission denied'), { code: 'EACCES' })
      },
      copy: async () => ({ kind: 'absent' }),
    }
    // An unreadable file is never silently dropped: the plan treats it as
    // differing, so the restore still attempts the write.
    expect(await store.impactsAfter(session, 5, failingProbe)).toEqual([
      { path: file, action: 'restore' },
    ])
    const outcome = await store.restoreAfter(session, 5, unlink, failingProbe)
    expect(outcome.restored).toEqual([file])
  })

  it('never writes a legacy LOSSY record back over the live file', async () => {
    // A released-v1 record that contains U+FFFD lost the original bytes: it is
    // comparable but must never become a restore target, so the path is
    // skipped and the live bytes stay untouched.
    const file = await touch('gbk.txt', 'x')
    await writeFile(file, Buffer.from([0xd6, 0xd0, 0xce, 0xc4])) // GBK "中文"
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'c1.json'), JSON.stringify({
      callId: 'c1', anchorSeq: 5, path: file, before: '\uFFFD', time: 1,
    }), 'utf8')

    expect(await store.impactsAfter(session, 5)).toEqual([])
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome).toEqual({ restored: [], deleted: [], skipped: [file], failed: [] })
    expect(await readFile(file)).toEqual(Buffer.from([0xd6, 0xd0, 0xce, 0xc4]))
  })

  it('treats a legacy lossy record that still matches the disk as unchanged', async () => {
    const file = await touch('gbk-same.txt', 'x')
    await writeFile(file, Buffer.from([0xd6, 0xd0])) // lossy decode: two U+FFFD
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'c1.json'), JSON.stringify({
      callId: 'c1', anchorSeq: 5, path: file, before: '\uFFFD\uFFFD', time: 1,
    }), 'utf8')

    expect(await store.impactsAfter(session, 5)).toEqual([])
    expect(await store.restoreAfter(session, 5, unlink))
      .toEqual({ restored: [], deleted: [], skipped: [], failed: [] })
  })

  it('restores a faithful legacy text record byte-exactly', async () => {
    // A v1 string without U+FFFD is byte-exact UTF-8, so it restores normally.
    const file = await touch('text.txt', 'x')
    await writeFile(file, Buffer.from([0xd6, 0xd0]))
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'c1.json'), JSON.stringify({
      callId: 'c1', anchorSeq: 5, path: file, before: 'text', time: 1,
    }), 'utf8')

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('text')
  })

  it('still deletes a created file whose current bytes are not valid UTF-8', async () => {
    // A delete needs no content, so a binary file must not suppress it:
    // rewinding past the file's creation still removes it.
    const created = await touch('created.bin', '')
    await writeFile(created, Buffer.from([0x89, 0x50, 0x4e, 0x47])) // PNG magic
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 6, path: created, before: null })

    expect(await store.impactsAfter(session, 5)).toEqual([{ path: created, action: 'delete' }])
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.deleted).toEqual([created])
    expect(await store.exists(created)).toBe(false)
  })

  it('fails the path — never deletes — when content cannot be resolved', async () => {
    // A dangling dedup link is a per-file integrity failure. Falling back to
    // "the file was created" would plan a DELETE of a file we cannot restore.
    const file = await touch('dangling.txt', 'live content')
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'dangling.json'), JSON.stringify({
      callId: 'dangling', anchorSeq: 5, path: file, ref: '6/missing.json', time: 1,
    }), 'utf8')

    expect(await store.impactsAfter(session, 5)).toEqual([])
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.deleted).toEqual([])
    expect(outcome.restored).toEqual([])
    expect(outcome.failed.map(f => f.path)).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('live content')
  })

  it('fails the path — never deletes — when the recorded sidecar is missing', async () => {
    const file = await touch('gone-sidecar.txt', 'live content')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'recorded' })
    const sidecar = (await readdir(store.anchorDir(session, 5))).find(name => name.endsWith('.before'))
    if (sidecar === undefined) throw new Error('expected a staged sidecar')
    await rm(join(store.anchorDir(session, 5), sidecar), { force: true })

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.deleted).toEqual([])
    expect(outcome.failed.map(f => f.path)).toEqual([file])
    expect(outcome.failed[0]!.message).toContain('missing backup sidecar')
    expect(await readFile(file, 'utf8')).toBe('live content')
  })
})

describe('defaultProbe (byte-exact comparisons)', () => {
  it('treats an absent path as the recorded "created" state', async () => {
    const missing = join(root, 'nope.txt')
    expect(await defaultProbe.matches(null, missing)).toBe(true)
    const file = await touch('present.txt', 'x')
    expect(await defaultProbe.matches(null, file)).toBe(false)
  })

  it('compares a file against in-memory text bytes', async () => {
    const file = await touch('text.txt', 'hello')
    expect(await defaultProbe.matches({ kind: 'text', bytes: Buffer.from('hello') }, file)).toBe(true)
    expect(await defaultProbe.matches({ kind: 'text', bytes: Buffer.from('other') }, file)).toBe(false)
    expect(await defaultProbe.matches({ kind: 'text', bytes: Buffer.from('hello') }, join(root, 'gone.txt'))).toBe(false)
  })

  it('compares a file against a sidecar across multiple read chunks', async () => {
    // 160 KiB exercises the streaming path (chunked, never whole-file).
    const bytes = Buffer.alloc(160 * 1024, 7)
    const live = await touch('big.bin', '')
    await writeFile(live, bytes)
    const sidecar = join(root, 'big.before')
    await writeFile(sidecar, bytes)
    expect(await defaultProbe.matches({ kind: 'blob', path: sidecar }, live)).toBe(true)

    const changed = Buffer.from(bytes)
    changed[bytes.length - 1] = 8
    await writeFile(sidecar, changed)
    expect(await defaultProbe.matches({ kind: 'blob', path: sidecar }, live)).toBe(false)
  })

  it('compares a legacy lossy string with the same lossy decode', async () => {
    const file = await touch('gbk.bin', '')
    await writeFile(file, Buffer.from([0xd6, 0xd0]))
    const lossy: ByteSource = { kind: 'lossyText', text: '\uFFFD\uFFFD' }
    expect(await defaultProbe.matches(lossy, file)).toBe(true)
    expect(await defaultProbe.matches({ kind: 'lossyText', text: 'x' }, file)).toBe(false)
  })

  it('stages a raw byte copy, reporting absent and failed outcomes', async () => {
    const file = await touch('copy.txt', 'payload')
    const dest = join(root, 'staged.before')
    expect(await defaultProbe.copy(file, dest)).toEqual({ kind: 'copied', size: 7 })
    expect(await readFile(dest, 'utf8')).toBe('payload')
    expect(await defaultProbe.copy(join(root, 'nope.txt'), dest)).toEqual({ kind: 'absent' })
    const failed = await defaultProbe.copy(file, join(root, 'no-such-dir', 'x.before'))
    expect(failed.kind).toBe('failed')
  })
})

describe('reconcileTracked (user-message boundary re-check)', () => {
  it('records an external edit at the next boundary and restores it on rewind', async () => {
    const file = await touch('tracked.txt', 'original')
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: file, before: 'original' })
    await writeFile(file, 'externally edited', 'utf8') // external change
    const tracked = await store.trackedPaths(session)

    expect(await reconcileTracked(store, session, 7, tracked)).toBe(1)
    // The recheck entry anchors the external state at the boundary message.
    // Rewinding to it restores the external edit…
    await writeFile(file, 'something else', 'utf8')
    const outcome = await store.restoreAfter(session, 7, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('externally edited')
    // …while rewinding before it still restores the tool-captured before.
    await writeFile(file, 'again', 'utf8')
    const earlier = await store.restoreAfter(session, 5, unlink)
    expect(earlier.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('original')
  })

  it('records a deletion and restores the file when rewinding before it', async () => {
    const file = await touch('tracked.txt', 'original')
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: file, before: 'original' })
    await rm(file, { force: true }) // external delete
    const tracked = await store.trackedPaths(session)

    expect(await reconcileTracked(store, session, 7, tracked)).toBe(1)
    // At the boundary the deletion is already applied: rewinding to 7 is a
    // no-op; rewinding before it recreates the file from the earlier entry.
    expect(await store.impactsAfter(session, 7)).toEqual([])
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('original')
  })

  it('never records a path whose CURRENT size is over the backup cap', async () => {
    const file = await touch('grew.txt', 'small')
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: file, before: 'small' })
    // The boundary honours the cap BEFORE looking at content: this probe throws
    // if either the content comparison or the copy is reached, so a regression
    // that moved the cap check after them fails loudly here instead of quietly
    // spending the IO the cap exists to save.
    let isLinkCalls = 0
    const sized = (bytes: number): DiskProbe => ({
      isLink: async () => { isLinkCalls += 1; return false },
      size: async () => bytes,
      matches: async () => { throw new Error('the cap gate must run before any content comparison') },
      copy: async () => { throw new Error('an over-cap path must never be copied') },
    })
    expect(await reconcileTracked(store, session, 7, new Set([file]), sized(9_000_000))).toBe(0)
    expect(isLinkCalls).toBe(1) // the path really was visited and then skipped

    // Back under the cap, with a NEW state to record: captured normally.
    await writeFile(file, 'shrunk again', 'utf8')
    expect(await reconcileTracked(store, session, 8, new Set([file]), defaultProbe)).toBe(1)
  })

  it('records the boundary state after a creation, then stays silent while unchanged', async () => {
    // The write captured `before: null` (the file did not exist yet); the write
    // itself then created it. So at the NEXT message the disk (A) no longer
    // matches that record (null) — the boundary records A, and the message
    // after that is genuinely unchanged and records nothing.
    const file = join(root, 'ws', 'created-at-boundary.txt')
    await mkdir(dirname(file), { recursive: true })
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: file, before: null })
    await writeFile(file, 'A', 'utf8')
    const tracked = await store.trackedPaths(session)

    expect(await reconcileTracked(store, session, 6, tracked)).toBe(1)
    const atSix = await store.entriesAfter(session, 6)
    expect(atSix.map(entry => entry.path)).toEqual([file])
    expect(await store.restoreAfter(session, 6, unlink)).toEqual({ restored: [], deleted: [], skipped: [], failed: [] })

    expect(await reconcileTracked(store, session, 7, tracked)).toBe(0)
  })

  it('records only on state change (first sighting always records)', async () => {
    const file = await touch('tracked.txt', 'original')
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: file, before: 'original' })
    await writeFile(file, 'edited by turn', 'utf8')
    const tracked = await store.trackedPaths(session)

    // First sighting of the path: unconditionally record the current state.
    expect(await reconcileTracked(store, session, 7, tracked)).toBe(1)
    // Next boundary: state unchanged → nothing new recorded.
    expect(await reconcileTracked(store, session, 8, tracked)).toBe(0)
    // External change → recorded again.
    await writeFile(file, 'externally edited', 'utf8')
    expect(await reconcileTracked(store, session, 9, tracked)).toBe(1)
  })

  it('skips symlinked paths', async () => {
    const real = await touch('real.txt', 'x')
    const link = join(root, 'ws', 'link.txt')
    const { symlink } = await import('node:fs/promises')
    try {
      await symlink(real, link)
    } catch {
      return // filesystem without symlink support: nothing to assert
    }
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: link, before: 'x' })
    const tracked = await store.trackedPaths(session)
    expect(await reconcileTracked(store, session, 7, tracked)).toBe(0)
  })

  it('records a non-UTF-8 file byte-exactly instead of as absent', async () => {
    // A decode failure must never become `before: null` (a later rewind would
    // DELETE the file); the boundary stages the CURRENT bytes instead.
    const file = await touch('binary.bin', 'original')
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: file, before: 'original' })
    const gbk = Buffer.from([0xd6, 0xd0, 0xce, 0xc4]) // GBK "中文"
    await writeFile(file, gbk)
    const tracked = await store.trackedPaths(session)

    expect(await reconcileTracked(store, session, 7, tracked)).toBe(1)
    const outcome = await store.restoreAfter(session, 7, unlink)
    expect(outcome.deleted).toEqual([])
    expect(await readFile(file)).toEqual(gbk)

    // The captured state is byte-exact: change the file and rewind to the
    // boundary to get exactly those bytes back.
    await writeFile(file, Buffer.from([0x00, 0xff]))
    const restored = await store.restoreAfter(session, 7, unlink)
    expect(restored.restored).toEqual([file])
    expect(await readFile(file)).toEqual(gbk)
  })
})

describe('content dedup (in-place link; old + new entry format)', () => {
  it('reads pre-dedup (legacy, no `ref`) entries correctly: restore/impacts/tracked', async () => {
    const file = await touch('a.txt', 'original')
    // Simulate an OLD-format entry written by a pre-dedup build (no `ref`).
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'legacy1.json'), JSON.stringify({ callId: 'legacy1', anchorSeq: 5, path: file, before: 'original', time: 1 }))
    await writeFile(file, 'changed', 'utf8')
    expect((await store.trackedPaths(session)).has(file)).toBe(true)
    expect(await store.impactsAfter(session, 5)).toEqual([{ path: file, action: 'restore' }])
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('original')
  })

  it('dedups a new identical write against a legacy real entry (new reads old)', async () => {
    const file = await touch('a.txt', 'v')
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'legacy1.json'), JSON.stringify({ callId: 'legacy1', anchorSeq: 5, path: file, before: 'same', time: 1 }))
    await store.recordEntry(session, { callId: 'new1', anchorSeq: 6, path: file, before: 'same' })
    const entries = await store.entriesAfter(session, 5)
    const links = entries.filter(isLinkEntry)
    expect(links).toHaveLength(1)
    expect(links[0]!.ref).toBe('5/legacy1.json') // the new entry links to the legacy real
    expect(entries.filter(e => !isLinkEntry(e))).toHaveLength(1)
    // The link is not just structural: restoring through it pulls the LEGACY
    // (old-format) real content back, proving new-reads-old actually works.
    await writeFile(file, 'changed', 'utf8')
    const outcome = await store.restoreAfter(session, 6, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('same')
  })

  it('collapses the boundary-recheck + write-tool double record into one real + one link', async () => {
    const file = await touch('a.txt', 'v')
    // recheck (boundary) records the current state, then the turn's tool edit
    // captures the SAME before — the second becomes a link to the first.
    await store.recordEntry(session, { callId: 'recheck-5', anchorSeq: 5, path: file, before: 'same' })
    await store.recordEntry(session, { callId: 'tool', anchorSeq: 5, path: file, before: 'same' })
    const entries = await store.entriesAfter(session, 5)
    expect(entries).toHaveLength(2)
    expect(entries.filter(isLinkEntry)).toHaveLength(1)
    expect(entries.filter(e => !isLinkEntry(e))).toHaveLength(1)
  })

  it('realistic double-record via the boundary recheck + next tool capture is deduped', async () => {
    const file = await touch('a.txt', 'A')
    // Turn 1: a tool edits A→X; the recordEntry captures before=A.
    await store.recordEntry(session, { callId: 'tool1', anchorSeq: 5, path: file, before: 'A' })
    await writeFile(file, 'X', 'utf8')
    // Turn 2 boundary: reconcileTracked re-reads the tracked file; the state
    // changed to X, so it records a before=X entry at the boundary.
    const tracked = await store.trackedPaths(session)
    expect(await reconcileTracked(store, session, 7, tracked)).toBe(1)
    // Turn 2 tool: edits X→Y; the capture before is ALSO X — dedup turns this
    // into a link to the boundary's X entry instead of a second full copy.
    await store.recordEntry(session, { callId: 'tool2', anchorSeq: 7, path: file, before: 'X' })
    const entries = await store.entriesAfter(session, 5)
    expect(entries.filter(isLinkEntry)).toHaveLength(1)
    expect(entries.filter(e => !isLinkEntry(e))).toHaveLength(2) // A@5, X@7(recheck)
    // Rewinding to the second turn restores X (through the earliest X entry).
    await writeFile(file, 'Y', 'utf8')
    const outcome = await store.restoreAfter(session, 7, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('X')
  })

  it('keeps genuinely different content as separate real snapshots (no false dedup)', async () => {
    const file = await touch('a.txt', 'v')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'v1' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: 'v2' })
    const entries = await store.entriesAfter(session, 5)
    expect(entries.filter(isLinkEntry)).toHaveLength(0)
    expect(entries).toHaveLength(2)
  })

  it('restores the correct content when the earliest entry at the target is a link', async () => {
    const file = await touch('a.txt', 'v')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    await writeFile(file, 'edited', 'utf8')
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: 'edited' })
    await writeFile(file, 'final', 'utf8')
    await store.recordEntry(session, { callId: 'c3', anchorSeq: 7, path: file, before: 'edited' }) // link to c2
    const outcome = await store.restoreAfter(session, 7, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('edited')
  })

  it('writes full copies when dedup is disabled', async () => {
    const file = await touch('a.txt', 'v')
    const s = new SnapshotStore(root, { dedup: false })
    await s.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'same' })
    await s.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: 'same' })
    const entries = await s.entriesAfter(session, 5)
    expect(entries.filter(isLinkEntry)).toHaveLength(0)
    expect(entries).toHaveLength(2)
  })

  it('persists and rereads link entries across a restart (new format read)', async () => {
    const file = await touch('a.txt', 'v')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'X' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: 'X' }) // link
    const reopened = new SnapshotStore(root)
    await writeFile(file, 'changed', 'utf8')
    const outcome = await reopened.restoreAfter(session, 6, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('X')
  })

  it('seeds dedup state from disk after a restart so identical content still links', async () => {
    const file = await touch('a.txt', 'v')
    const s1 = new SnapshotStore(root)
    await s1.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'X' })
    const s2 = new SnapshotStore(root)
    await s2.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: 'X' })
    const entries = await s2.entriesAfter(session, 5)
    expect(entries.filter(isLinkEntry)).toHaveLength(1)
    expect(entries.filter(e => !isLinkEntry(e))).toHaveLength(1)
  })

  it('materializes links before dropping the referenced group during prune (no dangling)', async () => {
    const file = await touch('a.txt', 'v')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 1, path: file, before: 'A' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 2, path: file, before: 'A' })
    await store.recordEntry(session, { callId: 'c3', anchorSeq: 3, path: file, before: 'A' })
    await store.prune(session, 1)
    const entries = await store.entriesAfter(session, 1)
    expect(entries).toHaveLength(1)
    const survivor = entries[0]!
    if (isLinkEntry(survivor)) throw new Error('expected a materialized real snapshot')
    if (survivor.before === null || survivor.before.kind !== 'blob') throw new Error('expected a materialized blob source')
    expect(await readFile(survivor.before.path, 'utf8')).toBe('A')
    expect(survivor.size).toBe(1)
    // Reopen on disk and confirm the surviving entry restores without a dangling link.
    const reopened = new SnapshotStore(root)
    await writeFile(file, 'changed', 'utf8')
    const outcome = await reopened.restoreAfter(session, 1, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('A')
  })

  it('applies a good action AND reports a dangling link in the same restore', async () => {
    const good = await touch('good.txt', 'v')
    const broken = await touch('broken.txt', 'v')
    await store.recordEntry(session, { callId: 'g', anchorSeq: 5, path: good, before: 'before' })
    await writeFile(good, 'after', 'utf8')
    // A corrupt link for a second path at the same target.
    await writeFile(join(store.anchorDir(session, 5), 'broken.json'), JSON.stringify({ callId: 'broken', anchorSeq: 5, path: broken, ref: '99/missing.json', time: 2 }))
    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([good])          // the good path is still restored
    expect(await readFile(good, 'utf8')).toBe('before')
    expect(outcome.failed).toHaveLength(1)            // the dangling link is reported, not silent
    expect(outcome.failed[0]!.path).toBe(broken)
  })

  it('dedups two created (before null) states for the same file into a link', async () => {
    const file = await touch('a.txt', 'v')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: null })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: null })
    const entries = await store.entriesAfter(session, 5)
    expect(entries.filter(isLinkEntry)).toHaveLength(1)   // c2 links to c1
    expect(entries.filter(e => !isLinkEntry(e))).toHaveLength(1)
  })

  it('collapses a long identical run into one real plus links', async () => {
    const file = await touch('a.txt', 'v')
    for (let seq = 1; seq <= 5; seq++) {
      await store.recordEntry(session, { callId: `c${seq}`, anchorSeq: seq, path: file, before: 'same' })
    }
    const entries = await store.entriesAfter(session, 1)
    expect(entries.filter(isLinkEntry)).toHaveLength(4)          // c2..c5 link to c1
    expect(entries.filter(e => !isLinkEntry(e))).toHaveLength(1) // c1 real
  })

  it('reports the correct impact when the earliest entry at the target is a link', async () => {
    const file = await touch('a.txt', 'v')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'X' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file, before: 'X' }) // link
    await writeFile(file, 'Y', 'utf8')
    expect(await store.impactsAfter(session, 6)).toEqual([{ path: file, action: 'restore' }])
  })

  it('treats a traversal (unsafe) ref as an invalid link, never reading outside the store', async () => {
    const file = await touch('a.txt', 'v')
    await mkdir(store.anchorDir(session, 6), { recursive: true })
    // A tampered/corrupt link whose ref tries to escape the session dir.
    await writeFile(join(store.anchorDir(session, 6), 'c2.json'), JSON.stringify({ callId: 'c2', anchorSeq: 6, path: file, ref: '../outside.json', time: 1 }))
    // A decoy one level up: it is never read if the ref is not followed.
    await writeFile(join(root, 'outside.json'), 'decoy', 'utf8')
    const outcome = await store.restoreAfter(session, 6, unlink)
    expect(outcome.failed).toHaveLength(1)          // reported, not silent
    expect(outcome.restored).toEqual([])
    expect(outcome.deleted).toEqual([])
    expect(await readFile(join(root, 'outside.json'), 'utf8')).toBe('decoy')
  })
})

describe('pruneStale', () => {
  const day = 86_400_000
  const now = () => Date.now()

  /** Seed one anchor group with an entry file and pin every ancestor mtime. */
  async function seedSession(sessionId: string, anchor: string, callId: string, body: string, mtimeMs: number): Promise<void> {
    const anchorDir = join(root, sessionId, anchor)
    await mkdir(anchorDir, { recursive: true })
    const file = join(anchorDir, `${callId}.json`)
    await writeFile(file, body, 'utf8')
    const t = new Date(mtimeMs)
    await utimes(file, t, t)
    await utimes(anchorDir, t, t)
    await utimes(join(root, sessionId), t, t)
  }

  /** Seed a journal-only session (an entry directly in the session dir). */
  async function seedJournal(sessionId: string, name: string, body: string, mtimeMs: number): Promise<void> {
    const sessionDir = join(root, sessionId)
    await mkdir(sessionDir, { recursive: true })
    const file = join(sessionDir, name)
    await writeFile(file, body, 'utf8')
    const t = new Date(mtimeMs)
    await utimes(file, t, t)
    await utimes(sessionDir, t, t)
  }

  it('deletes finished-session dirs idle past maxAgeDays and keeps fresh ones', async () => {
    await seedSession('old', '1', 'a', '{}', now() - 40 * day)
    await seedSession('fresh', '1', 'a', '{}', now() - 1 * day)
    const rep = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep).toMatchObject({ deleted: 1, kept: 1, scanned: 2, skippedActive: 0, dryRun: false })
    expect(rep.freedBytes).toBeGreaterThan(0)
    await expect(store.exists(join(root, 'old'))).resolves.toBe(false)
    await expect(store.exists(join(root, 'fresh'))).resolves.toBe(true)
  })

  it('treats a fresh staged capture as activity (dot dirs are store members)', async () => {
    const old = now() - 40 * day
    await seedSession('staged', '1', 'a', '{}', old)
    const pendingDir = join(root, 'staged', '.pending')
    await mkdir(pendingDir, { recursive: true })
    // A staged capture written into the ALREADY EXISTING `.pending/`: only the
    // file is fresh, so the freshness must be seen INSIDE the dot directory
    // (creating the dir would have bumped the session dir's own mtime).
    await writeFile(join(pendingDir, 'call.before'), 'x', 'utf8')
    const t = new Date(old)
    await utimes(join(root, 'staged'), t, t)
    await utimes(pendingDir, t, t)

    const rep = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep.deleted).toBe(0)
    await expect(store.exists(join(root, 'staged'))).resolves.toBe(true)
  })

  it('counts staged-capture bytes in freedBytes', async () => {
    const old = now() - 40 * day
    await seedSession('old-pending', '1', 'a', '{}', old)
    const pendingDir = join(root, 'old-pending', '.pending')
    await mkdir(pendingDir, { recursive: true })
    const staged = join(pendingDir, 'call.before')
    await writeFile(staged, '12345', 'utf8')
    // Everything in this session is genuinely old (the byte total is what this
    // test is about), including the staged file itself.
    const t = new Date(old)
    await utimes(staged, t, t)
    await utimes(join(root, 'old-pending'), t, t)
    await utimes(pendingDir, t, t)

    const rep = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep.deleted).toBe(1)
    // '{}' (2 bytes entry) + '12345' (5 bytes staged) — the staged bytes are
    // real store content and must be reported as freed.
    expect(rep.freedBytes).toBe(7)
  })

  it('forgets in-memory state for the sessions it deleted', async () => {
    const old = now() - 40 * day
    const file = join(root, 'ws', 'gone.txt')
    await mkdir(join(root, 'ws'), { recursive: true })
    await writeFile(file, 'x', 'utf8')
    await seedSession(session, '5', 'c1', JSON.stringify({
      callId: 'c1', anchorSeq: 5, path: file, before: 'x', time: 1,
    }), old)

    // Seeding from disk puts a handle in memory (the dedup state).
    await expect(store.lastKnownContent(session, file)).resolves.not.toBeUndefined()
    const rep = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep.deleted).toBe(1)
    // The dir is gone, so the handle must be gone too — otherwise the store
    // keeps state for a session it just deleted (and skips re-stamping its
    // markers on the next commit).
    await expect(store.lastKnownContent(session, file)).resolves.toBeUndefined()
  })

  it('measures the newest MEMBER mtime, not the session-dir mtime', async () => {
    await seedSession('nested', '1', 'a', '{}', now() - 40 * day)
    // A fresh file inside an otherwise old anchor group: newest member wins.
    const fresh = join(root, 'nested', '1', 'b.json')
    await writeFile(fresh, '{}', 'utf8')
    await utimes(join(root, 'nested', '1'), new Date(now() - 40 * day), new Date(now() - 40 * day))
    await utimes(join(root, 'nested'), new Date(now() - 40 * day), new Date(now() - 40 * day))
    const rep = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep.deleted).toBe(0)
    expect(rep.kept).toBe(1)
  })

  it('never deletes the active session, even when idle past the cutoff', async () => {
    await seedSession('active', '1', 'a', '{}', now() - 40 * day)
    const rep = await store.pruneStale({ maxAgeDays: 30, keepActiveId: 'active' })
    expect(rep.skippedActive).toBe(1)
    expect(rep.deleted).toBe(0)
    await expect(store.exists(join(root, 'active'))).resolves.toBe(true)
  })

  it('reports without deleting when dryRun', async () => {
    await seedSession('old', '1', 'a', '{}', now() - 40 * day)
    const rep = await store.pruneStale({ maxAgeDays: 30, dryRun: true })
    expect(rep.dryRun).toBe(true)
    expect(rep.deleted).toBe(1)
    expect(rep.freedBytes).toBeGreaterThan(0)
    await expect(store.exists(join(root, 'old'))).resolves.toBe(true) // untouched
  })

  it('uses a strict older-than cutoff (== maxAgeDays is retained)', async () => {
    vi.useFakeTimers()
    try {
      const t0 = 1_700_000_000_000
      vi.setSystemTime(t0)
      await seedSession('exact', '1', 'a', '{}', t0 - 30 * day)
      // Exactly at the cutoff: not older-than => kept.
      const rep0 = await store.pruneStale({ maxAgeDays: 30 })
      expect(rep0.deleted).toBe(0)
      expect(rep0.kept).toBe(1)
      // One day later: now strictly older than 30 days => deleted.
      vi.setSystemTime(t0 + day)
      const rep1 = await store.pruneStale({ maxAgeDays: 30 })
      expect(rep1.deleted).toBe(1)
      expect(rep1.kept).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })

  it('rejects a non-positive maxAgeDays instead of mass-deleting', async () => {
    await expect(store.pruneStale({ maxAgeDays: 0 })).rejects.toThrow(RangeError)
    await expect(store.pruneStale({ maxAgeDays: -5 })).rejects.toThrow(RangeError)
    await expect(store.pruneStale({ maxAgeDays: Number.NaN })).rejects.toThrow(RangeError)
  })

  it('returns an empty report when the root does not exist', async () => {
    const missing = new SnapshotStore(join(root, 'nope'))
    const rep = await missing.pruneStale({ maxAgeDays: 30 })
    expect(rep).toMatchObject({ scanned: 0, deleted: 0, kept: 0, skippedActive: 0, freedBytes: 0 })
  })

  it('counts mixed sessions and reports sizes correctly', async () => {
    await seedSession('a', '1', 'x', '{}', now() - 40 * day) // old -> delete (2 bytes)
    await seedSession('b', '1', 'x', '{}', now() - 1 * day)  // fresh -> keep (2 bytes)
    await seedSession('c', '1', 'x', '{}', now() - 40 * day) // old but active -> skip (2 bytes)
    const rep = await store.pruneStale({ maxAgeDays: 30, keepActiveId: 'c' })
    expect(rep).toMatchObject({ scanned: 3, deleted: 1, kept: 1, skippedActive: 1 })
    expect(rep.freedBytes).toBe(2)      // 'a' (one 2-byte file)
    expect(rep.remainingBytes).toBe(4)  // 'b' + 'c' (one 2-byte file each)
    await expect(store.exists(join(root, 'a'))).resolves.toBe(false)
    await expect(store.exists(join(root, 'b'))).resolves.toBe(true)
    await expect(store.exists(join(root, 'c'))).resolves.toBe(true)
  })

  it('measures and prunes a journal-only session (no anchor groups)', async () => {
    await seedJournal('j', 'restore-journal-x.json', '{}', now() - 40 * day)
    const rep = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep.deleted).toBe(1)
    await expect(store.exists(join(root, 'j'))).resolves.toBe(false)
  })

  it('skips non-directories and dot-prefixed entries in the root', async () => {
    await writeFile(join(root, 'stray.txt'), 'x', 'utf8')
    await mkdir(join(root, '.hidden'), { recursive: true })
    await seedSession('real', '1', 'a', '{}', now() - 40 * day)
    const rep = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep.scanned).toBe(1)
    expect(rep.deleted).toBe(1)
    await expect(store.exists(join(root, 'stray.txt'))).resolves.toBe(true)
    await expect(store.exists(join(root, '.hidden'))).resolves.toBe(true)
  })

  it('never follows a symlink out of the root (containment)', async () => {
    const outside = join(root, '..', `outside-${Date.now()}`)
    await mkdir(outside, { recursive: true })
    await writeFile(join(outside, 'secret.txt'), 's', 'utf8')
    try {
      await symlink(outside, join(root, 'link'), 'dir')
      await seedSession('real', '1', 'a', '{}', now() - 40 * day)
      const rep = await store.pruneStale({ maxAgeDays: 30 })
      expect(rep.scanned).toBe(1) // 'link' is a symlink => not a directory => skipped
      expect(rep.deleted).toBe(1)
      await expect(store.exists(join(outside, 'secret.txt'))).resolves.toBe(true)
    } finally {
      await rm(outside, { recursive: true, force: true })
    }
  })

  it('is idempotent: a second sweep removes nothing new', async () => {
    await seedSession('old', '1', 'a', '{}', now() - 40 * day)
    await store.pruneStale({ maxAgeDays: 30 })
    const rep2 = await store.pruneStale({ maxAgeDays: 30 })
    expect(rep2.deleted).toBe(0)
    expect(rep2.scanned).toBe(0)
  })

  it('keeps everything when maxAgeDays is large', async () => {
    await seedSession('old', '1', 'a', '{}', now() - 40 * day)
    const rep = await store.pruneStale({ maxAgeDays: 365 })
    expect(rep.deleted).toBe(0)
    expect(rep.kept).toBe(1)
  })
})

describe('clearSession', () => {
  it('reports a zero summary for a session with no data', async () => {
    const rep = await store.clearSession(session)
    expect(rep).toEqual({ sessionId: session, anchorGroups: 0, entries: 0, journals: 0, bytes: 0, dryRun: false })
    // A missing dir is a no-op regardless of the dry/apply switch.
    const dry = await store.clearSession('nope', { dryRun: true })
    expect(dry.dryRun).toBe(true)
    expect(dry.entries).toBe(0)
    expect(dry.anchorGroups).toBe(0)
  })

  it('summarizes anchor groups, entries, journals and bytes', async () => {
    const a = await touch('a.txt', 'one')
    const b = await touch('b.txt', 'two')
    const c = await touch('c.txt', 'three')
    await store.recordEntry(session, { callId: 'a1', anchorSeq: 5, path: a, before: 'one' })
    await store.recordEntry(session, { callId: 'b1', anchorSeq: 5, path: b, before: 'two' })
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 7, path: c, before: 'three' })
    // Fabricate a journal file directly in the session dir (named by prefix).
    const sessionDir = store.sessionDir(session)
    await writeFile(join(sessionDir, 'restore-journal-op1.json'), JSON.stringify({ v: 1 }), 'utf8')
    const rep = await store.clearSession(session, { dryRun: true })
    expect(rep.anchorGroups).toBe(2)
    expect(rep.entries).toBe(3)
    expect(rep.journals).toBe(1)
    expect(rep.bytes).toBeGreaterThan(0)
    expect(rep.dryRun).toBe(true)
  })

  it('dry-run leaves disk and dedup memory untouched', async () => {
    const file = await touch('a.txt', 'original')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    await store.lastKnownContent(session, file) // seed dedup state
    const rep = await store.clearSession(session, { dryRun: true })
    expect(rep.dryRun).toBe(true)
    expect(rep.entries).toBe(1)
    expect(await store.exists(store.sessionDir(session))).toBe(true)
    expect(await store.trackedPaths(session)).toEqual(new Set([file]))
    const handle = await store.lastKnownContent(session, file)
    if (handle === null || handle === undefined || handle.kind !== 'blob') throw new Error('expected a blob handle')
    expect(await readFile(handle.path, 'utf8')).toBe('original')
  })

  it('clears a session dir that only holds a staged capture', async () => {
    // A staged capture is store content (it counts in `bytes`), so an explicit
    // clear must remove it — otherwise the dir survives with content the
    // report just said it would free.
    const staged = await store.stageCapture(session, 'orphan')
    await writeFile(staged, 'x', 'utf8')

    const dry = await store.clearSession(session, { dryRun: true })
    expect(dry.entries).toBe(0)
    expect(dry.bytes).toBeGreaterThan(0)

    const rep = await store.clearSession(session)
    expect(rep.dryRun).toBe(false)
    await expect(store.exists(store.sessionDir(session))).resolves.toBe(false)
  })

  it('apply clears the session dir and resets dedup memory (no dangling link)', async () => {
    const file = await touch('a.txt', 'original')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    const rep = await store.clearSession(session)
    expect(rep.dryRun).toBe(false)
    expect(rep.entries).toBe(1)
    expect(await store.exists(store.sessionDir(session))).toBe(false)
    expect(await store.trackedPaths(session)).toEqual(new Set())
    expect(await store.lastKnownContent(session, file)).toBeUndefined()
    // A fresh record for the same path/content must be a real entry, NOT a link
    // to the just-deleted prior entry (the dedup chain was reset).
    const file2 = await touch('a.txt', 'original')
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file2, before: 'original' })
    const entries = await store.entriesAfter(session, 0)
    expect(entries).toHaveLength(1)
    expect(isLinkEntry(entries[0]!)).toBe(false)
    expect(entries[0]!.path).toBe(file2)
  })

  it('clears a session even when a stale (orphaned) non-terminal restore journal exists', async () => {
    const file = await touch('a.txt', 'original')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    await writeFile(file, 'rewritten', 'utf8')
    // Crash BEFORE the first restore action so a `running` journal stays on disk.
    await expect(store.restoreAfter(session, 5, unlink, undefined, { crash: () => { throw new Error('crash') } })).rejects.toThrow()
    const dir = store.sessionDir(session)
    expect(await store.exists(dir)).toBe(true)
    // Clearing is an explicit abandonment of this session's archive, so it must
    // proceed regardless of the orphaned journal (it is only ever stale — a
    // clear and a restore never interleave).
    const rep = await store.clearSession(session)
    expect(rep.dryRun).toBe(false)
    expect(await store.exists(dir)).toBe(false)
  })

  it('clears a session holding a corrupt (unclassifiable) journal', async () => {
    const file = await touch('a.txt', 'x')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'x' })
    await writeFile(join(store.sessionDir(session), 'restore-journal-bad.json'), JSON.stringify({ not: 'a journal' }), 'utf8')
    const rep = await store.clearSession(session)
    expect(rep.dryRun).toBe(false)
    expect(rep.journals).toBe(1)
    expect(await store.exists(store.sessionDir(session))).toBe(false)
  })

  it('apply on an already-empty session still resets the in-memory dedup state', async () => {
    const file = await touch('a.txt', 'original')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    // Remove the session dir out-of-band while the in-memory dedup state still
    // holds this path's content (simulates an external wipe).
    await rm(store.sessionDir(session), { recursive: true, force: true })
    await store.clearSession(session) // apply on an empty/nonexistent dir
    expect(await store.lastKnownContent(session, file)).toBeUndefined()
    // A fresh record for the same path must be a full entry, not a dangling link.
    const file2 = await touch('a.txt', 'original')
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 6, path: file2, before: 'original' })
    const entries = await store.entriesAfter(session, 0)
    expect(entries).toHaveLength(1)
    expect(isLinkEntry(entries[0]!)).toBe(false)
  })

  it('does not interfere with the age-based retention sweep', async () => {
    // Seed a stale session past the 30-day cutoff directly on disk.
    const staleDir = join(root, 'stale')
    const staleAnchor = join(staleDir, '1')
    await mkdir(staleAnchor, { recursive: true })
    const staleFile = join(staleAnchor, 'a.json')
    await writeFile(staleFile, '{}', 'utf8')
    const t = new Date(Date.now() - 40 * 86_400_000)
    await utimes(staleFile, t, t)
    await utimes(staleAnchor, t, t)
    await utimes(staleDir, t, t)
    // Clear the active session, then verify the stale sweep still removes `stale`.
    const file = await touch('a.txt', 'x')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'x' })
    await store.clearSession(session)
    const rep = await store.pruneStale({ keepActiveId: session, maxAgeDays: 30 })
    expect(rep.deleted).toBe(1)
    expect(await store.exists(join(root, 'stale'))).toBe(false)
  })
})

describe('session format-version reconcile', () => {
  const formatFile = (id: string): string => join(store.sessionDir(id), 'format')
  const anchorDir = (id: string, seq: number): string => join(store.sessionDir(id), String(seq))
  const readFormat = async (id: string): Promise<string | null> => readFile(formatFile(id), 'utf8').catch(() => null)

  it('clears a legacy dir (snapshots, no marker) and re-stamps the current version', async () => {
    const file = await touch('legacy.txt', 'x')
    // Written under a pre-marker build: no format marker is stamped.
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'x' })
    expect(await store.exists(anchorDir(session, 5))).toBe(true)
    expect(await readFormat(session)).toBeNull()

    const result = await store.reconcileFormatVersion(session, 3)
    expect(result.cleared).toBe(true)
    expect(await store.exists(anchorDir(session, 5))).toBe(false)
    expect(await readFormat(session)).toBe('3')
  })

  it('keeps snapshots when the marker matches the loaded session format', async () => {
    store.setFormatVersion(3)
    const file = await touch('match.txt', 'x')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'x' })
    expect(await readFormat(session)).toBe('3')

    const result = await store.reconcileFormatVersion(session, 3)
    expect(result.cleared).toBe(false)
    expect(await store.exists(anchorDir(session, 5))).toBe(true)
  })

  it('clears snapshots and re-stamps when the marker differs (v2 -> v3)', async () => {
    const file = await touch('v2.txt', 'x')
    // The snapshot was anchored under the v2 format (marker 2).
    await store.markFormatVersion(session, 2)
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'x' })
    expect(await readFormat(session)).toBe('2')

    const result = await store.reconcileFormatVersion(session, 3)
    expect(result.cleared).toBe(true)
    expect(await store.exists(anchorDir(session, 5))).toBe(false)
    expect(await readFormat(session)).toBe('3')
  })

  it('does nothing (and materializes no dir) for an untouched session', async () => {
    const result = await store.reconcileFormatVersion(session, 3)
    expect(result.cleared).toBe(false)
    expect(await readFormat(session)).toBeNull()
  })

  it('recordEntry stamps the current format onto newly-written snapshots', async () => {
    store.setFormatVersion(3)
    const file = await touch('stamp.txt', 'x')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'x' })
    expect(await readFormat(session)).toBe('3')
  })
})

describe('store-root default (harness-home resolution)', () => {
  const prevHome = process.env.DSH_HOME
  const prevOverride = process.env.DSH_REWIND_SNAPSHOT_DIR
  afterEach(() => {
    if (prevHome === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = prevHome
    if (prevOverride === undefined) delete process.env.DSH_REWIND_SNAPSHOT_DIR
    else process.env.DSH_REWIND_SNAPSHOT_DIR = prevOverride
  })

  it('follows $DSH_HOME when set', async () => {
    const home = await mkdtemp(join(tmpdir(), 'dsh-rewind-home-'))
    try {
      process.env.DSH_HOME = home
      expect(new SnapshotStore().root).toBe(join(home, 'rewind-snapshots'))
    } finally {
      await rm(home, { recursive: true, force: true })
    }
  })

  it('defaults under ~/.dsh when $DSH_HOME is unset', () => {
    delete process.env.DSH_HOME
    const s = new SnapshotStore()
    expect(isAbsolute(s.root)).toBe(true)
    expect(s.root.endsWith(join('.dsh', 'rewind-snapshots'))).toBe(true)
  })

  it('DSH_REWIND_SNAPSHOT_DIR env overrides the harness-home default', () => {
    process.env.DSH_HOME = join(tmpdir(), 'dsh-home-a')
    const override = join(tmpdir(), 'override')
    process.env.DSH_REWIND_SNAPSHOT_DIR = override
    expect(new SnapshotStore().root).toBe(override)
  })

  it('explicit root (snapshotDir) beats the env override', () => {
    process.env.DSH_REWIND_SNAPSHOT_DIR = join(tmpdir(), 'override')
    const explicit = join(tmpdir(), 'explicit')
    expect(new SnapshotStore(explicit).root).toBe(explicit)
  })

  it('opts.dshHome (config) beats $DSH_HOME for the default base', () => {
    process.env.DSH_HOME = join(tmpdir(), 'dsh-home-a')
    const configHome = join(tmpdir(), 'dsh-config')
    expect(new SnapshotStore(undefined, { dshHome: configHome }).root).toBe(join(configHome, 'rewind-snapshots'))
  })
})
