/**
 * Accident-scenario tests for the checkpoint store's crash safety
 * (src/snapshot.ts). Every scenario injects a crash at a concrete point —
 * a mid-checkpoint-commit, a mid-restore action, a delete, two consecutive
 * crashes — then re-instantiates the store (a host restart) and asserts that
 * journal reconciliation reports / finishes / undoes the op to a consistent
 * state. The properties under test:
 *
 *  - checkpoint commits are ATOMIC: a half-written crash commits nothing;
 *  - restore passes are JOURNALED: intent + per-action done-marks on disk;
 *  - reconcileRestores() reports "restored up to where, what changed" from
 *    the REAL disk (disk is truth, not the marks);
 *  - continueRestore() finishes an interrupted op deterministically;
 *  - rollbackRestore() returns the workspace to the exact pre-restore
 *    state, idempotently across repeated crashes;
 *  - journal corruption is reported fail-loud, journal IO failure is
 *    non-fatal, and journal files never disturb the existing store paths;
 *  - storage stays bounded: terminal journals are recycled by the same
 *    per-commit prune pass that enforces the 100-anchor-group cap, while
 *    crashed (running) and corrupt journals are never destroyed.
 */
import { chmod, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { SnapshotStore, type CrashPoint, type DiskProbe, type RestoreJournal, type RestoreRunOptions } from '../src/snapshot.ts'

let root: string
let store: SnapshotStore
const session = 'session-crash'

const unlink = async (path: string): Promise<void> => {
  await rm(path, { force: true })
}

beforeEach(async () => {
  root = await mkdtemp(join(tmpdir(), 'dsh-rewind-crash-'))
  store = new SnapshotStore(root)
})

afterEach(async () => {
  await rm(root, { recursive: true, force: true })
})

async function touch(rel: string, content: string): Promise<string> {
  const abs = join(root, 'ws', rel)
  await mkdir(join(root, 'ws'), { recursive: true })
  await writeFile(abs, content, 'utf8')
  return abs
}

/**
 * Crash-injection hook: throws at the given (point, index) to simulate a host
 * crash at exactly that spot. `index === undefined` fires on the first match.
 */
function crashAt(point: CrashPoint, index?: number): RestoreRunOptions {
  return {
    crash: (p, i) => {
      if (p === point && (index === undefined || i === index)) throw new Error('simulated host crash')
    },
  }
}

/** True for a journal file name of either format (current or released v1). */
function journalFileName(name: string): boolean {
  return (name.startsWith('journal-') || name.startsWith('restore-journal-')) && name.endsWith('.json')
}

/** Read the session's journal files (tests run at most a few ops per session). */
async function readJournals(store: SnapshotStore, sessionId: string): Promise<RestoreJournal[]> {
  const dir = store.sessionDir(sessionId)
  const names = (await readdir(dir)).filter(n => journalFileName(n))
  return Promise.all(names.map(async name => JSON.parse(await readFile(join(dir, name), 'utf8')) as RestoreJournal))
}

/** The raw bytes of one journal action's rescue copy. */
async function readRescue(action: RestoreJournal['actions'][number]): Promise<string | null> {
  const rescue = action.rescue as unknown as { blob?: string } | string | null
  if (rescue === null) return null
  const ref = typeof rescue === 'string' ? rescue : rescue.blob
  if (typeof ref !== 'string') return null
  return readFile(join(store.sessionDir(session), ref), 'utf8')
}

/**
 * The standard multi-action scenario: a (edited), b (edited), c (created) —
 * all backed up before their edits. The anchors are DISTINCT (6/5/4) so
 * `entriesAfter` sorts deterministically (anchorSeq desc) and the restore
 * actions are always [a-restore, b-restore, c-delete] — a crash at a given
 * action index is stable across runs.
 */
async function seedThreeFileScenario(): Promise<{ a: string; b: string; c: string }> {
  const a = await touch('a.txt', 'A0')
  const b = await touch('b.txt', 'B0')
  const c = await touch('c.txt', 'C0')
  await store.recordEntry(session, { callId: 'ca', anchorSeq: 6, path: a, before: 'A0' })
  await store.recordEntry(session, { callId: 'cb', anchorSeq: 5, path: b, before: 'B0' })
  await store.recordEntry(session, { callId: 'cc', anchorSeq: 4, path: c, before: null })
  await writeFile(a, 'A1', 'utf8')
  await writeFile(b, 'B1', 'utf8')
  await writeFile(c, 'C1', 'utf8')
  return { a, b, c }
}

describe('atomic checkpoint commits', () => {
  it('same-millisecond commits on one file still restore the FIRST capture', async () => {
    const file = await touch('f.txt', 'v0')
    // Freeze the clock so both captures land in the same millisecond: without
    // the monotonic bump the entries tie on `time` and earliestEntries would
    // depend on the filesystem's readdir order — restoring v1 (the later
    // capture) instead of v0. With the bump the capture order is
    // deterministic and reproducible after a re-read.
    vi.spyOn(Date, 'now').mockReturnValue(1_700_000_000_000)
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'v0' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 5, path: file, before: 'v1' })
    vi.restoreAllMocks()
    await writeFile(file, 'v2', 'utf8')

    const outcome = await store.restoreAfter(session, 5, unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('v0')
  })

  it('entry timestamps are strictly increasing within a store', async () => {
    const file = await touch('f.txt', 'v0')
    // Frozen clock: two captures in the same millisecond must still get
    // distinct, capture-ordered timestamps (deterministic assertion of the
    // monotonic bump — independent of any filesystem readdir order).
    vi.spyOn(Date, 'now').mockReturnValue(1_700_000_000_000)
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'v0' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 5, path: file, before: 'v1' })
    vi.restoreAllMocks()
    // entriesAfter returns newest first, so c2 (later capture) leads.
    const [later, earlier] = await store.entriesAfter(session, 5)
    expect(later!.time).toBeGreaterThan(earlier!.time)
  })

  it('a crash between the temp write and the rename commits no entry', async () => {
    const file = await touch('a.txt', 'original')
    await expect(
      store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' }, crashAt('after-temp-write')),
    ).rejects.toThrow('simulated host crash')

    // No committed entry: the crash left only the inert temp file, and the
    // reader never sees a half-written checkpoint. The sidecar may already be
    // in place — an ORPHAN is harmless (nothing references it), while the
    // opposite order (metadata without bytes) would be a broken backup.
    const anchorDir = store.anchorDir(session, 5)
    const names = await readdir(anchorDir)
    expect(names.filter(n => n.endsWith('.json'))).toEqual([])
    expect(names.some(n => n.endsWith('.tmp'))).toBe(true)
    expect(await store.entriesAfter(session, 5)).toEqual([])

    // The next commit of the same call id overwrites the leftover temp and
    // lands the entry atomically.
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'original' })
    expect(await store.entriesAfter(session, 5)).toHaveLength(1)
    const landed = (await readdir(anchorDir)).sort()
    expect(landed.filter(n => n.endsWith('.json'))).toHaveLength(1)
    expect(landed.filter(n => n.endsWith('.before'))).toHaveLength(1)
  })

  it('a planted half-written entry is ignored, never read as a checkpoint', async () => {
    const file = await touch('a.txt', 'original')
    const anchorDir = store.anchorDir(session, 5)
    await mkdir(anchorDir, { recursive: true })
    await writeFile(join(anchorDir, 'c1.json'), '{"callId":"c1","anchorSeq":5,"path":"/x","before":"orig', 'utf8')
    expect(await store.entriesAfter(session, 5)).toEqual([])
  })
})

describe('a crash mid-restore is journaled and reconciled after a host restart', () => {
  it('reports restored/pending from the real disk and continueRestore finishes the op', async () => {
    const { a, b, c } = await seedThreeFileScenario()
    // Crash right after the FIRST action's fs op (a restored on disk, but its
    // done-mark was never persisted): b and c are untouched.
    await expect(store.restoreAfter(session, 3, unlink, undefined, crashAt('after-action', 0))).rejects.toThrow('simulated host crash')
    expect(await readFile(a, 'utf8')).toBe('A0')
    expect(await readFile(b, 'utf8')).toBe('B1')
    expect(await readFile(c, 'utf8')).toBe('C1')

    // Host restart: the journal survives; the report derives from the disk.
    const restarted = new SnapshotStore(root)
    const reports = await restarted.reconcileRestores(session)
    expect(reports).toHaveLength(1)
    const report = reports[0]!
    expect(report.state).toBe('interrupted')
    expect(report.journalState).toBe('running')
    expect([...report.restored].sort()).toEqual([a])
    expect([...report.pending].sort()).toEqual([b, c])
    expect(report.failed).toEqual([])

    // continueRestore applies exactly what is still pending — the
    // already-restored a is marked done without being rewritten.
    const outcome = await restarted.continueRestore(session, report.opId, unlink)
    expect([...outcome.restored].sort()).toEqual([b])
    expect([...outcome.deleted].sort()).toEqual([c])
    expect(outcome.failed).toEqual([])
    expect(await readFile(a, 'utf8')).toBe('A0')
    expect(await readFile(b, 'utf8')).toBe('B0')
    expect(await store.exists(c)).toBe(false)
    expect(await restarted.reconcileRestores(session)).toEqual([])
  })

  it('rollbackRestore undoes the applied actions to the exact pre-restore state', async () => {
    const { a, b, c } = await seedThreeFileScenario()
    // Crash after the LAST action: all three landed (a restored, b restored,
    // c deleted), but only a and b got their done-marks persisted.
    await expect(store.restoreAfter(session, 3, unlink, undefined, crashAt('after-action', 2))).rejects.toThrow('simulated host crash')
    expect(await readFile(a, 'utf8')).toBe('A0')
    expect(await readFile(b, 'utf8')).toBe('B0')
    expect(await store.exists(c)).toBe(false)

    // The journal pins the per-action progress marks (done after each action).
    const journal = (await readJournals(store, session))[0]!
    expect(journal.state).toBe('running')
    expect(journal.actions.map(action => action.path)).toEqual([a, b, c])
    expect(journal.actions.map(action => action.done)).toEqual([true, true, false])
    // The rescue copies hold the PRE-restore bytes, on disk next to the journal.
    expect(await Promise.all(journal.actions.map(action => readRescue(action)))).toEqual(['A1', 'B1', 'C1'])

    // rollbackRestore: everything is returned to the pre-restore state —
    // including the delete that landed (c comes back) — regardless of the
    // done-marks.
    const restarted = new SnapshotStore(root)
    const rollback = await restarted.rollbackRestore(session, journal.id, unlink)
    expect([...rollback.restored].sort()).toEqual([a, b, c])
    expect(rollback.deleted).toEqual([])
    expect(rollback.failed).toEqual([])
    expect(await readFile(a, 'utf8')).toBe('A1')
    expect(await readFile(b, 'utf8')).toBe('B1')
    expect(await readFile(c, 'utf8')).toBe('C1')
    expect(await restarted.reconcileRestores(session)).toEqual([])
  })
})

describe('a crash around a delete action', () => {
  async function seedSingleDelete(): Promise<string> {
    const c = await touch('c.txt', 'C1')
    await store.recordEntry(session, { callId: 'cc', anchorSeq: 6, path: c, before: null })
    return c
  }

  it('crash before the delete: the file stays and redo removes it', async () => {
    const c = await seedSingleDelete()
    await expect(store.restoreAfter(session, 5, unlink, undefined, crashAt('before-action', 0))).rejects.toThrow('simulated host crash')
    expect(await store.exists(c)).toBe(true)

    const restarted = new SnapshotStore(root)
    const reports = await restarted.reconcileRestores(session)
    expect(reports[0]!.state).toBe('interrupted')
    expect([...reports[0]!.pending]).toEqual([c])
    expect(reports[0]!.restored).toEqual([])

    const outcome = await restarted.continueRestore(session, reports[0]!.opId, unlink)
    expect(outcome.deleted).toEqual([c])
    expect(await store.exists(c)).toBe(false)
    expect(await restarted.reconcileRestores(session)).toEqual([])
  })

  it('crash right after the unlink: the disk already matches and auto-heals', async () => {
    const c = await seedSingleDelete()
    await expect(store.restoreAfter(session, 5, unlink, undefined, crashAt('after-action', 0))).rejects.toThrow('simulated host crash')
    expect(await store.exists(c)).toBe(false)

    // The delete landed but the mark did not; reconcile trusts the disk, so
    // the op is already complete and heals itself — nothing to report.
    const restarted = new SnapshotStore(root)
    const journal = (await readJournals(restarted, session))[0]!
    expect(journal.actions[0]!.done).toBe(false)
    expect(await restarted.reconcileRestores(session)).toEqual([])
    expect((await readJournals(restarted, session))[0]!.state).toBe('completed')
  })
})

describe('two consecutive crashes stay consistent', () => {
  it('redo chain: restore crash -> continue crash -> continue completes', async () => {
    const { a, b, c } = await seedThreeFileScenario()
    // Crash 1: mid-restore after the first action.
    await expect(store.restoreAfter(session, 3, unlink, undefined, crashAt('after-action', 0))).rejects.toThrow('simulated host crash')
    // Crash 2: mid-continue, right after b's restore applied (a was skipped as
    // already matching the target).
    let first: SnapshotStore = new SnapshotStore(root)
    const reports1 = await first.reconcileRestores(session)
    expect(reports1).toHaveLength(1)
    await expect(
      first.continueRestore(session, reports1[0]!.opId, unlink, undefined, crashAt('after-action', 1)),
    ).rejects.toThrow('simulated host crash')

    // After the second crash: a and b already match the target, c is pending.
    const second = new SnapshotStore(root)
    const reports2 = await second.reconcileRestores(session)
    expect(reports2).toHaveLength(1)
    expect([...reports2[0]!.restored].sort()).toEqual([a, b])
    expect([...reports2[0]!.pending]).toEqual([c])

    // Finish: continueRestore completes the op and the disk is consistent.
    const outcome = await second.continueRestore(session, reports2[0]!.opId, unlink)
    expect(outcome.restored).toEqual([])
    expect(outcome.deleted).toEqual([c])
    expect(await readFile(a, 'utf8')).toBe('A0')
    expect(await readFile(b, 'utf8')).toBe('B0')
    expect(await store.exists(c)).toBe(false)
    expect(await second.reconcileRestores(session)).toEqual([])
  })

  it('rollback chain: restore crash -> rollback crash -> rollback finishes', async () => {
    const { a, b, c } = await seedThreeFileScenario()
    // Crash 1: mid-restore after the SECOND action (a and b restored — a
    // marked, b applied-but-unmarked — c untouched, so the op stays
    // reconcilable).
    await expect(store.restoreAfter(session, 3, unlink, undefined, crashAt('after-action', 1))).rejects.toThrow('simulated host crash')
    expect(await readFile(a, 'utf8')).toBe('A0')
    expect(await readFile(b, 'utf8')).toBe('B0')
    expect(await readFile(c, 'utf8')).toBe('C1')
    // Crash 2: mid-rollback right after a was written back to its rescue
    // content — the journal is left in 'rollback-running'.
    let first: SnapshotStore = new SnapshotStore(root)
    const journal = (await readJournals(first, session))[0]!
    const reports1 = await first.reconcileRestores(session)
    expect(reports1).toHaveLength(1)
    await expect(
      first.rollbackRestore(session, journal.id, unlink, undefined, crashAt('after-action', 0)),
    ).rejects.toThrow('simulated host crash')
    expect((await readJournals(first, session))[0]!.state).toBe('rollback-running')

    // After the second crash: a is back at rescue, b is still at the restore
    // target (pending rollback), c was never touched so it trivially matches
    // its rescue — the report says exactly that.
    const second = new SnapshotStore(root)
    const reports2 = await second.reconcileRestores(session)
    expect(reports2).toHaveLength(1)
    expect(reports2[0]!.journalState).toBe('rollback-running')
    expect([...reports2[0]!.restored].sort()).toEqual([a, c])
    expect([...reports2[0]!.pending]).toEqual([b])

    // Finish the rollback: the workspace returns to the exact pre-restore state.
    const outcome = await second.rollbackRestore(session, journal.id, unlink)
    expect([...outcome.restored].sort()).toEqual([b])
    expect(await readFile(a, 'utf8')).toBe('A1')
    expect(await readFile(b, 'utf8')).toBe('B1')
    expect(await readFile(c, 'utf8')).toBe('C1')
    expect(await second.reconcileRestores(session)).toEqual([])
  })
})

describe('reconciliation auto-heal and failure reporting', () => {
  it('a later successful rewind heals the interrupted journal on reconcile', async () => {
    const { a, b, c } = await seedThreeFileScenario()
    await expect(store.restoreAfter(session, 3, unlink, undefined, crashAt('after-action', 0))).rejects.toThrow('simulated host crash')

    // The user just rewinds again: the normal plan re-applies the remaining
    // actions (a already matches, so it is not planned)…
    const restarted = new SnapshotStore(root)
    const outcome = await restarted.restoreAfter(session, 3, unlink)
    expect([...outcome.restored].sort()).toEqual([b])
    expect([...outcome.deleted].sort()).toEqual([c])

    // …and the first reconcile sees the stale journal's goal fully reached:
    // it auto-heals to 'completed' instead of reporting a false interruption
    // (the healing rewind's own journal is 'completed' too).
    expect(await restarted.reconcileRestores(session)).toEqual([])
    const journals = await readJournals(restarted, session)
    expect(journals).toHaveLength(2)
    for (const journal of journals) expect(journal.state).toBe('completed')
  })

  it('a corrupt journal is reported recovery-required, never silently dropped', async () => {
    const sessionDir = store.sessionDir(session)
    await mkdir(sessionDir, { recursive: true })
    await writeFile(join(sessionDir, 'restore-journal-op-broken.json'), '{"version":1,"id":"op-broken","sessionId":"x",', 'utf8')

    const reports = await store.reconcileRestores(session)
    expect(reports).toHaveLength(1)
    expect(reports[0]!.state).toBe('recovery-required')
    expect(reports[0]!.opId).toBe('op-broken')
    expect(reports[0]!.corrupt).toBeDefined()
  })

  it('journal IO failure is non-fatal: the restore still applies everything', async () => {
    const a = await touch('a.txt', 'A0')
    await store.recordEntry(session, { callId: 'ca', anchorSeq: 5, path: a, before: 'A0' })
    await writeFile(a, 'A1', 'utf8')

    // Lock the session dir so the journal temp write fails with EACCES.
    const sessionDir = store.sessionDir(session)
    await chmod(sessionDir, 0o555)
    let blocked = true
    try {
      await writeFile(join(sessionDir, '.probe'), 'x')
      blocked = false
    } catch {
      // Expected: the directory is read-only.
    }
    await chmod(sessionDir, 0o755)
    if (!blocked) return // filesystem without meaningful chmod: nothing to assert

    await chmod(sessionDir, 0o555)
    try {
      const outcome = await store.restoreAfter(session, 5, unlink)
      expect(outcome.restored).toEqual([a])
      expect(outcome.failed).toEqual([])
      expect(await readFile(a, 'utf8')).toBe('A0')
      // No journal could be persisted: the degradation is invisible and the
      // store reports nothing to reconcile.
      expect(await store.reconcileRestores(session)).toEqual([])
    } finally {
      await chmod(sessionDir, 0o755)
    }
  })

  it('a failed rescue is reported and rollback leaves the path untouched', async () => {
    // The rescue (pre-restore state) is staged as raw bytes; when the copy
    // fails, the journal records a rescue error and a rollback skips the path
    // instead of guessing at the pre-restore content.
    const file = await touch('live.txt', 'text-before')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: file, before: 'text-before' })
    await writeFile(file, 'user-edited', 'utf8')

    const failingCopyProbe: DiskProbe = {
      isLink: async () => false,
      matches: async () => false, // plan a restore (the content differs)
      copy: async () => ({ kind: 'failed', message: 'EACCES: cannot stage rescue' }),
    }

    await expect(
      store.restoreAfter(session, 5, unlink, failingCopyProbe, crashAt('before-action', 0)),
    ).rejects.toThrow('simulated host crash')
    const [journal] = await readJournals(store, session)
    expect(journal!.actions[0]!.rescue).toBeNull()
    expect(journal!.actions[0]!.rescueError).toContain('cannot stage rescue')

    const rollback = await store.rollbackRestore(session, journal!.id, unlink)
    expect(rollback.failed.map(f => f.path)).toEqual([file])
    expect(rollback.restored).toEqual([])
    expect(await readFile(file, 'utf8')).toBe('user-edited')
  })

  it('continues a legacy (v1) journal and rewrites it IN PLACE', async () => {
    const file = await touch('legacy.txt', 'v1-before')
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'c1.json'), JSON.stringify({
      callId: 'c1', anchorSeq: 5, path: file, before: 'v1-before', time: 1,
    }), 'utf8')
    await writeFile(file, 'v1-after', 'utf8')
    // An op the released v1 build interrupted: inline strings, legacy prefix.
    const sessionDir = store.sessionDir(session)
    await writeFile(join(sessionDir, 'restore-journal-op-legacy.json'), JSON.stringify({
      version: 1,
      id: 'op-legacy',
      sessionId: session,
      targetSeq: 5,
      startedAt: 1,
      state: 'running',
      actions: [{ path: file, action: 'restore', before: 'v1-before', rescue: 'v1-after', done: false }],
    }), 'utf8')

    const reports = await store.reconcileRestores(session)
    expect(reports).toHaveLength(1)
    expect(reports[0]!.pending).toEqual([file])

    const outcome = await store.continueRestore(session, 'op-legacy', unlink)
    expect(outcome.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('v1-before')

    // Same file, rewritten in the current format — never two divergent copies.
    const names = (await readdir(sessionDir)).filter(n => journalFileName(n))
    expect(names).toEqual(['restore-journal-op-legacy.json'])
    expect((JSON.parse(await readFile(join(sessionDir, names[0]!), 'utf8')) as { version: number }).version).toBe(2)
  })

  it('rolls back a legacy (v1) journal to its inline rescue content', async () => {
    const file = await touch('legacy-rollback.txt', 'pre-restore')
    await mkdir(store.anchorDir(session, 5), { recursive: true })
    await writeFile(join(store.anchorDir(session, 5), 'c1.json'), JSON.stringify({
      callId: 'c1', anchorSeq: 5, path: file, before: 'target', time: 1,
    }), 'utf8')
    const sessionDir = store.sessionDir(session)
    await writeFile(join(sessionDir, 'restore-journal-op-rb.json'), JSON.stringify({
      version: 1,
      id: 'op-rb',
      sessionId: session,
      targetSeq: 5,
      startedAt: 1,
      state: 'running',
      actions: [{ path: file, action: 'restore', before: 'target', rescue: 'pre-restore', done: true }],
    }), 'utf8')
    await writeFile(file, 'target', 'utf8') // the restore had already landed

    const rollback = await store.rollbackRestore(session, 'op-rb', unlink)
    expect(rollback.restored).toEqual([file])
    expect(await readFile(file, 'utf8')).toBe('pre-restore')
  })

  it('keeps the sidecars a non-terminal journal needs (redo survives prune)', async () => {
    // A journal references its target content by sidecar path. Prune must not
    // evict that content while the op is unfinished, or the advertised
    // "continue finishes the interrupted restore" stops working.
    const live = await touch('pinned.txt', 'A0')
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 5, path: live, before: 'A0' })
    await writeFile(live, 'A1', 'utf8')
    await expect(
      store.restoreAfter(session, 5, unlink, undefined, crashAt('before-action', 0)),
    ).rejects.toThrow('simulated host crash')

    // Push the referenced group far outside the keep window.
    for (const seq of [6, 7, 8]) {
      const other = await touch(`other-${seq}.txt`, 'x')
      await store.recordEntry(session, { callId: `o${seq}`, anchorSeq: seq, path: other, before: 'x' })
    }
    await store.prune(session, 1)

    const reports = await store.reconcileRestores(session)
    expect(reports).toHaveLength(1)
    const outcome = await store.continueRestore(session, reports[0]!.opId, unlink)
    expect(outcome.failed).toEqual([])
    expect(outcome.restored).toEqual([live])
    expect(await readFile(live, 'utf8')).toBe('A0')
  })

  it('journal files never disturb entriesAfter/prune; terminal ones are recycled', async () => {
    const a = await touch('a.txt', 'A0')
    for (let seq = 1; seq <= 3; seq++) {
      await store.recordEntry(session, { callId: `c${seq}`, anchorSeq: seq, path: a, before: 'A0' })
    }
    await writeFile(a, 'A1', 'utf8')
    await store.restoreAfter(session, 1, unlink) // writes a completed journal
    await store.prune(session, 1) // drops anchor groups 1..2

    expect(await store.entriesAfter(session, 1)).toHaveLength(1) // seq 3 kept
    expect(await store.reconcileRestores(session)).toEqual([])
    // The completed journal was recycled by the prune pass: journal files
    // never confuse planning, and the storage cap now bounds them too.
    expect((await readdir(store.sessionDir(session))).some(n => journalFileName(n))).toBe(false)

    // A second restore still works.
    await writeFile(a, 'A2', 'utf8')
    const outcome = await store.restoreAfter(session, 1, unlink)
    expect(outcome.restored).toEqual([a])
    expect(await readFile(a, 'utf8')).toBe('A0')
  })

  it('repeated restores recycle terminal journals (bounded storage)', async () => {
    const a = await touch('a.txt', 'A0')
    await store.recordEntry(session, { callId: 'ca', anchorSeq: 5, path: a, before: 'A0' })
    for (let round = 1; round <= 4; round++) {
      await writeFile(a, `A${round}`, 'utf8')
      await store.restoreAfter(session, 5, unlink) // one completed journal each
      expect(await readFile(a, 'utf8')).toBe('A0')
    }
    // Every pass recycled the earlier terminal journals: at most the newest
    // one survives, never one journal per rewind.
    expect((await readdir(store.sessionDir(session))).filter(n => journalFileName(n))).toHaveLength(1)
    expect(await store.reconcileRestores(session)).toEqual([])
  })

  it('prune recycles completed journals but keeps crashed (running) ones', async () => {
    const a = await touch('a.txt', 'A0')
    await store.recordEntry(session, { callId: 'ca', anchorSeq: 5, path: a, before: 'A0' })
    await writeFile(a, 'A1', 'utf8')
    // A crashed restore leaves a running journal…
    await expect(store.restoreAfter(session, 5, unlink, undefined, crashAt('before-action', 0))).rejects.toThrow('simulated host crash')
    // …then a normal restore completes a second one (beginRestore keeps the
    // running journal — only terminal journals are recycled).
    await store.restoreAfter(session, 5, unlink)

    const journalNames = async () => (await readdir(store.sessionDir(session))).filter(n => journalFileName(n))
    expect(await journalNames()).toHaveLength(2)
    await store.prune(session, 1)
    expect(await journalNames()).toHaveLength(1) // completed recycled, running kept
    const kept = (await readJournals(store, session))[0]!
    expect(kept.state).toBe('running')
    // The surviving crashed op is still reconcilable; since the later normal
    // restore already reached the same target on disk, reconcile auto-heals
    // it to 'completed' instead of reporting a false interruption.
    expect(await store.reconcileRestores(session)).toEqual([])
    expect((await readJournals(store, session))[0]!.state).toBe('completed')
  })

  it('corrupt journals are never recycled', async () => {
    const sessionDir = store.sessionDir(session)
    await mkdir(sessionDir, { recursive: true })
    await writeFile(join(sessionDir, 'restore-journal-op-broken.json'), '{"version":1,"id":"op-broken","sessionId":"x",', 'utf8')
    await store.prune(session, 1)
    // An unclassifiable journal is kept: destroying it could erase the only
    // recovery record of an interrupted restore.
    expect(await store.reconcileRestores(session)).toHaveLength(1)
  })

  it('a crash during prune materialization is safe: the link still resolves and a retry finishes', async () => {
    const a = await touch('a.txt', 'A0')
    // A chain of identical content across 3 anchors: c1 real, c2/c3 links.
    await store.recordEntry(session, { callId: 'c1', anchorSeq: 1, path: a, before: 'A0' })
    await store.recordEntry(session, { callId: 'c2', anchorSeq: 2, path: a, before: 'A0' })
    await store.recordEntry(session, { callId: 'c3', anchorSeq: 3, path: a, before: 'A0' })
    // Crash right after the materialization temp write, before the rename.
    await expect(store.prune(session, 1, { crash: crashAt('after-temp-write').crash })).rejects.toThrow('simulated host crash')
    // The doomed real (group 1) is still on disk and c3 (a kept link) still
    // resolves — nothing dangled, the store is fully usable.
    await writeFile(a, 'A1', 'utf8')
    const beforeRetry = await store.restoreAfter(session, 3, unlink)
    expect(beforeRetry.restored).toEqual([a])
    expect(await readFile(a, 'utf8')).toBe('A0')
    // A clean retry materializes then drops the oldest group; no dangling link.
    await store.prune(session, 1)
    const after = await store.entriesAfter(session, 1)
    expect(after).toHaveLength(1)
    expect('ref' in after[0]!).toBe(false) // materialized to a real snapshot
    await writeFile(a, 'A2', 'utf8')
    const outcome = await store.restoreAfter(session, 1, unlink)
    expect(outcome.restored).toEqual([a])
    expect(await readFile(a, 'utf8')).toBe('A0')
  })

  it('deleting the data directory leaves a clean store that rebuilds from scratch', async () => {
    // A dedicated snapshot root, separate from the workspace files, so the
    // wipe below removes ONLY the plugin's own data (like deleting
    // ~/.dsh/rewind-snapshots in production).
    const snapRoot = join(root, 'snapshots')
    const s = new SnapshotStore(snapRoot)
    const a = await touch('a.txt', 'A0')
    await s.recordEntry(session, { callId: 'ca', anchorSeq: 5, path: a, before: 'A0' })
    await writeFile(a, 'A1', 'utf8')
    await s.restoreAfter(session, 5, unlink)
    expect((await readdir(s.sessionDir(session))).some(n => journalFileName(n))).toBe(true)

    // The user deletes the plugin data directory: ALL plugin-owned state
    // (checkpoints + journals) lives under this single root and disappears
    // together. Every read path treats the missing root as empty…
    await rm(snapRoot, { recursive: true, force: true })
    expect(await s.reconcileRestores(session)).toEqual([])
    expect(await s.entriesAfter(session, 5)).toEqual([])
    expect(await s.restoreAfter(session, 5, unlink)).toEqual({ restored: [], deleted: [], skipped: [], failed: [] })

    // …and nothing is left half-initialized: new captures and restores work
    // from a fresh, clean store.
    await writeFile(a, 'A2', 'utf8')
    await s.recordEntry(session, { callId: 'cb', anchorSeq: 6, path: a, before: 'A1' })
    const outcome = await s.restoreAfter(session, 6, unlink)
    expect(outcome.restored).toEqual([a])
    expect(await readFile(a, 'utf8')).toBe('A1')
  })
})
