import test from 'node:test';
import assert from 'node:assert/strict';
import { parseOfficialPrices, synchronizePrices, fetchOfficialPrices } from '../src/official-prices.mjs';
import { UsageMonitor, usageCost, normalizeMonitorSettings } from '../src/usage-monitor.mjs';
import { convertCosts } from '../src/billing-units.mjs';
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { fetchWindowsPricePage } from '../src/fetch-price-page.mjs';

test('Windows Desktop execFile wrapper without a custom promisify symbol returns the price page', { skip: process.platform !== 'win32' }, async () => {
  const original = childProcess.execFile;
  try {
    childProcess.execFile = (file, args, options, callback) => {
      assert.equal(file, 'powershell.exe');
      assert.equal(options.windowsHide, true);
      assert.match(args.at(-1), /https:\/\/ai\.google\.dev\/gemini-api\/docs\/pricing/);
      queueMicrotask(() => callback(null, '<table>official prices</table>', ''));
    };
    syncBuiltinESMExports();
    assert.equal(await fetchWindowsPricePage('google'), '<table>official prices</table>');
    childProcess.execFile = (_file, _args, _options, callback) => queueMicrotask(() => callback(null, '', ''));
    syncBuiltinESMExports();
    await assert.rejects(fetchWindowsPricePage('google'), /页面为空/);
  } finally { childProcess.execFile = original; syncBuiltinESMExports(); }
});

// Synthetic small tables exercise shape, not vendor price constants.
const deepseek = `<table><tr><th colspan="3">MODEL</th><th>deepseek-test</th></tr><tr><td rowspan="6">PRICING</td><td rowspan="2">1M INPUT TOKENS (CACHE HIT)</td><td>OFF-PEAK</td><td>$0.01</td></tr><tr><td>PEAK</td><td>$0.02</td></tr><tr><td rowspan="2">1M INPUT TOKENS (CACHE MISS)</td><td>OFF-PEAK</td><td>$1</td></tr><tr><td>PEAK</td><td>$2</td></tr><tr><td rowspan="2">1M OUTPUT TOKENS</td><td>OFF-PEAK</td><td>$3</td></tr><tr><td>PEAK</td><td>$6</td></tr></table>`;
const tagged = rows => [1, rows.map(row => [1, row.map(cell => [0, cell])])];
const openai = `<astro-island opts="TextTokenPricingTables" props="${JSON.stringify({ tier: [0, 'standard'], rows: tagged([['gpt-test', 2, .2, 2.5, 8], ['gpt-legacy', 3, .3, 9]]) }).replaceAll('"', '&quot;')}"><table><tr><th>Model</th><th>Input</th><th>Cached input</th><th>Cache writes</th><th>Output</th><th>Input</th><th>Cached input</th><th>Cache writes</th><th>Output</th></tr><tr><td>gpt-test</td><td>$2</td><td>$0.2</td><td>$2.5</td><td>$8</td><td>$4</td><td>$0.4</td><td>$5</td><td>$12</td></tr></table></astro-island>`;
test('official DeepSeek parser keeps model columns, cache categories and peak/off-peak separate', () => {
  const prices = parseOfficialPrices('deepseek', deepseek, 123);
  assert.equal(prices.length, 2); const peak = prices.find(p => p.tariff === 'peak');
  assert.equal(peak.model, 'deepseek-test'); assert.equal(peak.input, 2); assert.equal(peak.output, 6); assert.equal(peak.cacheRead, .02); assert.equal(peak.currency, 'USD'); assert.equal(peak.syncedAt, 123);
});
test('official OpenAI parser identifies service tier, context tier and both four/five-column model data', () => {
  const prices = parseOfficialPrices('openai', openai);
  assert.equal(prices.find(p => p.model === 'gpt-test' && p.tariff === 'standard:long').output, 12);
  assert.equal(prices.find(p => p.model === 'gpt-test' && p.tariff === 'standard:short').cacheWrite, 2.5);
  assert.equal(prices.find(p => p.model === 'gpt-legacy').output, 9);
  assert.equal(prices.find(p => p.model === 'gpt-legacy').cacheWrite, null);
});
test('Anthropic cache TTL and OpenRouter per-token denominators are explicit', () => {
  const html = `<table><tr><td>Claude Example 7.2</td><td>$2 / MTok</td><td>$10 / MTok</td><td>$2.5 / MTok</td><td>$4 / MTok</td><td>$0.2 / MTok</td></tr></table>`;
  const prices = parseOfficialPrices('anthropic', html);
  assert.equal(prices[0].model, 'claude-example-7-2'); assert.equal(prices[0].cacheWrite, 2.5); assert.equal(prices[1].cacheWrite, 4);
  const router = parseOfficialPrices('openrouter', JSON.stringify({ data: [{ id: 'vendor/test', pricing: { prompt: '.000002', completion: '.00001' } }] }));
  assert.equal(router[0].input, 2); assert.equal(router[0].output, 10);
});
test('Google paid text tariffs follow effective dates and never include audio or cache storage charges as token prices', () => {
  const html = `<h2>Gemini Example</h2><code>gemini-example</code><h3>Standard</h3><table><tr><td>Input price</td><td>Free of charge</td><td>$1 through December 31, 2026. $2 starting January 1, 2027.</td></tr><tr><td>Output price (including thinking)</td><td>Free of charge</td><td>$4 through December 31, 2026. $8 starting January 1, 2027.</td></tr><tr><td>Context caching price</td><td>Not available</td><td>$0.1 (text) $9 (audio) $30 per hour (storage price)</td></tr></table>`;
  const before = parseOfficialPrices('google', html, Date.parse('2026-10-19T00:00:00Z'))[0];
  const after = parseOfficialPrices('google', html, Date.parse('2027-01-02T00:00:00Z'))[0];
  assert.equal(before.input, 1); assert.equal(before.output, 4); assert.equal(before.cacheRead, .1); assert.equal(before.tariff, 'standard:text');
  assert.equal(after.input, 2); assert.equal(after.output, 8); assert.equal(after.cacheWrite, null);
});
test('sync never aliases unknown models, overwrites manual rates, or loses last known prices on failure', async () => {
  const settings = normalizeMonitorSettings({ prices: [{ provider: 'p', model: 'actual', mode: 'official', source: 'deepseek', sourceModel: 'deepseek-test', tariff: 'peak', input: 8, output: 9 }, { provider: 'custom', model: 'actual', input: 15, output: 20 }, { provider: 'q', model: 'unknown', mode: 'official', source: 'deepseek', tariff: 'peak' }] });
  const result = await synchronizePrices(settings, async () => ({ ok: true, text: async () => deepseek }));
  assert.equal(result.settings.prices[0].input, 2); assert.equal(result.settings.prices[0].model, 'actual'); assert.equal(result.settings.prices[1].input, 15);
  assert.ok(result.settings.prices[2].syncError); assert.equal(result.settings.prices[2].input, null);
  const failed = await synchronizePrices(settings, async () => { throw new Error('offline'); });
  assert.equal(failed.settings.prices[0].input, 8); assert.match(failed.settings.prices[0].syncError, /offline/);
});
test('official fetch uses fixed public endpoint and sends neither authorization nor user data', async () => {
  await fetchOfficialPrices('deepseek', async (url, options) => { assert.equal(url, 'https://api-docs.deepseek.com/quick_start/pricing/'); assert.equal(options.redirect, 'error'); assert.deepEqual(Object.keys(options.headers), ['Accept']); assert.equal(options.body, undefined); return { ok: true, text: async () => deepseek }; });
  await assert.rejects(fetchOfficialPrices('http://localhost/secret'), /来源/);
  assert.throws(() => parseOfficialPrices('deepseek', '<html>changed</html>'), /保留/);
});
test('custom Token denominators and display units retain original currency and historical tariff snapshots', () => {
  assert.equal(usageCost({ inputTokens: 1000, outputTokens: 2000 }, { input: 2, output: 4, unitTokens: 1000 }), 10);
  assert.deepEqual(convertCosts({ USD: 2, CNY: 3 }, { moneyUnit: '积分', rates: { USD: 100, CNY: 10 } }), { '积分': 230 });
  assert.deepEqual(convertCosts({ USD: 2, CNY: 3 }, { moneyUnit: '积分', rates: { USD: 100 } }), { '积分': 200, CNY: 3 });
  const monitor = new UsageMonitor();
  const initial = { display: { moneyUnit: '积分', rates: { USD: 100 }, tokenDivisor: 1000, tokenLabel: 'K Token' }, prices: [{ provider: 'p', model: 'm', input: 2, output: 4, unitTokens: 1000, currency: 'USD' }] };
  monitor.configure('s', { settings: initial, budget: 500, expectedRevision: 0 });
  const call = monitor.begin({ provider: 'p', model: 'm' }, { sessionId: 's' });
  monitor.configure('s', { settings: { ...initial, display: { moneyUnit: 'USD' }, prices: [{ ...initial.prices[0], input: 20 }] }, budget: 500, preserveBudget: true, expectedRevision: 1 });
  monitor.chunk(call, { type: 'usage', usage: { inputTokens: 1000, outputTokens: 0 } }); monitor.end(call);
  const snapshot = monitor.snapshot('s');
  assert.equal(call.cost, 2); assert.equal(call.currency, 'USD'); assert.equal(snapshot.budget.currency, '积分'); assert.equal(snapshot.budget.spent, 200);
  assert.equal(snapshot.settings.prices[0].input, 20); assert.equal(snapshot.budget.limit, 500);
});
