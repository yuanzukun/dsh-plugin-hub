import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { LeadWorkerHostService } from '../src/host.mjs';
import { normalizeWorkflow, workflowTemplates } from '../src/workflow.mjs';
import { builtinWorkflowSkills, renderNodeSkills } from '../src/workflow-skills.mjs';
import { TeamBoard } from '../src/core.mjs';

const members = ['a', 'b', 'q'].map(id => ({ id, name: id, provider: 'fake', model: id, role: 'implementation', instructions: '', enabled: true, readOnly: id === 'q' }));
const config = { enabled: true, mode: 'mixed', bossDirect: true, confirmPlan: true, maxParallel: 2, maxRetries: 2, members };
function fixture(t, extras = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'workflow-skills-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const parent = { ctx: {}, options: { provider: 'fake', model: 'a' }, session: { header: { id: 's' } } };
  const ctx = { profileContext: { dir }, logger: { info() {}, warn() {}, error() {} }, inject() {}, get(name) { return this[name]; }, agents: { get: id => id === 's' ? parent : undefined }, ...extras };
  const create = () => new LeadWorkerHostService(ctx, { defaultConfig: config });
  return { host: create(), create, ctx, parent };
}
const original = { id: 't', title: '任务', instructions: '完成目标', acceptance: ['行为正确'], memberId: 'a', writeScopes: ['src/'] };

test('Skill library survives restart; stale edits fail and library changes cannot rewrite applied node snapshots', async t => {
  const { host, create } = fixture(t);
  let library = await host.handleAction('s', 'workflowSkillSave', { skill: { name: '约定', content: '核对验收编号 SKILL-ONE' }, expectedSkillsRevision: 0 });
  const skill = library.skills.find(item => item.source === 'workflow');
  const definition = workflowTemplates(members)[0]; definition.nodes[0].skills = [skill];
  const board = host.getOrCreateBoard('s'); board.plan([original]); board.attachWorkflow('t', definition);
  await assert.rejects(host.handleAction('s', 'workflowSkillSave', { skillId: skill.id, skill: { ...skill, content: 'new' }, expectedSkillsRevision: 0 }), /已更新/);
  await host.handleAction('s', 'workflowSkillSave', { skillId: skill.id, skill: { ...skill, content: 'SKILL-TWO' }, expectedSkillsRevision: 1 });
  assert.equal(create().getWorkflowSkills().skills.find(item => item.id === skill.id).content, 'SKILL-TWO');
  await host.handleAction('s', 'workflowSkillDelete', { skillId: skill.id, expectedSkillsRevision: 2 });
  assert.match(renderNodeSkills(board.snapshot().tasks[0].workflow.definition.nodes[0]), /SKILL-ONE/);
  assert.equal(fixture(t).host.getWorkflowSkills().skills.length, builtinWorkflowSkills().length);
});

test('native Skill lookup uses the current agent scope and cwd, preserves resource base and rejects unavailable user invocations', async t => {
  let observed;
  const definition = { name: 'repo-style', description: '仓库约定', content: '读取 references/style.md', invocation: { userInvocable: true }, resourceBase: { kind: 'directory', path: 'C:/repo/skills/style' } };
  const { host, parent } = fixture(t, { workingDirectory: { ensure: async agent => { assert.equal(agent, parent); return 'C:/repo'; } }, skills: { list: async options => { observed = options; return [definition, { name: 'hidden', invocation: { userInvocable: false } }]; }, get: async name => name === definition.name ? definition : undefined } });
  const catalog = await host.handleAction('s', 'workflowSkillCatalog', {});
  assert.deepEqual(catalog.nativeSkills.map(item => item.id), ['dsh:repo-style']);
  assert.equal(observed.cwd, 'C:/repo'); assert.equal(observed.scope, parent);
  const skill = await host.handleAction('s', 'workflowSkillResolve', { skillId: 'dsh:repo-style' });
  assert.deepEqual(skill.resourceBase, definition.resourceBase); assert.equal(skill.content, definition.content);
  await assert.rejects(host.handleAction('s', 'workflowSkillResolve', { skillId: 'dsh:hidden' }), /不可用/);
});

test('invalid duplicate Skill snapshots fail; Tang department routing retains Skill on every takeover step', () => {
  const definition = workflowTemplates(members)[3], skill = builtinWorkflowSkills()[1];
  definition.nodes.find(node => node.id === 'bingbu').skills = [skill, skill];
  assert.throws(() => normalizeWorkflow(definition), /唯一/);
  definition.nodes.find(node => node.id === 'bingbu').skills = [skill];
  definition.nodes.find(node => node.id === 'bingbu').modelSelection = 'simple';
  const board = new TeamBoard({ ...config, modelRouting: { enabled: true, classification: 'auto', simple: { memberId: 'a', maxReworks: 0 }, complex: { memberId: 'b', maxReworks: 1 }, autoEscalate: true, fallbacks: [] } });
  board.plan([original]); board.attachWorkflow('t', definition);
  const department = board.snapshot().tasks.find(task => task.orchestration?.nodeId === 'bingbu');
  assert.equal(department.workflow.definition.nodes.length, 2);
  assert.ok(department.workflow.definition.nodes.every(node => node.skills[0].content === skill.content));
});

test('official DSH 0.2.0 Skill lookup uses session.header.cwd without a workingDirectory service', async t => {
  let lookup;
  const { host, parent } = fixture(t, { skills: { list: async options => { lookup = options; return []; }, get: async () => undefined } });
  parent.session.header.cwd = 'C:/legacy-project';
  const result = await host.handleAction('s', 'workflowSkillCatalog', {});
  assert.equal(result.nativeError, ''); assert.equal(lookup.cwd, 'C:/legacy-project'); assert.equal(lookup.scope, parent);
});

test('worker prompt receives only current node Skill and its resource base, while the task scope remains unchanged', async t => {
  let request;
  const { host, parent } = fixture(t, { subagents: { async start(_kind, options) { request = options; return { id: 'child', result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: 'done' }] }), dispose: async () => {} }; } } });
  host.scheduleReadyTasks = async () => [];
  const board = host.getOrCreateBoard('s'); board.plan([original]);
  const definition = workflowTemplates(members)[0]; definition.nodes[0].reviewerId = null;
  definition.nodes[0].skills = [{ ...builtinWorkflowSkills()[1], content: 'PROMPT_SKILL_MARKER', resourceBase: { kind: 'directory', path: 'C:/skills/example' } }];
  board.attachWorkflow('t', definition); board.approve();
  await host.dispatchTask('s', 't', { agent: parent, signal: new AbortController().signal });
  assert.match(JSON.stringify(request.prompt), /PROMPT_SKILL_MARKER/); assert.match(JSON.stringify(request.prompt), /C:\/skills\/example/);
  assert.deepEqual(board.snapshot().tasks[0].writeScopes, ['src/']);
});
