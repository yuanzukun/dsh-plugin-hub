import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { LeadWorkerHostService } from '../src/host.mjs';
import { workflowTemplates, normalizeWorkflow } from '../src/workflow.mjs';

const members = ['worker', 'reviewer'].map((id, i) => ({ id, name: id, provider: 'mock', model: id, role: i ? 'review' : 'implementation', instructions: '', enabled: true, readOnly: Boolean(i) }));
const config = { enabled: true, mode: 'mixed', members, confirmPlan: true, maxParallel: 2, maxRetries: 2 };
const definition = () => ({ ...workflowTemplates(members)[0], name: '我的流程' });
function fixture(t) {
  const dir = mkdtempSync(join(tmpdir(), 'workflow-templates-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const ctx = { profileContext: { dir }, logger: { info(){}, warn(){}, error(){} }, inject(){}, get(key){ return this[key]; } };
  const create = () => new LeadWorkerHostService(ctx, { defaultConfig: config });
  return { host: create(), create };
}
test('Tang preset contains three departments, all six ministries, acceptance and report with editable instructions', () => {
  const tang = workflowTemplates(members)[3];
  assert.equal(tang.name, '三省六部'); assert.equal(tang.kind, 'orchestration'); assert.equal(tang.version, 2); assert.equal(tang.nodes.length, 12);
  assert.deepEqual(normalizeWorkflow(tang), tang);
  for (const office of ['中书省', '门下省', '尚书省', '吏部', '户部', '礼部', '兵部', '刑部', '工部']) assert.ok(tang.nodes.some(node => node.label.includes(office)));
  assert.ok(tang.nodes.every(node => node.instructions.length > 10));
  assert.ok(tang.nodes.filter(node => node.role === 'review').every(node => node.readOnly));
});
test('custom template persists across sessions and restarts, but stays in its Profile', async t => {
  const { host, create } = fixture(t);
  const saved = await host.handleAction('s', 'workflowTemplateSave', { definition: definition(), description: '复用流程', expectedTemplatesRevision: 0 });
  const item = saved.templates.find(template => template.id === saved.savedTemplateId);
  assert.match(item.id, /^user-template-/); assert.equal(item.description, '复用流程'); assert.equal(item.builtin, false);
  assert.deepEqual(host.getWorkflowTemplates('other'), host.getWorkflowTemplates('s'));
  assert.deepEqual(create().getWorkflowTemplates('other'), host.getWorkflowTemplates('s'));
  assert.equal(fixture(t).host.getWorkflowTemplates('s').templates.length, 5);
});
test('template updates use a library revision; stale, invalid and builtin edits are atomic', async t => {
  const { host } = fixture(t);
  const saved = await host.handleAction('s', 'workflowTemplateSave', { definition: definition(), expectedTemplatesRevision: 0 });
  const id = saved.savedTemplateId;
  const before = host.getWorkflowTemplates('s');
  await assert.rejects(host.handleAction('s', 'workflowTemplateSave', { templateId: id, definition: definition(), expectedTemplatesRevision: 0 }), /模板库已更新/);
  await assert.rejects(host.handleAction('s', 'workflowTemplateSave', { templateId: 'template-3', definition: definition(), expectedTemplatesRevision: 1 }), /复制/);
  await assert.rejects(host.handleAction('s', 'workflowTemplateSave', { templateId: id, definition: { ...definition(), edges: [{ source: 'missing', target: 'missing', condition: 'passed' }] }, expectedTemplatesRevision: 1 }), /连线/);
  assert.deepEqual(host.getWorkflowTemplates('s'), before);
  const updated = await host.handleAction('s', 'workflowTemplateSave', { templateId: id, definition: { ...definition(), name: '更新模板' }, expectedTemplatesRevision: 1 });
  assert.equal(updated.templates.find(item => item.id === id).version, 2);
});
test('applying and deleting templates preserve independent task and default copies', async t => {
  const { host } = fixture(t); const board = host.getOrCreateBoard('s');
  board.plan([{ id: 't', title: '旧任务', instructions: '执行', acceptance: '通过', memberId: 'worker', writeScopes: ['src/'] }]);
  const saved = await host.handleAction('s', 'workflowTemplateSave', { definition: definition(), expectedTemplatesRevision: 0 });
  const params = { templateId: saved.savedTemplateId, expectedTemplatesRevision: 1 };
  await host.handleAction('s', 'workflowTemplateApply', { ...params, target: 'default', expectedRevision: board.snapshot().revision });
  assert.equal(board.snapshot().tasks[0].workflow, null);
  await host.handleAction('s', 'workflowTemplateApply', { ...params, target: 'task', taskId: 't', expectedRevision: board.snapshot().revision });
  const attached = board.snapshot().tasks[0].workflow.definition;
  await host.handleAction('s', 'workflowTemplateDelete', params);
  assert.deepEqual(board.snapshot().tasks[0].workflow.definition, attached);
  assert.equal(board.snapshot().workflowDefault.id, params.templateId);
  assert.equal(host.getWorkflowTemplates('s').templates.some(item => item.id === params.templateId), false);
});
test('unavailable members cannot apply, and session-only routes cannot leak into reusable templates', async t => {
  const { host } = fixture(t); const board = host.getOrCreateBoard('s');
  const d = definition(); d.nodes[0].memberId = 'removed-member';
  const saved = await host.handleAction('s', 'workflowTemplateSave', { definition: d, expectedTemplatesRevision: 0 });
  await assert.rejects(host.handleAction('s', 'workflowTemplateApply', { templateId: saved.savedTemplateId, target: 'default', expectedTemplatesRevision: 1, expectedRevision: board.snapshot().revision }), /成员.*不可用/);
  assert.equal(board.snapshot().workflowDefault, null);
  d.nodes[0].memberId = 'task-route-private-session';
  await assert.rejects(host.handleAction('s', 'workflowTemplateSave', { definition: d, expectedTemplatesRevision: 1 }), /共享角色/);
});


test('layout direction survives reusable template persistence, while legacy definitions remain valid', async t => {
  const { host, create } = fixture(t);
  const horizontal = { ...definition(), layoutDirection: 'LR' };
  const saved = await host.handleAction('s', 'workflowTemplateSave', { definition: horizontal, expectedTemplatesRevision: 0 });
  assert.equal(create().getWorkflowTemplates('s').templates.find(item => item.id === saved.savedTemplateId).layoutDirection, 'LR');
  assert.equal(normalizeWorkflow(definition()).layoutDirection, undefined);
  assert.throws(() => normalizeWorkflow({ ...definition(), layoutDirection: 'sideways' }), /流程方向/);
});
