import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TeamBoard } from '../src/core.mjs';
import { LeadWorkerHostService } from '../src/host.mjs';
import { workflowTemplates, normalizeWorkflow } from '../src/workflow.mjs';
import { orchestrationPrompt } from '../src/orchestration.mjs';
import { workflowOverlaps, arrangeWorkflow } from '../client/graph-layout.mjs';

const members = ['frontend', 'backend', 'integrator', 'reviewer'].map((id, i) => ({ id, name: id, provider: 'offline', model: id, enabled: true, readOnly: i === 3, role: i === 3 ? 'review' : 'implementation', instructions: '' }));
const config = { enabled: true, mode: 'mixed', members, maxParallel: 3, maxRetries: 2, confirmPlan: false };
const preset = () => workflowTemplates(members).find(item => item.id === 'template-fullstack');
const original = { id: 'fullstack', title: '实现全栈功能', instructions: '在现有项目实现页面和真实 API', acceptance: ['界面与接口一致，关键路径有测试证据'], memberId: 'frontend', writeScopes: ['src/'] };
function fixture() {
  const definition = preset(), board = new TeamBoard(config);
  board.plan([original], 'user'); board.attachWorkflow(original.id, definition);
  const id = nodeId => board.snapshot().orchestrations.fullstack.taskIds[nodeId];
  const task = nodeId => board.snapshot().tasks.find(item => item.id === id(nodeId));
  const settle = (nodeId, output = '完成并附有真实测试结果') => { if (nodeId === 'fullstack-final-review' && output?.approved) output = { ...output, evidence: [{ requirementId: 'fullstack-R1', version: 1, status: 'verified', reference: '独立夹具验证原始需求及交付结果' }] }; board.start(id(nodeId)); board.finish(id(nodeId), { output: typeof output === 'string' ? output : JSON.stringify(output) }); board.review(id(nodeId), true); };
  const plan = { summary: '需求与验收清单', departments: definition.nodes.filter(n => n.stage === 'work').map(n => ({ nodeId: n.id, selected: true, reason: '完整全栈开发需要此职责', instructions: n.instructions, acceptance: [`完成 ${n.label}`], writeScopes: n.readOnly ? [] : [`src/${n.id}/`], dependencies: [] })) };
  const ready = () => { settle('fullstack-plan', plan); settle('fullstack-plan-review', { approved: true, feedback: '范围与依赖通过' }); settle('fullstack-dispatch'); };
  return { board, definition, id, task, settle, plan, ready };
}

test('fullstack preset is discoverable, copyable and normalized with valid members, Skills and non-overlapping cards', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'fullstack-library-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const ctx = { profileContext: { dir }, logger: { info() {}, warn() {}, error() {} }, inject() {}, get(key) { return this[key]; } };
  const host = new LeadWorkerHostService(ctx, { defaultConfig: config });
  const item = host.getWorkflowTemplates('s').templates.find(item => item.id === 'template-fullstack');
  assert.equal(item.name, '全栈开发团队'); assert.equal(item.builtin, true); assert.match(item.description, /前后端并行/);
  const definition = preset(); assert.equal(definition.nodes.length, 12); assert.deepEqual(normalizeWorkflow(definition), definition);
  assert.ok(definition.nodes.every(n => members.some(m => m.id === n.memberId && m.enabled)));
  assert.ok(definition.nodes.filter(n => n.role === 'review').every(n => n.readOnly));
  assert.ok(definition.nodes.find(n => n.id === 'fullstack-qa').skills.some(s => s.id === 'builtin-skill-regression'));
  assert.equal(workflowOverlaps(definition), false);
  assert.equal(workflowOverlaps(arrangeWorkflow(definition)), false);
  const saved = await host.handleAction('s', 'workflowTemplateSave', { definition, description: '我的全栈团队', expectedTemplatesRevision: 0 });
  assert.ok(saved.templates.find(item => item.id === saved.savedTemplateId && !item.builtin));
  assert.equal(workflowTemplates([]).length, 0);
  assert.ok(workflowTemplates([members[3]]).find(item => item.id === 'template-fullstack'));
});

test('contract and UX are real prerequisites; frontend and backend can run together before integration', () => {
  const { board, id, task, ready, settle } = fixture(); ready();
  assert.throws(() => board.start(id('fullstack-frontend')), /dependenc/i);
  assert.throws(() => board.start(id('fullstack-backend')), /dependenc/i);
  settle('fullstack-contract', 'CONTRACT: GET /items => {items: []}');
  assert.throws(() => board.start(id('fullstack-frontend')), /dependenc/i);
  settle('fullstack-ux', 'UX: loading, empty, error states');
  board.start(id('fullstack-frontend')); board.start(id('fullstack-backend'));
  assert.equal(task('fullstack-frontend').status, 'running'); assert.equal(task('fullstack-backend').status, 'running');
  assert.throws(() => board.start(id('fullstack-integration')), /dependenc/i);
  assert.throws(() => board.start(id('fullstack-qa')), /dependenc/i);
  assert.throws(() => board.start(id('fullstack-join')), /dependenc/i);
});

test('frontend rejection re-runs integration and QA while keeping accepted backend and design, then settles delivery', () => {
  const { board, task, ready, settle } = fixture(); ready();
  for (const node of ['contract', 'ux', 'frontend', 'backend', 'integration', 'qa', 'join']) settle(`fullstack-${node}`);
  settle('fullstack-final-review', { approved: false, feedback: '前端错误提示未实现', reworkNodeIds: ['fullstack-frontend'] });
  for (const node of ['frontend', 'integration', 'qa', 'join', 'final-review', 'report']) assert.equal(task(`fullstack-${node}`).status, 'pending', node);
  for (const node of ['backend', 'contract', 'ux']) assert.equal(task(`fullstack-${node}`).status, 'done', node);
  for (const node of ['frontend', 'integration', 'qa', 'join']) settle(`fullstack-${node}`);
  settle('fullstack-final-review', { approved: true, feedback: '全部需求与证据一致' }); settle('fullstack-report');
  assert.equal(board.snapshot().orchestrations.fullstack.status, 'done');
  assert.deepEqual(new TeamBoard(config, board.snapshot()).snapshot().orchestrations, board.snapshot().orchestrations);
});

test('complete-team mode explicitly instructs all roles and rejects a skipped frontend before any work starts', () => {
  const { board, definition, plan, settle, id, task } = fixture();
  assert.match(orchestrationPrompt(definition.nodes[0], definition, original), /全部工作节点必须 selected=true/);
  plan.departments.find(n => n.nodeId === 'fullstack-frontend').selected = false;
  settle('fullstack-plan', plan);
  const reviewId = id('fullstack-plan-review'); board.start(reviewId); board.finish(reviewId, { output: JSON.stringify({ approved: true, feedback: '通过' }) });
  const before = board.snapshot(); assert.throws(() => board.review(reviewId, true), /完整职责/); assert.deepEqual(board.snapshot(), before);
  assert.equal(task('fullstack-contract').executionEpoch, 0);
});

test('host executes the fullstack preset and passes full design artifacts to implementation and both sides to integration', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'fullstack-host-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const definition = preset(), captures = [], messages = [], errors = [];
  const plan = { summary: '按需求交付全栈功能', departments: definition.nodes.filter(n => n.stage === 'work').map(n => ({ nodeId: n.id, selected: true, reason: '完整分工', instructions: n.instructions, acceptance: ['结果可核实'], writeScopes: n.readOnly ? [] : [`src/${n.id}/`], dependencies: [] })) };
  let child = 0;
  const parent = { ctx: {}, status: 'idle', options: { provider: 'offline', model: 'controller' }, session: { header: { id: 's' } }, followup: async message => messages.push(message) };
  const ctx = { profileContext: { dir }, logger: { info() {}, warn(e) { errors.push(e); }, error(e) { errors.push(e); } }, inject() {}, get(key) { return this[key]; }, agents: { get: id => id === 's' ? parent : undefined }, subagents: { async start(_kind, request) {
    captures.push(request);
    const independent = request.label.startsWith('[独立验收]');
    const node = definition.nodes.find(n => request.label.endsWith(n.label));
    const output = independent ? JSON.stringify({ passed: true, feedback: '离线证据已核对', evidence: [] }) : node?.stage === 'plan' ? JSON.stringify(plan) : ['plan-review', 'final-review'].includes(node?.stage) ? JSON.stringify({ approved: true, feedback: '范围与真实结果通过', evidence: [{ requirementId: 'fullstack-R1', version: 1, status: 'verified', reference: '独立夹具核对界面接口与关键路径' }] }) : `ARTIFACT:${node?.id}:` + '完整交付证据'.repeat(140);
    return { id: `child-${++child}`, result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: output }] }), dispose: async () => {} };
  } } };
  const host = new LeadWorkerHostService(ctx, { defaultConfig: config }), board = host.getOrCreateBoard('s');
  board.plan([original], 'user'); board.attachWorkflow(original.id, definition);
  await host.handleAction('s', 'startOrchestration', { taskId: original.id, expectedRevision: board.snapshot().revision });
  const deadline = Date.now() + 5000;
  while (Date.now() < deadline && (!messages.length || board.snapshot().orchestrations.fullstack.status !== 'done')) await new Promise(resolve => setTimeout(resolve, 5));
  assert.equal(board.snapshot().orchestrations.fullstack.status, 'done', JSON.stringify(errors));
  const prompt = id => captures.find(r => r.label.startsWith('[Team ') && r.label.endsWith(definition.nodes.find(n => n.id === id).label))?.prompt.map(part => part.text).join('\n');
  assert.ok(prompt('fullstack-frontend').includes('ARTIFACT:fullstack-contract:'));
  assert.ok(prompt('fullstack-frontend').includes('ARTIFACT:fullstack-ux:'));
  assert.ok(prompt('fullstack-backend').includes('完整交付证据'.repeat(140)), 'upstream artifacts are not truncated to a short summary');
  for (const id of ['frontend', 'backend']) assert.ok(prompt('fullstack-integration').includes(`ARTIFACT:fullstack-${id}:`));
  assert.ok(messages.some(message => JSON.stringify(message).includes('全栈开发团队编排')));
});
