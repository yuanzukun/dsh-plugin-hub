import test from 'node:test';
import assert from 'node:assert/strict';
import { TeamBoard } from '../src/core.mjs';
import { workflowTemplates, normalizeWorkflow } from '../src/workflow.mjs';
import { LeadWorkerHostService } from '../src/host.mjs';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
const members = ['worker-a', 'worker-b', 'reviewer'].map((id, i) => ({ id, name: id, provider: 'offline', model: id, role: i === 2 ? 'review' : 'implementation', readOnly: i === 2, instructions: '', enabled: true }));
const config = { enabled: true, mode: 'mixed', members, maxParallel: 2, maxRetries: 2, confirmPlan: false };
const original = { id: 'root', title: '交付工程', instructions: '实现两个独立模块', acceptance: ['模块可用且通过测试'], memberId: 'worker-a', writeScopes: ['src/'] };
function fixture() {
  const board = new TeamBoard(config), definition = workflowTemplates(members)[3];
  definition.nodes.find(n => n.id === 'libu-interfaces').memberId = 'worker-b';
  board.plan([original], 'user'); board.attachWorkflow('root', definition);
  const taskId = nodeId => board.snapshot().orchestrations.root.taskIds[nodeId];
  const settle = (nodeId, output = '完成') => { if (nodeId === 'menxia-final' && output?.approved) output = { ...output, evidence: [{ requirementId: 'root-R1', version: 1, status: 'verified', reference: '独立夹具验证原始需求及交付结果' }] }; const id = taskId(nodeId); board.start(id); board.finish(id, { output: typeof output === 'string' ? output : JSON.stringify(output) }); return board.review(id, true); };
  const plan = dependencies => ({ departments: definition.nodes.filter(n => n.stage === 'work').map(node => ({ nodeId: node.id, selected: ['bingbu', 'libu-interfaces'].includes(node.id), reason: ['bingbu', 'libu-interfaces'].includes(node.id) ? '本任务需要实现此模块' : '本任务不涉及此职责', instructions: '实现独立模块并核对', acceptance: ['实现正确'], writeScopes: node.id === 'bingbu' ? ['src/core'] : node.id === 'libu-interfaces' ? ['src/ui'] : [], dependencies: node.id === 'libu-interfaces' && dependencies ? ['bingbu'] : [] })) });
  const ready = (dependencies = false) => { settle('zhongshu-plan', plan(dependencies)); settle('menxia-spec', { approved: true, feedback: '方案、范围、依赖已核实' }); settle('shangshu-plan'); };
  return { board, definition, taskId, settle, plan, ready };
}
test('Tang branches become real tasks; skipped roles never start, independent branches can run together', () => {
  const { board, ready, taskId } = fixture(); ready();
  const run = board.snapshot().orchestrations.root;
  assert.equal(Object.keys(run.skipped).length, 4);
  for (const id of Object.keys(run.skipped)) assert.equal(board.snapshot().tasks.find(t => t.id === taskId(id)).status, 'cancelled');
  board.start(taskId('bingbu')); board.start(taskId('libu-interfaces'));
  assert.equal(board.snapshot().tasks.filter(t => t.status === 'running').length, 2);
  assert.throws(() => board.start(taskId('shangshu-join')), /dependenc/i);
});
test('declared task dependency delays a department; a failed branch cannot satisfy the join', () => {
  const { board, ready, taskId, settle } = fixture(); ready(true);
  assert.throws(() => board.start(taskId('libu-interfaces')), /dependenc/i);
  settle('bingbu'); board.start(taskId('libu-interfaces')); board.finish(taskId('libu-interfaces'), { error: '执行失败' });
  assert.throws(() => board.start(taskId('shangshu-join')), /dependenc/i);
});
test('plan rejection rewinds only the gated plan, preserves history and has a separate rejection limit', () => {
  const { board, settle, plan, taskId } = fixture();
  for (let i = 0; i < 3; i++) {
    settle('zhongshu-plan', plan()); settle('menxia-spec', { approved: false, feedback: '需要补充验收依据' });
    if (i < 2) assert.equal(board.snapshot().tasks.find(t => t.id === taskId('zhongshu-plan')).status, 'pending');
  }
  const snapshot = board.snapshot();
  assert.equal(snapshot.orchestrations.root.planRejections, 3);
  assert.equal(snapshot.orchestrations.root.resultReworks, 0);
  assert.equal(snapshot.tasks.find(t => t.id === taskId('menxia-spec')).waitingReason, 'PLAN_REJECTION_LIMIT');
  assert.equal(snapshot.tasks.find(t => t.id === taskId('bingbu')).executionEpoch, 0, 'unstarted descendants do not acquire invented executions');
});
test('result rejection invalidates selected branch and its dependents, preserving independent accepted work', () => {
  const { board, ready, settle, taskId } = fixture(); ready();
  settle('bingbu'); settle('libu-interfaces'); settle('shangshu-join');
  settle('menxia-final', { approved: false, feedback: '核心实现有缺口', reworkNodeIds: ['bingbu'] });
  let snapshot = board.snapshot();
  assert.equal(snapshot.tasks.find(t => t.id === taskId('bingbu')).status, 'pending');
  assert.equal(snapshot.tasks.find(t => t.id === taskId('libu-interfaces')).status, 'done');
  assert.equal(snapshot.tasks.find(t => t.id === taskId('shangshu-join')).status, 'pending');
  settle('bingbu'); settle('shangshu-join'); settle('menxia-final', { approved: true, feedback: '原需求和实际结果一致' }); settle('zhongshu-report');
  assert.equal(board.snapshot().orchestrations.root.status, 'done');
  const restored = new TeamBoard(config, board.snapshot()).snapshot();
  assert.deepEqual(restored.orchestrations, board.snapshot().orchestrations);
});
test('malformed, cyclic or scope-expanding plan is rejected atomically before any branch starts', () => {
  for (const mutate of [plan => { plan.departments.pop(); }, plan => { plan.departments.find(d => d.nodeId === 'bingbu').writeScopes = ['../escape']; }, plan => { plan.departments.find(d => d.nodeId === 'bingbu').dependencies = ['libu-interfaces']; plan.departments.find(d => d.nodeId === 'libu-interfaces').dependencies = ['bingbu']; }]) {
    const { board, settle, plan, taskId } = fixture(); const value = plan(); mutate(value); settle('zhongshu-plan', value);
    const id = taskId('menxia-spec'); board.start(id); board.finish(id, { output: JSON.stringify({ approved: true, feedback: '同意' }) });
    const before = board.snapshot(); assert.throws(() => board.review(id, true)); assert.deepEqual(board.snapshot(), before);
  }
});
test('default orchestration expands new tasks and remains compatible with restart quarantine', () => {
  const board = new TeamBoard(config); board.setDefaultWorkflow(workflowTemplates(members)[3]); board.plan([original], 'user');
  assert.equal(board.snapshot().tasks.length, 12);
  const id = board.snapshot().orchestrations.root.taskIds['zhongshu-plan']; board.start(id);
  const restored = new TeamBoard(config, board.snapshot()).snapshot();
  assert.equal(restored.tasks.find(t => t.id === id).waitingReason, 'INTERRUPTED_RESTART');
  assert.equal(restored.status, 'paused');
});
test('execution graph requires valid stage order and independent review contexts', () => {
  const definition = workflowTemplates(members)[3];
  assert.throws(() => normalizeWorkflow({ ...definition, edges: [...definition.edges, { id: 'cycle', source: 'zhongshu-report', target: 'zhongshu-plan', condition: 'passed' }] }), /成环|顺序/);
});
test('department model tier, local budgets, escalation chain and explicit model lock survive outer orchestration', () => {
  const policy = { enabled: true, classification: 'auto', simple: { memberId: 'worker-a', maxReworks: 2 }, complex: { memberId: 'worker-b', maxReworks: 3 }, autoEscalate: true, fallbacks: [] };
  for (const locked of [false, true]) {
    const board = new TeamBoard({ ...config, modelRouting: policy }), definition = workflowTemplates(members)[3];
    const department = definition.nodes.find(n => n.id === 'bingbu'); department.modelSelection = 'simple'; department.maxReworks = 0; department.timeoutMs = 42;
    board.plan([{ ...original, locked, difficulty: 'complex', difficultyReason: '任务整体较复杂，但此部门为简单子任务' }], 'user');
    board.attachWorkflow('root', definition);
    const task = board.snapshot().tasks.find(t => t.orchestration.nodeId === 'bingbu'), first = task.workflow.definition.nodes.find(n => n.id === task.workflow.current);
    assert.equal(task.memberId, 'worker-a'); assert.equal(first.maxReworks, 0); assert.equal(first.timeoutMs, 42); assert.equal(first.reviewerId, 'reviewer');
    assert.equal(task.workflow.definition.nodes.length, locked ? 1 : 2);
  }
});
test('host scheduler runs a user-started orchestration with parallel workers and returns delivery to original conversation', async t => {
  const directory = mkdtempSync(join(tmpdir(), 'orchestration-host-')); t.after(() => rmSync(directory, { recursive: true, force: true }));
  const definition = workflowTemplates(members)[3]; definition.nodes.find(n => n.id === 'libu-interfaces').memberId = 'worker-b';
  let release; const hold = new Promise(resolve => { release = resolve; });
  let starts = 0; const errors = [], messages = [], labels = [];
  const parent = { ctx: {}, status: 'idle', options: { provider: 'offline', model: 'parent' }, session: { header: { id: 's' } }, followup: async message => { messages.push(message); } };
  const plan = { departments: definition.nodes.filter(n => n.stage === 'work').map(n => ({ nodeId: n.id, selected: ['bingbu', 'libu-interfaces'].includes(n.id), reason: '按任务范围选择', instructions: '实现并核对独立模块', acceptance: ['完成并核实'], writeScopes: n.id === 'bingbu' ? ['src/core'] : n.id === 'libu-interfaces' ? ['src/ui'] : [], dependencies: [] })) };
  const ctx = { profileContext: { dir: directory }, logger: { info() {}, warn(message) { errors.push(message); }, error(message) { errors.push(message); } }, inject() {}, get(name) { return this[name]; }, agents: { get: id => id === 's' ? parent : undefined }, subagents: { async start(_kind, request) {
    const label = request.label; labels.push(label); const id = `child-${++starts}`;
    const isWorker = !label.includes('独立验收') && /兵部|礼部/.test(label);
    const output = label.includes('独立验收') ? JSON.stringify({ passed: true, feedback: '真实夹具已核验', evidence: [] }) : label.includes('中书省 · 需求') ? JSON.stringify(plan) : /门下省/.test(label) ? JSON.stringify({ approved: true, feedback: '方案与交付符合原需求', evidence: [{ requirementId: 'root-R1', version: 1, status: 'verified', reference: '独立夹具验证原始需求' }] }) : '最终交付与实际结果';
    return { id, result: (async () => { if (isWorker) await hold; return { stopReason: 'completed', output: [{ type: 'text', text: output }] }; })(), dispose: async () => {} };
  } } };
  const host = new LeadWorkerHostService(ctx, { defaultConfig: config }), board = host.getOrCreateBoard('s');
  board.plan([original], 'user'); board.attachWorkflow('root', definition);
  board.appendTasks([{ ...original, id: 'unrelated', title: '未获授权的其他工作', writeScopes: ['other/'] }], 'user');
  const waitFor = async predicate => { const deadline = Date.now() + 5000; while (!predicate() && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 5)); assert.ok(predicate(), JSON.stringify({ errors, labels, tasks: board.snapshot().tasks.map(task => [task.id, task.status, task.waitingReason]), run: board.snapshot().orchestrations.root.status })); };
  await host.handleAction('s', 'startOrchestration', { taskId: 'root', expectedRevision: board.snapshot().revision });
  await waitFor(() => board.snapshot().tasks.filter(task => task.status === 'running' && task.orchestration?.stage === 'work').length === 2);
  assert.equal(board.snapshot().tasks.find(task => task.id === 'unrelated').status, 'pending');
  release();
  await waitFor(() => board.snapshot().orchestrations.root.status === 'done');
  await waitFor(() => messages.some(message => JSON.stringify(message).includes('最终交付与实际结果')));
  assert.equal(labels.filter(label => !label.includes('独立验收') && /户部|工部|刑部|吏部/.test(label)).length, 0);
  assert.equal(board.snapshot().tasks.find(task => task.id === 'unrelated').executionEpoch, 0);
});
