import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TeamBoard } from '../src/core.mjs';
import { LeadWorkerHostService } from '../src/host.mjs';
import { normalizeWorkflow, requirementLedger, workflowTemplates } from '../src/workflow.mjs';
import { normalizeModel, taskModel } from '../src/execution-model.mjs';
import { createLeadWorkerTools } from '../src/tools.mjs';

const model = normalizeModel({ provider: 'offline', model: 'shared' });
const config = { enabled: true, mode: 'mixed', members: [model], maxRetries: 2, confirmPlan: false };
const task = (id, extra = {}) => ({ id, title: id, instructions: '实现范围内的功能', acceptance: ['满足需求'], memberId: model.id, writeScopes: ['src/'], ...extra });
const node = (id, extra = {}) => ({ id, label: id, mode: 'worker', modelConfig: model, maxReworks: 0, ...extra });
const flow = (nodes, edges = [], extra = {}) => ({ id: 'flow', name: '业务流程', version: 1, entry: nodes[0].id, nodes, edges, ...extra });
function hostFixture(t, scheduling = false) {
  const dir = mkdtempSync(join(tmpdir(), 'product-fixes-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const ctx = { profileContext: { dir }, logger: { info() {}, warn() {}, error() {} }, inject() {}, get(key) { return this[key]; } };
  const host = new LeadWorkerHostService(ctx, { defaultConfig: config }); if (!scheduling) host.scheduleReadyTasks = async () => [];
  return { host, board: host.getOrCreateBoard('s'), ctx };
}
test('scope violations cannot be accepted through the real review entry', async t => {
  const { host, board } = hostFixture(t); board.plan([task('t')]); board.start('t'); board.finish('t', { output: '完成', files: ['outside/file.js'] });
  await host.reviewTask('s', { taskId: 't', passed: true, feedback: '请求通过' });
  assert.notEqual(board.snapshot().tasks[0].status, 'done');
  assert.match(board.snapshot().tasks[0].feedback, /范围|scope|违规/);
});
test('ordinary rejection follows its declared edge and explicit loops remain bounded', () => {
  const board = new TeamBoard(config); board.plan([task('t')]);
  board.attachWorkflow('t', flow([node('review'), node('fix')], [{ source: 'review', target: 'fix', condition: 'rejected' }, { source: 'fix', target: 'review', condition: 'passed' }]));
  board.start('t'); board.finish('t', { output: '失败' }); board.review('t', false, '需要修复');
  assert.equal(board.snapshot().tasks[0].workflow.current, 'fix');
  board.start('t'); board.finish('t', { output: '已修复' }); board.review('t', true);
  board.start('t'); board.finish('t', { output: '仍有缺口' }); board.review('t', false);
  assert.equal(board.snapshot().tasks[0].waitingReason, 'WORKFLOW_LOOP_LIMIT');
});
test('latest trusted correction resolves a gap without self-report overriding it', () => {
  const board = new TeamBoard(config); board.plan([task('t')]); board.attachWorkflow('t', flow([node('execute')])); board.start('t');
  const record = { requirementId: 't-R1', version: 1, reference: '实际检查结果' };
  board.recordRequirementEvidence('t', { ...record, status: 'gap' });
  board.recordRequirementEvidence('t', { ...record, status: 'verified' }, 'self-reported');
  assert.equal(requirementLedger(board.snapshot().tasks[0])[0].status, 'gap');
  board.recordRequirementEvidence('t', { ...record, status: 'verified' }, 'user');
  assert.equal(requirementLedger(board.snapshot().tasks[0])[0].status, 'verified');
  assert.equal(board.snapshot().tasks[0].requirementEvidence.length, 3);
});
test('applied model and reviewer routes survive catalog edits, removal and restart', () => {
  const board = new TeamBoard(config); board.plan([task('t')]);
  board.attachWorkflow('t', flow([node('execute', { reviewerId: model.id })]));
  board.reconfigure({ ...config, members: [{ ...model, model: 'replacement' }] });
  assert.equal(taskModel(board.snapshot().tasks[0], board.config.members).model, 'shared');
  board.reconfigure({ ...config, members: [] });
  const restored = new TeamBoard({ ...config, members: [] }, board.snapshot());
  restored.start('t');
  assert.equal(taskModel(restored.snapshot().tasks[0], []).model, 'shared');
  assert.equal(taskModel(restored.snapshot().tasks[0], [], true).model, 'shared');
});
test('same model runs independent instances and migrates away from legacy capacity limits', () => {
  const board = new TeamBoard({ ...config, maxParallel: 1 });
  board.plan([task('front', { writeScopes: ['src/front'] }), task('back', { writeScopes: ['src/back'] }), task('overlap', { writeScopes: ['src/front'] })]);
  board.start('front'); board.start('back');
  assert.equal(board.snapshot().tasks.filter(t => t.status === 'running').length, 2);
  assert.throws(() => board.start('overlap'), e => e.code === 'WRITE_SCOPE_CONFLICT');
  assert.equal(Object.hasOwn(board.config, 'maxParallel'), false);
});
test('free branch and join graph becomes actual tasks with per-node scopes and same-model parallelism', () => {
  const board = new TeamBoard(config); board.plan([task('root')]);
  const definition = flow([node('design', { readOnly: true }), node('front', { writeScopes: ['src/front'] }), node('back', { writeScopes: ['src/back'] }), node('delivery', { role: 'review' })], [
    ['design', 'front'], ['design', 'back'], ['front', 'delivery'], ['back', 'delivery'],
  ].map(([source, target]) => ({ source, target, condition: 'passed' })));
  assert.equal(normalizeWorkflow(definition).kind, 'dag'); board.attachWorkflow('root', definition);
  const run = board.snapshot().orchestrations.root;
  board.start(run.taskIds.design); board.finish(run.taskIds.design, { output: '接口设计' }); board.review(run.taskIds.design, true);
  board.start(run.taskIds.front); board.start(run.taskIds.back);
  assert.equal(board.snapshot().tasks.filter(t => t.status === 'running').length, 2);
  assert.throws(() => board.start('root'), e => e.code === 'DEPENDENCY_NOT_DONE');
  for (const id of ['front', 'back']) { board.finish(run.taskIds[id], { output: id }); board.review(run.taskIds[id], true); }
  board.start('root'); assert.equal(board.snapshot().tasks.find(t => t.id === 'root').status, 'running');
});
test('multi-sink DAG adds an explicit delivery join and rejects dependency cycles', () => {
  const board = new TeamBoard(config); board.plan([task('root')]);
  board.attachWorkflow('root', flow([node('a'), node('b'), node('c')], [{ source: 'a', target: 'b', condition: 'passed' }, { source: 'a', target: 'c', condition: 'passed' }]));
  assert.equal(board.snapshot().orchestrations.root.definition.nodes.length, 4);
  assert.equal(board.snapshot().tasks.find(t => t.id === 'root').dependencies.length, 2);
  assert.throws(() => normalizeWorkflow(flow([node('a'), node('b')], [{ source: 'a', target: 'b', condition: 'passed' }, { source: 'b', target: 'a', condition: 'passed' }], { kind: 'dag' })), /成环/);
});
test('cancelled dependencies are explicit and cannot be recovered as successful prerequisites', () => {
  const board = new TeamBoard(config); board.plan([task('up'), task('down', { dependencies: ['up'] }), task('independent', { writeScopes: ['elsewhere'] })]);
  board.cancelTask('up'); const down = board.snapshot().tasks.find(t => t.id === 'down');
  assert.equal(down.status, 'needs_attention'); assert.equal(down.waitingReason, 'DEPENDENCY_CANCELLED');
  assert.throws(() => board.recoverTask('down', '继续'), e => e.code === 'DEPENDENCY_CANCELLED');
  board.start('independent'); assert.equal(board.snapshot().tasks.find(t => t.id === 'independent').status, 'running');
});
test('completed historical model can be retired without losing actual route or restart', async t => {
  const { host, board } = hostFixture(t); board.plan([task('t')]); board.start('t'); board.finish('t', { output: '完成' }); board.review('t', true);
  await host.handleAction('s', 'configure', { config: { ...config, members: [] } });
  const restored = new TeamBoard({ ...config, members: [] }, board.snapshot());
  assert.equal(restored.snapshot().tasks[0].status, 'done'); assert.equal(restored.snapshot().tasks[0].memberSnapshot.model, 'shared');
});
test('staged orchestration requires original requirement evidence and respects missing rejection edges', () => {
  const prepare = () => {
    const board = new TeamBoard(config), definition = workflowTemplates(config.members).find(d => d.id === 'template-3');
    board.plan([task('root')]); board.attachWorkflow('root', definition);
    const ids = board.snapshot().orchestrations.root.taskIds;
    const settle = (id, output) => { board.start(ids[id]); board.finish(ids[id], { output: typeof output === 'string' ? output : JSON.stringify(output) }); return board.review(ids[id], true); };
    return { board, definition, ids, settle };
  };
  const { board, definition, ids, settle } = prepare();
  settle('zhongshu-plan', { departments: definition.nodes.filter(n => n.stage === 'work').map(n => ({ nodeId: n.id, selected: n.id === 'bingbu', reason: '按需执行', instructions: '实现', acceptance: ['满足要求'], writeScopes: n.id === 'bingbu' ? ['src/part'] : [], dependencies: [] })) });
  settle('menxia-spec', { approved: true, feedback: '方案已核实' }); settle('shangshu-plan', '调度'); settle('bingbu', '成果'); settle('shangshu-join', '汇总');
  board.start(ids['menxia-final']); board.finish(ids['menxia-final'], { output: JSON.stringify({ approved: true, feedback: '试图口头通过' }) });
  assert.throws(() => board.review(ids['menxia-final'], true), /尚缺独立核验依据/);
  assert.equal(board.snapshot().tasks.find(t => t.id === ids['menxia-final']).status, 'review');
  board.recordRequirementEvidence('root', { requirementId: 'root-R1', version: 1, status: 'verified', reference: '独立核查文件与测试结果' }, 'user');
  board.review(ids['menxia-final'], true); settle('zhongshu-report', '交付');
  assert.equal(requirementLedger(board.snapshot().tasks.find(t => t.id === 'root'))[0].status, 'verified');
  assert.equal(board.snapshot().orchestrations.root.status, 'done');
  const noRoute = prepare();
  const replacement = { ...noRoute.definition, edges: noRoute.definition.edges.filter(e => e.condition !== 'rejected') };
  const other = new TeamBoard(config); other.plan([task('root')]); other.attachWorkflow('root', replacement);
  const run = other.snapshot().orchestrations.root;
  other.start(run.taskIds['zhongshu-plan']); other.finish(run.taskIds['zhongshu-plan'], { output: '{"departments":[]}' }); other.review(run.taskIds['zhongshu-plan'], true);
  other.start(run.taskIds['menxia-spec']); other.finish(run.taskIds['menxia-spec'], { output: '{"approved":false,"feedback":"需修正"}' }); other.review(run.taskIds['menxia-spec'], true);
  assert.equal(other.snapshot().tasks.find(t => t.id === run.taskIds['menxia-spec']).waitingReason, 'REJECTED_NO_ROUTE');
  assert.equal(other.snapshot().orchestrations.root.generation, 1);
});
test('planner accepts a catalog model directly, including structured contract tasks without any members', async () => {
  const board = new TeamBoard({ ...config, members: [] });
  const tools = createLeadWorkerTools({ getBoard: () => board, getModelCatalog: async () => [model] });
  const exec = { agent: { session: { header: { id: 's' } } } };
  const catalog = await tools.find(tool => tool.name === 'lead_worker_list_members').execute({}, exec);
  assert.equal(catalog.models[0].model, 'shared');
  const result = await tools.find(tool => tool.name === 'lead_worker_plan').execute({ tasks: [{ ...task('t', { memberId: undefined }), modelConfig: model, taskType: 'code', deliverables: [] }] }, exec);
  assert.equal(result.error, undefined);
  board.start('t'); assert.equal(board.snapshot().tasks[0].memberSnapshot.model, 'shared');
});
test('real host scheduler launches same-model instances together and uses saved routes', async t => {
  const { host, board, ctx } = hostFixture(t, true);
  const parent = { ctx: {}, session: { header: { id: 's' } }, followup() {} };
  ctx.agents = { get: () => parent };
  let release; const held = new Promise(resolve => { release = resolve; }); const requests = [];
  ctx.subagents = { async start(_kind, request) { requests.push(request); return { id: `child-${requests.length}`, result: held.then(() => ({ stopReason: 'completed', output: [{ type: 'text', text: '实际夹具交付' }] })), dispose: async () => {} }; } };
  await host.handleAction('s', 'configureSession', { autopilot: true });
  board.plan([task('a', { writeScopes: ['src/a'] }), task('b', { writeScopes: ['src/b'] })]);
  await host.handleAction('s', 'configure', { config: { ...host.getConfig('s'), members: [{ ...model, model: 'new-default' }] } });
  assert.equal(requests.length, 2);
  assert.equal(board.snapshot().tasks.filter(item => item.status === 'running').length, 2);
  assert.deepEqual(requests.map(request => request.agentOptions.model), ['shared', 'shared']);
  release(); await host.drainExecutions('s', { timeoutMs: 1000 });
  assert.ok(board.snapshot().tasks.every(item => item.status === 'review'));
});
test('host completes a custom same-model parallel graph only after independent final evidence', async t => {
  const { host, board, ctx } = hostFixture(t, true);
  const notices = [], calls = [];
  const parent = { ctx: {}, status: 'idle', session: { header: { id: 's' } }, followup(message) { notices.push(message); } };
  ctx.agents = { get: () => parent };
  ctx.subagents = { async start(_kind, request) {
    calls.push(request);
    let output = '夹具交付';
    if (request.label.startsWith('[独立验收]')) {
      const text = request.prompt[0].text, context = JSON.parse(text.slice(text.indexOf('{"taskId":')));
      output = JSON.stringify({ passed: true, feedback: '独立夹具已核对', evidence: context.requirements.map(req => ({ requirementId: req.id, version: req.version, status: 'verified', reference: '隔离夹具核查原始需求与真实交付记录' })) });
    }
    return { id: `graph-child-${calls.length}`, result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: output }] }), dispose: async () => {} };
  } };
  const checked = (id, extra = {}) => node(id, { reviewerId: model.id, reviewerConfig: model, ...extra });
  const definition = flow([checked('design', { readOnly: true }), checked('front', { writeScopes: ['src/front'] }), checked('back', { writeScopes: ['src/back'] }), checked('final', { role: 'review' })], [['design', 'front'], ['design', 'back'], ['front', 'final'], ['back', 'final']].map(([source, target]) => ({ source, target, condition: 'passed' })), { kind: 'dag' });
  board.plan([task('root')]); board.attachWorkflow('root', definition);
  await host.handleAction('s', 'startOrchestration', { taskId: 'root' });
  const deadline = Date.now() + 1500;
  while (board.snapshot().orchestrations.root.status !== 'done' && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 5));
  assert.equal(board.snapshot().orchestrations.root.status, 'done');
  assert.equal(requirementLedger(board.snapshot().tasks.find(item => item.id === 'root'))[0].status, 'verified');
  assert.equal(calls.filter(request => request.label.startsWith('[独立验收]')).length, 4);
  assert.ok(notices.some(message => JSON.stringify(message).includes('编排已通过独立成果验收')));
});
test('failed independent delivery review never emits an orchestration-completed notice', async t => {
  const { host, board, ctx } = hostFixture(t, true), notices = [];
  ctx.agents = { get: () => ({ ctx: {}, status: 'idle', session: { header: { id: 's' } }, followup(message) { notices.push(message); } }) };
  let calls = 0;
  ctx.subagents = { async start(_kind, request) { return { id: `rejected-${++calls}`, result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: request.label.startsWith('[独立验收]') ? '{"passed":false,"feedback":"原需求未满足","evidence":[]}' : '待核验的交付' }] }), dispose: async () => {} }; } };
  board.plan([task('root')]); board.attachWorkflow('root', flow([node('delivery', { reviewerId: model.id, reviewerConfig: model })], [], { kind: 'dag' }));
  await host.handleAction('s', 'startOrchestration', { taskId: 'root' });
  const deadline = Date.now() + 1000;
  while (board.snapshot().tasks[0].status === 'running' && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 5));
  assert.equal(board.snapshot().tasks[0].status, 'needs_attention');
  assert.notEqual(board.snapshot().orchestrations.root.status, 'done');
  assert.ok(notices.every(message => !JSON.stringify(message).includes('编排已通过独立成果验收')));
});
