import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TeamBoard } from '../src/core.mjs';
import { LeadWorkerHostService } from '../src/host.mjs';
import { normalizeWorkflow, requirementLedger, workflowTemplates } from '../src/workflow.mjs';
import { bossGuardReason } from '../src/boss-policy.mjs';
const member = id => ({ id, name: id, provider: 'mock', model: id, role: 'implementation', instructions: 'test', enabled: true, readOnly: false });
const config = { enabled: true, mode: 'mixed', bossDirect: true, autopilot: false, confirmPlan: true, maxParallel: 3, maxRetries: 7, members: ['A','B','C','Q'].map(member) };
const task = { id: 't', title: '任务', instructions: '修复功能', acceptance: ['测试通过'], memberId: 'A', writeScopes: ['src/'] };
const node = (id, extra = {}) => ({ id, memberId: id, mode: 'worker', maxReworks: 0, timeoutMs: 0, ...extra });
const definition = (nodes = [node('A'),node('B'),node('C')], edges = [{ source: 'A', target: 'B', condition: 'rework_limit' }, { source: 'B', target: 'C', condition: 'timeout' }]) => ({ id: 'f', name: '接管', version: 1, entry: nodes[0].id, nodes, edges });
const prepare = (d = definition()) => { const board = new TeamBoard(config); board.plan([task]); board.attachWorkflow('t', d); board.approve(); return board; };
const rejected = board => { board.start('t'); board.finish('t', { output: '需要修复', files: ['src/a.js'] }); return board.review('t', false, '缺少边界测试'); };
const tick = () => new Promise(resolve => setImmediate(resolve));
const deferred = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; };
function fixture(t, start) {
  const dir = mkdtempSync(join(tmpdir(), 'workflow-host-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const messages = [];
  const parent = { ctx: {}, options: { provider: 'mock', model: 'root' }, session: { header: { id: 's' }, deriveMessages: () => messages }, followup: m => messages.push(m) };
  const ctx = { profileContext: { dir }, logger: { info(){}, warn(){}, error(){} }, inject(names,fn){ if(names.length===1&&names[0]==='tools') fn({tools:{guard:fn=>{this.guard=fn;}}}); }, get(name){ return this[name]; }, agents: { get: id => id === 's' ? parent : undefined }, subagents: { start } };
  const host = new LeadWorkerHostService(ctx, { defaultConfig: config });
  host.scheduleReadyTasks = async () => [];
  const board = host.getOrCreateBoard('s'); board.plan([task]);
  return { host, board, parent, messages, ctx, exec: { agent: parent, signal: new AbortController().signal } };
}
test('per-node rework budget counts initial plus N reworks and preserves all handoffs', () => {
  const board = prepare(definition([node('A', { maxReworks: 2 }), node('B'),node('C')]));
  rejected(board); rejected(board); assert.equal(board.snapshot().tasks[0].workflow.current, 'A');
  const t = rejected(board).tasks[0];
  assert.equal(t.workflow.current, 'B'); assert.equal(t.retries, 2); assert.equal(t.workflow.reworks, 0);
  assert.equal(t.reviewHistory.length, 3); assert.equal(t.workflow.handoffs[0].result.files[0], 'src/a.js');
  assert.equal(new TeamBoard(config, board.snapshot()).snapshot().tasks[0].workflow.current, 'B');
});
test('long chains have no three-node cap; invalid and ambiguous graphs fail atomically', () => {
  const nodes = Array.from({ length: 150 }, (_, i) => node(`n${i}`, { memberId: 'A' }));
  const edges = nodes.slice(1).map((n, i) => ({ source: nodes[i].id, target: n.id, condition: 'rework_limit' }));
  assert.equal(normalizeWorkflow(definition(nodes, edges)).nodes.length, 150);
  assert.throws(() => normalizeWorkflow(definition([node('A'),node('B')], [])), /不可达/);
  assert.throws(() => normalizeWorkflow(definition([node('A'),node('B')], [...edges.slice(0,0), { source:'A',target:'B',condition:'timeout' },{ source:'A',target:'B',condition:'timeout' }])), /同一条件/);
  assert.throws(() => normalizeWorkflow(definition([node('A', { maxReworks: -1 })], [])), /非负/);
});
test('explicit loop traversal bound pauses after exhaustion', () => {
  const board = prepare(definition([node('A')], [{ source:'A',target:'A',condition:'rework_limit',maxTraversals:2 }]));
  rejected(board); rejected(board); const t = rejected(board).tasks[0];
  assert.equal(t.status, 'needs_attention'); assert.equal(t.waitingReason, 'WORKFLOW_LOOP_LIMIT'); assert.equal(t.workflow.transitions.length, 2);
});
test('saved drafts never mutate a running version, and restarts quarantine live epochs', () => {
  const board = prepare(); board.start('t'); const original = board.snapshot().tasks[0].workflow.definition;
  board.saveWorkflowDraft({ ...original, version:2, name:'改版' });
  assert.deepEqual(board.snapshot().tasks[0].workflow.definition, original);
  assert.throws(() => board.attachWorkflow('t', original), /尚未启动/);
  const restored = new TeamBoard(config, board.snapshot());
  assert.equal(restored.snapshot().status, 'paused');
  assert.throws(() => restored.finish('t', { output:'stale' }, undefined, 1), /old execution/);
});
test('self-reported evidence remains unknown, stale versions and epochs never verify requirements', () => {
  const board = prepare(); board.start('t');
  const record = { requirementId:'t-R1',version:1,status:'verified',reference:'src/a.js:12 inspected' };
  board.recordRequirementEvidence('t', record, 'self-reported'); assert.equal(requirementLedger(board.snapshot().tasks[0])[0].status, 'unknown');
  board.recordRequirementEvidence('t', record, 'user'); assert.equal(requirementLedger(board.snapshot().tasks[0])[0].status, 'verified');
  assert.throws(() => board.recordRequirementEvidence('t', {...record,version:2}), /版本/);
  board.finish('t',{output:'x'}); board.review('t',false,'reject'); board.start('t');
  assert.equal(requirementLedger(board.snapshot().tasks[0])[0].status, 'unknown');
});
test('all optional scale templates validate and permit custom roles', () => {
  const templates = workflowTemplates(config.members); assert.equal(templates.length,5);
  for (const d of templates) assert.deepEqual(normalizeWorkflow(d), d);
  assert.ok(templates[3].nodes.some(n => n.role === 'review'));
});
test('timeout cannot launch next model until real disposal settles', async t => {
  const result = deferred(), dispose = deferred(); let aborted = false;
  const {host,board,exec} = fixture(t, async (_kind, request) => {
    request.signal.addEventListener('abort', () => { aborted = true; result.resolve({stopReason:'aborted'}); });
    return { id:'child',result:result.promise,dispose:()=>dispose.promise };
  });
  board.attachWorkflow('t', definition([node('A',{timeoutMs:10}),node('B')],[{source:'A',target:'B',condition:'timeout'}])); board.approve();
  const running = host.dispatchTask('s','t',exec); await new Promise(r => setTimeout(r,30));
  assert.equal(aborted,true); assert.equal(board.snapshot().tasks[0].workflow.current,'A');
  assert.equal((await host.drainExecutions('s',{timeoutMs:1})).safe,false);
  dispose.resolve(); await running;
  const state = board.snapshot().tasks[0]; assert.equal(state.workflow.current,'B'); assert.equal(state.workflow.handoffs[0].settled,true);
});
test('user abort does not follow timeout/error edges', async t => {
  const controller = new AbortController();
  const {host,board,exec} = fixture(t, async (_kind,request) => ({id:'child',result:new Promise(resolve => request.signal.addEventListener('abort',()=>resolve({stopReason:'aborted'}))),dispose:async()=>{}}));
  board.attachWorkflow('t', definition([node('A'),node('B')],[{source:'A',target:'B',condition:'error'}])); board.approve();
  const running = host.dispatchTask('s','t',{...exec,signal:controller.signal}); await tick(); controller.abort(); await running;
  assert.equal(board.snapshot().tasks[0].workflow.current,'A'); assert.equal(board.snapshot().status,'paused');
});
test('failed cleanup keeps execution reservation and never hands off', async t => {
  const {host,board,exec} = fixture(t, async () => ({id:'child',result:Promise.resolve({stopReason:'completed',output:[]}),dispose:async()=>{throw new Error('cleanup failed');}}));
  board.attachWorkflow('t', definition([node('A'),node('B')],[{source:'A',target:'B',condition:'error'}])); board.approve();
  const result = await host.dispatchTask('s','t',exec);
  assert.match(result.summary,/尚未确认退出/); assert.equal(board.snapshot().tasks[0].workflow.current,'A');
  assert.equal((await host.drainExecutions('s',{timeoutMs:1})).safe,false);
});
test('independent reviewer is a separate activation and verifies requirements before done', async t => {
  const requests = []; let disposed=0;
  const {host,board,exec} = fixture(t, async (_kind,request) => {
    requests.push(request); const review = request.label.includes('独立验收');
    return {id:`child-${requests.length}`,localAgent:{options:request.agentOptions}, result:Promise.resolve({stopReason:'completed',output:[{type:'text',text:review ? JSON.stringify({passed:true,feedback:'已检查',evidence:[{requirementId:'t-R1',version:1,status:'verified',reference:'src/a.js:12 checked'}]}) : '完成'}]}),dispose:async()=>{disposed++;}};
  });
  board.attachWorkflow('t',definition([node('A',{reviewerId:'Q'})],[])); board.approve(); await host.dispatchTask('s','t',exec);
  assert.equal(requests.length,2); assert.equal(disposed,2); assert.equal(requests[1].agentOptions.model,'Q');
  assert.equal(board.snapshot().tasks[0].status,'done'); assert.equal(requirementLedger(board.snapshot().tasks[0])[0].status,'verified');
});
test('invalid independent review cannot silently accept; main cannot bypass configured reviewer', async t => {
  const {host,board,exec} = fixture(t, async () => ({id:'child',result:Promise.resolve({stopReason:'completed',output:[{text:'looks good'}]}),dispose:async()=>{}}));
  board.attachWorkflow('t',definition([node('A',{reviewerId:'Q'})],[])); board.approve(); await host.dispatchTask('s','t',exec);
  assert.equal(board.snapshot().tasks[0].status,'review'); await assert.rejects(host.reviewTask('s',{taskId:'t',passed:true},exec),/独立验收/);
});
test('controller child uses the actual root route in a distinct child', async t => {
  let request;
  const {host,board,exec} = fixture(t, async (_kind, input) => { request=input; return {id:'new-child',result:Promise.resolve({stopReason:'completed',output:[]}),dispose:async()=>{}}; });
  board.attachWorkflow('t',definition([node('A',{mode:'controller-child'})],[])); board.approve(); await host.dispatchTask('s','t',exec);
  assert.deepEqual(request.agentOptions,{provider:'mock',model:'root'}); assert.equal(board.snapshot().tasks[0].status,'review');
});
test('controller lease is task and epoch bound, does not unlock native delegation, and revokes on pause', async t => {
  const {host,board,exec} = fixture(t, async ()=>{throw new Error('not a child');});
  board.attachWorkflow('t',definition([node('A',{mode:'controller',reviewerId:'Q'})],[])); board.approve(); await host.dispatchTask('s','t',exec);
  const lease=host.controllerLease('s'); assert.ok(lease);
  assert.equal(bossGuardReason({name:'write',agent:exec.agent},config,lease),undefined);
  assert.ok(bossGuardReason({name:'subagent',agent:exec.agent},config,lease));
  board.pause(); assert.equal(host.controllerLease('s'),null);
});
test('controller timeout waits for real root idleness before taking timeout edge', async t => {
  const idle=deferred(); let cancelled=0;
  const {host,board,parent,exec} = fixture(t, async()=>{});
  parent.cancel=()=>{cancelled++;}; parent.whenIdle=()=>idle.promise;
  board.attachWorkflow('t',definition([node('A',{mode:'controller',reviewerId:'Q',timeoutMs:10}),node('B')],[{source:'A',target:'B',condition:'timeout'}])); board.approve(); await host.dispatchTask('s','t',exec);
  await new Promise(r=>setTimeout(r,30)); assert.equal(cancelled,1); assert.equal(host.controllerLease('s'),null); assert.equal(board.snapshot().tasks[0].workflow.current,'A');
  idle.resolve(); await tick(); assert.equal(board.snapshot().tasks[0].workflow.current,'B');
});
test('workbench chat writes to real parent conversation; model actions cannot apply drafts', async t => {
  const {host,messages,exec} = fixture(t,async()=>{});
  await host.handleAction('s','workflowChat',{text:'补充验收标准'});
  assert.equal(messages[0].content[0].text,'补充验收标准'); assert.equal(host.conversationSnapshot('s').messages[0].text,'补充验收标准');
  await assert.rejects(host.workflowAction('s','apply',{},exec),/应用流程请在工作台/);
});
test('future edits preserve current execution, record prior version and reject active-node changes atomically', () => {
  const board=prepare(); board.start('t');
  const next=definition([node('A'),node('B',{maxReworks:5}),node('C')]);
  board.updateFutureWorkflow('t',next);
  assert.equal(board.snapshot().tasks[0].workflow.definition.version,2);
  assert.equal(board.snapshot().tasks[0].workflow.definitionHistory.length,1);
  const before=board.snapshot();
  assert.throws(()=>board.updateFutureWorkflow('t',definition([node('A',{maxReworks:9}),node('B'),node('C')])),/当前节点/);
  assert.deepEqual(board.snapshot(),before);
});
test('real scheduler advances A rejected → B timed out → C, without clearing task history', async t => {
  const started=[];
  const {host,board,exec}=fixture(t,async(_kind,request)=>{
    const model=request.agentOptions.model;started.push(model);
    const result=model==='B'?new Promise(resolve=>request.signal.addEventListener('abort',()=>resolve({stopReason:'aborted'}))):Promise.resolve({stopReason:'completed',output:[{text:'成果'}]});
    return {id:`child-${model}`,result,dispose:async()=>{}};
  });
  host.scheduleReadyTasks=LeadWorkerHostService.prototype.scheduleReadyTasks.bind(host);
  await host.handleAction('s','configureSession',{bossDirect:true});
  board.attachWorkflow('t',definition([node('A'),node('B',{timeoutMs:10}),node('C')]));board.approve();
  await host.dispatchTask('s','t',exec);
  await host.reviewTask('s',{taskId:'t',passed:false,feedback:'需修复'},exec);
  for(let i=0;i<100 && board.snapshot().tasks[0].status!=='review';i++) await new Promise(r=>setTimeout(r,5));
  assert.deepEqual(started,['A','B','C']);
  const current=board.snapshot().tasks[0];assert.equal(current.workflow.current,'C');assert.equal(current.status,'review');
  assert.equal(current.workflow.handoffs.length,2);assert.equal(current.reviewHistory.length,1);
  board.recordRequirementEvidence('t',{requirementId:'t-R1',version:1,status:'verified',reference:'user checked src'},'user');
  await host.reviewTask('s',{taskId:'t',passed:true,feedback:'完成'},exec);assert.equal(board.snapshot().tasks[0].status,'done');
});
test('default workflow binds before first autopilot dispatch and survives restore without changing existing runs', () => {
  const board=new TeamBoard({...config,autopilot:true});
  board.setDefaultWorkflow(definition());board.plan([task]);
  assert.equal(board.snapshot().approved,true);assert.equal(board.snapshot().tasks[0].workflow.current,'A');
  board.start('t');board.setDefaultWorkflow(definition([node('B')],[]));
  assert.equal(board.snapshot().tasks[0].workflow.current,'A');
  const restored=new TeamBoard({...config,autopilot:true},board.snapshot());
  assert.equal(restored.snapshot().workflowDefault.entry,'B');assert.equal(restored.snapshot().tasks[0].workflow.current,'A');
});
test('passed-loop exhaustion cannot masquerade as final acceptance', () => {
  const board=prepare(definition([node('A')],[{source:'A',target:'A',condition:'passed',maxTraversals:1}]));
  board.start('t');board.finish('t',{output:'stage1'});board.review('t',true,'pass');
  board.start('t');board.finish('t',{output:'stage2'});board.review('t',true,'pass');
  assert.equal(board.snapshot().tasks[0].status,'needs_attention');assert.equal(board.snapshot().tasks[0].waitingReason,'WORKFLOW_LOOP_LIMIT');
});
test('read-only node blocks implementation and nested team dispatch through the host guard', async t => {
  const result=deferred();
  const {host,board,exec,ctx}=fixture(t,async()=>({id:'readonly-child',result:result.promise,dispose:async()=>{}}));
  board.attachWorkflow('t',definition([node('A',{readOnly:true})],[]));board.approve();
  const running=host.dispatchTask('s','t',exec);await tick();
  for(const name of ['write','pwsh','subagent','lead_worker_dispatch','lead_worker_approve']) assert.match(ctx.guard({name,agent:{session:{header:{id:'readonly-child',parentSession:'s'}}}}),/只读/);
  assert.equal(ctx.guard({name:'read',agent:{session:{header:{id:'readonly-child',parentSession:'s'}}}}),undefined);
  result.resolve({stopReason:'completed',output:[]});await running;
});
test('changing acceptance criteria increments requirement version and revokes earlier evidence', () => {
  const board=prepare();board.recordRequirementEvidence('t',{requirementId:'t-R1',version:1,status:'verified',reference:'original check'},'user');
  board.plan([{...task,acceptance:['新的验收标准']}],'user');
  const current=board.snapshot().tasks[0];assert.equal(current.requirements[0].id,'t-R1');assert.equal(current.requirements[0].version,2);
  assert.equal(requirementLedger(current)[0].status,'unknown');assert.equal(current.requirementEvidence.length,1);
});
