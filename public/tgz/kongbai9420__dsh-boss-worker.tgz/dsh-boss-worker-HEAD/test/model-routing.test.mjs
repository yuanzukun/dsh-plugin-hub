import test from 'node:test';
import assert from 'node:assert/strict';
import { TeamBoard } from '../src/core.mjs';
import { workflowTemplates } from '../src/workflow.mjs';
import { LeadWorkerHostService } from '../src/host.mjs';
import { createLeadWorkerTools } from '../src/tools.mjs';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const members = ['cheap', 'strong', 'fallback'].map(id => ({ id, name: id, provider: 'mock', model: id, role: 'implementation', instructions: '', enabled: true, readOnly: false }));
const route = (memberId, maxReworks = 0) => ({ memberId, maxReworks, timeoutMs: 0 });
const policy = { enabled: true, classification: 'auto', simple: route('cheap'), complex: route('strong'), autoEscalate: true, fallbacks: [route('fallback')] };
const config = (modelRouting = policy) => ({ enabled: true, mode: 'mixed', members, maxRetries: 2, maxParallel: 3, confirmPlan: true, modelRouting });
const task = (id = 't', difficulty = 'simple') => ({ id, title: id, instructions: '执行', acceptance: '完成并验证', writeScopes: [`src/${id}`], difficulty, difficultyReason: difficulty === 'simple' ? '范围明确且没有跨模块依赖' : '跨模块设计和不确定性较高' });
const failReview = board => { board.start('t'); board.finish('t', { output: '需要修复' }); return board.review('t', false, '验收不通过'); };

test('each child task uses its configured tier; recommended member cannot override routing', () => {
  const board = new TeamBoard(config());
  board.plan([{ ...task('small'), memberId: 'strong' }, task('large', 'complex')], 'model');
  assert.deepEqual(board.snapshot().tasks.map(item => item.memberId), ['cheap', 'strong']);
  assert.deepEqual(board.snapshot().tasks.map(item => item.workflow.definition.nodes.length), [3, 2]);
  assert.equal(board.snapshot().tasks[0].routingHistory[0].reason, task().difficultyReason);
});
test('rejections escalate through configured models while retaining results and reasons', () => {
  const board = new TeamBoard(config()); board.plan([task()]); board.approve();
  failReview(board); assert.equal(board.snapshot().tasks[0].memberId, 'strong');
  failReview(board); const current = board.snapshot().tasks[0];
  assert.equal(current.memberId, 'fallback'); assert.equal(current.workflow.handoffs.length, 2);
  assert.equal(current.reviewHistory.length, 2); assert.equal(current.routingHistory.at(-1).reason, 'rework_limit');
  assert.equal(current.workflow.handoffs[0].result.output, '需要修复');
});
test('missing or manually unconfirmed difficulty cannot silently dispatch a guessed model', () => {
  for (const manual of [false, true]) {
    const board = new TeamBoard(config({ ...policy, classification: manual ? 'manual' : 'auto' }));
    const input = task(); if (!manual) { delete input.difficulty; delete input.difficultyReason; }
    board.plan([input], 'model');
    assert.equal(board.snapshot().tasks[0].memberId, null);
    assert.equal(board.snapshot().tasks[0].waitingReason, 'DIFFICULTY_REQUIRED');
    assert.throws(() => board.start('t', undefined, true), /难度/);
    board.classifyTask('t', 'simple', '用户确认范围较小');
    assert.equal(board.snapshot().tasks[0].memberId, 'cheap');
    assert.equal(board.snapshot().tasks[0].difficultyLocked, true);
  }
});
test('fixed templates stay fixed; template nodes can follow difficulty or a selected tier', () => {
  for (const [selection, expected] of [['fixed', 'fallback'], ['task', 'cheap'], ['complex', 'strong']]) {
    const board = new TeamBoard(config()); const definition = workflowTemplates(members)[0];
    definition.nodes[0] = { ...definition.nodes[0], modelSelection: selection, memberId: 'fallback' };
    board.setDefaultWorkflow(definition); board.plan([task()], 'model');
    assert.equal(board.snapshot().tasks[0].memberId, expected);
    assert.equal(board.snapshot().tasks[0].workflow.definition.nodes.length, 1);
  }
});
test('user model locks prevent automatic upgrade and difficulty overrides cannot alter running tasks', () => {
  const board = new TeamBoard(config()); board.plan([task()]); board.assign('t', 'cheap'); board.approve();
  failReview(board); const current = board.snapshot().tasks[0];
  assert.equal(current.memberId, 'cheap'); assert.equal(current.waitingReason, 'ROUTING_LOCKED');
  const second = new TeamBoard(config()); second.plan([task()]); second.classifyTask('t', 'complex', '用户要求复杂模型'); second.approve(); second.start('t');
  assert.throws(() => second.classifyTask('t', 'simple', '改为简单'), /尚未启动/);
  assert.equal(second.snapshot().tasks[0].memberId, 'strong');
  const fixed = new TeamBoard(config()); fixed.setDefaultWorkflow(workflowTemplates(members)[0]);
  fixed.plan([{ ...task(), memberId: 'fallback', locked: true }], 'user');
  assert.equal(fixed.snapshot().tasks[0].memberId, 'fallback');
  const manual = new TeamBoard(config({ ...policy, classification: 'manual' }));
  const template = workflowTemplates(members)[0]; template.nodes[0].modelSelection = 'task'; manual.setDefaultWorkflow(template);
  const locked = task(); delete locked.difficulty; delete locked.difficultyReason;
  manual.plan([{ ...locked, memberId: 'fallback', locked: true }], 'user');
  assert.equal(manual.snapshot().tasks[0].memberId, 'fallback');
});
test('policy changes affect new tasks, with independent route copies surviving restore', () => {
  const board = new TeamBoard(config()); board.plan([task()]);
  const original = board.snapshot().tasks[0].workflow;
  board.reconfigure(config({ ...policy, simple: route('fallback') }));
  board.appendTasks([task('new')]);
  assert.deepEqual(board.snapshot().tasks[0].workflow, original);
  assert.equal(board.snapshot().tasks[1].memberId, 'fallback');
  const restored = new TeamBoard(board.config, board.snapshot());
  assert.deepEqual(restored.snapshot().tasks[0].routingHistory, board.snapshot().tasks[0].routingHistory);
});
test('disabling escalation keeps a single node and disabling routing retains legacy assignment', () => {
  const board = new TeamBoard(config({ ...policy, autoEscalate: false })); board.plan([task()]); board.approve();
  failReview(board); assert.equal(board.snapshot().tasks[0].status, 'needs_attention');
  assert.equal(board.snapshot().tasks[0].memberId, 'cheap');
  const legacy = new TeamBoard(config({ enabled: false })); legacy.plan([{ ...task(), memberId: 'strong' }]);
  assert.equal(legacy.snapshot().tasks[0].workflow, null); assert.equal(legacy.snapshot().tasks[0].memberId, 'strong');
});

function hostFixture(t) {
  const directory = mkdtempSync(join(tmpdir(), 'model-routing-host-')); t.after(() => rmSync(directory, { recursive: true, force: true }));
  const requests = [];
  const parent = { ctx: {}, session: { header: { id: 's' }, deriveMessages: () => [] }, followup(){} };
  const ctx = { profileContext: { dir: directory }, logger: { warn(){}, info(){}, error(){} }, inject(){}, get(key){ return this[key]; }, agents: { get: id => id === 's' ? parent : null }, subagents: { async start(_kind, request){ requests.push(request); return { id: `child-${requests.length}`, result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: '已完成只读分析，未修改文件。' }] }), dispose: async () => {} }; } } };
  const create = () => new LeadWorkerHostService(ctx, { defaultConfig: config() });
  const host = create(); host.scheduleReadyTasks = async () => [];
  return { host, create, requests, exec: { agent: parent, signal: new AbortController().signal } };
}
test('real host dispatches cheap then strong after rejection and keeps normal main review', async t => {
  const { host, requests, exec } = hostFixture(t); const board = host.getOrCreateBoard('s');
  board.plan([{ ...task(), readOnly: true, writeScopes: [], taskType: 'analysis' }]); board.approve();
  await host.dispatchTask('s', 't', exec);
  assert.equal(requests[0].agentOptions.model, 'cheap');
  await host.reviewTask('s', { taskId: 't', passed: false, feedback: '分析遗漏关键依赖，请接管补充' }, exec);
  await host.dispatchTask('s', 't', exec);
  assert.equal(requests[1].agentOptions.model, 'strong');
  await host.reviewTask('s', { taskId: 't', passed: true, feedback: '主控已核对分析结果' }, exec);
  assert.equal(board.snapshot().tasks[0].status, 'done');
  assert.equal(requests.length, 2);
});
test('planning tool preserves difficulty through structured contracts without extra classifier calls', async () => {
  const board = new TeamBoard({ ...config(), confirmPlan: false });
  const tools = createLeadWorkerTools({ getBoard: () => board, isDelegationDisabled: () => true });
  const plan = tools.find(tool => tool.name === 'lead_worker_plan');
  await plan.execute({ tasks: [{ ...task(), readOnly: true, writeScopes: [], taskType: 'analysis' }] }, { agent: { session: { header: { id: 's' } } } });
  assert.equal(board.snapshot().tasks[0].difficulty, 'simple');
  assert.equal(board.snapshot().tasks[0].memberId, 'cheap');
  assert.equal(board.snapshot().tasks[0].difficultySource, 'model');
});
test('manual classification submits a pending plan without asking execution approval too early', async () => {
  const board = new TeamBoard(config({ ...policy, classification: 'manual' }));
  const tools = createLeadWorkerTools({ getBoard: () => board, askUserQuestion: async () => { throw new Error('unexpected approval'); } });
  const result = await tools.find(tool => tool.name === 'lead_worker_plan').execute({ tasks: [task()] }, { agent: { session: { header: { id: 's' } } } });
  assert.equal(result.error, undefined); assert.equal(result.tasks[0].waitingReason, 'DIFFICULTY_REQUIRED');
});
test('saved policy is Profile-shared and applied future routes survive catalog retirement', async t => {
  const { host, create } = hostFixture(t);
  await host.handleAction('s', 'configureModelRouting', { modelRouting: { ...policy, simple: route('cheap', 3) }, expectedConfigRevision: 0 });
  assert.equal(host.getConfig('other').modelRouting.simple.maxReworks, 3);
  assert.deepEqual(create().getConfig('s').modelRouting, host.getConfig('s').modelRouting);
  const board = host.getOrCreateBoard('s'); board.plan([task()]);
  const before = host.getConfig('s');
  await host.handleAction('s', 'configure', { config: { ...before, members: before.members.filter(member => member.id !== 'fallback'), modelRouting: { enabled: false } } });
  assert.equal(board.snapshot().tasks[0].workflow.definition.nodes.at(-1).modelConfig.model, before.members.find(member => member.id === 'fallback').model);
});
test('user difficulty lock rejects model replanning and pending templates keep their original definition', () => {
  const board = new TeamBoard(config()); board.plan([task()]); board.classifyTask('t', 'complex', '用户确认跨模块设计');
  const before = board.snapshot(); assert.throws(() => board.plan([task()], 'model'), /锁定的难度/); assert.deepEqual(board.snapshot(), before);
  const pending = new TeamBoard(config({ ...policy, classification: 'manual' }));
  const definition = workflowTemplates(members)[0]; definition.nodes[0].modelSelection = 'task';
  pending.setDefaultWorkflow(definition); pending.plan([task()], 'model'); pending.setDefaultWorkflow(null);
  pending.classifyTask('t', 'simple', '用户确认范围明确');
  assert.equal(pending.snapshot().tasks[0].workflow.definition.id, definition.id);
});
test('editing an internal routing graph retains normal review semantics and legacy nodes remain editable in future', () => {
  const board = new TeamBoard(config()); board.plan([task()]);
  const definition = board.snapshot().tasks[0].workflow.definition;
  board.attachWorkflow('t', definition);
  assert.equal(board.snapshot().tasks[0].routing.generatedWorkflow, true);
  board.approve(); board.start('t');
  const stored = board.snapshot(); for (const node of stored.tasks[0].workflow.definition.nodes) delete node.modelSelection;
  stored.tasks[0].status = 'review';
  const legacy = new TeamBoard(config(), stored);
  const next = legacy.snapshot().tasks[0].workflow.definition; next.nodes[1].label = '更新后继显示名称';
  assert.doesNotThrow(() => legacy.updateFutureWorkflow('t', next));
});
test('routing refuses a read-only fallback for writable work before committing the plan', () => {
  const board = new TeamBoard({ ...config(), members: members.map(member => member.id === 'fallback' ? { ...member, readOnly: true } : member) });
  const before = board.snapshot(); assert.throws(() => board.plan([task()]), /只读权限/);
  assert.deepEqual(board.snapshot(), before);
});
