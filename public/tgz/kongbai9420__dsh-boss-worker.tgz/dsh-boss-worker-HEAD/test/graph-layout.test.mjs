import test from 'node:test';
import assert from 'node:assert/strict';
import { arrangeWorkflow, workflowOverlaps, workflowExecutionKey } from '../client/graph-layout.mjs';
import { workflowTemplates } from '../src/workflow.mjs';

const tang = () => workflowTemplates([{ id: 'worker', enabled: true }, { id: 'review', enabled: true, readOnly: true }])[3];
const content = ({ layoutDirection, ...definition }) => ({ ...definition, nodes: definition.nodes.map(({ position, ...node }) => node) });

test('Tang preset leaves room for full model and usage cards around six parallel branches', () => {
  const definition = tang();
  const measurements = Object.fromEntries(definition.nodes.map(node => [node.id, { width: 240, height: 300 }]));
  assert.equal(workflowOverlaps(definition, measurements), false);
  for (const edge of definition.edges.filter(edge => edge.condition === 'passed')) {
    const source = definition.nodes.find(node => node.id === edge.source);
    const target = definition.nodes.find(node => node.id === edge.target);
    assert.equal(definition.layoutDirection, 'LR');
    assert.ok(target.position.x - source.position.x - 240 >= 100);
  }
});

test('legacy Tang layout is repaired using uneven actual card sizes without changing execution semantics', () => {
  const legacy = tang();
  legacy.layoutDirection = 'TB';
  legacy.nodes = legacy.nodes.map((node, i) => ({ ...node, position: { x: i >= 3 && i <= 8 ? (i - 3) * 290 : 725, y: i < 3 ? i * 210 : i <= 8 ? 630 : (i - 5) * 210 } }));
  const measurements = Object.fromEntries(legacy.nodes.map((node, i) => [node.id, { width: 240, height: 340 + i * 17 }]));
  assert.equal(workflowOverlaps(legacy, measurements), true);
  const arranged = arrangeWorkflow(legacy, measurements);
  assert.equal(workflowOverlaps(arranged, measurements), false);
  assert.deepEqual(content(arranged), content(legacy));
  const branches = arranged.nodes.filter(node => node.stage === 'work');
  assert.equal(new Set(branches.map(node => node.position.y + measurements[node.id].height / 2)).size, 1);
  const dispatch = arranged.nodes.find(node => node.stage === 'dispatch');
  const join = arranged.nodes.find(node => node.stage === 'join');
  for (const branch of branches) {
    assert.ok(branch.position.y - dispatch.position.y - measurements[dispatch.id].height >= 100);
    assert.ok(join.position.y - branch.position.y - measurements[branch.id].height >= 100);
  }
});

test('overlap check respects hand-positioned layouts and detects growth crossing the next rank', () => {
  const definition = tang();
  assert.equal(workflowOverlaps(definition), false);
  assert.equal(workflowOverlaps(definition, { 'shangshu-plan': { width: 500, height: 300 } }), true);
  const copy = structuredClone(definition);
  workflowOverlaps(definition);
  assert.deepEqual(definition, copy);
});


test('both orchestration templates support horizontal and vertical layout without execution changes or collisions', () => {
  for (const definition of workflowTemplates([{ id: 'worker', enabled: true }, { id: 'review', enabled: true, readOnly: true }]).filter(d => d.kind === 'orchestration')) {
    const measurements = Object.fromEntries(definition.nodes.map((node, i) => [node.id, { width: 240, height: 300 + i * 17 }]));
    for (const direction of ['LR', 'TB']) {
      const arranged = arrangeWorkflow(definition, measurements, direction);
      assert.equal(arranged.layoutDirection, direction);
      assert.equal(workflowOverlaps(arranged, measurements), false);
      assert.equal(workflowExecutionKey(definition), workflowExecutionKey(arranged));
      for (const edge of arranged.edges.filter(e => e.condition === 'passed')) {
        const source = arranged.nodes.find(n => n.id === edge.source), target = arranged.nodes.find(n => n.id === edge.target);
        assert.ok(direction === 'LR' ? target.position.x - source.position.x - measurements[source.id].width >= 100 : target.position.y - source.position.y - measurements[source.id].height >= 100);
      }
    }
  }
});
