import test from 'node:test';
import assert from 'node:assert/strict';
import { workflowVisuals } from '../client/workflow-visuals.mjs';

const ab = { source: 'A', target: 'B', condition: 'rework_limit' };
const bc = { source: 'B', target: 'C', condition: 'timeout' };
const run = { current: 'C', transitions: [{ from: 'A', to: 'B', condition: 'rework_limit' }, { from: 'B', to: 'C', condition: 'timeout' }] };

test('light follows only the last confirmed handoff into the current executing node', () => {
  const visual = workflowVisuals(run, 'running', 'ready');
  assert.equal(visual.pulse, true);
  assert.deepEqual(visual.edge(ab), { traversed: true, active: false });
  assert.deepEqual(visual.edge(bc), { traversed: true, active: true });
  assert.deepEqual(visual.edge({ ...bc, condition: 'passed' }), { traversed: false, active: false });
});
test('pause, stop, review and terminal states stop motion while retaining real history', () => {
  for (const [taskStatus, boardStatus] of [['running', 'paused'], ['running', 'draining'], ['running', 'cancelled'], ['review', 'ready'], ['done', 'ready'], ['cancelled', 'ready'], ['needs_attention', 'ready']]) {
    const visual = workflowVisuals(run, taskStatus, boardStatus);
    assert.equal(visual.pulse, false);
    assert.deepEqual(visual.edge(bc), { traversed: true, active: false });
  }
  assert.equal(workflowVisuals(run, 'running', 'paused').paused, true);
});
test('pending successor shows its handoff, but never pulses as if executing', () => {
  const visual = workflowVisuals(run, 'pending', 'ready');
  assert.equal(visual.pulse, false);
  assert.equal(visual.edge(bc).active, true);
});
test('draft preview and never-traversed branches do not invent progress', () => {
  const preview = workflowVisuals(null, 'running', 'ready');
  assert.equal(preview.pulse, false);
  assert.deepEqual(preview.edge(ab), { traversed: false, active: false });
  assert.equal(workflowVisuals({ ...run, current: 'A' }, 'running', 'ready').edge(bc).active, false);
});
