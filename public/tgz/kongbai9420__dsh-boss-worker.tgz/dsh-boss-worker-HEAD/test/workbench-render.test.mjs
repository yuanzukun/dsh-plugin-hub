import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import React from 'react';
import { renderToString } from 'react-dom/server';
const result = await build({ entryPoints:[fileURLToPath(new URL('../client/workbench.jsx',import.meta.url))], bundle:true,write:false,platform:'node',format:'cjs',external:['react','react-dom'],loader:{'.css':'text'} });
const module = {exports:{}};
new Function('require','module','exports',result.outputFiles[0].text)(createRequire(import.meta.url),module,module.exports);
test('real React workbench renders during initial empty snapshot without crashing', () => {
  const html=renderToString(React.createElement(module.exports.Workbench,{sessionId:'loading',subscribe:()=>()=>{},refresh:async()=>{},openChild:async()=>{},onClose(){}}));
  assert.ok(html.includes('aria-label="返回会话"'));
  assert.ok(html.includes('流程工作台')); assert.ok(html.includes('主控会话尚未加载')); assert.ok(html.includes('先创建一个任务'));
  assert.ok(html.includes('aria-label="工作区视图"')); assert.ok(html.includes('aria-label="发送给主控"')); assert.ok(html.includes('aria-modal="true"'));
});
test('native workflow is a contained region and does not create a second chat input or modal', () => {
  const html = renderToString(React.createElement(module.exports.Workbench, { nativeView: true, sessionId: 'native', subscribe: () => () => {}, refresh: async () => {}, openChild: async () => {}, onClose() {} }));
  assert.ok(!html.includes('aria-label="返回会话"'));
  assert.ok(html.includes('aria-label="关闭辅助面板"'));
  assert.ok(html.includes('wf-native'));
  const header = html.slice(html.indexOf('<header'), html.indexOf('</header>'));
  assert.ok(!/保存草案|用于新任务|应用流程|流程操作/.test(header));
  assert.ok(html.includes('aria-label="流程保存与应用"'));
  assert.ok(html.includes('保存草案'));
  assert.ok(html.includes('aria-label="流程方向"')); assert.ok(html.includes('role="region"')); assert.ok(!html.includes('aria-modal'));
  assert.ok(!html.includes('aria-label="发送给主控"')); assert.ok(!html.includes('aria-label="主控对话"'));
  assert.ok(html.includes('用量设置'));
  assert.ok(html.includes('模板库')); assert.ok(html.includes('Skill 库'));
  assert.ok(html.includes('aria-label="流程模板库"')); assert.ok(html.includes('搜索流程模板'));
  assert.ok(!html.includes('class="wf-usage-strip"'), 'session totals remain in monitoring rather than occupying canvas space');
  const editorHtml = renderToString(React.createElement(module.exports.Workbench, { nativeView: true, templateEditor: {}, sessionId: 'editor', subscribe: () => () => {}, refresh: async () => {}, onClose() {} }));
  assert.ok(editorHtml.includes('aria-label="返回模板设置"'), 'template editor keeps its hierarchical back navigation');
});

const usageBuild = await build({ entryPoints: [fileURLToPath(new URL('../client/usage-monitor.jsx', import.meta.url))], bundle: true, write: false, platform: 'node', format: 'cjs', external: ['react'] });
const usageModule = { exports: {} };
new Function('require', 'module', 'exports', usageBuild.outputFiles[0].text)(createRequire(import.meta.url), usageModule, usageModule.exports);
const { UsageMonitor } = await import('../src/usage-monitor.mjs');

const pickerBuild = await build({ entryPoints: [fileURLToPath(new URL('../client/node-model-select.jsx', import.meta.url))], bundle: true, write: false, platform: 'node', format: 'cjs', external: ['react'] });
const pickerModule = { exports: {} };
new Function('require', 'module', 'exports', pickerBuild.outputFiles[0].text)(createRequire(import.meta.url), pickerModule, pickerModule.exports);
test('node model picker exposes real routes and locks protected execution selectors', () => {
  const data = { label: '实现', mode: 'worker', modelSelection: 'fixed', memberId: 'a', modelMembers: [{ id: 'a', name: '经济成员', provider: 'provider-a', model: 'small-model', enabled: true }, { id: 'b', name: '复杂成员', provider: 'provider-b', model: 'large-model', enabled: false }], modelProvider: 'provider-a', modelId: 'small-model', modelLocked: true, modelLockReason: '当前节点已锁定' };
  const html = renderToString(React.createElement(pickerModule.exports.NodeModelSelect, { id: 'n', data }));
  assert.ok(html.includes('切换 实现 的模型')); assert.ok(html.includes('provider-a / small-model')); assert.ok(!html.includes('large-model'));
  assert.ok(html.includes('经济档模型')); assert.ok(html.includes('当前节点已锁定')); assert.match(html, /<select[^>]*disabled/);
});
test('direct node model selection clears tier routing while retaining Skills, budgets and review settings', () => {
  const node = { id: 'n', mode: 'worker', modelSelection: 'complex', memberId: 'a', reviewerId: 'q', role: 'test', skills: [{ id: 'skill', content: 'retain' }], timeoutMs: 1234, maxReworks: 3 };
  const members = [{ id: 'a', provider: 'p', model: 'a', enabled: true }, { id: 'b', provider: 'p', model: 'b', enabled: true }, { id: 'off', enabled: false }];
  const changed = pickerModule.exports.nodeModelChange(node, 'member:b', members);
  assert.equal(changed.memberId, 'b'); assert.equal(changed.modelSelection, 'fixed');
  assert.deepEqual(changed.skills, node.skills); assert.equal(changed.reviewerId, 'q'); assert.equal(changed.timeoutMs, 1234); assert.equal(changed.maxReworks, 3);
  assert.equal(pickerModule.exports.nodeModelChange(node, 'tier:simple', members).modelSelection, 'simple');
  assert.throws(() => pickerModule.exports.nodeModelChange(node, 'member:off', members), /不可用/);
  assert.throws(() => pickerModule.exports.nodeModelChange({ ...node, reviewerId: null }, 'controller', members), /独立验收/);
});
test('monitor UI shows unknowns honestly and preserves node versus session scope', () => {
  const monitor = new UsageMonitor();
  const call = monitor.begin({ provider: 'offline', model: '<model>' }, { sessionId: 's', taskId: 't', nodeId: 'A', batchId: 1, role: 'reviewer', epoch: 2 });
  monitor.chunk(call, { type: 'usage', usage: { inputTokens: 10, outputTokens: 20 } }); monitor.end(call);
  const html = renderToString(React.createElement(usageModule.exports.UsagePanel, { monitor: monitor.snapshot('s'), task: { id: 't' }, nodeId: 'A', batchId: 1, isApplied: true, scope: 'node', setScope() {}, members: [] }));
  assert.ok(html.includes('已结算 Token')); assert.ok(html.includes('30')); assert.ok(html.includes('未计价'));
  assert.ok(html.includes('独立验收')); assert.ok(html.includes('&lt;model&gt;')); assert.ok(html.includes('未提供'));
  assert.ok(html.includes('隐藏推理不推算速度'));
  const live = new UsageMonitor(); const current = live.begin({ provider: 'p', model: 'm' }, { sessionId: 's' });
  live.chunk(current, { type: 'text-delta', text: '示例' });
  const nodeHtml = renderToString(React.createElement(usageModule.exports.NodeUsage, { summary: live.snapshot('s').summary }));
  assert.ok(nodeHtml.includes('本轮用量待结算')); assert.ok(nodeHtml.includes('未计价')); assert.ok(!nodeHtml.includes('≈未计价'));
});

test('node card shows cumulative Token and cost with honest empty states; scoped model details exclude other nodes', () => {
  const monitor = new UsageMonitor();
  const call = monitor.begin({ provider: 'p', model: 'node-model' }, { sessionId: 's', taskId: 't', nodeId: 'A', batchId: 1, role: 'worker', epoch: 1 });
  monitor.chunk(call, { type: 'usage', usage: { inputTokens: 1200, outputTokens: 300 } }); monitor.end(call);
  const other = monitor.begin({ provider: 'p', model: 'other-node-model' }, { sessionId: 's', taskId: 't', nodeId: 'B', batchId: 1, role: 'worker', epoch: 1 });
  monitor.chunk(other, { type: 'usage', usage: { inputTokens: 9, outputTokens: 1 } }); monitor.end(other);
  const snapshot = monitor.snapshot('s');
  const nodeHtml = renderToString(React.createElement(usageModule.exports.NodeUsage, { summary: snapshot.nodes.find(node => node.nodeId === 'A'), onOpen() {} }));
  assert.ok(nodeHtml.includes('节点累计')); assert.ok(nodeHtml.includes('1,500 Token')); assert.ok(nodeHtml.includes('预估费用')); assert.ok(nodeHtml.includes('未计价')); assert.ok(nodeHtml.includes('用量明细'));
  const empty = renderToString(React.createElement(usageModule.exports.NodeUsage, { showEmpty: true, emptyLabel: '草案未运行' }));
  assert.ok(empty.includes('— Token')); assert.ok(empty.includes('草案未运行')); assert.ok(!empty.includes('0 Token'));
  const details = renderToString(React.createElement(usageModule.exports.UsagePanel, { monitor: snapshot, task: { id: 't' }, nodeId: 'A', batchId: 1, isApplied: true, scope: 'node', setScope() {}, members: [] }));
  assert.ok(details.includes('本节点按模型统计')); assert.ok(details.includes('node-model')); assert.ok(!details.includes('other-node-model'));
});
