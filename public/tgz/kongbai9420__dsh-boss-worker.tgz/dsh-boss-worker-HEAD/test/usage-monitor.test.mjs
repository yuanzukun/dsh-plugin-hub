import test from 'node:test';
import assert from 'node:assert/strict';
import { UsageMonitor, normalizeUsage, usageCost, normalizeMonitorSettings, summarizeCalls } from '../src/usage-monitor.mjs';

const scope = { sessionId: 'parent', taskId: 'task', nodeId: 'A', epoch: 1, role: 'worker' };
const options = { provider: 'offline', model: 'A', sessionId: 'child' };
const prices = { currency: 'CNY', prices: [{ provider: 'offline', model: 'A', input: 1, output: 3, cacheRead: .1, cacheWrite: 2 }] };
const usage = { inputTokens: 100, outputTokens: 200, cacheReadTokens: 50, cacheWriteTokens: 10, reasoningTokens: 120 };
function fixture() {
  let now = 1000, saves = 0;
  const monitor = new UsageMonitor({ clock: () => now, save: () => saves++ });
  monitor.configure('parent', { settings: prices, budget: 1, expectedRevision: 0 });
  return { monitor, time: value => { now = value; }, saves: () => saves };
}
function finish(monitor, call) { monitor.chunk(call, { type: 'usage', usage }); monitor.chunk(call, { type: 'finish', reason: { kind: 'stop' } }); monitor.end(call); }

test('cache counters remain disjoint and reasoning is not billed twice', () => {
  const normalized = normalizeUsage(usage);
  assert.equal(normalized.totalTokens, 360);
  assert.equal(usageCost(normalized, prices.prices[0]), .000725);
  assert.equal(normalizeUsage({ inputTokens: -1, outputTokens: 2 }), null);
  assert.equal(normalizeUsage({ inputTokens: 1, outputTokens: NaN }), null);
});
test('unknown tariff is not free; explicit zero prices are valid', () => {
  assert.equal(usageCost(normalizeUsage(usage), null), null);
  assert.equal(usageCost(normalizeUsage(usage), { input: 1, output: 2 }), null);
  assert.equal(usageCost(normalizeUsage(usage), { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }), 0);
});
test('tariff input rejects invalid prices and duplicate routes', () => {
  for (const input of [{ currency: 'EUR' }, { prices: [{ provider: 'a', model: 'b', output: -1 }] }, { prices: [{ provider: 'a', model: 'b', input: Infinity }] }, { prices: [prices.prices[0], prices.prices[0]] }]) assert.throws(() => normalizeMonitorSettings(input));
});
test('stream preserves chunks and records TTFT, settled speed and authoritative usage', async () => {
  const { monitor, time, saves } = fixture(); monitor.bind('child', scope);
  const chunks = [{ type: 'block-start' }, { type: 'reasoning-delta', text: 'secret thinking' }, { type: 'text-delta', text: 'private result' }, { type: 'usage', usage }, { type: 'finish', reason: { kind: 'stop' } }];
  const stream = monitor.stream(options, async function* () {
    time(1200); yield chunks[0]; time(1500); yield chunks[1]; time(2500); yield chunks[2]; time(2700); yield chunks[3]; yield chunks[4];
  });
  assert.deepEqual(await Array.fromAsync(stream), chunks);
  const snapshot = monitor.snapshot('parent');
  assert.equal(snapshot.summary.ttftMs, 500);
  assert.equal(snapshot.summary.speed, 200);
  assert.equal(snapshot.summary.usage.totalTokens, 360);
  assert.equal(snapshot.summary.costs.CNY, .000725);
  assert.equal(snapshot.nodes[0].nodeId, 'A'); assert.equal(snapshot.summary.pendingUsage, 0);
  assert.equal(saves(), 3, 'settings, request start and settlement write; token chunks never do');
  assert.ok(!JSON.stringify(monitor.serialize()).includes('private result'));
  assert.ok(!JSON.stringify(monitor.serialize()).includes('secret thinking'));
});
test('live estimated output does not masquerade as settled tokens or costs', () => {
  const { monitor, time } = fixture();
  const call = monitor.begin(options, scope); time(1500); monitor.chunk(call, { type: 'text-delta', text: '中文abcd' }); time(2500);
  const snapshot = monitor.snapshot('parent');
  assert.equal(snapshot.summary.speedEstimated, true); assert.equal(snapshot.summary.speed, 3);
  assert.equal(snapshot.summary.liveEstimatedTokens, 3); assert.equal(snapshot.summary.usage.totalTokens, null);
  assert.deepEqual(snapshot.summary.costs, {}); assert.equal(snapshot.summary.pendingUsage, 1);
});
test('repeated usage snapshots settle once; cancellation keeps known billed work', async () => {
  const { monitor } = fixture(); monitor.bind('child', scope);
  await Array.fromAsync(monitor.stream(options, async function* () { yield { type: 'usage', usage }; yield { type: 'usage', usage }; yield { type: 'finish', reason: { kind: 'aborted' } }; }));
  const snapshot = monitor.snapshot('parent');
  assert.equal(snapshot.summary.usage.totalTokens, 360); assert.equal(snapshot.calls[0].status, 'cancelled');
  assert.equal(snapshot.summary.costs.CNY, .000725);
});
test('failed or interrupted stream without provider usage stays unknown', async () => {
  const { monitor } = fixture(); monitor.bind('child', scope);
  await assert.rejects(async () => Array.fromAsync(monitor.stream(options, async function* () { yield { type: 'text-delta', text: 'some text' }; throw new Error('network'); })), /network/);
  const snapshot = monitor.snapshot('parent');
  assert.equal(snapshot.summary.missingUsage, 1); assert.equal(snapshot.summary.unpriced, 1);
  assert.equal(snapshot.summary.usage.totalTokens, null); assert.equal(snapshot.calls[0].status, 'error');
});
test('retry, handoff and reviewer usage retain distinct scopes and aggregate once', () => {
  const { monitor } = fixture();
  for (const attribution of [scope, { ...scope, epoch: 2 }, { ...scope, epoch: 2, role: 'reviewer' }, { ...scope, nodeId: 'B', epoch: 3 }]) finish(monitor, monitor.begin(options, attribution));
  const snapshot = monitor.snapshot('parent');
  assert.equal(snapshot.summary.usage.totalTokens, 1440); assert.equal(snapshot.nodes[0].usage.totalTokens, 1080);
  assert.equal(snapshot.nodes[1].usage.totalTokens, 360); assert.equal(snapshot.calls.filter(c => c.role === 'reviewer').length, 1);
});
test('startup async scope catches child calls before spawn handle is returned', async () => {
  const { monitor } = fixture();
  await monitor.withScope(scope, async () => {
    await Promise.resolve();
    await Array.fromAsync(monitor.stream(options, async function* () { yield { type: 'usage', usage }; yield { type: 'finish', reason: { kind: 'stop' } }; }));
  });
  assert.equal(monitor.snapshot('parent').calls[0].taskId, 'task');
  assert.equal(monitor.resolve('child').epoch, 1);
});
test('parallel scopes and separate conversations never mix', async () => {
  const { monitor } = fixture();
  await Promise.all(['other', 'parent'].map(sessionId => monitor.withScope({ ...scope, sessionId }, async () => {
    await new Promise(resolve => setImmediate(resolve));
    const call = monitor.begin({ ...options, sessionId: `child-${sessionId}` }, monitor.resolve(`child-${sessionId}`)); finish(monitor, call);
  })));
  assert.equal(monitor.snapshot('parent').calls.length, 1); assert.equal(monitor.snapshot('other').calls.length, 1);
  assert.equal(monitor.resolve('unwatched'), null);
});
test('main request attribution is frozen at start, not assigned to a later controller lease', () => {
  const { monitor } = fixture();
  const call = monitor.begin({ ...options, sessionId: 'parent' }, monitor.resolve('parent'));
  assert.equal(call.role, 'controller'); assert.equal(call.taskId, null);
  const next = monitor.begin({ ...options, sessionId: 'parent' }, monitor.resolve('parent', { ...scope, role: 'controller-direct' }));
  assert.equal(next.taskId, 'task'); assert.equal(call.taskId, null);
});
test('tariff edits affect future calls, preserve currency and reject stale settings', () => {
  const { monitor } = fixture(); const first = monitor.begin(options, scope);
  monitor.configure('parent', { settings: { ...prices, currency: 'USD' }, budget: 2, expectedRevision: 1 });
  finish(monitor, first); finish(monitor, monitor.begin(options, scope));
  assert.deepEqual(Object.keys(monitor.snapshot('parent').summary.costs).sort(), ['CNY', 'USD']);
  assert.equal(monitor.snapshot('parent').budget.currency, 'USD');
  assert.throws(() => monitor.configure('parent', { settings: prices, budget: 1, expectedRevision: 1 }), /刷新/);
});
test('restart keeps settled totals and marks unfinished requests interrupted', () => {
  const { monitor } = fixture(); finish(monitor, monitor.begin(options, scope)); monitor.begin(options, scope);
  const restored = new UsageMonitor(); restored.restore(monitor.serialize());
  const snapshot = restored.snapshot('parent');
  assert.equal(snapshot.summary.running, 0); assert.equal(snapshot.summary.missingUsage, 1);
  assert.equal(snapshot.summary.usage.totalTokens, 360); assert.equal(snapshot.calls[1].status, 'interrupted');
  assert.equal(snapshot.quota.available, false);
});
test('parallel tools count union duration once, separately from model time', () => {
  const { monitor, time } = fixture(); monitor.bind('child', scope); finish(monitor, monitor.begin(options, scope));
  monitor.toolEvent('child', { type: 'tool/call', data: { callId: 'a' } }); time(1500);
  monitor.toolEvent('child', { type: 'tool/call', data: { callId: 'b' } }); time(2000);
  monitor.toolEvent('child', { type: 'tool/result', data: { message: { callId: 'a' } } });
  assert.equal(monitor.snapshot('parent').nodes[0].toolsRunning, 1); time(2500);
  monitor.toolEvent('child', { type: 'tool/result', data: { message: { callId: 'b' } } });
  const snapshot = monitor.snapshot('parent');
  assert.equal(snapshot.summary.toolMs, 1500); assert.equal(snapshot.nodes[0].toolMs, 1500);
  assert.equal(snapshot.summary.modelMs, 0); assert.equal(snapshot.nodes[0].toolsRunning, 0);
});
test('empty summary has no fabricated usage, speed or charges', () => {
  const summary = summarizeCalls([]); assert.equal(summary.usage.totalTokens, null); assert.equal(summary.speed, null); assert.deepEqual(summary.costs, {});
});

test('a reused task/node id in a later batch keeps its own totals', () => {
  const { monitor } = fixture();
  finish(monitor, monitor.begin(options, { ...scope, batchId: 1 }));
  finish(monitor, monitor.begin(options, { ...scope, batchId: 2 }));
  const snapshot = monitor.snapshot('parent');
  assert.equal(snapshot.nodes.length, 2);
  assert.equal(snapshot.nodes.find(node => node.batchId === 2).usage.totalTokens, 360);
  assert.equal(snapshot.summary.usage.totalTokens, 720);
});
test('hidden reasoning is billed but not fabricated as visible generation speed', () => {
  const { monitor, time } = fixture(); const call = monitor.begin(options, scope);
  time(1500); monitor.chunk(call, { type: 'text-delta', text: 'visible' }); time(2500); monitor.chunk(call, { type: 'text-delta', text: 'output' });
  finish(monitor, call);
  assert.equal(monitor.snapshot('parent').summary.speed, 80);
  assert.equal(monitor.snapshot('parent').summary.usage.outputTokens, 200);
});
test('disposal closes tool timing and removes stale running phase', () => {
  const { monitor, time } = fixture(); monitor.bind('child', scope); finish(monitor, monitor.begin(options, scope));
  monitor.toolEvent('child', { type: 'tool/call', data: { callId: 'aborted-tool' } }); time(2200); monitor.unbind('child'); time(5000);
  const snapshot = monitor.snapshot('parent'); assert.equal(snapshot.nodes[0].toolsRunning, 0); assert.equal(snapshot.nodes[0].toolMs, 1200);
});

test('node totals include rework and review but never other nodes using the same model or controller calls', () => {
  const { monitor } = fixture();
  const nodeScope = { ...scope, batchId: 7 };
  finish(monitor, monitor.begin(options, nodeScope));
  finish(monitor, monitor.begin(options, { ...nodeScope, epoch: 2 }));
  finish(monitor, monitor.begin({ ...options, model: 'QA' }, { ...nodeScope, role: 'reviewer' }));
  finish(monitor, monitor.begin(options, { ...nodeScope, nodeId: 'B' }));
  finish(monitor, monitor.begin(options, { sessionId: 'parent', role: 'controller' }));
  const snapshot = monitor.snapshot('parent');
  const nodeA = snapshot.nodes.find(node => node.nodeId === 'A');
  const nodeB = snapshot.nodes.find(node => node.nodeId === 'B');
  assert.equal(nodeA.usage.totalTokens, 1080); assert.equal(nodeA.calls, 3);
  assert.equal(nodeA.byModel.find(model => model.model === 'A').usage.totalTokens, 720);
  assert.equal(nodeA.byModel.find(model => model.model === 'QA').usage.totalTokens, 360);
  assert.equal(nodeB.usage.totalTokens, 360);
  assert.equal(snapshot.tasks[0].usage.totalTokens, 1440);
  assert.equal(snapshot.tasks[0].byModel.find(model => model.model === 'A').usage.totalTokens, 1080);
  assert.equal(snapshot.summary.usage.totalTokens, 1800);
});
