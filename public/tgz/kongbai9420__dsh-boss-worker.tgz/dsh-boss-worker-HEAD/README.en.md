<div align="center">

# DSH Boss Worker

**Choose models per node. Coordinate with workflows. Deliver with evidence.**

A multi-model workflow workbench for DeepSeek Harness

[![Pre-release](https://img.shields.io/badge/pre--release-0.2.0--beta.28-2563eb)](docs/CHANGELOG.en.md)
[![Local tests](https://img.shields.io/badge/local_tests-412_passed-16a34a)](docs/COMPATIBILITY.en.md)
[![License](https://img.shields.io/badge/license-MIT-64748b)](LICENSE)

[简体中文](README.md) · **English**

[Quick start](#quick-start) · [How it works](#how-it-works) · [Documentation](docs/README.en.md) · [Changelog](docs/CHANGELOG.en.md)

</div>

---

> [!NOTE]
> Current version: **[`0.2.0-beta.28` · Beta pre-release](https://github.com/kongbai9420/dsh-boss-worker/releases/tag/v0.2.0-beta.28)**. See verification boundaries below and download the package and checksums from the Release.

## Why use it

Turn requirements into nodes in DSH's official workflow tab. Choose a Provider / model for each node, then connect dependencies, reviews and rework. Model configurations, execution states and acceptance evidence stay recorded from draft to delivery.

| Capability | What you get |
| --- | --- |
| Models per node | Choose execution and independent review models directly, without maintaining a worker pool |
| Branches and joins | Independent nodes run in parallel when dependencies pass and declared write scopes do not conflict |
| Editable workflows | Drag connections, change layout, undo/redo, attach Skills, import/export templates |
| Evidence-based acceptance | Reconcile original requirements, retain verification history and distinguish failure from missing evidence |
| Explicit rework | Re-execute the rejection target and affected downstream nodes along canvas routes |
| Runtime visibility | Inspect node calls, rework, independent review, Token usage and estimated cost |

## How it works

```mermaid
flowchart LR
    A[Requirements and planning] --> B[Plan review]
    B --> C[Frontend implementation]
    B --> D[Backend implementation]
    C --> E[Integration and testing]
    D --> E
    E --> F[Independent acceptance]
    F -->|Pass| G[Delivery and reconciliation]
    F -->|Reject| C
    F -->|Reject| D
```

This conceptual example shows branching, joining and rework. Canvas connections define actual dependencies; the built-in full-stack template also includes architecture, UX and delivery nodes.

**There is no worker-count or maximum-concurrency setting.** The same model can create multiple independent execution instances. Scheduling follows dependencies and declared write scopes; conflicting writes queue. A single direct controller execution context remains serial.

| Workflow type | Best for | Rules |
| --- | --- | --- |
| Parallel graph · `kind=dag` | Custom branches and joins; the default for new templates | `passed` dependencies must be acyclic; `rejected` returns to a predecessor or the same node |
| Model handoff chain · no `kind` | Switching models sequentially for one task | Pass, rejection, rework limit, timeout and error routes; one successor per condition |
| Governed orchestration · `kind=orchestration` | Three Departments and Six Ministries; full-stack team | Structured planning, plan review, delegation, joining, final acceptance and reporting |

Applying a parallel graph with multiple terminal nodes and no explicit join adds a visible delivery-and-acceptance join. A handoff graph with multiple passing successors from one node is identified and validated as a parallel graph. See the [workflow guide](docs/WORKFLOW.en.md).

## Quick start

### Use in DSH

1. Configure available Providers and models in DSH, then install the local package through the app's plugin manager.
2. Open the official **workflow** tab and select a template or create a workflow.
3. Choose each node's model, responsibility, Skills, write scopes, rework budget and timeout. Adjust its independent review model as needed.
4. Connect **pass** routes for dependencies and **rejection** routes for rework targets.
5. Save a draft or apply it to an unstarted task. Approve or start orchestration under the current approval policy.
6. Check results in execution records and requirement reconciliation; deliver once the original requirements have valid acceptance evidence.

Previewing, saving and applying a workflow do not immediately call models. Applied nodes retain snapshots of execution and review configurations; editing the shared catalog does not silently change their models.

<details>
<summary><strong>Interface preview · Choose a model directly on a node</strong></summary>

Screenshot from offline interaction verification, showing template editing, model selection and responsibilities. `offline / C` is a test fixture. The interface shown is in Chinese.

<p align="center">
  <img src="docs/assets/node-model-settings.png" alt="Node configuration panel with model, responsibility, Skills and execution budget" width="360">
</p>

</details>

### Build from source

Use Node.js 24, matching the repository CI.

```powershell
git clone https://github.com/kongbai9420/dsh-boss-worker.git
cd dsh-boss-worker
npm ci --legacy-peer-deps --ignore-scripts
npm run build:client
npm test
npm run test:client
npm pack --ignore-scripts
```

This creates a local `.tgz` package. Check `package.json` in your checkout for its version. `client/` contains frontend sources; `client.js` is generated. Host contract checks also require official DSH dependencies; see the [CI configuration](.github/workflows/check.yml) for installation and execution.

Try the offline workbench:

```powershell
node scripts/preview-workbench.mjs
```

Open the local address printed in the terminal. Preview uses a temporary Profile and offline models; it does not operate on real sessions or incur model API charges.

## Acceptance and runtime controls

| Area | Current behavior |
| --- | --- |
| Quality and evidence | A model's `passed=true` cannot override a confirmed failure; missing evidence preserves results pending verification |
| Final delivery | Reconcile each original requirement's version, status and reviewable reference; a verbal summary is insufficient |
| Verification corrections | The latest trusted verification within the same version and execution epoch applies; history remains, and worker self-reports cannot override trusted conclusions |
| Independent acceptance | New implementation nodes default to an independent review context; manual verification requires recorded evidence before review |
| Read-only review | Inspect files and existing evidence; test execution belongs to test nodes |
| Pause scheduling | Stop new dispatches while started calls settle; interruption, cancellation and draining are distinct actions |
| Cancellation and recovery | Cancelling upstream work blocks affected dependants; interrupted work requires inspection and confirmation after restart |

`writeScopes` supports task contracts, conflict scheduling and delivery checks; **it is not filesystem isolation**. Execution follows the host sandbox and approvals. BOSS direct dispatch and automatic management are session-private switches; rework and approval defaults retain shared settings.

## Usage and pricing

Node totals include rework and independent review, attributed to the actual Provider / model. Add prices directly from available models; use official reference prices, manual overrides, display units and explicit conversions.

**Session budgets are reminders and do not stop execution.** Unknown usage and unpriced costs are explicit. Estimates do not represent invoices, subscription quotas or account balances. See [runtime monitoring](docs/RUNTIME_MONITORING.en.md).

## Verification status

Last verified: **2026-10-27**. These are local records, not a claim that remote GitHub Actions have run.

| Check | Result and scope |
| --- | --- |
| Unit and business regression tests | **412 passed, 0 failed, 0 skipped** |
| Official host and frontend contracts | Passed on DSH `0.1.7-rc.2`, `0.2.0-rc.2` and `0.2.1-rc.2` |
| Interface interaction | Offline template editing, model selection, saving and reopening verified |
| Live Providers | Full paid tasks, rate limits and invoice reconciliation still require separate acceptance |

Compatibility tests use real official host dependencies with offline model fixtures. See [compatibility](docs/COMPATIBILITY.en.md). Legacy `members` / `memberId` and `maxParallel` remain migration inputs; they no longer represent execution-instance counts or scheduling limits.

## Documentation and participation

| Document | Contents |
| --- | --- |
| [Documentation hub](docs/README.en.md) | Bilingual navigation and reading order |
| [Workflows](docs/WORKFLOW.en.md) | Parallelism, handoff, rejection, application and recovery |
| [Model routing](docs/MODEL_ROUTING.en.md) | Fixed models, tiers, snapshots and migration |
| [Full-stack team](docs/FULLSTACK_TEMPLATE.en.md) | Roles, dependencies and targeted rework |
| [Runtime monitoring](docs/RUNTIME_MONITORING.en.md) | Tokens, pricing, budgets and metric definitions |
| [Compatibility](docs/COMPATIBILITY.en.md) · [Roadmap](docs/ROADMAP.en.md) · [Changelog](docs/CHANGELOG.en.md) | Verification boundaries, next steps and version history |

Report problems through [Issues](https://github.com/kongbai9420/dsh-boss-worker/issues) with the plugin version, DSH version, reproduction steps and sanitized logs. Contributions should describe behavior changes and verification results; development commands are above.

Released under the [MIT License](LICENSE). See [third-party notices](THIRD_PARTY_NOTICES.md) for bundled dependency licenses.
