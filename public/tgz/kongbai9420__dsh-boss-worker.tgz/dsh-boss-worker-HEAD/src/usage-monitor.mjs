import { AsyncLocalStorage } from 'node:async_hooks';
import { randomUUID } from 'node:crypto';
import { PRICE_SOURCES } from './pricing-sources.mjs';
import { convertCosts } from './billing-units.mjs';

const clone = value => JSON.parse(JSON.stringify(value));
const count = value => Number.isSafeInteger(value) && value >= 0 ? value : null;
const usageKeys = ['inputTokens', 'outputTokens', 'totalTokens', 'cacheReadTokens', 'cacheWriteTokens', 'reasoningTokens'];
export function normalizeUsage(value) {
  if (!value || count(value.inputTokens) === null || count(value.outputTokens) === null) return null;
  const result = Object.fromEntries(usageKeys.map(key => [key, count(value[key])]));
  result.totalTokens ??= result.inputTokens + result.outputTokens + (result.cacheReadTokens || 0) + (result.cacheWriteTokens || 0);
  return result;
}
export function normalizeMonitorSettings(value = {}) {
  if (!['CNY', 'USD'].includes(value.currency ?? 'CNY') || !Array.isArray(value.prices ?? [])) throw new Error('请选择 CNY 或 USD，并提供模型价格列表');
  const seen = new Set();
  const unitTokens = value.unitTokens ?? 1e6;
  if (!Number.isSafeInteger(unitTokens) || unitTokens <= 0) throw new Error('计价 Token 单位必须为正整数');
  const display = { moneyUnit: value.display?.moneyUnit?.trim() || 'native', tokenDivisor: value.display?.tokenDivisor ?? 1, tokenLabel: value.display?.tokenLabel?.trim() || 'Token', decimals: value.display?.decimals ?? 4, rates: value.display?.rates || {} };
  if (display.moneyUnit.length > 16 || display.tokenLabel.length > 16 || !Number.isSafeInteger(display.tokenDivisor) || display.tokenDivisor <= 0 || !Number.isSafeInteger(display.decimals) || display.decimals < 0 || display.decimals > 10) throw new Error('显示单位、精度或 Token 数量单位无效');
  if (Object.entries(display.rates).some(([currency, rate]) => !['CNY', 'USD'].includes(currency) || rate != null && (typeof rate !== 'number' || !Number.isFinite(rate) || rate <= 0))) throw new Error('换算倍率必须是正数或留空');
  const prices = (value.prices || []).map(price => {
    if (!price || typeof price.provider !== 'string' || !price.provider.trim() || typeof price.model !== 'string' || !price.model.trim()) throw new Error('价格必须指定 Provider 和模型');
    const key = JSON.stringify([price.provider.trim(), price.model.trim()]);
    if (seen.has(key)) throw new Error('同一 Provider 和模型只能配置一组价格');
    seen.add(key);
    const result = { provider: price.provider.trim(), model: price.model.trim(), mode: price.mode || 'manual', currency: price.currency || value.currency || 'CNY', unitTokens: price.unitTokens ?? unitTokens };
    if (!['manual', 'official'].includes(result.mode) || !['CNY', 'USD'].includes(result.currency) || !Number.isSafeInteger(result.unitTokens) || result.unitTokens <= 0) throw new Error('模型计价方式、货币或单位无效');
    if (result.mode === 'official') {
      if (!Object.hasOwn(PRICE_SOURCES, price.source) || typeof price.tariff !== 'string' || !price.tariff || typeof (price.sourceModel || price.model) !== 'string') throw new Error('官方计价需要来源、模型 ID 和计费档位');
      Object.assign(result, { source: price.source, sourceModel: price.sourceModel || price.model, tariff: price.tariff, sourceUrl: PRICE_SOURCES[price.source].url, syncedAt: typeof price.syncedAt === 'number' ? price.syncedAt : null, syncError: typeof price.syncError === 'string' ? price.syncError : '', note: typeof price.note === 'string' ? price.note : '' });
    }
    for (const field of ['input', 'output', 'cacheRead', 'cacheWrite']) {
      const rate = price[field];
      if (rate !== null && rate !== undefined && (typeof rate !== 'number' || !Number.isFinite(rate) || rate < 0)) throw new Error('单价必须是非负有限数字；未知价格请留空');
      result[field] = rate ?? null;
    }
    return result;
  });
  if (value.autoSync != null && typeof value.autoSync !== 'boolean') throw new Error('自动同步开关无效');
  return { currency: value.currency || 'CNY', unitTokens, autoSync: value.autoSync ?? true, display, prices };
}
// DSH input/cache counters are disjoint. Reasoning is a breakdown of output,
// not an additional billable counter. Never add it to output a second time.
export function usageCost(usage, price) {
  if (!usage || !price) return null;
  let amount = 0;
  for (const [key, rate] of [['inputTokens', 'input'], ['outputTokens', 'output'], ['cacheReadTokens', 'cacheRead'], ['cacheWriteTokens', 'cacheWrite']]) {
    const tokens = usage[key] ?? 0;
    if (tokens && price[rate] == null) return null;
    amount += tokens * (price[rate] ?? 0);
  }
  return amount / (price.unitTokens || 1e6);
}
export function approximateTokens(text) {
  let wide = 0, other = 0;
  for (const char of text) /[\u2e80-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/u.test(char) ? wide++ : other++;
  return wide + other / 4;
}

export function summarizeCalls(calls, now = Date.now()) {
  const usage = Object.fromEntries(usageKeys.map(key => [key, null]));
  const costs = {};
  for (const call of calls) {
    if (call.status !== 'running' && call.usage) for (const key of usageKeys) if (call.usage[key] !== null && call.usage[key] !== undefined) usage[key] = (usage[key] ?? 0) + call.usage[key];
    if (call.cost !== null && call.cost !== undefined) costs[call.currency] = (costs[call.currency] || 0) + call.cost;
  }
  const active = calls.filter(c => c.status === 'running');
  const latest = active.at(-1) || calls.at(-1);
  const generating = active.filter(c => c.firstTokenAt != null);
  const liveTokens = generating.reduce((sum, c) => sum + c.estimatedTokens, 0);
  const liveMs = generating.reduce((sum, c) => sum + Math.max(0, now - c.firstTokenAt), 0);
  const generated = calls.filter(c => c.status !== 'running' && c.usage && c.firstTokenAt != null && c.lastTokenAt > c.firstTokenAt);
  const finalMs = generated.reduce((sum, c) => sum + c.lastTokenAt - c.firstTokenAt, 0);
  const visibleOutput = call => Math.max(0, call.usage.outputTokens - (call.sawReasoning ? 0 : call.usage.reasoningTokens || 0));
  return {
    calls: calls.length, running: active.length, usage, costs, liveEstimatedTokens: Math.round(liveTokens),
    missingUsage: calls.filter(c => c.status !== 'running' && !c.usage).length,
    unpriced: calls.filter(c => c.status !== 'running' && c.cost == null).length,
    pendingUsage: active.length,
    speed: active.length ? liveMs > 0 ? liveTokens / (liveMs / 1000) : null : finalMs > 0 ? generated.reduce((sum, c) => sum + visibleOutput(c), 0) / (finalMs / 1000) : null,
    speedEstimated: active.length > 0,
    ttftMs: latest?.firstTokenAt != null ? latest.firstTokenAt - latest.startedAt : null,
    modelMs: calls.reduce((sum, c) => sum + Math.max(0, (c.endedAt ?? now) - c.startedAt), 0),
  };
}

/** Local metadata only: no prompts, generated text, credentials or tool arguments. */
function summarizeModels(calls, now) {
  const groups = new Map();
  for (const call of calls) {
    const key = JSON.stringify([call.provider, call.model]);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(call);
  }
  return [...groups.values()].map(group => ({ provider: group[0].provider, model: group[0].model, ...summarizeCalls(group, now) }));
}

export class UsageMonitor {
  #context = new AsyncLocalStorage();
  #children = new Map();
  #sessions = new Map();
  #tools = new Map();
  #save;
  #clock;
  settings = normalizeMonitorSettings();
  revision = 0;
  constructor({ save = () => {}, clock = Date.now } = {}) { this.#save = save; this.#clock = clock; }
  restore(stored) {
    if (!stored) return;
    this.settings = normalizeMonitorSettings(stored.settings);
    this.revision = stored.revision || 0;
    for (const session of stored.sessions || []) {
      for (const call of session.calls) if (call.status === 'running') { call.status = 'interrupted'; call.endedAt = call.lastTokenAt ?? call.startedAt; }
      this.#sessions.set(session.id, session);
    }
  }
  serialize() { return clone({ settings: this.settings, revision: this.revision, sessions: [...this.#sessions.values()] }); }
  watch(sessionId) {
    if (!this.#sessions.has(sessionId)) this.#sessions.set(sessionId, { id: sessionId, since: this.#clock(), calls: [], budget: null, budgetCurrency: this.settings.currency, toolMs: 0 });
    return this.#sessions.get(sessionId);
  }
  configure(sessionId, { settings, budget, expectedRevision, preserveBudget = false }) {
    if (expectedRevision !== this.revision) throw new Error('监控设置已更新，请刷新后重试');
    const normalized = normalizeMonitorSettings(settings);
    if (budget !== null && (typeof budget !== 'number' || !Number.isFinite(budget) || budget < 0)) throw new Error('会话预算必须是非负数字或留空');
    const session = this.watch(sessionId);
    this.settings = normalized;
    if (!preserveBudget) { session.budget = budget; session.budgetCurrency = normalized.display.moneyUnit === 'native' ? normalized.currency : normalized.display.moneyUnit; session.budgetDisplay = clone(normalized.display); }
    this.revision++;
    this.#save(); return this.snapshot(sessionId);
  }
  applySynchronized(settings, expectedRevision) {
    if (expectedRevision !== this.revision) throw new Error('同步期间设置已更新，请重试；没有覆盖新设置');
    this.settings = normalizeMonitorSettings(settings); this.revision++; this.#save();
  }
  withScope(scope, work) { return this.#context.run(scope, work); }
  bind(childId, scope) { if (childId) this.#children.set(childId, { ...scope, childId }); }
  unbind(childId) { this.closeTools(childId); this.#children.delete(childId); }
  resolve(sessionId, controllerScope) {
    if (this.#children.has(sessionId)) return this.#children.get(sessionId);
    const inherited = this.#context.getStore();
    if (inherited && sessionId && sessionId !== inherited.sessionId) {
      this.bind(sessionId, inherited); return this.#children.get(sessionId);
    }
    if (this.#sessions.has(sessionId)) return controllerScope || { sessionId, role: 'controller', taskId: null, nodeId: null, epoch: null };
    return null;
  }
  begin(options, scope) {
    if (!scope) return null;
    const price = this.settings.prices.find(p => p.provider === options.provider && p.model === options.model);
    const call = { id: randomUUID(), ...scope, provider: options.provider, model: options.model, purpose: options.purpose || null,
      startedAt: this.#clock(), firstTokenAt: null, lastTokenAt: null, endedAt: null, status: 'running', estimatedTokens: 0,
      usage: null, cost: null, currency: price?.currency || this.settings.currency, price: price ? clone(price) : null };
    this.watch(scope.sessionId).calls.push(call);
    this.#save();
    return call;
  }
  chunk(call, chunk) {
    if (!call) return;
    if (chunk.type === 'reasoning-delta' && chunk.text) call.sawReasoning = true;
    const text = chunk.type === 'text-delta' || chunk.type === 'reasoning-delta' ? chunk.text : chunk.type === 'tool-call-delta' ? (chunk.argumentsDelta || '') + (chunk.name || '') : '';
    if (text) { const now = this.#clock(); call.firstTokenAt ??= now; call.lastTokenAt = now; call.estimatedTokens += approximateTokens(text); }
    if (chunk.type === 'usage') call.usage = normalizeUsage(chunk.usage);
    if (chunk.type === 'finish') call.finishReason = chunk.reason?.kind || 'unknown';
  }
  end(call, error = false) {
    if (!call || call.status !== 'running') return;
    call.endedAt = this.#clock(); call.status = error ? 'error' : call.finishReason === 'aborted' ? 'cancelled' : call.finishReason === 'error' ? 'error' : call.finishReason ? 'completed' : 'interrupted';
    call.cost = usageCost(call.usage, call.price); this.#save();
  }
  async *stream(options, next, controllerScope) {
    const call = this.begin(options, this.resolve(options.sessionId, controllerScope));
    let failed = true;
    try { for await (const chunk of next()) { this.chunk(call, chunk); yield chunk; } failed = false; }
    finally { this.end(call, failed); }
  }
  toolEvent(sessionId, event, controllerScope) {
    const scope = this.resolve(sessionId, controllerScope);
    if (!scope || !['tool/call', 'tool/result'].includes(event.type)) return;
    const key = sessionId;
    if (event.type === 'tool/call') {
      const state = this.#tools.get(key) || { scope, startedAt: this.#clock(), ids: new Set() };
      state.ids.add(event.data.callId); this.#tools.set(key, state);
    } else {
      const state = this.#tools.get(key); if (!state) return;
      state.ids.delete(event.data.message?.callId);
      if (!state.ids.size) {
        this.closeTools(key);
      }
    }
  }
  closeTools(sessionId) {
    const state = this.#tools.get(sessionId); if (!state) return;
    const ms = Math.max(0, this.#clock() - state.startedAt), session = this.watch(state.scope.sessionId);
    session.toolMs += ms; session.toolGroups ??= []; session.toolGroups.push({ ...state.scope, ms });
    this.#tools.delete(sessionId); this.#save();
  }
  snapshot(sessionId) {
    const session = this.watch(sessionId), now = this.#clock();
    const tools = [...this.#tools.values()].filter(t => t.scope.sessionId === sessionId);
    const summary = summarizeCalls(session.calls, now);
    const nodes = [];
    for (const call of session.calls.filter(c => c.taskId)) {
      if (!nodes.some(n => n.taskId === call.taskId && n.nodeId === call.nodeId && n.batchId === call.batchId)) {
        const calls = session.calls.filter(c => c.taskId === call.taskId && c.nodeId === call.nodeId && c.batchId === call.batchId);
        const nodeTools = tools.filter(t => t.scope.taskId === call.taskId && t.scope.nodeId === call.nodeId && t.scope.batchId === call.batchId);
        nodes.push({ taskId: call.taskId, nodeId: call.nodeId, batchId: call.batchId, ...summarizeCalls(calls, now), byModel: summarizeModels(calls, now), toolsRunning: nodeTools.length,
          toolMs: (session.toolGroups || []).filter(t => t.taskId === call.taskId && t.nodeId === call.nodeId && t.batchId === call.batchId).reduce((sum, t) => sum + t.ms, 0) + nodeTools.reduce((sum, t) => sum + now - t.startedAt, 0) });
      }
    }
    const byModel = summarizeModels(session.calls, now);
    const tasks = [...new Map(nodes.map(node => [`${node.taskId}:${node.batchId}`, { taskId: node.taskId, batchId: node.batchId }])).values()].map(task => ({ ...task, ...summarizeCalls(session.calls.filter(call => call.taskId === task.taskId && call.batchId === task.batchId), now), byModel: summarizeModels(session.calls.filter(call => call.taskId === task.taskId && call.batchId === task.batchId), now), toolsRunning: tools.filter(tool => tool.scope.taskId === task.taskId && tool.scope.batchId === task.batchId).length }));
    const budgetCosts = convertCosts(summary.costs, session.budgetDisplay || { moneyUnit: 'native' });
    return clone({ since: session.since, revision: this.revision, settings: this.settings, summary: { ...summary, toolMs: session.toolMs + tools.reduce((sum, t) => sum + now - t.startedAt, 0) }, nodes, tasks, byModel,
      budget: { limit: session.budget, currency: session.budgetCurrency, spent: budgetCosts[session.budgetCurrency] ?? null },
      quota: { available: false, reason: '当前 DSH 通用接口未提供账户余额／订阅剩余额度' }, calls: session.calls });
  }
}
