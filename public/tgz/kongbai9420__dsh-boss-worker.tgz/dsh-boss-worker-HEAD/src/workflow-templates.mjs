import { randomUUID } from 'node:crypto';
import { normalizeWorkflow } from './workflow.mjs';

export const emptyTemplateLibrary = () => ({ revision: 0, items: [] });
export function restoreTemplateLibrary(value) {
  if (!value) return emptyTemplateLibrary();
  if (!Number.isSafeInteger(value.revision) || value.revision < 0 || !Array.isArray(value.items)) throw new Error('无效模板库');
  const items = value.items.map(item => ({ ...normalizeWorkflow(item), description: typeof item.description === 'string' ? item.description : '' }));
  if (items.some(item => !item.id.startsWith('user-template-')) || new Set(items.map(item => item.id)).size !== items.length) throw new Error('无效模板 ID');
  return { revision: value.revision, items };
}
export function changeTemplateLibrary(library, action, params) {
  if (params.expectedTemplatesRevision !== library.revision) throw new Error('模板库已更新，请返回模板设置刷新后重试');
  const found = library.items.find(item => item.id === params.templateId);
  if (action === 'delete') {
    if (!found) throw new Error('用户模板不存在；内置模板请复制后编辑');
    return { revision: library.revision + 1, items: library.items.filter(item => item.id !== params.templateId) };
  }
  if (params.templateId && !found) throw new Error('用户模板不存在；内置模板请复制后编辑');
  if (typeof params.definition?.name !== 'string' || !params.definition.name.trim()) throw new Error('请填写模板名称');
  const definition = normalizeWorkflow({ ...params.definition, id: found?.id || `user-template-${randomUUID()}`, name: params.definition.name.trim(), version: (found?.version || 0) + 1 });
  if (definition.nodes.some(node => [node.memberId, node.reviewerId].some(id => id?.startsWith('task-route-')))) throw new Error('可复用模板请选择共享角色成员，不使用会话专属临时成员');
  const item = { ...definition, description: typeof params.description === 'string' ? params.description.trim() : '' };
  return { revision: library.revision + 1, items: found ? library.items.map(old => old.id === found.id ? item : old) : [...library.items, item] };
}
