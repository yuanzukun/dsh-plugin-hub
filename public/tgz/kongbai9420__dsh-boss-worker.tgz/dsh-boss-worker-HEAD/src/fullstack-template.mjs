import { builtinWorkflowSkills } from './workflow-skills.mjs';

// Original DSH adaptation of contract-first, role-based development workflows.
export function createFullstackTemplate(members, worker, reviewer) {
  const workers = members.filter(member => member.enabled && !member.readOnly);
  const executor = index => (workers.length ? workers[index % workers.length] : worker).id;
  const skills = Object.fromEntries(builtinWorkflowSkills().map(skill => [skill.id, skill]));
  const node = (id, label, stage, role, instructions, x, y, index = 0, skill) => ({
    id, label, stage, role, instructions, mode: 'worker', memberId: role === 'review' ? reviewer.id : executor(index),
    readOnly: ['planning', 'scheduling', 'review'].includes(role), reviewerId: stage === 'work' ? reviewer.id : null,
    maxReworks: 2, timeoutMs: 0, position: { x, y }, ...(skill ? { skills: [skills[`builtin-skill-${skill}`]] } : {}),
  });
  const nodes = [
    node('fullstack-plan', '产品负责人 · 需求拆分', 'plan', 'planning',
      '核对现有项目、用户目标、修改范围和可验证的验收标准，区分明确需求与假设。为架构契约、前端设计、前端开发、后端开发、联调、测试分别安排任务、写入范围和交付物。遵循画布依赖：前后端开发等待接口契约，前端还需等待 UX 设计，联调等待两端，测试等待联调。将需求与验收清单完整写入 JSON summary。此模板默认完整分工，所有工作节点 selected=true。不要另行派发子模型。', 300, 0, 0, 'requirements'),
    node('fullstack-plan-review', '方案评审 · 范围与依赖', 'plan-review', 'review',
      '独立核对需求覆盖、交付标准、写入范围、并行任务的文件冲突和真实依赖。检查架构、UX 设计、前后端、联调与测试的交付物是否明确。缺少业务决定时指出缺口，不猜测。只读审议，返回编排要求的 JSON 结论。', 300, 400, 0, 'review'),
    node('fullstack-dispatch', '项目经理 · 排期与交接', 'dispatch', 'scheduling',
      '依据已批准方案确认节点职责、前置交付物、模型与文件范围。记录可并行的前后端工作及共享文件负责人；不直接修改项目，不自行启动额外模型，实际调度由任务依赖图完成。', 300, 800, 0, 'handoff'),
    node('fullstack-contract', '架构师 · 接口与数据契约', 'work', 'planning',
      '先读取现有架构再设计。交付前后端共同遵循的接口清单、请求与响应示例、字段类型、校验、错误语义、鉴权约定和数据模型；仅在需求需要时提出迁移。沿用技术栈，不默认引入框架或服务。以完整契约作为节点结果供下游读取，只读设计，不修改代码。', 600, 1200),
    node('fullstack-ux', 'UI/UX 设计师 · 页面与交互', 'work', 'planning',
      '依据原需求和现有产品交付页面结构、用户路径、组件清单、交互状态及验收点，覆盖加载、空白、错误、关闭、返回、键盘和窄屏行为。沿用设计语言与组件，明确所需数据，不发明与架构师冲突的接口。以可执行设计说明作为结果，只读设计，不修改代码。', 0, 1200, 1),
    node('fullstack-frontend', '前端工程师 · 页面与交互', 'work', 'implementation',
      '读取已完成的接口契约和 UX 设计后实现前端。沿用组件、路由、状态和样式约定，处理真实接口、加载与错误状态；使用 Mock 时明确隔离并说明。只修改分配的前端范围，不私自更改公共契约或后端。交付文件、入口、适用测试及真实结果，契约缺口记录后交回协调。', 0, 1600, 0, 'implementation'),
    node('fullstack-backend', '后端工程师 · API 与数据', 'work', 'implementation',
      '读取已完成的接口与数据契约后实现后端，覆盖路由、业务逻辑、参数校验、权限和错误处理；按实际需求处理数据库或迁移。只修改分配的后端范围，不私自更改公共契约或前端。交付接口示例、文件、迁移或回退说明及真实测试结果。共享配置遵守方案中的负责人分配。', 600, 1600, 1, 'implementation'),
    node('fullstack-integration', '联调工程师 · 前后端集成', 'work', 'implementation',
      '等待前后端均完成后核对真实请求、响应、鉴权、错误展示和关键业务路径，检查契约偏差。只在批准的集成范围做必要修正；问题属于单侧时明确责任节点与复现。交付运行入口、联调命令、真实结果及未完成项，不把 Mock 联通宣称为真实联通。', 300, 2000, 2, 'implementation'),
    node('fullstack-qa', '测试工程师 · 回归与质量', 'work', 'test',
      '等待联调后独立核对用户验收清单，执行适用的前端、后端与端到端测试，检查交互、权限与回归。只在批准的测试范围补充测试，不代替实现者修改产品代码。问题须给出责任节点、复现、命令与真实结果；明确未运行及受环境阻塞的检查。', 300, 2400, 2, 'regression'),
    node('fullstack-join', '交付负责人 · 汇总成果', 'join', 'scheduling',
      '等待全部工作节点完成，核对需求、接口契约、UX 设计、两端实现、联调和测试证据是否一致。汇总文件与入口、命令、结果、缺口和交接说明，不将未运行检查标为已完成，不代替独立验收。', 300, 2800, 0, 'handoff'),
    node('fullstack-final-review', '独立验收 · 需求与证据', 'final-review', 'review',
      '以原始需求逐项核对实际代码、联调与测试证据，独立判断交付。失败时在 reworkNodeIds 填写具体责任工作节点：fullstack-contract、fullstack-ux、fullstack-frontend、fullstack-backend、fullstack-integration 或 fullstack-qa。只返工失败节点及其依赖后继，保留独立通过的成果。只读验收，不修复实现，不编造批准。', 300, 3200, 0, 'review'),
    node('fullstack-report', '交付汇报 · 结果与入口', 'report', 'planning',
      '依据真实验收结论向原主控会话汇报实现内容、文件与运行入口、测试、未解决问题和后续建议。区分设计说明、已落地代码和未验证内容。发布、部署及远程推送遵循用户现有授权，不将本地完成宣称为已上线。', 300, 3600),
  ];
  const work = nodes.filter(item => item.stage === 'work');
  const pairs = [
    ['fullstack-plan', 'fullstack-plan-review'], ['fullstack-plan-review', 'fullstack-dispatch'],
    ...work.flatMap(item => [['fullstack-dispatch', item.id], [item.id, 'fullstack-join']]),
    ['fullstack-contract', 'fullstack-frontend'], ['fullstack-ux', 'fullstack-frontend'],
    ['fullstack-contract', 'fullstack-backend'], ['fullstack-frontend', 'fullstack-integration'],
    ['fullstack-backend', 'fullstack-integration'], ['fullstack-integration', 'fullstack-qa'],
    ['fullstack-join', 'fullstack-final-review'], ['fullstack-final-review', 'fullstack-report'],
  ];
  const edges = pairs.map(([source, target], i) => ({ id: `fullstack-${i}`, source, target, condition: 'passed' }));
  edges.push({ id: 'fullstack-plan-rejected', source: 'fullstack-plan-review', target: 'fullstack-plan', condition: 'rejected' },
    ...work.map(item => ({ id: `${item.id}-rework`, source: 'fullstack-final-review', target: item.id, condition: 'rejected' })));
  return { id: 'template-fullstack', name: '全栈开发团队', version: 1, kind: 'orchestration', entry: 'fullstack-plan',
    orchestration: { selection: 'all', maxPlanRejections: 2, maxResultReworks: 2 }, nodes, edges };
}
