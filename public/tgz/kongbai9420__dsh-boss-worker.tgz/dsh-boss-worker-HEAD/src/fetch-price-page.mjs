import { execFile } from 'node:child_process';
import { PRICE_SOURCES } from './pricing-sources.mjs';
// Windows' HTTPS client follows the system network configuration. Some public
// documentation sites reject Node's HTTP client while accepting this client.
// Only the fixed public tariff URLs can reach the shell. TLS checks stay on.
export async function fetchWindowsPricePage(source) {
  if (process.platform !== 'win32' || !Object.hasOwn(PRICE_SOURCES, source)) throw new Error('Windows 官方价格读取不可用');
  const url = PRICE_SOURCES[source].url;
  const command = `$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); $pricePage=Invoke-WebRequest -UseBasicParsing -Uri '${url}' -MaximumRedirection 0 -TimeoutSec 15; [Console]::Write($pricePage.Content)`;
  // Desktop wraps execFile to hide Windows consoles; its wrapper may not retain
  // Node's custom promisify symbol. Use the documented callback shape directly.
  return new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', command], { windowsHide: true, timeout: 20000, maxBuffer: 4 * 1024 * 1024, encoding: 'utf8' }, (error, stdout) => {
      if (error) reject(error);
      else if (typeof stdout !== 'string' || !stdout.trim()) reject(new Error('官方价格页面为空，保留已有价格'));
      else resolve(stdout);
    });
  });
}
