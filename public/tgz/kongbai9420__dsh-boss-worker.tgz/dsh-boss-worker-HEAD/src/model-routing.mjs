const check = (ok, message) => { if (!ok) throw Object.assign(new Error(message), { code: 'INVALID_ROUTING' }); };
const copy = value => JSON.parse(JSON.stringify(value));
import { normalizeModel } from './execution-model.mjs';
export function normalizeModelRouting(value = {}, members = []) {
  check(value && typeof value === 'object' && !Array.isArray(value), '模型路由配置无效');
  check(Object.keys(value).every(key => ['enabled', 'classification', 'simple', 'complex', 'autoEscalate', 'fallbacks'].includes(key)), '模型路由含未知字段');
  const enabled = value.enabled ?? false, classification = value.classification || 'auto', autoEscalate = value.autoEscalate ?? false;
  check(typeof enabled === 'boolean' && typeof autoEscalate === 'boolean' && ['auto', 'manual'].includes(classification), '模型路由开关或分级方式无效');
  const route = input => {
    const item = input || {};
    check(typeof item === 'object' && !Array.isArray(item) && Object.keys(item).every(key => ['memberId', 'modelConfig', 'maxReworks', 'timeoutMs'].includes(key)), '模型档位配置无效');
    const modelConfig = item.modelConfig ? normalizeModel(item.modelConfig) : null;
    const memberId = modelConfig?.id || item.memberId || null, maxReworks = item.maxReworks ?? 2, timeoutMs = item.timeoutMs ?? 0;
    check(memberId === null || typeof memberId === 'string', '模型档位需要有效成员');
    check(Number.isSafeInteger(maxReworks) && maxReworks >= 0 && maxReworks <= 1000, '返工次数应为 0 至 1000');
    check(Number.isSafeInteger(timeoutMs) && timeoutMs >= 0 && timeoutMs <= 2147483647, '超时时间无效');
    if (enabled) check(modelConfig || members.some(member => member.id === memberId && member.enabled && !member.id.startsWith('task-route-')), '请为每个模型档位选择可用模型');
    return { memberId, ...(modelConfig ? { modelConfig } : {}), maxReworks, timeoutMs };
  };
  check(Array.isArray(value.fallbacks || []), '后继模型应为列表');
  return { enabled, classification, simple: route(value.simple), complex: route(value.complex), autoEscalate, fallbacks: (value.fallbacks || []).map(route) };
}

export function prepareModelRoute(task, policy, template) {
  const dynamic = node => node.mode === 'worker' && node.modelSelection && node.modelSelection !== 'fixed';
  const usesTaskTier = !task.locked && (template ? template.nodes.some(node => dynamic(node) && node.modelSelection === 'task') : policy.enabled);
  const explicitTier = template?.nodes.some(dynamic);
  if (explicitTier && !task.locked) check(policy.enabled, '模板使用模型档位，请先启用模型路由');
  if (usesTaskTier && (!task.difficulty || !task.difficultyReason.trim() || policy.classification === 'manual' && task.difficultySource !== 'user')) {
    return { pending: true, definition: null, routing: { source: 'difficulty', pendingClassification: true, pendingDefinition: template ? copy(template) : null, generatedWorkflow: false, reason: '等待用户分级或主控提交难度与理由' } };
  }
  if (template) {
    const definition = copy(template);
    const nodes = definition.nodes.filter(dynamic);
    for (const node of nodes) {
      const tier = node.modelSelection === 'task' ? task.difficulty : node.modelSelection;
      node.memberId = task.locked ? task.memberId : policy[tier].memberId;
      if (!task.locked && policy[tier].modelConfig) node.modelConfig = copy(policy[tier].modelConfig); else delete node.modelConfig;
    }
    const entry = definition.nodes.find(node => node.id === definition.entry);
    if (task.locked && entry?.mode === 'worker') { entry.memberId = task.memberId; entry.modelSelection = 'fixed'; if (task.memberSnapshot) entry.modelConfig = copy(task.memberSnapshot); else delete entry.modelConfig; }
    return { definition, routing: nodes.length ? { source: 'template', tier: task.difficulty, generatedWorkflow: false, pendingClassification: false, reason: task.difficultyReason || '模板指定模型档位' } : null };
  }
  if (!policy.enabled || task.locked) return { definition: null, routing: null };
  const tier = task.difficulty;
  const chain = [{ ...policy[tier], tier }, ...(policy.autoEscalate ? [...(tier === 'simple' ? [{ ...policy.complex, tier: 'complex' }] : []), ...policy.fallbacks.map((item, i) => ({ ...item, tier: `fallback-${i + 1}` }))] : [])];
  const nodes = chain.map((item, i) => ({ id: `route-${i}`, label: item.tier === 'simple' ? '经济模型执行' : item.tier === 'complex' ? '复杂任务模型执行' : `后继模型 ${i - (tier === 'simple' ? 1 : 0)}`, memberId: item.memberId, ...(item.modelConfig ? { modelConfig: copy(item.modelConfig) } : {}), mode: 'worker', role: task.readOnly ? 'planning' : 'implementation', readOnly: task.readOnly, maxReworks: item.maxReworks, timeoutMs: item.timeoutMs, position: { x: i * 300, y: 100 } }));
  const edges = nodes.slice(1).flatMap((node, i) => ['rework_limit', 'timeout', 'error'].map(condition => ({ id: `route-${i}-${condition}`, source: nodes[i].id, target: node.id, condition })));
  return { definition: { id: `model-route-${task.id}`, name: `${tier === 'simple' ? '简单' : '复杂'}任务模型路由`, version: 1, entry: nodes[0].id, nodes, edges }, routing: { source: 'difficulty', tier, generatedWorkflow: true, pendingClassification: false, reason: task.difficultyReason } };
}
