import { normalizeOrchestration } from './orchestration.mjs';
import { normalizeNodeSkills } from './workflow-skills.mjs';
import { createFullstackTemplate } from './fullstack-template.mjs';
import { normalizeModel } from './execution-model.mjs';
import { validateSafeRelativePath } from './contracts.mjs';
// A task owns one immutable workflow version; the outer task DAG owns concurrency.
const copy = value => JSON.parse(JSON.stringify(value));
const check = (ok, message) => { if (!ok) throw Object.assign(new Error(message), { code: 'INVALID_WORKFLOW' }); };
const text = value => typeof value === 'string' && value.trim().length > 0;
export const CONDITIONS = ['passed', 'rework_limit', 'timeout', 'error', 'rejected'];
export function normalizeWorkflow(input) {
  check(input && Array.isArray(input.nodes) && input.nodes.length > 0 && Array.isArray(input.edges), '流程需要节点与条件连线');
  const dag = input.kind === 'dag' || input.kind !== 'orchestration' && input.edges.some(edge => edge.condition === 'passed' && input.edges.filter(other => other.source === edge.source && other.condition === 'passed').length > 1);
  const ids = new Set();
  const nodes = input.nodes.map((n, index) => {
    check(text(n.id) && !ids.has(n.id), '节点 ID 必须唯一'); ids.add(n.id);
    const mode = n.mode || 'worker';
    const modelSelection = n.modelSelection || 'fixed';
    check(['fixed', 'task', 'simple', 'complex'].includes(modelSelection), '无效模型选择方式');
    check(['worker', 'controller-child', 'controller'].includes(mode), '无效执行方式');
    const modelConfig = n.modelConfig ? normalizeModel(n.modelConfig) : null;
    const reviewerConfig = n.reviewerConfig ? normalizeModel(n.reviewerConfig) : null;
    check(mode !== 'worker' || modelSelection !== 'fixed' || modelConfig || text(n.memberId), '执行节点需要选择模型');
    check(Number.isSafeInteger(n.maxReworks ?? 2) && (n.maxReworks ?? 2) >= 0, '返工额度必须是非负整数');
    check(Number.isSafeInteger(n.timeoutMs ?? 0) && (n.timeoutMs ?? 0) >= 0 && (n.timeoutMs ?? 0) <= 2147483647, '超时必须是有效毫秒数（0 为不限时）');
    check(['implementation', 'test', 'review', 'planning', 'scheduling'].includes(n.role || 'implementation'), '无效节点职责');
    check(!n.reviewerId || text(n.reviewerId), '无效审查成员');
    check(mode !== 'controller' || reviewerConfig || text(n.reviewerId), '当前主控直接执行必须配置独立验收模型');
    return { id: n.id, label: text(n.label) ? n.label : n.id, mode, modelSelection, memberId: modelConfig?.id || n.memberId || null,
      ...(modelConfig ? { modelConfig } : {}), ...(reviewerConfig ? { reviewerConfig } : {}),
      ...(n.writeScopes !== undefined ? { writeScopes: (() => { check(Array.isArray(n.writeScopes), '节点写入范围必须为列表'); return n.writeScopes.map(path => path === '**' || path === '.' ? path : validateSafeRelativePath(path, '节点写入范围')); })() } : {}),
      role: n.role || 'implementation', instructions: n.instructions || '', ...(n.skills?.length || n.skills !== undefined ? { skills: normalizeNodeSkills(n.skills) } : {}), maxReworks: n.maxReworks ?? 2,
      timeoutMs: n.timeoutMs ?? 0, reviewerId: reviewerConfig?.id || n.reviewerId || null, readOnly: Boolean(n.readOnly || ['review', 'planning', 'scheduling'].includes(n.role)),
      ...(input.kind === 'orchestration' ? { stage: n.stage } : {}),
      position: { x: Number.isFinite(n.position?.x) ? n.position.x : index * 280, y: Number.isFinite(n.position?.y) ? n.position.y : 80 } };
  });
  const entry = input.entry || nodes[0].id;
  check(ids.has(entry), '入口节点不存在');
  const conditions = new Set();
  const edges = input.edges.map((e, index) => {
    check(ids.has(e.source) && ids.has(e.target) && CONDITIONS.includes(e.condition), '连线需要有效起点、终点与条件');
    const key = `${e.source}:${e.condition}`;
    check(input.kind === 'orchestration' || dag && e.condition === 'passed' || !conditions.has(key), '接管链同一节点的同一条件只能有一个后继'); conditions.add(key);
    check(Number.isSafeInteger(e.maxTraversals ?? 1) && (e.maxTraversals ?? 1) > 0, '连线最大经过次数必须大于零');
    return { id: text(e.id) ? e.id : `edge-${index}`, source: e.source, target: e.target, condition: e.condition, maxTraversals: e.maxTraversals ?? 1 };
  });
  check(new Set(edges.map(e => e.id)).size === edges.length, '连线 ID 必须唯一');
  const reachable = new Set([entry]);
  for (let i = 0; i < nodes.length; i++) for (const e of edges) if (reachable.has(e.source)) reachable.add(e.target);
  check(nodes.every(n => reachable.has(n.id)), '存在从入口不可达的节点，请连接或移除');
  const definition = { id: text(input.id) ? input.id : 'workflow', name: input.name || '自定义流程', version: Number.isSafeInteger(input.version) && input.version > 0 ? input.version : 1, entry, nodes, edges };
  if (input.layoutDirection !== undefined) {
    check(['LR', 'TB'].includes(input.layoutDirection), '流程方向必须为 LR 或 TB');
    definition.layoutDirection = input.layoutDirection;
  }
  if (input.kind === 'orchestration') { definition.kind = 'orchestration'; definition.orchestration = normalizeOrchestration({ ...definition, orchestration: input.orchestration }); }
  if (dag) {
    definition.kind = 'dag';
    check(edges.every(e => ['passed', 'rejected'].includes(e.condition)), '并行流程使用通过依赖和封驳返工；超时或失败会暂停对应分支，等待重试');
    const done = new Set();
    for (let i = 0; i < nodes.length; i++) for (const node of nodes) if (edges.filter(e => e.condition === 'passed' && e.target === node.id).every(e => done.has(e.source))) done.add(node.id);
    check(done.size === nodes.length, '通过依赖不能成环；返工请使用封驳边');
    check(nodes.every(n => n.id === entry || edges.some(e => e.condition === 'passed' && e.target === n.id)), '并行流程的非入口节点必须有通过依赖');
    for (const edge of edges.filter(e => e.condition === 'rejected')) {
      const downstream = new Set([edge.target]);
      for (let i = 0; i < nodes.length; i++) for (const forward of edges.filter(e => e.condition === 'passed')) if (downstream.has(forward.source)) downstream.add(forward.target);
      check(downstream.has(edge.source), '并行流程的封驳目标必须是当前节点的前置节点或自身');
    }
  }
  return definition;
}
export function createWorkflowRun(definition) {
  check(!['orchestration', 'dag'].includes(definition.kind), '并行编排应应用为真实任务依赖图，不能作为单任务接管链运行');
  return { definition: normalizeWorkflow(definition), current: definition.entry || definition.nodes[0].id,
    reworks: 0, visits: [], transitions: [], handoffs: [], edgeCounts: {}, independentReviews: [] };
}
export const currentNode = task => task.workflow?.definition.nodes.find(n => n.id === task.workflow.current) || null;
export const reworkLimit = (task, config) => currentNode(task)?.maxReworks ?? config.maxRetries;
export function handoffContext(task, reason, settled = true) {
  return copy({ taskId: task.id, title: task.title, instructions: task.instructions, acceptance: task.acceptance,
    requirements: task.requirements, writeScopes: task.writeScopes, deliverables: task.deliverables,
    result: task.result, evidence: task.evidence, feedback: task.feedback, reviewHistory: task.reviewHistory,
    checkpoint: task.checkpoint, reason, settled, epoch: task.executionEpoch, at: new Date().toISOString() });
}
// Called only after the host has settled the old execution (review implies settled).
export function transitionWorkflow(task, condition) {
  const run = task.workflow;
  if (!run) return false;
  const edge = run.definition.edges.find(e => e.source === run.current && e.condition === condition);
  if (!edge) return false;
  const target = run.definition.nodes.find(node => node.id === edge.target);
  if (task.locked && task.routing?.generatedWorkflow && condition !== 'passed' && target.memberId !== task.memberId) { task.waitingReason = 'ROUTING_LOCKED'; return false; }
  if ((run.edgeCounts[edge.id] || 0) >= edge.maxTraversals) { task.waitingReason = 'WORKFLOW_LOOP_LIMIT'; return false; }
  const at = new Date().toISOString();
  run.handoffs.push(handoffContext(task, condition));
  run.transitions.push({ from: run.current, to: edge.target, condition, epoch: task.executionEpoch, at });
  run.edgeCounts[edge.id] = (run.edgeCounts[edge.id] || 0) + 1;
  run.current = edge.target; run.reworks = 0;
  const node = currentNode(task);
  // Controller nodes keep an assigned identity for existing board invariants.
  if (node.memberId) task.memberId = node.memberId;
  if (task.routing) task.routingHistory.push({ type: 'handoff', from: run.transitions.at(-1).from, to: run.current, memberId: task.memberId, reason: condition, at });
  task.status = 'pending'; task.phase = 'ready'; task.waitingReason = ''; task.result = null;
  return true;
}
export function requirementLedger(task) {
  return (task.requirements || []).map(req => {
    const records = (task.requirementEvidence || []).filter(e => e.requirementId === req.id && e.version === req.version && e.epoch === task.executionEpoch);
    const verified = records.filter(e => e.source === 'user' || e.source === 'independent-review');
    const latest = verified.at(-1);
    return { ...req, taskId: task.id, nodeId: task.workflow?.current || null, records,
      status: latest?.status === 'gap' ? 'gap' : latest?.status === 'verified' && latest.reference.trim() ? 'verified' : 'unknown' };
  });
}
export function workflowTemplates(members) {
  const worker = members.find(m => m.enabled && !m.readOnly) || members.find(m => m.enabled);
  const reviewer = members.find(m => m.enabled && m.readOnly) || worker;
  if (!worker) return [];
  const node = (id, role = 'implementation') => ({ id, label: id, memberId: (role === 'review' ? reviewer : worker).id, mode: 'worker', role, readOnly: role === 'review', maxReworks: 2, timeoutMs: 0, reviewerId: role === 'implementation' ? reviewer.id : null });
  const templates = [['快速处理', ['执行']], ['标准开发', ['实现', '测试']], ['复杂工程', ['方案', '实现', '测试', '审计']]].map(([name, labels], index) => {
    const nodes = labels.map((label, i) => ({ ...node(`n${i}`, /审议|审计|验证/.test(label) ? 'review' : /测试/.test(label) ? 'test' : /方案/.test(label) ? 'planning' : /调度/.test(label) ? 'scheduling' : 'implementation'), label, position: { x: i * 280, y: 100 } }));
    return normalizeWorkflow({ id: `template-${index}`, name, version: 1, entry: nodes[0].id, nodes, edges: nodes.slice(1).map((n, i) => ({ id: `e${i}`, source: nodes[i].id, target: n.id, condition: 'passed' })) });
  });
  const offices = [
    ['zhongshu-plan', '中书省 · 需求与方案', 'planning', '理解任务与范围，判断规模，列出阻塞问题、需求与可核对的验收标准。只输出方案，不修改项目。'],
    ['menxia-spec', '门下省 · 独立审议', 'review', '独立核对需求、方案、范围和风险，给出明确审议结论及具体缺口，不替实现者修改代码。'],
    ['shangshu-plan', '尚书省 · 调度与六部扫描', 'scheduling', '扫描吏、户、礼、兵、工、刑六个职责域，记录每个部门的具体工作或无需参与的理由。输出依赖顺序和交接事项，不另行派发子模型。'],
    ['libu', '吏部 · 仓库与职责', 'planning', '检查仓库结构、模块责任和任务依赖，明确后续执行范围与交接顺序；无需此项工作时说明理由。'],
    ['hubu', '户部 · 数据与依赖', 'implementation', '只处理当前任务确实需要的数据、状态、迁移、依赖与资源问题；无需改动时说明理由，保留已有成果。'],
    ['libu-interfaces', '礼部 · 接口与文档', 'implementation', '负责当前任务的接口契约、界面体验、兼容性、可访问性与文档；无关项目不改动。'],
    ['bingbu', '兵部 · 产品实现', 'implementation', '实现本任务的产品行为和核心代码，遵守既定范围，报告文件、命令与真实结果，不自我批准。'],
    ['gongbu', '工部 · 构建与交付', 'implementation', '处理本任务相关的构建、工具链、集成与本地打包。发布或部署须遵循用户现有授权；没有相关工作时说明理由。'],
    ['xingbu', '刑部 · 测试与安全', 'test', '独立运行适用测试、复现问题、检查权限与回归，提供命令及真实输出；不要把未运行的检查标为通过。'],
    ['menxia-final', '门下省 · 最终验收', 'review', '以原需求、验收标准和执行证据独立核验成果，逐项列出通过或缺口。只读检查，不代替执行部门修复。'],
    ['zhongshu-report', '中书省 · 结案汇报', 'planning', '依据实际交付与验收证据汇报完成项、测试、风险和未完成项，给出交付入口，不编造结案或用户确认。'],
  ];
  const stages = ['plan', 'plan-review', 'dispatch', ...Array(6).fill('work'), 'final-review', 'report'];
  const nodes = offices.map(([id, label, role, instructions], i) => ({ ...node(id, role), label, instructions, stage: stages[i], readOnly: ['planning', 'scheduling', 'review'].includes(role), reviewerId: stages[i] === 'work' ? reviewer.id : null, position: { x: i >= 3 && i <= 8 ? (i - 3) * 300 : 750, y: i < 3 ? i * 400 : i <= 8 ? 1200 : i === 9 ? 2000 : 2400 } }));
  nodes.splice(9, 0, { ...node('shangshu-join', 'scheduling'), label: '尚书省 · 汇合成果', instructions: '只汇总所有已选部门的真实交付、证据与未完成项，不能跳过失败分支。', stage: 'join', readOnly: true, reviewerId: null, position: { x: 750, y: 1600 } });
  const pairs = [['zhongshu-plan', 'menxia-spec'], ['menxia-spec', 'shangshu-plan'], ...nodes.filter(n => n.stage === 'work').flatMap(n => [['shangshu-plan', n.id], [n.id, 'shangshu-join']]), ['shangshu-join', 'menxia-final'], ['menxia-final', 'zhongshu-report']];
  const edges = pairs.map(([source, target], i) => ({ id: `tang-${i}`, source, target, condition: 'passed' }));
  edges.push({ id: 'plan-rejected', source: 'menxia-spec', target: 'zhongshu-plan', condition: 'rejected' }, { id: 'result-rejected', source: 'menxia-final', target: 'shangshu-plan', condition: 'rejected' });
  templates.push(normalizeWorkflow({ id: 'template-3', name: '三省六部', kind: 'orchestration', version: 2, entry: nodes[0].id, nodes, edges }));
  templates.push(normalizeWorkflow(createFullstackTemplate(members, worker, reviewer)));
  return templates.map(definition => definition.kind === 'orchestration' ? normalizeWorkflow({ ...definition, layoutDirection: 'LR', nodes: definition.nodes.map(node => ({ ...node, position: { x: node.position.y * .85, y: node.position.x * 1.2 } })) }) : definition);
}
