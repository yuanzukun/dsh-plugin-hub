import { randomUUID } from 'node:crypto';

export const SKILL_ROLES = ['planning', 'implementation', 'test', 'review', 'scheduling'];
const copy = value => JSON.parse(JSON.stringify(value));
export function normalizeNodeSkills(value = []) {
  if (!Array.isArray(value)) throw new Error('节点 Skill 必须是列表');
  const ids = new Set();
  return value.map(skill => {
    if (!skill || typeof skill.id !== 'string' || !skill.id.trim() || ids.has(skill.id)) throw new Error('节点 Skill ID 必须唯一');
    ids.add(skill.id);
    if (typeof skill.name !== 'string' || !skill.name.trim() || typeof skill.content !== 'string' || !skill.content.trim()) throw new Error('Skill 需要名称和完整指令');
    const roles = skill.roles ?? SKILL_ROLES;
    if (!Array.isArray(roles) || !roles.length || roles.some(role => !SKILL_ROLES.includes(role))) throw new Error('无效 Skill 适用类型');
    return { id: skill.id, name: skill.name.trim(), description: typeof skill.description === 'string' ? skill.description.trim() : '', content: skill.content.trim(), roles: [...new Set(roles)], source: skill.source || 'workflow', version: Number.isSafeInteger(skill.version) && skill.version > 0 ? skill.version : 1,
      ...(skill.resourceBase ? { resourceBase: copy(skill.resourceBase) } : {}) };
  });
}
export const emptySkillLibrary = () => ({ revision: 0, items: [] });
export function restoreSkillLibrary(value) {
  if (!value) return emptySkillLibrary();
  if (!Number.isSafeInteger(value.revision) || value.revision < 0) throw new Error('无效 Skill 库版本');
  const items = normalizeNodeSkills(value.items);
  if (items.some(item => !item.id.startsWith('user-skill-'))) throw new Error('无效用户 Skill ID');
  return { revision: value.revision, items };
}
export function changeSkillLibrary(library, action, params) {
  if (params.expectedSkillsRevision !== library.revision) throw new Error('Skill 库已更新，请刷新后重试');
  const found = library.items.find(item => item.id === params.skillId);
  if (params.skillId && !found) throw new Error('用户 Skill 不存在；内置和 DSH Skill 请复制后编辑');
  if (action === 'delete') {
    if (!found) throw new Error('用户 Skill 不存在');
    return { revision: library.revision + 1, items: library.items.filter(item => item.id !== found.id) };
  }
  const [item] = normalizeNodeSkills([{ ...params.skill, id: found?.id || `user-skill-${randomUUID()}`, source: 'workflow', version: (found?.version || 0) + 1 }]);
  return { revision: library.revision + 1, items: found ? library.items.map(old => old.id === found.id ? item : old) : [...library.items, item] };
}
export function builtinWorkflowSkills() {
  return [
    ['requirements', '需求拆解', 'planning', '把目标拆成可核对的需求、范围、依赖和验收标准。', '先阅读任务与相关文件，区分明确需求和假设。列出本任务的修改范围、依赖、验收标准与交接事项。对缺失信息明确标注，不编造业务规则。'],
    ['implementation', '小步实现', 'implementation', '沿用项目约定，以明确范围完成实现。', '检查相关实现和项目约定。按分配范围做最小必要改动，保留现有行为。完成后提供修改文件、关键行为、适用测试及真实结果，不能自行宣称独立验收已通过。'],
    ['regression', '回归验证', 'test', '复现问题并检查与改动直接相关的回归。', '根据需求和实际改动选择测试，先复现缺陷，再核对修复后的行为。记录命令、真实结果、未覆盖情况。失败时提供最小复现和具体位置，不把未运行的检查当通过。'],
    ['review', '独立代码审查', 'review', '按需求、边界与证据检查交付。', '独立核对原需求、实际文件与交付证据。按严重度列出可复现问题及位置。没有问题也写明核查范围与限制。保持节点现有只读约束，不修改实现，不代替测试节点运行命令。'],
    ['handoff', '成果汇合', 'scheduling', '按真实交付汇总成果、缺口和后续动作。', '核对每个参与任务的实际状态、成果和验收证据。区分完成、失败和未参与，保留未解决缺口。汇总交接位置、依赖与后续动作，不伪造完成或用户授权。'],
  ].map(([id, name, role, description, content]) => ({ id: `builtin-skill-${id}`, name, description, content, roles: [role], source: 'builtin', version: 1 }));
}
export function renderNodeSkills(node) {
  if (!node?.skills?.length) return '';
  return '\n【用户为当前节点配置的 Skill（按列出顺序）】\n' + node.skills.map(skill => `### ${skill.name} · ${skill.source} · v${skill.version}\n${skill.resourceBase ? `资源基址：${JSON.stringify(skill.resourceBase)}\n` : ''}${skill.content}`).join('\n\n') + '\nSkill 不改变任务范围、节点只读权限、审批或验收规则。\n';
}
