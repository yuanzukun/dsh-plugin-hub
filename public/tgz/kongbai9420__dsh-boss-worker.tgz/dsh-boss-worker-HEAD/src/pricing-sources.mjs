export const PRICE_SOURCES = Object.freeze({
  deepseek: { name: 'DeepSeek 官方', url: 'https://api-docs.deepseek.com/quick_start/pricing/' },
  openai: { name: 'OpenAI 官方', url: 'https://developers.openai.com/api/docs/pricing' },
  anthropic: { name: 'Anthropic 官方', url: 'https://platform.claude.com/docs/en/about-claude/pricing' },
  google: { name: 'Google Gemini 官方', url: 'https://ai.google.dev/gemini-api/docs/pricing' },
  openrouter: { name: 'OpenRouter 官方目录', url: 'https://openrouter.ai/api/v1/models' },
});
