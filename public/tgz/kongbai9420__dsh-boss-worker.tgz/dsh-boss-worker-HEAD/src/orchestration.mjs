// Outer task DAG. Model handoff remains local to each real task.
const clone = value => JSON.parse(JSON.stringify(value));
const requireValue = (ok, message) => { if (!ok) throw Object.assign(new Error(message), { code: 'INVALID_ORCHESTRATION' }); };
export const ORCHESTRATION_STAGES = ['plan', 'plan-review', 'dispatch', 'work', 'join', 'final-review', 'report'];
export function normalizeOrchestration(definition) {
  const stages = definition.nodes.map(node => node.stage);
  for (const stage of ORCHESTRATION_STAGES.filter(stage => stage !== 'work')) requireValue(stages.filter(value => value === stage).length === 1, `编排必须有且只有一个 ${stage} 阶段`);
  requireValue(stages.every(stage => ORCHESTRATION_STAGES.includes(stage)), '编排节点需要有效阶段');
  const config = definition.orchestration || {};
  for (const field of ['maxPlanRejections', 'maxResultReworks']) requireValue(Number.isSafeInteger(config[field] ?? 2) && (config[field] ?? 2) >= 0, '审议和成果返工上限必须为非负整数');
  requireValue(['on-demand', 'all'].includes(config.selection || 'on-demand'), '请选择按需分工或完整职责检查');
  const forward = definition.edges.filter(edge => edge.condition === 'passed');
  const phases = ['plan', 'plan-review', 'dispatch', 'work', 'join', 'final-review', 'report'];
  const stageOf = id => definition.nodes.find(node => node.id === id)?.stage;
  requireValue(stageOf(definition.entry) === 'plan', '编排必须从规划阶段开始');
  requireValue(definition.edges.every(edge => ['passed', 'rejected'].includes(edge.condition)), '编排使用通过依赖和封驳边，模型接管规则请配置在任务内部');
  requireValue(definition.edges.filter(edge => edge.condition === 'rejected').every(edge => stageOf(edge.source) === 'plan-review' && stageOf(edge.target) === 'plan' || stageOf(edge.source) === 'final-review' && ['work', 'dispatch'].includes(stageOf(edge.target))), '治理编排的封驳边只支持方案审议返回规划、最终验收返回工作或调度节点；其他返工请使用自由并行流程');
  requireValue(forward.every(edge => phases.indexOf(stageOf(edge.source)) <= phases.indexOf(stageOf(edge.target))), '编排阶段顺序不能绕回；返工请使用封驳边');
  for (const stage of ['plan-review', 'final-review']) requireValue(definition.nodes.find(n => n.stage === stage).mode !== 'controller', '审议和最终验收需要独立执行上下文');
  const has = (sourceStage, target) => forward.some(edge => stageOf(edge.source) === sourceStage && edge.target === target.id);
  for (const node of definition.nodes) {
    const prerequisite = ({ 'plan-review': 'plan', dispatch: 'plan-review', work: 'dispatch', 'final-review': 'join', report: 'final-review' })[node.stage];
    if (prerequisite) requireValue(has(prerequisite, node), `节点 ${node.label} 缺少 ${prerequisite} 前置阶段`);
  }
  const join = definition.nodes.find(n => n.stage === 'join');
  requireValue(definition.nodes.filter(n => n.stage === 'work').every(n => forward.some(edge => edge.source === n.id && edge.target === join.id)), '汇合必须等待所有已选部门');
  const done = new Set();
  for (let i = 0; i < definition.nodes.length; i++) for (const node of definition.nodes) if (forward.filter(edge => edge.target === node.id).every(edge => done.has(edge.source))) done.add(node.id);
  requireValue(done.size === definition.nodes.length, '执行依赖不能成环；返工使用 rejected 边和新代次');
  return { selection: config.selection || 'on-demand', maxPlanRejections: config.maxPlanRejections ?? 2, maxResultReworks: config.maxResultReworks ?? 2 };
}
export function controlResult(task) {
  const output = task?.result?.output;
  try { return typeof output === 'string' ? JSON.parse(output.trim().replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, '')) : null; }
  catch { return null; }
}
export function validateControlOutput(node, task) {
  if (!['plan', 'plan-review', 'final-review'].includes(node.stage)) return;
  const record = controlResult(task);
  if (node.stage === 'plan') requireValue(Array.isArray(record?.departments), '规划节点必须返回包含 departments 数组的结构化方案');
  else requireValue(typeof record?.approved === 'boolean' && typeof record.feedback === 'string', '审议必须返回 approved 和 feedback，不接受文本猜测');
}
export function orchestrationPrompt(node, definition, original) {
  if (node.stage === 'plan') return `\n只返回 JSON {"summary":"方案概要","departments":[{"nodeId":"部门节点ID","selected":true,"reason":"参与或跳过理由","instructions":"具体任务","acceptance":["验收标准"],"writeScopes":["原任务范围内的具体目录"],"dependencies":["其他已选部门节点ID"]}]}。必须逐项覆盖以下部门：${definition.nodes.filter(n => n.stage === 'work').map(n => `${n.id}=${n.label}`).join('；')}。只读部门的 writeScopes 必须为空，保留画布中已经声明的前置依赖。${definition.orchestration.selection === 'all' ? '当前为完整分工模式，全部工作节点必须 selected=true，不可跳过。' : '按真实依赖按需分工，不强制所有部门调用。'}原任务允许写入范围：${JSON.stringify(original.writeScopes)}。`;
  if (['plan-review', 'final-review'].includes(node.stage)) return `\n仅返回 JSON {"approved":true或false,"feedback":"独立核验结论及实际依据","reworkNodeIds":["成果不合格时需要重做的部门节点ID"],"evidence":[{"requirementId":"需求ID","version":1,"status":"verified或gap或unknown","reference":"实际文件或验证命令与结果"}]}。${node.stage === 'plan-review' ? '核验完整结构化方案、职责、依赖和范围；封驳后按画布返工。' : `逐项独立核验原需求；通过时 evidence 必须覆盖 ${JSON.stringify((Array.isArray(original.acceptance) ? original.acceptance : [original.acceptance]).map((criterion, i) => ({ requirementId: `${original.id}-R${i + 1}`, version: 1, criterion })))}。缺少实际依据不得批准。`}`;
  return '';
}
export function createOrchestration(original, definition, makeTask) {
  if (definition.kind === 'dag') return createDependencyGraph(original, definition, makeTask);
  const rootId = original.id, taskIds = {};
  for (const node of definition.nodes) taskIds[node.id] = node.stage === 'report' ? rootId : `${rootId}::${node.id}`;
  const run = { id: rootId, definition: clone(definition), original: clone(original), taskIds, skipped: {}, planRejections: 0, resultReworks: 0, generation: 1, history: [], status: 'active' };
  const tasks = definition.nodes.map(node => {
    const dependencies = definition.edges.filter(edge => edge.condition === 'passed' && edge.target === node.id).map(edge => taskIds[edge.source]);
    if (node.id === definition.entry) dependencies.push(...original.dependencies);
    return makeTask(node, { id: taskIds[node.id], title: `${original.title} · ${node.label}`, instructions: `${original.instructions}\n【原验收标准】${JSON.stringify(original.acceptance)}\n\n【部门职责】${node.instructions}${orchestrationPrompt(node, definition, original)}`, acceptance: node.stage === 'report' ? original.acceptance : [`完成 ${node.label} 的职责，并提供真实依据`], memberId: original.locked && node.stage === 'work' ? original.memberId : node.memberId || original.memberId, locked: original.locked, dependencies, writeScopes: node.readOnly || original.readOnly ? [] : original.writeScopes, readOnly: Boolean(node.readOnly || original.readOnly), difficulty: original.difficulty, difficultyReason: original.difficultyReason });
  });
  return { run, tasks };
}
const within = (path, scope) => { const a = path.replace(/\\/g, '/').replace(/\/$/, ''), b = scope.replace(/\\/g, '/').replace(/\/$/, ''); return b === '**' || b === '.' || a === b || a.startsWith(`${b}/`); };
export function reviewOrchestration(state, taskId) {
  const next = clone(state), task = next.tasks.find(t => t.id === taskId), address = task?.orchestration;
  if (!address || task.status !== 'done') return next;
  const run = next.orchestrations[address.id], definition = run.definition, node = definition.nodes.find(n => n.id === address.nodeId);
  if (definition.kind === 'dag') { if (task.id === run.id) run.status = 'done'; return next; }
  validateControlOutput(node, task);
  if (run.status === 'needs_attention') run.status = 'active';
  const byNode = id => next.tasks.find(t => t.id === run.taskIds[id]);
  const rewind = (ids, reason) => {
    const affected = new Set(ids);
    for (let i = 0; i < definition.nodes.length; i++) for (const item of next.tasks.filter(t => t.orchestration?.id === run.id)) if (item.dependencies.some(dep => [...affected].some(id => run.taskIds[id] === dep))) affected.add(item.orchestration.nodeId);
    requireValue([...affected].every(id => byNode(id)?.status !== 'running'), '相关分支仍在运行，必须先停止并结算后再返工');
    for (const id of affected) {
      const item = byNode(id); if (!item || run.skipped[id]) continue;
      item.status = 'pending'; item.phase = 'ready'; item.result = null; item.feedback = reason; item.waitingReason = ''; item.executionApproval = null;
      if (item.executionEpoch > 0) {
        item.executionHistory.push({ epoch: item.executionEpoch, status: 'orchestration-rework', at: new Date().toISOString(), reason });
        // Old evidence stays attached to its old epoch and cannot approve new work.
        item.executionEpoch++;
      }
      if (item.workflow) item.workflow.reworks = 0;
    }
    run.generation++;
  };
  if (node.stage === 'plan-review') {
    const decision = controlResult(task);
    if (!decision.approved) {
      const targets = definition.edges.filter(edge => edge.source === node.id && edge.condition === 'rejected').map(edge => edge.target);
      if (!targets.length) { task.status = 'needs_attention'; task.phase = 'blocked'; task.waitingReason = 'REJECTED_NO_ROUTE'; run.status = 'needs_attention'; return next; }
      requireValue(targets.every(id => definition.nodes.find(n => n.id === id)?.stage === 'plan'), '方案封驳边必须返回规划节点');
      run.planRejections++;
      const plan = definition.nodes.find(n => n.stage === 'plan');
      if (run.planRejections > definition.orchestration.maxPlanRejections) { task.status = 'needs_attention'; task.phase = 'blocked'; task.waitingReason = 'PLAN_REJECTION_LIMIT'; run.status = 'needs_attention'; }
      else rewind(targets, decision.feedback);
      run.history.push({ type: 'plan-rejected', feedback: decision.feedback, generation: run.generation });
    } else {
      const planTask = byNode(definition.nodes.find(n => n.stage === 'plan').id), plan = controlResult(planTask);
      const departments = definition.nodes.filter(n => n.stage === 'work');
      requireValue(plan && Array.isArray(plan.departments) && plan.departments.length === departments.length && new Set(plan.departments.map(d => d.nodeId)).size === departments.length, '方案必须逐项覆盖所有部门，且不能重复');
      const selected = new Set();
      for (const office of departments) {
        const item = plan.departments.find(d => d.nodeId === office.id);
        requireValue(item && typeof item.selected === 'boolean' && typeof item.reason === 'string' && item.reason.trim(), '每个部门需要参与状态和具体理由');
        if (definition.orchestration.selection === 'all') requireValue(item.selected, '完整职责检查模式需要为每个部门规划具体检查任务');
        if (item.selected) selected.add(office.id);
      }
      requireValue(selected.size > 0, '至少需要一个实际执行部门');
      for (const office of departments) {
        const spec = plan.departments.find(d => d.nodeId === office.id), target = byNode(office.id);
        if (!spec.selected) { target.status = 'cancelled'; target.phase = 'failed'; target.waitingReason = 'NOT_SELECTED'; run.skipped[office.id] = spec.reason; continue; }
        delete run.skipped[office.id];
        if (target.status === 'cancelled' && target.waitingReason === 'NOT_SELECTED') { target.status = 'pending'; target.phase = 'ready'; target.waitingReason = ''; }
        requireValue(typeof spec.instructions === 'string' && spec.instructions.trim() && Array.isArray(spec.acceptance) && spec.acceptance.length > 0 && spec.acceptance.every(s => typeof s === 'string' && s.trim()), '已选部门需要任务说明和验收标准');
        requireValue(Array.isArray(spec.writeScopes) && spec.writeScopes.every(p => typeof p === 'string' && !p.split(/[\\/]/).includes('..') && run.original.writeScopes.some(s => within(p, s))) && (!target.readOnly || spec.writeScopes.length === 0), '部门写入范围不能超出原任务或只读权限');
        requireValue(Array.isArray(spec.dependencies) && new Set(spec.dependencies).size === spec.dependencies.length && spec.dependencies.every(id => selected.has(id) && id !== office.id), '部门依赖必须指向其他已选部门');
        target.instructions = `${run.original.instructions}\n\n【本部门工作】${spec.instructions}\n【职责】${office.instructions}`;
        target.acceptance = spec.acceptance; target.writeScopes = spec.writeScopes;
        target.dependencies = [...new Set([...definition.edges.filter(e => e.condition === 'passed' && e.target === office.id).map(e => run.taskIds[e.source]), ...spec.dependencies.map(id => run.taskIds[id])])];
        target.requirements = spec.acceptance.map((criterion, i) => ({ id: `${target.id}-R${i + 1}`, version: (target.requirements[i]?.version || 0) + 1, criterion }));
      }
      const skippedIds = new Set(Object.keys(run.skipped).map(id => run.taskIds[id]));
      for (const target of next.tasks.filter(t => t.orchestration?.id === run.id)) target.dependencies = target.dependencies.filter(id => !skippedIds.has(id));
      run.history.push({ type: 'plan-approved', departments: [...selected], generation: run.generation });
    }
  }
  if (node.stage === 'final-review') {
    const decision = controlResult(task);
    if (!decision.approved) {
      const routes = definition.edges.filter(edge => edge.source === node.id && edge.condition === 'rejected');
      if (!routes.length) { task.status = 'needs_attention'; task.phase = 'blocked'; task.waitingReason = 'REJECTED_NO_ROUTE'; run.status = 'needs_attention'; return next; }
      requireValue(Array.isArray(decision.reworkNodeIds) && decision.reworkNodeIds.length > 0 && decision.reworkNodeIds.every(id => definition.nodes.some(n => n.id === id && n.stage === 'work') && !run.skipped[id]), '最终验收需明确需要返工的实际部门');
      requireValue(decision.reworkNodeIds.every(id => routes.some(edge => edge.target === id || definition.nodes.find(n => n.id === edge.target)?.stage === 'dispatch')), '返工部门没有对应的封驳连线，请调整流程或审查结论');
      run.resultReworks++;
      if (run.resultReworks > definition.orchestration.maxResultReworks) { task.status = 'needs_attention'; task.phase = 'blocked'; task.waitingReason = 'RESULT_REWORK_LIMIT'; run.status = 'needs_attention'; }
      else rewind(decision.reworkNodeIds, decision.feedback);
      run.history.push({ type: 'result-rejected', departments: decision.reworkNodeIds, feedback: decision.feedback, generation: run.generation });
    } else {
      const root = next.tasks.find(t => t.id === run.id);
      const evidence = decision.evidence || [];
      requireValue(Array.isArray(evidence), '最终验收 evidence 必须为列表');
      const accepted = [];
      for (const requirement of root.requirements) {
        const record = evidence.find(e => e.requirementId === requirement.id && e.version === requirement.version) || root.requirementEvidence.filter(e => e.requirementId === requirement.id && e.version === requirement.version && e.epoch === root.executionEpoch && ['user', 'independent-review'].includes(e.source)).at(-1);
        requireValue(record?.status === 'verified' && typeof record.reference === 'string' && record.reference.trim(), `原需求 ${requirement.id} 尚缺独立核验依据，请补充核验后重新验收`);
        accepted.push({ requirementId: requirement.id, version: requirement.version, status: 'verified', reference: record.reference, source: 'independent-review', nodeId: node.id });
      }
      run.finalEvidence = accepted;
      run.history.push({ type: 'result-approved', generation: run.generation });
    }
  }
  if (node.stage === 'report') run.status = 'done';
  return next;
}

function createDependencyGraph(original, input, makeTask) {
  const definition = clone(input), rootId = original.id;
  const sinks = definition.nodes.filter(node => !definition.edges.some(edge => edge.source === node.id && edge.condition === 'passed'));
  requireValue(sinks.length > 0, '流程需要交付终点');
  let final = sinks[0];
  if (sinks.length > 1) {
    let id = 'delivery'; while (definition.nodes.some(n => n.id === id)) id += '-join';
    final = { ...clone(sinks[0]), id, label: '汇合交付与验收', role: 'review', readOnly: true, reviewerId: sinks[0].modelConfig?.id || sinks[0].memberId, ...(sinks[0].modelConfig ? { reviewerConfig: clone(sinks[0].modelConfig) } : {}), instructions: '汇合所有分支的成果，逐项独立核验原需求，提供真实依据。', position: { x: Math.max(...sinks.map(n => n.position.x)) + 350, y: sinks[0].position.y } };
    definition.nodes.push(final);
    for (const sink of sinks) definition.edges.push({ id: `${sink.id}-${id}`, source: sink.id, target: id, condition: 'passed', maxTraversals: 1 });
  }
  const taskIds = Object.fromEntries(definition.nodes.map(n => [n.id, n.id === final.id ? rootId : `${rootId}::${n.id}`]));
  const run = { id: rootId, definition, original: clone(original), taskIds, skipped: {}, generation: 1, history: [], status: 'active' };
  const tasks = definition.nodes.map(node => {
    const dependencies = definition.edges.filter(e => e.condition === 'passed' && e.target === node.id).map(e => taskIds[e.source]);
    if (node.id === definition.entry) dependencies.push(...original.dependencies);
    const writeScopes = node.readOnly || original.readOnly ? [] : node.writeScopes?.length ? node.writeScopes : original.writeScopes;
    requireValue(writeScopes.every(path => original.writeScopes.some(scope => within(path, scope))), '节点写入范围不能超出原任务');
    return makeTask({ ...node, stage: node.id === final.id ? 'report' : 'work' }, { id: taskIds[node.id], title: `${original.title} · ${node.label}`, instructions: `${original.instructions}\n${node.instructions}`, acceptance: node.id === final.id ? original.acceptance : [`完成 ${node.label} 并交付可核验结果`], memberId: node.memberId || original.memberId, locked: original.locked, dependencies, writeScopes, readOnly: Boolean(node.readOnly || original.readOnly), difficulty: original.difficulty, difficultyReason: original.difficultyReason });
  });
  return { run, tasks };
}

export function rejectDependencyGraph(state, taskId, feedback) {
  const next = clone(state), task = next.tasks.find(t => t.id === taskId), run = next.orchestrations[task.orchestration.id];
  const edges = run.definition.edges.filter(e => e.source === task.orchestration.nodeId && e.condition === 'rejected');
  if (!edges.length) return null;
  run.edgeCounts ||= {};
  if (edges.some(e => (run.edgeCounts[e.id] || 0) >= e.maxTraversals)) { task.status = 'needs_attention'; task.phase = 'blocked'; task.waitingReason = 'WORKFLOW_LOOP_LIMIT'; return next; }
  const affected = new Set(edges.map(e => run.taskIds[e.target]));
  for (let i = 0; i < next.tasks.length; i++) for (const item of next.tasks) if (item.dependencies.some(dep => affected.has(dep))) affected.add(item.id);
  requireValue(!next.tasks.some(item => affected.has(item.id) && item.status === 'running'), '返工分支仍在运行，请先停止并结算');
  for (const item of next.tasks.filter(item => affected.has(item.id))) {
    item.executionHistory.push({ epoch: item.executionEpoch, status: 'orchestration-rework', reason: feedback, at: new Date().toISOString() });
    item.status = 'pending'; item.phase = 'ready'; item.result = null; item.feedback = feedback; item.waitingReason = ''; item.executionApproval = null;
    if (item.executionEpoch) item.executionEpoch++;
    if (item.workflow) item.workflow.reworks = 0;
  }
  for (const edge of edges) run.edgeCounts[edge.id] = (run.edgeCounts[edge.id] || 0) + 1;
  run.generation++; run.status = 'active'; run.history.push({ type: 'result-rejected', departments: edges.map(e => e.target), feedback, generation: run.generation });
  return next;
}
