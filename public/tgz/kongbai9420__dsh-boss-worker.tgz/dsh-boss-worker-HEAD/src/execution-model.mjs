// Saved execution routes are independent of the editable legacy model catalog.
export function modelIdentity(provider, model) { return `model:${encodeURIComponent(provider)}:${encodeURIComponent(model)}`; }
export function normalizeModel(value) {
  if (!value || typeof value.provider !== 'string' || !value.provider.trim() || typeof value.model !== 'string' || !value.model.trim()) throw new Error('请选择有效的 Provider 和模型');
  return { id: value.id || modelIdentity(value.provider, value.model), name: value.name || `${value.provider} / ${value.model}`, provider: value.provider, model: value.model,
    role: value.role || 'implementation', instructions: value.instructions || '', enabled: true, readOnly: Boolean(value.readOnly) };
}
export function snapshotModels(definition, members) {
  return { ...definition, nodes: definition.nodes.map(node => {
    const modelConfig = node.modelConfig || (node.mode === 'worker' && (!node.modelSelection || node.modelSelection === 'fixed') && members.find(m => m.id === node.memberId && m.enabled));
    const reviewerConfig = node.reviewerConfig || members.find(m => m.id === node.reviewerId && m.enabled);
    return { ...node, ...(modelConfig ? { memberId: modelConfig.id, modelConfig: normalizeModel(modelConfig) } : {}), ...(reviewerConfig ? { reviewerId: reviewerConfig.id, reviewerConfig: normalizeModel(reviewerConfig) } : {}) };
  }) };
}
export function taskModel(task, members, reviewer = false) {
  const node = task?.workflow?.definition.nodes.find(n => n.id === task.workflow.current);
  return reviewer ? node?.reviewerConfig || members.find(m => m.id === node?.reviewerId) : node?.modelConfig || task?.memberSnapshot || members.find(m => m.id === task?.memberId);
}
