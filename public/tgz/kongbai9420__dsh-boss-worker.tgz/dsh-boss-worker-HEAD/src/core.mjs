// Pure, dependency-free task orchestration. No agents, clocks, filesystem or I/O.
import { checkPlanningQuality } from './quality-gates.mjs';
import { createWorkflowRun, currentNode, transitionWorkflow, reworkLimit, normalizeWorkflow } from './workflow.mjs';
import { createOrchestration, reviewOrchestration, validateControlOutput, rejectDependencyGraph } from './orchestration.mjs';
import { snapshotModels, taskModel, normalizeModel } from './execution-model.mjs';
import { normalizeModelRouting, prepareModelRoute } from './model-routing.mjs';
const ACTORS = new Set(['user', 'model']);
const TASK_STATUSES = new Set(['pending', 'running', 'review', 'done', 'failed', 'cancelled', 'needs_attention']);
const BOARD_STATUSES = new Set(['draft', 'ready', 'paused', 'cancelled', 'draining', 'drained']);
const OWN = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

export class BoardError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'BoardError';
    this.code = code;
  }
}
const fail = (code, message) => { throw new BoardError(code, message); };
const assert = (condition, code, message) => { if (!condition) fail(code, message); };
function object(value, label) {
  assert(value !== null && typeof value === 'object' && !Array.isArray(value) &&
    (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null),
  'INVALID_INPUT', `${label} must be a plain object`);
}
function keys(value, allowed, label) {
  object(value, label);
  for (const key of Reflect.ownKeys(value)) {
    assert(typeof key === 'string' && allowed.includes(key), 'INVALID_INPUT', `${label}: unknown field ${String(key)}`);
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    assert(descriptor && 'value' in descriptor && descriptor.enumerable, 'INVALID_INPUT', `${label}: only enumerable data fields are supported`);
  }
}
function text(value, label, empty = false) {
  assert(typeof value === 'string' && (empty || value.trim().length > 0), 'INVALID_INPUT', `${label} must be ${empty ? 'a' : 'a nonempty'} string`);
  return value;
}
function bool(value, label) {
  assert(typeof value === 'boolean', 'INVALID_INPUT', `${label} must be boolean`);
  return value;
}
function integer(value, label, minimum = 0, maximum = Number.MAX_SAFE_INTEGER) {
  assert(Number.isSafeInteger(value) && value >= minimum && value <= maximum, 'INVALID_INPUT', `${label} must be a safe integer between ${minimum} and ${maximum}`);
  return value;
}
function strings(value, label) {
  assert(Array.isArray(value), 'INVALID_INPUT', `${label} must be an array`);
  const result = Array.from(value, (v) => text(v, label));
  assert(new Set(result).size === result.length, 'INVALID_INPUT', `${label} must not contain duplicates`);
  return result;
}
function json(value, label = 'value', seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  assert(typeof value === 'object' && value !== null, 'INVALID_INPUT', `${label} must contain only JSON values`);
  assert(!seen.has(value), 'INVALID_INPUT', `${label} must not be cyclic`);
  seen.add(value);
  let result;
  if (Array.isArray(value)) {
    assert(Object.keys(value).length === value.length, 'INVALID_INPUT', `${label} must be a dense JSON array`);
    result = Array.from(value, (v) => json(v, label, seen));
  } else {
    object(value, label);
    result = {};
    for (const key of Reflect.ownKeys(value)) {
      const d = Object.getOwnPropertyDescriptor(value, key);
      assert(typeof key === 'string' && d.enumerable && 'value' in d, 'INVALID_INPUT', `${label} must contain only JSON data fields`);
      Object.defineProperty(result, key, { value: json(d.value, label, seen), enumerable: true, writable: true, configurable: true });
    }
  }
  seen.delete(value);
  return result;
}
function actor(value) {
  assert(ACTORS.has(value), 'INVALID_INPUT', 'actor must be user or model');
}
function normalizeConfig(input) {
  keys(input, ['enabled', 'mode', 'leadPrompt', 'members', 'maxParallel', 'maxRetries', 'confirmPlan', 'askApprovalPrompt', 'bossDirect', 'autopilot', 'modelRouting'], 'config');
  const enabled = bool(input.enabled, 'config.enabled');
  if (OWN(input, 'maxParallel')) integer(input.maxParallel, 'legacy maxParallel', 1, 1000);
  assert(['auto', 'manual', 'mixed'].includes(input.mode), 'INVALID_INPUT', 'invalid team mode');
  const leadPrompt = OWN(input, 'leadPrompt') ? text(input.leadPrompt, 'config.leadPrompt', true) : '';
  assert(input.members === undefined || Array.isArray(input.members), 'INVALID_INPUT', 'members must be an array');
  const members = Array.from(input.members || [], (m) => {
    keys(m, ['id', 'name', 'provider', 'model', 'role', 'instructions', 'enabled', 'readOnly'], 'member');
    return {
      id: text(m.id, 'member.id'), name: text(m.name, 'member.name'),
      provider: text(m.provider, 'member.provider'), model: text(m.model, 'member.model'),
      role: text(m.role, 'member.role'), instructions: text(m.instructions, 'member.instructions', true),
      enabled: bool(m.enabled, 'member.enabled'), readOnly: bool(m.readOnly, 'member.readOnly'),
    };
  });
  assert(new Set(members.map((m) => m.id)).size === members.length, 'INVALID_INPUT', 'member IDs must be unique');
  const askApprovalPrompt = OWN(input, 'askApprovalPrompt') ? bool(input.askApprovalPrompt, 'askApprovalPrompt') : true;
  const bossDirect = OWN(input, 'bossDirect') ? bool(input.bossDirect, 'bossDirect') : false;
  // Read old maxParallel fields for migration; node execution has no user capacity limit.
  return { enabled, mode: input.mode, leadPrompt, members,
    maxRetries: integer(input.maxRetries, 'maxRetries', 0, 1000), confirmPlan: bool(input.confirmPlan, 'confirmPlan'), askApprovalPrompt, bossDirect, autopilot: OWN(input, 'autopilot') ? bool(input.autopilot, 'autopilot') : false, modelRouting: normalizeModelRouting(OWN(input, 'modelRouting') ? json(input.modelRouting) : undefined, members) };
}
const TASK_FIELDS = ['id', 'title', 'instructions', 'acceptance', 'modelConfig', 'memberId', 'locked', 'dependencies', 'writeScopes', 'readOnly', 'status', 'retries', 'taskType', 'deliverables', 'phase', 'evidence', 'difficulty', 'difficultyReason'];
const STORED_FIELDS = [...TASK_FIELDS, 'memberSnapshot', 'result', 'feedback', 'reviewHistory', 'waitingReason', 'executionEpoch', 'checkpoint', 'executionHistory', 'executionApproval', 'extraRetryCredit', 'workflow', 'requirements', 'requirementEvidence', 'difficultySource', 'difficultyLocked', 'routing', 'routingHistory', 'orchestration'];
const VALID_TASK_TYPES = Object.freeze(['code', 'test', 'analysis', 'review', 'doc', 'general']);
const VALID_PHASES = Object.freeze(['planned', 'ready', 'running', 'verifying', 'completed', 'failed', 'blocked']);
const STATUS_TO_PHASE_MAP = Object.freeze({
  pending: 'ready',
  running: 'running',
  review: 'verifying',
  done: 'completed',
  failed: 'failed',
  needs_attention: 'blocked',
  cancelled: 'failed',
});
function normalizeTask(input, restored = false) {
  keys(input, restored ? STORED_FIELDS : TASK_FIELDS, 'task');
  const status = OWN(input, 'status') ? input.status : 'pending';
  const retries = OWN(input, 'retries') ? integer(input.retries, 'task.retries') : 0;
  assert(TASK_STATUSES.has(status), 'INVALID_INPUT', 'invalid task status');
  if (!restored) assert(status === 'pending' && retries === 0, 'INVALID_INPUT', 'new tasks must be pending with zero retries');
  const acceptance = Array.isArray(input.acceptance)
    ? strings(input.acceptance, 'task.acceptance') : text(input.acceptance, 'task.acceptance');
  assert(!Array.isArray(acceptance) || acceptance.length > 0, 'INVALID_INPUT', 'acceptance criteria must not be empty');
  const modelConfig = input.modelConfig ? normalizeModel(input.modelConfig) : null;
  const memberId = modelConfig?.id || (!OWN(input, 'memberId') || input.memberId === null ? null : text(input.memberId, 'task.memberId'));
  const readOnly = OWN(input, 'readOnly') ? bool(input.readOnly, 'task.readOnly') : false;
  const writeScopes = OWN(input, 'writeScopes') ? strings(input.writeScopes, 'task.writeScopes') : [];

  let taskType;
  if (OWN(input, 'taskType')) {
    taskType = text(input.taskType, 'task.taskType');
    assert(VALID_TASK_TYPES.includes(taskType), 'INVALID_TYPE', 'invalid taskType');
  } else {
    taskType = readOnly ? 'analysis' : (writeScopes.length > 0 ? 'code' : 'general');
  }

  let deliverables = [];
  if (OWN(input, 'deliverables')) {
    assert(Array.isArray(input.deliverables), 'INVALID_INPUT', 'task.deliverables must be an array');
    deliverables = json(input.deliverables, 'task.deliverables');
  }

  let phase;
  if (OWN(input, 'phase')) {
    phase = text(input.phase, 'task.phase');
    assert(VALID_PHASES.includes(phase), 'INVALID_INPUT', 'invalid task.phase');
  } else {
    phase = STATUS_TO_PHASE_MAP[status] || 'planned';
  }

  let evidence = null;
  if (OWN(input, 'evidence') && input.evidence !== null) {
    evidence = json(input.evidence, 'task.evidence');
  }

  const task = {
    id: text(input.id, 'task.id'), title: text(input.title, 'task.title'),
    instructions: text(input.instructions, 'task.instructions'), acceptance, memberId,
    locked: OWN(input, 'locked') ? bool(input.locked, 'task.locked') : false,
    dependencies: OWN(input, 'dependencies') ? strings(input.dependencies, 'task.dependencies') : [],
    writeScopes,
    readOnly,
    status, retries,
    taskType, deliverables, phase, evidence,
    result: restored && OWN(input, 'result') ? json(input.result, 'task.result') : null,
    feedback: restored && OWN(input, 'feedback') ? text(input.feedback, 'task.feedback', true) : '',
    reviewHistory: restored && OWN(input, 'reviewHistory') ? json(input.reviewHistory, 'task.reviewHistory') : [],
    waitingReason: restored && OWN(input, 'waitingReason') ? text(input.waitingReason, 'task.waitingReason', true) : '',
    executionEpoch: restored && OWN(input, 'executionEpoch') ? integer(input.executionEpoch, 'executionEpoch') : 0,
    checkpoint: restored && OWN(input, 'checkpoint') ? json(input.checkpoint) : null,
    executionHistory: restored && OWN(input, 'executionHistory') ? json(input.executionHistory) : [],
    executionApproval: restored && typeof input.executionApproval === 'string' ? input.executionApproval : null,
    extraRetryCredit: restored && OWN(input, 'extraRetryCredit') ? integer(input.extraRetryCredit, 'extraRetryCredit', 0, 1) : 0,
    workflow: restored && input.workflow ? json(input.workflow) : null,
    requirements: restored && input.requirements ? json(input.requirements) : [],
    requirementEvidence: restored && input.requirementEvidence ? json(input.requirementEvidence) : [],
    difficulty: input.difficulty ?? null,
    difficultyReason: OWN(input, 'difficultyReason') ? text(input.difficultyReason, 'task.difficultyReason', true) : '',
    difficultySource: restored ? input.difficultySource || null : null,
    difficultyLocked: restored ? Boolean(input.difficultyLocked) : false,
    routing: restored && input.routing ? json(input.routing) : null,
    routingHistory: restored && input.routingHistory ? json(input.routingHistory) : [],
    orchestration: restored && input.orchestration ? json(input.orchestration) : null,
    memberSnapshot: modelConfig || (restored && input.memberSnapshot ? json(input.memberSnapshot) : null),
  };
  assert(task.difficulty === null || ['simple', 'complex'].includes(task.difficulty), 'INVALID_INPUT', '难度必须为 simple 或 complex');
  assert(!task.locked || task.memberId !== null, 'INVALID_INPUT', 'a locked task must have a member');
  assert(!task.readOnly || task.writeScopes.length === 0, 'INVALID_INPUT', 'read-only tasks cannot declare write scopes');
  return task;
}

/**
 * All successful mutations return a detached snapshot and advance revision once.
 * expectedRevision is optional; supply it for CAS. Actor is a trusted caller claim,
 * not authentication. Failed operations never mutate state.
 * snapshot() is JSON-serializable; restore with new TeamBoard(config, snapshot).
 */
export class TeamBoard {
  #config;
  #state;
  #onChange;
  constructor(config, state, onChange) {
    this.#config = normalizeConfig(config);
    this.#onChange = typeof onChange === 'function' ? onChange : null;
    this.#state = { version: 1, revision: 0, status: 'draft', approved: false, tasks: [], archivedTasks: [], batchId: 1, planning: null, workflowDraft: null, workflowVersions: [], workflowDefault: null, orchestrations: {} };
    if (state !== undefined) this.#restore(state);
  }
  reconfigure(config) {
    const next = normalizeConfig(config);
    // Preserve task history and live state. Active assignments must remain valid.
    for (const task of this.#state.tasks.filter(t => !['done', 'cancelled', 'failed'].includes(t.status))) {
      for (const node of task.workflow?.definition.nodes || []) for (const id of [node.memberId, node.reviewerId].filter(Boolean)) {
        if (!node.modelConfig && id === node.memberId || !node.reviewerConfig && id === node.reviewerId) assert(this.#config.members.some(member => member.id === id && member.enabled) || next.members.some(member => member.id === id && member.enabled), 'INVALID_MEMBER', `流程节点 ${node.label} 缺少模型配置 ${id}`);
      }
      if (task.memberId === null) continue;
      if (taskModel(task, this.#config.members)?.provider) continue;
      const member = next.members.find(m => m.id === task.memberId && m.enabled);
      const alreadyUnavailable = !this.#config.members.some(m => m.id === task.memberId && m.enabled);
      if (!member && alreadyUnavailable) continue;
      assert(member, 'INVALID_MEMBER', `任务 ${task.id} 的成员仍在使用中，不能删除或禁用`);
      assert(!member.readOnly || currentNode(task)?.readOnly || task.writeScopes.length === 0, 'READ_ONLY', `任务 ${task.id} 需要写入权限`);
    }
    const modeChanged = this.#config.autopilot !== next.autopilot;
    for (const task of [...this.#state.tasks, ...this.#state.archivedTasks]) {
      if (task.workflow) task.workflow.definition = snapshotModels(task.workflow.definition, this.#config.members);
      task.memberSnapshot ||= taskModel(task, this.#config.members) || null;
    }
    this.#config = next;
    if (modeChanged && this.#state.tasks.length) {
      this.#invalidateApproval();
      return this.#commit();
    }
    return this.snapshot();
  }
  get config() { return json(this.#config); }
  snapshot() {
    const snap = json(this.#state);
    if (!snap.archivedTasks) snap.archivedTasks = [];
    if (!snap.batchId) snap.batchId = 1;
    if (!snap.planning) snap.planning = null;
    return snap;
  }
  #member(id) {
    const member = this.#config.members.find((m) => m.id === id);
    assert(member, 'INVALID_MEMBER', `unknown member: ${id}`);
    assert(member.enabled, 'INVALID_MEMBER', `member is disabled: ${id}`);
    return member;
  }
  #task(id) {
    text(id, 'taskId');
    const task = this.#state.tasks.find((t) => t.id === id);
    assert(task, 'UNKNOWN_TASK', `unknown task: ${id}`);
    return task;
  }
  #assignment(task, memberId) {
    const member = task.memberId === memberId && taskModel(task, []) || this.#member(memberId);
    assert(!member.readOnly || currentNode(task)?.readOnly || task.writeScopes.length === 0, 'READ_ONLY', 'a read-only member cannot receive write scopes');
    return member;
  }
  #readOnly(task) { return currentNode(task)?.readOnly || task.readOnly || taskModel(task, this.#config.members)?.readOnly; }
  #writeConflict(a, b) {
    if (this.#readOnly(a) || this.#readOnly(b)) return false;
    const scopesA = a.writeScopes.length ? a.writeScopes : ['**'];
    const scopesB = b.writeScopes.length ? b.writeScopes : ['**'];
    const overlaps = (left, right) => {
      if (left === '**' || left === '.' || right === '**' || right === '.') return true;
      const norm = s => s.replace(/\\/g, '/').replace(/\/$/, '');
      const x = norm(left), y = norm(right);
      return x === y || x.startsWith(`${y}/`) || y.startsWith(`${x}/`);
    };
    return scopesA.some(x => scopesB.some(y => overlaps(x, y)));
  }
  #validateTasks(tasks, restoring = false) {
    const ids = new Map(tasks.map((t) => [t.id, t]));
    assert(ids.size === tasks.length, 'INVALID_INPUT', 'task IDs must be unique');
    for (const task of tasks) {
      const resolved = taskModel(task, this.#config.members);
      const unavailable = restoring && task.memberId !== null && !resolved?.enabled;
      if (unavailable) {
        // Historical identity is evidence, not a license to invent a new model.
        // Keep accepted history intact; quarantine unfinished work for explicit repair.
        if (!['done', 'cancelled', 'failed'].includes(task.status)) {
          if (task.status === 'running') task.executionEpoch++;
          if (task.status !== 'pending') {
            task.status = 'needs_attention';
            task.phase = STATUS_TO_PHASE_MAP.needs_attention;
          }
          if (task.waitingReason !== 'RETRY_LIMIT_REACHED') task.waitingReason = 'MEMBER_UNAVAILABLE';
        }
      }
      if (task.memberId !== null && !unavailable) assert(resolved?.enabled, 'INVALID_MEMBER', `unknown model: ${task.memberId}`);
      if (task.memberId !== null && !unavailable && !task.readOnly && !currentNode(task)?.readOnly && !resolved.readOnly) {
        assert(task.writeScopes.length > 0, 'MISSING_WRITE_SCOPE', `可写任务 ${task.id} 必须声明精确的 writeScopes`);
      }
      // retries records historical attempts; lowering maxRetries must not invalidate saved tasks.
      // Future retry permission remains enforced by review/retry transitions.
      if (task.memberId !== null && !unavailable) this.#assignment(task, task.memberId);
      for (const dep of task.dependencies) assert(ids.has(dep), 'INVALID_DEPENDENCY', `missing dependency: ${dep}`);
    }
    // Iterative topological traversal avoids a recursion limit on long DAGs.
    const indegrees = new Map(tasks.map((t) => [t.id, t.dependencies.length]));
    const children = new Map(tasks.map((t) => [t.id, []]));
    for (const task of tasks) for (const dep of task.dependencies) children.get(dep).push(task.id);
    const queue = tasks.filter((t) => indegrees.get(t.id) === 0).map((t) => t.id);
    for (let i = 0; i < queue.length; i++) for (const child of children.get(queue[i])) {
      indegrees.set(child, indegrees.get(child) - 1);
      if (indegrees.get(child) === 0) queue.push(child);
    }
    assert(queue.length === tasks.length, 'DEPENDENCY_CYCLE', 'task dependencies contain a cycle');
  }
  #check(revision, allowCancelled = false) {
    if (revision !== undefined) {
      integer(revision, 'expectedRevision');
      assert(revision === this.#state.revision, 'REVISION_CONFLICT', 'state revision changed');
    }
    assert(this.#state.revision < Number.MAX_SAFE_INTEGER, 'REVISION_EXHAUSTED', 'revision counter exhausted');
    assert(allowCancelled || this.#state.status !== 'cancelled', 'CANCELLED', 'board is cancelled');
  }
  #commit() {
    this.#state.revision++;
    const snapshot = this.snapshot();
    this.#onChange?.(snapshot);
    return snapshot;
  }
  #invalidateApproval() { this.#state.approved = this.#config.autopilot || !this.#config.confirmPlan; }
  #restore(input) {
    keys(input, ['version', 'revision', 'status', 'approved', 'tasks', 'recovery', 'archivedTasks', 'batchId', 'planning', 'workflowDraft', 'workflowVersions', 'workflowDefault', 'orchestrations'], 'state');
    assert(input.version === 1, 'INVALID_INPUT', 'unsupported state version');
    const state = { version: 1, revision: integer(input.revision, 'state.revision'), status: input.status,
      approved: bool(input.approved, 'state.approved'), tasks: [], archivedTasks: [], batchId: typeof input.batchId === 'number' ? input.batchId : 1,
      planning: OWN(input, 'planning') && input.planning !== null ? json(input.planning) : null,
      workflowDraft: input.workflowDraft ? normalizeWorkflow(input.workflowDraft) : null, workflowVersions: input.workflowVersions ? json(input.workflowVersions) : [], workflowDefault: input.workflowDefault ? normalizeWorkflow(input.workflowDefault) : null, orchestrations: input.orchestrations ? json(input.orchestrations) : {} };
    assert(BOARD_STATUSES.has(state.status), 'INVALID_INPUT', 'invalid board status');
    assert(Array.isArray(input.tasks), 'INVALID_INPUT', 'state.tasks must be an array');
    if (OWN(input, 'recovery')) state.recovery = json(input.recovery);
    if (OWN(input, 'archivedTasks')) {
      assert(Array.isArray(input.archivedTasks), 'INVALID_INPUT', 'state.archivedTasks must be an array');
      state.archivedTasks = Array.from(input.archivedTasks, (t) => normalizeTask(t, true));
    }
    state.tasks = Array.from(input.tasks, (t) => normalizeTask(t, true));
    this.#validateTasks(state.tasks, true);
    for (const task of [...state.tasks, ...state.archivedTasks]) {
      if (task.workflow) task.workflow.definition = snapshotModels(task.workflow.definition, this.#config.members);
      task.memberSnapshot ||= taskModel(task, this.#config.members) || null;
    }
    if (state.tasks.some(t => t.memberId !== null && !taskModel(t, this.#config.members)?.enabled && !['done', 'cancelled', 'failed'].includes(t.status))) {
      state.approved = false;
      state.status = 'paused';
    }
    assert(state.status !== 'draft' || (state.tasks.length === 0 && !state.approved), 'INVALID_INPUT', 'draft state must be empty and unapproved');
    assert(state.status === 'draft' || state.status === 'cancelled' || state.tasks.length > 0, 'INVALID_INPUT', 'active board must contain tasks');
    const running = state.tasks.filter((t) => t.status === 'running');
    for (let i = 0; i < running.length; i++) for (let j = i + 1; j < running.length; j++) {
      assert(!this.#writeConflict(running[i], running[j]), 'INVALID_INPUT', 'restored running tasks have overlapping write scopes');
    }
    for (const task of state.tasks) {
      if (['running', 'review', 'done', 'failed', 'needs_attention'].includes(task.status)) {
        assert(task.memberId !== null, 'INVALID_INPUT', 'started tasks require an assigned member');
        assert(task.dependencies.every((id) => state.tasks.find((t) => t.id === id).status === 'done'), 'INVALID_INPUT', 'started task dependencies must be accepted');
      }
      if (task.status === 'failed') assert(task.retries >= this.#config.maxRetries, 'INVALID_INPUT', 'failed task must exhaust retries');
      if (task.waitingReason === 'RETRY_LIMIT_REACHED') assert(task.status === 'needs_attention' && (task.workflow ? task.workflow.reworks >= reworkLimit(task, this.#config) : task.retries >= this.#config.maxRetries), 'INVALID_INPUT', 'retry-limit tasks require user attention');
      if (state.status === 'cancelled') assert(['done', 'failed', 'cancelled'].includes(task.status), 'INVALID_INPUT', 'cancelled board contains active tasks');
    }
    // Persisted executions are not resumed here. Even an unapproved legacy
    // snapshot must be quarantined instead of making the whole board unreadable.
    if (running.length) {
      assert(state.revision < Number.MAX_SAFE_INTEGER, 'REVISION_EXHAUSTED', 'cannot record recovery revision');
      const interruptedAt = new Date().toISOString();
      for (const task of running) {
        task.status = 'needs_attention'; task.waitingReason = 'INTERRUPTED_RESTART';
        task.phase = STATUS_TO_PHASE_MAP.needs_attention;
        task.executionEpoch++;
        task.executionHistory.push({ epoch: task.executionEpoch - 1, status: 'interrupted', at: interruptedAt, reason: 'RESTART' });
      }
      state.status = 'paused';
      state.recovery = {
        interruptedAt,
        reason: 'RESTART',
        drained: false,
        settled: false,
        processStopped: false,
        safeToShutdown: false,
        needsCheck: true,
        activeExecutions: 0,
        interruptedTaskIds: running.map((t) => t.id)
      };
      state.revision++; // Recovery is a real state transition; stale workers fail CAS.
    }
    this.#state = state;
  }
  plan(planInput, by = 'model', expectedRevision) {
    this.#check(expectedRevision, true);
    actor(by);
    assert(this.#state.status !== 'paused' && this.#state.status !== 'draining', 'PAUSED', 'resume before planning');

    let tasks;
    let planningMeta = null;
    let isStructuredPlan = false;
    if (Array.isArray(planInput)) {
      tasks = planInput;
    } else if (planInput && typeof planInput === 'object') {
      object(planInput, 'plan');
      assert(Array.isArray(planInput.tasks), 'INVALID_INPUT', 'plan.tasks must be an array');
      tasks = planInput.tasks;
      isStructuredPlan = true;
      planningMeta = {
        planningRationale: planInput.planningRationale ?? planInput.rationale ?? null,
        parallelizationJustification: planInput.parallelizationJustification ?? planInput.parallelRationale ?? null,
        dependencyJustification: planInput.dependencyJustification ?? planInput.dependencyRationale ?? null,
        idleMembersJustification: planInput.idleMembersJustification ?? planInput.idleMemberRationale ?? null,
      };
    } else {
      fail('INVALID_INPUT', 'plan must be an array or plan object');
    }

    assert(Array.isArray(tasks) && tasks.length > 0, 'INVALID_INPUT', 'plan must contain tasks');

    // 规划质量门禁核查 (针对结构化规划对象)
    if (isStructuredPlan) {
      const qualityResult = checkPlanningQuality(
        { tasks, ...planningMeta },
        { members: this.#config.members, maxParallel: this.#config.maxParallel }
      );
      if (!qualityResult.passed) {
        const err = new BoardError(
          qualityResult.code || 'PLANNING_QUALITY_ERROR',
          qualityResult.message || '规划质量门禁未通过'
        );
        if (qualityResult.remedy) err.remedy = qualityResult.remedy;
        if (qualityResult.findings) err.findings = qualityResult.findings;
        throw err;
      }
    }

    const prepared = this.#preparePlanTasks(tasks, by);
    const normalized = prepared.tasks;
    if (this.#config.bossDirect && by === 'model' && this.#config.mode !== 'manual') {
      const nonLeadMembers = this.#config.members.filter(m => !m.id.toLowerCase().includes('lead') && !m.role.toLowerCase().includes('主控') && !m.role.toLowerCase().includes('planner'));
      const pool = nonLeadMembers.length > 0 ? nonLeadMembers : this.#config.members;
      for (const task of normalized) {
        if (!task.memberId && !task.routing?.pendingClassification) {
          const candidate = pool.find(m => m.enabled && (!m.readOnly || task.readOnly || (task.writeScopes && task.writeScopes.length === 0)));
          if (candidate) task.memberId = candidate.id;
        }
      }
    }
    this.#validateTasks(normalized);

    const existingTasks = this.#state.tasks;
    // 判断是否为旧终止批次（任务板处于 cancelled，或者所有历史任务均已进入 done/cancelled/failed 终态）
    const isSettledBatch = this.#state.status === 'cancelled' ||
      (existingTasks.length > 0 && existingTasks.every((t) => ['done', 'failed', 'cancelled'].includes(t.status)));

    if (!isSettledBatch && existingTasks.length > 0) {
      // 活跃任务保护：仍有 running / review / needs_attention 的原任务禁止覆盖，保留历史！
      const activeTasks = existingTasks.filter(t => ['running', 'review', 'needs_attention'].includes(t.status));
      if (activeTasks.length > 0) {
        for (const act of activeTasks) {
          const rep = normalized.find(t => t.id === act.id);
          if (rep) {
            const scopeChanged = JSON.stringify(rep.writeScopes.slice().sort()) !== JSON.stringify(act.writeScopes.slice().sort());
            const depChanged = JSON.stringify(rep.dependencies.slice().sort()) !== JSON.stringify(act.dependencies.slice().sort());
            const instChanged = rep.instructions !== act.instructions;
            const memberChanged = rep.memberId !== act.memberId;
            if (scopeChanged || depChanged || instChanged || memberChanged) {
              fail('CANNOT_OVERWRITE_ACTIVE_TASK', `原任务 ${act.id} 仍处于 ${act.status} 状态，禁止覆盖，必须保留历史`);
            }
          } else {
            fail('CANNOT_OVERWRITE_ACTIVE_TASK', `活跃任务 ${act.id} (${act.status}) 不能被新规划丢弃`);
          }
        }
      } else {
        // 没有活跃任务，但已有任务执行过（有非 pending 任务，如全部 done）
        const hasStarted = existingTasks.some(t => t.status !== 'pending');
        if (hasStarted) {
          for (const old of existingTasks.filter(t => t.status === 'done')) {
            const rep = normalized.find(t => t.id === old.id);
            if (rep && rep.status !== 'done') {
              fail('INVALID_STATE', `已完成任务 ${old.id} 不能被重置为未完成`);
            }
          }
        }
      }
    }

    // 锁定规则与权限校验：全量校验通过前，绝不修改 this.#state 任何字段
    if (by === 'model') {
      if (!isSettledBatch) {
        for (const old of this.#state.tasks.filter((t) => t.locked)) {
          const replacement = normalized.find((t) => t.id === old.id);
          assert(replacement && replacement.locked && replacement.memberId === old.memberId, 'LOCKED', 'model cannot remove or reassign a user-locked task');
        }
        for (const task of normalized) {
          const old = this.#state.tasks.find((t) => t.id === task.id);
          assert(!task.locked || (old?.locked && old.memberId === task.memberId), 'FORBIDDEN', 'only user may lock an assignment');
          assert(this.#config.mode !== 'manual' || task.memberId === null || old?.memberId === task.memberId,
            'MANUAL_ASSIGNMENT', 'manual mode requires user assignment');
          assert(this.#config.mode !== 'manual' || !old?.memberId || task.memberId === old.memberId,
            'MANUAL_ASSIGNMENT', 'model cannot alter manual assignments');
        }
        if (this.#config.mode === 'manual') for (const old of this.#state.tasks.filter((t) => t.memberId !== null)) {
          assert(normalized.some((t) => t.id === old.id), 'MANUAL_ASSIGNMENT', 'model cannot remove a manually assigned task');
        }
      } else {
        // 在 settledBatch（旧终止批次或已取消）规划新批次时：模型不得自行声明 locked 锁定，手动模式须由用户分配
        for (const task of normalized) {
          assert(!task.locked, 'FORBIDDEN', 'only user may lock an assignment');
          assert(this.#config.mode !== 'manual' || task.memberId === null,
            'MANUAL_ASSIGNMENT', 'manual mode requires user assignment');
        }
      }
    }

    // 所有校验、规则与权限全部通过后，原子提交更新并撤销批准
    if (isSettledBatch) {
      const nextArchived = Array.isArray(this.#state.archivedTasks) ? [...this.#state.archivedTasks] : [];
      if (this.#state.tasks.length > 0) {
        nextArchived.push(...this.#state.tasks);
      }
      this.#state.archivedTasks = nextArchived;
      this.#state.recovery = null;
      this.#state.batchId = (this.#state.batchId || 1) + 1;
    }

    // 保留已存在任务的历史记录与状态（例如活跃任务或已完成任务）
    const mergedTasks = [];
    for (const next of normalized) {
      const old = !isSettledBatch ? this.#state.tasks.find(t => t.id === next.id) : null;
      if (old && ['pending', 'running', 'review', 'needs_attention', 'done', 'failed', 'cancelled'].includes(old.status)) {
        mergedTasks.push({
          ...next,
          status: old.status,
          retries: old.retries,
          phase: old.phase,
          result: old.result,
          feedback: old.feedback,
          reviewHistory: old.reviewHistory,
          waitingReason: old.waitingReason,
          executionEpoch: old.executionEpoch,
          checkpoint: old.checkpoint,
          executionHistory: old.executionHistory,
          executionApproval: old.executionApproval,
          extraRetryCredit: old.extraRetryCredit,
          workflow: old.workflow,
          requirements: old.workflow && JSON.stringify(old.acceptance) !== JSON.stringify(next.acceptance)
            ? (Array.isArray(next.acceptance) ? next.acceptance : [next.acceptance]).map((criterion, i) => ({ id: old.requirements[i]?.id || `${old.id}-R${i + 1}`, version: old.requirements[i]?.criterion === criterion ? old.requirements[i].version : (old.requirements[i]?.version || 0) + 1, criterion }))
            : old.requirements,
          requirementEvidence: old.requirementEvidence,
          difficulty: old.difficulty, difficultyReason: old.difficultyReason, difficultySource: old.difficultySource, difficultyLocked: old.difficultyLocked, routing: old.routing, routingHistory: old.routingHistory,
          orchestration: old.orchestration,
          evidence: old.evidence ?? next.evidence
        });
      } else {
        mergedTasks.push(next);
      }
    }

    this.#state.tasks = mergedTasks;
    this.#state.orchestrations = { ...(isSettledBatch ? {} : this.#state.orchestrations), ...prepared.runs };
    if (isStructuredPlan) {
      this.#state.planning = planningMeta ? { ...planningMeta, updatedAt: new Date().toISOString() } : null;
    } else if (this.#state.planning === undefined) {
      this.#state.planning = null;
    }
    // 注意：旧数组规划调用时保留既有 this.#state.planning，不清除已有 planning 元数据
    this.#state.status = 'ready';
    this.#invalidateApproval();
    return this.#commit();
  }
  appendTasks(appendInput, by = 'model', expectedRevision) {
    this.#check(expectedRevision);
    actor(by);
    let tasks;
    let appendPlanningMeta = null;
    let isStructuredAppend = false;
    if (Array.isArray(appendInput)) {
      tasks = appendInput;
    } else if (appendInput && typeof appendInput === 'object') {
      object(appendInput, 'appendInput');
      assert(Array.isArray(appendInput.tasks), 'INVALID_INPUT', 'appendInput.tasks must be an array');
      tasks = appendInput.tasks;
      isStructuredAppend = true;
      appendPlanningMeta = {
        planningRationale: appendInput.planningRationale ?? appendInput.rationale ?? null,
        parallelizationJustification: appendInput.parallelizationJustification ?? appendInput.parallelRationale ?? null,
        dependencyJustification: appendInput.dependencyJustification ?? appendInput.dependencyRationale ?? null,
        idleMembersJustification: appendInput.idleMembersJustification ?? appendInput.idleMemberRationale ?? null,
      };
    } else {
      fail('INVALID_INPUT', 'appendTasks must receive an array or append object');
    }
    assert(Array.isArray(tasks) && tasks.length > 0, 'INVALID_INPUT', 'appendTasks must contain tasks');

    const prepared = this.#preparePlanTasks(tasks, by);
    const normalized = prepared.tasks;
    const existingIds = new Set(this.#state.tasks.map((t) => t.id));
    for (const t of normalized) {
      assert(!existingIds.has(t.id), 'DUPLICATE_TASK_ID', `cannot append existing task ID: ${t.id}`);
    }

    // 活跃任务保护：仍有 running / review / needs_attention 的原任务禁止被追加或篡改
    const activeTasks = this.#state.tasks.filter(t => ['running', 'review', 'needs_attention'].includes(t.status));
    const activeIds = new Set(activeTasks.map(t => t.id));
    for (const t of normalized) {
      assert(!activeIds.has(t.id), 'CANNOT_OVERWRITE_ACTIVE_TASK', `活跃任务 ${t.id} 禁止通过 append 覆盖`);
    }

    // 依赖合法性核查：追加任务依赖的 ID 必须存在于已有任务或本次追加任务中
    const allTaskIds = new Set([...existingIds, ...normalized.map(t => t.id)]);
    for (const t of normalized) {
      for (const depId of t.dependencies) {
        assert(allTaskIds.has(depId), 'INVALID_DEPENDENCY', `追加任务 ${t.id} 依赖不存在的任务 ${depId}`);
      }
    }

    const combined = [...this.#state.tasks, ...normalized];
    this.#validateTasks(combined);

    // 规划质量门禁核查 (针对包含追加的整体规划结构)
    if (isStructuredAppend) {
      const mergedMeta = {
        planningRationale: appendPlanningMeta.planningRationale ?? this.#state.planning?.planningRationale ?? null,
        parallelizationJustification: appendPlanningMeta.parallelizationJustification ?? this.#state.planning?.parallelizationJustification ?? null,
        dependencyJustification: appendPlanningMeta.dependencyJustification ?? this.#state.planning?.dependencyJustification ?? null,
        idleMembersJustification: appendPlanningMeta.idleMembersJustification ?? this.#state.planning?.idleMembersJustification ?? null,
      };
      const qualityResult = checkPlanningQuality(
        { tasks: combined, ...mergedMeta },
        { members: this.#config.members, maxParallel: this.#config.maxParallel }
      );
      if (!qualityResult.passed) {
        const err = new BoardError(
          qualityResult.code || 'PLANNING_QUALITY_ERROR',
          qualityResult.message || '追加任务规划质量门禁未通过'
        );
        if (qualityResult.remedy) err.remedy = qualityResult.remedy;
        if (qualityResult.findings) err.findings = qualityResult.findings;
        throw err;
      }
      this.#state.planning = { ...mergedMeta, updatedAt: new Date().toISOString() };
    }

    this.#state.tasks = combined;
    this.#state.orchestrations = { ...this.#state.orchestrations, ...prepared.runs };
    this.#invalidateApproval();
    return this.#commit();
  }
  getDrainStatus() {
    const running = this.#state.tasks.filter((t) => t.status === 'running');
    const isDrained = running.length === 0 && this.#state.status === 'drained';
    const isHostSettled = Boolean(this.#state.recovery?.settled);
    const processStopped = Boolean(this.#state.recovery?.processStopped);
    const safeToShutdown = isDrained && isHostSettled && processStopped;
    return {
      status: this.#state.status,
      activeExecutions: running.length,
      activeTaskIds: running.map((t) => t.id),
      isDrained,
      safeToShutdown,
      processStopped,
      interruptedAt: this.#state.recovery?.interruptedAt || null,
      stopReason: this.#state.recovery?.reason || null,
      drainedAt: this.#state.recovery?.drainedAt || null,
    };
  }
  drain(hostSettlement = {}, expectedRevision) {
    if (typeof hostSettlement === 'number') {
      expectedRevision = hostSettlement;
      hostSettlement = {};
    }
    this.#check(expectedRevision);
    const running = this.#state.tasks.filter((t) => t.status === 'running');
    if (running.length > 0) {
      this.#state.status = 'draining';
      const at = new Date().toISOString();
      this.#state.recovery = {
        ...(this.#state.recovery || {}),
        drained: false,
        settled: false,
        processStopped: false,
        safeToShutdown: false,
        activeExecutions: running.length,
        drainingAt: at,
      };
      return this.#commit();
    }
    this.#state.status = 'drained';
    const drainedAt = new Date().toISOString();
    const hasExplicitSettlement = hostSettlement && typeof hostSettlement === 'object' &&
      (OWN(hostSettlement, 'settled') || OWN(hostSettlement, 'processStopped'));
    const hostSettled = hasExplicitSettlement
      ? Boolean(hostSettlement.settled ?? hostSettlement.drained ?? false)
      : false;
    const processStopped = hasExplicitSettlement
      ? Boolean(hostSettlement.processStopped)
      : false;
    const safeToShutdown = hostSettled && processStopped;
    this.#state.recovery = {
      ...(this.#state.recovery || {}),
      drained: true,
      settled: hostSettled,
      processStopped,
      safeToShutdown,
      activeExecutions: 0,
      drainedAt,
    };
    return this.#commit();
  }
  assign(taskId, memberId, by = 'user', expectedRevision) {
    this.#check(expectedRevision);
    actor(by);
    const task = this.#task(taskId);
    assert(task.status === 'pending' || task.status === 'needs_attention', 'INVALID_STATE', 'only unstarted or interrupted tasks can be reassigned');
    assert(by !== 'model' || !task.locked, 'LOCKED', 'model cannot change a locked assignment');
    assert(by !== 'model' || this.#config.mode !== 'manual', 'MANUAL_ASSIGNMENT', 'manual mode requires user assignment');
    assert(by !== 'model' || !task.routing || task.memberId === memberId, 'ROUTING_CONTROLLED', '此任务由模型路由配置分配，修改档位或由用户指定模型');
    this.#assignment(task, memberId);
    task.memberId = memberId;
    task.memberSnapshot = json(this.#member(memberId));
    if (by === 'user') {
      task.locked = true;
      const node = currentNode(task);
      if (node) { node.memberId = memberId; node.modelConfig = json(this.#member(memberId)); node.mode = 'worker'; node.modelSelection = 'fixed'; }
      if (task.routing?.pendingClassification) { task.routing.pendingClassification = false; task.waitingReason = ''; }
      task.routingHistory.push({ type: 'user-assigned', memberId, reason: '用户指定并锁定模型', at: new Date().toISOString() });
    }
    this.#invalidateApproval();
    return this.#commit();
  }
  balanceReadyAssignments() {
    // A model configuration can serve multiple independent execution instances.
    return this.snapshot();
  }
  approve(by = 'user', expectedRevision) {
    this.#check(expectedRevision);
    actor(by);
    assert(by === 'user', 'FORBIDDEN', 'only user can approve a plan');
    assert(this.#state.status === 'ready' || this.#state.status === 'paused', 'INVALID_STATE', 'no plan to approve');
    assert(this.#state.tasks.every((t) => t.memberId !== null || t.status === 'cancelled'), 'UNASSIGNED', 'assign all tasks before approval');
    this.#state.approved = true;
    return this.#commit();
  }
  #approvalScope(task) {
    return JSON.stringify([task.id, task.instructions, task.acceptance, task.dependencies, task.writeScopes, task.readOnly]);
  }
  isTaskExecutionApproved(taskId) {
    const task = this.#task(taskId);
    return task.executionApproval === this.#approvalScope(task);
  }
  start(taskId, expectedRevision, userTaskApproval = false) {
    this.#check(expectedRevision);
    assert(this.#config.enabled, 'DISABLED', 'team is disabled');
    assert(this.#state.status === 'ready', 'INVALID_STATE', 'board must be ready to start');
    const task = this.#task(taskId);
    assert(!task.routing?.pendingClassification, 'DIFFICULTY_REQUIRED', '请先为任务确定难度与理由，或由用户指定模型');
    assert(this.#state.approved || userTaskApproval === true || this.isTaskExecutionApproved(taskId), 'APPROVAL_REQUIRED', 'plan requires user approval');
    assert(task.status === 'pending', 'INVALID_STATE', 'task must be pending');
    assert(task.memberId !== null, 'UNASSIGNED', 'task requires an assigned member');
    this.#assignment(task, task.memberId);
    assert(task.dependencies.every((id) => this.#task(id).status === 'done'), 'DEPENDENCY_NOT_DONE', 'dependencies must pass review before starting');
    const running = this.#state.tasks.filter((t) => t.status === 'running');
    assert(currentNode(task)?.mode !== 'controller' || !running.some(t => currentNode(t)?.mode === 'controller'), 'CONTROLLER_BUSY', '同一主控同时只能直接实施一个任务');
    assert(!running.some(other => this.#writeConflict(task, other)), 'WRITE_SCOPE_CONFLICT', 'write scopes overlap with another running task');
    assert(task.executionEpoch < Number.MAX_SAFE_INTEGER, 'REVISION_EXHAUSTED', 'execution epoch exhausted');
    task.extraRetryCredit = 0;
    task.executionApproval = this.#approvalScope(task);
    task.executionEpoch++;
    task.memberSnapshot = json(taskModel(task, this.#config.members));
    const finalEvidence = task.orchestration && task.orchestration.stage === 'report' && this.#state.orchestrations[task.orchestration.id]?.finalEvidence;
    if (finalEvidence) for (const record of finalEvidence) task.requirementEvidence.push({ ...json(record), epoch: task.executionEpoch, at: new Date().toISOString() });
    if (task.workflow) task.workflow.visits.push({ nodeId: task.workflow.current, epoch: task.executionEpoch, at: new Date().toISOString() });
    task.executionHistory.push({ epoch: task.executionEpoch, status: 'started', memberId: task.memberId, at: new Date().toISOString() });
    task.status = 'running';
    task.phase = STATUS_TO_PHASE_MAP.running;
    task.waitingReason = '';
    return this.#commit();
  }
  recordDispatch(taskId, dispatch, executionEpoch) {
    this.#check();
    const task = this.#task(taskId);
    assert(task.status === 'running' && task.executionEpoch === executionEpoch, 'STALE_EXECUTION', 'dispatch record does not match running execution');
    task.evidence = { dispatchStatus: 'running', dispatch: json(dispatch, 'dispatch') };
    return this.#commit();
  }
  finish(taskId, result, expectedRevision, executionEpoch) {
    this.#check(expectedRevision);
    const task = this.#task(taskId);
    if (executionEpoch !== undefined) assert(task.executionEpoch === executionEpoch, 'STALE_EXECUTION', 'old execution result ignored');
    assert(task.status === 'running', 'INVALID_STATE', 'only running tasks can finish');
    const value = json(result, 'result');
    task.result = value;
    if (value && typeof value === 'object' && OWN(value, 'evidence') && value.evidence !== null) {
      task.evidence = json(value.evidence, 'task.evidence');
    }
    const failed = Boolean(value && typeof value === 'object' && value.error);
    task.status = failed ? 'needs_attention' : 'review';
    task.phase = STATUS_TO_PHASE_MAP[task.status];
    task.waitingReason = failed ? 'EXECUTION_FAILED' : '';
    task.executionHistory.push({ epoch: task.executionEpoch, status: task.status, at: new Date().toISOString(), result: value });
    return this.#commit();
  }
  continueAfterRetryLimit(taskId, by = 'user', expectedRevision) {
    this.#check(expectedRevision);
    actor(by);
    assert(by === 'user', 'FORBIDDEN', 'only user may authorize more retries');
    const task = this.#task(taskId);
    assert(task.status === 'needs_attention' && task.waitingReason === 'RETRY_LIMIT_REACHED', 'INVALID_STATE', 'task is not waiting for retry-limit approval');
    task.status = 'pending';
    task.phase = STATUS_TO_PHASE_MAP.pending;
    task.retries++;
    task.extraRetryCredit = 1;
    task.waitingReason = '';
    task.feedback = `${task.feedback}\n用户已批准额外一轮返工；累计返工次数保留，本次授权仅允许再执行一次。`;
    return this.#commit();
  }
  review(taskId, passed, feedback = '', expectedRevision) {
    this.#check(expectedRevision);
    bool(passed, 'passed');
    text(feedback, 'feedback', true);
    const task = this.#task(taskId);
    assert(task.status === 'review', 'INVALID_STATE', 'only completed executions can be reviewed');
    const originalState = task.orchestration ? json(this.#state) : null;
    if (!passed && task.orchestration && this.#state.orchestrations[task.orchestration.id]?.definition.kind === 'dag') {
      const next = rejectDependencyGraph(this.#state, taskId, feedback);
      if (next) { this.#validateTasks(next.tasks); this.#state = next; return this.#commit(); }
    }
    if (passed && task.orchestration) validateControlOutput(this.#state.orchestrations[task.orchestration.id].definition.nodes.find(n => n.id === task.orchestration.nodeId), task);
    task.feedback = feedback;
    task.reviewHistory.push({
      attempt: task.retries + 1,
      passed,
      feedback,
      result: task.result,
      reviewedAt: new Date().toISOString(),
    });
    task.waitingReason = '';
    if (passed && transitionWorkflow(task, 'passed')) {
      // A succeeding stage keeps the task's full acceptance history.
    } else if (task.waitingReason === 'WORKFLOW_LOOP_LIMIT') {
      task.status = 'needs_attention'; task.phase = STATUS_TO_PHASE_MAP.needs_attention;
    } else if (passed) {
      task.status = 'done';
      task.phase = STATUS_TO_PHASE_MAP.done;
    } else if (!passed && transitionWorkflow(task, 'rejected')) {
      // Explicit rejection edges are distinct from retry-budget exhaustion.
    } else if (task.waitingReason === 'WORKFLOW_LOOP_LIMIT') {
      task.status = 'needs_attention'; task.phase = STATUS_TO_PHASE_MAP.needs_attention;
    } else if ((task.workflow ? task.workflow.reworks : task.retries) < reworkLimit(task, this.#config)) {
      if (task.workflow) task.workflow.reworks++;
      task.retries++;
      task.status = 'pending';
      task.phase = STATUS_TO_PHASE_MAP.pending;
      task.result = null;
    } else {
      task.status = 'needs_attention';
      task.phase = STATUS_TO_PHASE_MAP.needs_attention;
      task.waitingReason = 'RETRY_LIMIT_REACHED';
      transitionWorkflow(task, 'rework_limit');
    }
    if (task.orchestration) {
      try {
        const next = reviewOrchestration(this.#state, taskId);
        this.#validateTasks(next.tasks);
        this.#state = next;
        const run = this.#state.orchestrations[task.orchestration.id];
        if (run.userStarted) for (const child of this.#state.tasks.filter(t => t.orchestration?.id === run.id && t.status === 'pending')) child.executionApproval = this.#approvalScope(child);
      } catch (error) { this.#state = originalState; throw error; }
    }
    return this.#commit();
  }
  saveWorkflowDraft(definition, expectedRevision) {
    this.#check(expectedRevision, true);
    this.#state.workflowDraft = normalizeWorkflow(definition);
    return this.#commit();
  }
  #prepareTask(input, by) {
    const task = normalizeTask(input);
    task.memberSnapshot ||= this.#config.members.find(member => member.id === task.memberId && member.enabled) ? json(this.#member(task.memberId)) : null;
    const settled = this.#state.status === 'cancelled' || this.#state.tasks.length > 0 && this.#state.tasks.every(old => ['done', 'cancelled', 'failed'].includes(old.status));
    const old = !settled && this.#state.tasks.find(old => old.id === task.id);
    if (old) {
      if (by === 'model' && old.difficultyLocked) assert((input.difficulty === undefined || input.difficulty === old.difficulty) && (input.difficultyReason === undefined || input.difficultyReason === old.difficultyReason), 'LOCKED', '模型不能修改用户锁定的难度');
      if (by === 'model' && old.routing) { assert(task.memberId === null || task.memberId === old.memberId, 'ROUTING_CONTROLLED', '已有路由任务不能通过重新规划改换模型'); task.memberId = old.memberId; }
      return task;
    }
    task.difficultySource = task.difficulty ? by : null;
    return this.#applyDefaultWorkflow(task, by);
  }
  #makeOrchestrationTask(node, input, rootId) {
    const task = normalizeTask({ ...input, readOnly: input.readOnly || node.readOnly, writeScopes: input.readOnly || node.readOnly ? [] : input.writeScopes });
    task.orchestration = { id: rootId, nodeId: node.id, stage: node.stage };
    task.difficultySource = input.difficulty ? 'user' : null;
    const usesRouting = !task.locked && node.stage === 'work' && node.modelSelection !== 'fixed' && this.#config.modelRouting.enabled;
    if (usesRouting) {
      const difficulty = task.difficulty, difficultyReason = task.difficultyReason;
      if (node.modelSelection !== 'task') { task.difficulty = node.modelSelection; task.difficultyReason ||= `模板节点指定 ${node.modelSelection} 档模型`; task.difficultySource = 'user'; }
      this.#applyDefaultWorkflow(task, 'user', null);
      task.difficulty = difficulty; task.difficultyReason = difficultyReason;
      for (const step of task.workflow?.definition.nodes || []) { step.reviewerId = node.reviewerId; if (node.reviewerConfig) step.reviewerConfig = json(node.reviewerConfig); step.instructions = node.instructions; step.role = node.role; step.readOnly = node.readOnly; if (node.skills) step.skills = structuredClone(node.skills); }
      if (task.workflow) { const first = currentNode(task); first.maxReworks = node.maxReworks; first.timeoutMs = node.timeoutMs; }
    } else {
      const memberId = input.locked && node.stage === 'work' ? input.memberId : node.memberId || input.memberId;
      const step = { ...node, memberId, modelSelection: 'fixed' };
      this.#applyDefaultWorkflow(task, 'user', { id: `${rootId}-${node.id}`, name: node.label, version: 1, entry: node.id, nodes: [step], edges: [] });
    }
    return task;
  }
  #preparePlanTasks(inputs, by) {
    const runs = {}, tasks = [];
    const settled = this.#state.status === 'cancelled' || this.#state.tasks.length > 0 && this.#state.tasks.every(t => ['done', 'failed', 'cancelled'].includes(t.status));
    for (const input of inputs) {
      const task = this.#prepareTask(input, by);
      if (['orchestration', 'dag'].includes(this.#state.workflowDefault?.kind) && (settled || !this.#state.tasks.some(old => old.id === task.id))) {
        const built = createOrchestration(task, this.#state.workflowDefault, (node, spec) => this.#makeOrchestrationTask(node, spec, task.id));
        runs[task.id] = built.run; tasks.push(...built.tasks);
      } else tasks.push(task);
    }
    return { tasks, runs };
  }
  attachOrchestration(taskId, definition, expectedRevision) {
    this.#check(expectedRevision);
    const original = this.#task(taskId);
    assert(original.status === 'pending' && original.executionEpoch === 0 && !original.orchestration, 'INVALID_STATE', '编排只可应用到未启动且尚未编排的任务');
    const normalized = snapshotModels(normalizeWorkflow(definition), this.#config.members);
    const built = createOrchestration(original, normalized, (node, spec) => this.#makeOrchestrationTask(node, spec, taskId));
    const tasks = [...this.#state.tasks.filter(task => task.id !== taskId), ...built.tasks];
    this.#validateTasks(tasks);
    this.#state.tasks = tasks; this.#state.orchestrations[taskId] = built.run;
    this.#state.workflowDraft = normalized; this.#state.workflowVersions.push(normalized);
    this.#invalidateApproval();
    return this.#commit();
  }
  startOrchestration(taskId, expectedRevision) {
    this.#check(expectedRevision);
    const run = this.#state.orchestrations[taskId];
    assert(run && run.status !== 'done' && this.#state.status === 'ready', 'INVALID_STATE', '请先应用编排，并确保任务板处于可调度状态');
    run.userStarted = true;
    for (const task of this.#state.tasks.filter(t => t.orchestration?.id === taskId && t.status === 'pending')) task.executionApproval = this.#approvalScope(task);
    return this.#commit();
  }
  #applyDefaultWorkflow(task, by = 'user', definition = this.#state.workflowDefault) {
    if (['orchestration', 'dag'].includes(definition?.kind)) return task;
    const policy = this.#config.mode === 'manual' && by === 'model' ? { ...this.#config.modelRouting, classification: 'manual' } : this.#config.modelRouting;
    const routed = prepareModelRoute(task, policy, definition);
    task.routing = routed.routing;
    if (routed.pending) { task.memberId = null; task.waitingReason = 'DIFFICULTY_REQUIRED'; return task; }
    if (!routed.definition) return task;
    task.workflow = createWorkflowRun(snapshotModels(routed.definition, this.#config.members));
    for (const node of task.workflow.definition.nodes) if (node.mode === 'worker') {
      const member = node.modelConfig || this.#member(node.memberId);
      assert(!member.readOnly || node.readOnly || task.readOnly || task.writeScopes.length === 0, 'READ_ONLY', `节点 ${node.label} 的成员仅有只读权限，不能执行此写入任务`);
    }
    task.memberId = currentNode(task).memberId || task.memberId;
    task.requirements = (Array.isArray(task.acceptance) ? task.acceptance : [task.acceptance]).map((criterion, i) => ({ id: `${task.id}-R${i + 1}`, version: 1, criterion }));
    if (task.routing) task.routingHistory.push({ type: 'routed', tier: task.routing.tier, memberId: task.memberId, reason: task.routing.reason, at: new Date().toISOString() });
    return task;
  }
  classifyTask(taskId, difficulty, reason, expectedRevision) {
    this.#check(expectedRevision);
    const old = this.#task(taskId);
    assert(old.status === 'pending' && old.executionEpoch === 0, 'INVALID_STATE', '仅可修改尚未启动任务的难度');
    assert(['simple', 'complex'].includes(difficulty), 'INVALID_INPUT', '请选择简单或复杂任务');
    text(reason, 'difficultyReason');
    const task = json(old);
    task.difficulty = difficulty; task.difficultyReason = reason.trim(); task.difficultySource = 'user'; task.difficultyLocked = true;
    task.waitingReason = '';
    const definition = task.routing?.pendingClassification ? task.routing.pendingDefinition : task.routing?.generatedWorkflow ? null : task.workflow?.definition || null;
    task.workflow = null; task.routing = null;
    this.#applyDefaultWorkflow(task, 'user', definition);
    this.#validateTasks(this.#state.tasks.map(item => item.id === taskId ? task : json(item)));
    this.#state.tasks = this.#state.tasks.map(item => item.id === taskId ? task : item);
    this.#invalidateApproval();
    return this.#commit();
  }
  setDefaultWorkflow(definition, expectedRevision) {
    this.#check(expectedRevision, true);
    const next = definition ? snapshotModels(normalizeWorkflow(definition), this.#config.members) : null;
    for (const node of next?.nodes || []) { if (node.mode === 'worker' && node.modelSelection === 'fixed' && !node.modelConfig) this.#member(node.memberId); else if (node.mode === 'worker' && node.modelSelection !== 'fixed') assert(this.#config.modelRouting.enabled, 'INVALID_ROUTING', '请先启用模型路由'); if (node.reviewerId && !node.reviewerConfig) this.#member(node.reviewerId); }
    this.#state.workflowDefault = next;
    if (next) { this.#state.workflowDraft = next; this.#state.workflowVersions.push(next); }
    return this.#commit();
  }
  attachWorkflow(taskId, definition, requirements = [], expectedRevision) {
    definition = normalizeWorkflow(definition);
    if (['orchestration', 'dag'].includes(definition.kind)) return this.attachOrchestration(taskId, definition, expectedRevision);
    this.#check(expectedRevision);
    const task = this.#task(taskId);
    assert(task.status === 'pending' && task.executionEpoch === 0, 'INVALID_STATE', '流程只能绑定尚未启动的任务；运行中编辑请保存为下一版本');
    const prepared = prepareModelRoute(task, this.#config.modelRouting, definition);
    assert(!prepared.pending, 'DIFFICULTY_REQUIRED', '模板需要先确定任务难度与理由');
    const run = createWorkflowRun(snapshotModels(prepared.definition, this.#config.members));
    for (const node of run.definition.nodes) {
      if (node.mode === 'worker' && !node.modelConfig) this.#member(node.memberId);
      if (node.reviewerId && !node.reviewerConfig) this.#member(node.reviewerId);
    }
    const reqs = requirements.length ? requirements : (Array.isArray(task.acceptance) ? task.acceptance : [task.acceptance]).map((criterion, i) => ({ id: `${task.id}-R${i + 1}`, version: 1, criterion }));
    assert(Array.isArray(reqs) && reqs.every(r => typeof r.id === 'string' && typeof r.criterion === 'string' && Number.isSafeInteger(r.version) && r.version > 0) && new Set(reqs.map(r => r.id)).size === reqs.length, 'INVALID_INPUT', '需求需要唯一 ID、版本与验收标准');
    const storedRequirements = json(reqs);
    const first = run.definition.nodes.find(n => n.id === run.current);
    const retainedRoute = task.routing?.generatedWorkflow && task.workflow?.definition.id === run.definition.id ? task.routing : null;
    task.workflow = run; task.routing = retainedRoute || prepared.routing; task.requirements = storedRequirements; task.requirementEvidence = [];
    if (task.routing) task.routingHistory.push({ type: 'routed', memberId: run.definition.nodes.find(node => node.id === run.current).memberId, tier: task.routing.tier, reason: task.routing.reason, at: new Date().toISOString() });
    if (first.memberId) task.memberId = first.memberId;
    this.#state.workflowVersions.push(run.definition);
    this.#state.workflowDraft = run.definition;
    this.#invalidateApproval();
    return this.#commit();
  }
  workflowFailure(taskId, condition, executionEpoch) {
    this.#check();
    assert(['timeout', 'error'].includes(condition), 'INVALID_INPUT', '无效接管原因');
    const task = this.#task(taskId);
    assert(task.executionEpoch === executionEpoch && task.status === 'needs_attention', 'STALE_EXECUTION', '旧执行不能触发接管');
    if (!transitionWorkflow(task, condition) && task.workflow && !['WORKFLOW_LOOP_LIMIT', 'ROUTING_LOCKED'].includes(task.waitingReason)) task.waitingReason = condition === 'timeout' ? 'WORKFLOW_TIMEOUT' : 'EXECUTION_FAILED';
    return this.#commit();
  }
  updateFutureWorkflow(taskId, definition, expectedRevision) {
    this.#check(expectedRevision);
    const task = this.#task(taskId);
    assert(task.workflow && !['done', 'cancelled', 'failed'].includes(task.status), 'INVALID_STATE', '任务没有可调整的后续流程');
    const prepared = prepareModelRoute(task, this.#config.modelRouting, definition);
    assert(!prepared.pending, 'DIFFICULTY_REQUIRED', '请先确定任务难度');
    const next = createWorkflowRun(snapshotModels(prepared.definition, this.#config.members)).definition;
    const old = task.workflow.definition;
    const protectedIds = new Set([task.workflow.current, ...task.workflow.visits.map(v => v.nodeId)]);
    assert(next.entry === old.entry, 'INVALID_WORKFLOW', '不能修改运行流程的入口');
    for (const id of protectedIds) {
      const comparable = node => node ? JSON.stringify(Object.fromEntries(Object.entries({ ...node, modelSelection: node.modelSelection || 'fixed', position: null }).sort(([a], [b]) => a.localeCompare(b)))) : null;
      assert(comparable(old.nodes.find(n => n.id === id)) === comparable(next.nodes.find(n => n.id === id)), 'INVALID_WORKFLOW', '已执行和当前节点的模型、预算、指令及权限不可修改');
    }
    for (const edge of old.edges.filter(e => protectedIds.has(e.source) && e.source !== task.workflow.current)) {
      assert(next.edges.some(e => JSON.stringify(e) === JSON.stringify(edge)), 'INVALID_WORKFLOW', '不能修改已执行节点的连线');
    }
    for (const node of next.nodes) { if (node.mode === 'worker' && !node.modelConfig) this.#member(node.memberId); if (node.reviewerId && !node.reviewerConfig) this.#member(node.reviewerId); }
    next.version = Math.max(old.version + 1, next.version);
    task.workflow.definitionHistory ||= [];
    task.workflow.definitionHistory.push({ definition: old, epoch: task.executionEpoch, at: new Date().toISOString() });
    task.workflow.definition = next;
    this.#state.workflowVersions.push(next); this.#state.workflowDraft = next;
    return this.#commit();
  }
  recordIndependentReview(taskId, record, executionEpoch) {
    this.#check(); const task = this.#task(taskId);
    assert(task.executionEpoch === executionEpoch && task.status === 'review' && task.workflow, 'STALE_EXECUTION', '验收代次已过期');
    task.workflow.independentReviews.push({ ...json(record), epoch: executionEpoch, nodeId: task.workflow.current, at: new Date().toISOString() });
    return this.#commit();
  }
  recordRequirementEvidence(taskId, record, source = 'user') {
    this.#check(); const task = this.#task(taskId);
    assert(task.requirements.some(r => r.id === record.requirementId && r.version === record.version), 'INVALID_INPUT', '需求 ID 或版本不匹配');
    assert(['verified', 'gap', 'unknown'].includes(record.status) && typeof record.reference === 'string', 'INVALID_INPUT', '验证记录需要状态与来源依据');
    assert(['user', 'independent-review', 'self-reported'].includes(source), 'INVALID_INPUT', '无效证据来源');
    task.requirementEvidence.push({ ...json(record), epoch: task.executionEpoch, nodeId: task.workflow?.current || null, source, at: new Date().toISOString() });
    return this.#commit();
  }
  checkpointTask(taskId, note, executionEpoch) {
    this.#check(); text(note, 'checkpoint.note');
    const task = this.#task(taskId);
    if (executionEpoch !== undefined) assert(task.executionEpoch === executionEpoch, 'STALE_EXECUTION', 'old checkpoint ignored');
    task.checkpoint = { note, updatedAt: new Date().toISOString() };
    return this.#commit();
  }
  interrupt(reason = 'USER_INTERRUPTED', taskId) {
    this.#check();
    const at = new Date().toISOString();
    for (const task of this.#state.tasks.filter(t => t.status === 'running' && (taskId === undefined || t.id === taskId))) {
      task.executionHistory.push({ epoch: task.executionEpoch, status: 'interrupted', at, reason });
      task.executionEpoch++; task.status = 'needs_attention'; task.phase = STATUS_TO_PHASE_MAP.needs_attention; task.waitingReason = reason;
    }
    const runningLeft = this.#state.tasks.filter(t => t.status === 'running').length;
    this.#state.status = 'paused';
    this.#state.recovery = {
      interruptedAt: at,
      reason,
      drained: runningLeft === 0,
      processStopped: false,
      safeToShutdown: false,
      activeExecutions: runningLeft
    };
    return this.#commit();
  }
  recoverTask(taskId, continuationNote, by = 'user') {
    this.#check(); actor(by); assert(by === 'user', 'FORBIDDEN', 'recovery requires user confirmation');
    text(continuationNote, 'continuationNote'); const task = this.#task(taskId);
    assert(task.status === 'needs_attention' && task.waitingReason !== 'RETRY_LIMIT_REACHED', 'INVALID_STATE', 'only interrupted tasks can recover');
    assert(task.waitingReason !== 'DEPENDENCY_CANCELLED', 'DEPENDENCY_CANCELLED', '上游已取消，请重新规划依赖或取消受影响分支');
    task.checkpoint = { note: continuationNote, updatedAt: new Date().toISOString() };
    task.executionHistory.push({ epoch: task.executionEpoch, status: 'recovery-confirmed', at: task.checkpoint.updatedAt, note: continuationNote });
    task.status = 'pending'; task.phase = STATUS_TO_PHASE_MAP.pending; task.waitingReason = '';
    // Recovery is not a failed review: preserve retry budget, previous results and review history.
    return this.#commit();
  }
  pause(expectedRevision) {
    this.#check(expectedRevision);
    assert(this.#state.status === 'ready', 'INVALID_STATE', 'only a ready board can pause');
    this.#state.status = 'paused';
    return this.#commit();
  }
  resume(expectedRevision) {
    this.#check(expectedRevision);
    assert(['paused', 'draining', 'drained'].includes(this.#state.status), 'INVALID_STATE', 'only a paused or drained board can resume');
    this.#state.status = 'ready';
    return this.#commit();
  }
  cancel(expectedRevision) {
    this.#check(expectedRevision);
    this.#state.status = 'cancelled';
    for (const task of this.#state.tasks) if (!['done', 'failed', 'cancelled'].includes(task.status)) {
      task.status = 'cancelled';
      task.phase = STATUS_TO_PHASE_MAP.cancelled;
    }
    return this.#commit();
  }
  cancelTask(taskId, expectedRevision) {
    this.#check(expectedRevision);
    const task = this.#task(taskId);
    assert(!['done', 'failed', 'cancelled'].includes(task.status), 'INVALID_STATE', 'terminal task cannot be cancelled');
    task.status = 'cancelled';
    task.phase = STATUS_TO_PHASE_MAP.cancelled;
    const affected = new Set([task.id]);
    for (let i = 0; i < this.#state.tasks.length; i++) for (const child of this.#state.tasks) if (child.dependencies.some(id => affected.has(id))) affected.add(child.id);
    for (const child of this.#state.tasks.filter(t => t.id !== task.id && affected.has(t.id) && !['done', 'failed', 'cancelled'].includes(t.status))) {
      child.status = 'needs_attention'; child.phase = 'blocked'; child.waitingReason = 'DEPENDENCY_CANCELLED'; child.feedback = `上游任务 ${task.id} 已取消；请重新规划或取消此分支。`;
    }
    if (task.orchestration) this.#state.orchestrations[task.orchestration.id].status = 'needs_attention';
    return this.#commit();
  }
  /** An interrupted execution never restarts implicitly. User explicitly accepts re-run risk. */
  retry(taskId, by = 'user', expectedRevision) {
    this.#check(expectedRevision);
    actor(by);
    assert(by === 'user', 'FORBIDDEN', 'only user may retry an interrupted execution');
    const task = this.#task(taskId);
    assert(task.status !== 'cancelled', 'INVALID_STATE', '已取消任务不能直接重试，请重新规划');
    assert(task.waitingReason !== 'DEPENDENCY_CANCELLED', 'DEPENDENCY_CANCELLED', '上游已取消，请重新规划依赖或取消受影响分支');
    assert(task.status === 'needs_attention' && task.waitingReason !== 'RETRY_LIMIT_REACHED', 'INVALID_STATE', 'retry-limit tasks require explicit user authorization');
    assert(task.retries < this.#config.maxRetries, 'RETRY_LIMIT', 'retry budget exhausted');
    task.retries++;
    task.status = 'pending';
    task.phase = STATUS_TO_PHASE_MAP.pending;
    task.result = null;
    task.waitingReason = '';
    return this.#commit();
  }
}
