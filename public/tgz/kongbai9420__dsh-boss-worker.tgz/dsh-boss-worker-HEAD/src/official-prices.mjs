// Read public vendor tariffs only. No credentials or user request content is sent.
import { PRICE_SOURCES } from './pricing-sources.mjs';
import { fetchWindowsPricePage } from './fetch-price-page.mjs';
export { PRICE_SOURCES } from './pricing-sources.mjs';
const entities = text => text.replace(/&(?:quot|#34);/g, '"').replace(/&(?:apos|#39);/g, "'").replace(/&(?:nbsp|#160);/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
const plain = text => entities(text.replace(/<sup\b[^>]*>[\s\S]*?<\/sup>/gi, '').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
const money = text => { const match = String(text ?? '').match(/(?:\$|USD\s*)([\d,]+(?:\.\d+)?)/); return match ? Number(match[1].replaceAll(',', '')) : null; };
export function tableRows(html) {
  const rows = [], spans = [];
  for (const row of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cells = []; let index = 0;
    const fill = () => { while (spans[index]?.remaining > 0) { cells[index] = spans[index].value; spans[index].remaining--; index++; } };
    for (const cell of row[1].matchAll(/<(td|th)\b([^>]*)>([\s\S]*?)<\/\1>/gi)) {
      fill();
      const width = Number(cell[2].match(/colspan\s*=\s*["']?(\d+)/i)?.[1] || 1), height = Number(cell[2].match(/rowspan\s*=\s*["']?(\d+)/i)?.[1] || 1);
      for (let n = 0; n < width; n++) { const value = plain(cell[3]); cells[index] = value; if (height > 1) spans[index] = { remaining: height - 1, value }; index++; }
    }
    fill(); rows.push(cells);
  }
  return rows;
}
export function parseOfficialPrices(source, body, syncedAt = Date.now()) {
  if (!Object.hasOwn(PRICE_SOURCES, source)) throw new Error('未知官方价格来源');
  const rows = [], add = (model, tariff, rates, note = '') => {
    if (!model || rates.input == null || rates.output == null || Object.values(rates).some(value => value != null && (!Number.isFinite(value) || value < 0))) return;
    rows.push({ model, tariff, ...rates, currency: 'USD', unitTokens: 1e6, source, sourceUrl: PRICE_SOURCES[source].url, syncedAt, note });
  };
  if (source === 'openrouter') {
    const payload = JSON.parse(body);
    for (const model of payload.data || []) {
      const convert = value => value == null ? null : Number(value) * 1e6;
      add(model.id, 'standard', { input: convert(model.pricing?.prompt), output: convert(model.pricing?.completion), cacheRead: convert(model.pricing?.input_cache_read), cacheWrite: convert(model.pricing?.input_cache_write) }, 'OpenRouter 自身公开报价；其他转售路由不自动套用。');
    }
  } else if (source === 'deepseek') {
    const table = tableRows(body.match(/<table\b[\s\S]*?<\/table>/i)?.[0] || '');
    const header = table.find(row => row[0] === 'MODEL');
    const get = (label, period, column) => money(table.find(row => row.some(cell => label.test(cell)) && row.some(cell => cell === period))?.[column]);
    for (let col = 1; col < (header?.length || 0); col++) {
      const model = header[col].match(/deepseek-[a-z\d.-]+/)?.[0];
      for (const period of ['PEAK', 'OFF-PEAK']) add(model, period.toLowerCase(), { input: get(/INPUT TOKENS.*CACHE MISS/i, period, col), output: get(/OUTPUT TOKENS/i, period, col), cacheRead: get(/INPUT TOKENS.*CACHE HIT/i, period, col), cacheWrite: null }, '峰谷档位需按账户适用时段选择；中国节假日等特殊计价以官方为准。');
    }
  } else if (source === 'openai') {
    // Official page embeds named service tiers in its SSR component props.
    // Parse JSON data, never execute vendor scripts or infer tier from table order.
    for (const island of body.matchAll(/<astro-island\b[^>]*TextTokenPricingTables[^>]*>/g)) {
      const props = island[0].match(/\bprops="([^"]+)"/);
      if (!props) continue;
      let tier, data;
      try { data = JSON.parse(entities(props[1])); tier = data.tier?.[1]; } catch { continue; }
      if (typeof tier !== 'string') continue;
      const unpack = value => Array.isArray(value) && typeof value[0] === 'number' ? value[0] === 1 ? value[1].map(unpack) : value[1] : value;
      for (const values of unpack(data.rows) || []) {
        if (!Array.isArray(values)) continue;
        const model = String(values[0]).match(/^(?:gpt-[\w.\-]+|o\d[\w.\-]*|chatgpt-[\w.\-]+|(?:davinci|babbage)-\d+)/)?.[0];
        const number = value => typeof value === 'number' && Number.isFinite(value) ? value : null;
        const hasWrite = values.length >= 5;
        add(model, `${tier}:${/>\s*\d/.test(values[0]) ? 'long' : 'short'}`, { input: number(values[1]), cacheRead: number(values[2]), cacheWrite: hasWrite ? number(values[3]) : null, output: number(values[hasWrite ? 4 : 3]) }, `${tier} 服务档位 · 按官方上下文档位计价。`);
      }
      const start = island.index + island[0].length, end = body.indexOf('</astro-island>', start);
      const table = [...body.slice(start, end < 0 ? undefined : end).matchAll(/<table\b[\s\S]*?<\/table>/gi)].flatMap(match => tableRows(match[0]));
      for (const cells of table) {
        const model = cells[0]?.match(/^(?:gpt-[\w.\-]+|o\d[\w.\-]*|chatgpt-[\w.\-]+|(?:davinci|babbage)-\d+)/)?.[0];
        if (!model || money(cells[1]) == null) continue;
        const width = cells.length >= 9 ? 4 : cells.length >= 5 ? 4 : 3;
        const variants = cells.length >= 9 ? ['short', 'long'] : [/>\s*\d/.test(cells[0]) ? 'long' : 'short'];
        for (const [n, context] of variants.entries()) {
          const base = 1 + n * width;
          add(model, `${tier}:${context}`, { input: money(cells[base]), cacheRead: money(cells[base + 1]), cacheWrite: width === 4 ? money(cells[base + 2]) : null, output: money(cells[base + width - 1]) }, `${tier} 服务档位 · ${context === 'short' ? '短上下文' : '长上下文'}；不会自动匹配别名或订阅额度。`);
        }
      }
    }
  } else if (source === 'google') {
    const quote = cell => {
      const segments = [...String(cell || '').matchAll(/\$([\d,]+(?:\.\d+)?)([^$]*)/g)];
      for (const part of segments) {
        const detail = part[2];
        if (/per hour|storage price/i.test(detail) || /audio/i.test(detail) && !/text/i.test(detail)) continue;
        const effective = detail.match(/\b(starting|through)\s+([A-Z][a-z]+ \d{1,2}, \d{4})/);
        if (effective) {
          const date = Date.parse(`${effective[2]} 00:00:00 UTC`);
          if (effective[1] === 'starting' && syncedAt < date || effective[1] === 'through' && syncedAt >= date + 86400000) continue;
        }
        return Number(part[1].replaceAll(',', ''));
      }
      return null;
    };
    const sections = [...body.matchAll(/<h2\b[^>]*>[\s\S]*?<\/h2>/gi)];
    for (let i = 0; i < sections.length; i++) {
      const section = body.slice(sections[i].index, sections[i + 1]?.index);
      const model = section.match(/<code\b[^>]*>(gemini-[\w.-]+)<\/code>/i)?.[1];
      if (!model) continue;
      const tiers = [...section.matchAll(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi)];
      for (let j = 0; j < tiers.length; j++) {
        const tier = plain(tiers[j][1]).toLowerCase();
        if (!['standard', 'batch', 'flex', 'priority', 'contributor'].includes(tier)) continue;
        const block = section.slice(tiers[j].index, tiers[j + 1]?.index), table = tableRows(block.match(/<table\b[\s\S]*?<\/table>/i)?.[0] || '');
        const cell = label => table.find(row => label.test(row[0]))?.at(-1);
        add(model, `${tier}:text`, { input: quote(cell(/^Input price/i)), output: quote(cell(/^Output price/i)), cacheRead: quote(cell(/^Context caching price/i)), cacheWrite: null }, 'Google 付费文本档位参考价；按同步时生效日期选价。音频、长上下文溢价、缓存存储和工具费用不包含；第三方模型别名需显式映射。');
      }
    }
  } else if (source === 'anthropic') {
    const table = tableRows(body.match(/<table\b[\s\S]*?<\/table>/i)?.[0] || '');
    for (const cells of table) {
      const name = cells[0]?.match(/Claude\s+[a-z]+\s+\d+(?:\.\d+)?/i)?.[0];
      if (!name || cells.length < 6) continue;
      const model = name.toLowerCase().replace(/[\s.]+/g, '-');
      for (const [tariff, write] of [['standard:5m-cache', 3], ['standard:1h-cache', 4]]) add(model, tariff, { input: money(cells[1]), output: money(cells[2]), cacheRead: money(cells[5]), cacheWrite: money(cells[write]) }, '标准文本报价；缓存写入有效期需显式选择，长上下文等特殊条件需另行核对。');
    }
  }
  if (!rows.length) throw new Error('官方页面未返回可识别价格，保留已有价格；请检查来源或手动配置');
  return [...new Map(rows.map(row => [`${row.model}:${row.tariff}`, row])).values()];
}
export async function fetchOfficialPrices(source, fetcher = fetch) {
  const spec = Object.hasOwn(PRICE_SOURCES, source) && PRICE_SOURCES[source];
  if (!spec) throw new Error('请选择受支持的官方来源');
  let body;
  try {
    const response = await fetcher(spec.url, { signal: AbortSignal.timeout(15000), redirect: 'error', headers: { Accept: source === 'openrouter' ? 'application/json' : 'text/html' } });
    if (!response.ok) throw new Error(`官方价格同步失败：HTTP ${response.status}`);
    body = await response.text();
  } catch (error) {
    if (fetcher !== fetch || process.platform !== 'win32') throw error;
    body = await fetchWindowsPricePage(source);
  }
  return parseOfficialPrices(source, body);
}
export async function synchronizePrices(settings, fetcher = fetch) {
  const sources = [...new Set(settings.prices.filter(p => p.mode === 'official').map(p => p.source))], catalog = {}, errors = {};
  await Promise.all(sources.map(async source => { try { catalog[source] = await fetchOfficialPrices(source, fetcher); } catch (error) { errors[source] = error.message; } }));
  const prices = settings.prices.map(price => {
    if (price.mode !== 'official') return price;
    const found = catalog[price.source]?.find(row => row.model === (price.sourceModel || price.model) && row.tariff === price.tariff);
    if (!found) return { ...price, syncError: errors[price.source] || '未找到完全匹配的官方模型和计费档位，未改动已有价格' };
    return { ...price, ...found, model: price.model, provider: price.provider, sourceModel: found.model, mode: 'official', syncError: '' };
  });
  return { settings: { ...settings, prices }, catalog, errors, checkedAt: Date.now() };
}
