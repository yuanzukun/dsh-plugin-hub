export function convertCosts(costs, display = {}) {
  if (!display.moneyUnit || display.moneyUnit === 'native') return { ...costs };
  const converted = {};
  for (const [currency, amount] of Object.entries(costs || {})) {
    const rate = currency === display.moneyUnit ? 1 : display.rates?.[currency];
    const key = rate == null ? currency : display.moneyUnit;
    converted[key] = (converted[key] || 0) + amount * (rate ?? 1);
  }
  return converted;
}
