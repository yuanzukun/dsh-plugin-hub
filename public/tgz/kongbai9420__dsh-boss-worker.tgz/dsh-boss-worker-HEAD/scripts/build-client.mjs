import { build } from 'esbuild';
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
// Normalize checked-out text before embedding it in generated JavaScript.
const readText = path => readFileSync(path, 'utf8').replace(/\r\n?/g, '\n');
const result = await build({ absWorkingDir: root, entryPoints: ['client/workbench.jsx'], bundle: true, write: false, metafile: true, format: 'cjs', platform: 'browser', target: 'es2022', minify: true, external: ['react', 'react-dom', 'react/jsx-runtime'], loader: { '.css': 'text' }, legalComments: 'eof' });
const canvas = result.outputFiles[0].text;
const styles = readText(new URL('../client/workbench.css', import.meta.url)) + '\n' + readText(new URL('../client/native.css', import.meta.url));
const entry = `let WorkflowModule; function workflowModule() { if (!WorkflowModule) { const module = { exports: {} }; (function(require, module, exports) { ${canvas}\n })(require, module, module.exports); WorkflowModule = module.exports; } return WorkflowModule; } function WorkflowWorkbench(props) { return React.createElement(React.Fragment, null, React.createElement('style', null, ${JSON.stringify(styles)}), React.createElement(workflowModule().Workbench, props)); } function WorkflowTemplateSettings(props) { return React.createElement(React.Fragment, null, React.createElement('style', null, ${JSON.stringify(styles)}), React.createElement(workflowModule().TemplateSettings, props)); } function WorkflowModelRoutingSettings(props) { return React.createElement(React.Fragment, null, React.createElement('style', null, ${JSON.stringify(styles)}), React.createElement(workflowModule().ModelRoutingSettings, props)); }`;
const source = readText(new URL('../client/legacy.js', import.meta.url));
if (!source.includes('/* WORKFLOW_ENTRY */')) throw new Error('Missing workflow entry marker');
const billingEntry = `function WorkflowBillingSettings(props) { return React.createElement(React.Fragment, null, React.createElement('style', null, ${JSON.stringify(styles)}), React.createElement(workflowModule().BillingSettingsPage, props)); }`;
writeFileSync(new URL('../client.js', import.meta.url), source.replace('/* WORKFLOW_ENTRY */', () => entry + billingEntry));
const packages = [...new Set(Object.keys(result.metafile.inputs).filter(p => p.startsWith('node_modules/')).map(p => p.split('/').slice(1, p.split('/')[1].startsWith('@') ? 3 : 2).join('/')))].sort();
let notices = '# Third-party notices\n\nclient.js bundles the following packages. React and ReactDOM are supplied by DSH.\n';
for (const name of packages) {
  const directory = join(root, 'node_modules', name);
  const pkg = JSON.parse(readFileSync(join(directory, 'package.json'), 'utf8'));
  const license = readdirSync(directory).find(name => /^licen[sc]e(?:\.(?:md|txt))?$/i.test(name));
  if (!license) throw new Error(`Missing bundled license: ${name}`);
  notices += `\n## ${name} ${pkg.version} (${pkg.license})\n\n${readFileSync(join(directory, license), 'utf8').trim()}\n`;
}
writeFileSync(new URL('../THIRD_PARTY_NOTICES.md', import.meta.url), notices);
console.log('Built client.js with React Flow workbench');
