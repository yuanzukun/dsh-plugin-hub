// Offline browser QA: real UI and host state machine, deterministic model fixture.
import { createServer } from 'node:http';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { build } from 'esbuild';
process.env.DSH_BOSS_WORKER_TEST_RUNTIME = '1';
const { LeadWorkerHostService } = await import('../src/host.mjs');
const profile = mkdtempSync(join(tmpdir(), 'workflow-preview-'));
const messages = [{ id:'intro', role:'assistant',content:[{type:'text',text:'这是离线交互预览，监控数据为模拟调用。可以拖拽节点、编辑接管规则并发送对话；这里不会调用真实模型。'}] }];
const parent = { ctx:{},options:{provider:'offline',model:'controller'},session:{header:{id:'preview'},deriveMessages:()=>messages},followup(message){ messages.push(message); messages.push({id:`reply-${messages.length}`,role:'assistant',content:[{type:'text',text:'已收到，消息已进入同一主控会话。离线预览不会自动调用模型生成草案。'}]}); },cancel(){},whenIdle:async()=>{} };
let api;
const hooks = new Map();
let monitorDemo = false, monitorDemoSeeded = false;
async function previewModelCalls(id, request) {
  const stream = hooks.get('llm/stream');
  if (!stream) return;
  const options = { ...request.agentOptions, sessionId: id, messages: [] };
  for await (const chunk of stream(options, async function* () {
    yield { type: 'text-delta', index: 0, text: '离线已完成的模型输出' };
    yield { type: 'usage', usage: { inputTokens: 12500, outputTokens: 1800, cacheReadTokens: 4000, reasoningTokens: 600 } };
    yield { type: 'finish', reason: { kind: 'stop' } };
  })) {}
  const session = { header: { id } };
  hooks.get('session/event')?.(session, { type: 'tool/call', data: { callId: 'preview-tool' } });
  await new Promise(resolve => setTimeout(resolve, 300));
  hooks.get('session/event')?.(session, { type: 'tool/result', data: { message: { callId: 'preview-tool' } } });
  for await (const chunk of stream(options, async function* () {
    for (let i = 0; i < 200 && !request.signal.aborted; i++) {
      await new Promise(resolve => setTimeout(resolve, 500));
      yield { type: 'text-delta', index: 0, text: '离线示例：检查当前任务实现与测试结果。' };
    }
    yield { type: 'usage', usage: { inputTokens: 14000, outputTokens: 2400 } };
    yield { type: 'finish', reason: { kind: request.signal.aborted ? 'aborted' : 'stop' } };
  })) {}
}
const ctx={on(name, fn){hooks.set(name, fn);},profileContext:{dir:profile},logger:console,agents:{get:id=>id==='preview'?parent:undefined},get(name){return this[name];},
  inject(names,fn){ if(names.length===1 && names[0]==='webServer')fn({webServer:{register:spec=>{api=spec.handler;}}}); },
  subagents:{async start(_kind,request){const childId=`preview-child-${Date.now()}`; return {id:childId,localAgent:{options:request.agentOptions},result:(monitorDemo ? previewModelCalls(childId, request) : Promise.resolve()).then(()=>({stopReason:'completed',output:[{type:'text',text:request.label.includes('独立验收')?JSON.stringify({passed:true,feedback:'离线验收样例',evidence:[{requirementId:'preview-task-R1',version:1,status:'verified',reference:'offline fixture'}]}):'离线执行样例'}]})),dispose:async()=>{}};}}
};
const members=['A','B','C','QA'].map(id=>({id,name:id==='QA'?'独立验收':`模型 ${id}`,provider:'offline',model:id,role:id==='QA'?'review':'implementation',instructions:'offline',enabled:true,readOnly:id==='QA'}));
const host=new LeadWorkerHostService(ctx,{defaultConfig:{enabled:true,mode:'mixed',bossDirect:true,confirmPlan:true,maxParallel:3,maxRetries:2,members}});
await host.handleAction('preview','configureSession',{bossDirect:true});
const board=host.getOrCreateBoard('preview');board.plan([{id:'preview-task',title:'示例：模型接管流程',instructions:'离线交互验证',acceptance:'通过交互验证',memberId:'A',writeScopes:['src/']}]);
board.attachWorkflow('preview-task',{id:'preview-flow',name:'模型接管示例',version:1,entry:'A',nodes:members.slice(0,3).map((m,i)=>({id:m.id,label:`${m.name}${i===0?' · 首轮执行':i===1?' · 返工接管':' · 超时接管'}`,memberId:m.id,reviewerId:'QA',role:'implementation',mode:'worker',maxReworks:i===0?2:1,timeoutMs:i===1?120000:0,position:{x:i*290,y:100}})),edges:[{id:'AB',source:'A',target:'B',condition:'rework_limit'},{id:'BC',source:'B',target:'C',condition:'timeout'}]});
const css=readFileSync(new URL('../client/workbench.css',import.meta.url),'utf8');
const result=await build({stdin:{contents:`import React from 'react';import {createRoot} from 'react-dom/client';import * as ReactDOM from 'react-dom';import * as JSXRuntime from 'react/jsx-runtime';let plugin;window.__ModuleLoader__={load({factory}){plugin=factory(name=>{if(name==='react')return React;if(name==='react-dom')return ReactDOM;if(name==='react/jsx-runtime')return JSXRuntime;if(name==='@deepseek-ai/dsh-client-ui-slots')return {};throw new Error('Unexpected host import: '+name);});}};await import('/plugin.js');let listeners=new Set();async function refresh(){const r=await fetch('/api/lead-worker/view?sessionId=preview');const data=await r.json();const motion=new URLSearchParams(location.search).get('motion');if(['running','paused','review','done'].includes(motion)){const t=data.board.tasks[0];data.board.status=motion==='paused'?'paused':'ready';t.title='离线光效样例：A 返工超限 → B';t.status=motion==='paused'?'running':motion;t.executionEpoch=2;t.workflow.current='B';t.workflow.transitions=[{from:'A',to:'B',condition:'rework_limit',epoch:1,at:new Date().toISOString()}];t.workflow.visits=[{nodeId:'A',epoch:1,at:new Date().toISOString()},{nodeId:'B',epoch:2,at:new Date().toISOString()}];t.workflow.definition.nodes[1].position={x:340,y:250};t.workflow.definition.nodes[2].position={x:620,y:100};}for(const fn of listeners)fn({data});}const subscribe=(_s,_i,fn)=>{listeners.add(fn);refresh();const timer=setInterval(refresh,2000);return()=>{listeners.delete(fn);clearInterval(timer);};};createRoot(document.getElementById('root')).render(React.createElement(React.Fragment,null,React.createElement('style',null,${JSON.stringify(css)}),React.createElement(new URLSearchParams(location.search).has('tasks')?plugin.previewDialog:new URLSearchParams(location.search).has('settings')?plugin.previewDialog:new URLSearchParams(location.search).has('templates')?plugin.previewTemplates:plugin.previewWorkbench,{sessionId:'preview',nativeView:new URLSearchParams(location.search).has('native'),isOpen:true,embedded:true,initialTab:new URLSearchParams(location.search).has('tasks')?'board':'lead',themeMode:'light',subscribe,refresh,onClose:()=>{},openChild:async()=>{}})));`,resolveDir:new URL('../',import.meta.url).pathname.replace(/^\/([A-Z]:)/,'$1'),loader:'jsx'},bundle:true,external:['/plugin.js'],format:'esm',write:false,loader:{'.css':'text'},define:{'process.env.NODE_ENV':'"development"'}});
let routingDemoSeeded=false;
const server=createServer(async(req,res)=>{
  const location = new URL(req.url,'http://127.0.0.1');
  if(location.searchParams.get('demo')==='routing'&&!routingDemoSeeded){
    routingDemoSeeded=true;
    await host.handleAction('preview','configureModelRouting',{modelRouting:{enabled:true,classification:'auto',simple:{memberId:'A',maxReworks:1,timeoutMs:60000},complex:{memberId:'B',maxReworks:2,timeoutMs:120000},autoEscalate:true,fallbacks:[{memberId:'C',maxReworks:1,timeoutMs:180000}]}});
    board.setDefaultWorkflow(null);
    board.plan([{id:'route-simple',title:'离线：调整提示文案',instructions:'只调整提示文案',acceptance:'文案符合要求',memberId:'A',writeScopes:['src/simple'],difficulty:'simple',difficultyReason:'范围明确，单文件修改，无跨模块依赖。'},{id:'route-complex',title:'离线：跨模块认证设计',instructions:'设计跨模块认证机制',acceptance:'设计完整',memberId:'B',writeScopes:['src/complex'],difficulty:'complex',difficultyReason:'需要跨模块设计，涉及状态、接口与复杂上下文。'},{id:'route-unclassified',title:'离线：等待用户分级',instructions:'等待用户确认范围',acceptance:'确认后执行',writeScopes:['src/pending']}],'model');
  }
  if(location.searchParams.get('demo')==='monitor' && !monitorDemoSeeded){
    monitorDemoSeeded=true; monitorDemo=true;
    await host.handleAction('preview','configureMonitoring',{expectedRevision:0,budget:0.1,settings:{currency:'CNY',prices:members.map(member=>({provider:member.provider,model:member.model,input:2,output:8,cacheRead:0.2,cacheWrite:2}))}});
    board.approve();
    host.dispatchTask('preview','preview-task',{agent:parent,signal:new AbortController().signal}).catch(console.error);
  }
  if(location.pathname==='/responsive'){
    const width=Math.max(320,Math.min(1600,Number(location.searchParams.get('width'))||626));
    const height=Math.max(420,Math.min(1000,Number(location.searchParams.get('height'))||720));
    const appearance=location.searchParams.get('appearance')==='dark'?'dark':'light';
    const textScale=location.searchParams.get('text')==='200'?'200':'100';
    res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
    return res.end(`<!doctype html><html><head><title>工作台布局验收 ${width} × ${height}</title><style>body{margin:0;padding:20px;background:#e8e8ed;color:#555;font:13px system-ui;min-width:${width+40}px}p{margin:0 0 12px}iframe{display:block;width:${width}px;height:${height}px;border:0;box-shadow:0 8px 30px #0001}</style></head><body><p>离线界面验收 · ${width} × ${height} · ${appearance} · 文字 ${textScale}%</p><iframe title="工作台测试视口" src="/?appearance=${appearance}&text=${textScale}"></iframe><pre id="measurements" aria-label="布局验收测量" style="white-space:pre-wrap;font-size:12px"></pre><script>setInterval(()=>{const f=document.querySelector('iframe'),w=f.contentWindow,d=f.contentDocument;if(!d||!d.querySelector('.wf-workbench'))return;const r=q=>{const e=d.querySelector(q);return e?{...e.getBoundingClientRect().toJSON(),visibility:w.getComputedStyle(e).visibility}:null;};document.getElementById('measurements').textContent=JSON.stringify({viewport:{width:w.innerWidth,height:w.innerHeight},bodyWidth:d.body.scrollWidth,root:r('.wf-workbench'),stage:r('.wf-stage'),composer:r('.wf-composer'),theme:d.querySelector('.wf-workbench').className,nodeFont:d.querySelector('.wf-node strong')?w.getComputedStyle(d.querySelector('.wf-node strong')).fontSize:null,zoom:d.querySelector('.react-flow__viewport')?.getAttribute('style')},null,2);},300);</script></body></html>`);
  }
  if(req.url.startsWith('/api/')) return api(req,res);
  if(req.url==='/plugin.js'){res.writeHead(200,{'Content-Type':'application/javascript'});return res.end(readFileSync(new URL('../client.js',import.meta.url),'utf8').replace('exports.apply = apply;', 'exports.previewWorkbench = WorkflowWorkbench; exports.previewTemplates = WorkflowTemplateSettings; exports.previewDialog = LeadWorkerDialog; exports.apply = apply;'));}
  if(req.url==='/app.js'){res.writeHead(200,{'Content-Type':'application/javascript'});return res.end(result.outputFiles[0].text);}
  res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});const requestedAppearance=location.searchParams.get('appearance');
  const panelWidth=Math.max(320,Math.min(1600,Number(location.searchParams.get('panel'))||1600));
  const panelStyle=location.searchParams.has('panel')?`<style>#root{width:${panelWidth}px;max-width:100%}</style>`:'';
  const testStyle=location.searchParams.get('text')==='200'?'<style>html{font-size:200%}</style>':'';
  const reduced=location.searchParams.get('reduce')==='1';
  const testAppearance=requestedAppearance||reduced?`<script>const nativeMatchMedia=window.matchMedia.bind(window);window.matchMedia=function(query){if(query==='(prefers-reduced-motion: reduce)'&&${reduced})return {matches:true,media:query,addEventListener(){},removeEventListener(){}};if(query==='(prefers-color-scheme: dark)'&&${Boolean(requestedAppearance)})return {matches:${requestedAppearance==='dark'},media:query,addEventListener(){},removeEventListener(){}};return nativeMatchMedia(query);};</script>`:'';
  res.end('<!doctype html><html><head>'+panelStyle+testStyle+testAppearance+'<meta name="viewport" content="width=device-width, initial-scale=1"><title>DSH 工作流离线验证</title></head><body style="margin:0"><div id="root"></div><script type="module" src="/app.js"></script></body></html>');
});
server.listen(4318,'127.0.0.1',()=>console.log('Offline UI preview: http://127.0.0.1:4318'));
const stop=()=>server.close(()=>{rmSync(profile,{recursive:true,force:true});process.exit();});process.on('SIGINT',stop);process.on('SIGTERM',stop);
