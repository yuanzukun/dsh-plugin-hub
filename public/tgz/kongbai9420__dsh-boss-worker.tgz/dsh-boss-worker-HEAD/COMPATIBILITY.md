# DSH 兼容性检查

[English](docs/COMPATIBILITY.en.md) · [文档中心](docs/README.md)

## 当前验证 · 2026-10-27

插件版本：**0.2.0-beta.28，Beta 预发布版**。以下为本地验证记录，不代表远端 GitHub Actions 已运行。

| DSH 版本 | 官方宿主 smoke | 官方前端契约 |
| --- | --- | --- |
| `0.1.7-rc.2` | 通过 | 通过 |
| `0.2.0-rc.2` | 通过 | 通过 |
| `0.2.1-rc.2` | 通过 | 通过 |

- 单元与业务回归：**412 通过，0 失败，0 跳过**；独立客户端模拟通过。
- 离线界面交互：模板编辑、节点直接选模型、保存与重新打开已验证。
- 业务覆盖：节点并行、依赖及写冲突、独立验收、原需求证据、可信核验修正、显式封驳、取消、恢复和历史迁移。
- DSH Desktop 的 web Profile 与 DSH NEXT 的 desktop Profile 均已更新 beta.28；安装副本代码一致性检查及隔离宿主 smoke 均通过。

### 方法与边界

宿主检查加载真实官方 Cordis、工具、Web、子模型和消息契约，模型后端使用可控离线夹具；临时 Profile 与真实用户会话隔离。前端契约检查验证官方插槽与生命周期，不能替代桌面交互验收。

`npm test` 与 `npm run test:client` 可用于本地回归。宿主／前端检查需要官方 DSH 依赖和绝对 `bin.js` 锚点，见 [CI 配置](.github/workflows/check.yml)。

监控通过公开 `llm/stream` 与 `session/event` 接口验证流式调用、节点归属、独立验收和未知费用。宿主无法观测的外部调用不能从输出文字补造统计。

真实付费 Provider 的完整任务、限流、账单、余额和订阅额度仍待独立验收。其他预发布宿主版本需要单独检查。

## 历史验证记录

以下保留早期版本的原始记录。旧测试数量、模板结构和当时的 npm 标签均是对应日期的历史状态，当前行为以本页顶部与使用指南为准。

### 工作流开发版复验（2026-10-19）

本地 `0.2.0-beta.5` 尚未发布。2026-10-18 查询官方 npm 标签时为：`latest=0.2.0-rc.2`、`next=0.2.1-rc.2`。UI 改造后重新运行三版本宿主和前端契约检查，均通过；本次未重新查询 npm 标签。

新增宿主 smoke 覆盖第八个工具 `lead_worker_workflow`、草案提交、不同 activation 的独立验收、需求证据、真实消息构造函数和 HTTP 主会话发送；模型执行仍使用离线 provider。新增状态机及真实 React 渲染测试，完整回归目前 334 项通过（Node.js 26.7.0）。

浏览器运行真实 React Flow 界面及本插件 HTTP handler，已手动验证首次加载、节点拖动、撤销、添加节点、拖拽连接条件边、预算保存与同一主控会话的消息回显。该预览使用临时 Profile，不是安装到 DSH 桌面，也未调用真实模型。

模板设置新增 Profile 内持久化、跨会话复用、修订冲突检查和模板应用隔离测试；三省六部为 11 节点串行适配预设。

模型路由新增逐任务分级、模板档位引用、人工覆盖/锁定、插件宿主服务中经济模型到复杂模型的离线派发与验收，以及既有模型链引用和旧节点兼容检查。三版本宿主和前端检查已重新运行并通过。

以下为已发布 `0.1.0-beta.2` 的历史验证记录。


检查日期：2026-10-17（Asia/Shanghai）。插件版本：`0.1.0-beta.2`。

### 目标版本

官方 npm `@deepseek-ai/dsh` 的 `latest` 为 `0.2.0-rc.2`，`next` 为 `0.2.1-rc.2`。后者同日发布为 [dsh-v0.2.1-rc.2](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-rc.2)。同时保留原声明的 `0.1.7-rc.2`。

### 已修复的问题

1. 三个 DSH peerDependencies 原先只接受 `^0.1.7-rc.2`，拒绝 Issue #1 的 `0.2.0-rc.2`。新增两个已验证版本范围，保留宿主的检查机制。
2. 新版取消 `subagents.start`，改为 `startActivation`。适配新的请求/返回结构，使用 `delivery: 'caller'`，由任务板在保存结果后发送唯一的审查通知，保持 `review` 门禁。
3. `startActivation` 的 signal 只拥有启动阶段的取消权。发布后的中断必须转至该 activation 的 `dispose()`；适配器保留同一个释放 Promise，使释放失败仍能被宿主观察到。
4. 新请求不再接受 `persona`。成员指令随任务文本传递，旧 API 仍原样接收 `persona`。不更改用户的成员或模型路由配置。
5. Cordis 服务代理改变方法的 `this`，直接访问本服务的原生私有字段会抛错。将本 Profile 服务的方法绑定到原始实例，真实服务代理调用已验证。
6. 提示词组装通过 `context.agent.session` 提供会话；旧的 `context.session` 假设会使协作规则静默缺失。现在兼容两种上下文。
7. 新任务记录子会话地址模式 `unknown`，让新版工作台按真实子会话解析；历史任务继续按 `one-shot` 打开。新增首页 `conversation.hero.options` 入口，并读取新版 `diagnostic` 错误说明。
8. HTTP 路由使用官方声明的 `kind: 'prefix'`，修正旧代码的 `prefixes` 拼写。

官方契约参考：[子任务 API](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.1-rc.2/packages/subagent/subagent/src/index.ts)、[activation 类型](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.1-rc.2/packages/subagent/subagent/src/types.ts)、[提示词上下文](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.1-rc.2/packages/core/agent/src/dispatch.ts)、[前端插槽](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.1-rc.2/packages/client/ui-conversation/src/client/contract/slots.ts)。

### 验证方法与边界

本地验证结果（Node.js `26.7.0`）：

| DSH | 宿主服务 / HTTP / 中断释放 | 官方前端插槽契约 |
| --- | --- | --- |
| `0.1.7-rc.2` | 通过（`start`） | 通过 |
| `0.2.0-rc.2` | 通过（`start`） | 通过 |
| `0.2.1-rc.2` | 通过（`startActivation`） | 通过（含新版首页入口） |

单元/回归测试：289 项通过；独立客户端模拟通过；npm 打包白名单检查通过。CI 配置使用 Node.js 24；此处的结果来自本地执行，不代表已经运行远程 Actions。

`npm test` 运行隔离单元/回归测试；`npm run test:client` 运行客户端模拟。

`test/host-compat-smoke.mjs` 必须由普通 Node 进程执行，断言未启用测试替身。它加载隔离安装的真实 Cordis、ToolRuntime、SystemPrompt、WebServer、SubagentRuntime 和消息构造函数，验证服务代理、HTTP 访问、七个工具注册、真实工具调用、提示词组装、模型路由请求、角色指令、子任务交付进入待审查、审查通知、运行后中断及资源释放。

宿主 smoke 仅以可控的离线 provider 替代模型执行，使用临时 Profile、临时 loopback 端口和父 Agent fixture。未调用真实模型，未启动或修改桌面 DSH，也未验证所有第三方 provider。前端 smoke 使用官方 SlotCore 和对应 Conversation 发布的插槽声明，验证实际存在的入口可以注册、注入会话身份并卸载；不代替浏览器/桌面视觉测试。

CI 的 `host-compatibility` job 将依赖版本固定为三个目标版本。安装步骤和执行命令见 `.github/workflows/check.yml`。未来其他预发布版本需要单独验证。


#### 节点运行监控（本地 beta.6）

监控使用公开的 `llm/stream` waterfall 与 `session/event` 观察接口，不改写请求、分块或结果。兼容烟测通过真实 Cordis、LlmRuntime 和离线 LlmAdapter，验证子模型在启动句柄返回前发流、节点归属、独立验收计数和未知费用；覆盖既有三个 DSH 版本。跨进程／外部 Provider 若没有向本插件所在宿主暴露调用流，界面会显示尚未收到统计，不根据最终文本捏造 Token。真实模型计费和账户余额尚未验证。
