# Task classification and model routing

[简体中文](MODEL_ROUTING.md) · [Documentation](README.en.md)

From **0.2.0-beta.28**, fixed nodes select a DSH Provider/model directly. Economy, complex and follow-task-complexity options are advanced routing strategies; node options remain disabled with a configuration hint until routing is enabled.

In **Settings → Model routing**, choose each tier's model, allowed rework, timeout and successor model directly. No member creation is needed. The interface uses `modelConfig={provider,model}`; `memberId` is retained only for legacy compatibility.

The controller classifies the original plan as `simple` / `complex` with reasons, or the user classifies it manually. Automatic classification does not override user-locked models. Fixed nodes use their own configuration. Dynamic nodes resolve tiers when applied and save execution snapshots.

Before switching on budget exhaustion or timeout, the previous call must actually exit. New settings affect subsequent tasks; existing chains and history remain. Changing later nodes requires explicit application. Missing valid tier configuration cannot silently select another model.

One model can serve multiple parallel nodes. Member copies and maximum concurrency settings are unnecessary; dependencies and conflicting write scopes still constrain simultaneous execution.
