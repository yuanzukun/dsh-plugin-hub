# Documentation

[简体中文](README.md) · [Project home](../README.en.md)

For the **0.2.0-beta.28 Beta pre-release**. Start with the workflow guide, then read routing, templates and monitoring as needed.

| Order | English | 简体中文 | Contents |
| --- | --- | --- | --- |
| 1 | [Overview](../README.en.md) | [项目介绍](../README.md) | Features, quick start and development |
| 2 | [Workflows](WORKFLOW.en.md) | [节点与流程](WORKFLOW.md) | Nodes, dependencies, rework, acceptance and recovery |
| 3 | [Model routing](MODEL_ROUTING.en.md) | [模型路由](MODEL_ROUTING.md) | Fixed models, tiers and configuration snapshots |
| 4 | [Full-stack team](FULLSTACK_TEMPLATE.en.md) | [全栈开发团队](FULLSTACK_TEMPLATE.md) | Role deliverables, parallel development and targeted rework |
| 5 | [Runtime monitoring](RUNTIME_MONITORING.en.md) | [运行监控](RUNTIME_MONITORING.md) | Metrics, prices, budgets and attribution |
| 6 | [Compatibility](COMPATIBILITY.en.md) | [兼容性](../COMPATIBILITY.md) | Official host matrix, offline verification and boundaries |
| 7 | [Roadmap](ROADMAP.en.md) | [项目规划](../ROADMAP.md) | Completed capabilities and pending acceptance |
| 8 | [Changelog](CHANGELOG.en.md) | [更新记录](../CHANGELOG.md) | Current preview changes; full history retained in Chinese |

## Development references

- [CI configuration](../.github/workflows/check.yml): official dependencies and host/frontend contract checks.
- [License](../LICENSE) and [third-party notices](../THIRD_PARTY_NOTICES.md).
- [Workbench redesign plan](WORKFLOW-REDESIGN-PLAN.md) and [early architecture research](design/model-handoff-workflow-research.md): historical design notes in Chinese. Current guides and source define current behavior.

> [!NOTE]
> Local compatibility checks use real official hosts with offline model fixtures. Paid Providers, rate limits and invoice reconciliation require separate acceptance.
