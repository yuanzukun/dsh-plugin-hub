# Runtime monitoring

[简体中文](RUNTIME_MONITORING.md) · [Documentation](README.en.md)

For the **0.2.0-beta.28 Beta pre-release**. No additional monitoring service is required. Data is not uploaded to Langfuse, Helicone or other external observability platforms.

## Usage

1. Open the workflow workbench. Node cards show settled Tokens, estimated costs, call counts and pending settlement. Session totals are under **Monitoring → Current session**.
2. Open a node's usage details for input, output, cache, model totals and individual calls. Totals include rework and independent review. Other nodes using the same model are counted separately. Governed templates aggregate department tasks; internal handoff chains retain node-level details.
3. Open **Usage and pricing** in BOSS settings or the workflow's usage settings. Prices match the exact Provider + model ID. Add a model price, select its official source/model/tier, then save and sync. Monitoring also links to the session budget and pricing settings.

## Official prices and custom units

- Supported reference sources: [DeepSeek](https://api-docs.deepseek.com/quick_start/pricing/), [OpenAI](https://developers.openai.com/api/docs/pricing), [Anthropic](https://platform.claude.com/docs/en/about-claude/pricing), [Google Gemini](https://ai.google.dev/gemini-api/docs/pricing) and [OpenRouter](https://openrouter.ai/api/v1/models). Public reference pricing requires no account key and does not upload Provider credentials, prompts or session contents.
- Explicitly select peak/off-peak, service, context or cache-duration tiers. Google uses paid text prices effective at sync time. Unknown models, channel aliases and unrecognized tiers are not matched approximately. Resold/subscription models can map explicitly to an official reference model; manually override with actual channel rates.
- Price rows retain source, sync time and applicability. Manual sync is available; automatic mode checks at 24-hour intervals when opening the workbench. Fetch failures retain previous prices and show the cause. Historical calls are not repriced. On Windows, a hidden system HTTPS client may fetch fixed official URLs with certificate checks enabled.
- Rates default to CNY or USD per million Tokens. Manual rates accept any positive integer Token base; changing the base rescales existing numbers to preserve the rate.
- Token display supports a quantity and label, such as `1000` + `K Token`. Keep original currencies or supply a target unit such as CNY, USD or credits with an explicit conversion factor. Exchange rates are not assumed. Unconvertible currencies remain separate.
- Calls retain their starting source, rate, Token base and currency. Global settings do not overwrite session budgets. Each budget's units/conversion snapshot is set when saved.
- Only observed model Token costs are estimated. Cache storage duration, search tools, audio/video charges and subscription quotas are not folded into text Token rates.

Rates are shared within the current Profile; budgets apply to the current session. **Reaching a budget warns without stopping execution or switching models.**

Display conversion does not alter historical original-currency amounts. Budget totals use their saved conversion snapshot for known costs. Unknown or unsettled costs do not establish remaining headroom. Price edits affect calls that start afterward; in-flight calls retain starting rates.

## Metric definitions

| Metric | Definition |
| --- | --- |
| Live generation speed | Approximate average throughput of observed streamed text, marked `≈`; simple character estimates are not tokenizer-accurate |
| Final average speed | Provider output Tokens divided by the first-to-last observed output interval; known hidden reasoning Tokens are excluded when no reasoning stream is exposed |
| First response | Time from entering the monitored stream to the first nonempty text, reasoning or tool-call fragment; includes waiting and may precede visible text |
| Model-call time | Cumulative call start-to-end time, including first-response waiting but excluding tool execution outside the model stream |
| Tool time | DSH tool-call-to-result interval; overlapping tools within one Agent use the time union, while totals across Agents may overlap |
| Settled Tokens | Final Provider `usage`, including uncached input, cache reads/writes and output; use the supplied total or sum known mutually exclusive fields |
| Reasoning Tokens | Optional output subdivision; displayed without being added again to totals or costs; unavailable values show `—` |
| Estimated cost | Starting rates multiplied by Provider usage; not an invoice, subscription quota or account debit |

DSH uncached input and cache input are mutually exclusive. Cost is:

```text
(uncached input × input rate
 + output × output rate
 + cache reads × read rate
 + cache writes × write rate) / call Token base
```

The default base is `1,000,000`.

A nonzero usage category without a rate makes the call unpriced. Calls without `usage` show unknown usage; final Tokens are not inferred from visible output. Live estimates do not enter settled Tokens or costs. Totals identify incomplete settlement when calls are running or unknown.

## Attribution and recovery

- Session totals include observed controller, submodel and independent-review calls since monitoring began. Task batches, nodes, execution epochs and roles remain separate. Rework and handoff do not reset consumption.
- Attribution is fixed at request start. A controller request is not retroactively assigned to a node because it later invokes a tool enabling direct execution; subsequent requests can belong to that node.
- Independent review contributes to the relevant node total and is labeled in call records. Nodes without data show that no statistics have been received.
- Cancelled and failed calls retain observed usage. Real consumption may remain unknown if interruption prevents a final `usage` response.
- Start/end metadata is persisted; streamed fragments are not written individually. Unfinished calls become interrupted after restart, without pretending to remain active or rerunning automatically.
- Monitoring stores route identifiers, times, counters, rates and state. It does not additionally store prompts, output text, reasoning, tool arguments or credentials. Existing DSH session logs are unaffected.

## Support and verification

Monitoring uses public DSH `llm/stream` and `session/event` interfaces. Official hosts `0.1.7-rc.2`, `0.2.0-rc.2` and `0.2.1-rc.2` are verified with offline model fixtures and no API charges.

Calls in other processes or external services that this host cannot observe do not produce invented statistics. Usage completeness depends on Provider adapters. Generic DSH interfaces do not supply account balances or subscription quotas; the interface marks them unavailable. Provider-specific adapters and real-invoice reconciliation remain pending.

Design references: [Langfuse Agent Graphs](https://langfuse.com/docs/observability/features/agent-graphs), [Token & Cost Tracking](https://langfuse.com/docs/observability/features/token-and-cost-tracking), [Helicone Sessions](https://docs.helicone.ai/features/sessions) and [LiteLLM Budgets](https://docs.litellm.ai/docs/proxy/users). This feature is implemented within the project without importing those services or copying their source.

## Offline interaction preview

Run:

```powershell
node scripts/preview-workbench.mjs
```

Open [the local monitoring demo](http://127.0.0.1:4318/?demo=monitor). A temporary Profile simulates completed calls, tools and ongoing generation through the actual monitoring layer. The conversation identifies the offline simulation. It does not read real accounts, call remote models or modify real Profiles.
