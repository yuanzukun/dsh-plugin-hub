# 文档中心

[English](README.en.md) · [项目首页](../README.md)

适用于 **0.2.0-beta.28 Beta 预发布版**。建议先读流程指南，再按需要查看模型路由、模板与运行监控。

| 阅读顺序 | 简体中文 | English | 内容 |
| --- | --- | --- | --- |
| 1 | [项目介绍](../README.md) | [Overview](../README.en.md) | 功能、快速开始与开发 |
| 2 | [节点与流程](WORKFLOW.md) | [Workflows](WORKFLOW.en.md) | 节点、依赖、返工、验收与恢复 |
| 3 | [模型路由](MODEL_ROUTING.md) | [Model routing](MODEL_ROUTING.en.md) | 固定模型、经济／复杂档与配置快照 |
| 4 | [全栈开发团队](FULLSTACK_TEMPLATE.md) | [Full-stack team](FULLSTACK_TEMPLATE.en.md) | 角色交付、前后端并行与定向返工 |
| 5 | [运行监控](RUNTIME_MONITORING.md) | [Runtime monitoring](RUNTIME_MONITORING.en.md) | 指标口径、价格、预算与归属 |
| 6 | [兼容性](../COMPATIBILITY.md) | [Compatibility](COMPATIBILITY.en.md) | 官方宿主矩阵、离线验证与边界 |
| 7 | [项目规划](../ROADMAP.md) | [Roadmap](ROADMAP.en.md) | 已完成能力与待验收项目 |
| 8 | [更新记录](../CHANGELOG.md) | [Changelog](CHANGELOG.en.md) | 当前预览版更新；中文保留完整历史 |

## 开发参考

- [CI 配置](../.github/workflows/check.yml)：官方依赖安装和宿主／前端契约检查。
- [许可证](../LICENSE)与[第三方声明](../THIRD_PARTY_NOTICES.md)。
- [工作台改造计划](WORKFLOW-REDESIGN-PLAN.md)和[早期架构研究](design/model-handoff-workflow-research.md)：中文历史设计记录。具体行为以当前使用指南和源码为准。

> [!NOTE]
> 本地兼容验证使用真实官方宿主和离线模型夹具。真实付费 Provider、限流及账单对照尚待独立验收。
