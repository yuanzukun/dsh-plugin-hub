# Full-stack development team

[简体中文](FULLSTACK_TEMPLATE.md) · [Documentation](README.en.md)

The **0.2.0-beta.28 Beta pre-release** includes a full-stack team template. It defines executable responsibilities and dependencies; it does not scaffold a frontend/backend project or choose a technology stack.

Open **Template library → Full-stack development team → Preview on canvas**, or preview, copy, edit and apply it from template settings. Targets include drafts, unstarted tasks and subsequent new tasks. Preview does not call models. Once applied as an orchestration, execution starts through the start action.

## Roles and deliverables

| Node | Deliverables and dependencies |
| --- | --- |
| Product owner | Requirements, scope, individual acceptance criteria, node assignments, write scopes and dependencies |
| Plan reviewer | Independently check requirement coverage, authorization, file conflicts and delegation |
| Project manager | Confirm schedule, deliverables and shared-file ownership; runtime performs dispatch |
| Architect | Complete API, field, error, authentication and data-model contracts |
| UI/UX designer | Pages, journeys, components, states, close/back behavior, keyboard and narrow-screen behavior |
| Frontend engineer | Wait for API contracts and UX design, implement the frontend and supply actual test results |
| Backend engineer | Wait for API contracts, implement API/data logic and supply actual test results |
| Integration engineer | Wait for both implementations; check real requests/responses, authentication and business paths |
| Test engineer | Wait for integration; verify acceptance, regression and applicable end-to-end tests |
| Delivery lead | Wait for all work nodes; compile complete results and outstanding work |
| Independent acceptance | Judge original requirements and evidence, or identify responsible work nodes |
| Delivery report | Report results, files, entry points, tests and unresolved issues to the original controller session |

Architecture and UX can run in parallel. Once their prerequisites finish, frontend and backend work can run in parallel. Runtime checks dependencies and write conflicts; the same model can use independent instances. Complete upstream results reach downstream tasks rather than being replaced by short summaries.

Work nodes have independent review configured. Design, planning and review stay read-only. Implementation and testing operate within the original task's approved scope.

## Models and customization

Nodes bind directly to models available in the current Profile. Change each model independently or select economy, complex or task-complexity routing after configuring tiers. Applied nodes retain execution and review snapshots. No execution-member pool or maximum concurrency setting is required.

Built-in Skill snapshots cover requirement decomposition, incremental implementation, regression, independent code review and result consolidation. Add, remove or replace them as needed.

The default template uses the complete division of work and requires all six work nodes. Copy and adjust roles/dependencies for frontend-only or backend-only tasks. Plan rejection and result rework default to two rounds each; individual node budgets remain editable.

Final acceptance identifies failed work nodes through `reworkNodeIds`. Frontend rework repeats integration, testing, consolidation and acceptance, preserving independently accepted backend/design results. Backend or contract issues redo actual dependants. Exhausted budgets preserve a needs-attention state. Tier-based nodes may use their configured handoff chains.

Application and execution do not automatically publish or push remotely. Applied tasks retain their workflow copies; template editing does not overwrite execution history.

## Method references

This project authors its own role instructions and execution configuration. These projects informed the approach; their runtimes and source were not imported:

- [fullstack-starter work workflow](https://github.com/first-fluke/fullstack-starter/blob/main/.agents/workflows/work.md): contracts, frontend/backend delegation, QA and targeted rework.
- [BMad roles and workflows](https://github.com/bmad-code-org/BMAD-METHOD/blob/main/docs/reference/skills-and-agents.md): product, UX, architecture and delivery.
- [MetaGPT](https://github.com/FoundationAgents/MetaGPT) and [ChatDev](https://github.com/OpenBMB/ChatDev): collaboration, standardized deliverables and handoffs.

## Canvas controls

The template defaults to horizontal layout. The direction control switches to vertical; layout changes can be saved and undone. Draft/application targets and workflow import/export are at the bottom of the configuration panel.
