# DSH compatibility

[简体中文](../COMPATIBILITY.md) · [Documentation](README.en.md)

## Current verification · 2026-10-27

Plugin: **0.2.0-beta.28, Beta pre-release**. Verification results below were obtained locally and do not claim a remote GitHub Actions run.

| DSH version | Official host smoke | Official frontend contracts |
| --- | --- | --- |
| `0.1.7-rc.2` | Passed | Passed |
| `0.2.0-rc.2` | Passed | Passed |
| `0.2.1-rc.2` | Passed | Passed |

Local unit/business regression results: **412 passed, 0 failed, 0 skipped**. Client simulation passed. Offline browser verification covered template editing, direct node model selection, saving and reopening.

Coverage includes parallel scheduling, dependency/write conflicts, independent acceptance, original-requirement evidence, trusted corrections, explicit rejection routes, cancellation, recovery and legacy migration.

Installed copies in DSH Desktop's web Profile and DSH NEXT's desktop Profile were updated to beta.28. Both passed isolated host smoke checks and source-file consistency checks. This installation record is separate from live-model end-to-end acceptance.

## Methods and boundaries

Host smoke checks load actual official Cordis, tool, web, subagent and message contracts while using controlled offline models. Temporary Profiles isolate fixtures from real user sessions. Frontend checks validate official slots and lifecycle; they do not replace desktop interaction testing.

Use `npm test` and `npm run test:client` locally. Official host/frontend checks need installed DSH dependencies and an absolute `bin.js` anchor; see the [CI configuration](../.github/workflows/check.yml) for commands and pinned versions.

Monitoring checks exercise public `llm/stream` and `session/event` interfaces, including streams before startup handles return, node attribution, review costs and unknown pricing. External calls not visible to this host cannot be reconstructed from output text.

Paid Provider completion, rate limits, actual invoices, account balances and subscription quotas remain unverified. Compatibility with other prerelease versions requires a separate check.

## Historical records

The [Chinese compatibility log](../COMPATIBILITY.md) retains dated beta.5/beta.6 and public `0.1.0-beta.2` records, including API adaptations and earlier test totals. Those totals and old template descriptions are historical, not the current state.
