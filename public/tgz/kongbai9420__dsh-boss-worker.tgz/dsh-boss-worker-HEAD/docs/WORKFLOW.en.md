# Nodes and workflows

[简体中文](WORKFLOW.md) · [Documentation](README.en.md)

For the **0.2.0-beta.28 Beta pre-release**.

## Start a workflow

Open DSH's official workflow tab. Choose a template or create one. Select a Provider/model directly on each node; configure its independent review model in the same panel. No worker pool is required.

| Action | Effect |
| --- | --- |
| Save draft | Save editing changes |
| Apply workflow | Bind it to the current unstarted task |
| Use for new tasks | Affect subsequent tasks in the current session |

Existing execution versions stay separate. Changing later nodes requires the corresponding explicit application action.

New implementation nodes default to a separate review context. You can select another review model. For manual verification, record evidence in requirement reconciliation under records before controller review. Applied model changes support undo. Nodes retain configuration snapshots; changing shared defaults does not silently replace them.

## Parallelism and handoff

New templates default to `kind=dag`. Passing edges are prerequisites: A branches to B and C, and both must finish before D. Nodes may reuse one model through independent execution contexts. Conflicting writes queue.

Enter one relative file or directory per line in a node's write scope. Scopes must stay within the original task's authorization. An empty scope inherits the task scope. Parallel write nodes need non-overlapping declarations. Read-only nodes do not write files.

Passing dependencies must be acyclic. Rejection edges return to a predecessor or the same node, redoing the target and affected descendants while preserving independent accepted results. Multiple terminal nodes without an explicit join gain a visible delivery-and-acceptance join when applied.

Legacy model handoff chains omit `kind`. They switch models sequentially within one task:

| Condition | Behavior |
| --- | --- |
| `passed` | Move to the next node after acceptance; attempt delivery if none exists |
| `rejected` | Follow the explicit rejection route |
| `rework_limit` | Handoff after the node's rework budget is exhausted |
| `timeout` | Handoff only after the previous execution has actually exited |
| `error` | Handoff after the failed execution settles |

Chains allow one successor per condition; explicit loops have visit limits. Parallel graphs use `passed` / `rejected`; errors and timeouts pause the branch for inspection and retry. Adding multiple passing successors makes an ordinary graph subject to parallel-graph validation.

## Governed templates

Three Departments and Six Ministries and the full-stack team use `kind=orchestration`. They include structured planning, plan review, delegation, joining, final acceptance and a delivery report. Node participation and responsibilities follow template settings.

Rejection requires an explicit route. A rejected plan returns to planning. Rejected results target specific work nodes, or use the dispatch node to authorize targeted rework. Without rejection routes, failed review waits for handling with a missing-route state; it does not silently return to an earlier stage.

Final acceptance returns an `evidence` list covering original requirements, each with `requirementId`, `version`, `status` and `reference`. An `approved=true` flag and verbal summary are insufficient. Delivery copies the current epoch's verification evidence to the root task, keeping reconciliation and completion consistent.

## Review and corrections

A confirmed quality failure cannot be bypassed with `passed=true`. Missing evidence preserves results pending additional verification; rerunning implementation does not itself establish complete evidence.

Within the same requirement version and execution epoch, the latest trusted verification applies and all history remains. Manual or independent review may correct gaps; worker self-reports cannot override trusted conclusions. Changed acceptance criteria or a new execution epoch invalidate automatic reuse of old evidence.

Read-only review contexts cannot run a general terminal. Test nodes rerun tests; reviewers inspect records and files. Reading a result is not an independent test rerun.

## Controls and recovery

Pausing scheduling stops future dispatches while started calls settle. Before shutdown, use draining and inspect the result. Cancelling upstream work explicitly blocks affected dependants until replanning or cancellation; dependencies are not treated as completed.

After restart, inspect interrupted work before resuming. Records and execution epochs remain; late results cannot overwrite a newer epoch. Retiring catalog entries preserves tasks with complete model snapshots. Old tasks genuinely missing routes need explicit repair.

## Editing and observation

The canvas supports dragging, zoom, horizontal/vertical layout, undo/redo, template and Skill libraries, and import/export. The native view reuses DSH's official input. Escape, close buttons and blank-canvas clicks dismiss auxiliary panels.

Node totals include rework and independent review. Select available models directly in pricing settings. Budgets warn without stopping execution; unknown usage is not zero. See [runtime monitoring](RUNTIME_MONITORING.en.md).

`writeScopes` provides contracts, scheduling and delivery checks, not filesystem isolation. Execution follows host sandbox and approval rules.

Build frontend sources in `client/`; `client.js` is generated. Run `node scripts/preview-workbench.mjs` for an isolated offline preview. Record live Provider and invoice acceptance separately.
