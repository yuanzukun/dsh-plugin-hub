# Changelog

[简体中文](../CHANGELOG.md) · [Documentation](README.en.md)

## 0.2.0-beta.28 · 2026-10-27

**Beta pre-release.**

- Normalize build input line endings so Windows CRLF and LF checkouts produce identical frontend artifacts.

- Select Provider/models directly on nodes. Save execution and independent-review snapshots; retain legacy member migration and retire unused catalog entries without breaking history.
- Remove execution-member capacity and user maximum concurrency. Schedule independent model instances through dependencies and declared write scopes.
- Add freely constructed parallel graphs, visible delivery joins and explicit rejection routes. Missing rejection edges no longer trigger hidden returns.
- Require evidence for original requirements before final delivery. Apply trusted corrections within the same version and execution epoch while preserving history.
- Explicitly block dependants of cancelled upstream tasks. Add model pricing directly from available models and consolidate configuration entry points.
- Local verification: 412 tests passed; official host and frontend contract checks passed for DSH `0.1.7-rc.2`, `0.2.0-rc.2` and `0.2.1-rc.2`. Live paid Providers and invoice reconciliation still require separate acceptance.

### Documentation refresh

Align Chinese/English READMEs and core guides, add bilingual navigation, workflow diagrams and an offline interface screenshot, and distinguish current verification from historical records.

## Earlier versions

The [Chinese changelog](../CHANGELOG.md) retains the full earlier history. The previous public release is `v0.1.0-beta.2`; intervening local preview entries do not imply published releases.
