# Roadmap

[简体中文](../ROADMAP.md) · [Documentation](README.en.md)

Updated **2026-10-27**. Current Beta pre-release: **0.2.0-beta.28**. Earlier public release: **v0.1.0-beta.2**. This page summarizes current milestones; the Chinese roadmap retains the original implementation sequence and detailed checklist.

## Completed

- [x] Editable workflow canvas: nodes, conditional routes, dragging, layout, undo/redo, template persistence and import/export.
- [x] Native conversation view, official input, session drafts, message/node navigation and conversation-driven workflow control.
- [x] Sequential model handoff with per-node rework and timeouts; direct controller and independent execution contexts.
- [x] Node-level model selection, execution/review snapshots, legacy migration and catalog retirement.
- [x] Parallel graphs with dependency-based dispatch and write-conflict scheduling, without worker counts or maximum concurrency settings.
- [x] Three Departments and Six Ministries and full-stack templates with planning, review, branching, joining and targeted rework.
- [x] Independent acceptance, requirement/evidence reconciliation, trusted verification corrections and final-delivery gates.
- [x] Explicit upstream-cancellation blocking, interrupted-work recovery and execution history.
- [x] Model tiers, task classification, manual locks and configured escalation chains.
- [x] Template and Skill libraries, DSH catalog integration and instruction snapshots.
- [x] Node/session/model/call monitoring, Token details, timing, pricing snapshots and budget reminders.
- [x] Official reference-price sources, manual overrides, custom Token bases, display units and explicit conversions.
- [x] Local regression, offline browser interaction and official DSH 0.1.7/0.2.0/0.2.1 contract verification.

## Pending

- [ ] Complete paid-model tasks in desktop DSH, including failure and handoff scenarios.
- [ ] Validate real Provider rate limits and end-to-end usage against invoices.
- [ ] Add Provider-specific balance/subscription-quota adapters where supported.
- [ ] Build an evidence-linked project experience index with revision and deduplication.

Session budgets remain reminders rather than spending caps. Templates remain optional; approval follows the selected session/template policy. Live acceptance results must be recorded separately from offline checks.

See the [original architecture research](design/model-handoff-workflow-research.md) for historical implementation planning in Chinese.
