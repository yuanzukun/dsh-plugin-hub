import React, { useEffect, useRef, useState } from 'react';
import { ReactFlowProvider, applyNodeChanges, applyEdgeChanges, useReactFlow } from '@xyflow/react';
import flowCSS from '@xyflow/react/dist/style.css';
import { WorkbenchView, useSystemAppearance } from './workbench-view.jsx';
import { workflowVisuals } from './workflow-visuals.mjs';
import { TemplateSettingsView } from './template-settings.jsx';
import { ModelRoutingSettingsView } from './model-routing-settings.jsx';
import { NODE_SIZE, arrangeWorkflow, workflowOverlaps, workflowExecutionKey, readCanvasState, writeCanvasState } from './graph-layout.mjs';
import { BillingSettings } from './billing-settings.jsx';
import { nodeModelChange } from './node-model-select.jsx';
import { normalizeModel, taskModel } from '../src/execution-model.mjs';
const clone = value => JSON.parse(JSON.stringify(value));
const definitionKey = workflowExecutionKey;
const conditions = { passed: '通过', rework_limit: '返工超限', timeout: '超时', error: '执行错误' };
const states = { running: '执行中', review: '待验收', pending: '待执行', done: '已验收', needs_attention: '需处理', cancelled: '已取消' };
const roles = { implementation: '实现', test: '测试', review: '审查', planning: '方案', scheduling: '调度' };
function elapsed(task,nodeId) {
  const visit=task?.workflow?.visits.filter(v=>v.nodeId===nodeId).at(-1);
  if(!visit)return '';
  const end=task.executionHistory.find(e=>e.epoch===visit.epoch&&e.status!=='started');
  const seconds=Math.floor(((end?Date.parse(end.at):Date.now())-Date.parse(visit.at))/1000);
  return Number.isFinite(seconds)?`${Math.floor(Math.max(0,seconds)/60)}分${Math.max(0,seconds)%60}秒`:'';
}
function Canvas({ sessionId, monitor, subscribe, refresh, onClose, openChild, initialDefinition, templateEditor, onTemplateSaved, nativeView = false }) {
  const [live, setLive] = useState(monitor), [taskId, setTaskId] = useState(() => readCanvasState(sessionId).taskId || ''), [draft, setDraft] = useState(() => initialDefinition ? clone(initialDefinition) : readCanvasState(sessionId).draft || null);
  const [templateDescription, setTemplateDescription] = useState(templateEditor?.description || '');
  const [selection, setSelection] = useState(null), [error, setError] = useState(''), [notice, setNotice] = useState(''), [busy, setBusy] = useState(false);
  const [text, setText] = useState(''), [buildMode, setBuildMode] = useState(false), [edgeCondition, setEdgeCondition] = useState('passed');
  const [history, setHistory] = useState({ past: [], future: [] }), [detail, setDetail] = useState('timeline');
  const [skillCatalog, setSkillCatalog] = useState(null);
  const theme = useSystemAppearance();
  const [measurements, setMeasurements] = useState({});
  const [layoutRequest, setLayoutRequest] = useState(0), [layoutRevision, setLayoutRevision] = useState(0);
  const beforeDrag = useRef(); const flow = useReactFlow();
  useEffect(() => subscribe(sessionId, 2000, setLive), [sessionId, subscribe]);
    const data = live?.data || {}, board = data.board || {}, tasks = board.tasks || [];
  const selectableTasks = tasks.filter(t => !t.orchestration || t.id === t.orchestration.id || t.id === taskId);
  const task = tasks.find(t => t.id === taskId) || selectableTasks[0], members = data.config?.members || [];
  const orchestration = task?.orchestration && task.id === task.orchestration.id ? board.orchestrations?.[task.id] : null;
  const selectedRunTask = orchestration && tasks.find(t => t.id === orchestration.taskIds[selection?.node]);
  useEffect(() => { if (!draft) { const d = orchestration?.definition || task?.workflow?.definition || board.workflowDraft || data.workflows?.templates?.[0]; if (d) { const saved = readCanvasState(sessionId).positions; const definition = clone(d); if (saved?.definitionId === d.id && saved.version === d.version) for (const node of definition.nodes) if (saved.nodes[node.id]) node.position = saved.nodes[node.id]; setDraft(definition); } } }, [data, draft, task, orchestration]);
  useEffect(() => { if (taskId) writeCanvasState(sessionId, { taskId }); }, [sessionId, taskId]);
  const edit = (next, remember = true) => {
    if (typeof next !== 'function') setLayoutRequest(value => value + 1);
    if (remember && draft) setHistory(h => ({ past: [...h.past, clone(draft)].slice(-100), future: [] }));
    setDraft(previous => { const resolved = typeof next === 'function' ? next(clone(previous)) : clone(next); if (!templateEditor && (remember || typeof next !== 'function')) writeCanvasState(sessionId, { draft: resolved }); return resolved; });
  };
  // Repair loaded layouts and card growth after every node has an actual size.
  // Position-only edits do not trigger this effect, so manual dragging stays under user control.
  useEffect(() => {
    if (!draft?.nodes.length || beforeDrag.current || !draft.nodes.every(node => measurements[node.id]?.width && measurements[node.id]?.height)) return;
    if (!workflowOverlaps(draft, measurements)) return;
    const repaired = arrangeWorkflow(draft, measurements);
    setDraft(repaired);
    if (!templateEditor) writeCanvasState(sessionId, { draft: repaired, positions: { definitionId: repaired.id, version: repaired.version, nodes: Object.fromEntries(repaired.nodes.map(node => [node.id, node.position])) } });
    setLayoutRevision(value => value + 1);
  }, [measurements, layoutRequest, draft?.id, draft?.version]);
  const undo = () => { if (!history.past.length) return; setHistory({ past: history.past.slice(0, -1), future: [clone(draft), ...history.future] }); setDraft(history.past.at(-1)); if (!templateEditor) writeCanvasState(sessionId, { draft: history.past.at(-1) }); };
  const redo = () => { if (!history.future.length) return; setHistory({ past: [...history.past, clone(draft)], future: history.future.slice(1) }); setDraft(history.future[0]); if (!templateEditor) writeCanvasState(sessionId, { draft: history.future[0] }); };
  const act = async (action, params = {}) => {
    setBusy(true); setError(''); setNotice('');
    try {
      const response = await fetch('/api/lead-worker/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId, action, ...params }) });
      const result = await response.json(); if (!response.ok || !result.ok) throw new Error(result.error || `HTTP ${response.status}`);
      if (!['workflowSkillCatalog', 'workflowSkillResolve'].includes(action)) await refresh(sessionId); if (!['workflowSkillCatalog', 'workflowSkillResolve'].includes(action)) setNotice(action === 'workflowDraft' ? '草案已保存；运行实例保持原版本' : action === 'workflowChat' ? '已发送至当前主控会话' : '操作已完成'); return result.result;
    } catch (err) { setError(err.message); throw err; } finally { setBusy(false); }
  };
  const run = (action, params) => act(action, params).catch(() => {});
  const loadSkills = async () => {
    try { const result = await act('workflowSkillCatalog'); setSkillCatalog(result); return result; } catch { return null; }
  };
  const attachSkill = async (skillId, nodeId = selection?.node) => {
    if (!nodeId || !draft?.nodes.some(node => node.id === nodeId)) { setError('先选择一个节点，或把 Skill 拖到目标节点上'); return; }
    try {
      const skill = await act('workflowSkillResolve', { skillId });
      edit(d => ({ ...d, nodes: d.nodes.map(node => node.id === nodeId ? { ...node, skills: [...(node.skills || []).filter(old => old.id !== skill.id), skill] } : node) }));
      setSelection({ node: nodeId }); setNotice(`已为节点添加 ${skill.name}；保存或应用草案后生效`);
    } catch { /* Keep the action error visible. */ }
  };
  const selectedNode = draft?.nodes.find(n => n.id === selection?.node), selectedEdge = draft?.edges.find(e => e.id === selection?.edge);
  const selectNodeModel = (id, value) => {
    const node = nodes.find(node => node.id === id);
    if (!node || node.data.modelLocked) return;
    try {
      const changed = nodeModelChange(draft.nodes.find(node => node.id === id), value, members, data.models || []);
      edit(d => ({ ...d, nodes: d.nodes.map(node => node.id === id ? changed : node) }));
      setSelection({ node: id }); setError(''); setNotice('节点模型已切换；应用流程后生效，可撤销');
    } catch (error) { setError(error.message); }
  };
  const updateNode = changes => edit(d => ({ ...d, nodes: d.nodes.map(n => n.id === selectedNode.id ? { ...n, ...changes } : n) }));
  const updateEdge = changes => edit(d => ({ ...d, edges: d.edges.map(e => e.id === selectedEdge.id ? { ...e, ...changes } : e) }));
  const uniqueId = () => `n-${globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`}`;
  const addNode = (role = 'implementation', position) => {
    if (!draft) return;
    const id = uniqueId(), member = data.models?.[0] ? normalizeModel(data.models[0]) : members.find(m => m.enabled && (role !== 'review' || m.readOnly)) || members.find(m => m.enabled);
    edit(d => ({ ...d, nodes: [...d.nodes, { id, label: `${roles[role]}节点`, role, ...(d.kind === 'orchestration' ? { stage: 'work' } : {}), mode: 'worker', memberId: member?.id, ...(member ? { modelConfig: normalizeModel(member) } : {}), reviewerId: ['implementation', 'test'].includes(role) ? member?.id || null : null, ...(['implementation', 'test'].includes(role) && member ? { reviewerConfig: normalizeModel(member) } : {}), maxReworks: 2, timeoutMs: 0, readOnly: ['review', 'planning', 'scheduling'].includes(role), position: position || { x: d.nodes.length * 280, y: 120 } }], edges: d.kind === 'orchestration' ? [...d.edges, { id: uniqueId(), source: d.nodes.find(n => n.stage === 'dispatch').id, target: id, condition: 'passed' }, { id: uniqueId(), source: id, target: d.nodes.find(n => n.stage === 'join').id, condition: 'passed' }] : d.edges })); setSelection({ node: id });
  };
  const connect = connection => edit(d => ({ ...d, edges: [...d.edges, { id: uniqueId(), source: connection.source, target: connection.target, condition: d.kind === 'orchestration' ? 'passed' : d.kind === 'dag' && !['passed', 'rejected'].includes(edgeCondition) ? 'passed' : edgeCondition, maxTraversals: 1 }] }));
  const remove = () => { edit(d => { const removed = new Set(d.nodes.filter(n => n.selected || n.id === selection?.node).map(n => n.id)), nodes = d.nodes.filter(n => !removed.has(n.id)); return { ...d, entry: removed.has(d.entry) ? nodes[0]?.id : d.entry, nodes, edges: d.edges.filter(e => !removed.has(e.source) && !removed.has(e.target) && e.id !== selection?.edge && !e.selected) }; }); setSelection(null); };
  const copySelected = () => edit(d => { const source = d.nodes.filter(n => n.selected || n.id === selection?.node), map = new Map(source.map(n => [n.id, uniqueId()])); return { ...d, nodes: [...d.nodes.map(n => ({ ...n, selected: false })), ...source.map(n => ({ ...n, id: map.get(n.id), label: `${n.label} 副本`, selected: true, position: { x: n.position.x + 40, y: n.position.y + 160 } }))], edges: [...d.edges, ...d.edges.filter(e => map.has(e.source) && map.has(e.target)).map(e => ({ ...e, id: uniqueId(), source: map.get(e.source), target: map.get(e.target) }))] }; });
  const graphRun = !templateEditor && orchestration && draft && definitionKey(orchestration.definition) === definitionKey(draft) ? orchestration : null;
  const nodeStates = !templateEditor && !graphRun && task?.workflow && draft && definitionKey(task.workflow.definition) === definitionKey(draft) ? task.workflow : null;
  const visuals = workflowVisuals(nodeStates, task?.status, board.status);
  const nodes = (draft?.nodes || []).map(n => ({ id: n.id, type: 'model', initialWidth: NODE_SIZE.width, initialHeight: NODE_SIZE.height, measured: measurements[n.id], position: n.position, selected: n.selected, data: { ...n, layoutDirection: draft.layoutDirection || 'TB', usage: nodeStates ? data.monitoring?.nodes.find(item => item.taskId === task.id && item.nodeId === n.id && item.batchId === board.batchId) : null, taskDifficulty: nodeStates ? task.difficulty : null, difficultyReason: nodeStates ? task.difficultyReason : null, isPreview: !nodeStates, isEntry: draft.entry === n.id, elapsed: nodeStates ? elapsed(task,n.id) : null, memberName: members.find(m => m.id === n.memberId)?.name, state: nodeStates?.current === n.id ? task.status : nodeStates?.transitions.some(t => t.from === n.id && t.condition === 'passed') ? 'done' : nodeStates?.visits.some(v => v.nodeId === n.id) ? 'needs_attention' : null, reworks: nodeStates?.current === n.id ? nodeStates.reworks : 0 } }));
  if (graphRun) for (const n of nodes) {
    const actual = tasks.find(t => t.id === graphRun.taskIds[n.id]);
    const skipped = graphRun.skipped[n.id];
    const activeNode = actual?.workflow?.definition.nodes.find(step => step.id === actual.workflow.current);
    n.data = { ...n.data, isPreview: false, memberId: actual?.memberId || n.memberId, state: skipped ? 'skipped' : actual?.status, skippedReason: skipped, memberName: members.find(m => m.id === actual?.memberId)?.name, model: members.find(m => m.id === actual?.memberId)?.model, usage: data.monitoring?.tasks?.find(summary => summary.taskId === actual?.id && summary.batchId === board.batchId), reworks: actual?.retries || 0, activeNodeLabel: activeNode?.label };
  }
  for (const n of nodes) {
    n.data.billingSettings = data.monitoring?.settings;
    n.data.modelMembers = members; n.data.onModelSelect = selectNodeModel; n.data.modelBusy = busy;
    const actualTask = graphRun ? tasks.find(t => t.id === graphRun.taskIds[n.id]) : null;
    const actualMember = actualTask ? taskModel(actualTask, members) : n.data.modelConfig || members.find(member => member.id === n.data.memberId);
    n.data.modelCatalog = data.models || []; n.data.routingEnabled = data.config?.modelRouting?.enabled === true;
    if (actualMember) n.data.modelConfig = actualMember;
    n.data.modelProvider = actualMember?.provider; n.data.modelId = actualMember?.model;
    n.data.modelLocked = Boolean(graphRun || task?.workflow && draft?.id === task.workflow.definition.id && draft?.version === task.workflow.definition.version && task.executionEpoch > 0 && (n.id === task.workflow.current || task.workflow.visits.some(visit => visit.nodeId === n.id)));
    n.data.modelLockReason = graphRun ? '已应用编排；请在新草案中调整模型' : '当前及已执行节点的模型已锁定';
  }
  const graphEdges = graphRun ? [...(draft?.edges || []).filter(e => e.condition !== 'passed' || tasks.find(t => t.id === graphRun.taskIds[e.target])?.dependencies.includes(graphRun.taskIds[e.source])), ...tasks.filter(t => t.orchestration?.id === graphRun.id).flatMap(t => t.dependencies.map(dep => ({ source: tasks.find(d => d.id === dep)?.orchestration?.nodeId, target: t.orchestration.nodeId })).filter(e => e.source && !(draft?.edges || []).some(old => old.source === e.source && old.target === e.target && old.condition === 'passed')).map(e => ({ ...e, id: `dependency-${e.source}-${e.target}`, condition: 'passed' })))] : draft?.edges || [];
  const edges = graphEdges.map((e, _, all) => { const siblings = all.filter(other => other.source === e.source && other.target === e.target); const source = graphRun && tasks.find(t => t.id === graphRun.taskIds[e.source]), target = graphRun && tasks.find(t => t.id === graphRun.taskIds[e.target]); const traversed = graphRun ? e.condition === 'passed' && source?.status === 'done' && target?.executionEpoch > 0 : visuals.edge(e).traversed; return { ...e, type: 'handoff', label: e.condition === 'rejected' ? '审议封驳 / 定向返工' : conditions[e.condition], data: { ...(graphRun ? { traversed, active: board.status === 'ready' && e.condition === 'passed' && source?.status === 'done' && target?.status === 'running' } : visuals.edge(e)), lane: (siblings.findIndex(other => other.id === e.id) - (siblings.length - 1) / 2) * 52 }, reconnectable: !graphRun }; });
  const nodeChanges = changes => {
    const dimensions = changes.filter(c => c.type === 'dimensions');
    if (dimensions.length) setMeasurements(previous => ({ ...previous, ...Object.fromEntries(dimensions.map(c => [c.id, c.dimensions])) }));
    const updated = applyNodeChanges(changes, nodes);
    if (changes.some(c => c.type === 'position' || c.type === 'select')) edit(d => ({ ...d, nodes: d.nodes.map(n => { const next = updated.find(v => v.id === n.id); return next ? { ...n, position: next.position, selected: next.selected } : n; }) }), false);
  };
  const locate = () => { const id = task?.workflow?.current; if (id) { setSelection({ node: id }); flow.fitView({ nodes: [{ id }], padding: .4, maxZoom: 1.1, duration: typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 0 : 180 }); } };
  const timeline = [ ...(task?.routingHistory || []).map(e => ({ at: e.at, text: e.type === 'handoff' ? `模型升级 · ${members.find(m => m.id === e.memberId)?.name || e.memberId} · ${conditions[e.reason] || e.reason}` : `模型路由 · ${members.find(m => m.id === e.memberId)?.name || e.memberId || '待分配'}`, body: e.type === 'handoff' ? undefined : e.reason })), ...(task?.executionHistory || []).map(e => ({ at: e.at, text: `执行 ${e.epoch} · ${states[e.status] || e.status}`, body: e.result || e.reason })), ...(task?.workflow?.transitions || []).map(e => ({ at: e.at, text: `${e.from} → ${e.to} · ${conditions[e.condition]}` })), ...(task?.workflow?.independentReviews || []).map(e => ({ at: e.at, text: `独立验收 · ${e.passed ? '通过' : '未通过'}`, body: e.feedback, childId: e.childId, childMode: e.childMode })) ].sort((a, b) => String(b.at).localeCompare(String(a.at)));
  const download = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(draft, null, 2)], { type: 'application/json' })); a.download = `${draft.id}-v${draft.version}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 0); };
  const edgeChanges = changes => {
    const updated = applyEdgeChanges(changes, edges);
    edit(d => ({ ...d, edges: d.edges.filter(e => updated.some(v => v.id === e.id)).map(e => ({ ...e, selected: updated.find(v => v.id === e.id)?.selected })) }), changes.some(c => c.type === 'remove'));
  };
  return <WorkbenchView state={{ layoutRevision, skillCatalog, sessionId, nativeView, live, data, board, tasks: selectableTasks, task, members, draft, selection, selectedNode, selectedEdge, selectedRunTask, graphRun, error, notice, busy, text, buildMode, edgeCondition, history, detail, theme, nodes, edges, timeline, flowCSS, visuals: graphRun ? { ...visuals, pulse: board.status === 'ready', paused: board.status === 'paused' } : visuals, templateEditor, templateDescription, canvasState: readCanvasState(sessionId), isApplied: Boolean(nodeStates || graphRun) }} actions={{
    setTemplateDescription, onTemplateSaved, loadSkills, attachSkill,
    setTaskId, setSelection, setText, setBuildMode, setEdgeCondition, setDetail, setError, setNotice,
    edit, undo, redo, act, run, updateNode, updateEdge, addNode, connect, remove, copySelected,
    nodeChanges, edgeChanges, locate, download, onClose, openChild,
    arrange: () => { edit(arrangeWorkflow(draft, measurements)); setLayoutRevision(value => value + 1); },
    setDirection: direction => { edit(arrangeWorkflow(draft, measurements, direction)); setLayoutRevision(value => value + 1); },
    saveViewport: viewport => writeCanvasState(sessionId, { viewport, viewportDirection: draft?.layoutDirection || 'TB', definitionId: `${draft?.id}:${draft?.version}` }),
    reconnect: (edge, connection) => edit(d => ({ ...d, edges: d.edges.map(e => e.id === edge.id ? { ...e, source: connection.source, target: connection.target } : e) })),
    dragStart: () => { beforeDrag.current = clone(draft); },
    dragStop: () => { if (beforeDrag.current) setHistory(h => ({ past: [...h.past, beforeDrag.current].slice(-100), future: [] })); beforeDrag.current = null; if (!templateEditor) writeCanvasState(sessionId, { draft, positions: { definitionId: draft.id, version: draft.version, nodes: Object.fromEntries(draft.nodes.map(n => [n.id, n.position])) } }); },
  }}/>;
}
export function Workbench(props) { return <ReactFlowProvider><Canvas {...props}/></ReactFlowProvider>; }
export function TemplateSettings(props) {
  const [editor, setEditor] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const theme = useSystemAppearance();
  if (editor) return <Workbench {...props} nativeView initialDefinition={editor.definition} templateEditor={editor} onClose={() => setEditor(null)} onTemplateSaved={id => { setSelectedId(id); setEditor(null); props.refresh(props.sessionId); }}/>;
  return <TemplateSettingsView {...props} initialSelectedId={selectedId} theme={theme} onEdit={setEditor}/>;
}
export function ModelRoutingSettings(props) { const theme = useSystemAppearance(); return <ModelRoutingSettingsView {...props} theme={theme}/>; }
export function BillingSettingsPage(props) {
  const [monitor, setMonitor] = useState(props.monitor);
  const [busy, setBusy] = useState(false);
  useEffect(() => props.subscribe(props.sessionId, 3000, setMonitor), [props.sessionId, props.subscribe]);
  const act = async (action, params) => {
    setBusy(true);
    try {
      const response = await fetch('/api/lead-worker/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: props.sessionId, action, ...params }) });
      const value = await response.json(); if (!response.ok || !value.ok) throw new Error(value.error || `HTTP ${response.status}`);
      await props.refresh(props.sessionId); return value.result;
    } finally { setBusy(false); }
  };
  return <BillingSettings monitor={monitor?.data?.monitoring} members={[...(monitor?.data?.models || []), ...(monitor?.data?.config?.members || []), ...(monitor?.data?.board?.tasks || []).flatMap(task => task.workflow?.definition.nodes.flatMap(node => [node.modelConfig, node.reviewerConfig].filter(Boolean)) || [])].map(normalizeModel).filter((model, index, all) => all.findIndex(other => other.provider === model.provider && other.model === model.model) === index)} act={act} busy={busy} onBack={props.onBack} theme={useSystemAppearance()}/>;
}
