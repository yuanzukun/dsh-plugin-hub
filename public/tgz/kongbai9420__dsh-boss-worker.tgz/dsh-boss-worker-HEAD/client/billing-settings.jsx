import React, { useEffect, useState } from 'react';
import { PRICE_SOURCES } from '../src/pricing-sources.mjs';

const tariffDefault = source => ({ deepseek: 'off-peak', openai: 'standard:short', anthropic: 'standard:5m-cache', google: 'standard:text', openrouter: 'standard' })[source];
const sourceGuess = (provider, model = '') => /deepseek/.test(provider + model) ? 'deepseek' : /anthropic|claude/.test(provider + model) ? 'anthropic' : /openrouter/.test(provider) ? 'openrouter' : /google|gemini/.test(provider + model) ? 'google' : 'openai';
const rateKeys = [['input', '未缓存输入'], ['output', '输出（含推理）'], ['cacheRead', '缓存读取'], ['cacheWrite', '缓存写入']];
export function BillingSettings({ monitor, members = [], act, busy = false, onBack, theme = 'light' }) {
  const [form, setForm] = useState(() => monitor ? structuredClone(monitor.settings) : null), [revision, setRevision] = useState(monitor?.revision);
  const [dirty, setDirty] = useState(false), [error, setError] = useState(''), [notice, setNotice] = useState(''), [catalogs, setCatalogs] = useState({}), [loading, setLoading] = useState('');
  useEffect(() => { if (!dirty && monitor && (revision == null || monitor.revision >= revision)) { setForm(structuredClone(monitor.settings)); setRevision(monitor.revision); } }, [monitor?.revision, dirty, revision]);
  const edit = update => { setDirty(true); setForm(previous => typeof update === 'function' ? update(previous) : { ...previous, ...update }); setNotice(''); };
  const changePrice = (index, update) => edit(previous => ({ ...previous, prices: previous.prices.map((price, i) => i === index ? { ...price, ...update } : price) }));
  const loadCatalog = async source => {
    if (catalogs[source]) return;
    setLoading(source); setError('');
    try { const result = await act('officialPriceCatalog', { source }); setCatalogs(previous => ({ ...previous, [source]: result.prices })); }
    catch (error) { setError(error.message); } finally { setLoading(''); }
  };
  const save = async (event, sync) => {
    event?.preventDefault(); setError(''); setNotice('');
    try {
      const settings = { ...form, prices: form.prices.map(price => ({ ...price, ...Object.fromEntries(rateKeys.map(([key]) => [key, price[key] === '' || price[key] == null ? null : Number(price[key])])) })) };
      const result = await act('configureMonitoring', { settings, budget: monitor.budget.limit, preserveBudget: true, expectedRevision: revision, sync });
      setForm(structuredClone(result.settings)); setRevision(result.revision); setDirty(false);
      const failures = result.settings.prices.filter(price => price.syncError);
      setNotice(failures.length ? `设置已保存；${failures.length} 个模型未同步成功，保留原价格。` : sync ? '官方价格已同步；历史调用保留原计价快照。' : '计价与显示设置已保存。');
    } catch (error) { setError(error.message); }
  };
  if (!form) return <p>正在读取用量与计价设置…</p>;
  const display = form.display || { moneyUnit: 'native', tokenDivisor: 1, tokenLabel: 'Token', decimals: 4, rates: {} };
  const setDisplay = update => edit(previous => ({ ...previous, display: { ...display, ...update } }));
  return <section className={`wf-workbench wf-billing-settings ${theme}`} aria-label="用量与计价设置">
    <header className="wf-template-heading"><div>{onBack && <button type="button" onClick={onBack}>‹ 返回</button>}<h2>用量与计价</h2><p>Profile 共享 · 模型价格、官方同步与显示单位</p></div><button className="primary" disabled={busy || !dirty} onClick={event => save(event, false)}>保存设置</button></header>
    {(error || notice) && <p className={`wf-template-notice ${error ? 'error' : ''}`} role={error ? 'alert' : 'status'}>{error || notice}</p>}
    <form onSubmit={event => save(event, false)}>
      <section className="wf-billing-section"><h3>官方价格</h3><p>将实际 Provider / 模型 ID 映射到厂商模型和适用计费档位。转售价格、订阅额度和 API 参考费用分别核对。</p>
        <label className="wf-inline-check"><input type="checkbox" checked={form.autoSync ?? true} onChange={event => edit({ autoSync: event.target.checked })}/>自动更新已配置官方价格（每 24 小时检查，打开工作台时触发）</label>
        <button type="button" disabled={busy || !form.prices.some(price => price.mode === 'official')} onClick={event => save(event, true)}>保存并同步官方价格</button>
        <div className="wf-billing-models">{form.prices.map((price, index) => {
          const catalog = catalogs[price.source] || [], official = price.mode === 'official';
          const chosen = catalog.find(row => row.model === (price.sourceModel || price.model) && row.tariff === price.tariff);
          return <fieldset className="wf-billing-model" key={index}><legend>{price.provider || 'Provider'} / {price.model || '模型 ID'}</legend>
            <div className="wf-field-pair"><label>Provider<input required value={price.provider} onChange={event => changePrice(index, { provider: event.target.value })}/></label><label>实际模型 ID<input required value={price.model} onChange={event => changePrice(index, { model: event.target.value })}/></label></div>
            <label>价格来源<select value={official ? price.source : 'manual'} onChange={event => { const source = event.target.value; if (source === 'manual') changePrice(index, { mode: 'manual', syncError: '' }); else { changePrice(index, { mode: 'official', source, sourceModel: price.model, tariff: tariffDefault(source), currency: 'USD', unitTokens: 1e6, input: null, output: null, cacheRead: null, cacheWrite: null, syncedAt: null }); loadCatalog(source); } }}><option value="manual">手动单价 / 自定义渠道</option>{Object.entries(PRICE_SOURCES).map(([key, source]) => <option key={key} value={key}>{source.name}</option>)}</select></label>
            {official && <><div className="wf-field-pair"><label>官方模型 ID<input list={`official-model-${index}`} value={price.sourceModel || price.model} onChange={event => changePrice(index, { sourceModel: event.target.value, input: null, output: null, cacheRead: null, cacheWrite: null, syncedAt: null })}/><datalist id={`official-model-${index}`}>{[...new Set(catalog.map(row => row.model))].map(model => <option key={model} value={model}/>)}</datalist></label><label>计费档位<select value={price.tariff} onChange={event => { const row = catalog.find(row => row.model === (price.sourceModel || price.model) && row.tariff === event.target.value); changePrice(index, { ...(row || {}), model: price.model, provider: price.provider, tariff: event.target.value }); }}><option value={price.tariff}>{price.tariff}</option>{[...new Set(catalog.filter(row => row.model === (price.sourceModel || price.model)).map(row => row.tariff))].filter(tariff => tariff !== price.tariff).map(tariff => <option key={tariff} value={tariff}>{tariff}</option>)}</select></label></div>
              <button type="button" disabled={busy || Boolean(loading)} onClick={() => loadCatalog(price.source)}>{loading === price.source ? '读取官方目录…' : '读取官方模型与档位'}</button>
              {chosen && <button type="button" onClick={() => changePrice(index, { ...chosen, provider: price.provider, model: price.model, sourceModel: chosen.model })}>采用此官方报价</button>}
              <p className="wf-price-source"><a href={PRICE_SOURCES[price.source]?.url} target="_blank" rel="noreferrer">查看官方来源 ↗</a> · {price.syncedAt ? `最近同步 ${new Date(price.syncedAt).toLocaleString('zh-CN', { hour12: false })}` : '尚未同步'}{price.syncError && ` · ${price.syncError}`}</p>{price.note && <p>{price.note}</p>}
            </>}
            <div className="wf-field-pair"><label>原始计价货币<select disabled={official} value={price.currency || form.currency} onChange={event => changePrice(index, { currency: event.target.value })}><option value="CNY">CNY · 元</option><option value="USD">USD · 美元</option></select></label><label>以下单价对应 Token 数<input disabled={official} type="number" min="1" step="1" value={price.unitTokens || form.unitTokens || 1e6} onChange={event => { const next = Number(event.target.value), old = price.unitTokens || form.unitTokens || 1e6; changePrice(index, { unitTokens: next, ...Object.fromEntries(rateKeys.map(([key]) => [key, price[key] == null ? null : price[key] * next / old])) }); }}/></label></div>
            <div className="wf-field-pair">{rateKeys.map(([key, label]) => <label key={key}>{label}<input disabled={official} type="number" min="0" step="any" placeholder="未知，留空" value={price[key] ?? ''} onChange={event => changePrice(index, { [key]: event.target.value })}/></label>)}</div>
            <button type="button" className="danger" onClick={() => edit(previous => ({ ...previous, prices: previous.prices.filter((_, i) => i !== index) }))}>移除此模型价格</button>
          </fieldset>;
        })}</div>
        <label>添加模型价格<select value="" onChange={event => { const member = members.find(member => member.id === event.target.value); if (member) edit(previous => ({ ...previous, prices: [...previous.prices, { provider: member.provider, model: member.model, mode: 'official', source: sourceGuess(member.provider, member.model), sourceModel: member.model, tariff: tariffDefault(sourceGuess(member.provider, member.model)), currency: 'USD', unitTokens: 1e6, input: null, output: null, cacheRead: null, cacheWrite: null }] })); }}><option value="">选择可用模型…</option>{members.filter(member => !form.prices.some(price => price.provider === member.provider && price.model === member.model)).map(member => <option key={member.id} value={member.id}>{member.name} · {member.provider}/{member.model}</option>)}</select></label>
        <button type="button" onClick={() => edit(previous => ({ ...previous, prices: [...previous.prices, { provider: '', model: '', mode: 'manual', currency: previous.currency, unitTokens: previous.unitTokens || 1e6, input: null, output: null, cacheRead: null, cacheWrite: null }] }))}>添加其他模型</button>
      </section>
      <section className="wf-billing-section"><h3>自定义单位</h3><p>原始账目保留来源货币。显示换算使用你填写的倍率，不自动猜测汇率或订阅额度。</p>
        <div className="wf-field-pair"><label>金额显示单位<input value={display.moneyUnit} placeholder="native / CNY / USD / 积分" onChange={event => setDisplay({ moneyUnit: event.target.value })}/><small>native 保留各币种，也可填写“积分”“额度”等名称</small></label><label>金额小数位<input type="number" min="0" max="10" value={display.decimals} onChange={event => setDisplay({ decimals: Number(event.target.value) })}/></label></div>
        {display.moneyUnit !== 'native' && <div className="wf-field-pair">{['CNY', 'USD'].map(currency => <label key={currency}>1 {currency} = 多少 {display.moneyUnit}<input type="number" min="0" step="any" value={display.rates?.[currency] ?? ''} placeholder="不换算，留空" onChange={event => setDisplay({ rates: { ...display.rates, [currency]: event.target.value === '' ? null : Number(event.target.value) } })}/></label>)}</div>}
        <div className="wf-field-pair"><label>每个显示单位对应 Token 数<input type="number" min="1" step="1" value={display.tokenDivisor} onChange={event => setDisplay({ tokenDivisor: Number(event.target.value) })}/></label><label>Token 显示名称<input value={display.tokenLabel} placeholder="Token / K Token / M Token" onChange={event => setDisplay({ tokenLabel: event.target.value })}/></label></div>
        <p>例如数量填 1000、名称填 K Token；金额单位填“积分”、USD 倍率填 100，表示 1 美元显示为 100 积分。</p>
      </section>
      <footer className="wf-billing-footer"><span>更改价格只影响之后启动的调用。</span><button className="primary" disabled={busy || !dirty} type="submit">保存设置</button></footer>
    </form>
  </section>;
}
