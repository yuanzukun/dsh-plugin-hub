import React, { useState } from 'react';
import { convertCosts } from '../src/billing-units.mjs';

export const tokenText = value => value == null ? '—' : new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 0 }).format(value);
const duration = ms => ms == null ? '—' : ms < 1000 ? `${Math.round(ms)} ms` : `${(ms / 1000).toFixed(1)} 秒`;
export const costText = (costs, settings) => Object.entries(convertCosts(costs || {}, settings?.display)).map(([currency, amount]) => {
  const decimals = settings?.display?.decimals ?? 4, threshold = 10 ** -decimals;
  return `${currency === 'CNY' ? '¥' : currency === 'USD' ? '$' : currency + ' '}${amount > 0 && amount < threshold ? '<' + threshold.toFixed(decimals) : amount.toFixed(decimals)}`;
}).join(' + ') || '未计价';
export const usageText = (value, settings) => `${value == null ? '—' : new Intl.NumberFormat('zh-CN', { maximumFractionDigits: settings?.display?.tokenDivisor > 1 ? 3 : 0 }).format(value / (settings?.display?.tokenDivisor || 1))} ${settings?.display?.tokenLabel || 'Token'}`;
const speedText = summary => summary?.speed == null ? '—' : `${summary.speedEstimated ? '≈' : ''}${summary.speed.toFixed(1)} tok/s`;
const roleText = { worker: '节点执行', reviewer: '独立验收', controller: '主控会话', 'controller-direct': '主控直接执行' };
const statusText = { running: '运行中', completed: '已结束', interrupted: '已中断', cancelled: '已取消', error: '调用失败' };

export function NodeUsage({ summary, settings, showEmpty = false, emptyLabel = '尚未收到调用统计', onOpen }) {
  if (!summary) return showEmpty ? <div className="wf-node-usage" aria-label="节点运行统计"><span className="wf-usage-stage">节点累计</span><dl className="wf-node-usage-totals"><div><dt>已结算 Token</dt><dd>{usageText(null, settings)}</dd></div><div><dt>预估费用</dt><dd>未计价</dd></div></dl><small>{emptyLabel}</small></div> : null;
  const stage = summary.toolsRunning ? '工具执行中' : summary.running ? summary.speed == null ? '等待首响应' : '正在生成' : '已统计';
  const hasCost = Object.keys(summary.costs).length > 0, incomplete = summary.pendingUsage > 0 || summary.missingUsage > 0 || summary.unpriced > 0;
  return <div className="wf-node-usage nodrag nopan" aria-label="节点运行统计" title="本节点累计，包含返工和独立验收；不包含其他节点或普通主控对话">
    <span className="wf-usage-stage">节点累计 <small>{summary.calls} 次调用</small></span>
    <dl className="wf-node-usage-totals"><div><dt>已结算 Token</dt><dd>{usageText(summary.usage.totalTokens, settings)}</dd></div><div><dt>预估费用{hasCost && incomplete ? '（部分）' : ''}</dt><dd>{hasCost ? '≈' : ''}{costText(summary.costs, settings)}</dd></div></dl>
    <span className="wf-usage-stage"><small>{stage}{summary.byModel?.length > 1 ? ` · ${summary.byModel.length} 个模型` : ''}</small><b>{summary.running && !summary.toolsRunning ? speedText(summary) : ''}</b></span>
    {summary.running > 0 && <small>本轮用量待结算{summary.liveEstimatedTokens > 0 ? ` · 输出估算 ${usageText(summary.liveEstimatedTokens, settings)}` : ''}</small>}
    {(summary.missingUsage > 0 || summary.unpriced > 0) && <small>{summary.missingUsage > 0 ? '部分调用未返回用量' : `${summary.unpriced} 次调用未计价`}</small>}
    {onOpen && <button type="button" className="wf-node-usage-open" onPointerDown={event => event.stopPropagation()} onClick={event => { event.stopPropagation(); onOpen(); }}>用量明细 ↗</button>}
  </div>;
}

export function UsageStrip({ monitor, onOpen }) {
  if (!monitor) return null;
  const { summary, budget, settings } = monitor;
  return <button className="wf-usage-strip" onClick={onOpen} aria-label="查看当前会话运行统计"><span>会话用量 <b>{usageText(summary.usage.totalTokens, settings)}</b>{(summary.pendingUsage > 0 || summary.missingUsage > 0) && <small> · 未完全结算</small>}</span><span>预估费用 <b>{costText(summary.costs, settings)}</b></span>{budget.limit != null && <span className={budget.spent != null && budget.spent >= budget.limit ? 'wf-budget-alert' : ''}>预算 {budget.currency === 'CNY' ? '¥' : budget.currency === 'USD' ? '$' : budget.currency + ' '}{budget.limit} · {budget.spent == null ? '待统计' : `${Math.round(budget.spent / (budget.limit || 1) * 100)}%`}</span>}<span className="wf-usage-open">查看监控 ↗</span></button>;
}

function Stats({ summary, settings }) {
  return <dl className="wf-usage-stats">{[
    ['已结算 Token', usageText(summary.usage.totalTokens, settings)], ['预估费用', costText(summary.costs, settings)],
    ['平均生成速度', speedText(summary)], ['最近首响应', duration(summary.ttftMs)],
    ['模型调用时间', duration(summary.modelMs)], ['工具执行时间', duration(summary.toolMs)],
  ].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>;
}

function BudgetEditor({ monitor, act, busy }) {
  const [editing, setEditing] = useState(false), [limit, setLimit] = useState(''), [error, setError] = useState('');
  if (!editing) return <button onClick={() => { setLimit(monitor.budget.limit ?? ''); setEditing(true); }}>调整本会话预算</button>;
  const unit = monitor.settings.display?.moneyUnit === 'native' ? monitor.settings.currency : monitor.settings.display?.moneyUnit;
  return <form onSubmit={async event => { event.preventDefault(); setError(''); try { await act('configureMonitoring', { settings: monitor.settings, budget: limit === '' ? null : Number(limit), expectedRevision: monitor.revision }); setEditing(false); } catch (error) { setError(error.message); } }}><label>本会话预算（{unit || 'CNY'}）<input type="number" min="0" step="any" value={limit} placeholder="不限，留空" onChange={event => setLimit(event.target.value)}/></label>{error && <p role="alert">{error}</p>}<button disabled={busy} type="submit">保存预算</button><button type="button" onClick={() => setEditing(false)}>取消</button></form>;
}

export function UsagePanel({ monitor, task, nodeId, members, act, busy, isApplied, batchId, scope = 'session', setScope, onOpenSettings, aggregateTask = false }) {
  if (!monitor) return <div className="wf-pane-scroll"><p>正在读取运行统计…</p></div>;
  const node = isApplied ? aggregateTask ? monitor.tasks?.find(n => n.taskId === task?.id && n.batchId === batchId) : monitor.nodes.find(n => n.taskId === task?.id && n.nodeId === nodeId && n.batchId === batchId) : null;
  const settings = monitor.settings;
  const useNode = scope === 'node' && node;
  const summary = useNode ? node : monitor.summary;
  const calls = useNode ? monitor.calls.filter(c => c.taskId === task.id && (aggregateTask || c.nodeId === nodeId) && c.batchId === batchId) : monitor.calls;
  const modelSummaries = useNode ? node.byModel || [] : monitor.byModel;
  const budget = monitor.budget, budgetSpent = budget.spent ?? 0;
  return <><div className="wf-panel-heading"><div><h3>运行监控</h3><p>速度、用量与费用</p></div>{onOpenSettings && <button onClick={onOpenSettings}>计价设置</button>}</div><div className="wf-pane-scroll wf-monitor"><nav className="wf-record-tabs" aria-label="统计范围"><button aria-pressed={scope === 'session' || !node} onClick={() => setScope('session')}>当前会话</button><button disabled={!node} aria-pressed={Boolean(useNode)} onClick={() => setScope('node')}>选中节点</button></nav><Stats summary={summary} settings={settings}/>
    <p className="wf-field-help">{summary.calls} 次模型调用 · {summary.pendingUsage} 次待结算{summary.missingUsage > 0 ? ` · ${summary.missingUsage} 次未提供用量` : ''}{summary.unpriced > 0 ? ` · ${summary.unpriced} 次未计价` : ''}</p>
    <p className="wf-field-help">实时速度按流式文本估算，结束后使用提供方用量计算平均速度。工具时间单独统计，隐藏推理不推算速度。推理 Token 是输出的细分，不重复相加；并行调用的累计时间可重叠。</p>
    <section className="wf-config-group"><h4>Token 明细</h4><dl className="wf-usage-breakdown">{[['inputTokens', '未缓存输入'], ['cacheReadTokens', '缓存读取'], ['cacheWriteTokens', '缓存写入'], ['outputTokens', '输出'], ['reasoningTokens', '其中：推理']].map(([key, label]) => <div key={key}><dt>{label}</dt><dd>{usageText(summary.usage[key], settings)}</dd></div>)}</dl></section>
    {!useNode && <section className="wf-config-group"><h4>本会话预算</h4>{budget.limit != null ? <><progress aria-label="已知费用占会话预算" max={budget.limit || 1} value={Math.min(budgetSpent, budget.limit || 1)}/><p className={budget.spent != null && budgetSpent >= budget.limit ? 'wf-budget-alert' : ''}>{budget.spent == null ? '待统计' : costText({ [budget.currency]: budgetSpent })} / {budget.currency === 'CNY' ? '¥' : budget.currency === 'USD' ? '$' : budget.currency + ' '}{budget.limit}{budget.spent != null && budgetSpent >= budget.limit ? ' · 已达到预算' : ''}</p><p className="wf-field-help">仅统计可计价且可换算的调用；未换算币种、待结算与未知费用未包含。预算提醒不会中断任务。</p></> : <p>尚未设置会话预算</p>}<BudgetEditor monitor={monitor} act={act} busy={busy}/></section>}
    {modelSummaries.length > 0 && <section className="wf-config-group"><h4>{useNode ? '本节点按模型统计' : '按模型查看'}</h4>{modelSummaries.map(model => <article className="wf-model-usage" key={`${model.provider}/${model.model}`}><b>{model.model}</b><small>{model.provider}</small><span>{usageText(model.usage.totalTokens, settings)} · {costText(model.costs, settings)}{model.unpriced > 0 ? ' · 部分未计价' : ''}</span></article>)}</section>}
    <section className="wf-config-group"><h4>调用记录</h4>{!calls.length && <p>开始执行后显示真实调用；历史用量不会根据文字补算。</p>}{calls.slice(-100).reverse().map(call => <details className="wf-call" key={call.id}><summary><span><b>{roleText[call.role] || call.role} · {call.model}</b><small>第 {call.epoch ?? '—'} 代 · {statusText[call.status]}{call.purpose ? ` · ${call.purpose}` : ''}</small></span><span>{call.usage ? usageText(call.usage.totalTokens, settings) : call.status === 'running' ? '待结算' : '用量未知'}</span></summary><dl className="wf-usage-breakdown"><div><dt>Provider</dt><dd>{call.provider}</dd></div><div><dt>时间</dt><dd>{new Date(call.startedAt).toLocaleTimeString('zh-CN', { hour12: false })}</dd></div><div><dt>首响应</dt><dd>{duration(call.firstTokenAt == null ? null : call.firstTokenAt - call.startedAt)}</dd></div><div><dt>预估费用</dt><dd>{call.cost == null ? '未计价' : costText({ [call.currency]: call.cost }, settings)}</dd></div><div><dt>价格来源</dt><dd>{call.price?.sourceUrl ? <a href={call.price.sourceUrl} target="_blank" rel="noreferrer">{call.price.source} · {call.price.tariff}</a> : '手动单价'}</dd></div></dl></details>)}</section>
    <section className="wf-config-group"><h4>账户剩余额度</h4><p>未提供</p><p className="wf-field-help">{monitor.quota.reason}。会话消耗和自设预算独立显示。</p></section><p className="wf-monitor-since">统计起于 {new Date(monitor.since).toLocaleString('zh-CN', { hour12: false })}；仅保存调用元数据。</p>
  </div></>;
}
