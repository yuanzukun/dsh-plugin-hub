import React, { useState } from 'react';
import { normalizeModel } from '../src/execution-model.mjs';

const roles = { planning: '方案', implementation: '实现', test: '测试', review: '审查', scheduling: '调度' };
export function WorkflowLibrary({ mode, templates = [], skills = [], revision, nativeError, selectedNode, draft, members = [], models = [], busy, act, loadSkills, attachSkill, edit, onClose, onUseTemplate }) {
  const [query, setQuery] = useState(''), [role, setRole] = useState(''), [form, setForm] = useState(null), [error, setError] = useState('');
  const matches = item => `${item.name} ${item.description || ''}`.toLowerCase().includes(query.toLowerCase());
  const saveSkill = async event => {
    event.preventDefault(); setError('');
    try { await act('workflowSkillSave', { skillId: form.id, skill: form, expectedSkillsRevision: revision }); setForm(null); await loadSkills(); }
    catch (error) { setError(error.message); }
  };
  const removeSkill = async id => {
    try { await act('workflowSkillDelete', { skillId: id, expectedSkillsRevision: revision }); await loadSkills(); }
    catch (error) { setError(error.message); }
  };
  const blank = () => {
    const member = (models.length ? models.map(normalizeModel) : members).find(member => member.enabled !== false);
    if (!member) { setError('请先在 DSH 中配置一个可用模型'); return; }
    onUseTemplate({ id: `draft-${Date.now()}`, name: '自定义流程', kind: 'dag', version: 1, entry: 'start', nodes: [{ id: 'start', label: '执行', role: 'implementation', mode: 'worker', memberId: member.id, modelConfig: normalizeModel(member), reviewerId: member.id, reviewerConfig: normalizeModel(member), maxReworks: 2, timeoutMs: 0, position: { x: 100, y: 100 } }], edges: [] });
  };
  return <section id="wf-library" className="wf-library nodrag nopan" aria-label={mode === 'templates' ? '流程模板库' : 'Skill 库'}>
    <header><div><h3>{mode === 'templates' ? '流程模板库' : 'Skill 库'}</h3><p>{mode === 'templates' ? '选一个起点，再按任务修改' : '拖到节点，或为选中节点点击添加'}</p></div><button type="button" aria-label="关闭资源库" onClick={onClose}>×</button></header>
    <div className="wf-library-tools"><input aria-label={mode === 'templates' ? '搜索流程模板' : '搜索 Skill'} placeholder={mode === 'templates' ? '搜索模板…' : '搜索 Skill…'} value={query} onChange={event => setQuery(event.target.value)}/>
      {mode === 'skills' && <select aria-label="筛选 Skill 类型" value={role} onChange={event => setRole(event.target.value)}><option value="">全部类型</option>{Object.entries(roles).map(([id, name]) => <option key={id} value={id}>{name}</option>)}</select>}</div>
    <div className="wf-library-actions">{mode === 'templates' ? <><button type="button" onClick={blank}>从空白开始</button><button type="button" disabled={!draft || busy} onClick={async () => { try { await act('workflowTemplateSave', { definition: draft, description: '', expectedTemplatesRevision: revision }); } catch (error) { setError(error.message); } }}>保存当前为模板</button></> : <><button type="button" onClick={() => { setError(''); setForm({ name: '', description: '', content: '', roles: role ? [role] : Object.keys(roles) }); }}>新建 Skill</button><button type="button" disabled={busy} onClick={loadSkills}>刷新 DSH Skill</button></>}</div>
    {error && <p role="alert" className="wf-library-error">{error}</p>}
    {mode === 'skills' && nativeError && <p className="wf-library-help">{nativeError}</p>}
    <div className="wf-library-scroll">
      {form && <form className="wf-skill-form" onSubmit={saveSkill}><h4>{form.id ? '编辑 Skill' : '新建 Skill'}</h4><label>Skill 名称<input required value={form.name} onChange={event => setForm({ ...form, name: event.target.value })}/></label><label>Skill 说明<input value={form.description} onChange={event => setForm({ ...form, description: event.target.value })}/></label><fieldset><legend>推荐节点类型</legend>{Object.entries(roles).map(([id, name]) => <label key={id}><input type="checkbox" checked={form.roles.includes(id)} onChange={event => setForm({ ...form, roles: event.target.checked ? [...form.roles, id] : form.roles.filter(old => old !== id) })}/>{name}</label>)}</fieldset><label>Skill 指令<textarea required value={form.content} onChange={event => setForm({ ...form, content: event.target.value })} placeholder="填写可复用的操作步骤、交付标准和约束…"/></label><div className="wf-library-actions"><button className="primary" disabled={busy || !form.roles.length} type="submit">保存 Skill</button><button type="button" onClick={() => setForm(null)}>取消编辑</button></div></form>}
      {mode === 'templates' ? <>
        {templates.filter(matches).map(template => <article key={template.id} className="wf-library-card"><div className="wf-library-card-title"><b>{template.name}</b><span>{template.builtin ? '内置' : '我的模板'}</span></div><small>{template.nodes.length} 个节点 · {template.kind === 'orchestration' ? '分支编排' : '模型接管'} · v{template.version}</small><p>{template.description || template.nodes.map(node => node.label).join(' → ')}</p><button className="wf-library-use" type="button" onClick={() => onUseTemplate(template)}>预览到画布</button></article>)}
        {!templates.filter(matches).length && <p className="wf-library-help">没有匹配模板。可以从空白开始，或先配置成员。</p>}
      </> : <>
        <p className="wf-library-target">{selectedNode ? `添加目标：${selectedNode.label}` : '尚未选中节点 · 可直接拖到画布节点'}</p>
        {skills.filter(matches).filter(skill => !role || !skill.roles.length || skill.roles.includes(role)).map(skill => <article key={skill.id} className="wf-library-card wf-skill-card" draggable onDragStart={event => { event.dataTransfer.effectAllowed = 'copy'; event.dataTransfer.setData('application/dsh-skill', skill.id); }}><div className="wf-library-card-title"><b>{skill.name}</b><span>{skill.source === 'dsh' ? 'DSH' : skill.source === 'builtin' ? '内置' : '我的 Skill'}</span></div><small>{skill.roles.length ? skill.roles.map(role => roles[role]).join(' · ') : '任意类型'} · 拖拽添加</small><p>{skill.description || '可复用的节点工作指令'}</p><div className="wf-library-actions"><button type="button" disabled={!selectedNode || busy} onClick={() => attachSkill(skill.id)}>{selectedNode?.skills?.some(old => old.id === skill.id) ? '更新节点快照' : '添加到选中节点'}</button>{skill.source !== 'dsh' && <button type="button" onClick={() => setForm({ ...skill, id: skill.source === 'builtin' ? undefined : skill.id, name: skill.source === 'builtin' ? `${skill.name} 副本` : skill.name })}>{skill.source === 'builtin' ? '复制编辑' : '编辑'}</button>}{skill.source === 'workflow' && <button type="button" className="danger" disabled={busy} onClick={() => removeSkill(skill.id)}>删除</button>}</div></article>)}
        {!skills.filter(matches).filter(skill => !role || !skill.roles.length || skill.roles.includes(role)).length && <p className="wf-library-help">没有匹配的 Skill。试试其他类型，或新建一个。</p>}
      </>}
    </div>
  </section>;
}
