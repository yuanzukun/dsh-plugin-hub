import React, { useEffect, useState } from 'react';
import { normalizeModel } from '../src/execution-model.mjs';
const copy = value => JSON.parse(JSON.stringify(value));
export function ModelRoutingSettingsView({ sessionId, monitor, subscribe, refresh, onBack, theme }) {
  const [live, setLive] = useState(monitor), [draft, setDraft] = useState(null), [revision, setRevision] = useState(null);
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [notice, setNotice] = useState('');
  useEffect(() => subscribe(sessionId, 2000, setLive), [sessionId, subscribe]);
  const data = live?.data || {};
  useEffect(() => { if (!draft && data.config?.modelRouting) { setDraft(copy(data.config.modelRouting)); setRevision(data.configRevision); } }, [data, draft]);
  const members = (data.models?.length ? data.models.map(normalizeModel) : data.config?.members || []).filter(member => member.enabled !== false);
  if (!draft) return <section className={`wf-workbench wf-template-settings ${theme}`}><p>正在读取模型路由设置…</p></section>;
  const patch = changes => setDraft(old => ({ ...old, ...changes }));
  const tierFields = (name, item, change) => <section className="wf-routing-tier"><h3>{name}</h3><label>执行模型<select aria-label={`${name}模型`} value={item.memberId || ''} onChange={event => change({ ...item, memberId: event.target.value || null, modelConfig: members.find(model => model.id === event.target.value) || null })}><option value="">选择可用模型…</option>{members.map(member => <option key={member.id} value={member.id}>{member.name} · {member.provider}/{member.model}{member.readOnly ? '（只读）' : ''}</option>)}</select></label><div className="wf-field-pair"><label>允许返工次数<input aria-label={`${name}返工次数`} type="number" min="0" max="1000" value={item.maxReworks} onChange={event => change({ ...item, maxReworks: Number(event.target.value) })}/></label><label>超时时间（秒）<input aria-label={`${name}超时秒数`} type="number" min="0" value={item.timeoutMs / 1000} onChange={event => change({ ...item, timeoutMs: Math.round(Number(event.target.value) * 1000) })}/></label></div></section>;
  const save = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      const response = await fetch('/api/lead-worker/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId, action: 'configureModelRouting', modelRouting: draft, expectedConfigRevision: revision }) });
      const result = await response.json(); if (!response.ok || !result.ok) throw new Error(result.error || `HTTP ${response.status}`);
      setDraft(copy(result.result.config.modelRouting)); setRevision(result.result.configRevision); await refresh(sessionId); setNotice('模型路由已保存，用于后续新任务；已有任务的模型链保持原配置。');
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  return <section className={`wf-workbench wf-template-settings wf-routing-settings ${theme}`} aria-label="模型路由设置"><header className="wf-template-heading"><div>{onBack && <button onClick={onBack}>‹ 返回设置</button>}<h2>任务分级与模型路由</h2><p>简单子任务使用经济模型，复杂子任务使用你指定的高能力模型。</p></div><button className="primary" disabled={busy} onClick={save}>保存路由设置</button></header>
    {(error || notice || live?.error) && <p className={`wf-template-notice ${error || live?.error ? 'error' : ''}`} role={error || live?.error ? 'alert' : 'status'}>{error || live?.error || notice}</p>}
    <div className="wf-routing-overview"><label className="wf-check-row"><span><b>启用模型路由</b><small>设置在当前 Profile 内共享；主控负责分级与验收，子模型负责执行。</small></span><input type="checkbox" checked={draft.enabled} onChange={event => patch({ enabled: event.target.checked })}/></label><label>难度确定方式<select aria-label="难度确定方式" value={draft.classification} onChange={event => patch({ classification: event.target.value })}><option value="auto">主控在现有规划中判断</option><option value="manual">由用户手动确定</option></select></label><p>按每项拆分后的子任务判断范围、依赖、上下文和不确定性，不按整个项目统一分级。缺少难度或理由时等待补充，不额外调用分类模型。</p></div>
    <div className="wf-routing-tiers">{tierFields('简单任务 · 经济档', draft.simple, simple => patch({ simple }))}{tierFields('复杂任务 · 能力档', draft.complex, complex => patch({ complex }))}</div>
    <section className="wf-routing-overview"><label className="wf-check-row"><span><b>允许自动升级</b><small>返工用尽、超时或执行错误后，保留成果交给后继模型；主动取消不触发升级。</small></span><input type="checkbox" checked={draft.autoEscalate} onChange={event => patch({ autoEscalate: event.target.checked })}/></label><p>简单档 → 复杂档 → 自定义后继；复杂任务从复杂档开始。关闭后在当前档位停止，等待处理。超时 0 表示不限时，返工次数不含首次执行。</p>
      {draft.fallbacks.map((item, index) => <div key={index} className="wf-routing-fallback">{tierFields(`后继模型 ${index + 1}`, item, next => patch({ fallbacks: draft.fallbacks.map((old, i) => i === index ? next : old) }))}<button className="danger" onClick={() => patch({ fallbacks: draft.fallbacks.filter((_, i) => i !== index) })}>移除此后继</button></div>)}<button onClick={() => patch({ fallbacks: [...draft.fallbacks, { memberId: null, maxReworks: 2, timeoutMs: 0 }] })}>＋ 添加后继模型</button></section>
    <p className="wf-routing-help">模板中固定指定的成员继续生效；需要路由时，将节点模型选择改为“跟随任务难度”“经济档”或“复杂档”。模板自身的预算和条件边仍由模板决定。成员的实际模型在“角色”中配置；档位名称不代表自动获取或核算价格。</p><button disabled={busy} onClick={() => { setDraft(copy(data.config.modelRouting)); setRevision(data.configRevision); setError(''); setNotice('已载入最新设置。'); }}>重新载入最新设置</button>
  </section>;
}
