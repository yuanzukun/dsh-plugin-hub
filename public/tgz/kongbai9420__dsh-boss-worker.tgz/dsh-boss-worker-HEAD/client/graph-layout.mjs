import dagre from '@dagrejs/dagre';
export const NODE_SIZE = { width: 240, height: 300 };
const sizeOf = (id, measurements) => ({ width: measurements[id]?.width || NODE_SIZE.width, height: measurements[id]?.height || NODE_SIZE.height });
export function workflowOverlaps(definition, measurements = {}) {
  return definition.nodes.some((node, i) => {
    const a = sizeOf(node.id, measurements);
    return definition.nodes.slice(i + 1).some(other => {
      const b = sizeOf(other.id, measurements);
      return Math.min(node.position.x + a.width, other.position.x + b.width) - Math.max(node.position.x, other.position.x) > 1
        && Math.min(node.position.y + a.height, other.position.y + b.height) - Math.max(node.position.y, other.position.y) > 1;
    });
  });
}
export function workflowExecutionKey(value) {
  if (!value) return '';
  const { layoutDirection, ...definition } = value;
  return JSON.stringify({ ...definition, nodes: value.nodes.map(({ selected, position, ...node }) => node), edges: value.edges.map(({ selected, ...edge }) => edge) });
}
export function arrangeWorkflow(definition, measurements = {}, direction = definition.layoutDirection || 'TB') {
  const layoutDirection = direction === 'LR' ? 'LR' : 'TB';
  const graph = new dagre.graphlib.Graph().setGraph({ rankdir: layoutDirection, nodesep: 60, ranksep: 100, marginx: 36, marginy: 36 }).setDefaultEdgeLabel(() => ({}));
  for (const node of definition.nodes) graph.setNode(node.id, sizeOf(node.id, measurements));
  for (const edge of definition.edges) if (edge.condition === 'passed') graph.setEdge(edge.source, edge.target);
  dagre.layout(graph);
  return { ...definition, layoutDirection, nodes: definition.nodes.map(node => { const pos = graph.node(node.id); return { ...node, position: { x: pos.x - pos.width / 2, y: pos.y - pos.height / 2 } }; }) };
}
const key = sessionId => `dsh_boss_workflow_view_${sessionId}`;
export function readCanvasState(sessionId) { if (typeof window === 'undefined') return {}; try { return JSON.parse(localStorage.getItem(key(sessionId)) || '{}'); } catch { return {}; } }
export function writeCanvasState(sessionId, patch) { if (typeof window === 'undefined') return; try { localStorage.setItem(key(sessionId), JSON.stringify({ ...readCanvasState(sessionId), ...patch })); } catch {} }
