import React from 'react';
import { normalizeModel, modelIdentity } from '../src/execution-model.mjs';

export function NodeModelSelect({ id, data }) {
  const members = (data.modelMembers || []).filter(member => member.enabled);
  const catalog = data.modelCatalog?.length ? data.modelCatalog : members;
  const selected = data.modelConfig || members.find(member => member.id === data.memberId);
  const value = data.mode === 'controller' || data.mode === 'controller-child' ? data.mode : data.modelSelection && data.modelSelection !== 'fixed' ? `tier:${data.modelSelection}` : selected ? modelIdentity(selected.provider, selected.model) : '';
  const known = !value.startsWith('model:') || catalog.some(model => modelIdentity(model.provider, model.model) === value);
  const routeLabels = { task: '跟随任务难度', simple: '经济档模型', complex: '复杂档模型' };
  const detail = data.mode === 'controller' ? '当前主控直接执行' : data.mode === 'controller-child' ? '沿用主控模型 · 独立子会话' : data.modelSelection && data.modelSelection !== 'fixed' && data.isPreview ? routeLabels[data.modelSelection] : data.modelProvider && data.modelId ? `${data.modelProvider} / ${data.modelId}` : '选择已配置的成员模型';
  return <div className="wf-node-model-picker nodrag nopan nowheel" onPointerDown={event => event.stopPropagation()} onClick={event => event.stopPropagation()} onDoubleClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}>
    <label><span>模型</span><select aria-label={`切换 ${data.label || id} 的模型`} title={data.modelLocked ? data.modelLockReason : detail} value={value} disabled={data.modelLocked || data.modelBusy} onChange={event => data.onModelSelect(id, event.target.value)}>
      {!value && <option value="" disabled>请选择模型</option>}
      {!known && <option value={value}>{selected?.provider} / {selected?.model} · 已保存配置</option>}
      <optgroup label="可用模型">{catalog.filter((model, index, all) => all.findIndex(other => other.provider === model.provider && other.model === model.model) === index).map(model => <option key={modelIdentity(model.provider, model.model)} value={modelIdentity(model.provider, model.model)}>{model.provider} / {model.model}</option>)}</optgroup>
      <optgroup label={data.routingEnabled ? '自动模型路由' : '自动路由（请先在设置中启用）'} disabled={!data.routingEnabled}>{Object.entries(routeLabels).map(([key, label]) => <option key={key} value={`tier:${key}`}>{label}</option>)}</optgroup>
      <optgroup label="主控模型"><option value="controller-child">主控同款模型 · 独立执行</option><option value="controller" disabled={!data.reviewerId}>当前主控直接执行{!data.reviewerId ? '（需先配置独立验收）' : ''}</option></optgroup>
    </select></label><small title={detail}>{detail}</small>{data.modelLocked && <small className="wf-model-lock-note">{data.modelLockReason}</small>}
  </div>;
}

export function nodeModelChange(node, value, members, catalog = []) {
  if (value.startsWith('model:')) {
    const model = [...catalog, ...members].find(item => modelIdentity(item.provider, item.model) === value);
    if (!model) throw new Error('所选模型不在当前 DSH 可用目录中');
    const modelConfig = normalizeModel({ provider: model.provider, model: model.model, name: model.name });
    return { ...node, mode: 'worker', modelSelection: 'fixed', memberId: modelConfig.id, modelConfig };
  }
  if (value.startsWith('member:')) {
    const memberId = value.slice(7);
    if (!members.some(member => member.id === memberId && member.enabled)) throw new Error('所选成员不可用，请先在团队设置中配置模型');
    return { ...node, mode: 'worker', modelSelection: 'fixed', memberId, modelConfig: normalizeModel(members.find(member => member.id === memberId)) };
  }
  if (value.startsWith('tier:') && ['task', 'simple', 'complex'].includes(value.slice(5))) { const changed = { ...node, mode: 'worker', modelSelection: value.slice(5) }; delete changed.modelConfig; return changed; }
  if (value === 'controller-child' || value === 'controller' && node.reviewerId) return { ...node, mode: value, modelSelection: 'fixed' };
  throw new Error('无效模型选择；主控直接执行需要独立验收成员');
}
