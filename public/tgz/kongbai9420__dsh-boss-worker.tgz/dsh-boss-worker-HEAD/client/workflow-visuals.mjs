// Visuals describe confirmed execution history, never possible future branches.
export function workflowVisuals(run, taskStatus, boardStatus) {
  const transitions = run?.transitions || [];
  const latest = transitions.at(-1);
  const moving = Boolean(run) && boardStatus === 'ready' && ['running', 'pending'].includes(taskStatus);
  return {
    paused: boardStatus === 'paused',
    pulse: moving && taskStatus === 'running',
    edge(edge) {
      const matches = event => event.from === edge.source && event.to === edge.target && event.condition === edge.condition;
      const traversed = transitions.some(matches);
      return { traversed, active: Boolean(moving && latest && matches(latest) && latest.to === run.current) };
    },
  };
}
