import React, { useEffect, useState } from 'react';
import { normalizeModel } from '../src/execution-model.mjs';

export function TemplateSettingsView({ sessionId, monitor, subscribe, refresh, theme, onBack, onEdit, initialSelectedId }) {
  const [live, setLive] = useState(monitor), [selectedId, setSelectedId] = useState(initialSelectedId || 'template-3');
  const [target, setTarget] = useState('default'), [busy, setBusy] = useState(false), [error, setError] = useState(''), [notice, setNotice] = useState(''), [deleting, setDeleting] = useState(false);
  useEffect(() => subscribe(sessionId, 2000, setLive), [sessionId, subscribe]);
  const data = live?.data || {}, library = data.workflows || {}, templates = library.templates || [];
  const selected = templates.find(item => item.id === selectedId) || templates[0];
  const tasks = (data.board?.tasks || []).filter(task => task.status === 'pending' && task.executionEpoch === 0);
  const shared = (data.models?.length ? data.models.map(normalizeModel) : data.config?.members || []).filter(member => member.enabled !== false);
  const newDefinition = () => ({ id: 'new-template', name: '新模板', kind: 'dag', version: 1, entry: 'start', nodes: [{ id: 'start', label: '执行', mode: 'worker', memberId: shared[0]?.id, ...(shared[0] ? { modelConfig: normalizeModel(shared[0]), reviewerConfig: normalizeModel(shared[0]), reviewerId: shared[0].id } : {}), role: 'implementation', maxReworks: 2, timeoutMs: 0, position: { x: 80, y: 100 } }], edges: [] });
  const openEditor = (item, copy) => {
    setDeleting(false);
    onEdit({ templateId: copy ? null : item.id, expectedTemplatesRevision: library.templatesRevision, description: item.description || '', definition: { ...item, name: copy ? `${item.name} 副本` : item.name } });
  };
  const act = async (action, params) => {
    setBusy(true); setError(''); setNotice('');
    try {
      const response = await fetch('/api/lead-worker/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId, action, ...params }) });
      const result = await response.json(); if (!response.ok || !result.ok) throw new Error(result.error || `HTTP ${response.status}`);
      if (result.result?.templates) setLive(previous => ({ ...previous, data: { ...previous.data, workflows: { ...previous.data.workflows, ...result.result } } }));
      await refresh(sessionId); return result.result;
    } catch (err) { setError(err.message); return null; } finally { setBusy(false); }
  };
  const apply = async () => {
    const result = await act('workflowTemplateApply', { templateId: selected.id, target: target.startsWith('task:') ? 'task' : target, taskId: target.startsWith('task:') ? target.slice(5) : undefined, expectedTemplatesRevision: library.templatesRevision, expectedRevision: data.board?.revision });
    if (result) setNotice(target === 'default' ? '已设为当前会话后续新任务的默认流程；已有任务保持原流程。' : target === 'draft' ? '已载入当前会话草案，可前往流程画布继续编辑。' : '已应用到所选未启动任务。');
  };
  return <section className={`wf-workbench wf-template-settings ${theme}`} aria-label="模板设置">
    <header className="wf-template-heading"><div>{onBack && <button onClick={onBack}>‹ 返回设置</button>}<h2>模板设置</h2><p>内置流程与我的模板 · 在当前 DSH Profile 的会话间复用</p></div><button className="primary" disabled={busy || !shared.length || !Number.isSafeInteger(library.templatesRevision)} onClick={() => onEdit({ templateId: null, expectedTemplatesRevision: library.templatesRevision, description: '', definition: newDefinition() })}>新建模板</button></header>
    {(error || notice || live?.error) && <p className={`wf-template-notice ${error || live?.error ? 'error' : ''}`} role={error || live?.error ? 'alert' : 'status'}>{error || live?.error || notice}</p>}
    {!shared.length && <p>请先在 DSH 中配置至少一个可用模型，再创建或应用模板。</p>}
    <div className="wf-template-layout"><nav className="wf-template-list" aria-label="模板库">{['内置模板', '我的模板'].map((heading, index) => <section key={heading}><h3>{heading}</h3>{templates.filter(item => Boolean(item.builtin) === (index === 0)).map(item => <button key={item.id} aria-pressed={selected?.id === item.id} onClick={() => { setSelectedId(item.id); setDeleting(false); setNotice(''); }}><b>{item.name}</b><span>{item.nodes.length} 个节点 · v{item.version}</span></button>)}{index === 1 && !templates.some(item => !item.builtin) && <p>还没有自建模板。可以新建，也可以复制内置模板。</p>}</section>)}</nav>
      {selected ? <article className="wf-template-preview"><div className="wf-template-title"><div><span className="wf-template-tag">{selected.builtin ? '内置预设' : '我的模板'}</span><h3>{selected.name}</h3></div><span>v{selected.version}</span></div><p>{selected.description || '用户自定义流程，可修改节点模型、依赖与返工条件。'}</p>
        {selected.id === 'template-3' && <p className="wf-template-context">三省负责方案、审议与调度，六部各有职责，随后终验与汇报。此预设采用真实分支编排：方案审议后按需派发、依赖调度、汇合与定向返工。可复制后配置部门模型和审议上限。</p>}
        {selected.id === 'template-fullstack' && <p className="wf-template-context">需求审议通过后，架构师与 UI/UX 先交付契约和设计。前端等待二者，后端等待契约，两端完成后才联调与测试。默认完整分工；验收退回具体责任节点及其依赖后继，独立通过的分支保留。可复制后调整模型、Skill 和返工预算。</p>}
        <ol className="wf-template-steps">{selected.nodes.map(node => <li key={node.id}><b>{node.label}</b><span>{node.mode === 'worker' && node.modelSelection && node.modelSelection !== 'fixed' ? ({ task: '跟随任务难度', simple: '经济档模型', complex: '复杂档模型' })[node.modelSelection] : node.mode === 'worker' ? node.modelConfig ? `${node.modelConfig.provider} / ${node.modelConfig.model}` : data.config?.members?.find(member => member.id === node.memberId)?.name || `缺少旧模型配置：${node.memberId}` : node.mode === 'controller' ? '当前主控' : '主控模型独立执行'} · 返工 {node.maxReworks} 次{node.timeoutMs ? ` · ${node.timeoutMs / 1000} 秒` : ''}</span></li>)}</ol>
        <div className="wf-template-edit-actions"><button disabled={busy} onClick={() => openEditor(selected, true)}>复制并编辑</button>{!selected.builtin && <><button disabled={busy} onClick={() => openEditor(selected, false)}>编辑模板</button><button className="danger" disabled={busy} onClick={() => setDeleting(!deleting)}>删除模板</button></>}{data.board?.workflowDraft && <button disabled={busy} onClick={() => openEditor({ ...data.board.workflowDraft, description: '从当前会话流程创建' }, true)}>从当前流程创建</button>}</div>
        {deleting && <div className="wf-template-delete" role="group" aria-label="确认删除模板"><p>删除“{selected.name}”？已应用到任务的流程副本会保留。</p><button className="danger" disabled={busy} onClick={async () => { if (await act('workflowTemplateDelete', { templateId: selected.id, expectedTemplatesRevision: library.templatesRevision })) { setDeleting(false); setSelectedId('template-3'); setNotice('模板已删除。'); } }}>确认删除</button><button onClick={() => setDeleting(false)}>取消</button></div>}
        <div className="wf-template-apply"><label>应用到<select aria-label="应用到" value={target} onChange={e => setTarget(e.target.value)}><option value="default">当前会话后续新任务</option><option value="draft">当前会话流程草案</option>{tasks.map(task => <option key={task.id} value={`task:${task.id}`}>未启动任务：{task.title}</option>)}</select></label><button className="primary" disabled={busy || !shared.length || !data.config?.enabled || !Number.isSafeInteger(data.board?.revision)} onClick={apply}>{busy ? '处理中…' : '应用模板'}</button><p>保存模板供复用；应用模板才会改变选定目标。已有运行任务不会被替换。</p></div>
      </article> : <p>正在读取模板库…</p>}
    </div>
  </section>;
}
