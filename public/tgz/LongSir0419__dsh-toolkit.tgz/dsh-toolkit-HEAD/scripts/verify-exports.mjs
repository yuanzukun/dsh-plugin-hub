import { createRequire } from 'node:module';
// Simulate client-modules resolution from the toolkit package root
const req = createRequire('file:///D:/PROJECT/dsh-toolkit/');
const specs = [
  '@wanghailong0419/dsh-toolkit/mcp/package.json',
  '@wanghailong0419/dsh-toolkit/skill/package.json',
  '@wanghailong0419/dsh-toolkit/branch/package.json',
];
for (const spec of specs) {
  try {
    const p = req.resolve(spec);
    console.log('OK ', spec, '->', p);
  } catch (e) {
    console.log('FAIL', spec, '->', e.code || e.message);
  }
}
// also check root exports still resolve for host side
for (const spec of ['@wanghailong0419/dsh-toolkit/mcp', '@wanghailong0419/dsh-toolkit/skill', '@wanghailong0419/dsh-toolkit/branch']) {
  try {
    const p = req.resolve(spec);
    console.log('OK ', spec, '->', p);
  } catch (e) {
    console.log('FAIL', spec, '->', e.code || e.message);
  }
}
