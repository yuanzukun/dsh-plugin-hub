import { readFileSync } from 'node:fs';
for (const rel of ['lib/mcp/client.js', 'lib/skill/client.js', 'lib/branch/client.js']) {
  const p = 'D:/PROJECT/dsh-toolkit/' + rel;
  const text = readFileSync(p, 'utf8');
  const loadIds = [...text.matchAll(/__ModuleLoader__\.load\(\{[\s\S]*?id:\s*"(@[^"]+)"/g)].map((m) => m[1]);
  console.log(rel, Buffer.byteLength(text), 'bytes; load ids:', JSON.stringify(loadIds));
  // ensure the trailing forward block exists (toolkit/<name>)
  const hasForward = text.includes('exports.apply');
  console.log('  has apply forward:', hasForward, '| tail:', JSON.stringify(text.slice(-80)));
}
// cross-file duplicate check
const all = [];
for (const rel of ['lib/mcp/client.js', 'lib/skill/client.js', 'lib/branch/client.js']) {
  const text = readFileSync('D:/PROJECT/dsh-toolkit/' + rel, 'utf8');
  for (const m of text.matchAll(/__ModuleLoader__\.load\(\{[\s\S]*?id:\s*"(@[^"]+)"/g)) all.push(m[1]);
}
const dup = [...new Set(all.filter((x, i) => all.indexOf(x) !== i))];
console.log('cross-file duplicate load ids:', JSON.stringify(dup));
