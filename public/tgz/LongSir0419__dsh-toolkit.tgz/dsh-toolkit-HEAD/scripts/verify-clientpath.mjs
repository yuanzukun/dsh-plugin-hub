import { createRequire } from 'node:module';
import { join, dirname } from 'node:path';
import { readFileSync } from 'node:fs';

// Simulate client-modules resolveMeta from the PROFILE root (ctx.baseUrl = profile dir)
// In a real install the toolkit is at profile/node_modules/@wanghailong0419/dsh-toolkit.
// We can't easily simulate nested resolution without installing, so instead verify the
// clientPath computation for each subpath using the virtual package.json as the pkgPath:
const base = 'D:/PROJECT/dsh-toolkit/lib';
for (const member of ['mcp', 'skill', 'branch']) {
  const pkgPath = `${base}/${member}/package.json`;
  const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
  const clientRel = pkg.exports['./client'];
  const clientPath = join(dirname(pkgPath), clientRel);
  console.log(member, '| pkgPath:', pkgPath, '| clientRel:', clientRel, '| clientPath:', clientPath);
  // what dsh.client inject does the virtual package declare?
  console.log('   dsh.client.inject:', JSON.stringify(pkg.dsh?.client?.inject));
  console.log('   platform:', pkg.dsh?.client?.platform);
}
