import { readFileSync, writeFileSync } from 'node:fs';
const p = 'C:/Users/15354/.dsh/profiles/web/package.json';
let t = readFileSync(p, 'utf8');
// The file tail contains the literal two-char sequence backslash + n ("\\n" escaped once).
// Inspect the tail first, then rebuild the JSON cleanly from parsed values.
console.log('tail repr:', JSON.stringify(t.slice(-40)));
// Try to parse; if it fails due to trailing literal \n, strip it.
let j;
try { j = JSON.parse(t); }
catch (e) {
  const cleaned = t.replace(/\\n\s*$/, '').trim();
  console.log('cleaned tail repr:', JSON.stringify(cleaned.slice(-20)));
  j = JSON.parse(cleaned);
}
console.log('deps:', Object.keys(j.dependencies).join(','));
console.log('bundles:', j.dsh.profile.bundles.join(','));
writeFileSync(p, JSON.stringify(j, null, 2) + '\n', 'utf8');
console.log('rewritten OK; new length:', readFileSync(p, 'utf8').length);
