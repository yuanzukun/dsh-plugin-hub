const tabs = await fetch('http://127.0.0.1:9224/json').then((r) => r.json());
const tab = tabs.find((t) => t.url.includes('127.0.0.1:3100'));
if (!tab) { console.log('3100 tab not found'); process.exit(1); }
console.log('tab:', tab.url);
const ws = new WebSocket(tab.webSocketDebuggerUrl);
let id = 0;
const pending = new Map();
const events = [];
const send = (method, params = {}) => new Promise((resolve) => {
  const msgId = ++id;
  pending.set(msgId, resolve);
  ws.send(JSON.stringify({ id: msgId, method, params }));
});
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
  else if (msg.method) events.push(msg);
};
await new Promise((res) => (ws.onopen = res));
await send('Runtime.enable');
await send('Log.enable');
await send('Console.enable');
await send('Page.enable');

// reload to capture boot-time errors with the NEW toolkit structure
await send('Page.reload', { ignoreCache: true });
await new Promise((r) => setTimeout(r, 15000));

const errs = events.filter((e) => {
  if (e.method === 'Runtime.exceptionThrown') return true;
  if (e.method === 'Runtime.consoleAPICalled' && e.params.type === 'error') return true;
  if (e.method === 'Log.entryAdded' && e.params.entry.level === 'error') return true;
  return false;
});
console.log('=== ERRORS AFTER RELOAD (' + errs.length + ') ===');
for (const e of errs.slice(0, 30)) {
  try {
    if (e.method === 'Runtime.exceptionThrown') {
      const d = e.params.exceptionDetails;
      console.log('EXC:', d?.text, '|', (d?.exception?.description ?? '').split('\n').slice(0, 3).join(' | '));
    } else if (e.method === 'Runtime.consoleAPICalled') {
      const args = (e.params.args || []).map((a) => a.value ?? a.description ?? a.type).join(' ');
      console.log('CONSOLE[error]:', args.slice(0, 250));
    } else if (e.method === 'Log.entryAdded') {
      console.log('LOG[error]:', e.params.entry.text.slice(0, 250));
    }
  } catch {}
}

// DOM state
const dom = await send('Runtime.evaluate', {
  expression: `(() => {
    const out = {};
    out.branchBadge = document.querySelectorAll('.hm-branch-badge').length;
    out.heroPreset = document.querySelectorAll('.hm-hero-preset-branch').length;
    out.branchMenu = document.querySelectorAll('.hm-branch-menu').length;
    out.bootRev = (globalThis.__DSH_BOOT__ || {}).rev;
    out.bootEntries = (globalThis.__DSH_BOOT__?.entries || []).map(e => e.id).filter(x => /wanghailong/.test(x));
    return JSON.stringify(out, null, 1);
  })()`,
  returnByValue: true,
});
console.log('=== DOM ===');
console.log(dom.result?.result?.value ?? JSON.stringify(dom, null, 1));
ws.close();
process.exit(0);
