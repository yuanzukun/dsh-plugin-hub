import { createRequire } from 'node:module';
const req = createRequire('file:///C:/Users/15354/.dsh/profiles/web/');
for (const s of [
  '@wanghailong0419/dsh-toolkit/mcp/package.json',
  '@wanghailong0419/dsh-toolkit/skill/package.json',
  '@wanghailong0419/dsh-toolkit/branch/package.json',
  '@wanghailong0419/dsh-toolkit/mcp',
  '@wanghailong0419/dsh-toolkit/skill',
  '@wanghailong0419/dsh-toolkit/branch',
]) {
  try { console.log('OK  ', s, '->', req.resolve(s)); }
  catch (e) { console.log('FAIL', s, '->', e.code || e.message); }
}
