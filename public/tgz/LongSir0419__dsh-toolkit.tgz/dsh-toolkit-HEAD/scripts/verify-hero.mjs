const tabs = await fetch('http://127.0.0.1:9224/json').then((r) => r.json());
const tab = tabs.find((t) => t.url.includes('127.0.0.1:3100'));
const ws = new WebSocket(tab.webSocketDebuggerUrl);
let id = 0;
const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => {
  const msgId = ++id;
  pending.set(msgId, resolve);
  ws.send(JSON.stringify({ id: msgId, method, params }));
});
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
};
await new Promise((res) => (ws.onopen = res));
await send('Runtime.enable');

// Check whether the hero view's BranchBadge made a remote call; if the page is on the
// blank hero (no session), the badge returns null by design. Check if there is any way to
// see a session header — the GUI may need a workspace + session. First inspect what's rendered
// and whether a workspace picker exists.
const evalRes = await send('Runtime.evaluate', {
  expression: `(() => {
    const out = {};
    const hero = document.querySelector('.hm-hero-preset-branch');
    out.heroHTML = hero ? hero.outerHTML.slice(0, 400) : null;
    // body text around workspace / session
    const txt = document.body.innerText;
    out.bodyStart = txt.slice(0, 400);
    out.workspaceNames = [...document.querySelectorAll('*')].filter(el => /workspace/i.test(el.className||'') || /Workspace/i.test(el.textContent||'')).length;
    return JSON.stringify(out, null, 1);
  })()`,
  returnByValue: true,
});
console.log(evalRes.result?.result?.value ?? JSON.stringify(evalRes, null, 1));
ws.close();
process.exit(0);
