const tabs = await fetch('http://127.0.0.1:9224/json').then((r) => r.json());
const tab = tabs.find((t) => t.url.includes('127.0.0.1:3100'));
const ws = new WebSocket(tab.webSocketDebuggerUrl);
let id = 0;
const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => {
  const msgId = ++id;
  pending.set(msgId, resolve);
  ws.send(JSON.stringify({ id: msgId, method, params }));
});
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
};
await new Promise((res) => (ws.onopen = res));
await send('Runtime.enable');

// The cordis client ctx isn't on window, but the boot graph + slot registrations might be
// reachable through the module system. Try to find evidence that the branch client module
// was materialized and its apply() ran: look for the injected styles (data-plugin attr) and
// the hm CSS classes in <style> tags, plus any window.__DSH_BOOT__ slots info.
const evalRes = await send('Runtime.evaluate', {
  expression: `(() => {
    const out = {};
    out.styles = [...document.querySelectorAll('style[data-plugin]')].map(s => s.getAttribute('data-plugin') + ':' + (s.getAttribute('data-plugin-css')||'').slice(0,40));
    out.hmStyles = [...document.querySelectorAll('style')].filter(s => /hm-branch|hm-hero/.test(s.textContent)).length;
    out.hasBranchCss = [...document.querySelectorAll('style')].some(s => /hm-branch-badge/.test(s.textContent));
    out.moduleLoader = typeof window.__ModuleLoader__;
    return JSON.stringify(out, null, 1);
  })()`,
  returnByValue: true,
});
console.log(evalRes.result?.result?.value ?? JSON.stringify(evalRes, null, 1));
ws.close();
process.exit(0);
