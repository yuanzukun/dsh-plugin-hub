import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const src = 'D:/PROJECT/dsh-toolkit/lib/client.js';
const text = readFileSync(src, 'utf8');

// locate load blocks
const blocks = [];
const re = /window\.__ModuleLoader__\.load\(\{/g;
let m;
while ((m = re.exec(text)) !== null) {
  const start = m.index;
  const head = text.slice(start, start + 200);
  const idm = head.match(/id:\s*"(@[^"]+)"/);
  blocks.push({ start, id: idm ? idm[1] : '?' });
}
for (let i = 0; i < blocks.length; i++) {
  blocks[i].end = i + 1 < blocks.length ? blocks[i + 1].start : text.length;
}
console.log('blocks:', blocks.map((b) => `${b.id}@${b.start}-${b.end}`).join('\n'));

const byId = (id) => blocks.find((b) => b.id === id);
const full = (id) => text.slice(byId(id).start, byId(id).end);
const HEADER = (member) => `// dsh-toolkit: client half for the ${member} member bundle.
// Standalone bundle served per loader entry (no shared aggregate file, so the
// browser never re-registers a factory). Regenerate from lib/client.js segments.
`;

const files = {
  'lib/mcp/client.js': HEADER('dsh-mcp-manager') + full('@wanghailong0419/dsh-mcp-manager') + '\n' + full('@wanghailong0419/dsh-toolkit/mcp'),
  'lib/skill/client.js': HEADER('dsh-skill-manager') + full('@wanghailong0419/dsh-skill-manager') + '\n' + full('@wanghailong0419/dsh-toolkit/skill'),
  'lib/branch/client.js': HEADER('dsh-git-branch-manage') + full('@wanghailong0419/dsh-git-branch-manage') + '\n' + full('@wanghailong0419/dsh-toolkit/branch'),
};

for (const [rel, content] of Object.entries(files)) {
  const p = 'D:/PROJECT/dsh-toolkit/' + rel;
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, content, 'utf8');
  console.log('wrote', rel, Buffer.byteLength(content), 'bytes');
}
