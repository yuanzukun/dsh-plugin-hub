# dsh-toolkit

[English](README.md) | [中文](README_CN.md)

A DeepSeek Harness (DSH) plugin toolkit — **install three essential plugins with one command**: MCP Manager, Skill Manager, and Git Branch Badge. Ready to use right after install; the settings page automatically gains **MCP Manager** and **Skill Manager** sections, and the session header / new-session hero gain a **Git branch badge**.

[![npm](https://img.shields.io/npm/v/@wanghailong0419/dsh-toolkit)](https://www.npmjs.com/package/@wanghailong0419/dsh-toolkit)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![dshbase 实测可装](https://dshbase.com/badges/wanghailong0419-dsh-toolkit.svg)](https://dshbase.com/zh/plugins/wanghailong0419-dsh-toolkit/)
[![Listed on dsh-plugin.org](https://dsh-plugin.org/badges/listed.svg)](https://dsh-plugin.org/zh/plugins/longsir0419/dsh-toolkit)
[![DSH Market](https://raw.githubusercontent.com/2BingLing/dsh-market/master/assets/readme/badge-listed-en.svg)](https://dsh.market/)

## Screenshots

| MCP Manager | Skill Manager |
|---|---|
| ![mcp](docs/preview_mcp.png) | ![skill](docs/preview_skill.png) |

## Screenshots (branch)

| Git Branch Badge | Branch menu |
|---|---|
| ![branch](docs/preview_branch_badge.png) | ![branch-menu](docs/preview_branch_menu.png) |

## Features

### 🧩 MCP Manager — Settings → MCP Manager
- **List overview**: each server shows connection status (green dot) + registered tool count
- **Click to expand / collapse**: click anywhere on a row to expand details (Server name / module / config JSON), click again to collapse (input fields and buttons excluded)
- **Add / edit / delete / rename / enable-disable**: inline form to configure MCP servers, enable/disable toggle, writes to `$DSH_HOME/profiles/web/cordis.patch.yml`
- **Connection test**: independent MCP handshake (initialize + tools/list) to verify reachability, tool count and latency
- **Cache optimization**: re-entering the page is instant (stale-while-revalidate); add/edit/delete updates state locally without flicker

### 🎯 Skill Manager — Settings → Skill Manager
- **List overview**: lists all Skills under `$DSH_HOME/skills` (name + description)
- **Click to expand / collapse**: click anywhere on a row to expand details (Skill name + SKILL.md content)
- **Edit / rename / add / delete**: inline editing of name and content; rename syncs the directory name; delete has a confirmation step
- **Enable / disable**: toggle takes effect immediately; disabling adds `disable-model-invocation: true` to the frontmatter and the watcher instantly excludes it from the model directory — no restart needed

### 🌿 Git Branch Badge — session header & new-session hero
- **Current branch badge**: shows the active git branch in the conversation header (and on the new-session welcome page); follows the workspace/directory you select
- **Branch menu**: click the badge to switch / create / pull / fetch / push / delete local branches (IDEA-style tree, 7-day active branches)
- **Workspace-aware**: the hero badge tracks the currently selected directory; the header badge tracks the open session's working directory

## Installation

```bash
dsh plugin --profile web add @wanghailong0419/dsh-toolkit
dsh web   # restart to take effect
```

## Included Packages

| Package | Version | Entry |
|---|---|---|
| [@wanghailong0419/dsh-mcp-manager](https://github.com/LongSir0419/dsh-mcp-manager) | ^0.1.3 | Settings → **MCP Manager** |
| [@wanghailong0419/dsh-skill-manager](https://github.com/LongSir0419/dsh-skill-manager) | ^0.1.4 | Settings → **Skill Manager** |
| [@wanghailong0419/dsh-git-branch-manage](https://github.com/LongSir0419/dsh-git-branch-manage) | ^0.1.3 | Session header → **Branch badge** |

## Install Individually / Remove

```bash
# Install individually
dsh plugin --profile web add @wanghailong0419/dsh-mcp-manager
dsh plugin --profile web add @wanghailong0419/dsh-skill-manager

# Remove the whole toolkit
dsh plugin --profile web remove @wanghailong0419/dsh-toolkit

# Upgrade
dsh plugin --profile web update @wanghailong0419/dsh-toolkit
```

## License

MIT
