// 动作平面测试：node test/ops.test.mjs
// 验收（设计笔记）：喂本会话那 7 次真实工具调用，输出里不许出现 `dcterms` 这类标识符。
import assert from 'node:assert/strict'

import {
  FALLBACK_OPS,
  OP_IDS,
  WEAK_OPS,
  activityFromCalls,
  activityFromText,
  classifyShellCommand,
  classifyToolCall,
  opForLegacyAction,
} from '../src/ops.js'
import { extractPathTokens } from '../src/util/path-token.js'

let passed = 0
const ok = (name) => {
  passed++
  console.log('  ok', name)
}

// --- 1. 工具名 → op，写目标必须是**值**不是键名（曾把 file_path 当成路径） ---
{
  const w = classifyToolCall('edit', '{"file_path":"src/readiness.js"}')
  assert.deepEqual(w.ops, ['file-write'])
  assert.deepEqual(w.targets, ['src/readiness.js'])
  const read = classifyToolCall('read', '{"file_path":"src/readiness.js"}')
  assert.deepEqual(read.ops, [], '读不是写：不产出 op（也不产出写目标）')
  assert.deepEqual(read.targets, [])
  assert.deepEqual(classifyToolCall('read_image', '{"file_path":"a.png"}').ops, ['read-image'])
  assert.deepEqual(classifyToolCall('index_repo', '{"root":"/x"}').ops, ['index-doc'])
  assert.deepEqual(classifyToolCall('web_fetch', '{"url":"https://x"}').ops, ['fetch-web'])
  ok('classifyToolCall：写/读/索引/取网页各自归一，写目标取参数值')
}

// --- 2. shell 命令 → op：只认渲染器，不认扩展名 ---
{
  assert.ok(classifyShellCommand('npm publish --access public').ops.includes('npm-publish'))
  assert.ok(classifyShellCommand('git tag v0.5.6').ops.includes('release'))
  assert.ok(classifyShellCommand('git commit -am x').ops.includes('git-commit'))
  assert.ok(classifyShellCommand('rm -rf build/').ops.includes('file-delete'))
  assert.ok(classifyShellCommand('node scripts/bench.mjs').ops.includes('run-bench'))
  assert.deepEqual(classifyShellCommand('soffice --headless --convert-to pdf').ops, ['render-doc'])
  assert.deepEqual(classifyShellCommand('npx pptxgenjs build.js').ops, ['render-doc'])
  // 关键回归：只是"提到一个 .pptx"（改时间戳那次就是这么干的）绝不能算 render-doc
  assert.deepEqual(classifyShellCommand('ls -la /mnt/c/x/deck.pptx').ops, ['shell-run'])
  assert.deepEqual(classifyShellCommand('python3 - <<PY zipfile deck.pptx TotalTime PY').ops, ['shell-run'])
  ok('classifyShellCommand：渲染器才算 render-doc，扩展名不算')
}

// --- 2b. 误命中回归：目录名 / grep pattern / 引号 / heredoc / 脚本正文里的词都不是动作 ---
// 这一组全部来自 2026-10-25 的真实会话（一个审计任务，含 4 个子代理）：
// `find … bench …` 命中 run-bench 注入了 4 条基准 procedure、1777 字符；
// 子代理提示词里的"删除/迁移"让父会话连吃 8 步 file-delete/migrate。
{
  assert.deepEqual(
    classifyShellCommand('find src client test scripts bench docs -type f | head -100').ops,
    ['shell-run'], '目录名 bench 不是"跑基准"',
  )
  assert.deepEqual(classifyShellCommand('grep -rn "migrate" docs | head').ops, ['shell-run'], 'grep pattern 不是"迁移"')
  assert.deepEqual(classifyShellCommand('grep -rn "bench" src').ops, ['shell-run'], 'grep pattern 不是"跑基准"')
  assert.deepEqual(
    classifyShellCommand('node -e "const fs=require(\'fs\');fs.mkdirSync(\'/tmp/x\');fs.readFileSync(\'src/index.js\')"').targets,
    [], 'node -e 的脚本正文不是写目标',
  )
  assert.deepEqual(classifyShellCommand('echo "a > b"').targets, [], '引号里的 > 不是重定向')
  assert.deepEqual(classifyShellCommand('git commit -m "fix rm and migrate bugs"').ops, ['git-commit'], '提交信息里的词不是动作')
  assert.deepEqual(classifyShellCommand('bash -c "npm publish"').ops, ['npm-publish'], 'bash -c 要递归一层')
  assert.deepEqual(classifyShellCommand('cd x && rm -rf build').ops, ['file-delete'], '分段后第二段仍要认 rm')
  assert.deepEqual(
    classifyShellCommand('python3 - <<PY\nimport os\nos.system("rm -rf x")\nPY').ops,
    ['shell-run'], 'heredoc 正文不是 shell 命令',
  )
  ok('命令头匹配：路径 / pattern / 引号 / heredoc / 脚本正文里的词不算动作')
}

// --- 3. 写目标只从会写盘的命令里取；读列目录不产目标 ---
{
  assert.deepEqual(classifyShellCommand('ls -la notes.md').targets, [])
  assert.deepEqual(classifyShellCommand('rm -f notes.md').targets, ['notes.md'])
  // 点开头的裸文件名同样是写目标。ops 原先只顾「带扩展名的路径」，把这一类漏了，
  // 而 ops.targets 正是 when.writes 的匹配面 —— 漏掉等于一条 writes:['.gitignore']
  // 的教训静默漏召（实测 rm -f .gitignore 曾抽出 targets=[]）。语义已与 readiness 收敛为同源。
  assert.deepEqual(classifyShellCommand('rm -f .gitignore').targets, ['.gitignore'])
  assert.deepEqual(classifyShellCommand('echo x >> .npmrc').targets, ['.npmrc'])
  assert.deepEqual(classifyShellCommand('touch .eslintrc').targets, ['.eslintrc'])
  // 刻意的边界：点文件只认 token 起始处。中缀的 `src/.env` 与普通点号无法区分，
  // 不在文本抽取规则内（调用方已知完整路径时应直接并入 path，而不是指望从这里猜）。
  assert.deepEqual(classifyShellCommand('sed -i s/a/b/ src/.env').targets, [])
  // 丢弃输出的重定向不是写盘：`2>/dev/null` / `2>&1` 是读命令最常见的写法，旧判据
  // (`>>?\s*\S`) 会把它们连同命令里**任意**路径一起算成写目标 —— 实测
  // `ls .agents 2>/dev/null | head` → ['.agents']、`cat package.json 2>&1` → ['package.json']，
  // 而 targets 正是 when.writes 的匹配面，于是"看一眼"会误触发"要改它"的教训。
  assert.deepEqual(classifyShellCommand('ls .agents 2>/dev/null | head').targets, [])
  assert.deepEqual(classifyShellCommand('cat package.json 2>&1 | grep version').targets, [])
  assert.deepEqual(classifyShellCommand('node script.mjs 2>/dev/null').targets, [])
  assert.deepEqual(classifyShellCommand('grep -r x . >/dev/null 2>&1').targets, [])
  // 但真的写文件仍然要算：> / >> / 2> / 1>> 都保留
  assert.deepEqual(classifyShellCommand('cat a.md > out.md').targets, ['a.md', 'out.md'])
  assert.deepEqual(classifyShellCommand('printf x 1>>notes.md').targets, ['notes.md'])
  assert.deepEqual(classifyShellCommand('make 2>build.log').targets, ['build.log'])
  const wsl = classifyShellCommand('powershell.exe -Command SetFileTime /mnt/c/x/a.pptx')
  assert.deepEqual(wsl.hosts, ['wsl'], '命令里出现 /mnt/* 或 powershell.exe → host=wsl')
  ok('写目标只来自写盘命令（含点开头文件名）；WSL 主机可被识别')
}

// --- 3b. 共享路径 token 模块：边缘输入、去重与顺序确定 ---
// 规则是 readiness 与 ops **同一份实现**（src/util/path-token.js），这里把边缘输入钉死。
{
  assert.deepEqual(extractPathTokens(''), [])
  assert.deepEqual(extractPathTokens(null), [])
  assert.deepEqual(extractPathTokens(undefined), [])
  assert.deepEqual(extractPathTokens('   '), [])
  assert.deepEqual(extractPathTokens('a.md a.md'), ['a.md'], '去重')
  // 顺序确定：先「带扩展名」、后「点开头」，各自按出现顺序
  assert.deepEqual(extractPathTokens('.gitignore src/a.js .env'), ['src/a.js', '.gitignore', '.env'])
  assert.deepEqual(extractPathTokens('v1.10 版本'), [], '版本号的点后面是数字，不是扩展名')
  assert.deepEqual(extractPathTokens('.env'), ['.env'])
  assert.deepEqual(extractPathTokens('.x'), [], '点文件名至少要 2 个字符（.x 不是文件名）')
  ok('extractPathTokens：空/缺失/去重/顺序/版本号与点文件名边界')
}

// --- 4. 本会话那 7 次真实调用的回归：不产出标识符类噪音 ---
{
  const sessionCalls = [
    { name: 'bash', arguments: '{"command":"date; ls -la --time-style=full-iso \\"/mnt/c/Users/me/OneDrive/桌面/示例调研.pptx\\""}' },
    { name: 'bash', arguments: '{"command":"which powershell.exe pwsh.exe"}' },
    { name: 'bash', arguments: '{"command":"powershell.exe -NoProfile -Command \\"$f.CreationTime = ...\\" -Filter \\"*.pptx\\""}' },
    { name: 'bash', arguments: '{"command":"python3 - <<\'PY\'\\nimport zipfile, re\\napp = zin.read(\'docProps/app.xml\')\\ndcterms = None\\nPY"}' },
    { name: 'bash', arguments: '{"command":"ls -la /tmp/pptx-backup.pptx"}' },
    { name: 'bash', arguments: '{"command":"node --test test/insight-store.test.mjs"}' },
    { name: 'read', arguments: '{"file_path":"/repo/notes.md"}' },
  ]
  const a = activityFromCalls(sessionCalls)
  const dump = JSON.stringify(a)
  // 这些字符串出现过，但它们不是动作、也不是写目标——出现过不等于做过
  for (const noise of ['dcterms', 'rm', 'pptx"', 'docProps']) {
    assert.ok(!dump.includes(noise), `动作平面不该出现 ${noise}：${dump}`)
  }
  assert.ok(a.ops.every((op) => OP_IDS.includes(op)), `op 必须落在闭集内：${a.ops}`)
  assert.ok(a.targets.every((t) => /[./]/.test(t)), `写目标应当是路径形态：${a.targets}`)
  assert.ok(a.hosts.includes('wsl'))
  ok(`本会话 7 次调用的动作平面：ops=${JSON.stringify(a.ops)} targets=${JSON.stringify(a.targets)}`)
}

// --- 5. actionText 兜底：能解析 `edit {json}` 与裸命令 ---
{
  const a = activityFromText('edit {"file_path":"src/a.js"}\ngit commit -m x\nnpm publish')
  assert.ok(a.ops.includes('file-write') && a.ops.includes('git-commit') && a.ops.includes('npm-publish'))
  assert.ok(a.targets.includes('src/a.js'))
  // 纯文本行不该退化成 shell-run（那是噪音源）
  assert.ok(!activityFromText('这是一句普通的话').ops.includes('shell-run'))
  assert.deepEqual(activityFromText('这是一句普通的话').targets, [])
  // 丢掉噪音 op ≠ 丢掉整行的事实：写目标要靠路径 token 这种具体签名才抽得出，
  // 泛泛散文产不出来，所以 shell-run-only 的行仍要留下写目标。
  // 结构化行更明显：`bash {"command":"echo x >> .gitignore"}` 曾连写目标一起被吞。
  const structured = activityFromText('bash {"command":"echo x >> .gitignore"}')
  assert.deepEqual(structured.ops, [], '没有 shell 动作规则命中时不产出 shell-run')
  assert.deepEqual(structured.targets, ['.gitignore'], '结构化调用行的写目标不得连带丢失')
  const bare = activityFromText('cp .env .env.bak')
  assert.deepEqual(bare.ops, [])
  assert.deepEqual(bare.targets.sort(), ['.env', '.env.bak'])
  ok('activityFromText：工具调用行与裸命令都能读；噪音 op 不带走写目标')
}

// --- 6. 旧 action → op 映射：死值显式返回 null（供自检报出来）---
{
  assert.equal(opForLegacyAction('npm-pack'), 'npm-publish')
  assert.equal(opForLegacyAction('generate-pptx'), 'render-doc')
  assert.equal(opForLegacyAction('benchmark'), 'run-bench')
  assert.equal(opForLegacyAction('cleanup'), 'file-delete')
  assert.equal(opForLegacyAction('recover'), null)
  assert.equal(opForLegacyAction('interview-prep'), null)
  assert.equal(opForLegacyAction('git-commit'), 'git-commit')
  assert.ok(WEAK_OPS.has('git-commit') && WEAK_OPS.has('shell-run'))
  assert.ok(FALLBACK_OPS.has('file-write') && !FALLBACK_OPS.has('git-commit'))
  ok('opForLegacyAction：旧值有归宿，死值返回 null 交给自检')
}

console.log(`\nops tests: ${passed} passed`)
