// 就绪引擎（push 侧）：trigger 推广到所有 insight kind + 两个窗口 + 预算排程 —— PR2
//   node test/readiness.test.mjs
//
// 设计口径：recall 回答"记忆里有什么和这件事有关"，readiness 回答"动手之前必须知道什么"。
// 交付契约：**authored trigger = 确定性注入（优先级 1）；统计信号 = 提示态（优先级 2）**。
// 动机：实测中人类消息"你顺便提交一下"对那条 lesson 的 overlap 只有 0.014（阈值 0.25），
// 所以这次提交之前它从未到达。本文件把那个数字钉成回归。
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { GlobalStore, cfgInsight } from '../src/insight-store.js'
import { buildInjection, cfgEngine } from '../src/auto-inject.js'

let passed = 0
const ok = (name) => {
  passed++
  console.log('  ok', name)
}

// PR2 新增模块：修前不存在 → 依赖它的断言必须红。
let readiness = null
try {
  readiness = await import('../src/readiness.js')
} catch {
  readiness = null
}

function globalWith(items) {
  const file = path.join(mkdtempSync(path.join(tmpdir(), 'ready-')), 'global.json')
  const gs = new GlobalStore(file).load()
  gs.doc.items.push(...items)
  return gs
}

const CFG = cfgEngine({ insight: {}, autoContext: { maxTokens: 400 } })

// 动机场景：一条 **lesson**（不是 procedure）+ 人说要提交
const PUBLIC_FACE = {
  id: 'ins_pub',
  kind: 'lesson',
  scope: 'global',
  title: '公开作品仓库的「公开面」不止文件清单',
  fix: '内部文档一律写进 .gitignore；公开前扫描 src/ test/ CHANGELOG',
  trigger: { keywords: ['公开', '内部文档', '泄漏'], actions: ['git-commit'] },
  confidence: 1,
  archived: false,
}

// ---- 1. 动作词典：人类意图也算动作 ----
{
  assert.ok(readiness, 'src/readiness.js 不存在：trigger 还只服务 procedure')
  assert.ok(readiness.detectActions('你顺便提交一下，参考记忆里的提交注意').includes('git-commit'), '意图词"提交"→ git-commit')
  assert.ok(readiness.detectActions('npm publish --access public').includes('npm-publish'))
  assert.ok(readiness.detectActions('先把仓库公开').includes('go-public'))
  assert.equal(readiness.detectActions('今天天气不错').length, 0)
  ok('detectActions：人类意图词与命令都归一成动作 id')
}

// ---- 2. 路径抽取 ----
{
  assert.ok(readiness, 'src/readiness.js 不存在')
  const paths = readiness.extractPaths('git add README.md CHANGELOG.md && npm pack')
  assert.ok(paths.includes('README.md'), `应抽到 README.md：${paths}`)
  assert.ok(paths.includes('CHANGELOG.md'))
  // 点开头的裸文件名也要抽到。这一类原先只有 readiness 有，ops 那份副本漏了，
  // 两份注释却写着"同规则" —— 现在收在 util/path-token.js，是同一份实现。
  const dotted = readiness.extractPaths('rm -f .gitignore && cp .env .env.bak')
  for (const p of ['.gitignore', '.env', '.env.bak']) assert.ok(dotted.includes(p), `应抽到 ${p}：${dotted}`)
  const { extractPathTokens } = await import('../src/util/path-token.js')
  for (const t of ['git add README.md', 'rm -f .gitignore', '.env', '']) {
    assert.deepEqual(readiness.extractPaths(t), extractPathTokens(t), `必须与共享规则同源：${JSON.stringify(t)}`)
  }
  ok('extractPaths：从工具参数里抽路径 token（含点开头文件名，与共享规则同源）')
}

// ---- 3. matchTrigger：准入化后的三类判据（op / write / intent）+ 旧 trigger 不再触发 ----
{
  assert.ok(readiness, 'src/readiness.js 不存在')
  const ctx = readiness.buildReadinessContext({
    humanText: '你顺便提交一下，注意别泄漏内部文档',
    actionText: 'edit {"file_path":"/repo/README.md"}',
    ops: ['git-commit'],
    targets: ['README.md'],
  })
  // when 的三类判据（取或）
  assert.match(readiness.matchTrigger({ when: { ops: ['git-commit'] } }, ctx) || '', /^op:/)
  assert.match(readiness.matchTrigger({ when: { writes: ['README.md'] } }, ctx) || '', /^write:/)
  assert.match(readiness.matchTrigger({ when: { intents: ['内部文档'] } }, ctx) || '', /^intent:/)
  // guard 只能收窄
  assert.equal(readiness.matchTrigger({ when: { ops: ['git-commit'] }, guard: { paths: ['package.json'] } }, ctx), null)
  assert.equal(readiness.matchTrigger({ when: { ops: ['git-commit'] }, guard: { not_paths: ['README.md'] } }, ctx), null)
  assert.match(readiness.matchTrigger({ when: { ops: ['git-commit'] }, guard: { paths: ['README.md'] } }, ctx) || '', /^op:/)
  // 扩展名/泛名 glob 在 writes 里被硬性忽略（它们只能撒谎）
  assert.equal(readiness.matchTrigger({ when: { writes: ['*.pptx'] } }, ctx), null)
  assert.equal(readiness.matchTrigger({ when: { writes: ['README*'] } }, ctx), null)
  // 旧 trigger（没有 when）不再触发任何东西——这是 S2 的核心语义变更
  assert.equal(readiness.matchTrigger({ keywords: ['内部文档'] }, ctx), null)
  assert.equal(readiness.matchTrigger({ actions: ['git-commit'] }, ctx), null)
  assert.equal(readiness.matchTrigger({ paths: ['README.md'] }, ctx), null)
  // 意图词看的是**剥离引用后**的人类消息，且拉丁词要过词边界
  assert.equal(readiness.matchTrigger({ when: { intents: ['ppt'] } }, readiness.buildReadinessContext({ humanText: '看看这个 pptx' })), null)
  assert.equal(readiness.matchTrigger({ when: { intents: ['调研'] } }, readiness.buildReadinessContext({ humanText: '把这个 "示例调研.pptx" 的时间改一下' })), null)
  assert.match(readiness.matchTrigger({ when: { intents: ['调研'] } }, readiness.buildReadinessContext({ humanText: '帮我做一份市场调研' })) || '', /^intent:/)
  assert.equal(readiness.matchTrigger(null, ctx), null)
  ok('matchTrigger：op / write / intent 三类判据；guard 只收窄；旧 trigger 与坏 glob 不再触发')
}

// ---- 3b. 路径 glob 的 `?` 按字面量；guard.paths 认人类消息里的写意图 ----
{
  // `?` 不是通配符。漏转义时 `^?` 是非法正则，会让整个 pre-step 注入抛异常并静默失效。
  assert.equal(readiness.matchTrigger({ when: { writes: ['?.md'] } }, readiness.buildReadinessContext({ targets: ['a.md'] })), null)
  assert.match(
    readiness.matchTrigger({ when: { writes: ['a?.js'] } }, readiness.buildReadinessContext({ targets: ['a?.js'] })) || '',
    /^write:/,
    '? 按字面量匹配',
  )
  // guard 与 when.writes 用同一份写目标（targets ∪ humanPaths）
  const human = readiness.buildReadinessContext({ humanText: '重构一下 src/auto-inject.js 的注入逻辑' })
  assert.match(readiness.matchTrigger({ when: { intents: ['重构'] }, guard: { paths: ['src/auto-inject.js'] } }, human) || '', /^intent:/)
  assert.equal(readiness.matchTrigger({ when: { intents: ['重构'] }, guard: { not_paths: ['src/auto-inject.js'] } }, human), null)
  ok('路径 glob：`?` 字面量；guard.paths / not_paths 与 when.writes 同源')
}

// ---- 3c. 长中文消息不能回溯爆炸：intentText 每步都跑 ----
{
  // 没有空格的中文句子里，文件名之后的意图词必须留下（旧正则与新的 token 版都是这个范围）
  assert.equal(readiness.intentText('把这个示例调研.pptx的时间改一下'), '的时间改一下')
  assert.equal(readiness.intentText('中文文件.pdf'), '')
  const started = Date.now()
  readiness.intentText('中'.repeat(20000))
  const elapsed = Date.now() - started
  assert.ok(elapsed < 1000, `2 万字中文消息耗时应是毫秒级，实际 ${elapsed}ms`)
  ok(`intentText：2 万字中文消息 ${elapsed}ms（无灾难性回溯）`)
}

// ---- 3b. normalizeTrigger：旧 trigger → 新 schema（幂等、纯函数）----
{
  const legacy = {
    id: 'x',
    trigger: { keywords: ['ppt', 'PaperX', '内部文档'], actions: ['npm-pack', 'interview-prep'], paths: ['*.pptx', 'src/a.js'], scope: ['npm'] },
  }
  // 显式要求 filter 时才把 legacy scope 当收窄条件（旧语义，保留但不再是默认）
  const nf = readiness.normalizeTrigger(legacy, { legacyScope: 'filter' })
  assert.deepEqual(nf.trigger.when.ops.sort(), ['npm-publish'])
  assert.deepEqual(nf.trigger.when.writes, ['src/a.js'])
  assert.deepEqual(nf.trigger.when.intents.sort(), ['PaperX', '内部文档'].sort())
  assert.deepEqual(nf.trigger.guard, { tags: ['npm'] })
  assert.ok(nf.triggerNormalized.dropped.includes('path:*.pptx'))
  assert.ok(nf.triggerNormalized.dropped.includes('action:interview-prep'))
  // 默认（不传 opts / 传 ignore）**不得**生成 guard.tags：实测唯一带 scope 的条目
  // （npm 包发布流程）的 scope 值落在画像 tag 空间之外，filter 会把它永远判死。
  for (const opts of [undefined, { legacyScope: 'ignore' }]) {
    const n = readiness.normalizeTrigger(legacy, opts)
    assert.equal(n.trigger.guard, undefined, `legacy scope 默认不该变成 guard（opts=${JSON.stringify(opts)}）`)
    assert.equal(n.triggerNormalized.scopeIgnored, true, '仍要如实记下"这条带 scope，已忽略"')
  }
  const n = readiness.normalizeTrigger(legacy)
  assert.equal(readiness.normalizeTrigger(n).trigger, n.trigger, '幂等：已是新 schema 就原样返回')
  assert.equal(legacy.trigger.when, undefined, '纯函数：不改原对象')
  ok('normalizeTrigger：actions→ops、具体 paths→writes、keywords→intents、坏 glob 丢弃；legacy scope 默认忽略（显式 filter 才收窄）')
}

// ---- 3c. 点开头的写目标要贯通到 when.writes（本轮收敛的真实收益）----
// 反应窗口从已观察到的 shell 命令抽写目标，`ops.targets` 就是这里的来源；
// 它原先漏掉点文件名，并且 shell-run-only 的行会把写目标整个吞掉。
{
  const ctx = readiness.buildReadinessContext({ humanText: '', actionText: 'rm -f .gitignore' })
  assert.ok(ctx.targets.includes('.gitignore'), `shell 写目标应含 .gitignore：${JSON.stringify(ctx.targets)}`)
  assert.equal(readiness.matchTrigger({ when: { writes: ['.gitignore'] } }, ctx), 'write:.gitignore')
  // 结构化调用行 + 无 op 规则命中（echo >> 不是删除）：写目标仍须到达 writes 判据
  const echo = readiness.buildReadinessContext({ humanText: '', actionText: 'bash {"command":"echo x >> .gitignore"}' })
  assert.deepEqual(echo.ops, [], '不产出 shell-run 噪音 op')
  assert.equal(readiness.matchTrigger({ when: { writes: ['.gitignore'] } }, echo), 'write:.gitignore')
  ok('点开头写目标贯通：rm -f .gitignore 与 bash 写 .gitignore 都命中 when.writes')
}

// ---- 4. 动机回归：lesson 的 authored trigger 必须让人在动手前看到它 ----
{
  const gs = globalWith([PUBLIC_FACE])
  const out = buildInjection({
    query: '你顺便提交一下',
    readiness: { humanText: '你顺便提交一下', actions: ['git-commit'], paths: [], actionText: '' },
    globalStore: gs,
    cfg: CFG,
  })
  assert.ok(out.text.includes('公开面'), `lesson trigger 命中即注入；实际: ${JSON.stringify(out.text)}`)
  assert.ok(out.reasons.some((r) => r.channel === 'trigger'), '必须记录命中通道（可审计）')
  ok('动机回归：lesson 的 trigger 命中，动手前注入（修前 0.014 从未到达）')
}

// ---- 5. 反应窗口：观察到的动作走同一个匹配器 ----
{
  const gs = globalWith([PUBLIC_FACE])
  const out = buildInjection({
    query: '继续',
    readiness: { humanText: '继续', actions: [], paths: [], actionText: 'git commit -m "docs: x"' },
    globalStore: gs,
    cfg: CFG,
  })
  assert.ok(out.text.includes('公开面'), 'actionText 里的 git commit 也应命中 trigger.actions')
  ok('反应窗口：已观察到的动作同样触发注入')
}

// ---- 6. 精度护栏：无 trigger + 无关内容 → 不注入 ----
{
  const unrelated = { id: 'ins_jwt', kind: 'lesson', scope: 'global', title: 'JWT 未校验 exp', fix: '用 jose 校验 exp/nbf', confidence: 1, archived: false }
  const gs = globalWith([unrelated])
  const out = buildInjection({
    query: '你顺便提交一下',
    readiness: { humanText: '你顺便提交一下', actions: ['git-commit'], paths: [] },
    globalStore: gs,
    cfg: CFG,
  })
  assert.equal(out.text, '', '无关 lesson 不得被注入（相对阈值 + 零分过滤）')
  ok('精度护栏：无关 lesson 不注入')
}

// ---- 7. 提示通道：没有 trigger，但语义相关也能进来（标记为 hint）----
{
  const lesson = { id: 'ins_reg', kind: 'lesson', scope: 'global', title: 'npm 发包要过官方源', fix: '设置 registry 为官方源', confidence: 1, archived: false }
  const gs = globalWith([lesson])
  const out = buildInjection({
    query: 'npm 发包总是失败，官方源怎么配',
    readiness: { humanText: 'npm 发包总是失败，官方源怎么配', actions: [], paths: [] },
    globalStore: gs,
    cfg: CFG,
  })
  assert.ok(out.text.includes('官方源'), `相关 lesson 应作为提示注入；实际: ${JSON.stringify(out.text)}`)
  assert.ok(out.reasons.some((r) => r.channel === 'hint'), '提示通道要能被审计')
  ok('提示通道：无 trigger 的相关 lesson 作为 hint 注入')
}

// ---- 8. 预算排程：trigger 命中先于 hint ----
{
  const hit = { ...PUBLIC_FACE }
  const hint = { id: 'ins_reg2', kind: 'lesson', scope: 'global', title: 'npm 发包要过官方源', fix: '设置 registry 为官方源', confidence: 1, archived: false }
  const gs = globalWith([hint, hit])
  const out = buildInjection({
    query: '你顺便提交一下，npm 发包也要注意',
    readiness: { humanText: '你顺便提交一下，npm 发包也要注意', actions: ['git-commit'], paths: [] },
    globalStore: gs,
    cfg: CFG,
  })
  assert.equal(out.reasons[0].channel, 'trigger', '预算排程：确定性命中优先于统计信号')
  ok('预算排程：trigger 命中排在 hint 之前')
}

// ---- 9. 相对阈值：与语料同尺度，不再是长度敏感的魔法常量 ----
{
  assert.ok(readiness, 'src/readiness.js 不存在')
  const scored = [{ id: 'a', score: 10 }, { id: 'b', score: 4 }, { id: 'c', score: 0 }]
  assert.deepEqual(readiness.relativeHits(scored, { ratioMin: 0.5 }).map((r) => r.id), ['a'])
  assert.deepEqual(readiness.relativeHits(scored, { ratioMin: 0.3 }).map((r) => r.id), ['a', 'b'])
  assert.deepEqual(readiness.relativeHits([], { ratioMin: 0.5 }), [])
  ok('relativeHits：按层内最高分取相对阈值，零分恒被剔除')
}

// ---- 10. 兼容：显式 relevanceMin 时仍走旧的绝对 overlap 判据 ----
{
  const lesson = { id: 'ins_reg3', kind: 'lesson', scope: 'global', title: 'npm 发包要过官方源', fix: '设置 registry 为官方源', confidence: 1, archived: false }
  const gs = globalWith([lesson])
  const strict = cfgEngine({ insight: {}, autoContext: { maxTokens: 400, relevanceMin: 0.9 } })
  const out = buildInjection({ query: '发包', globalStore: gs, cfg: strict })
  assert.equal(out.text, '', '显式 relevanceMin=0.9 时，overlap 不足的老行为必须保留')
  ok('兼容：显式 relevanceMin 仍走绝对 overlap 判据')
}

// ---- 11. 就绪查询只取真人消息（注入块不得成为查询） ----
{
  const { lastUserText, isOwnInjection, SOURCE_KIND } = await import('../src/auto-inject.js')
  const human = { role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: '你顺便提交一下' }] }
  const text = [{ type: 'text', text: '[Memory Inject] auto-context\n任务: x\n进度: 8 步' }]
  // 三种历史形状都必须继续被认作"自己注入的"，否则会拿上一步注入正文当本步查询（自激）。
  const shapes = [
    { kind: SOURCE_KIND }, // 现在写的 == v3→v4 迁移对老消息的改写结果
    { kind: 'project-memory' }, // 保留别名
    { kind: 'plugin', plugin: 'dsh-project-memory' }, // 迁移前内存里的旧形状
  ]
  for (const source of shapes) {
    const injected = { role: 'user', source, content: text }
    assert.equal(lastUserText([human, injected]), '你顺便提交一下',
      `source=${JSON.stringify(source)} 的注入块不得成为这一步的查询（自激）`)
    assert.ok(isOwnInjection(source), `isOwnInjection 必须认 ${JSON.stringify(source)}`)
  }
  assert.equal(isOwnInjection({ kind: 'user' }), false, '真人消息不是自己注入的')
  assert.equal(isOwnInjection(undefined), false, '无 source 的消息不是自己注入的')
  assert.equal(lastUserText([{ role: 'user', content: [{ type: 'text', text: 'hi' }] }]), 'hi', '无 source 的消息仍兜底（老宿主/测试）')
  ok('就绪查询只取真人消息，注入块不参与（防自激）')
}

// ---- 11b. 通知类 user 消息不是"人说的话"（2026-10-25 修）----
// `agent/pre-step` 的 messages 是 claimed delta；会话中段没有真人消息，旧实现把
// `agent-message`（子代理报告）/`subagent-settled`/`tool-jobs`/`time-context` 当成了 query。
// 实测：子代理报告里的"发布/渲染"触发了 intent:release（1050 字符）与 intent:渲染（1200 字符）。
{
  const { lastUserText } = await import('../src/auto-inject.js')
  const { SOURCE_KIND } = await import('../src/auto-inject.js')
  const notices = [
    { kind: 'agent-message' },
    { kind: 'subagent-settled' },
    { kind: 'tool-jobs' },
    { kind: 'time-context' },
    { kind: 'runtime-context' },
    { kind: SOURCE_KIND },
  ]
  for (const source of notices) {
    const notice = { role: 'user', source, content: [{ type: 'text', text: '发布到 npm，然后渲染 pptx，再迁移数据库' }] }
    assert.equal(lastUserText([notice]), '', `${source.kind} 不是人话，不得成为就绪查询`)
  }
  // 真人消息 + 通知混排：仍取人话（且不受顺序影响）
  const human = { role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: '帮我看下 README' }] }
  const relay = { role: 'user', source: { kind: 'agent-message' }, content: [{ type: 'text', text: '子代理报告：发布流程…' }] }
  assert.equal(lastUserText([human, relay]), '帮我看下 README')
  ok('通知 / 子代理 relay / job 通知 / 时间快照都不再冒充人类意图')
}

// ---- 11c. 散文动作词只有"不可逆外部动作"能进 ops（2026-10-25 修）----
// 证据来源分级：观察到的工具调用（rm 真的执行了）可以触发；人类消息里的词只有
// npm-publish / git-push / deploy / go-public 允许先发，其余只记为 intentOps（遥测/提示用）。
{
  const purge = {
    id: 'ins_purge', kind: 'procedure', scope: 'global', title: '误删恢复', steps: ['1'],
    trigger: { when: { ops: ['file-delete'] } }, confidence: 1, archived: false,
  }
  const publish = {
    id: 'ins_pub', kind: 'procedure', scope: 'global', title: '发布流程', steps: ['1'],
    trigger: { when: { ops: ['npm-publish'] } }, confidence: 1, archived: false,
  }
  const prose = readiness.buildReadinessContext({ humanText: '清理一下 README 的措辞，把过时的段落删掉' })
  assert.deepEqual(prose.ops, [], '散文里的删除/清理不进 ops（否则注入 1200 字符的恢复 procedure）')
  assert.ok(prose.intentOps.includes('file-delete'), '但仍要留下 intentOps，供遥测与提示通道用')
  assert.equal(readiness.matchTrigger(purge.trigger, prose), null, '仅凭散文命中不得触发全文注入')

  const before = readiness.buildReadinessContext({ humanText: '发布到 npm，记得先核对三处版本' })
  assert.ok(before.ops.includes('npm-publish'), '发布属于不可逆外部动作：允许先发')
  assert.equal(readiness.matchTrigger(publish.trigger, before), 'op:npm-publish')
  assert.ok(readiness.buildReadinessContext({ humanText: '发版 0.6.6' }).ops.includes('release'), '发版也算先发动作')
  assert.deepEqual(readiness.detectActions('帮我写 release notes'), [], 'release notes 是文档任务，不是发版')

  const observed = readiness.buildReadinessContext({ humanText: '', actionText: 'rm -rf build/' })
  assert.ok(observed.ops.includes('file-delete'), '真的执行了 rm 仍走 file-delete')
  assert.equal(readiness.matchTrigger(purge.trigger, observed), 'op:file-delete')
  ok('散文动作词分级：删除/清理只记录不触发，发布/推送仍可先发；观察到的动作不受影响')
}

// ---- 12. 1–2 字符拉丁缩写不作为提示证据 ----
{
  assert.ok(readiness, 'src/readiness.js 不存在')
  const acronym = { id: 'ins_pr', kind: 'lesson', scope: 'global', title: '自动安全 PR 扫描：横向越权', fix: 'authz 检查', confidence: 1, archived: false }
  const content = { id: 'ins_pub2', kind: 'lesson', scope: 'global', title: '公开作品仓库的公开面', fix: '内部文档写进 .gitignore', confidence: 1, archived: false }
  const gs = globalWith([acronym, content])
  const human = 'PR 提交前检查公开面'
  const out = buildInjection({ query: human, readiness: { humanText: human, actionText: '' }, globalStore: gs, cfg: CFG })
  const ids = out.reasons.map((r) => r.id)
  assert.ok(ids.includes('ins_pub2'), `内容命中必须进：${JSON.stringify(out.reasons)}`)
  assert.ok(!ids.includes('ins_pr'), '仅靠 "PR" 这种缩写命中的条目不得作为提示注入')
  assert.equal(readiness.hintQueryText('PR src/a.js 提交'), 'src/a.js 提交', '只剔除独立缩写，路径 token 原样保留')
  ok('提示证据：1–2 字符拉丁缩写被忽略，避免缩写巧合命中')
}

// ---- 13. 预算塞不下"有用前缀"时宁可丢弃，也不输出 stub ----
{
  const { fitBody } = await import('../src/auto-inject.js')
  assert.equal(fitBody('x'.repeat(300), 100, 120), null, '剩余预算 < 最小可用长度 → 丢弃')
  assert.equal(fitBody('short body', 200, 120), 'short body', '放得下就原样')
  assert.equal(fitBody('y'.repeat(500), 400, 120).length, 400, '截断不超过剩余预算')
  const many = []
  for (let i = 0; i < 4; i++) many.push({ id: `ins_stub_${i}`, kind: 'lesson', scope: 'global', title: '公开面检查清单', fix: 'x'.repeat(280), confidence: 1, archived: false })
  const gs = globalWith(many)
  const out = buildInjection({ query: '公开面', globalStore: gs, cfg: cfgEngine({ insight: {}, autoContext: { maxTokens: 200 } }) })
  for (const line of out.text.split('\n')) {
    if (!line.startsWith('- [')) continue
    assert.ok(line.length >= 120, `提示正文不得是 stub：${JSON.stringify(line)}`)
  }
  ok('预算压力下：宁可丢弃也不输出无意义的截断 stub')
}

// ---- 12. idfCoveragePrepared 与 idfCoverage 必须逐字段一致 ----
// 把语料词集合提出候选循环是**纯性能**优化（实测真实 store 单步 147ms → 1.3ms，109×），
// 但它改了评分路径，所以把"等价"钉成回归：任何字段不一致都是静默的判据漂移。
{
  const { idfCoverage, idfCoveragePrepared, corpusTermSets } = await import('../src/readiness.js')
  const corpus = [
    '数据库连接池 配置 参数 调优 maxPoolSize',
    '连接池 耗尽 报错 泄漏 排查',
    'pptx 时间戳 修改 文件',
    'npm publish 发版 版本号 核对 package.json',
    '注入 配额 滑动窗口 影子 记录 候选 门槛',
  ]
  const sets = corpusTermSets(corpus)
  assert.equal(sets.length, corpus.length)
  for (const q of ['连接池 配置', 'npm publish 发版', '配额 候选', 'zzz 不存在的词']) {
    for (let i = 0; i < corpus.length; i++) {
      assert.deepEqual(
        idfCoveragePrepared(q, corpus[i], sets),
        idfCoverage(q, corpus[i], corpus),
        `prepared 与 wrapped 结果必须一致：q=${q} i=${i}`,
      )
    }
  }
  assert.deepEqual(idfCoveragePrepared('', corpus[0], sets), { coverage: 0, matched: 0, supported: 0, terms: 0 })
  ok('idfCoveragePrepared ≡ idfCoverage（语料提出循环外，逐字段等价）')
}

console.log(`\nreadiness tests: ${passed} passed`)
