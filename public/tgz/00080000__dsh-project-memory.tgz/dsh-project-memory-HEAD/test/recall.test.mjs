// 统一召回（pull 侧）：insight 层接入 query_memory + 规范段加权 —— PR1
//   node test/recall.test.mjs
//
// 设计口径：一个记忆、一个检索契约、按层分桶 + 层先验；insight 不再只有"注入"一条出口。
// 本文件是 PR1 的验收面：修前 1/2/3/4/5/6/7 条必须红。
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { ProjectMemoryStore } from '../src/store.js'
import { cfgInsight, GlobalStore, saveInsight } from '../src/insight-store.js'
import { memoryRootFor } from '../src/util/fs.js'
import { indexRepository } from '../src/tools/index-repo.js'
import { queryMemoryTool } from '../src/tools/query-memory.js'
import { rankEntriesMergedScored } from '../src/util/search.js'

let passed = 0
const ok = (name) => {
  passed++
  console.log('  ok', name)
}

const CONFIG = {
  memoryDir: '.dsh-project-memory',
  chunkChars: 3000,
  maxChunksPerFile: 40,
  maxFileSizeMb: 50,
  maxPdfPages: 10,
  maxOutputChars: 8000,
  llmQueryExpansion: false,
}

// PR1 新增的统一召回模块：修前不存在 → 依赖它的断言必须红（而不是静默通过）。
let recall = null
try {
  recall = await import('../src/recall.js')
} catch {
  recall = null
}

const INSIGHT = {
  kind: 'lesson',
  title: '发布前要扫的公开面不止文件清单：注释、CHANGELOG 与提交历史都会一起暴露',
  pattern: '把内部文档从 .gitignore 里排除，却忘了 src 注释、CHANGELOG 与提交历史同样公开',
  fix: '内部文档一律写进 .gitignore；公开前扫描 src/ test/ CHANGELOG 的内部引用与代号；注意 npm pack 的 files 白名单；旧提交快照里的措辞也算公开',
  confidence: 0.88,
}
const QUERY = '提交前检查公开面，别把内部文档带进公开仓库'

function newProject() {
  const root = mkdtempSync(path.join(tmpdir(), 'pm-recall-'))
  const store = new ProjectMemoryStore(memoryRootFor(root, CONFIG.memoryDir)).load()
  const gs = new GlobalStore(path.join(root, 'global.json')).load()
  return { root, store, gs, cfg: cfgInsight(CONFIG) }
}

function exec0(root, sessionId = 'sess_unbound') {
  return { agent: { session: { id: sessionId, header: { cwd: root } } } }
}

// ---- 1. 适配器：insight 映射到统一检索条目契约 ----
{
  assert.ok(recall, 'src/recall.js 不存在：insight 层还没有接入统一召回')
  const e = recall.insightToEntry({ id: 'ins_x', scope: 'project', ...INSIGHT, files: ['README.md'], symbols: ['publish'] })
  assert.equal(e.type, 'insight')
  assert.equal(e.id, 'insight:ins_x')
  assert.equal(e.insightId, 'ins_x')
  assert.match(e.title, /公开面/)
  assert.ok(e.summary.includes('gitignore'), 'summary 必须带上 fix，供展示与注入复用')
  const kw = (e.keywords || []).join(' ')
  assert.ok(kw.includes('lesson'), 'kind 进关键词，便于按类型检索')
  assert.ok(kw.includes('README.md') && kw.includes('publish'), 'files / symbols 进关键词')
  ok('insightToEntry：insight 映射到统一检索条目契约')
}

// ---- 2. 规范段先验 ----
{
  assert.ok(recall, 'src/recall.js 不存在')
  assert.ok(recall.normativePrior({ title: '必须遵守' }) > 1, '中文规范段标题要提权')
  assert.ok(recall.normativePrior({ title: '禁止 git add -A' }) > 1)
  assert.ok(recall.normativePrior({ title: 'Rules' }) > 1, '英文规范段同样提权')
  assert.equal(recall.normativePrior({ title: 'Firebase 配置' }), 1, '普通标题不得提权')
  assert.equal(recall.normativePrior({}), 1)
  ok('normativePrior：规范段标题提权，普通标题不提权')
}

// ---- 3. query_memory 新增 insight 层（自然语言查询） ----
{
  const { root, store, gs, cfg } = newProject()
  store.commit((s) => saveInsight({ store: s, globalStore: gs, raw: INSIGHT, scope: 'project', cfg }))
  const tool = queryMemoryTool({}, CONFIG)
  const out = await tool.execute({ query: QUERY, root, type: 'insight' }, exec0(root))
  assert.match(out, /ins_/, 'type=insight 必须返回 project insight（现在 enum 里没有 insight）')
  assert.match(out, /公开面/)
  ok('query_memory type=insight 能召回 lesson（自然语言查询）')
}

// ---- 4. type=all 也要带上 insight 段 ----
{
  const { root, store, gs, cfg } = newProject()
  store.commit((s) => saveInsight({ store: s, globalStore: gs, raw: INSIGHT, scope: 'project', cfg }))
  const tool = queryMemoryTool({}, CONFIG)
  const out = await tool.execute({ query: QUERY, root }, exec0(root))
  assert.match(out, /## Insights/, "type=all 应包含 '## Insights' 段")
  assert.match(out, /公开面/)
  ok("type=all 输出包含 '## Insights' 段")
}

// ---- 5. 作用域可见性：task 级只对绑定它的会话可见 ----
{
  const { root, store, gs, cfg } = newProject()
  const now = new Date().toISOString()
  store.addTask({ id: 'tsk_a', title: 'A', projectRoot: root, steps: null, files: [], archived: false, createdAt: now, updatedAt: now, lastActiveAt: now })
  store.commit((s) => saveInsight({
    store: s,
    globalStore: gs,
    raw: { kind: 'lesson', title: '任务私有：内部文档外泄检查清单', fix: '提交前扫描公开面' },
    scope: 'task',
    taskId: 'tsk_a',
    cfg,
  }))
  const tool = queryMemoryTool({}, CONFIG)
  const unbound = await tool.execute({ query: '内部文档 外泄 检查清单', root, type: 'insight' }, exec0(root, 'sess_unbound'))
  assert.ok(!/任务私有/.test(unbound), '未绑定会话不得看到 task 作用域条目')
  store.setBinding('sess_bound', 'tsk_a')
  const bound = await tool.execute({ query: '内部文档 外泄 检查清单', root, type: 'insight' }, exec0(root, 'sess_bound'))
  assert.match(bound, /任务私有/, '绑定该任务的会话应能看到')
  ok('作用域可见性：task 级 insight 只对绑定它的会话可见')
}

// ---- 6. 规范段提权：同样词频下「必须遵守」chunk 必须胜出 ----
{
  const entries = [
    { id: 'a#0', type: 'doc', sourcePath: 'a.md', sourceLine: 1, title: '项目手册', summary: '不要 提交 私密 文件 公开 仓库 提交 说明', keywords: ['提交', '不要', '公开'], terms: '' },
    { id: 'a#1', type: 'doc', sourcePath: 'a.md', sourceLine: 90, title: '必须遵守', summary: '不要提交私密文件', keywords: ['提交'], terms: '' },
  ]
  // 前置：现状就是"普通 chunk 靠词频压过规范段"（本 PR 要修的现象）
  const baseline = rankEntriesMergedScored(entries, ['提交前不要做什么'], 2).map((r) => r.entry.id)
  assert.equal(baseline[0], 'a#0', '前置事实：未提权时 a#0 胜出')
  assert.ok(recall, 'src/recall.js 不存在')
  const ranked = recall.recallItems({ entries, queries: ['提交前不要做什么'], layers: ['doc'] })
  assert.equal(ranked.layers[0].hits[0].item.id, 'a#1', '规范段提权后必须排第一')
  ok('规范段提权：同样词频下「必须遵守」chunk 胜出')
}

// ---- 7. 真实文件端到端：规范段必须出现在召回里 ----
{
  const { root, store } = newProject()
  const filler = `${'这是无关的项目说明，用于填充体积。'.repeat(60)}\n\n`
  writeFileSync(path.join(root, 'HANDBOOK.md'), `# 项目手册\n\n${filler}## 必须遵守\n\n- 不要提交私密文件，禁止 git add -A\n- 提交前扫描 src/ 与 CHANGELOG 的内部引用\n`)
  await indexRepository({}, CONFIG, root, {})
  const tool = queryMemoryTool({}, CONFIG)
  const out = await tool.execute({ query: '提交前不要做什么', root, type: 'doc' }, exec0(root))
  assert.match(out, /必须遵守/, '规范段所在 chunk 必须出现在召回结果里')
  ok('端到端：长文档里的规范段 chunk 可被召回')
}

// ---- 8. recallItems：按层分桶 + 层先验 ----
{
  assert.ok(recall, 'src/recall.js 不存在')
  const { store, gs, cfg } = newProject()
  store.commit((s) => saveInsight({ store: s, globalStore: gs, raw: INSIGHT, scope: 'project', cfg }))
  const r = recall.recallItems({ store, globalStore: gs, queries: [QUERY], layers: ['doc', 'insight'] })
  const bucket = r.layers.find((l) => l.layer === 'insight')
  assert.ok(bucket, 'layers 里必须有 insight 桶')
  assert.equal(bucket.prior, recall.LAYER_PRIORS.insight, '层先验必须暴露出来（可审计）')
  assert.ok(bucket.hits.length >= 1, 'insight 桶必须有命中')
  assert.equal(bucket.hits[0].item.type, 'insight')
  ok('recallItems：按层分桶 + 层先验，insight 层可检索')
}


// ---- 9. 父根未命中时，把"这里有独立子索引"告诉模型（走 root= 再问一次） ----
// 父根不再重复保存子项目的内容（walkDir 跳过自带 store 的嵌套根），所以这一步必须指路，
// 否则"在父根下问子项目的事"就是静默无结果。
{
  const root = mkdtempSync(path.join(tmpdir(), 'pm-nested-note-'))
  writeFileSync(path.join(root, 'package.json'), '{}')
  // 父根自己的 store（有内容，但对下面的 query 不命中）
  const parentStore = new ProjectMemoryStore(memoryRootFor(root, CONFIG.memoryDir)).load()
  parentStore.setEntries('own.md', [{ id: 'own', type: 'doc', relPath: 'own.md', sourcePath: 'own.md', title: 'parent own doc', summary: 'about widgets' }])
  parentStore.save()
  // 子根：自带 store → 应被列出来
  const child = path.join(root, 'childproj')
  const childStore = new ProjectMemoryStore(memoryRootFor(child, CONFIG.memoryDir)).load()
  childStore.setEntries('x.md', [{ id: 'x', type: 'doc', relPath: 'x.md', sourcePath: 'x.md', title: 'child doc', summary: 'about gadgets' }])
  childStore.save()

  const tool = queryMemoryTool({}, CONFIG)
  const miss = await tool.execute({ query: 'zzz-no-such-thing-zzz', root, type: 'doc' }, exec0(root))
  assert.match(miss, /nested project\(s\)/, '未命中时要提示存在独立子索引')
  assert.ok(miss.includes(child), `提示里要给出子根路径：${miss.slice(-300)}`)
  ok('query_memory：本根未命中 → 列出独立子索引并让模型换 root')

  // 命中时不该出现这段提示（否则每次查询都刷屏）
  const hit = await tool.execute({ query: 'widgets', root, type: 'doc' }, exec0(root))
  assert.ok(!/nested project\(s\)/.test(hit), '本根命中时不得追加指路提示')
  ok('query_memory：本根命中 → 不追加提示')
}

// 回归（0.6.x 统一存储）：`kind:'experience'` 也能由 save_lesson 写出 —— 它没有
// problem/solution（正文在 fix/choice/pattern 里），而旧的经验桶用 v0.4 的
// `${problem}...${solution}` 打分，那种条目的 BM25 文档是三个字面量 `undefined`：
// 经验桶 0 分、洞察桶又排除了 experience → 条目在库里但两条拉取路径都查不到。
{
  const root = mkdtempSync(path.join(tmpdir(), 'pm-exp-shape-'))
  const store = new ProjectMemoryStore(memoryRootFor(root, CONFIG.memoryDir)).load()
  const gs = new GlobalStore(path.join(root, 'global.json')).load()
  const cfg = cfgInsight({ insight: { globalFile: path.join(root, 'global.json') } })
  const saved = store.commit((s) => saveInsight({
    store: s, globalStore: gs,
    raw: { title: 'pnpm 拦截安装脚本', kind: 'experience', pattern: 'pnpm 10 默认不跑 postinstall', fix: '用 approve-builds 放行' },
    scope: 'project', cfg,
  }))
  assert.ok(saved.ok)
  const tool = queryMemoryTool({}, CONFIG)
  const out = await tool.execute({ query: 'pnpm 拦截安装脚本', root, type: 'experience' }, exec0(root))
  assert.match(out, /pnpm 拦截安装脚本/, `save_lesson 写的 experience 必须能被经验桶召回：${out}`)
  assert.ok(!/undefined/.test(out), `渲染不得出现 undefined 字段：${out}`)
  ok('经验桶：save_lesson 形状（无 problem/solution）也能召回且不渲染 undefined')

  // v0.4 remember 形状不受影响（problem/solution 仍是正文来源）
  const s2 = new ProjectMemoryStore(memoryRootFor(root, CONFIG.memoryDir)).load()
  s2.commit((s) => saveInsight({
    store: s, globalStore: gs,
    raw: { title: '缓存逐出是假的', kind: 'experience', problem: '缓存逐出是假的', solution: '看 hitRate 而不是 size' },
    scope: 'project', cfg,
  }))
  const out2 = await tool.execute({ query: '缓存逐出是假的', root, type: 'experience' }, exec0(root))
  assert.match(out2, /缓存逐出是假的/)
  assert.match(out2, /看 hitRate/, 'problem/solution 形状的 solution 仍要出现在 solution 行')
  ok('经验桶：v0.4 problem/solution 形状的渲染与召回不变')
}

// ---- 16. 段落顺序由相关性决定，而不是写死的 docs 优先 ----
// 真实案例：查一条很明确的记忆时，insight 层第 1（hint 1.150），doc 层第 1 却是无关的长文档
// 条目（hint 1.000）。旧输出写死 docs → insights，模型第一眼看到无关文档，正确答案在
// ~4.6k 字符之后。这里钉住：顺序取各段最佳条目的 rel × 层先验。
{
  const { root, gs, cfg } = newProject()
  const toolCfg = { ...CONFIG, insight: { globalFile: path.join(root, 'global.json') } }
  const store = new ProjectMemoryStore(memoryRootFor(root, CONFIG.memoryDir)).load()
  store.commit((s) => saveInsight({ store: s, globalStore: gs, raw: INSIGHT, scope: 'project', cfg }))
  // 同一条查询也命中一个 doc（否则测不到两段并存），但它只是摘要级命中，相关性更低。
  store.setEntries('PUBLIC.md', [{
    id: 'pub', type: 'doc', relPath: 'PUBLIC.md', sourcePath: 'PUBLIC.md', sourceLine: 1,
    title: '公开仓库说明', summary: '提交前检查公开面；内部文档不要带进公开仓库；src 与 CHANGELOG 也要扫',
  }])
  store.save()

  const out = await queryMemoryTool({}, toolCfg).execute({ query: QUERY, root }, exec0(root))
  const iInsight = out.indexOf('## Insights')
  const iMemory = out.indexOf('## Memory')
  assert.ok(iInsight >= 0 && iMemory >= 0, `两段都应存在：${out.slice(0, 400)}`)
  assert.ok(iInsight < iMemory, `insight 更强时必须排在 Memory 之前：\n${out.slice(0, 400)}`)
  const firstHit = out.split('\n').find((l) => l.startsWith('### '))
  assert.match(firstHit, /公开面/, `第一条命中必须是 insight：${firstHit}`)
  ok('输出顺序：insight 更强时排在 docs 之前（第一条即正确答案）')
}

// ---- 16b. 没有 insight 命中时，doc 仍排第一（doc-only 查询行为不变） ----
{
  const { root } = newProject()
  const toolCfg = { ...CONFIG, insight: { globalFile: path.join(root, 'global.json') } }
  const store = new ProjectMemoryStore(memoryRootFor(root, CONFIG.memoryDir)).load()
  store.setEntries('ONLY.md', [{
    id: 'only', type: 'doc', relPath: 'ONLY.md', sourcePath: 'ONLY.md', sourceLine: 1,
    title: '公开仓库说明', summary: '提交前检查公开面；内部文档不要带进公开仓库',
  }])
  store.save()
  const out = await queryMemoryTool({}, toolCfg).execute({ query: QUERY, root }, exec0(root))
  assert.ok(out.startsWith('## Memory'), `doc-only 查询仍以 Memory 开头：${out.slice(0, 200)}`)
  assert.ok(!out.includes('## Insights'), '没有 insight 命中时不应出现 Insights 段')
  ok('输出顺序：doc-only 查询保持 Memory 在前')
}

// ---- 17. prev 在 pull 侧可见：模型能判断是否写回旧值 ----
{
  const { root, store, gs, cfg } = newProject()
  const r = store.commit((s) => saveInsight({
    store: s, globalStore: gs, scope: 'project', cfg,
    raw: { ...INSIGHT, fix: '旧解法：先扫 src 注释' },
  }))
  store.commit((s) => saveInsight({
    store: s, globalStore: gs, cfg,
    raw: { id: r.id, fix: '新解法：先扫 src 注释与 CHANGELOG' },
  }))
  const toolCfg = { ...CONFIG, insight: { globalFile: path.join(root, 'global.json') } }
  const out = await queryMemoryTool({}, toolCfg).execute({ query: QUERY, root, type: 'insight' }, exec0(root))
  assert.match(out, /previous: fix=旧解法：先扫 src 注释/, `prev 必须出现在 pull 输出里：${out}`)
  ok('query_memory：覆盖字段的上一版（prev）可见')
}

// ---- 18. doc/symbol 跨层合并不再按原始 BM25 分互相挤占 ----
{
  const root = mkdtempSync(path.join(tmpdir(), 'pm-merge-doc-sym-'))
  const filler = 'alpha '.repeat(40)
  for (let i = 0; i < 6; i++) {
    writeFileSync(path.join(root, `doc${i}.md`), `# alpha doc ${i}\n\n${filler}\n`)
  }
  writeFileSync(path.join(root, 'alpha.js'), 'export function alphaFn() { return 1 }\n')
  await indexRepository({}, CONFIG, root, {})
  const toolCfg = { ...CONFIG, insight: { globalFile: path.join(root, 'global.json') } }
  const out = await queryMemoryTool({}, toolCfg).execute({ query: 'alpha', root, limit: 2 }, exec0(root))
  assert.match(out, /alphaFn/, `limit=2 时符号层必须保留一条：${out}`)
  assert.match(out, /alpha doc/, `limit=2 时文档层必须保留一条：${out}`)
  ok('doc/symbol 跨层合并：按层内相对分排序，并各保留一条')
}

console.log(`\nrecall tests: ${passed} passed`)
