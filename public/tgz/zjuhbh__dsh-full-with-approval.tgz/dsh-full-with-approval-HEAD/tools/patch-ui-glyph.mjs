/**
 * Patch the installed dsh client UI to draw a glyph for the
 * `full-with-approval` permission preset.
 *
 * Why: the permission selector's icon map (`permissionGlyphs`) lives inside
 * the core `@deepseek-ai/dsh-client-ui-conversation` client bundle and is
 * keyed by preset value; plugin-added presets get no icon (the client module
 * graph is flat, so a client bundle cannot override it). Until that is
 * supported upstream, this script applies the same 3-line-style edit to the
 * installed package, which the web app serves live (verify with a page
 * refresh).
 *
 * Usage:
 *   node tools/patch-ui-glyph.mjs [/path/to/dsh-client-ui-conversation/lib]
 *
 * Idempotent: re-running after an upgrade re-applies; matches only the exact
 * built-bundle shape, and refuses when the anchor moved (re-check with a
 * newer dsh).
 */
import { copyFileSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const require = createRequire(import.meta.url);
let pkgDir;
try {
	pkgDir = dirname(require.resolve(
		"@deepseek-ai/dsh-client-ui-conversation/package.json",
		{ paths: [process.cwd()] }
	));
} catch {
	pkgDir = process.argv[2];
	if (pkgDir === void 0) {
		console.error("cannot locate @deepseek-ai/dsh-client-ui-conversation; pass the package lib dir as argv[1]");
		process.exit(1);
	}
}
const libDir = pkgDir.endsWith("/lib") || pkgDir.endsWith("\\lib") ? pkgDir : join(pkgDir, "lib");
const target = join(libDir, "client.js");

const needle = `"full-with-approval": (0, react_jsx_runtime.jsxs)("svg", {`;
const text = readFileSync(target, "utf8");
if (text.includes(needle)) {
	console.log(`${target}: already patched`);
	process.exit(0);
}

const marker = `					})
				]
			})
		};
		/** Glyph for a permission option value; host-configured names outside the design set get none. */`;
const insertion = `					})
				]
			}),
			"full-with-approval": (0, react_jsx_runtime.jsxs)("svg", {
				width: "16",
				height: "16",
				viewBox: "0 0 16 16",
				fill: "none",
				"aria-hidden": true,
				children: [
					(0, react_jsx_runtime.jsx)("path", {
						d: shieldOutline,
						stroke: "currentColor",
						strokeWidth: "1.31831",
						strokeLinejoin: "round"
					}),
					(0, react_jsx_runtime.jsx)("path", {
						d: "M5.3 8.55 L7.15 10.4 L10.85 6.35",
						stroke: "currentColor",
						strokeWidth: "1.3",
						strokeLinecap: "round",
						strokeLinejoin: "round"
					})
				]
			})
		};
		/** Glyph for a permission option value; host-configured names outside the design set get none. */`;

const index = text.indexOf(marker);
if (index === -1) {
	console.error(`${target}: anchor not found — this dsh version moved the glyph table; update the patch or report upstream`);
	process.exit(1);
}

const backup = `${target}.bak-fwa`;
copyFileSync(target, backup);
writeFileSync(target, text.slice(0, index) + insertion + text.slice(index + marker.length));
console.log(`${target}: patched (backup at ${backup})`);
console.log("Refresh the web UI to pick the new bundle rev.");
