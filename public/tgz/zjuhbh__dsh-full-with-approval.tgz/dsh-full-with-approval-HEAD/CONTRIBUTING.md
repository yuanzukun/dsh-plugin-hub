# Contributing

> **This project is no longer maintained.** Contributions are not being accepted —
> issues and pull requests are not monitored. Fork the repository if you wish to
> continue development.

Thanks for taking an interest! This plugin is intentionally small: two runtime
modules, one loader patch, a couple of tests.

## Setup

```sh
git clone https://github.com/zjuhbh/dsh-full-with-approval.git
cd dsh-full-with-approval
npm ci                      # picomatch (dev: vendored copy is fine too)
```

## Checks

```sh
node --test                                 # classifier unit tests
DSH_AI_NODE_MODULES=/path/to/node_modules/@deepseek-ai \
  node test/pre-execute.harness.mjs         # real-registry ask→approval→dispatch chain
```

The harness imports `@deepseek-ai/dsh-tools` + `@deepseek-ai/cordis` from a dsh
install (`DSH_AI_NODE_MODULES`); the CI job installs them into a scratch
prefix instead.

## What can change

- `lib/classify.js` — path classification (workspace/temp containment,
  protected globs). Keep it a pure function: no fs writes, no side effects.
- `lib/index.js` — the `tools/pre-execute` gate: preset gating, ask reasons,
  fail-closed error mapping.
- `cordis.patch.yml` — the permission-table entry and plugin config
  (`protectedPaths`, `extraWritableRoots`).
- `tools/patch-ui-glyph.mjs` — the core-client icon workaround for the 4th
  preset value (upstream gap; keep idempotent + backing up).

## Behavioral rules

- Never weaken a denial: if the classifier cannot decide, fail closed.
- Never add a path class that bypasses approval silently — extend the
  `ask`/`allow` verdicts through `createClassifier` and cover them in
  `test/classify.test.mjs`.
- Docs ship bilingual (`README.md` + `README.zh.md`); keep both in sync.
- Version bumps go to `package.json`, `CHANGELOG.md`, and a `vX.Y.Z` tag.
