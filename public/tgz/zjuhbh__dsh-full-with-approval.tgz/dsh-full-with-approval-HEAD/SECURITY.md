# Security Policy

> **This project is no longer maintained.** No security patches will be issued.
> Vulnerability reports are not monitored; fork the repository if you need fixes.

## Trust model

`dsh-full-with-approval` is a DSH *permission* plugin: it does **not** create a
security boundary of its own. It selects the session sandbox mode
`danger-full-access` (processes unconfined — by design, for GPU/device usage)
and layers the official `tools/pre-execute` **ask** decision on top of the
mutating filesystem tools. The actual authorization boundary for the agent's
own actions is the user approval prompt (`ctx.approval`, one-shot
`allowed-once`); the boundary for untrusted *code* remains the host's sandbox
whenever a narrower mode is selected.

What the gate guarantees:

- a `write` / `edit` targeting a path outside the session workspace (outside
  the platform temp areas and configured scratch roots), or a workspace path
  matching `protectedPaths`, never executes without an explicit per-operation
  user approval;
- a rejected / cancelled / unavailable approval means nothing is written;
- classifier errors fail closed (deny);
- reads and non-mutating tools are untouched.

What the gate does **not** guarantee (deliberate, documented boundaries):

- shell commands are filtered by a STATIC heuristic, not by a kernel fence —
  a command can still evade the check (dynamically built paths, `cd` +
  relative writes, interpreters hiding file access). Under
  `danger-full-access` a command may ultimately write anywhere the user
  account can; treat the shell guard as prompt-on-suspicion, not a security
  boundary (the kernel boundary is `workspace-write` mode, at the cost of
  GPU access);
- `run_code` / code-mode sub-dispatches are not inspected;
- the workspace classification is canonicalize-then-compare; filesystems with
  unusual symlink aliasing (Windows 8.3, case-insensitive paths) make the
  boundary advisory — the kernel-level fence is authoritative only where modes
  actually confine.

## Installation hygiene

Installing a DSH plugin runs third-party code with your own permissions. This
plugin is small and read-only over the host except for the permission-table
patch and the `tools/pre-execute` listener; review the bundle patch and
`lib/` before installing, and prefer installing from a pinned release
(`v0.1.0`) or an npm tarball over following `main`.

## Reporting

Open an issue in this repository for anything that looks wrong — a write that
bypassed the gate, an approval that was not asked, or a denial that blocked a
legitimate write. Describe the session mode, the tool call (write/edit), the
target path, and the configured `protectedPaths`.
