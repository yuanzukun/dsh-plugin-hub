/**
 * In-process harness: proves the full gate chain against the REAL tools
 * registry — host-plane `tools/pre-execute` listener → `{kind:"ask"}` →
 * registry `serviceAsk` → `ctx.approval.request` → `allowed-once` → actual
 * tool dispatch — and the negative paths (preset off ⇒ no approval; reject
 * ⇒ no dispatch).
 *
 * The harness imports `@deepseek-ai/cordis` and `@deepseek-ai/dsh-tools`
 * straight out of a dsh install. Point DSH_AI_NODE_MODULES at the `@deepseek-ai`
 * package directory there (defaults to the author's checkout).
 *
 * Run: DSH_AI_NODE_MODULES=/path/to/node_modules/@deepseek-ai node test/pre-execute.harness.mjs
 */
import path from "node:path";

const AI_MODULES = process.env.DSH_AI_NODE_MODULES ??
	"/home/he/.nvm/versions/node/v26.7.0/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai";
const cordisUrl = pathToFileUrl(path.join(AI_MODULES, "cordis/lib/index.js"));
const toolsUrl = pathToFileUrl(path.join(AI_MODULES, "dsh-tools/lib/index.js"));

function pathToFileUrl(p) {
	return `file://${p}`;
}

const { Context } = await import(cordisUrl);
const { default: ToolRuntime, defineTool } = await import(toolsUrl);
import apply, { PRESET_NAME } from "../lib/index.js";

const results = [];
function check(name, ok, detail = "") {
	results.push({ name, ok, detail });
	console.log(`${ok ? "✔" : "✖"} ${name}${detail ? ` — ${detail}` : ""}`);
}

const ctx = new Context();
// Stub systemPrompt (ToolRuntime inject) with the tiny surface it uses.
ctx.provide("systemPrompt", {
	tools() {},
	section() {},
	variable() {}
});

const approvalCalls = [];
let approvalOutcome = "allowed-once";
ctx.provide("approval", {
	request: async (request) => {
		approvalCalls.push(request);
		return approvalOutcome;
	}
});

let preset = PRESET_NAME;
ctx.provide("permissionPresets", {
	current: () => preset
});

let executed = 0;
await ctx.plugin(ToolRuntime, { mode: "native" });
await ctx.plugin((c) => { apply(c, { protectedPaths: [".git/**", ".env*"], extraWritableRoots: [] }); }, {});

ctx.tools.register(defineTool({
	name: "write",
	description: "test write tool",
	parameters: {
		file_path: { type: "string", required: true },
		content: { type: "string", required: true }
	},
	output: { schema: { type: "object", properties: { path: { type: "string" } }, additionalProperties: false }, render: () => [{ type: "text", text: "written" }] },
	async execute(args) {
		executed += 1;
		return { path: args.file_path };
	}
}));

ctx.tools.register(defineTool({
	name: "bash",
	description: "test bash tool",
	parameters: {
		command: { type: "string", required: true }
	},
	output: { schema: { type: "object", properties: { code: { type: "number" } }, additionalProperties: false }, render: () => [{ type: "text", text: "ran" }] },
	async execute(args) {
		executed += 1;
		return { code: 0 };
	}
}));

const agent = { session: { events: [], header: { cwd: "/tmp/ws" } } };
function call(filePath, name = "write") {
	return ctx.tools.execute({
		name,
		arguments: name === "bash"
			? { command: filePath }
			: { file_path: filePath, content: "x" },
		signal: new AbortController().signal,
		callId: `c-${Math.random()}`,
		...agent ? { agent } : {}
	});
}

// 1. preset ON, protected path → ask → approval fired → executed
preset = PRESET_NAME;
approvalCalls.length = 0;
executed = 0;
await call("/tmp/ws/.git/config");
check("protected write asks approval", approvalCalls.length === 1, `requests=${approvalCalls.length}`);
check("ask reason names the path", approvalCalls[0]?.reason?.includes(".git/config") === true);
check("approved write dispatches", executed === 1);

// 2. preset ON, outside path → ask
approvalCalls.length = 0;
executed = 0;
await call("/etc/hostname");
check("outside write asks approval", approvalCalls.length === 1);
check("approved outside write dispatches", executed === 1);

// 3. preset ON, ordinary workspace file → no approval
approvalCalls.length = 0;
executed = 0;
await call("/tmp/ws/src/main.ts");
check("normal workspace write is silent", approvalCalls.length === 0 && executed === 1);

// 4. preset OFF → no approval, executes
preset = "workspace-write";
approvalCalls.length = 0;
executed = 0;
await call("/tmp/ws/.git/config");
check("preset off: no approval", approvalCalls.length === 0 && executed === 1);

// 5. non-mutating tool → no approval regardless of preset
preset = PRESET_NAME;
approvalCalls.length = 0;
executed = 0;
await call("", "read");
check("read tool untouched", approvalCalls.length === 0);

// 5b. bash gate: outside-path modification evidence → ask → executes on allow
approvalCalls.length = 0;
executed = 0;
await call("chmod 600 ~/.codex/config.toml", "bash");
check("bash outside modification asks approval", approvalCalls.length === 1);
check("bash ask reason names the target", approvalCalls[0]?.reason?.includes(".codex") === true);
check("approved bash executes", executed === 1);

// 5c. bash gate: visibly read-only outside reads are silent
approvalCalls.length = 0;
executed = 0;
await call("cat ~/.codex/config.toml", "bash");
check("read-only bash is silent", approvalCalls.length === 0 && executed === 1);

// 5d. bash gate: workspace-relative commands are silent
approvalCalls.length = 0;
executed = 0;
await call("npm test", "bash");
check("workspace bash is silent", approvalCalls.length === 0 && executed === 1);

// 6. rejected approval → tool denied, nothing executes
preset = PRESET_NAME;
approvalOutcome = "rejected";
approvalCalls.length = 0;
executed = 0;
const rejected = await call("/tmp/ws/.git/config");
check("rejected approval denies dispatch", executed === 0 && /rejected/i.test(JSON.stringify(rejected)));

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
process.exit(failed.length === 0 ? 0 : 1);
