import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createBashClassifier, createClassifier } from "../lib/classify.js";

/** One classifier over a scratch workspace with the default protected paths. */
function fixture() {
	const ws = mkdtempSync(join(tmpdir(), "dsh-fwa-"));
	mkdirSync(join(ws, ".git"), { recursive: true });
	mkdirSync(join(ws, "src"), { recursive: true });
	writeFileSync(join(ws, ".env"), "");
	writeFileSync(join(ws, ".git", "config"), "");
	writeFileSync(join(ws, "src", "main.js"), "");
	return { ws, classify: createClassifier() };
}

/** A real, always-present path outside any workspace and outside temp areas. */
const OUTSIDE = "/etc/hostname";

test("workspace file that is not protected: allow", () => {
	const { ws, classify } = fixture();
	assert.equal(classify(join(ws, "src", "main.js"), ws).kind, "allow");
	assert.equal(classify("src/main.js", ws).kind, "allow");
	assert.equal(classify("README.md", ws).kind, "allow");
});

test(".git/** is protected: ask", () => {
	const { ws, classify } = fixture();
	const v = classify(join(ws, ".git", "config"), ws);
	assert.equal(v.kind, "ask");
	assert.equal(v.category, "protected");
	assert.equal(v.pattern, ".git/**");
});

test(".env* is protected: ask for .env and .env.local", () => {
	const { ws, classify } = fixture();
	assert.equal(classify(join(ws, ".env"), ws).kind, "ask");
	assert.equal(classify(".env.local", ws).kind, "ask");
	assert.equal(classify(".envrc", ws).kind, "ask");
});

test("file outside the workspace: ask", () => {
	const { ws, classify } = fixture();
	const v = classify(OUTSIDE, ws);
	assert.equal(v.kind, "ask");
	assert.equal(v.category, "outside");
});

test("temp area is writable without prompting", () => {
	const { ws, classify } = fixture();
	assert.equal(classify(join(tmpdir(), "scratch", "out.log"), ws).kind, "allow");
	assert.equal(classify(join("/tmp", "scratch", "out.log"), ws).kind, "allow");
});

test("absolute protected pattern matches an absolute target anywhere", () => {
	const { ws } = fixture();
	const classify = createClassifier({ protectedPaths: ["/etc/hostname"] });
	assert.equal(classify("/etc/hostname", ws).kind, "ask");
});

test("extra writable roots never prompt", () => {
	const { ws } = fixture();
	const classify = createClassifier({ extraWritableRoots: ["/etc"] });
	assert.equal(classify("/etc/hostname", ws).kind, "allow");
});

//#region bash guard
test("bash: chmod on an outside path asks", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier();
	const v = classifyBash("chmod 600 ~/.codex/config.toml", ws);
	assert.equal(v.kind, "ask");
	assert.ok(v.targets[0].includes(".codex"));
});

test("bash: visibly read-only commands on outside paths are allowed", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier();
	assert.equal(classifyBash("cat ~/.codex/config.toml", ws).kind, "allow");
	assert.equal(classifyBash("ls -la /etc/ssl/certs", ws).kind, "allow");
	assert.equal(classifyBash("grep -w token ~/.codex/config.toml", ws).kind, "allow");
	assert.equal(classifyBash("env | grep -i '^DSH_' | sort", ws).kind, "allow");
});

test("bash: writes to temp areas are allowed", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier();
	assert.equal(classifyBash("curl -s https://api.github.com > /tmp/out.json", ws).kind, "allow");
	assert.equal(classifyBash("rm -f /tmp/scratch/x.log", ws).kind, "allow");
});

test("bash: outside path + redirection asks even under a read-only lead", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier();
	assert.equal(classifyBash("echo hi > /etc/motd", ws).kind, "ask");
	assert.equal(classifyBash("cat /etc/hostname > /etc/hostname.bak", ws).kind, "ask");
});

test("bash: command substitution touching outside paths asks", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier();
	const v = classifyBash("KEY=$(grep 'experimental_bearer_token' ~/.codex/config.toml | awk -F'\"' '{print $2}')", ws);
	assert.equal(v.kind, "ask");
});

test("bash: python/node with outside paths ask", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier();
	assert.equal(classifyBash("python3 - <<'EOF'\nopen('/home/he/secret.txt','w')\nEOF", ws).kind, "ask");
	assert.equal(classifyBash("node -e \"require('fs').writeFileSync('/etc/foo','x')\"", ws).kind, "ask");
});

test("bash: workspace-relative commands never prompt", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier();
	assert.equal(classifyBash("npm test", ws).kind, "allow");
	assert.equal(classifyBash("git status", ws).kind, "allow");
	assert.equal(classifyBash("make build", ws).kind, "allow");
});

test("bash: extraBashTokens force an ask", () => {
	const { ws } = fixture();
	const classifyBash = createBashClassifier({ extraBashTokens: ["~/.codex"] });
	assert.equal(classifyBash("cat ~/.codex/config.toml", ws).kind, "ask");
});
//#endregion
