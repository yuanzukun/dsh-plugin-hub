# Changelog

## Unmaintained — 2026-10-07

- **This project is no longer maintained.** Archived: no further releases, fixes,
  or security patches. The code remains available as-is under the MIT License;
  fork it to continue development.

## 0.2.0 — 2026-08-25

- Bash/pwsh guard: under `full-with-approval`, shell commands showing
  evidence of modifying files outside the workspace now require
  per-operation approval too (out-of-workspace path tokens + a write marker;
  visibly read-only invocations and workspace-relative commands pass).
  Static heuristic — errs toward asking; `bashGuard: false` disables it,
  `extraBashTokens` forces asks on listed substrings.
- Classifier: `createBashClassifier`; 8 new bash-guard unit tests (15 total)
  and 5 new harness checks (14 total).

## 0.1.0 — 2026-08-23

- Fourth DSH permission preset `full-with-approval`: session sandbox mode
  `danger-full-access` (unconfined, GPU-capable processes) with per-operation
  user approval for `write`/`edit` targets outside the workspace or matching
  `protectedPaths`.
- Implemented entirely on official extension points: the permission preset
  table is patched by id; the gate is the `tools/pre-execute` waterfall's
  `ask` decision resolved by `ctx.approval` (`allowed-once`). No core package
  edits.
- Configuration: `protectedPaths` (default `.git/**`, `.env*`, `.env/**`) and
  `extraWritableRoots`; absolute patterns match absolute targets.
- Tests: classifier unit tests (7) and an in-process harness against the real
  `@deepseek-ai/dsh-tools` registry (9 checks incl. reject/cancel and
  preset-off paths).
- Tooling: `tools/patch-ui-glyph.mjs` draws the preset's shield-check glyph in
  the core client bundle (upstream gap — value-keyed icon table).
