# 更新日志（CHANGELOG）

> dsh-agent-router 的版本变更记录。格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，版本号遵循[语义化版本](https://semver.org/lang/zh-CN/)。
> 内部注解（提交号 / EV 编号）供追溯，用户可忽略。

## v0.8.1 — 2026-11-07

### 摘要

**预设默认模型播种在宿主 0.2.2 上的断代修复（PATCH）**。核心变化一句话：宿主 0.2.2（cordis 4.1.0）收紧了带 Scoped 过滤的事件投递，`dsh-agent-preset-registry` 对 `agent-preset/selected` 的 cordis 重发射对空会话不再发生（其 `session/event` 监听未带 `{global:true}`，收不到子树外会话载体的事件），插件原依赖该重发射触发的「空白会话切换预设 → 播种默认模型」随之静默失效（0.2.1 / cordis 4.0.5 投递可达，故旧代际正常）。本版把订阅改为与宿主一等消费者同款的 `ctx.on('session/event', …, { global: true })` 直订事件流并按事件类型过滤（P5 单路径，旧订阅删除），并新增**跨代际真树行为臂**测试（真 cordis + 真 dsh-session，append 真事件断言播种全链）防复发。无用户配置项 / 存储格式变更。

### 变更

- **FIX-058｜预设播种订阅换代（session/event global 直订）**
  - `lib/preset-defaults.js`：`agent-preset/selected` 触发源由 cordis 重发射（0.2.1 可达 / 0.2.2 断）改为 `ctx.on('session/event', …, {global:true})` 直订 + `event.type` 过滤，汇入零改动的 `onPresetSelected` 处理器；播种处理器、sessionBlank 判据、序列化队列、异常纪律全部不动。宿主先例：`dsh-api-session-controller/lib/types/state/listener.js`（0.2.2-rc.1 L33，`{global:true}` 直订）。
  - `lib/host-abi/events.js`：`MANAGED_EVENTS` 除名 `agent-preset/selected`（服务端唯一消费者已迁走）；客户端转发白名单镜像 `FORWARDED_EVENT_ALLOWLIST` 保留该条目（客户端 `$on` 面与本案分离）。
- **FIX-058｜跨代际真树行为臂（新增 `tests/host-event-chain.mjs`，第 25 套件）**
  - 目标树真包动态导入 cordis + dsh-session，真 `root.plugin(SessionStore)` → 载体 fiber → 会话 append `{type:'agent-preset/selected', data:{agentPreset}}` → 断言播种全链（global 直订收到 → onPresetSelected → selectModel 收到预设配置模型）+ options 突变 / 全局默认净零 / 负向过滤 / dispose 四组守卫。
  - 红绿两态三树实证：0.2.0-rc.2（cordis 4.0.1）/ 0.2.1-rc.2（4.0.5，npm 全局嵌套树）/ 0.2.2-rc.1（4.1.0）——旧订阅形态三树各 6 FAIL，新形态三树各 11/11 PASS。「预设播种事件链」由此进入断代即红的看护面（此前仅 fixture 桩世界覆盖，P10-④ 缺口由此补上）。
- **FIX-058｜既有看护网适配**：`tests/preset-defaults.mjs`（fixture 载荷改 session/event 形态 + `{global:true}` options 断言）、`tests/host-abi-health.mjs`（9a 三事件清单 + 迁移判据）、`tests/host-contract.mjs`（DIRECT_STREAM_EVENTS 白名单类目 + S4 ≥1 处 global 直订正向守卫）、`tests/smoke.mjs`（census 换键并透传第三参——原包装剥 options 的缺陷一并修复）、`tests/fix-052-preset-attribution.mjs`（rig 换形态）。

### 破坏性变更

- 无（`session/event` 直订在 0.2.0 / 0.2.1 / 0.2.2 三代宿主上均为可达面，`{global:true}` 过滤短路在 cordis 4.0.x / 4.1.0 源码逐字同款）。

### 已知行为 / 口径披露

- **客户端预设切换目录刷新在 0.2.2 上延迟**（同根因、插件侧不可独立修复）：`lib/client.js` 的 `preset-switch-directory-refresh` 消费 `$on('agent-preset/selected')` 转发面，其宿主侧事件源即上述已停发的重发射；`session/event` 不在宿主转发白名单内，客户端无法直订。影响 = 模型选择器目录在预设切换后不主动刷新（打开选择器时仍加载最新目录）；服务端播种（本版修复面）不受影响。登记为治理 R 项，宿主上游恢复重发射后自动恢复。

### 验证

- 全量门控 `node tests/run-all.mjs`：**25 套件 + 4 运行器模块全绿**（32.9s，#SKIP 5）。
- 行为臂三树：0.2.2（`.inspect-host/npm-0.2.2-rc.1`）与 0.2.1（npm 全局嵌套树）由协调者独立复跑 11/11 PASS；默认树（0.2.0-rc.2）在全量门控内通过。
- 真机证据链：0.2.1 时代会话日志 `agent-preset/selected` 后紧跟 `model/selection=配置值`（播种生效）↔ 0.2.2 复现会话 15 次选预设零写入（失效）；行为臂以同一 append 形态断言恢复。
- 独立复审：APPROVED_WITH_NOTES（3 处措辞级微瑕已回炉修正；2 项注记分别以本节披露与治理 R 项收口）。

## v0.8.0 — 2026-11-07

### 摘要

**宿主代际升级（0.2.2-rc.1 主基线登记）与声明面/依赖面/客户端面的单源收口（MINOR）**。核心变化一句话：宿主桌面端已跑到 `0.2.2-rc.1`（asar 分发，331 个 `@deepseek-ai` 包全为该代际，cordis `4.1.0`、schemastery `3.19.0`），本版登记该代际并把声明面从「单区间 + 装载门 `includePrerelease` 镜像」改为**按代际并集的 stock semver 口径**（D5），把转发事件镜像补齐到 `0.2.2` 实读的 30 项并接上 `llm/models-updated` 的模型目录刷新（D1），新增**依赖台账**把「用了宿主什么、缺了会怎样、哪条既有断言会红／确无红测的缺口是什么」收敛为单点审计表（D2）。无用户配置项 / 存储格式 / RPC 契约变更。

### 变更

- **D5｜声明面改为逐代并集（stock semver 语义）**
  - `package.json` 的 `engines.dsh` 与 11 项 `@deepseek-ai/dsh-*` 运行时/特性 peer 声明统一为：
    `>=0.2.0-rc.2 <0.2.1-0 || >=0.2.1-rc.1 <0.2.2-0 || >=0.2.2-rc.1 <0.2.3-0`。
  - 起因（实测定性）：单区间 `>=0.2.0-rc.2 <0.2.3-0` 在 **stock semver**（npm / pnpm / 插件市场）下只接纳 `0.2.0-rc.2`，拒绝 `0.2.1-rc.2` / `0.2.2-rc.1`——只有宿主装载门 `semver.satisfies(..., {includePrerelease:true})` 会放行。即「桌面端装得上、包管理器与市场判定失配」，声明面必须逐代各写一段（预发布门槛：仅当比较器与版本同 major.minor.patch 且带预发布时才准入）。`^4.0.1`（cordis）/ `^3.18.5`（schemastery）不变。
  - `lib/host-abi/version.js`：登记 `0.2.2` 档案项（`dsh`/`dshPackages` = `0.2.2-rc.1`，cordis `4.1.0`，schemastery `3.19.0`，`status: primary`），`0.2.1` 由 primary 降为 frozen；免于「新代际未登记即误判」的探测口径不变。
  - `lib/host-abi/host-packages.js`：11 项 dsh `range` 同步为并集字面量，文件头补「每次登记新宿主代际必须追加同代际段」维护规则与 D5 机理说明。
  - `README.md`：基线集表新增 `0.2.2 primary` 行；声明面段落改写为并集字面量 + stock 语义解释 + 维护规则 + `engines.dsh` 与 peer 逐字一致的要求；漂移示例改为 `0.2.2` 正式版。
  - `docs/cold-install-gate.md`：§5 三方一致凭据改写为并集/结构锁/行级 README 断言族；如实登记两处宿主事实（本机 PATH `dsh --version` = `0.2.1-rc.2`；桌面宿主实测 `0.2.2-rc.1`）。
  - `tests/host-version-snapshot.mjs`：新增 stock 语义最小 semver 实现（`parseSemver`/`compareSemver`/`satisfiesDeclaredRange`）与 §0 自检；正例（3 个支持代际全部满足）+ 负例（`0.2.3-0`/`0.2.3`/`0.3.0`/`0.1.5-rc.2`/`0.2.1-alpha.5` 均不满足）+ **结构锁**（并集段数 === 支持代际数、每段下界由该代际档案项推导、每段准入自身 `dshPackages`）+ README 行级四值比对。
- **D1｜客户端转发事件镜像与模型目录刷新对齐 0.2.2**
  - `lib/host-abi/events.js`：`FORWARDED_EVENT_ALLOWLIST` 由 28 项补到 **30 项**，新增 `llm/models-updated`、`plugin-manager/update-state`（0.2.2 宿主 `dsh-api-remotes/lib/types/remote-events.js` 实读新增；`dsh-llm/lib/typert.host.js` 同步出现双签名）。
  - `lib/client.js`：浏览器镜像 `FORWARDED_EVENT_ALLOWLIST` 同步 30 项；`settings-page-models` 消费者新增 `llm/models-updated` 订阅——模型目录变更即刷新设置页模型列表（此前只在打开页面/30s 兜底轮询时刷新）；`tests/served-client.js` 逐字副本同步（SHA256 一致性由客户端 parity 断言锁定）。
  - 事件代际注记（`since`）逐项在位，`tests/host-contract.mjs` S7 7a 按所选基线派生期望集，`0.2.1` 以下不会把新增事件计入期望。
- **D2｜依赖台账（新增模块，单点审计面）**
  - 新增 `lib/host-abi/dependency-ledger.js`：`DEPENDENCY_LEDGER` 为 **36 条**冻结记录（13 宿主供给包 + 11 ctx 服务 + 9 fiber 注入面 + 3 客户端注入包），每条含 `kind` / `level`（`required`|`optional`）/ `evidence`（消费者文件 + 缺失/降级后果 + 红测断言名／缺口登记）/ `since`；**12 条 `required` 中 7 条点名了既有断言名（逐字核对存在），`llm` / `settings` / `fs` / `remote` / `slots` 5 条经缺面夹具实读 + 全绿实测确认：既有用例只断言降级信封 / 形状门控 / 探针记 missing，在该面缺失时仍绿（无一变红），故显式登记 `redTest: null` + `redTestGap`（原因 + 补测方向），并冻结进 `RED_TEST_GAPS`**；文件头记录 4 个来源清单、level 语义、「新增宿主面必须同步台账」「红测缺口只许显式登记/补测后同批删除」维护规则。`lib/host-abi/index.js` 桶导出 `DEPENDENCY_LEDGER` 与 `RED_TEST_GAPS`。
  - `tests/host-abi-health.mjs` 新增 §6g `B1-a`…`B1-m` 看护：条目数量与集合（对 4 个来源清单取并集恰 36）、`kind` 分布（13/11/9/3）、**B1-k1 对全部 36 条要求 `evidence` 含 `lib/*.js` / `package.json` 消费者路径与 `→` 后果；B1-k 对 12 条 `required` 再要求「点名 `tests/*.mjs` 且文件存在」或「`redTestGap` 非空」或「`RED_TEST_GAPS` 登记」三选一（缺一即判红并点名越界 id，无静默空档）；B1-k2 锁 `since` 必须命中 `HOST_BASELINE_REGISTRY` 代际；B1-k3 冻结缺口清单（5 项、双向核对 `redTest: null` + 非空 `redTestGap`，补测后漏删即红）**、required/optional 分级锁定（`llm`/`settings`/`fs` ctx、`slots`/`remote` fiber、`dsh-client-ui-settings`/`dsh-api-remotes` 客户端包必须 `required`）。
  - `tests/host-abi-health.mjs` 9h 锚清单登记该文件（`stale: []` + 代表性 evidence 锚串），新增含行号证据锚的文件不会在被 9h-5 覆盖率判据红。

### 破坏性变更

**声明面 MINOR（0.8.0）**：`engines.dsh` 与 11 项 dsh peer 的范围形态由单区间改为并集；这是**放宽**（新增 `0.2.1`/`0.2.2` 代际准入），不是收窄——`0.2.0-rc.2` 仍在范围内。`peerDependenciesMeta`（8 项 optional）与 `dependencies`（仅 `undici`）零改动；无配置项 / 存储格式 / RPC 导出面变更。

### 验证

- 全量门控（默认不设 `DSH_BASELINE`，主基线 = `0.2.2`；本机默认靶子 = npm-global `0.2.1-rc.2`）：`node tests/run-all.mjs` = **ALL 24 SUITES + 4 RUNNER MODULES (via smoke.mjs) PASSED, 50.0s, exit 0, `#SKIP 5`（`host-contract`×3、`smoke`×2）**。
  - `host-contract` 168 assertions + 3 skip；`host-version-snapshot` 97 assertions（含 stock 正/负例与结构锁）；`host-abi-health` 242 assertions（含 `B1-k1`/`B1-k`/`B1-k2`/`B1-k3` 四条台账判据）。
- 目标树边界（如实登记）：本机 PATH/npm-global 宿主树仍是 `0.2.1-rc.2`（28 项事件），与主基线 `0.2.2` 不一致；`host-contract` S3/S7 按**靶子树 package.json 实读版本**派生期望，故 target≠baseline 告警与 2 项 `0.2.2` 新事件（`llm/models-updated`、`plugin-manager/update-state`）以 `#SKIP` 可见跳过，不静默判过。**三靶均已实跑（Coordinator 亲跑，2026-11-07）**：① npm 形态 `0.2.2` 树（`.inspect-host/npm-0.2.2-rc.1`）→ `node tests/run-all.mjs` = ALL 24 SUITES + 4 RUNNER MODULES PASSED，50.5s，`#SKIP 2`（仅 `smoke`×2），exit 0（类型锚真验，`host-contract` 零 skip）；② 桌面 asar 真机依赖图 `0.2.2`（`--prefix dsh/node_modules` 抽取，331 包 + 裸依赖完整）→ 同上全绿，50.2s，`#SKIP 9`（`host-contract`×7 = bundled 形态 `.d.ts` 面可见跳过 + `smoke`×2），exit 0；③ 默认靶子（npm-global `0.2.1-rc.2`）同轮复跑亦全绿（50.0s，`#SKIP 5`）。桌面 `0.2.2-rc.1` 为 asar 分发（整树无 `.d.ts`），其声明面符号在该形态下不可验。`DSH_BASELINE=0.2.1` 复跑同为 24 套件 + 4 runner 全绿（`host-contract` 2 skip）；无效基线 `DSH_BASELINE=0.9.9` fail-closed（`1 FAILURE(S) (19 passed)`，exit 1）。
- 声明面判别力：`0.2.3-0` / `0.2.3` / `0.3.0` / `0.1.5-rc.2` / `0.2.1-alpha.5` 全部判不满足；`0.2.0-rc.2` / `0.2.1-rc.2` / `0.2.2-rc.1` 全部判满足（stock 语义，无 `includePrerelease`）。
- 结构锁判别力：并集段数 = 支持代际数（3）；新增代际漏追加段、段下界与档案项不符、段数漂移任一即红（`tests/host-version-snapshot.mjs` §0d）。

## v0.7.1 — 2026-10-25

### 摘要

**v0.7.0 的审查非阻塞项收口（PATCH）**。核心变化一句话：v0.7.0 的桌面端启动故障修复与宿主包代际诊断经**独立 Code Reviewer** 审查为 `APPROVED_WITH_NOTES / unresolved_blockers=0`，本版把审查提出的 **5 项 P2 全部收口**（逐包不可判定可观测性、import 边界对多行/`require`/动态 `import()`/递归子目录的覆盖、`optional`/`bundled` 依赖旁路、宿主面桩锚定宿主源码、`apply` 接线守卫），并顺手修掉 5 项 P3。**产品对外行为、声明面与用户配置面与 v0.7.0 完全一致**——本版只增强看护强度与诊断完整性。

### 修复（审查 P2 收口）

- **P2-1｜逐包不可判定必须可观测（P8）**：v0.7.0 的 `noteHostGeneration` 对「某一侧读不到版本」的包**静默跳过**，与文件自述「不可判定 ≠ 一致」自相矛盾。本版在 mismatch 事件之外新增正交事件 `host-package-generation-unknown` / `unresolved-host-package`（detail 列出不可判定的包名），遮蔽与读不到同帧各自入 health 环形。
- **P2-2｜S10 import 边界判别力（P4/P5）**：旧实现只匹配同一行 `import … from`，多行 import、`require()`、动态 `import()` 与更深子目录均可绕过——「新增裸 import 即红」属过度声称。本版改为 dotAll 容忍多行、显式覆盖 `require()`/`import()`、扫描面升级为 **`lib/` 递归全树**，并新增「扫描面非空且含 host-abi 子目录」的自证断言（守卫不得空转）。
- **P2-3｜纯净性旁路通道**：v0.7.0 只断言 `dependencies` 零 `@deepseek-ai/*`；`optionalDependencies` 与 `bundledDependencies` 同样会被安装器装进 profile 根（同形故障、不同通路）。两套件（`host-version-snapshot` / `host-contract` S3）同时补锁这两条旁路，`dependencies` 的键序敏感断言改为集合比较。
- **P2-4｜宿主面桩锚定宿主源码（P10-④）**：域 8 的代际自检依赖宿主两条**不同**的解析路径（宿主侧裸路径序 / 插件侧替换层路由）。v0.7.0 的测试桩没有锚定宿主源码，宿主重构后探测会静默退化为 unknown。本版在 `host-contract` S7 增补 5 条宿主源码锚：`packageDirFromAnchor` 的裸路径序、`manifestOf` 优先问 `pluginPackages.packageOf`、`PluginPackages.packageOf` 经 `interception.packageDir` 路由、`profileContext.installAnchor` 提供点（按 `profile-boot*` 前缀枚举定位，禁写死内容哈希）、`unmetRequirements` 的 `engines.dsh` 优先级。宿主不可达/部分树 → 可见 skip（BR-03 语义）。
- **P2-5｜`apply` 接线守卫**：v0.7.0 无测试断言 `apply()` 真的调用了 `noteHostGeneration`——删掉接线三套件仍全绿。本版新增静态断言（`apply` 块内必须含 `noteHostGeneration(ctx)`）。

### 变更（审查 P3 收口）

- `lib/schemas.js` 改为直接 import `./host-abi/host-imports.js` 而非桶入口：公开子路径 `./schemas` 不再连带引入 `version`/`health`/`ctx-services` 等 Node-only 图（今天无浏览器消费者，但契约模块不应无谓扩大依赖图）。宿主包 import 单点出口（S10）不变。
- `lib/host-abi/version.js` 注释同步（宿主包自 v0.7.0 起为 `peerDependencies`，不再称 `dependencies`）。
- 措辞如实化：CI 段「与宿主装载门同构」的表述收窄为「宿主侧同构、插件侧经替换层路由」的准确说法。

### 破坏性变更

**无。** 分项依据：① 无任何用户配置项、存储格式、插件导出面或 RPC 契约变更（本版改动集中在诊断事件、测试断言与注释）；② 诊断事件是**新增**的事件种类，既有 `router/hostFaceDiagnostics` 载荷结构不变；③ 声明面零改动（13 项 peer + `engines.dsh` 与 v0.7.0 一致）。

### 已知行为 / 口径披露

- **诊断面会多出一条事件**：若某侧宿主包版本读不到（如部分树/权限受限），健康面板诊断环形会新增 `unresolved-host-package` 条目——这是诚实披露而非故障；它与此前静默跳过相比是行为增强。
- **审查未覆盖项（如实登记）**：R0 审查为**有界**审查（时间盒 ≈8 min），明确 `NOT_RUN`：全量 `run-all`（本版发布前由 Coordinator 实跑绿）、A/B 装机复现、桌面端真机复跑（v0.7.0 已做，本版代码路径未触及启动面）。负控实验在本版由 Coordinator 补做并留证（见「验证」）。
- **版本位**：0.7.0 → **0.7.1**（PATCH：纯看护/诊断增强，无功能面与声明面变更）。

### 验证

- 全量门控：`node tests/run-all.mjs` = **ALL 23 SUITES + 4 RUNNER MODULES PASSED，exit 0，`#SKIP 2`**（既有 win32 环境性 skip）。
- 三套件断言数变化：`host-version-snapshot` 73 → **74**；`host-contract` 160 → **168**（新增 5 条宿主源码锚 + 2 条旁路/接线断言 + 1 条扫描面自证）；`host-abi-health` 223 → **224**（新增 R3-g）。
- **负控（判别力实证，全部字节还原恒等）**：① 向 `lib/memory.js` 注入多行 `import { … } from '@deepseek-ai/dsh-tools'` → S10 恰 1 FAIL；② `package.json` 注入 `optionalDependencies: {"@deepseek-ai/dsh-tools": …}` → snapshot 恰 1 FAIL；③ 注释掉 `apply` 内 `noteHostGeneration(ctx)` → S10 恰 1 FAIL；三者还原后全套绿。
- **CI 回归修复（发版前拦下，两次推送两轮定位）**：首推后三基线矩阵 job 全红——新增的域 8 宿主源码锚直接 `readFileSync` `dsh-app-boot`，而 CI pinned 宿主树 = `HOST_KEY_PACKAGES` 8 包、刻意不含该包 → 裸抛 `ENOENT` 击穿套件（本批自伤的 fail-safe 违约：仓库纪律是「部分树 = 可见 skip」）。修一：4 条 `dsh-app-boot` 锚加 `existsSync` 守卫 → 缺失记可见 skip。修二：`0.1.5` 矩阵仍红——`profile-boot` 在该代际尚无 `installAnchor`（机制定型于 0.2.x），锚未按基线分代 → 整套域 8 锚加 `baselineIncludes('0.2.0')` 分代门（低于该代际记可见 skip，禁把「机制尚未存在」误判成「机制漂移」，与 S8/S8b/S9b 既有分代纪律同构）。**三代复跑全绿**：完整树 168 断言 0 skip / CI 同形部分树（8 包 junction、无 `dsh-app-boot`）153 断言 + 4 可见 skip / `DSH_BASELINE=0.1.5` 145 断言 + 9 可见 skip。

## v0.7.0 — 2026-10-25

### 摘要

**桌面端启动故障根因修复 + 宿主依赖面收敛（MINOR）**。核心变化一句话：**宿主包（`@deepseek-ai/dsh-tools` 等）此前被写在 `dependencies`，桌面端 profile 用 `nodeLinker: hoisted` 装插件时 pnpm 把它们提升到 profile 根 `node_modules`，宿主装载门据此把核心行 `tools` 判为「与运行宿主代际不兼容」并 disable，required 的 `agent-loop` 永久 pending ⇒ `startup failed: 1 required plugin did not activate`，桌面端完全无法启动；本版把 5 个宿主包从 `dependencies` 迁入 `peerDependencies`（另加 `engines.dsh` 单字段运行时契约），新增 host-abi 域 8 收敛宿主耦合面并让遮蔽类故障可观测**。声明面语义变更（安装形态），无用户配置/存储格式变更。

### 修复

- **FIX-057：桌面端安装插件后启动失败（P0，用户报障）**
  - **症状**：桌面端（`@deepseek-ai/dsh-desktop 0.2.1-rc.3`）装上本插件后启动即弹「The application could not start or stopped unexpectedly」，错误详情为 `startup failed: 1 required plugin did not activate` + `agent-loop (required) → tools` / `cordis-inspect-providers → cordisInspect, tools` 等 8-9 行「等待服务」表；点「Disable third-party plugins, back up profile patch, and restart」**仍不恢复**（重启后 8 行等待表照旧）。
  - **根因（一手机制，实测证据链）**：本插件把 `@deepseek-ai/{cordis,schemastery,dsh-llm,dsh-tools,dsh-typert-protocol}` 声明为 `dependencies`。桌面端 profile（`%USERPROFILE%/.dsh/profiles/desktop`）的 `pnpm-workspace.yaml` 为 `nodeLinker: hoisted`，pnpm 因此把这 5 包及其闭包（共 10 个 `@deepseek-ai/*` 目录）**提升到 profile 根 `node_modules`**；宿主 `dsh-app-boot` 的装载门链路 `prepareProfileEntries` → `preflight` → `manifestOf` 用 `createRequire(profile/cordis.yml).resolve.paths(...)` 做**未经运行时替换层拦截**的最近副本解析，于是核心行 `tools`（`@deepseek-ai/dsh-tools`）解析到 profile 里那份 `0.2.0-rc.2`，而运行宿主是 `0.2.1-rc.3` → `evaluatePluginCompatibility` 判不兼容 → 该行被 disable（宿主 stderr 原文：`dsh: disabling profile plugin row "tools": Plugin @deepseek-ai/dsh-tools@0.2.0-rc.2 is incompatible with dsh 0.2.1-rc.2 …`）→ `tools` 服务永不发布 → required `agent-loop` 永久 pending → 启动失败。桌面端崩溃报告只截取「等待表」，该 stderr 行不在报告内，因此症状表现为「核心插件莫名等待」。「禁用第三方插件」只重置 bundle 选择与用户补丁层，**不动依赖树**，故被提升的副本仍在、故障不解除。Web 端不受影响的原因：web profile 用 `link:D:/AI/.../router` 装插件，pnpm 不安装 link 依赖的依赖树，profile 根没有宿主包副本。
  - **证据（A/B 隔离实测，v0.7.0 开发期）**：以 `DSH_HOME` 隔离复刻桌面端 profile 形态——① 保留被提升的 `@deepseek-ai/*` → 逐字复现 `disabling profile plugin row "tools"` + 同形 `startup failed` 8 行等待表，exit 1；② 移走该目录 → 同一 profile 正常 `dsh web: http://127.0.0.1:…` 起服。装配层面的机制证实后本版实施修复。
  - **修复**：`package.json` 中 5 个宿主包全部由 `dependencies` 迁入 `peerDependencies`（`cordis` / `schemastery` 为平台包、`dsh-llm` / `dsh-tools` / `dsh-typert-protocol` 为运行时包），`dependencies` 仅保留真正自有的 `undici`；同 5 包改入 `devDependencies` 以维持本仓开发/测试树。**安装形态实测（生产形态复验）**：`npm pack` → `pnpm add <tgz>` 装入桌面端 profile 后，profile 根 `node_modules/@deepseek-ai` 为**空目录**（修复前 10 个包），`dsh.profile.bundles` 挂回 `dsh-agent-router` 后 `--dump-config` 显示 `tools` / `router` / `tool-router` 三行 `disabled=False`，宿主启动零 `disabling profile plugin row` 警告。
  - **本机处置（已执行，可回退）**：profile 五件套（`package.json` / `cordis.patch.yml` / `cordis.yml` / `pnpm-lock.yaml` / `pnpm-workspace.yaml`）备份至 `~/.dsh/backups/desktop-profile-pre-0.7.0-<时间戳>/`；`pnpm remove dsh-agent-router` 清掉被提升的宿主包副本 → 桌面端形态恢复可启动；随后以 0.7.0 发行包重装并把 `dsh-agent-router` 挂回 `dsh.profile.bundles`；用户补丁层自 `cordis.patch.yml.bak-*` 原样还原（「禁用第三方插件」动作留下的备份，即该动作的撤销）。重装 spec 暂为本地 tarball（`file:`），GitHub 发行后可用 `dsh plugin --profile desktop remove/add` 归一为 `github:peterwangze/dsh-agent-router`。

### 变更

- **宿主依赖面收敛（host-abi 域 8，降耦合演进）**：
  - 新增 `lib/host-abi/host-packages.js`：宿主供给包的**唯一代码侧事实源** `HOST_PACKAGE_REGISTRY`（13 项，逐项标注 `kind`（runtime / platform）、`usage`（import / service / structure）、`range`、`optional`）+ 宿主包**代际自检**（`hostGenerationReport` / `noteHostGeneration`：宿主侧用与宿主装载门同构的裸路径序探测读「安装副本」，插件侧取**经宿主运行时替换层路由后**的实际解析结果（`pluginPackages.packageOf` 优先、CJS `require('<pkg>/package.json')` 兜底）；两侧代际不一致 → `host-package-generation-mismatch`，安装锚缺失或无替换层服务 → 能力缺失事件；均入 health 环形经既有 `router/hostFaceDiagnostics` RPC 下发——P8：遮蔽类故障不再只能靠「起不来」暴露）。**两侧必须用不同探测机制**这一点是实测教训：插件侧若改用裸路径序，会命中 `$DSH_HOME/profiles/node_modules`（脚本通道扁平宿主树，0.2.1-rc.2），与桌面端宿主 0.2.1-rc.3 天然不同代，**每次启动误报遮蔽**；该语义由 `tests/host-abi-health.mjs` R3 组以构造性夹具双向锁定（无服务→恰零 mismatch 的误报防线 + 两侧不一致→命中并落诊断的漏报防线）。该域**零宿主 import**（只读 package.json 元数据），保证探测在任何宿主代际下都不会自身崩栈。
  - 新增 `lib/host-abi/host-imports.js`：**本插件对宿主包的唯一静态 import 出口**（`defineTool` / `BlockAssembler` / `createUserMessage` / `createAssistantMessage` / `TypertRemoteService` / `z`）。`lib/tool.js`、`lib/prestep.js`、`lib/service.js`、`lib/schemas.js` 四处原本散落的 `@deepseek-ai/*` 裸 import 全部改为经 host-abi 桶导入——宿主 API 漂移/包改名/代际切换的改动面收敛到一处。
  - `package.json` 新增 `engines.dsh = ^0.2.0-rc.2`：宿主 `dsh-app-boot` 的 `unmetRequirements` 语义为「自身 `engines.dsh` 存在则单独判定、忽略 peer 判定」，故这是装载门的**权威输入**；与 11 项 `@deepseek-ai/dsh*` peer 的共同范围**逐字相同**（两套范围分叉即被测试判红）。
  - 版本面：0.6.2 → **0.7.0**（MINOR：安装形态/声明面语义变更 + 新增诊断能力面，非纯缺陷修复）。

### 破坏性变更

**结论：无破坏性变更（用户可见功能面与 v0.6.2 一致；变更为安装形态与声明面语义）。** 分项依据：① 无新增/删除/改名任何用户配置项与存储格式——统计 JSONL、凭据文件、`oauthAccounts` 结构、settings namespace `router` 字段全部不动；② 插件导出面（`main` / `./tool` / `./client` / `./schemas` / `./rpc`）与 RPC 契约 `/api/router/*` 零改动；③ 声明面变更方向是**收窄安装耦合**：宿主包由「插件自带副本」改为「宿主供给」，运行时代码不变，仅在宿主缺少对应包时由宿主装载门/服务注入面按既有语义降级；④ `engines.dsh` 与既有 peer 共同范围一致，支持的宿主代际不变（`^0.2.0-rc.2` 覆盖 0.2.0 / 0.2.1 系，含桌面端 0.2.1-rc.3）；⑤ 已装用户的升级路径 = 重装即自动清除被提升的宿主包副本（`pnpm remove/add` 触发 prune），无需手工删目录。

### 已知行为 / 口径披露

- **桌面端 profile 由 Electron 应用独占管理**：`dsh` CLI 对 `--profile desktop` 的 boot 与 `plugin` 命令显式拒绝（`error: profile "desktop" is managed exclusively by the Electron application`）。本机处置阶段对 profile 的依赖树操作因此直接调用宿主同版本 pnpm（`resources/runtime/primary-runtime/dependencies/pnpm`，v11.28.5），未走 CLI 转发路径；`dsh.profile.bundles` 与用户补丁层为直接编辑（与桌面端插件管理器写入同形）。
- **`link:` 安装形态的宿主代际差异（开发场景，未变）**：本仓 `node_modules` 由 `devDependencies` 供给宿主包（当前 0.2.0-rc.2），故 web profile 的 `link:` 安装下插件解析到的是**开发树副本**而非宿主副本；这是开发形态而非发布形态（发布形态为零副本、经宿主运行时替换层路由）。新增的代际自检会把该差异如实记为 `host-package-generation-mismatch` 诊断事件——属**预期观测**，不是故障。
- **`engines.dsh` 与 peer 判定的优先级**：宿主实现为「`engines.dsh` 存在则单独判定，peerDependencies 被忽略」。因此本版之后，支持面判定的权威输入是 `engines.dsh` 一处；11 项 peer 范围退为安装期可观测性声明（与本版前「peer 即门控钥匙」的语义不同，README 已同步改写）。
- **审查台账（随本版入册，非阻塞）**：① 本版未新增「装包→boot」端到端自动化测试（需要 pnpm 与真实 profile，属发布链/真机验收范畴）；机制回归保障改为静态双守卫（`tests/host-version-snapshot.mjs` 断言 `dependencies` 零 `@deepseek-ai/*` + 注册表投影值级锁定；`tests/host-contract.mjs` S3/S10 断言声明面纯净性与 import 单点），并把「装配形态实测」留证于本 CHANGELOG 与发布验收。② 治理插件（`software-project-governance` skill）在本会话不可用（skill 目录未加载），本版条目编号（FIX-057 / REL-015）为会话内自定、**未经治理流程机录**——`plan-tracker` / `decision-log` / EVD 记录待治理环境可用时补齐。

## v0.6.2 — 2026-10-22

### 摘要

**图片轮 reminder 来源标记与宿主 v4 会话格式对齐（P0 热修，PATCH）**。核心变化一句话：**v0.6.1 在宿主 0.2.1-rc.2 下「文字模型发图 → 接管 `+多模态` → 发送」会整轮失败（宿主报 `format v4 message requires a producer-owned source kind`）——本版把插件 pre-step reminder 的来源标记从宿主 v4 已不接受的 `plugin` 改为 producer-owned 的 `plugin:dsh-agent-router`，图片轮恢复可发送**。纯缺陷修复：无新增能力面、无破坏性变更、声明面（11 项 dsh 依赖声明）零改动。

### 修复

- **FIX-054：图片轮 pre-step reminder 被宿主 v4 会话格式拒收导致整轮失败（P0，用户场景）**：
  - **症状**：用文字模型（非原生多模态主模型）的会话中发送图片 → 插件按既有条件接管、切换为 `+多模态` 包装路由 → 消息发送后**本轮运行失败**，宿主侧报 `format v4 message requires a producer-owned source kind`；用户视角为「加了图就发不出去」。
  - **根因**：本机实测宿主 0.2.1-rc.2（v4 会话格式）对 v4 会话行执行 producer-owned source kind admission（运行时验证覆盖 = 0.2.1-rc.2 主基线；0.2.0 / 0.1.5 由 CI 三基线矩阵后置覆盖，本版未作运行验证）——只接受 producer 自有的 direct kind，**不再接受 catch-all `plugin`**；而插件唯一写入 reminder 的点 `lib/prestep.js` 的 `buildReminderMessage` 仍写 `source.kind='plugin'`。宿主 v3→v4 会话迁移对本插件（未登记第三方插件名、非改名）的映射口径是 `plugin:<插件名>`，即 `plugin:dsh-agent-router`。
  - **修复**：`lib/prestep.js` 新增单点常量 `REMINDER_SOURCE_KIND = plugin:${PLUGIN_NAME}`（求值 = `plugin:dsh-agent-router`，与 `PLUGIN_NAME` / `lib/index.js` / `cordis.patch.yml` 现有名称同源），`buildReminderMessage` 的 source 引用该常量；判别测试与 5 个测试套件（`tests/smoke.mjs` / `tests/metrics.mjs` / `tests/routing-paths.mjs` / `tests/fix-010-gui-fidelity.mjs` / `tests/fix-029-host-contract.mjs`）断言同步收紧为「精确新 kind + 非空 + source 无 `plugin` 字段」，旧实现下各套件至少一条必红。
  - **影响面**：仅 reminder 消息的 source 元数据（单写入点、单调用点）；除 reminder source 元数据写入点外，客户端与服务端其它逻辑零改动，无数据迁移（旧 v3 会话由宿主迁移为同形 kind，`client.js` 不消费 `source.kind`）。（内部注解：`4bed2d3`；REVIEW-FIX-054-R0 为 APPROVED_WITH_NOTES / unresolved_blockers=0，P2×2 + P3×4 入台账非阻塞。）

### 破坏性变更

**结论：无破坏性变更。** 分项依据：① 纯缺陷修复——不含新功能、接口变更或用户可见行为变更（图片轮从「整轮失败」恢复为可发送，属修复方向）；② **用户配置 / 存储格式零变更**：不新增、不删除、不改名任何配置项，统计 JSONL、凭据文件、`oauthAccounts` 结构不动；③ **声明面零改动**：11 项 dsh 依赖声明（8 peer + 3 dependencies）与 `peerDependenciesMeta` 不变，装载门支持面不变；④ 改动仅 reminder 消息 source 元数据一处，客户端镜像与 RPC 面零改动；⑤ 旧会话无需迁移——宿主 v3→v4 迁移产出同形 `plugin:` kind。

### 已知行为 / 口径披露

- **宿主 v4 会话格式要求 producer-owned kind（无 catch-all `plugin`）**：本版起插件 reminder 写 `plugin:dsh-agent-router`；该格式由宿主 v3→v4 迁移映射表定义（「其他任何插件名 → `plugin:` 后接完整原始名称」），本插件新写入即用该形态——保证新旧会话 kind 单一形态、不引入裸名与 `plugin:` 并存的第二形态。
- **升级雷达 issue #1（alpha 通道）保持打开**：宿主 alpha / next 预发布通道仍由周频雷达持续观测；本版不吸收 alpha 通道，待后续版本按宿主升级 SOP 定性后处置。
- **另：用户报告「原生多模态模型贴图仍被切 +多模态」为独立待复测观察**（与本次 v4 会话格式崩溃非同线；已记录于 plan-tracker 待办项）——待用户重装后复测取证；若复现将独立立案，本版修复不声称覆盖该观察。
- **审查台账（非阻塞，随 FIX-054 入册）**：P2×2——① 5 个测试套件中的 `isProducerOwnedSource` 为宿主 admission 谓词的镜像（未 import 宿主真实模块；建议后续在 host-contract 增真实 admission 合约测试；已立项 FIX-055 承载：真实 admission 合约测试 + 插件名单源/锚守卫）；② `docs/**` 两处 FIX-054 文案不在 6 文件修复提交内，承载提交归属由 Coordinator 处置（不在本三件套范围）。P3×4（宿主行号锚无机器守卫 / 插件名三处字面量无相等守卫 / 测试标题历史措辞 / 5 套件常量副本有意独立 oracle）均为卫生项，不阻塞发布。

### 版本说明

- **版本号**：0.6.1 → **v0.6.2**（**PATCH 位**）。依据：纯缺陷修复（P0 热修）——无新增能力面、无破坏性变更、声明面零改动；按语义化版本取 PATCH 位。**发布链任务定版 PATCH 候选 0.6.2（2026-10-22），E-4 Release Reviewer 保留独立升降位建议权**。**日期口径**：本节日期 2026-10-22 = 发布候选定版与发布三件套（E-1）时点。
- **发布范围**：v0.6.1（tag `a86883b`）以来 main 全部提交——E-1 时点实采 **3 个**（复核命令与产出：`git rev-list --count v0.6.1..HEAD`）：**产品 / 发布面提交 1 个** = FIX-054 热修 `4bed2d3`（`lib/prestep.js` + `tests/**` 5 文件，+112/−16，全修复面）；**治理提交 2 个** = `217f037`（REL-013 v0.6.1 发布收尾：EVD-5 机录 / RECO-REL-013 推荐快照 / tracker 终态与版本路线图 / session-snapshot）/ `c259751`（REL-013 收尾治理入仓：EVD-3 / EVD-4 / REVIEW-REL-013-R0·R1 机录 / DEC-35 / TRIAGE-FIX-053 等；另含 `docs/cold-install-gate.md` 第 5 节 ARCH-006 口径勘正——文档面，零产品行为）——两者不承载用户可见变更，不入用户面。**结论行：产品 1 + 治理 2 = 3 = E-1 时点实采；本 E-1 提交落地后 = 4（改动面为版本声明与文档，不承载产品行为）；产品提交在「修复」节语义全覆盖。**
- **验证基线**：E-1 时点本地全量门控实测（Windows 真实基线口径 `cmd /c "chcp 65001>nul && node tests/run-all.mjs"`）= **ALL 23 SUITES + 4 RUNNER MODULES (via smoke.mjs) PASSED，`#SKIP 2 (smoke.mjs×2)`，exit 0（32.1s）**；skip 明细 = win32 `0o600` 权限位不可判定 1 条 + 无 sh / curl 时 POSIX 在线臂 1 条（**历史上 smoke 恰 2 条 sh 臂环境性失败本时点未复现，如实记录**）。**E-2 发布门控复跑 / E-3 隔离环境安装冒烟（环境变量重定向至临时目录）/ E-5 资产终验由发布链机录，本节不预填数字**（不写入 tarball 字节数 / sha256——资产由 tag 树重打，定值以 E-5 实测为准）。**E-4 发布审查结论不在本节预填**（由 `review-record` 机录承载）。

## v0.6.1 — 2026-10-20

### 摘要

**宿主 0.2.1-rc.2 基线档案刷新版（PATCH）**。核心变化一句话：**把宿主 0.2.1-rc.2 从「未实测宿主版本」吸收为已测主基线——基线档案追加 0.2.1 primary（原 0.2.0 降档 frozen，恰一 primary 断言保持），转发事件白名单 27→28、`llm.listConfigurableProviders` schema 白名单 6→9 字段随宿主超集增量对齐；同步演进声明面覆盖判据与 patch 感知分代谓词，使声明面与基线代际继续被机器看护。插件声明面 `^0.2.0-rc.2` 与插件消费面均零改动——本版全 additive，无破坏性变更、无新增功能**。

### 变更

- **🛰 宿主基线档案刷新（ARCH-006）**：`HOST_BASELINE_REGISTRY` 追加 `0.2.1`（status=primary），`0.2.0` 由 primary 降档 frozen（状态词表仅 frozen / primary，不臆造新状态）；「恰一 primary」不变式断言保持。五个消费面单源跟随：`tests/host-contract.mjs` 的 marker 提取断言 / `.github/workflows/ci.yml` 的 `resolve-baselines` 派生三基线矩阵（yaml 零版本字面量，自动新增 0.2.1 矩阵 job）/ `tests/host-radar.mjs` probe 的 `totalDiffs=0`（包表 10/10 match）/ `lib/host-abi/version.js` 投影与快照权威的值级锁定（`tests/host-abi-health.mjs` R2-a 解析快照权威 ↔ import 投影逐项 canonical 比较，覆盖整个数组含新条目）/ `tests/host-version-snapshot.mjs` 三基线档案（内部注解：`6bbf78b`；CI run `39392930138` 五 job 全绿；REVIEW-ARCH-006-R0）。
- **📡 转发事件白名单 27 → 28**：追加 `plugin-market/changed`（`since` 分代 = 0.2.1）；`lib/host-abi/events.js` / `lib/client.js` / `tests/served-client.js` 三镜像逐字节恒等同步；0.2.0 / 0.1.5 代基线下该事件记可见 skip、不误红（分代复跑：`DSH_BASELINE=0.2.0` → 126 断言 + 4 可见 skip 零红 / `0.1.5` → 123 断言 + 6 可见 skip 零红）（内部注解：`6bbf78b`；REVIEW-ARCH-006-R0）。
- **🧾 `llm.listConfigurableProviders` schema 白名单 6 → 9 字段**：宿主 0.2.1 结果的超集增量 `defaultBaseURL` / `baseURLEnv` / `nativeAuth` 入白名单（字段序与宿主 `dsh-api-remotes` 源码声明逐序恒等）；插件消费面仍只用旧 6 字段子集（`lib/` 对新三字段零消费）——消费代码零改动（内部注解：`6bbf78b`；REVIEW-ARCH-006-R0）。
- **🧭 两项判据语义演进（看护强度不降）**：① 声明面判据由「逐字相等」演进为**覆盖判据 `declaredRangeCovers`**——镜像宿主装载门 `semver.satisfies(runtimeVersion, range, { includePrerelease: true })` 一手锚（宿主 `dsh-app-boot` 源码），使 `^0.2.0-rc.2` 声明面覆盖新主基线 `0.2.1-rc.2`；防回退负控全红实证（回退 `^0.1.5-rc.2` / `^0.1.0-rc.1` / 假 `^9.9.9` / 越顶 `^0.3.0-rc.1` 判红；分裂 / 缺失范围判红；未注册锚定值 README 判据组红；审查员独立求值 6 例符合预期），声明面零改动（`^0.2.0-rc.2` ×11）。② 分代谓词由 `minorOf` 演进为 **`versionTripleOf`（patch 感知）**——`since=0.2.1` 对 `target=0.2.0` 的错向判定修正（旧谓词把 0.2.0 树假红）；既有全部 8 个（since × target）组合新旧谓词零分歧穷举核验，0.2.0 / 0.1.5 分代复跑零红（内部注解：`6bbf78b`；REVIEW-ARCH-006-R0）。
- **📘 README 版本面与宿主兼容性矩阵同步**：README 版本面（badge / 离线发行包 URL 与 tar 名 / 固定版本示例）0.6.0 → 0.6.1；「宿主兼容性（实测基线）」支持基线集表刷新为 **0.2.1 primary（当前，2026-10-20 npm 全局树实读）/ 0.2.0 frozen（2026-10-17 实读）/ 0.1.5 frozen（历史，2026-09-12 实读）**——三行逐条对应机器档案注册表；安装前置提示同步改为「DSH ≥ 0.2.0-rc.2（声明面支持范围下限；实测主基线 `0.2.1-rc.2`）」。§5 README 判据组要求的声明面锚定项（0.2.0 frozen 四值）仍在位（内部注解：本 E-1 提交）。
- **🛡 定性与处置路径（雷达自动化）**：宿主 0.2.1-rc.2 由升级雷达首窗（run `39228057201`）自动预警（issue #1 alpha 通道 / issue #2 新版本）发现；四类 diff（锚 / 白名单 / schema / 包表）全部 additive、锚 0 漂移 → 按宿主升级 SOP ③「additive 路径」处置（非抢救）；吸收后 issue #2 已关闭，issue #1（alpha 通道）保持打开。ARCH-006 批验收 = `tests/host-contract.mjs` 129 断言绿（原 S7 红转绿）+ probe `totalDiffs=0` + cold-install-gate / a3-apply-gate 双门 GREEN + 三态桩 `matched/0.2.1` 机证（含 `0.2.1-alpha.5` → compatible-unknown / degraded → incompatible 旁路）（内部注解：`6bbf78b` / `265acc1`；REVIEW-ARCH-006-R0 为 APPROVED_WITH_NOTES / unresolved_blockers=0，P3×3 入台账非阻塞）。

### 破坏性变更

**结论：无破坏性变更（全 additive）。** 分项依据：① 基线档案为**数据面追加 + 状态降档**（0.2.1 入册 primary / 0.2.0 转 frozen），不改变插件运行行为；支持面仍由声明面 `^0.2.0-rc.2` 覆盖（0.2.1-rc.2 与 0.2.0-rc.2 均在该范围内，装载门双 GREEN 实证），未收窄。② 事件白名单 27→28、schema 白名单 6→9 均为**宿主超集对齐**；新增事件 / 字段对旧代宿主按分代记可见 skip，插件消费面零改动。③ 两项判据变化仅在看护 / 测试语义层（覆盖判据更贴合宿主装载门；分代谓词修正 patch 位误判），不改变插件对用户暴露的接口与行为。④ **用户配置 / 存储格式零变更**：不新增、不删除、不改名任何用户配置项；统计 JSONL、凭据文件、`oauthAccounts` 结构不动。⑤ 无新增能力面——本版不含新功能与用户可见行为变更。

### 已知行为 / 口径披露

- **升级雷达 issue #1（alpha 通道）保持打开**：宿主 0.2.1 的 alpha / next 预发布通道（如 `0.2.1-alpha.5`）仍由周频雷达持续观测——落在声明范围内但未实测的宿主版本继续以 `compatible-unknown` 黄态 + 一次性 `host-version-unknown` 诊断事件如实告知；本版**不吸收 alpha 通道**，待后续版本按宿主升级 SOP ③ 定性后处置。
- **本版不含新功能**：v0.6.1 为 ARCH-006 基线刷新的发布承载，仅含基线档案 / 白名单 / 看护判据变更与版本声明；用户可见功能面与 v0.6.0 一致。
- **审查台账 P3×3（非阻塞，随 ARCH-006 入册）**：① `caretRangeContains` 双侧剥离 rc 后缀——同三元组 rc 错位时与真实 `satisfies` 存在方向分歧（当前数据不可达）；② `versionTripleOf` 对畸形输入回落 `[0,0,0]`（恒适用、非 fail-closed；被守卫路径不可达，建议后续卫生批对齐 F-3 风格）；③ 本机 smoke 2 条 sh 臂历史性失败为环境性（批前已存在，归因实验证实；CI 为权威）。

### 版本说明

- **版本号**：0.6.0 → **v0.6.1**（**PATCH 位**）。依据：本版为 ARCH-006 基线档案刷新的发布承载——全部为 additive 数据 / 白名单 / 看护判据变更与版本声明，无新增能力面、无破坏性变更（见「破坏性变更」结论）；按语义化版本取 PATCH 位。**发布链任务定版 PATCH 候选 0.6.1（2026-10-20），E-4 Release Reviewer 保留独立升降位建议权**。**日期口径**：本节日期 2026-10-20 = 发布候选定版与发布三件套（E-1）时点。
- **发布范围**：v0.6.0（tag `74ad536`，2026-10-17）以来 main 全部提交——E-1 时点实采 **3 个**（复核命令与产出：`git rev-list --count v0.6.0..HEAD`）：**产品 / 发布面提交 1 个** = ARCH-006 基线刷新 `6bbf78b`（`lib/**` 3 文件 + `tests/**` 5 文件，全 additive）；**治理提交 2 个** = `4d7f331`（ARCH-005 收口：v0.6.0 发布终态 / EV-224 / REVIEW-ARCH-005-R14 机录等）/ `265acc1`（ARCH-006 收口：EV-225 / REVIEW-ARCH-006-R0 机录 / 雷达 issue #2 关闭等）——两者仅 `.governance/**` 改动，不承载用户可见变更，不入用户面。**结论行：产品 1 + 治理 2 = 3 = E-1 时点实采；本 E-1 提交落地后 = 4（E-1 提交自身计入本版发布面，改动面为版本声明与文档，不承载产品行为）；产品提交在「变更」节语义全覆盖。**
- **验证基线**：E-1 时点本地全量门控复跑实测（Windows 真实基线口径 `cmd /c "chcp 65001>nul && node tests/run-all.mjs"`）= **ALL 23 SUITES + 4 RUNNER MODULES (via smoke.mjs) PASSED，`#SKIP 2 (smoke.mjs×2)`，exit 0**；skip 明细 = win32 `0o600` 权限位不可判定 1 条 + 无 sh / curl 时 POSIX 在线臂 1 条（**历史上 smoke 恰 2 条 sh 臂环境性失败本时点未复现，如实记录**）。ARCH-006 批自身验收凭据（`tests/host-contract.mjs` 129 断言绿 / probe `totalDiffs=0` / 双门 GREEN / 三态 `matched/0.2.1` 桩机证 / CI run `39392930138` 五 job 全绿）随批入账；E-2 发布门控复跑（Coordinator 独立复跑，**发布候选树（本提交定稿前，文档面定稿不改动被测代码/配置）**，同一命令）= **ALL 23 SUITES + 4 RUNNER MODULES (via smoke.mjs) PASSED，`#SKIP 2 (smoke.mjs×2)`，exit 0**（耗时随环境浮动，逐次实测记录见治理证据）（与 E-1 一致）；E-3 隔离环境安装冒烟（环境变量重定向至临时目录）双形态通过：① `scripts/cold-install-gate.mjs` GREEN（link 形态冷装 + headless `--dump-config`，宿主 stderr 0 字节、组合树含 `# == dsh-agent-router`）；② `npm pack` tarball 形态（33 files）在 $TEMP 沙箱（`DSH_HOME` 重定向）安装 exit 0（安装版本 0.6.1、零 `link:` 形态）→ `dsh --profile sandbox --dump-config` exit 0 + stderr 0 字节 + 组合树含插件段；**发布资产终验（尺寸 / sha256 / 公网下载）以 E-5 机录为准**。**E-4 发布审查结论不在本节预填**（由 `review-record` 机录承载）。

## v0.6.0 — 2026-10-17

### 摘要

**宿主 0.2.0-rc.2 适配 + 版本依赖解耦架构版**。核心变化一句话：**宿主 0.1.5-rc.2 → 0.2.0-rc.2 升级对本插件的四个断裂点（装载门 / RPC codec / settings 声明 / 图片直传）全部解除——插件在 0.2.0 宿主上完整加载（装载门放行 + apply 全程无 throw），图片直传自 0.1.5 起的降级随之恢复；同时把「宿主升级」从单次抢救重构为常设架构：基线档案（单一事实源）/ 协商三态徽章 / 看护矩阵（双基线 CI）/ 漂移雷达（周频 cron）/ 宿主升级 SOP（五步可重放）；支持面基线同步跳跃至宿主 0.2.0-rc.2 及以上（DEC-1 单范围基线跳跃——低于基线不再支持，宿主装载门将整层拒载）**。同版内修复 v0.5.0 发布后真机验收与用户报障四件（健康面板取数失败 / 图片条件化接管失效 / 原生多模态贴图误切 / 预设统计归属错乱）。

### 新增

- **🛰 版本协商三态徽章（R2）**：设置页健康面板的宿主版本徽章从单态扩展为三态——**matched**（绿：实测基线组合）/ **compatible-unknown**（黄「未实测宿主版本」：落在声明范围内但未经实测的宿主版本（patch/rc 内跳位）照常装载运行，黄态 + 一次性 `host-version-unknown` 诊断事件如实告知）/ **incompatible**（面级判定先于版本判定的不兼容）。判定单点 `hostCapabilityProfile`（判定序：面先于版本）+ RPC `capabilityProfile` 字段（codec 必填，旧服务端网关直通容忍）+ 徽章渲染期零探针；基线值单源锁定（快照权威 ↔ lib 投影值级相等，机器断言看护——单侧漂移即红）（内部注解：`6d9fead`；REVIEW-ARCH-005-R9）。
- **📡 宿主升级雷达（R4）**：`.github/workflows/host-radar.yml` cron 周频（每周一 03:30 UTC）+ `workflow_dispatch` 应急——dist-tags **全枚举**（latest + next/alpha 等预发布 tag 并集比对，0.2.1-alpha.5 采集实证）+ **树静默重写形态吸收**（T-6：主包版本不变但嵌套树被整树重写——probe 每周期无条件对主基线新装 fresh 树跑四类 diff 报告：锚 / 白名单 / schema / 包表）+ 心跳自警（连续 ≥2 周期未成功运行即开自警 issue）；**探测不门控**（发现差异恒 exit 0——报告 = 决策输入，永不把门控 CI 打红）+ 46 断言判别套件；新版本 / 漂移 → issue（处置入口指回 SOP 第②步）（内部注解：`e01213e`；REVIEW-ARCH-005-R11）。
- **🧮 看护矩阵化（R0 + R3）**：`HOST_BASELINE_REGISTRY` 双基线注册表（frozen 0.1.5 历史 / primary 0.2.0 当前——「恰一 primary」恒等断言）成为单一事实源，四处消费面（snapshot / host-contract / ci.yml / probe）按 marker 文本权威提取（版本副本删除，提取失败即红——fail-closed）；`DSH_BASELINE` 参数化 + 锚 / schema `since` 分代（低代宿主记可见 skip 不误红）；CI 新增 `guard-matrix` matrix job（resolve-baselines → 每条基线 pack 8 包装树 + `DSH_HOST_SOURCE` + 同门控命令——yaml 零版本字面量）；非法 `DSH_BASELINE` 从旧静默 exit 0 改判红收口（P8）（内部注解：R0 `bd17cac` / R3 `dffb553`；REVIEW-ARCH-005-R3 / R10）。
- **🚪 冷装装载门取证程序（A1）**：`scripts/cold-install-gate.mjs`——$TEMP 沙箱（DSH_HOME 重定向）冷装 + headless `--dump-config` 启动，按宿主 dsh-app-boot 实读判据断言装载门放行（stderr 无 skip 警告 + 组合树含本插件段）；`--expect-skip` 判别红演示（临时回退单项声明 → 宿主 stderr 逐字警告 → 恢复 → 复跑绿——装载门判据非恒绿自证）+ 六类失败出口全部非零退出（P8）；判据文档 `docs/cold-install-gate.md`（内部注解：`678ff97`；REVIEW-ARCH-005-R5）。
- **📘 宿主升级 SOP（R5）**：`docs/host-upgrade-sop.md` 五步——① 检测（雷达 / 靶子告警 / 用户线索三通道）② diff 定性（四类机器报告 + 人工比对）③ 影响分级（breaking / additive / neutral 可判定谓词）④ 适配批（四类断点的先例批索引直接复用，不重发明）⑤ 发布 + 复验（CHANGELOG 义务行 / 门控 / 冷装 / 真机复验清单）+ 基线登记 checklist 11 条 + 重装后真机复验清单 12 条（回归面只增不减）；以本链十批做 retrospective walk-through 验证（按步骤重放可得出与本链一致的动作序列）（内部注解：`5b08fea`；REVIEW-ARCH-005-R12）。

### 修复

- **HD-002：settings Config 声明制迁移（apply 期断点解除——A3）**：宿主 0.2.0 起 settings 面改声明制——旧的订阅式读取在 apply 期抛 `settings.register is not a function`（插件整层加载失败）。修复：`routerConfig.volatile()` + `Config` 导出（**schemastery `^3.18.1` → `^3.18.5` 硬前提**——`.volatile()` 为新版能力）+ 四订阅点 `settings/updated` → `settings/document-updated`（宿主双参形态逐字对齐）+ host-route describe 读 + 事件驱动缓存（磁盘读热路径消除）；46 断言判别套件 + 五场景全绿（老配置可读可写 / stats 跨重启 / 热同步 / 快速连续操作 / **目标值 = 默认值**）+ `scripts/a3-apply-gate.mjs`（真 boot「服务端 apply 全程无 throw」+ 正向 TCP 探针）（内部注解：`b6aeac4`；REVIEW-ARCH-005-R7）。
- **HD-003：RPC codec `create()` 工厂迁移（apply 期断点解除——A2）**：宿主 0.2.0 的 TypertRegistry 走 `create()` 工厂契约——旧 `.schema` 静态形态抛 `strict codec has no create() factory`。修复：`strictCodec` 单点包装（38 个 codec 位全部收敛经 parameter/result 两个 helper——同一动作单路径）+ 客户端镜像字节恒等 + shadow-guard 扩展（真树实跑：0.2.0 双通道 19/19 + 旧形态负控 throw 逐字复演）（内部注解：`43e8267`；REVIEW-ARCH-005-R6）。
- **HD-004：图片直传恢复（A4——「恢复」而非 0.2.0 回归修复）**：对话输入框「添加图片」→ 附件随消息原生直传的链路**自宿主 0.1.5 起已降级**（T-1 定性：`npm pack` 实证宿主 `createDraftImages` 在 0.1.5-rc.2 零命中——v0.5.0 时代即已缺失该面，0.2.0 适配时定性为**恢复**而非 0.2.0 回归修复）。修复：对齐宿主原生三步链 `createDrafts` → `addAttachments` → 拒绝 release（走上传得 file receipt 且 serialize 未注册 id 直接 throw——选型经审查独立证实）+ 四项缺面守卫（缺面降级不崩，FIX-048 降级语义延续）+ `isImageFile` 四类 MIME 对齐宿主；判别群 9/9 + 红演示 6 红（内部注解：`66878ea`；REVIEW-ARCH-005-R8）。
- **FIX-046：设置页宿主面健康面板 / 预设生效诊断面板取数失败（v0.5.0 真机验收发现——面板版本恒 `?`、诊断恒空）**：根因 = RPC descriptor 两份事实源（服务端 19 / 客户端 17，差集恰为 `presetDiagnostics` + `hostFaceDiagnostics`）→ 客户端 remote 缺方法。修复：可观测化先行（客户端四态分类诊断 + 上屏）+ Rework 补齐客户端观测面两条 descriptor（单点化）+ 双侧 parity 机器守卫（修复前必红实证）；V-9 真机复验 4/4 通过（版本三值真实 / 失败行消失 / 面探针 5→18 / 诊断事件复活）（内部注解：`a75f85d` + `3869e79`）。
- **FIX-048：图片条件化自动接管失效（用户报障）**：宿主 InputState 的 `attachmentIds` 形态演进后，v0.3.3 起的「贴图即自动切多模态包装路由」武装判定失效——贴图不再自动切换。修复：宿主 InputState `attachmentIds` 双形态跟随（内部注解：`bff7a7f`）。
- **FIX-049：原生多模态模型会话贴图误切 twin（用户报障）**：宿主原生多模态模型会话中贴图被误切到插件包装路由 / 订阅模型——接管门控存在漂移窗口。修复：贴图时点按需能力刷新（接管门控漂移窗口消除）（内部注解：`c6028fd`）。
- **FIX-052：预设作用域统计归属错乱（用户报障）**：多预设使用下统计归属可能错乱（切换预设 / 快速连续建会话等扰动）。修复：归属键重构为会话预设身份不变量——三扰动零漂移（内部注解：`4ac01fa`）。

### 变更

- **靶子候选链修复 + 事件白名单镜像对齐（R0）**：`tests/host-contract.mjs` 宿主靶子候选链增加 npm 全局树（此前对 0.2.0 全局树失明、跑在过期 `_npx` 副本上——本次升级的第一发现人是用户报障；靶子修复把「升级已发生」的本地发现能力补齐）；probe 类工具必须显式瞄准（`--host-source`），不自动发现；`lib/host-abi/events.js` 白名单镜像 19→27 项 + `since` 分代（三镜像字节恒等断言）+ pi-ai 锚（内部注解：`bd17cac`）。
- **锚守卫体系与测试基础设施批（零用户行为面——9 任务 50 提交）**：FIX-038 CI 首跑失败修复（非适用平台断言改可见 skip + LRU 夹具 POSIX 路径语义 + `lstat` 裸抛消除）/ FIX-039 v0.5.0 发布审查台账批（注释锚）/ FIX-040（skip 可见性口径修正 + `.cmd` shim 断言平台中立化 + 锚符号名化等 14 笔）/ FIX-041~FIX-045（在仓行号锚全量改符号名 / 代码串式 + `ANCHOR_CASES` 全量接线 19 文件级条目 + 守卫自指与入表完备性机器判据）/ FIX-047（FIX-046 遗留 P3 卫生微批）——全部为注释 / 测试 / CI 面，产品行为零改动（内部注解：见「版本说明·发布范围」SHA 底账）。
- **治理工作流升级（零用户可见变更）**：GOV-012 / GOV-013 / GOV-014 三次治理工作流升级（0.80.0→0.98.0；AGENTS.md bootstrap splice + 治理记录——按改动面机器分类计入产品/发布面，语义为治理，如实披露）（内部注解：`6ff1b07` / `1002777` / `2d63a97`）。

### 破坏性变更

**结论：对基线（宿主 0.2.0-rc.2）及以上 = 用户面零破坏性变更；对低于基线的旧宿主 = 支持面终止（DEC-1 单范围基线跳跃，如实披露）。**分项依据：

1. **支持面 = 宿主 0.2.0-rc.2 及以上（本版唯一收窄面，DEC-1 基线跳跃）**：宿主 0.2.0 起装载门（dsh-app-boot）对插件 manifest 中全部 `@deepseek-ai/dsh*` peerDeps 逐项 `semver.satisfies(runtimeVersion, range, { includePrerelease: true })` 门控——**低于基线的旧宿主不在本版支持面**，宿主装载门将整层拒载并打印 skip 警告（`dsh: skipping profile bundle "dsh-agent-router"` + `is incompatible with dsh` / crash/data-loss 风险提示）；不承诺回退——请先把宿主升到 0.2.0-rc.2 及以上再升级本插件（README「宿主兼容性（实测基线）」支持基线集表：0.2.0 primary / 0.1.5 frozen）。
2. **依赖声明面跳跃（记录性 + 装载门门控钥匙双语义）**：11 项 dsh 声明（peerDependencies 8 项 + dsh 包 dependencies 3 项）`^0.1.5-rc.2` → `^0.2.0-rc.2`（R1 `367b65f`，pnpm-lock 同步刷新——CI frozen-lockfile 口径）；8 项 peerDeps 另带 `peerDependenciesMeta` `optional: true`——**该标记仅影响安装器行为（pnpm 装入 profile 时不对缺失 peer 告警），不解除宿主装载门**（R1 验收：optional 不解除门控的行为级实证）。
3. **schemastery `^3.18.1` → `^3.18.5`**（A3 `b6aeac4`）：`.volatile()` 声明制迁移的硬前提——无此能力则 settings Config 声明不可表达。
4. **用户配置 / 存储格式零变更**：不新增、不删除、不改名任何用户配置项；统计 JSONL、凭据文件、`oauthAccounts` 结构不动（v2 统计行的降级读取边界沿用 v0.4.5 已披露口径，见下）。
5. **行为面**：HD-002 / HD-003 为宿主契约对齐（旧宿主面在 0.2.0 已不存在）；HD-004 为能力恢复（0.1.5 起降级的链路恢复）；FIX-046 / FIX-048 / FIX-049 / FIX-052 均为缺陷修正方向。

**是否算 breaking（明确结论与依据）**：第 1 项按 semver 严格口径属支持面收窄（对「运行在低于 0.2.0-rc.2 宿主上」的场景构成 breaking）；本仓 0.x 阶段口径 = **声明基线即支持面**（先例 v0.4.4「宿主面跟随披露」/ v0.5.0），基线数值随实测上移时如实披露而非承诺旧宿主兼容。故本版入账口径 = **「基线及以上用户面零破坏 + 支持面收窄已披露」**；**版本位 = MINOR（v0.6.0，2026-10-17 定版）**，见「版本说明」。

### 已知行为 / 口径披露

- **gate-block regime（单范围基线跳跃的已知代价）**：宿主未来 minor 跳位（如 0.3.0）不在 `^0.2.0-rc.2` 范围内 → 插件整层拒载、**插件侧三态徽章 / 诊断事件不可达**（gate-block 下插件零运行机会）——宿主启动 stderr 的 skip 警告是唯一用户侧线索，升级雷达为机器观测面（处置 = 升级插件，或宿主侧 `dsh plugin allow-version` 豁免）。patch/rc 内跳位则照常装载运行（黄态「未实测宿主版本」+ 面级降级不整页崩溃）。
- **本地全量门控基线（Windows）**：`cmd /c "chcp 65001 >nul && node tests/run-all.mjs"` 真实基线口径下，**smoke.mjs 恰 2 条 sh 臂为本地环境性失败（Git Bash 编码/兼容——立案批实证，CI 为权威）**；本地基线形态 = 23 独立套件 22 PASS + smoke 恰 2 条 sh 臂 + `#SKIP 0`（本版实测见「版本说明·验证基线」）。
- **升级雷达 Actions 首跑复核义务在册（R4 登记）**：`host-radar.yml` 已随本版入库，但 schedule 触发与 gh / GITHUB_TOKEN 真机行为以 Actions 首跑日志为准（首跑属 push 后动作——本节不声称雷达已在线生效）。
- **降级兼容（延续披露）**：v0.4.5 起产生的 v2 统计行（含预设作用域 scope 行）无法被 v0.4.4 及更早版本读取，最坏情形下降级后首次统计加载会触发旧版坏行修复机制、不可逆清除这些 v2 行——如需降级请先备份统计目录（`DSH_HOME/dsh-agent-router/stats/`）；本版不改变该边界。
- **宿主域延续披露（三条不变）**：某形态会话 GUI 预设下拉不发切换请求（DEFERRED-001）/ 带切换历史的空白会话重启后状态可能非最后预设配置 / 会话内切换模型会同步改写全局默认——详见 v0.4.5 节「已知行为 / 口径披露」。

### 版本说明

- **版本号**：0.5.0 → **v0.6.0**（**中位抬升 = MINOR 位**）。依据：本版含**新增能力面**——版本协商三态徽章 + 升级雷达（cron workflow）+ CI 看护矩阵 + 冷装装载门程序 + 宿主升级 SOP 文档——叠加**已披露的支持面收窄**（DEC-1 基线跳跃）；仓内成文先例「新能力面 → 中位抬升」（v0.4.2 / v0.5.0）；**发布链任务定版 MINOR 候选 0.6.0（2026-10-17），E-4 Release Reviewer 保留独立升降位建议权**。**日期口径**：本节日期 2026-10-17 = 发布候选定版与发布三件套（E-1）时点。破坏性判定见「破坏性变更」结论行。
- **发布范围**：v0.5.0（tag `336665c`，2026-09-12）以来 main 全部提交——E-1 时点（本三件套 staged、提交落地前）实采 **117 个**（复核命令与产出：`git rev-list --count v0.5.0..HEAD`；本 E-1 提交落地后 = 118）。三分账（按提交实际改动面机器分类——仅 `.governance/` 改动的提交计治理，其余计产品/发布面）：**产品/发布面提交 69 个**——① ARCH-005 链十批 10 个（R0 `bd17cac` 靶子修复 + 基线登记 / R1 `367b65f` 声明面基线跳跃 / A1 `678ff97` 装载门取证程序 / A2 `43e8267` codec create() 工厂迁移 / A3 `b6aeac4` settings 声明制迁移 / A4 `66878ea` 图片直传恢复 / R2 `6d9fead` 协商三态 / R3 `dffb553` 看护矩阵化 / R4 `e01213e` 升级雷达 / R5 `5b08fea` 宿主升级 SOP）；①补 ARCH-005-R4F 修复批 1 个（CI 基线矩阵 job env 泄漏修复——tests/host-radar.mjs 判别套件封闭化：spawn env 剥离 DSH_HOST_SOURCE/DSH_BASELINE 宿主继承后再合并用例显式传入，套件结果与宿主 env 恒一致；先于 E 批提交落地故计入 E-1 时点实采，`d71dee2`）；② 用户可见修复 4 任务 5 个（FIX-046 `a75f85d` + `3869e79` / FIX-048 `bff7a7f` / FIX-049 `c6028fd` / FIX-052 `4ac01fa`）；③ 锚守卫/测试基础设施/注释卫生批 9 任务 50 个（FIX-038 ×4：`cc89119` / `96aca2c` / `7fd8cb5` / `e1fe160`；FIX-039 ×2：`3f3e59b` / `5d8af6e`；FIX-040 ×14：`8c99c0f` / `ec86c28` / `6bb961c` / `09c7cc7` / `207141a` / `04edcf9` / `1b5cead` / `4e5c848` / `b87df16` / `08d562a` / `ebda9d1` / `e13ca17` / `8eef8f1` / `d301859`；FIX-041 ×10：`6d77ad5` / `8f187f6` / `f2a4d37` / `bd649a3` / `7c5e510` / `524a30d` / `6c9553b` / `de9d551` / `704a331` / `0af6927`；FIX-042 ×9：`fa99686` / `0a176b5` / `61af16a` / `d58c5ca` / `246c8bb` / `14156b8` / `866f688` / `8aed89c` / `9b262ef`；FIX-043 ×6：`813c4a9` / `2d65f6e` / `cfe7756` / `2ea0bc9` / `ce8d908` / `355687a`；FIX-044 ×1：`6680d29`；FIX-045 ×2：`3e9e8a5` / `cd1441a`；FIX-047 ×2：`d1c9d95` / `06b4c85`）；④ 治理工作流升级 3 个（GOV-012 `6ff1b07` / GOV-013 `1002777` / GOV-014 `2d63a97`——AGENTS.md bootstrap splice，零用户可见变更）；**治理提交 48 个**（仅 `.governance/` 改动——ARCH-005 立案/分析/双审工件/各批审查机录与终态、FIX-046~FIX-052 任务治理入账、真机验收留证、REL-012 尾账等，不承载用户可见变更）。**结论行：69 + 48 = 117 = E-1 时点实采；本 E-1 提交自身计入本版发布面（落地后 118，改动面为文档与版本声明，不承载产品行为）；产品提交在本节语义全覆盖（ARCH-005 链按批归并到「新增 / 修复 / 变更 / 破坏性变更」各节；锚守卫批与治理升级零用户行为面、按「变更」节两行归并），治理提交不入用户面。**
- **验证基线**：E-2 门控全量复跑实测（本版 bump 后，Windows 真实基线口径 `cmd /c "chcp 65001 >nul && node tests/run-all.mjs"`）= **23 独立套件 + 4 runner 模块：22 PASS + smoke.mjs 恰 2 条 sh 臂环境性 FAIL**（`bare-source install (sh --local) idempotent on sh` / `git clone failure reports clear error on sh`——Git Bash 编码/兼容，CI 为权威）**+ `#SKIP 0`（零 skip 回显），39.3s——与链上基线（R4/R5 批）一致零回退**；E-3 tarball 隔离冷装实测（发布验收用 packed 产物而非 link 形态）= `npm pack` 产物 **1,702,929 字节**（`dsh-agent-router-0.6.0.tgz`，33 files，shasum `579cb708`，Release 资产终验记录值）→ $TEMP 沙箱（`DSH_HOME` 重定向——唯一 env 覆写，零 HOME/USERPROFILE 赋值）以 **tarball 形态**安装（`dsh plugin --profile sandbox add <tarball>` exit 0，install-log `+ dsh-agent-router file:…dsh-agent-router-0.6.0.tgz`，全 log 零 `link:` 形态）→ `--dump-config` 启动 **exit 0 + stderr 0 字节（无任何 skip 警告标记）+ 组合树含 `# == dsh-agent-router` 段 + 沙箱内安装版本 0.6.0**——装载门放行判据全绿（A1 程序判据同形）。链上各批验收凭据随批入账（rpc-shadow-guard 真树双通道 19/19 / settings-config-migration 46 断言五场景 / a3-apply-gate 真 boot stderr 0B + TCP 探针 / host-radar 46 断言 + dry-run 双树吻合）；十批审查记录均为 APPROVED_WITH_NOTES / unresolved_blockers=0（REVIEW-ARCH-005-R3~R12）。**E-4 发布审查结论由发布链各自入账，本节不预填**；用户真机复验（SOP §7 清单 12 条——装载门 / 五场景 / 三态徽章 / 图片直传 / FIX-052·049 顺延项）由发布后真机臂承载，本节不预填。

## v0.5.0 — 2026-09-12

### 摘要

**宿主 0.1.5-rc.2 兼容性适配版（宿主 ABI 分层 + 静态看护 + CI 接线）+ 预设 subagent 模型跟随修正**。核心变化一句话：**v0.4.5 以来本版把插件对宿主接口的依赖收敛为分域适配层（`lib/host-abi/`）——宿主面缺失从「整页崩溃 / 静默失效」改为「面级降级 + 可观测诊断」，宿主契约（形状 / 声明面 / 消费点 / 事件白名单）由静态守卫成体系看护，测试门控收为单入口并接线 CI 第①步；同一版内修正预设 subagent 留空时的模型跟随语义——跟随主 Agent 当前实际模型（含会话内手动切换），不再固化为预设配置的主模型值**。

### 新增

- **🩺 宿主面健康诊断（设置页）**：设置页新增宿主面健康面板与徽章——显示宿主版本、各宿主面健康状态（`ok` / `degraded` / `missing`，面名如 `ctx:llm` / `llm:adapter` / `session:select` / 客户端 remote 面）与诊断环形记录（RPC `router/hostFaceDiagnostics`，**条件式读时复检**——全绿快照为纯缓存读；快照为空或含非 ok 面时，本次读触发一次全量自检，探针不进渲染路径与设置页轮询）。宿主升级导致某面不适配时可直接看到「哪一面不可用、为什么」，不再是「某功能莫名失灵」而无从排查（内部注解：EVO-019）。

### 修复

- **FIX-032：预设 subagent 留空跟随主 agent 当前模型（用户报障 2026-09-07）**：
  - **现象**：预设 subagent 未设置模型时，会话内手动切换主 agent 模型后，新派生 subagent 仍走预设配置的模型——「会话内手动选择永远优先」被子代理路径击穿。
  - **根因**：`subagentFixup` 的 target 链在 `cfg.subagent` 未设置时回落 `cfg.main`（配置时静态值），主动覆盖宿主委托基线（`parentAgentOptionsForDelegation`，dsh-subagent L603-613 交付父最近请求头路由 = 主 agent 当前实际模型）。
  - **修复**：移除 `cfg.main` 固化回落——target 只认 `cfg.subagent`，留空 = 零动作（宿主基线已保证跟随主 agent 当前模型）；修复定位 `lib/preset-defaults.js`。
  - **语义四态**：① 留空跟随主 Agent 当前实际模型（含会话内手动切换，不固化为预设配置值）；② subagent 显式配置仍优先；③ 预设未配置零行为变化；④ 显式指定模型的子代理不受影响。
  - **判别**：`tests/preset-defaults.mjs` 新增 M 判别节 M1-M5（M1 复刻报障主诉，旧实现必败——HEAD 直接复跑与 stash 突变复跑双重 RED 实证）；B2/B5/B6 按 FIX-032 语义修订（B2 零 fixup 化 / B5 保护降级改由 subagent 显式配置承载 / B6 冻结防御路径同）。
  - **代码级验证**：门控全量 21/21 套件 exit 0 零回退（产品提交 `640e2e4` 实测）；用户真机复验由发布链后置记录，本节不预填。
  - **文档**：README L16/L165 行为句澄清（「继承主预设模型」→「跟随主 Agent 当前实际模型（含会话内手动切换）」）已随产品提交入库。
- **设置页宿主面缺失不再整页崩溃（P8 同向）**：设置页读取宿主客户端面（llm / settings / credentials / session）改经独立域模块（`lib/host-abi/client-remotes.js`），失败由「整页加载失败」降级为**面级降级**——该卡片显示可诊断短码（`host-face-missing` / `host-face-shape` / `host-face-call`）+ 健康徽章 + 诊断事件，其余面照常可用（此前宿主某一面缺失即整页不可用，正是用户报障「部分 plugin 设置页崩溃」的同一类面；内部注解：EVO-020）。
- **客户端死订阅修复 + 设置页轮询治理（症状② 插件侧贡献面）**：credentials 引用更新事件此前订阅的是宿主不存在的事件名（该事件不触发，属静默死订阅）→ 改订域管白名单内的实际事件；设置页轮询治理——页面隐藏时暂停轮询（此前 2 秒双 RPC 持续轮询），对用户报障「DSH 卡顿」的插件侧贡献面完成可量化治理（不主张为卡顿全部成因；内部注解：EVO-023）。
- **宿主事件订阅失败不再静默（P8 同向）**：事件 attach 抛错时此前会记「已订阅」并使同事件的后续消费者收不到事件（静默死订阅）——现改为失败不入表 + 记 `event-subscribe-failed` 诊断（含事件名 / 消费者标签 / 错误摘要）+ 降级 no-op 不悬挂 + 后续订阅重试自愈（内部注解：FIX-035）。
- **宿主 LlmAdapter 契约对齐**：宿主 0.1.5-rc.2 的 LlmAdapter 原型新增 `imageRequestPricing` 契约方法，插件两个自有适配器（twin / oauth-llm）补齐镜像实现（同步零 I/O；未声明图片定价时恒 `undefined`，不虚构数字）——缺失会断裂宿主 token 计价的取价路径（`adapters.get(provider).adapter.imageRequestPricing`）；契约守卫扩展为双适配器动态枚举同构校验（内部注解：FIX-033 / FIX-034）。
- **预设链单形态收敛**：预设链的 apiProxy 旧面回落路径删除，统一 sessionController 单形态（宿主 0.1.5-rc.2 起模型选择面为单形态）——同一动作不再并存两条来源（内部注解：EVO-021）。

### 变更

- **宿主依赖声明面止损**：删除 `dsh.client.inject` 死行 `@deepseek-ai/dsh-client-runtime`（宿主 0.1.5 起已无此包——此前仅为加载器 informational skip 的死重）；`peerDependencies` 8 项与 dsh 包 `dependencies` 3 项版本范围统一为实测基线 `^0.1.5-rc.2`（记录性声明，语义见 README「宿主兼容性（实测基线）」）；新增宿主版本快照守卫 `tests/host-version-snapshot.mjs` 锁定声明面（内部注解：EVO-018）。
- **宿主服务访问单点化**：宿主服务访问 24 处散点（`service.js` 17 处 + `host-route.js` 7 处）收敛为具名访问器，常量归位（`HOST_ROUTE_*` 权威定义收单点）；低危面（fs / settings）按设计分级白名单保留，越界新增即由 `tests/host-abi-health.mjs` 精确快照判红（内部注解：EVO-022）。
- **静态看护成体系 + 门控单入口 + CI 第①步**：新增 `tests/host-contract.mjs` 五类守卫（契约快照四类面 / 宿主源码形状锚点 / 声明面比对 / 消费点黑名单 / 字段级 wire schema 与转发事件白名单；宿主可达侧 82 断言，宿主不可达侧 71 条照跑、只记 skip 不失败）；门控收为单入口 `node tests/run-all.mjs`（20 独立套件 + 4 runner 模块；修复 pwsh 不展开 `tests/*.mjs` glob 造成的门控漏洞）+ `npm test` / `npm run test:contract` 脚本；CI 第①步接线（`.github/workflows/ci.yml` 单 job：checkout → pnpm → setup-node LTS → `pnpm install --frozen-lockfile` → `node tests/run-all.mjs`），并补齐 CI 平台容错（无 PowerShell 的 runner 正确 skip）、幻影套件双向守卫（排除不得等于丢覆盖）、skip 可观测与版本一致性判据（内部注解：EVO-024 / FIX-036 / FIX-037）。

### 破坏性变更

**结论：对声明基线（宿主 0.1.5-rc.2）及以上 = 用户面零破坏性变更；对低于该基线的旧宿主 = 支持面终止（兼容性收窄，如实披露）。**分项依据：

1. **依赖声明变更（记录性）**：`dsh.client.inject` 删除死行 `@deepseek-ai/dsh-client-runtime`（宿主 0.1.5 起已无此包）；`peerDependencies` 8 项与 dsh 包 `dependencies` 3 项版本范围由 `^0.1.0-rc.8` / `^0.1.0-rc.6` 统一为 `^0.1.5-rc.2`——该声明为**记录性**（不做安装期 enforcement：宿主 runner/cordis 不校验 peerDeps、安装器不告警），兼容性判定的权威防护是版本快照守卫 + 契约静态看护（见 README「宿主兼容性（实测基线）」）。
2. **兼容性基线上移（本版唯一收窄面）**：预设链的 apiProxy 旧面回落路径已删除（宿主 0.1.5-rc.2 起模型选择面为 sessionController 单形态，本版按单形态适配）——**低于 `0.1.5-rc.2` 的旧宿主不在本版支持面**，不承诺回退；建议先把宿主升到实测基线再升级本插件。
3. **用户配置 / 存储格式零变更**：不新增、不删除、不改名任何用户配置项；统计 JSONL、凭据文件、`oauthAccounts` 结构不动（v2 统计行的降级读取边界沿用 v0.4.5 已披露口径，见下）。
4. **行为面均为修正方向**：预设 subagent 留空从「固化为预设配置的主模型值」回到「跟随主 Agent 当前实际模型」（未配置预设与显式配置路径零行为变化）；设置页某宿主面缺失从「整页加载失败」变为「该面降级 + 健康徽章 + 诊断事件」（可用面增加方向）；设置页轮询在页面隐藏时暂停。

**是否算 breaking（明确结论与依据）**：按 semver 严格口径，第 2 项属**支持面收窄**——对「运行在低于 `0.1.5-rc.2` 宿主上」的场景构成 breaking；本仓 0.x 阶段的处理口径为**声明基线即支持面**（先例 v0.4.4「宿主面跟随披露——不支持组合，无回退承诺」），基线数值随实测上移时如实披露而非承诺旧宿主兼容。故本版入账口径 = **「用户面零破坏 + 支持面收窄已披露」**；**版本位已按重划后范围裁决为 MINOR（v0.5.0，用户 2026-09-12）**，见「版本号」。

### 已知行为 / 口径披露

- **降级兼容（延续披露）**：v0.4.5 起产生的 v2 统计行（含预设作用域 scope 行）无法被 v0.4.4 及更早版本读取，最坏情形下降级后首次统计加载会触发旧版坏行修复机制、不可逆清除这些 v2 行——如需降级请先备份统计目录（`DSH_HOME/dsh-agent-router/stats/`）；本版不改变该边界。
- **CI 口径如实披露（本补正替代此前「本项目暂无持续集成（CI）自动化」表述）**：本版已接线 **CI 第①步**（`.github/workflows/ci.yml` 单 job：checkout → pnpm → setup-node LTS → `pnpm install --frozen-lockfile` → `node tests/run-all.mjs`），但**尚无 CI 首跑结果**（首跑属 push 后动作）——本节**不声称 CI 已通过**；**现行回归保护 = 本地全量门控单入口** `node tests/run-all.mjs`（20 独立套件 + 4 runner 模块，顺序执行并聚合退出码）。CI 不覆盖的面（Windows PowerShell 5.1 解析/执行臂、win32 junction 与 POSIX symlink 目录语义、宿主运行时装配与 inject 就绪时序、GUI 渲染与设置页交互、OAuth 真实端点登录流、CLI 子代理真机执行）仍由真机手工验收 + 设置页诊断面板兜底（边界清单与预期内 skip 口径见 README「维护与开发」）。
- **宿主域延续披露（三条不变）**：某形态会话 GUI 预设下拉不发切换请求（DEFERRED-001）/ 带切换历史的空白会话重启后状态可能非最后预设配置 / 会话内切换模型会同步改写全局默认——详见 v0.4.5 节「已知行为 / 口径披露」。

### 版本说明

- **版本号**：0.4.5 → **v0.5.0**（**中位抬升 = MINOR 位**）。依据：本版含**新增能力面**——`lib/host-abi/` 分域适配层 8 文件 + 公开 RPC `router/hostFaceDiagnostics` + 设置页宿主面健康面板与徽章（`package.json` files 白名单新增 `lib/host-abi/`）——叠加**已披露的兼容性支持面收窄**（低于宿主 0.1.5-rc.2 不在支持面）；仓内成文先例「新能力面 → 中位抬升」（v0.4.2 版本说明原文「MINOR：完整新能力面——新配置节 + 新设置卡片 + 新事件行为，向后兼容」）；**用户 2026-09-12 裁决取 MINOR（0.5.0）**——旧「推送小版本」授权成立于重划前范围（FIX-032 单点，当时实采 2 笔），重划后版本位按本裁决。**日期口径**：本节日期 2026-09-12 = 版本位升位裁决与发布候选定稿时点（E-5 发布定于当日）。破坏性判定见「破坏性变更」结论行。
- **发布范围**：v0.4.5（tag `79d67c7`，2026-09-07）以来 main 全部提交 **42 个**（复核命令与产出：`git log v0.4.5..HEAD --oneline` / `git rev-list --count v0.4.5..HEAD`，本次返工提交落地后实采 = 42）。三分账（按提交实际改动面机器分类——仅 `.governance/` 改动的提交计治理，其余计产品/发布面）：**产品提交 16 个**——ARCH-004 链 15（`3344f0d` EVO-018 B0 声明面止损 / `ff56096` EVO-019 锁文件刷新至实测基线 / `c89d635` FIX-033 twin 契约对齐 / `c57de5b` EVO-019 B1 骨架 + 诊断环形 / `a3e39f3` FIX-034 oauth-llm 契约补齐 / `f8bd6d4` EVO-020 B2 面级降级 / `e541028` EVO-021 B3 单形态收敛 / `2090267` EVO-022 B4 散点收敛 / `79eead9` EVO-023 B5 事件域 + 死订阅修复 / `4315991` EVO-024 B6 静态看护 + 门控单入口 + CI 第①步 / `031a1ff` FIX-035 attach 失败修复 / `7fec25e` FIX-036 CI 容错 + 幻影套件守卫 / `a9e06da` + `df96ddf` + `c99b4cf` FIX-037 终批收账 + R0 返工 + R1 收口）+ FIX-032 `640e2e4`（subagentFixup 移除 cfg.main 固化回落 + M1-M5 判别节 + B2/B5/B6 语义修订 + README 行为句澄清）；**治理提交 20 个**（不承载用户可见变更）——`969531b`（REL-011 发布终态入仓，归属 v0.4.5 发布链尾账）/ `bc7533d` + `5c7d321` + `5cd6ce9`（REL-012 治理入仓与留痕）/ `5caafe4` + `9692ccb` + `3557298` + `de70938`（ARCH-004 任务入仓 / 双审机录 / 分析双文档冻结 / ADR 写回 DEC-030·DEC-031）/ `7a82a2e` / `4d5daa2` / `faefd82` / `e7a8b36` / `9da069b` / `05759cf` / `9c01c67` / `8c5c4d9` / `70dc0a4` / `f4340ac` / `3dc2fa1` / `dc8b8a1`（EVO-018~024 与 FIX-033~037 各任务终态入仓及补录）；**E-1 提交 6 个**（发布三件套及其补正/返工系）——`65201ad`（首版三件套：version bump + CHANGELOG 节 + README 版本引用；该时点范围实采 = 2 提交）/ `4d7889b`（CHANGELOG 范围重划补正：四处不实陈述修正 + 三分账重算）/ `19f9a94`（README L130 提示词块前置消歧）/ `0ef1844`（README L30 人读面主前置句同口径消歧）/ `01e0446`（发布范围账目校正：37/38 → 40 @ 冻结时点 `0ef1844`）/ **本返工提交**（E-4 R1 返工：版本位升位 0.5.0 + 健康诊断措辞修正 + 断言计数口径 + 发布范围重算；hash 见 git log）。**口径说明：E-1 各提交自身计入本版范围（42 = 实采 42），其改动面均为文档与版本声明，不承载产品行为。结论行：产品 16 + 治理 20 + E-1 6 = 42 = 实采 42；产品提交在本节语义全覆盖（ARCH-004 链按任务族归并到「新增 / 修复 / 变更」各节；其中 `3344f0d` B0 为声明面 + 版本快照守卫批，无生产代码逻辑改动，语义见「变更」节），治理提交不入用户面。E-5a 发布链治理入仓提交将于 tag 时点计入治理面（发布收口 EV 回填终值）——范围以 tag 时点实采为准（先例 REL-011：治理提交不入用户面）。**
- **验证基线**：ARCH-004 链终态（`dc8b8a1`，2026-09-12）复跑实测——门控单入口 `node tests/run-all.mjs` = **ALL 20 SUITES + 4 RUNNER MODULES (via smoke.mjs) PASSED（29.6s，`#SKIP 1 (smoke.mjs×1)`）exit 0**；`tests/host-contract.mjs` 单跑 82 断言 PASSED（宿主可达侧；宿主不可达侧 71 条照跑、只记 skip 不失败，见 README）；`tests/host-version-snapshot.mjs` **24 断言 PASSED（运行时断言数——实跑 `passed` 值口径，与同段 `host-contract.mjs` 82 断言同口径；源级 15 处 `check()` 调用点，其中 peerDeps 8 项 / deps 3 项为循环展开）**；FIX-032 判别测试（M1-M5 新判别节 + B2/B5/B6 语义修订，RED→GREEN 双重实证）。各任务审查记录**均为 APPROVED_WITH_NOTES / unresolved_blockers=0**——REVIEW-EVO-018~024 七条、REVIEW-FIX-033~036 四条、REVIEW-FIX-037 三轮（R0 / R1 / R2，R2 零新发现）。本补正时点 `node tests/smoke.mjs` = **1162 ok / 0 FAIL / 1 skip / exit 0**（三件套与补正均为文档面，零代码逻辑改动）。**CI 首跑结果尚未产生——本节不声称 CI 已通过**；E-2 门控全量复跑、E-3 隔离冷装、E-4 发布审查结论由 REL-012 链各自入账，本节不预填；用户真机复验由发布链后置记录，本节不预填。

## v0.4.5 — 2026-09-07

### 摘要

**统计归因与分级重构版**。核心变化一句话：**统计信息完成分级重构（预设 / 专业 / 账号 / 全局四张二级卡），并根治统计归因的老大难——同一账号不再因通路形态被拆成多张卡、内部实现键（twin / `-router` / `oauth:` 前缀）不再出现在任何统计可见面、账号级计数覆盖全部路由形态（含无预设会话与宿主官方路由）；同时适配宿主 0.1.2-rc.1 预设链双断裂**。

### 新增

- **📊 统计信息分级重构（EVO-017，用户规格五条 2026-09-05）**：统计信息卡内四张二级卡——**预设统计**（按预设 × 主 / subagent 两口径）、**专业 Agent 统计**、**账号级统计**（按真实账号聚合）、**全局统计**（散落全局元素收编第四卡）；每卡统一三段结构（总用量 / 每日用量 / 实时 tokens 分布）+ 最近调用记录；预设作用域请求遥测（`agent/request` 只读旁路——用户授权的观测豁免，每请求恰记一条）；CSV 导出新增 `level: preset` 档（agent / account / preset 三级）；统计持久化行版本升级 v2（预设作用域行，历史 v1 行读侧兼容）。
- **预设生效观测面（FIX-030 组成部分）**：预设配置的生效 / 未生效经诊断事件可观测——诊断环形缓冲 + `presetDiagnostics` RPC + 预设卡生效诊断面板（此前预设不生效完全静默，排障只能靠猜）。

### 修复

- **FIX-030：宿主 0.1.2-rc.1 预设链双断裂（用户报障三连 2026-09-05）**：①预设切换后模型不跟随——宿主把会话模型读取面从 apiProxy 迁到 sessionController（双形态适配，旧宿主回落兼容）；②subagent 模型配置不生效——继承链与主会话同构修复。
- **FIX-031：统计归因单点化 + 路由透明性（DEC-029 不变量；用户三轮真机复验驱动 D1–D10 全修，含两次独立审查返工）**：
  - **账号伪实体消除**：包装路由键（如 `glm-local-router`）归并真实账号（`glm-local`）——同一账号的原生 / 包装 / 专业 agent 多通路只一张卡；
  - **内部键不可见**：`twin` / `oauth:` 前缀 / `-router` 后缀 / 裸 `main` 不再出现在统计任何可见面（含导出 CSV 列值）；专业 Agent 统计新增「主模型」分组卡（主 agent 含 subagent 经插件通路用量的归组对账）；
  - **账号级计数全覆盖**：解除预设门控——无预设会话（含直用宿主官方 deepseek-official）照记请求口径计数；
  - **同一 ChatGPT 订阅归并一卡**：宿主官方路由（openai-codex）与 oauth 通路共用同一份订阅凭据，用量归并一卡——含启动竞态安全重载（路由维护完成后全量重放，历史行正确归并）与身份 / 健康度解耦（路由降级 / 探活失败不抹归属，身份从配置确定性推导）；
  - **跨 UTC 午夜请求不再双计**：调用行归因对齐请求起点（此前跨午夜请求账号级合计 2）；
  - **twin 目录条目不入 roster**：账号显示名不再被「+ 多模态」接管变体标记污染（宿主模型选择器内的该标记保留——功能指示语义不变）。

### 变更

- **EVO-016（用户指令 2026-09-05）**：设置页四张分级分类卡（预设 Agent / 专业 Agent / 多模态账号 / 统计信息）现**全部默认折叠**（专业 Agent 卡由默认展开改为默认折叠）。

### 破坏性变更

**无。**论证（四证）：① **配置面零新增节**——不新增/变更任何用户配置项；② **依赖面零变更**——deps/peerDeps 与 v0.4.4 逐项一致；③ **数据面**——v1 调用明细行双向兼容；新增 v2 作用域行仅影响**降级读取**方向（旧版无法读取、最坏情形被旧版修复机制清除），该唯一降级面已在下方「已知行为」段「降级兼容」条目如实披露并给出备份步骤；④ **行为面**——统计视图重构与归并修复对历史行全部读侧归一（盘面零改写），路由/账号/预设功能行为不变。

### 已知行为 / 口径披露

- **降级兼容（回滚数据边界）**：v0.4.5 产生的 v2 统计行（含预设作用域 scope 行——账号级请求计数的数据源）无法被 v0.4.4 及更早版本读取（旧版行校验无 scope 分支，整体拒收）；拒收后的下落不能从既有记录确证，**最坏情形**下降级后首次统计加载会触发旧版坏行修复机制、**不可逆清除这些 v2 行**（该使用窗的请求计数历史丢失）。如需降级请**先备份统计目录**（`DSH_HOME/dsh-agent-router/stats/`）或明确接受 v2 行丢失；v1 调用明细行双向兼容，不受影响。
- **账号级调用数 = 请求口径**（每次 LLM 请求恰记一条，覆盖全部路由形态）；**token / 耗时 / 失败数 = 调用明细口径**——插件自有流才有 token，直连 provider 端点无 token 上报时显示 0，因此调用数可能大于有明细的调用条数（统计页内有口径说明文案）。
- **历史误归数据不自动纠正**：归并修复作用于其后的新折叠与重启重放；已落盘聚合中的历史误归（如拆卡时期的数字）保持原样——重发验证请求或一键清空重记即可获得正确归并。
- **「宿主路由（账号未知）」回落卡**：仅在无任何启用的 host transport 订阅账号时出现（诚实回落，不伪装成已知账号）。
- **多预设 ChatGPT 账号场景**：宿主路由用量归首个启用账号（与路由自身的确定性选择同源——单一凭据 ref 只能持有一份 JWT）。
- **某形态会话的 GUI 预设下拉不发切换请求（宿主域，DEFERRED-001 延续披露）**：header 无预设信息的会话上 GUI 预设下拉切换不产生请求——DSH 宿主层问题，插件链路已验证无责；规避：该形态会话改用「新建会话选预设」，或任意一次直接切换动作后即恢复。
- **带切换历史的空白会话重启后状态可能非最后预设配置（宿主域，延续披露）**：切一次预设即恢复；随后续批次或宿主申报处理。
- **会话内切换模型会同步改写全局默认（宿主域，延续披露）**：宿主 0.1.2-rc.1 起 GUI/插件在会话内选择模型都会同时保存为全局默认（宿主 GUI 手动选择同路径，非插件引入）；如需固定全局默认请在「设置 → 模型」中调整。
- **候选台账延续（随版披露，不阻发布）**：FIX-031 审查台账余项（F-3 scope 丢弃可观测 / F-4 浏览器面双定义合并 / O 系观察项等未修事项）与既有候选批（EVO-013/022 台账、路由体验、AUDIT-001 台账、FIX-281）继续分级登记，随后续批次消化。
- **本项目暂无持续集成（CI）自动化**（v0.3.0 起披露延续）：回归保护依赖发布前本地全量测试网（tests/ 下 21 面门控套件清单复跑，见「版本说明·验证基线」）。

### 版本说明

- **版本号**：0.4.4 → **v0.4.5**（版本位按用户发布裁决 2026-09-07「发布版本承载这次修改」；零 breaking 见「破坏性变更」四证——数据面仅新增 v2 作用域行且降级面已披露。版本位惯例先例：本仓 0.x 阶段以用户裁决 + 惯例覆盖 semver 严格口径——v0.4.1 曾以 PATCH 位承载订阅生图 + 画布架构等更大新功能面；若未来收紧版本纪律以 DEC 立版）。
- **发布范围**：v0.4.4（tag `246ced1`，2026-09-06）以来 main 全部提交 **19 个**（`git rev-list --count v0.4.4..HEAD` 实采）。三分账：**产品提交 14 个**——FIX-030 `3b1013e`（宿主预设链双断裂修复 + 生效观测面）+ EVO-016 `a12d129`（专业 Agent 卡默认折叠）+ EVO-017 `4b19d31` / `8a81c3d` / `384058c`（统计分级重构 + 布局与归属修正 + 账号补源与三段统一）+ FIX-031 九笔 `770d9e0`（归因单点化主批）/ `978ea53` / `8a7c564`（F-1 跨午夜双计 + F-2 常量锚定返工）/ `339123f`（D5/D6/D7 通路归并收口）/ `2bb793c`（N1 判别补缺）/ `3ddd321` / `d1f2c29`（D8 启动竞态 + N2 persist 复检）/ `ce63bf0`（D9 身份解耦）/ `15135b7`（D10 roster 污染）；**治理提交 5 个**——FIX-030 治理入账 `4d7cbf5` + EVO-017 入账 `19ce903` / `11755ab` / `a0ff3c4` + REL-010 发布终态 `3307d3f`。**结论行：14 + 5 = 19，与实采一致；产品提交在本节语义全覆盖，治理提交不入用户面。**
- **验证基线**：E-1 门控冒烟面四套件（smoke / stats / fix-031 103 断言 / client-render）退出码 0；全量 21 套件零回退（FIX-031 D10 批实测，D 系判别组累计 103 断言含 stash 法 RED 对照）。发布链后续步骤回填：E-2 门控全量复跑、E-3 隔离冷装、E-4 发布审查结论（由 REL-011 链各自入账，本节不预填）。

## v0.4.4 — 2026-09-05

### 摘要

**宿主演进兼容版（热修）**。核心变化一句话：**DSH 宿主升级到 0.1.2-rc.1 后出现三处适配断裂——设置页整页「加载失败」（旧客户端连接面 `connection.api` 被宿主移除）、贴图不再自动跳「+多模态」（composer 槽位 props 契约演进）、手切「+多模态」后首张图片在气泡中被转成文字标记（会话模型选择持久化面演进）——本版把三面全部对齐宿主现行契约（行为恢复 v0.4.3 语义）**。

### 修复

- **设置页「Agent 路由」加载失败（用户报障 2026-09-05，截图 sha256:61a445ce…）**：宿主 dsh 0.1.1-rc.8 → 0.1.2-rc.1 升级后，插件旧客户端经 `connection.api`（旧 apiproxy 信封面）读取 llm/settings/credentials 等——该字段已在宿主新连接面中移除（dsh-client-connection 0.1.2-rc.1 源码实证）→ `api` 恒 undefined → 整页加载失败。修复：`hostApiFace` 适配层把宿主新面（`remote.llm / settings / credentials / agentPresets / session`，typert remote `{ok,value|error}` 直面 + 位置参数）收敛回插件既有消费信封（页面与组件消费点零改动）；provider 目录经 registered∪declared 连接（与宿主「设置 → 模型」页同构语义）；会话模型读取经宿主 modelDirectories（新宿主已无 per-session wire RPC）；模块 inject 声明命名空间面（激活前等待挂载，宿主官方先例）；**旧 `connection.api` 路径删除（多触发来源单路径，被取代路径不并存）**；命名空间缺失 fail-loud——页面显示可诊断原因而非裸 TypeError（P8/P9 守护）。
- **贴图不再自动接管到「+多模态」（用户报障 2026-09-05，问题①）**：宿主 0.1.2-rc.1 起 composer 槽位 `conversation.input.right` 的标准 props 只提供 `useInput`（订阅 hook）等，不再提供 `input`（快照 prop）——接管组件读不到草稿图片数 → 永不武装（会话日志实证：贴图后无 `model/selection` 接管事件）。修复（两处）：接管组件经 `useInput((s)=>s)` 读取输入快照（旧宿主/旧形态双兼容；判别 B1 旧代码必败）+ **装配点补 `useInput` 透传**（真根因——组件内修复被装配层短路：`apply()` 转发处仍只传旧 `props.input`（新宿主恒 undefined），探针实测三联证据闭环定位；装配点源码契约守卫 C1-C4 防复活）。
- **手动选择「+多模态」后首张图片在气泡中被转成文字标记（用户报障 2026-09-05，问题②，截图 sha256:f16a224b）**：新宿主把会话模型选择持久化为 `model/selection` 会话事件（宿主请求路由以其 pending 为第一优先级），而插件 pre-step 判定链仍从「日志末条请求头」读会话路由——切换后第一次发送时该请求头还是旧 provider（当前请求的头此刻尚未写入）→ 误判「未在包装路由」→ 逃生组把图片块改写成 route_agent 文字标记并持久化进会话日志（故障会话 94adf09f 事件链三点实证：手切 twin → 图片被改写 → 实际请求确实走了 twin）。修复：判定链增加 durable pending 优先层（与宿主请求路由同序；旧宿主无此投影时回落原链，双向兼容）。修复后：包装路由会话（含手切/自动接管）的图片块保留在会话日志中，气泡正常显示图片。

### 变更

- **接管链 F12 可观测遥测**：自动接管组件的每次评估在浏览器控制台输出结构化日志（前缀 `dsh-agent-router[FIX-029]`）——`switched`（成功切换，info）/ `skip-armed-wrapped`（已在包装组，info）/ `models-failed` / `models-empty` / `skip-capability` / `switch-failed` / `face-missing` / `error`（均为 warn）。此前接管失败完全静默（本轮真机首验「贴图不切且无任何痕迹」的排障成本由此终结）；仅闲逛态（`skip-idle`）不打印。
- **无用户可见配置变更**：纯客户端数据面适配层 + pre-step 判定链对齐宿主（内部注解：FIX-028 + FIX-029；判别组 11 + 19 断言均 RED（旧代码+新宿主面夹具必败）→GREEN；门控全量套件退出码 0 零回退）。

### 破坏性变更

**无。**论证（四证）：① **配置面零新增节**——不新增/变更任何用户配置项；② **依赖面零变更**——deps/peerDeps 与 v0.4.3 逐项一致；③ **数据面零变更**——不触碰任何存储格式与用户数据；④ **行为面**——页面/路由/统计/账号功能行为不变，仅数据面与判定链对齐宿主现行契约（恢复宿主升级前的既有语义）；**宿主面跟随披露**：本版面向宿主 ≥0.1.2-rc.1（旧连接面已被宿主删除，插件无法继续支持——宿主侧移除非本版引入，若运行在已删除该面的宿主上会得到可诊断的「remote face 不可用」错误而非静默空载）；旧宿主（≤0.1.1-rc.x）上 FIX-029 判定链回落原路径、FIX-028 的 remote 命名空间面不可用——不支持组合，无回退承诺。

### 已知问题

- **本项目暂无持续集成（CI）自动化**（v0.3.0 起披露延续）：回归保护依赖发布前本地全量测试网（**十九面套件清单全绿复跑**——tests/ 下全部 .mjs 门控套件，metrics.mjs 为观测脚本非门控面；见「版本说明·验证基线」）。
- **某形态会话的 GUI 预设下拉不发切换请求（宿主域挂账 DEFERRED-001）**：header 无预设信息的会话上，GUI 预设下拉切换不产生切换请求（F12 Network 零请求行实证）——DSH 宿主层问题，插件链路已验证无责。规避：该形态会话改用「新建会话选预设」，或任意一次直接切换动作后即恢复跟随。
- **带切换历史的空白会话重启后状态可能非最后预设配置**：切一次预设即恢复；随后续批次或宿主申报处理。
- **会话内切换模型会同步改写全局默认模型（宿主新语义随版披露）**：宿主 0.1.2-rc.1 起 GUI/插件在会话内选择模型（含接管切到「+多模态」）都会同时保存为全局默认——新会话将继承该选择。此为宿主自身行为（其 GUI 手动选择同路径），非插件引入；如需固定全局默认请在「设置 → 模型」中调整。
- **v0.4.5 候选台账延续（随版披露，不阻发布）**：EVO-015 R0 审查台账（P2-1 断言收紧 + P3×5）与既有候选批（EVO-013/022 台账、路由体验×2、AUDIT-001 台账、FIX-281）继续分级登记，随后续批次消化。

### 版本说明

- **版本号**：0.4.3 → **v0.4.4**（版本位按用户发布裁决——用户选择「正式发布链 REL-010」；FIX-029 经用户裁决并入本版；本版为宿主演进热修，零 breaking 见「破坏性变更」四证）。
- **发布范围**：v0.4.3（tag 5e86d23，2026-09-04）以来 main 全部提交 **14 个**（`git rev-list --count v0.4.3..HEAD` 实采）。三分账：**产品提交 4 个**——FIX-028 `f0438f9`（hostApiFace 适配层）+ FIX-029 `334e9ed`（prestep pending 优先层 + ModelTakeover useInput 面 + 判别组 + served-client 镜像）/ `afe0548`（接管链 P8 遥测 + effect 结构化重构 + 镜像）/ `eda320f`（装配点透传 useInput——真根因修复 + C 组装配点契约守卫 + 镜像）；**治理提交 10 个**——REL-009 收尾 2（`626904b`/`5d3d333`）+ REL-010 E-1（`545ab03`）+ FIX-029 治理链 7（`a289723` CHANGELOG 增补 / `98a5568` EV-151 / `7b99203` EV-152 / `f676da9` tracker 推进 / `a8c5062` EV-153 / `4ddde02` EV-154 / `ac77b01` EV-155）。**结论行：4 + 10 = 14，与实采一致；产品提交在本节语义全覆盖，治理提交不入用户面。**
- **验证基线**：E-2 门控复跑实测 **20/20 套件退出码 0**（十九面门控面 + metrics 观测脚本；判别组 fix-029-host-contract 19 断言——A 组 prestep pending 6 + B 组 useInput 组件面 4 + C 组装配点契约 4，全绿）+ E-3 隔离冷装通过（tarball 1,608,986B → 临时目录隔离安装 0.4.4 → client/prestep 语法 OK + 装配点修复在包内实证）+ E-4 发布审查 R0 **APPROVED_WITH_NOTES / unresolved_blockers=0**（P1×2 = 本节完整性补正——即本段与上两处增补；P2-1 验证基线时点口径已按终值回填）。

## v0.4.3 — 2026-09-04

### 摘要

**标准插件管理版**。核心变化一句话：**`dsh plugin --profile web add / update / remove` 官方管理命令真实可用（此前该通道装而不激活）；README 安装文档双通道化，每条命令经隔离环境实测（在线 git spec 通道随发布链 E-5b 复验后发布）**。

### 新增

- **🔌 dsh plugin 标准管理支持（EVO-015）**：package.json 声明 `dsh.bundle` + 包内 bundle patch 层（`cordis.patch.yml`，与安装脚本写入宿主 profile 的宿主平面行逐字一致——两通道注册同一对服务 `router` / `tool-router`）。README 安装章节双通道化：方式一（推荐）`dsh plugin --profile web add`——npm 安装 dsh / npx 拉起 × 在线 git spec / 离线 `file:` 解压目录（说明 `link:` 只创建符号链接、不安装依赖故不采用），并附 `update` / `remove` 命令矩阵与「从旧方式（junction/脚本）迁移」三步；方式二安装脚本原样保留——已用脚本通道的用户零影响、可继续使用（内部注解：commit `7965c9d`；REVIEW-EVO-015-R0 APPROVED_WITH_NOTES / unresolved_blockers=0；EV-143~144）。

### 修复

- **README 离线安装链接勘误（EVO-015 顺带取证）**：v0.4.2 及此前的发行资产名**无 v 前缀**（`dsh-agent-router-X.Y.Z.tar.gz`）——旧文档链接（带 v 前缀）实为 404 坏链（GitHub API 列举 + 实下载核验）；发行包为 npm pack 形态（解压根目录固定 `package/`），旧文档的 `cd dsh-agent-router-vX.Y.Z` 目录名不存在——离线安装步骤已按真实结构改写。

### 变更

- **files 列表新增 `cordis.patch.yml`**（打包完整性——bundle patch 层随发行包分发）。
- **install-entry 新增 11 条判别断言**（dsh.bundle 声明 / patch 层逐字一致 / README 双通道命令守卫；`tests/smoke.mjs` 1087 → 1098，零回退）。

### 破坏性变更

**无。**论证（四证）：① **配置面零新增节**——`dsh.bundle` 为包清单声明（宿主 `dsh plugin` 通道读取），不新增任何用户配置项；② **依赖面零变更**——deps/peerDeps 与 v0.4.2 逐项一致，仅 files 列表 +1；③ **数据面零变更**——不触碰任何存储格式与用户数据；④ **行为面零强制**——双通道并存，既有脚本通道安装（junction + 手写 patch 行）运行时零影响（宿主 loadProfile 仅映射 profile 的 `dsh.profile.bundles` 列表，脚本通道该列表不含本包、不读包内 `dsh.bundle` 字段）。

### 已知问题

- **本项目暂无持续集成（CI）自动化**（v0.3.0 起披露延续）：回归保护依赖发布前本地全量测试网（**十八面套件清单全绿复跑**——tests/ 下全部 .mjs 门控套件，metrics.mjs 为观测脚本非门控面；见「版本说明·验证基线」）。CI 建设已列入后续排期。
- **某形态会话的 GUI 预设下拉不发切换请求（宿主域挂账 DEFERRED-001）**：header 无预设信息的会话上，GUI 预设下拉切换不产生切换请求（F12 Network 零请求行实证）——DSH 宿主层问题，插件链路已验证无责（同会话直发 RPC 正常）。规避：该形态会话改用「新建会话选预设」，或任意一次直接切换动作后即恢复跟随。
- **带切换历史的空白会话重启后状态可能非最后预设配置**：重启恢复的空白老会话（此前切换过预设）显示状态可能不是最后预设的配置（resume 链 header 无预设 + 事件重放交互缝隙）——**切一次预设即恢复**；随后续批次或宿主申报处理。
- **标准管理通道的已知边界（本版新增）**：在线 git spec 安装需本机 git 与 GitHub 可达；`dsh plugin` 通道依赖 pnpm（宿主无 pnpm 时报 exit 127 明确提示）——README 已注明前置要求，属环境前置非缺陷；离线通道用发行包 `file:` 安装不受 git/GitHub 影响。
- **P3 台账批（随版披露，不阻发布）**：审查台账中的 P3 级改进项（断言收紧 / 文案小项等）延续分级登记为 v0.4.4 候选，随后续批次消化（内部注解：P2-1/P3 台账不动，入 v0.4.4 候选）。

### 版本说明

- **版本号**：0.4.2 → **v0.4.3**（版本位按用户裁决 v0.4.3 立即发布；新增面为标准管理声明与文档双通道化，零 breaking 见「破坏性变更」四证）。
- **发布范围**：v0.4.2（tag e91f77d，2026-09-02）以来 main 全部提交 **3 个**（`git rev-list --count v0.4.2..HEAD` E-1 时点实采 = 2，加本提交）。三分账：**产品提交 1 个**——EVO-015 `7965c9d`（dsh.bundle 声明 + 包内 patch 层 + README 双通道文档 + install-entry 判别）；**治理提交 1 个**——`c2be6dc`（REL-008 tracker 终态，归属 v0.4.2 发布链尾账，不入用户面）+ **REL-009（本提交——version bump + 本节收口 + README 版本校对，hash 见 git log）**。**结论行：1 + 1 + 本提交 = 3，与实采一致（2 + 本提交）；产品提交在本节语义全覆盖，治理提交不入用户面。**
- **验证基线**：E-1 时点 `node tests/smoke.mjs` **1098 ok / 0 FAIL / exit 0**（含 install-entry 判别 11 断言）。内部注解：发布执行段 E-2 十八面门控复跑（tests/ 下全部 .mjs 门控套件，metrics.mjs 观测脚本除外）与 E-3 tarball 隔离环境安装冒烟（环境变量重定向至临时目录）随发布链执行，最终以复跑实测值为准。

## v0.4.2 — 2026-09-02

### 摘要

**预设 Agent 默认模型全链承载版**。核心变化一句话：**按 DSH 预设粒度配置主 Agent 与 subagent 的默认模型——设置页新增「预设 Agent」卡片，新会话打开即显示、切换预设实时跟随；配套修复链收口（预设列表域名 / 播种静默失效 / 显示刷新单路径收敛 / 遥测可观测）**。

### 新增

- **🎯 Agent 预设默认模型（EVO-013 + EVO-014）**：设置 → Agent 路由新增「预设 Agent」折叠卡片（默认折叠、空列表起步；统一添加模板下拉直接选择 DSH 预设）——按 DSH 预设粒度配置主 Agent 默认模型与 subagent 默认模型；新会话/空白会话切换预设时模型选择器**即时跟随**（打开即显示，无需先发消息；空白判据与宿主同构——未开启过对话轮即可切）；会话内手动选择始终优先（用户主权）；subagent 未配置时继承主预设模型；未配置预设零行为变化（完全遵循 DSH 现行规则）。播种借用宿主会话模型选择通路，其附带的全局默认写入**立即自动写回恢复**（瞬态毫秒级，通常不可感知；恢复失败自动重试一次并高声告警）；多个播种事件并发到达时按内部**串行化队列**依次执行，不会污染全局默认（内部注解：EVO-013 配置面 + EVO-014 事件驱动重构——模型只跟随两个预设事件，彻底移除会话过程介入）。

### 修复

- **预设列表加载失败（FIX-022）**：roster RPC 域名误用单数 `api.agentPreset.list`（宿主命名陷阱：wire 方法名单数、JS 组名复数，真实域名为 `api.agentPresets`）→ TypeError 致「预设 Agent」下拉不可用。修复：域名对齐 + 三层防御（复数优先 / 单数回落 / 缺域明确诊断）。
- **切换播种静默失效（FIX-023）**：`ctx.agents` 属性面访问恒 undefined（插件 inject 未含 agents 服务）→ 切换预设后的播种静默失效。修复：`ctx.get('agents')` 调用时解析 + 失败 warn 可观测。
- **显示刷新单路径收敛（FIX-024 → FIX-026）**：切换预设后模型选择器显示不跟随（目标 = 全局默认时设置写无差异、刷新事件不触发）。最终态：客户端 `agent-preset/selected` 事件直驱模型目录重载（与「打开即加载」同源同对象）——中间态的服务端 emit 路径经真机取证不可达，已删除（多触发来源单路径汇入，旧路径不并存）。
- **modelDirectories 规范注入 + 结构化遥测（FIX-027）**：客户端对 modelDirectories 的裸解析在真机解析失败致显示仍不跟随。修复：宿主 inject 规范声明 + 双形态解析防御 + 结构化遥测——排障时浏览器 F12 控制台可见 `dsh-agent-router[FIX-027]` 前缀的播种链路日志。

### 变更

- **文档**：README 三大主要功能置顶刷新（①Agent 预设与 subagent 默认模型配置 ②专业 Agent 配置 ③ChatGPT 订阅登录 + 主模型调用）——简介/项目目标/特性列表对齐现能力面。
- **治理（无用户面）**：项目质量原则升级至 P-v3（新增用户报障受理与验证纪律五条 + 单路径收敛强化）——纯治理资产，用户可见行为零变化。

### 破坏性变更

**无。**论证（四证）：① **配置面零破坏**——`router.presets` 为新增配置节（缺省空字典），旧配置零迁移零阻塞；未配置预设时零行为变化；② **依赖面零变更**——除版本号与 files 列表新增 `lib/preset-defaults.js`（打包完整性，只增不减）外，package.json 依赖面（deps/peerDeps）与 v0.4.1 逐项一致，pnpm-lock 零变更；③ **数据面零变更**——无既有 Schema/存储格式变更（预设配置为新命名空间，不触碰 oauthAccounts / 统计 JSONL / 凭据文件）；④ **行为面零强制**——默认层选择权在三层主权保护之下（picked/header 优先，仅空白会话、仅预设事件播种、无模型变更监听）；已运行会话与显式指定模型的子代理不受影响。

### 已知问题

- **本项目暂无持续集成（CI）自动化**（v0.3.0 起披露延续）：回归保护依赖发布前本地全量测试网（**十八面套件清单全绿复跑**——tests/ 下全部 .mjs 门控套件，metrics.mjs 为观测脚本非门控面；见「版本说明·验证基线」）。CI 建设已列入后续排期。
- **某形态会话的 GUI 预设下拉不发切换请求（宿主域挂账）**：header 无预设信息的会话上，GUI 预设下拉切换不产生切换请求（F12 Network 零请求行实证）——DSH 宿主层问题，插件链路已验证无责（同会话直发 RPC 正常）。规避：该形态会话改用「新建会话选预设」，或任意一次直接切换动作后即恢复跟随。
- **带切换历史的空白会话重启后状态可能非最后预设配置**：重启恢复的空白老会话（此前切换过预设）显示状态可能不是最后预设的配置（resume 链 header 无预设 + 事件重放交互缝隙）——**切一次预设即恢复**；随后续批次或宿主申报处理。
- **P3 台账批（随版披露，不阻发布）**：EVO-013 / FIX-022 / EVO-014 / FIX-023 / FIX-025 / FIX-027 各任务审查台账中的 P3 级改进项已分级登记（parent 查询失败保护降级披露 / 测试缺口三处 / liveDefaultSelection 双份实现去重 / fixture 字段同构 / 覆盖观察 / 回落可选加固等），随后续批次消化；另 v0.4.1 候选批（路由体验优化 ×2 + AUDIT-001 台账 P1×3/P2×13/P3×23）记录待排期。

### 版本说明

- **版本号**：0.4.1 → **v0.4.2**（MINOR：完整新能力面——新配置节 + 新设置卡片 + 新事件行为，向后兼容；零 breaking 见「破坏性变更」四证；先例 v0.4.0：功能面 = MINOR）。
- **发布范围**：v0.4.1（tag 40816dc，2026-09-01）以来 main 全部提交 **31 个**（`git rev-list --count v0.4.1..HEAD` 实采 2026-09-02 = 30，加本提交）。三分账：**产品提交 16 个（按任务族，SHA 底账全量）**——EVO-013 ×4（`2ab27d6` 机制 / `97b04ac` UI 卡片 / `08e0461` README 使用指南 / `75434e7` Rework）+ EVO-014 ×3（`de72e0c` 事件驱动重构 / `fe0a94e` Rework / `4e1d9cc` MicroFix）+ FIX-022 ×1（`740f95a` 域名对齐 + 三层防御）+ FIX-023 ×1（`afa6ddc`——混合 commit：产品代码与治理记录同车，按 diff 实采归属产品面）+ FIX-024 ×1（`ba36836`——显示刷新中间态，已被 FIX-026 单路径收敛取代并删除，以最终态发布）+ FIX-025 ×1（`a80e935` 空白判据与宿主同构）+ FIX-026 ×1（`98299e5` 客户端直驱 + 旧路径删除）+ FIX-027 ×2（`8c4cfc5` 规范注入 + 遥测 / `6d5e357` 镜像同步）+ DOC-001 ×1（`2e1cdf8` README 功能面刷新）+ **REL-008（本提交——version bump + 本节收口 + README 同步，hash 见 git log）**；**治理提交 15 个（不承载用户可见变更）**——`39506cd` / `de101c0`（REL-007 E-6/tracker 终态，归属 v0.4.1 发布链尾账，随本版范围携带）+ 治理入仓/收尾机录 ×12（`803f9fc` / `7dc78fe` / `9c3ee78` / `4608413` / `06ada14` / `5988286` / `017a3fc` / `7f68c96` / `3578d28` / `d29bc4a` / `07c8d94`（GOV-005 P-v3 原则）/ `6a5f029`（GOV-006 终态归档））+ `4138f53`（REL-008 规划段终态：version-plan R1 入仓 + 双机录 + tracker 收口）。**结论行：16 + 15 = 31，与实采一致（30 + 本提交）；产品提交经逐 commit 对照在本节语义全覆盖，治理提交不入用户面。**
- **验证基线**：E-1 时点 `node tests/smoke.mjs` **1087 ok / 0 FAIL / 1 skip / exit 0**（含 client-render 渲染级看护 207 断言基线与 README 一致性守卫）；**用户真机复验在案**（预设卡片配置 / 新会话打开即显示 / 老会话切换跟随 / subagent 继承——EVO-013/014、FIX-022~027 用户复验链）。内部注解：发布执行段 E-2 全量门控复跑（**十八面套件清单**——tests/ 下全部 .mjs 门控套件（metrics.mjs 观测脚本除外），含 preset-defaults / routing-paths / adapter-parity / install-entry 等）与 tarball 隔离环境安装冒烟（环境变量重定向至临时目录）随发布链执行，最终以复跑实测值为准。

## v0.4.1 — 2026-09-01

### 摘要

**订阅生图 + 视觉产物画布 + 主模型官方路由版**。核心变化一句话：**ChatGPT 订阅可生成图片（gpt-image 系）、生成图经插件同源画布直达显示（不再受宿主附件通道牵制）、主模型默认走宿主官方 openai-codex 路由（token 自动注入）**。

### 新增

- **ChatGPT 订阅生图（EVO-011）**：draw agent 绑定订阅账号即可出图——经 chatgpt.com codex images 专用端点（OpenAI Images API 兼容；调研 RES-004 三层证据：DSH 自家 dsh-codex-connect 实证 + openai/codex 官方源码 + 社区探针）；gpt-image-* 模型透传（默认 gpt-image-2，dall-e-3 等旧默认自动换型并提示）；尺寸/质量参数支持 + 订阅额度错误（429 usage_limit）友好提示；真实端点实测通过（200 + PNG）。**勘误**：v0.3.0 时代「订阅 OAuth 无 Images API」的判断对 api.openai.com 平台成立，但漏了 chatgpt.com codex 后端端点（用户质疑驱动修正）。
- **视觉产物画布架构（EVO-012，用户提案）**：生成图经插件同源 HTTP 路由（`/router-assets/` 内容寻址）直达显示——彻底绕开受宿主网关断言演进反复牵制的 imageData RPC 通道（FIX-008 域历史遗留根除）；route_agent 工具卡默认折叠（摘要行 + 缩略图，过程收起、结果直出）；识别场景不再复读用户发的图（输入回显消除）；旧产物自动自愈显示；会话产物集合（输入区 🖼 图标按钮 → 网格 → 放大，悬停显示计数）。
- **主模型宿主官方路由（EVO-010，用户「复用宿主」质疑驱动）**：ChatGPT 订阅默认经宿主官方 openai-codex 路由——插件自动维护 provider 条目 + OAuth token 热注入刷新 + P9 parity 守卫自动回滚 + 降级开关「插件内置」通路保留；桥接可行性经 ARCH-003 调研（三层证据）+ 真机 PoC 实证（文本/图片全通、模型直接识图零中转）。

### 修复

- **生成图显示三连败真根因（AUDIT-001 P0-A）**：React 18.3.1 的 `ref` 是保留 prop（`createElement` 剥离）——组件以 `ref` 传图片数据导致恒 `undefined`、直达路径从未生效（必现非偶发）。修复：prop 更名 `imageRef` + 惰性 getter 单次访问快照。**历史测试全绿的原因**：测试 shim 原样透传 props，与宿主 React 语义存在 parity 缺口——已建立宿主语义同构判别 harness 看护（同类缺口不再漏检）。
- **凭据竞态（AUDIT-001 P0-B）**：登出/登录写绕过凭据文件锁、与在途 token 刷新交错——登出后凭据「复活」、新登录被旧 token 链覆写。修复：锁收敛 + 盘上 CAS 双保险。
- **并发审计 41 条台账（AUDIT-001，用户指令专项审计）**：全库并发正确性专项审计分级登记 P1×3（CLI 中止漏检/附件同名覆盖/产物归属竞态）+ P2×13 + P3×23，随 v0.4.2 批次消化（本版承载其中 P0×2，见上两条）。
- **幽灵卡三形态（FIX-019）**：统计键/宿主路由真条目混入账号管理、渲染假编辑器——判据单点化三重排除。
- **数据防护链（FIX-015）**：模型列表保存读写对称（空编辑态不再空覆盖——用户数据丢失根因修）+ 写路径防缩小守卫 + 实预填（placeholder 幻觉根治）+ 空值可观测。

### 变更

- **ChatGPT 订阅组默认不注册**：host 模式下订阅主模型由 openai-codex 官方组承载（见「新增·主模型宿主官方路由」），订阅卡保留「插件内置 / 宿主官方路由」双通路开关。
- **生成物按钮纯图标**：28px 方形按钮内的文本竖排折行修正——入口改纯图标，产物计数移入悬停提示（用户反馈驱动，2026-09-01）。

### 破坏性变更

**无。**论证（四证）：① **依赖面零变更**——除版本号与 files 列表新增 `lib/host-route.js`（打包完整性，只增不减）外，package.json 依赖面（deps/peerDeps）与 v0.3.3 逐项一致；② **配置面零破坏**——schemas 新增字段均带默认值（如订阅卡 transport 通路开关），无键删除、无默认行为翻转，旧配置零迁移零阻塞；③ **数据面零变更**——统计 JSONL / 凭据文件 / oauthAccounts 结构不变（凭据竞态修复仅收窄写窗口，不改变存储格式）；④ **行为变化均为缺陷修复与新增能力**——画布架构为显示通路新增（imageData RPC 保留为旧产物回退）、官方路由默认带降级开关（「插件内置」通路完整保留）、审计修复均为正确性收窄而非能力收窄。

### 已知问题

- **本项目暂无持续集成（CI）自动化**（v0.3.0 起披露延续）：回归保护依赖发布前本地全量测试网（十七面全绿复跑，见「版本说明·验证基线」）。CI 建设已列入后续排期。
- **对话内图片附件「加载失败」显示层遗留已根治（历史披露收口）**：v0.3.0~v0.3.3 连续披露的显示层残留（FIX-008 域）经 v0.4.1 双线根治——视觉产物画布架构（同源路由绕开 imageData RPC 通道）+ React 18 `ref` 保留 prop 真根因修复（AUDIT-001 P0-A——此前「直达路径」实际从未生效）。
- **deepseek-official 视觉端点挂起**（宿主/端点域，EV-088 披露延续）：227s/0token 挂起属上游端点现象，vision 旁路（glm 等可用服务商）可用——本仓不可修，不构成本版回滚触发条件。
- **picked 层盲区**（宿主固有 P3，延续）：selectModel 进程内选择不落 header/options 且插件无访问 API——selectModel 后首轮 prestep 与宿主判定可能短暂不一致，属宿主设计固有窗口（注释披露在案）。
- **并发审计台账 41 条待消化（本版新增披露）**：P1×3（CLI 中止漏检/附件同名覆盖/产物归属竞态）+ P2×13 + P3×23 已分级登记，随 v0.4.2 批次修复。
- **reasoning 回传缺口（本版新增披露，FIX-017 发布门必验项延续）**：多工具往返深场景 reasoning 回传验证缺口，已随主通路切换宿主官方 openai-codex 路由缓解（官方通路原生承载 reasoning）；「插件内置」降级通路的该场景仍待验证。

### 版本说明

- **版本号**：0.3.3 → **v0.4.1**（MINOR：两大新能力（订阅生图/主模型官方路由）+ 一架构迁移（视觉产物画布）+ 并发审计 P0×2 修复；零 breaking 见「破坏性变更」四证）。**无 0.4.0 中间版说明**：v0.4.0 候选内容（EVO-009 主模型直选 + EVO-010 官方路由）已于 2026-08-31 在 main 完成开发与审查，但发布链被用户裁决暂停、未及发布——0.4.0 候选与 0.4.1 批次（EVO-011/012 + FIX-020/021 + AUDIT-001）合并为一次发布，semver 允许跳版（0.3.3 → 0.4.1，MINOR 跃迁一次到位，0.4.0 号段不占用）。
- **发布范围**：v0.3.3（tag e818183，2026-08-30）以来 main 全部提交 **44 个**（`git rev-list --count e818183..HEAD` 实采 2026-09-01 = 43，加本提交）。三分账：**产品提交 30 个（按任务族，SHA 底账全量）**——EVO-009 ×2（`01729a2` 订阅账号注册主模型 provider / `bc500f7` files 列表补 oauth-llm）+ FIX-015 ×5（`e170cf2` 空模型 P8 告警 / `fef785b` 幽灵卡过滤+空提示+镜像 / `c9a8deb` 实预填+防呆 / `86fb209` 读写对称 / `af6a1f8` 防缩小盘点）+ FIX-016 ×1（`a410a52` tools 映射真形状修复）+ FIX-017 ×1（`6b2ada3` multi-turn 映射契约重构）+ FIX-018 ×3（`1d77817` 武装条件补判定 / `e70028c` 直传判定核查 / `d52b716` 镜像同步）+ EVO-010 ×4（`30dd55e` host-route 服务端 / `82ae39a` 通路开关 UI / `3ead43f` 收尾卫生 / `31ab145` R0 返工）+ FIX-019 ×3（`6e456ce` chatgpt-oauth 过滤 / `961aa13` openai-codex 三判据 / `321a5ef` 判据语义拆分）+ EVO-011 ×2（`1dd124b` 订阅生图直连 / `f3268af` UI 类型化+镜像）+ EVO-012 ×4（`6d12289` 同源路由 / `9b751a1` 折叠+直达 / `1f08e18` 输入回显消除 / `120c058` url 自愈+集合视图）+ FIX-021 ×1（`2e945f6` attachment.id 兜底）+ AUDIT-001 ×3（`b0683a2` P0×2 修复+判别入网 / `1832db0` 生成物按钮纯图标 / `2aa9316` emoji 断言修正）+ **REL-007（本提交——version bump + 本段收口 + README 同步，hash 见 git log）**；**治理提交 14 个（不承载用户可见变更）**——`4fecc06`（REL-006 E-6 尾账，归属 v0.3.3 发布链）+ `c477930`（v0.4.0 发布链暂停留痕）+ 治理收尾机录 ×12（`4b59d09` / `13cd084` / `e81ac6b` / `8120048` / `b12dc5f` / `30281d7` / `d1c5c1e` / `53cbb80` / `04231a7` / `5b24ca3` / `d8dc44a` / `2544e66`）。**结论行：30 + 14 = 44，与实采一致（43 + 本提交）；产品提交经逐 commit 对照在本节语义全覆盖，治理提交不入用户面。**口径注记：`4fecc06` 为 v0.3.3 tag 后落盘的 v0.3.3 发布链尾账（先例：v0.3.2 口径注记），不在 v0.3.3 范围计数内、计入本版治理面。
- **验证基线**：门控 **17 套件全绿 exit 0**（含 AUDIT-001 审计判别 14 断言——宿主 React 语义同构 harness（RED 复现后转绿）/ FIX-015 判别组 / oauth-main-model 40 断言 / EVO-012 判别 RED/GREEN 三轮）；`tests/smoke.mjs` **1037 ok / 0 FAIL**；served-client 镜像一致；**真实端点实测**（订阅生图 200 + PNG ≈665KB（680,946 字节；908K 为 b64 字符长度非解码后体积） / 官方路由文本+图片全通——插件同款头部+代理链+只读凭据零泄漏）；**用户真机验证**（生图直达显示 / 生成物纯图标按钮 / 官方路由多模态识图）。内部注解：发布执行段 bump 后全量门控复跑与 tarball 隔离环境安装冒烟（环境变量重定向至临时目录）随发布链执行，最终以复跑实测值为准。

## v0.3.3 — 2026-08-30

### 摘要

**用户报障三连热修 + 默认模型更新版**。核心变化一句话：**统计面板恢复显示（v0.3.0 起即断的读侧 RPC）、文本模型贴图自动切多模态、ChatGPT 绑定测试按钮不再 400、预设默认模型更新为 gpt-5.6 系**。

### 修复

- **统计面板恒 0（P0，FIX-011）**：v0.3.0 统计迁移引入实例字段遮蔽同名 RPC 方法（`stats` 字段遮蔽 `stats` 方法）→ 宿主网关 method-unavailable → 设置页统计轮询静默失败（**记录/持久化一直正常，磁盘数据完好**）。修复：stats RPC 描述符 implementation 显式指向 `statsSnapshot` + 17 描述符全量守卫测试（tests/rpc-shadow-guard.mjs 21 断言——未来任何 RPC 方法被字段遮蔽必败）。
- **文本模型发图被拦（P0，FIX-012）**：宿主准入按当前选中模型的能力拒绝带图消息（「当前模型不支持图片，请切换支持图片的模型」Toast）；插件自动接管自 FIX-002 起默认关闭 → 文本主模型贴图即被拦。修复：**图片条件化武装——贴图即自动切「\<provider\> + 多模态」包装路由、发送后保持**（文本轮经包装路由零开销委托原生模型；带图轮放行准入并改写路由提示；判别测试 tests/fix-012-image-takeover.mjs 22 断言）；无图/纯文本轮永不自动切换、用户手动选择的模型始终尊重（FIX-002 用户主权语义完整）。行为说明：**移除未发送的图片不会自动切回原模型**（宿主无安全区分「发送」与「移除」的机制——selectModel 对会话图片零校验，还原会成功切回纯文本并让下一张图被拦），切回请在模型列表手动选择。
- **ChatGPT 绑定测试按钮 HTTP 400（FIX-013）**：测试路径强制 maxTokens → codex-responses 分支发送 `max_output_tokens` → ChatGPT 后端拒绝该参数（实际调用因不带该参数一直正常）。修复：codex-responses 协议不再发送该参数（用户显式配置 maxTokens 的 OAuth agent 实际调用同样受益）。
- **发布 tarball 缺运行时模块（P0，FIX-014）**：v0.3.0~v0.3.2 的发布 tarball `files` 列表仅打包 7/12 个 lib 模块——缺 `attachments.js` / `memory.js` / `prestep.js` / `stats.js` / `wrapper.js`（均被 index/service/tool 深度导入）→ 安装后插件无法加载（E-3 隔离冷装完整 import 冒烟实证 `Cannot find module ...\lib\memory.js imported from lib\service.js`）。修复：files 列表补齐 5 模块（lib 段全量 12 项按字母序；发布时点由完整 ESM import 冒烟看护——见「版本说明·验证基线」）。**勘误披露：v0.3.0~v0.3.2 的 tarball 安装用户请升级 0.3.3**（junction 开发树安装不受影响——全部文件在位，这就是真机一直正常的原因）。

### 变更

- **ChatGPT 预设默认模型（EVO-008）**：新增账号预填模型 gpt-5.4-mini / gpt-5.4 → **gpt-5.6-sol / gpt-5.6-terra / gpt-5.6-luna**（用户指令 2026-08-30；**已配置账号的 models 字段不迁移不改写**）。client-render 正向断言锁定默认列表（防回归）。

### 破坏性变更

**无。**论证（四证）：① **依赖面零变更**——除版本号与 files 列表（FIX-014 补 5 个缺失运行时模块，只增不减）外，package.json 依赖面与 v0.3.2 完全一致（deps/peerDeps 逐项一致——reviewer 独立核验）；② **配置面零变更**——lib/schemas.js 零触碰（无键增删）；③ **数据面零变更**——统计 JSONL / 凭据文件 / oauthAccounts 结构不变；④ **行为变化均为缺陷修复而非能力收窄**——FIX-011/FIX-013 为回归/缺陷修复，FIX-012 的自动切换仅在贴图时发生且方向为扩展能力（此前被拦的带图消息现在可发）。**如实披露（no-overclaim）**：启用视觉类 agent 后贴图会自动切换会话模型到包装路由（此前需手动开启 takeoverDefaultModel 开关）——属修复而非破坏；且移除未发送图片不自动切回（见「修复·FIX-012」行为说明）。

### 已知问题

- **本项目暂无持续集成（CI）自动化**（v0.3.0/v0.3.1/v0.3.2 披露延续）：回归保护依赖发布前本地全量测试网（十五面全绿复跑，见「版本说明·验证基线」）。CI 建设已列入后续排期。
- **部分宿主下对话内图片附件可能显示「加载失败」**（延续，FIX-008 候选域）：附件识别功能已验通，服务端附件链已修复并验证 7 格式全绿；显示层残留属客户端渲染路径——本版不承载修复。
- **deepseek-official 视觉端点挂起**（宿主/端点域，EV-088 披露）：227s/0token 挂起属上游端点现象，vision 旁路（glm 等可用服务商）可用——本仓不可修，不构成本版回滚触发条件。
- **picked 层盲区**（宿主固有 P3）：selectModel 进程内选择不落 header/options 且插件无访问 API——selectModel 后首轮 prestep 与宿主判定可能短暂不一致，属宿主设计固有窗口（注释披露在案）。
- **接管语义边界（P3 讨论项，review-FIX-012-R0/R1）**：armedBy 来源标记（image 来源永不自动还原 / switch 来源走既有还原）与 deps 完整性（P2-1 已修复）的语义边界记录于审查报告，后续演进（如宿主 selectModel 增加图片校验）时复核。

### 版本说明

- **版本号**：0.3.2 → **v0.3.3**（PATCH）——三缺陷修复 + 一默认值调整，零新能力面，零 breaking（见「破坏性变更」四证）；MINOR 反论否弃：本版无新增功能面（默认模型列表调整属配置默认值更新而非新能力），v0.3.1/v0.3.2 PATCH 先例。
- **发布范围**：v0.3.2（tag d63b368，2026-08-30）以来 main 提交 **10 个**（`git rev-list --count d63b368..HEAD` 实采 2026-08-30）。三分账：**产品提交 8 个**——FIX-013 `5e15c43`（codex-responses 移除 max_output_tokens）/ FIX-011 `52331a8`（stats RPC 描述符修复 + 守卫测试）/ FIX-012 `c3831b4`（图片条件化接管 + 判别测试）/ EVO-008 `922c74f`（预设默认模型 gpt-5.6 系）/ FIX-012 `4f26846`（served-client 镜像同步）/ FIX-012 `5f68c17`（R0 P2-1 deps 修复）/ EVO-008 `785dc1e`（R0 P2-1 正向断言）/ **FIX-014（本提交——files 补齐 + 本段勘误，hash 见 git log）**；**治理提交 2 个**——`b796741` / `3e878b9`（REL-005 E-8 治理收尾尾段，归属 v0.3.2 发布链尾账，不计入产品面）。**结论行：8 + 2 = 10，与实采一致**；产品提交经逐 commit 对照在本节语义全覆盖，治理提交不入用户面；本版治理提交（发布链）随发布入仓。
- **验证基线**：门控 **15/15 套件 exit 0**（含新增 tests/rpc-shadow-guard.mjs 21 断言 / tests/fix-012-image-takeover.mjs 22 断言 / client-render 新增 gpt-5.6 正向断言）；**用户真机验证四项全过**（2026-08-30：统计面板恢复显示 / 文本模型贴图发送成功 / ChatGPT 测试按钮不再 400 / 新账号默认模型 gpt-5.6 系）。内部注解：发布执行段 bump 后全量门控复跑与 tarball 隔离环境安装冒烟（环境变量重定向至临时目录）随发布链执行，最终以复跑实测值为准；**E-3 隔离冷装自本版起升级为完整 ESM import 冒烟**（`node -e "import('dsh-agent-router')"` 全链加载 + tarball 清单核验 lib 12 模块）——历史版本冷装只验版本号与清单、探测深度不足（REL-004/005 口径，FIX-014 即由升级后的 E-3 实证），如实勘误。

## v0.3.2 — 2026-08-30

### 摘要

**多模态双修 + 账号面板 UX 版**。核心变化一句话：**纯图消息不再 400（FIX-009）、对话气泡恢复图片显示（FIX-010）、ChatGPT 订阅登录上移一级醒目位 + 移除不可用的 OAuth 官方登录入口（EVO-007）**。

### 修复

- **纯图消息 400/1213（P0，FIX-009）**：image-solo（用户只发图片无文本）经 wrapper 深改写后 user message content 变空 `[]` → 下游端点 400（GLM 1213「未正常接收到prompt参数」实测）。修复：wrapper 深改写后注入最小 text part（占位文案 `[图片已上传，请按系统提示操作]`）——委托请求恒含非空文本；4xx 快速失败（不重试不重发，错误带 provider/model 诊断）语义保持（判别测试 tests/fix-009-image-solo.mjs 9/9）。
- **对话气泡图片显示回归（P0，FIX-010 + REL-005 P1-1）**：prestep 会话路由判定与宿主实际路由分裂（读 agent.options 创建快照，宿主 selectionFor 实为 picked → 日志 header → live default）——默认模型漂移后误判 onWrapperRoute=false → 逃生组改写把图片块替换为标记文本并持久化日志层 → GUI 显示标记而非图片（用户实证 + 会话实录 ec6b01b0 铁证）。修复：prestep 判定 header 优先（与宿主 selectionFor 同序）+ 回落链补 live default（`agentDefaultModel.currentSelection()`，漂移窗口对齐）+ options 终回退——wrapper 路由会话日志层不再被改写；模型面适配保留在 wrapper stream 输入层（判别测试 tests/fix-010-gui-fidelity.mjs 13/13，含 REL-005 E 组漂移窗口判别）。
- **非 preset OAuth 账号删除路径恢复（EVO-007 R0→R1 返工）**：移除 OAuth 官方登录区块后，池内一键建号 / 历史自定义与粘贴 token / 未知 preset 值账号无删除入口、条目与凭据永久残留（P7 数据主权缺陷）。修复：账号池行「删除账号」按钮 + 高级扩展区「未入池的 OAuth 账号」列表行双入口——unset oauthAccounts 条目 + `credentials.unset(tokenRef)` 凭据清理 + 从全部账号池移除引用（preset 成员仍走 W-5 联动删除）。

### 变更

- **账号面板布局（EVO-007）**：多模态账号区新顺序 = API Key 账号 → **ChatGPT 订阅登录（一级醒目位，正式通道优先呈现）** → 子代理（无头 CLI）→ 高级扩展（仅账号池，折叠壳保留）。
- **「OAuth 账号（官方登录）」管理入口移除（EVO-007）**：官方 API 不提供 OAuth、Gemini 内置公开 Client 已被 Google 禁用——该入口自述不可用，整块移除（含文案/添加按钮/未配置态）；**oauthAccounts 数据域零触碰**（仅呈现层，EV-090），历史账号经账号池 / 未入池列表管理（删除入口见「修复」节）。README「v0.3.2 起」三处披露呼应（特性 / 多模态账号配置 / FAQ）。

### 破坏性变更

**无。**论证（四证）：① **无公共 API/协议面变更，依赖面零变更**——除版本号外 package.json 与 v0.3.1 完全一致（undici ^7.18.0 / peerDependencies 8×^0.1.0-rc.8 / files 11 项维持；产品 commits 零触碰 package.json，review-REL-005-R0「无 bump」实证）；② **无配置面变更**——lib/schemas.js 零触碰（无键增删；settings 遗留键容忍语义与 v0.3.1 相同）；③ **数据面零变更**——oauthAccounts 数据域 / 凭据文件 / 统计 JSONL 结构不变（EV-090「数据域零触碰」）；④ **入口移除对象为从未可用的误导性入口**（官方 API 无 OAuth——移除非能力收窄），行为变化均有披露与官方替代路径（README「v0.3.2 起」三处 + 本版变更节；替代路径 = 官方 API Key / ChatGPT 订阅登录 / 账号池管理）。

### 已知问题

- **本项目暂无持续集成（CI）自动化**（v0.3.0/v0.3.1 披露延续）：回归保护依赖发布前本地全量测试网（十二面全绿复跑，见「版本说明·验证基线」）。CI 建设已列入后续排期。
- **部分宿主下对话内图片附件可能显示「加载失败」**（v0.3.0/v0.3.1 已知问题延续，FIX-008 候选域）：附件识别功能已验通，服务端附件链已修复并验证 7 格式全绿；显示层残留属客户端渲染路径（与 FIX-010「气泡图片消失」为**不同缺陷面**）——本版不承载修复。
- **deepseek-official 视觉端点挂起**（宿主/端点域，EV-088 披露）：227s/0token 挂起属上游端点现象，vision 旁路（glm 等可用服务商）可用——本仓不可修，不构成本版回滚触发条件。
- **picked 层盲区**（宿主固有 P3）：selectModel 进程内选择不落 header/options 且插件无访问 API——selectModel 后首轮 prestep 与宿主判定可能短暂不一致，属宿主设计固有窗口（注释披露在案）。

### 版本说明

- **版本号**：0.3.1 → **v0.3.2**（PATCH）——零新能力语义（两处缺陷修复 + 一 UX 调整 + 收口），零 breaking（见「破坏性变更」四证）；MINOR 反论否弃：semver MINOR = 向后兼容的**新增功能**，本版无新增功能面（入口移除为清理**从未可用**的误导性入口，删除按钮双入口属缺陷补全而非新能力）；v0.2.1 PATCH 先例。
- **发布范围**：v0.3.1（tag 5ca8b87，2026-08-30）以来 main 全部提交 **14 个**（`git rev-list --count origin/main..HEAD` 实采 2026-08-30）。三分账：**产品提交 5 个**——FIX-009 `8877365`（wrapper 占位注入）/ FIX-010 `020909b`（prestep 判定 header 优先）/ EVO-007 `65226a3`（账号面板 UX：入口移除 + 布局）/ EVO-007 R0 返工 `3665d6a`（F-1 删除路径恢复 + F-2 文案）/ REL-005 收尾 `1d2bf36`（P1-1 live default 对齐 + P2-2 hygiene + README 收口）；**治理提交 9 个**——`d92dfba` / `ec94a6c` / `49ac8ab` / `0234a88` / `0c7f987` / `b664f52` / `ed229db` / `6877389` / `18d5cf1`。**结论行：5 + 9 = 14，与实采一致**；产品提交经逐 commit 对照在本节语义全覆盖，治理提交不入用户面。口径注记：`v0.3.1..HEAD` 计数 15 差 1——`4ee80e9`（REL-004 E-8 治理收尾）归属 v0.3.1 发布链（tag 后 origin/main 侧补录），不在本版 14 个内。
- **验证基线**（EV-090 Coordinator 实测 + 收尾段申报一致）：`tests/smoke.mjs` **963 ok / 1 skip / 0 FAIL / exit 0**；`tests/fix-009-image-solo.mjs` 9/9、`tests/fix-010-gui-fidelity.mjs` 13/13（含 REL-005 P1-1 漂移窗口判别 E 组）、`tests/routing-paths.mjs` 114/114、`tests/adapter-parity.mjs` 14/14、`tests/metrics.mjs` ALL PASSED、`tests/client-render.mjs` 130 断言。内部注解：发布执行段 E-2 全量门控复跑与 tarball 隔离环境安装冒烟（环境变量重定向至临时目录）随发布链执行，最终以复跑实测值为准。

## v0.3.1 — 2026-08-30

### 摘要

**转正版本**——**GPT OAuth 实验通道转正式**（DEC-026 C2）。核心变化一句话：**ChatGPT 订阅登录即正式通道——无实验开关、无实验弹窗、无实验标签（界面中英同步），登录即可用；关闭能力三层保留**。

### 新增

- **停用账号发起授权的拒绝遥测（可观测性，REL-004）**：已停用账号（`enabled=false`）发起 ChatGPT 授权登录时，拒绝动作记录原因 `account_disabled`（停用拒绝留痕；正常登录路径零事件）——停用语义可观测、可追溯。

### 变更

- **ChatGPT 订阅登录转正式通道（EVO-006，DEC-026 C2）**：「ChatGPT（实验）」入口转为正式登录通道——无需再开启任何开关，设置 → Agent 路由 → 多模态账号中直接一键登录；v0.3.0 已登录的账号升级后不受影响（凭据保留、继续可用）。
  - **实验开关与条款确认移除**：`router.oauthExperimental` / `router.oauthTosAccepted` 配置键废弃——升级零操作（旧配置中的遗留键自动忽略）；设置页不再有实验开关与条款确认弹窗。
  - **升级披露（「开过又关」用户请留意）**：v0.3.0 时期曾开启实验开关创建账号、后又手动关闭 `router.oauthExperimental` 的用户——该「关闭」偏好不随升级迁移（实验门控已随转正移除，此偏好无账号级停用对应物），升级后 ChatGPT 通道对您恢复可用；暂不使用可在账号卡片**停用账号**（`enabled=false`）或「登出并删除凭据」。
  - **风险提示保留（非阻断、非实验声明）**：界面保留平台服务条款与账号风控方面的常规风险提示。
  - **关闭能力不变**：总开关 `router.enabled`、单账号停用（`enabled`，调用与发起授权均被拦截并明确提示）、「登出并删除凭据」（恒可用，不受任何开关门控）三层路径全部保留。
  - 内部注解：DEC-026 用户裁决（「先仅将gpt实验通道转成正式的Oauth登陆逻辑，当前的验证证明OAuth登陆可行，其他的等后续的我的需求」——仅 GPT 通道，Claude/账号池方向不做）；判别测试 tests/oauth-promotion.mjs（旧实验语义必败断言 + 关闭能力保留断言）；kill-switch 转正后为三层新语义（① 通道开关 / ② 账号开关——调用与发起授权双侧判别为本版补全 / ③ 登出删除恒可用）。

### 破坏性变更

**无。**论证（四证）：① 无公共 API/协议面变更，**依赖面零变更**——除版本号外 package.json 与 v0.3.0 完全一致（undici ^7.18.0 / peerDependencies 8×^0.1.0-rc.8 维持）；② 配置键废弃带容忍迁移——schemastery 非 strict 未知字段透传，旧配置中的 `oauthExperimental`/`oauthTosAccepted` 遗留键零启动阻塞、零行为改变，升级零操作；③ 行为变化均有披露与官方替代路径——「开过又关」cohort 见「变更」节升级披露（替代路径：账号卡停用或登出删除），v0.3.0 已登录账号升级后凭据保留、继续可用；④ 关闭能力三层全保留且不弱于 v0.3.0（实验 flag 层退役属转正裁决内的语义消亡，非破坏）。

### 已知问题

- **本项目暂无持续集成（CI）自动化**（v0.3.0 披露延续）：回归保护依赖发布前本地全量测试网（十面全绿复跑，见「版本说明·验证基线」）。CI 建设已列入后续排期。
- **部分宿主下对话内图片附件可能显示「加载失败」**（v0.3.0 已知问题延续，跟踪至后续版本）：附件识别功能已验通，服务端附件链已修复并验证 7 格式全绿；显示层残留属客户端渲染路径，后续版本专项修复（FIX-008 候选域）——本版不承载修复。

### 版本说明

- **版本号**：0.3.0 → **v0.3.1**（MINOR）——转正为用户可见能力语义变化（缺省即正式通道 + 配置面废弃 + 升级行为披露），非缺陷修正，不判 PATCH；零 breaking（见「破坏性变更」四证）；0.x 阶段 MINOR 承载新能力语义（先例 v0.2.0）。
- **发布范围**：v0.3.0（tag bb81abf，2026-08-29）以来 main 全部提交 **12 个**（`git rev-list --count bb81abf..HEAD` 实采 2026-08-30）。三分账：**产品提交 7 个**——EVO-006 转正 ×3（bf667b3 服务端语义 / 6ebe9ed 客户端 UI / a4d33cd 文档口径）+ REL-004 收尾 ×4（6cbe4fc 停用拒绝遥测 / f2f3ba5 「开过又关」升级披露 / 21db990 feature-flags ②层新语义注记 / 866d4df 测试注释归属修正）；**治理提交 5 个**——b2a1f66 v0.3.0 发布链收尾入账 / a6acd06 EVO-006 入账收尾（DEC-026 裁决）/ 0eb1324 EVO-006 治理收尾 / 820d862 REL-004 收尾段治理 / a9651ad REL-004 规划段三产物入仓。**结论行：7 + 5 = 12，与实采一致；产品提交经逐 commit 对照在本节语义全覆盖，治理提交不入用户面。**
- **验证基线**（EV-086 十面，2026-08-30 M-3 无沙箱复跑权威）：`tests/smoke.mjs` **948 ok / 0 FAIL / exit 0**；九套件零回退——`tests/stats.mjs` 110、`tests/routing-paths.mjs` 114/114、`tests/adapter-parity.mjs` 14/14、`tests/attachments.mjs` 65/65、`tests/oauth-credentials.mjs` 98、`tests/oauth-loopback.mjs` 20、`tests/client-render.mjs` exit 0、`tests/oauth-promotion.mjs` 13/13、`tests/metrics.mjs` ALL PASSED。内部注解：发布执行段 bump 后全量门控复跑与 tarball 隔离环境安装冒烟（环境变量重定向至临时目录）随发布链执行，最终以复跑实测值为准。

## v0.3.0 — 2026-08-28（发布候选——正式日期以 v0.3.0 tag 为准）

### 摘要

**双主题版本**——**C-1 ChatGPT 订阅接入 + C-3 统计持久化**（DEC-025 D-1a）。核心变化一句话：**ChatGPT 订阅账号可以一键登录接入路由（实验开关，默认关闭），用量统计缺省落盘、重启不再清零**。

### 新增

- **ChatGPT 订阅一键登录（实验，C-1）**：设置 → Agent 路由 → 多模态账号 →「ChatGPT（实验）」一键登录——浏览器完成 OAuth 授权后凭据自动落盘（独立文件、仅当前用户可读），账号卡可直接选用订阅模型对话（含带图）。
  - **授权通道双路径**：优先本地回调（1455 端口，秒级完成）；端口被占用时（如 Codex CLI 等生态工具在监听）**自动降级设备码通道**——展示授权链接，在任意浏览器完成授权，插件后台轮询兑换（15 分钟有效窗口；瞬时网络错误自动退避重试，不会因单次抖动失败）。*兑现 v0.2.1「完整功能（协议分支/UI/设备码）将在 v0.3.0 发布」预告。*
  - **使用前提**：需在设置中显式开启 `router.oauthExperimental`（**默认关闭**）；首次开启需确认风险声明（实验条款，自担风险）；chatgpt.com 通常需代理可达（`oauthProxyUrl` 可配，授权端点直连）。
  - **登出即删除**：账号卡「登出并删除凭据」——删除凭据文件 + 清除账号条目 + 清除账号池引用，三处联动不留残留（含登录过程中登出的竞态保护）。
  - 内部注解：preset 账号 + codex-responses 协议分支 + per-protocol 能力接口（image/speech 留桩）；C-9 观测埋点自本版起采集（报告将于 v0.3.2 出——本版不含任何成功率结论）。
- **统计持久化（C-3）**：
  - **按天落盘**：用量统计按天写入 DSH 插件数据目录（`$DSH_HOME`）的 JSONL 文件，**重启后统计保留**（此前为内存态、重启清零）；默认保留 90 天。
  - **按天视图**：统计面板新增按天聚合视图（每日调用/失败/tokens）。
  - **CSV 导出**：统计面板新增导出按钮——可选时间范围与粒度（全局/Agent/账号级），导出 CSV（含公式注入防护）。
  - **数据安全**：原子写入、损坏自愈、版本迁移、清空保护（一键清空走软删除备份，误清可恢复）。
  - **成本单价表**：可为模型配置单价用于成本估算。
- **`router.oauthExperimental` 配置开关**（默认 false）：ChatGPT 实验通路总开关（合规三层开关的第③层；见「变更」节统计开关与 README）。

### 变更

- **【数据行为变化——请留意】统计缺省落盘**：升级到 v0.3.0 后，用量统计**默认写入磁盘**（位置：`$DSH_HOME` 插件数据目录；按天 JSONL；默认保留 90 天）——此前版本统计仅存内存、重启即清零。**不希望落盘的用户**：设置中关闭 `router.stats.persist`（false = 回到纯内存行为，此前已落盘的数据不受影响，重新开启后自动全量恢复）。
- **宿主依赖声明提升**：peerDependencies 8 个 dsh-* 包 `^0.1.0-rc.6 → ^0.1.0-rc.8`（对齐实测宿主版本）。**仍在 rc.6 宿主环境的用户升级后可能收到 peer 依赖警告/安装拒配**——请先升级 DSH 宿主再安装本版。
- 统计逻辑从 service.js 分离为独立模块 lib/stats.js（架构内聚，行为等价）。

### 修复

- **多模态路由失效、附件链断裂与会话图片消失（P0 热修，FIX-003 + FIX-003C）**：DSH 宿主静默更新（npx 缓存刷新）后，能力探测与附件注册接口行为回归——视觉 agent 收不到图片（`includeImages` 未达 / `attachmentIds` 报「未注册且宿主无法读取」/ 文件被「模型不支持图片输入」拒绝），会话气泡中的图片消失。修复：能力预检改按真实宿主提供方清单判定 + 附件懒注册自取证降级（自动探测图片尺寸、内容哈希兜底）+ 设置侧模型能力声明补全（宿主 GUI 写回配置会覆盖内置能力声明的陷阱）；经用户真机验证恢复。附件根目录回退与 WebP 尺寸探测边界两处遗留随本族并入（b6581c5 / 0782516）。
- **OAuth 代理路径在发布环境必失败（P0，FIX-006）**：运行时代理依赖 undici 此前未声明——发布安装后配置代理的 ChatGPT 调用必然报「Cannot find package」。修复：显式声明 `undici ^7.18.0` + 代理 dispatcher 主版本判别（版本不匹配立即明确报错，不静默错行为）+ pnpm-lock 入仓 + 适配器契约对齐宿主 rc.8。
- **接管开关的会话记忆缺陷（FIX-002 发布后返工）**：v0.2.1 的 `takeoverDefaultModel` 修复在客户端会话层缺少与服务器端对等的记忆机制——开启接管后切换会话（含起子代理）场景，用户手动改回的模型可能不被记住；补齐对等记忆三态 + 护栏与不变量断言（72b2670 / 0b3c15d）。
- **设备码登录两处可靠性修复（REL-003）**：① 登出×授权兑换竞态——登录进行中登出后凭据不再「复活」落盘（persist 前复查 + 竞态判别测试）；② 瞬时传输错误不再终止设备码流程——单次网络抖动改为退避重试（窗口内有界），并以独立错误原因区分「传输错误」与「授权被拒」。
- **能力自证与预检可观测（FIX-004）**：宿主 GUI 写回模型配置丢失能力声明时，插件以适配器实测能力自证兜底；预检拒绝不再静默（6dd6e5b）。
- **路由引导条件化（FIX-005）**：`route_agent` 引导提示按主模型能力分级——主模型原生支持图片输入时不再注入冗余路由引导，工具描述同步中性化（a484469）。
- **附件链在宿主演进后回归（P0，FIX-007）**：宿主 dsh-attachment 更新至 `0.1.1-rc.2`（npx 缓存静默刷新）后，已注册附件的懒注册读取以裸 id 调用宿主 `readImage`——新宿主的元数据全等校验（mediaType/字节数/尺寸必须与 ref 一致）恒拒（`ATTACHMENT_CORRUPT`）；WebP 尺寸探测存在字节偏移（VP8 有损将块尺寸当帧标签、VP8L 位拼装不完整）导致 `attachmentIds` 链全断——表现为对话内图片附件「加载失败」与部分情形下整体变慢（端点重试链放大）。修复：完整 ref 读取单点（条目元数据 → 权威 ref → 宿主读取 → 自取证降级回填）+ WebP 三分支尺寸探测器按规范重写（RFC 6386）+ 元数据补全 + 降级可观测事件（`attachment_ref_degraded`）；判别测试先红后绿 + 真实宿主隔离验证 7 格式（PNG/EXIF-JPEG/大图/VP8/VP8L/VP8X/GIF）全绿（b816601 / 08accbd）。

### 破坏性变更

**无。**论证：① 既有 OAuth 通用账号（粘贴 token）与 API Key 账号行为不变；② ChatGPT 实验通路全程由 `oauthExperimental`（默认 false）门控——不开启零可见；③ undici 为 dependencies 追加（非 peer 收窄）；④ 统计落盘虽为可感知的数据行为变化，但带等价回退开关（`stats.persist=false`）且不破坏既有数据。

### 已知问题

- **本项目暂无持续集成（CI）自动化**：回归保护依赖发布前本地全量测试网（六套件全绿复跑，见「验证基线」）。CI 建设已列入后续排期。
- **设备码授权失败时界面反馈较弱**：15 分钟窗口内若授权失败（拒绝/过期），账号卡状态变化不明显——可关闭后重试，或改用「粘贴 token」方式添加账号（后续版本将增强失败状态展示）。
- **部分宿主下对话内图片附件可能显示「加载失败」**（已知残留，跟踪至后续版本）：附件识别功能已验通（识别文本正常返回），但部分宿主/部分路径下对话内图片附件渲染可能显示「图片加载失败，点击重试」（客户端 imageData 译码面拒绝）——服务端附件链已修复并验证 7 格式全绿，显示层残留属客户端渲染路径，后续版本专项修复（见 FIX-008 候选域）。
- **统计历史规模性能未经实机标定**：100 天以上数据量的加载性能（目标 ≤200ms）为观察项，非已达标声明。
- **新装依赖解析时变**：npm 安装包不含锁文件，新安装将解析 undici 7.x 最新版（可能与开发验证版本存在 minor/patch 差异）；主版本不一致时会明确报错而非静默异常。
- **宿主 npm 环境缺陷（正交披露）**：npm 11.8.0 的依赖树解析对 dsh-* 环形 peer 关系存在缺陷（children null）——属宿主环境问题，非本插件缺陷；安装验证以 `--legacy-peer-deps` 绕行。

### 版本说明

- **版本号**：0.2.1 → **v0.3.0**（MINOR）——双主题均为向后兼容新能力面，无破坏性变更（见上）；0.x 阶段 MINOR 承载新功能（先例 v0.1.7→v0.2.0）。范围变更留痕：C-3 统计持久化原排 v0.3.1，因已在 main 完成随本版如实并入（DEC-025 D-1a）；设备码通道为兑现 v0.2.1 预告补实现（DEC-025 D-2a）。
- **发布范围**：v0.2.1（tag a1ab717，2026-08-22）以来 main 全部提交 **86 个**（`git rev-list --count a1ab717..HEAD` 实采；三分账清单基线 `.governance/gate7-commits-v030.txt` 81 行 + 后续 5 commits：a066de3 REL-003 资产入仓（治理）+ FIX-007 族 ×4——efec43f 受理（治理）/ b816601 修复（产品）/ 08accbd P8 增补（产品）/ 5cf524d 终态入账（治理））。三分账：**产品提交 36 个（SHA 底账全量，按任务族）**——EVO-002 Step 5-7 ×6（db1ddf7 / 5f5a38b / 522025e / f9d8bf0 / cbfafcf / 3e95034）+ EVO-003 ×2（1199c0b / c2d01ea）+ EVO-004 ×7（31a8c74 / 4d08990 / a9f98b2 / 9fd6110 / dd5d310 / d8ee97c / 8938a54）+ EVO-005 设备码 ×3（6355eb7 / 65e7e34 / d49ed4c）+ REL-003 ×5（dcd44fa / 6dbe57d / fbdfc61 / d78dc00 / 850b30c）+ FIX-002 发布后返工 ×2（72b2670 / 0b3c15d）+ FIX-003 ×1（b6581c5）+ FIX-003C ×1（0782516）+ FIX-004 ×1（6dd6e5b）+ FIX-005 ×1（a484469）+ FIX-006 ×4（bef08eb / 6a7ba76 / 669679e / 69ccf94）+ **FIX-007 ×2（b816601 / 08accbd）** + DEV-002 测试基建 ×1（3e0e2b5——核心通路回归套件，见「验证基线」routing-paths）；**治理提交 50 个（按类计数汇总，不承载用户可见变更）**——GOV-002 会话治理/证据入账 ×37 + GOV-003 治理记录入仓 ×1 + GOV-004 工作流升级 ×1 + REL-001 发布收尾 ×3 + REL-002 规划与 M-0 裁决入账 ×2 + REL-003 资产入仓 ×1 + 任务审查/终态闭环入账 ×3（FIX-006 ×2、EVO-005 ×1）+ FIX-007 受理/终态 ×2。**结论行：36 + 50 = 86，与实采一致；产品提交经逐 commit 对照在本节（新增/变更/修复）语义全覆盖，治理提交不入用户面。**
- **验证基线**（EV-078 六套件复跑全绿 + Coordinator 三次运行时实测；**FIX-007 后以 934 为权威**）：`tests/smoke.mjs` **934 ok + 1 skip / 0 FAIL**（账目链 873→908→918（REL-003 时点）→ 932（FIX-007 b816601 +14）→ 934（08accbd +2）——运行时实测为权威，静态预估仅供交叉参考）；`tests/oauth-credentials.mjs` 98；`tests/stats.mjs` 110 / 0；`tests/routing-paths.mjs` 114 / 114；`tests/client-render.mjs` 全绿；`tests/adapter-parity.mjs` 14 / 14（宿主 rc.8 对齐）；`tests/attachments.mjs` 65 / 65（含 FIX-007 判别断言族，真实宿主 rc.2 隔离验证 7 格式全绿——EV-082）。tarball 隔离环境安装冒烟（环境变量重定向至临时目录）已通过（EV-078：undici 7.29.0、ProxyAgent 可构造、真实 ~/.dsh 零触碰）。

## v0.2.1 — 2026-08-22

### 摘要

**P0 热修版本**——承载 2026-08-22 两个生产故障修复与一个行为修正。核心变化一句话：**多模态"接管"从默认强制改为默认关闭（用户主权），并修复宿主 dsh-llm 更新导致的多模态消息全量失败**。

### 修复

- **多模态消息全量失败（宿主接口演进兼容，FIX-001）**
  - 症状：宿主 dsh-llm 更新（0.1.1-rc.2，npx cache 静默刷新）后，所有多模态消息报 `registration.adapter.prepareCall is not a function`。
  - 根因：新宿主每次分发先调 `adapter.prepareCall`（prepared-dispatch 契约）；本插件 twin 包装适配器为手工对象字面量（无基类继承），缺该方法即全量断裂。
  - 修复：twin 显式实现 `prepareCall` 并绑定 twin 自身方法（prepared 分发不得绕过 twin 的改写/直传逻辑）；6 处测试夹具同步修复；新增**适配器接口奇偶回归测试**（动态枚举宿主基类方法——宿主未来新增方法而插件未跟进时测试即红，RISK-003 看护网）（commit f1c4c91；R6 审查 + FIX-001b 返工 cba0d98）。
- **模型选择被强制覆盖（双层接管行为修正，FIX-002/FIX-002b）**
  - 症状：① 切换会话（含起子代理）后，用户手动选回的模型被强制切回多模态包装路由；② 纯文本消息也被强制经包装路由（中间层故障被放大为全量故障）。
  - 根因：两个独立的接管面均无开关且无用户主权保护——服务端默认模型接管（三个同步触发点无条件执行）+ 客户端会话级接管（effect 依赖 sessionId，起子代理即触发强制切换）。
  - 修复：新增 `router.takeoverDefaultModel` 配置（**默认 false**）统一约束两层——关闭时包装路由仅出现在模型列表（用户手动选用），默认模型与会话选择永不被触碰；显式开启后为一次性接管（记住来源，用户改回即尊重）；关闭开关/禁用插件时恢复原 provider；旧版本遗留的强制接管选择在首次同步时自动还原（commit d264f03 + 5c8f2dc；DEC-022 用户裁决）。

### 新增

- **`router.takeoverDefaultModel` 配置开关**（默认 false）：多模态自动接管的可选开关（见上）；schema 字段 + catalog 镜像（客户端可见）。

### 变更

- **ChatGPT 订阅 OAuth 服务层就位（不可见预置，EVO-002 Step 1-4b 部分）**：凭据模块（原子写/文件锁/自动刷新）、1455 惰性回调服务、授权流 preset 分支已进入 main——全部由 `router.oauthExperimental`（默认 false）与默认关闭保护，**用户零可见**；完整功能（协议分支/UI/设备码）将在 v0.3.0 发布。

### 已知问题

- 接管关闭（默认）时，多模态能力需要用户在模型列表手动选 `xxx + 多模态` 组，或在设置中显式开启 `takeoverDefaultModel`（换来零操作体验，代价是自动切组）。
- EVO-002 Step 5+（codex-responses 协议分支/客户端 UI/设备码）未包含在本版本——`oauthExperimental` 保持关闭即无影响。

### 版本说明

- **版本号**：缺陷修正 + 向后兼容的新配置开关（默认值不改变合规行为，改变的是缺陷行为本身）→ patch 级 **v0.2.1**。
- **发布范围**：v0.2.0（2026-08-20 tag）以来 main 全部提交——EVO-002 Step 1-4b（11c42c0 / 8ba6ab18 / 128cb810 / a2567db / 564e18c，OAuth 地基，kill-switch 默认关闭）+ FIX-001/001b（f1c4c91 / cba0d98）+ FIX-002/002b（d264f03 / 5c8f2dc）。
- **验证基线**：`node tests/smoke.mjs` 656 断言全绿；`tests/adapter-parity.mjs` 14 断言（首次真实运行，R6-F1 修复后）；oauth-credentials 75 / oauth-loopback 20；R6 独立审查链闭环（APPROVED_WITH_NOTES + 绑定条件全落地）。

## v0.2.0 — 2026-08-20

### 摘要

本版本是 **v3 架构迁移（MIG-001）的收官发布**。核心变化一句话：**带图轮从"自动切换到视觉模型"改为"主 agent 轮次 + 工具调用"**——主 agent 始终是唯一参与者，图片按主模型能力分级处理（原生直传 / 改写提示），并可跨轮指代、上传任意文件、统一寻址、三级展示。原定 v0.1.8 的范围（whole-turn 图片路由默认化）已被本次架构演进整体超越，故直接发布为 **v0.2.0**（见「版本说明」）。

### 破坏性变更

- **带图轮不再自动切换视觉模型（整轮路由移除）**
  - 此前（≤v0.1.7）：消息带图时，整轮请求会被静默切换到视觉模型处理（主 agent 的上下文与工具也随之一并切换）。
  - 现在：带图轮始终由主 agent 应答（请求恒为主模型），主 agent 按需调用 `route_agent` 工具把图片交给视觉专业 agent（专业 agent 以独立调用/子会话执行，只返回文本结果）。
  - **迁移指引**：升级无需额外操作。若你的主模型**没有**图片输入能力，插件会改写图片块并向主 agent 注入提示（reminder / 标记 / 记忆段），请确认已配置至少一个视觉类专业 agent（能力标签含 `image`），主 agent 才能委派识别；若主模型**有**图片输入能力，图片会保真直传（见「新增」）。图片识别结果仍照常到达。
  - 内部注解：`lib/tool.js:199-232` 整轮路由注册与 `[用户附带图片]` 死规则移除（EV-011，Step 1，commit 7cb2024；DEC-008 / ADR-001）。
- **"用户消息带路径清单"注入规则移除**
  - 此前插件注入的路径清单声明与真实机制（原生草稿轨）矛盾，可能误导主 agent 判断"无图"；现移除，改为与真实附件通道一致的提示文本（EV-012，Step 2，commit b7261d5）。

### 新增

- **图片按主模型能力分级（preserveImageInput）**：主模型支持图片输入 → 图片块**保真直传**（零改写）；不支持 → 当前轮图片改写为标记 + 行为提示，历史轮改写为记忆段；能力查询失败安全回落改写，不静默丢图（EV-013，Step 3，commit a23b338；DEC-010 / ADR-003）。
- **imageMemory 跨轮指代**：图片轮识别结果自动回写记忆；后续文本轮追问（如"刚才图里 X 是什么"）时，历史图以记忆段（描述 + 附件 id）注入主模型——无需重传图片、无需重新描述（EV-014，Step 4，commit 374edfa；DEC-012 D-5）。
- **附件统一寻址 + `attachmentIds` 参数**：附件 id ↔ 工作区路径 ↔ `files` 参数三向映射统一管理；`route_agent` 新增 `attachmentIds` 参数，可跨轮精确引用历史附件（如"再看一眼那张图"）（EV-015/EV-016，Step 5a/5b，commit f89b8bd/f294c3c；DEC-011 / ADR-004；D-1-4 编址往返 100% 自动化验证——EV-023）。
- **任意文件上传（音频 / 视频 / 文档）**：对话框附件按钮扩展——此前仅支持图片，现在音频、视频、文档可直接上传，落盘工作区 `.router-files/`，以附件卡片 + 结构化路径文本进入消息，主 agent 可见可引用（EV-021，Step 8，commit e88dfb2；DEC-007 交互全景）。
- **工具产物三级展示**：L1 原生图片块（会话日志）/ L2 缩略图画廊（工具卡片）/ L3 路径文本 +「打开文件」——音频/视频内联播放、其他文件下载（EV-022，Step 9，commit 0554c5d）。
- **带图轮行为提示（reminder）+ 逃生组兜底**：带图轮注入带附件 id 的行为指令（主 agent 明确知道可调 `route_agent`）；用户手动切回原组 / 未接管等逃生场景下，图片轮不再以裸图片击穿端点（EV-019，Step 6，commit 1f17ea8）。
- **模态能力矩阵**：agent 目录按模态方向（image / audio / video / text / file，消费与产出）可观测、可检索；为音频/视频能力扩展留位（EV-020，Step 7，commit 12a8c71）。
- **文件通道 RPC**：`uploadFile` / `readWorkspaceFile` 通道契约就位——任意文件上传与工作区文件读取的基础设施（EV-018，Step 5c，commit 2c4b194）。
- **成功标准观测脚本**：`tests/metrics.mjs`——D-1 五指标 31 项自动化观测 + 门判定汇总（开发者可见；EV-023，Step 10，commit 53c0e40）。

### 变更

- **模型接管语义收窄**：接管从"静默模型替换"变为"准入放行 + 能力感知改写"——包装路由（twin）上运行的始终是主模型，不再发生模型替换（EV-013；DEC-009 / ADR-002）。
- **能力标签枚举化**：capabilities 从自由字符串改为枚举（image / audio / video / text / file）+ 消费/产出方向语义；未知值兼容放行（仅警告），老配置零破坏（EV-020；DEC-012 W-5 双轨兼容）。
- **`route_agent` 工具描述与真实机制对齐**：删除过时的路径清单声明，描述指向真实附件通道（EV-012，Step 2）。
- **附件寻址收敛**：图片注入 / CLI 物化 / 附件选择三处调用点统一经附件注册表寻址，消除路径与附件 id 双轨各自为政（EV-016，Step 5b）。

### 修复

- **图片注入失效（用户报告问题②）**：历史图跳过标记导致后续文本轮对图片一无所知（LP-1）→ 由 imageMemory 记忆段修复；"[用户附带图片] 死规则"误导主 agent 判"无图"（LP-3）→ 移除；空 provider 解析致图片二次剥离（LP-2）机制链 → 随整轮路由移除而消除（EV-011/EV-012；RES-001 问题②闭环）。
- **附件寻址三处分散收敛**：从"路径与附件 id 双轨、映射散落"收敛到统一注册表（EV-015/EV-016）。
- **工作区文件读取符号链接逃逸漏洞**：`readWorkspaceFile` 增加真实路径二次包含校验（fail-closed）——词法校验通过但 realpath 指向工作区外的符号链接/联接不再可读（EV-022，Step 9 返工，R12→R13）。
- **同名文件不再静默覆盖**：上传落盘采用排他写入 + 碰撞去重后缀，保持内容寻址完整性（EV-021，Step 8 返工，R10→R11）。

### 已知问题

- **端到端指标待实测**：图片到达真实视觉模型（D-1-2）、`route_agent` 带图触发率（D-1-3）、跨轮指代成功率（D-1-5）——机制面已全部就位并有自动化观测，真实比率需真实使用统计（U-3）后评估。当前门判定：**满足×2**（恒主模型 / 编址往返，自动化 100%）+ **部分满足×2**（图片到达 / 跨轮指代，机制面 100%）+ **待实测×1**（触发率）（EV-023；DEC-015）。
- **P3 记录项**：个别容器格式（如 m4a / mkv）在展示层可能类型误判（魔数检测 + 扩展名兜底的固有限制，EV-022 R12 F-4~F-10）；测试卫生遗留项（metrics.mjs 物化落盘残留、UTF-16 码元截断边界）已转后续任务域（EV-023 R14-F-01；EV-014 R4 F-2）。
- **统计为内存态**：用量统计随 DSH 重启清零（既有行为，与 v0.1.7 一致）。

### 版本说明

- **v0.1.8 跳号**：v0.1.8 原定范围（whole-turn 图片路由默认化，commit c2648d2 / 963b4f5）在开发中被 v3 架构演进整体超越；本次包含行为变更（见「破坏性变更」）与大量新能力，按语义化版本属 **MINOR 级**而非 patch 级，故直接发布 **v0.2.0**（DEC-015，用户 2026-08-20 确认）。
- **发布范围**：v0.1.7（2026-08-17 tag）以来 main 全部提交——治理接入（04f1e67，含锁文件 untrack 7c66e50）、v3 迁移 Step 1-10（7cb2024 / b7261d5 / a23b338 / 374edfa / f89b8bd / f294c3c / 98f04a3 / 2c4b194 / 1f17ea8 / 12a8c71 / e88dfb2 / 0554c5d / 53c0e40，含快照 9f485d9）、v0.1.8 原定范围（c2648d2 / 963b4f5）。
- **验证基线**：`node tests/smoke.mjs` 534 断言全绿（含附件注册表 49 断言）；`node tests/metrics.mjs` 31 项观测全过；MIG-001 全 13 单元 R1-R14 独立审查链闭环（含两次 NEEDS_CHANGE → 返工 → 复审）。
