# 隔离冷装装载门取证程序（cold-install gate）

> ARCH-005 A1 批固化（2026-10-17）。程序本体 = `scripts/cold-install-gate.mjs`。
> R1 批手工验证的「隔离冷装装载门判据」自本批起以**同一可复用程序**承载——
> R2（面板取证）/ A3（端到端）/ R5（复验清单）引用同一实现路径（P5：同一动作
> 多触发来源汇入同一实现路径，禁止手工重演另立路径）。

## 1. 判据（什么算绿 / 什么算红）

在 $TEMP 沙箱（DSH_HOME 重定向）内对仓库做**冷装**（`dsh plugin --profile <name> add <repo>`，
link: 形态——manifest 实时读自仓库树），再以 headless `--dump-config` 启动**同一宿主运行时**
（npm 全局树 dsh，本机 PATH 实读 `0.2.1-rc.2`；桌面宿主实测主基线 `0.2.2-rc.1`——两者均在
声明面逐代并集内），断言宿主 app-boot 装载门对 `dsh-agent-router` 放行。

| 面 | 绿（放行） | 红（拒载） |
|---|---|---|
| 启动 stderr | 无任何装载门标记 | 含 `dsh: skipping profile bundle "dsh-agent-router"`（reportSkippedBundles 前缀，dsh-app-boot `lib/index.js:516` 形态）+ `is incompatible with dsh` / `Running it may cause crashes or data loss`（pluginCompatibilityWarning 模板，`:320-322`；catch 进 skippedBundles 形态 = `:940-945`） |
| dump-config stdout | `# == dsh-agent-router` 段在场（bundle 被组合进 profile 树） | 该段消失（bundle 整层拒载，R1 沙箱证据实证：绿 3 次在场 / 红 0 次） |

**判据边界（如实声明）**：本判据只覆盖**装载门放行**（`evaluatePluginCompatibility`
不再拒载）。apply 期断点（HD-002 settings 声明制 / HD-003 codec create()——服务端
register 路径）不在断言面，其收口分别由 A2/A3 批验收门承载；A3 的「服务端 apply 全程
无 throw」是更靠后的完整判据点。

## 2. 用法

```bash
node scripts/cold-install-gate.mjs                # 绿判据：冷装 + 启动 + 断言放行（= R1-③ 判据的程序化复跑）
node scripts/cold-install-gate.mjs --expect-skip  # 红演示（判别力自证）：
                                                  #   boot1 绿 → 临时回退一项 peerDep → boot2 红 + 摘录警告
                                                  #   → 字节精确恢复 → boot3 复跑绿
```

可选参数：`--repo <path>`（默认本仓库）/ `--profile <name>`（默认 `sandbox`，R1 证据同名）/
`--revert-pkg <pkg>`（默认 `@deepseek-ai/dsh-settings`）/ `--revert-range <range>`
（默认 `^0.1.5-rc.2`）/ `--dsh <command>`（默认走 PATH）。

前置：PATH 上有 `dsh`（本机实读 `0.2.1-rc.2`，属声明并集中段；桌面主基线 `0.2.2-rc.1`
为另一段，两代均由并集准入）与 pnpm（宿主 plugin-manager 拉起安装用）。
缺 dsh / 冷装失败 / profile 未生成 / 启动超时 → 明确错误 + exit 1（P8 可观测，不静默）。

**输出与留证**：结构化结论（`COLD-INSTALL-GATE-RESULT {…}` JSON 行 + exit
0/1）+ 逐条命令上报表（R4 纪律：命令、退出码、影响路径）+ 沙箱证据文件
（`install-log.txt` / `bootN-stdout.txt` / `bootN-stderr.txt` / `repo-pkg-bak.json` /
`commands.jsonl` / `result.json`），目录路径随结论行打印，供报告引用。沙箱保留不删
（取证件；$TEMP 由系统清理策略回收）。

## 3. 隔离与真实环境防护（破坏性红线配套）

- **DSH_HOME 重定向至 $TEMP 唯一沙箱目录**（每次运行新建）——dsh 的 profile / 状态
  写入只落沙箱；对用户 HOME 下配置目录零删除 / 零清空 / 零重建 / 零移动。实证：
  A1 固化首跑期间 `~/.dsh` mtime 保持 2026-10-16 23:12:11 不变（R1 批同一时点值）。
- **仓库写操作仅存在于 `--expect-skip` 红演示**：package.json 临时回退 → 恢复。
  恢复 = 内存原文写回 + 复读字节核对 + 沙箱内 `repo-pkg-bak.json` 磁盘双保险；
  核对失败即 FATAL 报错并给出恢复命令（cp 备份 / `git checkout -- package.json`），
  绝不静默。
- pnpm 由宿主 plugin-manager 拉起，其用户级 content-addressable store 为**追加式缓存**
  写入（非配置目录写入），如实登记。
- 回退目标串（`"<pkg>": "<range>"`）在 package.json 中命中数必须恰为 1，否则拒绝
  盲替换（P8）。

## 4. 在升级 SOP 中的位置（谁引用本程序）

| SOP 步骤 / 批 | 引用方式 |
|---|---|
| **R1-③ 判据的复验**（本批 A1 验收门 ①） | 绿路径 = 同一判据的程序化复跑，禁止手工重演 |
| **A3 端到端验收**（HD-002 收口后） | 「服务端 apply 全程无 throw」的**前置半边**：装载门判据同 A1 口径以本程序复验（A3 验收门 ① 明文「装载门判据同 A1 口径复验」） |
| **R2 面板取证**（协商三态徽章） | 发布前面板取证的双层口径之**本机隔离冷装臂**：沙箱冷装环境内启动真实宿主渲染面板取证（截图/录屏），装载门放行由本程序同一冷装口径保证 |
| **R5 复验清单**（「重装后真机复验」节） | 发布前隔离臂的机器凭据由本程序产出；真机复验（后置）按同一判据面人工核对（stderr 无 skip 警告 + 功能在位），判据文本以本文件 §1 为准 |

新宿主基线登记（SOP 第 4 步）后，本程序无需改动——判据锚定的是宿主装载门的
**行为形态**（警告文案标记 + dump-config 组合结果），不锚定具体版本号。

## 5. HD-001 声明面收口：三方一致核对凭据（既有断言引用）

HD-001 收口要求 package.json（11 项声明）× `HOST_BASELINE_REGISTRY` × README 基线集表
**逐项一致**。**ARCH-007 语义演进**：声明面从 ARCH-006 的「单区间 + 覆盖判据
（`declaredRangeCovers`，镜像宿主装载门 `semver.satisfies(..., {includePrerelease:true})`）」
改为**逐代并集**——`>=0.2.0-rc.2 <0.2.1-0 || >=0.2.1-rc.1 <0.2.2-0 || >=0.2.2-rc.1 <0.2.3-0`，
按 **stock semver 语义**（npm / pnpm / 插件市场判定口径，无 `includePrerelease`）逐段准入；
`tests/host-contract.mjs` 的覆盖判据 `declaredRangeCovers` 仍经文本提取消费
`tests/host-version-snapshot.mjs` 的同一 `caretRangeContains`，ARCH-007 起该谓词兼承
并集/stock 语义，S3「范围收敛且覆盖 primary」判据继续有效；
每个被支持代际一段，主基线 = 注册表 primary `0.2.2`，frozen 项 `0.2.0` / `0.2.1` 由各自的
同代际段准入；`0.1.5` 为历史冻结项、低于声明面下限，**不在并集内**（注册表保留该档案项，
但声明面不承诺准入）。**D5 起因**：单区间 `>=0.2.0-rc.2 <0.2.3-0` 在 stock 语义下只接纳
`0.2.0-rc.2`，拒绝 `0.2.1-rc.2` / `0.2.2-rc.1`（仅装载门的 `includePrerelease` 放行），
即「宿主装得上、包管理器/市场判定失配」——故必须逐代并集。该口径**已由
`tests/host-version-snapshot.mjs` 既有断言机器覆盖**（不重复造轮子）；
核对凭据 = 以下断言族（跑 `node tests/host-version-snapshot.mjs`，绿 = 一致）：

| 三方边 | 断言（`ok` 行文本，ARCH-007 后口径） | 数量 |
|---|---|---|
| 并集 → 支持代际（stock 正例） | `stock satisfies: every peer/runtime declared range (<并集>) admits ALL supported baselines under stock semantics (no includePrerelease crutch)`；逐项 `stock satisfies: baseline <id> …` | 1 + 3 |
| 并集 → 代际外版本（负例） | `stock satisfies: out-of-scope <ver> is NOT in the declared union`（`0.2.3-0` / `0.2.3` / `0.3.0` / `0.1.5-rc.2` / `0.2.1-alpha.5`） | 5 |
| 并集 → 结构锁（防漏代际） | `declared range has exactly one segment per supported registry generation …` + `declared segments are derived 1:1 from supported generations …` + 每段准入自身 `dshPackages` | 3 |
| package.json → 注册表（逐项） | `peerDep/dep @deepseek-ai/<pkg> records the common declared range (<并集>)`（8 项 optional peer + 3 项运行时 peer；平台 2 项 `^` 范围另判） | 11 |
| 注册表 → README（行级） | 每项 `README §5: registry entry <id> has exactly one table row` + `README §5: row <id> mirrors registry (status=…, dsh=…, dsh-*=…, cordis=…, schemastery=…)`；`exactly one primary baseline row`；primary 行 `baseline id` / `status cell declares primary（当前）` / 四值列（dsh、dsh-*、cordis、schemastery）逐列相等 | 16 |

三方由传递性闭合（pkg 声明范围 ↔ 注册表逐项相等；注册表每代际 ↔ README 行级四值一致；
并集正/负例 + 结构锁保证恰好覆盖被支持代际、既不漏代际也不放宽越界）。ARCH-007 批核对
证据：2026-11-07 跑 `node tests/host-version-snapshot.mjs` = **97/97 绿，exit 0**
（断言数随刷新变化，以当次运行输出为准）。

**覆盖面如实声明（边界）**：README 侧断言为**行级 + 列值字面量比对**（ARCH-007 起解析
基线集表并逐行比对 status / 四值列），不再依赖「全文别处出现」；剩余边界 = 列序固定
（列换位需同步刷新解析器），以及不校验措辞/备注列。声明面 = **逐代并集结构锁**
（段数 === 支持代际数、每段下界由档案项推导——新增代际漏追加同代际段即红）+ 正负例；
不覆盖「宿主装载门自身实现变更」（那由 §1 冷装行为判据承载，两者互补）。

## 6. 判别红演示（判据非恒绿的自证）

`--expect-skip` 即判别力自证程序：临时回退任一 peerDep 至旧范围（默认
`@deepseek-ai/dsh-settings` → `^0.1.5-rc.2`）→ 冷装环境启动即现
`dsh: skipping profile bundle "dsh-agent-router"` 警告（红，摘录留证）→ 恢复 →
复跑绿。A1 批固化首跑证据（2026-10-17）：

- 红演示沙箱：`%TEMP%\arch005-gate-32660-mvba0zo8\`（boot2 摘录警告与宿主
  `:320-322` 模板逐字一致，且警告只点名被回退的单项——与 R1 批证据同形态；
  R5 审查 F-1 修复后复跑，7 条命令行全 exit=0）；
- 绿路径沙箱：`%TEMP%\arch005-gate-1436-mvba14d5\`（stderr 0 字节 + bundle 段在场）；
- 红演示后仓库 `git diff` 干净（字节精确恢复经 git 层独立证实）。

SOP 义务：装载门判据相关变更（声明面跳跃 / 豁免通道行为 / 宿主装载门实现变更）
后，`--expect-skip` 判别演示 MUST 至少跑一次——恒绿判据无看护价值。
