// FIX-001 / RISK-003 看护网：twin adapter 与宿主 dsh-llm adapter 接口奇偶回归。
//
// 事实源：宿主 adapter 契约（dsh-llm LlmAdapter）。宿主 adapterStream 对每次
// 分发先调 adapter.prepareCall——twin 是手工对象字面量（无基类继承），缺任一
// 契约方法即全量断裂（FIX-001 实证：prepareCall 缺失 → "registration.adapter.
// prepareCall is not a function" → 接管路由全部失败）。
//
// FIX-001b（R6 审查绑定条件）：
// - F1：独立入口守卫改 pathToFileURL 可移植写法（此前 Windows 永假——断言
//   从未执行过，独立运行空转 exit 0 = 假绿）。
// - F2：契约清单改**动态枚举并集**——宿主实际导出 LlmAdapter 基类，原型方法
//   自动进清单（宿主未来新增方法即自动受检 = RISK-003 真实预警）；stream 为
//   抽象声明不在运行时原型，静态补集（纯枚举会漏检）。
// - F3：test 3 marker 断言增强（system 含 MARKER 才是改写路径核心证据）。
//
// FIX-034：守卫扩展——契约枚举校验从 twin 单覆盖扩展为 twin + oauth-llm 双
// 适配器（EVO-009 createOauthAdapter 同为手工对象字面量，宿主消费点
// LlmRuntime.imageRequestPricing 直调缺方法即同型断裂）；7b 夹具勘正为宿主 schema 实形
// （LlmImageRequestPricing 方法式 `priceImages(images)`）；7c 补
// wrapper 取价抛错 fail-safe 判别（FIX-033 R0 P2×2 归并）。
//
// 本文件独立可跑（node tests/adapter-parity.mjs），并导出 runner 供 smoke
// 接线（接线由后续任务统一执行）。
import { pathToFileURL } from 'node:url'
import { LlmAdapter } from '@deepseek-ai/dsh-llm'
import { createWrapAdapter, WRAP_SUFFIX } from '../lib/wrapper.js'
import { createOauthAdapter, OAUTH_PROVIDER } from '../lib/oauth-llm.js'

/**
 * 宿主 LlmAdapter 契约方法清单 = 动态枚举并集：
 * - `Object.getOwnPropertyNames(LlmAdapter.prototype)` 去掉 constructor——
 *   宿主基类的具体方法（宿主未来新增自动进入本清单，预警真实生效）；
 * - 静态补 `'stream'`——抽象声明（无运行时实现）不在原型上，纯枚举会漏检；
 * - 静态补 `'prepareCall'`（FIX-006 宿主漂移对齐，FIX-033 rc.2 复核）——该方法
 *   在宿主 rc 系三次迁移：rc.6 原型（FIX-001 实证 adapterStream 每次分发先调
 *   adapter.prepareCall）→ rc.8 移出原型（adapterStream 直接调
 *   adapter.stream）→ **0.1.5-rc.2 回归原型**（宿主 LlmAdapter 的 prepareCall，
 *   adapterStream 的 prepared 缺省分支仍先调 adapter.prepareCall）。
 *   twin 保留 prepareCall 作为跨 rc 兼容层，静态补入与原型枚举经 Set 去重——
 *   任一侧漂移（再移出/再回归）清单恒覆盖，继续受看护。
 *
 * FIX-033 枚举 diff 全量审计（0.1.5-rc.2）：原型方法集 = providerInfo /
 * providerRetryPolicy / **imageRequestPricing（新增，LlmAdapter 默认「declares none」）** / listModels /
 * resolveModel / prepareCall（回归原型）。与 twin 既有方法集对比，
 * 唯一缺口 = imageRequestPricing；其余零差异（stream 维持静态补集）。
 */
const ADAPTER_CONTRACT = [
  ...new Set([
    ...(typeof LlmAdapter === 'function'
      ? Object.getOwnPropertyNames(LlmAdapter.prototype).filter((name) => name !== 'constructor')
      : []),
    'stream',
    'prepareCall',
  ]),
]

/** 构造 fake llm：registration 返回可控的原生 adapter（记录调用供断言）。 */
function makeFakeLlm({ inputModalities = ['text'] } = {}) {
  const calls = { resolveModel: 0, stream: 0, nativeStream: 0 }
  const nativeAdapter = {
    providerInfo: (provider) => ({ id: provider, name: `Fake ${provider}` }),
    providerRetryPolicy: () => undefined,
    listModels: async () => [{ provider: 'fake-prov', id: 'm1', name: 'm1' }],
    resolveModel: async (provider, model) => {
      calls.resolveModel += 1
      return { provider, id: model, name: model, inputModalities }
    },
    stream: async function* () {
      calls.nativeStream += 1
      yield { type: 'text', text: 'native' }
    },
  }
  const llm = {
    registration: (provider) => ({ adapter: nativeAdapter }),
    stream: async function* (options) {
      calls.stream += 1
      yield { type: 'text', text: 'twin-delegated' }
    },
  }
  return { llm, calls }
}

export async function runAdapterParityTests(check) {
  // 0. 契约清单健康自检（FIX-001b F2，FIX-006 漂移对齐，FIX-033 rc.2 对齐）：
  //    动态枚举必须产出 ≥6 项方法（rc.2 基类形状：providerInfo/
  //    providerRetryPolicy/imageRequestPricing/listModels/resolveModel/
  //    prepareCall 全在原型）且必含 resolveModel 与 imageRequestPricing
  //    （rc.2 新增契约——枚举失效/宿主回退均红）；stream 为静态补集
  //    （抽象声明）恒在清单——宿主导出形状变化（枚举失效）本身就要红。
  check('ADAPTER_CONTRACT dynamic enum yields core methods (F2, rc.2)', ADAPTER_CONTRACT.length >= 6 && ADAPTER_CONTRACT.includes('prepareCall') && ADAPTER_CONTRACT.includes('resolveModel') && ADAPTER_CONTRACT.includes('stream') && ADAPTER_CONTRACT.includes('providerInfo') && ADAPTER_CONTRACT.includes('listModels') && ADAPTER_CONTRACT.includes('imageRequestPricing'))

  // 1. 接口奇偶（核心看护）：契约方法在 twin 上逐一 typeof === 'function'。
  //    宿主未来新增契约方法而 twin 未跟进 → 此处红 = RISK-003 预警。
  {
    const { llm } = makeFakeLlm()
    const active = [{ modality: 'image', stateOf: null, marker: () => '', rewrite: () => null }]
    const twin = createWrapAdapter(llm, 'fake-prov', active)
    for (const method of ADAPTER_CONTRACT) {
      check(`twin implements adapter contract method: ${method}`, typeof twin[method] === 'function')
    }
  }

  // 1b. FIX-034：oauth-llm 适配器接口奇偶——同一契约清单（ADAPTER_CONTRACT
  //     动态枚举宿主 LlmAdapter.prototype 六方法）对 createOauthAdapter 产出
  //     对象同构校验：EVO-009 适配器同为手工对象字面量（无基类默认可继承），
  //     宿主 LlmRuntime.imageRequestPricing 消费点
  //     经 adapters.get(provider).adapter.imageRequestPricing 直调——缺任一
  //     契约方法即同型 "adapter.imageRequestPricing is not a function" 断裂
  //     （FIX-033 Developer 上报的 twin 同缺口在本适配器的镜像形状）。
  //     工厂构造期零依赖（ctx/service 仅在方法体内消费）——契约面校验传
  //     null 即可，不引 service 夹具（EVO-009 内联夹具形态按现状适配，test 5
  //     形状直传组维持不动）。
  {
    const oauthAdapter = createOauthAdapter(null, null)
    for (const method of ADAPTER_CONTRACT) {
      check(`oauth-llm adapter implements adapter contract method: ${method}`, typeof oauthAdapter[method] === 'function')
    }
    // 行为判别：chatgpt-oauth 路由未声明图片定价（端点无公开按图计价表，
    // 不虚构数字）→ undefined（宿主 LlmAdapter.imageRequestPricing 默认语义 "declares none"，消费者
    // 回落中性估算）；同步零 I/O、不抛。误声明默认定价 / 异步化 / 抛错均红。
    // 缺方法时降级为 'not-a-function' 哨兵而非崩溃调用（TDD RED 期可读失败）。
    let oauthPricing = 'not-a-function'
    if (typeof oauthAdapter.imageRequestPricing === 'function') {
      oauthPricing = oauthAdapter.imageRequestPricing(OAUTH_PROVIDER, 'gpt-x')
    }
    check('oauth-llm: imageRequestPricing 未声明定价 → undefined（宿主 LlmAdapter.imageRequestPricing 默认语义，同步零 I/O）', oauthPricing === undefined)
  }

  // 2. prepareCall 行为：返回 {model, stream}；model 经 twin resolveModel
  //    （wrapRoute 改写 + inputModalities 聚合）；stream 经 twin stream。
  //    （FIX-001b：wrapRoute 从 WRAP_SUFFIX 组装——此前硬编码 'fake-prov+多模态'
  //    系把显示名当路由名，断言永红但因守卫缺陷从未执行过。）
  {
    const { llm, calls } = makeFakeLlm()
    const active = [{ modality: 'image', stateOf: null, marker: () => '', rewrite: () => null }]
    const twin = createWrapAdapter(llm, 'fake-prov', active)
    const prepared = await twin.prepareCall('fake-prov' + WRAP_SUFFIX, 'm1')
    check('prepareCall returns prepared object', prepared && typeof prepared === 'object' && typeof prepared.stream === 'function')
    check('prepared model carries wrapRoute rewrite', prepared.model.provider === 'fake-prov' + WRAP_SUFFIX)
    check('prepared model aggregates declared modalities', Array.isArray(prepared.model.inputModalities) && prepared.model.inputModalities.includes('text') && prepared.model.inputModalities.includes('image'))
    let chunks = []
    for await (const chunk of prepared.stream({ provider: 'fake-prov' + WRAP_SUFFIX, model: 'm1', messages: [] })) chunks.push(chunk)
    check('prepared dispatch goes through twin stream (not native)', calls.stream === 1 && calls.nativeStream === 0 && chunks.some((c) => c.text === 'twin-delegated'))
  }

  // 3. prepared 不绕过改写：原生模型纯文本 + 带图消息 → prepared.stream 分发
  //    后 fake llm.stream 收到的 messages 无图片块（twin 改写生效）+ system
  //    含 marker（改写路径核心证据——FIX-001b F3 增强）。
  //    （provider 'fake-text'：与 test 4 隔离——wrapper 能力探测缓存是模块级
  //    60s TTL，同 provider+model+modality 键会互相污染判定。）
  {
    const { llm } = makeFakeLlm({ inputModalities: ['text'] })
    const active = [{
      modality: 'image',
      stateOf: null,
      marker: () => 'MARKER',
      rewrite: () => null, // rewrite 返回 null = 图片块整体移除（v3 语义）
    }]
    const twin = createWrapAdapter(llm, 'fake-text', active)
    const prepared = await twin.prepareCall('fake-text' + WRAP_SUFFIX, 'm1')
    const seen = []
    let seenSystem
    llm.stream = async function* (options) {
      seen.push(...options.messages)
      seenSystem = options.system
      yield { type: 'text', text: 'ok' }
    }
    const imageMessage = { role: 'user', content: [{ type: 'text', text: '看图' }, { type: 'image', source: { kind: 'base64', mediaType: 'image/png', data: 'aGk=' } }] }
    for await (const chunk of prepared.stream({ provider: 'fake-text' + WRAP_SUFFIX, model: 'm1', messages: [imageMessage] })) { void chunk }
    const sawImage = seen.some((m) => Array.isArray(m.content) && m.content.some((b) => b.type === 'image'))
    check('prepared dispatch rewrites image blocks for text-only source model', sawImage === false)
    check('prepared dispatch injects marker into system (F3)', typeof seenSystem === 'string' && seenSystem.includes('MARKER'))
  }

  // 4. 原生多模态对照组：直传分支图片块保留（prepared 链路不破坏直传语义）。
  //    （provider 'fake-mm'：独立键避免与 test 3 的探测缓存互相污染。）
  {
    const { llm } = makeFakeLlm({ inputModalities: ['text', 'image'] })
    const active = [{ modality: 'image', stateOf: null, marker: () => 'MARKER', rewrite: () => null }]
    const twin = createWrapAdapter(llm, 'fake-mm', active)
    const prepared = await twin.prepareCall('fake-mm' + WRAP_SUFFIX, 'm1')
    const seen = []
    llm.stream = async function* (options) {
      seen.push(...options.messages)
      yield { type: 'text', text: 'ok' }
    }
    const imageMessage = { role: 'user', content: [{ type: 'text', text: '看图' }, { type: 'image', source: { kind: 'base64', mediaType: 'image/png', data: 'aGk=' } }] }
    for await (const chunk of prepared.stream({ provider: 'fake-mm' + WRAP_SUFFIX, model: 'm1', messages: [imageMessage] })) { void chunk }
    const sawImage = seen.some((m) => Array.isArray(m.content) && m.content.some((b) => b.type === 'image'))
    check('prepared dispatch preserves image blocks when source model is multimodal', sawImage === true)
  }

  // 5. FIX-018 缺陷 2 证明（EVO-009 chatgpt-oauth 实案形状）：「原模型已多模态
  //    时 twin 直传图片」判定链锁定。适配器形状 = EVO-009 createOauthAdapter
  //    的 resolveModel 返回形状（{provider, id, name, inputModalities}，声明
  //    ['text','image']）；twin stream 对含图请求先经 sourceAcceptsModality →
  //    registration('fake-oauth').adapter.resolveModel 直调可达 → accepts=true
  //    → 直传分支：委托 provider = 原 provider、图片块保真、零 system 标记
  //    （主模型自己看图，不进 route_agent 改写面）。判别：探测不可达（如误经
  //    宿主二次路由/形状不兼容读不到 inputModalities）→ accepts=false → 改写
  //    分支 → 图片块消失 + MARKER 注入 → 三断言必败。
  //    （provider 'fake-oauth' + model 'gpt-x'：独立缓存键，避免与 test 3/4 的
  //    模块级 60s 探测缓存互相污染。）
  {
    const oauthAdapter = {
      providerInfo: (route) => ({ id: route, name: 'ChatGPT 订阅' }),
      // EVO-009 形状：route 参数弃用（目录咨询性），恒返回账号级能力声明。
      resolveModel: async (_route, model) => ({ provider: 'fake-oauth', id: model, name: model, inputModalities: ['text', 'image'] }),
    }
    const delegations = []
    const llm = {
      registration: (provider) => {
        if (provider !== 'fake-oauth') throw new Error(`no adapter registered for provider "${provider}"`)
        return { adapter: oauthAdapter }
      },
      stream: async function* (options) {
        delegations.push(options)
        yield { type: 'text', text: 'ok' }
      },
    }
    const active = [{ modality: 'image', stateOf: null, marker: () => 'MARKER', rewrite: () => null }]
    const twin = createWrapAdapter(llm, 'fake-oauth', active)
    const imageMessage = { role: 'user', content: [{ type: 'text', text: '看图' }, { type: 'image', source: { kind: 'base64', mediaType: 'image/png', data: 'aGk=' } }] }
    for await (const chunk of twin.stream({ provider: 'fake-oauth' + WRAP_SUFFIX, model: 'gpt-x', messages: [imageMessage] })) { void chunk }
    check('EVO-009 形状：twin 探测可达插件注册适配器并直传（委托=原 provider）', delegations.length === 1 && delegations[0].provider === 'fake-oauth')
    check('EVO-009 形状：图片块保真（零改写直传）', Array.isArray(delegations[0].messages[0].content) && delegations[0].messages[0].content.some((b) => b.type === 'image'))
    check('EVO-009 形状：零 system 标记注入（不进 route_agent 改写面）', delegations[0].system === undefined)
  }

  // 6. EVO-017 R2：twin 调用统计回调（onCall）——预设会话主/subagent 的 LLM
  //    流经 twin，账号级用量此前零记录（账号统计恒 0 根因）。判别：成功流
  //    上报 ok:true + usage tokens；失败流上报 ok:false + error + 原样上抛；
  //    回调抛错零影响流。
  {
    // 6a 成功流：usage chunk 提取 + ok:true。
    const reports = []
    const llmOk = {
      registration: () => ({ adapter: { resolveModel: async (p, m) => ({ provider: p, id: m, name: m, inputModalities: ['text'] }) } }),
      stream: async function* () {
        yield { type: 'usage', usage: { inputTokens: 11, outputTokens: 7 } }
        yield { type: 'finish', reason: { kind: 'stop' } }
      },
    }
    const activeOk = [{ modality: 'image', stateOf: null, marker: () => 'MARKER', rewrite: () => null }]
    const twinOk = createWrapAdapter(llmOk, 'fake-stat', activeOk, (event) => reports.push(event))
    for await (const chunk of twinOk.stream({ provider: 'fake-stat' + WRAP_SUFFIX, model: 'm1', messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }] })) { void chunk }
    check('R2-5: twin onCall 成功上报（provider=twin 路由 + usage tokens）', reports.length === 1 && reports[0].ok === true && reports[0].provider === 'fake-stat' + WRAP_SUFFIX && reports[0].model === 'm1' && reports[0].inputTokens === 11 && reports[0].outputTokens === 7 && reports[0].ms >= 0)

    // 6b 失败流：ok:false + error + 原样上抛。
    const reportsFail = []
    const llmFail = {
      registration: () => ({ adapter: { resolveModel: async (p, m) => ({ provider: p, id: m, name: m, inputModalities: ['text'] }) } }),
      stream: async function* () { throw new Error('upstream boom') },
    }
    const twinFail = createWrapAdapter(llmFail, 'fake-stat2', activeOk, (event) => reportsFail.push(event))
    let thrown = null
    try { for await (const chunk of twinFail.stream({ provider: 'fake-stat2' + WRAP_SUFFIX, model: 'm1', messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }] })) { void chunk } } catch (error) { thrown = error }
    check('R2-6: twin onCall 失败上报 + 异常原样上抛', thrown !== null && thrown.message === 'upstream boom' && reportsFail.length === 1 && reportsFail[0].ok === false && String(reportsFail[0].error).includes('upstream boom'))

    // 6c 回调抛错零影响流（统计旁路）。
    const llmQuiet = {
      registration: () => ({ adapter: { resolveModel: async (p, m) => ({ provider: p, id: m, name: m, inputModalities: ['text'] }) } }),
      stream: async function* () { yield { type: 'finish', reason: { kind: 'stop' } } },
    }
    const twinQuiet = createWrapAdapter(llmQuiet, 'fake-stat3', activeOk, () => { throw new Error('stats boom') })
    let quietChunks = 0
    let quietThrown = null
    try { for await (const chunk of twinQuiet.stream({ provider: 'fake-stat3' + WRAP_SUFFIX, model: 'm1', messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }] })) quietChunks += 1 } catch (error) { quietThrown = error }
    check('R2-7: onCall 抛错零影响流（chunks 正常产出）', quietThrown === null && quietChunks === 1)
  }

  // 7. FIX-033：twin imageRequestPricing 镜像语义（宿主 0.1.5-rc.2 原型新增，
  //    LlmAdapter.imageRequestPricing）。契约：同步零 I/O（宿主注释 "must answer
  //    synchronously without I/O"），默认 undefined = 路由未声明图片定价（消费者回落中性
  //    估算）；运行时消费点 LlmRuntime.imageRequestPricing 逐路由
  //    经 adapters.get(provider).adapter 解析。twin 语义对齐：定价归属原适配
  //    器（twin 路由 = 同一上游模型的包装路由）——原适配器声明则透传（传参
  //    原 provider id，与其余镜像方法同构），未声明/缺失 → undefined（宿主
  //    基类默认）。判别：透传错路由 id / 误声明默认定价 / 异步化均红。
  {
    // 7a 原适配器未实现（宿主基类默认 = 未声明）：twin 返回 undefined。
    {
      const llmPlain = {
        registration: () => ({ adapter: { resolveModel: async (p, m) => ({ provider: p, id: m, name: m, inputModalities: ['text'] }) } }),
        stream: async function* () { yield { type: 'text', text: 'ok' } },
      }
      const twinPlain = createWrapAdapter(llmPlain, 'fake-plain', [])
      const pricing = twinPlain.imageRequestPricing('fake-plain' + WRAP_SUFFIX, 'm1')
      check('FIX-033: 原适配器未声明定价 → twin 返回 undefined（宿主 LlmAdapter.imageRequestPricing 默认语义）', pricing === undefined)
    }

    // 7b 原适配器声明定价：twin 同步透传同形返回 + 以原 provider id 委托。
    //    FIX-034 F2-1（P10-④ 勘正）：夹具形状锚定宿主 schema 实形——
    //    LlmImageRequestPricing = 方法式 `{ priceImages(images) }`（宿主 dsh-llm
    //    lib/types/types.d.ts：对一次请求投影的全部图片逐 occurrence
    //    计价，返回与 images 索引对齐；单价形态 LlmImageRequestPrice
    //    {visualTokens, text}）。旧夹具 {perImageTokens,
    //    perRequestImages} 系按心智模型伪造的字段式形状，宿主消费面零此
    //    字段。勘正后 twin 透传语义断言不变（同形返回 + 原 provider 委托）。
    {
      const PRICING = {
        priceImages(images) {
          return images.map((ref) => ({ visualTokens: 85, text: `image:${ref.attachmentId}` }))
        },
      }
      const seenArgs = []
      const llmPriced = {
        registration: () => ({
          adapter: {
            resolveModel: async (p, m) => ({ provider: p, id: m, name: m, inputModalities: ['text'] }),
            imageRequestPricing(provider, model) {
              seenArgs.push({ provider, model })
              return PRICING
            },
          },
        }),
        stream: async function* () { yield { type: 'text', text: 'ok' } },
      }
      const twinPriced = createWrapAdapter(llmPriced, 'fake-priced', [])
      const returned = twinPriced.imageRequestPricing('fake-priced' + WRAP_SUFFIX, 'm1')
      check('FIX-033: 原适配器声明定价 → twin 同步透传同形返回（宿主 LlmRuntime.imageRequestPricing 消费面同构）', returned === PRICING && seenArgs.length === 1 && seenArgs[0].provider === 'fake-priced' && seenArgs[0].model === 'm1')
    }

    // 7c FIX-034 F2-2：原适配器取价抛错 → twin 回落 undefined 且不抛
    //    （wrapper fail-safe 分支判别——计量元数据缺陷不击穿 token meter，
    //    与 providerRetryPolicy 抛错回落同构方向）。红/绿演示：临时删
    //    wrapper imageRequestPricing 的 try/catch fail-safe → 抛错上击 →
    //    本断言红（判别力证明，非形式化用例）。
    {
      const llmThrowing = {
        registration: () => ({
          adapter: {
            resolveModel: async (p, m) => ({ provider: p, id: m, name: m, inputModalities: ['text'] }),
            imageRequestPricing() { throw new Error('pricing boom') },
          },
        }),
        stream: async function* () { yield { type: 'text', text: 'ok' } },
      }
      const twinThrowing = createWrapAdapter(llmThrowing, 'fake-throw', [])
      let threw = false
      let returnedThrowing
      try { returnedThrowing = twinThrowing.imageRequestPricing('fake-throw' + WRAP_SUFFIX, 'm1') } catch { threw = true }
      check('FIX-034: 原适配器取价抛错 → twin 回落 undefined 且不抛（fail-safe 判别）', threw === false && returnedThrowing === undefined)
    }
  }
}

// FIX-001b F1：pathToFileURL 可移植比较（Windows 下 argv[1] 反斜杠路径 vs
// import.meta URL 格式不匹配——此前守卫永假，独立运行空转 exit 0 = 假绿）。
const invoked = import.meta.url === pathToFileURL(process.argv[1] ?? '').href
if (invoked) {
  let failures = 0
  let oks = 0
  const check = (name, ok) => {
    if (ok) { oks += 1; console.log(`  ok  ${name}`) }
    else { failures += 1; console.log(`  FAIL ${name}`) }
  }
  await runAdapterParityTests(check)
  if (failures > 0) {
    console.log(`ADAPTER PARITY TESTS FAILED (${failures} failures, ${oks} ok)`)
    process.exit(1)
  }
  console.log(`ALL ADAPTER PARITY TESTS PASSED (${oks} assertions)`)
}
