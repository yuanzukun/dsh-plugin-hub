// dsh-agent-router 平台安装入口测试：
// - BOM 编码守卫：install.ps1 必须带 UTF-8 BOM（PS 5.1 的 -File 离线入口在无 BOM 时
//   按 ANSI 解码 UTF-8 中文注释，产生假解析错误——本机实测）；install.sh 必须无 BOM
//   （POSIX shebang 无法处理 BOM）。
// - 在线命令守卫：本地 HTTP fixture 服务器（复刻 GitHub raw 响应头）按请求生成带/不带
//   BOM 的参数块脚本，对每个可用 PowerShell 宿主执行与 README 一致的在线命令，断言成功；
//   同时反向断言旧命令（irm | iex）在带 BOM 响应下失败，防止假绿。
// - POSIX 在线命令守卫：sh 可用时执行 curl | sh 形式；不可用则跳过。
// - 离线安装守卫：临时 DSH_HOME 下跑 -File/-LocalPath 与 sh --local，验证幂等。
// - 依赖解析守卫：裸源码（git clone 形态，无 node_modules）安装后，安装脚本必须把
//   profiles 的平坦依赖树链接进源码目录，使插件自身 @deepseek-ai/* 依赖可解析
//   （缺失时 ERR_MODULE_NOT_FOUND 击穿 DSH 启动——实测复现）；自带真实 node_modules
//   的源码目录不得被改动。
// - 文档一致性守卫：README 与 install.ps1 头部注释记载的命令必须与测试模板一致。
//
// 沙箱兼容：所有子进程 stdio 一律 ignore，断言信号由 fixture 写入结果文件，
// 不依赖捕获子进程管道输出。清理 temp 目录时 junction/symlink 只删链接本身。
import { spawn } from 'node:child_process'
import { createServer } from 'node:http'
import { readFileSync, existsSync, readdirSync, lstatSync, rmSync, mkdirSync, rmdirSync, cpSync, symlinkSync, writeFileSync, openSync, closeSync, chmodSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT_DIR = join(dirname(fileURLToPath(import.meta.url)), '..')

const ONLINE_CMD_CORE = `iex (((irm {URL}) -join [Environment]::NewLine).TrimStart([char]0xFEFF))`
const OLD_CMD_CORE = `irm {URL} | iex`
const RAW_URL = 'https://raw.githubusercontent.com/peterwangze/dsh-agent-router/main/install.ps1'

const BOM = Buffer.from([0xef, 0xbb, 0xbf])

/** 子进程超时（受限环境偶发挂起时快速失败而非无限等待）。 */
const SPAWN_TIMEOUT_MS = 30000

/**
 * install.ps1 **离线安装臂**的平台适用性（FIX-038）：install.ps1 自述为 Windows
 * 专属入口（install.ps1:1「Windows / PowerShell 5.1+」；POSIX 侧入口 = install.sh:2），
 * 其离线臂依赖 Windows 原生链接/拷贝语义——`New-Item -ItemType Junction`（win32
 * junction）、`robocopy` 拷贝回退、`Join-Path $dshHome 'profiles\node_modules'` 式
 * 反斜杠子路径。非 win32 平台上该臂不可判定：CI run 34696694673（ubuntu-24.04 +
 * PowerShell 7 首跑）实证 `offline install (-File) succeeds on pwsh` 失败，且裸源码
 * 臂随后在 `lstatSync` 上 ENOENT 裸抛 → 套件崩溃、其后断言与诊断全部丢失。
 * CI 覆盖边界同此声明（.github/workflows/ci.yml「必须 Windows 本地跑」节：
 * 「目录 link 语义（win32 走 junction，POSIX 走 symlink）」）。
 * 判据取**平台**（非宿主）：win32 上 powershell/pwsh 两臂都执行 install.ps1；
 * 非 win32 上 POSIX 对偶覆盖按臂分列（仅陈述实际成立范围）：§6（`-File` 离线安装）/ §6c
 * （裸源码依赖链接）在 sh 可用时由 install.sh 臂承担（见各段 sh 臂；sh 缺失时另有
 * `POSIX online checks` skip 行可辨）；§6d（自带真实 `node_modules` 不得改动）**无 POSIX
 * 对照臂**——install.sh 的「源码自带依赖目录：…（跳过依赖链接）」分支与 `LINKED=0`
 * 拷贝回退护栏（「只移除本脚本创建的符号链接（绝不对真实目录 rm -rf）」）同载该数据
 * 保护语义却零判别测试（已知覆盖缺口，台账候选）。**锚形 = 符号名 / 代码串 + 文件**
 * （FIX-040：行号锚实测漂移族，不再写死行号；锚点为 install.sh 的 `step` 文案与
 * `LINKED` 守卫变量，按串检索即可定位）。非适用平台分支均先打印可见 skip 再空循环，
 * 不静默丢弃。
 */
const PS1_OFFLINE_APPLICABLE = process.platform === 'win32'

/** install.ps1 各离线臂共用的不适用原因（单点，P5：同一动作单一实现路径）。 */
const PS1_PLATFORM_DETAIL = `install.ps1 是 Windows 专属安装入口（离线臂依赖 junction/robocopy 与 'profiles\\node_modules' 反斜杠子路径）；本平台 ${process.platform} 不适用`

/**
 * 可见 skip（FIX-037 ① 机制）：非适用平台/宿主上断言不得静默通过——打印原因行
 * （`  skip <臂> (<原因>)`；本模块的 stdout 由承载套件 smoke.mjs 输出，run-all.mjs
 * 捕获该形态行回显 `#SKIP | …` 并计入 `#SKIP n` 汇总，口径见 ci.yml「预期内的 skip」）。
 */
function skipArm(label, reason) {
  console.log(`  skip ${label} (${reason})`)
}

/**
 * 目录项存在性安全探测（FIX-038）：`lstatSync` 在路径不存在时**裸抛 ENOENT**——
 * 夹具断言点不得用异常表达「缺失」（CI run 34696694673 实证：安装脚本未产出链接
 * → 套件崩在 lstat，真实失败面被 ENOENT 覆盖、后续断言全部丢失）。
 * @param {string} path - 目标路径。
 * @returns {import('node:fs').Stats | undefined} undefined = 路径不存在（交断言如实判 FAIL）。
 */
function lstatOrUndefined(path) {
  try {
    return lstatSync(path)
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
}

/**
 * 异步执行子进程并等待退出。默认 stdio 全部 ignore；传 `outputFile` 时把
 * stdout+stderr 合并重定向到该文件（文件捕获兼容受限环境，避免命名管道）。
 * 必须异步：fixture 服务器跑在本进程事件循环里，spawnSync 同步阻塞会饿死
 * HTTP 响应、导致子进程永远等响应。
 * @returns {Promise<{status: number | null, error: {code?: string} | null}>}
 */
function runCommand(command, args, options = {}) {
  return new Promise((resolve) => {
    const { outputFile, ...spawnOptions } = options
    let outputFd = null
    if (outputFile !== undefined) {
      outputFd = openSync(outputFile, 'w')
      spawnOptions.stdio = ['ignore', outputFd, outputFd]
    }
    const child = spawn(command, args, { stdio: 'ignore', ...spawnOptions })
    if (outputFd !== null) closeSync(outputFd)
    let settled = false
    const finish = (error, status) => {
      if (settled) return
      settled = true
      resolve({ error, status })
    }
    const timer = setTimeout(() => {
      child.kill()
      finish(null, null)
    }, SPAWN_TIMEOUT_MS)
    child.on('error', (error) => {
      clearTimeout(timer)
      finish({ code: error.code ?? 'SPAWN_ERROR' }, null)
    })
    child.on('exit', (code) => {
      clearTimeout(timer)
      finish(null, code)
    })
  })
}

/** 探测可用的 PowerShell 宿主（5.1 为 powershell.exe，7+ 为 pwsh.exe）。 */
async function powerShellHosts() {
  const hosts = []
  for (const exe of ['powershell', 'pwsh']) {
    const probe = await runCommand(exe, ['-NoProfile', '-Command', 'exit 0'])
    if (probe.error === null) hosts.push(exe)
  }
  return hosts
}

/** 探测可用的 POSIX shell 与 curl。 */
async function posixShell() {
  const probe = await runCommand('sh', ['-c', 'exit 0'])
  if (probe.error !== null) return null
  const curl = await runCommand('curl', ['--version'])
  if (curl.error !== null) return null
  return 'sh'
}

/** 生成带 param 块的 PowerShell fixture（在线入口形态镜像），结果写入文件而非 stdout。 */
function psFixtureBody(resultFile) {
  return [
    `# fixture: mirrors the param-block entry shape of install.ps1 (online iex path).`,
    `param(`,
    `  [string]$RepoUrl = 'https://example.com/dsh-agent-router.git',`,
    `  [string]$Ref = 'main',`,
    `  [string]$LocalPath = '',`,
    `  [string]$Profile = 'web'`,
    `)`,
    `Set-Content -Path '${resultFile.replace(/'/g, "''")}' -Value ("SENTINEL-OK repo={0} ref={1} local={2} profile={3}" -f $RepoUrl, $Ref, $LocalPath, $Profile)`,
    ``,
  ].join('\n')
}

/** 生成 POSIX sh fixture，结果写入文件而非 stdout。 */
function shFixtureBody(resultFile) {
  return `#!/bin/sh\n# fixture: entry-shape mirror for install.sh (online curl|sh path).\necho 'SENTINEL-SH-OK' > '${resultFile.replace(/'/g, "'\\''")}'\n`
}

/**
 * 创建目录链接（Windows 用 junction，POSIX 用默认 symlink）。
 * @param {string} target - 链接目标（真实目录）。
 * @param {string} link - 链接路径。
 */
function makeDirLink(target, link) {
  symlinkSync(target, link, process.platform === 'win32' ? 'junction' : undefined)
}

/**
 * 从临时 DSH_HOME 的 web profile 目录解析插件本体（模拟 DSH loader 的
 * bare-name import）：probe 脚本写入 profile 目录、结果写入文件（stdio
 * ignore 兼容受限环境）。
 * @param {string} dshHome - 临时 DSH_HOME 根目录。
 * @returns {Promise<string>} probe 输出内容（RESOLVE-OK / RESOLVE-FAIL <code>）。
 */
async function resolvePluginProbe(dshHome) {
  const profileDir = join(dshHome, 'profiles', 'web')
  mkdirSync(profileDir, { recursive: true })
  const probePath = join(profileDir, `.resolve-probe-${Date.now()}.mjs`)
  const resultFile = join(profileDir, `.resolve-result-${Date.now()}.txt`)
  writeFileSync(probePath, `import { writeFileSync } from 'node:fs'
try {
  const mod = await import('dsh-agent-router')
  writeFileSync(${JSON.stringify(resultFile)}, 'RESOLVE-OK ' + Object.keys(mod).join(','))
} catch (error) {
  writeFileSync(${JSON.stringify(resultFile)}, 'RESOLVE-FAIL ' + (error.code ?? '') + ' ' + String(error.message).split('\\n')[0])
}
`)
  const run = await runCommand(process.execPath, [probePath], { cwd: profileDir })
  rmSync(probePath, { force: true })
  if (run.error !== null || run.status !== 0) return `PROBE-CRASH status=${run.status} error=${run.error?.code ?? ''}`
  if (!existsSync(resultFile)) return 'PROBE-NO-RESULT'
  const output = readFileSync(resultFile, 'utf8')
  rmSync(resultFile, { force: true })
  return output
}

/**
 * 启动内存 fixture 服务器（复刻 GitHub raw：text/plain; charset=utf-8 + content-length）。
 * 路由值可以是 Buffer，或 (searchParams) => string|Buffer 的按请求生成函数。
 * @returns {{ port: number, register: (path: string, body: Buffer | ((params: URLSearchParams) => string | Buffer)) => void, close: () => Promise<void> }}
 */
function startFixtureServer() {
  const routes = new Map()
  const server = createServer((req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1')
    const route = routes.get(url.pathname)
    const body = typeof route === 'function' ? route(url.searchParams) : route
    if (!body) { res.writeHead(404); res.end('not found'); return }
    const buffer = Buffer.isBuffer(body) ? body : Buffer.from(body, 'utf8')
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'content-length': String(buffer.length) })
    res.end(buffer)
  })
  return new Promise((resolve, reject) => {
    server.on('error', reject)
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address()
      resolve({
        port,
        register: (path, body) => routes.set(path, body),
        close: () => new Promise((done) => server.close(() => done())),
      })
    })
  })
}

/** 在仓库内建测试临时目录（`.test-home/` 已在 .gitignore 内，不入库）。 */
function tempResultDir() {
  const dir = join(ROOT_DIR, '.test-home', `entry-${process.pid}-${Date.now()}`)
  mkdirSync(dir, { recursive: true })
  return dir
}

/**
 * 删除测试临时目录。junction/symlink 绝不跟随（lstat 判定），只删链接本身，
 * 防止把链接目标（如仓库目录）一并删除。
 */
function removeTempDir(dir) {
  if (!existsSync(dir)) return
  for (const name of readdirSync(dir)) {
    const full = join(dir, name)
    const stat = lstatSync(full)
    if (stat.isSymbolicLink()) {
      // 链接（symlink/junction）：只删链接本体。
      try { rmSync(full, { force: true }) } catch { try { rmdirSync(full) } catch { /* 尽力清理 */ } }
    } else if (stat.isDirectory()) {
      removeTempDir(full)
    } else {
      rmSync(full, { force: true })
    }
  }
  rmdirSync(dir)
}

export async function runInstallEntryTests(check) {
  console.log('install entry:')

  // ── 1. BOM 编码守卫 ────────────────────────────────────────────────
  {
    // install.ps1 带 BOM：PS 5.1 的 -File 离线入口按 BOM 识别 UTF-8；
    // 无 BOM 时中文字节被按 ANSI 解码、产生假解析错误（本机实测 2 处）。
    const ps1 = readFileSync(join(ROOT_DIR, 'install.ps1'))
    const ps1HasBom = ps1.length >= 3 && ps1[0] === 0xef && ps1[1] === 0xbb && ps1[2] === 0xbf
    check('install.ps1 carries UTF-8 BOM (PS 5.1 -File entry)', ps1HasBom)
    // install.sh 无 BOM：POSIX shebang 与 curl|sh 管道都不接受 BOM 前缀。
    const shBytes = readFileSync(join(ROOT_DIR, 'install.sh'))
    const shHasBom = shBytes.length >= 3 && shBytes[0] === 0xef && shBytes[1] === 0xbb && shBytes[2] === 0xbf
    check('install.sh has no UTF-8 BOM (POSIX shebang)', !shHasBom)
  }

  // ── 2. 文档一致性守卫 ──────────────────────────────────────────────
  {
    const core = ONLINE_CMD_CORE.replace('{URL}', RAW_URL)
    const ps1Text = readFileSync(join(ROOT_DIR, 'install.ps1'), 'utf8')
    const readmeText = readFileSync(join(ROOT_DIR, 'README.md'), 'utf8')
    check('install.ps1 header documents BOM-immune command', ps1Text.includes(core))
    check('README documents BOM-immune command (script install table)', readmeText.split(core).length - 1 >= 1)
    check('README no longer documents irm|iex form', !readmeText.includes('irm https://raw.githubusercontent.com/peterwangze/dsh-agent-router/main/install.ps1 | iex') && !readmeText.includes('irm https://raw.githubusercontent.com/peterwangze/dsh-agent-router/main/install.ps1 \\| iex'))
  }

  const tmpDir = tempResultDir()
  const server = await startFixtureServer()
  const baseUrl = `http://127.0.0.1:${server.port}`
  try {
    // ── 3. dsh.bundle 标准管理守卫（`dsh plugin add/remove/update` 通道）──
  // 回归目标：宿主按 `dsh?.bundle?.patch !== undefined` 判活插件层——未声明的
  // 包只按普通依赖安装、不进 profile 层栈（stderr 提示 plain dependency、
  // 不激活）。包内 cordis.patch.yml 顶层数组两行必须与 install.ps1 写入宿主
  // profile 的宿主平面行逐字一致（脚本通道与标准管理通道注册同一对服务）。
  {
    const pkg = JSON.parse(readFileSync(join(ROOT_DIR, 'package.json'), 'utf8'))
    check('package.json declares dsh.bundle.patch layer', pkg.dsh?.bundle?.patch === './cordis.patch.yml')
    check('package.json keeps dsh.client declaration intact', pkg.dsh?.client?.platform === 'web' && Array.isArray(pkg.dsh.client.inject) && pkg.dsh.client.inject.length > 0)
    check('package.json files ships cordis.patch.yml', Array.isArray(pkg.files) && pkg.files.includes('cordis.patch.yml'))
    const patchPath = join(ROOT_DIR, 'cordis.patch.yml')
    check('cordis.patch.yml exists at package root', existsSync(patchPath))
    const patchLines = existsSync(patchPath)
      ? readFileSync(patchPath, 'utf8').split(/\r?\n/).map((line) => line.replace(/\s+$/, ''))
      : []
    check('cordis.patch.yml is a top-level insert array', patchLines.includes('- insert:'))
    check('cordis.patch.yml registers router row verbatim', patchLines.includes('    - id: router') && patchLines.includes('      name: dsh-agent-router'))
    check('cordis.patch.yml registers tool-router row verbatim', patchLines.includes('    - id: tool-router') && patchLines.includes('      name: dsh-agent-router/tool'))
    // README 双通道文档守卫：标准管理命令（在线 git spec / 离线 file: spec /
    // update / remove）必须与 dsh plugin 通道同形；离线段必须说明 link: 只做
    // 符号链接、依赖不安装的缺陷。
    const readmeText = readFileSync(join(ROOT_DIR, 'README.md'), 'utf8')
    check('README documents dsh plugin add (npm + npx online forms)', readmeText.includes('dsh plugin --profile web add github:peterwangze/dsh-agent-router') && readmeText.includes('npx @deepseek-ai/dsh plugin --profile web add github:peterwangze/dsh-agent-router'))
    check('README documents offline add via file: spec', readmeText.includes('plugin --profile web add file:./'))
    check('README documents dsh plugin update and remove', readmeText.includes('plugin --profile web update dsh-agent-router') && readmeText.includes('plugin --profile web remove dsh-agent-router'))
    check('README warns link: skips dependency install', readmeText.includes('link:'))
  }

  // ── 4. 在线命令守卫（PowerShell 5.1 / 7）────────────────────────
    const hosts = await powerShellHosts()
    if (hosts.length === 0) {
      skipArm('PowerShell online checks', 'no powershell/pwsh available')
    }
    for (const host of hosts) {
      for (const variant of ['plain', 'bom']) {
        const resultFile = join(tmpDir, `online-${host}-${variant}.txt`)
        const route = (params) => {
          const body = psFixtureBody(params.get('result') ?? resultFile)
          return variant === 'bom' ? Buffer.concat([BOM, Buffer.from(body, 'utf8')]) : body
        }
        const routePath = `/fixture-${variant}-${host}.ps1`
        server.register(routePath, route)
        const command = ONLINE_CMD_CORE.replace('{URL}', `${baseUrl}${routePath}?result=${encodeURIComponent(resultFile)}`)
        const run = await runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', command])
        const sentinel = existsSync(resultFile) && readFileSync(resultFile, 'utf8').includes('SENTINEL-OK')
        check(`online command succeeds on ${host} (${variant})`, run.status === 0 && run.error === null && sentinel)
      }
      // 反向守卫：旧命令形式在带 BOM 响应下必须失败——证明本测试能捕获该回归。
      {
        const resultFile = join(tmpDir, `online-old-${host}.txt`)
        const routePath = `/fixture-old-${host}.ps1`
        server.register(routePath, (params) => Buffer.concat([BOM, Buffer.from(psFixtureBody(params.get('result') ?? resultFile), 'utf8')]))
        const command = OLD_CMD_CORE.replace('{URL}', `${baseUrl}${routePath}?result=${encodeURIComponent(resultFile)}`)
        const run = await runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', command])
        check(`old irm|iex form rejected under BOM on ${host} (regression witness)`, run.status !== 0 && !existsSync(resultFile))
      }
    }

    // ── 5. POSIX 在线命令守卫 ────────────────────────────────────────
    const sh = await posixShell()
    if (sh === null) {
      skipArm('POSIX online checks', 'no sh/curl available')
    } else {
      const resultFile = join(tmpDir, 'online-sh.txt')
      server.register('/fixture.sh', (params) => shFixtureBody(params.get('result') ?? resultFile))
      const run = await runCommand(sh, ['-c', `curl -fsSL '${baseUrl}/fixture.sh?result=${encodeURIComponent(resultFile)}' | sh`])
      const sentinel = existsSync(resultFile) && readFileSync(resultFile, 'utf8').includes('SENTINEL-SH-OK')
      check(`online curl|sh command succeeds on ${sh}`, run.status === 0 && run.error === null && sentinel)
    }

    // ── 6. 离线安装守卫（临时 DSH_HOME，不触碰真实 ~/.dsh）──────────
    const dshHome = join(tmpDir, 'offline-dsh-home')
    // FIX-038：`-File` 离线臂仅 win32 适用（PS1_OFFLINE_APPLICABLE 注释含实证与
    // CI 边界）；非适用平台打印可见 skip——不静默通过、不删断言，POSIX 侧由紧邻的
    // install.sh 臂承担同一断言面（succeeds + idempotent）。
    if (!PS1_OFFLINE_APPLICABLE) {
      skipArm('offline install (-File) succeeds/idempotent', `${PS1_PLATFORM_DETAIL}——同一断言面由下方 install.sh 臂承担`)
    }
    for (const host of (PS1_OFFLINE_APPLICABLE ? hosts : [])) {
      const runInstall = () => runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(ROOT_DIR, 'install.ps1'), '-LocalPath', ROOT_DIR], { env: { ...process.env, DSH_HOME: dshHome } })
      const first = await runInstall()
      const patch = join(dshHome, 'profiles', 'web', 'cordis.patch.yml')
      const patchOk = existsSync(patch) && readFileSync(patch, 'utf8').includes('name: dsh-agent-router/tool')
      const linkOk = existsSync(join(dshHome, 'profiles', 'node_modules', 'dsh-agent-router', 'package.json'))
      const second = await runInstall()
      const patchAgain = existsSync(patch) && readFileSync(patch, 'utf8').includes('name: dsh-agent-router/tool')
      check(`offline install (-File) succeeds on ${host}`, first.status === 0 && first.error === null && patchOk && linkOk)
      check(`offline install idempotent on ${host}`, second.status === 0 && second.error === null && patchAgain)
    }
    if (sh !== null) {
      const runSh = () => runCommand(sh, ['-c', `DSH_HOME='${dshHome}' sh '${join(ROOT_DIR, 'install.sh')}' --local '${ROOT_DIR}'`])
      const first = await runSh()
      const patch = join(dshHome, 'profiles', 'web', 'cordis.patch.yml')
      const patchOk = existsSync(patch) && readFileSync(patch, 'utf8').includes('name: dsh-agent-router/tool')
      const linkOk = existsSync(join(dshHome, 'profiles', 'node_modules', 'dsh-agent-router', 'package.json'))
      const second = await runSh()
      const patchAgain = existsSync(patch) && readFileSync(patch, 'utf8').includes('name: dsh-agent-router/tool')
      check(`offline install (sh --local) succeeds on ${sh}`, first.status === 0 && first.error === null && patchOk && linkOk)
      check(`offline install (sh --local) idempotent on ${sh}`, second.status === 0 && second.error === null && patchAgain)
    }

    // ── 7. 依赖解析守卫：裸源码（git clone 形态，无 node_modules）────
    // 回归目标：junction 挂载后 Node 从插件真实目录解析 `@deepseek-ai/*`
    // 依赖；缺依赖链接时 ERR_MODULE_NOT_FOUND 击穿 DSH 启动（实测复现）。
    // 裸环境放在仓库外：仓库自身的 dev 依赖 junction 会沿父目录污染解析，
    // 使负向见证假绿（本仓库 .gitignore 注明的开发机 node_modules junction）。
    {
      const bareRoot = join(ROOT_DIR, '..', `.test-home-bare-${process.pid}-${Date.now()}`)
      try {
        // 6a. 构造裸源码拷贝 + 模拟 heal 后的平坦依赖树（把插件 4 个
        //     @deepseek-ai 运行时依赖链接进临时 profiles/node_modules）。
        const bareSrc = join(bareRoot, 'bare-plugin')
        mkdirSync(bareSrc, { recursive: true })
        for (const name of ['lib', 'install.ps1', 'install.sh', 'package.json', 'README.md', 'LICENSE', 'docs']) {
          const from = join(ROOT_DIR, name)
          if (existsSync(from)) cpSync(from, join(bareSrc, name), { recursive: true })
        }
        const bareHome = join(bareRoot, 'bare-dsh-home')
        const bareModules = join(bareHome, 'profiles', 'node_modules')
        mkdirSync(bareModules, { recursive: true })
        // 复刻 heal：把安装树的 @deepseek-ai 包按平坦结构链接进临时 home。
        // 从测试进程自身解析各依赖的真实目录（dev junction / pnpm 布局均可）。
        for (const dep of ['schemastery', 'dsh-tools', 'dsh-typert-protocol', 'dsh-llm']) {
          const pkgJson = createRequire(import.meta.url).resolve(`@deepseek-ai/${dep}/package.json`)
          const realDir = dirname(pkgJson)
          const linkParent = join(bareModules, '@deepseek-ai')
          mkdirSync(linkParent, { recursive: true })
          makeDirLink(realDir, join(linkParent, dep))
        }
        // 6b. 负向见证：仅挂插件本体链接（无依赖链接）→ 必须 ERR_MODULE_NOT_FOUND。
        mkdirSync(join(bareHome, 'profiles', 'web'), { recursive: true })
        makeDirLink(bareSrc, join(bareModules, 'dsh-agent-router'))
        const probeNeg = await resolvePluginProbe(bareHome)
        check('bare source without dep link fails to resolve (regression witness)', probeNeg.includes('ERR_MODULE_NOT_FOUND'))
        // 6c. 正向：跑真实安装脚本后，依赖链接被创建且插件可解析；幂等重跑亦然。
        // FIX-038：`-File` 臂仅 win32 适用；非适用平台记可见 skip，同一断言面由
        // 紧随其后的 sh --local 臂（6c-sh）承担。lstat 一律经 lstatOrUndefined
        // （缺失 → undefined 交断言判 FAIL，禁 ENOENT 裸抛阻断后续断言）。
        if (!PS1_OFFLINE_APPLICABLE) {
          skipArm('bare-source install (-File) creates dep link / plugin resolves / idempotent', `${PS1_PLATFORM_DETAIL}——同一断言面由下方 sh --local 臂承担`)
        }
        for (const host of (PS1_OFFLINE_APPLICABLE ? hosts : [])) {
          const run = () => runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(ROOT_DIR, 'install.ps1'), '-LocalPath', bareSrc], { env: { ...process.env, DSH_HOME: bareHome } })
          const first = await run()
          const depLinkOk = lstatOrUndefined(join(bareSrc, 'node_modules'))?.isSymbolicLink() === true
          const probeOk = await resolvePluginProbe(bareHome)
          const second = await run()
          const probeAgain = await resolvePluginProbe(bareHome)
          check(`bare-source install creates dep link on ${host}`, first.status === 0 && first.error === null && depLinkOk)
          check(`bare-source plugin resolves after install on ${host}`, probeOk.includes('RESOLVE-OK'))
          check(`bare-source install idempotent (dep link kept) on ${host}`, second.status === 0 && second.error === null && probeAgain.includes('RESOLVE-OK'))
        }
        // 6c-sh. POSIX 同守卫：install.sh --local 后依赖链接被创建且插件可解析。
        if (sh !== null) {
          const shBareHome = join(bareRoot, 'bare-dsh-home-sh')
          const shBareModules = join(shBareHome, 'profiles', 'node_modules')
          mkdirSync(shBareModules, { recursive: true })
          for (const dep of ['schemastery', 'dsh-tools', 'dsh-typert-protocol', 'dsh-llm']) {
            const pkgJson = createRequire(import.meta.url).resolve(`@deepseek-ai/${dep}/package.json`)
            const linkParent = join(shBareModules, '@deepseek-ai')
            mkdirSync(linkParent, { recursive: true })
            makeDirLink(dirname(pkgJson), join(linkParent, dep))
          }
          mkdirSync(join(shBareHome, 'profiles', 'web'), { recursive: true })
          const run = () => runCommand(sh, ['-c', `DSH_HOME='${shBareHome}' sh '${join(ROOT_DIR, 'install.sh')}' --local '${bareSrc}'`])
          const first = await run()
          const depLinkOk = lstatOrUndefined(join(bareSrc, 'node_modules'))?.isSymbolicLink() === true
          const probeOk = await resolvePluginProbe(shBareHome)
          const second = await run()
          const probeAgain = await resolvePluginProbe(shBareHome)
          check(`bare-source install (sh --local) creates dep link on ${sh}`, first.status === 0 && first.error === null && depLinkOk)
          check(`bare-source plugin resolves after install on ${sh}`, probeOk.includes('RESOLVE-OK'))
          check(`bare-source install (sh --local) idempotent on ${sh}`, second.status === 0 && second.error === null && probeAgain.includes('RESOLVE-OK'))
        }
        // 6d. 自带真实 node_modules 的源码：跳过依赖链接且不得改动用户目录。
        //     （独立拷贝顶层条目，避免继承 6c 在 bareSrc 里创建的依赖链接。）
        {
          const realNmSrc = join(bareRoot, 'real-nm-plugin')
          mkdirSync(realNmSrc, { recursive: true })
          for (const name of ['lib', 'install.ps1', 'install.sh', 'package.json', 'README.md', 'LICENSE', 'docs']) {
            const from = join(ROOT_DIR, name)
            if (existsSync(from)) cpSync(from, join(realNmSrc, name), { recursive: true })
          }
          mkdirSync(join(realNmSrc, 'node_modules'), { recursive: true })
          writeFileSync(join(realNmSrc, 'node_modules', 'user-marker.txt'), 'keep me')
          const realNmHome = join(bareRoot, 'real-nm-home')
          mkdirSync(join(realNmHome, 'profiles', 'node_modules'), { recursive: true })
          // FIX-038：`-File` 臂仅 win32 适用；非适用平台记可见 skip。理由串与同
          // 文件 `PS1_OFFLINE_APPLICABLE` JSDoc 同口径（FIX-040 N1）：install.sh
          // 同载该保护语义但**无对照臂**（已知覆盖缺口），不得表述为「平台不可判定」。
          if (!PS1_OFFLINE_APPLICABLE) {
            skipArm('real node_modules dir left untouched (-File)', `${PS1_PLATFORM_DETAIL}——install.sh 同载该保护语义但无对照臂（已知覆盖缺口，台账候选）`)
          }
          for (const host of (PS1_OFFLINE_APPLICABLE ? hosts : [])) {
            const run = () => runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(ROOT_DIR, 'install.ps1'), '-LocalPath', realNmSrc], { env: { ...process.env, DSH_HOME: realNmHome } })
            const result = await run()
            const nmStat = lstatOrUndefined(join(realNmSrc, 'node_modules'))
            const markerOk = existsSync(join(realNmSrc, 'node_modules', 'user-marker.txt'))
            const stillRealDir = nmStat?.isDirectory() === true && nmStat.isSymbolicLink() === false
            check(`real node_modules dir left untouched on ${host}`, result.status === 0 && markerOk && stillRealDir)
          }
        }
      } finally {
        removeTempDir(bareRoot)
      }
    }

    // ── 8. git 失败守卫：在线模式 git 失败必须立即中止───────────────
    // 回归目标：git clone 失败后旧脚本继续走 junction/robocopy，最终以误导性的
    // "robocopy 退出码 16" 收场且污染失败现场（用户实测报错）。修复后：
    // git 任一环节失败 → 清晰报错并退出，不创建任何链接/拷贝/补丁。
    {
      const gitRoot = bareRoot()
      try {
        const fakeGitRoot = join(gitRoot, 'fake-git')
        mkdirSync(fakeGitRoot, { recursive: true })
        // Windows fake git（.cmd shim 进入 PATH 首位）；POSIX 用同名 shell 脚本。
        writeFileSync(join(fakeGitRoot, 'git.cmd'), '@echo off\r\necho fatal: unable to access repo: simulated failure 1>&2\r\nexit /b 128\r\n')
        writeFileSync(join(fakeGitRoot, 'git'), '#!/bin/sh\necho "fatal: unable to access repo: simulated failure" >&2\nexit 128\n')
        if (process.platform !== 'win32') chmodSync(join(fakeGitRoot, 'git'), 0o755)
        const fakePath = `${fakeGitRoot}${process.platform === 'win32' ? ';' : ':'}${process.env.PATH ?? ''}`

        for (const host of hosts) {
          const failHome = join(fakeGitRoot, `fail-home-${host}`)
          const outFile = join(fakeGitRoot, `fail-out-${host}.txt`)
          const run = () => runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(ROOT_DIR, 'install.ps1')], { env: { ...process.env, DSH_HOME: failHome, PATH: fakePath }, outputFile: outFile })
          const result = await run()
          const output = existsSync(outFile) ? readFileSync(outFile, 'utf8') : ''
          const noLink = !existsSync(join(failHome, 'profiles', 'node_modules', 'dsh-agent-router'))
          const noPatch = !existsSync(join(failHome, 'profiles', 'web', 'cordis.patch.yml'))
          check(`git clone failure aborts install on ${host}`, result.status !== 0 && noLink && noPatch)
          check(`git clone failure reports clear error on ${host}`, output.includes('git clone 失败') && output.includes('离线安装'))
        }
        if (sh !== null) {
          const failHome = join(fakeGitRoot, 'fail-home-sh')
          const outFile = join(fakeGitRoot, 'fail-out-sh.txt')
          const run = () => runCommand(sh, ['-c', `DSH_HOME='${failHome}' PATH='${fakePath}' sh '${join(ROOT_DIR, 'install.sh')}'`], { outputFile: outFile })
          const result = await run()
          const output = existsSync(outFile) ? readFileSync(outFile, 'utf8') : ''
          const noLink = !existsSync(join(failHome, 'profiles', 'node_modules', 'dsh-agent-router'))
          const noPatch = !existsSync(join(failHome, 'profiles', 'web', 'cordis.patch.yml'))
          check(`git clone failure aborts install on ${sh}`, result.status !== 0 && noLink && noPatch)
          check(`git clone failure reports clear error on ${sh}`, output.includes('git clone 失败') && output.includes('离线安装'))
        }
        if (hosts.length > 0) {
          // git pull 失败同样中止（.git 已存在分支）。
          const host = hosts[0]
          const pullHome = join(fakeGitRoot, 'pull-home')
          mkdirSync(join(pullHome, 'plugins-src', 'dsh-agent-router', '.git'), { recursive: true })
          writeFileSync(join(pullHome, 'plugins-src', 'dsh-agent-router', 'package.json'), '{}')
          const outFile = join(fakeGitRoot, 'pull-out.txt')
          const run = () => runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(ROOT_DIR, 'install.ps1')], { env: { ...process.env, DSH_HOME: pullHome, PATH: fakePath }, outputFile: outFile })
          const result = await run()
          const output = existsSync(outFile) ? readFileSync(outFile, 'utf8') : ''
          const noLink = !existsSync(join(pullHome, 'profiles', 'node_modules', 'dsh-agent-router'))
          const noPatch = !existsSync(join(pullHome, 'profiles', 'web', 'cordis.patch.yml'))
          check('git fetch failure aborts install (existing checkout)', result.status !== 0 && noLink && noPatch)
          check('git fetch failure reports clear error', output.includes('git fetch 失败') && output.includes('离线安装'))
          // 正向后置：fake git 成功（exit 0 且不创建目录）→ 触发源码缺失拦截。
          writeFileSync(join(fakeGitRoot, 'git.cmd'), '@echo off\r\nexit /b 0\r\n')
          writeFileSync(join(fakeGitRoot, 'git'), '#!/bin/sh\nexit 0\n')
          if (process.platform !== 'win32') chmodSync(join(fakeGitRoot, 'git'), 0o755)
          const ghostHome = join(fakeGitRoot, 'ghost-home')
          const ghostOut = join(fakeGitRoot, 'ghost-out.txt')
          const ghostRun = () => runCommand(host, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(ROOT_DIR, 'install.ps1')], { env: { ...process.env, DSH_HOME: ghostHome, PATH: fakePath }, outputFile: ghostOut })
          const ghost = await ghostRun()
          const ghostOutput = existsSync(ghostOut) ? readFileSync(ghostOut, 'utf8') : ''
          check('ghost git clone (no source dir) aborts with missing-source error', ghost.status !== 0 && ghostOutput.includes('未生成源码目录') && !existsSync(join(ghostHome, 'profiles', 'node_modules', 'dsh-agent-router')))
        }
      } finally {
        removeTempDir(gitRoot)
      }
    }
  } finally {
    await server.close()
    removeTempDir(tmpDir)
  }
}

/** 仓库外临时目录（同裸源码守卫的 bareRoot 约定，避免仓库 dev junction 污染解析）。 */
function bareRoot() {
  const dir = join(ROOT_DIR, '..', `.test-home-git-${process.pid}-${Date.now()}`)
  mkdirSync(dir, { recursive: true })
  return dir
}
