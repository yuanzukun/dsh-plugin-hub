/**
 * dsh-agent-router 浏览器侧包（`./client`，dual-face 下发）。
 *
 * 单页签「Agent 路由」（settings.section list slot）。分级卡片布局：
 * - 总开关（唯一不折叠，置顶）；
 * - 三个顶层分类卡片（头部整行点击展开/收起，内部再嵌各自子卡片）：
 *   · 专业 Agent（核心区，前置且默认展开）：每卡默认折叠摘要（名称/
 *     类型/生效模型/简要用量），点击展开配置与明细统计；末尾「+」添加
 *     （图片识别/图片生成/翻译/语音识别/视频生成/通用子 Agent 预设）；
 *   · 多模态账号（默认折叠）：API Key 登录 + ChatGPT 订阅登录 + 子代理 +
 *     账号池四区（EVO-007：移除不可用的「OAuth 官方登录」入口——官方 API
 *     无 OAuth / Gemini 内置 Client 被禁；ChatGPT 订阅登录上移为一级醒目位，
 *     正式通道（DEC-026 C2 转正）优先呈现）；
 *   · 统计信息（默认折叠）：Agent 级与账号级（服务商）两级明细卡片
 *     （平均耗时、模型细分、分钟级 tokens 分布）+ 最近调用记录。
 *
 * wire 面：宿主客户端 typed remote 命名空间（llm/settings/credentials/
 * agentPresets/session——FIX-028 适配层收敛旧信封）+ 本包 $mount 的
 * `remote.router` namespace（catalog/stats/test/reset/config/save）。
 */
window.__ModuleLoader__.load({
  id: 'dsh-agent-router',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    let react = require('react')

    const el = react.createElement
    const { useState, useEffect, useCallback, useRef } = react

    // FIX-019：插件直选路由 provider id 单点镜像——浏览器包 client.js 经
    // __ModuleLoader__ 仅 require('react')，无 ESM 模块面，无法 import Node
    // ESM 模块 lib/oauth-llm.js；此值与 lib/oauth-llm.js `export const
    // OAUTH_PROVIDER = 'chatgpt-oauth'` 同构——lib/oauth-llm.js 是权威单点，
    // 本镜像必须随其同步（EVO-010 起主模型经插件路由的调用统计即按此 id 记账）。
    const OAUTH_ROUTE_PROVIDER = 'chatgpt-oauth'
    // FIX-019：宿主官方路由 provider id 单点镜像——权威单点自 EVO-022 B4 ①
    // 起为 lib/host-abi/version.js `export const HOST_ROUTE_PROVIDER =
    // 'openai-codex'`（P2-2 权威翻转：host-route.js 改 re-export）；EVO-010
    // 起插件把该条目维护进 llm-pi-ai settings → 宿主 llm 目录暴露为**真
    // provider**（7 个模型来自宿主官方目录；调用随宿主路由走，账号管理区不
    // 计）——配置归「设置 → 模型」，不得在 Agent 路由账号管理区渲染（用户 ⑤
    // 确认截图 sha256:9fa0908e 实证第三幽灵卡：已激活 · 7 个模型 · 调用 0）。
    // 两镜像值变更必须跟随权威单点。
    const HOST_ROUTE_ID = 'openai-codex'
    // FIX-015 + FIX-019：插件自注册 provider 判据——两语义面分开（host 路由
    // 不是 oauth 账号，各自独立演进）：
    //  · oauth 面（isPluginRouteProvider）：旧统计聚合键 `oauth:` 前缀（服务端
    //    record provider 形态，如 oauth:chatgpt，FIX-015）+ EVO-010 起无冒号
    //    插件路由 id（OAUTH_PROVIDER，前缀判据失效，用户实证「又出现了」红字
    //    假编辑器）；
    //  · 宿主路由面（isHostManagedRoute）：插件自动维护进 llm-pi-ai settings
    //    的 HOST_ROUTE_PROVIDER 条目（真 provider 形态，出现在 llm-pi-ai
    //    providers 目录，无法靠「不在 providers 里」过滤，须显式排除）。
    // isPluginSelfRegisteredProvider 组合谓词 = 渲染过滤**单点**：addedAccounts
    // 与 statsAccountRows 的全部来源（llm-pi-ai providers 目录 + 统计
    // accountTotals）只经它判定；新增路由形态仅改此地，禁止在过滤点重复
    // 展开条件（P5 单点化）。订阅登录真卡的「路由已维护」状态行（EVO-010
    // openaiCodexRoute）已承载宿主路由可见性——账号管理区零重复。
    const isPluginRouteProvider = (id) => typeof id === 'string' && (id.startsWith('oauth:') || id === OAUTH_ROUTE_PROVIDER)
    const isHostManagedRoute = (id) => typeof id === 'string' && id === HOST_ROUTE_ID
    const isPluginSelfRegisteredProvider = (id) => isPluginRouteProvider(id) || isHostManagedRoute(id)

    // ── FIX-031 统计归因显示层（DEC-029②「实现路径不可见」浏览器面单点）──────
    // 权威单点在 Node 侧 lib/stats.js（normalizeAttribution / accountDisplayLabel）：
    // 统计快照下发的账号与 agent 已是规范实体。此处是其**同构镜像 + 滚动升级
    // 兜底**（旧服务端/历史值仍可能带 `*-router` / `oauth:` / 'chatgpt-oauth' /
    // 'twin' / 'main' 形态），且**键→显示名**只经这一处，禁止在各渲染点重复
    // 展开条件（P5）。与权威单点的不漂移由 tests/fix-031-attribution.mjs G 组
    // 源码契约 + 值 parity 断言锁定（P-v3 原则 9）。
    const WRAP_ROUTE_SUFFIX = '-router'
    const MAIN_MODEL_AGENT_ID = 'main-model'

    /** 账号键 → 清洁显示键（与 lib/stats.js accountDisplayLabel 同构镜像：剥包装
     *  路由后缀与内部命名空间标记，输出实体 id）。 */
    function accountDisplayKeyOf(value) {
      let key = typeof value === 'string' ? value.trim() : ''
      while (key.length > WRAP_ROUTE_SUFFIX.length && key.endsWith(WRAP_ROUTE_SUFFIX)) key = key.slice(0, -WRAP_ROUTE_SUFFIX.length)
      if (key === OAUTH_ROUTE_PROVIDER) key = 'oauth:chatgpt'
      if (key.startsWith('oauth:pool:')) return key.slice('oauth:pool:'.length)
      if (key.startsWith('oauth:')) return key.slice('oauth:'.length)
      if (key.startsWith('cli:')) return key.slice('cli:'.length)
      return key
    }

    /** agent 键 → 规范 agent 键（内部实现 id 'twin'/'main' 折回主模型实体）。 */
    function agentDisplayKeyOf(value) {
      const id = typeof value === 'string' ? value.trim() : ''
      return !id || id === 'twin' || id === 'main' ? MAIN_MODEL_AGENT_ID : id
    }

    /**
     * 可见名单点（配置面 roster 解析）：账号/agent 规范键 → 用户配置名。
     * @param {string} kind 'provider' | 'oauth' | 'pool' | 'cli' | 'host-route' | 'agent'
     * @param {Map<string, string>} names 建键形态 `${kind}|${清洁键}`
     */
    function rosterDisplayName(names, kind, key) {
      if (!names || !key) return undefined
      return names.get(`${kind}|${key}`)
    }

    /**
     * 「服务商/模型」列与账号卡标题的显示名单点：账号清洁键优先（配置面名覆盖），
     * 无账号归属时回落 agent 词汇——主模型用用户语言「主模型」，专业 agent 用配置名。
     * 内部标记（`oauth:` / `pool:` / `-router` / 'twin' / 裸 'main'）永不直出
     * （DEC-029②）。
     * FIX-031 D6 回落：host-route 通路行在归并 resolver 不可用/账号未知时保持
     * 独立实体——标签出「宿主路由（账号未知）」而非冒充实体键/已知账号。
     */
    function statsProviderLabelOf(row, names, t) {
      const account = accountDisplayKeyOf(row?.provider)
      if (account && account !== '?') {
        if (row?.accountKind === 'host-route') return rosterDisplayName(names, 'host-route', account) ?? t('statsHostRouteAccount')
        return rosterDisplayName(names, row?.accountKind ?? 'provider', account) ?? account
      }
      const agentKey = agentDisplayKeyOf(row?.agentId)
      if (agentKey === MAIN_MODEL_AGENT_ID) return t('statsMainModel')
      return rosterDisplayName(names, 'agent', agentKey) ?? agentKey
    }

    /**
     * FIX-031 显示名单点（配置面 roster → 用户可见名）的**构建函数**（D10
     * 微批 8 提取为真函数——浏览器包 exports 面可测，G9-G12 先例）。建键
     * 形态 `${kind}|${清洁键}`——kind 参与键空间，provider 账号与同名 OAuth
     * 账号/池/子代理条目不会互相顶掉。
     *
     * D10（第三轮复验）：包装路由 twin 目录条目（provider 以
     * WRAP_ROUTE_SUFFIX 结尾——多模态接管变体，宿主目录 displayName 带
     * 「+ 多模态」类标记）是路由构件不是账号：剥后缀后与真实条目同键，
     * 后写入会顶掉真实显示名（用户实证「DeepSeek + 多模态」污染账号卡标题，
     * DEC-029② 实现路径不可见）——**排除而非覆盖序技巧**（twin 根本不入
     * roster，顺序无关）。宿主模型选择器里 twin 条目自身的「+ 多模态」标记
     * 是宿主 UX 功能指示（用户已认可），不经本函数、不受影响。
     * @param {Array} providers 宿主 llm providers 目录条目
     * @param {object} catalog 配置面目录（oauthAccounts/pools/cliAgents/agents）
     * @param {object} configuredAgents 设置草稿中的 agents 映射（agent 名兜底）
     * @returns {Map<string, string>} `${kind}|${清洁键}` → 显示名
     */
    function buildAccountNames(providers, catalog, configuredAgents) {
      const names = new Map()
      for (const entry of providers ?? []) {
        if (!entry || typeof entry.provider !== 'string' || !entry.displayName) continue
        if (entry.provider.endsWith(WRAP_ROUTE_SUFFIX)) continue
        names.set(`provider|${accountDisplayKeyOf(entry.provider)}`, entry.displayName)
      }
      for (const entry of catalog?.oauthAccounts ?? []) {
        if (entry && entry.id && entry.name) names.set(`oauth|${accountDisplayKeyOf(`oauth:${entry.id}`)}`, entry.name)
      }
      for (const entry of catalog?.pools ?? []) {
        if (entry && entry.id && entry.name) names.set(`pool|${accountDisplayKeyOf(`oauth:pool:${entry.id}`)}`, entry.name)
      }
      for (const entry of catalog?.cliAgents ?? []) {
        if (entry && entry.id && entry.name) names.set(`cli|${accountDisplayKeyOf(`cli:${entry.id}`)}`, entry.name)
      }
      for (const entry of catalog?.agents ?? []) {
        if (entry && entry.id && entry.name) names.set(`agent|${entry.id}`, entry.name)
      }
      for (const [id, agent] of Object.entries(configuredAgents ?? {})) {
        if (agent && agent.name && !names.has(`agent|${id}`)) names.set(`agent|${id}`, agent.name)
      }
      return names
    }


    // ── wire codecs（与宿主 lib/schemas.js 同形状的轻量校验器）──────────────
    function wireCheck(spec, value, path) {
      if (value === undefined || value === null) {
        if (spec.optional === true) return value
        throw new Error(`dsh-agent-router wire: ${path} is required`)
      }
      if (spec.kind === 'string') {
        if (typeof value !== 'string') throw new Error(`dsh-agent-router wire: ${path} must be a string`)
        return value
      }
      if (spec.kind === 'boolean') {
        if (typeof value !== 'boolean') throw new Error(`dsh-agent-router wire: ${path} must be a boolean`)
        return value
      }
      if (spec.kind === 'number') {
        if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error(`dsh-agent-router wire: ${path} must be a finite number`)
        return value
      }
      if (spec.kind === 'array') {
        if (!Array.isArray(value)) throw new Error(`dsh-agent-router wire: ${path} must be an array`)
        if (spec.items) for (let index = 0; index < value.length; index++) {
          const next = wireCheck(spec.items, value[index], `${path}[${index}]`)
          if (next !== undefined) value[index] = next
        }
        return value
      }
      if (spec.kind === 'object') {
        if (typeof value !== 'object' || Array.isArray(value)) throw new Error(`dsh-agent-router wire: ${path} must be an object`)
        if (spec.properties) for (const [key, child] of Object.entries(spec.properties)) {
          const childSpec = child && child.spec ? child.spec : child
          const next = wireCheck(childSpec, value[key], path === '' ? key : `${path}.${key}`)
          if (next !== undefined) value[key] = next
        }
        return value
      }
      return value
    }
    function wireNode(spec) {
      return { parse: (value) => wireCheck(spec, value, ''), spec }
    }
    const wv = {
      object: (properties, optional) => wireNode({ kind: 'object', properties, optional: optional === true }),
      array: (items, optional) => wireNode({ kind: 'array', items: items && items.spec ? items.spec : items, optional: optional === true }),
      string: (optional) => wireNode({ kind: 'string', optional: optional === true }),
      boolean: (optional) => wireNode({ kind: 'boolean', optional: optional === true }),
      number: (optional) => wireNode({ kind: 'number', optional: optional === true }),
    }
    const wEmpty = wv.object({})
    const wAgentId = wv.object({ agentId: wv.string() })
    // EVO-004 出口⑤导出按钮：statsExport RPC 请求/结果（与 lib/rpc.js 同构）。
    const wStatsExportRequest = wv.object({ range: wv.string(), level: wv.string() })
    const wStatsExportResult = wv.object({ ok: wv.boolean(), message: wv.string(), csv: wv.string(true) })
    const wCatalog = wv.object({
      ok: wv.boolean(), enabled: wv.boolean(),
      defaults: wv.object({ provider: wv.string(), model: wv.string(), reasoningEffort: wv.string(true) }),
      // FIX-018：主模型 image 能力判定（服务端单点下发，客户端贴图接管门控
      // 消费；可选——旧服务端缺省 = 客户端按「不判定」保守回落既有接管）。
      mainModelImage: wv.object({
        acceptsImage: wv.boolean(), source: wv.string(), provider: wv.string(), model: wv.string(),
      }, true),
      agents: wv.array(wv.object({
        id: wv.string(), name: wv.string(), type: wv.string(), enabled: wv.boolean(),
        description: wv.string(), capabilities: wv.array(wv.string()),
        provider: wv.string(), model: wv.string(), account: wv.string(), cliAgent: wv.string(true),
        effectiveProvider: wv.string(), effectiveModel: wv.string(), source: wv.string(),
        error: wv.string(true),
      })),
      oauthAccounts: wv.array(wv.object({
        id: wv.string(), name: wv.string(), enabled: wv.boolean(),
        protocol: wv.string(), baseURL: wv.string(), tokenRef: wv.string(),
        clientId: wv.string(), authUrl: wv.string(), tokenUrl: wv.string(), scope: wv.string(),
        models: wv.array(wv.string()),
        publicClient: wv.boolean(true),
        // EVO-002 Step 6：preset 镜像 + 登录态（可选——旧服务端缺省兼容）。
        preset: wv.string(true),
        presetLoggedIn: wv.boolean(true),
        // EVO-010：调用通路镜像（'host'|'plugin'，可选——旧服务端缺省兼容）。
        transport: wv.string(true),
      })),
      // EVO-010：宿主官方 openai-codex 路由维护状态（可选——旧服务端缺省兼容）。
      openaiCodexRoute: wv.object({
        maintained: wv.boolean(), ref: wv.string(), accountId: wv.string(),
        tokenInjected: wv.string(), degraded: wv.boolean(), failures: wv.number(),
        notice: wv.string(true),
      }, true),
      pools: wv.array(wv.object({
        id: wv.string(), name: wv.string(), enabled: wv.boolean(), strategy: wv.string(),
        accounts: wv.array(wv.string()),
        accountHealth: wv.array(wv.object({
          accountId: wv.string(), calls: wv.number(), errors: wv.number(), lastAt: wv.number(true),
        })),
      }), true),
      cliAgents: wv.array(wv.object({
        id: wv.string(), name: wv.string(), enabled: wv.boolean(),
        command: wv.string(), args: wv.string(),
        timeoutMs: wv.number(), maxConcurrent: wv.number(),
      }), true),
    })
    const wBucket = wv.object({
      minute: wv.string(), calls: wv.number(), errors: wv.number(),
      inputTokens: wv.number(), outputTokens: wv.number(),
    })
    const wStats = wv.object({
      ok: wv.boolean(), enabled: wv.boolean(),
      totals: wv.array(wv.object({
        agentId: wv.string(), name: wv.string(), provider: wv.string(), model: wv.string(),
        calls: wv.number(), errors: wv.number(), inputTokens: wv.number(), outputTokens: wv.number(),
        totalMs: wv.number(), lastAt: wv.number(true),
      })),
      recent: wv.array(wv.object({
        at: wv.number(), agentId: wv.string(), provider: wv.string(), model: wv.string(),
        ok: wv.boolean(), ms: wv.number(), inputTokens: wv.number(true), outputTokens: wv.number(true),
        error: wv.string(true),
      })),
      series: wv.array(wv.object({ agentId: wv.string(), buckets: wv.array(wBucket) })),
      accountTotals: wv.array(wv.object({
        provider: wv.string(),
        // FIX-031：归一化实体种类（provider/oauth/pool/cli/host-route/unknown）+
        // 双权威源计数分解（可选——旧服务端缺省 = 客户端按 provider 判据回退）。
        accountKind: wv.string(true),
        requestCalls: wv.number(true),
        callRows: wv.number(true),
        calls: wv.number(), errors: wv.number(), inputTokens: wv.number(), outputTokens: wv.number(),
        totalMs: wv.number(), lastAt: wv.number(true),
        models: wv.array(wv.object({
          model: wv.string(),
          calls: wv.number(), errors: wv.number(), inputTokens: wv.number(), outputTokens: wv.number(),
          totalMs: wv.number(), lastAt: wv.number(true),
        })),
      })),
      accountSeries: wv.array(wv.object({ provider: wv.string(), buckets: wv.array(wBucket) })),
    })
    const wTest = wv.object({
      ok: wv.boolean(), message: wv.string(), latencyMs: wv.number(true),
      usage: wv.object({
        inputTokens: wv.number(true), outputTokens: wv.number(true),
        cacheReadTokens: wv.number(true), cacheWriteTokens: wv.number(true), reasoningTokens: wv.number(true),
      }, true),
    })
    const wReset = wv.object({ ok: wv.boolean() })
    const wConfig = wv.object({
      ok: wv.boolean(), enabled: wv.boolean(), revision: wv.number(), writable: wv.boolean(),
      value: wv.object({}), user: wireNode({ kind: 'json', optional: true }),
    })
    const wSaveRequest = wv.object({
      ops: wv.array(wv.object({
        op: wv.string(), path: wv.array(wv.string()),
        value: wireNode({ kind: 'json', optional: true }),
      })),
      expectedRevision: wv.number(true),
    })
    const wSaveResult = wv.object({
      ok: wv.boolean(), revision: wv.number(),
      user: wireNode({ kind: 'json', optional: true }),
    })
    const wOauthBeginRequest = wv.object({ accountId: wv.string(), redirectUri: wv.string() })
    const wOauthBeginResult = wv.object({ ok: wv.boolean(), message: wv.string(), authUrl: wv.string(true), state: wv.string(true), mode: wv.string(true), userCode: wv.string(true), verificationUrl: wv.string(true), intervalSeconds: wv.number(true), expiresIn: wv.number(true) })
    const wOauthExchangeRequest = wv.object({
      code: wv.string(), state: wv.string(true),
      accountId: wv.string(true), codeVerifier: wv.string(true), redirectUri: wv.string(true),
    })
    const wOauthExchangeResult = wv.object({ ok: wv.boolean(), message: wv.string(), expiresIn: wv.number(true) })
    const wOauthDiscoverRequest = wv.object({ accountId: wv.string() })
    const wOauthDiscoverResult = wv.object({ ok: wv.boolean(), message: wv.string(), models: wv.array(wv.string()) })
    // EVO-002 Step 6：preset 账号登出（§3.6 凭据删除路径 / W-5）。
    const wOauthLogoutRequest = wv.object({ accountId: wv.string() })
    const wOauthLogoutResult = wv.object({ ok: wv.boolean(), message: wv.string() })
    const wCliStatusResult = wv.object({ ok: wv.boolean(), message: wv.string(), loggedIn: wv.boolean(true) })
    const wCliLoginResult = wv.object({ ok: wv.boolean(), message: wv.string() })
    const wCliModelsResult = wv.object({ ok: wv.boolean(), message: wv.string(), models: wv.array(wv.string()), source: wv.string(true) })
    const wImageDataRequest = wv.object({
      ref: wv.object({
        attachmentId: wv.string(), mediaType: wv.string(), bytes: wv.number(),
        width: wv.number(), height: wv.number(), name: wv.string(true),
      }),
    })
    const wImageDataResult = wv.object({
      ok: wv.boolean(), message: wv.string(), code: wv.string(true),
      mediaType: wv.string(true), data: wv.string(true), width: wv.number(true), height: wv.number(true), name: wv.string(true),
    })
    const wUploadFileRequest = wv.object({ name: wv.string(), mediaType: wv.string(), dataBase64: wv.string() })
    const wUploadFileResult = wv.object({
      ok: wv.boolean(), path: wv.string(true), attachmentId: wv.string(true),
      name: wv.string(true), message: wv.string(true), code: wv.string(true),
    })
    const wReadWorkspaceFileRequest = wv.object({ path: wv.string() })
    const wReadWorkspaceFileResult = wv.object({
      ok: wv.boolean(), dataBase64: wv.string(true), mediaType: wv.string(true),
      name: wv.string(true), message: wv.string(true), code: wv.string(true),
    })
    // FIX-046 返工（根因确证，EV-217）：观测面两条结果的客户端 codec——
    // 此前 $mount 列表缺这两条 descriptor ⇒ `remote.router.presetDiagnostics` /
    // `remote.router.hostFaceDiagnostics` **不存在** ⇒ 设置页宿主面健康面板的
    // 版本/诊断面被静默跳过（真机 `host-face-shape: hostFaceDiagnostics`）。
    // 形状权威 = lib/schemas.js 的 `presetDiagnosticsResult`（FIX-030-C）与
    // `hostFaceDiagnosticsResult`（ARCH-004 B1；face 条目 `faceHealthCodec`、
    // diag 条目 `hostDiagEntryCodec`）——本处为浏览器镜像（本包经
    // __ModuleLoader__ 仅 require('react')，无 ESM 模块面，无法 import）；形状
    // 漂移由 tests/rpc-shadow-guard.mjs 的双侧 descriptor id 集合 + codec
    // schema 深度等价守卫看护。**FIX-047（N-5）限定语（禁超宣示）**：该深等判据
    // 只覆盖两侧**手写 spec 的文本等价**（本包 `wv` 家族 vs lib/schemas.js `v`
    // 家族），**不覆盖**两侧校验器实现（本包 `wireCheck` vs lib/schemas.js
    // `check`）的行为等价，也不覆盖宿主 `$mount` 的 codec 消费面（本仓不可核验）。
    const wPresetDiagEntry = wv.object({
      at: wv.number(), kind: wv.string(), applied: wv.boolean(),
      preset: wv.string(), session: wv.string(),
      target: wv.object({ provider: wv.string(), model: wv.string() }, true),
      skip: wv.string(true), detail: wv.string(true),
    })
    const wPresetDiagnosticsResult = wv.object({ entries: wv.array(wPresetDiagEntry) })
    const wFaceHealth = wv.object({ name: wv.string(), state: wv.string(), detail: wv.string(true) })
    const wHostDiagEntry = wv.object({
      at: wv.number(), kind: wv.string(),
      face: wv.string(true), consumer: wv.string(true), code: wv.string(true), detail: wv.string(true),
    })
    // ARCH-005 R2：协商三态 codec（lib/schemas.js capabilityProfileCodec 的浏览器
    // 镜像——codec 必填，双侧同形由 rpc-shadow-guard 深等判据锁定）。旧服务端
    // 容忍不经本 codec（$mount descriptor 无 decode/网关结果直通），由渲染层
    // null-guard 承载（HostHealthCard capability 判空回落两态口径——返工 F-3：
    // 原「可选字段」注释把容忍机制误归于 codec optional 位）。
    const wCapabilityProfile = wv.object({ state: wv.string(), baselineId: wv.string() })
    const wHostFaceDiagnosticsResult = wv.object({
      // 版本三键为**必填**（lib/schemas.js 同形）：结果缺 hostVersions 时
      // 客户端按 `host-face-result-shape` 显式诊断，不再静默回落为 '?'。
      hostVersions: wv.object({ llm: wv.string(), tools: wv.string(), typertProtocol: wv.string() }),
      faces: wv.array(wFaceHealth),
      diag: wv.array(wHostDiagEntry),
      capabilityProfile: wCapabilityProfile,
    })

    // ── Remote 契约（与宿主 lib/rpc.js 一致）────────────────────────────────
    // ARCH-005 A2（HD-003）：strict codec 单点产出 `{create: () => schema}` 惰性
    // 工厂——宿主 0.2.0 validateCodec 对无 create() 的 strict codec 直接 throw
    // （typert-registry :565），$mount 侧同样过此门（镜像单点 = lib/rpc.js
    // strictCodec）。
    function strictCodec(name, schema) {
      return { mode: 'strict', typeSymbol: `dsh-agent-router/types#${name}`, create: () => schema }
    }
    function parameter(name, schema) {
      return { name, wire: name, source: 'json', codec: strictCodec(name, schema) }
    }
    function resultOf(name, schema) {
      return strictCodec(name, schema)
    }
    const ROUTER_REMOTE = {
      package: 'dsh-agent-router',
      descriptors: [
        { id: 'dsh-agent-router#router/catalog', service: 'router', namespace: 'router', method: 'catalog', invocation: { kind: 'direct' }, parameters: [parameter('request', wEmpty)], result: resultOf('CatalogResult', wCatalog) },
        { id: 'dsh-agent-router#router/stats', service: 'router', namespace: 'router', method: 'stats', invocation: { kind: 'direct' }, parameters: [parameter('request', wEmpty)], result: resultOf('StatsResult', wStats) },
        // FIX-046 返工（EV-217 根因）：descriptor 集合曾为**两份事实源**——服务端
        // lib/rpc.js 的 ROUTER_DESCRIPTORS 19 条、本 $mount 列表 17 条，缺此两条
        // ⇒ 浏览器侧 remote.router 少注册两个方法（宿主的 $mount 按本列表注册，
        // 与宿主 ROUTER_DESCRIPTORS 无关）。同一动作必须只有一处事实源，故本列表
        // 与服务端逐条对齐（id/method/parameters/result 形状同构：emptyRequest
        // 请求 + presetDiagnosticsResult / hostFaceDiagnosticsResult 结果）。
        // 防再分叉：tests/rpc-shadow-guard.mjs 的双侧 id 集合 + codec 等价守卫
        // （任一单侧增删即判红）。
        { id: 'dsh-agent-router#router/presetDiagnostics', service: 'router', namespace: 'router', method: 'presetDiagnostics', invocation: { kind: 'direct' }, parameters: [parameter('request', wEmpty)], result: resultOf('PresetDiagnosticsResult', wPresetDiagnosticsResult) },
        { id: 'dsh-agent-router#router/hostFaceDiagnostics', service: 'router', namespace: 'router', method: 'hostFaceDiagnostics', invocation: { kind: 'direct' }, parameters: [parameter('request', wEmpty)], result: resultOf('HostFaceDiagnosticsResult', wHostFaceDiagnosticsResult) },
        { id: 'dsh-agent-router#router/statsExport', service: 'router', namespace: 'router', method: 'statsExport', invocation: { kind: 'direct' }, parameters: [parameter('request', wStatsExportRequest)], result: resultOf('StatsExportResult', wStatsExportResult) },
        { id: 'dsh-agent-router#router/test', service: 'router', namespace: 'router', method: 'test', invocation: { kind: 'direct' }, parameters: [parameter('request', wAgentId)], result: resultOf('TestResult', wTest) },
        { id: 'dsh-agent-router#router/reset', service: 'router', namespace: 'router', method: 'reset', invocation: { kind: 'direct' }, parameters: [parameter('request', wEmpty)], result: resultOf('ResetResult', wReset) },
        { id: 'dsh-agent-router#router/config', service: 'router', namespace: 'router', method: 'config', invocation: { kind: 'direct' }, parameters: [parameter('request', wEmpty)], result: resultOf('ConfigResult', wConfig) },
        { id: 'dsh-agent-router#router/save', service: 'router', namespace: 'router', method: 'save', invocation: { kind: 'direct' }, parameters: [parameter('request', wSaveRequest)], result: resultOf('SaveResult', wSaveResult) },
        { id: 'dsh-agent-router#router/oauthTokenExchange', service: 'router', namespace: 'router', method: 'oauthTokenExchange', invocation: { kind: 'direct' }, parameters: [parameter('request', wOauthExchangeRequest)], result: resultOf('OauthTokenExchangeResult', wOauthExchangeResult) },
        { id: 'dsh-agent-router#router/oauthBegin', service: 'router', namespace: 'router', method: 'oauthBegin', invocation: { kind: 'direct' }, parameters: [parameter('request', wOauthBeginRequest)], result: resultOf('OauthBeginResult', wOauthBeginResult) },
        { id: 'dsh-agent-router#router/oauthDiscover', service: 'router', namespace: 'router', method: 'oauthDiscover', invocation: { kind: 'direct' }, parameters: [parameter('request', wOauthDiscoverRequest)], result: resultOf('OauthDiscoverResult', wOauthDiscoverResult) },
        { id: 'dsh-agent-router#router/oauthLogout', service: 'router', namespace: 'router', method: 'oauthLogout', invocation: { kind: 'direct' }, parameters: [parameter('request', wOauthLogoutRequest)], result: resultOf('OauthLogoutResult', wOauthLogoutResult) },
        { id: 'dsh-agent-router#router/cliStatus', service: 'router', namespace: 'router', method: 'cliStatus', invocation: { kind: 'direct' }, parameters: [parameter('request', wAgentId)], result: resultOf('CliStatusResult', wCliStatusResult) },
        { id: 'dsh-agent-router#router/cliLogin', service: 'router', namespace: 'router', method: 'cliLogin', invocation: { kind: 'direct' }, parameters: [parameter('request', wAgentId)], result: resultOf('CliLoginResult', wCliLoginResult) },
        { id: 'dsh-agent-router#router/cliModels', service: 'router', namespace: 'router', method: 'cliModels', invocation: { kind: 'direct' }, parameters: [parameter('request', wAgentId)], result: resultOf('CliModelsResult', wCliModelsResult) },
        { id: 'dsh-agent-router#router/imageData', service: 'router', namespace: 'router', method: 'imageData', invocation: { kind: 'direct' }, parameters: [parameter('request', wImageDataRequest)], result: resultOf('ImageDataResult', wImageDataResult) },
        { id: 'dsh-agent-router#router/uploadFile', service: 'router', namespace: 'router', method: 'uploadFile', invocation: { kind: 'direct' }, parameters: [parameter('request', wUploadFileRequest)], result: resultOf('UploadFileResult', wUploadFileResult) },
        { id: 'dsh-agent-router#router/readWorkspaceFile', service: 'router', namespace: 'router', method: 'readWorkspaceFile', invocation: { kind: 'direct' }, parameters: [parameter('request', wReadWorkspaceFileRequest)], result: resultOf('ReadWorkspaceFileResult', wReadWorkspaceFileResult) },
      ],
    }

    // ── 样式 ────────────────────────────────────────────────────────────────
    const CSS = `
.dshrouter-section{max-width:760px;display:flex;flex-direction:column;gap:12px;color:var(--dsw-alias-label-primary)}
.dshrouter-title{margin:0;font-size:16px;font-weight:500;line-height:24px}
.dshrouter-subtitle{margin:0;font-size:13px;font-weight:500;line-height:20px}
.dshrouter-intro{margin:0;font-size:14px;line-height:22px;color:var(--dsw-alias-label-tertiary)}
.dshrouter-error{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;margin:0}
.dshrouter-ok{color:var(--dsw-alias-state-success-primary);font-size:12px;line-height:18px;margin:0}
/* ARCH-005 R2：unknown 协商态黄徽章——宿主 token 实读锚（dsh-client-ui-cordis /
   dsh-client-ui-conversation bundle 的 var(--dsw-alias-state-business-primary) 引用
   形态，2026-10-17 只读探针）+ 字面回落（token 缺失环境不裸失效——P9 防御）。 */
.dshrouter-warn{color:var(--dsw-alias-state-business-primary,#b45309);font-size:12px;line-height:18px;margin:0}
.dshrouter-hint{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;margin:0}
.dshrouter-card{border:1px solid rgba(140,140,140,.45);border:1px solid color-mix(in srgb,currentColor 26%,transparent);border-radius:12px;padding:12px 14px;display:flex;flex-direction:column;gap:10px}
.dshrouter-card.disabled{opacity:.55}
.dshrouter-card-head{display:flex;align-items:center;gap:8px;width:100%;background:none;border:none;padding:0;font:inherit;color:inherit;cursor:pointer;text-align:left}
.dshrouter-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.dshrouter-head{display:flex;align-items:center;gap:8px}
.dshrouter-name{font-size:14px;font-weight:500;line-height:22px}
.dshrouter-id{color:var(--dsw-alias-label-secondary);font-size:12px;border:1px solid var(--dsw-alias-border-l3);border-radius:4px;padding:0 6px}
.dshrouter-tag{color:var(--dsw-alias-label-secondary);font-size:11px;line-height:16px;border:1px solid var(--dsw-alias-border-l3);border-radius:4px;padding:0 6px}
.dshrouter-spacer{flex:1}
.dshrouter-chevron{color:var(--dsw-alias-label-tertiary);font-size:12px;flex:none}
.dshrouter-field{display:flex;flex-direction:column;gap:4px;min-width:200px;flex:1}
.dshrouter-field-label{font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary)}
.dshrouter-input,.dshrouter-select,.dshrouter-textarea{box-sizing:border-box;width:100%;font:inherit;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-input,transparent);border:1px solid var(--dsw-alias-border-l3);border-radius:8px;padding:6px 10px;outline:none}
.dshrouter-textarea{resize:vertical;min-height:56px}
.dshrouter-input:focus,.dshrouter-select:focus,.dshrouter-textarea:focus{border-color:var(--dsw-alias-button-primary-fill)}
.dshrouter-button{box-sizing:border-box;height:32px;font:inherit;font-size:13px;line-height:20px;cursor:pointer;border:none;border-radius:16px;padding:0 14px;display:inline-flex;align-items:center;gap:4px;background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground)}
.dshrouter-button:hover:not(:disabled){filter:brightness(1.08)}
.dshrouter-button:disabled{opacity:.5;cursor:not-allowed}
.dshrouter-button.ghost{background:transparent;color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l3)}
.dshrouter-button.danger{background:transparent;color:var(--dsw-alias-state-error-primary);border:1px solid var(--dsw-alias-state-error-primary)}
.dshrouter-chip{box-sizing:border-box;height:28px;font:inherit;font-size:12px;line-height:18px;cursor:pointer;border:1px solid var(--dsw-alias-border-l3);border-radius:14px;padding:0 12px;display:inline-flex;align-items:center;gap:4px;background:transparent;color:var(--dsw-alias-label-primary)}
.dshrouter-chip:hover{border-color:var(--dsw-alias-button-primary-fill)}
.dshrouter-chip.active{border-color:var(--dsw-alias-button-primary-fill);background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground)}
.dshrouter-dot{width:8px;height:8px;border-radius:50%;display:inline-block;flex:none;background:#6f7280;vertical-align:middle}
.dshrouter-dot.ok{background:var(--dsw-alias-state-success-primary)}
.dshrouter-dot.bad{background:var(--dsw-alias-state-error-primary)}
.dshrouter-meta{font-size:12px;color:var(--dsw-alias-label-tertiary);line-height:18px}
.dshrouter-stats{border-top:1px solid rgba(140,140,140,.35);border-top:1px solid color-mix(in srgb,currentColor 20%,transparent);padding-top:8px;display:flex;flex-direction:column;gap:6px}
.dshrouter-table{width:100%;border-collapse:collapse;font-size:12px;line-height:18px}
.dshrouter-table th,.dshrouter-table td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--dsw-alias-border-l3)}
.dshrouter-table th{color:var(--dsw-alias-label-secondary);font-weight:500}
.dshrouter-table-row{cursor:pointer}
.dshrouter-table-row:hover td{background:var(--dsw-alias-bg-hover,rgba(255,255,255,.04))}
.dshrouter-bars{display:flex;align-items:flex-end;gap:2px;height:44px;padding:2px 0}
.dshrouter-bar{flex:1;min-width:2px;background:var(--dsw-alias-button-primary-fill);border-radius:1px 1px 0 0;opacity:.85}
.dshrouter-bar.err{background:var(--dsw-alias-state-error-primary)}
.dshrouter-modal{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.4);z-index:1000}
.dshrouter-modal-body{background:var(--dsw-alias-bg-overlay,#1b1d24);border:1px solid var(--dsw-alias-border-l2);border-radius:12px;padding:16px;min-width:360px;max-width:560px;max-height:70vh;overflow:auto;display:flex;flex-direction:column;gap:10px}
.dshrouter-modal-title{margin:0;font-size:14px;font-weight:500}
.dshrouter-candidate{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:8px;cursor:pointer;font-size:13px}
.dshrouter-candidate:hover{background:var(--dsw-alias-bg-hover, rgba(255,255,255,.06))}
.dshrouter-switch{display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:13px}
.dshrouter-switch input{width:14px;height:14px}
.dshrouter-add{display:flex;align-items:center;justify-content:center;gap:6px;border:1px dashed rgba(140,140,140,.5);border:1px dashed color-mix(in srgb,currentColor 30%,transparent);border-radius:12px;padding:14px;cursor:pointer;color:var(--dsw-alias-label-secondary);font-size:13px}
.dshrouter-add:hover{border-color:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary)}
.dshrouter-divider{border:none;border-top:1px solid rgba(140,140,140,.35);border-top:1px solid color-mix(in srgb,currentColor 20%,transparent);margin:4px 0}
.dshrouter-category{border:1px solid rgba(140,140,140,.45);border:1px solid color-mix(in srgb,currentColor 26%,transparent);border-radius:12px;display:flex;flex-direction:column}
.dshrouter-category-head{display:flex;align-items:center;gap:10px;width:100%;background:none;border:none;padding:12px 14px;font:inherit;color:inherit;cursor:pointer;text-align:left}
.dshrouter-category-head:hover{background:var(--dsw-alias-bg-hover,rgba(255,255,255,.03))}
.dshrouter-category-title{font-size:14px;font-weight:500;line-height:22px}
.dshrouter-category-body{border-top:1px solid rgba(140,140,140,.35);border-top:1px solid color-mix(in srgb,currentColor 20%,transparent);padding:12px 14px;display:flex;flex-direction:column;gap:10px}
/* 多模态展示辅助：composer 附件按钮 / route_agent 工具卡片 */
.dshrouter-attach{box-sizing:border-box;width:28px;height:28px;border:1px solid transparent;border-radius:8px;background:transparent;color:var(--dsw-alias-label-secondary);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;flex:none;font-size:15px;line-height:1}
.dshrouter-attach:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.dshrouter-attach:disabled{opacity:.5;cursor:not-allowed}
.dshrouter-attachcard{box-sizing:border-box;display:inline-flex;align-items:center;gap:4px;max-width:240px;font-size:12px;line-height:16px;color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l3);border-radius:8px;padding:2px 8px;background:var(--dsw-alias-bg-base,transparent);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:default}
.dshrouter-toolcard{border:1px solid var(--dsw-alias-border-l2);border-radius:12px;padding:10px 12px;display:flex;flex-direction:column;gap:8px;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);min-width:0}
/* EVO-012：route_agent 卡片默认折叠——摘要行（标题+状态+耗时+展开箭头，参考
宿主 Think 条目交互）与折叠态缩略图（url 直达）。 */
.dshrouter-toolcard-summary{display:flex;align-items:center;gap:8px;width:100%;min-width:0;background:none;border:none;padding:0;font:inherit;color:inherit;cursor:pointer;text-align:left}
.dshrouter-toolcard-summary:hover{opacity:.85}
.dshrouter-toolcard-chevron{flex:none;font-size:12px;line-height:16px;color:var(--dsw-alias-label-tertiary)}
.dshrouter-toolcard-thumbs{display:flex;flex-wrap:wrap;gap:8px}
.dshrouter-toolthumb{display:block;width:48px;height:48px;border:1px solid var(--dsw-alias-border-l3);border-radius:6px;background:var(--dsw-alias-bg-base,transparent);object-fit:cover;cursor:zoom-in}
.dshrouter-toolthumb:hover{opacity:.9}
/* EVO-012：展开态正文容器（内部分组与卡片 gap 语义一致）。 */
.dshrouter-toolcard-body{display:flex;flex-direction:column;gap:8px}
.dshrouter-toolcard-head{display:flex;align-items:center;gap:8px}
.dshrouter-toolcard-title{font-size:13px;font-weight:500}
.dshrouter-toolimages{display:flex;flex-wrap:wrap;gap:8px}
.dshrouter-toolgallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px}
.dshrouter-toolimage{display:block;border:1px solid var(--dsw-alias-border-l3);border-radius:8px;background:var(--dsw-alias-bg-base,transparent);object-fit:cover;width:160px;height:160px;cursor:zoom-in}
.dshrouter-toolimage:hover{opacity:.9}
.dshrouter-tooltext{white-space:pre-wrap;word-break:break-word;color:var(--dsw-alias-label-primary)}
/* EVO-012 批二 C：会话产物集合视图（输入区按钮 → 网格 → 单图放大）。 */
.dshrouter-gallery{display:inline-flex;align-items:center}
.dshrouter-gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px}
.dshrouter-gallery-cell{display:block;padding:0;border:none;background:none;cursor:zoom-in;border-radius:8px}
.dshrouter-gallery-image{display:block;width:100%;height:120px;object-fit:cover;border:1px solid var(--dsw-alias-border-l3);border-radius:8px;background:var(--dsw-alias-bg-base,transparent)}
.dshrouter-gallery-image:hover{opacity:.9}
.dshrouter-toolmeta{font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary)}
.dshrouter-toolerror{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px}
.dshrouter-toolfile{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-width:0}
.dshrouter-toolpath{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;line-height:16px;color:var(--dsw-alias-label-secondary);word-break:break-all;white-space:pre-wrap}
.dshrouter-toolmedia{max-width:100%;border-radius:8px;background:var(--dsw-alias-bg-base,transparent)}
`
    const CSS_ID = 'dsh-agent-router'
    if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css=' + JSON.stringify(CSS_ID) + ']') === null) {
      const tag = document.createElement('style')
      tag.dataset.plugin = 'dsh-agent-router'
      tag.dataset.pluginCss = CSS_ID
      tag.textContent = CSS
      document.head.appendChild(tag)
    }

    // ── 文案 ────────────────────────────────────────────────────────────────
    const zh = {
      nav: 'Agent 路由',
      title: '多模型路由',
      intro: '为不同能力配置专业 agent（图片识别、图片生成、翻译、语音识别等），每个 agent 可选独立服务商与模型；未配置时自动复用主 agent 模型。四张分类卡片（专业 Agent / 预设 Agent / 多模态账号 / 统计信息）均默认折叠——点击分类卡片标题展开或收起。',
      masterSwitch: '启用多模型路由',
      masterHint: '关闭后 route_agent 工具将拒绝调用，提示段与统计暂停；组合层可通过禁用 dsh-agent-router 行整体关闭插件。',
      accountTitle: '多模态账号管理',
      accountSummary: (n) => `已配置 ${n} 个账号`,
      accountIntro: '为任意服务商配置 API Key（官方服务商、第三方中转与本地部署均可；ChatGPT/Claude/Grok/Gemini 订阅 plan 可用其官方 API Key）。',
      accountOAuth: '说明：harness 模型适配层目前仅支持 API Key 认证，官方 OAuth 登录流暂不在支持范围；登录后该服务商模型会立即出现在上方模型列表中，账号与模型的具体配置与「设置 → 模型」页同源。',
      accountAddHint: '配置式添加（与「设置 → 模型」模型基座同款逻辑）：适用于任意服务商——官方服务商填官方 Base URL 与 API Key，未集成服务商 / 第三方中转 / 本地部署（Ollama / One-API / LM Studio 等）填对应端点。保存后服务商立即注册到共享模型列表；模型留空时保存会自动从端点拉取并写入（同名内置服务商除外），也可在 Agent 配置中用「发现模型」拉取端点模型。',
      fieldProviderId: '服务商 ID（如 openai / my-gateway / one-api；已存在同名服务商时保存将覆盖其配置）',
      accountApi: '接口类型',
      accountModelsField: '模型（可选，逗号分隔；自定义服务商留空则保存时自动从端点拉取）',
      accountKeyOptional: 'API Key（可选：本地部署/免鉴权中转可留空）',
      accountBaseUrlRequired: 'Base URL（必填，如 http://127.0.0.1:11434/v1）',
      accountAddProvider: '添加提供方',
      accountCustom: '＋ 自定义',
      accountProvider: '服务商',
      accountKey: 'API Key',
      accountBaseUrl: 'Base URL（可选，覆盖默认端点，如代理网关）',
      accountDone: '已配置',
      accountMissing: '未配置',
      accountActive: '已激活',
      accountDormant: '未激活',
      accountList: '已配置账号',
      addAccount: '添加账号',
      accountEditTitle: '编辑配置',
      accountEditHint: '修改 Base URL 或 API Key 后点「保存」（Key 留空 = 保持原凭据；Base URL 不能为空）。',
      accountKeyKeep: '留空 = 保持原 Key',
      accountNoBaseUrlWarn: '该自定义服务商未配置 Base URL：缺少它会使整个模型目录失效（内置服务商无需填写）。请补全后保存。',
      accountCatalogEmptyWarn: '模型目录整体为空：通常由某个账号的无效配置引起（缺少 Base URL 的自定义服务商会使整个 llm-pi-ai 目录失效）。请逐个展开账号，为缺少 Base URL 的补全并保存。',
      accountDelete: '删除账号',
      accountModelsTitle: '模型列表',
      accountConfirmDelete: '确认删除该账号？（将移除该服务商的配置与凭据）',
      accountModels: '个模型',
      accountDiscoverFailed: '未能从端点拉取模型',
      accountModelsRequiredHint: '自定义服务商必须在模型列表中配置至少一个模型 id：请检查 Base URL / API Key 与网络后重试，或手工填写模型列表',
      accountDiscoverEmpty: '端点未返回任何模型：请手工填写模型 id，或检查端点地址是否正确',
      accountModelsKept: '已保留现有模型列表：自定义服务商必须列出模型才能生效，如需清空请改为手工填写',
      accountDiscovered: (n) => `已从端点自动发现并保存 ${n} 个模型`,
      oauthPopupBlocked: '浏览器拦截了弹窗，请允许本页弹出窗口后重试。',
      oauthWaiting: '已打开授权页：请在弹窗中完成授权，登录状态将自动刷新。',
      oauthExpired: '等待授权超时，请重新发起。',
      oauthAutoDiscovering: '授权成功：正在自动发现模型…',
      advancedLogin: '账号与登录设置',
      oauthNeedRestart: '一键授权需要 DSH 重启后生效（宿主侧新增回调端点）。',
      poolTitle: '账号池',
      poolIntro: '把多个已授权账号组成池：调用时按策略自动选择账号（健康优先 / 用量最低 / 轮询），单个账号失败自动切换到下一个。agent 的「OAuth 账号」可指向池。',
      poolSummary: (n) => `${n} 个账号池`,
      poolStrategy: '选号策略',
      poolStrategyHealthy: '健康优先（失败最少）',
      poolStrategyUsage: '用量最低优先',
      poolStrategyRoundRobin: '轮询',
      poolAccounts: '池内账号',
      poolAddAccount: '从已授权账号添加',
      poolRemove: '移出',
      poolNoAccounts: '池内还没有账号：从下方下拉选择已授权账号加入，或对账号执行「一键授权登录」后再加入。',
      poolAddPlaceholder: '新池 id（如 gemini-pool）',
      addPool: '添加账号池',
      poolDelete: '删除池',
      poolConfirmDelete: '确认删除该账号池？',
      // F-1（EVO-007 R0 返工）：池行/孤儿列表的账号删除入口——非 preset
      // OAuth 账号删除路径恢复（unset 条目 + 凭据清理 + 清全部池引用）。
      poolDeleteAccount: '删除账号',
      poolOneClick: '一键授权登录',
      poolOneClickAdd: '一键授权并加入池',
      poolHealth: '健康',
      poolAccountSource: '账号池',
      oauthLoggedIn: '已登录',
      oauthNotLoggedIn: '未登录',
      oauthModels: '模型（插件独立维护）',
      oauthDiscover: '发现模型',
      oauthDiscovering: '查询中…',
      // ── ChatGPT 订阅登录（正式通道，EVO-006 / DEC-026 C2 转正；
      //    EVO-007 上移为一级醒目位）──────────────────────────────────
      presetTitle: 'ChatGPT 订阅登录',
      presetSummary: (n) => `${n} 个 ChatGPT 账号`,
      presetNotice: '使用 ChatGPT 订阅经官方 Codex OAuth 通路调用：请知悉并自行承担平台服务条款与账号风控方面的风险。',
      presetIntro: '在这里添加 ChatGPT 预设账号：一键浏览器授权 → 凭据落盘 → 专业 agent 的「OAuth 账号」指向它即可调用。',
      presetAdd: '＋ 添加 ChatGPT 账号',
      presetLogin: '登录 ChatGPT',
      presetLoggingIn: '等待授权…',
      presetLoginWaiting: '已打开授权页：在弹窗中完成 ChatGPT 登录，登录状态将自动刷新。',
      presetDeviceWaiting: (code, url) => `设备码登录进行中（回调端口被占用，已自动降级）：请打开 ${url} 并输入设备码 ${code} 完成授权`,
      presetLoginDone: 'ChatGPT 登录完成，凭据已保存。',
      presetLogout: '登出并删除凭据',
      presetLogoutConfirm: '确认登出并删除本机 ChatGPT 凭据文件？（不影响账号本身，随时可重新登录）',
      presetDelete: '删除账号',
      presetDeleteConfirm: '确认删除该 ChatGPT 预设账号？将同时删除本机凭据文件，并从引用它的账号池中移除。',
      presetDeleted: 'ChatGPT 账号已删除（凭据文件与池引用已清理）。',
      presetLogoutFailed: '登出失败（删除凭据文件）：请重试',
      presetPoolCleaned: (n) => `已从 ${n} 个账号池移除引用`,
      presetModelsHint: '模型列表由插件独立维护（可编辑；ChatGPT 订阅端点不提供模型发现，常用值 gpt-5.6-sol / gpt-5.6-terra / gpt-5.6-luna）。',
      presetModelsEmpty: '模型列表为空——主 agent 模型选择器不会出现该账号（保存模型列表后自动注册）。',
      presetModelsEmptyNotice: '已保存，但模型列表为空——主 agent 模型选择器不会出现该账号。',
      // EVO-010：调用通路开关 + 宿主官方 openai-codex 路由状态行。
      presetTransportLabel: '调用通路',
      presetTransportHost: '宿主官方（推荐）',
      presetTransportPlugin: '插件内置（降级）',
      presetRouteOk: 'openai-codex 路由已维护 · token 注入正常',
      presetRouteDegraded: 'openai-codex 路由已维护 · 此前连续失败（降级告警中）',
      presetRouteTokenFailed: 'openai-codex 路由已维护 · token 注入异常（插件内置通路不受影响）',
      presetRouteOff: 'openai-codex 路由未维护（无启用账号 / 未登录 / 已切插件内置 / 宿主路由异常）',
      presetRouteDegradedNotice: '官方路由连续失败已达 3 次：建议把「调用通路」切换为插件内置（不会自动改你的配置）。',
      presetTransportSaved: '调用通路已保存。',
      // F-4（EVO-010 R0）：transport 是维护开关非请求路由决策——实际走向由
      // 模型选择器所选分组决定（host=openai-codex 官方组 / plugin=ChatGPT
      // 订阅插件组）；切换不迁移既有会话绑定，如实披露。
      presetTransportHint: '实际调用走向以模型选择器所选分组为准（宿主官方 = openai-codex 组；插件内置 = ChatGPT 订阅组）；切换通路后既有会话请在模型选择器手动选组。',
      oauthTokenBack: 'access token 已自动保存。',
      oauthNeedConfig: '请先完善账号配置（Base URL 等）再登录',
      // F-1（EVO-007 R0 返工）：非 preset OAuth 账号删除路径恢复——
      // 删除确认/成功文案 + 未入池孤儿账号的极简管理列表文案。
      oauthDeleteConfirm: '确认删除该 OAuth 账号？将同时删除本机凭据，并从引用它的账号池中移除。',
      oauthDeleted: 'OAuth 账号已删除（凭据与池引用已清理）。',
      orphanOauthTitle: '未入池的 OAuth 账号',
      orphanOauthSummary: (n) => `${n} 个未入池账号`,
      orphanOauthIntro: '历史配置中未加入任何账号池的 OAuth 账号（含未知预设值账号）：此处仅提供删除入口，确保本机凭据可清理。',
      fieldAccount: 'OAuth 账号（插件独立管理，覆盖服务商/模型）',
      oauthChatOnly: 'OAuth 账号仅支持 chat 类型',
      // EVO-011（RES-004）：codex-responses（ChatGPT 订阅）账号 + image 类型
      // = 订阅生图直连（服务端 runCodexResponsesImage）——提示与字段可见性
      // 按此区分；endpoint / API Key 由账号凭据直连自取。
      oauthImageHint: '经 ChatGPT 订阅出图（gpt-image 系）——账号凭据直连 codex images 端点，无需配置 endpoint / API Key（尺寸仅支持 1024x1024 / 1024x1536 / 1536x1024 / auto）',
      oauthImageModelHint: '订阅出图建议在「模型」使用 gpt-image 系（如 gpt-image-2；draw 预设默认 dall-e-3 为平台 API 模型，经订阅账号调用时服务端自动换用 gpt-image-2 并提示）',
      // EVO-013：预设 Agent（按 DSH 预设粒度的默认模型；主权规则——手动选择
      // 与已运行会话永不被覆盖，未设置的预设零行为变化）。
      presetsTitle: '预设 Agent',
      presetsSummary: (n) => `已配置 ${n} 个预设`,
      presetDiagTitle: '预设生效诊断（最近事件）',
      presetDiagHint: '✓ = 已应用；✗ = 跳过（括号内为原因：not-configured 未配置 / produced 会话已运行 / explicit-override 显式覆盖 / face-unavailable 选择面缺失 / select-rejected 模型不可用等）',
      // ARCH-004 B1（§6.1）：宿主面健康徽章 + 面板（一次性快照数据源）。
      hostHealthTitle: '宿主面健康',
      hostHealthOk: '✓ 宿主面正常',
      hostHealthWarn: (n) => `⚠ ${n} 个宿主面降级/缺失`,
      faceDegraded: (list) => `宿主面降级（对应分区只读，其余功能正常）：${list}`,
      hostHealthVersions: (v) => `宿主版本：dsh-llm ${v.llm} · dsh-tools ${v.tools} · typert-protocol ${v.typertProtocol}`,
      hostHealthVersionsUnavailable: '宿主版本不可读（下文列出取数失败原因）',
      hostHealthRpcFailed: (code) => `⚠ 宿主面取数失败：${code}`,
      hostHealthFacesTitle: '面探针：',
      hostHealthNoProbes: '尚无已注册面探针（B2-B5 迁移批次接入后自动覆盖宿主依赖面）',
      hostHealthDiagTitle: '最近宿主诊断事件：',
      hostHealthNoDiag: '暂无诊断事件',
      // ARCH-005 R2：协商三态徽章（capabilityProfile.state 驱动——matched 绿 /
      // compatible-unknown 黄（显式「未实测宿主版本」提示）/ incompatible 红）。
      hostHealthUnknown: '⚠ 未实测宿主版本',
      hostHealthUnknownHint: '当前宿主版本组合不在插件实测基线档案内（gate-pass-unknown：面探针全绿，功能照常运行）。如遇异常，报障导出请附本面板信息；若宿主为 minor 跳位升级，插件会被宿主装载门整体拒载（本面板不可达——见宿主启动日志的 skip 警告）。',
      hostHealthBaseline: (id) => ` · 实测基线 ${id}`,
      presetsIntro: '以 DSH 预设为粒度配置默认模型：对应预设新开会话的主 Agent 与其派生的 subagent 将以配置模型为默认（subagent 留空 = 继承主 Agent 模型）。未配置的预设完全遵循 DSH 现行规则（零行为变化）；会话内手动选择的模型与已运行会话始终优先，不受此处影响。',
      presetsEmpty: '尚未配置预设默认模型——添加后，对应预设的新会话将以配置模型为默认模型。',
      presetsAdd: '添加预设配置',
      presetsAddHint: '从下拉选择宿主预设并配置模型后保存；已配置的预设不会再出现在下拉中。',
      presetsPresetLabel: 'DSH 预设',
      presetsSelectPreset: '选择预设',
      presetsMainLabel: '主 Agent 默认模型',
      presetsSubagentLabel: 'subagent 默认模型',
      presetsFieldProvider: '服务商',
      presetsFieldModel: '模型',
      presetsNotSet: '未设置（遵循 DSH 规则）',
      presetsInheritMain: '继承主 Agent 模型',
      presetsSubagentEmpty: '留空 = 继承主 Agent 模型',
      presetsMissing: '该预设已不存在（配置残留）：对应会话不会应用此配置，可删除本条目。',
      presetsDelete: '删除配置',
      presetsDeleteConfirm: '确认删除该预设的默认模型配置？',
      presetsRosterError: '预设列表获取失败',
      presetsRosterEmpty: '未获取到宿主预设：请确认宿主已提供 agentPreset 接口，或稍后重试。',
      presetsBroken: '已损坏',
      statsTitle: '统计信息',
      statsIntro: '实时用量（每 2 秒刷新）：Agent 级与账号级（服务商）两级明细卡片，默认折叠，点击展开查看平均耗时、模型细分与分钟级 tokens 分布；统计保存在内存中，重启后清零。',
      statsSummary: (calls, errors) => `累计 ${calls} 次调用 / ${errors} 次失败`,
      statsCalls: '调用',
      statsErrors: '失败',
      statsTokens: 'tokens（入/出）',
      statsAvg: '平均耗时',
      statsLast: '最近调用',
      statsReset: '清空统计',
      statsDisabled: '多模型路由未启用',
      statsAgent: 'Agent',
      statsProvider: '服务商/模型',
      statsTime: '时间',
      statsStatus: '状态',
      statsOk: '成功',
      statsFail: '失败',
      statsRecent: '最近调用记录',
      statsSeries: 'tokens 分布（每分钟，近 90 分钟）',
      // EVO-017 R3（FIX-031）：账号级调用数口径披露（双权威源合并的用户语义）。
      statsMainModel: '主模型',
      statsAccountScopeHint: '账号级调用数按请求口径（每次 LLM 请求恰记一条，覆盖全部路由形态，含端点无 token 上报的请求）；token / 耗时 / 失败数按调用明细口径统计，因此调用数可大于有明细的调用条数。',
      // FIX-031 D6 回落：宿主路由通路行在归并账号未知时的诚实标签（不伪装
      // 成已知账号/实体键）。
      statsHostRouteAccount: '宿主路由（账号未知）',
      statsAgentLevel: '专业 Agent 统计',
      statsAccountLevel: '账号级统计',
      // EVO-017：分级统计文案（预设作用域 + 二/三级卡片 + 三类视图）。
      statsPresetLevel: '预设 Agent 统计',
      statsPresetSummary: (n) => `${n} 个预设有调用`,
      statsGlobalLevel: '全局统计',
      statsPresetScopeHint: '按预设分组统计主 Agent 与 subagent 的每次 LLM 请求（计次口径——token 精确口径见专业/账号级视图；实时调用保留最新 10 条）。',
      statsPresetScopeNote: '计次口径：来自请求遥测（配置生效与归属观测）。',
      statsPresetMain: '预设 Agent（主会话）',
      statsPresetSub: 'subagent',
      statsPresetTotals: '总用量（模型分布）',
      statsPresetDaily: '每日用量',
      statsPresetRecent: '实时调用（最新 10 条）',
      statsAgentSummary: (n) => `${n} 个专业 agent`,
      statsAccountSummary: (n) => `${n} 个账号`,
      statsModelDetail: '模型细分',
      statsNoCalls: '暂无调用记录',
      statsDayLevel: '按天聚合',
      statsDate: '日期',
      statsDayMs: '耗时',
      statsCost: '成本（约）',
      statsExport: '导出 CSV',
      statsExportRange: '时间范围',
      statsExportLevel: '分组粒度',
      statsExportDone: '已导出：',
      statsExportFailed: '导出失败',
      statsExportMissing: '导出不可用（宿主行 dsh-agent-router 未挂载或 Remote 缺 statsExport）',
      agentsTitle: '专业 Agent',
      agentsSummary: (n) => `${n} 个专业 agent`,
      agentsIntro: '每个专业 Agent 用独立的服务商与模型处理特定能力（图片识别、生成、翻译、语音识别等）。卡片默认折叠，点击展开配置；服务商与模型留空时自动复用主 Agent 模型，点击末尾「+」添加。',
      addTitle: '添加专业 Agent',
      addPlaceholder: '新 agent id（如 vision / draw）',
      add: '添加',
      presets: '预设模板：',
      presetVision: '图片识别',
      presetImage: '图片生成',
      presetTranslate: '翻译',
      presetSpeech: '语音识别',
      presetVideo: '视频生成',
      presetGeneral: '通用子 Agent',
      cliPickerCodex: 'Codex CLI（OpenAI）',
      cliPickerClaude: 'Claude Code（Anthropic）',
      cliPickerGemini: 'Gemini CLI（Google）',
      fieldName: '名称',
      fieldType: '类型',
      fieldTypeHint: '类型只是执行方式（chat 调远端模型 / agent 委派 DSH 子代理 / image 文生图 / speech 语音转写 / cli 无头 CLI 子代理），不限制能力；能力标签才是你自定义的调度依据，files 图片分发也按它判定。',
      typeChat: 'chat · 对话型专业调用',
      typeAgent: 'agent · 完整子 Agent 委派',
      typeImage: 'image · 图片生成',
      typeSpeech: 'speech · 语音识别（转写）',
      typeCli: 'cli · 无头 CLI 子代理',
      fieldDescription: '能力说明（主模型据此判断何时调用）',
      fieldCapabilities: '能力标签（逗号分隔，如 image, audio）——自定义调度依据；files 传图片要求含 image',
      fieldProvider: '服务商（空 = 跟随主模型）',
      fieldModel: '模型（空 = 继承）',
      fieldDiscover: '发现模型',
      fieldReasoning: '推理强度（可选，如 high/max）',
      fieldTemperature: '温度',
      fieldMaxTokens: '最大输出 tokens（0 = 不限制）',
      fieldMaxRounds: '对话轮数上限',
      fieldSystemPrompt: 'System prompt（空 = 默认专业助手）',
      fieldEndpoint: '端点（image / speech 类型，空 = 官方端点）',
      fieldImageSize: '图片尺寸',
      fieldApiKeyEnv: '凭据引用（image / speech 类型，空 = OPENAI_API_KEY）',
      fieldTools: '工具白名单（agent 类型，逗号分隔；空 = 全部工具但禁用 route_agent）',
      fieldCommand: 'CLI 命令（如 codex / claude / gemini，或任意可执行路径）',
      fieldCliArgs: 'CLI 参数（空格分隔，可带引号；空 = 该 CLI 的安全默认参数；codex 未显式指定 --sandbox 时按平台自动补齐）',
      fieldCliTimeout: '执行超时（分钟，0 = 默认 15 分钟）',
      fieldCliConcurrent: '并发上限（同 agent，1-4）',
      cliSystemHint: 'cli 类型的 system prompt 会以「角色设定」段落注入任务头部（各 CLI 的原生 system prompt 参数形态不一，统一用注入方式生效）。',
      cliLoginStatus: '登录状态',
      cliStatusLoggedIn: '已登录',
      cliStatusLoggedOut: '未登录',
      cliStatusUnknown: '未检测',
      cliStatusRefresh: '刷新状态',
      cliLogin: '登录（打开终端窗口）',
      cliLoginWaiting: '等待登录…',
      cliRelogin: '重新登录',
      cliRemoteMissing: '宿主未提供 cliStatus/cliLogin 接口（dsh-agent-router 宿主行可能是旧版本）：请完全退出并重启 DSH，然后强制刷新页面（Ctrl+F5）。',
      cliRemoteFailed: 'CLI 接口调用失败',
      cliLoginTimeoutHint: '等待登录超时（约 60 秒未检测到登录完成）：请在终端窗口完成授权后点「刷新状态」；若已完成登录，刷新即显示「已登录」。',
      cliFetchModels: '拉取模型',
      cliFetchingModels: '拉取中…',
      cliTitle: '子代理（无头 CLI）',
      cliSummary: (n) => `${n} 个子代理`,
      cliIntro: '无头 CLI 子代理（Codex / Claude Code / Gemini CLI 等）作为账号类条目统一管理：配置命令与参数、完成登录、拉取模型、查看用量统计；专业 Agent 把「执行方式」设为 cli 后，从下拉直接选择这里的条目作为执行路径。',
      cliAdd: '添加子代理',
      cliQuickAddHint: '点击即创建子代理条目：Codex / Claude / Gemini 已预填命令与参数（登录/状态/模型列表命令走各 CLI 预设，可在高级设置覆盖）。',
      cliCustomAdd: '＋ 自定义',
      cliCustomHint: '已创建空白子代理：请在卡片中填写 CLI 命令与参数后保存，再执行登录。',
      cliConfirmDelete: '确认删除该子代理？（引用它的专业 agent 将无法调用）',
      cliDelete: '删除子代理',
      fieldCliAgent: '子代理（账号区维护的 CLI 条目）',
      cliAgentNone: '— 未选择（使用本 agent 内嵌命令，建议迁移）—',
      cliManageHint: '登录、拉取模型与命令参数在 多模态账号 → 子代理 中维护；此处模型字段为 -m / --model 覆盖参数（空 = CLI 默认模型）。',
      cliRoutingHint: '能力标签才是调度依据：保留能力标签（如 image），主 agent 仍会按对应任务路由到此 agent，cli 只决定交给哪个子代理执行；生成图片等产物时让子代理把文件写入工作区并在结果中报告路径。宿主会向子代理注入重试纪律（同一失败最多重试 2 次即报告错误结束），避免任务长时间卡死；图片生成走子代理自身的上游服务（如 ChatGPT 图片接口）时，请保证本机网络可达（例如开启代理）。',
      advancedSection: '高级扩展（账号池）',
      cliLegacyHint: '旧配置：本 agent 直接内嵌命令（未引用子代理条目）。建议在 多模态账号 → 子代理 中创建条目并在此选择，便于统一登录、模型与统计。',
      fieldCliLoginArgs: '登录命令参数（空 = 该 CLI 预设）',
      fieldCliStatusArgs: '状态命令参数（空 = 该 CLI 预设）',
      fieldCliModelsArgs: '模型列表命令参数（空 = 该 CLI 预设）',
      enable: '启用',
      save: '保存',
      saved: '已保存',
      saving: '保存中…',
      delete: '删除',
      confirmDelete: '确认删除该 agent？',
      test: '测试',
      testing: '测试中…',
      effective: '生效模型：',
      sourceAgent: '本 agent 配置',
      sourceMain: '复用主模型',
      sourceProvider: '服务商默认',
      sourceUnknown: '未知',
      loadFailed: '加载失败',
      retry: '重试',
      conflict: '配置已被他人修改，请重新加载后编辑。',
      readOnly: '设置文档只读。',
      fetching: '查询中…',
      fetchTitle: '发现模型',
      fetchEmpty: '端点没有公布模型',
      adopt: '选用',
      close: '关闭',
      cancel: '取消',
      routeDisabled: '多模型路由总开关已关闭',
      noAgents: '尚未配置任何专业 agent。点击下方「+」添加。',
      testNone: '尚未测试',
      invalidId: 'id 仅允许小写字母、数字与连字符',
      duplicateId: '该 id 已存在',
      advanced: '高级设置',
      inherit: '继承',
      expand: '展开',
      collapse: '收起',
      attach: '添加附件',
      attachUnavailable: '当前输入框不可用：无法添加附件',
      attachPickTitle: '选择附件',
      attachUploadFailed: '附件上传失败',
      imageLoadFailed: '图片加载失败，点击重试',
      imagePreviewTitle: '原图预览',
      toolRouteTitle: 'route_agent · 多模型路由',
      toolRunning: '正在处理…',
      toolImageLabel: '图片',
      galleryButton: '本会话图片产物',
      galleryTitle: '本会话图片产物',
      galleryEmpty: '本会话暂无图片产物',
      openFile: '打开文件',
      fileOpening: '正在读取…',
      fileOpenFailed: '文件打开失败，点击重试',
      download: '下载',
    }
    const en = {
      nav: 'Agent Routing',
      title: 'Multi-model Routing',
      intro: 'Configure specialist agents (vision, image generation, translation, speech recognition, …) with their own provider and model; unset values inherit the main agent model. All four category cards (Specialist / Preset Agents, accounts, statistics) are collapsed by default — click a category header to expand or collapse.',
      masterSwitch: 'Enable multi-model routing',
      masterHint: 'While disabled, route_agent refuses calls, the prompt section renders empty and stats pause. The whole native plugin can also be disabled by disabling the dsh-agent-router composition row.',
      accountTitle: 'Multimodal Accounts',
      accountSummary: (n) => `${n} account(s) configured`,
      accountIntro: 'Configure an API key for any provider — official providers, third-party relays and local deployments; ChatGPT/Claude/Grok/Gemini subscription plans work through their official API keys.',
      accountOAuth: 'Note: the harness model layer currently supports API-key authentication only; official OAuth sign-in flows are not provided. Once signed in, the provider models appear in the lists above; accounts share the same storage as Settings → Models.',
      accountAddHint: 'Configuration-style add (same as the Models foundation in Settings → Models): works for any provider — official providers take their official Base URL and API key, while unintegrated providers / third-party relays / local deployments (Ollama / One-API / LM Studio) take their own endpoint. Saving registers the provider into the shared model lists; with the model field left empty, saving auto-fetches the endpoint models and writes them (except when overwriting a built-in provider), or use "Discover models" in an agent to fetch them.',
      fieldProviderId: 'Provider id (e.g. openai / my-gateway / one-api; saving overwrites an existing route of the same id)',
      accountApi: 'API type',
      accountModelsField: 'Models (optional, comma separated; a custom provider auto-fetches them from the endpoint on save when left empty)',
      accountKeyOptional: 'API Key (optional: leave empty for keyless local deployments)',
      accountBaseUrlRequired: 'Base URL (required, e.g. http://127.0.0.1:11434/v1)',
      accountAddProvider: 'Add Provider',
      accountCustom: '+ Custom',
      accountProvider: 'Provider',
      accountKey: 'API Key',
      accountBaseUrl: 'Base URL (optional, overrides the default endpoint, e.g. a proxy gateway)',
      accountDone: 'Configured',
      accountMissing: 'Missing',
      accountActive: 'Active',
      accountDormant: 'Dormant',
      accountList: 'Configured accounts',
      addAccount: 'Add Account',
      accountEditTitle: 'Edit configuration',
      accountEditHint: 'Edit Base URL or API Key, then Save (leave Key empty to keep the current credential; Base URL must not be empty).',
      accountKeyKeep: 'empty = keep current key',
      accountNoBaseUrlWarn: 'This custom provider has no Base URL: a custom provider without one voids the whole model catalog (built-in providers need none). Fill it in and save.',
      accountCatalogEmptyWarn: 'The model catalog is entirely empty: usually caused by one invalid account (a custom provider without a Base URL voids the whole llm-pi-ai catalog). Expand each account and fill in the missing Base URL, then save.',
      accountDelete: 'Delete account',
      accountModelsTitle: 'Models',
      accountConfirmDelete: 'Delete this account? (Removes the provider config and its credential.)',
      accountModels: 'models',
      accountDiscoverFailed: 'Could not fetch models from the endpoint',
      accountModelsRequiredHint: 'A custom provider must list at least one model id: check the Base URL / API key and network and retry, or type the model ids by hand',
      accountDiscoverEmpty: 'The endpoint returned no models: type the model ids by hand, or check the endpoint URL',
      accountModelsKept: 'Kept the existing model list: a custom provider must list its models to serve; edit them by hand instead',
      accountDiscovered: (n) => `Auto-discovered ${n} models from the endpoint and saved`,
      oauthPopupBlocked: 'The browser blocked the popup; allow popups for this page and retry.',
      oauthWaiting: 'Authorization page opened: complete it in the popup and the login state refreshes automatically.',
      oauthExpired: 'Authorization timed out; start again.',
      oauthAutoDiscovering: 'Signed in: discovering models automatically…',
      advancedLogin: 'Account & sign-in settings',
      oauthNeedRestart: 'One-click sign-in requires a DSH restart (new host callback endpoint).',
      poolTitle: 'Account Pools',
      poolIntro: 'Group authorized accounts into a pool: calls pick an account by strategy (healthy first / lowest usage / round robin) and fail over to the next one automatically. An agent\'s "OAuth account" can point at a pool.',
      poolSummary: (n) => `${n} account pool(s)`,
      poolStrategy: 'Routing strategy',
      poolStrategyHealthy: 'Healthy first (fewest failures)',
      poolStrategyUsage: 'Lowest usage first',
      poolStrategyRoundRobin: 'Round robin',
      poolAccounts: 'Pool accounts',
      poolAddAccount: 'Add from authorized accounts',
      poolRemove: 'Remove',
      poolNoAccounts: 'No accounts in this pool yet: pick authorized accounts below, or use one-click sign-in on an account first.',
      poolAddPlaceholder: 'New pool id (e.g. gemini-pool)',
      addPool: 'Add Account Pool',
      poolDelete: 'Delete pool',
      poolConfirmDelete: 'Delete this account pool?',
      // F-1 (EVO-007 R0 rework): per-account delete entry on pool rows and the
      // orphan list — restores the non-preset OAuth account delete path.
      poolDeleteAccount: 'Delete account',
      poolOneClick: 'One-click sign-in',
      poolOneClickAdd: 'One-click sign-in & add to pool',
      poolHealth: 'Health',
      poolAccountSource: 'account pool',
      oauthLoggedIn: 'Signed in',
      oauthNotLoggedIn: 'Not signed in',
      oauthModels: 'Models (plugin-managed)',
      oauthDiscover: 'Discover models',
      oauthDiscovering: 'Querying…',
      // ── ChatGPT subscription sign-in (official channel, EVO-006 / DEC-026 C2;
      //    promoted to first level by EVO-007) ──────────────────────────
      presetTitle: 'ChatGPT Subscription Sign-in',
      presetSummary: (n) => `${n} ChatGPT account(s)`,
      presetNotice: 'Calling via a ChatGPT subscription through the official Codex OAuth path: please be aware of and accept the platform Terms of Service and account-risk considerations.',
      presetIntro: 'Add a ChatGPT preset account here: one-click browser authorization → credential stored → point an agent\'s "OAuth account" at it to call.',
      presetAdd: '+ Add ChatGPT Account',
      presetLogin: 'Sign in with ChatGPT',
      presetLoggingIn: 'Waiting for authorization…',
      presetLoginWaiting: 'Authorization page opened: complete ChatGPT sign-in in the popup; the login state refreshes automatically.',
      presetDeviceWaiting: (code, url) => `Device-code sign-in in progress (callback port occupied; degraded automatically): open ${url} and enter code ${code} to authorize`,
      presetLoginDone: 'ChatGPT sign-in complete; credential saved.',
      presetLogout: 'Sign out & delete credential',
      presetLogoutConfirm: 'Sign out and delete the local ChatGPT credential file? (The account itself is unaffected; you can sign in again anytime.)',
      presetDelete: 'Delete account',
      presetDeleteConfirm: 'Delete this ChatGPT preset account? The local credential file will also be deleted, and references will be removed from account pools.',
      presetDeleted: 'ChatGPT account deleted (credential file and pool references cleaned up).',
      presetLogoutFailed: 'Sign-out failed (credential file deletion): please retry',
      presetPoolCleaned: (n) => `Removed references from ${n} pool(s)`,
      presetModelsHint: 'The model list is plugin-managed (editable; the ChatGPT subscription endpoint offers no model discovery — common values gpt-5.6-sol / gpt-5.6-terra / gpt-5.6-luna).',
      presetModelsEmpty: 'Empty model list — this account will not appear in the main-agent model selector (it registers automatically once a model list is saved).',
      presetModelsEmptyNotice: 'Saved, but the model list is empty — this account will not appear in the main-agent model selector.',
      // EVO-010：调用通路开关 + 宿主官方 openai-codex 路由状态行。
      presetTransportLabel: 'Transport',
      presetTransportHost: 'Host official (recommended)',
      presetTransportPlugin: 'Plugin built-in (fallback)',
      presetRouteOk: 'openai-codex route maintained · token injection OK',
      presetRouteDegraded: 'openai-codex route maintained · earlier consecutive failures (degraded warning active)',
      presetRouteTokenFailed: 'openai-codex route maintained · token injection failing (plugin transport unaffected)',
      presetRouteOff: 'openai-codex route not maintained (no enabled account / not signed in / plugin transport / host route unhealthy)',
      presetRouteDegradedNotice: 'The official route failed 3 times in a row: consider switching Transport to the plugin built-in (your config is never changed automatically).',
      presetTransportSaved: 'Transport saved.',
      presetTransportHint: 'Actual calls follow the group picked in the model selector (Host official = the openai-codex group; Plugin built-in = the ChatGPT subscription group). After switching, pick the group manually in the model selector for existing sessions.',
      oauthTokenBack: 'Access token saved automatically.',
      oauthNeedConfig: 'Complete the account configuration first (Base URL, …)',
      // F-1 (EVO-007 R0 rework): delete confirm/success copy + minimal orphan
      // account list copy (non-preset OAuth accounts outside every pool).
      oauthDeleteConfirm: 'Delete this OAuth account? Its local credential will also be deleted, and references removed from all account pools.',
      oauthDeleted: 'OAuth account deleted (credential and pool references cleaned up).',
      orphanOauthTitle: 'Orphan OAuth accounts',
      orphanOauthSummary: (n) => `${n} orphan account(s)`,
      orphanOauthIntro: 'OAuth accounts from older configurations that belong to no account pool (including unknown preset values): delete-only management here so their local credentials can still be cleaned up.',
      fieldAccount: 'OAuth account (plugin-managed, overrides provider/model)',
      oauthChatOnly: 'OAuth accounts support chat type only',
      oauthImageHint: 'Generates via ChatGPT subscription (gpt-image family) — account credentials connect directly to the codex images endpoint; endpoint / API Key fields are not used (sizes: 1024x1024 / 1024x1536 / 1536x1024 / auto)',
      oauthImageModelHint: 'Use a gpt-image model for subscription generation (e.g. gpt-image-2; the draw preset defaults to dall-e-3 for platform API — the server switches to gpt-image-2 with a hint when an OAuth account is bound)',
      // EVO-013: per-DSH-preset default models (sovereignty — manual picks and
      // already-running sessions are never overridden; unconfigured presets keep DSH behavior).
      presetsTitle: 'Preset Agents',
      presetsSummary: (n) => `${n} preset(s) configured`,
      presetDiagTitle: 'Preset effectiveness diagnostics (recent events)',
      presetDiagHint: '✓ = applied; ✗ = skipped (reason in parentheses: not-configured / produced / explicit-override / face-unavailable / select-rejected …)',
      // ARCH-004 B1 (§6.1): host face health badge + panel (one-shot snapshot source).
      hostHealthTitle: 'Host face health',
      hostHealthOk: '✓ host faces healthy',
      hostHealthWarn: (n) => `⚠ ${n} host face(s) degraded/missing`,
      faceDegraded: (list) => `Host faces degraded (affected sections read-only, rest unaffected): ${list}`,
      hostHealthVersions: (v) => `Host versions: dsh-llm ${v.llm} · dsh-tools ${v.tools} · typert-protocol ${v.typertProtocol}`,
      hostHealthVersionsUnavailable: 'Host versions unreadable (the fetch failure is listed below)',
      hostHealthRpcFailed: (code) => `⚠ host face fetch failed: ${code}`,
      hostHealthFacesTitle: 'Face probes: ',
      hostHealthNoProbes: 'No face probes registered yet (host dependency faces are covered automatically once the B2-B5 migration batches land)',
      hostHealthDiagTitle: 'Recent host diagnostics: ',
      hostHealthNoDiag: 'No diagnostic events yet',
      // ARCH-005 R2: negotiation tri-state badge (capabilityProfile.state — matched green /
      // compatible-unknown yellow with explicit untested-version hint / incompatible red).
      hostHealthUnknown: '⚠ host version not in tested baselines',
      hostHealthUnknownHint: 'The current host version combination is not in the tested baseline registry of this plugin (gate-pass-unknown: all face probes green, features keep running). If anything misbehaves, attach this panel to the diagnostics export; on a minor-version jump the host loader rejects the plugin entirely (this panel is unreachable — see the skip warning in the host startup log).',
      hostHealthBaseline: (id) => ` · tested baseline ${id}`,
      presetsIntro: 'Configure default models per DSH preset: new sessions of the preset main agent and its subagents default to the configured model (empty subagent = inherit the main model). Unconfigured presets fully follow current DSH rules (zero behavior change); models picked manually in a session and already-running sessions always win.',
      presetsEmpty: 'No preset default models configured yet — once added, new sessions of the matching preset default to the configured model.',
      presetsAdd: 'Add preset configuration',
      presetsAddHint: 'Pick a host preset from the dropdown, configure models and save; presets already configured are excluded from the dropdown.',
      presetsPresetLabel: 'DSH preset',
      presetsSelectPreset: 'Select preset',
      presetsMainLabel: 'Main agent default model',
      presetsSubagentLabel: 'Subagent default model',
      presetsFieldProvider: 'Provider',
      presetsFieldModel: 'Model',
      presetsNotSet: 'Not set (follows DSH rules)',
      presetsInheritMain: 'Inherit main agent model',
      presetsSubagentEmpty: 'Leave empty to inherit the main agent model',
      presetsMissing: 'This preset no longer exists (residual config): sessions will not apply it — you can delete this entry.',
      presetsDelete: 'Delete config',
      presetsDeleteConfirm: 'Delete the default model configuration for this preset?',
      presetsRosterError: 'Failed to load preset list',
      presetsRosterEmpty: 'No host presets available: make sure the host provides the agentPreset API, or retry later.',
      presetsBroken: 'broken',
      statsTitle: 'Usage Statistics',
      statsIntro: 'Realtime usage (refreshed every 2s) at agent level and account (provider) level. Cards are collapsed by default — expand for average latency, model breakdown and per-minute token distribution; stats live in memory and reset on restart.',
      statsSummary: (calls, errors) => `${calls} calls / ${errors} errors`,
      statsCalls: 'Calls',
      statsErrors: 'Errors',
      statsTokens: 'tokens (in/out)',
      statsAvg: 'Avg latency',
      statsLast: 'Last call',
      statsReset: 'Clear stats',
      statsDisabled: 'Multi-model routing is disabled',
      statsAgent: 'Agent',
      statsProvider: 'Provider / model',
      statsTime: 'Time',
      statsStatus: 'Status',
      statsOk: 'OK',
      statsFail: 'Failed',
      statsRecent: 'Recent calls',
      statsSeries: 'Tokens per minute (last 90 min)',
      // EVO-017 R3 (FIX-031): account-level call-count basis disclosure.
      statsMainModel: 'Main model',
      statsAccountScopeHint: 'Account-level calls use the request basis (exactly one record per LLM request, covering every routing shape including requests whose endpoint reports no tokens); tokens / latency / failures come from call detail, so calls can exceed the number of detailed calls.',
      // FIX-031 D6 fallback: honest label for host-route rows when the backing
      // account is unknown (never impersonate a known account/entity key).
      statsHostRouteAccount: 'Host route (account unknown)',
      statsAgentLevel: 'Specialist Agent stats',
      statsAccountLevel: 'Account-level stats',
      // EVO-017: tiered stats copy (preset scope + tier cards + three views).
      statsPresetLevel: 'Preset Agent stats',
      statsPresetSummary: (n) => `${n} preset(s) with calls`,
      statsGlobalLevel: 'Global stats',
      statsPresetScopeHint: 'Per-preset request counts for the main agent and subagents (call-count basis — exact tokens live in the specialist/account views; recent calls keep the latest 10).',
      statsPresetScopeNote: 'Call-count basis: from request telemetry (config-effectiveness and attribution).',
      statsPresetMain: 'Preset agent (main session)',
      statsPresetSub: 'subagent',
      statsPresetTotals: 'Totals (model distribution)',
      statsPresetDaily: 'Daily usage',
      statsPresetRecent: 'Recent calls (latest 10)',
      statsAgentSummary: (n) => `${n} specialist agent(s)`,
      statsAccountSummary: (n) => `${n} account(s)`,
      statsModelDetail: 'Model breakdown',
      statsNoCalls: 'No calls recorded yet',
      statsDayLevel: 'By-day aggregate',
      statsDate: 'Date',
      statsDayMs: 'Latency',
      statsCost: 'Cost (est.)',
      statsExport: 'Export CSV',
      statsExportRange: 'Range',
      statsExportLevel: 'Granularity',
      statsExportDone: 'Exported: ',
      statsExportFailed: 'Export failed',
      statsExportMissing: 'Export unavailable (host dsh-agent-router not mounted or Remote lacks statsExport)',
      agentsTitle: 'Specialist Agents',
      agentsSummary: (n) => `${n} specialist agent(s)`,
      agentsIntro: 'Each specialist agent handles one capability (vision, image generation, translation, speech recognition, …) with its own provider and model. Cards are collapsed by default — click to expand and configure; unset provider/model inherits the main agent model; use "+" at the end to add one.',
      addTitle: 'Add Specialist Agent',
      addPlaceholder: 'New agent id (e.g. vision / draw)',
      add: 'Add',
      presets: 'Templates:',
      presetVision: 'Vision',
      presetImage: 'Image Generation',
      presetTranslate: 'Translation',
      presetSpeech: 'Speech Recognition',
      presetVideo: 'Video Generation',
      presetGeneral: 'General Subagent',
      cliPickerCodex: 'Codex CLI (OpenAI)',
      cliPickerClaude: 'Claude Code (Anthropic)',
      cliPickerGemini: 'Gemini CLI (Google)',
      fieldName: 'Name',
      fieldType: 'Type',
      fieldTypeHint: 'Type is only the execution path (chat calls a remote model / agent delegates a DSH subagent / image generates images / speech transcribes audio / cli runs a headless CLI subagent) — it does not limit capability. Capability tags are your custom routing contract, and files image dispatch follows them.',
      typeChat: 'chat · specialist call',
      typeAgent: 'agent · full subagent delegation',
      typeImage: 'image · image generation',
      typeSpeech: 'speech · audio transcription',
      typeCli: 'cli · headless CLI subagent',
      fieldDescription: 'Capability description (guides the main model)',
      fieldCapabilities: 'Capability tags (comma separated, e.g. image, audio) — custom routing contract; files images require image',
      fieldProvider: 'Provider (empty = inherit main model)',
      fieldModel: 'Model (empty = inherit)',
      fieldDiscover: 'Discover models',
      fieldReasoning: 'Reasoning effort (optional, e.g. high/max)',
      fieldTemperature: 'Temperature',
      fieldMaxTokens: 'Max output tokens (0 = unset)',
      fieldMaxRounds: 'Max rounds',
      fieldSystemPrompt: 'System prompt (empty = default specialist)',
      fieldEndpoint: 'Endpoint (image / speech types; empty = official endpoint)',
      fieldImageSize: 'Image size',
      fieldApiKeyEnv: 'Credential ref (image / speech types; empty = OPENAI_API_KEY)',
      fieldTools: 'Tool allow-list (agent type, comma separated; empty = all tools except route_agent)',
      fieldCommand: 'CLI command (e.g. codex / claude / gemini, or any executable path)',
      fieldCliArgs: 'CLI args (space separated, quotes allowed; empty = safe defaults for this CLI; codex auto-fills --sandbox per platform when unspecified)',
      fieldCliTimeout: 'Timeout (minutes; 0 = default 15 minutes)',
      fieldCliConcurrent: 'Concurrency cap (same agent, 1-4)',
      cliSystemHint: 'For cli type, the system prompt is injected into the task as a "role" section (CLI-specific system-prompt flags vary, so injection keeps it uniform).',
      cliLoginStatus: 'Sign-in status',
      cliStatusLoggedIn: 'Signed in',
      cliStatusLoggedOut: 'Not signed in',
      cliStatusUnknown: 'Unknown',
      cliStatusRefresh: 'Refresh status',
      cliLogin: 'Sign in (opens terminal)',
      cliLoginWaiting: 'Waiting for sign-in…',
      cliRelogin: 'Sign in again',
      cliRemoteMissing: 'The host does not provide the cliStatus/cliLogin interface (outdated dsh-agent-router host plugin): fully quit and restart DSH, then hard-refresh the page (Ctrl+F5).',
      cliRemoteFailed: 'CLI interface call failed',
      cliLoginTimeoutHint: 'Sign-in was not detected within ~60s: complete the authorization in the terminal window, then click "Refresh status"; if you already signed in, refreshing shows "Signed in".',
      cliFetchModels: 'Fetch models',
      cliFetchingModels: 'Fetching…',
      cliTitle: 'Subagents (headless CLI)',
      cliSummary: (n) => `${n} subagent(s)`,
      cliIntro: 'Headless CLI subagents (Codex / Claude Code / Gemini CLI, …) are managed as account-like entries: configure command & args, sign in, fetch models, and review usage stats. Specialist agents pick one of these entries as their execution path when their type is set to cli.',
      cliAdd: 'Add Subagent',
      cliQuickAddHint: 'Click to create a subagent entry: Codex / Claude / Gemini come pre-filled (login/status/model-list commands use per-CLI presets, overridable in advanced settings).',
      cliCustomAdd: '+ Custom',
      cliCustomHint: 'Blank subagent created: fill in the CLI command and args, save, then sign in.',
      cliConfirmDelete: 'Delete this subagent? (agents referencing it will fail to run)',
      cliDelete: 'Delete subagent',
      fieldCliAgent: 'Subagent (CLI entry maintained under accounts)',
      cliAgentNone: '— None selected (uses this agent\'s embedded command; migrate recommended) —',
      cliManageHint: 'Sign-in, model fetching and command args live under Accounts → Subagents; the model field here is the -m / --model override (empty = CLI default model).',
      cliRoutingHint: 'Capability tags drive routing: keep tags like image and the main agent still routes matching tasks here — cli only picks which subagent executes them. For artifacts such as images, have the subagent write files into the workspace and report their paths in the result. The host injects a retry discipline (max 2 retries per failure, then report and exit) to prevent long hangs; when image generation goes through the subagent\'s own upstream (e.g. ChatGPT\'s image API), the machine must be able to reach it (e.g. with a proxy on).',
      advancedSection: 'Advanced extensions (account pools)',
      cliLegacyHint: 'Legacy config: this agent embeds its own command (no subagent reference). Create an entry under Accounts → Subagents and select it here for unified sign-in, models and stats.',
      fieldCliLoginArgs: 'Login command args (empty = CLI preset)',
      fieldCliStatusArgs: 'Status command args (empty = CLI preset)',
      fieldCliModelsArgs: 'Model-list command args (empty = CLI preset)',
      enable: 'Enabled',
      save: 'Save',
      saved: 'Saved',
      saving: 'Saving…',
      delete: 'Delete',
      confirmDelete: 'Delete this agent?',
      test: 'Test',
      testing: 'Testing…',
      effective: 'Effective model: ',
      sourceAgent: 'agent config',
      sourceMain: 'inherits main model',
      sourceProvider: 'provider default',
      sourceUnknown: 'unknown',
      loadFailed: 'Load failed',
      retry: 'Retry',
      conflict: 'Settings changed elsewhere; reload and retry.',
      readOnly: 'The settings document is read-only.',
      fetching: 'Querying…',
      fetchTitle: 'Discover models',
      fetchEmpty: 'The endpoint reported no models',
      adopt: 'Adopt',
      close: 'Close',
      cancel: 'Cancel',
      routeDisabled: 'Multi-model routing master switch is off',
      noAgents: 'No specialist agents yet. Click "+" below to add one.',
      testNone: 'Not tested',
      invalidId: 'id allows lowercase letters, digits and hyphens only',
      duplicateId: 'That id already exists',
      advanced: 'Advanced',
      inherit: 'Inherit',
      expand: 'Expand',
      collapse: 'Collapse',
      attach: 'Add attachments',
      attachUnavailable: 'Cannot add attachments: the input is unavailable right now',
      attachPickTitle: 'Choose attachments',
      attachUploadFailed: 'Attachment upload failed',
      imageLoadFailed: 'Image failed to load; click to retry',
      imagePreviewTitle: 'Original image preview',
      toolRouteTitle: 'route_agent · Multi-model routing',
      toolRunning: 'Processing…',
      toolImageLabel: 'Image',
      galleryButton: 'Session images',
      galleryTitle: 'Session images',
      galleryEmpty: 'No images generated in this session yet',
      openFile: 'Open file',
      fileOpening: 'Opening…',
      fileOpenFailed: 'Failed to open file; click to retry',
      download: 'Download',
    }

    // ── 工具函数 ────────────────────────────────────────────────────────────
    function messageOf(error) {
      return error instanceof Error ? error.message : String(error)
    }
    function deriveKeyRef(provider) {
      return `${provider.toUpperCase().replace(/[^A-Z0-9]+/g, '_')}_API_KEY`
    }
    const ID_PATTERN = /^[a-z][a-z0-9-]*$/
    function timeOf(at) {
      return at ? new Date(at).toLocaleTimeString() : '—'
    }
    function fmtMs(ms) {
      return ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${Math.round(ms)}ms`
    }
    function fmtTokens(n) {
      if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`
      if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`
      return String(n)
    }
    function fmtCost(value) {
      const n = Number(value) || 0
      if (n === 0) return '0'
      return String(Math.round(n * 1e6) / 1e6)
    }
    /** EVO-004 出口⑤：CSV 下载——浏览器用 Blob + <a download>（不离开当前页）；
     *  无 DOM 环境（宿主预渲染/测试）回落 data: URL 新标签页（用户可保存）。 */
    function downloadCsv(csv, filename) {
      if (typeof document !== 'undefined' && typeof document.createElement === 'function' && typeof window !== 'undefined' && window.URL && typeof window.URL.createObjectURL === 'function') {
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
        const url = window.URL.createObjectURL(blob)
        const anchor = document.createElement('a')
        anchor.href = url
        anchor.download = filename
        document.body.appendChild(anchor)
        anchor.click()
        document.body.removeChild(anchor)
        window.URL.revokeObjectURL(url)
        return
      }
      window.open(`data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`, '_blank')
    }

    /** 从 describe 结果中取一个 namespace view。 */
    function viewOf(namespaces, ns) {
      return namespaces.find((view) => view.ns === ns)
    }

    /**
     * 询问服务商端点公布的模型（llm.discoverModels 一次性探测，绝不落盘）：
     * - 内置目录路由直接返回目录模型（不联网）；自定义路由按 baseURL 经
     *   GET /models 询问端点；
     * - `apiKey` 一次性携带（添加流程时 profile 尚未写入，宿主无法代取
     *   已存凭据）；该参数只服务于本次探测，服务端接口不保存；
     * - 失败抛错（端点不可达 / 无模型列表 / 协议不可探测），由调用方决定
     *   后续——添加流程中止写入并给出指引，编辑流程保留现有模型列表。
     */
    async function probeProviderModels(api, request) {
      const response = await api.llm.discoverModels({
        settingsNs: 'llm-pi-ai',
        provider: request.provider,
        ...(request.baseURL ? { baseURL: request.baseURL } : {}),
        ...(request.api ? { api: request.api } : {}),
        ...(request.apiKey ? { apiKey: request.apiKey } : {}),
      })
      if (!response.result.ok) throw new Error(response.result.error.message)
      return response.result.value.models ?? []
    }

    /**
     * 把端点发现的模型组装为 llm-pi-ai profile 的 models 条目：
     * 携带端点公布的 name/contextWindow/maxTokens（宿主 schema 可接收；
     * 容量字段必须是正整数，否则丢弃、按宿主默认容量走）。
     */
    function modelEntriesOf(discovered) {
      return (discovered ?? []).map((model) => ({
        id: model.id,
        ...(typeof model.name === 'string' && model.name ? { name: model.name } : {}),
        ...(Number.isInteger(model.contextWindow) && model.contextWindow > 0 ? { contextWindow: model.contextWindow } : {}),
        ...(Number.isInteger(model.maxTokens) && model.maxTokens > 0 ? { maxTokens: model.maxTokens } : {}),
      }))
    }

    /** 专业 agent 预设模板：都是能力起点（chat/agent/image/speech 执行方式），
     *  不是 agent 类别——codex/claude/gemini 等 CLI 工具不是预设，而是任意
     *  专业 agent 在「执行方式 = cli」时可选的子代理路径（见 CLI_PICKER）。 */
    const AGENT_PRESETS = [
      { id: 'vision', key: 'presetVision', draft: { name: '视觉识别', type: 'chat', description: '识别与描述图片内容（OCR、界面截图、图表解读等；可接收 files 图片路径/URL 与对话图片附件）', capabilities: ['image'] } },
      { id: 'draw', key: 'presetImage', draft: { name: '图片生成', type: 'image', provider: 'openai', model: 'dall-e-3', description: '根据文字描述生成图片', capabilities: ['image'] } },
      { id: 'translate', key: 'presetTranslate', draft: { name: '翻译', type: 'chat', description: '多语言互译与润色', capabilities: ['translate'] } },
      { id: 'voice', key: 'presetSpeech', draft: { name: '语音识别', type: 'speech', provider: 'openai', model: 'whisper-1', description: '把音频文件转写为文字（route_agent 经 filePath 指定工作区文件）', capabilities: ['audio'] } },
      { id: 'video', key: 'presetVideo', draft: { name: '视频生成', type: 'chat', description: '视频脚本、字幕与内容生成（无通用视频生成 API：请在高级设置中配置兼容网关与模型）', capabilities: ['video'] } },
      { id: 'assistant', key: 'presetGeneral', draft: { name: '通用子 Agent', type: 'agent', description: '把复杂子任务交给独立模型的完整 agent', capabilities: [] } },
    ]

    /** cli 执行方式的可选子代理工具（codex/claude/gemini + 自定义）。
     *  账号区的「子代理」快速添加使用：选中即预填条目名称/命令/参数
     *  （登录/状态/模型命令走运行时预设，可在条目高级设置覆盖）。
     *  codex 的 args 留空 = 运行时按平台自适应补齐沙箱参数（Windows 用
     *  danger-full-access——其 OS 沙箱无法启动 WindowsApps 的 shell；
     *  其余平台 workspace-write），不要再预填旧版固定模板。 */
    const CLI_PICKER = [
      { id: '', key: 'cliCustomAdd' },
      { id: 'codex', key: 'cliPickerCodex', fill: { name: 'Codex 子代理', command: 'codex', args: '' } },
      { id: 'claude', key: 'cliPickerClaude', fill: { name: 'Claude 子代理', command: 'claude', args: '-p --output-format json --permission-mode bypassPermissions' } },
      { id: 'gemini', key: 'cliPickerGemini', fill: { name: 'Gemini 子代理', command: 'gemini', args: '-p --output-format json --yolo' } },
    ]

    /** OAuth 账号预设（官方登录）。authUrl/tokenUrl 为空的预设仅支持粘贴 token。
     *  gemini 预设默认走自建 Client（publicClient=false）：scope 为官方组合
     *  （cloud-platform + generative-language.retriever，token 可调 API）；
     *  用户需在 Google Cloud 控制台创建 OAuth Client（回调
     *  http://127.0.0.1:3080/router-oauth/callback）。内置公开 Client 仅能
     *  完成授权、其 token 被 Google 禁用于 API 调用（403 insufficient
     *  scopes），故不再作为默认。
     *  EVO-007：官方登录入口 UI 已移除（自述不可用），预设仍服务于账号池的
     *  「一键授权并加入池」创建路径。 */
    const GEMINI_SELF_CLIENT_SCOPES = 'https://www.googleapis.com/auth/cloud-platform https://www.googleapis.com/auth/generative-language.retriever'
    const OAUTH_PRESETS = [
      { id: 'gemini', label: 'Gemini · Google', draft: { name: 'Gemini', protocol: 'gemini', baseURL: 'https://generativelanguage.googleapis.com/v1beta', authUrl: 'https://accounts.google.com/o/oauth2/v2/auth', tokenUrl: 'https://oauth2.googleapis.com/token', scope: GEMINI_SELF_CLIENT_SCOPES, publicClient: false } },
      { id: 'chatgpt', label: 'ChatGPT · OpenAI（自建网关）', draft: { name: 'ChatGPT', protocol: 'openai-completions', baseURL: 'https://api.openai.com/v1' } },
      { id: 'claude', label: 'Claude · Anthropic（自建网关）', draft: { name: 'Claude', protocol: 'anthropic', baseURL: 'https://api.anthropic.com/v1' } },
      { id: 'grok', label: 'Grok · xAI（自建网关）', draft: { name: 'Grok', protocol: 'openai-completions', baseURL: 'https://api.x.ai/v1' } },
    ]

    /** 预设账号成员值集合（R8-F1 判据统一）：与 schemas.js OAUTH_PRESET_VALUES
     *  对齐（客户端无法 import——本地镜像常量）。preset 存在且为成员值 = 预设
     *  账号（专属账号卡 + W-5 联动删除）；非成员 preset 值（未知值）回落到
     *  通用账号（可删——非成员账号无独立凭据文件，通用删除安全）。 */
    const OAUTH_PRESET_MEMBER_VALUES = ['chatgpt-codex']
    const isPresetAccount = (entry) => !!entry && typeof entry.preset === 'string' && OAUTH_PRESET_MEMBER_VALUES.includes(entry.preset)

    // ── OAuth2 PKCE 工具 ────────────────────────────────────────────────────
    // （EVO-007 移除：官方登录 UI 与 openOauthAuthorize/exchangeOauthCode 一并
    //  删除后无引用；账号池的一键授权走宿主 oauthBegin 服务端 PKCE，不经此。）

    /** 分钟级 tokens 柱状图。 */
    function BarChart(props) {
      const { buckets, height = 30, title } = props
      const shown = (buckets ?? []).slice(-48)
      const max = Math.max(1, ...shown.map((bucket) => bucket.inputTokens + bucket.outputTokens))
      return el('div', { className: 'dshrouter-bars', title: title || undefined },
        ...shown.map((bucket) => el('div', {
          key: bucket.minute,
          className: 'dshrouter-bar' + (bucket.errors > 0 && bucket.calls === bucket.errors ? ' err' : ''),
          style: { height: `${Math.max(2, Math.round(((bucket.inputTokens + bucket.outputTokens) / max) * height))}px` },
          title: `${bucket.minute} · in ${bucket.inputTokens} / out ${bucket.outputTokens} · ${bucket.errors} err`,
        })))
    }

    /** 折叠式统计卡片（Agent 级与账号级共用的摘要+详情形态）。 */
    function StatsRowCard(props) {
      const { title, badge, meta, calls, errors, inputTokens, outputTokens, totalMs, lastAt, buckets, expanded, t, onToggle } = props
      return el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          el('span', { className: 'dshrouter-name' }, title),
          badge ? el('span', { className: 'dshrouter-id' }, badge) : null,
          meta ? el('span', { className: 'dshrouter-tag' }, meta) : null,
          el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')} ${calls} · ${t('statsErrors')} ${errors} · ${fmtTokens(inputTokens)}/${fmtTokens(outputTokens)}`),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')),
        expanded ? el('div', { className: 'dshrouter-stats' },
          el('div', { className: 'dshrouter-row' },
            el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')}: ${calls}`),
            el('span', { className: 'dshrouter-meta', style: errors > 0 ? { color: 'var(--dsw-alias-state-error-primary)' } : undefined }, `${t('statsErrors')}: ${errors}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsTokens')}: ${fmtTokens(inputTokens)} / ${fmtTokens(outputTokens)}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsAvg')}: ${calls > 0 ? fmtMs(totalMs / calls) : '—'}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsLast')}: ${timeOf(lastAt)}`)),
          (buckets ?? []).length > 0 ? el(BarChart, { buckets, title: t('statsSeries') }) : el('p', { className: 'dshrouter-hint' }, t('statsNoCalls'))) : null)
    }

    /** 账号级统计卡片：摘要 + 模型细分表 + 账号级柱状图。 */
    function AccountStatsCard(props) {
      const { provider, displayName, active, calls, errors, inputTokens, outputTokens, totalMs, lastAt, models, buckets, expanded, t, onToggle } = props
      return el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          active ? el('span', { className: 'dshrouter-dot ok', title: t('accountActive') }) : el('span', { className: 'dshrouter-dot bad', title: t('accountDormant') }),
          el('span', { className: 'dshrouter-name' }, displayName),
          el('span', { className: 'dshrouter-id' }, provider),
          active ? el('span', { className: 'dshrouter-tag' }, t('accountActive')) : el('span', { className: 'dshrouter-tag' }, t('accountDormant')),
          el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')} ${calls} · ${t('statsErrors')} ${errors} · ${fmtTokens(inputTokens)}/${fmtTokens(outputTokens)}`),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')),
        expanded ? el('div', { className: 'dshrouter-stats' },
          el('div', { className: 'dshrouter-row' },
            el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')}: ${calls}`),
            el('span', { className: 'dshrouter-meta', style: errors > 0 ? { color: 'var(--dsw-alias-state-error-primary)' } : undefined }, `${t('statsErrors')}: ${errors}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsTokens')}: ${fmtTokens(inputTokens)} / ${fmtTokens(outputTokens)}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsAvg')}: ${calls > 0 ? fmtMs(totalMs / calls) : '—'}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsLast')}: ${timeOf(lastAt)}`)),
          el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('statsModelDetail'))),
          models.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : el('table', { className: 'dshrouter-table' },
            el('thead', null, el('tr', null,
              el('th', null, t('fieldModel')), el('th', null, t('statsCalls')), el('th', null, t('statsErrors')), el('th', null, t('statsTokens')), el('th', null, t('statsAvg')), el('th', null, t('statsLast')))),
            el('tbody', null, ...models.map((modelTotal) => el('tr', { key: modelTotal.model },
              el('td', null, modelTotal.model),
              el('td', null, modelTotal.calls),
              el('td', null, modelTotal.errors > 0 ? el('span', { className: 'dshrouter-error' }, modelTotal.errors) : modelTotal.errors),
              el('td', null, `${fmtTokens(modelTotal.inputTokens)} / ${fmtTokens(modelTotal.outputTokens)}`),
              el('td', null, modelTotal.calls > 0 ? fmtMs(modelTotal.totalMs / modelTotal.calls) : '—'),
              el('td', null, timeOf(modelTotal.lastAt)))))),
          buckets.length > 0 ? el(BarChart, { buckets, title: t('statsSeries') }) : null) : null)
    }

    /**
     * EVO-017：预设作用域统计卡（三级卡片，默认折叠）——每预设分 main/
     * subagent 两口径，各含三类：总用量（计次+模型分布）/ 每日用量（按天
     * 计次+模型）/ 实时调用（最新 10 条请求）。计次口径说明：token 精确
     * 口径在专业/账号级视图（此处观测配置生效与归属）。
     */
    function PresetStatsCard(props) {
      const { preset, row, expanded, accountNames, t, onToggle } = props
      const armOf = (arm) => el('div', { className: 'dshrouter-stats', style: { marginTop: 4 } },
        el('div', { className: 'dshrouter-row' },
          el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')}: ${arm.calls}`),
          el('span', { className: 'dshrouter-meta' }, `${t('statsLast')}: ${timeOf(arm.lastAt)}`),
          el('span', { className: 'dshrouter-spacer' })),
        el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('statsPresetTotals'))),
        el('table', { className: 'dshrouter-table' },
          el('thead', null, el('tr', null, el('th', null, t('fieldProvider')), el('th', null, t('fieldModel')), el('th', null, t('statsCalls')))),
          el('tbody', null, ...arm.models.map((modelCount) => el('tr', { key: `${modelCount.provider}/${modelCount.model}` },
            el('td', null, statsProviderLabelOf(modelCount, accountNames, t)),
            el('td', null, modelCount.model),
            el('td', null, modelCount.calls))))),
        el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('statsPresetDaily'))),
        arm.days.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : el('table', { className: 'dshrouter-table' },
          el('thead', null, el('tr', null, el('th', null, t('statsDate')), el('th', null, t('statsCalls')), el('th', null, t('fieldModel')))),
          el('tbody', null, ...[...arm.days].reverse().map((day) => el('tr', { key: day.date },
            el('td', null, day.date),
            el('td', null, day.calls),
            el('td', null, day.models.map((modelCount) => `${modelCount.model}×${modelCount.calls}`).join(', ')))))),
        el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('statsPresetRecent'))),
        arm.recent.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : el('table', { className: 'dshrouter-table' },
          el('thead', null, el('tr', null, el('th', null, t('statsTime')), el('th', null, t('statsProvider')))),
          el('tbody', null, ...arm.recent.map((entry, index) => el('tr', { key: `${entry.at}-${index}` },
            el('td', null, timeOf(entry.at)),
            el('td', null, `${statsProviderLabelOf(entry, accountNames, t)}/${entry.model}`))))))
      return el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          el('span', { className: 'dshrouter-name' }, preset),
          el('span', { className: 'dshrouter-meta' }, `${t('statsPresetMain')} ${row.main.calls} · ${t('statsPresetSub')} ${row.subagent.calls}`),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')),
        expanded ? el('div', { className: 'dshrouter-stats' },
          el('p', { className: 'dshrouter-hint' }, t('statsPresetScopeNote')),
          el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-subtitle' }, t('statsPresetMain'))),
          row.main.calls > 0 ? armOf(row.main) : el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')),
          el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-subtitle' }, t('statsPresetSub'))),
          row.subagent.calls > 0 ? armOf(row.subagent) : el('p', { className: 'dshrouter-hint' }, t('statsNoCalls'))) : null)
    }

    /**
     * EVO-017 R2 统一分组统计体（用户裁决：所有 2/3 级分组复用相同逻辑——
     * 总用量 / 每日用量 / 实时调用 三段）。props：totals 行（calls/errors/
     * inputTokens/outputTokens/totalMs/lastAt）+ days 数组（date/calls/
     * errors/inputTokens/outputTokens/ms/cost/models?）+ recent 数组（≤10
     * 条 {at, provider?, agentId?, model, ok?, ms?, inputTokens?,
     * outputTokens?}）+ models 可选（总用量模型分布表）。
     * FIX-031：明细「服务商」列经 statsProviderLabelOf 单点取名（账号清洁键 →
     * 配置面显示名；无账号归属时按 agent 词汇），旧实现 `provider || agentId`
     * 直接把内部 agentId 当服务商打印（用户实证 `twin/glm-5.3`）。
     */
    function GroupStatsBody(props) {
      const { totals, days, recent, models, accountNames, t } = props
      const call = totals || { calls: 0, errors: 0, inputTokens: 0, outputTokens: 0, totalMs: 0 }
      return el('div', { className: 'dshrouter-stats' },
        el('div', { className: 'dshrouter-row' },
          el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')}: ${call.calls}`),
          el('span', { className: 'dshrouter-meta', style: call.errors > 0 ? { color: 'var(--dsw-alias-state-error-primary)' } : undefined }, `${t('statsErrors')}: ${call.errors}`),
          el('span', { className: 'dshrouter-meta' }, `${t('statsTokens')}: ${fmtTokens(call.inputTokens)} / ${fmtTokens(call.outputTokens)}`),
          call.totalMs > 0 && call.calls > 0 ? el('span', { className: 'dshrouter-meta' }, `${t('statsAvg')}: ${fmtMs(call.totalMs / call.calls)}`) : null,
          totals && totals.lastAt ? el('span', { className: 'dshrouter-meta' }, `${t('statsLast')}: ${timeOf(totals.lastAt)}`) : null),
        el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('statsPresetTotals'))),
        Array.isArray(models) && models.length > 0 ? el('table', { className: 'dshrouter-table' },
          el('thead', null, el('tr', null, el('th', null, t('fieldModel')), el('th', null, t('statsCalls')), el('th', null, t('statsErrors')), el('th', null, t('statsTokens')))),
          el('tbody', null, ...models.map((modelTotal) => el('tr', { key: modelTotal.model },
            el('td', null, modelTotal.model),
            el('td', null, modelTotal.calls),
            el('td', null, modelTotal.errors > 0 ? el('span', { className: 'dshrouter-error' }, modelTotal.errors) : modelTotal.errors),
            el('td', null, `${fmtTokens(modelTotal.inputTokens)} / ${fmtTokens(modelTotal.outputTokens)}`))))) : null,
        el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('statsPresetDaily'))),
        (!days || days.length === 0) ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : el('table', { className: 'dshrouter-table' },
          el('thead', null, el('tr', null,
            el('th', null, t('statsDate')), el('th', null, t('statsCalls')), el('th', null, t('statsErrors')), el('th', null, t('statsTokens')), el('th', null, t('statsDayMs')), el('th', null, t('statsCost')), ...(days.some((day) => Array.isArray(day.models) && day.models.length > 0) ? [el('th', null, t('fieldModel'))] : []))),
          el('tbody', null, ...[...days].reverse().map((day) => el('tr', { key: day.date },
            el('td', null, day.date),
            el('td', null, day.calls),
            el('td', null, day.errors),
            el('td', null, `${fmtTokens(day.inputTokens)} / ${fmtTokens(day.outputTokens)}`),
            el('td', null, fmtMs(day.ms)),
            el('td', null, fmtCost(day.cost)),
            ...(days.some((d) => Array.isArray(d.models) && d.models.length > 0)
              ? [el('td', null, Array.isArray(day.models) ? day.models.map((modelCount) => `${modelCount.model}×${modelCount.calls}`).join(', ') : '')]
              : []))))),
        el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('statsPresetRecent'))),
        (!recent || recent.length === 0) ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : el('table', { className: 'dshrouter-table' },
          el('thead', null, el('tr', null,
            el('th', null, t('statsTime')), el('th', null, t('statsProvider')), el('th', null, t('statsStatus')), el('th', null, t('statsAvg')))),
          el('tbody', null, ...recent.map((row, index) => el('tr', { key: `${row.at}-${index}` },
            el('td', null, timeOf(row.at)),
            el('td', null, `${statsProviderLabelOf(row, accountNames, t)}/${row.model || '?'}`),
            el('td', null, row.ok === false ? el('span', { className: 'dshrouter-error' }, t('statsFail')) : t('statsOk')),
            el('td', null, `${fmtMs(row.ms || 0)}${row.outputTokens ? ` · ${fmtTokens(row.outputTokens)} out` : ''}`)))))
      )
    }

    /**
     * EVO-017 R2 统一分组卡（三级卡壳：折叠头 + GroupStatsBody）——专业
     * Agent / 账号 / 全局 复用（预设卡因双口径结构保持 PresetStatsCard）。
     */
    function GroupStatsCard(props) {
      const { title, badge, summaryText, totals, days, recent, models, accountNames, expanded, t, onToggle } = props
      return el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          el('span', { className: 'dshrouter-name' }, title),
          badge ? el('span', { className: 'dshrouter-id' }, badge) : null,
          el('span', { className: 'dshrouter-meta' }, summaryText),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')),
        expanded ? el(GroupStatsBody, { totals, days, recent, models, accountNames, t }) : null)
    }

    /** 已配置账号卡片：折叠摘要 + 展开编辑（Base URL / API Key / 删除）与模型列表。 */
    function AccountCard(props) {
      const { provider, displayName, active, models, profile, total, buckets, expanded, draft, busy, notice, failure, declared, t, writable, onToggle, onField, onSave, onDiscover, onDelete } = props
      return el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          active ? el('span', { className: 'dshrouter-dot ok', title: t('accountDone') }) : el('span', { className: 'dshrouter-dot bad', title: t('accountDormant') }),
          el('span', { className: 'dshrouter-name' }, displayName),
          el('span', { className: 'dshrouter-id' }, provider),
          active ? el('span', { className: 'dshrouter-tag' }, t('accountActive')) : el('span', { className: 'dshrouter-tag' }, t('accountDormant')),
          el('span', { className: 'dshrouter-meta' }, `${models.length} ${t('accountModels')} · ${t('statsCalls')} ${total ? total.calls : 0} · ${total ? fmtTokens(total.inputTokens) : 0}/${total ? fmtTokens(total.outputTokens) : 0}`),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')),
        expanded ? el('div', { className: 'dshrouter-stats' },
          el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-subtitle' }, t('accountEditTitle'))),
          el('div', { className: 'dshrouter-row' },
            el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('accountApi')),
              el('select', { className: 'dshrouter-select', value: draft.api ?? 'openai-completions', onChange: (event) => onField('api', event.target.value) },
                el('option', { value: 'openai-completions' }, 'openai-completions'),
                el('option', { value: 'openai-responses' }, 'openai-responses'),
                el('option', { value: 'anthropic-messages' }, 'anthropic-messages'))),
            el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('accountBaseUrlRequired')),
              el('input', { className: 'dshrouter-input', value: draft.baseURL ?? '', placeholder: 'https://api.openai.com/v1', onChange: (event) => onField('baseURL', event.target.value) }),
              declared === true && profile && !profile.baseURL ? el('p', { className: 'dshrouter-error' }, t('accountNoBaseUrlWarn')) : null),
            el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('accountKeyOptional')),
              el('input', { className: 'dshrouter-input', type: 'password', autoComplete: 'off', value: draft.key ?? '', placeholder: t('accountKeyKeep'), onChange: (event) => onField('key', event.target.value) })),
            el('button', {
              type: 'button', className: 'dshrouter-button',
              disabled: busy || !writable || !(draft.baseURL ?? '').trim(),
              onClick: onSave,
            }, busy ? t('saving') : t('save'))),
          el('div', { className: 'dshrouter-row' },
            el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('accountModelsField')),
              el('input', { className: 'dshrouter-input', type: 'text', value: draft.models ?? '', placeholder: t('accountModelsField'), onChange: (event) => onField('models', event.target.value) })),
            el('button', {
              type: 'button', className: 'dshrouter-button ghost',
              disabled: busy || !writable || !(draft.baseURL ?? '').trim(),
              title: (draft.baseURL ?? '').trim() ? undefined : t('accountBaseUrlRequired'),
              onClick: onDiscover,
            }, busy ? t('oauthDiscovering') : t('fieldDiscover'))),
          el('p', { className: 'dshrouter-hint' }, t('accountEditHint')),
          notice ? el('p', { className: 'dshrouter-hint' }, notice) : null,
          el('div', { className: 'dshrouter-head' }, el('span', { className: 'dshrouter-meta' }, t('accountModelsTitle'))),
          failure ? el('p', { className: 'dshrouter-error' }, `模型目录解析失败：${failure}`) : null,
          models.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('accountMissing')) : el('table', { className: 'dshrouter-table' },
            el('thead', null, el('tr', null, el('th', null, t('fieldModel')), el('th', null, t('fieldName')), el('th', null, 'input'))),
            el('tbody', null, ...models.map((model) => el('tr', { key: model.id },
              el('td', null, model.id),
              el('td', null, model.name || '—'),
              el('td', null, (model.inputModalities ?? []).join(', ') || '—'))))),
          (buckets ?? []).length > 0 ? el(BarChart, { buckets, title: t('statsSeries') }) : null,
          el('div', { className: 'dshrouter-row' },
            el('span', { className: 'dshrouter-spacer' }),
            el('button', { type: 'button', className: 'dshrouter-button danger', disabled: busy || !writable, onClick: onDelete }, t('accountDelete')))) : null)
    }

    /** 账号列表末尾的「+」登录卡片。 */
    /** 账号列表末尾的「+」添加卡片：配置式表单（与「设置 → 模型」模型基座
     *  同款逻辑）——服务商 ID / 接口类型 / Base URL / 可选 API Key / 可选模型。
     *  默认模式：下拉选择已注册服务商，填 Key 即保存（对已有 profile 只写
     *  凭据不覆盖）；「＋ 自定义」切换为配置表单（覆盖式写入完整 profile）。 */
    function AddAccountCard(props) {
      const { t, adding, setAdding, account, setAccount, providers, writable, busy, failure, onLogin, accountProvider } = props
      if (!adding) {
        return el('div', { className: 'dshrouter-add', role: 'button', tabIndex: 0, onClick: () => setAdding(true), onKeyDown: (event) => { if (event.key === 'Enter') setAdding(true) } },
          el('span', { style: { fontSize: 18, lineHeight: 1 } }, '+'),
          el('span', null, t('addAccount')))
      }
      const custom = account.custom === true
      const idEmpty = !account.provider.trim()
      const urlEmpty = custom && !account.baseUrl.trim()
      const invalid = idEmpty || urlEmpty
      return el('div', { className: 'dshrouter-card' },
        el('div', { className: 'dshrouter-head' },
          el('span', { className: 'dshrouter-name' }, t('addAccount')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => { setAdding(false); setAccount((current) => ({ ...current, key: '', custom: false, models: '', failure: null })) } }, t('cancel'))),
        el('div', { className: 'dshrouter-row' },
          el('button', {
            type: 'button',
            className: 'dshrouter-chip' + (custom ? ' active' : ''),
            onClick: () => setAccount((current) => ({ ...current, custom: !current.custom, ...(current.custom ? {} : { provider: '' }), failure: null })),
          }, t('accountCustom'))),
        el('div', { className: 'dshrouter-row' },
          custom
            ? el('input', {
                className: 'dshrouter-input', style: { flex: '0 0 240px' }, type: 'text',
                placeholder: t('fieldProviderId'), 'aria-label': t('fieldProviderId'),
                value: account.provider, onChange: (event) => setAccount((current) => ({ ...current, provider: event.target.value })),
              })
            : el('select', {
                className: 'dshrouter-select', style: { flex: '0 0 240px' },
                value: account.provider,
                onChange: (event) => setAccount((current) => ({ ...current, provider: event.target.value, baseUrl: '' })),
              }, providers.filter((entry) => entry.settingsNs === 'llm-pi-ai').map((entry) =>
                el('option', { value: entry.provider, key: entry.provider }, `${entry.displayName} (${entry.provider})`))),
          custom ? el('select', {
            className: 'dshrouter-select', style: { flex: '0 0 190px' },
            value: account.api ?? 'openai-completions',
            onChange: (event) => setAccount((current) => ({ ...current, api: event.target.value })),
          },
          el('option', { value: 'openai-completions' }, 'openai-completions'),
          el('option', { value: 'openai-responses' }, 'openai-responses'),
          el('option', { value: 'anthropic-messages' }, 'anthropic-messages')) : null,
          el('input', {
            className: 'dshrouter-input', type: 'password', autoComplete: 'off',
            placeholder: custom ? t('accountKeyOptional') : t('accountKey'), 'aria-label': t('accountKey'),
            value: account.key, onChange: (event) => setAccount((current) => ({ ...current, key: event.target.value })),
          }),
          el('input', {
            className: 'dshrouter-input', type: 'text',
            placeholder: custom ? t('accountBaseUrlRequired') : t('accountBaseUrl'), 'aria-label': t('accountBaseUrl'),
            value: account.baseUrl, onChange: (event) => setAccount((current) => ({ ...current, baseUrl: event.target.value })),
          }),
          el('button', {
            type: 'button', className: 'dshrouter-button',
            disabled: busy || !writable || invalid || (!custom && !account.key.trim()),
            onClick: onLogin,
          }, busy ? t('saving') : (custom ? t('accountAddProvider') : t('save')))),
        custom ? el('div', { className: 'dshrouter-field' },
          el('span', { className: 'dshrouter-field-label' }, t('accountModelsField')),
          el('input', {
            className: 'dshrouter-input', type: 'text',
            placeholder: t('accountModelsField'), 'aria-label': t('accountModelsField'),
            value: account.models ?? '', onChange: (event) => setAccount((current) => ({ ...current, models: event.target.value })),
          })) : null,
        custom ? el('p', { className: 'dshrouter-hint' }, t('accountAddHint')) : null,
        custom && invalid ? el('p', { className: 'dshrouter-error' }, idEmpty ? t('fieldProviderId') : t('accountBaseUrlRequired')) : null,
        accountProvider ? el('p', { className: 'dshrouter-meta' }, `${accountProvider.provider} · ${accountProvider.active ? t('accountActive') : t('accountDormant')}${custom ? '（同名服务商已存在：保存将覆盖其配置）' : ''}`) : null,
        failure ? el('p', { className: 'dshrouter-error' }, failure) : null)
    }

    /** ChatGPT preset 账号卡（订阅登录区专属，EVO-002 Step 6 / EVO-006 转正；
     *  EVO-007 上移一级醒目位）：登录态圆点 + 登录/登出/删除 + 模型列表编辑
     *  （§3.6 凭据删除路径 / W-5 联动入口）。 */

    // FIX-015（c/d）：preset 默认模型三件套单一来源（P5——禁止复制字面量）：
    // placeholder、新建账号预填、存量已登录空 models 账号的编辑态实预填共用。
    const PRESET_MODEL_DEFAULTS = ['gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna']
    const PRESET_MODELS_PLACEHOLDER = PRESET_MODEL_DEFAULTS.join(', ')

    /** FIX-015 防御面：发现模型合并（discoverOauth 用）——**并集语义**：已存
     *  列表 ∪ 发现结果，保序去重。任何发现结果（含空/失败）都不可能缩小已有
     *  非空列表（写 oauthAccounts.<id>.models 的防缩小证明之一；判别见
     *  client-render FIX-015 块）。经 exports 暴露供判别测试直驱（FIX-012
     *  测试钩子先例——浏览器包内不可用 export 语句）。 */
    function mergePresetModels(existing, discovered) {
      const base = Array.isArray(existing) ? existing : []
      const extra = Array.isArray(discovered) ? discovered : []
      return [...new Set([...base, ...extra])]
    }

    /** EVO-010：订阅卡路由状态行文案（transport 归一 + 路由状态面判别——
     *  单一事实源，渲染与判别共用）。 */
    function presetRouteLine(t, entry, route) {
      const transport = entry && entry.transport === 'plugin' ? 'plugin' : 'host'
      if (transport === 'plugin') return t('presetRouteOff')
      if (!route || route.maintained !== true) return t('presetRouteOff')
      if (route.tokenInjected === 'failed') return t('presetRouteTokenFailed')
      if (route.degraded === true) return t('presetRouteDegraded')
      return t('presetRouteOk')
    }

    function PresetAccountCard(props) {
      const { id, entry, busy, notice, t, writable, onLogin, onLogout, onDelete, modelsValue, onModelsChange, onSaveModels, routeStatus, onTransportChange } = props
      const loggedIn = entry.presetLoggedIn === true
      const transport = entry.transport === 'plugin' ? 'plugin' : 'host'
      const routeLine = presetRouteLine(t, entry, routeStatus)
      return el('div', { className: 'dshrouter-card' },
        el('div', { className: 'dshrouter-head' },
          loggedIn ? el('span', { className: 'dshrouter-dot ok', title: t('oauthLoggedIn') }) : el('span', { className: 'dshrouter-dot bad', title: t('oauthNotLoggedIn') }),
          el('span', { className: 'dshrouter-name' }, entry.name || id),
          el('span', { className: 'dshrouter-id' }, id),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button', disabled: busy || !writable, onClick: onLogin }, busy ? t('presetLoggingIn') : t('presetLogin')),
          el('button', { type: 'button', className: 'dshrouter-button ghost', disabled: busy || !writable || !loggedIn, onClick: onLogout }, t('presetLogout')),
          el('button', { type: 'button', className: 'dshrouter-button danger', disabled: busy || !writable, onClick: onDelete }, t('presetDelete'))),
        // EVO-010：调用通路开关（宿主官方 openai-codex 路由 = 推荐；插件内置
        // = 降级手切，零重启）+ 官方路由状态行（维护/token 注入/降级）。
        el('div', { className: 'dshrouter-row' },
          el('div', { className: 'dshrouter-field', style: { flex: '0 0 220px' } },
            el('span', { className: 'dshrouter-field-label' }, t('presetTransportLabel')),
            el('select', {
              className: 'dshrouter-select', value: transport, disabled: busy || !writable,
              'aria-label': t('presetTransportLabel'),
              onChange: (event) => onTransportChange(event.target.value),
            },
              el('option', { value: 'host' }, t('presetTransportHost')),
              el('option', { value: 'plugin' }, t('presetTransportPlugin')))),
          el('div', { className: 'dshrouter-field', style: { flex: '1 1 260px' } },
            el('span', { className: 'dshrouter-field-label' }, 'openai-codex'),
            el('span', { className: 'dshrouter-meta' }, routeLine))),
        el('p', { className: 'dshrouter-hint' }, t('presetTransportHint')),
        el('div', { className: 'dshrouter-row' },
          el('div', { className: 'dshrouter-field', style: { flex: '1 1 320px' } },
            el('span', { className: 'dshrouter-field-label' }, t('oauthModels')),
            el('input', {
              className: 'dshrouter-input', value: modelsValue, placeholder: PRESET_MODELS_PLACEHOLDER,
              'aria-label': t('oauthModels'), onChange: (event) => onModelsChange(event.target.value),
            })),
          el('button', { type: 'button', className: 'dshrouter-button ghost', disabled: busy || !writable, onClick: onSaveModels }, t('save'))),
        el('p', { className: 'dshrouter-hint' }, t('presetModelsHint')),
        // FIX-015：已登录但模型列表为空 → 明示「选择器不会出现该账号」（用户
        // 实证被幽灵卡误导配置位置的根因——空模型 = 主 agent 侧零注册零观测）。
        loggedIn && (modelsValue ?? '').trim() === '' ? el('p', { className: 'dshrouter-error' }, t('presetModelsEmpty')) : null,
        // EVO-010：降级告警（服务端 notice 数据源——只提示，不改用户配置）。
        routeStatus && routeStatus.degraded === true && transport === 'host'
          ? el('p', { className: 'dshrouter-error' }, routeStatus.notice || t('presetRouteDegradedNotice'))
          : null,
        notice ? el('p', { className: 'dshrouter-hint' }, notice) : null)
    }

    /** 账号池卡片：折叠摘要 + 展开配置（策略 / 池内账号一键授权与健康度 / 增删）。 */
    function PoolCard(props) {
      const { id, pool, health, oauthEntries, tokenStates, expanded, draft, busy, notice, t, writable, onToggle, onField, onSave, onDelete, onAddAccount, onRemoveAccount, onOneClickAccount, onDiscoverAccount, onOauthAddToPool, onDeleteAccount, accountBusy, accountNotice } = props
      const healthById = new Map((health ?? []).map((entry) => [entry.accountId, entry]))
      const accounts = pool.accounts ?? []
      const totalCalls = (health ?? []).reduce((sum, entry) => sum + entry.calls, 0)
      const totalErrors = (health ?? []).reduce((sum, entry) => sum + entry.errors, 0)
      const summary = el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          el('span', { className: 'dshrouter-name' }, draft.name || id),
          el('span', { className: 'dshrouter-id' }, id),
          el('span', { className: 'dshrouter-tag' }, ({ healthy: t('poolStrategyHealthy'), 'usage-lowest': t('poolStrategyUsage'), 'round-robin': t('poolStrategyRoundRobin') }[pool.strategy] ?? pool.strategy)),
          el('span', { className: 'dshrouter-meta' }, `${accounts.length} ${t('accountModels')} · ${t('statsCalls')} ${totalCalls} · ${t('statsErrors')} ${totalErrors}`),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')))
      if (!expanded) return summary
      const availableAccounts = (oauthEntries ?? []).filter((entry) => !accounts.includes(entry.id))
      return el('div', { className: 'dshrouter-card' + (pool.enabled === false ? ' disabled' : '') },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: t('collapse') },
          el('span', { className: 'dshrouter-name' }, draft.name || id),
          el('span', { className: 'dshrouter-id' }, id),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, '▾')),
        el('div', { className: 'dshrouter-row' },
          el('div', { className: 'dshrouter-field' },
            el('span', { className: 'dshrouter-field-label' }, t('fieldName')),
            el('input', { className: 'dshrouter-input', value: draft.name ?? '', onChange: (event) => onField('name', event.target.value) })),
          el('div', { className: 'dshrouter-field', style: { flex: '0 0 240px' } },
            el('span', { className: 'dshrouter-field-label' }, t('poolStrategy')),
            el('select', { className: 'dshrouter-select', value: draft.strategy ?? 'healthy', onChange: (event) => onField('strategy', event.target.value) },
              el('option', { value: 'healthy' }, t('poolStrategyHealthy')),
              el('option', { value: 'usage-lowest' }, t('poolStrategyUsage')),
              el('option', { value: 'round-robin' }, t('poolStrategyRoundRobin'))))),
        el('div', { className: 'dshrouter-head', style: { marginTop: 4 } }, el('span', { className: 'dshrouter-subtitle' }, t('poolAccounts'))),
        accounts.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('poolNoAccounts')) : null,
        el('div', { className: 'dshrouter-stats' },
          ...accounts.map((accountId) => {
            const entry = (oauthEntries ?? []).find((candidate) => candidate.id === accountId)
            const tokenState = entry && entry.tokenRef ? tokenStates[entry.tokenRef] : undefined
            const configured = tokenState && tokenState.configured === true
            const healthEntry = healthById.get(accountId)
            const deleteNotice = accountNotice && accountNotice[accountId]
            return [
              el('div', { className: 'dshrouter-row', key: accountId },
                configured ? el('span', { className: 'dshrouter-dot ok', title: t('oauthLoggedIn') }) : el('span', { className: 'dshrouter-dot bad', title: t('oauthNotLoggedIn') }),
                el('span', { className: 'dshrouter-name' }, entry ? entry.name || accountId : accountId),
                el('span', { className: 'dshrouter-id' }, accountId),
                el('span', { className: 'dshrouter-meta' }, `${t('poolHealth')}: ${t('statsCalls')} ${healthEntry ? healthEntry.calls : 0} / ${t('statsErrors')} ${healthEntry ? healthEntry.errors : 0}${healthEntry && healthEntry.lastAt ? ` · ${timeOf(healthEntry.lastAt)}` : ''}`),
                el('span', { className: 'dshrouter-spacer' }),
                el('button', { type: 'button', className: 'dshrouter-button ghost', disabled: !writable || !entry || !entry.authUrl || (!entry.publicClient && !entry.clientId), title: !entry || !entry.authUrl || (!entry.publicClient && !entry.clientId) ? t('oauthNeedConfig') : undefined, onClick: () => onOneClickAccount(accountId) }, t('poolOneClick')),
                el('button', { type: 'button', className: 'dshrouter-button ghost', disabled: !entry || !entry.baseURL, onClick: () => onDiscoverAccount(accountId) }, t('oauthDiscover')),
                el('button', { type: 'button', className: 'dshrouter-button danger', disabled: !writable, onClick: () => onRemoveAccount(accountId) }, t('poolRemove')),
                // F-1（EVO-007 R0 返工）：整账号删除——unset 条目 + 凭据清理 +
                // 清全部池引用（preset 成员自动分流 W-5）。区别于「移除」（仅移出本池）。
                el('button', {
                  type: 'button', className: 'dshrouter-button danger',
                  disabled: !writable || !!((accountBusy ?? {})[accountId]),
                  title: t('oauthDeleteConfirm'),
                  onClick: () => onDeleteAccount(accountId),
                }, t('poolDeleteAccount'))),
              deleteNotice ? el('p', { className: 'dshrouter-hint', key: `notice-${accountId}` }, deleteNotice) : null,
            ]
          })),
        el('div', { className: 'dshrouter-row' },
          el('select', {
            className: 'dshrouter-select', style: { flex: '0 0 280px' },
            value: '',
            disabled: !writable,
            onChange: (event) => { if (event.target.value) onAddAccount(event.target.value) },
          },
            el('option', { value: '' }, `+ ${t('poolAddAccount')}`),
            ...availableAccounts.map((entry) => el('option', { value: entry.id, key: entry.id }, `${entry.name || entry.id} (${entry.id})`)))),
        el('div', { className: 'dshrouter-row' },
          el('span', { className: 'dshrouter-meta' }, `+ ${t('poolAddAccount')}:`),
          ...OAUTH_PRESETS.map((preset) => el('button', {
            type: 'button', key: preset.id, className: 'dshrouter-chip',
            disabled: !writable,
            onClick: () => onOauthAddToPool(id, preset.id, ''),
          }, `+ ${preset.label}`))),
        notice ? el('p', { className: 'dshrouter-hint' }, notice) : null,
        el('div', { className: 'dshrouter-row' },
          el('button', { type: 'button', className: 'dshrouter-button', disabled: busy || !writable, onClick: onSave }, busy ? t('saving') : t('save')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button danger', disabled: busy || !writable, onClick: onDelete }, t('poolDelete'))))
    }

    /** 账号池列表末尾的「+」创建卡片。 */
    function AddPoolCard(props) {
      const { t, adding, setAdding, newId, setNewId, idTaken, idInvalid, writable, onSave } = props
      if (!adding) {
        return el('div', { className: 'dshrouter-add', role: 'button', tabIndex: 0, onClick: () => setAdding(true), onKeyDown: (event) => { if (event.key === 'Enter') setAdding(true) } },
          el('span', { style: { fontSize: 18, lineHeight: 1 } }, '+'),
          el('span', null, t('addPool')))
      }
      return el('div', { className: 'dshrouter-card' },
        el('div', { className: 'dshrouter-head' },
          el('span', { className: 'dshrouter-name' }, t('addPool')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => { setAdding(false); setNewId('') } }, t('cancel'))),
        el('div', { className: 'dshrouter-row' },
          el('input', {
            className: 'dshrouter-input', style: { flex: '0 0 280px' },
            placeholder: t('poolAddPlaceholder'), 'aria-label': t('poolAddPlaceholder'),
            value: newId, onChange: (event) => setNewId(event.target.value.trim()),
          }),
          el('button', {
            type: 'button', className: 'dshrouter-button',
            disabled: !newId || idInvalid || idTaken || !writable,
            onClick: onSave,
          }, t('add'))),
        newId && idInvalid ? el('p', { className: 'dshrouter-error' }, t('invalidId')) : null,
        newId && idTaken ? el('p', { className: 'dshrouter-error' }, t('duplicateId')) : null)
    }

    /**
     * 分级分类卡片（页面顶层分区：专业 Agent / 多模态账号 / 统计信息）。
     * 头部整行可点击展开/收起；内部再嵌各分区自己的子卡片。
     */
    function CategoryCard(props) {
      const { title, summary, expanded, t, onToggle, children } = props
      return el('div', { className: 'dshrouter-category' },
        el('button', { type: 'button', className: 'dshrouter-category-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          el('span', { className: 'dshrouter-category-title' }, title),
          summary ? el('span', { className: 'dshrouter-meta' }, summary) : null,
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')),
        expanded ? el('div', { className: 'dshrouter-category-body' }, ...(Array.isArray(children) ? children : [children])) : null)
    }

    /**
     * EVO-013：宿主 agentPreset.list 返回归一（容忍数组 / {presets|items|roster}
     * 包裹形态；条目至少含字符串 id；字段缺省容错；broken 条目保留——UI 标记
     * 不可选）。失败由调用方按可观测降级处理（错误提示 + 空列表）。
     * broken 归一为字符串（R0 F-1）：宿主 wire 契约为非空原因字符串
     * （dsh-agent-presets `AgentPreset.broken?: string`，两处 zod 实证），非
     * 布尔——非空字符串 = 损坏；历史 boolean true 容忍映射 'broken'；其余
     * （含缺省/空串/false）= 未损坏。下游 disabled/标记一律真值判定。
     */
    function presetRosterItemsOf(value) {
      const raw = Array.isArray(value) ? value
        : Array.isArray(value?.presets) ? value.presets
          : Array.isArray(value?.items) ? value.items
            : Array.isArray(value?.roster) ? value.roster
              : []
      return raw
        .filter((entry) => entry && typeof entry === 'object' && typeof entry.id === 'string' && entry.id)
        .map((entry) => ({
          id: entry.id,
          name: typeof entry.name === 'string' ? entry.name : '',
          trust: entry.trust === 'system' || entry.trust === 'user' ? entry.trust : '',
          broken: typeof entry.broken === 'string' && entry.broken ? entry.broken : (entry.broken === true ? 'broken' : ''),
        }))
    }

    /**
     * EVO-013：provider/model 下拉对（数据源与专业 Agent 卡同款 providers /
     * state.models 分组；模型为 datalist 自由输入 + 分组选项）。group = 草稿里
     * 的模型组键（'main' | 'subagent'）；idPrefix 保证同页多实例的 datalist id
     * 唯一（AgentCard `dshrouter-models-${id}` 同款防碰撞）。
     */
    function PresetModelFields(props) {
      const { label, group, draft, providers, models, t, onGroupField, idPrefix } = props
      const listId = `dshrouter-preset-models-${idPrefix}-${group}`
      const current = draft[group] ?? { provider: '', model: '' }
      const selectedGroup = (models ?? []).find((entry) => entry.id === current.provider)
      const modelOptions = selectedGroup ? selectedGroup.models ?? [] : []
      const known = new Set(modelOptions.map((model) => model.id))
      const list = (current.model && !known.has(current.model) ? [current.model] : []).concat(modelOptions.map((model) => model.id))
      return el('div', { className: 'dshrouter-row' },
        el('div', { className: 'dshrouter-field' },
          el('span', { className: 'dshrouter-field-label' }, `${label} · ${t('presetsFieldProvider')}`),
          el('select', { className: 'dshrouter-select', value: current.provider ?? '', onChange: (event) => onGroupField(group, 'provider', event.target.value) },
            el('option', { value: '' }, `— ${t('presetsNotSet')} —`),
            ...(providers ?? []).filter((entry) => entry.active || entry.provider === current.provider).map((entry) => el('option', { value: entry.provider, key: entry.provider }, `${entry.displayName} (${entry.provider})`)))),
        el('div', { className: 'dshrouter-field' },
          el('span', { className: 'dshrouter-field-label' }, `${label} · ${t('presetsFieldModel')}`),
          el('input', { className: 'dshrouter-input', list: listId, value: current.model ?? '', placeholder: '—', onChange: (event) => onGroupField(group, 'model', event.target.value) }),
          el('datalist', { id: listId },
            ...list.map((modelId) => el('option', { value: modelId, key: modelId }, modelId)))))
    }

    /**
     * EVO-013：预设默认模型条目卡（一行摘要：预设 id · 主模型 · subagent 模型
     * 或「继承主 Agent」；点击展开编辑 + 删除；roster 无此 id 时提示「预设已
     * 不存在」）。
     */
    function PresetCard(props) {
      const { id, draft, rosterEntry, providers, models, busy, notice, expanded, t, writable, onToggle, onGroupField, onSave, onDelete } = props
      const mainSet = !!(draft.main?.provider && draft.main?.model)
      const subSet = !!(draft.subagent?.provider && draft.subagent?.model)
      const mainLabel = mainSet ? `${draft.main.provider}/${draft.main.model}` : t('presetsNotSet')
      const subLabel = subSet ? `${draft.subagent.provider}/${draft.subagent.model}` : t('presetsInheritMain')
      const head = el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
        el('span', { className: 'dshrouter-name' }, rosterEntry?.name || id),
        el('span', { className: 'dshrouter-id' }, id),
        el('span', { className: 'dshrouter-meta' }, `${t('presetsMainLabel')}: ${mainLabel}`),
        el('span', { className: 'dshrouter-meta' }, `${t('presetsSubagentLabel')}: ${subLabel}`),
        el('span', { className: 'dshrouter-spacer' }),
        el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸'))
      if (!expanded) {
        return el('div', { className: 'dshrouter-card' }, head)
      }
      return el('div', { className: 'dshrouter-card' },
        head,
        notice ? el('p', { className: 'dshrouter-hint' }, notice) : null,
        !rosterEntry ? el('p', { className: 'dshrouter-error' }, t('presetsMissing')) : null,
        el(PresetModelFields, { label: t('presetsMainLabel'), group: 'main', draft, providers, models, t, onGroupField, idPrefix: `preset-${id}` }),
        el('p', { className: 'dshrouter-hint' }, t('presetsNotSet')),
        el(PresetModelFields, { label: t('presetsSubagentLabel'), group: 'subagent', draft, providers, models, t, onGroupField, idPrefix: `preset-${id}` }),
        el('p', { className: 'dshrouter-hint' }, t('presetsSubagentEmpty')),
        el('div', { className: 'dshrouter-row' },
          el('button', { type: 'button', className: 'dshrouter-button', disabled: busy || !writable, onClick: onSave }, t('save')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button danger', disabled: busy || !writable, onClick: onDelete }, t('presetsDelete'))))
    }

    /** EVO-013：统一添加模板（折叠为「+ 添加预设配置」，展开 = 内联表单：
     *  预设下拉（roster 数据源，已配置排除、broken 不可选）→ 主模型两下拉 →
     *  subagent 模型两下拉（留空 = 继承主 Agent）→ 保存/取消）。 */
    function AddPresetCard(props) {
      const { t, adding, setAdding, newPresetId, onChoosePreset, newPresetDraft, onGroupField, rosterItems, configuredIds, providers, models, writable, busy, onSave } = props
      if (!adding) {
        return el('div', { className: 'dshrouter-add', role: 'button', tabIndex: 0, onClick: () => setAdding(true), onKeyDown: (event) => { if (event.key === 'Enter') setAdding(true) } },
          el('span', { style: { fontSize: 18, lineHeight: 1 } }, '+'),
          el('span', null, t('presetsAdd')))
      }
      const available = (rosterItems ?? []).filter((entry) => !(configuredIds ?? []).includes(entry.id))
      const selected = available.find((entry) => entry.id === newPresetId.trim())
      return el('div', { className: 'dshrouter-card' },
        el('div', { className: 'dshrouter-head' },
          el('span', { className: 'dshrouter-name' }, t('presetsAdd')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => { setAdding(false); onChoosePreset('') } }, t('cancel'))),
        el('p', { className: 'dshrouter-hint' }, t('presetsAddHint')),
        el('div', { className: 'dshrouter-field' },
          el('span', { className: 'dshrouter-field-label' }, t('presetsPresetLabel')),
          el('select', { className: 'dshrouter-select', 'aria-label': t('presetsPresetLabel'), value: newPresetId, onChange: (event) => onChoosePreset(event.target.value) },
            el('option', { value: '' }, `— ${t('presetsSelectPreset')} —`),
            ...available.map((entry) => el('option', { value: entry.id, key: entry.id, disabled: !!entry.broken },
              `${entry.name || entry.id} (${entry.id})${entry.trust ? ` · ${entry.trust}` : ''}${entry.broken ? ` · ${t('presetsBroken')}` : ''}`)))),
        el(PresetModelFields, { label: t('presetsMainLabel'), group: 'main', draft: newPresetDraft, providers, models, t, onGroupField, idPrefix: 'preset-add' }),
        el(PresetModelFields, { label: t('presetsSubagentLabel'), group: 'subagent', draft: newPresetDraft, providers, models, t, onGroupField, idPrefix: 'preset-add' }),
        el('p', { className: 'dshrouter-hint' }, t('presetsSubagentEmpty')),
        el('div', { className: 'dshrouter-row' },
          el('button', {
            type: 'button', className: 'dshrouter-button',
            disabled: !selected || !!selected.broken || busy || !writable,
            onClick: onSave,
          }, t('add'))),
        (rosterItems ?? []).length === 0 ? el('p', { className: 'dshrouter-hint' }, t('presetsRosterEmpty')) : null)
    }

    // ── 页面 ────────────────────────────────────────────────────────────────
    function AgentsPage(props) {
      const { api, health, remote, remoteReady, t, $on } = props
      const [ready, setReady] = useState(false)
      const [state, setState] = useState({ status: 'idle' })
      const [drafts, setDrafts] = useState({})
      const [newId, setNewId] = useState('')
      const [adding, setAdding] = useState(false)
      const [busy, setBusy] = useState({})
      const [notice, setNotice] = useState({})
      const [testResults, setTestResults] = useState({})
      const [cliStates, setCliStates] = useState({})
      const [cliDrafts, setCliDrafts] = useState({})
      const [cliBusy, setCliBusy] = useState({})
      const [cliNotice, setCliNotice] = useState({})
      const [addingCli, setAddingCli] = useState(false)
      const [expandedCli, setExpandedCli] = useState({})
      const [expandedAdvanced, setExpandedAdvanced] = useState(false)
      const [discover, setDiscover] = useState(null)
      const [account, setAccount] = useState({ provider: '', baseUrl: '', key: '', custom: false, api: 'openai-completions', models: '', busy: false, failure: null, state: null })
      const [stats, setStats] = useState(null)
      // EVO-004 出口⑤导出按钮 UI 面：range/level 选择 + 导出状态/提示。
      const [exportRange, setExportRange] = useState('7d')
      const [exportLevel, setExportLevel] = useState('agent')
      const [exportBusy, setExportBusy] = useState(false)
      const [exportNotice, setExportNotice] = useState('')
      const [expandedAgents, setExpandedAgents] = useState({})
      const [expandedAccounts, setExpandedAccounts] = useState({})
      const [accountDrafts, setAccountDrafts] = useState({})
      const [accountBusy, setAccountBusy] = useState({})
      const [accountNotice, setAccountNotice] = useState({})
      const [addingAccount, setAddingAccount] = useState(false)
      const [expandedStats, setExpandedStats] = useState({})
      // EVO-007：OAuth 官方登录区移除——expandedOauth/addingOauth/oauthDrafts/
      // oauthFlow 状态随区块一并删除（账号池经 pool* 状态与 oauthTokenStates
      // 维护；ChatGPT 预设账号经 oauthNotice/oauthBusy 维护）。
      const [oauthTokenStates, setOauthTokenStates] = useState({})
      const [oauthNotice, setOauthNotice] = useState({})
      const [oauthBusy, setOauthBusy] = useState({})
      /** ChatGPT preset 模型列表草稿（id → 逗号分隔串；EVO-002 Step 6）。 */
      const [presetModels, setPresetModels] = useState({})
      const [expandedPools, setExpandedPools] = useState({})
      const [addingPool, setAddingPool] = useState(false)
      const [newPoolId, setNewPoolId] = useState('')
      const [poolDrafts, setPoolDrafts] = useState({})
      const [poolBusy, setPoolBusy] = useState({})
      const [poolNotice, setPoolNotice] = useState({})
      // EVO-013：预设 Agent 默认模型——条目草稿/展开/忙碌与添加模板状态 +
      // 宿主预设罗盘（agentPreset.list；失败可观测降级为错误提示 + 空列表）。
      const [presetDrafts, setPresetDrafts] = useState({})
      const [expandedPresets, setExpandedPresets] = useState({})
      const [presetBusy, setPresetBusy] = useState({})
      const [presetNotice, setPresetNotice] = useState({})
      const [addingPreset, setAddingPreset] = useState(false)
      const [newPresetId, setNewPresetId] = useState('')
      const [presetRoster, setPresetRoster] = useState({ status: 'idle', items: [], failure: '' })
      // FIX-030-C：预设播种/修正诊断（最近事件环形——观测面随统计轮询刷新；
      // 服务端旧版本无该 RPC 时静默空表，不破坏页面）。
      const [presetDiag, setPresetDiag] = useState([])
      // ARCH-004 B1（§6.1）：宿主面健康一次性快照（hostVersions + FaceHealth
      // 缓存 + 诊断环形——router/hostFaceDiagnostics RPC；render 期零 probe，
      // §7.1 惰性纪律：渲染只读本快照缓存）。
      const [hostHealth, setHostHealth] = useState(null)
      // FIX-046：宿主面 RPC 取数失败/结果形状非法的**显式诊断**（P8 禁无观测
      // 吞错）——旧实现两侧静默（方法缺失不调用、rejection 吞为 undefined），
      // 真机表现 = 版本三值恒 '?' + 诊断恒空而面板显示「宿主面正常」。本状态
      // 承载 { code, detail }，由 HostHealthCard 上行（徽章计降级 + 诊断行）。
      const [hostFaceNotice, setHostFaceNotice] = useState(null)
      // ARCH-004 B2（§4.3 域 1）：本地 client 面健康快照（createClientRemotes
      // health() ——一次性 effect 探测后缓存，render 期零 probe，§7.1 惰性
      // 纪律）+ 面·code 降级表（load() 消费路径实测的降级短码——面级降级行）。
      const [faceHealth, setFaceHealth] = useState(null)
      const [faceFailures, setFaceFailures] = useState({})
      // 分级分类卡片：预设 Agent 与专业 Agent 核心区前置（预设默认折叠）；
      // 账号与统计默认折叠。
      // EVO-015 后调整（用户指令 2026-09-05）：专业 Agent 默认折叠——四张
      // 分类卡片统一默认折叠（用户按需展开；原 agents:true 默认展开取消）。
      const [expandedSection, setExpandedSection] = useState({ presets: false, agents: false, accounts: false, stats: false })
      const loadRef = useRef(() => {})

      const load = useCallback(async () => {
        const routerRemote = remote()
        if (!routerRemote) {
          setState((current) => ({ ...current, status: 'error', error: t('loadFailed') + ': remote.router 未就绪（宿主行 dsh-agent-router 未挂载或 Remote 挂载失败）' }))
          return
        }
        let configResponse, providersResponse, catalogResponse, settingsResponse
        try {
          ;[configResponse, providersResponse, catalogResponse, settingsResponse] = await Promise.all([
            routerRemote.config({}),
            api.llm.providers({}),
            routerRemote.catalog({}),
            api.settings.describe({}),
          ])
        } catch (error) {
          setState((current) => ({ ...current, status: 'error', error: messageOf(error) }))
          return
        }
        if (!configResponse.ok) { setState((current) => ({ ...current, status: 'error', error: configResponse.error.message })); return }
        const config = configResponse.value
        const providers = providersResponse.result.ok ? providersResponse.result.value.providers : []
        const catalog = catalogResponse.ok ? catalogResponse.value : null
        const llmPiAi = settingsResponse.result.ok ? viewOf(settingsResponse.result.value.namespaces, 'llm-pi-ai') : null
        // ARCH-004 B2：面·code 降级表（load() 消费路径实测——降级信封短码
        // 入页面数据面；非降级信封（无 code）= 空串，不影响旧路径）。
        const faceFailuresNow = { llm: hostFaceCodeOf(providersResponse), settings: hostFaceCodeOf(settingsResponse), session: '' }
        setState({
          status: 'ready',
          error: null,
          writable: config.writable !== false,
          revision: config.revision,
          value: config.value ?? null,
          user: config.user ?? null,
          providers,
          catalog,
          models: [],
          modelsFailure: null,
          llmPiAi,
          faceFailures: faceFailuresNow,
        })
        const groupResponse = await api.llm.models({})
        setState((current) => ({
          ...current,
          models: groupResponse.result.ok ? groupResponse.result.value.groups ?? [] : current.models,
          modelsFailure: groupResponse.result.ok ? groupResponse.result.value.failures ?? [] : current.modelsFailure,
          // B2：session 面（modelCatalog）降级短码并入面·code 表。
          faceFailures: { ...(current.faceFailures ?? {}), session: hostFaceCodeOf(groupResponse) },
        }))
        // EVO-013：宿主预设罗盘（wire 方法 agentPreset.list）——独立失败面：罗盘
        // 不可达不阻塞整页（卡片显示错误提示 + 空列表，添加下拉为空），P8 可观测。
        // FIX-022：宿主客户端 api 面方法组名是复数 agentPresets（wire 方法名保持
        // 单数——宿主自身命名不一致陷阱）；曾误用单数 api.agentPreset 导致真机
        // 「Cannot read properties of undefined (reading 'list')」（EV-123）。
        // P9 防御：优先复数、复数缺失回落单数形态；两者皆缺 → 明确诊断的
        // 可观测降级（P8：禁裸 TypeError 击穿）。
        const presetApi = api.agentPresets ?? api.agentPreset
        try {
          if (!presetApi || typeof presetApi.list !== 'function') {
            throw new Error('宿主连接未提供 agentPresets.list（复数/单数方法组均缺失——宿主版本过旧或连接面不完整）')
          }
          const presetResponse = await presetApi.list({})
          const presetValue = presetResponse && presetResponse.result && presetResponse.result.ok ? presetResponse.result.value : null
          if (presetValue !== null) {
            setPresetRoster({ status: 'ready', items: presetRosterItemsOf(presetValue), failure: '' })
          } else {
            setPresetRoster({ status: 'error', items: [], failure: presetResponse?.result?.error?.message ?? '' })
            setFaceFailures((current) => ({ ...current, agentPresets: presetResponse?.result?.error?.code ?? '' }))
          }
        } catch (error) {
          setPresetRoster({ status: 'error', items: [], failure: messageOf(error) })
        }
      }, [api, remote, t])

      useEffect(() => {
        loadRef.current = load
      }, [load])

      useEffect(() => {
        let alive = true
        remoteReady.then(() => { if (alive) setReady(true) }, () => { if (alive) setReady(true) })
        return () => { alive = false }
      }, [remoteReady])

      // ── OAuth 账号 token 状态：hooks 必须先于所有条件提前返回声明，
      //    否则 status 从 idle→ready 时 hook 数量变化触发 React #310 ────
      const oauthEntries = state.catalog?.oauthAccounts ?? []
      const oauthRefsKey = oauthEntries.map((entry) => entry.tokenRef).filter(Boolean).join('|')
      const refreshOauthTokens = useCallback(async () => {
        const refs = oauthRefsKey ? oauthRefsKey.split('|') : []
        if (refs.length === 0) return
        const response = await api.credentials.describe({ refs })
        if (response.result.ok) {
          setOauthTokenStates((current) => ({ ...current, ...Object.fromEntries(Object.entries(response.result.value.credentials ?? {}).map(([ref, info]) => [ref, info])) }))
        } else if (hostFaceCodeOf(response)) {
          // ARCH-004 B2：credentials 面降级短码并入面·code 表（P8 可观测）。
          setFaceFailures((current) => ({ ...current, credentials: hostFaceCodeOf(response) }))
        }
      }, [api, oauthRefsKey])

      useEffect(() => {
        if (state.status === 'ready') refreshOauthTokens()
      }, [state.status, refreshOauthTokens])

      useEffect(() => {
        if (!ready) return
        load()
        // 书签回传的 access token：主页已自动写入 credentials，这里补发提示并刷新登录态。
        const tokenBack = window.sessionStorage.getItem('dshrouter-token-saved')
        if (tokenBack) {
          window.sessionStorage.removeItem('dshrouter-token-saved')
          setOauthNotice((current) => ({ ...current, [tokenBack]: t('oauthTokenBack') }))
          refreshOauthTokens()
        }
        // ARCH-004 B5（§4.3 域 4 / W-4）：页面三条转发订阅收敛 events 域镜像
        // ——共享 listener（与 apply 级 settings/document-updated 订阅聚合）+
        // 白名单拒绝外名 + 卸载聚合。
        // Analyst D-2 死订阅修复：旧 `credentials/updated` 不在宿主转发白名单
        // （dsh-api-remotes/lib/types/remote-events.js 全表无此名 → 宿主从未转发
        // → 凭据变化不触发刷新，死订阅实证）；正名 `credentials/reference-updated`
        // （同表 API_REMOTE_FORWARDED_EVENTS 条目内，凭据引用变化转发事件）。
        const disposeEvents = subscribeClientEvents($on, [
          { event: 'settings/document-updated', consumer: 'settings-page-reload', handler: (ns) => {
            if (ns === 'router' || ns === 'llm-pi-ai' || ns === 'llm-deepseek' || ns === 'agent-default-model') loadRef.current()
          } },
          { event: 'credentials/reference-updated', consumer: 'settings-page-credentials', handler: () => loadRef.current() },
          { event: 'llm/adapters-updated', consumer: 'settings-page-adapters', handler: () => loadRef.current() },
        ])
        return () => { disposeEvents() }
      }, [ready, $on, load, refreshOauthTokens])

      // 实时用量轮询（页签打开期间每 2 秒刷新一次）
      // ARCH-004 B5（D1-10 / W-1 症状②治理，三措施）：① 页面隐藏暂停——tick 在
      // document.hidden 期间直接返回（隐藏态零 RPC），visibilitychange 恢复可见
      // 立即补拍一次（实时语义保留，不丢一轮）；② 双 RPC 同拍——stats +
      // presetDiagnostics 由同一 tick 触发（单 2s timer，无相位拍击/突发密集）；
      // ③ 不新增常驻 timer（判别断言见 tests/client-render.mjs B5 组：隐藏态 0
      // RPC / 每拍恰 2 RPC / ≤1 RPC/s 量级 / timer census 不变）。
      useEffect(() => {
        if (!ready) return
        let alive = true
        // FIX-047（F-16）：stats 轮询失败的**边沿触发**机录状态——持续失败期只在
        // 首拍记一条（见下方 rejection 分支注释），成功一拍即复位。
        let statsFailureRecorded = false
        const poll = () => {
          const routerRemote = remote()
          if (!routerRemote) return
          routerRemote.stats({}).then((response) => {
            statsFailureRecorded = false
            if (alive && response.ok) setStats(response.value)
          }, (error) => {
            // FIX-047（F-16，R0 P3／P8 同族）：旧实现此处 `() => undefined`
            // 静默吞错——stats 轮询失败在上屏面与诊断环均无痕。改为与
            // host-face-* 同一体系机录（noteHostFaceDiag 镜像环，不新增第二
            // 观测通道）：环条目由 health() 上行（createClientRemotes
            // health().diag），健康面板「最近宿主诊断事件」行即其消费面。
            // **边沿触发**（如实登记口径）：一个失败周期只记首拍一条——逐拍
            // 追加会在 64 条环上限（HOST_FACE_DIAG_LIMIT）内挤掉既有诊断事件
            // （apply 期 inject-face-missing 等），即观测面自伤；成功一拍复位，
            // 故「失败 → 恢复 → 再失败」仍各有一条。持续性由「无新条目 + 无恢复
            // 复位」推断（与 host-face 成功路径只清 notice、不记恢复条目同口径）。
            if (!alive || statsFailureRecorded) return
            statsFailureRecorded = true
            noteHostFaceDiag({
              kind: 'host-face-rpc',
              face: 'remote.router',
              code: 'host-face-stats-rejected',
              detail: String(error?.message ?? error).slice(0, 160),
            })
          })
          // FIX-030-C：预设诊断随轮询刷新（方法缺失 = 旧服务端，静默跳过）。
          if (typeof routerRemote.presetDiagnostics === 'function') {
            routerRemote.presetDiagnostics({}).then((response) => {
              if (alive && response.ok && Array.isArray(response.value?.entries)) setPresetDiag(response.value.entries.slice(0, 8))
            }, () => undefined)
          }
        }
        const visible = () => !(window.document && window.document.hidden === true)
        const tick = () => { if (alive && visible()) poll() }
        tick()
        const timer = window.setInterval(tick, 2000)
        const onVisibilityChange = () => { tick() }
        try { window.document?.addEventListener?.('visibilitychange', onVisibilityChange) } catch { /* 无 document 面（测试/异构宿主）→ 仅 timer 面 */ }
        return () => {
          alive = false
          window.clearInterval(timer)
          try { window.document?.removeEventListener?.('visibilitychange', onVisibilityChange) } catch { /* 卸载尽力而为 */ }
        }
      }, [ready, remote])

      // ARCH-004 B1（§6.1/D4）：宿主面健康一次性快照——打开期仅取一次，
      // 绝不进 2s 轮询（D1-10 治理纪律：设置页常驻 RPC 面不加码）；
      // render 期零 probe 判别锚点（tests/host-abi-health.mjs §3——调用点
      // 唯一且位于本 effect 内，面板只读 hostHealth 状态缓存）。
      // FIX-046（P8：失败与降级 MUST 可观测）：旧实现三处静默——① 方法缺失
      // 直接跳过（presetDiagnostics 方法存在性先例沿用过度：那一处是惰性观测
      // 面的可选降级，版本/诊断面是面板主数据源，缺它即面板失真）；② rejection
      // 经 `() => undefined` 吞噬；③ `ok:false` / 结果形状非法静默保留 null。
      // 三者合并表现为「本地 face 探针全绿 + 版本三值 '?' + 诊断恒空」，真机
      // 报障无从定因。现改为四态分类（method-missing / rpc-failed /
      // result-invalid / ok），失败一律 noteHostFaceDiag 机录 + 上屏。
      useEffect(() => {
        if (!ready) return
        let alive = true
        // ARCH-004 B2（§7.1「健康面板打开」时机——一次性本地探测，绝不进
        // 2s 轮询）：client remote 五面存在性/形状快照（徽章 ⚠ 数据源——
        // remote.* 客户端 fiber 面 Node 侧注册表不可见，故页面本地探测并入
        // HostHealthCard；B1 的 RPC 面快照保留不变）。
        if (typeof health === 'function') {
          const localFaces = health()
          if (alive && localFaces && typeof localFaces === 'object') setFaceHealth(localFaces)
        }
        // FIX-046：诊断短码/详情提取（宿主侧错误信封 {code,message} 优先，
        // 无 code 的 rejection/Error 回落 name/message；长度按环形白名单截断）。
        const failNotice = (code, detail) => ({
          code: typeof code === 'string' && code ? code.slice(0, 48) : 'host-face-unknown',
          detail: typeof detail === 'string' ? detail.slice(0, 160) : String(detail ?? '').slice(0, 160),
        })
        const reportFailure = (code, detail) => {
          if (!alive) return
          const notice = failNotice(code, detail)
          // FIX-046 R0 F-4／R1 更正：本行**不是**自激重渲染防线。它只在
          // code+detail 均相同时保留原对象（notice 身份稳定）；同 effect 内
          // setFaceHealth(localFaces) 与成功路径 setHostHealth(response.value)
          // 每次重跑写新身份，该守卫不覆盖它们。R0 已证伪的「宿主 props.remote
          // 每次渲染新函数 ⇒ effect 重跑 ⇒ 自激」前提在判别夹具中不可复现
          // （tests/client-render.mjs 单次构造 root element、settle 复用同一
          // props 身份 ⇒ deps 稳定 ⇒ effect 不重跑），故此处不作防线声称。
          // 影响面为零：notice 写入本身幂等，无重复渲染放大。
          setHostFaceNotice((current) => (current && current.code === notice.code && current.detail === notice.detail ? current : notice))
          // FIX-047（F-12，R0 P3）：失败即清陈旧 RPC 快照——effect 重跑（deps
          // 变化）后失败时，上一次成功的 hostHealth 仍被面板合并（faces 行 /
          // hostVersions），与失败行并存 ⇒「旧成功值 + 新失败态」不可区分。
          // 清空后失败态只剩本地 face 快照（面数据源语义不变：本地面仍由
          // health() 一次性探测上行）。
          setHostHealth(null)
          noteHostFaceDiag({ kind: 'host-face-rpc', face: 'remote.router', code: notice.code, detail: notice.detail })
        }
        const routerRemote = remote()
        if (!routerRemote) {
          reportFailure('host-face-missing', 'remote.router 命名空间未挂载（宿主行 dsh-agent-router 未挂载或 Remote 挂载失败）')
          return () => { alive = false }
        }
        if (typeof routerRemote.hostFaceDiagnostics !== 'function') {
          // FIX-047（N-6，R1 P3）：detail 中性化——原文案只指宿主侧
          // （「宿主服务端未注册该方法——插件与宿主服务端版本不一致？」），
          // 而真机该短码的实际成因是**浏览器侧 $mount 挂载列表**缺
          // descriptor（EV-217），本批已修复。缺失面两侧皆可能，故不预设
          // 因果（禁未证断言）：只如实列出「谁没提供该方法」。
          reportFailure('host-face-shape: hostFaceDiagnostics', '宿主面版本/诊断 RPC 方法缺失（浏览器侧挂载列表或宿主命名空间未提供该方法）')
          return () => { alive = false }
        }
        routerRemote.hostFaceDiagnostics({}).then((response) => {
          if (!alive) return
          if (!response || typeof response !== 'object' || typeof response.ok !== 'boolean') {
            reportFailure('host-face-result-invalid', `宿主面取数响应非形状信封：${String(response).slice(0, 120)}`)
            return
          }
          if (!response.ok) {
            const error = response.error ?? {}
            reportFailure(error.code ?? 'host-face-rpc-failed', error.message ?? String(response.error ?? '未知错误'))
            return
          }
          if (!response.value || typeof response.value !== 'object' || typeof response.value.hostVersions !== 'object' || response.value.hostVersions === null) {
            reportFailure('host-face-result-shape', `宿主面取数结果缺 hostVersions 对象：${JSON.stringify(response.value).slice(0, 120)}`)
            return
          }
          setHostHealth(response.value)
          setHostFaceNotice(null)
        }, (error) => {
          reportFailure(error?.code ?? error?.name ?? 'host-face-call-rejected', error?.message ?? String(error))
        })
        return () => { alive = false }
      }, [ready, remote, health])

      const clearStats = async () => {
        const routerRemote = remote()
        if (!routerRemote) return
        await routerRemote.reset({})
        const response = await routerRemote.stats({})
        if (response.ok) setStats(response.value)
      }

      /** EVO-004 出口⑤导出按钮：调 statsExport RPC（range/level）→ CSV 文本 →
       *  浏览器下载。宿主行缺 statsExport（未重启）显式报错，绝不静默失败。 */
      const exportStats = async () => {
        const routerRemote = remote()
        if (!routerRemote || typeof routerRemote.statsExport !== 'function') {
          setExportNotice(t('statsExportMissing'))
          return
        }
        setExportBusy(true)
        try {
          const response = await routerRemote.statsExport({ range: exportRange, level: exportLevel })
          if (response && response.ok && response.value && response.value.ok) {
            downloadCsv(response.value.csv, 'dsh-agent-router-stats.csv')
            setExportNotice(`${t('statsExportDone')}${response.value.message ?? ''}`)
          } else {
            setExportNotice(response && response.error && response.error.message ? response.error.message : (response && response.value && response.value.message ? response.value.message : t('statsExportFailed')))
          }
        } catch (error) {
          setExportNotice(`${t('statsExportFailed')}：${messageOf(error)}`)
        } finally {
          setExportBusy(false)
        }
      }

      // ── cli 子代理：登录状态 / 交互式登录 / 模型列表 ──────────────────
      // 接口探测：宿主行旧版本（未重启）时 remote 缺少 cliStatus/cliLogin/
      // cliModels——一律显式报错，绝不静默失败（按钮"无效"的第一大原因）。
      const cliRemote = () => {
        const routerRemote = remote()
        if (!routerRemote) return null
        return typeof routerRemote.cliStatus === 'function' && typeof routerRemote.cliLogin === 'function' && typeof routerRemote.cliModels === 'function'
          ? routerRemote
          : null
      }

      const runCliStatus = async (id, stateKey = id) => {
        const routerRemote = cliRemote()
        if (!routerRemote) {
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), statusBusy: false, statusMessage: t('cliRemoteMissing') } }))
          return
        }
        setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), statusBusy: true } }))
        try {
          const response = await routerRemote.cliStatus({ agentId: id })
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), statusBusy: false, loggedIn: response.ok ? response.value.loggedIn : undefined, statusMessage: response.ok ? response.value.message : response.error.message } }))
        } catch (error) {
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), statusBusy: false, statusMessage: `${t('cliRemoteFailed')}：${messageOf(error)}` } }))
        }
      }

      const runCliLogin = async (id, stateKey = id) => {
        const routerRemote = cliRemote()
        if (!routerRemote) {
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginBusy: false, loginError: true, loginNotice: t('cliRemoteMissing') } }))
          return
        }
        setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginBusy: true, loginError: false, loginNotice: '' } }))
        try {
          const response = await routerRemote.cliLogin({ agentId: id })
          if (!response.ok) {
            setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginBusy: false, loginError: true, loginNotice: response.error.message } }))
            return
          }
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginNotice: response.value.message } }))
          // 轮询登录状态：最多 20 次 × 3 秒，登录成功即停。轮询期间 loginBusy
          // 保持 true（按钮显示「等待登录…」并禁用，防止重复弹窗）；轮询任一
          // 失败与轮询耗尽都必须复位 busy 并给出明确提示，避免按钮永久卡死。
          for (let attempt = 0; attempt < 20; attempt++) {
            await new Promise((done) => window.setTimeout(done, 3000))
            try {
              const poll = await routerRemote.cliStatus({ agentId: id })
              const loggedIn = poll.ok && poll.value.loggedIn === true
              // 每次轮询都镜像探测结果（含负向）：登录流程中状态以端点为准，
              // 轮询耗尽时 chip 与按钮如实回到「未登录」而不是残留旧值。
              setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loggedIn: poll.ok ? poll.value.loggedIn === true : undefined, statusMessage: poll.ok ? poll.value.message : (current[stateKey]?.statusMessage ?? '') } }))
              if (loggedIn) {
                setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginBusy: false, loginError: false, loginNotice: t('cliStatusLoggedIn') + `：${poll.value.message}` } }))
                return
              }
            } catch (pollError) {
              setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginBusy: false, loginError: true, loginNotice: `${t('cliRemoteFailed')}：${messageOf(pollError)}` } }))
              return
            }
          }
          // 轮询耗尽（60 秒内未检测到登录完成）：复位并指引用户手动刷新状态。
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginBusy: false, loginError: true, loginNotice: t('cliLoginTimeoutHint') } }))
        } catch (error) {
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), loginBusy: false, loginError: true, loginNotice: `${t('cliRemoteFailed')}：${messageOf(error)}` } }))
        }
      }

      const runCliModels = async (id, stateKey = id) => {
        const routerRemote = cliRemote()
        if (!routerRemote) {
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), modelsMessage: t('cliRemoteMissing') } }))
          return
        }
        setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), modelsBusy: true } }))
        try {
          const response = await routerRemote.cliModels({ agentId: id })
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), modelsBusy: false, models: response.ok ? response.value.models : [], modelsMessage: response.ok ? response.value.message : response.error.message } }))
        } catch (error) {
          setCliStates((current) => ({ ...current, [stateKey]: { ...(current[stateKey] ?? {}), modelsBusy: false, modelsMessage: `${t('cliRemoteFailed')}：${messageOf(error)}` } }))
        }
      }

      // 目录就绪后自动探测 CLI 子代理条目与旧形态 cli agent 的登录状态（幂等，可手动刷新）。
      useEffect(() => {
        if (state.status !== 'ready') return
        for (const entry of state.catalog?.cliAgents ?? []) {
          if (entry.enabled === false) continue
          const cached = cliStates[entry.id]
          if (cached?.statusBusy) continue
          if (!cached || cached.loggedIn === undefined) void runCliStatus(entry.id)
        }
        for (const agent of state.catalog?.agents ?? []) {
          if (agent.type !== 'cli' || agent.cliAgent) continue
          const key = `agent:${agent.id}`
          const cached = cliStates[key]
          if (cached?.statusBusy) continue
          if (!cached || cached.loggedIn === undefined) void runCliStatus(agent.id, key)
        }
        // cliStates 不在依赖内：避免状态更新触发循环；手动刷新走按钮。
        // eslint-disable-next-line react-hooks/exhaustive-deps
      }, [state.status, state.catalog])

      const mutate = useCallback(async (ops) => {
        const routerRemote = remote()
        if (!routerRemote) return { ok: false, message: t('loadFailed') }
        const response = await routerRemote.save({
          ops,
          ...(state.revision !== undefined ? { expectedRevision: state.revision } : {}),
        })
        if (!response.ok) {
          const detail = response.error && response.error.message ? response.error.message : 'save failed'
          return { ok: false, message: /conflict|moved|revision/i.test(detail) ? t('conflict') : detail }
        }
        setState((current) => ({ ...current, revision: response.value.revision }))
        await load()
        return { ok: true }
      }, [remote, state.revision, load, t])

      const agentValue = (id) => {
        const v = state.value
        return v && v.agents ? v.agents[id] : null
      }
      const defaultDraft = () => ({
        name: '', type: 'chat', enabled: true, description: '', capabilities: [],
        provider: '', model: '', account: '', reasoningEffort: '', temperature: 0, maxTokens: 0,
        maxRounds: 1, systemPrompt: '', endpoint: '', imageSize: '1024x1024', apiKeyEnv: '', tools: [],
        command: '', args: '', timeoutMs: 0, maxConcurrent: 1, cliAgent: '',
      })
      const draftOf = (id) => drafts[id] ?? agentValue(id) ?? defaultDraft()
      const setDraft = (id, patch) => setDrafts((current) => ({ ...current, [id]: { ...draftOf(id), ...patch } }))
      const setDraftField = (id, key, value) => setDraft(id, { [key]: value })

      const saveAgent = async (id, isNew) => {
        if (isNew && (!ID_PATTERN.test(id) || id === '')) return
        if (isNew && state.value?.agents?.[id]) return
        setBusy((current) => ({ ...current, [id]: true }))
        const draft = draftOf(id)
        const outcome = await mutate([{ op: 'set', path: ['agents', id], value: draft }])
        setBusy((current) => ({ ...current, [id]: false }))
        if (outcome.ok) setNotice((current) => ({ ...current, [id]: t('saved') }))
        else setNotice((current) => ({ ...current, [id]: outcome.message }))
        if (isNew) { setNewId(''); setAdding(false) }
      }

      const deleteAgent = async (id) => {
        if (!window.confirm(t('confirmDelete'))) return
        setBusy((current) => ({ ...current, [id]: true }))
        await mutate([{ op: 'unset', path: ['agents', id] }])
        setBusy((current) => ({ ...current, [id]: false }))
        setDrafts((current) => { const next = { ...current }; delete next[id]; return next })
      }

      const toggleMaster = async () => {
        await mutate([{ op: 'set', path: ['enabled'], value: !(state.value && state.value.enabled !== false) }])
      }

      const runTest = async (id) => {
        const routerRemote = remote()
        if (!routerRemote) return
        setTestResults((current) => ({ ...current, [id]: { busy: true } }))
        const response = await routerRemote.test({ agentId: id })
        setTestResults((current) => ({ ...current, [id]: { busy: false, ok: response.ok, message: response.ok ? response.value.message : response.error.message } }))
      }

      const doLogin = async () => {
        const provider = account.provider.trim()
        const key = account.key.trim()
        const custom = account.custom === true
        if (!provider) return
        if (custom && !account.baseUrl.trim()) {
          setAccount((current) => ({ ...current, failure: t('accountBaseUrlRequired') }))
          return
        }
        if (!custom && !key) return
        setAccount((current) => ({ ...current, busy: true, failure: null }))
        try {
          const ref = deriveKeyRef(provider)
          const settingsResponse = await api.settings.describe({})
          if (!settingsResponse.result.ok) throw new Error(settingsResponse.result.error.message)
          const namespaces = settingsResponse.result.value.namespaces
          const llmView = viewOf(namespaces, 'llm-pi-ai')
          if (!llmView) throw new Error('llm-pi-ai namespace 不可用：请确认该适配器已挂载')
          if (custom) {
            // 配置式添加（与「设置 → 模型」模型基座同款逻辑）：覆盖式写入
            // 完整 provider profile；无凭据 = 免鉴权本地部署直连。
            // 自定义（未内置目录）路由的 profile 必须列出模型——宿主
            // llm-pi-ai 校验器会以 "resolves no models" 拒绝无模型列表的
            // 写入。因此模型留空时，保存前自动向端点拉取一次（与账号卡片
            // 「发现模型」同款探测，apiKey 一次性携带、绝不落盘），拉到即
            // 随 profile 一并写入；拉不到则中止并给出明确指引，绝不写入
            // 半成品配置。同名内置服务商（目录路由）保持旧行为：不写
            // models 即按目录默认模型服务。
            const apiType = ['openai-completions', 'openai-responses', 'anthropic-messages'].includes(account.api) ? account.api : 'openai-completions'
            const modelIds = String(account.models ?? '').split(',').map((item) => item.trim()).filter(Boolean)
            const catalogRoute = !!(accountProvider && accountProvider.declared === false)
            let modelEntries = modelIds.length > 0 ? modelIds.map((id) => ({ id })) : null
            let autoDiscovered = 0
            if (modelIds.length === 0 && !catalogRoute) {
              let discovered
              try {
                discovered = await probeProviderModels(api, { provider, baseURL: account.baseUrl.trim(), api: apiType, apiKey: key })
              } catch (error) {
                throw new Error(`${t('accountDiscoverFailed')}：${messageOf(error)}。${t('accountModelsRequiredHint')}`)
              }
              if (discovered.length === 0) throw new Error(t('accountDiscoverEmpty'))
              modelEntries = modelEntriesOf(discovered)
              autoDiscovered = discovered.length
            }
            const profile = {
              api: apiType,
              ...(account.baseUrl.trim() ? { baseURL: account.baseUrl.trim() } : {}),
              ...(key ? { apiKeyEnv: ref } : {}),
              // 中转/本地部署常同时服务文本与多模态模型：默认输入声明含
              // image，避免 pi-ai 默认纯文本导致视觉调用被拒。
              defaultInput: ['text', 'image'],
              ...(modelEntries !== null ? { models: modelEntries } : {}),
            }
            const response = await api.settings.mutate({
              ns: 'llm-pi-ai',
              ops: [{ op: 'set', path: ['providers', provider], value: profile }],
            })
            if (!response.result.ok) throw new Error(response.result.error.message)
            if (key) {
              const stored = await api.credentials.set({ ref, value: key })
              if (!stored.result.ok) throw new Error(stored.result.error.message)
            }
            setAccount((current) => ({ ...current, busy: false, provider: '', key: '', models: '', failure: null }))
            if (autoDiscovered > 0) setAccountNotice((current) => ({ ...current, [provider]: t('accountDiscovered')(autoDiscovered) }))
            await load()
            return
          }
          // 下拉模式：对已注册服务商保存凭据；已有 profile 不覆盖。
          const existing = llmView.value && llmView.value.providers ? llmView.value.providers[provider] : undefined
          if (existing === undefined) {
            const profile = {
              apiKeyEnv: ref,
              ...(account.baseUrl.trim() ? { baseURL: account.baseUrl.trim() } : {}),
            }
            const response = await api.settings.mutate({
              ns: 'llm-pi-ai',
              ops: [{ op: 'set', path: ['providers', provider], value: profile }],
            })
            if (!response.result.ok) throw new Error(response.result.error.message)
          }
          const stored = await api.credentials.set({ ref, value: key })
          if (!stored.result.ok) throw new Error(stored.result.error.message)
          setAccount((current) => ({ ...current, busy: false, key: '', failure: null }))
          await load()
        } catch (error) {
          setAccount((current) => ({ ...current, busy: false, failure: messageOf(error) }))
        }
      }

      useEffect(() => {
        if (state.status !== 'ready') return
        let alive = true
        const ref = deriveKeyRef(account.provider)
        api.credentials.describe({ refs: [ref] }).then((response) => {
          if (alive && response.result.ok) setAccount((current) => ({ ...current, state: response.result.value.credentials[ref] ?? null }))
        }, () => undefined)
        return () => { alive = false }
      }, [state.status, account.provider, api])

      if (state.status === 'idle') return el('div', { className: 'dshrouter-section' }, el('p', { className: 'dshrouter-intro' }, '…'))
      if (state.status === 'error') {
        return el('div', { className: 'dshrouter-section' },
          el('p', { className: 'dshrouter-error' }, `${t('loadFailed')}: ${state.error}`),
          el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => load() }, t('retry')))
      }
      const value = state.value ?? { enabled: true, agents: {} }
      const enabled = value.enabled !== false
      const agentIds = Object.keys(value.agents ?? {}).sort()
      const catalogById = new Map((state.catalog?.agents ?? []).map((entry) => [entry.id, entry]))
      const providers = state.providers ?? []
      const providerEntry = (provider) => providers.find((entry) => entry.provider === provider)
      const accountProvider = providerEntry(account.provider)
      const idTaken = agentIds.includes(newId.trim())
      const idInvalid = newId.trim() !== '' && !ID_PATTERN.test(newId.trim())

      // 统计归一视图
      // FIX-031：账号索引一律按**清洁账号键**（accountDisplayKeyOf）建键——服务端
      // 快照下发的 provider/key 已是规范实体，镜像一次保证滚动期新旧行同键空间；
      // 专业 agent 与「主模型」按规范 agent 键建键（内部 'twin'/'main' 归一）。
      const statsTotals = stats ? new Map((stats.totals ?? []).map((entry) => [agentDisplayKeyOf(entry.agentId), entry])) : new Map()
      const statsSeries = stats ? new Map((stats.series ?? []).map((entry) => [agentDisplayKeyOf(entry.agentId), entry.buckets ?? []])) : new Map()
      const accountTotalsById = stats ? new Map((stats.accountTotals ?? []).map((entry) => [accountDisplayKeyOf(entry.provider), entry])) : new Map()
      const accountSeriesById = stats ? new Map((stats.accountSeries ?? []).map((entry) => [accountDisplayKeyOf(entry.provider), entry.buckets ?? []])) : new Map()
      const recentCalls = stats ? stats.recent ?? [] : []
      const statsDays = stats ? (stats.days ?? {}) : {}
      // EVO-017：预设作用域统计行（presetStats——main/subagent 两口径）。
      const presetStatsRows = stats && Array.isArray(stats.presetStats) ? stats.presetStats : []
      // EVO-017 R2：统一分组视图派生索引（per-agent / per-account 按天 + 最近≤10）。
      const agentDaysById = stats ? new Map((stats.agentDays ?? []).map((entry) => [agentDisplayKeyOf(entry.key), entry.days ?? []])) : new Map()
      const accountDaysById = stats ? new Map((stats.accountDays ?? []).map((entry) => [accountDisplayKeyOf(entry.key), entry.days ?? []])) : new Map()
      const recentByAgentId = stats ? new Map((stats.recentByAgent ?? []).map((entry) => [agentDisplayKeyOf(entry.key), entry.recent ?? []])) : new Map()
      const recentByAccountId = stats ? new Map((stats.recentByAccount ?? []).map((entry) => [accountDisplayKeyOf(entry.key), entry.recent ?? []])) : new Map()
      // kind 参与键空间：provider 账号与同名 OAuth 账号/池/子代理条目互不顶掉。
      const accountKindKey = (kind, key) => `${kind ?? 'provider'}|${key}`
      const accountTotalsByKindId = stats ? new Map((stats.accountTotals ?? []).map((entry) => [accountKindKey(entry.accountKind, accountDisplayKeyOf(entry.provider)), entry])) : new Map()
      // FIX-031 显示名单点（配置面 roster → 用户可见名）：构建经
      // buildAccountNames 单点（D10 提取为真函数——含 twin 目录条目排除），
      // 统计面所有键→名映射经此一处（P5）。
      const accountNames = buildAccountNames(providers, state.catalog, value.agents)
      // FIX-031：专业 Agent 分组行 = 配置的专业 agent + 「主模型」统一实体
      // （twin/oauth 两条内部记录路径归一后只此一行；无数据不出卡）。
      const agentStatsRows = [
        ...agentIds.map((id) => ({ id, isMainModel: false })),
        ...(statsTotals.has(MAIN_MODEL_AGENT_ID) ? [{ id: MAIN_MODEL_AGENT_ID, isMainModel: true }] : []),
      ]
      const sumAll = (stats ? stats.totals ?? [] : []).reduce(
        (acc, entry) => ({ calls: acc.calls + entry.calls, errors: acc.errors + entry.errors, inTokens: acc.inTokens + entry.inputTokens, outTokens: acc.outTokens + entry.outputTokens }),
        { calls: 0, errors: 0, inTokens: 0, outTokens: 0 })

      const addFromTemplate = (template) => {
        let id = template.id
        let n = 2
        while (agentIds.includes(id)) { id = `${template.id}-${n}`; n++ }
        setNewId(id)
        setDraft(id, { ...defaultDraft(), ...template.draft })
      }
      const toggleExpanded = (id) => setExpandedAgents((current) => ({ ...current, [id]: !current[id] }))
      const toggleAccount = (provider) => setExpandedAccounts((current) => ({ ...current, [provider]: !current[provider] }))
      const toggleStatCard = (key) => setExpandedStats((current) => ({ ...current, [key]: !current[key] }))
      const toggleSection = (key) => setExpandedSection((current) => ({ ...current, [key]: !current[key] }))

      // 已添加的账号（llm-pi-ai 目录中已激活的路由 = 已配置 profile）。
      // FIX-015 + FIX-019：插件侧 provider（oauth 面统计键 + 宿主路由面真目录
      // 条目）不得渲染成通用 API Key 编辑器（幽灵卡）——目录来源同样过滤，
      // 判据经 isPluginSelfRegisteredProvider 单点（与统计 accountTotals 来源
      // 同判）。
      const addedAccounts = providers
        .filter((entry) => entry.settingsNs === 'llm-pi-ai' && entry.active === true)
        .map((entry) => entry.provider)
        .filter((provider) => !isPluginSelfRegisteredProvider(provider))
      for (const total of stats ? stats.accountTotals ?? [] : []) {
        // FIX-015 + FIX-019 + FIX-031：插件自注册身份键（OAuth 订阅账号 / 账号池 /
        // 子代理条目 / 宿主官方路由）不是「可配置 API Key 账号」，不得并入配置区
        // 渲染成通用 API Key 编辑器（幽灵卡——用户实证）。判据单点：优先服务端
        // 归一化下发的 accountKind（实体种类），无该字段（滚动升级旧服务端）回退
        // isPluginSelfRegisteredProvider 字符串判据；两处判据同点消费。
        if ((total.accountKind && total.accountKind !== 'provider') || isPluginSelfRegisteredProvider(total.provider)) continue
        const clean = accountDisplayKeyOf(total.provider)
        if (!addedAccounts.includes(clean)) addedAccounts.push(clean)
      }
      addedAccounts.sort()
      const accountModelsOf = (provider) => {
        const group = (state.models ?? []).find((entry) => entry.id === provider)
        return group ? group.models ?? [] : []
      }
      const accountProfileOf = (provider) => {
        const profiles = state.llmPiAi && state.llmPiAi.value && state.llmPiAi.value.providers ? state.llmPiAi.value.providers : null
        const profile = profiles ? profiles[provider] : undefined
        return profile && typeof profile === 'object' ? profile : null
      }
      // ── 已添加账号的编辑（Base URL / API Key / 模型 / 删除）──────────
      const accountDraftOf = (provider) => {
        const profile = accountProfileOf(provider)
        const modelsText = profile && Array.isArray(profile.models) ? profile.models.map((entry) => (typeof entry === 'string' ? entry : entry?.id)).filter(Boolean).join(', ') : ''
        const apiType = profile && ['openai-completions', 'openai-responses', 'anthropic-messages'].includes(profile.api) ? profile.api : 'openai-completions'
        return { baseURL: profile && profile.baseURL ? profile.baseURL : '', key: '', api: apiType, models: modelsText, ...(accountDrafts[provider] ?? {}) }
      }
      const setAccountDraftField = (provider, field, fieldValue) => {
        setAccountDrafts((current) => ({ ...current, [provider]: { ...accountDraftOf(provider), [field]: fieldValue } }))
      }
      const saveAccount = async (provider) => {
        const draft = accountDraftOf(provider)
        if (!(draft.baseURL ?? '').trim()) {
          setAccountNotice((current) => ({ ...current, [provider]: t('accountBaseUrlRequired') }))
          return
        }
        setAccountBusy((current) => ({ ...current, [provider]: true }))
        try {
          const settingsResponse = await api.settings.describe({})
          if (!settingsResponse.result.ok) throw new Error(settingsResponse.result.error.message)
          const llmView = viewOf(settingsResponse.result.value.namespaces, 'llm-pi-ai')
          const existing = llmView && llmView.value && llmView.value.providers ? llmView.value.providers[provider] : undefined
          const apiType = ['openai-completions', 'openai-responses', 'anthropic-messages'].includes(draft.api) ? draft.api : 'openai-completions'
          const modelIds = String(draft.models ?? '').split(',').map((item) => item.trim()).filter(Boolean)
          // 内置目录路由（declared === false）不写 models 即按目录默认模型
          // 服务；其余（自定义路由 / 目录缺失）必须列出模型，清空时需先向
          // 端点拉取——与添加流程同一套探测助手。
          const catalogRoute = providerEntry(provider)?.declared === false
          let notice = t('saved')
          if (existing === undefined) {
            // 与添加流程同源：profile 首次写入时模型留空必须拉到才能写入。
            let modelEntries = modelIds.length > 0 ? modelIds.map((id) => ({ id })) : null
            if (modelIds.length === 0 && !catalogRoute) {
              let discovered
              try {
                discovered = await probeProviderModels(api, { provider, baseURL: draft.baseURL.trim(), api: apiType, apiKey: draft.key.trim() })
              } catch (error) {
                throw new Error(`${t('accountDiscoverFailed')}：${messageOf(error)}。${t('accountModelsRequiredHint')}`)
              }
              if (discovered.length === 0) throw new Error(t('accountDiscoverEmpty'))
              modelEntries = modelEntriesOf(discovered)
              notice = t('accountDiscovered')(discovered.length)
            }
            const profile = {
              api: apiType,
              baseURL: draft.baseURL.trim(),
              ...(draft.key.trim() ? { apiKeyEnv: deriveKeyRef(provider) } : {}),
              // 中转/本地部署常同时服务文本与多模态模型：路由级默认输入
              // 声明含 image，避免 pi-ai 默认纯文本导致视觉调用被拒。
              defaultInput: ['text', 'image'],
              ...(modelEntries !== null ? { models: modelEntries } : {}),
            }
            const response = await api.settings.mutate({ ns: 'llm-pi-ai', ops: [{ op: 'set', path: ['providers', provider], value: profile }] })
            if (!response.result.ok) throw new Error(response.result.error.message)
          } else {
            // 已存在 profile：Base URL / 接口类型 / 模型列表合并进一次原子
            // 写入（旧实现拆两次写入，模型列表被宿主校验器拒绝时会出现
            // 半生效状态）。
            const ops = [
              { op: 'set', path: ['providers', provider, 'baseURL'], value: draft.baseURL.trim() },
              { op: 'set', path: ['providers', provider, 'api'], value: apiType },
              { op: 'set', path: ['providers', provider, 'defaultInput'], value: ['text', 'image'] },
            ]
            if (modelIds.length > 0) {
              ops.push({ op: 'set', path: ['providers', provider, 'models'], value: modelIds.map((id) => ({ id })) })
            } else if (catalogRoute) {
              // 内置目录路由：清空 = 恢复目录默认模型。
              ops.push({ op: 'unset', path: ['providers', provider, 'models'] })
            } else {
              // 自定义路由必须列出模型：清空时自动向端点拉取；拉不到保留
              // 现有模型列表（绝不写坏已生效的配置）。
              try {
                const discovered = await probeProviderModels(api, { provider, baseURL: draft.baseURL.trim(), api: apiType, apiKey: draft.key.trim() })
                if (discovered.length > 0) {
                  ops.push({ op: 'set', path: ['providers', provider, 'models'], value: modelEntriesOf(discovered) })
                  notice = t('accountDiscovered')(discovered.length)
                } else {
                  notice = `${t('accountDiscoverEmpty')}；${t('accountModelsKept')}`
                }
              } catch (error) {
                notice = `${t('accountDiscoverFailed')}：${messageOf(error)}；${t('accountModelsKept')}`
              }
            }
            const response = await api.settings.mutate({ ns: 'llm-pi-ai', ops })
            if (!response.result.ok) throw new Error(response.result.error.message)
          }
          if (draft.key.trim()) {
            const stored = await api.credentials.set({ ref: deriveKeyRef(provider), value: draft.key.trim() })
            if (!stored.result.ok) throw new Error(stored.result.error.message)
          }
          setAccountBusy((current) => ({ ...current, [provider]: false }))
          setAccountNotice((current) => ({ ...current, [provider]: notice }))
          setAccountDrafts((current) => ({ ...current, [provider]: { baseURL: draft.baseURL.trim(), key: '' } }))
          await load()
        } catch (error) {
          setAccountBusy((current) => ({ ...current, [provider]: false }))
          setAccountNotice((current) => ({ ...current, [provider]: messageOf(error) }))
        }
      }
      const discoverAccountModels = async (provider) => {
        setAccountBusy((current) => ({ ...current, [provider]: true }))
        try {
          const draft = accountDraftOf(provider)
          const response = await api.llm.discoverModels({
            settingsNs: 'llm-pi-ai',
            provider,
            ...(draft.baseURL.trim() ? { baseURL: draft.baseURL.trim() } : {}),
            ...(['openai-completions', 'openai-responses', 'anthropic-messages'].includes(draft.api) ? { api: draft.api } : {}),
          })
          if (!response.result.ok) throw new Error(response.result.error.message)
          const existing = String(draft.models ?? '').split(',').map((item) => item.trim()).filter(Boolean)
          const merged = [...new Set([...existing, ...(response.result.value.models ?? []).map((model) => model.id)])]
          setAccountDrafts((current) => ({ ...current, [provider]: { ...accountDraftOf(provider), models: merged.join(', ') } }))
          setAccountNotice((current) => ({ ...current, [provider]: `发现 ${(response.result.value.models ?? []).length} 个模型（已合并进模型列表，点「保存」生效）` }))
        } catch (error) {
          setAccountNotice((current) => ({ ...current, [provider]: `发现模型失败：${messageOf(error)}` }))
        } finally {
          setAccountBusy((current) => ({ ...current, [provider]: false }))
        }
      }
      const removeAccount = async (provider) => {
        if (!window.confirm(t('accountConfirmDelete'))) return
        setAccountBusy((current) => ({ ...current, [provider]: true }))
        try {
          const response = await api.settings.mutate({ ns: 'llm-pi-ai', ops: [{ op: 'unset', path: ['providers', provider] }] })
          if (!response.result.ok) throw new Error(response.result.error.message)
          await api.credentials.unset({ ref: deriveKeyRef(provider) }).catch(() => undefined)
          setAccountBusy((current) => ({ ...current, [provider]: false }))
          setAccountDrafts((current) => { const next = { ...current }; delete next[provider]; return next })
          await load()
        } catch (error) {
          setAccountBusy((current) => ({ ...current, [provider]: false }))
          setAccountNotice((current) => ({ ...current, [provider]: messageOf(error) }))
        }
      }
      // 统计卡片用的账号行（激活账号 + 有调用的账号）。
      const statsAccountRows = []
      for (const entry of providers) {
        if (entry.settingsNs !== 'llm-pi-ai') continue
        // FIX-019 边界澄清（EVO-017 R2 修订）：插件自注册 provider 不出现在
        // **账号管理**可编辑行（原判据保持），但**统计行**按用户需求 4「统计
        // 所有经过当前账号的数据，不关联场景」呈现真实用量——此处不再过滤
        //（管理区 addedAccounts 的 isPluginSelfRegisteredProvider 过滤不变）。
        // FIX-031 D5（返工批 3）：宿主路由键例外——它是通路构件不是账号
        //（凭据与 oauth 通路同源，用量经服务端 D6 归并到订阅账号），roster
        // 行不再为其出卡；回落态（账号未知）由统计行单卡承载，杜绝同键
        // 双卡。取数键经显示层单点（accountDisplayKeyOf）——与统计行同键空间。
        if (isHostManagedRoute(entry.provider)) continue
        const total = accountTotalsById.get(accountDisplayKeyOf(entry.provider))
        if (entry.active !== true && !total) continue
        statsAccountRows.push({
          provider: entry.provider,
          accountKind: 'provider',
          displayName: entry.displayName,
          active: entry.active === true,
          calls: total ? total.calls : 0,
          errors: total ? total.errors : 0,
          inputTokens: total ? total.inputTokens : 0,
          outputTokens: total ? total.outputTokens : 0,
          totalMs: total ? total.totalMs : 0,
          lastAt: total ? total.lastAt : undefined,
        })
      }
      for (const total of stats ? stats.accountTotals ?? [] : []) {
        // EVO-017 R2：有真实用量的账号（含插件自注册身份 oauth/pool/cli——用户
        // 需求「统计所有经过当前账号的数据，不关联场景」）都进统计行。
        // FIX-031：provider 已是归一化后的规范账号键（无 `-router` 伪实体、无
        // 内部标记），displayName 经配置面 roster 单点解析。
        // D5（返工批 3）：身份去重按**归一账号键跨 accountKind**——旧判据
        // provider+kind 双等时，宿主路由 roster 行（provider 形态）与统计行
        //（host-route 形态）同键不同 kind 双双渲染、读同一份 totals 数字重复。
        if (statsAccountRows.some((row) => accountDisplayKeyOf(row.provider) === accountDisplayKeyOf(total.provider))) continue
        const rowKind = total.accountKind ?? 'provider'
        statsAccountRows.push({
          provider: total.provider,
          accountKind: rowKind,
          // D6 回落诚实标签：宿主路由通路行无 roster 名时不冒充实体键——
          // displayName 留空，标题经 statsProviderLabelOf 出「宿主路由
          //（账号未知）」；其余 kind 维持 roster 名 → 清洁键回落。
          displayName: rowKind === 'host-route'
            ? rosterDisplayName(accountNames, 'host-route', accountDisplayKeyOf(total.provider))
            : (rosterDisplayName(accountNames, rowKind, accountDisplayKeyOf(total.provider)) ?? total.provider),
          active: true,
          calls: total.calls,
          errors: total.errors,
          inputTokens: total.inputTokens,
          outputTokens: total.outputTokens,
          totalMs: total.totalMs,
          lastAt: total.lastAt || undefined,
        })
      }
      statsAccountRows.sort((a, b) => (a.provider < b.provider ? -1 : 1))

      // ── OAuth 账号（插件独立管理）派生与操作 ──────────────────────────
      // EVO-007：官方登录管理 UI（OAuthAccountCard/AddOAuthCard 及专属操作
      // saveOauthAccount/deleteOauthAccount/quickAddOauthAccount/pasteOauthToken/
      // openOauthAuthorize/exchangeOauthCode）已随区块移除；以下保留项服务
      // 账号池（池内一键授权/发现模型/按预设建号入池）与 ChatGPT 预设账号。
      // F-1（EVO-007 R0 返工）：deleteOauthAccount 以池行/孤儿列表入口恢复
      // （非 preset 账号删除路径——unset 条目 + 凭据清理 + 清全部池引用）。
      const oauthById = new Map(oauthEntries.map((entry) => [entry.id, entry]))
      const defaultOauthDraft = () => ({
        name: '', enabled: true, protocol: 'openai-completions', baseURL: '',
        clientId: '', clientSecret: '', publicClient: false, authUrl: '', tokenUrl: '', scope: '', models: [],
      })
      const oauthDraftOf = (id) => {
        const entry = oauthById.get(id)
        return entry
          ? { name: entry.name, enabled: entry.enabled, protocol: entry.protocol, baseURL: entry.baseURL, clientId: entry.clientId, publicClient: entry.publicClient === true, authUrl: entry.authUrl, tokenUrl: entry.tokenUrl, scope: entry.scope, models: entry.models ?? [] }
          : defaultOauthDraft()
      }

      /** 删除非 preset OAuth 账号（F-1，EVO-007 R0 返工恢复删除路径）：
       *  ① credentials.unset(tokenRef) 凭据清理（幂等，失败容忍）→
       *  ② 从所有引用它的账号池移除（含当前池）→ ③ unset oauthAccounts 条目。
       *  preset 成员账号（chatgpt-codex）分流 W-5 联动删除（deletePresetAccount：
       *  删凭据文件 + 清池引用 + unset 三步，§3.6）。入口：账号池行「删除账号」
       *  按钮与高级扩展区「未入池的 OAuth 账号」列表行（孤儿兜底）。 */
      const deleteOauthAccount = async (id) => {
        const entry = oauthById.get(id)
        if (entry && isPresetAccount(entry)) return deletePresetAccount(id)
        if (!window.confirm(t('oauthDeleteConfirm'))) return
        setOauthBusy((current) => ({ ...current, [id]: true }))
        try {
          if (entry && entry.tokenRef) await api.credentials.unset({ ref: entry.tokenRef }).catch(() => undefined)
          const ops = []
          for (const pool of poolEntries) {
            if ((pool.accounts ?? []).includes(id)) {
              ops.push({ op: 'set', path: ['pools', pool.id, 'accounts'], value: (pool.accounts ?? []).filter((item) => item !== id) })
            }
          }
          ops.push({ op: 'unset', path: ['oauthAccounts', id] })
          const outcome = await mutate(ops)
          setOauthNotice((current) => ({ ...current, [id]: outcome.ok ? t('oauthDeleted') : outcome.message }))
          if (outcome.ok) await load()
        } catch (error) {
          setOauthNotice((current) => ({ ...current, [id]: messageOf(error) }))
        } finally {
          setOauthBusy((current) => ({ ...current, [id]: false }))
        }
      }

      // F-1 孤儿兜底（派生在账号池区，依赖 poolEntries）——非 preset 且未加入
      // 任何账号池的账号（历史自定义/粘贴 token/未知 preset 值）：池行删除覆盖
      // 池内账号，此处覆盖池外残留，保证每条 oauthAccounts 条目都有删除入口
      // （P7 凭据可清理）。

      // ── ChatGPT 订阅登录（正式通道，EVO-006 / DEC-026 C2 转正）────────
      const presetOauthEntries = oauthEntries.filter((entry) => isPresetAccount(entry))

      /** 添加 ChatGPT preset 账号（零配置：端点常量由服务端 preset 分支预填）
       *  并立即发起一键登录；模型预置 gpt-5.6 系（用户指令 2026-08-30）。
       *  FIX-015 防缩小证明：恒为**新建**（accountId 去重循环保证不覆盖已有
       *  账号）。 */
      const addPresetAccount = async () => {
        let accountId = 'chatgpt'
        let n = 2
        while (oauthById.has(accountId)) { accountId = `chatgpt-${n++}` }
        const value = {
          name: 'ChatGPT', enabled: true, preset: 'chatgpt-codex', protocol: 'codex-responses',
          baseURL: 'https://chatgpt.com/backend-api', credentialFile: '', clientId: '', clientSecret: '',
          publicClient: false, authUrl: '', tokenUrl: '', scope: '', models: [...PRESET_MODEL_DEFAULTS], tokenRef: '',
        }
        const outcome = await mutate([{ op: 'set', path: ['oauthAccounts', accountId], value }])
        if (!outcome.ok) { setOauthNotice((current) => ({ ...current, [accountId]: outcome.message })); return }
        await runPresetLogin(accountId)
      }

      /** preset 一键登录：oauthBegin（preset 分支）→ 弹窗授权 → 轮询 catalog
       *  的 presetLoggedIn（1455 回调在宿主侧自动完成 code 交换与凭据落盘，
       *  客户端只观察登录态翻转）。EVO-005：1455 被占时服务端自动降级设备码
       *  流（mode:'device'）——展示验证页链接 + 设备码，宿主侧轮询兑换，
       *  客户端同样观察 catalog 翻转（轮询不依赖弹窗存活）。 */
      const runPresetLogin = async (id) => {
        const routerRemote = remote()
        if (!routerRemote || typeof routerRemote.oauthBegin !== 'function') {
          setOauthNotice((current) => ({ ...current, [id]: t('oauthNeedRestart') }))
          return
        }
        setOauthBusy((current) => ({ ...current, [id]: true }))
        const response = await routerRemote.oauthBegin({ accountId: id, redirectUri: window.location.origin + '/router-oauth/callback' })
        if (!response.ok) {
          setOauthBusy((current) => ({ ...current, [id]: false }))
          setOauthNotice((current) => ({ ...current, [id]: response.error.message }))
          return
        }
        // EVO-005 设备码降级分支：服务端已发起设备码会话并后台轮询——打开
        // 验证页（失败不阻断：notice 内链接可手动打开）+ 常显设备码提示。
        if (response.value.mode === 'device') {
          try { window.open(response.value.authUrl, 'dsh-agent-router-device', 'popup,width=520,height=680') } catch { /* 弹窗拦截：notice 链接仍可用 */ }
          setOauthNotice((current) => ({ ...current, [id]: t('presetDeviceWaiting')(response.value.userCode, response.value.authUrl) }))
          const deadline = Date.now() + (response.value.expiresIn || 900) * 1000
          const pollDevice = async () => {
            if (Date.now() > deadline) {
              setOauthNotice((current) => ({ ...current, [id]: t('oauthExpired') }))
              setOauthBusy((current) => ({ ...current, [id]: false }))
              return
            }
            let loggedIn = false
            try {
              const catalog = await routerRemote.catalog({})
              const entry = ((catalog.value?.oauthAccounts) ?? []).find((candidate) => candidate.id === id)
              loggedIn = entry?.presetLoggedIn === true
            } catch { /* 网络瞬时失败：继续轮询 */ }
            if (loggedIn) {
              setOauthNotice((current) => ({ ...current, [id]: t('presetLoginDone') }))
              setOauthBusy((current) => ({ ...current, [id]: false }))
              await load()
              return
            }
            window.setTimeout(pollDevice, 1200)
          }
          window.setTimeout(pollDevice, 1000)
          return
        }
        let popup
        try { popup = window.open(response.value.authUrl, 'dsh-agent-router-oauth', 'popup,width=520,height=680') } catch { popup = null }
        if (!popup) {
          setOauthBusy((current) => ({ ...current, [id]: false }))
          setOauthNotice((current) => ({ ...current, [id]: t('oauthPopupBlocked') }))
          return
        }
        setOauthNotice((current) => ({ ...current, [id]: t('presetLoginWaiting') }))
        const deadline = Date.now() + 3 * 60 * 1000
        const poll = async () => {
          if (popup.closed || Date.now() > deadline) {
            if (Date.now() > deadline) setOauthNotice((current) => ({ ...current, [id]: t('oauthExpired') }))
            setOauthBusy((current) => ({ ...current, [id]: false }))
            return
          }
          let loggedIn = false
          try {
            const catalog = await routerRemote.catalog({})
            const entry = ((catalog.value?.oauthAccounts) ?? []).find((candidate) => candidate.id === id)
            loggedIn = entry?.presetLoggedIn === true
          } catch { /* 网络瞬时失败：继续轮询 */ }
          if (loggedIn) {
            setOauthNotice((current) => ({ ...current, [id]: t('presetLoginDone') }))
            try { popup.close() } catch { /* 已由用户关闭 */ }
            setOauthBusy((current) => ({ ...current, [id]: false }))
            await load()
            return
          }
          window.setTimeout(poll, 1200)
        }
        window.setTimeout(poll, 1000)
      }

      /** 登出并删除凭据（§3.6 凭据删除路径；服务端 store.delete 幂等，
       *  合规删除路径恒可用——不受任何开关门控，W-5 三层联动不变）。 */
      const logoutPresetAccount = async (id) => {
        if (!window.confirm(t('presetLogoutConfirm'))) return
        setOauthBusy((current) => ({ ...current, [id]: true }))
        const response = await remote().oauthLogout({ accountId: id })
        setOauthBusy((current) => ({ ...current, [id]: false }))
        setOauthNotice((current) => ({ ...current, [id]: response.ok ? response.value.message : response.error.message }))
        if (response.ok) await load()
      }

      /** 删除 preset 账号（W-5 联动）：先删本机凭据文件 → 清引用它的账号池
       *  （联动提示）→ 删账号条目——三步一次完成（§3.6 合规删除路径）。
       *  R7-F4：oauthLogout 响应语义为 value.ok（RPC 外层 ok 恒真）——删除
       *  凭据失败（fs 级错误）时中止后续 ops（账号保留可重试）并展示失败
       *  文案，避免"凭据残留 + 条目已删 + 成功提示"的失联状态。 */
      const deletePresetAccount = async (id) => {
        if (!window.confirm(t('presetDeleteConfirm'))) return
        setOauthBusy((current) => ({ ...current, [id]: true }))
        const logoutResponse = await remote().oauthLogout({ accountId: id }).catch(() => ({ ok: true, value: { ok: false, message: t('presetLogoutFailed') } }))
        if (!logoutResponse?.value || logoutResponse.value.ok !== true) {
          setOauthBusy((current) => ({ ...current, [id]: false }))
          setOauthNotice((current) => ({ ...current, [id]: logoutResponse?.value?.message ?? t('presetLogoutFailed') }))
          return
        }
        const poolsContaining = poolEntries.filter((pool) => (pool.accounts ?? []).includes(id))
        const ops = []
        for (const pool of poolsContaining) {
          ops.push({ op: 'set', path: ['pools', pool.id, 'accounts'], value: (pool.accounts ?? []).filter((item) => item !== id) })
        }
        ops.push({ op: 'unset', path: ['oauthAccounts', id] })
        const outcome = await mutate(ops)
        setOauthBusy((current) => ({ ...current, [id]: false }))
        const cleaned = poolsContaining.length
        setOauthNotice((current) => ({ ...current, [id]: outcome.ok ? `${t('presetDeleted')}${cleaned > 0 ? ` ${t('presetPoolCleaned')(cleaned)}` : ''}` : outcome.message }))
      }

      /** preset 模型编辑态解析（FIX-015 c/d + 根因未定防御）：显式 draft 优先
       *  （含用户清空的 ''）；已存 models 非空 → join；已登录且空 → 默认三件套
       *  **实预填**（用户保存即写入真实值）；未登录空 → ''（placeholder 保留）。
       *  显示与保存共用（P5 单点）——**防缩小守卫**：无 draft 时保存回退已存值
       *  （未编辑保存 = 幂等原值，绝不空覆盖）。RCA 注记（2026-08-31 修正）：
       *  用户数据丢失根因**未定**——已证 ①磁盘 models:[] ②本缺陷能造成空覆盖
       *  （需保存点击触发）③用户唯一保存点击在丢值之后（不构成因果）④
       *  persistPresetLogin 只写凭据文件不写 settings；真凶未明，防御性全覆盖。 */
      const presetModelsDraftOf = (id) => {
        if (presetModels[id] !== undefined) return presetModels[id]
        const entry = oauthById.get(id)
        const saved = entry && Array.isArray(entry.models) ? entry.models : []
        if (saved.length > 0) return saved.join(', ')
        if (entry && entry.presetLoggedIn === true) return PRESET_MODEL_DEFAULTS.join(', ')
        return ''
      }

      /** preset 模型列表保存（逗号分隔编辑 → 数组落盘）。FIX-015（c 兜底）：
       *  已登录账号解析后仍为空 → 提示而非「已保存」（配合实预填该路径自然
       *  消失，防呆兜底）。 */
      const savePresetModels = async (id) => {
        const raw = presetModelsDraftOf(id)
        const models = raw.split(/[,，]/).map((item) => item.trim()).filter(Boolean)
        const outcome = await mutate([{ op: 'set', path: ['oauthAccounts', id, 'models'], value: models }])
        const entry = oauthById.get(id)
        if (outcome.ok && models.length === 0 && entry && entry.presetLoggedIn === true) {
          setOauthNotice((current) => ({ ...current, [id]: t('presetModelsEmptyNotice') }))
          return
        }
        setOauthNotice((current) => ({ ...current, [id]: outcome.ok ? t('saved') : outcome.message }))
      }

      /** EVO-010：调用通路保存（'host' | 'plugin'）——写 oauthAccounts.<id>.
       *  transport；服务端 settings/document-updated 联动路由维护热增删（零重启）。 */
      const savePresetTransport = async (id, value) => {
        const outcome = await mutate([{ op: 'set', path: ['oauthAccounts', id, 'transport'], value: value === 'plugin' ? 'plugin' : 'host' }])
        setOauthNotice((current) => ({ ...current, [id]: outcome.ok ? t('presetTransportSaved') : outcome.message }))
      }

      // ── 子代理（无头 CLI 条目：账号区维护，专业 agent 经 cliAgent 引用）──
      const cliEntries = state.catalog?.cliAgents ?? []
      const cliEntriesById = new Map(cliEntries.map((entry) => [entry.id, entry]))
      const cliEntryIds = cliEntries.map((entry) => entry.id).sort()
      const cliValue = (id) => state.value && state.value.cliAgents ? state.value.cliAgents[id] ?? null : null
      const defaultCliDraft = () => ({
        name: '', enabled: true, command: '', args: '', timeoutMs: 0, maxConcurrent: 1,
        loginArgs: '', statusArgs: '', modelsArgs: '',
      })
      const cliDraftOf = (id) => {
        const entry = cliValue(id)
        const base = entry
          ? { name: entry.name, enabled: entry.enabled, command: entry.command, args: entry.args, timeoutMs: entry.timeoutMs, maxConcurrent: entry.maxConcurrent, loginArgs: entry.loginArgs, statusArgs: entry.statusArgs, modelsArgs: entry.modelsArgs }
          : defaultCliDraft()
        return { ...base, ...(cliDrafts[id] ?? {}) }
      }
      const setCliDraft = (id, patch) => setCliDrafts((current) => ({ ...current, [id]: { ...cliDraftOf(id), ...patch } }))

      const saveCliAgent = async (id, isNew) => {
        if (isNew && (!ID_PATTERN.test(id) || id === '')) return
        if (isNew && cliEntriesById.has(id)) return
        setCliBusy((current) => ({ ...current, [id]: true }))
        const draft = cliDraftOf(id)
        const outcome = await mutate([{ op: 'set', path: ['cliAgents', id], value: draft }])
        setCliBusy((current) => ({ ...current, [id]: false }))
        setCliNotice((current) => ({ ...current, [id]: outcome.ok ? t('saved') : outcome.message }))
        if (outcome.ok && isNew) setAddingCli(false)
        if (outcome.ok) setCliDrafts((current) => ({ ...current, [id]: { ...cliDraftOf(id) } }))
      }

      const deleteCliAgent = async (id) => {
        if (!window.confirm(t('cliConfirmDelete'))) return
        await mutate([{ op: 'unset', path: ['cliAgents', id] }])
        setCliDrafts((current) => { const next = { ...current }; delete next[id]; return next })
      }

      /** 快速添加子代理条目：'custom' 空白；其余按 CLI_PICKER 预填名称/命令/参数。 */
      const quickAddCli = async (kind) => {
        let id = kind === 'custom' ? 'custom' : kind
        if (!id) return
        let n = 2
        while (cliEntriesById.has(id)) { id = `${kind === 'custom' ? 'custom' : kind}-${n++}` }
        const pick = CLI_PICKER.find((entry) => entry.id === kind)
        const draft = pick?.fill
          ? { name: pick.fill.name, enabled: true, command: pick.fill.command, args: pick.fill.args, timeoutMs: 0, maxConcurrent: 1, loginArgs: '', statusArgs: '', modelsArgs: '' }
          : defaultCliDraft()
        const outcome = await mutate([{ op: 'set', path: ['cliAgents', id], value: draft }])
        if (!outcome.ok) { setCliNotice((current) => ({ ...current, [id]: outcome.message })); return }
        setAddingCli(false)
        setExpandedCli((current) => ({ ...current, [id]: true }))
        setCliNotice((current) => ({ ...current, [id]: pick?.fill ? t('saved') : t('cliCustomHint') }))
        void runCliStatus(id)
      }

      /**
       * 一键授权登录（EVO-007 起仅供账号池「池内一键授权」与「按预设建号入池」
       * 使用——官方登录管理 UI 已移除）：宿主生成 PKCE+state 并返回授权 URL，
       * 弹窗完成授权后服务商重定向到宿主回调页（/router-oauth/callback）自动
       * 交换 token；本页轮询凭据状态，成功后自动关闭弹窗并刷新登录态。
       * tokenRefOverride：刚创建/保存的账号尚未进入本渲染闭包的目录时，
       * 由调用方传入确定性构造的凭据引用（`ROUTER_OAUTH_<ID>_TOKEN`）。
       */
      const runOneClickOauth = async (id, tokenRefOverride) => {
        const entry = oauthById.get(id)
        const draft = oauthDraftOf(id)
        const tokenRef = tokenRefOverride ?? (entry ? entry.tokenRef : undefined)
        if (!draft.authUrl || (!draft.publicClient && !draft.clientId) || !tokenRef) {
          setOauthNotice((current) => ({ ...current, [id]: t('oauthNeedConfig') }))
          return
        }
        const routerRemote = remote()
        if (!routerRemote || typeof routerRemote.oauthBegin !== 'function') {
          setOauthNotice((current) => ({ ...current, [id]: t('oauthNeedRestart') }))
          return
        }
        const redirectUri = window.location.origin + '/router-oauth/callback'
        setOauthBusy((current) => ({ ...current, [id]: true }))
        const response = await routerRemote.oauthBegin({ accountId: id, redirectUri })
        setOauthBusy((current) => ({ ...current, [id]: false }))
        if (!response.ok) {
          setOauthNotice((current) => ({ ...current, [id]: response.error.message }))
          return
        }
        let popup
        try {
          popup = window.open(response.value.authUrl, 'dsh-agent-router-oauth', 'popup,width=520,height=680')
        } catch {
          popup = null
        }
        if (!popup) {
          setOauthNotice((current) => ({ ...current, [id]: t('oauthPopupBlocked') }))
          return
        }
        setOauthNotice((current) => ({ ...current, [id]: t('oauthWaiting') }))
        const ref = tokenRef
        const deadline = Date.now() + 3 * 60 * 1000
        const poll = async () => {
          if (popup.closed || Date.now() > deadline) {
            if (Date.now() > deadline) setOauthNotice((current) => ({ ...current, [id]: t('oauthExpired') }))
            return
          }
          let configured = false
          try {
            const describe = await api.credentials.describe({ refs: [ref] })
            configured = !!describe.result.ok && (describe.result.value.credentials ?? {})[ref]?.configured === true
          } catch {
            // 网络瞬时失败：继续轮询。
          }
          if (configured) {
            setOauthNotice((current) => ({ ...current, [id]: t('oauthAutoDiscovering') }))
            refreshOauthTokens()
            try { popup.close() } catch { /* 已由用户关闭 */ }
            // 授权成功后的下一步是模型列表：自动触发一次发现模型（等
            // load() 刷新账号目录后执行；失败则提示用户手动重试）。
            window.setTimeout(() => discoverOauth(id), 800)
            return
          }
          window.setTimeout(poll, 1200)
        }
        window.setTimeout(poll, 1000)
      }

      const discoverOauth = async (id) => {
        setOauthBusy((current) => ({ ...current, [id]: true }))
        const response = await remote().oauthDiscover({ accountId: id })
        setOauthBusy((current) => ({ ...current, [id]: false }))
        if (!response.ok) { setOauthNotice((current) => ({ ...current, [id]: `发现模型失败：${response.error.message}（可稍后重试）` })); return }
        // FIX-015 防缩小证明：并集合并（mergePresetModels）——已存非空列表在
        // 任何发现结果（含空/端点失效）下都不可能被缩小；空发现 = 幂等保存原值。
        const entry = oauthById.get(id)
        const merged = mergePresetModels(entry ? entry.models ?? [] : [], response.value.models)
        const outcome = await mutate([{ op: 'set', path: ['oauthAccounts', id, 'models'], value: merged }])
        // 0 个模型时直接展示服务端诊断信息（响应形状与样例），便于定位。
        const count = response.value.models.length
        setOauthNotice((current) => ({ ...current, [id]: outcome.ok ? (count > 0 ? `已发现 ${count} 个模型并合并到模型列表` : response.value.message) : outcome.message }))
      }

      // ── 账号池（插件独立管理）派生与操作 ──────────────────────────────
      const poolEntries = state.catalog?.pools ?? []
      const poolById = new Map(poolEntries.map((entry) => [entry.id, entry]))
      const poolIds = poolEntries.map((entry) => entry.id).sort()
      // F-1 孤儿兜底派生：非 preset 且未加入任何账号池的账号（历史自定义/
      // 粘贴 token/未知 preset 值）——池行删除覆盖池内账号，此处覆盖池外
      // 残留，保证每条 oauthAccounts 条目都有删除入口（P7 凭据可清理）。
      const poolMemberIds = new Set(poolEntries.flatMap((pool) => pool.accounts ?? []))
      const orphanOauthIds = oauthEntries
        .filter((entry) => !isPresetAccount(entry) && !poolMemberIds.has(entry.id))
        .map((entry) => entry.id).sort()
      const valuePools = state.value && state.value.pools ? state.value.pools : {}
      const poolIdsTaken = Object.keys(valuePools).sort()
      const poolIdInvalid = newPoolId.trim() !== '' && !ID_PATTERN.test(newPoolId.trim())
      const poolDraftOf = (id) => {
        const entry = poolById.get(id)
        const stored = valuePools[id] ?? null
        const base = entry
          ? { name: entry.name, enabled: entry.enabled, strategy: entry.strategy, accounts: entry.accounts ?? [] }
          : stored
            ? { name: stored.name ?? '', enabled: stored.enabled !== false, strategy: stored.strategy ?? 'healthy', accounts: stored.accounts ?? [] }
            : { name: '', enabled: true, strategy: 'healthy', accounts: [] }
        return { ...base, ...(poolDrafts[id] ?? {}) }
      }
      const setPoolDraft = (id, patch) => setPoolDrafts((current) => ({ ...current, [id]: { ...poolDraftOf(id), ...patch } }))

      const savePool = async (id, isNew) => {
        if (isNew && (!ID_PATTERN.test(id) || id === '')) return
        if (isNew && valuePools[id]) return
        setPoolBusy((current) => ({ ...current, [id]: true }))
        const draft = poolDraftOf(id)
        const value = { name: draft.name ?? '', enabled: draft.enabled !== false, strategy: draft.strategy ?? 'healthy', accounts: draft.accounts ?? [] }
        const outcome = await mutate([{ op: 'set', path: ['pools', id], value }])
        setPoolBusy((current) => ({ ...current, [id]: false }))
        setPoolNotice((current) => ({ ...current, [id]: outcome.ok ? t('saved') : outcome.message }))
        if (outcome.ok && isNew) { setNewPoolId(''); setAddingPool(false) }
      }

      const deletePool = async (id) => {
        if (!window.confirm(t('poolConfirmDelete'))) return
        await mutate([{ op: 'unset', path: ['pools', id] }])
        setPoolDrafts((current) => { const next = { ...current }; delete next[id]; return next })
      }

      // ── 预设 Agent 默认模型（EVO-013）派生与操作 ───────────────────────
      const valuePresets = value.presets && typeof value.presets === 'object' ? value.presets : {}
      const presetIds = Object.keys(valuePresets).sort()
      const emptyPresetDraft = () => ({ enabled: true, main: { provider: '', model: '' }, subagent: { provider: '', model: '' } })
      const presetDraftOf = (id) => {
        const stored = valuePresets[id]
        const base = stored
          ? {
            enabled: stored.enabled !== false,
            main: { provider: stored.main?.provider ?? '', model: stored.main?.model ?? '' },
            subagent: { provider: stored.subagent?.provider ?? '', model: stored.subagent?.model ?? '' },
          }
          : emptyPresetDraft()
        return { ...base, ...(presetDrafts[id] ?? {}) }
      }
      const setPresetDraft = (id, patch) => setPresetDrafts((current) => ({ ...current, [id]: { ...presetDraftOf(id), ...patch } }))
      const setPresetDraftField = (id, group, key, fieldValue) => setPresetDraft(id, { [group]: { ...presetDraftOf(id)[group], [key]: fieldValue } })

      const savePreset = async (id, isNew) => {
        if (!id) return
        if (isNew && valuePresets[id]) return
        setPresetBusy((current) => ({ ...current, [id]: true }))
        const draft = presetDraftOf(id)
        // 保存形状 = presetDefaultSchema（权威单点在 schemas.js）；布尔与
        // 空串归一保证 wire 保存值与 schema 默认同构。
        const value = {
          enabled: draft.enabled !== false,
          main: { provider: draft.main?.provider ?? '', model: draft.main?.model ?? '' },
          subagent: { provider: draft.subagent?.provider ?? '', model: draft.subagent?.model ?? '' },
        }
        const outcome = await mutate([{ op: 'set', path: ['presets', id], value }])
        setPresetBusy((current) => ({ ...current, [id]: false }))
        setPresetNotice((current) => ({ ...current, [id]: outcome.ok ? t('saved') : outcome.message }))
        if (outcome.ok && isNew) { setNewPresetId(''); setAddingPreset(false) }
      }

      const deletePreset = async (id) => {
        if (!window.confirm(t('presetsDeleteConfirm'))) return
        setPresetBusy((current) => ({ ...current, [id]: true }))
        await mutate([{ op: 'unset', path: ['presets', id] }])
        setPresetBusy((current) => ({ ...current, [id]: false }))
        setPresetDrafts((current) => { const next = { ...current }; delete next[id]; return next })
      }

      const addAccountToPool = async (poolId, accountId) => {
        const draft = poolDraftOf(poolId)
        if ((draft.accounts ?? []).includes(accountId)) return
        const outcome = await mutate([{ op: 'set', path: ['pools', poolId, 'accounts'], value: [...(draft.accounts ?? []), accountId] }])
        setPoolNotice((current) => ({ ...current, [poolId]: outcome.ok ? t('saved') : outcome.message }))
      }

      const removeAccountFromPool = async (poolId, accountId) => {
        const draft = poolDraftOf(poolId)
        const outcome = await mutate([{ op: 'set', path: ['pools', poolId, 'accounts'], value: (draft.accounts ?? []).filter((item) => item !== accountId) }])
        setPoolNotice((current) => ({ ...current, [poolId]: outcome.ok ? t('saved') : outcome.message }))
      }

      /** 池内「一键授权并加入池」：按预设创建账号 → 入池 → 立即一键授权。
       *  clientId 留空 = 使用内置公开 OAuth Client（零配置）。 */
      const oauthAddToPool = async (poolId, presetId, clientId) => {
        const preset = OAUTH_PRESETS.find((entry) => entry.id === presetId)
        if (!preset) return
        const ownClient = typeof clientId === 'string' && clientId.trim() !== ''
        let accountId = preset.id
        let n = 2
        while (oauthById.has(accountId)) { accountId = `${preset.id}-${n++}` }
        const value = {
          name: preset.draft.name ?? preset.id,
          enabled: true,
          protocol: preset.draft.protocol ?? 'openai-completions',
          baseURL: preset.draft.baseURL ?? '',
          clientId: ownClient ? clientId.trim() : '',
          publicClient: !ownClient,
          authUrl: preset.draft.authUrl ?? '',
          tokenUrl: preset.draft.tokenUrl ?? '',
          scope: preset.draft.scope ?? '',
          models: preset.draft.models ?? [],
          tokenRef: `ROUTER_OAUTH_${accountId.toUpperCase().replace(/[^A-Z0-9]+/g, '_')}_TOKEN`,
        }
        // FIX-015 防缩小证明：oauthAddToPool 恒为**新建**（accountId 去重循环
        // 保证永不写已存在账号）——models 空模板不会覆盖任何已有非空列表。
        const outcome = await mutate([{ op: 'set', path: ['oauthAccounts', accountId], value }])
        if (!outcome.ok) { setPoolNotice((current) => ({ ...current, [poolId]: outcome.message })); return }
        const joined = await mutate([{ op: 'set', path: ['pools', poolId, 'accounts'], value: [...(poolDraftOf(poolId).accounts ?? []), accountId] }])
        if (!joined.ok) { setPoolNotice((current) => ({ ...current, [poolId]: joined.message })); return }
        if (preset.draft.authUrl) await runOneClickOauth(accountId, value.tokenRef)
        else setPoolNotice((current) => ({ ...current, [poolId]: t('oauthNeedConfig') }))
      }

      // ── 分级分类卡片组装：专业 Agent 前置且默认展开，账号与统计默认折叠 ──
      // ARCH-004 B2：面·code 降级表 → 单面降级行数据（面级短码，见 sectionHead）。
      const degradedFaceList = Object.entries(state.faceFailures ?? {}).filter(([, code]) => typeof code === 'string' && code)
      const sectionHead = [
        el('h2', { className: 'dshrouter-title' }, t('title')),
        el('p', { className: 'dshrouter-intro' }, t('intro')),
        // ── 总开关（唯一不折叠，置顶）────────────────────────────────────
        el('div', { className: 'dshrouter-card' },
          el('label', { className: 'dshrouter-switch' },
            el('input', { type: 'checkbox', checked: enabled, disabled: !state.writable, onChange: toggleMaster }),
            t('masterSwitch')),
          el('p', { className: 'dshrouter-hint' }, t('masterHint')),
          !enabled ? el('p', { className: 'dshrouter-error' }, t('routeDisabled')) : null),
        // ARCH-004 B1（§6.1）：宿主面健康徽章 + 面板（一次性快照；
        // render 期零 probe——纯 HostHealthCard 缓存渲染）。B2 起并入本地
        // client 面健康（faceHealth——createClientRemotes health() 快照）。
        el(HostHealthCard, { hostHealth, faceHealth, hostFaceNotice, t }),
        // ARCH-004 B2（§4.3 域 1 降级行为）：单面降级行——面级短码入页面
        // （对比 FIX-028 时代 throw → 整页「加载失败」行：此处仅该面分区
        // 降级只读，其余面照常工作，永不整页崩）。
        degradedFaceList.length > 0 ? el('p', { className: 'dshrouter-error', style: { margin: '0', fontSize: '12px', wordBreak: 'break-all' } },
          t('faceDegraded')(degradedFaceList.map(([face, code]) => `${face}:${code}`).join(' · '))) : null,
      ]
      // ── 多模态账号（API Key → ChatGPT 订阅登录 → 子代理 → 高级扩展[账号池，默认折叠]）──
      const accountsBody = [
        el('p', { className: 'dshrouter-intro' }, t('accountIntro')),
        el('p', { className: 'dshrouter-hint' }, t('accountOAuth')),
        // llm-pi-ai 整体解析：任一账号无效（如缺 Base URL）会使整个模型
        // 目录回退为空（groups 与 failures 同时为空）——显式警示引导修复。
        addedAccounts.length > 0 && (state.models ?? []).length === 0 && (state.modelsFailure ?? []).length === 0
          ? el('p', { className: 'dshrouter-error' }, t('accountCatalogEmptyWarn'))
          : null,
        addedAccounts.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('accountMissing')) : null,
        ...addedAccounts.map((provider) => {
          const entry = providerEntry(provider)
          const total = accountTotalsById.get(provider)
          return el(AccountCard, {
            key: provider,
            provider,
            displayName: entry ? entry.displayName : provider,
            active: entry ? entry.active === true : true,
            models: accountModelsOf(provider),
            profile: accountProfileOf(provider),
            total,
            buckets: accountSeriesById.get(provider) ?? [],
            expanded: expandedAccounts[provider] === true,
            draft: accountDraftOf(provider),
            busy: !!accountBusy[provider],
            notice: accountNotice[provider],
            failure: (state.modelsFailure ?? []).find((item) => item.id === provider)?.message ?? '',
            declared: entry ? entry.declared === true : false,
            t,
            writable: state.writable,
            onToggle: () => toggleAccount(provider),
            onField: (field, fieldValue) => setAccountDraftField(provider, field, fieldValue),
            onSave: () => saveAccount(provider),
            onDiscover: () => discoverAccountModels(provider),
            onDelete: () => removeAccount(provider),
          })
        }),
        el(AddAccountCard, {
          t, adding: addingAccount, setAdding: setAddingAccount,
          account, setAccount, providers, writable: state.writable, busy: account.busy,
          failure: account.failure, accountProvider,
          onLogin: doLogin,
        }),
        // ── ChatGPT 订阅登录（正式通道，EVO-006 / DEC-026 C2 转正；
        //    EVO-007 与子代理交换位置上移为一级醒目位——正式通道优先呈现；
        //    无开关无 ToS 门；平台 ToS/账号风控提示保留，不阻断）──
        el('hr', { className: 'dshrouter-divider' }),
        el('div', { className: 'dshrouter-head' },
          el('span', { className: 'dshrouter-subtitle' }, t('presetTitle')),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-meta' }, t('presetSummary')(presetOauthEntries.length))),
        el('div', { className: 'dshrouter-card' },
          el('p', { className: 'dshrouter-hint' }, t('presetNotice')),
          presetOauthEntries.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('presetIntro')) : null,
          ...presetOauthEntries.map((entry) => el(PresetAccountCard, {
            key: entry.id, id: entry.id, entry,
            busy: !!oauthBusy[entry.id], notice: oauthNotice[entry.id],
            t, writable: state.writable,
            modelsValue: presetModelsDraftOf(entry.id),
            onModelsChange: (value) => setPresetModels((current) => ({ ...current, [entry.id]: value })),
            onSaveModels: () => savePresetModels(entry.id),
            onLogin: () => runPresetLogin(entry.id),
            onLogout: () => logoutPresetAccount(entry.id),
            onDelete: () => deletePresetAccount(entry.id),
            // EVO-010：调用通路开关 + 官方路由状态行数据源。
            routeStatus: state.catalog?.openaiCodexRoute,
            onTransportChange: (value) => savePresetTransport(entry.id, value),
          })),
          el('div', { className: 'dshrouter-row' },
            el('button', { type: 'button', className: 'dshrouter-button', disabled: !state.writable, onClick: addPresetAccount }, t('presetAdd')))),
        // ── 子代理（无头 CLI：codex/claude/gemini 等账号类条目，ChatGPT 之后）──
        el('hr', { className: 'dshrouter-divider' }),
        el('div', { className: 'dshrouter-head' },
          el('span', { className: 'dshrouter-subtitle' }, t('cliTitle')),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-meta' }, t('cliSummary')(cliEntryIds.length))),
        el('p', { className: 'dshrouter-hint' }, t('cliIntro')),
        cliEntryIds.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('accountMissing')) : null,
        ...cliEntryIds.map((id) => {
          const entry = cliEntriesById.get(id)
          // FIX-031：子代理用量的账号侧记账键 = 规范账号键（服务端 accountKind
          // 'cli' + 清洁 id；旧实现按内部 `cli:<id>` 形态直查聚合表）。
          const total = accountTotalsByKindId.get(`cli|${id}`) ?? accountTotalsById.get(id)
          return el(CliAgentCard, {
            key: id, id, entry, total,
            expanded: expandedCli[id] === true,
            draft: cliDraftOf(id),
            busy: !!cliBusy[id],
            notice: cliNotice[id],
            cliState: cliStates[id],
            t, writable: state.writable,
            onToggle: () => setExpandedCli((current) => ({ ...current, [id]: !current[id] })),
            onField: (field, fieldValue) => setCliDraft(id, { [field]: fieldValue }),
            onSave: () => saveCliAgent(id, false),
            onDelete: () => deleteCliAgent(id),
            onCliLogin: () => runCliLogin(id),
            onCliStatus: () => runCliStatus(id),
            onCliModels: () => runCliModels(id),
          })
        }),
        el(AddCliCard, {
          t, adding: addingCli, setAdding: setAddingCli,
          onQuickAdd: (kind) => quickAddCli(kind),
        }),
        // ── 高级扩展：账号池 + 未入池 OAuth 账号（收进折叠卡片，默认不展开。
        //    EVO-007：OAuth 官方登录区整块移除、ChatGPT 订阅登录上移后，折叠
        //    区仅余账号池与孤儿账号删除兜底——折叠壳保留，避免一级区空置噪音）──
        el(CategoryCard, {
          title: t('advancedSection'),
          summary: t('poolSummary')(poolIds.length),
          expanded: expandedAdvanced === true,
          t,
          onToggle: () => setExpandedAdvanced((current) => !current),
          children: [
            // 账号池（扩展功能；多账号健康路由 + 失败切换）
            el('div', { className: 'dshrouter-head' },
              el('span', { className: 'dshrouter-subtitle' }, t('poolTitle')),
              el('span', { className: 'dshrouter-spacer' }),
              el('span', { className: 'dshrouter-meta' }, t('poolSummary')(poolIds.length))),
            el('p', { className: 'dshrouter-hint' }, t('poolIntro')),
            poolIds.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('accountMissing')) : null,
            ...poolIds.map((id) => {
              const entry = poolById.get(id)
              return el(PoolCard, {
                key: id, id, pool: entry ?? { name: '', enabled: true, strategy: 'healthy', accounts: [] },
                health: entry ? entry.accountHealth ?? [] : [],
                oauthEntries: oauthEntries, tokenStates: oauthTokenStates,
                expanded: expandedPools[id] === true,
                draft: poolDraftOf(id),
                busy: !!poolBusy[id],
                notice: poolNotice[id],
                t, writable: state.writable,
                onToggle: () => setExpandedPools((current) => ({ ...current, [id]: !current[id] })),
                onField: (field, fieldValue) => setPoolDraft(id, { [field]: fieldValue }),
                onSave: () => savePool(id, false),
                onDelete: () => deletePool(id),
                onAddAccount: (accountId) => addAccountToPool(id, accountId),
                onRemoveAccount: (accountId) => removeAccountFromPool(id, accountId),
                onOneClickAccount: (accountId) => runOneClickOauth(accountId),
                onDiscoverAccount: (accountId) => discoverOauth(accountId),
                onOauthAddToPool: (poolId, presetId, clientId) => oauthAddToPool(poolId, presetId, clientId),
                // F-1（EVO-007 R0 返工）：池行整账号删除入口 + 结果提示。
                onDeleteAccount: (accountId) => deleteOauthAccount(accountId),
                accountBusy: oauthBusy,
                accountNotice: oauthNotice,
              })
            }),
            el(AddPoolCard, {
              t, adding: addingPool, setAdding: setAddingPool,
              newId: newPoolId, setNewId: setNewPoolId,
              idTaken: poolIdsTaken.includes(newPoolId.trim()),
              idInvalid: poolIdInvalid,
              writable: state.writable,
              onSave: () => savePool(newPoolId.trim(), true),
            }),
            // 未入池的 OAuth 账号（F-1 孤儿兜底：池行删除覆盖池内账号，
            // 此处覆盖池外历史残留——极简列表行，仅删除入口）
            ...(orphanOauthIds.length > 0 ? [
              el('hr', { className: 'dshrouter-divider' }),
              el('div', { className: 'dshrouter-head' },
                el('span', { className: 'dshrouter-subtitle' }, t('orphanOauthTitle')),
                el('span', { className: 'dshrouter-spacer' }),
                el('span', { className: 'dshrouter-meta' }, t('orphanOauthSummary')(orphanOauthIds.length))),
              el('p', { className: 'dshrouter-hint' }, t('orphanOauthIntro')),
              ...orphanOauthIds.map((id) => {
                const entry = oauthById.get(id)
                return el('div', { className: 'dshrouter-card', key: id },
                  el('div', { className: 'dshrouter-row' },
                    el('span', { className: 'dshrouter-dot bad', title: t('oauthNotLoggedIn') }),
                    el('span', { className: 'dshrouter-name' }, entry ? entry.name || id : id),
                    el('span', { className: 'dshrouter-id' }, id),
                    el('span', { className: 'dshrouter-spacer' }),
                    el('button', {
                      type: 'button', className: 'dshrouter-button danger',
                      disabled: !state.writable || !!oauthBusy[id],
                      title: t('oauthDeleteConfirm'),
                      onClick: () => deleteOauthAccount(id),
                    }, t('poolDeleteAccount'))),
                  oauthNotice[id] ? el('p', { className: 'dshrouter-hint' }, oauthNotice[id]) : null)
              }),
            ] : []),
          ],
        }),
      ]
      // ── 统计信息（辅助功能区，默认折叠）───────────────────────────────
      const statsBody = [
        el('p', { className: 'dshrouter-intro' }, t('statsIntro')),
        stats && stats.enabled === false ? el('p', { className: 'dshrouter-error' }, t('statsDisabled')) : null,
        // 操作行（清空 + 导出）：工具行不是统计数据——留在卡顶（用户布局
        // 裁决 2026-09-06：统计内容全部归入二级卡，操作行除外）。
        el('div', { className: 'dshrouter-row' },
          el('span', { className: 'dshrouter-meta' }, t('statsExportRange')),
          el('select', { className: 'dshrouter-select', 'aria-label': t('statsExportRange'), value: exportRange, onChange: (event) => setExportRange(event.target.value) },
            el('option', { value: '7d' }, '7d'),
            el('option', { value: '30d' }, '30d'),
            el('option', { value: '90d' }, '90d')),
          el('span', { className: 'dshrouter-meta' }, t('statsExportLevel')),
          el('select', { className: 'dshrouter-select', 'aria-label': t('statsExportLevel'), value: exportLevel, onChange: (event) => setExportLevel(event.target.value) },
            el('option', { value: 'agent' }, 'agent'),
            el('option', { value: 'account' }, 'account'),
            el('option', { value: 'preset' }, 'preset')),
          el('button', { type: 'button', className: 'dshrouter-button ghost', disabled: exportBusy, onClick: exportStats }, t('statsExport')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: clearStats }, t('statsReset')),
          exportNotice ? el('span', { className: 'dshrouter-meta' }, exportNotice) : null),
        // ── EVO-017 分级统计（用户规格 2026-09-05）：三张二级卡片（默认折叠）
        //    ——预设 Agent 统计 / 专业 Agent 统计 / 账号级统计；各含按分组
        //    三级卡片（默认折叠），每分组三类：总用量 / 每日用量 / 实时调用
        //    （最新 10 条）。───────────────────────────────────────────────
        el(CategoryCard, {
          title: t('statsPresetLevel'), summary: t('statsPresetSummary')(presetStatsRows.length),
          expanded: expandedSection.statsPresets === true, t, onToggle: () => toggleSection('statsPresets'),
          children: [
            el('p', { className: 'dshrouter-hint' }, t('statsPresetScopeHint')),
            presetStatsRows.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : null,
            ...presetStatsRows.map((row) => el(PresetStatsCard, {
              key: `pstat:${row.preset}`,
              preset: row.preset, row, accountNames, t,
              expanded: expandedStats[`pstat:${row.preset}`] === true,
              onToggle: () => toggleStatCard(`pstat:${row.preset}`),
            })),
          ],
        }),
        el(CategoryCard, {
          title: t('statsAgentLevel'), summary: t('statsAgentSummary')(agentStatsRows.length),
          expanded: expandedSection.statsAgents === true, t, onToggle: () => toggleSection('statsAgents'),
          children: [
            agentStatsRows.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : null,
            // EVO-017 R2：专业 Agent 分组复用统一分组卡（总用量/每日/实时
            // 三段——GroupStatsCard；days/recent 来自 R2 派生索引）。
            // FIX-031：分组行 = 配置的专业 agent + 「主模型」统一实体（twin/main
            // 两条内部记录路径在此归一，DEC-029①——路由中间构件不再另立分组）。
            ...agentStatsRows.map(({ id, isMainModel }) => {
              const total = statsTotals.get(id)
              const statKey = `agent:${id}`
              return el(GroupStatsCard, {
                key: statKey,
                title: isMainModel ? t('statsMainModel') : (total ? total.name : (rosterDisplayName(accountNames, 'agent', id) ?? id)),
                badge: isMainModel ? '' : id,
                summaryText: `${t('statsCalls')} ${total ? total.calls : 0} · ${t('statsErrors')} ${total ? total.errors : 0} · ${fmtTokens(total ? total.inputTokens : 0)}/${fmtTokens(total ? total.outputTokens : 0)}`,
                totals: total ?? { calls: 0, errors: 0, inputTokens: 0, outputTokens: 0, totalMs: 0 },
                days: agentDaysById.get(id) ?? [],
                recent: recentByAgentId.get(id) ?? [],
                models: [],
                accountNames,
                expanded: expandedStats[statKey] === true,
                t,
                onToggle: () => toggleStatCard(statKey),
              })
            }),
          ],
        }),
        el(CategoryCard, {
          title: t('statsAccountLevel'), summary: t('statsAccountSummary')(statsAccountRows.length),
          expanded: expandedSection.statsAccounts === true, t, onToggle: () => toggleSection('statsAccounts'),
          children: [
            el('p', { className: 'dshrouter-hint' }, t('statsAccountScopeHint')),
            statsAccountRows.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('statsNoCalls')) : null,
            // EVO-017 R2：账号分组复用统一分组卡（模型分布进总用量段；
            // days/recent 来自 R2 派生索引；含插件自注册键全量）。
            // FIX-031：标题 = 配置面账号显示名（归一化键 → roster 映射）；徽标
            // 只给可配置 provider 账号（oauth/pool/cli 身份键不外显）。
            ...statsAccountRows.map((row) => {
              const statKey = `acct:${row.accountKind ?? 'provider'}:${row.provider}`
              // FIX-031 D5：明细取数与身份去重同键空间（归一账号键）——roster
              // 行的原始 provider 键与统计行清洁键滚动期共存时展开卡不空挂。
              const accountTotal = accountTotalsByKindId.get(accountKindKey(row.accountKind, row.provider)) ?? accountTotalsById.get(accountDisplayKeyOf(row.provider))
              const models = accountTotal && accountTotal.models ? accountTotal.models : []
              return el(GroupStatsCard, {
                key: statKey,
                title: row.displayName || statsProviderLabelOf(row, accountNames, t),
                badge: (row.accountKind ?? 'provider') === 'provider' ? row.provider : '',
                summaryText: `${t('statsCalls')} ${row.calls} · ${t('statsErrors')} ${row.errors} · ${fmtTokens(row.inputTokens)}/${fmtTokens(row.outputTokens)}`,
                totals: { calls: row.calls, errors: row.errors, inputTokens: row.inputTokens, outputTokens: row.outputTokens, totalMs: row.totalMs, lastAt: row.lastAt },
                days: accountDaysById.get(accountDisplayKeyOf(row.provider)) ?? [],
                recent: recentByAccountId.get(accountDisplayKeyOf(row.provider)) ?? [],
                models,
                accountNames,
                expanded: expandedStats[statKey] === true,
                t,
                onToggle: () => toggleStatCard(statKey),
              })
            }),
          ],
        }),
        // 全局统计二级卡（用户布局裁决 2026-09-06：散落的全局元素收编；
        // EVO-017 R2 复用统一分组体——总用量/每日/实时三段同构）。
        el(CategoryCard, {
          title: t('statsGlobalLevel'), summary: `${t('statsCalls')} ${sumAll.calls} · ${t('statsErrors')} ${sumAll.errors}`,
          expanded: expandedSection.statsGlobal === true, t, onToggle: () => toggleSection('statsGlobal'),
          children: [
            el('div', { className: 'dshrouter-stats' },
              el(GroupStatsBody, {
                totals: { calls: sumAll.calls, errors: sumAll.errors, inputTokens: sumAll.inTokens, outputTokens: sumAll.outTokens, totalMs: 0 },
                days: Object.keys(statsDays).sort().map((date) => ({ date, ...statsDays[date], models: [] })),
                recent: recentCalls.slice(0, 10),
                models: [],
                accountNames,
                t,
              })),
          ],
        }),
      ]
      // ── 预设 Agent（EVO-013：按 DSH 预设粒度的默认模型；第一张分类卡片，
      //    默认折叠）──────────────────────────────────────────────────────
      const presetsBody = [
        el('p', { className: 'dshrouter-intro' }, t('presetsIntro')),
        // FIX-030-C：预设生效诊断（最近事件——applied/skip 原因/target；
        // 观测面：配置是否生效一眼可判，排障不再依赖宿主终端日志）。
        presetDiag.length > 0 ? el('details', { className: 'dshrouter-notice', style: { margin: '8px 0' } },
          el('summary', { style: { cursor: 'pointer', fontSize: '12px' } }, t('presetDiagTitle')),
          el('div', { style: { fontSize: '12px', lineHeight: 1.7, marginTop: '6px', wordBreak: 'break-all' } },
            ...presetDiag.map((entry, index) => el('div', { key: `diag-${index}-${entry.at}` },
              `${new Date(entry.at).toLocaleTimeString()} ${entry.applied ? '✓' : '✗'} ${entry.preset || '—'} → ${entry.target ? `${entry.target.provider}/${entry.target.model}` : '—'}${entry.skip ? ` (${entry.skip})` : ''}`)),
            el('div', { style: { opacity: 0.6, marginTop: '4px' } }, t('presetDiagHint')))) : null,
        presetRoster.status === 'error' ? el('p', { className: 'dshrouter-error' }, `${t('presetsRosterError')}${presetRoster.failure ? `：${presetRoster.failure}` : ''}`) : null,
        presetIds.length === 0 ? el('p', { className: 'dshrouter-hint' }, t('presetsEmpty')) : null,
        ...presetIds.map((id) => {
          const rosterEntry = (presetRoster.items ?? []).find((entry) => entry.id === id)
          return el(PresetCard, {
            key: id, id, draft: presetDraftOf(id), rosterEntry,
            providers, models: state.models ?? [],
            busy: !!presetBusy[id], notice: presetNotice[id],
            expanded: expandedPresets[id] === true,
            t, writable: state.writable,
            onToggle: () => setExpandedPresets((current) => ({ ...current, [id]: !current[id] })),
            onGroupField: (group, key, fieldValue) => setPresetDraftField(id, group, key, fieldValue),
            onSave: () => savePreset(id, false),
            onDelete: () => deletePreset(id),
          })
        }),
        el(AddPresetCard, {
          t, adding: addingPreset, setAdding: setAddingPreset,
          newPresetId,
          onChoosePreset: (id) => {
            setNewPresetId(id)
            // 切换预设清空同 id 残留草稿（从干净模板开始，避免上一预设的
            // 未保存字段串扰）。
            const trimmed = id.trim()
            if (!trimmed) return
            setPresetDrafts((current) => { const next = { ...current }; delete next[trimmed]; return next })
          },
          newPresetDraft: newPresetId.trim() ? presetDraftOf(newPresetId.trim()) : emptyPresetDraft(),
          onGroupField: (group, key, fieldValue) => {
            const trimmed = newPresetId.trim()
            if (!trimmed) return
            setPresetDraftField(trimmed, group, key, fieldValue)
          },
          rosterItems: presetRoster.items ?? [], configuredIds: presetIds,
          providers, models: state.models ?? [],
          writable: state.writable, busy: !!presetBusy[newPresetId.trim()],
          onSave: () => savePreset(newPresetId.trim(), true),
        }),
      ]
      // ── 核心区：专业 Agent（前置，默认展开）────────────────────────────
      const agentsBody = [
        el('p', { className: 'dshrouter-intro' }, t('agentsIntro')),
        agentIds.length === 0 ? el('p', { className: 'dshrouter-intro' }, t('noAgents')) : null,
        ...agentIds.map((id) => {
          const draft = draftOf(id)
          const catalog = catalogById.get(id)
          const testResult = testResults[id]
          return el(AgentCard, {
            key: id, id, draft, t, writable: state.writable, busy: !!busy[id], notice: notice[id],
            providers, models: state.models ?? [], catalog, oauthAccounts: oauthEntries, pools: poolEntries, cliEntries, testResult,
            stat: statsTotals.get(id) ?? null,
            buckets: statsSeries.get(id) ?? [],
            expanded: expandedAgents[id] === true,
            cliState: draft.type === 'cli' ? cliStates[(draft.cliAgent ?? '').trim() || `agent:${id}`] : undefined,
            onToggle: () => toggleExpanded(id),
            onField: (key, fieldValue) => setDraftField(id, key, fieldValue),
            onSave: () => saveAgent(id, false),
            onDelete: () => deleteAgent(id),
            onTest: () => runTest(id),
            onDiscover: (provider) => setDiscover({ id, provider }),
            onCliLogin: () => runCliLogin(id, (draft.cliAgent ?? '').trim() || `agent:${id}`),
          })
        }),
        el(AddAgentCard, {
          t, adding, setAdding, newId, setNewId, idTaken, idInvalid,
          writable: state.writable,
          agentIds,
          onSave: () => saveAgent(newId.trim(), true),
          onTemplate: addFromTemplate,
        }),
      ]
      return el('section', { className: 'dshrouter-section', 'aria-label': t('title') },
        ...sectionHead,
        // ── 分级分类卡片：预设 Agent 第一张（默认折叠）；专业 Agent 前置且
        //    默认展开；账号与统计默认折叠 ──────────────────────────────────
        el(CategoryCard, {
          title: t('presetsTitle'), summary: t('presetsSummary')(presetIds.length),
          expanded: expandedSection.presets === true, t, onToggle: () => toggleSection('presets'),
          children: presetsBody,
        }),
        el(CategoryCard, {
          title: t('agentsTitle'), summary: t('agentsSummary')(agentIds.length),
          expanded: expandedSection.agents === true, t, onToggle: () => toggleSection('agents'),
          children: agentsBody,
        }),
        el(CategoryCard, {
          title: t('accountTitle'), summary: `${t('accountSummary')(addedAccounts.length)} · ${t('cliSummary')(cliEntryIds.length)}`,
          expanded: expandedSection.accounts === true, t, onToggle: () => toggleSection('accounts'),
          children: accountsBody,
        }),
        el(CategoryCard, {
          title: t('statsTitle'), summary: t('statsSummary')(sumAll.calls, sumAll.errors),
          expanded: expandedSection.stats === true, t, onToggle: () => toggleSection('stats'),
          children: statsBody,
        }),
        // 发现模型弹窗
        discover ? el(DiscoverModal, {
          api, t, provider: discover.provider,
          providers,
          baseURL: (accountProfileOf(discover.provider) ?? {}).baseURL ?? '',
          onClose: () => setDiscover(null),
          onAdopt: (model) => { setDraftField(discover.id, 'model', model); setDiscover(null) },
        }) : null,
      )
    }

    /** cli 登录状态指示 chip（圆点与文字分离：dshrouter-dot 是纯色点，不承载文字）。
     *  未登录时文字以错误色（红）呈现，避免灰色小字不醒目。 */
    function cliStatusChipOf(cliState, t) {
      const loggedOut = !!cliState && cliState.loggedIn === false && !cliState.statusBusy
      const chip = cliState && cliState.statusBusy
        ? { dot: '', text: `${t('fetching')}…` }
        : cliState && cliState.loggedIn === true
          ? { dot: 'ok', text: t('cliStatusLoggedIn') }
          : cliState && cliState.loggedIn === false
            ? { dot: 'bad', text: t('cliStatusLoggedOut') }
            : { dot: '', text: t('cliStatusUnknown') }
      return el('span', { className: 'dshrouter-meta' + (loggedOut ? ' dshrouter-error' : ''), title: cliState && cliState.statusMessage },
        el('span', { className: `dshrouter-dot ${chip.dot}`.trim(), style: { marginRight: 6 } }),
        chip.text)
    }

    /**
     * ARCH-004 B1（§6.1）：宿主面健康徽章行 + 可展开面板。纯快照渲染：
     * 只读 hostHealth 状态缓存（一次性 effect 取数），render 期零 probe/
     * 零 RPC 调用（§7.1 探针惰性化的渲染面保证——判别锚点
     * tests/host-abi-health.mjs §3）。布局参照 presetDiag 最近事件行先例
     * （details/summary 折叠行）；徽章语义：✓ 全绿 / ⚠ n 面降级或缺失；
     * ARCH-005 R2 起协商三态——matched 绿 / compatible-unknown 黄
     * （dshrouter-warn + 「未实测宿主版本」提示）/ incompatible 红（面降级
     * 口径，capabilityProfile.state 驱动，见下方渲染体注释）。
     */
    function HostHealthCard(props) {
      const { hostHealth, faceHealth, hostFaceNotice, t } = props
      // ARCH-004 B2：faces/diag = RPC 面（hostFaceDiagnostics——Node 侧注册表
      // 快照）∪ 本地 client 面（faceHealth——createClientRemotes health()
      // 一次性探测快照；remote.* 客户端 fiber 面 Node 侧不可见故本地并入）。
      // 纯 props 读——render 期零 probe（§7.1 判别锚点 tests/host-abi-health
      // §3）。任一数据源在场即渲染（旧服务端无 RPC 面时本地徽章仍可见）。
      // FIX-047（F-11，R0 P3）：取数失败通知本身即「必须上屏的信息」——双源
      // 皆缺（health 面不可用 ⇒ faceHealth 恒 null，且取数失败 ⇒ hostHealth 为
      // null）时旧早退条件会把通知一并吞掉（静默）。故 failure 判定前移并纳入
      // 早退条件：失败态恒渲染，其余情况行为不变。
      const failure = hostFaceNotice && typeof hostFaceNotice === 'object' ? hostFaceNotice : null
      if ((!hostHealth || typeof hostHealth !== 'object') && (!faceHealth || typeof faceHealth !== 'object') && !failure) return null
      const mergedFaces = [
        ...(hostHealth && Array.isArray(hostHealth.faces) ? hostHealth.faces : []),
        ...(faceHealth && Array.isArray(faceHealth.faces) ? faceHealth.faces : []),
      ]
      // F-6（EVO-020 R0 台账，EVO-022 B4 ⑧收口）：faces 合并按名去重——
      // 两数据源重叠时（Node 注册表与本地 client 面同名，如 remote.llm 双
      // 登记）防重复行；先到先留（RPC 权威序在前）。无名面透传不丢弃
      // （FaceHealth 形状保证 name 字符串，此处防御宿主漂移）。
      const seen = new Set()
      const faces = mergedFaces.filter((face) => {
        if (!face || typeof face.name !== 'string') return true
        if (seen.has(face.name)) return false
        seen.add(face.name)
        return true
      })
      const diag = [
        ...(faceHealth && Array.isArray(faceHealth.diag) ? faceHealth.diag : []),
        ...(hostHealth && Array.isArray(hostHealth.diag) ? hostHealth.diag : []),
      ]
      // FIX-046（P8）：取数失败**不**计入降级面数——面数与本地 face 探针一一
      // 对应（remote.llm/settings/credentials/agentPresets/session 五面），
      // router 自身 RPC 失败不与任一探针面混同（同批：失败态由失败徽章 + 失败行
      // 承载，不借面数篡改语义）。
      // R1 更正（R0 F-3）：R0 指出原注释「『恒 ? 而全绿』的误导性已由该行消除」
      // 不成立——`degraded` 只由面数派生，失败态曾与绿色徽章同排。现改为失败态
      // 徽章位直接渲染失败文案（见下方 summary），原声称已由行为消除。
      // FIX-047（N-2，R1 P3）：失败 ∧ 降级**并存**时折叠态同时给出失败短码与
      // 降级面计数（summary 文本单点合成，见下）——旧形态只渲染失败文案，
      // 降级计数仅存在于展开体 faces 行。`degraded` 口径不变（仍只由 faces 派生，
      // 失败不计入面数）。
      const degraded = faces.filter((face) => face && face.state !== 'ok').length
      const versions = hostHealth && hostHealth.hostVersions && typeof hostHealth.hostVersions === 'object'
        ? hostHealth.hostVersions
        : { llm: '?', tools: '?', typertProtocol: '?' }
      // ARCH-005 R2：协商三态徽章——capabilityProfile.state（router/hostFaceDiagnostics
      // RPC 一次性 effect 快照，render 期纯读零 probe/零 RPC）。优先级：取数失败 >
      // 面降级（incompatible 口径，红）> 版本 ∉ 实测基线档案（compatible-unknown，
      // 黄——显式「未实测宿主版本」提示）> matched（绿 + 实测基线 id）。字段缺席
      // （旧服务端/非strict响应）→ 回落既有两态口径，不误黄。gate-block regime
      // 下本面板不可达（宿主装载门拒载——版本域权威注释见 host-abi/version.js）。
      const capability = hostHealth && hostHealth.capabilityProfile && typeof hostHealth.capabilityProfile === 'object' ? hostHealth.capabilityProfile : null
      const baselineNote = capability && capability.state === 'matched' && typeof capability.baselineId === 'string' && capability.baselineId
        ? t('hostHealthBaseline')(capability.baselineId)
        : ''
      const stateUnknown = !failure && degraded === 0 && capability !== null && capability.state === 'compatible-unknown'
      // FIX-046（P8）→ 返工（R0 F-1/F-2）：失败原因**并列**于「最近宿主诊断事件」
      // 区首行（R0 F-1：原实现以失败行**替换** diag 全集 ⇒ 失败时本地镜像环条目
      // face-degraded / event-subscribe-* / inject-face-missing 被静默隐藏）；且
      // 短码上抬进 summary（R0 F-2：原实现把短码放进默认折叠的 details 体内 ⇒
      // 「直接可见」不成立——V-9 验收要求失败原因直接可见）。
      const diagRows = failure
        ? [{ at: Date.now(), kind: 'host-face-rpc', face: 'remote.router', code: failure.code, detail: failure.detail }, ...diag]
        : diag
      return el('details', { className: 'dshrouter-notice', style: { margin: '0' } },
        el('summary', { style: { cursor: 'pointer', fontSize: '12px' } },
          el('span', { className: failure || degraded > 0 ? 'dshrouter-error' : stateUnknown ? 'dshrouter-warn' : 'dshrouter-ok' },
            failure
              ? `${t('hostHealthRpcFailed')(failure.code)}${degraded > 0 ? ` · ${t('hostHealthWarn')(degraded)}` : ''}`
              : degraded > 0 ? t('hostHealthWarn')(degraded)
                : stateUnknown ? t('hostHealthUnknown')
                  : t('hostHealthOk')),
          el('span', { className: 'dshrouter-meta', style: { marginLeft: 8 } },
            ` ${t('hostHealthTitle')} · ${failure ? t('hostHealthVersionsUnavailable') : `${t('hostHealthVersions')(versions)}${baselineNote}`}`)),
        el('div', { style: { fontSize: '12px', lineHeight: 1.7, marginTop: '6px', wordBreak: 'break-all' } },
          failure ? el('div', { className: 'dshrouter-error' }, failure.detail || '') : null,
          stateUnknown ? el('div', { className: 'dshrouter-warn' }, t('hostHealthUnknownHint')) : null,
          faces.length === 0
            ? el('div', { style: { opacity: 0.6 } }, t('hostHealthNoProbes'))
            : el('div', null, t('hostHealthFacesTitle'),
              ...faces.map((face, index) => el('div', { key: `hface-${index}-${face.name}` },
                `${face.state === 'ok' ? '✓' : face.state === 'degraded' ? '⚠' : '✗'} ${face.name}${face.detail ? ` (${face.detail})` : ''}`))),
          el('div', { style: { marginTop: '4px' } }, t('hostHealthDiagTitle'),
            diagRows.length === 0
              ? el('div', { style: { opacity: 0.6 } }, t('hostHealthNoDiag'))
              : el('div', null,
                ...diagRows.slice(0, 8).map((entry, index) => el('div', { key: `hdiag-${index}-${entry.at}` },
                  `${new Date(entry.at).toLocaleTimeString()} ${entry.kind}${entry.face ? ` ${entry.face}` : ''}${entry.code ? ` (${entry.code})` : ''}${entry.detail ? ` ${entry.detail}` : ''}`))))))
    }

    /** 子代理条目卡片（账号区的「子代理」区：命令/登录/模型/统计）。 */
    function CliAgentCard(props) {
      const { id, total, expanded, draft, busy, notice, cliState, t, writable, onToggle, onField, onSave, onDelete, onCliLogin, onCliStatus, onCliModels } = props
      return el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          el('span', { className: 'dshrouter-name' }, draft.name || id),
          el('span', { className: 'dshrouter-id' }, id),
          el('span', { className: 'dshrouter-tag' }, draft.command || 'cli'),
          el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')} ${total ? total.calls : 0} · ${t('statsErrors')} ${total ? total.errors : 0} · ${total && total.calls > 0 ? fmtMs(total.totalMs / total.calls) : '—'}`),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')),
        expanded ? el('div', { className: 'dshrouter-stats' },
          notice ? el('p', { className: 'dshrouter-hint' }, notice) : null,
          el('div', { className: 'dshrouter-row', style: { alignItems: 'flex-end' } },
            el('div', { className: 'dshrouter-field', style: { flex: '0 0 150px' } },
              el('span', { className: 'dshrouter-field-label' }, t('cliLoginStatus')),
              cliStatusChipOf(cliState, t)),
            el('button', { type: 'button', className: 'dshrouter-button', disabled: busy || !writable || (cliState && cliState.loginBusy), onClick: onCliLogin },
              cliState && cliState.loginBusy ? t('cliLoginWaiting') : (cliState && cliState.loggedIn === true ? t('cliRelogin') : t('cliLogin'))),
            el('button', { type: 'button', className: 'dshrouter-button ghost', disabled: cliState && cliState.statusBusy, onClick: onCliStatus }, t('cliStatusRefresh'))),
          cliState && cliState.statusMessage ? el('p', { className: cliState.loggedIn === false ? 'dshrouter-error' : 'dshrouter-hint' }, cliState.statusMessage) : null,
          cliState && cliState.loginNotice ? el('p', { className: cliState.loginError === true ? 'dshrouter-error' : 'dshrouter-hint' }, cliState.loginNotice) : null,
          el('div', { className: 'dshrouter-row' },
            el('div', { className: 'dshrouter-field', style: { flex: '0 0 180px' } },
              el('span', { className: 'dshrouter-field-label' }, t('fieldName')),
              el('input', { className: 'dshrouter-input', value: draft.name ?? '', onChange: (event) => onField('name', event.target.value) })),
            el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('fieldCommand')),
              el('input', { className: 'dshrouter-input', value: draft.command ?? '', placeholder: 'codex', onChange: (event) => onField('command', event.target.value) })),
            el('div', { className: 'dshrouter-field', style: { flex: '0 0 260px' } },
              el('span', { className: 'dshrouter-field-label' }, t('fieldCliArgs')),
              el('input', { className: 'dshrouter-input', value: draft.args ?? '', placeholder: 'exec --json（留空 = 平台自适应默认）', onChange: (event) => onField('args', event.target.value) }))),
          el('div', { className: 'dshrouter-row', style: { alignItems: 'flex-end' } },
            el('div', { className: 'dshrouter-field', style: { flex: '0 0 180px' } },
              el('span', { className: 'dshrouter-field-label' }, t('fieldCliTimeout')),
              el('input', { className: 'dshrouter-input', type: 'number', min: 0, step: 1, value: draft.timeoutMs ? Math.round(Number(draft.timeoutMs) / 60000) : '', placeholder: '15', onChange: (event) => onField('timeoutMs', Math.max(0, Math.trunc(Number(event.target.value) || 0)) * 60000) })),
            el('div', { className: 'dshrouter-field', style: { flex: '0 0 120px' } },
              el('span', { className: 'dshrouter-field-label' }, t('fieldCliConcurrent')),
              el('input', { className: 'dshrouter-input', type: 'number', min: 1, max: 4, step: 1, value: draft.maxConcurrent ?? 1, onChange: (event) => onField('maxConcurrent', Math.max(1, Math.min(4, Math.trunc(Number(event.target.value) || 1)))) })),
            el('button', { type: 'button', className: 'dshrouter-button ghost', style: { flex: 'none' }, disabled: cliState && cliState.modelsBusy, onClick: onCliModels },
              cliState && cliState.modelsBusy ? t('cliFetchingModels') : t('cliFetchModels'))),
          cliState && cliState.modelsMessage ? el('p', { className: 'dshrouter-hint' }, cliState.modelsMessage) : null,
          el('details', null,
            el('summary', { className: 'dshrouter-meta' }, t('advancedLogin')),
            el('div', { className: 'dshrouter-stats', style: { marginTop: 8 } },
              el('div', { className: 'dshrouter-field' },
                el('span', { className: 'dshrouter-field-label' }, t('fieldCliLoginArgs')),
                el('input', { className: 'dshrouter-input', value: draft.loginArgs ?? '', placeholder: 'login / auth login', onChange: (event) => onField('loginArgs', event.target.value) })),
              el('div', { className: 'dshrouter-field' },
                el('span', { className: 'dshrouter-field-label' }, t('fieldCliStatusArgs')),
                el('input', { className: 'dshrouter-input', value: draft.statusArgs ?? '', placeholder: 'login status / auth status', onChange: (event) => onField('statusArgs', event.target.value) })),
              el('div', { className: 'dshrouter-field' },
                el('span', { className: 'dshrouter-field-label' }, t('fieldCliModelsArgs')),
                el('input', { className: 'dshrouter-input', value: draft.modelsArgs ?? '', placeholder: '--list-models', onChange: (event) => onField('modelsArgs', event.target.value) })))),
          el('div', { className: 'dshrouter-row' },
            el('button', { type: 'button', className: 'dshrouter-button', disabled: busy || !writable, onClick: onSave }, busy ? t('saving') : t('save')),
            el('span', { className: 'dshrouter-spacer' }),
            el('button', { type: 'button', className: 'dshrouter-button danger', disabled: busy || !writable, onClick: onDelete }, t('cliDelete')))) : null)
    }

    /** 子代理列表末尾的「+」创建卡片（选 CLI 即创建并预填）。 */
    function AddCliCard(props) {
      const { t, adding, setAdding, onQuickAdd } = props
      if (!adding) {
        return el('div', { className: 'dshrouter-add', role: 'button', tabIndex: 0, onClick: () => setAdding(true), onKeyDown: (event) => { if (event.key === 'Enter') setAdding(true) } },
          el('span', { style: { fontSize: 18, lineHeight: 1 } }, '+'),
          el('span', null, t('cliAdd')))
      }
      return el('div', { className: 'dshrouter-card' },
        el('div', { className: 'dshrouter-head' },
          el('span', { className: 'dshrouter-name' }, t('cliAdd')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => setAdding(false) }, t('cancel'))),
        el('p', { className: 'dshrouter-hint' }, t('cliQuickAddHint')),
        el('div', { className: 'dshrouter-row' },
          ...CLI_PICKER.map((pick) => el('button', {
            type: 'button', key: pick.id || 'custom', className: 'dshrouter-chip',
            onClick: () => onQuickAdd(pick.id),
          }, pick.id ? t(pick.key) : t('cliCustomAdd')))))
    }

    function AgentCard(props) {
      const { id, draft, t, writable, busy, notice, providers, models, catalog, oauthAccounts, pools, cliEntries, testResult, stat, buckets, expanded, cliState, onToggle, onField, onSave, onDelete, onTest, onDiscover, onCliLogin } = props
      const groups = models ?? []
      const group = groups.find((entry) => entry.id === (draft.provider || ''))
      const poolRef = typeof draft.account === 'string' && draft.account.startsWith('pool:') ? draft.account.slice(5) : ''
      const poolEntry = poolRef ? (pools ?? []).find((entry) => entry.id === poolRef) : undefined
      const poolFirstAccount = poolEntry && (poolEntry.accounts ?? []).length > 0
        ? (oauthAccounts ?? []).find((entry) => entry.id === poolEntry.accounts[0])
        : undefined
      const oauthEntry = poolRef ? poolFirstAccount : (oauthAccounts ?? []).find((entry) => entry.id === (draft.account || ''))
      // EVO-011（RES-004）：codex-responses（ChatGPT 订阅）账号 + image 类型
      // = 订阅生图直连（服务端 runCodexResponsesImage）——提示文本与
      // endpoint/API Key 字段可见性按此区分（非 codex 协议 + image 仍拒绝）。
      const oauthImageDirect = draft.type === 'image' && !poolRef && oauthEntry?.protocol === 'codex-responses'
      const modelOptions = oauthEntry
        ? (oauthEntry.models ?? []).map((modelId) => ({ id: modelId, name: modelId }))
        : group ? group.models ?? [] : []
      const modelIds = new Set(modelOptions.map((model) => model.id))
      if (draft.model && !modelIds.has(draft.model)) modelOptions.push({ id: draft.model, name: draft.model })
      const providerChoice = providers.find((entry) => entry.provider === draft.provider)
      const effective = catalog ? `${catalog.effectiveProvider}/${catalog.effectiveModel}` : '—'
      const effectiveDisplay = draft.type === 'cli'
        ? `${draft.command || 'cli'}${draft.model ? `/${draft.model}` : ''}`
        : effective
      const sourceLabel = catalog ? ({ agent: t('sourceAgent'), main: t('sourceMain'), 'provider-default': t('sourceProvider'), account: t('fieldAccount'), pool: t('poolAccountSource') }[catalog.source] ?? t('sourceUnknown')) : ''
      const barBuckets = (buckets ?? []).slice(-48)
      const barMax = Math.max(1, ...barBuckets.map((bucket) => bucket.inputTokens + bucket.outputTokens))
      const typeLabel = ({ chat: t('typeChat'), agent: t('typeAgent'), image: t('typeImage'), speech: t('typeSpeech'), cli: t('typeCli') }[draft.type] ?? t('typeChat'))

      // 折叠摘要：类型 tag + 生效模型 + 简要用量
      const summary = el('div', { className: 'dshrouter-card' },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: expanded ? t('collapse') : t('expand') },
          el('span', { className: 'dshrouter-name' }, draft.name || id),
          el('span', { className: 'dshrouter-id' }, id),
          el('span', { className: 'dshrouter-tag' }, draft.type || 'chat'),
          catalog && catalog.error ? el('span', { className: 'dshrouter-error', title: catalog.error }, '⚠') : null,
          el('span', { className: 'dshrouter-meta' }, `${effectiveDisplay}`),
          el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')} ${stat ? stat.calls : 0} · ${t('statsErrors')} ${stat ? stat.errors : 0} · ${stat ? fmtTokens(stat.inputTokens) : 0}/${stat ? fmtTokens(stat.outputTokens) : 0}`),
          el('span', { className: 'dshrouter-spacer' }),
          el('span', { className: 'dshrouter-chevron' }, expanded ? '▾' : '▸')))

      if (!expanded) return summary

      return el('div', { className: 'dshrouter-card' + (draft.enabled === false ? ' disabled' : '') },
        el('button', { type: 'button', className: 'dshrouter-card-head', onClick: onToggle, 'aria-expanded': expanded, title: t('collapse') },
          el('span', { className: 'dshrouter-name' }, draft.name || id),
          el('span', { className: 'dshrouter-id' }, id),
          el('span', { className: 'dshrouter-tag' }, typeLabel),
          catalog && catalog.error ? el('span', { className: 'dshrouter-error', title: catalog.error }, catalog.error.slice(0, 60)) : null,
          el('span', { className: 'dshrouter-spacer' }),
          el('label', { className: 'dshrouter-switch', onClick: (event) => event.stopPropagation() },
            el('input', { type: 'checkbox', checked: draft.enabled !== false, disabled: !writable, onChange: (event) => onField('enabled', event.target.checked) }),
            t('enable')),
          el('span', { className: 'dshrouter-chevron' }, '▾')),
        el('div', { className: 'dshrouter-row' },
          el('div', { className: 'dshrouter-field' },
            el('span', { className: 'dshrouter-field-label' }, t('fieldName')),
            el('input', { className: 'dshrouter-input', value: draft.name ?? '', onChange: (event) => onField('name', event.target.value) })),
          el('div', { className: 'dshrouter-field', style: { flex: '0 0 240px' } },
            el('span', { className: 'dshrouter-field-label' }, t('fieldType')),
            el('select', { className: 'dshrouter-select', value: draft.type ?? 'chat', onChange: (event) => onField('type', event.target.value) },
              el('option', { value: 'chat' }, t('typeChat')),
              el('option', { value: 'agent' }, t('typeAgent')),
              el('option', { value: 'image' }, t('typeImage')),
              el('option', { value: 'speech' }, t('typeSpeech')),
              el('option', { value: 'cli' }, t('typeCli'))))),
        el('p', { className: 'dshrouter-hint' }, t('fieldTypeHint')),
        el('div', { className: 'dshrouter-field' },
          el('span', { className: 'dshrouter-field-label' }, t('fieldDescription')),
          el('textarea', { className: 'dshrouter-textarea', value: draft.description ?? '', onChange: (event) => onField('description', event.target.value) })),
        (draft.type !== 'cli' && ((oauthAccounts ?? []).length > 0 || (pools ?? []).length > 0)) ? el('div', { className: 'dshrouter-field' },
          el('span', { className: 'dshrouter-field-label' }, t('fieldAccount')),
          el('select', { className: 'dshrouter-select', value: draft.account ?? '', onChange: (event) => onField('account', event.target.value) },
            el('option', { value: '' }, `— ${t('inherit')} —`),
            ...(pools ?? []).map((entry) => el('option', { value: `pool:${entry.id}`, key: `pool:${entry.id}` }, `${t('poolTitle')} · ${entry.name || entry.id} (${entry.id})`)),
            ...(oauthAccounts ?? []).map((entry) => el('option', { value: entry.id, key: entry.id }, `${entry.name || entry.id} (${entry.id})`))),
          draft.account ? el('p', { className: 'dshrouter-hint' }, oauthImageDirect ? t('oauthImageHint') : t('oauthChatOnly')) : null) : null,
        oauthImageDirect ? el('p', { className: 'dshrouter-hint' }, t('oauthImageModelHint')) : null,
        draft.type === 'cli' ? el('div', { className: 'dshrouter-stats' },
          el('div', { className: 'dshrouter-row', style: { alignItems: 'flex-end' } },
            el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('fieldCliAgent')),
              el('select', { className: 'dshrouter-select', value: draft.cliAgent ?? '', onChange: (event) => onField('cliAgent', event.target.value) },
                el('option', { value: '' }, t('cliAgentNone')),
                ...cliEntries.map((entry) => el('option', { value: entry.id, key: entry.id }, `${entry.name || entry.id} (${entry.id})`)))),
            el('div', { className: 'dshrouter-field', style: { flex: '0 0 170px' } },
              el('span', { className: 'dshrouter-field-label' }, t('cliLoginStatus')),
              cliStatusChipOf(cliState, t))),
          draft.cliAgent ? null : el('p', { className: 'dshrouter-hint' }, t('cliLegacyHint')),
          el('div', { className: 'dshrouter-field', style: { maxWidth: 420 } },
            el('span', { className: 'dshrouter-field-label' }, t('fieldModel')),
            el('input', { className: 'dshrouter-input', list: `dshrouter-cli-models-${id}`, value: draft.model ?? '', placeholder: `— ${t('inherit')} —`, onChange: (event) => onField('model', event.target.value) }),
            el('datalist', { id: `dshrouter-cli-models-${id}` },
              ...(Array.isArray(cliState?.models) ? cliState.models : []).map((model) => el('option', { value: model, key: model }, model)))),
          el('p', { className: 'dshrouter-hint' }, t('cliManageHint')),
          el('p', { className: 'dshrouter-hint' }, t('cliRoutingHint'))) : el('div', { className: 'dshrouter-row' },
          el('div', { className: 'dshrouter-field' },
            el('span', { className: 'dshrouter-field-label' }, t('fieldProvider')),
            el('select', { className: 'dshrouter-select', value: draft.provider ?? '', disabled: !!draft.account, onChange: (event) => onField('provider', event.target.value) },
              el('option', { value: '' }, `— ${t('inherit')} —`),
              ...providers.filter((entry) => entry.active || entry.provider === draft.provider).map((entry) => el('option', { value: entry.provider, key: entry.provider }, `${entry.displayName} (${entry.provider})`)))),
          el('div', { className: 'dshrouter-field' },
            el('span', { className: 'dshrouter-field-label' }, t('fieldModel')),
            el('input', {
              className: 'dshrouter-input', list: `dshrouter-models-${id}`,
              value: draft.model ?? '', placeholder: '—',
              onChange: (event) => onField('model', event.target.value),
            }),
            el('datalist', { id: `dshrouter-models-${id}` },
              ...modelOptions.map((model) => el('option', { value: model.id, key: model.id }, model.name || model.id)))),
          el('button', {
            type: 'button', className: 'dshrouter-button ghost',
            style: { flex: 'none' },
            disabled: !draft.provider || !!draft.account,
            title: draft.account ? (oauthImageDirect ? t('oauthImageHint') : t('oauthChatOnly')) : draft.provider ? undefined : t('fieldProvider'),
            onClick: () => onDiscover(draft.provider),
          }, t('fieldDiscover'))),
        draft.type === 'image' || draft.type === 'speech' ? el('div', { className: 'dshrouter-row' },
          (draft.type === 'speech' || !oauthImageDirect) ? el('div', { className: 'dshrouter-field' },
            el('span', { className: 'dshrouter-field-label' }, t('fieldEndpoint')),
            el('input', { className: 'dshrouter-input', value: draft.endpoint ?? '', placeholder: 'https://api.openai.com/v1/images/generations', onChange: (event) => onField('endpoint', event.target.value) })) : null,
          draft.type === 'image' ? el('div', { className: 'dshrouter-field', style: { flex: '0 0 180px' } },
            el('span', { className: 'dshrouter-field-label' }, t('fieldImageSize')),
            el('select', { className: 'dshrouter-select', value: draft.imageSize ?? '1024x1024', onChange: (event) => onField('imageSize', event.target.value) },
              el('option', { value: '1024x1024' }, '1024x1024'),
              el('option', { value: '1792x1024' }, '1792x1024'),
              el('option', { value: '1024x1792' }, '1024x1792'))) : null,
          (draft.type === 'speech' || !oauthImageDirect) ? el('div', { className: 'dshrouter-field' },
            el('span', { className: 'dshrouter-field-label' }, t('fieldApiKeyEnv')),
            el('input', { className: 'dshrouter-input', value: draft.apiKeyEnv ?? '', placeholder: 'OPENAI_API_KEY', onChange: (event) => onField('apiKeyEnv', event.target.value) })) : null) : null,
        draft.type === 'agent' ? el('div', { className: 'dshrouter-field' },
          el('span', { className: 'dshrouter-field-label' }, t('fieldTools')),
          el('input', { className: 'dshrouter-input', value: (draft.tools ?? []).join(', '), onChange: (event) => onField('tools', event.target.value.split(',').map((item) => item.trim()).filter(Boolean)) })) : null,
        el('details', null,
          el('summary', { className: 'dshrouter-meta' }, t('advanced')),
          el('div', { className: 'dshrouter-row', style: { marginTop: 8 } },
            draft.type !== 'cli' ? el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('fieldReasoning')),
              el('input', { className: 'dshrouter-input', value: draft.reasoningEffort ?? '', placeholder: 'high', onChange: (event) => onField('reasoningEffort', event.target.value) })) : null,
            draft.type !== 'cli' ? el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('fieldTemperature')),
              el('input', { className: 'dshrouter-input', type: 'number', min: 0, max: 2, step: 0.1, value: draft.temperature ?? 0, onChange: (event) => onField('temperature', Number(event.target.value) || 0) })) : null,
            draft.type !== 'cli' ? el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('fieldMaxTokens')),
              el('input', { className: 'dshrouter-input', type: 'number', min: 0, step: 1, value: draft.maxTokens ?? 0, onChange: (event) => onField('maxTokens', Number(event.target.value) || 0) })) : null,
            draft.type !== 'image' && draft.type !== 'cli' ? el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('fieldMaxRounds')),
              el('input', { className: 'dshrouter-input', type: 'number', min: 1, max: 8, step: 1, value: draft.maxRounds ?? 1, onChange: (event) => onField('maxRounds', Math.max(1, Math.min(8, Number(event.target.value) || 1))) })) : null,
            el('div', { className: 'dshrouter-field' },
              el('span', { className: 'dshrouter-field-label' }, t('fieldCapabilities')),
              el('input', { className: 'dshrouter-input', value: (draft.capabilities ?? []).join(', '), onChange: (event) => onField('capabilities', event.target.value.split(',').map((item) => item.trim()).filter(Boolean)) }))),
          el('div', { className: 'dshrouter-field', style: { marginTop: 8 } },
            el('span', { className: 'dshrouter-field-label' }, t('fieldSystemPrompt')),
            el('textarea', { className: 'dshrouter-textarea', value: draft.systemPrompt ?? '', onChange: (event) => onField('systemPrompt', event.target.value) })),
          draft.type === 'cli' ? el('p', { className: 'dshrouter-hint' }, t('cliSystemHint')) : null),
        draft.type === 'cli' ? null : el('p', { className: 'dshrouter-meta' },
          t('effective'), el('strong', null, effective),
          catalog && catalog.source ? ` · ${sourceLabel}` : null,
          providerChoice && !providerChoice.active ? ` · (${t('accountDormant')})` : null),
        // 该 agent 的实时用量
        el('div', { className: 'dshrouter-stats' },
          el('div', { className: 'dshrouter-row' },
            el('span', { className: 'dshrouter-meta' }, `${t('statsCalls')}: ${stat ? stat.calls : 0}`),
            el('span', { className: 'dshrouter-meta', style: stat && stat.errors > 0 ? { color: 'var(--dsw-alias-state-error-primary)' } : undefined }, `${t('statsErrors')}: ${stat ? stat.errors : 0}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsTokens')}: ${stat ? fmtTokens(stat.inputTokens) : 0} / ${stat ? fmtTokens(stat.outputTokens) : 0}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsAvg')}: ${stat && stat.calls > 0 ? fmtMs(stat.totalMs / stat.calls) : '—'}`),
            el('span', { className: 'dshrouter-meta' }, `${t('statsLast')}: ${timeOf(stat && stat.lastAt)}`)),
          barBuckets.length > 0 ? el('div', { className: 'dshrouter-bars', title: t('statsSeries') },
            ...barBuckets.map((bucket) => el('div', {
              key: bucket.minute,
              className: 'dshrouter-bar' + (bucket.errors > 0 && bucket.calls === bucket.errors ? ' err' : ''),
              style: { height: `${Math.max(2, Math.round(((bucket.inputTokens + bucket.outputTokens) / barMax) * 26))}px` },
              title: `${bucket.minute} · in ${bucket.inputTokens} / out ${bucket.outputTokens} · ${bucket.errors} err`,
            }))) : null),
        testResult ? el('p', { className: testResult.ok ? 'dshrouter-ok' : 'dshrouter-error' },
          testResult.busy ? t('testing') : testResult.message) : null,
        notice ? el('p', { className: 'dshrouter-hint' }, notice) : null,
        el('div', { className: 'dshrouter-row' },
          el('button', { type: 'button', className: 'dshrouter-button', disabled: busy || !writable, onClick: onSave }, busy ? t('saving') : t('save')),
          // cli 类型：测试按键替换为登录（CLI 无连通性测试，登录即就绪）。
          draft.type === 'cli'
            ? el('button', {
              type: 'button', className: 'dshrouter-button ghost',
              disabled: busy || !writable || (cliState && cliState.loginBusy),
              onClick: onCliLogin,
            }, cliState && cliState.loginBusy ? t('cliLoginWaiting') : (cliState && cliState.loggedIn === true ? t('cliRelogin') : t('cliLogin')))
            : el('button', { type: 'button', className: 'dshrouter-button ghost', disabled: testResult && testResult.busy, onClick: onTest }, testResult && testResult.busy ? t('testing') : t('test')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button danger', disabled: busy || !writable, onClick: onDelete }, t('delete'))),
      )
    }

    /** 列表末尾的「+」添加卡片。 */
    function AddAgentCard(props) {
      const { t, adding, setAdding, newId, setNewId, idTaken, idInvalid, writable, onSave, onTemplate } = props
      if (!adding) {
        return el('div', { className: 'dshrouter-add', role: 'button', tabIndex: 0, onClick: () => setAdding(true), onKeyDown: (event) => { if (event.key === 'Enter') setAdding(true) } },
          el('span', { style: { fontSize: 18, lineHeight: 1 } }, '+'),
          el('span', null, t('addTitle')))
      }
      return el('div', { className: 'dshrouter-card' },
        el('div', { className: 'dshrouter-head' },
          el('span', { className: 'dshrouter-name' }, t('addTitle')),
          el('span', { className: 'dshrouter-spacer' }),
          el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => { setAdding(false); setNewId('') } }, t('cancel'))),
        el('div', { className: 'dshrouter-row' },
          el('input', {
            className: 'dshrouter-input', style: { flex: '0 0 240px' },
            placeholder: t('addPlaceholder'), 'aria-label': t('addPlaceholder'),
            value: newId, onChange: (event) => setNewId(event.target.value),
          }),
          el('button', {
            type: 'button', className: 'dshrouter-button',
            disabled: !newId.trim() || idInvalid || idTaken || !writable,
            onClick: onSave,
          }, t('add'))),
        newId.trim() && idInvalid ? el('p', { className: 'dshrouter-error' }, t('invalidId')) : null,
        newId.trim() && idTaken ? el('p', { className: 'dshrouter-error' }, t('duplicateId')) : null,
        el('div', { className: 'dshrouter-row' },
          el('span', { className: 'dshrouter-meta' }, t('presets')),
          ...AGENT_PRESETS.map((preset) => el('button', {
            type: 'button', key: preset.id, className: 'dshrouter-chip',
            onClick: () => onTemplate(preset),
          }, t(preset.key)))),
      )
    }

    function DiscoverModal(props) {
      const { api, t, provider, providers, baseURL, onClose, onAdopt } = props
      const [busy, setBusy] = useState(true)
      const [failure, setFailure] = useState(null)
      const [candidates, setCandidates] = useState([])
      const entry = providers.find((item) => item.provider === provider)
      useEffect(() => {
        let alive = true
        setBusy(true)
        setFailure(null)
        // 自定义服务商无内置模型目录：发现请求必须携带其 Base URL，
        // 否则 pi-ai 适配器报 "ships no catalog … set a baseURL"。
        api.llm.discoverModels({
          settingsNs: entry ? entry.settingsNs : 'llm-pi-ai',
          provider,
          ...(typeof baseURL === 'string' && baseURL.trim() ? { baseURL: baseURL.trim() } : {}),
        }).then((response) => {
          if (!alive) return
          if (!response.result.ok) { setFailure(response.result.error.message); return }
          setCandidates(response.result.value.models ?? [])
        }, (error) => { if (alive) setFailure(messageOf(error)) })
          .finally(() => { if (alive) setBusy(false) })
        return () => { alive = false }
      }, [api, provider, entry])
      return el('div', { className: 'dshrouter-modal', onClick: (event) => { if (event.target === event.currentTarget) onClose() } },
        el('div', { className: 'dshrouter-modal-body' },
          el('h4', { className: 'dshrouter-modal-title' }, `${t('fetchTitle')} · ${provider}`),
          busy ? el('p', { className: 'dshrouter-intro' }, t('fetching')) : null,
          failure ? el('p', { className: 'dshrouter-error' }, failure) : null,
          !busy && !failure && candidates.length === 0 ? el('p', { className: 'dshrouter-intro' }, t('fetchEmpty')) : null,
          candidates.map((model) => el('div', {
            className: 'dshrouter-candidate', key: model.id,
            onClick: () => onAdopt(model.id),
          },
            el('span', null, model.id),
            el('span', { className: 'dshrouter-meta' }, model.name || ''),
            el('span', { className: 'dshrouter-spacer' }),
            el('span', { className: 'dshrouter-meta' }, model.contextWindow ? `${fmtTokens(model.contextWindow)} ctx` : ''))),
          el('div', { className: 'dshrouter-row' },
            el('span', { className: 'dshrouter-spacer' }),
            el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: onClose }, t('close')))))
    }

    // ── 多模态展示辅助（composer 附件按钮 / route_agent 工具卡片）────────
    //
    // 发送与准入由宿主准入包装（twin 路由）接管：选「+ 自动识图」组后
    // 粘贴/拖拽 + 回车即原生可用，图片块留在日志、Web UI 原生显示。本区
    // 保留三件展示辅助：
    // - composer 附件按钮：图片文件送进原生草稿栏（预览/移除原生机制）；
    //   音频/视频/文档经 router/uploadFile 落盘（F11，v3 §4.4.2）→ 附件
    //   卡片 + 结构化路径文本经 inputActions.setDraft 进 draft；
    // - 模型接管（无 UI）：多模态开启 → 会话自动切包装路由；
    // - route_agent 工具卡片：生成图片以纯文本标记渲染进工具结果，卡片
    //   解析标记经 router/imageData 取字节渲染缩略图。

    /** 模块级路由目录缓存：composer 组件共用（apply 内轮询刷新）。 */
    const routerCatalog = {
      value: null,
      version: 0,
      listeners: new Set(),
    }
    function setRouterCatalog(value) {
      if (routerCatalog.value === value) return
      routerCatalog.value = value
      routerCatalog.version += 1
      for (const listener of routerCatalog.listeners) listener()
    }
    /** 组件内订阅目录版本（兼容迷你 React 的 useState/useEffect）。 */
    function useRouterCatalog() {
      const [version, setVersion] = useState(routerCatalog.version)
      useEffect(() => {
        const listener = () => setVersion(routerCatalog.version)
        routerCatalog.listeners.add(listener)
        return () => { routerCatalog.listeners.delete(listener) }
      }, [])
      return routerCatalog.value
    }
    /** 目录中的多模态 agent 并集（识别 + 生图），按 id 排序：image 类型
     *  （生图端点）或 capabilities 含 image 的任意类型（chat/agent 识别、
     *  cli 生图子代理）都计入——附件按钮显隐与模型接管只看"是否有任一
     *  多模态 agent"，与宿主 MODALITY_ENTRIES 的 stateOf 门控一致。改写标记
     *  里的"识别 vs 图生图"分流由宿主 listImageVisionAgents /
     *  listImageGenerationAgents 负责，这里不分。 */
    function multimodalAgentsOf(catalog) {
      if (!catalog || catalog.ok !== true) return []
      return (catalog.agents ?? [])
        .filter((agent) => {
          if (agent.enabled === false) return false
          const capabilities = Array.isArray(agent.capabilities) ? agent.capabilities : []
          return agent.type === 'image' || capabilities.includes('image')
        })
        .sort((a, b) => (a.id < b.id ? -1 : 1))
    }
    /** 从文本提取图片标记的引用（容忍损坏负载）。 */
    function parseMarkersOf(text) {
      const out = []
      if (typeof text !== 'string') return out
      const re = /\[router:image:([^\]\n]+)\]/g
      let match
      while ((match = re.exec(text)) !== null) {
        try {
          const ref = JSON.parse(match[1])
          if (ref && typeof ref === 'object' && typeof ref.attachmentId === 'string' && ref.attachmentId) out.push(ref)
        } catch { /* 非 JSON 负载：忽略 */ }
      }
      return out
    }

    /**
     * FIX-018：会话当前模型是否被「正向判定」为支持 image（贴图接管门控）。
     *
     * 判定来源（P5 单点——服务端判定，客户端消费）：router/catalog 的
     * mainModelImage（服务端 RouterService.mainModelImageCapability 复用
     * decideImagePrecheck——宿主声明优先 + wrapper sourceAcceptsModality 能力
     * 自证，60s TTL）。客户端零探测：宿主不向客户端暴露模态信息（2026-08-31
     * 取证：buildModelCatalog group.models 仅 {id,name,description,reasoning}，
     * session.models current 仅 {provider,model}，llm.providers 仅 provider 视图）。
     *
     * 门控语义（保守侧不破图）：
     * - 仅当 mainModelImage.acceptsImage === true 且其 provider+model 与会话
     *   当前选择一致时，才认定「当前模型已多模态」→ 贴图不切 twin（图直传
     *   主模型，FIX-005 约定——消除多余 twin 中转面）；
     * - 判定缺失（旧服务端/llm 不可用/无默认选择/探测失败）或漂移（能力快照
     *   与当前选择不一致——目录 30s 轮询窗口内的模型切换）→ 不认定 → 保守
     *   回落既有贴图接管（图经 twin 必可达，宁多切不漏图——FIX-012 语义不受损）。
     *   已知边界（与旧代码一致，非本修复引入）：图片在草稿途中手动把会话切到
     *   另一个模型不触发重评（组件无选择变化订阅面），发送时由宿主准入拦截。
     * - FIX-049 漂移窗口消除：漂移/缺失不再是即刻保守切换——armed 且未 wrapped
     *   时先按需刷新新鲜能力再判（refreshMainModelImage——catalog RPC 实时重算
     *   + 防抖 + 失败/超时回落），命中即按本函数语义 suppress 直传；上面的
     *   保守回落仅剩刷新失败/超时/旧服务端/真不匹配形态。判定语义零改动。
     */
    function currentModelAcceptsImage(catalog, current) {
      const capability = catalog && catalog.mainModelImage
      if (!capability || capability.acceptsImage !== true) return false
      if (!capability.provider || !capability.model) return false
      return !!current && current.provider === capability.provider && current.model === capability.model
    }
    /** 能力快照签名（effect deps）：目录轮询（30s/settings 事件）带来判定变化
     *  时重评接管——否则「判定缺失窗口内误切/抑制」后不会随目录刷新纠偏。 */
    function mainModelImageSignature(catalog) {
      const capability = catalog && catalog.mainModelImage
      if (!capability) return ''
      return `${capability.acceptsImage === true ? '1' : '0'}|${capability.provider || ''}|${capability.model || ''}`
    }

    // ── FIX-049：能力快照按需刷新（漂移窗口消除）────────────────────────
    // mainModelImage 按默认选择计算、随 ~30s 轮询刷新——会话内切模型后立即
    // 贴图必落「快照 vs 当前」不匹配窗口（用户报障 2026-09-18：原生多模态
    // 模型贴图被误切 twin，FIX-012 永不还原使其停留永久化）。armed 时点先
    // 刷新新鲜能力再判定，FIX-018「正向判定命中即直传不切」的意图在时序上
    // 成立。
    /** 防抖记忆（sessionId → `${capabilitySig}|${provider}/${model}`）：同会话
     *  同快照同当前选择不重复刷（目录 30s 轮询兜底保留），失败不重试风暴。
     *  生命周期同 takeoverMemory（模块级，随浏览器包存活）。 */
    const capabilityRefreshKeys = new Map()
    /** 按需刷新竞速上限：catalog RPC 为本机 daemon 调用（常态 <100ms），2s
     *  上限覆盖慢机；超时按「刷新失败」保守回落既有接管（宁多切不漏图）。 */
    const CAPABILITY_REFRESH_TIMEOUT_MS = 2000

    /**
     * FIX-049：按需拉取新鲜能力快照。直调 router/catalog RPC（与装配层
     * refreshCatalog 同一消费面——P5 不新造第二刷新路径），新鲜值写回共享
     * 目录缓存（setRouterCatalog → useRouterCatalog 订阅全量跟随 →
     * capabilitySig 进 effect deps 重评）并原值返回供调用方即时判定。
     *
     * 服务端新鲜性（2026-09-19 只读实读 lib/service.js / lib/wrapper.js）：
     * mainModelImageCapability 每次 catalog RPC 实时重算——host-declared 路径
     * （宿主 resolveModelInfo 声明含 image）无缓存即时返回；self-certified
     * 路径的 60s TTL 按 `provider\0model\0modality` 分键（wrapper.js
     * sourceAcceptsModality），新选中模型必走新鲜探测——故按需 RPC 拿到的
     * 即是会话内新选择的当前判定。
     *
     * 失败语义（保守侧不破图）：router 面不可达 / RPC 拒绝 / 超时 / 防抖命中
     * → resolve null——调用方保守回落既有切换（宁多切不漏图，FIX-018/FIX-012
     * 语义零改动）；response.ok=false 同样按失败回落。
     * @param {unknown} router 槽位注入的 routerRemote（() => ctx.get('remote.router')，
     *   AttachButton 同款注入先例）
     * @param {string} sessionId 会话 id（防抖键之一）
     * @param {string} snapshotSig 触发时的能力快照签名（mainModelImageSignature）
     * @param {{provider: string, model: string}} current 会话当前选择（调用方已验证非空）
     * @returns {Promise<object|null>} 新鲜 catalog（response.value）或 null
     */
    function refreshMainModelImage(router, sessionId, snapshotSig, current) {
      const remote = typeof router === 'function' ? router() : router
      if (!remote || typeof remote.catalog !== 'function') return Promise.resolve(null)
      const key = `${snapshotSig}|${current.provider}/${current.model}`
      if (capabilityRefreshKeys.get(sessionId) === key) return Promise.resolve(null)
      capabilityRefreshKeys.set(sessionId, key)
      let timer = null
      const timedOut = new Promise((resolve) => { timer = setTimeout(() => resolve(null), CAPABILITY_REFRESH_TIMEOUT_MS) })
      return Promise.race([
        Promise.resolve(remote.catalog({})).then((response) => {
          const value = response && response.ok ? (response.value ?? null) : null
          if (value) setRouterCatalog(value)
          return value
        }, () => null),
        timedOut,
      ]).finally(() => { if (timer !== null) clearTimeout(timer) })
    }

    /** 包装路由后缀（与宿主 lib/wrapper.js 的 WRAP_SUFFIX 一致；双面各自定义）。 */
    const WRAP_SUFFIX = '-router'

    /** 接管来源记忆（FIX-002-R7 F1）：sessionId → 本组件接管时切走的原生
     *  provider——服务端 wrapper `tookOverFrom` 的客户端对等机制（"这个 twin
     *  选择是谁放上的"）。仅当会话当前停在本组件接管放上的 twin 上时，解除
     *  武装才还原；用户手动选的 twin（无记忆）一律尊重不撤销。接管/还原成功
     *  才写入/清除记忆（失败保持原状，下次 effect 触发重试）。 */
    const takeoverMemory = new Map()

    /**
     * FIX-048：输入快照待发图片计数（双形态兼容——宿主 M2 附件统一编址跟随）。
     *
     * 权威宿主契约（2026-09-18 只读实读，宿主实跑 npx checkout 0.1.5-rc.1，包
     * @deepseek-ai/dsh-client-ui-conversation）：
     *  - `lib/types/client/contract/input.d.ts` 的 `export interface InputState`
     *    字段清单：draft / attachmentIds / draftRev / phase / claim /
     *    occurrences / queue——附件以不透明 `attachmentIds: readonly
     *    DraftAttachmentId[]` 承载（M2 image/file 统一编址），**无 imageIds
     *    字段**（全宿主树 grep 零命中）；宿主消费点 = 同包 lib/client.js 的
     *    InputBar：`resolveDraftAttachments(input.attachmentIds)`。
     *  - kind 解析面 = 该包 `lib/types/client/service.d.ts` 的
     *    `resolveDraftAttachments(ids): readonly ComposerAttachment[]`
     *    （ConversationController 以 `conversation` 名注册 plugin ctx——宿主
     *    lib/client.js `super(ctx, "conversation")`；`ComposerAttachment.kind:
     *    'image' | 'file'`，见 contract/slots.d.ts 的 ComposerImageAttachment /
     *    ComposerFileAttachment）。
     *
     * 计数策略（兼容序：新形态 kind 解析 → 新形态保守回落 → 旧形态 imageIds）：
     *  1. attachmentIds（现行 InputState 形态）+ kind 解析面可达 → 仅统计
     *     kind === 'image'（方案 A：「贴图即切」精确语义，file-only 不武装）；
     *  2. attachmentIds + 解析面不可达/抛错（face 缺失等）→ 保守回落
     *     count = attachmentIds.length（方案 B：宁多切不漏图——file-only 轮也
     *     切 twin，wrapper 对无图轮零改写委托原生模型，代价 = 会话模型标签
     *     变化；与 FIX-012 门控语义同向的保守侧）。降级可观测（P8）：调用方
     *     （ModelTakeover）对 source === 'attachment-ids' 的活跃回落一次性 warn。
     *  3. imageIds（旧宿主 0.1.2-rc.x 前契约回落，旧夹具同源）→ 长度即图片数
     *     （FIX-012 语义不变）。
     * @param {{attachmentIds?: unknown, imageIds?: unknown}} inputSnapshot 宿主 InputState 快照（双形态）
     * @param {((ids: unknown) => unknown) | null} resolveDraftAttachments kind 解析面（无则 null）
     * @returns {{count: number, source: 'attachment-kind'|'attachment-ids'|'imageIds'|'none'}}
     */
    function inputImageCountOf(inputSnapshot, resolveDraftAttachments) {
      if (!inputSnapshot || typeof inputSnapshot !== 'object') return { count: 0, source: 'none' }
      if (Array.isArray(inputSnapshot.attachmentIds)) {
        if (typeof resolveDraftAttachments === 'function') {
          try {
            const attachments = resolveDraftAttachments(inputSnapshot.attachmentIds)
            if (Array.isArray(attachments)) {
              return { count: attachments.filter((attachment) => !!attachment && attachment.kind === 'image').length, source: 'attachment-kind' }
            }
          } catch { /* 解析面异常 → 与 face 缺失同走保守回落（P8 由调用方 warn 承担） */ }
        }
        return { count: inputSnapshot.attachmentIds.length, source: 'attachment-ids' }
      }
      if (Array.isArray(inputSnapshot.imageIds)) return { count: inputSnapshot.imageIds.length, source: 'imageIds' }
      return { count: 0, source: 'none' }
    }

    /**
     * 模型接管（无 UI）：武装时当前会话切到包装路由；解除武装时仅还原
     * 本组件接管放上的会话选择（takeoverMemory 命中且仍停在我们的 twin 上），
     * 用户手动选的 twin 一律尊重不撤销（FIX-002-R7 F1）。武装来源（FIX-012）
     * 决定还原语义：
     *  - takeoverDefaultModel 开关（FIX-002）：开启即接管（含纯文本轮），
     *    关闭还原——既有语义不回退；
     *  - 图片条件化（FIX-012，用户裁决 2026-08-30「贴图即切、发送后保持」）：
     *    开关默认 false 时输入框存在待发送图片（imageCount>0）也接管，
     *    否则带图消息被宿主 prompt 准入拦截（MODEL_DOES_NOT_SUPPORT_IMAGES）。
     *    image 来源的接管**永不自动还原**（保持 twin 直到用户手动切换，或
     *    开启 takeoverDefaultModel 后经 armed 分支升级 armedBy=switch 再走
     *    既有还原）。原因（宿主核实 2026-08-30，dsh-api-session-controller
     *    的 session.selectModel 面）：session.selectModel 仅 resolveCallConfig +
     *    写 selectionFor.current，对会话历史/草稿图片零校验——旧注释「会话已
     *    含图时宿主拒绝切回纯文本」不成立（图片准入只在 prompt 时点
     *    dsh-api-session-controller 的 prompt 侧准入与 pi-ai stream 时点
     *    dsh-llm-pi-ai 的 streamWithSnapshot()）。
     *    发送后 imageCount 归零与移除未发送图片不可区分（组件无会话日志查询
     *    面）；若还原会成功切回纯文本，下一张图 prompt 被拦（用户报障形态
     *    复现）——故 image 来源一律不自动还原。InputZone 快照随 input/session
     *    store 变化重渲染，草稿附件实时（现行 InputState.attachmentIds，kind 经
     *    conversation.resolveDraftAttachments 解析——FIX-048）：视觉已开启而用户
     *    手动切回纯文本组后贴图，同样自动归位到包装组。
     */
    function ModelTakeover(props) {
      const { sessionId, input, useInput, api, conversation, router } = props
      const catalog = useRouterCatalog()
      // FIX-002（客户端层）：会话级接管受 router.takeoverDefaultModel 开关约束
      // （默认 false = 不接管——twin 路由在模型列表，用户手动选）。此前仅看
      // 开关即在每个会话（含子代理会话，sessionId 变化触发 effect）强制切
      // twin——覆盖用户手动选择（用户报障：起子代理时主代理配置被切）。开关
      // 开启时保留既有"开启瞬间切换 + 贴图自动归位"语义。
      // FIX-012：武装条件纳入 imageCount——文本主模型（默认开关 false）贴图
      // 时自动接管（用户裁决：贴图即切）；还原语义见组件头注释（armedBy
      // 来源标记：'switch' 走既有还原，'image' 永不自动还原）。
      // FIX-002-R7 F1：解除武装的还原同样需要来源记忆（takeoverMemory）——
      // 此前 !armed && wrapped 分支在每次 effect 触发（贴图/会话切换/子代理
      // sessionId）都把用户手动选的 twin 静默剥回原生。
      // FIX-029-B：宿主 0.1.2-rc.1 起 conversation.input.right standardProps
      // 只提供 useInput（SnapshotSelectorHook）/inputActions/sessionId，不再
      // 提供 input（快照 prop）——宿主注入面 dsh-client-ui-conversation 的
      // ctx.uiSession.provide({ hooks: ['conversation','input'], props:
      // ['inputActions'] })，PropsHooks input→useInput（FIX-043 批 C 实读：
      // 原行号式锚已漂移到他对象 ⇒ 改代码串式）。输入快照改经 hook 读取；typeof
      // 分支在组件生命周期内形态稳定（宿主面恒定），hook 调用序不漂移；
      // props.input 旧形态回落（旧宿主/旧夹具双形态兼容——AttachButton
      // useInput 同款先例）。
      const inputSnapshot = typeof useInput === 'function' ? useInput((state) => state) : input
      // FIX-048：宿主 0.1.5-rc.1 M2 附件统一编址——InputState 以 attachmentIds
      // 承载附件（input.d.ts 的 export interface InputState，无 imageIds 字段），
      // 旧 imageIds 只读形态在现行宿主恒 0 → 贴图接管静默失效（用户报障
      // 2026-09-18）。计数双形态兼容（inputImageCountOf）：attachmentIds 经 kind
      // 解析面仅计 image（方案 A——「贴图即切」指图片），面不可达保守回落
      // attachmentIds.length（方案 B——宁多切不漏图）；imageIds 旧形态长度即
      // 图片数（语义不变）。解析面 = conversation 服务的 resolveDraftAttachments
      // （service.d.ts 面；conversation 形如装配层注入的 conversationFace =
      // () => ctx.get('conversation')，AttachButton 同款先例；以方法调用保住
      // 服务 this）。capabilitySuppressed（下方 effect）消费同一 imageCount，
      // kind 形态下语义等价（有图 + 当前模型原生多模态 → 直传不切）。
      const conversationSvc = typeof conversation === 'function' ? conversation() : conversation
      const resolveDraftFace = conversationSvc && typeof conversationSvc.resolveDraftAttachments === 'function'
        ? (ids) => conversationSvc.resolveDraftAttachments(ids)
        : null
      const imageInfo = inputImageCountOf(inputSnapshot, resolveDraftFace)
      const imageCount = imageInfo.count
      // FIX-048 P8 可观测：方案 B 保守回落活跃（attachmentIds 非空而 kind 解析
      // 面缺失/异常）→ 一次性 warn——「宁多切不漏图」的降级形态禁静默。
      const fallbackWarnedRef = useRef(false)
      if (imageInfo.source === 'attachment-ids' && imageInfo.count > 0 && !fallbackWarnedRef.current) {
        fallbackWarnedRef.current = true
        console.warn('dsh-agent-router[FIX-048] input.attachmentIds kind 解析面不可达（conversation.resolveDraftAttachments 缺失/异常）——imageCount 保守回落为 attachmentIds.length（file-only 轮亦武装，宁多切不漏图）')
      }
      const takeoverArmed = multimodalAgentsOf(catalog).length > 0 && (catalog.takeoverDefaultModel === true || imageCount > 0)
      const imageConditional = !catalog || catalog.takeoverDefaultModel !== true
      // FIX-018：能力快照签名进 deps——门控抑制后目录刷新带来判定变化时重评
      // （F18-5：抑制 → 能力反转 → 补接管；缺该 deps 则抑制后永不重评）。
      const capabilitySig = mainModelImageSignature(catalog)
      useEffect(() => {
        const sessions = api && api.sessions
        // P8 可观测（FIX-029 复验取证）：接管链关键分叉结构化上行——F12 可直接
        // 区分「未武装（无图/无多模态 agent）/会话面缺失/models 读取失败/
        // current 缺失/能力门控抑制/切换失败/成功」。修复验收期开启；静默
        // 失败形态（FIX-029 真机首验：贴图不切且无任何提示）由此终结。
        const trace = (phase, detail) => {
          const line = `dsh-agent-router[FIX-029] takeover ${phase} (session ${sessionId}${detail ? `, ${detail}` : ''})`
          if (phase === 'switched' || phase === 'skip-armed-wrapped' || phase === 'capability-refresh') console.info(line)
          else if (phase !== 'skip-idle') console.warn(line)
        }
        if (!sessionId || !sessions || typeof sessions.models !== 'function' || typeof sessions.selectModel !== 'function') {
          trace('face-missing', 'api.sessions incomplete')
          return
        }
        let cancelled = false
        ;(async () => {
          try {
            const { result } = await sessions.models({ sessionId })
            if (cancelled) return
            if (!result || !result.ok || !result.value) {
              trace('models-failed', result && result.error && result.error.message ? String(result.error.message).slice(0, 120) : 'no result')
              return
            }
            if (!result.value.current) {
              trace('models-empty', 'current is null (directory loading?)')
              return
            }
            const current = result.value.current
            if (typeof current.provider !== 'string' || typeof current.model !== 'string' || current.model === '') {
              trace('models-invalid-current', JSON.stringify(current).slice(0, 120))
              return
            }
            const wrapped = current.provider.endsWith(WRAP_SUFFIX)
            if (!takeoverArmed) {
              if (!wrapped) trace('skip-idle', 'not armed')
              return
            }
            if (wrapped) {
              // armed 重跑（开关/图片条件变化）：已停在我们的 twin 上——
              // 开关开启时把 image 来源记忆升级为 switch 来源（用户开启
              // takeoverDefaultModel 后关闭 → 走既有还原，FIX-012 承诺；
              // P2-1 deps 含 imageConditional 的交错升级链）。
              const entry = takeoverMemory.get(sessionId)
              if (entry && !imageConditional && entry.armedBy !== 'switch') takeoverMemory.set(sessionId, { ...entry, armedBy: 'switch' })
              trace('skip-armed-wrapped', `already on ${current.provider}`)
              return
            }
            // FIX-018：image 来源接管先过「当前模型已多模态」门控——主模型
            // 原生支持图片时贴图直传主模型，不切 twin（FIX-005 约定；消除
            // 多余 twin 中转面）。仅 image 来源门控：开关驱动接管不经此判定
            // （imageConditional=false 时 armed 来自开关——用户显式要 twin
            // 路由面，FIX-002 语义）。判定缺失/与当前选择漂移 → 不认定 →
            // 保守回落既有接管（见 currentModelAcceptsImage 注释）。未切换
            // = 无记忆写入，解除武装还原逻辑零影响。
            const capabilitySuppressed = imageConditional && imageCount > 0 && currentModelAcceptsImage(catalog, current)
            if (capabilitySuppressed) {
              trace('skip-capability', `current ${current.provider}/${current.model} natively accepts image`)
              return
            }
            // FIX-049：漂移窗口——快照与当前选择不匹配/缺失时先按需拉取新鲜
            // 能力再判定（服务端 catalog RPC 实时重算，见 refreshMainModelImage）；
            // 新鲜判定命中 → suppress 直传主模型（FIX-018 正向判定意图在时序上
            // 成立，消除「切模型→立即贴图」误切 twin）。刷新不可达/失败/超时/
            // 防抖命中/仍不匹配 → 保守回落既有切换（宁多切不漏图不破坏，下方
            // 既有路径零改动）。防抖：同 sessionId+同快照签名+同当前选择不重复
            // 刷；新鲜值经 setRouterCatalog 写回共享缓存 → capabilitySig 变化
            // 驱动 effect 重评（下方 deps 闭环）。
            if (imageConditional && imageCount > 0) {
              const freshCatalog = await refreshMainModelImage(router, sessionId, capabilitySig, current)
              if (cancelled) return
              if (freshCatalog && currentModelAcceptsImage(freshCatalog, current)) {
                trace('skip-capability', `current ${current.provider}/${current.model} natively accepts image (on-demand refreshed)`)
                return
              }
              trace('capability-refresh', freshCatalog ? 'refreshed snapshot still mismatched — conservative switch' : 'refresh unavailable/failed/timed out/debounced — conservative switch')
            }
            // 接管：切到当前 provider 的包装路由。宿主包装组注册先于客户端
            // 感知（settings 事件本地先行、RPC 后至），开启瞬间完成切换；
            // 失败静默，下次快照变化再试。成功后记忆来源与武装类型
            // （FIX-002-R7 F1 + FIX-012 armedBy：'switch' 开关驱动 /
            // 'image' 图片条件化——只有本组件放上的 twin 才在解除武装时
            // 还原，且 image 来源永不自动还原）。
            const taken = await sessions.selectModel({ sessionId, provider: `${current.provider}${WRAP_SUFFIX}`, model: current.model })
            if (taken && taken.result && taken.result.ok) {
              takeoverMemory.set(sessionId, { native: current.provider, armedBy: imageConditional ? 'image' : 'switch' })
              trace('switched', `${current.provider} -> ${current.provider}${WRAP_SUFFIX}`)
            } else {
              const message = taken && taken.result && taken.result.error && taken.result.error.message ? String(taken.result.error.message).slice(0, 120) : 'unknown'
              trace('switch-failed', message)
            }
            return
          } catch (error) {
            // 接管失败容忍：准入是最终防线，用户仍可手动切组（P8：结构化
            // 上行后不再静默）。
            trace('error', error && error.message ? String(error.message).slice(0, 120) : String(error).slice(0, 120))
          }
        })()
        // 未武装但持有接管记忆的还原路径（FIX-002-R7 F1 + FIX-012）：独立于
        // 上面的 armed 主链——仅 !takeoverArmed 时评估（armed 期间的还原会
        // 与接管主链互踩：开启开关的 armed 重跑被还原撤销 = P2-1 交错链破坏）。
        if (!takeoverArmed && takeoverMemory.has(sessionId)) {
          ;(async () => {
            try {
              const entry = takeoverMemory.get(sessionId)
              if (entry.armedBy === 'image') {
                // FIX-012：image 条件化接管永不自动还原（宿主 selectModel 无
                // 「会话已含图拒绝切回」校验——见组件头注释；还原会成功切回
                // 纯文本，下一张图 prompt 被 MODEL_DOES_NOT_SUPPORT_IMAGES
                // 拦截）。保持 twin；用户手动改走（原生/别的 twin）则清记忆
                // 尊重，下次贴图重新接管——需读当前选择判断是否仍停在我们的
                // twin 上，读不到时保守保持。
                const { result } = await sessions.models({ sessionId })
                const current = result && result.ok && result.value ? result.value.current : null
                if (current && (typeof current.provider !== 'string' || !current.provider.endsWith(WRAP_SUFFIX) || current.provider !== `${entry.native}${WRAP_SUFFIX}`)) takeoverMemory.delete(sessionId)
              } else {
                // 恢复（FIX-002-R7 F1）：仅当 twin 选择是本组件接管逻辑放上的
                // （记忆命中且仍停在我们的 twin 上）才还原——用户手动选的 twin
                // （无记忆）一律尊重不撤销；用户已手动改走（原生/别的 twin）=
                // 尊重，静默清记忆不写设置。还原成功才清记忆（失败保留，下次
                // 触发重试）。
                const { result } = await sessions.models({ sessionId })
                const current = result && result.ok && result.value ? result.value.current : null
                const native = entry.native
                if (current && typeof current.provider === 'string' && current.provider === `${native}${WRAP_SUFFIX}`) {
                  const restored = await sessions.selectModel({ sessionId, provider: native, model: current.model })
                  if (restored && restored.result && restored.result.ok) {
                    takeoverMemory.delete(sessionId)
                    trace('restored', `${current.provider} -> ${native}`)
                  }
                } else if (current) {
                  takeoverMemory.delete(sessionId)
                }
              }
            } catch { /* 还原失败容忍：记忆保留，下次触发重试 */ }
          })()
        }
        return () => { cancelled = true }
        // R0 P2-1：deps 含 imageConditional——「图片在途时 takeoverDefaultModel
        // 开→关」不改 armed（imageCount 仍在）但改升级/保持判定，缺该变量时
        // effect 不重跑 → armedBy 滞留 'image' → 移除图片后不还原（组件头承诺
        // 的「开启后走既有还原」在交错下失效）。补入后交错升级链闭合。
        // FIX-018：deps 含 capabilitySig——能力快照变化（目录轮询纠偏/适配器
        // 注销反转判定）时重评门控（F18-5 看护）。
        // FIX-049：deps 含 router——按需刷新消费的注入面（宿主经槽位 inject
        // 同步提供，恒稳定；api 同款 deps 先例）。
      }, [sessionId, api, takeoverArmed, imageCount, imageConditional, capabilitySig, router])
      return null
    }

    /** 文件是否图片（ARCH-005 A4/HD-004：与宿主 isImageMediaType 四 MIME 精确
     *  集合对齐——dsh-client-ui-conversation 的 createDrafts 只认 png/jpeg/
     *  webp/gif 走 runtime 图片草稿；非四 MIME 的 image/*（如 svg）宿主会当
     *  file draft 触发上传（双通道错位），插件侧同口径分流即免疫。accept
     *  属性声明同一集合（下方 input accept），常规操作不可达错位分支）。 */
    const ATTACH_IMAGE_MEDIA_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif'])
    function isImageFile(file) {
      return !!file && ATTACH_IMAGE_MEDIA_TYPES.has(typeof file.type === 'string' ? file.type : '')
    }

    /** 附件类型中文标签（结构化路径文本与卡片共用，§4.4.2 ③：音频/视频/文档）。 */
    function attachKind(mediaType) {
      return typeof mediaType === 'string' && mediaType.startsWith('audio/') ? '音频'
        : typeof mediaType === 'string' && mediaType.startsWith('video/') ? '视频' : '文档'
    }

    /** 结构化路径文本（v3 §4.4.2 ③ / §5.5 输入段格式）：
     *  [附件: 音频 xxx.wav 路径 .router-files/xxx.wav]——路径文本常驻模型输入，
     *  主 agent 据此 route_agent(agent=speech, filePath=路径) / files=[路径]。 */
    function attachPathText(mediaType, name, path) {
      return `[附件: ${attachKind(mediaType)} ${name} 路径 ${path}]`
    }

    /** composer 工具行附件按钮：多模态开启时出现（与模型接管共用同一目录
     *  信号——开启出现并接管、关闭消失并恢复，严格同步）。选文件按类型分流：
     *  图片进原生草稿图片栏（预览/移除都走原生机制，发送走原生回车，由准入
     *  包装放行）；音频/视频/文档经 router/uploadFile RPC 落盘到工作区
     *  .router-files/（F11 输入入口，v3 §4.4.2 / §5.5——浏览器无法直写文件
     *  系统，F8/F12 约束下唯一合规通路）→ 附件卡片渲染 + 结构化路径文本经
     *  inputActions.setDraft 注入 draft（读最近渲染 draft 追加回写，V-DSH-2
     *  结论：setDraft 是单一公共 draft 写通道，完全支持路径文本进 draft；
     *  F-01：全部上传落定后累积一次回写，多选不丢路径文本）。 */
    function AttachButton(props) {
      const { t, router, conversation, inputActions, useInput, sessionId } = props
      const catalog = useRouterCatalog()
      const [error, setError] = useState('')
      const [cards, setCards] = useState([])
      const inputRef = useRef(null)
      // 当前 draft（渲染期快照，draftRef 每渲染刷新为最新值）：上传全部落定后
      // 以最近一次渲染的 draft 为基一次性回写路径文本（宿主会话 slot 恒提供
      // useInput，SessionStandardProps；缺失时仅跳过注入——上传与卡片不受影响）。
      // 快照口径：V-DSH-2 无 draft 读取事件通道，上传窗口内的用户输入以最近
      // 一次渲染为准（F-01 修复：多文件不再逐文件整体覆盖——累积全部路径文本
      // 后仅一次 setDraft，读-改-写全程一次完成，不丢写）。
      const currentDraft = typeof useInput === 'function'
        ? String(useInput((s) => (s && typeof s.draft === 'string' ? s.draft : '')) ?? '')
        : ''
      const draftRef = useRef(currentDraft)
      draftRef.current = currentDraft
      const agents = multimodalAgentsOf(catalog)
      if (agents.length === 0) return null
      /** 单个非图片文件上传：FileReader 读字节 → base64 → router/uploadFile RPC。
       *  成功返回该文件的结构化路径文本（由 intake 累积后一次 setDraft 注入），
       *  失败返回 null（错误已渲染，不注入 draft）。 */
      const uploadFile = (file) => {
        const FR = typeof window !== 'undefined' ? window.FileReader : undefined
        const remote = typeof router === 'function' ? router() : router
        if (typeof FR !== 'function' || !remote || typeof remote.uploadFile !== 'function') {
          setError(t('attachUnavailable'))
          return Promise.resolve(null)
        }
        const name = typeof file.name === 'string' && file.name.trim() ? file.name.trim() : `upload-${Date.now().toString(36)}`
        const mediaType = typeof file.type === 'string' && file.type ? file.type : 'application/octet-stream'
        return new Promise((resolve) => {
          const reader = new FR()
          reader.onload = () => {
            const dataBase64 = String(reader.result ?? '').split(',')[1] ?? ''
            remote.uploadFile({ name, mediaType, dataBase64 }).then((response) => {
              const value = response && response.ok && response.value ? response.value : null
              if (!value || value.ok !== true || !value.path) {
                const detail = value && typeof value.message === 'string'
                  ? `${value.code || 'UPLOAD_FAILED'}: ${value.message}`
                  : t('attachUploadFailed')
                setError(detail)
                resolve(null)
                return
              }
              const path = String(value.path)
              const cardName = typeof value.name === 'string' && value.name ? value.name : name
              setCards((current) => [...current, { name: cardName, mediaType, path }])
              resolve(attachPathText(mediaType, cardName, path))
            }, (failure) => {
              setError(failure && failure.message ? String(failure.message) : t('attachUploadFailed'))
              resolve(null)
            })
          }
          reader.onerror = () => { setError(t('attachUploadFailed')); resolve(null) }
          reader.readAsDataURL(file)
        })
      }
      const intake = (list) => {
        setError('')
        const files = Array.from(list ?? []).filter((file) => file && typeof file.name === 'string')
        const images = files.filter(isImageFile)
        const others = files.filter((file) => !isImageFile(file))
        if (images.length > 0) {
          // ARCH-005 A4（HD-004）：图片直传迁移至宿主 0.1.5 起的 addAttachments
          // 通道——旧 createDraftImages/addImages 面 0.1.5-rc.2 已消失（T-1 定性：
          // npm pack 0.1.5-rc.2 grep 双 0 命中）。新链 = 宿主原生先例逐形
          // （dsh-client-ui-conversation composer addFiles 注入——三步链先例
          // 0.1.5-rc.2 :16776 / 0.2.0 :18389 链形同形；InputActions 面
          // 0.1.5-rc.2 :12631 / 0.2.0 :13475 定义精确同形）：
          // conversation.createDrafts(sessionId,
          // files) 注册 runtime 图片草稿（零上传——object URL 预览，字节随
          // prompt 编码；上传源只用于非图片 file draft，本路径不涉）→
          // inputActions.addAttachments(ids)；拒绝（adjudicating/submitting
          // 提交锁）→ releaseDraftAttachments 回滚。守卫语义延续（FIX-048）：
          // 任一面/sessionId 缺失 → attachUnavailable 降级不崩。
          const conversationSvc = typeof conversation === 'function' ? conversation() : conversation
          if (!conversationSvc || typeof conversationSvc.createDrafts !== 'function'
            || typeof conversationSvc.releaseDraftAttachments !== 'function'
            || !inputActions || typeof inputActions.addAttachments !== 'function'
            || typeof sessionId !== 'string' || !sessionId) {
            setError(t('attachUnavailable'))
            return
          }
          try {
            const drafts = conversationSvc.createDrafts(sessionId, images)
            if (!inputActions.addAttachments(drafts.map((draft) => draft.id))) conversationSvc.releaseDraftAttachments(drafts)
          } catch (failure) {
            setError(messageOf(failure))
          }
        }
        // F-01：多文件非图片并发上传（multiple:true）——各文件独立 RPC，全部
        // 落定后把全部路径文本一次性 setDraft（以 draftRef 最新渲染值为基）；
        // 绝不逐文件整体覆盖（旧实现后完成者覆盖前 N-1 项，路径文本丢失，且
        // 上传窗口内用户输入被旧快照覆盖）。
        if (others.length === 0) return
        Promise.all(others.map(uploadFile)).then((texts) => {
          const lines = texts.filter((text) => text !== null)
          if (lines.length === 0) return
          if (inputActions && typeof inputActions.setDraft === 'function') {
            const base = draftRef.current.trim()
            inputActions.setDraft(base ? `${base}\n${lines.join('\n')}` : lines.join('\n'))
          }
        })
      }
      return el('span', { style: { display: 'inline-flex', alignItems: 'center', gap: 4 } },
        ...cards.map((card) => el('span', {
          className: 'dshrouter-attachcard',
          key: card.path,
          title: card.path,
        }, `[${attachKind(card.mediaType)}] ${card.name} → ${card.path}`)),
        error ? el('span', { className: 'dshrouter-error' }, error) : null,
        el('input', {
          ref: inputRef,
          type: 'file',
          accept: 'image/png,image/jpeg,image/webp,image/gif,audio/*,video/*,.pdf,.doc,.docx,.txt,.md,.csv,.json,.zip',
          multiple: true,
          style: { display: 'none' },
          'aria-label': t('attachPickTitle'),
          onChange: (event) => {
            intake(Array.from(event.target.files ?? []))
            event.target.value = ''
          },
        }),
        el('button', {
          type: 'button',
          className: 'dshrouter-attach',
          'aria-label': t('attach'),
          title: error || t('attach'),
          onClick: () => {
            setError('')
            if (inputRef.current) inputRef.current.click()
          },
        }, error ? '⚠' : '📎'))
    }

    /** EVO-012 批二 A / FIX-021：ref → 同源直达 url。兜底序 **url > attachmentId
     *  > id**（三者任一 string 非空即用）：
     * - url：标记 url 字段优先；
     * - attachmentId：标记（parseMarkersOf）产物 ref 的规范字段；
     * - id：宿主浏览器侧把 tool-result marker 结构化为 image content block 的
     *   attachment 形状（dsh-client-ui-conversation 实证 `attachment.id`——
     *   浏览器 store 的 block 形状与持久化 jsonl 格式不同，宿主编解码层归一
     *   化为 id 字段）。缺失 id 兜底 = FIX-021 根因：推导空 → RouteImage 走
     *   imageData RPC → 宿主网关 rejected → 用户见「图片加载失败」错误按钮
     *   （EVO-012 复验失败）。
     * 经 encodeURIComponent 防御路径注入，宿主路由白名单兜底。RouteImage 与
     * 本会话集合视图共用（P5 单点）。 */
    function directAssetUrlOf(ref) {
      if (typeof ref?.url === 'string' && ref.url) return ref.url
      const idField = typeof ref?.attachmentId === 'string' && ref.attachmentId
        ? ref.attachmentId
        : (typeof ref?.id === 'string' && ref.id ? ref.id : '')
      return idField ? `/router-assets/${encodeURIComponent(idField)}` : ''
    }

    /** 单张图片缩略图：优先同源 url 直达（EVO-012——directAssetUrlOf 单点；
     *  imageData RPC 降为 onError 最后回退（Electron file:// 面 / 宿主网关回归
     *  边界 / 非内容寻址 id）。thumb 态用小尺寸类（卡片折叠态）。 */
    function RouteImage(props) {
      // AUDIT-001 P0-A：宿主浏览器提供**真 React 18.3.1**（dsh-web-frontend
      // seed 表 `react` → react.production.min.js，createRoot 并发入口），
      // createElement 的 RESERVED_PROPS（key/ref/__self/__source）会把 `ref`
      // 从 props 中剥离——本组件曾以 `ref` 为 prop 名接收图片引用，props.ref
      // 恒 undefined → directAssetUrlOf 恒空 → 直达路径永不生效 → RPC 回退
      // （EVO-012/FIX-021 用户侧「三连败」根因；L3 诊断
      // `site=collapsed ref=undefined` 直接印证）。prop 更名 imageRef 彻底
      // 避开保留字；tests/audit-001-concurrency.mjs S1（宿主剥离语义
      // harness）守卫本回归。
      const { t, router, imageRef, onOpen } = props
      const [state, setState] = useState({ status: 'loading' })
      const directUrl = directAssetUrlOf(imageRef)
      const load = () => {
        const remote = typeof router === 'function' ? router() : router
        if (!remote || typeof remote.imageData !== 'function') {
          setState({ status: 'error', detail: 'REMOTE_UNAVAILABLE' })
          return
        }
        setState({ status: 'loading' })
        remote.imageData({ ref: imageRef }).then((response) => {
          if (response.ok && response.value && response.value.data) {
            setState({
              status: 'ready',
              src: `data:${response.value.mediaType || 'image/png'};base64,${response.value.data}`,
              alt: response.value.name || t('toolImageLabel'),
            })
          } else {
            const detail = response.value && typeof response.value.message === 'string'
              ? `${response.value.code || 'FAILED'}: ${response.value.message}`
              : (response.error && response.error.message ? String(response.error.message) : 'FAILED')
            setState({ status: 'error', detail })
          }
        }, (failure) => setState({ status: 'error', detail: failure && failure.message ? String(failure.message) : 'RPC_FAILED' }))
      }
      useEffect(() => { if (!directUrl) load() }, [])
      if (directUrl) {
        const alt = (typeof imageRef.name === 'string' && imageRef.name) || t('toolImageLabel')
        return el('img', {
          className: props.thumb ? 'dshrouter-toolthumb' : 'dshrouter-toolimage',
          src: directUrl,
          alt,
          onClick: () => onOpen({ src: directUrl, alt }),
          onError: () => load(),
        })
      }
      if (state.status === 'error') {
        return el('button', {
          type: 'button',
          className: 'dshrouter-toolcard',
          title: state.detail,
          onClick: load,
        }, `${t('imageLoadFailed')}（${state.detail}）`)
      }
      if (state.status === 'ready') {
        return el('img', {
          className: 'dshrouter-toolimage',
          src: state.src,
          alt: state.alt,
          onClick: () => onOpen({ src: state.src, alt: state.alt }),
        })
      }
      return el('span', { className: 'dshrouter-toolmeta' }, t('toolRunning'))
    }

    /** EVO-012：工具耗时格式化（<1s → ms；<60s → x.xs；其余 → mmss）。 */
    function formatToolDuration(ms) {
      if (!Number.isFinite(ms) || ms < 0) return ''
      if (ms < 1000) return `${Math.round(ms)}ms`
      if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
      const minutes = Math.floor(ms / 60000)
      const seconds = Math.floor((ms % 60000) / 1000)
      return `${minutes}m${seconds}s`
    }

    // ── EVO-012 批二 C：会话产物集合视图（本会话生成图网格入口）────────────
    // 收集：route_agent 工具卡渲染时把标记产物 ref 写入会话产物表（sessionId
    // 由输入区 SessionGallery 在 render 期锚定——DSH web 单会话视图，活跃输入
    // 区即当前会话；render 期赋值先于工具卡 effect 回写，无时序竞态）；展示：
    // 输入区「本会话图片」按钮（N 张）→ 网格 → 单图放大。跨会话不串（键 =
    // sessionId），同一张图（attachmentId 内容寻址）按 id 去重。
    const sessionGallery = {
      map: new Map(),
      activeId: '',
      listeners: new Set(),
    }
    const SESSION_GALLERY_MAX = 200
    function sessionProductsOf(sessionId) {
      return sessionGallery.map.get(sessionId) ?? []
    }
    function addSessionProduct(sessionId, ref) {
      if (!sessionId || !ref || typeof ref.attachmentId !== 'string' || !ref.attachmentId) return
      const list = sessionGallery.map.get(sessionId) ?? []
      if (list.some((item) => item.attachmentId === ref.attachmentId)) return
      list.push({ ...ref })
      if (list.length > SESSION_GALLERY_MAX) list.splice(0, list.length - SESSION_GALLERY_MAX)
      sessionGallery.map.set(sessionId, list)
      for (const listener of sessionGallery.listeners) listener()
    }
    function useSessionProducts(sessionId) {
      const [version, setVersion] = useState(0)
      useEffect(() => {
        const listener = () => setVersion((value) => value + 1)
        sessionGallery.listeners.add(listener)
        return () => { sessionGallery.listeners.delete(listener) }
      }, [])
      void version
      return sessionId ? sessionProductsOf(sessionId) : []
    }
    /** 本会话图片产物集合视图入口：输入区纯图标按钮（28×28 与附件按钮同
     *  形态——「🖼 N」文本在固定宽按钮内会竖排折行，用户反馈不协调
     *  2026-09-01）→ 悬停 title 显示计数 → 网格 → 单图放大。 */
    function SessionGallery(props) {
      const { t, sessionId } = props
      // render 期锚定当前会话（工具卡 useEffect 回写作读取——render 先于 effect）。
      sessionGallery.activeId = typeof sessionId === 'string' && sessionId ? sessionId : ''
      const products = useSessionProducts(sessionId)
      const [open, setOpen] = useState(false)
      const [lightbox, setLightbox] = useState(null)
      if (products.length === 0) return null
      return el('div', { className: 'dshrouter-gallery' },
        el('button', {
          type: 'button',
          className: 'dshrouter-attach',
          'aria-label': t('galleryButton'),
          title: `${t('galleryTitle')}（${products.length}）`,
          onClick: () => setOpen(true),
        }, '🖼'),
        open ? el('div', { className: 'dshrouter-modal', onClick: (event) => { if (event.target === event.currentTarget) setOpen(false) } },
          el('div', { className: 'dshrouter-modal-body' },
            el('h4', { className: 'dshrouter-modal-title' }, t('galleryTitle')),
            el('div', { className: 'dshrouter-gallery-grid' },
              ...products.map((ref, index) => el('button', {
                type: 'button',
                className: 'dshrouter-gallery-cell',
                key: `${String(ref.attachmentId ?? '')}:${index}`,
                onClick: () => setLightbox(ref),
              }, el('img', {
                className: 'dshrouter-gallery-image',
                src: directAssetUrlOf(ref),
                alt: (typeof ref.name === 'string' && ref.name) || t('toolImageLabel'),
              })))),
            el('div', { className: 'dshrouter-row' },
              el('span', { className: 'dshrouter-spacer' }),
              el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => setOpen(false) }, t('close'))))) : null,
        lightbox ? el('div', { className: 'dshrouter-modal', onClick: (event) => { if (event.target === event.currentTarget) setLightbox(null) } },
          el('div', { className: 'dshrouter-modal-body' },
            el('h4', { className: 'dshrouter-modal-title' }, t('imagePreviewTitle')),
            el('img', { src: directAssetUrlOf(lightbox), alt: (typeof lightbox.name === 'string' && lightbox.name) || t('toolImageLabel'), style: { maxWidth: '100%', borderRadius: 8 } }),
            el('div', { className: 'dshrouter-row' },
              el('span', { className: 'dshrouter-spacer' }),
              el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => setLightbox(null) }, t('close'))))) : null)
    }

    /** base64 → blob URL（L3 预览用；createObjectURL 不可用时回落 data: URL）。 */
    function blobUrlOf(dataBase64, mediaType) {
      try {
        const binary = atob(dataBase64)
        const bytes = new Uint8Array(binary.length)
        for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index)
        const blob = new Blob([bytes], { type: mediaType || 'application/octet-stream' })
        const url = window.URL && typeof window.URL.createObjectURL === 'function' ? window.URL.createObjectURL(blob) : ''
        if (url) return url
      } catch { /* 解码失败：回落 data: URL */ }
      return `data:${mediaType || 'application/octet-stream'};base64,${dataBase64}`
    }

    /**
     * L3 文件行（v3 §5 展示段 L3 / N-7）：路径文本 + 「打开文件」动作。点击 →
     * router/readWorkspaceFile 读字节 → blob 预览：audio/video 原生标签兜底
     * （V-DSH-3：宿主无播放组件，降级路径即最终路径），其余类型下载链接；
     * 失败显示错误码可重试（不静默）。
     */
    function RouteFileRow(props) {
      const { t, router, file } = props
      const [state, setState] = useState({ status: 'idle' })
      const open = () => {
        const remote = typeof router === 'function' ? router() : router
        if (!remote || typeof remote.readWorkspaceFile !== 'function') {
          setState({ status: 'error', detail: 'REMOTE_UNAVAILABLE' })
          return
        }
        setState({ status: 'loading' })
        remote.readWorkspaceFile({ path: file.path }).then((response) => {
          if (response && response.ok && response.value && response.value.ok === true && response.value.dataBase64) {
            const value = response.value
            setState({
              status: 'ready',
              previewUrl: blobUrlOf(value.dataBase64, value.mediaType),
              mediaType: typeof value.mediaType === 'string' ? value.mediaType : '',
              name: typeof value.name === 'string' && value.name ? value.name : file.name,
            })
          } else {
            const detail = response && response.value && typeof response.value.message === 'string'
              ? `${response.value.code || 'FAILED'}: ${response.value.message}`
              : (response && response.error && response.error.message ? String(response.error.message) : 'FAILED')
            setState({ status: 'error', detail })
          }
        }, (failure) => setState({ status: 'error', detail: failure && failure.message ? String(failure.message) : 'RPC_FAILED' }))
      }
      // blob URL 生命周期（F-2 R12）：createObjectURL 产生的 URL 必须随组件
      // 卸载 / previewUrl 变更释放（revokeObjectURL），否则长会话反复打开文件
      // 会累积 blob URL 与底层 Blob（每份上限 25MB）。data: URL 回落非 object
      // URL，无需（也无法）revoke——守卫跳过，失败回落路径不受影响。
      const previewUrl = state.status === 'ready' && typeof state.previewUrl === 'string' ? state.previewUrl : ''
      useEffect(() => {
        return () => {
          if (previewUrl && !previewUrl.startsWith('data:')) {
            try { window.URL.revokeObjectURL(previewUrl) } catch { /* URL API 不可用时无需释放 */ }
          }
        }
      }, [previewUrl])
      const pathText = el('span', { className: 'dshrouter-toolpath', title: file.path }, file.path)
      if (state.status === 'ready') {
        // ready 三态共用容器（F-11 R12）：audio/video 原生标签兜底（V-DSH-3），
        // 其余类型下载链接——提取共用避免重复。
        const mediaType = String(state.mediaType || '')
        const media = mediaType.startsWith('audio/')
          ? el('audio', { className: 'dshrouter-toolmedia', controls: true, src: previewUrl })
          : mediaType.startsWith('video/')
            ? el('video', { className: 'dshrouter-toolmedia', controls: true, src: previewUrl })
            : el('a', { className: 'dshrouter-button ghost', href: previewUrl, download: state.name || 'file' }, t('download'))
        return el('div', { className: 'dshrouter-toolfile' }, pathText, media)
      }
      const action = state.status === 'loading'
        ? el('span', { className: 'dshrouter-toolmeta' }, t('fileOpening'))
        : state.status === 'error'
          ? el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: open }, `${t('fileOpenFailed')}（${state.detail}）`)
          : el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: open }, t('openFile'))
      return el('div', { className: 'dshrouter-toolfile' }, pathText, action)
    }

    /** route_agent 工具卡片：默认折叠（EVO-012）——摘要行（route_agent ·
     * 多模型路由 · 成功/失败/处理中 · 耗时 + 展开箭头，参考宿主 Think 条目
     * 交互）+ 折叠态产物缩略图（directAssetUrlOf 直达；旧产物无 url 字段自愈）；
     * 点击展开完整结果（错误行 / 图片 gallery / L3 文件行 / 文本）。imageData
     * RPC 仅 onError 最后回退。标记产物同时回写本会话产物集合（批二 C）。 */
    function RouteAgentToolCard(props) {
      const { t, router, block } = props
      const [lightbox, setLightbox] = useState(null)
      const [expanded, setExpanded] = useState(false)
      const settled = !!block && block.kind === 'tool-result'
      const refs = []
      const productRefs = []
      const texts = []
      for (const contentBlock of settled ? block.content ?? [] : []) {
        if (!contentBlock) continue
        if (contentBlock.type === 'image') {
          // FIX-021 根因修复：attachment 单次访问存局部（宿主对象可能为惰性
          // getter——条件判断与 push 的两次属性访问可能返回不同值，push 进
          // undefined → directAssetUrlOf 空 → RPC 回退 → 错误按钮）。值为空
          // 或非对象时跳过（该图的显示由同块 text marker 解析的 ref 承载——
          // marker ref 携带 url，直达渲染）。
          const attachment = contentBlock.attachment
          if (attachment && typeof attachment === 'object') refs.push(attachment)
          continue
        }
        if (contentBlock.type === 'text' && typeof contentBlock.text === 'string') {
          for (const ref of parseMarkersOf(contentBlock.text)) {
            refs.push(ref)
            // 标记派生 ref = 产物（批二 B 起转发图不再进结果标记；旧会话的
            // 图片 content 块是输入回显遗留——不进集合，避免污染产物网格）。
            productRefs.push(ref)
          }
          const cleaned = contentBlock.text.replace(/\[router:image:[^\]\n]+\]/g, '').trim()
          if (cleaned) texts.push(cleaned)
        }
      }
      // EVO-012 批二 C：产物回写本会话集合（所有 hook 在运行态分支之前——
      // 节点 running→settled 转换时 hook 顺序稳定；addSessionProduct 按
      // attachmentId 去重，重渲染幂等）。
      useEffect(() => {
        for (const ref of productRefs) addSessionProduct(sessionGallery.activeId, ref)
      })
      if (!settled) {
        return el('div', { className: 'dshrouter-toolcard' },
          el('div', { className: 'dshrouter-toolcard-summary' },
            el('span', { className: 'dshrouter-toolcard-title' }, t('toolRouteTitle')),
            el('span', { className: 'dshrouter-toolmeta' }, t('toolRunning'))))
      }
      const open = (target) => setLightbox(target)
      // L3 文件引用（v3 §5 展示段 L3 / N-7）：从工具调用参数提取 filePath 与
      // files 的非 URL 条目——「打开文件」预览的确定性来源（audio/video 原生
      // 标签兜底 / 其他类型下载）；容错：argsRaw 非法时无 L3（不击穿渲染）。
      const fileRefs = []
      try {
        const args = JSON.parse(block.call && typeof block.call.argsRaw === 'string' ? block.call.argsRaw : '{}')
        const seenFiles = new Set()
        const pushFile = (value) => {
          const trimmed = typeof value === 'string' ? value.trim() : ''
          if (!trimmed || /^https?:\/\//i.test(trimmed) || seenFiles.has(trimmed)) return
          seenFiles.add(trimmed)
          fileRefs.push({ path: trimmed, name: String(trimmed).split(/[\\/]/).pop() || trimmed })
        }
        if (typeof args.filePath === 'string') pushFile(args.filePath)
        if (Array.isArray(args.files)) for (const item of args.files) pushFile(item)
      } catch { /* 容错：非法 argsRaw 不产生 L3 行 */ }
      // 摘要状态与耗时：成功/失败（错误终态展开行在 body），处理中由运行态分支承担。
      const statusText = block.isError === true ? t('statsFail') : t('statsOk')
      const duration = typeof block.callTime === 'number' && typeof block.time === 'number'
        ? formatToolDuration(Math.max(0, block.time - block.callTime))
        : ''
      // 折叠态缩略图：directAssetUrlOf 直达（渲染零 RPC、零等待）。
      const directRefs = refs.filter((ref) => directAssetUrlOf(ref))
      return el('div', { className: 'dshrouter-toolcard' },
        el('button', {
          type: 'button',
          className: 'dshrouter-toolcard-summary',
          'aria-expanded': expanded ? 'true' : 'false',
          onClick: () => setExpanded(!expanded),
        },
          el('span', { className: 'dshrouter-toolcard-title' }, t('toolRouteTitle')),
          el('span', { className: 'dshrouter-toolmeta' }, `${statusText}${duration ? ` · ${duration}` : ''}`),
          block.isError === true && block.error && typeof block.error.message === 'string' && block.error.message
            ? el('span', { className: 'dshrouter-toolerror' }, block.error.message)
            : null,
          el('span', { className: 'dshrouter-toolcard-chevron' }, expanded ? '▾' : '▸')),
        !expanded && directRefs.length > 0 ? el('div', { className: 'dshrouter-toolcard-thumbs' },
          // AUDIT-001 P0-A：图片引用经 imageRef prop 传递——`ref` 是 React
          // 保留 prop（RESERVED_PROPS），宿主真 React 18.3.1 会剥离致
          // props.ref 恒 undefined（组件头注释）。
          ...directRefs.map((imageRef, index) => el(RouteImage, {
            t, router, imageRef, onOpen: open, thumb: true,
            key: `${String(imageRef.attachmentId ?? '')}:${index}`,
          }))) : null,
        expanded ? el('div', { className: 'dshrouter-toolcard-body' },
          block.isError === true ? el('span', { className: 'dshrouter-toolerror' }, block.error && block.error.message ? block.error.message : t('statsFail')) : null,
          refs.length > 0 ? el('div', { className: 'dshrouter-toolimages dshrouter-toolgallery' },
            ...refs.map((imageRef, index) => el(RouteImage, {
              t, router, imageRef, onOpen: open,
              key: `${String(imageRef.attachmentId ?? '')}:${index}`,
            }))) : null,
          fileRefs.length > 0 ? el('div', { className: 'dshrouter-toolfiles' },
            ...fileRefs.map((file, index) => el(RouteFileRow, { t, router, file, key: `${file.path}:${index}` }))) : null,
          ...texts.map((text, index) => el('div', { className: 'dshrouter-tooltext', key: index }, text))) : null,
        lightbox ? el('div', { className: 'dshrouter-modal', onClick: (event) => { if (event.target === event.currentTarget) setLightbox(null) } },
          el('div', { className: 'dshrouter-modal-body' },
            el('h4', { className: 'dshrouter-modal-title' }, t('imagePreviewTitle')),
            el('img', { src: lightbox.src, alt: lightbox.alt, style: { maxWidth: '100%', borderRadius: 8 } }),
            el('div', { className: 'dshrouter-row' },
              el('span', { className: 'dshrouter-spacer' }),
              el('button', { type: 'button', className: 'dshrouter-button ghost', onClick: () => setLightbox(null) }, t('close'))))) : null)
    }

    // ── FIX-028：宿主客户端面演进适配（0.1.1-rc.8 → 0.1.2-rc.1）────────────
    // 用户报障（2026-09-05，设置页截图 sha256:61a445ce…）：「Agent 路由」整页
    // 「加载失败: Cannot read properties of undefined (reading 'llm')」。
    // RCA（宿主源码实证）：
    //  · 旧面 `connection.api` 已被宿主移除——dsh-client-connection 0.1.2-rc.1
    //    connection handle 面只有 isLoopback /
    //    generation / state / rpc / reconnect / registerGenerationSource /
    //    start，无 api 字段；本包旧 apply() `const api = connection.api` →
    //    undefined → load() 内 api.llm.providers 抛「Cannot read properties
    //    of undefined (reading 'llm')」→ 整页 error（用户截图实证）。
    //  · 新面：host 客户端统一走 typed remote 命名空间（dsh-api-remotes
    //    lib/client.js 全部描述子——llm L5682-5760 / settings L4939-5260 /
    //    credentials L4942-5030 / agentPresets L4337-4500 / session
    //    L8018-8500），响应为 {ok, value|error} 直面、参数为位置参数；
    //    宿主官方插件同款消费：dsh-client-ui-settings-models
    //    的 static inject（remote.credentials/llm/settings）+ 其对**同批三命名
    //    空间**的调用面（`ctx.remote.llm.listProviders()` 与
    //    `createModelsOperations(ctx)` 绑定的 `remote.credentials` 读写 /
    //    `remote.settings.mutate` / `remote.llm.discoverModels`）；
    //    另有 dsh-client-ui-model-selection 的 scope.modelDirectories 与
    //    ctx.remote.session.modelCatalog() 调用——后两者属 modelDirectories
    //    服务与 remote.session（**命名空间不同**），作**追加**证据保留，
    //    不替代上句三命名空间的证据对象（FIX-043 批 C 按 R1 P2-2 裁定取
    //    (a)：恢复原证据对象并符号化去行号——该对象经批 C 实读复核仍准确，
    //    且恰为三命名空间消费面）。
    // 本适配层把「新面」收敛成本包既有消费面「旧信封」——页面/组件消费点
    // 零改动（P5：宿主面代差单点收敛；旧 connection.api 路径已删除，禁止
    // 并存）。映射与形状全部锚定宿主 schema：
    //
    // | 本包消费面（旧信封）              | 宿主新面（typert remote）          |
    // | api.llm.providers({})            | remote.llm.listProviders() +        |
    // |                                   |   listConfigurableProviders() 连接  |
    // | api.llm.models({})               | remote.session.modelCatalog()       |
    // | api.llm.discoverModels(p)        | remote.llm.discoverModels(p.settingsNs, {provider,baseURL,api,apiKey}) |
    // | api.settings.describe({})        | remote.settings.describe()           |
    // | api.settings.mutate({ns,ops})    | remote.settings.mutate(ns, ops)      |
    // | api.credentials.describe({refs}) | remote.credentials.describe(refs)    |
    // | api.credentials.set({ref,v})     | remote.credentials.set(ref, v)       |
    // | api.credentials.unset({ref})     | remote.credentials.unset(ref)        |
    // | api.agentPresets.list({})        | remote.agentPresets.list()           |
    // | api.sessions.models({id})        | ctx.modelDirectories.directoryFor(id).load()（宿主无 per-session wire RPC）|
    // | api.sessions.selectModel(p)      | remote.session.selectModel(p)        |
    //
    // 形状锚：llm/listProviders L5678-5681、listConfigurableProviders L5671-5677、
    // discoverModels 参数 L5658-5664 / 结果（裸数组）L5665-5670；
    // settings/describe L4709-4757、mutate L4758-4811（参数位置 + 直面团）；
    // credentials/describe 结果 L4698-4702 / set L4703-4705 / unset L4706-4707；
    // agentPresets/list L4315-4325；session/modelCatalog L7794-7823、
    // selectModel L7946-7956。
    /** 宿主 provider 目录连接（registered ∪ declared）——dsh-client-ui-
     *  settings-models 的 joinProviderDirectory 同构镜像
     *  （P10：锚定宿主源码形态，非心智模型）：declared 行在前（声明序），
     *  注册而未声明行追加在后（displayName=注册名、settingsNs=""）。
     *  @param registered - llm.listProviders 结果（[{id,name}]）。
     *  @param directory - llm.listConfigurableProviders 结果
     *    （[{provider, displayName, settingsNs, settingsPath, declared?}]）。
     *  @returns 旧 providers 条目数组（含 active/declared 判定）。 */
    function joinProviderDirectoryHost(registered, directory) {
      const active = new Set((registered ?? []).map((provider) => provider.id))
      const declared = new Set((directory ?? []).map((entry) => entry.provider))
      const rows = (directory ?? []).map((entry) => ({
        provider: entry.provider,
        displayName: entry.displayName,
        settingsNs: entry.settingsNs,
        settingsPath: Array.isArray(entry.settingsPath) ? [...entry.settingsPath] : [],
        active: active.has(entry.provider),
        ...(entry.declared === undefined ? {} : { declared: entry.declared }),
      }))
      for (const provider of registered ?? []) {
        if (declared.has(provider.id)) continue
        rows.push({
          provider: provider.id,
          displayName: provider.name,
          settingsNs: '',
          settingsPath: [],
          active: true,
        })
      }
      return rows
    }
    /** 本包消费面兼容适配（FIX-028）：把宿主 remote.* 的 {ok,value|error}
     *  直面响应包装成旧信封 {result:{ok,value?,error?}}——本包全部消费点
     *  （probeProviderModels / load() / 账号卡 / 预设卡 / ModelTakeover /
     *  refreshSessionDirectory 保底）以旧信封判定，包装在单点完成。 */
    function envelopeOf(response) {
      if (response && typeof response === 'object' && typeof response.ok === 'boolean') {
        return {
          result: {
            ok: response.ok,
            ...(response.ok
              ? { value: response.value }
              : { error: response.error && response.error.message ? response.error : { message: String(response.error ?? response) } }),
          },
        }
      }
      return { result: { ok: false, error: { message: `dsh-agent-router: host remote answered ${String(response)}` } } }
    }
    /** ARCH-004 B2（§4.3 域 1）浏览器镜像诊断环形——lib/host-abi/health.js
     *  noteHostDiag/HOST_DIAG_LIMIT=64 同构（浏览器包无法 import Node ESM）；
     *  face-degraded / inject-face-missing 事件的唯一数据面（createClientRemotes
     *  health().diag——健康徽章面板可观测，P8 禁无观测吞错）。
     *  FIX-037 ⑤（EVO-023 R0 P2-1 镜像半边）：补**字段白名单 + 长度截断**
     *  （与 lib/host-abi/health.js noteHostDiag 逐字同构——旧实现仅 64 条
     *  上限，face/consumer/code/detail 靠调用点各自截断，镜像环防御深度
     *  低于权威半球）。 */
    const HOST_FACE_DIAG_LIMIT = 64
    const hostFaceDiagEntries = []
    function noteHostFaceDiag(entry) {
      try {
        const record = {
          at: Date.now(),
          kind: typeof entry?.kind === 'string' && entry.kind ? entry.kind.slice(0, 64) : '?',
          ...(typeof entry?.face === 'string' && entry.face ? { face: entry.face.slice(0, 64) } : {}),
          ...(typeof entry?.consumer === 'string' && entry.consumer ? { consumer: entry.consumer.slice(0, 64) } : {}),
          ...(typeof entry?.code === 'string' && entry.code ? { code: entry.code.slice(0, 48) } : {}),
          ...(typeof entry?.detail === 'string' && entry.detail ? { detail: entry.detail.slice(0, 160) } : {}),
        }
        hostFaceDiagEntries.push(record)
        if (hostFaceDiagEntries.length > HOST_FACE_DIAG_LIMIT) hostFaceDiagEntries.splice(0, hostFaceDiagEntries.length - HOST_FACE_DIAG_LIMIT)
      } catch { /* 诊断失败绝不影响主链（presetDiag 同款纪律） */ }
    }

    /** ARCH-004 域 4（§4.3 域 4 / W-4，EVO-023 B5）events 域浏览器镜像——
     *  lib/host-abi/events.js 的转发事件白名单 + 共享订阅单点的镜像（本包经
     *  __ModuleLoader__ 仅 require('react')，无 ESM 模块面：OAUTH_ROUTE_PROVIDER
     *  / createClientRemotes 同款镜像纪律）。白名单单一声明源 = 宿主
     *  dsh-api-remotes/lib/types/remote-events.js 的 API_REMOTE_FORWARDED_EVENTS（28 项转发事件，ARCH-005 R0 随 0.2.0-rc.2 基线登记同步；ARCH-006 随 0.2.1-rc.2 吸收 plugin-market/changed）；
     *  权威侧 = lib/host-abi/events.js `FORWARDED_EVENT_ALLOWLIST`，值级 parity
     *  由 tests/host-abi-health.mjs §9e 判别锁定，漂移即红。
     *  运行时半边（W-4 双检②）：白名单外事件名**订阅即拒绝** + 诊断——
     *  Analyst D-2 死订阅（旧 `credentials/updated` 不在表，宿主从未转发）的
     *  机器防线（静态半边 = 插件 `$on` 字面量 ⊆ 白名单比对测试）。 */
    const FORWARDED_EVENT_ALLOWLIST = [
      'agent-preset/selected',
      'approval/request',
      'api-session/activity',
      'api-session/added',
      'api-session/error',
      'api-session/removed',
      'api-session/status',
      'commands/change',
      'deepseek-account/session-expired',
      'deepseek-account/model-sign-in-required',
      'credentials/record-updated',
      'credentials/reference-updated',
      'goal/activation-changed',
      'cordis/request-run',
      'cordis/request-run-resolved',
      'cordis/dynamic-package',
      'cordis/dynamic-retract',
      'cordis/inspect-query',
      'cordis/inspect-query-resolved',
      'llm/adapters-updated',
      'permission-presets/catalog-changed',
      'plugin-manager/changed',
      'plugin-manager/install-log',
      'plugin-manager/install-state',
      'plugin-market/changed',
      'settings/document-updated',
      'schedule/changed',
      'user-questions/request',
    ]
    /** 转发事件可达性判定（权威侧 isForwardedEvent 镜像）。 */
    const isForwardedEvent = (event) => typeof event === 'string' && FORWARDED_EVENT_ALLOWLIST.includes(event)
    /** 同目标（$on 闭包）共享 listener 注册表——同事件名多次订阅收敛单宿主
     *  listener（Node 侧 events 域 sharedListeners 同构）。 */
    const sharedClientListeners = new WeakMap()
    /**
     * 共享转发事件订阅（权威侧 subscribeEvents 的浏览器镜像）：同事件名多
     *  consumer 共享单 $on listener + 按名分发 + 卸载聚合（最后一个消费者摘除
     * 才真 dispose）；白名单外事件名拒绝 + noteHostFaceDiag 诊断；handler 抛错
     *  fail-safe 吞并记诊断（绝不外泄击穿宿主事件总线）；attach 抛错条目**不
     *  入表** + event-subscribe-failed 诊断（FIX-035 降级语义，与权威侧
     *  events.js 同型——失败消费者 dispose no-op，下次订阅重试 attach）。
     * @param on - `$on`（ctx.remote.$on 包装）。
     * @param subscriptions - [{ event, consumer?, handler(args…) }]
     * @returns disposeAll。
     */
    function subscribeClientEvents(on, subscriptions) {
      if (typeof on !== 'function') return () => {}
      const perEvent = new Map()
      for (const sub of Array.isArray(subscriptions) ? subscriptions : []) {
        if (!sub || typeof sub.event !== 'string' || !sub.event || typeof sub.handler !== 'function') {
          noteHostFaceDiag({ kind: 'event-subscribe-rejected', code: 'invalid-shape' })
          continue
        }
        const consumer = typeof sub.consumer === 'string' && sub.consumer ? sub.consumer : ''
        if (!isForwardedEvent(sub.event)) {
          noteHostFaceDiag({ kind: 'event-subscribe-rejected', face: sub.event.slice(0, 64), consumer, code: 'not-forwarded', detail: 'event absent from API_REMOTE_FORWARDED_EVENTS mirror (dead subscription)' })
          continue
        }
        const consumers = perEvent.get(sub.event) ?? []
        consumers.push({ consumer, handler: sub.handler })
        perEvent.set(sub.event, consumers)
      }
      let table = sharedClientListeners.get(on)
      if (!table) {
        table = new Map()
        sharedClientListeners.set(on, table)
      }
      const disposeAll = []
      for (const [event, consumers] of perEvent) {
        let entry = table.get(event)
        if (!entry) {
          const created = { consumers: [], dispose: null }
          const sharedListener = (...args) => {
            // 返回值语义与权威侧同构：单 consumer 的 thenable 原样透传（调用方
            // await 可用），多 consumer 合并 Promise.all；无 thenable 零分配。
            const pending = []
            for (const consumer of created.consumers.slice()) {
              try {
                const outcome = consumer.handler(...args)
                if (outcome && typeof outcome.then === 'function') pending.push(outcome)
              } catch (error) {
                noteHostFaceDiag({ kind: 'event-handler-error', face: event, consumer: consumer.consumer, detail: String(error?.message ?? error).slice(0, 120) })
              }
            }
            if (pending.length === 0) return undefined
            return pending.length === 1 ? pending[0] : Promise.all(pending)
          }
          let attached = false
          try {
            const dispose = on(event, sharedListener)
            created.dispose = typeof dispose === 'function' ? dispose : null
            attached = true
          } catch (error) {
            // FIX-035（EVO-023 R0 P2-1 镜像半边）：attach 失败条目**绝不入表**
            // （否则后续订阅复用死条目 + 静默死订阅）；失败消费者本次零 listener，
            // dispose 降级 no-op，下次订阅重试 attach。
            noteHostFaceDiag({ kind: 'event-subscribe-failed', face: event, consumer: consumers.map((item) => item.consumer).filter(Boolean).join(',').slice(0, 64), code: 'attach-threw', detail: String(error?.message ?? error).slice(0, 120) })
          }
          if (!attached) {
            disposeAll.push(() => {})
            continue
          }
          entry = created
          table.set(event, created)
        }
        entry.consumers.push(...consumers)
        disposeAll.push(() => {
          for (const consumer of consumers) {
            const index = entry.consumers.indexOf(consumer)
            if (index >= 0) entry.consumers.splice(index, 1)
          }
          if (entry.consumers.length === 0) {
            try { entry.dispose?.() } catch { /* 卸载尽力而为 */ }
            if (table.get(event) === entry) table.delete(event)
          }
        })
      }
      return () => {
        for (const dispose of disposeAll.splice(0)) {
          try { dispose() } catch { /* 卸载尽力而为 */ }
        }
      }
    }

    /** 客户端 remote.* 五命名空间方法形状契约——lib/host-abi/client-remotes.js
     *  CLIENT_REMOTE_FACES 的浏览器镜像（B2 随 createClientRemotes 一并镜像；
     *  行为 parity 由 tests/host-abi-health.mjs §7 判别锁定，漂移即红）。 */
    const CLIENT_REMOTE_FACES = {
      llm: ['listProviders', 'listConfigurableProviders', 'discoverModels'],
      settings: ['describe', 'mutate'],
      credentials: ['describe', 'set', 'unset'],
      agentPresets: ['list'],
      session: ['modelCatalog', 'selectModel'],
    }

    /** 单面能力探测（§4.3 域 1，probeRemoteFace 镜像）：存在性（ctx.get 优先 +
     *  ctx.remote.<ns> 属性面兜底——FIX-027 双形态）+ 方法形状校验。 */
    function probeRemoteFace(ctx, name) {
      const requiredMethods = CLIENT_REMOTE_FACES[name] ?? []
      let face
      try {
        const viaGet = ctx && typeof ctx.get === 'function' ? ctx.get(`remote.${name}`) : undefined
        face = viaGet !== undefined ? viaGet : (ctx && ctx.remote ? ctx.remote[name] : undefined)
      } catch (error) {
        return { name, state: 'missing', detail: `host-face-missing: ${String(error?.message ?? error).slice(0, 80)}` }
      }
      if (!face || typeof face !== 'object') return { name, state: 'missing', detail: 'host-face-missing' }
      const missingMethods = requiredMethods.filter((method) => typeof face[method] !== 'function')
      if (missingMethods.length > 0) return { name, state: 'degraded', detail: `host-face-shape: ${missingMethods.join(',')}` }
      return { name, state: 'ok' }
    }

    /** 客户端宿主面健康快照（clientRemotesHealth 镜像）：五命名空间逐面探测。 */
    function clientRemotesHealth(ctx) {
      return Object.keys(CLIENT_REMOTE_FACES).map((name) => probeRemoteFace(ctx, name))
    }

    /** ARCH-004 B2（§4.3 域 1 唯一入口）createClientRemotes——FIX-028 旧
     *  适配层本体迁域更名（→ lib/host-abi/client-remotes.js 权威单点 +
     *  本浏览器镜像，OAUTH_ROUTE_PROVIDER 镜像先例；envelope/health 行为
     *  parity 由 tests/host-abi-health.mjs §7 判别锁定，漂移即红；P5：旧
     *  实现已删除，grep 零残留）。
     *  面按调用时延迟解析（get 优先 + ctx.remote.<ns> 属性面兜底——FIX-027
     *  双形态防御先例；服务卸载/重挂后取最新，不缓存旧引用）。
     *  B2 语义变更（对比 FIX-028 throw）：命名空间缺失/方法形状漂移 → 降级
     *  信封（host-face-missing/host-face-shape）+ face-degraded 诊断事件；
     *  宿主调用被拒 → host-face-call 信封（透传宿主错误，绝不外泄击穿）——
     *  单面卡片降级 + 健康徽章，其余面照常，永不整页崩（§4.3「降级行为」）。
     *  @param ctx - 客户端 fiber ctx（命名空间声明见模块 inject 列表）。
     *  @returns { api, health() }——api 与旧适配层同形旧信封面
     *  （{result:{ok,value?,error?}}，消费点零改动）；health() → 徽章数据源
     *  （faces 探测快照 + diag 降级事件环形，惰性——仅显式调用时探测）。 */
    function createClientRemotes(ctx) {
      const noteDegraded = (face, code, detail) => noteHostFaceDiag({ kind: 'face-degraded', face, code, ...(detail ? { detail } : {}) })
      const degradedEnvelope = (face, code, message, detail) => {
        noteDegraded(face, code, detail)
        return { result: { ok: false, error: { code, message } } }
      }
      const faceOf = (name) => {
        const viaGet = ctx.get(`remote.${name}`)
        return viaGet !== undefined ? viaGet : (ctx.remote ? ctx.remote[name] : undefined)
      }
      const directoryFace = () => {
        const viaGet = ctx.get('modelDirectories')
        return viaGet !== undefined ? viaGet : ctx.modelDirectories
      }
      // 命名空间缺失 = 降级信封（B2：原 throw 语义已废——单面降级，永不整页崩）。
      const unavailable = (name) => degradedEnvelope(`remote.${name}`, 'host-face-missing', `dsh-agent-router: host remote face "${name}" 不可用——宿主 ${name} 命名空间未挂载或插件版本与宿主不兼容`)
      const misshapen = (name, methods) => degradedEnvelope(`remote.${name}`, 'host-face-shape', `dsh-agent-router: host remote face "${name}" 形状漂移——方法缺失: ${methods.join(',')}`, methods.join(','))
      // 面解析 + 形状守卫（缺面 → missing 信封；面在方法缺 → shape 信封；就绪 → null 放行）。
      const resolveFace = (name, face, methods) => {
        if (!face) return unavailable(name)
        const missing = methods.filter((method) => typeof face[method] !== 'function')
        if (missing.length > 0) return misshapen(name, missing)
        return null
      }
      const okValue = (value) => ({ result: { ok: true, value } })
      const failureOf = (error) => ({ result: { ok: false, error: error && error.message ? error : { message: String(error) } } })
      // 调用守卫（host-face-call）：宿主调用 throw → 降级信封（透传宿主错误，
      // 绝不外泄击穿调用方整页——§4.3「永不整页崩」的调用期防线）。
      const guard = (face, fn) => async (...args) => {
        try {
          return await fn(...args)
        } catch (error) {
          noteDegraded(face, 'host-face-call')
          return failureOf({ code: 'host-face-call', message: `dsh-agent-router: host face "${face}" 调用被拒: ${error && error.message ? error.message : String(error)}` })
        }
      }
      const llmFace = () => faceOf('llm')
      const settingsFace = () => faceOf('settings')
      const credentialsFace = () => faceOf('credentials')
      const agentPresetsFace = () => faceOf('agentPresets')
      const sessionFace = () => faceOf('session')
      return {
        api: {
          llm: {
            providers: guard('remote.llm', async () => {
              const llm = llmFace()
              const bad = resolveFace('llm', llm, ['listProviders', 'listConfigurableProviders'])
              if (bad) return bad
              const [registered, declared] = await Promise.all([llm.listProviders(), llm.listConfigurableProviders()])
              if (!registered.ok) return failureOf(registered.error)
              if (!declared.ok) return failureOf(declared.error)
              return okValue({ providers: joinProviderDirectoryHost(registered.value, declared.value) })
            }),
            models: guard('remote.session', async () => {
              const session = sessionFace()
              const bad = resolveFace('session', session, ['modelCatalog'])
              if (bad) return bad
              const response = await session.modelCatalog()
              if (!response.ok) return failureOf(response.error)
              const catalog = response.value ?? {}
              return okValue({ groups: Array.isArray(catalog.groups) ? catalog.groups : [], failures: Array.isArray(catalog.failures) ? catalog.failures : [] })
            }),
            discoverModels: guard('remote.llm', async (payload) => {
              const llm = llmFace()
              const bad = resolveFace('llm', llm, ['discoverModels'])
              if (bad) return bad
              const input = payload && typeof payload === 'object' ? payload : {}
              const response = await llm.discoverModels(input.settingsNs, {
                ...(input.provider !== undefined ? { provider: input.provider } : {}),
                ...(input.baseURL !== undefined ? { baseURL: input.baseURL } : {}),
                ...(input.api !== undefined ? { api: input.api } : {}),
                ...(input.apiKey !== undefined ? { apiKey: input.apiKey } : {}),
              })
              if (!response.ok) return failureOf(response.error)
              return okValue({ models: Array.isArray(response.value) ? response.value : [] })
            }),
          },
          settings: {
            describe: guard('remote.settings', async () => {
              const settings = settingsFace()
              const bad = resolveFace('settings', settings, ['describe'])
              if (bad) return bad
              const response = await settings.describe()
              if (!response.ok) return failureOf(response.error)
              const value = response.value ?? {}
              return okValue({
                writable: value.writable === true,
                hasDocument: value.hasDocument === true,
                namespaces: Array.isArray(value.namespaces) ? value.namespaces : [],
              })
            }),
            mutate: guard('remote.settings', async (payload) => {
              const settings = settingsFace()
              const bad = resolveFace('settings', settings, ['mutate'])
              if (bad) return bad
              const input = payload && typeof payload === 'object' ? payload : {}
              const response = await settings.mutate(input.ns, Array.isArray(input.ops) ? input.ops : [])
              return envelopeOf(response)
            }),
          },
          credentials: {
            describe: guard('remote.credentials', async (payload) => {
              const credentials = credentialsFace()
              const bad = resolveFace('credentials', credentials, ['describe'])
              if (bad) return bad
              const input = payload && typeof payload === 'object' ? payload : {}
              const response = await credentials.describe(Array.isArray(input.refs) ? input.refs : [])
              if (!response.ok) return failureOf(response.error)
              return okValue({ credentials: response.value ?? {} })
            }),
            set: guard('remote.credentials', async (payload) => {
              const credentials = credentialsFace()
              const bad = resolveFace('credentials', credentials, ['set'])
              if (bad) return bad
              const input = payload && typeof payload === 'object' ? payload : {}
              return envelopeOf(await credentials.set(input.ref, input.value))
            }),
            unset: guard('remote.credentials', async (payload) => {
              const credentials = credentialsFace()
              const bad = resolveFace('credentials', credentials, ['unset'])
              if (bad) return bad
              const input = payload && typeof payload === 'object' ? payload : {}
              return envelopeOf(await credentials.unset(input.ref))
            }),
          },
          agentPresets: {
            list: guard('remote.agentPresets', async () => {
              const presets = agentPresetsFace()
              const bad = resolveFace('agentPresets', presets, ['list'])
              if (bad) return bad
              const response = await presets.list()
              if (!response.ok) return failureOf(response.error)
              return okValue(response.value ?? { presets: [] })
            }),
          },
          sessions: {
            // 宿主 0.1.2-rc.1 客户端面无 per-session 模型 wire RPC（api-remotes
            // session 命名空间只有 modelCatalog——全局目录，非会话选择）；
            // 等价读 = ctx.modelDirectories.directoryFor(sessionId).load()
            // （ModelDirectory 快照 {current,routable,groups,failures} 与旧
            // sessions.models 值同形——FIX-026 直驱路径同一机制）。
            models: guard('modelDirectories', async (payload) => {
              const input = payload && typeof payload === 'object' ? payload : {}
              const directoryService = directoryFace()
              // F-3（EVO-020 R0 台账，EVO-022 B4 ⑦收口）：缺面（命名空间未挂载）
              // → host-face-missing 降级信封 + face-degraded 诊断事件——对齐
              // 权威单点 HOST_FACE_ERROR_CODES 三错误码降级体系（原 FIX-028
              // failureOf 无短码无环形事件）。directoryFor 形状漂移 / sessionId
              // 缺失保持
              // failureOf 原语义（非缺面形态不误标 missing）。
              if (!directoryService) {
                return degradedEnvelope('modelDirectories', 'host-face-missing', 'dsh-agent-router: modelDirectories 服务不可用（宿主旧版本？）')
              }
              if (typeof directoryService.directoryFor !== 'function' || !input.sessionId) {
                return failureOf(new Error('dsh-agent-router: modelDirectories 服务不可用（宿主旧版本？）'))
              }
              let directory
              try {
                directory = directoryService.directoryFor(input.sessionId)
              } catch (error) {
                return failureOf(error)
              }
              if (!directory || typeof directory.load !== 'function') {
                return failureOf(new Error('dsh-agent-router: 会话模型目录不可用'))
              }
              try {
                return okValue(await directory.load())
              } catch (error) {
                return failureOf(error)
              }
            }),
            selectModel: guard('remote.session', async (payload) => {
              const session = sessionFace()
              const bad = resolveFace('session', session, ['selectModel'])
              if (bad) return bad
              return envelopeOf(await session.selectModel(payload))
            }),
          },
        },
        health() {
          return { faces: clientRemotesHealth(ctx), diag: hostFaceDiagEntries.slice() }
        },
      }
    }

    /** ARCH-004 B2：降级信封错误码提取（load() 面·code 数据面——面级降级
     *  短码入页面降级行；非降级信封（无 code）返回空串不影响旧路径）。 */
    const hostFaceCodeOf = (envelope) => envelope && envelope.result && envelope.result.ok === false && envelope.result.error && typeof envelope.result.error.code === 'string' ? envelope.result.error.code : ''

    // ── 插件装配 ────────────────────────────────────────────────────────────
    const NS = 'router'
    // FIX-027：模块级 inject 声明扩展——新增 'modelDirectories'（服务就绪时序 +
    // 隔离域可见性的规范保证面）。EV-134 真机反证：FIX-026 状态层/部署层全对
    // 而显示层断——裸 ctx.get('modelDirectories') 在客户端隔离域/注入门控下
    // 解析 undefined，handler 走保底 RPC（只读不更新显示）。声明即同时拿到
    // 两点保证：runner 激活门控等待服务就绪（dsh-cordis-client-runner
    // 的 waitingFor 记录按 fiber.inject 过滤）+ 属性面可见
    // （dynamicCordisContext 属性访问按 fiber.inject 声明门控，宿主
    // readService(prop, true) 面）。
    // FIX-028：命名空间面（remote.llm/settings/credentials/agentPresets/
    // session）同样按宿主官方先例声明——dsh-client-ui-settings-models
    // 的 static inject（remote.credentials/llm/settings）
    // + runner 自身 'remote.dynamicCordisRunner'（dsh-cordis-client-runner
    // 的 inject 数组声明）；
    // 声明 = 激活前等待命名空间挂载（页面永不早于宿主面就绪加载）。
    // 旧 'connection' 面仅用于取 .api（已随 0.1.2-rc.1 移除）——删除声明
    // （P5：被取代路径禁止并存）。
    const inject = ['slots', 'locale', 'remote', 'remote.llm', 'remote.settings', 'remote.credentials', 'remote.agentPresets', 'remote.session', 'modelDirectories']

    function apply(ctx) {
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-agent-router: locale')
      // FIX-028：宿主 0.1.2-rc.1 起 connection.api 已移除——统一经 remote.*
      // 命名空间适配（EVO-020/ARCH-004 B2：FIX-028 旧适配层迁域更名
      // createClientRemotes——lib/host-abi/client-remotes.js 权威单点 + 本包
      // 浏览器镜像，P5 旧实现已删除，grep 零残留）。旧实现
      // `ctx.get('connection').api` 在升级后恒 undefined → 页面加载失败
      // （用户截图实证），已删除。
      const remotes = createClientRemotes(ctx)
      const api = remotes.api
      // ARCH-004 域 5（§4.3 域 5 ②，B2 接线）：apply 时 fiber 面存在性自检
      // ——缺面记 inject-face-missing 诊断（lib/host-abi/inject-manifest.js
      // noteInjectFaceGaps 的浏览器镜像：本包无法 import Node ESM，
      // OAUTH_ROUTE_PROVIDER 镜像先例；FIBER_INJECT 单一事实源 ↔ 模块
      // inject 数组镜像锁定 tests/host-abi-health.mjs 6e）。不 throw 不阻断
      // apply——宿主 runner waitingFor 门控下用户无从得知卡在哪一面，本自检
      // 让「等待面」页面打开后立即可见（健康徽章数据源）。
      for (const name of inject) {
        let resolved
        try { resolved = typeof ctx.get === 'function' ? ctx.get(name) : undefined } catch { resolved = undefined }
        if (resolved === undefined) noteHostFaceDiag({ kind: 'inject-face-missing', face: name, code: 'missing' })
      }
      const t = ctx.locale.bind(NS)
      const remoteReady = ctx.remote.$mount(ROUTER_REMOTE).catch((error) => {
        console.error('dsh-agent-router: remote mount failed', error)
      })
      // 书签回传的 access token：官方站页面点「获取 token 书签」→ 跳回本页
      // 带 dshrouter-account/dshrouter-token 参数 → 自动写入 credentials。
      remoteReady.then(async () => {
        try {
          const params = new URLSearchParams(window.location.search)
          const accountId = params.get('dshrouter-account') ?? ''
          const token = params.get('dshrouter-token') ?? ''
          if (!accountId || !token) return
          window.history.replaceState(null, '', window.location.pathname)
          const routerRemote = ctx.get('remote.router')
          if (!routerRemote) return
          const response = await routerRemote.config({})
          if (!response.ok) return
          const configValue = response.value && response.value.value ? response.value.value : null
          const account = configValue && configValue.oauthAccounts ? configValue.oauthAccounts[accountId] : undefined
          if (!account || typeof account.tokenRef !== 'string' || !account.tokenRef) return
          const stored = await api.credentials.set({ ref: account.tokenRef, value: token })
          if (stored && stored.result && stored.result.ok) window.sessionStorage.setItem('dshrouter-token-saved', accountId)
        } catch { /* 静默：不影响页面加载 */ }
      })
      const $on = (event, listener) => ctx.remote.$on(event, listener)
      const injected = () => ({ api, health: remotes.health, remote: () => ctx.get('remote.router') ?? null, remoteReady, t, $on })
      ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: 'router-agents',
        order: 20,
        label: () => t('nav'),
        inject: injected,
      }, (props) => el(AgentsPage, {
        api: props.api,
        health: props.health,
        remote: props.remote,
        remoteReady: props.remoteReady,
        t: props.t,
        $on: props.$on,
      })))

      // ── 多模态展示辅助装配 ────────────────────────────────────────────
      const routerRemote = () => ctx.get('remote.router') ?? null
      const conversationFace = () => ctx.get('conversation')
      // 目录轮询：供 composer 附件按钮判定视觉 agent 可用性。
      const refreshCatalog = () => {
        const remote = routerRemote()
        if (!remote || typeof remote.catalog !== 'function') return
        remote.catalog({}).then((response) => {
          if (response && response.ok) setRouterCatalog(response.value ?? null)
        }, () => undefined)
      }
      refreshCatalog()
      remoteReady.then(() => refreshCatalog(), () => undefined)
      // ARCH-004 B5（D1-8 / §4.3 域 4）：事件订阅挂 events 域镜像（与设置页
      // settings/document-updated 订阅聚合同一共享 listener）；30s timer 保留
      // 为兜底（单 timer，D1-8 裁决——事件驱动 + 兜底轮询）。
      const disposeCatalogEvents = subscribeClientEvents($on, [{ event: 'settings/document-updated', consumer: 'composer-catalog', handler: () => refreshCatalog() }])
      const catalogTimer = window.setInterval(refreshCatalog, 30000)
      ctx.effect(() => () => {
        disposeCatalogEvents()
        window.clearInterval(catalogTimer)
      }, 'dsh-agent-router: composer catalog polling')
      // ── FIX-026：预设切换显示刷新——客户端直驱模型目录重载 ────────────
      // 缺陷事实（EV-129）：服务端播种全对（fce2785a 四连切终态正确）而显示层
      // 不跟随——宿主模型目录的刷新源只有 llm/adapters-updated 与
      // settings/document-updated 两个远程事件（dsh-client-ui-model-selection
      // 的 ctx.remote.$on 订阅）加目录打开时 load()，预设切换三者皆不触发；
      // FIX-024 的服务端 ctx.emit('llm/adapters-updated') 在真机不可达（源码
      // 推演通过、真机实证失败——方法论教训已入档）。本修复走 FIX-012 已验证
      // 模式：客户端订阅 agent-preset/selected（dsh-api-remotes
      // API_REMOTE_FORWARDED_EVENTS 首项；$on 即
      // ctx.remote.$on），直接调宿主 modelDirectories 服务
      // （ModelDirectoryResolver，super(ctx, "modelDirectories") 注册，宿主
      // dsh-client-ui-model-selection 的 directoryFor 面）的 directoryFor(sessionId).load()——load 只读幂等
      // （generation === this.generation 守卫，宿主模型目录服务面）、从 session.models 重拉并写 store
      // 快照，composer 模型选择器经 uSES（useSyncExternalStore）订阅该 store
      // （宿主 directory.store.subscribe + ModelSelect 的 uSES 订阅）→ load 完成
      // 即显示更新；与新会话打开时组件 mount → load() 同构。FIX-026 范围
      // 追加（EV-132 真机反证 emit 链不可达 + 用户架构裁决 P5 单一路径）：
      // 服务端 preset-defaults.js 的 FIX-024 emit 死路径已删除——本订阅是
      // 唯一显示刷新路径（服务端防复活守卫见 tests/preset-defaults.mjs I 节）。
      const refreshSessionDirectory = (sessionId, agentPreset) => {
        // FIX-027 遥测（P8）：handler 每次触发的结果结构化 console 上行——前缀
        // dsh-agent-router[FIX-027]，含结果/解析形态/preset/sessionId，用户 F12
        // 可见。服务端上行面待后续任务（现有 remote.router 方法均有语义，
        // 不为遥测新造 RPC 面拆分职责）。
        const telemetry = (result, detail) => {
          const line = `dsh-agent-router[FIX-027] preset switch model directory refresh: ${result} (preset ${agentPreset}, session ${sessionId}${detail ? `, ${detail}` : ''})`
          if (result === 'load') console.info(line)
          else console.warn(line)
        }
        try {
          // 主路径双形态解析（FIX-027）：规范 ctx.get 优先，属性面兜底——注入
          // 声明后两形态都应可用，双形态防御注册面差异（agentPresetsServiceOf
          // 先例——EVO-022 B4 F-1 归属勘正后唯一实现在 host-abi ctx-services
          // 域，属性面优先镜像形态；宿主自身经 scope.modelDirectories 属性面
          // 消费，model-selection 的 scope.modelDirectories 属性面）。
          const viaGet = ctx.get('modelDirectories')
          const directoryService = viaGet !== undefined ? viaGet : ctx.modelDirectories
          const directory = directoryService?.directoryFor?.(sessionId)
          if (directory && typeof directory.load === 'function') {
            // 只读幂等刷新（宿主语义：失败保留上次好状态并写 store.error）——
            // 多次触发无害；拒绝仅意味着显示不更新（插件层无重试面，不放大）。
            Promise.resolve(directory.load()).catch(() => undefined)
            telemetry('load', `form ${viaGet !== undefined ? 'ctx.get' : 'ctx.modelDirectories'}`)
            return
          }
          // 保底路径（modelDirectories 服务面不可达）：退化为一次
          // session.models RPC——仅维持可观测（证明订阅与分发链路活着），不
          // 更新显示（主路径是上面的 directory.load() 直驱 store 快照）。
          telemetry('fallback-rpc', 'modelDirectories service unavailable')
          Promise.resolve(api.sessions?.models?.({ sessionId })).catch(() => undefined)
        } catch (error) {
          // directoryFor 对无 scope/subagent 会话可能同步 throw（宿主
          // dsh-client-ui-model-selection 的 directoryFor「resolved no scope」；subagent 的 load 拒绝形态
          // 经上方 catch 容错）——warn 级可观测（P8），绝不破坏预设切换本身。
          telemetry('error', `caught ${error && error.message ? error.message : String(error)}`)
        }
      }
      const disposePresetSelected = subscribeClientEvents($on, [{ event: 'agent-preset/selected', consumer: 'preset-switch-directory-refresh', handler: (sessionId, agentPreset) => refreshSessionDirectory(sessionId, agentPreset) }])
      ctx.effect(() => () => {
        disposePresetSelected()
      }, 'dsh-agent-router: preset switch directory refresh')
      // conversation 插槽由 ui-conversation 声明：声明存在才注册，注册失败
      // （如 key 冲突）只记录、绝不击穿插件其余功能（settings 页等不受影响）。
      const safeRegister = (options, render) => {
        try {
          return ctx.slots.register(options, render)
        } catch (error) {
          console.error(`dsh-agent-router: slot "${options.name}" registration failed`, error)
          return () => {}
        }
      }
      ctx.slots.inject('conversation.input.right', () => safeRegister({
        name: 'conversation.input.right',
        id: 'router-attach',
        order: 50,
        inject: () => ({ router: routerRemote, conversation: conversationFace }),
      }, (props) => el(AttachButton, {
        t,
        router: props.router,
        conversation: props.conversation,
        inputActions: props.inputActions,
        useInput: props.useInput,
        // ARCH-005 A4：sessionId 透传（createDrafts(sessionId, files) 必需——
        // 宿主 conversation.input.right 域按会话传递，sessionId=undefined 时宿主
        // 不渲染本槽位〔renderSlot 守卫〕，透传值恒非空；守卫仍留缺面降级）。
        sessionId: props.sessionId,
      })))
      // EVO-012 批二 C：会话产物集合视图入口（输入区「本会话图片」按钮；空态
      // 不渲染）。同样注入 sessionId（宿主 input.right 域按会话传递）。
      ctx.slots.inject('conversation.input.right', () => safeRegister({
        name: 'conversation.input.right',
        id: 'router-session-gallery',
        order: 30,
        inject: () => ({}),
      }, (props) => el(SessionGallery, {
        t,
        sessionId: props.sessionId,
      })))
      // 模型接管（无 UI）：与附件按钮同一槽位、独立条目，随 InputZone 快照驱动。
      // FIX-029-B 事故根因补漏：装配点此前只透传 props.input（新宿主恒
      // undefined——探针实测 input=undefined/useInput=function），组件内
      // useInput 消费修复被装配层短路——useInput 必须透传（组件内双形态
      // 兼容保持，旧宿主 props.input 形态仍回落）。
      // FIX-048：conversation 必须透传（组件 kind 解析面来源——conversationFace
      // = () => ctx.get('conversation')，宿主 ConversationController 以
      // `conversation` 名注册的 resolveDraftAttachments 面；AttachButton 槽位
      // 同款 inject 先例）。漏透传 = 组件恒走方案 B 保守回落（file-only 亦武装）。
      // FIX-049：router 必须透传（组件按需能力刷新面来源——routerRemote =
      // () => ctx.get('remote.router')，AttachButton/RouteAgentToolCard 同款
      // inject 先例）。漏透传 = 组件无刷新面 → 漂移窗口内恒走保守切换（误切
      // twin 复发，FIX-029-B 同型装配事故面；tests/fix-012 D49-0 源码级守卫）。
      ctx.slots.inject('conversation.input.right', () => safeRegister({
        name: 'conversation.input.right',
        id: 'router-model-takeover',
        order: 40,
        inject: () => ({ api, conversation: conversationFace, router: routerRemote }),
      }, (props) => el(ModelTakeover, {
        sessionId: props.sessionId,
        input: props.input,
        useInput: props.useInput,
        api: props.api,
        conversation: props.conversation,
        router: props.router,
      })))
      ctx.slots.inject('tool.call.toolview', () => safeRegister({
        name: 'tool.call.toolview',
        key: 'route_agent',
        inject: () => ({ router: routerRemote }),
      }, (props) => el(RouteAgentToolCard, {
        t,
        router: props.router,
        block: props.block,
      })))
    }

    exports.apply = apply
    exports.inject = inject
    // FIX-012 判别测试钩子：ModelTakeover 组件与目录写入面直驱（宿主运行时
    // 仅消费 apply/inject；tests/fix-012-image-takeover.mjs 经 setRouterCatalog
    // 模拟 catalog 快照变化并渲染组件断言接管/还原行为）。
    exports.ModelTakeover = ModelTakeover
    // ARCH-004 B2 判别测试钩子：createClientRemotes 浏览器镜像直驱（宿主运行
    // 时仅消费 apply/inject；tests/host-abi-health.mjs §7 经本导出与权威单点
    // lib/host-abi/client-remotes.js 做行为 parity 断言——镜像漂移即红）。
    exports.createClientRemotes = createClientRemotes
    // ARCH-004 B5 判别测试钩子：events 域浏览器镜像（转发白名单 + 共享订阅）
    // 与 HostHealthCard 渲染面直驱（宿主运行时仅消费 apply/inject；tests/
    // host-abi-health.mjs §9e/§9g 经本导出与权威单点做值/行为 parity 断言——
    // 镜像漂移即红；HostHealthCard 导出兼供 F-6 faces 去重行为断言）。
    exports.FORWARDED_EVENT_ALLOWLIST = FORWARDED_EVENT_ALLOWLIST
    exports.subscribeClientEvents = subscribeClientEvents
    exports.HostHealthCard = HostHealthCard
    // FIX-046 返工判别测试钩子：`$mount` 描述符集合直出（宿主运行时只消费
    // apply/inject；tests/rpc-shadow-guard.mjs 经本导出与服务端 lib/rpc.js 的
    // ROUTER_DESCRIPTORS 做**双侧 id 集合 + codec 等价**断言——单侧增删即红，
    // P5「同一动作单一事实源」的机器落地）。
    exports.ROUTER_REMOTE = ROUTER_REMOTE
    exports.setRouterCatalog = setRouterCatalog
    exports.mergePresetModels = mergePresetModels
    // FIX-031 判别钩子：统计显示层单点（浏览器面归一化镜像）。宿主运行时只消费
    // apply/inject；tests/fix-031-attribution.mjs G 组直接驱动这三个函数与服务端
    // lib/stats.js 权威单点做值 parity 断言（双面漂移 = 该组红，P-v3 原则 9）。
    exports.accountDisplayKeyOf = accountDisplayKeyOf
    exports.agentDisplayKeyOf = agentDisplayKeyOf
    exports.statsProviderLabelOf = statsProviderLabelOf
    // D10（微批 8）：roster 构建真函数导出（判别测试直驱——twin 目录条目
    // 排除的行为锁；产品运行零额外占用）。
    exports.buildAccountNames = buildAccountNames
    // EVO-012 批二 C 判别测试钩子：清空会话产物表（渲染测试跨块隔离；产品
    // 运行零占用——模块级状态只被 addSessionProduct/SessionGallery 读写）。
    exports.resetSessionGallery = () => {
      sessionGallery.map.clear()
      sessionGallery.activeId = ''
    }
    return module.exports
  },
})
