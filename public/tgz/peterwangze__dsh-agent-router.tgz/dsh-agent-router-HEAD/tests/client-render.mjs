/**
 * 客户端 UI 真实渲染测试：在 Node 里用迷你 React 驱动 lib/client.js
 * （浏览器包，window.__ModuleLoader__ 格式）完整渲染「Agent 路由」设置页，
 * 对渲染出的元素树做结构断言——覆盖宿主侧单测够不到的两类回归：
 * - 界面结构错误（如圆点组件里塞文字、按钮行错乱）；
 * - cli 卡片的「测试 → 登录」替换与登录状态指示。
 *
 * 迷你 React 只实现 useState/useEffect/useCallback/useRef + 路径化的
 * 组件实例帧 + 脏标记重渲染循环，足以走完 load()→ready→自动状态探测
 * 的完整状态流（effects 按 deps 语义去重，避免无限循环）。
 * @module dsh-agent-router/tests/client-render
 */

export async function runClientRender(check) {
  const { readFileSync } = await import('node:fs')
  const { join, dirname } = await import('node:path')
  const { fileURLToPath } = await import('node:url')
  const source = readFileSync(join(dirname(fileURLToPath(import.meta.url)), '..', 'lib', 'client.js'), 'utf8')

  // ── 迷你 React 运行时 ──────────────────────────────────────────────────
  const instances = new Map()
  const frameStack = []
  let dirty = false
  let renderErrors = []
  const currentFrame = () => frameStack[frameStack.length - 1]

  function createElement(type, props, ...children) {
    const flat = []
    for (const child of children.flat(Infinity)) {
      if (child === null || child === undefined || child === false || child === true) continue
      flat.push(child)
    }
    const element = { type, props: { ...(props ?? {}) } }
    if (flat.length > 0) element.props.children = flat
    return element
  }

  function arraysEqual(a, b) {
    if (a === b) return true
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false
    for (let index = 0; index < a.length; index++) {
      if (!Object.is(a[index], b[index])) return false
    }
    return true
  }

  /** 取当前帧的 hook 槽位（首次访问时初始化为空对象）。 */
  const hookSlot = (index) => {
    const inst = currentFrame()
    let value = inst.hooks[index]
    if (!value) value = inst.hooks[index] = {}
    return value
  }

  function useState(initial) {
    const inst = currentFrame()
    const slot = hookSlot(inst.hookIndex++)
    if (!slot.has) {
      slot.has = true
      slot.value = typeof initial === 'function' ? initial() : initial
    }
    const setter = (value) => {
      const next = typeof value === 'function' ? value(slot.value) : value
      if (Object.is(next, slot.value)) return
      slot.value = next
      dirty = true
    }
    return [slot.value, setter]
  }

  function useEffect(fn, deps) {
    const inst = currentFrame()
    const slot = hookSlot(inst.hookIndex++)
    slot.fn = fn
    inst.effects.push(slot)
    if (slot.deps === undefined || !arraysEqual(slot.deps, deps)) {
      slot.deps = deps
      slot.pending = true
    } else {
      slot.pending = false
    }
  }

  function useCallback(fn, deps) {
    const inst = currentFrame()
    const slot = hookSlot(inst.hookIndex++)
    if (slot.has && arraysEqual(slot.deps, deps)) return slot.value
    slot.has = true
    slot.deps = deps
    slot.value = fn
    return fn
  }

  function useRef(value) {
    const inst = currentFrame()
    const slot = hookSlot(inst.hookIndex++)
    if (!slot.has) {
      slot.has = true
      slot.value = { current: value }
    }
    return slot.value
  }

  const react = { createElement, useState, useEffect, useCallback, useRef }

  function callComponent(type, props, pathKey) {
    let inst = instances.get(pathKey)
    if (!inst) {
      inst = { hooks: [], hookIndex: 0, effects: [] }
      instances.set(pathKey, inst)
    }
    inst.hookIndex = 0
    inst.effects = []
    frameStack.push(inst)
    let result
    try {
      result = type(props)
    } catch (error) {
      renderErrors.push(error)
      result = null
    }
    frameStack.pop()
    for (const slot of inst.effects) {
      if (!slot.pending) continue
      try {
        slot.fn()
      } catch (error) {
        renderErrors.push(error)
      }
    }
    return result
  }

  function walk(node, pathKey) {
    if (node === null || node === undefined) return null
    if (typeof node === 'string' || typeof node === 'number') return String(node)
    if (Array.isArray(node)) return node.map((child, index) => walk(child, `${pathKey}.${index}`)).filter((value) => value !== null)
    if (typeof node.type === 'function') return walk(callComponent(node.type, node.props, pathKey), pathKey)
    const children = node.props.children === undefined ? [] : Array.isArray(node.props.children) ? node.props.children : [node.props.children]
    return {
      type: node.type,
      props: node.props,
      children: children.map((child, index) => walk(child, `${pathKey}.${index}`)).filter((value) => value !== null),
    }
  }

  let rootElement = null
  let currentTree = null
  let walkPrefix = 'root'
  async function settle(maxTurns = 40) {
    for (let turn = 0; turn < maxTurns; turn++) {
      if (dirty) {
        dirty = false
        renderErrors = []
        currentTree = walk(rootElement, walkPrefix)
      }
      await new Promise((resolve) => setImmediate(resolve))
      if (!dirty) {
        await new Promise((resolve) => setImmediate(resolve))
        if (!dirty) return currentTree
      }
    }
    return currentTree
  }
  /** 换一棵组件树渲染（独立实例路径，避免与设置页共享 hook 槽位）。 */
  async function renderInto(element, prefix, maxTurns = 40) {
    rootElement = element
    walkPrefix = prefix
    dirty = true
    return settle(maxTurns)
  }

  // ── 装配：评估浏览器包 → mock ctx → apply → 渲染 ─────────────────────
  const captured = { registrations: [], listeners: [], effectCleanups: [], uploadFileCalls: [], readWorkspaceFileCalls: [], saveOps: [], oauthLogoutCalls: [], beginCalls: [], openCalls: [], statsExportCalls: [], credUnsetCalls: [], timers: [], documentListeners: [] }
  // EVO-023（B5）轮询治理判别面：2s 轮询 tick 由 captured.timers 手动驱动
  //（fakeWindow.setInterval 记录 fn/ms），document.hidden 可切换以判别
  //「页面隐藏零 RPC」；pollRpc 计数 stats/presetDiag 双 RPC 同拍与频率。
  const pollRpc = { stats: 0, presetDiagnostics: 0 }
  const fakeWindow = {
    __ModuleLoader__: { load: (payload) => { captured.bundle = payload } },
    location: { search: '', pathname: '/' },
    history: { replaceState: () => {} },
    sessionStorage: { getItem: () => null, setItem: () => {}, removeItem: () => {} },
    setInterval: (fn, ms) => { captured.timers.push({ fn, ms, cleared: false }); return captured.timers.length },
    clearInterval: (id) => { const timer = captured.timers[id - 1]; if (timer) timer.cleared = true },
    // D1-10 治理面：页面隐藏暂停经 window.document.hidden + visibilitychange
    //（浏览器真实形态；宿主 bundle 只经 window 取面）。
    document: {
      hidden: false,
      addEventListener: (type, handler) => { captured.documentListeners.push({ type, handler }) },
      removeEventListener: () => {},
    },
    // 登录轮询依赖 setTimeout 真正回调（忽略延迟立即排队），否则轮询挂死。
    setTimeout: (fn) => { setImmediate(fn); return 0 },
    clearTimeout: () => {},
    confirm: () => confirmMode,
    open: (url) => { captured.openCalls.push(String(url)); return { closed: true } },
    // F11 附件上传（Step 8）：AttachButton 经 FileReader 读字节 → base64 →
    // router/uploadFile RPC。测试用假 FileReader（与真实浏览器同构：readAsDataURL
    // 产出 data: URL，onload 异步回调）；文件字节由夹具的 _base64 字段提供。
    FileReader: class {
      readAsDataURL(file) {
        const base64 = typeof file._base64 === 'string' && file._base64 ? file._base64 : 'aGk='
        this.result = `data:${file.type || 'application/octet-stream'};base64,${base64}`
        queueMicrotask(() => { if (typeof this.onload === 'function') this.onload() })
      }
    },
    // L3 打开文件预览（Step 9）：blob URL 由宿主浏览器 API 提供——测试打桩。
    URL: { createObjectURL: () => 'blob:mock-preview', revokeObjectURL: () => {} },
  }
  new Function('window', source)(fakeWindow)
  check('client bundle evaluates', !!captured.bundle && captured.bundle.id === 'dsh-agent-router' && typeof captured.bundle.factory === 'function')
  const bundleExports = captured.bundle.factory((name) => {
    if (name === 'react') return react
    throw new Error(`unexpected require: ${name}`)
  })
  check('client exports apply/inject', typeof bundleExports.apply === 'function' && Array.isArray(bundleExports.inject))

  // cli 登录状态可切换：'ok' = 已登录；'logged-out' = 未登录（Not logged in）。
  // 登录轮询、刷新状态与未登录红色提示的回归断言共用。
  let cliStatusMode = 'ok'
  // 目录形态可切换：'withVision' = 识别+生图；'drawOnly' = 仅生图 agent；
  // 'none' = 无任何多模态 agent（附件按钮隐藏、接管解除）。
  let catalogMode = 'withVision'
  // FIX-002-R7 F3：接管开关可切换（catalog.takeoverDefaultModel 镜像值）——
  // 默认 true 维持既有接管断言语义；false 供"开关关闭"判别双断言组。
  let takeoverSwitch = true
  // EVO-002 Step 6 → EVO-006 转正：ChatGPT 订阅登录分区（正式通道——EVO-006
  // 起 config 无实验开关键），presetMode 控制目录 preset 账号形态
  // （'none'|'logged-out'|'logged-in'），confirmMode 控制登出/删除确认对话
  // （decline 判别）。
  let presetMode = 'none'
  let confirmMode = true
  // EVO-004 R8-F1（P2）：非成员 preset 值账号判据统一——未知 preset（'zzz'）
  // 必须回落到通用 OAuth 卡（旧：宽判据排除 + 预设卡严格成员 → UI 黑箱 +
  // 删除死锁）。true 时 catalog 注入一个 preset:'zzz' 的散账号。
  let unknownPresetMode = false
  // FIX-015：统计聚合键幽灵卡判别——true 时 stats.accountTotals 注入
  // oauth:chatgpt（服务端 OAuth 调用统计 provider 键）；旧代码将其并入
  // addedAccounts/statsAccountRows 渲染出通用 API Key 假编辑器（用户实证）。
  let oauthGhostMode = false
  // FIX-019：换马甲幽灵卡判别（用户实证 2026-08-31 红字「又出现了」）——
  // EVO-010 起主模型经插件路由（lib/oauth-llm.js OAUTH_PROVIDER）的调用统计
  // provider 键为无冒号路由 id 'chatgpt-oauth'，FIX-015 的 `oauth:` 前缀判据
  // 不覆盖 → 旧代码仍并入账号卡（实测形态：已激活 · 0 个模型 · 调用 18 ·
  // 119.1K/1.0K · 展开 = 通用 API Key 假编辑器）。true 时 stats.accountTotals
  // 额外注入 chatgpt-oauth（与 oauthGhostMode 并存 = 两种键同时存在）。
  let oauthRouteGhostMode = false
  // FIX-019 追加（用户 ⑤ 确认截图 sha256:9fa0908e）：宿主官方 openai-codex
  // 路由条目（EVO-010 由插件维护进 llm-pi-ai settings，lib/host-route.js
  // HOST_ROUTE_PROVIDER）在宿主 llm 目录暴露为**真 provider**（active、7 个
  // 模型来自宿主官方目录、调用 0）——不是统计键，无法靠「不在 providers 里」
  // 过滤，须显式排除。true 时 apiMock 注入该 provider 条目 + 同名 models 组。
  let hostRouteGhostMode = false
  // FIX-015 修 3：true 时 logged-in 的 ChatGPT 账号模型列表为空（主 agent 选择器
  // 不会出现该账号——订阅卡须明示，旧代码无提示必败）。
  let presetEmptyModelsMode = false
  // EVO-002 Step 7（R7-F4 判别）：true 时 remoteMock.oauthLogout 返回
  // ok:false（store.delete 失败形态——凭据文件残留 + 无重试入口的旧行为判别）。
  let logoutFailMode = false
  // F11 上传失败模式：true 时 remoteMock.uploadFile 返回 ok:false（错误码形状）。
  let uploadFailMode = false
  // L3 打开文件失败模式（Step 9）：true 时 remoteMock.readWorkspaceFile 返回
  // ok:false（错误码形状）；mediaType 按路径扩展名派生（audio/video/doc）。
  let readFileFailMode = false
  // EVO-013：预设 Agent 卡片——roster 模式（'ok'|'fail'，fail = 宿主 RPC
  // 失败形态）与 config.presets 夹具（可变对象，EVO-013 块内按场景注入）。
  let presetRosterMode = 'ok'
  const configPresets = {}
  // FIX-046 判别面：hostFaceDiagnostics 的宿主面形态开关——
  // 'ok' 正常取数 / 'absent' 方法缺失（浏览器侧挂载列表或宿主命名空间未提供该方法）/
  // 'throw' 调用被拒 / 'notOk' 宿主失败信封 / 'noVersions' 结果缺 hostVersions /
  // 'plain' 响应非信封对象（结果形状非法）/ 'withEntries' 成功且 faces/diag 非空
  // （FIX-047 F-10：codec 形状面）。
  // 形态锚定（P10-④）：**本仓权威面** = lib/service.js 的 `hostFaceDiagnostics()`
  // 供数方法与其返回的三键形状（hostVersions/faces/diag）+ lib/schemas.js 导出的
  // `hostFaceDiagnosticsResult`（face 条目 `faceHealthCodec`、diag 条目
  // `hostDiagEntryCodec`）；失败信封 `{ ok:false, error:{ code, message } }` 与本仓
  // 既有同型用例一致（tests/host-abi-health.mjs 的 `{ok:false,error:{code}}` 面）。
  // **FIX-047 N-4**（锚卫生）：上列锚原为「文件 + 行号区间」式，行号漂移后无判据
  // 看护 ⇒ 按仓库既有卫生方向（FIX-040/043/044）改**符号名式**（文件 + 导出名）。
  // **R0 F-6 勘正**：此前该处登记「宿主
  // dsh-api-gateway `assertExactArguments` wire 对齐拒绝 = 真机定因」——该断言
  // 已被真机证据证伪（EV-216：真机 `router/stats` RPC 成功；EV-217：真机定因为
  // 客户端 `$mount` 缺 descriptor），本夹具不锚定该形态，仅按本仓信封形状判别。
  let hostFaceMode = 'ok'
  // FIX-047（F-16，R0 P3）：stats 轮询失败形态开关——判别「静默吞错 → 诊断环
  // 机录」（唯一变量；默认 false 维持既有 stats 成功基线）。
  let statsFailMode = false
  // F-5：remote.router 命名空间整体缺失形态（旧实现静默吞错；本批须显式诊断）。
  let remoteAbsentMode = false
  const remoteMock = {
    catalog: async () => ({
      ok: true,
      value: {
        ok: true, enabled: true, takeoverDefaultModel: takeoverSwitch, defaults: { provider: 'deepseek-official', model: 'deepseek-v4-pro' },
        agents: catalogMode === 'drawOnly'
          ? [
            { id: 'draw', name: '画图', type: 'image', enabled: true, description: 'd', capabilities: ['image'], provider: 'openai', model: 'dall-e-3', account: '', effectiveProvider: 'openai', effectiveModel: 'dall-e-3', source: 'agent' },
          ]
          : catalogMode === 'none'
            ? [
              { id: 'plain', name: '纯文本', type: 'chat', enabled: true, description: 'd', capabilities: [], provider: 'openai', model: 'gpt-4o', account: '', effectiveProvider: 'openai', effectiveModel: 'gpt-4o', source: 'agent' },
            ]
            : [
              { id: 'codex', name: 'Codex 助手', type: 'cli', enabled: true, description: 'd', capabilities: ['image'], provider: '', model: '', account: '', cliAgent: 'codexentry', effectiveProvider: 'cli:codexentry', effectiveModel: '', source: 'agent' },
              { id: 'vision', name: '视觉', type: 'chat', enabled: true, description: 'd', capabilities: ['image'], provider: '', model: '', account: '', effectiveProvider: 'deepseek-official', effectiveModel: 'deepseek-v4-pro', source: 'main' },
            ],
        oauthAccounts: presetMode === 'none' && !unknownPresetMode ? [] : [
          { id: 'chatgpt', name: 'ChatGPT', enabled: true, protocol: 'codex-responses', baseURL: 'https://chatgpt.com/backend-api', tokenRef: '', clientId: '', authUrl: '', tokenUrl: '', scope: '', models: presetEmptyModelsMode ? [] : ['gpt-5.4-mini'], publicClient: false, preset: 'chatgpt-codex', presetLoggedIn: presetMode === 'logged-in' },
          // F-1（EVO-007 R0 返工）夹具：weird = 未知 preset 值账号（R8-F1 场景，
          // 入池——验证池行删除）；stray = 无 preset 非 preset 孤儿账号（未入池——
          // 验证高级扩展区孤儿列表删除兜底）。
          ...(unknownPresetMode ? [
            { id: 'weird', name: '怪异账号', enabled: true, protocol: 'openai-completions', baseURL: '', tokenRef: 'ROUTER_OAUTH_WEIRD_TOKEN', clientId: '', authUrl: '', tokenUrl: '', scope: '', models: [], publicClient: false, preset: 'zzz' },
            { id: 'stray', name: '散落账号', enabled: true, protocol: 'openai-completions', baseURL: '', tokenRef: 'ROUTER_OAUTH_STRAY_TOKEN', clientId: '', authUrl: '', tokenUrl: '', scope: '', models: [], publicClient: false },
          ] : []),
        ],
        pools: presetMode === 'none'
          ? (unknownPresetMode ? [
            { id: 'main', name: '主池', enabled: true, strategy: 'healthy', accounts: ['weird'], accountHealth: [] },
          ] : [])
          : [
            { id: 'main', name: '主池', enabled: true, strategy: 'healthy', accounts: ['chatgpt'], accountHealth: [] },
          ], cliAgents: [
          { id: 'codexentry', name: 'Codex 子代理', enabled: true, command: 'codex', args: '', timeoutMs: 0, maxConcurrent: 1 },
        ],
      },
    }),
    config: async () => ({ ok: true, value: { ok: true, enabled: true, revision: 1, writable: true, value: {
      enabled: true,
      agents: {
        codex: { name: 'Codex 助手', type: 'cli', enabled: true, description: 'd', capabilities: ['image'], command: '', args: '', timeoutMs: 0, maxConcurrent: 1, cliAgent: 'codexentry' },
        vision: { name: '视觉', type: 'chat', enabled: true, description: 'd', capabilities: ['image'], provider: '', model: '', maxRounds: 1 },
      },
      oauthAccounts: {},
      pools: {},
      presets: configPresets,
      cliAgents: {
        codexentry: { name: 'Codex 子代理', enabled: true, command: 'codex', args: '', timeoutMs: 0, maxConcurrent: 1, loginArgs: '', statusArgs: '', modelsArgs: '' },
      },
    }, user: null } }),
    stats: async () => {
      pollRpc.stats += 1
      // FIX-047（F-16）：stats 轮询失败形态（唯一变量开关）——判别「静默吞错 →
      // 诊断环机录」。
      if (statsFailMode) throw new Error('stats gateway rejected (FIX-047 F-16 fixture)')
      return ({ ok: true, value: { ok: true, enabled: true, totals: [], recent: [], series: [], accountTotals: [
      ...(oauthGhostMode ? [{ provider: 'oauth:chatgpt', name: 'ChatGPT 订阅', calls: 3, errors: 0, inputTokens: 13200, outputTokens: 4800, totalMs: 0, lastAt: undefined }] : []),
      ...(oauthRouteGhostMode ? [{ provider: 'chatgpt-oauth', name: 'ChatGPT 订阅', calls: 18, errors: 0, inputTokens: 119100, outputTokens: 1000, totalMs: 0, lastAt: undefined }] : []),
    ], accountSeries: [], days: {
      '2026-01-15': { calls: 3, errors: 1, inputTokens: 110, outputTokens: 50, tokens: 160, ms: 180, cost: 0.5 },
      '2026-01-16': { calls: 2, errors: 0, inputTokens: 20, outputTokens: 0, tokens: 20, ms: 60, cost: 0 },
    } } }) },
    // EVO-023（B5）：presetDiag 随 2s 轮询同拍拉取（FIX-030-C 观测面）——
    // 计数面供「双 RPC 同拍/隐藏态零 RPC」判别（既有用例零消费面）。
    presetDiagnostics: async () => { pollRpc.presetDiagnostics += 1; return { ok: true, value: { ok: true, enabled: true, entries: [] } } },
    // FIX-046：宿主面健康 RPC（真实形状 = lib/service.js hostFaceDiagnostics()
    // 三合一 { hostVersions, faces, diag }；faces 条目形状锚定 lib/schemas.js
    // faceHealthCodec、diag 条目锚定 hostDiagEntryCodec——宿主侧本仓权威面）。
    // 默认 'ok' 恒成功（非判别场景下维持「健康面板正常」基线，避免各用例
    // 被取数失败噪音污染）；失败形态由下方 FIX-046 判别组按需切换。
    // 未注入者 = 本夹具**无 hostFaceDiagnostics 方法**（方法缺失形态；真机 V-9
    // 实测该短码同形，成因见 EV-217 —— 挂载列表/命名空间两侧皆可能，不预设宿主
    // 单因；FIX-047 N-6 措辞中性化前写「旧服务端形态」）。
    hostFaceDiagnostics: async () => {
      if (hostFaceMode === 'throw') throw new Error('router gateway rejected hostFaceDiagnostics')
      if (hostFaceMode === 'notOk') {
        // 宿主失败信封（形状锚定见上方形态开关注释；非真机定因断言）。
        return { ok: false, error: { code: 'gateway/arguments-invalid', message: 'typert gateway: router/hostFaceDiagnostics: args fields do not match the descriptor: missing "request"' } }
      }
      if (hostFaceMode === 'withEntries') {
        // FIX-047（F-10，R0 P3）：非空示例条目——字段面取两侧同构的 codec 声明
        // （lib/schemas.js `faceHealthCodec`：name/state/detail；`hostDiagEntryCodec`：
        // at/kind/face/code/detail，code 语义 = 面状态变化后的新状态，与
        // lib/host-abi/health.js 的 face-state 条目同形）。`hostDiagEntryCodec` 的
        // `consumer` 为可选字段且卡片正文不渲染它 ⇒ 本夹具不带、本组不声称覆盖。
        // （codec 声明等价由 tests/rpc-shadow-guard.mjs 的深等判据看护；客户端渲染
        // 路径为手写判定、不经 codec——限定语见该守卫 N-5 段。）
        return { ok: true, value: {
          hostVersions: { llm: '9.9.9-a', tools: '8.8.8-b', typertProtocol: '7.7.7-c' },
          faces: [
            { name: 'host-probe-alpha', state: 'degraded', detail: 'face detail: codec 形状样例' },
            { name: 'host-probe-beta', state: 'ok' },
          ],
          diag: [
            { at: 1767225600000, kind: 'face-state', face: 'host-probe-alpha', code: 'degraded', detail: 'hostDiagEntryCodec 形状样例' },
          ],
        } }
      }
      if (hostFaceMode === 'noVersions') return { ok: true, value: { faces: [], diag: [] } }
      if (hostFaceMode === 'plain') return 'not-an-envelope'
      return { ok: true, value: {
        hostVersions: { llm: '9.9.9-a', tools: '8.8.8-b', typertProtocol: '7.7.7-c' },
        faces: [],
        diag: [],
      } }
    },
    statsExport: async (request) => { captured.statsExportCalls.push(request); return { ok: true, value: { ok: true, message: '已导出 2 行', csv: 'date,agent,account,model,calls,errors,inputTokens,outputTokens,p50ms,p95ms,costEstimate\n2026-01-15,vision,openai,gpt-4o,3,1,110,50,60,180,0.5' } } },
    save: async (request) => { captured.saveOps.push(...((request && request.ops) ?? [])); return { ok: true, value: { ok: true, revision: 1 } } },
    oauthBegin: async (request) => { captured.beginCalls.push(request); return { ok: true, value: { ok: true, message: '授权 URL 已生成', authUrl: 'https://auth.openai.com/oauth/authorize?x=1', state: 'st-6' } } },
    oauthLogout: async (request) => {
      captured.oauthLogoutCalls.push(request)
      return logoutFailMode
        ? { ok: true, value: { ok: false, message: '登出失败（删除凭据文件）：模拟磁盘错误' } }
        : { ok: true, value: { ok: true, message: '已登出并删除 ChatGPT 凭据文件' } }
    },
    reset: async () => ({ ok: true, value: { ok: true } }),
    test: async () => ({ ok: true, value: { ok: true, message: 'ok' } }),
    cliStatus: async () => cliStatusMode === 'logged-out'
      ? { ok: true, value: { ok: true, loggedIn: false, message: 'Not logged in' } }
      : { ok: true, value: { ok: true, loggedIn: true, message: '已登录' } },
    cliLogin: async () => ({ ok: true, value: { ok: true, message: '已在终端窗口启动' } }),
    cliModels: async () => ({ ok: true, value: { ok: true, message: '2 个模型', models: ['m1', 'm2'], source: 'cli' } }),
    imageData: async (request) => {
      captured.imageDataCalls.push(request)
      return { ok: true, value: { ok: true, message: 'ok', mediaType: 'image/png', data: 'aGk=', width: 2, height: 2 } }
    },
    uploadFile: async (request) => {
      captured.uploadFileCalls.push(request)
      if (uploadFailMode) return { ok: true, value: { ok: false, message: '文件超过大小上限', code: 'FILE_TOO_LARGE' } }
      return { ok: true, value: { ok: true, path: `.router-files/${request.name}`, attachmentId: `sha256:${'f'.repeat(64)}`, name: request.name } }
    },
    readWorkspaceFile: async (request) => {
      captured.readWorkspaceFileCalls.push(request)
      if (readFileFailMode) return { ok: true, value: { ok: false, message: '文件路径超出会话工作区', code: 'PATH_OUTSIDE_WORKSPACE' } }
      const path = String(request.path ?? '')
      const lower = path.toLowerCase()
      const mediaType = lower.endsWith('.mp4') ? 'video/mp4' : lower.endsWith('.doc') ? 'application/msword' : 'audio/wav'
      return { ok: true, value: { ok: true, dataBase64: 'aGVsbG8=', mediaType, name: path.split('/').pop() } }
    },
  }
  // 账号添加/编辑回归用记录：端点探测请求、llm-pi-ai 写入、凭据写入。
  // discoverMode 切 'fail' 模拟端点不可达（负向见证）。
  const discoverCalls = []
  const mutateCalls = []
  const credSetCalls = []
  let discoverMode = 'ok'
  // 模型接管面：会话当前选中 + 切换调用记录（视觉开→切包装组，关→切回）。
  let sessionCurrent = { provider: 'openai', model: 'gpt-4o' }
  const sessionSelectCalls = []
  // FIX-026：保底路径（session.models RPC）调用记录——主路径不可达时的
  // 可观测降级判别（保底仅维持可观测，不更新显示）。
  const sessionModelsCalls = []
  // FIX-026：模型目录服务面模式——'ok' 主路径（directoryFor→load）、
  // 'absent' 服务不可达（ctx.get 返回 undefined → 保底 RPC）、
  // 'throw' subagent 会话形态（directoryFor 同步 throw，宿主
  // dsh-client-ui-model-selection 的 directoryFor「resolved no scope」同型
  // ——防御断言：捕获不炸 + warn 可观测）。
  let modelDirectoriesMode = 'ok'
  const directoryForCalls = []
  const directoryLoadCalls = []
  const apiMock = {
    sessions: {
      // FIX-026：记录保底路径调用（载荷形参判别）——返回形状与既有断言一致。
      models: async (payload) => { sessionModelsCalls.push(payload && typeof payload === 'object' ? { ...payload } : payload); return { result: { ok: true, value: { current: { ...sessionCurrent }, routable: true, groups: [], failures: [] } } } },
      selectModel: async (payload) => {
        sessionSelectCalls.push({ ...payload })
        sessionCurrent = { provider: payload.provider, model: payload.model }
        return { result: { ok: true, value: { selected: { provider: payload.provider, model: payload.model } } } }
      },
    },
    llm: {
      providers: async () => ({ result: { ok: true, value: { providers: [
        { provider: 'openai', displayName: 'OpenAI', settingsNs: 'llm-pi-ai', settingsPath: ['providers', 'openai'], active: false, declared: false },
        { provider: 'gateway', displayName: 'Gateway', settingsNs: 'llm-pi-ai', settingsPath: ['providers', 'gateway'], active: true, declared: true },
        // FIX-019 追加：宿主官方 openai-codex 路由 = llm-pi-ai 真 provider（EVO-010
        // 插件维护进 settings；7 个模型来自宿主官方目录）。
        ...(hostRouteGhostMode ? [{ provider: 'openai-codex', displayName: 'OpenAI Codex 官方', settingsNs: 'llm-pi-ai', settingsPath: ['providers', 'openai-codex'], active: true, declared: false }] : []),
      ] } } }),
      models: async () => ({ result: { ok: true, value: { groups: [
        ...(hostRouteGhostMode ? [{ id: 'openai-codex', models: [1, 2, 3, 4, 5, 6, 7].map((index) => ({ id: `codex-m-${index}`, name: `Codex M${index}` })) }] : []),
        { id: 'gateway', models: [{ id: 'old-m', name: 'Old M' }] },
      ], failures: [] } } }),
      discoverModels: async (request) => {
        discoverCalls.push(request)
        if (discoverMode === 'fail') return { result: { ok: false, error: { message: 'could not reach https://gateway.example/v1/models' } } }
        return { result: { ok: true, value: { models: [{ id: 'm-a' }, { id: 'm-b', name: 'Model B', contextWindow: 65536, maxTokens: 4096 }] } } }
      },
    },
    settings: {
      describe: async () => ({ result: { ok: true, value: { namespaces: [{ ns: 'llm-pi-ai', value: { providers: { gateway: { api: 'openai-completions', baseURL: 'https://gateway.example/v1', models: [{ id: 'old-m', name: 'Old M' }] } } } }] } } }),
      mutate: async (payload) => {
        mutateCalls.push(payload)
        return { result: { ok: true } }
      },
    },
    // EVO-013 / FIX-022：宿主预设罗盘 RPC（roster 数据源；'fail' = 网关失败
    // 形态——客户端按可观测降级处理：错误提示 + 空列表，不阻塞整页）。
    // FIX-022：宿主客户端 api 面方法组名为复数 agentPresets（wire 方法名
    // agentPreset.list 是单数——宿主自身命名不一致陷阱，EV-123）；响应值含
    // presets/authorable/hasDocument 三字段（FIX-044 逐 schema 符号名重建）：`presets` 与 `authorable`
    // 锚定宿主 `_deepseek_ai_dsh_agent_presets_agentPresets_list_result$schema`；**`hasDocument` 不在该
    // schema 内**（宿主当前装态该字段属
    // `_deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema`，消费面 = 下方 settings.describe 夹具）。
    // fixture 仅提供复数域——旧实现（误调 api.agentPreset）对此必败（判别 RED）。
    agentPresets: {
      // R0 F-1：broken 用宿主真实形状——非空原因字符串（dsh-agent-presets
      // `AgentPreset.broken?: string`，zod min(1)；宿主不发 boolean false，健康
      // 条目直接省略该字段）。legacy-broken 条目保留 boolean true 历史形态，
      // 验证归一真值判定的双形态兼容。
      list: async () => presetRosterMode === 'fail'
        ? { result: { ok: false, error: { message: 'agentPreset gateway rejected' } } }
        : { result: { ok: true, value: { presets: [
          { id: 'governance', name: 'Governance 预设', trust: 'system' },
          { id: 'novel', name: '小说写作', trust: 'user' },
          { id: 'broken-one', name: '坏预设', trust: 'user', broken: 'composition missing' },
          { id: 'legacy-broken', name: '旧形态坏预设', trust: 'user', broken: true },
        ], authorable: true, hasDocument: false } } },
    },
    credentials: {
      describe: async () => ({ result: { ok: true, value: { credentials: {} } } }),
      set: async (payload) => { credSetCalls.push(payload); return { result: { ok: true } } },
      // F-1：记录删除账号时的凭据清理调用（assert tokenRef unset）。
      unset: async (payload) => { captured.credUnsetCalls.push(payload); return { result: { ok: true } } },
    },
  }
  // FIX-028：宿主 0.1.2-rc.1 客户端面夹具（dsh-api-remotes typed remote
  // 直面形状——作为 apply() 里 createClientRemotes 适配层（EVO-020/B2 起
  // hostApiFace 迁域更名：lib/host-abi/client-remotes.js 权威单点 + 本包
  // 浏览器镜像）的宿主面输入；数据与上方
  // 旧 apiMock 语义等价（providers=registered∪declared 连接 / models=
  // session.modelCatalog / discover 返回裸数组 / settings+credentials 位置
  // 参数）。形状锚定宿主 schema（dsh-api-remotes lib/client.js）——**逐 schema 符号名**式（FIX-044 按
  // 宿主只读实读逐条重建；原行号式 `L####` 锚实测部分漂移，判定与逐条对照见
  // `tests/host-abi-health.mjs` 本文件条目 `notes`）：
  //  · llm/listProviders result = `_deepseek_ai_dsh_llm_llm_listProviders_result$schema`、
  //    listConfigurableProviders result = `_deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema`、
  //    discoverModels(settingsNs, request) 参数 = `_deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema`
  //    / `_deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema` + 结果（裸数组）=
  //    `_deepseek_ai_dsh_llm_llm_discoverModels_result$schema`；
  //  · settings/describe result = `_deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema`、
  //    settings/mutate(ns, ops) 参数 = `_deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema`
  //    / `_deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema`
  //    / `_deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema`；
  //  · credentials/describe result = `_deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema`、
  //    set(ref, value) 参数 = `_deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema`
  //    / `_deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema`、
  //    unset(ref) 参数 = `_deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema`；
  //  · agentPresets/list result = `_deepseek_ai_dsh_agent_presets_agentPresets_list_result$schema`
  //    （含 isDefault 字段——宿主真实形状，R0 F-1 的 legacy-broken 双形态保留）；
  //  · session/modelCatalog result = `_deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema`、
  //    session/selectModel 参数 = `_deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema`
  //    / 结果 = `_deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema`。
  // p10：夹具按宿主源码形态锚定，禁止从旧 apiMock 心智模型外推。
  const missingFaces = new Set()
  const hostFaces = {
    llm: {
      listProviders: async () => ({ ok: true, value: [
        { id: 'gateway', name: 'Gateway' },
        ...(hostRouteGhostMode ? [{ id: 'openai-codex', name: 'OpenAI Codex 官方' }] : []),
      ] }),
      listConfigurableProviders: async () => ({ ok: true, value: [
        { provider: 'openai', displayName: 'OpenAI', settingsNs: 'llm-pi-ai', settingsPath: ['providers', 'openai'], declared: false },
        { provider: 'gateway', displayName: 'Gateway', settingsNs: 'llm-pi-ai', settingsPath: ['providers', 'gateway'], declared: true },
        ...(hostRouteGhostMode ? [{ provider: 'openai-codex', displayName: 'OpenAI Codex 官方', settingsNs: 'llm-pi-ai', settingsPath: ['providers', 'openai-codex'], declared: false }] : []),
      ] }),
      discoverModels: async (settingsNs, request) => {
        discoverCalls.push({ settingsNs, ...(request ?? {}) })
        if (discoverMode === 'fail') return { ok: false, error: { message: 'could not reach https://gateway.example/v1/models' } }
        return { ok: true, value: [{ id: 'm-a' }, { id: 'm-b', name: 'Model B', contextWindow: 65536, maxTokens: 4096 }] }
      },
    },
    settings: {
      describe: async () => ({ ok: true, value: { writable: true, hasDocument: true, namespaces: [
        { ns: 'llm-pi-ai', schema: null, value: { providers: { gateway: { api: 'openai-completions', baseURL: 'https://gateway.example/v1', models: [{ id: 'old-m', name: 'Old M' }] } } }, applies: 'live', secrets: [], revision: 1 },
      ] } }),
      mutate: async (ns, ops) => { mutateCalls.push({ ns, ops }); return { ok: true, value: { ns, schema: null, value: null, applies: 'live', secrets: [], revision: 2 } } },
    },
    credentials: {
      describe: async (refs) => ({ ok: true, value: Object.fromEntries((refs ?? []).map((ref) => [ref, { configured: false, writable: true }])) }),
      set: async (ref, value) => { credSetCalls.push({ ref, value }); return { ok: true, value: undefined } },
      unset: async (ref) => { captured.credUnsetCalls.push({ ref }); return { ok: true, value: undefined } },
    },
    agentPresets: {
      list: async () => presetRosterMode === 'fail'
        ? { ok: false, error: { message: 'agentPreset gateway rejected' } }
        : { ok: true, value: { presets: [
          { id: 'governance', name: 'Governance 预设', trust: 'system', isDefault: false },
          { id: 'novel', name: '小说写作', trust: 'user', isDefault: false },
          { id: 'broken-one', name: '坏预设', trust: 'user', isDefault: false, broken: 'composition missing' },
          { id: 'legacy-broken', name: '旧形态坏预设', trust: 'user', isDefault: false, broken: true },
        ], authorable: true } },
    },
    session: {
      modelCatalog: async () => ({ ok: true, value: { default: { provider: 'deepseek-official', model: 'deepseek-v4-pro' }, routableProviders: ['gateway'], groups: [
        ...(hostRouteGhostMode ? [{ id: 'openai-codex', models: [1, 2, 3, 4, 5, 6, 7].map((index) => ({ id: `codex-m-${index}`, name: `Codex M${index}` })) }] : []),
        { id: 'gateway', models: [{ id: 'old-m', name: 'Old M' }] },
      ], failures: [] } }),
      selectModel: async (payload) => {
        sessionSelectCalls.push({ ...payload })
        sessionCurrent = { provider: payload.provider, model: payload.model }
        return { ok: true, value: { selected: { provider: payload.provider, model: payload.model } } }
      },
    },
  }
  // FIX-026：modelDirectories 客户端服务 stub——宿主 ModelDirectoryResolver
  // （dsh-client-ui-model-selection 的 `super(ctx, "modelDirectories")` 注册；
  // directoryFor(sessionId) 惰性返回带 load() 的会话目录，load 为只读幂等刷新
  // ——ModelDirectory.load）。directoryFor 记录调用；'throw' 模式复刻宿主无
  // scope 会话的同步 throw 形态（宿主 directoryFor「resolved no scope」）。
  const modelDirectoriesStub = () => {
    if (modelDirectoriesMode === 'absent') return undefined
    return {
      directoryFor: (sessionId) => {
        directoryForCalls.push(sessionId)
        if (modelDirectoriesMode === 'throw') throw new Error(`ui-model-selection: session "${String(sessionId)}" resolved no scope`)
        return { load: async () => { directoryLoadCalls.push(sessionId); return { current: { ...sessionCurrent }, routable: true, groups: [], failures: [] } } }
      },
    }
  }
  // FIX-027：注入门控判据——模块 inject 声明列表决定可解析面（复刻真实
  // cordis 客户端形态；'remote.router' 的声明名是 'remote'——命名空间远程面
  // 挂在 remote 服务下）。'getMiss' 模式 = get 解析落空而属性面可用（隔离域/
  // 注入门控下裸 get 失败的 EV-134 嫌疑形态；双形态防御判别面——
  // agentPresetsServiceOf 先例，定义在 lib/host-abi/ctx-services.js）。
  const declaredService = (key) => Array.isArray(bundleExports.inject) && bundleExports.inject.includes(String(key).split('.')[0])
  let modelDirectoriesGetMiss = false
  const zh = {}
  const ctx = {
    // FIX-026：捕获装配清理函数（产品代码 ctx.effect(() => cleanup, label)）——
    // 「装配卸载 off 生效」判别需要真实可调用的卸载路径（旧 stub 丢弃 cleanup
    // 无法判别）；locale effect 的 fn 返回 undefined，不入列。
    effect: (fn) => { const cleanup = fn(); if (typeof cleanup === 'function') captured.effectCleanups.push(cleanup); return () => {} },
    locale: {
      register: (_ns, tables) => { Object.assign(zh, tables.zh) },
      bind: () => (key) => zh[key] ?? key,
    },
    // FIX-027：get 按注入门控解析——未声明名返回 undefined（EV-134 缺陷形态：
    // 旧 inject 不含 modelDirectories → 主路径裸解析落空 → 保底 RPC 只读不更新
    // 显示）。声明名且服务就绪才回 stub；'getMiss' 模式 = 声明在而 get 落空。
    get: (key) => {
      if (!declaredService(key)) return undefined
      if (key === 'remote.router') return remoteAbsentMode ? undefined : remoteMock
      if (missingFaces.has(key)) return undefined
      if (key === 'remote.llm') return hostFaces.llm
      if (key === 'remote.settings') return hostFaces.settings
      if (key === 'remote.credentials') return hostFaces.credentials
      if (key === 'remote.agentPresets') return hostFaces.agentPresets
      if (key === 'remote.session') return hostFaces.session
      if (key === 'modelDirectories') return modelDirectoriesGetMiss ? undefined : modelDirectoriesStub()
      return undefined
    },
    // FIX-027：属性面（宿主 cordis-client-runner：属性访问按 fiber.inject 声明
    // 门控的形态）——声明后才可见，双形态防御的兜底面；'absent' 模式（提供者
    // 未就绪）两形态皆 undefined（与真实服务未激活一致）。
    get modelDirectories() { return declaredService('modelDirectories') ? modelDirectoriesStub() : undefined },
    // FIX-026：$on 订阅带 active 标记——退订函数置 inactive，「卸载后派发不再
    // 触发」的判别基础；既有断言经 entry.listener 直调，不受影响。
    remote: { $mount: (contribution) => { captured.mount = contribution; return Promise.resolve() }, $on: (event, listener) => { const entry = { event, listener, active: true }; captured.listeners.push(entry); return () => { entry.active = false } } },
    slots: {
      inject: (_slot, register) => { captured.registrations.push(register()); return () => {} },
      register: (descriptor, renderFn) => ({ ...descriptor, render: renderFn }),
    },
  }
  bundleExports.apply(ctx)
  const registrationOf = (name) => captured.registrations.find((reg) => reg && reg.name === name)
  const settingsReg = registrationOf('settings.section')
  check('settings section registered', !!settingsReg && typeof settingsReg.render === 'function')
  check('composer image slots registered', !!registrationOf('conversation.input.right') && !!registrationOf('tool.call.toolview'))
  check('toolview keyed to route_agent', registrationOf('tool.call.toolview') && registrationOf('tool.call.toolview').key === 'route_agent')
  // 浏览器侧 Remote 契约必须与宿主 rpc.js 同步包含 cli 三方法与 imageData（曾漏加导致按钮全失效）。
  check('client remotes include cli methods', !!captured.mount && ['cliStatus', 'cliLogin', 'cliModels'].every((method) => (captured.mount.descriptors ?? []).some((descriptor) => descriptor.method === method)))
  check('client remotes include image methods', !!captured.mount && (captured.mount.descriptors ?? []).some((descriptor) => descriptor.method === 'imageData'))
  check('client remotes include uploadFile', !!captured.mount && (captured.mount.descriptors ?? []).some((descriptor) => descriptor.method === 'uploadFile' && descriptor.id === 'dsh-agent-router#router/uploadFile'))
  // FIX-046 返工验收（EV-217 根因）：观测面两条 MUST 进 `$mount` 列表——缺失时
  // 浏览器侧 `remote.router.hostFaceDiagnostics` 不存在（真机 host-face-shape：
  // 面板版本/诊断面被静默跳过）。此处判「挂载列表含该方法 + id 对齐」；与服务端
  // 集合的等价判据在 tests/rpc-shadow-guard.mjs（双侧 id 集合 + codec 深度等价）。
  check('client remotes include router observability methods (FIX-046: presetDiagnostics + hostFaceDiagnostics registered via $mount)',
    !!captured.mount && ['dsh-agent-router#router/presetDiagnostics', 'dsh-agent-router#router/hostFaceDiagnostics'].every((id) => (captured.mount.descriptors ?? []).some((descriptor) => descriptor.id === id && descriptor.method === id.split('/')[1])))
  rootElement = settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} })
  dirty = true
  currentTree = await settle()

  // ── 工具函数 ──────────────────────────────────────────────────────────
  const textOf = (node) => {
    if (node === null || node === undefined) return ''
    if (typeof node === 'string' || typeof node === 'number') return String(node)
    if (Array.isArray(node)) return node.map(textOf).join(' ')
    return (node.children ?? []).map(textOf).join(' ')
  }
  const findAll = (node, predicate, out = []) => {
    if (node === null || node === undefined) return out
    if (Array.isArray(node)) { for (const child of node) findAll(child, predicate, out); return out }
    if (predicate(node)) out.push(node)
    for (const child of node.children ?? []) findAll(child, predicate, out)
    return out
  }
  const hasClass = (node, token) => node && node.type && typeof node.props?.className === 'string' && node.props.className.includes(token)
  const buttonsOf = (tree) => findAll(tree, (node) => node && node.type === 'button')

  // ── 断言：渲染无异常 + 折叠摘要 ──────────────────────────────────────
  if (renderErrors.length > 0) {
    try {
      const { writeFileSync } = await import('node:fs')
      writeFileSync(join(dirname(fileURLToPath(import.meta.url)), '..', 'render-errors.txt'), renderErrors.map((error) => (error && error.stack ? error.stack : String(error))).join('\n---\n'))
    } catch { /* 调试输出失败忽略 */ }
  }
  check('client renders without errors', renderErrors.length === 0)
  check('client shows ready page', textOf(currentTree).includes(zh.agentsTitle))
  // 用户指令 2026-09-05：四张分类卡片统一默认折叠——专业 Agent 卡需先点击
  // 分类头（dshrouter-category-head）展开后再断言卡内内容（原默认展开直接
  // 可见的断言面随之调整）。
  const categoryHeadsOfInitial = () => findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head'))
  const agentsCategoryHead = categoryHeadsOfInitial().find((node) => textOf(node).includes(zh.agentsTitle))
  check('agents category collapsed by default (chevron ▸ + all four cards)', !!agentsCategoryHead && textOf(agentsCategoryHead).includes('▸'))
  if (agentsCategoryHead) {
    agentsCategoryHead.props.onClick()
    currentTree = await settle()
  }
  const heads = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-card-head'))
  check('agent cards rendered', heads.length >= 2)

  // ── 断言：cli 卡片展开 → 登录按钮替换测试按钮 + 状态指示 ─────────────
  const codexHead = heads.find((node) => textOf(node).includes('codex'))
  check('cli card head found', !!codexHead)
  if (codexHead) {
    codexHead.props.onClick()
    currentTree = await settle()
    const allButtons = buttonsOf(currentTree)
    const labels = allButtons.map(textOf)
    // 已登录状态显示「重新登录」，未登录显示「登录（打开终端窗口）」——
    // 两者都是登录语义；关键断言：cli 卡内不存在「测试」按钮。
    check('cli card login button replaces test', (labels.includes(zh.cliLogin) || labels.includes(zh.cliRelogin)) && !labels.includes(zh.test))
    check('cli card shows logged-in chip', textOf(currentTree).includes(zh.cliStatusLoggedIn))
    // 子代理是账号区条目：agent 卡片用「子代理」下拉选择，选项来自 cliAgents 目录。
    const selects = findAll(currentTree, (node) => node && node.type === 'select')
    check('cli card subagent select lists entries', selects.some((selectNode) => textOf(selectNode).includes('Codex 子代理') && textOf(selectNode).includes('codexentry')) && textOf(currentTree).includes(zh.fieldCliAgent))
    // 圆点组件绝不承载文字（此前 UI 错乱的根因）。
    const dots = findAll(currentTree, (node) => hasClass(node, 'dshrouter-dot'))
    check('status dots carry no text', dots.length > 0 && dots.every((dot) => (dot.children ?? []).every((child) => typeof child !== 'string')))
  }

  // ── 断言：chat 卡片展开 → 仍是「测试」按钮（其余类型不受影响）────────
  const visionHead = heads.find((node) => textOf(node).includes('vision'))
  check('chat card head found', !!visionHead)
  if (visionHead) {
    visionHead.props.onClick()
    currentTree = await settle()
    const labels = buttonsOf(currentTree).map(textOf)
    check('chat card keeps test button', labels.includes(zh.test))
  }

  // ── 断言：添加卡片模板是能力起点，不含 CLI 类别 ──────────────────────
  const addCards = findAll(currentTree, (node) => hasClass(node, 'dshrouter-add'))
  if (addCards.length > 0) {
    addCards[0].props.onClick()
    currentTree = await settle()
    const chipLabels = buttonsOf(currentTree).map(textOf)
    check('templates are capabilities, not cli categories', chipLabels.some((label) => label.includes(zh.presetVision)) && !chipLabels.some((label) => label.includes('Codex CLI 子代理') || label.includes('Claude Code 子代理') || label.includes('Gemini CLI 子代理')))
  }

  // ── 断言：子代理条目归入多模态账号区（可展开，含登录维护入口）；
  //    EVO-007 新布局：ChatGPT 订阅登录上移为一级醒目位（与子代理交换），
  //    OAuth 官方登录（插件独立管理）区块整块移除 ─────────────────────
  const accountsHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.accountTitle))
  check('accounts category head found', !!accountsHead)
  if (accountsHead) {
    accountsHead.props.onClick()
    currentTree = await settle()
    check('subagents live under accounts', textOf(currentTree).includes(zh.cliTitle) && textOf(currentTree).includes('codexentry'))
    // EVO-007-A：OAuth 官方登录区块（标题/文案/添加按钮/未配置态）零残留。
    check('oauth official-login block removed (EVO-007-A)', !textOf(currentTree).includes('官方登录，插件独立管理') && !textOf(currentTree).includes('添加 OAuth 账号'))
    // EVO-007-B：ChatGPT 订阅登录无需展开「高级扩展」即一级可见（标题/提示/
    // 添加入口/计数徽标），正式通道优先呈现。
    check('chatgpt section promoted to first level (EVO-007-B)', textOf(currentTree).includes(zh.presetTitle) && textOf(currentTree).includes(zh.presetNotice) && textOf(currentTree).includes(zh.presetAdd) && textOf(currentTree).includes(zh.presetSummary(0)))
    // EVO-007-B：顺序断言——ChatGPT 订阅登录先于子代理（subtitle 按文档序）。
    check('chatgpt section precedes subagents (EVO-007-B)', (() => {
      const subtitles = findAll(currentTree, (node) => node && hasClass(node, 'dshrouter-subtitle')).map(textOf)
      const presetIndex = subtitles.indexOf(zh.presetTitle)
      const cliIndex = subtitles.indexOf(zh.cliTitle)
      return presetIndex >= 0 && cliIndex > presetIndex
    })())
    const cliCardHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-card-head')).find((node) => textOf(node).includes('codexentry'))
    check('subagent card rendered under accounts', !!cliCardHead)
    if (cliCardHead) {
      cliCardHead.props.onClick()
      currentTree = await settle()
      const labels = buttonsOf(currentTree).map(textOf)
      check('subagent card keeps login & fetch-models buttons', (labels.includes(zh.cliLogin) || labels.includes(zh.cliRelogin)) && labels.includes(zh.cliFetchModels))
    }
    const advancedHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.advancedSection))
    check('advanced section card present', !!advancedHead)
    if (advancedHead) {
      // EVO-007：折叠壳保留给账号池——徽标仅余账号池计数（OAuth 计数随区块移除）。
      check('advanced section badge drops oauth count (EVO-007)', textOf(advancedHead).includes(zh.poolSummary(0)) && !textOf(advancedHead).includes('OAuth'))
      advancedHead.props.onClick()
      currentTree = await settle()
      check('advanced section reveals pools only (EVO-007)', textOf(currentTree).includes(zh.poolIntro) && !textOf(currentTree).includes('官方登录，插件独立管理'))
    }
  }

  // ── 断言：添加账号（＋ 自定义）模型留空时自动从端点拉取并随配置写入 ──
  // 负向见证：旧行为直接写无 models 的 profile → 宿主 llm-pi-ai 校验器
  // 报 "resolves no models" 拒绝写入；新行为必须先探测端点（与 cc-switch
  // 同款 GET /models），拉到才写入，拉不到中止并给出指引。
  const accountAddCard = findAll(currentTree, (node) => hasClass(node, 'dshrouter-add')).find((node) => textOf(node).includes(zh.addAccount))
  check('account add card found', !!accountAddCard)
  if (accountAddCard) {
    accountAddCard.props.onClick()
    currentTree = await settle()
    const customChip = buttonsOf(currentTree).find((node) => textOf(node).includes(zh.accountCustom))
    check('account add custom chip found', !!customChip)
    if (customChip) {
      customChip.props.onClick()
      currentTree = await settle()
      const inputByLabel = (label) => findAll(currentTree, (node) => node && node.type === 'input' && node.props && node.props['aria-label'] === label)[0]
      const fillAdd = (provider, baseUrl, key, models) => {
        const providerInput = inputByLabel(zh.fieldProviderId)
        if (providerInput) providerInput.props.onChange({ target: { value: provider } })
        const keyInput = inputByLabel(zh.accountKey)
        if (keyInput) keyInput.props.onChange({ target: { value: key } })
        const urlInput = inputByLabel(zh.accountBaseUrl)
        if (urlInput) urlInput.props.onChange({ target: { value: baseUrl } })
        const modelsInput = inputByLabel(zh.accountModelsField)
        if (modelsInput) modelsInput.props.onChange({ target: { value: models } })
      }
      const submitAdd = async () => {
        currentTree = await settle()
        const addButton = buttonsOf(currentTree).find((node) => textOf(node) === zh.accountAddProvider)
        if (addButton) addButton.props.onClick()
        currentTree = await settle()
        return addButton
      }
      // 场景 1：模型留空 + 端点可达 → 保存时自动拉取并写入发现的模型。
      fillAdd('crazy-code', 'https://gateway.example/v1', 'sk-test', '')
      const ready1 = await submitAdd()
      check('account add submit ready', !!ready1)
      check('custom add probes endpoint once', discoverCalls.length === 1 && discoverCalls[0].settingsNs === 'llm-pi-ai' && discoverCalls[0].provider === 'crazy-code' && discoverCalls[0].baseURL === 'https://gateway.example/v1' && discoverCalls[0].api === 'openai-completions' && discoverCalls[0].apiKey === 'sk-test')
      const crazyWrite = mutateCalls.find((call) => call.ns === 'llm-pi-ai' && Array.isArray(call.ops) && call.ops[0] && call.ops[0].path[1] === 'crazy-code')
      check('custom add writes discovered models', !!crazyWrite && Array.isArray(crazyWrite.ops[0].value.models) && crazyWrite.ops[0].value.models.length === 2 && crazyWrite.ops[0].value.models[0].id === 'm-a' && crazyWrite.ops[0].value.models[1].id === 'm-b' && crazyWrite.ops[0].value.models[1].name === 'Model B' && crazyWrite.ops[0].value.models[1].contextWindow === 65536 && crazyWrite.ops[0].value.models[1].maxTokens === 4096 && crazyWrite.ops[0].value.apiKeyEnv === 'CRAZY_CODE_API_KEY' && crazyWrite.ops[0].value.defaultInput.join(',') === 'text,image' && crazyWrite.ops[0].value.api === 'openai-completions' && crazyWrite.ops[0].value.baseURL === 'https://gateway.example/v1')
      check('custom add stores credential', credSetCalls.some((call) => call.ref === 'CRAZY_CODE_API_KEY' && call.value === 'sk-test'))

      // 场景 2：手工填写模型 → 原样写入，不探测端点（保持旧行为）。
      fillAdd('manual-gw', 'https://manual.example/v1', '', 'gpt-x, gpt-y')
      const ready2 = await submitAdd()
      check('manual add submit ready', !!ready2)
      const manualWrite = mutateCalls.find((call) => call.ns === 'llm-pi-ai' && Array.isArray(call.ops) && call.ops[0] && call.ops[0].path[1] === 'manual-gw')
      check('manual models skip probe', discoverCalls.length === 1)
      check('manual models written verbatim', !!manualWrite && Array.isArray(manualWrite.ops[0].value.models) && manualWrite.ops[0].value.models.length === 2 && manualWrite.ops[0].value.models[0].id === 'gpt-x' && manualWrite.ops[0].value.models[1].id === 'gpt-y' && !('apiKeyEnv' in manualWrite.ops[0].value))

      // 场景 3：同名内置服务商（目录路由）模型留空 → 不探测、不写 models
      // （按目录默认模型服务），保持旧行为。
      fillAdd('openai', 'https://api.openai.com/v1', 'sk-o', '')
      const ready3 = await submitAdd()
      check('catalog overwrite submit ready', !!ready3)
      const openaiWrite = mutateCalls.find((call) => call.ns === 'llm-pi-ai' && Array.isArray(call.ops) && call.ops[0] && call.ops[0].path[1] === 'openai')
      check('catalog route overwrite skips probe', discoverCalls.length === 1)
      check('catalog route overwrite omits models', !!openaiWrite && !('models' in openaiWrite.ops[0].value) && openaiWrite.ops[0].value.apiKeyEnv === 'OPENAI_API_KEY')

      // 场景 4：端点不可达 → 中止写入并给出明确指引（绝不写半成品配置）。
      const beforeFailWrites = mutateCalls.length
      discoverMode = 'fail'
      fillAdd('broken-gw', 'https://broken.example/v1', '', '')
      const ready4 = await submitAdd()
      check('failed add submit ready', !!ready4)
      check('failed discovery aborts write', mutateCalls.length === beforeFailWrites && discoverCalls.length === 2)
      check('failed discovery shows guidance', textOf(currentTree).includes(zh.accountDiscoverFailed) && textOf(currentTree).includes(zh.accountModelsRequiredHint))
      discoverMode = 'ok'
    }
  }

  // ── 断言：账号卡片编辑——自定义路由清空模型时自动拉取并原子写入；
  //  拉取失败时保留现有模型（绝不写坏已生效的配置）────────────────────
  const gatewayHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-card-head')).find((node) => textOf(node).includes('gateway'))
  check('declared account card head found', !!gatewayHead)
  if (gatewayHead) {
    gatewayHead.props.onClick()
    currentTree = await settle()
    // 按头部按钮定位账号卡片：其他卡片展开后的内容（如 agent 卡片的服务商
    // datalist 选项 "Gateway (gateway)"）同样含该字样，必须锚定在头部。
    const gatewayCard = () => findAll(currentTree, (node) => node && node.type === 'div' && hasClass(node, 'dshrouter-card')).find((node) => {
      const head = (node.children ?? []).find((child) => child && child.type === 'button' && hasClass(child, 'dshrouter-card-head'))
      return !!head && textOf(head).includes('gateway')
    })
    // 账号卡片的模型输入框没有 aria-label（仅添加表单有）：在卡片子树内按
    // 值定位（profile 里既有模型渲染为 'old-m'）。
    const gatewayModelsInput = () => {
      const card = gatewayCard()
      return card ? findAll(card, (node) => node && node.type === 'input').find((node) => node.props && node.props.value === 'old-m') : null
    }
    const gatewaySave = () => {
      const card = gatewayCard()
      return card ? findAll(card, (node) => node && node.type === 'button').find((node) => textOf(node) === zh.save) : null
    }
    const gatewayInput = gatewayModelsInput()
    check('declared account models field shown', !!gatewayInput)
    if (gatewayInput) {
      // 清空模型字段后保存：自动拉取 → 模型与 Base URL 合并进同一次原子写入。
      gatewayInput.props.onChange({ target: { value: '' } })
      currentTree = await settle()
      const beforeEditWrites = mutateCalls.length
      const saveButton = gatewaySave()
      check('declared account save button found', !!saveButton)
      if (saveButton) {
        saveButton.props.onClick()
        currentTree = await settle()
        const lastDiscover = discoverCalls[discoverCalls.length - 1]
        check('edit probes endpoint for declared route', lastDiscover && lastDiscover.provider === 'gateway' && lastDiscover.baseURL === 'https://gateway.example/v1' && lastDiscover.api === 'openai-completions' && !('apiKey' in lastDiscover))
        const gatewayEditWrite = mutateCalls.slice(beforeEditWrites).find((call) => call.ns === 'llm-pi-ai')
        const modelsOp = gatewayEditWrite ? gatewayEditWrite.ops.find((op) => op.path[2] === 'models') : null
        check('edit writes discovered models atomically', !!gatewayEditWrite && gatewayEditWrite.ops.length >= 4 && !!modelsOp && modelsOp.op === 'set' && Array.isArray(modelsOp.value) && modelsOp.value.length === 2 && modelsOp.value[0].id === 'm-a' && modelsOp.value[1].id === 'm-b' && gatewayEditWrite.ops.some((op) => op.path[2] === 'baseURL' && op.value === 'https://gateway.example/v1'))
        check('edit notice reports discovery', textOf(currentTree).includes(zh.accountDiscovered(2)))

        // 负向见证：拉取失败时保留现有模型列表——本次写入不含 models 操作。
        discoverMode = 'fail'
        const beforeFailEdit = mutateCalls.length
        const inputAgain = gatewayModelsInput()
        if (inputAgain) inputAgain.props.onChange({ target: { value: '' } })
        currentTree = await settle()
        const saveAgain = gatewaySave()
        if (saveAgain) saveAgain.props.onClick()
        currentTree = await settle()
        const failEditWrite = mutateCalls.slice(beforeFailEdit).find((call) => call.ns === 'llm-pi-ai')
        check('failed edit keeps models', !!failEditWrite && !failEditWrite.ops.some((op) => op.path[2] === 'models') && failEditWrite.ops.some((op) => op.path[2] === 'baseURL'))
        check('failed edit notice kept models', textOf(currentTree).includes(zh.accountModelsKept) && textOf(currentTree).includes(zh.accountDiscoverFailed))
        discoverMode = 'ok'
      }
    }
  }

  // ── 断言：cli 子代理登录体验——未登录红色醒目提示 + 登录轮询状态机 ──
  // 负向见证：宿主 cliLogin 曾引用未定义的 agent（ReferenceError），登录
  // 按钮永远报失败、只有「刷新状态」能显示已登录；轮询成功后 loginBusy
  // 不复位、按钮永久卡「等待登录…」。以下断言覆盖：未登录红字、登录后
  // 轮询自动刷新为已登录且按钮复位、轮询耗尽给出红色超时提示且按钮复位。
  const subCard = () => findAll(currentTree, (node) => node && node.type === 'div' && hasClass(node, 'dshrouter-card')).find((node) => {
    const head = (node.children ?? []).find((child) => child && child.type === 'button' && hasClass(child, 'dshrouter-card-head'))
    return !!head && textOf(head).includes('codexentry')
  })
  const subButtons = () => {
    const card = subCard()
    return card ? findAll(card, (node) => node && node.type === 'button') : []
  }
  const subCardFound = !!subCard()
  check('subagent card found for login flow', subCardFound)
  if (subCardFound) {
    // 场景 1：未登录 → 刷新状态后 chip 与状态消息均为红色醒目样式。
    cliStatusMode = 'logged-out'
    const refreshButton = subButtons().find((node) => textOf(node) === zh.cliStatusRefresh)
    check('subagent refresh status button found', !!refreshButton)
    if (refreshButton) {
      refreshButton.props.onClick()
      currentTree = await settle()
      const card = subCard()
      const redChips = card ? findAll(card, (node) => node && node.type === 'span' && hasClass(node, 'dshrouter-error') && textOf(node).includes(zh.cliStatusLoggedOut)) : []
      check('logged-out chip rendered red', redChips.length > 0)
      const redMessages = card ? findAll(card, (node) => node && node.type === 'p' && hasClass(node, 'dshrouter-error') && textOf(node).includes('Not logged in')) : []
      check('logged-out status message rendered red', redMessages.length > 0)

      // 场景 2：点击登录 → 轮询立即成功 → chip 已登录 + 按钮复位为「重新登录」。
      cliStatusMode = 'ok'
      const loginButton = subButtons().find((node) => textOf(node) === zh.cliLogin)
      check('subagent login button found', !!loginButton)
      if (loginButton) {
        loginButton.props.onClick()
        currentTree = await settle(120)
        const after = subCard()
        const afterButtons = after ? findAll(after, (node) => node && node.type === 'button') : []
        check('login poll flips chip to logged in', !!after && textOf(after).includes(zh.cliStatusLoggedIn) && textOf(after).includes('已登录：已登录'))
        check('login button resets after success', afterButtons.some((node) => textOf(node) === zh.cliRelogin) && !afterButtons.some((node) => textOf(node) === zh.cliLoginWaiting))

        // 场景 3：轮询耗尽（20 次都未登录）→ 红色超时提示 + 按钮复位为「登录」。
        cliStatusMode = 'logged-out'
        const reloginButton = afterButtons.find((node) => textOf(node) === zh.cliRelogin)
        check('subagent relogin button found', !!reloginButton)
        if (reloginButton) {
          reloginButton.props.onClick()
          currentTree = await settle(200)
          const timedOut = subCard()
          const timedOutButtons = timedOut ? findAll(timedOut, (node) => node && node.type === 'button') : []
          const timeoutNotice = timedOut ? findAll(timedOut, (node) => node && node.type === 'p' && hasClass(node, 'dshrouter-error') && textOf(node).includes(zh.cliLoginTimeoutHint)) : []
          check('login poll timeout shows red hint', timeoutNotice.length > 0)
          check('timeout flips chip back to logged out', !!timedOut && textOf(timedOut).includes(zh.cliStatusLoggedOut))
          check('login button resets after timeout', timedOutButtons.some((node) => textOf(node) === zh.cliLogin) && !timedOutButtons.some((node) => textOf(node) === zh.cliLoginWaiting))
        }
      }
    }
    cliStatusMode = 'ok'
  }

  // ── 断言：对话框图片通路（composer 附件按钮 / route_agent 工具卡片）──
  // 负向见证：旧版本无附件按钮（宿主准入直接拒绝图片），route_agent 生成
  // 图片以真实图片块写入工具结果（文本模型历史被击穿）。
  const tOf = (key) => zh[key] ?? key
  const imageToolReg = registrationOf('conversation.input.right')
  const toolCardReg = registrationOf('tool.call.toolview')
  // ARCH-005 A4（HD-004）：宿主 0.1.5 起图片直传通道 = conversation.createDrafts
  // (sessionId, files) → inputActions.addAttachments(ids) → 失败
  // conversation.releaseDraftAttachments(drafts)（宿主原生先例
  // dsh-client-ui-conversation composer addFiles 注入；createDraftImages/
  // addImages 0.1.5-rc.2 npm pack 实测 0 命中——T-1 定性）。夹具锚定该新面
  // （P10-④：宿主面形态锚定实读，drafts 描述符含 kind/id/previewUrl/file——
  // browserDraftAttachment 实读同形）。
  const conversationMock = {
    createDrafts: (sessionId, files) => files.map((file, index) => ({ kind: 'image', id: `draft-${index}-${file.name}`, previewUrl: 'blob:preview', file })),
    releaseDraftAttachments: () => {},
  }
  const inputActionsMock = { addAttachments: () => true }
  captured.imageDataCalls = []

  // 附件按钮：多模态开启（有视觉 agent）时渲染；仅有生图 agent 时隐藏——与接管同信号。
  {
    const tree = await renderInto(imageToolReg.render({ t: tOf, router: () => remoteMock, conversation: () => conversationMock, inputActions: inputActionsMock, sessionId: 'session-1' }), 'imagetool')
    const attachButton = findAll(tree, (node) => node && node.type === 'button' && node.props && node.props['aria-label'] === tOf('attach'))
    check('composer attach button renders with vision agent', attachButton.length === 1)
    // 生图 agent（draw，image 类型）也触发按钮显示——图生图需要发图。
    catalogMode = 'drawOnly'
    const listener = captured.listeners.find((entry) => entry.event === 'settings/document-updated')
    if (listener) listener.listener()
    const genTree = await renderInto(imageToolReg.render({ t: tOf, router: () => remoteMock, conversation: () => conversationMock, inputActions: inputActionsMock, sessionId: 'session-1' }), 'imagetool')
    const genButton = findAll(genTree, (node) => node && node.type === 'button' && node.props && node.props['aria-label'] === tOf('attach'))
    check('composer attach button renders with generation-only agent', genButton.length === 1)
    // 无任何多模态 agent → 按钮隐藏。
    catalogMode = 'none'
    if (listener) listener.listener()
    const hidden = await renderInto(imageToolReg.render({ t: tOf, router: () => remoteMock, conversation: () => conversationMock, inputActions: inputActionsMock, sessionId: 'session-1' }), 'imagetool')
    const attachHidden = findAll(hidden, (node) => node && node.type === 'button' && node.props && node.props['aria-label'] === tOf('attach'))
    check('composer attach button hidden without multimodal agent', attachHidden.length === 0)
    catalogMode = 'withVision'
    listener && listener.listener()
  }

  // F11 附件上传（v3 Step 8 / N-6）：attach 输入 accept 扩展非图片类型；非图片
  // 经 remote.uploadFile 上传（字节 base64）→ 成功渲染附件卡片 + 结构化路径文本
  // 经 inputActions.setDraft 追加进 draft；失败显示错误提示；图片文件仍走原生
  // addAttachments 通道（ARCH-005 A4/HD-004 迁移：createDrafts 注册 runtime 图片
  // 草稿——零上传，字节随 prompt 编码；uploadFile 不接管图片——避免双通道）。
  {
    const fileInputOf = (tree) => findAll(tree, (node) => node && node.type === 'input' && node.props && node.props.type === 'file')[0]
    const draftState = { value: '已有草稿文本' }
    const addAttachmentsCalls = []
    const setDraftCalls = []
    const conversationUpload = {
      createDrafts: (sessionId, files) => files.map((file, index) => ({ kind: 'image', id: `draft-${index}-${file.name}`, previewUrl: 'blob:preview', file })),
      releaseDraftAttachments: () => {},
    }
    const inputActionsUpload = {
      addAttachments: (ids) => { addAttachmentsCalls.push(ids); return true },
      setDraft: (text) => { setDraftCalls.push(text) },
    }
    const f11Props = () => ({
      t: tOf,
      router: () => remoteMock,
      conversation: () => conversationUpload,
      inputActions: inputActionsUpload,
      useInput: (selector) => selector({ draft: draftState.value }),
      sessionId: 'session-1',
    })
    catalogMode = 'withVision'
    const listener = captured.listeners.find((entry) => entry.event === 'settings/document-updated')
    if (listener) listener.listener()
    await new Promise((resolve) => setImmediate(resolve))
    captured.uploadFileCalls = []
    uploadFailMode = false
    const f11Tree = await renderInto(imageToolReg.render(f11Props()), 'imagetool-f11')
    const fileInput = fileInputOf(f11Tree)
    check('attach input accept extended to non-image', !!fileInput && typeof fileInput.props.accept === 'string' && fileInput.props.accept.includes('audio/') && fileInput.props.accept.includes('video/') && fileInput.props.accept.includes('.pdf'))
    // 上传成功：卡片渲染 + uploadFile RPC 载荷 + setDraft 追加路径文本。
    if (fileInput) {
      fileInput.props.onChange({ target: { files: [{ name: 'voice.wav', type: 'audio/wav', _base64: 'aGVsbG8=' }], value: '' } })
      currentTree = await settle()
      const cards = findAll(currentTree, (node) => hasClass(node, 'dshrouter-attachcard'))
      check('upload success renders attachment card', cards.length === 1 && textOf(cards[0]).includes('voice.wav') && textOf(cards[0]).includes('.router-files/voice.wav'))
      check('uploadFile RPC called with name/mediaType/base64', captured.uploadFileCalls.length === 1 && captured.uploadFileCalls[0].name === 'voice.wav' && captured.uploadFileCalls[0].mediaType === 'audio/wav' && captured.uploadFileCalls[0].dataBase64 === 'aGVsbG8=')
      check('upload success appends path text via setDraft', setDraftCalls.length === 1 && setDraftCalls[0].startsWith('已有草稿文本') && setDraftCalls[0].includes('[附件: 音频 voice.wav 路径 .router-files/voice.wav]'))
      // 上传失败：同一组件实例上失败（先成功已渲染 1 张卡）→ 错误提示渲染
      // （错误码可见）且不追加卡片（判别：卡片数保持 1——旧断言在全新实例上
      // 断言空 cards 恒真，无判别力，F-05）。
      uploadFailMode = true
      const failInput = fileInputOf(currentTree)
      if (failInput) {
        failInput.props.onChange({ target: { files: [{ name: 'big.bin', type: 'application/octet-stream', _base64: 'Ymln' }], value: '' } })
        currentTree = await settle()
        const failCards = findAll(currentTree, (node) => hasClass(node, 'dshrouter-attachcard'))
        check('upload failure shows error without extra card', failCards.length === 1 && textOf(currentTree).includes('FILE_TOO_LARGE'))
      }
      uploadFailMode = false
      // 图片 + 视频混选：图片仍走原生 addAttachments（不进 uploadFile），视频走 uploadFile。
      const mixedTree = await renderInto(imageToolReg.render(f11Props()), 'imagetool-f11-mixed')
      const mixedInput = fileInputOf(mixedTree)
      if (mixedInput) {
        mixedInput.props.onChange({ target: { files: [
          { name: 'shot.png', type: 'image/png', _base64: 'aGk=' },
          { name: 'clip.mp4', type: 'video/mp4', _base64: 'bXA0' },
        ], value: '' } })
        currentTree = await settle()
        check('image routes to native addAttachments, video to uploadFile', addAttachmentsCalls.length === 1 && addAttachmentsCalls[0][0] === 'draft-0-shot.png' && captured.uploadFileCalls.some((call) => call.name === 'clip.mp4') && captured.uploadFileCalls.some((call) => call.name === 'clip.mp4' && call.mediaType === 'video/mp4'))
      }

      // ── ARCH-005 A4（HD-004）判别断言群：图片直传 addAttachments 迁移 ──
      // 验收门 ①：stub 宿主面在场 → 选图 → createDrafts（sessionId+files）→
      // addAttachments(ids) 全链被调（绿）；stub 缺面 → attachUnavailable 降级
      // 不崩（守卫负向判别——FIX-048 守卫语义延续）；addAttachments 拒绝（提交
      // 锁 adjudicating/submitting）→ releaseDraftAttachments 回滚（宿主原生
      // 先例逐形）；旧面 stub（createDraftImages/addImages 形态）→ 拒识降级
      // （P5 零并存：旧路径删除后旧面不再被消费）。
      {
        // ① 正向链：createDrafts 收到 sessionId 与图片集，addAttachments 收到
        // 草稿 id 集，成功路径不回滚。
        const chainCalls = { createDrafts: [], addAttachments: [], release: 0 }
        const chainConversation = {
          createDrafts: (sessionId, files) => { chainCalls.createDrafts.push({ sessionId, files }); return files.map((file, index) => ({ kind: 'image', id: `draft-${index}-${file.name}`, previewUrl: 'blob:preview', file })) },
          releaseDraftAttachments: () => { chainCalls.release += 1 },
        }
        const chainInputActions = {
          addAttachments: (ids) => { chainCalls.addAttachments.push(ids); return true },
          setDraft: () => {},
        }
        const chainTree = await renderInto(imageToolReg.render({
          t: tOf, router: () => remoteMock, conversation: () => chainConversation,
          inputActions: chainInputActions, sessionId: 'session-chain',
        }), 'imagetool-a4-chain')
        const chainInput = fileInputOf(chainTree)
        if (chainInput) {
          chainInput.props.onChange({ target: { files: [
            { name: 'a.png', type: 'image/png', _base64: 'YQ==' },
            { name: 'b.webp', type: 'image/webp', _base64: 'Yg==' },
          ], value: '' } })
          currentTree = await settle()
          check('a4 positive: createDrafts called with sessionId and image files',
            chainCalls.createDrafts.length === 1 && chainCalls.createDrafts[0].sessionId === 'session-chain'
              && chainCalls.createDrafts[0].files.length === 2 && chainCalls.createDrafts[0].files[0].name === 'a.png')
          check('a4 positive: addAttachments called with draft ids and no release on success',
            chainCalls.addAttachments.length === 1 && chainCalls.addAttachments[0].length === 2
              && chainCalls.addAttachments[0][0] === 'draft-0-a.png' && chainCalls.addAttachments[0][1] === 'draft-1-b.webp'
              && chainCalls.release === 0)
        }
        // ② addAttachments 拒绝（false——宿主提交锁形态）→ releaseDraftAttachments
        // 回滚（宿主先例：drafts→addAttachments 失败→releaseDraftAttachments）。
        const rejectCalls = { addAttachments: 0, release: 0 }
        const rejectConversation = {
          createDrafts: (sessionId, files) => files.map((file, index) => ({ kind: 'image', id: `draft-${index}-${file.name}`, previewUrl: 'blob:preview', file })),
          releaseDraftAttachments: () => { rejectCalls.release += 1 },
        }
        const rejectTree = await renderInto(imageToolReg.render({
          t: tOf, router: () => remoteMock, conversation: () => rejectConversation,
          inputActions: { addAttachments: (ids) => { rejectCalls.addAttachments += 1; return false }, setDraft: () => {} },
          sessionId: 'session-reject',
        }), 'imagetool-a4-reject')
        const rejectInput = fileInputOf(rejectTree)
        if (rejectInput) {
          rejectInput.props.onChange({ target: { files: [{ name: 'x.png', type: 'image/png', _base64: 'eA==' }], value: '' } })
          currentTree = await settle()
          check('a4 addAttachments rejection rolls back via releaseDraftAttachments',
            rejectCalls.addAttachments === 1 && rejectCalls.release === 1)
        }
        // ③ 负向守卫（attachUnavailable 降级不崩——FIX-048 守卫语义延续）：
        // 缺 createDrafts 面 / 缺 addAttachments 面 / 缺 sessionId——三种缺面形态。
        const guardCases = [
          { label: 'missing createDrafts face', conversation: () => ({ releaseDraftAttachments: () => {} }), inputActions: { addAttachments: () => true }, sessionId: 'session-guard' },
          { label: 'missing addAttachments face', conversation: () => chainConversation, inputActions: { setDraft: () => {} }, sessionId: 'session-guard' },
          { label: 'missing sessionId', conversation: () => chainConversation, inputActions: chainInputActions, sessionId: undefined },
        ]
        for (const guardCase of guardCases) {
          const guardTree = await renderInto(imageToolReg.render({
            t: tOf, router: () => remoteMock, conversation: guardCase.conversation,
            inputActions: guardCase.inputActions, useInput: (selector) => selector({ draft: '' }),
            sessionId: guardCase.sessionId,
          }), `imagetool-a4-guard-${guardCase.label.replace(/[^a-z]+/g, '-')}`)
          const guardInput = fileInputOf(guardTree)
          if (guardInput) {
            guardInput.props.onChange({ target: { files: [{ name: 'g.png', type: 'image/png', _base64: 'Zw==' }], value: '' } })
            currentTree = await settle()
            check(`a4 guard (${guardCase.label}): attachUnavailable downgrade, no crash`,
              textOf(currentTree).includes(zh.attachUnavailable))
          }
        }
        // ④ 旧面 stub 拒识（P5 零并存判别）：宿主 stub 只提供 0.1.2 时代
        // createDraftImages/addImages 形态 → 新实现不消费 → attachUnavailable。
        const legacyTree = await renderInto(imageToolReg.render({
          t: tOf, router: () => remoteMock,
          conversation: () => ({ createDraftImages: (files) => files.map((file, index) => ({ id: `legacy-${index}`, previewUrl: 'blob:legacy', file })), releaseDraftImages: () => {} }),
          inputActions: { addImages: () => true, setDraft: () => {} },
          useInput: (selector) => selector({ draft: '' }),
          sessionId: 'session-legacy',
        }), 'imagetool-a4-legacy')
        const legacyInput = fileInputOf(legacyTree)
        if (legacyInput) {
          legacyInput.props.onChange({ target: { files: [{ name: 'old.png', type: 'image/png', _base64: 'b2xk' }], value: '' } })
          currentTree = await settle()
          check('a4 legacy face (createDraftImages/addImages) is no longer consumed',
            textOf(currentTree).includes(zh.attachUnavailable))
        }
        // ⑤ 图片分流口径与宿主对齐（isImageMediaType 四 MIME：png/jpeg/webp/gif）：
        // 非四 MIME 的 image/*（如 image/svg+xml）不入图片直传分支——宿主
        // createDrafts 只认四 MIME，其余会被宿主当 file draft 触发上传（双通道
        // 错位），插件侧同口径分流即免疫。
        const svgCalls = { createDrafts: 0 }
        const svgConversation = {
          createDrafts: (sessionId, files) => { svgCalls.createDrafts += 1; return [] },
          releaseDraftAttachments: () => {},
        }
        captured.uploadFileCalls = []
        const svgTree = await renderInto(imageToolReg.render({
          t: tOf, router: () => remoteMock, conversation: () => svgConversation,
          inputActions: { addAttachments: () => true, setDraft: () => {} },
          useInput: (selector) => selector({ draft: '' }),
          sessionId: 'session-svg',
        }), 'imagetool-a4-svg')
        const svgInput = fileInputOf(svgTree)
        if (svgInput) {
          svgInput.props.onChange({ target: { files: [{ name: 'icon.svg', type: 'image/svg+xml', _base64: 'c3Zn' }], value: '' } })
          currentTree = await settle()
          check('a4 non-raster image/* routes to uploadFile path, not createDrafts',
            svgCalls.createDrafts === 0 && captured.uploadFileCalls.some((call) => call.name === 'icon.svg'))
        }
      }
      // F-01（P1 回归）：多非图片文件一次选选 → 全部路径文本累积后一次 setDraft
      // （旧实现逐文件整体覆盖渲染期快照，除最后一项外全部路径文本丢失）。
      const multiBefore = setDraftCalls.length
      const multiTree = await renderInto(imageToolReg.render(f11Props()), 'imagetool-f11-multi')
      const multiInput = fileInputOf(multiTree)
      if (multiInput) {
        multiInput.props.onChange({ target: { files: [
          { name: 'notes.doc', type: 'application/msword', _base64: 'YQ==' },
          { name: 'data.csv', type: 'text/csv', _base64: 'Yg==' },
        ], value: '' } })
        currentTree = await settle()
        const multiDrafts = setDraftCalls.slice(multiBefore)
        const multiCards = findAll(currentTree, (node) => hasClass(node, 'dshrouter-attachcard'))
        check('multi non-image upload accumulates all paths in one setDraft', multiDrafts.length === 1 && multiCards.length === 2 && multiDrafts[0].startsWith('已有草稿文本') && multiDrafts[0].includes('[附件: 文档 notes.doc 路径 .router-files/notes.doc]') && multiDrafts[0].includes('[附件: 文档 data.csv 路径 .router-files/data.csv]'))
      }
    }
    catalogMode = 'withVision'
  }

  // FIX-048 夹具形态：现行宿主 InputState（attachmentIds 统一编址，经 useInput
  // hook 注入——宿主 0.1.5-rc.1 现行 standardProps 面；字段清单锚
  // @deepseek-ai/dsh-client-ui-conversation lib/types/client/contract/input.d.ts
  // 的 export interface InputState）；conversation = kind 解析面 fake（service.d.ts
  // 的 resolveDraftAttachments(ids): readonly ComposerAttachment[]，kind:
  // 'image'|'file' 见 contract/slots.d.ts）。旧宿主形态（input.imageIds——
  // 0.1.2-rc.x 前契约）保留为显式回落断言（下方 legacy 条目）。
  // 作用域：两个接管断言块（开启/幂等/停用 + FIX-002-R7 F3）共用本层定义。
  const inputStateOf = (attachmentIds) => ({ draft: '', attachmentIds, draftRev: 1, phase: 'plain', occurrences: [], queue: [] })
  const conversationFaceOf = (kinds = {}) => ({
    resolveDraftAttachments: (ids) => ids.map((id) => (kinds[id] ?? 'file') === 'image'
      ? { kind: 'image', id, file: {}, previewUrl: '' }
      : { kind: 'file', id, file: {} }),
  })

  // 模型接管（无 UI 条目）：视觉开启 → 自动切包装组；已接管幂等；关闭 → 切回原 provider。
  {
    const takeoverReg = captured.registrations.find((reg) => reg && reg.id === 'router-model-takeover')
    check('model takeover entry registered', !!takeoverReg)
    if (takeoverReg) {
      const listener = captured.listeners.find((entry) => entry.event === 'settings/document-updated')
      // 开启接管：纯文本当前选中 → 自动切到包装组。
      sessionCurrent = { provider: 'openai', model: 'gpt-4o' }
      sessionSelectCalls.length = 0
      await renderInto(takeoverReg.render({ sessionId: 'sess-1', useInput: (sel) => sel(inputStateOf([])), conversation: conversationFaceOf(), api: apiMock }), 'takeover')
      check('takeover switches to wrap route', sessionSelectCalls.some((call) => call.provider === 'openai-router' && call.model === 'gpt-4o'))
      // 已接管：草稿变化（如贴图）重渲染不重复切（幂等，零竞态）。
      const before = sessionSelectCalls.length
      await renderInto(takeoverReg.render({ sessionId: 'sess-1', useInput: (sel) => sel(inputStateOf(['att-1'])), conversation: conversationFaceOf({ 'att-1': 'image' }), api: apiMock }), 'takeover')
      check('takeover idempotent when already wrapped', sessionSelectCalls.length === before)
      // 关闭全部多模态 agent：包装组当前选中 → 切回原 provider。
      sessionCurrent = { provider: 'openai-router', model: 'gpt-4o' }
      sessionSelectCalls.length = 0
      catalogMode = 'none'
      listener && listener.listener()
      await new Promise((resolve) => setImmediate(resolve))
      await renderInto(takeoverReg.render({ sessionId: 'sess-1', useInput: (sel) => sel(inputStateOf([])), conversation: conversationFaceOf(), api: apiMock }), 'takeover')
      check('takeover restores original provider on disable', sessionSelectCalls.some((call) => call.provider === 'openai' && call.model === 'gpt-4o'))
      catalogMode = 'withVision'
      listener && listener.listener()
      await new Promise((resolve) => setImmediate(resolve))
    }
  }

  // FIX-002-R7 F3：开关关闭（takeoverDefaultModel=false）判别双断言组——既有
  // fixture 恒 true，接管断言在"armed 只看多模态 agent"的旧客户端代码下全过
  // （零判别覆盖）。每条断言的"旧代码下必败"推演见各处注释。
  {
    const takeoverReg = captured.registrations.find((reg) => reg && reg.id === 'router-model-takeover')
    if (takeoverReg) {
      const listener = captured.listeners.find((entry) => entry.event === 'settings/document-updated')
      takeoverSwitch = false
      if (listener) listener.listener()
      await new Promise((resolve) => setImmediate(resolve))
      // ① 开关 false → 会话级不接管：会话停在原生 provider，effect 触发后零
      //    selectModel。旧代码推演（无 catalog.takeoverDefaultModel 门控 →
      //    armed=true）：armed && !wrapped → selectModel('openai-router') →
      //    length===0 必败 → 判别成立。
      sessionCurrent = { provider: 'openai', model: 'gpt-4o' }
      sessionSelectCalls.length = 0
      await renderInto(takeoverReg.render({ sessionId: 'sess-off', useInput: (sel) => sel(inputStateOf([])), conversation: conversationFaceOf(), api: apiMock }), 'takeover-off')
      check('takeover off: no session takeover without switch (F3-1)', sessionSelectCalls.length === 0)
      // ② 开关 false → 不撤销用户手动选的 twin：挂载 / 贴图（imageCount 0→1）/
      //    会话切换（新 sessionId，子代理场景）三类 effect 触发均零 selectModel。
      //    F1 修复前代码推演（!armed && wrapped 无来源记忆 → 每次触发直接还原）：
      //    每次触发 selectModel('openai') 剥回原生 → length===0 必败 → 判别成立
      //    （拦住 F1 的断言）。每次触发前重置 sessionCurrent 为 twin + 清空调用
      //    记录，保证三类触发各自独立判别（旧代码下三条全部失败）。
      //    挂载断言用全新实例（prefix 'takeover-off-2'）——与 F3-1 同实例同 deps
      //    的渲染不会重跑 effect（deps 去重语义），那会退化成 vacuous pass。
      const manualTwin = () => { sessionCurrent = { provider: 'openai-router', model: 'gpt-4o' }; sessionSelectCalls.length = 0 }
      manualTwin()
      await renderInto(takeoverReg.render({ sessionId: 'sess-off', useInput: (sel) => sel(inputStateOf([])), conversation: conversationFaceOf(), api: apiMock }), 'takeover-off-2')
      check('takeover off: manual twin untouched on mount (F3-2)', sessionSelectCalls.length === 0)
      manualTwin()
      await renderInto(takeoverReg.render({ sessionId: 'sess-off', useInput: (sel) => sel(inputStateOf(['att-9'])), conversation: conversationFaceOf({ 'att-9': 'image' }), api: apiMock }), 'takeover-off-2')
      check('takeover off: paste does not revoke manual twin (F3-2)', sessionSelectCalls.length === 0)
      manualTwin()
      await renderInto(takeoverReg.render({ sessionId: 'sess-off-2', useInput: (sel) => sel(inputStateOf([])), conversation: conversationFaceOf(), api: apiMock }), 'takeover-off-2')
      check('takeover off: session switch does not revoke manual twin (F3-2)', sessionSelectCalls.length === 0)
      // FIX-048 旧宿主形态回落断言：props.input.imageIds（0.1.2-rc.x 前契约）
      // 长度即图片数 → 武装语义不回退（新形态为主、旧形态显式回落，无只测旧
      // 形态假绿）。
      sessionCurrent = { provider: 'openai', model: 'gpt-4o' }
      sessionSelectCalls.length = 0
      await renderInto(takeoverReg.render({ sessionId: 'sess-off-legacy', input: { imageIds: ['legacy-1'] }, api: apiMock }), 'takeover-off-legacy')
      check('takeover legacy imageIds form still arms (FIX-048 fallback)', sessionSelectCalls.some((call) => call.provider === 'openai-router' && call.model === 'gpt-4o'))
      takeoverSwitch = true
      if (listener) listener.listener()
      await new Promise((resolve) => setImmediate(resolve))
    }
  }

  // EVO-002 Step 6 → EVO-006 转正（DEC-026 C2）：ChatGPT 订阅登录为正式通道
  // （无实验开关、无 ToS 门；平台 ToS/账号风控提示保留）+ preset 账号卡 +
  // W-5 删除联动。判别性推演：断言 ①② 在"实验开关门控入口"的旧客户端代码
  // 下必败——旧代码 config 无 oauthExperimental=true 时分区不渲染 presetAdd/
  // presetLogin 元素（findAll 查空 → undefined 分支跳过点击 → 捕获数组为空
  // → 断言失败）；断言 ③④⑤⑥ 在"无登出联动"的旧代码下必败。
  {
    const settingsReg6 = captured.registrations.find((reg) => reg && reg.name === 'settings.section')
    const listener6 = captured.listeners.find((entry) => entry.event === 'settings/document-updated')
    const renderSettings6 = async (prefix) => {
      const tree6 = await renderInto(settingsReg6.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: tOf, $on: () => () => {} }), prefix)
      // 两级折叠（分类卡头为 dshrouter-category-head）：多模态账号区 → 高级扩展。
      const heads6 = findAll(tree6, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head'))
      const accountsHead6 = heads6.find((node) => textOf(node).includes(tOf('accountTitle')))
      if (accountsHead6) accountsHead6.props.onClick()
      const tree6b = await settle()
      const heads6b = findAll(tree6b, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head'))
      const advHead6 = heads6b.find((node) => textOf(node).includes(tOf('advancedSection')))
      if (advHead6) advHead6.props.onClick()
      return settle()
    }
    // ① 转正渲染：正式分区标题 + 平台提示 + 添加入口恒可见 + 全树无实验字样。
    {
      presetMode = 'none'
      if (listener6) listener6.listener()
      await new Promise((resolve) => setImmediate(resolve))
      const tree6 = await renderSettings6('step6-promotion')
      check('step6: official channel section title renders (DEC-026)', textOf(tree6).includes(tOf('presetTitle')) && textOf(tree6).includes(tOf('presetNotice')))
      check('step6: preset add entry always visible, no experimental labels (DEC-026)', textOf(tree6).includes(tOf('presetAdd')) && !textOf(tree6).includes('实验') && !textOf(tree6).includes('Experimental'))
    }
    // ② 无 ToS 门添加：拒绝一切 confirm 仍可创建账号并发起授权；转正后任何
    //    操作不得写入 oauthExperimental/oauthTosAccepted 键。
    {
      const tree6 = await renderSettings6('step6-add')
      confirmMode = false
      captured.saveOps.length = 0
      captured.beginCalls.length = 0
      const addBtn6 = buttonsOf(tree6).find((node) => textOf(node) === tOf('presetAdd'))
      if (addBtn6) addBtn6.props.onClick()
      await settle()
      const accountOps6 = captured.saveOps.filter((op) => op.path[0] === 'oauthAccounts')
      const gateOps6 = captured.saveOps.filter((op) => op.path[0] === 'oauthExperimental' || op.path[0] === 'oauthTosAccepted')
      check('step6: add account proceeds without ToS confirm (DEC-026)', !!addBtn6 && accountOps6.length === 1 && captured.beginCalls.length === 1 && captured.beginCalls[0]?.accountId === 'chatgpt')
      check('step6: retired gate keys never written (DEC-026)', gateOps6.length === 0)
      // EVO-008 R0 P2-1：正向锁定 preset 新增账号的默认 models（深等于 gpt-5.6
      // 三件套）——旧默认（gpt-5.4 系）或任何错值必败；与五点负向残留守卫互补。
      const accountValue6 = accountOps6.length === 1 && accountOps6[0].op === 'set' && accountOps6[0].value ? accountOps6[0].value : null
      const defaultModels6 = accountValue6 && Array.isArray(accountValue6.models) ? accountValue6.models : null
      check('step6: preset default models = gpt-5.6 trio (EVO-008 P2-1 正向锁定)', defaultModels6 !== null && defaultModels6.length === 3 && defaultModels6[0] === 'gpt-5.6-sol' && defaultModels6[1] === 'gpt-5.6-terra' && defaultModels6[2] === 'gpt-5.6-luna')
      confirmMode = true
      presetMode = 'logged-out'
      if (listener6) listener6.listener()
      await new Promise((resolve) => setImmediate(resolve))
    }
    // ④ 开启后：preset 账号卡（登录按钮）+ 添加入口可见。
    {
      const tree6 = await renderSettings6('step6-on')
      check('step6: preset card renders with login button', textOf(tree6).includes(tOf('presetLogin')) && textOf(tree6).includes('chatgpt'))
      check('step6: preset add entry visible when on', textOf(tree6).includes(tOf('presetAdd')))
      // ⑤ 登录点击 → oauthBegin（preset 分支）→ 授权页弹窗（open 捕获）。
      captured.beginCalls.length = 0
      captured.openCalls.length = 0
      const loginBtn6 = buttonsOf(tree6).find((node) => textOf(node) === tOf('presetLogin'))
      if (loginBtn6) loginBtn6.props.onClick()
      await settle()
      check('step6: login click fires oauthBegin for preset account', captured.beginCalls.length === 1 && captured.beginCalls[0]?.accountId === 'chatgpt')
      check('step6: login opens authorization popup url', captured.openCalls.length === 1 && captured.openCalls[0].includes('auth.openai.com'))
    }
    // ⑥ 登出（§3.6 凭据删除路径）+ 删除账号（W-5：凭据删除 + 池引用清理
    //    + 账号 unset 三步一次完成）。
    {
      presetMode = 'logged-in'
      if (listener6) listener6.listener()
      await new Promise((resolve) => setImmediate(resolve))
      const tree6 = await renderSettings6('step6-logout')
      captured.oauthLogoutCalls.length = 0
      const logoutBtn6 = buttonsOf(tree6).find((node) => textOf(node) === tOf('presetLogout'))
      if (logoutBtn6) logoutBtn6.props.onClick()
      await settle()
      check('step6: logout click fires oauthLogout (credential deletion)', captured.oauthLogoutCalls.length === 1 && captured.oauthLogoutCalls[0]?.accountId === 'chatgpt')
      captured.saveOps.length = 0
      captured.oauthLogoutCalls.length = 0
      const delBtn6 = buttonsOf(tree6).find((node) => textOf(node) === tOf('presetDelete'))
      if (delBtn6) delBtn6.props.onClick()
      await settle()
      const poolOps6 = captured.saveOps.filter((op) => op.path.join('/') === 'pools/main/accounts')
      const unsetOps6 = captured.saveOps.filter((op) => op.op === 'unset' && op.path.join('/') === 'oauthAccounts/chatgpt')
      check('step6: delete cleans credential + pool refs + entry (W-5)', captured.oauthLogoutCalls.length === 1 && poolOps6.length === 1 && Array.isArray(poolOps6[0].value) && poolOps6[0].value.length === 0 && unsetOps6.length === 1)
    }
    // ── EVO-002 Step 7：R7 收尾（F4 吞错 / F2 成功文案）──
    // EVO-007：通用 OAuth 官方登录区整块移除——R7-F1 的"通用区排除 preset
    // 账号"渲染过滤语义被区块删除吸收：preset 账号只经专职卡呈现，通用区
    // 文案（oauthTitle/oauthIntro/oauthAdd）零残留（旧断言 oauthSummary(0)
    // 随键删除失效，改判区块缺席）。
    // F4 旧代码忽略 ok:false 继续 unset + 弹成功提示 → 断言 unset 缺席 + 失败
    // 文案必败；F2 旧代码复用 oauthTokenBack → 断言 presetDeleted 必败。
    {
      const tree7 = await renderSettings6('step7-f1')
      check('step7: generic oauth area removed, presets surface via dedicated card (EVO-007)', textOf(tree7).includes(tOf('presetTitle')) && !textOf(tree7).includes('官方登录，插件独立管理'))
      // F4：oauthLogout 返回 ok:false → 账号条目保留（可重试）+ 展示失败消息。
      logoutFailMode = true
      captured.oauthLogoutCalls.length = 0
      captured.saveOps.length = 0
      const delFail7 = buttonsOf(tree7).find((node) => textOf(node) === tOf('presetDelete'))
      if (delFail7) delFail7.props.onClick()
      await settle()
      const unsetFail7 = captured.saveOps.filter((op) => op.op === 'unset' && op.path.join('/') === 'oauthAccounts/chatgpt')
      check('step7: logout failure keeps account entry (retry path, R7-F4)', captured.oauthLogoutCalls.length === 1 && unsetFail7.length === 0)
      check('step7: logout failure surfaces error message (R7-F4)', textOf(currentTree).includes('登出失败'))
      // F2：成功删除后提示用 presetDeleted 文案（非 oauthTokenBack）。
      logoutFailMode = false
      captured.saveOps.length = 0
      const delOk7 = buttonsOf(currentTree).find((node) => textOf(node) === tOf('presetDelete'))
      if (delOk7) delOk7.props.onClick()
      await settle()
      check('step7: delete success notice uses presetDeleted copy (R7-F2)', textOf(currentTree).includes(tOf('presetDeleted')) && !textOf(currentTree).includes(tOf('oauthTokenBack')))
      logoutFailMode = false
    }
    // 复位（不污染后续块）。
    presetMode = 'none'
    confirmMode = true
    if (listener6) listener6.listener()
    await new Promise((resolve) => setImmediate(resolve))
  }

  // route_agent 工具卡片：默认折叠（EVO-012）——摘要行（route_agent · 多模型
  // 路由 · 成功/失败 · 耗时 + 展开箭头）+ 折叠态产物缩略图（url 直达）；点击
  // 展开完整结果（标记缩略图 / 旧会话真实图片块 / 文本）。运行态显示处理中。
  // 展开助手（本区各块共用）：点击卡片摘要行 → 返回展开后的最新树。
  const expandCard = async (tree) => {
    const summary = findAll(tree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-toolcard-summary'))[0]
    if (!summary) return currentTree
    summary.props.onClick()
    return settle()
  }
  {
    const settledBlock = {
      kind: 'tool-result',
      seq: 1,
      time: 48000,
      callId: 'c1',
      call: { name: 'route_agent', argsRaw: '{"agent":"draw"}' },
      callTime: 5000,
      content: [
        { type: 'text', text: '已生成图片（1024x1024）\n[router:image:{"attachmentId":"sha256:tv","mediaType":"image/png","bytes":4,"width":2,"height":2,"name":"router-draw.png"}]' },
        { type: 'text', text: '[openai/dall-e-3 · 输入 0 / 输出 0 tokens]' },
        { type: 'image', attachment: { attachmentId: 'sha256:old', mediaType: 'image/png', bytes: 4, width: 2, height: 2 } },
      ],
      isError: false,
      subCalls: [],
    }
    captured.imageDataCalls = []
    const tree = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: settledBlock }), 'toolcard')
    const summaries = findAll(tree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-toolcard-summary'))
    check('tool card collapsed by default with summary row (EVO-012)', summaries.length === 1 && textOf(summaries[0]).includes(tOf('toolRouteTitle')) && textOf(summaries[0]).includes(tOf('statsOk')) && textOf(summaries[0]).includes('43.0s') && textOf(summaries[0]).includes('▸'))
    check('tool card collapsed hides full result content (EVO-012)', !textOf(tree).includes('已生成图片') && !textOf(tree).includes('[openai/dall-e-3'))
    check('tool card collapsed issues no imageData RPC (old markers stay off-line)', captured.imageDataCalls.length === 0)
    const expandedTree = await expandCard(tree)
    const imgs = findAll(expandedTree, (node) => node && node.type === 'img')
    // EVO-012 批二 A：无 url 字段的标记 ref（旧产物/输入回显）从 attachmentId
    // 推导直达 url——RPC 零调用（RED：批一客户端走 RPC，imageData 必调）。
    check('tool card derives asset url for url-less marker (A)', imgs.length === 2 && imgs.some((img) => img.props && img.props.src === '/router-assets/sha256%3Atv') && imgs.some((img) => img.props && img.props.src === '/router-assets/sha256%3Aold'))
    check('tool card derives legacy image block url without RPC (A)', captured.imageDataCalls.length === 0)
    check('tool card hides marker text after expand', !textOf(expandedTree).includes('[router:image:') && textOf(expandedTree).includes('已生成图片'))
    const runningBlock = { callId: 'c2', name: 'route_agent', argsRaw: '{}', turn: 1, step: 1, time: 1, callView: null, subCalls: [] }
    const running = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: runningBlock }), 'toolcard-running')
    check('tool card running state', textOf(running).includes(tOf('toolRunning')))
    // 错误结果：摘要行显示失败状态与错误消息（可观测——折叠不吞错），展开行
    // 展示错误文案。
    const failedBlock = { ...settledBlock, isError: true, error: { name: 'Error', code: 'X', message: '端点拒绝（无额度）' } }
    const failed = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: failedBlock }), 'toolcard-failed')
    check('tool card error state visible in collapsed summary (EVO-012)', textOf(failed).includes(tOf('statsFail')) && textOf(failed).includes('端点拒绝（无额度）'))
    const failedExpanded = await expandCard(failed)
    check('tool card error state expanded body', textOf(failedExpanded).includes('端点拒绝（无额度）'))

    // EVO-012 批二 A 判别（真实内容寻址 id）：标记带 url → 直接使用标记 url；
    // 无 url 的旧图片 content 块（旧会话输入回显遗留）→ 从 attachmentId 推导
    // 直达（RPC 零调用；onError 最后回退仅在真实加载失败时发生）。
    captured.imageDataCalls = []
    const urlId = `sha256:${'e'.repeat(64)}`
    const urlRef = { attachmentId: urlId, mediaType: 'image/png', bytes: 4, width: 2, height: 2, name: 'router-draw.png', url: `/router-assets/${urlId}` }
    const urlBlock = {
      kind: 'tool-result',
      seq: 5,
      time: 48000,
      callId: 'c5',
      call: { name: 'route_agent', argsRaw: '{"agent":"draw"}' },
      callTime: 5000,
      content: [
        { type: 'text', text: `已生成图片（1024x1024）\n[router:image:${JSON.stringify(urlRef)}]` },
        { type: 'image', attachment: { attachmentId: 'sha256:old', mediaType: 'image/png', bytes: 4, width: 2, height: 2 } },
      ],
      isError: false,
      subCalls: [],
    }
    const urlTree = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: urlBlock }), 'toolcard-url')
    const thumbs = findAll(urlTree, (node) => node && node.type === 'img' && hasClass(node, 'dshrouter-toolthumb'))
    check('tool card collapsed thumbnails render url markers + derived legacy (A)', thumbs.length === 2 && thumbs.some((img) => img.props.src === `/router-assets/${urlId}`) && thumbs.some((img) => img.props.src === '/router-assets/sha256%3Aold'))
    check('tool card collapsed thumbnails issue no imageData RPC (A)', captured.imageDataCalls.length === 0)
    const urlExpanded = await expandCard(urlTree)
    const expandedUrlImgs = findAll(urlExpanded, (node) => node && node.type === 'img')
    check('tool card expanded: url direct + derived legacy, zero RPC (A)', expandedUrlImgs.length === 2 && expandedUrlImgs.some((img) => img.props && img.props.src === `/router-assets/${urlId}`) && expandedUrlImgs.some((img) => img.props && img.props.src === '/router-assets/sha256%3Aold') && captured.imageDataCalls.length === 0)

    // EVO-012 批二 C：会话产物集合视图——输入区按钮（N 张；空态不渲染）→ 网格
    // → 单图放大。喂料链路：工具卡渲染标记产物 → 回写当前会话（activeId 由
    // 输入区组件 render 期锚定）→ 集合订阅重渲染。组合树驱动（同一根树上
    // input.right 与 toolview 两槽位）。
    const galleryReg = captured.registrations.find((reg) => reg && reg.id === 'router-session-gallery')
    check('session gallery slot registered in input.right (C)', !!galleryReg && typeof galleryReg.render === 'function')
    bundleExports.resetSessionGallery()
    const galleryRoot = createElement('div', {},
      galleryReg.render({ t: tOf, sessionId: 'sess-gallery-1' }),
      toolCardReg.render({ t: tOf, router: () => remoteMock, block: urlBlock }))
    const combinedTree = await renderInto(galleryRoot, 'gallery-combined')
    const galleryButtons = findAll(combinedTree, (node) => node && node.type === 'button' && textOf(node).includes('🖼'))
    // UX 2026-09-01：纯图标按钮（28×方形内「🖼 N」会竖排折行）——计数移入 title 悬停提示。
    // emoji 是 surrogate pair——文本等值比对按码点（Array.from），slice(1) 会切半个代理对。
    check('session gallery collects products from tool card (C)', galleryButtons.length === 1
      && String(galleryButtons[0].props.title ?? '').includes('1')
      && Array.from(textOf(galleryButtons[0]).trim()).join('') === '🖼')
    if (galleryButtons.length === 1) {
      galleryButtons[0].props.onClick()
      currentTree = await settle()
      // 集合只收标记派生 ref（产物）——旧图片 content 块（输入回显遗留）不入集合。
      const gridCells = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-gallery-cell'))
      check('session gallery grid renders marker products only (C)', gridCells.length === 1)
      const cellImgs = findAll(currentTree, (node) => hasClass(node, 'dshrouter-gallery-image'))
      check('session gallery cells carry direct asset urls (C)', cellImgs.length === 1 && cellImgs.some((img) => img.props && img.props.src === `/router-assets/${urlId}`))
      if (gridCells.length >= 1) {
        gridCells[0].props.onClick()
        currentTree = await settle()
        const viewer = findAll(currentTree, (node) => node && node.type === 'img' && node.props && node.props.src === `/router-assets/${urlId}` && node.props.style !== undefined && node.props.style.maxWidth === '100%')
        check('session gallery cell opens lightbox viewer (C)', viewer.length === 1)
      }
    }
    // 空态：无产物时输入区按钮不渲染（另一会话无污染——键 = sessionId）。
    bundleExports.resetSessionGallery()
    const emptyTree = await renderInto(galleryReg.render({ t: tOf, sessionId: 'sess-gallery-2' }), 'gallery-empty')
    const emptyButtons = findAll(emptyTree, (node) => node && node.type === 'button' && textOf(node).includes('🖼'))
    check('session gallery hidden when session has no products (C)', emptyButtons.length === 0)

    // ── FIX-021（EVO-012 复验失败真根因）：宿主浏览器侧把 tool-result marker
    // 结构化为 image content block 时 attachment 字段是 **id**（dsh-client-
    // ui-conversation 实证 `b.type==="image" && b.attachment` + `attachment.id`
    // ——浏览器 store 的 block 形状与持久化 jsonl 格式不同，宿主编解码层归一
    // 化为 id 字段）→ 批二代码 directAssetUrlOf 只认 url/attachmentId → 推导
    // 空 → RouteImage useEffect load() 走 imageData RPC → 宿主网关 rejected →
    // 用户见错误按钮（铁证逻辑链：directUrl 非空时 error 按钮代码不可达）。
    // 修复：兜底序 url > attachmentId > id。判别：id-only ref 渲染推导 img
    // （RED=批二代码必走 RPC）；三字段优先序逐一断言。
    console.log('FIX-021 attachment.id fallback:')
    {
      captured.imageDataCalls = []
      const idA = `sha256:${'a'.repeat(64)}`
      const idB = `sha256:${'b'.repeat(64)}`
      const fix21Block = {
        kind: 'tool-result',
        seq: 7,
        time: 48000,
        callId: 'c7',
        call: { name: 'route_agent', argsRaw: '{"agent":"draw"}' },
        callTime: 5000,
        content: [
          // ① 宿主结构化形态：仅 id 字段（无 attachmentId/url）。
          { type: 'image', attachment: { id: idA, mediaType: 'image/png', bytes: 4, width: 2, height: 2, name: 'host-shaped.png' } },
          // ② 标记形态：仅 attachmentId。
          { type: 'image', attachment: { attachmentId: idB, mediaType: 'image/png', bytes: 4, width: 2, height: 2, name: 'marker-shaped.png' } },
          // ③ url 优先：url + id 并存（历史双字段形态）→ 用 url。
          { type: 'image', attachment: { url: 'https://cdn.example/x.png', id: idA, mediaType: 'image/png', bytes: 4, width: 2, height: 2, name: 'url-shaped.png' } },
        ],
        isError: false,
        subCalls: [],
      }
      const fix21Tree = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: fix21Block }), 'toolcard-fix21')
      const fix21Thumbs = findAll(fix21Tree, (node) => node && node.type === 'img' && hasClass(node, 'dshrouter-toolthumb'))
      check('FIX-021 id-only ref derives asset url (RED: batch-2 walks RPC)', fix21Thumbs.length === 3 && fix21Thumbs.some((img) => img.props.src === `/router-assets/${encodeURIComponent(idA)}`))
      check('FIX-021 attachmentId ref still derives asset url', fix21Thumbs.some((img) => img.props.src === `/router-assets/${encodeURIComponent(idB)}`))
      check('FIX-021 url field wins over id (priority)', fix21Thumbs.some((img) => img.props.src === 'https://cdn.example/x.png'))
      check('FIX-021 zero imageData RPC calls (RED: batch-2 calls for id-only)', captured.imageDataCalls.length === 0)
      const fix21Expanded = await expandCard(fix21Tree)
      const fix21Imgs = findAll(fix21Expanded, (node) => node && node.type === 'img')
      check('FIX-021 expanded gallery keeps direct rendering, zero RPC', fix21Imgs.length === 3 && captured.imageDataCalls.length === 0)
    }
  }

  // v3 Step 9（三级展示 L3 / N-7）：route_agent 工具卡片 L3——调用参数 filePath /
  // files（非 URL 条目）→ 路径文本 + 「打开文件」→ remote.readWorkspaceFile →
  // blob 预览（audio/video 原生标签兜底，V-DSH-3 降级路径 / 其他类型下载）；
  // 打开失败显示错误码可重试。L1/L2 gallery 形态：多图并排容器（对齐宿主
  // ImageGallery 语义，同构实现——不强求 import 宿主组件）。
  {
    const l3Block = {
      kind: 'tool-result',
      seq: 3,
      time: 3,
      callId: 'c3',
      call: { name: 'route_agent', argsRaw: '{"agent":"speech","task":"转写这段音频","filePath":".router-files/voice.wav"}' },
      callTime: 3,
      content: [{ type: 'text', text: '转写完成：你好' }],
      isError: false,
      subCalls: [],
    }
    const openButtonsOf = (tree) => findAll(tree, (node) => node && node.type === 'button' && textOf(node).includes(tOf('openFile')))
    captured.readWorkspaceFileCalls = []
    readFileFailMode = false
    const l3Tree = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: l3Block }), 'toolcard-l3')
    check('tool card L3 collapsed by default (EVO-012)', !textOf(l3Tree).includes('.router-files/voice.wav'))
    const l3Expanded = await expandCard(l3Tree)
    const pathRows = findAll(l3Expanded, (node) => hasClass(node, 'dshrouter-toolpath'))
    check('tool card renders L3 path text', pathRows.length === 1 && textOf(pathRows[0]).includes('.router-files/voice.wav'))
    const openButtons = openButtonsOf(l3Expanded)
    check('tool card renders open-file button', openButtons.length === 1)
    if (openButtons.length === 1) {
      openButtons[0].props.onClick()
      currentTree = await settle()
      check('open-file calls readWorkspaceFile with path', captured.readWorkspaceFileCalls.length === 1 && captured.readWorkspaceFileCalls[0].path === '.router-files/voice.wav')
      const audios = findAll(currentTree, (node) => node && node.type === 'audio')
      check('audio player renders with blob source (native fallback)', audios.length === 1 && audios[0].props && audios[0].props.controls === true && typeof audios[0].props.src === 'string' && audios[0].props.src.startsWith('blob:'))
    }
    // 打开失败：错误码提示渲染（可重试），不渲染播放器。
    readFileFailMode = true
    captured.readWorkspaceFileCalls = []
    const failTree = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: l3Block }), 'toolcard-l3-fail')
    const failExpanded = await expandCard(failTree)
    const failButtons = openButtonsOf(failExpanded)
    if (failButtons.length === 1) {
      failButtons[0].props.onClick()
      currentTree = await settle()
      check('open-file failure shows code without player', textOf(currentTree).includes('PATH_OUTSIDE_WORKSPACE') && findAll(currentTree, (node) => node.type === 'audio').length === 0)
    }
    readFileFailMode = false
    // 视频 → <video controls>；二进制/文档 → 下载链接；URL 条目不产生 L3 行。
    const mixedBlock = { ...l3Block, call: { name: 'route_agent', argsRaw: '{"agent":"vision","task":"处理文件","files":[".router-files/clip.mp4",".router-files/notes.doc","https://example.com/x.png"]}' } }
    captured.readWorkspaceFileCalls = []
    const mixedTree = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: mixedBlock }), 'toolcard-l3-mixed')
    const mixedExpanded = await expandCard(mixedTree)
    const mixedPaths = findAll(mixedExpanded, (node) => hasClass(node, 'dshrouter-toolpath'))
    check('L3 files list skips URL entries', mixedPaths.length === 2)
    const mixedButtons = openButtonsOf(mixedExpanded)
    check('L3 renders open-file per file', mixedButtons.length === 2)
    if (mixedButtons.length === 2) {
      mixedButtons[0].props.onClick()
      currentTree = await settle()
      const videos = findAll(currentTree, (node) => node && node.type === 'video')
      check('video renders with native controls', videos.length === 1 && videos[0].props && videos[0].props.controls === true && typeof videos[0].props.src === 'string' && videos[0].props.src.startsWith('blob:'))
      const second = openButtonsOf(currentTree)
      if (second.length > 0) {
        second[0].props.onClick()
        currentTree = await settle()
        const links = findAll(currentTree, (node) => node && node.type === 'a' && typeof node.props?.download === 'string')
        check('binary/doc renders download link', links.length === 1 && links[0].props.href && links[0].props.href.startsWith('blob:') && links[0].props.download === 'notes.doc')
      }
    }
    // L1/L2 gallery 形态：多图并排容器（两张图：标记 + 旧会话真实图片块）。
    const galleryBlock = {
      kind: 'tool-result',
      seq: 4,
      time: 4,
      callId: 'c4',
      call: { name: 'route_agent', argsRaw: '{"agent":"draw"}' },
      callTime: 4,
      content: [
        { type: 'text', text: '已生成图片（1024x1024）\n[router:image:{"attachmentId":"sha256:tv","mediaType":"image/png","bytes":4,"width":2,"height":2,"name":"router-draw.png"}]' },
        { type: 'image', attachment: { attachmentId: 'sha256:old', mediaType: 'image/png', bytes: 4, width: 2, height: 2 } },
      ],
      isError: false,
      subCalls: [],
    }
    const galleryTree = await renderInto(toolCardReg.render({ t: tOf, router: () => remoteMock, block: galleryBlock }), 'toolcard-gallery')
    const galleryExpanded = await expandCard(galleryTree)
    const gallery = findAll(galleryExpanded, (node) => hasClass(node, 'dshrouter-toolgallery'))
    check('tool card renders image gallery container', gallery.length === 1)
  }

  // ── 断言：F-1（EVO-007 R0 返工）非 preset OAuth 账号删除路径恢复 ──────
  // 旧实现（65226a3）：未知 preset 账号零渲染、无任何删除入口——R8-F1
  // （EVO-004 "UI 黑箱 + 删除死锁"修复）的"可删"语义被区块删除反转，条目与
  // tokenRef 凭据永久残留（P7 数据主权缺陷）。修复后：
  // ① 池内账号行有「删除账号」入口（unset 条目 + credentials.unset(tokenRef)
  //    + 从全部池移除引用）；② 未入池孤儿账号在高级扩展区有极简删除列表。
  // 判别性：旧实现无删除按钮 → 点击分支跳过 → saveOps/credUnsetCalls 为空 →
  // 断言必败；旧"零渲染"断言若保留则与可删语义冲突（语义反转见证）。
  // 独立渲染设置页（不扰动前面断言的展开态）。
  {
    unknownPresetMode = true
    presetMode = 'none'
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'settings-r8f1', 60)
    const acctHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.accountTitle))
    check('F-1 accounts category head present', !!acctHead)
    if (acctHead) {
      acctHead.props.onClick()
      currentTree = await settle()
      const advHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.advancedSection))
      check('F-1 advanced section present', !!advHead)
      if (advHead) {
        advHead.props.onClick()
        currentTree = await settle()
        // ① 孤儿账号（stray：无 preset、未入池）在高级扩展区有极简行 + 删除入口。
        const orphanCard = () => findAll(currentTree, (node) => node && node.type === 'div' && hasClass(node, 'dshrouter-card') && textOf(node).includes('stray'))[0]
        const orphanCardFound = !!orphanCard()
        check('F-1: orphan oauth account row renders (stray)', orphanCardFound && textOf(currentTree).includes('散落账号') && textOf(currentTree).includes(zh.orphanOauthTitle))
        const orphanDel = orphanCardFound ? findAll(orphanCard(), (node) => node && node.type === 'button' && textOf(node) === zh.poolDeleteAccount)[0] : null
        check('F-1: orphan row carries delete button', !!orphanDel)
        if (orphanDel) {
          captured.saveOps.length = 0
          captured.credUnsetCalls.length = 0
          orphanDel.props.onClick()
          await settle()
          const strayUnset = captured.saveOps.filter((op) => op.op === 'unset' && op.path.join('/') === 'oauthAccounts/stray')
          check('F-1: orphan delete unsets oauthAccounts entry', strayUnset.length === 1)
          check('F-1: orphan delete clears tokenRef credential', captured.credUnsetCalls.some((call) => call.ref === 'ROUTER_OAUTH_STRAY_TOKEN'))
          check('F-1: orphan delete touches no pool ops', captured.saveOps.filter((op) => op.path[0] === 'pools').length === 0)
          check('F-1: orphan delete reports success notice', textOf(currentTree).includes(zh.oauthDeleted))
        }
        // ② 池内未知 preset 账号（weird ∈ pool main）：池行有删除入口；删除 =
        // unset 条目 + 凭据清理 + 从全部池移除引用（含当前池）。
        const poolCardHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-card-head')).find((node) => textOf(node).includes('main'))
        check('F-1: pool card head found', !!poolCardHead)
        if (poolCardHead) {
          poolCardHead.props.onClick()
          currentTree = await settle()
          check('F-1: in-pool account row renders with delete entry', textOf(currentTree).includes('怪异账号') && textOf(currentTree).includes('weird'))
          const poolCard = () => findAll(currentTree, (node) => node && node.type === 'div' && hasClass(node, 'dshrouter-card')).find((node) => {
            const head = (node.children ?? []).find((child) => child && child.type === 'button' && hasClass(child, 'dshrouter-card-head'))
            return !!head && textOf(head).includes('main')
          })
          const poolDel = poolCard() ? findAll(poolCard(), (node) => node && node.type === 'button' && textOf(node) === zh.poolDeleteAccount)[0] : null
          check('F-1: in-pool row carries delete button', !!poolDel)
          if (poolDel) {
            captured.saveOps.length = 0
            captured.credUnsetCalls.length = 0
            poolDel.props.onClick()
            await settle()
            const weirdUnset = captured.saveOps.filter((op) => op.op === 'unset' && op.path.join('/') === 'oauthAccounts/weird')
            const poolOps = captured.saveOps.filter((op) => op.path.join('/') === 'pools/main/accounts')
            check('F-1: in-pool delete unsets oauthAccounts entry', weirdUnset.length === 1)
            check('F-1: in-pool delete clears tokenRef credential', captured.credUnsetCalls.some((call) => call.ref === 'ROUTER_OAUTH_WEIRD_TOKEN'))
            check('F-1: in-pool delete strips ref from all pools', poolOps.length === 1 && Array.isArray(poolOps[0].value) && poolOps[0].value.length === 0)
          }
        }
      }
    }
    unknownPresetMode = false
    presetMode = 'none'
  }

  // ── FIX-015：统计聚合键幽灵卡判别——oauth:chatgpt 不得渲染为账号卡 ────
  // 旧代码把 stats.accountTotals 里 `oauth:` 前缀键并入 addedAccounts（→
  // AccountCard 通用 API Key 假编辑器）与 statsAccountRows（账号级统计卡）。
  // 判别：账号分类展开后整树文本不含 oauth:chatgpt（旧代码必含 → 必败）。
  // ── FIX-015：用户数据丢失 RCA 取证留档（2026-08-31，根因未定）──────────
  // 已证事实链：① 磁盘 settings.yaml models:[]；② 代码存在读写不对称缺陷
  // （显示回退已存值 vs 保存无回退 → 能造成空覆盖，但需保存点击触发）；
  // ③ 用户唯一保存点击发生在丢值之后（不构成本案因果）；④ persistPresetLogin
  // 只写凭据文件不写 settings（排除）。真凶未明——不默认归因用户操作
  // （元批评：「怀疑要有实际证据」）。防御面覆盖（本组断言 + 代码注释）：
  //   · savePresetModels 读写对称（无 draft 回退已存值）——旧代码必败判别
  //   · discoverOauth 并集合并（mergePresetModels 单点，不可缩小）——回归锁定
  //   · oauthAddToPool / addPresetAccount 新建语义（accountId 去重不覆盖）
  //     ——注释证明（静态核验：写路径全量盘点 6 条 client + 1 透传，见
  //     lib/client.js 各路径注释）
  {
    oauthGhostMode = true
    presetMode = 'none'
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'fix015-ghost', 60)
    const acctHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.accountTitle))
    if (acctHead) {
      acctHead.props.onClick()
      currentTree = await settle()
    }
    check('FIX-015: oauth: 前缀统计键不渲染为账号卡（旧代码幽灵卡必含）', !!acctHead && !textOf(currentTree).includes('oauth:chatgpt'))
    oauthGhostMode = false
    // FIX-015 c/d + 修 3：已登录空 models 账号——编辑态实预填三件套（非
    // placeholder 幻觉）、保存写入真实值、清空后保存触发防呆 notice、
    // 清空态红字提示（修 3 原语义随预填转移为「清空后」出现）。
    presetMode = 'logged-in'
    presetEmptyModelsMode = true
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'fix015-empty-models', 60)
    const presetHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.accountTitle))
    if (presetHead) {
      presetHead.props.onClick()
      currentTree = await settle()
    }
    const modelsInput = findAll(currentTree, (node) => node && node.type === 'input' && node.props['aria-label'] === zh.oauthModels)
    check('FIX-015: 已登录+空 models 编辑态实预填三件套（旧代码空值必败）', !!presetHead && !!modelsInput && modelsInput.length > 0 && modelsInput[0].props.value === 'gpt-5.6-sol, gpt-5.6-terra, gpt-5.6-luna')
    check('FIX-015: 初始态无幻觉提示（预填后提示让位于实值——旧代码空值必显示必败）', !textOf(currentTree).includes(zh.presetModelsEmpty))
    // 保存 → settings 写入真实三件套（旧代码存空 [] 必败）。
    captured.saveOps.length = 0
    const saveBtn = buttonsOf(currentTree).find((node) => textOf(node) === zh.save)
    if (saveBtn) saveBtn.props.onClick()
    await settle()
    const savedModelsOp = captured.saveOps.find((op) => op.op === 'set' && op.path.join('/') === 'oauthAccounts/chatgpt/models')
    check('FIX-015: 保存写入真实三件套（旧代码存空必败）', !!savedModelsOp && Array.isArray(savedModelsOp.value) && savedModelsOp.value.length === 3 && savedModelsOp.value[0] === 'gpt-5.6-sol' && savedModelsOp.value[1] === 'gpt-5.6-terra' && savedModelsOp.value[2] === 'gpt-5.6-luna')
    // 用户清空输入框 → 修 3 红字提示出现（预填让位后的提示语义）。
    if (modelsInput && modelsInput[0]) modelsInput[0].props.onChange({ target: { value: '' } })
    await settle()
    check('FIX-015: 清空后显示选择器提示（修 3 语义随预填转移）', textOf(currentTree).includes(zh.presetModelsEmpty))
    // 清空态保存 → 空值落盘 + 防呆 notice（旧代码「已保存」必败）。
    captured.saveOps.length = 0
    const saveBtn2 = buttonsOf(currentTree).find((node) => textOf(node) === zh.save)
    if (saveBtn2) saveBtn2.props.onClick()
    await settle()
    check('FIX-015: 清空后保存 → 防呆 notice（旧代码「已保存」必败）', textOf(currentTree).includes(zh.presetModelsEmptyNotice))
    // FIX-015 根因判别（用户数据丢失铁证：settings.yaml models:[] + 用户时间线
    // 确认保存过三件套）：账号已存 models=['gpt-5.4-mini'] + 编辑态无 draft 键
    // （重启后 presetModels state 重置）→ 点「保存」→ mutate 收到**原值**
    // ['gpt-5.4-mini']（旧代码 raw = presetModels[id] ?? '' 无回退 → 存 [] 覆盖
    // 已存值 → 必败）。读写对称：显示回退与保存回退同源。fixture 需非空
    // models——presetEmptyModelsMode 须先复位。
    presetEmptyModelsMode = false
    presetMode = 'logged-in'
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'fix015-rootcause', 60)
    const rootHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.accountTitle))
    if (rootHead) {
      rootHead.props.onClick()
      currentTree = await settle()
    }
    captured.saveOps.length = 0
    const rootSaveBtn = buttonsOf(currentTree).find((node) => textOf(node) === zh.save)
    if (rootSaveBtn) rootSaveBtn.props.onClick()
    await settle()
    const rootSavedOp = captured.saveOps.find((op) => op.op === 'set' && op.path.join('/') === 'oauthAccounts/chatgpt/models')
    check('FIX-015: 未编辑保存不覆盖已存 models（旧代码空数组覆盖必败）', !!rootSavedOp && Array.isArray(rootSavedOp.value) && rootSavedOp.value.length === 1 && rootSavedOp.value[0] === 'gpt-5.4-mini')
    // FIX-015 防御面回归锁定（非判别——旧代码 discoverOauth 同为并集语义天然
    // 不可缩小；本断言锁定 mergePresetModels 单点语义，防未来回归为覆盖写）。
    const mergeFn = bundleExports.mergePresetModels
    check('FIX-015: 发现合并并集语义——空发现不缩小已存列表（回归锁定）', typeof mergeFn === 'function' && mergeFn(['a', 'b'], []).join(',') === 'a,b' && mergeFn(['a'], ['b', 'a']).join(',') === 'a,b' && mergeFn([], []).length === 0)
    presetMode = 'none'
  }

  // ── FIX-019：换马甲幽灵卡判别——chatgpt-oauth（无冒号路由 id）─────────
  // 旧代码只按 `oauth:` 前缀过滤（FIX-015 判据）；EVO-010 起主模型经插件路由
  // 的调用统计 provider 键为无冒号路由 id 'chatgpt-oauth'（lib/oauth-llm.js
  // OAUTH_PROVIDER 常量），前缀判据失效 → addedAccounts/statsAccountRows 均
  // 并入（用户实证 2026-08-31 红字「又出现了」：已激活 · 0 个模型 · 调用 18 ·
  // 119.1K/1.0K · 展开 = 通用 API Key 假编辑器）。判别：两种统计键并存时账号
  // 卡与统计卡均不渲染二者（FIX-015 断言只覆盖 oauth: 键——chatgpt-oauth
  // 必败于旧代码）。
  {
    oauthGhostMode = true
    oauthRouteGhostMode = true
    presetMode = 'none'
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'fix019-ghost', 60)
    const fix019AcctHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.accountTitle))
    if (fix019AcctHead) {
      fix019AcctHead.props.onClick()
      currentTree = await settle()
    }
    check('FIX-019: chatgpt-oauth 路由统计键不渲染为账号卡（旧代码幽灵卡必含）', !!fix019AcctHead && !textOf(currentTree).includes('chatgpt-oauth'))
    check('FIX-019: oauth: 前缀统计键同判不回归（单点化后 FIX-015 判据仍有效）', !textOf(currentTree).includes('oauth:chatgpt'))
    // 统计分区消费同一判据（statsAccountRows 第二过滤点）：展开后不得出现两类行。
    const fix019StatsHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.statsTitle))
    if (fix019StatsHead) {
      fix019StatsHead.props.onClick()
      currentTree = await settle()
    }
    check('FIX-019: 统计账号级卡片不含 chatgpt-oauth 行（第二过滤点同判据）', !!fix019StatsHead && !textOf(currentTree).includes('chatgpt-oauth'))
    oauthRouteGhostMode = false
    oauthGhostMode = false
    presetMode = 'none'
  }

  // ── FIX-019 追加：宿主路由 openai-codex 显式排除（真 provider 形态）────
  // EVO-010 起插件把 openai-codex 目录路由维护进 llm-pi-ai settings（
  // lib/host-abi/version.js HOST_ROUTE_PROVIDER——EVO-022 B4 ①权威翻转后的
  // 单点定义，host-route.js 仅 re-export）→ 宿主 llm 目录暴露为**真 provider**
  // （active、7 个模型来自宿主官方目录、调用 0）；旧代码 addedAccounts 与
  // statsAccountRows 的 llm-pi-ai providers 来源不带任何过滤 → 渲染为假账号卡
  // （用户 ⑤ 确认截图 sha256:9fa0908e：已激活 · 7 个模型 · 调用 0 · 0/0）。
  // 判据：与统计键同点（isPluginRouteProvider 显式排除）；配置归「设置 → 模型」。
  // 判别：providers 含 openai-codex + 统计含 chatgpt-oauth/oauth:chatgpt 三种
  // 键并存 → 账号卡与统计卡均不渲染三者（旧代码必含 openai-codex 必败）。
  {
    oauthGhostMode = true
    oauthRouteGhostMode = true
    hostRouteGhostMode = true
    presetMode = 'none'
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'fix019-host-route', 60)
    const hostAcctHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.accountTitle))
    if (hostAcctHead) {
      hostAcctHead.props.onClick()
      currentTree = await settle()
    }
    check('FIX-019: openai-codex 宿主路由不渲染为账号卡（旧代码必含）', !!hostAcctHead && !textOf(currentTree).includes('openai-codex'))
    check('FIX-019: 三键并存账号卡零幽灵（chatgpt-oauth/oauth:chatgpt 同判不回归）', !textOf(currentTree).includes('chatgpt-oauth') && !textOf(currentTree).includes('oauth:chatgpt'))
    const hostStatsHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.statsTitle))
    if (hostStatsHead) {
      hostStatsHead.props.onClick()
      currentTree = await settle()
    }
    check('FIX-019: 统计账号级卡片不含 openai-codex 行（providers 来源第二过滤点）', !!hostStatsHead && !textOf(currentTree).includes('openai-codex'))
    hostRouteGhostMode = false
    oauthRouteGhostMode = false
    oauthGhostMode = false
    presetMode = 'none'
  }

  // ── 断言：①（EVO-004 出口②）按天视图 UI 面——stats.days 按天聚合表 ────
  // 旧代码 statsBody 只渲染 totals/series/recent，无 stats.days 消费面（UI 面
  // 零改动）→ 本组断言必败。构造：remoteMock.stats 返回 days（两日期聚合）。
  {
    presetMode = 'none'
    unknownPresetMode = false
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'settings-daily', 60)
    const statsHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.statsTitle))
    check('daily-view stats category head present', !!statsHead)
    if (statsHead) {
      statsHead.props.onClick()
      currentTree = await settle()
      // EVO-017 布局修正（用户裁决 2026-09-06）：按天聚合表移入「全局统计」
      // 二级卡（默认折叠）——先展开该卡再断言表内容（标题键随迁
      // statsPresetDaily）。
      const globalHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.statsGlobalLevel))
      if (globalHead) {
        globalHead.props.onClick()
        currentTree = await settle()
      }
      check('daily view renders by-day aggregate table (①)', !!globalHead && textOf(currentTree).includes(zh.statsPresetDaily) && textOf(currentTree).includes('2026-01-15') && textOf(currentTree).includes('2026-01-16'))
      check('daily view rows carry day call counts', textOf(currentTree).includes('3') && textOf(currentTree).includes('2'))
    }
  }

  // ── 断言：②（EVO-004 出口⑤）导出按钮 UI 面——statsExport RPC + CSV 下载
  // 旧代码 statsBody 无导出按钮（UI 面零改动）→ 本组断言必败。
  {
    presetMode = 'none'
    unknownPresetMode = false
    captured.statsExportCalls = []
    captured.openCalls = []
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), 'settings-export', 60)
    const statsHead = findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.statsTitle))
    if (statsHead) {
      statsHead.props.onClick()
      currentTree = await settle()
      const exportButton = buttonsOf(currentTree).find((node) => textOf(node) === zh.statsExport)
      check('export button renders in stats panel (②)', !!exportButton)
      if (exportButton) {
        exportButton.props.onClick()
        currentTree = await settle()
        check('export triggers statsExport RPC with range/level', captured.statsExportCalls.length === 1 && captured.statsExportCalls[0].range === '7d' && captured.statsExportCalls[0].level === 'agent')
        check('export downloads CSV via data: URL (②)', captured.openCalls.some((url) => url.startsWith('data:text/csv;charset=utf-8,') && decodeURIComponent(url.split(',')[1]).includes('date,agent,account,model')))
      }
    }
  }

  // ── EVO-013：预设 Agent 卡片（专业 Agent 之前 / 默认折叠 / 默认空 / 统一
  //    添加模板下拉选预设 / 保存 payload 含 presets 字典 / roster 失败降级 /
  //    残留条目「预设已不存在」提示）────────────────────────────────────────
  {
    const renderFresh = async (prefix) => {
      await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: (key) => zh[key] ?? key, $on: () => () => {} }), prefix, 60)
    }
    const categoryHeadsOf = () => findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head'))
    const presetsHeadOf = () => categoryHeadsOf().find((node) => textOf(node).includes(zh.presetsTitle))
    const entryHeadsOf = () => findAll(currentTree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-card-head'))

    // FIX-022 判别自证：apiMock 仅提供宿主真实复数域 agentPresets，不提供单数
    // 形态——旧实现（误调 api.agentPreset）在本 fixture 下无可用方法组，必败。
    check('EVO-013: fixture 仅提供宿主复数域 api.agentPresets（FIX-022）', typeof apiMock.agentPresets?.list === 'function' && !('agentPreset' in apiMock))

    // 场景 1：默认态（presets 空、roster ok）——位置/折叠/空提示/添加模板。
    presetMode = 'none'
    unknownPresetMode = false
    presetRosterMode = 'ok'
    for (const key of Object.keys(configPresets)) delete configPresets[key]
    await renderFresh('evo013-empty')
    const presetsHead = presetsHeadOf()
    const agentsHead = categoryHeadsOf().find((node) => textOf(node).includes(zh.agentsTitle))
    check('EVO-013: 预设 Agent 卡片渲染', !!presetsHead)
    check('EVO-013: 预设 Agent 位于专业 Agent 之前', !!presetsHead && !!agentsHead && categoryHeadsOf().indexOf(presetsHead) < categoryHeadsOf().indexOf(agentsHead))
    check('EVO-013: 默认折叠（aria-expanded=false）', !!presetsHead && presetsHead.props['aria-expanded'] === false)
    check('EVO-013: 默认折叠时空态提示不渲染（主体未挂载）', !textOf(currentTree).includes(zh.presetsEmpty))
    if (presetsHead) {
      presetsHead.props.onClick()
      currentTree = await settle()
      // FIX-022 判别：fixture 仅提供复数域 api.agentPresets——旧实现误调单数
      // api.agentPreset.list 时此处为 roster 错误（「Cannot read properties of
      // undefined (reading 'list')」，EV-123 真机形态）→ 本断言 RED；域名修复后 GREEN。
      check('EVO-013: 仅复数域 agentPresets 时 roster 正常加载（无错误文案，FIX-022）', !textOf(currentTree).includes(zh.presetsRosterError))
      check('EVO-013: 展开后空列表提示渲染（默认空）', textOf(currentTree).includes(zh.presetsEmpty))
      check('EVO-013: 统一添加入口渲染（+ 添加预设配置）', textOf(currentTree).includes(zh.presetsAdd))
      const addCardNode = findAll(currentTree, (node) => hasClass(node, 'dshrouter-add')).find((node) => textOf(node).includes(zh.presetsAdd))
      check('EVO-013: 添加入口为可点击卡片', !!addCardNode)
      if (addCardNode) {
        addCardNode.props.onClick()
        currentTree = await settle()
        const presetSelect = findAll(currentTree, (node) => node && node.type === 'select').find((node) => textOf(node).includes('governance'))
        check('EVO-013: 添加模板预设下拉列出宿主预设（roster 数据源）', !!presetSelect)
        const brokenOption = presetSelect ? findAll(presetSelect, (node) => node && node.type === 'option' && node.props.value === 'broken-one')[0] : null
        // R0 F-1 判别：broken-one 为宿主真实形状（非空原因字符串）——旧实现
        // 归一 `entry.broken === true` 恒 false → 不 disabled 且无标记，两条
        // 断言必败（RED）；真值归一修复后通过（GREEN）。
        check('EVO-013: string 形态 broken（宿主真实形状）不可选（disabled，R0 F-1）', !!brokenOption && brokenOption.props.disabled === true)
        check('EVO-013: string 形态 broken 带已损坏标记文案（R0 F-1）', !!brokenOption && textOf(brokenOption).includes(zh.presetsBroken))
        // 双形态判别：历史 boolean true 形态仍被真值判定兼容（不可选）。
        const legacyBrokenOption = presetSelect ? findAll(presetSelect, (node) => node && node.type === 'option' && node.props.value === 'legacy-broken')[0] : null
        check('EVO-013: boolean true 形态 broken 仍兼容（双形态判别，R0 F-1）', !!legacyBrokenOption && legacyBrokenOption.props.disabled === true)
        check('EVO-013: 展开模板含预设下拉 + 主/subagent 服务商下拉', findAll(currentTree, (node) => node && node.type === 'select').length >= 3)
        if (presetSelect) {
          presetSelect.props.onChange({ target: { value: 'governance' } })
          currentTree = await settle()
          let addConfirm = buttonsOf(currentTree).find((node) => textOf(node) === zh.add)
          check('EVO-013: 选定预设后添加按钮可用', !!addConfirm && addConfirm.props.disabled !== true)
          if (addConfirm) {
            captured.saveOps = []
            // 先填主模型服务商（夹具激活 provider = gateway）再保存——payload
            // 应携带完整草稿。每次状态更新后重取控件引用（对齐真实浏览器：
            // 点击的是最新一次渲染的按钮，闭包持最新状态）。
            const providerSelects = findAll(currentTree, (node) => node && node.type === 'select' && findAll(node, (option) => option.type === 'option' && option.props.value === 'gateway').length > 0)
            if (providerSelects[0]) providerSelects[0].props.onChange({ target: { value: 'gateway' } })
            currentTree = await settle()
            addConfirm = buttonsOf(currentTree).find((node) => textOf(node) === zh.add)
            if (addConfirm) addConfirm.props.onClick()
            currentTree = await settle()
            const setOp = captured.saveOps.find((op) => Array.isArray(op.path) && op.path[0] === 'presets' && op.path[1] === 'governance')
            check('EVO-013: 保存 payload 含 presets 字典（set op path=presets/governance）', !!setOp)
            check('EVO-013: 保存值与 presetDefaultSchema 同构（enabled/main/subagent）', !!setOp && setOp.value?.enabled === true && !!setOp.value?.main && typeof setOp.value.main === 'object' && !!setOp.value?.subagent && typeof setOp.value.subagent === 'object')
            check('EVO-013: 主模型草稿随保存下发（main.provider=gateway）', !!setOp && setOp.value?.main?.provider === 'gateway')
          }
        }
      }
    }

    // 场景 2：已配置条目（含 roster 无此 id 的残留条目）。
    configPresets.governance = { enabled: true, main: { provider: 'openai', model: 'gpt-5.6-sol' }, subagent: { provider: '', model: '' } }
    configPresets.gone = { enabled: true, main: { provider: 'gateway', model: 'm1' }, subagent: { provider: '', model: '' } }
    await renderFresh('evo013-entries')
    const presetsHead2 = presetsHeadOf()
    check('EVO-013: 卡片摘要计数（已配置 2 个预设）', !!presetsHead2 && textOf(presetsHead2).includes('2'))
    if (presetsHead2) {
      presetsHead2.props.onClick()
      currentTree = await settle()
      const entryHead = entryHeadsOf().find((node) => textOf(node).includes('governance'))
      check('EVO-013: 条目卡摘要行（预设 id · 主模型 · subagent 继承文案）', !!entryHead && textOf(entryHead).includes('openai/gpt-5.6-sol') && textOf(entryHead).includes(zh.presetsInheritMain))
      const goneHead = entryHeadsOf().find((node) => textOf(node).includes('gone'))
      check('EVO-013: roster 无此 id 的残留条目仍渲染', !!goneHead)
      if (entryHead) {
        entryHead.props.onClick()
        currentTree = await settle()
        const addCardNode2 = findAll(currentTree, (node) => hasClass(node, 'dshrouter-add')).find((node) => textOf(node).includes(zh.presetsAdd))
        if (addCardNode2) {
          addCardNode2.props.onClick()
          currentTree = await settle()
        }
        const presetSelect = findAll(currentTree, (node) => node && node.type === 'select').find((node) => textOf(node).includes('novel'))
        check('EVO-013: 已配置的预设从添加下拉排除', !!presetSelect && !textOf(presetSelect).includes('governance') && !textOf(presetSelect).includes('gone'))
      }
      if (goneHead) {
        goneHead.props.onClick()
        currentTree = await settle()
        check('EVO-013: 「预设已不存在」提示渲染', textOf(currentTree).includes(zh.presetsMissing))
      }
    }
    for (const key of Object.keys(configPresets)) delete configPresets[key]

    // 场景 3：roster 失败降级——错误提示 + 空列表，不阻塞整页。
    presetRosterMode = 'fail'
    await renderFresh('evo013-roster-fail')
    const failHead = presetsHeadOf()
    check('EVO-013: roster 失败 → 卡片仍渲染（不阻塞整页）', !!failHead)
    if (failHead) {
      failHead.props.onClick()
      currentTree = await settle()
      check('EVO-013: roster 失败 → 错误提示可见', textOf(currentTree).includes(zh.presetsRosterError))
      check('EVO-013: roster 失败 → 添加下拉为空态提示（presetsRosterEmpty）', textOf(currentTree).includes(zh.presetsAdd) || textOf(currentTree).includes(zh.presetsRosterEmpty))
    }
    presetRosterMode = 'ok'
  }

  // ── FIX-026：预设切换显示刷新——客户端直驱模型目录重载 ────────────────
  // 缺陷事实：服务端播种全对（fce2785a 四连切终态正确），显示层不跟随——
  // FIX-024 服务端 ctx.emit 在真机不可达。修复 = FIX-012 已验证模式：客户端
  // 订阅 agent-preset/selected（dsh-api-remotes API_REMOTE_FORWARDED_EVENTS
  // 首项 agent-preset/selected）直接调宿主 modelDirectories 服务 directoryFor(
  // sessionId).load()（只读幂等、generation 守卫，composer ModelSelect 经
  // uSES 订阅目录 store——load 完成即显示更新）。判别断言四组：主路径恰一
  // 次 / 服务不可达保底 RPC / directoryFor throw 不炸 + warn 可观测 / 卸载
  // off 生效。旧实现（无此订阅）对第 1/2/3 组必败 = RED。
  // ── FIX-027（EV-134）：fixture 保真度修正 + 注入声明守卫 + 遥测断言 ────
  // 缺陷事实：FIX-026 状态层/部署层全对而显示层仍断（EV-134 P10 取证链）——
  // 剩余嫌疑 = 裸 ctx.get('modelDirectories') 在客户端隔离域/注入门控下解析
  // undefined → handler 走保底 RPC（只读不更新显示）。fixture 同型 mock 保真度
  // 缺陷（旧 ctx.get 直塞服务、未复刻注入门控）已修正：get 与属性面均按模块
  // inject 声明门控（宿主 cordis-client-runner 的 dynamicCordisContext：属性访问
  // 按 fiber.inject 声明门控、get 为可选查找；声明 = 激活等待 `waitingFor`
  // 记录 + 可见性保证）。RED 判别：旧 inject 不含 modelDirectories
  // → 主路径解析 undefined → 保底 RPC → 下方场景 1 断言与结构守卫必败。
  // 修复面 = 模块 inject 声明（宿主 dsh-client-ui-model-selection 的
  // static inject / 模块级 inject + exports.inject 同款
  // 机制）+ get→属性面双形态解析（agentPresetsServiceOf 先例，定义在
  // lib/host-abi/ctx-services.js）+ 结构化 console 遥测（前缀
  // dsh-agent-router[FIX-027]；服务端上行面待后续任务——不为遥测新造 RPC 面）。
  {
    // FIX-027 结构守卫：模块 inject 声明含 modelDirectories（丢失即 EV-134
    // 缺陷复活——激活等待与属性面可见性同时失效）。
    check('FIX-027: 模块 inject 声明含 modelDirectories（结构守卫——runner 激活门控 + 属性面可见性前提）', Array.isArray(bundleExports.inject) && bundleExports.inject.includes('modelDirectories'))
    // FIX-027 遥测捕获：handler 同步触发的 info/warn 结构化行（含结果/解析形态）。
    const captureTelemetry = (fn) => {
      const lines = []
      const originalInfo = console.info
      const originalWarn = console.warn
      console.info = (...parts) => { lines.push(parts.map(String).join(' ')) }
      console.warn = (...parts) => { lines.push(parts.map(String).join(' ')) }
      try {
        fn()
      } finally {
        console.info = originalInfo
        console.warn = originalWarn
      }
      return lines
    }
    const presetEntries = captured.listeners.filter((entry) => entry.event === 'agent-preset/selected')
    check('FIX-026: agent-preset/selected 订阅经 ctx.remote.$on 装配（转发白名单首项）', presetEntries.length === 1 && typeof presetEntries[0]?.listener === 'function')
    if (presetEntries.length === 1) {
      // 派发模拟宿主远程事件总线：仅投递给仍订阅（active）的监听器——$on 退订
      // 函数置 inactive 后总线不再投递（场景 4 的判别基础）。
      const dispatch = (...args) => { if (presetEntries[0].active !== false) presetEntries[0].listener(...args) }
      // 场景 1（主路径）：modelDirectories 可达 → directoryFor(sessionId) 恰一次
      // 且参数正确，load() 恰一次，零保底 RPC（主路径短路）。
      modelDirectoriesMode = 'ok'
      modelDirectoriesGetMiss = false
      directoryForCalls.length = 0
      directoryLoadCalls.length = 0
      sessionModelsCalls.length = 0
      const mainTelemetry = captureTelemetry(() => dispatch('sess-main', 'novel-writing'))
      await new Promise((resolve) => setImmediate(resolve))
      check('FIX-026: 主路径 directoryFor(sessionId) 恰一次且参数正确（旧实现无订阅必败）', directoryForCalls.length === 1 && directoryForCalls[0] === 'sess-main')
      check('FIX-026: 主路径 directory.load() 恰一次（客户端直驱目录重载）', directoryLoadCalls.length === 1 && directoryLoadCalls[0] === 'sess-main')
      check('FIX-026: 主路径不触发保底 RPC（短路语义——遥测无 fallback-rpc 行）', !mainTelemetry.some((line) => line.includes('fallback-rpc')))
      // FIX-027：主路径遥测——结构化 info（前缀 + 结果 + 解析形态 + 标识）。
      check('FIX-027: 主路径遥测 load（前缀 dsh-agent-router[FIX-027] + form ctx.get + sessionId/preset）', mainTelemetry.length === 1 && mainTelemetry[0].startsWith('dsh-agent-router[FIX-027]') && mainTelemetry[0].includes('load') && mainTelemetry[0].includes('form ctx.get') && mainTelemetry[0].includes('sess-main') && mainTelemetry[0].includes('novel-writing'))
      // 场景 1b（幂等）：用户连切（真机四连切形态）→ load 跟随触发次数 1:1，
      // 无放大无叠加（只读幂等刷新，宿主 generation 守卫兜底）。
      dispatch('sess-main', 'cordis')
      await new Promise((resolve) => setImmediate(resolve))
      check('FIX-026: 多次切换 load 1:1 跟随无放大（只读幂等无害）', directoryForCalls.length === 2 && directoryLoadCalls.length === 2)
      // 场景 1c（FIX-027 双形态防御）：get 解析落空（'getMiss'——隔离域/注入
      // 门控下裸 get 失败的 EV-134 嫌疑形态）而属性面可用（声明后 intercept
      // 生效）→ handler 兜属性面，主路径照常 load，遥测 form=ctx.modelDirectories
      // （旧实现无属性兜底 → 保底 RPC → 必败 RED）。
      modelDirectoriesMode = 'ok'
      modelDirectoriesGetMiss = true
      directoryForCalls.length = 0
      directoryLoadCalls.length = 0
      sessionModelsCalls.length = 0
      const propTelemetry = captureTelemetry(() => dispatch('sess-prop', 'cordis'))
      await new Promise((resolve) => setImmediate(resolve))
      check('FIX-027: get 解析落空 → 属性面兜底仍走主路径 load（双形态防御——agentPresetsServiceOf 先例）', directoryForCalls.length === 1 && directoryForCalls[0] === 'sess-prop' && directoryLoadCalls.length === 1)
      check('FIX-027: 属性面兜底遥测 form ctx.modelDirectories（解析形态可观测）', propTelemetry.length === 1 && propTelemetry[0].startsWith('dsh-agent-router[FIX-027]') && propTelemetry[0].includes('form ctx.modelDirectories'))
      modelDirectoriesGetMiss = false
      // 场景 2（保底降级）：modelDirectories 服务面不可达 → 保底 session.models
      // RPC 恰一次（可观测降级不炸；保底不更新显示，主路径是 load）。
      modelDirectoriesMode = 'absent'
      directoryForCalls.length = 0
      directoryLoadCalls.length = 0
      sessionModelsCalls.length = 0
      const fallbackTelemetry = captureTelemetry(() => dispatch('sess-fallback', 'minimal'))
      await new Promise((resolve) => setImmediate(resolve))
      // FIX-028：保底 RPC 现经 createClientRemotes 适配层（EVO-020/B2 起
      // hostApiFace 迁域更名）的 sessions.models（旧
      // connection.api 面已随宿主 0.1.2-rc.1 删除——旧连接面 fixture 一并
      // 移除）；服务面不可达的降级信封 = 适配层单点结果，经
      // settingsReg.inject()（宿主等同的注入路径）取的适配 api 直断言
      // （P8 可观测：ok:false + 明确原因，禁裸 TypeError 击穿）。旧
      // sessionModelsCalls 记录器只挂在旧 apiMock 上，适配层路径下不再
      // 命中——按 P10 夹具锚定宿主面，断言指向适配层结果面。
      const fallbackEnvelope = await settingsReg.inject().api.sessions.models({ sessionId: 'sess-fallback' })
      check('FIX-026/FIX-028: 服务不可达 → 适配层 sessions.models 降级信封（ok:false + modelDirectories 原因）', fallbackEnvelope && fallbackEnvelope.result && fallbackEnvelope.result.ok === false && typeof fallbackEnvelope.result.error?.message === 'string' && fallbackEnvelope.result.error.message.includes('modelDirectories'))
      check('FIX-026: 保底路径零 load 调用（服务面不可达不误触主路径）', directoryLoadCalls.length === 0 && directoryForCalls.length === 0)
      // FIX-027：服务未就绪遥测——降级路径 warn 级结构化（P8 失败/降级可观测）。
      check('FIX-027: 服务未就绪遥测 fallback-rpc（warn 级 + 前缀 + 不可达原因）', fallbackTelemetry.length === 1 && fallbackTelemetry[0].startsWith('dsh-agent-router[FIX-027]') && fallbackTelemetry[0].includes('fallback-rpc') && fallbackTelemetry[0].includes('unavailable'))
      // 场景 3（subagent 会话防御）：directoryFor 同步 throw（宿主无 scope/
      // subagent 形态）→ 捕获不炸 + warn 级可观测（P8），且不误触发保底 RPC
      // （subagent 会话直连 session.models RPC 会被宿主拒绝——绝不降级到它）。
      modelDirectoriesMode = 'throw'
      directoryForCalls.length = 0
      directoryLoadCalls.length = 0
      sessionModelsCalls.length = 0
      const throwTelemetry = captureTelemetry(() => dispatch('sess-sub', 'standard'))
      await new Promise((resolve) => setImmediate(resolve))
      check('FIX-026: directoryFor throw 捕获不炸（事件分发链零外泄）', directoryForCalls.length === 1 && directoryLoadCalls.length === 0)
      check('FIX-026: subagent 形态降级 warn 可观测（P8：含标识与 sessionId）', throwTelemetry.some((line) => line.includes('dsh-agent-router') && line.includes('sess-sub')))
      // FIX-027：throw 遥测——错误路径 warn 级结构化（结果 + 前缀 + 标识）。
      check('FIX-027: throw 遥测 error（warn 级 + 前缀 + sessionId）', throwTelemetry.length === 1 && throwTelemetry[0].startsWith('dsh-agent-router[FIX-027]') && throwTelemetry[0].includes('error') && throwTelemetry[0].includes('sess-sub'))
      modelDirectoriesMode = 'ok'
      // 场景 4（卸载 off 生效）：装配卸载（effect cleanup 全量执行）→ 后续
      // 派发零触发（directoryFor/load/保底 RPC 全静默）。
      directoryForCalls.length = 0
      directoryLoadCalls.length = 0
      sessionModelsCalls.length = 0
      for (const cleanup of captured.effectCleanups) cleanup()
      check('FIX-026: 卸载执行了退订（$on 退订函数被调用）', presetEntries[0].active === false)
      dispatch('sess-after-off', 'novel-writing')
      await new Promise((resolve) => setImmediate(resolve))
      check('FIX-026: 卸载后派发零触发（off 生效——目录重载/保底 RPC 全静默）', directoryForCalls.length === 0 && directoryLoadCalls.length === 0)
    }
  }

  // FIX-028（宿主 0.1.1-rc.8 → 0.1.2-rc.1 兼容修复）判别组：
  // 缺陷事实：connection.api 已被宿主移除（dsh-client-connection 0.1.2-rc.1
  // 的 connection handle 面已无 `api` 字段）→ 旧 apply() `connection.api` 恒
  // undefined → 设置页整页「加载失败: Cannot read properties of undefined
  // (reading 'llm')」（用户截图 sha256:61a445ce…）。修复 = hostApiFace 适配层
  // （remote.* → 旧信封；EVO-020/B2 起迁域更名 createClientRemotes 并翻转
  // 为降级语义）+ 模块 inject 声明命名空间面（宿主官方先例
  // dsh-client-ui-settings-models 的 static `inject` 声明）。判定矩阵：
  //  F28-S 结构守卫：inject 含五个 remote.* 命名空间声明且不含 connection；
  //  F28-B 行为全链：经 settingsReg.inject()（宿主等同注入路径，非直塞旧
  //     apiMock）渲染整页 → 无「加载失败」错误面板 + 适配 api 数据面正确
  //     （providers join / models / discover 信封）；
  //  F28-F 失败可观测（P8+宿主面 Parity P9）：命名空间缺失 → 明确原因信封
  //     （禁裸 TypeError 击穿面板）——EVO-020（B2）起语义翻转为单面降级
  //     （面级降级行 + 徽章 ⚠，永不整页崩；见文末 B2 判别块）。
  {
    check('FIX-028: 模块 inject 声明 remote.llm/settings/credentials/agentPresets/session（runner 激活门控前提）', ['remote.llm', 'remote.settings', 'remote.credentials', 'remote.agentPresets', 'remote.session'].every((name) => Array.isArray(bundleExports.inject) && bundleExports.inject.includes(name)))
    check('FIX-028: 模块 inject 不再声明 connection（旧面已删除——P5 被取代路径禁止并存）', Array.isArray(bundleExports.inject) && !bundleExports.inject.includes('connection'))
    check('FIX-028: inject 面可注入（settingsReg.inject 是宿主注入路径）', typeof settingsReg?.inject === 'function' && typeof settingsReg.inject().api === 'object' && settingsReg.inject().api !== null)
    const adapter = settingsReg.inject().api
    // 适配层单点数据面（下面全部经 adapter 信封断言——旧 connection.api
    // fixture 已被移除，旧代码在此处无法构造 adapter 命名面）。
    const providersEnvelope = await adapter.llm.providers({})
    check('FIX-028: llm.providers 信封——registered∪declared 连接（active/declared 判定 + 声明序）', providersEnvelope.result.ok === true && Array.isArray(providersEnvelope.result.value.providers) && providersEnvelope.result.value.providers.length === 2 && providersEnvelope.result.value.providers[0].provider === 'openai' && providersEnvelope.result.value.providers[0].active === false && providersEnvelope.result.value.providers[0].declared === false && providersEnvelope.result.value.providers[1].provider === 'gateway' && providersEnvelope.result.value.providers[1].active === true && providersEnvelope.result.value.providers[1].declared === true && providersEnvelope.result.value.providers[1].settingsNs === 'llm-pi-ai')
    const modelsEnvelope = await adapter.llm.models({})
    check('FIX-028: llm.models 信封——modelCatalog groups/failures 映射', modelsEnvelope.result.ok === true && Array.isArray(modelsEnvelope.result.value.groups) && modelsEnvelope.result.value.groups.some((group) => group.id === 'gateway' && group.models.some((model) => model.id === 'old-m')) && modelsEnvelope.result.value.failures.length === 0)
    const discoveredEnvelope = await adapter.llm.discoverModels({ settingsNs: 'llm-pi-ai', provider: 'gateway', baseURL: 'https://gateway.example/v1' })
    check('FIX-028: llm.discoverModels 信封——裸数组 → {models} 映射 + 位置参数透传', discoveredEnvelope.result.ok === true && Array.isArray(discoveredEnvelope.result.value.models) && discoveredEnvelope.result.value.models.some((model) => model.id === 'm-b') && discoverCalls.some((call) => call.settingsNs === 'llm-pi-ai' && call.provider === 'gateway'))
    const describeEnvelope = await adapter.settings.describe({})
    check('FIX-028: settings.describe 信封——namespace view 透传（viewOf 消费形状）', describeEnvelope.result.ok === true && Array.isArray(describeEnvelope.result.value.namespaces) && describeEnvelope.result.value.namespaces.some((view) => view.ns === 'llm-pi-ai' && view.value && view.value.providers && view.value.providers.gateway))
    const credentialEnvelope = await adapter.credentials.describe({ refs: ['ROUTER_OAUTH_TOKEN'] })
    check('FIX-028: credentials.describe 信封——新直面 map → {credentials} 旧形状', credentialEnvelope.result.ok === true && credentialEnvelope.result.value.credentials && credentialEnvelope.result.value.credentials.ROUTER_OAUTH_TOKEN && credentialEnvelope.result.value.credentials.ROUTER_OAUTH_TOKEN.configured === false)
    const rosterEnvelope = await adapter.agentPresets.list({})
    check('FIX-028: agentPresets.list 信封——host 罗盘透传（broken 双形态保留）', rosterEnvelope.result.ok === true && Array.isArray(rosterEnvelope.result.value.presets) && rosterEnvelope.result.value.presets.length === 4 && rosterEnvelope.result.value.presets.some((preset) => preset.id === 'broken-one' && typeof preset.broken === 'string'))
    sessionCurrent = { provider: 'openai', model: 'gpt-4o' }
    sessionSelectCalls.length = 0
    const selectedEnvelope = await adapter.sessions.selectModel({ sessionId: 'sess-f28', provider: 'openai-router', model: 'gpt-4o' })
    check('FIX-028: sessions.selectModel 信封——remote.session.selectModel 直通', selectedEnvelope.result.ok === true && selectedEnvelope.result.value.selected && selectedEnvelope.result.value.selected.provider === 'openai-router' && sessionSelectCalls.some((call) => call.sessionId === 'sess-f28' && call.provider === 'openai-router'))
    // F28-B 行为全链：宿主注入路径渲染整页（适配 api 进组件）——ready 无错
    // 面板，且 load() 数据源确实经适配层（listProviders 计数 > 0——页面
    // load 走 api=adapter，非旧 apiMock 直塞）。
    const rawListProviders = hostFaces.llm.listProviders
    let adapterProviderCalls = 0
    hostFaces.llm.listProviders = async () => { adapterProviderCalls += 1; return rawListProviders() }
    await renderInto(settingsReg.render(settingsReg.inject()), 'fix028-fullpath')
    const fix028Tree = await settle()
    hostFaces.llm.listProviders = rawListProviders
    const fix028ErrorNodes = findAll(fix028Tree, (node) => Array.isArray(node.props?.children) && node.props.children.some((child) => typeof child === 'string' && child.includes('加载失败')))
    check('FIX-028: 宿主注入路径整页渲染零「加载失败」+ load 数据源经适配层（旧 connection.api 代码在此 fixture 下必败）', fix028ErrorNodes.length === 0 && adapterProviderCalls > 0)
    // F28-F → EVO-020（ARCH-004 B2）语义翻转：命名空间缺失从「throw →
    // 整页『加载失败』行」升级为「单面降级」（§4.3 域 1 降级行为）。同
    // fixture（stub 掉 remote.llm）下旧 throw 代码必现整页失败（上方 F28-B
    // 判别锚点的对照面——RED 演示锚点），B2 起必须：① 整页零「加载失败」；
    // ② 该面卡片降级短码入页面（面级降级行）；③ 徽章 ⚠（本地 face health
    // 进 HostHealthCard——B1 徽章数据源接通）；④ 其余面照常；⑤ apply 时
    // inject 自检记 inject-face-missing（域 5，不 throw 不阻断 apply）。
    missingFaces.add('remote.llm')
    await renderInto(settingsReg.render(settingsReg.inject()), 'b2-face-missing')
    const b2Tree = await settle()
    const b2WholePageErrors = findAll(b2Tree, (node) => Array.isArray(node.props?.children) && node.props.children.some((child) => typeof child === 'string' && child.startsWith('加载失败')))
    check('B2: remote.llm 缺失 → 整页零「加载失败」行（旧 throw 语义此 fixture 必红）', b2WholePageErrors.length === 0)
    check('B2: llm 面卡片降级短码入页面（面级降级行 llm:host-face-missing）', textOf(b2Tree).includes('llm:host-face-missing'))
    check('B2: 健康徽章 ⚠ + 缺失面行（本地 face health 进 HostHealthCard：⚠ 1 面 + ✗ llm）', textOf(b2Tree).includes(zh.hostHealthWarn(1)) && textOf(b2Tree).includes('✗ llm'))
    // FIX-046 非回归：取数面正常时面板**不得**出现失败行（反向判据——失败行
    // 只在取数失败时出现，禁止恒显/误显），且版本行显示真实宿主版本值而非回落。
    check('FIX-046 非回归: 取数正常时零宿主面取数失败行 + 版本行显示真实值（非 ? 回落）', !textOf(b2Tree).includes(zh.hostHealthRpcFailed('')) && textOf(b2Tree).includes('9.9.9-a') && textOf(b2Tree).includes('7.7.7-c'))
    const b2PresetsHead = findAll(b2Tree, (node) => node && node.type === 'button' && hasClass(node, 'dshrouter-category-head')).find((node) => textOf(node).includes(zh.presetsTitle))
    if (b2PresetsHead) {
      b2PresetsHead.props.onClick()
      currentTree = await settle()
    }
    // agentPresets 面（罗盘）渲染级锚点：添加预设展开 → roster 名入下拉
    // （数据源 = remote.agentPresets.list——与缺失的 llm 面零耦合）。
    const b2AddPreset = findAll(currentTree, (node) => hasClass(node, 'dshrouter-add')).find((node) => textOf(node).includes(zh.presetsAdd))
    if (b2AddPreset) {
      b2AddPreset.props.onClick()
      currentTree = await settle()
    }
    check('B2: 其余面正常——agentPresets 罗盘照常（添加预设下拉含 Governance 预设）', textOf(currentTree).includes('Governance 预设'))
    // settings/session/credentials 面（适配器级锚点，同一注入路径 ctx）：llm
    // 降级信封与兄弟面 ok 信封并存（渲染级锚点受 llm 耦合数据源限制——账号
    // 卡/模型下拉均以 llm.providers 为前置，适配器级断言为「其余面正常」的
    // 完备补面；宿主注入路径 = settingsReg.inject()）。
    const b2Settings = await settingsReg.inject().api.settings.describe({})
    const b2Session = await settingsReg.inject().api.llm.models({})
    const b2Credentials = await settingsReg.inject().api.credentials.describe({ refs: [] })
    const b2Llm = await settingsReg.inject().api.llm.providers({})
    check('B2: 其余面正常——settings/session/credentials ok 而 llm 降级（同 ctx 单面隔离）', b2Settings.result.ok === true && b2Session.result.ok === true && b2Credentials.result.ok === true && b2Llm.result.ok === false && b2Llm.result.error.code === 'host-face-missing')
    // 域 5 apply 自检：remote.llm 缺失下重新 apply → inject-face-missing 记入
    // 诊断环形（模块级共享——settingsReg.inject().health().diag 可见），
    // apply 本身不 throw 不阻断（§4.3 域 5 降级行为）。
    let b2ReapplyBlocked = false
    try { bundleExports.apply(ctx) } catch { b2ReapplyBlocked = true }
    const b2InjectDiag = settingsReg.inject().health().diag
    check('B2: apply 时 inject 自检记 inject-face-missing（remote.llm 缺面可视化，apply 不阻断）', !b2ReapplyBlocked && b2InjectDiag.some((entry) => entry.kind === 'inject-face-missing' && entry.face === 'remote.llm'))
    missingFaces.clear()
  }

  // ── EVO-023（ARCH-004 B5）：客户端订阅面收敛 + 设置页轮询治理判别 ────────
  // 1) D-2 死订阅修复判别（§0.5 Analyst D-2 / §4.3 域 4 能力探测）：旧代码
  //    订 credentials/updated——该名不在宿主转发白名单（单一声明源
  //    dsh-api-remotes/lib/types/remote-events.js 全表无此名），宿主从未转发
  //    → 凭据变化不触发刷新（死订阅）。修复 = 正名 credentials/
  //    reference-updated + 订阅经 events 域镜像白名单拒绝外名。判别：以真实
  //    $on 捕获面渲染整页 → 旧名下零订阅（RED：旧代码此处页面订阅名 = 死名）
  //    且派发正名事件必须触发刷新链路（load() 重跑 → catalog RPC）。
  // 2) 设置页 2s 双 RPC 轮询治理（D1-10，症状②首要嫌疑面）：页面隐藏暂停
  //    （隐藏态零 RPC）+ 双 RPC（stats/presetDiagnostics）同拍单 timer；判别
  //    断言 = 隐藏态 0 RPC、可见态每拍恰 2 RPC（≤1 RPC/s 量级）、渲染期无
  //    新增常驻 timer（timer census 与迁移前一致：2s 轮询 1 + 30s catalog 1）。
  {
    const pageSubs = []
    const capturedOn = (event, listener) => {
      const entry = { event, listener, active: true }
      pageSubs.push(entry)
      return () => { entry.active = false }
    }
    let catalogCalls = 0
    const rawCatalog = remoteMock.catalog
    remoteMock.catalog = async (...args) => { catalogCalls += 1; return rawCatalog(...args) }
    const timerMark = captured.timers.length
    const docListenerMark = captured.documentListeners.length
    pollRpc.stats = 0
    pollRpc.presetDiagnostics = 0
    await renderInto(settingsReg.render({ api: apiMock, remote: () => remoteMock, remoteReady: Promise.resolve(), t: tOf, $on: capturedOn }), 'b5-events')
    await settle(60)
    const deadSubs = pageSubs.filter((entry) => entry.event === 'credentials/updated')
    const refSubs = pageSubs.filter((entry) => entry.event === 'credentials/reference-updated')
    check('B5 D-2: 设置页订阅正名 credentials/reference-updated（白名单锚 API_REMOTE_FORWARDED_EVENTS）——死名 credentials/updated 零订阅', deadSubs.length === 0 && refSubs.length === 1)
    const modelsSubs = pageSubs.filter((entry) => entry.event === 'llm/models-updated')
    check('B5 D-2: 页面其余转发订阅在位（settings/document-updated + llm/adapters-updated——域管事件清单内；ARCH-007 增补 llm/models-updated 恰一站）', pageSubs.some((entry) => entry.event === 'settings/document-updated') && pageSubs.some((entry) => entry.event === 'llm/adapters-updated') && modelsSubs.length === 1)
    const catalogBeforeCred = catalogCalls
    for (const entry of refSubs) entry.listener()
    await new Promise((resolve) => setImmediate(resolve))
    check('B5 D-2 判别: 正名事件派发 → 账号卡刷新链路触发（load() 重跑 → catalog RPC；旧死名订阅在此必不触发 = RED）', catalogCalls > catalogBeforeCred)
    // ARCH-007（D1 宿主 0.2.2 事件面）：llm/models-updated 与 llm/adapters-updated 分列
    // 于 typert 双签名（models-updated(provider) 单独广播模型清单变化）⇒ 设置页模型面板
    // 必须同样刷新（旧代码只订 adapters-updated 会漏掉纯模型变化，模型下拉陈旧）。
    const catalogBeforeModels = catalogCalls
    for (const entry of modelsSubs) entry.listener()
    await new Promise((resolve) => setImmediate(resolve))
    check('B5 D-2 ARCH-007 判别: llm/models-updated 派发 → 模型刷新链路触发（catalog RPC；旧代码不订此名在此必不触发 = RED）', modelsSubs.length === 1 && catalogCalls > catalogBeforeModels)

    // 轮询治理（D1-10）：单 2s timer 承载双 RPC 同拍；隐藏态零 RPC。
    const b5Timers = captured.timers.slice(timerMark)
    const pollTimers = b5Timers.filter((timer) => timer.ms === 2000 && !timer.cleared)
    check('B5 D1-10: 设置页 2s 轮询为单 timer（双 RPC 同拍，非每 RPC 各起 timer）', pollTimers.length === 1 && b5Timers.filter((timer) => !timer.cleared).length === 1)
    check('B5 D1-10: 渲染期无新增常驻 timer——本实例仅新增 1 个 2s 轮询 timer（无其他新 timer；30s catalog 兜底仍为 apply 单例）', b5Timers.filter((timer) => !timer.cleared).length === 1 && b5Timers.every((timer) => timer.ms === 2000) && captured.timers.filter((timer) => !timer.cleared && timer.ms === 30000).length === 1)
    const pollTick = pollTimers[0]
    fakeWindow.document.hidden = false
    pollRpc.stats = 0
    pollRpc.presetDiagnostics = 0
    for (let index = 0; index < 5; index += 1) pollTick.fn()
    await new Promise((resolve) => setImmediate(resolve))
    check('B5 D1-10: 可见态 5 拍 → stats 5 + presetDiagnostics 5（双 RPC 同拍，每拍恰 2 RPC）', pollRpc.stats === 5 && pollRpc.presetDiagnostics === 5)
    check('B5 D1-10: 稳态 RPC 频率 ≤1 RPC/s 量级（2 RPC / 2s = 1 RPC/s）', (pollRpc.stats + pollRpc.presetDiagnostics) / (5 * 2) <= 1)
    fakeWindow.document.hidden = true
    const hiddenStats = pollRpc.stats
    const hiddenDiag = pollRpc.presetDiagnostics
    for (let index = 0; index < 5; index += 1) pollTick.fn()
    await new Promise((resolve) => setImmediate(resolve))
    check('B5 D1-10: 隐藏态零 RPC（页面隐藏暂停——症状②防御判别；旧代码此断言必红）', pollRpc.stats === hiddenStats && pollRpc.presetDiagnostics === hiddenDiag)
    fakeWindow.document.hidden = false
    for (const entry of captured.documentListeners.slice(docListenerMark).filter((item) => item.type === 'visibilitychange')) entry.handler()
    await new Promise((resolve) => setImmediate(resolve))
    check('B5 D1-10: 恢复可见立即补拍一次（visibilitychange 唤醒——实时语义保留，不丢一轮）', pollRpc.stats === hiddenStats + 1 && pollRpc.presetDiagnostics === hiddenDiag + 1)
  }

  // ── FIX-046（P8）：宿主面取数失败/降级 MUST 可观测（禁无观测吞错）────────
  // 真机 V-1 报障形态：设置页「Agent 路由」宿主面健康面板 = 本地 face 探针
  // 五面全绿 + 宿主版本三值恒 '?' + 诊断事件恒空。旧实现三处静默（方法缺失
  // 跳过 / rejection 吞为 undefined / ok:false 与形状非法静默保留 null）使
  // 该形态与「健康」不可区分——本组六形态逐一判别：失败**必须**产生明确
  // 诊断（短码 + 详情）并上屏，且**不得**再回落为「暂无诊断事件」。
  //
  // 判别性（RED 口径，R0 F-7 勘正后）：case 2/3/4/5/6 的失败断言面（失败徽章
  // 文案 / 失败行 / 诊断行短码 / 版本行「不可读」标记）在旧实现下**全部不存在**
  // （旧代码无任何 notice 状态与渲染面）⇒ 对旧实现必红；case 1 为**非回归对照**
  // （成功路径新旧皆绿——其断言面均为既有渲染面）、FIX-046-2b 的面探针标题断言
  // 为面数据源保留守卫（亦非判别）——真机版本三值为 '?' 属另一环境事实
  // （EV-214，根因见 EV-217），不构成本组 case 1 的 RED 依据。
  // 形态锚定（P10-④）：**本仓权威面** = lib/schemas.js `hostFaceDiagnosticsResult`
  // 三键结果形状 + lib/service.js `hostFaceDiagnostics()` 供数方法；失败信封
  // `{ ok:false, error:{ code, message } }` 与本仓同型用例一致
  // （tests/host-abi-health.mjs 的 `{ok:false,error:{code}}` 面）。**R0 F-6
  // 勘正**：此前登记的「真机定因 = 宿主网关 wire 字段对齐拒绝」已被证伪
  // （EV-216 真机 stats RPC 成功反证；EV-217 真机定因 = 客户端 `$mount` 缺
  // descriptor），本组断言不依赖亦不声称该形态。
  // FIX-047 续判（同组内，口径同上：旧实现对应断言必败，逐 case 注释给出唯一
  // 变量）：① F-16 stats 轮询 reject 必须机录诊断环（旧 `() => undefined` 吞错）；
  // ② F-10 非空 faces/diag 条目逐字段上屏（原夹具恒空 ⇒ codec 形状面零行使）；
  // ③ F-12 effect 重跑失败必须清陈旧 RPC 快照；④ F-11 双源皆缺时失败通知仍上屏
  // （旧早退条件吞掉唯一必须上屏的信息）；⑤ N-2 失败 ∧ 降级并存的折叠态双信息
  // 可见（最小改法 = summary 单点合成，见 lib/client.js 同段注释）。
  console.log('FIX-046: host face fetch observability (P8):')
  {
    // 每形态独立 remote：（a）携带各自 hostFaceDiagnostics；（b）模块级诊断环
    // 与面板展示严格同拍——六形态各判各的（互不继承 notice 状态）。
    const renderHostFace = async (prefix, method) => {
      // 浅拷贝 + 按需覆盖宿主面方法：'absent' 用**自有属性置 undefined** 表达
      // 「该方法不存在」（delete 只摘自有属性时原型链仍可达，判别会假绿）。
      // 其余注入面（api/health/remoteReady/t/$on）复用注册点自述注入
      // （settingsReg.inject()——与生产 render 路径同源），只替换 remote 取数。
      const router = { ...remoteMock }
      if (method === 'absent') router.hostFaceDiagnostics = undefined
      if (method === 'noRemote') {
        // F-5：`host-face-missing` 分支覆盖。诚实登记**可达前提**：生产装配下
        // `remote.router` 缺失会使首页 load() 早退为错误态（lib/client.js 的
        // load 守卫），面板本身不渲染 ⇒ 该分支是**防御分支**，仅在「面板已渲染
        // 后命名空间才消失」（Remote 热卸载/重挂——`injected()` 每次经
        // `ctx.get('remote.router') ?? null` 动态解析）时可达。此处以
        // 「首轮解析成功、面板首屏渲染后解析落空」的状态化 stub 复现该时序：
        // 自检 effect 的 deps 含 `remote`（其身份不变）⇒ 不重跑；重跑来自
        // 同页 stats 卡的 `clearStats` 路径（clear 按钮回调）——复现「取数时点
        // 命名空间已消失」。
        remoteAbsentMode = true
        let resolved = false
        await renderInto(settingsReg.render({ ...settingsReg.inject(), remote: () => (resolved ? null : (resolved = true, remoteMock)) }), prefix)
        const tree = await settle()
        remoteAbsentMode = false
        return tree
      }
      await renderInto(settingsReg.render({ ...settingsReg.inject(), remote: () => router }), prefix)
      return settle()
    }
    // 折叠态可见性判别（F-2）：summary 元素的文本面 = 用户无需展开即读到的内容。
    const summaryTextOf = (tree) => {
      const details = findAll(tree, (node) => node && node.type === 'details' && hasClass(node, 'dshrouter-notice'))
      if (details.length === 0) return ''
      const summary = findAll(details[0], (node) => node && node.type === 'summary')
      return summary.length > 0 ? textOf(summary[0]) : ''
    }
    /** 取该渲染树的折叠面板展开文本（既有组一律经 textOf 读全树——文本判据面）。 */
    const hfTexts = (tree) => ({ all: textOf(tree), summary: summaryTextOf(tree) })

    // case 1（非回归对照面）：取数成功 → 宿主版本三值真实上屏（真机期望面）。
    hostFaceMode = 'ok'
    const hfOk = await renderHostFace('fix046-ok')
    const hfOkText = textOf(hfOk)
    check('FIX-046-1: 取数成功 → 宿主版本三值真实上屏（非 ? 回落）且零失败行', hfOkText.includes('9.9.9-a') && hfOkText.includes('8.8.8-b') && hfOkText.includes('7.7.7-c') && !hfOkText.includes(zh.hostHealthRpcFailed('')))

    // case 2：宿主面方法缺失（该方法在浏览器侧挂载列表/宿主命名空间不可用——
    // FIX-047 N-6 措辞中性化，不预设宿主单因）→ 必须显式
    // 诊断 + 上屏（旧实现静默跳过：面板全绿 + 版本 '?' + 诊断恒空）。
    const hfAbsent = await renderHostFace('fix046-method-absent', 'absent')
    const hfAbsentText = textOf(hfAbsent)
    const hfAbsentSummary = summaryTextOf(hfAbsent)
    check('FIX-046-2: 方法缺失 → 明确诊断上屏（short code host-face-shape + 版本行「不可读」标记；旧实现此断言必红）',
      hfAbsentText.includes('host-face-shape: hostFaceDiagnostics') && hfAbsentText.includes(zh.hostHealthVersionsUnavailable) && hfAbsentText.includes(zh.hostHealthRpcFailed('host-face-shape: hostFaceDiagnostics')))
    check('FIX-046-2: 方法缺失的诊断进「最近宿主诊断事件」区（kind + code 机录，禁「暂无诊断事件」替代）',
      hfAbsentText.includes('host-face-rpc') && hfAbsentText.includes('(host-face-shape: hostFaceDiagnostics)') && !hfAbsentText.includes(zh.hostHealthNoDiag))
    check('FIX-046-2: 方法缺失下本地 face 探针快照保留（失败不改写面数据源——面数仍为本地五面派生）', hfAbsentText.includes(zh.hostHealthFacesTitle))
    // F-2（R0）：失败短码 MUST 在**折叠态即可见**（`<details>` 默认折叠 ⇒ 只
    // summary 文本可见；原实现把短码放进折叠体内 ⇒「直接看到失败原因」不成立）。
    check('FIX-046-2: 失败短码在折叠态（summary 文本）即直接可见——无需展开（R0 F-2；旧实现 summary 无短码此断言必红）',
      hfAbsentSummary.includes('host-face-shape: hostFaceDiagnostics') && hfAbsentSummary.includes(zh.hostHealthRpcFailed('host-face-shape: hostFaceDiagnostics')))
    // F-3（R0）：失败态徽章 MUST NOT 仍渲染 `✓ 宿主面正常`（`degraded` 只由面数
    // 派生 ⇒ 原实现失败与绿色徽章同排，显示层语义自相矛盾）。
    check('FIX-046-2: 失败态徽章不渲染「✓ 宿主面正常」（R0 F-3；旧实现 degraded=0 ⇒ 失败与绿徽章同排）',
      !hfAbsentText.includes(zh.hostHealthOk) && hfAbsentSummary.includes(zh.hostHealthRpcFailed('host-face-shape: hostFaceDiagnostics')))

    // case 3：调用 reject（宿主侧抛错/传输失败形态）→ 诊断 detail 携带宿主错误。
    hostFaceMode = 'throw'
    const hfThrow = await renderHostFace('fix046-throw')
    const hfThrowText = textOf(hfThrow)
    check('FIX-046-3: 调用 reject → 明确诊断（Error 名/消息入 detail，禁 `() => undefined` 吞噬；旧实现此断言必红）',
      hfThrowText.includes('router gateway rejected hostFaceDiagnostics') && hfThrowText.includes('(Error)') && !hfThrowText.includes(zh.hostHealthNoDiag))

    // case 4：宿主失败信封 → 诊断须携带宿主 code（下一轮排障可直接读出）。
    hostFaceMode = 'notOk'
    const hfNotOk = await renderHostFace('fix046-not-ok')
    const hfNotOkText = textOf(hfNotOk)
    check('FIX-046-4: ok:false 信封 → 诊断携带宿主 error.code + message（旧实现静默保留 null，此断言必红）',
      hfNotOkText.includes('(gateway/arguments-invalid)') && hfNotOkText.includes('missing "request"') && hfNotOkText.includes(zh.hostHealthRpcFailed('gateway/arguments-invalid')))

    // case 5：结果缺 hostVersions（形状非法）→ 显式 result-shape 诊断，禁静默
    // 回落为 '?' 而不留痕。
    hostFaceMode = 'noVersions'
    const hfShape = await renderHostFace('fix046-result-shape')
    const hfShapeText = textOf(hfShape)
    check('FIX-046-5: 结果缺 hostVersions → 显式 host-face-result-shape 诊断（版本三值回落必须有痕；旧实现此断言必红）',
      hfShapeText.includes('(host-face-result-shape)') && hfShapeText.includes(zh.hostHealthVersionsUnavailable) && !hfShapeText.includes(zh.hostHealthNoDiag))

    // case 6（F-5 补覆盖）：响应非信封对象（宿主动词返回值形态漂移）→ 必须走
    // host-face-result-invalid 分支，禁静默（旧实现「ok:false 与形状非法静默
    // 保留 null」⇒ 此断言必红）。
    hostFaceMode = 'plain'
    const hfPlain = await renderHostFace('fix046-result-invalid')
    const hfPlainText = textOf(hfPlain)
    const hfPlainSummary = summaryTextOf(hfPlain)
    check('FIX-046-6: 响应非信封对象 → 显式 host-face-result-invalid 诊断（含响应戳记）且折叠态可见（R0 F-5 补覆盖；旧实现此断言必红）',
      hfPlainText.includes('(host-face-result-invalid)') && hfPlainText.includes('not-an-envelope') && !hfPlainText.includes(zh.hostHealthNoDiag) && hfPlainSummary.includes('host-face-result-invalid'))

    // case 7（F-5 补覆盖）：remote.router 命名空间整体缺失 → host-face-missing
    // 短码（与「方法缺失」区分；旧实现 `if (!routerRemote) return` 静默 ⇒ 必红）。
    hostFaceMode = 'ok'
    const hfNoRemote = await renderHostFace('fix046-namespace-missing', 'noRemote')
    const hfNoRemoteText = textOf(hfNoRemote)
    const hfNoRemoteSummary = summaryTextOf(hfNoRemote)
    check('FIX-046-7: remote.router 命名空间缺失 → 显式 host-face-missing 诊断且折叠态可见（R0 F-5 补覆盖；旧实现静默跳过此断言必红）',
      hfNoRemoteText.includes('(host-face-missing)') && hfNoRemoteText.includes(zh.hostHealthVersionsUnavailable) && !hfNoRemoteText.includes(zh.hostHealthNoDiag) && hfNoRemoteSummary.includes('host-face-missing'))

    // F-1（R0）：失败行 MUST **并列**于诊断全集（原实现以失败行替换 diag 全集 ⇒
    // 本地镜像环条目被静默隐藏）。每形态独立渲染 ⇒ 本地环条目此刻恒在场
    // （apply 期 noteHostFaceDiag 写入——本文件 fixtures 先例），断言 = 失败行
    // 短码与本地条目名**同时**出现于诊断区。
    check('FIX-046-8: 失败行与本地镜像环诊断条目并列（禁失败行替换 diag 全集；R0 F-1——旧实现丢失本地条目此断言必红）',
      hfAbsentText.includes('(host-face-shape: hostFaceDiagnostics)') && hfAbsentText.includes('inject-face-missing'))

    // ── FIX-047 续判（R0 F-10/F-11/F-12/F-16 + R1 N-2；每条唯一变量）──────
    // 共享观察面：诊断环 = settingsReg.inject().health().diag（B2 组既有先例
    // ——模块级镜像环的公开读面）；折叠态文本 = summaryTextOf；报告面置空的
    // health stub 使「文本面出现某条」只可能来自被判别的那一侧数据源。
    const emptyHealth = () => ({ faces: [], diag: [] })
    // F-16（R0 P3／P8 同族）：stats 轮询 reject 此前 `() => undefined` 吞错——
    // 页面与诊断环均无痕。唯一变量 = statsFailMode（同一渲染路径、同一 remote）；
    // 判别 = 环内出现 host-face-stats-rejected 且 detail 携带原始错误消息
    // （旧实现下环内零该条目 ⇒ 此断言必红）。
    const statsDiagOf = () => settingsReg.inject().health().diag.filter((entry) => entry.code === 'host-face-stats-rejected')
    const statsDiagBefore = statsDiagOf().length
    statsFailMode = true
    try {
      await renderInto(settingsReg.render({ ...settingsReg.inject(), remote: () => ({ ...remoteMock }) }), 'fix047-stats-rejected')
      await settle()
    } finally {
      statsFailMode = false
    }
    const statsDiagAfter = statsDiagOf()
    check('FIX-047-F16: stats 轮询 reject → 诊断环机录 host-face-stats-rejected + 原始错误消息（禁 `() => undefined` 吞错；R0 F-16——旧实现此断言必红）',
      statsDiagBefore === 0 && statsDiagAfter.length > 0 && statsDiagAfter.every((entry) => entry.kind === 'host-face-rpc' && entry.face === 'remote.router' && String(entry.detail).includes('stats gateway rejected')))
    // 同批引入的**边沿触发**语义 MUST 有判据（P4）：持续失败不逐拍追加（否则
    // 64 条环上限被单一失败挤满、既有诊断被淘汰 = 观测面自伤）；成功一拍复位 ⇒
    // 下一失败周期重新记一条。判别 = 同一失败周期再推 3 拍后条数不变；随后
    // 「失败 → 成功一拍 → 再失败」恰 +1（旧实现吞错则两侧恒 0；若去掉边沿触发
    // 则同周期 +3 ⇒ 此断言必红）。
    const statsTimer = captured.timers.filter((timer) => timer.ms === 2000 && !timer.cleared).pop()
    // FIX-047 R0 P3（Rework）：harness 面形态守卫——原写法直接 `statsTimer.fn()`，
    // 一旦 timer 未被捕获（该渲染路径不再产生 2s timer / clearInterval 标记异常），
    // 即以 TypeError **崩掉整个 runner 模块**：本组后续断言全丢、失败退化为裸崩栈
    // 而非一条 FAIL。现改为**结构化 FAIL + 空驱动**（诊断携 timer census，形态漂移
    // 可定位），runner 不崩、后续断言照跑。
    check('FIX-047-F16b[harness]: 2s stats 轮询 timer 已被 harness 捕获且未清除（缺失 ⇒ 结构化 FAIL，不崩 runner；R0 P3）',
      Boolean(statsTimer) && typeof statsTimer.fn === 'function',
      { capturedTimers: captured.timers.length, nonClearedMs: captured.timers.filter((timer) => !timer.cleared).map((timer) => timer.ms) })
    const tickStatsTimer = statsTimer && typeof statsTimer.fn === 'function' ? statsTimer.fn : () => {}
    statsFailMode = true
    for (let index = 0; index < 3; index += 1) tickStatsTimer()
    await settle()
    const statsDiagWithinEpisode = statsDiagOf().length
    statsFailMode = false
    tickStatsTimer()
    await settle()
    statsFailMode = true
    tickStatsTimer()
    await settle()
    statsFailMode = false
    // FIX-047 R0 P3（Rework）：显式**基线非空前提**——`statsDiagWithinEpisode ===
    // statsDiagAfter.length` 在该窗口零记录时同样成立（`0 === 0`），此前判别力依赖
    // **前置** F-16 断言的非空 guard（`statsDiagAfter.length > 0`）这一隐式前提；断言
    // 顺序调整 / 前置被改即退化为空洞绿。显式写入 `statsDiagAfter.length > 0` 后，
    // 基线为空即判红（不再静默通过），判别力不再外挂于另一条断言。
    check('FIX-047-F16b: 边沿触发——同失败周期 3 拍不追加（统计轮询 2s 拍不挤满 64 条环）+ 成功复位后新周期恰 +1（含基线非空前提，防「0 === 0」空洞绿；R0 P3）',
      statsDiagAfter.length > 0 && statsDiagWithinEpisode === statsDiagAfter.length && statsDiagOf().length === statsDiagAfter.length + 1,
      { baseline: statsDiagAfter.length, withinEpisode: statsDiagWithinEpisode, final: statsDiagOf().length })

    // F-10（R0 P3）：原夹具成功分支 faces/diag **恒空** ⇒ lib/schemas.js 的
    // `faceHealthCodec` / `hostDiagEntryCodec` 形状面在渲染组零行使。唯一变量 =
    // hostFaceMode='withEntries'（非空条目）+ 本地面置空（⇒ 文本面只可能来自 RPC
    // 面）；判别 = faces 的 name/state/detail 与 diag 的 kind/face/code/detail
    // 逐字段上屏（旧夹具下这些串不存在 ⇒ 此断言必红）。
    hostFaceMode = 'withEntries'
    const hfEntriesText = textOf(await renderInto(settingsReg.render({
      ...settingsReg.inject(), remote: () => ({ ...remoteMock }), health: emptyHealth,
    }), 'fix047-rpc-entries'))
    check('FIX-047-F10: RPC 面非空 faces 条目逐条上屏（name/state/detail 三字段消费；R0 F-10——原夹具恒空此断言必红）',
      hfEntriesText.includes('⚠ host-probe-alpha (face detail: codec 形状样例)') && hfEntriesText.includes('✓ host-probe-beta'))
    check('FIX-047-F10: RPC 面非空 diag 条目逐条上屏（kind/face/code/detail 四字段消费；R0 F-10）',
      hfEntriesText.includes('face-state host-probe-alpha (degraded) hostDiagEntryCodec 形状样例'))
    hostFaceMode = 'ok'

    // F-12（R0 P3）：effect 重跑后失败时陈旧 hostHealth 未清 ⇒ 旧 RPC 快照与失败
    // 行并存。唯一变量 = 第二次取数形态（同前缀 ⇒ harness 复用同一组件实例、
    // 状态跨渲染保留；第一次 = 成功且 faces 非空，第二次 = reject）；判别 = 第二次
    // 渲染文本中旧面条目消失（旧实现下陈旧值仍在 ⇒ 此断言必红）。
    hostFaceMode = 'withEntries'
    const staleFirstTree = await renderInto(settingsReg.render({
      ...settingsReg.inject(), remote: () => ({ ...remoteMock }), health: emptyHealth,
    }), 'fix047-stale-cache')
    const staleFirstText = textOf(staleFirstTree)
    hostFaceMode = 'throw'
    const staleAfterFailureText = textOf(await renderInto(settingsReg.render({
      ...settingsReg.inject(), remote: () => ({ ...remoteMock }), health: emptyHealth,
    }), 'fix047-stale-cache'))
    hostFaceMode = 'ok'
    check('FIX-047-F12: effect 重跑失败清理陈旧 RPC 快照（判别项 = 旧成功面的 faces 行消失，版本值由失败分支接管；R0 F-12——旧实现陈旧 faces 行仍在 ⇒ 此断言必红）',
      staleFirstText.includes('host-probe-alpha') && staleAfterFailureText.includes('(Error)') && !staleAfterFailureText.includes('host-probe-alpha') && !staleAfterFailureText.includes('9.9.9-a'))

    // F-11（R0 P3）：双源皆缺（health 面不可用 ⇒ faceHealth 恒 null + 取数失败 ⇒
    // hostHealth 为 null）时旧早退条件把失败通知一并吞掉（卡片整体不渲染）。
    // 唯一变量 = health 返回非对象；判别 = 失败短码与「宿主版本不可读」仍在文本中
    // （旧实现下卡片为 null ⇒ 这些串零出现，此断言必红）。
    hostFaceMode = 'throw'
    const hfDoubleMissing = await renderInto(settingsReg.render({
      ...settingsReg.inject(), remote: () => ({ ...remoteMock }), health: () => undefined,
    }), 'fix047-double-missing')
    const hfDoubleMissingTree = await settle()
    const hfDoubleMissingText = textOf(hfDoubleMissingTree)
    hostFaceMode = 'ok'
    check('FIX-047-F11: 双源皆缺（health 面不可用 + 取数失败）时失败通知仍上屏且折叠态可见（R0 F-11——旧早退条件此断言必红）',
      hfDoubleMissingText.includes('(Error)') && hfDoubleMissingText.includes(zh.hostHealthVersionsUnavailable)
      && !hfDoubleMissingText.includes(zh.hostHealthOk) && summaryTextOf(hfDoubleMissingTree).includes(zh.hostHealthRpcFailed('Error')))

    // N-2（R1 P3）：失败 ∧ 降级**并存**的折叠态取舍——本批按 R1 建议取「同时可见」
    // 最小改法（lib/client.js summary 单点合成：失败短码后并列降级面计数；degraded
    // 口径未改，仍只由 faces 派生）。唯一变量 = 本地面含一个非 ok 面；判别 = 折叠态
    // 同时含失败短码与降级计数（旧实现折叠态只渲染失败文案，降级计数仅在展开体
    // ⇒ 此断言必红）。
    hostFaceMode = 'throw'
    const hfBothTree = await renderInto(settingsReg.render({
      ...settingsReg.inject(),
      remote: () => ({ ...remoteMock }),
      health: () => ({ faces: [{ name: 'probe-degraded', state: 'degraded', detail: 'stub' }], diag: [] }),
    }), 'fix047-failure-with-degraded')
    const hfBothSummary = summaryTextOf(hfBothTree)
    hostFaceMode = 'ok'
    check('FIX-047-N2: 失败 ∧ 降级并存 → 折叠态同时可见失败短码与降级面计数（R1 N-2 最小改法；旧实现折叠态只见失败文案此断言必红）',
      hfBothSummary.includes(zh.hostHealthRpcFailed('Error')) && hfBothSummary.includes(zh.hostHealthWarn(1)) && !textOf(hfBothTree).includes(zh.hostHealthOk))

    hostFaceMode = 'ok'
  }
}
