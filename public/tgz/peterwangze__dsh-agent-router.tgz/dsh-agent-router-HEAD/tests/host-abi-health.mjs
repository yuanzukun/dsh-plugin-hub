/**
 * EVO-019 宿主面健康守护（ARCH-004 设计 §10 B1 批：host-abi 骨架 + 诊断环形）。
 *
 * 覆盖面（任务验收判别项逐一对应）：
 * 1. noteHostDiag 通用诊断环形有界判别（presetDiag 同构泛化，§6.1——写入
 *    >64 条 → 恰好保留 64，最新保留；字段白名单 + 截断 + JSON 安全）。
 * 2. probe 惰性机制（§7.1「绝不进渲染路径」的机制面）：faceHealthSnapshot
 *    纯读缓存零 probe 调用；runFaceProbes 是唯一 probe 触发器；状态变化才
 *    入环形（首跑基线静默）；probe 抛错 fail-safe 降级不外泄。
 * 3. 客户端 render 期零 probe 判别（§6.1 判别锚点，源判别先例 fix-029 C4 /
 *    fix-031 G-H）：hostFaceDiagnostics 调用点唯一且位于 useEffect 内、
 *    绝不进 2s 轮询（D1-10 纪律）；健康面板渲染体零 remote 调用。
 * 4. hostVersionsOf 版本遥测 + 降级（'unknown'，§4.3 域 6）；HOST_ROUTE_*
 *    常量 re-export 值级锚定权威源（fix-031 G14 先例）。
 * 5. router/hostFaceDiagnostics RPC 全链形状（描述符 + 网关绑定契约 +
 *    strict wire codec 通过 + FaceHealth 形状）。
 * 6. 域骨架 probe 真实性抽样（client-remotes / llm-selection / ctx-services /
 *    events / inject-manifest——骨架纪律：真实探测行为，禁 TODO 存根）。
 * 7. EVO-020（ARCH-004 B2 域批）：createClientRemotes 降级语义（面缺失 →
 *    host-face-missing 降级信封 / 形状漂移 → host-face-shape / 调用被拒 →
 *    host-face-call；throw 语义已废）+ 浏览器包镜像行为 parity（client.js
 *    无法 import Node ESM——镜像纪律，漂移即红）+ P5 残留 grep + 域 5
 *    noteInjectFaceGaps（apply 时 inject 缺面诊断）。
 * 8. EVO-022（ARCH-004 B4 ctx-services 域批）：service.js/host-route.js
 *    24 处散点切换后的消费点分级白名单快照（lib/*.js 非 host-abi 的裸
 *    ctx.get 精确计数——越界新增即红）+ 八项累积绑定判别（P2-2 常量权威
 *    翻转 version.js 单点无环 / P3-5 RPC 供数平移 service.js 类方法 /
 *    F-1 agentPresetsServiceOf 归 ctx-services 归并单点 / F-2 形状降级
 *    边缘显式降级 + noteHostDiag / F-3 modelDirectories 缺面短码 + 诊断 /
 *    F-6 HostHealthCard faces 按名去重 / probeLlmAdapterFace 三方法并集）。
 * 9. EVO-023（ARCH-004 B5 events 域批）：域管五事件清单（MANAGED_EVENTS，
 *    W-3 收窄——scoped 钩子保留直订）+ 转发事件白名单双检（静态：插件订阅
 *    事件名字面量 ⊆ FORWARDED_EVENT_ALLOWLIST；运行时：白名单外订阅即拒绝 +
 *    诊断——D-2 死订阅机器防线）+ 共享 listener 聚合（跨调用同事件名单宿主
 *    listener / 单模块卸载摘除自身 consumer / 异步 consumer await 语义）+
 *    浏览器镜像值级 parity + R-5 Node 侧注册表接线（11 ctx 服务面 + 2
 *    llm-selection 面 → faces 生产非空；面板打开复检规则：全绿纯缓存读、
 *    非全绿一次失败驱动复检）+ R-3（F-6 HostHealthCard faces 去重行为断言）+
 *    R-1 锚清扫复核（**清单内**旧式锚零残留、替代式锚在位；限定语形态，见下）；FIX-040 扩面（R1 N4）：
 *    清扫面扩至 lib/host-abi/llm-selection.js / tests/metrics.mjs / tests/smoke.mjs /
 *    tests/install-entry.mjs / lib/preset-defaults.js / tests/preset-defaults.mjs +
 *    ci.yml / README.md 契约面（stale 零残留 + 符号/断言名式锚在位），并增设
 *    **跨文件对象核验**（9h-2：metrics 断言名式锚所指对象按**声明单源**实存；9h-2b：零自满足；
 *    9h-2c：表内声明源名合法性——未知源名显式判红，不裸抛 TypeError；
 *    9h-2d：对象在其声明源内恰出现 1 次——同源重复/副本即红）
 *    + **入表完备性自检**（9h-3：metrics 候选锚名未入表即红），使锚漂移成为机器看护而非人工巡检；
 *    并增设 **needle 自碰撞卫生**（FIX-043 批 A 收口 FIX-042 R1 P3-1：9h-4「stale needle 在守卫自身
 *    内的非登记出现次数 = 0」（被登记说明文本逐字复述即红）/ 9h-4b 自条目 needle 全文件出现次数 = 0
 *    （拼接常量登记）/ 9h-4c 登记数据单元解析完整性——解析失配即红，防判据面静默退化）。
 * 10. FIX-035（EVO-023 R0 P2-1 收口，§9i）：events 域 attach 失败条目**不入表**
 *    （后续订阅重试 attach——静默死订阅消除）+ event-subscribe-failed 诊断
 *    （code=attach-threw + consumer 标签 + 错误摘要，P8）+ 失败消费者 dispose
 *    降级 no-op（不悬挂）+ 浏览器镜像同型 parity（失败零复用/重试自愈）。
 * 11. ARCH-005 R2（设计 §2-B 四维-b / §6 R2 行）：运行面版本协商三态
 *    （matched / compatible-unknown / incompatible）——hostCapabilityProfile
 *    判定序（任一关键面非 ok → incompatible，先于版本——不把故障伪装成
 *    「只是没测过」；版本组合 ∈ 基线档案 → matched；否则 compatible-unknown
 *    + 一次性 host-version-unknown 诊断事件〔同版本组合只记一次〕）+ 基线
 *    档案表与 tests/host-version-snapshot.mjs HOST_BASELINE_REGISTRY 的**值级
 *    机器锁定**（P5 单源——import 评估结论见 §R2-a 注释：测试文件为顶层执行
 *    套件不可被产品代码 import，采用「测试侧权威登记 + 运行面投影」同形双表
 *    + 解析锁定断言，F-J「双份常量机器锁定」纪律同构）+ RPC 四合一字段
 *    （capabilityProfile）+ 徽章三态渲染判别（render 期零 probe——探针计数
 *    断言；两 regime 边界：gate-block 拒载态三态不可达，本节只覆盖
 *    gate-pass-unknown regime）。
 *
 * 红演示证据（任务验收 2）：实现前自然红（模块缺失套件失败）+ 绿后判别红
 * （R1：HOST_DIAG_LIMIT 临时 64→128 → 环形有界断言红；R2：HostHealthCard
 * 渲染体内临时注入第二处 .hostFaceDiagnostics( 调用 → render 期零 probe
 * 判别红）——复原后全绿。B4 追加：临时在 service.js 加一处裸
 * ctx.get('sessionController') → §8a 白名单快照红（分级放行越界）。B5 追加：
 * ① 临时把 client.js 页面订阅改回死名 credentials/updated → §9b 静态比对 +
 * §9c 运行时拒绝红（复原双绿）；② 实现前 §9 组全红（MANAGED_EVENTS 未导出 /
 * 白名单未启用 / faces 空注册表 / R-1 锚未清扫）——见任务结论 RED 记录。
 * FIX-035 追加：§9i attach 抛错用例在修复前红（死条目被缓存 → 二次订阅零
 * attach + 误记 event-subscribed + 重试后零派发；镜像半边同型红）→ 修复后绿。
 *
 * 独立入口：node tests/host-abi-health.mjs（exit 0/1）。
 */
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, rmSync, existsSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { Context } from '@deepseek-ai/cordis'
import { ROUTER_DESCRIPTORS } from '../lib/rpc.js'
import { RouterService } from '../lib/service.js'
import { wireCodecs } from '../lib/schemas.js'
// B4 ①（P2-2）：HOST_ROUTE_* 权威源 = version.js 单点（host-route.js 改
// re-export 消费面——本 import 锚定权威侧，host-route 侧 re-export 由 §8e 锁定）。
import { HOST_ROUTE_NS, HOST_ROUTE_PROVIDER, HOST_ROUTE_REF, HOST_ROUTE_TICK_MS } from '../lib/host-abi/version.js'
import * as hostAbi from '../lib/host-abi/index.js'

const ROOT_DIR = join(dirname(fileURLToPath(import.meta.url)), '..')
const {
  HOST_DIAG_LIMIT, noteHostDiag, hostDiagnostics, registerFaceProbes, faceHealthSnapshot, runFaceProbes,
  packageVersionOf, hostVersionsOf,
  CLIENT_REMOTE_FACES, probeRemoteFace, clientRemotesHealth, createClientRemotes,
  probeLlmAdapterFace, probeSessionSelectFace,
  serviceFaceOf, agentsRegistryOf, llmOf, ctxServiceFaceProbes,
  FORWARDED_EVENT_ALLOWLIST, MANAGED_EVENTS, isForwardedEvent, subscribeEvents, armEventGate,
  FIBER_INJECT, CLIENT_PACKAGE_INJECT, probeFiberInjectFaces, noteInjectFaceGaps,
  DEPENDENCY_LEDGER, RED_TEST_GAPS, CTX_SERVICES, HOST_PACKAGE_NAMES, HOST_PACKAGE_REGISTRY,
} = hostAbi

let failures = 0
let passed = 0
const check = (label, condition, detail) => {
  if (condition) { passed++; console.log(`  ok  ${label}`) }
  else { failures++; console.error(`FAIL  ${label}${detail !== undefined ? ` :: ${JSON.stringify(detail)}` : ''}`) }
}
const FACE_STATES = ['ok', 'degraded', 'missing']

// ── 1. 诊断环形有界（§6.1 / 任务验收「环形有界判别」）────────────────────
console.log('host diag ring bounded (noteHostDiag):')
{
  for (let index = 0; index < HOST_DIAG_LIMIT + 16; index++) noteHostDiag({ kind: `ring-fill-${index}` })
  const entries = hostDiagnostics().entries
  check('ring keeps exactly HOST_DIAG_LIMIT entries after >64 writes', entries.length === HOST_DIAG_LIMIT && HOST_DIAG_LIMIT === 64)
  check('ring keeps the NEWEST entries (overflow dropped from head)', entries[0].kind === `ring-fill-${16}` && entries[entries.length - 1].kind === `ring-fill-${HOST_DIAG_LIMIT + 15}`)
  check('entries carry timestamps and parse as lossless JSON', entries.every((entry) => typeof entry.at === 'number' && typeof entry.kind === 'string') && typeof JSON.stringify(entries) === 'string')
  // 字段白名单 + 截断 + 恶性输入防御（presetDiag/notePresetDiag 纪律同构）。
  noteHostDiag({ kind: 'shape', face: 'f'.repeat(300), consumer: 'c'.repeat(300), code: 'x'.repeat(300), detail: 'd'.repeat(500), poison: { nope: true } })
  noteHostDiag(null)
  noteHostDiag({ kind: () => {}, face: { weird: 1 } })
  const tail = hostDiagnostics().entries.slice(-3)
  check('field whitelist truncates (face/consumer ≤64, code ≤48, detail ≤160) and never throws', tail[0].face.length === 64 && tail[0].consumer.length === 64 && tail[0].code.length === 48 && tail[0].detail.length === 160 && !('poison' in tail[0]))
  check('hostile/absent entries degrade to safe shapes instead of throwing', tail[1].kind === '?' && tail[2].kind === '?' && !('face' in tail[2]) && typeof JSON.stringify(tail) === 'string')
  check('snapshot returns a copy (caller mutation cannot corrupt the ring)', (() => { const snap = hostDiagnostics().entries; snap.push({ at: 0, kind: 'mutated' }); return hostDiagnostics().entries.length === HOST_DIAG_LIMIT })())
}

// ── 2. probe 惰性机制：快照零 probe，runFaceProbes 唯一触发器（§7.1）──────
console.log('probe laziness (render reads cache, never probes):')
{
  let probeCalls = 0
  registerFaceProbes([
    { name: 'stub:ok', probe: () => { probeCalls += 1; return { state: 'ok' } } },
    { name: 'stub:degraded', probe: () => { probeCalls += 1; return { state: 'degraded', detail: 'host-face-shape: listProviders' } } },
    { name: 'stub:throws', probe: () => { probeCalls += 1; throw new Error('probe exploded') } },
  ])
  const before = probeCalls
  for (let index = 0; index < 5; index += 1) faceHealthSnapshot()
  check('faceHealthSnapshot is a pure cache read (0 probe calls across repeated reads)', probeCalls === before)
  const baselineLen = hostDiagnostics().entries.length
  const faces = runFaceProbes(null)
  check('runFaceProbes runs each registered probe exactly once', probeCalls === before + 3 && faces.length === 3)
  check('FaceHealth shape: {name, state ∈ ok|degraded|missing, detail?string}', faces.every((face) => typeof face.name === 'string' && FACE_STATES.includes(face.state) && (face.detail === undefined || typeof face.detail === 'string')))
  check('probe throw degrades fail-safe (never escapes; detail carries reason)', faces.find((face) => face.name === 'stub:throws').state === 'degraded' && String(faces.find((face) => face.name === 'stub:throws').detail).includes('probe exploded'))
  check('first run establishes baseline silently (no ring noise without a prior state)', hostDiagnostics().entries.length === baselineLen)
  registerFaceProbes([{ name: 'stub:ok', probe: () => { probeCalls += 1; return { state: 'missing', detail: 'host-face-missing' } } }])
  const changed = runFaceProbes(null)
  const changeEntries = hostDiagnostics().entries.filter((entry) => entry.kind === 'face-state')
  check('subsequent state CHANGES are noted into the ring (face + code = new state)', changed.find((face) => face.name === 'stub:ok').state === 'missing' && changeEntries.length === 1 && changeEntries[0].face === 'stub:ok' && changeEntries[0].code === 'missing')
  const cacheReads = probeCalls
  for (let index = 0; index < 3; index += 1) faceHealthSnapshot()
  check('snapshot after run still never probes (cached FaceHealth)', probeCalls === cacheReads)
}

// ── 3. 客户端 render 期零 probe（源判别——§6.1 判别锚点）──────────────────
console.log('client render-phase zero-probe (source discriminators):')
{
  const source = readFileSync(join(ROOT_DIR, 'lib', 'client.js'), 'utf8')
  const callSites = source.match(/\.hostFaceDiagnostics\(/g) ?? []
  check('exactly one hostFaceDiagnostics call site in client bundle', callSites.length === 1)
  const callPos = source.indexOf('.hostFaceDiagnostics(')
  const effectPos = source.lastIndexOf('useEffect(', callPos)
  check('the call site lives inside a useEffect (never in render body)', effectPos !== -1 && source.slice(effectPos, callPos).includes('ready') && !source.slice(effectPos, callPos).includes('return el('))
  const depsPos = source.indexOf('}, [', callPos)
  const effectWindow = source.slice(effectPos, depsPos)
  check('effect stores the snapshot into state (setHostHealth) — render reads state only', effectWindow.includes('setHostHealth('))
  check('one-shot snapshot is NOT wired into the 2s poll loop (D1-10 discipline: no setInterval in the effect window)', !effectWindow.includes('setInterval'))
  const cardPos = source.indexOf('function HostHealthCard')
  const cardEnd = source.indexOf('\n    function ', cardPos + 1)
  const cardBody = source.slice(cardPos, cardEnd === -1 ? undefined : cardEnd)
  check('HostHealthCard render body contains zero remote/RPC calls (pure snapshot render)', !cardBody.includes('remote(') && !cardBody.includes('.hostFaceDiagnostics(') && cardBody.includes('hostHealth.faces'))
  const mirror = readFileSync(join(ROOT_DIR, 'tests', 'served-client.js'), 'utf8')
  check('served-client mirror stays byte-identical to lib/client.js', mirror === source)
}

// ── 4. 版本遥测 + 降级（§4.3 域 6 / §5.3-3）───────────────────────────────
console.log('host version telemetry:')
{
  check('packageVersionOf degrades to unknown for unresolvable packages', packageVersionOf('@deepseek-ai/dsh-agent-router-no-such-package') === 'unknown')
  const versions = hostVersionsOf()
  check('hostVersionsOf returns the three dependency keys as strings (env-agnostic values)', typeof versions.llm === 'string' && typeof versions.tools === 'string' && typeof versions.typertProtocol === 'string' && Object.keys(versions).length === 3)
  check('installed dev graph resolves real versions (lockfile-synced deps readable)', versions.llm !== 'unknown' && versions.tools !== 'unknown' && versions.typertProtocol !== 'unknown')
  check('HOST_ROUTE_* stay value-anchored to the version.js single point (B4 authority flip; host-route re-export + barrel stay equal — fix-031 G14 precedent)', hostAbi.HOST_ROUTE_NS === HOST_ROUTE_NS && hostAbi.HOST_ROUTE_PROVIDER === HOST_ROUTE_PROVIDER && hostAbi.HOST_ROUTE_REF === HOST_ROUTE_REF && hostAbi.HOST_ROUTE_TICK_MS === HOST_ROUTE_TICK_MS)
}

// ── 5. router/hostFaceDiagnostics RPC 全链（§6.2 三合一形状）──────────────
console.log('router/hostFaceDiagnostics RPC contract:')
{
  const descriptor = ROUTER_DESCRIPTORS.find((item) => item.id === 'dsh-agent-router#router/hostFaceDiagnostics')
  check('descriptor registered (service/namespace router, method hostFaceDiagnostics, direct invocation)', !!descriptor && descriptor.service === 'router' && descriptor.namespace === 'router' && descriptor.method === 'hostFaceDiagnostics' && descriptor.invocation.kind === 'direct')
  check('result codec is the strict wire schema behind create() factory (wireCodecs.hostFaceDiagnosticsResult; ARCH-005 A2 形态——create() 交回同一对象)', descriptor?.result?.create() === wireCodecs.hostFaceDiagnosticsResult)
  // 网关绑定契约（rpc-shadow-guard 同语义：implementation ?? method 反射可调用）。
  const service = new RouterService(new Context())
  service.attach({ get: () => ({ enabled: true, agents: {} }) })
  const binding = Reflect.get(service, descriptor.implementation ?? descriptor.method)
  check('gateway binding contract: Reflect.get(service, implementation ?? method) is callable', typeof binding === 'function')
  const payload = binding.call(service)
  check('payload shape { hostVersions, faces: FaceHealth[], diag: entries[] }', !!payload && typeof payload.hostVersions === 'object' && Array.isArray(payload.faces) && Array.isArray(payload.diag) && payload.faces.every((face) => typeof face.name === 'string' && FACE_STATES.includes(face.state)))
  check('payload passes the strict wire codec (gateway result validation)', !!wireCodecs.hostFaceDiagnosticsResult.parse(payload))
  check('RPC serves exactly the cached FaceHealth snapshot (read-only semantics, no probe triggering)', JSON.stringify(payload.faces) === JSON.stringify(faceHealthSnapshot()) && typeof payload.hostVersions.llm === 'string')
}

// ── 6. 域骨架 probe 真实性抽样（骨架纪律：真实行为，无 TODO 存根）─────────
console.log('domain skeleton probes (real probing behavior):')
{
  // 6a. client-remotes：存在性 + 方法形状（§4.3 域 1——FIX-027 双形态解析）。
  const remoteFace = { listProviders: () => {}, listConfigurableProviders: () => {}, discoverModels: () => {} }
  const ctxFull = { get: (name) => (name === 'remote.llm' ? remoteFace : undefined), remote: { llm: remoteFace } }
  const ctxMissing = { get: () => undefined, remote: {} }
  const ctxShape = { get: (name) => (name === 'remote.llm' ? { listProviders: () => {} } : undefined), remote: {} }
  check('probeRemoteFace: face present + full method shape → ok', probeRemoteFace(ctxFull, 'llm').state === 'ok' && probeRemoteFace(ctxFull, 'llm').name === 'llm')
  check('probeRemoteFace: namespace absent → missing + host-face-missing code', probeRemoteFace(ctxMissing, 'llm').state === 'missing' && probeRemoteFace(ctxMissing, 'llm').detail.includes('host-face-missing'))
  check('probeRemoteFace: method shape drift → degraded + host-face-shape code', probeRemoteFace(ctxShape, 'llm').state === 'degraded' && probeRemoteFace(ctxShape, 'llm').detail.includes('host-face-shape'))
  check('CLIENT_REMOTE_FACES covers the five FIX-028 namespaces with method shape contracts', ['llm', 'settings', 'credentials', 'agentPresets', 'session'].every((name) => Array.isArray(CLIENT_REMOTE_FACES[name]) && CLIENT_REMOTE_FACES[name].length > 0))
  check('clientRemotesHealth probes every registry face', clientRemotesHealth(ctxFull).length === Object.keys(CLIENT_REMOTE_FACES).length && clientRemotesHealth(ctxFull).every((face) => FACE_STATES.includes(face.state)))
  // 6b. llm-selection：适配器注册面 + 会话选择面（§4.3 域 2；宿主锚点
  //     dsh-api-session-controller index.js:605 selectModel）。
  check('probeSessionSelectFace: sessionController.selectModel present → ok', probeSessionSelectFace({ get: (name) => (name === 'sessionController' ? { selectModel: async () => ({ selected: {} }) } : undefined) }).state === 'ok')
  check('probeSessionSelectFace: face absent → missing (B3 migration target stays single-form)', probeSessionSelectFace({ get: () => undefined }).state === 'missing')
  // B4 ⑥（EVO-019 P2-1 终闭环）：probe 三方法并集（registerAdapter/
  // registration/listModels——与 llmFaceOf LLM_FACE_METHODS 同锚 LlmRuntime）。
  check('probeLlmAdapterFace: 三方法并集形状检查（缺 registration → degraded；桩同步收口）',
    probeLlmAdapterFace({ get: (name) => (name === 'llm' ? { registerAdapter: () => {}, registration: () => {}, listModels: async () => [] } : undefined) }).state === 'ok'
    && probeLlmAdapterFace({ get: (name) => (name === 'llm' ? { registerAdapter: () => {}, listModels: async () => [] } : undefined) }).state === 'degraded'
    && probeLlmAdapterFace({ get: (name) => (name === 'llm' ? { registerAdapter: () => {} } : undefined) }).state === 'degraded')
  // 6c. ctx-services：通用 serviceFaceOf + 具名访问器（§4.3 域 3）。
  const agentsRegistry = { get: () => ({}) }
  const resolved = serviceFaceOf({ get: (name) => (name === 'agents' ? agentsRegistry : undefined) }, 'agents', ['get'])
  const missing = serviceFaceOf({ get: () => undefined }, 'agents', ['get'])
  check('serviceFaceOf resolves {face, probe} with method shape verification', resolved.face === agentsRegistry && resolved.probe.state === 'ok' && missing.face === null && missing.probe.state === 'missing')
  check('named accessor delegates to serviceFaceOf (agentsRegistryOf)', agentsRegistryOf({ get: (name) => (name === 'agents' ? agentsRegistry : undefined) }) === agentsRegistry && agentsRegistryOf({ get: () => undefined }) === null)
  // 6d. events：共享单 listener + fail-safe 分发 + gate 位 + 白名单镜像。
  const listeners = new Map()
  const eventCtx = { on: (event, handler) => { const list = listeners.get(event) ?? []; list.push(handler); listeners.set(event, list); return () => { listeners.set(event, (listeners.get(event) ?? []).filter((item) => item !== handler)) } } }
  let aCalls = 0
  let bCalls = 0
  const disposeAll = subscribeEvents(eventCtx, [
    { event: 'settings/document-updated', consumer: 'consumer-a', gate: { kind: 'settings-pass', key: 'router' }, handler: () => { aCalls += 1; throw new Error('handler exploded') } },
    { event: 'settings/document-updated', consumer: 'consumer-b', handler: () => { bCalls += 1 } },
  ])
  check('subscribeEvents dedupes to ONE shared ctx.on listener per event name (D1-9)', listeners.get('settings/document-updated').length === 1)
  for (const handler of listeners.get('settings/document-updated')) handler()
  check('handler throw is contained (fail-safe) and sibling consumers still run', aCalls === 1 && bCalls === 1)
  check('handler failure is ring-observed (P8: event-handler-error)', hostDiagnostics().entries.some((entry) => entry.kind === 'event-handler-error' && entry.consumer === 'consumer-a'))
  armEventGate('settings-pass', 'router', true)
  for (const handler of listeners.get('settings/document-updated')) handler()
  check('armed gate suppresses the gated consumer only (F-1 generalized)', aCalls === 1 && bCalls === 2 && hostDiagnostics().entries.some((entry) => entry.kind === 'event-gated'))
  armEventGate('settings-pass', 'router', false)
  for (const handler of listeners.get('settings/document-updated')) handler()
  check('disarmed gate resumes dispatch', aCalls === 2 && bCalls === 3)
  disposeAll()
  check('disposeAll removes the shared listeners', (listeners.get('settings/document-updated') ?? []).length === 0)
  check('FORWARDED_EVENT_ALLOWLIST mirrors host API_REMOTE_FORWARDED_EVENTS (D-2 anchor: reference-updated in, dead name out; ARCH-007: 30 items at 0.2.2-rc.1 primary baseline — llm/models-updated + plugin-manager/update-state absorbed)', FORWARDED_EVENT_ALLOWLIST.includes('credentials/reference-updated') && !FORWARDED_EVENT_ALLOWLIST.includes('credentials/updated') && FORWARDED_EVENT_ALLOWLIST.length === 30)
  check('FORWARDED_EVENT_ALLOWLIST ARCH-007 additions in place (llm/models-updated: llm face adapter/model list changes; plugin-manager/update-state: market update progress)', FORWARDED_EVENT_ALLOWLIST.includes('llm/models-updated') && FORWARDED_EVENT_ALLOWLIST.includes('plugin-manager/update-state') && FORWARDED_EVENT_ALLOWLIST.includes('llm/adapters-updated'))
  // 6e. inject-manifest：单一事实源 + fiber 面探测（§4.3 域 5）。
  check('FIBER_INJECT is the client.js fiber inject mirror (single source, B2/B6 static comparison)', (() => {
    const declared = readFileSync(join(ROOT_DIR, 'lib', 'client.js'), 'utf8').match(/const inject = \[([^\]]+)\]/)
    const names = declared ? [...declared[1].matchAll(/'([^']+)'/g)].map((match) => match[1]) : []
    return JSON.stringify(names) === JSON.stringify(FIBER_INJECT)
  })())
  check('CLIENT_PACKAGE_INJECT mirrors package.json dsh.client.inject (D1-1 dead line stays gone)', JSON.stringify(JSON.parse(readFileSync(join(ROOT_DIR, 'package.json'), 'utf8')).dsh?.client?.inject) === JSON.stringify(CLIENT_PACKAGE_INJECT) && !CLIENT_PACKAGE_INJECT.includes('@deepseek-ai/dsh-client-runtime'))
  const fiberCtx = { get: (name) => (name === 'remote.llm' ? {} : undefined) }
  const fiberHealth = probeFiberInjectFaces(fiberCtx)
  check('probeFiberInjectFaces probes every FIBER_INJECT face (ok/missing per resolution)', fiberHealth.length === FIBER_INJECT.length && fiberHealth.find((face) => face.name === 'remote.llm').state === 'ok' && fiberHealth.find((face) => face.name === 'modelDirectories').state === 'missing')
  // 6f. 桶：消费者统一入口可达（空桶零逻辑，§4.1）。
  check('host-abi barrel re-exports the domain surface (single consumer entry)', typeof noteHostDiag === 'function' && typeof hostVersionsOf === 'function' && typeof probeRemoteFace === 'function' && typeof subscribeEvents === 'function' && typeof serviceFaceOf === 'function' && Array.isArray(FIBER_INJECT))
}

// ── 6g. B1 依赖台账（ARCH-007 D2）：36 条宿主依赖义务的显式冻结清单 ─────────
//   ARCH-007 前依赖义务只隐式存在于四份源码清单（HOST_PACKAGE_REGISTRY / CTX_SERVICES /
//   FIBER_INJECT / CLIENT_PACKAGE_INJECT）与散落注释里，「用了宿主什么、缺了会怎样」无法
//   在单点审计、也无机器判据防止漏项。本组把台账锁到上述四源：集合任一漂移、条数不对、
//   级别与 optional 面不一致、证据/since 缺失 → 红（台账是登记面，不是运行时判定面）。
console.log('B1 dependency ledger (explicit host dependency obligations):')
{
  const pkgB1 = JSON.parse(readFileSync(join(ROOT_DIR, 'package.json'), 'utf8'))
  const sortedSet = (values) => JSON.stringify([...new Set(values)].sort())
  check('B1-a: DEPENDENCY_LEDGER is a frozen array of exactly 36 records (13 package + 11 ctx-service + 9 fiber-face + 3 client-package — the four source lists, exact union)',
    Array.isArray(DEPENDENCY_LEDGER) && Object.isFrozen(DEPENDENCY_LEDGER) && DEPENDENCY_LEDGER.length === 36
    && DEPENDENCY_LEDGER.every((record) => record !== null && typeof record === 'object' && Object.isFrozen(record)))
  const idsOfKind = (kind) => DEPENDENCY_LEDGER.filter((record) => record.kind === kind).map((record) => record.id)
  const kindCounts = Object.fromEntries(['package', 'ctx-service', 'fiber-face', 'client-package'].map((kind) => [kind, idsOfKind(kind).length]))
  check(`B1-b: per-kind counts are 13/11/9/3 (got ${JSON.stringify(kindCounts)})`,
    kindCounts.package === 13 && kindCounts['ctx-service'] === 11 && kindCounts['fiber-face'] === 9 && kindCounts['client-package'] === 3)
  check('B1-c: (kind,id) pairs are unique — no duplicated obligation',
    new Set(DEPENDENCY_LEDGER.map((record) => `${record.kind}:${record.id}`)).size === DEPENDENCY_LEDGER.length)
  check('B1-d: package entries === HOST_PACKAGE_NAMES (13) — ledger cannot silently drop or invent a declared host package',
    sortedSet(idsOfKind('package')) === sortedSet(HOST_PACKAGE_NAMES))
  check('B1-e: ctx-service entries === CTX_SERVICES keys (11) — ledger mirrors the service-face probe list verbatim',
    sortedSet(idsOfKind('ctx-service')) === sortedSet(Object.keys(CTX_SERVICES)))
  check('B1-f: fiber-face entries === FIBER_INJECT (9) — ledger mirrors the fiber inject mirror',
    sortedSet(idsOfKind('fiber-face')) === sortedSet(FIBER_INJECT))
  check('B1-g: client-package entries === CLIENT_PACKAGE_INJECT (3) — ledger mirrors the client bundle inject list',
    sortedSet(idsOfKind('client-package')) === sortedSet(CLIENT_PACKAGE_INJECT))
  const optionalNamesB1 = HOST_PACKAGE_REGISTRY.filter((entry) => entry.optional === true).map((entry) => entry.name)
  check('B1-h: package level mirrors HOST_PACKAGE_REGISTRY.optional exactly (8 optional / 5 required)',
    optionalNamesB1.length === 8
    && sortedSet(DEPENDENCY_LEDGER.filter((record) => record.kind === 'package' && record.level === 'optional').map((record) => record.id)) === sortedSet(optionalNamesB1)
    && sortedSet(DEPENDENCY_LEDGER.filter((record) => record.kind === 'package' && record.level === 'required').map((record) => record.id))
      === sortedSet(HOST_PACKAGE_NAMES.filter((name) => !optionalNamesB1.includes(name))))
  check('B1-i: package level also mirrors package.json peerDependenciesMeta.optional (same 8 names — two projections, one truth)',
    sortedSet(optionalNamesB1) === sortedSet(Object.keys(pkgB1.peerDependenciesMeta ?? {}).filter((name) => pkgB1.peerDependenciesMeta[name]?.optional === true)))
  check('B1-j: every record level is required|optional', DEPENDENCY_LEDGER.every((record) => record.level === 'required' || record.level === 'optional'))
  const registryVersionsB1 = new Set(hostAbi.HOST_BASELINE_REGISTRY.map((entry) => entry.dshPackages))
  const consumerPathReB1 = /lib\/[\w./-]+\.js|package\.json/
  const recordKeyB1 = (record) => `${record.kind}:${record.id}`
  const hasNamedRedTestB1 = (record) => {
    const files = [...record.evidence.matchAll(/tests\/[\w.-]+\.mjs/g)].map((match) => match[0])
    return files.length > 0 && files.every((file) => existsSync(join(ROOT_DIR, file)))
  }
  const hasGapB1 = (record) =>
    (typeof record.redTestGap === 'string' && record.redTestGap.trim().length > 0)
    || RED_TEST_GAPS.includes(recordKeyB1(record))
  const requiredB1 = DEPENDENCY_LEDGER.filter((record) => record.level === 'required')
  // 三判据各自把越界条目 id 打进 label（P1：红要能直接定位到哪一条，不能只说
  // 「有一处不合规」）——offenders 为空才绿。
  const offendersOfB1 = (records) => JSON.stringify(records.map(recordKeyB1))
  const missingConsumerB1 = DEPENDENCY_LEDGER.filter((record) => typeof record.evidence !== 'string'
    || !consumerPathReB1.test(record.evidence) || !/→\s*\S/.test(record.evidence))
  check(`B1-k1: every record names a consumer file (lib/*.js or package.json key) and states a consequence (→ …) — empty or hollow evidence is forbidden; offenders=${offendersOfB1(missingConsumerB1)}`,
    missingConsumerB1.length === 0)
  const silentRedB1 = requiredB1.filter((record) => !hasNamedRedTestB1(record) && !hasGapB1(record))
  check(`B1-k: every required record carries red-test info — one of (a) evidence names an existing tests/*.mjs suite, (b) non-empty redTestGap, (c) id in RED_TEST_GAPS; a required entry with none of the three is a silent gap and is named here; offenders=${offendersOfB1(silentRedB1)}`,
    silentRedB1.length === 0)
  const sinceOffendersB1 = DEPENDENCY_LEDGER.filter((record) => !registryVersionsB1.has(record.since))
  check(`B1-k2: every record since is a registered host generation (HOST_BASELINE_REGISTRY dshPackages) — offenders=${JSON.stringify(sinceOffendersB1.map((record) => `${recordKeyB1(record)}@${record.since}`))}`,
    sinceOffendersB1.length === 0)
  const gapOffendersB1 = [
    // ① 登记项必须在台账上有对得上的 required 记录 + redTest:null + 非空 redTestGap（无陈旧 id）
    ...RED_TEST_GAPS.filter((key) => !DEPENDENCY_LEDGER.some((record) => recordKeyB1(record) === key
      && record.level === 'required' && record.redTest === null
      && typeof record.redTestGap === 'string' && record.redTestGap.trim().length > 0)),
    // ② 反向：带 redTest:null 的记录必须登记（无孤儿缺口）
    ...DEPENDENCY_LEDGER.filter((record) => record.redTest === null && !RED_TEST_GAPS.includes(recordKeyB1(record))),
  ]
  check(`B1-k3: RED_TEST_GAPS (${RED_TEST_GAPS.length}) is frozen, duplicate-free and exactly the required records carrying redTest:null + non-empty redTestGap — bidirectional, no stale id, no unregistered gap; gaps=${JSON.stringify([...RED_TEST_GAPS])}; offenders=${offendersOfB1(gapOffendersB1)}`,
    Array.isArray(RED_TEST_GAPS) && Object.isFrozen(RED_TEST_GAPS)
    && new Set(RED_TEST_GAPS).size === RED_TEST_GAPS.length
    && DEPENDENCY_LEDGER.filter((record) => record.redTest === null).length === RED_TEST_GAPS.length
    && gapOffendersB1.length === 0)
  check('B1-l: ledger kinds are only the four audited axes (no ad-hoc fifth cluster)',
    DEPENDENCY_LEDGER.every((record) => ['package', 'ctx-service', 'fiber-face', 'client-package'].includes(record.kind)))
  // 非 package 轴的级别是语义判定（required ⇒ 缺失即核心不可用；optional ⇒ 缺失降级且
  // 有可见诊断，见台账头部注释）。核心面若被静默降为 optional，降级判据就会整体失灵——
  // 这里锁住三类核心最小集（不是全量清单，全量由上面四源等值判据看护）。
  const levelOfB1 = (kind, id) => DEPENDENCY_LEDGER.find((record) => record.kind === kind && record.id === id)?.level
  check('B1-m: semantic-required core faces stay required (ctx llm/settings/fs, fiber slots/remote, client ui-settings/api-remotes) — downgrading the core to optional goes red',
    ['llm', 'settings', 'fs'].every((id) => levelOfB1('ctx-service', id) === 'required')
    && ['slots', 'remote'].every((id) => levelOfB1('fiber-face', id) === 'required')
    && ['@deepseek-ai/dsh-client-ui-settings', '@deepseek-ai/dsh-api-remotes'].every((id) => levelOfB1('client-package', id) === 'required'))
}

// ── 7. EVO-020 B2：createClientRemotes 降级语义 + 浏览器镜像 parity（§4.3 域 1）──
console.log('B2 client-remotes domain (degraded semantics + browser mirror parity):')
{
  // 7a. 权威单点（lib/host-abi/client-remotes.js）：throw 语义 → 降级信封。
  const okLlm = {
    listProviders: async () => ({ ok: true, value: [{ id: 'gateway', name: 'Gateway' }] }),
    listConfigurableProviders: async () => ({ ok: true, value: [{ provider: 'gateway', displayName: 'Gateway', settingsNs: 'llm-pi-ai', settingsPath: ['providers', 'gateway'], declared: true }] }),
    discoverModels: async () => ({ ok: true, value: [{ id: 'm-a' }] }),
  }
  const okSession = {
    modelCatalog: async () => ({ ok: true, value: { default: { provider: 'deepseek-official', model: 'deepseek-v4-pro' }, routableProviders: ['gateway'], groups: [{ id: 'gateway', models: [{ id: 'old-m', name: 'Old M' }] }], failures: [] } }),
    selectModel: async (payload) => ({ ok: true, value: { selected: { provider: payload.provider } } }),
  }
  const okSettings = { describe: async () => ({ ok: true, value: { writable: true, hasDocument: true, namespaces: [] } }), mutate: async () => ({ ok: true, value: { ns: 'llm-pi-ai' } }) }
  const okCredentials = { describe: async (refs) => ({ ok: true, value: Object.fromEntries((refs ?? []).map((ref) => [ref, { configured: false }])) }), set: async () => ({ ok: true, value: undefined }), unset: async () => ({ ok: true, value: undefined }) }
  const okPresets = { list: async () => ({ ok: true, value: { presets: [], authorable: true } }) }
  const fullCtx = { get: (name) => (name === 'remote.llm' ? okLlm : name === 'remote.session' ? okSession : name === 'remote.settings' ? okSettings : name === 'remote.credentials' ? okCredentials : name === 'remote.agentPresets' ? okPresets : undefined), remote: {} }
  const remotes = createClientRemotes(fullCtx)
  check('B2: createClientRemotes(ctx) → { api, health() }（§4.3 唯一入口签名）', !!remotes && typeof remotes.api === 'object' && remotes.api !== null && typeof remotes.health === 'function')
  const providersEnvelope = await remotes.api.llm.providers({})
  check('B2: ok 路径信封与 FIX-028 旧形状逐字一致（{result:{ok,value}}——消费点零改动承诺）', providersEnvelope.result.ok === true && Array.isArray(providersEnvelope.result.value.providers) && providersEnvelope.result.value.providers.length === 1 && providersEnvelope.result.value.providers[0].provider === 'gateway' && providersEnvelope.result.value.providers[0].active === true && providersEnvelope.result.value.providers[0].declared === true)
  const modelsEnvelope = await remotes.api.llm.models({})
  check('B2: llm.models 映射 session.modelCatalog groups/failures（行为零回退）', modelsEnvelope.result.ok === true && modelsEnvelope.result.value.groups[0].id === 'gateway' && modelsEnvelope.result.value.failures.length === 0)
  const selectEnvelope = await remotes.api.sessions.selectModel({ sessionId: 's1', provider: 'gateway', model: 'old-m' })
  check('B2: sessions.selectModel 直通信封（envelopeOf 路径零回退）', selectEnvelope.result.ok === true && selectEnvelope.result.value.selected.provider === 'gateway')
  // 面缺失（任务验收场景：stub 掉 remote.llm）——同 fixture 其余四面在。
  const mixedCtx = { get: (name) => ({ 'remote.settings': okSettings, 'remote.credentials': okCredentials, 'remote.agentPresets': okPresets, 'remote.session': okSession })[name], remote: {} }
  const mixedRemotes = createClientRemotes(mixedCtx)
  const degradedProviders = await mixedRemotes.api.llm.providers({})
  check('B2: 面缺失 → 降级信封 {ok:false, error.code:host-face-missing}（throw 语义已废）', degradedProviders.result.ok === false && degradedProviders.result.error.code === 'host-face-missing' && typeof degradedProviders.result.error.message === 'string' && degradedProviders.result.error.message.includes('llm'))
  const degradedDiscover = await mixedRemotes.api.llm.discoverModels({ settingsNs: 'llm-pi-ai' })
  check('B2: 缺失面的每个方法都返回降级信封（degraded face——非单方法特例）', degradedDiscover.result.ok === false && degradedDiscover.result.error.code === 'host-face-missing')
  const siblingSettings = await mixedRemotes.api.settings.describe({})
  const siblingPresets = await mixedRemotes.api.agentPresets.list({})
  check('B2: 单面降级不波及兄弟面——settings/agentPresets 照常 ok（其余面正常）', siblingSettings.result.ok === true && siblingPresets.result.ok === true)
  // 形状漂移：面在而方法缺 → host-face-shape（BR-02 第一层防线语义化）。
  const shapeCtx = { get: (name) => (name === 'remote.llm' ? { listProviders: async () => ({ ok: true, value: [] }) } : name === 'remote.session' ? okSession : undefined), remote: {} }
  const shapeEnvelope = await createClientRemotes(shapeCtx).api.llm.providers({})
  check('B2: 形状漂移 → host-face-shape（error.message 列缺失方法名）', shapeEnvelope.result.ok === false && shapeEnvelope.result.error.code === 'host-face-shape' && shapeEnvelope.result.error.message.includes('listConfigurableProviders'))
  // 调用被拒 → host-face-call（透传宿主错误消息，绝不外泄击穿）。
  const rejectCtx = { get: (name) => (name === 'remote.llm' ? { listProviders: async () => { throw new Error('gateway exploded') }, listConfigurableProviders: async () => ({ ok: true, value: [] }) } : undefined), remote: {} }
  const rejectEnvelope = await createClientRemotes(rejectCtx).api.llm.providers({})
  check('B2: 宿主调用被拒 → host-face-call 信封（透传宿主错误消息）', rejectEnvelope.result.ok === false && rejectEnvelope.result.error.code === 'host-face-call' && rejectEnvelope.result.error.message.includes('gateway exploded'))
  // health()：徽章数据源（五面探测快照）+ face-degraded 诊断轨迹（P8）。
  const mixedHealth = mixedRemotes.health()
  check('B2: health().faces 探测五命名空间——llm missing 且兄弟四面 ok（徽章数据源）', mixedHealth.faces.length === Object.keys(CLIENT_REMOTE_FACES).length && mixedHealth.faces.find((face) => face.name === 'llm').state === 'missing' && mixedHealth.faces.filter((face) => face.state === 'ok').length === 4)
  check('B2: 降级调用记 face-degraded 诊断事件（health().diag 可观测，P8）', mixedHealth.diag.some((entry) => entry.kind === 'face-degraded' && entry.face === 'remote.llm' && entry.code === 'host-face-missing' && typeof entry.at === 'number'))
  check('B2: 权威单点降级事件同步上行全局环形（noteHostDiag——RPC 可见面）', hostDiagnostics().entries.some((entry) => entry.kind === 'face-degraded' && entry.face === 'remote.llm' && entry.code === 'host-face-missing'))
  // 7b. 浏览器包镜像 parity（lib/client.js 无法 import Node ESM——镜像纪律，
  //     OAUTH_ROUTE_PROVIDER 先例；envelope/health 行为逐字段相等，漂移即红）。
  const reactStub = { createElement: () => null, useState: () => [null, () => {}], useEffect: () => {}, useCallback: (fn) => fn, useRef: () => ({ current: null }) }
  let bundlePayload = null
  new Function('window', readFileSync(join(ROOT_DIR, 'lib', 'client.js'), 'utf8'))({ __ModuleLoader__: { load: (payload) => { bundlePayload = payload } } })
  const bundleExports = bundlePayload.factory((name) => (name === 'react' ? reactStub : null))
  check('B2: 浏览器包导出 createClientRemotes 镜像（判别测试钩子先例 ModelTakeover）', typeof bundleExports.createClientRemotes === 'function')
  const mirror = bundleExports.createClientRemotes(mixedCtx)
  const mirrorProviders = await mirror.api.llm.providers({})
  check('B2 镜像 parity: 面缺失降级信封与权威单点逐字相等（JSON 级）', JSON.stringify(mirrorProviders) === JSON.stringify(degradedProviders))
  const mirrorSettings = await mirror.api.settings.describe({})
  check('B2 镜像 parity: ok 路径信封与权威单点逐字相等（消费点零改动双面锁定）', JSON.stringify(mirrorSettings) === JSON.stringify(siblingSettings))
  check('B2 镜像 parity: health().faces 与权威单点相等（探测表面同步锁定）', JSON.stringify(mirror.health().faces) === JSON.stringify(mixedRemotes.health().faces))
  const diagTrailOf = (entries) => entries.map((entry) => `${entry.kind}:${entry.face}:${entry.code ?? ''}`).join('|')
  const parityCanonical = createClientRemotes(mixedCtx)
  await parityCanonical.api.llm.providers({})
  check('B2 镜像 parity: health().diag 降级轨迹相等（kind:face:code 序列——同调用序列对照实例）', diagTrailOf(mirror.health().diag) === diagTrailOf(parityCanonical.health().diag))
  // 7c. P5：lib/client.js 内 hostApiFace 本体零残留 + 调用点已切换。
  const clientSource = readFileSync(join(ROOT_DIR, 'lib', 'client.js'), 'utf8')
  check('B2/P5: lib/client.js 内 hostApiFace 零残留（被取代路径禁止并存）', !clientSource.includes('hostApiFace'))
  check('B2/P5: apply() 调用点已切换 createClientRemotes(ctx)（api = remotes.api）', /const remotes = createClientRemotes\(ctx\)/.test(clientSource) && /const api = remotes\.api/.test(clientSource))
  check('B2/P5: 镜像实现唯一（function createClientRemotes 恰一处）', (clientSource.match(/function createClientRemotes\(/g) ?? []).length === 1)
  // 7d. 域 5：noteInjectFaceGaps——apply 时 inject 缺面诊断（不 throw 不阻断）。
  const gapCtx = { get: (name) => (name === 'remote.llm' ? {} : undefined) }
  const gapsBefore = hostDiagnostics().entries.filter((entry) => entry.kind === 'inject-face-missing').length
  const gapFaces = noteInjectFaceGaps(gapCtx)
  check('B2: noteInjectFaceGaps 探测全部 FIBER_INJECT 面并返回 FaceHealth[]', gapFaces.length === FIBER_INJECT.length && gapFaces.find((face) => face.name === 'remote.llm').state === 'ok' && gapFaces.find((face) => face.name === 'slots').state === 'missing')
  check('B2: 缺面记 inject-face-missing 入环形（apply 自检权威单点，不 throw）', hostDiagnostics().entries.filter((entry) => entry.kind === 'inject-face-missing').length === gapsBefore + (FIBER_INJECT.length - 1))
}

// ── 8. EVO-022 B4：ctx-services 域批（24 散点切换分级白名单 + 八项累积绑定）──
console.log('B4 ctx-services batch (scatter whitelist + cumulative bindings):')
{
  const readLib = (name) => readFileSync(join(ROOT_DIR, 'lib', name), 'utf8')
  const serviceSource = readLib('service.js')
  const hostRouteSource = readLib('host-route.js')
  const rpcSource = readLib('rpc.js')
  const clientSourceB4 = readLib('client.js')
  const versionSource = readFileSync(join(ROOT_DIR, 'lib', 'host-abi', 'version.js'), 'utf8')
  const llmSelectionSource = readFileSync(join(ROOT_DIR, 'lib', 'host-abi', 'llm-selection.js'), 'utf8')
  const stripComments = (source) => source
    .replace(/\/\*[\s\S]*?\*\//g, (block) => block.replace(/[^\n]/g, ' '))
    .replace(/(^|[^:])\/\/[^\n]*/g, (line) => line.replace(/[^\n]/g, ' '))

  // 8a. 消费点散点分级白名单（设计 §10 B4 验收：lib/*.js（非 host-abi）内
  //     裸 ctx.get 仅剩放行清单——精确计数快照，越界新增即红）。分级依据：
  //     · service.js fs/settings = 低危面直用（设计 §10 B4 白名单明文）；
  //     · wrapper/prestep/preset-defaults = B4 冻结切换范围（service.js/
  //       host-route.js 24 处）之外的遗留消费点——后续批次候选，非放行扩张；
  //     · tool.js router = 自管服务面（RouterService 为本插件注册的 ctx
  //       key，非宿主 ABI 面）；
  //     · client.js = 客户端 fiber ctx 面（B2 client-remotes/inject 域权威
  //       的浏览器镜像 + FIX-026/027 装配——remote.*/modelDirectories/
  //       conversation 不属 ctx-services 域 3 的 Node 侧服务群）。
  {
    const WHITELIST = {
      'service.js': { fs: 5, settings: 2 },
      'host-route.js': {},
      'wrapper.js': { agentDefaultModel: 1 },
      'prestep.js': { sessionProjections: 1, llm: 1 },
      'tool.js': { router: 3 },
      'preset-defaults.js': { agentDefaultModel: 1 },
      'client.js': { 'remote.*': 2, 'dynamic-inject': 1, 'remote.router': 3, conversation: 1, modelDirectories: 2 },
    }
    const diffs = []
    for (const file of readdirSync(join(ROOT_DIR, 'lib')).filter((name) => name.endsWith('.js'))) {
      const found = {}
      for (const match of stripComments(readLib(file)).matchAll(/ctx\.get\(([^)\n]*)\)/g)) {
        const argument = match[1].trim()
        const face = argument.startsWith('`remote.') ? 'remote.*' : argument === 'name' ? 'dynamic-inject' : argument.startsWith("'") ? argument.slice(1, -1) : argument
        found[face] = (found[face] ?? 0) + 1
      }
      const expected = WHITELIST[file] ?? {}
      for (const key of new Set([...Object.keys(found), ...Object.keys(expected)])) {
        if ((found[key] ?? 0) !== (expected[key] ?? 0)) diffs.push(`${file}:${key} found=${found[key] ?? 0} expected=${expected[key] ?? 0}`)
      }
    }
    check('B4 白名单: lib/*.js（非 host-abi）裸 ctx.get = 分级放行清单精确快照（24 散点已切换，越界新增即红）', diffs.length === 0, diffs.join(' | '))
    check('B4 白名单: host-route.js 零裸消费（7 处散点已切换域访问器）', !/ctx\.get\(/.test(stripComments(hostRouteSource)))
  }

  // 8b. F-2（EVO-021 R0）：形状降级边缘显式化——严格访问器 + noteHostDiag。
  {
    const goodRegistry = { get: () => ({}) }
    const shapeRegistry = { notGet: true }
    check('F-2: agents 面形状降级（.get 非函数）→ 访问器 null（旧 TypeError 被 handler catch 吞掉 → 显式降级）', agentsRegistryOf({ get: (name) => (name === 'agents' ? shapeRegistry : undefined) }) === null)
    check('F-2: 形状降级记 face-degraded 诊断事件（face=agents code=host-face-shape，P8 环形上行）', hostDiagnostics().entries.some((entry) => entry.kind === 'face-degraded' && entry.face === 'agents' && entry.code === 'host-face-shape'))
    check('F-2: 完好面照常返回本体（preset-defaults 两消费点零回退）', agentsRegistryOf({ get: (name) => (name === 'agents' ? goodRegistry : undefined) }) === goodRegistry)
    const llmPartial = { listModels: async () => [] }
    check('F-2 锚定: llmOf 存在性解析（部分形状面透传给消费点自持守卫——smoke 桩最小形状零回退锚定）', llmOf({ get: (name) => (name === 'llm' ? llmPartial : undefined) }) === llmPartial && llmOf({ get: () => undefined }) === null)
  }

  // 8c. F-1（EVO-021 R0）：agentPresetsServiceOf 归属勘正——§4.3 域 3 为准。
  {
    const ctxServices = await import('../lib/host-abi/ctx-services.js')
    const aps = ctxServices.agentPresetsServiceOf
    const apo = ctxServices.agentPresetsOf
    const presetsFace = { composedPreset: () => ({ id: 'p' }) }
    check('F-1: agentPresetsServiceOf 迁 ctx-services 域（llm-selection 域内零残留导出）', typeof aps === 'function' && !/export function agentPresetsServiceOf/.test(llmSelectionSource))
    check('F-1: 双形态解析原样（属性面优先 + ctx.get 回落 + composedPreset 函数门控 → undefined）',
      typeof aps === 'function'
      && aps({ agentPresets: presetsFace }) === presetsFace
      && aps({ get: (name) => (name === 'agentPresets' ? presetsFace : undefined) }) === presetsFace
      && aps({ agentPresets: {}, get: () => undefined }) === undefined)
    check('F-1: 与 agentPresetsOf 归并单点（同一双形态解析；访问器语义 null / 服务语义 undefined——注释成文）', typeof apo === 'function' && apo({ get: () => undefined }) === null && apo({ agentPresets: presetsFace }) === presetsFace)
    check('F-1: 桶导出面不变（消费者 preset-defaults 经桶 import 零改动）', typeof hostAbi.agentPresetsServiceOf === 'function' && hostAbi.agentPresetsServiceOf === aps)
  }

  // 8d. P3-5（EVO-019）：hostFaceDiagnostics 供数从 rpc.js 原型挂载平移
  //     service.js 正式装配（类方法），原型挂载代码删除（P5 grep 零残留）。
  {
    check('P3-5: rpc.js 原型挂载零残留（RouterService 导入与 prototype 绑定双删——代码面，注释历史表述不计）', !/RouterService|prototype\.hostFaceDiagnostics/.test(stripComments(rpcSource)))
    check('P3-5: service.js 类方法正式装配（hostFaceDiagnostics() + 三合一供数）', /hostFaceDiagnostics\(\) \{/.test(serviceSource) && /hostVersionsOf\(\)/.test(serviceSource) && /faceHealthSnapshot\(\)/.test(serviceSource) && /hostDiagnostics\(\)\.entries/.test(serviceSource))
  }

  // 8e. P2-2（EVO-019 MUST）：HOST_ROUTE_* 常量权威源翻转——version.js 自持
  //     单点定义、host-route.js 从 version.js import（依赖方向按 §4.2 图，
  //     防循环 import）。
  {
    const versionModule = await import('../lib/host-abi/version.js')
    const hostRouteModule = await import('../lib/host-route.js')
    check('P2-2: HOST_ROUTE_* 权威源 = version.js 单点定义（四常量字面量在域内声明）',
      /export const HOST_ROUTE_NS = 'llm-pi-ai'/.test(versionSource)
      && /export const HOST_ROUTE_PROVIDER = 'openai-codex'/.test(versionSource)
      && /export const HOST_ROUTE_REF = 'DSH_ROUTER_OPENAI_CODEX'/.test(versionSource)
      && /export const HOST_ROUTE_TICK_MS = 30_000/.test(versionSource))
    check('P2-2: 反向依赖边已断（version.js 零 host-route import——依赖方向无环）', !/from ['"][^'"]*host-route/.test(versionSource))
    check('P2-2: host-route.js 从桶 import + re-export（service.js/tests 消费面 import 零改动；本地零重复定义）',
      /import \{ HOST_ROUTE_NS, HOST_ROUTE_PROVIDER, HOST_ROUTE_REF, HOST_ROUTE_TICK_MS,[^}]*\} from '\.\/host-abi\/index\.js'/.test(hostRouteSource)
      && /export \{ HOST_ROUTE_NS, HOST_ROUTE_PROVIDER, HOST_ROUTE_REF, HOST_ROUTE_TICK_MS \}/.test(hostRouteSource)
      && !/export const HOST_ROUTE_(NS|PROVIDER|REF|TICK_MS)/.test(hostRouteSource))
    check('P2-2: 值级三面锚定（version 权威 === host-route re-export === 桶）',
      versionModule.HOST_ROUTE_NS === hostRouteModule.HOST_ROUTE_NS
      && versionModule.HOST_ROUTE_PROVIDER === hostAbi.HOST_ROUTE_PROVIDER
      && versionModule.HOST_ROUTE_REF === hostRouteModule.HOST_ROUTE_REF
      && versionModule.HOST_ROUTE_TICK_MS === hostAbi.HOST_ROUTE_TICK_MS
      && versionModule.HOST_ROUTE_PROVIDER === 'openai-codex')
  }

  // 8f. F-6（EVO-020）：HostHealthCard faces 合并按名去重（防重复行）。
  {
    const cardPos = clientSourceB4.indexOf('function HostHealthCard')
    const cardEnd = clientSourceB4.indexOf('\n    function ', cardPos + 1)
    const cardBody = clientSourceB4.slice(cardPos, cardEnd === -1 ? undefined : cardEnd)
    check('F-6: HostHealthCard faces 合并按名去重（先到先留——RPC 权威序在前，同名面不重复渲染）', /const mergedFaces = \[/.test(cardBody) && /seen\.has\(face\.name\)/.test(cardBody) && /= mergedFaces\.filter/.test(cardBody))
  }

  // 8g. F-3（EVO-020，绑定 ⑦）：modelDirectories 缺面路径补 code + 诊断事件
  //     （host-face-missing 短码 + noteHostDiag——对齐三错误码降级体系）。
  {
    const reactStub2 = { createElement: () => null, useState: () => [null, () => {}], useEffect: () => {}, useCallback: (fn) => fn, useRef: () => ({ current: null }) }
    let bundlePayload2 = null
    new Function('window', clientSourceB4)({ __ModuleLoader__: { load: (payload) => { bundlePayload2 = payload } } })
    const bundleExports2 = bundlePayload2.factory((name) => (name === 'react' ? reactStub2 : null))
    const dirsMissingCtx = { get: () => undefined, remote: {} }
    const dirsEnvelope = await createClientRemotes(dirsMissingCtx).api.sessions.models({ sessionId: 's1' })
    check('F-3: modelDirectories 缺面 → host-face-missing 短码（对齐 lib/client.js 的 HOST_FACE_ERROR_CODES 三错误码降级体系）', dirsEnvelope.result.ok === false && dirsEnvelope.result.error.code === 'host-face-missing')
    check('F-3: 缺面记 face-degraded 诊断事件（noteHostDiag 上行，P8）', hostDiagnostics().entries.some((entry) => entry.kind === 'face-degraded' && entry.face === 'modelDirectories' && entry.code === 'host-face-missing'))
    const dirsMirror = await bundleExports2.createClientRemotes(dirsMissingCtx).api.sessions.models({ sessionId: 's1' })
    check('F-3 镜像 parity: 缺面降级信封与权威单点逐字相等（JSON 级）', JSON.stringify(dirsMirror) === JSON.stringify(dirsEnvelope))
    const dirsShapeCtx = { get: (name) => (name === 'modelDirectories' ? {} : undefined), remote: {} }
    const dirsShape = await createClientRemotes(dirsShapeCtx).api.sessions.models({ sessionId: 's1' })
    check('F-3 边界: directoryFor 形状漂移/sessionId 缺失保持 failureOf 原语义（不误标 host-face-missing）', dirsShape.result.ok === false && dirsShape.result.error.code === undefined)
  }
}

// ── 9. EVO-023 B5：events 域批（域管事件共享订阅 + 转发白名单双检 + R-5 注册表接线）──
console.log('B5 events domain batch (managed events + forwarded whitelist double-check + R-5 face registry):')
{
  const readLibB5 = (name) => readFileSync(join(ROOT_DIR, 'lib', name), 'utf8')
  const readTestB5 = (name) => readFileSync(join(ROOT_DIR, 'tests', name), 'utf8')
  const clientSourceB5 = readLibB5('client.js')
  const eventsSourceB5 = readFileSync(join(ROOT_DIR, 'lib', 'host-abi', 'events.js'), 'utf8')

  // 9a. 域管事件清单（§4.3 域 4 ① / W-3 收窄口径；ARCH-005 A3 后 settings/updated
  //     除名——0.2.0 宿主该事件已消失，四订阅点全部换代 settings/document-updated；
  //     FIX-058 后 agent-preset/selected 除名——preset-defaults 播种迁
  //     ctx.on('session/event', …, {global:true}) 直订，域管双参订阅形态退役）。
  const MANAGED_EXPECTED = ['llm/adapters-updated', 'settings/document-updated', 'credentials/reference-updated']
  check('B5 9a: MANAGED_EVENTS = 域管三事件清单（FIX-058 后 preset 播种迁直订；A3 后旧事件名零残留，P5）',
    Array.isArray(MANAGED_EVENTS) && JSON.stringify([...MANAGED_EVENTS].sort()) === JSON.stringify([...MANAGED_EXPECTED].sort()) && !MANAGED_EVENTS.includes('settings/updated'), MANAGED_EVENTS)
  check('B5 9a: W-3 收窄——scoped 生命周期钩子（agent/pre-step、agent/created、agent/request）不在域管清单（veto 语义/热路径零介入）',
    ['agent/pre-step', 'agent/created', 'agent/request'].every((name) => !MANAGED_EVENTS.includes(name)))
  check('B5 9a: scoped 钩子在消费面保留直订不经域（preset-defaults/prestep 源码面 W-3 口径）',
    /ctx\.on\('agent\/created'/.test(readLibB5('preset-defaults.js'))
    && /ctx\.on\('agent\/request'/.test(readLibB5('preset-defaults.js'))
    && /ctx\.on\('agent\/pre-step'/.test(readLibB5('prestep.js')))

  // 9b. 转发白名单双检——静态：插件订阅事件名 ⊆ 宿主白名单映射（W-4）。
  //     订阅点两种写法都扫：直订 `$on('name', …)`（scoped 合法面）与
  //     events 域镜像 `subscribeClientEvents($on, [{ event: 'name' … }])`。
  const onSites = [
    ...[...clientSourceB5.matchAll(/\$on\(\s*'([^']+)'/g)].map((match) => match[1]),
    ...[...clientSourceB5.matchAll(/\bevent:\s*'([^']+)'/g)].map((match) => match[1]),
  ]
  check('B5 9b 静态: client.js 全部订阅事件名字面量 ⊆ FORWARDED_EVENT_ALLOWLIST（≥5 站点——非空判别）',
    onSites.length >= 5 && onSites.every((name) => FORWARDED_EVENT_ALLOWLIST.includes(name)), onSites)
  check('B5 9b 静态: D-2 死订阅名 credentials/updated 零残留 + 正名 credentials/reference-updated 在位（白名单锚）',
    !onSites.includes('credentials/updated') && onSites.includes('credentials/reference-updated'))
  check('B5 9b 迁移: index.js/service.js 的 settings 事件订阅收敛 events 域（旧裸 ctx.on 零残留，P5；A3 后事件名 = settings/document-updated）',
    /subscribeEvents\(ctx,/.test(readLibB5('index.js')) && /subscribeEvents\(this\.ctx,/.test(readLibB5('service.js'))
    && /event: 'settings\/document-updated'/.test(readLibB5('index.js')) && /event: 'settings\/document-updated'/.test(readLibB5('service.js'))
    && !/ctx\.on\('settings\/updated'/.test(readLibB5('index.js')) && !/this\.ctx\.on\('settings\/updated'/.test(readLibB5('service.js')))
  check('FIX-058 迁移: preset-defaults 播种改 session/event global 直订（旧域管订阅零残留）；agent/created 保留直订（W-3）',
    /ctx\.on\('session\/event'[\s\S]*?\{ global: true \}\)/.test(readLibB5('preset-defaults.js'))
    && !/subscribeEvents\(ctx,/.test(readLibB5('preset-defaults.js'))
    && !/ctx\.on\('agent-preset\/selected'/.test(readLibB5('preset-defaults.js'))
    && /ctx\.on\('agent\/created'/.test(readLibB5('preset-defaults.js')))

  // 9c. 运行时可达性探测：转发面白名单外订阅拒绝 + 诊断（D-2 机器防线）。
  const forwardedListeners = new Map()
  const forwardedOn = (event, handler) => {
    const list = forwardedListeners.get(event) ?? []
    list.push(handler)
    forwardedListeners.set(event, list)
    return () => { forwardedListeners.set(event, (forwardedListeners.get(event) ?? []).filter((item) => item !== handler)) }
  }
  let forwardedCalls = 0
  const disposeForwarded = subscribeEvents(forwardedOn, [
    { event: 'credentials/updated', consumer: 'dead-subscription', handler: () => { forwardedCalls += 1 } },
    { event: 'credentials/reference-updated', consumer: 'settings-page-reload', handler: () => { forwardedCalls += 1 } },
  ])
  check('B5 9c 运行时: 转发面白名单外事件名订阅被拒——零 listener 注册（credentials/updated 死订阅机器防线）',
    !forwardedListeners.has('credentials/updated') && [...forwardedListeners.keys()].join('|') === 'credentials/reference-updated')
  check('B5 9c 运行时: 拒绝记观测事件（P8：event-subscribe-rejected + code=not-forwarded + 面名）',
    hostDiagnostics().entries.some((entry) => entry.kind === 'event-subscribe-rejected' && entry.face === 'credentials/updated' && entry.code === 'not-forwarded'))
  for (const handler of forwardedListeners.get('credentials/reference-updated') ?? []) handler()
  check('B5 9c 运行时: 白名单内事件名放行（正名订阅派发命中——死订阅修复后的刷新链路）', forwardedCalls === 1)
  disposeForwarded()
  check('B5 9c 运行时: isForwardedEvent 判定与白名单镜像一致（含空/非串防御）',
    isForwardedEvent('credentials/reference-updated') === true && isForwardedEvent('credentials/updated') === false
    && isForwardedEvent('') === false && isForwardedEvent(undefined) === false)
  check('B5 9c 运行时: 宿主面（ctx.on）事件名不受转发白名单约束（app-boot/config-reload 非转发事件仍合法——A3 后宿主面设置事件探针换真非转发名）',
    (() => {
      const seen = []
      subscribeEvents({ on: (event, handler) => { seen.push(event); return () => {} } }, [{ event: 'app-boot/config-reload', consumer: 'config-reload-probe', handler: () => {} }])
      return seen.join('|') === 'app-boot/config-reload'
    })())

  // 9d. 共享 listener 聚合（D1-9：跨模块多次 subscribeEvents 收敛单 ctx.on listener）。
  const hostListeners = new Map()
  const hostTarget = {
    on: (event, handler) => {
      const list = hostListeners.get(event) ?? []
      list.push(handler)
      hostListeners.set(event, list)
      return () => { hostListeners.set(event, (hostListeners.get(event) ?? []).filter((item) => item !== handler)) }
    },
  }
  let statsApplies = 0
  let routeSyncs = 0
  const disposeConsumerA = subscribeEvents(hostTarget, [{ event: 'settings/document-updated', consumer: 'stats-persistence', handler: (ns) => { if (ns === 'router') statsApplies += 1 } }])
  const disposeConsumerB = subscribeEvents(hostTarget, [{ event: 'settings/document-updated', consumer: 'host-route-router-ns', handler: (ns) => { if (ns === 'router') routeSyncs += 1 } }])
  check('B5 9d 聚合: 同目标两次 subscribeEvents 共享单 ctx.on listener（订阅 census 的机制面）', (hostListeners.get('settings/document-updated') ?? []).length === 1)
  for (const handler of hostListeners.get('settings/document-updated') ?? []) handler('router')
  check('B5 9d 聚合: 共享 listener 按名分发到全部 consumer（同事件两模块消费者各得其份）', statsApplies === 1 && routeSyncs === 1)
  disposeConsumerA()
  for (const handler of hostListeners.get('settings/document-updated') ?? []) handler('router')
  check('B5 9d 聚合: 单模块卸载只摘除自身 consumer（其余消费者不受影响——卸载聚合）', statsApplies === 1 && routeSyncs === 2)
  disposeConsumerB()
  check('B5 9d 聚合: 全量卸载后共享 listener 归零（无残留泄漏）', (hostListeners.get('settings/document-updated') ?? []).length === 0)
  // 9d-2. 异步 consumer 的 await 语义（域分发不得降级为 fire-and-forget——
  //   多 consumer 域事件的消费链依赖 `await handler(...)` 与直订等价；多 consumer
  //   时合并 Promise.all。FIX-058 后 preset-defaults 播种已迁 session/event
  //   global 直订不经域，本条为域自身的分发契约守卫）。
  {
    const asyncListeners = []
    const asyncTarget = { on: (event, handler) => { asyncListeners.push(handler); return () => {} } }
    const settled = []
    subscribeEvents(asyncTarget, [{ event: 'agent-preset/selected', consumer: 'async-consumer', handler: async () => { await new Promise((resolve) => setImmediate(resolve)); settled.push('done'); return 'seeded' } }])
    const outcome = asyncListeners[0]('sess-x', 'preset-x')
    check('B5 9d 异步语义: 域分发表透传 async consumer 的 promise（await handler 与直订等价）', !!outcome && typeof outcome.then === 'function' && settled.length === 0)
    await outcome
    check('B5 9d 异步语义: await 后 handler 副作用可见（preset-defaults 播种队列回归锚）', settled.length === 1)
  }

  // 9e. 浏览器镜像 parity（client.js 无法 import Node ESM——镜像纪律，B2 先例）。
  const reactStubB5 = {
    createElement: (type, props, ...children) => ({ type, props: { ...(props ?? {}), ...(children.length > 0 ? { children: children.flat(Infinity) } : {}) } }),
    useState: () => [null, () => {}],
    useEffect: () => {},
    useCallback: (fn) => fn,
    useRef: () => ({ current: null }),
  }
  let bundleB5 = null
  new Function('window', clientSourceB5)({ __ModuleLoader__: { load: (payload) => { bundleB5 = payload } } })
  const bundleExportsB5 = bundleB5.factory((name) => (name === 'react' ? reactStubB5 : null))
  check('B5 9e 镜像 parity: FORWARDED_EVENT_ALLOWLIST 浏览器镜像 === 权威单点（值级，漂移即红）',
    JSON.stringify(bundleExportsB5.FORWARDED_EVENT_ALLOWLIST) === JSON.stringify(FORWARDED_EVENT_ALLOWLIST))
  check('B5 9e 镜像 parity: subscribeClientEvents 镜像导出（判别测试钩子先例 createClientRemotes）', typeof bundleExportsB5.subscribeClientEvents === 'function')
  const mirrorListeners = new Map()
  const mirrorOn = (event, handler) => {
    const list = mirrorListeners.get(event) ?? []
    list.push(handler)
    mirrorListeners.set(event, list)
    return () => { mirrorListeners.set(event, (mirrorListeners.get(event) ?? []).filter((item) => item !== handler)) }
  }
  let mirrorCalls = 0
  const disposeMirror = bundleExportsB5.subscribeClientEvents(mirrorOn, [
    { event: 'credentials/updated', consumer: 'dead-subscription', handler: () => { mirrorCalls += 1 } },
    { event: 'llm/adapters-updated', consumer: 'settings-page-reload', handler: () => { mirrorCalls += 1 } },
  ])
  check('B5 9e 镜像 parity: 白名单拒绝与权威同型（死名零 listener + 白名单内保留）',
    !mirrorListeners.has('credentials/updated') && [...mirrorListeners.keys()].join('|') === 'llm/adapters-updated')
  for (const handler of mirrorListeners.get('llm/adapters-updated') ?? []) handler()
  check('B5 9e 镜像 parity: 放行面派发命中 + 拒绝记本地诊断环形（health().diag 可观测，P8）',
    mirrorCalls === 1 && bundleExportsB5.createClientRemotes({ get: () => undefined, remote: {} }).health().diag.some((entry) => entry.kind === 'event-subscribe-rejected' && entry.face === 'credentials/updated' && entry.code === 'not-forwarded'))
  disposeMirror()
  check('B5 9e 镜像 parity: 卸载聚合归零（镜像与权威同语义）', (mirrorListeners.get('llm/adapters-updated') ?? []).length === 0)
  // 9e-2. 镜像跨调用聚合：同一 `$on` 闭包上的两次订阅（设置页 + apply 级）→
  //   宿主 listener 恒 1（客户端订阅 census 只减不增的机制面；生产路径上
  //   页面经 inject 拿到与 apply 同一 $on 闭包）。
  {
    const dedupListeners = []
    const dedupOn = (event, handler) => { dedupListeners.push({ event, handler }); return () => {} }
    let dedupCalls = 0
    const disposeDedupA = bundleExportsB5.subscribeClientEvents(dedupOn, [{ event: 'settings/document-updated', consumer: 'settings-page-reload', handler: () => { dedupCalls += 1 } }])
    const disposeDedupB = bundleExportsB5.subscribeClientEvents(dedupOn, [{ event: 'settings/document-updated', consumer: 'composer-catalog', handler: () => { dedupCalls += 1 } }])
    check('B5 9e 镜像 parity: 跨调用同 $on 同事件名共享单宿主 listener（设置页 + apply 级聚合）', dedupListeners.length === 1 && dedupListeners[0].event === 'settings/document-updated')
    dedupListeners[0].handler()
    check('B5 9e 镜像 parity: 共享 listener 分发给两消费者（聚合不丢消费者）', dedupCalls === 2)
    disposeDedupA()
    dedupListeners[0].handler()
    check('B5 9e 镜像 parity: 单调用卸载只摘除自身 consumer（聚合卸载语义与权威一致）', dedupCalls === 3)
    disposeDedupB()
  }

  // 9f. R-5：Node 侧注册表接线（faces 生产非空——B1 空注册表落地）+ 面板打开复检规则。
  const fullFaces = {
    llm: { registerAdapter: () => {}, registration: () => ({}), listModels: async () => [] },
    credentials: { resolve: async () => undefined },
    settings: { get: () => undefined, mutate: async () => {} },
    fs: {},
    attachments: {},
    subagents: {},
    agentDefaultModel: { currentSelection: () => null, saveSelection: () => {} },
    sessionController: { selectModel: async () => ({}) },
    sessionProjections: { stateOf: () => null },
    agents: { get: () => ({}) },
    agentPresets: { composedPreset: () => 'p' },
  }
  const probeCtxFull = { get: (name) => fullFaces[name] }
  const nodeProbes = [
    ...ctxServiceFaceProbes(),
    { name: 'llm:adapter', probe: probeLlmAdapterFace },
    { name: 'session:select', probe: probeSessionSelectFace },
  ]
  check('B5 9f R-5: ctxServiceFaceProbes = 11 ctx 服务面（CTX_SERVICES 单点派生，无手抄清单）',
    nodeProbes.length === 13 && ctxServiceFaceProbes().length === Object.keys(hostAbi.CTX_SERVICES).length && ctxServiceFaceProbes().every((item) => typeof item.probe === 'function' && item.name.startsWith('ctx:')))
  registerFaceProbes(nodeProbes)
  // §2 桩面复原为 ok（同会话注册表按名幂等覆盖）——「全绿快照」判定需要。
  registerFaceProbes(['stub:ok', 'stub:degraded', 'stub:throws'].map((name) => ({ name, probe: () => ({ state: 'ok' }) })))
  const nodeFaces = runFaceProbes(probeCtxFull)
  const FACE_NAMES_B5 = ['ctx:llm', 'ctx:credentials', 'ctx:settings', 'ctx:fs', 'ctx:attachments', 'ctx:subagents', 'ctx:agentDefaultModel', 'ctx:sessionController', 'ctx:sessionProjections', 'ctx:agents', 'ctx:agentPresets', 'llm:adapter', 'session:select']
  check('B5 9f R-5: 注册表面真实探测——13 面全 ok（形状齐备 ctx，非占位/非 TODO）',
    FACE_NAMES_B5.every((name) => nodeFaces.find((face) => face.name === name)?.state === 'ok'), nodeFaces.filter((face) => FACE_NAMES_B5.includes(face.name)))
  const nodeFacesMissing = runFaceProbes({ get: () => undefined })
  check('B5 9f R-5: 空 ctx → 13 面全 missing + host-face-missing 短码（探测真实性反向判别）',
    FACE_NAMES_B5.every((name) => nodeFacesMissing.find((face) => face.name === name)?.state === 'missing' && String(nodeFacesMissing.find((face) => face.name === name)?.detail).includes('host-face-missing')))
  // 面板打开复检规则（§7.1 三时机之「健康面板打开」）：全绿 → 纯缓存读；非全绿 → 一次复检。
  runFaceProbes(probeCtxFull)
  let r5ProbeRuns = 0
  registerFaceProbes([{ name: 'b5:count', probe: () => { r5ProbeRuns += 1; return { state: 'ok' } } }])
  runFaceProbes(probeCtxFull)
  const r5BaselineRuns = r5ProbeRuns
  const root9 = new Context()
  for (const [name, value] of Object.entries(fullFaces)) root9.provide(name, value)
  const service9 = new RouterService(root9)
  const payload9 = service9.hostFaceDiagnostics()
  check('B5 9f R-5: Node 消费面（RPC 三合一）faces 生产非空——13 面 + 计数桩全部在场且无缺失态',
    FACE_NAMES_B5.every((name) => payload9.faces.some((face) => face.name === name && face.state === 'ok')) && payload9.faces.length >= 14)
  check('B5 9f R-5: 全绿快照 → RPC 读零 probe（纯缓存读，§7.1 惰性纪律不破）', r5ProbeRuns === r5BaselineRuns)
  const service9b = new RouterService(new Context())
  // 非全绿快照制造：空 ctx 自检（13 面全 missing）→ 下一次 RPC 读触发复检。
  runFaceProbes({ get: () => undefined })
  const r5BeforeDegradedRead = r5ProbeRuns
  const payload9b = service9b.hostFaceDiagnostics()
  check('B5 9f R-5: 非全绿快照 → 面板打开一次复检（失败驱动复检；boot 期面未就绪的陈旧 missing 于打开时自愈）',
    r5ProbeRuns === r5BeforeDegradedRead + 1 && payload9b.faces.filter((face) => FACE_NAMES_B5.includes(face.name) && face.state === 'ok').length === 0)

  // 9g. R-3（F-6 行为断言）：HostHealthCard faces 合并按名去重（RPC 权威序在前）。
  const tStubB5 = (key) => Object.assign((arg) => `${key}(${arg})`, { toString: () => key })
  const cardTree = bundleExportsB5.HostHealthCard({
    hostHealth: { hostVersions: { llm: '0.1.5-rc.2', tools: '0.1.5-rc.2', typertProtocol: '0.1.5-rc.2' }, faces: [{ name: 'llm', state: 'ok' }, { name: 'settings', state: 'ok' }] },
    faceHealth: { faces: [{ name: 'llm', state: 'degraded', detail: 'host-face-shape: listProviders' }, { name: 'remote.llm', state: 'ok' }] },
    t: tStubB5,
  })
  const cardTexts = []
  const collectTextB5 = (node) => {
    if (typeof node === 'string') { cardTexts.push(node); return }
    if (typeof node === 'function') { cardTexts.push(String(node)); return }
    if (typeof node === 'number' || typeof node === 'boolean') { cardTexts.push(String(node)); return }
    if (!node || typeof node !== 'object') return
    for (const child of Array.isArray(node.props?.children) ? node.props.children : []) collectTextB5(child)
  }
  collectTextB5(cardTree)
  const faceRows = cardTexts.filter((text) => /^[✓⚠✗] /.test(text))
  check('B5 9g F-6: faces 合并按名去重——同名 llm 仅一行且取 RPC 权威态（先到先留）',
    faceRows.length === 3 && faceRows.includes('✓ llm') && !faceRows.some((row) => row.startsWith('⚠ llm') || row.startsWith('✗ llm')))
  check('B5 9g F-6: 本地独有面照常渲染（remote.llm 非同名面不被去重丢弃）', faceRows.includes('✓ remote.llm') && faceRows.includes('✓ settings'))
  check('B5 9g F-6: 徽章口径随去重结果（去重后零降级 → 全绿文案，不误报）', cardTexts.includes('hostHealthOk') && !cardTexts.includes('hostHealthWarn(1)'))

  // 9h. R-1 锚清扫复核（FIX-039 S-2 起）：**清单内**旧式锚零残留（函数名/符号名/断言名式锚替代，
  //   防行号再漂移；限定语见下条 check 标签——列清单式判据只覆盖清单本身，不声称「整文件无
  //   行号锚」）。清单结构：
  //   - file   = 被守卫文件（相对 ROOT_DIR 的路径段）；
  //   - stale  = **不得残留**的旧行号式锚（或已被取代的旧式锚）；
  //   - fresh  = **必须在位**的新式锚（函数名 / 符号名 / 断言名 / 结构串）；
  //   - notes  = 可选，不可修 / 需产品语义裁决的项以 note 登记（可见，不参与判别）。
  //   另设**跨文件对象核验**（generic，见本段末）：断言名式锚引用的 smoke.mjs 断言名
  //   MUST 在 smoke.mjs 中确实存在（死锚 / 改名漂移即红）——锚指向的对象由机器核验，
  //   而非仅核验锚串本身在位。
  //   FIX-040 扩面（R1 N4）：把 FIX-038 清扫面（llm-selection.js / metrics.mjs / smoke.mjs /
  //   install-entry.mjs / install.sh 引用位与 ci.yml / README 契约面）纳入同一清单，使
  //   「行号式锚零残留」成为机器看护而非人工巡检（此前全部靠手工逐个发现 ⇒ 必然复发）。
  // FIX-042 W2：本守卫**自身**也登记锚判据（自指锚一律用判据名/块名，不用行号——W2 机核实测本文件
  //   零处行号式自指）。自条目的**自满足陷阱**：若把某旧锚串以字面量整串写进本文件，ANCHOR_CASES 对
  //   本文件的 `includes` 判据会命中**本行自身**（X && X 恒真、判别力归零）；与同批其他文件条目的
  //   stale 字面量也会互相碰撞。故此类串统一以**拼接常量**定义——文件内不存在该连续串，而 needle
  //   的值与判据（`source.includes(needle)`）完全不变（改回字面量行号式锚即判红）。
  const OLD_PRESETDIAG_LINE_ANCHOR = 'presetDiag ' + ':127-141'
  // FIX-043 ⑤/⑥：**自条目**（file 指向本守卫）的 needle/fresh 一律以**拼接常量**登记——自条目判据
  //   对 `source.includes(...)` 是对本文件自身求值：字面量登记会使判据命中自身的定义处（stale 侧恒红、
  //   fresh 侧恒真 ⇒ 判别力归零），故必须让文件内不存在该连续串（9h-4b 机器判据看护此纪律）。
  //   两条分别对应 FIX-042 R1 P3-2 的旧口径措辞（被清扫对象）与替代后的如实口径句（新增在位要求）。
  const OLD_CLIENT_SELF_ANCHOR_CLAIM = '9 处 ' + '`lib/client.js' + ':<NNN>` 自锚'
  const FRESH_CLIENT_HOST_ANCHOR_CLAIM = '非本仓' + '自锚'
  const ANCHOR_CASES = [
    { file: ['lib', 'host-abi', 'ctx-services.js'], stale: ['preset-defaults.js:163', 'preset-defaults.js:194', 'preset-defaults.js:214', 'prestep.js:193', 'wrapper.js:516', 'oauth-llm.js:449', 'service.js:927', 'host-route.js:248'], fresh: ['safeListModels', 'sessionSelectFaceOf', 'agentsRegistryOf', 'agentPresetsServiceOf', 'llmFaceOf'] },
    // FIX-043 批 F（扩充既有条目；批 C 清除锚接线）：宿主转发事件白名单锚由「行号区间 + 裸行号」
    //   改为「常量名 + 条目内」式（批 C 逐处判定：宿主 `remote-events.js` 全表 19 项，原行号区间
    //   为本表定义段 ⇒ 现值准确，改形态以降漂移面）。裸锚登记带**同句上下文**（R3 六项要求 ①；
    //   裸 `:NNN` 单写必歧义）。对象不可本仓核验（宿主面）⇒ 本条目只判位于本仓文本内的锚串形态。
    { file: ['lib', 'host-abi', 'events.js'], stale: ['host-route.js:263-270', 'remote-events.js:12-32', '在表（:21）', '实读 28 项'], fresh: ['syncHostRoute', '`API_REMOTE_FORWARDED_EVENTS` 实读 30 项', '在该表条目内'] },
    // FIX-041 R0 F-2：同族在仓漂移锚收口——lib/stats.js 引 `lib/oauth-llm.js` 的 `:43`，该行现已
    //   漂移为无关注释（`export const OAUTH_PROVIDER` 实在该文件内）⇒ 按 FIX-041 W2 同形去行号
    //   改**符号名式**；本条目一并扩 stale/fresh（原条目只覆盖 `host-route.js` 的 `:55` 一串）。
    //   FIX-043 ⑤ 卫生：被清锚串**不得在登记说明里逐字复述**——一律分段写出（9h-4 机器判据看护）。
    { file: ['lib', 'stats.js'], stale: ['host-route.js:55', 'lib/oauth-llm.js:43'], fresh: ['host-abi/version.js', 'OAUTH_PROVIDER'] },
    { file: ['tests', 'fix-031-attribution.mjs'], stale: ['host-route.js HOST_ROUTE_PROVIDER'], fresh: ['host-abi/version.js HOST_ROUTE_PROVIDER'] },
    // FIX-042 W1（扩充既有条目，P5：同文件不重复登记）：`agentPresetsServiceOf` 先例锚原写
    //   `lib/preset-defaults.js` 的 `:100-108`（实测漂移——该区间非定义；定义实在
    //   lib/host-abi/ctx-services.js 的 `export function agentPresetsServiceOf`）⇒ 归属文件式。
    {
      file: ['tests', 'client-render.mjs'],
      stale: [
        'lib/host-route.js HOST_ROUTE_PROVIDER',
        'lib/preset-defaults.js:100-108',
        'lib/client.js:4754-4825',
        'lib/client.js:2842-2848',
        'service.js:193',
        'dsh-client-ui-model-selection lib/client.js:170',
        '宿主 lib/client.js:193',
        'directoryFor :187',
        'directory.d.ts:52',
        '首项，lib/index.js:19',
        'remote-events.js:21',
        '157-161 static inject',
        ':729-736 模块级 inject',
        ':799 exports.inject',
        '按 fiber.inject 声明门控 L342',
        'get 为可选查找 L335',
        'L581 waitingFor',
        // FIX-044 ③：`L####` wire-schema 块逐 schema 符号名重建后**清除**的旧行号式锚（`L` 族一律带同句
        //   上下文登记——裸行号必歧义；原锚 → 实读符号的逐条对照见下方 notes）。
        'llm/listProviders result L5678-5681',
        'L5671-5677、discoverModels(settingsNs, request) 参数 L5658-5664',
        '（裸数组）L5665-5670',
        'settings/describe result L4709-4757',
        'settings/mutate(ns, ops) L4758-4811',
        'credentials/describe result L4698-4702',
        'set(ref, value) L4703-4705',
        'unset(ref) L4706-4707',
        'agentPresets/list result L4315-4325',
        'session/modelCatalog result L7794-7823',
        'session/selectModel L7946-7956',
        '宿主 L5774-5778 真实形状',
      ],
      fresh: [
        'lib/host-abi/version.js HOST_ROUTE_PROVIDER',
        'agentPresetsServiceOf 先例，定义在',
        'connection handle 面已无 `api` 字段',
        'dsh-client-ui-settings-models 的 static `inject` 声明',
        'dsh-client-ui-model-selection 的',
        'super(ctx, "modelDirectories")',
        'directoryFor(sessionId)',
        'directoryFor「resolved no scope」',
        '首项 agent-preset/selected',
        '白名单锚 API_REMOTE_FORWARDED_EVENTS',
        'ModelDirectory.load',
        'static inject / 模块级 inject + exports.inject',
        'dynamicCordisContext',
        'waitingFor',
        // FIX-044 ③：替代式锚 = 宿主 `dsh-api-remotes/lib/client.js` 只读实读所得的**逐 schema 符号名**
        //   （同一动作汇入「符号名式」单一实现路径：行号式 → 符号名式）。
        '_deepseek_ai_dsh_llm_llm_listProviders_result$schema',
        '_deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema',
        '_deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema',
        '_deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema',
        '_deepseek_ai_dsh_llm_llm_discoverModels_result$schema',
        '_deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema',
        '_deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema',
        '_deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema',
        '_deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema',
        '_deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema',
        '_deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema',
        '_deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema',
        '_deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema',
        '_deepseek_ai_dsh_agent_presets_agentPresets_list_result$schema',
        '_deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema',
        '_deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema',
        '_deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema',
      ],
      notes: [
        'FIX-044 ③ 收口（批 F 登记的「wire-schema 块逐 schema 符号名重建」）：该块 12 处行号式锚已按宿主**只读实读**逐 schema 重建为符号名式（原锚 → 实读符号逐条对照见本批交付报告；P10-④：改建对象全部为宿主 `dsh-api-remotes/lib/client.js` 内实读可达的 `$schema` 常量标识符，零虚构）。**实测漂移（如实登记）**：原 claim 的 describe 区间起界错位——该区间首三条实为 credentials unset 参数 / credentials unset 结果 / settings canOpenAgentPresetDirectory 结果的 schema，describe 结果 schema 实在其后 3 行；另一组（llm 面）实为 **parameters 段**（非结果 schema）；另一处原 `L5774-5778` 引用实为宿主 descriptor 的 `sourceLocation` 元数据块（非 schema 定义）。⇒ 原「presets/authorable/hasDocument 三字段为宿主形状」claim **部分不成立**：`hasDocument` 属宿主 `settings_describe_result` 面（消费面 = `settings.describe()`），不在 agentPresets list 结果 schema 内——本批已在目标文件行内**如实更正**（未改产品代码、未放宽任何判据）。',
        '对象核验边界（如实登记，**不得作通过依据**）：fresh 侧只判「锚串在目标文件内到位」。宿主对象面：17 个符号中 **6 个**（listProviders / listConfigurableProviders / session modelCatalog / settings describe / credentials describe / agentPresets list 的 result schema）由 `tests/host-contract.mjs` 的 S5/S7 组在宿主可达时按符号逐字核验；其余 11 个（`discoverModels` / `settings mutate` / `credentials set·unset` / `session selectModel` 的 parameter/result 细分符号）**本批未新增宿主侧核验** ⇒ 本条目**不声称**机器覆盖宿主对象，宿主升级后 MUST 按 `tests/host-contract.mjs` 头部刷新程序重核。',
      ],
    },
    // FIX-040 W8a：llm-selection.js 三处行号锚（R0 P3-3，:99/:179 已实测漂移）→ 符号名式。
    // FIX-042 W3.3（扩充同条目）：该文件头部/中段 5 处**宿主锚**去行号改包名+符号名式
    //   （@deepseek-ai/dsh-llm 类定义与三方法 / dsh-api-session-controller 选择面 /
    //   dsh-host-apiproxy 空白判据）——宿主对象不可机器核验（见基线登记），此处只判本仓锚串形态。
    { file: ['lib', 'host-abi', 'llm-selection.js'], stale: ['preset-defaults.js:226-238', 'preset-defaults.js:209-240', 'preset-defaults.js:303-307', '@deepseek-ai/dsh-llm lib/index.js:1698', 'registerAdapter :1780', 'registration :2177', 'listModels :2018', 'index.js:605, 2502-2503', 'dsh-host-apiproxy L1187-1189'], fresh: ['lib/preset-defaults.js', 'sessionSelectFaceOf', 'sessionNeverProduced', 'inheritedRouteOf', 'LLM_FACE_METHODS', '宿主 @deepseek-ai/dsh-llm 的类定义', '宿主 dsh-api-session-controller', '宿主 dsh-host-apiproxy 的空白判据'] },
    // FIX-040 W4：metrics.mjs 的 12 处 smoke.mjs:<行号> 证据锚（实测偏 ~1038~1200）→ 断言名式。
    //   fresh 只列**连续**锚串（本项判「清单内连续锚串」这一形态，不判跨行/合并写作/片段形态）。
    //   如实界定（R1 P3-2(new)）：跨行/合并形态的**入表完备性**由 9h-3 覆盖；其**对象存活**是否
    //   被核验取决于该名是否在 9h-2 表内（表内 = 按声明单源核验；表外 = 无核验）——不声称闭环。
    {
      file: ['tests', 'metrics.mjs'],
      stale: [
        'smoke.mjs:1162-1177',
        'smoke.mjs:1316-1326',
        'smoke.mjs:816-820',
        'smoke.mjs:1473-1480',
        'smoke.mjs:1669-1682',
        'smoke.mjs:1500-1507',
        'smoke.mjs:1153-1157',
        'smoke.mjs:846-868',
        'smoke.mjs:1557-1569',
        'smoke.mjs:848-867',
        'smoke.mjs:1266',
        'smoke.mjs:1680-1681',
        'index.js:4832-4835',
      ],
      fresh: [
        'smoke.mjs「image turn config passes through unchanged (no whole-turn routing)」',
        'smoke.mjs「wrapper takes over default model」',
        'smoke.mjs「vision call returns text without echoing injected images (B)」',
        'smoke.mjs「native multimodal delegate sees raw image (preserveImageInput)」',
        'smoke.mjs §7.7 pre-step「image turn on wrapper route injects plugin reminder」',
        'smoke.mjs「collectMarkers dedupes by attachment」',
        'smoke.mjs「tool parameters schema」',
        'smoke.mjs「attachmentIds resolution (M2)」节',
        'smoke.mjs「follow-up text turn injects memory segment into system」',
        'smoke.mjs「wrapper delegate sees route_agent',
        'dsh-vision-router 同款：adapterHandlesImages 分支',
      ],
      notes: [
        '对象参考面限制（如实登记，**不得作为机器核验通过的依据**）：本条目 fresh 侧所指对象 = 本地参考副本 `.tmp-research/dsh-vision-router`（**在仓库路径内、版本控制外**，`.gitignore` 忽略；`dsh-vision-router` 在宿主装态**不存在**，`Test-Path` 为假）⇒ 仓库级守卫**不可机器核验该对象**，本条目只判「本仓文本内的锚串形态」；副本与上游是否同源无校验面。',
        '9h-3 兼容：本批新增于目标文件的文本**不含**「」引号段（该形态由「候选锚名入表完备性」判据扫描，误加即判红）。',
      ],
    },
    // FIX-040 W2/W8b：smoke.mjs 的旧式锚（行号区间 / 自锚）→ 符号名或内容式指代。
    // FIX-042 W4（扩充既有条目）：`check` 三参形态锚原写 `host-contract.mjs` 的 `:82-88`（实测 HIT，但属
    //   行号式）⇒ 去行号改签名式（C5 半条）。
    // FIX-043 批 F（扩充既有条目；批 D 清除锚接线）：本文件（`tests/smoke.mjs`）内三组宿主锚由批 D
    //   逐处判定后去行号——改「包名 + 符号名 / 函数名」式；其中两处来自 `dsh-llm` 边界投影段的裸行号
    //   锚，按 R3 六项要求 ① 一律带**同句上下文**登记（裸行号单写必与同数字短串歧义）。
    { file: ['tests', 'smoke.mjs'], stale: ['install-entry.mjs:74-77', 'typert contribution registered` 断言行\n  // （符号名式锚；原写死行号', 'host-contract.mjs:82-88', 'index.js:128-135 register / 269-279 match', '宿主 lib/index.js:2251', ':721-729，图片块逐个替换为', 'textOnlyImageText :541-543'], fresh: ['powerShellHosts', 'typert contribution registered', '紧随的 `19 invocations` 断言行', 'host-contract.mjs 的 `check(label, condition, detail)`', 'register(route) 支持 kind', 'match(pathname)', 'dsh-llm 的 adapterStream', 'projectImagesForTextModel', 'textOnlyImageText'] },
    // FIX-040 W2/W3：install-entry.mjs 引用侧符号锚在位（其 install.sh 行号锚已符号化）。
    { file: ['tests', 'install-entry.mjs'], stale: ['install.sh:94-101', 'install.sh:113-131', '拷贝/链接回退语义仅 win32 可判定'], fresh: ['powerShellHosts', 'lstatOrUndefined', 'PS1_OFFLINE_APPLICABLE', 'PS1_PLATFORM_DETAIL', '源码自带依赖目录', '绝不对真实目录 rm -rf'] },
    // FIX-040 W3：install.sh 契约面引用位（ci.yml 头部契约 + README 覆盖边界）同口径核验。
    //   install.sh 的宿主源码锚（node_modules / dsh-* 上的行号）刻意不入本清单（不在本仓库面）。
    { file: ['.github', 'workflows', 'ci.yml'], stale: ['install.sh:94-101', 'install.sh:113-131'], fresh: ['源码自带依赖目录', 'LINKED=0', '绝不对真实目录 rm -rf'] },
    { file: ['README.md'], stale: ['install.sh:94-101', 'install.sh:113-131'], fresh: ['源码自带依赖目录', 'LINKED=0', '拷贝回退护栏'] },
    // FIX-040 W5：README 行号锚（L16/L158/L165，实测漂移 7 行）→ 关键词/小节名式。
    { file: ['lib', 'preset-defaults.js'], stale: ['README L158', 'README L16', 'README L165'], fresh: ['README「预设 Agent 默认模型」节', '留空 = 继承主 Agent 模型'] },
    { file: ['tests', 'preset-defaults.mjs'], stale: ['README L158', 'README L16', 'README L165'], fresh: ['README「留空 = 继承主 Agent 模型」句', 'README「特性」节'] },
    // FIX-041 W3：同族 `README` 的 `L125` 行号锚（实测已漂移 ~141 行——`:125` 现为安装提示句，
    //   被引 qwen3.7-plus 事实句现位于 `README.md:266`「常见问题」节「视觉 agent 用什么
    //   模型？」条）→ 关键词/小节名式；两处引用同口径核验。**限定语**（FIX-041 R0 F-5）：
    //   「零残留」只在 **shipped 面（lib/** + tests/**）**成立——`docs/release/` 两处历史
    //   发布文档（`release-checklist-v0.3.2.md:30` / `version-plan-v0.3.2.md:82`）与
    //   `CHANGELOG.md:25`（已发布节冻结）仍含同族 `README L<n>` 锚，属**历史快照**（锚指向
    //   当时的 README 行号），刻意不清扫。
    // FIX-042 W1（扩充既有条目）：`lib/service.js` 裸 `:4074` 锚原指向「设备码会话取消」，
    //   实测 :4074 属 `oauthTokenExchange` 的 tokenRef 解析（对象不符）；同一事实在
    //   `exchangeDeviceCode` 的落盘前 cancelled 复查 ⇒ 符号名式。
    // FIX-043 批 F（扩充既有条目；批 C 判定为**刻意保留**项）：本文件两处宿主锚（§四 保留锚）的
    //   对象 `dsh-host-apiproxy` 在本机 DSH 0.1.5-rc.2 装态**不存在**（无实读对象）⇒ 原锚与其承载的
    //   语义**一并保留 + 显式登记**（不静默改指）；二者 MUST NOT 入 stale 侧（入表即判红）。
    //   fresh 侧新增「失效登记句」在位判据——登记句本身离开文本即红（登记不是一次性动作）。
    { file: ['lib', 'service.js'], stale: ['README L125', ':4074 的设备码会话取消'], fresh: ['README「常见问题」节「视觉 agent 用什么', '`exchangeDeviceCode` 的落盘前 cancelled 复查', '对象已消失、无实读对象'] },
    { file: ['tests', 'routing-paths.mjs'], stale: ['README L125'], fresh: ['README「常见问题」节「视觉 agent 用什么'] },
    // FIX-041 W2：镜像对中**可在本仓核验**的行号锚/自身锚已符号名化（6 处）——stale 零
    //   残留 + 替代式锚在位。镜像侧（tests/served-client.js）**不重复登记**：§3 的字节
    //   恒等判据（`served-client mirror stays byte-identical to lib/client.js`）是更强的
    //   保证（逐字节相等 ⇒ 内容判据自动传递），重复登记只增表面不增判别力。
    //   宿主包锚刻意不入本清单——不在本仓库面，仓库级守卫不可解析（见 FIX-041 W4 报告）。
    //   **存量计数口径**（FIX-041 R0 F-3 收口：使数字可复算，不得只留精确数）——对
    //   `lib/client.js` 全文逐行 `matchAll` 三种行号形态，统计**匹配次数**（非行数；同一行
    //   可含多锚）：① `/[A-Za-z0-9_@\/.-]*[A-Za-z0-9_-]\.(js|mjs|ts|tsx|sh|ps1):\d+(-\d+)?/g`
    //   ② `/\bL\d{2,4}(?:[-–]\d{2,4})?/g` ③ `/(?:^|[^A-Za-z0-9_]):\d{2,4}(\/\d{1,4})?([-–]\d{2,4})?/g`。
    //   本批交付**前**（`524a30d^`）= **47**（15/17/15）；交付**后**（符号名化 6 处）= **41**
    //   （13/17/11），其中余留者**全部**为宿主包锚。**口径差异说明**：不同正则粒度会给出
    //   不同数字（如审查员口径把 `L5682-5760` 只计为 `L5682`、并排除 `lib/client.js` 的 `/:342` 形态 ⇒
    //   13/17/8 = 38）——**数字必须连口径引用**，且随文本增删自动变化，不得作长期基线。
    // FIX-043 批 B（锚族分批清扫 批 B 收口）：**镜像对 24 处**（`lib/client.js` 12 处 ↔
    //   `tests/served-client.js` 12 处）行号式锚**逐处语义判定**后登记（判定表见交付报告；
    //   禁 grep 批量改写）。口径 = 批 A 同口径 `git grep -nE
    //   '([A-Za-z0-9_./-]+\.(js|mjs)):[0-9]+(-[0-9]+)?' -- <文件>`（行数口径）：批前 @`813c4a9`
    //   = 每文件 **12**；本批交付后同命令 = 每文件 **0**——引用 MUST 按引用时点重跑并标注修订，
    //   不得沿用他时点数字、不得作长期基线。
    //   判定要点（逐处）：**12 处全部为宿主包锚**（对象不在本仓库面），其中 **11 处的宿主对象已在
    //   本机宿主靶子逐字实读**（`_npx/1e7f6d9597241db0/node_modules/@deepseek-ai`，只读）⇒ 按
    //   FIX-042 W3.3 试点同法去行号改「包名 + 文件 + 符号名」式；**1 处为跨文件归属勘正**——
    //   `:2596-2630` 原属宿主 `dsh-host-apiproxy`（该包在本机 DSH 0.1.5-rc.2 装态中**不存在**，
    //   历史 P3-1/P2-2 直接读源码的采样为更早宿主构造）⇒ 改用本轮实读可达且语义同源的
    //   `dsh-api-session-controller` 的 `session.selectModel` 面 + prompt 侧准入 + pi-ai
    //   `streamWithSnapshot()`；**零新增未实证宿主符号**（P10-④）。**镜像侧不重复登记**：
    //   §3 的字节恒等判据（`served-client mirror stays byte-identical to lib/client.js`）是更强的
    //   保证（逐字节相等 ⇒ 内容判据自动传递；本批实测两侧 blob 同一 `7913db8c`）。
    //   宿主锚对象不可本仓核验 ⇒ 本条目只判**本仓文本内的锚串形态**，不声称机器覆盖宿主对象
    //   （基线登记与人工复检义务见上方注释）；本批新增的宿主可达面机器判据在
    //   `tests/host-contract.mjs` S2/S5（`expectPackage`/`expectFile`/`expectSymbol` + 靶子文件
    //   存在性核验——R0 P1-1 收口，宿主可达时生效）。
    { file: ['lib', 'client.js'], stale: ['lib/oauth-llm.js:43', 'presetDiagnostics :2109', 'health.js:35-48', 'OAUTH_ROUTE_PROVIDER :36', '权威单点 :124-125', 'lib/client.js:4754-4825', 'lib/index.js:2596-2630', ':2749-2760', 'dsh-llm-pi-ai index.js:1721', 'lib/client.js:889-911', 'remote-events.js:12-32', 'lib/client.js:581', 'lib/client.js:2842-2848', 'lib/client.js:4493-4499', 'lib/client.js:175-179', 'lib/index.js:19', 'lib/client.js:170', 'lib/client.js:752', 'lib/client.js:193', ':991-992/:2556-2588', '（同表 :21，凭据引用变化转发事件）', 'ui-conversation :16041-16056', '声明门控，:313-314/:342', '（generation 守卫，宿主 :47/:53）', '订阅该 store（宿主 :292）', 'API_REMOTE_FORWARDED_EVENTS（28 项转发事件'], fresh: ['lib/oauth-llm.js `export const', 'presetDiagnostics 方法存在性先例', 'lib/host-abi/health.js noteHostDiag', 'HOST_FACE_ERROR_CODES 三错误码', 'connection handle 面只有 isLoopback', 'joinProviderDirectory 同构镜像', 'API_REMOTE_FORWARDED_EVENTS（30 项转发事件', 'waitingFor 记录按 fiber.inject 过滤', '的 static inject（remote.credentials/llm/settings）', '的 inject 数组声明', '的 ctx.remote.$on 订阅', '的 directoryFor 面）的 directoryFor(sessionId).load()', 'scope.modelDirectories 属性面', 'directoryFor「resolved no scope」', 'dsh-llm-pi-ai 的 streamWithSnapshot()', 'session.selectModel 面）：session.selectModel 仅 resolveCallConfig', '的 prompt 侧准入', '其对**同批三命名', '`createModelsOperations(ctx)` 绑定的', '（FIX-043 批 C 按 R1 P2-2 裁定取'] },
    //   **宿主锚核验基线登记**（FIX-042 W3.2，落于本注释处；ARCH-005 R1/A1 刷新口径，
    //     ARCH-007 刷新）：基线 = 声明面逐代并集（`>=0.2.0-rc.2 <0.2.1-0 ||
    //     >=0.2.1-rc.1 <0.2.2-0 || >=0.2.2-rc.1 <0.2.3-0`，package.json engines.dsh 与 11 个
    //     `@deepseek-ai/dsh-*` peer 同值；R1 安装同步后本仓实装抽样 = **0.2.0-rc.2**
    //     〔历史树未随 0.2.2 主基线升级；cordis/schemastery 按插件自持范围解析 4.0.1/3.18.5〕，
    //     宿主基线权威源 = tests/host-version-snapshot.mjs 的 HOST_BASELINE_REGISTRY，
    //     主基线 = 0.2.2-rc.1）。
    //     **仓库级守卫不可解析宿主树 ⇒ 本清单不覆盖宿主锚、不声称机器覆盖**（宿主锚的数量与
    //     对象符号只由 W3 清点表登记，机器判据仅覆盖「本仓文本内的锚串形态」）。
    //     **人工复检义务**：宿主升级后 MUST 按 `tests/host-contract.mjs` 头部
    //     「如何刷新本套件（宿主升级后…）」程序、与 `tests/host-version-snapshot.mjs` 刷新步骤
    //     同步执行，逐处重核宿主锚的对象符号（存在性 + 语义）并同步改写本仓注释与基线常量。
    //     试点口径（FIX-042 W3.3）：宿主锚去行号改**符号名/包名式**（如
    //     `dsh-client-connection` 的 connection handle 面、`dsh-api-gateway` 的
    //     `Reflect.get(receiver, implementation)` 解析面）——不引入未实证的宿主符号。
    //   **清点数字的取数修订绑定**（FIX-042 R0 F-1 收口；本批自设纪律「数字必须连口径引用」）：
    //   宿主锚清点 = **97 处 / 22 文件 @ `6bc3841`（FIX-042 批前树）**，其中 H1（同行宿主线索）
    //   57 / H2（仅**上一行**线索）40。**复跑命令**：`node .test-home/fix042-host-family.mjs`
    //   （口径见该脚本头：H1 同行线索 / H2 仅取上一行；排除 .governance/**、docs/**、CHANGELOG.md）；
    //   批前树复现：`git worktree add <tmp> 6bc3841` 后在该目录用同一脚本复跑（实测 97/57/40/22）。
    //   **差额可复算（修订绑定时态口径）**：同一脚本在 **`61af16a`（W3 笔收口时点）** 复跑 =
    //   92 处 / 19 文件（H1 54 / H2 38）——差 = **13 处**「批前有 / `61af16a` 无」（= W3 试点清点的
    //   宿主锚位点：镜像对 2 + inject-manifest 1 + llm-selection 4 + host-route 1 + wrapper 1 +
    //   client-render 2 + rpc-shadow-guard 2）**− 8 处**「`61af16a` 有 / 批前无」（= FIX-042 新增的
    //   `ANCHOR_CASES` 条目及其备忘文本：`tests/client-render.mjs` / `lib/host-abi/llm-selection.js` /
    //   `lib/host-abi/inject-manifest.js` / `lib/oauth-llm.js` / `lib/wrapper.js` /
    //   `tests/rpc-shadow-guard.mjs` / `lib/host-route.js` 七条目 + llm-selection 条目备忘注释一行
    //   = 8 行 @`61af16a`；其文本自身即含行号形态 ⇒ 被该工具计入）。**FIX-043 批 E 处置**：原文本以
    //   本文件**自身行号**枚举这 8 行（自指随增删行即漂移——FIX-042 时点与批 E 时点已不一致）⇒
    //   按本文件 9h-4b 段「自指一律用判据名/块名」的口径改为上述**条目名式**。工具 =
    //   `.test-home/fix042-inventory-diff.mjs`（用法见其文件头；输入 `fix042-base.txt` / `fix042-head.txt`）。
    //   **自我引用注意**：本段注释与 ANCHOR_CASES 条目文本**自身即含行号形态** ⇒ 每增一行都会再次改变
    //   计数（R0 返工笔后同一脚本实测已给 94/19）——这正是「数字必须连**取数修订**引用」的实证：
    //   **任何引用 MUST 按引用时点重跑并标注修订**，不得沿用他时点数字、不得作长期基线。
    //   **快照取数时点绑定**（FIX-043 ⑦ / FIX-042 R1 P3-3 收口）：差额工具的两份输入 = **时点快照**
    //   ——`fix042-base.txt` @`6bc3841`（自声明 97/22，本批实测吻合）/ `fix042-head.txt` @`61af16a`
    //   （自声明 92/19，本批实测吻合）；两者 MUST 按引用时点重生成，不得跨时点复用。
    //   **锁外未闭合（如实登记，不制造改动）**：工具头 / 表头（`.test-home/`，未跟踪取证件）内的
    //   快照时点标注不在本批锁面（本批只可改 `tests/host-contract.mjs` / `tests/host-abi-health.mjs`）
    //   ——该处标注移交后续批；守卫侧登记面即本段，已含两份快照的修订绑定与复跑命令。
    //   **本批实测计数回填**（FIX-042 R0 F-2 收口；提交信息历史不回改 ⇒ 计数事实以本行为准）：
    //   W1 = **12** 个 MISS 位点 / **8** 文件（`+20/−19`）；W2 = `ANCHOR_CASES` **16→22** 条目 /
    //   断言 165→**171**；W4 = 4 文件（`+14/−4`）/ 条目 22→**24** / 断言 **173**；W3 = 试点 **11** 锚位 /
    //   **8** 文件（5 lib + `tests/rpc-shadow-guard.mjs` + `tests/client-render.mjs` + 镜像侧
    //   `tests/served-client.js`）/ 条目 24→**25** / 断言 **174**；4 笔合计 **15** 文件（`--numstat` 口径）。
    //   **隔行站点登记**（FIX-042 R0 F-3）：对象在同块**隔行**（非同/上一行）的宿主锚未入 97 ——
    //   三处站点为「`lib/client.js` 的 `session.selectModel` 面」（宿主 `dsh-host-apiproxy` 面、
    //   隔行线索）、「`lib/service.js` 的模型信息面」（同上宿主面）、「`lib/wrapper.js` 的模型解析链」
    //   （**FIX-042 已按 W3.3 同法**去行号改符号名式：宿主 dsh-llm 的
    //   `resolveModelInfo → resolveModelInfoFor → adapter.resolveModel` 链——该处为清单外**真漂移**，
    //   审查员以宿主树只读实证原锚现为 `assembleAssistantStream`）。
    //   **FIX-043 批 B 收敛（登记修订）**：第一处（`lib/client.js`）本批已收敛——原宿主
    //   `dsh-host-apiproxy` 在本机 DSH 0.1.5-rc.2 装态中**不存在**（靶子实读判在），故改用本轮
    //   实读可达且语义同源的 `dsh-api-session-controller` 的 `session.selectModel` 面 +
    //   prompt 侧准入 + pi-ai `streamWithSnapshot()`，包×文件存在性由 `tests/host-contract.mjs`
    //   S2 判据机器核验；**第二处（`lib/service.js`）不在本批锁面，归后续批**（如实登记，不制造
    //   跨文件改动）；第三处已于 FIX-042 收敛。
    // FIX-042 W1/W2：在仓漂移锚收口批（8 文件）的看护接线——FIX-041 R1 §三.3 硬前置「逐处语义
    //   判定」已逐处执行（判定表见 FIX-042 交付报告 W1），本段只登记**判定后**的 stale/fresh 对：
    //   stale = 本轮清除的旧行号式锚串（零残留即绿）；fresh = 替代式符号名/代码串锚（在位即绿）。
    //   FIX-043 ⑥ 如实口径（FIX-042 R1 P3-2 收口——原句写「9 处自锚」与实测不符）：宿主锚（`dsh-*` /
    //   宿主 上下文，**非本仓自锚**）**不入本清单**：对象不在本仓库面，仓库级守卫不可解析宿主树
    //   （基线登记与人工复检义务见上方注释）。
    //   **数字口径 + 取数时点绑定（FIX-043 批 B 首订；批 E 按 R1 P2-1 复算修订——原句「8 处 / 包名
    //   邻近行分布」在两批清扫后已失真，属 FIX-042 R0 P2-1 同族：不得沿用他时点数字）**：
    //   口径 a = `git grep -oE 'lib/client\.js:[0-9]+(-[0-9]+)?' -- lib/client.js`（**匹配次数**，非行数）：
    //     `6bc3841`（FIX-042 批前树）= **9** → `175d3e1` / `813c4a9` = **8** → **批 B 交付后 @`cfe7756` = 0**
    //     （差额链自洽：9 = **1 处 FIX-042 已清** + **批 B 清除的 8 处** `lib/client.js` 自指宿主锚；
    //     批 E 复算修订——原写「本批清除的 7 处」为 off-by-one，R1 P2-1；批 E 未改 `lib/client.js`
    //     ⇒ 起止值同批 B 时点）。**批 C 后 @`2ea0bc9` = 0**（该形态不在批 C 清除面 ⇒ 值不变，时点已标明）。
    //   口径 b = 上述 FIX-041 R0 F-3 的三种行号形态 matchAll（① 文件:行号 ② `L###` ③ 裸 `:NNN`）——
    //     **匹配次数口径**（同一行多锚各计一次；**两种口径不可混用**）：
    //     `813c4a9`（批 A 前树）= **40**（①12 / ②17 / ③11）→ **批 B 后 @`cfe7756` = 24**（①0 / ②17 / ③7）
    //     → **批 C 后 @`2ea0bc9` = 17**（①0 / ②17 / ③0）——①③ 双归零；② 不变（该形态不在本批清除面）。
    //     **③ 族逐处标注（FIX-043 批 F 收口 R2 P2-2）**：**已删除原总括断言**——原文把该 7 处一律定性为
    //     「宿主锚无法符号化 ⇒ 无实证不引入新符号、刻意保留」，该定性**无实证支持**且与本段自陈的
    //     「登记为后续批逐处判定」自相矛盾（R1 P2-3 / R2 P2-2）。现按批 C 的逐处判定结果标注（判定证据 =
    //     `.governance/review-FIX-043-R3-input.md` §1.2 / §2.2，宿主只读实读逐处）；**5 行 / 7 token
    //     全部可符号化并已收敛**：
    //       · `:2138`「同表 `:21` 出处引用」→ **准确**（宿主 `dsh-api-remotes/lib/types/remote-events.js`
    //         的转发事件表第 `:21` 条确为 `credentials/reference-updated`）⇒ 去行号改符号式
    //         （`API_REMOTE_FORWARDED_EVENTS 条目内`）；
    //       · `:4310`「`ui-conversation` 的 `:16041-16056`」→ **不准**（该区间实为
    //         `dsh-client-ui-conversation` 的 InputBar JSX 渲染段，`PropsHooks` 在该包 0 命中）
    //         ⇒ 改代码串式（宿主 `ctx.uiSession.provide({ hooks, props })` 面）；
    //       · `:5453`「`:313-314/:342`」→ **准确**（`dsh-cordis-client-runner` 的 JSDoc +
    //         `readService(prop, true)`）⇒ 去行号改符号式（`宿主 readService(prop, true) 面`）；
    //       · `:5561`「`:47/:53`」→ **漂移**（`generation === this.generation` 实位于 `:48/:55/:61`，
    //         原 `:47`/`:53` 为无关语句）⇒ 改符号式（`generation === this.generation 守卫`）；
    //       · `:5562`「`:292`」→ **不准**（该行实为 `directoryFor` 的 JSDoc；真实订阅点 =
    //         `:128` / `:131` / `:314` / `:409`）⇒ 改符号式（`宿主 directory.store.subscribe +
    //         ModelSelect 的 uSES 订阅`）。
    //     **行数口径对照**（不得与上式混用）：② 行数 = **9**（同一行含多枚该形态锚时按 1 行计；
    //     三时点不变）vs 匹配次数 = 17；口径 b 整体行数 = **29 → 14（批 B）→ 9（批 C）**。
    //   **任何引用 MUST 按引用时点重跑并标注修订，不得沿用他时点数字、不得作长期基线。**
    { file: ['lib', 'host-abi', 'health.js'], stale: ['lib/preset-defaults.js:116-124', OLD_PRESETDIAG_LINE_ANCHOR], fresh: ['presetDiag/notePresetDiag'] },
    // FIX-043 ⑤（FIX-042 R1 P3-1 收口）：F-3 登记曾把被清扫的锚串**逐字**写入守卫 ⇒ 该 needle 成
    //   「自碰撞死 needle」（守卫自身 +1、目标文件 0）。改**拼接常量**登记——needle 值与判据
    //   （`source.includes(needle)`）完全不变，而守卫文本内不再存在该连续串（由 9h-4/9h-4b 看护）。
    { file: ['lib', 'host-abi', 'inject-manifest.js'], stale: [':5060 先例', 'lib/client.js:5060', 'dsh-client-modules ' + 'lib/client.js:265-268'], fresh: ['const inject =', '宿主 dsh-client-modules 的包表行'] },
    // FIX-043 批 F（扩充既有条目；批 C 清除锚接线）：本文件三组锚**均已漂移**——宿主 dsh-system-prompt
    //   的 tool provider schemas 解构面（原行号区间现值 `getContextOrder` JSDoc）、dsh-llm-pi-ai 的
    //   `toolsOf` 读法（原区间现值 context 模块注释）、宿主 `LlmAdapter` 空体默认三处 ⇒ 批 C 实读判定后
    //   改**代码串 / 符号名式**（P10-④：零新增未实证符号；对象逐字实读）。
    { file: ['lib', 'oauth-llm.js'], stale: ['runCodexResponsesChat :2906-2929', 'dsh-system-prompt lib/index.js:254-258', 'dsh-llm-pi-ai lib/index.js:1123-1128', 'lib/index.js:1645', 'lib/index.js:1996-1998', ':1639 "must answer synchronously', '（:1645 空体', 'Pricing schema :171-178'], fresh: ['`runCodexResponsesChat`', 'result.schemas.map(({ name, description', 'toolsOf(options)', '`imageRequestPricing(_provider, _model)` 空体默认', 'LlmRuntime.imageRequestPricing 经'] },
    // FIX-042 R0 F-3（扩充同条目）：`lib/wrapper.js:266` 的宿主锚（全角括号形态的 `:1397-1403`）为清单外**真漂移**
    //   （审查员宿主树实读：`dsh-llm resolveModelInfoFor` 在 `:2046`、`adapter.resolveModel` 在 `:2047`；
    //   `:1397-1403` 现为 `assembleAssistantStream`）⇒ 去行号改符号链式（与 W3.3 试点同法）。
    // FIX-043 批 F（扩充既有条目；批 C 清除锚接线）：宿主 `LlmAdapter` 空体默认契约方法的四处行号式
    //   锚（含宿主 JSDoc 注释行与 `LlmRuntime` 消费点）已由批 C 去行号 ⇒ 与 `lib/oauth-llm.js` 条目
    //   同对象的**连续串**在本条目重复登记（P5：同对象同形态不因文件而异，两处消费面各自登记）。
    { file: ['lib', 'wrapper.js'], stale: ['stream 直传分支（下方 :353）', 'dsh-llm lib/index.js:1527', '（:1397-1403）', 'lib/index.js:1645', ':1639 "must answer synchronously without', '（:1996-1998）', '默认语义 :1645'], fresh: ['`stream()` 的图片块保真直传分支', '宿主 dsh-llm 的 `registration()` 实现', '`resolveModelInfo → resolveModelInfoFor → adapter.resolveModel` 链', '`imageRequestPricing(_provider, _model)` 空体默认'] },
    { file: ['tests', 'rpc-shadow-guard.mjs'], stale: ['lib/service.js:673', 'lib/service.js:3172', 'dsh-api-gateway/lib/index.js:101-103'], fresh: ['`this.stats = new StatsStore(...)`（lib/service.js）', '`statsSnapshot()` 委托', '宿主 dsh-api-gateway 的 `Reflect.get(receiver, implementation)` 解析面'] },
    // FIX-042 W2（**结论口径经 F-4 更正与限定**）：**本守卫自身**的锚注释同口径看护——结论限定为
    //   「本文件无**指向本文件自身位置**的行号式自指」（口径：注释行内 `:NNN` / `L###` 且**被指
    //   对象在本文件**；`ANCHOR_CASES` 的 stale 字段字面量清单、以及**他文件锚**的历史引用**不计入**）。
    //   自指一律用判据名/块名（如「9h-2b 的 ANCHOR_OBJECTS_3 校验块」）——行号式自指随增删行即失效，
    //   即 FIX-041 R1 P3-2 指出的失效机理。**FIX-042 R0 F-4 如实更正**：原句「本文件零处行号式自指」
    //   未带口径 ⇒ 属**声明强度超过事实**（宽口径下另有多处他文件锚的历史引用）；FIX-042 W2 已把唯一
    //   一处**无归属**的行号式锚去行号（原形为裸 `:NNN`，对象 = `tests/metrics.mjs` 的旧锚名段——
    //   归属改写见 9h-2 表内注释；批 E 复算：该处行号残留 = 0），两口径计数由
    //   `.test-home/fix042-w2-selfref.mjs` 机核（严格口径 = 指向本文件者；宽口径 = 注释行内全部行号式锚）。
    //   stale 侧 = 本批自本文件清除的旧行号式锚（拼接常量，见上）；fresh 侧 = 替代式符号名/代码串锚
    //   （同样拼接写出，规避自满足）。
    //   **FIX-043 批 E 自指清扫 + 复算（取数时点 = 派发时 HEAD `2d65f6e` / 前批 `813c4a9`）**：口径 =
    //   `git grep -nE '([A-Za-z0-9_./-]+\.(js|mjs)):[0-9]+(-[0-9]+)?' -- tests/host-abi-health.mjs`
    //   （**行数口径**；括注**匹配次数**口径，两者不可混用）：`813c4a9` = **34 行 / 67 匹配次数** →
    //   `2d65f6e` = **32 行 / 75 匹配次数**（批 B 改动本文件 ⇒ 两个数字 MUST 各绑其时点，不得沿用）。
    //   逐处语义判定（判定表见 FIX-043 批 E 交付报告）结果：**上述 32 行内自指 = 0**——全部为 stale
    //   数据单元的 needle 清单（`ANCHOR_CASES`，对象为他文件/宿主）与他文件锚（`lib/**`、`tests/**`）、
    //   宿主锚（`dsh-*`）的历史引用（判定：保留 + 登记，本批不改其对象面）；**自指落在裸 `:NNN` 族**：
    //   差额段对该 8 个本文件自身行的枚举（1 组，按上述口径**不计入** 32）⇒ 已改条目名式（见上方
    //   「差额可复算」段）；另 3 处（无归属的历史登记去行号 / 宿主区间归属误标 / ⑥ 段落引用句失真）
    //   已按判定更正。**零 grep 批量改写**：逐处读上下文后单点修改。**机核口径的已知边界**：`.test-home/fix042-w2-selfref.mjs` 的归属
    //   解析取「同注释块内最近文件名 token」启发式 ⇒ 自指若同块紧邻他文件名即被误判为非自指
    //   （批 E 实测：该脚本 严格口径报 0，而差额段 8 处**实为自指**——故自指判定 MUST 按语义复核，
    //   不得只信该启发式）。
    //   **FIX-043 批 F：宽口径他文件裸锚收敛（R2 P2-3 判定面的收口）**——本文件「注释散文中的行号式
    //   锚」逐处语义判定，收敛判据 = **同一句内可唯一确定对象**（点名对象文件 / 宿主包，或所在登记单元
    //   的 `file` 字段唯一确定）。**逐处读上下文后单点修改，零 grep 批量改写**。本批收敛 2 处**无归属**者：
    //     (a) 某 check 标签内的「三错误码降级体系」引用（原为裸行号、未点名对象）⇒ 补归属并改符号名式
    //         （`lib/client.js` 的 `HOST_FACE_ERROR_CODES`）；
    //     (b) `lib/stats.js` 条目注中「`export const OAUTH_PROVIDER` 实在 <行号>」⇒ 去行号改「实在该文件内」。
    //   保留 = **有归属**者，逐类登记：(1) **登记数据单元内的字面量**（对象由该单元 `file` 唯一确定，
    //   且属判据输入而非散文引用）；(2) **历史登记注**（同句已点名对象文件 / 宿主包；去行号会丢历史
    //   信息）；(3) **宿主锚注**（同句已点名宿主包）；(4) 本批 ⑥ 段落的**逐处标注**（每站点自带对象与
    //   判定结论）。
    //   **计数**（口径 = FIX-041 R0 F-3 的第 ③ 形态正则；取数时点 = 本批交付工作树 —— 该数字随本文件
    //   增删自动变化，**不得作长期基线**，引用 MUST 连口径 + 时点）：
    //     全文件 = **53 行 / 101 处**；其中**登记数据单元内** = 25 行 / 56 处；**单元外**（散文 + 拼接
    //     常量片段）= 28 行 / 45 处 —— 单元外逐行均已归入上述四类，**「无归属」者 = 0**。
    //   判定面口径分层（补 R2 P2-3 的「声明面与判定面等宽」要求）：层 A = 带文件名自指（本文件路径 +
    //   行号）全文件 = 0；层 B = 行号族**逐处归属复核**（结论：无一处指向本文件）；层 C = 历史自指原位
    //   比对（批 A 前树中指向本文件的 8 个行号，在本文件同模式命中 = 0）。**自指判定 MUST 按语义复核**
    //   ——`.test-home/fix042-w2-selfref.mjs` 的「同注释块内最近文件名 token」启发式有已知盲区（批 E
    //   实证其结论与语义判定相反），**禁用该启发式结论替代人工判定**。
    { file: ['tests', 'host-abi-health.mjs'], stale: [OLD_PRESETDIAG_LINE_ANCHOR, OLD_CLIENT_SELF_ANCHOR_CLAIM], fresh: ['presetDiag/notePresetDiag ' + '纪律同构', FRESH_CLIENT_HOST_ANCHOR_CLAIM] },
    // FIX-042 W4：语义待定 5 项中「在仓且可改」的 2 处（第 3 处 `tests/smoke.mjs` 已并入上方既有条目）：
    //   ① tests/stats.mjs 的 `service.js` 的 `:2414-2561` 实为**历史迁移源**（现址为模态判定面，对象不符）
    //      ⇒ 改为「EVO-003 迁移前 RouterService 内联聚合」+ 现单点 `StatsStore`；
    //   ② tests/fix-012-image-takeover.mjs 的 `lib/client.js` 的 `:3226` 指**已勘正的旧注释**（现址为
    //      preset schema 保存形状）⇒ 改为归属文件式（假设文本仍可 grep：`会话已含图`）。
    { file: ['tests', 'stats.mjs'], stale: ['service.js:2414-2561'], fresh: ['EVO-003 迁移前 RouterService 内联聚合'] },
    // FIX-043 批 F（扩充既有条目；批 D 清除锚接线）：本文件三组宿主锚由批 D 判定为「包不存在 + 归属
    //   勘正」（`dsh-host-apiproxy` 在本机装态不存在 ⇒ 改用 `dsh-api-session-controller` 的 prompt 侧
    //   准入面）+「行号漂移」⇒ 去行号改符号/错误码式；两处裸 `:NNN` 按 R3 六项要求 ① 带同句上下文。
    { file: ['tests', 'fix-012-image-takeover.mjs'], stale: ['lib/client.js:3226', 'dsh-host-apiproxy lib/index.js:2749-2760', '（:2596-2630）', '（:2749-2760）', 'dsh-llm-pi-ai lib/index.js:1721'], fresh: ['lib/client.js 的旧假设', 'dsh-api-session-controller 的 prompt 侧准入', 'selectModel(request) 面', 'MODEL_DOES_NOT_SUPPORT_IMAGES', 'UNSUPPORTED_CONTENT 判定'] },
    // FIX-042 W3.3：宿主锚有界试点（本仓文本侧判据——去行号改包名+符号名式；宿主对象核验不可机器化，
    //   见上方基线登记）。lib/host-route.js 为本批新增条目（其余试点文件已并入各自既有条目）。
    // FIX-043 批 B：**隔行站点**登记批 A 两处已由本批收敛——`lib/client.js` 的宿主
    //   `dsh-host-apiproxy` 行号锚已改用本机宿主靶子实读可达的 `dsh-api-session-controller` 面
    //   （包 × 文件存在性由 `tests/host-contract.mjs` S2 判据核验）；`lib/service.js` 的
    //   「`lib/service.js` 的模型信息面」（宿主 `dsh-host-apiproxy` 面、隔行线索）同族站点**不在本批
    //   锁面**，归后续批（登记，不制造改动；该宿主包在本机装态中不存在 ⇒ 锚现值不可本仓核验）。
    //   **守卫自身面（FIX-043 批 E 判定 → 处置）**：本段原登记「守卫自身面的宿主锚行号计数句已失真
    //   ⇒ 归后续批修正」——批 E 实测该项**已闭合**：该行号引用（`lib/client.js` 侧宿主锚，原以
    //   「文件 + 行号」形态出现、并误标为 ⑥ 段落内容）已由批 B 改写「隔行站点登记」时随条目名式
    //   （「`lib/client.js` 的 `session.selectModel` 面」）一并清除——本文件内零残留，故不再挂后续批；
    //   ⑥ 段落的计数句（口径 a / 口径 b）由批 E 按 R1 P2-1 复算修订（见上方 ⑥ 段落）。
    // FIX-043 批 F（扩充既有条目；批 C 清除锚接线）：宿主 `dsh-settings` 的 `mutate`/`write` 两处行号式锚
    //   已由批 C 判定为**已漂移**（原区间已不含其所描述字面量 / `write()` 实体不在原区间）⇒ 改
    //   「方法签名 + 文件/包名」式；宿主对象不在本仓库面 ⇒ 本条目只判本仓文本内的锚串形态。
    { file: ['lib', 'host-route.js'], stale: ['dsh-credentials-local resolve(:473)/set(:513)/unset(:517)', 'dsh-settings lib/index.js:430-436', 'write()（:439-470）'], fresh: ['宿主 dsh-credentials-local 的 `resolve`/`set`/`unset`', '`mutate(ns, ops, expectedRevision)` 契约', '`write(ns, input, mode,'] },
    // FIX-043 批 A（锚族分批清扫 批 A 收口）：`tests/host-contract.mjs` 的 19 处行号式锚**逐处语义判定**
    //   后登记如下（判定表见交付报告；禁 grep 批量改写）。判定要点：**8 处是 `anchor:` 字段且被
    //   S2/S5 的「锚形态」判据消费** ⇒ 改前先在代码内把该两条判据由「路径:行号」改写为「宿主包名 +
    //   宿主文件 + 宿主符号」（否则去行号即判红；改写后判据面为三元 token，覆盖 > 单行号，且符号可由
    //   S7 增强组在宿主可达时逐字核验）；**1 处（`extra` 签名锚）为跨文件逐字在位断言**，源串在锁外
    //   文件（`tests/fix-029-host-contract.mjs` 与 `lib/prestep.js`）亦在位 ⇒ 本批**保留**（notes 登记）；
    //   其余 10 处为注释/断言标签面（不参与判据谓词 ⇒ 改文本不改判据强度）。**口径外同族**（同文件）
    //   一并处置：`.d.ts` 行锚 2 处 + 设计文档 `L###` 行锚 5 处（判定同上）。宿主锚对象不在本仓库面
    //   ⇒ 本条目只判**本仓文本内的锚串形态**，不声称机器覆盖宿主对象（基线登记见上方注释）。
    //   数字口径（批前 / 批后同一命令；口径 = FIX-042 R0 #23 审查员口径：`git grep -nE
    //   '([A-Za-z0-9_./-]+\.(js|mjs)):[0-9]+(-[0-9]+)?' -- tests/host-contract.mjs`，行数口径）：
    //   批前 @`175d3e1` = **19**；本批交付后同命令 = **1**（余 1 处 = 上记保留项，见 notes）——引用 MUST
    //   按引用时点重跑并标注修订，不得沿用他时点数字、不得作长期基线。
    {
      file: ['tests', 'host-contract.mjs'],
      stale: [
        'dsh-api-remotes lib/client.js:5727-5734',
        'lib/client.js:8164-8193',
        'dsh-llm lib/index.js:1618',
        ':1624/:1635/:1645/:1653/:1665/:1681',
        'lib/service.js:1437-1443',
        'remote-events.js:12-32',
        'lib/index.js:605,2502-2503',
        'lib/types/agent.js:289-318',
        ':297-299',
        'lib/types/client/service.d.ts:44',
        'lib/types/client/directory.d.ts:13-32,60',
        '设计 §5.1 L272',
        'lib/client.js:5735-5738',
        'lib/client.js:4712-4730',
        'lib/client.js:4701-4705',
        'lib/client.js:4315-4325',
        'dsh-llm lib/index.js:1618-1687',
        'service.js:28',
        'prestep.js:33',
        'lib/service.js:636',
        'lib/tool.js:61-219',
      ],
      fresh: [
        '宿主 dsh-llm 的 LlmAdapter 类原型',
        'assembler.push/usage/finish/blocks 消费块',
        'API_REMOTE_FORWARDED_EVENTS 单向消费断言核验',
        'selectionFor(agent) → stateOf(session, \'modelSelection\') → projectionState.pending',
        'stateOf(session, \'modelSelection\') → projectionState.pending',
        'llm_listConfigurableProviders_result schema',
        'llm_listProviders_result schema',
        'session_modelCatalog_result schema',
        'settings_describe_result schema',
        'credentials_describe_result schema',
        'agentPresets_list_result schema',
        'directoryFor(sessionId: SessionId): ModelDirectory 面',
        '设计 §5.1(a)',
        '锚点带「宿主包名 + 宿主文件 + 宿主符号」',
        '锚点带「宿主包名 + 宿主文件 + schema 符号」',
        'createUserMessage 消费面 = lib/service.js 与 lib/prestep.js 的 dsh-llm/message import 行',
        '`export class RouterService extends TypertRemoteService` 继承锚',
        'ctx.tools.register(defineTool( 块锚宿主 defineTool options 契约',
        '锚宿主 dsh-api-remotes 的 lib/types/remote-events.js 事件表',
      ],
      notes: [
        '保留定判（FIX-043 批 F 逐处判定；原登记为批 A 的「未闭合（本批保留）」项，`:270` 系批 A 批前树行号 → 批 A 插入后现址 = 本文件 S2 `extra` 行）⇒ **维持保留**，理由 = `extra` 签名锚含 `types/agent.js` 的 `:297-318`，为**判据承载锚**（非「不可符号化」）：机器锁 2 处 = 本行 needle + 对象文件 `tests/fix-029-host-contract.mjs`（`includes()` 原文、不经注释剥离 ⇒ 单侧去行号即判红）；`lib/prestep.js` 同串为 P5 收敛纪律锁（无守卫绑定）。收敛 MUST 三处同步且**先改判据**。R4 §2.1 独立复算谓词：现文 `[true,true]` / 去行号 `[false,true]`。行内逐处理由另见本文件 S2 该 face 处注释。',
      ],
    },

    // ═══ FIX-043 批 F 新增条目（9 个文件级条目：`lib/**` 面 4 新建 + `tests/**` 面 5 新建）══════════
    // 依据 = `.governance/fix-043-anchor-cases-requirements.md` §一（A~J，lib 面）与 §二（tests 面 9 文件），
    // 逐条按**本批引用时点**（工作树 `ce8d908` + 批 F 改动）重跑并与载体交叉核对；条目值经批 F **三向
    // 核验**（stale：批前树在位 × 现树缺席；fresh：现树在位）——核验命令/输出见本批交付证据。**与载体
    // 字面不符者按实况修正**（例：`createModelsOperations` 的登记串实为带反引号形态；`index.js:605,2502`
    // 补归属前缀以降歧义），逐条差异列入交付报告。
    // 约定（R3 六项条目录入要求）：① 裸 `:NNN` 族登记**一律带同句上下文**（裸登记必歧义）；② §四 的
    // 两处保留锚 MUST NOT 入本表；③ 镜像侧（`tests/served-client.js`）**不重复登记**（§3 字节恒等判据
    // 更强）；④ R2 P2-2 总括断言已随本批删除并改逐处标注（见上方 ⑥ 段落）；⑤ 本表条目数 26 → **35**，
    // `9h-4c` 的单元数判据随之变化（按引用时点重跑，不得沿用他时点数字）；⑥ 跨文件同锚旧形态已同步
    // （`tests/fix-029-host-contract.mjs` 见下）。

    // ── lib 面 4 新建（批 C 清除锚接线）──
    {
      file: ['lib', 'index.js'],
      stale: [
        'lib/index.js:128-135',
        'lib/index.js:269-279',
        'lib/attachments.js:38',
      ],
      fresh: [
        "route.kind === 'exact' ? this.exact : this.prefixes",
        '`match(pathname)` 对 exact 未命中作最长前缀优先',
        'lib/attachments.js 的 ATTACHMENT_ID_RE',
      ],
      notes: [
        '**双归属说明**（防误读）：前两处 stale 锚写出的 `lib/index.js` 指**宿主** `dsh-host-webserver` 的同名文件（非本仓同名文件）；第三处为**在仓** `lib/attachments.js` 的引用。三处均经批 C 宿主/在仓只读实读判定（前两处实读为 gzip 中间件与路由查表 ⇒ 现值非所声称对象；第三处现值准确），改符号/代码串式以降漂移面。',
      ],
    },
    {
      file: ['lib', 'prestep.js'],
      stale: [
        'vision-router index.js:4803-4806',
        'index.js:4832-4835',
      ],
      fresh: [
        'activateDeepTools()',
        'adapterHandlesImages',
      ],
      notes: [
        '保留（MUST NOT 入 stale 侧）：`types/agent.js` 的 `:297-318` 判据承载锚**刻意保留**——受 `tests/host-contract.mjs` 的 S2 `extra.signatures` 跨文件逐字在位断言约束（收敛 MUST 三处同步且**先改判据**）。**逐处理由全集**（完整指向，三处；FIX-044 ② 收口）：① `tests/host-contract.mjs` 的 S2 `extra` face 处**行内注释**（该处 9 行判定理由：机器锁 1/2 + P5 纪律锁 + 处置顺序）；② `tests/fix-029-host-contract.mjs` 头部**行内判定注释**（机器锁的**对象面**）；③ `tests/host-abi-health.mjs` 的 `tests/fix-029-host-contract.mjs` 条目 `notes`（收敛顺序说明）。',
        '对象参考面限制：两处 stale 锚的对象 = 本地参考副本 `.tmp-research/dsh-vision-router`（**在仓库路径内、版本控制外**；该包在宿主装态不存在）⇒ 仓库级守卫**不可机器核验该对象**，本条目只判本仓文本内的锚串形态。',
      ],
    },
    {
      file: ['lib', 'oauth-credentials.js'],
      stale: [
        'openai-codex.js:30',
        'openai-codex.js:31',
      ],
      fresh: [
        '`openai-codex.js` 中 `DEVICE_REDIRECT_URI`',
        '`openai-codex.js` 中 `DEVICE_CODE_TIMEOUT_SECONDS`',
      ],
      notes: [
        '归属：两处 stale 锚的对象 = 宿主 `@earendil-works/pi-ai` 的 `dist/auth/oauth/openai-codex.js`（批 C 宿主**只读**实读：两常量现值**准确**）⇒ 去行号改「文件 + 常量名」式以去漂移面。',
      ],
    },
    {
      file: ['lib', 'host-abi', 'client-remotes.js'],
      stale: [
        'PROVIDER lib/client.js:36 镜像先例',
        'settings-models lib/client.js:889-911',
      ],
      fresh: [
        '`OAUTH_ROUTE_PROVIDER` 镜像先例',
        '`joinProviderDirectory(registered, directory)` 同构镜像',
      ],
      notes: [
        '**双归属**：第一处 stale 锚的在仓对象 = `lib/client.js` 的 `OAUTH_ROUTE_PROVIDER` 常量（镜像**先例**，故改「常量名 + 镜像先例」式）；第二处的对象 = 宿主 `dsh-client-ui-settings-models` 的 `joinProviderDirectory`（改「符号签名 + 同构镜像」式；宿主只读实读该区间现值为该函数定义与返回）。',
      ],
    },

    // ── tests 面 5 新建（批 D 清除锚接线 + 未闭合项在仓登记）──
    {
      file: ['tests', 'fix-029-host-contract.mjs'],
      stale: [
        'dsh-api-session-controller index.js:605,2502',
        'dsh-llm lib/index.js:1698/1780/2177/2018',
        // FIX-044 ④：改指后**清除**的旧锚形态（与 `lib/client.js` 条目同形登记——同一对象的两处消费面
        //   各自看护；裸区间锚带对象名上下文）。
        'ui-conversation :16041-16056',
      ],
      fresh: [
        'selectModel(request) 面 + Remote("selectModel") 注册',
        'registerAdapter/registration/listModels 三方法齐备实证',
        // FIX-044 ④：定位所得**真实归属面**（宿主只读实读；替换原对象不成立的 `PropsHooks` claim）。
        'ctx.uiSession.provide({ hooks: ["conversation", "input"], props: ["inputActions"], ... })',
        'SessionStandardProps.useInput',
        'useInput: SnapshotSelectorHook<InputState>',
      ],
      notes: [
        '保留（MUST NOT 入 stale 侧）：`types/agent.js` 的 `:297-318`（本文件头部）为**机器锁**——`tests/host-contract.mjs` 的 S2 `extra.signatures` 对**本文件原文**做 `includes()`（不经注释剥离）⇒ 单侧去行号即判红（R4 §2.1 谓词独立复算：现文 `[true,true]` / 假设去行号 `[false,true]`）。**理由全集与收敛顺序见 `lib/prestep.js` 条目 notes**（FIX-044 ② 去冗余：本处不重复「三处同步」清单）。',
        '**已定位并改指**（FIX-044 ④ 收口；批 F 的「对象不成立」判定予以保留）：原 `:16041-16056` 区间锚（对象 = `dsh-client-ui-conversation`，claim 为 `PropsHooks` 面）——`PropsHooks` 在该宿主包内 **0 命中**、该区间实为 InputBar 的 JSX 渲染段（批 C / R4 实读判定）⇒ 本批以宿主**只读实读**定位真实面并改指（本文件头部行内注释同步）：宿主注入面 = 该包 `lib/client.js` 的 `InputHub` 装配点 `ctx.uiSession.provide({ hooks: ["conversation", "input"], ... })`；input → useInput 契约 = `SessionStandardProps.useInput`（`lib/types/client/contract/slots.d.ts` 的 `useInput: SnapshotSelectorHook<InputState>`）。按 P10-④ 只写实读可达符号（零虚构）；**旧形态已入本条目 `stale` ⇒ 再引入即判红**（批 F 的「MUST NOT 入 stale」成立于旧态——彼时对象未定位）。在仓登记两处（跨文件同步）：本 notes + 本文件头部行内判定注释。',
      ],
    },
    {
      file: ['tests', 'oauth-main-model.mjs'],
      stale: [
        'dsh-system-prompt lib/index.js:254-258',
        'dsh-llm-pi-ai lib/index.js:1123-1128',
      ],
      fresh: [
        'assemble() 工具 schema 消费面',
        'toolsOf(options) 映射面',
      ],
      notes: [
        '与 `lib/oauth-llm.js` 条目为**同对象的双消费面**（该处 = 生产代码注释，本处 = 判别夹具注释）⇒ 两侧**各自登记**（P5：同对象不因文件而异；不作镜像式去重，避免单侧漏看护）；宿主对象不在本仓库面 ⇒ 只判本仓文本内的锚串形态。',
      ],
    },
    {
      file: ['tests', 'adapter-parity.mjs'],
      stale: [
        'lib/index.js:1681-1686',
        'adapterStream :2232',
        '（新增，:1645）',
        '（回归原型，:1681）',
        'lib/index.js:1996-1998',
        '宿主 :1645 默认语义',
        '宿主注释 :1639',
        ':1645）。契约：同步零 I/O',
        ':1996-1998 直调缺方法即同型断裂',
        'LlmRuntime.imageRequestPricing :1996-1998 逐路由',
        '宿主 :1996 消费面同构',
        'lib/types/types.d.ts:171-178',
        '，:159-164）',
      ],
      fresh: [
        'LlmAdapter 的 prepareCall',
        'adapterStream 的 prepared 缺省分支',
        'LlmAdapter 默认「declares none」',
        'prepareCall（回归原型）',
        'LlmRuntime.imageRequestPricing 消费点',
        'LlmAdapter.imageRequestPricing 默认语义',
        'LlmRuntime.imageRequestPricing 消费面同构',
        'LlmImageRequestPricing 方法式',
        'LlmImageRequestPrice',
        'must answer',
      ],
      notes: [
        '裸锚登记形态（R3 六项要求 ①）：载体原列的裸「宿主 + 行号」短串**不作 needle**，一律扩写为**同句上下文**串（否则与他处同数字短串歧义）；同对象的多站点（原 3 处默认语义 + 2 处消费点 + 2 处契约枚举）合并为**可覆盖全部站点的上下文子串**，不逐站点重复登记。',
      ],
    },
    {
      file: ['tests', 'fix-010-gui-fidelity.mjs'],
      stale: [
        'lib/index.js:554）→ GUI 渲染标记文本',
      ],
      fresh: [
        'session.append("user/message", message) 持久化点',
      ],
      notes: [
        '裸锚登记形态（R3 六项要求 ① + 载体 §二 自碰撞提示）：该行号短串**不作 needle**，登记串加「同句后续」上下文（判别力 ≥ 短串且零歧义）。宿主对象的行号在批 D 已勘正（原锚为 JSDoc，持久化点实在别处）。',
      ],
    },
    {
      file: ['tests', 'run-all.mjs'],
      stale: [
        'host-contract.mjs:96-99',
      ],
      fresh: [
        '`stripComments` 同法',
      ],
      notes: [
        '**在仓对象**条目（非宿主面）：对象 = 本仓 `tests/host-contract.mjs` 的 `stripComments` 实现，可机器核验；本条目只判本仓文本内的锚串形态 + 替代式指代在位。',
      ],
    },
    // ARCH-005 A2（HD-003）：lib/rpc.js **首次入册**——本批 strictCodec 单点注释携带
    // 宿主树行号式锚（两锚对象均于本批实读核验：validateCodec 的 create() 强制 throw
    // 形态 + api-remotes 宿主自证 codec 形态）。stale 侧为空 = 本文件首含锚、无旧锚
    // 可清；fresh 侧 = 两宿主锚串在场（锚失即红——锚定的行为语义另由
    // tests/rpc-shadow-guard.mjs §5/§6 的形态判别 + 真树校验机器判据承载，非本表职责）。
    { file: ['lib', 'rpc.js'], stale: [], fresh: ['dsh-typert-registry/lib/index.js:565', '/lib/client.js:11666-11680'] },
    // ARCH-005 A3（HD-002）：lib/schemas.js + tests/settings-config-migration.mjs **首次入册**——
    //   本批 Config 导出声明制迁移在两文件引入宿主树行号式锚（锚对象均于本批实读核验：
    //   dsh-settings 的 volatile 写入门与 ns schema 来源、pi-ai volatile 先例、config-editor
    //   edit 净效应、loader _commitVolatile、cosmokit volatile 协议）。stale 空 = 两文件
    //   首含锚、无旧锚可清；fresh = 代表性宿主锚串在场（锚失即红——锚定语义的行为判别
    //   由 tests/settings-config-migration.mjs 的真树实跑判据承载，非本表职责）。
    { file: ['lib', 'schemas.js'], stale: [], fresh: ['dsh-settings :506-508', 'dsh-llm-pi-ai/lib/index.js:1051', '（dsh-settings :538-541）'] },
    { file: ['tests', 'settings-config-migration.mjs'], stale: [], fresh: ['dsh-config-editor lib/index.js:69-127 的净效应', 'cordis-plugin-loader _commitVolatile（lib/index.js:401-427）', 'lib/types/volatile.js:83', 'Config field "frozen" is not volatile'] },
    // ARCH-007 D2：新建依赖台账（lib/host-abi/dependency-ledger.js）首含行号式锚——evidence
    //   字段**刻意**指向消费者行号（台账语义 = 单点审计「用了宿主什么、缺了会怎样」），
    //   故无旧锚可清；fresh = 代表性证据锚串在场（台账若删证据/改指即红）。台账内部
    //   行号漂移不解除其义务，由刷新批次统一复核（同 §R3 宿主锚核验纪律）。
    { file: ['lib', 'host-abi', 'dependency-ledger.js'], stale: [], fresh: ['lib/service.js:1489 subagentsOf', 'lib/prestep.js:224', 'lib/preset-defaults.js:402', 'lib/tool.js:30 inject 声明'] },
  ]
  for (const anchorCase of ANCHOR_CASES) {
    const filePath = join(ROOT_DIR, ...anchorCase.file)
    const source = readFileSync(filePath, 'utf8')
    const staleHits = anchorCase.stale.filter((needle) => source.includes(needle))
    const missingFresh = anchorCase.fresh.filter((needle) => !source.includes(needle))
    // P3-1 限定语：本项判的是「**本清单所列**旧式锚零残留」，不等于被守卫文件内无任何行号锚
    //   （如 install-entry.mjs 的 `install.ps1:1` / `install.sh:2` 属宿主入口自述锚，现值准确、
    //   刻意不入本清单——列清单式判据只覆盖清单）。
    check(`B5 9h R-1: ${anchorCase.file.join('/')} 清单所列旧式锚零残留 + 替代式锚在位`, staleHits.length === 0 && missingFresh.length === 0, { staleHits, missingFresh })
    // notes（可选）：不可修 / 需产品语义裁决的项，以 note 形式登记（不参与判别，仅可见）。
    for (const note of anchorCase.notes ?? []) console.log(`  note  B5 9h R-1: ${anchorCase.file.join('/')} ${note}`)
  }
  // 9h-4（FIX-043 批 A 收口；FIX-042 R1 P3-1 的机核化）：**stale needle 自碰撞卫生**——每条 stale
  //   needle 在守卫自身内的出现 MUST 全部落在其**登记数据单元**（`stale` 字段的数组字面量）内；出现在
  //   守卫的其余文本（注释块 / 断言标签 / fresh 清单 / 其他结构）即判红。该失效形态的实例：
  //   「清洗自我引用时引入新的自我引用」——把被清扫的锚串逐字复述进登记说明（F-3 登记文本、
  //   FIX-042 W1/W2/W4 各条目注释），needle 文本因此常驻判据文件内（FIX-042 R1 P3-1）。
  //   口径（为何不判「全文件出现次数 = 0」）：needle 必须在**某处**被定义，其定义处即登记数据单元
  //   （恒 +1）；要求全文件零出现等于要求全部 needle 一律拼接常量编码——对非自条目无可判据收益且
  //   损害可读性。故本条判「**非登记逐字复述 = 0**」（= 在守卫自身内的出现次数恰等于其登记处次数）；
  //   「登记处次数」= **元素精确计数**（登记数据单元内**字面量元素值**的出现次数——FIX-043 批 E 按
  //   R0 P1-3 由「整段子串计数」改写：后者会被「单元内注释复述他人 needle」旁路，见下 A1 实证）。
  //   **自条目**（file 指向本守卫者）另由 9h-4b 要求全文件出现次数 = 0——该处定义处本身即判据面，
  //   字面量登记会使判据恒红 / 判别力归零（先例：OLD_PRESETDIAG_LINE_ANCHOR 的拼接常量法）。
  //   可达性（非恒真谓词，双方向均实跑）：本判据落地时**自然红**——10 处 needle 被登记说明文本
  //   逐字复述（逐处分段化后转绿）；9h-4b 由定向变异实证（自条目 needle 改字面量 → 判红）；
  //   元素精确计数形态由 A1 同形变异实证判红（仓库外副本：在 `stale` 数组首元素前插入含**他人
  //   needle** 的块注释 ⇒ FAIL，detail 报「登记 1 处 / 守卫内 2 处」——整段子串计数时二者相等故
  //   曾放行）。**本段注释自身亦受本条约束**：批 E 落地时首版注释因逐字写出两条 needle 与单元
  //   标记串而被本判据/9h-4c 判红（needleRepetitions × 3 + staleUnitCount 28≠26）⇒ 已改为
  //   分段/指代式表述——这正是「判据非恒真 + 守卫看护自身文本」的现场实证。
  //   9h-4c：登记数据单元解析完整性（单元数 === 条目数）——解析失配（引号/括号形态变化）会使本判据
  //   面静默失真（如 needle 被误判为「已登记」），故 fail-closed 判红而非静默降级（P8）。
  {
    const guardSource = readFileSync(join(ROOT_DIR, 'tests', 'host-abi-health.mjs'), 'utf8')
    const staleFieldMarker = 'stale' + ': ['
    const staleUnits = []
    for (let cursor = 0; (cursor = guardSource.indexOf(staleFieldMarker, cursor)) !== -1;) {
      let end = cursor + staleFieldMarker.length
      let inString = false
      for (; end < guardSource.length; end++) {
        const char = guardSource[end]
        if (char === '\\') { end += 1; continue }
        if (char === "'") inString = !inString
        else if (char === ']' && !inString) break
      }
      staleUnits.push(guardSource.slice(cursor, end + 1))
      cursor = end + 1
    }
    const countOccurrences = (text, needle) => text.split(needle).length - 1
    // **元素精确计数**（FIX-043 批 E / R0 P1-3 收口）：`registered` = needle 在**登记数据单元的
    //   字面量元素值**内的出现次数。**元素** = 数组字面量顶层（字符串/注释之外）以 `,` 分隔的片段，
    //   其「值」取纯字面量或字面量拼接（`'a' + 'b'`）的内容（`\n`/`\'` 等转义按 JS 语义解码）；
    //   注释文本、标识符、片段外文本**一律不产生元素值**。理由（R0 变异 A1 实证的旁路）：在
    //   `stale` 字段数组的**首元素前**插入含**他人 needle** 的块注释时，整段子串计数把该注释算作
    //   「已登记」（registered 虚增 ⇒ 与 inGuard 相等 ⇒ 放行）；逐元素取字面量值后该注释不计入 ⇒
    //   `inGuard > registered` 判红。**扫描器 MUST 注释/字符串感知**：needle 字面量自身含 `//`
    //   （metrics 条目的注释串）与 `,`（宿主选择面双段锚，逗号在引号内）者真实存在 ⇒ 正则剥离 /
    //   朴素 `split(',')` 都会误伤；元素值按**逐元素子串计数**（非 `===` 相等）——两条登记串互为
    //   前缀/子串（宿主适配器两段锚）时两侧计数一致，不制造假红。
    const staleElementValuesOf = (unitText) => {
      const decodedEscapes = { n: '\n', t: '\t', r: '\r', '\\': '\\', "'": "'" }
      const body = unitText.slice(unitText.indexOf('[') + 1, -1)
      const values = []
      let literal = ''
      let valid = true
      let seen = false
      let mode = 'code'
      const flush = () => {
        if (valid && seen) values.push(literal)
        literal = ''
        valid = true
        seen = false
      }
      for (let index = 0; index < body.length; index++) {
        const char = body[index]
        const next = body[index + 1]
        if (mode === 'line') { if (char === '\n') mode = 'code'; continue }
        if (mode === 'block') { if (char === '*' && next === '/') { mode = 'code'; index += 1 } ; continue }
        if (mode === 'string') {
          if (char === '\\') { literal += decodedEscapes[next] ?? next; index += 1; continue }
          if (char === "'") { mode = 'code'; continue }
          literal += char
          continue
        }
        if (char === '/' && next === '/') { mode = 'line'; index += 1; continue }
        if (char === '/' && next === '*') { mode = 'block'; index += 1; continue }
        if (char === "'") { mode = 'string'; seen = true; continue }
        if (char === ',') { flush(); continue }
        if (char === '+' || /\s/.test(char)) continue
        valid = false
      }
      flush()
      return values
    }
    const registeredLiteralText = staleUnits.flatMap((unit) => staleElementValuesOf(unit)).join('\n')
    const needleRepetitions = []
    const selfLiteralNeedles = []
    for (const anchorCase of ANCHOR_CASES) {
      const fileKey = anchorCase.file.join('/')
      const selfTarget = fileKey === 'tests/host-abi-health.mjs'
      for (const needle of anchorCase.stale) {
        const registered = countOccurrences(registeredLiteralText, needle)
        const inGuard = countOccurrences(guardSource, needle)
        if (inGuard > registered) needleRepetitions.push(`${fileKey} :: 「${needle}」登记 ${registered} 处 / 守卫内 ${inGuard} 处`)
        if (selfTarget && inGuard !== 0) selfLiteralNeedles.push(needle)
      }
    }
    check('B5 9h-4c R-1: 登记数据单元解析完整性（stale 字段数组单元数 === 条目数——解析失配即红，防判据面静默失真）',
      staleUnits.length === ANCHOR_CASES.length, { staleUnitCount: staleUnits.length, caseCount: ANCHOR_CASES.length })
    check('B5 9h-4 R-1: stale needle 在守卫自身内的出现次数 = 其登记处次数（非登记逐字复述即红——needle 自碰撞卫生）',
      needleRepetitions.length === 0,
      { needleRepetitions, needleCount: ANCHOR_CASES.reduce((sum, item) => sum + item.stale.length, 0), staleUnitCount: staleUnits.length })
    check('B5 9h-4b R-1: 自条目 stale needle 全文件出现次数 = 0（拼接常量登记——定义处即判据面，字面量登记使判据恒红/判别力归零）',
      selfLiteralNeedles.length === 0, { selfLiteralNeedles })
  }
  // 9h-5（FIX-044 ① 收口 R5 P3-2；R4 P3-5「保护窗口」同族面）：**入表完备性自检——文件级**。
  //   判据（与 9h-3 同族同型：9h-3 判「候选锚名未入表即红」，本项判「含行号式锚的**文件**未入表即红」）：
  //   行号式锚只由 `ANCHOR_CASES` 的 `stale` 侧看护 ⇒ 若**某文件存在行号式锚却无任何登记单元**，
  //   其锚可被静默重引入（批 F 前的保护窗口即此形态）。本项把「文件是否已纳入看护面」由人工核验
  //   改为机器看护：扫描面内含锚文件 MUST 出现在 `ANCHOR_CASES` 的 `file` 全集**或**显式豁免表内。
  //   **扫描面**（机器枚举，非人工清单——新增文件自动入面）：`lib/**` + `tests/**` 的非点号条目
  //   （点号条目 = 运行时产物 / 参考副本）中扩展名为 `.js`/`.mjs`/`.cjs` 者，外加 `README.md` 与
  //   `.github/workflows/*.yml`。**面外**：`docs/**`、`CHANGELOG.md`（历史快照锚刻意不清扫，见上方
  //   ⑥ 段落限定语）、`.tmp-research/**`（版本控制外的参考副本）、宿主树（本就不可解析）。
  //   **行号式锚形态** = 与上方 ⑥ 段落同源的三种正则（① 文件:行号 ② `L###` ③ 裸 `:NNN`）。
  //   **如实声明的限制（不得夸大覆盖）**：
  //     ① 本项判**文件级**入表（该文件存在登记单元）——**不**声称该文件内的每一个行号式锚都已逐条
  //        纳入看护（逐锚覆盖由各条目 stale/fresh 自身承担，即 9h R-1）；
  //     ② 形态判定依赖上述三正则 ⇒ 正则不可达的形态（跨行拆分的锚、三种写法之外的变体）不计入，属已知盲区；
  //     ③ 豁免表是**人工维护面**：把新文件同时写入豁免表即不判红 ⇒ 本项把「静默漏登」改为
  //        「必须显式登记或显式豁免」，豁免是可在 diff 中复审的显式决策；本项**不**判断豁免理由的
  //        实质充分性；
  //     ④ 面外文件不覆盖（见上）。
  //   **非恒真/可达性**（实跑证据见本批交付报告）：① 基线不误红；② 在仓库外副本新增一个含行号式锚的
  //   `tests/**` 文件（不登记、不豁免）⇒ 判红；③ 从表中移除任一条目（其文件仍含锚）⇒ 亦判红
  //   （⇒ 判据依赖实际表内容，非常量满足）。9h-5b 独立判**豁免表腐化**（所列文件已无锚 / 与已登记
  //   条目重叠 ⇒ 判红）。
  //   FIX-045 收口（R5 P3-2/P3-3 两项，均为**代码面**收口、无产品代码改动；P3-2 段落表述由 R1 F-1 勘正）：
  //     · P3-2 形态①的扩展名集与扫描面枚举集**互不相等**（**双向差集**：去 `ts|tsx|sh|ps1`、增 `cjs`；
  //       如实口径与复核依据见该块内「差集 / 当前树无判红差异 / 前瞻敏感性收缩」三段）⇒ 已按**单一常量
  //       来源**收敛（见下方 `ANCHOR_COVERAGE_EXT_ALTERNATION`），并新增 9h-5c 机器判据看护该单源绑定；
  //     · P3-3 `overlappingExempts` 单变量判红实证：仓库外副本**仅**向 `ANCHOR_CASES` 增加一条指向
  //       `tests/oauth-promotion.mjs`（既有豁免文件）的登记单元（旧式锚侧留空 + 一条实存于该文件的
  //       fresh 字符串，其它构造一字未动）⇒ 实测 **1 FAILURE(S) (190 passed)**、exit 1，且该 FAIL 的
  //       detail 为 `{"exemptCount":3,"deadExempts":[],"overlappingExempts":["tests/oauth-promotion.mjs"]}`
  //       ⇒ **`deadExempts` 分支未触发**（该合取项为真）而重叠分支单独判红 = 单变量实证；同一副本上
  //       不改任何构造的基线运行 = 190 断言全绿 / exit 0（不误红对照）。
  //   **本段与下方 9h-5c 判据新增文本同样受 9h-4/9h-4b/9h-4c 约束**（已实跑复核：三条 hygiene 判据
  //   保持全绿、断言面为「基线 189 + 9h-5c 1 = 190」；本段首版曾因逐字复述登记数据单元的起始标记
  //   被 9h-4c 判红 ⇒ 已改为指代式表述，这正是本条判据看护自身文本的现场实证）。
  {
    // 形态①的扩展名集**由扫描面枚举单点派生**（FIX-045 P3-2；本节表述由 R1 F-1 勘正）：此前该正则持有
    //   独立的扩展名交替组，与枚举集**互不相等** ⇒ 若该组认作「文件:行号」载体的扩展名不被
    //   `coverageFiles` 枚举，`anchorBearingFiles` 便无从命中其承载文件、也就无从判红（潜在漏面/潜在
    //   误判面，方向双向）。
    //   收敛方向取「单一常量来源」（P5）：正则扩展名集 = `ANCHOR_COVERAGE_EXTS` 逐项去前导点后拼接。
    //   **方向性说明（不得反向理解）**：枚举集才是**面定义**（本次枚举集**零改动**，面语义不变），正则
    //   随其派生、MUST NOT **宽于**枚举、MUST NOT **异于**枚举——正则侧此后不持有独立的扩展名知识；
    //   绑定由 9h-5c 判据按**源串文本恒等**看护（见下）。
    //   **差集如实陈述（R1 F-1 勘正：本节首版曾把该扩展名集差异定性为「改前改后无行为差别、判据强度
    //   只增不减」，两项均与事实不符——已按下文口径整体改写）**：旧组 = `(js|mjs|ts|tsx|sh|ps1)`、枚举
    //   = `js|mjs|cjs` ⇒ 二者是**双向差集**——本次**去** `ts|tsx|sh|ps1`、**增** `cjs`（旧正则**不含**
    //   `cjs`，故该方向是真实补口，而非放宽）。
    //   **当前树无判红差异**（R1 独立镜像探针复核：面 51 个文件）：旧组比新组多判 3 个文件为「锚承载」——
    //   `tests/smoke.mjs`、`tests/install-entry.mjs`、`.github/workflows/ci.yml`（承载文件数 20 → 17），
    //   而**三者均已在 `ANCHOR_CASES` 在册** ⇒ 9h-5 的 `uncoveredFiles` 不受影响（登记面与正则形态无关；
    //   承载面收缩只会使其更难判红）；三个豁免文件在两版正则下**均判承载**（判定一致）⇒ 9h-5b 的
    //   `deadExempts` 两支同样不受影响。本次**无新增承载文件**（`.cjs` 方向当前实例 = 0）。
    //   **代价（前瞻敏感性收缩，如实声明）**：面内「旧命中、新不命中」的**内容级**锚串实例确实存在——
    //   `lib/service.js` 与 `tests/smoke.mjs` 内的 `transport.ts:22`；`tests/install-entry.mjs` 内的
    //   `install.ps1:1` / `install.sh:2`；`.github/workflows/ci.yml` 内的 `install.ps1:1`；本守卫自身
    //   登记与注释文本内的 `.d.ts:NNN` 族、`install.sh` 行号区间族（多处，见上方 `ANCHOR_CASES`）
    //   ⇒ 这些**非 JS 扩展名**锚串此后**不再计为锚承载**：若未来面内出现「唯一锚即此类引用」的文本
    //   （如 README/yml 内的 `.ts`/`.ps1` 引用），9h-5 不会因该文件判红——此为换取「正则不宽于枚举」
    //   所付的**已知盲区**，本段不再作强度只升的声称。
    const ANCHOR_COVERAGE_EXTS = ['.js', '.mjs', '.cjs']
    const ANCHOR_COVERAGE_EXT_ALTERNATION = ANCHOR_COVERAGE_EXTS.map((extension) => extension.replace(/^\./, '')).join('|')
    const ANCHOR_COVERAGE_FORM_1_SOURCE = `[A-Za-z0-9_@/.-]*[A-Za-z0-9_-]\\.(${ANCHOR_COVERAGE_EXT_ALTERNATION}):\\d+(-\\d+)?`
    const ANCHOR_COVERAGE_FORMS = [
      new RegExp(ANCHOR_COVERAGE_FORM_1_SOURCE),
      /\bL\d{2,4}(?:[-–]\d{2,4})?/,
      /(?:^|[^A-Za-z0-9_]):\d{2,4}(\/\d{1,4})?([-–]\d{2,4})?/,
    ]
    // 9h-5c（FIX-045 P3-2 机器判据；R1 F-2 收紧 + F-3 勘正）：**单源绑定非静默失真**——形态①的扩展名
    //   交替组 MUST 恰等于由 `ANCHOR_COVERAGE_EXTS` 派生的交替串（顺序含：弱等于会放行「组内混入枚举外
    //   扩展名」的静默漂移），且形态①的**源串 MUST 与该派生串逐字恒等**（`===`，非 `endsWith`）。收紧前
    //   只约束尾部，留有静默通过形态：**前插**一个额外分支（如 `<扩展名组>:\d+(-\d+)?|` + 派生串）时尾部
    //   组 1 仍等于派生串 ⇒ 判绿，而形态①已重新纳入枚举外扩展名（原缺口形态复发；R1 变异实证：该形态在
    //   旧实现下 exit 0 / 190 全绿，改用 `===` 后判红）。判据面 = 运行时派生值，非等下次人工巡检。
    //   **红触发集（如实口径，R1 F-3——原「枚举增项即红 / 写回字面量即红」两处不成立）**：正则侧**单边**
    //   改动（组内扩展名增减 / 写回文本不同的字面量 / 前插或后附分支）⇒ 红；枚举侧改动经单源派生**自动
    //   同步** ⇒ **不红**（这正是单源绑定的预期语义，R1 变异实证：枚举增项 exit 0 / 190 全绿）；**源串
    //   逐字相同**的字面量回写亦不红（此后枚举变更即红 ⇒ 绑定漂移保护仍在，但非「立即判红」）。失配即
    //   判红并带 `form1ExtGroup` / `form1Source` 诊断（P5 单点化 + P8 失败可观测）。
    const anchorCoverageExtGroup = ANCHOR_COVERAGE_FORMS[0].source.match(/\(([^()]*)\):\\d\+\(-\\d\+\)\?$/)
    check('B5 9h-5c R-1: 形态①扩展名集 === 扫描面枚举派生集，且形态①源串与该派生串逐字恒等（正则侧单边改动——组内扩展名增减 / 写回不同文本 / 前插后附分支——即红；枚举侧改动经单源派生同步不红）',
      anchorCoverageExtGroup?.[1] === ANCHOR_COVERAGE_EXT_ALTERNATION
      && ANCHOR_COVERAGE_FORMS[0].source === ANCHOR_COVERAGE_FORM_1_SOURCE,
      { extAlternation: ANCHOR_COVERAGE_EXT_ALTERNATION, form1ExtGroup: anchorCoverageExtGroup?.[1] ?? null, form1Source: ANCHOR_COVERAGE_FORMS[0].source })
    // 豁免面（显式、带理由、可复核；四类各有依据）：镜像侧 + 本地快照对象 + 版本冻结文档 + 合成夹具
    //   （合成行号字面量复制自行号锚注释、用于构造候选窗口为空的突变树——非宿主/本仓真实源码锚）。
    const ANCHOR_COVERAGE_EXEMPTS = [
      { file: ['tests', 'served-client.js'], kind: 'mirror', reason: '镜像侧不重复登记（载体 §一 notes 4）：`served-client mirror stays byte-identical to lib/client.js` 的字节恒等判据是更强的保证（逐字节相等 ⇒ 内容判据自动传递）。' },
      { file: ['tests', 'oauth-credentials.mjs'], kind: 'snapshot-object', reason: '该处锚的对象 = `.router-files/` 的一手快照（版本控制外的一手来源，非本仓 tracked 面、非宿主包）⇒ 与 `.tmp-research` 同类的对象参考面限制，属「无实读对象」的登记面。' },
      { file: ['tests', 'oauth-promotion.mjs'], kind: 'frozen-doc', reason: '该处锚的对象 = `rollback-plan v0.3.0` 版本冻结文档（历史快照）⇒ 与既有 ⑥ 段落「`docs/release` 历史发布文档锚刻意不清扫」同口径。' },
      { file: ['tests', 'host-radar.mjs'], kind: 'synthetic-fixture', reason: '该处行号字面量是 S9b 反向夹具的**合成**锚——复制自 `lib/prestep.js` 注释锚的行号，仅用于构造「行号候选窗口结构性为空」的突变树（合成树远短于该行号）；非对宿主/本仓真实源码的行号锚。真实锚的看护在 `tests/host-contract.mjs` 的 `HOST_V4_ANCHORS` 锚表，以及 `tests/host-radar.mjs` 自身的 `guard S9b 反向` 断言（合成树 × 精确 FAIL 点名）。' },
    ]
    const coverageFiles = []
    const walkCoverageFace = (absoluteDir, relativeDir) => {
      for (const entry of readdirSync(absoluteDir, { withFileTypes: true })) {
        if (entry.name.startsWith('.')) continue
        const relativePath = `${relativeDir}/${entry.name}`
        if (entry.isDirectory()) walkCoverageFace(join(absoluteDir, entry.name), relativePath)
        else if (ANCHOR_COVERAGE_EXTS.some((extension) => entry.name.endsWith(extension))) coverageFiles.push(relativePath)
      }
    }
    walkCoverageFace(join(ROOT_DIR, 'lib'), 'lib')
    walkCoverageFace(join(ROOT_DIR, 'tests'), 'tests')
    coverageFiles.push('README.md')
    for (const entry of readdirSync(join(ROOT_DIR, '.github', 'workflows'), { withFileTypes: true })) {
      if (entry.isFile() && entry.name.endsWith('.yml')) coverageFiles.push(`.github/workflows/${entry.name}`)
    }
    const anchorBearingFiles = coverageFiles.filter((relativePath) => {
      const source = readFileSync(join(ROOT_DIR, ...relativePath.split('/')), 'utf8')
      return ANCHOR_COVERAGE_FORMS.some((form) => form.test(source))
    })
    const registeredFiles = new Set(ANCHOR_CASES.map((anchorCase) => anchorCase.file.join('/')))
    const exemptFiles = new Set(ANCHOR_COVERAGE_EXEMPTS.map((entry) => entry.file.join('/')))
    const uncoveredFiles = anchorBearingFiles.filter((relativePath) => !registeredFiles.has(relativePath) && !exemptFiles.has(relativePath))
    const deadExempts = [...exemptFiles].filter((relativePath) => !anchorBearingFiles.includes(relativePath))
    const overlappingExempts = [...exemptFiles].filter((relativePath) => registeredFiles.has(relativePath))
    check('B5 9h-5 R-1: 扫描面内含行号式锚的文件全部已入 ANCHOR_CASES（或显式豁免）——新增含锚文件未入表即红',
      uncoveredFiles.length === 0, { scanFaceSize: coverageFiles.length, anchorFileCount: anchorBearingFiles.length, uncoveredFiles })
    check('B5 9h-5b R-1: 豁免表完整性（所列文件仍含锚 × 不与已登记条目重叠——豁免表腐化即红）',
      deadExempts.length === 0 && overlappingExempts.length === 0, { exemptCount: exemptFiles.size, deadExempts, overlappingExempts })
  }
  // 9h-2（FIX-040 W4；R0 P1-1 收口）：跨文件对象核验——metrics.mjs 的断言名式锚
  //   （`smoke.mjs「<label>」`）所引用的断言名 MUST 在 smoke.mjs（或测试面）中确实存在。
  //   判据取**显式对照表**（锚侧原文 → 对象侧原文）：锚串在 metrics.mjs 中在位（失去锚即红）
  //   × 对象在位（标签改名/断言被删即红）——两侧都判，避免「锚指向不存在对象」的静默失效。
  //   **本项覆盖面 = 下表所列锚**（≠ 全文件全部候选锚名）；表外候选名的**入表完备性**由
  //   9h-3 强制入表（新增候选名未入表即红）。**对象存活面的如实界定**（R1 P3-2(new)）：
  //   9h-2 的 21 对各自按**声明的单源**核验其对象；9h-3 只保证"候选名已入表"，**不等于**
  //   对象的存活已被覆盖（两者判据不同、不可互相替代），故不声称"全部候选锚名均有对象核验"。
  //   表结构（R1 P1-1(new) 收口）：`[锚串, 对象串（带判别前缀）, 声明源]` 三元组，对象**只在
  //   其声明源**内查找（禁止多源析取），并由 9h-2b 机器判据保证零自满足（见下）。
  {
    const metricsSource = readFileSync(join(ROOT_DIR, 'tests', 'metrics.mjs'), 'utf8')
    const smokeSource = readFileSync(join(ROOT_DIR, 'tests', 'smoke.mjs'), 'utf8')
    const paritySource = readFileSync(join(ROOT_DIR, 'tests', 'adapter-parity.mjs'), 'utf8')
    const wrapperSource = readFileSync(join(ROOT_DIR, 'lib', 'wrapper.js'), 'utf8')
    const ANCHOR_OBJECTS_3 = [
      ['smoke.mjs「image turn config passes through unchanged (no whole-turn routing)」', "check('image turn config passes through unchanged (no whole-turn routing)'", 'smoke'],
      ['smoke.mjs「wrapper takes over default model」', "check('wrapper takes over default model'", 'smoke'],
      ['wrapper twin mirrors catalog', "check('wrapper twin mirrors catalog'", 'smoke'],
      ['smoke.mjs「vision call returns text without echoing injected images (B)」', "check('vision call returns text without echoing injected images (B)'", 'smoke'],
      ['smoke.mjs「native multimodal delegate sees raw image (preserveImageInput)」', "check('native multimodal delegate sees raw image (preserveImageInput)'", 'smoke'],
      ['smoke.mjs §7.7 pre-step「image turn on wrapper route injects plugin reminder」', "check('image turn on wrapper route injects plugin reminder'", 'smoke'],
      ['reminder carries attachment id + route_agent instruction', "check('reminder carries attachment id + route_agent instruction'", 'smoke'],
      ['escape-group turn also injects reminder', "check('escape-group turn also injects reminder'", 'smoke'],
      ['smoke.mjs「collectMarkers dedupes by attachment」', "check('collectMarkers dedupes by attachment'", 'smoke'],
      ['marker offers recognition and generation routes', "check('marker offers recognition and generation routes'", 'smoke'],
      ['smoke.mjs「tool parameters schema」', "check('tool parameters schema'", 'smoke'],
      ['attachmentIds resolution (M2)', "console.log('attachmentIds resolution (M2):'", 'smoke'],
      ['smoke.mjs「follow-up text turn injects memory segment into system」', "check('follow-up text turn injects memory segment into system'", 'smoke'],
      ['memory segment carries id and untrust annotation', "check('memory segment carries id and untrust annotation'", 'smoke'],
      ['memory segments capped at recent 5', "check('memory segments capped at recent 5'", 'smoke'],
      ['current-turn image not double-injected as memory', "check('current-turn image not double-injected as memory'", 'smoke'],
      ['smoke.mjs「wrapper delegate sees route_agent', "check('wrapper delegate sees route_agent marker in system'", 'smoke'],
      ['log keeps original image block (F3)', "check('log keeps original image block (F3)'", 'smoke'],
      // R0 P1-1：`tests/metrics.mjs` 该条目的旧锚名（不存在的断言名）已改写为指向本条实存对象——实现面按
      //   声明单源（wrapper）核验；对偶断言按声明单源（parity）核验。
      ['twin 实现保 id 仅改写 provider', 'return { ...resolved, provider: wrapRoute, inputModalities: modalities }', 'wrapper'],
      ['prepared model carries wrapRoute rewrite', "check('prepared model carries wrapRoute rewrite'", 'parity'],
      ['twin resolveModel 镜像模型身份（模型 id 不变）', "checks.push(['twin resolveModel 镜像模型身份（模型 id 不变）'", 'metrics'],
    ]
    const missingAnchors = ANCHOR_OBJECTS_3.filter(([anchor]) => !metricsSource.includes(anchor)).map(([anchor]) => anchor)
    // 对象核验 = **逐行声明的单源**（禁止四源析取）：每个对象串都带**判别前缀**（`check('` /
    // `console.log('` / `checks.push(['`），且只在那一个声明源里找——否则会出现两类自满足
    // 退化（R1 P1-1(new) 实测）：① `anchor === object`（同一谓词判两次 ⇒ X && X 恒真）
    // ② 对象串被**被守卫文件自身**的注释/锚文本碰撞 ⇒ 目标源漂移也不判红。判别前缀使
    // 对象只可能命中"真正的断言发射点"，杜绝与锚文本/注释碰撞。
    const ANCHOR_SOURCES = {
      smoke: smokeSource,
      parity: paritySource,
      wrapper: wrapperSource,
      metrics: metricsSource,
    }
    // 声明源名合法性（FIX-040 R2 P3-1(new) 收口）：表第三元是**字符串源名**，此前
    //   直接 `ANCHOR_SOURCES[origin].includes(...)`——源名误写（如尾随空格的 `'smoke '`）
    //   时取值为 undefined ⇒ 调用 `.includes` 抛 TypeError：套件以栈回溯崩溃退出，而
    //   非「源名非法」的明确报文（非静默，但诊断指向错误）。本项把该形态改为**显式
    //   check FAIL**（带非法源名清单 + 合法源名全集），并把下方核验一律改为安全取值
    //   （`?.includes(...) ?? false`）——非法源名只判红、不裸抛。
    const anchorSourceNames = Object.keys(ANCHOR_SOURCES)
    const unknownAnchorSources = [...new Set(ANCHOR_OBJECTS_3.map(([, , origin]) => origin))]
      .filter((origin) => !anchorSourceNames.includes(origin))
    check('B5 9h-2c R-1: 锚对象表的声明源名全部在 ANCHOR_SOURCES 内（未知源名判红，不得裸抛 TypeError）',
      unknownAnchorSources.length === 0, { unknownAnchorSources, knownSources: anchorSourceNames })
    const deadAnchors = ANCHOR_OBJECTS_3.filter(([, assertion, origin]) => !(ANCHOR_SOURCES[origin]?.includes(assertion) ?? false))
      .map(([, assertion, origin]) => `${origin}: ${assertion}`)
    // 自满足面核验（R1 P1-1(new) 的机器判据，三类恒 0）：
    //   ① anchor === object（同一谓词判两次）② object ⊂ anchor（对象被锚文本包含）
    //   ③ 对象串在**非声明源**里出现（碰撞/自引渠道）。
    //   同源重复渠道（第四类）由下方 **9h-2d** 独立判据判别（见该处说明）。
    const selfSatisfied = {
      identical: ANCHOR_OBJECTS_3.filter(([anchor, assertion]) => anchor === assertion).map(([anchor]) => anchor),
      objectInsideAnchor: ANCHOR_OBJECTS_3.filter(([anchor, assertion]) => anchor !== assertion && anchor.includes(assertion)).map(([anchor, assertion]) => `${anchor} ⊃ ${assertion}`),
      foreignSourceHits: ANCHOR_OBJECTS_3.filter(([, assertion, origin]) => Object.entries(ANCHOR_SOURCES)
        .some(([otherSource, text]) => otherSource !== origin && text.includes(assertion)))
        .map(([, assertion, origin]) => `${origin}: ${assertion}`),
    }
    // 标签取**限定语**形态：本项判别范围 = 本表所列锚（R0 P1-1-C：不得读作「全文件死锚即红」；
    // 表外候选名的入表完备性由 9h-3 强制）。
    check('B5 9h-2 R-1: metrics.mjs 本表所列断言名式锚全部有对象（锚在位 × 对象在其声明单源在位）',
      missingAnchors.length === 0 && deadAnchors.length === 0, { anchorCount: ANCHOR_OBJECTS_3.length, missingAnchors, deadAnchors })
    check('B5 9h-2b R-1: 对象核验零自满足（anchor≠object × 对象不被锚文本包含 × 对象仅在其声明源出现）',
      selfSatisfied.identical.length === 0 && selfSatisfied.objectInsideAnchor.length === 0 && selfSatisfied.foreignSourceHits.length === 0,
      { ...selfSatisfied, tableSize: ANCHOR_OBJECTS_3.length })
    // 9h-2d（FIX-040 R2 P3-2(new) 收口）：**同源重复**判据——对象串在其**声明源**内
    //   MUST **恰出现 1 次**。9h-2b 的三类只覆盖「非声明源 / 锚文本」碰撞：若在声明源
    //   **自身**的注释里复制一份对象串、同时删掉真断言，字符串包含式判别仍判绿（残留
    //   盲区；FIX-040 R1 的实际缺陷即该类碰撞的跨源变体，已由 9h-2b ③ 堵住）——要求「恰 1 次」
    //   把该残留形式化关闭：同源多一份同串 ⇒ 对象存活证据不再唯一 ⇒ 判红。
    //   现状基线：**21/21 对象在其声明源内均恰 1 次**（零暴露、零误红；独立复算见 FIX-041
    //   取证件 .test-home/fix041-occurrence-count.mjs）。
    //   落地形态说明：FIX-040 R2 将该类表述为「9h-2b 第四类」；此处落地为**独立判据 9h-2d**
    //   （不折叠进 9h-2b 聚合谓词）——①判据彼此独立，独立 check 的失败定位更细；②断言
    //   计数如实体现新增判据；③不重复判别（9h-2b 仍判原三类，无并存双路径）。
    //   **告警面与 9h-2 的重叠**（FIX-041 R0 F-4 披露）：谓词 `count !== 1` **含 `count === 0`**
    //   ——即「对象被删/改名」时本项与 9h-2 的 `deadAnchors` **同时判红**（同一根因两条 FAIL）。
    //   这是**有意的冗余双报**（方向偏严、不引入假阴性），**不是**并存双实现：对象存活核验
    //   仍只有 9h-2 一条实现路径；9h-2 判据本体（含「非声明源命中」语义边界）**不得**因本项
    //   而简化或删除。本项 detail 因此语义为「同源计数总览」（`×0` 与 `×N≥2` 均入表）。
    const duplicateInSource = ANCHOR_OBJECTS_3
      .map(([, assertion, origin]) => ({ origin, assertion, count: (ANCHOR_SOURCES[origin] ?? '').split(assertion).length - 1 }))
      .filter((entry) => entry.count !== 1)
      .map((entry) => `${entry.origin}: ×${entry.count} ${entry.assertion}`)
    check('B5 9h-2d R-1: 对象串在其声明源内恰出现 1 次（同源重复/副本即红——9h-2b 跨源判据的盲区）',
      duplicateInSource.length === 0, { duplicateInSource, tableSize: ANCHOR_OBJECTS_3.length })
    // 9h-3（FIX-040 R0 P1-1-B / P2-1 收口）：**入表完备性自检**——metrics.mjs 内出现的
    //   每个「…」候选锚名（逐行抽取，兼容跨行注释被折行/截断的形态）MUST 登记在
    //   ANCHOR_OBJECTS_3 首列 ⇒ **新增锚未入表即红**——把「完备性」由人工改为机器看护
    //   （本批 P1-1 的失效链 = 新写死锚 + 表未收 + 声称「死锚即红」）。
    //   判据强度（R1 P2-1(new) 收口）：用**双向精确判据**而非子串包含式 `key.includes(label)`
    //   ——后者会让「新标签恰为既有键子串」的笔误形态（漏字/截断）静默通过。允许的两种
    //   合法形态：① label 精确等于某表键；② 某表键以 `「label」` 结尾（表键为「前缀 +
    //   「label」」的更长锚串，如 `smoke.mjs「wrapper takes over default model」`）。
    //   注（P2-1(new) 代码卫生）：早期用于兼容 `+「…」` 片段键的显式分支已随 P3-6（片段键
    //   改整串键）删除——该形态现由上述判据②覆盖（表键以 `「label」` 结尾），无遗留分支。
    //   已知漏判面（P3-1(new) 如实披露）：`<12 字符` 的短名不参与本项（避免把普通中文
    //   引号文本误纳）⇒ **短名死锚不会被本项捕获**（当前 metrics.mjs 无 <12 字符的「…」段，
    //   最短 22 字符；该阈值是显式保留的已知盲区，非声称无漏判；如需收紧可改为形态判据
    //   或对短名加显式白名单）。
    {
      const metricsLines = metricsSource.split('\n')
      const tableKeys = ANCHOR_OBJECTS_3.map(([anchor]) => anchor)
      const isKnown = (label) => tableKeys.some((key) => key === label || key.endsWith(`「${label}」`))
      const unregistered = []
      for (let index = 0; index < metricsLines.length; index++) {
        for (const match of metricsLines[index].matchAll(/「([^」]+)」/g)) {
          const label = match[1]
          if (label.length < 12) continue
          if (isKnown(label)) continue
          unregistered.push(`metrics.mjs:${index + 1} 「${label}」`)
        }
      }
      check('B5 9h-3 R-1: metrics.mjs 候选锚名全部已入对象核验表（精确匹配；新增锚未入表即红）',
        unregistered.length === 0, { tableKeys: tableKeys.length, unregistered })
    }
  }
  // 9i. FIX-035（EVO-023 R0 P2-1 收口）：attach 抛错条目**绝不入表**——否则
  //   后续订阅复用死条目（不再 attach）却记正向 event-subscribed = 静默死
  //   订阅 + 观测误导（违反 P8 / §4.3 域 4 降级行为）。三重断言：①失败零
  //   缓存（二次订阅重试 attach）②诊断落环形（code=attach-threw）③失败
  //   消费者 dispose 降级 no-op（不悬挂）；镜像同型 parity（9i-2）。
  {
    const attemptEvents = []
    const flakyListeners = new Map()
    let failNext = true
    const flakyCtx = {
      on: (event, handler) => {
        attemptEvents.push(event)
        if (failNext) { failNext = false; throw new Error('ctx disposed: cannot attach') }
        const list = flakyListeners.get(event) ?? []
        list.push(handler)
        flakyListeners.set(event, list)
        return () => { flakyListeners.set(event, (flakyListeners.get(event) ?? []).filter((item) => item !== handler)) }
      },
    }
    let degradedCalls = 0
    const disposeFailed = subscribeEvents(flakyCtx, [{ event: 'settings/document-updated', consumer: 'degraded-consumer', handler: () => { degradedCalls += 1 } }])
    check('FIX-035 9i: attach 抛错 → 条目不入表（零宿主 listener，无假订阅）',
      attemptEvents.length === 1 && (flakyListeners.get('settings/document-updated') ?? []).length === 0)
    check('FIX-035 9i: attach 抛错记 event-subscribe-failed（P8：面名 + code=attach-threw + consumer 标签 + 错误摘要截断）',
      hostDiagnostics().entries.some((entry) => entry.kind === 'event-subscribe-failed' && entry.face === 'settings/document-updated'
        && entry.code === 'attach-threw' && entry.consumer === 'degraded-consumer' && String(entry.detail).includes('ctx disposed')))
    check('FIX-035 9i: 失败消费者不得记正向 event-subscribed（观测误导消除——诊断不再是「已订阅」的相反信号）',
      !hostDiagnostics().entries.some((entry) => entry.kind === 'event-subscribed' && entry.face === 'settings/document-updated' && entry.consumer === 'degraded-consumer'))
    // ① 失败条目未缓存 → 同目标同事件二次订阅**重新 attach** 并成功（自愈；
    //   静默死订阅消除——P2-1 的核心判别锚，失败消费者仍在订阅态下测）。
    let retryCalls = 0
    const disposeRetry = subscribeEvents(flakyCtx, [{ event: 'settings/document-updated', consumer: 'retry-consumer', handler: () => { retryCalls += 1 } }])
    check('FIX-035 9i: 失败条目未缓存 → 二次订阅重试 attach（零复用死条目）',
      attemptEvents.length === 2 && (flakyListeners.get('settings/document-updated') ?? []).length === 1,
      { attempts: attemptEvents, listeners: (flakyListeners.get('settings/document-updated') ?? []).length })
    for (const handler of flakyListeners.get('settings/document-updated') ?? []) handler()
    check('FIX-035 9i: 重试成功后消费者真正收到事件（零 host listener 的静默收不到已消除）',
      retryCalls === 1 && degradedCalls === 0)
    // ③ 入表后跨调用聚合语义不破（第三次订阅零 attach；卸载按 consumer 摘除）。
    const disposeThird = subscribeEvents(flakyCtx, [{ event: 'settings/document-updated', consumer: 'third-consumer', handler: () => { retryCalls += 1 } }])
    check('FIX-035 9i 非回归: attach 成功后入表 → 跨调用共享单 listener（零第三次 attach）',
      attemptEvents.length === 2 && (flakyListeners.get('settings/document-updated') ?? []).length === 1)
    for (const handler of flakyListeners.get('settings/document-updated') ?? []) handler()
    check('FIX-035 9i 非回归: 共享 listener 分发给重试消费者 + 后到消费者（聚合不破）', retryCalls === 3)
    // ② 失败消费者 dispose 为 no-op（幂等、不抛、不悬挂、零跨消费者误摘）。
    check('FIX-035 9i: 失败路径 dispose 降级 no-op（幂等、不抛——活消费者不受影响）', (() => {
      try { disposeFailed(); disposeFailed(); return retryCalls === 3 } catch { return false }
    })())
    for (const handler of flakyListeners.get('settings/document-updated') ?? []) handler()
    check('FIX-035 9i: 失败消费者 dispose 后活消费者照常派发（无悬挂、无误摘）', retryCalls === 5)
    disposeRetry()
    disposeThird()
    check('FIX-035 9i 非回归: 全量卸载后 listener 归零（无残留泄漏）', (flakyListeners.get('settings/document-updated') ?? []).length === 0)

    // 9i-2. 镜像 parity（lib/client.js subscribeClientEvents 同型分支；§9e 先例）。
    const mirrorAttempts = []
    const mirrorFlaky = new Map()
    let mirrorFailNext = true
    const flakyOn = (event, handler) => {
      mirrorAttempts.push(event)
      if (mirrorFailNext) { mirrorFailNext = false; throw new Error('remote $on disposed: cannot attach') }
      const list = mirrorFlaky.get(event) ?? []
      list.push(handler)
      mirrorFlaky.set(event, list)
      return () => { mirrorFlaky.set(event, (mirrorFlaky.get(event) ?? []).filter((item) => item !== handler)) }
    }
    const mirrorDiagOf = () => bundleExportsB5.createClientRemotes({ get: () => undefined, remote: {} }).health().diag
    let mirrorRetryCalls = 0
    const disposeMirrorFailed = bundleExportsB5.subscribeClientEvents(flakyOn, [{ event: 'agent-preset/selected', consumer: 'degraded-mirror-consumer', handler: () => { mirrorRetryCalls += 1 } }])
    check('FIX-035 9i-2 镜像 parity: attach 抛错条目不入表 + 本地诊断 event-subscribe-failed（code=attach-threw，与权威侧同语义）',
      mirrorAttempts.length === 1 && (mirrorFlaky.get('agent-preset/selected') ?? []).length === 0
      && mirrorDiagOf().some((entry) => entry.kind === 'event-subscribe-failed' && entry.face === 'agent-preset/selected' && entry.code === 'attach-threw' && entry.consumer === 'degraded-mirror-consumer'))
    const disposeMirrorRetry = bundleExportsB5.subscribeClientEvents(flakyOn, [{ event: 'agent-preset/selected', consumer: 'mirror-retry-consumer', handler: () => { mirrorRetryCalls += 1 } }])
    check('FIX-035 9i-2 镜像 parity: 二次订阅重试 attach（失败条目零复用——镜像与权威侧同判别）',
      mirrorAttempts.length === 2 && (mirrorFlaky.get('agent-preset/selected') ?? []).length === 1,
      { attempts: mirrorAttempts, listeners: (mirrorFlaky.get('agent-preset/selected') ?? []).length })
    for (const handler of mirrorFlaky.get('agent-preset/selected') ?? []) handler()
    check('FIX-035 9i-2 镜像 parity: 重试成功后消费者收到事件（镜像零静默死订阅）', mirrorRetryCalls === 1)
    check('FIX-035 9i-2 镜像 parity: 失败路径 dispose 降级 no-op（幂等、不抛、活消费者不受影响）', (() => {
      try { disposeMirrorFailed(); disposeMirrorFailed(); return mirrorRetryCalls === 1 } catch { return false }
    })())
    for (const handler of mirrorFlaky.get('agent-preset/selected') ?? []) handler()
    check('FIX-035 9i-2 镜像 parity: 失败消费者 dispose 后活消费者照常派发', mirrorRetryCalls === 2)
    disposeMirrorRetry()
    check('FIX-035 9i-2 镜像 parity: 全量卸载后 listener 归零', (mirrorFlaky.get('agent-preset/selected') ?? []).length === 0)
  }

  void eventsSourceB5
}

// ── 11. ARCH-005 R2：运行面协商三态（hostCapabilityProfile + 基线档案 + 徽章渲染）──
console.log('R2 capability negotiation tri-state (matched / compatible-unknown / incompatible):')
{
  const versionModuleR2 = await import('../lib/host-abi/version.js')
  const { hostCapabilityProfile, HOST_BASELINE_REGISTRY, HOST_CAPABILITY_STATES } = versionModuleR2

  // R2-a. 基线档案单源（P5 硬门槛）：与 tests/host-version-snapshot.mjs 的
  //   HOST_BASELINE_REGISTRY 值级机器锁定。**import 评估结论（显式登记）**：产品
  //   代码不可 import 该测试文件——它是顶层执行套件（import 即全量跑测；断言失败
  //   时 process.exit(1) 会击穿宿主进程），且依赖方向禁止 lib → tests ⇒ 采用
  //   「权威源（测试侧宿主树实读登记处）+ 运行面投影（version.js 常量）」的同形
  //   双表，由本断言解析锁定：任一侧漂移（宿主升级漏刷 / 单侧手滑改值）即红——
  //   F-J「双份常量机器锁定」纪律同构（host-contract 的 HOST_VERSION_BASELINE
  //   副本同款先例）。R3 批并行中重构该文件时本判据随之显红（fail-visible，
  //   非静默分叉）。
  const snapshotSourceR2 = readFileSync(join(ROOT_DIR, 'tests', 'host-version-snapshot.mjs'), 'utf8')
  const declPosR2 = snapshotSourceR2.indexOf('HOST_BASELINE_REGISTRY =')
  const arrayStartR2 = declPosR2 === -1 ? -1 : snapshotSourceR2.indexOf('[', declPosR2)
  const arrayEndR2 = arrayStartR2 === -1 ? -1 : snapshotSourceR2.indexOf('])', arrayStartR2)
  const canonicalOf = (entry) => JSON.stringify(Object.keys(entry).sort().map((key) => [key, entry[key]]))
  const parsedRegistryR2 = []
  if (arrayStartR2 !== -1 && arrayEndR2 !== -1) {
    for (const match of snapshotSourceR2.slice(arrayStartR2, arrayEndR2).matchAll(/\{([^}]*)\}/g)) {
      const entry = {}
      for (const pair of match[1].matchAll(/([A-Za-z0-9_]+)\s*:\s*'([^']*)'/g)) entry[pair[1]] = pair[2]
      parsedRegistryR2.push(entry)
    }
  }
  check('R2-a: 基线档案表与 HOST_BASELINE_REGISTRY（snapshot 权威源）值级相等（P5 单源——任一侧漂移即红；解析失败亦红非静默）',
    Array.isArray(HOST_BASELINE_REGISTRY) && parsedRegistryR2.length > 0
    && parsedRegistryR2.every((entry) => ['id', 'status', 'dsh', 'dshPackages', 'cordis', 'schemastery'].every((key) => typeof entry[key] === 'string' && entry[key]))
    && JSON.stringify(parsedRegistryR2.map(canonicalOf)) === JSON.stringify(HOST_BASELINE_REGISTRY.map(canonicalOf)),
    { parsed: parsedRegistryR2, lib: HOST_BASELINE_REGISTRY })
  check('R2-a: 协商态词汇表 = 恰三态（matched/compatible-unknown/incompatible）',
    JSON.stringify(HOST_CAPABILITY_STATES) === JSON.stringify(['matched', 'compatible-unknown', 'incompatible']), HOST_CAPABILITY_STATES)

  // R2-b. matched：版本组合 ∈ 档案（primary 与 frozen 两档案边界）且面全绿。
  const okFacesR2 = [{ name: 'ctx:llm', state: 'ok' }, { name: 'llm:adapter', state: 'ok' }]
  const primaryR2 = HOST_BASELINE_REGISTRY.find((entry) => entry.status === 'primary')
  const frozenR2 = HOST_BASELINE_REGISTRY.find((entry) => entry.status === 'frozen')
  const versionsOfR2 = (value) => ({ llm: value, tools: value, typertProtocol: value })
  const matchedPrimaryR2 = hostCapabilityProfile({ versions: versionsOfR2(primaryR2.dshPackages), faces: okFacesR2 })
  check('R2-b: 版本 ∈ 主基线档案 + 面全绿 → matched（baselineId = primary id）',
    matchedPrimaryR2.state === 'matched' && matchedPrimaryR2.baselineId === primaryR2.id)
  check('R2-b 边界: 版本 ∈ frozen 历史档案项 + 面全绿 → matched（档案边界含 frozen——∈ 档案即实测过）',
    hostCapabilityProfile({ versions: versionsOfR2(frozenR2.dshPackages), faces: okFacesR2 }).state === 'matched')
  check('R2-b 边界: 单键漂移的混合组合不算 ∈ 档案（→ compatible-unknown，不误判 matched）',
    hostCapabilityProfile({ versions: { llm: frozenR2.dsh, tools: primaryR2.dshPackages, typertProtocol: primaryR2.dshPackages }, faces: okFacesR2 }).state === 'compatible-unknown')

  // R2-c. compatible-unknown（gate-pass-unknown regime 可达态）：∉ 档案但面全绿 →
  //   黄态 + 一次性诊断事件（同版本组合只记一次——§7.1 去重语义）。
  const diagCountR2 = (needle) => hostDiagnostics().entries.filter((entry) => entry.kind === 'host-version-unknown' && String(entry.detail).includes(needle)).length
  const unknownFirstR2 = hostCapabilityProfile({ versions: versionsOfR2('0.2.1-alpha.5'), faces: okFacesR2 })
  check('R2-c: 版本 ∉ 档案 + 面全绿 → compatible-unknown + baselineId 空（gate-pass-unknown regime）',
    unknownFirstR2.state === 'compatible-unknown' && unknownFirstR2.baselineId === '')
  check('R2-c: unknown 一次性诊断事件（kind=host-version-unknown，版本组合入 detail——P8 可观测）',
    diagCountR2('llm=0.2.1-alpha.5') === 1)
  hostCapabilityProfile({ versions: versionsOfR2('0.2.1-alpha.5'), faces: okFacesR2 })
  hostCapabilityProfile({ versions: versionsOfR2('0.2.1-alpha.5'), faces: [{ name: 'ctx:llm', state: 'ok' }] })
  check('R2-c: 同版本组合只记一次（重复调用零追加——去重与既有诊断环形纪律一致）',
    diagCountR2('llm=0.2.1-alpha.5') === 1)
  hostCapabilityProfile({ versions: versionsOfR2('9.9.9-z'), faces: okFacesR2 })
  check('R2-c: 不同未知组合各记一次（换组合 → 新事件）', diagCountR2('llm=9.9.9-z') === 1)

  // R2-d. incompatible：任一关键面 degraded/missing → incompatible（判定序先于版本）。
  const degradedFacesR2 = [
    { name: 'ctx:llm', state: 'ok' },
    { name: 'ctx:settings', state: 'degraded', detail: 'host-face-shape: mutate' },
    { name: 'session:select', state: 'missing', detail: 'host-face-missing' },
  ]
  check('R2-d: 版本 ∈ 档案但任一面 degraded/missing → incompatible（面先于版本——不把故障伪装成「只是没测过」）',
    hostCapabilityProfile({ versions: versionsOfR2(primaryR2.dshPackages), faces: degradedFacesR2 }).state === 'incompatible')
  check('R2-d: 版本 ∉ 档案且面 degraded → incompatible 且不记 unknown 事件（unknown 判据收紧）',
    (() => {
      const outcome = hostCapabilityProfile({ versions: versionsOfR2('8.8.8-y'), faces: degradedFacesR2 })
      return outcome.state === 'incompatible' && diagCountR2('llm=8.8.8-y') === 0
    })())

  // R2-e. 缺版本边界：版本读取降级（'unknown'）∉ 档案 → 诚实黄态；空面快照（注册期
  //   诚实空态）+ 版本 ∈ 档案 → matched（B1 空注册表语义不破）。
  check('R2-e: 版本读取降级（unknown 键）+ 面全绿 → compatible-unknown（缺版本面边界，不误绿）',
    hostCapabilityProfile({ versions: { llm: 'unknown', tools: 'unknown', typertProtocol: 'unknown' }, faces: okFacesR2 }).state === 'compatible-unknown')
  check('R2-e: 空面快照 + 版本 ∈ 档案 → matched（faces [] 空态视为无已知降级面）',
    hostCapabilityProfile({ versions: versionsOfR2(primaryR2.dshPackages), faces: [] }).state === 'matched')

  // R2-f. 默认实读路径：hostVersionsOf / faceHealthSnapshot 单点复用 + 纯缓存读
  //   （零 probe 调用——§7.1 三时机纪律不破）。
  {
    let probeCallsR2 = 0
    registerFaceProbes([{ name: 'r2:count', probe: () => { probeCallsR2 += 1; return { state: 'ok' } } }])
    runFaceProbes({ get: () => undefined })
    const baselineRunsR2 = probeCallsR2
    const liveR2 = hostCapabilityProfile()
    check('R2-f: 默认路径复用 hostVersionsOf/faceHealthSnapshot（读数与单点逐字相等）+ 纯缓存读零 probe',
      JSON.stringify(liveR2.versions) === JSON.stringify(hostVersionsOf())
      && JSON.stringify(liveR2.faces) === JSON.stringify(faceHealthSnapshot())
      && probeCallsR2 === baselineRunsR2)
  }

  // R2-g. RPC 四合一全链：RouterService.hostFaceDiagnostics() 附 capabilityProfile
  //   字段（strict wire codec 通过；真实仓内版本 ∈ 基线档案 → matched。ARCH-006 起
  //   本仓树 = 0.2.0-rc.2〔0.2.0 frozen 档案项——package.json 声明面 ^0.2.0-rc.2 ×11
  //   零改动收编，未随 0.2.1 主基线重装〕；协商判据 =「版本组合 ∈ 档案（含 frozen
  //   历史实测项）」而非「= primary」——baselineId 报命中档案项 id）。
  {
    const fullFacesR2 = {
      llm: { registerAdapter: () => {}, registration: () => ({}), listModels: async () => [] },
      credentials: { resolve: async () => undefined },
      settings: { get: () => undefined, mutate: async () => {} },
      fs: {},
      attachments: {},
      subagents: {},
      agentDefaultModel: { currentSelection: () => null, saveSelection: () => {} },
      sessionController: { selectModel: async () => ({}) },
      sessionProjections: { stateOf: () => null },
      agents: { get: () => ({}) },
      agentPresets: { composedPreset: () => 'p' },
    }
    const rootR2 = new Context()
    for (const [name, value] of Object.entries(fullFacesR2)) rootR2.provide(name, value)
    const serviceR2 = new RouterService(rootR2)
    serviceR2.attach({ get: () => ({ enabled: true, agents: {} }) })
    const payloadR2 = serviceR2.hostFaceDiagnostics()
    check('R2-g: RPC 结果附 capabilityProfile{state,baselineId}（三态词汇内）且整体过 strict wire codec',
      !!payloadR2.capabilityProfile && typeof payloadR2.capabilityProfile.state === 'string'
      && HOST_CAPABILITY_STATES.includes(payloadR2.capabilityProfile.state)
      && typeof payloadR2.capabilityProfile.baselineId === 'string'
      && !!wireCodecs.hostFaceDiagnosticsResult.parse(payloadR2))
    // 返工 F-3 判据锁定：capabilityProfile 为 codec **必填**字段——缺字段 parse
    // 必须红（服务端供数恒在场；旧服务端容忍由渲染层 null-guard 承载，不经 codec
    // optional 位——防后来者仿 mainModelImage 例回退 optional）。
    check('R2-g F-3: capabilityProfile 为 codec 必填字段（缺字段 parse 判红）', (() => {
      try {
        wireCodecs.hostFaceDiagnosticsResult.parse({ hostVersions: { llm: '0.2.0-rc.2', tools: '0.2.0-rc.2', typertProtocol: '0.2.0-rc.2' }, faces: [], diag: [] })
        return false
      } catch { return true }
    })())
    const liveEntryR2 = HOST_BASELINE_REGISTRY.find((entry) => entry.dshPackages === payloadR2.hostVersions.llm
      && entry.dshPackages === payloadR2.hostVersions.tools && entry.dshPackages === payloadR2.hostVersions.typertProtocol)
    check('R2-g 真实锚: 本仓实装版本组合 ∈ 基线档案 → RPC 协商态 matched（baselineId = 命中档案项 id；ARCH-007：主基线升 0.2.2-rc.1，本仓 node_modules 树仍 0.2.0-rc.2 ⇒ 命中 0.2.0 frozen 项——声明面逐代并集覆盖全部支持代际）',
      liveEntryR2 !== undefined
      && payloadR2.capabilityProfile.state === 'matched'
      && payloadR2.capabilityProfile.baselineId === liveEntryR2.id,
      { hostVersions: payloadR2.hostVersions, capabilityProfile: payloadR2.capabilityProfile })
  }

  // R2-h. 徽章三态渲染判别（浏览器镜像 HostHealthCard）+ render 期零 probe（探针
  //   计数断言——渲染只消费快照数据，capabilityProfile 经 RPC 一次性 effect 进
  //   hostHealth 状态缓存，render 体零 probe/零 RPC）。
  {
    const reactStubR2 = {
      createElement: (type, props, ...children) => ({ type, props: { ...(props ?? {}), ...(children.length > 0 ? { children: children.flat(Infinity) } : {}) } }),
      useState: () => [null, () => {}],
      useEffect: () => {},
      useCallback: (fn) => fn,
      useRef: () => ({ current: null }),
    }
    let bundleR2 = null
    new Function('window', readFileSync(join(ROOT_DIR, 'lib', 'client.js'), 'utf8'))({ __ModuleLoader__: { load: (payload) => { bundleR2 = payload } } })
    const bundleExportsR2 = bundleR2.factory((name) => (name === 'react' ? reactStubR2 : null))
    const tStubR2 = (key) => Object.assign((arg) => `${key}(${arg})`, { toString: () => key })
    const textsR2 = []
    const pairsR2 = []
    const collectR2 = (node) => {
      if (typeof node === 'string') { textsR2.push(node); return }
      if (typeof node === 'function') { textsR2.push(String(node)); return }
      if (typeof node === 'number' || typeof node === 'boolean') { textsR2.push(String(node)); return }
      if (!node || typeof node !== 'object') return
      if (typeof node.props?.className === 'string' && /dshrouter-(ok|warn|error)/.test(node.props.className)) {
        // 类名↔文本绑定收集（防误配对：unknown 展开体 hint 行同持 dshrouter-warn，
        // 徽章判据必须锚定「徽章文案所在节点」的类名——类名单独收集会被同簇类
        // 遮蔽（判别红演示实证）。
        const nodeTexts = []
        const collectTextOnly = (child) => {
          if (typeof child === 'string' || typeof child === 'number' || typeof child === 'boolean') nodeTexts.push(String(child))
          else if (typeof child === 'function') nodeTexts.push(String(child))
          else if (child && typeof child === 'object' && Array.isArray(child.props?.children)) for (const grandchild of child.props.children) collectTextOnly(grandchild)
        }
        if (Array.isArray(node.props.children)) for (const child of node.props.children) collectTextOnly(child)
        pairsR2.push({ className: node.props.className, text: nodeTexts.join(' ') })
      }
      for (const child of Array.isArray(node.props?.children) ? node.props.children : []) collectR2(child)
    }
    const renderR2 = (hostHealth, faceHealth) => {
      textsR2.length = 0
      pairsR2.length = 0
      collectR2(bundleExportsR2.HostHealthCard({ hostHealth, faceHealth, t: tStubR2 }))
      return { texts: textsR2.slice(), pairs: pairsR2.slice() }
    }
    // 徽章节点 = 持 dshrouter-{ok,warn,error} 类且文本为徽章文案（ok/unknown 精确、
    // warn 为 hostHealthWarn(n) 形态——与 hint 行的 hostHealthUnknownHint 区分）。
    const badgeOfR2 = (render) => render.pairs.find((pair) => /dshrouter-(ok|warn|error)/.test(pair.className)
      && (pair.text === 'hostHealthOk' || pair.text === 'hostHealthUnknown' || pair.text.startsWith('hostHealthWarn('))) ?? null
    let probeCallsR2h = 0
    registerFaceProbes([{ name: 'r2h:count', probe: () => { probeCallsR2h += 1; return { state: 'ok' } } }])
    runFaceProbes({ get: () => undefined })
    const renderBaselineR2 = probeCallsR2h
    const matchedRenderR2 = renderR2({ hostVersions: versionsOfR2('0.2.0-rc.2'), faces: [{ name: 'llm', state: 'ok' }], capabilityProfile: { state: 'matched', baselineId: '0.2.0' } }, null)
    const unknownRenderR2 = renderR2({ hostVersions: versionsOfR2('0.2.1-alpha.5'), faces: [{ name: 'llm', state: 'ok' }], capabilityProfile: { state: 'compatible-unknown', baselineId: '' } }, null)
    // incompatible 夹具：非 ok 面在 RPC faces 内（真实 payload 中 capabilityProfile.
    // state=incompatible 与非 ok 面同帧到达；本地面同名会被 F-6 去重 RPC 权威序在前）。
    const incompatibleRenderR2 = renderR2({ hostVersions: versionsOfR2('0.2.0-rc.2'), faces: [{ name: 'llm', state: 'ok' }, { name: 'remote.settings', state: 'missing', detail: 'host-face-missing' }], capabilityProfile: { state: 'incompatible', baselineId: '0.2.0' } }, null)
    check('R2-h: matched → 绿徽章（badge 节点 dshrouter-ok + hostHealthOk）+ 实测基线 id 上屏（hostHealthBaseline——版本行后缀）',
      badgeOfR2(matchedRenderR2)?.className === 'dshrouter-ok' && matchedRenderR2.texts.includes('hostHealthOk')
      && matchedRenderR2.texts.some((text) => text.includes('hostHealthBaseline(0.2.0)'))
      && !matchedRenderR2.pairs.some((pair) => pair.className === 'dshrouter-warn'))
    check('R2-h: compatible-unknown → 黄徽章 + 显式「未实测宿主版本」提示（badge 节点 dshrouter-warn + badge 文案 + 展开体 hint 行；不误绿不误红）',
      badgeOfR2(unknownRenderR2)?.className === 'dshrouter-warn' && badgeOfR2(unknownRenderR2)?.text === 'hostHealthUnknown'
      && unknownRenderR2.texts.some((text) => text.includes('hostHealthUnknownHint'))
      && !unknownRenderR2.texts.includes('hostHealthOk') && !unknownRenderR2.pairs.some((pair) => pair.className === 'dshrouter-error'))
    check('R2-h: incompatible → 红徽章 ⚠ 面降级计数（badge 节点 dshrouter-error + hostHealthWarn(n)；非黄非绿）',
      badgeOfR2(incompatibleRenderR2)?.className === 'dshrouter-error' && badgeOfR2(incompatibleRenderR2)?.text === 'hostHealthWarn(1)'
      && !incompatibleRenderR2.pairs.some((pair) => pair.className === 'dshrouter-warn') && !incompatibleRenderR2.texts.includes('hostHealthOk'))
    check('R2-h: 三态渲染期零 probe（探针计数断言——render 只消费快照/RPC 数据）',
      probeCallsR2h === renderBaselineR2)
    // 旧服务端容忍：capabilityProfile 缺席（旧服务端响应 / 取数失败恢复期）→ 回落
    // 既有两态口径（全绿徽章），不误报黄。
    const legacyRenderR2 = renderR2({ hostVersions: versionsOfR2('0.1.5-rc.2'), faces: [{ name: 'llm', state: 'ok' }] }, null)
    check('R2-h 兼容: capabilityProfile 缺席（旧服务端）→ 既有口径回落（badge 绿，不误黄）',
      badgeOfR2(legacyRenderR2)?.className === 'dshrouter-ok' && !legacyRenderR2.pairs.some((pair) => pair.className === 'dshrouter-warn')
      && legacyRenderR2.texts.includes('hostHealthOk'))
  }
}

// ═══════════════════════════════════════════════════════════════════════════
/**
 * R3（ARCH-004 域 8）：宿主包代际自检的**判定语义**判别。
 *
 * 为什么需要本组：2026-10-25 桌面端启动故障的机制（profile 根被提升出宿主包旧
 * 副本 → 装载门 disable 核心 tools 行）此前完全不可观测。域 8 补上观测面，而
 * 观测面本身最容易犯的错是**误报**——「插件实际解析副本」必须取经宿主运行时
 * 替换层路由后的结果；若改用裸路径序探测，会命中 profile 之上的
 * `$DSH_HOME/profiles/node_modules`（脚本通道扁平宿主树），与桌面端宿主天然
 * 不同代 ⇒ 每次启动误报遮蔽（实测：打包安装的插件裸路径序读到
 * dsh-tools@0.2.1-rc.2，运行时实际却加载宿主 0.2.1-rc.3）。
 *
 * 本组以**构造性夹具**（临时锚 + 桩服务）判别三件事，任一反向实现都会红：
 * ① 无替换层服务（老宿主/桩上下文）→ `routing='none'` 且**恰零** mismatch
 *    （即使宿主锚侧版本与插件侧版本天然不同也不许报）——误报防线；
 * ② 有服务且两侧一致 → 零 mismatch、零事件（健康时不制造噪声）；
 * ③ 有服务且两侧不一致（= 遮蔽形态）→ 命中 mismatch 一条/包 + 精确诊断
 *    `host-package-generation-mismatch`/`shadowed-host-package`——漏报防线。
 */
console.log('R3 host-package generation self-check (domain 8: routed-vs-anchor semantics):')
{
  const HP_ANCHOR_VERSION = '9.9.9'
  const HP_SIDE_TMP = mkdtempSync(join(tmpdir(), 'dsh-router-hp-'))
  try {
    // 构造「宿主安装锚」：只放 dsh-tools 一个包，版本刻意远离本仓解析值 ⇒
    // 任何「裸路径序比对」实现都会报 mismatch（= ① 的判别力来源）。
    mkdirSync(join(HP_SIDE_TMP, 'node_modules', '@deepseek-ai', 'dsh-tools'), { recursive: true })
    writeFileSync(join(HP_SIDE_TMP, 'node_modules', '@deepseek-ai', 'dsh-tools', 'package.json'), JSON.stringify({ name: '@deepseek-ai/dsh-tools', version: HP_ANCHOR_VERSION }))
    const anchorPath = join(HP_SIDE_TMP, 'package.json')
    writeFileSync(anchorPath, JSON.stringify({ name: 'hp-fixture-host', version: '0.0.0' }))

    /** 上下文桩：profileContext.installAnchor 可选；pluginPackages 服务可选。 */
    const ctxStub = (anchor, service) => ({
      get: (name) => name === 'profileContext'
        ? (anchor === null ? undefined : { installAnchor: anchor })
        : name === 'pluginPackages' ? service : undefined,
    })
    /** 路由桩：逐包返回给定版本（模拟宿主替换层把裸包名解析到某副本）。 */
    const serviceOf = (versionOf) => ({ packageOf: (name) => (versionOf[name] === undefined ? undefined : { version: versionOf[name] }) })
    const diagTail = () => {
      const entries = hostAbi.hostDiagnostics().entries
      return entries.length === 0 ? undefined : entries[entries.length - 1]
    }
    /** 环形内最后一条匹配事件（mismatch 与 unresolved 正交同帧，不能用 tail 断言）。 */
    const lastDiag = (kind, code) => {
      const entries = hostAbi.hostDiagnostics().entries
      for (let index = entries.length - 1; index >= 0; index -= 1) {
        const entry = entries[index]
        if (entry.kind === kind && (code === undefined || entry.code === code)) return entry
      }
      return undefined
    }

    check('R3-a: 静态 import 面恰 4 包（代际比对集合 = 本插件真正 import 的宿主包，非全部 13 项声明）',
      JSON.stringify([...hostAbi.HOST_IMPORTED_PACKAGE_NAMES].sort())
      === JSON.stringify(['@deepseek-ai/dsh-llm', '@deepseek-ai/dsh-tools', '@deepseek-ai/dsh-typert-protocol', '@deepseek-ai/schemastery'].sort()),
      hostAbi.HOST_IMPORTED_PACKAGE_NAMES)

    // ① 无替换层服务 → 不给判定（误报防线）
    const noServiceReport = hostAbi.hostGenerationReport(ctxStub(anchorPath, undefined))
    check('R3-b: 无 pluginPackages 服务 → routing=none 且恰零 mismatch（宿主锚侧 9.9.9 与插件侧真值本就不同，仍不得报——裸路径序比对实现会在此红）',
      noServiceReport.routing === hostAbi.HOST_ROUTING.none
      && noServiceReport.mismatches.length === 0
      && noServiceReport.anchorAvailable === true
      && noServiceReport.host['@deepseek-ai/dsh-tools'] === HP_ANCHOR_VERSION,
      { routing: noServiceReport.routing, mismatches: noServiceReport.mismatches, hostTools: noServiceReport.host['@deepseek-ai/dsh-tools'] })

    // ①b 无 pluginPackages → noteHostGeneration 记「能力缺失」事件（P8 禁静默）
    hostAbi.noteHostGeneration(ctxStub(anchorPath, undefined))
    check('R3-c: 无替换层服务 → 诊断环形记 host-package-generation-unknown / no-plugin-packages（不静默、不误报为遮蔽）',
      diagTail()?.kind === 'host-package-generation-unknown' && diagTail()?.code === 'no-plugin-packages',
      diagTail())

    // ② 服务两侧一致 → 零 mismatch（健康态零 mismatch）
    const aligned = hostAbi.hostGenerationReport(ctxStub(anchorPath, serviceOf({ '@deepseek-ai/dsh-tools': HP_ANCHOR_VERSION })))
    check('R3-d: 服务两侧版本一致 → 零 mismatch（健康态零遮蔽噪声）',
      aligned.routing === hostAbi.HOST_ROUTING.intercept && aligned.mismatches.length === 0,
      { routing: aligned.routing, mismatches: aligned.mismatches })

    // ③ 服务两侧不一致（遮蔽形态）→ 命中 + 精确诊断
    const shadowedVersions = { '@deepseek-ai/dsh-tools': '0.2.0-rc.2' }
    const shadowed = hostAbi.hostGenerationReport(ctxStub(anchorPath, serviceOf(shadowedVersions)))
    check('R3-e: 服务侧 0.2.0-rc.2 vs 宿主锚 9.9.9 → 命中恰 1 条 mismatch 且带双侧版本（漏报防线）',
      shadowed.mismatches.length === 1
      && shadowed.mismatches[0].name === '@deepseek-ai/dsh-tools'
      && shadowed.mismatches[0].host === HP_ANCHOR_VERSION
      && shadowed.mismatches[0].own === '0.2.0-rc.2',
      shadowed.mismatches)
    hostAbi.noteHostGeneration(ctxStub(anchorPath, serviceOf(shadowedVersions)))
    const shadowEvent = lastDiag('host-package-generation-mismatch', 'shadowed-host-package')
    check('R3-f: 遮蔽形态 → 诊断环形记 host-package-generation-mismatch / shadowed-host-package 且 detail 含双侧版本（可一键导出报障）',
      shadowEvent !== undefined
      && typeof shadowEvent.detail === 'string'
      && shadowEvent.detail.includes(HP_ANCHOR_VERSION) && shadowEvent.detail.includes('0.2.0-rc.2'),
      shadowEvent)
    /**
     * ③b 逐包不可判定必须可观测（R0 审查 P2-1 / P8）：同一帧内 3 个包读不到版本
     * （夹具锚只放了 dsh-tools），旧实现静默跳过 → 这里必须有 dedicated 事件且列包名。
     * 断言用 lastDiag 而非 tail：mismatch 与 unresolved 正交同帧，各自入环形。
     */
    const unresolvedEvent = lastDiag('host-package-generation-unknown', 'unresolved-host-package')
    check('R3-g: 某侧逐包不可判定 → 记 host-package-generation-unknown / unresolved-host-package 且 detail 列出包名（不可判定 ≠ 一致，禁静默跳过——R0 P2-1）',
      unresolvedEvent !== undefined
      && typeof unresolvedEvent.detail === 'string'
      && unresolvedEvent.detail.includes('@deepseek-ai/dsh-llm')
      && !unresolvedEvent.detail.includes('@deepseek-ai/dsh-tools'),
      unresolvedEvent)

    // ④ 安装锚缺失 → 能力缺失事件（不是「一致」，也不是「遮蔽」）
    hostAbi.noteHostGeneration(ctxStub(null, serviceOf({})))
    check('R4: 无 profileContext（安装锚缺失）→ host-package-generation-unknown / no-install-anchor（不可判定 ≠ 一致）',
      diagTail()?.kind === 'host-package-generation-unknown' && diagTail()?.code === 'no-install-anchor',
      diagTail())

    // ⑤ 诊断失败绝不外泄：畸形 ctx 不 throw
    let survived = true
    try {
      hostAbi.noteHostGeneration({ get: () => { throw new Error('boom') } })
    } catch { survived = false }
    check('R5: 宿主上下文 read 抛错 → 自检绝不 throw（诊断失败绝不影响主链，health 域同款纪律）', survived)
  } finally {
    rmSync(HP_SIDE_TMP, { recursive: true, force: true })
  }
}

console.log(failures === 0 ? `\nALL HOST ABI HEALTH TESTS PASSED (${passed} assertions)` : `\n${failures} FAILURE(S) (${passed} passed)`)
process.exit(failures === 0 ? 0 : 1)

