// dsh-virtual-workspace — Client half（code.client，与运行版 vws-1/pkg-7 逻辑一致；CSS 以模板串排版，内容相同）
//
// 这是 cordis_define 的 `code.client` 函数体（原样逻辑）。
// 平台约束：纯 JavaScript；无 import/require/JSX/TypeScript；
// UI 一律 React.createElement；数据经 host.call 包私有 RPC。
// 国际化：注册 `vws` 字典（en/zh）；显式选择——仅 zh 显示简体中文，其余语言一律英文；
// 语言切换经 locale.subscribe 即时重渲染。
export default function () {
const VWS_EN = {
  'flow.title': 'Add workspace',
  'flow.cancel': 'Cancel',
  'flow.dragHint': 'Drag to move this panel',
  'single.title': 'Single directory (native)',
  'single.choose': 'Choose folder…',
  'single.choosing': 'Choosing…',
  'single.hint': 'Opens the system folder dialog and creates a regular workspace.',
  'multi.title': 'Or create a virtual workspace (multiple directories)',
  'multi.namePlaceholder': 'Name (e.g. myprojects)',
  'multi.dirPlaceholder': 'D:\\proj\\app',
  'multi.browse': 'Browse',
  'multi.addDir': '＋ add directory',
  'multi.mirror': ' Mirror directories into the sidebar workspace list',
  'multi.create': 'Create virtual workspace',
  'multi.requireNameDirs': 'name and at least one directory are required',
  'list.title': 'Virtual workspaces',
  'list.empty': 'None yet. A virtual workspace groups several project directories for the agent to read and modify together.',
  'ws.sidebarOn': 'Sidebar: on',
  'ws.sidebarOff': 'Sidebar: off',
  'ws.remove': 'Remove',
  'err.load': 'failed to load state',
  'err.request': 'request failed',
  'err.add': 'add failed',
  'err.noPicker': 'native directory picker unavailable',
  'err.noPickerManual': 'native directory picker unavailable — type the path manually',
}
const VWS_ZH = {
  'flow.title': '添加工作区',
  'flow.cancel': '取消',
  'flow.dragHint': '拖动可移动此面板',
  'single.title': '单个目录（原生）',
  'single.choose': '选择文件夹…',
  'single.choosing': '选择中…',
  'single.hint': '打开系统文件夹对话框并创建普通工作区。',
  'multi.title': '或创建虚拟工作区（多个目录）',
  'multi.namePlaceholder': '名称（例如 myprojects）',
  'multi.dirPlaceholder': 'D:\\proj\\app',
  'multi.browse': '浏览',
  'multi.addDir': '＋ 添加目录',
  'multi.mirror': ' 将目录镜像到侧边栏工作区列表',
  'multi.create': '创建虚拟工作区',
  'multi.requireNameDirs': '需要填写名称和至少一个目录',
  'list.title': '虚拟工作区',
  'list.empty': '暂无。虚拟工作区把多个项目目录组合在一起，供 agent 统一读取和修改。',
  'ws.sidebarOn': '侧边栏：开',
  'ws.sidebarOff': '侧边栏：关',
  'ws.remove': '移除',
  'err.load': '状态加载失败',
  'err.request': '请求失败',
  'err.add': '添加失败',
  'err.noPicker': '无法使用系统目录选择器',
  'err.noPickerManual': '无法使用系统目录选择器——请手动输入路径',
}

function VwsFlow(props) {
  const open = Boolean(props && props.open)
  const ownerBusy = Boolean(props && props.busy)
  const onPicked = props && props.onPicked
  const onCancel = props && props.onCancel
  const pickDirectory = props && props.pickDirectory
  const t = (props && props.t) || ((k) => k)
  const onLocale = props && props.onLocale

  const [state, setState] = React.useState(null)
  const [error, setError] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const [picking, setPicking] = React.useState(false)
  const [name, setName] = React.useState('')
  const [dirs, setDirs] = React.useState([''])
  const [mirror, setMirror] = React.useState(true)
  const [pos, setPos] = React.useState({ x: 12, y: 46 })
  const [dragging, setDragging] = React.useState(false)
  const [dragStart, setDragStart] = React.useState(null)
  const [, forceRender] = React.useState(0)

  React.useEffect(() => {
    if (!onLocale) return
    return onLocale(() => forceRender((v) => v + 1))
  }, [onLocale])
  React.useEffect(() => {
    if (!open) return
    host.call('vws.state').then((res) => {
      if (res && res.ok) setState(res)
      else setError(res && res.error ? res.error : t('err.load'))
    }).catch((err) => setError(String((err && err.message) || err)))
  }, [open])
  // Defensive reset: if the native picker never reports back (hangs after the
  // dialog is closed), reopening the drawer clears the stuck picking state.
  React.useEffect(() => {
    if (!open) setPicking(false)
  }, [open])

  if (!open) return null

  function refresh() {
    host.call('vws.state').then((res) => {
      if (res && res.ok) setState(res)
    }).catch(() => {})
  }
  function runCall(method, callArgs) {
    setBusy(true)
    setError('')
    host.call(method, callArgs).then((res) => {
      setBusy(false)
      if (res && res.ok) refresh()
      else setError(res && res.error ? res.error : t('err.request'))
    }).catch((err) => {
      setBusy(false)
      setError(String((err && err.message) || err))
    })
  }
  function browseRow(i) {
    if (!pickDirectory) { setError(t('err.noPickerManual')); return }
    setPicking(true)
    pickDirectory().then((path) => {
      setPicking(false)
      if (path) setDirs((prev) => prev.map((d, j) => (j === i ? path : d)))
    }).catch((err) => {
      setPicking(false)
      setError(String((err && err.message) || err))
    })
  }
  function quickAddSingle() {
    if (!pickDirectory) { setError(t('err.noPicker')); return }
    setPicking(true)
    pickDirectory().then((path) => {
      setPicking(false)
      if (path && onPicked) onPicked(path)
    }).catch((err) => {
      setPicking(false)
      setError(String((err && err.message) || err))
    })
  }
  function create() {
    const clean = dirs.map((s) => s.trim()).filter((s) => s.length > 0)
    if (name.trim() === '' || clean.length === 0) { setError(t('multi.requireNameDirs')); return }
    setBusy(true)
    setError('')
    host.call('vws.add', { name: name.trim(), dirs: clean, mirror }).then((res) => {
      setBusy(false)
      if (res && res.ok) {
        setName('')
        setDirs([''])
        setMirror(true)
        refresh()
        if (onCancel) onCancel()
      } else {
        setError(res && res.error ? res.error : t('err.add'))
      }
    }).catch((err) => {
      setBusy(false)
      setError(String((err && err.message) || err))
    })
  }

  // Dragging: pointer capture on the header, so moves outside the panel are
  // tracked without window/document listeners (sandbox-safe). Buttons inside
  // the header stop pointerdown propagation to keep clicks working.
  function startDrag(e) {
    if (!e || e.button !== 0) return
    e.preventDefault()
    try { e.currentTarget.setPointerCapture(e.pointerId) } catch (err) { /* noop */ }
    setDragStart({ x: e.clientX, y: e.clientY, base: pos })
    setDragging(true)
  }
  function moveDrag(e) {
    if (!dragStart) return
    setPos({ x: Math.max(0, dragStart.base.x + (e.clientX - dragStart.x)), y: Math.max(0, dragStart.base.y + (e.clientY - dragStart.y)) })
  }
  function endDrag() {
    setDragging(false)
    setDragStart(null)
  }

  const workspaces = state && Array.isArray(state.workspaces) ? state.workspaces : []
  // An in-flight native pick must never freeze the whole drawer: only the
  // pick buttons are disabled while picking; Cancel always stays clickable.
  const disabled = busy || ownerBusy
  const browseDisabled = disabled || picking

  return React.createElement('div', { className: 'vws-drawer', style: { top: pos.y, left: pos.x } },
    React.createElement('div', {
      className: dragging ? 'vws-panel-head vws-panel-head-drag' : 'vws-panel-head',
      title: t('flow.dragHint'),
      onPointerDown: startDrag,
      onPointerMove: moveDrag,
      onPointerUp: endDrag,
      onPointerCancel: endDrag,
    },
      React.createElement('span', { className: 'vws-panel-title' }, t('flow.title')),
      React.createElement('button', { type: 'button', className: 'vws-mini', onPointerDown: (e) => e.stopPropagation(), onClick: () => onCancel && onCancel() }, t('flow.cancel')),
    ),
    React.createElement('div', { className: 'vws-card' },
      React.createElement('div', { className: 'vws-sec' }, t('single.title')),
      React.createElement('button', { type: 'button', className: 'vws-add', disabled: browseDisabled, onClick: quickAddSingle }, picking ? t('single.choosing') : t('single.choose')),
      React.createElement('div', { className: 'vws-hint' }, t('single.hint')),
    ),
    React.createElement('div', { className: 'vws-card' },
      React.createElement('div', { className: 'vws-sec' }, t('multi.title')),
      React.createElement('input', { className: 'vws-input', value: name, placeholder: t('multi.namePlaceholder'), disabled, onChange: (e) => setName(e.target.value) }),
      ...dirs.map((d, i) => React.createElement('div', { className: 'vws-dir-row', key: i },
        React.createElement('input', { className: 'vws-input', value: d, placeholder: t('multi.dirPlaceholder'), disabled, onChange: (e) => setDirs(dirs.map((x, j) => (j === i ? e.target.value : x))) }),
        React.createElement('button', { type: 'button', className: 'vws-mini', disabled: browseDisabled, title: t('multi.browse'), onClick: () => browseRow(i) }, t('multi.browse')),
        React.createElement('button', { type: 'button', className: 'vws-mini', disabled: disabled, onClick: () => setDirs(dirs.filter((x, j) => j !== i)) }, '×'),
      )),
      React.createElement('button', { type: 'button', className: 'vws-mini', disabled, onClick: () => setDirs(dirs.concat([''])) }, t('multi.addDir')),
      React.createElement('label', { className: 'vws-check' },
        React.createElement('input', { type: 'checkbox', checked: mirror, disabled, onChange: (e) => setMirror(e.target.checked) }),
        t('multi.mirror'),
      ),
      React.createElement('button', { type: 'button', className: 'vws-add', disabled: disabled || name.trim() === '' || dirs.every((s) => s.trim() === ''), onClick: create }, t('multi.create')),
    ),
    error ? React.createElement('div', { className: 'vws-error' }, error) : null,
    React.createElement('div', { className: 'vws-panel-title' }, t('list.title')),
    ...(workspaces.length === 0
      ? [React.createElement('div', { className: 'vws-empty' }, t('list.empty'))]
      : workspaces.map((ws) => React.createElement('div', { className: 'vws-card', key: ws.name },
          React.createElement('div', { className: 'vws-card-head' },
            React.createElement('span', { className: 'vws-name' }, ws.name),
            React.createElement('div', { className: 'vws-card-actions' },
              React.createElement('button', { type: 'button', className: 'vws-mini', disabled: disabled, onClick: () => runCall('vws.set-mirror', { name: ws.name, enabled: !ws.mirror }) }, ws.mirror ? t('ws.sidebarOn') : t('ws.sidebarOff')),
              React.createElement('button', { type: 'button', className: 'vws-mini', disabled: disabled, onClick: () => runCall('vws.remove', { name: ws.name }) }, t('ws.remove')),
            ),
          ),
          ...ws.dirs.map((d) => React.createElement('div', { className: 'vws-dir-row', key: d.path },
            React.createElement('span', { className: 'vws-dir', title: d.path }, d.path),
            React.createElement('button', { type: 'button', className: 'vws-mini', disabled: disabled, onClick: () => runCall('vws.remove-dir', { name: ws.name, path: d.path }) }, '×'),
          )),
        ))),
  )
}

return {
  apply(ctx) {
    const slots = ctx.get('slots')
    if (slots === undefined) return
    const workspaces = ctx.get('workspaces')
    const locale = ctx.get('locale')
    const t = locale
      ? (key) => {
          const snap = locale.getLocale()
          const id = snap && snap.active
          if (id !== 'zh') return VWS_EN[key] !== undefined ? VWS_EN[key] : key
          return VWS_ZH[key] !== undefined ? VWS_ZH[key] : (VWS_EN[key] !== undefined ? VWS_EN[key] : key)
        }
      : (key) => (VWS_EN[key] !== undefined ? VWS_EN[key] : key)
    ctx.effect(() => {
      const disposers = []
      if (locale) {
        try {
          disposers.push(locale.register('vws', 'en', VWS_EN))
          disposers.push(locale.register('vws', 'zh', VWS_ZH))
        } catch (err) {
          console.error('vws: locale registration failed:', err)
        }
      }
      return () => { for (const d of disposers) { try { d() } catch (err) { /* noop */ } } }
    })
    ctx.effect(() => styles.insert(`
      @keyframes vws-drop { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
      .vws-drawer {
        position: fixed; top: 46px; left: 12px; z-index: 9980;
        width: min(360px, calc(100vw - 24px));
        max-height: calc(100vh - 64px); overflow-y: auto;
        background: var(--dsw-alias-bg-overlay, #1e1f24);
        border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.35));
        border-radius: 12px;
        box-shadow: 0 12px 32px rgba(0,0,0,.35);
        color: var(--dsw-alias-label-primary, inherit);
        padding: 12px; display: flex; flex-direction: column; gap: 10px;
        font-size: 13px; pointer-events: auto;
        animation: vws-drop .14s ease;
      }
      .vws-panel-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; cursor: grab; user-select: none; touch-action: none; }
      .vws-panel-head-drag { cursor: grabbing; }
      .vws-panel-title { font-weight: 600; font-size: 13px; }
      .vws-sec { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: var(--dsw-alias-label-secondary, inherit); opacity: .9; }
      .vws-card { border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.3)); border-radius: 8px; padding: 8px 10px; display: flex; flex-direction: column; gap: 6px; background: var(--dsw-alias-bg-layer-1, transparent); }
      .vws-card-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .vws-card-actions { display: flex; align-items: center; gap: 4px; }
      .vws-name { font-weight: 600; }
      .vws-dir-row { display: flex; align-items: center; gap: 6px; }
      .vws-dir { font-family: ui-monospace, SFMono-Regular, Consolas, monospace; font-size: 11px; word-break: break-all; flex: 1; color: var(--dsw-alias-label-secondary, inherit); }
      .vws-input { font-family: inherit; font-size: 13px; width: 100%; min-width: 0; box-sizing: border-box; padding: 6px 8px; border-radius: 8px; border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.35)); background: var(--dsw-alias-bg-base, transparent); color: var(--dsw-alias-label-primary, inherit); }
      .vws-mini { cursor: pointer; border: none; background: transparent; color: var(--dsw-alias-label-secondary, inherit); font-size: 12px; padding: 2px 6px; border-radius: 6px; flex: none; }
      .vws-mini:hover { background: var(--dsw-alias-bg-layer-2, rgba(127,127,127,.15)); color: var(--dsw-alias-state-error-primary, inherit); }
      .vws-add { cursor: pointer; font-family: inherit; font-size: 13px; padding: 6px 12px; border-radius: 8px; border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.5)); background: var(--dsw-alias-brand-primary, #4c7df0); color: #fff; align-self: flex-start; }
      .vws-add:disabled { opacity: .5; cursor: default; }
      .vws-hint { font-size: 11px; color: var(--dsw-alias-label-secondary, inherit); opacity: .85; }
      .vws-check { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--dsw-alias-label-secondary, inherit); }
      .vws-error { color: var(--dsw-alias-state-error-primary, #e5484d); font-size: 12px; white-space: pre-wrap; }
      .vws-empty { color: var(--dsw-alias-label-secondary, inherit); font-size: 12px; opacity: .85; }
    `))
    slots.inject('sidebar.workspaces.directoryFlow', () => slots.register(
      { name: 'sidebar.workspaces.directoryFlow', priority: -2, inject: () => ({
        pickDirectory: workspaces ? () => workspaces.pickDirectory() : null,
        t,
        onLocale: locale ? (fn) => locale.subscribe(fn) : null,
      }) },
      (props) => React.createElement(VwsFlow, props),
    ))
  },
}
}
