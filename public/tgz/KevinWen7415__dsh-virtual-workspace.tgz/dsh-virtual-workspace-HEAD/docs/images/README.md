# docs/images — 截图目录

按 `README.md`「截图」一节的说明放置图片：

| 文件 | 内容 |
| --- | --- |
| `01-drawer.png` | 点击侧边栏 ＋ 弹出的抽屉面板（创建表单 + 管理列表） |
| `02-sidebar-mirror.png` | 内置侧边栏列表中的 `EDB · xxx` 镜像条目 |
| `03-picker.png` | 点击 Browse / Choose folder 弹出的系统目录选择对话框 |
| `04-agent-usage.png` | 对话中 agent 调用 `vws` 跨目录读文件/搜索的结果 |

建议尺寸：01 ≈ 400×720；02 ≈ 320×420；03 仅对话框；04 ≈ 640×600。
