# 设计文档：dsh-virtual-workspace（虚拟工作区）

版本：1.0 ｜ 对应实现：`vws-1/pkg-3` ｜ 关联：01-requirements、03-development、04-api-reference

## 1. 总体架构

```
┌────────────────────────────── Web GUI（Client）──────────────────────────────┐
│  shell.overlay（浮层插槽）                                                    │
│   └─ vws-dock：侧边栏顶部按钮 ＋ 管理面板（列表/添加/移除）                     │
│       └─ host.call('vws.state' | 'vws.add' | 'vws.remove' | ...)  ────────┐  │
├───────────────────────────────────────────────────────────────────────────┼──┤
│  Host（DSH Node 进程）                                                     │  │
│   ├─ vws 工具（12 actions，注册进 tools 注册表）── 模型可调用                │  │
│   ├─ vws Host 服务（ctx.provide）── 其他插件可组合                          │  │
│   ├─ RPC handlers（harness.handle）◄──────────────────────────────────────┘  │
│   ├─ systemPrompt 段（tool:vws）── agent 每轮可见                             │
│   ├─ 状态：内存 {name → dirs[]} ＋ 持久化 .vws-workspaces.json（fs 服务）      │
│   └─ 沙箱：sandboxPolicy.resolve({session}) → fs.writeText/editText(…, policy)│
└──────────────────────────────────────────────────────────────────────────────┘
```

职责划分：

| 层 | 职责 | 关键技术点 |
| --- | --- | --- |
| Host | 状态模型、持久化、路径解析、文件读写、沙箱/审批、agent 工具、提示注入、RPC 服务端 | `fs`、`sandboxPolicy`、`approval`、`systemPrompt`、`harness` |
| Client | 侧边栏按钮与面板 UI、RPC 客户端、样式 | `shell.overlay` 插槽、`host.call`、`styles.insert` |

## 2. UI 设计：插槽选型分析

### 2.1 候选插槽矩阵（实测自 Slots.listSubTree）

| 候选 | kind | 占用 | replaceRisk | 位置 | 结论 |
| --- | --- | --- | --- | --- | --- |
| `sidebar` | single | 官方 SidebarRoot | shadows-shipped-ui | 整个左列 | ❌ 替换整个导航列，连带移除工作区/设置座位 |
| `sidebar.workspaces` | single | 官方 WorkspaceBrowser | shadows-shipped-ui | 浏览区 | ❌ 需自研会话列表/搜索/对话框，遮蔽官方 UI |
| `sidebar.workspaces.directoryFlow` | single | 官方目录选择流 | shadows-shipped-ui | 浏览区下方 | ❌ 替换会破坏官方"选目录"流程 |
| `sidebar.footer.action` | list（可追加） | 空 | none | 侧边栏**底部** | ❌ 位置不满足"侧边栏上面" |
| `settings.section` | list（可追加） | 已用（本插件 pkg-1/2） | none | 设置面板 | ❌ 用户明确否定 |
| `shell.overlay` | list（可追加） | **空** | none | 帧级浮层 | ✅ 唯一同时满足"可追加 + 顶部定位"的合法入口 |

### 2.2 选定方案：shell.overlay 停靠按钮 + 面板

- 浮层本身 click-through，条目自行启用 pointer-events（`pointer-events: auto`），不阻塞下方交互。
- 按钮固定定位在侧边栏顶部左上角（`position: fixed; top: 6px; left: 6px`），与侧边栏头部（36px 高、左侧为 "Workspaces" 标题、右侧为官方搜索/添加按钮）错位共存：
  - 默认半透明（opacity 0.55），hover 全显，降低对标题文字的视觉干扰；
  - rail（折叠）状态下按钮仍在原位，成为列顶的显式入口。
- 面板锚定在按钮下方（`top: 44px; left: 8px; width: 320px; max-height: calc(100vh - 60px)`），内容可滚动。

### 2.3 布局规格（pkg-3）

```
┌─ 侧边栏（wide 或 rail）────────────────┐
│ [＋]  ← vws 按钮（28×28，圆形，fixed 6/6）│
│ ┌─ 面板（展开时，fixed 44/8，宽 320）──┐ │
│ │ Virtual Workspaces            [×] │ │
│ │ Sandbox mode: workspace-write     │ │
│ │ ┌ EDB ──────────────────[Remove]┐ │ │
│ │ │ D:\workspace\external-demo… [×]│ │ │
│ │ │ D:\workspace\spring-cloud…  [×]│ │ │
│ │ │ D:\workspace\internal-demo [×] │ │ │
│ │ └────────────────────────────────┘ │ │
│ │ ┌ Add / replace workspace ───────┐ │ │
│ │ │ Name [__________]              │ │ │
│ │ │ Directories (one per line)     │ │ │
│ │ │ [__________________]           │ │ │
│ │ │ [__________________]           │ │ │
│ │ │ [ Add ]                        │ │ │
│ │ └────────────────────────────────┘ │ │
│ └────────────────────────────────────┘ │
└────────────────────────────────────────┘
```

### 2.4 交互状态机

```
closed ──点击按钮──▶ open ──点击按钮/×──▶ closed
                       │
                       ├─ Add 成功 ──▶ 刷新列表（保持 open）
                       ├─ Remove/× 成功 ──▶ 刷新列表
                       └─ RPC 失败 ──▶ 面板内错误行
```

- 面板不拦截全局指针（仅面板自身区域捕获事件）。
- 不做拖拽、不记忆位置（列入后续增强）。

### 2.5 备选方案对比

| 方案 | 描述 | 优点 | 缺点 | 结论 |
| --- | --- | --- | --- | --- |
| A. 替换 `sidebar.workspaces` | 自研整个浏览区（标题/搜索/会话列表/对话框） | 完全原生位置 | 工作量大、遮蔽官方 UI、升级易碎 | ❌ |
| B. 注册进 `workspaceRegistry` | 把虚拟工作区每个目录 create 为内置工作区 | 直接出现在内置列表 | 概念混淆（单目录≠分组）、污染注册表、无法表达"一组" | ✅ **已采用（pkg-4 镜像注册）**：标题 `工作区名 · 目录名` + 所有权跟踪 + 只清理自建条目，缓解上述缺点 |
| C. 底部 `sidebar.footer.action` | 用官方可追加座位 | 零风险 | 位置在底部，不满足需求 | ❌ |
| D. 固化进 host composition | 修改侧边栏包以提供顶部插槽 | 长期最优 | 超出动态插件范围，需部署级改造 | 🔮 后续演进方向 |
| E. overlay 停靠按钮＋面板（选定） | 帧级浮层锚定侧边栏顶部 | 零遮蔽风险、可追加、满足位置 | 与标题轻微重叠（半透明缓解）；无 collapse 状态感知 | ✅ |

### 2.6 镜像注册设计（pkg-4，方案 B 落地）

**目标**：让虚拟工作区的成员目录出现在内置侧边栏/工作区列表。

**机制**：
- 宿主服务 `workspaceRegistry`（持久化注册表）。`create(path, title)` 只接受**真实存在**的目录（realpath 后不存在/非目录均拒绝——"虚假目录"不可注入）；重复 create 同一路径返回既有条目且不改标题；`delete(id)` 只删注册记录，保留目录与会话日志。
- 插件为每个成员目录调用 `create(dir.path, '工作区名 · 目录名')`，条目即出现在官方列表（含新会话工作区选择器）。

**所有权跟踪（安全清理的核心）**：
- 状态文件新增 `mirror` 映射：`{ 工作区名: { 目录路径: { id, preexisting } } }`（v2）。
- 注册前先 `resolveByPath(dir.path)`：命中 → 记 `preexisting: true`（不删除他人条目）；未命中 → `create` 并记 `preexisting: false`。
- 清理路径（移除工作区 / 移除目录 / 关闭镜像）只 `delete` 自建条目（`preexisting:false`），`preexisting` 条目仅解除映射。

**开关**：`mirror`（工作区级布尔，add 默认 true）+ `set-mirror` 动作（true 全量注册，false 全量清理）。

**降级与边界**：
- `workspaceRegistry` 未挂载：工作区创建照常成功，`registryAvailable:false`，镜像错误汇总进 `mirrorErrors`。
- 不做启动期自动对账（用户在官方 UI 手动删除条目后不复活；`delete` 未知 id 为幂等 no-op）。
- 条目顺序：create 会前插注册表顺序，接受该表现，不做排序控制。

### 2.7 原生入口集成（pkg-5，替代 dock 方案）

**动机**：用户否定左上角悬浮按钮，要求"增强内置添加工作区按钮"（下拉选单式）并支持"选中多个目录联立虚拟工作区"。

**插槽机制（实测自源码）**：
- 内置侧边栏 ＋ 按钮只在 `sidebar.workspaces.directoryFlow` 槽**被占用**时显示（`useDirectoryFlow((occupied) => occupied)`），点击即把 `open` 置真并在槽内渲染占用者。
- 单槽竞争规则（ui-slots）：**priority 升序、最低者渲染**；官方占用者 priority 0，动态插件注册默认 priority **-2** → 我们的注册天然遮蔽官方目录浏览流（官方条目保留但 inactive）。hero 空白页的 `conversation.hero.workspace.directoryFlow` 是独立槽，不受影响。
- 槽属主契约（`DirectoryFlowOwnerProps`）：`{ open, busy, onPicked(path), onCancel, onError }`，每次 open 恰好上报一个结果。

**双模式面板（等价下拉选单）**：
```
[＋ 内置按钮] → VwsFlow（open 时渲染）
  ├─ Single directory（原生）：pickDirectory() → onPicked(path)   // 官方创建普通工作区
  ├─ Virtual workspace（多目录）：名称 + N 行目录（Browse=pickDirectory 逐行选择/手动/增删行）
  │     + Mirror 开关 → host.call('vws.add') → onCancel()        // 插件创建虚拟工作区并关闭流程
  └─ 管理列表：既有虚拟工作区（移除 / 目录 × / Sidebar 开关）
```
- `pickDirectory` 来自客户端 `workspaces` 服务（`ctx.get('workspaces').pickDirectory()`，经 register 的 `inject` 选项注入组件 props）；不可用时降级为手动输入并提示。
- `onCancel()` 复用属主契约关闭流程；`busy` 期间禁用全部控件。

**原生选择器冻结防护（pkg-8）**：平台原生目录选择器在独立 worker 进程中显示对话框，取消时依赖 worker IPC 回传 `done`；若 worker 关闭后未回报（消息悬挂），`pickDirectory()` 永不结算。因此：`picking` 状态**只禁用 Browse/Choose 按钮**，不再禁用整个抽屉；**Cancel 恒可点击**；抽屉关闭/重开时重置 `picking`（防御性兜底，卡死的按钮随重开恢复）。

**抽屉呈现（pkg-6，解决槽位高度不足）**：
- 槽位内联容器高度有限（用户实测只能看到 add directory 行），故面板改为 `position: fixed; top: 46px; left: 12px` 的**向下弹出抽屉**：`width: min(360px, calc(100vw - 24px))`，`max-height: calc(100vh - 64px)` + `overflow-y: auto` 独立滚动，`@keyframes vws-drop` 下滑淡入动画，视觉上从侧边栏头部"落下"。
- 组件仍挂在 `directoryFlow` 槽内（open 时渲染、关闭返回 null），fixed 定位使其脱离槽位的溢出裁剪；显式 Cancel / 再点 ＋ 关闭。

**可拖动（pkg-9）**：抽屉标题栏为拖动手柄——`onPointerDown` 记录起点并经 `e.currentTarget.setPointerCapture(pointerId)` 捕获指针（元素级捕获，后续 move/up 全部派发到标题栏，**无需 window/document 监听**，符合动态插件约束）；标题栏内按钮 `stopPropagation` 保持点击；位置为组件内 state（`{x,y}`，初始 12/46），`Math.max(0,…)` 仅钳制左上角，无 viewport 尺寸钳制（无 window 访问）；关闭后重开回到默认位置；`cursor: grab/grabbing` + `user-select:none` + `touch-action:none`。

### 2.8 国际化设计（pkg-7）

- **字典**：`src/client.js` 内两个常量表 `VWS_EN` / `VWS_ZH`（25 个键，命名空间 `vws`），通过 `locale.register('vws', 'en'|'zh', dict)` 注册进平台（注册失败仅记录日志，不阻断插件）。
- **选择规则（严格满足"不支持的语言默认英文"）**：不依赖平台回落链（平台未知语言回落 zh），而是显式读取 `locale.getLocale().active`：`active === 'zh'` → `VWS_ZH`，**其余一律 `VWS_EN`**；键缺失回落到英文再回落到键名本身。
- **响应式**：`t` 函数每次渲染时读取当前快照；另经 `locale.subscribe` 在语言切换时强制重渲染（`forceRender` 计数钩子）。
- **locale 服务缺失**：`t` 降级为英文表查找（面板仍可用）。
- **不做翻译的部分**：Host 侧工具 schema/描述/业务错误（模型面向，与平台一致）；工作区名、目录路径等用户数据；标题 `工作区名 · 目录名` 结构。

**跨会话作用域结论（回答用户"每个目录下的会话能否跨工作区工作"）**：
- 动态插件 Host 半挂在**根上下文**的 `cordis-dynamic` 分组（`rootCtx.plugin(...)`），无会话作用域标签（`scopeOf` = undefined）→ 其注册的工具（`vws`）与系统提示段（`tool:vws`）为**全局**：任何目录下新建会话的 agent 均可见、可调用。
- 读取：任何会话读任何目录不受限（沙箱只拦写入）。
- 写入：受各自会话 cwd 边界约束；跨成员目录写入被拒后走一次性审批升级（与内置工具一致）。
- 局限：DSH 进程重启后动态插件停止，其他会话随之失去 `vws` 工具/提示，直至重新激活；要永久全局可用需固化进 host composition（演进路线 4）。

## 3. 数据模型

### 3.1 内存态

```js
state.workspaces = {
  '<name>': {
    dirs: [ { path: '<canonical absolute path>', label: string | null } ]
  }
}
```

- 名称规则：`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`。
- 目录在 add 时经 `fs.resolve` + `fs.stat` 校验（必须存在且为 directory），存储 `fs.processPath` 的规范化绝对路径；同一工作区内按路径去重。

### 3.2 持久化

文件：`<sandboxPolicy.workspaceRoot>\.vws-workspaces.json`（当前部署为 `C:\Users\Kevin Wen\.vws-workspaces.json`）。

```json
{
  "version": 2,
  "workspaces": {
    "EDB": {
      "mirror": true,
      "dirs": [
        { "path": "D:\\workspace\\external-demo-berry", "label": null },
        { "path": "D:\\workspace\\spring-cloud-cms-demo", "label": null },
        { "path": "D:\\workspace\\internal-demo", "label": null }
      ]
    }
  },
  "mirror": {
    "EDB": {
      "D:\\workspace\\external-demo-berry": { "id": "<registry workspace id>", "preexisting": false }
    }
  }
}
```

- 写入：整文件原子替换（`fs.writeText`），last-writer-wins；写失败返回 `saved:false` 并记录日志，内存态保持。
- 读取：启动时异步加载，缺失/损坏 → 空状态 + `loadError`。
- 选择部署级回退根而非会话工作区的原因：跨会话稳定、始终可写（该根在 workspace-write 的允许列表内）。

## 4. 路径语义（虚拟路径解析）

```
解析优先级：
1. 绝对路径（/^[A-Za-z]:[\\/]/、UNC、POSIX '/'）→ 直接使用；
2. 'name:/rel'：':' 前匹配已存在的工作区名 → 虚拟路径；
3. 无前缀时：显式 workspace 参数 → 该工作区；否则唯一工作区隐式命中；
4. 都不满足 → 报错（提示用 vws list 查看）。
```

操作语义：

| 操作 | 多目录命中规则 |
| --- | --- |
| read / write / edit | 文件：第一个存在的命中；多个目录同时存在同一文件 → 报错要求绝对路径 |
| ls / find / grep | 目录：所有命中目录的并集（find/grep 按绝对路径去重） |
| resolve | 返回每个目录的候选 + 存在性 + first（首个存在者） |

## 5. 安全与沙箱设计

### 5.1 事实基础（来自平台实现）

- fs 沙箱后端**只拦截写入/编辑，不拦截读取**（读任何目录均允许）。
- `writeText/editText(target, …, sandboxPolicy?)`：省略策略时后端使用自身默认（无会话上下文的插件调用会回退到部署级回退根）；传入策略时按策略围栏。
- 工具层的正确做法（`dsh-tool-fs` 同款）：**始终**将 `sandboxPolicy.resolve({ session: exec.agent.session })` 的结果盖上每次写入。

### 5.2 写入策略流程（pkg-2 起生效，pkg-3 沿用）

```
write/edit 调用
 ├─ 校验升级参数配对（sandbox_permissions ⇔ justification，非空）
 ├─ 无 sandboxPolicy 服务（未挂沙箱后端）→ 不传策略（后端不围栏）
 ├─ 有：standing = sandboxPolicy.resolve({ session: agent.session })
 │   ├─ 未请求升级 → 直接以 standing 写入
 │   └─ 请求升级：
 │       ├─ 校验严格更宽阶梯：read-only → workspace-write | danger-full-access；
 │       │                   workspace-write → danger-full-access
 │       ├─ approval.request({agent, toolName:'vws', callId, reason, signal})
 │       ├─ allowed-once → 以 { mode: 升级模式, workspaceRoot } 写入
 │       └─ rejected/cancelled/unavailable → 失败关闭（不执行写入）
 └─ 写入被拒（FS_SANDBOX_DENIED）且未走升级 → 抛带标记的错误：
      [sandbox: file access denied under <mode> mode]
      [sandbox: escalation available — retry … sandbox_permissions + justification]
```

## 6. 错误处理与降级

| 场景 | 行为 |
| --- | --- |
| 状态文件缺失/损坏 | 空状态启动，UI 显示 `loadError` |
| 持久化失败 | `saved:false`，控制台日志，内存态继续 |
| RPC 业务异常 | `{ ok:false, error }`，面板错误行展示 |
| 目录不存在/非目录 | add 被拒并给出具体目录 |
| 多目录同名文件写冲突 | 报错，要求绝对路径 |
| 非法名称/空目录列表 | 表单提交被 Host 校验拒绝 |

## 7. 主题与样式

- 面板使用系统无关的中性色（`rgba(128,128,128,.35)` 边框、继承色文字），明暗主题均可读；错误色固定 `#e5484d`。
- 按钮默认半透明，hover 全显；面板带阴影（`0 8px 24px rgba(0,0,0,.25)`）与圆角，形成浮层质感。
- 不覆盖全局主题 token（改动范围仅本包样式，符合平台约束）。

## 8. 演进路线

1. **pkg-3（已交付）**：overlay 按钮 + 面板，设置页下线。
2. **pkg-4（已交付）**：镜像注册进内置侧边栏（方案 B 落地，含所有权跟踪与开关）。
3. **pkg-5（已交付）**：撤销 dock，接管内置 ＋ 流程（双模式面板 + 原生目录选择 + 管理列表）。
4. 候选增强：面板拖拽与位置记忆、rail 状态感知、工作区重命名/排序、镜像条目排序控制。
5. 长期（composition 级）：在官方侧边栏组件中提供顶部可追加插槽，或为分组工作区提供原生支持；插件固化进 host composition 以脱离会话生命周期。
