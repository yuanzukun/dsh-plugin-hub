# 接口文档：dsh-virtual-workspace（虚拟工作区）

版本：1.1 ｜ 对应实现：`vws-1/pkg-5` ｜ 关联：02-design、03-development

> pkg-5 仅改动 Client（入口由 shell.overlay dock 改为接管 `sidebar.workspaces.directoryFlow`），
> Host 侧工具/服务/RPC/状态文件格式与 pkg-4 完全一致，本文档接口部分保持不变。

## 1. 模型可调用工具：`vws`

注册于 Host 工具注册表，名称 `vws`，输出 schema `{ type: 'json' }`，渲染为格式化的 JSON 文本。

### 1.1 参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `action` | string | ✅ | 见 1.2 动作表 |
| `workspace` | string | | 工作区名；`path` 无 `name:/` 前缀时必填 |
| `path` | string | | 绝对路径，或虚拟路径 `工作区:/相对路径` |
| `dirs` | json | | add/add-dir：路径数组，或 `{path,label}` 对象数组 |
| `mirror` | boolean | | add：是否镜像成员目录到内置侧边栏（默认 true） |
| `enabled` | boolean | | set-mirror：true 注册 / false 清理自建条目 |
| `content` | string | | write 的完整文件内容 |
| `old_string` / `new_string` | string | | edit 的字面替换对 |
| `replace_all` | boolean | | edit 全量替换（默认 false） |
| `pattern` | string | | find：glob（默认 `**/*`）；grep：正则 |
| `include` | string | | grep 文件名 glob 过滤（默认 `*`） |
| `offset` / `limit` | number | | read 起始行（1 起）/上限（默认 2000） |
| `maxDepth` | number | | find/grep 递归深度（默认 8） |
| `skip` | json | | find/grep 跳过的目录名（默认 `[".git","node_modules"]`） |
| `sandbox_permissions` | string | | 写升级：`workspace-write` \| `danger-full-access`，与 justification 成对 |
| `justification` | string | | 升级理由（一句） |

### 1.2 动作（action）

| action | 输入 | 输出要点 | 多目录语义 |
| --- | --- | --- | --- |
| `list` | — | `{ workspaces, root, mode, stateFile, loadError }` | — |
| `add` | workspace + dirs | `{ name, dirs, saved }` | 同名=替换；目录去重 |
| `remove` | workspace | `{ removed, saved }` | — |
| `add-dir` | workspace + dirs\|path | `{ name, added, saved }` | 已存在则跳过 |
| `remove-dir` | workspace + path（绝对） | `{ name, removed, saved }` | 规范路径比对 |
| `set-mirror` | workspace + enabled（boolean） | `{ name, mirror, mirrorIds, mirrorErrors, saved }` | true 注册内置侧边栏条目；false 仅移除本插件创建的条目 |
| `resolve` | path | `{ spec, mapped[], first }`；mapped: `{dir,absolute,exists,type}` | 列出每个目录候选 |
| `read` | path | `{ path, offset, limit, totalLines, truncated, lines[] }` | 首个存在的文件 |
| `write` | path + content | `{ path, written }` | 多目录同名报错 |
| `edit` | path + old/new | `{ path, replaced }` | 同上 |
| `ls` | path | `{ path, entries[], truncated }`；空 rel = 列出目录本身 | 所有命中目录并集 |
| `find` | path + pattern | `{ pattern, matches[], truncated, searched }` | 并集、绝对路径去重 |
| `grep` | path + pattern | `{ pattern, include, matches[{file,line,text}], filesScanned, truncated }` | 同上 |

### 1.3 调用示例

```jsonc
// 添加工作区
{ "action": "add", "workspace": "EDB", "dirs": [
  "D:\\workspace\\external-demo-berry",
  { "path": "D:\\workspace\\spring-cloud-cms-demo", "label": "cms" } ] }

// 跨目录读文件
{ "action": "read", "path": "EDB:/src/main/java/com/demo/App.java", "limit": 50 }

// 跨目录搜代码
{ "action": "grep", "path": "EDB:/src", "pattern": "@RestController", "include": "*.java" }

// 工作区内写文件
{ "action": "write", "path": "EDB:/.notes/todo.txt", "content": "…" }

// 工作区外写（需审批升级，一次一授权）
{ "action": "write", "path": "D:\\outside\\x.txt", "content": "…",
  "sandbox_permissions": "danger-full-access", "justification": "用户要求把生成物写到该目录" }
```

## 2. 虚拟路径语法

| 形式 | 解析 |
| --- | --- |
| `D:\a\b` / `D:/a/b` / `\\host\share` / `/posix` | 绝对路径，直接使用 |
| `name:/sub/path` | 工作区 `name` 的虚拟路径（前导 `/` 或 `\` 可省略） |
| `name:` | 工作区根（目录列表） |
| 无前缀 + `workspace` 参数 | 使用该工作区 |
| 无前缀且仅一个工作区 | 隐式命中该工作区 |
| 其他 | 报错 `vws: path must be absolute or "workspace:/relative/path"` |

## 3. Host 服务：`vws`（ctx.provide）

供其他插件组合使用：

| 方法 | 签名 | 说明 |
| --- | --- | --- |
| `list()` | `→ [{name, dirs:[{path,label}]}]` | 全部工作区 |
| `get(name)` | `→ {name, dirs} \| undefined` | 单个查询 |
| `resolve(name, rel)` | `→ [{absolute, exists, type}] \| undefined` | 候选解析 |
| `add(name, dirs)` | 同工具 add | 创建/替换 |
| `remove(name)` | 同工具 remove | 移除 |
| `addDir(name, dirs)` / `removeDir(name, path)` | 同工具对应动作 | 目录管理 |

## 4. RPC 接口（Client → Host，包私有）

Client 通过 `host.call(method, args)` 调用；全部返回 `{ ok: true, ...数据 }` 或 `{ ok: false, error }`。

| method | args | 成功返回（ok:true 附加字段） |
| --- | --- | --- |
| `vws.state` | — | `workspaces, root, mode, stateFile, loadError` |
| `vws.add` | `{name, dirs}` | `name, dirs, saved` |
| `vws.remove` | `{name}` | `removed, saved` |
| `vws.add-dir` | `{name, dirs\|path}` | `name, added, saved` |
| `vws.remove-dir` | `{name, path}` | `name, removed, saved` |
| `vws.set-mirror` | `{name, enabled}` | `name, mirror, mirrorIds, mirrorErrors, saved` |

## 5. 状态文件格式

路径：`<sandboxPolicy.workspaceRoot>\.vws-workspaces.json`；UTF-8，整文件原子替换。

```json
{
  "version": 2,
  "workspaces": {
    "<name>": {
      "mirror": true,
      "dirs": [ { "path": "<canonical absolute path>", "label": "<string|null>" } ]
    }
  },
  "mirror": {
    "<name>": {
      "<dir path>": { "id": "<registry workspace id>", "preexisting": false }
    }
  }
}
```

- 名称规则：`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`。
- 加载容错：非法名称/结构跳过；整体损坏 → 空状态 + `loadError`；旧版（v1，无 mirror 字段）自动按 `mirror: true` 兼容。

## 6. 错误码与消息

| 场景 | 错误（throw，模型可见） |
| --- | --- |
| 非法名称 | `vws: invalid workspace name "…": use 1-64 letters, digits, ".", "_", "-"` |
| 目录不存在 / 非目录 | `vws: directory not found: …` / `vws: not a directory: …` |
| 未知工作区 | `vws: unknown workspace "…"` |
| 路径不可解析 | `vws: path must be absolute or "workspace:/relative/path"…` |
| 文件不存在 / 是目录 | `vws: path not found: …` / `vws: "…" is a directory, not a file` |
| 多目录同名冲突 | `vws: "…" exists in multiple mapped directories; use an absolute path to pick one` |
| set-mirror 缺 enabled | `vws: set-mirror requires a boolean enabled` |
| 镜像不可用 | `vws: workspaceRegistry is not composed; mirroring is unavailable`（add 时不阻断，回落到 `mirrorErrors`/`registryAvailable:false`） |
| edit 无匹配 / 多匹配 | `vws: old_string not found in …` / `vws: old_string occurs N times; set replace_all=true…` |
| 沙箱拒绝（可升级） | `[sandbox: file access denied under <mode> mode] … [sandbox: escalation available — retry …]` |
| 升级参数不成对 | `vws: invalid escalation: sandbox_permissions requires a justification`（反向同理） |
| 升级非严格更宽 | `vws: sandbox escalation to "…" is not strictly wider than the current "…" mode` |
| 无审批服务/无 agent | `vws: sandbox escalation … requires approval, but no approval service is composed / the call has no agent to route it through` |
| 审批结果 | `the user rejected escalating this operation to "…"` / `approval … was cancelled` / `no approval channel is available` |

## 7. 系统提示注入

段名 `tool:vws`，order 125，仅在有工作区时输出：

```
## Virtual workspaces (tool: vws)
Virtual workspaces map short names to one or more project directories; use the `vws` tool with paths like `name:/sub/path` (read/write/edit/ls/find/grep), and `vws resolve` to map virtual paths to absolute ones.
- EDB: D:\workspace\external-demo-berry ; D:\workspace\spring-cloud-cms-demo ; D:\workspace\internal-demo
```
