# 测试文档：dsh-virtual-workspace（虚拟工作区）

版本：1.0 ｜ 关联：01-requirements、02-design

## 1. 已完成测试记录

### 1.1 pkg-1 冒烟（通过）

| 用例 | 步骤 | 结果 |
| --- | --- | --- |
| T-01 列表 | `vws list`（空态） | ✅ 返回空 workspaces + root/mode/stateFile/loadError |
| T-02 添加 | `vws add demo + 2 目录` | ✅ 目录规范化、saved:true |
| T-03 ls 根 | `vws ls demo:/` | ✅ 两个目录以条目列出 |
| T-04 resolve | `vws resolve demo:/node_modules/@deepseek-ai/dsh/package.json` | ✅ 两候选 + exists 标记 + first 命中 |
| T-05 read | 同路径 limit 8 | ✅ 行号切片正确 |
| T-06 find | `*.js`（skip=[]） | ✅ 命中与 searched 统计正确（limit=10 时正确截断） |
| T-07 grep | `defineTool` + include `*.js` | ✅ 文件/行号/文本正确 |
| T-08 写入（会话内，pkg-1） | `demo:/.vws-smoke.txt` | ⚠️ 被拒（缺陷：未带会话策略）→ 修复于 pkg-2 |
| T-09 写入（回退根内） | `C:\Users\Kevin Wen\.vws-smoke-home.txt` | ✅ 成功 |
| T-10 拒绝标记 | 同 T-08 | ✅ 出现 `[sandbox: file access denied …]` + 升级提示 |

### 1.2 pkg-2 冒烟（通过）

| 用例 | 步骤 | 结果 |
| --- | --- | --- |
| T-11 状态恢复 | update 后 `vws list` | ✅ demo 工作区从状态文件恢复（loadError:null） |
| T-12 会话内写入 | `demo:/.vws-smoke.txt` | ✅ 成功（会话边界 D:\workspace\dsh-workspace） |
| T-13 edit | old→new | ✅ replaced:1 |
| T-14 会话外拒绝 | 写检出目录 | ✅ 拒绝 + 标记 + 升级提示 |
| T-15 read 回读 | edit 后 read | ✅ 内容一致 |
| T-16 移除 | `vws remove demo` + 清文件 | ✅ saved:true，最终 list 为空 |

## 2. pkg-3/pkg-4 测试计划

### 2.0 原生入口集成（pkg-5）

| 用例 | 步骤 | 预期 |
| --- | --- | --- |
| F-01 无悬浮按钮 | 打开页面 | 左上角不再有 ＋ 悬浮按钮（shell.overlay 无 vws 占用） |
| F-02 接管内置 ＋ | 点击侧边栏头部内置 ＋ | 从头部**向下弹出抽屉面板**（固定定位、独立滚动、下滑动画；directoryFlow 槽显示 dyn/vws-1 为 active） |
| F-09 抽屉高度 | 多行目录 + 管理列表 | 抽屉内部滚动可见全部内容，不受槽位高度裁剪（pkg-6） |
| F-03 单目录原生 | Single directory → Choose folder | 系统目录对话框弹出；确认后官方流程创建普通工作区（onPicked） |
| F-04 多目录创建 | 填名称 + 2 行目录（手动或 Browse）→ Create | 虚拟工作区创建成功，流程关闭（onCancel），内置列表出现镜像条目 |
| F-05 目录行操作 | 增行/删行/Browse 回填 | 行状态正确；pick 取消不覆盖原值 |
| F-06 管理列表 | 面板下方 | 既有工作区可 Sidebar 开关/移除/目录 ×，操作后即时刷新 |
| F-07 hero 不受影响 | 空白页工作区选择器 | 仍为官方目录选择流（未被接管） |
| F-08 busy 状态 | 官方采纳路径期间 | 面板控件禁用 |
| F-10 取消系统弹窗不卡死 | 点 Browse → 关闭系统目录弹窗 | 抽屉可继续操作、可 Cancel；重开后 Browse 恢复可用（pkg-8，回归 bug） |
| F-11 拖动抽屉 | 按住标题栏拖动 → 释放 | 面板跟随指针移动；标题栏内 Cancel 仍可点击；拖到屏幕外左上角钳制在 0,0；重开回到默认位置（pkg-9） |

### 2.1 镜像注册（pkg-4，方案 A）

| 用例 | 步骤 | 预期 |
| --- | --- | --- |
| M-01 开启镜像 | `vws set-mirror EDB enabled:true` | 返回 mirrorIds（3 个目录 → 3 个注册 id）；内置侧边栏出现 `EDB · external-demo-berry` 等条目 |
| M-02 重复开启幂等 | 再次 set-mirror true | 不重复注册（沿用既有 id） |
| M-03 原有条目保护 | 某目录已在内置列表（preexisting） | 返回该目录映射为 `preexisting:true`，关闭镜像时不被删除 |
| M-04 关闭镜像 | set-mirror false | 自建条目从内置列表消失；preexisting 条目保留；状态文件 mirror 映射清空 |
| M-05 移除工作区清理 | remove EDB（镜像开） | 自建条目全部删除；状态文件无残留 |
| M-06 持久化 | 镜像后重启插件（run 重激活） | mirror 映射从状态文件恢复；不做自动复活 |
| M-07 注册表降级 | （模拟）registry 未挂载时 add | 工作区创建成功，`registryAvailable:false` + `mirrorErrors` |

### 2.1 UI 用例（人工）

| 用例 | 步骤 | 预期 |
| --- | --- | --- |
| U-01 按钮可见 | 打开页面，观察侧边栏左上角 | 半透明 ＋ 按钮，hover 全显，rail/wide 均可见 |
| U-02 打开面板 | 点击按钮 | 面板出现在按钮下方，列出 EDB 及 3 目录 |
| U-03 关闭面板 | 点击 × 或按钮 | 面板收起 |
| U-04 添加 | 填写 name + 3 行目录 → Add | 成功，列表即时刷新；状态文件更新；默认镜像开启 |
| U-05 校验 | 空名/非法名/不存在的目录 | 面板错误行提示，不落库 |
| U-06 移除工作区 | 卡片 Remove | 列表刷新，状态文件更新，自建镜像条目删除 |
| U-07 移除目录 | 目录行 × | 同上 |
| U-08 空态 | 移除全部后 | 显示空态文案 |
| U-09 设置页下线 | 打开设置面板 | 不再出现 Virtual Workspaces 页 |
| U-10 镜像开关 | 卡片 `Sidebar: on/off` | 内置列表条目对应出现/消失，面板状态即时刷新 |

### 2.2 自动化/模型侧回归（复用 1.1/1.2 用例）

- T-01…T-07、T-11…T-16 全部重跑（Host 未改动，预期行为不变）。

### 2.2 国际化（pkg-7）

| 用例 | 步骤 | 预期 |
| --- | --- | --- |
| I-01 zh 界面 | 设置 → 语言 = 中文；打开抽屉 | 全部文案简体中文（添加工作区/选择文件夹/创建虚拟工作区/移除…） |
| I-02 en 界面 | 语言 = English；打开抽屉 | 全部文案英文 |
| I-03 语言切换即时生效 | 抽屉打开时切换语言 | 文案即时重渲染，无需重开 |
| I-04 未知语言回退英文 | （模拟）active 非 zh | 显示英文（显式选择，不随平台 zh 回落链） |
| I-05 locale 服务缺失 | （模拟）无 locale 服务 | t 降级英文表，面板功能不受影响 |

### 2.3 沙箱用例

| 用例 | 步骤 | 预期 |
| --- | --- | --- |
| S-01 会话内写 | vws write → EDB 内某目录/会话工作区 | 成功 |
| S-02 会话外写 | vws write → 会话边界外 | 拒绝 + 标记 + 升级提示 |
| S-03 升级审批 | 重试 + sandbox_permissions=danger-full-access + justification | 弹出审批；同意后成功；拒绝后报错且不执行 |
| S-04 非更宽升级 | workspace-write 下请求 workspace-write | 报"not strictly wider"，不触发审批 |

### 2.4 恢复性用例

| 用例 | 步骤 | 预期 |
| --- | --- | --- |
| R-01 状态文件损坏 | 写入非法 JSON 后重启插件 | 空状态 + loadError 提示 |
| R-02 包更新 | pkg→pkg+1 update | 工作区定义保留 |

## 3. 回归清单（每次发布前）

1. `vws list` 正常；EDB（用户真实数据）无损。
2. 12 个 action 均可调用且返回 JSON。
3. 工具 schema 在 `Tool.listTools` 中可见。
4. `shell.overlay` 占用者为 vws-dock（`Slots.listSubTree` 查询）。
5. 系统提示段在下一轮出现（含 EDB 行）。
6. 状态文件可读、version=1。
7. 无 Host/Client 诊断错误（`cordis_inspect_self`）。

## 4. 已知限制（与验收口径对齐）

| 限制 | 说明 | 跟踪 |
| --- | --- | --- |
| L-01 | 虚拟工作区以"平铺目录条目"形式出现在内置列表（镜像），非单一分组条目 | pkg-4 已缓解；完全原生分组需 composition 级改造，见 02-design §2.6 |
| L-02 | ~~悬浮按钮与侧边栏标题重叠~~ | ✅ pkg-5 已撤销悬浮按钮，改为接管内置 ＋ 流程 |
| L-03 | 侧边栏内置 ＋ 的原生单目录浏览流被 VwsFlow 接管（面板内保留"单目录"等价路径） | hero 选择器不受影响；如需完整原生浏览流可后续在面板内嵌 listDirectory 浏览 |
| L-04 | 面板不可拖拽、无位置记忆 | 交互简化 | 候选增强 |
| L-05 | 动态插件进程内有效，重启需重新激活 | 平台机制 | README FAQ |
