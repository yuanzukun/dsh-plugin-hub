# 开发文档：dsh-virtual-workspace（虚拟工作区）

版本：1.0 ｜ 对应实现：`vws-1/pkg-3` ｜ 关联：01-requirements、02-design、04-api-reference、05-testing

## 1. 工程形态

本功能以**动态 Cordis 插件**实现（进程内、临时），不是静态包：

| 项 | 值 |
| --- | --- |
| pluginId | `vws-1`（Host 分配） |
| 当前包 | `pkg-3`（不可变；新版本只能追加，不能覆盖） |
| 版本指针 | `currentPackageId = pkg-3`（更新成功后） |
| 代码位置 | 包源码存于动态插件运行时（可用 `cordis_inspect_self(vws-1, pkg-3)` 查看） |
| 文档位置 | 本目录（`D:\workspace\dsh-workspace\dsh-virtual-workspace`） |

### 版本演进记录

| 包 | 变更 | 动机 |
| --- | --- | --- |
| pkg-1 | Host 全量能力 + 设置页 UI | 初始交付 |
| pkg-2 | 写入策略修复：始终带会话策略 | 与内置 fs 工具行为对齐 |
| pkg-3 | UI 改版：移除设置页；shell.overlay 侧边栏按钮 + 面板 | 用户反馈（可见性 + 入口位置） |

## 2. 开发环境与发布流程

```
1. cordis_inspect_list              # 刷新能力目录（服务/内置/插槽/主题/工具）
2. cordis_inspect_query …           # 查询将使用的精确契约
3. cordis_define(existing vws-1)    # 追加不可变包（返回新 packageId）
4. cordis_run(mode:'update')        # 切换版本（返回 awaiting-approval / starting）
5. （审批通过后）等待系统回报成功/失败
6. cordis_inspect_self(vws-1, pkg)  # 失败时读取精确诊断，修正后追加新包重试
```

- 回滚：`cordis_run(mode:'run', packageId: currentPackageId)`；
- 暂停：`cordis_stop`；删除：`cordis_undefine`（历史卡保留"已移除"记录）。

## 3. Host 代码结构（pkg-2/pkg-3 相同）

`code.host` 为纯 JS 函数体，`return { inject: ['fs'], apply(ctx) { … } }`。按职责分解：

| 模块 | 函数 | 说明 |
| --- | --- | --- |
| 启动加载 | `ready`（IIFE） | 异步读状态文件 → 校验 → 填充内存态；失败记 `loadError` |
| 路径工具 | `joinPath` / `isAbs` / `stripSlash` / `basename` | 无 node:path，纯字符串实现，统一 `/` 分隔 |
| 匹配工具 | `globToRegExp` / `matchesGlob` / `countOccurrences` | find/grep/edit 复用 |
| 状态 | `snapshot` / `persist` | 只读投影；整文件原子替换写入 |
| 变更 | `normalizeDirEntry` / `addWorkspace` / `removeWorkspace` / `addDirs` / `removeDir` | 全部"校验 → 变更 → persist" |
| 镜像（pkg-4） | `titleFor` / `ensureMirrorEntry` / `removeMirrorEntry` / `syncMirror` / `setMirror` | 注册表同步 + 所有权跟踪（`resolveByPath` 判 preexisting；只 delete 自建条目） |
| 路径解析 | `parseSpec` / `specLabel` / `candidatesOf` / `existing` | 虚拟路径 → 候选 FsTarget 列表 |
| 沙箱 | `resolveWritePolicy` / `mapWriteError` | 会话策略解析 + 升级审批 + 拒绝标记 |
| 动作 | `actionList/Read/Write/Edit/Ls/Find/Grep/Resolve` | 12 个 action 的 `execute` 分发体 |
| 工具注册 | `harness.defineTool` + `ctx.effect(() => harness.registerTool(ctx, tool))` | 工具随 Fiber 自动清理 |
| 提示注入 | `systemPrompt.section({ name:'tool:vws', order:125, text:()=>… })` | 空工作区返回 `''` |
| RPC | `rpc()` + 5 个 handler | `ctx.effect(() => harness.handle(...))` |
| 服务 | `ctx.provide('vws', {...})` | 供其他插件组合 |

### 关键实现要点

1. **`resolveWritePolicy`（pkg-2 修复核心）**：
   - 无升级参数 → 返回 `{ policy: standing, escalated: false }`，其中
     `standing = sandboxPolicy.resolve(exec.agent ? { session: exec.agent.session } : {})`；
   - 升级参数 → 校验配对与严格更宽阶梯（`WIDER` 表）→ `approval.request(...)` →
     `allowed-once` 时返回 `{ mode: 升级模式, workspaceRoot }`。
2. **`mapWriteError`**：`FS_SANDBOX_DENIED`（或文本含 file access denied）且未走升级时，抛带
   `[sandbox: …]` 标记与升级提示的错误，与内置工具词汇一致。
3. **`walk`（find/grep 共享）**：递归 listDir，深度/文件数双上限，`skipSet` 默认
   `['.git','node_modules']`，grep 跳过 >2MB 与读失败（二进制）文件。
4. **工具并发**：`isConcurrencySafe` 仅对只读 action 返回 true；写入/变更类排他。
5. **超时**：`timeoutMs: 120000`（find/grep 大目录兜底）。
6. **镜像（pkg-4）**：`ctx.get('workspaceRegistry')` 可选访问（判空）；`create(path, title)` 前先 `resolveByPath` 判是否原有；id 以 `String(id)` 持久化到状态文件；`delete` 失败仅记日志不阻断主流程；不在启动期对账（用户手动删除不复活）。

## 4. Client 代码结构（pkg-3 重写）

`code.client` 仅两件事：

```js
return {
  apply(ctx) {
    const slots = ctx.get('slots')
    if (slots === undefined) return
    ctx.effect(() => styles.insert(CSS))            // 包私有样式，随 Fiber 清理
    slots.inject('shell.overlay', () => slots.register(
      { name: 'shell.overlay', id: 'vws-dock', order: 0, label: 'Virtual Workspaces' },
      () => React.createElement(VwsDock, null),     // 组件在包代码内定义
    ))
  },
}
```

- **不再注册** `settings.section`（FR-5）；**不再注册** `shell.overlay`（pkg-5，FR-8）。
- **接管** `sidebar.workspaces.directoryFlow`（pkg-5）：`priority: -2`（动态默认，最低者渲染，遮蔽官方浏览流），
  `inject` 选项注入 `pickDirectory: () => ctx.get('workspaces').pickDirectory()`。
- `VwsFlow` 组件树（pkg-5）：
  - 属主 props：`{ open, busy, onPicked, onCancel, onError }`（`open` 为假时返回 null）；
  - 单目录区：`pickDirectory()` → `onPicked(path)`（官方创建普通工作区）；
  - 多目录区：名称 + 目录行数组（Browse 逐行 pick / 手动输入 / 增删行）+ Mirror 开关 → `vws.add` → `onCancel()`；
  - 管理区：既有虚拟工作区（Sidebar 开关 / Remove / 目录 ×）→ `vws.set-mirror|remove|remove-dir`。
- 数据流：`host.call('vws.state')` 在 `open` 变真时加载；每次变更成功后再次拉取刷新。
- 国际化（pkg-7）：字典常量 `VWS_EN`/`VWS_ZH`；`locale.register('vws', …)` 注册（effect 持有 disposer）；
  显式 `t = (key) => locale.getLocale().active === 'zh' ? ZH[key] ?? EN[key] ?? key : EN[key] ?? key`；
  `locale.subscribe` → `forceRender` 即时重渲染；locale 缺失时 t 降级英文表。
- 约束：无 JSX/TS/import；只用 `React.createElement/useState/useEffect`；
  不触碰 `document/window`；`onCancel()` 复用属主契约关闭流程（每次 open 恰好一个结果）。

## 5. 副作用生命周期清单

Host 与 Client 的所有贡献均挂在 Fiber 上（stop/update/undefine 自动清理）：

| 贡献 | 挂载方式 |
| --- | --- |
| 工具注册 | `ctx.effect(() => harness.registerTool(ctx, tool))` |
| RPC handler（5 个） | `ctx.effect(() => harness.handle(...))` |
| 提示段 | `ctx.effect(() => systemPrompt.section(...))` |
| Host 服务 `vws` | `ctx.effect(() => ctx.provide('vws', ...))` |
| Client 样式 | `ctx.effect(() => styles.insert(...))` |
| 插槽注册 | `slots.inject(...)`（回调内 register，随插槽声明延迟） |

## 6. 编码规范（本插件强制）

1. 纯 JavaScript；禁止 TypeScript 类型、`import/require`、JSX、装饰器。
2. Client 一律 `React.createElement`；Host 一律字符串拼接（模板串可用但少用）。
3. RPC 与工具参数/返回值必须 lossless JSON；**不序列化任何 live 对象**（FsTarget、
   Session、Service 等只取叶子字段）。
4. 服务访问：`inject: ['fs']` 声明硬依赖；`ctx.get('sandboxPolicy'|'systemPrompt'|'approval')`
   按可选处理（均判空）。
5. 错误信息统一 `vws: ` 前缀；沙箱拒绝使用平台统一标记词。
6. 每次定义新包后必须同步更新本文档与 README 的版本演进表。

## 7. 调试方法

| 手段 | 用途 |
| --- | --- |
| `cordis_inspect_self(vws-1, <pkg>)` | 读包源码 + Host/Client 诊断（state、provides、handlers、waitingFor） |
| `cordis_inspect_query(Tool.listTools)` | 确认 `vws` 工具注册与 schema |
| `cordis_inspect_query(Slots.listSubTree {root:'shell.overlay'})` | 确认面板条目与占用状态 |
| `vws list / read / …`（模型侧） | 行为验证 |
| Host `console.log/error`（包前缀） | 运行日志 |
| 状态文件直接读取 | 持久化验证 |

## 8. 常见失败与修复

| 症状 | 排查 |
| --- | --- |
| 服务未声明错误 | `ctx.x` 未注入 → 改 `ctx.get('x')` 或补 `inject` |
| Client 解析失败 | JSX/TS/import/未列出的全局 |
| 插槽注册失败 | 重新查询子树确认 name/kind/占用 |
| 写入被拒 | 检查目标是否在会话边界内；确认错误含升级提示 |
| update 失败 | `cordis_inspect_self` 读诊断 → 追加新包 → `update` 重试；或 `run` 当前包回滚 |
