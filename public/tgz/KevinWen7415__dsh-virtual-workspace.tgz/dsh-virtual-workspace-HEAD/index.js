// dsh-virtual-workspace — static Host plugin for the official bundle route
// (dsh plugin --profile <name> add github:KevinWen7415/dsh-virtual-workspace)
//
// This is the Host half of the virtual-workspace plugin as a regular Cordis
// plugin module (export name/inject/apply). It is a static port of the
// dynamic `code.host` in src/host.js: tool registration goes through the
// tools service + defineTool from @deepseek-ai/dsh-tools instead of the
// dynamic `harness` builtins; everything else (state, mirroring, sandbox
// escalation, prompt section) is unchanged.
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'dsh-virtual-workspace'
export const inject = ['fs', 'tools', 'timer']

export function apply(ctx) {
  const fs = ctx.fs
  const tools = ctx.tools
  const sandboxPolicy = ctx.get('sandboxPolicy')
  const systemPrompt = ctx.get('systemPrompt')
  // Lazily resolve services whose plugins activate asynchronously during boot
  // (workspaceRegistry waits for sessionPersistence + bootstrap; approval may
  // also register late). Reading them at call time — instead of caching at
  // apply time — is what makes the static bundle work on a fresh boot.
  const registry = () => ctx.get('workspaceRegistry')
  const approver = () => ctx.get('approval')

  // Same-origin HTTP routes for the static Client bundle: the browser cannot
  // use the dynamic harness.handle/host.call pairing, so the drawer UI talks
  // to these endpoints instead. webServer may register AFTER our apply during
  // boot, so ensureRoutes retries on a timer until the service appears; in
  // profiles without a web server it simply never registers (no client).
  let routesDisposer = null
  let routeTimer = null
  function ensureRoutes() {
    if (routesDisposer) {
      if (routeTimer) { routeTimer(); routeTimer = null }
      return
    }
    const webServer = ctx.get('webServer')
    if (!webServer) {
      if (!routeTimer) routeTimer = ctx.timeout(() => { routeTimer = null; ensureRoutes() }, 1000)
      return
    }
    routesDisposer = webServer.register({
      kind: 'prefix',
      path: '/api/vws',
      handler: async (req, res) => {
        try {
          const pathname = new URL(req.url ?? '/', 'http://x').pathname
          const action = pathname.slice('/api/vws'.length).replace(/^\/+/, '') || 'state'
          const chunks = []
          for await (const chunk of req) chunks.push(chunk)
          let args = {}
          if (chunks.length > 0) {
            try { args = JSON.parse(Buffer.concat(chunks).toString('utf8')) } catch (err) { args = {} }
          }
          const result = await runRpc(action, args)
          const payload = result && typeof result === 'object' ? Object.assign({ ok: true }, result) : { ok: true, result }
          const body = JSON.stringify(payload)
          res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
          res.end(body)
        } catch (err) {
          const body = JSON.stringify({ ok: false, error: String((err && err.message) || err) })
          res.writeHead(400, { 'content-type': 'application/json; charset=utf-8' })
          res.end(body)
        }
      },
    })
  }
  async function runRpc(action, args) {
    await ready
    switch (action) {
      case 'state': return snapshot()
      case 'add': return addWorkspace(args.name, args.dirs, args.mirror)
      case 'remove': return removeWorkspace(args.name)
      case 'add-dir': return addDirs(args.name, Array.isArray(args.dirs) ? args.dirs : (args.path ? [args.path] : []))
      case 'remove-dir': return removeDir(args.name, args.path)
      case 'set-mirror': return setMirror(args.name, args.enabled)
      default: throw new Error('vws: unknown rpc action "' + action + '"')
    }
  }

  const NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/
  const WIDER = { 'read-only': ['workspace-write', 'danger-full-access'], 'workspace-write': ['danger-full-access'] }

  const state = { workspaces: {}, mirror: {} }
  const statePath = sandboxPolicy ? joinPath(sandboxPolicy.workspaceRoot, '.vws-workspaces.json') : '.vws-workspaces.json'
  let stateTarget = null
  let loadError = null

  const ready = (async () => {
    try {
      stateTarget = await fs.resolve(statePath)
      const text = await fs.readText(stateTarget)
      const doc = JSON.parse(text)
      if (doc && typeof doc === 'object' && doc.workspaces && typeof doc.workspaces === 'object') {
        for (const name of Object.keys(doc.workspaces)) {
          const ws = doc.workspaces[name]
          if (!NAME_RE.test(name) || !ws || !Array.isArray(ws.dirs)) continue
          const dirs = []
          for (const d of ws.dirs) {
            if (d && typeof d.path === 'string' && d.path.length > 0) {
              dirs.push({ path: d.path, label: typeof d.label === 'string' && d.label.length > 0 ? d.label : null })
            }
          }
          if (dirs.length > 0) state.workspaces[name] = { dirs, mirror: ws.mirror !== false }
        }
      }
      if (doc && typeof doc === 'object' && doc.mirror && typeof doc.mirror === 'object') {
        for (const name of Object.keys(doc.mirror)) {
          const map = doc.mirror[name]
          if (!map || typeof map !== 'object') continue
          state.mirror[name] = {}
          for (const dirPath of Object.keys(map)) {
            const m = map[dirPath]
            if (m && typeof m.id === 'string') state.mirror[name][dirPath] = { id: m.id, preexisting: Boolean(m.preexisting) }
          }
        }
      }
    } catch (err) {
      loadError = String((err && err.message) || err)
    }
  })()

  function joinPath(base, rel) {
    const normBase = String(base == null ? '' : base).replace(/\\/g, '/')
    const normRel = String(rel == null ? '' : rel).replace(/\\/g, '/')
    const parts = normRel.split('/').filter((p) => p !== '' && p !== '.')
    let out = normBase.replace(/\/+$/, '')
    for (const p of parts) {
      if (p === '..') {
        const idx = out.lastIndexOf('/')
        out = idx < 0 ? '' : out.slice(0, idx)
        continue
      }
      out = out === '' ? p : out + '/' + p
    }
    if (/^[A-Za-z]:$/.test(out)) out = out + '/'
    return out === '' ? (normBase === '' ? '.' : normBase) : out
  }
  function isAbs(p) {
    const s = String(p == null ? '' : p)
    return /^[A-Za-z]:[\\/]/.test(s) || s.startsWith('\\\\') || s.startsWith('/')
  }
  function stripSlash(rel) {
    return String(rel == null ? '' : rel).replace(/^[\\/]+/, '')
  }
  function basename(p) {
    const s = String(p == null ? '' : p).replace(/[\\/]+$/, '')
    const idx = Math.max(s.lastIndexOf('/'), s.lastIndexOf('\\'))
    return idx < 0 ? s : s.slice(idx + 1)
  }
  function countOccurrences(text, needle) {
    let count = 0
    let idx = 0
    while ((idx = text.indexOf(needle, idx)) !== -1) {
      count += 1
      idx += needle.length
    }
    return count
  }
  function globToRegExp(pattern) {
    let re = ''
    for (let i = 0; i < pattern.length; i++) {
      const c = pattern.charAt(i)
      if (c === '*') {
        if (pattern.charAt(i + 1) === '*') { re += '.*'; i += 1 } else re += '[^/]*'
      } else if (c === '?') {
        re += '[^/]'
      } else if (c === '.') {
        re += '\\.'
      } else if ('+()^$|{}[]\\'.indexOf(c) >= 0) {
        re += '\\' + c
      } else {
        re += c
      }
    }
    return new RegExp('^' + re + '$')
  }
  function matchesGlob(pattern, relPath) {
    const re = globToRegExp(pattern)
    if (re.test(relPath)) return true
    if (pattern.indexOf('/') < 0) return re.test(relPath.split('/').pop() || '')
    return false
  }

  function mirrorIdsOf(wsName) {
    const map = state.mirror[wsName] || {}
    const out = {}
    for (const dirPath of Object.keys(map)) {
      out[dirPath] = { id: map[dirPath].id, preexisting: map[dirPath].preexisting }
    }
    return out
  }
  function snapshot() {
    return {
      workspaces: Object.keys(state.workspaces).sort().map((name) => ({
        name,
        dirs: state.workspaces[name].dirs.map((d) => ({ path: d.path, label: d.label || null })),
        mirror: state.workspaces[name].mirror !== false,
        mirrorIds: mirrorIdsOf(name),
      })),
      root: sandboxPolicy ? sandboxPolicy.workspaceRoot : null,
      mode: sandboxPolicy ? sandboxPolicy.resolve().mode : null,
      stateFile: stateTarget ? fs.processPath(stateTarget) : null,
      registryAvailable: Boolean(registry()),
      loadError,
    }
  }
  async function persist() {
    if (!stateTarget) return false
    try {
      const doc = { version: 2, workspaces: {}, mirror: {} }
      for (const name of Object.keys(state.workspaces)) {
        const ws = state.workspaces[name]
        doc.workspaces[name] = { mirror: ws.mirror, dirs: ws.dirs.map((d) => ({ path: d.path, label: d.label || undefined })) }
      }
      for (const name of Object.keys(state.mirror)) {
        const map = state.mirror[name]
        const out = {}
        for (const dirPath of Object.keys(map)) out[dirPath] = map[dirPath]
        if (Object.keys(out).length > 0) doc.mirror[name] = out
      }
      await fs.writeText(stateTarget, JSON.stringify(doc, null, 2) + '\n')
      return true
    } catch (err) {
      console.error('vws: persist failed:', err)
      return false
    }
  }

  async function normalizeDirEntry(raw) {
    const entry = typeof raw === 'string' ? { path: raw, label: null } : (raw && typeof raw.path === 'string' ? { path: raw.path, label: raw.label || null } : null)
    if (!entry) return null
    const target = await fs.resolve(entry.path)
    const info = await fs.stat(target)
    if (!info) throw new Error('vws: directory not found: ' + entry.path)
    if (info.type !== 'directory') throw new Error('vws: not a directory: ' + entry.path)
    return { path: fs.processPath(target), label: typeof entry.label === 'string' && entry.label.length > 0 ? entry.label : null }
  }
  function titleFor(wsName, dir) {
    return wsName + ' · ' + (dir.label || basename(dir.path))
  }
  async function ensureMirrorEntry(wsName, dir) {
    if (!state.mirror[wsName]) state.mirror[wsName] = {}
    const dirPath = dir.path
    if (state.mirror[wsName][dirPath]) return state.mirror[wsName][dirPath]
    const reg = registry()
    if (!reg) return { id: null, preexisting: false, unavailable: true }
    const existingWs = await reg.resolveByPath(dirPath)
    if (existingWs) {
      const rec = { id: String(existingWs.id), preexisting: true }
      state.mirror[wsName][dirPath] = rec
      return rec
    }
    const created = await reg.create(dirPath, titleFor(wsName, dir))
    const rec = { id: String(created.id), preexisting: false }
    state.mirror[wsName][dirPath] = rec
    return rec
  }
  async function removeMirrorEntry(wsName, dirPath) {
    if (!state.mirror[wsName]) return
    const rec = state.mirror[wsName][dirPath]
    if (!rec) return
    const reg = registry()
    if (!rec.preexisting && rec.id && reg) {
      try { await reg.delete(rec.id) } catch (err) { console.error('vws: mirror delete failed:', err) }
    }
    delete state.mirror[wsName][dirPath]
  }
  async function syncMirror(wsName) {
    const ws = state.workspaces[wsName]
    const errors = []
    for (const dir of ws.dirs) {
      try { await ensureMirrorEntry(wsName, dir) } catch (err) { errors.push({ path: dir.path, error: String((err && err.message) || err) }) }
    }
    return errors
  }
  async function addWorkspace(name, dirs, mirror) {
    const wsName = String(name == null ? '' : name)
    if (!NAME_RE.test(wsName)) throw new Error('vws: invalid workspace name "' + wsName + '": use 1-64 letters, digits, ".", "_", "-"')
    const list = []
    const seen = new Set()
    for (const raw of Array.isArray(dirs) ? dirs : []) {
      const entry = await normalizeDirEntry(raw)
      if (!entry) continue
      if (seen.has(entry.path)) continue
      seen.add(entry.path)
      list.push(entry)
    }
    if (list.length === 0) throw new Error('vws: add requires at least one existing directory')
    state.workspaces[wsName] = { dirs: list, mirror: mirror !== false }
    let mirrorErrors = []
    if (mirror !== false) mirrorErrors = await syncMirror(wsName)
    const saved = await persist()
    return { name: wsName, dirs: list.map((d) => ({ path: d.path, label: d.label })), mirror: state.workspaces[wsName].mirror, mirrorIds: mirrorIdsOf(wsName), mirrorErrors, saved }
  }
  async function removeWorkspace(name) {
    const wsName = String(name == null ? '' : name)
    const ws = state.workspaces[wsName]
    if (!ws) throw new Error('vws: unknown workspace "' + wsName + '"')
    for (const d of ws.dirs) await removeMirrorEntry(wsName, d.path)
    delete state.workspaces[wsName]
    delete state.mirror[wsName]
    const saved = await persist()
    return { removed: wsName, saved }
  }
  async function addDirs(name, dirs) {
    const wsName = String(name == null ? '' : name)
    const ws = state.workspaces[wsName]
    if (!ws) throw new Error('vws: unknown workspace "' + wsName + '"')
    const added = []
    for (const raw of Array.isArray(dirs) ? dirs : []) {
      const entry = await normalizeDirEntry(raw)
      if (!entry) continue
      const exists = ws.dirs.some((d) => d.path === entry.path)
      if (exists) continue
      ws.dirs.push(entry)
      added.push(entry)
    }
    let mirrorErrors = []
    if (ws.mirror !== false) {
      for (const entry of added) {
        try { await ensureMirrorEntry(wsName, entry) } catch (err) { mirrorErrors.push({ path: entry.path, error: String((err && err.message) || err) }) }
      }
    }
    const saved = await persist()
    return { name: wsName, added: added.map((d) => ({ path: d.path, label: d.label })), mirrorErrors, saved }
  }
  async function removeDir(name, path) {
    const wsName = String(name == null ? '' : name)
    const ws = state.workspaces[wsName]
    if (!ws) throw new Error('vws: unknown workspace "' + wsName + '"')
    const rawPath = String(path == null ? '' : path)
    if (!isAbs(rawPath)) throw new Error('vws: remove-dir requires an absolute directory path')
    const target = await fs.resolve(rawPath)
    const canonical = fs.processPath(target)
    const before = ws.dirs.length
    ws.dirs = ws.dirs.filter((d) => d.path !== canonical)
    await removeMirrorEntry(wsName, canonical)
    const saved = await persist()
    return { name: wsName, removed: before - ws.dirs.length, saved }
  }
  async function setMirror(name, enabled) {
    const wsName = String(name == null ? '' : name)
    const ws = state.workspaces[wsName]
    if (!ws) throw new Error('vws: unknown workspace "' + wsName + '"')
    if (typeof enabled !== 'boolean') throw new Error('vws: set-mirror requires a boolean enabled')
    if (!registry()) throw new Error('vws: workspaceRegistry is not composed; mirroring is unavailable')
    let mirrorErrors = []
    if (enabled) {
      mirrorErrors = await syncMirror(wsName)
      ws.mirror = true
    } else {
      for (const d of ws.dirs) await removeMirrorEntry(wsName, d.path)
      ws.mirror = false
    }
    const saved = await persist()
    return { name: wsName, mirror: ws.mirror, mirrorIds: mirrorIdsOf(wsName), mirrorErrors, saved }
  }

  function parseSpec(args) {
    const rawPath = String(args && args.path != null ? args.path : '')
    if (isAbs(rawPath)) return { kind: 'absolute', path: rawPath }
    let wsName = args && args.workspace != null ? String(args.workspace) : ''
    let rel = rawPath
    const ci = rel.indexOf(':')
    if (ci > 0) {
      const maybe = rel.slice(0, ci)
      if (state.workspaces[maybe]) { wsName = maybe; rel = rel.slice(ci + 1) }
    }
    if (!wsName) {
      const names = Object.keys(state.workspaces)
      if (names.length === 1) wsName = names[0]
      else if (rawPath === '') return { kind: 'all' }
      else throw new Error('vws: path must be absolute or "workspace:/relative/path"; use action=list to see workspaces')
    }
    const ws = state.workspaces[wsName]
    if (!ws) throw new Error('vws: unknown workspace "' + wsName + '"')
    return { kind: 'virtual', name: wsName, rel: stripSlash(rel), dirs: ws.dirs }
  }
  function specLabel(spec) {
    if (spec.kind === 'absolute') return spec.path
    return spec.name + ':/' + (spec.rel || '')
  }
  async function candidatesOf(spec, signal) {
    const out = []
    const opts = signal ? { signal } : undefined
    if (spec.kind === 'absolute') {
      const target = await fs.resolve(spec.path, opts)
      const info = await fs.stat(target, signal)
      out.push({ dir: null, rel: null, target, info, absolute: fs.processPath(target) })
      return out
    }
    for (const dir of spec.dirs) {
      const target = await fs.resolve(joinPath(dir.path, spec.rel || ''), opts)
      const info = await fs.stat(target, signal)
      out.push({ dir: { path: dir.path, label: dir.label }, rel: spec.rel || '', target, info, absolute: fs.processPath(target) })
    }
    return out
  }
  function existing(cands) {
    return cands.filter((c) => c.info)
  }

  async function resolveWritePolicy(args, exec) {
    const requested = args.sandbox_permissions
    const justification = args.justification
    if (requested !== undefined && justification === undefined) throw new Error('vws: invalid escalation: sandbox_permissions requires a justification')
    if (justification !== undefined && requested === undefined) throw new Error('vws: invalid escalation: justification is only valid together with sandbox_permissions')
    if (justification !== undefined && String(justification).trim().length === 0) throw new Error('vws: invalid justification: expected a non-empty sentence')
    if (!sandboxPolicy) {
      if (requested !== undefined || justification !== undefined) throw new Error('vws: sandbox_permissions is not available in this composition (no sandboxing filesystem to escalate)')
      return { policy: undefined, escalated: false }
    }
    const standing = sandboxPolicy.resolve(exec && exec.agent ? { session: exec.agent.session } : {})
    if (requested === undefined) return { policy: standing, escalated: false }
    if (!(WIDER[standing.mode] || []).includes(requested)) throw new Error('vws: sandbox escalation to "' + requested + '" is not strictly wider than this call\'s current "' + standing.mode + '" mode')
    const approvalService = approver()
    if (!approvalService) throw new Error('vws: sandbox escalation to "' + requested + '" requires approval, but no approval service is composed')
    if (!exec || !exec.agent) throw new Error('vws: sandbox escalation to "' + requested + '" requires approval, but the call has no agent to route it through')
    const outcome = await approvalService.request({ agent: exec.agent, toolName: 'vws', callId: exec.callId, reason: 'escalate sandbox to ' + requested + ': ' + justification, signal: exec.signal })
    if (outcome === 'allowed-once') return { policy: { mode: requested, workspaceRoot: standing.workspaceRoot }, escalated: true }
    if (outcome === 'rejected') throw new Error('the user rejected escalating this operation to "' + requested + '"')
    if (outcome === 'cancelled') throw new Error('approval for escalating to "' + requested + '" was cancelled')
    throw new Error('vws: sandbox escalation to "' + requested + '" requires approval, but no approval channel is available')
  }
  function mapWriteError(err, policy, escalated) {
    if (err && !escalated && (err.code === 'FS_SANDBOX_DENIED' || /file access denied/i.test(String(err.message)))) {
      const mode = policy ? policy.mode : (sandboxPolicy ? sandboxPolicy.resolve().mode : 'workspace-write')
      throw new Error('[sandbox: file access denied under ' + mode + ' mode]\n' + String(err.message) + '\n[sandbox: escalation available — retry this exact operation once with sandbox_permissions (the narrowest wider mode that suffices) + justification; the approval prompt asks the user]')
    }
    throw err
  }

  async function actionRead(args, exec) {
    const spec = parseSpec(args)
    if (spec.kind === 'all') throw new Error('vws: read requires a path')
    const cands = existing(await candidatesOf(spec, exec.signal))
    if (cands.length === 0) throw new Error('vws: path not found: ' + specLabel(spec))
    let chosen = null
    for (const c of cands) if (c.info.type === 'file') { chosen = c; break }
    if (!chosen) throw new Error('vws: "' + specLabel(spec) + '" is a directory, not a file')
    const text = await fs.readText(chosen.target, exec.signal)
    const all = text.split('\n')
    const offset = Math.max(1, Math.floor(Number(args.offset) || 1))
    const limit = Math.max(1, Math.floor(Number(args.limit) || 2000))
    const lines = []
    const end = Math.min(all.length, offset - 1 + limit)
    for (let i = offset - 1; i < end; i++) lines.push({ n: i + 1, text: all[i] })
    return { path: chosen.absolute, offset, limit, totalLines: all.length, truncated: offset - 1 + limit < all.length, lines }
  }
  async function actionWrite(args, exec) {
    if (typeof args.content !== 'string') throw new Error('vws: write requires a content string')
    const spec = parseSpec(args)
    if (spec.kind === 'all') throw new Error('vws: write requires a path')
    const cands = await candidatesOf(spec, exec.signal)
    const files = cands.filter((c) => c.info && c.info.type === 'file')
    if (files.length > 1) throw new Error('vws: "' + specLabel(spec) + '" exists in multiple mapped directories; use an absolute path to pick one')
    const target = files.length === 1 ? files[0].target : cands[0].target
    const resolved = await resolveWritePolicy(args, exec)
    try {
      await fs.writeText(target, args.content, undefined, exec.signal, resolved.policy)
    } catch (err) {
      mapWriteError(err, resolved.policy, resolved.escalated)
    }
    return { path: fs.processPath(target), written: true }
  }
  async function actionEdit(args, exec) {
    if (typeof args.old_string !== 'string') throw new Error('vws: edit requires old_string')
    if (args.old_string.length === 0) throw new Error('vws: edit old_string must not be empty')
    if (typeof args.new_string !== 'string') throw new Error('vws: edit requires new_string')
    const spec = parseSpec(args)
    if (spec.kind === 'all') throw new Error('vws: edit requires a path')
    const cands = await candidatesOf(spec, exec.signal)
    const files = cands.filter((c) => c.info && c.info.type === 'file')
    if (files.length === 0) throw new Error('vws: file not found: ' + specLabel(spec))
    if (files.length > 1) throw new Error('vws: "' + specLabel(spec) + '" exists in multiple mapped directories; use an absolute path to pick one')
    const chosen = files[0]
    const text = await fs.readText(chosen.target, exec.signal)
    const count = countOccurrences(text, args.old_string)
    if (count === 0) throw new Error('vws: old_string not found in ' + chosen.absolute)
    if (count > 1 && !args.replace_all) throw new Error('vws: old_string occurs ' + count + ' times; set replace_all=true to replace all')
    const resolved = await resolveWritePolicy(args, exec)
    try {
      await fs.editText(chosen.target, { oldString: args.old_string, newString: args.new_string, replaceAll: Boolean(args.replace_all) }, undefined, exec.signal, resolved.policy)
    } catch (err) {
      mapWriteError(err, resolved.policy, resolved.escalated)
    }
    return { path: chosen.absolute, replaced: args.replace_all ? count : 1 }
  }
  async function actionLs(args, exec) {
    const spec = parseSpec(args)
    if (spec.kind === 'all') {
      return { root: true, entries: Object.keys(state.workspaces).sort().map((name) => ({ name, type: 'workspace', dir: state.workspaces[name].dirs.map((d) => d.path) })) }
    }
    if (spec.kind === 'virtual' && spec.rel === '') {
      return { path: specLabel(spec), entries: spec.dirs.map((d) => ({ name: d.label || basename(d.path), type: 'directory', dir: d.path })) }
    }
    const cands = existing(await candidatesOf(spec, exec.signal))
    const limit = Math.max(1, Math.floor(Number(args.limit) || 200))
    const merged = []
    const seen = new Set()
    let truncated = false
    for (const c of cands) {
      if (c.info.type !== 'directory') continue
      const entries = await fs.listDir(c.target, exec.signal)
      for (const e of entries) {
        if (merged.length >= limit) { truncated = true; break }
        if (seen.has(e.name)) continue
        seen.add(e.name)
        merged.push({ name: e.name, type: e.type, dir: c.dir ? c.dir.path : null })
      }
      if (truncated) break
    }
    if (merged.length === 0) throw new Error('vws: no directories found for: ' + specLabel(spec))
    return { path: specLabel(spec), entries: merged, truncated }
  }
  async function searchRoots(spec, exec) {
    if (spec.kind === 'absolute') {
      const cand = (await candidatesOf(spec, exec.signal))[0]
      if (!cand.info || cand.info.type !== 'directory') throw new Error('vws: not a directory: ' + spec.path)
      return [{ target: cand.target, dirLabel: null }]
    }
    const roots = []
    for (const dir of spec.dirs) {
      const target = await fs.resolve(joinPath(dir.path, spec.rel || ''), exec.signal ? { signal: exec.signal } : undefined)
      const info = await fs.stat(target, exec.signal)
      if (info && info.type === 'directory') roots.push({ target, dirLabel: dir.path })
    }
    if (roots.length === 0) throw new Error('vws: no matching directories for: ' + specLabel(spec))
    return roots
  }
  async function walk(target, baseRel, depth, maxDepth, skipSet, capState, onFile) {
    if (capState.stopped || depth > maxDepth) return
    let entries
    try { entries = await fs.listDir(target, capState.signal) } catch (err) { return }
    for (const entry of entries) {
      if (capState.stopped) return
      const relPath = baseRel === '' ? entry.name : baseRel + '/' + entry.name
      if (entry.type === 'directory') {
        if (skipSet.has(entry.name)) continue
        await walk(entry.target, relPath, depth + 1, maxDepth, skipSet, capState, onFile)
      } else if (entry.type === 'file') {
        capState.count += 1
        if (capState.count > capState.cap) { capState.stopped = true; capState.truncated = true; return }
        await onFile(relPath, entry)
      }
    }
  }
  async function actionFind(args, exec) {
    const spec = parseSpec(args)
    const pattern = String(args.pattern == null ? '**/*' : args.pattern)
    const maxDepth = Math.max(0, Math.floor(Number(args.maxDepth) || 8))
    const cap = Math.max(1, Math.floor(Number(args.limit) || 500))
    const skip = new Set(Array.isArray(args.skip) ? args.skip.map(String) : ['.git', 'node_modules'])
    const roots = await searchRoots(spec, exec)
    const matches = []
    const seen = new Set()
    const capState = { count: 0, cap, stopped: false, truncated: false, signal: exec.signal }
    for (const root of roots) {
      if (capState.stopped) break
      await walk(root.target, '', 0, maxDepth, skip, capState, async (relPath, entry) => {
        if (capState.stopped) return
        if (matchesGlob(pattern, relPath)) {
          const abs = fs.processPath(entry.target)
          if (!seen.has(abs)) { seen.add(abs); matches.push(abs) }
        }
      })
    }
    return { pattern, matches, truncated: capState.truncated, searched: capState.count }
  }
  async function actionGrep(args, exec) {
    const spec = parseSpec(args)
    const pattern = String(args.pattern == null ? '' : args.pattern)
    if (pattern.length === 0) throw new Error('vws: grep requires a regex pattern')
    let re
    try { re = new RegExp(pattern, 'g') } catch (err) { throw new Error('vws: invalid regex: ' + String(err.message)) }
    const include = String(args.include == null ? '*' : args.include)
    const maxDepth = Math.max(0, Math.floor(Number(args.maxDepth) || 8))
    const fileCap = Math.max(1, Math.floor(Number(args.limit) || 1000))
    const matchCap = 250
    const skip = new Set(Array.isArray(args.skip) ? args.skip.map(String) : ['.git', 'node_modules'])
    const roots = await searchRoots(spec, exec)
    const matches = []
    const seen = new Set()
    const includeRe = globToRegExp(include)
    const capState = { count: 0, cap: fileCap, stopped: false, truncated: false, signal: exec.signal }
    for (const root of roots) {
      if (capState.stopped) break
      await walk(root.target, '', 0, maxDepth, skip, capState, async (relPath, entry) => {
        if (capState.stopped) return
        const abs = fs.processPath(entry.target)
        if (seen.has(abs)) return
        if (!includeRe.test(relPath.split('/').pop() || '')) return
        if (typeof entry.size === 'number' && entry.size > 2000000) return
        let text
        try { text = await fs.readText(entry.target, exec.signal) } catch (err) { return }
        seen.add(abs)
        const lines = text.split('\n')
        for (let i = 0; i < lines.length; i++) {
          re.lastIndex = 0
          if (re.test(lines[i])) {
            matches.push({ file: abs, line: i + 1, text: lines[i] })
            if (matches.length >= matchCap) { capState.stopped = true; capState.truncated = true; return }
          }
        }
      })
    }
    return { pattern, include, matches, filesScanned: seen.size, truncated: capState.truncated }
  }
  async function actionResolve(args, exec) {
    const spec = parseSpec(args)
    if (spec.kind === 'all') {
      return { workspaces: snapshot().workspaces }
    }
    const cands = await candidatesOf(spec, exec.signal)
    const mapped = cands.map((c) => ({ dir: c.dir ? c.dir.path : null, absolute: c.absolute, exists: Boolean(c.info), type: c.info ? c.info.type : null }))
    let first = null
    for (const m of mapped) if (m.exists) { first = m; break }
    if (!first) first = mapped[0] || null
    return { spec: specLabel(spec), mapped, first }
  }

  async function execute(args, exec) {
    await ready
    const action = String((args && args.action) || '')
    switch (action) {
      case 'list': return snapshot()
      case 'add': return addWorkspace(args.workspace, args.dirs, args.mirror)
      case 'remove': return removeWorkspace(args.workspace)
      case 'add-dir': return addDirs(args.workspace, Array.isArray(args.dirs) ? args.dirs : (args.path ? [args.path] : []))
      case 'remove-dir': return removeDir(args.workspace, args.path)
      case 'set-mirror': return setMirror(args.workspace, args.enabled)
      case 'resolve': return actionResolve(args, exec)
      case 'read': return actionRead(args, exec)
      case 'write': return actionWrite(args, exec)
      case 'edit': return actionEdit(args, exec)
      case 'ls': return actionLs(args, exec)
      case 'find': return actionFind(args, exec)
      case 'grep': return actionGrep(args, exec)
      default: throw new Error('vws: unknown action "' + action + '"; use list/add/remove/add-dir/remove-dir/set-mirror/resolve/read/write/edit/ls/find/grep')
    }
  }

  const tool = defineTool({
    name: 'vws',
    description: 'Manage and use virtual workspaces: named groups of one or more real project directories that can be read and modified together, so code and files across multiple projects are reachable in one place. State is persisted in .vws-workspaces.json under the deployment workspace root. Workspaces can be mirrored into the built-in sidebar list (workspaceRegistry entries titled "<ws> · <dir>", default on; only entries created by this plugin are removed on cleanup). Actions: list (workspaces, mirror state, sandbox mode), add (create or replace; dirs array of paths or {path,label}; optional mirror=false), remove, add-dir, remove-dir, set-mirror (enabled boolean; creates or removes sidebar entries), resolve (map a virtual path to absolute paths), read (line-sliced with offset/limit; first existing file wins across mapped dirs), write (full replace), edit (old_string/new_string/replace_all), ls (union of matching directories), find (glob across mapped dirs, default "**/*"), grep (regex with include glob filter). Paths may be absolute, or virtual as "name:/sub/path". Directory operations union every mapped directory where the relative path exists. Reads are unrestricted; writes/edits run under the calling session\'s sandbox policy (its workspace boundary) and, when denied outside it, may be retried once with sandbox_permissions + justification, which asks the user for approval.',
    parameters: {
      action: { type: 'string', required: true, enum: ['list', 'add', 'remove', 'add-dir', 'remove-dir', 'set-mirror', 'resolve', 'read', 'write', 'edit', 'ls', 'find', 'grep'], description: 'Operation to run.' },
      workspace: { type: 'string', description: 'Virtual workspace name; required when path is workspace-relative without a "name:/" prefix.' },
      path: { type: 'string', description: 'Absolute path, or virtual path "workspace:/relative/path" resolved across every mapped directory.' },
      dirs: { type: 'json', description: 'For add/add-dir: array of directory paths, or objects { path, label }.' },
      mirror: { type: 'boolean', description: 'For add: mirror member directories into the built-in sidebar list (default true).' },
      enabled: { type: 'boolean', description: 'For set-mirror: true registers sidebar entries, false removes the ones this plugin created.' },
      content: { type: 'string', description: 'Full file content for write.' },
      old_string: { type: 'string', description: 'Literal text to replace for edit.' },
      new_string: { type: 'string', description: 'Replacement text for edit.' },
      replace_all: { type: 'boolean', description: 'Replace every occurrence for edit (default false).' },
      pattern: { type: 'string', description: 'Glob for find (default "**/*"); regex for grep.' },
      include: { type: 'string', description: 'Glob filter on file names for grep (default "*").' },
      offset: { type: 'number', description: 'First line for read (default 1).' },
      limit: { type: 'number', description: 'Cap: read lines (2000), ls entries (200), find files (500), grep files scanned (1000).' },
      maxDepth: { type: 'number', description: 'Recursion depth for find/grep (default 8).' },
      skip: { type: 'json', description: 'Directory names skipped by find/grep (default [".git", "node_modules"]).' },
      sandbox_permissions: { type: 'string', enum: ['workspace-write', 'danger-full-access'], description: 'One-shot escalation for write/edit denied by the session sandbox policy; requires justification and user approval.' },
      justification: { type: 'string', description: 'One sentence explaining why this write/edit needs the wider access.' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    execute,
    isConcurrencySafe(args) {
      const action = String((args && args.action) || '')
      return ['add', 'remove', 'add-dir', 'remove-dir', 'set-mirror', 'write', 'edit'].indexOf(action) < 0
    },
    timeoutMs: 120000,
  })
  ctx.effect(() => tools.register(tool))

  if (systemPrompt) {
    ctx.effect(() => systemPrompt.section({
      name: 'tool:vws',
      order: 125,
      text: () => {
        const names = Object.keys(state.workspaces).sort()
        if (names.length === 0) return ''
        const lines = ['## Virtual workspaces (tool: vws)', 'Virtual workspaces map short names to one or more project directories; use the `vws` tool with paths like `name:/sub/path` (read/write/edit/ls/find/grep), and `vws resolve` to map virtual paths to absolute ones.']
        for (const name of names) {
          lines.push('- ' + name + ': ' + state.workspaces[name].dirs.map((d) => d.path).join(' ; '))
        }
        return lines.join('\n')
      },
    }))
  }

  ctx.effect(() => ctx.provide('vws', {
    list: () => snapshot().workspaces,
    get: (name) => {
      const ws = state.workspaces[String(name)]
      if (!ws) return undefined
      return { name: String(name), dirs: ws.dirs.map((d) => ({ path: d.path, label: d.label })), mirror: ws.mirror !== false }
    },
    async resolve(name, rel) {
      const ws = state.workspaces[String(name)]
      if (!ws) return undefined
      const cands = await candidatesOf({ kind: 'virtual', name: String(name), rel: stripSlash(rel), dirs: ws.dirs })
      return cands.map((c) => ({ absolute: c.absolute, exists: Boolean(c.info), type: c.info ? c.info.type : null }))
    },
    add: addWorkspace,
    remove: removeWorkspace,
    addDir: addDirs,
    removeDir,
    setMirror,
  }))

  // Register the browser-facing routes; retries until webServer appears, and
  // the fiber owns both the retry timer and the route for cleanup.
  ensureRoutes()
  ctx.effect(() => () => {
    if (routeTimer) routeTimer()
    if (routesDisposer) routesDisposer()
  })
}
