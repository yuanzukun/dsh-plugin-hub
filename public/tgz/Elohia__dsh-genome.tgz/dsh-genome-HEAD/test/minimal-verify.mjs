// dsh-genome minimal-preset 兼容验收：shell 服务缺失时，genome 仍激活、install 优雅降级。
import { apply } from 'file:///D:/dsh/dsh-genome/lib/index.js'
import { readFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const DATA_DIR = path.join(os.homedir(), '.dsh', 'genome')
const routes = {}
const listeners = {}
const mockWebServer = { register(spec) { routes[spec.path] = spec.handler } }

// 关键：模拟 minimal preset —— 有 webServer，但没有 shell 服务
const ctx = {
  get(k) {
    if (k === 'webServer') return mockWebServer
    // shell 不返回 → 模拟 minimal preset 无 shell 服务
    return undefined
  },
  on(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn) },
}

let failures = 0
function assert(cond, label) {
  if (cond) console.log('  PASS', label); else { console.log('  FAIL', label); failures++ }
}

console.log('== minimal-preset 兼容验收（无 shell 服务）==')

// apply 不因 shell 缺失而崩溃（inject 里已无 shell 硬依赖）
apply(ctx)

// 数据层正常初始化
assert(listeners['tools/result'] !== undefined, 'tools/result 监听已注册（自动度量不依赖 shell）')
assert(routes['/plugins/genome/status'] !== undefined, 'status 路由已注册（不依赖 shell）')
assert(routes['/plugins/genome/search'] !== undefined, 'search 路由已注册（走 fetch，不依赖 shell）')

// 触发 status 路由，确认能正常响应（无需 shell）
async function call(method, pathname, body) {
  const req = {
    method, url: pathname,
    headers: { host: '127.0.0.1:3080' },
    on(ev, cb) { if (ev === 'data') { if (body) cb(Buffer.from(body)) } if (ev === 'end') cb() },
  }
  const res = { statusCode: 200, headers: {}, body: '', setHeader(k, v) { this.headers[k] = v }, end(s) { this.body = s } }
  await routes[pathname.split('?')[0]](req, res)
  return { code: res.statusCode, json: JSON.parse(res.body) }
}

const r = await call('GET', '/plugins/genome/status')
assert(r.code === 200 && r.json.ok === true, 'minimal 下 status 正常响应')

// install 在无 shell 时优雅降级（返回结构化错误，不崩溃）
const ri = await call('POST', '/plugins/genome/install', JSON.stringify({ spec: 'dsh-market', profile: 'web' }))
assert(ri.code === 200 && ri.json.ok === false && ri.json.error.includes('shell'), 'minimal 下 install 优雅降级（提示 shell 不可用）')

console.log('')
console.log(failures === 0 ? '✅ minimal 兼容全部通过' : `❌ ${failures} 项失败`)
process.exit(failures === 0 ? 0 : 1)