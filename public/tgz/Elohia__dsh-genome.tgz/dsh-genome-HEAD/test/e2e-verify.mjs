// dsh-genome 端到端离线验收：mock 请求/响应 + mock fetch/shell，验证 handler 真实响应。
import { apply } from 'file:///D:/dsh/dsh-genome/lib/index.js'
import { readFileSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const DATA_DIR = path.join(os.homedir(), '.dsh', 'genome')
const routes = {}
const mockWebServer = { register(spec) { routes[spec.path] = spec.handler } }

// mock fetch：返回 GitHub 风格 search 响应
const originalFetch = globalThis.fetch
globalThis.fetch = async (url) => ({
  ok: true,
  async json() {
    return {
      items: [
        { full_name: 'omdsh-dev/dsh-toolkit', stargazers_count: 17, language: 'TypeScript', description: 'DSH 零依赖工具包', html_url: 'https://github.com/omdsh-dev/dsh-toolkit' },
        { full_name: 'dsh-market/dsh-market', stargazers_count: 192, language: 'TypeScript', description: 'DSH 可视化插件市场', html_url: 'https://github.com/dsh-market/dsh-market' },
      ],
    }
  },
})

// mock shell：记录命令，install 返回成功
const shellCalls = []
const mockShell = {
  resolve(req) { shellCalls.push(req.command); return { ...req } },
  async run() { return { exitCode: 0, stdout: '+ dsh-market (npm)' } },
}

const listeners = {}
const ctx = {
  get(k) { if (k === 'webServer') return mockWebServer; if (k === 'shell') return mockShell; return undefined },
  on(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn) },
}
apply(ctx)

function mockReq(method, body, url = '/') {
  return {
    method,
    url,
    headers: { host: '127.0.0.1:3080' },
    on(ev, cb) { if (ev === 'data') { if (body) cb(Buffer.from(body)) } if (ev === 'end') cb() },
  }
}
function mockRes() {
  return { statusCode: 200, headers: {}, body: '', setHeader(k, v) { this.headers[k] = v }, end(s) { this.body = s } }
}
async function call(method, pathname, body) {
  const purePath = pathname.split('?')[0]
  const req = mockReq(method, body, pathname)
  const res = mockRes()
  await routes[purePath](req, res)
  return { code: res.statusCode, json: JSON.parse(res.body) }
}

let failures = 0
function assert(cond, label) {
  if (cond) console.log('  PASS', label); else { console.log('  FAIL', label); failures++ }
}

console.log('== dsh-genome 端到端验收 ==')

// 预置 toolkit + metrics（含 sick/weak 样本）
const registry = { skills: {}, mcps: {}, plugins: {}, toolkits: { demo: { version: '1.0', members: [] } } }
writeFileSync(path.join(DATA_DIR, 'registry.json'), JSON.stringify(registry, null, 2))
const metrics = {
  members: {
    healthy_tool: { usage_count: 10, error_count: 0, user_feedback_sum: 45 },
    sick_tool: { usage_count: 20, error_count: 8, user_feedback_sum: 60 },   // error_rate=0.40 > 0.10 → sick
    weak_tool: { usage_count: 5, error_count: 0, user_feedback_sum: 5 },      // feedback=1.0 < 3.0 → weak
  },
  model_buckets: {},
}
writeFileSync(path.join(DATA_DIR, 'metrics.json'), JSON.stringify(metrics, null, 2))

// ── P0 回归 ──
let r = await call('GET', '/plugins/genome/status')
assert(r.code === 200 && r.json.ok === true && r.json.counts.toolkits === 1, 'status 返回 200 且 toolkit=1')

r = await call('POST', '/plugins/genome/up', JSON.stringify({ name: 'demo' }))
assert(r.code === 200 && r.json.ok === true, 'up demo ok')
r = await call('POST', '/plugins/genome/down', JSON.stringify({ name: 'demo' }))
assert(r.code === 200 && r.json.ok === true, 'down demo ok')

// ── P1 商店桥：search（mock fetch）──
r = await call('GET', '/plugins/genome/search?q=vision')
assert(r.code === 200 && r.json.ok === true, 'search 返回 200 ok')
assert(Array.isArray(r.json.items) && r.json.items.length === 2, `search items = ${r.json.items.length}`)
assert(r.json.items[0].full_name === 'omdsh-dev/dsh-toolkit', 'search 首项 full_name 正确')
assert(r.json.items[1].stars === 192, 'search 第二项 stars=192')

// ── P1 商店桥：install（mock shell 成功）──
r = await call('POST', '/plugins/genome/install', JSON.stringify({ spec: 'dsh-market', profile: 'web' }))
assert(r.code === 200 && r.json.ok === true && r.json.name === 'dsh-market', 'install dsh-market ok')
assert(shellCalls.some(c => c.includes('--profile web add dsh-market')), 'install 命令含 --profile web add')
const regAfterInstall = JSON.parse(readFileSync(path.join(DATA_DIR, 'registry.json'), 'utf8'))
assert(regAfterInstall.plugins['dsh-market'] !== undefined, 'install 后 plugins 库吸收 dsh-market')

// install 命令注入防护
r = await call('POST', '/plugins/genome/install', JSON.stringify({ spec: 'evil; rm -rf /', profile: 'web' }))
assert(r.code === 200 && r.json.ok === false && r.json.error.includes('invalid spec'), 'install 拒绝命令注入 spec')

// ── P1 进化闭环：scan（Sick/Weak 判定）──
r = await call('GET', '/plugins/genome/scan')
assert(r.code === 200 && r.json.ok === true, 'scan 返回 200 ok')
const verdicts = Object.fromEntries(r.json.verdicts.map(v => [v.key, v.verdict]))
assert(verdicts.healthy_tool === 'healthy', 'healthy_tool → healthy')
assert(verdicts.sick_tool === 'sick', 'sick_tool → sick')
assert(verdicts.weak_tool === 'weak', 'weak_tool → weak')

// ── P1 进化闭环：select（决策落地）──
r = await call('POST', '/plugins/genome/select', JSON.stringify({ key: 'sick_tool', decision: 'promote', by: 'manual', reason: '修复后评估改善' }))
assert(r.code === 200 && r.json.ok === true && r.json.decision === 'promote', 'select promote ok')
r = await call('POST', '/plugins/genome/select', JSON.stringify({ key: 'weak_tool', decision: 'reject', by: 'auto', reason: '退化' }))
assert(r.code === 200 && r.json.decision === 'reject', 'select reject ok')

// ── P2 进化闭环：mutate（变异意图 + Fix 建议）──
r = await call('POST', '/plugins/genome/mutate', JSON.stringify({ key: 'sick_tool', by: 'manual' }))
assert(r.code === 200 && r.json.ok === true, 'mutate 返回 200 ok')
assert(r.json.proposal && r.json.proposal.key === 'sick_tool', 'mutate 提案 key 正确')
assert(r.json.proposal.direction === 'logic', 'sick → logic 修复方向')
assert(typeof r.json.proposal.fix === 'string' && r.json.proposal.fix.length > 0, 'mutate 含 Fix 建议文本')
assert(r.json.proposal.next.includes('cordis_define'), 'mutate 指引用 cordis_define 生成实验体')
r = await call('POST', '/plugins/genome/mutate', JSON.stringify({ key: 'weak_tool', direction: 'connection', by: 'manual' }))
assert(r.json.proposal.direction === 'connection', '指定 connection 方向生效')

// history 含 install/promote/reject/mutate
const history = readFileSync(path.join(DATA_DIR, 'history.md'), 'utf8')
assert(history.includes('install') && history.includes('promote') && history.includes('reject') && history.includes('mutate'), 'history 记录 install/promote/reject/mutate')

// 同源校验：无 origin 放行
r = await call('GET', '/plugins/genome/status')
assert(r.code === 200, '无 origin 放行')

// ── P2 自动度量：触发 tools/result 监听 ──
const metricListeners = listeners['tools/result'] || []
assert(metricListeners.length === 1, 'tools/result 监听已注册')
metricListeners.forEach((fn) => fn({ name: 'bash' }, { isError: false }))
metricListeners.forEach((fn) => fn({ name: 'bash' }, { isError: true }))
metricListeners.forEach((fn) => fn({ name: 'read' }, { isError: false }))
const metricsAfterAuto = JSON.parse(readFileSync(path.join(DATA_DIR, 'metrics.json'), 'utf8'))
assert(metricsAfterAuto.members.bash !== undefined && metricsAfterAuto.members.bash.usage_count === 2, '自动度量 bash usage=2')
assert(metricsAfterAuto.members.bash.error_count === 1, '自动度量 bash error=1')
assert(metricsAfterAuto.members.read !== undefined && metricsAfterAuto.members.read.usage_count === 1, '自动度量 read usage=1')

console.log('')
console.log(failures === 0 ? '✅ 端到端全部通过' : `❌ ${failures} 项失败`)
process.exit(failures === 0 ? 0 : 1)