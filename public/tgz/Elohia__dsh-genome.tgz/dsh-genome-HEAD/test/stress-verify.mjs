// dsh-genome 压力测试：并发度量写入 + search 限流 + 路由稳定性。
// 打运行中的 web（默认 3080，可用 GENOME_URL 覆盖）。
const BASE = process.env.GENOME_URL || 'http://127.0.0.1:3080'

async function post(path, body) {
  const r = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  })
  return r.json()
}
async function get(path) {
  const r = await fetch(BASE + path)
  return r.json()
}

let failures = 0
function assert(cond, label) {
  if (cond) console.log('  PASS', label); else { console.log('  FAIL', label); failures++ }
}
function reset() { }

console.log('== dsh-genome 压力测试 ==')
const t0 = Date.now()

// ── 1) 并发度量写入：100 个并发 record_metric，验证不丢计数 ──
{
  const before = await get('/plugins/genome/metrics')
  const beforeCount = (before.metrics && before.metrics.members && before.metrics.members.stress_tool && before.metrics.members.stress_tool.usage_count) || 0
  const N = 100
  const jobs = []
  for (let i = 0; i < N; i++) {
    jobs.push(post('/plugins/genome/record_metric', { tool: 'stress_tool', ok: i % 10 !== 0, ms: i }))
  }
  const results = await Promise.all(jobs)
  const allOk = results.every(r => r.ok === true)
  assert(allOk, `100 并发 record_metric 全部返回 ok`)

  const after = await get('/plugins/genome/metrics')
  const m = (after.metrics && after.metrics.members && after.metrics.members.stress_tool) || {}
  const usage = m.usage_count || 0
  const expected = beforeCount + N
  assert(usage === expected, `并发写入不丢计数：usage=${usage} === ${expected}（写前 ${beforeCount} + ${N}）`)
  const errors = m.error_count || 0
  assert(errors === 10, `错误计数正确：error=${errors} === 10（i%10===0 共 10 次失败）`)
}

// ── 2) search 限流：连发 15 次，观察 GitHub 未认证限流（10次/分钟）是否优雅降级 ──
{
  let okCount = 0, failCount = 0, firstErr = ''
  for (let i = 0; i < 15; i++) {
    const r = await get('/plugins/genome/search?q=vision')
    if (r.ok) okCount++; else { failCount++; if (!firstErr) firstErr = r.error }
  }
  console.log(`  INFO: search 15 连发 → ok=${okCount} 限流/失败=${failCount}${firstErr ? ' 首个错误=' + firstErr : ''}`)
  // 关键断言：限流时返回结构化错误而非崩溃/500
  assert(okCount + failCount === 15, 'search 15 次全部有响应（无崩溃）')
  assert(okCount > 0, `search 至少成功 ${okCount} 次`)
}

// ── 3) 并发读路由稳定性：status/registry/metrics 各 50 并发 ──
{
  const jobs = []
  for (let i = 0; i < 50; i++) {
    jobs.push(get('/plugins/genome/status'))
    jobs.push(get('/plugins/genome/registry'))
    jobs.push(get('/plugins/genome/metrics'))
  }
  const results = await Promise.all(jobs)
  const allOk = results.every(r => r && r.ok === true)
  assert(allOk, `150 并发读请求全部 ok`)
}

// ── 4) 数据文件健康：metrics.json 可解析、结构完整 ──
{
  const m = await get('/plugins/genome/metrics')
  assert(m.ok === true && m.metrics && m.metrics.members && m.metrics.model_buckets, 'metrics 结构完整可解析')
}

console.log('')
console.log(`耗时 ${Date.now() - t0}ms`)
console.log(failures === 0 ? '✅ 压力测试全部通过' : `❌ ${failures} 项失败`)
process.exit(failures === 0 ? 0 : 1)