// dsh-genome host 离线验收：mock ctx，验证 apply() 初始化数据 + 注册全部路由。
import { apply, name, inject } from 'file:///D:/dsh/dsh-genome/lib/index.js'
import { existsSync, readFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const DATA_DIR = path.join(os.homedir(), '.dsh', 'genome')
const registered = []

const mockWebServer = { register(spec) { registered.push(spec) } }
const mockShell = {
  resolve(req) { return { ...req } },
  async run() { return { exitCode: 0, stdout: '' } },
}
const listeners = {}
const ctx = {
  get(k) {
    if (k === 'webServer') return mockWebServer
    if (k === 'shell') return mockShell
    return undefined
  },
  on(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn) },
}

let failures = 0
function assert(cond, label) {
  if (cond) { console.log('  PASS', label) } else { console.log('  FAIL', label); failures++ }
}

console.log('== dsh-genome host 离线验收 ==')
assert(name === 'genome', `name = ${name}`)
assert(Array.isArray(inject) && inject.includes('webServer'), `inject = ${JSON.stringify(inject)}`)
assert(!inject.includes('shell'), 'shell 不再是硬依赖（minimal preset 兼容）')
assert(typeof apply === 'function', 'apply 是函数')

apply(ctx)

for (const f of ['registry.json', 'metrics.json', 'surface.json', 'history.md']) {
  assert(existsSync(path.join(DATA_DIR, f)), `数据文件 ${f} 已初始化`)
}

const paths = registered.map(r => `${r.kind}:${r.path}`)
const expected = [
  'exact:/plugins/genome/status',
  'exact:/plugins/genome/registry',
  'exact:/plugins/genome/metrics',
  'exact:/plugins/genome/history',
  'exact:/plugins/genome/up',
  'exact:/plugins/genome/down',
  'exact:/plugins/genome/rollback',
  'exact:/plugins/genome/record_metric',
  'exact:/plugins/genome/search',
  'exact:/plugins/genome/install',
  'exact:/plugins/genome/scan',
  'exact:/plugins/genome/select',
  'exact:/plugins/genome/mutate',
]
for (const p of expected) assert(paths.includes(p), `路由已注册 ${p}`)
assert(paths.length === expected.length, `路由总数 ${paths.length} === ${expected.length}`)

// 自动度量监听已注册
assert(Array.isArray(listeners['tools/result']) && listeners['tools/result'].length === 1, 'tools/result 监听已注册（自动度量）')

const surface = JSON.parse(readFileSync(path.join(DATA_DIR, 'surface.json'), 'utf8'))
assert(Array.isArray(surface.alwaysVisible) && surface.alwaysVisible.includes('read'), 'surface.alwaysVisible 含 read')
assert(surface.maxExpanded === 6, `surface.maxExpanded = ${surface.maxExpanded}`)

const registry = JSON.parse(readFileSync(path.join(DATA_DIR, 'registry.json'), 'utf8'))
assert(registry.skills !== undefined && registry.mcps !== undefined && registry.plugins !== undefined && registry.toolkits !== undefined, 'registry 四库字段齐全')

const metrics = JSON.parse(readFileSync(path.join(DATA_DIR, 'metrics.json'), 'utf8'))
assert(metrics.members !== undefined && metrics.model_buckets !== undefined, 'metrics 字段齐全')

console.log('')
console.log(failures === 0 ? '✅ 全部验收通过' : `❌ ${failures} 项失败`)
process.exit(failures === 0 ? 0 : 1)