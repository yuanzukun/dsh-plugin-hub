---
name: "genome"
description: "DSH 能力转化与组装引擎的方法论层（钱学森工程控制论/系统论框架）。管理 skill/MCP/plugin 三库，驱动负反馈进化闭环（生成动态实验体 → 评估 → 晋升/淘汰）。当用户想管理已装技能/工具/插件、想进化某个能力（'把 X 变好'）、查看进化树或回滚变更时调用。"
allowed-tools: [Read, Write, LS, Glob, RunCommand, Skill]
---

# Genome — 三库管理与进化循环（常驻层方法论）

## When to Use

- 用户要求"管理技能/工具/插件"（列出、启停、归档、回滚）。
- 用户要求"把某个能力变好 / 进化"（触发变异→评估→选择闭环）。
- 系统需要查看进化历史、工具面状态、度量数据。

## 核心心智模型（控制论）

```
基准（当前版本）──比较──▶ 误差 ──▶ 进化控制器（阈值/选择）──▶ 变异机构（动态实验体）
    ▲                                                            │
    └────────────── 反馈通路（metrics 写回）◀── 观测（评估）◀──────┘
稳定性规则：只有评估确认改善才晋升（更新基准）；恶化则回滚（基准不变）。
负反馈保证系统不发散；死区/幅值/回滚/停机条件保证渐进稳定。
```

## 命令族

### /genome scan — 观测与筛选（负反馈回路第 1 步）
1. 读取 `~/.dsh/genome/metrics.json`（经 `GET /plugins/genome/metrics` 或直接读文件）。
2. 判定规则（magi skill-optimizer 阈值移植）：
   - **Sick（病态）**：`error_count / usage_count > 10%`
   - **Weak（弱势）**：`user_feedback_sum / usage_count < 3.0`
3. 输出 TOON 表格：`name, usage, error_rate, feedback, verdict`。

### /genome mutate — 变异提案（第 2 步）
对标记 Sick/Weak 的对象生成三种修复方向：
- **Fix A（逻辑）**：修正 prompt / SKILL.md 中的逻辑漏洞或缺失步骤。
- **Fix B（约束）**：增加 JSON Schema / 边界条件 / 护栏。
- **Fix C（连接）**：增加与三库中其他 skill / MCP / 插件的交互接口。
若需要实验新版本 → 用 `cordis_define` 生成动态实验体（新 Package），
或在目标 skill 目录产出 patch 后经 Genome 面板登记。

### /genome select — 选择（第 3 步，人机结合）
- **Manual**（默认）：向用户展示变异方案与评估预期，由用户决定。
- **Auto**：仅当 `置信度 > 90%` 且变更只涉及 bug 修复类（Fix A/B 中的纯修复）时自动应用，并记录 history。
- 晋升 = 将动态实验体固化回静态（`POST /plugins/genome/up` 或落地为静态代码）；
- 淘汰 = `POST /plugins/genome/rollback` + 移除实验体。

### /genome rollback — 30s 防呆回滚（omni 语义）
`POST /plugins/genome/rollback { name }`；若 30s 内无新晋升操作则保持原状，记录进化树。

### /genome log — 进化树
读取 `~/.dsh/genome/history.md`（或 `GET /plugins/genome/history`），整理为时间线。

### /genome status — 常驻层总览
`GET /plugins/genome/status` → 三库计数、工具面（alwaysVisible/maxExpanded/active）、最近进化 8 条。

### /genome discover — 商店桥（发现 → 安装 → 吸收）
- 搜索：`GET /plugins/genome/search?q=<关键词>` → GitHub `dsh-plugin` topic 结果（star 排序）。
- 安装：`POST /plugins/genome/install { spec, profile }` → 复用官方 `dsh plugin add`（安装即吸收，审核由官方沙箱/审批边界内生）。
- 安装成功自动写入 `registry.plugins`；spec 支持 npm 名或 `github:owner/repo#ref`。

## 进化循环协议（一条完整回路）

1. **定目标（定性）**：用户/agent 明确"把 X 变好"；写出可测的改善标准。
2. **观测基线（定量）**：`/genome scan` 取当前 metrics；必要时先评估任务集取基线。
3. **变异（小步）**：单变量控制——一次只改一个对象；产出实验体或 patch 草案。
4. **评估**：在真实/样例任务上跑，取评估指标（完成率/步数/误用率/token），
   每任务 ≥3 次取中位数，按 model 分桶。
5. **选择**：改善 → 晋升并更新基准；恶化/持平 → 回滚。写入 `history.md`。
6. **稳态判定**：连续 N 轮无改善 → 停止进化，报告稳态，等新需求（防振荡）。

## 数据与稳定性原则

- 一切数据在 `~/.dsh/genome/`（registry.json / metrics.json / history.md / surface.json），人可读可 grep。
- 只改一个变量；工具面受 `maxExpanded` 上限约束；30s 回滚兜底；
  auto 晋级仅限 bug 修复类；用户在 Manual 模式下始终可 veto（从定性到定量综合集成）。
- 输出尽量用 TOON（紧凑表格），省 token。

## <reflection>

回路结束后自检：本次变异是真改善还是噪声？（评估次数是否 ≥3、模型是否一致、阈值判定是否可靠。）
必要时更新 `history.md` 结论并在 metrics 中留痕。