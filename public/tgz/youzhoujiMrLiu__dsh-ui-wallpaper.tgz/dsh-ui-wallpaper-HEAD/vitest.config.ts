import { defineConfig } from 'vitest/config'
import { fileURLToPath } from 'node:url'

export default defineConfig({
  test: {
    environment: 'node',
    setupFiles: ['./tests/support/loader-shim.ts'],
    server: {
      deps: {
        // primitives carries a raw katex CSS import; it must go through vite's
        // transform pipeline (which stubs CSS) instead of Node's native loader.
        // test-runtime imports the runtime/client loader bundle and must go
        // through vite too, or Node resolves the real bundle file with no
        // named exports.
        inline: ['@deepseek-ai/dsh-client-ui-primitives', '@deepseek-ai/dsh-client-test-runtime'],
      },
    },
    alias: {
      '@deepseek-ai/dsh-client-runtime/client': fileURLToPath(new URL('./tests/support/aliases/runtime-client.ts', import.meta.url)),
      '@deepseek-ai/dsh-client-locale/client': fileURLToPath(new URL('./tests/support/aliases/locale-client.ts', import.meta.url)),
      '@deepseek-ai/dsh-client-ui-theme/client': fileURLToPath(new URL('./tests/support/aliases/theme-client.ts', import.meta.url)),
    },
  },
})
