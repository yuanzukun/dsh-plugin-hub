# dsh-ui-wallpaper

[English](README.md) | 中文

DeepSeek Harness Web GUI 的壁纸插件，仿照 Wallpaper Engine：把任意本地图片、GIF 或视频设为自己的自定义背景，应用表面转为半透明让壁纸透出，并在设置中提供「壁纸」页面用于选择、预览与管理。

## 效果图

![设置界面](screenshots/settings.jpg)

![壁纸效果](screenshots/wallpaper.jpg)

皮肤由本包拥有的三个独立贡献组成：

- **Token 叠加层** — `ctx.theme.overrideTokens()` 为 `--dsw-alias-bg-base` 与 `--dsw-specific-sidebar-fill` 在深浅两套色板各叠加 60% 半透明混合。折叠按 token、按色彩模式进行，用户的深浅色偏好不受影响；卸载插件即恢复原始不透明 token。
- **背景层** — `shell.overlay` 注册项把固定、点击穿透的媒体面通过 portal 挂到 `document.body` 并使用负 z-index，因此应用内容绘制在其上，而半透明列 token 让媒体透出。图片与 GIF 支持平铺、填充、适应、拉伸；视频支持填充、适应、拉伸（平铺回退为填充）。整个媒体面统一施加 CSS `brightness()` 滤镜实现 20%–200% 亮度调节，对图片、GIF、视频与平铺背景同样生效。
- **Host 路由** — `POST /dsh-wallpaper/media` 将所选文件原子替换存储到 `$DSH_HOME/wallpaper`，`GET /dsh-wallpaper/media` 以 nosniff 内容类型回读。路由位于浏览器信任栅栏之后（loopback 加 `trustedHosts` 配置）；接受的格式即 `src/model/wallpaper.ts` 里的共享 MIME 白名单。

设置页包含实时预览、四种显示方式、亮度滑块（20%–200%，实时作用于预览与背景）与本地文件选择（`image/*` 加 mp4/webm/ogg 视频）以及关闭/恢复默认操作。持久化偏好是 `dsh.wallpaper` store；只保存 URL、显示方式与亮度倍率，因此媒体字节落在磁盘而不是 localStorage。默认壁纸仍是 `/eva.jpg`（外壳静态资源 `apps/web/public/eva.jpg`），使用填充方式。亮度功能上线前持久化的偏好没有亮度字段，读取时按 100% 显示（观感不变），首次调整后该字段即随偏好持久化。

两个布局配合项保证染色只有一层：AppFrame 不画背景（body 拥有底色）、SidebarRoot 内容区画透明（布局列画填充色）。没有本皮肤时两者外观与原来完全一致；启用后壁纸从每一列单层透出，不会层层叠加变暗。

内容卡片、代码块、输入框等凸起表面保留自身填充，文字在媒体上仍然可读。

## 亮度控制

设置页提供 20%–200% 的亮度滑块，拖动时实时作用于预览与背景。实现上是对整个媒体面统一施加一个 CSS `brightness()` 滤镜：图片、GIF、视频与平铺背景共用同一条路径，动图与视频的播放完全不受影响，浏览器在 GPU 上合成也不增加渲染负担。亮度倍率与壁纸选择、显示方式一起持久化在 `dsh.wallpaper` store，重启后仍然生效；「重置亮度」按钮一键恢复 100%，「恢复默认」会把亮度与壁纸、显示方式一并还原。亮度功能上线前持久化的偏好没有亮度字段，读取时按 100% 显示（观感不变），首次调整后该字段即随偏好持久化。

## 播放速度

设置页提供 0.1×–5× 的播放速度控制，作用于 GIF 与视频：速度值可以直接输入，也可以用 ▲/▼ 按钮步进——1× 以下每按一次变化 0.1，1× 及以上每按一次变化 0.5。视频直接使用 `<video>` 的 `playbackRate`；GIF 没有浏览器原生变速能力，插件会把它逐帧解码后在 canvas 上按所选倍率重放，1× 时保持原生 `<img>` 渲染、零额外开销。速度倍率与壁纸选择、显示方式、亮度一起持久化在 `dsh.wallpaper` store，重启后仍然生效；「重置速度」一键恢复 1×。平铺模式下的 GIF 通过重复背景图渲染、没有逐帧路径，因此该模式下速度滑块会禁用并给出提示。变速重放需要在内存中逐帧解码，超大 GIF 会占用较多内存。

## 安装

本包是一个 dsh **bundle**：其 `dsh.bundle` 清单会把 `ui-wallpaper` 行插入任何列出该包的 profile，`dsh.client` 清单与 `lib/client.js` 携带 Web GUI 的浏览器半边。

最简单的安装方式是交给 agent 完成——DeepSeek Harness 本身，或任何能访问本仓库、且目标机器装有 `dsh` CLI 并有终端的 agent。把下面这段提示词粘贴给它：

```text
帮我安装 GitHub 上的 dsh-ui-wallpaper 插件（https://github.com/youzhoujiMrLiu/dsh-ui-wallpaper）。

1. 执行 `dsh plugin add github:youzhoujiMrLiu/dsh-ui-wallpaper`（针对特定 profile 加 `--profile <name>`）。
2. pnpm ≥10 首次会拒绝 git 依赖的构建脚本：把 pnpm 打印出的包键复制进该 profile 的 `pnpm-workspace.yaml` 的 `allowBuilds` 块，然后重新执行 add。
3. 验证 `ui-wallpaper` 行出现在 profile 组合里（`dsh --profile <name> --dump-config`）或 Web GUI 的插件页。
4. Web GUI 刷新页面——「壁纸」页会出现在设置里；服务器重启后请再次刷新。

信任提示：git 安装会在安装机上执行本包的 `prepare` 构建；如需固定版本可锁定提交（`github:youzhoujiMrLiu/dsh-ui-wallpaper#<sha>`）。
```

底层走的仍是官方 git 安装路径：`prepare` 在安装后从 `src/` 构建 `lib/`，自包含、不依赖 monorepo。

在 deepseek-harness 源码 checkout 内，同一插件位于 `packages/client/ui-wallpaper`；那里的客户端半边还需要 web-app bundle 依赖与客户端 bundle 重建，随后重启服务器并刷新页面。

## Wallpaper Engine 一键导入

设置页还可以一键导入本机已安装的 Wallpaper Engine 壁纸（仅 Windows）。导入面板通过 Steam 检测 Wallpaper Engine 安装（注册表、`libraryfolders.vdf` 或默认目录），并直接读取工坊索引（`workshopcache.json`），无需任何 Steam 集成。检测会报告 WE 版本，并要求 **Wallpaper Engine 2.8.0 或更高版本**——旧版本会得到明确的「请更新 Wallpaper Engine」提示，而不是一个坏掉的导入。若自动检测失败（非默认布局、其他盘符），面板允许直接指定 Wallpaper Engine 目录或它的 `wallpaper32.exe` / `wallpaper64.exe`；路径在服务端校验，缺失或错误时会给出具体原因。

按类型分流导入：

- **视频壁纸**直接复制源文件进入媒体存储——即时、无损，且不依赖 ffmpeg。
- **场景与网页壁纸**通过 WE 自带的命令行（`-control openWallpaper -playInWindow`）弹出一个独立的「Wallpaper Pop-out」窗口，可选应用你保存过的 WE 预设与任意属性覆盖（例如关掉时钟，避免录屏把冻结的时间烙进视频），把窗口置顶后用 ffmpeg（`gdigrab`，H.264）录制，随后自动关闭——**你的桌面壁纸和它的 WE 设置全程不被改动**。属性值与命名预设读取自 WE 的 `config.json`（`wproperties` / `wpresets`），并按壁纸定义的控件渲染（布尔、滑条、下拉、颜色、文本）。
- **应用类壁纸**会被拒绝并给出说明。

录制需要 ffmpeg，插件让这一步零配置：当机器上没有可用的 ffmpeg 时，导入面板提供一键「下载录制组件」，从官方构建下载（优先 [BtbN GitHub 发布版](https://github.com/BtbN/FFmpeg-Builds)，[gyan.dev](https://www.gyan.dev/ffmpeg/builds/) 兜底，每个源重试两次；两者均为 GPLv3，许可证文本随可执行文件一同安装），并用 Windows 自带的 Expand-Archive 解压到 `$DSH_HOME/wallpaper/ffmpeg`——无需管理员权限、不修改 `$PATH`，面板实时显示下载进度。解析顺序：面板中用户指定的路径、插件管理的安装、`$PATH`、常见安装目录，面板会明确显示实际使用的是哪一个。下载地址可通过 `we.ffmpegDownloadUrl` 配置镜像；视频壁纸完全不依赖 ffmpeg，离线机器依然可以走直接复制路径。WE 与 ffmpeg 的路径覆盖按机器持久化在 `$DSH_HOME/wallpaper/we-settings.json`。

已知录制说明：录屏无声（无音轨——音乐类壁纸导入后为静音视频）；弹窗实际尺寸跟随 WE 的 DPI 处理（录制会自动取偶像素）；录制期间弹窗会在屏幕上显示一段时间。

## Model Experience

无，因为插件只改变浏览器呈现，不注册任何 prompt、工具、schema、会话事件或 provider 请求。

#### KV Cache 影响

无；本包不组装也不发送任何 provider 请求。

## Known Limitations and Deferred Work

- **上传上限** — Host 路由最多接受 `maxBytes`（默认 64 MiB）。更大的视频需要在挂载它的补丁层 `config` 中覆盖 `maxBytes`。
- **WE 导入仅限 Windows 且要求 WE 2.8.0+** — 旧版本 WE 会在导入面板显示「请更新 Wallpaper Engine」；非 Windows 主机显示「未安装」。
- **录屏无声** — 弹窗录制没有音轨，音乐类壁纸导入后为静音视频。
- **应用类壁纸** — WE 的 application 类型无法导入，面板会拒绝并说明原因。
- **平铺 GIF 变速** — 平铺模式使用重复背景图渲染 GIF，无法逐帧变速；该模式下速度滑块会禁用并给出提示。
- **视频平铺** — 视频使用 `object-fit` 渲染，因此不提供平铺；旧偏好里的平铺会解析为填充。
- **启动闪现** — 外壳启动页先于插件 bundle 加载渲染，首帧先是纯色背景，随后才出现壁纸。
- **卸载在组合层完成** — `dsh plugin --profile <name> remove dsh-ui-wallpaper` 会同时移除依赖与插入的挂载层；暂无运行时开关。用户安装的 bundle 插入的行目前还不会出现在「自定义插件」标签页（该分类当前只识别用户补丁层）。
