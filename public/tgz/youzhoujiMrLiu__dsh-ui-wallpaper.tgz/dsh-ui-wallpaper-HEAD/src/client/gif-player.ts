/**
 * Animated-GIF playback engine for the wallpaper surface. GIFs have no
 * browser speed control, so the surface re-renders them frame by frame:
 * gifuct-js decodes the raw frames (palette indices plus disposal metadata)
 * and this module owns the pure, canvas-free math — RGBA conversion, frame
 * timing, alpha compositing, and disposal semantics — while the component
 * only puts the resulting full-frame buffer on a canvas. Keeping the math
 * here lets the unit lane cover every branch without a 2D context.
 */
import { decompressFrames, parseGIF } from 'gifuct-js'

/** One decoded GIF frame, normalized for the compositor. */
export interface GifFrame {
  /** Frame patch position inside the full canvas. */
  left: number
  top: number
  width: number
  height: number
  /** Display duration in milliseconds (gifuct-js floors it at 100 ms). */
  delay: number
  /** GIF disposal method: 1 leave, 2 clear to background, 3 restore previous. */
  disposal: number
  /** Frame-sized RGBA pixels; transparent pixels carry alpha 0. */
  rgba: Uint8ClampedArray<ArrayBuffer>
}

/** A decoded GIF ready for playback. */
export interface GifTimeline {
  width: number
  height: number
  frames: readonly GifFrame[]
}

/** Playback cursor: the frame index shown so far plus the disposed base buffer. */
export interface GifPlaybackState {
  /** Index of the last frame already displayed (-1 before the first). */
  index: number
  /** Full-size RGBA buffer holding the canvas content after the last disposal. */
  base: Uint8ClampedArray<ArrayBuffer>
}

/** Fallback delay for malformed frames without a usable delay value. */
const GIF_DEFAULT_DELAY = 100

/** Fully transparent full-size RGBA buffer. */
export function transparentBuffer(width: number, height: number): Uint8ClampedArray<ArrayBuffer> {
  return new Uint8ClampedArray(width * height * 4)
}

/**
 * Decode a GIF byte buffer into a playback timeline. Throws on data the
 * decoder cannot parse (the surface falls back to the native image path).
 * @param data - raw GIF bytes.
 * @returns the logical size and normalized frames.
 */
export function decodeGifTimeline(data: ArrayBuffer): GifTimeline {
  const gif = parseGIF(data)
  // The parser returns null dimensions for data that is not a GIF; treat it
  // as a decode failure so callers fall back to the native image path.
  if (!Number.isFinite(gif.lsd.width) || !Number.isFinite(gif.lsd.height)) {
    throw new Error('不是有效的 GIF 数据')
  }
  const frames = decompressFrames(gif, false).map((frame): GifFrame => ({
    left: frame.dims.left,
    top: frame.dims.top,
    width: frame.dims.width,
    height: frame.dims.height,
    /* v8 ignore next -- gifuct-js floors every decoded delay at 100 ms, so a non-positive delay never arrives */
    delay: frame.delay > 0 ? frame.delay : GIF_DEFAULT_DELAY,
    disposal: frame.disposalType,
    rgba: toGifRgba(frame.pixels, frame.colorTable, frame.transparentIndex),
  }))
  return { width: gif.lsd.width, height: gif.lsd.height, frames }
}

/**
 * Convert one frame's palette indices into RGBA pixels.
 * @param indices - decoded palette indices, row by row.
 * @param palette - the frame's color table (frame-local or global).
 * @param transparentIndex - index rendered fully transparent, if the GIF declares one.
 * @returns frame-sized RGBA pixels (transparent pixels carry alpha 0).
 */
export function toGifRgba(
  indices: readonly number[],
  palette: readonly (readonly [number, number, number])[],
  transparentIndex: number | undefined,
): Uint8ClampedArray<ArrayBuffer> {
  const rgba = new Uint8ClampedArray(indices.length * 4)
  for (let i = 0; i < indices.length; i += 1) {
    const index = indices[i]!
    const color = palette[index]!
    const offset = i * 4
    rgba[offset] = color[0]
    rgba[offset + 1] = color[1]
    rgba[offset + 2] = color[2]
    rgba[offset + 3] = indices[i] === transparentIndex ? 0 : 255
  }
  return rgba
}

/**
 * Resolve which frame is visible at an elapsed playback time. The timeline
 * loops forever; every GIF frame contributes its delay in order.
 * @param frames - decoded frames in display order.
 * @param elapsedMs - elapsed playback milliseconds (already speed-scaled).
 * @returns the visible frame index.
 */
export function gifFrameIndexAt(frames: readonly GifFrame[], elapsedMs: number): number {
  const total = frames.reduce((sum, frame) => sum + frame.delay, 0)
  /* v8 ignore next -- the decoder never returns an empty frame list, so a zero total is unreachable */
  if (total === 0) return 0
  let cursor = elapsedMs % total
  for (let index = 0; index < frames.length; index += 1) {
    if (cursor < frames[index]!.delay) return index
    cursor -= frames[index]!.delay
  }
  /* v8 ignore next -- the modulo above pins the cursor below the total */
  return 0
}

/**
 * Alpha-composite one frame over the base buffer (standard source-over).
 * @param base - full-size RGBA buffer before this frame.
 * @param frame - the frame to draw.
 * @param width - full canvas width in pixels.
 * @returns a new full-size buffer with the frame drawn in.
 */
export function compositeGifFrame(base: Uint8ClampedArray<ArrayBuffer>, frame: GifFrame, width: number): Uint8ClampedArray<ArrayBuffer> {
  const result = base.slice()
  for (let y = 0; y < frame.height; y += 1) {
    for (let x = 0; x < frame.width; x += 1) {
      const srcOffset = (y * frame.width + x) * 4
      const srcAlpha = frame.rgba[srcOffset + 3]! / 255
      const dstOffset = ((frame.top + y) * width + frame.left + x) * 4
      result[dstOffset] = frame.rgba[srcOffset]! * srcAlpha + result[dstOffset]! * (1 - srcAlpha)
      result[dstOffset + 1] = frame.rgba[srcOffset + 1]! * srcAlpha + result[dstOffset + 1]! * (1 - srcAlpha)
      result[dstOffset + 2] = frame.rgba[srcOffset + 2]! * srcAlpha + result[dstOffset + 2]! * (1 - srcAlpha)
      result[dstOffset + 3] = Math.min(255, (srcAlpha + (result[dstOffset + 3]! / 255) * (1 - srcAlpha)) * 255)
    }
  }
  return result
}

/**
 * Apply a frame's disposal method to the base buffer: disposal 2 clears the
 * frame rect to transparency, disposal 3 restores it to the buffer content
 * from before the frame, and anything else leaves the composited result.
 * @param base - full-size RGBA buffer after the frame was drawn.
 * @param previous - the buffer as it was before the frame was drawn.
 * @param frame - the frame whose disposal applies.
 * @param width - full canvas width in pixels.
 * @returns the buffer content the next frame starts from (same reference when untouched).
 */
export function applyGifDisposal(
  base: Uint8ClampedArray<ArrayBuffer>,
  previous: Uint8ClampedArray<ArrayBuffer>,
  frame: GifFrame,
  width: number,
): Uint8ClampedArray<ArrayBuffer> {
  if (frame.disposal !== 2 && frame.disposal !== 3) return base
  const result = base.slice()
  for (let y = 0; y < frame.height; y += 1) {
    for (let x = 0; x < frame.width; x += 1) {
      const offset = ((frame.top + y) * width + frame.left + x) * 4
      if (frame.disposal === 3) {
        result[offset] = previous[offset]!
        result[offset + 1] = previous[offset + 1]!
        result[offset + 2] = previous[offset + 2]!
        result[offset + 3] = previous[offset + 3]!
      } else {
        result[offset] = 0
        result[offset + 1] = 0
        result[offset + 2] = 0
        result[offset + 3] = 0
      }
    }
  }
  return result
}

/**
 * Advance the playback cursor toward the frame visible at the given elapsed
 * time, drawing every intermediate frame through composite + disposal so the
 * base stays correct even when a high speed skips several frames per tick.
 * The target is an absolute frame ordinal (cycle × frame count + in-cycle
 * index), so the monotonic cursor keeps stepping across timeline wraps.
 * @param state - mutable cursor (index + base buffer).
 * @param frames - decoded frames in display order.
 * @param elapsedMs - elapsed playback milliseconds (already speed-scaled).
 * @param width - full canvas width in pixels.
 * @returns the full-size buffer to paint when the visible frame changed, otherwise undefined.
 */
export function gifPlaybackTick(
  state: GifPlaybackState,
  frames: readonly GifFrame[],
  elapsedMs: number,
  width: number,
): Uint8ClampedArray<ArrayBuffer> | undefined {
  const total = frames.reduce((sum, frame) => sum + frame.delay, 0)
  /* v8 ignore next -- the decoder never returns an empty frame list, so a zero total is unreachable */
  if (total === 0) return undefined
  const target = gifFrameIndexAt(frames, elapsedMs % total) + Math.floor(elapsedMs / total) * frames.length
  let drawn: Uint8ClampedArray<ArrayBuffer> | undefined
  while (state.index < target) {
    state.index += 1
    const frame = frames[state.index % frames.length]!
    const previous = state.base
    state.base = compositeGifFrame(state.base, frame, width)
    if (state.index === target) drawn = state.base
    state.base = applyGifDisposal(state.base, previous, frame, width)
  }
  return drawn
}
