/**
 * Wallpaper plugin, browser half: stacks the translucent surface-token layer,
 * registers the frame-wide wallpaper layer into `shell.overlay` (portaled to
 * document.body so it paints behind the app), and registers the wallpaper
 * settings page. One shared preference store carries the selected host-served
 * media URL and layout mode across both registrations.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the theme service's Context merge (ctx.theme).
import type {} from '@deepseek-ai/dsh-client-ui-theme/client'
// Type-only: activates the shell.overlay SlotMap entry.
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
// Type-only: activates the settings.section SlotMap entry.
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: activates the ctx.locale Context merge.
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { ThemeTokenOverrides } from '@deepseek-ai/dsh-client-ui-theme/client'
import { uploadWallpaper, wallpaperWeApi, type WallpaperInjected } from './api.ts'
import { createWallpaperStore } from './stores.ts'
import { en, zh, type WallpaperKey } from './locales.ts'
import { WallpaperLayer } from './WallpaperLayer.tsx'
import { WallpaperSettings } from './WallpaperSettings.tsx'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Wallpaper settings copy. */
    wallpaper: WallpaperKey
  }
}

export type { WallpaperInjected, WallpaperApi, WallpaperWeApi, WallpaperUploadResult } from './api.ts'
export type { WallpaperSelection, WallpaperStoreState, WallpaperActions } from './stores.ts'
export { createWallpaperStore, DEFAULT_WALLPAPER } from './stores.ts'
export type { WallpaperKind, WallpaperMediaFormat, WallpaperMode, WallpaperRenderMode } from '../model/wallpaper.ts'

/** Override-layer source id; the theme runtime keys layers by it. */
const SOURCE = '@deepseek-ai/dsh-client-ui-wallpaper'

/** Dictionary namespace owned by this plugin. */
const NS = 'wallpaper'

/**
 * Alias-token overrides: the application base and sidebar fills become
 * translucent so the body-level wallpaper shows through. Values reference the
 * scheme-static palette tokens rather than literals, so they track palette
 * updates; each mode repeats the same 60% mix.
 */
const TOKENS: ThemeTokenOverrides = {
  '--dsw-alias-bg-base': {
    light: 'color-mix(in srgb, var(--dsw-static-neutral-bluish-00) 60%, transparent)',
    dark: 'color-mix(in srgb, var(--dsw-static-neutral-bluish-950) 60%, transparent)',
  },
  '--dsw-specific-sidebar-fill': {
    light: 'color-mix(in srgb, var(--dsw-static-neutral-bluish-50) 60%, transparent)',
    dark: 'color-mix(in srgb, var(--dsw-static-neutral-bluish-900) 60%, transparent)',
  },
}

/** Required services: theme tokens, locale dictionaries, and slot composition. */
export const inject = ['slots', 'locale', 'theme']

/**
 * Register the wallpaper dictionaries, token layer, frame layer, and settings
 * page, each registration once its slot is declared.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ui-wallpaper: dictionaries')
  const t = ctx.locale.bind(NS)
  ctx.effect(() => ctx.theme.overrideTokens(SOURCE, TOKENS), 'ui-wallpaper: token overrides')

  const store = createWallpaperStore()
  const injected = (): WallpaperInjected => ({ api: { upload: uploadWallpaper, we: wallpaperWeApi } })

  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'wallpaper',
    order: 0,
    store,
  }, WallpaperLayer))

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'wallpaper',
    order: 5,
    label: () => t('nav'),
    locale: NS,
    store,
    inject: injected,
  }, WallpaperSettings))
}
