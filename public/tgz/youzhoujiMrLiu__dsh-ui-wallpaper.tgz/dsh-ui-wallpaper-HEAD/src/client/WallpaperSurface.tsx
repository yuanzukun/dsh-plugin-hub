/**
 * Pure wallpaper surface: one sized container drawing the selected image or
 * video in the chosen layout mode. The frame layer portals it behind the app;
 * the settings page previews it inside a fixed-height box.
 */
import type { ReactNode } from 'react'
import { wallpaperBrightnessFilter, wallpaperPlaybackSpeed, wallpaperRenderMode } from '../model/wallpaper.ts'
import { GifSurface } from './GifSurface.tsx'
import type { WallpaperSelection } from './stores.ts'
import type { WallpaperMode } from '../model/wallpaper.ts'
import css from './WallpaperSurface.module.css'

export interface WallpaperSurfaceProps {
  selection: WallpaperSelection
  mode: WallpaperMode
  /** Brightness multiplier (1 = 100%); legacy states read undefined and render neutral. */
  brightness: number | undefined
  /** Playback-speed multiplier for animated media (1 = native speed). */
  speed: number | undefined
}

/**
 * Render one wallpaper selection at 100% × 100% of its positioned container.
 * @param props - the selected media, layout mode, brightness, and speed.
 * @returns the media surface.
 */
export function WallpaperSurface(props: WallpaperSurfaceProps): ReactNode {
  const { selection, mode, brightness, speed } = props
  const speedValue = wallpaperPlaybackSpeed(speed)
  const renderMode = wallpaperRenderMode(mode, selection.kind)
  // One filter on the surface element covers every presentation — tiled
  // backgrounds, still images, GIFs, and videos alike.
  const filter = wallpaperBrightnessFilter(brightness)
  if (renderMode === 'tile') {
    return (
      <div
        className={`${css.surface} ${css.tile}`}
        style={{ backgroundImage: `url("${selection.src}")`, filter }}
      />
    )
  }
  const objectFit = renderMode
  const media = selection.kind === 'video'
    ? (
      <video
        ref={(node) => { if (node !== null) node.playbackRate = speedValue }}
        className={css.media}
        src={selection.src}
        autoPlay
        muted
        loop
        playsInline
        style={{ objectFit }}
      />
    )
    : <GifSurface src={selection.src} speed={speed} objectFit={objectFit} />
  return <div className={css.surface} style={{ filter }}>{media}</div>
}
