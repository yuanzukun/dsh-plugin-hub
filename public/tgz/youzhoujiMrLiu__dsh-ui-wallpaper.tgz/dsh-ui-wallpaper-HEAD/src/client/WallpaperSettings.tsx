/**
 * Wallpaper settings page: a live preview of the current selection, the four
 * layout modes, a brightness slider and a typeable playback-speed input with
 * step buttons over the shared surface, local-file upload through the host
 * route, and disable/restore actions. Selection, mode, brightness, and speed
 * ride the shared store; upload failures render inline while the input keeps
 * its value cleared.
 */
import { useRef, useState, type ChangeEvent, type ReactNode } from 'react'
import type {
  InjectFace, PropsLocale, PropsRuntime, PropsStore,
} from '@deepseek-ai/dsh-client-ui-slots'
import {
  WALLPAPER_ACCEPT, WALLPAPER_BRIGHTNESS_DEFAULT, WALLPAPER_BRIGHTNESS_MAX,
  WALLPAPER_BRIGHTNESS_MIN, WALLPAPER_BRIGHTNESS_STEP, WALLPAPER_MODES,
  WALLPAPER_SPEED_DEFAULT, WALLPAPER_SPEED_MAX, WALLPAPER_SPEED_MIN,
  wallpaperBrightness, wallpaperBrightnessPercent,
  wallpaperPlaybackSpeed, wallpaperPlaybackSpeedLabel, wallpaperSpeedStepDown,
  wallpaperSpeedStepUp,
} from '../model/wallpaper.ts'
import type { WallpaperInjected } from './api.ts'
import type { createWallpaperStore } from './stores.ts'
import { WallpaperSurface } from './WallpaperSurface.tsx'
import { WeImport } from './WeImport.tsx'
import css from './WallpaperSettings.module.css'

export type WallpaperSettingsProps =
  & PropsRuntime<'settings.section'>
  & PropsStore<ReturnType<typeof createWallpaperStore>>
  & InjectFace<WallpaperInjected>
  & PropsLocale<'wallpaper'>

/**
 * Render the wallpaper settings page.
 * @param props - the four composed shares.
 * @returns the settings section content.
 */
export function WallpaperSettings(props: WallpaperSettingsProps): ReactNode {
  const { useStore, actions, api, t } = props
  const { selection, mode, brightness, speed } = useStore(s => s)
  const brightnessValue = wallpaperBrightness(brightness)
  const speedValue = wallpaperPlaybackSpeed(speed)
  // Tiled GIFs render through a repeating background image, which has no
  // frame-stepping path — the same tile exclusion videos already have.
  const speedUnavailable = selection?.kind === 'image' && mode === 'tile'

  const fileInput = useRef<HTMLInputElement | null>(null)
  const [uploading, setUploading] = useState(false)
  const [notice, setNotice] = useState<string | undefined>(undefined)
  const [uploadError, setUploadError] = useState<string | undefined>(undefined)
  // Raw text of the speed input while the user types (partial values like
  // "1." must survive a round trip); undefined means "mirror the store".
  const [speedText, setSpeedText] = useState<string | undefined>(undefined)

  /** Write a concrete speed and drop any in-flight input text. */
  const commitSpeed = (value: number): void => {
    setSpeedText(undefined)
    actions.setSpeed(value)
  }

  const handleSpeedInput = (event: ChangeEvent<HTMLInputElement>): void => {
    const text = event.currentTarget.value
    setSpeedText(text)
    const parsed = Number(text)
    if (text.trim() !== '' && Number.isFinite(parsed)) actions.setSpeed(parsed)
  }

  const handleFiles = (event: ChangeEvent<HTMLInputElement>): void => {
    const input = event.currentTarget
    const file = event.target.files?.[0]
    if (file === undefined) return
    setUploading(true)
    setUploadError(undefined)
    setNotice(undefined)
    void (async () => {
      try {
        const uploaded = await api.upload(file)
        actions.selectWallpaper({ kind: uploaded.kind, src: uploaded.url, name: file.name })
        if (uploaded.kind === 'video' && mode === 'tile') actions.setMode('cover')
        setNotice(t('upload.done'))
      } catch (error) {
        setUploadError(error instanceof Error ? error.message : String(error))
      } finally {
        setUploading(false)
        input.value = ''
      }
    })()
  }

  return (
    <div className={css.page}>
      <p className={css.hint}>{t('intro')}</p>
      <div className={css.preview}>
        {selection === null
          ? <p className={css.empty}>{t('none')}</p>
          : <WallpaperSurface selection={selection} mode={mode} brightness={brightness} speed={speed} />}
      </div>
      <p className={css.current}>
        {selection === null ? t('none') : `${t('current')}：${selection.name}`}
      </p>
      <div className={css.controls}>
        <span className={css.controlsLabel}>{t('mode.label')}</span>
        {WALLPAPER_MODES.map(option => {
          const unavailable = selection?.kind === 'video' && option === 'tile'
          return (
            <button
              key={option}
              type="button"
              className={mode === option && !unavailable ? `${css.modeButton} ${css.active}` : css.modeButton}
              aria-pressed={mode === option && !unavailable}
              disabled={unavailable}
              title={unavailable ? t('mode.videoHint') : undefined}
              onClick={() => actions.setMode(option)}
            >
              {t(`mode.${option}`)}
            </button>
          )
        })}
        <span className={css.spacer} />
        <button type="button" className={css.actionButton} onClick={() => fileInput.current?.click()} disabled={uploading}>
          {uploading ? t('uploading') : t('choose')}
        </button>
        {selection !== null && (
          <button type="button" className={css.actionButton} onClick={() => actions.disableWallpaper()}>
            {t('disable')}
          </button>
        )}
        <button type="button" className={css.actionButton} onClick={() => actions.restoreDefault()}>
          {t('restore')}
        </button>
      </div>
      <div className={css.controls}>
        <span className={css.controlsLabel}>{t('brightness.label')}</span>
        <input
          className={css.slider}
          type="range"
          min={WALLPAPER_BRIGHTNESS_MIN}
          max={WALLPAPER_BRIGHTNESS_MAX}
          step={WALLPAPER_BRIGHTNESS_STEP}
          value={brightnessValue}
          aria-label={t('brightness.label')}
          onChange={event => actions.setBrightness(Number(event.currentTarget.value))}
        />
        <span className={css.sliderValue}>{wallpaperBrightnessPercent(brightness)}%</span>
        <span className={css.spacer} />
        <button
          type="button"
          className={css.actionButton}
          disabled={brightnessValue === WALLPAPER_BRIGHTNESS_DEFAULT}
          onClick={() => actions.setBrightness(WALLPAPER_BRIGHTNESS_DEFAULT)}
        >
          {t('brightness.reset')}
        </button>
      </div>
      <div className={css.controls}>
        <span className={css.controlsLabel}>{t('speed.label')}</span>
        <button
          type="button"
          className={css.stepButton}
          aria-label={t('speed.slower')}
          disabled={speedUnavailable || speedValue <= WALLPAPER_SPEED_MIN}
          onClick={() => commitSpeed(speedValue - wallpaperSpeedStepDown(speedValue))}
        >
          {'▼'}
        </button>
        <input
          className={css.speedInput}
          type="text"
          inputMode="decimal"
          value={speedText ?? String(speedValue)}
          aria-label={t('speed.label')}
          disabled={speedUnavailable}
          title={speedUnavailable ? t('speed.tileHint') : undefined}
          onChange={handleSpeedInput}
          onBlur={() => setSpeedText(undefined)}
        />
        <button
          type="button"
          className={css.stepButton}
          aria-label={t('speed.faster')}
          disabled={speedUnavailable || speedValue >= WALLPAPER_SPEED_MAX}
          onClick={() => commitSpeed(speedValue + wallpaperSpeedStepUp(speedValue))}
        >
          {'▲'}
        </button>
        <span className={css.sliderValue}>{wallpaperPlaybackSpeedLabel(speed)}</span>
        <span className={css.spacer} />
        <button
          type="button"
          className={css.actionButton}
          disabled={speedValue === WALLPAPER_SPEED_DEFAULT}
          onClick={() => commitSpeed(WALLPAPER_SPEED_DEFAULT)}
        >
          {t('speed.reset')}
        </button>
      </div>
      {uploadError !== undefined && <p className={css.error}>{uploadError}</p>}
      {notice !== undefined && <p className={css.notice}>{notice}</p>}
      <details className={css.weDetails}>
        <summary className={css.weSummary}>{t('we.title')}</summary>
        <WeImport
          api={api}
          t={t}
          onImported={(imported) => {
            actions.selectWallpaper(imported)
            if (imported.kind === 'video' && mode === 'tile') actions.setMode('cover')
            setNotice(t('we.done'))
          }}
        />
      </details>
      <input
        ref={fileInput}
        className={css.hiddenInput}
        type="file"
        accept={WALLPAPER_ACCEPT}
        onChange={handleFiles}
      />
    </div>
  )
}
