/**
 * Wallpaper Engine import panel inside the wallpaper settings page: detects
 * the WE install (with a version gate), lists installed wallpapers with
 * previews, shows per-wallpaper property schemas, current values, and user
 * presets, and starts background imports — direct copies for videos, pop-out
 * recording for scenes and web wallpapers. The WE and ffmpeg paths are
 * user-overridable here and validated server-side.
 */
import { useEffect, useRef, useState, type ChangeEvent, type ReactNode } from 'react'
import type { WallpaperApi } from './api.ts'
import type { WallpaperKey } from './locales.ts'
import type { WallpaperSelection } from './stores.ts'
import {
  FFMPEG_DOWNLOAD_SIZE_LABEL, weColorFromHex, weColorToHex, wePropertyLabel,
  WE_IMPORT_BOUNDS,
  type FfmpegInstallState, type WeImportJob, type WePropertySchema,
  type WeStatus, type WeWallpaperDetail, type WeWallpaperInfo,
} from '../model/we.ts'
import css from './WallpaperSettings.module.css'

/** Panel properties: the injected host API, bound locale, and the apply hook. */
export interface WeImportProps {
  api: WallpaperApi
  t: (key: WallpaperKey) => string
  /** Called with the finished selection so the page can apply it. */
  onImported: (selection: WallpaperSelection) => void
}

/** Locale key with `{n}`-style placeholders replaced. */
function tf(t: (key: WallpaperKey) => string, key: WallpaperKey, vars?: Record<string, string>): string {
  let text = t(key)
  for (const [name, value] of Object.entries(vars ?? {})) text = text.replaceAll(`{${name}}`, value)
  return text
}

/** Scalar values the property form and overrides understand. */
type Scalar = string | number | boolean

/**
 * Engine-key property names (WE's own `ui_*` rows) with a user-facing label
 * in the dictionaries. WE's UI translates these through its locale files;
 * the panel mirrors that for the one engine key real wallpapers ship.
 */
const ENGINE_PROPERTY_LABELS: Partial<Record<string, WallpaperKey>> = {
  schemecolor: 'we.prop.schemecolor',
}

/**
 * User-facing label for one property row: the author's text, or the
 * dictionary translation for known engine keys; anything else falls back to
 * the raw property name (the pure model helper's engine-key behavior).
 */
function propertyRowLabel(
  name: string,
  schema: WePropertySchema,
  t: (key: WallpaperKey) => string,
): string {
  const label = wePropertyLabel(name, schema)
  if (label === name) {
    const key = ENGINE_PROPERTY_LABELS[name]
    if (key !== undefined) return t(key)
  }
  return label
}

/** Render the Wallpaper Engine import panel. */
export function WeImport(props: WeImportProps): ReactNode {
  const { api, t, onImported } = props
  const [status, setStatus] = useState<WeStatus | undefined>(undefined)
  const [wallpapers, setWallpapers] = useState<WeWallpaperInfo[]>([])
  const [listLoading, setListLoading] = useState(false)
  const [selectedId, setSelectedId] = useState<string | undefined>(undefined)
  const [detail, setDetail] = useState<WeWallpaperDetail | undefined>(undefined)
  const [form, setForm] = useState<Record<string, Scalar>>({})
  const [preset, setPreset] = useState('')
  const [duration, setDuration] = useState(String(WE_IMPORT_BOUNDS.durationSeconds.default))
  const [fps, setFps] = useState(String(WE_IMPORT_BOUNDS.fps.default))
  const [width, setWidth] = useState(String(Math.round(window.screen.width * (window.devicePixelRatio || 1) || 1920)))
  const [height, setHeight] = useState(String(Math.round(window.screen.height * (window.devicePixelRatio || 1) || 1080)))
  const [wePath, setWePath] = useState('')
  const [ffmpegPath, setFfmpegPath] = useState('')
  // The WE path input only shows when detection failed or the user asks to
  // re-pick the executable after a successful detection.
  const [showWePath, setShowWePath] = useState(false)
  // The ffmpeg path input only shows when the user expands it (re-pick or
  // manual specification); ready and download flows keep it hidden.
  const [showFfmpegPath, setShowFfmpegPath] = useState(false)
  const [job, setJob] = useState<WeImportJob | undefined>(undefined)
  const [install, setInstall] = useState<FfmpegInstallState | undefined>(undefined)
  const [notice, setNotice] = useState<string | undefined>(undefined)
  const [error, setError] = useState<string | undefined>(undefined)
  const polling = useRef<ReturnType<typeof setInterval> | undefined>(undefined)
  const installPolling = useRef<ReturnType<typeof setInterval> | undefined>(undefined)

  const stopInstallPolling = (): void => {
    if (installPolling.current !== undefined) clearInterval(installPolling.current)
    installPolling.current = undefined
  }

  const startFfmpegInstall = (): void => {
    setError(undefined)
    setNotice(undefined)
    setInstall({ id: '', state: 'downloading', receivedBytes: 0 })
    void (async () => {
      try {
        const installId = await api.we.ffmpegInstall()
        setInstall({ id: installId, state: 'downloading', receivedBytes: 0 })
        installPolling.current = setInterval(() => {
          void (async () => {
            const current = await api.we.ffmpegInstallStatus(installId)
            setInstall(current)
            if (current.state === 'done') {
              stopInstallPolling()
              setInstall(undefined)
              setNotice(t('we.ffmpeg.installed'))
              refresh()
            } else if (current.state === 'error') {
              stopInstallPolling()
              setError(current.error ?? t('we.failed'))
              setInstall(undefined)
            }
          })().catch((caught: unknown) => {
            stopInstallPolling()
            setError(caught instanceof Error ? caught.message : String(caught))
            setInstall(undefined)
          })
        }, 1000)
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : String(caught))
        setInstall(undefined)
      }
    })()
  }

  const refresh = (): void => {
    setError(undefined)
    void (async () => {
      try {
        const snapshot = await api.we.status()
        setStatus(snapshot)
        setWePath(snapshot.wallpaperEnginePath ?? '')
        setFfmpegPath(snapshot.ffmpegPath ?? '')
        if (snapshot.available && snapshot.supported) {
          setListLoading(true)
          try {
            const list = await api.we.list()
            setWallpapers(list)
          } finally {
            setListLoading(false)
          }
        } else {
          setWallpapers([])
          setDetail(undefined)
        }
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : String(caught))
      }
    })()
  }

  useEffect(() => {
    refresh()
    return () => {
      if (polling.current !== undefined) clearInterval(polling.current)
      stopInstallPolling()
    }
    // Run once on mount; the manual refresh button covers re-detection.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (selectedId === undefined) return
    setDetail(undefined)
    setError(undefined)
    void (async () => {
      try {
        const loaded = await api.we.detail(selectedId)
        setDetail(loaded)
        const initial: Record<string, Scalar> = {}
        for (const name of Object.keys(loaded.properties)) {
          initial[name] = toScalar(loaded.current[name])
        }
        setForm(initial)
        setPreset('')
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : String(caught))
      }
    })()
  }, [selectedId, api])

  const savePaths = (): void => {
    setError(undefined)
    setNotice(undefined)
    void (async () => {
      try {
        const snapshot = await api.we.saveSettings({ wallpaperEnginePath: wePath, ffmpegPath: ffmpegPath })
        setStatus(snapshot)
        setWePath(snapshot.wallpaperEnginePath ?? '')
        setFfmpegPath(snapshot.ffmpegPath ?? '')
        setNotice(t('we.path.saved'))
        if (snapshot.available && snapshot.supported) {
          const list = await api.we.list()
          setWallpapers(list)
        }
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : String(caught))
      }
    })()
  }

  const startImport = (): void => {
    if (detail === undefined || job !== undefined) return
    const differences: Record<string, unknown> = {}
    for (const [name, value] of Object.entries(form)) {
      const schema = detail.properties[name]
      const current = detail.current[name]
      // Color pickers rewrite the WE value into a canonical float string, so
      // color properties compare by value (via hex) rather than by string.
      const changed = schema?.type === 'color'
        ? weColorToHex(current) !== weColorToHex(value)
        : String(current) !== String(value)
      if (changed) differences[name] = value
    }
    const options = {
      workshopId: detail.wallpaper.workshopId,
      durationSeconds: Number(duration),
      fps: Number(fps),
      width: Number(width),
      height: Number(height),
      ...(preset !== '' ? { preset } : {}),
      ...(Object.keys(differences).length > 0 ? { properties: differences } : {}),
    }
    setError(undefined)
    setNotice(undefined)
    setJob({ id: '', workshopId: detail.wallpaper.workshopId, state: 'preparing' })
    void (async () => {
      try {
        const jobId = await api.we.import(options)
        setJob({ id: jobId, workshopId: detail.wallpaper.workshopId, state: 'preparing' })
        polling.current = setInterval(() => {
          void (async () => {
            const current = await api.we.importStatus(jobId)
            setJob(current)
            if (current.state === 'done' && current.url !== undefined && current.url !== '') {
              if (polling.current !== undefined) clearInterval(polling.current)
              polling.current = undefined
              onImported({ kind: 'video', src: current.url, name: detail.wallpaper.title })
              setNotice(t('we.done'))
              setJob(undefined)
            } else if (current.state === 'error') {
              if (polling.current !== undefined) clearInterval(polling.current)
              polling.current = undefined
              setError(current.error ?? t('we.failed'))
              setJob(undefined)
            }
          })().catch((caught: unknown) => {
            if (polling.current !== undefined) clearInterval(polling.current)
            polling.current = undefined
            setError(caught instanceof Error ? caught.message : String(caught))
            setJob(undefined)
          })
        }, 1000)
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : String(caught))
        setJob(undefined)
      }
    })()
  }

  const running = job !== undefined
  const weReady = status !== undefined && status.available && status.supported
  const canImport = detail !== undefined && !running
    && (detail.wallpaper.type === 'video' || status?.ffmpeg !== undefined)

  return (
    <div className={css.wePanel}>
      <p className={css.hint}>{t('we.intro')}</p>
      {status === undefined && <p className={css.notice}>{t('we.checking')}</p>}
      {status !== undefined && status.error !== undefined && (
        <p className={css.error}>{status.error}</p>
      )}
      {weReady && (
        <div className={css.weRow}>
          <p className={css.notice}>
            {tf(t, 'we.detect.ok', { version: status.version ?? '?' })}
          </p>
          <button type="button" className={css.actionButton} onClick={() => setShowWePath(show => !show)}>
            {t('we.repick')}
          </button>
        </div>
      )}
      {status?.ffmpeg !== undefined && (
        <div className={css.weRow}>
          <p className={css.notice} title={status.ffmpeg}>{t('we.ffmpeg.ready')}</p>
          <button type="button" className={css.actionButton} onClick={() => setShowFfmpegPath(show => !show)}>
            {t('we.repick')}
          </button>
        </div>
      )}
      {status !== undefined && status.ffmpeg === undefined && install === undefined && (
        <p className={css.notice}>{t('we.ffmpeg.missing')}</p>
      )}
      <div className={css.wePathRows}>
        {(!weReady || showWePath) && (
          <>
            <span className={css.controlsLabel}>{t('we.path.we')}</span>
            <input className={css.weInput} type="text" value={wePath} placeholder="自动检测" onChange={event => setWePath(event.currentTarget.value)} />
            {status?.wallpaperEnginePathError !== undefined && <p className={css.error}>{status.wallpaperEnginePathError}</p>}
          </>
        )}
        {showFfmpegPath && (
          <>
            <span className={css.controlsLabel}>{t('we.path.ffmpeg')}</span>
            <input className={css.weInput} type="text" value={ffmpegPath} placeholder="自动检测 / 首次使用时下载" onChange={event => setFfmpegPath(event.currentTarget.value)} />
            {status?.ffmpegPathError !== undefined && <p className={css.error}>{status.ffmpegPathError}</p>}
          </>
        )}
        <div className={css.weRow}>
          {((!weReady || showWePath) || showFfmpegPath) && (
            <button type="button" className={css.actionButton} onClick={savePaths} disabled={running}>{t('we.path.save')}</button>
          )}
          <button type="button" className={css.actionButton} onClick={refresh} disabled={running}>{t('we.refresh')}</button>
          {status !== undefined && status.ffmpeg === undefined && install === undefined && (
            <>
              <button type="button" className={css.actionButton} onClick={startFfmpegInstall}>
                {tf(t, 'we.ffmpeg.install', { size: FFMPEG_DOWNLOAD_SIZE_LABEL })}
              </button>
              <button type="button" className={css.actionButton} onClick={() => setShowFfmpegPath(show => !show)}>
                {t('we.ffmpeg.manual')}
              </button>
            </>
          )}
        </div>
        {install !== undefined && (
          <p className={css.notice}>
            {install.state === 'downloading'
              ? tf(t, 'we.ffmpeg.downloading', { mb: String(Math.round(install.receivedBytes / (1024 * 1024))) })
              : t('we.ffmpeg.installing')}
          </p>
        )}
        {status !== undefined && status.ffmpeg === undefined && install === undefined && (
          <p className={css.hint}>{t('we.ffmpeg.installHint')}</p>
        )}
      </div>
      {status?.available && status.supported && (
        <>
          <p className={css.hint}>{tf(t, 'we.count', { n: String(wallpapers.length) })} — {t('we.selectHint')}</p>
          {listLoading && <p className={css.notice}>{t('we.loading')}</p>}
          <div className={css.weCards}>
            {wallpapers.map(entry => (
              <button
                key={entry.workshopId}
                type="button"
                className={selectedId === entry.workshopId ? `${css.weCard} ${css.weCardActive}` : css.weCard}
                onClick={() => setSelectedId(entry.workshopId)}
              >
                {entry.preview !== '' && (
                  <img className={css.weThumb} src={api.we.previewUrl(entry.workshopId)} alt={entry.title} loading="lazy" />
                )}
                <span className={css.weCardTitle}>{entry.title}</span>
                <span className={css.weBadge}>{t(`we.type.${entry.type}`)}</span>
              </button>
            ))}
          </div>
          {wallpapers.length === 0 && !listLoading && <p className={css.notice}>{t('we.empty')}</p>}
          {detail !== undefined && (
            <div className={css.weForm}>
              {detail.presets.length > 0 && (
                <div className={css.weRow}>
                  <span className={css.controlsLabel}>{t('we.preset.label')}</span>
                  <select className={css.weSelect} value={preset} onChange={event => setPreset(event.currentTarget.value)}>
                    <option value="">{t('we.preset.none')}</option>
                    {detail.presets.map(entry => <option key={entry.name} value={entry.name}>{entry.name}</option>)}
                  </select>
                </div>
              )}
              {Object.entries(detail.properties).length > 0 && (
                <div className={css.weForm}>
                  <span className={css.controlsLabel}>{t('we.props.label')}</span>
                  {Object.entries(detail.properties).map(([name, schema]) => (
                    <div key={name} className={css.weRow}>
                      <span className={css.wePropName}>{propertyRowLabel(name, schema, t)}</span>
                      {renderPropertyControl(name, schema, form[name] ?? '', (value) => {
                        setForm(previous => ({ ...previous, [name]: value }))
                      }, css)}
                    </div>
                  ))}
                </div>
              )}
              <div className={css.weRow}>
                <span className={css.controlsLabel}>{t('we.duration')}</span>
                <input className={css.weNumInput} type="number" min={WE_IMPORT_BOUNDS.durationSeconds.min} max={WE_IMPORT_BOUNDS.durationSeconds.max} value={duration} onChange={event => setDuration(event.currentTarget.value)} />
                <span className={css.controlsLabel}>{t('we.fps')}</span>
                <input className={css.weNumInput} type="number" min={WE_IMPORT_BOUNDS.fps.min} max={WE_IMPORT_BOUNDS.fps.max} value={fps} onChange={event => setFps(event.currentTarget.value)} />
                <span className={css.controlsLabel}>{t('we.size')}</span>
                <input className={css.weNumInput} type="number" min={WE_IMPORT_BOUNDS.size.min} max={WE_IMPORT_BOUNDS.size.max} value={width} onChange={event => setWidth(event.currentTarget.value)} />
                <span className={css.controlsLabel}>×</span>
                <input className={css.weNumInput} type="number" min={WE_IMPORT_BOUNDS.size.min} max={WE_IMPORT_BOUNDS.size.max} value={height} onChange={event => setHeight(event.currentTarget.value)} />
              </div>
              <div className={css.weRow}>
                <button type="button" className={css.actionButton} onClick={startImport} disabled={!canImport}>
                  {running
                    ? job.state === 'recording' || job.state === 'preparing' || job.state === 'finishing'
                      ? t(`we.state.${job.state === 'preparing' ? 'preparing' : job.state === 'recording' ? 'recording' : 'finishing'}`)
                      : t('we.importing')
                    : detail.wallpaper.type === 'video' ? t('we.import.direct') : t('we.import.record')}
                </button>
              </div>
            </div>
          )}
        </>
      )}
      {notice !== undefined && <p className={css.notice}>{notice}</p>}
      {error !== undefined && <p className={css.error}>{error}</p>}
    </div>
  )
}

/** One form control matching the property schema type. */
function renderPropertyControl(
  name: string,
  schema: WePropertySchema,
  value: Scalar,
  onChange: (value: Scalar) => void,
  cssMap: { readonly [key: string]: string },
): ReactNode {
  switch (schema.type) {
    case 'bool':
      return (
        <input
          className={cssMap.weCheckbox}
          type="checkbox"
          checked={value === true}
          aria-label={name}
          onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.currentTarget.checked)}
        />
      )
    case 'slider':
      return (
        <input
          className={cssMap.weNumInput}
          type="number"
          value={typeof value === 'number' ? value : String(value)}
          min={schema.min}
          max={schema.max}
          step={schema.step ?? 1}
          aria-label={name}
          onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(Number(event.currentTarget.value))}
        />
      )
    case 'combo':
      return (
        <select
          className={cssMap.weSelect}
          value={String(value)}
          aria-label={name}
          onChange={(event: ChangeEvent<HTMLSelectElement>) => onChange(event.currentTarget.value)}
        >
          {(schema.options ?? []).map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
      )
    case 'color':
      // WE stores colors as "R G B" floats in 0–1; the browser picker speaks
      // hex, so convert both ways and keep the WE string in the form state.
      return (
        <input
          className={cssMap.weColorInput}
          type="color"
          value={weColorToHex(value) ?? '#000000'}
          aria-label={name}
          onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(weColorFromHex(event.currentTarget.value))}
        />
      )
    default:
      return (
        <input
          className={cssMap.weInput}
          type="text"
          value={String(value)}
          aria-label={name}
          onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.currentTarget.value)}
        />
      )
  }
}

/** Narrow one current value to the scalar union the form understands. */
function toScalar(value: unknown): Scalar {
  if (typeof value === 'boolean' || typeof value === 'number' || typeof value === 'string') return value
  return ''
}
