/**
 * Frame-wide wallpaper layer. It registers into `shell.overlay` so its
 * lifetime follows the plugin fiber, then portals straight to `document.body`:
 * the overlay seat's stacking context sits above the columns, which is exactly
 * where a background must NOT be. The body-level fixed layer carries a
 * negative z-index, so app content paints above it while the translucent
 * column tokens let the media show through.
 */
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'
import type { PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots'
import type { createWallpaperStore } from './stores.ts'
import { WallpaperSurface } from './WallpaperSurface.tsx'
import css from './WallpaperLayer.module.css'

export type WallpaperLayerProps =
  & PropsRuntime<'shell.overlay'>
  & PropsStore<ReturnType<typeof createWallpaperStore>>

/**
 * Render the selected wallpaper behind the application.
 * @param props - the framework shares; only the store seat is read.
 * @returns null while disabled, otherwise a body-level media layer.
 */
export function WallpaperLayer(props: WallpaperLayerProps): ReactNode {
  const { selection, mode, brightness, speed } = props.useStore(s => s)
  if (selection === null) return null
  return createPortal(
    <div className={css.layer} aria-hidden="true" data-wallpaper-layer>
      <WallpaperSurface selection={selection} mode={mode} brightness={brightness} speed={speed} />
    </div>,
    document.body,
  )
}
