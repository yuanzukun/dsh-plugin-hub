/**
 * Wallpaper preference store shared by the frame layer and settings
 * registrations: the selected media URL, layout mode, brightness, and
 * playback speed. The plugin
 * creates one handle at apply time so both entries share the framework-cached
 * instance; persistence is localStorage via the framework store engine, while
 * the media bytes live under `$DSH_HOME/wallpaper` through the host route.
 */
import { defineStore, type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client'
import {
  WALLPAPER_BRIGHTNESS_DEFAULT, WALLPAPER_SPEED_DEFAULT, wallpaperBrightness,
  wallpaperPlaybackSpeed, type WallpaperKind, type WallpaperMode,
} from '../model/wallpaper.ts'

/** One selected wallpaper: host-served URL plus the local filename for display. */
export interface WallpaperSelection {
  kind: WallpaperKind
  src: string
  name: string
}

/** Store state: `selection === null` hides the wallpaper. */
export interface WallpaperStoreState {
  selection: WallpaperSelection | null
  mode: WallpaperMode
  /**
   * Brightness multiplier for the media surface (1 = 100%). Optional at the
   * type level because preferences persisted before the brightness feature
   * shipped lack the field; every read normalizes through the model helpers.
   */
  brightness?: number
  /**
   * Playback-speed multiplier for animated media (1 = native speed).
   * Optional for the same legacy-preference reason as brightness.
   */
  speed?: number
}

/** The shipped wallpaper, also restored by the settings reset action. */
export const DEFAULT_WALLPAPER: WallpaperSelection = {
  kind: 'image',
  src: '/eva.jpg',
  name: 'eva.jpg',
}

/** The localStorage key the preference store persists under. */
export const WALLPAPER_STORE_KEY = 'dsh.wallpaper'

/**
 * The pre-prefix key builds before the rename to {@link WALLPAPER_STORE_KEY}
 * persisted under. States written by those builds rehydrate nothing after the
 * rename, silently resetting the wallpaper to the default — adopt them once.
 */
const LEGACY_WALLPAPER_STORE_KEY = 'wallpaper'

/**
 * One-time adoption of a state persisted under the legacy key. Runs inside
 * the store `init`, i.e. before the engine rehydrates the current key, so an
 * adopted legacy state is exactly what the page renders on the first load
 * after the rename. The current key wins when both exist; the legacy key is
 * dropped either way so the migration never repeats.
 */
function migrateLegacyStoreKey(): void {
  if (typeof localStorage === 'undefined') return
  try {
    const current = localStorage.getItem(WALLPAPER_STORE_KEY)
    const legacy = localStorage.getItem(LEGACY_WALLPAPER_STORE_KEY)
    if (legacy !== null) {
      if (current === null) {
        let adopt = false
        try {
          const parsed = JSON.parse(legacy) as unknown
          adopt = typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)
        } catch {
          // A corrupt legacy record is garbage: drop it without adopting.
        }
        if (adopt) localStorage.setItem(WALLPAPER_STORE_KEY, legacy)
      }
      localStorage.removeItem(LEGACY_WALLPAPER_STORE_KEY)
    }
  } catch {
    // Storage failures (private mode, quota) only skip the migration.
  }
}

/** Declared write surface (the complete mutation API for components). */
export type WallpaperActions = {
  selectWallpaper: (draft: WallpaperStoreState, selection: WallpaperSelection) => void
  setMode: (draft: WallpaperStoreState, mode: WallpaperMode) => void
  setBrightness: (draft: WallpaperStoreState, brightness: number) => void
  setSpeed: (draft: WallpaperStoreState, speed: number) => void
  disableWallpaper: (draft: WallpaperStoreState) => void
  restoreDefault: (draft: WallpaperStoreState) => void
}

/**
 * Declare the wallpaper preference store.
 * @returns the store handle shared by both registrations in apply.
 */
export function createWallpaperStore(): EngineStoreHandle<WallpaperStoreState, WallpaperActions> {
  return defineStore({
    init: (): WallpaperStoreState => {
      // Runs before the engine rehydrates WALLPAPER_STORE_KEY below, so a
      // state persisted under the legacy key is picked up on this very load.
      migrateLegacyStoreKey()
      return {
        selection: DEFAULT_WALLPAPER,
        mode: 'cover',
        brightness: WALLPAPER_BRIGHTNESS_DEFAULT,
        speed: WALLPAPER_SPEED_DEFAULT,
      }
    },
    persist: WALLPAPER_STORE_KEY,
    actions: {
      selectWallpaper: (draft, selection) => { draft.selection = selection },
      setMode: (draft, mode) => { draft.mode = mode },
      setBrightness: (draft, brightness) => { draft.brightness = wallpaperBrightness(brightness) },
      setSpeed: (draft, speed) => { draft.speed = wallpaperPlaybackSpeed(speed) },
      disableWallpaper: (draft) => { draft.selection = null },
      restoreDefault: (draft) => {
        draft.selection = DEFAULT_WALLPAPER
        draft.mode = 'cover'
        draft.brightness = WALLPAPER_BRIGHTNESS_DEFAULT
        draft.speed = WALLPAPER_SPEED_DEFAULT
      },
    },
  })
}
