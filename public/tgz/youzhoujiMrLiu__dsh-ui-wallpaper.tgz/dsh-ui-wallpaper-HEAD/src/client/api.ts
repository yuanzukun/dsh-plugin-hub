/**
 * Host wallpaper API over the /dsh-wallpaper route: one raw-file upload that
 * stores the media under `$DSH_HOME/wallpaper` and returns the URL the store
 * persists, plus the Wallpaper Engine import surface on the `/we` segment.
 * The picker derives a canonical MIME type before the fetch so the host
 * whitelist and the client accept surface stay one shared model.
 */
import {
  wallpaperFormatByFileName, wallpaperFormatByMime, type WallpaperKind,
} from '../model/wallpaper.ts'
import type {
  FfmpegInstallState, WeImportJob, WeImportOptions, WeStatus, WeWallpaperDetail,
  WeWallpaperInfo,
} from '../model/we.ts'

/** Host upload response: the durable URL plus the media kind. */
export interface WallpaperUploadResult {
  kind: WallpaperKind
  url: string
}

/** The Wallpaper Engine import surface injected into the settings page. */
export interface WallpaperWeApi {
  /** WE detection and version gate snapshot. */
  status(): Promise<WeStatus>
  /** Every installed WE wallpaper. */
  list(): Promise<WeWallpaperInfo[]>
  /** One wallpaper's property schema, current values, and presets. */
  detail(workshopId: string): Promise<WeWallpaperDetail>
  /** The preview image URL for the list thumbnails. */
  previewUrl(workshopId: string): string
  /** Persist the user's WE / ffmpeg path overrides; returns the new status. */
  saveSettings(input: { wallpaperEnginePath?: string; ffmpegPath?: string }): Promise<WeStatus>
  /** Start one background import; resolves with the job id. */
  import(options: WeImportOptions): Promise<string>
  /** Poll one import job. */
  importStatus(jobId: string): Promise<WeImportJob>
  /** Start (or join) the first-use ffmpeg download; resolves with its id. */
  ffmpegInstall(): Promise<string>
  /** Poll one ffmpeg installation job. */
  ffmpegInstallStatus(installId: string): Promise<FfmpegInstallState>
}

/** The host API surface injected into the settings registration. */
export interface WallpaperApi {
  upload(file: File): Promise<WallpaperUploadResult>
  we: WallpaperWeApi
}

/** Registrant business face for the settings page. */
export interface WallpaperInjected {
  api: WallpaperApi
}

/**
 * Upload one browser-picked local file; rejects with the host's message on
 * failure and with a client message when the type is not accepted.
 * @param file - the picked local file.
 * @returns the durable media URL and kind.
 */
export async function uploadWallpaper(file: File): Promise<WallpaperUploadResult> {
  const format = wallpaperFormatByMime(file.type) ?? wallpaperFormatByFileName(file.name)
  if (format === undefined) {
    throw new Error('不支持的文件类型，请选择 PNG、JPEG、GIF、WebP、AVIF、SVG 图片或 MP4、WebM、Ogg 视频')
  }
  const response = await fetch('/dsh-wallpaper/media', {
    method: 'POST',
    headers: { 'content-type': format.mime },
    body: file,
  })
  const body = await response.json().catch(() => ({})) as { url?: string; kind?: WallpaperKind; error?: string }
  if (!response.ok) {
    throw new Error(typeof body.error === 'string' && body.error !== '' ? body.error : `壁纸上传失败（${response.status}）`)
  }
  if (typeof body.url !== 'string' || body.url === '' || (body.kind !== 'image' && body.kind !== 'video')) {
    throw new Error('壁纸上传失败：服务端未返回有效的壁纸地址')
  }
  return { kind: body.kind, url: body.url }
}

/** The Wallpaper Engine import API; host errors surface as Error messages. */
export const wallpaperWeApi: WallpaperWeApi = {
  status: async () => requestJson<WeStatus>('/dsh-wallpaper/we/status'),
  list: async () => {
    const body = await requestJson<{ wallpapers: WeWallpaperInfo[] }>('/dsh-wallpaper/we/list')
    return body.wallpapers
  },
  detail: async (workshopId) => requestJson<WeWallpaperDetail>(`/dsh-wallpaper/we/detail?workshopId=${encodeURIComponent(workshopId)}`),
  previewUrl: (workshopId) => `/dsh-wallpaper/we/preview?workshopId=${encodeURIComponent(workshopId)}`,
  saveSettings: async (input) => {
    const body = await requestJson<{ status: WeStatus }>('/dsh-wallpaper/we/settings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(input),
    })
    return body.status
  },
  import: async (options) => {
    const body = await requestJson<{ jobId: string }>('/dsh-wallpaper/we/import', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(options),
    })
    return body.jobId
  },
  importStatus: async (jobId) => requestJson<WeImportJob>(`/dsh-wallpaper/we/import?id=${encodeURIComponent(jobId)}`),
  ffmpegInstall: async () => {
    const body = await requestJson<{ installId: string }>('/dsh-wallpaper/we/ffmpeg', { method: 'POST' })
    return body.installId
  },
  ffmpegInstallStatus: async (installId) => requestJson<FfmpegInstallState>(`/dsh-wallpaper/we/ffmpeg?id=${encodeURIComponent(installId)}`),
}

/** GET or POST one JSON endpoint, translating host errors into Error messages. */
async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init)
  const body = await response.json().catch(() => ({})) as Record<string, unknown> & { error?: string }
  if (!response.ok) {
    throw new Error(typeof body.error === 'string' && body.error !== '' ? body.error : `请求失败（${response.status}）`)
  }
  return body as T
}
