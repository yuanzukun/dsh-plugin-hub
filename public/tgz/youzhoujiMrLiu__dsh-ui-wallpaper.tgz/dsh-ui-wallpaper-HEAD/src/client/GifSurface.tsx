/**
 * Speed-controlled animated-GIF surface. Native <img> GIF playback has no
 * rate control, so at any speed other than 1× the component fetches the
 * media bytes (the host route answers with the GIF MIME type), decodes the
 * frames, and steps them onto a full-size canvas at the chosen multiplier.
 * Anything that is not a GIF — or any fetch, decode, or canvas failure —
 * falls back to the ordinary image element at native speed.
 */
import { useEffect, useRef, useState, type ReactNode } from 'react'
import { wallpaperPlaybackSpeed } from '../model/wallpaper.ts'
import {
  decodeGifTimeline, gifPlaybackTick, transparentBuffer, type GifTimeline,
} from './gif-player.ts'
import css from './WallpaperSurface.module.css'

export interface GifSurfaceProps {
  src: string
  /** Raw speed multiplier; 1× keeps the native <img> path untouched. */
  speed: number | undefined
  /** CSS object-fit, identical to the static image presentation. */
  objectFit: 'cover' | 'contain' | 'fill'
}

/**
 * Render an image surface with optional GIF rate control.
 * @param props - the media URL, speed multiplier, and layout fit.
 * @returns a native image at 1×, otherwise a canvas replaying the decoded frames.
 */
export function GifSurface(props: GifSurfaceProps): ReactNode {
  const { src, speed, objectFit } = props
  const speedValue = wallpaperPlaybackSpeed(speed)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [timeline, setTimeline] = useState<GifTimeline | undefined>(undefined)
  const [failed, setFailed] = useState(false)

  // Load and decode the media when (and only when) a non-native speed asks
  // for frame control; non-GIF media and any failure fall back to <img>.
  useEffect(() => {
    if (speedValue === 1) {
      setTimeline(undefined)
      setFailed(false)
      return
    }
    let alive = true
    setTimeline(undefined)
    setFailed(false)
    void (async () => {
      try {
        const response = await fetch(src)
        const contentType = response.headers.get('content-type')?.split(';', 1)[0]?.trim().toLowerCase()
        if (!response.ok || contentType !== 'image/gif') {
          if (alive) setFailed(true)
          return
        }
        const decoded = decodeGifTimeline(await response.arrayBuffer())
        if (alive) setTimeline(decoded)
      } catch {
        if (alive) setFailed(true)
      }
    })()
    return () => { alive = false }
  }, [src, speedValue])

  // rAF playback loop: step the pure cursor to the frame visible at the
  // speed-scaled clock and paint whenever it changes. jsdom has no 2D
  // context, so the whole loop is browser-lane code; the stepping math it
  // drives is fully covered in gif-player.ts.
  useEffect(() => {
    if (timeline === undefined) return
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d') ?? undefined
    /* v8 ignore next -- jsdom provides no 2D context; the browser/e2e lane owns the paint loop */
    if (canvas !== null && ctx !== undefined) {
      const state = { index: -1, base: transparentBuffer(timeline.width, timeline.height) }
      const start = performance.now()
      let raf = 0
      const step = (now: number): void => {
        const drawn = gifPlaybackTick(state, timeline.frames, (now - start) * speedValue, timeline.width)
        if (drawn !== undefined) ctx.putImageData(new ImageData(drawn, timeline.width, timeline.height), 0, 0)
        raf = requestAnimationFrame(step)
      }
      raf = requestAnimationFrame(step)
      return () => cancelAnimationFrame(raf)
    }
  }, [timeline, speedValue])

  if (timeline === undefined || failed) {
    return <img className={css.media} src={src} alt="" draggable={false} style={{ objectFit }} />
  }
  return (
    <canvas
      ref={canvasRef}
      className={css.media}
      width={timeline.width}
      height={timeline.height}
      style={{ objectFit }}
    />
  )
}
