/**
 * Wallpaper plugin, host half: mounts the /dsh-wallpaper routes on the web
 * server so the browser can store one user-picked image, GIF, or video under
 * `$DSH_HOME/wallpaper` and serve it back as the frame background, and adds
 * the Wallpaper Engine import routes (list, presets, pop-out recording) on
 * the `/we` segment.
 * @module @deepseek-ai/dsh-client-ui-wallpaper
 */
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
// Type-only: activates the webServer Context merge.
import type {} from '@deepseek-ai/dsh-host-webserver'
import { WALLPAPER_API_PATH, createWallpaperRoutes } from './host/routes.ts'
import { createWallpaperMediaStore } from './host/media.ts'
import { WeEngine } from './host/we.ts'

/** Stable Cordis plugin name. */
export const name = 'ui-wallpaper'

/** Wallpaper Engine import tuning; every field optional. */
export interface WallpaperWeConfig {
  /** Forced Steam root, overriding registry discovery. */
  steamPath?: string
  /** User-specified WE directory or wallpaper32/64.exe path (overridable from the settings page). */
  wallpaperEnginePath?: string
  /** User-specified ffmpeg path (overridable from the settings page). */
  ffmpegPath?: string
  /** First-use ffmpeg download URL; defaults to the official gyan.dev build. */
  ffmpegDownloadUrl?: string
  /** Overall recording budget in ms. */
  recordTimeoutMs?: number
  /** Wait after the pop-out opens before recording. */
  settleMs?: number
}

/** Host config: upload bound plus the non-loopback authorities permitted to reach the routes. */
export interface WallpaperConfig {
  /**
   * Maximum accepted upload body in bytes (default 64 MiB). Videos larger
   * than the default need a larger value in the mounting patch layer.
   */
  maxBytes?: number
  /**
   * Authorities this deployment serves beyond loopback (same shape as
   * client-connection's trustedHosts); omit for loopback-only serving.
   */
  trustedHosts?: string[]
  /** Wallpaper Engine import tuning; all optional. */
  we?: WallpaperWeConfig
}

const WeConfig = z.object({
  steamPath: z.string().default(''),
  wallpaperEnginePath: z.string().default(''),
  ffmpegPath: z.string().default(''),
  ffmpegDownloadUrl: z.string().default(''),
  recordTimeoutMs: z.natural().default(340_000),
  settleMs: z.natural().default(6000),
})

export const Config: z<WallpaperConfig> = z.object({
  maxBytes: z.natural().default(64 * 1024 * 1024),
  trustedHosts: z.array(String).default([]),
  we: WeConfig.default({
    steamPath: '',
    wallpaperEnginePath: '',
    ffmpegPath: '',
    ffmpegDownloadUrl: '',
    recordTimeoutMs: 340_000,
    settleMs: 6000,
  }),
})

/** The webserver service is a hard dependency: without it no route exists. */
export const inject = ['webServer']

/**
 * Resolve the wallpaper storage root and register the /dsh-wallpaper prefix;
 * Config() applies the schema defaults for direct callers. The Wallpaper
 * Engine engine is created eagerly but discovers lazily, so machines without
 * WE installs pay nothing until the import panel opens.
 * @param ctx - host plugin context.
 * @param config - resolved plugin config (schema defaults applied by the Loader).
 */
export function apply(ctx: Context, config: WallpaperConfig = {}): void {
  const { maxBytes, trustedHosts, we } = Config(config) as { maxBytes: number; trustedHosts: string[]; we: WallpaperWeConfig }
  const root = join(resolveDshHome(undefined, process.env), 'wallpaper')
  const engine = new WeEngine({
    steamRoot: we.steamPath !== '' ? we.steamPath : undefined,
    wallpaperEnginePath: we.wallpaperEnginePath !== '' ? we.wallpaperEnginePath : undefined,
    ffmpegPath: we.ffmpegPath !== '' ? we.ffmpegPath : undefined,
    ffmpegDownloadUrl: we.ffmpegDownloadUrl !== '' ? we.ffmpegDownloadUrl : undefined,
    recordTimeoutMs: we.recordTimeoutMs,
    settleMs: we.settleMs,
    mediaStore: createWallpaperMediaStore(root),
  })
  const routes = createWallpaperRoutes({
    root,
    maxBytes,
    trustedHosts,
    engine,
  })
  ctx.effect(() => {
    const dispose = ctx.webServer.register({
      kind: 'prefix',
      path: WALLPAPER_API_PATH,
      handler: routes.handle,
    })
    return () => {
      dispose()
      void engine.dispose()
    }
  }, 'ui-wallpaper: /dsh-wallpaper routes')
}

/** Re-exported for advanced host consumers driving the engine directly. */
export { WeEngine, type WeEngineOptions, type WeImportJob, type WeStatus, type WeSettingsOverrides } from './host/we.ts'
export { createWallpaperMediaStore, type WallpaperMediaStore } from './host/media.ts'
