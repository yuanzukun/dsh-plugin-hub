/**
 * Shared HTTP helpers for the /dsh-wallpaper route family: the browser trust
 * fence, bounded body reads, and JSON writes. Both the media routes and the
 * Wallpaper Engine import routes consume them so one fence covers the prefix.
 */
import type { IncomingMessage, ServerResponse } from 'node:http'

/** Request-scoped failure carrying the HTTP status. */
export class WallpaperHttpError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message)
  }
}

/** Read a bounded raw request body into one buffer. */
export async function readBody(req: IncomingMessage, limit: number): Promise<Buffer> {
  const chunks: Buffer[] = []
  let total = 0
  for await (const chunk of req) {
    const buffer = Buffer.from(chunk)
    total += buffer.length
    if (total > limit) throw new WallpaperHttpError(413, '请求内容超过大小上限')
    chunks.push(buffer)
  }
  return Buffer.concat(chunks)
}

/**
 * Decide whether a request's Host header is allowed past the fence: loopback
 * authorities always pass, and deployments serving beyond loopback list the
 * exact non-loopback authorities they trust.
 * @param req - the incoming request.
 * @param trustedHosts - configured non-loopback authorities.
 * @returns true when the request may reach the wallpaper routes.
 */
export function isTrustedWallpaperRequest(req: IncomingMessage, trustedHosts: readonly string[]): boolean {
  const host = req.headers.host?.trim().toLowerCase()
  if (host === undefined || host === '') return false
  const colon = host.indexOf(':')
  const hostname = host.startsWith('[') ? host.slice(1, host.indexOf(']')) : colon === -1 ? host : host.slice(0, colon)
  if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') return true
  return trustedHosts.some(entry => entry.toLowerCase() === host || entry.toLowerCase() === hostname)
}

/** Write one JSON response with the content-length precomputed. */
export function writeJson(res: ServerResponse, status: number, value: unknown): void {
  const body = JSON.stringify(value)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
  })
  res.end(body)
}
