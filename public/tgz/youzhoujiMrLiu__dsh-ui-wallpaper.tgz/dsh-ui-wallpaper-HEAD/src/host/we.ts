/**
 * Wallpaper Engine import engine (host half): discovery of the Steam / WE
 * install, reading the workshop index and per-user property state, driving
 * WE's command line (pop-out window, presets, property overrides), and
 * recording the pop-out into a stored mp4 through the shared media store.
 *
 * Recording needs ffmpeg with gdigrab. The engine resolves it in order:
 * user-specified path, the bundled `vendor/ffmpeg/ffmpeg.exe`, `$PATH`, then
 * common install locations — and reports precisely which candidate failed
 * when none works. Wallpaper Engine itself is resolved the same way: a
 * user-specified path (validated against the real executables), the Steam
 * registry/library folders, then the default install directory, and the
 * detected install's `version.json` gates the feature at WE 2.8.0+.
 */
import { execFile, spawn, type ChildProcess } from 'node:child_process'
import { existsSync } from 'node:fs'
import { copyFile, mkdir, mkdtemp, readFile, rename, rm, stat, unlink, writeFile } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import { dirname, extname, join, sep } from 'node:path'
import { tmpdir } from 'node:os'
import {
  encodeWePropertyOverrides, FFMPEG_DOWNLOAD_SOURCES, mergeWeCurrent,
  normalizeWePath, normalizeWeType, parseLibraryFolders,
  parseProjectProperties, parseWeUserState, parseWorkshopCache,
  weVersionSupported, WE_APP_ID, WE_MIN_VERSION, WE_POPOUT_TITLE,
  WE_PREVIEW_EXTENSIONS, type FfmpegInstallState, type WeImportJob,
  type WeImportOptions, type WeStatus, type WeUserState,
  type WeWallpaperDetail, type WeWallpaperInfo,
} from '../model/we.ts'
import { WALLPAPER_API_PATH } from './routes.ts'
import type { WallpaperMediaStore } from './media.ts'

/** Import-job and status wire types re-exported for direct engine consumers. */
export type { WeImportJob, WeStatus, WeUserState } from '../model/we.ts'

/** Engine construction options (composition config plus the media store). */
export interface WeEngineOptions {
  /** Forced Steam root; overrides registry discovery when present. */
  steamRoot?: string | undefined
  /** User-specified WE directory or wallpaper32/64.exe path. */
  wallpaperEnginePath?: string | undefined
  /** User-specified ffmpeg path. */
  ffmpegPath?: string | undefined
  /** Download URL for the first-use ffmpeg install; defaults to gyan.dev. */
  ffmpegDownloadUrl?: string | undefined
  /** Overall recording budget in ms (default 340 s). */
  recordTimeoutMs?: number | undefined
  /** Wait after the pop-out opens before recording (default 6 s). */
  settleMs?: number | undefined
  /** The media store recordings land in. */
  mediaStore: WallpaperMediaStore
}

/** Persisted per-machine overrides (the WE settings form writes these). */
export interface WeSettingsOverrides {
  wallpaperEnginePath?: string | undefined
  ffmpegPath?: string | undefined
}

/** Command exit outcome for the short-lived WE CLI calls. */
interface RunResult {
  code: number | null
  stdout: string
  stderr: string
}

/** One resolved Wallpaper Engine install. */
interface WeDiscovery {
  weDir: string
  cliExe: string
  version: string | undefined
  workshopDirs: string[]
}

/** File-system view the engine reads through (kept simple for the real one). */
export interface WeFileSystem {
  exists(path: string): boolean
  readFile(path: string): Promise<string>
  stat(path: string): Promise<{ isFile(): boolean; size: number } | undefined>
  listDir(path: string): Promise<string[]>
  spawnCli(exe: string, args: string[], cwd: string, timeoutMs: number): Promise<RunResult>
  spawnRecorder(exe: string, args: string[], timeoutMs: number): Promise<{ code: number | null; stderr: string }>
  /** Find an executable on PATH (`where`); undefined when absent. */
  findOnPath(name: string): Promise<string | undefined>
  /** The Steam install path from the registry, or undefined. */
  registrySteamPath(): Promise<string | undefined>
  /** Stream one URL to a local file, reporting received/total bytes. */
  download(url: string, toPath: string, onProgress: (received: number, total: number | undefined) => void, signal: AbortSignal): Promise<void>
  /** Unpack a ZIP archive into a directory (Windows Expand-Archive). */
  expandZip(zipPath: string, toDir: string): Promise<void>
}

const realFileSystem: WeFileSystem = {
  exists: (path) => existsSync(path),
  readFile: async (path) => readFile(path, 'utf8'),
  stat: async (path) => {
    try {
      const info = await stat(path)
      return { isFile: info.isFile.bind(info), size: info.size }
    } catch {
      return undefined
    }
  },
  listDir: async (path) => {
    const { readdir } = await import('node:fs/promises')
    return readdir(path)
  },
  spawnCli: (exe, args, cwd, timeoutMs) => runCommand(exe, args, { cwd, timeoutMs }),
  spawnRecorder: (exe, args, timeoutMs) => runRecorder(exe, args, timeoutMs),
  findOnPath: async (name) => {
    try {
      const result = await runCommand('where', [name], { timeoutMs: 5000 })
      const first = result.stdout.split(/\r?\n/).map(line => line.trim()).find(line => line !== '')
      return first
    } catch {
      return undefined
    }
  },
  registrySteamPath: async () => {
    for (const [root, key, value] of [
      ['HKCU', 'Software\\Valve\\Steam', 'SteamPath'],
      ['HKLM', 'SOFTWARE\\WOW6432Node\\Valve\\Steam', 'InstallPath'],
    ] as const) {
      try {
        const result = await runCommand('reg', ['query', `${root}\\${key}`, '/v', value], { timeoutMs: 10_000 })
        const match = result.stdout.match(/REG_SZ\s+(.+)\s*$/m)
        const path = match?.[1]?.trim()
        if (path !== undefined && path !== '' && existsSync(path)) return path
      } catch {
        // A missing key is ordinary; the next candidate or the default answers.
      }
    }
    return undefined
  },
  download: async (url, toPath, onProgress, signal) => {
    const { createWriteStream } = await import('node:fs')
    const { Readable, Transform } = await import('node:stream')
    const { pipeline } = await import('node:stream/promises')
    const response = await fetch(url, { signal })
    if (!response.ok || response.body === null) throw new Error(`下载失败（HTTP ${response.status}）`)
    const header = response.headers.get('content-length')
    const total = header !== null && Number.isFinite(Number(header)) ? Number(header) : undefined
    let received = 0
    const counter = new Transform({
      transform(chunk: Buffer, _encoding, callback) {
        received += chunk.length
        onProgress(received, total)
        callback(null, chunk)
      },
    })
    await pipeline(Readable.fromWeb(response.body as never), counter, createWriteStream(toPath))
  },
  expandZip: async (zipPath, toDir) => {
    await mkdir(toDir, { recursive: true })
    const result = await runCommand('powershell', [
      '-NoProfile', '-NonInteractive', '-Command',
      `Expand-Archive -LiteralPath '${zipPath.replaceAll("'", "''")}' -DestinationPath '${toDir.replaceAll("'", "''")}' -Force`,
    ], { timeoutMs: 300_000 })
    if (result.code !== 0) throw new Error(`解压失败：${result.stderr.slice(-300)}`)
  },
}

/**
 * The Wallpaper Engine import engine.
 * Discovery is lazy: nothing touches the file system until the first status,
 * list, or import call, so mounting the plugin stays free on machines without
 * WE installed.
 */
export class WeEngine {
  private readonly opts: {
    steamRoot?: string | undefined
    wallpaperEnginePath?: string | undefined
    ffmpegPath?: string | undefined
    ffmpegDownloadUrl?: string | undefined
    recordTimeoutMs: number
    settleMs: number
    mediaStore: WallpaperMediaStore
  }
  private readonly fs: WeFileSystem
  private discovery: WeDiscovery | undefined
  private discoveryError: string | undefined
  private overrides: WeSettingsOverrides | undefined
  private overridesLoaded = false
  private readonly jobs = new Map<string, WeImportJob>()
  private readonly ffmpegInstalls = new Map<string, FfmpegInstallState>()
  private activeInstallId: string | undefined
  private installAbort: AbortController | undefined
  private activeRecorder: ChildProcess | undefined
  private disposed = false

  constructor(options: WeEngineOptions, fs: WeFileSystem = realFileSystem) {
    this.opts = {
      steamRoot: options.steamRoot,
      wallpaperEnginePath: options.wallpaperEnginePath,
      ffmpegPath: options.ffmpegPath,
      ffmpegDownloadUrl: options.ffmpegDownloadUrl,
      recordTimeoutMs: options.recordTimeoutMs ?? 340_000,
      settleMs: options.settleMs ?? 6000,
      mediaStore: options.mediaStore,
    }
    this.fs = fs
  }

  /** One import job by id, or undefined. */
  getImport(id: string): WeImportJob | undefined {
    return this.jobs.get(id)
  }

  /** One ffmpeg installation job by id, or undefined. */
  getFfmpegInstall(id: string): FfmpegInstallState | undefined {
    return this.ffmpegInstalls.get(id)
  }

  /**
   * Start (or join) the first-use ffmpeg installation: downloads the official
   * gyan.dev build into the media root's `ffmpeg` folder, unpacks it with
   * Windows Expand-Archive, and lands `ffmpeg.exe` where the resolver finds
   * it. One installation runs at a time; later callers receive the same id.
   * @returns the installation job id.
   */
  installFfmpeg(): string {
    if (this.disposed) throw new Error('导入引擎已关闭')
    if (this.activeInstallId !== undefined) return this.activeInstallId
    const job: FfmpegInstallState = { id: randomUUID(), state: 'downloading', receivedBytes: 0 }
    this.ffmpegInstalls.set(job.id, job)
    this.activeInstallId = job.id
    void this.runFfmpegInstall(job).catch((error: unknown) => {
      job.state = 'error'
      job.error = error instanceof Error ? error.message : String(error)
    })
    return job.id
  }

  /** Download, unpack, and land ffmpeg.exe for one installation job. */
  private async runFfmpegInstall(job: FfmpegInstallState): Promise<void> {
    const root = this.opts.mediaStore.root
    const installDir = join(root, 'ffmpeg')
    const work = await mkdtemp(join(tmpdir(), 'dsh-ffmpeg-'))
    const zipPath = join(work, 'ffmpeg.zip')
    const extractDir = join(work, 'extract')
    const controller = new AbortController()
    this.installAbort = controller
    try {
      const sources = this.opts.ffmpegDownloadUrl !== undefined && this.opts.ffmpegDownloadUrl !== ''
        ? [this.opts.ffmpegDownloadUrl]
        : [...FFMPEG_DOWNLOAD_SOURCES]
      let lastError: unknown
      for (const url of sources) {
        // Two attempts per source: mid-stream resets are common on slow links.
        for (let attempt = 1; attempt <= 2; attempt += 1) {
          if (controller.signal.aborted) throw new Error('下载已取消')
          try {
            await this.fs.download(url, zipPath, (received, total) => {
              job.receivedBytes = received
              if (total !== undefined && total > 0) job.totalBytes = total
            }, controller.signal)
            lastError = undefined
            break
          } catch (error) {
            lastError = error
            if (attempt < 2) await delay(1500)
          }
        }
        if (lastError === undefined) break
      }
      if (lastError !== undefined) {
        throw new Error(`下载录制组件失败：${lastError instanceof Error ? lastError.message : String(lastError)}（可稍后重试，或在设置中手动指定 ffmpeg 路径）`)
      }
      const zipInfo = await this.fs.stat(zipPath)
      if (zipInfo === undefined || !zipInfo.isFile() || zipInfo.size === 0) throw new Error('下载的 ffmpeg 压缩包为空')
      job.state = 'installing'
      await this.fs.expandZip(zipPath, extractDir)
      const exe = await findFileIn(this.fs, extractDir, 'ffmpeg.exe', 3)
      if (exe === undefined) throw new Error('下载的压缩包中没有找到 ffmpeg.exe，请在设置中手动指定 ffmpeg 路径')
      await mkdir(installDir, { recursive: true })
      await copyOrMove(exe, join(installDir, 'ffmpeg.exe'))
      // Ship the license texts alongside the executable for GPL compliance.
      for (const [name, target] of [['LICENSE', 'LICENSE.txt'], ['README.txt', 'README.txt']] as const) {
        const source = await findFileIn(this.fs, extractDir, name, 2)
        if (source !== undefined) await copyOrMove(source, join(installDir, target)).catch(() => {})
      }
      job.state = 'done'
    } catch (error) {
      job.state = 'error'
      job.error = controller.signal.aborted ? '下载已取消' : error instanceof Error ? error.message : String(error)
    } finally {
      if (this.installAbort === controller) this.installAbort = undefined
      if (this.activeInstallId === job.id) this.activeInstallId = undefined
      await rm(work, { recursive: true, force: true }).catch(() => {})
    }
  }

  /** Report the WE / ffmpeg situation for the settings panel. */
  async status(): Promise<WeStatus> {
    const overrides = await this.loadOverrides()
    const status: WeStatus = { available: false, supported: false, minVersion: WE_MIN_VERSION, workshopDirs: [] }
    status.wallpaperEnginePath = overrides.wallpaperEnginePath ?? this.opts.wallpaperEnginePath ?? ''
    status.ffmpegPath = overrides.ffmpegPath ?? this.opts.ffmpegPath ?? ''

    const configured = status.wallpaperEnginePath
    if (configured !== '') {
      const error = await this.validateWallpaperEnginePath(configured)
      if (error !== undefined) status.wallpaperEnginePathError = error
    }

    const configuredFfmpeg = status.ffmpegPath
    if (configuredFfmpeg !== '') {
      const error = await this.validateFfmpegPath(configuredFfmpeg)
      if (error !== undefined) status.ffmpegPathError = error
    }

    const discovery = await this.discover()
    if (discovery === undefined) {
      status.error = this.discoveryError ?? '未检测到 Wallpaper Engine 安装'
      return status
    }
    status.available = true
    status.weDir = discovery.weDir
    status.cliExe = discovery.cliExe
    status.workshopDirs = discovery.workshopDirs
    if (discovery.version !== undefined) status.version = discovery.version
    if (discovery.version !== undefined && !weVersionSupported(discovery.version)) {
      status.supported = false
      status.error = `Wallpaper Engine 版本 ${discovery.version} 过低，导入功能需要 ${WE_MIN_VERSION} 及以上版本，请更新后重试`
      return status
    }
    status.supported = true
    const ffmpeg = await this.resolveFfmpeg()
    if (ffmpeg !== undefined) status.ffmpeg = ffmpeg
    return status
  }

  /** List every installed WE wallpaper (workshop index with a folder-scan fallback). */
  async listWallpapers(): Promise<WeWallpaperInfo[]> {
    const discovery = await this.requireDiscovery()
    const cachePath = join(discovery.weDir, 'workshopcache.json')
    let entries: WeWallpaperInfo[] = []
    if (this.fs.exists(cachePath)) {
      try {
        entries = parseWorkshopCache(JSON.parse(await this.fs.readFile(cachePath)) as unknown)
      } catch {
        entries = []
      }
    }
    if (entries.length === 0) entries = await this.scanWorkshopDirs(discovery)
    const withPreviews: WeWallpaperInfo[] = []
    for (const entry of entries) {
      withPreviews.push({ ...entry, preview: await this.resolvePreview(entry) })
    }
    return withPreviews
  }

  /** Read one wallpaper's property schema, current values, and presets. */
  async readWallpaperDetail(workshopId: string): Promise<WeWallpaperDetail | undefined> {
    const wallpapers = await this.listWallpapers()
    const wallpaper = wallpapers.find(entry => entry.workshopId === workshopId)
    if (wallpaper === undefined) return undefined
    let project: unknown = {}
    try {
      project = JSON.parse(await this.fs.readFile(wallpaper.project)) as unknown
    } catch {
      return undefined
    }
    const properties = parseProjectProperties(project)
    const discovery = await this.requireDiscovery()
    let userState: WeUserState = { currentByFile: new Map(), presetsByFile: new Map() }
    const configPath = join(discovery.weDir, 'config.json')
    if (this.fs.exists(configPath)) {
      try {
        userState = parseWeUserState(JSON.parse(await this.fs.readFile(configPath)) as unknown)
      } catch {
        // A malformed or locked config.json means no current values this round.
      }
    }
    const fileKey = normalizeWePath(wallpaper.file)
    const current = mergeWeCurrent(properties, userState.currentByFile.get(fileKey))
    const presets = userState.presetsByFile.get(fileKey) ?? []
    return { wallpaper, properties, current, presets }
  }

  /** Read one wallpaper's preview image for the browser list. */
  async readPreview(workshopId: string): Promise<{ bytes: Buffer; mime: string } | undefined> {
    const wallpapers = await this.listWallpapers()
    const wallpaper = wallpapers.find(entry => entry.workshopId === workshopId)
    if (wallpaper === undefined || wallpaper.preview === '') return undefined
    const extension = extname(wallpaper.preview).slice(1).toLowerCase()
    const mime = extension === 'jpg' ? 'image/jpeg' : `image/${extension}`
    if (!WE_PREVIEW_EXTENSIONS.includes(extension as (typeof WE_PREVIEW_EXTENSIONS)[number])) return undefined
    const info = await this.fs.stat(wallpaper.preview)
    if (info === undefined || !info.isFile() || info.size === 0 || info.size > 64 * 1024 * 1024) return undefined
    return { bytes: Buffer.from(await readFile(wallpaper.preview)), mime }
  }

  /** Validate and persist the user's WE / ffmpeg path overrides. */
  async saveSettings(input: unknown): Promise<{ status: WeStatus; error?: string }> {
    const record = typeof input === 'object' && input !== null && !Array.isArray(input) ? input as Record<string, unknown> : {}
    const overrides = await this.loadOverrides()
    const next: WeSettingsOverrides = { ...overrides }
    if (record.wallpaperEnginePath !== undefined) {
      if (typeof record.wallpaperEnginePath !== 'string' || record.wallpaperEnginePath.trim() === '') {
        next.wallpaperEnginePath = undefined
      } else {
        const path = record.wallpaperEnginePath.trim()
        const error = await this.validateWallpaperEnginePath(path)
        if (error !== undefined) {
          const status = await this.status()
          return { status, error: `Wallpaper Engine 路径无效：${error}` }
        }
        next.wallpaperEnginePath = path
      }
    }
    if (record.ffmpegPath !== undefined) {
      if (typeof record.ffmpegPath !== 'string' || record.ffmpegPath.trim() === '') {
        next.ffmpegPath = undefined
      } else {
        const path = record.ffmpegPath.trim()
        const error = await this.validateFfmpegPath(path)
        if (error !== undefined) {
          const status = await this.status()
          return { status, error: `ffmpeg 路径无效：${error}` }
        }
        next.ffmpegPath = path
      }
    }
    await this.persistOverrides(next)
    this.overrides = next
    this.discovery = undefined
    this.discoveryError = undefined
    const status = await this.status()
    return { status }
  }

  /**
   * Start one import in the background; the returned id polls through
   * {@link getImport}. Direct video imports finish in a few seconds without
   * recording; scene/web wallpapers open a WE pop-out window, optionally
   * apply a preset and property overrides, record it with ffmpeg, and close
   * it again — the desktop wallpaper is never touched.
   * @param options - the validated import options.
   * @returns the job id.
   */
  startImport(options: WeImportOptions): string {
    if (this.disposed) throw new Error('导入引擎已关闭')
    const job: WeImportJob = { id: randomUUID(), workshopId: options.workshopId, state: 'preparing' }
    this.jobs.set(job.id, job)
    while (this.jobs.size > 16) {
      const oldest = [...this.jobs.values()].find(candidate => candidate.state === 'done' || candidate.state === 'error')
      if (oldest === undefined) break
      this.jobs.delete(oldest.id)
    }
    void this.runImport(job, options).catch((error: unknown) => {
      job.state = 'error'
      job.error = error instanceof Error ? error.message : String(error)
    })
    return job.id
  }

  /** Close the pop-out and kill any in-flight recording or install (plugin dispose). */
  async dispose(): Promise<void> {
    this.disposed = true
    this.installAbort?.abort()
    if (this.activeRecorder !== undefined && this.activeRecorder.exitCode === null) {
      this.activeRecorder.kill()
    }
    const discovery = this.discovery
    if (discovery !== undefined) {
      await runCommand(discovery.cliExe, ['-control', 'closeWallpaper'], { cwd: discovery.weDir, timeoutMs: 15_000 })
        .catch(() => {})
    }
  }

  /** The discovery path list, ordered: forced config, registry, default. */
  private async steamRoots(): Promise<string[]> {
    const roots = new Set<string>()
    if (this.opts.steamRoot !== undefined && this.opts.steamRoot !== '' && this.fs.exists(this.opts.steamRoot)) {
      roots.add(this.opts.steamRoot)
    }
    const registry = await this.fs.registrySteamPath()
    if (registry !== undefined) roots.add(registry)
    const fallback = join('C:', sep, 'Program Files (x86)', 'Steam')
    if (this.fs.exists(fallback)) roots.add(fallback)
    const expanded = new Set<string>()
    for (const root of roots) {
      const vdfPath = join(root, 'steamapps', 'libraryfolders.vdf')
      let libraries = [root]
      if (this.fs.exists(vdfPath)) {
        try {
          libraries = parseLibraryFolders(await this.fs.readFile(vdfPath), root)
        } catch {
          libraries = [root]
        }
      }
      for (const library of libraries) {
        if (library !== '' && this.fs.exists(library)) expanded.add(library)
      }
    }
    return [...expanded]
  }

  /** Resolve one WE install from the configured override or Steam libraries. */
  private async discover(): Promise<WeDiscovery | undefined> {
    if (this.discovery !== undefined) return this.discovery
    if (this.discoveryError !== undefined) return undefined
    const overrides = await this.loadOverrides()
    const configured = overrides.wallpaperEnginePath ?? this.opts.wallpaperEnginePath ?? ''
    if (configured !== '' && this.fs.exists(configured)) {
      const cliExe = await pickWeCliExe(this.fs, configured)
      if (cliExe !== undefined) {
        const weDir = dirname(cliExe)
        this.discovery = {
          weDir,
          cliExe,
          version: await readWeVersion(this.fs, weDir),
          workshopDirs: await this.workshopDirsFor([weDir]),
        }
        return this.discovery
      }
    }
    for (const root of await this.steamRoots()) {
      const weDir = join(root, 'steamapps', 'common', 'wallpaper_engine')
      if (!this.fs.exists(join(weDir, 'config.json'))) continue
      const cliExe = await pickWeCliExe(this.fs, weDir)
      if (cliExe === undefined) continue
      this.discovery = {
        weDir,
        cliExe,
        version: await readWeVersion(this.fs, weDir),
        workshopDirs: await this.workshopDirsFor(await this.steamRoots()),
      }
      return this.discovery
    }
    this.discoveryError = this.opts.wallpaperEnginePath !== '' || (overrides.wallpaperEnginePath ?? '') !== ''
      ? '未检测到 Wallpaper Engine：请确认已安装 Wallpaper Engine，或检查自定义路径是否指向包含 wallpaper32.exe / wallpaper64.exe 的目录'
      : '未检测到 Wallpaper Engine 或 Steam：请在设置中手动指定 Wallpaper Engine 可执行文件所在目录'
    return undefined
  }

  private async requireDiscovery(): Promise<WeDiscovery> {
    const discovery = await this.discover()
    if (discovery === undefined) throw new Error(this.discoveryError ?? '未检测到 Wallpaper Engine')
    return discovery
  }

  private async workshopDirsFor(roots: string[]): Promise<string[]> {
    const dirs: string[] = []
    for (const root of roots) {
      const dir = join(root, 'steamapps', 'workshop', 'content', WE_APP_ID)
      if (this.fs.exists(dir)) dirs.push(dir)
    }
    return dirs
  }

  /** Folder-scan fallback when workshopcache.json is missing or unreadable. */
  private async scanWorkshopDirs(discovery: WeDiscovery): Promise<WeWallpaperInfo[]> {
    const entries: WeWallpaperInfo[] = []
    for (const dir of discovery.workshopDirs) {
      let folders: string[]
      try {
        folders = await this.fs.listDir(dir)
      } catch {
        continue
      }
      for (const folder of folders) {
        const project = join(dir, folder, 'project.json')
        if (!this.fs.exists(project)) continue
        let parsed: unknown = {}
        try {
          parsed = JSON.parse(await this.fs.readFile(project)) as unknown
        } catch {
          continue
        }
        const record = typeof parsed === 'object' && parsed !== null ? parsed as Record<string, unknown> : {}
        const fileField = typeof record.file === 'string' ? record.file : ''
        if (fileField === '') continue
        const type = normalizeWeType(typeof record.type === 'string' ? record.type : undefined)
        const title = typeof record.title === 'string' && record.title !== '' ? record.title : folder
        entries.push({
          workshopId: /^\d+$/.test(folder) ? folder : '',
          title,
          type,
          file: join(dir, folder, fileField),
          project,
          preview: '',
          tags: '',
          fileSizeBytes: 0,
          local: false,
        })
      }
    }
    return entries
  }

  /** Find the folder-root preview image (preview.gif/jpg/png/webp) for one entry. */
  private async resolvePreview(entry: WeWallpaperInfo): Promise<string> {
    const folder = dirname(entry.project)
    for (const extension of WE_PREVIEW_EXTENSIONS) {
      const candidate = join(folder, `preview.${extension}`)
      if (!this.fs.exists(candidate)) continue
      const info = await this.fs.stat(candidate)
      if (info !== undefined && info.isFile() && info.size > 0) return candidate
    }
    return ''
  }

  private async runImport(job: WeImportJob, options: WeImportOptions): Promise<void> {
    const detail = await this.readWallpaperDetail(options.workshopId)
    if (detail === undefined) throw new Error(`未找到壁纸 ${options.workshopId}，它可能已被取消订阅`)
    const { wallpaper } = detail
    if (wallpaper.type === 'application') throw new Error('应用类壁纸无法导入，请选择场景、视频或网页壁纸')
    if (wallpaper.type === 'video') {
      job.state = 'finishing'
      const extension = extname(wallpaper.file).slice(1).toLowerCase()
      const info = await this.fs.stat(wallpaper.file)
      if (info === undefined || !info.isFile() || info.size === 0) throw new Error('壁纸视频文件不存在或为空')
      if (extension !== 'mp4' && extension !== 'webm' && extension !== 'ogg') throw new Error(`不支持的视频格式 .${extension}`)
      await this.opts.mediaStore.adopt(extension, wallpaper.file)
      job.url = `${WALLPAPER_API_PATH}/media?v=${encodeURIComponent(job.id)}`
      job.kind = 'video'
      job.state = 'done'
      return
    }
    if (wallpaper.type !== 'scene' && wallpaper.type !== 'web') throw new Error('该壁纸类型暂不支持导入')

    const discovery = await this.requireDiscovery()
    if (discovery.version !== undefined && !weVersionSupported(discovery.version)) {
      throw new Error(`Wallpaper Engine 版本 ${discovery.version} 过低，导入功能需要 ${WE_MIN_VERSION} 及以上版本`)
    }
    this.checkPreset(detail, options.preset)

    const ffmpeg = await this.resolveFfmpeg()
    if (ffmpeg === undefined) {
      throw new Error('未找到 ffmpeg：场景/网页壁纸的导入需要录制。请在设置中指定 ffmpeg 路径，或安装 ffmpeg 后重试（视频壁纸无需 ffmpeg，可直接导入）')
    }

    job.state = 'recording'
    const opened = await this.openPopOut(discovery, options, detail)
    const output = join(this.opts.mediaStore.root, `.we-import-${job.id}.mp4`)
    try {
      if (opened && options.properties !== undefined && Object.keys(options.properties).length > 0) {
        await runCommand(discovery.cliExe, ['-control', 'applyProperties', '-properties', encodeWePropertyOverrides(options.properties)], { cwd: discovery.weDir, timeoutMs: 15_000 })
        await delay(1500)
      }
      const { code, stderr } = await this.fs.spawnRecorder(ffmpeg, [
        '-y',
        '-loglevel', 'error',
        '-f', 'gdigrab',
        '-draw_mouse', '0',
        '-framerate', String(options.fps),
        '-i', `title=${WE_POPOUT_TITLE}`,
        '-t', String(options.durationSeconds),
        // The pop-out's physical size follows WE's DPI handling and can land
        // on odd dimensions, which yuv420p rejects — snap to even pixels.
        '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p',
        '-c:v', 'libx264',
        '-preset', 'veryfast',
        '-crf', '18',
        output,
      ], this.opts.recordTimeoutMs)
      if (code !== 0) {
        const tail = stderr.split('\n').filter(line => line.trim() !== '').slice(-3).join(' ')
        throw new Error(`录制失败（ffmpeg）：${tail || '未知错误'}`)
      }
      job.state = 'finishing'
      await this.opts.mediaStore.adopt('mp4', output)
      job.url = `${WALLPAPER_API_PATH}/media?v=${encodeURIComponent(job.id)}`
      job.kind = 'video'
      job.state = 'done'
    } finally {
      await rm(output, { force: true }).catch(() => {})
      await runCommand(discovery.cliExe, ['-control', 'closeWallpaper'], { cwd: discovery.weDir, timeoutMs: 15_000 }).catch(() => {})
    }
  }

  private checkPreset(detail: WeWallpaperDetail, preset: string | undefined): void {
    if (preset === undefined) return
    if (!detail.presets.some(entry => entry.name === preset)) {
      throw new Error(`预设「${preset}」不存在，请重新选择`)
    }
    return
  }

  /** Open the pop-out window; returns true when the CLI call succeeded. */
  private async openPopOut(discovery: WeDiscovery, options: WeImportOptions, detail: WeWallpaperDetail): Promise<boolean> {
    const args = ['-control', 'openWallpaper', '-file', detail.wallpaper.file, '-playInWindow', '-width', String(options.width), '-height', String(options.height), '-borderless', '-activate']
    if (options.preset !== undefined) args.push('-preset', options.preset)
    await runCommand(discovery.cliExe, args, { cwd: discovery.weDir, timeoutMs: 30_000 })
    await delay(this.opts.settleMs)
    // Pin the pop-out above ordinary windows so the recording is never occluded.
    await pinPopOutTopmost()
    return true
  }

  /** Resolve ffmpeg from the override, the installed copy, PATH, and common dirs. */
  private async resolveFfmpeg(): Promise<string | undefined> {
    const overrides = await this.loadOverrides()
    const configured = overrides.ffmpegPath ?? this.opts.ffmpegPath ?? ''
    if (configured !== '') {
      if (await this.validateFfmpegPath(configured) === undefined) return configured
    }
    // The plugin-managed first-use installation wins over anything ambient.
    const installed = join(this.opts.mediaStore.root, 'ffmpeg', 'ffmpeg.exe')
    if (await this.validateFfmpegPath(installed) === undefined) return installed
    if (process.env.FFMPEG_PATH !== undefined && process.env.FFMPEG_PATH !== '') {
      if (await this.validateFfmpegPath(process.env.FFMPEG_PATH) === undefined) return process.env.FFMPEG_PATH
    }
    const onPath = await this.fs.findOnPath('ffmpeg')
    if (onPath !== undefined && await this.validateFfmpegPath(onPath) === undefined) return onPath
    for (const candidate of commonFfmpegPaths()) {
      if (await this.validateFfmpegPath(candidate) === undefined) return candidate
    }
    return undefined
  }

  /** Validate a user-supplied WE path; undefined means usable. */
  private async validateWallpaperEnginePath(path: string): Promise<string | undefined> {
    if (!this.fs.exists(path)) return '路径不存在'
    const info = await this.fs.stat(path)
    if (info !== undefined && info.isFile()) {
      const name = basenameLower(path)
      if (name !== 'wallpaper32.exe' && name !== 'wallpaper64.exe') return '文件不是 wallpaper32.exe 或 wallpaper64.exe'
      return undefined
    }
    const cliExe = await pickWeCliExe(this.fs, path)
    if (cliExe === undefined) return '目录中未找到 wallpaper32.exe 或 wallpaper64.exe'
    return undefined
  }

  /** Validate a user-supplied ffmpeg path; undefined means usable. */
  private async validateFfmpegPath(path: string): Promise<string | undefined> {
    if (!this.fs.exists(path)) return '路径不存在'
    const info = await this.fs.stat(path)
    if (info === undefined || !info.isFile()) return '不是文件'
    const name = basenameLower(path)
    if (name !== 'ffmpeg.exe' && name !== 'ffmpeg') return '文件不是 ffmpeg.exe'
    return undefined
  }

  /** Load the persisted per-machine overrides (`$DSH_HOME/wallpaper/we-settings.json`). */
  private async loadOverrides(): Promise<WeSettingsOverrides> {
    if (this.overridesLoaded) return this.overrides ?? {}
    this.overridesLoaded = true
    const path = join(this.opts.mediaStore.root, 'we-settings.json')
    if (!this.fs.exists(path)) return this.overrides ?? {}
    try {
      const parsed = JSON.parse(await this.fs.readFile(path)) as unknown
      if (typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)) {
        const record = parsed as Record<string, unknown>
        const overrides: WeSettingsOverrides = {}
        if (typeof record.wallpaperEnginePath === 'string' && record.wallpaperEnginePath !== '') {
          overrides.wallpaperEnginePath = record.wallpaperEnginePath
        }
        if (typeof record.ffmpegPath === 'string' && record.ffmpegPath !== '') {
          overrides.ffmpegPath = record.ffmpegPath
        }
        this.overrides = overrides
      }
    } catch {
      this.overrides = {}
    }
    return this.overrides ?? {}
  }

  private async persistOverrides(overrides: WeSettingsOverrides): Promise<void> {
    await mkdir(this.opts.mediaStore.root, { recursive: true })
    const path = join(this.opts.mediaStore.root, 'we-settings.json')
    const staging = join(this.opts.mediaStore.root, `.we-settings.${randomUUID()}`)
    await writeFile(staging, JSON.stringify({ wallpaperEnginePath: overrides.wallpaperEnginePath, ffmpegPath: overrides.ffmpegPath }, null, 2))
    await rename(staging, path)
    this.overridesLoaded = true
    this.overrides = overrides
  }
}

/** Run one short-lived command and capture its exit code and output. */
function runCommand(command: string, args: string[], options: { cwd?: string; timeoutMs: number }): Promise<RunResult> {
  return new Promise((resolvePromise, reject) => {
    execFile(command, args, { cwd: options.cwd, timeout: options.timeoutMs, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error !== null) {
        const killed = (error as NodeJS.ErrnoException & { killed?: boolean }).killed === true
        const code = killed ? null : (error as NodeJS.ErrnoException & { code?: number | string }).code ?? null
        if (code !== null && typeof code === 'number') {
          resolvePromise({ code, stdout: String(stdout), stderr: String(stderr) })
          return
        }
        reject(new Error(`命令执行失败：${command} — ${killed ? '超时' : error.message}`))
        return
      }
      resolvePromise({ code: 0, stdout: String(stdout), stderr: String(stderr) })
    })
  })
}

/** Run the long-lived recorder; resolves on exit, rejects on timeout. */
function runRecorder(exe: string, args: string[], timeoutMs: number): Promise<{ code: number | null; stderr: string }> {
  return new Promise((resolvePromise, reject) => {
    const child = spawn(exe, args, { windowsHide: true })
    let stderr = ''
    const timer = setTimeout(() => {
      child.kill()
      reject(new Error('录制超时，已中止'))
    }, timeoutMs)
    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString('utf8')
      if (stderr.length > 64 * 1024) stderr = stderr.slice(-64 * 1024)
    })
    child.on('error', (error) => {
      clearTimeout(timer)
      reject(new Error(`无法启动录制程序：${error.message}`))
    })
    child.on('close', (code) => {
      clearTimeout(timer)
      resolvePromise({ code, stderr })
    })
  })
}

/** Pick the WE CLI executable matching the machine's bitness when possible. */
async function pickWeCliExe(fs: WeFileSystem, weDir: string): Promise<string | undefined> {
  const candidates = process.arch === 'x64'
    ? ['wallpaper64.exe', 'wallpaper32.exe']
    : ['wallpaper32.exe', 'wallpaper64.exe']
  for (const name of candidates) {
    const path = join(weDir, name)
    if (fs.exists(path)) return path
  }
  return undefined
}

/** Read the WE version.json version field. */
async function readWeVersion(fs: WeFileSystem, weDir: string): Promise<string | undefined> {
  const path = join(weDir, 'version.json')
  if (!fs.exists(path)) return undefined
  try {
    const parsed = JSON.parse(await fs.readFile(path)) as unknown
    if (typeof parsed === 'object' && parsed !== null) {
      const version = (parsed as Record<string, unknown>).version
      if (typeof version === 'string') return version
    }
  } catch {
    return undefined
  }
  return undefined
}


/** Search a directory tree (bounded depth) for one file name. */
async function findFileIn(fs: WeFileSystem, dir: string, name: string, maxDepth: number): Promise<string | undefined> {
  const direct = join(dir, name)
  if (fs.exists(direct)) return direct
  if (maxDepth <= 0) return undefined
  let entries: string[]
  try {
    entries = await fs.listDir(dir)
  } catch {
    return undefined
  }
  for (const entry of entries) {
    const child = join(dir, entry)
    const info = await fs.stat(child)
    if (info !== undefined && !info.isFile()) {
      const found = await findFileIn(fs, child, name, maxDepth - 1)
      if (found !== undefined) return found
    }
  }
  return undefined
}

/** Rename with a cross-device copy fallback (workshop may live on another drive). */
async function copyOrMove(fromPath: string, toPath: string): Promise<void> {
  try {
    await rename(fromPath, toPath)
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code
    if (code !== 'EXDEV') throw error
    await copyFile(fromPath, toPath)
    await unlink(fromPath)
  }
}

/** Common ffmpeg install locations probed last. */
function commonFfmpegPaths(): string[] {
  const candidates: string[] = []
  for (const env of ['ProgramFiles', 'ProgramFiles(x86)', 'LOCALAPPDATA']) {
    const value = process.env[env]
    if (value !== undefined && value !== '') candidates.push(join(value, 'ffmpeg', 'bin', 'ffmpeg.exe'))
  }
  candidates.push(join('C:', sep, 'ffmpeg', 'bin', 'ffmpeg.exe'))
  candidates.push(join('D:', sep, 'ffmpeg', 'bin', 'ffmpeg.exe'))
  candidates.push(join('E:', sep, 'ffmpeg', 'bin', 'ffmpeg.exe'))
  return candidates
}

/** Pin the pop-out window topmost so the recording is never occluded. */
async function pinPopOutTopmost(): Promise<void> {
  const script = [
    '$sig = @"',
    'using System;',
    'using System.Runtime.InteropServices;',
    'public class WePin {',
    '  [DllImport("user32.dll")] public static extern IntPtr FindWindow(string cls, string title);',
    '  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);',
    '}',
    '"@',
    'Add-Type -TypeDefinition $sig',
    '$h = [WePin]::FindWindow("WPEOverlappedWallpaper", "Wallpaper Pop-out")',
    'if ($h -ne [IntPtr]::Zero) { [WePin]::SetWindowPos($h, [IntPtr](-1), 0, 0, 0, 0, 0x0001 -bor 0x0002) | Out-Null }',
  ].join('\n')
  const file = join(tmpdir(), `dsh-we-pin-${randomUUID()}.ps1`)
  await writeFile(file, script)
  try {
    await runCommand('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', file], { timeoutMs: 20_000 })
  } catch {
    // Pinning is best-effort: -activate already brought the window forward.
  } finally {
    await rm(file, { force: true }).catch(() => {})
  }
}

function basenameLower(path: string): string {
  const base = path.split(/[\\/]/).pop() ?? ''
  return base.toLowerCase()
}

function delay(ms: number): Promise<void> {
  return new Promise(resolvePromise => { setTimeout(resolvePromise, ms) })
}

export { runCommand, runRecorder }
