/**
 * Wallpaper Engine import routes, mounted under `/dsh-wallpaper/we`:
 * detection status, the wallpaper list, per-wallpaper details (property
 * schema, current values, presets), preview images, background import jobs,
 * and the per-machine path overrides form. Everything sits behind the same
 * browser trust fence as the media routes; workshop ids are numeric only, so
 * no request can address an arbitrary file.
 */
import type { IncomingMessage, ServerResponse } from 'node:http'
import {
  validateWeImportOptions, WeImportValidationError, type WeImportOptions,
} from '../model/we.ts'
import { readBody, WallpaperHttpError, writeJson } from './guard.ts'
import type { WeEngine } from './we.ts'

/** Maximum accepted JSON body for the import and settings routes. */
const MAX_BODY_BYTES = 64 * 1024

/** Route construction options resolved by the host apply. */
export interface WeRoutesOptions {
  engine: WeEngine
  trustedHosts: readonly string[]
}

/**
 * Build the /dsh-wallpaper/we request handler.
 * @param options - the import engine and the trust fence authorities.
 * @returns the handler for the `we` segment of the wallpaper prefix.
 */
export function createWeRoutes(options: WeRoutesOptions): { handle(req: IncomingMessage, res: ServerResponse, segments: readonly string[]): Promise<void> } {
  const { engine } = options
  return {
    async handle(req, res, segments) {
      try {
        const url = new URL(req.url ?? '/', 'http://localhost')
        const method = req.method
        const [sub] = segments
        if (method === 'GET' && sub === 'status') {
          writeJson(res, 200, await engine.status())
          return
        }
        if (method === 'GET' && sub === 'settings') {
          const status = await engine.status()
          writeJson(res, 200, {
            wallpaperEnginePath: status.wallpaperEnginePath ?? '',
            ffmpegPath: status.ffmpegPath ?? '',
          })
          return
        }
        if (method === 'POST' && sub === 'settings') {
          const bytes = await readBody(req, MAX_BODY_BYTES)
          let parsed: unknown
          try {
            parsed = JSON.parse(bytes.toString('utf8'))
          } catch {
            throw new WallpaperHttpError(400, '设置不是有效的 JSON')
          }
          const result = await engine.saveSettings(parsed)
          if (result.error !== undefined) {
            writeJson(res, 400, { error: result.error, status: result.status })
            return
          }
          writeJson(res, 200, { status: result.status })
          return
        }
        if (method === 'GET' && sub === 'list') {
          writeJson(res, 200, { wallpapers: await engine.listWallpapers() })
          return
        }
        if (method === 'GET' && sub === 'detail') {
          const workshopId = url.searchParams.get('workshopId') ?? ''
          if (!/^\d{1,12}$/.test(workshopId)) throw new WallpaperHttpError(400, '无效的壁纸 ID')
          const detail = await engine.readWallpaperDetail(workshopId)
          if (detail === undefined) throw new WallpaperHttpError(404, '未找到该壁纸，它可能已被取消订阅')
          writeJson(res, 200, detail)
          return
        }
        if (method === 'GET' && sub === 'preview') {
          const workshopId = url.searchParams.get('workshopId') ?? ''
          if (!/^\d{1,12}$/.test(workshopId)) throw new WallpaperHttpError(400, '无效的壁纸 ID')
          const preview = await engine.readPreview(workshopId)
          if (preview === undefined) throw new WallpaperHttpError(404, '该壁纸没有预览图')
          res.writeHead(200, {
            'content-type': preview.mime,
            'content-length': preview.bytes.length,
            'cache-control': 'no-cache',
            'x-content-type-options': 'nosniff',
          })
          res.end(preview.bytes)
          return
        }
        if (method === 'POST' && sub === 'import') {
          const bytes = await readBody(req, MAX_BODY_BYTES)
          let options: WeImportOptions
          try {
            options = validateWeImportOptions(JSON.parse(bytes.toString('utf8')) as unknown)
          } catch (error) {
            if (error instanceof WeImportValidationError) throw new WallpaperHttpError(400, error.message)
            throw new WallpaperHttpError(400, '导入参数不是有效的 JSON')
          }
          const jobId = engine.startImport(options)
          writeJson(res, 200, { jobId })
          return
        }
        if (method === 'GET' && sub === 'import') {
          const id = url.searchParams.get('id') ?? ''
          const job = engine.getImport(id)
          if (job === undefined) throw new WallpaperHttpError(404, '找不到该导入任务')
          writeJson(res, 200, job)
          return
        }
        if (method === 'POST' && sub === 'ffmpeg') {
          const installId = engine.installFfmpeg()
          writeJson(res, 200, { installId })
          return
        }
        if (method === 'GET' && sub === 'ffmpeg') {
          const id = url.searchParams.get('id') ?? ''
          const install = engine.getFfmpegInstall(id)
          if (install === undefined) throw new WallpaperHttpError(404, '找不到该下载任务')
          writeJson(res, 200, install)
          return
        }
        throw new WallpaperHttpError(404, 'not found')
      } catch (error) {
        const status = error instanceof WallpaperHttpError ? error.status : 500
        const message = error instanceof Error ? error.message : String(error)
        writeJson(res, status, { error: message })
      }
    },
  }
}
