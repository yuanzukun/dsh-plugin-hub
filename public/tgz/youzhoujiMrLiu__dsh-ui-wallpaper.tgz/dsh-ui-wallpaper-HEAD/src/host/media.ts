/**
 * The one stored-format media file under `$DSH_HOME/wallpaper`: uploads and
 * Wallpaper Engine imports write through the same atomic replace so both
 * paths share pruning and serving semantics.
 */
import { mkdir, rename, rm, stat, writeFile } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import { join } from 'node:path'
import type { ServerResponse } from 'node:http'
import { WALLPAPER_FORMATS } from '../model/wallpaper.ts'

/** One stored-format filename (the extension is the MIME authority). */
function mediaFileName(format: { readonly extension: string }): string {
  return `media.${format.extension}`
}

/** The writable media store both import paths share. */
export interface WallpaperMediaStore {
  /** The storage root directory. */
  readonly root: string
  /** Replace the stored media with the given bytes. */
  write(extension: string, bytes: Buffer): Promise<void>
  /** Atomically move a finished file into place (imported media). */
  adopt(extension: string, fromPath: string): Promise<void>
  /** Serve the one stored media file; false when none exists. */
  serve(res: ServerResponse): Promise<boolean>
}

/**
 * Create the media store for one storage root.
 * @param root - `$DSH_HOME/wallpaper`.
 * @returns the shared store.
 */
export function createWallpaperMediaStore(root: string): WallpaperMediaStore {
  return {
    root,
    write: (extension, bytes) => writeMedia(root, extension, bytes),
    adopt: (extension, fromPath) => adoptMedia(root, extension, fromPath),
    serve: (res) => serveMedia(root, res),
  }
}

/** Write the accepted bytes under `media.<extension>` and prune older formats. */
async function writeMedia(root: string, extension: string, bytes: Buffer): Promise<void> {
  const target = join(root, mediaFileName({ extension }))
  const staging = join(root, `.${mediaFileName({ extension })}.${randomUUID()}`)
  await mkdir(root, { recursive: true })
  await writeFile(staging, bytes)
  await rename(staging, target)
  await pruneStaleMedia(root, target)
}

/** Move a finished recording into `media.<extension>` and prune older formats. */
async function adoptMedia(root: string, extension: string, fromPath: string): Promise<void> {
  const target = join(root, mediaFileName({ extension }))
  const info = await stat(fromPath)
  if (!info.isFile() || info.size === 0) throw new Error('录制文件不存在或为空')
  await mkdir(root, { recursive: true })
  try {
    await rename(fromPath, target)
  } catch (error) {
    // Cross-device renames fail with EXDEV (workshop content often lives on a
    // different drive than $DSH_HOME); fall back to a copy then remove.
    const code = (error as NodeJS.ErrnoException).code
    if (code !== 'EXDEV') throw error
    const { copyFile, unlink } = await import('node:fs/promises')
    await copyFile(fromPath, target)
    await unlink(fromPath)
  }
  await pruneStaleMedia(root, target)
}

/** Serve the one stored media file; a missing file is an ordinary 404. */
async function serveMedia(root: string, res: ServerResponse): Promise<boolean> {
  for (const format of WALLPAPER_FORMATS) {
    const filePath = join(root, mediaFileName(format))
    if (!await isFile(filePath)) continue
    const { readFile } = await import('node:fs/promises')
    const bytes = await readFile(filePath)
    res.writeHead(200, {
      'content-type': format.mime,
      'content-length': bytes.length,
      'cache-control': 'no-cache',
      'x-content-type-options': 'nosniff',
    })
    res.end(bytes)
    return true
  }
  return false
}

async function isFile(path: string): Promise<boolean> {
  try {
    return (await stat(path)).isFile()
  } catch {
    return false
  }
}

/** Remove stored files of every accepted format except the one just written. */
async function pruneStaleMedia(root: string, keep: string): Promise<void> {
  for (const format of WALLPAPER_FORMATS) {
    const filePath = join(root, mediaFileName(format))
    if (filePath !== keep) await rm(filePath, { force: true })
  }
}
