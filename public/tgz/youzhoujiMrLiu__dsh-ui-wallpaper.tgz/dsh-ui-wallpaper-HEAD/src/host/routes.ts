/**
 * Wallpaper HTTP routes mounted under /dsh-wallpaper: a raw-file POST that
 * stores one user-picked media file under `$DSH_HOME/wallpaper`, a GET that
 * serves it back to the browser, and the Wallpaper Engine import routes on
 * the `/we` segment. Every route sits behind the browser trust fence
 * (loopback or configured authorities), the MIME whitelist is the shared
 * client/host model, and bodies are bounded before they touch disk.
 */
import { randomUUID } from 'node:crypto'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { WALLPAPER_FORMATS, wallpaperFormatByMime } from '../model/wallpaper.ts'
import { isTrustedWallpaperRequest, readBody, WallpaperHttpError, writeJson } from './guard.ts'
import { createWallpaperMediaStore } from './media.ts'
import { createWeRoutes } from './we-routes.ts'
import type { WeEngine } from './we.ts'

/** The webserver prefix these routes mount under. */
export const WALLPAPER_API_PATH = '/dsh-wallpaper'

/** Route construction options resolved by the host apply. */
export interface WallpaperRoutesOptions {
  /** `$DSH_HOME/wallpaper` — the one writable media root. */
  root: string
  /** Maximum accepted upload body in bytes. */
  maxBytes: number
  /** Non-loopback authorities allowed past the trust fence. */
  trustedHosts: readonly string[]
  /** The Wallpaper Engine import engine. */
  engine: WeEngine
}

/**
 * Build the /dsh-wallpaper request handler.
 * @param options - storage root, upload bound, trust fence authorities, and import engine.
 * @returns the handler registered on the webserver prefix.
 */
export function createWallpaperRoutes(options: WallpaperRoutesOptions): { handle(req: IncomingMessage, res: ServerResponse): Promise<void> } {
  const media = createWallpaperMediaStore(options.root)
  const weRoutes = createWeRoutes({ engine: options.engine, trustedHosts: options.trustedHosts })
  return {
    async handle(req, res) {
      if (!isTrustedWallpaperRequest(req, options.trustedHosts)) {
        writeJson(res, 403, { error: 'forbidden' })
        return
      }
      try {
        const url = new URL(req.url ?? '/', 'http://localhost')
        const segments = url.pathname.split('/').filter(segment => segment !== '')
        const method = req.method
        if (segments[1] === 'we') {
          await weRoutes.handle(req, res, segments.slice(2))
          return
        }
        if (method === 'GET' && segments.length === 2 && segments[1] === 'media') {
          await serveMedia(res)
          return
        }
        if (method === 'POST' && segments.length === 2 && segments[1] === 'media') {
          await uploadMedia(req, res)
          return
        }
        writeJson(res, 404, { error: 'not found' })
      } catch (error) {
        const status = error instanceof WallpaperHttpError ? error.status : 500
        const message = error instanceof Error ? error.message : String(error)
        writeJson(res, status, { error: message })
      }
    },
  }

  /** Read and validate the raw upload body, then replace the stored media atomically. */
  async function uploadMedia(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const contentType = req.headers['content-type']?.split(';', 1)[0]?.trim().toLowerCase() ?? ''
    const format = wallpaperFormatByMime(contentType)
    if (format === undefined) throw new WallpaperHttpError(415, '不支持的文件类型，请选择图片或视频')
    const bytes = await readBody(req, options.maxBytes)
    if (bytes.length === 0) throw new WallpaperHttpError(400, '缺少文件内容')
    await media.write(format.extension, bytes)
    const revision = randomUUID()
    writeJson(res, 200, {
      url: `${WALLPAPER_API_PATH}/media?v=${encodeURIComponent(revision)}`,
      kind: format.kind,
    })
  }

  /** Serve the one stored media file; a missing file is an ordinary 404. */
  async function serveMedia(res: ServerResponse): Promise<void> {
    const served = await media.serve(res)
    if (!served) throw new WallpaperHttpError(404, '壁纸不存在')
  }
}

/** Accepted formats re-exported for callers reading the whitelist directly. */
export { WALLPAPER_FORMATS }
