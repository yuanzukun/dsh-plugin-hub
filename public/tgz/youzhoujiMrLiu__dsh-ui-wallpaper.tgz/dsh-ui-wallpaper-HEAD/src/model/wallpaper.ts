/**
 * Shared wallpaper media model: the MIME/extension whitelist consumed by the
 * host upload route and the client picker, plus the render-mode mapping shared
 * by the frame layer and the settings preview.
 */

/** One media kind supported by the wallpaper layer. */
export type WallpaperKind = 'image' | 'video'

/** User-facing layout modes; `tile` only applies to images. */
export type WallpaperMode = 'tile' | 'cover' | 'contain' | 'stretch'

/** CSS `background-repeat`/`object-fit` presentation resolved from the layout mode. */
export type WallpaperRenderMode = 'tile' | 'cover' | 'contain' | 'fill'

/** MIME type, storage extension, and media kind of one accepted format. */
export interface WallpaperMediaFormat {
  /** Canonical MIME type sent by the picker and echoed by the host route. */
  readonly mime: string
  /** Lowercase filename extension used under `$DSH_HOME/wallpaper`. */
  readonly extension: string
  /** Media kind derived from the MIME type. */
  readonly kind: WallpaperKind
}

/** The complete accepted-format whitelist (source of truth for both planes). */
export const WALLPAPER_FORMATS: readonly WallpaperMediaFormat[] = [
  { mime: 'image/png', extension: 'png', kind: 'image' },
  { mime: 'image/jpeg', extension: 'jpg', kind: 'image' },
  { mime: 'image/gif', extension: 'gif', kind: 'image' },
  { mime: 'image/webp', extension: 'webp', kind: 'image' },
  { mime: 'image/avif', extension: 'avif', kind: 'image' },
  { mime: 'image/svg+xml', extension: 'svg', kind: 'image' },
  { mime: 'video/mp4', extension: 'mp4', kind: 'video' },
  { mime: 'video/webm', extension: 'webm', kind: 'video' },
  { mime: 'video/ogg', extension: 'ogg', kind: 'video' },
]

/** `accept` attribute value for the settings file input. */
export const WALLPAPER_ACCEPT = WALLPAPER_FORMATS.map(format => format.mime).join(',')

/** User-facing layout options in settings order. */
export const WALLPAPER_MODES: readonly WallpaperMode[] = ['tile', 'cover', 'contain', 'stretch']

/**
 * Resolve an accepted format from a MIME type.
 * @param mime - raw header or File.type value; parameters are ignored.
 * @returns the matching format, or undefined when the type is not accepted.
 */
export function wallpaperFormatByMime(mime: string): WallpaperMediaFormat | undefined {
  const normalized = (mime.split(';', 1)[0] as string).trim().toLowerCase()
  if (normalized === '') return undefined
  return WALLPAPER_FORMATS.find(format => format.mime === normalized)
}

/**
 * Resolve an accepted format from a local filename extension (the picker
 * fallback when a browser reports an empty File.type).
 * @param name - local filename.
 * @returns the matching format, or undefined when the extension is not accepted.
 */
export function wallpaperFormatByFileName(name: string): WallpaperMediaFormat | undefined {
  const dot = name.lastIndexOf('.')
  if (dot < 0) return undefined
  const extension = name.slice(dot + 1).toLowerCase()
  if (extension === '') return undefined
  return WALLPAPER_FORMATS.find(format => format.extension === extension)
}

/**
 * Resolve the CSS presentation mode for one selection.
 * @param mode - user-selected layout mode.
 * @param kind - selected media kind.
 * @returns tile for images only; videos fall back to cover and stretch becomes fill.
 */
export function wallpaperRenderMode(mode: WallpaperMode, kind: WallpaperKind): WallpaperRenderMode {
  if (mode === 'tile') return kind === 'image' ? 'tile' : 'cover'
  if (mode === 'stretch') return 'fill'
  return mode
}

/** Brightness slider floor: 20% — dark enough to matter, never fully black. */
export const WALLPAPER_BRIGHTNESS_MIN = 0.2

/** Brightness slider ceiling: 200%. */
export const WALLPAPER_BRIGHTNESS_MAX = 2

/** Brightness slider step (5 percentage points per tick). */
export const WALLPAPER_BRIGHTNESS_STEP = 0.05

/** Neutral brightness (100%); also the fallback for pre-brightness preferences. */
export const WALLPAPER_BRIGHTNESS_DEFAULT = 1

/**
 * Normalize a brightness multiplier into the slider bounds. Missing and NaN
 * values collapse to neutral: preferences persisted before the brightness
 * feature shipped have no such field, and those states must render unchanged.
 * @param value - raw multiplier; undefined for legacy states.
 * @returns the clamped multiplier, neutral when the value is unusable.
 */
export function wallpaperBrightness(value: number | undefined): number {
  if (value === undefined || Number.isNaN(value)) return WALLPAPER_BRIGHTNESS_DEFAULT
  return Math.min(WALLPAPER_BRIGHTNESS_MAX, Math.max(WALLPAPER_BRIGHTNESS_MIN, value))
}

/**
 * CSS filter for one brightness multiplier. The filter applies to the whole
 * surface element, so one mechanism covers images, GIFs, and videos alike —
 * including the repeating-background tile presentation.
 * @param value - raw multiplier; normalized by {@link wallpaperBrightness}.
 * @returns the `brightness(...)` filter value.
 */
export function wallpaperBrightnessFilter(value: number | undefined): string {
  return `brightness(${wallpaperBrightness(value)})`
}

/**
 * Rounded display percent for the settings slider readout.
 * @param value - raw multiplier; normalized by {@link wallpaperBrightness}.
 * @returns the rounded integer percent (20–200).
 */
export function wallpaperBrightnessPercent(value: number | undefined): number {
  return Math.round(wallpaperBrightness(value) * 100)
}

/** Playback-speed floor: 0.1×. */
export const WALLPAPER_SPEED_MIN = 0.1

/** Playback-speed ceiling: 5×. */
export const WALLPAPER_SPEED_MAX = 5

/** Neutral playback speed (1×); also the fallback for pre-speed preferences. */
export const WALLPAPER_SPEED_DEFAULT = 1

/** Step below 1×: 0.1 per press. */
export const WALLPAPER_SPEED_FINE_STEP = 0.1

/** Step from 1× up: 0.5 per press. */
export const WALLPAPER_SPEED_COARSE_STEP = 0.5

/**
 * Normalize a playback-speed multiplier into the bounds with 0.1 precision.
 * undefined and NaN collapse to neutral: preferences persisted before the
 * speed feature shipped have no such field, and those states must play at
 * native speed.
 * @param value - raw multiplier (typed input or button arithmetic).
 * @returns the clamped multiplier rounded to one decimal, neutral when unusable.
 */
export function wallpaperPlaybackSpeed(value: number | undefined): number {
  if (value === undefined || Number.isNaN(value)) return WALLPAPER_SPEED_DEFAULT
  const clamped = Math.min(WALLPAPER_SPEED_MAX, Math.max(WALLPAPER_SPEED_MIN, value))
  return Math.round(clamped * 10) / 10
}

/**
 * The step the speed-up button applies at a given value: fine (0.1) below
 * 1×, coarse (0.5) from 1× up.
 * @param value - current normalized multiplier.
 * @returns the step amount for one press.
 */
export function wallpaperSpeedStepUp(value: number): number {
  return value < WALLPAPER_SPEED_DEFAULT ? WALLPAPER_SPEED_FINE_STEP : WALLPAPER_SPEED_COARSE_STEP
}

/**
 * The step the slow-down button applies at a given value: coarse (0.5) above
 * 1×, fine (0.1) from 1× down.
 * @param value - current normalized multiplier.
 * @returns the step amount for one press.
 */
export function wallpaperSpeedStepDown(value: number): number {
  return value > WALLPAPER_SPEED_DEFAULT ? WALLPAPER_SPEED_COARSE_STEP : WALLPAPER_SPEED_FINE_STEP
}

/**
 * Human-facing multiplier label for the speed readout.
 * @param value - raw multiplier; normalized by {@link wallpaperPlaybackSpeed}.
 * @returns the label (e.g. `1.5×`).
 */
export function wallpaperPlaybackSpeedLabel(value: number | undefined): string {
  return `${wallpaperPlaybackSpeed(value)}×`
}
