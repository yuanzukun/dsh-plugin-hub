/**
 * Shared Wallpaper Engine import model: the wire types and pure parsers both
 * planes consume. Host-side discovery, CLI driving, and recording live in
 * `src/host/we.ts`; the browser import panel renders this shape unchanged.
 * Everything here is dependency-free so the client bundle and the node half
 * stay one shared source of truth.
 */
import type { WallpaperKind } from './wallpaper.ts'

/** Wallpaper Engine's Steam app id; its workshop content lives under this key. */
export const WE_APP_ID = '431960'

/** The four official WE wallpaper kinds plus a catch-all for future types. */
export type WeWallpaperType = 'scene' | 'video' | 'web' | 'application' | 'unknown'

/** One WE wallpaper entry (normalized from workshopcache.json or a folder scan). */
export interface WeWallpaperInfo {
  /** Numeric workshop id; empty string for non-workshop local wallpapers. */
  readonly workshopId: string
  readonly title: string
  readonly type: WeWallpaperType
  /** The file WE launches: scene.pkg, the video file, or index.html. */
  readonly file: string
  /** The project.json path. */
  readonly project: string
  /** Local preview image path (may be empty when the wallpaper ships none). */
  readonly preview: string
  readonly tags: string
  readonly fileSizeBytes: number
  /** True for local (non-workshop) wallpapers, which import only by path. */
  readonly local: boolean
}

/** Property control kinds WE exposes; anything else falls back to a text input. */
export type WePropertyType = 'bool' | 'slider' | 'combo' | 'color' | 'text'

/** One option of a combo property. */
export interface WeComboOption {
  readonly label: string
  readonly value: string
}

/** One user-facing property from project.json's `general.properties`. */
export interface WePropertySchema {
  readonly type: WePropertyType
  /** Author label; values starting with `ui_` are engine keys — show the name. */
  readonly text: string
  /** The schema default value. */
  readonly value: unknown
  readonly min?: number
  readonly max?: number
  readonly step?: number
  readonly options?: readonly WeComboOption[]
}

/** One named preset from config.json's `wpresets`. */
export interface WePreset {
  readonly name: string
  readonly properties: Record<string, unknown>
}

/** Everything the import panel needs for one wallpaper. */
export interface WeWallpaperDetail {
  readonly wallpaper: WeWallpaperInfo
  readonly properties: Record<string, WePropertySchema>
  /** Effective current values: the user's saved values over the schema defaults. */
  readonly current: Record<string, unknown>
  readonly presets: readonly WePreset[]
}

/** Import request the client posts to the host. */
export interface WeImportOptions {
  readonly workshopId: string
  /** Recording length in seconds (direct video copies ignore it). */
  readonly durationSeconds: number
  /** Pop-out window size in CSS pixels. */
  readonly width: number
  readonly height: number
  /** Recording frame rate (direct video copies ignore it). */
  readonly fps: number
  /** Named preset from the wallpaper's `wpresets`. */
  readonly preset?: string
  /** Property overrides applied to the pop-out before recording. */
  readonly properties?: Record<string, unknown>
}

/** One import job as reported to the client while it runs. */
export interface WeImportJob {
  readonly id: string
  readonly workshopId: string
  state: 'preparing' | 'recording' | 'finishing' | 'done' | 'error'
  error?: string
  url?: string
  kind?: WallpaperKind
}

/** WE discovery snapshot reported by the status route. */
export interface WeStatus {
  available: boolean
  supported: boolean
  version?: string
  minVersion: string
  weDir?: string
  cliExe?: string
  workshopDirs: string[]
  /** Error explaining why the feature is unavailable, when it is. */
  error?: string
  ffmpeg?: string
  /** The user-configured WE path, echoed back for the settings form. */
  wallpaperEnginePath?: string
  /** Validation failure for the user-configured WE path, when set. */
  wallpaperEnginePathError?: string
  /** The user-configured ffmpeg path, echoed back for the settings form. */
  ffmpegPath?: string
  /** Validation failure for the user-configured ffmpeg path, when set. */
  ffmpegPathError?: string
}

/** Accepted import parameter bounds. */
export const WE_IMPORT_BOUNDS = {
  durationSeconds: { min: 1, max: 300, default: 30 },
  fps: { min: 1, max: 60, default: 30 },
  size: { min: 320, max: 7680 },
} as const

/** A failed validation carries one user-facing message. */
export class WeImportValidationError extends Error {}

/** The WE pop-out window title; gdigrab captures it by this name. */
export const WE_POPOUT_TITLE = 'Wallpaper Pop-out'

/**
 * The official ffmpeg Windows build sources the plugin downloads on first
 * use when no usable ffmpeg exists, tried in order: the BtbN GitHub release
 * (globally CDN-cached) first, then gyan.dev. Both are GPLv3 builds shipped
 * as ZIPs Windows Expand-Archive can unpack. `we.ffmpegDownloadUrl` config
 * replaces this list with one mirror URL.
 */
export const FFMPEG_DOWNLOAD_SOURCES = [
  'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip',
  'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip',
] as const

/** The download size the settings panel advertises (approximate, for the label). */
export const FFMPEG_DOWNLOAD_SIZE_LABEL = '100–170 MB'

/** One background ffmpeg installation job as reported to the client. */
export interface FfmpegInstallState {
  readonly id: string
  state: 'downloading' | 'installing' | 'done' | 'error'
  /** Bytes received so far (approximate; updates per chunk). */
  receivedBytes: number
  /** Total bytes when the server reports a content length. */
  totalBytes?: number
  error?: string
}

/**
 * Minimum Wallpaper Engine version whose command line drives the pop-out
 * window, preset application, and property overrides this import relies on.
 * Verified against 2.8.42; earlier releases predate the pop-out workflow.
 */
export const WE_MIN_VERSION = '2.8.0'

/**
 * Compare two dotted numeric versions ("2.8.42"); suffixes are ignored.
 * @returns negative when `a` is older, zero when equal, positive when newer.
 */
export function compareWeVersions(a: string, b: string): number {
  const parse = (value: string): number[] => value
    .split(/[.-]/)
    .map(part => Number.parseInt(part, 10))
    .filter(part => Number.isFinite(part))
  const left = parse(a)
  const right = parse(b)
  const length = Math.max(left.length, right.length)
  for (let i = 0; i < length; i += 1) {
    const l = left[i] ?? 0
    const r = right[i] ?? 0
    if (l !== r) return l - r
  }
  return 0
}

/** Whether one WE version meets the minimum the import feature requires. */
export function weVersionSupported(version: string, min = WE_MIN_VERSION): boolean {
  return compareWeVersions(version, min) >= 0
}

/** Preview image extensions served to the import panel (gif renders animated). */
export const WE_PREVIEW_EXTENSIONS = ['gif', 'jpg', 'png', 'webp'] as const

/** Normalize a WE type label into the wire union. */
export function normalizeWeType(raw: string | undefined): WeWallpaperType {
  switch ((raw ?? '').trim().toLowerCase()) {
    case 'scene': return 'scene'
    case 'video': return 'video'
    case 'web': return 'web'
    case 'application': return 'application'
    default: return 'unknown'
  }
}

/** Parse one workshopcache.json document into wallpaper entries. */
export function parseWorkshopCache(doc: unknown): WeWallpaperInfo[] {
  const raw = Array.isArray(doc) ? doc : isRecord(doc) && Array.isArray(doc.wallpapers) ? doc.wallpapers : []
  const entries: WeWallpaperInfo[] = []
  for (const item of raw) {
    if (!isRecord(item)) continue
    const file = typeof item.file === 'string' ? item.file : ''
    const project = typeof item.project === 'string' ? item.project : ''
    if (file === '' || project === '') continue
    // Preset entries have no project of their own; keep them out of the list.
    if (item.ispreset === true) continue
    const workshopId = typeof item.workshopid === 'string' ? item.workshopid : ''
    const title = typeof item.title === 'string' && item.title !== '' ? item.title : `Wallpaper ${workshopId}`
    entries.push({
      workshopId,
      title,
      type: normalizeWeType(typeof item.type === 'string' ? item.type : undefined),
      file,
      project,
      preview: '',
      tags: typeof item.tags === 'string' ? item.tags : '',
      fileSizeBytes: typeof item.filesize === 'number' ? item.filesize : 0,
      local: item.local === true || workshopId === '',
    })
  }
  return entries
}

/** The labels of WE property schema types that map to a plain text input. */
const TEXT_PROPERTY_TYPES = new Set(['text', 'file', 'directory', 'font'])

/** Normalize one project.json `general.properties` entry. */
export function parseProjectProperties(project: unknown): Record<string, WePropertySchema> {
  if (!isRecord(project)) return {}
  const general = project.general
  if (!isRecord(general) || !isRecord(general.properties)) return {}
  const out: Record<string, WePropertySchema> = {}
  for (const [name, raw] of Object.entries(general.properties)) {
    if (!isRecord(raw)) continue
    const rawType = typeof raw.type === 'string' ? raw.type : 'text'
    let type: WePropertyType = 'text'
    if (rawType === 'bool') type = 'bool'
    else if (rawType === 'slider' || rawType === 'float' || rawType === 'int') type = 'slider'
    else if (rawType === 'combo') type = 'combo'
    else if (rawType === 'color') type = 'color'
    else if (!TEXT_PROPERTY_TYPES.has(rawType)) type = 'text'
    const options = type === 'combo' && Array.isArray(raw.options)
      ? raw.options.filter(isRecord).map(option => ({
        label: typeof option.label === 'string' ? option.label : String(option.value ?? ''),
        value: String(option.value ?? ''),
      }))
      : undefined
    out[name] = {
      type,
      text: typeof raw.text === 'string' ? raw.text : name,
      value: raw.value,
      ...(typeof raw.min === 'number' ? { min: raw.min } : {}),
      ...(typeof raw.max === 'number' ? { max: raw.max } : {}),
      ...(typeof raw.step === 'number' ? { step: raw.step } : {}),
      ...(options !== undefined ? { options } : {}),
    }
  }
  return out
}

/** User-facing label for one property: author text unless it is an engine key. */
export function wePropertyLabel(name: string, schema: WePropertySchema): string {
  const text = schema.text.trim()
  if (text === '' || text.startsWith('ui_')) return name
  return text
}

/** The parsed per-user state WE persists in its config.json. */
export interface WeUserState {
  /** Current property values keyed by normalized wallpaper file path. */
  readonly currentByFile: ReadonlyMap<string, Record<string, unknown>>
  /** Named presets keyed by normalized wallpaper file path. */
  readonly presetsByFile: ReadonlyMap<string, readonly WePreset[]>
}

/** Normalize a WE file path for map keys (Windows separators to `/`). */
export function normalizeWePath(path: string): string {
  return path.replaceAll('\\', '/')
}

/** Parse config.json's `wproperties` and `wpresets` sections. */
export function parseWeUserState(doc: unknown): WeUserState {
  const currentByFile = new Map<string, Record<string, unknown>>()
  const presetsByFile = new Map<string, readonly WePreset[]>()
  if (!isRecord(doc) || !isRecord(doc.admin)) return { currentByFile, presetsByFile }
  const admin = doc.admin
  const general = isRecord(admin.general) ? admin.general : {}
  // `wproperties` lives directly under admin; `wpresets` under admin.general.
  // Both are probed in each location so config layout drift stays harmless.
  for (const container of [admin, general]) {
    if (isRecord(container.wproperties)) {
      for (const [file, monitors] of Object.entries(container.wproperties)) {
        if (!isRecord(monitors)) continue
        // The pop-out instance takes the first monitor's values as its base.
        const first = Object.values(monitors).find(isRecord)
        if (first !== undefined) currentByFile.set(normalizeWePath(file), pickScalars(first))
      }
    }
  }
  for (const container of [general, admin]) {
    if (!isRecord(container.wpresets)) continue
    for (const [file, entry] of Object.entries(container.wpresets)) {
      if (!isRecord(entry) || !Array.isArray(entry.presets)) continue
      const presets: WePreset[] = []
      for (const preset of entry.presets) {
        if (!isRecord(preset) || typeof preset.name !== 'string' || !isRecord(preset.properties)) continue
        presets.push({ name: preset.name, properties: pickScalars(preset.properties) })
      }
      if (presets.length > 0) presetsByFile.set(normalizeWePath(file), presets)
    }
  }
  return { currentByFile, presetsByFile }
}

/** Keep only scalar property values (booleans, finite numbers, strings). */
function pickScalars(record: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(record)) {
    if (typeof value === 'boolean' || typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value))) {
      out[key] = value
    }
  }
  return out
}

/** Merge the user's current values over the schema defaults for one wallpaper. */
export function mergeWeCurrent(
  properties: Record<string, WePropertySchema>,
  current: Record<string, unknown> | undefined,
): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [name, schema] of Object.entries(properties)) out[name] = schema.value
  for (const [name, value] of Object.entries(current ?? {})) out[name] = value
  return out
}

/**
 * Convert a WE color property value into the `#rrggbb` hex a browser color
 * picker consumes. WE stores colors as `"R G B"` strings with each component
 * in 0–1 (e.g. `"0.5 0.5 0.5"`); components outside that range clamp and any
 * extra components (alpha) are ignored. Returns undefined when the value has
 * no three usable numbers.
 * @param value - raw property value from project.json / config.json.
 * @returns the six-digit hex color, or undefined when unparseable.
 */
export function weColorToHex(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const parts = value.trim().split(/\s+/).map(component => Number(component))
  if (parts.length < 3 || parts.slice(0, 3).some(component => !Number.isFinite(component))) return undefined
  return `#${parts.slice(0, 3).map(component => Math.round(Math.min(1, Math.max(0, component)) * 255).toString(16).padStart(2, '0')).join('')}`
}

/**
 * Convert a `#rrggbb` picker value back into WE's `"R G B"` string format
 * (each component a float in 0–1 at full precision, so the hex round trip is
 * exact). Unusable input collapses to black, mirroring the picker fallback.
 * @param hex - the picker value.
 * @returns the WE-format color string.
 */
export function weColorFromHex(hex: string): string {
  const match = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex.trim())
  if (match === null) return '0 0 0'
  const channels = [match[1], match[2], match[3]].map(pair => Number.parseInt(pair!, 16) / 255)
  return channels.join(' ')
}

/** Encode one property override set for the `applyProperties -properties` CLI. */
export function encodeWePropertyOverrides(properties: Record<string, unknown>): string {
  const parts: string[] = []
  for (const [key, value] of Object.entries(properties)) {
    if (!/^[A-Za-z0-9_.]+$/.test(key)) throw new WeImportValidationError(`属性名不合法：${key}`)
    const text = String(value)
    if (text === '' || text.includes('=') || text.includes(',')) {
      throw new WeImportValidationError(`属性 ${key} 的值无法通过命令行传递，请先在 Wallpaper Engine 中调整`)
    }
    parts.push(`${key}=${text}`)
  }
  return parts.join(',')
}

/**
 * Validate and normalize one raw import request into the host shape.
 * Throws {@link WeImportValidationError} with a user-facing message on
 * anything unusable; numbers clamp into the shared bounds.
 * @param input - the parsed request body (unknown JSON).
 * @returns the normalized options.
 */
export function validateWeImportOptions(input: unknown): WeImportOptions {
  if (!isRecord(input)) throw new WeImportValidationError('缺少导入参数')
  const workshopId = typeof input.workshopId === 'string' ? input.workshopId : ''
  if (!/^\d{1,12}$/.test(workshopId)) throw new WeImportValidationError('无效的壁纸 ID')
  const preset = typeof input.preset === 'string' && input.preset !== ''
    ? (input.preset.length <= 64 ? input.preset : undefined)
    : undefined
  if (input.preset !== undefined && input.preset !== '' && preset === undefined) {
    throw new WeImportValidationError('预设名过长')
  }
  const properties: Record<string, unknown> | undefined = (() => {
    if (!isRecord(input.properties)) return undefined
    const out: Record<string, unknown> = {}
    for (const [key, value] of Object.entries(input.properties)) {
      if (!/^[A-Za-z0-9_.]{1,64}$/.test(key)) throw new WeImportValidationError(`属性名不合法：${key}`)
      if (typeof value === 'boolean' || (typeof value === 'number' && Number.isFinite(value))) {
        out[key] = value
      } else if (typeof value === 'string' && value.length > 0 && value.length <= 256) {
        out[key] = value
      } else {
        throw new WeImportValidationError(`属性 ${key} 的值不合法`)
      }
      if (Object.keys(out).length > 64) throw new WeImportValidationError('属性数量过多')
    }
    return Object.keys(out).length > 0 ? out : undefined
  })()
  return {
    workshopId,
    durationSeconds: clampNumber(input.durationSeconds, WE_IMPORT_BOUNDS.durationSeconds.min, WE_IMPORT_BOUNDS.durationSeconds.max, WE_IMPORT_BOUNDS.durationSeconds.default),
    fps: clampNumber(input.fps, WE_IMPORT_BOUNDS.fps.min, WE_IMPORT_BOUNDS.fps.max, WE_IMPORT_BOUNDS.fps.default),
    width: clampNumber(input.width, WE_IMPORT_BOUNDS.size.min, WE_IMPORT_BOUNDS.size.max, 1920),
    height: clampNumber(input.height, WE_IMPORT_BOUNDS.size.min, WE_IMPORT_BOUNDS.size.max, 1080),
    ...(preset !== undefined ? { preset } : {}),
    ...(properties !== undefined ? { properties } : {}),
  }
}

/** Parse the `libraryfolders.vdf` Steam manifest into library root paths. */
export function parseLibraryFolders(text: string, fallbackRoot: string): string[] {
  const roots: string[] = []
  const seen = new Set<string>()
  for (const match of text.matchAll(/"path"\s+"((?:[^"\\]|\\.)*)"/g)) {
    const raw = match[1] ?? ''
    const unescaped = raw.replaceAll('\\\\', '\\')
    if (unescaped !== '' && !seen.has(unescaped)) {
      seen.add(unescaped)
      roots.push(unescaped)
    }
  }
  if (roots.length === 0 && fallbackRoot !== '') roots.push(fallbackRoot)
  return roots
}

/** Clamp one raw number field into bounds, defaulting when unusable. */
function clampNumber(raw: unknown, min: number, max: number, fallback: number): number {
  if (typeof raw !== 'number' || !Number.isFinite(raw)) return fallback
  return Math.min(max, Math.max(min, Math.round(raw)))
}

/** Narrow an unknown to a plain object record. */
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
