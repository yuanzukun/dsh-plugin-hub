// @vitest-environment jsdom
// Speed-controlled GIF surface: native image at 1× with no fetch, fetch +
// decode + canvas only for non-native speeds on GIF media, and native image
// fallback for non-GIF content types, failed fetches, and undecodable bytes.

import { cleanup, render, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { GifSurface, type GifSurfaceProps } from '../src/client/GifSurface.tsx'

const GIF_BYTES = 'R0lGODlhAQABAIEAAP8AAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQIFAAAACwAAAAAAQABAAAIBAABBAQAIfkEBQoAAAAsAAAAAAEAAQCBAAD/AAAAAAAAAAAACAQAAQQEADs='

function gifResponse(contentType = 'IMAGE/GIF; charset=binary'): Response {
  const bytes = Buffer.from(GIF_BYTES, 'base64')
  const body = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer
  return new Response(body, { status: 200, headers: { 'content-type': contentType } })
}

function mount(props: Partial<GifSurfaceProps> = {}) {
  return render(<GifSurface src="/dsh-wallpaper/media?v=1" speed={2} objectFit="cover" {...props} />)
}

afterEach(() => {
  cleanup()
  document.body.innerHTML = ''
  vi.restoreAllMocks()
  vi.unstubAllGlobals()
})

describe('GifSurface', () => {
  it('renders the native image at 1× without fetching', () => {
    const fetchMock = vi.fn()
    vi.stubGlobal('fetch', fetchMock)
    mount({ speed: 1 })
    const image = document.querySelector('img')
    expect(image?.getAttribute('src')).toBe('/dsh-wallpaper/media?v=1')
    expect(document.querySelector('canvas')).toBeNull()
    expect(fetchMock).not.toHaveBeenCalled()
  })

  it('fetches and decodes a GIF into a sized canvas at non-native speed', async () => {
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(null)
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(gifResponse())))
    mount()
    await waitFor(() => { expect(document.querySelector('canvas')).not.toBeNull() })
    const canvas = document.querySelector('canvas')
    expect(canvas?.getAttribute('width')).toBe('1')
    expect(canvas?.getAttribute('height')).toBe('1')
    expect(document.querySelector('img')).toBeNull()
  })

  it('falls back to the native image when the media is not a GIF', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(
      new Response(new ArrayBuffer(0), { status: 200, headers: { 'content-type': 'image/png' } }),
    )))
    mount()
    await waitFor(() => { expect(document.querySelector('img')).not.toBeNull() })
    expect(document.querySelector('canvas')).toBeNull()
  })

  it('falls back to the native image when the response is not ok', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(
      new Response('missing', { status: 404, headers: { 'content-type': 'image/gif' } }),
    )))
    mount()
    await waitFor(() => { expect(document.querySelector('img')).not.toBeNull() })
    expect(document.querySelector('canvas')).toBeNull()
  })

  it('falls back to the native image when the fetch rejects', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.reject(new Error('network down'))))
    mount()
    await waitFor(() => { expect(document.querySelector('img')).not.toBeNull() })
    expect(document.querySelector('canvas')).toBeNull()
  })

  it('falls back to the native image when the bytes do not decode', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(
      new Response(new ArrayBuffer(4), { status: 200, headers: { 'content-type': 'image/gif' } }),
    )))
    mount()
    await waitFor(() => { expect(document.querySelector('img')).not.toBeNull() })
    expect(document.querySelector('canvas')).toBeNull()
  })

  it('returns to the native image when the speed returns to 1×', async () => {
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(null)
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(gifResponse())))
    const view = mount()
    await waitFor(() => { expect(document.querySelector('canvas')).not.toBeNull() })
    view.rerender(<GifSurface src="/dsh-wallpaper/media?v=1" speed={1} objectFit="cover" />)
    expect(document.querySelector('canvas')).toBeNull()
    expect(document.querySelector('img')).not.toBeNull()
  })

  it('ignores a late non-GIF resolution after unmount', async () => {
    let resolveFetch: (response: Response) => void = () => {}
    vi.stubGlobal('fetch', vi.fn(() => new Promise<Response>(resolve => { resolveFetch = resolve })))
    const view = mount()
    view.unmount()
    resolveFetch(new Response(new ArrayBuffer(0), { status: 200, headers: { 'content-type': 'image/png' } }))
    await new Promise(resolve => setTimeout(resolve, 0))
    expect(document.querySelector('canvas')).toBeNull()
    expect(document.querySelector('img')).toBeNull()
  })

  it('ignores a late fetch failure after unmount', async () => {
    let rejectFetch: (error: Error) => void = () => {}
    vi.stubGlobal('fetch', vi.fn(() => new Promise<Response>((_resolve, reject) => { rejectFetch = reject })))
    const view = mount()
    view.unmount()
    rejectFetch(new Error('late failure'))
    await new Promise(resolve => setTimeout(resolve, 0))
    expect(document.querySelector('canvas')).toBeNull()
    expect(document.querySelector('img')).toBeNull()
  })

  it('ignores a late fetch resolution after unmount', async () => {
    let resolveFetch: (response: Response) => void = () => {}
    vi.stubGlobal('fetch', vi.fn(() => new Promise<Response>(resolve => { resolveFetch = resolve })))
    const view = mount()
    view.unmount()
    resolveFetch(gifResponse())
    await new Promise(resolve => setTimeout(resolve, 0))
    expect(document.querySelector('canvas')).toBeNull()
    expect(document.querySelector('img')).toBeNull()
  })
})
