// Pure Wallpaper Engine import model: type normalization, workshop-cache and
// project parsing, per-user property state, preset encoding, import-option
// validation, version gating, and the Steam library manifest.

import { describe, expect, it } from 'vitest'
import {
  compareWeVersions, encodeWePropertyOverrides, mergeWeCurrent, normalizeWePath,
  normalizeWeType, parseLibraryFolders, parseProjectProperties,
  parseWeUserState, parseWorkshopCache, validateWeImportOptions,
  weColorFromHex, weColorToHex, wePropertyLabel, weVersionSupported,
  WeImportValidationError, WE_MIN_VERSION,
} from '../src/model/we.ts'

describe('normalizeWeType', () => {
  it('maps the four engine labels and falls back to unknown', () => {
    expect(normalizeWeType('Scene')).toBe('scene')
    expect(normalizeWeType('Video')).toBe('video')
    expect(normalizeWeType('web')).toBe('web')
    expect(normalizeWeType('APPLICATION')).toBe('application')
    expect(normalizeWeType('future-type')).toBe('unknown')
    expect(normalizeWeType(undefined)).toBe('unknown')
  })
})

describe('parseWorkshopCache', () => {
  it('reads the wallpapers array and skips preset and malformed entries', () => {
    const entries = parseWorkshopCache({
      user: 'x',
      version: 1,
      wallpapers: [
        {
          file: 'D:/Steam/steamapps/workshop/content/431960/1/scene.pkg',
          project: 'D:/Steam/steamapps/workshop/content/431960/1/project.json',
          title: 'A Scene',
          type: 'Scene',
          tags: 'Wallpaper,Scene,Anime',
          filesize: 123,
          workshopid: '1',
        },
        {
          file: 'D:/Steam/steamapps/workshop/content/431960/2/movie.mp4',
          project: 'D:/Steam/steamapps/workshop/content/431960/2/project.json',
          title: 'A Video',
          type: 'Video',
          filesize: 456,
          workshopid: '2',
        },
        { ispreset: true, file: 'D:/x/scene.pkg', project: 'D:/x/project.json' },
        { file: '', project: '' },
        null,
      ],
    })
    expect(entries).toHaveLength(2)
    expect(entries[0]).toMatchObject({ workshopId: '1', title: 'A Scene', type: 'scene', fileSizeBytes: 123 })
    expect(entries[1]).toMatchObject({ workshopId: '2', title: 'A Video', type: 'video' })
    expect(parseWorkshopCache('garbage')).toEqual([])
  })
})

describe('parseProjectProperties', () => {
  it('normalizes every control type and carries slider bounds and combo options', () => {
    const properties = parseProjectProperties({
      general: {
        properties: {
          clock: { type: 'bool', text: 'Clock', value: true },
          rate: { type: 'slider', text: 'Speed', value: 30, min: 1, max: 100, step: 1 },
          quality: { type: 'combo', text: 'Quality', value: 'high', options: [{ label: 'High', value: 'high' }, { label: 'Low', value: 'low' }] },
          tint: { type: 'color', text: 'Tint', value: '0.5 0.5 0.5' },
          caption: { type: 'text', text: 'Caption', value: 'hello' },
          schemecolor: { type: 'color', text: 'ui_browse_properties_scheme_color', value: '0 0 0' },
        },
      },
    })
    expect(properties.clock).toMatchObject({ type: 'bool', value: true })
    expect(properties.rate).toMatchObject({ type: 'slider', min: 1, max: 100, step: 1 })
    expect(properties.quality?.options).toEqual([{ label: 'High', value: 'high' }, { label: 'Low', value: 'low' }])
    expect(properties.tint?.type).toBe('color')
    expect(properties.caption?.type).toBe('text')
    expect(wePropertyLabel('schemecolor', properties.schemecolor!)).toBe('schemecolor')
    expect(wePropertyLabel('clock', properties.clock!)).toBe('Clock')
    expect(parseProjectProperties({})).toEqual({})
    expect(parseProjectProperties(null)).toEqual({})
  })
})

describe('parseWeUserState', () => {
  it('reads per-file current values and named presets, normalizing path separators', () => {
    const state = parseWeUserState({
      admin: {
        general: {
          wproperties: {
            'D:\\Steam\\steamapps\\workshop\\content\\431960\\1\\scene.pkg': {
              Monitor0: { clock: false, rate: 32, volume: 0, junk: { nested: true } },
              Monitor1: { clock: true },
            },
          },
          wpresets: {
            'D:/Steam/steamapps/workshop/content/431960/1/scene.pkg': {
              presets: [{ name: '夜晚', properties: { clock: false, tint: '0.1 0.1 0.2' } }],
            },
          },
        },
      },
    })
    const key = normalizeWePath('D:/Steam/steamapps/workshop/content/431960/1/scene.pkg')
    expect(state.currentByFile.get(key)).toEqual({ clock: false, rate: 32, volume: 0 })
    expect(state.presetsByFile.get(key)).toEqual([{ name: '夜晚', properties: { clock: false, tint: '0.1 0.1 0.2' } }])
    expect(parseWeUserState({}).currentByFile.size).toBe(0)
  })

  it('also reads wproperties from directly under admin (the real config layout)', () => {
    const state = parseWeUserState({
      admin: {
        wproperties: {
          'D:/Steam/steamapps/workshop/content/431960/1/scene.pkg': { Monitor0: { clock: true } },
        },
        general: {},
      },
    })
    const key = normalizeWePath('D:/Steam/steamapps/workshop/content/431960/1/scene.pkg')
    expect(state.currentByFile.get(key)).toEqual({ clock: true })
  })
})

describe('mergeWeCurrent', () => {
  it('overlays saved values onto the schema defaults', () => {
    const merged = mergeWeCurrent(
      { clock: { type: 'bool', text: 'Clock', value: true } },
      { clock: false },
    )
    expect(merged).toEqual({ clock: false })
  })
})

describe('encodeWePropertyOverrides', () => {
  it('joins scalars into the CLI key=value format', () => {
    expect(encodeWePropertyOverrides({ clock: false, rate: 32 })).toBe('clock=false,rate=32')
  })

  it('rejects keys and values the CLI cannot carry', () => {
    expect(() => encodeWePropertyOverrides({ 'bad key': true })).toThrow(WeImportValidationError)
    expect(() => encodeWePropertyOverrides({ clock: 'a,b' })).toThrow(WeImportValidationError)
    expect(() => encodeWePropertyOverrides({ clock: '' })).toThrow(WeImportValidationError)
  })
})

describe('validateWeImportOptions', () => {
  it('normalizes a full request', () => {
    const options = validateWeImportOptions({
      workshopId: '2921844318',
      durationSeconds: 15,
      fps: 30,
      width: 1920,
      height: 1080,
      preset: '夜晚',
      properties: { clock: false },
    })
    expect(options).toEqual({
      workshopId: '2921844318', durationSeconds: 15, fps: 30, width: 1920, height: 1080,
      preset: '夜晚', properties: { clock: false },
    })
  })

  it('clamps numbers and defaults missing fields', () => {
    const options = validateWeImportOptions({ workshopId: '1', durationSeconds: 99999, fps: -5, width: 100, height: 900000 })
    expect(options.durationSeconds).toBe(300)
    expect(options.fps).toBe(1)
    expect(options.width).toBe(320)
    expect(options.height).toBe(7680)
    expect(options.preset).toBeUndefined()
    expect(options.properties).toBeUndefined()
  })

  it('rejects unusable ids, presets, and property values', () => {
    expect(() => validateWeImportOptions({})).toThrow('无效的壁纸 ID')
    expect(() => validateWeImportOptions({ workshopId: '../../etc' })).toThrow('无效的壁纸 ID')
    expect(() => validateWeImportOptions({ workshopId: '1', preset: 'x'.repeat(100) })).toThrow('预设名过长')
    expect(() => validateWeImportOptions({ workshopId: '1', properties: { clock: { nested: true } } })).toThrow('不合法')
    expect(() => validateWeImportOptions({ workshopId: '1', properties: { 'clock=': true } })).toThrow('不合法')
  })
})

describe('version gating', () => {
  it('compares dotted versions numerically', () => {
    expect(compareWeVersions('2.8.42', '2.8.0')).toBeGreaterThan(0)
    expect(compareWeVersions('2.7.0', WE_MIN_VERSION)).toBeLessThan(0)
    expect(compareWeVersions('2.8.0', '2.8.0')).toBe(0)
    expect(compareWeVersions('3.0', '2.99.99')).toBeGreaterThan(0)
  })

  it('gates the feature at the minimum version', () => {
    expect(weVersionSupported('2.8.42')).toBe(true)
    expect(weVersionSupported('2.8.0')).toBe(true)
    expect(weVersionSupported('2.7.9')).toBe(false)
    expect(weVersionSupported('1.0')).toBe(false)
  })
})

describe('parseLibraryFolders', () => {
  it('extracts library paths from the Valve manifest', () => {
    const text = [
      '"libraryfolders"',
      '{',
      '\t"0"',
      '\t{',
      '\t\t"path"\t\t"D:\\\\SteamLibrary"',
      '\t}',
      '\t"1"',
      '\t{',
      '\t\t"path"\t\t"E:\\\\Games"',
      '\t}',
      '}',
    ].join('\n')
    expect(parseLibraryFolders(text, 'C:\\Steam')).toEqual(['D:\\SteamLibrary', 'E:\\Games'])
  })

  it('falls back to the given root when nothing matches', () => {
    expect(parseLibraryFolders('no paths here', 'C:\\Steam')).toEqual(['C:\\Steam'])
  })
})

describe('weColorToHex / weColorFromHex', () => {
  it('converts WE "R G B" floats into picker hex, clamping and ignoring extras', () => {
    expect(weColorToHex('0.5 0.5 0.5')).toBe('#808080')
    expect(weColorToHex('1 0 0')).toBe('#ff0000')
    expect(weColorToHex('0 0 0')).toBe('#000000')
    expect(weColorToHex(' 0.2  0.4  0.6 ')).toBe('#336699')
    expect(weColorToHex('0 0 0 0')).toBe('#000000')
    expect(weColorToHex('-1 0.5 2')).toBe('#0080ff')
  })

  it('returns undefined for values that are not three usable numbers', () => {
    expect(weColorToHex('')).toBeUndefined()
    expect(weColorToHex('red')).toBeUndefined()
    expect(weColorToHex('0.5 0.5')).toBeUndefined()
    expect(weColorToHex(123)).toBeUndefined()
    expect(weColorToHex(undefined)).toBeUndefined()
  })

  it('converts picker hex back into WE floats and round-trips exactly', () => {
    expect(weColorFromHex('#ff0000')).toBe('1 0 0')
    expect(weColorFromHex('#000000')).toBe('0 0 0')
    // Float channels use JS shortest round-trip precision; compare the
    // component math directly rather than a brittle string literal.
    expect(weColorFromHex('3f6fa0')).toBe([63, 111, 160].map(channel => String(channel / 255)).join(' '))
    expect(weColorToHex(weColorFromHex('#3f6fa0'))).toBe('#3f6fa0')
    expect(weColorFromHex('garbage')).toBe('0 0 0')
  })
})
