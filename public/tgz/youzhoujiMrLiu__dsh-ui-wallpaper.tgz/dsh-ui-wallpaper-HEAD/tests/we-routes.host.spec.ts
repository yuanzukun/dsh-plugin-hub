// Wallpaper Engine import routes over a fake engine and a real HTTP server:
// status, settings persistence and validation, the wallpaper list, details,
// preview bytes, background import jobs, and generic failures. The trust
// fence itself is owned by the outer route and covered in routes.host.spec.

import { createServer, type Server } from 'node:http'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createWeRoutes } from '../src/host/we-routes.ts'
import type { WeEngine } from '../src/host/we.ts'
import type { WeImportJob, WeStatus, WeWallpaperDetail } from '../src/model/we.ts'

interface FakeEngine {
  status: WeEngine['status']
  listWallpapers: WeEngine['listWallpapers']
  readWallpaperDetail: WeEngine['readWallpaperDetail']
  readPreview: WeEngine['readPreview']
  saveSettings: WeEngine['saveSettings']
  startImport: WeEngine['startImport']
  getImport: WeEngine['getImport']
  installFfmpeg: WeEngine['installFfmpeg']
  getFfmpegInstall: WeEngine['getFfmpegInstall']
}

const STATUS: WeStatus = { available: true, supported: true, version: '2.8.42', minVersion: '2.8.0', weDir: 'D:/WE', workshopDirs: ['D:/workshop'] }

function fakeEngine(overrides: Partial<FakeEngine> = {}): FakeEngine {
  return {
    status: vi.fn(() => Promise.resolve(STATUS)),
    listWallpapers: vi.fn(() => Promise.resolve([])),
    readWallpaperDetail: vi.fn(() => Promise.resolve(undefined)),
    readPreview: vi.fn(() => Promise.resolve(undefined)),
    saveSettings: vi.fn(() => Promise.resolve({ status: STATUS })),
    startImport: vi.fn(() => 'job-1'),
    getImport: vi.fn(() => undefined),
    installFfmpeg: vi.fn(() => 'install-1'),
    getFfmpegInstall: vi.fn(() => undefined),
    ...overrides,
  }
}

let server: Server | undefined
let port = 0
let engine: FakeEngine

beforeEach(async () => {
  engine = fakeEngine()
  const routes = createWeRoutes({ engine: engine as unknown as WeEngine, trustedHosts: [] })
  server = createServer(async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost')
    const segments = url.pathname.split('/').filter(segment => segment !== '')
    await routes.handle(req, res, segments)
  })
  await new Promise<void>((resolvePromise) => { server!.listen(0, '127.0.0.1', resolvePromise) })
  port = (server.address() as { port: number }).port
})

afterEach(async () => {
  await new Promise<void>((resolvePromise) => { server?.close(() => resolvePromise()) })
  server = undefined
})

async function request(path: string, init?: RequestInit): Promise<{ status: number; json: unknown; bytes: Buffer }> {
  const response = await fetch(`http://127.0.0.1:${String(port)}${path}`, init)
  const bytes = Buffer.from(await response.arrayBuffer())
  let json: unknown
  try {
    json = JSON.parse(bytes.toString('utf8'))
  } catch {
    json = undefined
  }
  return { status: response.status, json, bytes }
}

describe('we status and settings routes', () => {
  it('serves the status snapshot', async () => {
    const response = await request('/status')
    expect(response.status).toBe(200)
    expect(response.json).toMatchObject({ version: '2.8.42', supported: true })
  })

  it('persists valid path overrides through the engine', async () => {
    const response = await request('/settings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ wallpaperEnginePath: 'D:\\WE', ffmpegPath: 'D:\\ffmpeg\\bin\\ffmpeg.exe' }),
    })
    expect(response.status).toBe(200)
    expect(engine.saveSettings).toHaveBeenCalledWith({ wallpaperEnginePath: 'D:\\WE', ffmpegPath: 'D:\\ffmpeg\\bin\\ffmpeg.exe' })
  })

  it('surfaces engine-side validation failures with their message', async () => {
    engine.saveSettings = vi.fn(() => Promise.resolve({ status: STATUS, error: 'Wallpaper Engine 路径无效：目录中未找到 wallpaper32.exe 或 wallpaper64.exe' }))
    const response = await request('/settings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ wallpaperEnginePath: 'C:\\nothing' }),
    })
    expect(response.status).toBe(400)
    expect(response.json).toMatchObject({ error: expect.stringContaining('路径无效') })
  })

  it('rejects a non-JSON settings body', async () => {
    const response = await request('/settings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: 'not json',
    })
    expect(response.status).toBe(400)
  })

  it('bounds oversized settings bodies', async () => {
    const response = await request('/settings', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: 'x'.repeat(70 * 1024),
    })
    expect(response.status).toBe(413)
  })
})

describe('we list and detail routes', () => {
  it('serves the wallpaper list', async () => {
    engine.listWallpapers = vi.fn(() => Promise.resolve([
      { workshopId: '1', title: 'A', type: 'scene' as const, file: 'D:/a.pkg', project: 'D:/a.json', preview: '', tags: '', fileSizeBytes: 0, local: false },
    ]))
    const response = await request('/list')
    expect(response.status).toBe(200)
    expect(response.json).toMatchObject({ wallpapers: [{ workshopId: '1', title: 'A' }] })
  })

  it('serves one wallpaper detail and 404s missing ones', async () => {
    const detail: WeWallpaperDetail = {
      wallpaper: { workshopId: '1', title: 'A', type: 'scene', file: 'D:/a.pkg', project: 'D:/a.json', preview: '', tags: '', fileSizeBytes: 0, local: false },
      properties: { clock: { type: 'bool', text: 'Clock', value: true } },
      current: { clock: false },
      presets: [],
    }
    engine.readWallpaperDetail = vi.fn(() => Promise.resolve(detail))
    const found = await request('/detail?workshopId=1')
    expect(found.status).toBe(200)
    expect(found.json).toMatchObject({ current: { clock: false } })

    engine.readWallpaperDetail = vi.fn(() => Promise.resolve(undefined))
    const missing = await request('/detail?workshopId=1')
    expect(missing.status).toBe(404)

    const bad = await request('/detail?workshopId=..%2Fetc')
    expect(bad.status).toBe(400)
  })

  it('serves preview bytes with the image mime', async () => {
    engine.readPreview = vi.fn(() => Promise.resolve({ bytes: Buffer.from('GIF8'), mime: 'image/gif' }))
    const response = await request('/preview?workshopId=1')
    expect(response.status).toBe(200)
    expect(response.bytes.toString()).toBe('GIF8')
  })
})

describe('we import routes', () => {
  it('starts one job and reports its progress', async () => {
    const started = await request('/import', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ workshopId: '1', durationSeconds: 20, fps: 30, width: 1920, height: 1080 }),
    })
    expect(started.status).toBe(200)
    expect(started.json).toMatchObject({ jobId: 'job-1' })
    expect(engine.startImport).toHaveBeenCalledWith(expect.objectContaining({ workshopId: '1', durationSeconds: 20 }))

    const job: WeImportJob = { id: 'job-1', workshopId: '1', state: 'recording' }
    engine.getImport = vi.fn(() => job)
    const progress = await request('/import?id=job-1')
    expect(progress.status).toBe(200)
    expect(progress.json).toMatchObject({ state: 'recording' })

    engine.getImport = vi.fn(() => undefined)
    const missing = await request('/import?id=nope')
    expect(missing.status).toBe(404)
  })

  it('rejects invalid import bodies before the engine runs', async () => {
    const badId = await request('/import', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ workshopId: 'not-an-id' }),
    })
    expect(badId.status).toBe(400)
    expect(engine.startImport).not.toHaveBeenCalled()

    const badJson = await request('/import', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: 'nope',
    })
    expect(badJson.status).toBe(400)
  })
})

describe('we ffmpeg install routes', () => {
  it('starts (or joins) one installation and reports its progress', async () => {
    const started = await request('/ffmpeg', { method: 'POST' })
    expect(started.status).toBe(200)
    expect(started.json).toMatchObject({ installId: 'install-1' })

    engine.getFfmpegInstall = vi.fn(() => ({ id: 'install-1', state: 'downloading' as const, receivedBytes: 123 }))
    const progress = await request('/ffmpeg?id=install-1')
    expect(progress.status).toBe(200)
    expect(progress.json).toMatchObject({ state: 'downloading', receivedBytes: 123 })

    engine.getFfmpegInstall = vi.fn(() => undefined)
    const missing = await request('/ffmpeg?id=nope')
    expect(missing.status).toBe(404)
  })

  it('surfaces engine errors from a failed installation start', async () => {
    engine.installFfmpeg = vi.fn(() => { throw new Error('导入引擎已关闭') })
    const response = await request('/ffmpeg', { method: 'POST' })
    expect(response.status).toBe(500)
    expect(response.json).toMatchObject({ error: '导入引擎已关闭' })
  })
})

describe('we route failures', () => {
  it('answers unknown segments with 404', async () => {
    const response = await request('/unknown')
    expect(response.status).toBe(404)
  })

  it('converts engine errors into 500 responses with the message', async () => {
    engine.status = vi.fn(() => Promise.reject(new Error('boom')))
    const response = await request('/status')
    expect(response.status).toBe(500)
    expect(response.json).toMatchObject({ error: 'boom' })
  })
})
