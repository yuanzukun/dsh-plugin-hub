// Wallpaper Engine import engine over a fake file system: discovery and
// version gating, ffmpeg resolution order, and the first-use ffmpeg install
// flow (download → unpack → land), including failure and single-flight cases.
// No real registry, process spawning, or network access.

import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { WeEngine, type WeFileSystem } from '../src/host/we.ts'
import { createWallpaperMediaStore } from '../src/host/media.ts'
import type { WallpaperMediaStore } from '../src/host/media.ts'

interface FakeOptions {
  weDir?: string
  version?: string
  onPathFfmpeg?: () => string | undefined
  registrySteam?: string
  downloadImpl?: WeFileSystem['download']
  expandZipImpl?: WeFileSystem['expandZip']
  ffmpegPath?: string
}

/** A fake file system over a real temp root plus scripted network/process seams. */
function fakeFs(root: string, options: FakeOptions): WeFileSystem {
  const weDir = options.weDir ?? join(root, 'we')
  return {
    exists: (path) => existsSync(path),
    readFile: async (path) => {
      const { readFile } = await import('node:fs/promises')
      return readFile(path, 'utf8')
    },
    stat: async (path) => {
      const { stat } = await import('node:fs/promises')
      try {
        const info = await stat(path)
        return { isFile: info.isFile.bind(info), size: info.size }
      } catch {
        return undefined
      }
    },
    listDir: async (path) => {
      const { readdir } = await import('node:fs/promises')
      return readdir(path)
    },
    spawnCli: async () => ({ code: 0, stdout: '', stderr: '' }),
    spawnRecorder: async () => ({ code: 0, stderr: '' }),
    findOnPath: async () => options.onPathFfmpeg?.(),
    registrySteamPath: async () => options.registrySteam,
    download: options.downloadImpl ?? (async (url, toPath, onProgress, signal) => {
      onProgress(1024 * 1024, 10 * 1024 * 1024)
      await writeFile(toPath, 'fake-zip')
    }),
    expandZip: options.expandZipImpl ?? (async (zipPath, toDir) => {
      await mkdir(toDir, { recursive: true })
      await writeFile(join(toDir, 'ffmpeg.exe'), 'fake-exe')
      await writeFile(join(toDir, 'LICENSE'), 'gpl')
    }),
  }
}

/** Stand up a fake Steam/WE layout (config/version/exe + a workshop cache). */
async function seedWeInstall(steamRoot: string, version: string): Promise<string> {
  const weDir = join(steamRoot, 'steamapps', 'common', 'wallpaper_engine')
  await mkdir(weDir, { recursive: true })
  await writeFile(join(weDir, 'config.json'), JSON.stringify({ admin: { general: {} } }))
  await writeFile(join(weDir, 'version.json'), JSON.stringify({ version }))
  await writeFile(join(weDir, 'wallpaper64.exe'), 'exe')
  await writeFile(join(weDir, 'workshopcache.json'), JSON.stringify({ wallpapers: [] }))
  await mkdir(join(steamRoot, 'steamapps', 'workshop', 'content', '431960'), { recursive: true })
  return weDir
}

let root: string | undefined
let store: WallpaperMediaStore | undefined

afterEach(async () => {
  if (root !== undefined) await rm(root, { recursive: true, force: true })
  root = undefined
  store = undefined
})

async function bench(options: FakeOptions = {}): Promise<{ engine: WeEngine; weDir: string }> {
  root = await mkdtemp(join(tmpdir(), 'dsh-we-engine-'))
  store = createWallpaperMediaStore(root)
  const weDir = await seedWeInstall(root, options.version ?? '2.8.42')
  const engine = new WeEngine({
    mediaStore: store,
    steamRoot: root,
    ffmpegPath: options.ffmpegPath,
  }, fakeFs(root, { weDir, ...options }))
  return { engine, weDir }
}

describe('WeEngine discovery and ffmpeg resolution', () => {
  it('reports a supported install and resolves ffmpeg by override, then the installed copy', async () => {
    const { engine } = await bench({ ffmpegPath: 'C:/custom/ffmpeg.exe' })
    const status = await engine.status()
    expect(status).toMatchObject({ available: true, supported: true, version: '2.8.42' })
    // The override path is validated against the fake fs and does not exist.
    expect(status.ffmpeg).toBeUndefined()

    const { engine: engine2 } = await bench({})
    await mkdir(join(root!, 'ffmpeg'), { recursive: true })
    await writeFile(join(root!, 'ffmpeg', 'ffmpeg.exe'), 'exe')
    const status2 = await engine2.status()
    expect(status2.ffmpeg).toBe(join(root!, 'ffmpeg', 'ffmpeg.exe'))
  })

  it('falls back to PATH when nothing is installed', async () => {
    const holder: { value?: string } = {}
    const { engine } = await bench({ onPathFfmpeg: () => holder.value })
    const onPath = join(root!, 'onpath', 'ffmpeg.exe')
    await mkdir(join(root!, 'onpath'), { recursive: true })
    await writeFile(onPath, 'exe')
    holder.value = onPath
    const status = await engine.status()
    expect(status.ffmpeg).toBe(onPath)
  })

  it('gates old WE versions with a clear message', async () => {
    const { engine } = await bench({ version: '2.7.9' })
    const status = await engine.status()
    expect(status.available).toBe(true)
    expect(status.supported).toBe(false)
    expect(status.error).toContain('2.8.0')
  })
})

describe('WeEngine first-use ffmpeg install', () => {
  it('downloads, unpacks, and lands ffmpeg.exe in the media root', async () => {
    const { engine } = await bench({})
    const id = engine.installFfmpeg()
    const deadline = Date.now() + 10_000
    for (;;) {
      const job = engine.getFfmpegInstall(id)
      if (job?.state === 'done') break
      if (job?.state === 'error') throw new Error(job.error)
      if (Date.now() > deadline) throw new Error('install timeout')
      await new Promise(resolvePromise => setTimeout(resolvePromise, 20))
    }
    const target = join(root!, 'ffmpeg', 'ffmpeg.exe')
    expect(existsSync(target)).toBe(true)
    expect(existsSync(join(root!, 'ffmpeg', 'LICENSE.txt'))).toBe(true)
    const status = await engine.status()
    expect(status.ffmpeg).toBe(target)
  })

  it('reports download failures on the job', async () => {
    const { engine } = await bench({
      downloadImpl: async () => { throw new Error('网络不可用') },
    })
    const id = engine.installFfmpeg()
    const deadline = Date.now() + 10_000
    for (;;) {
      const job = engine.getFfmpegInstall(id)
      if (job?.state === 'error') {
        expect(job.error).toContain('网络不可用')
        break
      }
      if (Date.now() > deadline) throw new Error('install timeout')
      await new Promise(resolvePromise => setTimeout(resolvePromise, 20))
    }
  })

  it('rejects archives without ffmpeg.exe with a clear message', async () => {
    const { engine } = await bench({
      expandZipImpl: async (zipPath, toDir) => {
        await mkdir(toDir, { recursive: true })
        await writeFile(join(toDir, 'not-ffmpeg.txt'), 'x')
      },
    })
    const id = engine.installFfmpeg()
    const deadline = Date.now() + 10_000
    for (;;) {
      const job = engine.getFfmpegInstall(id)
      if (job?.state === 'error') {
        expect(job.error).toContain('没有找到 ffmpeg.exe')
        break
      }
      if (Date.now() > deadline) throw new Error('install timeout')
      await new Promise(resolvePromise => setTimeout(resolvePromise, 20))
    }
  })

  it('runs one installation at a time and shares its id', async () => {
    let release: (() => void) | undefined
    const pending = new Promise<void>((resolvePromise) => { release = resolvePromise })
    const { engine } = await bench({
      downloadImpl: async () => { await pending },
    })
    const first = engine.installFfmpeg()
    const second = engine.installFfmpeg()
    expect(second).toBe(first)
    expect(engine.getFfmpegInstall(first)?.state).toBe('downloading')
    release?.()
  })
})
