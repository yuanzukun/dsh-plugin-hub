// @vitest-environment jsdom
// Client apply wiring under the standard service form: dictionaries register,
// the theme token layer stacks and restores, and both UI registrations install
// into their declared slots with one shared store. The node half lives in
// node.host.spec.ts so the client aggregate never imports it.

import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it } from 'vitest'
import { SlotRegistry } from '@deepseek-ai/dsh-client-runtime/client'
import { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client'
import { ThemeRuntime } from '@deepseek-ai/dsh-client-ui-theme/client'
import { stubSettingsScope } from '@deepseek-ai/dsh-client-test-runtime'
import { apply, inject } from '../src/client/index.ts'

/** A host-style entry declaring the two slots the wallpaper plugin registers into. */
const rootEntry = ({ renderSlot }: { renderSlot: (key: string, owner: object) => unknown }) => {
  renderSlot('shell.overlay', {})
  renderSlot('settings.section', { close: () => {} })
  return null
}

async function bench() {
  const ctx = new Context()
  new SlotRegistry(ctx)
  ctx.provide('theme', new ThemeRuntime(ctx, stubSettingsScope().scope as never))
  ctx.provide('locale', new LocaleRuntime(ctx, undefined))
  ctx.slots.register({
    name: 'root',
    children: {
      'shell.overlay': { kind: 'list', scope: 'root' },
      'settings.section': { kind: 'list', scope: 'root' },
    },
  }, rootEntry as never)
  const fiber = ctx.plugin({ inject, apply })
  await fiber.await()
  return { ctx, fiber }
}

describe('ui-wallpaper client apply', () => {
  it('declares the slots, locale, and theme service dependencies', () => {
    expect(inject).toEqual(['slots', 'locale', 'theme'])
  })

  it('registers the layer and settings entries with one shared store plus the dictionaries', async () => {
    const { ctx, fiber } = await bench()

    const overlay = ctx.slots.entries('shell.overlay')
    expect(overlay.map(entry => entry.options.id)).toEqual(['wallpaper'])
    const section = ctx.slots.entries('settings.section')
    expect(section.map(entry => entry.options.id)).toEqual(['wallpaper'])
    expect(section[0]?.store).toBe(overlay[0]?.store)
    const injected = (section[0]?.inject as (() => { api: { upload: unknown } }) | undefined)?.()
    expect(injected?.api.upload).toBeTypeOf('function')
    expect(['壁纸', 'Wallpaper']).toContain((section[0]?.options.label as (() => string) | undefined)?.())

    const locale = ctx.get('locale') as LocaleRuntime
    const translated = locale.bind('wallpaper')('nav')
    expect(['壁纸', 'Wallpaper']).toContain(translated)

    await fiber.dispose()
    expect(ctx.slots.entries('shell.overlay')).toEqual([])
    expect(ctx.slots.entries('settings.section')).toEqual([])
  })

  it('folds translucent surface tokens into the active theme and restores them on dispose', async () => {
    const { ctx, fiber } = await bench()
    const theme = ctx.get('theme') as ThemeRuntime
    const active = theme.getTheme().active.tokens
    expect(active['--dsw-alias-bg-base']).toContain('color-mix')
    expect(active['--dsw-alias-bg-base']).toContain('60%')
    expect(active['--dsw-specific-sidebar-fill']).toContain('60%')
    await fiber.dispose()
    const restored = theme.getTheme().active.tokens
    expect(restored['--dsw-alias-bg-base']).toBeUndefined()
    expect(restored['--dsw-specific-sidebar-fill']).toBeUndefined()
  })
})
