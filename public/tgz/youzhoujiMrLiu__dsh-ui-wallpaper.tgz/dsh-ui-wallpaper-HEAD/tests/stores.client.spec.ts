// @vitest-environment jsdom
// Wallpaper preference store: init defaults, the declared action mutators
// (including the clamped brightness write path), legacy states persisted
// before the brightness feature, and restoreDefault's full reset. The
// component suites spy on these actions, so this spec drives the real
// mutators. The runtime store engine loads as a web bundle, hence jsdom;
// every instance gets a unique scope key so the localStorage persistence
// backing never leaks state between tests.

import { afterEach, describe, expect, it } from 'vitest'
import {
  WALLPAPER_BRIGHTNESS_DEFAULT, WALLPAPER_BRIGHTNESS_MAX, WALLPAPER_BRIGHTNESS_MIN,
  WALLPAPER_SPEED_DEFAULT, WALLPAPER_SPEED_MAX, WALLPAPER_SPEED_MIN,
} from '../src/model/wallpaper.ts'
import {
  createWallpaperStore, DEFAULT_WALLPAPER, WALLPAPER_STORE_KEY,
  type WallpaperSelection, type WallpaperStoreState,
} from '../src/client/stores.ts'

let seq = 0

function instance() {
  return createWallpaperStore().create(`stores-spec-${seq++}`)
}

describe('wallpaper store', () => {
  it('initializes with the default wallpaper, cover mode, and neutral brightness and speed', () => {
    expect(instance().getSnapshot()).toEqual({
      selection: DEFAULT_WALLPAPER,
      mode: 'cover',
      brightness: WALLPAPER_BRIGHTNESS_DEFAULT,
      speed: WALLPAPER_SPEED_DEFAULT,
    })
  })

  it('applies the selection, mode, and disable actions to the state', () => {
    const store = instance()
    const picked: WallpaperSelection = { kind: 'image', src: '/picked.png', name: 'picked.png' }
    store.actions.selectWallpaper(picked)
    store.actions.setMode('contain')
    expect(store.getSnapshot()).toMatchObject({ selection: picked, mode: 'contain' })
    store.actions.disableWallpaper()
    expect(store.getSnapshot().selection).toBeNull()
  })

  it('clamps brightness writes into the slider bounds and collapses NaN to neutral', () => {
    const store = instance()
    store.actions.setBrightness(0.5)
    expect(store.getSnapshot().brightness).toBe(0.5)
    store.actions.setBrightness(5)
    expect(store.getSnapshot().brightness).toBe(WALLPAPER_BRIGHTNESS_MAX)
    store.actions.setBrightness(0)
    expect(store.getSnapshot().brightness).toBe(WALLPAPER_BRIGHTNESS_MIN)
    store.actions.setBrightness(Number.NaN)
    expect(store.getSnapshot().brightness).toBe(WALLPAPER_BRIGHTNESS_DEFAULT)
  })

  it('clamps and quantizes speed writes and collapses NaN to native', () => {
    const store = instance()
    store.actions.setSpeed(1.5)
    expect(store.getSnapshot().speed).toBe(1.5)
    store.actions.setSpeed(10)
    expect(store.getSnapshot().speed).toBe(WALLPAPER_SPEED_MAX)
    store.actions.setSpeed(0)
    expect(store.getSnapshot().speed).toBe(WALLPAPER_SPEED_MIN)
    store.actions.setSpeed(0.95)
    expect(store.getSnapshot().speed).toBe(1)
    store.actions.setSpeed(Number.NaN)
    expect(store.getSnapshot().speed).toBe(WALLPAPER_SPEED_DEFAULT)
  })

  it('restores the default wallpaper with neutral brightness and speed together', () => {
    const store = instance()
    store.actions.setBrightness(0.3)
    store.actions.setSpeed(2)
    store.actions.restoreDefault()
    expect(store.getSnapshot()).toEqual({
      selection: DEFAULT_WALLPAPER,
      mode: 'cover',
      brightness: WALLPAPER_BRIGHTNESS_DEFAULT,
      speed: WALLPAPER_SPEED_DEFAULT,
    })
  })

  it('reads a legacy persisted state without brightness or speed as undefined until the next write', () => {
    const store = instance()
    const legacy = { selection: DEFAULT_WALLPAPER, mode: 'cover' } satisfies WallpaperStoreState
    store.store.set(legacy)
    expect(store.getSnapshot().brightness).toBeUndefined()
    expect(store.getSnapshot().speed).toBeUndefined()
    store.actions.setBrightness(0.8)
    store.actions.setSpeed(1.5)
    expect(store.getSnapshot().brightness).toBe(0.8)
    expect(store.getSnapshot().speed).toBe(1.5)
  })
})

describe('legacy persist-key migration', () => {
  const LEGACY_KEY = 'wallpaper'
  const legacyState: WallpaperStoreState = {
    selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'old.mp4' },
    mode: 'contain',
    brightness: 0.8,
    speed: 2,
  }

  afterEach(() => {
    localStorage.removeItem(LEGACY_KEY)
    localStorage.removeItem(WALLPAPER_STORE_KEY)
  })

  it('adopts a state persisted under the pre-prefix key and removes the legacy key', () => {
    localStorage.setItem(LEGACY_KEY, JSON.stringify(legacyState))
    const store = createWallpaperStore().create()
    // The unscoped instance rehydrates the migrated key: the legacy selection
    // and name survive the rename instead of resetting to the default.
    expect(store.getSnapshot()).toEqual(legacyState)
    expect(localStorage.getItem(WALLPAPER_STORE_KEY)).toBe(JSON.stringify(legacyState))
    expect(localStorage.getItem(LEGACY_KEY)).toBeNull()
  })

  it('keeps the current key when both exist and still drops the legacy record', () => {
    localStorage.setItem(LEGACY_KEY, JSON.stringify(legacyState))
    const current = JSON.stringify({ selection: null, mode: 'stretch', brightness: 1, speed: 1 })
    localStorage.setItem(WALLPAPER_STORE_KEY, current)
    const store = createWallpaperStore().create()
    expect(store.getSnapshot().selection).toBeNull()
    expect(localStorage.getItem(WALLPAPER_STORE_KEY)).toBe(current)
    expect(localStorage.getItem(LEGACY_KEY)).toBeNull()
  })

  it('drops a corrupt legacy record without adopting it', () => {
    localStorage.setItem(LEGACY_KEY, '{not json')
    const store = createWallpaperStore().create()
    expect(store.getSnapshot()).toEqual({
      selection: DEFAULT_WALLPAPER,
      mode: 'cover',
      brightness: WALLPAPER_BRIGHTNESS_DEFAULT,
      speed: WALLPAPER_SPEED_DEFAULT,
    })
    expect(localStorage.getItem(WALLPAPER_STORE_KEY)).toBeNull()
    expect(localStorage.getItem(LEGACY_KEY)).toBeNull()
  })

  it('leaves an empty current key untouched when no legacy record exists', () => {
    const store = createWallpaperStore().create()
    expect(store.getSnapshot().selection).toEqual(DEFAULT_WALLPAPER)
    expect(localStorage.getItem(LEGACY_KEY)).toBeNull()
  })
})
