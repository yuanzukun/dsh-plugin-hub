// Shared wallpaper media model: MIME/extension resolution, the accept list,
// render-mode mapping (including the video-tile fallback), and the brightness
// normalization behind the surface filter and the settings slider.

import { describe, expect, it } from 'vitest'
import {
  WALLPAPER_ACCEPT, WALLPAPER_BRIGHTNESS_DEFAULT, WALLPAPER_BRIGHTNESS_MAX,
  WALLPAPER_BRIGHTNESS_MIN, WALLPAPER_FORMATS, WALLPAPER_MODES,
  WALLPAPER_SPEED_COARSE_STEP, WALLPAPER_SPEED_DEFAULT, WALLPAPER_SPEED_FINE_STEP,
  WALLPAPER_SPEED_MAX, WALLPAPER_SPEED_MIN, wallpaperBrightness,
  wallpaperBrightnessFilter, wallpaperBrightnessPercent,
  wallpaperFormatByFileName, wallpaperFormatByMime, wallpaperPlaybackSpeed,
  wallpaperPlaybackSpeedLabel, wallpaperRenderMode, wallpaperSpeedStepDown,
  wallpaperSpeedStepUp,
} from '../src/model/wallpaper.ts'

describe('wallpaper media formats', () => {
  it('lists every accepted mime in the picker accept attribute', () => {
    expect(WALLPAPER_ACCEPT).toBe(WALLPAPER_FORMATS.map(format => format.mime).join(','))
  })

  it('resolves canonical mime types and ignores parameters', () => {
    for (const format of WALLPAPER_FORMATS) {
      expect(wallpaperFormatByMime(format.mime)).toEqual(format)
      expect(wallpaperFormatByMime(`${format.mime}; charset=utf-8`)).toEqual(format)
    }
  })

  it('rejects unknown and empty mime types', () => {
    expect(wallpaperFormatByMime('application/pdf')).toBeUndefined()
    expect(wallpaperFormatByMime('')).toBeUndefined()
    expect(wallpaperFormatByMime(' ; ')).toBeUndefined()
  })

  it('resolves filename extensions case-insensitively', () => {
    expect(wallpaperFormatByFileName('wall.GIF')?.extension).toBe('gif')
    expect(wallpaperFormatByFileName('clip.MP4')?.kind).toBe('video')
  })

  it('rejects files without an accepted extension', () => {
    expect(wallpaperFormatByFileName('notes.txt')).toBeUndefined()
    expect(wallpaperFormatByFileName('no-extension')).toBeUndefined()
    expect(wallpaperFormatByFileName('trailing.')).toBeUndefined()
  })
})

describe('wallpaperRenderMode', () => {
  it('keeps the four layout modes in order', () => {
    expect(WALLPAPER_MODES).toEqual(['tile', 'cover', 'contain', 'stretch'])
  })

  it('maps image modes to css presentations', () => {
    expect(wallpaperRenderMode('tile', 'image')).toBe('tile')
    expect(wallpaperRenderMode('cover', 'image')).toBe('cover')
    expect(wallpaperRenderMode('contain', 'image')).toBe('contain')
    expect(wallpaperRenderMode('stretch', 'image')).toBe('fill')
  })

  it('falls video tile back to cover and maps the other video modes', () => {
    expect(wallpaperRenderMode('tile', 'video')).toBe('cover')
    expect(wallpaperRenderMode('cover', 'video')).toBe('cover')
    expect(wallpaperRenderMode('contain', 'video')).toBe('contain')
    expect(wallpaperRenderMode('stretch', 'video')).toBe('fill')
  })
})

describe('wallpaper brightness', () => {
  it('keeps the slider bounds in the documented order', () => {
    expect(WALLPAPER_BRIGHTNESS_MIN).toBeLessThan(WALLPAPER_BRIGHTNESS_DEFAULT)
    expect(WALLPAPER_BRIGHTNESS_DEFAULT).toBeLessThan(WALLPAPER_BRIGHTNESS_MAX)
  })

  it('collapses undefined and NaN multipliers to neutral', () => {
    expect(wallpaperBrightness(undefined)).toBe(1)
    expect(wallpaperBrightness(Number.NaN)).toBe(1)
  })

  it('clamps out-of-range multipliers into the slider bounds', () => {
    expect(wallpaperBrightness(0)).toBe(WALLPAPER_BRIGHTNESS_MIN)
    expect(wallpaperBrightness(-3)).toBe(WALLPAPER_BRIGHTNESS_MIN)
    expect(wallpaperBrightness(0.19)).toBe(WALLPAPER_BRIGHTNESS_MIN)
    expect(wallpaperBrightness(10)).toBe(WALLPAPER_BRIGHTNESS_MAX)
  })

  it('passes in-range multipliers through to the css filter', () => {
    expect(wallpaperBrightnessFilter(0.5)).toBe('brightness(0.5)')
    expect(wallpaperBrightnessFilter(1)).toBe('brightness(1)')
    expect(wallpaperBrightnessFilter(1.25)).toBe('brightness(1.25)')
    expect(wallpaperBrightnessFilter(undefined)).toBe('brightness(1)')
  })

  it('derives the rounded display percent from the normalized multiplier', () => {
    expect(wallpaperBrightnessPercent(0.2)).toBe(20)
    expect(wallpaperBrightnessPercent(0.75)).toBe(75)
    expect(wallpaperBrightnessPercent(1)).toBe(100)
    expect(wallpaperBrightnessPercent(2)).toBe(200)
    expect(wallpaperBrightnessPercent(undefined)).toBe(100)
  })
})

describe('wallpaper playback speed', () => {
  it('keeps the speed bounds around the neutral multiplier', () => {
    expect(WALLPAPER_SPEED_MIN).toBeLessThan(WALLPAPER_SPEED_DEFAULT)
    expect(WALLPAPER_SPEED_DEFAULT).toBeLessThan(WALLPAPER_SPEED_MAX)
    expect(WALLPAPER_SPEED_FINE_STEP).toBeLessThan(WALLPAPER_SPEED_COARSE_STEP)
  })

  it('collapses undefined and NaN multipliers to native speed', () => {
    expect(wallpaperPlaybackSpeed(undefined)).toBe(1)
    expect(wallpaperPlaybackSpeed(Number.NaN)).toBe(1)
  })

  it('clamps out-of-range multipliers into the bounds', () => {
    expect(wallpaperPlaybackSpeed(0)).toBe(WALLPAPER_SPEED_MIN)
    expect(wallpaperPlaybackSpeed(-2)).toBe(WALLPAPER_SPEED_MIN)
    expect(wallpaperPlaybackSpeed(0.05)).toBe(WALLPAPER_SPEED_MIN)
    expect(wallpaperPlaybackSpeed(10)).toBe(WALLPAPER_SPEED_MAX)
  })

  it('quantizes multipliers to one decimal', () => {
    expect(wallpaperPlaybackSpeed(0.95)).toBe(1)
    expect(wallpaperPlaybackSpeed(1.24)).toBe(1.2)
    expect(wallpaperPlaybackSpeed(4.96)).toBe(5)
  })

  it('passes in-range one-decimal multipliers through', () => {
    expect(wallpaperPlaybackSpeed(0.5)).toBe(0.5)
    expect(wallpaperPlaybackSpeed(1.5)).toBe(1.5)
    expect(wallpaperPlaybackSpeed(5)).toBe(5)
  })

  it('steps up by 0.1 below 1× and by 0.5 from 1× up', () => {
    expect(wallpaperSpeedStepUp(0.1)).toBe(0.1)
    expect(wallpaperSpeedStepUp(0.9)).toBe(0.1)
    expect(wallpaperSpeedStepUp(1)).toBe(0.5)
    expect(wallpaperSpeedStepUp(4.5)).toBe(0.5)
  })

  it('steps down by 0.5 above 1× and by 0.1 from 1× down', () => {
    expect(wallpaperSpeedStepDown(0.1)).toBe(0.1)
    expect(wallpaperSpeedStepDown(1)).toBe(0.1)
    expect(wallpaperSpeedStepDown(1.5)).toBe(0.5)
    expect(wallpaperSpeedStepDown(5)).toBe(0.5)
  })

  it('derives the multiplier label from the normalized value', () => {
    expect(wallpaperPlaybackSpeedLabel(0.1)).toBe('0.1×')
    expect(wallpaperPlaybackSpeedLabel(1)).toBe('1×')
    expect(wallpaperPlaybackSpeedLabel(1.5)).toBe('1.5×')
    expect(wallpaperPlaybackSpeedLabel(5)).toBe('5×')
    expect(wallpaperPlaybackSpeedLabel(undefined)).toBe('1×')
  })
})
