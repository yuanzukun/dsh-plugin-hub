// Pure GIF playback engine: decoding normalization, frame timing, alpha
// compositing, disposal semantics, and the monotonic stepping cursor. All
// math is canvas-free so the node lane covers every branch; the browser
// lane owns the actual putImageData draw.
import { describe, expect, it } from 'vitest'
import {
  applyGifDisposal, compositeGifFrame, decodeGifTimeline, gifFrameIndexAt,
  gifPlaybackTick, toGifRgba, transparentBuffer, type GifFrame,
  type GifPlaybackState,
} from '../src/client/gif-player.ts'

/** 2-frame 1×1 GIF fixture: opaque red 200 ms (disposal 2), transparent blue 100 ms (disposal 1). */
const GIF_BYTES = 'R0lGODlhAQABAIEAAP8AAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQIFAAAACwAAAAAAQABAAAIBAABBAQAIfkEBQoAAAAsAAAAAAEAAQCBAAD/AAAAAAAAAAAACAQAAQQEADs='

function fixture(): ArrayBuffer {
  const bytes = Buffer.from(GIF_BYTES, 'base64')
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer
}

function frame(overrides: Partial<GifFrame>): GifFrame {
  return {
    left: 0, top: 0, width: 1, height: 1, delay: 100, disposal: 1,
    rgba: Uint8ClampedArray.from([255, 0, 0, 255]), ...overrides,
  }
}

describe('decodeGifTimeline', () => {
  it('decodes a GIF into normalized frames with RGBA pixels', () => {
    const timeline = decodeGifTimeline(fixture())
    expect(timeline.width).toBe(1)
    expect(timeline.height).toBe(1)
    expect(timeline.frames).toHaveLength(2)
    const first = timeline.frames[0]!
    const second = timeline.frames[1]!
    expect(first).toMatchObject({ left: 0, top: 0, width: 1, height: 1, delay: 200, disposal: 2 })
    expect(Array.from(first.rgba)).toEqual([255, 0, 0, 255])
    expect(second).toMatchObject({ delay: 100, disposal: 1 })
    expect(Array.from(second.rgba)).toEqual([0, 0, 255, 0])
  })

  it('rejects data that is not a GIF', () => {
    expect(() => decodeGifTimeline(new ArrayBuffer(4))).toThrow('不是有效的 GIF 数据')
  })
})

describe('toGifRgba', () => {
  it('maps palette indices to RGBA and renders the transparent index at alpha 0', () => {
    const palette = [[255, 0, 0], [0, 255, 0]] as const
    const rgba = toGifRgba([0, 1, 1], palette, 1)
    expect(Array.from(rgba)).toEqual([255, 0, 0, 255, 0, 255, 0, 0, 0, 255, 0, 0])
  })
})

describe('gifFrameIndexAt', () => {
  it('maps elapsed time to the visible frame across the looping timeline', () => {
    const frames = decodeGifTimeline(fixture()).frames // delays 200 + 100
    expect(gifFrameIndexAt(frames, 0)).toBe(0)
    expect(gifFrameIndexAt(frames, 199)).toBe(0)
    expect(gifFrameIndexAt(frames, 200)).toBe(1)
    expect(gifFrameIndexAt(frames, 299)).toBe(1)
    expect(gifFrameIndexAt(frames, 300)).toBe(0)
    expect(gifFrameIndexAt(frames, 550)).toBe(1)
  })
})

describe('compositeGifFrame', () => {
  it('source-over blends semi-transparent pixels and keeps opaque base pixels', () => {
    const base = transparentBuffer(2, 1)
    base.set([0, 0, 255, 255], 4)
    const semi = frame({ width: 2, height: 1, rgba: Uint8ClampedArray.from([255, 0, 0, 128, 0, 255, 0, 0]) })
    expect(Array.from(compositeGifFrame(base, semi, 2))).toEqual([128, 0, 0, 128, 0, 0, 255, 255])
  })
})

describe('applyGifDisposal', () => {
  it('leaves the composited buffer untouched for disposal 1', () => {
    const base = Uint8ClampedArray.from([1, 2, 3, 4])
    const previous = Uint8ClampedArray.from([9, 9, 9, 9])
    expect(applyGifDisposal(base, previous, frame({}), 1)).toBe(base)
  })

  it('clears the frame rect for disposal 2 and restores it for disposal 3', () => {
    const base = Uint8ClampedArray.from([1, 2, 3, 4, 5, 6, 7, 8])
    const previous = Uint8ClampedArray.from([9, 9, 9, 9, 10, 10, 10, 10])
    const patch = frame({ left: 1, disposal: 2 })
    expect(Array.from(applyGifDisposal(base, previous, patch, 2))).toEqual([1, 2, 3, 4, 0, 0, 0, 0])
    expect(Array.from(applyGifDisposal(base, previous, { ...patch, disposal: 3 }, 2))).toEqual([1, 2, 3, 4, 10, 10, 10, 10])
  })
})

describe('gifPlaybackTick', () => {
  it('steps the cursor frame by frame and paints only when the visible frame changes', () => {
    const frames = [frame({ rgba: Uint8ClampedArray.from([255, 0, 0, 255]) }), frame({ rgba: Uint8ClampedArray.from([0, 255, 0, 255]) })]
    const state: GifPlaybackState = { index: -1, base: transparentBuffer(1, 1) }
    const first = gifPlaybackTick(state, frames, 0, 1)
    expect(state.index).toBe(0)
    expect(Array.from(first ?? [])).toEqual([255, 0, 0, 255])
    expect(gifPlaybackTick(state, frames, 50, 1)).toBeUndefined()
    const second = gifPlaybackTick(state, frames, 150, 1)
    expect(state.index).toBe(1)
    expect(Array.from(second ?? [])).toEqual([0, 255, 0, 255])
  })

  it('keeps stepping across timeline wraps and skips intermediate frames at high speed', () => {
    const frames = [frame({ rgba: Uint8ClampedArray.from([255, 0, 0, 255]) }), frame({ rgba: Uint8ClampedArray.from([0, 255, 0, 255]) })]
    const state: GifPlaybackState = { index: -1, base: transparentBuffer(1, 1) }
    const wrapped = gifPlaybackTick(state, frames, 300, 1)
    expect(state.index).toBe(3)
    expect(Array.from(wrapped ?? [])).toEqual([0, 255, 0, 255])
    expect(state.base).toBe(wrapped)
    const skipped = gifPlaybackTick(state, frames, 650, 1)
    expect(state.index).toBe(6)
    expect(Array.from(skipped ?? [])).toEqual([255, 0, 0, 255])
  })
})
