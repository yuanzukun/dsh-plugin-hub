// Real-Loader composition: the webserver and the wallpaper plugin boot from a
// cordis.yml, then HTTP requests exercise upload, serving, pruning, bounds,
// the trust fence, and generic route failures. No real model calls.

import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { request as rawRequest } from 'node:http'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import Include from '@deepseek-ai/cordis-plugin-include'
import HttpServer from '@deepseek-ai/dsh-host-webserver'
import * as WallpaperPlugin from '../src/index.ts'
import { createWallpaperRoutes } from '../src/host/routes.ts'
import { createWallpaperMediaStore } from '../src/host/media.ts'
import { WeEngine } from '../src/host/we.ts'

/** A discovery-free engine for the direct route-handler probes. */
function testEngine(root: string): WeEngine {
  return new WeEngine({ mediaStore: createWallpaperMediaStore(root) })
}

let root: string | undefined
let context: Context | undefined

afterEach(async () => {
  await context?.fiber.dispose()
  context = undefined
  if (root !== undefined) await rm(root, { recursive: true, force: true })
  root = undefined
  vi.unstubAllEnvs()
  vi.unstubAllGlobals()
})

/** Write a cordis.yml with the webserver plus the wallpaper plugin, then boot it through the real Loader. */
async function loadComposition(config: { maxBytes: number; trustedHosts: string[] } | undefined): Promise<{ port: number }> {
  root = await mkdtemp(join(tmpdir(), 'dsh-wallpaper-loader-'))
  vi.stubEnv('DSH_HOME', root)
  const configPath = join(root, 'cordis.yml')
  const rows = [
    "- name: '@deepseek-ai/dsh-host-webserver'",
    '  config:',
    "    host: '127.0.0.1'",
    '    port: 0',
    "- name: '@deepseek-ai/dsh-client-ui-wallpaper'",
  ]
  if (config !== undefined) {
    rows.push('  config:')
    rows.push(`    maxBytes: ${String(config.maxBytes)}`)
    rows.push('    trustedHosts:')
    for (const host of config.trustedHosts) rows.push(`      - ${String(host)}`)
  }
  await writeFile(configPath, `${rows.join('\n')}\n`)

  context = new Context()
  context.baseUrl = pathToFileURL(root).href + '/'
  await context.plugin(Loader)
  context.loader.builtins.include = Include
  const modules = new Map<string, unknown>([
    ['@deepseek-ai/dsh-host-webserver', HttpServer],
    ['@deepseek-ai/dsh-client-ui-wallpaper', WallpaperPlugin],
  ])
  context.loader.internal = {
    version: 'v2',
    async import(specifier: string) {
      if (!modules.has(specifier)) throw new Error(`unexpected Loader import: ${specifier}`)
      return modules.get(specifier)
    },
  } as unknown as NonNullable<typeof context.loader.internal>
  await context.loader.create({ name: 'cordis:include', config: { path: pathToFileURL(configPath).href } })
  await context.loader.await()

  const unloaded = [...context.loader.entries()]
    .filter(entry => entry.fiber === undefined && !entry.disabled)
    .map(entry => entry.options.name)
  expect(unloaded).toEqual([])
  const port = context.webServer.port
  expect(port).toBeGreaterThan(0)
  return { port }
}

interface ResponseProbe {
  status: number
  text: string
  json: unknown
  contentType: string | null
  bytes: Buffer
  nosniff: string | null
}

async function request(port: number, path: string, init?: RequestInit): Promise<ResponseProbe> {
  const response = await fetch(`http://127.0.0.1:${String(port)}${path}`, init)
  const bytes = Buffer.from(await response.arrayBuffer())
  const text = bytes.toString('utf8')
  let json: unknown
  try {
    json = JSON.parse(text)
  } catch {
    json = undefined
  }
  return {
    status: response.status,
    text,
    json,
    contentType: response.headers.get('content-type'),
    bytes,
    nosniff: response.headers.get('x-content-type-options'),
  }
}

/** A request carrying a caller-chosen Host header (fetch cannot override Host). */
function rawHostRequest(port: number, path: string, host: string, method = 'GET'): Promise<ResponseProbe> {
  return new Promise((resolve, reject) => {
    const req = rawRequest({ host: '127.0.0.1', port, path, method, headers: { host } }, (res) => {
      const chunks: Buffer[] = []
      res.on('data', (chunk: Buffer) => { chunks.push(chunk) })
      res.on('end', () => {
        const bytes = Buffer.concat(chunks)
        resolve({
          status: res.statusCode ?? 0,
          text: bytes.toString('utf8'),
          json: undefined,
          contentType: res.headers['content-type'] ?? null,
          bytes,
          nosniff: (res.headers['x-content-type-options'] as string | undefined) ?? null,
        })
      })
    })
    req.on('error', reject)
    req.end()
  })
}

const upload = (port: number, contentType: string, body: string | Buffer): Promise<ResponseProbe> =>
  request(port, '/dsh-wallpaper/media', {
    method: 'POST',
    headers: { 'content-type': contentType },
    body: typeof body === 'string' ? body : new Uint8Array(body),
  })

describe('route handler trust fence', () => {
  function responseProbe() {
    const calls: { status: number; body: string }[] = []
    return {
      calls,
      res: {
        writeHead: (status: number, headers: Record<string, string | number>) => {
          calls.push({ status, body: headers['content-length'] as string })
        },
        end: (body: string) => { calls.push({ status: calls[calls.length - 1]?.status ?? 0, body }) },
      },
    }
  }

  it('rejects requests without a Host header before route dispatch', async () => {
    const routes = createWallpaperRoutes({ root: root ?? join(tmpdir(), 'unused'), maxBytes: 4, trustedHosts: [], engine: testEngine(root ?? join(tmpdir(), 'unused')) })
    const missing = responseProbe()
    await routes.handle({ headers: {}, url: '/dsh-wallpaper/media', method: 'GET' } as never, missing.res as never)
    expect(missing.calls[1]?.body).toBe('{"error":"forbidden"}')

    const empty = responseProbe()
    await routes.handle({ headers: { host: '' }, url: '/dsh-wallpaper/media', method: 'GET' } as never, empty.res as never)
    expect(empty.calls[1]?.body).toBe('{"error":"forbidden"}')
  })

  it('handles undefined URLs, missing content types, and non-Error body failures', async () => {
    const routes = createWallpaperRoutes({ root: join(tmpdir(), 'unused-wallpaper'), maxBytes: 4, trustedHosts: [], engine: testEngine(join(tmpdir(), 'unused-wallpaper')) })

    const noUrl = responseProbe()
    await routes.handle({ headers: { host: 'localhost' }, method: 'GET' } as never, noUrl.res as never)
    expect(noUrl.calls[1]?.body).toBe('{"error":"not found"}')

    const noType = responseProbe()
    await routes.handle({ headers: { host: 'localhost' }, method: 'POST', url: '/dsh-wallpaper/media' } as never, noType.res as never)
    expect(noType.calls[1]?.body).toContain('不支持的文件类型')

    const throwingBody = {
      headers: { host: 'localhost', 'content-type': 'image/png' },
      method: 'POST',
      url: '/dsh-wallpaper/media',
      [Symbol.asyncIterator]() {
        return {
          next: () => Promise.reject('body boom'),
        }
      },
    }
    const nonError = responseProbe()
    await routes.handle(throwingBody as never, nonError.res as never)
    expect(nonError.calls[1]?.body).toBe('{"error":"body boom"}')
  })
})

describe('real Loader composition', () => {
  it('uploads, serves, and replaces the stored wallpaper with schema defaults', { timeout: 60_000 }, async () => {
    const { port } = await loadComposition(undefined)
    expect((await request(port, '/dsh-wallpaper/media')).status).toBe(404)
    expect((await request(port, '/dsh-wallpaper/nope')).status).toBe(404)

    const image = await upload(port, 'image/gif', Buffer.from('GIF-bytes'))
    expect(image.status).toBe(200)
    expect((image.json as { kind?: string; url?: string }).kind).toBe('image')
    const imageUrl = (image.json as { url: string }).url
    expect(imageUrl).toMatch(/^\/dsh-wallpaper\/media\?v=/)

    const served = await request(port, imageUrl)
    expect(served.status).toBe(200)
    expect(served.contentType).toBe('image/gif')
    expect(served.nosniff).toBe('nosniff')
    expect(served.bytes.toString()).toBe('GIF-bytes')

    const video = await upload(port, 'video/webm', Buffer.from('WEBM-bytes'))
    expect((video.json as { kind?: string }).kind).toBe('video')
    const replaced = await request(port, '/dsh-wallpaper/media')
    expect(replaced.bytes.toString()).toBe('WEBM-bytes')
    expect(replaced.contentType).toBe('video/webm')
  })

  it('enforces type, size, trust, and generic route failures', { timeout: 60_000 }, async () => {
    const { port } = await loadComposition({ maxBytes: 4, trustedHosts: ['app.internal'] })
    expect((await upload(port, 'application/pdf', 'pdf')).status).toBe(415)
    expect((await upload(port, 'image/png', '')).status).toBe(400)
    expect((await upload(port, 'image/png', '12345')).status).toBe(413)

    expect((await upload(port, 'image/png', 'png')).status).toBe(200)
    expect((await rawHostRequest(port, '/dsh-wallpaper/media', 'evil.example')).status).toBe(403)
    expect((await rawHostRequest(port, '/dsh-wallpaper/media', '[::1]:3080')).status).toBe(200)
    expect((await rawHostRequest(port, '/dsh-wallpaper/media', 'app.internal')).status).toBe(200)
  })

  it('answers generic storage failures with 500', { timeout: 60_000 }, async () => {
    const { port } = await loadComposition(undefined)
    await rm(join(root!, 'wallpaper'), { recursive: true, force: true })
    await writeFile(join(root!, 'wallpaper'), 'this is a file, not a directory')
    const failed = await upload(port, 'image/png', 'png')
    expect(failed.status).toBe(500)
    expect(typeof (failed.json as { error?: unknown }).error).toBe('string')
  })
})
