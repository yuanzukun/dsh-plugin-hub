// Host loader face: the /dsh-wallpaper route registration plus the invariant
// companion. The client aggregate excludes this file, so it is the one home
// for imports of the package's node half.

import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it, vi } from 'vitest'
import { apply as nodeApply } from '../src/index.ts'
import * as invariant from '../src/invariant.ts'

describe('node half + invariant companion', () => {
  it('registers the /dsh-wallpaper route through the webServer service with schema defaults', async () => {
    const register = vi.fn(() => () => {})
    const ctx = new Context()
    ctx.provide('webServer', { register })
    nodeApply(ctx as never)
    expect(register).toHaveBeenCalledWith(expect.objectContaining({
      kind: 'prefix',
      path: '/dsh-wallpaper',
      handler: expect.any(Function),
    }))
    await ctx.fiber.dispose()
    expect(register.mock.results[0]?.value).toBeTypeOf('function')
  })

  it('invariant companion registers under the package name', async () => {
    const register = vi.fn().mockReturnValue(() => {})
    const ctx = { invariants: { register } } as never
    const dispose = await (invariant as { apply: (ctx: never) => Promise<() => void> }).apply(ctx)
    expect(register).toHaveBeenCalledWith('@deepseek-ai/dsh-client-ui-wallpaper', expect.any(Function))
    expect(() => { (register.mock.calls[0]![1] as (c: never) => void)(undefined as never) }).not.toThrow()
    expect(dispose).toBeTypeOf('function')
  })
})
