/**
 * Vitest alias target for `@deepseek-ai/dsh-client-runtime/client`. The npm
 * artifact is a web-loader closure bundle with no ESM exports; this module
 * triggers the real bundle through the loader shim and re-exports the
 * factory's exports under their real names.
 */
import { createRequire } from 'node:module'

const nodeRequire = createRequire(import.meta.url)

interface Loader { get(id: string): Record<string, unknown> | undefined }

const ID = '@deepseek-ai/dsh-client-runtime'
const loader = (globalThis as { __ModuleLoader__?: Loader }).__ModuleLoader__

if (loader?.get(ID) === undefined) nodeRequire('@deepseek-ai/dsh-client-runtime/client')
const m = loader!.get(ID)! as typeof import('@deepseek-ai/dsh-client-runtime/client')

export const apply = m.apply
export const contextForm = m.contextForm
export const contextProvenance = m.contextProvenance
export const conversationContextKey = m.conversationContextKey
export const ConversationEventRegistry = m.ConversationEventRegistry
export const ConversationLocationIndex = m.ConversationLocationIndex
export const ConversationNodeAssembler = m.ConversationNodeAssembler
export const ConversationViewRegistry = m.ConversationViewRegistry
export const createScope = m.createScope
export const createSnapshotStore = m.createSnapshotStore
export const defineStore = m.defineStore
export const DirectoryBrowseError = m.DirectoryBrowseError
export const displayFailureMessage = m.displayFailureMessage
export const EMPTY_CHAT_SNAPSHOT = m.EMPTY_CHAT_SNAPSHOT
export const EMPTY_CONVERSATION_VIEWS = m.EMPTY_CONVERSATION_VIEWS
export const emptyAssistantBlock = m.emptyAssistantBlock
export const indexSubagentDescendants = m.indexSubagentDescendants
export const inject = m.inject
export const isAppendSurfaceEvent = m.isAppendSurfaceEvent
export const isReplacementSurfaceEvent = m.isReplacementSurfaceEvent
export const isTokenDelta = m.isTokenDelta
export const PendingWait = m.PendingWait
export const resolveWorkspacePath = m.resolveWorkspacePath
export const scopeOf = m.scopeOf
export const SessionCreateError = m.SessionCreateError
export const SessionProvideChannel = m.SessionProvideChannel
export const SessionRuntime = m.SessionRuntime
export const shallowEqual = m.shallowEqual
export const SlotRegistry = m.SlotRegistry
export const toAssistantBlock = m.toAssistantBlock
export const toAssistantBlocks = m.toAssistantBlocks
export const WorkspaceCreateError = m.WorkspaceCreateError
export const WorkspaceRuntime = m.WorkspaceRuntime
export const workspaceTitleOf = m.workspaceTitleOf
