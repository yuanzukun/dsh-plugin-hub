/**
 * Vitest alias target for `@deepseek-ai/dsh-client-locale/client`. The npm
 * artifact is a web-loader closure bundle with no ESM exports; this module
 * triggers the real bundle through the loader shim and re-exports the
 * factory's exports under their real names.
 */
import { createRequire } from 'node:module'

const nodeRequire = createRequire(import.meta.url)

interface Loader { get(id: string): Record<string, unknown> | undefined }

const ID = '@deepseek-ai/dsh-client-locale'
const loader = (globalThis as { __ModuleLoader__?: Loader }).__ModuleLoader__

if (loader?.get(ID) === undefined) nodeRequire('@deepseek-ai/dsh-client-locale/client')
const m = loader!.get(ID)! as typeof import('@deepseek-ai/dsh-client-locale/client')

export const apply = m.apply
export const COMMON_NS = m.COMMON_NS
export const FALLBACK_LOCALE = m.FALLBACK_LOCALE
export const inject = m.inject
export const LocaleRuntime = m.LocaleRuntime
export const SETTINGS_NS = m.SETTINGS_NS
