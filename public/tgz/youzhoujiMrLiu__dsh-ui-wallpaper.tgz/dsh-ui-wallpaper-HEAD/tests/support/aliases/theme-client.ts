/**
 * Vitest alias target for `@deepseek-ai/dsh-client-ui-theme/client`. The npm
 * artifact is a web-loader closure bundle with no ESM exports; this module
 * triggers the real bundle through the loader shim and re-exports the
 * factory's exports under their real names.
 */
import { createRequire } from 'node:module'

const nodeRequire = createRequire(import.meta.url)

interface Loader { get(id: string): Record<string, unknown> | undefined }

const ID = '@deepseek-ai/dsh-client-ui-theme'
const loader = (globalThis as { __ModuleLoader__?: Loader }).__ModuleLoader__

if (loader?.get(ID) === undefined) nodeRequire('@deepseek-ai/dsh-client-ui-theme/client')
const m = loader!.get(ID)! as typeof import('@deepseek-ai/dsh-client-ui-theme/client')

export const apply = m.apply
export const inject = m.inject
export const SETTINGS_NS = m.SETTINGS_NS
export const ThemeRuntime = m.ThemeRuntime
