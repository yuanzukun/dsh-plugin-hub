/**
 * Vitest shim for published dsh client bundles. The npm artifacts of client
 * packages are web-loader closure bundles (`window.__ModuleLoader__.load({ id,
 * factory })`) with no ESM exports; this setup file installs a synchronous
 * loader that answers the factories' platform-module requires from vite-loaded
 * namespaces (so CSS and React tooling stay on vite's pipeline) and caches
 * factory exports by bundle id. Node ≥22.12 `require(esm)` covers any leftover
 * specifier.
 */
import * as cordisNs from '@deepseek-ai/cordis'
import * as slotsNs from '@deepseek-ai/dsh-client-ui-slots'
import * as primitivesNs from '@deepseek-ai/dsh-client-ui-primitives'
import * as webReactNs from '@deepseek-ai/dsh-client-web-react'
import * as reactNs from 'react'
import * as jsxNs from 'react/jsx-runtime'
import * as reactDomNs from 'react-dom'
import * as reactDomClientNs from 'react-dom/client'
import * as apiproxyApiNs from '@deepseek-ai/dsh-host-apiproxy/api'
import { createRequire } from 'node:module'

const nodeRequire = createRequire(import.meta.url)

/** Platform module table: vite-loaded namespaces answer the factories' requires. */
const table = new Map<string, unknown>([
  ['react', reactNs],
  ['react/jsx-runtime', jsxNs],
  ['react-dom', reactDomNs],
  ['react-dom/client', reactDomClientNs],
  ['@deepseek-ai/cordis', cordisNs],
  ['@deepseek-ai/dsh-client-ui-slots', slotsNs],
  ['@deepseek-ai/dsh-client-ui-primitives', primitivesNs],
  ['@deepseek-ai/dsh-client-web-react', webReactNs],
  ['@deepseek-ai/dsh-host-apiproxy/api', apiproxyApiNs],
])

/** Loaded factory exports, keyed by bundle id. */
const registry = new Map<string, unknown>()

function registryLookup(spec: string): unknown {
  const direct = registry.get(spec)
  if (direct !== undefined) return direct
  // Bundles register under their bare package name while factories require
  // the /client subpath.
  return spec.endsWith('/client') ? registry.get(spec.slice(0, -'/client'.length)) : undefined
}

function load(entry: { id: string; factory: (req: (spec: string) => unknown) => unknown }): unknown {
  const existing = registryLookup(entry.id)
  if (existing !== undefined) return existing
  const require = (spec: string): unknown => {
    const registered = registryLookup(spec)
    if (registered !== undefined) return registered
    if (table.has(spec)) return table.get(spec)
    if (/\.(css|png|svg|jpe?g|woff2?|gif|webp|mp4|webm|ogg)$/.test(spec)) return {}
    return nodeRequire(spec)
  }
  const result = entry.factory(require)
  registry.set(entry.id, result)
  return result
}

const loader = {
  load,
  get: (id: string): unknown => registryLookup(id),
}
;(globalThis as Record<string, unknown>).__ModuleLoader__ = loader
if (typeof window !== 'undefined') (window as unknown as Record<string, unknown>).__ModuleLoader__ = loader
