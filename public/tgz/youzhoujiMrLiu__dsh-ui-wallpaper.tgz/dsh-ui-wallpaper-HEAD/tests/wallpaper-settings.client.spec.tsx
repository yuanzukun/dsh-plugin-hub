// @vitest-environment jsdom
// Wallpaper settings page: live preview, layout-mode controls (tile disabled
// for video), local-file upload through the injected host API, and the
// disable/restore actions. The upload helper's fetch/type-validation contract
// is covered directly after the component suite.

import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots'
import { uploadWallpaper, type WallpaperApi, type WallpaperUploadResult } from '../src/client/api.ts'
import { WallpaperSettings, type WallpaperSettingsProps } from '../src/client/WallpaperSettings.tsx'
import { createWallpaperStore, type WallpaperStoreState } from '../src/client/stores.ts'
import type { WeWallpaperDetail } from '../src/model/we.ts'
import { zh } from '../src/client/locales.ts'

const t = ((key: string) => (zh as Record<string, string>)[key] ?? key) as WallpaperSettingsProps['t']

const IMAGE_UPLOAD: WallpaperUploadResult = { kind: 'image', url: '/dsh-wallpaper/media?v=1' }
const VIDEO_UPLOAD: WallpaperUploadResult = { kind: 'video', url: '/dsh-wallpaper/media?v=2' }

function makeApi(overrides: Partial<WallpaperApi> = {}): WallpaperApi {
  return {
    upload: vi.fn(() => Promise.resolve(IMAGE_UPLOAD)),
    we: {
      status: vi.fn(() => Promise.resolve({ available: false, supported: false, minVersion: '2.8.0', workshopDirs: [] })),
      list: vi.fn(() => Promise.resolve([])),
      detail: vi.fn(() => Promise.reject(new Error('unused'))),
      previewUrl: (id) => `/dsh-wallpaper/we/preview?workshopId=${id}`,
      saveSettings: vi.fn(() => Promise.resolve({ available: false, supported: false, minVersion: '2.8.0', workshopDirs: [] })),
      import: vi.fn(() => Promise.resolve('job')),
      importStatus: vi.fn(() => Promise.reject(new Error('unused'))),
      ffmpegInstall: vi.fn(() => Promise.resolve('install')),
      ffmpegInstallStatus: vi.fn(() => Promise.reject(new Error('unused'))),
    },
    ...overrides,
  }
}

interface Harness {
  api: WallpaperApi
  actions: WallpaperSettingsProps['actions']
  input: HTMLInputElement
}

function mount(api: WallpaperApi = makeApi(), state?: Partial<WallpaperStoreState>): Harness {
  const instance = createWallpaperStore().create('settings')
  if (state !== undefined) instance.store.set({ selection: null, mode: 'cover', ...state })
  const useStore = ((selector: (snapshot: WallpaperStoreState) => unknown) =>
    selector(instance.getSnapshot())) as SnapshotSelectorHook<WallpaperStoreState>
  render(
    <WallpaperSettings
      close={() => {}}
      useSessions={(() => { throw new Error('unused') }) as WallpaperSettingsProps['useSessions']}
      useWorkspaces={(() => { throw new Error('unused') }) as WallpaperSettingsProps['useWorkspaces']}
      useStore={useStore}
      actions={instance.actions}
      api={api}
      t={t}
    />,
  )
  const input = document.querySelector('input[type=file]')
  expect(input).not.toBeNull()
  return { api, actions: instance.actions, input: input as HTMLInputElement }
}

afterEach(() => {
  cleanup()
  document.body.innerHTML = ''
  vi.restoreAllMocks()
})

describe('WallpaperSettings', () => {
  it('renders the disabled state without the disable action', () => {
    mount(makeApi(), { selection: null })
    expect(screen.getAllByText('未设置壁纸')).toHaveLength(2)
    expect(screen.queryByText('关闭壁纸')).toBeNull()
    expect(screen.getByText('恢复默认')).toBeDefined()
  })

  it('shows the current selection and marks the active layout mode', () => {
    mount(makeApi(), { selection: { kind: 'image', src: '/eva.jpg', name: 'eva.jpg' }, mode: 'cover' })
    expect(screen.getByText(/eva\.jpg/)).toBeDefined()
    expect(screen.getByText('填充').getAttribute('aria-pressed')).toBe('true')
    expect(screen.getByText('拉伸').getAttribute('aria-pressed')).toBe('false')
  })

  it('applies layout-mode changes through the store action', () => {
    const { actions } = mount()
    const spy = vi.spyOn(actions, 'setMode')
    fireEvent.click(screen.getByText('拉伸'))
    expect(spy).toHaveBeenCalledWith('stretch')
  })

  it('disables tiling for videos and explains the fallback', () => {
    mount(makeApi(), { selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' }, mode: 'cover' })
    const tile = screen.getByText('平铺') as HTMLButtonElement
    expect(tile.disabled).toBe(true)
    expect(tile.title).toBe('视频不支持平铺，会以填充方式显示')
  })

  it('uploads a picked image and stores the returned URL', async () => {
    const api = makeApi()
    const { actions, input } = mount(api)
    const selectSpy = vi.spyOn(actions, 'selectWallpaper')
    fireEvent.change(input, { target: { files: [new File(['png'], 'wall.png', { type: 'image/png' })] } })
    await waitFor(() => { expect(api.upload).toHaveBeenCalled() })
    expect(selectSpy).toHaveBeenCalledWith({ kind: 'image', src: '/dsh-wallpaper/media?v=1', name: 'wall.png' })
    expect(screen.getByText('壁纸已更新')).toBeDefined()
    expect(input.value).toBe('')
  })

  it('normalizes video uploads away from tile mode', async () => {
    const api = makeApi({ upload: vi.fn(() => Promise.resolve(VIDEO_UPLOAD)) })
    const { actions, input } = mount(api, { selection: null, mode: 'tile' })
    const modeSpy = vi.spyOn(actions, 'setMode')
    fireEvent.change(input, { target: { files: [new File(['video'], 'clip.webm', { type: 'video/webm' })] } })
    await waitFor(() => { expect(modeSpy).toHaveBeenCalledWith('cover') })
  })

  it('shows upload failures and keeps the input clearable', async () => {
    const api = makeApi({ upload: vi.fn(() => Promise.reject(new Error('boom 上传失败'))) })
    const { input } = mount(api)
    fireEvent.change(input, { target: { files: [new File(['png'], 'wall.png', { type: 'image/png' })] } })
    expect(await screen.findByText('boom 上传失败')).toBeDefined()
  })

  it('renders non-Error upload failures as plain text', async () => {
    const api = makeApi({ upload: vi.fn(() => Promise.reject('raw failure')) })
    const { input } = mount(api)
    fireEvent.change(input, { target: { files: [new File(['png'], 'wall.png', { type: 'image/png' })] } })
    expect(await screen.findByText('raw failure')).toBeDefined()
  })

  it('opens the hidden file input from the choose action', () => {
    const { input } = mount()
    const clickSpy = vi.spyOn(input, 'click')
    fireEvent.click(screen.getByText('选择本地文件'))
    expect(clickSpy).toHaveBeenCalledOnce()
  })

  it('ignores an empty file-list change and disables actions while uploading', async () => {
    const api = makeApi({ upload: vi.fn(() => new Promise<never>(() => {})) })
    const { input } = mount(api)
    fireEvent.change(input, { target: { files: [] } })
    expect(api.upload).not.toHaveBeenCalled()
    fireEvent.change(input, { target: { files: [new File(['png'], 'wall.png', { type: 'image/png' })] } })
    const choose = await screen.findByText('上传中…') as HTMLButtonElement
    expect(choose.disabled).toBe(true)
  })

  it('disables and restores the wallpaper through the store actions', () => {
    const { actions } = mount()
    const disableSpy = vi.spyOn(actions, 'disableWallpaper')
    const restoreSpy = vi.spyOn(actions, 'restoreDefault')
    fireEvent.click(screen.getByText('关闭壁纸'))
    fireEvent.click(screen.getByText('恢复默认'))
    expect(disableSpy).toHaveBeenCalledOnce()
    expect(restoreSpy).toHaveBeenCalledOnce()
  })

  it('renders the brightness slider at the stored multiplier with a live percent readout', () => {
    mount(makeApi(), { selection: { kind: 'image', src: '/eva.jpg', name: 'eva.jpg' }, brightness: 1.5 })
    const slider = screen.getByLabelText('亮度') as HTMLInputElement
    expect(slider.type).toBe('range')
    expect(slider.value).toBe('1.5')
    expect(slider.min).toBe('0.2')
    expect(slider.max).toBe('2')
    expect(slider.step).toBe('0.05')
    expect(screen.getByText('150%')).toBeDefined()
    expect((screen.getByText('重置亮度') as HTMLButtonElement).disabled).toBe(false)
  })

  it('normalizes a missing legacy brightness to the neutral slider position', () => {
    mount(makeApi(), { selection: { kind: 'image', src: '/eva.jpg', name: 'eva.jpg' } })
    expect((screen.getByLabelText('亮度') as HTMLInputElement).value).toBe('1')
    expect(screen.getByText('100%')).toBeDefined()
    expect((screen.getByText('重置亮度') as HTMLButtonElement).disabled).toBe(true)
  })

  it('writes slider changes through the store action', () => {
    const { actions } = mount()
    const spy = vi.spyOn(actions, 'setBrightness')
    fireEvent.change(screen.getByLabelText('亮度'), { target: { value: '0.8' } })
    expect(spy).toHaveBeenCalledWith(0.8)
  })

  it('resets the brightness to neutral through the store action', () => {
    const { actions } = mount(makeApi(), { brightness: 0.5 })
    const spy = vi.spyOn(actions, 'setBrightness')
    fireEvent.click(screen.getByText('重置亮度'))
    expect(spy).toHaveBeenCalledWith(1)
  })

  it('renders the typeable speed input at the stored multiplier with a live label readout', () => {
    mount(makeApi(), { selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' }, mode: 'cover', speed: 1.5 })
    const input = screen.getByLabelText('播放速度') as HTMLInputElement
    expect(input.type).toBe('text')
    expect(input.inputMode).toBe('decimal')
    expect(input.value).toBe('1.5')
    expect(screen.getByText('1.5×')).toBeDefined()
    expect((screen.getByText('重置速度') as HTMLButtonElement).disabled).toBe(false)
    expect((screen.getByLabelText('加速') as HTMLButtonElement).disabled).toBe(false)
    expect((screen.getByLabelText('减速') as HTMLButtonElement).disabled).toBe(false)
  })

  it('normalizes a missing legacy speed to the native input position', () => {
    mount(makeApi(), { selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' } })
    expect((screen.getByLabelText('播放速度') as HTMLInputElement).value).toBe('1')
    expect(screen.getByText('1×')).toBeDefined()
    expect((screen.getByText('重置速度') as HTMLButtonElement).disabled).toBe(true)
  })

  it('commits typed speed values through the store action', () => {
    const { actions } = mount()
    const spy = vi.spyOn(actions, 'setSpeed')
    fireEvent.change(screen.getByLabelText('播放速度'), { target: { value: '2' } })
    expect(spy).toHaveBeenCalledWith(2)
  })

  it('commits partial typed values and keeps the raw text until blur', () => {
    const { actions } = mount()
    const spy = vi.spyOn(actions, 'setSpeed')
    const input = screen.getByLabelText('播放速度') as HTMLInputElement
    fireEvent.change(input, { target: { value: '1.' } })
    expect(spy).toHaveBeenCalledWith(1)
    expect(input.value).toBe('1.')
    fireEvent.blur(input)
    expect(input.value).toBe('1')
  })

  it('ignores unparsable input and snaps back to the normalized value on blur', () => {
    const { actions } = mount(makeApi(), { speed: 1.5 })
    const spy = vi.spyOn(actions, 'setSpeed')
    const input = screen.getByLabelText('播放速度') as HTMLInputElement
    fireEvent.change(input, { target: { value: 'abc' } })
    expect(spy).not.toHaveBeenCalled()
    fireEvent.blur(input)
    expect(input.value).toBe('1.5')
  })

  it('ignores an empty input and snaps back to the normalized value on blur', () => {
    const { actions } = mount(makeApi(), { speed: 1.5 })
    const spy = vi.spyOn(actions, 'setSpeed')
    const input = screen.getByLabelText('播放速度') as HTMLInputElement
    fireEvent.change(input, { target: { value: '' } })
    expect(spy).not.toHaveBeenCalled()
    expect(input.value).toBe('')
    fireEvent.blur(input)
    expect(input.value).toBe('1.5')
  })

  it('steps the speed up by 0.1 below 1× and by 0.5 from 1× up', () => {
    const below = mount(makeApi(), { speed: 0.9 })
    const belowSpy = vi.spyOn(below.actions, 'setSpeed')
    fireEvent.click(screen.getByLabelText('加速'))
    expect(belowSpy).toHaveBeenCalledWith(1)
    cleanup()
    document.body.innerHTML = ''
    const atNeutral = mount(makeApi(), { speed: 1 })
    const neutralSpy = vi.spyOn(atNeutral.actions, 'setSpeed')
    fireEvent.click(screen.getByLabelText('加速'))
    expect(neutralSpy).toHaveBeenCalledWith(1.5)
  })

  it('steps the speed down by 0.1 at 1× and by 0.5 above 1×', () => {
    const atNeutral = mount(makeApi(), { speed: 1 })
    const neutralSpy = vi.spyOn(atNeutral.actions, 'setSpeed')
    fireEvent.click(screen.getByLabelText('减速'))
    expect(neutralSpy).toHaveBeenCalledWith(0.9)
    cleanup()
    document.body.innerHTML = ''
    const above = mount(makeApi(), { speed: 1.5 })
    const aboveSpy = vi.spyOn(above.actions, 'setSpeed')
    fireEvent.click(screen.getByLabelText('减速'))
    expect(aboveSpy).toHaveBeenCalledWith(1)
  })

  it('disables the step buttons at the speed bounds', () => {
    mount(makeApi(), { speed: 0.1 })
    expect((screen.getByLabelText('减速') as HTMLButtonElement).disabled).toBe(true)
    expect((screen.getByLabelText('加速') as HTMLButtonElement).disabled).toBe(false)
    cleanup()
    document.body.innerHTML = ''
    mount(makeApi(), { speed: 5 })
    expect((screen.getByLabelText('加速') as HTMLButtonElement).disabled).toBe(true)
    expect((screen.getByLabelText('减速') as HTMLButtonElement).disabled).toBe(false)
  })

  it('resets the speed to native through the store action', () => {
    const { actions } = mount(makeApi(), { speed: 2 })
    const spy = vi.spyOn(actions, 'setSpeed')
    fireEvent.click(screen.getByText('重置速度'))
    expect(spy).toHaveBeenCalledWith(1)
  })

  it('disables the speed slider for tiled images and explains the fallback', () => {
    mount(makeApi(), { selection: { kind: 'image', src: '/gif.gif', name: 'gif.gif' }, mode: 'tile' })
    const slider = screen.getByLabelText('播放速度') as HTMLInputElement
    expect(slider.disabled).toBe(true)
    expect(slider.title).toBe('平铺模式下不支持变速播放')
  })

  it('keeps the speed slider enabled for videos in tile mode', () => {
    mount(makeApi(), { selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' }, mode: 'tile' })
    expect((screen.getByLabelText('播放速度') as HTMLInputElement).disabled).toBe(false)
  })

    it('labels the WE engine scheme-color property with the dictionary translation', async () => {
      const base = makeApi()
      const api: WallpaperApi = {
        ...base,
        we: {
          ...base.we,
          status: vi.fn(() => Promise.resolve({
            available: true, supported: true, version: '2.8.42', minVersion: '2.8.0',
            workshopDirs: [], ffmpeg: 'C:\\ffmpeg\\ffmpeg.exe',
          })),
          list: vi.fn(() => Promise.resolve([{
            workshopId: '1', title: 'A Scene', type: 'scene',
            file: 'D:/scene.pkg', project: 'D:/project.json', preview: '',
            tags: '', fileSizeBytes: 0, local: false,
          }])),
          detail: vi.fn(() => Promise.resolve({
            wallpaper: {
              workshopId: '1', title: 'A Scene', type: 'scene',
              file: 'D:/scene.pkg', project: 'D:/project.json', preview: '',
              tags: '', fileSizeBytes: 0, local: false,
            },
            properties: {
              schemecolor: { type: 'color', text: 'ui_browse_properties_scheme_color', value: '0.5 0.5 0.5' },
            },
            current: { schemecolor: '0.5 0.5 0.5' },
            presets: [],
          } satisfies WeWallpaperDetail)),
        },
      }
      mount(api)
      fireEvent.click(await screen.findByText('A Scene'))
      // The engine key renders its translated label, not the raw name.
      expect(await screen.findByText('主题配色')).toBeDefined()
      expect(screen.queryByText('schemecolor')).toBeNull()
      // The picker still carries the WE-read value as its default.
      expect((screen.getByLabelText('schemecolor') as HTMLInputElement).value).toBe('#808080')
    })
})

describe('uploadWallpaper', () => {
  it('uploads with the canonical mime type and returns the host result', async () => {
    const fetchMock = vi.fn(() => Promise.resolve(new Response(JSON.stringify({ url: '/dsh-wallpaper/media?v=1', kind: 'image' }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    })))
    vi.stubGlobal('fetch', fetchMock)
    const result = await uploadWallpaper(new File(['png'], 'wall.PNG', { type: '' }))
    expect(result).toEqual({ kind: 'image', url: '/dsh-wallpaper/media?v=1' })
    expect(fetchMock).toHaveBeenCalledWith('/dsh-wallpaper/media', expect.objectContaining({
      method: 'POST',
      headers: { 'content-type': 'image/png' },
    }))
  })

  it('rejects unsupported file types before any fetch', async () => {
    const fetchMock = vi.fn()
    vi.stubGlobal('fetch', fetchMock)
    await expect(uploadWallpaper(new File(['pdf'], 'notes.pdf', { type: 'application/pdf' })))
      .rejects.toThrow('不支持的文件类型')
    expect(fetchMock).not.toHaveBeenCalled()
  })

  it('surfaces the host error message on a non-ok response', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(new Response(JSON.stringify({ error: '文件超过大小上限' }), {
      status: 413,
      headers: { 'content-type': 'application/json' },
    }))))
    await expect(uploadWallpaper(new File(['video'], 'clip.mp4', { type: 'video/mp4' })))
      .rejects.toThrow('文件超过大小上限')
  })

  it('rejects a malformed success body', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    }))))
    await expect(uploadWallpaper(new File(['png'], 'wall.png', { type: 'image/png' })))
      .rejects.toThrow('服务端未返回有效的壁纸地址')
  })

  it('rejects an empty URL in an otherwise valid success body', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(new Response(JSON.stringify({ url: '', kind: 'image' }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    }))))
    await expect(uploadWallpaper(new File(['png'], 'wall.png', { type: 'image/png' })))
      .rejects.toThrow('服务端未返回有效的壁纸地址')
  })

  it('rejects an unknown media kind in an otherwise valid success body', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(new Response(JSON.stringify({ url: '/dsh-wallpaper/media?v=1', kind: 'audio' }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    }))))
    await expect(uploadWallpaper(new File(['png'], 'wall.png', { type: 'image/png' })))
      .rejects.toThrow('服务端未返回有效的壁纸地址')
  })

  it('falls back to a status-only message when the failure body is not json', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.resolve(new Response('nope', { status: 500 }))))
    await expect(uploadWallpaper(new File(['png'], 'wall.png', { type: 'image/png' })))
      .rejects.toThrow('壁纸上传失败（500）')
  })
})
