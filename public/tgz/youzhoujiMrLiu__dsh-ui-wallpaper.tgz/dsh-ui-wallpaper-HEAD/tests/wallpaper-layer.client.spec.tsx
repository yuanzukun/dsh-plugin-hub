// @vitest-environment jsdom
// Frame wallpaper layer: the store selection portals a fixed media surface to
// document.body, videos never tile, disabled selection renders nothing, and
// unmount removes the portaled layer.

import { cleanup, render } from '@testing-library/react'
import { afterEach, describe, expect, it } from 'vitest'
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots'
import { WallpaperLayer, type WallpaperLayerProps } from '../src/client/WallpaperLayer.tsx'
import { createWallpaperStore, type WallpaperStoreState } from '../src/client/stores.ts'

function mount(state: WallpaperStoreState) {
  const instance = createWallpaperStore().create('layer')
  instance.store.set(state)
  const useStore = ((selector: (snapshot: WallpaperStoreState) => unknown) =>
    selector(instance.getSnapshot())) as SnapshotSelectorHook<WallpaperStoreState>
  return render(
    <WallpaperLayer
      useStore={useStore}
      actions={instance.actions}
      useSessions={(() => { throw new Error('unused') }) as WallpaperLayerProps['useSessions']}
      useWorkspaces={(() => { throw new Error('unused') }) as WallpaperLayerProps['useWorkspaces']}
    />,
  )
}

afterEach(() => {
  cleanup()
  document.body.innerHTML = ''
})

describe('WallpaperLayer', () => {
  it('portals the default image to document.body with cover fit and neutral brightness', () => {
    mount({ selection: { kind: 'image', src: '/eva.jpg', name: 'eva.jpg' }, mode: 'cover' })
    const layer = document.querySelector('[data-wallpaper-layer]')
    expect(layer?.parentElement).toBe(document.body)
    expect(layer?.getAttribute('aria-hidden')).toBe('true')
    const image = layer?.querySelector('img')
    expect(image?.getAttribute('src')).toBe('/eva.jpg')
    expect((image as HTMLElement | null)?.style.objectFit).toBe('cover')
    const surface = layer?.firstElementChild as HTMLElement
    expect(surface.style.filter).toBe('brightness(1)')
  })

  it('renders tiled images as a repeating background without an img element', () => {
    mount({ selection: { kind: 'image', src: '/tile.gif', name: 'tile.gif' }, mode: 'tile' })
    const surface = document.querySelector('[data-wallpaper-layer]')?.firstElementChild as HTMLElement
    expect(surface?.style.backgroundImage).toBe('url("/tile.gif")')
    expect(document.querySelector('[data-wallpaper-layer] img')).toBeNull()
  })

  it('renders videos with muted looping playback and cover fallback for tile mode', () => {
    mount({ selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' }, mode: 'tile' })
    const video = document.querySelector('[data-wallpaper-layer] video') as HTMLVideoElement
    expect(video.getAttribute('src')).toBe('/dsh-wallpaper/media?v=1')
    expect(video.muted).toBe(true)
    expect(video.loop).toBe(true)
    expect(video.style.objectFit).toBe('cover')
  })

  it('applies one brightness filter across image, tile, and video surfaces', () => {
    const states = [
      { selection: { kind: 'image', src: '/wall.jpg', name: 'wall.jpg' }, mode: 'cover' },
      { selection: { kind: 'image', src: '/tile.gif', name: 'tile.gif' }, mode: 'tile' },
      { selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' }, mode: 'cover' },
    ] as const
    for (const state of states) {
      cleanup()
      document.body.innerHTML = ''
      mount({ ...state, brightness: 0.6 })
      const surface = document.querySelector('[data-wallpaper-layer]')?.firstElementChild as HTMLElement
      expect(surface?.style.filter).toBe('brightness(0.6)')
    }
  })

  it('sets the video playback rate from the store speed', () => {
    mount({ selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' }, mode: 'cover', speed: 1.5 })
    const video = document.querySelector('[data-wallpaper-layer] video') as HTMLVideoElement
    expect(video.playbackRate).toBe(1.5)
  })

  it('plays videos at native rate for legacy states without a speed value', () => {
    mount({ selection: { kind: 'video', src: '/dsh-wallpaper/media?v=1', name: 'clip.mp4' }, mode: 'cover' })
    const video = document.querySelector('[data-wallpaper-layer] video') as HTMLVideoElement
    expect(video.playbackRate).toBe(1)
  })

  it('keeps the native image element when a non-native speed cannot fetch the media', () => {
    mount({ selection: { kind: 'image', src: '/gif.gif', name: 'gif.gif' }, mode: 'cover', speed: 2 })
    const image = document.querySelector('[data-wallpaper-layer] img')
    expect(image?.getAttribute('src')).toBe('/gif.gif')
  })

  it('maps stretch to fill for scaled media', () => {
    mount({ selection: { kind: 'image', src: '/stretch.jpg', name: 'stretch.jpg' }, mode: 'stretch' })
    const image = document.querySelector('[data-wallpaper-layer] img') as HTMLElement
    expect(image.style.objectFit).toBe('fill')
  })

  it('renders nothing while disabled and cleans the layer up on unmount', () => {
    const view = mount({ selection: null, mode: 'cover' })
    expect(document.querySelector('[data-wallpaper-layer]')).toBeNull()
    view.rerender(
      <WallpaperLayer
        useStore={((selector: (snapshot: WallpaperStoreState) => unknown) =>
          selector({ selection: { kind: 'image', src: '/eva.jpg', name: 'eva.jpg' }, mode: 'cover' })) as SnapshotSelectorHook<WallpaperStoreState>}
        actions={undefined as never}
        useSessions={(() => { throw new Error('unused') }) as WallpaperLayerProps['useSessions']}
        useWorkspaces={(() => { throw new Error('unused') }) as WallpaperLayerProps['useWorkspaces']}
      />,
    )
    expect(document.querySelector('[data-wallpaper-layer]')).not.toBeNull()
    view.unmount()
    expect(document.querySelector('[data-wallpaper-layer]')).toBeNull()
  })
})
