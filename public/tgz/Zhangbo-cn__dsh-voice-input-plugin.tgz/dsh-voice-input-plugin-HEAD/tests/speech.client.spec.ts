/**
 * Text preparation for reply reading: markdown markup is stripped so the TTS
 * does not read `**` / backticks / header hashes aloud.
 */
import { describe, expect, it } from 'vitest'
import { applyResults, stripMarkdownForSpeech, TranscriptAccumulator } from '../src/client/speech.ts'

describe('stripMarkdownForSpeech', () => {
  it('strips bold and italic markers', () => {
    expect(stripMarkdownForSpeech('**加粗**和*斜体*')).toBe('加粗和斜体')
    expect(stripMarkdownForSpeech('__下划线__和_斜体_')).toBe('下划线和斜体')
  })

  it('strips inline and fenced code, keeping inline text', () => {
    expect(stripMarkdownForSpeech('用 `dsh plugin add` 安装')).toBe('用 dsh plugin add 安装')
    expect(stripMarkdownForSpeech('```js\nconst x = 1\n```')).toBe('')
  })

  it('keeps link and image labels, drops the URL', () => {
    expect(stripMarkdownForSpeech('[DeepSeek](https://deepseek.com)')).toBe('DeepSeek')
    expect(stripMarkdownForSpeech('![图](img.png)')).toBe('图')
  })

  it('strips headers, list bullets, and blockquotes', () => {
    expect(stripMarkdownForSpeech('## 标题\n- 列表项\n> 引用')).toBe('标题 列表项 引用')
  })

  it('collapses leftover whitespace and trims', () => {
    expect(stripMarkdownForSpeech('  一段    文字  ')).toBe('一段 文字')
  })

  it('decodes common HTML entities', () => {
    expect(stripMarkdownForSpeech('a &amp; b')).toBe('a & b')
  })

  it('removes strikethrough', () => {
    expect(stripMarkdownForSpeech('~~删除~~保留')).toBe('删除保留')
  })

  it('strips emoji and decorative symbols (Edge TTS otherwise renders them silently)', () => {
    expect(stripMarkdownForSpeech('信号满格～📡😄')).toBe('信号满格～')
    expect(stripMarkdownForSpeech('你好🚀再见')).toBe('你好再见')
  })
})

describe('applyResults', () => {
  it('commits final segments and reports true when one was committed', () => {
    const acc = new TranscriptAccumulator()
    const committed = applyResults(acc, {
      resultIndex: 0,
      results: [
        { isFinal: true, 0: { transcript: '你好' } },
        { isFinal: false, 0: { transcript: '世界' } },
      ],
    })
    expect(committed).toBe(true)
    expect(acc.transcript).toBe('你好 世界')
    expect(acc.isFinal).toBe(true)
  })

  it('reports false for interim-only results (nothing committed)', () => {
    const acc = new TranscriptAccumulator()
    const committed = applyResults(acc, {
      resultIndex: 0,
      results: [{ isFinal: false, 0: { transcript: '你好' } }],
    })
    expect(committed).toBe(false)
    expect(acc.isFinal).toBe(false)
  })

  it('only folds results at and after resultIndex', () => {
    const acc = new TranscriptAccumulator()
    acc.appendFinal('先前')
    const committed = applyResults(acc, {
      resultIndex: 1,
      results: [
        { isFinal: true, 0: { transcript: '忽略' } },
        { isFinal: true, 0: { transcript: '新句' } },
      ],
    })
    expect(committed).toBe(true)
    expect(acc.transcript).toBe('先前 新句')
  })
})
