import { defineConfig } from 'vitest/config'

/**
 * Standalone vitest config for this package. The only deliberate setting is the
 * automatic JSX runtime (`react/jsx-runtime`), matching how the package's own
 * tsdown build compiles JSX — vitest's default is the classic transform, which
 * would require a bare `React` import in every test/source file.
 *
 * `tests/apply.client.spec.ts` is intentionally NOT listed here: it binds real
 * Harness services (`@deepseek-ai/cordis`, `-runtime`, `-locale`) that are built
 * from the DeepSeek Harness monorepo and are not all published, so it runs
 * inside that monorepo, not standalone. The package `test` script therefore
 * scopes to the self-contained suites.
 */
export default defineConfig({
  esbuild: { jsx: 'automatic' },
  test: {
    setupFiles: ['./vitest.setup.ts'],
  },
})
