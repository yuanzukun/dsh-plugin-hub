/**
 * Standalone vitest setup. Enables React 18's `act()` environment so the
 * `act(...)` support warning is silent when tests drive state updates with
 * fake timers. Kept to a minimum — the suites manage their own cleanup.
 */
;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
