/* Offline smoke test for the host half: stubs the cordis context, drives the
 * approval waterfall, a finished turn and the HTTP routes, and prints the
 * notifier verdicts.
 *
 * Run: node test/smoke.mjs
 * Writes its config/log into test/.home so the real ~/.dsh stays untouched. */
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const HOME = path.join(here, '.home')
process.env.DSH_HOME = HOME
fs.rmSync(HOME, { recursive: true, force: true })
fs.mkdirSync(HOME, { recursive: true })

const plugin = await import('../lib/index.js')

const routes = new Map()
const hooks = new Map()

const ctx = {
  on(name, handler) {
    hooks.set(name, handler)
    return () => hooks.delete(name)
  },
  get(name) {
    if (name === 'webServer') {
      return {
        register(route) {
          routes.set(route.path, route)
          return () => routes.delete(route.path)
        }
      }
    }
    return undefined
  },
  effect(fn) {
    const dispose = fn()
    return () => { try { dispose() } catch (err) { /* ignore */ } }
  },
  logger: { warn: (m) => console.warn('[warn]', m), info: (m) => console.log('[info]', m) }
}

function call(routePath, method = 'GET', body = null) {
  const route = routes.get(routePath)
  if (!route) return Promise.reject(new Error('no route ' + routePath))
  return new Promise((resolve) => {
    const req = { method, url: routePath, headers: {}, on: (ev, cb) => { if (ev === 'end') cb(); return req } }
    const chunks = []
    const res = {
      statusCode: 200,
      writeHead(code) { this.statusCode = code; return this },
      end(payload) { if (payload) chunks.push(Buffer.from(payload)); resolve({ status: this.statusCode, body: JSON.parse(Buffer.concat(chunks).toString('utf8')) }) }
    }
    if (body !== null) {
      const raw = JSON.stringify(body)
      req.on = (ev, cb) => { if (ev === 'data') cb(Buffer.from(raw)); if (ev === 'end') cb(); return req }
    }
    route.handler(req, res)
  })
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

await plugin.apply(ctx)
console.log('plugin name/inject:', plugin.name, JSON.stringify(plugin.inject))
console.log('routes:', Array.from(routes.keys()))
console.log('hooks:', Array.from(hooks.keys()))

const cfg0 = await call('/dsh-desktop-alerts/config')
console.log('GET config ->', cfg0.status, JSON.stringify(cfg0.body.config))
console.log('resolved sound ->', cfg0.body.soundFile)

const saved = await call('/dsh-desktop-alerts/config', 'POST', { patch: { repeats: 0, skipWhenFocused: false, soundSeconds: 3 } })
console.log('POST config ->', saved.status, 'soundSeconds=', saved.body.config.soundSeconds, 'soundMode=', saved.body.config.soundMode)

const approvalTest = await call('/dsh-desktop-alerts/test', 'POST', { kind: 'approval' })
console.log('POST test(approval) ->', approvalTest.body.kind, JSON.stringify(approvalTest.body.verdict))

const taskTest = await call('/dsh-desktop-alerts/test', 'POST', { kind: 'task' })
console.log('POST test(task) ->', taskTest.body.kind, JSON.stringify(taskTest.body.verdict))

/* A real approval through the waterfall: the hook must pass the outcome
 * through unchanged while the toast fires on the side. */
const approvalHook = hooks.get('approval/request')
const outcome = await new Promise((resolve) => {
  Promise.resolve(approvalHook({ toolName: 'bash', reason: 'sandbox escalation', callId: 'smoke-1' }, () => Promise.resolve('unavailable')))
    .then(resolve, resolve)
})
console.log('waterfall outcome ->', outcome)

/* A finished turn must produce exactly one completion toast. */
const sessionEvent = hooks.get('session/event')
if (sessionEvent) {
  const session = { header: { id: 'sess-smoke', origin: 'user', title: '' } }
  sessionEvent(session, { type: 'session/title', data: { title: '冒烟测试对话' } })
  sessionEvent(session, { type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } })
  sessionEvent(session, { type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } }) // duplicate: ignored
  sessionEvent(session, { type: 'turn/end', data: { turn: 2, reason: { kind: 'aborted' } } }) // not "done": ignored
  sessionEvent({ header: { id: 'sess-sub', origin: 'subagent' } }, { type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } })
  console.log('session/event driven')
} else {
  console.log('MISSING session/event hook')
}

await sleep(8000)
const status = await call('/dsh-desktop-alerts/status')
console.log('status.captured ->', JSON.stringify(status.body.captured))
console.log('status.soundFile ->', status.body.soundFile)
console.log('status.last ->', JSON.stringify(status.body.last))
console.log('status.recent ->', JSON.stringify(status.body.recent))

const log = fs.readFileSync(path.join(HOME, 'dsh-desktop-alerts.log'), 'utf8').trim().split('\n')
console.log('log lines:', log.length)
console.log('log kinds:', log.map((line) => { try { return JSON.parse(line).kind } catch (err) { return '?' } }).join(','))

await call('/dsh-desktop-alerts/config', 'POST', { action: 'reset' })
console.log('reset done')
fs.rmSync(HOME, { recursive: true, force: true })
http.globalAgent.destroy?.()
process.exit(0)
