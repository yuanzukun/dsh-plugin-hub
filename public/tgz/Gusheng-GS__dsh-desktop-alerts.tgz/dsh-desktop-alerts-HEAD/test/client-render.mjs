/* Offline render check for the browser half.
 *
 * The settings panel is a lazy-CJS bundle that never runs under Node, so this
 * harness reproduces the module loader contract, a minimal `react` (hooks +
 * createElement) and `fetch`, then renders the panel once and walks the tree.
 * It catches the failure modes a syntax check cannot: a hook order break, a
 * control that reads a config key the host no longer sends, or new sections
 * silently rendering nothing.
 *
 * Run: node test/client-render.mjs */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))

/* ── minimal react ─────────────────────────────────────────────────────── */
let hookState = []
let hookIndex = 0
let dirty = false
let effectsRan = new Set()

const react = {
  createElement(type, props, ...children) {
    const flat = children.length === 1 && Array.isArray(children[0]) ? children[0] : children
    return { type, props: props || {}, children: flat }
  },
  useState(initial) {
    const i = hookIndex++
    if (!(i in hookState)) hookState[i] = typeof initial === 'function' ? initial() : initial
    const set = (next) => {
      hookState[i] = typeof next === 'function' ? next(hookState[i]) : next
      dirty = true
    }
    return [hookState[i], set]
  },
  useEffect(fn) {
    const i = hookIndex++
    if (!effectsRan.has(i)) {
      effectsRan.add(i)
      fn()
    }
  }
}

/* ── fake host surface ─────────────────────────────────────────────────── */
const config = {
  ok: true,
  version: '0.3.0',
  platform: 'win32',
  file: 'C:\\Users\\me\\.dsh\\dsh-desktop-alerts.json',
  soundFile: 'C:\\Windows\\Media\\Alarm01.wav',
  config: {
    enabled: true,
    skipWhenFocused: true,
    scenario: 'auto',
    soundMode: 'alarm',
    soundFile: '',
    soundSeconds: 8,
    taskEnabled: true,
    taskScenario: 'urgent',
    taskSound: true,
    taskTitle: '任务已完成',
    repeats: 2,
    repeatIntervalSec: 25,
    cooldownSec: 5,
    title: '需要审批',
    includeReason: true,
    appId: 'DeepSeek.Harness.DesktopAlerts',
    displayName: 'DeepSeek Harness',
    focusProcesses: []
  },
  last: { at: 1, kind: 'task', action: 'shown', ok: true, scenario: 'urgent' },
  recent: [{ at: 1, kind: 'task', action: 'shown', ok: true, scenario: 'urgent' }],
  captured: { approvals: 2, viaEvent: 2, viaService: 0, patched: false }
}

globalThis.fetch = async () => ({ json: async () => config })
globalThis.document = {
  hasFocus: () => true,
  querySelector: () => null,
  createElement: () => ({ dataset: {}, setAttribute() {}, textContent: '', appendChild() {} }),
  head: { appendChild() {} }
}
globalThis.window = {
  addEventListener() {},
  __ModuleLoader__: { load(def) { globalThis.__loaded = def } }
}
globalThis.setInterval = () => 0

/* ── load the bundle ───────────────────────────────────────────────────── */
const source = fs.readFileSync(path.join(here, '..', 'lib', 'client.js'), 'utf8')
const run = new Function('window', source + '\n//# sourceURL=client.js')
run(globalThis.window)

const def = globalThis.__loaded
if (!def) throw new Error('bundle did not call window.__ModuleLoader__.load')
const api = def.factory((id) => {
  if (id === 'react') return react
  throw new Error('unexpected require: ' + id)
})
console.log('bundle id:', def.id, '| apply:', typeof api.apply, '| inject:', JSON.stringify(api.inject))

/* ── drive apply() and capture the settings section ────────────────────── */
let registered = null
api.apply({
  slots: {
    inject(name, fn) { if (name === 'settings.section') fn() },
    register(spec, component) { registered = { spec, component } }
  }
})

if (!registered) { console.log('RESULT: FAILED (no section registered)'); process.exit(1) }
console.log('section:', registered.spec.id, '| label:', registered.spec.label())

/* ── expand function components so element children become reachable ───── */
function expand(node, depth = 0) {
  if (depth > 24) throw new Error('render recursion too deep')
  if (node === null || node === undefined || node === false) return node
  if (typeof node === 'string' || typeof node === 'number') return node
  if (Array.isArray(node)) return node.map((item) => expand(item, depth + 1))
  if (typeof node.type === 'function') return expand(node.type(node.props), depth + 1)
  return { ...node, children: (node.children || []).map((child) => expand(child, depth + 1)) }
}

/* ── render, letting the fetch settle and state flush ──────────────────── */
let tree = null
for (let pass = 0; pass < 8; pass += 1) {
  hookIndex = 0
  dirty = false
  tree = expand(registered.component())
  await new Promise((r) => setTimeout(r, 10))
  if (!dirty) break
}

function texts(node, out = []) {
  if (node === null || node === undefined || node === false) return out
  if (typeof node === 'string' || typeof node === 'number') { out.push(String(node)); return out }
  if (Array.isArray(node)) { for (const item of node) texts(item, out); return out }
  if (node.props && typeof node.props.label === 'string') out.push('label:' + node.props.label)
  if (node.children) for (const child of node.children) texts(child, out)
  return out
}

const all = texts(tree)
const joined = all.join('\n')
const expected = [
  '桌面通知',
  '启用审批通知',
  'DeepSeek Harness 在前台时不提醒',
  '提示音',
  '提示音响多久（秒）',
  '实际使用的音频',
  '任务完成时也通知',
  '完成通知强度',
  '完成时响系统提示音',
  '完成通知标题',
  '测试审批通知',
  '测试完成通知',
  '保存修改'
]
let missing = expected.filter((needle) => !joined.includes(needle))
console.log('rendered text nodes:', all.length)
console.log('missing:', missing.length ? missing.join(' | ') : '(none)')

const badNodes = []
;(function walk(node) {
  if (!node || typeof node !== 'object') return
  if (Array.isArray(node)) { node.forEach(walk); return }
  if (node.type === undefined) badNodes.push('node without type')
  if (node.children) node.children.forEach(walk)
})(tree)
console.log('malformed nodes:', badNodes.length)
console.log(missing.length === 0 && badNodes.length === 0 ? 'RESULT: ok' : 'RESULT: FAILED')
process.exit(missing.length === 0 && badNodes.length === 0 ? 0 : 1)
