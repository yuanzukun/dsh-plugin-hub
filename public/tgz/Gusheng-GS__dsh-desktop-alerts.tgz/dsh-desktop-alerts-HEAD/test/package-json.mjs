/* Packaging regression checks.
 *
 * 0.3.0 shipped a package.json with a UTF-8 BOM. DSH validates a package by
 * JSON.parse-ing the raw text, so the leading U+FEFF made it throw and the whole
 * plugin was denied at profile startup — the settings page vanished and no toast
 * fired, while every other test still passed. These checks make that class of
 * mistake fail locally instead of in the app.
 *
 * Run: node test/package-json.mjs */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const failures = []
const note = (ok, label) => {
  if (!ok) failures.push(label)
  console.log((ok ? 'ok   ' : 'FAIL ') + label)
}

for (const rel of ['package.json', 'README.md', 'cordis.patch.yml', 'lib/index.js', 'lib/client.js', 'lib/notify.ps1', 'lib/sound.ps1', 'lib/focus.ps1', 'lib/protocol.js']) {
  const file = path.join(root, rel)
  if (!fs.existsSync(file)) { note(false, rel + ' exists'); continue }
  const raw = fs.readFileSync(file, 'utf8')
  note(raw.charCodeAt(0) !== 0xfeff, rel + ' has no UTF-8 BOM')
  note(!raw.includes('\r'), rel + ' uses LF line endings')
}

const pkgRaw = fs.readFileSync(path.join(root, 'package.json'), 'utf8')
let pkg = null
try { pkg = JSON.parse(pkgRaw) } catch (err) { note(false, 'package.json parses: ' + err.message) }
if (pkg) {
  note(pkg.name === 'dsh-desktop-alerts', 'package name is dsh-desktop-alerts')
  note(/^\d+\.\d+\.\d+$/.test(pkg.version || ''), 'version looks semver: ' + pkg.version)
  note(pkg.type === 'module', 'package is ESM')
  note(pkg.main === 'lib/index.js', 'main points at lib/index.js')
  note(pkg.exports && pkg.exports['./client'] === './lib/client.js', 'exports["./client"] points at lib/client.js')
  note(pkg.dsh && pkg.dsh.bundle && pkg.dsh.bundle.patch === './cordis.patch.yml', 'dsh.bundle.patch declared')
  note(fs.existsSync(path.join(root, 'cordis.patch.yml')), 'cordis.patch.yml shipped')
  note(pkg.dsh && pkg.dsh.client && pkg.dsh.client.platform === 'web', 'dsh.client.platform is web')
  note(Array.isArray(pkg.dsh.client.inject) && pkg.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-settings'), 'client injects the settings slot')
  note((pkg.files || []).includes('cordis.patch.yml'), 'files[] ships cordis.patch.yml')
}

/* version must be bumped together in package.json and the host half's log line */
const indexSource = fs.readFileSync(path.join(root, 'lib', 'index.js'), 'utf8')
note(/PLUGIN_VERSION/.test(indexSource), 'host reads its version from package.json')

/* per-kind toast marks: the green check for "finished", the brand mark otherwise */
note(fs.existsSync(path.join(root, 'lib', 'icon-task.png')), 'task-complete icon shipped')
note(fs.existsSync(path.join(root, 'lib', 'icon.png')), 'brand icon shipped')
note(fs.existsSync(path.join(root, 'lib', 'icon.ico')), 'AUMID .ico shipped')
note(indexSource.includes("icon-task.png"), 'host points task toasts at the green check')
const notifySource = fs.readFileSync(path.join(root, 'lib', 'notify.ps1'), 'utf8')
note(notifySource.includes('appLogoOverride'), 'toast sets an appLogoOverride image')

note(fs.existsSync(path.join(root, 'LICENSE')), 'LICENSE shipped')

/* clicking a toast cannot activate an unpackaged app: the click has to go
 * through the dshalerts: protocol handler, so all three pieces must ship */
note(fs.existsSync(path.join(root, 'lib', 'focus.ps1')), 'focus helper shipped')
note(fs.existsSync(path.join(root, 'lib', 'launch.vbs')), 'window-less launcher shipped')
const protocolSource = fs.readFileSync(path.join(root, 'lib', 'protocol.js'), 'utf8')
note(protocolSource.includes("dshalerts:focus"), 'protocol helper advertises the activation URI')
note(indexSource.includes('./protocol.js'), 'host wires the protocol helper')
note(notifySource.includes('activationType="protocol"'), 'toast declares protocol activation')
/* launch.vbs is read by wscript, which never sees a BOM-less UTF-8 file as ASCII-safe
 * once non-ASCII creeps in; keep it pure ASCII like the PowerShell helpers */
for (const rel of ['lib/focus.ps1', 'lib/launch.vbs']) {
  const raw = fs.readFileSync(path.join(root, rel), 'utf8')
  note(!/[^\x09\x0a\x0d\x20-\x7e]/.test(raw), rel + ' is pure ASCII')
}

/* the client bundle must register under the package name, or ModuleLoader complains */
const clientSource = fs.readFileSync(path.join(root, 'lib', 'client.js'), 'utf8')
note(clientSource.includes("id: 'dsh-desktop-alerts'"), "client bundle id matches the package name")

console.log(failures.length === 0 ? 'RESULT: ok' : 'RESULT: FAILED (' + failures.length + ')')
process.exit(failures.length === 0 ? 0 : 1)
