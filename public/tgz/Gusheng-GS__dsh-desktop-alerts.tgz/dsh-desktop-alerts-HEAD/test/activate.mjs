/* End-to-end check of the toast click path.
 *
 * 1. registers the `dshalerts:` scheme (idempotent, per user)
 * 2. prints the command Windows would run
 * 3. dry-runs lib/focus.ps1 so the window lookup itself is exercised
 *
 * It does not fake a toast click - Windows only ShellExecutes the URI on a real
 * click - but the URI round trip is exactly what a click performs.
 *
 * Run: node test/activate.mjs   (or with DSH_APP_EXE=<exe> to test relaunch)
 */
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { ensureProtocol, activationCommand, resolveAppExe } from '../lib/protocol.js'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const failures = []
const note = (ok, label) => {
  if (!ok) failures.push(label)
  console.log((ok ? 'ok   ' : 'FAIL ') + label)
}

if (process.platform !== 'win32') {
  console.log('skip: not windows')
  process.exit(0)
}

const appExe = resolveAppExe()
console.log('app exe:', appExe || '(unknown - focus still works, relaunch disabled)')

const state = ensureProtocol()
console.log('protocol:', JSON.stringify(state, null, 2))
note(state.ok, 'dshalerts: scheme registered')

const reg = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'reg.exe')
const query = spawnSync(reg, ['query', 'HKCU\\Software\\Classes\\dshalerts\\shell\\open\\command', '/ve'], { encoding: 'utf8' })
note(query.status === 0, 'HKCU\\Software\\Classes\\dshalerts\\shell\\open\\command exists')
note(String(query.stdout || '').includes(path.join(root, 'lib', 'focus.ps1')), 'handler points at lib/focus.ps1')
note(String(query.stdout || '').includes(path.join(root, 'lib', 'launch.vbs')), 'handler goes through launch.vbs (no console flash)')
note(activationCommand().command.includes(path.join(root, 'lib', 'focus.ps1')), 'generated command targets the same lib')

const ps = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
const dry = spawnSync(ps, [
  '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
  '-File', path.join(root, 'lib', 'focus.ps1'),
  '-App', appExe,
  '-DryRun'
], { encoding: 'utf8', timeout: 30000 })
const verdict = String(dry.stdout || '').trim().split(/\r?\n/).filter(Boolean).pop() || ''
console.log('focus.ps1:', verdict)
let parsed = null
try { parsed = JSON.parse(verdict) } catch (err) { parsed = null }
note(!!parsed && parsed.ok === true, 'focus.ps1 reports ok')
/* 'focused' = the window was found (normal desktop); 'would-launch' = this shell
 * runs in an isolated window station and saw no window - both mean the script
 * ran end to end. */
const looked = !!parsed && (parsed.action === 'focused' || parsed.action === 'would-launch')
note(looked, 'focus.ps1 window lookup ran (action=' + (parsed && parsed.action) + ')')

console.log(failures.length === 0 ? 'RESULT: ok' : 'RESULT: FAILED (' + failures.length + ')')
process.exit(failures.length === 0 ? 0 : 1)
