# 更新记录

遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## 0.5.2

- 收录到 [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) 用到的描述、图标与关键词：新增 `assets/icon-180.png`（市场卡片图标：琥珀色「!」+ 绿色对勾），`package.json` 补中英文 `keywords`，README 加「常见搜法」一节。**没有行为变化**，已经在用 0.5.1 的不用升级。

## 0.5.1

- **修「任务运行中点通知，窗口提到最前又瞬间消失」**：窗口在托盘里/最小化时不再用外部 `ShowWindow` 硬拉（那样会和应用自己的可见性状态打架，close-to-tray 那条路随后又把窗口收起），改为**再启动一次应用**——第二个进程拿不到单实例锁，Electron 把它交给正在运行的实例，走应用自己的 `focusPrimaryWindow()`，和点托盘图标是同一条路。窗口只是被压在别的窗口后面时仍直接 `SetForegroundWindow`。
- 无论走哪条路，抢完前台都有 2.6 秒**看门狗**：窗口若在这期间被收起，立即 `ShowWindow(SW_SHOW)` + 重新置前，脚本退出前保证窗口是可见的。
- 激活日志新增 `visible` / `reshows` 字段，`method` 新增 `relaunch` / `show-restore` / `reshow` 三种取值，排查时能直接看出走了哪条路、补了几次。
- `focus.ps1` 新增 `-Mode all|plain|attach|attach-show|alt|switch` 诊断开关（默认 `all`），可在个别 Windows 上锁定某一种抢前台策略。

## 0.5.0

- **改名**：`dsh-approval-toast` → **`dsh-desktop-alerts`**（原名和 npm / 市场上几个插件撞得太厉害）。包名、cordis 插件 id、设置页分组 id、HTTP 路由（`/dsh-desktop-alerts/*`）、配置与日志文件名、AUMID（`DeepSeek.Harness.DesktopAlerts`）、点击协议（`dshalerts:`）全部跟着改。
- **升级不用重配**：首次启动会自动把 `~/.dsh/dsh-approval-toast.json` 与旧日志搬到新名字下，并删掉旧版注册表项（`dshapproval:` 协议、`DeepSeek.Harness.Approval` 应用 ID），只做一次，之后由 `~/.dsh/dsh-desktop-alerts.migrated` 标记。
- 设置页标题由「审批 / 完成通知」改为「桌面通知」，与插件名一致。
- 升级前记得 `dsh plugin remove dsh-approval-toast`，否则新旧两份会同时加载、通知弹两遍。

## 0.4.2

- 切前台更可靠：`SetForegroundWindow` 被前台锁拒绝时，依次尝试 `AttachThreadInput`（挂到当前前台线程的输入队列）、模拟一次 `ALT` 击键解除锁、最后 `SwitchToThisWindow`；`/status` 的激活日志多了 `method` 字段，能看出是哪一步成功的。
- 修「最小化时反而不弹通知」：最小化的窗口仍然可能是前台窗口，旧逻辑会误判成「用户正看着 DSH」而静默跳过；现在前台窗口若已最小化或不可见，一律按「没在看」处理，照常弹通知。
- `resolveAppExe()` 增加缓存回退（`%DSH_HOME%\dsh-desktop-alerts.activate.json`）：宿主进程不是 `DeepSeek Harness.exe`（例如以 `node` 跑测试）时，沿用上一次解析到的 exe，避免写进注册表的命令丢掉「DSH 已关闭就重新启动」的能力。
- 点击通知的注册命令改用 `wscript.exe` 直跑 `launch.vbs`（不再经 `cmd.exe`），路径里的空格与全角括号不必再转义，也不会闪黑框。

## 0.4.1

- **修好「点通知不会回到 DSH」**：未打包的 Win32 应用从 toast 被点击时，Windows 会去找 AUMID 对应的 COM 激活器，找不到就把这次点击丢掉——这是此前的根本原因。现在 toast 带 `activationType="protocol" launch="dshalerts:focus"`，插件启动时在 `HKCU\Software\Classes\dshalerts` 注册一个按用户生效的 URI 处理器（不需要管理员），点击经由 `lib/launch.vbs` 无窗口地跑 `lib/focus.ps1`：最小化就还原、被挡住就提到前台；DSH 已关掉时用记录的 exe 路径重新启动它。
- 新增 `lib/protocol.js`（注册与命令拼装，幂等，启动时只比对一次）与 `lib/focus.ps1`（枚举窗口、`ShowWindow(SW_RESTORE)`、`SetForegroundWindow`，失败再 `SwitchToThisWindow`；支持 `-DryRun` 只报告不改状态）。
- 设置页新增开关「点击通知切回 DeepSeek Harness 窗口」（默认开），关掉后 toast 不再挂 `launch`，点它和以前一样什么都不做。
- `/dsh-desktop-alerts/status` 增加 `protocol` 段，能看到注册是否成功、用的是 `wscript` 还是隐藏的 PowerShell、以及实际写入的命令行。
- 打包回归测试新增：`focus.ps1` / `launch.vbs` 随包、纯 ASCII、宿主声明激活 URI、toast 声明协议激活。

## 0.4.0

- **完成通知换图标**：任务完成的通知左侧改为**绿色对勾**（`lib/icon-task.png`），审批通知保持 DSH 图标。此前 toast 没有 `appLogoOverride`，Windows 只能拿 AUMID 的应用图标兜底，未打包应用会显示成通用占位图（那个「感叹号」）。现在两类通知都显式指定图片，图标跟着通知类型走。
- `lib/notify.ps1` 新增 `-DryRun`：只构建并打印 toast XML，不真正弹窗，方便在无通知平台的环境（CI、沙箱、远程会话）里回归图标与模板。
- `tools/deploy.mjs` 改为自动遍历（不再维护文件白名单），复制时逐个剥 BOM、校验 `package.json`，并自动把插件补进 profile 的 `dsh.profile.bundles`；新增 `--dest` 参数。
- 打包回归测试新增：两个图标存在、宿主机指向对勾图标、toast 设置 `appLogoOverride`、`LICENSE` 随包。
- 仓库整理：补 `LICENSE`、`CHANGELOG`、`.gitignore`、`.gitattributes`、CI。

## 0.3.1

- 修复 0.3.0 装上后插件直接失效的问题：`package.json` 被写进了 UTF-8 BOM（`EF BB BF`），DSH 校验安装包时对原始文本做 `JSON.parse`，开头多出的 U+FEFF 直接抛 `Unexpected token`，整个包被判定「无法校验」，profile 启动时拒绝加载（表现就是设置页消失、通知不再弹）。现在：
  - 随包文件全部去掉 BOM，新增 `test/package-json.mjs` 把「无 BOM / LF / 契约字段齐全」变成可回归的检查；
  - 新增 `tools/deploy.mjs`：部署时逐文件剥 BOM、校验 JSON，并自动把 `dsh-desktop-alerts` 补回 profile 的 `dsh.profile.bundles`；
  - 读配置先剥 BOM；遇到坏 JSON 先把坏文件备份成 `*.broken-<时间戳>`、再用默认值重建并记一条 `config-repair`；写入改成「临时文件 + rename」原子替换。

## 0.3.0

- 新增 `session/event → turn/end` 完成通知：`duration="short"` 几秒自动收起（用 `History.Remove` 真正关掉横幅），正文带对话标题，子代理会话与 `aborted` 忽略，同一轮只弹一次。
- 审批提示音改为可选「闹钟声 / 系统提示音 / 自定义文件 / 静音」，并可设置响铃 1–60 秒；新增 `lib/sound.ps1`，到点自动停，审批 toast 本身改为静音（toast 的循环音频没法按时停止）。
- 设置页新增「任务完成」分组与两个测试按钮。

## 0.2.0

- 修复审批抓取：`approval/request` 监听改为 `{ prepend: true, global: true }`（作用域外监听会被 `scopeTarget` 过滤掉，此前可能一条都不弹）。
- 加了一层 `approval.request()` 方法包装作兜底，两条路径共用去重。
- 设置页新增「已捕获审批请求」计数，区分事件钩子与服务钩子。

## 0.1.0

- 首个版本：Windows toast（urgent / alarm 穿透勿扰与全屏）、焦点静音、重复提醒、设置页。
