"""Render the green check that sits left of a "task finished" toast title.

Windows draws `appLogoOverride` at ~48px, so the shape is drawn 4x oversized
and downsampled to keep the edges clean.

  lib/icon-task.png   green disc + white check -> task-complete notifications
  lib/icon.png        the DSH mark            -> approval notifications

Run: python tools/make-icons.py   (needs Pillow)
"""
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent.parent / "lib"
SCALE = 4
SIZE = 256


def check():
    img = Image.new("RGBA", (SIZE * SCALE, SIZE * SCALE), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pad = 18 * SCALE
    d.ellipse((pad, pad, SIZE * SCALE - pad, SIZE * SCALE - pad), fill=(22, 163, 74))  # #16A34A
    w = 20 * SCALE
    pts = [(72 * SCALE, 132 * SCALE), (114 * SCALE, 174 * SCALE), (186 * SCALE, 88 * SCALE)]
    d.line(pts, fill=(255, 255, 255, 255), width=w, joint="curve")
    r = w // 2
    for x, y in (pts[0], pts[2]):
        d.ellipse((x - r, y - r, x + r, y + r), fill=(255, 255, 255, 255))
    return img


OUT.mkdir(parents=True, exist_ok=True)
check = check().resize((SIZE, SIZE), Image.LANCZOS)
target = OUT / "icon-task.png"
check.save(target, optimize=True)
print("wrote", target)

# The AUMID registry entry wants an .ico; a PNG there often renders as the
# generic placeholder in Settings → Notifications and in the action centre.
brand = Image.open(OUT / "icon.png").convert("RGBA")
ico = OUT / "icon.ico"
brand.save(ico, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("wrote", ico)
