"""Render the storefront tile used by the dsh-market listing.

The catalog draws it at ~96 px and falls back to the owner avatar when the
entry has no `icon:`, so the mark has to read at that size.

    assets/icon-180.png   storefront tile (referenced by the catalog entry)
    assets/icon-512.png   same art, for the README / npm page

Both notification kinds appear side by side — the amber "!" of an approval
and the green check of a finished turn — because the plugin is those two
things and nothing else.

Run: python tools/make-storefront.py   (needs Pillow)
"""
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent.parent / "assets"
SIZE = 180
SCALE = 4
AMBER = (245, 158, 11)  # #F59E0B
GREEN = (22, 163, 74)  # #16A34A
INK = (15, 23, 42)  # #0F172A


def tile():
    s = SIZE * SCALE
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Rounded-square background, same geometry Electron uses for app tiles.
    d.rounded_rectangle((0, 0, s - 1, s - 1), radius=int(s * 0.22), fill=INK)

    r = int(s * 0.205)
    cy = s // 2
    left = (int(s * 0.335), cy)
    right = (int(s * 0.665), cy)
    ring = int(s * 0.022)

    # Approval: amber disc, white exclamation mark.
    d.ellipse((left[0] - r, cy - r, left[0] + r, cy + r), fill=AMBER)
    bar_w = int(r * 0.34)
    bar_top = cy - int(r * 0.55)
    bar_bottom = cy + int(r * 0.08)
    d.rounded_rectangle(
        (left[0] - bar_w // 2, bar_top, left[0] + bar_w // 2, bar_bottom),
        radius=bar_w // 2,
        fill=(255, 255, 255, 255),
    )
    dot_r = bar_w // 2
    dot_y = cy + int(r * 0.42)
    d.ellipse((left[0] - dot_r, dot_y - dot_r, left[0] + dot_r, dot_y + dot_r), fill=(255, 255, 255, 255))

    # Finished turn: green disc, white check.
    d.ellipse((right[0] - r, cy - r, right[0] + r, cy + r), fill=GREEN, outline=INK, width=ring)
    w = int(r * 0.36)
    pts = [
        (right[0] - int(r * 0.38), cy + int(r * 0.02)),
        (right[0] - int(r * 0.06), cy + int(r * 0.34)),
        (right[0] + int(r * 0.40), cy - int(r * 0.34)),
    ]
    d.line(pts, fill=(255, 255, 255, 255), width=w, joint="curve")
    r2 = w // 2
    for x, y in (pts[0], pts[2]):
        d.ellipse((x - r2, y - r2, x + r2, y + r2), fill=(255, 255, 255, 255))

    return img


OUT.mkdir(parents=True, exist_ok=True)
art = tile()
for size in (180, 512):
    target = OUT / f"icon-{size}.png"
    art.resize((size, size), Image.LANCZOS).save(target, optimize=True)
    print("wrote", target)
