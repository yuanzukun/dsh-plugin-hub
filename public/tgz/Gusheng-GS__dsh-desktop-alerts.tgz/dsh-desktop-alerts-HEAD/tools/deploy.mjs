/* Copy this working tree into the DSH install location, safely.
 *
 * Two Windows-specific hazards this script exists to eliminate:
 *  1. UTF-8 BOMs. DSH validates a package with JSON.parse over the raw text, so
 *     a BOM-prefixed package.json makes the plugin "denied" and it silently
 *     stops loading. Every copied text file is stripped on the way out.
 *  2. A missing `dsh.profile.bundles` entry. Re-installing with pnpm does not
 *     re-append it, so the plugin would be present but never loaded.
 *
 * node tools/deploy.mjs [--dry-run] [--dest <dir>]
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const SRC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DSH_HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const argDest = process.argv.indexOf('--dest')
const DEST = argDest > -1
  ? path.resolve(process.argv[argDest + 1])
  : path.join(DSH_HOME, 'plugins', 'dsh-desktop-alerts')
const PROFILE = path.join(DSH_HOME, 'profiles', 'desktop', 'package.json')
const BUNDLE = 'dsh-desktop-alerts'
const dryRun = process.argv.includes('--dry-run')

const TEXT_EXT = new Set(['.json', '.md', '.yml', '.yaml', '.js', '.mjs', '.cjs', '.ps1'])
const SKIP_DIRS = new Set(['node_modules', '.git', '.home', 'test/.home'])

function walk(dir, base = dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    const rel = path.relative(base, full).split(path.sep).join('/')
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name) || SKIP_DIRS.has(rel)) continue
      walk(full, base, out)
    } else {
      out.push(rel)
    }
  }
  return out
}

const stripBom = (text) => text.replace(/^\uFEFF/, '')

function writeAtomically(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  const tmp = file + '.tmp-deploy'
  fs.writeFileSync(tmp, text, 'utf8')
  fs.renameSync(tmp, file)
}

const files = walk(SRC).filter((rel) => rel !== 'package-lock.json' && !rel.startsWith('tools/'))

console.log('source:', SRC)
console.log('dest:  ', DEST)
if (dryRun) {
  console.log('dry run, nothing written; files:', files.join(', '))
  process.exit(0)
}

let deBombed = 0
for (const rel of files) {
  const from = path.join(SRC, rel)
  const to = path.join(DEST, rel)
  if (!TEXT_EXT.has(path.extname(rel).toLowerCase())) {
    fs.mkdirSync(path.dirname(to), { recursive: true })
    fs.copyFileSync(from, to)
    console.log('  bin', rel, fs.statSync(from).size + 'b')
    continue
  }
  const raw = fs.readFileSync(from, 'utf8')
  if (raw.charCodeAt(0) === 0xFEFF) deBombed += 1
  const text = stripBom(raw)
  if (rel === 'package.json') JSON.parse(text) // fail loudly instead of shipping junk
  writeAtomically(to, text)
  console.log('  ok ', rel, text.length + 'ch')
}

/* the installed package.json must parse without a BOM */
const installed = fs.readFileSync(path.join(DEST, 'package.json'), 'utf8')
if (installed.charCodeAt(0) === 0xFEFF) throw new Error('installed package.json still starts with a BOM')
const pkg = JSON.parse(installed)
console.log('installed version:', pkg.version, '| de-BOMmed on the way:', deBombed)

/* keep the profile's bundle list in sync */
if (fs.existsSync(PROFILE)) {
  const raw = fs.readFileSync(PROFILE, 'utf8')
  const profile = JSON.parse(stripBom(raw))
  profile.dsh = profile.dsh || {}
  profile.dsh.profile = profile.dsh.profile || {}
  const bundles = Array.isArray(profile.dsh.profile.bundles) ? profile.dsh.profile.bundles : []
  if (!bundles.includes(BUNDLE)) {
    bundles.push(BUNDLE)
    profile.dsh.profile.bundles = bundles
    writeAtomically(PROFILE, JSON.stringify(profile, null, 2) + '\n')
    console.log('profile bundles: added', BUNDLE)
  } else {
    console.log('profile bundles: already present')
  }
} else {
  console.log('profile bundles: skipped (no profile at', PROFILE + ')')
}
