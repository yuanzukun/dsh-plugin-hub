# 发布清单

本仓库已经推到 https://github.com/Gusheng-GS/dsh-desktop-alerts，下面第 1 步是「以后换人维护时」才需要改的信息，其余步骤按顺序执行即可。命令都在仓库根目录跑（PowerShell）。

## 1. 仓库信息（已填好，换人维护时才动）

- package.json 末尾：
  `json
  "repository": { "type": "git", "url": "git+https://github.com/Gusheng-GS/dsh-desktop-alerts.git" },
  "bugs": { "url": "https://github.com/Gusheng-GS/dsh-desktop-alerts/issues" },
  "homepage": "https://github.com/Gusheng-GS/dsh-desktop-alerts#readme"
  `
- LICENSE 第 3 行：Copyright (c) 2026 Gusheng-GS
- README.md 里「方式一：从 GitHub 安装」的仓库地址。

## 1.5 仓库的 Description 和 Topics（在 GitHub 网页上填）

Description 直接用这句（约 60 字，搜索和卡片都够用）：

> DeepSeek Harness 插件：审批 / 任务完成时弹 Windows 系统通知，穿透「请勿打扰」与全屏，点一下切回 DSH。

Topics（仓库右上角齿轮里填，逗号分隔）：

```
dsh, dsh-plugin, deepseek-harness, windows, notification, toast, powershell, approval
```

## 2. 本地先跑一遍检查

```powershell
npm test              # 打包契约（无 BOM / LF / 图标 / 协议声明）+ 设置页渲染
npm run test:smoke    # 宿主半边：审批瀑布、完成事件、HTTP 路由（会真的弹测试通知）
```

两条都 `RESULT: ok` 再往下走。CI（`.github/workflows/ci.yml`）在 Windows runner 上跑的是同一套。

## 3. 推送新版本

```powershell
git add -A
git commit -m "fix: 点通知切回窗口不再闪现（v0.5.1）"
git push
git tag v0.5.1
git push origin v0.5.1
```

> 每次提交前瞄一眼 `git status`：`node_modules/`、`test/.home/`、`*.log`、`~/.dsh` 相关文件都不该出现（`.gitignore` 已挡住）。

## 4. 发 Release（可选但推荐）

在 GitHub 的 Releases 页面用 `v0.5.1` 这个 tag 建一个 Release，正文直接粘 `CHANGELOG.md` 里对应段落。

## 5. 发到 npm（市场里的「一键安装」依赖这一步）

```powershell
npm login            # 首次
npm publish          # 包名 dsh-desktop-alerts
```

`package.json` 已带 `dsh-plugin` 关键词、`dsh.bundle.patch`、`dsh.client`，`files` 只打包 `lib`、`cordis.patch.yml`、`README.md`、`LICENSE`。发布后 DSH 用户可以直接：

```powershell
dsh plugin add dsh-desktop-alerts
```

## 6. 上架 dsh-market（可选）

- 在 [dsh-market](https://github.com/dsh-market/dsh-market) 提 PR 加条目，或等它索引 npm 上的包；
- 建议补一张设置页截图 `docs/screenshot.png` 贴到 README 顶部，市场卡片更容易被点；
- 描述用 `package.json` 里那句中文，市场卡片直接读它。