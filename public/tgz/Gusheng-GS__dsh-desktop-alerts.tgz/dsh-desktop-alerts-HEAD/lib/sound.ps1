#requires -Version 5.1
<#
  dsh-desktop-alerts :: sound player
  ---------------------------------------------------------------------------
  Plays one file and exits after `-Seconds`, which is what bounds the approval
  alarm: a WAV is looped through SoundPlayer (winmm) and stops when the process
  exits, so "how long should it ring" is a real duration instead of a toast
  lifetime. Non-WAV files fall back to WPF's MediaPlayer.

  Pure ASCII on purpose (PowerShell 5.1 mis-decodes non-ASCII .ps1 without BOM).

  Usage: powershell.exe -NoProfile -ExecutionPolicy Bypass -File sound.ps1 `
             -Path "C:\path\sound.wav" -Seconds 8 [-Once]

  Never prints anything; a failure only affects its own exit code, because the
  host spawns it detached and ignores the result.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Path,
  [int]$Seconds = 8,
  [switch]$Once
)

$ErrorActionPreference = 'Stop'
try {
  if (-not (Test-Path -LiteralPath $Path)) { exit 3 }
  $seconds = [Math]::Max(1, [Math]::Min(120, $Seconds))
  $ext = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()

  if ($ext -eq '.wav') {
    $player = New-Object System.Media.SoundPlayer $Path
    $player.Load()
    if ($Once) {
      $player.PlaySync()
    } else {
      $player.PlayLooping()
      Start-Sleep -Seconds $seconds
      $player.Stop()
    }
  } else {
    Add-Type -AssemblyName PresentationCore
    $media = New-Object System.Windows.Media.MediaPlayer
    $media.Open((New-Object System.Uri($Path)))
    Start-Sleep -Milliseconds 400
    $media.Play()
    if ($Once) {
      # give the decoder time to finish a short clip
      Start-Sleep -Seconds 2
    } else {
      Start-Sleep -Seconds $seconds
    }
    $media.Stop()
    $media.Close()
  }
  exit 0
} catch {
  exit 1
}
