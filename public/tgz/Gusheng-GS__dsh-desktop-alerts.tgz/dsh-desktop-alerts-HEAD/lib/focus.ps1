#requires -Version 5.1
<#
  dsh-desktop-alerts :: bring the DSH window back after a toast click
  ---------------------------------------------------------------------------
  Windows calls this through the `dshalerts:` protocol handler that
  lib/index.js registers under HKCU\Software\Classes. A toast cannot activate an
  unpackaged app directly (there is no COM activator), but it can ShellExecute a
  URI - so the click lands here.

  Pure-ASCII script on purpose (PS 5.1 mis-decodes non-ASCII .ps1 bytes without
  a BOM); everything it writes out is ASCII JSON.

  Two ways back, chosen by the state the window is in:
  * parked (hidden to the tray, or minimized) - relaunching the app is the only
    path that keeps the app's own visibility state in sync: the second process
    never wins the single-instance lock, so Electron hands it to the running
    instance, whose handler calls focusPrimaryWindow(). Win32 ShowWindow on a
    parked window merely races that state and loses.
  * visible but behind another window - ask for the foreground directly.

  A short watchdog follows either path: while a turn is running the window
  occasionally gets hidden right after it gains focus, and the watchdog puts it
  back before the script exits.

  Usage (registered form):
    powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass \
      -File focus.ps1 -App "<DeepSeek Harness.exe>" -Log "<log file>"
  Or dry run (report what it would do, change nothing):
    ... -File focus.ps1 -App "<exe>" -DryRun
  Diagnostics: -Mode all|plain|attach|attach-show|alt|switch forces one
  foreground strategy, so a misbehaving Windows build can be pinned down.
#>
[CmdletBinding()]
param(
  [string]$App = '',
  [string]$Log = '',
  [string]$Uri = '',
  [string]$Mode = '',
  [switch]$DryRun
)

if (-not $Mode) { $Mode = $env:DSH_FOCUS_MODE }
if (-not $Mode) { $Mode = 'all' }

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Process names of the Electron app; the .exe basename is used when known so a
# renamed build still matches.
$names = @('DeepSeek Harness')
if ($App) {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($App)
  if ($base -and ($names -notcontains $base)) { $names += $base }
}

function Emit($obj) {
  try { [Console]::Out.WriteLine(($obj | ConvertTo-Json -Compress -Depth 4)) } catch { }
}

function Append-Log($obj) {
  if (-not $Log) { return }
  try {
    $line = ($obj | ConvertTo-Json -Compress -Depth 4) + "`n"
    $dir = [System.IO.Path]::GetDirectoryName($Log)
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { [void][System.IO.Directory]::CreateDirectory($dir) }
    [System.IO.File]::AppendAllText($Log, $line, (New-Object System.Text.UTF8Encoding($false)))
  } catch { }
}

function Init-Win32() {
  if ('DshActivateWin32' -as [type]) { return }
  Add-Type -Namespace '' -Name 'DshActivateWin32' -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern System.IntPtr GetForegroundWindow();
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool SetForegroundWindow(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool ShowWindow(System.IntPtr hWnd, int nCmdShow);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool IsIconic(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool IsWindowVisible(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern void SwitchToThisWindow(System.IntPtr hWnd, bool fAltTab);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern uint GetWindowThreadProcessId(System.IntPtr hWnd, out uint lpdwProcessId);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern int GetWindowTextLength(System.IntPtr hWnd);
public delegate bool EnumWindowsProc(System.IntPtr hWnd, System.IntPtr lParam);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, System.IntPtr lParam);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool BringWindowToTop(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("kernel32.dll")]
public static extern uint GetCurrentThreadId();
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, System.UIntPtr dwExtraInfo);
'@
}

function Find-AppWindow() {
  Init-Win32
  $result = @{ hwnd = [System.IntPtr]::Zero; pid = 0; title = '' }
  $pids = @(Get-Process -Name $names -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
  if ($pids.Count -eq 0) { return $result }
  $callback = [DshActivateWin32+EnumWindowsProc] {
    param([System.IntPtr]$hWnd, [System.IntPtr]$lParam)
    try {
      if (-not [DshActivateWin32]::IsWindowVisible($hWnd)) { return $true }
      if ([DshActivateWin32]::GetWindowTextLength($hWnd) -le 0) { return $true }
      $ownerPid = 0
      [void][DshActivateWin32]::GetWindowThreadProcessId($hWnd, [ref]$ownerPid)
      if (-not $ownerPid) { return $true }
      if ($pids -notcontains [int]$ownerPid) { return $true }
      $result.hwnd = $hWnd
      $result.pid = [int]$ownerPid
      return $false   # stop at the first titled window of the app
    } catch { return $true }
  }
  try { [void][DshActivateWin32]::EnumWindows($callback, [System.IntPtr]::Zero) } catch { }
  return $result
}

$found = Find-AppWindow

if ($found.hwnd -eq [System.IntPtr]::Zero) {
  if ($DryRun) {
    $dry = @{ ok = $true; action = 'would-launch'; app = $App; exists = (Test-Path -LiteralPath $App) }
    Emit $dry
    exit 0
  }
  $started = $false
  if ($App -and (Test-Path -LiteralPath $App)) {
    try { Start-Process -FilePath $App | Out-Null; $started = $true } catch { $started = $false }
  }
  $payload = @{ at = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds(); kind = 'activate'; action = 'launched'; ok = $started; app = $App }
  Emit $payload
  Append-Log $payload
  exit 0
}

$restored = $false
$method = 'none'
$reshows = 0
$doPlain = @('all', 'plain') -contains $Mode
$doAttach = @('all', 'attach', 'attach-show') -contains $Mode
$doShow = $Mode -ne 'attach-show'
$doAlt = @('all', 'alt') -contains $Mode
$doSwitch = @('all', 'switch') -contains $Mode
if (-not $DryRun) {
  $h = $found.hwnd
  $parked = (-not [DshActivateWin32]::IsWindowVisible($h)) -or [DshActivateWin32]::IsIconic($h)

  if ($parked) {
    # Parked in the tray (hidden) or minimized. Pulling it up with ShowWindow
    # from the outside leaves the app's own visibility state out of sync, and the
    # close-to-tray path wins the next race and hides it again. Ask the app to
    # restore itself instead: a second launch never gets the single-instance
    # lock, so Electron routes it to the owner, whose handler calls
    # focusPrimaryWindow() - the same path the tray icon uses.
    $started = $false
    if ($App -and (Test-Path -LiteralPath $App)) {
      try { Start-Process -FilePath $App | Out-Null; $started = $true } catch { $started = $false }
    }
    if ($started) {
      $method = 'relaunch'
      $wait = [DateTimeOffset]::UtcNow.AddMilliseconds(2500)
      while ([DateTimeOffset]::UtcNow -lt $wait) {
        Start-Sleep -Milliseconds 100
        if ([DshActivateWin32]::IsWindowVisible($h) -and ([DshActivateWin32]::GetForegroundWindow() -eq $h)) { break }
      }
    }
    if (-not ([DshActivateWin32]::IsWindowVisible($h) -and ([DshActivateWin32]::GetForegroundWindow() -eq $h))) {
      if ([DshActivateWin32]::IsIconic($h)) {
        [void][DshActivateWin32]::ShowWindow($h, 9)   # SW_RESTORE
        $restored = $true
      }
      [void][DshActivateWin32]::ShowWindow($h, 5)     # SW_SHOW
      [void][DshActivateWin32]::SetForegroundWindow($h)
      $method = 'show-restore'
    }
  } else {
    $fg = [DshActivateWin32]::GetForegroundWindow()
    if ($fg -ne $h) {
      if ($doPlain) {
        # 1) Plain request. Usually refused while another app owns the foreground
        #    lock, but free to try.
        [void][DshActivateWin32]::SetForegroundWindow($h)
        $method = 'SetForegroundWindow'
      }
    } else {
      $method = 'already-foreground'
    }

    if ($doAttach -and [DshActivateWin32]::GetForegroundWindow() -ne $h) {
      # 2) Attach to the foreground thread's input queue: while attached we are
      #    allowed to hand it the foreground window.
      $fgPid = 0
      $fgThread = [DshActivateWin32]::GetWindowThreadProcessId($fg, [ref]$fgPid)
      $self = [DshActivateWin32]::GetCurrentThreadId()
      if ($fgThread -and $fgThread -ne $self) {
        $attached = [DshActivateWin32]::AttachThreadInput($self, $fgThread, $true)
        if ($attached) {
          try {
            [void][DshActivateWin32]::BringWindowToTop($h)
            if ($doShow) { [void][DshActivateWin32]::ShowWindow($h, 5) }   # SW_SHOW
            [void][DshActivateWin32]::SetForegroundWindow($h)
          } finally {
            [void][DshActivateWin32]::AttachThreadInput($self, $fgThread, $false)
          }
          $method = 'AttachThreadInput'
        }
      }
    }

    if ($doAlt -and [DshActivateWin32]::GetForegroundWindow() -ne $h) {
      # 3) Tap ALT: Windows drops the foreground lock once it sees keyboard input,
      #    after which SetForegroundWindow goes through.
      [DshActivateWin32]::keybd_event(0x12, 0, 0, [System.UIntPtr]::Zero)
      [DshActivateWin32]::keybd_event(0x12, 0, 0x0002, [System.UIntPtr]::Zero)
      [void][DshActivateWin32]::SetForegroundWindow($h)
      $method = 'alt-tap'
    }

    if ($doSwitch -and [DshActivateWin32]::GetForegroundWindow() -ne $h) {
      # 4) Last resort: the shell's own "switch to this window".
      [DshActivateWin32]::SwitchToThisWindow($h, $true)
      $method = 'SwitchToThisWindow'
    }
  }
  # 5) Watchdog. While a turn is running the app occasionally hides the window
  #    again a moment after it gains focus (the close-to-tray path wins the
  #    race). Watch the window for a couple of seconds and put it back.
  $reshows = 0
  $stable = 0
  $deadline = [DateTimeOffset]::UtcNow.AddMilliseconds(2600)
  while ([DateTimeOffset]::UtcNow -lt $deadline) {
    Start-Sleep -Milliseconds 100
    $hwnd = $found.hwnd
    if (-not [DshActivateWin32]::IsWindowVisible($hwnd)) {
      [void][DshActivateWin32]::ShowWindow($hwnd, 5)   # SW_SHOW
      [void][DshActivateWin32]::SetForegroundWindow($hwnd)
      $reshows = $reshows + 1
      $stable = 0
      $method = 'reshow'
    } elseif ([DshActivateWin32]::GetForegroundWindow() -eq $hwnd) {
      $stable = $stable + 1
      if ($stable -ge 7) { break }
    } else {
      $stable = 0
    }
  }
}

$isForeground = ([DshActivateWin32]::GetForegroundWindow() -eq $found.hwnd)
$isVisible = [DshActivateWin32]::IsWindowVisible($found.hwnd)
$payload = @{
  at = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  kind = 'activate'
  action = 'focused'
  ok = $true
  pid = $found.pid
  hwnd = $found.hwnd.ToInt64()
  restored = $restored
  method = $method
  foreground = $isForeground
  visible = $isVisible
  reshows = $reshows
  dryRun = [bool]$DryRun
}
Emit $payload
Append-Log $payload
