#requires -Version 5.1
<#
  dsh-desktop-alerts :: Windows toast sender
  ---------------------------------------------------------------------------
  Pure-ASCII script on purpose: PowerShell 5.1 mis-decodes non-ASCII .ps1
  bytes without a BOM, so every localized string travels through the UTF-8
  JSON payload instead.

  Usage:  powershell.exe -NoProfile -ExecutionPolicy Bypass -File notify.ps1 -JsonPath <file.json>

  Payload (UTF-8 JSON):
  {
    "title": "DSH 需要审批",
    "body": "bash: sandbox escalation ...",
    "appId": "DeepSeek.Harness.DesktopAlerts",
    "displayName": "DeepSeek Harness",
    "iconPath": "C:\\...\\icon.png",
    "logo": "C:\\...\\icon-task.png",
    "scenario": "urgent" | "alarm" | "default",
    "audio": "silent" | "default" | "chime" | "alarmLoop",
    "duration": "short" | "long",
    "sound": true,
    "silentAudio": false,
    "skipWhenFocused": true,
    "focusProcesses": ["DeepSeek Harness"],
    "tag": "approval-1234",
    "group": "dsh-approval"
  }

  Prints one JSON line: {"ok":true,"action":"shown"|"skipped-focus","scenario":"...","setting":"..."}
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$JsonPath,
  # Build the toast XML and print it instead of showing a banner. Used by the
  # test suite, which runs in environments without a notification platform.
  [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Emit($obj) {
  try { [Console]::Out.WriteLine(($obj | ConvertTo-Json -Compress -Depth 6)) } catch { }
}

function Focused-ProcessName() {
  try {
    if (-not ('DshToastWin32' -as [type])) {
      Add-Type -Namespace '' -Name 'DshToastWin32' -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern System.IntPtr GetForegroundWindow();
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool IsIconic(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool IsWindowVisible(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern uint GetWindowThreadProcessId(System.IntPtr hWnd, out uint lpdwProcessId);
'@
    }
    $hwnd = [DshToastWin32]::GetForegroundWindow()
    if ($hwnd -eq [System.IntPtr]::Zero) { return '' }
    # A minimized window can still be the foreground window: the user has it
    # tucked away and wants the notification, so do not treat it as "looking at DSH".
    if ([DshToastWin32]::IsIconic($hwnd)) { return '' }
    if (-not [DshToastWin32]::IsWindowVisible($hwnd)) { return '' }
    $pid = 0
    [void][DshToastWin32]::GetWindowThreadProcessId($hwnd, [ref]$pid)
    if (-not $pid) { return '' }
    $p = Get-Process -Id $pid -ErrorAction SilentlyContinue
    if ($p) { return [string]$p.ProcessName }
    return ''
  } catch { return '' }
}

try {
  $raw = [System.IO.File]::ReadAllText($JsonPath, [System.Text.Encoding]::UTF8)
} catch {
  Emit @{ ok = $false; error = ('payload unreadable: ' + $_.Exception.Message) }
  exit 2
}

try { $p = $raw | ConvertFrom-Json } catch {
  Emit @{ ok = $false; error = ('payload invalid json: ' + $_.Exception.Message) }
  exit 2
}

$title = [string]$p.title
if (-not $title) { $title = 'DeepSeek Harness' }
$body = [string]$p.body
$appId = [string]$p.appId
if (-not $appId) { $appId = 'DeepSeek.Harness.DesktopAlerts' }
$displayName = [string]$p.displayName
if (-not $displayName) { $displayName = 'DeepSeek Harness' }
$iconPath = [string]$p.iconPath
$logoPath = [string]$p.logo
$scenario = [string]$p.scenario
if (-not $scenario) { $scenario = 'alarm' }
$sound = $true
if ($null -ne $p.sound) { $sound = [bool]$p.sound }
$skipWhenFocused = $true
if ($null -ne $p.skipWhenFocused) { $skipWhenFocused = [bool]$p.skipWhenFocused }

# ---- focus gate ----------------------------------------------------------
if ($skipWhenFocused -and -not $DryRun) {
  $names = @()
  if ($p.focusProcesses) { $names = @($p.focusProcesses) }
  if ($names.Count -eq 0) { $names = @('DeepSeek Harness') }
  $fg = Focused-ProcessName
  foreach ($n in $names) {
    if ($fg -and $fg.ToLowerInvariant() -eq ([string]$n).ToLowerInvariant()) {
      Emit @{ ok = $true; action = 'skipped-focus'; foreground = $fg }
      exit 0
    }
  }
}

# ---- register AppUserModelID (idempotent, per-user) ----------------------
try {
  if (-not $DryRun) {
    $regPath = 'HKCU:\Software\Classes\AppUserModelId\' + $appId
    if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
    New-ItemProperty -Path $regPath -Name 'DisplayName' -Value $displayName -PropertyType String -Force | Out-Null
    if ($iconPath -and (Test-Path -LiteralPath $iconPath)) {
      New-ItemProperty -Path $regPath -Name 'IconUri' -Value $iconPath -PropertyType String -Force | Out-Null
    }
    New-ItemProperty -Path $regPath -Name 'ShowInSettings' -Value 1 -PropertyType DWord -Force | Out-Null
  }
} catch { }

function Xml-Escape($s) {
  if ($null -eq $s) { return '' }
  return [System.Security.SecurityElement]::Escape([string]$s)
}

try {
  [void][Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
  [void][Windows.UI.Notifications.ToastNotification, Windows.UI.Notifications, ContentType = WindowsRuntime]
  [void][Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime]

  $scenarioUsed = 'default'
  $audioXml = ''

  # The approval flow owns its sound (lib/sound.ps1 plays it for a chosen number
  # of seconds and stops), so its toast is silent: otherwise the looping alarm
  # event would keep ringing after the configured duration. Task-complete toasts
  # stay on the system chime.
  $audioMode = [string]$p.audio
  if (-not $audioMode) {
    if ($sound) { $audioMode = 'alarmLoop' } else { $audioMode = 'silent' }
  }
  switch ($audioMode) {
    'default' { $audioXml = '<audio src="ms-winsoundevent:Notification.Default" />' }
    'chime' { $audioXml = '<audio src="ms-winsoundevent:Notification.IM" />' }
    'alarmLoop' { $audioXml = '<audio src="ms-winsoundevent:Notification.Looping.Alarm2" loop="true" />' }
    default { $audioXml = '<audio silent="true" />' }
  }

  $toastDuration = 'long'
  if ([string]$p.duration -eq 'short') { $toastDuration = 'short' }

  # A "short" duration is only a hint: alarm / urgent scenarios are allowed to
  # keep the banner up. Removing the toast from the history right after the
  # delay slams it shut, which is what a completion notice needs.
  $autoDismissMs = 0
  if ($p.autoDismissMs) { $autoDismissMs = [int]$p.autoDismissMs }

  # Urgent (Win11 22000+) breaks through Do-Not-Disturb AND fullscreen rules.
  # Alarm does the same on Windows 10 and stays until dismissed.
  $candidates = @()
  if ($scenario -eq 'urgent') { $candidates += 'urgent' }
  elseif ($scenario -eq 'alarm') { $candidates += 'alarm' }
  elseif ($scenario -eq 'default') { $candidates += 'default' }
  else { $candidates = @('urgent', 'alarm', 'default') }

  # Without an explicit image the banner shows the AUMID app icon, which for an
  # unpackaged app is Windows' generic placeholder. An absolute file URI keeps
  # the mark we want (green check = finished, whale = approval).
  $logoXml = ''
  if ($logoPath -and (Test-Path -LiteralPath $logoPath)) {
    try {
      $logoSrc = (New-Object System.Uri -ArgumentList (Resolve-Path -LiteralPath $logoPath).Path).AbsoluteUri
      $logoXml = '<image placement="appLogoOverride" hint-crop="none" src="' + (Xml-Escape $logoSrc) + '" />'
    } catch { $logoXml = '' }
  }

  # A toast cannot activate an unpackaged app (there is no COM activator to
  # launch), but Windows will happily ShellExecute a URI. lib/index.js registers
  # the `dshalerts:` scheme under HKCU\Software\Classes; declaring
  # activationType="protocol" is what makes a click go through it.
  $launchAttr = ''
  $launchUri = [string]$p.launch
  if ($launchUri) {
    $launchAttr = ' activationType="protocol" launch="' + (Xml-Escape $launchUri) + '"'
  }

  $notifier = $null
  $setting = ''
  if (-not $DryRun) {
    $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId)
    try { $setting = [string]$notifier.Setting } catch { }
  }

  $shown = $false
  $lastError = ''
  foreach ($cand in $candidates) {
    $scenAttr = ''
    if ($cand -ne 'default') { $scenAttr = ' scenario="' + $cand + '"' }
    $durAttr = ' duration="' + $toastDuration + '"'
    $xmlStr = '<toast' + $scenAttr + $durAttr + $launchAttr + '><visual><binding template="ToastGeneric">' +
      $logoXml + '<text>' +
      (Xml-Escape $title) + '</text><text>' + (Xml-Escape $body) + '</text></binding></visual>' +
      $audioXml + '</toast>'
    $doc = New-Object Windows.Data.Xml.Dom.XmlDocument
    try {
      $doc.LoadXml($xmlStr)
    } catch {
      $lastError = $_.Exception.Message
      continue
    }
    if ($DryRun) { Emit @{ ok = $true; action = 'dry-run'; scenario = $cand; xml = $xmlStr }; exit 0 }
    try {
      $toast = New-Object Windows.UI.Notifications.ToastNotification $doc
      try { $toast.Priority = [Windows.UI.Notifications.ToastNotificationPriority]::High } catch { }
      try {
        $tag = [string]$p.tag
        if ($tag) {
          $grp = [string]$p.group
          if (-not $grp) { $grp = 'dsh-approval' }
          $toast.Tag = $tag
          $toast.Group = $grp
        }
      } catch { }
      try { $toast.SuppressPopup = $false } catch { }
      $notifier.Show($toast)
      $shown = $true
      $scenarioUsed = $cand
      break
    } catch {
      $lastError = $_.Exception.Message
    }
  }

  if ($shown) {
    $dismissed = $false
    if ($autoDismissMs -gt 0 -and [string]$p.tag) {
      Start-Sleep -Milliseconds $autoDismissMs
      $tagRemove = [string]$p.tag
      $grpRemove = [string]$p.group
      if (-not $grpRemove) { $grpRemove = 'dsh-approval' }
      try {
        # The 3-argument overload (tag, group, appId) is the one that works for
        # an unpackaged app; the 2-argument form returns "Element not found".
        [Windows.UI.Notifications.ToastNotificationManager]::History.Remove($tagRemove, $grpRemove, $appId)
        $dismissed = $true
      } catch {
        try {
          [Windows.UI.Notifications.ToastNotificationManager]::History.Remove($tagRemove, $grpRemove)
          $dismissed = $true
        } catch { }
      }
    }
    Emit @{ ok = $true; action = 'shown'; scenario = $scenarioUsed; setting = $setting; dismissed = $dismissed; foreground = (Focused-ProcessName) }
    exit 0
  }
  Emit @{ ok = $false; action = 'failed'; scenario = $scenario; setting = $setting; error = $lastError }
  exit 1
} catch {
  Emit @{ ok = $false; action = 'failed'; error = $_.Exception.Message }
  exit 1
}
