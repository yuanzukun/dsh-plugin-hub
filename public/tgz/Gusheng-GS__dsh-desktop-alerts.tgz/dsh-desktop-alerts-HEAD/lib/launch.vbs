' dsh-desktop-alerts :: zero-flash launcher for the toast click handler
' ---------------------------------------------------------------------------
' Windows starts the `dshalerts:` protocol handler without a console window of
' its own; this launcher runs the PowerShell focus script fully hidden so a
' toast click never flashes a console.
'
' Args: 0 = focus.ps1 path, 1 = DeepSeek Harness.exe path, 2 = log file path
Option Explicit

Dim sh, scriptPath, appExe, logFile, cmd

If WScript.Arguments.Count < 1 Then WScript.Quit 1

scriptPath = WScript.Arguments(0)
appExe = ""
logFile = ""
If WScript.Arguments.Count > 1 Then appExe = WScript.Arguments(1)
If WScript.Arguments.Count > 2 Then logFile = WScript.Arguments(2)

cmd = "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File """ & scriptPath & """" & _
      " -App """ & appExe & """" & _
      " -Log """ & logFile & """"

Set sh = CreateObject("WScript.Shell")
sh.Run cmd, 0, False
