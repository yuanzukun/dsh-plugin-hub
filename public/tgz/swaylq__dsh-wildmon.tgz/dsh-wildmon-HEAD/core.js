/**
 * dsh-wildmon core — the whole safari as pure functions.
 *
 * No IO, no clock reads, no randomness of its own, no harness imports: every
 * function takes the state, a millisecond timestamp and (where chance is
 * involved) an injectable `rng` returning [0,1). This is the half the unit
 * tests pin down completely; the plugin half (index.js/store.js) only wires
 * harness events to `observe` and commands to the renderers.
 *
 * The loop is the collect-em-all classic: real work rustles the grass
 * (encounters), balls are thrown (catches), the dex fills up (collection),
 * six partners walk with you (team). Rarity rides on how the event happened —
 * errors wake the glitch ridge, small hours open the night pool, and one
 * legendary only answers a deep-night error.
 *
 * @module dsh-wildmon/core
 */

import { CATCHABLE_BEFORE_MYTH, RARITY, SPECIES, STARTERS, habitatSpecies } from './species.js'

/** Ball economy: the send-off gift, the pouch cap, the per-turn refill. */
export const BALL_START = 8
export const BALL_CAP = 30

/** How long a wild one waits in the grass before wandering off. */
export const ENCOUNTER_TTL_MS = 10 * 60_000

/** Chance a spawn is the sparkly recolor. */
export const SHINY_RATE = 1 / 64

/** Base spawn chance per observed event kind. */
export const SPAWN_BASE = {
  message: 0.05,
  turn: 0.09,
  toolBuild: 0.06,
  toolLore: 0.06,
  toolNeutral: 0.06,
  toolError: 0.16,
  agentError: 0.2,
}

/** Dry-spell mercy: each quiet event adds this much, up to the cap. */
export const PITY_STEP = 0.008
export const PITY_CAP = 0.25

/** Every miss on the same wild one makes the next throw stick better. */
export const THROW_BONUS = 0.12
export const CATCH_CEILING = 0.95

/** The lead partner's habitat spawns half again as often. */
export const LEAD_AURA = 1.5

/** Night pool window: 00:00–05:59 local; non-error events roll it this often. */
export const NIGHT_POOL_RATE = 0.7

/** Legendary tempers. */
export const KILOWHALE_EVERY = 250
export const NULLNIGHT_RATE = 0.12
export const OMNIKIRIN_RATE = 0.03

export const PARTY_SIZE = 6
const JOURNAL_CAP = 120

/** Mutating tools rustle the forge; observing tools rustle the archive. */
const BUILD_RE = /write|edit|patch|apply|create|make|mkdir|move|copy|rename|remove|delete|shell|bash|exec|spawn|run|terminal|command|kill|install|git|commit|deploy|code/i
const LORE_RE = /read|cat|open|grep|glob|search|find|list|fetch|web|browse|query|inspect|view|status|log|diff|doc|get|head|tail|show|think/i

/**
 * Map a tool name to the observe kind it produces.
 * @returns 'toolBuild' | 'toolLore' | 'toolNeutral'
 */
export function classify(toolName) {
  const name = String(toolName ?? '')
  if (BUILD_RE.test(name)) return 'toolBuild'
  if (LORE_RE.test(name)) return 'toolLore'
  return 'toolNeutral'
}

/** 00:00–05:59 in the machine's local time. */
export function isNight(now) {
  return new Date(now).getHours() < 6
}

/**
 * Begin the journey: pick a starter, get the pouch of balls.
 * @param starterId - one of {@link STARTERS}.
 * @param now - millisecond timestamp.
 * @returns a fresh state, or null when the id is not a starter.
 */
export function beginJourney(starterId, now) {
  if (!STARTERS.includes(starterId)) return null
  return {
    version: 1,
    createdAt: now,
    lastSeenAt: now,
    starter: starterId,
    balls: BALL_START,
    pity: 0,
    owed: null,
    encounter: null,
    party: [starterId],
    caught: [{ species: starterId, at: now, name: null, shiny: false }],
    seen: [starterId],
    counters: { turns: 0, toolCalls: 0, messages: 0, mishaps: 0, encounters: 0, throws: 0, catches: 0, fled: 0, dupes: 0 },
    journal: [{ at: now, kind: 'start', species: starterId }],
  }
}

function pushJournal(state, entry) {
  state.journal.push(entry)
  if (state.journal.length > JOURNAL_CAP) state.journal.splice(0, state.journal.length - JOURNAL_CAP)
}

/** Whether this species is already in the dex's caught column. */
export function caughtHas(state, speciesId) {
  return state.caught.some(c => c.species === speciesId)
}

function markSeen(state, speciesId) {
  if (!state.seen.includes(speciesId)) state.seen.push(speciesId)
}

/** Dex tallies: `{ caught, seen, total }` (seen includes caught). */
export function dexCounts(state) {
  return { caught: state.caught.length, seen: state.seen.length, total: Object.keys(SPECIES).length }
}

function allBeforeMythCaught(state) {
  return state.caught.filter(c => SPECIES[c.species].rarity !== 'legendary').length >= CATCHABLE_BEFORE_MYTH
}

/**
 * Clear an encounter whose patience ran out.
 * @returns the escaped species id, or null when nothing expired.
 */
export function settleEncounter(state, now) {
  const enc = state.encounter
  if (!enc || now < enc.expiresAt) return null
  state.encounter = null
  state.counters.fled += 1
  pushJournal(state, { at: now, kind: 'escaped', species: enc.species, seen: enc.seen, shiny: enc.shiny })
  return enc.species
}

/** The habitat a given event kind rustles (before the night override). */
function baseHabitat(kind) {
  if (kind === 'toolError' || kind === 'agentError') return 'glitch'
  if (kind === 'toolBuild') return 'forge'
  if (kind === 'toolLore') return 'archive'
  return 'field'
}

/**
 * The habitat the lead partner's aura blesses, or null with an empty party.
 * Starters bless their temperament's home (`aura`) since trio never spawns.
 */
export function leadHabitat(state) {
  const lead = state.party[0]
  if (!lead) return null
  return SPECIES[lead].aura ?? SPECIES[lead].habitat
}

/**
 * Weighted pick from a habitat pool. The field pool also hides the two
 * starters not chosen, at a sliver of a rare's weight.
 */
function pickSpecies(state, pool, rng) {
  const entries = habitatSpecies(pool).map(id => [id, RARITY[SPECIES[id].rarity].weight])
  if (pool === 'field') {
    for (const s of STARTERS) {
      if (s !== state.starter) entries.push([s, 0.5])
    }
  }
  const total = entries.reduce((sum, [, w]) => sum + w, 0)
  let roll = rng() * total
  for (const [id, w] of entries) {
    roll -= w
    if (roll < 0) return id
  }
  return entries[entries.length - 1][0]
}

function spawn(state, speciesId, now, source, rng) {
  state.encounter = {
    species: speciesId,
    at: now,
    expiresAt: now + ENCOUNTER_TTL_MS,
    throws: 0,
    seen: false,
    shiny: rng() < SHINY_RATE,
    source,
  }
  state.counters.encounters += 1
  state.pity = 0
  return speciesId
}

/**
 * Digest one observed harness event: tally it, refill balls on turns, and
 * maybe rustle the grass. rng call order (for seeded tests): night-pool roll
 * (non-error daylight events skip it), legendary rolls where armed, spawn
 * roll, species pick, shiny roll.
 *
 * @param state - the journey (must exist; store gates on that).
 * @param kind - a key of {@link SPAWN_BASE}.
 * @param now - millisecond timestamp.
 * @param rng - () => [0,1).
 * @returns `{ spawned }` — the species that appeared, or null.
 */
export function observe(state, kind, now, rng) {
  if (!(kind in SPAWN_BASE)) return { spawned: null }
  settleEncounter(state, now)

  const c = state.counters
  if (kind === 'message') c.messages += 1
  else if (kind === 'turn') c.turns += 1
  else if (kind === 'toolError' || kind === 'agentError') c.mishaps += 1
  else c.toolCalls += 1
  if (kind === 'turn') state.balls = Math.min(BALL_CAP, state.balls + 1)
  state.lastSeenAt = now

  // The 250-turn tide is owed even if the whale must wait out a live encounter.
  if (kind === 'turn' && c.turns % KILOWHALE_EVERY === 0 && !caughtHas(state, 'kilowhale')) {
    state.owed = 'kilowhale'
  }

  if (state.encounter) return { spawned: null }

  if (state.owed) {
    const owed = state.owed
    state.owed = null
    if (!caughtHas(state, owed)) return { spawned: spawn(state, owed, now, kind, rng) }
  }

  const isError = kind === 'toolError' || kind === 'agentError'
  const night = isNight(now)
  if (isError && night && !caughtHas(state, 'nullnight') && rng() < NULLNIGHT_RATE) {
    return { spawned: spawn(state, 'nullnight', now, kind, rng) }
  }
  if (allBeforeMythCaught(state) && !caughtHas(state, 'omnikirin') && rng() < OMNIKIRIN_RATE) {
    return { spawned: spawn(state, 'omnikirin', now, kind, rng) }
  }

  const pool = !isError && night && rng() < NIGHT_POOL_RATE ? 'night' : baseHabitat(kind)
  let chance = SPAWN_BASE[kind] + Math.min(PITY_CAP, state.pity * PITY_STEP)
  if (leadHabitat(state) === pool) chance *= LEAD_AURA
  if (rng() >= chance) {
    state.pity += 1
    return { spawned: null }
  }
  return { spawned: spawn(state, pickSpecies(state, pool, rng), now, kind, rng) }
}

/**
 * Actually look at the grass: marks the wild one (and its dex row) as seen.
 * @returns the live encounter, or null.
 */
export function look(state, now) {
  settleEncounter(state, now)
  const enc = state.encounter
  if (!enc) return null
  enc.seen = true
  markSeen(state, enc.species)
  return enc
}

/**
 * Throw one ball at the live encounter. rng call order: catch roll, then on
 * a miss the flee roll, then the cosmetic shake roll.
 *
 * @returns a result card: `{ outcome, species?, shiny?, shakes?, ballsLeft,
 *   partyJoined?, dex? }` with outcome one of 'none' | 'noball' | 'caught' |
 *   'dupe' | 'miss' | 'fled'.
 */
export function throwBall(state, now, rng) {
  settleEncounter(state, now)
  const enc = state.encounter
  if (!enc) return { outcome: 'none', ballsLeft: state.balls }
  if (state.balls <= 0) return { outcome: 'noball', species: enc.species, shiny: enc.shiny, ballsLeft: 0 }

  enc.seen = true
  markSeen(state, enc.species)
  state.balls -= 1
  state.counters.throws += 1

  const spec = SPECIES[enc.species]
  const chance = Math.min(CATCH_CEILING, RARITY[spec.rarity].catch + THROW_BONUS * enc.throws)
  if (rng() < chance) {
    state.encounter = null
    if (caughtHas(state, enc.species)) {
      state.balls = Math.min(BALL_CAP, state.balls + 2)
      state.counters.dupes += 1
      pushJournal(state, { at: now, kind: 'dupe', species: enc.species, shiny: enc.shiny })
      return { outcome: 'dupe', species: enc.species, shiny: enc.shiny, shakes: 3, ballsLeft: state.balls }
    }
    state.caught.push({ species: enc.species, at: now, name: null, shiny: enc.shiny })
    const partyJoined = state.party.length < PARTY_SIZE
    if (partyJoined) state.party.push(enc.species)
    state.counters.catches += 1
    pushJournal(state, { at: now, kind: 'catch', species: enc.species, shiny: enc.shiny })
    return { outcome: 'caught', species: enc.species, shiny: enc.shiny, shakes: 3, ballsLeft: state.balls, partyJoined, dex: dexCounts(state) }
  }

  enc.throws += 1
  const fled = rng() < RARITY[spec.rarity].flee
  const shakes = 1 + (rng() < 0.5 ? 1 : 0)
  if (fled) {
    state.encounter = null
    state.counters.fled += 1
    pushJournal(state, { at: now, kind: 'fled', species: enc.species, shiny: enc.shiny })
    return { outcome: 'fled', species: enc.species, shiny: enc.shiny, shakes, ballsLeft: state.balls }
  }
  return { outcome: 'miss', species: enc.species, shiny: enc.shiny, shakes, ballsLeft: state.balls, throws: enc.throws }
}

/**
 * Walk away from the live encounter (no fled tally — it was your call).
 * @returns the species you left behind, or null.
 */
export function walkAway(state, now) {
  settleEncounter(state, now)
  const enc = state.encounter
  if (!enc) return null
  state.encounter = null
  pushJournal(state, { at: now, kind: 'walked', species: enc.species })
  return enc.species
}

/**
 * The unified roster the team commands number from: party first (in party
 * order), then the box (in catch order).
 * @returns `[{ species, at, name, shiny, inParty }]`
 */
export function roster(state) {
  const byId = new Map(state.caught.map(c => [c.species, c]))
  const rows = state.party.map(id => ({ ...byId.get(id), inParty: true }))
  for (const c of state.caught) {
    if (!state.party.includes(c.species)) rows.push({ ...c, inParty: false })
  }
  return rows
}

/**
 * Swap two roster slots (1-based, as `/mon team` prints them): party↔party
 * reorders, party↔box exchanges.
 * @returns null on success, or a human-readable refusal.
 */
export function swapSlots(state, a, b) {
  const rows = roster(state)
  const i = a - 1
  const j = b - 1
  if (!Number.isInteger(a) || !Number.isInteger(b) || i < 0 || j < 0 || i >= rows.length || j >= rows.length) {
    return `编号要在 1–${rows.length} 之间（看 /mon team 的编号）`
  }
  if (i === j) return '同一个编号，不用换'
  const partyLen = state.party.length
  if (i < partyLen && j < partyLen) {
    ;[state.party[i], state.party[j]] = [state.party[j], state.party[i]]
    return null
  }
  if (i >= partyLen && j >= partyLen) return '两只都在盒子里，换了也还在盒子里'
  const partyIdx = Math.min(i, j)
  const boxRow = rows[Math.max(i, j)]
  state.party[partyIdx] = boxRow.species
  return null
}

/**
 * Nickname a caught partner by roster number (1-based).
 * @returns `{ species, name }`, or null when the number or name is unusable.
 */
export function rename(state, slot, rawName, now) {
  const rows = roster(state)
  const row = rows[slot - 1]
  if (!Number.isInteger(slot) || !row) return null
  const cleaned = String(rawName ?? '').replace(/\s+/g, ' ').trim().slice(0, 16)
  if (cleaned === '') return null
  const entry = state.caught.find(c => c.species === row.species)
  entry.name = cleaned
  pushJournal(state, { at: now, kind: 'rename', species: row.species, to: cleaned })
  return { species: row.species, name: cleaned }
}

/**
 * Upgrade a parsed save file to the current version.
 * @returns a v1 state, or null when the file is foreign or unreadable.
 */
export function migrate(parsed) {
  if (!parsed || typeof parsed !== 'object') return null
  if (parsed.version === 1) return parsed
  return null
}
