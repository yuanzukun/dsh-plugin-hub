import assert from 'node:assert/strict'
import { test } from 'node:test'

import {
  BALL_CAP,
  BALL_START,
  ENCOUNTER_TTL_MS,
  beginJourney,
  caughtHas,
  classify,
  dexCounts,
  isNight,
  look,
  migrate,
  observe,
  rename,
  roster,
  settleEncounter,
  swapSlots,
  throwBall,
  walkAway,
} from '../core.js'
import { DEX_ORDER, SPECIES } from '../species.js'

/** An rng that replays a fixed sequence, then repeats its last value. */
function seqFix(...vals) {
  let i = 0
  return () => {
    const v = vals[Math.min(i, vals.length - 1)]
    i += 1
    return v
  }
}

const DAY = new Date(2026, 7, 15, 14, 0, 0).getTime()
const NIGHT = new Date(2026, 7, 15, 3, 0, 0).getTime()

const fresh = () => beginJourney('mossling', DAY)

function forceEncounter(state, species, now, extra = {}) {
  state.encounter = { species, at: now, expiresAt: now + ENCOUNTER_TTL_MS, throws: 0, seen: false, shiny: false, source: 'test', ...extra }
}

test('seqFix replays then repeats', () => {
  const r = seqFix(0.1, 0.2)
  assert.equal(r(), 0.1)
  assert.equal(r(), 0.2)
  assert.equal(r(), 0.2)
})

test('classify sorts tools into forge, archive, neutral', () => {
  assert.equal(classify('write_file'), 'toolBuild')
  assert.equal(classify('shell'), 'toolBuild')
  assert.equal(classify('web_search'), 'toolLore')
  assert.equal(classify('grep'), 'toolLore')
  assert.equal(classify('quux'), 'toolNeutral')
  assert.equal(classify(undefined), 'toolNeutral')
})

test('isNight is the 00:00–05:59 local window', () => {
  assert.equal(isNight(NIGHT), true)
  assert.equal(isNight(DAY), false)
  assert.equal(isNight(new Date(2026, 7, 15, 5, 59).getTime()), true)
  assert.equal(isNight(new Date(2026, 7, 15, 6, 0).getTime()), false)
})

test('beginJourney: the starter is partner, dex row and seen row in one', () => {
  const s = fresh()
  assert.equal(s.version, 1)
  assert.equal(s.starter, 'mossling')
  assert.equal(s.balls, BALL_START)
  assert.deepEqual(s.party, ['mossling'])
  assert.equal(s.caught.length, 1)
  assert.deepEqual(s.seen, ['mossling'])
  assert.equal(s.journal[0].kind, 'start')
  assert.deepEqual(dexCounts(s), { caught: 1, seen: 1, total: 28 })
  assert.equal(beginJourney('volttuft', DAY), null, 'only the trio can start a journey')
})

test('quiet events tally counters, grow pity, refill balls on turns', () => {
  const s = fresh()
  const never = () => 1
  observe(s, 'message', DAY, never)
  observe(s, 'toolLore', DAY, never)
  observe(s, 'toolError', DAY, never)
  observe(s, 'turn', DAY, never)
  assert.deepEqual(
    [s.counters.messages, s.counters.toolCalls, s.counters.mishaps, s.counters.turns],
    [1, 1, 1, 1],
  )
  assert.equal(s.pity, 4)
  assert.equal(s.balls, BALL_START + 1)
  assert.equal(s.encounter, null)

  s.balls = BALL_CAP
  observe(s, 'turn', DAY, never)
  assert.equal(s.balls, BALL_CAP, 'the pouch has a cap')

  observe(s, 'notAnEvent', DAY, never)
  assert.equal(s.counters.turns, 2, 'unknown kinds are ignored')
})

test('a lucky roll spawns a field encounter and resets pity', () => {
  const s = fresh()
  s.pity = 7
  const { spawned } = observe(s, 'message', DAY, seqFix(0, 0.5, 0.9))
  assert.ok(spawned, 'spawned a species')
  assert.ok(['field', 'trio'].includes(SPECIES[spawned].habitat), 'messages rustle the field (or a stray starter)')
  assert.equal(s.encounter.species, spawned)
  assert.equal(s.encounter.expiresAt, DAY + ENCOUNTER_TTL_MS)
  assert.equal(s.encounter.shiny, false)
  assert.equal(s.pity, 0)
  assert.equal(s.counters.encounters, 1)
})

test('pity turns a near-miss roll into a spawn', () => {
  const dry = fresh()
  assert.equal(observe(dry, 'message', DAY, seqFix(0.1)).spawned, null, '0.1 misses the 5% base')
  const pitied = fresh()
  pitied.pity = 10
  assert.ok(observe(pitied, 'message', DAY, seqFix(0.1, 0.5, 0.9)).spawned, '10 quiet events add 8%')
})

test('the lead partner’s aura raises its blessed habitat’s spawn rate', () => {
  const archival = beginJourney('puddlenip', DAY)
  assert.equal(observe(archival, 'message', DAY, seqFix(0.06)).spawned, null, 'a water lead does not bless the field')
  const grassy = fresh()
  assert.ok(observe(grassy, 'message', DAY, seqFix(0.06, 0.5, 0.9)).spawned, 'mossling blesses the field: 5% × 1.5 covers 0.06')
  const led = beginJourney('puddlenip', DAY)
  led.party = ['fluffgrub']
  assert.ok(observe(led, 'message', DAY, seqFix(0.06, 0.5, 0.9)).spawned, 'a caught field lead blesses it too')
})

test('night rolls the night pool for non-error events', () => {
  const s = fresh()
  const { spawned } = observe(s, 'message', NIGHT, seqFix(0.5, 0, 0.5, 0.9))
  assert.equal(SPECIES[spawned].habitat, 'night')
  const s2 = fresh()
  const roll2 = observe(s2, 'message', NIGHT, seqFix(0.9, 0, 0.5, 0.9))
  assert.ok(['field', 'trio'].includes(SPECIES[roll2.spawned].habitat), 'the 30% miss keeps the day pool')
})

test('errors rustle the glitch ridge, day or night', () => {
  const s = fresh()
  const { spawned } = observe(s, 'toolError', DAY, seqFix(0, 0.5, 0.9))
  assert.equal(SPECIES[spawned].habitat, 'glitch')
  const s2 = fresh()
  const night = observe(s2, 'agentError', NIGHT, seqFix(0.5, 0, 0.5, 0.9))
  assert.equal(SPECIES[night.spawned].habitat, 'glitch', 'a failed nullnight roll still wakes the glitch pool')
})

test('a deep-night error can summon Nullnight', () => {
  const s = fresh()
  const { spawned } = observe(s, 'agentError', NIGHT, seqFix(0.05, 0.9))
  assert.equal(spawned, 'nullnight')
  const day = fresh()
  assert.notEqual(observe(day, 'agentError', DAY, seqFix(0.05, 0.5, 0.9)).spawned, 'nullnight', 'daylight errors never do')
})

test('the 250-turn tide owes a Kilowhale, even across a live encounter', () => {
  const s = fresh()
  s.counters.turns = 249
  assert.equal(observe(s, 'turn', DAY, seqFix(0.9)).spawned, 'kilowhale', 'the milestone spawns it on the spot')

  const busy = fresh()
  busy.counters.turns = 249
  forceEncounter(busy, 'fluffgrub', DAY)
  assert.equal(observe(busy, 'turn', DAY, seqFix(0.9)).spawned, null, 'the encounter is not replaced')
  assert.equal(busy.owed, 'kilowhale')
  walkAway(busy, DAY)
  assert.equal(observe(busy, 'message', DAY, seqFix(0.9)).spawned, 'kilowhale', 'the debt is paid at the next opening')

  const done = fresh()
  done.caught.push({ species: 'kilowhale', at: DAY, name: null, shiny: false })
  done.counters.turns = 249
  assert.equal(observe(done, 'turn', DAY, seqFix(1)).spawned, null, 'a caught whale stops surfacing')
  assert.equal(done.owed, null)
})

test('Omnikirin only visits a completed pre-myth dex', () => {
  const s = fresh()
  for (const id of DEX_ORDER) {
    if (SPECIES[id].rarity !== 'legendary' && !caughtHas(s, id)) {
      s.caught.push({ species: id, at: DAY, name: null, shiny: false })
    }
  }
  assert.equal(observe(s, 'message', DAY, seqFix(0.01, 0.9)).spawned, 'omnikirin')
  const partial = fresh()
  assert.notEqual(observe(partial, 'message', DAY, seqFix(0.01, 0.5, 0.9)).spawned, 'omnikirin')
})

test('an ignored encounter wanders off and the journal remembers', () => {
  const s = fresh()
  forceEncounter(s, 'dotfinch', DAY)
  assert.equal(settleEncounter(s, DAY + ENCOUNTER_TTL_MS - 1), null, 'still waiting')
  assert.equal(settleEncounter(s, DAY + ENCOUNTER_TTL_MS), 'dotfinch')
  assert.equal(s.encounter, null)
  assert.equal(s.counters.fled, 1)
  const last = s.journal.at(-1)
  assert.deepEqual([last.kind, last.species, last.seen], ['escaped', 'dotfinch', false])
  assert.equal(look(s, DAY + ENCOUNTER_TTL_MS + 1), null)
})

test('look marks the wild one (and its dex row) as seen', () => {
  const s = fresh()
  forceEncounter(s, 'volttuft', DAY)
  const enc = look(s, DAY + 1)
  assert.equal(enc.seen, true)
  assert.ok(s.seen.includes('volttuft'))
  assert.equal(dexCounts(s).seen, 2)
})

test('throwBall: empty grass and empty pouch both refuse gently', () => {
  const s = fresh()
  assert.equal(throwBall(s, DAY, seqFix(0)).outcome, 'none')
  forceEncounter(s, 'fluffgrub', DAY)
  s.balls = 0
  const result = throwBall(s, DAY, seqFix(0))
  assert.equal(result.outcome, 'noball')
  assert.ok(s.encounter, 'it is still there, judging you')
})

test('a catch joins the party, fills the dex, spends the ball', () => {
  const s = fresh()
  forceEncounter(s, 'fluffgrub', DAY)
  const result = throwBall(s, DAY, seqFix(0.5))
  assert.equal(result.outcome, 'caught')
  assert.equal(result.partyJoined, true)
  assert.equal(result.shakes, 3)
  assert.deepEqual(result.dex, { caught: 2, seen: 2, total: 28 })
  assert.equal(s.balls, BALL_START - 1)
  assert.deepEqual(s.party, ['mossling', 'fluffgrub'])
  assert.equal(s.encounter, null)
  assert.equal(s.counters.catches, 1)
  assert.equal(s.journal.at(-1).kind, 'catch')
})

test('a duplicate catch trades itself back for two balls', () => {
  const s = fresh()
  forceEncounter(s, 'mossling', DAY)
  const result = throwBall(s, DAY, seqFix(0.01))
  assert.equal(result.outcome, 'dupe')
  assert.equal(s.balls, BALL_START - 1 + 2)
  assert.equal(s.caught.length, 1)
  assert.equal(s.counters.dupes, 1)

  s.balls = BALL_CAP
  forceEncounter(s, 'mossling', DAY)
  throwBall(s, DAY, seqFix(0.01))
  assert.equal(s.balls, BALL_CAP, 'dupe refunds respect the cap')
})

test('misses raise the next throw’s odds; rares can bolt', () => {
  const s = fresh()
  forceEncounter(s, 'miststag', DAY)
  const miss = throwBall(s, DAY, seqFix(0.5, 0.9, 0.3))
  assert.equal(miss.outcome, 'miss', '0.5 misses a rare’s 28%')
  assert.equal(miss.shakes, 2)
  assert.equal(s.encounter.throws, 1)

  s.encounter.throws = 2
  const caught = throwBall(s, DAY, seqFix(0.5))
  assert.equal(caught.outcome, 'caught', 'two misses add 24 points: 52% now covers 0.5')

  const bolt = fresh()
  forceEncounter(bolt, 'miststag', DAY)
  const fled = throwBall(bolt, DAY, seqFix(0.9, 0.1, 0.6))
  assert.equal(fled.outcome, 'fled')
  assert.equal(fled.shakes, 1)
  assert.equal(bolt.encounter, null)
  assert.equal(bolt.counters.fled, 1)
  assert.ok(bolt.seen.includes('miststag'), 'you saw it get away')
})

test('a full party sends new catches to the box', () => {
  const s = fresh()
  s.party = ['mossling', 'fluffgrub', 'dotfinch', 'volttuft', 'chimehop', 'miststag']
  forceEncounter(s, 'inkblot', DAY)
  const result = throwBall(s, DAY, seqFix(0.1))
  assert.equal(result.outcome, 'caught')
  assert.equal(result.partyJoined, false)
  assert.equal(s.party.length, 6)
})

test('walking away is not fleeing', () => {
  const s = fresh()
  forceEncounter(s, 'dotfinch', DAY)
  assert.equal(walkAway(s, DAY), 'dotfinch')
  assert.equal(s.encounter, null)
  assert.equal(s.counters.fled, 0)
  assert.equal(s.journal.at(-1).kind, 'walked')
  assert.equal(walkAway(s, DAY), null)
})

function partyOfFive() {
  const s = fresh()
  for (const id of ['fluffgrub', 'dotfinch', 'volttuft', 'chimehop']) {
    s.caught.push({ species: id, at: DAY, name: null, shiny: false })
  }
  s.party = ['mossling', 'fluffgrub', 'dotfinch']
  return s
}

test('roster lists party first, then the box in catch order', () => {
  const s = partyOfFive()
  assert.deepEqual(roster(s).map(r => [r.species, r.inParty]), [
    ['mossling', true], ['fluffgrub', true], ['dotfinch', true],
    ['volttuft', false], ['chimehop', false],
  ])
})

test('swapSlots reorders the party and trades with the box', () => {
  const s = partyOfFive()
  assert.equal(swapSlots(s, 1, 2), null)
  assert.deepEqual(s.party, ['fluffgrub', 'mossling', 'dotfinch'])
  assert.equal(swapSlots(s, 3, 4), null, 'party slot 3 takes box slot 4')
  assert.deepEqual(s.party, ['fluffgrub', 'mossling', 'volttuft'])
  assert.ok(roster(s).some(r => r.species === 'dotfinch' && !r.inParty), 'the ousted one waits in the box')
  assert.match(swapSlots(s, 4, 5), /盒子/)
  assert.match(swapSlots(s, 1, 1), /同一个/)
  assert.match(swapSlots(s, 0, 2), /编号/)
  assert.match(swapSlots(s, 1, 99), /编号/)
  assert.match(swapSlots(s, NaN, 2), /编号/)
})

test('rename nicknames by roster number and trims to 16', () => {
  const s = partyOfFive()
  const renamed = rename(s, 4, '  电  电  ', DAY)
  assert.deepEqual(renamed, { species: 'volttuft', name: '电 电' })
  assert.equal(s.caught.find(c => c.species === 'volttuft').name, '电 电')
  assert.equal(s.journal.at(-1).kind, 'rename')
  assert.equal(rename(s, 99, 'x', DAY), null)
  assert.equal(rename(s, 1, '   ', DAY), null)
  assert.equal(rename(s, 1, 'x'.repeat(40), DAY).name.length, 16)
})

test('migrate accepts v1 and rejects foreign files', () => {
  const s = fresh()
  assert.equal(migrate(s), s)
  assert.equal(migrate({ version: 99 }), null)
  assert.equal(migrate('junk'), null)
  assert.equal(migrate(null), null)
})
