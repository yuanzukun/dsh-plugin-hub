import assert from 'node:assert/strict'
import { test } from 'node:test'

import { CATCHABLE_BEFORE_MYTH, DEX_ORDER, HABITATS, RARITY, SPECIES, STARTERS, habitatSpecies } from '../species.js'

test('the roster is 28 strong and DEX_ORDER covers it exactly', () => {
  assert.equal(Object.keys(SPECIES).length, 28)
  assert.deepEqual(DEX_ORDER, Object.keys(SPECIES))
})

test('every species is fully described and points at real metadata', () => {
  for (const [id, s] of Object.entries(SPECIES)) {
    assert.match(id, /^[a-z]+$/, `${id} id shape`)
    assert.ok(s.zh.length >= 2, `${id} zh`)
    assert.match(s.en, /^[A-Z][A-Za-z]+$/, `${id} en`)
    assert.ok(HABITATS[s.habitat], `${id} habitat ${s.habitat}`)
    assert.ok(RARITY[s.rarity], `${id} rarity ${s.rarity}`)
    assert.ok(s.flavor.length >= 6, `${id} flavor`)
    assert.ok(Array.isArray(s.art) && s.art.length >= 2 && s.art.length <= 5, `${id} art rows`)
    for (const line of s.art) {
      assert.ok([...line].length <= 20, `${id} art line too wide: ${line}`)
    }
  }
})

test('names are unique in both languages', () => {
  const zh = Object.values(SPECIES).map(s => s.zh)
  const en = Object.values(SPECIES).map(s => s.en.toLowerCase())
  assert.equal(new Set(zh).size, zh.length)
  assert.equal(new Set(en).size, en.length)
})

test('the starter trio is the whole trio habitat, all rare', () => {
  assert.equal(STARTERS.length, 3)
  assert.deepEqual(STARTERS, habitatSpecies('trio'))
  for (const id of STARTERS) assert.equal(SPECIES[id].rarity, 'rare')
})

test('habitat pools have the intended shapes', () => {
  assert.equal(habitatSpecies('field').length, 5)
  assert.equal(habitatSpecies('forge').length, 5)
  assert.equal(habitatSpecies('archive').length, 5)
  assert.equal(habitatSpecies('glitch').length, 4)
  assert.equal(habitatSpecies('night').length, 3)
  assert.equal(habitatSpecies('myth').length, 3)
})

test('legendaries are exactly the myth habitat and each keeps a rumor', () => {
  for (const id of Object.keys(SPECIES)) {
    const s = SPECIES[id]
    assert.equal(s.rarity === 'legendary', s.habitat === 'myth', id)
    if (s.rarity === 'legendary') assert.match(s.hint, /^谣传/, id)
  }
  assert.equal(CATCHABLE_BEFORE_MYTH, 25)
})

test('rarity weights order and catch odds are monotone', () => {
  assert.ok(RARITY.common.weight > RARITY.uncommon.weight)
  assert.ok(RARITY.uncommon.weight > RARITY.rare.weight)
  assert.equal(RARITY.legendary.weight, 0, 'legendaries never enter the weighted pools')
  assert.ok(RARITY.common.catch > RARITY.uncommon.catch)
  assert.ok(RARITY.uncommon.catch > RARITY.rare.catch)
  assert.ok(RARITY.rare.catch > RARITY.legendary.catch)
  assert.ok(RARITY.common.flee < RARITY.legendary.flee)
})
