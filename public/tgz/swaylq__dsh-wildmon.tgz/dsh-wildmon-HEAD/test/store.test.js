import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'

import { createStore, defaultStatePath, dshHome } from '../store.js'

const DAY = new Date(2026, 7, 15, 14, 0, 0).getTime()
const seqFix = (...vals) => { let i = 0; return () => { const v = vals[Math.min(i, vals.length - 1)]; i += 1; return v } }

function tempPath(t) {
  const dir = mkdtempSync(join(tmpdir(), 'wildmon-store-'))
  t.after(() => rmSync(dir, { recursive: true, force: true }))
  return join(dir, 'state.json')
}

/** A store with a manual clock, scripted dice, and captured timers. */
function mount(t, { rng = () => 1, path } = {}) {
  const statePath = path ?? tempPath(t)
  let nowMs = DAY
  const timers = []
  const store = createStore(statePath, {
    now: () => nowMs,
    rng,
    setTimer: (fn, ms) => { timers.push({ fn, ms }); return timers.length },
    clearTimer: (id) => { timers[id - 1].cleared = true },
  })
  return { store, statePath, timers, tick: () => timers.at(-1).fn(), setNow: v => { nowMs = v } }
}

test('the save path follows DSH_HOME', (t) => {
  const prev = process.env.DSH_HOME
  t.after(() => { if (prev === undefined) delete process.env.DSH_HOME; else process.env.DSH_HOME = prev })
  process.env.DSH_HOME = '/tmp/fake-dsh-home'
  assert.equal(dshHome(), '/tmp/fake-dsh-home')
  assert.equal(defaultStatePath(), '/tmp/fake-dsh-home/wildmon/state.json')
})

test('before the journey starts every verb is a safe no-op', (t) => {
  const { store, statePath } = mount(t)
  store.observe('turn')
  assert.equal(store.look(), null)
  assert.equal(store.throwBall().outcome, 'none')
  assert.equal(store.walkAway(), null)
  assert.match(store.swap(1, 2), /旅程/)
  assert.equal(store.rename(1, 'x'), null)
  store.dispose()
  assert.equal(existsSync(statePath), false, 'nothing to save yet')
  assert.equal(store.state, null)
})

test('start → observe → dispose persists, and a new store reloads it', (t) => {
  const { store, statePath } = mount(t, { rng: () => 1 })
  assert.equal(store.start('volttuft'), false, 'only starters begin journeys')
  assert.equal(store.start('cinderpuff'), true)
  assert.equal(store.start('mossling'), false, 'one journey per home')
  store.observe('turn')
  store.dispose()
  assert.equal(existsSync(statePath), true)

  const again = createStore(statePath, { now: () => DAY + 1 })
  assert.equal(again.state.starter, 'cinderpuff')
  assert.equal(again.state.balls, 9)
  assert.equal(again.state.counters.turns, 1)
})

test('writes are atomic-style and throttled to one timer', (t) => {
  const { store, timers, tick, statePath } = mount(t)
  store.start('mossling')
  store.observe('message')
  store.observe('message')
  store.observe('turn')
  assert.equal(timers.length, 1, 'many observations, one pending save')
  tick()
  assert.equal(existsSync(statePath), true)
  const onDisk = JSON.parse(readFileSync(statePath, 'utf8'))
  assert.equal(onDisk.counters.messages, 2)
  assert.equal(existsSync(`${statePath}.tmp`), false, 'the temp file was renamed away')

  store.observe('message')
  assert.equal(timers.length, 2, 'a fresh dirty state arms a fresh timer')
  store.dispose()
  assert.equal(timers[1].cleared, true)
  assert.equal(JSON.parse(readFileSync(statePath, 'utf8')).counters.messages, 3, 'dispose flushes')
})

test('corrupt or foreign save files fall back to a fresh journey', (t) => {
  const p1 = tempPath(t)
  writeFileSync(p1, 'not json at all {')
  assert.equal(createStore(p1, { now: () => DAY }).state, null)

  const p2 = tempPath(t)
  writeFileSync(p2, JSON.stringify({ version: 99, starter: 'alien' }))
  assert.equal(createStore(p2, { now: () => DAY }).state, null)
})

test('the injected dice drive spawns end to end', (t) => {
  const { store } = mount(t, { rng: seqFix(0, 0.5, 0.9, 1) })
  store.start('mossling')
  store.observe('message')
  const enc = store.look()
  assert.ok(enc, 'the scripted 0 roll spawned something')
  assert.equal(enc.seen, true)
  assert.equal(store.state.counters.encounters, 1)
})

test('store.now exposes the injected clock', (t) => {
  const { store, setNow } = mount(t)
  assert.equal(store.now(), DAY)
  setNow(DAY + 5)
  assert.equal(store.now(), DAY + 5)
})

test('throw, walk, swap and rename write through the store', (t) => {
  const { store } = mount(t, { rng: seqFix(0, 0.5, 0.9, 0.01, 1) })
  store.start('mossling')
  store.observe('message')                       // consumes 0, 0.5, 0.9 → a wild field critter
  const result = store.throwBall()               // consumes 0.01 → caught
  assert.equal(result.outcome, 'caught')
  assert.equal(store.state.party.length, 2)
  assert.equal(store.swap(1, 2), null)
  const renamed = store.rename(1, '球球')
  assert.equal(renamed.name, '球球')
  assert.equal(store.walkAway(), null, 'no standoff after the catch')
  store.dispose()
})
