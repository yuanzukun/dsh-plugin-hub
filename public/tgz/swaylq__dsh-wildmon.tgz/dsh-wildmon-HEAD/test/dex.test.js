import assert from 'node:assert/strict'
import { test } from 'node:test'

import { ENCOUNTER_TTL_MS, beginJourney, look, throwBall } from '../core.js'
import {
  rarityTag,
  renderAbout,
  renderDex,
  renderEncounter,
  renderJourneyStart,
  renderQuiet,
  renderStarterOffer,
  renderStory,
  renderTeam,
  renderThrow,
  renderWalk,
  speciesName,
  title,
} from '../dex.js'

const DAY = new Date(2026, 7, 15, 14, 0, 0).getTime()
const fresh = () => beginJourney('mossling', DAY)
const seqFix = (...vals) => { let i = 0; return () => { const v = vals[Math.min(i, vals.length - 1)]; i += 1; return v } }

function withEncounter(species, extra = {}) {
  const s = fresh()
  s.encounter = { species, at: DAY, expiresAt: DAY + ENCOUNTER_TTL_MS, throws: 0, seen: false, shiny: false, source: 'test', ...extra }
  look(s, DAY)
  return s
}

test('naming helpers', () => {
  assert.equal(speciesName('volttuft'), '绒电鼠 Volttuft')
  assert.equal(rarityTag('volttuft'), '◈ 少见')
  assert.equal(title({ species: 'volttuft', name: null }), '绒电鼠 Volttuft')
  assert.equal(title({ species: 'volttuft', name: '电电' }), '电电（绒电鼠）')
})

test('the starter offer shows all three with art and the start hint', () => {
  const text = renderStarterOffer('mon')
  for (const zh of ['苔尾崽', '烬绒崽', '澪滴崽']) assert.match(text, new RegExp(zh))
  assert.match(text, /\/mon start <1\|2\|3/)
})

test('the send-off card names the starter and counts the balls', () => {
  const text = renderJourneyStart(fresh(), 'mon')
  assert.match(text, /你选择了 苔尾崽/)
  assert.match(text, /8 颗捕灵球/)
})

test('the encounter card leads with the punchline and knows the dex', () => {
  const s = withEncounter('volttuft')
  const text = renderEncounter(s, DAY + 60_000, 'mon')
  assert.match(text.split('\n')[0], /^野生的 绒电鼠 Volttuft 出现了！◈ 少见 · 常野原$/)
  assert.match(text, /图鉴里还没有它的记录/)
  assert.match(text, /停留 9 分钟/)
  assert.match(text, /球 ×8 —— \/mon throw/)
  assert.doesNotMatch(text, /异色/)

  const shiny = withEncounter('volttuft', { shiny: true, throws: 2 })
  const text2 = renderEncounter(shiny, DAY, 'mon')
  assert.match(text2, /✨ 是异色个体！/)
  assert.match(text2, /已投 2 球/)

  const dupe = withEncounter('mossling')
  assert.match(renderEncounter(dupe, DAY, 'mon'), /图鉴里已有 —— 抓到会换回 2 颗球/)
})

test('the quiet card shows pouch, dex, aura and the latest stir', () => {
  const s = fresh()
  const text = renderQuiet(s, 'mon')
  assert.match(text.split('\n')[0], /^草丛静悄悄。球 ×8 · 图鉴 1\/28$/)
  assert.match(text, /带头 苔尾崽 Mossling —— 气场笼罩「常野原」/)
  assert.doesNotMatch(text, /最近动静/, 'the start entry is not a stir')

  s.journal.push({ at: DAY, kind: 'fled', species: 'dotfinch' })
  assert.match(renderQuiet(s, 'mon'), /最近动静：2026-08-15 点点雀 挣脱逃走了/)
})

test('renderThrow covers every outcome', () => {
  assert.match(renderThrow({ outcome: 'none', ballsLeft: 3 }, fresh(), 'mon'), /先去干活/)
  assert.match(renderThrow({ outcome: 'noball' }, fresh(), 'mon'), /球用完了/)

  const s = withEncounter('volttuft')
  const caught = throwBall(s, DAY, seqFix(0.01))
  const text = renderThrow(caught, s, 'mon')
  assert.match(text.split('\n')[0], /三摇… 咔哒！捕获了 绒电鼠 Volttuft！◈ 少见/)
  assert.match(text, /它加入了队伍（2\/6）· 图鉴 2\/28/)
  assert.match(text, /球 ×7/)

  const dupe = withEncounter('mossling')
  assert.match(renderThrow(throwBall(dupe, DAY, seqFix(0.01)), dupe, 'mon'), /图鉴里已经有了[\s\S]*\+2，现有 ×9/)

  const missState = withEncounter('miststag')
  const miss = throwBall(missState, DAY, seqFix(0.9, 0.9, 0.6))
  assert.match(renderThrow(miss, missState, 'mon'), /啪！雾角鹿 挣脱了出来！[\s\S]*已投 1 球/)

  const fledState = withEncounter('miststag')
  const fled = throwBall(fledState, DAY, seqFix(0.9, 0.01, 0.6))
  assert.match(renderThrow(fled, fledState, 'mon'), /钻进草丛深处，跑了/)

  const shinyState = withEncounter('volttuft', { shiny: true })
  assert.match(renderThrow(throwBall(shinyState, DAY, seqFix(0.01)), shinyState, 'mon'), /✨ 而且是异色个体！/)
})

test('renderWalk with and without a standoff', () => {
  assert.match(renderWalk('dotfinch', 'mon'), /点点雀 目送你离开/)
  assert.match(renderWalk(null, 'mon'), /本来就没有/)
})

test('the dex veils the unknown, half-veils the seen, honors rumors', () => {
  const s = fresh()
  const text = renderDex(s)
  assert.match(text.split('\n')[0], /^图鉴 1\/28/)
  assert.match(text, /● 苔尾崽 Mossling ★ —— 尾巴尖上/)
  assert.match(text, /○ ？？？ ◇/)
  assert.match(text, /「谣传：深夜的报错声会引来一位不速之客。」/)
  assert.match(text, /「谣传：陪一个 harness 走过足够多的回合/)
  assert.doesNotMatch(text, /Nullnight|千轮鲸/, 'unmet legendaries stay nameless')

  s.seen.push('volttuft')
  assert.match(renderDex(s), /◐ 绒电鼠 Volttuft ◈ —— 见过，还没抓到/)

  s.caught.push({ species: 'volttuft', at: DAY, name: null, shiny: true })
  assert.match(renderDex(s), /● 绒电鼠 Volttuft ◈ ✨ —— 腮帮子/)
})

test('the team card numbers party then box, crowns the lead', () => {
  const s = fresh()
  s.caught.push({ species: 'volttuft', at: DAY, name: '电电', shiny: false })
  s.party.push('volttuft')
  let text = renderTeam(s, 'mon')
  assert.match(text.split('\n')[0], /^队伍 2\/6 · 带头的气场让「常野原」遭遇率 ×1\.5$/)
  assert.match(text, /1 ☆ 苔尾崽 Mossling ★ · 2026-08-15/)
  assert.match(text, /2 {3}电电（绒电鼠） ◈/)
  assert.match(text, /盒子还是空的/)
  assert.match(text, /\/mon swap <甲> <乙>/)

  s.caught.push({ species: 'shardtoad', at: DAY, name: null, shiny: false })
  text = renderTeam(s, 'mon')
  assert.match(text, /盒子 1 只/)
  assert.match(text, /3 {3}碎屏蛙 Shardtoad ◇/)
})

test('the story reads like a journey log', () => {
  const s = fresh()
  s.journal.push({ at: DAY, kind: 'catch', species: 'volttuft', shiny: true })
  s.journal.push({ at: DAY, kind: 'escaped', species: 'miststag', seen: false })
  s.journal.push({ at: DAY, kind: 'escaped', species: 'miststag', seen: true })
  s.journal.push({ at: DAY, kind: 'walked', species: 'dotfinch' })
  s.journal.push({ at: DAY, kind: 'rename', species: 'volttuft', to: '电电' })
  s.journal.push({ at: DAY, kind: 'dupe', species: 'volttuft' })
  const text = renderStory(s)
  assert.match(text, /苔尾崽 与你的旅程/)
  assert.match(text, /带着 苔尾崽 出发了/)
  assert.match(text, /捕获了 绒电鼠 ✨/)
  assert.match(text, /有什么东西悄悄溜走了（你没看清）/)
  assert.match(text, /雾角鹿 等累了，回草丛去了/)
  assert.match(text, /你从 点点雀 面前退开了/)
  assert.match(text, /绒电鼠 有了名字「电电」/)
  assert.match(text, /又遇到 绒电鼠，把球换了回来/)
})

test('the about card carries the trust stance and the command list', () => {
  const text = renderAbout('mon')
  assert.match(text, /零 token/)
  assert.match(text, /\$DSH_HOME\/wildmon\/state\.json/)
  assert.match(text, /dsh-digipet 同装共存/)
  assert.match(text, /每 250 个回合/)
  assert.match(text, /1\/64/)
  assert.match(text, /\/mon · start · throw · run · dex · team/)
})
