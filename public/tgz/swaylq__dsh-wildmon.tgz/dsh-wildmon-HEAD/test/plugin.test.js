import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'

import { apply } from '../index.js'

const DAY = new Date(2026, 7, 15, 14, 0, 0).getTime()
const NIGHT = new Date(2026, 7, 15, 3, 0, 0).getTime()

/** The slice of a Cordis context the plugin actually touches. */
function fakeCtx() {
  const listeners = new Map()
  const cleanups = []
  const commands = []
  const ctx = {
    on(event, fn) { listeners.set(event, [...(listeners.get(event) ?? []), fn]) },
    effect(fn) { const dispose = fn(); if (typeof dispose === 'function') cleanups.push(dispose) },
    inject(deps, fn) {
      assert.deepEqual(deps, ['commands'], 'commands is the only injected service')
      fn({ commands: { register: c => commands.push(c) } })
    },
  }
  const emit = (event, ...args) => { for (const fn of listeners.get(event) ?? []) fn(...args) }
  return { ctx, emit, commands, cleanups, listeners }
}

/**
 * Mount the plugin with scripted dice and a manual clock: dice.queue values
 * are consumed first, then every roll returns 1 (never spawn, never catch).
 */
function mount(t, config = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'wildmon-plugin-'))
  t.after(() => rmSync(dir, { recursive: true, force: true }))
  const statePath = join(dir, 'state.json')
  const world = fakeCtx()
  const dice = { queue: [] }
  const clockBox = { now: DAY }
  apply(world.ctx, {
    statePath,
    rng: () => (dice.queue.length > 0 ? dice.queue.shift() : 1),
    clock: () => clockBox.now,
    ...config,
  })
  const command = world.commands[0]
  const run = input => command.handler({ commandId: 'c1', agent: null, rawInput: input, signal: null })
  return { ...world, statePath, command, run, dice, clockBox }
}

test('apply wires four event taps, one command, one cleanup effect', (t) => {
  const { listeners, commands, cleanups, command } = mount(t)
  assert.deepEqual(
    [...listeners.keys()].sort(),
    ['agent/error', 'agent/inbox/claimed', 'agent/turn-stopping', 'tools/result'],
  )
  assert.equal(commands.length, 1)
  assert.equal(command.name, 'mon')
  assert.match(command.description, /wildmon/)
  assert.equal(cleanups.length, 1)
})

test('the whole first day: offer → start → quiet → encounter → catch', (t) => {
  const { run, emit, dice } = mount(t)

  assert.match(run('').text, /没人踏过的草丛/)
  assert.match(run('throw').text, /旅程还没开始/)
  assert.match(run('start').text, /苔尾崽[\s\S]*烬绒崽[\s\S]*澪滴崽/)
  assert.match(run('start 2').text, /你选择了 烬绒崽/)
  assert.match(run('start').text, /已经带着 烬绒崽/)
  assert.match(run('').text, /草丛静悄悄/)

  // Real work with scripted dice: the message event rolls a field spawn.
  dice.queue.push(0, 0.5, 0.9)
  emit('agent/inbox/claimed', { agent: null, message: {}, turn: 1 })
  assert.match(run('').text, /^野生的 .+ 出现了！/)

  dice.queue.push(0.01)
  const caught = run('throw')
  assert.match(caught.text, /咔哒！捕获了/)
  assert.match(caught.text, /图鉴 2\/28/)
  assert.match(run('dex').text, /图鉴 2\/28/)
  assert.match(run('team').text, /队伍 2\/6/)
  assert.match(run('story').text, /带着 烬绒崽 出发了/)
})

test('tool results and errors are observed and classified', (t) => {
  const { run, emit } = mount(t)
  run('start 1')
  emit('tools/result', { name: 'write_file' }, { isError: false })
  emit('tools/result', { name: 'web_search' }, { isError: false })
  emit('tools/result', { name: 'shell' }, { isError: true })
  emit('agent/error', { agent: null, turn: 1, step: 1, error: new Error('boom') })
  emit('agent/turn-stopping', { agent: null, turn: 1, signal: null })
  const about = run('about')
  assert.equal(about.kind, 'success')
  const quiet = run('')
  assert.match(quiet.text, /球 ×9/, 'the finished turn refilled one ball')
})

test('a night message can wake the night pool', (t) => {
  const { run, emit, dice, clockBox } = mount(t)
  run('start 1')
  clockBox.now = NIGHT
  dice.queue.push(0.5, 0, 0.5, 0.9)
  emit('agent/inbox/claimed', { agent: null, message: {}, turn: 1 })
  assert.match(run('').text, /夜阈/)
})

test('malformed event payloads are absorbed, not thrown', (t) => {
  const { run, emit } = mount(t)
  run('start 1')
  emit('tools/result', undefined, undefined)
  emit('tools/result', {}, {})
  emit('agent/turn-stopping')
  emit('agent/error')
  assert.equal(run('').kind, 'success', 'the grass swallowed the garbage')
})

test('run, swap, name and unknown subcommands answer in character', (t) => {
  const { run, emit, dice } = mount(t)
  run('start 3')
  assert.match(run('run').text, /本来就没有/)

  dice.queue.push(0, 0.5, 0.9)
  emit('agent/inbox/claimed', {})
  dice.queue.push(0.01)
  run('throw')
  assert.equal(run('swap 1 2').kind, 'success')
  assert.match(run('swap 1 99').text, /编号/)
  assert.match(run('name 2 闪闪').text, /叫「闪闪」/)
  assert.match(run('name').text, /用法/)
  assert.match(run('feed').text, /不认识「feed」/)
})

test('walking away from a live standoff', (t) => {
  const { run, emit, dice } = mount(t)
  run('start 1')
  dice.queue.push(0, 0.5, 0.9)
  emit('agent/inbox/claimed', {})
  assert.match(run('run').text, /目送你离开/)
  assert.match(run('').text, /草丛静悄悄/)
})

test('the command name is configurable and invalid overrides fall back', (t) => {
  assert.equal(mount(t, { command: 'wild' }).command.name, 'wild')
  assert.equal(mount(t, { command: 'Bad Name!' }).command.name, 'mon')
})

test('the cleanup effect flushes the save to disk', (t) => {
  const { run, emit, cleanups, statePath } = mount(t)
  run('start 1')
  emit('agent/turn-stopping', {})
  cleanups[0]()
  assert.equal(existsSync(statePath), true)
})

test('a handler explosion becomes a friendly error result', (t) => {
  const { command } = mount(t)
  const result = command.handler({ rawInput: { toString() { throw new Error('cursed input') } } })
  assert.equal(result.kind, 'error')
  assert.match(result.text, /wildmon 被草绊了一下/)
})
