/**
 * dsh-wildmon dex — every card `/mon` prints. Pure string builders; no IO,
 * no harness imports, no mutation (seen-marking happens in core's `look`).
 *
 * Card layout honors how the harness renders command results: the stream
 * shows a collapsed single line (newlines flattened), the detail card is
 * monospace with newlines kept — so every card puts its punchline in line 1
 * and the ASCII art below.
 *
 * @module dsh-wildmon/dex
 */

import { dexCounts, leadHabitat, roster, BALL_CAP, KILOWHALE_EVERY, LEAD_AURA, PARTY_SIZE } from './core.js'
import { HABITATS, RARITY, SPECIES, STARTERS } from './species.js'

const fmtDay = (ms) => {
  const d = new Date(ms)
  const p = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

/** `◈ 少见` — the rarity tag every card reuses. */
export function rarityTag(speciesId) {
  const r = RARITY[SPECIES[speciesId].rarity]
  return `${r.glyph} ${r.zh}`
}

/** Species display name: `绒电鼠 Volttuft`. */
export function speciesName(speciesId) {
  const s = SPECIES[speciesId]
  return `${s.zh} ${s.en}`
}

/** A caught partner's display title: nickname first, species otherwise. */
export function title(entry) {
  const s = SPECIES[entry.species]
  return entry.name ? `${entry.name}（${s.zh}）` : `${s.zh} ${s.en}`
}

const shinyMark = entry => (entry.shiny ? ' ✨' : '')

/** The `/mon` card when a wild one is in the grass (call core.look first). */
export function renderEncounter(state, now, commandName) {
  const enc = state.encounter
  const spec = SPECIES[enc.species]
  const lines = []
  lines.push(`野生的 ${speciesName(enc.species)} 出现了！${rarityTag(enc.species)} · ${HABITATS[spec.habitat].zh}`)
  if (enc.shiny) lines.push('✨ 是异色个体！')
  lines.push('')
  lines.push(...spec.art)
  lines.push('')
  if (state.caught.some(c => c.species === enc.species)) {
    lines.push(`「${spec.flavor}」（图鉴里已有 —— 抓到会换回 2 颗球）`)
  } else {
    lines.push('图鉴里还没有它的记录。')
  }
  const minutes = Math.max(1, Math.ceil((enc.expiresAt - now) / 60_000))
  const throwNote = enc.throws > 0 ? ` · 已投 ${enc.throws} 球（下一球更容易命中）` : ''
  lines.push(`它大约还会停留 ${minutes} 分钟${throwNote}`)
  lines.push(`球 ×${state.balls} —— /${commandName} throw 投球 · /${commandName} run 撤退`)
  return lines.join('\n')
}

/** The `/mon` card when the grass is quiet. */
export function renderQuiet(state, commandName) {
  const d = dexCounts(state)
  const lines = []
  lines.push(`草丛静悄悄。球 ×${state.balls} · 图鉴 ${d.caught}/${d.total}`)
  const lead = state.party[0]
  if (lead) {
    lines.push(`带头 ${title(roster(state)[0])} —— 气场笼罩「${HABITATS[leadHabitat(state)].zh}」，那里遭遇率 ×${LEAD_AURA}`)
  }
  const last = [...state.journal].reverse().find(e => e.kind !== 'start')
  if (last) lines.push(`最近动静：${fmtDay(last.at)} ${journalLine(last)}`)
  lines.push('')
  lines.push('去干活吧 —— 回合、工具调用、报错都会惊动草丛，深夜还有夜行的。')
  lines.push(`回来 /${commandName} 看一眼；有东西的话别让它等太久。`)
  return lines.join('\n')
}

/** The starter offer (`/mon start` with nothing chosen yet). */
export function renderStarterOffer(commandName) {
  const lines = ['三只小灵在等你挑一个同伴 ——', '']
  STARTERS.forEach((id, i) => {
    const s = SPECIES[id]
    lines.push(`${i + 1}. ${s.zh} ${s.en}`)
    lines.push(...s.art.map(a => '  ' + a))
    lines.push(`  「${s.flavor}」`)
    lines.push('')
  })
  lines.push(`/${commandName} start <1|2|3 或名字> 带走一只。没选的两只，据说以后还能在野外碰见。`)
  return lines.join('\n')
}

/** The send-off card right after choosing. */
export function renderJourneyStart(state, commandName) {
  const starter = SPECIES[state.starter]
  return [
    `你选择了 ${starter.zh} ${starter.en}！它蹭了蹭你的手。`,
    '',
    ...starter.art,
    '',
    `「${starter.flavor}」`,
    `导师塞给你 ${state.balls} 颗捕灵球。从现在起，你的每一点真实工作都会惊动草丛。`,
    `/${commandName} 看状态 · /${commandName} dex 看图鉴 · /${commandName} about 了解规则`,
  ].join('\n')
}

const SHAKE_WORDS = ['◓ 一摇…', '◓ 二摇…', '◓ 三摇…']
const shakeLine = n => SHAKE_WORDS.slice(0, Math.max(1, Math.min(3, n))).join(' ')

/** The throw ceremony card, from a core.throwBall result. */
export function renderThrow(result, state, commandName) {
  const lines = []
  switch (result.outcome) {
    case 'none':
      return `草丛里现在没有小灵。先去干活惊动它们，回头 /${commandName} 看看。`
    case 'noball':
      return `球用完了！每完成一个回合补 1 颗（上限 ${BALL_CAP}），抓到重复的也会换回 2 颗。`
    case 'caught': {
      const spec = SPECIES[result.species]
      lines.push(`${shakeLine(3)} 咔哒！捕获了 ${speciesName(result.species)}！${rarityTag(result.species)}`)
      if (result.shiny) lines.push('✨ 而且是异色个体！')
      lines.push('')
      lines.push(...spec.art)
      lines.push('')
      lines.push(`「${spec.flavor}」`)
      lines.push(result.partyJoined
        ? `它加入了队伍（${state.party.length}/${PARTY_SIZE}）· 图鉴 ${result.dex.caught}/${result.dex.total}`
        : `队伍满了，它住进了盒子 · 图鉴 ${result.dex.caught}/${result.dex.total}`)
      lines.push(`球 ×${result.ballsLeft} —— /${commandName} dex 看收集 · /${commandName} team 看队伍`)
      return lines.join('\n')
    }
    case 'dupe':
      return [
        `${shakeLine(3)} 咔哒！又一只 ${speciesName(result.species)} —— 图鉴里已经有了。`,
        `它在球里滚了两圈表示抗议，帮你把球捡了回来（+2，现有 ×${result.ballsLeft}）。`,
      ].join('\n')
    case 'miss':
      return [
        `${shakeLine(result.shakes)} 啪！${SPECIES[result.species].zh} 挣脱了出来！`,
        `它还在草丛里瞪着你（已投 ${result.throws} 球，下一球更容易命中）。`,
        `球 ×${result.ballsLeft} —— /${commandName} throw 再来`,
      ].join('\n')
    case 'fled':
      return [
        `${shakeLine(result.shakes)} 啪！${SPECIES[result.species].zh} 挣脱后钻进草丛深处，跑了。`,
        `球 ×${result.ballsLeft} —— 下次再遇见吧。`,
      ].join('\n')
    default:
      return '……什么都没发生。'
  }
}

/** The walk-away card. */
export function renderWalk(speciesId, commandName) {
  if (!speciesId) return `本来就没有对峙中的小灵。/${commandName} 看看草丛。`
  return `你慢慢退了出来。${SPECIES[speciesId].zh} 目送你离开，回草丛里去了。`
}

/** One dex row: caught ●, seen ◐, unknown ○. */
function dexRow(state, id) {
  const spec = SPECIES[id]
  const r = RARITY[spec.rarity]
  const entry = state.caught.find(c => c.species === id)
  if (entry) return `  ● ${spec.zh} ${spec.en} ${r.glyph}${shinyMark(entry)} —— ${spec.flavor}`
  if (state.seen.includes(id)) return `  ◐ ${spec.zh} ${spec.en} ${r.glyph} —— 见过，还没抓到`
  const veil = spec.hint ? ` ——「${spec.hint}」` : ''
  return `  ○ ？？？ ${r.glyph}${veil}`
}

/** The `/mon dex` collection page, grouped by habitat. */
export function renderDex(state) {
  const d = dexCounts(state)
  const lines = [`图鉴 ${d.caught}/${d.total}（捕获 ● · 目击 ◐ · 未知 ○）`, '']
  for (const [habitat, info] of Object.entries(HABITATS)) {
    const ids = Object.keys(SPECIES).filter(id => SPECIES[id].habitat === habitat)
    if (ids.length === 0) continue
    lines.push(`${info.zh}（${info.hint}）`)
    for (const id of ids) lines.push(dexRow(state, id))
    lines.push('')
  }
  return lines.join('\n').trimEnd()
}

/** The `/mon team` party-and-box page (numbering feeds swap/name). */
export function renderTeam(state, commandName) {
  const rows = roster(state)
  const partyLen = state.party.length
  const lines = [`队伍 ${partyLen}/${PARTY_SIZE} · 带头的气场让「${HABITATS[leadHabitat(state)].zh}」遭遇率 ×${LEAD_AURA}`, '']
  rows.forEach((row, i) => {
    if (i === partyLen) {
      lines.push('')
      lines.push(`盒子 ${rows.length - partyLen} 只`)
    }
    const lead = i === 0 ? '☆' : ' '
    lines.push(`  ${String(i + 1).padStart(2)} ${lead} ${title(row)} ${rarityTag(row.species).split(' ')[0]}${shinyMark(row)} · ${fmtDay(row.at)}`)
  })
  if (rows.length === partyLen) {
    lines.push('')
    lines.push('盒子还是空的。')
  }
  lines.push('')
  lines.push(`/${commandName} swap <甲> <乙> 换位（1 号位是带头）· /${commandName} name <编号> <名字> 起名`)
  return lines.join('\n')
}

/** One journal entry, without the date prefix. */
function journalLine(e) {
  const zh = SPECIES[e.species]?.zh ?? e.species
  switch (e.kind) {
    case 'start': return `带着 ${zh} 出发了`
    case 'catch': return `捕获了 ${zh}${e.shiny ? ' ✨' : ''}`
    case 'dupe': return `又遇到 ${zh}，把球换了回来`
    case 'fled': return `${zh} 挣脱逃走了`
    case 'escaped': return e.seen ? `${zh} 等累了，回草丛去了` : '有什么东西悄悄溜走了（你没看清）'
    case 'walked': return `你从 ${zh} 面前退开了`
    case 'rename': return `${zh} 有了名字「${e.to}」`
    default: return e.kind
  }
}

/** The `/mon story` journey log. */
export function renderStory(state) {
  const starter = SPECIES[state.starter]
  const lines = [`${starter.zh} 与你的旅程`, '']
  for (const e of state.journal) lines.push(`  ${fmtDay(e.at)}  ${journalLine(e)}`)
  return lines.join('\n')
}

/** The `/mon about` mechanics-and-trust card. */
export function renderAbout(commandName) {
  return [
    'dsh-wildmon —— 你的真实工作就是草丛，野生小灵住在里面。',
    '',
    '遭遇：每个回合、消息、工具调用、报错都有几率惊动草丛（报错最响），',
    '越久没遇见几率越高。00:00–05:59 有夜行小灵；带头同伴的老家遭遇率 ×1.5。',
    '捕捉：/mon throw 消耗 1 颗球。越稀有越难抓，连续脱手会越投越准；',
    '它也可能跑掉。球：出发 8 颗，每完成一个回合 +1（上限 30），抓到重复 +2。',
    `野外的小灵只等 10 分钟。传说小灵有 3 只 —— 其中一只每 ${KILOWHALE_EVERY} 个回合浮出一次，`,
    '另外两只的条件，图鉴里只留了谣传。异色个体存在，概率 1/64。',
    '',
    '信任立场：不注册模型工具、不注入上下文 —— 模型不知道它存在，',
    '零 token 开销；不联网；只读写自己的存档（$DSH_HOME/wildmon/state.json）。',
    '事件监听全部包在 try/catch 里，抓小灵永远不会打断你的工作。',
    '与 dsh-digipet 同装共存：不同命令、不同存档，互不相扰。',
    '',
    `命令：/${commandName} · start · throw · run · dex · team · swap <甲> <乙> · name <编号> <名字> · story · about`,
  ].join('\n')
}
