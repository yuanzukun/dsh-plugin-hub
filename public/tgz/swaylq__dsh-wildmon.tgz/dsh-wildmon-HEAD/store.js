/**
 * dsh-wildmon store — the save file and the grass valve.
 *
 * One journey per harness home, saved at `$DSH_HOME/wildmon/state.json` the
 * same way the official JSON storage backend persists: write a sibling temp
 * file, fsync, then atomically rename over the old save. Observations are
 * throttled to one disk write per interval so a busy agent doesn't turn every
 * tool call into IO. Clock and rng are injectable for tests.
 *
 * @module dsh-wildmon/store
 */

import { closeSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, writeSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'

import {
  beginJourney,
  look as coreLook,
  migrate,
  observe as coreObserve,
  rename as coreRename,
  swapSlots as coreSwap,
  throwBall as coreThrow,
  walkAway as coreWalk,
} from './core.js'

/** The harness home, matching the launcher's own resolution. */
export function dshHome() {
  const configured = process.env.DSH_HOME
  return configured !== undefined && configured.trim() !== ''
    ? resolve(configured.trim())
    : join(homedir(), '.dsh')
}

/** Default save location. */
export function defaultStatePath() {
  return join(dshHome(), 'wildmon', 'state.json')
}

const SAVE_THROTTLE_MS = 1500

/**
 * Open (or lazily create on journey start) the save file.
 * @param filePath - where the save lives.
 * @param options.now / options.rng - injectable clock and dice for tests.
 * @param options.setTimer / options.clearTimer - injectable scheduler.
 */
export function createStore(filePath = defaultStatePath(), options = {}) {
  const now = options.now ?? (() => Date.now())
  const rng = options.rng ?? Math.random
  const setTimer = options.setTimer ?? setTimeout
  const clearTimer = options.clearTimer ?? clearTimeout

  let dirty = false
  let timer = null
  let state = load()

  function load() {
    try {
      return migrate(JSON.parse(readFileSync(filePath, 'utf8')))
    } catch {
      return null
    }
  }

  function writeNow() {
    if (!dirty || state === null) return
    mkdirSync(dirname(filePath), { recursive: true })
    const tmp = `${filePath}.tmp`
    const fd = openSync(tmp, 'w')
    try {
      writeSync(fd, JSON.stringify(state))
      fsyncSync(fd)
    } finally {
      closeSync(fd)
    }
    renameSync(tmp, filePath)
    dirty = false
  }

  function scheduleSave() {
    dirty = true
    if (timer !== null) return
    timer = setTimer(() => {
      timer = null
      try { writeNow() } catch { /* the safari must never break the harness */ }
    }, SAVE_THROTTLE_MS)
    if (typeof timer?.unref === 'function') timer.unref()
  }

  return {
    /** The live state (null until a starter is chosen). Exposed for rendering. */
    get state() { return state },

    /** The store's clock, so renderers agree with the injected time source. */
    now() { return now() },

    /** Digest one observed harness event; silently ignored before the journey starts. */
    observe(kind) {
      if (state === null) return
      coreObserve(state, kind, now(), rng)
      scheduleSave()
    },

    /** Begin the journey with a starter. Returns false when one is underway. */
    start(starterId) {
      if (state !== null) return false
      const fresh = beginJourney(starterId, now())
      if (fresh === null) return false
      state = fresh
      scheduleSave()
      return true
    },

    /** Settle expiry, mark the live encounter (and dex) seen; null when quiet. */
    look() {
      if (state === null) return null
      const enc = coreLook(state, now())
      scheduleSave()
      return enc
    },

    /** Throw one ball; a result card object (see core.throwBall). */
    throwBall() {
      if (state === null) return { outcome: 'none', ballsLeft: 0 }
      const result = coreThrow(state, now(), rng)
      scheduleSave()
      return result
    },

    /** Walk away from the encounter; the species left, or null. */
    walkAway() {
      if (state === null) return null
      const species = coreWalk(state, now())
      scheduleSave()
      return species
    },

    /** Swap two roster slots; null on success or a refusal string. */
    swap(a, b) {
      if (state === null) return '旅程还没开始'
      const refusal = coreSwap(state, a, b)
      if (refusal === null) scheduleSave()
      return refusal
    },

    /** Nickname a partner; `{ species, name }` or null. */
    rename(slot, rawName) {
      if (state === null) return null
      const renamed = coreRename(state, slot, rawName, now())
      if (renamed) scheduleSave()
      return renamed
    },

    /** Flush any pending write and stop the timer. Called on plugin unload. */
    dispose() {
      if (timer !== null) {
        clearTimer(timer)
        timer = null
      }
      try { writeNow() } catch { /* best effort on the way out */ }
    },
  }
}
