/**
 * dsh-wildmon — your real work is the tall grass; wild critters live in it.
 *
 * The whole plugin is four event taps and one slash command. It registers no
 * model-facing tool and injects no context: the model never learns the safari
 * exists, so it costs zero tokens per request. Every listener body is wrapped
 * so a safari bug can never veto or delay real work — the taps observe
 * emit-mode notifications and return immediately.
 *
 * The taps only roll dice: a finished turn, a user message, a tool result or
 * an error each has a chance to rustle the grass (errors rustle loudest, the
 * small hours wake the night pool). Catching, collecting and team-building
 * all happen through the command — the classic loop, fed by real work.
 *
 * @module dsh-wildmon
 */

import { classify } from './core.js'
import {
  renderAbout,
  renderDex,
  renderEncounter,
  renderJourneyStart,
  renderQuiet,
  renderStarterOffer,
  renderStory,
  renderTeam,
  renderThrow,
  renderWalk,
  speciesName,
} from './dex.js'
import { SPECIES, STARTERS } from './species.js'
import { createStore } from './store.js'

export const name = 'wildmon'
export const inject = []

/** Never let a safari exception travel into the agent loop. */
const contained = fn => (...args) => {
  try { fn(...args) } catch { /* the grass swallows its own mishaps */ }
}

export function apply(ctx, config = {}) {
  const commandName = typeof config.command === 'string' && /^[a-z][a-z0-9-]{0,23}$/.test(config.command)
    ? config.command
    : 'mon'
  const store = createStore(
    typeof config.statePath === 'string' && config.statePath.trim() !== '' ? config.statePath : undefined,
    {
      // Test-only seams; YAML config can't express functions, so production
      // installs always get the real clock and dice.
      now: typeof config.clock === 'function' ? config.clock : undefined,
      rng: typeof config.rng === 'function' ? config.rng : undefined,
    },
  )

  // ---- the grass: observe real work, roll for encounters ----
  ctx.on('agent/inbox/claimed', contained(() => store.observe('message')))
  ctx.on('agent/turn-stopping', contained(() => store.observe('turn')))
  ctx.on('agent/error', contained(() => store.observe('agentError')))
  ctx.on('tools/result', contained((exec, result) => {
    store.observe(result?.isError ? 'toolError' : classify(exec?.name))
  }))

  // Flush the throttled save when the plugin unloads or the process leaves.
  ctx.effect(() => () => store.dispose())

  // ---- the one human command ----
  ctx.inject(['commands'], (commandCtx) => {
    commandCtx.commands.register({
      name: commandName,
      description: 'wildmon safari: 遭遇 · throw 捕捉 · dex 图鉴 · team 队伍',
      input: { hint: '[start|throw|run|dex|team|swap 甲 乙|name 编号 名字|story|about]' },
      handler: (invocation) => {
        try {
          return dispatch(store, commandName, String(invocation.rawInput ?? ''))
        } catch (error) {
          return { kind: 'error', text: `wildmon 被草绊了一下：${error?.message ?? error}` }
        }
      },
    })
  })
}

/** Resolve `/mon start` input to a starter id: 1-based index, 中文名 or English. */
function resolveStarter(argument) {
  const arg = argument.trim()
  if (arg === '') return null
  const index = Number.parseInt(arg, 10)
  if (Number.isInteger(index) && index >= 1 && index <= STARTERS.length) return STARTERS[index - 1]
  const lower = arg.toLowerCase()
  return STARTERS.find(id => SPECIES[id].zh === arg || SPECIES[id].en.toLowerCase() === lower || id === lower) ?? null
}

/** Route `/mon <sub>` to a card. Exported for tests. */
export function dispatch(store, commandName, rawInput) {
  const trimmed = rawInput.trim()
  const [sub, ...rest] = trimmed === '' ? [''] : trimmed.split(/\s+/)
  const argument = rest.join(' ')
  const notStarted = { kind: 'error', text: `旅程还没开始。/${commandName} start 先挑一个同伴。` }

  switch (sub.toLowerCase()) {
    case '': {
      if (store.state === null) {
        return {
          kind: 'success',
          text: `这里是一片没人踏过的草丛。/${commandName} start 选一个同伴，你的真实工作就会开始惊动它。`,
        }
      }
      const encounter = store.look()
      return {
        kind: 'success',
        text: encounter ? renderEncounter(store.state, store.now(), commandName) : renderQuiet(store.state, commandName),
      }
    }
    case 'start': {
      if (store.state !== null) {
        return { kind: 'success', text: `你已经带着 ${speciesName(store.state.starter)} 出发过了。/${commandName} 看看现在的草丛。` }
      }
      const starterId = resolveStarter(argument)
      if (starterId === null) return { kind: 'success', text: renderStarterOffer(commandName) }
      store.start(starterId)
      return { kind: 'success', text: renderJourneyStart(store.state, commandName) }
    }
    case 'throw': {
      if (store.state === null) return notStarted
      return { kind: 'success', text: renderThrow(store.throwBall(), store.state, commandName) }
    }
    case 'run': {
      if (store.state === null) return notStarted
      return { kind: 'success', text: renderWalk(store.walkAway(), commandName) }
    }
    case 'dex': {
      if (store.state === null) return notStarted
      return { kind: 'success', text: renderDex(store.state) }
    }
    case 'team': {
      if (store.state === null) return notStarted
      return { kind: 'success', text: renderTeam(store.state, commandName) }
    }
    case 'swap': {
      if (store.state === null) return notStarted
      const [a, b] = rest.map(n => Number.parseInt(n, 10))
      const refusal = store.swap(a, b)
      if (refusal !== null) return { kind: 'error', text: refusal }
      return { kind: 'success', text: renderTeam(store.state, commandName) }
    }
    case 'name': {
      if (store.state === null) return notStarted
      const slot = Number.parseInt(rest[0], 10)
      const renamed = store.rename(slot, rest.slice(1).join(' '))
      if (renamed === null) return { kind: 'error', text: `用法：/${commandName} name <编号> <名字>（16 字以内，编号看 /${commandName} team）` }
      return { kind: 'success', text: `从今天起，${speciesName(renamed.species)} 叫「${renamed.name}」。` }
    }
    case 'story': {
      if (store.state === null) return notStarted
      return { kind: 'success', text: renderStory(store.state) }
    }
    case 'about':
    case 'help': {
      return { kind: 'success', text: renderAbout(commandName) }
    }
    default: {
      return { kind: 'error', text: `不认识「${sub}」。可用：/${commandName} · start · throw · run · dex · team · swap · name · story · about` }
    }
  }
}
