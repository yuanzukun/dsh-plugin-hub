/**
 * dsh-wildmon species — the full roster, pure data.
 *
 * Kept import-free so both the logic half (core.js) and the rendering half
 * (dex.js) can depend on it without a cycle. All names and ASCII art are
 * original; silhouettes only nod to the collect-em-all genre (a starter trio,
 * an electric rodent, a legendary whale for the harness mascot). Art is
 * deliberately narrow (≤ 20 columns) so each line survives proportional fonts.
 *
 * @module dsh-wildmon/species
 */

/** Rarity tiers: glyph shown everywhere, weight used by the spawn table. */
export const RARITY = {
  common: { glyph: '◇', zh: '常见', weight: 6, catch: 0.65, flee: 0.10 },
  uncommon: { glyph: '◈', zh: '少见', weight: 3, catch: 0.45, flee: 0.15 },
  rare: { glyph: '★', zh: '稀有', weight: 1, catch: 0.28, flee: 0.20 },
  legendary: { glyph: '✦', zh: '传说', weight: 0, catch: 0.12, flee: 0.25 },
}

/** Habitats: where each work event rustles the grass. Display order. */
export const HABITATS = {
  trio: { zh: '御三家', hint: '旅程开始时的三个同伴，没选的两只据说仍在野外游荡' },
  field: { zh: '常野原', hint: '聊天和回合惊动的寻常草丛' },
  forge: { zh: '锻造窟', hint: '写文件、跑命令时火花溅出来的地方' },
  archive: { zh: '墨书林', hint: '读代码、查资料时纸页间窜出来的东西' },
  glitch: { zh: '故障岭', hint: '报错才会震醒的荒地' },
  night: { zh: '夜阈', hint: '只在 00:00–05:59 出没' },
  myth: { zh: '传说', hint: '各有各的脾气，图鉴不告诉你怎么遇见' },
}

/**
 * The 28 species. `hint` is the veiled dex line shown before you catch one;
 * legendaries keep their spawn condition a rumor.
 */
export const SPECIES = {
  // ---- 御三家（/mon start 三选一；没选的两只成为常野原的稀客） ----
  // `aura`: the habitat a starter blesses when leading the party — trio
  // itself never spawns, so each starter roots for its temperament's home.
  mossling: {
    zh: '苔尾崽', en: 'Mossling', habitat: 'trio', rarity: 'rare', aura: 'field',
    flavor: '尾巴尖上长了一株新芽，浇水就摇。',
    art: [
      '   ⌒ ☘',
      '  (ᵔᴥᵔ )',
      '  c(   )ɔ',
      '    ᵛ ᵛ',
    ],
  },
  cinderpuff: {
    zh: '烬绒崽', en: 'Cinderpuff', habitat: 'trio', rarity: 'rare', aura: 'forge',
    flavor: '一团永远差一口气熄灭的火绒，生气时噼啪响。',
    art: [
      '   ( ((',
      '  (ʘᴥʘ )',
      '  ⟅,,,,,⟆',
      '    ᘳᘰ',
    ],
  },
  puddlenip: {
    zh: '澪滴崽', en: 'Puddlenip', habitat: 'trio', rarity: 'rare', aura: 'archive',
    flavor: '身体是一滴不肯落地的水，心情好的时候冒泡。',
    art: [
      '    ○',
      '   ( ˘ω˘)',
      '  ~(   )~',
      '    ~~~',
    ],
  },

  // ---- 常野原（消息、回合、中性工具） ----
  fluffgrub: {
    zh: '绒绒虫', en: 'Fluffgrub', habitat: 'field', rarity: 'common',
    flavor: '毛茸茸的一节一节，据说每节存着一句没发出去的话。',
    art: [
      '  ⌒⌒⌒⌒',
      ' (◉‿◉)ɔɔɔ~',
    ],
  },
  dotfinch: {
    zh: '点点雀', en: 'Dotfinch', habitat: 'field', rarity: 'common',
    flavor: '落在光标上打盹，闪一下就换一个地方。',
    art: [
      '   ‸',
      '  (•ᴗ•)>',
      '   ⌄⌄',
    ],
  },
  volttuft: {
    zh: '绒电鼠', en: 'Volttuft', habitat: 'field', rarity: 'uncommon',
    flavor: '腮帮子存着静电，蹭一下够点亮一盏台灯。',
    art: [
      '  ⟋⟍  ⟋⟍',
      '  (⚡ᴥ⚡)',
      '  c(   )ɔ',
      '    ⌁⌁',
    ],
  },
  chimehop: {
    zh: '铃铛兔', en: 'Chimehop', habitat: 'field', rarity: 'uncommon',
    flavor: '每跳一下响一声，你听不见，但别的小灵都竖起耳朵。',
    art: [
      '  ⌒) (⌒',
      '  ( •ㅅ•)',
      '   (,,)◎',
    ],
  },
  miststag: {
    zh: '雾角鹿', en: 'Miststag', habitat: 'field', rarity: 'rare',
    flavor: '角上挂着一小片晨雾，走过的地方句子会变通顺。',
    art: [
      '  ⑃   ⑃',
      '   \\ /',
      '  (ᴗ˳ᴗ)',
      '   |  |›',
    ],
  },

  // ---- 锻造窟（写文件、跑命令类工具） ----
  malletclaw: {
    zh: '锤头蟹', en: 'Malletclaw', habitat: 'forge', rarity: 'common',
    flavor: '左钳是把小锤子，看见没敲平的东西就手痒。',
    art: [
      '  🔨   ⌐',
      '  (•︿•)',
      '  ⟨⟨   ⟩⟩',
    ],
  },
  rivetshell: {
    zh: '铆钉龟', en: 'Rivetshell', habitat: 'forge', rarity: 'common',
    flavor: '壳上的铆钉一颗都不是装饰，它自己也数不清了。',
    art: [
      '   ▂▄▂',
      '  ⟨◘ ◘ ◘⟩',
      '  (ᴗ    )',
      '   ‿  ‿',
    ],
  },
  weldfly: {
    zh: '焊花萤', en: 'Weldfly', habitat: 'forge', rarity: 'uncommon',
    flavor: '尾巴上的光是焊出来的，落过的地方接缝更结实。',
    art: [
      '   ≡(  )≡',
      '   (•‿•)',
      '     ✧⌁',
    ],
  },
  cogbadger: {
    zh: '齿轮獾', en: 'Cogbadger', habitat: 'forge', rarity: 'uncommon',
    flavor: '背上的齿轮咬合你的进度，卡住的时候它比你先皱眉。',
    art: [
      '  ✿▂▂✿',
      '  (◔ᴥ◔)',
      '  ⟨⟨▔▔▔⟩⟩',
      '   ⌐ ⌐',
    ],
  },
  coredrake: {
    zh: '熔芯蜥', en: 'Coredrake', habitat: 'forge', rarity: 'rare',
    flavor: '肚子里揣着一颗还没冷却的构建产物，冬天很抢手。',
    art: [
      '   ▲▲',
      '  (ò▿ó)',
      '  ⟨▓▓▓⟩=~',
      '   ⌐  ⌐',
    ],
  },

  // ---- 墨书林（读代码、查资料类工具） ----
  markmoth: {
    zh: '书签蛾', en: 'Markmoth', habitat: 'archive', rarity: 'common',
    flavor: '停在哪一页，哪一页就是你下次要找的那页。',
    art: [
      '  ⟦⟧  ⟦⟧',
      '   (ᵕᴗᵕ)',
      '    ‖‖',
    ],
  },
  inkblot: {
    zh: '墨团猫', en: 'Inkblot', habitat: 'archive', rarity: 'common',
    flavor: '踩过键盘的地方留下一行墨迹，偶尔居然能跑通。',
    art: [
      '  /\\_/\\',
      ' ( -ω- )',
      '  (,,)(,,)▓',
    ],
  },
  indexowl: {
    zh: '索引鸮', en: 'Indexowl', habitat: 'archive', rarity: 'uncommon',
    flavor: '记得每样东西在哪，就是不肯直接告诉你。',
    art: [
      '   ,▽,',
      '  {◉ v ◉}',
      '   |¶¶¶|',
      '    ^ ^',
    ],
  },
  nibshrew: {
    zh: '注脚鼩', en: 'Nibshrew', habitat: 'archive', rarity: 'uncommon',
    flavor: '住在脚注里，出场顺序永远是 [1]。',
    art: [
      '   ⌐[1]',
      '  (•̀ · •́ )>✎',
      '    ˇˇ',
    ],
  },
  tomewyrm: {
    zh: '典藏龙', en: 'Tomewyrm', habitat: 'archive', rarity: 'rare',
    flavor: '盘在一部没人借过的大部头上，你翻开它就算相遇。',
    art: [
      '   ~ϟ~',
      '  (ᴗ͡ ˬᴗ͡ )⟩',
      '  ⟦▤▤▤▤⟧',
      '  ⟦▤▤▤▤⟧',
    ],
  },

  // ---- 故障岭（工具失败、agent 报错） ----
  shardtoad: {
    zh: '碎屏蛙', en: 'Shardtoad', habitat: 'glitch', rarity: 'common',
    flavor: '皮肤是花屏纹理的，蹲着不动时像一块坏掉的显示区。',
    art: [
      '  ▚ ▞▚ ▞',
      ' ( ⊙ ﹏⊙ )',
      '  ⟋⟍  ⟋⟍',
    ],
  },
  tracepede: {
    zh: '栈迹蜈', en: 'Tracepede', habitat: 'glitch', rarity: 'uncommon',
    flavor: '一节一节全是现场，最后一节永远写着 at line 1。',
    art: [
      ' ⟅at⟆⟅at⟆⟅at⟆',
      '  (×н×)ɜɜɜ',
      '   ˇˇˇˇˇ',
    ],
  },
  nullhog: {
    zh: '空指猬', en: 'Nullhog', habitat: 'glitch', rarity: 'uncommon',
    flavor: '刺是指针，大多数指着不存在的地方，抱它要看运气。',
    art: [
      '  ↗ ↑ ↖',
      ' ⟨(ᵒ⌓ᵒ)⟩',
      '   ‿‿‿',
    ],
  },
  panicray: {
    zh: '惊叹魟', en: 'Panicray', habitat: 'glitch', rarity: 'rare',
    flavor: '翅膀展开是一个大大的感叹号，出现说明事情不小。',
    art: [
      '  ⟋▔▔▔⟍',
      ' ⟨  ◉︿◉ ⟩',
      '  ⟍▁▁▁⟋',
      '    ❕',
    ],
  },

  // ---- 夜阈（00:00–05:59 的非报错事件） ----
  lunasmudge: {
    zh: '月痕猫', en: 'Lunasmudge', habitat: 'night', rarity: 'uncommon',
    flavor: '身上有一块擦不掉的月光，白天它自己也找不到自己。',
    art: [
      '  ☾ /\\_/\\',
      '   ( ˘ᴗ˘ )',
      '    (,,)~',
    ],
  },
  dozetapir: {
    zh: '枕梦貘', en: 'Dozetapir', habitat: 'night', rarity: 'uncommon',
    flavor: '专吃你「再改一行就睡」之后产生的那些梦。',
    art: [
      '   ᶻᶻᶻ',
      '  (ᴗ˳ᴗ)⌒',
      '  ⟨     ⟩',
      '   ‿ ‿',
    ],
  },
  stardrift: {
    zh: '星屑水母', en: 'Stardrift', habitat: 'night', rarity: 'rare',
    flavor: '飘在屏幕的光里，触手末端各挂着一颗没保存的星星。',
    art: [
      '   ✧ ◠ ✧',
      '  ( ˚ ᵕ ˚ )',
      '   ⌇ ⌇ ⌇',
      '   ˚  ⋆ ˚',
    ],
  },

  // ---- 传说（各有各的出现条件，图鉴只留谣传） ----
  nullnight: {
    zh: '零点误魔', en: 'Nullnight', habitat: 'myth', rarity: 'legendary',
    hint: '谣传：深夜的报错声会引来一位不速之客。',
    flavor: '深夜报错的化身。它不制造事故，只是每次都准时到场。',
    art: [
      '  ▚  ☾  ▞',
      '   (Ø_Ø)',
      '  ⟨⟨ ▒▒ ⟩⟩',
      '    ⌄ ⌄',
    ],
  },
  kilowhale: {
    zh: '千轮鲸', en: 'Kilowhale', habitat: 'myth', rarity: 'legendary',
    hint: '谣传：陪一个 harness 走过足够多的回合，海里会浮起什么。',
    flavor: '每积攒二百五十个回合浮出水面一次，背上驮着所有没写完的会话。',
    art: [
      '   ______',
      '  ⟨ ◕   ⟋⟍~',
      '   ⟍____⟋',
      '    ~ ~ ~',
    ],
  },
  omnikirin: {
    zh: '万象麒', en: 'Omnikirin', habitat: 'myth', rarity: 'legendary',
    hint: '谣传：图鉴收满二十五格的人，才配得上最后一页。',
    flavor: '只肯见集齐前二十五格的收藏家，鳞片上写着整部图鉴。',
    art: [
      '   ϡ  ✧  ϡ',
      '   (˘ ³˘)',
      '  ⟨▞▚▞▚▞⟩',
      '   ⌐|  |⌐',
    ],
  },
}

/** Dex display order: habitat by HABITATS order, then roster order. */
export const DEX_ORDER = Object.keys(SPECIES)

/** Species ids of one habitat, in roster order. */
export function habitatSpecies(habitat) {
  return DEX_ORDER.filter(id => SPECIES[id].habitat === habitat)
}

/** The three starter ids, in the order `/mon start` offers them. */
export const STARTERS = habitatSpecies('trio')

/** Non-legendary count — the bar Omnikirin sets for collectors. */
export const CATCHABLE_BEFORE_MYTH = DEX_ORDER.filter(id => SPECIES[id].rarity !== 'legendary').length
