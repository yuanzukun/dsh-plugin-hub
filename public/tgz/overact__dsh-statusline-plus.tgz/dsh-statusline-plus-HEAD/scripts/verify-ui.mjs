import { execFileSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { mkdir, writeFile } from 'node:fs/promises'
import { join, relative, resolve } from 'node:path'
import { artifacts, excerpt, redact, root } from './verification.mjs'
import { mountFixture, mountResponsiveFixture, uiRequire } from './ui-fixture.mjs'

function options(args) {
  const opts = { panel: 'all', live: false, session: null, service: 'dsh-web', output: null }
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]
    if (arg === '--live') opts.live = true
    else if (['--panel', '--session', '--service', '--output'].includes(arg)) {
      const value = args[++i]
      if (!value || value.startsWith('--')) throw new Error(arg + ' requires a value')
      opts[arg.slice(2)] = value
    } else throw new Error('Unknown option: ' + arg)
  }
  if (!['all', 'cost', 'subagents', 'responsive'].includes(opts.panel)) throw new Error('--panel must be cost, subagents, responsive or all')
  if (opts.live && opts.panel === 'responsive') throw new Error('Responsive verification changes fixture settings and is offline only')
  if (opts.live && !opts.session) throw new Error('--live requires an explicitly selected --session ID')
  return opts
}

function authUrl(service) {
  const provided = process.env.DSH_AUTH_URL
  const journal = provided ? '' : execFileSync('journalctl', ['--user', '-u', service, '--grep', 'https?://(127\\.0\\.0\\.1|localhost):[0-9]+/?\\?token=', '-n', '1', '--no-pager'], { encoding: 'utf8', timeout: 5000 })
  const value = provided || journal.match(/https?:\/\/(?:127\.0\.0\.1|localhost):\d+\/?\?token=[A-Za-z0-9_-]+/g)?.at(-1)
  if (!value) throw new Error('No local DSH login URL found; provide DSH_AUTH_URL in the environment')
  if (!['localhost', '127.0.0.1'].includes(new URL(value).hostname)) throw new Error('Live verification accepts only a local DSH URL')
  return value
}

async function mountLive(page, session) {
  await page.addInitScript(() => {
    let loader
    Object.defineProperty(window, '__ModuleLoader__', { configurable: true, get: () => loader, set(value) {
      loader = value; let create = value.create
      Object.defineProperty(value, 'create', { configurable: true, get: () => (...args) => {
        const result = create.apply(value, args); window.slpModules = result; return result
      }, set(fn) { create = fn } })
    } })
  })
  await page.goto(authUrl(session.service), { waitUntil: 'domcontentloaded' })
  await page.waitForFunction(() => window.slpModules?.entries.loader && window.__ModuleLoader__.mode === 'live', null, { timeout: 30000 })
  await page.waitForFunction(() => !window.slpModules.entries.state.getSnapshot().syncing && window.slpModules.entries.loader.ctx.sessions.list.getSnapshot().phase === 'ready', null, { timeout: 30000 })
  return page.evaluate(async id => {
    const ctx = window.slpModules.entries.loader.ctx
    await ctx.sessions.refresh()
    if (!ctx.sessions.list.getSnapshot().ids.includes(id)) throw new Error('Selected session was not found')
    await ctx.sessions.refreshProjections(id)
    const list = ctx.sessions.list.getSnapshot(), values = list.projectionsBySession[id]?.values || list.byId[id]?.projectionValues || {}
    const ui = ctx.uiWorkspace || ctx.get('uiWorkspace')
    if (typeof ui?.openSession !== 'function') throw new Error('Native session navigation is unavailable')
    ui.openSession(id)
    return { hasCosts: !!values.statuslineMetrics?.session?.pricedMessages,
      subagents: Array.isArray(values.subagentCatalog) ? values.subagentCatalog.length : 0 }
  }, session.session)
}

async function geometry(page, panel, maxWidth) {
  // Wait for the final animation frame and the native responsive layout.
  await panel.evaluate(node => new Promise(resolveDone => {
    const animations = node.getAnimations(); Promise.all(animations.map(animation => animation.finished.catch(() => {}))).then(resolveDone)
  }))
  await page.waitForFunction(selector => {
    const node = document.querySelector(selector), box = node?.getBoundingClientRect()
    return box && box.left >= 0 && box.right <= innerWidth && node.contains(document.elementFromPoint(box.left + 8, box.top + 18))
  }, await panel.getAttribute('class').then(classes => '.' + classes.split(' ').join('.')))
  const box = await panel.boundingBox()
  if (!box || box.width > maxWidth + 2 || box.height > 360) throw new Error('Panel is no longer compact')
  return { width: Math.round(box.width), height: Math.round(box.height) }
}

async function verifyCost(page, folder, live) {
  const trigger = page.locator('.slp-cost-trigger').first()
  await trigger.waitFor(); await trigger.click()
  const panel = page.locator('.slp-cost-panel').first()
  await panel.waitFor()
  if (!/\d\.\d{2}/.test(await trigger.textContent())) throw new Error('Missing two-decimal reference amount')
  const rows = panel.locator('tbody tr')
  const rowCount = await rows.count()
  if (rowCount < 3) throw new Error('Missing Input/Cache/Output breakdown')
  const tokens = await panel.locator('.slp-cost-tokens').allTextContents()
  if (tokens.length < 3 || tokens.some(text => !/^\d+(?:\.\d+)?[KM]$/.test(text))) throw new Error('Missing compact token counts; an older Host may need reloading')
  const proportions = await panel.locator('.slp-cost-bar').evaluateAll(bars => bars.map(bar => [...bar.children].reduce((sum, child) => sum + parseFloat(child.style.width), 0)))
  if (proportions.some(total => total !== 0 && Math.abs(total - 100) > 0.01)) throw new Error('Cost bar proportions do not sum to 100%')
  if (!live) {
    if (tokens.join('|') !== '12K|1M|0.2K') throw new Error('Token formatting differs from settled counts')
    const text = (await rows.allInnerTexts()).join(' ')
    if (!['Input', 'Cache', 'Output', '$2.00', '$3.00', '$5.00', '20%', '30%', '50%'].every(value => text.includes(value))) throw new Error('Missing component fees or shares')
  }
  await page.setViewportSize({ width: 390, height: 844 })
  const size = await geometry(page, panel, 250)
  const screenshot = join(folder, 'cost.png')
  await panel.screenshot({ path: screenshot, animations: 'disabled' })
  await trigger.click()
  return { panel: 'cost', ...size, rows: rowCount, screenshot: relative(root, screenshot) }
}

async function verifySubagents(page, folder, live, count) {
  if (live && count === 0) return { panel: 'subagents', skipped: 'Selected session has no subagents' }
  const trigger = page.locator('.slp-activity .slp-activity-trigger').first()
  await trigger.waitFor(); await trigger.click()
  const panel = page.locator('.slp-subagent-panel').first()
  await panel.waitFor()
  const size = await geometry(page, panel, 280)
  const model = panel.locator('.slp-subagent-model').first(), effort = panel.locator('.slp-subagent-effort').first()
  if (await effort.count()) {
    const m = await model.boundingBox(), e = await effort.boundingBox()
    if (m && e && e.x - m.x - m.width > 10) throw new Error('Reasoning effort is too far from the model')
  }
  const screenshot = join(folder, 'subagents.png')
  await panel.screenshot({ path: screenshot, animations: 'disabled' }); await trigger.click()
  if (!live) {
    const expect = label => page.waitForFunction(value => document.querySelector('.slp-activity .slp-activity-trigger')?.textContent === value, label)
    await expect('Subagents 0/2')
    await page.evaluate(() => window.setChildRunning(0, false)); await expect('Subagents 1/2')
    await page.clock.runFor(15000); await expect('Subagents 1/2')
    await page.evaluate(() => window.setChildRunning(1, false)); await expect('Subagents 2/2')
    await page.clock.runFor(5000)
    await page.waitForFunction(() => document.querySelector('.slp-activity .slp-activity-trigger')?.style.opacity === '0.6')
    await page.clock.runFor(10000)
    await page.waitForFunction(() => !document.querySelector('.slp-activity .slp-activity-trigger'))
    await page.evaluate(() => window.setChildRunning(0, true)); await expect('Subagents 1/2')
  }
  return { panel: 'subagents', ...size, lifecycle: live ? 'read-only snapshot' : 'progress/expiry/resumption passed', screenshot: relative(root, screenshot) }
}

async function verifyResponsive(page, folder) {
  await page.setViewportSize({ width: 390, height: 844 })
  await mountResponsiveFixture(page)
  const toggle = page.getByRole('checkbox', { name: 'Hide bottom status line on narrow screens', exact: true })
  const dock = page.locator('#fixture-dock .slp-root')
  const assertResources = async (open, total) => {
    await page.waitForFunction(({ open, total }) => {
      const state = window.slpResponsive
      return state.sources.filter(source => !source.closed).length === open &&
        state.gitRequests.length === total && state.gitRequests.filter(request => !request.aborted).length === open
    }, { open, total })
  }
  await toggle.waitFor()
  if (!await toggle.isChecked() || await dock.count()) throw new Error('Stored preference did not suppress the initial narrow dock')
  await assertResources(0, 0)
  await page.locator('#fixture-header .slp-quota-with-age').waitFor()
  await page.locator('#fixture-footer .slp-peak-dot-btn').waitFor()
  // A failed refresh recovers without activity, with exactly three retries.
  const quota = page.locator('#fixture-header .slp-quota-trigger')
  const quotaCount = count => page.waitForFunction(expected => window.slpResponsive.quotaRequests.length === expected, count)
  await quotaCount(1)
  await page.evaluate(() => { window.slpResponsive.quotaFailures = 4 })
  // Opening details no longer bypasses the cache; the explicit Refresh button does.
  await quota.click()
  await page.locator('.slp-panel .slp-link-btn').first().click()
  await quotaCount(2)
  await page.locator('#fixture-header .slp-err').waitFor()
  for (const [index, delay] of [15000, 30000, 60000].entries()) {
    await page.clock.runFor(delay); await quotaCount(index + 3)
  }
  await page.clock.runFor(120000); await quotaCount(5)
  if (!(await quota.getAttribute('title')).includes('Automatic retries exhausted')) throw new Error('Retry exhaustion was not explained while retaining successful data')
  const retryBodies = await page.evaluate(() => window.slpResponsive.quotaRequests.slice(2).map(request => JSON.parse(request.body)))
  if (retryBodies.some(body => body.force)) throw new Error('Automatic retries bypassed Host backoff')
  await page.evaluate(() => window.dispatchEvent(new Event('focus')))
  await quotaCount(6)
  await page.locator('#fixture-header .slp-err').waitFor({ state: 'detached' })
  if (!(await quota.innerText()).includes('20%')) throw new Error('Focus recovery did not restore the quota')
  await page.evaluate(() => window.dispatchEvent(new Event('focus')))
  await quotaCount(6)
  await page.keyboard.press('Escape')
  await page.setViewportSize({ width: 481, height: 844 })
  await dock.waitFor(); await assertResources(1, 1)
  await page.setViewportSize({ width: 480, height: 844 })
  await dock.waitFor({ state: 'detached' }); await assertResources(0, 1)
  await page.setViewportSize({ width: 320, height: 844 })
  await page.clock.runFor(2000); await assertResources(0, 1)
  if (!await page.locator('#fixture-header .slp-quota-with-age').isVisible() ||
      !await page.locator('#fixture-footer .slp-peak-dot-btn').isVisible() ||
      !await page.locator('#fixture-native').isVisible()) throw new Error('Hiding the dock affected other UI')
  await toggle.uncheck(); await page.clock.runFor(700)
  await dock.waitFor(); await assertResources(1, 2)
  await toggle.check(); await page.clock.runFor(700)
  await dock.waitFor({ state: 'detached' }); await assertResources(0, 2)
  await page.evaluate(() => window.slpFixtureRoot.unmount())
  await page.waitForFunction(() => window.slpResponsive.observers.every(observer => observer.closed))
  await page.evaluate(() => window.remountResponsiveFixture())
  await toggle.waitFor()
  if (!await toggle.isChecked() || await dock.count()) throw new Error('Setting was not retained on remount')
  await assertResources(0, 2)
  // The update affordance: named after the new version, installed on one click,
  // and it reports the live swap the page detects through the instance id. The
  // fixture records the request instead of running pnpm.
  const updateButton = page.locator('.slp-update')
  await updateButton.waitFor()
  if (!(await updateButton.innerText()).includes('9.9.9')) throw new Error('Update button did not name the new version')
  await updateButton.click()
  await page.waitForFunction(() => document.querySelector('.slp-update')?.textContent?.includes('Refresh'), null, { timeout: 15000 })
  const updateBodies = await page.evaluate(() => window.slpResponsive.updateRequests)
  if (updateBodies.length !== 1 || updateBodies[0].version !== '9.9.9') throw new Error('Update request was not sent exactly once')
  if (await updateButton.isDisabled()) throw new Error('Update stopped being clickable before the page could refresh')
  const screenshot = join(folder, 'responsive-settings.png')
  await page.locator('.slp-set').screenshot({ path: screenshot, animations: 'disabled' })
  await page.setViewportSize({ width: 768, height: 844 })
  await dock.waitFor(); await assertResources(1, 3)
  // A sidebar can narrow the input area without narrowing the browser viewport.
  await page.locator('#fixture-dock').evaluate(node => { node.style.width = '480px' })
  await dock.waitFor({ state: 'detached' }); await assertResources(0, 3)
  if (!await page.locator('#fixture-native').isVisible()) throw new Error('Container suppression hid native stats')
  await page.locator('#fixture-dock').evaluate(node => { node.style.width = '481px' })
  await dock.waitFor(); await assertResources(1, 4)
  await page.evaluate(() => window.disposeResponsiveFixture())
  await assertResources(0, 4)
  await page.waitForFunction(() => window.slpResponsive.observers.every(observer => observer.closed))
  return { panel: 'responsive', widths: [320, 390, 480, 481, 768],
    lifecycle: 'three retries/exhaustion hint/focus recovery/container suppression/native stats/settings save/remount/resource cleanup passed', screenshot: relative(root, screenshot) }
}

let browser, folder
try {
  const opts = options(process.argv.slice(2)), errors = [], started = performance.now()
  folder = opts.output ? resolve(root, opts.output) : await artifacts('output/playwright/ui')
  await mkdir(folder, { recursive: true })
  let chromium
  try { ({ chromium } = uiRequire('playwright')) } catch { throw new Error('UI dependencies are missing; run npm run ui:install') }
  const executablePath = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || (existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined)
  browser = await chromium.launch({ headless: true, ...(executablePath ? { executablePath } : {}) })
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } })
  page.setDefaultTimeout(8000)
  page.on('pageerror', error => errors.push(redact(error.message)))
  let network = 0
  page.on('request', request => { if (/^https?:/.test(request.url())) network++ })
  const data = opts.live ? await mountLive(page, opts) : opts.panel === 'responsive' ? {} : (await mountFixture(page), { hasCosts: true, subagents: 2 })
  const checks = []
  if (['all', 'cost'].includes(opts.panel)) {
    if (!data.hasCosts) throw new Error('Selected session has no priced usage')
    checks.push(await verifyCost(page, folder, opts.live))
  }
  if (['all', 'subagents'].includes(opts.panel)) checks.push(await verifySubagents(page, folder, opts.live, data.subagents))
  if (!opts.live && ['all', 'responsive'].includes(opts.panel)) checks.push(await verifyResponsive(page, folder))
  else if (!opts.live) await page.evaluate(() => window.slpFixtureRoot.unmount())
  if (errors.length || !opts.live && network) throw new Error(errors.join('; ') || 'Offline fixture made a network request')
  if (opts.live && await page.evaluate(() => window.slpModules.entries.state.getSnapshot().failures.length)) throw new Error('Native module loader reported failures')
  const report = { ok: true, mode: opts.live ? 'live' : 'fixture', durationMs: Math.round(performance.now() - started), checks, errors: 0 }
  await writeFile(join(folder, 'ui-report.json'), JSON.stringify(report, null, 2))
  console.log(JSON.stringify(report))
} catch (error) {
  const report = { ok: false, error: excerpt(error.message) }
  if (folder) await writeFile(join(folder, 'ui-report.json'), JSON.stringify(report, null, 2))
  console.log(JSON.stringify(report)); process.exitCode = 1
} finally { await browser?.close() }
