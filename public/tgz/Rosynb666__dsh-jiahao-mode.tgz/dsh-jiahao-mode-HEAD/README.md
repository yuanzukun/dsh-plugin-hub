# 嘉豪模式 · Jiahao Mode

> 让 DeepSeek Harness（DSH）变成一个玩威龙的绝活哥：活要干对，但每一步都要「豪」出声。
>
> 非官方粉丝项目，与腾讯、琳琅天上、《三角洲行动》官方无关，非商业用途。

**状态**：v0.4 · 人设注入 + 三档切换 + 人设互斥 + 豪气值 + 击杀播报 + 结算卡 + 四条命令 + 生涯战绩。

---

## 这是什么

嘉豪模式是一个 DSH 人设/行为插件：它不改变交付标准，只改变「做事的方式」和「说话的味道」。

| 层 | v0.1 状态 | 内容 |
| --- | --- | --- |
| 行为准则 | ✅ 已实现 | 接活「我累铜泥丸」／开打「往里豪」／打输「卡了」／打赢「我从来都没虚」 |
| 嘴臭分档 | ✅ 已实现 | 屏息 / 小声豪 / 放开豪，只改说话密度，不改验收标准 |
| 人设互斥 | ✅ 已实现 | 与其它人设（含鲸鱼娘）互斥，可切换成叠加 |
| 豪气值 | ✅ 已实现 | 面板、连杀、战绩，数据来自 session 事件 |
| 击杀播报 / 结算卡 | ✅ 已实现 | 面板内滚动播报 + 回合结算卡 |
| 命令与战绩 | ✅ 已实现 | `/advance` `/lagged` `/niwan` `/career` |

## 安装

v0.1 可以直接从 GitHub 装（把 `<owner>` 换成仓库所有者）：

```bash
dsh plugin --profile desktop add github:<owner>/dsh-jiahao-mode
```

或者用本地包：

```bash
dsh plugin --profile desktop add /path/to/dsh-jiahao-mode
```

装完刷新页面；卸载：

```bash
dsh plugin --profile desktop remove dsh-jiahao-mode
```

## 配置

三个开关都在 DSH 设置里，改完即时生效（volatile 配置，不用重启插件）：

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `enabled` | `true` | 总开关，关掉后不注入任何人设 |
| `tone` | `normal` | 嘴臭档位：`quiet`（屏息）/ `normal`（小声豪）/ `loud`（放开豪） |
| `exclusive` | `true` | 与其它人设互斥；设为 `false` 则叠加 |

**互斥是软互斥**：v0.1 不会去关别的插件，而是在本段里声明优先级——「若上文存在其它人设，以嘉豪模式为准」。关掉本模式后，其它人设自然恢复。

## 面板

装好后右上角出现「嘉豪 · 突击」面板，点标题栏可折叠：

- 豪气值：成功 +6、失败 −10、连续只读再扣静步分，范围 0–100
- 档位切换：面板里三颗按钮（屏息 / 小声豪 / 放开豪），点了立刻生效
- 击杀 / 卡了 / 连杀 / 最佳连杀
- 播报：成功与失败各一条，最多留 6 条
- 结算卡：每个回合结束弹一次，评 S/A/B/C，自动消失

数据来自 Host 的 `/jiahao/api/state`，客户端每 1.5 秒拉一次；接口挂了只是面板不动，不影响会话。

## 命令

DSH 的命令名只允许 ASCII（`^[a-z][a-z0-9_-]*$`），所以中文名只做显示别名：

| 命令 | 中文叫法 | 作用 |
| --- | --- | --- |
| `/advance [n]` | 推进 | 往当前会话注入「跳过调研、直接改」的指令，默认 3 步 |
| `/lagged` | 卡了 | 清掉连杀位，注入「立刻真实重试」的指令 |
| `/niwan` | 铜泥丸 | 报出当前豪气值与战绩 |
| `/career` | 战绩 | 跨会话生涯数据 |

生涯写在 `~/.dsh/jiahao-mode/career.json`，每回合结算后累加；面板底部也会显示一行。

## 开发

```bash
npm test          # 纯函数单测：人设正文、档位、互斥、配置归一化
```

目录：

```
lib/persona.mjs     人设正文构建（纯函数，可单测）
lib/index.mjs       Cordis 插件：注册 jiahao:mode 段 + volatile 配置
cordis.patch.yml    profile 补丁层
docs/               设计文档 v1.6
```

## 文档

- [设计文档 v1.6（中文，Word）](docs/嘉豪模式-设计文档-v1.6.docx)

## 仓库原则

- 不含任何游戏美术资源、角色立绘、游戏截图或官方 logo。
- 不修改上游 DSH；卸载后不残留状态。
- 所有提示词注入都可关闭，且不改动验收标准。

## 免责声明

本项目是《三角洲行动》玩家社区的二创作品，仅供学习与娱乐。文中出现的游戏名称、干员名、武器名、口头禅等均归其权利人所有，本项目与官方无任何关联，也不代表官方立场。请勿用于商业用途。

## 许可

代码与文档以 [MIT](LICENSE) 授权；第三方名称与商标不在此授权范围内。

---

## English

Jiahao Mode is a fan-made persona plugin for DeepSeek Harness. v0.2 ships the host-side persona (four behavior rules, three tone levels, persona exclusion) plus a HUD with a "Hao" score, a kill feed and a round-settle card. No game assets, screenshots, or official logos are included.
