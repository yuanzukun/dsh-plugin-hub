# Security Policy

## Supported version

安全修复面向默认分支上的最新版本。使用旧标签的用户应先升级并确认问题是否仍然存在。

## Reporting a vulnerability

请不要在公开 Issue 中提交 App Secret、访问令牌、飞书消息内容、用户 `open_id` 或工作区文件。请通过 GitHub 仓库所有者的公开联系方式私下报告安全问题，并提供最小化的复现步骤、影响范围和版本信息。

## Deployment guidance

- 将飞书凭据保存在 DSH 凭据文件中，不要写入仓库或插件配置。
- 保持 `allowedOpenIds` 默认拒绝策略，并至少配置一名可信管理员。
- 将 `workspace` 指向专用目录，避免让机器人访问不相关文件。
- 为任务设置合理超时和文件大小上限，并定期审计动态授权列表。
