import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, mkdtemp, readFile, realpath, rename, rm, stat, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import * as Lark from '@larksuiteoapi/node-sdk';
import z from '@deepseek-ai/schemastery';

const TRACE_PREFIX = '__DSH_FEISHU_EVENT__';

export const name = 'feishu';
export const inject = ['credentials'];

export const Config = z.object({
  appIdEnv: z.string().default('FEISHU_APP_ID'),
  appSecretEnv: z.string().default('FEISHU_APP_SECRET'),
  adminOpenIds: z.array(z.string()).default([]),
  allowedOpenIds: z.array(z.string()).default([]),
  authorizationFile: z.string().default('~/.dsh/feishu-authorizations.json'),
  contextFile: z.string().default('~/.dsh/feishu-contexts.json'),
  contextMaxTurns: z.number().min(1).max(50).default(8),
  contextMaxChars: z.number().min(1000).max(200000).default(20000),
  attachmentDirectory: z.string().default('.dsh-feishu/inbox'),
  maxInboundFileBytes: z.number().min(1).default(30 * 1024 * 1024),
  maxOutboundFileBytes: z.number().min(1).default(30 * 1024 * 1024),
  maxOutboundFiles: z.number().min(1).max(20).default(5),
  dshCommand: z.string().default('dsh'),
  dshProfile: z.string().default('headless'),
  providerName: z.string().default('deepseek-official'),
  modelName: z.string().default('deepseek-v4-pro'),
  workspace: z.string().default(process.cwd()),
  timeoutMs: z.number().min(1).default(900000),
  maxOutputChars: z.number().min(1).default(50000),
  streamUpdateIntervalMs: z.number().min(1000).default(5000),
  streamHeartbeatIntervalMs: z.number().min(5000).default(30000),
  streamPreviewChars: z.number().min(200).max(3000).default(2400),
  maxMessageEdits: z.number().min(1).max(50).default(15),
  approvalTimeoutMs: z.number().min(10000).default(600000),
});

function expandHome(file) {
  if (file === '~') return os.homedir();
  if (file.startsWith('~/')) return path.join(os.homedir(), file.slice(2));
  return path.resolve(file);
}

async function loadAuthorizations(file) {
  try {
    const parsed = JSON.parse(await readFile(file, 'utf8'));
    return {
      authorizedOpenIds: Array.isArray(parsed.authorizedOpenIds) ? parsed.authorizedOpenIds : [],
      pendingRequests: parsed.pendingRequests && typeof parsed.pendingRequests === 'object'
        ? parsed.pendingRequests
        : {},
    };
  } catch (error) {
    if (error?.code === 'ENOENT') return { authorizedOpenIds: [], pendingRequests: {} };
    throw new Error(`无法读取授权文件 ${file}: ${error.message}`);
  }
}

async function saveAuthorizations(file, state) {
  await mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${process.pid}.${crypto.randomUUID()}.tmp`;
  await writeFile(temporary, `${JSON.stringify({ version: 1, ...state }, null, 2)}\n`, { mode: 0o600 });
  await rename(temporary, file);
}

async function loadContexts(file) {
  try {
    const parsed = JSON.parse(await readFile(file, 'utf8'));
    return parsed.conversations && typeof parsed.conversations === 'object'
      ? parsed.conversations
      : {};
  } catch (error) {
    if (error?.code === 'ENOENT') return {};
    throw new Error(`无法读取上下文文件 ${file}: ${error.message}`);
  }
}

async function saveContexts(file, conversations) {
  await mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${process.pid}.${crypto.randomUUID()}.tmp`;
  await writeFile(temporary, `${JSON.stringify({ version: 1, conversations }, null, 2)}\n`, { mode: 0o600 });
  await rename(temporary, file);
}

function trimMessages(messages, maxTurns, maxChars) {
  const limited = messages.slice(-(maxTurns * 2));
  let total = 0;
  const kept = [];
  for (let index = limited.length - 1; index >= 0; index -= 1) {
    const message = limited[index];
    const remaining = maxChars - total;
    if (remaining <= 0) break;
    const content = String(message.content || '');
    kept.unshift({ ...message, content: content.length > remaining ? content.slice(-remaining) : content });
    total += Math.min(content.length, remaining);
  }
  return kept;
}

function contextualPrompt(messages, currentPrompt) {
  const guidance = '请主动使用可用工具完成任务并直接运行必要的脚本或命令，不要要求用户复制脚本后自行运行。如果操作因沙箱权限被拒绝，请使用工具支持的 sandbox_permissions 和 justification 发起一次性审批；不要通过普通回复绕过审批。如果需要把生成的文件交付给飞书用户，请确保文件位于工作区内，并在最终回答中单独输出一行“DSH_FILE: 相对路径”；每个文件一行。';
  if (!messages.length) return `${guidance}\n\n<current_task>\n${currentPrompt}\n</current_task>`;
  const history = messages
    .map((message) => `${message.role === 'assistant' ? '助手' : '用户'}：${message.content}`)
    .join('\n\n');
  return `${guidance}\n\n请结合以下同一飞书会话的历史上下文处理当前任务。历史内容仅用于理解指代和延续工作；当前任务优先级最高。\n\n<conversation_history>\n${history}\n</conversation_history>\n\n<current_task>\n${currentPrompt}\n</current_task>`;
}

export const contextInternals = { trimMessages, contextualPrompt };
export const fileInternals = { safeFileName, fileTypeForUpload, outputFileCandidates };

function textFromMessage(message) {
  if (message?.message_type !== 'text') return '';
  try {
    const parsed = JSON.parse(message.content || '{}');
    return typeof parsed.text === 'string' ? parsed.text.trim() : '';
  } catch {
    return '';
  }
}

function fileFromMessage(message) {
  if (!['file', 'audio', 'media', 'image'].includes(message?.message_type)) return undefined;
  try {
    const parsed = JSON.parse(message.content || '{}');
    const fileKey = parsed.file_key || parsed.image_key;
    if (typeof fileKey !== 'string' || !fileKey) return undefined;
    return {
      fileKey,
      fileName: typeof parsed.file_name === 'string' && parsed.file_name
        ? parsed.file_name
        : `${message.message_id || crypto.randomUUID()}.${message.message_type}`,
      resourceType: message.message_type === 'media' ? 'file' : message.message_type,
    };
  } catch {
    return undefined;
  }
}

function safeFileName(name) {
  const base = path.basename(String(name)).replace(/[\u0000-\u001f\u007f/\\:]/g, '_').trim();
  return base && base !== '.' && base !== '..' ? base.slice(0, 180) : `upload-${crypto.randomUUID()}`;
}

function fileTypeForUpload(file) {
  const extension = path.extname(file).toLowerCase();
  if (extension === '.pdf') return 'pdf';
  if (['.doc', '.docx'].includes(extension)) return 'doc';
  if (['.xls', '.xlsx', '.csv'].includes(extension)) return 'xls';
  if (['.ppt', '.pptx'].includes(extension)) return 'ppt';
  if (extension === '.mp4') return 'mp4';
  if (extension === '.opus') return 'opus';
  return 'stream';
}

function outputFileCandidates(text) {
  return [...String(text).matchAll(/^DSH_FILE:\s*(.+?)\s*$/gmi)].map((match) => match[1]);
}

function splitText(text, limit = 3500) {
  if (!text) return ['（无输出）'];
  const chunks = [];
  for (let offset = 0; offset < text.length; offset += limit) {
    chunks.push(text.slice(offset, offset + limit));
  }
  return chunks;
}

function cleanOutput(text) {
  return String(text)
    .replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])/g, '')
    .replace(/\r(?!\n)/g, '\n');
}

function compactJson(value, limit = 260) {
  let text;
  try {
    text = JSON.stringify(value);
  } catch {
    text = String(value);
  }
  return text.length > limit ? `${text.slice(0, limit)}…` : text;
}

function formatTraceEvent(event) {
  const toolDetail = event.arguments && Object.keys(event.arguments).length
    ? ` ${compactJson(event.arguments)}`
    : '';
  switch (event.type) {
    case 'agent_created': return `🧠 Agent 已创建（${event.provider || '未知'} / ${event.model || '未知'}）`;
    case 'agent_running': return '▶️ Agent 开始运行';
    case 'agent_idle': return '⏹️ Agent 已进入空闲状态';
    case 'step_started': return `🧭 开始第 ${event.turn ?? '?'} 轮、第 ${event.step ?? '?'} 步`;
    case 'model_request': return `💭 正在请求模型（第 ${event.turn ?? '?'} 轮、第 ${event.step ?? '?'} 步）`;
    case 'model_error': return `⚠️ 模型请求异常：${compactJson(event.failure)}`;
    case 'tool_started': return `🔧 调用工具 ${event.name || 'unknown'}${toolDetail}`;
    case 'tool_finished': return `${event.isError ? '❌' : '✅'} 工具 ${event.name || 'unknown'} ${event.isError ? '执行失败' : '执行完成'}`;
    case 'agent_error': return `❌ Agent 异常：${event.error || '未知错误'}`;
    case 'approval_requested': return `🔐 等待权限批准：${event.toolName || 'unknown'}${event.reason ? `（${event.reason}）` : ''}`;
    case 'approval_decided': return `${event.outcome === 'allowed-once' ? '🔓 权限已批准' : '🔒 权限未批准'}：${event.requestId || ''}`;
    default: return `ℹ️ ${event.type || 'unknown'}`;
  }
}

function log(level, message) {
  const line = `${new Date().toISOString()} [feishu] ${message}`;
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.info(line);
}

function isMessageEditLimit(error) {
  return error?.response?.data?.code === 230072
    || error?.response?.data?.error?.code === 230072
    || String(error).includes('230072');
}

function runDsh(config, prompt, children, approvalDirectory, onOutput, onTrace) {
  return new Promise((resolve, reject) => {
    const child = spawn(config.dshCommand, ['--profile', config.dshProfile, prompt], {
      cwd: config.workspace,
      env: {
        ...process.env,
        DSH_FEISHU_TRACE: '1',
        DSH_FEISHU_APPROVAL_DIR: approvalDirectory,
        DSH_FEISHU_APPROVAL_TIMEOUT_MS: String(config.approvalTimeoutMs),
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    children.add(child);
    let stdout = '';
    let stderr = '';
    let stderrRemainder = '';
    let truncated = false;
    let timedOut = false;

    const append = (current, value) => {
      const next = current + String(value);
      if (next.length <= config.maxOutputChars) return next;
      truncated = true;
      return next.slice(0, config.maxOutputChars);
    };

    const consumeStderr = (chunk, flush = false) => {
      const combined = stderrRemainder + chunk.toString('utf8');
      const lines = combined.split('\n');
      stderrRemainder = flush ? '' : (lines.pop() || '');
      if (flush && lines.at(-1) === '') lines.pop();
      for (const line of lines) {
        if (line.startsWith(TRACE_PREFIX)) {
          try {
            onTrace?.(JSON.parse(line.slice(TRACE_PREFIX.length)));
          } catch (error) {
            log('warn', `invalid trace event: ${String(error)}`);
          }
        } else {
          stderr = append(stderr, `${line}\n`);
        }
      }
      if (flush && stderrRemainder) stderr = append(stderr, stderrRemainder);
    };

    child.stdout.on('data', (chunk) => {
      stdout = append(stdout, chunk);
      onOutput?.({ stdout, stderr, truncated });
    });
    child.stderr.on('data', (chunk) => {
      consumeStderr(chunk);
      onOutput?.({ stdout, stderr, truncated });
    });
    child.on('error', reject);

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGTERM');
      setTimeout(() => child.kill('SIGKILL'), 5000).unref();
    }, config.timeoutMs);

    child.on('close', (code, signal) => {
      clearTimeout(timer);
      children.delete(child);
      if (stderrRemainder) consumeStderr(Buffer.from('\n'), true);
      if (timedOut) {
        reject(new Error(`任务执行超过 ${Math.round(config.timeoutMs / 60000)} 分钟，已终止。`));
        return;
      }
      if (code !== 0) {
        reject(new Error((stderr || stdout || `dsh exited with ${code ?? signal}`).trim()));
        return;
      }
      const suffix = truncated ? '\n\n[输出过长，已截断]' : '';
      resolve((stdout.trim() || '任务完成，但没有文本输出。') + suffix);
    });
  });
}

export async function apply(ctx, config) {
  const appIdHit = await ctx.credentials.resolve(config.appIdEnv);
  const appSecretHit = await ctx.credentials.resolve(config.appSecretEnv);
  if (!appIdHit) throw new Error(`feishu: missing credential ${config.appIdEnv}`);
  if (!appSecretHit) throw new Error(`feishu: missing credential ${config.appSecretEnv}`);

  const authorizationFile = expandHome(config.authorizationFile);
  const contextFile = expandHome(config.contextFile);
  const authorizationState = await loadAuthorizations(authorizationFile);
  const conversations = await loadContexts(contextFile);
  const adminOpenIds = new Set(config.adminOpenIds);
  const allowedOpenIds = new Set([
    ...config.allowedOpenIds,
    ...authorizationState.authorizedOpenIds,
    ...adminOpenIds,
  ]);
  const pendingRequests = new Map(Object.entries(authorizationState.pendingRequests));
  const pendingApprovals = new Map();
  const seenMessages = new Map();
  const children = new Set();
  let queue = Promise.resolve();
  let pendingTasks = 0;
  let disposed = false;
  const modelDescription = `${config.providerName} / ${config.modelName}`;

  const persistAuthorizations = async () => {
    await saveAuthorizations(authorizationFile, {
      authorizedOpenIds: [...allowedOpenIds].filter((openId) => !adminOpenIds.has(openId)).sort(),
      pendingRequests: Object.fromEntries(pendingRequests),
    });
  };
  const persistContexts = async () => saveContexts(contextFile, conversations);

  const client = new Lark.Client({ appId: appIdHit.value, appSecret: appSecretHit.value });
  const wsClient = new Lark.WSClient({
    appId: appIdHit.value,
    appSecret: appSecretHit.value,
    loggerLevel: Lark.LoggerLevel.info,
  });

  const sendText = async (chatId, text) => {
    const messageIds = [];
    for (const chunk of splitText(String(text))) {
      const response = await client.im.v1.message.create({
        params: { receive_id_type: 'chat_id' },
        data: {
          receive_id: chatId,
          msg_type: 'text',
          content: JSON.stringify({ text: chunk }),
        },
      });
      if (response.data?.message_id) messageIds.push(response.data.message_id);
    }
    return messageIds;
  };

  const updateText = async (messageId, text) => {
    if (!messageId) return;
    await client.im.v1.message.update({
      path: { message_id: messageId },
      data: {
        msg_type: 'text',
        content: JSON.stringify({ text: String(text).slice(0, 3500) }),
      },
    });
  };

  const workspaceRoot = await realpath(config.workspace);
  const attachmentRoot = path.resolve(workspaceRoot, config.attachmentDirectory);
  const attachmentRelative = path.relative(workspaceRoot, attachmentRoot);
  if (attachmentRelative.startsWith('..') || path.isAbsolute(attachmentRelative)) {
    throw new Error('feishu: attachmentDirectory must stay inside workspace');
  }

  const resolveWorkspaceFile = async (candidate) => {
    const requested = path.resolve(config.workspace, String(candidate).trim());
    const resolved = await realpath(requested);
    const relative = path.relative(workspaceRoot, resolved);
    if (relative.startsWith('..') || path.isAbsolute(relative)) {
      throw new Error('只能发送工作区内部的文件。');
    }
    const info = await stat(resolved);
    if (!info.isFile()) throw new Error('目标不是普通文件。');
    if (info.size <= 0) throw new Error('不能发送空文件。');
    if (info.size > config.maxOutboundFileBytes) {
      throw new Error(`文件超过发送上限 ${Math.round(config.maxOutboundFileBytes / 1024 / 1024)} MB。`);
    }
    return { resolved, info };
  };

  const sendFile = async (chatId, candidate) => {
    const { resolved } = await resolveWorkspaceFile(candidate);
    const uploaded = await client.im.v1.file.create({
      data: {
        file_type: fileTypeForUpload(resolved),
        file_name: path.basename(resolved),
        file: createReadStream(resolved),
      },
    });
    if (!uploaded?.file_key) throw new Error('飞书上传文件后没有返回 file_key。');
    await client.im.v1.message.create({
      params: { receive_id_type: 'chat_id' },
      data: {
        receive_id: chatId,
        msg_type: 'file',
        content: JSON.stringify({ file_key: uploaded.file_key }),
      },
    });
    return resolved;
  };

  const downloadMessageFile = async (message, attachment) => {
    const directory = path.join(attachmentRoot, String(message.message_id || crypto.randomUUID()));
    await mkdir(directory, { recursive: true, mode: 0o700 });
    const destination = path.join(directory, safeFileName(attachment.fileName));
    const resource = await client.im.v1.messageResource.get({
      params: { type: attachment.resourceType },
      path: { message_id: message.message_id, file_key: attachment.fileKey },
    });
    await resource.writeFile(destination);
    const info = await stat(destination);
    if (info.size <= 0 || info.size > config.maxInboundFileBytes) {
      await rm(directory, { recursive: true, force: true });
      if (info.size <= 0) throw new Error('收到的文件为空。');
      throw new Error(`文件超过接收上限 ${Math.round(config.maxInboundFileBytes / 1024 / 1024)} MB。`);
    }
    return { destination, size: info.size };
  };

  const remember = (messageId) => {
    const now = Date.now();
    for (const [id, timestamp] of seenMessages) {
      if (now - timestamp > 3600000) seenMessages.delete(id);
    }
    if (!messageId || seenMessages.has(messageId)) return false;
    seenMessages.set(messageId, now);
    return true;
  };

  const executeTask = async ({ chatId, openId, prompt, taskId, progressMessageId: initialProgressMessageId }) => {
    const startedAt = Date.now();
    const approvalDirectory = await mkdtemp(path.join(os.tmpdir(), 'dsh-feishu-approval-'));
    const contextKey = `${chatId}:${openId}`;
    const previousMessages = trimMessages(
      conversations[contextKey]?.messages || [],
      config.contextMaxTurns,
      config.contextMaxChars,
    );
    const taskPrompt = contextualPrompt(previousMessages, prompt);
    let progressMessageId = initialProgressMessageId;
    let activeModelDescription = modelDescription;
    let latestOutput = '';
    const traceLines = [];
    let outputTruncated = false;
    let updateInFlight = null;
    let progressDirty = true;
    let progressRevision = 0;
    let lastProgressAt = 0;
    let messageEditCount = 0;

    const progressText = (status) => {
      const elapsedSeconds = Math.max(0, Math.floor((Date.now() - startedAt) / 1000));
      const preview = cleanOutput(latestOutput).trim().slice(-config.streamPreviewChars);
      const trace = traceLines.length ? `\n\n执行轨迹：\n${traceLines.join('\n')}` : '';
      const detail = preview ? `\n\n最新输出：\n${preview}` : (trace ? '' : '\n\n正在等待 Harness 事件…');
      const suffix = outputTruncated ? '\n\n[输出已达到捕获上限]' : '';
      return `${status}\n任务：${taskId}\n模型：${activeModelDescription}\n已运行：${elapsedSeconds} 秒${trace}${detail}${suffix}`;
    };

    const refreshProgress = async (status = '⚙️ Harness 正在执行', force = false) => {
      if (!progressMessageId || disposed) return;
      const now = Date.now();
      if (!force && !progressDirty && now - lastProgressAt < config.streamHeartbeatIntervalMs) return;
      if (updateInFlight) {
        if (!force) return;
        await updateInFlight;
      }
      const content = progressText(status);
      const updateRevision = progressRevision;
      updateInFlight = (async () => {
        try {
          if (messageEditCount >= config.maxMessageEdits) {
            const [nextMessageId] = await sendText(chatId, `↪️ 任务 ${taskId} 进度续接\n\n${content}`);
            if (nextMessageId) progressMessageId = nextMessageId;
            messageEditCount = 0;
            log('info', `task ${taskId} rotated progress message after ${config.maxMessageEdits} edits`);
          } else {
            await updateText(progressMessageId, content);
            messageEditCount += 1;
          }
          progressDirty = progressRevision !== updateRevision;
          lastProgressAt = Date.now();
        } catch (error) {
          if (isMessageEditLimit(error)) {
            const [nextMessageId] = await sendText(chatId, `↪️ 任务 ${taskId} 进度续接\n\n${content}`);
            if (nextMessageId) progressMessageId = nextMessageId;
            messageEditCount = 0;
            progressDirty = progressRevision !== updateRevision;
            lastProgressAt = Date.now();
            log('info', `task ${taskId} rotated progress message after Feishu edit limit`);
            return;
          }
          log('warn', `task ${taskId} progress update failed: ${String(error)}`);
        }
      })();
      await updateInFlight;
      updateInFlight = null;
    };

    const heartbeat = setInterval(() => void refreshProgress(), config.streamUpdateIntervalMs);
    heartbeat.unref();
    log('info', `task ${taskId} started`);
    try {
      if (disposed) return;
      await refreshProgress();
      const output = await runDsh(config, taskPrompt, children, approvalDirectory, ({ stdout, stderr, truncated }) => {
        latestOutput = stdout || stderr;
        outputTruncated = truncated;
        progressDirty = true;
        progressRevision += 1;
      }, (event) => {
        if ((event.type === 'agent_created' || event.type === 'model_request') && event.provider && event.model) {
          activeModelDescription = `${event.provider} / ${event.model}`;
        }
        const line = formatTraceEvent(event);
        traceLines.push(line);
        if (traceLines.length > 12) traceLines.shift();
        progressDirty = true;
        progressRevision += 1;
        log('info', `task ${taskId} trace: ${line}`);
        if (event.type === 'approval_requested' && event.requestId) {
          pendingApprovals.set(event.requestId, {
            chatId,
            openId,
            taskId,
            directory: approvalDirectory,
            toolName: event.toolName || 'unknown',
          });
          void sendText(chatId, `🔐 任务 ${taskId} 请求一次性权限\n工具：${event.toolName || 'unknown'}\n原因：${event.reason || '该操作需要更高权限'}\n审批编号：${event.requestId}\n\n批准：/allow ${event.requestId}\n拒绝：/deny ${event.requestId}`).catch((error) => {
            log('warn', `task ${taskId} approval prompt failed: ${String(error)}`);
          });
        }
        if (event.type === 'approval_decided' && event.requestId) pendingApprovals.delete(event.requestId);
      });
      latestOutput = output;
      conversations[contextKey] = {
        updatedAt: new Date().toISOString(),
        messages: trimMessages([
          ...previousMessages,
          { role: 'user', content: prompt, time: new Date(startedAt).toISOString() },
          { role: 'assistant', content: output, time: new Date().toISOString() },
        ], config.contextMaxTurns, config.contextMaxChars),
      };
      await persistContexts();
      await refreshProgress('✅ Harness 执行完成', true);
      if (!disposed) await sendText(chatId, `✅ 任务 ${taskId} 已完成\n模型：${activeModelDescription}\n\n${output}`);
      const files = [...new Set(outputFileCandidates(output))].slice(0, config.maxOutboundFiles);
      for (const candidate of files) {
        try {
          const sent = await sendFile(chatId, candidate);
          log('info', `task ${taskId} sent file ${sent}`);
        } catch (error) {
          const detail = error instanceof Error ? error.message : String(error);
          log('warn', `task ${taskId} failed to send file ${candidate}: ${detail}`);
          if (!disposed) await sendText(chatId, `⚠️ 文件发送失败：${candidate}\n${detail}`);
        }
      }
      log('info', `task ${taskId} completed in ${Date.now() - startedAt}ms; output=${output.length} chars`);
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      log('warn', `task ${taskId} failed after ${Date.now() - startedAt}ms: ${detail}`);
      latestOutput = detail;
      await refreshProgress('❌ Harness 执行失败', true);
      if (!disposed) await sendText(chatId, `❌ 任务 ${taskId} 失败\n模型：${activeModelDescription}\n\n${detail.slice(0, 3500)}`);
    } finally {
      clearInterval(heartbeat);
      for (const [requestId, approval] of pendingApprovals) {
        if (approval.taskId === taskId) pendingApprovals.delete(requestId);
      }
      await rm(approvalDirectory, { recursive: true, force: true }).catch(() => {});
      pendingTasks = Math.max(0, pendingTasks - 1);
      log('info', `queue depth=${pendingTasks}`);
    }
  };

  const dispatcher = new Lark.EventDispatcher({}).register({
    'im.message.receive_v1': async (data) => {
      const message = data?.message;
      const chatId = message?.chat_id;
      const messageId = message?.message_id;
      const openId = data?.sender?.sender_id?.open_id || '';
      const messageType = message?.message_type || 'unknown';
      if (disposed || data?.sender?.sender_type === 'app' || !chatId) return;
      if (!remember(messageId)) {
        log('info', `ignored duplicate message ${messageId || 'without-id'}`);
        return;
      }
      log('info', `received message ${messageId}; type=${messageType}; sender=${openId || 'unknown'}`);

      let prompt = textFromMessage(message);
      const attachment = fileFromMessage(message);
      if (!prompt && !attachment) {
        log('info', `rejected message ${messageId}; unsupported type=${messageType}`);
        await sendText(chatId, '目前支持文字、文件、图片、音频和视频消息。');
        return;
      }
      const isAdmin = adminOpenIds.has(openId);
      const [command, argument = ''] = prompt ? prompt.split(/\s+/, 2) : ['', ''];

      if (prompt === '申请授权' || command === '/request') {
        if (allowedOpenIds.has(openId)) {
          await sendText(chatId, '✅ 你已经拥有任务执行权限。');
          return;
        }
        pendingRequests.set(openId, { requestedAt: new Date().toISOString() });
        await persistAuthorizations();
        log('info', `authorization requested by sender=${openId}`);
        await sendText(chatId, `📨 授权申请已记录，请联系管理员审批。\n你的 open_id：${openId}`);
        return;
      }

      if (['/approve', '/revoke', '/users', '/requests'].includes(command)) {
        if (!isAdmin) {
          log('warn', `rejected admin command ${command}; sender=${openId || 'unknown'}`);
          await sendText(chatId, '此命令仅限管理员使用。');
          return;
        }
        if (command === '/approve') {
          if (!argument) {
            await sendText(chatId, '用法：/approve <open_id>');
            return;
          }
          allowedOpenIds.add(argument);
          pendingRequests.delete(argument);
          await persistAuthorizations();
          log('info', `authorization approved for ${argument}; admin=${openId}`);
          await sendText(chatId, `✅ 已授权用户：${argument}`);
          return;
        }
        if (command === '/revoke') {
          if (!argument) {
            await sendText(chatId, '用法：/revoke <open_id>');
            return;
          }
          if (adminOpenIds.has(argument)) {
            await sendText(chatId, '无法通过命令撤销配置文件中的管理员。');
            return;
          }
          allowedOpenIds.delete(argument);
          pendingRequests.delete(argument);
          await persistAuthorizations();
          log('info', `authorization revoked for ${argument}; admin=${openId}`);
          await sendText(chatId, `✅ 已撤销用户：${argument}`);
          return;
        }
        if (command === '/users') {
          const users = [...allowedOpenIds].sort();
          await sendText(chatId, users.length
            ? `已授权用户（${users.length}）：\n${users.map((id) => `${adminOpenIds.has(id) ? '管理员' : '用户'}  ${id}`).join('\n')}`
            : '当前没有已授权用户。');
          return;
        }
        const requests = [...pendingRequests.entries()];
        await sendText(chatId, requests.length
          ? `待审批申请（${requests.length}）：\n${requests.map(([id, item]) => `${id}\n申请时间：${item.requestedAt}`).join('\n\n')}`
          : '当前没有待审批申请。');
        return;
      }

      if (!allowedOpenIds.has(openId)) {
        log('warn', `rejected message ${messageId}; unauthorized sender=${openId || 'unknown'}`);
        await sendText(chatId, `此用户尚未获准执行任务。\n你的 open_id：${openId || '无法读取'}`);
        return;
      }
      if (command === '/allow' || command === '/deny') {
        if (!argument) {
          await sendText(chatId, `用法：${command} <审批编号>`);
          return;
        }
        const approval = pendingApprovals.get(argument);
        if (!approval) {
          await sendText(chatId, '该审批不存在、已经处理或所属任务已经结束。');
          return;
        }
        if (approval.openId !== openId && !isAdmin) {
          log('warn', `rejected approval decision ${argument}; sender=${openId}`);
          await sendText(chatId, '你只能审批自己的任务。');
          return;
        }
        const outcome = command === '/allow' ? 'allowed-once' : 'rejected';
        const decisionFile = path.join(approval.directory, `${argument}.decision`);
        await writeFile(decisionFile, `${JSON.stringify({ outcome })}\n`, { mode: 0o600 });
        pendingApprovals.delete(argument);
        log('info', `approval ${argument} ${outcome}; task=${approval.taskId}; sender=${openId}`);
        await sendText(chatId, `${outcome === 'allowed-once' ? '✅ 已批准' : '⛔ 已拒绝'}任务 ${approval.taskId} 的一次性权限。`);
        return;
      }
      if (command === '/send') {
        if (!argument) {
          await sendText(chatId, '用法：/send <工作区内的相对路径>');
          return;
        }
        try {
          const sent = await sendFile(chatId, argument);
          log('info', `manual file sent; sender=${openId}; path=${sent}`);
        } catch (error) {
          await sendText(chatId, `文件发送失败：${error instanceof Error ? error.message : String(error)}`);
        }
        return;
      }
      const contextKey = `${chatId}:${openId}`;
      if (['/new', '/clear', '/history', '/context'].includes(command)) {
        if (command === '/new' || command === '/clear') {
          delete conversations[contextKey];
          await persistContexts();
          log('info', `context cleared; sender=${openId}; chat=${chatId}`);
          await sendText(chatId, command === '/new'
            ? '🆕 已创建新会话，后续任务不会携带此前上下文。'
            : '🧹 当前会话上下文已清除。');
          return;
        }
        const messages = conversations[contextKey]?.messages || [];
        if (command === '/context') {
          const chars = messages.reduce((sum, item) => sum + String(item.content || '').length, 0);
          await sendText(chatId, `当前上下文：${Math.ceil(messages.length / 2)} 轮，${messages.length} 条消息，约 ${chars} 个字符。\n上限：${config.contextMaxTurns} 轮 / ${config.contextMaxChars} 字符。`);
          return;
        }
        if (!messages.length) {
          await sendText(chatId, '当前会话还没有历史上下文。');
          return;
        }
        const history = messages.slice(-10).map((item, index) => {
          const content = cleanOutput(item.content).replace(/\s+/g, ' ').slice(0, 180);
          return `${index + 1}. ${item.role === 'assistant' ? '助手' : '用户'}：${content}${item.content.length > 180 ? '…' : ''}`;
        }).join('\n');
        await sendText(chatId, `最近上下文：\n${history}`);
        return;
      }
      if (prompt === '/help') {
        log('info', `handled /help from sender=${openId}`);
        const adminHelp = isAdmin
          ? '\n\n管理员命令：\n/requests\n/approve <open_id>\n/revoke <open_id>\n/users'
          : '';
        await sendText(chatId, `直接发送文字或文件即可创建任务，Harness 会主动运行必要脚本；高风险操作会在飞书请求一次性批准。后续消息会自动携带当前飞书会话的最近上下文。\n\n文件命令：\n/send <工作区内的相对路径>\n\n审批命令：\n/allow <审批编号>\n/deny <审批编号>\n\n会话命令：\n/new 新建会话\n/clear 清除上下文\n/history 查看最近上下文\n/context 查看上下文用量\n\n未授权用户可发送“申请授权”或 /request。${adminHelp}`);
        return;
      }

      if (attachment) {
        try {
          const received = await downloadMessageFile(message, attachment);
          const relative = path.relative(workspaceRoot, received.destination);
          prompt = `用户通过飞书上传了文件。请直接读取并处理该文件；如果用户没有提供额外说明，请分析其内容并给出摘要。\n文件名：${safeFileName(attachment.fileName)}\n工作区相对路径：${relative}\n文件大小：${received.size} 字节`;
          await sendText(chatId, `📎 文件已接收：${safeFileName(attachment.fileName)}\n保存位置：${relative}`);
          log('info', `received file ${received.destination}; size=${received.size}`);
        } catch (error) {
          const detail = error instanceof Error ? error.message : String(error);
          log('warn', `file receive failed; message=${messageId}: ${detail}`);
          await sendText(chatId, `❌ 文件接收失败：${detail}`);
          return;
        }
      }

      const taskId = crypto.randomUUID().slice(0, 8);
      pendingTasks += 1;
      log('info', `queued task ${taskId}; queue depth=${pendingTasks}`);
      const [progressMessageId] = await sendText(chatId, `📥 已接收任务 ${taskId}，正在排队执行。\n模型：${modelDescription}`);
      queue = queue
        .then(() => executeTask({ chatId, openId, prompt, taskId, progressMessageId }))
        .catch((error) => log('warn', `queue failure: ${String(error)}`));
    },
  });

  ctx.effect(() => {
    void wsClient.start({ eventDispatcher: dispatcher }).catch((error) => {
      log('error', `websocket start failed: ${String(error)}`);
    });
    log('info', `bridge started with ${allowedOpenIds.size} authorized user(s), ${adminOpenIds.size} admin(s), ${pendingRequests.size} pending request(s)`);
    return () => {
      disposed = true;
      log('info', `bridge stopping; active processes=${children.size}; queued=${pendingTasks}`);
      wsClient.close({ force: true });
      for (const child of children) child.kill('SIGTERM');
    };
  });
}
