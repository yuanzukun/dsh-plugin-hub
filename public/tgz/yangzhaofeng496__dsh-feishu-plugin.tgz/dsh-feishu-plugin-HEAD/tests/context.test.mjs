import assert from 'node:assert/strict';
import test from 'node:test';
import { contextInternals } from '../src/index.mjs';

const { contextualPrompt, trimMessages } = contextInternals;

test('trimMessages keeps only the latest configured turns', () => {
  const messages = [
    { role: 'user', content: 'u1' },
    { role: 'assistant', content: 'a1' },
    { role: 'user', content: 'u2' },
    { role: 'assistant', content: 'a2' },
  ];
  assert.deepEqual(trimMessages(messages, 1, 100), messages.slice(-2));
});

test('trimMessages applies the character budget from newest to oldest', () => {
  const messages = [
    { role: 'user', content: '12345' },
    { role: 'assistant', content: 'abcdef' },
  ];
  assert.deepEqual(trimMessages(messages, 5, 8), [
    { role: 'user', content: '45' },
    { role: 'assistant', content: 'abcdef' },
  ]);
});

test('contextualPrompt tells the agent to execute a first task directly', () => {
  const result = contextualPrompt([], '当前任务');
  assert.match(result, /主动使用可用工具/);
  assert.match(result, /<current_task>\n当前任务/);
});

test('contextualPrompt labels history separately from the current task', () => {
  const result = contextualPrompt([
    { role: 'user', content: '分析项目' },
    { role: 'assistant', content: '已经完成分析' },
  ], '继续修改');
  assert.match(result, /<conversation_history>/);
  assert.match(result, /用户：分析项目/);
  assert.match(result, /助手：已经完成分析/);
  assert.match(result, /<current_task>\n继续修改/);
});
