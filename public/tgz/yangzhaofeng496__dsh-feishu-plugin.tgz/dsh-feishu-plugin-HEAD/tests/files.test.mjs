import assert from 'node:assert/strict';
import test from 'node:test';
import { fileInternals } from '../src/index.mjs';

const { fileTypeForUpload, outputFileCandidates, safeFileName } = fileInternals;

test('safeFileName strips paths and unsafe separators', () => {
  assert.equal(safeFileName('../../report:final.pdf'), 'report_final.pdf');
  assert.equal(safeFileName('folder\\payload.txt'), 'folder_payload.txt');
});

test('fileTypeForUpload maps office formats and falls back to stream', () => {
  assert.equal(fileTypeForUpload('/tmp/report.pdf'), 'pdf');
  assert.equal(fileTypeForUpload('/tmp/table.xlsx'), 'xls');
  assert.equal(fileTypeForUpload('/tmp/archive.zip'), 'stream');
});

test('outputFileCandidates extracts one path per DSH_FILE line', () => {
  assert.deepEqual(outputFileCandidates([
    '任务完成。',
    'DSH_FILE: outputs/report.pdf',
    'DSH_FILE: outputs/data.csv',
  ].join('\n')), ['outputs/report.pdf', 'outputs/data.csv']);
});
