import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { apply } from '../headless-trace/src/index.mjs';

test('headless trace resolves a Feishu approval decision', async () => {
  const handlers = new Map();
  const ctx = { on(name, handler) { handlers.set(name, handler); } };
  apply(ctx);
  const handler = handlers.get('approval/request');
  assert.equal(typeof handler, 'function');

  const directory = await mkdtemp(path.join(os.tmpdir(), 'dsh-feishu-test-'));
  const previousDirectory = process.env.DSH_FEISHU_APPROVAL_DIR;
  const previousTrace = process.env.DSH_FEISHU_TRACE;
  const originalWrite = process.stderr.write;
  let trace = '';
  process.env.DSH_FEISHU_APPROVAL_DIR = directory;
  process.env.DSH_FEISHU_TRACE = '1';
  process.stderr.write = (chunk) => { trace += String(chunk); return true; };

  try {
    const outcomePromise = handler({ toolName: 'bash' }, async () => 'unavailable');
    const event = JSON.parse(trace.split('\n')[0].replace('__DSH_FEISHU_EVENT__', ''));
    assert.equal(event.type, 'approval_requested');
    await writeFile(path.join(directory, `${event.requestId}.decision`), '{"outcome":"allowed-once"}\n');
    assert.equal(await outcomePromise, 'allowed-once');
  } finally {
    process.stderr.write = originalWrite;
    if (previousDirectory === undefined) delete process.env.DSH_FEISHU_APPROVAL_DIR;
    else process.env.DSH_FEISHU_APPROVAL_DIR = previousDirectory;
    if (previousTrace === undefined) delete process.env.DSH_FEISHU_TRACE;
    else process.env.DSH_FEISHU_TRACE = previousTrace;
    await rm(directory, { recursive: true, force: true });
  }
});
