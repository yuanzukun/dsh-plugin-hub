import crypto from 'node:crypto';
import { readFile, unlink } from 'node:fs/promises';
import path from 'node:path';

export const name = 'feishu-trace';

const PREFIX = '__DSH_FEISHU_EVENT__';
const SECRET_KEY = /(?:secret|token|password|authorization|api[_-]?key|credential)/i;

function redact(value, key = '', depth = 0) {
  if (SECRET_KEY.test(key)) return '[REDACTED]';
  if (depth > 3) return '[TRUNCATED]';
  if (Array.isArray(value)) return value.slice(0, 10).map((item) => redact(item, '', depth + 1));
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).slice(0, 20)
      .map(([childKey, childValue]) => [childKey, redact(childValue, childKey, depth + 1)]));
  }
  if (typeof value === 'string') return value.length > 500 ? `${value.slice(0, 500)}…` : value;
  return value;
}

function emit(type, data = {}) {
  if (process.env.DSH_FEISHU_TRACE !== '1') return;
  const event = { type, time: new Date().toISOString(), ...redact(data) };
  process.stderr.write(`${PREFIX}${JSON.stringify(event)}\n`);
}

function wait(milliseconds, signal) {
  return new Promise((resolve, reject) => {
    const finish = () => {
      signal?.removeEventListener('abort', abort);
      resolve();
    };
    const timer = setTimeout(finish, milliseconds);
    const abort = () => {
      clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
      reject(signal?.reason || new Error('approval cancelled'));
    };
    if (signal?.aborted) abort();
    else signal?.addEventListener('abort', abort, { once: true });
  });
}

async function waitForDecision(file, signal) {
  const deadline = Date.now() + Number(process.env.DSH_FEISHU_APPROVAL_TIMEOUT_MS || 600000);
  while (Date.now() < deadline) {
    if (signal?.aborted) return 'cancelled';
    try {
      const parsed = JSON.parse(await readFile(file, 'utf8'));
      await unlink(file).catch(() => {});
      return parsed.outcome === 'allowed-once' ? 'allowed-once' : 'rejected';
    } catch (error) {
      if (error?.code !== 'ENOENT') return 'unavailable';
    }
    try {
      await wait(500, signal);
    } catch {
      return 'cancelled';
    }
  }
  return 'unavailable';
}

export function apply(ctx) {
  ctx.on('approval/request', async (request, next) => {
    const directory = process.env.DSH_FEISHU_APPROVAL_DIR;
    if (!directory) return next();
    const requestId = crypto.randomUUID().slice(0, 8);
    const decisionFile = path.join(directory, `${requestId}.decision`);
    emit('approval_requested', {
      requestId,
      toolName: request.toolName,
      callId: request.callId ? String(request.callId) : undefined,
      reason: request.reason,
    });
    const outcome = await waitForDecision(decisionFile, request.signal);
    emit('approval_decided', { requestId, outcome });
    return outcome;
  }, { prepend: true });

  ctx.on('agent/created', ({ agent }) => {
    emit('agent_created', {
      sessionId: String(agent.id),
      provider: agent.options?.provider,
      model: agent.options?.model,
    });
  });

  ctx.on('agent/status', ({ status }) => {
    emit(status === 'running' ? 'agent_running' : 'agent_idle');
  });

  ctx.on('agent/pre-step', async ({ turn, step }, next) => {
    emit('step_started', { turn, step });
    return next();
  });

  ctx.on('agent/request', async ({ agent, turn, step }, next) => {
    emit('model_request', {
      turn,
      step,
      provider: agent.options?.provider,
      model: agent.options?.model,
    });
    return next();
  });

  ctx.on('agent/request-error', async ({ turn, step, provider, failure }, next) => {
    emit('model_error', { turn, step, provider, failure });
    return next();
  });

  ctx.on('tools/pre-execute', async (exec, next) => {
    emit('tool_started', {
      callId: String(exec.callId),
      name: exec.name,
      arguments: exec.arguments,
    });
    return next();
  });

  ctx.on('tools/result', (exec, result) => {
    emit('tool_finished', {
      callId: String(exec.callId),
      name: exec.name,
      isError: result.isError,
    });
  });

  ctx.on('agent/error', ({ turn, step, error }) => {
    emit('agent_error', {
      turn,
      step,
      error: error instanceof Error ? error.message : String(error),
    });
  });
}
