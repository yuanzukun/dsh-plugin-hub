import { clientConfig } from './tsdown.client.ts'

/**
 * Browser-half build: emits the closure-factory client bundle at
 * `lib/client.js` (served at /plugins/<id>/client.js by the dsh web shell).
 * Runs as a separate tsdown pass after the host pass so `clean` on the host
 * config never wipes it.
 */
export default clientConfig('dsh-blackjack', 'src/client/index.ts')
