/**
 * DeepSeek-dealt blackjack host service: a sidebar 21-point game where the
 * DeepSeek model deals and talks trash. Game state lives in the owning
 * session's plugin-side sidecar (`blackjack/*` events under `$DSH_HOME`), so
 * rounds replay and fork identically without writing events the harness does
 * not know; legacy sessions are migrated from the harness log on first load.
 *
 * @module @deepseek-ai/dsh-blackjack
 */

import { randomUUID } from 'node:crypto'
import { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import type { SessionEventMap } from '@deepseek-ai/dsh-session/types'
import { TypertRemoteService, Remote } from '@deepseek-ai/dsh-typert-protocol'
import type { TypertRegistryContract } from '@deepseek-ai/dsh-typert-protocol'
import { blackjackRemoteContribution } from '../typert.remote-client.ts'
import { handOf, settle } from '../game'
import { banterTriggerForResult, generateDealerBanter, shouldRandomBanter } from './banter.ts'
import type { BanterTrigger } from './banter.ts'
import { dealerDecide } from './dealer.ts'
import type { DealerDecisionResult } from './dealer.ts'
import { applyBlackjackEvent, blackjackView, emptyBlackjackFoldState, nextDraw } from './fold.ts'
import type { BlackjackFoldState } from './fold.ts'
import { BlackjackError, resolveBlackjackConfig } from './runtime.ts'
import type { ResolvedBlackjackConfig } from './runtime.ts'
import { defaultBlackjackDataRoot, BlackjackSidecar } from './sidecar.ts'
import type { BlackjackSidecarEvent } from './sidecar.ts'
import type {
  BlackjackBanterRequest,
  BlackjackBanterResult,
  BlackjackConfig,
  BlackjackSessionEventType,
  BlackjackSetPersonaRequest,
  BlackjackStartRequest,
  BlackjackView,
} from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    blackjack: BlackjackService
  }
}

export type * from './types.ts'
export {
  BLACKJACK_LLM_TIMEOUT_CODE,
  BLACKJACK_PERSONAS,
  DEFAULT_BLACKJACK_CONFIG,
  BlackjackError,
  resolveBlackjackConfig,
} from './runtime.ts'
export type { BlackjackErrorCode, ResolvedBlackjackConfig } from './runtime.ts'
export {
  applyBlackjackEvent,
  blackjackView,
  emptyBlackjackFoldState,
  foldBlackjack,
  nextDraw,
} from './fold.ts'
export type { BlackjackFoldState } from './fold.ts'
export { banterPrompt, banterTriggerForResult, generateDealerBanter, shouldRandomBanter } from './banter.ts'
export type { BanterTrigger, DealerBanterInput } from './banter.ts'
export { dealerDecide, decisionPrompt } from './dealer.ts'
export type { DealerDecisionInput, DealerDecisionResult } from './dealer.ts'

/** Process-local fold cache per session. */
interface BlackjackCache {
  readonly state: BlackjackFoldState
}

interface HostTypertContribution {
  readonly package: string
  readonly face: 'host'
  readonly schemas: readonly unknown[]
  readonly model: {
    readonly services: readonly unknown[]
    readonly events: readonly unknown[]
    readonly objects: readonly unknown[]
  }
  readonly invocations: readonly unknown[]
}

interface HostTypertRegistry extends TypertRegistryContract {
  register(contribution: HostTypertContribution): () => void
}

/**
 * The blackjack service (`ctx.blackjack`): event-sourced 21-point rounds with
 * an LLM dealer, banter, and strict replay from the session log.
 */
export class BlackjackService extends TypertRemoteService {
  static inject = ['agents', 'llm']

  static Config: z<BlackjackConfig> = z.object({
    dealerPersona: z.union(['大肥鱼', '雌小鬼'] as const).default('大肥鱼'),
    randomBanterChance: z.number().min(0).max(1).default(0.3),
    maxDecisionTokens: z.number().step(1).min(1).default(100),
    maxBanterTokens: z.number().step(1).min(1).default(60),
    timeoutMs: z.number().step(1).min(1).default(15000),
    dealerLlm: z.boolean().default(true),
  })

  private readonly resolved: ResolvedBlackjackConfig
  private readonly dataRoot: string
  private readonly caches = new WeakMap<Session, BlackjackCache>()
  private readonly sidecars = new WeakMap<Session, BlackjackSidecar>()

  constructor(ctx: Context, config: BlackjackConfig = {}) {
    super(ctx, 'blackjack')
    this.resolved = resolveBlackjackConfig(config)
    this.dataRoot = config.dataRoot ?? defaultBlackjackDataRoot()

    // Keep the generated client contribution mounted for Remote consumers.
    const typert = ctx.get('typert', false) as HostTypertRegistry | undefined
    if (typert !== undefined) {
      ctx.effect(
        () => typert.remotes.register(blackjackRemoteContribution),
        'dsh-blackjack: Remote descriptors',
      )

      // rc.6 Gateway dispatches Host calls from the local invocation registry.
      // Registering here avoids relying on @Remote decorator metadata crossing
      // separate protocol module instances in an npx-installed plugin.
      if (typeof typert.register === 'function') {
        const hostInvocations = blackjackRemoteContribution.descriptors.map(descriptor => ({
          ...descriptor,
          parameters: descriptor.parameters.map(parameter => parameter.source === 'lookup'
            ? { ...parameter, codec: { mode: 'src-json' as const } }
            : parameter),
        }))
        ctx.effect(
          () => typert.register({
            package: 'dsh-blackjack',
            face: 'host',
            schemas: [],
            model: { services: [], events: [], objects: [] },
            invocations: hostInvocations,
          }),
          'dsh-blackjack: Host invocation definitions',
        )
      }
    }
  }

  /**
   * Open a new round: deal from a fresh (or explicitly seeded) deck. The
   * dealer's greeting fires in the background and lands in the log moments
   * later (pull `view` to catch it), so dealing never waits on the model.
   * @param agent - owning live agent.
   * @param request - optional explicit deck seed for deterministic replays.
   * @returns the live view in the player's turn.
   */
  @Remote('start')
  async start(agent: Agent, request: BlackjackStartRequest): Promise<BlackjackView> {
    const cache = this.prepare(agent)
    if (cache.state.phase !== 'idle' && cache.state.phase !== 'settled') {
      throw new BlackjackError(
        `round ${cache.state.round} is already in progress (${cache.state.phase})`,
        'BLACKJACK_ROUND_IN_PROGRESS',
      )
    }
    const round = cache.state.round + 1
    const deckSeed = request.deckSeed ?? randomUUID()
    this.commit(agent, cache, 'blackjack/game-start', { round, deckSeed })
    void this.appendDealerBanter(agent, cache, 'game-start')
    return this.viewOf(cache)
  }

  /**
   * Draw one card for the player. A bust settles the round immediately.
   * Dealer chatter never blocks the draw: any taunt or bust line fires in
   * the background and lands in the log moments later.
   * @param agent - owning live agent.
   * @returns the live view (settled when the hit busted).
   */
  @Remote('hit')
  async hit(agent: Agent): Promise<BlackjackView> {
    const cache = this.prepare(agent)
    this.expectPlayerTurn(cache.state)
    const state = cache.state
    const seed = this.requireSeed(state)
    const drawn = nextDraw(seed, state.player.cards.length, state.dealer.cards.length)
    const player = handOf([...state.player.cards, drawn])
    this.commit(agent, cache, 'blackjack/hit', { round: state.round, player: player.cards })
    if (player.bust) {
      const result = settle(player, state.dealer)
      this.commit(agent, cache, 'blackjack/settle', {
        round: state.round,
        result,
        playerTotal: player.total,
        dealerTotal: state.dealer.total,
      })
      this.commit(agent, cache, 'blackjack/emotion', { emotion: state.emotion })
      void this.appendDealerBanter(agent, cache, 'player-bust')
    } else if (shouldRandomBanter(this.resolved.randomBanterChance)) {
      void this.appendDealerBanter(agent, cache, 'random')
    }
    return this.viewOf(cache)
  }

  /**
   * Pass the player's turn: commit the stand and open the dealer turn. The
   * dealer then plays one step per {@link dealer} call — the client drives
   * the steps so every decision is visible: think (the model decides), draw
   * one card, repeat until the dealer stands or busts.
   * @param agent - owning live agent.
   * @returns the live view with the dealer turn open.
   */
  @Remote('stand')
  async stand(agent: Agent): Promise<BlackjackView> {
    const cache = this.prepare(agent)
    this.expectPlayerTurn(cache.state)
    const state = cache.state
    this.commit(agent, cache, 'blackjack/stand', { round: state.round, playerTotal: state.player.total })
    return this.viewOf(cache)
  }

  /**
   * Run one dealer turn step: one model-backed (or policy) decision and, on
   * a hit, one drawn card. When the dealer stands or busts the round settles
   * inside this step; the settle line fires in the background so the verdict
   * never waits on the model.
   * @param agent - owning live agent.
   * @returns the live view (settled once the dealer stands or busts).
   */
  @Remote('dealer')
  async dealer(agent: Agent): Promise<BlackjackView> {
    const cache = this.prepare(agent)
    if (cache.state.round === 0) throw new BlackjackError('no blackjack round has started', 'BLACKJACK_NO_ROUND')
    if (cache.state.phase !== 'dealer-turn') {
      throw new BlackjackError(`cannot deal during "${cache.state.phase}"`, 'BLACKJACK_INVALID_ACTION')
    }
    const state = cache.state
    const seed = this.requireSeed(state)
    const decision = await this.dealerDecision(agent, cache)
    if (decision.action === 'stand') {
      this.commit(agent, cache, 'blackjack/dealer-hit', {
        round: state.round,
        dealer: state.dealer.cards,
        decision: 'stand',
        ...(decision.llm === undefined ? {} : { llm: decision.llm }),
      })
    } else {
      const drawn = nextDraw(seed, state.player.cards.length, state.dealer.cards.length)
      const dealer = handOf([...state.dealer.cards, drawn])
      this.commit(agent, cache, 'blackjack/dealer-hit', {
        round: state.round,
        dealer: dealer.cards,
        decision: 'hit',
        ...(decision.llm === undefined ? {} : { llm: decision.llm }),
      })
    }
    if (state.dealer.bust || decision.action === 'stand') {
      const result = settle(state.player, state.dealer)
      this.commit(agent, cache, 'blackjack/settle', {
        round: state.round,
        result,
        playerTotal: state.player.total,
        dealerTotal: state.dealer.total,
      })
      this.commit(agent, cache, 'blackjack/emotion', { emotion: state.emotion })
      void this.appendDealerBanter(agent, cache, banterTriggerForResult(result))
    }
    return this.viewOf(cache)
  }

  /**
   * Read the live table without committing anything — the client's way to
   * catch background chatter (greetings, taunts, settle lines) between verbs.
   * @param agent - owning live agent.
   * @returns the live view.
   */
  @Remote('view')
  async view(agent: Agent): Promise<BlackjackView> {
    const cache = this.prepare(agent)
    return this.viewOf(cache)
  }

  /**
   * Receive one player trash-talk line and return the dealer's reply.
   * @param agent - owning live agent.
   * @param request - the player's line.
   * @returns the dealer reply, also durable in the session log.
   */
  @Remote('banter')
  async banter(agent: Agent, request: BlackjackBanterRequest): Promise<BlackjackBanterResult> {
    const cache = this.prepare(agent)
    const content = typeof request.content === 'string' ? request.content.trim() : ''
    if (content.length === 0) {
      throw new BlackjackError('blackjack banter requires non-empty content', 'BLACKJACK_EMPTY_BANTER')
    }
    this.commit(agent, cache, 'blackjack/banter', { ...this.roundField(cache), from: 'player', content })
    const reply = await this.appendDealerBanter(agent, cache, 'reply', content)
    return { reply }
  }

  /**
   * Switch the dealer's role-play persona: durable per session, so the pick
   * survives refresh, resume, and compaction. Works in any phase — the tone
   * of the next dealer line changes immediately.
   * @param agent - owning live agent.
   * @param request - the picked persona.
   * @returns the live view with the new persona.
   */
  @Remote('persona')
  async persona(agent: Agent, request: BlackjackSetPersonaRequest): Promise<BlackjackView> {
    const cache = this.prepare(agent)
    this.commit(agent, cache, 'blackjack/persona', { persona: request.persona })
    return this.viewOf(cache)
  }

  /** Resolve and validate the cache used by a call. */
  private prepare(agent: Agent): BlackjackCache {
    this.assertLive(agent)
    return this.cache(agent.session)
  }

  /** Enforce exact live-agent identity rather than trusting a matching id. */
  private assertLive(agent: Agent): void {
    if (this.ctx.agents.get(agent.id) !== agent) {
      throw new BlackjackError(`agent "${agent.id}" is not live in this registry`, 'BLACKJACK_AGENT_NOT_LIVE')
    }
  }

  /** The session's plugin-side sidecar, cached per session. */
  private sidecar(session: Session): BlackjackSidecar {
    let sidecar = this.sidecars.get(session)
    if (sidecar === undefined) {
      sidecar = BlackjackSidecar.forSession(session.id, this.dataRoot)
      this.sidecars.set(session, sidecar)
    }
    return sidecar
  }

  /** Return the per-session cache, folding the plugin-side log once. */
  private cache(session: Session): BlackjackCache {
    let cache = this.caches.get(session)
    if (cache !== undefined) return cache
    // The deployment config supplies the pre-selection persona; the first
    // `blackjack/persona` event (the player's pick) overrides it durably.
    const state = emptyBlackjackFoldState(this.resolved.dealerPersona)
    const sidecar = this.sidecar(session)
    const events = sidecar.load()
    if (events.length === 0) {
      // Legacy migration: sessions written while blackjack events still
      // landed in the harness log carry them in `session.events`; fold them
      // into the sidecar once so the plugin-owned log stays the single
      // source of truth from here on.
      this.migrateLegacy(sidecar, session, state)
    } else {
      for (const event of events) applyBlackjackEvent(state, event as SessionEvent)
    }
    cache = { state }
    this.caches.set(session, cache)
    return cache
  }

  /** Fold a legacy harness-log stream into the sidecar when it is empty. */
  private migrateLegacy(sidecar: BlackjackSidecar, session: Session, state: BlackjackFoldState): void {
    const migrated = sidecar.migrate(session.events)
    for (const event of migrated) applyBlackjackEvent(state, event as SessionEvent)
  }

  /** Commit one blackjack event into the plugin-side log and the local fold. */
  private commit<T extends BlackjackSessionEventType>(
    agent: Agent,
    cache: BlackjackCache,
    type: T,
    data: SessionEventMap[T],
  ): void {
    const event = this.sidecar(agent.session).append(type, data)
    applyBlackjackEvent(cache.state, event as SessionEvent)
  }

  /** Require the player's turn for hit/stand. */
  private expectPlayerTurn(state: BlackjackFoldState): void {
    if (state.round === 0) throw new BlackjackError('no blackjack round has started', 'BLACKJACK_NO_ROUND')
    if (state.phase !== 'player-turn') {
      throw new BlackjackError(`cannot act during "${state.phase}"`, 'BLACKJACK_INVALID_ACTION')
    }
  }

  /** Require a deck seed for the current round. */
  private requireSeed(state: BlackjackFoldState): string {
    if (state.deckSeed === undefined) {
      throw new BlackjackError('no blackjack round has started', 'BLACKJACK_NO_ROUND')
    }
    return state.deckSeed
  }

  /** Omit the round field until the first round opens. */
  private roundField(cache: BlackjackCache): { round?: number } {
    return cache.state.round === 0 ? {} : { round: cache.state.round }
  }

  /** Resolve the dealer decision for the current table state. */
  private async dealerDecision(agent: Agent, cache: BlackjackCache): Promise<DealerDecisionResult> {
    const state = cache.state
    return dealerDecide(this.ctx, this.resolved, {
      round: state.round,
      player: state.player,
      dealer: state.dealer,
      emotion: state.emotion,
      persona: state.persona,
      record: state.record,
      ...(state.lastResult ? { lastResult: state.lastResult } : {}),
      banter: state.banter,
    }, this.agentRoute(agent))
  }

  /** Resolve one dealer banter line, commit it durably, and return it. */
  private async appendDealerBanter(agent: Agent, cache: BlackjackCache, trigger: BanterTrigger, playerLine?: string): Promise<string> {
    const reply = await this.dealerBanter(agent, cache, trigger, playerLine)
    if (reply.length === 0) return reply
    this.commit(agent, cache, 'blackjack/banter', { ...this.roundField(cache), from: 'dealer', content: reply, trigger })
    return reply
  }

  /** Resolve one dealer banter line through the LLM or the fallback pool. */
  private async dealerBanter(agent: Agent, cache: BlackjackCache, trigger: BanterTrigger, playerLine?: string): Promise<string> {
    const state = cache.state
    return generateDealerBanter(this.ctx, this.resolved, {
      round: state.round,
      trigger,
      player: state.player,
      dealer: state.dealer,
      emotion: state.emotion,
      persona: state.persona,
      record: state.record,
      ...(state.lastResult ? { lastResult: state.lastResult } : {}),
      ...(playerLine === undefined ? {} : { playerLine }),
      banter: state.banter,
    }, this.agentRoute(agent))
  }

  /** The agent's own model route, when configured. */
  private agentRoute(agent: Agent): { provider: string; model: string } | undefined {
    const provider = agent.options.provider
    const model = agent.options.model
    if (typeof provider !== 'string' || provider.length === 0 || typeof model !== 'string' || model.length === 0) {
      return undefined
    }
    return { provider, model }
  }

  /** Project the folded cache into a detached view. */
  private viewOf(cache: BlackjackCache): BlackjackView {
    return blackjackView(cache.state)
  }
}

export default BlackjackService
