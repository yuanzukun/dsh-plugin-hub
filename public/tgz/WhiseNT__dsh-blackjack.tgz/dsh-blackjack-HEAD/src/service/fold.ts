/**
 * Strict event-sourced fold of the blackjack session stream: every round is
 * reconstructed from `blackjack/*` events alone, so logs replay and fork
 * identically. The fold is strict by design — malformed streams throw, which
 * the companion invariant turns into a stream rejection where it is
 * installed, and the service surfaces as a fail-loud cache error on replay.
 *
 * @module @deepseek-ai/dsh-blackjack/fold
 */

import type { SessionEvent } from '@deepseek-ai/dsh-session'
import {
  deal,
  foldEmotion,
  handOf,
  resultDirection,
  settle,
  shuffleDeck,
  DEFAULT_BLACKJACK_PERSONA,
  FULL_DECK,
} from '../game'
import { assertPersona } from '../game/invariant'
import type { BanterLine, BlackjackPersona, BlackjackResult, Card, DealerEmotion, Hand } from '../game'
import { MAX_BANTER_HISTORY } from './runtime.ts'
import type { BlackjackPhase, BlackjackRecord, BlackjackView } from './types.ts'

/** Mutable accumulator kept private to the pure fold. */
export interface BlackjackFoldState {
  /** Current round number; 0 before the first game-start. */
  round: number
  /** Current round phase. */
  phase: BlackjackPhase
  /** Deck seed of the current round; absent before the first game-start. */
  deckSeed: string | undefined
  /** Current player hand; empty before the first deal. */
  player: Hand
  /** Current dealer hand; empty before the first deal. */
  dealer: Hand
  /** Folded dealer emotion. */
  emotion: DealerEmotion
  /** The dealer's current role-play persona. */
  persona: BlackjackPersona
  /** Chatter history, most recent last, capped at {@link MAX_BANTER_HISTORY}. */
  banter: BanterLine[]
  /** Lifetime ledger. */
  record: BlackjackRecord
  /** Latest settled outcome; cleared when the next round opens. */
  result: BlackjackResult | undefined
  /** The most recent settled outcome, kept across rounds for the dealer's memory. */
  lastResult: BlackjackResult | undefined
  /** Consecutive player wins including the current settle. */
  playerWinStreak: number
  /** Consecutive player losses including the current settle. */
  playerLossStreak: number
}

/**
 * Build an empty replay accumulator.
 * @param initialPersona - persona before any `blackjack/persona` event.
 * @returns a fresh accumulator.
 */
export function emptyBlackjackFoldState(initialPersona: BlackjackPersona = DEFAULT_BLACKJACK_PERSONA): BlackjackFoldState {
  return {
    round: 0,
    phase: 'idle',
    deckSeed: undefined,
    player: handOf([]),
    dealer: handOf([]),
    emotion: 'calm',
    persona: initialPersona,
    banter: [],
    record: { wins: 0, losses: 0, pushes: 0, blackjacks: 0 },
    result: undefined,
    lastResult: undefined,
    playerWinStreak: 0,
    playerLossStreak: 0,
  }
}

/** Require a positive safe-integer round number. */
function positiveRound(value: unknown, field: string): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 1) {
    throw new Error(`blackjack ${field} must be a positive safe integer`)
  }
  return value
}

/** Require a non-empty string. */
function nonEmptyString(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`blackjack ${field} must be a non-empty string`)
  }
  return value
}

/** Require the event's round to be the current round. */
function requireRound(state: BlackjackFoldState, round: number, eventType: string): void {
  if (round !== state.round) {
    throw new Error(`blackjack ${eventType} targets round ${round} while round ${state.round} is current`)
  }
}

/** The deterministic next draw for the current table. */
export function nextDraw(seed: string, playerCards: number, dealerCards: number): Card {
  const card = shuffleDeck(FULL_DECK, seed)[playerCards + dealerCards]
  if (card === undefined) {
    throw new Error('blackjack deck exhausted: more draws than 52 cards')
  }
  return card
}

/** Validate that the last card of a full hand is the next seeded draw. */
function validateDraw(state: BlackjackFoldState, hand: readonly Card[], subject: string): void {
  const seed = state.deckSeed
  if (seed === undefined) throw new Error(`blackjack ${subject} draw without a deck seed`)
  const drawn = hand[hand.length - 1]
  const expected = nextDraw(seed, state.player.cards.length, state.dealer.cards.length)
  if (drawn === undefined || drawn.suit !== expected.suit || drawn.rank !== expected.rank) {
    throw new Error(`blackjack ${subject} draw diverges from the seeded deck order`)
  }
}

/**
 * Fold one session event into the accumulator. Non-blackjack events pass
 * through untouched; malformed blackjack events throw with a precise reason.
 * @param state - mutable accumulator (in-place).
 * @param event - the next committed session event.
 * @returns the same accumulator, updated.
 */
export function applyBlackjackEvent(state: BlackjackFoldState, event: SessionEvent): BlackjackFoldState {
  switch (event.type) {
    case 'blackjack/game-start': {
      if (state.phase !== 'idle' && state.phase !== 'settled') {
        throw new Error(`blackjack game-start during "${state.phase}" (round ${state.round} unclosed)`)
      }
      const data = event.data
      const round = positiveRound(data.round, 'game-start round')
      if (round !== state.round + 1) {
        throw new Error(`blackjack game-start round ${round} must follow round ${state.round}`)
      }
      const deckSeed = nonEmptyString(data.deckSeed, 'game-start deckSeed')
      const dealt = deal(deckSeed)
      state.round = round
      state.deckSeed = deckSeed
      state.player = dealt.player
      state.dealer = dealt.dealer
      state.phase = 'player-turn'
      // A new round clears the current verdict — the view must not carry last
      // round's banner into the fresh table. `lastResult` (the dealer's
      // memory) survives across rounds.
      state.result = undefined
      return state
    }
    case 'blackjack/hit': {
      requireRound(state, positiveRound(event.data.round, 'hit round'), 'hit')
      if (state.phase !== 'player-turn') {
        throw new Error(`blackjack hit during "${state.phase}"`)
      }
      const player = event.data.player
      if (!Array.isArray(player)) throw new Error('blackjack hit player must be an array of cards')
      if (player.length !== state.player.cards.length + 1) {
        throw new Error('blackjack hit hand must gain exactly one card')
      }
      validateDraw(state, player, 'player')
      state.player = handOf(player)
      return state
    }
    case 'blackjack/stand': {
      requireRound(state, positiveRound(event.data.round, 'stand round'), 'stand')
      if (state.phase !== 'player-turn') {
        throw new Error(`blackjack stand during "${state.phase}"`)
      }
      if (event.data.playerTotal !== state.player.total) {
        throw new Error(`blackjack stand playerTotal ${event.data.playerTotal} diverges from the folded ${state.player.total}`)
      }
      state.phase = 'dealer-turn'
      return state
    }
    case 'blackjack/dealer-hit': {
      requireRound(state, positiveRound(event.data.round, 'dealer-hit round'), 'dealer-hit')
      if (state.phase !== 'dealer-turn') {
        throw new Error(`blackjack dealer-hit during "${state.phase}"`)
      }
      const dealer = event.data.dealer
      if (!Array.isArray(dealer)) throw new Error('blackjack dealer-hit dealer must be an array of cards')
      switch (event.data.decision) {
        case 'hit': {
          if (dealer.length !== state.dealer.cards.length + 1) {
            throw new Error('blackjack dealer hit hand must gain exactly one card')
          }
          validateDraw(state, dealer, 'dealer')
          break
        }
        case 'stand': {
          if (dealer.length !== state.dealer.cards.length) {
            throw new Error('blackjack dealer stand must carry the unchanged dealer hand')
          }
          const unchanged = dealer.every((card: Card, index: number) => {
            const prior = state.dealer.cards[index]
            return prior !== undefined && card.suit === prior.suit && card.rank === prior.rank
          })
          if (!unchanged) throw new Error('blackjack dealer stand must carry the unchanged dealer hand')
          break
        }
        default:
          throw new Error(`blackjack dealer-hit decision must be hit or stand, got ${String(event.data.decision)}`)
      }
      state.dealer = handOf(dealer)
      return state
    }
    case 'blackjack/settle': {
      requireRound(state, positiveRound(event.data.round, 'settle round'), 'settle')
      if (state.phase !== 'player-turn' && state.phase !== 'dealer-turn') {
        throw new Error(`blackjack settle during "${state.phase}"`)
      }
      if (event.data.playerTotal !== state.player.total || event.data.dealerTotal !== state.dealer.total) {
        throw new Error('blackjack settle totals diverge from the folded hands')
      }
      const expected = settle(state.player, state.dealer)
      if (event.data.result !== expected) {
        throw new Error(`blackjack settle result "${event.data.result}" diverges from the rules (${expected})`)
      }
      state.phase = 'settled'
      state.result = event.data.result
      state.lastResult = event.data.result
      const direction = resultDirection(event.data.result)
      if (direction === 'win') {
        state.playerWinStreak += 1
        state.playerLossStreak = 0
      } else if (direction === 'loss') {
        state.playerLossStreak += 1
        state.playerWinStreak = 0
      } else {
        state.playerWinStreak = 0
        state.playerLossStreak = 0
      }
      const record: BlackjackRecord = {
        wins: state.record.wins + (event.data.result === 'player-win' || event.data.result === 'player-blackjack' ? 1 : 0),
        losses: state.record.losses + (event.data.result === 'dealer-win' ? 1 : 0),
        pushes: state.record.pushes + (event.data.result === 'push' ? 1 : 0),
        blackjacks: state.record.blackjacks + (event.data.result === 'player-blackjack' ? 1 : 0),
      }
      state.record = record
      state.emotion = foldEmotion(state.emotion, event.data.result, state.playerWinStreak, state.playerLossStreak)
      return state
    }
    case 'blackjack/emotion': {
      if (state.phase !== 'settled') {
        throw new Error(`blackjack emotion during "${state.phase}"`)
      }
      if (event.data.emotion !== state.emotion) {
        throw new Error(`blackjack emotion event "${event.data.emotion}" diverges from the folded "${state.emotion}"`)
      }
      return state
    }
    case 'blackjack/persona': {
      const data = event.data
      const persona = data.persona as unknown
      try {
        assertPersona(persona as BlackjackPersona)
      } catch {
        throw new Error(`blackjack persona event carries an unknown persona "${String(persona)}"`)
      }
      state.persona = persona as BlackjackPersona
      return state
    }
    case 'blackjack/banter': {
      const data = event.data
      if (data.round !== undefined) requireRound(state, positiveRound(data.round, 'banter round'), 'banter')
      // Runtime guard for malformed payloads; the typed union is widened to
      // unknown so the always-true literal comparison cannot be elided.
      const from = data.from as unknown
      if (from !== 'player' && from !== 'dealer') {
        throw new Error(`blackjack banter from must be player or dealer, got ${String(from)}`)
      }
      const content = nonEmptyString(data.content, 'banter content')
      state.banter = [...state.banter.slice(-(MAX_BANTER_HISTORY - 1)), { from: data.from, content }]
      return state
    }
    default:
      return state
  }
}

/**
 * Fold a full event log into the current blackjack state.
 * @param events - committed session events in seq order.
 * @returns a fresh accumulator over the log.
 */
export function foldBlackjack(events: readonly SessionEvent[]): BlackjackFoldState {
  const state = emptyBlackjackFoldState()
  for (const event of events) applyBlackjackEvent(state, event)
  return state
}

/** Project one folded state into the caller-visible view. */
export function blackjackView(state: BlackjackFoldState): BlackjackView {
  return {
    round: state.round,
    phase: state.phase,
    player: state.player,
    dealer: state.dealer,
    // The hole card stays face-down during the player's turn; the moment the
    // player stands the dealer plays face-up, so the player reads the dealer's
    // total as the draws land (and the settled board keeps it revealed).
    dealerHidden: state.phase === 'player-turn',
    emotion: state.emotion,
    persona: state.persona,
    banter: [...state.banter],
    record: { ...state.record },
    ...(state.result ? { result: state.result } : {}),
  }
}
