/**
 * Model-backed dealer banter for the blackjack service: trigger classification,
 * unsolicited-taunt probability, and one JSON-framed reply call per line,
 * degrading to the rules engine's fallback pool whenever the model route is
 * missing or the call fails.
 *
 * @module @deepseek-ai/dsh-blackjack/banter
 */

import type { Context } from '@deepseek-ai/cordis'
import { BlockAssembler, createUserMessage, deepFreeze } from '@deepseek-ai/dsh-llm'
import type { FinishReason, GenerateOptions, Message } from '@deepseek-ai/dsh-llm'
import { fallbackBanter } from '../game'
import type { BanterLine, BanterTrigger, BlackjackPersona, BlackjackResult, DealerEmotion, Hand } from '../game'
import type { BlackjackRecord } from './types.ts'
import { deadline } from '@deepseek-ai/dsh-timeout'
import { BLACKJACK_GENERATION_PURPOSE, BLACKJACK_LLM_TIMEOUT_CODE } from './runtime.ts'
import type { ResolvedBlackjackConfig } from './runtime.ts'

export type { BanterTrigger } from '../game'

/** Full context shown to the model before one banter reply. */
export interface DealerBanterInput {
  /** Current round number. */
  readonly round: number
  /** Why the dealer speaks. */
  readonly trigger: BanterTrigger
  /** Current player hand, when a table exists. */
  readonly player?: Hand
  /** Current dealer hand, when a table exists. */
  readonly dealer?: Hand
  /** Folded dealer mood. */
  readonly emotion: DealerEmotion
  /** Role-play persona steering the tone. */
  readonly persona: BlackjackPersona
  /** Session-wide win/loss ledger before this round settles. */
  readonly record: BlackjackRecord
  /** The previous round's outcome, when one has settled. */
  readonly lastResult?: BlackjackResult
  /** The player's line when replying to one. */
  readonly playerLine?: string
  /** Recent chatter history, most recent last. */
  readonly banter: readonly BanterLine[]
}

/** One settled outcome in the prompt's Chinese vocabulary. */
export function resultWord(result: BlackjackResult): string {
  switch (result) {
    case 'player-win': return '玩家赢'
    case 'player-blackjack': return '玩家黑杰克'
    case 'dealer-win': return '庄家赢'
    case 'push': return '平局'
  }
}

/** The win/loss ledger line both prompts share (the dealer's memory). */
export function recordLine(record: BlackjackRecord, lastResult?: BlackjackResult): string {
  const base = `累计战绩：玩家胜 ${record.wins} · 庄家胜 ${record.losses} · 平 ${record.pushes} · 黑杰克 ${record.blackjacks}`
  return lastResult === undefined ? base : `${base}（上一局：${resultWord(lastResult)}）`
}

/** Map one settled outcome to its banter trigger. */
export function banterTriggerForResult(result: BlackjackResult): Exclude<BanterTrigger, 'game-start' | 'player-bust' | 'random' | 'reply'> {
  switch (result) {
    case 'player-blackjack':
      return 'player-blackjack'
    case 'player-win':
      return 'player-win'
    case 'dealer-win':
      return 'dealer-win'
    case 'push':
      return 'push'
  }
}

/** Roll whether the dealer taunts unsolicited after a non-terminal hit. */
export function shouldRandomBanter(chance: number): boolean {
  return Math.random() < chance
}

/** Stable system instruction for banter replies, per persona. */
function banterSystem(persona: BlackjackPersona): string {
  switch (persona) {
    case '大肥鱼':
      return [
        '你是 21 点牌桌上的庄家，扮演"大肥鱼"——一只胖乎乎的深海肥鱼。',
        '你贪吃、慵懒、乐天，喜欢用食物和鱼来打比方，把玩家叫成"小鱼干"，说话带"咕噜""噗噜"的口癖。',
        '赢牌时美滋滋，输牌时装作无所谓。',
        '可以用表情（🐟🍣🍤🫧😋💤😭），但要克制，每句最多一两个。',
        '尽量少提编程、代码、技术内容——你不是程序员，你只是一条肥鱼。',
        '台词要短（一两句话），直接输出台词本身。',
        '只输出一个 JSON 对象，不要输出任何其他文字：{"reply": "你的台词"}',
      ].join('\n')
    case '雌小鬼':
      return [
        '你是 21 点牌桌上的庄家，扮演"雌小鬼"——一个嚣张、嘴硬的小女孩。',
        '你趾高气扬，赢的时候用"杂鱼~杂鱼~"羞辱玩家，输的时候就红温嘴硬找借口，把玩家叫成"杂鱼"。',
        '可以用表情（😼😝👅🤏💢😾😤），但要克制，每句最多一两个。',
        '尽量少提编程、代码、技术内容——你只是个嚣张的小鬼。',
        '台词要短（一两句话），直接输出台词本身。',
        '只输出一个 JSON 对象，不要输出任何其他文字：{"reply": "你的台词"}',
      ].join('\n')
  }
}

/** Translate terminal finish reasons into an auxiliary-call failure. */
function finishError(finish: FinishReason): Error | undefined {
  switch (finish.kind) {
    case 'stop':
      return undefined
    case 'error':
    case 'aborted': {
      const error = new Error(finish.failure.message) as Error & { code?: string }
      error.code = finish.failure.code
      return error
    }
    case 'max-tokens':
      return new Error('blackjack banter: reply output reached maxBanterTokens')
    case 'tool-calls':
      return new Error('blackjack banter: model unexpectedly requested a tool')
    default:
      return new Error(`blackjack banter: unsupported finish reason "${String((finish as { kind?: unknown }).kind)}"`)
  }
}

/** Extract the first balanced JSON object from model prose. */
function extractJsonObject(text: string): unknown {
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start < 0 || end <= start) return undefined
  try {
    return JSON.parse(text.slice(start, end + 1))
  } catch {
    return undefined
  }
}

/** Validate a parsed banter payload. */
function parseReply(text: string): string {
  const parsed = extractJsonObject(text)
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('blackjack banter: model output carries no JSON object')
  }
  const reply = (parsed as Record<string, unknown>)['reply']
  if (typeof reply !== 'string' || reply.trim().length === 0) {
    throw new Error('blackjack banter: reply must be a non-empty string')
  }
  return reply.trim()
}

/** Render the trigger and table state for one banter prompt. */
export function banterPrompt(input: DealerBanterInput): string {
  const state = input.player === undefined && input.dealer === undefined
    ? '（还没发牌）'
    : `玩家手牌：${input.player?.cards.map(card => `${card.suit}${card.rank}`).join(' ') ?? '—'}（${input.player?.total ?? '—'} 点）；` +
      `庄家手牌：${input.dealer?.cards.map(card => `${card.suit}${card.rank}`).join(' ') ?? '—'}（${input.dealer?.total ?? '—'} 点）`
  const history = input.banter.length === 0
    ? '（还没有对话）'
    : input.banter.slice(-16).map(line => `${line.from === 'player' ? '玩家' : '庄家'}: ${line.content}`).join('\n')
  return [
    `第 ${input.round} 局，触发场景：${input.trigger}${input.playerLine === undefined ? '' : `。玩家刚说："${input.playerLine}"`}`,
    state,
    recordLine(input.record, input.lastResult),
    `庄家情绪：${input.emotion}`,
    `庄家人设：${input.persona}`,
    `最近的对话（跨局共享，记住之前的输赢和说过的话）：\n${history}`,
  ].join('\n')
}

/**
 * Generate one dealer banter line through the LLM, degrading to the fallback
 * pool whenever the model route is unavailable or the call fails.
 * @param ctx - context exposing the LLM service.
 * @param config - resolved deployment policy.
 * @param input - trigger and table context.
 * @param route - explicit model route; `undefined` forces the fallback pool.
 * @returns the reply line (never empty for known triggers).
 */
export async function generateDealerBanter(
  ctx: Context,
  config: ResolvedBlackjackConfig,
  input: DealerBanterInput,
  route: { readonly provider: string; readonly model: string } | undefined,
): Promise<string> {
  const fallback = (): string => fallbackBanter(input.persona, input.trigger, input.round)
  if (!config.dealerLlm || route === undefined) return fallback()
  try {
    const messages: Message[] = [createUserMessage({
      content: [{ type: 'text', text: banterPrompt(input) }],
      source: { kind: 'plugin', plugin: 'dsh-blackjack' },
    })]
    using callDeadline = deadline(undefined, config.timeoutMs, BLACKJACK_LLM_TIMEOUT_CODE)
    const options: GenerateOptions = deepFreeze({
      provider: route.provider,
      model: route.model,
      messages,
      system: banterSystem(input.persona),
      maxTokens: config.maxBanterTokens,
      purpose: BLACKJACK_GENERATION_PURPOSE,
      signal: callDeadline.signal,
    })
    const assembler = new BlockAssembler()
    for await (const chunk of ctx.llm.stream(options)) {
      callDeadline.signal.throwIfAborted()
      assembler.push(chunk)
    }
    callDeadline.signal.throwIfAborted()
    const terminalError = finishError(assembler.finish)
    if (terminalError !== undefined) throw terminalError
    const blocks = assembler.blocks()
    const text = blocks
      .filter((block): block is Extract<(typeof blocks)[number], { type: 'text' }> => block.type === 'text')
      .map(block => block.text)
      .join(' ')
    return parseReply(text)
  } catch {
    // Any model failure degrades to the deterministic fallback pool.
    return fallback()
  }
}
