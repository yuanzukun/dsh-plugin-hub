/**
 * Model-backed dealer decisions for the blackjack service: one auxiliary
 * LLM call per dealer turn, framed as JSON, with a local-policy fallback
 * whenever the route is missing, the model fails, times out, or returns
 * unusable output. The fallback reuses the rules engine's own
 * {@link dealerPolicy} (stand on 17, hit below) so a degraded dealer still
 * plays legal blackjack.
 *
 * @module @deepseek-ai/dsh-blackjack/dealer
 */

import type { Context } from '@deepseek-ai/cordis'
import { BlockAssembler, createUserMessage, deepFreeze } from '@deepseek-ai/dsh-llm'
import type { FinishReason, GenerateOptions, Message } from '@deepseek-ai/dsh-llm'
import { dealerPolicy } from '../game'
import type { BanterLine, BlackjackPersona, BlackjackResult, DealerEmotion, Hand } from '../game'
import { deadline } from '@deepseek-ai/dsh-timeout'
import { BLACKJACK_GENERATION_PURPOSE, BLACKJACK_LLM_TIMEOUT_CODE } from './runtime.ts'
import type { ResolvedBlackjackConfig } from './runtime.ts'
import { recordLine } from './banter.ts'
import type { BlackjackRecord } from './types.ts'

/** Full table state shown to the model before one dealer decision. */
export interface DealerDecisionInput {
  /** Current round number. */
  readonly round: number
  /** Current player hand. */
  readonly player: Hand
  /** Current dealer hand. */
  readonly dealer: Hand
  /** Folded dealer mood. */
  readonly emotion: DealerEmotion
  /** Role-play persona steering the tone. */
  readonly persona: BlackjackPersona
  /** Session-wide win/loss ledger before this round settles. */
  readonly record: BlackjackRecord
  /** The previous round's outcome, when one has settled. */
  readonly lastResult?: BlackjackResult
  /** Recent chatter history, most recent last. */
  readonly banter: readonly BanterLine[]
}

/** One resolved dealer decision, LLM-backed or policy-degraded. */
export interface DealerDecisionResult {
  /** Whether the dealer draws or passes. */
  readonly action: 'hit' | 'stand'
  /** Why the dealer chose this action (model reason or policy label). */
  readonly reason: string
  /** Model route that produced the decision; absent when degraded. */
  readonly llm?: { readonly provider: string; readonly model: string }
}

/** Stable system instruction for dealer decisions, per persona. */
function decisionSystem(persona: BlackjackPersona): string {
  const character = persona === '大肥鱼'
    ? '你扮演"大肥鱼"——一只胖乎乎的深海肥鱼：贪吃、慵懒、乐天，把玩家叫成"小鱼干"，说话带"咕噜""噗噜"口癖，喜欢用食物和鱼打比方，尽量少提编程和技术。'
    : '你扮演"雌小鬼"——一个嚣张、嘴硬的小女孩：趾高气扬，把玩家叫成"杂鱼"，赢的时候嚣张，输的时候嘴硬，尽量少提编程和技术。'
  return [
    '你是 21 点牌桌上的庄家，正在决定自己是否要牌。',
    character,
    '规则：正常策略是 17 点及以上停牌（含软 17）。你可以按人设适度偏离策略来制造节目效果，但不要为了效果连续冒险到爆牌。',
    '只输出一个 JSON 对象，不要输出任何其他文字、Markdown 或解释：{"action": "hit" 或 "stand", "reason": "一句话理由（中文，符合人设）"}',
  ].join('\n')
}

/** Translate terminal finish reasons into an auxiliary-call failure. */
function finishError(finish: FinishReason): Error | undefined {
  switch (finish.kind) {
    case 'stop':
      return undefined
    case 'error':
    case 'aborted': {
      const error = new Error(finish.failure.message) as Error & { code?: string }
      error.code = finish.failure.code
      return error
    }
    case 'max-tokens':
      return new Error('blackjack dealer: decision output reached maxDecisionTokens')
    case 'tool-calls':
      return new Error('blackjack dealer: model unexpectedly requested a tool')
    default:
      return new Error(`blackjack dealer: unsupported finish reason "${String((finish as { kind?: unknown }).kind)}"`)
  }
}

/** Extract the first balanced JSON object from model prose. */
function extractJsonObject(text: string): unknown {
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start < 0 || end <= start) return undefined
  try {
    return JSON.parse(text.slice(start, end + 1))
  } catch {
    return undefined
  }
}

/** Validate a parsed dealer decision payload. */
function parseDecision(text: string): { action: 'hit' | 'stand'; reason: string } {
  const parsed = extractJsonObject(text)
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('blackjack dealer: model output carries no JSON object')
  }
  const record = parsed as Record<string, unknown>
  const action = record['action']
  if (action !== 'hit' && action !== 'stand') {
    throw new Error(`blackjack dealer: action must be hit or stand, got ${String(action)}`)
  }
  const reason = record['reason']
  return {
    action,
    reason: typeof reason === 'string' && reason.length > 0 ? reason : '（模型没有说明理由）',
  }
}

/** Render the full table state for one decision prompt. */
export function decisionPrompt(input: DealerDecisionInput): string {
  const banter = input.banter.length === 0
    ? '（还没有对话）'
    : input.banter.slice(-16).map(line => `${line.from === 'player' ? '玩家' : '庄家'}: ${line.content}`).join('\n')
  return [
    `第 ${input.round} 局。`,
    `玩家手牌：${input.player.cards.map(card => `${card.suit}${card.rank}`).join(' ')}（${input.player.total} 点）`,
    `庄家手牌：${input.dealer.cards.map(card => `${card.suit}${card.rank}`).join(' ')}（${input.dealer.total} 点）`,
    recordLine(input.record, input.lastResult),
    `庄家情绪：${input.emotion}`,
    `庄家人设：${input.persona}`,
    `最近的对话（跨局共享，记住之前的输赢和说过的话）：\n${banter}`,
  ].join('\n')
}

/**
 * Resolve one dealer decision through the LLM, degrading to the local
 * policy whenever the model route is unavailable or the call fails.
 * @param ctx - context exposing the LLM service.
 * @param config - resolved deployment policy.
 * @param input - current table state.
 * @param route - explicit model route; `undefined` forces the policy path.
 * @returns the decision; `llm` is present only on a successful model call.
 */
export async function dealerDecide(
  ctx: Context,
  config: ResolvedBlackjackConfig,
  input: DealerDecisionInput,
  route: { readonly provider: string; readonly model: string } | undefined,
): Promise<DealerDecisionResult> {
  const policy: DealerDecisionResult = {
    action: dealerPolicy(input.dealer).kind,
    reason: '本地策略：17 点及以上停牌，以下要牌',
  }
  if (!config.dealerLlm || route === undefined) return policy
  try {
    const messages: Message[] = [createUserMessage({
      content: [{ type: 'text', text: decisionPrompt(input) }],
      source: { kind: 'plugin', plugin: 'dsh-blackjack' },
    })]
    using callDeadline = deadline(undefined, config.timeoutMs, BLACKJACK_LLM_TIMEOUT_CODE)
    const options: GenerateOptions = deepFreeze({
      provider: route.provider,
      model: route.model,
      messages,
      system: decisionSystem(input.persona),
      maxTokens: config.maxDecisionTokens,
      purpose: BLACKJACK_GENERATION_PURPOSE,
      signal: callDeadline.signal,
    })
    const assembler = new BlockAssembler()
    for await (const chunk of ctx.llm.stream(options)) {
      callDeadline.signal.throwIfAborted()
      assembler.push(chunk)
    }
    callDeadline.signal.throwIfAborted()
    const terminalError = finishError(assembler.finish)
    if (terminalError !== undefined) throw terminalError
    const blocks = assembler.blocks()
    const text = blocks
      .filter((block): block is Extract<(typeof blocks)[number], { type: 'text' }> => block.type === 'text')
      .map(block => block.text)
      .join(' ')
    const decision = parseDecision(text)
    return { action: decision.action, reason: decision.reason, llm: { provider: route.provider, model: route.model } }
  } catch {
    // Any model failure — timeout, finish error, malformed JSON — degrades
    // to the deterministic house policy; the round stays playable.
    return policy
  }
}
