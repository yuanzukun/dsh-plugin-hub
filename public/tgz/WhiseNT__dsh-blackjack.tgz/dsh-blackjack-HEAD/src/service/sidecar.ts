/**
 * Plugin-owned durable store for the blackjack event stream.
 *
 * Blackjack state no longer rides the harness session log: harness builds
 * refuse to resume a session whose log carries unknown non-ignorable events
 * (rc.6 has no out-of-repo event registration API), and blackjack events are
 * opaque to every harness fold anyway. Each session's `blackjack/*` events
 * are therefore persisted in a JSONL sidecar under the dsh data root
 * (`$DSH_HOME/blackjack/<sessionId>.jsonl`), keyed by the session id so
 * rounds still replay and fork identically across restarts.
 *
 * Legacy sessions (written while blackjack events still landed in the
 * harness log) are migrated once: the service replays the events the harness
 * recovered from its log into the sidecar on first load.
 *
 * @module @deepseek-ai/dsh-blackjack/sidecar
 */

import { appendFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import type { SessionEventMap } from '@deepseek-ai/dsh-session/types'
import type { BlackjackSessionEventType } from './types.ts'

/** One durable blackjack event as persisted plugin-side. */
export type BlackjackSidecarEvent = {
  [K in BlackjackSessionEventType]: {
    readonly type: K
    readonly seq: number
    readonly time: number
    readonly data: SessionEventMap[K]
  }
}[BlackjackSessionEventType]

/** Directory holding every session's blackjack sidecar, under the data root. */
const SIDECAR_DIRNAME = 'blackjack'

/**
 * Resolve the dsh data root: `$DSH_HOME` when set, otherwise `~/.dsh` (the
 * harness's own default data location).
 */
export function defaultBlackjackDataRoot(): string {
  const env = process.env.DSH_HOME
  return typeof env === 'string' && env.length > 0 ? env : join(homedir(), '.dsh')
}

/** Encode one session id as a single safe path segment (mirrors the harness). */
function encodeSegment(raw: string): string {
  let out = ''
  for (const ch of raw) {
    out += /^[A-Za-z0-9._-]$/.test(ch)
      ? ch
      : `~${ch.codePointAt(0)!.toString(16).toUpperCase().padStart(4, '0')}`
  }
  return out
}

/** Parse one sidecar line; malformed lines fail loud rather than corrupt the fold. */
function parseLine(line: string): BlackjackSidecarEvent {
  let parsed: unknown
  try {
    parsed = JSON.parse(line)
  } catch (error) {
    throw new Error(`blackjack sidecar holds a malformed line: ${String(error)}`)
  }
  if (typeof parsed !== 'object' || parsed === null) throw new Error('blackjack sidecar line must be an event object')
  const event = parsed as Record<string, unknown>
  if (typeof event.type !== 'string' || !event.type.startsWith('blackjack/')) {
    throw new Error('blackjack sidecar line must carry a blackjack event type')
  }
  if (typeof event.seq !== 'number' || !Number.isSafeInteger(event.seq) || event.seq < 0) {
    throw new Error('blackjack sidecar line must carry a non-negative integer seq')
  }
  if (typeof event.time !== 'number' || !Number.isFinite(event.time) || event.time < 0) {
    throw new Error('blackjack sidecar line must carry a non-negative time')
  }
  if (event.data === undefined || event.data === null) {
    throw new Error('blackjack sidecar line must carry event data')
  }
  return parsed as BlackjackSidecarEvent
}

/**
 * JSONL append-only store of one session's blackjack events. Loads are
 * cached per instance; appends extend the file and the in-memory view in one
 * step, so seq stays contiguous without re-reading.
 */
export class BlackjackSidecar {
  private events: BlackjackSidecarEvent[] | undefined

  private constructor(readonly file: string) {}

  /** Build the sidecar for one session under the given data root. */
  static forSession(sessionId: string, dataRoot: string = defaultBlackjackDataRoot()): BlackjackSidecar {
    return new BlackjackSidecar(join(dataRoot, SIDECAR_DIRNAME, `${encodeSegment(sessionId)}.jsonl`))
  }

  /** Read every durable event in order; an absent sidecar yields the empty log. */
  load(): BlackjackSidecarEvent[] {
    if (this.events !== undefined) return this.events
    let events: BlackjackSidecarEvent[] = []
    let text: string
    try {
      text = readFileSync(this.file, 'utf8')
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        this.events = events
        return events
      }
      throw error
    }
    for (const line of text.split('\n')) {
      if (line.length === 0) continue
      events.push(parseLine(line))
    }
    this.events = events
    return events
  }

  /**
   * Migrate legacy `blackjack/*` events recovered from a harness session log
   * into the sidecar. Only the first migration writes: once events are
   * durable plugin-side, a recovered harness log contributes nothing more.
   * @param legacy - blackjack events from the session log, in seq order.
   * @returns the sidecar's full event list after the migration.
   */
  migrate(legacy: readonly SessionEvent[]): BlackjackSidecarEvent[] {
    const events = this.load()
    if (events.length > 0) return events
    const migrated: BlackjackSidecarEvent[] = []
    for (const event of legacy) {
      if (typeof event.type !== 'string' || !event.type.startsWith('blackjack/')) continue
      migrated.push({
        type: event.type as BlackjackSessionEventType,
        seq: event.seq,
        time: event.time,
        data: event.data,
      } as BlackjackSidecarEvent)
    }
    if (migrated.length === 0) return events
    mkdirSync(dirname(this.file), { recursive: true })
    writeFileSync(this.file, `${migrated.map(event => JSON.stringify(event)).join('\n')}\n`)
    this.events = migrated
    return migrated
  }

  /** Append one event and extend the in-memory log in the same step. */
  append<T extends BlackjackSessionEventType>(type: T, data: SessionEventMap[T]): BlackjackSidecarEvent {
    const events = this.load()
    const seq = events.length > 0 ? events[events.length - 1]!.seq + 1 : 0
    const event = { type, seq, time: Date.now(), data } as BlackjackSidecarEvent
    mkdirSync(dirname(this.file), { recursive: true })
    appendFileSync(this.file, `${JSON.stringify(event)}\n`)
    events.push(event)
    return event
  }
}
