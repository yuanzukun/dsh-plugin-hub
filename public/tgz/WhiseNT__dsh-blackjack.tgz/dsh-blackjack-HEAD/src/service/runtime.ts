/**
 * Runtime constructors and configuration policy for the blackjack domain.
 * @module @deepseek-ai/dsh-blackjack/runtime
 */

import { HarnessError, deepFreeze } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions } from '@deepseek-ai/dsh-llm'
import { MAX_TIMER_DELAY_MS } from '@deepseek-ai/dsh-timeout'
import { BLACKJACK_PERSONA_LIST, DEFAULT_BLACKJACK_PERSONA } from '../game'
import type { BlackjackConfig, BlackjackPersona } from './types.ts'

/** Timeout code stamped onto blackjack auxiliary LLM calls. */
export const BLACKJACK_LLM_TIMEOUT_CODE = 'BLACKJACK_LLM_TIMEOUT'

/**
 * Auxiliary purpose tag stamped on blackjack LLM calls. `GenerateOptions.purpose`
 * is a closed literal union in dsh-llm that the runtime never reads (it is a
 * documentation/telemetry classification), so the tag is widened through the
 * union with one annotated cast until dsh-llm adds the purpose formally.
 */
export const BLACKJACK_GENERATION_PURPOSE = 'blackjack' as unknown as Exclude<GenerateOptions['purpose'], undefined>

/** Cap on the folded banter history exposed through the view. */
export const MAX_BANTER_HISTORY = 50

/** Stable error codes returned by the blackjack domain boundary. */
export type BlackjackErrorCode =
  | 'BLACKJACK_AGENT_NOT_LIVE'
  | 'BLACKJACK_ROUND_IN_PROGRESS'
  | 'BLACKJACK_NO_ROUND'
  | 'BLACKJACK_INVALID_ACTION'
  | 'BLACKJACK_EMPTY_BANTER'
  | 'BLACKJACK_INVALID_CONFIG'

/** Error thrown by the blackjack service boundary. */
export class BlackjackError extends HarnessError {
  /**
   * @param message - human-readable rejection reason.
   * @param code - stable machine-routable classification.
   */
  // Keep the constructor to narrow HarnessError's string code at this boundary.
  // oxlint-disable-next-line typescript/no-useless-constructor -- type-only narrowing
  constructor(message: string, code: BlackjackErrorCode) {
    super(message, code)
  }
}

/** The dealer personas accepted by deployment configuration. */
export const BLACKJACK_PERSONAS: readonly BlackjackPersona[] = BLACKJACK_PERSONA_LIST

/** Deployment defaults materialized when a config field is omitted. */
export const DEFAULT_BLACKJACK_CONFIG: ResolvedBlackjackConfig = deepFreeze({
  dealerPersona: DEFAULT_BLACKJACK_PERSONA,
  randomBanterChance: 0.3,
  maxDecisionTokens: 100,
  maxBanterTokens: 60,
  timeoutMs: 15000,
  dealerLlm: true,
})

/** Validated immutable deployment policy. */
export interface ResolvedBlackjackConfig {
  readonly dealerPersona: BlackjackPersona
  readonly randomBanterChance: number
  readonly maxDecisionTokens: number
  readonly maxBanterTokens: number
  readonly timeoutMs: number
  readonly dealerLlm: boolean
}

/** Complete configuration key set for direct construction validation. */
const CONFIG_KEYS: ReadonlySet<string> = new Set([
  'dealerPersona',
  'randomBanterChance',
  'maxDecisionTokens',
  'maxBanterTokens',
  'timeoutMs',
  'dealerLlm',
  'dataRoot',
])

/** Validate one positive integer limit. */
function assertPositiveInteger(name: string, value: number): void {
  if (!Number.isInteger(value) || value <= 0) {
    throw new BlackjackError(`blackjack: ${name} must be a positive integer`, 'BLACKJACK_INVALID_CONFIG')
  }
}

/**
 * Validate and detach deployment configuration.
 * @param config - untrusted plugin configuration; every field defaults.
 * @returns immutable resolved policy.
 */
export function resolveBlackjackConfig(config: BlackjackConfig = {}): ResolvedBlackjackConfig {
  const candidate: unknown = config
  if (candidate === null || typeof candidate !== 'object' || Array.isArray(candidate)) {
    throw new BlackjackError('blackjack: configuration must be an object', 'BLACKJACK_INVALID_CONFIG')
  }
  const value = candidate as BlackjackConfig
  for (const key of Object.keys(value)) {
    if (!CONFIG_KEYS.has(key)) throw new BlackjackError(`blackjack: unknown config key "${key}"`, 'BLACKJACK_INVALID_CONFIG')
  }
  const dealerPersona = value.dealerPersona ?? DEFAULT_BLACKJACK_CONFIG.dealerPersona
  if (!BLACKJACK_PERSONAS.includes(dealerPersona)) {
    throw new BlackjackError(`blackjack: dealerPersona must be one of ${BLACKJACK_PERSONAS.join('/')}`, 'BLACKJACK_INVALID_CONFIG')
  }
  const randomBanterChance = value.randomBanterChance ?? DEFAULT_BLACKJACK_CONFIG.randomBanterChance
  if (typeof randomBanterChance !== 'number' || !Number.isFinite(randomBanterChance)
    || randomBanterChance < 0 || randomBanterChance > 1) {
    throw new BlackjackError('blackjack: randomBanterChance must be a number in [0, 1]', 'BLACKJACK_INVALID_CONFIG')
  }
  const maxDecisionTokens = value.maxDecisionTokens ?? DEFAULT_BLACKJACK_CONFIG.maxDecisionTokens
  assertPositiveInteger('maxDecisionTokens', maxDecisionTokens)
  const maxBanterTokens = value.maxBanterTokens ?? DEFAULT_BLACKJACK_CONFIG.maxBanterTokens
  assertPositiveInteger('maxBanterTokens', maxBanterTokens)
  const timeoutMs = value.timeoutMs ?? DEFAULT_BLACKJACK_CONFIG.timeoutMs
  if (!Number.isInteger(timeoutMs) || timeoutMs <= 0 || timeoutMs > MAX_TIMER_DELAY_MS) {
    throw new BlackjackError(`blackjack: timeoutMs must be a positive integer no greater than ${MAX_TIMER_DELAY_MS}`, 'BLACKJACK_INVALID_CONFIG')
  }
  const dealerLlm = value.dealerLlm ?? DEFAULT_BLACKJACK_CONFIG.dealerLlm
  if (typeof dealerLlm !== 'boolean') {
    throw new BlackjackError('blackjack: dealerLlm must be a boolean', 'BLACKJACK_INVALID_CONFIG')
  }
  if (value.dataRoot !== undefined
    && (typeof value.dataRoot !== 'string' || value.dataRoot.length === 0)) {
    throw new BlackjackError('blackjack: dataRoot must be a non-empty string', 'BLACKJACK_INVALID_CONFIG')
  }
  return deepFreeze({ dealerPersona, randomBanterChance, maxDecisionTokens, maxBanterTokens, timeoutMs, dealerLlm })
}
