/**
 * Host-side vocabulary of the DeepSeek Blackjack service: RPC payloads, the
 * live table view, deployment configuration, and the durable session events
 * that reconstruct every round. Pure types only — no host-side imports
 * beyond the event map augmentation, so `./client` can project this module
 * to browser consumers with zero duplication.
 *
 * @module @deepseek-ai/dsh-blackjack/types
 */

import type {
  BanterLine,
  BlackjackPersona,
  BlackjackResult,
  Card,
  DealerEmotion,
  Hand,
} from '../game'
import type { SessionEventType } from '@deepseek-ai/dsh-session/types'

// Game vocabulary rides the same `./client` outlet so browser consumers can
// name one import site for the whole wire contract.
export type {
  BanterLine,
  BlackjackPersona,
  BlackjackResult,
  Card,
  DealerEmotion,
  Hand,
} from '../game'

/** Lifecycle phase of one round, mirrored from the event stream. */
export type BlackjackPhase =
  | 'idle'
  | 'player-turn'
  | 'dealer-turn'
  | 'settled'

/** Lifetime ledger across every settled round of the session. */
export interface BlackjackRecord {
  /** Rounds won by the player (including blackjacks). */
  readonly wins: number
  /** Rounds won by the dealer. */
  readonly losses: number
  /** Push rounds. */
  readonly pushes: number
  /** Natural 21 rounds, also counted inside `wins`. */
  readonly blackjacks: number
}

/**
 * Live table view returned by every service call. Derived entirely from the
 * session event log — the client can also rebuild it with {@link foldBlackjack}.
 */
export interface BlackjackView {
  /** Current round number; 0 before the first `start`. */
  readonly round: number
  /** Current round phase. */
  readonly phase: BlackjackPhase
  /** Current player hand (empty before the first deal). */
  readonly player: Hand
  /** Current dealer hand (empty before the first deal). */
  readonly dealer: Hand
  /** Whether the dealer's hole card is hidden from the player. */
  readonly dealerHidden: boolean
  /** Folded dealer mood. */
  readonly emotion: DealerEmotion
  /** The dealer's current role-play persona. */
  readonly persona: BlackjackPersona
  /** Dealer/player chatter history, most recent last. */
  readonly banter: readonly BanterLine[]
  /** Lifetime win/loss ledger. */
  readonly record: BlackjackRecord
  /** Settled outcome of the latest round, present once it settles. */
  readonly result?: BlackjackResult
}

/** Input of `start`: an optional explicit deck seed for deterministic replay. */
export interface BlackjackStartRequest {
  /**
   * Explicit seed controlling the deck order. Omitted seeds are random, so
   * every round deals a fresh unpredictable table; fixed seeds make rounds
   * reproducible for tests and replays.
   */
  readonly deckSeed?: string
}

/** Client-facing summary of one player hit. */
export interface BlackjackHitResult {
  /** Round the hit belonged to. */
  readonly round: number
  /** The updated player hand. */
  readonly player: Hand
  /** Whether the hit busted the player. */
  readonly bust: boolean
  /** Whether the bust forced an immediate settle of the round. */
  readonly settled: boolean
}

/** Client-facing summary of one stand (round settlement). */
export interface BlackjackStandResult {
  /** Round that settled. */
  readonly round: number
  /** Final outcome. */
  readonly result: BlackjackResult
  /** Final player total. */
  readonly playerTotal: number
  /** Final dealer total. */
  readonly dealerTotal: number
}

/** Input of `banter`: one line of player trash talk. */
export interface BlackjackBanterRequest {
  /** Non-empty player chatter, trimmed at the boundary. */
  readonly content: string
}

/** Result of `banter`: the dealer's reply line. */
export interface BlackjackBanterResult {
  /** Dealer reply, from the model or the fallback pool. */
  readonly reply: string
}

/** Input of `persona`: the player picks the dealer's role-play character. */
export interface BlackjackSetPersonaRequest {
  /** One of the shipped personas (`大肥鱼` / `雌小鬼`). */
  readonly persona: BlackjackPersona
}

/**
 * Deployment configuration of the blackjack plugin. Every field defaults, so
 * an empty config yields the 大肥鱼 dealer that banters on ~30% of hits.
 */
export interface BlackjackConfig {
  /** Initial dealer persona steering LLM decisions and banter. Default `大肥鱼`. */
  readonly dealerPersona?: BlackjackPersona
  /** Probability of an unsolicited random taunt after a non-terminal hit. Default `0.3`. */
  readonly randomBanterChance?: number
  /** Output-token cap of one dealer decision call. Default `100`. */
  readonly maxDecisionTokens?: number
  /** Output-token cap of one banter call. Default `60`. */
  readonly maxBanterTokens?: number
  /** End-to-end deadline of one auxiliary LLM call, in milliseconds. Default `15000`. */
  readonly timeoutMs?: number
  /** Whether the dealer and banter run through the LLM; false forces local policies. Default `true`. */
  readonly dealerLlm?: boolean
  /**
   * Data root holding the plugin's per-session sidecar store
   * (`<dataRoot>/blackjack/<sessionId>.jsonl`). Defaults to `$DSH_HOME` or
   * `~/.dsh`, mirroring the harness's own data location; tests override it
   * with a scratch directory.
   */
  readonly dataRoot?: string
}

/** Durable payload of a round-opening `blackjack/game-start` event. */
export interface BlackjackGameStartData {
  /** Positive round number, one past the previous round. */
  readonly round: number
  /** Deck seed controlling this round's deterministic shuffle. */
  readonly deckSeed: string
}

/** Durable payload of a `blackjack/hit` event (the full player hand). */
export interface BlackjackHitData {
  /** Round of the hit. */
  readonly round: number
  /** Complete player hand after the hit, in draw order. */
  readonly player: readonly Card[]
}

/** Durable payload of a `blackjack/stand` event. */
export interface BlackjackStandData {
  /** Round of the stand. */
  readonly round: number
  /** Player total at the moment of standing. */
  readonly playerTotal: number
}

/** Durable payload of one `blackjack/dealer-hit` event. */
export interface BlackjackDealerHitData {
  /** Round of the dealer action. */
  readonly round: number
  /** Complete dealer hand, in draw order (unchanged when standing). */
  readonly dealer: readonly Card[]
  /** Whether the dealer drew (`hit`) or passed (`stand`). */
  readonly decision: 'hit' | 'stand'
  /** Model route that produced the decision, when an LLM call succeeded. */
  readonly llm?: { readonly provider: string; readonly model: string }
}

/** Durable payload of a `blackjack/settle` event. */
export interface BlackjackSettleData {
  /** Round that settled. */
  readonly round: number
  /** Final outcome. */
  readonly result: BlackjackResult
  /** Final player total. */
  readonly playerTotal: number
  /** Final dealer total. */
  readonly dealerTotal: number
}

/** Durable payload of one `blackjack/banter` event. */
export interface BlackjackBanterData {
  /** Round the line belongs to; absent before the first deal. */
  readonly round?: number
  /** Speaker. */
  readonly from: 'player' | 'dealer'
  /** The spoken line. */
  readonly content: string
  /** Trigger classification (`player-bust`, `reply`, …), dealer lines only. */
  readonly trigger?: string
}

/** Durable payload of a `blackjack/emotion` event. */
export interface BlackjackEmotionData {
  /** The emotion the stream folded for this round. */
  readonly emotion: DealerEmotion
}

/** Durable payload of a `blackjack/persona` event. */
export interface BlackjackPersonaData {
  /** The persona the player picked for the dealer. */
  readonly persona: BlackjackPersona
}

/** The durable session event names owned by the blackjack plugin. */
export const BLACKJACK_SESSION_EVENT_TYPES = [
  'blackjack/game-start',
  'blackjack/hit',
  'blackjack/stand',
  'blackjack/dealer-hit',
  'blackjack/settle',
  'blackjack/banter',
  'blackjack/emotion',
  'blackjack/persona',
] as const

/** The session event types owned by the blackjack plugin. */
export type BlackjackSessionEventType = Extract<SessionEventType, `blackjack/${string}`>

declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /** A round opens: the deal is fully determined by `deckSeed`. */
    'blackjack/game-start': BlackjackGameStartData
    /** The player drew one card. */
    'blackjack/hit': BlackjackHitData
    /** The player passed; the dealer turn opens. */
    'blackjack/stand': BlackjackStandData
    /** The dealer drew one card, or passed early on an LLM call. */
    'blackjack/dealer-hit': BlackjackDealerHitData
    /** The round settled with a final outcome. */
    'blackjack/settle': BlackjackSettleData
    /** One line of chatter. */
    'blackjack/banter': BlackjackBanterData
    /** The folded dealer emotion after a settlement. */
    'blackjack/emotion': BlackjackEmotionData
    /** The player picked the dealer's role-play persona. */
    'blackjack/persona': BlackjackPersonaData
  }
}
