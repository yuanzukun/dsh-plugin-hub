/**
 * Package-owned durable blackjack-stream invariants: every `blackjack/*`
 * event must obey the strict fold — rounds open and close exactly once,
 * actions only during their phase, and every derived value consistent with
 * the deterministic rules engine. Violations reject the offending append.
 * @module @deepseek-ai/dsh-blackjack/invariant
 */

import type { Context } from '@deepseek-ai/cordis'
import type { InvariantFailure, InvariantInstaller } from '@deepseek-ai/dsh-invariants'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import { applyBlackjackEvent, emptyBlackjackFoldState } from './fold.ts'
import type { BlackjackFoldState } from './fold.ts'

const PACKAGE_NAME = '@deepseek-ai/dsh-blackjack'

/** Cordis companion plugin name. */
export const name = 'blackjack-invariant'
/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

/** Copy the independent fold before validating one candidate event. */
function cloneState(state: BlackjackFoldState): BlackjackFoldState {
  return {
    round: state.round,
    phase: state.phase,
    deckSeed: state.deckSeed,
    player: state.player,
    dealer: state.dealer,
    emotion: state.emotion,
    persona: state.persona,
    banter: [...state.banter],
    record: { ...state.record },
    result: state.result,
    lastResult: state.lastResult,
    playerWinStreak: state.playerWinStreak,
    playerLossStreak: state.playerLossStreak,
  }
}

/** Apply one event through the strict fold and attribute failures. */
function applyChecked(state: BlackjackFoldState, event: SessionEvent, fail: InvariantFailure): void {
  try {
    applyBlackjackEvent(state, event)
  } catch (error) {
    /* v8 ignore next -- the strict fold throws Error instances */
    const message = error instanceof Error ? error.message : String(error)
    fail(`session event ${event.seq} violates the durable blackjack stream: ${message}`)
  }
}

/** Install an independent incremental fold over every attached session. */
const install: InvariantInstaller = Object.assign((ctx: Context, fail: InvariantFailure) => {
  const states = new WeakMap<Session, BlackjackFoldState>()
  const staged = new WeakMap<SessionEvent, { session: Session; state: BlackjackFoldState }>()

  const seed = (session: Session): BlackjackFoldState => {
    const state = emptyBlackjackFoldState()
    for (const event of session.events) applyChecked(state, event, fail)
    states.set(session, state)
    return state
  }
  /* v8 ignore next -- session/event always follows list() or session/created seeding */
  const stateFor = (session: Session): BlackjackFoldState => states.get(session) ?? seed(session)

  for (const session of ctx.sessions.list()) seed(session)
  ctx.on('session/created', (session) => { seed(session) }, { global: true })
  ctx.on('internal/dispatch', (_mode, eventName, args) => {
    if (eventName !== 'session/event') return
    const [session, event] = args as [Session, SessionEvent]
    const state = cloneState(stateFor(session))
    applyChecked(state, event, fail)
    staged.set(event, { session, state })
  }, { global: true })
  ctx.on('session/event', (session, event) => {
    const candidate = staged.get(event)
    /* v8 ignore next 2 -- internal/dispatch stages the exact callback arguments */
    if (candidate === undefined || candidate.session !== session) {
      return fail('session/event reached publication without matching blackjack-fold validation')
    }
    staged.delete(event)
    states.set(session, candidate.state)
  }, { global: true })
}, { inject: ['sessions'] })

/**
 * Register the blackjack-stream invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
