/**
 * Client face of the blackjack Host Remote and its wire vocabulary.
 *
 * Hand-written projection of the typert generator's `typert.remote-client`
 * artifact: merges the `blackjack` namespace into the protocol's
 * `TypertRemoteNamespaceMap` so client code (and `ctx.remote.blackjack`)
 * sees the generated method signatures, addressed per session.
 */

import { array, boolean, literal, number, object, optional, string, union } from 'zod'
import type { InvocationParameterDescriptor, RemoteResult, TypertCodec, TypertRemoteContribution, TypertRemoteNamespaceMap } from '@deepseek-ai/dsh-typert-protocol'
import type { SessionId } from '@deepseek-ai/dsh-session'
import type {
  BlackjackBanterRequest,
  BlackjackBanterResult,
  BlackjackSetPersonaRequest,
  BlackjackStartRequest,
  BlackjackView,
} from './service/types.ts'

/** The `blackjack` Remote namespace, addressed per session. */
export interface BlackjackRemote {
  /** Open a new round. */
  start(session: SessionId, request: BlackjackStartRequest): Promise<RemoteResult<BlackjackView>>
  /** Draw one card for the player. */
  hit(session: SessionId): Promise<RemoteResult<BlackjackView>>
  /** Pass the player's turn. */
  stand(session: SessionId): Promise<RemoteResult<BlackjackView>>
  /** Run one dealer turn step. */
  dealer(session: SessionId): Promise<RemoteResult<BlackjackView>>
  /** Read the live table without committing. */
  view(session: SessionId): Promise<RemoteResult<BlackjackView>>
  /** Send one player trash-talk line. */
  banter(session: SessionId, request: BlackjackBanterRequest): Promise<RemoteResult<BlackjackBanterResult>>
  /** Switch the dealer's persona. */
  persona(session: SessionId, request: BlackjackSetPersonaRequest): Promise<RemoteResult<BlackjackView>>
}

declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespaceMap {
    blackjack: BlackjackRemote
  }
}

/* ── wire schemas (zod v4, the same factory API the generated codecs use) ── */

const cardSchema = object({ rank: string(), suit: string() })
const handSchema = object({
  cards: array(cardSchema),
  total: number(),
  blackjack: boolean(),
  bust: boolean(),
})
const banterLineSchema = object({
  from: union([literal('player'), literal('dealer')]),
  content: string(),
  trigger: optional(string()),
})
const recordSchema = object({
  wins: number(),
  losses: number(),
  blackjacks: number(),
  pushes: number(),
})
const blackjackViewSchema = object({
  round: number(),
  phase: union([literal('idle'), literal('player-turn'), literal('dealer-turn'), literal('settled')]),
  player: handSchema,
  dealer: handSchema,
  dealerHidden: boolean(),
  emotion: union([literal('calm'), literal('nervous'), literal('broken'), literal('smug')]),
  persona: string(),
  banter: array(banterLineSchema),
  record: recordSchema,
  result: optional(union([literal('player-win'), literal('player-blackjack'), literal('dealer-win'), literal('push')])),
})
const startRequestSchema = object({ deckSeed: optional(string()) })
const banterRequestSchema = object({ content: string() })
const personaRequestSchema = object({ persona: string() })
const banterResultSchema = object({ reply: string() })

/** One strict codec over a wire type. */
function strict(typeSymbol: string, schema: { parse(value: unknown): unknown }): TypertCodec {
  return { mode: 'strict', typeSymbol, schema }
}

const AGENT_CODEC = strict('dsh-blackjack#blackjack/agent', string())

/** One descriptor for a verb taking an optional JSON request. */
function blackjackDescriptor(
  method: string,
  requestCodec: TypertCodec | undefined,
  resultCodec: TypertCodec,
): TypertRemoteContribution['descriptors'][number] {
  const agentParameter: InvocationParameterDescriptor = {
    name: 'agent',
    wire: 'agentId',
    source: 'lookup',
    lookup: 'agent',
    codec: AGENT_CODEC,
  }
  const parameters: InvocationParameterDescriptor[] = [
    agentParameter,
    ...(requestCodec === undefined
      ? []
      : [{ name: 'request', wire: 'request', source: 'json', codec: requestCodec } as InvocationParameterDescriptor]),
  ]
  return {
    id: `dsh-blackjack#blackjack/${method}`,
    service: 'blackjack',
    namespace: 'blackjack',
    method,
    invocation: { kind: 'direct' },
    scope: { context: 'agent', wire: 'agentId' },
    parameters,
    result: resultCodec,
  }
}

/**
 * The generated Host-for-Client contribution this package mounts itself:
 * `api-remotes` only hard-codes the in-box contributions, so a third-party
 * Host Remote must `$mount` its own descriptor set. Every verb is a direct
 * method on the `blackjack` service keyed by the owning agent (whose id is
 * the session id).
 */
export const blackjackRemoteContribution: TypertRemoteContribution = {
  package: 'dsh-blackjack',
  descriptors: [
    blackjackDescriptor('start', strict('dsh-blackjack#blackjack/start:request', startRequestSchema), strict('dsh-blackjack#blackjack/start:result', blackjackViewSchema)),
    blackjackDescriptor('hit', undefined, strict('dsh-blackjack#blackjack/hit:result', blackjackViewSchema)),
    blackjackDescriptor('stand', undefined, strict('dsh-blackjack#blackjack/stand:result', blackjackViewSchema)),
    blackjackDescriptor('dealer', undefined, strict('dsh-blackjack#blackjack/dealer:result', blackjackViewSchema)),
    blackjackDescriptor('view', undefined, strict('dsh-blackjack#blackjack/view:result', blackjackViewSchema)),
    blackjackDescriptor('banter', strict('dsh-blackjack#blackjack/banter:request', banterRequestSchema), strict('dsh-blackjack#blackjack/banter:result', banterResultSchema)),
    blackjackDescriptor('persona', strict('dsh-blackjack#blackjack/persona:request', personaRequestSchema), strict('dsh-blackjack#blackjack/persona:result', blackjackViewSchema)),
  ],
}
