/**
 * Package-owned invariant companion for `@deepseek-ai/dsh-blackjack-game`.
 * @module @deepseek-ai/dsh-blackjack-game/invariant
 */

/* jscpd:ignore-start */
import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'
import type { BlackjackPersona, BlackjackResult, Card, DealerEmotion } from './types.ts'

const PACKAGE_NAME = '@deepseek-ai/dsh-blackjack-game'

/** Cordis companion plugin name. */
export const name = 'blackjack-game-invariant'
/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

/** Assert a card is a member of a standard deck. */
export function assertCard(card: Card): void {
  if (!['♠', '♥', '♦', '♣'].includes(card.suit)) {
    throw new Error(`blackjack: invalid suit "${card.suit}"`)
  }
  const rank = card.rank
  const valid = rank.length >= 1 && rank.length <= 2
    && (rank === 'A' || rank === 'J' || rank === 'Q' || rank === 'K' || /^[2-9]$/.test(rank) || rank === '10')
  if (!valid) {
    throw new Error(`blackjack: invalid rank "${rank}"`)
  }
}

/** Assert a settle result is one of the closed union values. */
export function assertResult(result: BlackjackResult): void {
  switch (result) {
    case 'player-win':
    case 'player-blackjack':
    case 'dealer-win':
    case 'push':
      return
    default:
      throw new Error(`blackjack: invalid result "${String(result)}"`)
  }
}

/** Assert an emotion is one of the closed union values. */
export function assertEmotion(emotion: DealerEmotion): void {
  switch (emotion) {
    case 'calm':
    case 'nervous':
    case 'broken':
    case 'smug':
      return
    default:
      throw new Error(`blackjack: invalid emotion "${String(emotion)}"`)
  }
}

/** Assert a persona is one of the closed union values. */
export function assertPersona(persona: BlackjackPersona): void {
  switch (persona) {
    case '大肥鱼':
    case '雌小鬼':
      return
    default:
      throw new Error(`blackjack: invalid persona "${String(persona)}"`)
  }
}

/**
 * No runtime invariant: this pure rules engine owns no event stream or
 * mutable runtime data; its value algebra is enforced by unit tests.
 */
const install: InvariantInstaller = () => {}

/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
/* jscpd:ignore-end */
