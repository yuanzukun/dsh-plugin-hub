/**
 * Deterministic Blackjack rules engine: seeded shuffle, hand scoring,
 * hit/stand transitions, dealer policy, and settlement. Pure functions over
 * immutable inputs — no I/O, no randomness outside the caller-supplied seed,
 * so the same seed reproduces the same round (the session log stores the
 * seed and replays identically).
 *
 * @module @deepseek-ai/dsh-blackjack-game/engine
 */

import type { BlackjackDecision, BlackjackResult, Card, Hand, Rank, Suit } from './types.ts'

/** All 52 cards of one standard deck. */
export const FULL_DECK: readonly Card[] = (() => {
  const suits: readonly Suit[] = ['♠', '♥', '♦', '♣']
  const ranks: readonly Rank[] = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
  const cards: Card[] = []
  for (const suit of suits) {
    for (const rank of ranks) {
      cards.push({ suit, rank })
    }
  }
  return cards
})()

/** Point value of one rank under Blackjack rules (A counted separately). */
function rankPoints(rank: Rank): number {
  switch (rank) {
    case 'J':
    case 'Q':
    case 'K':
      return 10
    case 'A':
      return 11
    default:
      return Number(rank)
  }
}

/**
 * Score a hand. Aces count 11 unless that would bust, in which case the
 * lowest-ace-first substitution reduces them to 1 until the hand fits.
 * @param cards - the hand's cards, in draw order.
 * @returns total, blackjack flag, and bust flag.
 */
export function scoreHand(cards: readonly Card[]): Pick<Hand, 'total' | 'blackjack' | 'bust'> {
  let total = 0
  let aces = 0
  for (const card of cards) {
    total += rankPoints(card.rank)
    if (card.rank === 'A') aces += 1
  }
  // Soft values: each ace over the soft threshold drops 10.
  while (total > 21 && aces > 0) {
    total -= 10
    aces -= 1
  }
  return {
    total,
    blackjack: cards.length === 2 && total === 21,
    bust: total > 21,
  }
}

/** Build the immutable hand value for a card list. */
export function handOf(cards: readonly Card[]): Hand {
  const scored = scoreHand(cards)
  return { cards: [...cards], ...scored }
}

/**
 * Deterministic Fisher-Yates shuffle keyed by a string seed. The seed is
 * hashed into a 32-bit state via FNV-1a, then a mulberry32 PRNG drives the
 * shuffle — same seed, same deck order, on every platform.
 * @param cards - deck to shuffle (not mutated).
 * @param seed - caller-supplied seed, stored in the session log.
 * @returns a new shuffled card array.
 */
export function shuffleDeck(cards: readonly Card[], seed: string): Card[] {
  const result = [...cards]
  let hash = 0x811c9dc5
  for (let i = 0; i < seed.length; i += 1) {
    hash ^= seed.charCodeAt(i)
    hash = Math.imul(hash, 0x01000193)
  }
  // mulberry32
  let state = hash >>> 0
  const next = (): number => {
    state = (state + 0x6d2b79f5) >>> 0
    let t = state
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(next() * (i + 1))
    const tmp = result[i]!
    result[i] = result[j]!
    result[j] = tmp
  }
  return result
}

/**
 * Deal a fresh round from a seeded deck: player gets two face-up cards,
 * dealer gets two (first face-up, second hidden — hidden state is implied
 * by position, the engine returns the dealer's full hand).
 * @param seed - deck seed, persisted in the session log for replay.
 * @returns the draw pile plus both opening hands.
 */
export function deal(seed: string): { deck: Card[]; player: Hand; dealer: Hand } {
  const deck = shuffleDeck(FULL_DECK, seed)
  const playerCards = [deck[0]!, deck[2]!]
  const dealerCards = [deck[1]!, deck[3]!]
  return {
    deck: deck.slice(4),
    player: handOf(playerCards),
    dealer: handOf(dealerCards),
  }
}

/**
 * Resolve one player decision against the current hand. `hit` draws from
 * the pile; `stand` passes. Returns the updated hand and remaining deck.
 * @param hand - current player hand.
 * @param decision - hit or stand.
 * @param deck - remaining draw pile.
 * @returns next hand and deck; the hand is unchanged on `stand`.
 */
export function applyPlayerDecision(
  hand: Hand,
  decision: BlackjackDecision,
  deck: readonly Card[],
): { hand: Hand; deck: Card[] } {
  if (decision.kind === 'stand') {
    return { hand, deck: [...deck] }
  }
  const [drawn, ...rest] = deck
  if (drawn === undefined) return { hand, deck: [...deck] }
  return { hand: handOf([...hand.cards, drawn]), deck: rest }
}

/**
 * Dealer policy: stand on 17 or higher (hard or soft), otherwise hit.
 * @param hand - current dealer hand.
 * @returns the policy decision.
 */
export function dealerPolicy(hand: Hand): BlackjackDecision {
  return hand.total >= 17 ? { kind: 'stand' } : { kind: 'hit' }
}

/**
 * Settle a round after the player stands and the dealer finishes drawing.
 * Blackjack pays only against a non-blackjack dealer hand; equal totals push.
 * @param player - final player hand.
 * @param dealer - final dealer hand.
 * @returns the round outcome.
 */
export function settle(player: Hand, dealer: Hand): BlackjackResult {
  if (player.bust) return 'dealer-win'
  if (dealer.bust) return player.blackjack ? 'player-blackjack' : 'player-win'
  if (player.blackjack && !dealer.blackjack) return 'player-blackjack'
  if (dealer.blackjack && !player.blackjack) return 'dealer-win'
  if (player.total > dealer.total) return 'player-win'
  if (player.total < dealer.total) return 'dealer-win'
  return 'push'
}

/** Win/draw/loss orientation of one outcome, for streak tracking. */
export function resultDirection(result: BlackjackResult): 'win' | 'draw' | 'loss' {
  switch (result) {
    case 'player-win':
    case 'player-blackjack':
      return 'win'
    case 'dealer-win':
      return 'loss'
    case 'push':
      return 'draw'
  }
}
