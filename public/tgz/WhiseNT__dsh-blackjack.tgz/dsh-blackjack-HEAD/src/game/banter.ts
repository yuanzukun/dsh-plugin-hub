/**
 * Dealer mood and preset banter: emotion folding from settle history plus
 * the per-persona fallback chatter lines used when the model route is
 * disabled or fails. Every persona has its own voice: the fat fish talks
 * food, the brat talks down — both with emoji, neither with code jokes.
 *
 * @module @deepseek-ai/dsh-blackjack-game/banter
 */

import type { BlackjackPersona, BlackjackResult, DealerEmotion } from './types.ts'
import { resultDirection } from './engine.ts'

/**
 * Fold one round result into the dealer emotion state machine.
 * - calm → nervous when the player wins two rounds in a row.
 * - nervous → broken when the player wins two more (four total).
 * - calm → smug when the player loses three rounds in a row.
 * - A player loss while nervous/broken relaxes one step toward calm.
 * @param emotion - previous emotion (start with 'calm').
 * @param result - the just-settled round outcome.
 * @param playerWinStreak - consecutive player wins including this round.
 * @param playerLossStreak - consecutive player losses including this round.
 * @returns the next emotion.
 */
export function foldEmotion(
  emotion: DealerEmotion,
  result: BlackjackResult,
  playerWinStreak: number,
  playerLossStreak: number,
): DealerEmotion {
  const direction = resultDirection(result)
  if (direction === 'win') {
    if (playerWinStreak >= 4) return 'broken'
    if (playerWinStreak >= 2) return 'nervous'
    return emotion === 'smug' ? 'calm' : emotion
  }
  if (direction === 'loss') {
    if (playerLossStreak >= 3) return 'smug'
    if (emotion === 'broken') return 'nervous'
    if (emotion === 'nervous') return 'calm'
    return emotion
  }
  // Push: mood persists.
  return emotion
}

/** Why the dealer speaks: one closed trigger set. */
export type BanterTrigger =
  | 'game-start'
  | 'player-bust'
  | 'player-blackjack'
  | 'player-win'
  | 'dealer-win'
  | 'push'
  | 'random'
  | 'reply'

/**
 * Per-persona fallback lines keyed by trigger. Each list cycles round-robin
 * by round number, so consecutive rounds vary even in degraded mode. Lines
 * carry the persona's voice and emoji but no programming references: the
 * dealer is a character, not a colleague.
 */
export const FALLBACK_BANTER: Readonly<Record<BlackjackPersona, Readonly<Record<BanterTrigger, readonly string[]>>>> = {
  '大肥鱼': {
    'game-start': [
      '咕噜咕噜~ 我是大肥鱼，今天要把你的筹码全吃光。🐟',
      '噗噜~ 洗好牌啦，输了就请我吃小鱼干。🍣',
      '咕噜~ 快来快来，我饿啦。😋',
    ],
    'player-bust': [
      '咕噜？！爆掉啦~ 正好，我开动了。🍤',
      '噗噜噗噜~ 你的牌撑不住啦，就像我的鱼缸。🐟',
      '咕噜~ 爆牌啦，小鱼干就是小鱼干。😋',
    ],
    'player-blackjack': [
      '咕…？！黑杰克！我的鱼鳍在发抖…🫧',
      '咕噜？！这不合理！把我的小鱼干还来！😭',
    ],
    'player-win': [
      '咕…输给小鱼干了…不过没关系，吃饱最重要。🍣',
      '噗噜~ 算你厉害，但我不承认（嚼嚼）。😋',
    ],
    'dealer-win': [
      '咕噜咕噜~ 赢了赢了，你的筹码真香。🐟',
      '噗噜~ 大肥鱼就是大肥鱼。😋',
    ],
    'push': [
      '平局？咕噜~ 那我们还是朋友。🐟',
      '噗噜…谁也不欠谁，正好歇会儿。🫧',
    ],
    'random': [
      '咕噜~ 我快睡着啦，你快点嘛。💤',
      '噗噜~ 我在想晚饭吃什么呢…🍤',
      '咕噜~ 要不我们改玩吃牌？😋',
    ],
    'reply': [
      '咕噜咕噜！嘴硬可赢不了牌哦。🐟',
      '噗噜~ 好吵哦，专心点啦。🫧',
      '咕噜~（假装没听见）😋',
    ],
  },
  '雌小鬼': {
    'game-start': [
      '杂鱼~ 敢和我玩 21 点，胆子不小嘛。😼',
      '哼哼，准备好哭鼻子了吗？杂鱼。😝',
      '来吧杂鱼，本小姐今天心情好，陪你玩玩。👅',
    ],
    'player-bust': [
      '爆掉啦~ 杂鱼就是杂鱼。💢',
      '啊啦啊啦~ 这就爆了？真是杂鱼呢。😝',
      '看吧，连牌都在嘲笑你，杂鱼。😼',
    ],
    'player-blackjack': [
      '？！你作弊了吧！杂鱼怎么可能…😾',
      '什…什么嘛！只是运气好而已！💢',
    ],
    'player-win': [
      '哼！这局是让着你的，别得意！😤',
      '赢一局就这么开心，果然是杂鱼。😼',
      '哈？本小姐只是热身而已。👅',
    ],
    'dealer-win': [
      '杂鱼~杂鱼~ 连庄家都打不过~😝',
      '看吧，这就是实力差距，杂鱼。👅',
      '输给本小姐是你的荣幸哦，杂鱼。😼',
    ],
    'push': [
      '平局？无聊，再来一局，杂鱼。😼',
      '哼，勉强承认你和本小姐一样强好了。💢',
    ],
    'random': [
      '快点啦杂鱼，本小姐都要睡着了。😪',
      '在发呆吗？杂鱼就是杂鱼~😝',
      '这局你输定了哦，杂鱼。👅',
    ],
    'reply': [
      '哈？杂鱼在说什么呢~😝',
      '吵死了，杂鱼。专心打牌啦。😼',
      '哼哼~ 嘴硬可赢不了本小姐哦。👅',
    ],
  },
}

/**
 * Pick one fallback line for a persona and trigger, cycling deterministically
 * by round.
 * @param persona - the dealer's current role-play persona.
 * @param trigger - banter trigger key.
 * @param round - current round number (rotation index).
 * @returns the fallback line.
 */
export function fallbackBanter(persona: BlackjackPersona, trigger: BanterTrigger, round: number): string {
  const pool = FALLBACK_BANTER[persona][trigger]
  if (pool === undefined || pool.length === 0) return ''
  return pool[round % pool.length]!
}
