/**
 * Card and game-state vocabulary for the DeepSeek Blackjack engine.
 * Pure value types: every structure here is lossless-JSON serializable so
 * game states can travel through session events and RPC boundaries.
 *
 * @module @deepseek-ai/dsh-blackjack-game/types
 */

/** The four French suits. */
export type Suit = '♠' | '♥' | '♦' | '♣'

/** Face value ranks 2..10, J, Q, K, A. */
export type Rank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A'

/** One playing card. */
export interface Card {
  readonly suit: Suit
  readonly rank: Rank
}

/** A hand of cards plus the already-derived totals. */
export interface Hand {
  readonly cards: readonly Card[]
  /** Lowest non-bust total (A counted as 1 when 11 would bust). */
  readonly total: number
  /** Whether the hand is a natural two-card 21 (A + 10/J/Q/K). */
  readonly blackjack: boolean
  /** Whether the hand exceeds 21. */
  readonly bust: boolean
}

/**
 * The single decision a player or dealer can make at their turn.
 * Discriminated union so downstream renderers can switch exhaustively.
 */
export type BlackjackDecision =
  | { readonly kind: 'hit' }
  | { readonly kind: 'stand' }

/** Outcome of one settled round. */
export type BlackjackResult =
  | 'player-win'
  | 'player-blackjack'
  | 'dealer-win'
  | 'push'

/**
 * Dealer persona state: the game-tracked mood that drives banter tone.
 * The sequence calm → nervous → broken is player win pressure; calm → smug
 * is player losing streak arrogance. Folded from settle events, never stored
 * out-of-band.
 */
export type DealerEmotion = 'calm' | 'nervous' | 'broken' | 'smug'

/**
 * Dealer role-play persona: the character the model (or the fallback pool)
 * performs while dealing. Two shipped characters:
 * - `大肥鱼`: a gluttonous, lazy deep-sea fat fish ("咕噜咕噜").
 * - `雌小鬼`: a smug, cheeky brat who calls the player "杂鱼".
 */
export type BlackjackPersona = '大肥鱼' | '雌小鬼'

/** The persona used before the player picks one (and the fold's default). */
export const DEFAULT_BLACKJACK_PERSONA: BlackjackPersona = '大肥鱼'

/** Every persona the game knows, in picker order. */
export const BLACKJACK_PERSONA_LIST: readonly BlackjackPersona[] = ['大肥鱼', '雌小鬼']

/** One line of in-game chatter between the player and the dealer. */
export interface BanterLine {
  readonly from: 'player' | 'dealer'
  readonly content: string
}

/** Preset emoji the player can fire at the dealer. */
export const BANTER_EMOJI: readonly string[] = ['🍌', '🐟', '🤡', '💀', '🔥', '🃏', '😤', '🫡', '🧠'] as const
