import { useEffect, useRef, useState } from 'react'
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
import type { BlackjackPersona, BlackjackView } from './remote.ts'
import { NS, type BlackjackKey } from './locales.ts'
import css from './BlackjackPanel.module.css'

/** Emoji fired at the dealer; each one sends as its own line immediately. */
export const BANTER_EMOJI: readonly string[] = ['🍌', '🐟', '🤡', '💀', '🔥', '🃏', '😤', '🫡', '🧠']

/** The two shipped dealer personas and their picker faces. */
const PERSONA_OPTIONS: readonly {
  persona: BlackjackPersona
  emoji: string
  nameKey: BlackjackKey
  descKey: BlackjackKey
}[] = [
  { persona: '大肥鱼', emoji: '🐟', nameKey: 'persona.bigfish.name', descKey: 'persona.bigfish.desc' },
  { persona: '雌小鬼', emoji: '😼', nameKey: 'persona.brat.name', descKey: 'persona.brat.desc' },
]

/** Stable empty hand for the pre-deal table (the panel is a projection). */
const EMPTY_HAND: BlackjackView['dealer'] = Object.freeze({ cards: [], total: 0, blackjack: false, bust: false })

/**
 * One entry of the table chatter feed. Banter lines come from the dealer and
 * the player; status lines record the game itself (deals, draws, stands,
 * verdicts) so the chat doubles as the round's replay log.
 */
export type BlackjackChatLine =
  | { readonly id: number; readonly kind: 'player'; readonly content: string }
  | { readonly id: number; readonly kind: 'dealer'; readonly content: string }
  | { readonly id: number; readonly kind: 'status'; readonly content: string }

/**
 * Hand-area render of one side. While the dealer's hole card is hidden only
 * the first card is face-up; the rest render as backs and the total stays
 * hidden so the player cannot infer it.
 *
 * `flip` is the dealer reveal: cards beyond the hole card mount face-up with
 * a staggered flip so the player watches the dealer's draws land one by one.
 */
function HandArea(props: {
  label: string
  hand: BlackjackView['dealer']
  hidden: boolean
  flip: boolean
  totalLabel: string
  hiddenTotalLabel: string
  blackjackLabel: string
  bustLabel: string
}) {
  const { label, hand, hidden, flip } = props
  const visible = hidden ? hand.cards.slice(0, 1) : hand.cards
  const backs = hidden ? Math.max(0, hand.cards.length - 1) : 0
  return (
    <section className={css.hand}>
      <h4 className={css.handLabel}>{label}</h4>
      <div className={css.cards}>
        {visible.map((card, index) => (
          <span
            key={`${card.rank}-${card.suit}-${index}`}
            className={`${css.card} ${flip && index >= 1 ? css.cardFlip : ''}`}
            data-rank={card.rank}
            data-suit={card.suit}
          >
            <span className={css.cardRank}>{card.rank}</span>
            <span className={css.cardSuit}>{card.suit}</span>
          </span>
        ))}
        {Array.from({ length: backs }, (_, index) => (
          <span key={`back-${index}`} className={`${css.card} ${css.cardBack}`}>
            <span className={css.cardBackGlyph}>?</span>
          </span>
        ))}
      </div>
      <div className={css.handMeta}>
        <span className={`${css.total} ${flip ? css.totalReveal : ''}`}>{hidden ? props.hiddenTotalLabel : props.totalLabel}</span>
        {hand.blackjack ? <span className={css.marker}>{props.blackjackLabel}</span> : null}
        {hand.bust ? <span className={`${css.marker} ${css.markerBust}`}>{props.bustLabel}</span> : null}
      </div>
    </section>
  )
}

/** The dealer's emotion dictionary key for a view. */
function emotionKey(emotion: BlackjackView['emotion']): BlackjackKey {
  switch (emotion) {
    case 'calm': return 'emotion.calm'
    case 'nervous': return 'emotion.nervous'
    case 'broken': return 'emotion.broken'
    case 'smug': return 'emotion.smug'
  }
}

/** The phase word dictionary key for a view. */
function phaseKey(phase: BlackjackView['phase']): BlackjackKey {
  switch (phase) {
    case 'idle': return 'phase.idle'
    case 'player-turn': return 'phase.player-turn'
    case 'dealer-turn': return 'phase.dealer-turn'
    case 'settled': return 'phase.settled'
  }
}

/**
 * The blackjack table: dealer zone (hand, mood badge), player zone, the
 * persona picker, the phase-appropriate action row, and the banter composer
 * pinned to the bottom. Purely presentational — verbs arrive through
 * callbacks and the view through props, so the panel holds only the
 * composer's text state and the transient emoji-burst sprite.
 */
export function BlackjackPanel(props: {
  view: BlackjackView | null
  busy: boolean
  error: string | null
  chat: readonly BlackjackChatLine[]
  thinking: boolean
  t: TranslateNS<typeof NS>
  onStart: () => void
  onHit: () => void
  onStand: () => void
  onBanter: (text: string) => void
  onPersona: (persona: BlackjackPersona) => void
  onDismiss: () => void
}) {
  const { view, busy, error, t, chat, thinking } = props
  const [draft, setDraft] = useState('')
  // One flying-emoji sprite per sent emoji; keyed so repeats re-run the burst.
  const [burst, setBurst] = useState<{ id: number; emoji: string } | null>(null)
  const burstId = useRef(0)
  // The chat is its own scrolling column; new chatter pins it to the bottom.
  const transcriptRef = useRef<HTMLDivElement | null>(null)

  const sendable = draft.trim().length > 0 && !busy

  // The dealer's cards flip face-up once the player stands (or the round
  // settles on a bust) — the player watches the draws land one by one.
  const dealerFlip = view !== null && !view.dealerHidden && view.phase !== 'player-turn'

  // The chat is the single chatter surface, most recent last; it scrolls on
  // its own so the table above never leaves the viewport.
  useEffect(() => {
    const el = transcriptRef.current
    if (el !== null) el.scrollTop = el.scrollHeight
  }, [chat.length, thinking])

  /**
   * Fire one emoji as its own instant line — emojis are messages, not input
   * text — and launch the flying-emoji burst.
   */
  const onEmoji = (emoji: string): void => {
    if (busy) return
    burstId.current += 1
    setBurst({ id: burstId.current, emoji })
    props.onBanter(emoji)
  }

  return (
    <div className={css.panel} role="dialog" aria-label={t('panel.title')}>
      <header className={css.header}>
        <h3 className={css.title}>{t('panel.title')}</h3>
        {view !== null ? <span className={css.phase}>{t(phaseKey(view.phase))}</span> : null}
        {view !== null && view.round > 0 ? <span className={css.round}>{t('round.label', { round: view.round })}</span> : null}
        <button type="button" className={css.close} aria-label="Close" onClick={props.onDismiss}>×</button>
      </header>

      <div className={css.persona} aria-label={t('persona.label')}>
        <span className={css.personaLabel}>{t('persona.label')}</span>
        {PERSONA_OPTIONS.map(({ persona, emoji, nameKey, descKey }) => (
          <button
            key={persona}
            type="button"
            className={`${css.personaChip} ${view?.persona === persona ? css.personaActive : ''}`}
            aria-pressed={view?.persona === persona}
            title={t(descKey)}
            disabled={busy}
            onClick={() => { props.onPersona(persona) }}
          >
            <span className={css.personaEmoji} aria-hidden="true">{emoji}</span>
            {t(nameKey)}
          </button>
        ))}
      </div>

      {view !== null ? (
        <div className={css.record} aria-label={t('record.label')}>
          <span>{t('record.wins', { wins: view.record.wins })}</span>
          <span>{t('record.losses', { losses: view.record.losses })}</span>
          <span>{t('record.pushes', { pushes: view.record.pushes })}</span>
          <span>{t('record.blackjacks', { blackjacks: view.record.blackjacks })}</span>
        </div>
      ) : null}

      {/* The board stays pinned: hands, verdict and errors never scroll away. */}
      <div className={css.board}>
        <div className={css.table}>
          <div className={css.dealerZone}>
            <div className={css.dealerRow}>
              <HandArea
                label={t('dealer.label')}
                hand={view?.dealer ?? EMPTY_HAND}
                hidden={view?.dealerHidden ?? false}
                flip={dealerFlip}
                totalLabel={t('hand.total', { total: view?.dealer.total ?? 0 })}
                hiddenTotalLabel={t('dealer.hidden')}
                blackjackLabel={t('hand.blackjack')}
                bustLabel={t('hand.bust')}
              />
              {view !== null
                ? <span className={`${css.emotion} ${css[`emotion${view.emotion}`]}`}>{t(emotionKey(view.emotion))}</span>
                : null}
            </div>
          </div>

          <HandArea
            label={t('player.label')}
            hand={view?.player ?? EMPTY_HAND}
            hidden={false}
            flip={false}
            totalLabel={t('hand.total', { total: view?.player.total ?? 0 })}
            hiddenTotalLabel={t('dealer.hidden')}
            blackjackLabel={t('hand.blackjack')}
            bustLabel={t('hand.bust')}
          />
        </div>

        {view?.result !== undefined
          ? (
            <div className={`${css.resultBurst} ${css[`resultBurst${view.result}`]}`}>
              <p className={`${css.result} ${css[`result${view.result}`]}`}>{t(`result.${view.result}`)}</p>
            </div>
          )
          : null}

        {error !== null ? <p className={css.error}>{t('error.call', { message: error })}</p> : null}
      </div>

      {/* The chat is a standalone scroll column: banter lines plus status
          lines recording the round's own progress, and a "diving deep"
          placeholder while the dealer thinks or talks. */}
      <div className={css.transcript} ref={transcriptRef} aria-label={t('banter.aria')}>
        {chat.length > 0 || thinking
          ? (
            <>
              {chat.map((line) => {
                if (line.kind === 'status') {
                  return <p key={line.id} className={css.statusLine}>{line.content}</p>
                }
                return (
                  <p
                    key={line.id}
                    className={line.kind === 'dealer'
                      ? `${css.bubble} ${css.bubbleDealer}`
                      : `${css.bubble} ${css.bubblePlayer}`}
                  >
                    {line.content}
                  </p>
                )
              })}
              {thinking
                ? <p className={`${css.bubble} ${css.bubbleDealer} ${css.thinking}`} aria-label={t('chat.thinking')}>{t('chat.thinking')}</p>
                : null}
            </>
          )
          : <p className={css.transcriptHint}>{t('banter.placeholder')}</p>}
      </div>

      <div className={css.bottom}>
        <div className={css.actions}>
          {view === null || view.phase === 'idle' || view.phase === 'settled'
            ? <button type="button" className={css.primary} disabled={busy} onClick={props.onStart}>{t('button.start')}</button>
            : null}
          {view?.phase === 'player-turn'
            ? (
              <>
                <button type="button" className={css.primary} disabled={busy} onClick={props.onHit}>{t('button.hit')}</button>
                <button type="button" className={css.ghost} disabled={busy} onClick={props.onStand}>{t('button.stand')}</button>
              </>
            )
            : null}
        </div>

        <form
          className={css.banter}
          onSubmit={(event) => {
            event.preventDefault()
            const text = draft.trim()
            if (text.length === 0 || busy) return
            props.onBanter(text)
            setDraft('')
          }}
        >
          <div className={css.emojiRow} aria-label={t('banter.emoji')}>
            {BANTER_EMOJI.map(emoji => (
              <button
                key={emoji}
                type="button"
                className={css.emoji}
                disabled={busy}
                aria-label={emoji}
                onClick={() => { onEmoji(emoji) }}
              >
                {emoji}
              </button>
            ))}
            {burst !== null
              ? <span key={burst.id} className={css.emojiBurst} onAnimationEnd={() => { setBurst(null) }}>{burst.emoji}</span>
              : null}
          </div>
          <div className={css.composer}>
            <input
              className={css.input}
              type="text"
              value={draft}
              placeholder={t('banter.placeholder')}
              aria-label={t('banter.aria')}
              onChange={(event) => { setDraft(event.target.value) }}
            />
            <button type="submit" className={css.send} disabled={!sendable}>{t('banter.send')}</button>
          </div>
        </form>
      </div>
    </div>
  )
}
