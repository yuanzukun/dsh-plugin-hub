/**
 * Client face of the blackjack Host Remote and its wire vocabulary.
 *
 * The value types (view, hand, record, banter) are re-exported from the host
 * service package's `./client` outlet — the single source of truth the typert
 * generator also consumes. The Remote namespace shape is the generated one
 * merged into the protocol's `TypertClientRemote` face, aliased here as
 * `BlackjackRemote` so components and tests name one import site.
 */

import type { TypertClientRemote } from '@deepseek-ai/dsh-typert-protocol'
// Type-only: pulls the `blackjack` namespace into the protocol's
// TypertRemoteNamespaceMap merge (from this package's ./remote outlet).
import type {} from 'dsh-blackjack/remote'

export type {
  BanterLine, BlackjackBanterRequest, BlackjackBanterResult, BlackjackPersona, BlackjackRecord,
  BlackjackResult, BlackjackStartRequest, BlackjackView, Card, DealerEmotion, Hand,
} from 'dsh-blackjack/client'

/** The generated `blackjack` Remote namespace, addressed per session. */
export type BlackjackRemote = TypertClientRemote['blackjack']

import type { BlackjackView as BlackjackViewType } from 'dsh-blackjack/client'

/**
 * Narrow the value a Remote verb resolved to a game view. Guarded because
 * `RemoteResult<T>` is a union and the carrier's value must be assumed
 * unknown until inspected.
 */
export function isBlackjackView(value: unknown): value is BlackjackViewType {
  return typeof value === 'object' && value !== null && 'phase' in value
}
