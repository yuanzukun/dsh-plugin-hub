import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import { NS } from './locales.ts'
import css from './BlackjackAction.module.css'

/** Registrant-private injected share (arrives via the register inject factory). */
export interface BlackjackInjected {
  /** Open the right details column where the blackjack table lives. */
  openDetails: () => void
}

/** Full props for the sidebar footer blackjack action. */
export type BlackjackActionProps =
  PropsRuntime<'sidebar.footer.action'> & PropsLocale<typeof NS> & BlackjackInjected

/**
 * Sidebar footer action: the 🃏 entry that opens the blackjack table in the
 * right details column for the current session. Root-scope slot, so the
 * session id is read reactively from the standard sessions feed; without a
 * current session the entry renders disabled, because every verb addresses
 * the session the game state lives in. The wins badge mirrors the lifetime
 * record from the last deal the user saw — the details column owns the live
 * view.
 * @param props - wide/rail column state, the sessions selector, copy, and the
 *   details-opening callback.
 */
export function BlackjackAction({ wide, useSessions, t, openDetails }: BlackjackActionProps) {
  const sessionId = useSessions(state => state.current)
  const label = t('action.label')

  return (
    <button
      type="button"
      className={wide ? css.trigger : `${css.trigger} ${css.triggerRail}`}
      disabled={sessionId === undefined}
      title={sessionId === undefined ? t('action.noSession') : t('action.aria')}
      aria-label={t('action.aria')}
      onClick={() => { openDetails() }}
    >
      <span className={css.icon} aria-hidden="true">🃏</span>
      {wide ? <span className={css.label}>{label}</span> : null}
    </button>
  )
}
