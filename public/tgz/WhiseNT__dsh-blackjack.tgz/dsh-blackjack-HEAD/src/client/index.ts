/**
 * Blackjack plugin, browser half: the 🃏 sidebar footer action that opens the
 * 21 table in the right details column for the current session, with the
 * DeepSeek model dealing. The table is a projection of the Host-owned game:
 * every verb (deal/hit/stand/banter) goes through the generated `blackjack`
 * Remote namespace and the resulting view replaces the table, so the plugin
 * holds no game state of its own beyond the latest view and in-flight flags.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import { blackjackRemoteContribution } from 'dsh-blackjack/remote'
// Type-only: pulls the generated Remote API and ctx.remote merge through the
// Client assembly boundary (and the `blackjack` namespace this package's own
// contract declares in ./remote.ts).
import type {} from '@deepseek-ai/dsh-api-remotes/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the layout service merge (ctx.layout) used by the details
// entry to open and close the right column.
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import { BlackjackAction, type BlackjackInjected } from './BlackjackAction.tsx'
import { registerBlackjackDetails } from './BlackjackDetails.tsx'
import { en, NS, zh, type BlackjackKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Blackjack table copy. */
    blackjack: BlackjackKey
  }
}

export { BlackjackPanel } from './BlackjackPanel.tsx'
export { BlackjackDetails, registerBlackjackDetails } from './BlackjackDetails.tsx'
export type { BlackjackInjected, BlackjackActionProps } from './BlackjackAction.tsx'
export type { BlackjackDetailsInjected, BlackjackDetailsProps } from './BlackjackDetails.tsx'
export type {
  BanterLine, BlackjackBanterRequest, BlackjackBanterResult, BlackjackRecord,
  BlackjackResult, BlackjackRemote, BlackjackStartRequest, BlackjackView,
  Card, DealerEmotion, Hand,
} from './remote.ts'
export { isBlackjackView } from './remote.ts'
export type { BlackjackKey } from './locales.ts'

/** Required services: locale registration, the footer and details slots,
 * sessions for the current session id, the Remote capability (whose
 * `blackjack` namespace this plugin mounts itself), and the layout service
 * that owns the right column. */
export const inject = ['slots', 'locale', 'sessions', 'remote', 'layout']

/**
 * Client plugin body: mount the blackjack Host Remote contribution (api-remotes
 * only hard-codes the in-box contributions, so a third-party Remote mounts its
 * own descriptor set), then register the dictionaries, the footer action that
 * opens the table, and the details column that renders it.
 * @param ctx - client root context.
 */
export async function apply(ctx: ClientContext): Promise<void> {
  await ctx.remote.$mount(blackjackRemoteContribution)
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ui-blackjack: dictionaries')
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'blackjack',
    // After settings: the game seat is a treat, not chrome.
    order: 20,
    locale: NS,
    inject: (): BlackjackInjected => ({
      openDetails: () => { ctx.layout.openDetails() },
    }),
  }, BlackjackAction))
  registerBlackjackDetails(ctx)
}
