/**
 * The blackjack table as the right details column: the game state holder that
 * registers into the layout's `details` slot, so the 🃏 sidebar action opens a
 * full-height side panel. The Host owns every verb; this component folds each
 * returned view into the board AND a local chatter feed — banter lines plus
 * synthesized status lines recording the round's own progress (deals, draws,
 * stands, verdicts) — and drives the dealer's turn step by step so every
 * decision is visible: think (a "diving deep" placeholder), draw one card,
 * repeat until the round settles.
 */
import { useEffect, useRef, useState } from 'react'
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the ui-layout `details` SlotMap merge (DetailsOwnerProps)
// and the SessionStandardProps sessionId seat.
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type {} from '@deepseek-ai/dsh-client-runtime/client'
import { BlackjackPanel, type BlackjackChatLine } from './BlackjackPanel.tsx'
import { isBlackjackView, type BlackjackPersona, type BlackjackRemote, type BlackjackResult, type BlackjackView } from './remote.ts'
import { NS, type BlackjackKey } from './locales.ts'
import css from './BlackjackDetails.module.css'

/** The pre-deal table: an idle projection with nothing dealt yet. */
const EMPTY_VIEW: BlackjackView = Object.freeze({
  round: 0,
  phase: 'idle',
  player: Object.freeze({ cards: [], total: 0, blackjack: false, bust: false }),
  dealer: Object.freeze({ cards: [], total: 0, blackjack: false, bust: false }),
  dealerHidden: true,
  emotion: 'calm',
  persona: '大肥鱼',
  banter: [],
  record: Object.freeze({ wins: 0, losses: 0, blackjacks: 0, pushes: 0 }),
})

/** Cap on the local chatter feed (the Host caps its own banter history). */
const MAX_CHAT_LINES = 200

/** Registrant-private injected share (arrives via the register inject factory). */
export interface BlackjackDetailsInjected {
  /** The generated `blackjack` Remote namespace, addressed per current session. */
  remote: BlackjackRemote
  /** Close the right details column through the layout service. */
  closeDetails: () => void
}

/** Full props: the session-scoped runtime seat, copy, and the injected face. */
export type BlackjackDetailsProps =
  PropsRuntime<'details'> & PropsLocale<typeof NS> & BlackjackDetailsInjected

/** The result verdict dictionary key for one settled outcome. */
function resultKey(result: BlackjackResult): BlackjackKey {
  switch (result) {
    case 'player-win': return 'result.player-win'
    case 'player-blackjack': return 'result.player-blackjack'
    case 'dealer-win': return 'result.dealer-win'
    case 'push': return 'result.push'
  }
}

/** One card as the chat renders it (suit then rank). */
function cardLabel(card: { readonly suit: string; readonly rank: string }): string {
  return `${card.suit}${card.rank}`
}

/**
 * Diff two views into chat status lines: every draw, stand, bust and verdict
 * the round went through, in event order.
 * @param prev - the previously applied view, or null on first load.
 * @param next - the newly applied view.
 * @param t - bound translator for the `blackjack` namespace.
 * @returns status contents to append before the banter lines.
 */
function synthesizeStatuses(prev: BlackjackView | null, next: BlackjackView, t: BlackjackDetailsProps['t']): string[] {
  const lines: string[] = []
  if (prev === null) {
    // Fresh load (or session switch): recap where the table is, not how it
    // got there — a replayed feed would spam every historical draw.
    if (next.round > 0) lines.push(t('chat.roundStart', { round: next.round }))
    if (next.phase === 'dealer-turn') lines.push(t('chat.playerStand', { total: next.player.total }))
    else if (next.phase === 'settled' && next.result !== undefined) {
      lines.push(t('chat.settle', { result: t(resultKey(next.result)) }))
    }
    return lines
  }
  if (next.round > prev.round) lines.push(t('chat.roundStart', { round: next.round }))
  // Card diffs only count as draws inside one round — the opening deal of a
  // new round is covered by the round-start line, not by per-card "drew" lines.
  if (next.round === prev.round) {
    for (const card of next.player.cards.slice(prev.player.cards.length)) {
      lines.push(t('chat.playerHit', { card: cardLabel(card) }))
    }
    if (prev.phase !== 'dealer-turn' && next.phase === 'dealer-turn') {
      lines.push(t('chat.playerStand', { total: next.player.total }))
    }
    const dealerDrew = next.dealer.cards.slice(prev.dealer.cards.length)
    for (const card of dealerDrew) {
      lines.push(t('chat.dealerHit', { card: cardLabel(card) }))
    }
    if (prev.phase !== 'settled' && next.phase === 'settled') {
      if (next.player.bust) lines.push(t('chat.playerBust'))
      else if (dealerDrew.length === 0 && prev.phase === 'dealer-turn') lines.push(t('chat.dealerStand'))
      if (next.dealer.bust) lines.push(t('chat.dealerBust'))
      if (next.result !== undefined) lines.push(t('chat.settle', { result: t(resultKey(next.result)) }))
    }
  }
  return lines
}

/**
 * Right-side details column occupant: the whole 21 table for the current
 * session, plus the chatter feed that records it. The `details` slot is
 * session-scoped, so `sessionId` arrives through the framework; closing the
 * panel calls the injected `closeDetails()` on the layout service, which
 * owns the column's visibility.
 * @param props - session-scoped slot props, copy, and the injected face.
 */
export function BlackjackDetails({ sessionId, t, remote, closeDetails }: BlackjackDetailsProps) {
  const [view, setView] = useState<BlackjackView>(EMPTY_VIEW)
  const [chat, setChat] = useState<BlackjackChatLine[]>([])
  const [thinking, setThinking] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Live mirrors the async step loop reads instead of stale closures.
  const sessionRef = useRef(sessionId)
  sessionRef.current = sessionId
  const viewRef = useRef<BlackjackView>(view)
  viewRef.current = view
  const prevViewRef = useRef<BlackjackView | null>(null)
  const chatIdRef = useRef(0)
  const banterSyncedRef = useRef(0)
  const pullTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const steppingRef = useRef(false)
  const applyViewRef = useRef<(next: BlackjackView) => void>(() => {})
  const runStepsRef = useRef<() => void>(() => {})

  /** Append with the local feed cap. */
  const pushChat = (lines: BlackjackChatLine[], line: BlackjackChatLine): BlackjackChatLine[] => {
    const next = [...lines, line]
    return next.length > MAX_CHAT_LINES ? next.slice(-MAX_CHAT_LINES) : next
  }
  const nextChatId = (): number => { chatIdRef.current += 1; return chatIdRef.current }

  /**
   * Fold one Host view into the board and the chatter feed: synthesize the
   * round's status lines from the diff, then adopt any banter lines the log
   * gained (skipping the pair the banter reply already mirrored locally).
   */
  const applyView = (next: BlackjackView): void => {
    const prev = prevViewRef.current
    const statuses = synthesizeStatuses(prev, next, t)
    const newBanter = next.banter.slice(banterSyncedRef.current)
    banterSyncedRef.current = next.banter.length
    setChat((current) => {
      let lines = current
      for (const content of statuses) {
        lines = pushChat(lines, { id: nextChatId(), kind: 'status', content })
      }
      for (const line of newBanter) {
        const tail1 = lines[lines.length - 1]
        const tail2 = lines[lines.length - 2]
        const mirrored = (line.from === 'player' && tail2?.kind === 'player' && tail2.content === line.content)
          || (line.from === 'dealer' && tail1?.kind === 'dealer' && tail1.content === line.content)
        if (!mirrored) lines = pushChat(lines, { id: nextChatId(), kind: line.from, content: line.content })
      }
      return lines
    })
    prevViewRef.current = next
    // The step loop reads the ref synchronously between RPCs — React renders
    // flush later, so the ref must move with the view, not with the render.
    viewRef.current = next
    setView(next)
  }
  applyViewRef.current = applyView

  /** Pull the view once, quietly — the way background chatter surfaces. */
  const schedulePull = (delay = 3500): void => {
    if (pullTimerRef.current !== null) clearTimeout(pullTimerRef.current)
    pullTimerRef.current = setTimeout(() => {
      pullTimerRef.current = null
      void remote.view(sessionRef.current).then((carried) => {
        if (carried.ok && isBlackjackView(carried.value)) applyViewRef.current(carried.value)
      }).catch(() => {})
    }, delay)
  }

  /**
   * Drive the dealer turn one visible step at a time: while the dealer
   * thinks the chat shows the diving placeholder; every hit lands as a
   * drawn-card status line and a flipping card on the board.
   */
  const runDealerSteps = (): void => {
    if (steppingRef.current) return
    steppingRef.current = true
    void (async () => {
      try {
        for (let i = 0; i < 24; i += 1) {
          const current = viewRef.current
          if (current === null || current.phase !== 'dealer-turn') return
          setThinking(true)
          const carried = await remote.dealer(sessionRef.current)
          setThinking(false)
          if (!carried.ok) {
            setError(carried.error.message)
            return
          }
          if (!isBlackjackView(carried.value)) return
          applyViewRef.current(carried.value)
          if (carried.value.phase !== 'dealer-turn') {
            schedulePull()
            return
          }
        }
      } finally {
        steppingRef.current = false
      }
    })()
  }
  runStepsRef.current = runDealerSteps

  // On mount and on session switch the table clears and reloads from the log,
  // so reopening the panel (or resuming a session) restores the live table —
  // and a dealer turn left mid-way keeps playing.
  useEffect(() => {
    setView(EMPTY_VIEW)
    setChat([])
    setThinking(false)
    setError(null)
    prevViewRef.current = null
    banterSyncedRef.current = 0
    if (sessionId === undefined) return
    void remote.view(sessionId).then((carried) => {
      if (carried.ok && isBlackjackView(carried.value)) {
        applyViewRef.current(carried.value)
        if (carried.value.phase === 'dealer-turn') runStepsRef.current()
      }
    }).catch(() => {})
  }, [sessionId, remote])

  // Background chatter pulls must never outlive the occupant.
  useEffect(() => () => {
    if (pullTimerRef.current !== null) clearTimeout(pullTimerRef.current)
  }, [])

  /**
   * Run one verb against the current session and fold its returned view into
   * the board and the feed. Every verb is a RemoteResult envelope, so
   * failures render as an inline message instead of an unhandled rejection.
   */
  const act = async (
    verb: (sessionId: BlackjackDetailsProps['sessionId']) => Promise<RemoteResult<unknown>>,
    options: { background?: boolean } = {},
  ): Promise<void> => {
    if (busy && !options.background) return
    if (!options.background) {
      setBusy(true)
      setError(null)
    }
    try {
      const carried = await verb(sessionId)
      if (!carried.ok) {
        setError(carried.error.message)
      } else if (isBlackjackView(carried.value)) {
        applyViewRef.current(carried.value)
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'remote call failed')
    } finally {
      if (!options.background) setBusy(false)
    }
  }

  const onStart = (): void => {
    void act(session => remote.start(session, {})).then(() => { schedulePull() })
  }
  const onHit = (): void => {
    void act(session => remote.hit(session)).then(() => { schedulePull() })
  }
  const onStand = (): void => {
    void act(session => remote.stand(session)).then(() => { runStepsRef.current() })
  }
  const onPersona = (persona: BlackjackPersona): void => { void act(session => remote.persona(session, { persona })) }
  const onBanter = (text: string): void => {
    if (busy) return
    setBusy(true)
    setError(null)
    // Mirror the player line instantly and hold a diving placeholder until
    // the dealer's reply lands — the reply replaces the placeholder.
    setChat(current => pushChat(current, { id: nextChatId(), kind: 'player', content: text }))
    setThinking(true)
    void remote.banter(sessionId, { content: text }).then((carried) => {
      setThinking(false)
      if (!carried.ok) {
        setError(carried.error.message)
        return
      }
      if (isBlackjackView(carried.value)) {
        applyViewRef.current(carried.value)
      } else {
        setChat(current => pushChat(current, { id: nextChatId(), kind: 'dealer', content: carried.value.reply }))
      }
    }).catch((caught: unknown) => {
      setThinking(false)
      setError(caught instanceof Error ? caught.message : 'remote call failed')
    }).finally(() => {
      setBusy(false)
    })
  }

  return (
    <div className={css.details}>
      <BlackjackPanel
        view={view}
        busy={busy}
        error={error}
        chat={chat}
        thinking={thinking}
        t={t}
        onStart={onStart}
        onHit={onHit}
        onStand={onStand}
        onBanter={onBanter}
        onPersona={onPersona}
        onDismiss={closeDetails}
      />
    </div>
  )
}

/**
 * Register the blackjack details column on a client context.
 * @param ctx - client root context exposing the layout service.
 */
export function registerBlackjackDetails(ctx: ClientContext): void {
  ctx.slots.inject('details', () => ctx.slots.register({
    name: 'details',
    // The details column is a single-slot cell; ui-conversation's panel holds
    // priority 0, so the game table takes a lower priority and owns the
    // column while registered (lowest live entry renders).
    priority: -1,
    locale: NS,
    inject: (): BlackjackDetailsInjected => ({
      // The namespace is mounted by this plugin's own apply ($mount), so the
      // dotted accessor would demand an inject declaration that cannot resolve
      // before the mount; the registry lookup reads the live service instead.
      remote: ctx.get('remote.blackjack') as BlackjackRemote,
      closeDetails: () => { ctx.layout.closeDetails() },
    }),
  }, BlackjackDetails))
}
