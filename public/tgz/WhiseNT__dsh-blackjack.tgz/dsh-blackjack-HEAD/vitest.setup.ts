/**
 * Minimal browser-module loader for tests: the @deepseek-ai client half
 * bundles are closure factories registered through window.__ModuleLoader__
 * (the GUI's module system). Under vitest there is no real loader, so this
 * setup provides a minimal one: factory(require) executes with a require
 * backed by Node's resolver (Node >=22.12 can require ESM). The module's
 * exports are the factory's return value (the closure's own module.exports).
 */
import { createRequire, registerHooks } from 'node:module'

// Node's ESM loader resolves .css imports (katex ships one) natively and
// fails with "Unknown file extension". Resolve them to an empty module so
// client-bundle factories that pull katex load under test.
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier.endsWith('.css')) {
      return { url: 'data:text/javascript;base64,' + Buffer.from('export default {}').toString('base64'), shortCircuit: true }
    }
    return nextResolve(specifier, context)
  },
})

interface LoaderEntry {
  id: string
  factory: (require: (spec: string) => unknown) => unknown
}

const nodeRequire = createRequire(import.meta.url)
const modules = new Map<string, { exports: unknown }>()

function req(spec: string): unknown {
  // Stylesheets inside client-bundle factories: the GUI loader resolves them
  // through CSS Modules; under test they contribute no styles, so stub them.
  if (spec.endsWith('.css')) return {}
  // katex ships an ESM entry that imports its own .css, which Node cannot load
  // outside the GUI loader; tests never render math, so stub the whole module.
  if (spec === 'katex' || spec.startsWith('katex/')) return {}
  // Cross-package requires inside client-bundle factories: answer from the
  // loader table. The published bundles' own module.exports stays empty (the
  // closure registers through __ModuleLoader__), so nodeRequire would yield {}.
  if (spec.startsWith('@deepseek-ai/')) {
    const direct = modules.get(spec)
    if (direct) return direct.exports
    for (const [id, module] of modules) {
      if (spec === id || spec === `${id}/client`) return module.exports
    }
  }
  const cached = modules.get(spec)
  if (cached) return cached.exports
  return nodeRequire(spec)
}

const loader = {
  load(entry: LoaderEntry): unknown {
    const cached = modules.get(entry.id)
    if (cached) return cached.exports
    // Register the placeholder first so circular factory requires resolve.
    const module = { exports: {} as unknown }
    modules.set(entry.id, module)
    module.exports = entry.factory(req) ?? module.exports
    return module.exports
  },
  /** The composed exports of an already-loaded client-bundle id (test helper). */
  getExports(id: string): Record<string, unknown> {
    const module = modules.get(id)
    return (module?.exports ?? {}) as Record<string, unknown>
  },
}

if (typeof window !== 'undefined') {
  Object.defineProperty(window, '__ModuleLoader__', {
    value: loader,
    configurable: true,
    writable: true,
  })
}
