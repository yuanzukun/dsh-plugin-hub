/**
 * Invariant companion tests: canonical blackjack streams append cleanly,
 * malformed streams (unpaired rounds, phase violations, tampered draws,
 * divergent emotions) are rejected at the session boundary, and a pre-existing
 * valid log is reconstructed before later events are checked.
 */
import { describe, expect, it } from 'vitest'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import AgentRegistry, { Inbox } from '@deepseek-ai/dsh-agent'
import type { Agent } from '@deepseek-ai/dsh-agent'
import InvariantRegistry, { InvariantError } from '@deepseek-ai/dsh-invariants'
import SessionStore, { Session, SessionId } from '@deepseek-ai/dsh-session'
import {
  FULL_DECK,
  deal,
  settle,
  shuffleDeck,
  type Card,
} from '../src/game'
import * as BlackjackInvariantCompanion from '../src/service/invariant'
import BlackjackService from '../src/service/index'

/** Build a registry-compatible agent around a fresh session. */
function stubAgent(rawId: string): { agent: Agent; session: Session } {
  const session = Session.create(SessionId(rawId))
  const inbox = new Inbox(session, { inserted: () => {}, discarded: () => {}, claimed: () => {} })
  const agent: Agent = {
    id: session.id,
    options: {},
    session,
    inbox,
    ctx: new Context(),
    status: 'idle',
    send: () => {},
    followup: () => {},
    steer: () => {},
    inject(input) { inbox.append('next-step', input) },
    cancel() {},
    runMaintenance: task => task(new AbortController().signal),
    whenIdle() { return Promise.resolve() },
  }
  return { agent, session }
}

async function setup(): Promise<Context> {
  const ctx = new Context()
  await ctx.plugin(SessionStore)
  await ctx.plugin(InvariantRegistry, { enabled: true })
  await ctx.plugin(BlackjackInvariantCompanion)
  return ctx
}

describe('blackjack stream invariants', () => {
  it('accepts a canonical round played through the service', async () => {
    const ctx = await setup()
    await ctx.plugin(AgentRegistry)
    ctx.provide('llm', { stream: async function* () {} } as never)
    await ctx.plugin(BlackjackService, { dealerLlm: false, dataRoot: mkdtempSync(join(tmpdir(), 'blackjack-invariant-')) })
    const stub = stubAgent('blackjack-invariant-valid')
    ctx.agents.register(stub.agent)

    await ctx.blackjack.start(stub.agent, { deckSeed: 'invariant-valid' })
    const stand = await ctx.blackjack.stand(stub.agent)
    expect(stand.phase).toBe('dealer-turn')
    let view = stand
    for (let i = 0; i < 24 && view.phase === 'dealer-turn'; i += 1) {
      view = await ctx.blackjack.dealer(stub.agent)
    }
    expect(view.phase).toBe('settled')
    // Blackjack events now persist plugin-side, so the harness log stays
    // free of them while the invariant companion still validates the game.
    expect(view.record.losses + view.record.wins + view.record.pushes).toBe(1)
    expect(stub.session.events.some(event => event.type.startsWith('blackjack/'))).toBe(false)
  })

  it('rejects a settle without an open round', async () => {
    const ctx = await setup()
    const session = ctx.sessions.create(SessionId('blackjack-invariant-no-round'))
    expect(() => {
      session.append('blackjack/settle', {
        round: 1,
        result: 'push',
        playerTotal: 20,
        dealerTotal: 20,
      })
    }).toThrow(expect.objectContaining<Partial<InvariantError>>({
      code: 'INVARIANT',
      packageName: '@deepseek-ai/dsh-blackjack',
    }))
    expect(session.seq).toBe(0)
  })

  it('rejects a second settle for the same round', async () => {
    const ctx = await setup()
    const session = ctx.sessions.create(SessionId('blackjack-invariant-double-settle'))
    const seed = 'invariant-double-settle'
    const { player, dealer } = deal(seed)
    const result = settle(player, dealer)
    session.append('blackjack/game-start', { round: 1, deckSeed: seed })
    session.append('blackjack/settle', {
      round: 1,
      result,
      playerTotal: player.total,
      dealerTotal: dealer.total,
    })
    expect(() => {
      session.append('blackjack/settle', {
        round: 1,
        result,
        playerTotal: player.total,
        dealerTotal: dealer.total,
      })
    }).toThrow(expect.objectContaining<Partial<InvariantError>>({
      code: 'INVARIANT',
      packageName: '@deepseek-ai/dsh-blackjack',
    }))
  })

  it('rejects a tampered draw that diverges from the seeded deck', async () => {
    const ctx = await setup()
    const session = ctx.sessions.create(SessionId('blackjack-invariant-tampered'))
    const seed = 'invariant-tampered'
    const { player } = deal(seed)
    const expected = shuffleDeck(FULL_DECK, seed)[4]!
    const tamperedCard: Card = { suit: expected.suit === '♠' ? '♥' : '♠', rank: expected.rank === 'A' ? '2' : 'A' }
    session.append('blackjack/game-start', { round: 1, deckSeed: seed })
    expect(() => {
      session.append('blackjack/hit', {
        round: 1,
        player: [...player.cards, tamperedCard],
      })
    }).toThrow(expect.objectContaining<Partial<InvariantError>>({
      code: 'INVARIANT',
      packageName: '@deepseek-ai/dsh-blackjack',
    }))
  })

  it('rejects a hit while the dealer turn is open', async () => {
    const ctx = await setup()
    const session = ctx.sessions.create(SessionId('blackjack-invariant-wrong-phase'))
    const seed = 'invariant-wrong-phase'
    const { player } = deal(seed)
    session.append('blackjack/game-start', { round: 1, deckSeed: seed })
    session.append('blackjack/stand', { round: 1, playerTotal: player.total })
    expect(() => {
      session.append('blackjack/hit', { round: 1, player: player.cards })
    }).toThrow(expect.objectContaining<Partial<InvariantError>>({
      code: 'INVARIANT',
      packageName: '@deepseek-ai/dsh-blackjack',
    }))
  })

  it('rejects an emotion event that diverges from the folded mood', async () => {
    const ctx = await setup()
    const session = ctx.sessions.create(SessionId('blackjack-invariant-emotion'))
    const seed = 'invariant-emotion'
    const { player, dealer } = deal(seed)
    const result = settle(player, dealer)
    session.append('blackjack/game-start', { round: 1, deckSeed: seed })
    session.append('blackjack/settle', {
      round: 1,
      result,
      playerTotal: player.total,
      dealerTotal: dealer.total,
    })
    expect(() => {
      session.append('blackjack/emotion', { emotion: 'broken' })
    }).toThrow(expect.objectContaining<Partial<InvariantError>>({
      code: 'INVARIANT',
      packageName: '@deepseek-ai/dsh-blackjack',
    }))
  })

  it('reconstructs an existing durable round before checking later events', async () => {
    const ctx = new Context()
    await ctx.plugin(SessionStore)
    const session = ctx.sessions.create(SessionId('blackjack-invariant-late-load'))
    const seed = 'invariant-late-load'
    const { player, dealer } = deal(seed)
    const result = settle(player, dealer)
    session.append('blackjack/game-start', { round: 1, deckSeed: seed })
    session.append('blackjack/stand', { round: 1, playerTotal: player.total })
    session.append('blackjack/settle', {
      round: 1,
      result,
      playerTotal: player.total,
      dealerTotal: dealer.total,
    })

    await ctx.plugin(InvariantRegistry, { enabled: true })
    await ctx.plugin(BlackjackInvariantCompanion)
    session.append('blackjack/emotion', { emotion: 'calm' })
    expect(() => {
      session.append('blackjack/hit', { round: 1, player: player.cards })
    }).toThrow(expect.objectContaining<Partial<InvariantError>>({
      code: 'INVARIANT',
      packageName: '@deepseek-ai/dsh-blackjack',
    }))
  })
})
