/**
 * Engine unit tests: scoring, seeded determinism, player decisions, dealer
 * policy, settlement, and emotion folding. All pure-function assertions —
 * no services, no I/O.
 */
import { describe, expect, it } from 'vitest'
import {
  BLACKJACK_PERSONA_LIST,
  FALLBACK_BANTER,
  FULL_DECK,
  applyPlayerDecision,
  deal,
  dealerPolicy,
  fallbackBanter,
  foldEmotion,
  handOf,
  resultDirection,
  scoreHand,
  settle,
  shuffleDeck,
} from '../src/game/index'

describe('shuffleDeck', () => {
  it('preserves all 52 cards', () => {
    const shuffled = shuffleDeck(FULL_DECK, 'seed-1')
    expect(shuffled).toHaveLength(52)
    const keys = shuffled.map(card => `${card.suit}${card.rank}`).sort()
    expect(new Set(keys).size).toBe(52)
  })

  it('is deterministic for the same seed', () => {
    const a = shuffleDeck(FULL_DECK, 'same-seed')
    const b = shuffleDeck(FULL_DECK, 'same-seed')
    expect(a).toEqual(b)
  })

  it('differs across seeds', () => {
    const a = shuffleDeck(FULL_DECK, 'seed-a')
    const b = shuffleDeck(FULL_DECK, 'seed-b')
    expect(a).not.toEqual(b)
  })
})

describe('scoreHand', () => {
  it('counts face cards as 10', () => {
    expect(scoreHand([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: 'Q' }]).total).toBe(20)
  })

  it('counts an ace as 11 when it does not bust', () => {
    expect(scoreHand([{ suit: '♠', rank: 'A' }, { suit: '♥', rank: '7' }]).total).toBe(18)
  })

  it('counts an ace as 1 when 11 would bust', () => {
    const scored = scoreHand([{ suit: '♠', rank: 'A' }, { suit: '♥', rank: 'K' }, { suit: '♦', rank: '5' }])
    expect(scored.total).toBe(16)
    expect(scored.bust).toBe(false)
  })

  it('detects natural blackjack', () => {
    const scored = scoreHand([{ suit: '♠', rank: 'A' }, { suit: '♥', rank: 'K' }])
    expect(scored.blackjack).toBe(true)
    expect(scored.total).toBe(21)
  })

  it('does not call a three-card 21 a blackjack', () => {
    const scored = scoreHand([{ suit: '♠', rank: 'A' }, { suit: '♥', rank: '5' }, { suit: '♦', rank: '5' }])
    expect(scored.total).toBe(21)
    expect(scored.blackjack).toBe(false)
  })

  it('flags busts', () => {
    const scored = scoreHand([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: 'Q' }, { suit: '♦', rank: '3' }])
    expect(scored.total).toBe(23)
    expect(scored.bust).toBe(true)
  })
})

describe('deal', () => {
  it('deals two cards each and is deterministic per seed', () => {
    const first = deal('round-1')
    const second = deal('round-1')
    expect(first.player.cards).toHaveLength(2)
    expect(first.dealer.cards).toHaveLength(2)
    expect(first.player).toEqual(second.player)
    expect(first.dealer).toEqual(second.dealer)
    expect(first.deck).toHaveLength(48)
  })

  it('deals distinct cards', () => {
    const { player, dealer } = deal('round-2')
    const all = [...player.cards, ...dealer.cards]
    expect(new Set(all.map(card => `${card.suit}${card.rank}`)).size).toBe(4)
  })
})

describe('applyPlayerDecision', () => {
  it('draws one card on hit', () => {
    const opened = deal('round-3')
    const next = applyPlayerDecision(opened.player, { kind: 'hit' }, opened.deck)
    expect(next.hand.cards).toHaveLength(3)
    expect(next.deck).toHaveLength(47)
  })

  it('keeps the hand on stand', () => {
    const opened = deal('round-4')
    const next = applyPlayerDecision(opened.player, { kind: 'stand' }, opened.deck)
    expect(next.hand).toEqual(opened.player)
    expect(next.deck).toHaveLength(48)
  })
})

describe('dealerPolicy', () => {
  it('stands on 17', () => {
    expect(dealerPolicy(handOf([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: '7' }]))).toEqual({ kind: 'stand' })
  })

  it('hits below 17', () => {
    expect(dealerPolicy(handOf([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: '5' }]))).toEqual({ kind: 'hit' })
  })
})

describe('settle', () => {
  it('player bust loses', () => {
    const player = handOf([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: 'Q' }, { suit: '♦', rank: '3' }])
    const dealer = handOf([{ suit: '♠', rank: '9' }, { suit: '♥', rank: '7' }])
    expect(settle(player, dealer)).toBe('dealer-win')
  })

  it('dealer bust wins (non-blackjack)', () => {
    const player = handOf([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: '8' }])
    const dealer = handOf([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: '6' }, { suit: '♦', rank: '7' }])
    expect(settle(player, dealer)).toBe('player-win')
  })

  it('blackjack beats a non-blackjack dealer', () => {
    const player = handOf([{ suit: '♠', rank: 'A' }, { suit: '♥', rank: 'K' }])
    const dealer = handOf([{ suit: '♠', rank: '10' }, { suit: '♥', rank: '9' }])
    expect(settle(player, dealer)).toBe('player-blackjack')
  })

  it('higher total wins', () => {
    const player = handOf([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: '9' }])
    const dealer = handOf([{ suit: '♠', rank: '10' }, { suit: '♥', rank: '8' }])
    expect(settle(player, dealer)).toBe('player-win')
  })

  it('equal totals push', () => {
    const player = handOf([{ suit: '♠', rank: 'K' }, { suit: '♥', rank: '9' }])
    const dealer = handOf([{ suit: '♠', rank: '10' }, { suit: '♥', rank: '9' }])
    expect(settle(player, dealer)).toBe('push')
  })
})

describe('resultDirection', () => {
  it('maps outcomes to streaks', () => {
    expect(resultDirection('player-win')).toBe('win')
    expect(resultDirection('player-blackjack')).toBe('win')
    expect(resultDirection('dealer-win')).toBe('loss')
    expect(resultDirection('push')).toBe('draw')
  })
})

describe('foldEmotion', () => {
  it('stays calm through mixed results', () => {
    expect(foldEmotion('calm', 'player-win', 1, 0)).toBe('calm')
    expect(foldEmotion('calm', 'push', 0, 0)).toBe('calm')
  })

  it('turns nervous after two consecutive wins', () => {
    expect(foldEmotion('calm', 'player-win', 2, 0)).toBe('nervous')
  })

  it('turns broken after four consecutive wins', () => {
    expect(foldEmotion('calm', 'player-win', 4, 0)).toBe('broken')
  })

  it('turns smug after three consecutive losses', () => {
    expect(foldEmotion('calm', 'dealer-win', 0, 3)).toBe('smug')
  })

  it('relaxes broken to nervous on a loss', () => {
    expect(foldEmotion('broken', 'dealer-win', 0, 1)).toBe('nervous')
  })

  it('relaxes nervous to calm on a loss', () => {
    expect(foldEmotion('nervous', 'dealer-win', 0, 1)).toBe('calm')
  })

  it('clears smug on a win', () => {
    expect(foldEmotion('smug', 'player-win', 1, 0)).toBe('calm')
  })
})

describe('fallbackBanter', () => {
  it('returns a persona line for known triggers', () => {
    expect(fallbackBanter('大肥鱼', 'player-bust', 0)).toContain('爆')
    expect(fallbackBanter('雌小鬼', 'player-bust', 0)).toContain('爆')
    expect(fallbackBanter('大肥鱼', 'game-start', 0)).toContain('咕噜')
    expect(fallbackBanter('雌小鬼', 'game-start', 0)).toContain('杂鱼')
  })

  it('rotates by round within one persona', () => {
    const a = fallbackBanter('大肥鱼', 'game-start', 0)
    const b = fallbackBanter('大肥鱼', 'game-start', 1)
    expect(a).not.toBe(b)
  })

  it('returns empty for unknown triggers', () => {
    expect(fallbackBanter('大肥鱼', 'nope' as never, 0)).toBe('')
  })

  it('keeps the two personas apart', () => {
    expect(FALLBACK_BANTER['大肥鱼']).not.toEqual(FALLBACK_BANTER['雌小鬼'])
    for (const persona of BLACKJACK_PERSONA_LIST) {
      for (const [trigger, pool] of Object.entries(FALLBACK_BANTER[persona])) {
        expect(pool.length).toBeGreaterThan(0)
        // Every line carries at least one emoji — the dealer emotes too.
        expect(pool.some(line => /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(line))).toBe(true)
        void trigger
      }
    }
  })
})
