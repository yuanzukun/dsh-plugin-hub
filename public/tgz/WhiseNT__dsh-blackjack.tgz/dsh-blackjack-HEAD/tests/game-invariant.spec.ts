/**
 * Game-package type and invariant tests: closed-union guards reject
 * unknown values, and the companion registers against the invariants service.
 */
import { describe, expect, it } from 'vitest'
import { assertCard, assertEmotion, assertResult } from '../src/game/invariant'

describe('assertCard', () => {
  it('accepts valid cards', () => {
    expect(() => assertCard({ suit: '♠', rank: 'A' })).not.toThrow()
    expect(() => assertCard({ suit: '♥', rank: '10' })).not.toThrow()
  })

  it('rejects invalid suits and ranks', () => {
    expect(() => assertCard({ suit: '★' as never, rank: 'A' })).toThrow()
    expect(() => assertCard({ suit: '♠', rank: '0' as never })).toThrow()
    expect(() => assertCard({ suit: '♠', rank: 'X' as never })).toThrow()
  })
})

describe('assertResult', () => {
  it('accepts the closed union', () => {
    expect(() => assertResult('player-win')).not.toThrow()
    expect(() => assertResult('push')).not.toThrow()
  })

  it('rejects unknown values', () => {
    expect(() => assertResult('nope' as never)).toThrow()
  })
})

describe('assertEmotion', () => {
  it('accepts the closed union', () => {
    expect(() => assertEmotion('calm')).not.toThrow()
    expect(() => assertEmotion('broken')).not.toThrow()
  })

  it('rejects unknown values', () => {
    expect(() => assertEmotion('angry' as never)).toThrow()
  })
})
