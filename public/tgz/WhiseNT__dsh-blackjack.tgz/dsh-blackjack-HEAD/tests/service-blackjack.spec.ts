/**
 * Service and fold unit tests: round lifecycle, seeded determinism, bust
 * settlement, policy dealer loop, banter durability, random-taunt gating,
 * emotion folding, LLM integration, and strict replay from the plugin-side
 * sidecar log. The LLM route is disabled or stubbed so every table outcome
 * is governed by the deterministic rules engine.
 */
import { describe, expect, it } from 'vitest'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import AgentRegistry, { Inbox } from '@deepseek-ai/dsh-agent'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import type { Hand } from '../src/game'
import {
  FULL_DECK,
  deal,
  handOf,
  settle,
  shuffleDeck,
  type Card,
} from '../src/game'
import { BlackjackSidecar } from '../src/service/sidecar'
import type { BlackjackSidecarEvent } from '../src/service/sidecar'
import BlackjackService, {
  BlackjackError,
  DEFAULT_BLACKJACK_CONFIG,
  blackjackView,
  foldBlackjack,
  resolveBlackjackConfig,
} from '../src/service/index'
import type { BlackjackView } from '../src/service/index'

interface StubAgent {
  agent: Agent
  session: Session
}

/** Build a registry-compatible agent around one concrete session. */
function stubAgentForSession(session: Session, options: Agent['options'] = {}): StubAgent {
  const inbox = new Inbox(session, { inserted: () => {}, discarded: () => {}, claimed: () => {} })
  const agent: Agent = {
    id: session.id,
    options,
    session,
    inbox,
    ctx: new Context(),
    status: 'idle',
    send: () => {},
    followup: () => {},
    steer: () => {},
    inject(input) { inbox.append('next-step', input) },
    cancel() {},
    runMaintenance: task => task(new AbortController().signal),
    whenIdle() { return Promise.resolve() },
  }
  return { agent, session }
}

/** Build a registry-compatible agent around a fresh session. */
function stubAgent(rawId: string, options: Agent['options'] = {}): StubAgent {
  return stubAgentForSession(Session.create(SessionId(rawId)), options)
}

/** A stub LLM route: `stream` never runs under `dealerLlm: false`. */
function stubLlm(stream?: (options: { signal?: AbortSignal }) => AsyncIterable<unknown>): never {
  return { stream: stream ?? async function* () {} } as never
}

async function harness(
  config: Parameters<typeof resolveBlackjackConfig>[0] = {},
  options: Agent['options'] = {},
  stream?: (options: { signal?: AbortSignal }) => AsyncIterable<unknown>,
) {
  const dataRoot = mkdtempSync(join(tmpdir(), 'blackjack-test-'))
  const ctx = new Context()
  await ctx.plugin(AgentRegistry)
  ctx.provide('llm', stubLlm(stream))
  await ctx.plugin(BlackjackService, { ...config, dataRoot })
  const stub = stubAgent(`blackjack-test-${Math.random()}`, options)
  ctx.agents.register(stub.agent)
  return { ctx, dataRoot, ...stub }
}

/** The plugin-side durable events of one session. */
function sidecarEvents(dataRoot: string, sessionId: string): BlackjackSidecarEvent[] {
  return BlackjackSidecar.forSession(sessionId, dataRoot).load()
}

/** Brute-force a seed whose opening hands satisfy the predicate. */
function findSeed(predicate: (seed: string, player: Hand, dealer: Hand) => boolean, prefix = 'seed'): string {
  for (let i = 0; i < 1000; i += 1) {
    const seed = `${prefix}-${i}`
    const { player, dealer } = deal(seed)
    if (predicate(seed, player, dealer)) return seed
  }
  throw new Error(`no seed found for ${prefix}`)
}

/** Simulate one policy round where the player stands immediately. */
function simulatePolicyStand(seed: string): { player: Hand; dealer: Hand } {
  const dealt = deal(seed)
  const player = dealt.player
  let { deck, dealer } = dealt
  while (!dealer.bust && dealer.total < 17) {
    const [drawn, ...rest] = deck
    if (drawn === undefined) break
    dealer = handOf([...dealer.cards, drawn])
    deck = rest
  }
  return { player, dealer }
}

/** Flush pending background banter commits (fire-and-forget greetings, taunts). */
async function settleChatter(): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 0))
  await new Promise(resolve => setTimeout(resolve, 0))
}

/** Stand, then drive the dealer turn step by step until the round settles. */
async function playDealer(
  ctx: Awaited<ReturnType<typeof harness>>['ctx'],
  agent: Agent,
): Promise<BlackjackView> {
  let view = await ctx.blackjack.stand(agent)
  expect(view.phase).toBe('dealer-turn')
  for (let i = 0; i < 24 && view.phase === 'dealer-turn'; i += 1) {
    view = await ctx.blackjack.dealer(agent)
  }
  expect(view.phase).toBe('settled')
  return view
}

describe('BlackjackService round lifecycle', () => {
  it('migrates a legacy harness-log stream into the plugin sidecar', async () => {
    // A session whose harness log already carries blackjack events (written
    // before the plugin moved to sidecar persistence) must replay them into
    // the sidecar on first load, without touching the harness log.
    const dataRoot = mkdtempSync(join(tmpdir(), 'blackjack-test-'))
    const seed = 'migrate-legacy'
    const { player, dealer } = deal(seed)
    const legacy: SessionEvent[] = [
      { type: 'blackjack/game-start', seq: 0, time: 1, data: { round: 1, deckSeed: seed } },
      {
        type: 'blackjack/settle', seq: 1, time: 2,
        data: { round: 1, result: settle(player, dealer), playerTotal: player.total, dealerTotal: dealer.total },
      },
    ]
    const session = Session.create(SessionId('migrate-legacy'), legacy)
    const ctx = new Context()
    await ctx.plugin(AgentRegistry)
    ctx.provide('llm', stubLlm())
    await ctx.plugin(BlackjackService, { dealerLlm: false, dataRoot })
    const stub = stubAgentForSession(session)
    ctx.agents.register(stub.agent)

    const view = await ctx.blackjack.view(stub.agent)
    expect(view.round).toBe(1)
    expect(view.phase).toBe('settled')
    expect(sidecarEvents(dataRoot, session.id).map(event => event.type))
      .toEqual(['blackjack/game-start', 'blackjack/settle'])
    // The harness log is left untouched by the migration.
    expect(session.events.filter(event => event.type.startsWith('blackjack/'))).toHaveLength(2)
  })

  it('starts a seeded round with a dealer greeting', async () => {
    const seed = 'round-lifecycle-0'
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    const view = await ctx.blackjack.start(agent, { deckSeed: seed })

    expect(view).toMatchObject({
      round: 1,
      phase: 'player-turn',
      emotion: 'calm',
      record: { wins: 0, losses: 0, pushes: 0, blackjacks: 0 },
    })
    expect(view.player.cards).toEqual(deal(seed).player.cards)
    expect(view.dealer.cards).toEqual(deal(seed).dealer.cards)
    // The greeting is fire-and-forget: dealing never waits on the model. It
    // lands in the plugin sidecar moments later and surfaces through the
    // next view pull.
    expect(view.banter).toHaveLength(0)
    await settleChatter()
    const refreshed = await ctx.blackjack.view(agent)
    expect(refreshed.banter).toHaveLength(1)
    expect(refreshed.banter[0]).toMatchObject({ from: 'dealer' })
    const events = sidecarEvents(dataRoot, session.id)
    expect(events.map(event => event.type)).toEqual(['blackjack/game-start', 'blackjack/banter'])
    expect(events[0]?.data).toMatchObject({ round: 1, deckSeed: seed })
    expect(events[1]?.data).toMatchObject({ from: 'dealer', trigger: 'game-start', round: 1 })
    // The harness session log stays free of plugin events.
    expect(session.events.some(event => event.type.startsWith('blackjack/'))).toBe(false)
  })

  it('generates a random deck seed when none is supplied', async () => {
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    const view = await ctx.blackjack.start(agent, {})
    expect(view.round).toBe(1)
    expect(view.player.cards).toHaveLength(2)
    expect(sidecarEvents(dataRoot, session.id)[0]?.type).toBe('blackjack/game-start')
  })

  it('rejects starting while a round is in progress', async () => {
    const { ctx, agent } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: 'double-start' })
    await expect(ctx.blackjack.start(agent, { deckSeed: 'double-start-2' })).rejects.toThrow(
      expect.objectContaining({ code: 'BLACKJACK_ROUND_IN_PROGRESS' }),
    )
  })

  it('rejects hit and stand before any round', async () => {
    const { ctx, agent } = await harness({ dealerLlm: false })
    await expect(ctx.blackjack.hit(agent)).rejects.toThrow(expect.objectContaining({ code: 'BLACKJACK_NO_ROUND' }))
    await expect(ctx.blackjack.stand(agent)).rejects.toThrow(expect.objectContaining({ code: 'BLACKJACK_NO_ROUND' }))
  })

  it('rejects hit and stand after the round settled', async () => {
    const seed = findSeed((_seed, player) => player.total >= 17 && player.total <= 20, 'settled-turn')
    const { ctx, agent } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: seed })
    await playDealer(ctx, agent)
    await expect(ctx.blackjack.hit(agent)).rejects.toThrow(expect.objectContaining({ code: 'BLACKJACK_INVALID_ACTION' }))
    await expect(ctx.blackjack.stand(agent)).rejects.toThrow(expect.objectContaining({ code: 'BLACKJACK_INVALID_ACTION' }))
    await expect(ctx.blackjack.dealer(agent)).rejects.toThrow(expect.objectContaining({ code: 'BLACKJACK_INVALID_ACTION' }))
  })

  it('serves a read-only view verb without committing anything', async () => {
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    const before = sidecarEvents(dataRoot, session.id).length
    const view = await ctx.blackjack.view(agent)
    expect(view.round).toBe(0)
    expect(view.phase).toBe('idle')
    expect(sidecarEvents(dataRoot, session.id).length).toBe(before)
  })

  it('runs one dealer step at a time and reveals the draws', async () => {
    const seed = findSeed((_seed, player, dealer) => player.total >= 12 && dealer.total < 17, 'step')
    const { ctx, agent } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: seed })
    const stand = await ctx.blackjack.stand(agent)
    expect(stand.phase).toBe('dealer-turn')
    // The hole card turns face-up the moment the dealer turn opens.
    expect(stand.dealerHidden).toBe(false)
    const before = stand.dealer.cards.length
    const step = await ctx.blackjack.dealer(agent)
    // The policy dealer on <17 draws exactly one card per step.
    expect(step.dealer.cards.length).toBe(before + 1)
  })

  it('rejects dealer steps outside the dealer turn', async () => {
    const { ctx, agent } = await harness({ dealerLlm: false })
    await expect(ctx.blackjack.dealer(agent)).rejects.toThrow(expect.objectContaining({ code: 'BLACKJACK_NO_ROUND' }))
    await ctx.blackjack.start(agent, { deckSeed: 'dealer-guard' })
    await expect(ctx.blackjack.dealer(agent)).rejects.toThrow(expect.objectContaining({ code: 'BLACKJACK_INVALID_ACTION' }))
  })

  it('rejects agents that are not live in the registry', async () => {
    const { ctx, agent } = await harness({ dealerLlm: false })
    const stranger = stubAgent('blackjack-stranger')
    await expect(ctx.blackjack.start(stranger.agent, { deckSeed: 'x' })).rejects.toThrow(
      expect.objectContaining({ code: 'BLACKJACK_AGENT_NOT_LIVE' }),
    )
    expect(agent.id).not.toBe(stranger.agent.id)
  })

  it('hits the seeded card and settles a bust immediately', async () => {
    const seed = findSeed((seed, player) => handOf([...player.cards, shuffleDeck(FULL_DECK, seed)[4]!]).bust, 'bust-hit')
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: seed })
    const view = await ctx.blackjack.hit(agent)

    expect(view.phase).toBe('settled')
    expect(view.player.bust).toBe(true)
    expect(view.player.cards).toHaveLength(3)
    expect(view.record.losses).toBe(1)
    expect(view.emotion).toBe('calm')
    // The greeting and the bust line commit in the background after the
    // game events, in fire order.
    await settleChatter()
    const events = sidecarEvents(dataRoot, session.id)
    expect(events.map(event => event.type)).toEqual([
      'blackjack/game-start',
      'blackjack/hit',
      'blackjack/settle',
      'blackjack/emotion',
      'blackjack/banter',
      'blackjack/banter',
    ])
    expect(events[2]?.data).toMatchObject({ result: 'dealer-win', round: 1 })
    expect(events[5]?.data).toMatchObject({ from: 'dealer', trigger: 'player-bust' })
  })

  it('stands and runs the policy dealer loop to settlement', async () => {
    const seed = findSeed((_seed, player) => player.total >= 12, 'policy-stand')
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: seed })
    const view = await playDealer(ctx, agent)

    expect(view.phase).toBe('settled')
    expect(view.player.cards).toHaveLength(2)
    expect(view.dealer.bust || view.dealer.total >= 17).toBe(true)
    const expected = settle(view.player, view.dealer)
    await settleChatter()
    const events = sidecarEvents(dataRoot, session.id)
    const settleEvent = events.filter(event => event.type === 'blackjack/settle').at(-1)
    expect(settleEvent?.data).toMatchObject({ result: expected, playerTotal: view.player.total, dealerTotal: view.dealer.total })
    const emotionEvent = events.filter(event => event.type === 'blackjack/emotion').at(-1)
    expect(emotionEvent?.data.emotion).toBe('calm')
  })

  it('records wins, blackjacks, and folds the dealer mood across rounds', async () => {
    // Pick two seeds where standing on the opening hand beats the policy dealer.
    const winSeeds: string[] = []
    for (let i = 0; i < 1000 && winSeeds.length < 2; i += 1) {
      const candidate = `mood-win-${i}`
      const { player, dealer } = simulatePolicyStand(candidate)
      if (settle(player, dealer) === 'player-win' && !player.blackjack) winSeeds.push(candidate)
    }
    expect(winSeeds.length).toBe(2)

    const { ctx, agent } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: winSeeds[0]! })
    const first = await playDealer(ctx, agent)
    expect(first.record).toMatchObject({ wins: 1, losses: 0, blackjacks: 0 })
    expect(first.emotion).toBe('calm')

    await ctx.blackjack.start(agent, { deckSeed: winSeeds[1]! })
    const second = await playDealer(ctx, agent)
    expect(second.record).toMatchObject({ wins: 2, losses: 0 })
    expect(second.emotion).toBe('nervous')
  })

  it('turns smug after three busted rounds', async () => {
    const bustSeed = findSeed((seed, player) => handOf([...player.cards, shuffleDeck(FULL_DECK, seed)[4]!]).bust, 'smug-bust')
    const { ctx, agent } = await harness({ dealerLlm: false })
    let view: BlackjackView | undefined
    for (let round = 1; round <= 3; round += 1) {
      await ctx.blackjack.start(agent, { deckSeed: bustSeed })
      view = await ctx.blackjack.hit(agent)
      expect(view.record.losses).toBe(round)
    }
    expect(view?.emotion).toBe('smug')
    expect(view?.record.blackjacks).toBe(0)
  })

  it('replies to banter with a durable dealer line', async () => {
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: 'banter-reply' })
    const result = await ctx.blackjack.banter(agent, { content: '  你输定了！  ' })

    expect(result.reply.length).toBeGreaterThan(0)
    await settleChatter()
    // Background chatter (the greeting) lands around the exchange; identify
    // the pair by speaker and trigger instead of absolute positions.
    const events = sidecarEvents(dataRoot, session.id)
    const playerLine = events.find(event =>
      event.type === 'blackjack/banter' && event.data.from === 'player')
    const dealerLine = events.find(event =>
      event.type === 'blackjack/banter' && event.data.from === 'dealer' && event.data.trigger === 'reply')
    expect(playerLine?.data).toMatchObject({ from: 'player', content: '你输定了！' })
    expect(dealerLine?.data).toMatchObject({ from: 'dealer', content: result.reply, trigger: 'reply' })
  })

  it('rejects empty banter content', async () => {
    const { ctx, agent } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: 'empty-banter' })
    await expect(ctx.blackjack.banter(agent, { content: '   ' })).rejects.toThrow(
      expect.objectContaining({ code: 'BLACKJACK_EMPTY_BANTER' }),
    )
  })

  it('keeps the banter history across rounds and player lines', async () => {
    const { ctx, agent } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: 'banter-history' })
    const reply = await ctx.blackjack.banter(agent, { content: '第一句' })
    await playDealer(ctx, agent)
    await ctx.blackjack.start(agent, { deckSeed: 'banter-history-2' })
    await playDealer(ctx, agent)
    await settleChatter()
    const view = await ctx.blackjack.view(agent)
    // Greeting, exchange, settle line, next greeting, next settle line: six
    // durable lines, with the player line before its reply.
    expect(view.banter).toHaveLength(6)
    expect(view.banter.every(line => line.from === 'player' || line.from === 'dealer')).toBe(true)
    const playerIndex = view.banter.findIndex(line => line.content === '第一句')
    const replyIndex = view.banter.findIndex(line => line.content === reply.reply)
    expect(playerIndex).toBeGreaterThanOrEqual(0)
    expect(replyIndex).toBeGreaterThan(playerIndex)
  })

  it('fires random taunts only when the config chance admits them', async () => {
    const safeSeed = findSeed((_seed, player) => player.total <= 10, 'random-safe')
    const quiet = await harness({ dealerLlm: false, randomBanterChance: 0 })
    await quiet.ctx.blackjack.start(quiet.agent, { deckSeed: safeSeed })
    await quiet.ctx.blackjack.hit(quiet.agent)
    await settleChatter()
    const quietTriggers = sidecarEvents(quiet.dataRoot, quiet.session.id)
      .filter(event => event.type === 'blackjack/banter')
      .map(event => (event.type === 'blackjack/banter' ? event.data.trigger : undefined))
    expect(quietTriggers).toEqual(['game-start'])

    const chatty = await harness({ dealerLlm: false, randomBanterChance: 1 })
    await chatty.ctx.blackjack.start(chatty.agent, { deckSeed: safeSeed })
    await chatty.ctx.blackjack.hit(chatty.agent)
    await settleChatter()
    const chattyTriggers = sidecarEvents(chatty.dataRoot, chatty.session.id)
      .filter(event => event.type === 'blackjack/banter')
      .map(event => (event.type === 'blackjack/banter' ? event.data.trigger : undefined))
    expect(chattyTriggers).toEqual(['game-start', 'random'])
  })
})

describe('BlackjackService LLM integration', () => {
  it('uses model decisions with provenance when the route and LLM are configured', async () => {
    const seed = findSeed((_seed, player) => player.total >= 12, 'llm-stand')
    const json = JSON.stringify({ action: 'stand', reason: '我心情好，放你一马' })
    const stream = async function* () {
      yield { type: 'block-start', index: 0, blockType: 'text' }
      yield { type: 'text-delta', index: 0, text: json }
      yield { type: 'block-end', index: 0, block: { type: 'text', text: json } }
      yield { type: 'finish', reason: { kind: 'stop' } }
    }
    const { ctx, agent, session, dataRoot } = await harness(
      { dealerLlm: true },
      { provider: 'mock', model: 'dealer-model' },
      stream,
    )
    await ctx.blackjack.start(agent, { deckSeed: seed })
    const stand = await ctx.blackjack.stand(agent)
    expect(stand.phase).toBe('dealer-turn')
    const view = await ctx.blackjack.dealer(agent)

    expect(view.phase).toBe('settled')
    const events = sidecarEvents(dataRoot, session.id)
    const dealerHit = events.find(event => event.type === 'blackjack/dealer-hit')
    expect(dealerHit?.data.decision).toBe('stand')
    expect(dealerHit?.data.llm).toEqual({ provider: 'mock', model: 'dealer-model' })
    // The same stub output is not a valid banter reply, so the greeting falls back.
    await settleChatter()
    expect(sidecarEvents(dataRoot, session.id).filter(event => event.type === 'blackjack/banter').length).toBeGreaterThanOrEqual(1)
  })

  it('degrades a failing model to the local policy mid-round', async () => {
    const seed = findSeed((_seed, player, dealer) => player.total >= 12 && dealer.total < 17, 'llm-fail')
    const stream = async function* (): AsyncGenerator<never> {
      throw new Error('provider down')
    }
    const { ctx, agent, session, dataRoot } = await harness(
      { dealerLlm: true },
      { provider: 'mock', model: 'dealer-model' },
      stream,
    )
    await ctx.blackjack.start(agent, { deckSeed: seed })
    const view = await playDealer(ctx, agent)

    expect(view.phase).toBe('settled')
    const dealerHits = sidecarEvents(dataRoot, session.id).filter(event => event.type === 'blackjack/dealer-hit')
    expect(dealerHits.length).toBeGreaterThan(0)
    for (const event of dealerHits) {
      expect(event.data.llm).toBeUndefined()
      if (event.data.decision === 'hit') {
        expect(event.data.dealer.length).toBeGreaterThan(2)
      }
    }
  })
})

describe('BlackjackService config', () => {
  it('resolves documented defaults', () => {
    expect(resolveBlackjackConfig()).toEqual({
      dealerPersona: '大肥鱼',
      randomBanterChance: 0.3,
      maxDecisionTokens: 100,
      maxBanterTokens: 60,
      timeoutMs: 15000,
      dealerLlm: true,
    })
    expect(DEFAULT_BLACKJACK_CONFIG).toEqual(resolveBlackjackConfig())
  })

  it('rejects invalid config at direct construction', () => {
    // Cordis registers the service name on the owning context at construction,
    // so each failing construction gets a fresh context.
    const reject = (config: Record<string, unknown>): void => {
      expect(() => new BlackjackService(new Context(), config as never)).toThrow(
        expect.objectContaining({ code: 'BLACKJACK_INVALID_CONFIG' }),
      )
    }
    reject({ dealerPersona: 'evil' })
    reject({ randomBanterChance: 1.5 })
    reject({ maxDecisionTokens: 0 })
    reject({ timeoutMs: 0 })
    reject({ dealerLlm: 'yes' })
    reject({ surprise: 1 })
    expect(() => new BlackjackService(new Context(), { dealerPersona: 'evil' as never })).toThrow(BlackjackError)
  })
})

describe('BlackjackService persona', () => {
  it('starts on the configured persona and switches durably', async () => {
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false, dealerPersona: '雌小鬼' })
    const initial = await ctx.blackjack.start(agent, { deckSeed: 'persona-0' })
    expect(initial.persona).toBe('雌小鬼')

    const switched = await ctx.blackjack.persona(agent, { persona: '大肥鱼' })
    expect(switched.persona).toBe('大肥鱼')
    expect(switched.phase).toBe('player-turn')

    // The pick is an event, so a fresh fold replays the same persona.
    const events = sidecarEvents(dataRoot, session.id)
    expect(events.filter(event => event.type === 'blackjack/persona')).toHaveLength(1)
    expect(foldBlackjack(events as unknown as SessionEvent[]).persona).toBe('大肥鱼')
  })

  it('rejects an unknown persona fail-loud through the strict fold', async () => {
    const { ctx, agent } = await harness({ dealerLlm: false })
    await expect(ctx.blackjack.persona(agent, { persona: '毒舌' as never })).rejects.toThrow(/persona/)
  })
})

describe('BlackjackService memory', () => {
  it('clears the verdict when a new round opens but keeps the dealer\'s memory', async () => {
    const bustSeed = findSeed((seed, player) => handOf([...player.cards, shuffleDeck(FULL_DECK, seed)[4]!]).bust, 'memory')
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: bustSeed })
    await ctx.blackjack.hit(agent)
    const settled = await ctx.blackjack.view(agent)
    expect(settled.phase).toBe('settled')
    expect(settled.result).toBe('dealer-win')

    await ctx.blackjack.start(agent, { deckSeed: 'memory-next' })
    const fresh = await ctx.blackjack.view(agent)
    expect(fresh.phase).toBe('player-turn')
    expect(fresh.result).toBeUndefined()
    // The dealer's memory retains the previous verdict across rounds.
    const folded = foldBlackjack(sidecarEvents(dataRoot, session.id) as unknown as SessionEvent[])
    expect(folded.lastResult).toBe('dealer-win')
    expect(folded.record.losses).toBe(1)
  })
})

describe('BlackjackService replay and fold', () => {
  it('reconstructs the exact view from the plugin sidecar', async () => {
    const seed = findSeed((_seed, player) => player.total >= 12, 'replay')
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: seed })
    await ctx.blackjack.banter(agent, { content: '再来' })
    const live = await playDealer(ctx, agent)

    const durable = sidecarEvents(dataRoot, session.id)
    const folded = foldBlackjack(durable as unknown as SessionEvent[])
    expect(blackjackView(folded)).toEqual(live)

    // A second service over a session restored from the sidecar log must
    // serve the identical table.
    const replaySession = Session.create(SessionId('replay-restored'), [...durable] as unknown as SessionEvent[])
    const replayCtx = new Context()
    await replayCtx.plugin(AgentRegistry)
    replayCtx.provide('llm', stubLlm())
    await replayCtx.plugin(BlackjackService, { dealerLlm: false, dataRoot })
    const replayStub = stubAgentForSession(replaySession)
    replayCtx.agents.register(replayStub.agent)
    const restored = await replayCtx.blackjack.banter(replayStub.agent, { content: '查状态' })
    expect(restored.reply.length).toBeGreaterThan(0)
    // The restored session still serves the folded view through a new service.
    await expect(replayCtx.blackjack.start(replayStub.agent, { deckSeed: 'replay-next' })).resolves.toMatchObject({ round: 2 })
  })

  it('foldBlackjack throws on malformed streams', () => {
    const seed = 'malformed'
    const { player, dealer } = deal(seed)
    const result = settle(player, dealer)

    expect(() => foldBlackjack([
      { type: 'blackjack/hit', seq: 0, time: 1, data: { round: 1, player: player.cards } },
    ])).toThrow(/targets round 1 while round 0/)

    const start: SessionEvent = {
      type: 'blackjack/game-start', seq: 0, time: 1, data: { round: 1, deckSeed: seed },
    }
    expect(() => foldBlackjack([
      start,
      { type: 'blackjack/game-start', seq: 1, time: 2, data: { round: 2, deckSeed: seed } },
    ])).toThrow(/unclosed/)

    expect(() => foldBlackjack([
      start,
      { type: 'blackjack/hit', seq: 1, time: 2, data: { round: 2, player: player.cards } },
    ])).toThrow(/round 2 while round 1/)

    expect(() => foldBlackjack([
      start,
      { type: 'blackjack/hit', seq: 1, time: 2, data: { round: 1, player: [player.cards[0]!] } },
    ])).toThrow(/exactly one card/)

    // A tampered draw that differs from the deterministic deck order.
    const expected = shuffleDeck(FULL_DECK, seed)[4]!
    const tamperedCard: Card = { suit: expected.suit === '♠' ? '♥' : '♠', rank: expected.rank === 'A' ? '2' : 'A' }
    const tampered: SessionEvent = {
      type: 'blackjack/hit', seq: 1, time: 2,
      data: { round: 1, player: [...player.cards, tamperedCard] },
    }
    expect(() => foldBlackjack([start, tampered])).toThrow(/diverges from the seeded deck order/)

    const stand: SessionEvent = {
      type: 'blackjack/stand', seq: 1, time: 2, data: { round: 1, playerTotal: player.total },
    }
    expect(() => foldBlackjack([
      start,
      stand,
      { type: 'blackjack/hit', seq: 2, time: 3, data: { round: 1, player: player.cards } },
    ])).toThrow(/hit during/)

    expect(() => foldBlackjack([
      start,
      { type: 'blackjack/settle', seq: 1, time: 2, data: { round: 1, result, playerTotal: player.total, dealerTotal: dealer.total } },
      { type: 'blackjack/settle', seq: 2, time: 3, data: { round: 1, result, playerTotal: player.total, dealerTotal: dealer.total } },
    ])).toThrow(/settle during "settled"/)
  })

  it('rejects an emotion event that diverges from the folded mood', () => {
    const seed = 'emotion-mismatch'
    const { player, dealer } = deal(seed)
    const result = settle(player, dealer)
    expect(() => foldBlackjack([
      { type: 'blackjack/game-start', seq: 0, time: 1, data: { round: 1, deckSeed: seed } },
      { type: 'blackjack/settle', seq: 1, time: 2, data: { round: 1, result, playerTotal: player.total, dealerTotal: dealer.total } },
      { type: 'blackjack/emotion', seq: 2, time: 3, data: { emotion: 'smug' } },
    ])).toThrow(/diverges from the folded/)
  })

  it('rebuilds the live cache from a seeded sidecar log without re-publishing', async () => {
    const seed = findSeed((seed, player) => handOf([...player.cards, shuffleDeck(FULL_DECK, seed)[4]!]).bust, 'seed-cache')
    const { ctx, agent, session, dataRoot } = await harness({ dealerLlm: false })
    await ctx.blackjack.start(agent, { deckSeed: seed })
    await ctx.blackjack.hit(agent)
    const durable = sidecarEvents(dataRoot, session.id)
    const originalLength = durable.length

    const restored = Session.create(SessionId('seed-cache-restored'), [...durable] as unknown as SessionEvent[])
    // The constructor seed is never re-published: the restored log is the
    // original log plus the session's own end-seed marker (never a blackjack event).
    expect(restored.events.slice(0, originalLength)).toEqual([...durable] as unknown as SessionEvent[])
    expect(restored.events.slice(originalLength).every(event => event.type === 'session/end-seed')).toBe(true)
    const replayCtx = new Context()
    await replayCtx.plugin(AgentRegistry)
    replayCtx.provide('llm', stubLlm())
    await replayCtx.plugin(BlackjackService, { dealerLlm: false, dataRoot })
    const replayStub = stubAgentForSession(restored)
    replayCtx.agents.register(replayStub.agent)
    const view = await replayCtx.blackjack.banter(replayStub.agent, { content: '复盘的桌子' })
    expect(view.reply).toBeDefined()
    await expect(replayCtx.blackjack.start(replayStub.agent, { deckSeed: 'next-round' })).resolves.toMatchObject({ round: 2 })
  })
})
