/**
 * Dealer/banter LLM unit tests: prompt framing, JSON parsing, model
 * provenance, and the degrade paths (missing route, disabled LLM, stream
 * failure, terminal finish errors, malformed output, timeout).
 */
import { describe, expect, it, vi } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import type { StreamChunk } from '@deepseek-ai/dsh-llm'
import { dealerPolicy, fallbackBanter, handOf } from '../src/game'
import { banterPrompt, banterTriggerForResult, generateDealerBanter, recordLine, shouldRandomBanter } from '../src/service/banter'
import { dealerDecide, decisionPrompt } from '../src/service/dealer'
import { resolveBlackjackConfig } from '../src/service/runtime'
import type { DealerDecisionInput } from '../src/service/dealer'
import type { DealerBanterInput } from '../src/service/banter'

/** A stub context exposing only the LLM stream the aux modules touch. */
function stubCtx(stream: (options: { signal?: AbortSignal }) => AsyncIterable<unknown>): Context {
  return { llm: { stream } } as unknown as Context
}

/** Stream one complete text block. */
function textStream(json: string): (options: { signal?: AbortSignal }) => AsyncGenerator<StreamChunk> {
  return async function* () {
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text: json }
    yield { type: 'block-end', index: 0, block: { type: 'text', text: json } }
    yield { type: 'finish', reason: { kind: 'stop' } }
  }
}

/** Stream chunks then a terminal finish failure. */
function failingStream(): (options: { signal?: AbortSignal }) => AsyncGenerator<StreamChunk> {
  return async function* () {
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text: '{"action":' }
    yield { type: 'finish', reason: { kind: 'error', failure: { message: 'quota exceeded', code: 'QUOTA' } } }
  }
}

/** A table where the dealer holds a 12. */
function decisionInput(overrides: Partial<DealerDecisionInput> = {}): DealerDecisionInput {
  const player = handOf([{ suit: '♠', rank: '10' }, { suit: '♥', rank: '7' }])
  const dealer = handOf([{ suit: '♦', rank: '6' }, { suit: '♣', rank: '6' }])
  return {
    round: 1,
    player,
    dealer,
    emotion: 'calm',
    persona: '大肥鱼',
    record: { wins: 1, losses: 2, pushes: 0, blackjacks: 0 },
    banter: [],
    ...overrides,
  }
}

/** A banter context with a live table. */
function banterInput(overrides: Partial<DealerBanterInput> = {}): DealerBanterInput {
  const player = handOf([{ suit: '♠', rank: '10' }, { suit: '♥', rank: '7' }])
  const dealer = handOf([{ suit: '♦', rank: '6' }, { suit: '♣', rank: '6' }])
  return {
    round: 2,
    trigger: 'reply',
    player,
    dealer,
    emotion: 'nervous',
    persona: '雌小鬼',
    record: { wins: 1, losses: 2, pushes: 0, blackjacks: 0 },
    lastResult: 'player-win',
    playerLine: '你要输了',
    banter: [],
    ...overrides,
  }
}

describe('dealerDecide', () => {
  it('follows the local policy without a model route', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ action: 'stand', reason: 'unused' })))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const input = decisionInput()
    const result = await dealerDecide(ctx, config, input, undefined)
    expect(result.action).toBe(dealerPolicy(input.dealer).kind)
    expect(result.reason).toMatch(/本地策略/)
    expect(result.llm).toBeUndefined()
  })

  it('follows the local policy when the LLM is disabled', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ action: 'hit', reason: 'unused' })))
    const config = resolveBlackjackConfig({ dealerLlm: false })
    const result = await dealerDecide(ctx, config, decisionInput(), { provider: 'mock', model: 'm' })
    expect(result.action).toBe(dealerPolicy(decisionInput().dealer).kind)
    expect(result.llm).toBeUndefined()
  })

  it('parses a JSON hit decision with model provenance', async () => {
    const ctx = stubCtx(textStream('```json\n{"action":"hit","reason":"再抽一张试试水"}\n```'))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const result = await dealerDecide(ctx, config, decisionInput(), { provider: 'mock', model: 'm' })
    expect(result).toEqual({ action: 'hit', reason: '再抽一张试试水', llm: { provider: 'mock', model: 'm' } })
  })

  it('parses a JSON stand decision', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ action: 'stand', reason: '手气不错' })))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const result = await dealerDecide(ctx, config, decisionInput(), { provider: 'mock', model: 'm' })
    expect(result.action).toBe('stand')
    expect(result.reason).toBe('手气不错')
  })

  it('defaults a missing reason and still keeps provenance', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ action: 'stand' })))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const result = await dealerDecide(ctx, config, decisionInput(), { provider: 'mock', model: 'm' })
    expect(result.action).toBe('stand')
    expect(result.llm).toEqual({ provider: 'mock', model: 'm' })
  })

  it('degrades to the policy when the stream throws', async () => {
    const ctx = stubCtx(async function* () { throw new Error('provider down') })
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const input = decisionInput()
    const result = await dealerDecide(ctx, config, input, { provider: 'mock', model: 'm' })
    expect(result.action).toBe(dealerPolicy(input.dealer).kind)
    expect(result.reason).toMatch(/本地策略/)
    expect(result.llm).toBeUndefined()
  })

  it('degrades to the policy on a terminal finish error', async () => {
    const ctx = stubCtx(failingStream())
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const input = decisionInput()
    const result = await dealerDecide(ctx, config, input, { provider: 'mock', model: 'm' })
    expect(result.action).toBe(dealerPolicy(input.dealer).kind)
    expect(result.llm).toBeUndefined()
  })

  it('degrades to the policy on malformed model output', async () => {
    const ctx = stubCtx(textStream('今天的牌运不错，哈哈'))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const input = decisionInput()
    const result = await dealerDecide(ctx, config, input, { provider: 'mock', model: 'm' })
    expect(result.action).toBe(dealerPolicy(input.dealer).kind)
    expect(result.llm).toBeUndefined()
  })

  it('degrades to the policy on an invalid action value', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ action: 'double-down', reason: '疯狂' })))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const result = await dealerDecide(ctx, config, decisionInput(), { provider: 'mock', model: 'm' })
    expect(result.action).toBe('hit')
    expect(result.llm).toBeUndefined()
  })

  it('degrades to the policy when the deadline aborts a hanging stream', async () => {
    const stream = async function* (options: { signal?: AbortSignal }) {
      await new Promise((_resolve, reject) => {
        options.signal?.addEventListener('abort', () => {
          reject(new Error('blackjack deadline aborted'))
        })
      })
    }
    const ctx = stubCtx(stream)
    const config = resolveBlackjackConfig({ dealerLlm: true, timeoutMs: 10 })
    const input = decisionInput()
    const result = await dealerDecide(ctx, config, input, { provider: 'mock', model: 'm' })
    expect(result.action).toBe(dealerPolicy(input.dealer).kind)
    expect(result.llm).toBeUndefined()
  })

  it('frames the table state and persona in the prompt', () => {
    const prompt = decisionPrompt(decisionInput({ banter: [{ from: 'player', content: '你的牌是假的' }] }))
    expect(prompt).toContain('第 1 局')
    expect(prompt).toContain('♠10 ♥7')
    expect(prompt).toContain('大肥鱼')
    expect(prompt).toContain('你的牌是假的')
    // The dealer's memory: the session ledger and the previous verdict.
    expect(prompt).toContain('累计战绩：玩家胜 1 · 庄家胜 2 · 平 0 · 黑杰克 0')
    expect(prompt).toContain('跨局共享')
  })
})

describe('generateDealerBanter', () => {
  it('parses a JSON reply from the model', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ reply: '你这话说得和你的牌一样虚。' })))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const reply = await generateDealerBanter(ctx, config, banterInput(), { provider: 'mock', model: 'm' })
    expect(reply).toBe('你这话说得和你的牌一样虚。')
  })

  it('falls back without a route or with the LLM disabled', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ reply: 'unused' })))
    const input = banterInput()
    const noRoute = await generateDealerBanter(ctx, resolveBlackjackConfig(), input, undefined)
    expect(noRoute).toBe(fallbackBanter(input.persona, 'reply', input.round))
    const disabled = await generateDealerBanter(ctx, resolveBlackjackConfig({ dealerLlm: false }), input, { provider: 'mock', model: 'm' })
    expect(disabled).toBe(fallbackBanter(input.persona, 'reply', input.round))
  })

  it('falls back on terminal failure and on malformed output', async () => {
    const input = banterInput()
    const failed = await generateDealerBanter(stubCtx(failingStream()), resolveBlackjackConfig(), input, { provider: 'mock', model: 'm' })
    expect(failed).toBe(fallbackBanter(input.persona, 'reply', input.round))
    const malformed = await generateDealerBanter(stubCtx(textStream('无可奉告')), resolveBlackjackConfig(), input, { provider: 'mock', model: 'm' })
    expect(malformed).toBe(fallbackBanter(input.persona, 'reply', input.round))
  })

  it('frames the trigger, player line, and mood in the prompt', () => {
    const prompt = banterPrompt(banterInput({ trigger: 'player-bust', playerLine: '我不信' }))
    expect(prompt).toContain('player-bust')
    expect(prompt).toContain('我不信')
    expect(prompt).toContain('nervous')
    expect(prompt).toContain('雌小鬼')
    // The dealer's memory: the session ledger plus the previous verdict.
    expect(prompt).toContain('累计战绩：玩家胜 1 · 庄家胜 2 · 平 0 · 黑杰克 0')
    expect(prompt).toContain('（上一局：玩家赢）')
    expect(prompt).toContain('跨局共享')
  })
})

describe('banter helpers', () => {
  it('maps every settle result to its trigger', () => {
    expect(banterTriggerForResult('player-blackjack')).toBe('player-blackjack')
    expect(banterTriggerForResult('player-win')).toBe('player-win')
    expect(banterTriggerForResult('dealer-win')).toBe('dealer-win')
    expect(banterTriggerForResult('push')).toBe('push')
  })

  it('rolls the random taunt by chance', () => {
    expect(shouldRandomBanter(0)).toBe(false)
    expect(shouldRandomBanter(1)).toBe(true)
    const random = vi.spyOn(Math, 'random')
    random.mockReturnValue(0.9)
    expect(shouldRandomBanter(0.5)).toBe(false)
    random.mockReturnValue(0.1)
    expect(shouldRandomBanter(0.5)).toBe(true)
    random.mockRestore()
  })

  it('accepts pre-game banter input without a table', async () => {
    const ctx = stubCtx(textStream(JSON.stringify({ reply: '还没发牌就开始了？' })))
    const config = resolveBlackjackConfig({ dealerLlm: true })
    const input: DealerBanterInput = {
      round: 0, trigger: 'reply', emotion: 'calm', persona: '大肥鱼',
      record: { wins: 0, losses: 0, pushes: 0, blackjacks: 0 }, banter: [],
    }
    const reply = await generateDealerBanter(ctx, config, input, { provider: 'mock', model: 'm' })
    expect(reply).toBe('还没发牌就开始了？')
    const prompt = banterPrompt(input)
    expect(prompt).toContain('还没发牌')
  })

  it('renders the record line with and without the previous verdict', () => {
    expect(recordLine({ wins: 0, losses: 1, pushes: 0, blackjacks: 0 }, 'dealer-win'))
      .toContain('（上一局：庄家赢）')
    expect(recordLine({ wins: 3, losses: 0, pushes: 1, blackjacks: 2 }))
      .not.toContain('上一局')
    expect(recordLine({ wins: 3, losses: 0, pushes: 1, blackjacks: 2 }))
      .toContain('黑杰克 2')
  })
})
