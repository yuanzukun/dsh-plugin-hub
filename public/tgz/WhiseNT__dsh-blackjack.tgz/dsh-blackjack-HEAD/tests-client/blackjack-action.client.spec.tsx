// @vitest-environment jsdom
// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { makeTranslate } from '@deepseek-ai/dsh-client-test-runtime'
import type { SessionId, SessionListState } from '@deepseek-ai/dsh-client-runtime/client'
import { BlackjackAction, type BlackjackActionProps } from '../src/client/BlackjackAction.tsx'
import { zh } from '../src/client/locales.ts'

afterEach(() => {
  cleanup()
  vi.restoreAllMocks()
})

const SESSION = 'session' as SessionId
const t: BlackjackActionProps['t'] = makeTranslate(zh)

function props(
  state: SessionListState,
  over: Partial<BlackjackActionProps> = {},
): BlackjackActionProps {
  function useSessions<T>(select: (snapshot: SessionListState) => T): T {
    return select(state)
  }
  return { wide: true, useSessions, t, openDetails: vi.fn(), ...over } as unknown as BlackjackActionProps
}

function stateWithSession(): SessionListState {
  return {
    ids: [SESSION],
    byId: { [SESSION]: { id: SESSION, displayTitle: 's' } as never },
    current: SESSION,
    phase: 'ready',
    subagentsByParent: {},
    jobsBySession: {},
    currentAddress: undefined,
  }
}

describe('BlackjackAction entry', () => {
  it('renders disabled without a current session', () => {
    const state = { ...stateWithSession(), current: undefined }
    const { openDetails } = props(state) as BlackjackActionProps & { openDetails: ReturnType<typeof vi.fn> }
    render(<BlackjackAction {...props(state)} />)
    const trigger = screen.getByRole('button', { name: '21 点：DeepSeek 庄家' })
    expect(trigger).toHaveProperty('disabled', true)
    fireEvent.click(trigger)
    expect(openDetails).not.toHaveBeenCalled()
  })

  it('shows the wide label and is enabled with a current session', () => {
    render(<BlackjackAction {...props(stateWithSession())} />)
    const trigger = screen.getByRole('button', { name: '21 点：DeepSeek 庄家' })
    expect(trigger).toHaveProperty('disabled', false)
    expect(screen.getByText('21 点')).toBeDefined()
  })

  it('opens the details column on click', () => {
    const openDetails = vi.fn()
    render(<BlackjackAction {...props(stateWithSession(), { openDetails } as never)} />)
    fireEvent.click(screen.getByRole('button', { name: '21 点：DeepSeek 庄家' }))
    expect(openDetails).toHaveBeenCalledTimes(1)
  })

  it('renders the rail form without a label when narrow', () => {
    render(<BlackjackAction {...props(stateWithSession(), { wide: false } as never)} />)
    const trigger = screen.getByRole('button', { name: '21 点：DeepSeek 庄家' })
    expect(trigger).toBeDefined()
    expect(screen.queryByText('21 点')).toBeNull()
  })
})
