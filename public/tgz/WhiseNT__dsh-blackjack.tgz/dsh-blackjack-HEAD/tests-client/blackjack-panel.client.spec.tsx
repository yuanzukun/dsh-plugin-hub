// @vitest-environment jsdom
// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { makeTranslate } from '@deepseek-ai/dsh-client-test-runtime'
import { BlackjackPanel, type BlackjackChatLine } from '../src/client/BlackjackPanel.tsx'
import { zh } from '../src/client/locales.ts'
import type { BlackjackView } from '../src/client/remote.ts'

afterEach(() => {
  cleanup()
  vi.restoreAllMocks()
})

const t = makeTranslate(zh)

function view(over: Partial<BlackjackView> = {}): BlackjackView {
  return {
    round: 2,
    phase: 'idle',
    player: { cards: [], total: 0, blackjack: false, bust: false },
    dealer: { cards: [], total: 0, blackjack: false, bust: false },
    dealerHidden: true,
    emotion: 'calm',
    persona: '大肥鱼',
    banter: [],
    record: { wins: 0, losses: 0, blackjacks: 0, pushes: 0 },
    ...over,
  }
}

function renderPanel(over: {
  view?: BlackjackView | null
  busy?: boolean
  error?: string | null
  chat?: BlackjackChatLine[]
  thinking?: boolean
} = {}) {
  const onStart = vi.fn()
  const onHit = vi.fn()
  const onStand = vi.fn()
  const onBanter = vi.fn()
  const onPersona = vi.fn()
  const onDismiss = vi.fn()
  render(
    <BlackjackPanel
      view={over.view ?? null}
      busy={over.busy ?? false}
      error={over.error ?? null}
      chat={over.chat ?? []}
      thinking={over.thinking ?? false}
      t={t}
      onStart={onStart}
      onHit={onHit}
      onStand={onStand}
      onBanter={onBanter}
      onPersona={onPersona}
      onDismiss={onDismiss}
    />,
  )
  return { onStart, onHit, onStand, onBanter, onPersona, onDismiss }
}

describe('BlackjackPanel phases', () => {
  it('offers only 开始一局 while idle', () => {
    renderPanel({ view: view() })
    expect(screen.getByRole('button', { name: '开始一局' })).toBeDefined()
    expect(screen.queryByRole('button', { name: '要牌' })).toBeNull()
    expect(screen.queryByRole('button', { name: '停牌' })).toBeNull()
  })

  it('offers 要牌/停牌 during the player turn and hides the dealer total', () => {
    renderPanel({
      view: view({
        phase: 'player-turn',
        player: {
          cards: [{ rank: 'A', suit: '♠' }, { rank: '7', suit: '♥' }],
          total: 18, blackjack: false, bust: false,
        },
        dealer: {
          cards: [{ rank: 'K', suit: '♦' }, { rank: '5', suit: '♣' }],
          total: 15, blackjack: false, bust: false,
        },
        dealerHidden: true,
      }),
    })
    expect(screen.getByRole('button', { name: '要牌' })).toBeDefined()
    expect(screen.getByRole('button', { name: '停牌' })).toBeDefined()
    expect(screen.queryByRole('button', { name: '开始一局' })).toBeNull()
    // Only the dealer's first card is face-up; the second renders as a back,
    // and the hidden total never reaches the document.
    expect(screen.getAllByText('K').length).toBeGreaterThan(0)
    expect(screen.queryByText('15')).toBeNull()
    expect(screen.getByText('盖牌')).toBeDefined()
  })

  it('offers 开始一局 again once the round settles', () => {
    renderPanel({
      view: view({
        phase: 'settled',
        dealerHidden: false,
        dealer: { cards: [{ rank: 'K', suit: '♦' }, { rank: '5', suit: '♣' }], total: 15, blackjack: false, bust: false },
        player: { cards: [{ rank: '9', suit: '♠' }], total: 9, blackjack: false, bust: false },
        result: 'player-win',
      }),
    })
    expect(screen.getByRole('button', { name: '开始一局' })).toBeDefined()
    expect(screen.queryByRole('button', { name: '要牌' })).toBeNull()
    expect(screen.queryByRole('button', { name: '停牌' })).toBeNull()
  })

  it('reveals the dealer hand once settled and prints the result', () => {
    renderPanel({
      view: view({
        phase: 'settled',
        dealerHidden: false,
        dealer: { cards: [{ rank: 'K', suit: '♦' }, { rank: '5', suit: '♣' }], total: 15, blackjack: false, bust: false },
        player: { cards: [{ rank: '9', suit: '♠' }], total: 9, blackjack: false, bust: false },
        result: 'dealer-win',
      }),
    })
    expect(screen.getByText('你输了')).toBeDefined()
    expect(screen.getByText('点数 15')).toBeDefined()
    expect(screen.getByText('点数 9')).toBeDefined()
    // The settle celebrates through the burst wrapper around the verdict.
    expect(screen.getByText('你输了').parentElement?.className).toContain('resultBurst')
  })
})

describe('BlackjackPanel dealer theater', () => {
  it('labels the dealer mood', () => {
    renderPanel({ view: view({ emotion: 'smug' }) })
    expect(screen.getByText('心态：轻蔑')).toBeDefined()
  })

  it('labels the nervous and broken moods', () => {
    const { rerender } = render(
      <BlackjackPanel
        view={view({ emotion: 'nervous' })}
        busy={false}
        error={null}
        chat={[]}
        thinking={false}
        t={t}
        onStart={vi.fn()}
        onHit={vi.fn()}
        onStand={vi.fn()}
        onBanter={vi.fn()}
        onPersona={vi.fn()}
        onDismiss={vi.fn()}
      />,
    )
    expect(screen.getByText('心态：紧张')).toBeDefined()
    rerender(
      <BlackjackPanel
        view={view({ emotion: 'broken' })}
        busy={false}
        error={null}
        chat={[]}
        thinking={false}
        t={t}
        onStart={vi.fn()}
        onHit={vi.fn()}
        onStand={vi.fn()}
        onBanter={vi.fn()}
        onPersona={vi.fn()}
        onDismiss={vi.fn()}
      />,
    )
    expect(screen.getByText('心态：破防')).toBeDefined()
  })

  it('renders the dealer-turn phase word', () => {
    renderPanel({ view: view({ phase: 'dealer-turn' }) })
    expect(screen.getByText('庄家回合')).toBeDefined()
  })

  it('renders the persona picker with the active persona marked', () => {
    renderPanel({ view: view({ persona: '大肥鱼' }) })
    const fish = screen.getByRole('button', { name: /大肥鱼/ })
    const brat = screen.getByRole('button', { name: /雌小鬼/ })
    expect(fish.getAttribute('aria-pressed')).toBe('true')
    expect(brat.getAttribute('aria-pressed')).toBe('false')
  })

  it('switches the persona through the callback', () => {
    const { onPersona } = renderPanel({ view: view({ persona: '大肥鱼' }) })
    fireEvent.click(screen.getByRole('button', { name: /雌小鬼/ }))
    expect(onPersona).toHaveBeenCalledWith('雌小鬼')
  })

  it('marks a blackjack and a bust hand', () => {
    renderPanel({
      view: view({
        phase: 'player-turn',
        player: { cards: [{ rank: 'A', suit: '♠' }, { rank: 'K', suit: '♠' }], total: 21, blackjack: true, bust: false },
        dealer: { cards: [{ rank: '9', suit: '♦' }, { rank: '9', suit: '♦' }], total: 22, blackjack: false, bust: true },
        dealerHidden: false,
      }),
    })
    expect(screen.getAllByText('Blackjack').length).toBeGreaterThan(0)
    expect(screen.getByText('爆牌')).toBeDefined()
  })

  it('renders the banter exchange: player lines and model-styled dealer bubbles', () => {
    renderPanel({
      chat: [
        { id: 1, kind: 'player', content: '你发牌太慢了' },
        { id: 2, kind: 'dealer', content: '运气守恒，等着瞧。' },
      ],
    })
    // The chat feed is the single chatter surface: each line appears exactly
    // once (no separate dealer-zone bubble, which would read as a duplicate
    // reply), and every dealer line carries the model-styled class.
    const dealer = screen.getAllByText('运气守恒，等着瞧。')
    expect(dealer).toHaveLength(1)
    expect(dealer.some(node => node.className.includes('bubbleDealer'))).toBe(true)
    expect(screen.getByText('你发牌太慢了').className).toContain('bubblePlayer')
  })

  it('renders game status lines in the chatter feed', () => {
    renderPanel({
      chat: [
        { id: 1, kind: 'status', content: '—— 第 1 局 ——' },
        { id: 2, kind: 'status', content: '你抽到了 ♠7' },
        { id: 3, kind: 'status', content: '庄家抽到了 ♥K' },
      ],
    })
    const round = screen.getByText('—— 第 1 局 ——')
    expect(round.className).toContain('statusLine')
    expect(screen.getByText('你抽到了 ♠7')).toBeDefined()
    expect(screen.getByText('庄家抽到了 ♥K')).toBeDefined()
  })

  it('shows the diving placeholder while the dealer thinks', () => {
    renderPanel({ thinking: true })
    const placeholder = screen.getByText('深潜中')
    expect(placeholder.className).toContain('thinking')
    expect(placeholder.className).toContain('bubbleDealer')
  })

  it('renders the lifetime record', () => {
    renderPanel({
      view: view({ record: { wins: 1, losses: 2, blackjacks: 1, pushes: 0 } }),
    })
    const record = screen.getByLabelText('战绩')
    expect(record.textContent).toContain('胜 1')
    expect(record.textContent).toContain('负 2')
    expect(record.textContent).toContain('平 0')
    expect(record.textContent).toContain('BJ 1')
  })
})

describe('BlackjackPanel composer', () => {
  it('sends the draft and clears it', () => {
    const { onBanter } = renderPanel()
    const input = screen.getByRole('textbox', { name: '对庄家说垃圾话' }) as HTMLInputElement
    fireEvent.change(input, { target: { value: '快发牌' } })
    fireEvent.click(screen.getByRole('button', { name: '发射' }))
    expect(onBanter).toHaveBeenCalledWith('快发牌')
    expect(input.value).toBe('')
  })

  it('fires an emoji as its own instant message, not as input text', () => {
    const { onBanter } = renderPanel()
    const input = screen.getByRole('textbox', { name: '对庄家说垃圾话' }) as HTMLInputElement
    fireEvent.click(screen.getByRole('button', { name: '🍌' }))
    expect(onBanter).toHaveBeenCalledWith('🍌')
    expect(onBanter).toHaveBeenCalledTimes(1)
    // The emoji never pollutes the draft composer.
    expect(input.value).toBe('')
  })

  it('refuses emoji fire while busy', () => {
    const { onBanter } = renderPanel({ busy: true })
    fireEvent.click(screen.getByRole('button', { name: '🔥' }))
    expect(onBanter).not.toHaveBeenCalled()
  })

  it('keeps send disabled for a blank draft or while busy', () => {
    const { onBanter } = renderPanel({ busy: true })
    const input = screen.getByRole('textbox', { name: '对庄家说垃圾话' }) as HTMLInputElement
    const send = screen.getByRole('button', { name: '发射' })
    expect(send.hasAttribute('disabled')).toBe(true)
    fireEvent.change(input, { target: { value: 'hi' } })
    expect(send.hasAttribute('disabled')).toBe(true)
    expect(onBanter).not.toHaveBeenCalled()
  })

  it('refuses a blank or busy submission', () => {
    const { onBanter } = renderPanel()
    const form = screen.getByRole('textbox', { name: '对庄家说垃圾话' }).closest('form') as HTMLFormElement
    fireEvent.submit(form)
    expect(onBanter).not.toHaveBeenCalled()
  })

  it('refuses a busy submission even with a draft', () => {
    const { onBanter } = renderPanel({ busy: true })
    const input = screen.getByRole('textbox', { name: '对庄家说垃圾话' }) as HTMLInputElement
    const form = input.closest('form') as HTMLFormElement
    fireEvent.change(input, { target: { value: 'hi' } })
    fireEvent.submit(form)
    expect(onBanter).not.toHaveBeenCalled()
  })
})

describe('BlackjackPanel busy and errors', () => {
  it('disables the action row while a verb is in flight', () => {
    renderPanel({ view: view({ phase: 'player-turn' }), busy: true })
    expect(screen.getByRole('button', { name: '要牌' }).hasAttribute('disabled')).toBe(true)
    expect(screen.getByRole('button', { name: '停牌' }).hasAttribute('disabled')).toBe(true)
  })

  it('renders the inline error message', () => {
    renderPanel({ error: 'table flipped' })
    expect(screen.getByText('请求失败：table flipped')).toBeDefined()
  })
})
