// @vitest-environment jsdom
// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { makeTranslate } from '@deepseek-ai/dsh-client-test-runtime'
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import { BlackjackDetails, type BlackjackDetailsProps } from '../src/client/BlackjackDetails.tsx'
import { zh } from '../src/client/locales.ts'
import type { BlackjackRemote, BlackjackView } from '../src/client/remote.ts'

afterEach(() => {
  cleanup()
  vi.restoreAllMocks()
})

const SESSION = 'session' as SessionId
const t: BlackjackDetailsProps['t'] = makeTranslate(zh)

/** A minimal but structurally valid game view. */
function view(over: Partial<BlackjackView> = {}): BlackjackView {
  return {
    round: 1,
    phase: 'idle',
    player: { cards: [], total: 0, blackjack: false, bust: false },
    dealer: { cards: [], total: 0, blackjack: false, bust: false },
    dealerHidden: true,
    emotion: 'calm',
    persona: '大肥鱼',
    banter: [],
    record: { wins: 0, losses: 0, blackjacks: 0, pushes: 0 },
    ...over,
  }
}

const ok = (value: BlackjackView): { ok: true; value: BlackjackView } => ({ ok: true, value })
const fail = (message: string): { ok: false; error: { code: string; message: string; details: Record<string, unknown> } } => ({
  ok: false,
  error: { code: 'remote-error', message, details: {} },
})

/** Mocked `blackjack` namespace; each verb records its own calls. */
function remoteMock(overrides: Partial<BlackjackRemote> = {}): BlackjackRemote {
  return {
    view: vi.fn(async () => ok(view())),
    start: vi.fn(async () => ok(view({ phase: 'player-turn', round: 1 }))),
    hit: vi.fn(async () => ok(view({ phase: 'player-turn', round: 1 }))),
    stand: vi.fn(async () => ok(view({ phase: 'dealer-turn', dealerHidden: false }))),
    dealer: vi.fn(async () => ok(view({
      phase: 'settled',
      dealerHidden: false,
      result: 'player-win',
      dealer: {
        cards: [{ rank: 'K', suit: '♦' }, { rank: '6', suit: '♣' }, { rank: 'J', suit: '♥' }],
        total: 26, blackjack: false, bust: true,
      },
      player: {
        cards: [{ rank: '9', suit: '♠' }, { rank: '8', suit: '♦' }],
        total: 17, blackjack: false, bust: false,
      },
      record: { wins: 1, losses: 0, blackjacks: 0, pushes: 0 },
    }))),
    banter: vi.fn(async () => ({ ok: true, value: { reply: '哼，就这？' } })),
    persona: vi.fn(async () => ok(view({ phase: 'player-turn', round: 1, persona: '雌小鬼' }))),
    ...overrides,
  } as unknown as BlackjackRemote
}

function props(
  remote: BlackjackRemote,
  over: Partial<BlackjackDetailsProps> = {},
): BlackjackDetailsProps {
  return {
    sessionId: SESSION,
    t,
    remote,
    closeDetails: vi.fn(),
    ...over,
  } as unknown as BlackjackDetailsProps
}

describe('BlackjackDetails table', () => {
  it('offers only 开始一局 while idle', () => {
    render(<BlackjackDetails {...props(remoteMock())} />)
    expect(screen.getByRole('button', { name: '开始一局' })).toBeDefined()
    expect(screen.queryByRole('button', { name: '要牌' })).toBeNull()
    expect(screen.queryByRole('button', { name: '停牌' })).toBeNull()
  })

  it('deals on 开始一局 and enters the player turn', async () => {
    const remote = remoteMock()
    render(<BlackjackDetails {...props(remote)} />)
    fireEvent.click(screen.getByRole('button', { name: '开始一局' }))
    await waitFor(() => { expect(remote.start).toHaveBeenCalledWith(SESSION, {}) })
    await waitFor(() => { expect(screen.getByRole('button', { name: '要牌' })).toBeDefined() })
    // The chat records the round itself.
    await waitFor(() => { expect(screen.getByText('—— 第 1 局 ——')).toBeDefined() })
  })

  it('hits and stands through the Remote namespace, then drives the dealer steps', async () => {
    const remote = remoteMock()
    render(<BlackjackDetails {...props(remote)} />)
    fireEvent.click(screen.getByRole('button', { name: '开始一局' }))
    await waitFor(() => { expect(screen.getByRole('button', { name: '要牌' })).toBeDefined() })
    fireEvent.click(screen.getByRole('button', { name: '要牌' }))
    await waitFor(() => { expect(remote.hit).toHaveBeenCalledWith(SESSION) })
    fireEvent.click(screen.getByRole('button', { name: '停牌' }))
    await waitFor(() => { expect(remote.stand).toHaveBeenCalledWith(SESSION) })
    // The dealer turn is driven one visible step at a time until it settles.
    await waitFor(() => { expect(remote.dealer).toHaveBeenCalledWith(SESSION) })
    await waitFor(() => { expect(screen.getByText('本局结束 · 你赢了')).toBeDefined() })
  })

  it('shows the diving placeholder while the dealer reply is pending', async () => {
    let release: ((value: { ok: true; value: { reply: string } }) => void) | undefined
    const remote = remoteMock({
      banter: vi.fn(() => new Promise<{ ok: true; value: { reply: string } }>((resolve) => {
        release = resolve
      })),
    })
    render(<BlackjackDetails {...props(remote)} />)
    const input = screen.getByRole('textbox', { name: '对庄家说垃圾话' })
    fireEvent.change(input, { target: { value: '接招' } })
    fireEvent.click(screen.getByRole('button', { name: '发射' }))
    // The player line lands instantly and the placeholder takes the dealer's seat.
    await waitFor(() => { expect(screen.getByText('接招')).toBeDefined() })
    expect(screen.getByText('深潜中')).toBeDefined()
    release?.({ ok: true, value: { reply: '杂鱼！' } })
    await waitFor(() => { expect(screen.getByText('杂鱼！')).toBeDefined() })
    expect(screen.queryByText('深潜中')).toBeNull()
  })

  it('records the dealer draws as status lines', async () => {
    const remote = remoteMock()
    render(<BlackjackDetails {...props(remote)} />)
    fireEvent.click(screen.getByRole('button', { name: '开始一局' }))
    await waitFor(() => { expect(screen.getByRole('button', { name: '要牌' })).toBeDefined() })
    fireEvent.click(screen.getByRole('button', { name: '停牌' }))
    await waitFor(() => { expect(remote.dealer).toHaveBeenCalledWith(SESSION) })
    await waitFor(() => { expect(screen.getByText('你停牌了 · 0 点')).toBeDefined() })
    await waitFor(() => { expect(screen.getByText('庄家抽到了 ♥J')).toBeDefined() })
    await waitFor(() => { expect(screen.getByText('庄家爆牌！')).toBeDefined() })
  })

  it('switches the dealer persona through the Remote namespace', async () => {
    const remote = remoteMock()
    render(<BlackjackDetails {...props(remote)} />)
    fireEvent.click(screen.getByRole('button', { name: /雌小鬼/ }))
    await waitFor(() => { expect(remote.persona).toHaveBeenCalledWith(SESSION, { persona: '雌小鬼' }) })
  })

  it('renders a remote failure as an inline message', async () => {
    const remote = remoteMock({ start: vi.fn(async () => fail('table on fire')) })
    render(<BlackjackDetails {...props(remote)} />)
    fireEvent.click(screen.getByRole('button', { name: '开始一局' }))
    await waitFor(() => { expect(screen.getByText('请求失败：table on fire')).toBeDefined() })
  })

  it('sends banter and surfaces the dealer reply as a bubble', async () => {
    const remote = remoteMock()
    render(<BlackjackDetails {...props(remote)} />)
    fireEvent.click(screen.getByRole('button', { name: '开始一局' }))
    await waitFor(() => { expect(screen.getByRole('button', { name: '要牌' })).toBeDefined() })
    const input = screen.getByRole('textbox', { name: '对庄家说垃圾话' })
    fireEvent.change(input, { target: { value: '接招' } })
    fireEvent.click(screen.getByRole('button', { name: '发射' }))
    await waitFor(() => { expect(remote.banter).toHaveBeenCalledWith(SESSION, { content: '接招' }) })
    // The local projection mirrors both sides of the exchange immediately —
    // the player line and the dealer reply — each shown exactly once.
    await waitFor(() => { expect(screen.getByText('接招')).toBeDefined() })
    expect(screen.getAllByText('哼，就这？').length).toBe(1)
  })

  it('renders a failing banter as an inline message', async () => {
    const remote = remoteMock({ banter: vi.fn(async () => fail('dealer is speechless')) })
    render(<BlackjackDetails {...props(remote)} />)
    fireEvent.click(screen.getByRole('button', { name: '开始一局' }))
    await waitFor(() => { expect(screen.getByRole('button', { name: '要牌' })).toBeDefined() })
    const input = screen.getByRole('textbox', { name: '对庄家说垃圾话' })
    fireEvent.change(input, { target: { value: '说话啊' } })
    fireEvent.click(screen.getByRole('button', { name: '发射' }))
    await waitFor(() => { expect(screen.getByText('请求失败：dealer is speechless')).toBeDefined() })
  })

  it('closes the details column through the injected callback', () => {
    const closeDetails = vi.fn()
    render(<BlackjackDetails {...props(remoteMock(), { closeDetails } as never)} />)
    fireEvent.click(screen.getByRole('button', { name: 'Close' }))
    expect(closeDetails).toHaveBeenCalledTimes(1)
  })

  it('clears the table when the session changes', () => {
    const { rerender } = render(<BlackjackDetails {...props(remoteMock())} />)
    fireEvent.click(screen.getByRole('button', { name: '开始一局' }))
    rerender(<BlackjackDetails {...props(remoteMock(), { sessionId: 'other' as SessionId } as never)} />)
    expect(screen.getByRole('button', { name: '开始一局' })).toBeDefined()
  })
})
