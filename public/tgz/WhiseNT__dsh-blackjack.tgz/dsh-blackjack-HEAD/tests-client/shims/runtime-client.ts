/**
 * Test shim for `@deepseek-ai/dsh-client-runtime/client`.
 *
 * The published client half is a CJS closure-factory bundle: its named exports
 * are only reachable through `window.__ModuleLoader__` (the bundle's own
 * `module.exports` stays empty, so neither Node nor vite can statically resolve
 * the names). Tests alias the specifier to this shim: import the real bundle
 * for its registration side effect, then re-export the loader-composed exports
 * as named bindings. Runtime values are the real classes/functions.
 */
import '../../node_modules/@deepseek-ai/dsh-client-runtime/lib/client.js'

declare global {
  interface Window {
    __ModuleLoader__: { getExports(id: string): Record<string, unknown> }
  }
}

const runtime = window.__ModuleLoader__.getExports('@deepseek-ai/dsh-client-runtime')

export const ConversationEventRegistry: any = runtime.ConversationEventRegistry
export const ConversationLocationIndex: any = runtime.ConversationLocationIndex
export const ConversationNodeAssembler: any = runtime.ConversationNodeAssembler
export const ConversationViewRegistry: any = runtime.ConversationViewRegistry
export const DirectoryBrowseError: any = runtime.DirectoryBrowseError
export const EMPTY_CHAT_SNAPSHOT: any = runtime.EMPTY_CHAT_SNAPSHOT
export const EMPTY_CONVERSATION_VIEWS: any = runtime.EMPTY_CONVERSATION_VIEWS
export const PendingWait: any = runtime.PendingWait
export const SessionCreateError: any = runtime.SessionCreateError
export const SessionProvideChannel: any = runtime.SessionProvideChannel
export const SessionRuntime: any = runtime.SessionRuntime
export const SlotRegistry: any = runtime.SlotRegistry
export const WorkspaceCreateError: any = runtime.WorkspaceCreateError
export const WorkspaceRuntime: any = runtime.WorkspaceRuntime
export const apply: any = runtime.apply
export const contextForm: any = runtime.contextForm
export const contextProvenance: any = runtime.contextProvenance
export const conversationContextKey: any = runtime.conversationContextKey
export const createScope: any = runtime.createScope
export const createSnapshotStore: any = runtime.createSnapshotStore
export const defineStore: any = runtime.defineStore
export const displayFailureMessage: any = runtime.displayFailureMessage
export const emptyAssistantBlock: any = runtime.emptyAssistantBlock
export const indexSubagentDescendants: any = runtime.indexSubagentDescendants
export const inject: any = runtime.inject
export const isAppendSurfaceEvent: any = runtime.isAppendSurfaceEvent
export const isReplacementSurfaceEvent: any = runtime.isReplacementSurfaceEvent
export const isTokenDelta: any = runtime.isTokenDelta
export const resolveWorkspacePath: any = runtime.resolveWorkspacePath
export const scopeOf: any = runtime.scopeOf
export const shallowEqual: any = runtime.shallowEqual
export const toAssistantBlock: any = runtime.toAssistantBlock
export const toAssistantBlocks: any = runtime.toAssistantBlocks
export const workspaceTitleOf: any = runtime.workspaceTitleOf

export default runtime
