/**
 * ui-blackjack plugin halves: the browser entry's dictionary and footer-slot
 * registrations against the real SlotRegistry (with fiber teardown proving
 * removal — HMR safety), the inert node entry, and the invariant companion's
 * ownership reservation.
 */
// @vitest-environment jsdom
import { Context, Service } from '@deepseek-ai/cordis'
import { describe, expect, it } from 'vitest'
import InvariantRegistry from '@deepseek-ai/dsh-invariants'
import { stubSettingsScope } from '@deepseek-ai/dsh-client-test-runtime'
// The @deepseek-ai client packages ship CJS closure-factory bundles whose
// exports are only reachable through the __ModuleLoader__ registration (the
// bundle's own module.exports stays empty). Import for side effect to fire the
// registration, then read the composed exports via the loader test helper.
import type {} from '@deepseek-ai/dsh-client-runtime/client'
import '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import '@deepseek-ai/dsh-client-locale/client'
import { apply, inject } from '../src/client/index.ts'
import { apply as applyNode } from '../src/client/plugin-index.ts'
import * as BlackjackInvariant from '../src/client/invariant.ts'
import { en, NS, zh } from '../src/client/locales.ts'

/** Loader test helper: composed exports of an already-registered client bundle. */
function loaderExports(id: string): Record<string, unknown> {
  return (window as unknown as { __ModuleLoader__: { getExports(id: string): Record<string, unknown> } })
    .__ModuleLoader__.getExports(id)
}

const { SlotRegistry } = loaderExports('@deepseek-ai/dsh-client-runtime') as {
  SlotRegistry: typeof import('@deepseek-ai/dsh-client-runtime/client').SlotRegistry
}
const { apply: applyLocale, inject: localeInject } = loaderExports('@deepseek-ai/dsh-client-locale') as {
  apply: typeof import('@deepseek-ai/dsh-client-locale/client').apply
  inject: typeof import('@deepseek-ai/dsh-client-locale/client').inject
}

/** Slot ledger reader: entry ids currently registered in the footer list. */
function footerEntryIds(ctx: Context): (string | undefined)[] {
  return ctx.slots
    .entries('sidebar.footer.action')
    .map(entry => entry.options.id)
}

/** Slot ledger reader: dictionary namespaces currently occupying the details column. */
function detailsOccupantNamespaces(ctx: Context): (string | undefined)[] {
  return ctx.slots.entries('details').map(entry => entry.locale)
}

/** A real cordis service face for `remote`, so dotted namespace provides resolve. */
class RemoteService extends Service {
  constructor(serviceCtx: Context) {
    super(serviceCtx, 'remote')
  }

  /** The plugin mounts its own contribution through this face; no-op under test. */
  async $mount(): Promise<() => void> {
    return () => {}
  }
}

/** A layout-service stub: open/close/resize the details column. */
class LayoutService extends Service {
  constructor(serviceCtx: Context) {
    super(serviceCtx, 'layout')
  }

  openDetails(): void {}
  closeDetails(): void {}
  setDetailsWidth(): void {}
}

/** Boot the browser half over a real slot tree that declares the footer list. */
async function bench(): Promise<{ ctx: Context; fiber: ReturnType<Context['plugin']> }> {
  const ctx = new Context()
  await ctx.plugin(SlotRegistry).await()
  ctx.slots.register({
    name: 'root',
    children: {
      'sidebar.footer.action': { kind: 'list', scope: 'root' },
      'details': { kind: 'single', scope: 'session' },
    },
  } as never, () => null)
  ctx.provide('sessions', {})
  // The locale plugin binds a settings scope, which reads the connection handle
  // and the forwarded-event port.
  ctx.provide('connection', { api: { settings: {} }, isLoopback: false } as never)
  new RemoteService(ctx)
  new LayoutService(ctx)
  // The blackjack namespace service the plugin's fiber inject waits on; the
  // Host contribution mounts it once @deepseek-ai/dsh-blackjack is assembled.
  ctx.provide('remote.blackjack', {} as never)
  ctx.provide('settingsScope', { bind: () => stubSettingsScope().scope } as never)
  await ctx.plugin({ inject: localeInject, apply: applyLocale }).await()
  const fiber = ctx.plugin({ inject: [...inject], apply })
  await fiber.await()
  return { ctx, fiber }
}

describe('ui-blackjack browser half', () => {
  it('declares the services it binds', () => {
    expect(inject).toEqual(['slots', 'locale', 'sessions', 'remote', 'layout'])
  })

  it('registers the footer action and the details occupant, and fiber teardown removes both (HMR safety)', async () => {
    const { ctx, fiber } = await bench()
    expect(footerEntryIds(ctx)).toContain('blackjack')
    expect(detailsOccupantNamespaces(ctx)).toContain('blackjack')
    await fiber.dispose()
    expect(footerEntryIds(ctx)).not.toContain('blackjack')
    expect(detailsOccupantNamespaces(ctx)).not.toContain('blackjack')
  })

  it('injects the blackjack Remote namespace into the registered entry', async () => {
    const ctx = new Context()
    await ctx.plugin(SlotRegistry).await()
    ctx.slots.register({
      name: 'root',
      children: {
        'sidebar.footer.action': { kind: 'list', scope: 'root' },
        'details': { kind: 'single', scope: 'session' },
      },
    } as never, () => null)
    ctx.provide('sessions', {})
    ctx.provide('connection', { api: { settings: {} }, isLoopback: false } as never)
    new RemoteService(ctx)
    new LayoutService(ctx)
    const blackjackRemote = {}
    ctx.provide('remote.blackjack', blackjackRemote)
    ctx.provide('settingsScope', { bind: () => stubSettingsScope().scope } as never)
    await ctx.plugin({ inject: localeInject, apply: applyLocale }).await()
    const fiber = ctx.plugin({ inject: [...inject], apply })
    await fiber.await()

    // The slot's inject factory hands the Remote namespace and the layout
    // close callback to the details occupant the moment the column renders.
    // Single slots carry no list-style ids; the occupant's dictionary
    // namespace identifies it in the ledger.
    const entry = ctx.slots.entries('details').find(e => e.locale === 'blackjack')
    const injected = entry?.inject?.() as { remote: unknown; closeDetails: unknown } | undefined
    expect(injected?.remote).toBe(blackjackRemote)
    expect(typeof injected?.closeDetails).toBe('function')
    await fiber.dispose()
  })

  it('registers both dictionaries under its own namespace and releases them with the fiber', async () => {
    const { ctx, fiber } = await bench()
    const translate = ctx.locale.bind(NS)
    // The stub settings scope defaults to 'en'; the dictionaries land under
    // whatever locale is active, so pin zh first to assert the Chinese side.
    ctx.locale.setLocale('zh')
    expect(translate('button.start')).toBe(zh['button.start'])
    ctx.locale.setLocale('en')
    expect(translate('button.start')).toBe(en['button.start'])

    // Withdrawn dictionaries leave the key unresolved rather than translated.
    await fiber.dispose()
    expect(translate('button.start')).not.toBe(en['button.start'])
  })

  it('keeps the English dictionary key-identical to the Chinese source of truth', () => {
    expect(Object.keys(en).sort()).toEqual(Object.keys(zh).sort())
  })
})

describe('ui-blackjack node half', () => {
  it('contributes no host behavior', () => {
    // The node half exists only so the plugin appears in the Loader tree.
    expect(applyNode).not.toThrow()
  })
})

describe('ui-blackjack invariant companion', () => {
  it('reserves package ownership under its declared companion name', async () => {
    const ctx = new Context()
    await ctx.plugin(InvariantRegistry, { enabled: true })
    const fiber = ctx.plugin(BlackjackInvariant)
    await fiber.await()
    expect(BlackjackInvariant.name).toBe('client-ui-blackjack-invariant')
    expect(BlackjackInvariant.inject).toEqual(['invariants'])
    // Emitting an unrelated event proves the companion installed no audit.
    expect(() => { (ctx.emit as (event: string) => void)('slots/changed') }).not.toThrow()
    await fiber.dispose()
  })
})
