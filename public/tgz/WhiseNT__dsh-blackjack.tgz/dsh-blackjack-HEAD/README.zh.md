# dsh-blackjack

给 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的一个**侧边栏 21 点（Blackjack）**插件：DeepSeek 模型扮演庄家，发牌、决定、垃圾话，支持两种人格；每一局全程**事件溯源**进会话日志，可精确重放。一个包同时提供 **host 游戏服务**与**浏览器侧边栏 UI**（双半区），`dsh plugin add` 一次装齐。

<!-- markdownlint-disable MD033 -->
[English](README.md) · 中文
<!-- markdownlint-enable MD033 -->

> **安装状态**
> - ✅ **GitHub 安装完整可用**（实测 `dsh web`）：一个包 = host 服务 + 浏览器 UI。插件同时声明 `dsh.bundle`（host 插件行）与 `dsh.client`（Web 前端入口），安装后 host 层挂载，客户端模块系统自动把 UI 编进前端引导图。
> - 依赖全部为 **npm 已发布的 `@deepseek-ai/*` 包**（`0.1.0-rc.6`），无需旁置 monorepo，也无需等待任何未发布的内部包。

## 功能

**Host 侧**

- **两种庄家人格**（每会话可选，经 `blackjack/persona` 事件持久化）：
  - 🐟 **大肥鱼** —— 贪吃慵懒的深海肥鱼（"咕噜咕噜"）。
  - 😼 **雌小鬼** —— 嚣张嘴硬、叫你"杂鱼"。
- **模型决定要牌/停牌**：每一步通过一次辅助 LLM 调用，逐张可见。
- **跨局记忆**：庄家提示词携带累计战绩与共享聊天历史。
- **事件溯源**：`blackjack/game-start|hit|stand|dealer-hit|settle|banter|emotion|persona` 为持久会话事件，fold 严格重放。
- **优雅降级**：LLM 缺失或失败时，fallback 到人格化的预设台词，牌局不卡死。

**浏览器 UI**

- 侧边栏底部 🃏 入口，点击在右侧详情列打开 21 点牌桌。
- 牌桌、情绪徽章、累计战绩、聊天流（庄家垃圾话 + 逐张翻转的发牌动画）、表情快捷条。
- 通过自挂载的 `blackjack` Remote 命名空间调用 host，UI 自身不持有游戏状态。

## UI 截图

下面的截图来自已验证的 `dsh web` 会话。具体牌面、庄家台词和累计战绩会随会话日志变化，但可以完整看到浏览器半区：侧边栏入口、牌桌、聊天流和操作栏。

![侧边栏入口](docs/screenshots/01-sidebar-entry.png)

![21 点牌桌](docs/screenshots/02-table-settled.png)

![庄家聊天与会话状态](docs/screenshots/03-table-dealt.png)

![玩家操作与表情快捷条](docs/screenshots/04-table-action.png)

## 安装（完整：host + UI）

本插件是 dsh **双半区 bundle**（`dsh.bundle` → `cordis.patch.yml` + `dsh.client` → `lib/client.js`）：

```sh
dsh plugin --profile <name> add github:<owner>/dsh-blackjack
```

git 安装抓的是**源码**，第一次 `add` 需要允许一次自包含的 `prepare` 构建 —— 把 pnpm 打印的包键复制进 profile 的 `pnpm-workspace.yaml` 的 `allowBuilds`（见[官方发布指南](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md)），再重新 `add`。只允许你信任的源码。

校验并启动：

```sh
dsh --profile <name> --dump-config   # 应显示 "# == dsh-blackjack" 层
dsh --profile <name>                 # Web 面：dsh web / dsh --profile <name> web
```

重启 `dsh web` 后侧边栏底部出现 🃏 入口即为 UI 生效：host 层在 `--dump-config` 可见；客户端模块系统会自动扫描 `dsh.client` 声明，把 UI 编进前端引导图（`__DSH_BOOT__`），无需额外配置。

配置（可在你的 profile `cordis.patch.yml` 覆盖）：

```yaml
- id: blackjack
  config:
    dealerPersona: 雌小鬼     # 初始人格；会话内可持续切换
    randomBanterChance: 0.3   # 每次要牌后不请自来的嘲讽概率
```

## 玩法

标准 21 点，单副确定性 52 张牌（种子存于 `game-start` 事件）：A 记 11/1，花牌 10，要牌/停牌，庄家补到 ≥17。爆牌直接输，同分平局。

## 仓库结构

```
dsh-blackjack/
├── cordis.patch.yml            # bundle patch：挂载 `blackjack` host 行
├── src/
│   ├── game/                   # 纯规则引擎（零依赖），内联进 bundle
│   ├── service/                # host 插件：@Remote 动词、fold、LLM 庄家、banter
│   ├── client/                 # 浏览器半区：React 21 点面板（BlackjackPanel 等）
│   ├── css-modules.d.ts        # CSS Modules 类型声明
│   └── typert.remote-client.ts # `blackjack` Remote 类型 + 运行时贡献（client 自挂载）
├── tests/                      # host 单元测试（92）
├── tests-client/               # 浏览器半区测试（44，jsdom + __ModuleLoader__ stub）
├── tsdown.config.ts            # host 构建：tsc（原生 decorators）→ 打包 → 类型
├── tsdown.client.config.ts     # 浏览器半区构建：closure-factory client bundle
├── tsdown.client.ts            # 官方 client 构建预设（取自 dsh 基座，CSS Modules 内联）
├── web-platform.ts             # 平台模块表（shell 共享的模块清单）
└── package.json                # dsh.bundle + dsh.client 双半区声明 + 自包含 prepare 构建
```

开发：`pnpm install`、`pnpm run build`、`pnpm test`（136 个测试：92 host + 44 UI）。所有 `@deepseek-ai/*` 依赖均为**已发布版本**，无需旁置 monorepo。

## License

[MIT](LICENSE)

给仓库打上 [`dsh-plugin`](https://github.com/topics/dsh-plugin) topic，方便 dsh 用户发现。
