import { defineConfig } from 'tsdown'

export default defineConfig({
  // Bundle the tsc-emitted JS (which carries the runnable decorator helpers);
  // tsdown just bundles + externalizes runtime deps. The client bundle
  // (lib/client.js) is emitted separately by tsdown.client.config.ts.
  entry: {
    index: 'build-ts/service/index.js',
    types: 'build-ts/service/types.js',
    remote: 'build-ts/typert.remote-client.js',
  },
  format: ['esm'],
  outDir: 'lib',
  dts: false,
  clean: true,
  fixedExtension: false,
  deps: {
    neverBundle: [/@deepseek-ai\//, /^zod$/],
  },
})
