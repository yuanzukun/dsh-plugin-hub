import { resolve } from 'node:path'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  resolve: {
    alias: {
      // The published client half is a CJS closure-factory bundle; alias the
      // specifier to a shim that re-exports the loader-composed exports.
      '@deepseek-ai/dsh-client-runtime/client': resolve(
        import.meta.dirname,
        'tests-client/shims/runtime-client.ts',
      ),
    },
  },
  test: {
    environment: 'node',
    setupFiles: ['vitest.setup.ts'],
    include: ['tests/**/*.spec.ts', 'tests-client/**/*.spec.tsx'],
    server: {
      deps: {
        // The @deepseek-ai SDK client packages ship CJS closure-factory
        // bundles; let vite transpile them so named exports (SlotRegistry,
        // applyLocale, ...) resolve and CSS imports are neutralized.
        inline: [/@deepseek-ai\//],
      },
    },
  },
})
