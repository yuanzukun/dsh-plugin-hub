/**
 * Whale pet persistence: a small JSON file under the dsh home, atomically
 * published (temp + rename). Owned by this plugin; no other surface writes
 * it.
 */

import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { DEFAULT_CONFIG, type WhaleConfig } from './protocol.ts'

/** Where the pet config lives under the dsh home. */
function whalePath(): string {
  return join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'dsh-ventus-whale', 'config.json')
}

/** Load the persisted config, falling back to defaults on any problem. */
export function loadConfig(): WhaleConfig {
  const path = whalePath()
  if (!existsSync(path)) return { ...DEFAULT_CONFIG }
  try {
    const parsed = JSON.parse(readFileSync(path, 'utf8')) as Partial<WhaleConfig>
    return {
      enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : DEFAULT_CONFIG.enabled,
      flipOnSend: typeof parsed.flipOnSend === 'boolean' ? parsed.flipOnSend : DEFAULT_CONFIG.flipOnSend,
      scale: clampNumber(parsed.scale, 0.2, 3, DEFAULT_CONFIG.scale),
      sensitivity: clampNumber(parsed.sensitivity, 0.2, 5, DEFAULT_CONFIG.sensitivity),
      caption: typeof parsed.caption === 'string' ? parsed.caption.slice(0, 80) : DEFAULT_CONFIG.caption,
      // t8: 停靠位置已移除；t10: bottom 随左下角定位一并移除，旧配置字段被忽略。
      x: parsed.x === null || parsed.x === undefined ? undefined : clampNumber(parsed.x, 0, 10000, 0),
      y: parsed.y === null || parsed.y === undefined ? undefined : clampNumber(parsed.y, 0, 10000, 0),
    }
  } catch {
    return { ...DEFAULT_CONFIG }
  }
}

/** Clamp a numeric field to its schema bounds with a fallback. */
function clampNumber(value: unknown, min: number, max: number, fallback: number): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback
  return Math.max(min, Math.min(max, value))
}

/** Persist the config atomically. */
export function saveConfig(config: WhaleConfig): void {
  const dir = join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'dsh-ventus-whale')
  mkdirSync(dir, { recursive: true })
  const payload = JSON.stringify(config, null, 2)
  const temp = whalePath() + '.tmp'
  // t13: 写盘后 fsync 再原子发布（崩溃安全：先落盘再 rename，避免半写文件）。
  const fd = openSync(temp, 'w')
  try {
    writeFileSync(fd, payload)
    fsyncSync(fd)
  } finally {
    closeSync(fd)
  }
  renameSync(temp, whalePath())
}
