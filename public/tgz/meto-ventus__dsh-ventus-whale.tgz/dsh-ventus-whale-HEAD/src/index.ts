/**
 * dsh-ventus-whale — host half. Mounts the /api/ventus-whale route family and
 * a settings section (namespace `ventus-whale`) so the web settings surface
 * can edit the pet's scale, sensitivity, caption, and placement. The browser
 * half (./client) renders the interactive 3D whale.
 */

import type { Context } from '@deepseek-ai/cordis'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import z from 'schemastery'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { makeWhaleRoutes } from './routes.ts'
import { loadConfig, saveConfig } from './host.ts'
import { DEFAULT_CONFIG, type WhaleConfig } from './protocol.ts'

/** Stable cordis plugin name (matches cordis.patch.yml insert id). */
export const name = 'ventus-whale'

/** Services required before the routes can mount. */
export const inject = ['webServer']

/** Settings namespace the web settings surface edits. */
export const WHALE_SETTINGS_NAMESPACE = 'ventus-whale'

/** Settings section schema: the fields the settings surface edits. */
export const WHALE_SETTINGS_SCHEMA = z.object({
  // 默认 true 与 Config/持久化文件一致：settings 初始 resolved 若用 schema
  // 默认 false 会误杀路由挂载（鲸鱼消失）。
  enabled: z.boolean().default(true),
  flipOnSend: z.boolean().default(true),
  scale: z.number().step(0.05).min(0.2).max(3).default(1),
  sensitivity: z.number().step(0.05).min(0.2).max(5).default(1),
  caption: z.string().max(80).default(''),
  // t8: 停靠位置已移除；t10: 底部偏移（bottom）随左下角定位一并移除，
  // 默认召唤位置改为视口右侧中部。
})

/** Plugin config (subset of the settings section). */
export interface WhalePluginConfig {
  /** Master switch. */
  enabled?: boolean
}

export const Config: z<WhalePluginConfig> = z.object({
  // 默认 true：无显式配置时跟随持久化文件（loadConfig），
  // 否则 schema 默认 false 会使 ?? 兜底失效，路由永不挂载。
  enabled: z.boolean().default(true),
})

/** Register the whale host surfaces. */
export function apply(ctx: Context, config: WhalePluginConfig = {}): void {
  // The settings surface edits the pet config; the composition base starts
  // from the persisted file so an empty user layer resolves to exactly what
  // the pet already shows. Declared before `current` so installSettingsSection
  // (which may invoke onChange synchronously) never reads a TDZ binding.
  const base: WhaleConfig = {
    ...loadConfig(),
    enabled: config.enabled ?? loadConfig().enabled,
  }
  let current: () => WhaleConfig = () => base
  // installSettingsSection 注册时会同步触发一次 onChange（此时 settings 的
  // resolved 落在 schema 默认值上，不是文件真实值）——这次必须跳过保存，
  // 否则每次启动都会把 config.json 重置成默认（enabled=false、x/y 丢失）。
  let settingsReady = false

  // 路由始终挂载：即使鲸鱼处于停用状态，侧边栏召唤/设置卡仍需
  // /api/ventus-whale/state|update|reset 来读取和启用。enabled 只控制
  // 客户端是否显示鲸鱼，不控制 API 是否存在。
  ctx.effect(
    () => {
      const disposers = makeWhaleRoutes().map(route => ctx.webServer.register(route))
      return () => { for (const dispose of disposers) dispose() }
    },
    'ventus-whale: routes',
  )

  try {
    installSettingsSection(ctx, settingsNamespace(WHALE_SETTINGS_NAMESPACE), WHALE_SETTINGS_SCHEMA, base, {
      // The settings surface's resolved values satisfy WhaleConfig structurally;
      // the schema's ObjectT return type is not exactly assignable, so bridge.
      setSource: (source) => { current = () => source as unknown as WhaleConfig },
      onChange: () => {
        if (!settingsReady) {
          settingsReady = true
          return
        }
        // The settings section owns only the schema fields — it must never
        // drop the free position (x/y), which is persisted via the routes.
        // Merge over the file so any settings attach/detach/change keeps it.
        saveConfig({ ...loadConfig(), ...current() })
      },
    })
  } catch (error) {
    // Settings service absent or section registration failed: the pet still
    // works with its persisted defaults (routes + client), just without the
    // editable settings card.
    ctx.logger?.warn?.('[ventus-whale] settings section unavailable:', error)
  }
}

export { DEFAULT_CONFIG }
