/**
 * Browser-half entry for dsh-ventus-whale — runs inside the dsh web GUI.
 *
 * Mounts:
 *  1. the floating 3D whale pet (body portal — no corner slot exists);
 *  2. the "Ventus 插件" group card into the settings plugin list, plus the
 *     whale settings card into its child slot.
 *
 * Failure policy: DOM mounting problems are logged, never thrown — an
 * external plugin must not take the GUI down.
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the settings-surface SlotMap merge (settings.section)
// and the ctx.settingsScope Context merge.
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { createRoot } from 'react-dom/client'
import { VentusSettingsPage } from './VentusSettingsPage.tsx'
import { WhalePet } from './WhalePet.tsx'
import { WhaleSettingsCard } from './WhaleSettingsCard.tsx'
import { ensureConfigLoaded } from './whale-config-store.ts'
import { applyVentusPrefs } from './ventus-prefs.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    /**
     * The child slot one Ventus family plugin settings card registers into,
     * rendered by the "Ventus" settings section page.
     */
    'ventus.settings.item': { kind: 'list'; scope: 'root'; owner: VentusSettingsItemOwnerProps }
  }
}

/** Owner share of one Ventus settings card (the page supplies nothing). */
export interface VentusSettingsItemOwnerProps {
  /** Marker field: card owner props are intentionally empty. */
  children?: never
}

/** Required services. */
export const inject = ['slots']

/** Check whether a slot name exists in a live slot snapshot. */
function containsSlot(node: unknown, name: string): boolean {
  if (Array.isArray(node)) return node.some(item => containsSlot(item, name))
  if (typeof node !== 'object' || node === null) return false
  const record = node as { name?: unknown; children?: unknown }
  if (record.name === name) return true
  return containsSlot(record.children, name)
}

/** Mount the whale pet + Ventus settings group. */
export function apply(ctx: ClientContext): void {
  const disposers: Array<() => void> = []
  try {
    // 0. Ventus-series shared UI preferences (cache-hit decimals + fluid width).
    disposers.push(applyVentusPrefs())

    // 1. Floating 3D whale pet (body portal).
    const host = document.createElement('div')
    host.dataset.ventusWhaleHost = ''
    document.body.appendChild(host)
    const root = createRoot(host)
    root.render(<WhalePet />)
    disposers.push(() => {
      root.unmount()
      host.remove()
    })

    // 2. Ventus settings page. Only create the page when no other Ventus
    // plugin already declared `ventus.settings.item`; otherwise merge into
    // the existing page so the series shares one "Ventus" settings entry.
    let disposePage: (() => void) | undefined
    const pageTimer = setTimeout(() => {
      if (containsSlot(ctx.slots.snapshot(), 'ventus.settings.item')) return
      disposePage = ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: 'ventus',
        order: 60,
        label: () => 'Ventus',
        children: { 'ventus.settings.item': { kind: 'list', scope: 'root' } },
      }, VentusSettingsPage))
    }, 800)
    disposers.push(() => { clearTimeout(pageTimer); disposePage?.() })
    disposers.push(ctx.slots.inject('ventus.settings.item', () => ctx.slots.register({
      name: 'ventus.settings.item',
      id: 'ventus-whale',
      order: 10,
    }, WhaleSettingsCard)))
    // t9: 激活时预取 config——设置卡片挂载时数据已就绪，打开设置立即渲染
    // （与 webui 全家桶卡片「数据在激活时预载」的时序一致；官方 settings RPC
    // 的 apiproxy allowlist 对第三方 namespace 硬编码不可用，故预取自身端点）。
    ensureConfigLoaded()
  } catch (error) {
    // DOM failures degrade the pet, never the GUI.
    console.warn('[dsh-ventus-whale] mount failed:', error)
  }
  ctx.effect(() => () => {
    for (const dispose of disposers.splice(0)) dispose()
  }, 'dsh-ventus-whale: ui mounts')
}
