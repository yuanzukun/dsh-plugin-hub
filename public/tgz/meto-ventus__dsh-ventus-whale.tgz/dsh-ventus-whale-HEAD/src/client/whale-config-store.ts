/**
 * Shared whale-config cache (t9).
 *
 * The whale config is prefetched at plugin activation so the settings card
 * renders immediately when the settings dialog opens — the same "data ready
 * before the card mounts" timing the web-ui family cards get from their
 * settings bridge. The official settings RPC cannot serve third-party
 * namespaces on this host (the apiproxy settings allowlist is hard-coded, and
 * the web-ui bridge allowlist does not include ventus-whale), so the ventus
 * card prefetches its own endpoint into this store instead.
 */

import type { WhaleConfig } from '../protocol.ts'

/** One cache snapshot. */
export interface ConfigSnapshot {
  /** 'ready' once a value stands; 'unavailable' after a failed prefetch. */
  status: 'loading' | 'ready' | 'unavailable'
  /** The last accepted config, or null before the first acceptance. */
  value: WhaleConfig | null
}

let snapshot: ConfigSnapshot = { status: 'loading', value: null }
let inFlight: Promise<void> | null = null
const listeners = new Set<() => void>()

/** @returns the current sync snapshot (stable reference until the next change). */
export function getConfigSnapshot(): ConfigSnapshot {
  return snapshot
}

/**
 * Observe snapshot replacements.
 * @param listener - invoked after each snapshot change.
 * @returns the disposer removing this listener.
 */
export function subscribeConfig(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

function publish(next: ConfigSnapshot): void {
  snapshot = next
  for (const listener of listeners) listener()
}

/** External writers (e.g. WhalePet's own load) publish their accepted config. */
export function publishConfig(config: WhaleConfig): void {
  publish({ status: 'ready', value: config })
}

/** Prefetch the config (idempotent; deduplicates in-flight loads). */
export function ensureConfigLoaded(): void {
  if (snapshot.status === 'ready' || inFlight !== null) return
  inFlight = (async () => {
    try {
      const response = await fetch('/api/ventus-whale/state')
      if (!response.ok) throw new Error('ventus-whale state failed: ' + response.status)
      const body = (await response.json()) as { config: WhaleConfig }
      publish({ status: 'ready', value: body.config })
    } catch {
      // A failed prefetch leaves the cache unavailable; the card renders its
      // "设置不可用" explanation instead of a blank hole.
      publish({ status: 'unavailable', value: null })
    } finally {
      inFlight = null
    }
  })()
}
