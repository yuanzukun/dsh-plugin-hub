/**
 * The whale pet settings card: enabled, flip-on-send, scale, sensitivity,
 * caption, and bottom offset. Reads the shared config cache (t9: prefetched
 * at plugin activation, so the card renders immediately when the settings
 * dialog opens — the same data-ready-before-mount timing the web-ui family
 * cards get from their settings bridge), and writes through the host API so
 * the pet's full config (including the free x/y position) stays intact.
 * Registered into the `ventus.plugin.item` child slot the Ventus group
 * card declares.
 *
 * t12: 设置不再自动保存——所有控件只写入本地草稿（draft），点「保存」一次性
 * 提交到 host API 并广播，「取消」丢弃草稿回到已保存值。虎鲸自身的交互
 * （拖拽定位、悬停改名）仍即时持久化，不受本卡保存语义影响。
 */

import { useEffect, useSyncExternalStore, useState, type ReactNode } from 'react'
import { DEFAULT_CONFIG, type WhaleConfig } from '../protocol.ts'
import { WHALE_CONFIG_EVENT, WHALE_PREVIEW_EVENT, whaleApi, type WhaleApi } from './WhalePet.tsx'
import { ensureConfigLoaded, getConfigSnapshot, publishConfig, subscribeConfig } from './whale-config-store.ts'
import { VENTUS_PREFS_EVENT, readVentusPrefs, writeVentusPrefs, type VentusPrefs } from './ventus-prefs.ts'
import css from './ventus-settings.module.css'

/** Props the settings card binds. */
export interface WhaleSettingsCardProps {
  /** The host API (tests inject a fake). */
  api?: WhaleApi
}

/** One numeric slider row. */
function SliderRow(props: {
  label: string
  hint: string
  min: number
  max: number
  step: number
  value: number
  disabled: boolean
  onChange: (value: number) => void
}): ReactNode {
  return (
    <label className={css.field}>
      <span className={css.fieldHead}>
        <span className={css.fieldLabel}>{props.label}</span>
        <span className={css.fieldValue}>{props.value.toFixed(2)}</span>
      </span>
      <input
        type="range"
        className={css.slider}
        min={props.min}
        max={props.max}
        step={props.step}
        value={props.value}
        disabled={props.disabled}
        onChange={event => props.onChange(Number(event.target.value))}
      />
      <span className={css.fieldHint}>{props.hint}</span>
    </label>
  )
}

/**
 * Render the whale pet settings card.
 * @param props - api client.
 * @returns the card, or nothing when the API is unreachable.
 */
export function WhaleSettingsCard({ api = whaleApi }: WhaleSettingsCardProps): ReactNode {
  /** 已保存（服务端确认）的配置。 */
  const [committed, setCommitted] = useState<WhaleConfig | null>(null)
  /** 未保存的本地草稿；null = 没有待保存修改。 */
  const [draft, setDraft] = useState<WhaleConfig | null>(null)
  const [saving, setSaving] = useState(false)
  const [failed, setFailed] = useState(false)
  /** 折叠状态为会话内纯视觉状态，默认折叠：用户点击后再展开设置内容。 */
  const [collapsed, setCollapsed] = useState(true)
  /** Ventus 系列共享 UI 偏好（localStorage，立即生效）。 */
  const [prefs, setPrefs] = useState<VentusPrefs>(() => readVentusPrefs())
  useEffect(() => {
    const onPrefs = (event: Event): void => {
      const detail = (event as CustomEvent<VentusPrefs>).detail
      if (detail !== undefined) setPrefs(detail)
    }
    window.addEventListener(VENTUS_PREFS_EVENT, onPrefs)
    window.addEventListener('storage', onPrefs)
    return () => {
      window.removeEventListener(VENTUS_PREFS_EVENT, onPrefs)
      window.removeEventListener('storage', onPrefs)
    }
  }, [])
  const setPref = (patch: Partial<VentusPrefs>): void => {
    const next = { ...prefs, ...patch }
    setPrefs(next)
    writeVentusPrefs(next)
  }
  /** t9: 共享 config 缓存（插件激活时预取）。缓存 ready 时卡片立即渲染。 */
  const storeSnapshot = useSyncExternalStore(subscribeConfig, getConfigSnapshot)

  // 预取兜底（apply 已启动，这里幂等）：卡片独立挂载时也确保数据在途。
  useEffect(() => {
    ensureConfigLoaded()
  }, [])

  // t15: 挂载时拉取实时持久化配置作为基准——预取缓存可能早于侧边栏召唤/隐藏，
  // 若直接以它为 base，保存会把过期的 enabled 写回去（表现为保存后虎鲸消失）。
  useEffect(() => {
    let cancelled = false
    void api.state().then(({ config }) => {
      if (!cancelled) setCommitted(config)
    }).catch(() => {
      // 读取失败时保留预取缓存/默认值兜底。
    })
    return () => { cancelled = true }
  }, [api])

  useEffect(() => {
    // The pet broadcasts every accepted update (move, hide, summon); keep the
    // card's committed config in sync without a reload. 草稿不受外部更新影响。
    const onConfig = (event: Event): void => {
      const detail = (event as CustomEvent<WhaleConfig>).detail
      if (detail !== undefined) setCommitted(detail)
    }
    window.addEventListener(WHALE_CONFIG_EVENT, onConfig)
    return () => window.removeEventListener(WHALE_CONFIG_EVENT, onConfig)
  }, [])

  // 已保存值优先级：本地 committed（本卡保存后/广播）> 预取缓存 > 默认值。
  // 展示值优先级：草稿（未保存修改）> 已保存值。永远不返回 null——loading
  // 时用默认值占位（附「读取中」标记），unavailable 时给出不可用说明。
  const base: WhaleConfig = committed ?? storeSnapshot.value ?? DEFAULT_CONFIG
  const effective: WhaleConfig = draft ?? base
  if (storeSnapshot.status === 'unavailable' && committed === null && draft === null) {
    return (
      <li className={css.card}><span className={css.readOnly}>设置不可用（host API 未响应）</span></li>
    )
  }
  const loading = storeSnapshot.status === 'loading' && committed === null && draft === null

  /** 与已保存值相比是否有未保存修改（草稿非空且任一可编辑字段不同）。 */
  const dirty = draft !== null && (
    draft.enabled !== base.enabled
    || draft.flipOnSend !== base.flipOnSend
    || draft.scale !== base.scale
    || draft.sensitivity !== base.sensitivity
    || draft.caption !== base.caption
  )

  /** 只改草稿，不写 host；同步 pet 实时预览（拖滑块即时看到效果，保存才落盘）。 */
  const stage = (partial: Partial<WhaleConfig>): void => {
    const next = { ...effective, ...partial }
    setDraft(next)
    setFailed(false)
    window.dispatchEvent(new CustomEvent<WhaleConfig>(WHALE_PREVIEW_EVENT, { detail: next }))
  }

  /** 把草稿一次性提交到 host API 并广播。 */
  const save = async (): Promise<void> => {
    if (draft === null) return
    setSaving(true)
    setFailed(false)
    try {
      const result = await api.update({
        enabled: draft.enabled,
        flipOnSend: draft.flipOnSend,
        scale: draft.scale,
        sensitivity: draft.sensitivity,
        caption: draft.caption,
      })
      setCommitted(result.config)
      setDraft(null)
      publishConfig(result.config)
      window.dispatchEvent(new CustomEvent<WhaleConfig>(WHALE_CONFIG_EVENT, { detail: result.config }))
    } catch {
      setFailed(true)
    } finally {
      setSaving(false)
    }
  }

  /** 丢弃草稿，回到已保存值，并让 pet 预览还原。 */
  const cancel = (): void => {
    setDraft(null)
    setFailed(false)
    window.dispatchEvent(new CustomEvent<WhaleConfig>(WHALE_PREVIEW_EVENT, { detail: base }))
  }

  const setEnabled = (enabled: boolean): void => stage({ enabled })
  const toggleCollapsed = (): void => {
    setCollapsed(current => !current)
  }

  return (
    <li className={css.card}>
      <div
        className={css.cardHead}
        role="button"
        tabIndex={0}
        aria-expanded={!collapsed}
        onClick={toggleCollapsed}
        onKeyDown={(event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault()
            toggleCollapsed()
          }
        }}
      >
        <span className={css.cardTitle}>大肥鱼桌宠</span>
        {loading && <span className={css.saving}>读取中…</span>}
        {saving && <span className={css.saving}>保存中…</span>}
        {failed && <span className={css.failed} role="status">保存失败</span>}
        <span className={collapsed ? `${css.chevron} ${css.collapse}` : `${css.chevronOpen} ${css.collapse}`}>
          ▾
        </span>
      </div>
      {!collapsed && (
        <div className={css.cardBody}>
        <label className={css.toggleRow}>
          <span className={css.toggleRowText}>
            <span className={css.toggleRowLabel}>启用虎鲸</span>
            <span className={css.toggleRowHint}>关闭后隐藏桌宠，仍可用侧边栏「召唤虎鲸」重新显示</span>
          </span>
          <input
            id="ventus-whale-enabled"
            type="checkbox"
            className={css.switch}
            checked={effective.enabled}
            disabled={saving}
            onChange={event => setEnabled(event.target.checked)}
          />
        </label>
        <span className={css.usageHint}>操作提示：左键拖动旋转 · 右键或「拖动」按钮移动 · 单击爱心 · 双击弹跳 · 悬停工具栏「转圈」翻跟头</span>
        <label className={css.field}>
          <span className={css.fieldHead}>
            <span className={css.fieldLabel}>发送时翻跟头</span>
          </span>
          <span className={css.switchWrap}>
            <input
              id="ventus-whale-flip-on-send"
              type="checkbox"
              className={css.switch}
              checked={effective.flipOnSend}
              disabled={saving}
              onChange={event => stage({ flipOnSend: event.target.checked })}
            />
            <label htmlFor="ventus-whale-flip-on-send" className={css.switchLabel}>
              {effective.flipOnSend ? '已开启' : '已关闭'}
            </label>
          </span>
          <span className={css.fieldHint}>发送消息时虎鲸翻一个跟头庆祝</span>
        </label>
        <SliderRow
          label="大小"
          hint="虎鲸的显示尺寸（窗口随大小缩放，鲸鱼始终完整可见）"
          min={0.2}
          max={3}
          step={0.05}
          value={effective.scale}
          disabled={saving}
          onChange={value => stage({ scale: value })}
        />
        <SliderRow
          label="灵敏度"
          hint="拖动旋转的灵敏度"
          min={0.2}
          max={5}
          step={0.05}
          value={effective.sensitivity}
          disabled={saving}
          onChange={value => stage({ sensitivity: value })}
        />
        <label className={css.field}>
          <span className={css.fieldHead}>
            <span className={css.fieldLabel}>显示文字</span>
          </span>
          <input
            type="text"
            className={css.textInput}
            value={effective.caption}
            maxLength={80}
            disabled={saving}
            placeholder="留空则隐藏"
            onChange={event => stage({ caption: event.target.value })}
          />
          <span className={css.fieldHint}>显示在虎鲸下方的文字，留空隐藏</span>
        </label>
        <label className={css.field}>
          <span className={css.fieldHead}>
            <span className={css.fieldLabel}>缓存命中显示两位小数</span>
          </span>
          <span className={css.switchWrap}>
            <input
              id="ventus-cache-hit-2decimals"
              type="checkbox"
              className={css.switch}
              checked={prefs.cacheHit2Decimals}
              onChange={event => setPref({ cacheHit2Decimals: event.target.checked })}
            />
            <label htmlFor="ventus-cache-hit-2decimals" className={css.switchLabel}>
              {prefs.cacheHit2Decimals ? '已开启' : '已关闭'}
            </label>
          </span>
          <span className={css.fieldHint}>把输入框下方的“缓存命中 x%”统一显示为两位小数（兼容桌面/Web）</span>
        </label>
        <label className={css.field}>
          <span className={css.fieldHead}>
            <span className={css.fieldLabel}>对话横向宽度不限制</span>
          </span>
          <span className={css.switchWrap}>
            <input
              id="ventus-fluid-width"
              type="checkbox"
              className={css.switch}
              checked={prefs.fluidConversationWidth}
              onChange={event => setPref({ fluidConversationWidth: event.target.checked })}
            />
            <label htmlFor="ventus-fluid-width" className={css.switchLabel}>
              {prefs.fluidConversationWidth ? '已开启' : '已关闭'}
            </label>
          </span>
          <span className={css.fieldHint}>开启后对话内容贴合左右侧边栏边界，不再限制为固定 748px 宽度</span>
        </label>
        {dirty && (
          <div className={css.actions}>
            <span className={css.dirtyHint}>有未保存的更改</span>
            <button
              type="button"
              className={css.saveButton}
              disabled={saving}
              onClick={() => void save()}
            >
              {saving ? '保存中…' : '保存'}
            </button>
            <button
              type="button"
              className={css.cancelButton}
              disabled={saving}
              onClick={cancel}
            >
              取消
            </button>
          </div>
        )}
      </div>
      )}
    </li>
  )
}