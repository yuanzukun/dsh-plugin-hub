/**
 * The Ventus whale pet: a transparent floating 3D whale in the corner of the
 * web GUI. Interactions:
 * - left drag: rotate the whale in place (arcball, with release momentum);
 * - right drag (or the hover toolbar's 拖动 button, touch-friendly):
 *   freely reposition the whale anywhere in the viewport (persisted as x/y;
 *   any settings save keeps the position); the button toggles move mode and
 *   pointer events unify mouse/touch (touch-action: none while dragging);
 * - drag (left or right): hearts keep bursting while the pointer moves,
 *   throttled to ~5 bursts/s, so the whole gesture showers hearts;
 * - single click: a burst of 3–5 hearts floats up from the head crown
 *   (sprite hearts follow the whale's rotation); right click bursts too;
 * - double click: the whale jumps;
 * - hover: a two-row toolbar appears (改名 / 重置 / 拖动 / 爱心开关 / 转圈);
 *   on touch devices a tap on the whale toggles the toolbar; 改名 edits the
 *   caption inline; 转圈 triggers a 360° front somersault on demand. The
 *   caption is hidden by default.
 * - summon/hide is the sidebar 🐋 toggle (t8): no independent hide control.
 * - default: disabled (t10), summoned at the right-middle of the viewport.
 * Config (scale / sensitivity / caption / x / y) rides the
 * host /api/ventus-whale endpoints; every accepted update is broadcast on
 * WHALE_CONFIG_EVENT so the settings card stays in sync.
 */

import { useEffect, useRef, useState, type ReactPortal } from 'react'
import { createPortal } from 'react-dom'
import type { WhaleConfig } from '../protocol.ts'
import { createWhaleScene, type WhaleSceneHandle } from './whale-model.ts'
import { publishConfig } from './whale-config-store.ts'
import styles from './whale-pet.module.css'
/** Host API patch: x/y accept null to clear the free position. */
export type WhalePatch = Partial<Omit<WhaleConfig, 'x' | 'y'>> & { x?: number | null; y?: number | null }

/** The host API surface. */
export interface WhaleApi {
  state(): Promise<{ config: WhaleConfig }>
  update(patch: WhalePatch): Promise<{ config: WhaleConfig }>
}

/** Default host API (same-origin). */
export const whaleApi: WhaleApi = {
  state: async () => {
    const response = await fetch('/api/ventus-whale/state')
    if (!response.ok) throw new Error(`ventus-whale state failed: ${response.status}`)
    return (await response.json()) as { config: WhaleConfig }
  },
  update: async (patch) => {
    const response = await fetch('/api/ventus-whale/update', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(patch),
    })
    if (!response.ok) throw new Error(`ventus-whale update failed: ${response.status}`)
    return (await response.json()) as { config: WhaleConfig }
  },
}

/** Base whale window size (px) at scale 1.0. t12: the window scales with the
 * pet size setting so the model stays fully in frame at any scale.
 * t13: 220 → 176（画幅整体调小 20%）。 */
const PET_SIZE = 176

/** Cross-component config sync event (pet <-> settings card). */
export const WHALE_CONFIG_EVENT = 'ventus-whale:config'
/** t15: 设置卡草稿实时预览事件——只同步 pet 渲染，不视为已保存配置。 */
export const WHALE_PREVIEW_EVENT = 'ventus-whale:preview'

/** Props for the whale pet. */
export interface WhalePetProps {
  /** The host API. */
  api?: WhaleApi
}

/** Viewport edge margins (px) kept when free-positioning the pet. */
const MIN_EDGE_X = 0
const MIN_EDGE_Y = 0

/**
 * The floating 3D whale pet.
 * @param props - api client.
 */
export function WhalePet({ api = whaleApi }: WhalePetProps): ReactPortal | null {
  const wrapperRef = useRef<HTMLDivElement | null>(null)
  const containerRef = useRef<HTMLDivElement | null>(null)
  const sceneRef = useRef<WhaleSceneHandle | null>(null)
  const [config, setConfig] = useState<WhaleConfig | null>(null)
  const [moveMode, setMoveMode] = useState(false)
  /** t10: 触屏无 hover，点按切换悬停面板显隐（桌面靠 :hover）。 */
  const [toolbarPinned, setToolbarPinned] = useState(false)
  /** t10: hover 可用设备（鼠标）用 :hover 显示面板；触屏用点按切换。 */
  const [isHoverDevice] = useState(() => (
    typeof window.matchMedia === 'function' ? window.matchMedia('(hover: hover)').matches : true
  ))
  const [previewPos, setPreviewPos] = useState<{ x: number; y: number } | null>(null)
  const [editingName, setEditingName] = useState(false)
  /** True when the next click must be swallowed (it closes a drag gesture). */
  const suppressClickRef = useRef(false)
  /** Set when Escape cancels the rename input, so its blur does not save. */
  const renameCancelRef = useRef(false)
  const configRef = useRef<WhaleConfig | null>(null)
  configRef.current = config

  // Load config, then create the scene.
  useEffect(() => {
    let cancelled = false
    void api.state().then(({ config: loaded }) => {
      if (cancelled) return
      setConfig(loaded)
      // t9: 写入共享缓存，设置卡片挂载时直接取用（激活时预取的同源数据）。
      publishConfig(loaded)
    }).catch(() => {
      // Fall back to defaults; the scene still shows.
      if (!cancelled) {
        setConfig({
          enabled: false, flipOnSend: true, scale: 1, sensitivity: 1, caption: '',
        })
      }
    })
    // The settings card publishes every accepted update; the pet follows it
    // live so toggling the switch off hides the whale without a refresh.
    const onConfig = (event: Event): void => {
      const detail = (event as CustomEvent<WhaleConfig>).detail
      if (detail !== undefined) setConfig(detail)
    }
    // t15: 设置卡草稿预览（拖滑块实时缩放）与已保存广播都驱动 pet 渲染。
    window.addEventListener(WHALE_CONFIG_EVENT, onConfig)
    window.addEventListener(WHALE_PREVIEW_EVENT, onConfig)
    return () => {
      cancelled = true
      window.removeEventListener(WHALE_CONFIG_EVENT, onConfig)
      window.removeEventListener(WHALE_PREVIEW_EVENT, onConfig)
    }
  }, [api])

  // ---- 3D scene lifecycle ----
  // 场景只创建一次（首次启用时），之后启用/停用只切换可见性（display），
  // 不销毁/重建——召唤与隐藏即时响应，不再有重建空白期或 dispose 卡顿。
  const sceneBuiltRef = useRef(false)
  const unmountedRef = useRef(false)
  useEffect(() => () => { unmountedRef.current = true }, [])
  useEffect(() => {
    if (unmountedRef.current || sceneBuiltRef.current) return
    if (config === null || !config.enabled) return
    const container = containerRef.current
    if (container === null) return
    sceneBuiltRef.current = true
    let cancelled = false
    const build = (): void => {
      if (cancelled || unmountedRef.current) return
      // t12: 大小由窗口尺寸驱动（容器已按 scale 撑开），模型保持自然入框。
      sceneRef.current = createWhaleScene(container)
    }
    // 首次构建推迟一帧（不阻塞当前渲染），召唤时鲸鱼尽快出现。
    const timer = window.setTimeout(build, 0)
    return () => {
      cancelled = true
      window.clearTimeout(timer)
      // 仅组件真正卸载时才释放 WebGL 资源；启用/停用切换保留场景。
      if (unmountedRef.current) {
        sceneRef.current?.dispose()
        sceneRef.current = null
      }
    }
  }, [config?.enabled]) // eslint-disable-line react-hooks/exhaustive-deps
  // t3: 停用（display:none）时暂停渲染循环——否则隐藏的鲸鱼仍每帧 rAF 空转，
  // 拖慢整个页面（含其他插件的隐藏/交互）。启用时恢复，场景本身保留。
  useEffect(() => {
    if (config === null) return
    if (config.enabled) sceneRef.current?.resume()
    else sceneRef.current?.pause()
  }, [config?.enabled]) // eslint-disable-line react-hooks/exhaustive-deps
  // Enter sends a message → the whale flips (gated on flipOnSend). A "send"
  // is Enter without Shift (Shift+Enter inserts a newline), outside IME
  // composition (the composing Enter confirms a candidate, not the message),
  // pressed inside a text input/textarea, and not auto-repeated. Typing
  // inside the pet's own window (rename input) must not count as a send.
  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (event.key !== 'Enter' || event.shiftKey || event.isComposing || event.repeat) return
      const target = event.target
      const isEditable = target instanceof HTMLElement
        && (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT')
      if (!isEditable) return
      if (target instanceof Node && wrapperRef.current?.contains(target)) return
      if (!configRef.current?.flipOnSend) return
      sceneRef.current?.flip()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  // Esc exits move mode.
  useEffect(() => {
    if (!moveMode) return
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setMoveMode(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [moveMode])
  // t10: 拖动模式下点击面板外退出（触屏松手已有 onPointerUp 退出路径）。
  useEffect(() => {
    if (!moveMode) return
    const onDown = (event: PointerEvent): void => {
      const target = event.target
      if (target instanceof Node && wrapperRef.current !== null && !wrapperRef.current.contains(target)) {
        setMoveMode(false)
      }
    }
    document.addEventListener('pointerdown', onDown)
    return () => document.removeEventListener('pointerdown', onDown)
  }, [moveMode])

  // Drag state. Declared before any conditional return so the hook count
  // stays stable when the pet is hidden/shown via the enable switch.
  interface DragState {
    pointerId: number
    lastX: number
    lastY: number
    moved: boolean
    startX: number
    startY: number
    /** Which button started the drag (0 = rotate, 2 = move). */
    button: number
    /** Grab-point offset inside the wrapper (keeps the whale under the cursor). */
    grabOffsetX: number
    grabOffsetY: number
  }
  const dragRef = useRef<DragState | null>(null)

  // 拖拽喷爱心节流：指针移动事件频率极高，200ms 间隔限制喷发频率，
  // 避免 burstHearts 高频调用产生过量 sprite（约每秒 5 次喷发）。
  const HEART_INTERVAL = 200
  const lastHeartRef = useRef(0)
  // 爱心开关（悬停工具栏切换，localStorage 持久化）
  const [heartsEnabled, setHeartsEnabled] = useState(() => localStorage.getItem('ventus-hearts') !== 'off')
  const heartsEnabledRef = useRef(heartsEnabled)
  heartsEnabledRef.current = heartsEnabled
  const toggleHearts = (): void => {
    const next = !heartsEnabledRef.current
    heartsEnabledRef.current = next
    setHeartsEnabled(next)
    localStorage.setItem('ventus-hearts', next ? 'on' : 'off')
  }
  const maybeBurstHearts = (): void => {
    if (!heartsEnabledRef.current) return
    const now = performance.now()
    if (now - lastHeartRef.current < HEART_INTERVAL) return
    lastHeartRef.current = now
    sceneRef.current?.burstHearts()
  }

  if (config === null) return null
  // t12: 窗口（画布）随大小设置线性缩放；模型在画布内保持自然入框比例。
  const petSize = Math.round(PET_SIZE * config.scale)

  /** Resolve the wrapper style: live preview > free x/y > docked (fixed left). */
  const positionStyle = (cfg: WhaleConfig, preview: { x: number; y: number } | null): React.CSSProperties => {
    const pos = preview ?? (cfg.x !== undefined && cfg.y !== undefined
      ? { x: clampX(cfg.x), y: clampY(cfg.y) }
      : null)
    if (pos !== null) {
      return { left: `${pos.x}px`, top: `${pos.y}px` }
    }
        // t10: 无已保存 x/y 时，召唤出现在视口右侧中部（距右 32px、垂直居中偏上一点），不压左下/右下角。
    return {
      right: '32px',
      top: '38%',
    }
  }

  /** Persist a patch, adopt the result, and broadcast it. */
  const applyUpdate = async (patch: WhalePatch): Promise<WhaleConfig | null> => {
    const current = configRef.current
    if (current === null) return null
    const result = await api.update(patch)
    setConfig(result.config)
    // t15: 所有接受更新的写入方都同步共享缓存，避免设置卡读到过期值。
    publishConfig(result.config)
    window.dispatchEvent(new CustomEvent<WhaleConfig>(WHALE_CONFIG_EVENT, { detail: result.config }))
    return result.config
  }

  // 召唤入口在侧边栏（sidebar.footer.action）——停用时 wrapper 隐藏但保留
  // 场景（召唤即时出现），不再渲染 body 上的独立 pill（避免重复入口）。

  // t11: 按 wrapper 实际尺寸钳制（悬停工具栏在上、canvas、caption 在下）——
  // 拖到任何边缘时整只虎鲸+工具栏都留在视口内。
  const wrapperSize = (): { w: number; h: number } => {
    const rect = wrapperRef.current?.getBoundingClientRect()
    // 布局未就绪时按预期最大尺寸钳制（canvas + 悬停工具栏高度），
    // 避免渲染钳制竞态导致 bottom 超视口。
    return rect !== undefined && rect.width > 1
      ? { w: rect.width, h: rect.height }
      : { w: petSize, h: petSize + 40 }
  }
  const clampX = (x: number): number => {
    const { w } = wrapperSize()
    return Math.max(MIN_EDGE_X, Math.min(window.innerWidth - w, x))
  }
  const clampY = (y: number): number => {
    const { h } = wrapperSize()
    return Math.max(MIN_EDGE_Y, Math.min(window.innerHeight - h, y))
  }

  /** Right-drag moves the whale; left-drag rotates (or free-moves in moveMode). */
  const onPointerDown = (event: ReactPointerEvent2): void => {
    if (event.button !== 0 && event.button !== 2) return
    event.preventDefault()
    const rect = wrapperRef.current?.getBoundingClientRect() ?? { left: 0, top: 0 }
    dragRef.current = {
      pointerId: event.pointerId,
      lastX: event.clientX,
      lastY: event.clientY,
      startX: event.clientX,
      startY: event.clientY,
      moved: false,
      button: event.button,
      grabOffsetX: event.clientX - rect.left,
      grabOffsetY: event.clientY - rect.top,
    }
    ;(event.currentTarget as HTMLElement).setPointerCapture?.(event.pointerId)
  }
  const onPointerMove = (event: ReactPointerEvent2): void => {
    const drag = dragRef.current
    if (drag === null || drag.pointerId !== event.pointerId) return
    const dx = event.clientX - drag.lastX
    const dy = event.clientY - drag.lastY
    if (Math.abs(event.clientX - drag.startX) > 4 || Math.abs(event.clientY - drag.startY) > 4) drag.moved = true
    drag.lastX = event.clientX
    drag.lastY = event.clientY
    // Right button (or moveMode): reposition the whale freely.
    if (moveMode || drag.button === 2) {
      setPreviewPos({
        x: clampX(event.clientX - drag.grabOffsetX),
        y: clampY(event.clientY - drag.grabOffsetY),
      })
      maybeBurstHearts() // 右键/移动模式拖拽中持续喷爱心
      return
    }
    const sensitivity = configRef.current?.sensitivity ?? 1
    // Horizontal drag: rotate yaw; vertical drag: tilt pitch (俯瞰/仰视).
    // +dy (mouse down) pitches forward to look up from below; -dy (mouse up)
    // pitches back to look down from above — natural "grab the whale" feel.
    // 灵敏度系数缩小约 3 倍（0.01→0.0033、0.008→0.0027），
    // 使默认 sensitivity=1.0 等效于旧的 0.3，体感适中。
    sceneRef.current?.rotateYaw(dx * 0.0033 * sensitivity)
    sceneRef.current?.rotatePitch(dy * 0.0027 * sensitivity)
    maybeBurstHearts() // 左键拖拽旋转中持续喷爱心（200ms 节流）
  }
  const onPointerUp = (event: ReactPointerEvent2): void => {
    const drag = dragRef.current
    if (drag === null || drag.pointerId !== event.pointerId) return
    const wasMove = drag.moved && (drag.button === 2 || moveMode)
    // Any drag (or a right click) must not burst hearts: the browser fires a
    // click right after the pointer-up, so flag it here for onClick to eat.
    suppressClickRef.current = drag.moved || drag.button === 2
    dragRef.current = null
    if (!wasMove) return
    // Persist the free position and leave move mode (preview stays until the
    // host confirms, so the whale does not snap back during the round-trip).
    const x = Math.round(clampX(event.clientX - drag.grabOffsetX))
    const y = Math.round(clampY(event.clientY - drag.grabOffsetY))
    void applyUpdate({ x, y }).then(() => {
      setPreviewPos(null)
      setMoveMode(false)
    })
  }
  const onPointerCancel = (event: ReactPointerEvent2): void => {
    if (dragRef.current?.pointerId !== event.pointerId) return
    suppressClickRef.current = false
    dragRef.current = null
  }

  // ---- double-click: jump (bounce) ---------------------------------------
  const onDoubleClick = (): void => {
    if (moveMode) {
      setMoveMode(false)
      setPreviewPos(null)
      return
    }
    sceneRef.current?.jump()
  }

  // ---- single click (no drag): heart burst at the head crown ---------------
  const onClick = (event: ReactMouseEvent2): void => {
    // The second click of a double-click belongs to the jump gesture.
    if (event.detail > 1) return
    // A click closing a drag (or arriving mid-drag) must not burst hearts.
    if (suppressClickRef.current) {
      suppressClickRef.current = false
      return
    }
    if (dragRef.current !== null) return
    // t10: 触屏无 hover，点按切换悬停面板显隐（桌面 hover 不受影响）。
    if (!isHoverDevice) setToolbarPinned(current => !current)
    if (heartsEnabledRef.current) sceneRef.current?.burstHearts()
  }

  // Right-click now drags to move (onPointerDown/button 2); suppress the
  // native context menu so the drag gesture does not pop a browser menu.
  // contextmenu 是右键唯一可靠的钩子（浏览器不派发 click 事件）：
  // 在此补一次爱心喷发，右键单击/拖拽按下都会触发。
  const onContextMenu = (event: ReactMouseEvent2): void => {
    event.preventDefault()
    maybeBurstHearts()
  }

  const commitRename = (value: string): void => {
    setEditingName(false)
    void applyUpdate({ caption: value.trim() })
  }

  const resetPosition = async (): Promise<void> => {
    sceneRef.current?.resetRotation()
    const next = await api.update({ x: null, y: null })
    setConfig(next.config)
    window.dispatchEvent(new CustomEvent<WhaleConfig>(WHALE_CONFIG_EVENT, { detail: next.config }))
  }

  // t8: 隐藏功能并入侧边栏「召唤虎鲸」按钮（toggle）；工具栏不再有独立隐藏。

  return createPortal(
    <div
      ref={wrapperRef}
      className={toolbarPinned ? `${styles.wrapper} ${styles.wrapperToolbarOn}` : styles.wrapper}
      style={{
        ...positionStyle(config, previewPos),
        // 停用时隐藏但不卸载（场景保留，召唤即时显示）
        ...(!config.enabled ? { display: 'none' } : {}),
      }}
      data-ventus-whale
    >
      <div className={styles.quickToolbar} role="toolbar" aria-label="虎鲸快捷操作">
        <div className={styles.toolbarRow}>
          {editingName ? (
            <input
              className={styles.renameInput}
              autoFocus
              defaultValue={config.caption}
              placeholder="输入名字，留空隐藏"
              maxLength={80}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  event.currentTarget.blur()
                } else if (event.key === 'Escape') {
                  renameCancelRef.current = true
                  setEditingName(false)
                }
              }}
              onBlur={(event) => {
                if (renameCancelRef.current) {
                  renameCancelRef.current = false
                  return
                }
                commitRename(event.currentTarget.value)
              }}
            />
          ) : (
            <button type="button" onClick={() => setEditingName(true)}>改名</button>
          )}
          <button type="button" onClick={() => void resetPosition()}>重置</button>
          <button type="button" onClick={() => setMoveMode(current => !current)}>{moveMode ? '退出拖动' : '拖动'}</button>
        </div>
        <div className={styles.toolbarRow}>
          <button type="button" aria-pressed={heartsEnabled} onClick={toggleHearts}>{heartsEnabled ? '爱心开' : '爱心关'}</button>
          <button type="button" onClick={() => sceneRef.current?.flip()}>转圈</button>
        </div>
      </div>
      <div
        ref={containerRef}
        className={moveMode ? styles.canvasMove : styles.canvas}
        style={{ width: petSize, height: petSize }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerCancel}
        onClick={onClick}
        onDoubleClick={onDoubleClick}
        onContextMenu={onContextMenu}
      />
      {moveMode && (
        <div className={styles.moveHint}>按住拖动定位 · 松手保存 · 再次点击「拖动」或 Esc 退出</div>
      )}
      {config.caption !== '' && (
        <div className={styles.caption}>{config.caption}</div>
      )}
    </div>,
    document.body,
  )
}

/** Minimal pointer/mouse event aliases (React types without full import). */
type ReactPointerEvent2 = import('react').PointerEvent<HTMLDivElement>
type ReactMouseEvent2 = import('react').MouseEvent<HTMLDivElement>
