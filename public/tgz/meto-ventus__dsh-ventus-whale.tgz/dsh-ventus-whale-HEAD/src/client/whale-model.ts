/**
 * The Ventus whale 3D model: a self-contained three.js scene built from the
 * DeepSeek whale contour (swept body + dorsal/pectoral/tail fins + eyes).
 * Ported from the interactive whale demo and adapted for the pet use case:
 * transparent background, gentle idle animation, no OrbitControls (the pet
 * host handles rotation/drag). The on-screen size is driven by the host
 * window size (the pet window scales with the size setting); the camera
 * fits the model into the canvas once at build time.
 *
 * The module owns its renderer lifecycle: createWhaleScene() returns a
 * handle with start/pause/rotate/dispose so the plugin fiber can clean
 * everything up.
 */

import {
  Box3,
  BufferGeometry,
  CanvasTexture,
  Clock,
  DataTexture,
  DoubleSide,
  Euler,
  Float32BufferAttribute,
  Group,
  HalfFloatType,
  LinearFilter,
  Mesh,
  MeshBasicMaterial,
  PerspectiveCamera,
  Quaternion,
  RGFormat,
  Raycaster,
  Scene,
  ShapeUtils,
  Sprite,
  SpriteMaterial,
  Sphere,
  Vector2,
  Vector3,
  WebGLRenderer,
} from 'three'

/** Path constants from the original demo (whale body + fins + brow). */
const BODY_PATH = 'M 144.00 80.00 C 144.67 84.83, 143.00 95.34, 141.00 102.00 C 139.00 108.66, 136.50 113.84, 132.00 120.00 C 127.50 126.16, 119.66 134.34, 114.00 139.00 C 108.34 143.66, 103.49 146.17, 98.00 148.00 C 92.51 149.83, 87.83 150.83, 81.00 150.00 C 74.17 149.17, 63.83 146.66, 57.00 143.00 C 50.17 139.34, 44.50 134.16, 40.00 128.00 C 35.50 121.84, 31.83 113.16, 30.00 106.00 C 28.17 98.84, 28.17 90.99, 29.00 85.00 C 29.83 79.01, 32.17 74.50, 35.00 70.00 C 37.83 65.50, 41.67 61.00, 46.00 58.00 C 50.33 55.00, 56.01 53.00, 61.00 52.00 C 66.00 51.00, 70.51 51.00, 76.00 52.00 C 81.49 53.00, 85.34 52.34, 94.00 58.00 C 102.66 63.66, 120.84 83.50, 128.00 86.00 C 135.16 88.50, 134.34 74.00, 137.00 73.00 C 139.66 72.00, 143.33 75.17, 144.00 80.00 Z'
const BROW_PATH = 'M 146.00 127.00 C 144.34 128.00, 138.50 129.50, 136.00 129.00 C 133.50 128.50, 131.83 126.33, 131.00 124.00 C 130.17 121.67, 131.67 117.16, 131.00 115.00 C 130.33 112.84, 128.33 111.67, 127.00 111.00 C 125.67 110.33, 124.00 111.33, 123.00 111.00 C 122.00 110.67, 121.17 109.83, 121.00 109.00 C 120.83 108.17, 120.50 106.67, 122.00 106.00 C 123.50 105.33, 127.84 104.67, 130.00 105.00 C 132.16 105.33, 133.00 106.17, 135.00 108.00 C 137.00 109.83, 140.17 113.50, 142.00 116.00 C 143.83 118.50, 145.33 121.17, 146.00 123.00 C 146.67 124.83, 147.66 126.00, 146.00 127.00 Z'
const TAIL_PATH = 'M 17.902 4.103 L 22.379 9.998 C 22.435 9.614, 22.507 9.073, 22.499 8.762 C 22.494 8.572, 22.538 8.499, 22.755 8.477 C 23.354 8.408, 23.935 8.244, 24.469 7.950 C 26.019 7.104, 26.644 5.713, 26.791 4.047 C 26.813 3.792, 26.787 3.529, 26.517 3.395 C 26.235 3.257, 26.114 3.520, 25.949 3.653 C 25.892 3.697, 25.845 3.753, 25.797 3.805 C 25.385 4.245, 24.903 4.534, 24.274 4.500 C 23.354 4.448, 22.568 4.737, 21.873 5.441 C 21.726 4.573, 21.235 4.055, 20.489 3.723 C 20.099 3.551, 19.703 3.377, 19.430 3.002 C 19.239 2.735, 19.186 2.437, 19.091 2.143 C 19.030 1.966, 18.970 1.785, 18.766 1.754 C 18.544 1.720, 18.457 1.905, 18.370 2.061 C 18.023 2.695, 17.889 3.395, 17.902 4.103 Z'
const DORSAL_PATH = 'M 10.436 2.993 L 13.852 4.746 C 12.758 3.684, 13.995 2.812, 14.282 2.708 C 14.581 2.600, 14.386 2.229, 13.418 2.233 C 12.450 2.237, 11.565 2.562, 10.436 2.993 Z'
const PEC_PATH = 'M 16.747 19.267 L 20.614 19.565 C 20.093 19.673, 19.421 19.772, 18.722 19.707 C 17.815 19.630, 17.268 19.526, 16.747 19.267 Z'

/** Model tuning (kept close to the demo defaults). */
const MODEL = {
  // t3: 桌面 3D 桌宠无需高密度网格；60×48→36×24 把体表三角形数降到约 1/3，
  // 渲染与射线命中都更快，肉眼无差（PET_SIZE=176px 下 ~1728 个三角形足够平滑）。
  SWEPT_SLICES: 36,
  SWEPT_RINGS: 24,
  TAIL_FORK_SCALE: 0.177,
  TAIL_THICKNESS: 0.06,
  TAIL_OPEN_ANGLE_DEG: 76.95,
  TAIL_NOTCH_DX: 0.3,
  TAIL_NOTCH_DY: 0.5,
  TAIL_TILT_DEG: 50,
  DORSAL_START_FRAC: 0.331,
  DORSAL_END_FRAC: 0.559,
  DORSAL_SAMPLES: 20,
  DORSAL_THICKNESS: 0.06,
  DORSAL_HEIGHT_SCALE: 0.3186,
  PEC_START_FRAC: 0.38,
  PEC_END_FRAC: 0.48,
  PEC_SPAN: 0.924,
  PEC_SWEEP: 0.33,
  PEC_THICKNESS: 0.05,
  PEC_ANGLE_DEG: 30,
  PEC_RADIAN: 130,
  PEC_OUTWARD_OFFSET: -0.025,
  BODY_TARGET_HEIGHT: 3.5,
  BROW_SCALE: 0.65,
  BROW_OFFSET_X: -35.4,
  BROW_OFFSET_Y: 6,
  BROW_LIFT: 0.9,
  EYE_OFFSET_Y: 10.5,
  EYE_RADIUS: 3.73,
  EYE_CIRCLE_SEGMENTS: 20,
  COLOR_BODY_BLUE: 0x4D6BFE,
  COLOR_WHITE: 0xffffff,
  SWIM_SPEED: 0.9,
  BODY_SWAY_AMPLITUDE: 0.04,
  TAIL_SWAY_AMPLITUDE: 0.08,
  TAIL_PITCH_AMPLITUDE: 0.15,
  PEC_FLAP_AMPLITUDE: 0.25,
  PEC_FLAP_PHASE: 0.6,
  PITCH_AMPLITUDE: 0.015,
  ROLL_AMPLITUDE: 0.01,
  BLINK_INTERVAL: 3.4,
  BLINK_DURATION: 0.2,
  FLOAT_AMPLITUDE: 0.06,
  FLOAT_SPEED: 1.2,
  /** Swim speed multiplier while the cursor hovers the whale. */
  HOVER_SWIM_BOOST: 1.25,
  /** Max yaw the whale adds toward the cursor (radians, full deflection). */
  MOUSE_BIAS_MAX: 0.05,
  /** Max pitch the whale adds toward the cursor (radians, full deflection). */
  MOUSE_PITCH_BIAS: 0.04,
  /** Exponential decay rate of the post-drag rotation momentum.
   *  3.5 → 10：释放后的滑行时间/总角度缩小约 3 倍，避免惯性旋转过大。 */
  DRAG_DECAY: 10,
}

/** t13: 画幅基准缩小 20%（PET_SIZE 220→176）后，模型等比放大 220/176 补偿，
 * 保持鲸鱼在屏幕上的像素尺寸不变（窗口变小、鲸鱼大小不变）。 */
const FRAME_COMPENSATION = 220 / 176

/** Heart burst tuning (sprite hearts at the head crown). */
const LOVE_CONFIG = {
  COUNT_MIN: 3,
  COUNT_MAX: 5,
  /** Base rise speed along the model's local up axis (units/s). */
  SPEED: 1.4,
  /** Heart lifetime in seconds. */
  LIFETIME: 1.2,
  SIZE_MIN: 0.2,
  SIZE_VAR: 0.12,
  /** Horizontal drift speed (units/s). */
  DRIFT: 0.5,
  /** Spawn scatter around the head crown (model units). */
  SCATTER_X: 0.7,
  SCATTER_Y: 0.25,
  SCATTER_Z: 0.7,
  /** Spawn lift above the crown surface so hearts start visibly in the air. */
  LIFT: 0.3,
}

/** Bubble burst tuning (sprite bubbles at the head crown: smaller, slower,
 * longer-lived than hearts). */
const BUBBLE_CONFIG = {
  COUNT_MIN: 4,
  COUNT_MAX: 7,
  /** Base rise speed along the model's local up axis (units/s). */
  SPEED: 1.0,
  /** Bubble lifetime in seconds. */
  LIFETIME: 1.6,
  SIZE_MIN: 0.12,
  SIZE_VAR: 0.1,
  /** Horizontal drift speed (units/s). */
  DRIFT: 0.35,
  /** Spawn scatter around the head crown (model units). */
  SCATTER_X: 0.9,
  SCATTER_Y: 0.3,
  SCATTER_Z: 0.9,
  /** Spawn lift above the crown surface so bubbles start visibly in the air. */
  LIFT: 0.25,
}

let loveTexture: CanvasTexture | null = null

/** Lazy shared flat heart sprite texture (canvas-drawn, one per session). */
function getLoveTexture(): CanvasTexture {
  if (loveTexture !== null) return loveTexture
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 64
  const ctx = canvas.getContext('2d')
  if (ctx !== null) {
    ctx.clearRect(0, 0, 64, 64)
    ctx.fillStyle = '#ff4d6d'
    const size = 30
    const cx = 32
    const cy = 30
    ctx.beginPath()
    ctx.moveTo(cx, cy + size * 0.8)
    ctx.bezierCurveTo(cx + size, cy + size * 0.4, cx + size * 0.8, cy - size * 0.5, cx, cy - size * 0.2)
    ctx.bezierCurveTo(cx - size * 0.8, cy - size * 0.5, cx - size, cy + size * 0.4, cx, cy + size * 0.8)
    ctx.fill()
    ctx.fillStyle = 'rgba(255,255,255,0.6)'
    ctx.beginPath()
    ctx.ellipse(cx - 8, cy - 5, 5, 3, 0, 0, Math.PI * 2)
    ctx.fill()
  }
  const texture = new CanvasTexture(canvas)
  texture.minFilter = LinearFilter
  texture.magFilter = LinearFilter
  loveTexture = texture
  return texture
}

let bubbleTexture: CanvasTexture | null = null

/** Lazy shared translucent bubble sprite texture (canvas-drawn, one per session).
 * The canvas background is left unpainted (alpha 0) so the bubble is a soft
 * disc with a bright rim + highlight, same mechanism as the heart texture. */
function getBubbleTexture(): CanvasTexture {
  if (bubbleTexture !== null) return bubbleTexture
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 64
  const ctx = canvas.getContext('2d')
  if (ctx !== null) {
    ctx.clearRect(0, 0, 64, 64)
    // Radial gradient: bright core fading to a translucent blue rim.
    const gradient = ctx.createRadialGradient(32, 30, 2, 32, 32, 26)
    gradient.addColorStop(0, 'rgba(255,255,255,0.85)')
    gradient.addColorStop(0.5, 'rgba(160,220,255,0.35)')
    gradient.addColorStop(1, 'rgba(120,200,255,0.12)')
    ctx.fillStyle = gradient
    ctx.beginPath()
    ctx.arc(32, 32, 26, 0, Math.PI * 2)
    ctx.fill()
    // White rim so the bubble reads against any background.
    ctx.strokeStyle = 'rgba(255,255,255,0.8)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.arc(32, 32, 26, 0, Math.PI * 2)
    ctx.stroke()
    // Top-left highlight (same idea as the heart highlight).
    ctx.fillStyle = 'rgba(255,255,255,0.9)'
    ctx.beginPath()
    ctx.ellipse(23, 20, 5, 3.5, -0.6, 0, Math.PI * 2)
    ctx.fill()
  }
  const texture = new CanvasTexture(canvas)
  texture.minFilter = LinearFilter
  texture.magFilter = LinearFilter
  bubbleTexture = texture
  return texture
}

/** Parse an SVG path into sample points. */
function sampleSvgPath(d: string, stepsPerSegment = 40): Array<{ x: number; y: number }> {
  const toks = d.match(/[MLCZ]|[-+]?\d*\.?\d+(?:e[-+]?\d+)?/gi)
  if (toks === null) return []
  let i = 0
  let x = 0
  let y = 0
  const pts: Array<{ x: number; y: number }> = []
  const num = (): number => parseFloat(toks[i++])
  const bez = (t: number, p0: number, p1: number, p2: number, p3: number): number => {
    const mt = 1 - t
    return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3
  }
  while (i < toks.length) {
    const c = toks[i++].toUpperCase()
    if (c === 'M' || c === 'L') {
      x = num()
      y = num()
      pts.push({ x, y })
    } else if (c === 'C') {
      const c1x = num(), c1y = num(), c2x = num(), c2y = num(), ex = num(), ey = num()
      for (let s = 1; s <= stepsPerSegment; s++) {
        const t = s / stepsPerSegment
        pts.push({ x: bez(t, x, c1x, c2x, ex), y: bez(t, y, c1y, c2y, ey) })
      }
      x = ex
      y = ey
    }
  }
  return pts
}

/** Catmull-Rom resample for a dense, evenly spaced contour. */
function catmullRomResample(points: Array<{ x: number; y: number }>, targetCount: number): Array<{ x: number; y: number }> {
  const n = points.length
  if (n < 2) return points
  const src = [...points, points[0], points[1], points[2]]
  const arcLen = [0]
  for (let i = 1; i < src.length; i++) {
    const dx = src[i].x - src[i - 1].x
    const dy = src[i].y - src[i - 1].y
    arcLen.push(arcLen[i - 1] + Math.sqrt(dx * dx + dy * dy))
  }
  const totalLen = arcLen[arcLen.length - 1]
  const result: Array<{ x: number; y: number }> = []
  for (let k = 0; k < targetCount; k++) {
    const t = (k / targetCount) * totalLen
    let seg = 0
    while (seg < arcLen.length - 2 && arcLen[seg + 1] < t) seg++
    const localT = (arcLen[seg + 1] - arcLen[seg]) > 0 ? (t - arcLen[seg]) / (arcLen[seg + 1] - arcLen[seg]) : 0
    const p0 = src[Math.max(0, seg - 1)], p1 = src[seg], p2 = src[seg + 1], p3 = src[Math.min(src.length - 1, seg + 2)]
    const tt = localT, tt2 = tt * tt, tt3 = tt2 * tt
    result.push({
      x: 0.5 * ((2 * p1.x) + (-p0.x + p2.x) * tt + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * tt2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * tt3),
      y: 0.5 * ((2 * p1.y) + (-p0.y + p2.y) * tt + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * tt2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * tt3),
    })
  }
  return result
}

/** Build the swept body geometry from a closed contour. */
function buildSwept(poly: Array<{ x: number; y: number }>): { geometry: BufferGeometry; swept: { xs: number[]; mid: number[]; rad: number[] } } {
  let minX = 1e9
  let maxX = -1e9
  let polyMinY = Infinity
  let polyMaxY = -Infinity
  for (const p of poly) {
    minX = Math.min(minX, p.x)
    maxX = Math.max(maxX, p.x)
    polyMinY = Math.min(polyMinY, p.y)
    polyMaxY = Math.max(polyMaxY, p.y)
  }
  const totalX = maxX - minX
  const step = totalX / MODEL.SWEPT_SLICES
  const polyHeight = polyMaxY - polyMinY
  const tailLiftAmount = 0.1 * polyHeight
  const xs: number[] = []
  const midRaw: number[] = []
  const radRaw: number[] = []
  let lastM = 0
  for (let s = 0; s <= MODEL.SWEPT_SLICES; s++) {
    const x = minX + s * step
    let top = -Infinity
    let bot = Infinity
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i]
      const b = poly[(i + 1) % poly.length]
      if (Math.abs(a.x - b.x) < 1e-9) continue
      if ((a.x - x) * (b.x - x) > 0) continue
      const y = a.y + (x - a.x) / (b.x - a.x) * (b.y - a.y)
      if (y > top) top = y
      if (y < bot) bot = y
    }
    let m: number
    let r: number
    if (Number.isFinite(top) && Number.isFinite(bot)) {
      m = (top + bot) / 2
      r = (top - bot) / 2
      if (r < 0) r = 0
      lastM = m
    } else {
      m = lastM
      r = 0
    }
    xs.push(x)
    midRaw.push(m)
    radRaw.push(Math.max(0, r))
  }

  const smooth = (arr: number[], sigma: number, iterations: number): number[] => {
    const len = arr.length
    const half = Math.ceil(sigma * 3)
    const kernel: number[] = []
    let sumK = 0
    for (let j = -half; j <= half; j++) {
      const val = Math.exp(-0.5 * (j / sigma) * (j / sigma))
      kernel.push(val)
      sumK += val
    }
    for (let i = 0; i < kernel.length; i++) kernel[i] /= sumK
    let work = [...arr]
    for (let iter = 0; iter < iterations; iter++) {
      const temp = [...work]
      for (let i = 0; i < len; i++) {
        let sum = 0
        for (let j = -half; j <= half; j++) {
          const idx = Math.min(len - 1, Math.max(0, i + j))
          sum += temp[idx] * kernel[j + half]
        }
        work[i] = sum
      }
    }
    return work
  }

  const removeDents = (arr: number[], window = 10): number[] => {
    const res = [...arr]
    for (let i = 1; i < res.length - 1; i++) {
      const left = Math.max(0, i - window)
      const right = Math.min(res.length - 1, i + window)
      let minNeighbor = Infinity
      for (let j = left; j <= right; j++) {
        if (j === i) continue
        if (res[j] < minNeighbor) minNeighbor = res[j]
      }
      if (res[i] < minNeighbor) res[i] = minNeighbor
    }
    return res
  }

  const smoothstep = (edge0: number, edge1: number, x: number): number => {
    const t = Math.min(1, Math.max(0, (x - edge0) / (edge1 - edge0)))
    return t * t * (3 - 2 * t)
  }

  let radSmooth = smooth(radRaw, 3, 2)
  const midSmooth = smooth(midRaw, 2, 1)
  radSmooth = removeDents(radSmooth, 8)
  radSmooth = smooth(radSmooth, 1.5, 1)
  let maxIdx = 0
  let maxVal = 0
  for (let i = 0; i < radSmooth.length; i++) {
    if (radSmooth[i] > maxVal) { maxVal = radSmooth[i]; maxIdx = i }
  }
  for (let i = maxIdx - 1; i >= 0; i--) {
    if (radSmooth[i] > radSmooth[i + 1]) radSmooth[i] = radSmooth[i + 1]
  }
  for (let i = maxIdx + 1; i < radSmooth.length; i++) {
    if (radSmooth[i] > radSmooth[i - 1]) radSmooth[i] = radSmooth[i - 1]
  }
  const tailRatio = 0.14
  const headRatio = 0.11
  const tailLen = totalX * tailRatio
  const headLen = totalX * headRatio
  const tailEnd = xs.findIndex(x => x >= minX + tailLen)
  if (tailEnd > 2) {
    const rBody = radSmooth[tailEnd]
    for (let i = 0; i <= tailEnd; i++) {
      const t = (xs[i] - minX) / tailLen
      const ease = 1 - Math.pow(1 - Math.min(1, Math.max(0, t)), 3)
      radSmooth[i] = Math.min(radSmooth[i], rBody * ease)
    }
  }
  const headStart = xs.findIndex(x => x >= maxX - headLen)
  if (headStart < MODEL.SWEPT_SLICES - 2) {
    const rBody = radSmooth[headStart]
    for (let i = headStart; i <= MODEL.SWEPT_SLICES; i++) {
      const t = (maxX - xs[i]) / headLen
      const ease = 1 - Math.pow(1 - Math.min(1, Math.max(0, t)), 3)
      radSmooth[i] = Math.min(radSmooth[i], rBody * ease)
    }
  }
  radSmooth[0] = 0
  radSmooth[MODEL.SWEPT_SLICES] = 0
  const tailLiftStartFrac = 0.75
  for (let i = 0; i <= MODEL.SWEPT_SLICES; i++) {
    const t = (xs[i] - minX) / totalX
    if (t > tailLiftStartFrac) {
      midSmooth[i] += tailLiftAmount * smoothstep(tailLiftStartFrac, 1, t)
    }
  }

  const pos: number[] = []
  for (let s = 0; s <= MODEL.SWEPT_SLICES; s++) {
    for (let k = 0; k < MODEL.SWEPT_RINGS; k++) {
      const th = (k / MODEL.SWEPT_RINGS) * Math.PI * 2
      const c = Math.cos(th)
      const sn = Math.sin(th)
      pos.push(xs[s], midSmooth[s] + radSmooth[s] * c, radSmooth[s] * sn)
    }
  }
  const idx: number[] = []
  for (let s = 0; s < MODEL.SWEPT_SLICES; s++) {
    for (let k = 0; k < MODEL.SWEPT_RINGS; k++) {
      const k2 = (k + 1) % MODEL.SWEPT_RINGS
      const a = s * MODEL.SWEPT_RINGS + k
      const b = s * MODEL.SWEPT_RINGS + k2
      const c2 = (s + 1) * MODEL.SWEPT_RINGS + k
      const d = (s + 1) * MODEL.SWEPT_RINGS + k2
      idx.push(a, d, c2, a, b, d)
    }
  }
  const geometry = new BufferGeometry()
  geometry.setAttribute('position', new Float32BufferAttribute(pos, 3))
  geometry.setIndex(idx)
  return { geometry, swept: { xs, mid: midSmooth, rad: radSmooth } }
}

/** Encode a float32 as a float16 bit pattern (three 0.147 has no DataUtils). */
function toHalfFloat(value: number): number {
  const floatView = new DataView(new ArrayBuffer(4))
  floatView.setFloat32(0, value)
  const bits = floatView.getUint32(0)
  // IEEE 754 half-float conversion (round-to-nearest).
  const sign = (bits >>> 16) & 0x8000
  let exponent = ((bits >>> 23) & 0xff) - 127 + 15
  let mantissa = bits & 0x7fffff
  if (exponent <= 0) {
    // Subnormal or zero.
    if (exponent < -10) return sign
    mantissa = (mantissa | 0x800000) >> (1 - exponent)
    return sign | ((mantissa + 0x1000) >> 13)
  }
  if (exponent >= 31) {
    return sign | 0x7c00 // infinity / NaN
  }
  return sign | (exponent << 10) | ((mantissa + 0x1000) >> 13)
}

/** Extrude a 2D polygon into a thin 3D slab. */
function extrudePolygon3D(
  points2D: Array<{ x: number; y: number }>,
  thickness: number,
  origin: Vector3,
  axisX: Vector3,
  axisY: Vector3,
): BufferGeometry {
  const n = points2D.length
  const h = thickness / 2
  const axisZ = new Vector3().crossVectors(axisX, axisY).normalize()
  const tri = ShapeUtils.triangulateShape(points2D.map(p => new Vector2(p.x, p.y)), [])
  const pos: number[] = []
  for (const p of points2D) {
    const v = new Vector3().copy(origin).addScaledVector(axisX, p.x).addScaledVector(axisY, p.y).addScaledVector(axisZ, h)
    pos.push(v.x, v.y, v.z)
  }
  for (const p of points2D) {
    const v = new Vector3().copy(origin).addScaledVector(axisX, p.x).addScaledVector(axisY, p.y).addScaledVector(axisZ, -h)
    pos.push(v.x, v.y, v.z)
  }
  const idx: number[] = []
  for (const t of tri) idx.push(t[0], t[1], t[2])
  for (const t of tri) idx.push(n + t[0], n + t[2], n + t[1])
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n
    idx.push(i, j, n + j, i, n + j, n + i)
  }
  const geom = new BufferGeometry()
  geom.setAttribute('position', new Float32BufferAttribute(pos, 3))
  geom.setIndex(idx)
  geom.computeVertexNormals()
  return geom
}

/** The assembled whale model plus animation references. */
interface WhaleRig {
  model: Group
  tail: Group | undefined
  pecPivots: Group[]
  eyeGroup: Group | undefined
  eyeMats: MeshBasicMaterial[]
  bodyGeo: BufferGeometry
  disposables: BufferGeometry[]
  /** Head crown anchor (top of the body above the eye), model-local units. */
  headAnchor: Vector3
}

/** Build the full whale model rig. */
function buildWhaleRig(): WhaleRig {
  const disposables: BufferGeometry[] = []

  // Body contour: sample the SVG, center it, normalize orientation.
  const raw = sampleSvgPath(BODY_PATH, 24)
  const dense = catmullRomResample(raw, 400)
  let cx = 0
  let cy = 0
  for (const p of dense) { cx += p.x; cy += p.y }
  cx /= dense.length
  cy /= dense.length
  const pts = dense.map(p => ({ x: (p.x - cx) * 1.1, y: -(p.y - cy) }))
  if (ShapeUtils.isClockWise(pts.map(p => new Vector2(p.x, p.y)))) pts.reverse()

  const { geometry: bodyGeo, swept } = buildSwept(pts)
  bodyGeo.computeVertexNormals()
  bodyGeo.computeBoundingBox()
  const size = bodyGeo.boundingBox?.getSize(new Vector3()) ?? new Vector3(1, 1, 1)
  const scale = MODEL.BODY_TARGET_HEIGHT / size.y
  bodyGeo.scale(scale, scale, scale)
  const sweptScaled = {
    xs: swept.xs.map(v => v * scale),
    mid: swept.mid.map(v => v * scale),
    rad: swept.rad.map(v => v * scale),
  }
  disposables.push(bodyGeo)

  // Shader material with the logo eye-mark pattern.
  const mrData = new Uint16Array(sweptScaled.mid.length * 2)
  for (let i = 0; i < sweptScaled.mid.length; i++) {
    mrData[i * 2] = toHalfFloat(sweptScaled.mid[i])
    mrData[i * 2 + 1] = toHalfFloat(sweptScaled.rad[i])
  }
  const mrTex = new DataTexture(mrData, sweptScaled.mid.length, 1, RGFormat, HalfFloatType)
  mrTex.minFilter = mrTex.magFilter = LinearFilter
  mrTex.needsUpdate = true
  const bb = bodyGeo.boundingBox
  const material = new MeshBasicMaterial({ side: DoubleSide })
  material.onBeforeCompile = (sh): void => {
    sh.uniforms.uMR = { value: mrTex }
    sh.uniforms.uMin = { value: bb?.min.x ?? 0 }
    sh.uniforms.uMax = { value: bb?.max.x ?? 1 }
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vPos;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvPos = position;')
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>',
        '#include <common>\nvarying vec3 vPos;\nuniform sampler2D uMR;\nuniform float uMin, uMax;')
      .replace('#include <color_fragment>', `#include <color_fragment>
      {
        // 腹部白色图案（参考原版实现）：沿 x 方向一个大椭圆白色区域，
        // 头部（u 小）更宽，尾部有一个小凸起。ang=0 是背部，π 是腹部。
        float u = clamp((vPos.x - uMin) / (uMax - uMin), 0.0, 1.0);
        float midY = texture2D(uMR, vec2(u, 0.5)).r;
        float ang = 3.14159265 - abs(atan(vPos.z, vPos.y - midY));

        float baseScale = 0.77 * 1.1;
        float uCenter = 0.28;
        float uHalf = 0.245 * baseScale;
        float angMax = 0.84 * baseScale;

        // 头部区域白色更宽
        float headFactor = 1.0 - smoothstep(0.18, 0.52, u);
        float angMaxAdjusted = angMax * (1.0 + 0.7 * headFactor);

        float uu = (0.16 + 0.49 * u - uCenter) / uHalf;
        float nn = ang / angMaxAdjusted;
        float rr = uu * uu + nn * nn;

        // 尾部区域小凸起
        float tailZone = smoothstep(0.40, 0.58, u) * (1.0 - smoothstep(0.80, 0.86, u));
        float peak = 0.78;
        float bumpWidth = 0.11;
        float bumpStrength = 1.0;
        float d = nn - peak;
        float bump = tailZone * bumpStrength * exp(-d * d / (bumpWidth * bumpWidth));
        float threshold = 1.0 + bump;

        float aa = fwidth(rr) * 1.2 + 2e-4;
        float a = 1.0 - smoothstep(threshold - aa, threshold + aa, rr);
        diffuseColor.rgb = mix(vec3(0.302, 0.420, 0.996), vec3(1.0), a);
      }`)
  }
  const model = new Group()
  const bodyMesh = new Mesh(bodyGeo, material)
  model.add(bodyMesh)

  // Brow + eye mapping helper (uses the scaled swept data).
  const mapToSurface = (px: number, py: number): { x: number; y: number; z: number } => {
    const xsArr = sweptScaled.xs
    const midArr = sweptScaled.mid
    const radArr = sweptScaled.rad
    const n = xsArr.length
    let s: number
    if (px <= xsArr[0]) s = 0
    else if (px >= xsArr[n - 1]) s = n - 1
    else {
      let i = 0
      while (i < n - 1 && xsArr[i + 1] < px) i++
      s = i + (px - xsArr[i]) / Math.max(1e-9, xsArr[i + 1] - xsArr[i])
    }
    const i0 = Math.min(Math.floor(s), n - 1)
    const i1 = Math.min(i0 + 1, n - 1)
    const t = s - i0
    const m = midArr[i0] * (1 - t) + midArr[i1] * t
    const r = Math.max(0, radArr[i0] * (1 - t) + radArr[i1] * t)
    const cosTh = r > 1e-6 ? Math.max(-1, Math.min(1, (py - m) / r)) : 1
    const sinTh = Math.sqrt(Math.max(0, 1 - cosTh * cosTh))
    const dx = Math.max(1e-9, xsArr[i1] - xsArr[i0])
    const dr = (radArr[i1] - radArr[i0]) / dx
    const dm = (midArr[i1] - midArr[i0]) / dx
    const nx = -(dr + dm * cosTh)
    const ny = cosTh
    const nz = sinTh
    const len = Math.hypot(nx, ny, nz) || 1
    // BROW_LIFT is specified in the original (unscaled) body space; the
    // swept data here is already scaled, so the outward lift must be scaled
    // too — otherwise the eye-mark floats far off the surface (a literal
    // "eyes beside the body" look).
    const lift = MODEL.BROW_LIFT * scale
    return {
      x: px + nx / len * lift,
      y: m + r * cosTh + ny / len * lift,
      z: r * sinTh + nz / len * lift,
    }
  }

  // The swept body (sweptScaled) is built from points scaled by 1.1 on x
  // (body width stretch) and -1 on y (flip), then by `scale`. The brow/eye
  // SVG contour lives in the original space; replicate the same transform
  // chain before interpolating against sweptScaled — otherwise the eye-mark
  // x positions drift off the body (visible as a misaligned white patch).
  const scaledPoint = (p: { x: number; y: number }): { x: number; y: number } => ({
    x: (((p.x - cx) * MODEL.BROW_SCALE + MODEL.BROW_OFFSET_X) * 1.1) * scale,
    y: ((-(p.y - cy) * MODEL.BROW_SCALE + MODEL.BROW_OFFSET_Y)) * scale,
  })

  const buildSurfaceMesh = (contour: Array<{ x: number; y: number }>, flip: boolean, offset: { x: number; y: number }): BufferGeometry => {
    const pos: number[] = []
    const tri = ShapeUtils.triangulateShape(
      contour.map(p => new Vector2((p.x - cx) * MODEL.BROW_SCALE + offset.x, -(p.y - cy) * MODEL.BROW_SCALE + offset.y)),
      [],
    )
    for (const p of contour) {
      const sp = mapToSurface(scaledPoint(p).x, scaledPoint(p).y)
      pos.push(sp.x, sp.y, sp.z)
    }
    const idx: number[] = []
    for (const t of tri) idx.push(t[0], t[1], t[2])
    const g = new BufferGeometry()
    g.setAttribute('position', new Float32BufferAttribute(pos, 3))
    g.setIndex(idx)
    if (flip) {
      const arr = g.attributes.position.array as Float32Array
      for (let i = 2; i < arr.length; i += 3) arr[i] = -arr[i]
    }
    disposables.push(g)
    return g
  }

  const browSvg = sampleSvgPath(BROW_PATH, 20)
  const browMat = new MeshBasicMaterial({
    color: MODEL.COLOR_WHITE, side: DoubleSide,
    polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
  })
  const browGroup = new Group()
  browGroup.add(new Mesh(buildSurfaceMesh(browSvg, false, { x: MODEL.BROW_OFFSET_X, y: MODEL.BROW_OFFSET_Y }), browMat))
  browGroup.add(new Mesh(buildSurfaceMesh(browSvg, true, { x: MODEL.BROW_OFFSET_X, y: MODEL.BROW_OFFSET_Y }), browMat))
  model.add(browGroup)

  // Eye. Two white discs, one per side of the head (flip z). Sized relative
  // to the body so they read as eyes, not invisible specks.
  const dentPoint = browSvg.reduce((prev, curr) => (curr.y < prev.y ? curr : prev), browSvg[0])
  const eyeCenterX = dentPoint.x - 2
  const eyeCenterY = dentPoint.y + MODEL.EYE_OFFSET_Y
  const circlePoints: Array<{ x: number; y: number }> = []
  for (let i = 0; i < MODEL.EYE_CIRCLE_SEGMENTS; i++) {
    const angle = (i / MODEL.EYE_CIRCLE_SEGMENTS) * Math.PI * 2
    circlePoints.push({ x: eyeCenterX + MODEL.EYE_RADIUS * Math.cos(angle), y: eyeCenterY + MODEL.EYE_RADIUS * Math.sin(angle) })
  }
  const eyeMat = new MeshBasicMaterial({
    color: MODEL.COLOR_WHITE, side: DoubleSide,
    polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3,
    transparent: true, opacity: 1,
  })
  const eyeGroup = new Group()
  eyeGroup.add(new Mesh(buildSurfaceMesh(circlePoints, false, { x: MODEL.BROW_OFFSET_X, y: MODEL.BROW_OFFSET_Y }), eyeMat))
  eyeGroup.add(new Mesh(buildSurfaceMesh(circlePoints, true, { x: MODEL.BROW_OFFSET_X, y: MODEL.BROW_OFFSET_Y }), eyeMat))
  model.add(eyeGroup)

  // Head crown anchor: the top of the body surface directly above the eye
  // centre, in model-local units. Hearts spawn here as model children so
  // they follow the whale through every rotation.
  const eyeScaled = scaledPoint({ x: eyeCenterX, y: eyeCenterY })
  const xsArrH = sweptScaled.xs
  const midArrH = sweptScaled.mid
  const radArrH = sweptScaled.rad
  let sH: number
  if (eyeScaled.x <= xsArrH[0]) sH = 0
  else if (eyeScaled.x >= xsArrH[xsArrH.length - 1]) sH = xsArrH.length - 1
  else {
    let iH = 0
    while (iH < xsArrH.length - 1 && xsArrH[iH + 1] < eyeScaled.x) iH++
    sH = iH + (eyeScaled.x - xsArrH[iH]) / Math.max(1e-9, xsArrH[iH + 1] - xsArrH[iH])
  }
  const iH0 = Math.min(Math.floor(sH), xsArrH.length - 1)
  const iH1 = Math.min(iH0 + 1, xsArrH.length - 1)
  const tH = sH - iH0
  const mH = midArrH[iH0] * (1 - tH) + midArrH[iH1] * tH
  const rH = Math.max(0, radArrH[iH0] * (1 - tH) + radArrH[iH1] * tH)
  const headAnchor = new Vector3(eyeScaled.x, mH + rH, 0)

  // Tail fin.
  const tailSvgPts = sampleSvgPath(TAIL_PATH, 24)
  const bodyTipX = sweptScaled.xs[sweptScaled.xs.length - 1]
  const bodyTipY = sweptScaled.mid[sweptScaled.mid.length - 1]
  const openAng = MODEL.TAIL_OPEN_ANGLE_DEG * Math.PI / 180
  const oc = Math.cos(openAng)
  const os = Math.sin(openAng)
  const TAIL_NOTCH = { x: 21.873, y: 5.441 }
  const finPts = tailSvgPts.map(p => {
    const lx = (p.x - TAIL_NOTCH.x) * MODEL.TAIL_FORK_SCALE
    const ly = -(p.y - TAIL_NOTCH.y) * MODEL.TAIL_FORK_SCALE
    return { x: lx * oc + ly * os, z: -lx * os + ly * oc }
  })
  const buildLeaf = (contour2D: Array<{ x: number; z: number }>, thickness: number): BufferGeometry => {
    const n = contour2D.length
    const h = thickness / 2
    const tri = ShapeUtils.triangulateShape(contour2D.map(p => new Vector2(p.x, p.z)), [])
    const pos: number[] = []
    for (const p of contour2D) pos.push(p.x, h, p.z)
    for (const p of contour2D) pos.push(p.x, -h, p.z)
    const idx: number[] = []
    for (const t of tri) idx.push(t[0], t[1], t[2])
    for (const t of tri) idx.push(n + t[0], n + t[2], n + t[1])
    for (let i = 0; i < n; i++) {
      const a = i
      const b = (i + 1) % n
      idx.push(a, b, n + b, a, n + b, n + a)
    }
    const geom = new BufferGeometry()
    geom.setAttribute('position', new Float32BufferAttribute(pos, 3))
    geom.setIndex(idx)
    geom.computeVertexNormals()
    disposables.push(geom)
    return geom
  }
  const tailMat = new MeshBasicMaterial({ color: MODEL.COLOR_BODY_BLUE, side: DoubleSide })
  const tailGroup = new Group()
  const closedFin = [...finPts, { x: finPts[0].x, z: finPts[0].z }]
  const leftGeom = buildLeaf(closedFin, MODEL.TAIL_THICKNESS)
  tailGroup.add(new Mesh(leftGeom, tailMat))
  const rightMesh = new Mesh(leftGeom.clone(), tailMat)
  rightMesh.scale.z = -1
  tailGroup.add(rightMesh)
  model.add(tailGroup)
  tailGroup.position.set(bodyTipX + MODEL.TAIL_NOTCH_DX, bodyTipY + MODEL.TAIL_NOTCH_DY, 0)
  tailGroup.rotation.z = MODEL.TAIL_TILT_DEG * Math.PI / 180

  // Dorsal fin.
  const dorsalSvg = sampleSvgPath(DORSAL_PATH, MODEL.DORSAL_SAMPLES)
  const DORSAL_BL = 10.436
  const DORSAL_BR = 13.852
  const backSurfaceAt = (frac: number): { x: number; top: number } => {
    const xsArr = sweptScaled.xs
    const midArr = sweptScaled.mid
    const radArr = sweptScaled.rad
    const totalX = xsArr[xsArr.length - 1] - xsArr[0]
    const x = xsArr[0] + totalX * frac
    let idx = 0
    while (idx < xsArr.length - 1 && xsArr[idx + 1] < x) idx++
    const t = (x - xsArr[idx]) / (xsArr[idx + 1] - xsArr[idx] || 1)
    const mid = midArr[idx] * (1 - t) + midArr[idx + 1] * t
    const rad = radArr[idx] * (1 - t) + radArr[idx + 1] * t
    return { x, top: mid + rad }
  }
  const by0 = backSurfaceAt(MODEL.DORSAL_START_FRAC).top
  const by1 = backSurfaceAt(MODEL.DORSAL_END_FRAC).top
  const dorsalPts = dorsalSvg.map(p => {
    const u = (p.x - DORSAL_BL) / (DORSAL_BR - DORSAL_BL)
    const baseY = 2.993 + u * (4.746 - 2.993)
    const h = Math.max(0, (baseY - p.y) * MODEL.DORSAL_HEIGHT_SCALE)
    const frac = MODEL.DORSAL_START_FRAC + u * (MODEL.DORSAL_END_FRAC - MODEL.DORSAL_START_FRAC)
    const xsArr = sweptScaled.xs
    const px = xsArr[0] + (xsArr[xsArr.length - 1] - xsArr[0]) * frac
    const py = by0 + u * (by1 - by0) + h
    return { x: px, y: py }
  })
  const dorsalMat = new MeshBasicMaterial({ color: MODEL.COLOR_BODY_BLUE, side: DoubleSide })
  const dorsalGeo = extrudePolygon3D(dorsalPts, MODEL.DORSAL_THICKNESS, new Vector3(0, 0, 0), new Vector3(1, 0, 0), new Vector3(0, 1, 0))
  disposables.push(dorsalGeo)
  model.add(new Mesh(dorsalGeo, dorsalMat))

  // Pectoral fins (pivots for flapping).
  const pecSvg = sampleSvgPath(PEC_PATH, 16)
  const PEC_BL = 16.747
  const PEC_BR = 20.614
  const PEC_DROP = 0.288
  const pecMat = new MeshBasicMaterial({ color: MODEL.COLOR_BODY_BLUE, side: DoubleSide })
  const pecAngle = MODEL.PEC_RADIAN * Math.PI / 180
  const pecPivots: Group[] = []
  for (const side of [1, -1]) {
    const s0 = backSurfaceAt(MODEL.PEC_START_FRAC)
    const s1 = backSurfaceAt(MODEL.PEC_END_FRAC)
    const r0 = s0.top - MODEL.PEC_OUTWARD_OFFSET
    const r1 = s1.top - MODEL.PEC_OUTWARD_OFFSET
    const Rh = new Vector3(s0.x, r0 * Math.cos(pecAngle), side * (r0 * Math.sin(pecAngle) + MODEL.PEC_OUTWARD_OFFSET))
    const Rt = new Vector3(s1.x, r1 * Math.cos(pecAngle), side * (r1 * Math.sin(pecAngle) + MODEL.PEC_OUTWARD_OFFSET))
    const rootLen = Rh.distanceTo(Rt)
    const axisX = new Vector3().subVectors(Rt, Rh).normalize()
    const outRaw = new Vector3(0, -Math.sin(MODEL.PEC_ANGLE_DEG * Math.PI / 180), side * Math.cos(MODEL.PEC_ANGLE_DEG * Math.PI / 180))
    const axisY = outRaw.clone().addScaledVector(axisX, -outRaw.dot(axisX)).normalize()
    const pec2D = pecSvg.map(p => {
      const u = (p.x - PEC_BL) / (PEC_BR - PEC_BL)
      const baseY = 19.267 + u * (19.565 - 19.267)
      const w = Math.max(0, (p.y - baseY) / PEC_DROP)
      return { x: u * rootLen + w * MODEL.PEC_SWEEP, y: w * MODEL.PEC_SPAN }
    })
    const finGeom = extrudePolygon3D(pec2D, MODEL.PEC_THICKNESS, new Vector3(0, 0, 0), axisX, axisY)
    disposables.push(finGeom)
    const finMesh = new Mesh(finGeom, pecMat)
    const pivot = new Group()
    pivot.position.copy(Rh)
    pivot.add(finMesh)
    model.add(pivot)
    pecPivots.push(pivot)
  }

  return {
    model,
    tail: tailGroup,
    pecPivots,
    eyeGroup,
    eyeMats: [eyeMat],
    bodyGeo,
    disposables,
    headAnchor,
  }
}

/** A running whale pet scene. */
export interface WhaleSceneHandle {
  /** The rendered canvas element (transparent background). */
  canvas: HTMLCanvasElement
  /** Apply an incremental yaw rotation (radians) for drag-rotate. */
  rotateYaw(delta: number): void
  /** Apply an incremental pitch rotation (radians) for vertical look. */
  rotatePitch(delta: number): void
  /** Reset the accumulated rotation to the identity. */
  resetRotation(): void
  /** Trigger a jump bounce (double-click). */
  jump(): void
  /** Trigger a 360° front somersault on the world X axis (message send). */
  flip(): void
  /** Spawn a heart burst at the head crown (single click). */
  burstHearts(): void
  /** Spawn a bubble burst at the head crown. */
  burstBubbles(): void
  /** Pause the idle animation loop. */
  pause(): void
  /** Resume the idle animation loop. */
  resume(): void
  /** Release all WebGL resources and remove the canvas. */
  dispose(): void
}

/**
 * Create the whale scene inside a container element.
 * @param container - the DOM element the canvas is appended to.
 * @returns the scene handle.
 */
export function createWhaleScene(container: HTMLElement): WhaleSceneHandle {
  const scene = new Scene()
  const camera = new PerspectiveCamera(42, 1, 0.1, 100)
  // t19: 正侧面平视视角（用户要求：不要斜上方俯视）。
  camera.position.set(0, 0, 6)
  camera.lookAt(0, 0, 0)
  const renderer = new WebGLRenderer({ antialias: true, alpha: true })
  renderer.setClearColor(0x000000, 0) // transparent background
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  container.appendChild(renderer.domElement)

  const rig = buildWhaleRig()
  scene.add(rig.model)

  // t11: 相机按模型包围盒自动适配——整只虎鲸（含尾鳍/胸鳍摆动、跳跃、翻转
  // 抬升等动画余量）完整入框并留边距，任何姿态都不被画布边缘裁切。
  const fitCamera = (): void => {
    rig.model.updateMatrixWorld(true)
    const box = new Box3().setFromObject(rig.model)
    // 动画余量：flip 抬升峰值 ~1.6、跳跃 ~0.25、尾鳍/胸鳍摆动；四周再留 0.2。
    box.min.y -= 0.3
    box.max.y += 1.6
    box.expandByScalar(0.2)
    const center = box.getCenter(new Vector3())
    const radius = box.getBoundingSphere(new Sphere()).radius
    const fovRad = (camera.fov * Math.PI) / 180
    // 方形画布（aspect=1）水平/垂直 FOV 相同，球体半径约束即可；15% 边距
    // （模型约占画布 55% 高度，既完整入框又不会显得过小）。
    const distance = (radius / Math.sin(fovRad / 2)) * 1.15
    // t19: 侧面视角，相机与鲸鱼同高（y=0），不做俯视。
    const dir = new Vector3(0, 0, 1)
    camera.position.copy(center).addScaledVector(dir, distance)
    camera.lookAt(center)
    camera.near = Math.max(0.1, distance - radius * 2)
    camera.far = distance + radius * 2
    camera.updateProjectionMatrix()
  }
  fitCamera()
  // t13: 画幅缩小后放大模型补偿（见 FRAME_COMPENSATION）；动画位移
  // （翻转/跳跃/浮动）是世界坐标偏移、不随模型缩放，相对鲸鱼更紧凑。
  rig.model.scale.setScalar(FRAME_COMPENSATION)

  let running = true
  let raf = 0
  const clock = new Clock()
  let elapsed = 0
  // t11: 空闲降帧——循环动画（呼吸/摆动）无需每帧绘制；悬停/拖拽/粒子/
  // 跳跃/翻转期间恢复全帧率。动画状态每帧照常更新，仅跳过 WebGL 绘制。
  let frameCounter = 0
  const RENDER_EVERY_N_FRAMES = 3

  // Heart/bubble sprites live as model children (they follow the whale's
  // rotation). One array holds both; each particle carries its own lifetime
  // and base size so the update loop is shared.
  interface Love {
    sprite: Sprite
    material: SpriteMaterial
    birth: number
    vx: number
    vy: number
    vz: number
    lifetime: number
    baseSize: number
  }
  const loves: Love[] = []

  // Drag feel (ported from the original demo): cursor hover boosts the swim
  // rate, the whale tilts toward the cursor, and a release keeps the drag
  // momentum spinning down (OrbitControls-style damping).
  const raycaster = new Raycaster()
  const mouseNDC = new Vector2()
  let isHovering = false
  let pointerDragging = false
  let spinYaw = 0
  let spinPitch = 0
  let lastSpinT = 0
  const incQuat = new Quaternion()

  // User drag rotation accumulates in a quaternion (arcball style) instead
  // of Euler yaw/pitch: Euler angles get gimbal-locked and lose a rotation
  // degree of freedom once you pitch past ±90°, which reads as "stuck" or
  // "missing an axis" while dragging. A quaternion composes every drag
  // increment around the world axes without singularities.
  const userRotation = new Quaternion()
  const idleRotation = new Quaternion()
  const worldX = new Vector3(1, 0, 0)
  const worldY = new Vector3(0, 1, 0)
  const userQuat = new Quaternion()

  // Jump physics (double-click bounce).
  let jumpOffset = 0
  let jumpVelocity = 0
  let isJumping = false

  const JUMP_VELOCITY = 2.2
  const GRAVITY = 9.8

  // Flip (360° front somersault on the world X axis, message send). flipStart
  // is the elapsed-seconds timestamp of the flip start; -1 means not flipping.
  // The timestamp scheme is drop-frame safe: delta is clamped to 0.1 and
  // pause/resume discards the gap via clock.getDelta(), so elapsed stays the
  // single source of truth.
  let flipStart = -1
  const FLIP_DURATION = 0.9
  const FLIP_HEIGHT = 1.6
  const flipQuat = new Quaternion()

  const animate = (): void => {
    if (!running) return
    raf = requestAnimationFrame(animate)
    const delta = Math.min(clock.getDelta(), 0.1)
    elapsed += delta
    const t = elapsed

    const swimSpeed = MODEL.SWIM_SPEED * (isHovering ? MODEL.HOVER_SWIM_BOOST : 1)
    const bodySway = Math.sin(t * swimSpeed * Math.PI * 2) * MODEL.BODY_SWAY_AMPLITUDE
    const pitchSway = Math.sin(t * swimSpeed * Math.PI * 2 + 0.8) * MODEL.PITCH_AMPLITUDE
    const rollSway = Math.sin(t * swimSpeed * Math.PI * 1.1 + 0.3) * MODEL.ROLL_AMPLITUDE
    // Idle sway in Euler, then the user's arcball rotation on top:
    // rotation = userRotation * idleSway. Euler order XYZ applies X first,
    // so we build the idle quaternion from (pitchSway, bodySway, rollSway)
    // and multiply the accumulated drag on the left. The cursor tilts the
    // head slightly (skipped while dragging so it never fights the gesture).
    const yawBias = pointerDragging ? 0 : mouseNDC.x * MODEL.MOUSE_BIAS_MAX
    const pitchBias = pointerDragging ? 0 : -mouseNDC.y * MODEL.MOUSE_PITCH_BIAS
    idleRotation.setFromEuler(new Euler(pitchSway + pitchBias, bodySway + yawBias, rollSway))
    userQuat.copy(userRotation).multiply(idleRotation)
    // Flip rotates on top of (userRotation * idleRotation) around the world X
    // axis: premultiplying is a left-multiply, so the somersault reads as a
    // front flip facing the camera no matter what pose the user dragged the
    // whale into, and it never fights the drag momentum or idle sway below.
    // Flip rotates on top of (userRotation * idleRotation) around the world X
    // axis: premultiplying is a left-multiply, so the somersault reads as a
    // front flip facing the camera no matter what pose the user dragged the
    // whale into, and it never fights the drag momentum or idle sway below.
    if (flipStart >= 0) {
      const fp = Math.min(1, (elapsed - flipStart) / FLIP_DURATION)
      // t12: 方向修正——绕世界 X 轴负向旋转，虎鲸向前翻（前空翻），
      // 与视觉朝向一致；原先正方向是向后翻。
      flipQuat.setFromAxisAngle(worldX, -fp * Math.PI * 2)
      userQuat.premultiply(flipQuat)
      if (fp >= 1) flipStart = -1
    }
    rig.model.quaternion.copy(userQuat)

    // Rotation momentum: after the drag ends the spin decays exponentially
    // (OrbitControls-style damping factor).
    if (!pointerDragging) {
      const decay = Math.exp(-MODEL.DRAG_DECAY * delta)
      spinYaw *= decay
      spinPitch *= decay
      if (Math.abs(spinYaw) > 0.0004) {
        incQuat.setFromAxisAngle(worldY, spinYaw * delta)
        userRotation.premultiply(incQuat)
      } else {
        spinYaw = 0
      }
      if (Math.abs(spinPitch) > 0.0004) {
        incQuat.setFromAxisAngle(worldX, spinPitch * delta)
        userRotation.premultiply(incQuat)
      } else {
        spinPitch = 0
      }
    }

    if (rig.tail !== undefined) {
      rig.tail.rotation.y = Math.sin(t * swimSpeed * Math.PI * 2 + 0.7) * MODEL.TAIL_SWAY_AMPLITUDE
      rig.tail.rotation.x = Math.sin(t * swimSpeed * Math.PI * 2 + 1.2) * MODEL.TAIL_PITCH_AMPLITUDE
    }

    const pecFlap = Math.sin(t * swimSpeed * Math.PI * 2 + MODEL.PEC_FLAP_PHASE) * MODEL.PEC_FLAP_AMPLITUDE
    for (const pivot of rig.pecPivots) pivot.rotation.x = pecFlap

    // Jump physics: y offset on top of the float.
    if (isJumping) {
      jumpOffset += jumpVelocity * delta
      jumpVelocity -= GRAVITY * delta
      if (jumpOffset <= 0) {
        jumpOffset = 0
        jumpVelocity = 0
        isJumping = false
      }
    }
    // Flip vertical lift: sin(π·fp) arch adds and removes itself (0 at both
    // ends, peak 1.6 at fp=0.5 — exactly when the whale is head-down mid-flip),
    // additively on top of the float + jump so it can coincide with a jump.
    const flipProgress = flipStart >= 0 ? Math.min(1, (elapsed - flipStart) / FLIP_DURATION) : 0
    rig.model.position.y = Math.sin(t * MODEL.FLOAT_SPEED) * MODEL.FLOAT_AMPLITUDE + jumpOffset + Math.sin(flipProgress * Math.PI) * FLIP_HEIGHT

    // Sprites drift up from the head crown, pulse, and fade.
    for (let i = loves.length - 1; i >= 0; i--) {
      const love = loves[i]
      const age = elapsed - love.birth
      if (age >= love.lifetime) {
        rig.model.remove(love.sprite)
        love.material.dispose()
        loves.splice(i, 1)
        continue
      }
      const progress = age / love.lifetime
      love.sprite.position.x += love.vx * delta
      love.sprite.position.y += love.vy * delta
      love.sprite.position.z += love.vz * delta
      const scaleMul = 1 + 0.3 * Math.sin(progress * Math.PI)
      love.sprite.scale.setScalar(scaleMul * love.baseSize * (1 - 0.5 * progress))
      love.material.opacity = 1 - progress
    }

    // Blink.
    const cycle = t % MODEL.BLINK_INTERVAL
    if (cycle < MODEL.BLINK_DURATION) {
      const p = cycle / MODEL.BLINK_DURATION
      for (const mat of rig.eyeMats) {
        mat.opacity = p < 0.4 ? 1 - p / 0.4 : ((p - 0.4) / 0.6) ** 2 * (3 - 2 * (p - 0.4) / 0.6)
      }
      if (rig.eyeGroup !== undefined) {
        const squash = 1 - Math.sin(Math.min(p, 1) * Math.PI) * 0.35
        rig.eyeGroup.scale.set(1 + (1 - squash) * 0.3, squash, 1 + (1 - squash) * 0.3)
      }
    } else {
      for (const mat of rig.eyeMats) mat.opacity = 1
      if (rig.eyeGroup !== undefined) rig.eyeGroup.scale.set(1, 1, 1)
    }

    // t11: 空闲降帧渲染（每 3 帧绘制 1 次）；交互/粒子/动画期间全帧率。
    const interactiveNow = isHovering || pointerDragging || loves.length > 0
      || isJumping || flipStart >= 0
    frameCounter++
    if (!interactiveNow && frameCounter % RENDER_EVERY_N_FRAMES !== 0) return
    renderer.render(scene, camera)
  }

  const setSize = (): void => {
    const rect = container.getBoundingClientRect()
    const width = Math.max(1, Math.floor(rect.width))
    const height = Math.max(1, Math.floor(rect.height))
    renderer.setSize(width, height, false)
    camera.aspect = width / height
    camera.updateProjectionMatrix()
  }
  setSize()
  const resizeObserver = new ResizeObserver(() => { setSize() })
  resizeObserver.observe(container)

  // Hover + drag tracking. The canvas itself has pointer-events: none (hit
  // testing happens on the container), so listen on the container element.
  const hoverTarget = renderer.domElement.parentElement ?? renderer.domElement
  // t3: 悬停射线命中按帧节流——pointermove 频率远高于帧率，逐事件做全模型
  // 相交测试会卡顿（几何已精简，配合每帧最多一次命中，交互更跟手）。
  let hoverHitPending = false
  const onHoverMove = (event: PointerEvent): void => {
    const rect = hoverTarget.getBoundingClientRect()
    mouseNDC.x = ((event.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1
    mouseNDC.y = -((event.clientY - rect.top) / Math.max(1, rect.height)) * 2 + 1
    if (hoverHitPending) return
    hoverHitPending = true
    requestAnimationFrame(() => {
      hoverHitPending = false
      raycaster.setFromCamera(mouseNDC, camera)
      isHovering = raycaster.intersectObject(rig.model, true).length > 0
    })
  }
  const onHoverLeave = (): void => {
    isHovering = false
    mouseNDC.set(0, 0)
  }
  const onDragStart = (): void => { pointerDragging = true }
  const onDragEnd = (): void => { pointerDragging = false }
  hoverTarget.addEventListener('pointermove', onHoverMove)
  hoverTarget.addEventListener('pointerleave', onHoverLeave)
  hoverTarget.addEventListener('pointerdown', onDragStart)
  window.addEventListener('pointerup', onDragEnd)
  window.addEventListener('pointercancel', onDragEnd)

  animate()

  return {
    canvas: renderer.domElement,
    rotateYaw(delta: number): void {
      // Horizontal drag: rotate around the world Y axis (arcball increment);
      // track the angular velocity for the post-release momentum.
      const now = performance.now()
      const dt = Math.max(0.001, (now - lastSpinT) / 1000)
      lastSpinT = now
      spinYaw = delta / dt
      incQuat.setFromAxisAngle(worldY, delta)
      userRotation.premultiply(incQuat)
    },
    rotatePitch(delta: number): void {
      // Vertical drag: rotate around the world X axis (arcball increment).
      const now = performance.now()
      const dt = Math.max(0.001, (now - lastSpinT) / 1000)
      lastSpinT = now
      spinPitch = delta / dt
      incQuat.setFromAxisAngle(worldX, delta)
      userRotation.premultiply(incQuat)
    },
    resetRotation(): void {
      userRotation.identity()
    },
    jump(): void {
      if (!isJumping) {
        isJumping = true
        jumpVelocity = JUMP_VELOCITY
        jumpOffset = 0
      }
    },
    flip(): void {
      if (flipStart >= 0) return
      flipStart = elapsed
      // The flip celebrates with a heart burst at the head crown. The model
      // layer deliberately does not read the UI-level hearts toggle — that
      // gate lives in the WhalePet call site.
      this.burstHearts()
    },
    burstHearts(): void {
      const count = LOVE_CONFIG.COUNT_MIN + Math.floor(Math.random() * (LOVE_CONFIG.COUNT_MAX - LOVE_CONFIG.COUNT_MIN + 1))
      for (let i = 0; i < count; i++) {
        const material = new SpriteMaterial({
          map: getLoveTexture(),
          color: 0xffffff,
          transparent: true,
          opacity: 1,
          // 开启深度测试：爱心被鲸鱼本体遮挡（看腹部时爱心不再穿透显示）
          depthTest: true,
          depthWrite: false,
        })
        const sprite = new Sprite(material)
        sprite.position.set(
          rig.headAnchor.x + (Math.random() - 0.5) * LOVE_CONFIG.SCATTER_X,
          rig.headAnchor.y + LOVE_CONFIG.LIFT + Math.random() * LOVE_CONFIG.SCATTER_Y,
          (Math.random() - 0.5) * LOVE_CONFIG.SCATTER_Z,
        )
        sprite.scale.setScalar(LOVE_CONFIG.SIZE_MIN + Math.random() * LOVE_CONFIG.SIZE_VAR)
        rig.model.add(sprite)
        loves.push({
          sprite,
          material,
          birth: elapsed,
          vx: (Math.random() - 0.5) * LOVE_CONFIG.DRIFT,
          vy: LOVE_CONFIG.SPEED + Math.random() * 0.5,
          vz: (Math.random() - 0.5) * LOVE_CONFIG.DRIFT,
          lifetime: LOVE_CONFIG.LIFETIME,
          baseSize: LOVE_CONFIG.SIZE_MIN + Math.random() * LOVE_CONFIG.SIZE_VAR,
        })
      }
    },
    burstBubbles(): void {
      const count = BUBBLE_CONFIG.COUNT_MIN + Math.floor(Math.random() * (BUBBLE_CONFIG.COUNT_MAX - BUBBLE_CONFIG.COUNT_MIN + 1))
      for (let i = 0; i < count; i++) {
        const material = new SpriteMaterial({
          map: getBubbleTexture(),
          color: 0xffffff,
          transparent: true,
          opacity: 1,
          depthTest: true,
          depthWrite: false,
        })
        const sprite = new Sprite(material)
        sprite.position.set(
          rig.headAnchor.x + (Math.random() - 0.5) * BUBBLE_CONFIG.SCATTER_X,
          rig.headAnchor.y + BUBBLE_CONFIG.LIFT + Math.random() * BUBBLE_CONFIG.SCATTER_Y,
          (Math.random() - 0.5) * BUBBLE_CONFIG.SCATTER_Z,
        )
        sprite.scale.setScalar(BUBBLE_CONFIG.SIZE_MIN + Math.random() * BUBBLE_CONFIG.SIZE_VAR)
        rig.model.add(sprite)
        loves.push({
          sprite,
          material,
          birth: elapsed,
          vx: (Math.random() - 0.5) * BUBBLE_CONFIG.DRIFT,
          vy: BUBBLE_CONFIG.SPEED + Math.random() * 0.4,
          vz: (Math.random() - 0.5) * BUBBLE_CONFIG.DRIFT,
          lifetime: BUBBLE_CONFIG.LIFETIME,
          baseSize: BUBBLE_CONFIG.SIZE_MIN + Math.random() * BUBBLE_CONFIG.SIZE_VAR,
        })
      }
    },
    pause(): void {
      running = false
      cancelAnimationFrame(raf)
    },
    resume(): void {
      if (!running) {
        running = true
        clock.getDelta()
        // display:none 期间容器尺寸失效，恢复时先重测（隐藏期间 rAF 已暂停，
        // 不会再对 0 尺寸画布空转）。
        setSize()
        animate()
      }
    },
    dispose(): void {
      running = false
      cancelAnimationFrame(raf)
      resizeObserver.disconnect()
      for (const love of loves.splice(0)) {
        rig.model.remove(love.sprite)
        love.material.dispose()
      }
      hoverTarget.removeEventListener('pointermove', onHoverMove)
      hoverTarget.removeEventListener('pointerleave', onHoverLeave)
      hoverTarget.removeEventListener('pointerdown', onDragStart)
      window.removeEventListener('pointerup', onDragEnd)
      window.removeEventListener('pointercancel', onDragEnd)
      for (const geometry of rig.disposables) geometry.dispose()
      renderer.dispose()
      renderer.domElement.remove()
    },
  }
}
