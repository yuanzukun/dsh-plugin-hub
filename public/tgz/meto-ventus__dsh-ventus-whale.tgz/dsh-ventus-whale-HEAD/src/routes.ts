/**
 * The /api/ventus-whale route family: state read + config write. Loopback
 * fence like every other plugin API; the pet config is local user state.
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import { loadConfig, saveConfig } from './host.ts'
import { DEFAULT_CONFIG, type WhaleConfig } from './protocol.ts'

/** Cap on JSON request bodies. */
const MAX_JSON_BODY_BYTES = 16 * 1024

/** Loopback literal check plus browser same-origin markers. */
function isLoopbackRequest(request: IncomingMessage): boolean {
  const address = request.socket.remoteAddress
  if (address !== '127.0.0.1' && address !== '::1' && address !== '::ffff:127.0.0.1') return false
  const host = request.headers.host
  if (typeof host !== 'string') return false
  let hostUrl: URL
  try {
    hostUrl = new URL(`http://${host}`)
  } catch {
    return false
  }
  if (hostUrl.hostname !== '127.0.0.1' && hostUrl.hostname !== 'localhost' && hostUrl.hostname !== '[::1]') return false
  if (request.headers['sec-fetch-site'] === 'cross-site') return false
  const origin = request.headers.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}

/** One JSON response. */
function writeJson(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'referrer-policy': 'no-referrer',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(body))
}

/** Read a JSON request body (undefined when too large or unparseable). */
async function readJsonBody(req: IncomingMessage): Promise<Record<string, unknown> | undefined> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk as Buffer
    size += buffer.length
    if (size > MAX_JSON_BODY_BYTES) return undefined
    chunks.push(buffer)
  }
  try {
    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return typeof parsed === 'object' && parsed !== null ? parsed as Record<string, unknown> : undefined
  } catch {
    return undefined
  }
}

/** Guard helper: fence + method check. */
function guard(req: IncomingMessage, res: ServerResponse, method: string): boolean {
  if (!isLoopbackRequest(req)) {
    writeJson(res, 403, { error: 'forbidden: loopback-only' })
    return false
  }
  if (req.method !== method) {
    writeJson(res, 405, { error: `method not allowed (expected ${method})` })
    return false
  }
  return true
}

/** Merge a partial patch over the current config with schema bounds. */
function applyPatch(current: WhaleConfig, patch: Record<string, unknown>): WhaleConfig {
  const numberOr = (value: unknown, fallback: number): number =>
    typeof value === 'number' && Number.isFinite(value) ? value : fallback
  const stringOr = (value: unknown, fallback: string): string =>
    typeof value === 'string' ? value.slice(0, 80) : fallback
  // A free position is optional: an absent key keeps the current value (so a
  // scale/slider patch never wipes a placed pet); null or any non-finite value
  // clears it and the pet falls back to docked placement.
  const positionOr = (value: unknown, fallback: number | undefined): number | undefined => {
    if (value === undefined) return fallback
    if (typeof value !== 'number' || !Number.isFinite(value)) return undefined
    return Math.max(0, Math.min(10000, value))
  }
  return {
    enabled: typeof patch.enabled === 'boolean' ? patch.enabled : current.enabled,
    flipOnSend: typeof patch.flipOnSend === 'boolean' ? patch.flipOnSend : current.flipOnSend,
    scale: Math.max(0.2, Math.min(3, numberOr(patch.scale, current.scale))),
    sensitivity: Math.max(0.2, Math.min(5, numberOr(patch.sensitivity, current.sensitivity))),
    caption: stringOr(patch.caption, current.caption),
    // t8: 停靠位置已移除；t10: bottom 随左下角定位一并移除，patch 里的旧字段被忽略。
    x: positionOr(patch.x, current.x),
    y: positionOr(patch.y, current.y),
  }
}

/** Build the route family. */
export function makeWhaleRoutes(): WebRoute[] {
  const state: WebRoute = {
    kind: 'exact',
    path: '/api/ventus-whale/state',
    handler: (req, res) => {
      if (!guard(req, res, 'GET')) return
      writeJson(res, 200, { config: loadConfig() })
    },
  }

  const update: WebRoute = {
    kind: 'exact',
    path: '/api/ventus-whale/update',
    handler: async (req, res) => {
      if (!guard(req, res, 'POST')) return
      const body = await readJsonBody(req)
      if (body === undefined) {
        writeJson(res, 400, { error: 'invalid JSON body' })
        return
      }
      const next = applyPatch(loadConfig(), body)
      saveConfig(next)
      writeJson(res, 200, { config: next })
    },
  }

  const reset: WebRoute = {
    kind: 'exact',
    path: '/api/ventus-whale/reset',
    handler: (req, res) => {
      if (!guard(req, res, 'POST')) return
      saveConfig({ ...DEFAULT_CONFIG })
      writeJson(res, 200, { config: { ...DEFAULT_CONFIG } })
    },
  }

  return [state, update, reset]
}
