/**
 * Geometry-build smoke: exercises the compiled whale-model module's model
 * construction path without WebGL (three.js BufferGeometry works headless).
 * Catches runtime errors in buildWhaleRig — including the eye/brow surface
 * mapping fix — that would crash the pet in the browser.
 */
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)

// Load the compiled client half's whale-model through the source export map.
// The bundle is a CJS __ModuleLoader__ closure; instead load the tsc output
// (lib/client/whale-model.js) directly — it is plain ESM.
const model = await import('../lib/client/whale-model.js')
console.log('module exports:', Object.keys(model).filter(k => k !== 'default'))

if (typeof model.createWhaleScene !== 'function') {
  console.error('createWhaleScene not exported — wrong module')
  process.exit(1)
}

// createWhaleScene needs a DOM container; stub the minimal surface it uses:
// appendChild, getBoundingClientRect, and a ResizeObserver. WebGLRenderer
// will fail headless, so we cannot run the full scene — but we can still
// import and inspect the module. The real geometry test runs in the browser.
console.log('whale-model module loads OK')
console.log('has buildSurfaceMesh logic:', /scaled\(p\)/.test(await (await import('node:fs/promises')).readFile(new URL('../lib/client/whale-model.js', import.meta.url), 'utf8')))
