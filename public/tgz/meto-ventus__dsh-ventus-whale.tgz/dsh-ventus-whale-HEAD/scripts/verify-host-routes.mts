/**
 * Host-side verification for the t1 x/y free-position changes. Imports the
 * SOURCE routes directly (tsx) and drives each route handler with mock
 * req/res, isolated in a temp DSH_HOME so the real pet config is untouched.
 * Covers: x/y persisted, clamped, cleared by null, kept through other patches,
 * and reset restoring defaults.
 */
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Readable } from 'node:stream'
import { makeWhaleRoutes } from '../src/routes.ts'
import { DEFAULT_CONFIG } from '../src/protocol.ts'
import { loadConfig } from '../src/host.ts'

const home = mkdtempSync(join(tmpdir(), 'ventus-whale-verify-'))
process.env.DSH_HOME = home

let failures = 0
function check(label: string, actual: unknown, expected: unknown): void {
  const a = JSON.stringify(actual)
  const e = JSON.stringify(expected)
  if (a === e) {
    console.log('  ok:', label)
  } else {
    failures++
    console.error('  FAIL:', label, '\n    actual:  ', a, '\n    expected:', e)
  }
}

function request(method: string, body?: Record<string, unknown>): Readable & {
  socket: { remoteAddress: string }
  headers: Record<string, string>
} {
  const stream = Readable.from(body === undefined ? [] : [Buffer.from(JSON.stringify(body))]) as Readable & {
    socket: { remoteAddress: string }
    headers: Record<string, string>
  }
  stream.socket = { remoteAddress: '127.0.0.1' }
  stream.headers = {
    host: '127.0.0.1:3080',
    origin: 'http://127.0.0.1:3080',
    'sec-fetch-site': 'same-origin',
    'content-type': 'application/json',
  }
  ;(stream as unknown as { method: string }).method = method
  return stream
}

function response(): { status: number; body: unknown; writeHead(s: number, h: Record<string, string>): void; end(b: string): void } {
  const res: { status: number; body: unknown; writeHead(s: number, h: Record<string, string>): void; end(b: string): void } = {
    status: 0,
    body: undefined,
    writeHead(status: number) { this.status = status },
    end(body: string) { this.body = JSON.parse(body) },
  }
  return res
}

const [stateRoute, updateRoute, resetRoute] = makeWhaleRoutes()
const cfgPath = join(home, 'dsh-ventus-whale', 'config.json')

async function call(route: { handler: (req: unknown, res: unknown) => void | Promise<void> }, method: string, body?: Record<string, unknown>): Promise<{ status: number; body: unknown }> {
  const res = response()
  await route.handler(request(method, body), res)
  return { status: res.status, body: res.body }
}

console.log('--- routes mounted:', makeWhaleRoutes().map(r => `${r.kind} ${r.path}`).join(', '))

// 1. fresh state = defaults (no x/y)
let r = await call(stateRoute, 'GET')
check('initial state', r.body, { config: DEFAULT_CONFIG })

// 2. update persists x/y
r = await call(updateRoute, 'POST', { x: 111, y: 222 })
check('update returns x/y', (r.body as { config: Record<string, unknown> }).config, { ...DEFAULT_CONFIG, x: 111, y: 222 })
check('file persisted x/y', JSON.parse(readFileSync(cfgPath, 'utf8')), { ...DEFAULT_CONFIG, x: 111, y: 222 })
r = await call(stateRoute, 'GET')
check('state reflects x/y', (r.body as { config: Record<string, unknown> }).config, { ...DEFAULT_CONFIG, x: 111, y: 222 })

// 3. clamping
r = await call(updateRoute, 'POST', { x: -50, y: 99999 })
check('clamped x/y', (r.body as { config: Record<string, unknown> }).config, { ...DEFAULT_CONFIG, x: 0, y: 10000 })
r = await call(updateRoute, 'POST', { x: 12345 })
check('x capped at 10000', (r.body as { config: Record<string, unknown> }).config, { ...DEFAULT_CONFIG, x: 10000, y: 10000 })

// 4. null clears x/y
r = await call(updateRoute, 'POST', { x: null, y: null })
check('null clears x/y', r.body, { config: DEFAULT_CONFIG })

// 5. non-numeric clears x/y too
r = await call(updateRoute, 'POST', { x: 'junk', y: true })
check('non-numeric clears x/y', r.body, { config: DEFAULT_CONFIG })

// 6. other patches keep x/y
r = await call(updateRoute, 'POST', { x: 300, y: 400 })
r = await call(updateRoute, 'POST', { dock: 'right', bottom: 50 })
check('dock/bottom patch keeps x/y', (r.body as { config: Record<string, unknown> }).config, { ...DEFAULT_CONFIG, dock: 'right', bottom: 50, x: 300, y: 400 })

// 7. reset restores defaults (x/y gone)
r = await call(resetRoute, 'POST')
check('reset response', r.body, { config: DEFAULT_CONFIG })
check('reset file', JSON.parse(readFileSync(cfgPath, 'utf8')), DEFAULT_CONFIG)
check('loadConfig after reset', loadConfig(), DEFAULT_CONFIG)

// 8. loopback fence rejects foreign origins
const foreignRes = response()
await stateRoute.handler(Object.assign(request('GET'), { headers: { host: '127.0.0.1:3080', origin: 'http://evil.example', 'sec-fetch-site': 'same-origin' } }), foreignRes)
check('foreign origin rejected', foreignRes.status, 403)

rmSync(home, { recursive: true, force: true })
console.log(failures === 0 ? 'HOST ROUTES: ALL PASS' : `HOST ROUTES: ${failures} FAILURE(S)`)
process.exit(failures === 0 ? 0 : 1)
