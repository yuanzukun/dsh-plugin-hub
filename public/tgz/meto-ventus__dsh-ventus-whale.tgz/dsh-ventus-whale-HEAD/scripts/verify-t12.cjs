// t12 verification: ①Ventus 描述家族→系列 ②设置卡保存按钮语义 ③大小滑块改窗口尺寸
// ④工具栏两行 + 转圈按钮。全程使用真实 GUI，结束时还原原配置。
const { chromium } = require('E:/ProgramData/deepseek-harness/node_modules/.pnpm/node_modules/playwright')

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const errors = []
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  const fetchState = () => page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  const waitWhale = async (timeoutMs = 12000) => {
    const t0 = Date.now()
    while (Date.now() - t0 < timeoutMs) {
      const has = await page.evaluate(() => {
        const w = document.querySelector('[data-ventus-whale]')
        return !!(w && getComputedStyle(w).display !== 'none' && w.querySelector('canvas'))
      }).catch(() => false)
      if (has) return true
      await page.waitForTimeout(400)
    }
    return false
  }

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(8000)
  const orig = await fetchState()
  console.log('ORIG:', JSON.stringify(orig))

  // 0. 展开侧边栏 → 打开设置 → 切「插件」页。
  const sidebarOpened = await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button')).find((b) => (b.getAttribute('aria-label') || '').includes('打开侧边栏'))
    if (!btn) return false
    btn.click()
    return true
  })
  console.log('SIDEBAR_OPEN_CLICKED:', sidebarOpened)
  await page.waitForTimeout(2500)
  const settingsClicked = await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll('button')).find((b) => (b.textContent || '').trim() === '设置' && b.offsetParent !== null)
    if (!btn) return false
    btn.click()
    return true
  })
  console.log('SETTINGS_CLICKED:', settingsClicked)
  await page.waitForTimeout(6000)
  const pluginsClicked = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]') || document
    const els = Array.from(d.querySelectorAll('button, [role=button], a, div, span, li'))
    const hit = els.find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null && el.tagName !== 'LI')
    if (!hit) return false
    hit.click()
    return true
  })
  console.log('PLUGINS_TAB_CLICKED:', pluginsClicked)
  await page.waitForTimeout(5000)

  // 1. Ventus 分组描述文案。
  const desc = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]') || document
    const text = d.innerText || ''
    const el = Array.from(d.querySelectorAll('span[title]')).find((s) => (s.getAttribute('title') || '').includes('Ventus'))
    return { el: el ? { text: el.textContent.trim(), title: el.getAttribute('title') } : null, hasSeries: text.includes('Ventus 系列的插件设置'), hasFamily: text.includes('家族') }
  })
  console.log('VENTUS_DESC:', JSON.stringify(desc))

  // 2. 大肥鱼桌宠卡：拖大小滑块 → state 不变；保存按钮出现；点保存 → state 变。
  const cardBefore = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]') || document
    const card = Array.from(d.querySelectorAll('li')).find((li) => li.textContent.includes('大肥鱼桌宠'))
    if (!card) return null
    const slider = card.querySelector('input[type=range]')
    const r = slider ? slider.getBoundingClientRect() : null
    const hint = Array.from(card.querySelectorAll('span')).find((s) => s.textContent.includes('操作提示'))
    return { hasCard: true, hasUsageHint: !!hint, sliderValue: slider ? slider.value : null, sliderRect: r ? { x: r.x, y: r.y, w: r.width, h: r.height } : null }
  })
  console.log('WHALE_CARD:', JSON.stringify(cardBefore))
  const before = await fetchState()
  if (cardBefore && cardBefore.sliderRect) {
    const r = cardBefore.sliderRect
    await page.mouse.move(r.x + r.w * 0.5, r.y + r.h / 2)
    await page.mouse.down()
    await page.mouse.move(r.x + r.w, r.y + r.h / 2, { steps: 10 })
    await page.mouse.up()
    await page.waitForTimeout(1500)
    const afterDrag = await fetchState()
    console.log('STATE_AFTER_DRAG:', JSON.stringify(afterDrag))
    console.log('AUTO_SAVE_STILL_ACTIVE:', afterDrag.scale !== before.scale)
    const staged = await page.evaluate(() => {
      const d = document.querySelector('[role=dialog]') || document
      const card = Array.from(d.querySelectorAll('li')).find((li) => li.textContent.includes('大肥鱼桌宠'))
      if (!card) return null
      const btns = Array.from(card.querySelectorAll('button')).map((b) => b.textContent.trim())
      return { hasSave: btns.includes('保存'), hasCancel: btns.includes('取消'), hasDirtyHint: Array.from(card.querySelectorAll('span')).some((s) => s.textContent.includes('未保存的更改')), buttons: btns }
    })
    console.log('STAGED_UI:', JSON.stringify(staged))
    const saveClicked = await page.evaluate(() => {
      const d = document.querySelector('[role=dialog]') || document
      const card = Array.from(d.querySelectorAll('li')).find((li) => li.textContent.includes('大肥鱼桌宠'))
      if (!card) return false
      const btn = Array.from(card.querySelectorAll('button')).find((b) => b.textContent.trim() === '保存')
      if (!btn) return false
      btn.click()
      return true
    })
    console.log('SAVE_CLICKED:', saveClicked)
    await page.waitForTimeout(2500)
    const afterSave = await fetchState()
    console.log('STATE_AFTER_SAVE:', JSON.stringify(afterSave))
    console.log('SAVE_TOOK_EFFECT:', afterSave.scale !== before.scale)
  }

  // 2b. 关闭设置。
  await page.keyboard.press('Escape')
  await page.waitForTimeout(1500)

  // 3. 大小 → 窗口尺寸：scale=2 时画布约 440px。
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: true, scale: 2, x: null, y: null }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(3000)
  await waitWhale()
  const size = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    if (!w) return null
    const canvas = w.querySelector('canvas')
    const r = canvas.getBoundingClientRect()
    return { canvasW: Math.round(r.width), canvasH: Math.round(r.height) }
  })
  console.log('CANVAS_AT_SCALE_2 (expect 352 = 176x2):', JSON.stringify(size))

  // 4. 工具栏两行 + 转圈按钮。
  const toolbar = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    if (!w) return null
    const rows = w.querySelectorAll('[class*=toolbarRow]')
    const btns = Array.from(w.querySelectorAll('[class*=quickToolbar] button')).map((b) => b.textContent.trim())
    const canvas = w.querySelector('canvas')
    return { rowCount: rows.length, buttons: btns, canvasTitle: canvas && canvas.closest('[class*=canvas]') ? canvas.closest('[class*=canvas]').getAttribute('title') : null }
  })
  console.log('TOOLBAR:', JSON.stringify(toolbar))
  const flipClicked = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    if (!w) return false
    const btn = Array.from(w.querySelectorAll('[class*=quickToolbar] button')).find((b) => b.textContent.trim() === '转圈')
    if (!btn) return false
    btn.click()
    return true
  })
  console.log('FLIP_CLICKED:', flipClicked)
  await page.waitForTimeout(1200)

  // 还原原配置。
  await page.evaluate(async (o) => {
    const body = { enabled: o.enabled, scale: o.scale, sensitivity: o.sensitivity, caption: o.caption, flipOnSend: o.flipOnSend }
    if (o.x !== undefined) body.x = o.x
    if (o.y !== undefined) body.y = o.y
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
  }, orig)
  console.log('RESTORED:', JSON.stringify(await fetchState()))
  console.log('ERRORS:', JSON.stringify(errors.slice(0, 8)))
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })