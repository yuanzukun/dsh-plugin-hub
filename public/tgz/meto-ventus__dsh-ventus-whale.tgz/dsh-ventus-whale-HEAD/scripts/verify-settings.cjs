// Part 2: open Settings, verify the "Ventus 插件" group card and the
// "大肥鱼桌宠" whale settings card (sliders + caption field), and pixel-
// sample the WebGL canvas to prove the whale actually draws (non-blank).
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(10000)

  // 1. Pixel-sample the whale canvas: non-blank means the 3D scene drew.
  const pixels = await page.evaluate(() => {
    const c = document.querySelector('[data-ventus-whale-host] canvas')
    if (!c) return { found: false }
    const gl = c.getContext('webgl') || c.getContext('experimental-webgl')
    if (!gl) return { found: true, gl: false }
    const w = gl.drawingBufferWidth, h = gl.drawingBufferHeight
    const buf = new Uint8Array(w * h * 4)
    gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf)
    let nonZero = 0, opaque = 0
    for (let i = 0; i < buf.length; i += 4) {
      if (buf[i] || buf[i + 1] || buf[i + 2]) nonZero++
      if (buf[i + 3] > 10) opaque++
    }
    return { found: true, gl: true, w, h, nonZeroPx: nonZero, opaquePx: opaque, total: w * h }
  })
  console.log('CANVAS:', JSON.stringify(pixels))

  // 2. Click the 设置 entry (sidebar).
  const clicked = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('button, [role=button], a, div, span, li'))
    const hit = els.find((el) => el.textContent.trim() === '设置' && el.offsetParent !== null)
    if (hit) { hit.click(); return true }
    return false
  })
  console.log('SETTINGS_CLICKED:', clicked)
  await page.waitForTimeout(6000)

  const text = await page.evaluate(() => document.body.innerText)
  console.log('HAS_VENTUS_GROUP:', text.includes('Ventus 插件'))
  console.log('HAS_WHALE_CARD:', text.includes('大肥鱼桌宠'))
  console.log('HAS_CAPTION_VAL:', text.includes('Ventus'))
  const snippet = text.split('\n').filter((l) => /Ventus|大肥鱼|虎鲸|桌宠|大小|灵敏度|文字/.test(l)).slice(0, 20)
  console.log('SNIPPET:', JSON.stringify(snippet, null, 2))

  // 3. Locate the whale card controls: range inputs + text input.
  const controls = await page.evaluate(() => {
    const ranges = Array.from(document.querySelectorAll('input[type=range]')).map((i) => ({
      value: i.value, min: i.min, max: i.max, step: i.step,
      aria: i.getAttribute('aria-label') || i.closest('label')?.textContent?.trim()?.slice(0, 30) || '',
    }))
    const texts = Array.from(document.querySelectorAll('input[type=text], input:not([type]), textarea')).map((i) => ({
      value: i.value, ph: i.placeholder || '',
    }))
    return { ranges, texts }
  })
  console.log('CONTROLS:', JSON.stringify(controls, null, 2))

  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/02-settings.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
