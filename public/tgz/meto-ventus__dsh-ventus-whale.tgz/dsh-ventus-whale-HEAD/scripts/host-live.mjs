/**
 * Minimal live host for dsh-ventus-whale verification: mounts ONLY the
 * webserver service and the whale plugin (its built lib/index.js), listening
 * on 127.0.0.1:3081. Isolated via DSH_HOME so the real pet config is never
 * touched. Used to verify the NEW host routes (x/y persistence) end-to-end
 * without restarting the live GUI (whose in-memory host predates the change).
 */
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import WebServer from '@deepseek-ai/dsh-host-webserver'
import * as whale from 'dsh-ventus-whale'

process.env.DSH_HOME = mkdtempSync(join(tmpdir(), 'ventus-whale-live-'))

const ctx = new Context()
await ctx.plugin(WebServer, { host: '127.0.0.1', port: 3081 })
await ctx.plugin(whale)

console.log('[ventus-whale-live] listening on http://127.0.0.1:3081 (pid ' + process.pid + ')')
process.on('SIGTERM', () => { void ctx.stop().then(() => process.exit(0)) })
