// Debug v3: full hide-flow trace with fetch instrumentation + whale-girl overlap checks.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  page.on('console', (m) => console.log('CONSOLE[' + m.type() + ']:', m.text().slice(0, 250)))
  page.on('pageerror', (e) => console.log('PAGEERROR:', String(e).slice(0, 300)))
  await page.addInitScript(() => {
    const origFetch = window.fetch
    window.fetch = (...args) => {
      const url = String(args[0])
      if (url.includes('/api/ventus-whale/')) {
        const body = args[1] ? String(args[1].body) : null
        console.log('FETCH>>', args[1] ? args[1].method : 'GET', url, body)
        return origFetch(...args).then((r) => {
          r.clone().json().then((j) => console.log('FETCH<<', r.status, JSON.stringify(j).slice(0, 250))).catch(() => {})
          return r
        })
      }
      return origFetch(...args)
    }
  })

  const snap = async (label) => {
    const info = await page.evaluate(() => {
      const w = document.querySelector('[data-ventus-whale]')
      const g = document.querySelector('[aria-label="whale girl"]')
      const ws = w ? window.getComputedStyle(w) : null
      const gs = g ? window.getComputedStyle(g) : null
      const wb = w ? w.getBoundingClientRect() : null
      const gb = g ? g.getBoundingClientRect() : null
      const menu = Array.from(document.querySelectorAll('[role=menu] button')).map((b) => b.textContent.trim())
      return {
        whale: wb ? { x: Math.round(wb.x), y: Math.round(wb.y), w: Math.round(wb.width), h: Math.round(wb.height), zi: ws?.zIndex } : null,
        girl: gb ? { x: Math.round(gb.x), y: Math.round(gb.y), w: Math.round(gb.width), h: Math.round(gb.height), zi: gs?.zIndex } : null,
        menu,
        summon: !!document.querySelector('[data-ventus-whale-summon]'),
      }
    })
    console.log(label, JSON.stringify(info))
  }
  const state = async (label) => {
    const s = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
    console.log(label, 'STATE=', JSON.stringify(s))
  }

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(8000)
  const resetResp = await page.evaluate(async () => (await fetch('/api/ventus-whale/reset', { method: 'POST' })).status)
  console.log('RESET_STATUS:', resetResp)
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(9000)
  await snap('AFTER_RESET+RELOAD')
  await state('AFTER_RESET+RELOAD')

  // right-click -> menu -> 重置位置
  const wrapper = page.locator('[data-ventus-whale]')
  let box = await wrapper.boundingBox()
  await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2, { button: 'right' })
  await page.waitForTimeout(1000)
  await snap('RC1_MENU')
  await page.getByRole('menuitem', { name: '重置位置' }).click({ timeout: 4000 })
  await page.waitForTimeout(2000)
  await snap('AFTER_RESETPOS')
  await state('AFTER_RESETPOS')

  // right-click -> menu -> 隐藏虎鲸
  box = await wrapper.boundingBox()
  console.log('BOX2:', JSON.stringify(box))
  await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2, { button: 'right' })
  await page.waitForTimeout(1000)
  await snap('RC2_MENU')
  await page.getByRole('menuitem', { name: '隐藏虎鲸' }).click({ timeout: 4000 })
  for (const t of [300, 700, 1500, 3000]) {
    await page.waitForTimeout(t)
    await snap('HIDE+t' + t)
    await state('HIDE+t' + t)
  }

  await browser.close()
})().catch((e) => { console.error('DEBUG FAILED:', e); process.exit(1) })
