// Real-browser verification for the Ventus whale pet inside the live GUI.
// Launches system Edge via playwright (declared dep of dsh-web-ui), opens
// http://127.0.0.1:3080, waits for the SPA, and reports:
//  - boot manifest containing ventus-whale
//  - the [data-ventus-whale-host] mount + canvas presence
//  - console errors
//  - a screenshot of the whole viewport
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  // Let the SPA + HMR-loaded client bundles settle.
  await page.waitForTimeout(12000)

  const report = await page.evaluate(() => {
    const boot = window.__DSH_BOOT__ || {}
    const entries = Array.isArray(boot) ? boot : boot.entries || boot.bundles || []
    const names = Array.isArray(entries)
      ? entries.map((e) => (typeof e === 'string' ? e : e && (e.name || e.id))).filter(Boolean)
      : Object.keys(boot)
    return {
      title: document.title,
      hasBoot: !!window.__DSH_BOOT__,
      bootHasVentus: names.some((n) => String(n).toLowerCase().includes('ventus')),
      bootSample: names.slice(0, 12),
      whaleHost: !!document.querySelector('[data-ventus-whale-host]'),
      canvasCount: document.querySelectorAll('canvas').length,
      canvasSizes: Array.from(document.querySelectorAll('canvas')).map((c) => `${c.width}x${c.height}`),
      bodyHasSettings: document.body.innerText.includes('设置'),
      bodySample: document.body.innerText.slice(0, 200).replace(/\s+/g, ' '),
    }
  })

  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/01-main.png' })
  console.log('REPORT:', JSON.stringify(report, null, 2))
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
