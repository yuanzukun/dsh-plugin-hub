// t11 probe 1: occlusion source — sidebar/whale/girl z-index + hit testing
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(3000)

  // Bring the whale on-screen first (current saved pos may be off-viewport)
  const orig = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('ORIG:', JSON.stringify(orig))
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: true, x: 100, y: 400 }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(5000)

  // 1. z-index inventory of all fixed/high-z elements
  const zi = await page.evaluate(() => {
    const out = []
    for (const el of document.querySelectorAll('body *')) {
      const cs = getComputedStyle(el)
      const z = parseInt(cs.zIndex, 10)
      if (cs.position === 'fixed' && (z > 1000 || el.closest('[data-ventus-whale]'))) {
        const r = el.getBoundingClientRect()
        out.push({
          tag: el.tagName,
          cls: (el.className || '').toString().slice(0, 50),
          z,
          x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height),
          text: el.textContent.trim().slice(0, 20),
        })
      }
    }
    // dedupe by z+class
    const seen = new Set()
    return out.filter(o => { const k = o.z + '|' + o.cls; if (seen.has(k)) return false; seen.add(k); return true })
  })
  console.log('Z_INDEX_INVENTORY:')
  for (const o of zi) console.log(' ', JSON.stringify(o))

  // 2. Whale wrapper details
  const whale = await page.evaluate(() => {
    const wrapper = document.querySelector('[data-ventus-whale]')
    const canvas = wrapper ? wrapper.querySelector('canvas') : null
    const ws = wrapper ? getComputedStyle(wrapper) : null
    const cs = canvas ? getComputedStyle(canvas) : null
    const wr = wrapper ? wrapper.getBoundingClientRect() : null
    return {
      wrapperZ: ws ? ws.zIndex : null,
      canvasZ: cs ? cs.zIndex : null,
      rect: wr ? { x: Math.round(wr.x), y: Math.round(wr.y), w: Math.round(wr.width), h: Math.round(wr.height) } : null,
    }
  })
  console.log('WHALE:', JSON.stringify(whale))

  // 3. Drag whale to left edge, then hit-test the left part of its canvas
  const wb = await page.locator('[data-ventus-whale]').boundingBox()
  if (wb) {
    await page.mouse.move(wb.x + wb.width / 2, wb.y + wb.height / 2)
    await page.waitForTimeout(400)
    // right-drag to x≈0
    await page.mouse.down({ button: 'right' })
    await page.mouse.move(30, wb.y + wb.height / 2, { steps: 10 })
    await page.mouse.up({ button: 'right' })
    await page.waitForTimeout(1500)
    const atEdge = await page.evaluate(() => {
      const wrapper = document.querySelector('[data-ventus-whale]')
      const r = wrapper.getBoundingClientRect()
      // sample points along the left edge of the wrapper
      const pts = []
      for (const fy of [0.3, 0.5, 0.7]) {
        const x = r.x + 5
        const y = r.y + r.height * fy
        const top = document.elementFromPoint(x, y)
        pts.push({
          x: Math.round(x), y: Math.round(y),
          top: top ? top.tagName + '.' + (top.className || '').toString().slice(0, 40) : null,
          inWhale: top ? !!top.closest('[data-ventus-whale]') : false,
        })
      }
      return { rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }, pts }
    })
    console.log('LEFT_EDGE:', JSON.stringify(atEdge, null, 2))
  }

  // 4. Sidebar z-index specifically
  const sidebar = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('body *'))
    const candidates = els.filter((el) => {
      const cs = getComputedStyle(el)
      const r = el.getBoundingClientRect()
      return cs.position === 'fixed' && r.x === 0 && r.width > 50 && r.height > 200
    }).slice(0, 8).map((el) => {
      const cs = getComputedStyle(el)
      const r = el.getBoundingClientRect()
      return { tag: el.tagName, cls: (el.className || '').toString().slice(0, 60), z: cs.zIndex, x: Math.round(r.x), w: Math.round(r.width), h: Math.round(r.height) }
    })
    return candidates
  })
  console.log('SIDEBAR_CANDIDATES:', JSON.stringify(sidebar, null, 2))

  // Restore original
  await page.evaluate(async (o) => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(o) })
  }, orig)
  await browser.close()
})().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
