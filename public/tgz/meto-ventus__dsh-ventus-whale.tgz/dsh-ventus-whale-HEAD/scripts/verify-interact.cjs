// Part 7: end-to-end interaction test.
// 1. Drag the 大小 slider -> verify /api/ventus-whale/state reflects the new scale
// 2. Right-click the whale -> context menu appears
// 3. Drag the whale -> no crash
const path = require('path')
const { chromium } = require('E:/ProgramData/deepseek-harness/node_modules/.pnpm/node_modules/playwright')

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(9000)
  await page.getByRole('button', { name: /设置/ }).first().click({ timeout: 10000 })
  await page.waitForTimeout(3000)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const hit = Array.from(d.querySelectorAll('button, [role=button], div, span')).find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(3500)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const hit = Array.from(d.querySelectorAll('button[aria-expanded]')).find((b) => (b.getAttribute('aria-label') || '').includes('Ventus') || b.textContent.includes('Ventus 插件'))
    if (hit) hit.click()
  })
  await page.waitForTimeout(3500)

  // 1. t12: 拖「大小」滑块只改草稿——/state 不得变化；点「保存」后才落盘。
  const before = await fetchState()
  console.log('STATE_BEFORE:', JSON.stringify(before))
  const slider = page.locator('[role=dialog] input[type=range]').first()
  const box = await slider.boundingBox()
  await page.mouse.move(box.x + box.width * 0.5, box.y + box.height / 2)
  await page.mouse.down()
  await page.mouse.move(box.x + box.width, box.y + box.height / 2, { steps: 10 })
  await page.mouse.up()
  await page.waitForTimeout(1500)
  const afterDrag = await fetchState()
  console.log('STATE_AFTER_DRAG:', JSON.stringify(afterDrag))
  console.log('AUTO_SAVE_STILL_ACTIVE:', afterDrag.config.scale !== before.config.scale)
  const saveClicked = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return false
    const card = Array.from(d.querySelectorAll('li')).find((li) => li.textContent.includes('大肥鱼桌宠'))
    if (!card) return false
    const btn = Array.from(card.querySelectorAll('button')).find((b) => b.textContent.trim() === '保存')
    if (!btn) return false
    btn.click()
    return true
  })
  console.log('SAVE_CLICKED:', saveClicked)
  await page.waitForTimeout(2500)
  const afterSave = await fetchState()
  console.log('STATE_AFTER_SAVE:', JSON.stringify(afterSave))

  // Close dialog to interact with the whale.
  await page.keyboard.press('Escape')
  await page.waitForTimeout(1500)

  // 2. Right-click the whale wrapper.
  const wrapper = page.locator('[data-ventus-whale]')
  await wrapper.click({ button: 'right', timeout: 8000 })
  await page.waitForTimeout(1500)
  const menu = await page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('[role=menu] button')).map((b) => b.textContent.trim())
    return { menuItems: items }
  })
  console.log('CONTEXT_MENU:', JSON.stringify(menu))

  // 3. Drag the whale (pointer rotate).
  const wb = await wrapper.boundingBox()
  if (wb) {
    await page.mouse.move(wb.x + wb.width / 2, wb.y + wb.height / 2)
    await page.mouse.down()
    await page.mouse.move(wb.x + wb.width / 2 + 60, wb.y + wb.height / 2, { steps: 8 })
    await page.mouse.up()
    await page.waitForTimeout(1500)
  }
  console.log('DRAG_DONE')
  // Restore the original scale (test 1 saved a new one).
  await page.evaluate(async (s) => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ scale: s }) })
  }, before.config.scale)
  const restored = await fetchState()
  console.log('RESTORED_SCALE:', JSON.stringify(restored.config.scale))
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()

  async function fetchState() {
    const r = await page.evaluate(async () => (await fetch('/api/ventus-whale/state')).json())
    return r
  }
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
