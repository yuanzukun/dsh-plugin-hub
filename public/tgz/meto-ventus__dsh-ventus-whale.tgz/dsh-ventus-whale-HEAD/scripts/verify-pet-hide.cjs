// Focused: does hide reliably unmount the sprite? Watch DOM + API state over time.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const logs = []
  page.on('console', (m) => { if (/pet|whale|error/i.test(m.text())) logs.push(`[${m.type()}] ${m.text().slice(0, 200)}`) })
  page.on('request', (r) => { if (r.url().includes('/api/pet')) logs.push(`REQ ${r.url().split('/').pop()} ${r.postData() || ''}`) })

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(6000)
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'))
    const target = btns.find((b) => (b.getAttribute('aria-label') === '新建会话' || b.textContent.trim() === '新会话') && b.offsetParent !== null)
    if (target) target.click()
  })
  // wait for girl
  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(1000)
    if (await page.evaluate(() => !!document.querySelector('[aria-label="whale girl"]'))) break
  }
  const present = await page.evaluate(() => ({
    girl: !!document.querySelector('[aria-label="whale girl"]'),
    girlBg: (() => { const el = document.querySelector('[aria-label="whale girl"]'); return el ? (getComputedStyle(el).backgroundImage.includes('url') ? 'OK' : 'NONE') : '-' })(),
  }))
  console.log('PRESENT:', JSON.stringify(present))

  // hover + click hide
  const c = await page.evaluate(() => {
    const r = document.querySelector('[aria-label="whale girl"]').getBoundingClientRect()
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 }
  })
  await page.mouse.move(c.x, c.y)
  await page.waitForTimeout(1500)
  const panel = await page.evaluate(() => {
    const float = document.querySelector('[aria-label="whale girl"]')?.parentElement
    return float ? Array.from(float.querySelectorAll('button')).map((b) => b.textContent.trim()) : []
  })
  console.log('PANEL_BUTTONS:', JSON.stringify(panel))
  await page.evaluate(() => {
    const float = document.querySelector('[aria-label="whale girl"]').parentElement
    Array.from(float.querySelectorAll('button')).find((b) => b.textContent.trim() === '隐藏').click()
  })
  console.log('HIDE CLICKED at', new Date().toISOString())

  // watch 8s
  for (let i = 0; i < 16; i++) {
    await page.waitForTimeout(500)
    const s = await page.evaluate(async () => {
      const api = await (await fetch('/api/pet/state')).json()
      return {
        t: new Date().toISOString().slice(17, 23),
        girl: !!document.querySelector('[aria-label="whale girl"]'),
        summon: !!document.querySelector('[data-testid="pet-summon"]'),
        apiVisible: api.display.visible,
      }
    })
    console.log('WATCH:', JSON.stringify(s))
    if (!s.girl && s.summon) { console.log('UNMOUNTED at', s.t); break }
  }

  // restore
  await page.evaluate(async () => {
    await fetch('/api/pet/set-visible', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ visible: true }) })
  })
  await page.waitForTimeout(2000)
  console.log('RESTORED:', JSON.stringify(await page.evaluate(async () => ({
    girl: !!document.querySelector('[aria-label="whale girl"]'),
    apiVisible: (await (await fetch('/api/pet/state')).json()).display.visible,
  }))))
  console.log('LOGS:', logs.length ? JSON.stringify(logs, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('FAILED:', e); process.exit(1) })
