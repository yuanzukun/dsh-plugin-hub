// Part 5: click the "插件" nav item in the settings dialog, then check the
// plugin section for the Ventus group card + whale settings card + sliders.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(9000)

  // Open settings.
  await page.getByRole('button', { name: /设置/ }).first().click({ timeout: 10000 })
  await page.waitForTimeout(3000)

  // Click the "插件" nav row inside the dialog.
  const nav = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return { dialog: false }
    const rows = Array.from(d.querySelectorAll('button, [role=button], div, span'))
    const hit = rows.find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) { hit.click(); return { dialog: true, clicked: true } }
    return { dialog: true, clicked: false }
  })
  console.log('NAV:', JSON.stringify(nav))
  await page.waitForTimeout(4000)

  const result = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const text = d ? d.innerText : ''
    const controls = Array.from(d ? d.querySelectorAll('input[type=range]') : [])
    const textInputs = Array.from(d ? d.querySelectorAll('input[type=text], input:not([type]), textarea') : [])
    return {
      hasVentusGroup: text.includes('Ventus 插件'),
      hasWhaleCard: text.includes('大肥鱼桌宠'),
      hasWebUiGroup: text.includes('Web UI 插件'),
      rangeCount: controls.length,
      rangeValues: controls.map((i) => `${i.min}..${i.max}@${i.value}`),
      textInputs: textInputs.map((i) => ({ value: i.value, ph: i.placeholder || '' })),
      snippet: text.split('\n').map((l) => l.trim()).filter(Boolean).filter((l) => /Ventus|大肥鱼|虎鲸|桌宠|大小|灵敏度|显示文字|Web UI/.test(l)).slice(0, 25),
    }
  })
  console.log('PLUGIN_SECTION:', JSON.stringify(result, null, 2))
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/06-plugin-section.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
