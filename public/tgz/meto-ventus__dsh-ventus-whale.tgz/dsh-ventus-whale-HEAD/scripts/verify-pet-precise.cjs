// Precise timeline: poll every 1s, log whale-girl mount time vs image request/response.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const t0 = Date.now()
  const stamp = () => ((Date.now() - t0) / 1000).toFixed(1) + 's'
  page.on('request', (r) => { if (r.url().includes('/pet/whale')) console.log(`[${stamp()}] REQ ${r.url().split('/').pop()}`) })
  page.on('response', (r) => { if (r.url().includes('/pet/whale')) console.log(`[${stamp()}] RES ${r.status()} ${r.url().split('/').pop()}`) })
  page.on('requestfailed', (r) => { if (r.url().includes('/pet/whale')) console.log(`[${stamp()}] FAIL ${r.url().split('/').pop()} ${r.failure()?.errorText}`) })

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  console.log(`[${stamp()}] goto done`)

  for (let i = 0; i < 45; i++) {
    await page.waitForTimeout(1000)
    const s = await page.evaluate(() => {
      const el = document.querySelector('[aria-label="whale girl"]')
      if (!el) return { present: false, dock: !!document.querySelector('[data-testid="pet-dock"]') }
      return { present: true, img: getComputedStyle(el).backgroundImage.includes('url') ? 'OK' : 'NONE', dock: !!document.querySelector('[data-testid="pet-dock"]') }
    })
    if (s.present || i % 5 === 0) console.log(`[${stamp()}] ${JSON.stringify(s)}`)
    if (s.present && s.img === 'OK') { console.log(`[${stamp()}] VISIBLE!`); break }
    if (s.present && s.img === 'NONE' && i > 20) { console.log(`[${stamp()}] STUCK INVISIBLE`); break }
  }
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/pet-09-final.png' })
  await browser.close()
})().catch((e) => { console.error('FAILED:', e); process.exit(1) })
