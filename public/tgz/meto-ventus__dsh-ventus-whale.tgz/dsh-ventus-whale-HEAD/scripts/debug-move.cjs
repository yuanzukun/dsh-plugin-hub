// Debug v2: instrument fetch to see whale update calls; trace move drag.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  page.on('console', (m) => console.log('CONSOLE[' + m.type() + ']:', m.text().slice(0, 300)))
  page.on('pageerror', (e) => console.log('PAGEERROR:', String(e).slice(0, 300)))
  await page.addInitScript(() => {
    const origFetch = window.fetch
    window.fetch = (...args) => {
      const url = String(args[0])
      if (url.includes('/api/ventus-whale/')) {
        const body = args[1] ? String(args[1].body) : null
        console.log('FETCH>>', args[1] ? args[1].method : 'GET', url, body)
        return origFetch(...args).then((r) => {
          r.clone().json().then((j) => console.log('FETCH<<', JSON.stringify(j).slice(0, 300))).catch(() => {})
          return r
        })
      }
      return origFetch(...args)
    }
  })

  // reset state first
  const page0 = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  await page0.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page0.evaluate(async () => { await fetch('/api/ventus-whale/reset', { method: 'POST' }) })
  await page0.close()

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(9000)

  const state = async (label) => {
    const s = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
    const w = await page.evaluate(() => {
      const el = document.querySelector('[data-ventus-whale]')
      const cs = el ? window.getComputedStyle(el) : null
      return { left: cs?.left, top: cs?.top, hint: Array.from(document.querySelectorAll('[data-ventus-whale] div')).some((d) => /拖动定位/.test(d.textContent)) }
    })
    console.log(label, 'STATE=', JSON.stringify(s), 'STYLE=', JSON.stringify(w))
  }

  const wrapper = page.locator('[data-ventus-whale]')
  const box = await wrapper.boundingBox()
  console.log('BOX:', JSON.stringify(box))
  const cx = box.x + box.width / 2
  const cy = box.y + box.height / 2
  await state('BEFORE')

  await page.mouse.dblclick(cx, cy)
  await page.waitForTimeout(800)
  await state('AFTER_DBLCLICK')

  await page.mouse.move(cx, cy)
  await page.mouse.down()
  await page.mouse.move(cx + 500, cy - 250, { steps: 6 })
  await state('MID_DRAG')
  await page.mouse.up()
  await page.waitForTimeout(1000)
  await state('AFTER_UP')

  await browser.close()
})().catch((e) => { console.error('DEBUG FAILED:', e); process.exit(1) })
