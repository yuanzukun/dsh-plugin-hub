// Force a conversation open via 新建会话, then verify whale-girl coexistence with our whale (docked right, overlapping).
const path = require('path')
const fs = require('fs')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

const OUT = 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify'
fs.mkdirSync(OUT, { recursive: true })

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const errors = []
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(6000)

  // Click 新建会话 (there are two buttons with aria 新建会话; click the visible one)
  const clicked = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button[aria-label="新建会话"], button'))
    const target = btns.find((b) => (b.getAttribute('aria-label') === '新建会话' || b.textContent.trim() === '新会话') && b.offsetParent !== null)
    if (!target) return false
    target.click()
    return true
  })
  console.log('NEW_SESSION_CLICKED:', clicked)
  await page.waitForTimeout(8000)

  // Poll for the whale girl
  let present = { whale: false, girl: false }
  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(1000)
    present = await page.evaluate(() => ({
      whale: !!document.querySelector('[data-ventus-whale]'),
      girl: !!document.querySelector('[aria-label="whale girl"]'),
      dock: !!document.querySelector('[data-testid="pet-dock"]'),
    }))
    if (present.girl) break
  }
  console.log('PRESENCE:', JSON.stringify(present))

  if (!present.girl) {
    console.log('GIRL NOT MOUNTED. bodyText:', JSON.stringify((await page.evaluate(() => document.body.innerText.slice(0, 200)))))
    await page.screenshot({ path: OUT + '/pet-11-nogirl.png' })
    await browser.close()
    return
  }

  const coexist = await page.evaluate(() => {
    const whale = document.querySelector('[data-ventus-whale]')
    const girl = document.querySelector('[aria-label="whale girl"]')
    const girlFloat = girl.parentElement
    const wcs = getComputedStyle(whale)
    const gcs = getComputedStyle(girlFloat)
    const wr = whale.getBoundingClientRect()
    const gr = girl.getBoundingClientRect()
    const bodyKids = Array.from(document.body.children)
    const ix0 = Math.max(wr.left, gr.left), ix1 = Math.min(wr.right, gr.right)
    const iy0 = Math.max(wr.top, gr.top), iy1 = Math.min(wr.bottom, gr.bottom)
    let probe = null
    if (ix1 > ix0 && iy1 > iy0) {
      const px = (ix0 + ix1) / 2, py = (iy0 + iy1) / 2
      const hit = document.elementFromPoint(px, py)
      probe = { px: Math.round(px), py: Math.round(py), hitTag: hit?.tagName, hitAria: hit?.getAttribute('aria-label'), inGirl: !!hit?.closest('[aria-label="whale girl"]'), inWhale: !!hit?.closest('[data-ventus-whale]'), hitCls: String(hit?.className || '').slice(0, 50) }
    }
    return {
      whaleZ: wcs.zIndex,
      girlFloatZ: gcs.zIndex,
      whaleRect: { l: Math.round(wr.left), t: Math.round(wr.top), r: Math.round(wr.right), b: Math.round(wr.bottom) },
      girlRect: { l: Math.round(gr.left), t: Math.round(gr.top), r: Math.round(gr.right), b: Math.round(gr.bottom) },
      overlap: { w: Math.round(ix1 - ix0), h: Math.round(iy1 - iy0) },
      probe,
      whaleIndex: bodyKids.indexOf(whale),
      girlIndex: bodyKids.indexOf(girlFloat),
      girlBg: getComputedStyle(girl).backgroundImage.includes('url') ? 'OK' : 'NONE',
    }
  })
  console.log('COEXIST:', JSON.stringify(coexist, null, 2))
  await page.screenshot({ path: OUT + '/pet-11-coexist-overlap.png' })

  // Hover girl center -> panel; click hide; verify; restore
  const c = await page.evaluate(() => {
    const r = document.querySelector('[aria-label="whale girl"]').getBoundingClientRect()
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 }
  })
  await page.mouse.move(c.x, c.y)
  await page.waitForTimeout(1500)
  const panel = await page.evaluate(() => {
    const float = document.querySelector('[aria-label="whale girl"]')?.parentElement
    return float ? { present: true, buttons: Array.from(float.querySelectorAll('button')).map((b) => b.textContent.trim()) } : { present: false }
  })
  console.log('PANEL:', JSON.stringify(panel))
  if (panel.present && panel.buttons.includes('隐藏')) {
    await page.evaluate(() => {
      const float = document.querySelector('[aria-label="whale girl"]').parentElement
      Array.from(float.querySelectorAll('button')).find((b) => b.textContent.trim() === '隐藏').click()
    })
    await page.waitForTimeout(2500)
    console.log('AFTER_HIDE:', JSON.stringify(await page.evaluate(async () => ({
      girl: !!document.querySelector('[aria-label="whale girl"]'),
      summon: !!document.querySelector('[data-testid="pet-summon"]'),
      display: (await (await fetch('/api/pet/state')).json()).display,
    }))))
    await page.evaluate(async () => {
      await fetch('/api/pet/set-visible', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ visible: true }) })
    })
    await page.waitForTimeout(2500)
    console.log('RESTORED:', JSON.stringify(await page.evaluate(async () => ({
      girl: !!document.querySelector('[aria-label="whale girl"]'),
      display: (await (await fetch('/api/pet/state')).json()).display,
    }))))
  }
  console.log('ERRORS:', errors.length ? JSON.stringify(errors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('FAILED:', e); process.exit(1) })
