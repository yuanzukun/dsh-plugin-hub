// t8+t9 verification: settings card renders immediately after hard refresh
// (scope-driven), no dock field / no whale-girl phrase, summon toggle works,
// whale fixed bottom-left. Restores the exact pre-run state.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const errors = []
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + String(e).slice(0, 200)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(2000)
  const orig = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('ORIG:', JSON.stringify(orig))

  // HARD-REFRESH simulation: reload, wait for the shell to mount the 设置
  // button, open settings -> 插件, then time until the whale card appears.
  // The measured window is the card's render latency once its section mounts.
  await page.reload({ waitUntil: 'domcontentloaded' })
  let settingsReady = false
  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(250)
    settingsReady = await page.evaluate(() => {
      const els = Array.from(document.querySelectorAll('button, [role=button], a'))
      return els.some((el) => el.textContent.trim() === '设置' && el.offsetParent !== null)
    })
    if (settingsReady) break
  }
  console.log('SHELL_READY_AFTER_RELOAD_MS:', settingsReady ? 'yes' : 'no (10s)')
  await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('button, [role=button], a'))
    const hit = els.find((el) => el.textContent.trim() === '设置' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(1500)
  // 插件 nav
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return
    const rows = Array.from(d.querySelectorAll('button, [role=button], div, span'))
    const hit = rows.find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  const tOpen = Date.now()
  let appeared = null
  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(250)
    const has = await page.evaluate(() => {
      const d = document.querySelector('[role=dialog]')
      if (!d) return false
      return Array.from(d.querySelectorAll('*')).some((el) => (el.textContent || '').includes('大肥鱼桌宠') && el.children.length === 0)
    })
    if (has) { appeared = (Date.now() - tOpen) / 1000; break }
  }
  console.log('CARD_APPEARED_AFTER_PLUGIN_NAV_MS:', appeared === null ? 'NEVER (10s)' : Math.round(appeared * 1000))

  await page.waitForTimeout(1500)
  const card = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return { dialog: false }
    const text = d.innerText
    const btn = Array.from(d.querySelectorAll('button[aria-label]')).find((b) => {
      const a = b.getAttribute('aria-label') || ''
      return a === '展开设置' || a === '收起设置'
    })
    const cardEl = btn ? btn.closest('li') : null
    const body = cardEl ? cardEl.querySelector('[class*=cardBody]') : null
    return {
      dialog: true,
      cardFound: !!btn,
      chevronAria: btn ? btn.getAttribute('aria-label') : null,
      bodyVisible: !!(body && body.offsetParent !== null),
      rangeCount: cardEl ? cardEl.querySelectorAll('input[type=range]').length : -1,
      textInputs: cardEl ? cardEl.querySelectorAll('input[type=text]').length : -1,
      hasDockField: text.includes('停靠位置'),
      hasDockButtons: text.includes('左下角') && text.includes('右下角'),
      hasCoexistPhrase: text.includes('互不遮挡'),
      hasWhaleGirlPhrase: text.includes('鲸鱼少女'),
    }
  })
  console.log('WHALE_CARD:', JSON.stringify(card))
  await page.keyboard.press('Escape')
  await page.waitForTimeout(800)

  // Summon toggle: text should reflect disabled state, click toggles
  const btnInfo = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button[aria-label]'))
    const hit = btns.find((b) => /召唤虎鲸|隐藏虎鲸/.test(b.getAttribute('aria-label') || ''))
    if (!hit) return { found: false }
    const r = hit.getBoundingClientRect()
    return { found: true, label: hit.getAttribute('aria-label'), text: hit.textContent.trim(), x: r.x + r.width / 2, y: r.y + r.height / 2 }
  })
  console.log('SUMMON_BTN:', JSON.stringify(btnInfo))

  if (btnInfo.found) {
    // Click -> summon (enabled true)
    await page.mouse.click(btnInfo.x, btnInfo.y)
    await page.waitForTimeout(1200)
    const after1 = await page.evaluate(() => {
      const wrapper = document.querySelector('[data-ventus-whale]')
      const style = wrapper ? getComputedStyle(wrapper) : null
      return {
        wrapper: !!wrapper,
        display: style ? style.display : null,
        left: style ? style.left : null,
        bottom: style ? style.bottom : null,
        top: style ? style.top : null,
      }
    })
    const label1 = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button[aria-label]'))
      const hit = btns.find((b) => /召唤虎鲸|隐藏虎鲸/.test(b.getAttribute('aria-label') || ''))
      return hit ? hit.getAttribute('aria-label') : null
    })
    console.log('AFTER_SUMMON:', JSON.stringify({ ...after1, btnLabel: label1 }))

    // Click again -> hide (enabled false)
    const btnInfo2 = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button[aria-label]'))
      const hit = btns.find((b) => /召唤虎鲸|隐藏虎鲸/.test(b.getAttribute('aria-label') || ''))
      if (!hit) return null
      const r = hit.getBoundingClientRect()
      return { x: r.x + r.width / 2, y: r.y + r.height / 2 }
    })
    if (btnInfo2) {
      await page.mouse.click(btnInfo2.x, btnInfo2.y)
      await page.waitForTimeout(1200)
      const after2 = await page.evaluate(() => {
        const wrapper = document.querySelector('[data-ventus-whale]')
        const style = wrapper ? getComputedStyle(wrapper) : null
        const btns = Array.from(document.querySelectorAll('button[aria-label]'))
        const hit = btns.find((b) => /召唤虎鲸|隐藏虎鲸/.test(b.getAttribute('aria-label') || ''))
        return {
          display: style ? style.display : null,
          btnLabel: hit ? hit.getAttribute('aria-label') : null,
        }
      })
      console.log('AFTER_HIDE:', JSON.stringify(after2))
    }

    // Whale fixed bottom-left check (visible state position)
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button[aria-label]'))
      const hit = btns.find((b) => /召唤虎鲸|隐藏虎鲸/.test(b.getAttribute('aria-label') || ''))
      if (hit) hit.click()
    })
    await page.waitForTimeout(1200)
    const pos = await page.evaluate(() => {
      const wrapper = document.querySelector('[data-ventus-whale]')
      const style = wrapper ? getComputedStyle(wrapper) : null
      return { left: style ? style.left : null, bottom: style ? style.bottom : null, display: style ? style.display : null }
    })
    console.log('DOCKED_POSITION:', JSON.stringify(pos))
  }

  // Restore exact original state
  await page.evaluate(async (o) => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(o) })
  }, orig)
  const restored = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('RESTORED:', JSON.stringify(restored))
  console.log('ERRORS:', JSON.stringify(errors.slice(0, 5)))
  await browser.close()
})().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
