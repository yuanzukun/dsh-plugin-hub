// Part 10: verify the cache-hit percentage renders with two decimals in a
// real conversation's stats line. Opens the first conversation with stats.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(9000)

  // Try clicking a conversation from the sidebar list to load its stats.
  const opened = await page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('li, [role=button], button, div'))
    const candidates = items.filter((el) => /工作流|视频剪辑|CombTheoScience|刚刚|分钟前/.test(el.textContent || '') && el.offsetParent !== null && (el.textContent || '').length < 60)
    if (candidates.length === 0) return { opened: false, reason: 'no candidates' }
    candidates[0].click()
    return { opened: true, clicked: candidates[0].textContent.trim().slice(0, 40) }
  })
  console.log('OPEN:', JSON.stringify(opened))
  await page.waitForTimeout(6000)

  const stats = await page.evaluate(() => {
    const text = document.body.innerText
    const hit = (text.match(/缓存命中[^\n|]*/g) || []).slice(0, 5)
    const cacheEn = (text.match(/Cache hit[^\n|]*/g) || []).slice(0, 5)
    const lines = text.split('\n').map((l) => l.trim()).filter(Boolean)
    return {
      cacheLines: hit,
      cacheEn,
      hasTwoDecimal: hit.some((h) => /缓存命中 \d+\.\d{2}%/.test(h)),
      sample: lines.filter((l) => /缓存|Cache hit|LLM|tok/.test(l)).slice(0, 10),
    }
  })
  console.log('STATS:', JSON.stringify(stats, null, 2))
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/10-stats.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
