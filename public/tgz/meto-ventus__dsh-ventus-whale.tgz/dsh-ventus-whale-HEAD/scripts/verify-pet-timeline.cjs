// Definitive: track the APP's whale-girl sprite state over time + remount cycle.
const path = require('path')
const fs = require('fs')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

const OUT = 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify'
fs.mkdirSync(OUT, { recursive: true })

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const net = []
  page.on('request', (r) => { if (r.url().includes('/pet/whale')) net.push(`[${Date.now() % 100000}] REQ ${r.method()} ${r.url().split('/').pop()}`) })
  page.on('response', (r) => { if (r.url().includes('/pet/whale')) net.push(`[${Date.now() % 100000}] RES ${r.status()} ${r.url().split('/').pop()}`) })
  page.on('requestfailed', (r) => { if (r.url().includes('/pet/whale')) net.push(`[${Date.now() % 100000}] FAIL ${r.url().split('/').pop()} :: ${r.failure()?.errorText}`) })

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })

  const spriteState = () => page.evaluate(() => {
    const el = document.querySelector('[aria-label="whale girl"]')
    if (!el) return { present: false }
    return {
      present: true,
      bgImage: getComputedStyle(el).backgroundImage.slice(0, 80),
      inlineBgImage: el.style.backgroundImage ? 'SET' : 'UNSET',
      bgPos: getComputedStyle(el).backgroundPosition,
    }
  })

  for (const t of [3000, 10000, 30000]) {
    await page.waitForTimeout(t === 3000 ? 3000 : t - (t === 10000 ? 3000 : 10000))
    console.log(`T+${t}ms:`, JSON.stringify(await spriteState()))
    if (t === 3000) await page.screenshot({ path: OUT + '/pet-06-t3.png' })
    if (t === 30000) await page.screenshot({ path: OUT + '/pet-07-t30.png' })
  }

  // Remount cycle: hide then summon (this remounts WhalePet)
  const hoverRes = await page.evaluate(() => {
    const el = document.querySelector('[aria-label="whale girl"]')
    const float = el ? el.parentElement : null
    if (!float) return { ok: false }
    const r = el.getBoundingClientRect()
    return { ok: true, x: r.left + r.width / 2, y: r.top + r.height / 2 }
  })
  if (hoverRes.ok) {
    await page.mouse.move(hoverRes.x, hoverRes.y)
    await page.waitForTimeout(1200)
    await page.evaluate(() => {
      const el = document.querySelector('[aria-label="whale girl"]')
      const float = el ? el.parentElement : null
      const btn = float && Array.from(float.querySelectorAll('button')).find((b) => b.textContent.trim() === '隐藏')
      if (btn) btn.click()
    })
    await page.waitForTimeout(2500)
    console.log('AFTER_HIDE:', JSON.stringify(await spriteState()))
    // summon back
    await page.evaluate(async () => {
      await fetch('/api/pet/set-visible', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ visible: true }) })
    })
    await page.waitForTimeout(2500)
    console.log('AFTER_SUMMON:', JSON.stringify(await spriteState()))
    await page.screenshot({ path: OUT + '/pet-08-remounted.png' })
  }

  console.log('NET:', net.length ? JSON.stringify(net, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('FAILED:', e); process.exit(1) })
