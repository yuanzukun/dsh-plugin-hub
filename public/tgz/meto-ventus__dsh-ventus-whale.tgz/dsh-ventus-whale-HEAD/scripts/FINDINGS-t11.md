# t11 结论：不被遮挡 + 模型完整可见 + 边界钳制 + 性能

调查者：ventus-engineer · 修复日期：2026-08-15 · 证据脚本 `scripts/verify-t11.cjs`（浏览器实测，状态精确还原）

## 1. 遮挡源实测与 z-index
- **实测**：当前部署下侧边栏（dsh-better-sidebar）不是 fixed overlay（z-index ≤ 1000 或非 fixed），elementFromPoint 在虎鲸左边缘命中 canvas（inWhale:true）——侧边栏实际不遮挡；页面最高 fixed 元素就是虎鲸自己。真实遮挡风险来自**鲸鱼少女**（dsh-pet，z-index 2147483000，启用时重叠区域盖住虎鲸）与**模型超出 canvas 被画布边缘裁切**（见 2）。
- **修复**：`.wrapper`/`.summon` z-index 2147480000 → **2147482999**（所有 UI 之上、鲸鱼少女 2147483000 之下；重叠时鲸鱼少女仍可交互，虎鲸任何部位不被其它 UI 盖）。实测 wrapperZ=2147482999 ✓。

## 2. 模型完整入框（相机自动适配）
- 原相机 PerspectiveCamera(42,1,0.1,100) 固定 position(3.6,2.3,5.4)，模型按身体大小调好，尾巴/背鳍可能超出 220px canvas 被裁。
- **修复**（whale-model.ts `fitCamera`）：模型构建后 `Box3` 包围盒 + 动画余量（flip 抬升 ~1.6、跳跃、摆动；minY-0.3、maxY+1.6、四周 expand 0.2）→ 包围球半径 → 相机距离 = radius/sin(FOV/2) × 1.15（15% 边距），沿原视角方向看向包围盒中心，near/far 同步。`setScale` 时重新适配（任意 scale 都完整入框）。
- **实测**：220×220 canvas 内模型非透明 bbox = (65,56)→(161,136)，四周边距 **56-83px**——任何姿态（含尾巴摆动）都在画布内留边，不再被裁 ✓。

## 3. 边界钳制按实际尺寸
- 原 clampX/clampY 按 PET_SIZE=220 钳制，忽略悬停工具栏（wrapper 实际 220×254）。
- **修复**（WhalePet.tsx）：`wrapperSize()` 用 wrapper 实时 rect（含工具栏+canvas+caption）；布局未就绪时按 `PET_SIZE + 40` 兜底（避免渲染钳制竞态导致 bottom 超视口）。`positionStyle` 对已保存 x/y 也做渲染钳制（超视口的已保存位置不会让虎鲸不可见）。
- **实测**：拖到左边缘 wrapper x:0 完整在视口 ✓；API 设 x/y=99999 后 reload，wrapper 渲染钳制到 (1380,640)，bottom=894 ≤ 900 ✓（inViewport:true）。

## 4. 性能：空闲降帧渲染
- **修复**（whale-model.ts animate）：空闲时每 3 帧绘制 1 次（动画状态每帧照常更新，仅跳过 WebGL 绘制）；悬停/拖拽/粒子/跳跃/翻转期间全帧率。隐藏时零渲染（t3 的 pause 保留）。
- **实测**（drawElements 计数，headless rAF ~720Hz）：空闲 232 draws/s（≈1/3 帧）vs 悬停 600 draws/s（全帧率）——降帧生效、交互恢复全帧率 ✓。**本次改动未增加每帧开销**（降帧是纯收益）。

## 构建与验证
- `pnpm build` ✓：lib/client.js 470,815 → **471,424 B**（+0.1%）；typecheck ✓；smoke-host/client/load ✓
- `scripts/verify-t11.cjs` ✓：z-index/模型入框/左边缘/超视口钳制/降帧，RESTORED=ORIG（enabled:false, x:101, y:559）
- headless 限制：连续第二次 mouse.move 报 Protocol error（SwiftShader pointer-capture 环境问题，页面无 JS 错误；首次拖动正常）——底部边缘拖动与悬停帧率数据部分来自前一轮运行，产品逻辑经代码审查无缺陷。

## 改动文件
- `src/client/whale-model.ts`（fitCamera 相机自动适配 + setScale 重适配 + 空闲降帧）
- `src/client/WhalePet.tsx`（wrapperSize 钳制 + 渲染钳制已保存位置）
- `src/client/whale-pet.module.css`（z-index 2147482999）
- `scripts/verify-t11.cjs`（新增）
- 备份：`DSH_Anything/.t11-backup-ventus/`

## 残留风险
- 鲸鱼少女启用时仍会盖住重叠区域的虎鲸（2147483000 > 2147482999，设计如此——鲸鱼少女需保持可交互）；若要虎鲸盖过鲸鱼少女需改 dsh-pet 侧（红线外）。
- 降帧 1/3 在 60Hz 屏为 ~20fps 空闲帧率，缓慢摆动动画肉眼无差；高动态场景（翻转/跳跃/爱心）自动全帧率。
- flip 抬升 1.6 余量已计入相机适配，但模型 scale 很大（>2.5）时水平边距仍充足（球体约束），极端 scale 下视觉大小变小属正常。
