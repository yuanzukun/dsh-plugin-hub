# t2 调查结论：whale girl「看不见但还在那儿」根因

调查者：pet-investigator · 2026-08-15 · 证据脚本 `scripts/verify-pet*.cjs`，截图 `.ventus-verify/pet-*.png`

## 结论（TL;DR）

- 「看不见但还在那儿」是 **dsh-pet 自身的前端健壮性问题**，不是我们的 ventus-whale 遮挡，也不是 CSS/服务器问题。
- 「隐藏点了都没用」实际**功能正常**（已两次验证 hide→unmount→召唤按钮→恢复），体感无效是因为：精灵已经不可见时点隐藏没有任何可见变化，唯一反馈是输入框 dock 行的小「召唤麦麦」按钮，容易被忽略。
- **发现并修复了一个真实的共存冲突**：t1 测试把虎鲸切到了 `dock:right`，虎鲸 220px canvas 与 whale girl 右下角默认位置重叠 96×160px，而两者 z-index 都是 2147483000（谁后挂载谁盖谁）。已把我们的 `.wrapper`/`.summon` z-index 降到 2147480000（低于 girl 的 2147483000），girl 永远在最上层、可交互。已构建并在浏览器验证。

## 证据

### 1. 精灵不可见但 DOM 在（用户症状 2）—— dsh-pet 缺陷

- sprite div 只有 `img.onload` 触发后才设置 `backgroundImage`；实测 **4/5 次 headless 会话中该图从未被应用**：`computed background-image: none`、`visibility:visible opacity:1 z-index:2147483000 pointer-events:auto`，DOM 在、hover 面板在、无 console 错误、无失败请求。
- 服务器服务 1.5MB WebP 很慢：GET 实测 1.0–4.6s（localhost）。挂载期（页面加载/HMR 重挂）的竞态会丢掉 onload → `imageReady` 永不置真 → 永久空白透明 div。
- `WhalePet.tsx` 图片 effect **没有 onerror、没有重试、没有超时**（served bundle 与源码一致）。
- 复现：T+30s 时 sprite 仍 `background-image:none`；hide+summon 重挂载后立即 `url(...)` 正常；硬刷新/重挂载即恢复 —— 与用户「强制刷新后两个都出现了」完全吻合。

### 2. 精灵整个消失（用户症状 1）—— dsh-pet 设计限制

- whale girl 只挂在会话作用域的 `conversation.input.dock` 槽里；无活动会话（如新建会话页）时 dock 不渲染 → 精灵完全不存在（45s 观察 run：dock:false，无 pet、无 /pet/whale 请求）。其代码注释自述为「accepted downgrade, see PR #17」。

### 3. 隐藏控件（用户症状 3）

- 功能正常（验证两次）：POST /api/pet/set-visible → 持久化 visible:false → sprite 卸载 → dock 出现「召唤麦麦」→ 恢复成功。
- 体感无效的合理解释：精灵已不可见时点隐藏无可见变化 + 召唤按钮太小且在 dock 行。
- 小瑕疵：一次 run 中服务器状态已变 visible:false 但客户端 sprite 2.5s 未卸载（客户端 store 刷新延迟）。

### 4. 与 ventus-whale 的关系

- 原几何（虎鲸左下 16,24、girl 右下 140,89）：不重叠，girl 后挂载盖上面，elementFromPoint 命中 sprite 本身，无遮挡。
- **新发现的冲突（已修复）**：虎鲸 dock:right 时与 girl 重叠 96×160px；同 z-index 2147483000 时谁盖谁取决于 DOM 顺序，HMR/重建后虎鲸若后挂载会盖住 girl 并抢走指针事件。修复 = 我们的 z-index 降到 2147480000（wrapper+summon），menu 保持 2147483001。构建后浏览器验证：overlap 区 elementFromPoint 命中 girl（inGirl:true, inWhale:false）、hover 面板可用、hide/restore 正常。

## 建议

1. **dsh-pet（上报用户，不改 dsh-web-ui 源码）**：给 `WhalePet.tsx` 图片加载加 `onerror`+重试+渲染兜底；否则任何一次瞬时图片加载失败都会让精灵永久隐形到刷新。
2. **我们侧（已完成）**：z-index 共存修复，已验证。
3. 操作提示：whale-engineer 测试后把虎鲸恢复 dock:left，或用户右键「重置位置」。

## 改动文件

- `dsh-ventus-whale/src/client/whale-pet.module.css`（.wrapper/.summon z-index 2147483000→2147480000）
- 已重新构建 `dsh-ventus-whale/lib/client.js`（2026-08-15 02:14:37）
- 新增验证脚本：`scripts/verify-pet.cjs`、`verify-pet-deep.cjs`、`verify-pet-flags.cjs`、`verify-pet-timeline.cjs`、`verify-pet-precise.cjs`、`verify-pet-coexist.cjs`、`verify-pet-hide.cjs`、`verify-pet-ui.cjs`
- 截图：`.ventus-verify/pet-01..11-*.png`
