// Task t2: whale girl (dsh-pet) visibility/interaction investigation.
// Checks [aria-label="whale girl"] computed style + background-image load,
// elementFromPoint hit-testing, hover panel buttons (喂食/改名/隐藏), hide
// persistence, summon restore, overlap with our ventus-whale pet, and
// console/network failures. Screenshots -> .ventus-verify/pet-*.png
const path = require('path')
const fs = require('fs')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

const OUT = 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify'
fs.mkdirSync(OUT, { recursive: true })

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  const failedRequests = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 400)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 400)))
  page.on('requestfailed', (r) => failedRequests.push(`${r.url()} :: ${r.failure()?.errorText}`))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(12000)

  // ---- 1. Whale girl presence + computed style + image load state
  const girl = await page.evaluate(() => {
    const el = document.querySelector('[aria-label="whale girl"]')
    if (!el) return { present: false, bodyChildren: document.body.children.length }
    const cs = getComputedStyle(el)
    const r = el.getBoundingClientRect()
    const float = el.parentElement
    const fcs = float ? getComputedStyle(float) : null
    const fr = float ? float.getBoundingClientRect() : null
    let imgEntry = null
    try {
      const hit = performance.getEntriesByType('resource').find((e) => e.name.includes('/pet/whale/spritesheet'))
      if (hit) imgEntry = { name: hit.name, transferSize: hit.transferSize, duration: Math.round(hit.duration) }
    } catch { /* ignore */ }
    return {
      present: true,
      tag: el.tagName,
      visibility: cs.visibility,
      opacity: cs.opacity,
      display: cs.display,
      zIndex: cs.zIndex,
      pointerEvents: cs.pointerEvents,
      rect: { left: Math.round(r.left), top: Math.round(r.top), right: Math.round(r.right), bottom: Math.round(r.bottom), width: Math.round(r.width), height: Math.round(r.height) },
      inlineBgImage: el.style.backgroundImage.slice(0, 120) || '(unset)',
      computedBgImage: cs.backgroundImage.slice(0, 120),
      bgSize: cs.backgroundSize,
      bgPos: cs.backgroundPosition,
      float: float ? { zIndex: fcs.zIndex, pointerEvents: fcs.pointerEvents, rect: { left: Math.round(fr.left), top: Math.round(fr.top), width: Math.round(fr.width), height: Math.round(fr.height) } } : null,
      imgEntry,
      role: el.getAttribute('role'),
    }
  })
  console.log('GIRL:', JSON.stringify(girl, null, 2))

  // ---- 2. Our whale wrapper
  const whale = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    if (!w) return { present: false }
    const cs = getComputedStyle(w)
    const r = w.getBoundingClientRect()
    // DOM order vs whale-girl float among body portals
    const girlsFloat = document.querySelector('[aria-label="whale girl"]')?.parentElement
    const bodyKids = Array.from(document.body.children)
    return {
      present: true,
      zIndex: cs.zIndex,
      pointerEvents: cs.pointerEvents,
      rect: { left: Math.round(r.left), top: Math.round(r.top), right: Math.round(r.right), bottom: Math.round(r.bottom), width: Math.round(r.width), height: Math.round(r.height) },
      canvas: !!w.querySelector('canvas'),
      whaleIndex: bodyKids.indexOf(w),
      girlIndex: girlsFloat ? bodyKids.indexOf(girlsFloat) : -1,
    }
  })
  console.log('WHALE:', JSON.stringify(whale, null, 2))

  // ---- 3. elementFromPoint probes at the whale-girl sprite
  const probes = await page.evaluate(() => {
    const el = document.querySelector('[aria-label="whale girl"]')
    if (!el) return { present: false }
    const r = el.getBoundingClientRect()
    const points = {
      center: [r.left + r.width / 2, r.top + r.height / 2],
      topLeft: [r.left + 6, r.top + 6],
      bottomRight: [r.right - 6, r.bottom - 6],
      above: [r.left + r.width / 2, Math.max(0, r.top - 40)], // where the hover panel appears
    }
    const out = {}
    for (const [k, [x, y]] of Object.entries(points)) {
      const hit = document.elementFromPoint(x, y)
      out[k] = hit ? {
        tag: hit.tagName,
        cls: String(hit.className).slice(0, 90),
        aria: hit.getAttribute('aria-label'),
        inGirl: !!hit.closest('[aria-label="whale girl"]'),
        inWhale: !!hit.closest('[data-ventus-whale]'),
        inDialog: !!hit.closest('[role=dialog]'),
        text: (hit.textContent || '').trim().slice(0, 30),
      } : null
    }
    return { present: true, points: out }
  })
  console.log('PROBES:', JSON.stringify(probes, null, 2))

  // ---- 4. API state sanity
  const apiState = await page.evaluate(async () => {
    try {
      const s = await (await fetch('/api/pet/state')).json()
      return { ok: true, display: s.display, animation: s.animation, sessionActive: s.sessionActive, name: s.name }
    } catch (e) {
      return { ok: false, error: String(e) }
    }
  })
  console.log('API_STATE:', JSON.stringify(apiState, null, 2))

  await page.screenshot({ path: OUT + '/pet-01-initial.png' })

  // ---- 5. Hover panel + hide button
  if (girl.present) {
    const g = await page.evaluate(() => {
      const el = document.querySelector('[aria-label="whale girl"]')
      const r = el.getBoundingClientRect()
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 }
    })
    await page.mouse.move(g.x, g.y)
    await page.waitForTimeout(1500)
    const panel = await page.evaluate(() => {
      const el = document.querySelector('[aria-label="whale girl"]')
      const float = el ? el.parentElement : null
      if (!float) return { present: false }
      const buttons = Array.from(float.querySelectorAll('button')).map((b) => b.textContent.trim())
      return { present: buttons.length > 0, buttons }
    })
    console.log('PANEL:', JSON.stringify(panel, null, 2))
    await page.screenshot({ path: OUT + '/pet-02-hover-panel.png' })

    if (panel.present && panel.buttons.includes('隐藏')) {
      // Record pre-hide state
      const preHide = await page.evaluate(async () => {
        const s = await (await fetch('/api/pet/state')).json()
        return { display: s.display }
      })
      console.log('PRE_HIDE:', JSON.stringify(preHide))
      // Click the hide button
      const hideClick = await page.evaluate(() => {
        const el = document.querySelector('[aria-label="whale girl"]')
        const float = el ? el.parentElement : null
        if (!float) return { clicked: false }
        const btn = Array.from(float.querySelectorAll('button')).find((b) => b.textContent.trim() === '隐藏')
        if (!btn) return { clicked: false }
        btn.click()
        return { clicked: true }
      })
      console.log('HIDE_CLICK:', JSON.stringify(hideClick))
      await page.waitForTimeout(3000)
      const afterHide = await page.evaluate(async () => {
        let state = null
        try { state = (await (await fetch('/api/pet/state')).json()).display } catch (e) { state = { fetchError: String(e) } }
        return {
          girlNow: !!document.querySelector('[aria-label="whale girl"]'),
          summon: !!document.querySelector('[data-testid="pet-summon"]'),
          summonText: document.querySelector('[data-testid="pet-summon"]')?.textContent.trim() ?? null,
          state,
        }
      })
      console.log('AFTER_HIDE:', JSON.stringify(afterHide, null, 2))
      await page.screenshot({ path: OUT + '/pet-03-after-hide.png' })

      // ---- 6. Summon back (click the summon button if present, else API)
      if (afterHide.summon) {
        await page.evaluate(() => {
          const btn = document.querySelector('[data-testid="pet-summon"]')
          if (btn) btn.click()
        })
        await page.waitForTimeout(3000)
      } else {
        await page.evaluate(async () => {
          await fetch('/api/pet/set-visible', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ visible: true }) })
        })
        await page.waitForTimeout(3000)
      }
      const afterRestore = await page.evaluate(async () => ({
        girlNow: !!document.querySelector('[aria-label="whale girl"]'),
        summon: !!document.querySelector('[data-testid="pet-summon"]'),
        state: (await (await fetch('/api/pet/state')).json()).display,
      }))
      console.log('AFTER_RESTORE:', JSON.stringify(afterRestore, null, 2))
      await page.screenshot({ path: OUT + '/pet-04-restored.png' })
    }
  }

  // ---- 7. Overlap geometry between the two pets
  const overlap = await page.evaluate(() => {
    const girl = document.querySelector('[aria-label="whale girl"]')
    const whale = document.querySelector('[data-ventus-whale]')
    if (!girl || !whale) return { both: !!girl && !!whale, girl: !!girl, whale: !!whale }
    const a = girl.getBoundingClientRect()
    const b = whale.getBoundingClientRect()
    const ox = Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left))
    const oy = Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top))
    return {
      both: true,
      overlapping: ox > 0 && oy > 0,
      overlapW: Math.round(ox),
      overlapH: Math.round(oy),
      girlRect: { l: Math.round(a.left), t: Math.round(a.top), r: Math.round(a.right), b: Math.round(a.bottom) },
      whaleRect: { l: Math.round(b.left), t: Math.round(b.top), r: Math.round(b.right), b: Math.round(b.bottom) },
    }
  })
  console.log('OVERLAP:', JSON.stringify(overlap, null, 2))

  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  console.log('FAILED_REQUESTS:', failedRequests.length ? JSON.stringify(failedRequests, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
