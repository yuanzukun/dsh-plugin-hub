// Part 3: corrected queries. The whale portal renders into body directly
// under [data-ventus-whale]; the React root host div stays empty.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(10000)

  // 1. Whale DOM structure + pixel sample from the portal wrapper.
  const whale = await page.evaluate(() => {
    const wrapper = document.querySelector('[data-ventus-whale]')
    if (!wrapper) return { wrapper: false }
    const canvas = wrapper.querySelector('canvas')
    if (!canvas) return { wrapper: true, canvas: false, caption: wrapper.querySelector('[class*=caption]')?.textContent || null }
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    let sample = null
    if (gl) {
      const w = gl.drawingBufferWidth, h = gl.drawingBufferHeight
      const buf = new Uint8Array(w * h * 4)
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf)
      let nonZero = 0, opaque = 0
      for (let i = 0; i < buf.length; i += 4) {
        if (buf[i] || buf[i + 1] || buf[i + 2]) nonZero++
        if (buf[i + 3] > 10) opaque++
      }
      sample = { w, h, nonZeroPx: nonZero, opaquePx: opaque, total: w * h }
    }
    const style = window.getComputedStyle(wrapper)
    return {
      wrapper: true, canvas: true, gl: !!gl, sample,
      position: style.position, right: style.right, left: style.left, bottom: style.bottom,
      wrapperClass: wrapper.className,
      caption: wrapper.querySelector('[class*=caption]')?.textContent || null,
    }
  })
  console.log('WHALE:', JSON.stringify(whale, null, 2))

  // 2. Click 设置 (sidebar bottom).
  const clicked = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('button, [role=button], a, div, span, li'))
    const hit = els.find((el) => el.textContent.trim() === '设置' && el.offsetParent !== null)
    if (hit) { hit.click(); return true }
    return false
  })
  console.log('SETTINGS_CLICKED:', clicked)
  await page.waitForTimeout(6000)

  // 3. Full body text analysis.
  const result = await page.evaluate(() => {
    const text = document.body.innerText
    const lines = text.split('\n').map((l) => l.trim()).filter(Boolean)
    return {
      hasVentusGroup: text.includes('Ventus 插件'),
      hasWebUiGroup: text.includes('Web UI 插件'),
      hasWhaleCard: text.includes('大肥鱼桌宠'),
      hasRange: text.includes('大小') && text.includes('灵敏度'),
      bodyLines: lines.slice(0, 60),
    }
  })
  console.log('SETTINGS:', JSON.stringify({ hasVentusGroup: result.hasVentusGroup, hasWebUiGroup: result.hasWebUiGroup, hasWhaleCard: result.hasWhaleCard, hasRange: result.hasRange }))
  console.log('BODY_LINES:', JSON.stringify(result.bodyLines, null, 2))

  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/03-settings2.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
