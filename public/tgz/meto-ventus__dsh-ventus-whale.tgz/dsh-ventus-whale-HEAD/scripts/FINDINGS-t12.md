# t12 结论：设置保存语义 + 大小滑块生效 + 工具栏两行与转圈按钮

调查者：user 反馈 · 修复日期：2026-08-15

## 1. Ventus 分组描述：家族 → 系列
- 设置页 Ventus 分组卡描述由「Ventus 家族的插件设置」改为「Ventus 系列的插件设置」
  （`src/client/VentusPluginsCard.tsx`，title 属性与文本同步，注释一并改为 series）。

## 2. 设置不再自动保存，新增保存/取消
- 原实现：`WhaleSettingsCard` 每次控件变更立即 `api.update` 写 host（含启用开关）。
- 修复（`src/client/WhaleSettingsCard.tsx`）：
  - 新增 `draft` 草稿状态；所有控件（启用/翻跟头/大小/灵敏度/文字）只写草稿。
  - 「保存」按钮把草稿一次性提交 host API（只提交五个可编辑字段，x/y 自由定位
    经 host `applyPatch` 保留），成功后广播并清空草稿。
  - 「取消」丢弃草稿回到已保存值；草稿与已保存值不同时显示「有未保存的更改」。
  - 虎鲸自身交互（拖拽定位、悬停改名、重置）仍即时持久化，不受设置卡保存语义影响。
- 视觉：`ventus-settings.module.css` 新增 `.actions/.dirtyHint/.saveButton/.cancelButton`。

## 3. 大小滑块失效根因与修复
- 根因（`src/client/whale-model.ts`）：`setScale` 缩放模型后又调用 `fitCamera()`——
  相机距离随模型半径同比拉远，屏幕上鲸鱼大小对 scale 不变（t11 的「任意 scale 完整
  入框」副作用，FINDINGS-t11 §2）。
- 修复：改为**窗口随大小缩放**——`WhalePet` 的画布尺寸 = `PET_SIZE × scale`（176px 基准，t13 由 220 调小 20%），
  模型在画布内保持自然入框比例（相机只在构建时适配一次），屏幕像素尺寸随 scale 线性变化，
  且任何 scale 下鲸鱼始终完整可见、不被画布裁剪（t11 保证保留）。
- 相应移除 `whale-model.ts` 的 `setScale`（接口 + 实现 + `scale` 变量）；`WhalePet` 不再调用。
- 边界：极小 scale（<0.9×）时悬停工具栏/文字会比窗口略宽（用户已确认接受的取舍）。

## 4. 翻转方向修正
- 用户反馈「鲸鱼翻身的方向反了」：`whale-model.ts` 的 flip 旋转角取反
  （`setFromAxisAngle(worldX, -fp * Math.PI * 2)`），虎鲸改为向前翻（前空翻），
  与视觉朝向一致；原来正方向是向后翻。

## 5. 悬停工具栏两行 + 转圈按钮
- `src/client/WhalePet.tsx` 工具栏改为两行：第一行 改名/重置/拖动，第二行 爱心开关/转圈。
- 「转圈」按钮手动触发 `scene.flip()`（360° 前空翻，与发送消息触发的翻跟头同一动画），
  不依赖 `flipOnSend` 开关。
- `whale-pet.module.css`：`.quickToolbar` 改纵向排列，新增 `.toolbarRow`。

## 6. 画幅调小 20%，鲸鱼大小不变（t13）
- `WhalePet.tsx`：`PET_SIZE` 220 → 176（画布 = 176 × scale）。
- `whale-model.ts`：新增 `FRAME_COMPENSATION = 220 / 176`，`fitCamera()` 后
  `rig.model.scale.setScalar(FRAME_COMPENSATION)` —— 画布变小但模型像素尺寸不变；
  动画位移（翻转/跳跃/浮动）是世界坐标偏移、不随模型缩放，相对鲸鱼更紧凑、入框更安全。
- 实测：scale=2 → 画布 352×352（176×2）。

## 7. 悬停工具栏贴紧鲸鱼（t14）
- 原工具栏在画布上方文档流，距鲸鱼头顶约 49px（画布顶部为翻转动画预留 ~45px 留白）。
- 修复（`whale-pet.module.css`）：`.quickToolbar` 改为 `position: absolute; top: 0` 悬浮覆盖
  画布顶部，贴近鲸鱼头部（覆盖约 13px，半透明毛玻璃）；`moveHint` 移到画布下方避免重叠。
- 实测：toolbar 底距画布顶 58px、鲸鱼头顶 ~45px，间距归零。

## 8. 悬停提示挪进设置页
- 用户要求「悬停只有那几个按钮选项」：移除画布容器的 `title` 悬停提示
  （`WhalePet.tsx`），操作说明改为设置卡内常驻的「操作提示」行
  （`WhaleSettingsCard.tsx` + `ventus-settings.module.css .usageHint`）。
- 实测：设置卡 `hasUsageHint:true`，画布 `canvasTitle:null`（verify-t12 断言）。

## t15/t16 追加
- t15：保存不再让虎鲸消失——设置卡挂载时拉取实时持久化配置（预取缓存可能早于侧边栏
  召唤/隐藏而过期，曾导致保存把过期 enabled 写回）；所有写入方（pet/sidebar）同步
  共享缓存；草稿阶段通过 `WHALE_PREVIEW_EVENT` 实时预览缩放，「取消」还原。
- t16：翻转方向最终确认为「原始动画 + 方向取反」（绕世界 X 轴 -fp 前空翻）；撤销
  头顶自转方案。预览 GIF 重录为 500×500 / 256 色 / sierra2_4a 高清版。

## 构建与验证
- `pnpm build`（tsc + tsdown）+ `pnpm verify`（typecheck + smoke-host/client/load）。
- `scripts/verify-interact.cjs` 更新为新保存语义：拖滑块 → `/api/ventus-whale/state`
  不变；点「保存」→ state 反映新值；末尾恢复原 scale。
- 浏览器实测：Ventus 描述文案、设置卡保存按钮、滑块改窗口尺寸、工具栏两行与转圈。

## 改动文件
- `src/client/VentusPluginsCard.tsx`（家族→系列）
- `src/client/WhaleSettingsCard.tsx`（草稿 + 保存/取消）
- `src/client/WhalePet.tsx`（窗口随 scale 缩放、工具栏两行、转圈按钮）
- `src/client/whale-model.ts`（移除 setScale，相机仅构建时适配）
- `src/client/ventus-settings.module.css`、`src/client/whale-pet.module.css`
- `README.md`、`scripts/verify-interact.cjs`、`scripts/FINDINGS-t12.md`