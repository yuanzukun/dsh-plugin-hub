# t8+t9 结论：UI 调整 + 设置卡片即时显示（ventus-whale）

调查者：ventus-engineer · 修复日期：2026-08-15 · 证据脚本 `scripts/verify-t8t9.cjs`、`scripts/verify-t9-prefetch.cjs`（浏览器实测，会还原现场状态）

## t8 UI 调整

1. **删除「与鲸鱼少女桌宠各占一角互不遮挡」**：源码（WhaleSettingsCard 停靠项 hint）与 README 均已清除；CSS 共存注释改为中立表述。
2. **删除「停靠位置」设置项**：设置卡片移除 dock 控件；类型（protocol.ts WhaleConfig.dock）、host 持久化（host.ts）、patch（routes.ts）、settings schema（src/index.ts）、WhalePet 定位逻辑全部清理。鲸鱼固定停靠左下角（自由拖拽 x/y 优先的既有逻辑保留）。
3. **召唤按钮开关化**：侧边栏底部 🐋 按钮改为 toggle——监听 config 状态（初始 fetch + WHALE_CONFIG_EVENT），虎鲸显示时显示「隐藏虎鲸」、隐藏时显示「召唤虎鲸」，点击翻转 enabled。工具栏「隐藏」按钮删除（hidePet 函数一并移除）。已实测：召唤→显示、再点→隐藏，按钮文案同步切换。
4. 顺带清理：停靠相关死 CSS（.segmented/.segment/.segmentActive）、README 中 outdated 的 bundle 体积（765KB→470KB）与使用说明。

## t9 设置卡片即时显示

### 根因（对照研究结论）
- **注册路径没有差异**：ventus（settings.plugin.item 组卡片 + ventus.plugin.item 子卡片）与 webui（web-ui.plugin.item）都走 slots 注入，挂载机制相同。
- **真正的差异是数据源与时序**：
  - webui 卡片的数据来自 **settings transport**（dsh-live-stats 等用 `ctx.settingsScope`/webUiSettings binder），在**插件激活时**（页面加载早期）就开始加载（RPC），打开设置时数据已 ready → 卡片立即渲染。
  - ventus 卡片此前用 `fetch('/api/ventus-whale/state')`，**打开设置那一刻**才发起；硬刷新后页面在下载 ~8MB 的插件 bundle 与 whale-girl WebP，host 事件循环拥塞 → HTTP fetch 排队数秒 → 卡片 `config === null` → 渲染 null（不显示）。t3 实测：打开设置 6-15s 卡片仍不出现。
- **为什么 ventus 不能直接复用 webui 的 settings scope**（已深入核实）：
  1. 官方 settings RPC（host-apiproxy）的 allowlist **硬编码**，第三方 namespace 一律返回 `unavailable`（`settings-not-exposed`）——webui 自己也是靠 `dsh-web-ui-settings` 的 bridge（`/api/dsh-web-ui-settings`）绕过。
  2. webui bridge 的 allowlist（`FAMILY_NAMESPACES`）**不含 ventus-whale**，且 `resolveNamespaceEntry` 不认该名字——复用 bridge 也拿不到数据；改 web-ui 仓库是红线。
- 所以 ventus 采用**等效时序**的轻量方案：激活时预取 + 共享 store + 卡片永不空渲染。

### 修复（`src/client/whale-config-store.ts` 新增 + 卡片/入口改造）
- **`whale-config-store.ts`**：模块级 config 缓存（snapshot + subscribe + 幂等预取 `ensureConfigLoaded`）。
- **入口 `index.tsx`**：apply 时调用 `ensureConfigLoaded()`——与 webui 卡片「激活时预载」同一时序。
- **WhalePet**：自身加载成功后 `publishConfig` 写入缓存（同一数据源）。
- **WhaleSettingsCard**：`useSyncExternalStore` 订阅缓存；渲染值优先级 = 本地保存/广播 config > 预取缓存 > 默认值；**loading 时用默认值占位渲染（附「读取中…」），unavailable 时给「设置不可用」说明——永远不返回 null**；写路径不变（/api/ventus-whale/update 返回完整 config 含 x/y，广播安全）。

### 实测数据
| 场景 | t3 时代 | t9 后 |
|---|---|---|
| 打开设置→插件后卡片出现 | 6-15s 不出现 / 10s 超时 | **~257ms** |
| 挂起 /api/ventus-whale/state（fetch 永不返回） | 卡片永远空白 | **0ms 出现**（默认值占位 + 读取中） |
| 卡片内容 | — | 3 滑杆 + 输入框 + 开关，真实值（enabled 状态正确反映） |

## 构建与验证
- `pnpm build` ✓（lib/client.js：t3 后 470,870 → t8+t9 后 **470,333 B**，gzip 123.44 kB）
- `pnpm run typecheck` ✓；`smoke-host/client/load` ✓
- `scripts/verify-t8t9.cjs` ✓（t8 三项 + t9 时序 + summon toggle + 状态还原）
- `scripts/verify-t9-prefetch.cjs` ✓（挂起 fetch 证明卡片不依赖打开时的 HTTP 请求）

## 改动文件
- `src/client/WhaleSettingsCard.tsx`（t8: 删停靠/文案；t9: store 驱动即时渲染）
- `src/client/WhalePet.tsx`（t8: 删隐藏按钮与 hidePet；t9: publishConfig）
- `src/client/WhaleSidebarEntry.tsx`（召唤→toggle，状态感知）
- `src/client/index.tsx`（激活时预取）
- `src/client/whale-config-store.ts`（新增共享缓存）
- `src/protocol.ts` / `src/host.ts` / `src/routes.ts` / `src/index.ts`（删 dock）
- `src/client/ventus-settings.module.css`（删死 CSS）、`src/client/whale-pet.module.css`（注释）
- `README.md`、`scripts/smoke-client.mjs`（t3 时已改）、`scripts/verify-t8t9.cjs` + `verify-t9-prefetch.cjs`（新增）
- 备份：`DSH_Anything/.t8-backup-ventus/`、`.t9-backup-ventus/`

## 残留风险
- 预取失败（unavailable）时卡片显示「设置不可用」；刷新页面可恢复（预取重试）。
- loading 占位期显示默认值，若真实配置不同会短暂闪烁（有「读取中…」标记），预取完成后即刷新。
- 召唤 toggle 的写等待服务器确认（非乐观），繁忙 host 下点击到切换有数百 ms 延迟；与 t3 的乐观隐藏取舍不同（toggle 需要服务器返回完整 config 才能正确广播）。
