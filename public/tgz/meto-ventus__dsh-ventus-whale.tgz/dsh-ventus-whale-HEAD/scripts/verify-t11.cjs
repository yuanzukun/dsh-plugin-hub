// t11 verification v3 (robust): z-index, model in frame, edge clamp, frame-skip.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const errors = []
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + String(e).slice(0, 200)))

  const waitWhale = async (timeoutMs = 12000) => {
    const t0 = Date.now()
    while (Date.now() - t0 < timeoutMs) {
      const has = await page.evaluate(() => {
        const w = document.querySelector('[data-ventus-whale]')
        return !!(w && getComputedStyle(w).display !== 'none' && w.querySelector('canvas'))
      }).catch(() => false)
      if (has) return true
      await page.waitForTimeout(400)
    }
    return false
  }

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(2500)
  const orig = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('ORIG:', JSON.stringify(orig))

  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: true, x: null, y: null }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await waitWhale()
  console.log('WHALE_READY: true')

  // A. z-index + pixel margins
  let a = null
  for (let attempt = 0; attempt < 6 && (a === null || a.pixels === null || a.pixels.opaque === 0); attempt++) {
    await page.waitForTimeout(900)
    a = await page.evaluate(() => new Promise((resolve) => {
      const wrapper = document.querySelector('[data-ventus-whale]')
      if (!wrapper) { resolve({ wrapperZ: null, pixels: null }); return }
      const canvas = wrapper.querySelector('canvas')
      const ws = getComputedStyle(wrapper)
      const gl = canvas.getContext('webgl2') || canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
      requestAnimationFrame(() => {
        let pixels = null
        if (gl) {
          const w = gl.drawingBufferWidth, h = gl.drawingBufferHeight
          const buf = new Uint8Array(w * h * 4)
          gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf)
          let minX = w, minY = h, maxX = -1, maxY = -1, opaque = 0
          for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
            const i = (y * w + x) * 4
            if (buf[i + 3] > 10) {
              opaque++
              if (x < minX) minX = x
              if (x > maxX) maxX = x
              if (y < minY) minY = y
              if (y > maxY) maxY = y
            }
          }
          pixels = {
            canvas: w + 'x' + h, opaque,
            modelBox: { minX, minY, maxX, maxY },
            marginLeft: minX, marginTop: minY,
            marginRight: w - 1 - maxX, marginBottom: h - 1 - maxY,
          }
        }
        resolve({ wrapperZ: ws.zIndex, pixels })
      })
    }))
  }
  console.log('A_Z_AND_FRAME:', JSON.stringify(a))

  // B. Drag to left edge; B2. toward bottom edge (both try/catch)
  try {
    const wb = await page.locator('[data-ventus-whale]').boundingBox()
    if (wb) {
      await page.mouse.move(wb.x + wb.width / 2, wb.y + wb.height / 2)
      await page.waitForTimeout(500)
      await page.mouse.down({ button: 'right' })
      await page.mouse.move(5, wb.y + wb.height / 2, { steps: 8 })
      await page.mouse.up({ button: 'right' })
      await page.waitForTimeout(1500)
      const left = await page.evaluate(() => {
        const wrapper = document.querySelector('[data-ventus-whale]')
        const r = wrapper.getBoundingClientRect()
        const top = document.elementFromPoint(r.x + 5, r.y + r.height * 0.5)
        return {
          rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) },
          inViewport: r.x >= 0 && r.y >= 0 && r.right <= innerWidth && r.bottom <= innerHeight,
          hitInWhale: top ? !!top.closest('[data-ventus-whale]') : false,
        }
      })
      console.log('B_LEFT_EDGE:', JSON.stringify(left))

      try {
        await page.mouse.move(left.rect.x + left.rect.width / 2, left.rect.y + left.rect.height / 2)
        await page.waitForTimeout(300)
        await page.mouse.down({ button: 'right' })
        await page.mouse.move(left.rect.x + left.rect.width / 2, 700, { steps: 5 })
        await page.mouse.move(left.rect.x + left.rect.width / 2, 860, { steps: 5 })
        await page.mouse.up({ button: 'right' })
        await page.waitForTimeout(1500)
        const bottom = await page.evaluate(() => {
          const wrapper = document.querySelector('[data-ventus-whale]')
          const r = wrapper.getBoundingClientRect()
          return {
            rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) },
            inViewport: r.x >= 0 && r.y >= 0 && r.right <= innerWidth && r.bottom <= innerHeight,
          }
        })
        console.log('B2_BOTTOM_EDGE:', JSON.stringify(bottom))
      } catch (dragError) {
        console.log('B2_SKIPPED:', String(dragError).slice(0, 120))
      }
    }
  } catch (bError) {
    console.log('B_SKIPPED:', String(bError).slice(0, 120))
  }

  // C. Off-viewport saved position -> render clamp keeps it visible
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ x: 99999, y: 99999 }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await waitWhale()
  const corner = await page.evaluate(() => {
    const wrapper = document.querySelector('[data-ventus-whale]')
    const r = wrapper.getBoundingClientRect()
    return {
      rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) },
      inViewport: r.x >= 0 && r.y >= 0 && r.right <= innerWidth && r.bottom <= innerHeight,
    }
  })
  console.log('C_OFF_VIEWPORT:', JSON.stringify(corner))

  // restore position for remaining checks
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ x: 300, y: 300, enabled: true }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await waitWhale()

  // D. Idle frame-skip vs hover full rate
  await page.evaluate(() => {
    const canvas = document.querySelector('[data-ventus-whale] canvas')
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl')
    window.__drawCount = 0
    const orig = gl.drawElements.bind(gl)
    gl.drawElements = (...args) => { window.__drawCount++; return orig(...args) }
  })
  await page.waitForTimeout(3000)
  const idle = await page.evaluate(() => ({ draws3s: window.__drawCount, drawsPerSec: Math.round(window.__drawCount / 3) }))
  console.log('D_IDLE_DRAWS:', JSON.stringify(idle))
  try {
    const wb3 = await page.locator('[data-ventus-whale]').boundingBox().catch(() => null)
    if (wb3) {
      await page.mouse.move(wb3.x + wb3.width / 2, wb3.y + wb3.height / 2)
      await page.waitForTimeout(2000)
      const hover = await page.evaluate(() => ({ draws2s: window.__drawCount, drawsPerSec: Math.round(window.__drawCount / 2) }))
      console.log('E_HOVER_DRAWS:', JSON.stringify(hover))
    }
  } catch (eError) {
    console.log('E_SKIPPED:', String(eError).slice(0, 120))
  }

  // Restore: original position + enabled:false
  await page.evaluate(async (o) => {
    const body = { enabled: false }
    if (o.x !== undefined) body.x = o.x
    if (o.y !== undefined) body.y = o.y
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
  }, orig)
  const restored = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('RESTORED:', JSON.stringify(restored))
  console.log('ERRORS:', JSON.stringify(errors.slice(0, 5)))
  await browser.close()
})().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
