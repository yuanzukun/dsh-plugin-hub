/**
 * Host-side smoke: import the built host half and drive `apply` with a fake
 * context to prove routes register without throwing. The settings section
 * wiring is best-effort (guarded in apply), so the stub context only needs
 * webServer + effect.
 */
const pkg = await import('../lib/index.js')

console.log('name:', pkg.name)
console.log('inject:', JSON.stringify(pkg.inject))
console.log('Config callable:', typeof pkg.Config === 'function')
console.log('DEFAULT_CONFIG present:', typeof pkg.DEFAULT_CONFIG === 'object')

const registered = []
const effects = []
const fakeCtx = {
  effect(fn, label) {
    effects.push(label)
    const dispose = fn()
    return () => { if (typeof dispose === 'function') dispose() }
  },
  webServer: {
    register(route) {
      registered.push(route.path)
      return () => { const i = registered.indexOf(route.path); if (i >= 0) registered.splice(i, 1) }
    },
  },
  logger: { warn: () => {} },
}

pkg.apply(fakeCtx, { enabled: true })

console.log('registered routes:', JSON.stringify(registered))
console.log('effects:', JSON.stringify(effects))

const expected = [
  '/api/ventus-whale/state',
  '/api/ventus-whale/update',
  '/api/ventus-whale/reset',
]
const ok = expected.every(p => registered.includes(p))
console.log(ok ? 'VENTUS HOST SMOKE OK' : 'VENTUS HOST SMOKE FAILED')
process.exit(ok ? 0 : 1)
