/**
 * Runtime smoke for the ventus-whale client bundle: loads lib/client.js in a
 * VM with browser stubs and runs the plugin apply() to catch load-time and
 * mount-time errors (React render errors surface as exceptions here).
 */
import { readFileSync } from 'node:fs'
import vm from 'node:vm'

const code = readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8')

const listeners = new Map()
const elements = []

function makeElement(tag) {
  const el = {
    tagName: tag.toUpperCase(),
    dataset: {},
    style: {},
    className: '',
    children: [],
    attrs: new Map(),
    parent: null,
    appendChild(child) { child.parent = el; this.children.push(child); return child },
    remove() { if (this.parent) { const i = this.parent.children.indexOf(this); if (i >= 0) this.parent.children.splice(i, 1) } },
    setAttribute(k, v) { this.attrs.set(k, String(v)) },
    removeAttribute(k) { this.attrs.delete(k) },
    getAttribute(k) { return this.attrs.get(k) ?? null },
    querySelector() { return null },
    querySelectorAll() { return [] },
    getBoundingClientRect() { return { left: 0, top: 0, width: 220, height: 220 } },
    setPointerCapture() {}, releasePointerCapture() {},
    addEventListener() {}, removeEventListener() {},
    get clientWidth() { return 220 }, get clientHeight() { return 220 },
  }
  elements.push(el)
  return el
}

const documentStub = {
  body: { appendChild() {}, removeChild() {} },
  head: { appendChild() {} },
  documentElement: {
    dataset: {},
    style: { setProperty() {}, removeProperty() {} },
    setAttribute() {}, removeAttribute() {},
  },
  createElement: makeElement,
  addEventListener(type, fn) { listeners.set(type, fn) },
  removeEventListener(type) { listeners.delete(type) },
  querySelector() { return null },
}

const context = {
  window: {
    __ModuleLoader__: {
      load(entry) {
        const module = { exports: {} }
        const require = (spec) => {
          const stubs = {
            'react': { createElement: () => ({}), useState: (v) => [v, () => {}], useEffect: () => {}, useRef: (v) => ({ current: v }), useMemo: (f) => f(), createPortal: (node) => node, Fragment: 'fragment' },
            'react/jsx-runtime': { jsx: () => ({}), jsxs: () => ({}) },
            'react-dom': { createPortal: (node) => node },
            'react-dom/client': { createRoot: () => ({ render() {}, unmount() {} }) },
            '@deepseek-ai/cordis': {},
          }
          if (spec in stubs) return stubs[spec]
          if (spec === 'three') {
            // Minimal three stub so module top-level code parses; the pet
            // mount path (createWhaleScene) is not exercised deeply here.
            return new Proxy({}, { get: () => () => ({}) })
          }
          throw new Error(`unexpected require: ${spec}`)
        }
        entry.factory(require)
        return module.exports
      },
    },
    addEventListener() {}, removeEventListener() {}, requestAnimationFrame() {}, devicePixelRatio: 1,
  },
  document: documentStub,
  CustomEvent: class { constructor(type, init) { this.type = type; this.detail = init?.detail } },
  MutationObserver: class { observe() {} disconnect() {} },
  ResizeObserver: class { observe() {} disconnect() {} },
  localStorage: { getItem: () => null, setItem: () => {}, },
  console,
  setTimeout, clearTimeout,
}

vm.createContext(context)
try {
  vm.runInContext(code, context)
  console.log('BUNDLE LOAD OK — no syntax/runtime error at load time')
} catch (error) {
  console.error('BUNDLE LOAD FAILED:', error.message)
  process.exit(1)
}
