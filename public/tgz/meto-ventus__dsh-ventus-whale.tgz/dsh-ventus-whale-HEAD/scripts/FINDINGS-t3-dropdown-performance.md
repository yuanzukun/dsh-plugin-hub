# t3 结论：设置下拉框打不开 + 3D 性能（ventus-whale）

调查者：ventus-engineer · 修复日期：2026-08-15 · 证据脚本 `scripts/verify-t3.cjs`（浏览器实测，会还原现场状态）

## 1. 「设置里下拉框打不开」根因与修复

### 根因（浏览器实测确认）
- 设置 → 插件 里的 **Ventus 插件 组卡片**默认展开（aria-expanded=true），其子卡片
  **大肥鱼桌宠 设置卡片**有渲染，但**默认处于折叠态**：折叠态被持久化到 localStorage
  `ventus-card-collapsed`，历史会话/测试留下 `'1'`，之后每次进入设置都只看到
  「大肥鱼桌宠 | 已停用 | ▾」，滑杆/输入框/停靠按钮全部不可见 → 用户视角就是
  「下拉框打不开 / 设置打不开」。
- 放大因素：组卡片头部那个 ▾（已展开状态）被点击后是**收起**整个组，用户点它期望
  「打开下拉」，结果内容反而消失，进一步坐实「打不开」的观感。
- 排除项：shell 自带的 aria-haspopup 下拉（插话发送 等）用真实鼠标点击**正常**打开
  （此前用 el.click() 测出假阴性，真实 click 事件不触发 mousedown/pointerdown）。
  虎鲸画布与设置对话框的 z-index/重叠也与本症状无关（当前 enabled:false 时 wrapper
  是 display:none，不拦截任何事件）。

### 修复（`src/client/WhaleSettingsCard.tsx`）
- 折叠态改为**会话内纯视觉状态，默认展开**：`useState(false)`，不再读写
  localStorage。设置内容每次进入都能看到；▾ 折叠/展开功能保留。
- 已浏览器验证：打开 设置→插件 即见卡片展开（aria-label=`收起设置`，
  3 个滑杆 + 显示文字输入框 + 停靠位置按钮可见）。

## 2. 3D 性能

### 2a. 几何精简（`src/client/whale-model.ts`）
| 项 | 前 | 后 |
|---|---|---|
| 身体 SWEPT_SLICES × RINGS | 60×48 | **36×24** |
| 身体顶点数 | 2,928 | **888**（-70%） |
| 身体三角形数 | 5,760 | **1,728**（-70%） |
| 眼睛圆分段 | 32 | 20 |
| 眉/背鳍/尾/胸鳍采样 | 40/40/60/30 | 20/20/24/16 |
| 身体轮廓重采样点 | 800 | 400（仅构建期） |
| 全模型三角形估计 | ~10.8k | ~3.9k（约 -64%） |

220px 桌宠尺寸下肉眼无差；渲染与射线命中都更快。

### 2b. bundle 体积（`tsdown.config.ts` + `whale-model.ts`）
- `lib/client.js`：**810,919 → 470,870 字节（-42%；gzip 123.45 kB）**。
- 手段：客户端配置开启 `minify: true`（此前整个 bundle 未压缩，three 源码 1.17MB
  原样内联）。
- **three.js 外部化不可行**（已核实）：宿主 shell 平台模块表
  （harness `packages/client/web/src/platform.ts` 与 web-ui `shared/web-platform.ts`）
  都没有 `three`；外部化后运行时 `require('three')` 会抛
  `client-modules: require missed the module table`，虎鲸直接不显示。
  而修改 shell/web-ui 在本任务红线之外 → 放弃外部化。
- 命名导入（`import * as THREE` → 具名导入）对 three@0.147 单文件版
  `three.module.js` 无 tree-shaking 收益（实测 811,265 ≈ 810,919），但保留：
  语义更清晰、对未来模块化 three 版本无害。

### 2c. 「点隐藏反应半天」修复（`WhalePet.tsx` + `whale-model.ts`）
- **乐观隐藏**：点「隐藏」立即置本地状态+广播（display:none 即时生效），持久化在
  后台完成；此前先等服务器确认，host 繁忙时（其他插件 API/大请求占住事件循环）
  实测点击到隐藏要 3.4s。修复后实测 **166ms**。
- **停用时暂停渲染循环**：此前 display:none 后 rAF 仍每帧渲染（空转 GPU/CPU，
  拖慢整页、连带 webui 隐藏也卡）；现在 enabled:false → scene.pause()，
  恢复时 resume() 并重测容器尺寸。
- **悬停射线命中按帧节流**：此前每次 pointermove 都对全模型递归相交测试
  （几何未精简前 ~10k 三角）；现在每帧至多一次。
- 页面加载：client.js 体积 -42%，主线程解析/执行更少（实测加载中该 bundle
  transferSize 470,984 B 已被服务器提供）。

## 3. 构建与验证
- `pnpm build` ✓（tsc + tsdown）；`pnpm run typecheck` ✓
- `scripts/smoke-host.mjs` ✓、`smoke-load.mjs` ✓
- `smoke-client.mjs` ✓ —— 其中「whale model builder」检查原依赖函数名
  `buildWhaleRig`/`buildSwept`，minify 后改名导致误报，已改为压缩安全的
  字符串标记（着色器模板串内的汉字注释）。
- `scripts/smoke-geometry.mjs`：**既有失败，与本任务无关**——它 import
  `lib/client/whale-model.js`，而 tsconfig.build.json 是 declaration-only
  （`emitDeclarationOnly: true`），该文件从未被生成过。
- 浏览器验证（`scripts/verify-t3.cjs`）：设置卡片默认展开 ✓；虎鲸 canvas 220×220
  正常渲染 ✓；隐藏延迟 166ms ✓；测试后精确还原现场状态 ✓。

## 改动文件
- `src/client/WhaleSettingsCard.tsx`（默认展开，去 localStorage 持久化）
- `src/client/WhalePet.tsx`（乐观隐藏；停用暂停渲染循环）
- `src/client/whale-model.ts`（具名 three 导入；几何密度 60×48→36×24 等；
  悬停射线按帧节流；resume 重测尺寸）
- `tsdown.config.ts`（客户端 minify: true）
- `scripts/smoke-client.mjs`（whale model builder 检查改为压缩安全标记）
- `scripts/verify-t3.cjs`（新增验证脚本）
- 备份：`DSH_Anything/.t3-backup-ventus/`

## 残留风险
- 隐藏持久化失败时本地已隐藏、服务器仍启用：下次刷新纠正（与修复前失败模式相同量级）。
- 乐观隐藏与「召唤」快速交替时存在最后写入胜出的常规竞态，无数据损坏。
- three 内联仍占 470KB（宿主无 three 平台模块，无法外部化）；后续若 shell 提供
  `three` 平台模块，可改回 external 进一步瘦身。
