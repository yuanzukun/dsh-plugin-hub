/**
 * Determine body orientation: build the swept xs/mid/rad exactly like
 * buildSwept and check which x end is the head (larger radius = head?).
 */
import { createRequire } from 'node:module'
const require = createRequire(import.meta.url)
const THREE = require('E:/ProgramData/deepseek-harness/DSH_Anything/dsh-ventus-whale/node_modules/three')

const BODY_PATH = 'M 144.00 80.00 C 144.67 84.83, 143.00 95.34, 141.00 102.00 C 139.00 108.66, 136.50 113.84, 132.00 120.00 C 127.50 126.16, 119.66 134.34, 114.00 139.00 C 108.34 143.66, 103.49 146.17, 98.00 148.00 C 92.51 149.83, 87.83 150.83, 81.00 150.00 C 74.17 149.17, 63.83 146.66, 57.00 143.00 C 50.17 139.34, 44.50 134.16, 40.00 128.00 C 35.50 121.84, 31.83 113.16, 30.00 106.00 C 28.17 98.84, 28.17 90.99, 29.00 85.00 C 29.83 79.01, 32.17 74.50, 35.00 70.00 C 37.83 65.50, 41.67 61.00, 46.00 58.00 C 50.33 55.00, 56.01 53.00, 61.00 52.00 C 66.00 51.00, 70.51 51.00, 76.00 52.00 C 81.49 53.00, 85.34 52.34, 94.00 58.00 C 102.66 63.66, 120.84 83.50, 128.00 86.00 C 135.16 88.50, 134.34 74.00, 137.00 73.00 C 139.66 72.00, 143.33 75.17, 144.00 80.00 Z'

function sampleSvgPath(d, stepsPerSegment = 40) {
  const toks = d.match(/[MLCZ]|[-+]?\d*\.?\d+(?:e[-+]?\d+)?/gi)
  let i = 0, x = 0, y = 0
  const pts = []
  const num = () => parseFloat(toks[i++])
  const bez = (t, p0, p1, p2, p3) => {
    const mt = 1 - t
    return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3
  }
  while (i < toks.length) {
    const c = toks[i++].toUpperCase()
    if (c === 'M' || c === 'L') { x = num(); y = num(); pts.push({ x, y }) }
    else if (c === 'C') {
      const c1x = num(), c1y = num(), c2x = num(), c2y = num(), ex = num(), ey = num()
      for (let s = 1; s <= stepsPerSegment; s++) {
        const t = s / stepsPerSegment
        pts.push({ x: bez(t, x, c1x, c2x, ex), y: bez(t, y, c1y, c2y, ey) })
      }
      x = ex; y = ey
    }
  }
  return pts
}

const raw = sampleSvgPath(BODY_PATH, 50)
let cx = 0, cy = 0
for (const p of raw) { cx += p.x; cy += p.y }
cx /= raw.length; cy /= raw.length
console.log('body center cx,cy =', cx.toFixed(1), cy.toFixed(1))

// The raw path: where is the head? Print the extremes.
const maxXPt = raw.reduce((a, b) => a.x > b.x ? a : b)
const minXPt = raw.reduce((a, b) => a.x < b.x ? a : b)
console.log('max x point (likely head):', maxXPt.x.toFixed(1), maxXPt.y.toFixed(1))
console.log('min x point (likely tail):', minXPt.x.toFixed(1), minXPt.y.toFixed(1))

// Check the body contour shape: x=144 is top-right (head), x=29 is left (tail).
// In the swept body, xs = (x - cx) * 1.1, so head = +65 end, tail = -62 end.
// The brow x=121..146 (head side) → (p.x - cx) positive → +22..+38 (before offset).
// With offset -35.4 → -13..+5 → lands near the CENTER, slightly tail-ward.
// The reference offsets assume body xs WITHOUT 1.1 and WITHOUT the sign flip?
// Compute what px the reference would produce against unscaled body xs.
const BROW_SCALE = 0.65, BROW_OFFSET_X = -35.4
const browRaw = sampleSvgPath('M 146.00 127.00 C 144.34 128.00, 138.50 129.50, 136.00 129.00 C 133.50 128.50, 131.83 126.33, 131.00 124.00 C 130.17 121.67, 131.67 117.16, 131.00 115.00 C 130.33 112.84, 128.33 111.67, 127.00 111.00 C 125.67 110.33, 124.00 111.33, 123.00 111.00 C 122.00 110.67, 121.17 109.83, 121.00 109.00 C 120.83 108.17, 120.50 106.67, 122.00 106.00 C 123.50 105.33, 127.84 104.67, 130.00 105.00 C 132.16 105.33, 133.00 106.17, 135.00 108.00 C 137.00 109.83, 140.17 113.50, 142.00 116.00 C 143.83 118.50, 145.33 121.17, 146.00 123.00 C 146.67 124.83, 147.66 126.00, 146.00 127.00 Z', 40)

// Where is the brow's dent (lowest y = eye position)?
const dent = browRaw.reduce((a, b) => a.y < b.y ? a : b)
console.log('brow dent (lowest):', dent.x.toFixed(1), dent.y.toFixed(1))

// Reference mapping: px = (p.x - cx) * 0.65 + (-35.4)  [NO 1.1, NO mirror]
const refPxs = browRaw.map(p => (p.x - cx) * BROW_SCALE + BROW_OFFSET_X)
console.log('reference px range:', Math.min(...refPxs).toFixed(1), '→', Math.max(...refPxs).toFixed(1))
// Body unscaled xs (NO 1.1): (p.x - cx) → -62..65? No: without 1.1 it is (x-cx) → -56..58.
console.log('→ body unscaled xs would be ≈', (minXPt.x - cx).toFixed(1), '→', (maxXPt.x - cx).toFixed(1))
console.log('→ reference eye lands at x fraction:', ((Math.max(...refPxs) - (minXPt.x - cx)) / ((maxXPt.x - cx) - (minXPt.x - cx))).toFixed(2), '(0=tail, 1=head)')
