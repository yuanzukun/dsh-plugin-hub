/**
 * Client-side smoke: verify the built client bundle contains the whale
 * model, the settings group, and the pet mount, and that its externals only
 * reference platform modules.
 */
import { readFileSync } from 'node:fs'

const client = readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8')

const checks = [
  ['three.js inlined', client.includes('WebGLRenderer')],
  // t3: bundle 开启 minify 后内部函数名被压缩改名，改用压缩安全的字符串标记
  // （着色器模板串里的汉字注释在字符串内，压缩后原样保留）。
  ['whale model builder', client.includes('腹部白色图案') || client.includes('swept')],
  ['transparent clear color', client.includes('setClearColor')],
  ['Ventus settings page', client.includes('ventus.settings.item')],
  ['大肥鱼桌宠 card', client.includes('大肥鱼桌宠')],
  ['size slider', client.includes('大小')],
  ['sensitivity slider', client.includes('灵敏度')],
  ['caption field', client.includes('显示文字')],
  ['pet portal mount', client.includes('ventusWhaleHost')],
  ['hover toolbar rename', client.includes('改名')],
  ['heart burst scene api', client.includes('burstHearts')],
  ['api routes', client.includes('/api/ventus-whale/state')],
  ['loader banner', client.includes('__ModuleLoader__.load')],
]

let failed = false
for (const [name, ok] of checks) {
  console.log(`${ok ? '✓' : '✗'} ${name}`)
  if (!ok) failed = true
}

// Externals must only be platform modules (react etc.), never @deepseek-ai
// cross-plugin value imports or other packages.
const externals = [...client.matchAll(/require\("([^"]+)"\)/g)].map(m => m[1])
const nonPlatform = [...new Set(externals)].filter(spec =>
  !['react', 'react/jsx-runtime', 'react-dom', 'react-dom/client', '@deepseek-ai/cordis',
    '@deepseek-ai/dsh-client-ui-slots', '@deepseek-ai/dsh-client-runtime/client',
    '@deepseek-ai/dsh-client-web-react', '@deepseek-ai/dsh-client-ui-primitives',
    '@deepseek-ai/dsh-client-ui-attachment', '@deepseek-ai/dsh-client-schema-form',
  ].includes(spec))
console.log(`externals: ${[...new Set(externals)].join(', ') || 'none'}`)
if (nonPlatform.length > 0) {
  console.log(`✗ non-platform externals: ${nonPlatform.join(', ')}`)
  failed = true
} else {
  console.log('✓ all externals are platform modules')
}

if (failed) {
  console.error('VENTUS CLIENT SMOKE FAILED')
  process.exit(1)
}
console.log('VENTUS CLIENT SMOKE OK')
