// Part 9: patience-based expansion diagnosis: open settings -> 插件 ->
// click the Ventus group header, wait longer, dump the dialog's plugin list.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(9000)
  await page.getByRole('button', { name: /设置/ }).first().click({ timeout: 10000 })
  await page.waitForTimeout(3000)

  // 插件 nav click.
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const rows = Array.from(d.querySelectorAll('button, [role=button], div, span'))
    const hit = rows.find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(4000)

  // Dump all buttons with aria-expanded and the plugin list text BEFORE expanding.
  const before = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const btns = Array.from(d.querySelectorAll('button[aria-expanded]')).map((b) => ({
      label: b.getAttribute('aria-label') || b.textContent.trim().slice(0, 40),
      expanded: b.getAttribute('aria-expanded'),
    }))
    const text = d.innerText
    return { btns, hasVentus: text.includes('Ventus 插件'), hasWebUi: text.includes('Web UI 插件') }
  })
  console.log('BEFORE:', JSON.stringify(before, null, 2))

  // Click the Ventus header via aria-label containing 'Ventus'.
  const clicked = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const btns = Array.from(d.querySelectorAll('button[aria-expanded]'))
    const hit = btns.find((b) => (b.getAttribute('aria-label') || '').includes('Ventus'))
    if (hit) { hit.click(); return hit.getAttribute('aria-label') }
    return null
  })
  console.log('CLICKED:', clicked)
  await page.waitForTimeout(6000)

  const after = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const text = d ? d.innerText : ''
    return {
      hasWhaleCard: text.includes('大肥鱼桌宠'),
      hasRange: text.includes('大小') && text.includes('灵敏度'),
      lines: text.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 60),
    }
  })
  console.log('AFTER:', JSON.stringify(after, null, 2))
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/09-expanded.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
