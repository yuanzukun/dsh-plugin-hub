// Deep-dive: why is the whale-girl spritesheet background never applied?
const path = require('path')
const fs = require('fs')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

const OUT = 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify'
fs.mkdirSync(OUT, { recursive: true })

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const logs = []
  const network = []
  page.on('console', (m) => logs.push(`[${m.type()}] ${m.text().slice(0, 300)}`))
  page.on('request', (r) => { if (r.url().includes('/pet/whale')) network.push(`REQ ${r.url()}`) })
  page.on('response', (r) => { if (r.url().includes('/pet/whale')) network.push(`RES ${r.status()} ${r.url()}`) })
  page.on('requestfailed', (r) => { if (r.url().includes('/pet/whale')) network.push(`FAIL ${r.url()} :: ${r.failure()?.errorText}`) })

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(12000)

  // All resource entries mentioning pet/whale
  const resEntries = await page.evaluate(() => performance.getEntriesByType('resource')
    .filter((e) => e.name.includes('/pet/whale'))
    .map((e) => ({ name: e.name.split('/').pop(), transferSize: e.transferSize, duration: Math.round(e.duration) })))
  console.log('RES_ENTRIES:', JSON.stringify(resEntries, null, 2))

  // Count whale-girl elements + body portal list
  const dom = await page.evaluate(() => {
    const girls = Array.from(document.querySelectorAll('[aria-label="whale girl"]'))
    const petDock = document.querySelector('[data-testid="pet-dock"]')
    const summon = document.querySelector('[data-testid="pet-summon"]')
    const bodyKids = Array.from(document.body.children).map((c, i) => ({
      i,
      tag: c.tagName,
      cls: String(c.className || c.getAttribute('class') || '').slice(0, 60),
      aria: c.getAttribute('aria-label'),
      data: c.getAttribute('data-testid') || c.getAttribute('data-ventus-whale') || '',
    }))
    return {
      girlCount: girls.length,
      girlSiblings: girls.map((g) => ({ cls: String(g.className).slice(0, 60), style: g.getAttribute('style')?.slice(0, 160) })),
      petDock: !!petDock,
      petDockChildren: petDock ? petDock.childElementCount : -1,
      summon: !!summon,
      bodyKids: bodyKids.slice(-12),
    }
  })
  console.log('DOM:', JSON.stringify(dom, null, 2))

  // Try loading the spritesheet manually in-page
  const imgProbe = await page.evaluate(async () => {
    const out = { webpSupported: false, direct: null, cached: null }
    const probe = new Image()
    probe.src = 'data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA='
    out.webpSupported = await new Promise((resolve) => {
      probe.onload = () => resolve(true)
      probe.onerror = () => resolve(false)
    })
    const img = new Image()
    img.src = '/pet/whale/spritesheet.webp'
    out.direct = await new Promise((resolve) => {
      const t = setTimeout(() => resolve({ status: 'timeout', naturalWidth: img.naturalWidth }), 15000)
      img.onload = () => { clearTimeout(t); resolve({ status: 'load', naturalWidth: img.naturalWidth, naturalHeight: img.naturalHeight }) }
      img.onerror = (e) => { clearTimeout(t); resolve({ status: 'error', naturalWidth: img.naturalWidth }) }
    })
    // Fetch + blob decode path
    try {
      const res = await fetch('/pet/whale/spritesheet.webp')
      const blob = await res.blob()
      const bit = await createImageBitmap(blob)
      out.cached = { status: 'bitmap', w: bit.width, h: bit.height, blobSize: blob.size }
    } catch (e) {
      out.cached = { status: 'error', msg: String(e) }
    }
    return out
  })
  console.log('IMG_PROBE:', JSON.stringify(imgProbe, null, 2))

  // What is above the whale girl in stacking? List body portals with z-index >= 2000000000
  const stacking = await page.evaluate(() => {
    const out = []
    for (const el of document.body.querySelectorAll('*')) {
      const cs = getComputedStyle(el)
      if (cs.position === 'fixed' || cs.position === 'absolute') {
        const z = parseInt(cs.zIndex, 10)
        if (z >= 2000000000) {
          out.push({ tag: el.tagName, cls: String(el.className).slice(0, 60), z, aria: el.getAttribute('aria-label'), testid: el.getAttribute('data-testid') })
        }
      }
    }
    return out
  })
  console.log('STACKING:', JSON.stringify(stacking, null, 2))

  // Is a session active? Look for composer / dock anchors
  const session = await page.evaluate(() => ({
    visibility: document.visibilityState,
    hasTextarea: !!document.querySelector('textarea'),
    textareaText: document.querySelector('textarea')?.getAttribute('placeholder') ?? null,
  }))
  console.log('SESSION:', JSON.stringify(session))

  await page.screenshot({ path: OUT + '/pet-05-deep.png' })
  console.log('LOGS:', logs.length ? JSON.stringify(logs, null, 2) : '(none)')
  console.log('NETWORK:', network.length ? JSON.stringify(network, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
