// Part 4: clean verification WITHOUT touching the WebGL context.
// 1. DOM presence of the whale wrapper/canvas/caption
// 2. Screenshot the whale corner region; pixel-analysis happens in PowerShell
// 3. Open the settings dialog via the aria-haspopup button and check for the
//    Ventus group card + whale settings card + sliders
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(10000)

  // Whale DOM (no context probing).
  const whale = await page.evaluate(() => {
    const wrapper = document.querySelector('[data-ventus-whale]')
    if (!wrapper) return { wrapper: false }
    const canvas = wrapper.querySelector('canvas')
    const style = window.getComputedStyle(wrapper)
    return {
      wrapper: true,
      canvas: !!canvas,
      canvasSize: canvas ? `${canvas.width}x${canvas.height}` : null,
      caption: wrapper.querySelector('[class*=caption]')?.textContent || null,
      position: style.position,
      right: style.right,
      bottom: style.bottom,
      visible: style.visibility !== 'hidden' && style.display !== 'none',
    }
  })
  console.log('WHALE:', JSON.stringify(whale))

  // Screenshot the bottom-right corner (whale zone).
  const clip = { x: 1600 - 300, y: 900 - 300, width: 300, height: 300 }
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/04-whale-corner.png', clip })

  // Open settings dialog.
  const settingsButton = page.getByRole('button', { name: /设置/ }).first()
  await settingsButton.click({ timeout: 10000 }).catch((e) => console.log('SETTINGS_CLICK_FAIL:', String(e).slice(0, 200)))
  await page.waitForTimeout(4000)
  const dialog = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return { dialog: false }
    const text = d.innerText
    return {
      dialog: true,
      hasVentusGroup: text.includes('Ventus 插件'),
      hasWebUiGroup: text.includes('Web UI 插件'),
      hasWhaleCard: text.includes('大肥鱼桌宠'),
      lines: text.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 40),
    }
  })
  console.log('DIALOG:', JSON.stringify(dialog, null, 2))
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/05-dialog.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
