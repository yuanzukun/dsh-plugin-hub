// t10 verification: default disabled, right-middle default position, drag
// button (mouse + touch), position persistence. Restores the pre-run state.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const errors = []
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + String(e).slice(0, 200)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(2500)
  const orig = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('ORIG:', JSON.stringify(orig))

  // 1. Default disabled: current state is disabled -> whale hidden, summon button shows 召唤
  const d1 = await page.evaluate(() => {
    const wrapper = document.querySelector('[data-ventus-whale]')
    const style = wrapper ? getComputedStyle(wrapper) : null
    const btn = Array.from(document.querySelectorAll('button[aria-label]')).find((b) => /召唤虎鲸|隐藏虎鲸/.test(b.getAttribute('aria-label') || ''))
    return { wrapper: !!wrapper, display: style ? style.display : null, btnLabel: btn ? btn.getAttribute('aria-label') : null }
  })
  console.log('1_DEFAULT_DISABLED:', JSON.stringify(d1))

  // 2. Fresh config (reset) is disabled by default
  await page.evaluate(async () => { await fetch('/api/ventus-whale/reset', { method: 'POST' }) })
  const fresh = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('2_FRESH_CONFIG:', JSON.stringify(fresh))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(4000)
  const d2 = await page.evaluate(() => {
    const wrapper = document.querySelector('[data-ventus-whale]')
    const style = wrapper ? getComputedStyle(wrapper) : null
    return { wrapper: !!wrapper, display: style ? style.display : null }
  })
  console.log('2_FRESH_WHALE:', JSON.stringify(d2))

  // 3. Summon with cleared position -> right-middle
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: true, x: null, y: null }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(4000)
  const pos = await page.evaluate(() => {
    const wrapper = document.querySelector('[data-ventus-whale]')
    const style = wrapper ? getComputedStyle(wrapper) : null
    const r = wrapper ? wrapper.getBoundingClientRect() : null
    return style ? { right: style.right, top: style.top, left: style.left, rect: r ? { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) } : null } : null
  })
  console.log('3_RIGHT_MIDDLE:', JSON.stringify(pos))

  // 4. Hover toolbar has 拖动 button
  const wb = await page.locator('[data-ventus-whale]').boundingBox()
  if (wb) {
    await page.mouse.move(wb.x + wb.width / 2, wb.y + wb.height / 2)
    await page.waitForTimeout(600)
    const toolbar = await page.evaluate(() => {
      const wrapper = document.querySelector('[data-ventus-whale]')
      const btns = Array.from(wrapper.querySelectorAll('[role=toolbar] button')).map((b) => b.textContent.trim())
      return { toolbarButtons: btns }
    })
    console.log('4_TOOLBAR:', JSON.stringify(toolbar))

    // 5. Click 拖动 -> move mode -> mouse drag -> release -> persisted
    const dragBtn = page.locator('[data-ventus-whale] [role=toolbar] button:has-text("拖动")')
    const db = await dragBtn.boundingBox()
    if (db) {
      await page.mouse.click(db.x + db.width / 2, db.y + db.height / 2)
      await page.waitForTimeout(500)
      const inMode = await page.evaluate(() => {
        const wrapper = document.querySelector('[data-ventus-whale]')
        const canvas = wrapper.querySelector('[class*=canvas]')
        const hint = wrapper.textContent.includes('拖动定位')
        return { moveModeClass: !!canvas && /canvasMove/.test(canvas.className), hint }
      })
      console.log('5_MOVE_MODE:', JSON.stringify(inMode))
      // drag from whale center to a new spot
      const cbox = await page.locator('[data-ventus-whale] canvas').boundingBox().catch(() => null)
      if (cbox) {
        const sx = cbox.x + cbox.width / 2
        const sy = cbox.y + cbox.height / 2
        await page.mouse.move(sx, sy)
        await page.mouse.down()
        await page.mouse.move(sx + 400, sy - 200, { steps: 8 })
        await page.mouse.up()
        await page.waitForTimeout(1200)
        const after = await page.evaluate(async () => {
          const s = (await (await fetch('/api/ventus-whale/state')).json()).config
          const wrapper = document.querySelector('[data-ventus-whale]')
          const canvas = wrapper.querySelector('[class*=canvas]')
          return { config: s, moveModeClass: !!canvas && /canvasMove/.test(canvas.className), hint: wrapper.textContent.includes('拖动定位') }
        })
        console.log('5_AFTER_DRAG:', JSON.stringify(after))

        // 6. Reload -> position persisted
        await page.reload({ waitUntil: 'domcontentloaded' })
        await page.waitForTimeout(4000)
        const persisted = await page.evaluate(() => {
          const wrapper = document.querySelector('[data-ventus-whale]')
          const style = wrapper ? getComputedStyle(wrapper) : null
          return { left: style ? style.left : null, top: style ? style.top : null, display: style ? style.display : null }
        })
        console.log('6_PERSISTED:', JSON.stringify(persisted))
      }
    }
  }

  // 7. Touch: tap the whale toggles the toolbar (touch context)
  const touchPage = await browser.newPage({ viewport: { width: 1600, height: 900 }, hasTouch: true, isMobile: false })
  touchPage.on('pageerror', (e) => errors.push('TOUCH PAGEERROR: ' + String(e).slice(0, 150)))
  await touchPage.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await touchPage.waitForTimeout(4000)
  const twb = await touchPage.locator('[data-ventus-whale]').boundingBox().catch(() => null)
  if (twb) {
    await touchPage.touchscreen.tap(twb.x + twb.width / 2, twb.y + twb.height / 2)
    await touchPage.waitForTimeout(600)
    const tRes = await touchPage.evaluate(() => {
      const wrapper = document.querySelector('[data-ventus-whale]')
      const toolbar = wrapper.querySelector('[role=toolbar]')
      const cs = toolbar ? getComputedStyle(toolbar) : null
      const btns = toolbar ? Array.from(toolbar.querySelectorAll('button')).map((b) => b.textContent.trim()) : []
      return { toolbarOpacity: cs ? cs.opacity : null, toolbarVisible: cs ? cs.opacity !== '0' : false, btns }
    })
    console.log('7_TOUCH_TOOLBAR:', JSON.stringify(tRes))
  }
  await touchPage.close()

  // 8. Restore original state
  await page.evaluate(async (o) => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(o) })
  }, orig)
  const restored = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('8_RESTORED:', JSON.stringify(restored))
  console.log('ERRORS:', JSON.stringify(errors.slice(0, 5)))
  await browser.close()
})().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
