// Record a README preview GIF of the whale pet from the real dsh GUI.
// v5: 默认姿态(不旋转)、scale 1.8 避免盖住 UI、位置靠右空白区、紧凑裁剪。
// Frames land in .ventus-verify/gif-frames-whale/ (gitignored).
const fs = require('fs')
const path = require('path')
// 本地开发脚本：自动探测可用的 playwright（环境可能清理 .pnpm 下的副本）。
const PLAYWRIGHT_CANDIDATES = [
  process.env.PLAYWRIGHT_PATH,
  'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/pw/node_modules/playwright',
  'E:/ProgramData/deepseek-harness/node_modules/.pnpm/node_modules/playwright',
].filter(Boolean)
const pwPath = PLAYWRIGHT_CANDIDATES.find((p) => { try { require.resolve(p); return true } catch { return false } })
const { chromium } = require(pwPath)

// RECORD_MODE=light|dark（默认 dark）：分别产出亮/暗两套预览。
const MODE = process.env.RECORD_MODE || 'dark'
const OUT_DIR = 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/gif-frames-whale-' + MODE
// 录制专用：默认指向独立实例（端口 3081），绝不录用户的实时实例；可用 RECORD_BASE_URL 覆盖。
const BASE = process.env.RECORD_BASE_URL || 'http://127.0.0.1:3081'

;(async () => {
  fs.rmSync(OUT_DIR, { recursive: true, force: true })
  fs.mkdirSync(OUT_DIR, { recursive: true })
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(8000)
  const orig = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ enabled: true, scale: 1.8, caption: '', x: 1200, y: 300 }),
    })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(4000)
  for (let i = 0; i < 20; i++) {
    const has = await page.evaluate(() => !!document.querySelector('[data-ventus-whale] canvas'))
    if (has) break
    await page.waitForTimeout(500)
  }
  await page.waitForTimeout(1500)

  // 纯净录制：隐藏 DSH 整套界面（对话框/侧边栏/顶栏），只保留鲸鱼本体 + 工具栏，
  // 背景统一深色——输出就是干净窗口效果，不混入任何 DSH 元素。
  await page.evaluate((mode) => {
    const dark = mode === 'dark'
    document.documentElement.style.colorScheme = dark ? 'dark' : 'light'
    document.body.toggleAttribute('data-ds-dark-theme', dark)
    document.body.style.background = dark ? '#151517' : '#F2F3F5'
    for (const el of Array.from(document.body.children)) {
      if (el.matches('[data-ventus-whale-host]') || el.matches('[data-ventus-whale]')) continue
      if (el.tagName === 'STYLE' || el.tagName === 'SCRIPT') continue
      el.style.display = 'none'
    }
  }, MODE)
  await page.waitForTimeout(500)

  // 固定裁剪区：画布向外扩 40px，钳制到视口（更紧凑，鲸鱼占满画面）。
  const clip = await page.evaluate(() => {
    const canvas = document.querySelector('[data-ventus-whale] canvas')
    const r = canvas.getBoundingClientRect()
    const pad = 20
    const x = Math.max(0, Math.floor(r.x - pad))
    const y = Math.max(0, Math.floor(r.y - pad))
    const w = Math.min(window.innerWidth - x, Math.ceil(r.width + pad * 2))
    const h = Math.min(window.innerHeight - y, Math.ceil(r.height + pad * 2))
    return { x, y, width: w, height: h }
  })
  console.log('CLIP:', JSON.stringify(clip))
  const canvasCenter = await page.evaluate(() => {
    const canvas = document.querySelector('[data-ventus-whale] canvas')
    const r = canvas.getBoundingClientRect()
    return { x: r.x + r.width / 2, y: r.y + r.height / 2 }
  })

  let n = 0
  const shot = async (label) => {
    const file = path.join(OUT_DIR, String(n).padStart(2, '0') + '-' + label + '.png')
    await page.screenshot({ path: file, clip })
    n++
  }

  // 1) 默认姿态空闲游动（不拖拽旋转，避免被识别为倒置/畸形）
  for (let i = 0; i < 12; i++) { await shot('idle'); await page.waitForTimeout(130) }
  // 3) 悬停 → 工具栏浮现
  await page.mouse.move(canvasCenter.x + 150, canvasCenter.y + 100)
  await page.waitForTimeout(600)
  for (let i = 0; i < 3; i++) { await shot('toolbar'); await page.waitForTimeout(150) }
  // 4) 点「转圈」→ 360° 前空翻
  await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const btn = Array.from(w.querySelectorAll('[class*=quickToolbar] button')).find((b) => b.textContent.trim() === '转圈')
    if (btn) btn.click()
  })
  for (let i = 0; i < 8; i++) { await shot('flip'); await page.waitForTimeout(110) }
  // 5) 单击 → 爱心
  await page.mouse.click(canvasCenter.x + 150, canvasCenter.y + 100)
  for (let i = 0; i < 6; i++) { await shot('hearts'); await page.waitForTimeout(130) }
  // 6) 结尾定格
  await page.waitForTimeout(700)
  for (let i = 0; i < 3; i++) { await shot('end'); await page.waitForTimeout(150) }

  console.log('FRAMES:', n)
  await page.evaluate(async (o) => {
    const body = { enabled: o.enabled, scale: o.scale, sensitivity: o.sensitivity, caption: o.caption, flipOnSend: o.flipOnSend }
    if (o.x !== undefined) body.x = o.x
    if (o.y !== undefined) body.y = o.y
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
  }, orig)
  await browser.close()
})().catch((e) => { console.error('RECORD FAILED:', e); process.exit(1) })
