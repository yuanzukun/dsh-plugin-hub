// Part 11: capture the actual network response for the ui-conversation
// client bundle as the page loads — proves what the browser really executes.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const bundleBodies = new Map()
  page.on('response', async (r) => {
    const url = r.url()
    if (url.includes('dsh-client-ui-conversation') || url.includes('dsh-web-app')) {
      try {
        const body = await r.text()
        bundleBodies.set(url, { len: body.length, toFixed2: body.includes('toFixed(2)'), cacheHit: body.includes('cacheHitPercent') })
      } catch { /* ignore */ }
    }
  })

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(10000)

  console.log('BUNDLES:', JSON.stringify(Object.fromEntries(bundleBodies), null, 2))
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
