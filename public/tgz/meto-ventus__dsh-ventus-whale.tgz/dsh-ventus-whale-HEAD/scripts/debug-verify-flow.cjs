// Debug v4: exact verify-t1-live flow with fetch instrumentation.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  page.on('console', (m) => console.log('CONSOLE[' + m.type() + ']:', m.text().slice(0, 250)))
  page.on('pageerror', (e) => console.log('PAGEERROR:', String(e).slice(0, 300)))
  await page.addInitScript(() => {
    const origFetch = window.fetch
    window.fetch = (...args) => {
      const url = String(args[0])
      if (url.includes('/api/ventus-whale/')) {
        const body = args[1] ? String(args[1].body) : null
        console.log('FETCH>>', args[1] ? args[1].method : 'GET', url, body)
        return origFetch(...args).then((r) => {
          r.clone().json().then((j) => console.log('FETCH<<', r.status, JSON.stringify(j).slice(0, 250))).catch(() => {})
          return r
        })
      }
      return origFetch(...args)
    }
  })

  const snap = async (label) => {
    const info = await page.evaluate(() => {
      const w = document.querySelector('[data-ventus-whale]')
      const ws = w ? window.getComputedStyle(w) : null
      const wb = w ? w.getBoundingClientRect() : null
      return {
        whale: wb ? { x: Math.round(wb.x), y: Math.round(wb.y), zi: ws?.zIndex, hint: Array.from(document.querySelectorAll('[data-ventus-whale] div')).some((d) => /拖动定位/.test(d.textContent)) } : null,
        menu: Array.from(document.querySelectorAll('[role=menu] button')).map((b) => b.textContent.trim()),
        summon: !!document.querySelector('[data-ventus-whale-summon]'),
      }
    })
    console.log(label, JSON.stringify(info))
  }

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(8000)
  await page.evaluate(async () => { await fetch('/api/ventus-whale/reset', { method: 'POST' }) })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(9000)

  const wrapper = page.locator('[data-ventus-whale]')
  const box = await wrapper.boundingBox()
  const cx = box.x + box.width / 2
  const cy = box.y + box.height / 2

  // step 2: dblclick -> drag -> up -> EXIT dblclick
  await page.mouse.dblclick(cx, cy)
  await page.waitForTimeout(1200)
  await snap('S2_ENTERED_MOVE')
  await page.mouse.move(cx, cy)
  await page.mouse.down()
  await page.mouse.move(cx + 400, cy - 200, { steps: 6 })
  await page.mouse.up()
  await page.waitForTimeout(1500)
  await snap('S2_AFTER_DRAG')
  await page.mouse.dblclick(cx, cy)
  await page.waitForTimeout(600)
  await snap('S2_AFTER_EXIT_DBLCLICK')

  // step 3: right-click -> 重置位置
  const box2 = await wrapper.boundingBox()
  await page.mouse.click(box2.x + box2.width / 2, box2.y + box2.height / 2, { button: 'right' })
  await page.waitForTimeout(1200)
  await snap('S3_MENU')
  await page.getByRole('menuitem', { name: '重置位置' }).click({ timeout: 4000 })
  await page.waitForTimeout(2000)
  await snap('S3_AFTER_RESET')

  // step 4: right-click -> 隐藏虎鲸
  const box3 = await wrapper.boundingBox()
  console.log('S4_BOX3:', JSON.stringify(box3))
  await page.mouse.click(box3.x + box3.width / 2, box3.y + box3.height / 2, { button: 'right' })
  await page.waitForTimeout(1200)
  await snap('S4_MENU')
  await page.getByRole('menuitem', { name: '隐藏虎鲸' }).click({ timeout: 4000 })
  for (const t of [300, 700, 1500]) {
    await page.waitForTimeout(t)
    await snap('S4_HIDE+t' + t)
  }

  await browser.close()
})().catch((e) => { console.error('DEBUG FAILED:', e); process.exit(1) })
