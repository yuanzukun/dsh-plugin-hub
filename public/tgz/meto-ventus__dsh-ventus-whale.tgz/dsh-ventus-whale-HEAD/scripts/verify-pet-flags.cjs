// Does the spritesheet Image decode hang depend on launch flags? (same-origin, on the GUI)
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

async function probe(label, args) {
  const browser = await chromium.launch({ channel: 'msedge', headless: true, args })
  const page = await browser.newPage({ viewport: { width: 1200, height: 800 } })
  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(3000)
  const result = await page.evaluate(async () => {
    const img = new Image()
    img.src = '/pet/whale/spritesheet.webp'
    const r = await new Promise((resolve) => {
      const t = setTimeout(() => resolve('timeout@8s naturalWidth=' + img.naturalWidth), 8000)
      img.onload = () => { clearTimeout(t); resolve('load ' + img.naturalWidth + 'x' + img.naturalHeight) }
      img.onerror = (e) => { clearTimeout(t); resolve('error') }
    })
    return r
  }).catch((e) => 'evaluate-error: ' + String(e))
  console.log(label, '=>', result)
  await browser.close()
}

;(async () => {
  await probe('flags=[--disable-gpu --no-sandbox --use-angle=swiftshader --enable-unsafe-swiftshader]', ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
  await probe('flags=[default]', [])
  await probe('flags=[--no-sandbox]', ['--no-sandbox'])
  await probe('flags=[--no-sandbox --disable-gpu]', ['--no-sandbox', '--disable-gpu'])
})().catch((e) => { console.error('FAILED:', e); process.exit(1) })
