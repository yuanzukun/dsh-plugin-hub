// Part 6: expand the "Ventus 插件" group card, then verify the whale
// settings card: 大肥鱼桌宠 title, 大小 slider, 灵敏度 slider, caption input.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(9000)
  await page.getByRole('button', { name: /设置/ }).first().click({ timeout: 10000 })
  await page.waitForTimeout(3000)

  // Click 插件 nav.
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const rows = Array.from(d.querySelectorAll('button, [role=button], div, span'))
    const hit = rows.find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(3500)

  // Expand the Ventus group card header (aria-label starts with 展开).
  const expanded = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const btns = Array.from(d.querySelectorAll('button[aria-expanded]'))
    const hit = btns.find((b) => (b.getAttribute('aria-label') || '').includes('Ventus') || b.textContent.includes('Ventus 插件'))
    if (hit) { hit.click(); return true }
    return false
  })
  console.log('EXPAND_CLICKED:', expanded)
  await page.waitForTimeout(3500)

  const result = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const text = d ? d.innerText : ''
    const ranges = Array.from(d ? d.querySelectorAll('input[type=range]') : [])
    const textInputs = Array.from(d ? d.querySelectorAll('input[type=text], input:not([type]), textarea') : [])
    return {
      hasWhaleCard: text.includes('大肥鱼桌宠'),
      rangeCount: ranges.length,
      ranges: ranges.map((i) => ({ min: i.min, max: i.max, value: i.value, aria: i.getAttribute('aria-label') || '' })),
      textInputs: textInputs.map((i) => ({ value: i.value, ph: i.placeholder || '' })),
      snippet: text.split('\n').map((l) => l.trim()).filter(Boolean).filter((l) => /大肥鱼|虎鲸|桌宠|大小|灵敏度|文字|Ventus/.test(l)).slice(0, 30),
    }
  })
  console.log('WHALE_CARD:', JSON.stringify(result, null, 2))
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/07-whale-card.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
