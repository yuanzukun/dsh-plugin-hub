// Task t1 LIVE client verification against the running GUI (127.0.0.1:3080).
// The browser bundle is fresh per page load, so ALL client behavior is live:
//  - double-click move mode: hint appears, preview follows the pointer (the
//    running host predates the x/y routes, so persistence is NOT asserted here;
//    host logic is covered by verify-host-routes.mts + the minimal live host).
//  - summon button when hidden, re-enables on click
//  - settings group card expanded by default + whale card + switch
//  - whale close-up screenshots for eye/mark appearance review
const path = require('path')
const fs = require('fs')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

const OUT = 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify'

;(async () => {
  fs.mkdirSync(OUT, { recursive: true })
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 2 })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  const results = {}
  const state = async () => page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(8000)
  // clean slate
  await page.evaluate(async () => { await fetch('/api/ventus-whale/reset', { method: 'POST' }) })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(9000)

  // 1. baseline
  const base = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const s = w ? window.getComputedStyle(w) : null
    return { present: !!w, canvas: !!w?.querySelector('canvas'), left: s?.left, bottom: s?.bottom }
  })
  results.baseline = base
  console.log('1_BASELINE:', JSON.stringify(base))

  // 2. double-click -> move mode -> preview follows pointer
  const wrapper = page.locator('[data-ventus-whale]')
  const box = await wrapper.boundingBox()
  if (!box) throw new Error('whale wrapper not visible')
  const cx = box.x + box.width / 2
  const cy = box.y + box.height / 2
  await page.mouse.dblclick(cx, cy)
  await page.waitForTimeout(1200)
  results.hint = await page.evaluate(() =>
    Array.from(document.querySelectorAll('[data-ventus-whale] div')).some((d) => /拖动定位/.test(d.textContent)))
  console.log('2_HINT:', JSON.stringify(results.hint))

  await page.mouse.move(cx, cy)
  await page.mouse.down()
  await page.mouse.move(cx + 400, cy - 200, { steps: 6 })
  const mid = await page.evaluate(() => {
    const s = window.getComputedStyle(document.querySelector('[data-ventus-whale]'))
    return { left: s.left, top: s.top }
  })
  await page.mouse.up()
  await page.waitForTimeout(1500)
  results.previewFollowed = mid.left !== base.left || mid.top !== base.bottom
  results.midDrag = mid
  console.log('2_MID_DRAG:', JSON.stringify(mid), 'previewFollowed:', results.previewFollowed)
  await page.screenshot({ path: path.join(OUT, 't1-movemode.png') })
  // exit move mode deterministically (Escape) instead of a second dblclick,
  // whose toggle can race the in-flight persist response.
  await page.keyboard.press('Escape')
  await page.waitForTimeout(600)

  // 3. context menu items + reset position
  const box2 = await wrapper.boundingBox()
  await page.mouse.click(box2.x + box2.width / 2, box2.y + box2.height / 2, { button: 'right' })
  await page.waitForTimeout(1200)
  results.menu = await page.evaluate(() => Array.from(document.querySelectorAll('[role=menu] button')).map((b) => b.textContent.trim()))
  console.log('3_MENU:', JSON.stringify(results.menu))
  await page.getByRole('menuitem', { name: '重置位置' }).click({ timeout: 5000 })
  await page.waitForTimeout(2000)

  // 4. hide -> summon -> click -> whale back
  const box3 = await wrapper.boundingBox()
  await page.mouse.click(box3.x + box3.width / 2, box3.y + box3.height / 2, { button: 'right' })
  await page.waitForTimeout(1200)
  await page.getByRole('menuitem', { name: '隐藏虎鲸' }).click({ timeout: 5000 })
  await page.waitForTimeout(3000)
  const summon = await page.evaluate(() => {
    const b = document.querySelector('[data-ventus-whale-summon]')
    return { present: !!b, text: b?.textContent.trim(), whaleGone: !document.querySelector('[data-ventus-whale]') }
  })
  results.summon = summon
  console.log('4_SUMMON:', JSON.stringify(summon))
  await page.screenshot({ path: path.join(OUT, 't1-summon.png') })
  await page.locator('[data-ventus-whale-summon]').click({ timeout: 5000 })
  await page.waitForTimeout(3000)
  const back = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const s = w ? window.getComputedStyle(w) : null
    return { whaleBack: !!w, left: s?.left, bottom: s?.bottom }
  })
  results.afterSummon = back
  results.stateAfterSummon = await state()
  console.log('4_AFTER_SUMMON:', JSON.stringify(back), JSON.stringify(results.stateAfterSummon))

  // 5. settings -> 插件 -> Ventus group expanded by default -> whale card + switch
  await page.getByRole('button', { name: /设置/ }).first().click({ timeout: 10000 })
  await page.waitForTimeout(3000)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const hit = Array.from(d.querySelectorAll('button, [role=button], div, span')).find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(3500)
  const group = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const header = Array.from(d.querySelectorAll('button[aria-expanded]')).find((b) => (b.getAttribute('aria-label') || '').includes('Ventus') || b.textContent.includes('Ventus 插件'))
    const card = Array.from(d.querySelectorAll('*')).find((el) => el.textContent.trim().startsWith('大肥鱼桌宠') && el.offsetParent !== null)
    const sw = d.querySelector('#ventus-whale-enabled')
    return { expanded: header ? header.getAttribute('aria-expanded') : null, cardVisible: !!card, switchPresent: !!sw, switchChecked: sw ? sw.checked : null }
  })
  results.settingsGroup = group
  console.log('5_SETTINGS_GROUP:', JSON.stringify(group))
  await page.screenshot({ path: path.join(OUT, 't1-settings.png') })
  await page.keyboard.press('Escape')
  await page.waitForTimeout(1500)

  // 6. eye close-up: scale up, reload, screenshot, restore
  const orig = await state()
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ scale: 2.5 }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(9000)
  const wb = await page.locator('[data-ventus-whale]').boundingBox()
  if (wb) {
    await page.screenshot({ path: path.join(OUT, 't1-whale-closeup.png'), clip: { x: Math.max(0, wb.x - 10), y: Math.max(0, wb.y - 10), width: wb.width + 20, height: wb.height + 20 } })
    results.closeup = wb
    console.log('6_CLOSEUP_SAVED:', JSON.stringify(wb))
  }
  await page.evaluate(async (s) => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ scale: s }) })
  }, orig.scale)
  await page.close()

  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  const pass = results.baseline.present && results.hint && results.previewFollowed &&
    results.menu.includes('重置位置') && results.menu.includes('隐藏虎鲸') &&
    summon.present && summon.whaleGone && back.whaleBack &&
    group.expanded === 'true' && group.cardVisible && group.switchPresent
  console.log('VERDICT:', pass ? 'PASS' : 'FAIL')
  fs.writeFileSync(path.join(OUT, 't1-live-results.json'), JSON.stringify(results, null, 2))
  await browser.close()
  if (!pass) process.exit(2)
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
