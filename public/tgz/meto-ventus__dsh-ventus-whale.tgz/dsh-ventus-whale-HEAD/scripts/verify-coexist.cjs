// Part 8: full verification of the coexisting pets:
// - whale in bottom-LEFT (dock left), whale girl in bottom-right
// - settings dialog -> 插件 -> expand Ventus 插件 -> new controls:
//   enable switch, dock segmented buttons, 距底部 slider, 大小/灵敏度 sliders, caption input
// - toggle the enable switch off and confirm the whale unmounts; toggle back on
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(10000)

  // 1. Both pets present, non-overlapping corners.
  const pets = await page.evaluate(() => {
    const whale = document.querySelector('[data-ventus-whale]')
    const girl = document.querySelector('[aria-label="whale girl"]')
    const w = whale ? window.getComputedStyle(whale) : null
    const g = girl ? window.getComputedStyle(girl) : null
    return {
      whalePresent: !!whale,
      whaleLeft: w ? w.left : null,
      whaleRight: w ? w.right : null,
      whaleBottom: w ? w.bottom : null,
      whaleCanvas: !!whale?.querySelector('canvas'),
      girlPresent: !!girl,
      girlRight: g ? g.right : null,
      girlBottom: g ? g.bottom : null,
    }
  })
  console.log('PETS:', JSON.stringify(pets, null, 2))

  // 2. Settings dialog -> 插件 -> expand Ventus group.
  await page.getByRole('button', { name: /设置/ }).first().click({ timeout: 10000 })
  await page.waitForTimeout(3000)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const hit = Array.from(d.querySelectorAll('button, [role=button], div, span')).find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(3500)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const hit = Array.from(d.querySelectorAll('button[aria-expanded]')).find((b) => (b.getAttribute('aria-label') || '').includes('Ventus') || b.textContent.includes('Ventus 插件'))
    if (hit) hit.click()
  })
  await page.waitForTimeout(3500)

  const card = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const text = d ? d.innerText : ''
    const ranges = Array.from(d ? d.querySelectorAll('input[type=range]') : [])
    const texts = Array.from(d ? d.querySelectorAll('input[type=text]') : [])
    const switches = Array.from(d ? d.querySelectorAll('input[type=checkbox]') : [])
    const segs = Array.from(d ? d.querySelectorAll('button') : []).filter((b) => /左下角|右下角/.test(b.textContent))
    return {
      hasGroup: text.includes('Ventus 插件'),
      hasCard: text.includes('大肥鱼桌宠'),
      rangeCount: ranges.length,
      ranges: ranges.map((i) => `${i.min}..${i.max}@${i.value}`),
      textValues: texts.map((i) => i.value),
      switchChecked: switches.map((i) => i.checked),
      segments: segs.map((b) => ({ label: b.textContent.trim(), active: b.className.includes('Active') })),
      snippet: text.split('\n').map((l) => l.trim()).filter(Boolean).filter((l) => /大肥鱼|虎鲸|大小|灵敏度|停靠|距底部|显示文字|已启用|已停用|左下角|右下角/.test(l)).slice(0, 30),
    }
  })
  console.log('CARD:', JSON.stringify(card, null, 2))

  // 3. Toggle the enable switch off -> whale unmounts.
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const sw = d.querySelector('input[type=checkbox]')
    if (sw) sw.click()
  })
  await page.waitForTimeout(2500)
  const afterOff = await page.evaluate(() => ({
    whalePresent: !!document.querySelector('[data-ventus-whale]'),
    state: null,
  }))
  afterOff.state = await page.evaluate(async () => (await fetch('/api/ventus-whale/state')).json())
  console.log('AFTER_OFF:', JSON.stringify(afterOff))

  // Toggle back on.
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const sw = d.querySelector('input[type=checkbox]')
    if (sw) sw.click()
  })
  await page.waitForTimeout(2500)
  const afterOn = await page.evaluate(async () => {
    const whale = document.querySelector('[data-ventus-whale]')
    return {
      whalePresent: !!whale,
      state: await (await fetch('/api/ventus-whale/state')).json(),
    }
  })
  console.log('AFTER_ON:', JSON.stringify(afterOn))

  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/08-coexist.png' })
  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  await browser.close()
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
