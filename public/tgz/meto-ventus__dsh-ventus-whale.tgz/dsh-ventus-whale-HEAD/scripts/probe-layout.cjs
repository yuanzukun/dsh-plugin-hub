const { chromium } = require('E:/ProgramData/deepseek-harness/node_modules/.pnpm/node_modules/playwright')
;(async () => {
  const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(8000)
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: true, scale: 1, x: null, y: null, caption: '蓝色大肥鱼' }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(4000)
  for (let i = 0; i < 20; i++) {
    const has = await page.evaluate(() => !!document.querySelector('[data-ventus-whale] canvas'))
    if (has) break
    await page.waitForTimeout(500)
  }
  const wb = await page.locator('[data-ventus-whale]').boundingBox()
  if (wb) {
    await page.mouse.move(wb.x + wb.width / 2, wb.y + wb.height / 2)
    await page.waitForTimeout(800)
  }
  const info = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const canvas = w.querySelector('canvas')
    const tool = w.querySelector('[class*=quickToolbar]')
    const wr = w.getBoundingClientRect()
    const cr = canvas.getBoundingClientRect()
    const tr = tool.getBoundingClientRect()
    return {
      wrapper: { x: Math.round(wr.x), y: Math.round(wr.y), w: Math.round(wr.width), h: Math.round(wr.height) },
      canvas: { x: Math.round(cr.x), y: Math.round(cr.y), w: Math.round(cr.width), h: Math.round(cr.height) },
      toolbar: { x: Math.round(tr.x), y: Math.round(tr.y), w: Math.round(tr.width), h: Math.round(tr.height) },
      toolbarBottomVsCanvasTop: Math.round(tr.bottom - cr.top),
    }
  })
  console.log(JSON.stringify(info, null, 2))
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/probe-toolbar-overlay.png', clip: { x: 1360, y: 320, width: 240, height: 320 } })
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: false, scale: 1.3, caption: '蓝色大肥鱼', x: null, y: null }) })
  })
  await browser.close()
})().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })