# t10 结论：默认关闭 + 默认位置右侧中部 + 悬停面板拖动按钮（触屏可拖）

调查者：ventus-engineer · 修复日期：2026-08-15 · 证据脚本 `scripts/verify-t10.cjs`（浏览器实测，会还原现场状态）

## 1. 默认关闭
- host 侧三处默认值改为 false：`protocol.ts DEFAULT_CONFIG.enabled`、`src/index.ts WHALE_SETTINGS_SCHEMA.enabled`、`Config.enabled`；client 侧 fallback（api.state 失败）同步为 false。
- 已保存配置不受影响（loadConfig 读已有字段）。
- ⚠️ host 代码在 dsh 启动时加载：新 `lib/index.js` 已编译（默认 false、无 dock/bottom 解析），**需重启 dsh 后「无配置默认关闭」才在运行环境生效**；client 侧默认值（设置卡片开关默认「已停用」等）已即时生效。

## 2. 默认位置右侧中部（不再左下角）
- 无已保存 x/y 时：`right: 32px; top: 38%`（视口右侧、垂直居中偏上，避开四角）；有 x/y 时用已保存位置（不变）。
- 随之清理：`bottom`（距底部）字段与设置项随左下角定位一并移除（protocol/host/routes/schema/设置卡片/README），与 t8 删 dock 同模式，旧配置字段被忽略。
- 实测：召唤后 wrapper right=32px、top=342px（900px 视口的 38%）、left=1348（右侧）✓

## 3. 悬停面板「拖动」按钮（触屏可拖）
- 工具栏新增「拖动」按钮：点击进入拖动模式（复用既有 moveMode），再点退出；松手（onPointerUp wasMove 路径）自动保存并退出；Esc 或**点击面板外**（document pointerdown 监听，wrapper 外）退出。
- 拖动走 Pointer Events（mouse/touch 统一）：moveMode 时 canvas 带 `touch-action: none`（防止触屏拖动时页面滚动），setPointerCapture 保持手势；结束经 /api/ventus-whale/update 保存 x/y（host 写路径），与 t9 的 whale-config-store 缓存无冲突（applyUpdate 广播 WHALE_CONFIG_EVENT，卡片/store 同步）。
- 触屏面板可达：`@media (hover: hover)` 包住桌面 :hover 规则；触屏设备（matchMedia 判断）点按虎鲸切换 `toolbarPinned` → `.wrapperToolbarOn` 固定显示工具栏（含拖动按钮）。
- 实测：hover 工具栏 = [改名, 重置, **拖动**, 爱心：开]；点拖动进入 moveMode（canvasMove class + 提示）；鼠标拖 400/-200 → 松手 → 状态持久化 x:1380,y:142、moveMode 自动退出；reload 后位置仍在（left:1380, top:142）；触屏 context 点按后工具栏 opacity=1、按钮齐全 ✓

## 构建与验证
- `pnpm build` ✓：lib/client.js 470,333 → **470,815 B**（+0.1%，拖动按钮/状态逻辑）；lib/index.js 46,981 B（host 新代码）
- `pnpm run typecheck` ✓；`smoke-host/client/load` ✓
- `scripts/verify-t10.cjs` ✓：默认关闭（fresh 配置 enabled:false 已编译，运行环境需重启 dsh 生效）、右侧中部位置、拖动按钮+拖动持久化、触屏工具栏、状态还原
- 注意：探针开始前用户已自行召唤（LIVE 状态 enabled:true, x:1654, y:559），探针按此原样还原（未强制改回，避免打断用户当前使用）。

## 改动文件
- `src/protocol.ts`（enabled 默认 false、删 bottom、注释）
- `src/index.ts`（schema/Config 默认 false、删 bottom）
- `src/host.ts` / `src/routes.ts`（删 bottom 解析/patch）
- `src/client/WhalePet.tsx`（fallback false、右侧中部定位、拖动按钮、触屏 toolbar、点外退出、文案）
- `src/client/WhaleSettingsCard.tsx`（删「距底部」设置项）
- `src/client/whale-pet.module.css`（hover 规则按设备拆分、.wrapperToolbarOn）
- `README.md`（默认关闭/右侧中部/拖动按钮说明）
- `scripts/verify-t10.cjs`（新增）
- 备份：`DSH_Anything/.t10-backup-ventus/`

## 残留风险
- **需重启 dsh** 后 host 侧「默认关闭」生效（当前运行进程为旧 host；红线禁止 kill dsh，故未重启）。
- 触屏拖动经 Pointer Events 与鼠标同路径，headless 只验证了 tap 唤出工具栏；真实触屏拖动手感需真机确认。
- 点面板外退出监听 document pointerdown：在设置卡片等弹层上点击也会退出拖动模式（符合预期）。
