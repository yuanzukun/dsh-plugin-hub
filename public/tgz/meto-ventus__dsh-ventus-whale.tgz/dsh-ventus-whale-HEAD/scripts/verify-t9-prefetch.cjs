// t9 proof: hang /api/ventus-whale/state; the card must still render (prefetch
// store / default placeholder), never a blank hole.
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  await page.addInitScript(() => {
    // Hang the whale state fetch: never settle. The settings scope (RPC)
    // must still make the card render.
    const origFetch = window.fetch
    window.fetch = (...args) => {
      const url = String(args[0])
      if (url.includes('/api/ventus-whale/state')) {
        return new Promise(() => {}) // never resolves
      }
      return origFetch(...args)
    }
  })
  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  // wait for shell
  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(250)
    const ready = await page.evaluate(() => {
      const els = Array.from(document.querySelectorAll('button, [role=button], a'))
      return els.some((el) => el.textContent.trim() === '设置' && el.offsetParent !== null)
    })
    if (ready) break
  }
  await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('button, [role=button], a'))
    const hit = els.find((el) => el.textContent.trim() === '设置' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(1500)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return
    const rows = Array.from(d.querySelectorAll('button, [role=button], div, span'))
    const hit = rows.find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  let appeared = null
  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(250)
    const has = await page.evaluate(() => {
      const d = document.querySelector('[role=dialog]')
      if (!d) return false
      return Array.from(d.querySelectorAll('*')).some((el) => (el.textContent || '').includes('大肥鱼桌宠') && el.children.length === 0)
    })
    if (has) { appeared = i * 250; break }
  }
  console.log('CARD_WITH_STATE_FETCH_HUNG:', appeared === null ? 'NEVER' : Math.round(appeared) + 'ms')
  const detail = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const btn = Array.from(d.querySelectorAll('button[aria-label]')).find((b) => {
      const a = b.getAttribute('aria-label') || ''
      return a === '展开设置' || a === '收起设置'
    })
    const cardEl = btn ? btn.closest('li') : null
    return {
      cardFound: !!btn,
      rangeCount: cardEl ? cardEl.querySelectorAll('input[type=range]').length : -1,
      enabledChecked: cardEl ? cardEl.querySelector('#ventus-whale-enabled')?.checked : null,
    }
  })
  console.log('DETAIL:', JSON.stringify(detail))
  await browser.close()
})().catch((e) => { console.error('PROBE FAILED:', e); process.exit(1) })
