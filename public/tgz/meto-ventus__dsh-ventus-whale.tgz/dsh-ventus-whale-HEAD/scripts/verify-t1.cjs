// Task t1 verification:
// 1. whale renders docked (left), no console errors
// 2. double-click enters move mode (hint) -> drag repositions -> x/y persisted in state
// 3. reload keeps the free position (host persistence)
// 4. context menu 重置位置 clears x/y (back to dock)
// 5. context menu 隐藏虎鲸 -> summon pill appears -> click summons the whale
// 6. settings -> 插件 -> Ventus group card is expanded by default -> 大肥鱼桌宠 switch visible
// 7. close-up whale screenshots for eye/mark appearance verification
const path = require('path')
const fs = require('fs')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

const OUT = 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify'

;(async () => {
  fs.mkdirSync(OUT, { recursive: true })
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 2 })
  const consoleErrors = []
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)) })
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + String(e).slice(0, 300)))

  const results = {}
  const state = async () => page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)

  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(10000)

  // 1. baseline: whale present + docked left.
  const base = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const s = w ? window.getComputedStyle(w) : null
    return { present: !!w, canvas: !!w?.querySelector('canvas'), left: s?.left, right: s?.right, bottom: s?.bottom }
  })
  results.baseline = base
  console.log('1_BASELINE:', JSON.stringify(base))

  // 2. double-click -> move mode -> drag -> x/y persisted.
  const wrapper = page.locator('[data-ventus-whale]')
  const box = await wrapper.boundingBox()
  if (!box) throw new Error('whale wrapper not visible')
  await page.mouse.dblclick(box.x + box.width / 2, box.y + box.height / 2)
  await page.waitForTimeout(1200)
  const hint = await page.evaluate(() =>
    Array.from(document.querySelectorAll('[data-ventus-whale] div')).some((d) => /拖动定位/.test(d.textContent)))
  results.moveHintVisible = hint
  console.log('2_MOVE_HINT:', JSON.stringify({ hint }))
  // Drag to center-right area.
  const targetX = box.x + 500
  const targetY = box.y - 250
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2)
  await page.mouse.down()
  await page.mouse.move(targetX, targetY, { steps: 12 })
  await page.mouse.up()
  await page.waitForTimeout(2500)
  const moved = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const s = w ? window.getComputedStyle(w) : null
    return { left: s?.left, top: s?.top, bottom: s?.bottom, right: s?.right }
  })
  const movedState = await state()
  results.afterMove = { style: moved, config: { x: movedState.x, y: movedState.y, dock: movedState.dock, bottom: movedState.bottom } }
  console.log('2_AFTER_MOVE:', JSON.stringify(results.afterMove))
  await page.screenshot({ path: path.join(OUT, 't1-after-move.png') })

  // 3. reload -> free position persists.
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(9000)
  const reloaded = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const s = w ? window.getComputedStyle(w) : null
    return { present: !!w, left: s?.left, top: s?.top, bottom: s?.bottom }
  })
  results.afterReload = reloaded
  console.log('3_AFTER_RELOAD:', JSON.stringify(reloaded))

  // 4. context menu -> 重置位置 clears x/y.
  const wrapper2 = page.locator('[data-ventus-whale]')
  const box2 = await wrapper2.boundingBox()
  await page.mouse.click(box2.x + box2.width / 2, box2.y + box2.height / 2, { button: 'right' })
  await page.waitForTimeout(1200)
  const menu = await page.evaluate(() => Array.from(document.querySelectorAll('[role=menu] button')).map((b) => b.textContent.trim()))
  results.menuItems = menu
  console.log('4_MENU:', JSON.stringify(menu))
  await page.getByRole('menuitem', { name: '重置位置' }).click({ timeout: 5000 })
  await page.waitForTimeout(2500)
  const resetStyle = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const s = w ? window.getComputedStyle(w) : null
    return { left: s?.left, bottom: s?.bottom }
  })
  const resetState = await state()
  results.afterReset = { style: resetStyle, x: resetState.x, y: resetState.y, dock: resetState.dock, bottom: resetState.bottom }
  console.log('4_AFTER_RESET:', JSON.stringify(results.afterReset))

  // 5. hide -> summon pill -> click -> whale back.
  const box3 = await wrapper2.boundingBox()
  await page.mouse.click(box3.x + box3.width / 2, box3.y + box3.height / 2, { button: 'right' })
  await page.waitForTimeout(1200)
  await page.getByRole('menuitem', { name: '隐藏虎鲸' }).click({ timeout: 5000 })
  await page.waitForTimeout(2000)
  const summon = await page.evaluate(() => {
    const b = document.querySelector('[data-ventus-whale-summon]')
    return { present: !!b, text: b?.textContent.trim(), whaleGone: !document.querySelector('[data-ventus-whale]') }
  })
  results.summon = summon
  console.log('5_SUMMON:', JSON.stringify(summon))
  await page.screenshot({ path: path.join(OUT, 't1-summon.png') })
  await page.locator('[data-ventus-whale-summon]').click({ timeout: 5000 })
  await page.waitForTimeout(2500)
  const afterSummon = await page.evaluate(() => {
    const w = document.querySelector('[data-ventus-whale]')
    const s = w ? window.getComputedStyle(w) : null
    return { whaleBack: !!w, left: s?.left, bottom: s?.bottom }
  })
  results.afterSummon = afterSummon
  console.log('5_AFTER_SUMMON:', JSON.stringify(afterSummon))

  // 6. settings -> 插件 -> Ventus group expanded by default -> whale card visible.
  await page.getByRole('button', { name: /设置/ }).first().click({ timeout: 10000 })
  await page.waitForTimeout(3000)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const hit = Array.from(d.querySelectorAll('button, [role=button], div, span')).find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(3500)
  const group = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    const header = Array.from(d.querySelectorAll('button[aria-expanded]')).find((b) => (b.getAttribute('aria-label') || '').includes('Ventus') || b.textContent.includes('Ventus 插件'))
    const card = Array.from(d.querySelectorAll('*')).find((el) => el.textContent.trim().startsWith('大肥鱼桌宠') && el.offsetParent !== null)
    const sw = d.querySelector('#ventus-whale-enabled')
    return { expanded: header ? header.getAttribute('aria-expanded') : null, cardVisible: !!card, switchPresent: !!sw, switchChecked: sw ? sw.checked : null }
  })
  results.settingsGroup = group
  console.log('6_SETTINGS_GROUP:', JSON.stringify(group))
  await page.screenshot({ path: path.join(OUT, 't1-settings.png') })

  // 7. eye close-up: bump scale, reload, screenshot, restore.
  const orig = await state()
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ scale: 2.5 }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(9000)
  const whaleBox = await page.locator('[data-ventus-whale]').boundingBox()
  if (whaleBox) {
    await page.screenshot({ path: path.join(OUT, 't1-whale-closeup.png'), clip: { x: Math.max(0, whaleBox.x - 10), y: Math.max(0, whaleBox.y - 10), width: whaleBox.width + 20, height: whaleBox.height + 20 } })
    console.log('7_CLOSEUP_SAVED:', JSON.stringify(whaleBox))
  }
  await page.evaluate(async (s) => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ scale: s }) })
  }, orig.scale)
  await page.close()

  console.log('CONSOLE_ERRORS:', consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : '(none)')
  const pass = results.baseline.present && results.moveHintVisible &&
    typeof movedState.x === 'number' && typeof movedState.y === 'number' &&
    reloaded.present && resetState.x === undefined && resetState.y === undefined &&
    summon.present && summon.whaleGone && afterSummon.whaleBack &&
    group.expanded === 'true' && group.cardVisible && group.switchPresent
  console.log('VERDICT:', pass ? 'PASS' : 'FAIL')
  fs.writeFileSync(path.join(OUT, 't1-results.json'), JSON.stringify(results, null, 2))
  await browser.close()
  if (!pass) process.exit(2)
})().catch((e) => { console.error('VERIFY FAILED:', e); process.exit(1) })
