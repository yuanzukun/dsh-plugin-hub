// t3 verification: whale settings card default-expanded, whale render,
// optimistic hide latency, state restore. Runs against the live GUI at
// http://127.0.0.1:3080 (must be running). Restores the exact pre-run state.
// t3 verify (see FINDINGS-t3-dropdown-performance.md)
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  const events = []
  page.on('pageerror', (e) => events.push('PAGEERROR: ' + String(e).slice(0, 200)))

  await page.addInitScript(() => {
    const origFetch = window.fetch
    const marks = {}
    window.fetch = (...args) => {
      const url = String(args[0])
      if (url.includes('/api/ventus-whale/')) {
        const key = url.split('/').pop() + ':' + (args[1] ? args[1].method : 'GET') + ':' + (args[1] ? String(args[1].body).slice(0, 60) : '')
        marks[key] = performance.now()
        console.log('VENTUS_FETCH>>', Math.round(performance.now()), key)
        return origFetch(...args).then((r) => {
          console.log('VENTUS_FETCH<<', Math.round(performance.now()), key, r.status)
          return r
        })
      }
      return origFetch(...args)
    }
    window.__ventusMarks = marks
  })

  // Current state
  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 60000 })
  await page.waitForTimeout(2000)
  const orig = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('ORIG:', JSON.stringify(orig))

  // Enable whale, keep position
  await page.evaluate(async () => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ enabled: true }) })
  })
  await page.reload({ waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(6000)

  const wrapper = page.locator('[data-ventus-whale]')
  const box = await wrapper.boundingBox()
  console.log('BOX:', JSON.stringify(box))

  // Hover -> toolbar -> hide, with timing
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2)
  await page.waitForTimeout(700)
  const hideBtn = page.locator('[data-ventus-whale] button:has-text("隐藏")')
  const hb = await hideBtn.boundingBox()
  console.log('HIDE_BTN:', JSON.stringify(hb))
  if (hb) {
    const tClick = Date.now()
    console.log('CLICK_AT_MS:', tClick)
    await page.mouse.move(hb.x + hb.width / 2, hb.y + hb.height / 2)
    await page.waitForTimeout(120)
    await page.mouse.click(hb.x + hb.width / 2, hb.y + hb.height / 2)
    // poll display with rAF in-page for precision
    const hiddenAt = await page.evaluate(async (start) => {
      return await new Promise((resolve) => {
        let last = start
        const check = () => {
          const w = document.querySelector('[data-ventus-whale]')
          const now = Date.now()
          if (w && getComputedStyle(w).display === 'none') { resolve(now); return }
          if (now - last > 500) { last = now } // watchdog
          requestAnimationFrame(check)
        }
        requestAnimationFrame(check)
      })
    }, tClick)
    console.log('HIDE_LATENCY_MS:', hiddenAt - tClick)
    // fetch trace
    const trace = await page.evaluate(() => {
      const t = performance.getEntriesByType('resource').filter(r => r.name.includes('ventus-whale')).map(r => ({ n: r.name.split('/').pop(), dur: Math.round(r.duration), start: Math.round(r.startTime) }))
      return t
    })
    console.log('FETCH_TRACE:', JSON.stringify(trace))
  }

  // Settings card default-expanded check
  await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('button, [role=button], a'))
    const hit = els.find((el) => el.textContent.trim() === '设置' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(3000)
  await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return
    const rows = Array.from(d.querySelectorAll('button, [role=button], div, span'))
    const hit = rows.find((el) => el.textContent.trim() === '插件' && el.offsetParent !== null)
    if (hit) hit.click()
  })
  await page.waitForTimeout(4000)
  const card = await page.evaluate(() => {
    const d = document.querySelector('[role=dialog]')
    if (!d) return { dialog: false }
    const btn = Array.from(d.querySelectorAll('button[aria-label]')).find((b) => (b.getAttribute('aria-label') || '').includes('设置'))
    const cardEl = btn ? btn.closest('li') : null
    const body = cardEl ? cardEl.querySelector('[class*=cardBody]') : null
    return {
      dialog: true,
      chevronAria: btn ? btn.getAttribute('aria-label') : null,
      bodyVisible: !!(body && body.offsetParent !== null),
      rangeCount: cardEl ? cardEl.querySelectorAll('input[type=range]').length : -1,
      textInputs: cardEl ? cardEl.querySelectorAll('input[type=text]').length : -1,
    }
  })
  console.log('WHALE_CARD2:', JSON.stringify(card))
  await page.screenshot({ path: 'E:/ProgramData/deepseek-harness/DSH_Anything/.ventus-verify/t3-settings-expanded.png' })

  // Restore exact original state
  await page.evaluate(async (o) => {
    await fetch('/api/ventus-whale/update', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(o) })
  }, orig)
  const restored = await page.evaluate(async () => (await (await fetch('/api/ventus-whale/state')).json()).config)
  console.log('RESTORED:', JSON.stringify(restored))
  console.log('EVENTS:', JSON.stringify(events.slice(0, 5)))
  await browser.close()
})().catch((e) => { console.error('PROBE8 FAILED:', e); process.exit(1) })

