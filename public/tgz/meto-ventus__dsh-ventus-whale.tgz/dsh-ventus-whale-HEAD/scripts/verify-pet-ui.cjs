// Probe the GUI for conversation affordances (to force the dock slot to mount).
const path = require('path')
const { chromium } = require(path.join('E:/ProgramData/deepseek-harness/plugins/dsh-web-ui/node_modules/playwright'))

;(async () => {
  const browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--disable-gpu', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } })
  await page.goto('http://127.0.0.1:3080', { waitUntil: 'domcontentloaded', timeout: 30000 })
  await page.waitForTimeout(8000)

  const ui = await page.evaluate(() => {
    const buttons = Array.from(document.querySelectorAll('button, [role=button], a'))
      .map((b) => ({ tag: b.tagName, text: (b.textContent || '').trim().slice(0, 30), aria: b.getAttribute('aria-label') }))
      .filter((b) => b.text || b.aria)
      .slice(0, 60)
    const dock = !!document.querySelector('[data-testid="pet-dock"]')
    const composer = !!document.querySelector('textarea')
    return { buttons, dock, composer, bodyText: document.body.innerText.slice(0, 300) }
  })
  console.log(JSON.stringify(ui, null, 2))
  await browser.close()
})().catch((e) => { console.error('FAILED:', e); process.exit(1) })
