# 第三方声明

本插件 client bundle 内联了以下第三方库：

## three.js（MIT）

- 项目：https://github.com/mrdoob/three.js
- 许可证：MIT License
- 用途：3D 虎鲸模型的渲染、几何构建与交互（渲染循环、WebGLRenderer、几何/材质/精灵）。

Copyright (c) 2010-2024 three.js authors

MIT License 全文见 https://github.com/mrdoob/three.js/blob/dev/LICENSE