/**
 * dsh-md-quiz 插件类型声明（极简版）。
 *
 * 服务端半区（lib/index.js）导出：
 * - apply(ctx): 注册 md-quiz-read 技能、/mdquiz 命令、GET /mdquiz/read 路由
 * - inject: ["skills", "commands", "webServer"]
 */
export function apply(ctx: unknown): void;

export const inject: string[];
