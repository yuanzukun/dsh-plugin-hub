# 开发「阅读区」的经验总结（dsh-md-quiz 插件）

> 记录本次给 DeepSeek Harness 写「答题式阅读」插件客户端 UI（侧边栏面板 + 对话区「阅读区」tab）时踩过的坑与可复用的结论。适用于后续在 DSH 上写双半区插件。

## 一、DSH 客户端插件的地基知识

1. **客户端 bundle 是手写 factory**：`window.__ModuleLoader__.load({ id, factory })`，factory 内是 CJS 风格代码，`require` 只能命中白名单外链：
   `react` / `react/jsx-runtime` / `react-dom` / `@deepseek-ai/cordis` / `@deepseek-ai/dsh-client-runtime/client` / `@deepseek-ai/dsh-client-ui-primitives` / `@deepseek-ai/dsh-client-ui-slots` / `@deepseek-ai/dsh-client-schema-form` / `@deepseek-ai/dsh-client-web-react` / `@deepseek-ai/dsh-client-ui-attachment`。其余一律 require 不到。
2. **package.json 双半区声明**：`dsh.client = { platform: "web", inject: [模块依赖...], immediately: true }` + `exports["./client"] = "./lib/client.js"`。node 半区扫描 loader 条目里带 `dsh.client` 的包，把 `./client` 编进 `window.__DSH_BOOT__`，served at `/plugins/<id>/client.js?rev=<sha1-12>`（rev = 文件内容 sha1 前 12 位）。
3. **UI 插槽**：`ctx.slots.inject(name, () => ctx.slots.register({ name, id, order, label, locale, inject }, Component))`。
   - 对话区视图 tab = `conversation.view` 槽（list；chat=0 / trajectory=10 / 阅读区=20）；`inject` 工厂会收到 `sessionId`。
   - 侧边栏底部按钮 = `sidebar.footer.action` 槽（list）。
   - `label: () => t(...)` 是 tab 文字；`locale: NS` 给组件注入绑定好的 `t`。
4. **客户端 API 面域键是复数**：`connection.api.sessions.prompt/list/history`（不是 `session`）、`connection.api.host.listDirectory/pickDirectory`、`connection.api.skills.list`。

## 二、踩过并修掉的坑（按 bug 记）

1. **`this` 丢失导致白屏（最痛）**
   `useSyncExternalStore(docStore.subscribe, docStore.getSnapshot)` 会把方法作为**裸引用**传入，调用时 `this` 是 undefined（严格模式）。于是 `this._snapshot === null` 判断失效、直接返回 undefined → `snapshot.path` 抛「Cannot read properties of undefined (reading 'path')」→ 组件整块空白。
   **结论**：给 uSES 的 subscribe/getSnapshot 绝不能依赖 `this`——用闭包状态（模块内 `const docState = {...}`，方法读闭包变量），或调用时 `.bind()`。同理，store 的其他方法也建议闭包化。

2. **轮询重复加载导致滚动回弹**
   阅读区 3 秒轮询识别；旧实现每轮都对同一路径 `setPath`（清空 content → 重新 fetch → 重建 DOM）→ 滚动位置被重置，表现为「拉到最底自动回弹」。
   **结论**：把「识别（识别 = 便宜、高频，只答“哪篇”）」和「加载（昂贵、低频，只答“显示内容”）」分开；识别到同一路径时跳过加载（`if (path !== docStore.path)`）。幂等守卫 + 轮询是标配。

3. **渲染崩溃 → 空白，无法排查**
   客户端插件没有给用户的 console；组件一崩就是白屏。
   **结论**：注册进槽位的外层组件套一个**错误边界**，把 `error.message` 直接渲染进 tab；同时对 `t` 等注入项做兜底（`typeof t === "function" ? t : fallbackDict`）。这一步把「啥也没有」变成了可定位的报错文字。

4. **用户消息不在 session.history 里**
   想通过 `connection.api.sessions.history` 识别「答题式阅读 <路径>」消息，但历史里只有 `assistant/chunk`、`assistant/message`、`tool/*`、`step/*`、`approval/*` —— 用户消息走的是 transient inbox，不在持久事件流。
   **结论**：识别用户消息用**客户端会话快照** `session.getSnapshot()`（`ConversationSnapshot`），其顶层兼容字段 `nodes` 含 `kind: 'user'` 的 `UserMessageNode`（`content` 是文本块数组）。绑定会话：`ctx.sessions.binding(sessionId)?.session`。

5. **相对路径解析基准错误**
   `/mdquiz/read` 服务端 `resolve(raw)` 用的是服务进程 cwd（`C:\Users\25290`），而会话 cwd 是 `C:\coding` → 相对路径 404。
   **结论**：路径一律按**会话工作目录**解析。客户端自己 `sessionId → api.sessions.list → cwd`，把相对路径拼成绝对路径再请求；服务端也接受 `cwd` 参数作兜底（`resolve(cwd, raw)`）。

6. **目录选择器能力不匹配**
   本机 auto 选择器解析为 `native`（OS 对话框），而面板需要 `browse`（应用内浏览器）能力，`host.listDirectory` 报「needs the browse capability」。且 `host.listDirectory` **只列子目录、不列文件**。
   **结论**：在 profile 补丁里 `disable` auto 行 + `insert` `dsh-host-directory-picker-browse`（后端）与 `dsh-client-ui-directory-picker-browse`（客户端 UI 面）两行。文件选择无法靠这个 API 完成，需用户补文件名或直接输路径。

## 三、DSH 运行时的坑与操作纪律

1. **补丁语义**：profile `cordis.patch.yml` 的非 insert 补丁要求 `name` 与目标行**匹配**，否则静默跳过（想换插件要「disable 旧 + insert 新」，不能直接改 name）。
2. **服务端模块改动必须重启**：loader 用 ESM `import(name)`，Node 按 URL 缓存；remove/re-add 条目不会重新 import 模块代码。**把所有服务端改动攒到一次重启里**。
3. **client-modules 增量扫描很脆**：运行中的服务器上对条目做 remove→re-add 刷新 rev 时，可能**不再把客户端条目扫回 boot 图**（bundle 404、面板/阅读区消失）。稳妥做法：**少做热 remove/re-add**；bundle 本身 `Cache-Control: no-cache` 且 serve 实时读盘，所以**改内容后直接刷新即可，不必刷 rev**；条目状态坏了就重启。
4. **`/api` 前缀被连接桥占用**：插件自定义 HTTP 路由（`ctx.webServer.register({ kind, path, handler })`）用非 `/api` 路径（本插件用 `/mdquiz/read`），`handler(req, res)` 是 node:http 风格。
5. **沙箱**：写工作区外（`C:\Users\25290\.dsh` 等）需要 `danger-full-access` 升级，且**升级会传播给子进程**；普通权限下派生进程会继承受限文件访问（写 profile 目录 EPERM）。

## 四、能反复用的验证手段

- `dsh --profile web --dump-config`：看组合树是否含插件行（需升级权限，会写 profile 的 cordis.yml）。
- **起一个临时实例**：`node <dsh>/lib/bin.js --profile web --port 3099`，验证 boot、`/plugins/<id>/client.js`、`window.__DSH_BOOT__`、skill.list，不碰生产。
- bundle 冒烟测试：Node `vm.runInThisContext` 执行 factory，primitives 用 Proxy 桩替身，断言导出 `apply/inject` 与模块级无异常。
- `window.__DSH_BOOT__` 从首页 HTML 用正则抠 JSON，核对条目 id/rev。
- **给 UI 加状态行 + 错误边界**：让用户在浏览器里就能看到「识别到没 / 加载没 / 报什么错」，是远程联调客户端 UI 的关键。

## 五、产品/交互层面的经验

1. **用户的心智模型要优先**：用户一直期待的是「发送『答题式阅读 <路径>』→ 系统把文章渲染出来」。先顺着这个模型做（消息驱动渲染 + 对话内渲染原文兜底），再谈侧栏/识别这类辅助。
2. **原文渲染与诊断诚实原则有张力**：诊断阶段要求「不许翻原文」，所以原文展示应放在 ③ 引导精读（逐段对照），或明确标注「精读材料」；不要开局就把全文怼在诊断题前面。
3. **减少重启摩擦**：这次让用户重启了多次，本质是服务端改动没能攒批。规划时先分清哪些改动只需刷新、哪些必须重启，尽量一次到位。
