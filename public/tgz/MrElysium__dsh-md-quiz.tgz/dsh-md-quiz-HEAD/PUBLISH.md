# 发布 dsh-md-quiz 到 DeepSeek Harness 生态

本文档说明如何把这个插件发布成 DSH 生态里可被 `dsh plugin add` 安装、可被
`dsh-plugin` GitHub 话题收录的正式插件。

## 1. 发布前准备（已就绪的部分）

本仓库已经按要求配好：

- `package.json`
  - `dsh.bundle.patch = "./cordis.patch.yml"` → `dsh plugin add` 会自动把它注册进 profile 的 `bundles`
  - `dsh.client = { platform: "web", inject: [...], immediately: true }` → 客户端半区被扫进 `window.__DSH_BOOT__`
  - `exports` 暴露 `.`（服务端）/ `./client`（客户端）/ `./cordis.patch.yml` / `./package.json`
  - `files` 只打包 `lib`、`cordis.patch.yml`、`README.md`、`LICENSE`
- `cordis.patch.yml`：插入了 `md-quiz` 行 + 目录选择器固定 browse 的补丁
- `lib/index.js`（服务端）、`lib/client.js`（客户端）、`lib/types/index.d.ts`、`LICENSE`

**唯一需要你改的**：`package.json` 里的 `repository.url` 占位符
`<your-account>` 换成你的 GitHub 用户名。

## 2. 发布到 npm

```bash
cd dsh-md-quiz
npm login                 # 登录 npm 账号
npm publish               # 发布
```

> 发布后包名是 `dsh-md-quiz`（想换成作用域包如 `@you/dsh-md-quiz`，改 `name` 即可）。

## 3. 建 GitHub 仓库并打 topic

1. 在 GitHub 新建仓库，把本目录 push 上去。
2. 仓库 **Settings → Topics** 添加 `dsh-plugin`（这是关键——生态市场靠这个话题自动收录）。
3. （可选）再加 `deepseek-harness`、`markdown`、`learning` 等话题。

添加 `dsh-plugin` 话题后，[AwesomeHou/dsh-plugin-marketplace](https://github.com/AwesomeHou/dsh-plugin-marketplace)、[bradeGithub/DSH-Plugins-Marketplace](https://github.com/bradeGithub/DSH-Plugins-Marketplace)、[Oh-My-DSH](https://github.com/NoWint/Oh-My-DSH) 等市场会自动同步收录（这些市场 live-sync GitHub `dsh-plugin` 话题，宣称 1800+ 仓库）。

## 4. 用户侧安装（写进 README）

```bash
dsh plugin --profile web add dsh-md-quiz   # 安装 + 自动注册进 bundles
# 重启 dsh web，刷新浏览器即可
```

原理：`dsh plugin add` = `pnpm add` + 对 `dsh.profile.bundles` 做 reconcile——
声明了 `dsh.bundle.patch` 的包会自动加入 bundle 层栈，其 `cordis.patch.yml`
在下次 boot 时组合进 profile，无需用户手改补丁。

## 5. 验证清单

- [ ] `npm publish` 成功，`npm view dsh-md-quiz` 能查到
- [ ] 干净环境 `dsh plugin --profile web add dsh-md-quiz` → 重启 → 侧边栏出现「🎮 答题式阅读」、对话区出现「阅读区」tab
- [ ] 面板「浏览目录」可用（browse 能力补丁已含）
- [ ] `答题式阅读 <任意 md>` 能走通 5 阶段 + 结算写入 `.md-quiz-read-progress.md`

## 注意事项

- **目录选择器副作用**：本插件把全局目录选择器固定为 browse（应用内浏览器），
  因为 native（OS 对话框）会导致面板浏览报错。若你想保留原生对话框，删掉
  `cordis.patch.yml` 里目录选择器的 4 行（面板仍可手动输路径）。
- **服务端改动需重启**：DSH 用 ESM import 缓存，服务端半区（lib/index.js）改动
  后必须重启 `dsh web` 才生效；客户端半区（lib/client.js）是 no-cache 实时读盘，
  改完刷新即可。
- **Node 版本**：DSH 要求 Node 20+。
