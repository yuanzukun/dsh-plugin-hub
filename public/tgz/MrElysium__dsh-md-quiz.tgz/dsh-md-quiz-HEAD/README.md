# dsh-md-quiz — DeepSeek Harness「答题式阅读」插件（真·插件 + Web UI）

把 `每日学习协议.md`（先诊断后带练）做成一个**可安装进 dsh web profile 的双半区插件**：
- **服务端半区**（`lib/index.js`）：向 DSH 注册 `md-quiz-read` 技能（模型侧协议）、`/mdquiz` 命令（UI 命令面）、`GET /mdquiz/read?path=…` 文件读取路由（供阅读区显示原文，仅限 .md/.markdown/.txt/.rst，≤512KB）。
- **客户端半区**（`lib/client.js`）：Web 侧边栏底部「🎮 答题式阅读」闯关面板（阶段流程条 / 开始闯关 / 只测我 / 抽查我 / 结算打卡 / 闯关规则），以及对话区 **「阅读区」tab**（聊天 | 轨迹 | 阅读区，显示 Markdown 原文，自动识别会话里的闯关消息）。

通用性：不绑定任何项目。任何目录里的 `.md` 都能用——面板里填路径即可，相对路径按会话工作目录解析。

## 安装

> 前置：装有 `pnpm`（`dsh plugin` 通过 pnpm 安装）。

**方式一：从 GitHub 装（推荐，公开分享即用）**

```bash
dsh plugin --profile web add github:<你的账号>/dsh-md-quiz
# 重启 dsh web，浏览器刷新
```



**方式二:本地开发装**

```bash
dsh plugin --profile web add link:./path/to/dsh-md-quiz
```

> 两种方式都会自动把插件注册进 `dsh.profile.bundles`（因为本包声明了
> `dsh.bundle.patch`），无需手改补丁。

### 验证

- 重启后访问 `http://127.0.0.1:3080/plugins/dsh-md-quiz/client.js` 返回 200；页面源码 `window.__DSH_BOOT__` 里出现 `dsh-md-quiz` 条目。
- 侧边栏底部出现「🎮 答题式阅读」；对话区上方出现「阅读区」tab（聊天 | 轨迹 | 阅读区）。
- 会话里说「答题式阅读 <任意 md 路径>」即触发 5 阶段阅读；输入框 `/mdquiz` 命令可见。

## 使用

| 操作 | 效果 |
|:--|:--|
| 侧边栏「答题式阅读」→ 填路径 → 「🚀 开始闯关」 | 向当前会话发送 `答题式阅读 <路径>`，陪练按 5 阶段带读 |
| 「📝 只测我」 | 发送 `只测我 <路径>`，只出 3 题诊断不教学 |
| 「🎯 抽查我」 | 发送 `抽查我 <路径>`，从已学章节随机出题 |
| 「💰 结算打卡」 | 发送 `结算`，输出结算框并写打卡日志 |
| 对话区「阅读区」tab | 显示当前文档原文（自动识别会话里的闯关消息，或手动输路径加载） |
| 输入框 `/mdquiz <路径>` | 命令面提示，同样可发起 |

进度默认记在 `<文档目录>/.md-quiz-read-progress.md`（XP / 连击 / 等级，规则同 `每日学习协议.md`）。

## 卸载

```bash
dsh plugin --profile web remove dsh-md-quiz
# 重启 dsh web
```

## 结构

```
dsh-md-quiz/
├── package.json        # dsh.bundle.patch + dsh.client 声明、exports、files
├── cordis.patch.yml    # bundle 补丁：挂载本插件 + 目录选择器固定 browse
├── lib/
│   ├── index.js        # 服务端：技能注册 + /mdquiz 命令 + /mdquiz/read 路由
│   ├── client.js       # 客户端 bundle：侧边栏面板 + 阅读区 tab
│   └── types/index.d.ts
├── README.md           # 本说明
├── PUBLISH.md          # 发布到 DSH 生态的步骤
├── NOTES.md            # 开发经验总结（DSH 客户端插件踩坑记录）
└── LICENSE             # MIT
```

## 注意

- **目录选择器**：本插件把全局目录选择器固定为 browse（应用内浏览器），否则
  本机（win32 + 回环）会解析成 native 导致面板「浏览目录」报错。若想保留系统
  原生目录对话框，删掉 `cordis.patch.yml` 里目录选择器的 4 行。
- **服务端改动需重启**，客户端改动刷新即可（详见 NOTES.md）。
- 在 rc.7 上开发与验证