# dsh-workspace-sidebar

DSH Web 右侧工作区侧边栏：文件树 / git 差异 / 提交历史 / `@文件` 引用。

## 功能

- **文件**：懒加载目录树、文件重命名/删除（「⋯」菜单）、Markdown / 代码高亮预览，自动刷新（2s，单在途防叠票）
- **差异**：git 变更文件列表（M=修改 / D=删除 / U=新建，优先级 M>D>U）、点文件看 diff，自动刷新（4s，单在途防叠票）
- **提交历史**：`git log --graph` 提交树，点提交展开改动文件，点文件看该次提交 diff
- **@文件**：文件行悬停「@」按钮，把 `@相对路径` 追加到输入框
- 右侧停靠、可拖拽调宽（拖拽中断/快速松手提交最后位置、不回弹），把会话区往左推（data 属性锚点 + CSS 变量，DSH 升级不依赖布局类名）

## 截图

### 文件（目录树 + 富文本预览）

![alt text](image.png)

### 差异（M / D / U 变更列表）

![alt text](image-1.png)

## 安装

```bash
# 从 GitHub
dsh plugin --profile web add github:pang123hui/dsh-workspace-sidebar

# 从 npm（发布后）
dsh plugin --profile web add dsh-workspace-sidebar
```

装完重启 `dsh web`（Ctrl+C 后重跑），浏览器硬刷新即可。

## 手动安装（不想用 `dsh plugin` 时）

1. 把本包链接到 `~/.dsh/profiles/node_modules/dsh-workspace-sidebar`（Windows 用 junction，macOS/Linux 用 symlink）
2. 在 `~/.dsh/profiles/web/cordis.patch.yml` 里加：

```yaml
- insert:
    - id: workspace-sidebar
      name: 'dsh-workspace-sidebar'
```

## 开发

- `lib/index.js` — host 半，`/wspan/api/*` HTTP 路由（文件读取、git 操作）
- `lib/client.js` — client 半，`window.__ModuleLoader__.load` 打包格式

client 半改动后浏览器硬刷新即可；host 半改动需重启 `dsh web`。

## 已知限制

- **写操作已绕过 DSH shell 沙箱**：文件删除/重命名走 host 进程内 Node fs（`unlink`/`rename`），git 操作经 `sandboxPolicy: danger-full-access` 执行——不再受会话工作区限制，任意目录可删/可改/可暂存/可提交。但**文件系统级 ACL 拒绝（Windows 层）绕不过**：若某目录（如 `.git`）被外部工具显式 `icacls ... /deny` 锁定写入，报「操作被拒绝……」时需管理员解除对应 DENY；只读浏览不受影响。

## License

MIT
