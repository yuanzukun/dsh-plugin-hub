# Security Policy

## Reporting a vulnerability

Please report security vulnerabilities **privately** using GitHub's
private vulnerability reporting:

1. Open the **Security** tab of this repository.
2. Click **Report a vulnerability**.
3. Describe the vulnerability, the affected version, and how to reproduce it.

Please do **not** open a public issue for security problems — doing so gives
attackers a head start before a fix is released.

## What to include

- Package version (`dsh-tang-governance` from `package.json` or npm output)
- DeepSeek Harness version
- A minimal reproduction, if possible
- Impact assessment (what an attacker could do)

## Response

We aim to acknowledge reports within **3 business days** and will keep you
informed as the fix is prepared. We ask that you refrain from public disclosure
until a fix is published.
