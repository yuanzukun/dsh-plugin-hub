import { tmpdir } from 'node:os'
import { describe, expect, it, vi } from 'vitest'
import { apply } from '../src/tool.ts'
import { TANG_REMAND_LABEL } from '../src/contracts.ts'

interface RegisteredTool {
  readonly name: string
  readonly execute: (value: unknown, execution: unknown) => Promise<unknown>
}

function setup(answer: unknown) {
  const registered: RegisteredTool[] = []
  const ask = vi.fn(async (..._args: unknown[]) => answer)
  const followup = vi.fn(async (..._args: unknown[]) => 'remand-message-1')
  const startContinuable = vi.fn(async (..._args: unknown[]) => ({ childId: 'recovery-zhongshu' }))
  const listChildren = vi.fn(async (): Promise<unknown[]> => [
    { kind: 'child', mode: 'continuable', label: '[中书省] 原需求', id: 'zhongshu-old' },
    { kind: 'child', mode: 'continuable', label: '[中书省] 最终报告', id: 'zhongshu-report' },
    { kind: 'child', mode: 'continuable', label: '[门下省] 验收', id: 'menxia' },
  ])
  let guard: ((exec: unknown, next: () => Promise<unknown>) => Promise<unknown>) | undefined
  apply({
    on: vi.fn((name: string, callback: typeof guard) => {
      if (name === 'tools/pre-execute') guard = callback
    }),
    inject: vi.fn(),
    systemPrompt: { section: vi.fn() },
    tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
    subagents: { listChildren, startContinuable, followup },
    userQuestions: { ask },
  } as never)
  const report = registered.find(tool => tool.name === 'tang_submit_final_report')!
  const clarification = registered.find(tool => tool.name === 'tang_request_clarification')!
  return { report, ask, followup, listChildren, startContinuable, guard, clarification }
}

const request = {
  case_id: 'case-closed', title: '是否确认结案？', report_markdown: '# 最终报告\n18 tests passed',
}
const acceptanceEvents = [
  { type: 'tool/call', data: { name: 'tang_progress', callId: 'acceptance-1',
    arguments: JSON.stringify({ stage: 'menxia-acceptance', status: 'passed' }) } },
  { type: 'tool/result', data: { message: { source: { callId: 'acceptance-1' },
    content: [{ isError: false, content: [{ type: 'text', text: 'menxia-acceptance: passed' }] }] } } },
]
const parent = { id: 'root', session: { header: { id: 'root', cwd: tmpdir() }, events: acceptanceEvents } }
const remandEvents = [
  ...acceptanceEvents,
  { type: 'tool/call', data: { name: 'tang_submit_final_report', callId: 'close-1', arguments: JSON.stringify(request) } },
  { type: 'tool/result', data: { message: { source: { callId: 'close-1' },
    content: [{ isError: false, content: [{ type: 'text', text: `${TANG_REMAND_LABEL} · case-closed · 已转交中书省 zhongshu-report` }] }] } } },
]
const signal = new AbortController().signal

describe('runtime closure remand routing', () => {
  it('resumes the latest Zhongshu with original feedback before returning', async () => {
    const { report, followup, startContinuable } = setup({ answers: [
      { id: 'tang-final-report', selected: [TANG_REMAND_LABEL], custom: '手动测试发现粘贴两次' },
    ] })
    await expect(report.execute(request, { agent: parent, signal })).resolves.toMatchObject({
      decision: 'remanded', feedback: '手动测试发现粘贴两次', zhongshuId: 'zhongshu-report',
      messageId: 'remand-message-1', nextAction: 'wait_for_zhongshu',
    })
    expect(followup).toHaveBeenCalledWith(parent, 'zhongshu-report', [expect.objectContaining({
      text: expect.stringContaining('手动测试发现粘贴两次'),
    })], expect.objectContaining({ signal }))
    expect(JSON.stringify(followup.mock.calls)).toContain('tang_raise_clarification')
    expect(startContinuable).not.toHaveBeenCalled()
  })

  it.each([
    { selected: [], custom: '需要修订报告' },
    { selected: [TANG_REMAND_LABEL] },
  ])('routes custom-only or empty-feedback remands: %j', async answer => {
    const { report, followup, ask } = setup({ answers: [{ id: 'tang-final-report', ...answer }] })
    await expect(report.execute(request, { agent: parent, signal }))
      .resolves.toMatchObject({ decision: 'remanded', zhongshuId: 'zhongshu-report' })
    expect(followup).toHaveBeenCalledOnce()
    expect(ask).toHaveBeenCalledOnce()
  })

  it('creates a recovery Zhongshu only when no resumable child exists', async () => {
    const { report, listChildren, startContinuable, followup } = setup({ answers: [
      { id: 'tang-final-report', selected: [TANG_REMAND_LABEL], custom: '重新检查验收证据' },
    ] })
    listChildren.mockResolvedValue([])
    await expect(report.execute(request, { agent: parent, signal }))
      .resolves.toMatchObject({ decision: 'remanded', zhongshuId: 'recovery-zhongshu' })
    expect(startContinuable).toHaveBeenCalledWith(expect.objectContaining({
      label: '[中书省] 结案驳回 · case-closed',
      request: expect.objectContaining({ parent, prompt: [expect.objectContaining({
        text: expect.stringContaining('TANG_OFFICE:zhongshu'),
      })] }),
    }))
    expect(followup).not.toHaveBeenCalled()
  })

  it('does not fall back to coordinator handling on failed delivery', async () => {
    const { report, followup, startContinuable } = setup({ answers: [
      { id: 'tang-final-report', selected: [TANG_REMAND_LABEL] },
    ] })
    followup.mockRejectedValue(new Error('delivery unavailable'))
    await expect(report.execute(request, { agent: parent, signal })).rejects.toThrow('delivery unavailable')
    expect(startContinuable).not.toHaveBeenCalled()
  })

  it('does not create a duplicate when historical child identity is unavailable', async () => {
    const { report, listChildren, startContinuable } = setup({ answers: [
      { id: 'tang-final-report', selected: [TANG_REMAND_LABEL] },
    ] })
    listChildren.mockResolvedValue([{ kind: 'diagnostic', id: 'unknown', reason: 'unavailable' }])
    await expect(report.execute(request, { agent: parent, signal })).rejects.toThrow('Cannot resolve Zhongshu history')
    expect(startContinuable).not.toHaveBeenCalled()
  })

  it('blocks default coordinator questions after durable remand without affecting unrelated sessions', async () => {
    const { guard } = setup({ answers: [] })
    const next = vi.fn(async () => ({ kind: 'allow' }))
    await expect(guard!({ name: 'ask_user_question', agent: { session: { events: remandEvents } } }, next))
      .resolves.toMatchObject({ kind: 'deny', reason: expect.stringContaining('中书省') })
    expect(next).not.toHaveBeenCalled()
    await expect(guard!({ name: 'ask_user_question', agent: parent }, next)).resolves.toEqual({ kind: 'allow' })
    await expect(guard!({ name: 'tang_request_clarification', agent: parent }, next)).resolves.toEqual({ kind: 'allow' })
  })

  it('only relays unchanged clarification actually reported by Zhongshu after remand', async () => {
    const { clarification, ask } = setup({ answers: [{ id: 'tang-clarification:case-closed:behavior', selected: ['一次'] }] })
    const questions = [{ id: 'behavior', question: '预期粘贴几次？' }]
    const args = { case_id: 'case-closed', zhongshu_id: 'zhongshu-report', questions }
    const exec = { agent: { ...parent, session: { ...parent.session, events: remandEvents } }, signal }
    await expect(clarification.execute(args, exec)).rejects.toThrow('cannot invent')
    expect(ask).not.toHaveBeenCalled()
    const reportEvent = { type: 'user/message', data: {
      source: { kind: 'subagent-report', senderSessionId: 'zhongshu-report' },
      content: [{ type: 'text', text: '<tang-clarification-request>\ncase_id: case-closed\n' + JSON.stringify({ questions }) }],
    } }
    const relayExec = { ...exec, agent: { ...parent, session: { ...parent.session, events: [...remandEvents, reportEvent] } } }
    await expect(clarification.execute({ ...args, questions: [{ ...questions[0], question: '协调器改写的问题' }] }, relayExec))
      .rejects.toThrow('cannot invent')
    await expect(clarification.execute(args, relayExec)).resolves.toMatchObject({ zhongshuId: 'zhongshu-report' })
    expect(ask).toHaveBeenCalledOnce()
  })
})
