import { describe, expect, it, vi } from 'vitest'
import { assertCaseArtifact, assertCaseReferences } from '../src/artifact-scope.ts'
import { apply } from '../src/tool.ts'

describe('case artifact submission scope', () => {
  it.each([
    '.tang/cases/case-1/evidence/checklist.md',
    '.tang\\cases\\case-1\\evidence\\screenshot.png',
    './.tang/cases/case-1/tests/output.log',
  ])('accepts case-local artifact %s', path => {
    expect(() => assertCaseArtifact(path, 'case-1', 'artifact')).not.toThrow()
  })

  it.each([
    '.tang/evidence/checklist.md', '.tang/reports/report.md',
    '.tang/workspace-knowledge.md', '.tang/cases/case-2/checklist.md',
    '.tang/cases/case-1/../case-2/report.md',
    '.tang\\cases\\case-1\\..\\..\\evidence\\check.md',
    'G:\\repo\\.tang\\cases\\case-1\\check.md',
    '.tang/cases/case-1/file.md:stream', '.tang/cases/case-1/.. /report.md',
    '.tang/cases/case-1/',
  ])('rejects ambiguous or out-of-case artifact %s', path => {
    expect(() => assertCaseArtifact(path, 'case-1', 'artifact')).toThrow('under .tang/cases/case-1/')
    expect(() => assertCaseReferences([`证据：\`${path}\``], 'case-1', 'evidence')).toThrow()
  })

  it('preserves source paths and command evidence alongside valid case artifacts', () => {
    expect(() => assertCaseReferences([
      'src/ui/settings.rs', 'cargo test: 681 passed', 'README.md',
      '[清单](.tang/cases/case-1/evidence/check.md)',
    ], 'case-1', 'evidence')).not.toThrow()
    expect(() => assertCaseReferences(['[清单](.tang/evidence/check.md)'], 'case-1', 'evidence')).toThrow()
    expect(() => assertCaseReferences([], '../escape', 'evidence')).toThrow('case_id')
  })

  it('enforces scope in progress and ministry result tools before recording success', async () => {
    const tools: { name: string; execute: (args: unknown, exec: unknown) => Promise<unknown> }[] = []
    apply({ on: vi.fn(), inject: vi.fn(), systemPrompt: { section: vi.fn() },
      tools: { register: (tool: typeof tools[number]) => tools.push(tool) },
    } as never)
    const progress = tools.find(tool => tool.name === 'tang_progress')!
    const args = { case_id: 'case-1', office: 'rites', stage: 'ministry-execution',
      status: 'succeeded', title: '契约核对完成', artifact_path: '.tang/evidence/check.md' }
    const exec = { agent: { session: { events: [] } } }
    await expect(progress.execute(args, exec)).rejects.toThrow('under .tang/cases/case-1/')
    await expect(progress.execute({ ...args, artifact_path: '.tang/cases/case-1/evidence/check.md' }, exec))
      .resolves.toMatchObject({ recorded: true })
    const result = tools.find(tool => tool.name === 'tang_record_ministry_result')!
    await expect(result.execute({ case_id: 'case-1', phase: 'p1', assignment_id: 'rites-ui',
      office: 'rites', status: 'succeeded', summary: '完成', evidence: ['.tang/evidence/check.md'],
    }, exec)).rejects.toThrow('under .tang/cases/case-1/')
    const plan = tools.find(tool => tool.name === 'tang_plan_ministries')!
    await expect(plan.execute({ case_id: 'case-1', phase: 'p1', changes_code: true, omissions: [],
      assignments: [{ assignment_id: 'rites-ui', office: 'rites', domain: 'interfaces-documentation',
        role: 'verification', objective: '契约核对', deliverables: ['.tang/evidence/check.md'],
        verification: 'cargo test', reasoning_effort: 'high' }],
    }, exec)).rejects.toThrow('under .tang/cases/case-1/')
  })
})
