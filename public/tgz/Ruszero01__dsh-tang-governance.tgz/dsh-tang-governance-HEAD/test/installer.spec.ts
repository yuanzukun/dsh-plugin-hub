import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import { apply } from '../src/index.ts'

describe('preset installer', () => {
  it('derives Tang from the target installation standard preset', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-tang-preset-'))
    const directory = join(root, 'tang')
    const compositionPath = join(directory, 'agent.cordis.yml')
    const copy = vi.fn(async () => {
      await import('node:fs/promises').then(fs => fs.mkdir(directory, { recursive: true }))
      await writeFile(compositionPath, "- id: inherited\n  name: 'standard/tool'\n", 'utf8')
    })
    const logger = { info: vi.fn(), warn: vi.fn() }
    const context = {
      agentPresets: {
        list: async () => [],
        copy,
        resolve: async () => ({ id: 'tang', path: compositionPath }),
      },
      logger,
    }

    await apply(context as never)

    expect(copy).toHaveBeenCalledWith('standard', 'tang', '三省六部模式')
    expect(await readFile(compositionPath, 'utf8')).toContain("name: 'dsh-tang-governance/tool'")
    expect(await readFile(join(directory, 'preset.yml'), 'utf8')).toContain('order: 5')
    expect(JSON.parse(await readFile(join(directory, '.dsh-tang-governance.json'), 'utf8'))).toEqual({
      package: 'dsh-tang-governance',
      presetVersion: 1,
    })
  })

  it('does not overwrite an unrelated preset named tang', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-tang-owned-'))
    const compositionPath = join(root, 'agent.cordis.yml')
    await writeFile(compositionPath, "- id: mine\n  name: 'my/plugin'\n", 'utf8')
    const logger = { info: vi.fn(), warn: vi.fn() }
    const context = {
      agentPresets: {
        list: async () => [{ id: 'tang', path: compositionPath }],
      },
      logger,
    }

    await apply(context as never)

    expect(await readFile(compositionPath, 'utf8')).not.toContain('dsh-tang-governance/tool')
    expect(logger.warn).toHaveBeenCalledOnce()
  })
})
