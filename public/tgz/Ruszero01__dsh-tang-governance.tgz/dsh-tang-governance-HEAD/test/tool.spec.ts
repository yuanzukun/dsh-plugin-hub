import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import { apply } from '../src/tool.ts'

interface RegisteredTool {
  readonly name: string
  readonly execute: (value: unknown, execution: unknown) => Promise<unknown>
}

type PreStepListener = (
  payload: { agent: unknown; signal: AbortSignal },
  next: () => Promise<unknown>,
) => Promise<unknown>

type RequestListener = (
  payload: { agent: { session: { events: readonly unknown[] } } },
  next: () => Promise<{ provider: string; model: string; reasoningEffort?: string; maxTokens?: number }>,
) => Promise<{ provider: string; model: string; reasoningEffort?: string; maxTokens?: number }>

function harness(events: readonly unknown[]) {
  const registered: RegisteredTool[] = []
  const startContinuable = vi.fn(async () => ({ childId: 'child-1' }))
  const context = {
    on: vi.fn(),
    inject: vi.fn(),
    systemPrompt: { section: vi.fn() },
    tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
    subagents: { startContinuable, listChildren: vi.fn(async () => []) },
  }
  apply(context as never)
  const delegate = registered.find(tool => tool.name === 'tang_delegate')
  if (delegate === undefined) throw new Error('tang_delegate was not registered')
  const execution = {
    agent: { session: { events } },
    signal: new AbortController().signal,
  }
  return { delegate, execution, startContinuable }
}

const shangshuRequest = {
  office: 'shangshu',
  description: '执行已批准方案',
  prompt: 'TANG_OFFICE:shangshu\nImplement the approved phases.',
}

describe('Tang delegation authority', () => {
  it('rejects Shangshu before the explicit user-approval evidence pair', async () => {
    const { delegate, execution, startContinuable } = harness([])

    await expect(delegate.execute(shangshuRequest, execution)).rejects.toThrow(
      'Shangshu cannot start before a successful Tang approval',
    )
    expect(startContinuable).not.toHaveBeenCalled()
  })

  it('accepts Shangshu only after approval result and passed milestone', async () => {
    const events = [
      {
        type: 'tool/call',
        data: { name: 'ask_user_question', callId: 'approval-call', arguments: '{}' },
      },
      {
        type: 'tool/result',
        data: {
          message: {
            source: { callId: 'approval-call' },
            content: [{ isError: false, content: [{ type: 'text', text: '批准执行' }] }],
          },
        },
      },
      {
        type: 'tool/call',
        data: {
          name: 'tang_progress',
          callId: 'progress-call',
          arguments: JSON.stringify({ stage: 'user-approval', status: 'passed' }),
        },
      },
    ]
    const { delegate, execution, startContinuable } = harness(events)

    await expect(delegate.execute(shangshuRequest, execution)).resolves.toEqual({
      office: 'shangshu',
      subagentId: 'child-1',
    })
    expect(startContinuable).toHaveBeenCalledOnce()
  })

  it('accepts the dedicated Tang approval result as execution authority', async () => {
    const events = [
      {
        type: 'tool/call',
        data: { name: 'tang_request_approval', callId: 'tang-approval', arguments: '{}' },
      },
      {
        type: 'tool/result',
        data: {
          message: {
            source: { callId: 'tang-approval' },
            content: [{ isError: false, content: [{ type: 'text', text: '批准执行 · case-1' }] }],
          },
        },
      },
      {
        type: 'tool/call',
        data: {
          name: 'tang_progress',
          callId: 'progress-call',
          arguments: JSON.stringify({ stage: 'user-approval', status: 'passed' }),
        },
      },
    ]
    const { delegate, execution } = harness(events)

    await expect(delegate.execute(shangshuRequest, execution)).resolves.toMatchObject({ office: 'shangshu' })
  })

  it('rejects a ministry delegated directly by the coordinator', async () => {
    const { delegate, execution, startContinuable } = harness([])

    await expect(delegate.execute({
      office: 'works',
      description: '实现功能',
      prompt: 'TANG_OFFICE:works\nImplement the feature.',
    }, execution)).rejects.toThrow('only Shangshu delegates Ministries')
    expect(startContinuable).not.toHaveBeenCalled()
  })
})

const ministryPlan = {
  case_id: 'case-ministries',
  phase: 'P1 feature implementation',
  changes_code: true,
  assignments: [
    {
      assignment_id: 'war-feature',
      office: 'war',
      domain: 'application-code',
      role: 'implementation',
      objective: 'Implement the approved application behavior.',
      deliverables: ['src/feature.ts'],
      verification: 'pnpm test -- feature',
      reasoning_effort: 'high',
    },
    {
      assignment_id: 'justice-feature',
      office: 'justice',
      domain: 'quality-security',
      role: 'verification',
      objective: 'Independently verify behavior and regressions.',
      deliverables: ['test/feature.spec.ts', 'verification report'],
      verification: 'pnpm test -- feature && pnpm typecheck',
      reasoning_effort: 'medium',
      depends_on: ['war-feature'],
    },
  ],
  omissions: [
    { office: 'personnel', reason: 'The approved phase is already bounded to one package.' },
    { office: 'revenue', reason: 'No data, dependency, resource, or performance surface changes.' },
    { office: 'rites', reason: 'No API, UI, compatibility, or documentation contract changes.' },
    { office: 'works', reason: 'No build, infrastructure, packaging, or release changes.' },
  ],
} as const

function ministryPlanEvents(plan: unknown = ministryPlan): readonly unknown[] {
  return [
    { type: 'subagent/descriptor', data: { label: '[尚书省] 执行批准方案' } },
    { type: 'tool/call', data: { name: 'tang_plan_ministries', callId: 'plan-1', arguments: JSON.stringify(plan) } },
    {
      type: 'tool/result',
      data: {
        message: {
          source: { callId: 'plan-1' },
          content: [{ isError: false, content: [{ type: 'text', text: 'dispatch plan accepted' }] }],
        },
      },
    },
  ]
}

describe('Shangshu Ministry planning', () => {
  function setupPlan() {
    const registered: RegisteredTool[] = []
    const context = {
      on: vi.fn(),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }
    apply(context as never)
    const plan = registered.find(tool => tool.name === 'tang_plan_ministries')
    if (plan === undefined) throw new Error('tang_plan_ministries was not registered')
    return plan
  }

  const execution = {
    agent: { session: { events: [{ type: 'subagent/descriptor', data: { label: '[尚书省] 执行批准方案' } }] } },
    signal: new AbortController().signal,
  }

  it('accepts a responsibility-matched implementation and independent verification plan', async () => {
    await expect(setupPlan().execute(ministryPlan, execution)).resolves.toEqual({
      caseId: 'case-ministries',
      phase: 'P1 feature implementation',
      assignments: 2,
      assessedOffices: 6,
    })
  })

  it('requires a responsibility decision for every Ministry', async () => {
    const incomplete = {
      ...ministryPlan,
      omissions: ministryPlan.omissions.filter(item => item.office !== 'personnel'),
    }

    await expect(setupPlan().execute(incomplete, execution)).rejects.toThrow(
      'must assign or explain omission of 吏部',
    )
  })

  it('rejects a generic omission that does not reflect the changed-surface scan', async () => {
    const generic = {
      ...ministryPlan,
      omissions: ministryPlan.omissions.map(item => item.office === 'personnel'
        ? { ...item, reason: 'Not needed.' }
        : item),
    }

    await expect(setupPlan().execute(generic, execution)).rejects.toThrow(
      '吏部 omission must cite a concrete phase fact',
    )
  })

  it.each([
    ['personnel', 'repository-governance'],
    ['revenue', 'data-dependencies'],
    ['rites', 'interfaces-documentation'],
    ['war', 'application-code'],
    ['justice', 'quality-security'],
    ['works', 'infrastructure-release'],
  ])('applies the same declared-domain matching rule to %s', async (office, expectedDomain) => {
    const wrongDomain = expectedDomain === 'application-code' ? 'data-dependencies' : 'application-code'
    const invalid = {
      ...ministryPlan,
      assignments: [{ ...ministryPlan.assignments[0], office, domain: wrongDomain }],
    }

    await expect(setupPlan().execute(invalid, execution)).rejects.toThrow(
      `accepts only domain ${expectedDomain}`,
    )
  })

  it.each([
    ['personnel', 'repository-governance', 'implementation'],
    ['revenue', 'data-dependencies', 'implementation'],
    ['rites', 'interfaces-documentation', 'implementation'],
    ['war', 'application-code', 'implementation'],
    ['justice', 'quality-security', 'implementation'],
    ['works', 'infrastructure-release', 'integration'],
  ])('allows %s to make a tangible bounded phase contribution', async (office, domain, role) => {
    const offices = ['personnel', 'revenue', 'rites', 'war', 'justice', 'works'] as const
    const focused = {
      ...ministryPlan,
      phase: `P1 bounded ${office} contribution`,
      assignments: [{
        assignment_id: `${office}-work`,
        office,
        domain,
        role,
        objective: `Produce the approved bounded ${office} change.`,
        deliverables: [`artifacts/${office}-result`],
        verification: `Inspect the ${office} artifact against the phase contract.`,
        reasoning_effort: 'medium',
      }],
      omissions: offices
        .filter(candidate => candidate !== office)
        .map(candidate => ({ office: candidate, reason: `The approved phase leaves the ${candidate} responsibility surface unchanged.` })),
    }

    await expect(setupPlan().execute(focused, execution)).resolves.toEqual({
      caseId: 'case-ministries',
      phase: `P1 bounded ${office} contribution`,
      assignments: 1,
      assessedOffices: 6,
    })
  })

  it('accepts any responsibility-matched subset produced by the uniform scan', async () => {
    const scanned = {
      ...ministryPlan,
      phase: 'P1 user documentation',
      changes_code: false,
      assignments: [{
        assignment_id: 'rites-docs',
        office: 'rites',
        domain: 'interfaces-documentation',
        role: 'documentation',
        objective: 'Update the approved user-facing documentation.',
        deliverables: ['README.md'],
        verification: 'Review the rendered documentation against the approved terminology.',
        reasoning_effort: 'low',
      }],
      omissions: [
        { office: 'personnel', reason: 'Repository ownership and dependency order are already established for this documentation-only phase.' },
        { office: 'revenue', reason: 'The phase changes no data, state, dependencies, resources, or performance surfaces.' },
        { office: 'war', reason: 'The phase changes no application source, feature, refactor, or migration surface.' },
        { office: 'justice', reason: 'The phase introduces no separate defect, security, permission, or regression verification workstream.' },
        { office: 'works', reason: 'The phase changes no build, tooling, infrastructure, packaging, deployment, or release surface.' },
      ],
    }

    await expect(setupPlan().execute(scanned, execution)).resolves.toEqual({
      caseId: 'case-ministries',
      phase: 'P1 user documentation',
      assignments: 1,
      assessedOffices: 6,
    })
  })

  it('binds Ministry delegation to the accepted assignment and injects its mandate', async () => {
    const { delegate, execution, startContinuable } = harness(ministryPlanEvents())

    await expect(delegate.execute({
      office: 'war',
      assignment_id: 'war-feature',
      description: '实现已批准功能',
      prompt: 'TANG_OFFICE:war\nImplement the approved feature.',
      reasoning_effort: 'high',
    }, execution)).resolves.toMatchObject({ office: 'war' })
    expect(startContinuable.mock.calls[0]?.[0].request.prompt[0].text).toContain('<tang-ministry-assignment>')
    expect(startContinuable.mock.calls[0]?.[0].request.prompt[0].text).toContain('Stay within application-code surfaces')
  })

  it('blocks dependent Justice verification until Shangshu records implementation success', async () => {
    const justiceRequest = {
      office: 'justice',
      assignment_id: 'justice-feature',
      description: '独立验证已实现功能',
      prompt: 'TANG_OFFICE:justice\nIndependently verify the approved feature.',
      reasoning_effort: 'medium',
    }
    const blocked = harness(ministryPlanEvents())
    await expect(blocked.delegate.execute(justiceRequest, blocked.execution)).rejects.toThrow(
      'justice-feature is blocked until war-feature is recorded succeeded',
    )

    const completedEvents = [
      ...ministryPlanEvents(),
      {
        type: 'tool/call',
        data: {
          name: 'tang_delegate',
          callId: 'delegate-war',
          arguments: JSON.stringify({ office: 'war', assignment_id: 'war-feature' }),
        },
      },
      {
        type: 'tool/result',
        data: {
          message: {
            source: { callId: 'delegate-war' },
            content: [{ isError: false, content: [{ type: 'text', text: 'started 兵部 as subagent war-1' }] }],
          },
        },
      },
      {
        type: 'tool/call',
        data: {
          name: 'tang_record_ministry_result',
          callId: 'result-war',
          arguments: JSON.stringify({ assignment_id: 'war-feature', status: 'succeeded' }),
        },
      },
      {
        type: 'tool/result',
        data: {
          message: {
            source: { callId: 'result-war' },
            content: [{ isError: false, content: [{ type: 'text', text: 'war-feature · 兵部 · succeeded' }] }],
          },
        },
      },
    ]
    const ready = harness(completedEvents)
    await expect(ready.delegate.execute(justiceRequest, ready.execution)).resolves.toMatchObject({ office: 'justice' })
  })

  it('records evidence only for an accepted assignment that was delegated', async () => {
    const registered: RegisteredTool[] = []
    const context = {
      on: vi.fn(),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }
    apply(context as never)
    const resultTool = registered.find(tool => tool.name === 'tang_record_ministry_result')
    if (resultTool === undefined) throw new Error('tang_record_ministry_result was not registered')
    const delegatedEvents = [
      ...ministryPlanEvents(),
      {
        type: 'tool/call',
        data: {
          name: 'tang_delegate',
          callId: 'delegate-war',
          arguments: JSON.stringify({ office: 'war', assignment_id: 'war-feature' }),
        },
      },
      {
        type: 'tool/result',
        data: {
          message: {
            source: { callId: 'delegate-war' },
            content: [{ isError: false, content: [{ type: 'text', text: 'started 兵部 as subagent war-1' }] }],
          },
        },
      },
    ]

    await expect(resultTool.execute({
      case_id: 'case-ministries',
      phase: 'P1 feature implementation',
      assignment_id: 'war-feature',
      office: 'war',
      status: 'succeeded',
      summary: 'Approved behavior implemented.',
      evidence: ['src/feature.ts', 'pnpm test -- feature passed'],
    }, {
      agent: { session: { events: delegatedEvents } },
      signal: new AbortController().signal,
    })).resolves.toEqual({ assignmentId: 'war-feature', office: 'war', status: 'succeeded' })
  })
})

describe('Tang governance artifact boundaries', () => {
  it('keeps pre-execution artifacts decision-level and requires useful Ministry outputs', () => {
    const section = vi.fn()
    const context = {
      on: vi.fn(),
      inject: vi.fn(),
      systemPrompt: { section },
      tools: { register: vi.fn() },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }

    apply(context as never)
    const prompt = section.mock.calls[0]?.[0]?.text as string
    expect(prompt).toContain('must not prescribe function-level code, exact patches, file-by-file implementation steps')
    expect(prompt).toContain('05-phased-development.md as a phase contract')
    expect(prompt).toContain('must produce a concrete artifact, code/configuration change, measurement, or independently inspectable evidence')
    expect(prompt).toContain('Do not activate all Ministries ceremonially')
    expect(prompt).toContain('calls tang_submit_final_report again')
    expect(prompt).toContain('must never use a generic/default question tool')
    expect(prompt).toContain('.tang/workspace-knowledge.md')
    expect(prompt).toContain('only cross-case knowledge source')
    expect(prompt).toContain('Do not copy the case timeline')
  })
})

describe('Tang workspace knowledge', () => {
  function setup() {
    const registered: RegisteredTool[] = []
    const context = {
      on: vi.fn(),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }
    apply(context as never)
    const knowledge = registered.find(tool => tool.name === 'tang_workspace_knowledge')
    if (knowledge === undefined) throw new Error('tang_workspace_knowledge was not registered')
    return knowledge
  }

  it('upserts one semantic entry across cases and progressively reads details and source artifacts', async () => {
    const cwd = await mkdtemp(join(tmpdir(), 'tang-knowledge-'))
    try {
      const knowledge = setup()
      const zhongshu = {
        session: {
          header: { cwd },
          events: [{ type: 'subagent/descriptor', data: { label: '[中书省] 总结案卷' } }],
        },
      }
      const signal = new AbortController().signal
      const caseOneArtifact = '.tang/cases/case-one/07-chronicle.md'
      const caseTwoArtifact = '.tang/cases/case-two/06-final-report.md'
      await mkdir(join(cwd, '.tang', 'cases', 'case-one'), { recursive: true })
      await mkdir(join(cwd, '.tang', 'cases', 'case-two'), { recursive: true })
      await writeFile(join(cwd, caseOneArtifact), '# Case one\n\nObserved stale cache.', 'utf8')
      await writeFile(join(cwd, caseTwoArtifact), '# Case two\n\nConfirmed cache invalidation.', 'utf8')

      const first = await knowledge.execute({
        operation: 'upsert',
        case_id: 'case-one',
        entries: [{
          key: 'runtime/cache-invalidation',
          kind: 'pitfall',
          topic: '运行时缓存失效',
          scope: '插件运行时配置刷新',
          summary: '配置切换后必须同步失效运行时缓存。',
          details: '症状：旧配置继续生效。处理：在配置提交后失效缓存，并验证下一次读取。',
          state: 'provisional',
          evidence: [{ artifact: caseOneArtifact, note: '记录了旧缓存复现与初步处理。' }],
        }],
      }, { agent: zhongshu, signal }) as { updatedIds: string[] }
      const id = first.updatedIds[0]
      if (id === undefined) throw new Error('knowledge id was not returned')
      expect(id).toMatch(/^K-[A-F0-9]{10}$/)

      await expect(knowledge.execute({
        operation: 'upsert',
        case_id: 'case-two',
        entries: [{
          key: 'runtime/cache-invalidation',
          kind: 'pitfall',
          topic: '运行时缓存失效',
          scope: '插件运行时配置刷新',
          summary: '配置切换后必须同步失效运行时缓存，并验证下一次读取。',
          details: '在配置提交点统一失效缓存；以新请求读取新配置作为确认，不依赖界面暂态。',
          state: 'confirmed',
          evidence: [{ artifact: caseTwoArtifact, note: '复验确认统一失效策略有效。' }],
        }],
      }, { agent: zhongshu, signal })).resolves.toMatchObject({ updatedIds: [id] })

      const head = await knowledge.execute({ operation: 'head' }, {
        agent: { session: { header: { cwd }, events: [] } },
        signal,
      }) as { content: string; knowledgeIds: string[] }
      expect(head.knowledgeIds).toEqual([id])
      expect(head.content).toContain('case-one, case-two')
      expect(head.content.match(new RegExp(id, 'g'))).toHaveLength(1)

      const details = await knowledge.execute({ operation: 'details', knowledge_ids: [id] }, {
        agent: { session: { header: { cwd }, events: [] } },
        signal,
      }) as { content: string }
      expect(details.content).toContain('在配置提交点统一失效缓存')
      expect(details.content).toContain(caseOneArtifact)
      expect(details.content).toContain(caseTwoArtifact)

      const sources = await knowledge.execute({ operation: 'sources', source_artifacts: [caseOneArtifact] }, {
        agent: { session: { header: { cwd }, events: [] } },
        signal,
      }) as { content: string }
      expect(sources.content).toContain('Observed stale cache.')

      const document = await readFile(join(cwd, '.tang', 'workspace-knowledge.md'), 'utf8')
      expect(document.match(/^### K-/gm)).toHaveLength(1)
      expect(document).toContain('TANG_WORKSPACE_KNOWLEDGE_DATA_START')
    } finally {
      await rm(cwd, { recursive: true, force: true })
    }
  })

  it('allows all offices to read but only Zhongshu to maintain the shared source', async () => {
    const cwd = await mkdtemp(join(tmpdir(), 'tang-knowledge-authority-'))
    try {
      const knowledge = setup()
      const signal = new AbortController().signal
      await expect(knowledge.execute({ operation: 'head' }, {
        agent: { session: { header: { cwd }, events: [] } },
        signal,
      })).resolves.toMatchObject({ operation: 'head' })
      await expect(knowledge.execute({
        operation: 'no_change',
        case_id: 'case-one',
        reason: '本案只应用既有知识，没有形成新的可复用结论。',
      }, {
        agent: { session: { header: { cwd }, events: [] } },
        signal,
      })).rejects.toThrow('only Zhongshu may maintain workspace knowledge')
    } finally {
      await rm(cwd, { recursive: true, force: true })
    }
  })
})

describe('Tang requirement clarification', () => {
  function setup(answer: unknown) {
    const registered: RegisteredTool[] = []
    const ask = vi.fn(async () => answer)
    const followup = vi.fn(async () => 'clarification-message-1')
    const reportFrom = vi.fn(async () => 'clarification-report-1')
    const context = {
      on: vi.fn(),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn(), followup, reportFrom },
      userQuestions: { ask },
    }
    apply(context as never)
    const clarification = registered.find(tool => tool.name === 'tang_request_clarification')
    if (clarification === undefined) throw new Error('tang_request_clarification was not registered')
    const raise = registered.find(tool => tool.name === 'tang_raise_clarification')
    if (raise === undefined) throw new Error('tang_raise_clarification was not registered')
    return { clarification, raise, ask, followup, reportFrom }
  }

  const request = {
    case_id: 'case-clarify',
    zhongshu_id: 'zhongshu-1',
    questions: [{
      id: 'target-platform',
      header: '运行平台',
      question: '首期需要覆盖哪些平台？',
      detail: '平台范围会影响需求量级与验收方式。',
      options: [
        { label: '仅 Windows（推荐）', description: '先覆盖当前开发设备。' },
        { label: 'Windows 与 macOS', description: '同步验证两个桌面平台。' },
      ],
    }],
  }

  it('lets Zhongshu block drafting and report structured questions to its coordinator', async () => {
    const { raise, ask, reportFrom } = setup({ answers: [] })
    const child = {
      id: 'zhongshu-1',
      session: { events: [{ type: 'subagent/descriptor', data: { label: '[中书省] 分析需求' } }] },
    }

    await expect(raise.execute({ case_id: request.case_id, questions: request.questions }, {
      agent: child,
      signal: new AbortController().signal,
    })).resolves.toEqual({
      caseId: 'case-clarify',
      zhongshuId: 'zhongshu-1',
      messageId: 'clarification-report-1',
    })
    expect(reportFrom).toHaveBeenCalledWith(
      child,
      [expect.objectContaining({ type: 'text', text: expect.stringContaining('<tang-clarification-request>') })],
      expect.objectContaining({ delivery: 'next-step' }),
    )
    expect(ask).not.toHaveBeenCalled()
  })

  it('uses the standard question channel and relays answers into the same Zhongshu child', async () => {
    const { clarification, ask, followup } = setup({
      answers: [{
        id: 'tang-clarification:case-clarify:target-platform',
        selected: ['仅 Windows（推荐）'],
      }],
    })
    const parent = { id: 'root-1', session: { events: [] } }

    await expect(clarification.execute(request, {
      agent: parent,
      signal: new AbortController().signal,
    })).resolves.toMatchObject({
      caseId: 'case-clarify',
      zhongshuId: 'zhongshu-1',
      answers: [{ id: 'target-platform', selected: ['仅 Windows（推荐）'] }],
      messageId: 'clarification-message-1',
    })
    expect(ask).toHaveBeenCalledWith(expect.objectContaining({
      agent: parent,
      questions: [expect.objectContaining({
        id: 'tang-clarification:case-clarify:target-platform',
        question: '首期需要覆盖哪些平台？',
      })],
    }))
    expect(followup).toHaveBeenCalledWith(
      parent,
      'zhongshu-1',
      [expect.objectContaining({ type: 'text', text: expect.stringContaining('"id":"target-platform"') })],
      expect.objectContaining({ source: expect.objectContaining({ kind: 'coordinator', form: 'relay' }) }),
    )
  })

  it('rejects a delegated office trying to open the user interaction channel directly', async () => {
    const { clarification, ask, followup } = setup({ answers: [] })

    await expect(clarification.execute(request, {
      agent: { id: 'zhongshu-1', session: { events: [{ type: 'subagent/descriptor', data: { label: '[中书省] 澄清需求' } }] } },
      signal: new AbortController().signal,
    })).rejects.toThrow('only the coordinator may open the user interaction channel')
    expect(ask).not.toHaveBeenCalled()
    expect(followup).not.toHaveBeenCalled()
  })
})

describe('Tang user approval', () => {
  function setup(answer: unknown) {
    const registered: RegisteredTool[] = []
    const ask = vi.fn(async () => answer)
    const context = {
      on: vi.fn(),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
      userQuestions: { ask },
    }
    apply(context as never)
    const approval = registered.find(tool => tool.name === 'tang_request_approval')
    if (approval === undefined) throw new Error('tang_request_approval was not registered')
    return { approval, ask }
  }

  const request = {
    case_id: 'case-42',
    title: '是否批准三省会签方案？',
    proposal_markdown: '# 方案\n\n1. 分阶段实现\n2. 每阶段独立验证',
  }

  it('publishes the complete proposal as a native plan-review request', async () => {
    const { approval, ask } = setup({
      answers: [{ id: 'tang-user-approval', selected: ['批准执行'] }],
    })
    const agent = { id: 'root', session: { events: [] } }
    const signal = new AbortController().signal

    await expect(approval.execute(request, { agent, signal })).resolves.toEqual({
      caseId: 'case-42',
      decision: 'approved',
    })
    expect(ask).toHaveBeenCalledWith(expect.objectContaining({
      agent,
      signal,
      questions: [{
        id: 'tang-user-approval',
        header: '三省会签方案',
        question: '是否批准三省会签方案？',
        detail: request.proposal_markdown,
        options: expect.arrayContaining([expect.objectContaining({ label: '批准执行' })]),
        intent: { kind: 'plan-review', approve: '批准执行' },
      }],
    }))
  })

  it('returns free-text feedback as a remand', async () => {
    const { approval } = setup({
      answers: [{ id: 'tang-user-approval', selected: [], custom: '补充 Windows 回归验证' }],
    })

    await expect(approval.execute(request, {
      agent: { id: 'root', session: { events: [] } },
      signal: new AbortController().signal,
    })).resolves.toEqual({
      caseId: 'case-42',
      decision: 'remanded',
      feedback: '补充 Windows 回归验证',
    })
  })
})

describe('Tang final report', () => {
  function setup(answer: unknown) {
    const registered: RegisteredTool[] = []
    const ask = vi.fn(async () => answer)
    const context = {
      on: vi.fn(),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn((tool: RegisteredTool) => { registered.push(tool) }) },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
      userQuestions: { ask },
    }
    apply(context as never)
    const report = registered.find(tool => tool.name === 'tang_submit_final_report')
    if (report === undefined) throw new Error('tang_submit_final_report was not registered')
    return { report, ask }
  }

  const request = {
    case_id: 'case-closed',
    title: '三省六部交付完成，是否确认结案？',
    report_markdown: '# 最终报告\n\n## 验证\n\n- 18 tests passed',
    verification_options: [{
      label: '启动开发服务器并手动测试',
      description: '启动本案开发服务后，由用户在浏览器中完成交互验证。',
      instruction: '启动本案已有开发服务器并报告访问地址，然后等待用户测试反馈。',
    }],
  }
  const acceptanceEvents = [
    {
      type: 'tool/call',
      data: {
        name: 'tang_progress',
        callId: 'acceptance-1',
        arguments: JSON.stringify({ stage: 'menxia-acceptance', status: 'passed' }),
      },
    },
    {
      type: 'tool/result',
      data: {
        message: {
          source: { callId: 'acceptance-1' },
          content: [{ isError: false, content: [{ type: 'text', text: 'menxia-acceptance: passed' }] }],
        },
      },
    },
  ]

  it('requires passed Menxia acceptance before presenting the closure report', async () => {
    const { report, ask } = setup({ answers: [] })

    await expect(report.execute(request, {
      agent: { session: { events: [] } },
      signal: new AbortController().signal,
    })).rejects.toThrow('requires a successful menxia-acceptance passed milestone')
    expect(ask).not.toHaveBeenCalled()
  })

  it('publishes Markdown and returns the user closure decision', async () => {
    const { report, ask } = setup({
      answers: [{ id: 'tang-final-report', selected: ['确认结案'] }],
    })
    const agent = { session: { events: acceptanceEvents } }
    const signal = new AbortController().signal

    await expect(report.execute(request, { agent, signal })).resolves.toEqual({
      caseId: 'case-closed',
      decision: 'closed',
    })
    expect(ask).toHaveBeenCalledWith(expect.objectContaining({
      questions: [expect.objectContaining({
        id: 'tang-final-report',
        detail: request.report_markdown,
        options: expect.arrayContaining([expect.objectContaining({ label: '确认结案' })]),
      })],
    }))
  })

  it('returns a task-specific pre-closure follow-up with its executable instruction', async () => {
    const { report, ask } = setup({
      answers: [{ id: 'tang-final-report', selected: ['启动开发服务器并手动测试'] }],
    })

    await expect(report.execute(request, {
      agent: { session: { events: acceptanceEvents } },
      signal: new AbortController().signal,
    })).resolves.toEqual({
      caseId: 'case-closed',
      decision: 'followup',
      selectedOption: '启动开发服务器并手动测试',
      instruction: '启动本案已有开发服务器并报告访问地址，然后等待用户测试反馈。',
      nextAction: 'execute_then_resubmit_final_report',
      interactionRule: expect.stringContaining('Do not use a generic/default question tool'),
    })
    expect(ask).toHaveBeenCalledWith(expect.objectContaining({
      questions: [expect.objectContaining({
        options: expect.arrayContaining([expect.objectContaining({ label: '启动开发服务器并手动测试' })]),
      })],
    }))
  })

  it('ignores repeated or built-in closure choices instead of failing the first submission', async () => {
    const { report, ask } = setup({
      answers: [{ id: 'tang-final-report', selected: ['确认结案'] }],
    })

    await expect(report.execute({
      ...request,
      verification_options: [
        ...request.verification_options,
        {
          label: '直接确认结案',
          description: '与内置结案决策重复。',
          instruction: '直接结案。',
        },
        request.verification_options[0],
      ],
    }, {
      agent: { session: { events: acceptanceEvents } },
      signal: new AbortController().signal,
    })).resolves.toEqual({
      caseId: 'case-closed',
      decision: 'closed',
    })

    const options = ask.mock.calls[0]?.[0].questions[0]?.options ?? []
    expect(options.filter((option: { label: string }) => option.label === '启动开发服务器并手动测试')).toHaveLength(1)
    expect(options.some((option: { label: string }) => option.label === '直接确认结案')).toBe(false)
  })
})

describe('Tang coordinator bootstrap', () => {
  it('dispatches the first root requirement to Zhongshu before the model request', async () => {
    let listener: PreStepListener | undefined
    const startContinuable = vi.fn(async () => ({ childId: 'zhongshu-1' }))
    const context = {
      on: vi.fn((name: string, callback: PreStepListener) => {
        if (name === 'agent/pre-step') listener = callback
      }),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn() },
      subagents: {
        listChildren: vi.fn(async () => []),
        startContinuable,
      },
    }
    apply(context as never)
    if (listener === undefined) throw new Error('agent/pre-step listener was not registered')
    const message = {
      id: 'user-1',
      role: 'user',
      source: { kind: 'user' },
      content: [{ type: 'text', text: '开发一个插件' }],
    }
    const signal = new AbortController().signal

    const decision = await listener({
      agent: { session: { header: { id: 'root-1' }, events: [] } },
      signal,
    }, async () => ({ kind: 'enter', messages: [message] })) as {
      kind: string
      messages: Array<{ source: { kind: string }; content: Array<{ type: string; text: string }> }>
    }

    expect(startContinuable).toHaveBeenCalledOnce()
    expect(startContinuable.mock.calls[0]?.[0]).toMatchObject({
      provider: 'spawn',
      label: '[中书省] 分析需求并起草方案',
      request: {
        prompt: [
          { type: 'text', text: expect.stringContaining('TANG_OFFICE:zhongshu') },
          { type: 'text', text: '开发一个插件' },
        ],
      },
    })
    const zhongshuPrompt = startContinuable.mock.calls[0]?.[0].request.prompt[0].text
    expect(zhongshuPrompt).toContain('需求澄清是从接案到提交门下省前持续生效的门禁')
    expect(zhongshuPrompt).toContain('任何时刻都不得调用默认／通用用户提问机制')
    expect(zhongshuPrompt).toContain('提交前必须再做一次阻塞决定检查')
    expect(zhongshuPrompt).toContain('tang_raise_clarification')
    expect(zhongshuPrompt).toContain('tang_request_clarification')
    expect(decision.kind).toBe('enter')
    expect(decision.messages.at(-1)?.source.kind).toBe('plugin')
    expect(decision.messages.at(-1)?.content[0]?.text).toContain('运行时已将本次原始需求强制派发给中书省')
  })

  it('initializes and injects only the workspace knowledge head into a new case', async () => {
    const cwd = await mkdtemp(join(tmpdir(), 'tang-knowledge-bootstrap-'))
    try {
      let listener: PreStepListener | undefined
      const startContinuable = vi.fn(async () => ({ childId: 'zhongshu-knowledge' }))
      const context = {
        on: vi.fn((name: string, callback: PreStepListener) => {
          if (name === 'agent/pre-step') listener = callback
        }),
        inject: vi.fn(),
        systemPrompt: { section: vi.fn() },
        tools: { register: vi.fn() },
        subagents: { listChildren: vi.fn(async () => []), startContinuable },
      }
      apply(context as never)
      if (listener === undefined) throw new Error('agent/pre-step listener was not registered')

      await listener({
        agent: { session: { header: { id: 'root-knowledge', cwd }, events: [] } },
        signal: new AbortController().signal,
      }, async () => ({
        kind: 'enter',
        messages: [{
          id: 'knowledge-request',
          role: 'user',
          source: { kind: 'user' },
          content: [{ type: 'text', text: '修复缓存刷新问题' }],
        }],
      }))

      const prompt = startContinuable.mock.calls[0]?.[0].request.prompt[0].text as string
      expect(prompt).toContain('<tang-workspace-knowledge-head path=".tang/workspace-knowledge.md">')
      expect(prompt).toContain('## 知识索引')
      expect(prompt).toContain('暂无可复用知识')
      expect(prompt).not.toContain('## 知识详情')
      const document = await readFile(join(cwd, '.tang', 'workspace-knowledge.md'), 'utf8')
      expect(document).toContain('## 知识详情')
    } finally {
      await rm(cwd, { recursive: true, force: true })
    }
  })

  it('uses soft intake guidance without reducing an explicit model output budget', async () => {
    let listener: PreStepListener | undefined
    const startContinuable = vi.fn(async () => ({ childId: 'zhongshu-small' }))
    const context = {
      on: vi.fn((name: string, callback: PreStepListener) => {
        if (name === 'agent/pre-step') listener = callback
      }),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn() },
      subagents: { listChildren: vi.fn(async () => []), startContinuable },
    }
    apply(context as never, {
      offices: { zhongshu: { provider: 'stable-provider', model: 'stable-model', maxTokens: 40_000 } },
    })
    if (listener === undefined) throw new Error('agent/pre-step listener was not registered')

    await listener({
      agent: { session: { header: { id: 'root-small' }, events: [] } },
      signal: new AbortController().signal,
    }, async () => ({
      kind: 'enter',
      messages: [{
        id: 'small-request',
        role: 'user',
        source: { kind: 'user' },
        content: [{ type: 'text', text: '把按钮颜色调深一点' }],
      }],
    }))

    const request = startContinuable.mock.calls[0]?.[0].request
    expect(request.agentOptions).toEqual({
      provider: 'stable-provider',
      model: 'stable-model',
      maxTokens: 40_000,
    })
    expect(request.prompt[0].text).toContain('TANG_CASE_SCALE:small')
    expect(request.prompt[0].text).toContain('soft_output_target: 4000')
    expect(request.prompt[0].text).not.toContain('safety_output_cap')
    expect(request.prompt[0].text).toContain('不得选择六部、安排跨部门工作')
  })

  it('does not bootstrap a delegated office or a later root turn', async () => {
    const listeners: PreStepListener[] = []
    const startContinuable = vi.fn()
    const context = {
      on: vi.fn((name: string, callback: PreStepListener) => {
        if (name === 'agent/pre-step') listeners.push(callback)
      }),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn() },
      subagents: { listChildren: vi.fn(async () => []), startContinuable },
    }
    apply(context as never)
    const listener = listeners[0]
    if (listener === undefined) throw new Error('agent/pre-step listener was not registered')
    const input = {
      kind: 'enter',
      messages: [{ id: 'u', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'x' }] }],
    }
    const signal = new AbortController().signal

    await listener({
      agent: { session: { header: { id: 'child' }, events: [{ type: 'subagent/descriptor', data: { label: '[门下省] review' } }] } },
      signal,
    }, async () => input)
    await listener({
      agent: { session: { header: { id: 'root' }, events: [{ type: 'user/message', data: { source: { kind: 'user' } } }] } },
      signal,
    }, async () => input)

    expect(startContinuable).not.toHaveBeenCalled()
  })
})

describe('Tang Department model routing', () => {
  it('applies a Department model and reasoning selection to the next model request', async () => {
    let listener: RequestListener | undefined
    const context = {
      on: vi.fn((name: string, callback: RequestListener) => {
        if (name === 'agent/request') listener = callback
      }),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn() },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }
    apply(context as never, {
      offices: {
        menxia: {
          provider: 'review-provider',
          model: 'review-model',
          reasoningEffort: 'high',
          maxTokens: 12000,
        },
      },
    })
    if (listener === undefined) throw new Error('agent/request listener was not registered')

    const routed = await listener({
      agent: { session: { events: [{ type: 'subagent/descriptor', data: { label: '[门下省] 独立审查' } }] } },
    }, async () => ({ provider: 'parent', model: 'parent-model', reasoningEffort: 'low', maxTokens: 4000 }))

    expect(routed).toEqual({
      provider: 'review-provider',
      model: 'review-model',
      reasoningEffort: 'high',
      maxTokens: 12000,
    })
  })

  it('preserves the configured review output budget for a small case', async () => {
    let listener: RequestListener | undefined
    const context = {
      on: vi.fn((name: string, callback: RequestListener) => {
        if (name === 'agent/request') listener = callback
      }),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn() },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }
    apply(context as never, {
      offices: {
        menxia: {
          provider: 'stable-review-provider',
          model: 'stable-review-model',
          reasoningEffort: 'high',
          maxTokens: 40_000,
        },
      },
    })
    if (listener === undefined) throw new Error('agent/request listener was not registered')

    const routed = await listener({
      agent: {
        session: {
          events: [
            { type: 'subagent/descriptor', data: { label: '[门下省] 轻量审议' } },
            { type: 'user/message', data: { content: [{ type: 'text', text: 'TANG_OFFICE:menxia\nTANG_CASE_SCALE:small\nReview.' }] } },
          ],
        },
      },
    }, async () => ({ provider: 'parent', model: 'parent-model', maxTokens: 64_000 }))

    expect(routed).toEqual({
      provider: 'stable-review-provider',
      model: 'stable-review-model',
      reasoningEffort: 'high',
      maxTokens: 40_000,
    })
  })

  it('preserves the root coordinator route when no office descriptor exists', async () => {
    let listener: RequestListener | undefined
    const context = {
      on: vi.fn((name: string, callback: RequestListener) => {
        if (name === 'agent/request') listener = callback
      }),
      inject: vi.fn(),
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn() },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }
    apply(context as never, { offices: { zhongshu: { provider: 'draft', model: 'draft-model' } } })
    if (listener === undefined) throw new Error('agent/request listener was not registered')
    const inherited = { provider: 'root', model: 'root-model', reasoningEffort: 'low' }

    await expect(listener({ agent: { session: { events: [] } } }, async () => inherited)).resolves.toEqual(inherited)
  })

  it('makes a Ministry inherit Shangshu model and maps unsupported reasoning to the model default', async () => {
    let listener: RequestListener | undefined
    const resolveModelInfo = vi.fn(async () => ({
      provider: 'delivery-provider',
      id: 'delivery-model',
      name: 'Delivery model',
      reasoning: {
        efforts: [
          { id: 'off', name: 'Off' },
          { id: 'low', name: 'Low' },
          { id: 'high', name: 'High' },
          { id: 'max', name: 'Max' },
        ],
        defaultEffort: 'high',
      },
    }))
    const context = {
      on: vi.fn((name: string, callback: RequestListener) => {
        if (name === 'agent/request') listener = callback
      }),
      inject: vi.fn(),
      llm: { resolveModelInfo },
      systemPrompt: { section: vi.fn() },
      tools: { register: vi.fn() },
      subagents: { listChildren: vi.fn(async () => []), startContinuable: vi.fn() },
    }
    apply(context as never, {
      offices: {
        shangshu: { provider: 'delivery-provider', model: 'delivery-model', reasoningEffort: 'max' },
        war: { provider: 'ignored-provider', model: 'ignored-model', reasoningEffort: 'high' },
      },
    })
    if (listener === undefined) throw new Error('agent/request listener was not registered')

    const routed = await listener({
      agent: {
        session: {
          events: [
            { type: 'subagent/descriptor', data: { label: '[兵部] 实现功能' } },
            {
              type: 'user/message',
              data: { content: [{ type: 'text', text: 'TANG_OFFICE:war\nTANG_REASONING_EFFORT:medium\nImplement.' }] },
            },
          ],
        },
      },
    }, async () => ({ provider: 'parent', model: 'parent-model', reasoningEffort: 'max' }))

    expect(routed).toEqual({
      provider: 'delivery-provider',
      model: 'delivery-model',
      reasoningEffort: 'high',
    })
    expect(resolveModelInfo).toHaveBeenCalledWith('delivery-provider', 'delivery-model')
  })
})
