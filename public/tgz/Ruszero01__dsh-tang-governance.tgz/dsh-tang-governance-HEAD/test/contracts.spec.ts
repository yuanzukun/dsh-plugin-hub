import { describe, expect, it } from 'vitest'
import { parseTangProgress } from '../src/contracts.ts'

describe('parseTangProgress', () => {
  it('accepts the durable tool argument vocabulary', () => {
    expect(parseTangProgress({
      case_id: 'case-1',
      stage: 'user-approval',
      office: 'menxia',
      status: 'waiting_approval',
      title: '待用户审批',
      artifact_path: '.tang/cases/case-1/04-spec.md',
    })).toEqual({
      caseId: 'case-1',
      stage: 'user-approval',
      office: 'menxia',
      status: 'waiting_approval',
      title: '待用户审批',
      artifactPath: '.tang/cases/case-1/04-spec.md',
    })
  })

  it('rejects unknown status and empty case ids', () => {
    expect(parseTangProgress({ case_id: '', stage: 'intake', office: 'zhongshu', status: 'running', title: 'x' })).toBeNull()
    expect(parseTangProgress({ case_id: 'x', stage: 'intake', office: 'zhongshu', status: 'done', title: 'x' })).toBeNull()
  })

  it('accepts the durable user-closure wait stage', () => {
    expect(parseTangProgress({
      case_id: 'case-1', stage: 'case-closure', office: 'zhongshu', status: 'waiting_approval', title: '等待用户结案',
    })).toMatchObject({ stage: 'case-closure', office: 'zhongshu', status: 'waiting_approval' })
  })
})
