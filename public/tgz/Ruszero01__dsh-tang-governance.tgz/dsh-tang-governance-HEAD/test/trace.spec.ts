import { describe, expect, it } from 'vitest'
import {
  buildDepartmentTrace, groupTimelineByDepartment, orderDepartmentTraces, projectTraceTimeline,
  projectMinistryDialogRecords, shangshuExecutionSegments, traceTokenTotal,
  type TangDialogRecord,
} from '../src/client/trace.ts'

describe('ministry detail records', () => {
  const invocation = (sessionId: string, time: number) => buildDepartmentTrace({
    sessionId, office: 'rites', label: '[礼部] 设置UI与i18n', depth: 1,
    activity: 'inactive',
    events: [{ type: 'turn/end', seq: 1, time, data: { reason: { kind: 'completed' } } }],
  })

  it('shows executed child work without coordinator progress or tang_progress', () => {
    expect(projectMinistryDialogRecords('rites', [invocation('r1', 200)], []))
      .toMatchObject([{ key: 'child:r1:invocation', title: '设置UI与i18n', time: 200,
        stage: 'ministry-execution', status: 'succeeded' }])
    expect(projectMinistryDialogRecords('war', [invocation('r1', 200)], [])).toEqual([])
  })

  it('retains repeated invocations of the same stage and title in execution-time order', () => {
    const rows = projectMinistryDialogRecords('rites', [invocation('r2', 300), invocation('r1', 200)], [])
    expect(rows.map(row => row.key)).toEqual(['child:r1:invocation', 'child:r2:invocation'])
  })

  it('merges coordinator-only history and deduplicates only exact mirrored child events', () => {
    const [child] = projectMinistryDialogRecords('rites', [invocation('r1', 200)], [])
    const mirror = { ...child!, key: 'event:mirror' }
    const older: TangDialogRecord = { ...mirror, key: 'event:older', time: 100, title: '前期契约检查' }
    expect(projectMinistryDialogRecords('rites', [], [older])).toEqual([older])
    expect(projectMinistryDialogRecords('rites', [invocation('r1', 200)], [mirror, older]))
      .toEqual([older, child])
  })

  it('uses child milestones when present rather than duplicating the invocation', () => {
    const trace = { ...invocation('r1', 300), phases: [
      { stage: 'ministry-execution' as const, title: '检查契约', status: 'succeeded' as const, updatedAt: 100 },
      { stage: 'ministry-execution' as const, title: '更新界面', status: 'succeeded' as const, updatedAt: 200 },
    ] }
    expect(projectMinistryDialogRecords('rites', [trace], []).map(row => row.title))
      .toEqual(['检查契约', '更新界面'])
  })

  it('does not complete parallel work merely because another invocation has a later record', () => {
    const running = { ...invocation('r1', 100), status: 'running' as const }
    expect(projectMinistryDialogRecords('rites', [running, invocation('r2', 200)], [])
      .map(row => row.status)).toEqual(['running', 'succeeded'])
    const pending = buildDepartmentTrace({ sessionId: 'r3', office: 'rites', depth: 1,
      activity: 'inactive', events: [] })
    expect(projectMinistryDialogRecords('rites', [pending], [])[0])
      .toMatchObject({ time: 0, status: 'pending' })
  })
})

describe('Tang department-call trace', () => {
  it('projects the latest real milestone and whole-session token usage', () => {
    const trace = buildDepartmentTrace({
      sessionId: 'child-1',
      office: 'zhongshu',
      label: '[中书省] 分析需求并起草方案',
      depth: 0,
      activity: 'inactive',
      events: [
        {
          type: 'tool/call',
          seq: 4,
          time: 1_000,
          data: {
            name: 'tang_progress',
            arguments: JSON.stringify({
              case_id: 'case-1',
              stage: 'zhongshu-draft',
              office: 'zhongshu',
              status: 'passed',
              title: '需求与初版方案已完成',
              summary: '已生成需求文档和技术选型草案。',
            }),
          },
        },
        { type: 'turn/end', seq: 5, time: 1_200, data: { reason: { kind: 'completed' } } },
      ],
      tokenUsage: {
        uncachedInputTokens: 1_200,
        cacheReadTokens: 700,
        cacheWriteTokens: 100,
        outputTokens: 450,
      },
    })

    expect(trace).toMatchObject({
      officeName: '中书省',
      invocationTitle: '分析需求并起草方案',
      title: '需求与初版方案已完成',
      summary: '已生成需求文档和技术选型草案。',
      stage: 'zhongshu-draft',
      status: 'passed',
      startedAt: 1_000,
      updatedAt: 1_200,
    })
    expect(traceTokenTotal(trace.usage)).toBe(2_450)
    expect(trace.phases).toEqual([{
      stage: 'zhongshu-draft',
      title: '需求与初版方案已完成',
      summary: '已生成需求文档和技术选型草案。',
      status: 'passed',
      updatedAt: 1_000,
    }])
  })

  it('uses catalog activity and description when the child has not recorded a milestone', () => {
    const trace = buildDepartmentTrace({
      sessionId: 'child-2',
      office: 'war',
      label: '[兵部] 实现组织架构图',
      depth: 1,
      activity: 'running',
      events: [],
      tokenUsage: { uncachedInputTokens: -1, outputTokens: 'unknown' },
    })

    expect(trace).toMatchObject({
      officeName: '兵部',
      depth: 1,
      title: '实现组织架构图',
      status: 'running',
      usage: {
        uncachedInputTokens: 0,
        cacheReadTokens: 0,
        cacheWriteTokens: 0,
        outputTokens: 0,
      },
    })
  })

  it('reports an aborted inactive invocation as stopped', () => {
    const trace = buildDepartmentTrace({
      sessionId: 'child-3',
      office: 'justice',
      depth: 1,
      activity: 'inactive',
      events: [{
        type: 'turn/end',
        seq: 9,
        time: 3_000,
        data: { reason: { kind: 'aborted', reason: { kind: 'user' } } },
      }],
    })

    expect(trace.status).toBe('stopped')
  })

  it('keeps a durable wait above catalog activity and replaces it when the same stage completes', () => {
    const event = (seq: number, status: 'waiting_input' | 'succeeded', title: string) => ({
      type: 'tool/call',
      seq,
      time: seq * 1_000,
      data: {
        name: 'tang_progress',
        arguments: JSON.stringify({
          case_id: 'case-wait', stage: 'requirement-clarification', office: 'zhongshu', status, title,
        }),
      },
    })
    const waiting = buildDepartmentTrace({
      sessionId: 'zhongshu-wait', office: 'zhongshu', depth: 0, activity: 'running',
      events: [event(1, 'waiting_input', '等待用户补充')],
    })
    expect(waiting.status).toBe('waiting_input')

    const completed = buildDepartmentTrace({
      sessionId: 'zhongshu-done', office: 'zhongshu', depth: 0, activity: 'inactive',
      events: [event(1, 'waiting_input', '等待用户补充'), event(2, 'succeeded', '需求澄清完成')],
    })
    expect(completed.phases).toHaveLength(1)
    expect(completed.phases[0]).toMatchObject({ status: 'succeeded', title: '需求澄清完成' })
  })

  it('keeps Zhongshu running and exposes drafting immediately after clarification succeeds', () => {
    const trace = buildDepartmentTrace({
      sessionId: 'zhongshu-drafting',
      office: 'zhongshu',
      depth: 0,
      activity: 'running',
      events: [{
        type: 'tool/call',
        seq: 1,
        time: 1_000,
        data: {
          name: 'tang_progress',
          arguments: JSON.stringify({
            case_id: 'case-drafting',
            stage: 'requirement-clarification',
            office: 'zhongshu',
            status: 'succeeded',
            title: '需求澄清完成',
          }),
        },
      }],
    })

    expect(trace.status).toBe('running')
    expect(trace.stage).toBe('zhongshu-draft')
    expect(trace.title).toBe('正在起草需求与方案')
    expect(trace.phases).toMatchObject([
      { stage: 'requirement-clarification', status: 'succeeded' },
      { stage: 'zhongshu-draft', status: 'running' },
    ])
  })

  it('prefers live catalog activity over an earlier successful ministry milestone', () => {
    const trace = buildDepartmentTrace({
      sessionId: 'war-still-running',
      office: 'war',
      depth: 1,
      activity: 'running',
      events: [{
        type: 'tool/call',
        seq: 1,
        time: 1_000,
        data: {
          name: 'tang_progress',
          arguments: JSON.stringify({
            case_id: 'case-war',
            stage: 'ministry-execution',
            office: 'war',
            status: 'succeeded',
            title: 'P1 已完成，继续执行 P2',
          }),
        },
      }],
    })

    expect(trace.status).toBe('running')
    expect(trace.phases[0]).toMatchObject({ status: 'succeeded' })
  })

  it('does not leave a superseded earlier stage displayed as running', () => {
    const progress = (seq: number, stage: 'zhongshu-draft' | 'countersign', status: 'running' | 'waiting_approval') => ({
      type: 'tool/call', seq, time: seq * 1_000,
      data: {
        name: 'tang_progress',
        arguments: JSON.stringify({ case_id: 'case-next', stage, office: 'zhongshu', status, title: stage }),
      },
    })
    const trace = buildDepartmentTrace({
      sessionId: 'zhongshu-next', office: 'zhongshu', depth: 0, activity: 'inactive',
      events: [progress(1, 'zhongshu-draft', 'running'), progress(2, 'countersign', 'waiting_approval')],
    })
    expect(trace.phases.map(phase => phase.status)).toEqual(['succeeded', 'waiting_approval'])
  })

  it('keeps repeated department calls on one forward-only chronological rail', () => {
    const invocation = (sessionId: string, office: 'zhongshu' | 'war', time: number) => buildDepartmentTrace({
      sessionId,
      office,
      depth: office === 'war' ? 2 : 0,
      activity: 'inactive',
      events: [{ type: 'turn/end', seq: 1, time, data: { reason: { kind: 'completed' } } }],
    })

    const ordered = orderDepartmentTraces([
      invocation('zhongshu-first', 'zhongshu', 1_000),
      invocation('zhongshu-follow-up', 'zhongshu', 4_000),
      invocation('war-build', 'war', 2_000),
      invocation('war-recheck', 'war', 3_000),
    ])

    expect(ordered.map(trace => trace.sessionId)).toEqual([
      'zhongshu-first',
      'war-build',
      'war-recheck',
      'zhongshu-follow-up',
    ])
    expect(ordered.map(trace => trace.depth)).toEqual([0, 2, 2, 0])
  })

  it('moves a reused Zhongshu reporting period behind departments called in between', () => {
    const base = (sessionId: string, office: 'zhongshu' | 'war', startedAt: number) => ({
      sessionId,
      office,
      officeName: office === 'zhongshu' ? '中书省' : '兵部',
      depth: office === 'zhongshu' ? 0 : 1,
      title: office,
      status: 'succeeded' as const,
      startedAt,
      updatedAt: startedAt,
      usage: { uncachedInputTokens: 10, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 },
    })
    const traces = [{
      ...base('zhongshu-reused', 'zhongshu', 1_000),
      phases: [
        { stage: 'zhongshu-draft', title: '立案', status: 'succeeded', updatedAt: 2_000 },
        { stage: 'zhongshu-report', title: '奏报', status: 'succeeded', updatedAt: 9_000 },
        { stage: 'case-closure', title: '结案', status: 'passed', updatedAt: 10_000 },
      ],
    }, {
      ...base('war-run', 'war', 5_000),
      phases: [{ stage: 'ministry-execution', title: '实现', status: 'succeeded', updatedAt: 7_000 }],
    }]
    const sequenced = projectTraceTimeline(traces)

    expect(sequenced.map(segment => [segment.trace.office, segment.continuation])).toEqual([
      ['zhongshu', false], ['war', false], ['zhongshu', true],
    ])
    expect(sequenced[0]?.phases.map(phase => phase.title)).toEqual(['立案'])
    expect(sequenced[2]?.phases.map(phase => phase.title)).toEqual(['奏报', '结案'])
    expect(sequenced[0]?.trace.sessionId).toBe('zhongshu-reused')
    expect(sequenced[2]?.trace.sessionId).toBe('zhongshu-reused')
    expect(traces.reduce((total, trace) => total + traceTokenTotal(trace.usage), 0)).toBe(20)
  })

  it('orders every visible segment by its printed execution time across offices', () => {
    const usage = { uncachedInputTokens: 100, outputTokens: 20, cacheReadTokens: 0, cacheWriteTokens: 0 }
    const zhongshu = {
      sessionId: 'zhongshu-long-lived', office: 'zhongshu' as const, officeName: '中书省', depth: 0,
      title: '中书省结案', status: 'succeeded' as const, startedAt: 14_530, updatedAt: 15_461,
      usage,
      phases: [
        { stage: 'requirement-clarification' as const, title: '需求澄清', status: 'succeeded' as const, updatedAt: 14_533 },
        { stage: 'zhongshu-draft' as const, title: '中书起草', status: 'succeeded' as const, updatedAt: 14_562 },
        { stage: 'countersign' as const, title: '两省会签', status: 'passed' as const, updatedAt: 14_590 },
        { stage: 'user-approval' as const, title: '用户审批', status: 'passed' as const, updatedAt: 14_593 },
        { stage: 'zhongshu-report' as const, title: '中书奏报', status: 'succeeded' as const, updatedAt: 15_452 },
        { stage: 'case-closure' as const, title: '用户结案', status: 'passed' as const, updatedAt: 15_461 },
      ],
    }
    const menxia = {
      sessionId: 'menxia-review', office: 'menxia' as const, officeName: '门下省', depth: 0,
      title: '门下复核', status: 'passed' as const, startedAt: 14_580, updatedAt: 14_582,
      usage,
      phases: [{ stage: 'menxia-review' as const, title: '门下复核', status: 'passed' as const, updatedAt: 14_582 }],
    }

    const timeline = projectTraceTimeline([zhongshu, menxia])

    expect(timeline.map(segment => ({
      office: segment.trace.office,
      times: segment.phases.map(phase => phase.updatedAt),
      continuation: segment.continuation,
    }))).toEqual([
      { office: 'zhongshu', times: [14_533, 14_562], continuation: false },
      { office: 'menxia', times: [14_582], continuation: false },
      { office: 'zhongshu', times: [14_590, 14_593, 15_452, 15_461], continuation: true },
    ])
    expect(new Set(timeline.map(segment => segment.trace.sessionId))).toEqual(
      new Set(['zhongshu-long-lived', 'menxia-review']),
    )
  })

  it('keeps an invocation without history sortable without exposing an invalid display time', () => {
    const trace = buildDepartmentTrace({
      sessionId: 'history-pending', office: 'revenue', depth: 1, activity: 'running', events: [],
    })

    const [segment] = projectTraceTimeline([trace])

    expect(segment).toMatchObject({ startedAt: 0, updatedAt: 0, continuation: false })
    expect(Number.isFinite(segment?.startedAt)).toBe(true)
    expect(Number.isFinite(segment?.updatedAt)).toBe(true)
  })

  it('keeps ministries under Shangshu and includes every ministry phase in its execution block', () => {
    const usage = { uncachedInputTokens: 1, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }
    const timeline = projectTraceTimeline([{
      sessionId: 'shangshu-supervisor', office: 'shangshu', officeName: '尚书省', depth: 0,
      title: '执行计划完成', status: 'succeeded', startedAt: 10_000, updatedAt: 40_000, usage,
      phases: [
        { stage: 'shangshu-dispatch', title: '尚书接旨', status: 'succeeded', updatedAt: 12_000 },
        { stage: 'ministry-execution', title: '六部执行完成', status: 'succeeded', updatedAt: 40_000 },
      ],
    }, {
      sessionId: 'war-child', office: 'war', officeName: '兵部', depth: 1,
      title: '实现', status: 'succeeded', startedAt: 20_000, updatedAt: 25_000, usage,
      phases: [{ stage: 'ministry-execution', title: '兵部实现', status: 'succeeded', updatedAt: 25_000 }],
    }, {
      sessionId: 'works-child', office: 'works', officeName: '工部', depth: 1,
      title: '构建', status: 'succeeded', startedAt: 30_000, updatedAt: 35_000, usage,
      phases: [
        { stage: 'ministry-execution', title: '工部构建', status: 'running', updatedAt: 34_000 },
        { stage: 'ministry-execution', title: '工部构建完成', status: 'succeeded', updatedAt: 35_000 },
      ],
    }, {
      sessionId: 'menxia-acceptance', office: 'menxia', officeName: '门下省', depth: 0,
      title: '最终验收', status: 'passed', startedAt: 50_000, updatedAt: 55_000, usage,
      phases: [{ stage: 'menxia-acceptance', title: '最终验收', status: 'passed', updatedAt: 55_000 }],
    }])

    expect(timeline.map(segment => segment.trace.office)).toEqual(['shangshu', 'war', 'works', 'menxia'])
    expect(timeline.filter(segment => segment.trace.office === 'shangshu')).toHaveLength(1)
    expect(timeline[0]?.phases.map(phase => phase.title)).toEqual(['尚书接旨', '六部执行完成'])
    const ministries = shangshuExecutionSegments(timeline, 0)
    expect(ministries.map(segment => segment.trace.office)).toEqual(['war', 'works'])
    const stageCount = timeline[0]!.phases.length + ministries.reduce(
      (total, segment) => total + Math.max(1, segment.phases.length), 0,
    )
    expect(stageCount).toBe(5)
  })

  it('collapses the rail into three Department cards with chronological internal records', () => {
    const usage = { uncachedInputTokens: 1, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }
    const trace = (sessionId: string, office: 'zhongshu' | 'menxia' | 'shangshu' | 'war', time: number) => ({
      sessionId, office, officeName: office, depth: office === 'war' ? 1 : 0,
      title: sessionId, status: 'succeeded' as const, startedAt: time, updatedAt: time, usage,
      phases: [{
        stage: office === 'war' ? 'ministry-execution' as const : office === 'zhongshu'
          ? 'zhongshu-draft' as const : office === 'menxia' ? 'menxia-review' as const : 'shangshu-dispatch' as const,
        title: sessionId, status: 'succeeded' as const, updatedAt: time,
      }],
    })
    const chronological = projectTraceTimeline([
      trace('menxia-late', 'menxia', 50),
      trace('zhongshu-late', 'zhongshu', 40),
      trace('shangshu', 'shangshu', 20),
      trace('war', 'war', 30),
      trace('zhongshu-early', 'zhongshu', 10),
    ])

    const grouped = groupTimelineByDepartment(chronological)

    expect(grouped.map(segment => segment.trace.sessionId)).toEqual([
      'department:zhongshu', 'department:menxia', 'department:shangshu', 'war',
    ])
    expect(grouped[0]?.phases.map(phase => phase.title)).toEqual(['zhongshu-early', 'zhongshu-late'])
    expect(shangshuExecutionSegments(grouped, 2).map(segment => segment.trace.sessionId)).toEqual(['war'])
  })
})
