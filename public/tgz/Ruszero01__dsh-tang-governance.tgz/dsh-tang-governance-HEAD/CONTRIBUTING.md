# Contributing to Tang Governance

Thanks for your interest in contributing! Tang Governance is an open-source
plugin for DeepSeek Harness, and every contribution — code, docs, tests,
reports — is welcome.

Please note that all interactions in this project are governed by our
[Code of Conduct](CODE_OF_CONDUCT.md).

## Development setup

Prerequisites:

- Node.js `^22.19.0 || >=24.0.0`
- [pnpm](https://pnpm.io/) 10

```sh
pnpm install
pnpm run typecheck   # TypeScript type check
pnpm run test        # vitest specs
pnpm run build       # esbuild + tsc bundle into lib/
pnpm run check       # typecheck + test + build (what CI runs)
```

`pnpm run dev` watches `src/` and rebuilds on change.

## Project layout

| Path                | Purpose                                   |
| ------------------- | ----------------------------------------- |
| `src/index.ts`      | Plugin entry point                        |
| `src/tool.ts`       | Model routing tool definition             |
| `src/invariant.ts`  | Runtime-enforced guarantees               |
| `src/contracts.ts`  | Shared types and contracts                |
| `src/client/`       | Conversation UI (React)                   |
| `test/`             | Vitest specs                              |
| `build.mjs`         | esbuild + tsc build script                |
| `cordis.patch.yml`  | DeepSeek Harness patch config             |

## Commit style

We follow [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` — new capability
- `fix:` — bug fix
- `docs:` — documentation only
- `refactor:` — behavior-preserving change
- `test:` — test-only change
- `chore:` — maintenance

Commit bodies may be written in English or Chinese (both are used in this
repository's history).

## Pull requests

1. Fork the repository and create a branch from `main`.
2. Keep each PR small and focused on one concern.
3. Add or update tests for the code you change.
4. Run `pnpm run check` before pushing — CI runs the same command.
5. Reference the issue your PR addresses (e.g. `Closes #12`).

## Reporting issues

- **Bugs** — use the bug report template and include your package version,
  environment, and any relevant logs or case dossier files.
- **Security vulnerabilities** — do **not** open a public issue. Follow
  [SECURITY.md](SECURITY.md) instead.
