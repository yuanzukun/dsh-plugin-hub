import { rm } from 'node:fs/promises'
import { build } from 'esbuild'
import ts from 'typescript'

await rm('lib', { recursive: true, force: true })

await build({
  entryPoints: ['src/index.ts', 'src/tool.ts', 'src/invariant.ts'],
  outdir: 'lib',
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'node22',
  packages: 'external',
  sourcemap: true,
})

await build({
  entryPoints: { client: 'src/client/index.tsx' },
  outdir: 'lib',
  entryNames: '[name]',
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: ['chrome120', 'safari17'],
  jsx: 'automatic',
  external: [
    'react',
    'react/jsx-runtime',
    'react-dom',
    'react-dom/client',
    '@deepseek-ai/cordis',
    '@deepseek-ai/dsh-client-runtime/client',
    '@deepseek-ai/dsh-client-ui-conversation/client',
    '@deepseek-ai/dsh-client-ui-primitives',
  ],
  banner: {
    js: 'window.__ModuleLoader__.load({ id: "dsh-tang-governance", factory: (require) => { var module = { exports: {} }; var exports = module.exports;',
  },
  footer: { js: 'return module.exports; } });' },
  sourcemap: true,
})

const configPath = ts.findConfigFile('.', ts.sys.fileExists, 'tsconfig.json')
if (configPath === undefined) throw new Error('tsconfig.json not found')
const configFile = ts.readConfigFile(configPath, ts.sys.readFile)
if (configFile.error !== undefined) throw new Error(ts.flattenDiagnosticMessageText(configFile.error.messageText, '\n'))
const parsed = ts.parseJsonConfigFileContent(configFile.config, ts.sys, '.')
const program = ts.createProgram(parsed.fileNames.filter(file => !file.includes('/test/')), parsed.options)
const result = program.emit()
const diagnostics = ts.getPreEmitDiagnostics(program).concat(result.diagnostics)
if (diagnostics.length > 0) {
  throw new Error(ts.formatDiagnosticsWithColorAndContext(diagnostics, {
    getCanonicalFileName: file => file,
    getCurrentDirectory: () => process.cwd(),
    getNewLine: () => '\n',
  }))
}
