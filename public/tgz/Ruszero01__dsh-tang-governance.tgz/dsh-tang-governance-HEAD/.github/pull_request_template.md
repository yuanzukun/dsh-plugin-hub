## Summary

<!-- What does this PR do, and why? Keep it concise. -->

## Changes

<!-- List the concrete changes: files, behavior, config, docs. -->

## Validation

<!-- What did you run to verify this change? CI runs the same `pnpm run check`. -->

- [ ] `pnpm run typecheck`
- [ ] `pnpm run test`
- [ ] `pnpm run build`

## Checklist

- [ ] I have read [CONTRIBUTING.md](../CONTRIBUTING.md)
- [ ] My changes are focused and do not include unrelated edits
- [ ] I have added or updated tests where applicable
