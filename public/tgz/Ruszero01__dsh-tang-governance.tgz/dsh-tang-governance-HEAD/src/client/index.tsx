/** Browser organization chart and task timeline for Tang-mode sessions. */
import {
  Fragment, useEffect, useId, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore,
} from 'react'
import { createPortal } from 'react-dom'
import type {
  ClientContext, ConversationNodeContext, ConversationNodeDefinition,
  ConversationViewBuilder, ConversationViewDefinition, ConversationViewNode,
  ISessions, PendingInteraction, SessionId, SessionListState, SettingsScope, SubagentAddress,
  SubagentCatalogSnapshot,
} from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { MarkdownText } from '@deepseek-ai/dsh-client-ui-primitives'
import {
  parseTangProgress, TANG_APPROVAL_QUESTION_ID, TANG_APPROVE_LABEL, TANG_CLARIFICATION_QUESTION_PREFIX, TANG_CLOSE_LABEL,
  TANG_CLOSURE_QUESTION_ID, TANG_DEPARTMENTS, TANG_OFFICE_DEFINITIONS, TANG_SETTINGS_NAMESPACE,
  TANG_REMAND_LABEL,
  type TangDepartment, type TangDepartmentRoutes, type TangOffice, type TangOfficeRoute,
  type TangProgressRecord, type TangStage, type TangStatus,
} from '../contracts.ts'
import {
  buildDepartmentTrace, groupTimelineByDepartment, orderDepartmentTraces, projectTraceTimeline,
  projectMinistryDialogRecords, shangshuExecutionSegments, traceTokenTotal,
  type TangDepartmentTrace, type TangDialogRecord, type TangTraceEvent,
} from './trace.ts'
import {
  BAOXIANG_ORNAMENT_SOURCE,
  CLOUD_ORNAMENT_SOURCE,
  TAOTIE_ORNAMENT_SOURCE,
} from './ornaments.ts'

declare module '@deepseek-ai/dsh-client-runtime/client' {
  interface ConversationViewSnapshotMap {
    /** Tang workflow transitions reconstructed from standard tool calls. */
    'tang-governance': TangTimelineSnapshot
  }
}

interface TangTimelineEntry extends TangProgressRecord {
  readonly key: string
  readonly seq: number
  readonly time: number
  readonly settled: 'running' | 'success' | 'failed'
}

interface TangTimelineNode extends ConversationViewNode {
  readonly target: 'tang-governance'
  readonly anchorSeq: number
  readonly data: TangTimelineEntry
}

interface TangReviewOption {
  readonly label: string
  readonly description?: string
  readonly instruction?: string
}

interface TangReviewRecord {
  readonly key: string
  readonly kind: 'approval' | 'closure'
  readonly caseId: string
  readonly title: string
  readonly detail: string
  readonly options: readonly TangReviewOption[]
  readonly status: 'waiting' | 'approved' | 'closed' | 'followup' | 'remanded' | 'failed'
  readonly seq: number
  readonly time: number
}

interface TangReviewNode extends ConversationViewNode {
  readonly target: 'tang-governance'
  readonly anchorSeq: number
  readonly data: TangReviewRecord
}

type TangGovernanceNode = TangTimelineNode | TangReviewNode

interface TangTimelineSnapshot {
  readonly entries: readonly TangTimelineEntry[]
  readonly latestByStage: ReadonlyMap<TangStage, TangTimelineEntry>
  readonly reviews: readonly TangReviewRecord[]
}

interface ProgressState {
  readonly record: TangProgressRecord
  readonly seq: number
  readonly time: number
  readonly settled: TangTimelineEntry['settled']
}

interface ReviewState extends Omit<TangReviewRecord, 'key' | 'status'> {
  readonly status: TangReviewRecord['status']
}

const EMPTY_TIMELINE: TangTimelineSnapshot = { entries: [], latestByStage: new Map(), reviews: [] }

function toolResultFailed(context: ConversationNodeContext<unknown>): boolean {
  const result = context.matches.findLast(match => match.event.type === 'tool/result')?.event
  return result?.type === 'tool/result'
    && (result.data.error !== undefined || result.data.message.content[0].isError) === true
}

const progressDefinition: ConversationNodeDefinition<ProgressState> = {
  kind: 'tang-progress-call',
  target: 'tang-governance',
  match: (event) => {
    if (event.type === 'tool/call' && event.data.name === 'tang_progress') {
      try {
        return parseTangProgress(JSON.parse(event.data.arguments)) === null
          ? null
          : { id: String(event.data.callId), role: 'start' }
      } catch {
        return null
      }
    }
    if (event.type === 'tool/result') {
      return { id: String(event.data.message.source.callId), role: 'update' }
    }
    return null
  },
  start: (_context, match) => {
    if (match.event.type !== 'tool/call') throw new Error('Tang progress start requires tool/call')
    const record = parseTangProgress(JSON.parse(match.event.data.arguments))
    if (record === null) throw new Error('Tang progress call carried invalid arguments')
    return { record, seq: match.event.seq, time: match.event.time, settled: 'running' }
  },
  update: context => ({
    ...context.state,
    settled: toolResultFailed(context) ? 'failed' : 'success',
  }),
  buildViewNode: context => context.state === undefined
    ? null
    : {
      key: context.key,
      kind: 'tang-progress',
      id: context.id,
      target: 'tang-governance',
      anchorSeq: context.state.seq,
      data: {
        ...context.state.record,
        key: context.key,
        seq: context.state.seq,
        time: context.state.time,
        settled: context.state.settled,
      },
    },
}

function reviewOptions(kind: TangReviewRecord['kind'], value: unknown): readonly TangReviewOption[] {
  const defaults = kind === 'approval'
    ? [
        { label: TANG_APPROVE_LABEL, description: '方案通过后交由尚书省分阶段实施。' },
        { label: TANG_REMAND_LABEL, description: '返回中书、门下修订方案后重新上报。' },
      ]
    : [
        { label: TANG_CLOSE_LABEL, description: '确认交付与验收记录，完成本案归档。' },
        { label: TANG_REMAND_LABEL, description: '附上补充意见，返回相关部门处理后重新验收。' },
      ]
  if (kind !== 'closure' || typeof value !== 'object' || value === null) return defaults
  const verification = (value as { readonly verification_options?: unknown }).verification_options
  if (!Array.isArray(verification)) return defaults
  const choices = verification.flatMap((option): TangReviewOption[] => {
    if (typeof option !== 'object' || option === null) return []
    const item = option as Record<string, unknown>
    if (typeof item.label !== 'string' || typeof item.description !== 'string') return []
    return [{
      label: item.label,
      description: item.description,
      ...(typeof item.instruction === 'string' ? { instruction: item.instruction } : {}),
    }]
  })
  return [defaults[0]!, ...choices, defaults[1]!]
}

function reviewResultText(context: ConversationNodeContext<ReviewState>): string {
  const result = context.matches.findLast(match => match.event.type === 'tool/result')?.event
  if (result?.type !== 'tool/result') return ''
  const collect = (value: unknown): string[] => {
    if (typeof value === 'string') return []
    if (Array.isArray(value)) return value.flatMap(collect)
    if (typeof value !== 'object' || value === null) return []
    const record = value as Record<string, unknown>
    return [typeof record.text === 'string' ? record.text : '', ...Object.values(record).flatMap(collect)].filter(Boolean)
  }
  return collect(result.data.message.content).join(' ')
}

const reviewDefinition: ConversationNodeDefinition<ReviewState> = {
  kind: 'tang-review-call',
  target: 'tang-governance',
  match: (event) => {
    if (event.type === 'tool/call'
      && (event.data.name === 'tang_request_approval' || event.data.name === 'tang_submit_final_report')) {
      return { id: String(event.data.callId), role: 'start' }
    }
    if (event.type === 'tool/result') return { id: String(event.data.message.source.callId), role: 'update' }
    return null
  },
  start: (_context, match) => {
    if (match.event.type !== 'tool/call') throw new Error('Tang review start requires tool/call')
    const args = JSON.parse(match.event.data.arguments) as Record<string, unknown>
    const kind = match.event.data.name === 'tang_request_approval' ? 'approval' : 'closure'
    return {
      kind,
      caseId: typeof args.case_id === 'string' ? args.case_id : '当前案卷',
      title: typeof args.title === 'string' ? args.title : kind === 'approval' ? '会签方案' : '结案汇报',
      detail: typeof args.proposal_markdown === 'string'
        ? args.proposal_markdown
        : typeof args.report_markdown === 'string' ? args.report_markdown : '',
      options: reviewOptions(kind, args),
      status: 'waiting',
      seq: match.event.seq,
      time: match.event.time,
    }
  },
  update: (context) => {
    if (toolResultFailed(context)) return { ...context.state, status: 'failed' }
    const text = reviewResultText(context)
    if (context.state.kind === 'approval') {
      return { ...context.state, status: text.trimStart().startsWith(TANG_APPROVE_LABEL) ? 'approved' : 'remanded' }
    }
    return {
      ...context.state,
      status: text.trimStart().startsWith(TANG_CLOSE_LABEL)
        ? 'closed'
        : text.trimStart().startsWith('结案前跟进') ? 'followup' : 'remanded',
    }
  },
  buildViewNode: context => context.state === undefined
    ? null
    : {
      key: context.key,
      kind: 'tang-review',
      id: context.id,
      target: 'tang-governance',
      anchorSeq: context.state.seq,
      data: { ...context.state, key: context.key },
    },
}

class TangTimelineBuilder implements ConversationViewBuilder<TangGovernanceNode, TangTimelineSnapshot> {
  readonly empty = EMPTY_TIMELINE
  private readonly nodes = new Map<string, TangGovernanceNode>()

  replace(input: { readonly nodes: readonly TangGovernanceNode[] }): TangTimelineSnapshot {
    this.nodes.clear()
    for (const node of input.nodes) this.nodes.set(node.key, node)
    return this.snapshot()
  }

  apply(input: { readonly upserts: readonly TangGovernanceNode[] }): TangTimelineSnapshot {
    for (const node of input.upserts) this.nodes.set(node.key, node)
    return this.snapshot()
  }

  private snapshot(): TangTimelineSnapshot {
    const nodes = [...this.nodes.values()].sort((left, right) => left.anchorSeq - right.anchorSeq)
    const entries = nodes.filter((node): node is TangTimelineNode => node.kind === 'tang-progress').map(node => node.data)
    const reviews = nodes.filter((node): node is TangReviewNode => node.kind === 'tang-review').map(node => node.data)
    const latestByStage = new Map<TangStage, TangTimelineEntry>()
    for (const entry of entries) latestByStage.set(entry.stage, entry)
    return { entries, latestByStage, reviews }
  }
}

const timelineView: ConversationViewDefinition<TangGovernanceNode, TangTimelineSnapshot> = {
  target: 'tang-governance',
  create: () => new TangTimelineBuilder(),
}

type CatalogEntry = SubagentCatalogSnapshot['entries'][number]
type ChildEntry = Extract<CatalogEntry, { kind: 'child' }>

interface LocatedChild {
  readonly entry: ChildEntry
  readonly parentSessionId: SessionId
  readonly depth: number
}

type QuestionWait = Extract<PendingInteraction, { readonly kind: 'question' }>
type QuestionItem = QuestionWait['payload']['questions'][number]

interface TangCaseReview {
  readonly kind: 'approval' | 'closure'
  readonly wait: QuestionWait
  readonly question: QuestionItem
}

interface TangModelReasoning {
  readonly efforts: readonly { readonly id: string; readonly name: string; readonly description?: string }[]
  readonly defaultEffort?: string
}

interface TangCatalogModel {
  readonly id: string
  readonly name: string
  readonly description?: string
  readonly reasoning?: TangModelReasoning
}

interface TangModelCatalog {
  readonly current: { readonly provider: string; readonly model: string; readonly reasoningEffort?: string }
  readonly groups: readonly {
    readonly id: string
    readonly name: string
    readonly models: readonly TangCatalogModel[]
  }[]
}

type TangModelsResponse = {
  readonly result:
    | { readonly ok: true; readonly value: TangModelCatalog }
    | { readonly ok: false; readonly error: { readonly code: string; readonly message: string } }
}

interface TangClientConnection {
  readonly api: {
    readonly sessions: {
      models(request: { readonly sessionId: SessionId }): Promise<TangModelsResponse>
    }
    readonly subagents: {
      history(request: SubagentAddress & { readonly maxMessages?: number }): Promise<{
        readonly result:
          | {
            readonly ok: true
            readonly value: {
              readonly events: readonly { readonly event: TangTraceEvent }[]
              readonly hasMore: boolean
              readonly projections?: { readonly values: Readonly<Record<string, unknown>> }
            }
          }
          | { readonly ok: false; readonly error: { readonly code: string; readonly message: string } }
      }>
    }
  }
}

interface TangTraceLoad {
  readonly entries: readonly TangDepartmentTrace[]
  readonly unavailableIds: readonly string[]
}

interface TangCourtInjected {
  readonly openChild: (address: SubagentAddress) => void
  readonly refresh: (parentSessionId: SessionId) => void
  readonly setCatalogOpen: (parentSessionId: SessionId, open: boolean) => void
  readonly stopTask: (rootSessionId: SessionId, childIds: readonly SessionId[]) => Promise<void>
  readonly routeSettings: SettingsScope<TangDepartmentRoutes>
  readonly loadModels: (sessionId: SessionId) => Promise<TangModelCatalog>
  readonly loadTraces: (children: readonly LocatedChild[]) => Promise<TangTraceLoad>
}

interface TangCourtProps extends TangCourtInjected {
  readonly sessionId: PropsRuntime<'conversation.session.header.actions'>['sessionId']
  readonly useSession: PropsRuntime<'conversation.session.header.actions'>['useSession']
  readonly useSessions: PropsRuntime<'conversation.session.header.actions'>['useSessions']
  readonly initialOpen?: boolean
}

type TangNewSessionCourtProps = PropsRuntime<'conversation.input.left'> & TangCourtInjected

const STYLE_ID = 'dsh-tang-governance-style'
const CSS = String.raw`
[data-tang-trigger]{border:1px solid color-mix(in srgb,var(--color-border,#b8aa91) 80%,#9b2f27);background:color-mix(in srgb,var(--color-bg,#fff) 88%,#f1e4cc);color:var(--color-text,#27231d);border-radius:999px;padding:5px 10px;font:600 12px/1.2 ui-sans-serif,system-ui;cursor:pointer;display:inline-flex;gap:6px;align-items:center}
[data-tang-trigger] i{width:7px;height:7px;border-radius:50%;background:#a83b2f;box-shadow:0 0 0 3px #a83b2f20}
[data-tang-court]{--paper:#f5efe3;--paper2:#fffaf0;--ink:#26231e;--muted:#746b5d;--line:#cbbda6;--cinnabar:#a63b30;--green:#3d6b55;position:fixed;z-index:700;inset:68px 20px 20px 278px;background:linear-gradient(135deg,#fffaf4 0%,var(--paper) 55%,#eee3d1 100%);color:var(--ink);border:1px solid #bcae96;border-radius:18px;box-shadow:0 24px 70px #261d1230;overflow:hidden;font-family:Inter,"PingFang SC","Microsoft YaHei",system-ui,sans-serif}
.tang-shell{height:100%;display:grid;grid-template-columns:minmax(0,1fr) 330px}
.tang-main{min-width:0;overflow:auto;padding:24px 26px 30px}.tang-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:20px}.tang-kicker{font:700 11px/1.2 ui-monospace,monospace;letter-spacing:.18em;text-transform:uppercase;color:var(--cinnabar)}.tang-title{font:650 25px/1.15 Georgia,"Songti SC",serif;margin:5px 0 4px}.tang-sub{color:var(--muted);font-size:12px}.tang-actions{display:flex;gap:8px}.tang-actions button,.tang-dialog button{border:1px solid var(--line);border-radius:9px;background:#fffaf1;color:var(--ink);padding:7px 10px;font-weight:600;cursor:pointer}.tang-actions .danger{border-color:#b46a61;color:#8c2e26;background:#fff4f1}
.tang-progressbar{height:4px;background:#ded2be;border-radius:99px;overflow:hidden;margin:0 0 26px}.tang-progressbar span{display:block;height:100%;background:linear-gradient(90deg,#b54b3d,#8e2f27);transition:width .3s ease}
.tang-org-chart{--org-line:#b6a485;min-width:0;padding:2px 0 12px}.tang-org-level{position:relative;z-index:2;display:grid}.tang-org-review{grid-template-columns:repeat(2,minmax(0,1fr));gap:clamp(24px,8vw,92px);padding:0 clamp(8px,3vw,34px)}.tang-org-executive{grid-template-columns:minmax(230px,42%);justify-content:center}.tang-org-ministries{grid-template-columns:repeat(6,minmax(86px,1fr));gap:10px}.tang-org-link{position:relative;z-index:1;height:48px;color:var(--org-line);pointer-events:none}.tang-org-link i{position:absolute;display:block;background:currentColor}.tang-org-link--review .tang-link-bus{left:25%;right:25%;top:23px;height:1px}.tang-org-link--review .tang-link-in-left,.tang-org-link--review .tang-link-in-right{top:0;width:1px;height:24px}.tang-org-link--review .tang-link-in-left{left:25%}.tang-org-link--review .tang-link-in-right{left:75%}.tang-org-link--review .tang-link-out{left:50%;top:23px;bottom:0;width:1px}.tang-org-link--ministries{height:62px}.tang-org-link--ministries .tang-link-in{left:50%;top:0;height:29px;width:1px}.tang-org-link--ministries .tang-link-bus{left:8.333%;right:8.333%;top:28px;height:1px}.tang-org-link--ministries .tang-link-drop{top:28px;bottom:0;width:1px}.tang-org-link--ministries .tang-link-drop:nth-of-type(3){left:8.333%}.tang-org-link--ministries .tang-link-drop:nth-of-type(4){left:25%}.tang-org-link--ministries .tang-link-drop:nth-of-type(5){left:41.667%}.tang-org-link--ministries .tang-link-drop:nth-of-type(6){left:58.333%}.tang-org-link--ministries .tang-link-drop:nth-of-type(7){left:75%}.tang-org-link--ministries .tang-link-drop:nth-of-type(8){left:91.667%}.tang-org-caption{position:absolute;left:calc(50% + 11px);top:9px;color:#8a6a47;font:700 9px/1.2 ui-monospace,monospace;letter-spacing:.12em;white-space:nowrap}.tang-office-node{min-width:0;display:flex;flex-direction:column}.tang-route-controls{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);gap:7px;margin:0 0 8px}.tang-route-field{position:relative;min-width:0}.tang-route-field:before{position:absolute;z-index:1;left:9px;top:6px;color:#8a6a47;font:700 8px/1 ui-monospace,monospace;letter-spacing:.11em;pointer-events:none}.tang-route-field.model:before{content:"MODEL"}.tang-route-field.effort:before{content:"THINK"}.tang-route-field select{appearance:none;width:100%;height:43px;border:1px solid #c8b89e;border-radius:9px;background:linear-gradient(180deg,#fffdf8,#f7eddd);color:var(--ink);padding:16px 24px 4px 9px;font:600 10px/1.2 ui-sans-serif,system-ui;white-space:nowrap;text-overflow:ellipsis;cursor:pointer;box-shadow:0 2px 7px #513b1c0a}.tang-route-field:after{content:"\2304";position:absolute;right:8px;top:16px;color:#8a6a47;font-size:12px;pointer-events:none}.tang-route-field select:focus{outline:2px solid #a63b3033;outline-offset:1px;border-color:#a7695d}.tang-route-field select:disabled{cursor:wait;opacity:.62}.tang-route-error{grid-column:1/-1;color:#9a362d;font-size:9px;line-height:1.3}.tang-card{appearance:none;position:relative;width:100%;flex:1;text-align:left;border:1px solid var(--line);border-radius:13px;background:linear-gradient(145deg,#fffdf8,#f4ead9);padding:15px;min-height:136px;color:inherit;cursor:pointer;box-shadow:0 5px 16px #513b1c0d;transition:transform .16s,border-color .16s,box-shadow .16s}.tang-card:hover{transform:translateY(-2px);border-color:#a98b68;box-shadow:0 9px 22px #513b1c16}.tang-card.running{border-color:#b96558;box-shadow:inset 3px 0 #a63b30}.tang-card.passed{box-shadow:inset 3px 0 #47735d}.tang-card.failed,.tang-card.remanded,.tang-card.stopped{box-shadow:inset 3px 0 #a63b30}.tang-card-top{display:flex;justify-content:space-between;gap:10px}.tang-name{font:650 18px Georgia,"Songti SC",serif}.tang-en{display:block;font:9px ui-monospace,monospace;color:#8b7d68;text-transform:uppercase;letter-spacing:.07em;margin-top:3px;overflow:hidden;text-overflow:ellipsis}.tang-dot{flex:none;width:9px;height:9px;border-radius:50%;background:#b9ad9a;margin-top:3px;box-shadow:0 0 0 4px #b9ad9a20}.tang-card.running .tang-dot{background:#b64034;animation:tangPulse 1.4s infinite}.tang-card.passed .tang-dot{background:#44745b}.tang-duty{display:block;font-size:12px;color:var(--muted);line-height:1.5;margin-top:12px}.tang-agent{display:block;font:10px ui-monospace,monospace;color:#5f5548;margin-top:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.tang-org-ministries .tang-card{min-height:122px;padding:13px 11px}.tang-org-ministries .tang-name{font-size:16px}.tang-org-ministries .tang-duty{font-size:11px;margin-top:10px}
.tang-timeline{border-left:1px solid var(--line);background:#efe5d5cc;padding:22px 18px;overflow:auto;box-shadow:inset 10px 0 25px #70512a0a}.tang-timeline h2{font:650 15px Georgia,"Songti SC",serif;margin:0}.tang-timeline-meta{color:var(--muted);font-size:11px;margin:5px 0 20px}.tang-step{position:relative;padding:0 0 18px 24px}.tang-step:before{content:"";position:absolute;left:6px;top:7px;bottom:-7px;width:1px;background:#c5b69e}.tang-step:last-child:before{display:none}.tang-step-dot{position:absolute;left:1px;top:3px;width:11px;height:11px;border:2px solid #b7aa95;background:#efe5d5;border-radius:50%}.tang-step.running .tang-step-dot,.tang-step.waiting_input .tang-step-dot,.tang-step.waiting_approval .tang-step-dot{border-color:var(--cinnabar);background:#fff}.tang-step.passed .tang-step-dot{border-color:var(--green);background:var(--green)}.tang-step.remanded .tang-step-dot,.tang-step.failed .tang-step-dot,.tang-step.stopped .tang-step-dot{border-color:var(--cinnabar);background:var(--cinnabar)}.tang-step-title{font-size:12px;font-weight:650}.tang-step-status{font:10px ui-monospace,monospace;color:#8a7660;margin-top:3px}.tang-step-summary{font-size:11px;color:var(--muted);line-height:1.45;margin-top:5px}.tang-empty{font-size:12px;color:var(--muted);padding:16px;border:1px dashed var(--line);border-radius:10px}
.tang-dialog-backdrop{position:fixed;z-index:720;inset:0;background:#1c160e45;display:grid;place-items:center;padding:24px}.tang-dialog{width:min(560px,calc(100vw - 40px));max-height:min(680px,calc(100vh - 40px));overflow:auto;background:#fffaf0;color:#28231c;border:1px solid #b7a68d;border-radius:16px;box-shadow:0 30px 90px #1a120d55;padding:22px}.tang-dialog-head{display:flex;justify-content:space-between;gap:20px}.tang-dialog h3{font:650 22px Georgia,"Songti SC",serif;margin:0}.tang-dialog .close{border:0;background:transparent;padding:2px 6px;font-size:20px}.tang-dialog-section{margin-top:18px;padding-top:14px;border-top:1px solid #ded1bd}.tang-dialog-section h4{font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:#8b6d4c;margin:0 0 8px}.tang-dialog-event{padding:9px 0;border-bottom:1px dashed #ded1bd;font-size:12px}.tang-dialog-event:last-child{border:0}.tang-dialog-note{font-size:11px;color:#786c5b;line-height:1.5;margin:12px 0}.tang-dialog-footer{display:flex;justify-content:flex-end;gap:8px;margin-top:18px}
.tang-card.succeeded{box-shadow:inset 3px 0 #47735d}.tang-card.succeeded .tang-dot{background:#44745b}.tang-step.succeeded .tang-step-dot{border-color:var(--green);background:var(--green)}
@keyframes tangPulse{50%{box-shadow:0 0 0 7px #b6403410}}@media(max-width:1450px){[data-tang-court]{left:18px}.tang-shell{grid-template-columns:minmax(0,1fr) 310px}}@media(max-width:980px){.tang-shell{display:block;overflow:auto}.tang-main,.tang-timeline{overflow:visible}.tang-timeline{border-left:0;border-top:1px solid var(--line)}.tang-org-ministries{grid-template-columns:repeat(6,minmax(92px,1fr))}}@media(max-width:680px){[data-tang-court]{inset:58px 8px 8px}.tang-head{display:block}.tang-actions{margin-top:12px}.tang-main{padding:20px 16px 26px}.tang-org-review{gap:12px;padding:0}.tang-org-review .tang-card{min-height:126px;padding:13px}.tang-org-review .tang-name{font-size:16px}.tang-org-review .tang-duty{font-size:11px}.tang-org-executive{grid-template-columns:minmax(220px,82%)}.tang-org-ministries{grid-template-columns:1fr;gap:12px;margin-left:40px}.tang-org-ministries:before{content:"";position:absolute;left:-20px;top:-32px;bottom:56px;width:1px;background:var(--org-line)}.tang-org-ministries .tang-card{min-height:106px}.tang-org-ministries .tang-card:before{content:"";position:absolute;right:100%;top:50%;width:20px;height:1px;background:var(--org-line)}.tang-org-link--ministries{height:38px}.tang-org-link--ministries .tang-link-in{height:18px}.tang-org-link--ministries .tang-link-bus{left:20px;right:50%;top:17px}.tang-org-link--ministries .tang-link-drop{display:none}.tang-org-link--ministries .tang-link-drop:nth-of-type(3){display:block;left:20px;top:17px;bottom:0}.tang-org-caption{left:calc(50% + 9px);top:1px}.tang-title{font-size:22px}}@media(max-width:480px){.tang-route-controls{grid-template-columns:1fr}.tang-route-field select{height:40px}.tang-route-error{grid-column:auto}}
`

const TECH_CSS = String.raw`
[data-tang-trigger]{border:1px solid #a5684f88;background:#111f22;color:#e6d9c3;border-radius:14px;padding:6px 11px;letter-spacing:.06em;box-shadow:0 8px 24px #0005}[data-tang-trigger] i{background:#bb6b4f;box-shadow:0 0 10px #bb6b4f88}
[data-tang-court]{--ink:#e8e1d5;--muted:#90a09d;--line:#8f654c55;--cinnabar:#bd6048;--green:#6fb094;--bronze:#b87355;--cyan:#69b5b0;inset:clamp(78px,8vh,96px) clamp(24px,4vw,64px) clamp(24px,4vh,46px) clamp(250px,19vw,304px);max-width:1320px;margin:0 auto;background:radial-gradient(circle at 16% 4%,#28545a73 0,transparent 29%),radial-gradient(circle at 58% 44%,#17424724 0,transparent 38%),radial-gradient(circle at 88% 86%,#88472f24 0,transparent 31%),linear-gradient(145deg,#071214,#0b191c 58%,#101819);color:var(--ink);border:1px solid #a66a4e70;border-radius:28px;box-shadow:0 28px 90px #000a,inset 0 0 80px #061012aa;isolation:isolate;font-family:"PingFang SC","Microsoft YaHei",system-ui,sans-serif}[data-tang-court]:before{content:"";position:absolute;z-index:0;inset:0;pointer-events:none;border-radius:inherit;opacity:.6;background-image:radial-gradient(circle,#84c9c22e 1px,transparent 1.5px),radial-gradient(circle,#bc76552d 1.5px,transparent 2px),linear-gradient(#72bdb707 1px,transparent 1px),linear-gradient(90deg,#72bdb707 1px,transparent 1px);background-size:20px 20px,100px 100px,100px 100px,100px 100px;background-position:0 0,10px 10px,0 0,0 0;box-shadow:inset 0 0 110px #3f8d850d}
.tang-shell{position:relative;z-index:1;grid-template-columns:minmax(0,1fr) 292px}.tang-main{padding:23px 26px 28px}.tang-head{align-items:center;margin-bottom:16px;padding:0 0 16px;border-bottom:1px solid #a36b4b35}.tang-head:before{display:none}.tang-brand{display:flex;align-items:center;gap:13px}.tang-logo{flex:none;width:48px;height:48px;overflow:visible;filter:drop-shadow(0 0 12px #c9795545)}.tang-logo-plate{fill:#142a2d;stroke:#a96d53;stroke-width:1.35;filter:drop-shadow(0 7px 9px #0005)}.tang-logo-plate-inner{fill:none;stroke:#70aaa4;stroke-width:.7;stroke-dasharray:2 3;opacity:.6}.tang-logo-mark{fill:none;stroke:#d18a67;stroke-width:2.35;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 4px #d18a6748)}.tang-logo-accent{fill:none;stroke:#72b7b0;stroke-width:1;stroke-linecap:round;opacity:.78}.tang-logo-node{fill:#78bdb6;filter:drop-shadow(0 0 2px #78bdb6)}.tang-kicker{margin:0 0 5px;color:#eadfcf;font:500 17px/1.1 "FZShuTi","STLiti","LiSu","KaiTi","STKaiti",serif;letter-spacing:.18em}.tang-sub{color:#839692;font:500 10px/1.4 ui-monospace,monospace}.tang-actions button,.tang-dialog button{border:1px solid #9b6a505e;background:#122225;color:#d9d1c5;border-radius:12px;padding:7px 11px}.tang-actions .danger{border-color:#a05d4c88;color:#df9580;background:#251a1a}.tang-progressbar{height:4px;border:0;border-radius:99px;background:#17282b}.tang-progressbar span{background:linear-gradient(90deg,#a95e48,#cf8763);box-shadow:0 0 12px #bf735455}
[data-tang-court][data-new-session="true"] .tang-shell{grid-template-columns:minmax(0,1fr)}[data-tang-court][data-new-session="true"] .tang-timeline{display:none}[data-tang-court][data-new-session="true"] .tang-main{overflow:auto}
.tang-org-chart{--org-line:#87634f80;--review-width:748px;--review-gap:clamp(18px,4vw,48px);--review-gap-quarter:clamp(4.5px,1vw,12px);--ministries-width:873px;padding:0 0 8px}.tang-org-review{width:min(100%,var(--review-width));margin-inline:auto;grid-template-columns:repeat(2,minmax(210px,350px));justify-content:center;gap:var(--review-gap);padding:0}.tang-org-executive{grid-template-columns:minmax(235px,330px)}.tang-org-ministries{width:min(100%,var(--ministries-width));margin-inline:auto;grid-template-columns:repeat(6,minmax(96px,138px));justify-content:center;gap:9px}.tang-org-link{color:var(--org-line)}.tang-org-link i{background:currentColor;box-shadow:0 0 6px #b46f4f25}.tang-org-link--review{width:min(100%,var(--review-width));margin-inline:auto}.tang-org-link--review .tang-link-bus{left:calc(25% - var(--review-gap-quarter));right:calc(25% - var(--review-gap-quarter))}.tang-org-link--review .tang-link-in-left{left:calc(25% - var(--review-gap-quarter))}.tang-org-link--review .tang-link-in-right{left:calc(75% + var(--review-gap-quarter))}.tang-org-link--ministries{width:min(100%,var(--ministries-width));margin-inline:auto}.tang-org-link--ministries .tang-link-bus{left:calc(8.333% - 3.75px);right:calc(8.333% - 3.75px)}.tang-org-link--ministries .tang-link-drop:nth-of-type(3){left:calc(8.333% - 3.75px)}.tang-org-link--ministries .tang-link-drop:nth-of-type(4){left:calc(25% - 2.25px)}.tang-org-link--ministries .tang-link-drop:nth-of-type(5){left:calc(41.667% - .75px)}.tang-org-link--ministries .tang-link-drop:nth-of-type(6){left:calc(58.333% + .75px)}.tang-org-link--ministries .tang-link-drop:nth-of-type(7){left:calc(75% + 2.25px)}.tang-org-link--ministries .tang-link-drop:nth-of-type(8){left:calc(91.667% + 3.75px)}.tang-org-caption{color:#a57860;font:500 9px/1.2 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.08em}
.tang-main{display:flex;flex-direction:column}.tang-org-chart{flex:1;display:flex;min-height:540px;flex-direction:column;justify-content:center}.tang-review-domain{position:relative;flex:none;padding:14px;border:1px dashed #6b99925c;border-radius:24px;background:linear-gradient(180deg,#1733372b,#0a1b1e18);box-shadow:inset 0 0 34px #69b5b008}.tang-org-link--review{flex:none;height:72px;margin-top:-15px}.tang-shangshu-domain{position:relative;flex:none;margin-top:-1px;padding:14px 14px 16px;border:1px dashed #a66e505c;border-radius:24px;background:linear-gradient(180deg,#1832352b,#0b1b1e1f);box-shadow:inset 0 0 34px #69b5b006}.tang-shangshu-domain:before{content:"";position:absolute;left:50%;top:-1px;width:1px;height:15px;background:var(--org-line);box-shadow:0 0 6px #b46f4f25}
.tang-sub{display:flex;align-items:center;gap:7px;margin-top:6px;color:#718783;font:500 9px/1.2 "PingFang SC","Microsoft YaHei",sans-serif}.tang-sub span{color:#a77a62}.tang-sub b{max-width:260px;overflow:hidden;color:#91a5a0;font-weight:500;text-overflow:ellipsis;white-space:nowrap}
.tang-card{position:relative;width:100%;min-height:146px;padding:0;border:1px solid #a873576b;border-radius:20px;background:linear-gradient(145deg,#1a3033f2,#142629f5);color:var(--ink);cursor:default;box-shadow:0 12px 30px #0006,inset 0 1px #ffffff12,inset 0 0 28px #68b7b008;overflow:hidden;transform:none;backdrop-filter:blur(6px)}.tang-card[data-tier="department"]{background:linear-gradient(145deg,#20383bf5,#172b2ef7);border-color:#b178596e;box-shadow:0 14px 34px #0006,inset 0 1px #ffffff14,inset 0 0 32px #71c4bc0b}.tang-card:before{display:none}.tang-card:hover{transform:translateY(-1px);border-color:#c5856699;background:linear-gradient(145deg,#213b3ef5,#182d30f7);box-shadow:0 16px 34px #0007,0 0 24px #6abbb321}.tang-card.running{border-color:#c47c5daa;box-shadow:0 0 26px #bd6e4b30,inset 0 0 26px #bf76500b}.tang-card.passed,.tang-card.succeeded{border-color:#6ca58c90;box-shadow:0 0 20px #4f8f7626}.tang-card.failed,.tang-card.remanded,.tang-card.stopped{border-color:#b86554a0;box-shadow:0 0 20px #a8524228}.tang-card-summary{appearance:none;width:100%;border:0;background:transparent;color:inherit;text-align:left;padding:13px 14px 9px;cursor:pointer}.tang-office-title{min-width:0}.tang-name{color:#f3e8d5;font:500 18px/1.1 "FZShuTi","STLiti","LiSu","KaiTi","STKaiti",serif;letter-spacing:.14em}.tang-en{display:none}.tang-status{display:flex;align-items:center;gap:6px;color:#9aaba7;font:500 9px/1.1 "PingFang SC","Microsoft YaHei",sans-serif;white-space:nowrap}.tang-dot{width:6px;height:6px;margin:0;background:#72827e;box-shadow:none}.tang-card.running .tang-dot{background:#cf7f60;box-shadow:0 0 11px #cf7f60}.tang-card.passed .tang-dot,.tang-card.succeeded .tang-dot{background:#77b399}.tang-duty{margin-top:9px;color:#b5bfba;font-size:11px;line-height:1.35}.tang-agent{margin-top:8px;color:#80938f;font:500 8px/1.2 "PingFang SC","Microsoft YaHei",sans-serif}
.tang-route-controls{position:relative;display:grid;grid-template-columns:minmax(0,1.45fr) minmax(0,1fr);gap:7px;margin:auto 11px 11px;padding:9px 0 0;border-top:1px solid #ae765437}.tang-route-controls:before{display:none}.tang-route-field.model:before{content:"模型"}.tang-route-field.effort:before{content:"思考"}.tang-route-field:before{left:9px;top:5px;color:#aa8c79;font-size:7px;letter-spacing:.08em}.tang-route-field:after{content:"▾";top:13px;color:#c18060}.tang-route-field select{height:36px;border:1px solid #92705e66;border-radius:11px;background:#102124cc;color:#e0d9cc;padding:13px 22px 3px 9px;font:500 9px/1.2 "PingFang SC","Microsoft YaHei",sans-serif}.tang-ministry-policy{display:grid;gap:3px;margin:auto 10px 10px;padding-top:8px;border-top:1px solid #ae765437;color:#8c9e99;font:500 8px/1.25 "PingFang SC","Microsoft YaHei",sans-serif}.tang-ministry-policy span{display:flex;gap:5px}.tang-ministry-policy b{color:#c18060;font-size:8px}.tang-org-ministries .tang-card{min-height:112px;padding:0}.tang-org-ministries .tang-card-summary{padding:12px 11px 8px}.tang-org-ministries .tang-name{font-size:16px}.tang-org-ministries .tang-duty{font-size:10px}.tang-org-ministries .tang-agent{display:none}
.tang-card[data-tier="department"]{min-height:118px}.tang-org-ministries .tang-card{min-height:78px}.tang-org-ministries .tang-card-summary{padding:12px 11px}.tang-org-ministries .tang-duty{margin-top:8px;font-size:9px}
.tang-name{white-space:nowrap}.tang-status{padding:4px 7px;border:1px solid #71807b45;border-radius:999px;background:#10212499;color:#91a19d;box-shadow:inset 0 1px #ffffff08}.tang-card.pending .tang-status{border-color:#93735d55;color:#aa9b8f}.tang-card.running .tang-status{border-color:#c67d5e70;background:#2a1d1a;color:#dda087;box-shadow:0 0 13px #be76502a}.tang-card.running .tang-dot{animation:tangPulse 1.45s ease-in-out infinite}.tang-card.succeeded .tang-status,.tang-card.passed .tang-status{border-color:#68a78e65;background:#132a26;color:#91ccb2}.tang-card.failed .tang-status,.tang-card.remanded .tang-status,.tang-card.stopped .tang-status{border-color:#b865546e;background:#2b1918;color:#dd8c7d}.tang-card.idle{opacity:.56;border-color:#765e4e4a;background:linear-gradient(145deg,#14272ac4,#0e1d20cc);box-shadow:0 8px 20px #0004,inset 0 1px #ffffff08;filter:saturate(.62)}.tang-card.idle:hover{opacity:.74;background:linear-gradient(145deg,#172c2fd9,#102124e0);filter:saturate(.8)}.tang-card.idle .tang-status{border-color:#68746f35;background:#0b181a88;color:#7e8a86}.tang-card.idle .tang-dot{background:#697570}.tang-org-ministries .tang-card{min-height:92px}.tang-org-ministries .tang-card-summary{position:relative;box-sizing:border-box;min-height:92px}.tang-org-ministries .tang-card-top{display:block}.tang-org-ministries .tang-status{position:absolute;left:11px;bottom:10px;padding:3px 6px}.tang-org-ministries .tang-duty{padding-bottom:23px}
.tang-card-ornament{position:absolute;z-index:0;top:-24px;right:-16px;width:78px;height:78px;overflow:visible;fill:none;stroke:#db8b67d1;stroke-width:1.05;stroke-linecap:round;stroke-linejoin:round;opacity:.17;pointer-events:none;transform:rotate(-2deg);transform-origin:75% 25%;transition:opacity .18s,transform .18s}.tang-card-ornament path{vector-effect:non-scaling-stroke}.tang-card[data-tier="department"] .tang-card-ornament{top:-27px;right:-14px;width:116px;height:116px;fill:#bd7155;stroke:none;opacity:.12;filter:drop-shadow(0 0 7px #c77c5938)}.tang-card[data-tier="department"] .tang-card-ornament[data-filled-ornament]{top:-15px;right:-7px;color:#bd7155;fill:currentColor;stroke:none;transform:none}.tang-card[data-tier="department"] .tang-card-ornament[data-ornament-office="zhongshu"]{width:188px;height:97px}.tang-card[data-tier="department"] .tang-card-ornament[data-ornament-office="menxia"]{width:176px;height:97px}.tang-card[data-tier="department"] .tang-card-ornament[data-ornament-office="shangshu"]{top:-19px;right:-4px;width:112px;height:112px}.tang-org-ministries .tang-card-ornament{top:-25px;right:-16px;width:76px;height:76px;stroke-width:1.05}.tang-card-summary,.tang-route-controls{position:relative;z-index:1}.tang-card:hover .tang-card-ornament{opacity:.21;transform:rotate(0)}.tang-card:hover .tang-card-ornament[data-filled-ornament]{transform:none}.tang-card.idle .tang-card-ornament{opacity:.08}
.tang-logo-mark{fill:url(#tang-logo-petal-gradient);stroke:#efae87;stroke-width:.7;filter:drop-shadow(0 0 5px #d18a675c)}
.tang-card[data-tier="department"] .tang-card-ornament[data-ornament-office="zhongshu"]{width:188px;height:97px}.tang-card[data-tier="department"] .tang-card-ornament[data-ornament-office="menxia"]{width:176px;height:97px}.tang-card[data-tier="department"] .tang-card-ornament[data-ornament-office="shangshu"]{top:-15px;right:-7px;width:182px;height:91px}
.tang-card-ornament[data-filled-ornament],.tang-trace-ornament[data-filled-ornament]{overflow:hidden}.tang-filled-ornament-art{position:absolute;left:0;top:0;display:block;width:100%;height:100%;max-width:none}.tang-card-ornament[data-crop-bottom] .tang-filled-ornament-art,.tang-trace-ornament[data-crop-bottom] .tang-filled-ornament-art{top:-100%;height:200%}
.tang-logo-plate{stroke:url(#tang-logo-frame-gradient);stroke-width:.85}
[data-tang-court]{top:clamp(68px,6.3vh,84px);right:0;bottom:0;left:clamp(238px,18vw,304px);max-width:none;margin:0;border-radius:0;border-right:0;border-bottom:0}body:has([data-sidebar-collapsed]) [data-tang-court]{left:64px}
.tang-timeline{border-left:1px solid #a16f4b45;background:#071315d9;padding:20px 16px;box-shadow:inset 18px 0 34px #0002}.tang-timeline h2{color:#eee2cf;font:500 16px/1.2 "FZShuTi","STLiti","LiSu","KaiTi","STKaiti",serif;letter-spacing:.1em}.tang-timeline h2:before{content:"任务流";color:#c08061;font:500 8px/1 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.12em;display:block;margin-bottom:7px}.tang-timeline-meta{color:#81938f;font-size:9px}.tang-step:before{background:linear-gradient(#8e644d,#335f5c)}.tang-step-dot{border-color:#736f65;background:#101b1e}.tang-step-title{color:#cfd2c9}.tang-step-status{color:#758b86}.tang-empty{border:1px solid #9f6c4f55;background:#17292cb8;color:#8c9d99;border-radius:14px}.tang-dialog-backdrop{background:#02090bc9;backdrop-filter:blur(5px)}.tang-dialog{background:linear-gradient(145deg,#1a3033,#0d1b1d);color:#ddd7ca;border:1px solid #aa73546e;border-radius:22px}
@media(max-width:1450px){[data-tang-court]{left:clamp(238px,18vw,270px);right:0}.tang-shell{grid-template-columns:minmax(0,1fr) 280px}.tang-main{padding:21px 22px 26px}}@media(max-width:1100px){[data-tang-court]{inset:68px 0 0}.tang-shell{display:block;overflow:auto}.tang-main,.tang-timeline{overflow:visible}.tang-timeline{border-left:0;border-top:1px solid #a16f4b38}}@media(max-width:780px){.tang-main{padding:18px 14px 24px}.tang-org-review{gap:10px}.tang-org-review .tang-card{min-height:140px}.tang-org-executive{grid-template-columns:minmax(220px,76%)}.tang-org-link--ministries{width:100%}.tang-org-ministries{width:100%;grid-template-columns:repeat(6,minmax(86px,1fr));gap:9px;margin-left:0}.tang-org-ministries .tang-card{min-height:106px}.tang-route-controls{grid-template-columns:1fr;margin:7px 10px 10px}.tang-logo{width:42px;height:42px}}@media(max-width:680px){.tang-org-review{width:100%;grid-template-columns:1fr}.tang-org-link--review{width:100%}.tang-org-link--review .tang-link-in-left{left:50%}.tang-org-link--review .tang-link-in-right{display:none}.tang-org-link--review .tang-link-bus{display:none}.tang-org-ministries{width:calc(100% - 40px);grid-template-columns:1fr;margin-left:40px}.tang-org-link--ministries{width:100%;height:38px}.tang-org-link--ministries .tang-link-in{height:18px}.tang-org-link--ministries .tang-link-bus{left:20px;right:50%;top:17px}.tang-org-link--ministries .tang-link-drop{display:none}.tang-org-link--ministries .tang-link-drop:nth-of-type(3){display:block;left:20px;top:17px;bottom:0}}@media(max-width:520px){.tang-head{display:block}.tang-actions{margin-top:12px}}
`

const TRACE_CSS = String.raw`
.tang-org-chart{position:relative;top:clamp(-48px,-3vh,-18px);min-height:0;justify-content:center;padding:clamp(18px,2.8vh,34px) 0 clamp(14px,2.2vh,26px)}.tang-org-link--review{flex:none;height:clamp(70px,12vh,170px);margin-top:-8px}.tang-org-link--review .tang-link-bus{top:50%}.tang-org-link--review .tang-link-in-left,.tang-org-link--review .tang-link-in-right{height:50%}.tang-org-link--review .tang-link-out{top:50%}.tang-shangshu-domain{display:flex;min-height:0;flex:none;flex-direction:column}.tang-org-link--ministries{flex:none;height:clamp(64px,10vh,145px)}.tang-org-link--ministries .tang-link-in{height:50%}.tang-org-link--ministries .tang-link-bus{top:50%}.tang-org-link--ministries .tang-link-drop{top:50%}.tang-review-domain,.tang-shangshu-domain{padding:clamp(11px,1.5vh,15px)}
.tang-shell{grid-template-columns:minmax(0,1fr) clamp(320px,23vw,420px)}
.tang-main{padding-top:20px}.tang-head{box-sizing:border-box;height:73px;min-height:73px;margin-bottom:0;padding:0 0 13px}.tang-actions{align-items:center;gap:8px}.tang-actions button{box-sizing:border-box;height:36px;border-radius:11px;padding:0 13px;font-size:11px;line-height:34px}.tang-timeline{padding:0 18px 26px}.tang-timeline h2:before{display:none}.tang-trace-head{position:sticky;z-index:5;top:0;display:flex;box-sizing:border-box;height:93px;align-items:center;justify-content:space-between;gap:10px;margin-bottom:15px;padding:20px 0 13px;border-bottom:1px solid #9a6a4c35;background:linear-gradient(180deg,#071315 0%,#071315fa 76%,#071315e8 100%);box-shadow:0 9px 16px #06111380;backdrop-filter:blur(10px)}.tang-trace-head .tang-timeline-meta{margin:6px 0 0;line-height:1.45}.tang-trace-head-stats{display:flex;flex:none;gap:8px}.tang-trace-head-stats span{display:flex;box-sizing:border-box;height:36px;align-items:center;gap:4px;border:1px solid #9a684b4f;border-radius:11px;background:#142629c7;padding:0 10px;color:#7f928d;font:500 8px/1 "PingFang SC","Microsoft YaHei",sans-serif;box-shadow:inset 0 1px #ffffff09}.tang-trace-head-stats b{color:#ce8d6c;font-size:11px}
.tang-trace-list{position:relative;display:block}.tang-trace-item{appearance:none;position:relative;display:grid;grid-template-columns:24px minmax(0,1fr);width:100%;margin:0;padding:0 0 10px;border:0;background:transparent;color:inherit;text-align:left;cursor:pointer}.tang-trace-item:last-child{padding-bottom:0}.tang-trace-rail{position:relative;display:block;align-self:stretch;min-height:38px}.tang-trace-rail:after{content:"";position:absolute;left:10px;top:11px;bottom:-21px;width:1px;background:linear-gradient(180deg,#966a50 0%,#3e6e68 65%,#315c58 100%);box-shadow:0 0 5px #5b999133}.tang-trace-item:last-child .tang-trace-rail:after{display:none}.tang-trace-rail i{position:absolute;z-index:1;left:4px;top:4px;box-sizing:border-box;width:14px;height:14px;border:2px solid #6c6b5f;background:#0c171a;border-radius:50%;box-shadow:0 0 0 4px #071315}.tang-trace-item.is-phase .tang-trace-rail i{left:6px;top:6px;width:10px;height:10px;border-width:1px}.tang-trace-item.running .tang-trace-rail i,.tang-trace-item.waiting_input .tang-trace-rail i,.tang-trace-item.waiting_approval .tang-trace-rail i{border-color:#e05a45;box-shadow:0 0 0 4px #071315,0 0 10px #e05a4566}.tang-trace-item.succeeded .tang-trace-rail i,.tang-trace-item.passed .tang-trace-rail i{border-color:#65c8a3;background:#315e51}.tang-trace-item.failed .tang-trace-rail i,.tang-trace-item.remanded .tang-trace-rail i,.tang-trace-item.stopped .tang-trace-rail i{border-color:#d7584c;background:#6f2d29}
.tang-trace-body{display:block;box-sizing:border-box;min-width:0;border:1px solid #a26d5048;border-radius:13px;background:linear-gradient(135deg,#192c2fe8,#122326ed);padding:9px 10px 8px;box-shadow:0 6px 16px #0003,inset 0 1px #ffffff0b;transition:border-color .15s,background .15s,transform .15s}.tang-trace-item:hover .tang-trace-body{transform:translateX(1px);border-color:#c1816188;background:#1d3336}.tang-trace-item.is-department .tang-trace-body{border-radius:15px;padding:10px 12px 9px;background:linear-gradient(135deg,#20383bea,#15282bed);box-shadow:0 8px 20px #0004,inset 0 1px #ffffff10}.tang-trace-item.is-ministry .tang-trace-body,.tang-trace-item.is-phase .tang-trace-body{margin-left:18px;width:calc(100% - 18px);border-radius:10px;padding:7px 8px 6px;background:#132528e8;box-shadow:0 3px 9px #0002}.tang-trace-item.is-phase .tang-trace-body{border-color:#7a68534d;background:linear-gradient(135deg,#142629db,#102023e6)}.tang-trace-row{display:flex;align-items:center;justify-content:space-between;gap:8px}.tang-trace-office{color:#ead9b9;font:500 11px/1 "FZShuTi","STLiti","LiSu","KaiTi","STKaiti",serif;letter-spacing:.1em}.tang-trace-item.is-department .tang-trace-office{font-size:13px}.tang-trace-office em{margin-right:7px;color:#c17f60;font:600 7px/1 monospace;font-style:normal;letter-spacing:0}.tang-trace-state{flex:none;color:#8ba09b;font:600 8px/1 "PingFang SC","Microsoft YaHei",sans-serif}.tang-trace-item.running .tang-trace-state{color:#d99075}.tang-trace-item.succeeded .tang-trace-state,.tang-trace-item.passed .tang-trace-state{color:#72caa8}.tang-trace-stats{display:flex;gap:5px;margin-top:8px}.tang-trace-stats span{display:flex;align-items:baseline;gap:3px;border:1px solid #98694e40;border-radius:8px;background:#102124a6;padding:5px 7px;color:#80938e;font:500 7px/1 "PingFang SC","Microsoft YaHei",sans-serif}.tang-trace-stats b{color:#cf8e6d;font-size:9px}.tang-trace-phase-label{display:block;min-width:0;overflow:hidden;color:#b67d60;font:600 7px/1 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.06em;text-overflow:ellipsis;white-space:nowrap}.tang-trace-title{display:block;margin-top:4px;overflow:hidden;color:#cbd2cc;font-size:9px;line-height:1.3;text-overflow:ellipsis;white-space:nowrap}.tang-trace-summary{display:block;margin-top:3px;overflow:hidden;color:#849793;font-size:8px;line-height:1.3;text-overflow:ellipsis;white-space:nowrap}.tang-trace-meta{display:flex;flex-wrap:wrap;gap:4px 7px;margin-top:5px;padding-top:4px;border-top:1px solid #a16c4e32;color:#708581;font:500 7px/1.2 "PingFang SC","Microsoft YaHei",sans-serif}.tang-trace-meta time{color:#c18868}.tang-trace-warning{margin-top:14px;padding:8px 10px;border:1px solid #9a654744;border-radius:12px;background:#241b18;color:#ad8875;font-size:9px;line-height:1.45}
.tang-trace-body{position:relative;overflow:hidden;isolation:isolate}.tang-trace-body>:not(.tang-trace-ornament){position:relative;z-index:1}.tang-trace-ornament{position:absolute;z-index:0;right:-8px;top:-13px;width:58px;height:58px;overflow:visible;pointer-events:none;transform:rotate(-2deg);transform-origin:75% 25%;transition:opacity .16s,transform .16s}.tang-trace-ornament path{vector-effect:non-scaling-stroke}.tang-trace-item.is-department .tang-trace-ornament{top:-16px;right:-9px;width:74px;height:74px;fill:#bd7155;stroke:none;opacity:.09;filter:drop-shadow(0 0 5px #c77c592e)}.tang-trace-item.is-department .tang-trace-ornament[data-filled-ornament]{top:-8px;right:-4px;color:#bd7155;fill:currentColor;stroke:none;transform:none}.tang-trace-item.is-department .tang-trace-ornament[data-ornament-office="zhongshu"]{width:126px;height:65px}.tang-trace-item.is-department .tang-trace-ornament[data-ornament-office="menxia"]{width:119px;height:65px}.tang-trace-item.is-department .tang-trace-ornament[data-ornament-office="shangshu"]{top:-12px;width:70px;height:70px}.tang-trace-item.is-ministry .tang-trace-ornament{fill:none;stroke:#db8b67c7;stroke-width:1;stroke-linecap:round;stroke-linejoin:round;opacity:.12}.tang-trace-item:hover .tang-trace-ornament{opacity:.18;transform:rotate(0)}.tang-trace-item:hover .tang-trace-ornament[data-filled-ornament]{transform:none}
.tang-dialog{display:flex;width:min(680px,calc(100vw - 40px));max-height:min(760px,calc(100vh - 40px));flex-direction:column;overflow:hidden}.tang-dialog .tang-dialog-section{margin-top:15px;padding-top:0;border-top:0}.tang-dialog .tang-dialog-record-section{display:flex;min-height:0;flex-direction:column;margin-top:17px;padding-top:15px;border-top:1px solid #956b5040}.tang-dialog-records{display:grid;max-height:min(430px,42vh);gap:8px;overflow-y:auto;overflow-x:hidden;margin-top:4px;padding:8px 10px 8px 42px;border:1px solid #7f624e40;border-radius:15px;background:#0c1a1cc2;scrollbar-color:#65574f #0c191b;scrollbar-width:thin}.tang-dialog-records::-webkit-scrollbar{width:8px}.tang-dialog-records::-webkit-scrollbar-track{border-radius:999px;background:#0c191b}.tang-dialog-records::-webkit-scrollbar-thumb{border:2px solid #0c191b;border-radius:999px;background:#65574f}.tang-dialog-event{position:relative;padding:10px 11px;border:1px solid #8c68534f!important;border-radius:12px;background:linear-gradient(135deg,#172b2ee8,#112225ed);font-size:11px;box-shadow:0 4px 12px #0002}.tang-dialog-event:after{content:"";position:absolute;left:-18px;top:18px;width:18px;height:1px;background:linear-gradient(90deg,#4c8179,#8b684f99)}.tang-dialog-event:not(:last-child):before{content:"";position:absolute;left:-18px;top:19px;bottom:-27px;width:1px;background:linear-gradient(180deg,#4d827a,#86634d);box-shadow:0 0 5px #5b99912e}.tang-dialog-event:last-child{border:1px solid #8c68534f}.tang-dialog-event-dot{position:absolute;z-index:1;left:-24px;top:12px;box-sizing:border-box;width:13px;height:13px;border:2px solid #72746b;border-radius:50%;background:#0c191b;box-shadow:0 0 0 4px #0c1a1c}.tang-dialog-event[data-status="running"] .tang-dialog-event-dot,.tang-dialog-event[data-status="waiting_input"] .tang-dialog-event-dot,.tang-dialog-event[data-status="waiting_approval"] .tang-dialog-event-dot{border-color:#db765a;box-shadow:0 0 0 4px #0c1a1c,0 0 9px #d56f535c}.tang-dialog-event[data-status="succeeded"] .tang-dialog-event-dot,.tang-dialog-event[data-status="passed"] .tang-dialog-event-dot{border-color:#67c2a1;background:#315c50}.tang-dialog-event[data-status="failed"] .tang-dialog-event-dot,.tang-dialog-event[data-status="remanded"] .tang-dialog-event-dot,.tang-dialog-event[data-status="stopped"] .tang-dialog-event-dot{border-color:#d75c4e;background:#6d302b}.tang-dialog-event-head,.tang-dialog-event-foot{display:flex;align-items:center;justify-content:space-between;gap:10px}.tang-dialog-event-stage{min-width:0;overflow:hidden;color:#c38364;font:600 8px/1.2 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.06em;text-overflow:ellipsis;white-space:nowrap}.tang-dialog-event-status{flex:none;color:#8fa29d;font:600 8px/1.2 "PingFang SC","Microsoft YaHei",sans-serif}.tang-dialog-event[data-status="succeeded"] .tang-dialog-event-status,.tang-dialog-event[data-status="passed"] .tang-dialog-event-status{color:#76cbaa}.tang-dialog-event[data-status="running"] .tang-dialog-event-status{color:#db9478}.tang-dialog-event strong{display:block;margin-top:5px;color:#d7d6cc;font-size:11px;line-height:1.35}.tang-dialog-event p{display:-webkit-box;margin:4px 0 0;overflow:hidden;color:#8fa19d;font-size:9px;line-height:1.5;-webkit-box-orient:vertical;-webkit-line-clamp:3}.tang-dialog-event-foot{justify-content:flex-start;margin-top:7px;padding-top:6px;border-top:1px solid #92664c32;color:#728682;font:500 8px/1.2 "PingFang SC","Microsoft YaHei",sans-serif}.tang-dialog-event-foot time{color:#c08365}.tang-dialog-note{color:#7f918d}
.tang-dialog-event:after{display:none}
.tang-trace-state-wrap{display:flex;align-items:center}.tang-trace-item.is-expanded .tang-trace-body{border-color:#a9735480;background:#172b2eea}.tang-trace-item.is-expanded .tang-trace-title,.tang-trace-item.is-expanded .tang-trace-summary{overflow:visible;text-overflow:clip;white-space:normal}.tang-trace-item.is-expanded .tang-trace-summary{line-height:1.5}
.tang-trace-state{display:inline-flex;box-sizing:border-box;min-height:20px;align-items:center;gap:5px;padding:3px 7px;border:1px solid #71807b45;border-radius:999px;background:#10212499;color:#91a19d;box-shadow:inset 0 1px #ffffff08}.tang-trace-state:before{content:"";flex:none;width:5px;height:5px;border-radius:50%;background:#72827e}.tang-trace-item.running .tang-trace-state,.tang-trace-item.waiting_input .tang-trace-state,.tang-trace-item.waiting_approval .tang-trace-state{border-color:#c67d5e70;background:#2a1d1a;color:#dda087;box-shadow:0 0 11px #be765024}.tang-trace-item.running .tang-trace-state:before,.tang-trace-item.waiting_input .tang-trace-state:before,.tang-trace-item.waiting_approval .tang-trace-state:before{background:#cf7f60;box-shadow:0 0 8px #cf7f60}.tang-trace-item.succeeded .tang-trace-state,.tang-trace-item.passed .tang-trace-state{border-color:#68a78e65;background:#132a26;color:#91ccb2}.tang-trace-item.succeeded .tang-trace-state:before,.tang-trace-item.passed .tang-trace-state:before{background:#77b399}.tang-trace-item.failed .tang-trace-state,.tang-trace-item.remanded .tang-trace-state,.tang-trace-item.stopped .tang-trace-state{border-color:#b865546e;background:#2b1918;color:#dd8c7d}.tang-trace-item.failed .tang-trace-state:before,.tang-trace-item.remanded .tang-trace-state:before,.tang-trace-item.stopped .tang-trace-state:before{background:#d06f60}
.tang-trace-item:not(.is-department) .tang-trace-state{min-height:0;gap:4px;padding:0;border:0;border-radius:0;background:transparent;box-shadow:none}.tang-trace-item:not(.is-department) .tang-trace-state:before{width:4px;height:4px;box-shadow:none}.tang-trace-item.is-retried .tang-trace-state{color:#b58a73}.tang-trace-item.is-retried .tang-trace-state:before{background:#a47761}.tang-trace-item.is-retried .tang-trace-rail i{border-color:#9b725d;background:#3b2b26}
.tang-trace-item:not(.is-department) .tang-trace-indicator{display:grid;box-sizing:border-box;width:16px;height:16px;min-height:16px;place-items:center;padding:0;border:1px solid #71807b66;border-radius:50%;background:#10212499;box-shadow:inset 0 1px #ffffff08}.tang-trace-indicator:before{display:block;width:6px;height:6px;background:#72827e;box-shadow:none}.tang-trace-item.running .tang-trace-indicator,.tang-trace-item.waiting_input .tang-trace-indicator,.tang-trace-item.waiting_approval .tang-trace-indicator{border-color:#c67d5e7d;background:#2a1d1a;box-shadow:0 0 8px #be76502e}.tang-trace-item.running .tang-trace-indicator:before,.tang-trace-item.waiting_input .tang-trace-indicator:before,.tang-trace-item.waiting_approval .tang-trace-indicator:before{background:#cf7f60;box-shadow:0 0 6px #cf7f6066}.tang-trace-item.succeeded .tang-trace-indicator,.tang-trace-item.passed .tang-trace-indicator{border-color:#68a78e73;background:#132a26;box-shadow:inset 0 1px #ffffff08}.tang-trace-item.succeeded .tang-trace-indicator:before,.tang-trace-item.passed .tang-trace-indicator:before{background:#77b399}.tang-trace-item.failed .tang-trace-indicator,.tang-trace-item.remanded .tang-trace-indicator,.tang-trace-item.stopped .tang-trace-indicator{border-color:#b865547d;background:#2b1918;box-shadow:0 0 7px #d06f6030}.tang-trace-item.failed .tang-trace-indicator:before,.tang-trace-item.remanded .tang-trace-indicator:before,.tang-trace-item.stopped .tang-trace-indicator:before{background:#d06f60}.tang-trace-item.is-retried .tang-trace-indicator{border-color:#a477617d;background:#251d1a;box-shadow:inset 0 1px #ffffff08}.tang-trace-item.is-retried .tang-trace-indicator:before{background:#a47761}
.tang-trace-item.is-department .tang-trace-ornament[data-ornament-office="zhongshu"]{width:126px;height:65px}.tang-trace-item.is-department .tang-trace-ornament[data-ornament-office="menxia"]{width:119px;height:65px}.tang-trace-item.is-department .tang-trace-ornament[data-ornament-office="shangshu"]{top:-8px;right:-4px;width:123px;height:62px}
@media(max-width:1450px){.tang-shell{grid-template-columns:minmax(0,1fr) 330px}}@media(max-width:1100px){.tang-trace-head{position:static}.tang-trace-list{display:block}.tang-trace-item{width:100%;margin:0}.tang-trace-rail{display:block}}@media(max-width:620px){.tang-trace-head{align-items:flex-start}.tang-trace-head-stats{flex-direction:column}.tang-trace-item{grid-template-columns:22px minmax(0,1fr)}}
@media(max-width:760px){.tang-org-chart{top:0;justify-content:flex-start;padding:18px 0}.tang-shangshu-domain{display:block;flex:none}.tang-org-link--review{flex:none;height:38px;margin-top:0}.tang-org-link--review .tang-link-in-left{height:18px}.tang-org-link--review .tang-link-out{top:17px}.tang-org-link--ministries{flex:none;height:38px}.tang-org-link--ministries .tang-link-in{height:18px}.tang-org-link--ministries .tang-link-bus{top:17px}.tang-org-link--ministries .tang-link-drop:nth-of-type(3){top:17px}}
`

const APPROVAL_CSS = String.raw`
.tang-approval-backdrop{position:fixed;z-index:760;inset:0;display:grid;place-items:center;padding:clamp(18px,4vw,52px);background:radial-gradient(circle at 50% 12%,#17353b66,transparent 42%),#02090be8;backdrop-filter:blur(9px)}.tang-approval-dialog{position:relative;display:grid;grid-template-rows:auto minmax(0,1fr) auto;width:min(1080px,100%);height:min(780px,100%);overflow:hidden;border:1px solid #a36c4f70;border-radius:26px;background-color:#0d1a1d;background-image:radial-gradient(circle at 10% 0%,#24474c80 0,transparent 30%),radial-gradient(circle,#8dbeba16 1px,transparent 1.4px),linear-gradient(145deg,#101f23 0%,#081316 58%,#171715 100%);background-size:auto,22px 22px,auto;color:#ddd8cc;box-shadow:0 35px 110px #000,inset 0 0 70px #00151988;font-family:"PingFang SC","Microsoft YaHei",sans-serif}.tang-approval-dialog:before{display:none}
.tang-approval-header{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;padding:22px 25px 18px;border-bottom:1px solid #9b684a3d;background:linear-gradient(90deg,#13282cbb,transparent)}.tang-approval-kicker{color:#bd7d5e;font:600 9px/1 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.16em}.tang-approval-header h2{margin:8px 0 5px;color:#f0e4cf;font:500 25px/1.12 "FZShuTi","STLiti","LiSu","KaiTi","STKaiti",serif;letter-spacing:.1em}.tang-approval-header p{margin:0;color:#91a5a1;font-size:11px}.tang-approval-seal{flex:none;display:grid;place-items:center;width:74px;height:56px;border:1px solid #a7685188;border-radius:17px;background:#2a1918;box-shadow:inset 0 0 18px #a13f3033}.tang-approval-seal span{color:#df8b70;font:500 16px/1 "FZShuTi","STLiti","LiSu","KaiTi","STKaiti",serif;letter-spacing:.18em}.tang-approval-seal small{max-width:64px;overflow:hidden;color:#9b7770;font:500 7px/1 monospace;text-overflow:ellipsis;white-space:nowrap}
.tang-approval-header-actions{display:flex;align-items:flex-start;gap:9px}.tang-approval-seal{width:94px}.tang-approval-close{display:grid;place-items:center;width:30px;height:30px;border:1px solid #8d654d52;border-radius:10px;background:#111f22;color:#9caaa6;font-size:18px;line-height:1;cursor:pointer}.tang-approval-close:hover{border-color:#b47a5b;color:#eadbc8}.tang-approval-dialog[data-review-status="waiting"] .tang-approval-seal{animation:tangReviewWait 2.2s ease-in-out infinite}.tang-approval-dialog[data-review-status="approved"] .tang-approval-seal,.tang-approval-dialog[data-review-status="closed"] .tang-approval-seal{border-color:#4f917d;background:#13251f}.tang-approval-dialog[data-review-status="approved"] .tang-approval-seal span,.tang-approval-dialog[data-review-status="closed"] .tang-approval-seal span{color:#83d4b1}@keyframes tangReviewWait{50%{box-shadow:inset 0 0 18px #a13f3033,0 0 18px #b96f5038}}
.tang-approval-seal span{white-space:nowrap;letter-spacing:.12em}
.tang-approval-layout{min-height:0;display:grid;grid-template-columns:215px minmax(0,1fr)}.tang-approval-guide{padding:24px 20px;border-right:1px solid #75623f59;background:#0b171acc}.tang-approval-code{color:#d3aa63;font:700 8px/1 monospace;letter-spacing:.22em}.tang-approval-guide h3{margin:10px 0 18px;color:#e7dcc8;font:620 17px/1.2 "Songti SC",serif;letter-spacing:.1em}.tang-approval-guide ol{margin:0;padding:0;list-style:none;counter-reset:review}.tang-approval-guide li{position:relative;margin:0 0 15px;padding:0 0 15px 28px;border-bottom:1px solid #4a5b5642;color:#94a39e;font-size:10px;line-height:1.45;counter-increment:review}.tang-approval-guide li:before{content:"0" counter(review);position:absolute;left:0;top:1px;color:#5fbdb7;font:700 8px/1 monospace}.tang-approval-rule{display:flex;gap:8px;margin-top:22px;padding:10px;border:1px solid #71433e;background:#211718;color:#c89589;font-size:9px;line-height:1.45}.tang-approval-rule i{flex:none;width:6px;height:6px;margin-top:3px;border-radius:50%;background:#e05b49;box-shadow:0 0 8px #e05b49}.tang-approval-document{min-width:0;min-height:0;display:flex;flex-direction:column;padding:20px 24px;background-image:linear-gradient(#64bbb806 1px,transparent 1px),linear-gradient(90deg,#64bbb806 1px,transparent 1px);background-size:24px 24px}.tang-approval-document-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:0 2px 12px;border-bottom:1px solid #6d5e4259}.tang-approval-document-head span{color:#6dbfba;font:700 7px/1 monospace;letter-spacing:.17em}.tang-approval-document-head b{color:#bda576;font:620 11px/1 "Songti SC",serif;letter-spacing:.12em}.tang-approval-markdown{--dsw-alias-label-primary:#c7d0c9;--dsw-alias-label-secondary:#91a39d;--dsw-alias-label-caption:#71857f;--dsw-alias-border-l2:#4d615b;--dsw-alias-state-business-primary:#72c9c1;--dsw-alias-bg-base:#081416;--dsw-alias-markdown-code-block:#091719;--dsw-alias-markdown-code-block-banner:#14272a;--dsw-alias-markdown-inline-code:#17282a;color-scheme:dark;flex:1;min-height:0;overflow:auto;padding:16px 4px 22px;color:#c7cdc5;font-size:12px;line-height:1.7;scrollbar-color:#745f3f #0b1619}.tang-approval-markdown h1,.tang-approval-markdown h2,.tang-approval-markdown h3{color:#eadfc9;font-family:"Songti SC",serif;letter-spacing:.035em}.tang-approval-markdown h1{font-size:22px}.tang-approval-markdown h2{margin-top:24px;padding-bottom:7px;border-bottom:1px solid #65563d66;font-size:17px}.tang-approval-markdown h3{font-size:14px}.tang-approval-markdown p,.tang-approval-markdown li,.tang-approval-markdown td{color:#bac5bd}.tang-approval-markdown strong{color:#e5c98f}.tang-approval-markdown a{color:#72c9c1}.tang-approval-markdown :not(pre)>code{color:#d9bd83!important;background:#17282a!important}.tang-approval-markdown pre,.tang-approval-markdown pre code{color:#c9d4cd!important;background:#091719!important}.tang-approval-markdown blockquote{margin-left:0;border-left-color:#b45a4b;background:#1d1918;padding:8px 12px}.tang-approval-markdown table{color:#bac5bd;border-color:#43564f;font-size:11px}.tang-approval-markdown th{color:#ddc38d;background:#17282a}.tang-approval-markdown td{border-color:#43564f;background:#0c191b80}.tang-approval-dialog[data-review-kind="closure"]:before{background:linear-gradient(90deg,#5bc1ba 0 34%,#d0a75e 34% 76%,#75c79f 76%)}.tang-approval-dialog[data-review-kind="closure"] .tang-approval-seal{border-color:#4f917d;background:#13251f}.tang-approval-dialog[data-review-kind="closure"] .tang-approval-seal span{color:#83d4b1}
.tang-closure-options{display:grid;gap:7px;margin-top:18px}.tang-closure-options>span{color:#b8996d;font:700 8px/1 monospace;letter-spacing:.12em}.tang-closure-options button{display:block;width:100%;border:1px solid #74604d5c;border-radius:11px;background:#101f22;color:#d6d1c5;padding:8px 9px;text-align:left;cursor:pointer}.tang-closure-options button.selected{border-color:#5aa18f;background:#17302e;box-shadow:0 0 14px #4f9b8b20}.tang-closure-options b{display:block;font-size:9px}.tang-closure-options small{display:block;margin-top:4px;color:#80928d;font-size:8px;line-height:1.4}.tang-review-shortcuts{display:flex;flex-wrap:wrap;gap:8px}.tang-review-shortcuts button{border-color:#6b91866b;background:#142a29;color:#9fd2bf}
.tang-approval-guide{min-height:0;display:flex;flex-direction:column;overflow:hidden}.tang-approval-guide>.tang-approval-code,.tang-approval-guide>h3,.tang-approval-guide>ol,.tang-approval-guide>.tang-approval-rule{flex:none}.tang-closure-options{flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding-right:5px;scrollbar-color:#795f43 #0b171a;scrollbar-width:thin}.tang-closure-options>span{position:sticky;z-index:1;top:0;padding:3px 0 7px;background:#0b171a}
.tang-approval-footer{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:end;gap:18px;padding:16px 22px 18px;border-top:1px solid #9c69493d;background:#0c171af5}.tang-approval-feedback{display:block}.tang-approval-feedback>span{display:block;margin-bottom:7px;color:#b98263;font:600 9px/1 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.1em}.tang-approval-feedback small{margin-left:7px;color:#8d6c61;font-weight:500;letter-spacing:.04em}.tang-approval-feedback textarea{box-sizing:border-box;width:100%;height:68px;resize:vertical;border:1px solid #8c654b55;border-radius:14px;background:#101f22;color:#d7d3c9;padding:10px 12px;font:500 11px/1.5 "PingFang SC","Microsoft YaHei",sans-serif}.tang-approval-feedback textarea:focus{outline:2px solid #b8775533;border-color:#ad765c}.tang-approval-feedback textarea::placeholder{color:#61736f}.tang-approval-actions{min-width:360px}.tang-approval-error{min-height:14px;margin-bottom:7px;color:#df796c;font-size:9px;text-align:right}.tang-approval-buttons{display:flex;justify-content:flex-end;gap:8px}.tang-approval-buttons button{min-height:38px;border-radius:12px;padding:0 14px;font:600 10px/1 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.04em;cursor:pointer}.tang-approval-buttons .cancel{border:1px solid #743f3b;background:#241718;color:#d07c72}.tang-approval-buttons .remand{border:1px solid #8b734d;background:#251f17;color:#d8b977}.tang-approval-buttons .approve{min-width:110px;border:1px solid #4f9183;background:linear-gradient(135deg,#285b53,#173e3a);color:#b9eee0;box-shadow:0 0 15px #4b9c8a22}.tang-approval-buttons button:hover:not(:disabled){filter:brightness(1.16)}.tang-approval-buttons button:disabled{cursor:not-allowed;opacity:.42}
.tang-clarification-backdrop{position:fixed;z-index:770;inset:0;display:grid;place-items:center;padding:24px;background:#02090be6;backdrop-filter:blur(9px)}.tang-clarification-dialog{width:min(720px,calc(100vw - 32px));max-height:min(720px,calc(100vh - 32px));overflow:auto;border:1px solid #a36c4f70;border-radius:26px;background:radial-gradient(circle at 8% 0%,#29515980,transparent 34%),linear-gradient(145deg,#112226,#081416 70%,#171715);color:#ddd8cc;box-shadow:0 34px 110px #000,inset 0 0 60px #00151988}.tang-clarification-header{display:flex;justify-content:space-between;gap:20px;padding:23px 25px 18px;border-bottom:1px solid #95644842}.tang-clarification-kicker{color:#bd7d5e;font:600 9px/1 "PingFang SC","Microsoft YaHei",sans-serif;letter-spacing:.16em}.tang-clarification-header h2{margin:8px 0 5px;color:#f0e4cf;font:500 24px/1.15 "FZShuTi","STLiti","LiSu","KaiTi",serif;letter-spacing:.1em}.tang-clarification-header p{margin:0;color:#91a5a1;font-size:11px}.tang-clarification-progress{flex:none;color:#72c1ba;font:700 10px/1 monospace}.tang-clarification-body{padding:23px 25px}.tang-clarification-label{color:#b8996d;font:700 9px/1 monospace;letter-spacing:.14em}.tang-clarification-question{margin:10px 0 7px;color:#eee2ce;font:600 18px/1.4 "Songti SC",serif}.tang-clarification-detail{margin:0 0 17px;color:#93a5a0;font-size:11px;line-height:1.6}.tang-clarification-options{display:grid;gap:9px}.tang-clarification-option{display:grid;grid-template-columns:18px minmax(0,1fr);gap:10px;width:100%;padding:12px 13px;border:1px solid #75634f66;border-radius:15px;background:#101f22;color:#d8d5cb;text-align:left;cursor:pointer}.tang-clarification-option:hover{border-color:#a57458;background:#15272a}.tang-clarification-option.selected{border-color:#65a99e;background:#17302f;box-shadow:0 0 16px #4d9a8c20}.tang-clarification-option i{width:12px;height:12px;margin-top:2px;border:1px solid #88735e;border-radius:50%;box-shadow:inset 0 0 0 3px #101f22}.tang-clarification-option.selected i{border-color:#7bc2b5;background:#7bc2b5}.tang-clarification-option b{display:block;color:#e8ddca;font-size:12px}.tang-clarification-option small{display:block;margin-top:4px;color:#899b96;font-size:10px;line-height:1.45}.tang-clarification-custom{display:block;margin-top:13px}.tang-clarification-custom span{display:block;margin-bottom:6px;color:#a98269;font-size:9px}.tang-clarification-custom textarea{box-sizing:border-box;width:100%;min-height:66px;resize:vertical;border:1px solid #755f4d66;border-radius:14px;background:#0d1c1f;color:#ddd8cc;padding:10px 12px;font:500 11px/1.5 "PingFang SC","Microsoft YaHei",sans-serif}.tang-clarification-footer{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 25px 20px;border-top:1px solid #95644842}.tang-clarification-error{color:#df796c;font-size:9px}.tang-clarification-actions{display:flex;gap:8px}.tang-clarification-actions button{min-height:38px;border:1px solid #765d4b;border-radius:12px;background:#172427;color:#cec8bb;padding:0 14px;font:600 10px/1 "PingFang SC","Microsoft YaHei",sans-serif;cursor:pointer}.tang-clarification-actions .submit{border-color:#4f9183;background:linear-gradient(135deg,#285b53,#173e3a);color:#b9eee0}.tang-clarification-actions button:disabled{cursor:not-allowed;opacity:.42}
@media(max-width:760px){.tang-approval-dialog{height:calc(100vh - 20px)}.tang-approval-header{padding:20px 18px 16px}.tang-approval-header h2{font-size:21px}.tang-approval-seal{width:62px}.tang-approval-layout{display:block;overflow:auto}.tang-approval-guide{padding:13px 16px;border-right:0;border-bottom:1px solid #75623f59}.tang-approval-guide h3,.tang-approval-guide ol{display:none}.tang-approval-rule{margin-top:9px}.tang-approval-document{height:50vh;padding:15px 16px}.tang-approval-footer{grid-template-columns:1fr;padding:13px 16px 16px}.tang-approval-actions{min-width:0}.tang-approval-buttons{display:grid;grid-template-columns:1fr 1fr}.tang-approval-buttons .approve{grid-column:1/-1;grid-row:1}.tang-approval-error{text-align:left}}
@media(max-width:760px){.tang-approval-guide{overflow:visible}.tang-closure-options{flex:none;max-height:min(38vh,300px);overflow-y:auto}.tang-closure-options>span{background:#0b171a}}
`

function statusLabel(status: TangStatus | 'idle'): string {
  const labels: Record<TangStatus | 'idle', string> = {
    idle: '未启用', pending: '待处理', running: '执行中', waiting_input: '待确认', waiting_approval: '待审批', succeeded: '已完成',
    passed: '已完成', remanded: '已驳回', failed: '执行失败', stopped: '已终止', skipped: '已跳过',
  }
  return labels[status]
}

function reviewStatusLabel(kind: TangReviewRecord['kind'], status: TangReviewRecord['status']): string {
  if (status === 'waiting') return kind === 'approval' ? '等待会签' : '等待结案'
  const labels: Record<Exclude<TangReviewRecord['status'], 'waiting'>, string> = {
    approved: '会签已通过', closed: '已结案', followup: '结案前跟进', remanded: '已驳回', failed: '提交失败',
  }
  return labels[status]
}

function reviewSealLabel(kind: TangReviewRecord['kind'], status: TangReviewRecord['status']): string {
  if (status === 'waiting') return kind === 'approval' ? '待会签' : '待结案'
  const labels: Record<Exclude<TangReviewRecord['status'], 'waiting'>, string> = {
    approved: '已通过', closed: '已结案', followup: '待跟进', remanded: '已驳回', failed: '失败',
  }
  return labels[status]
}

function reviewTangStatus(status: TangReviewRecord['status']): TangStatus {
  if (status === 'waiting') return 'waiting_approval'
  if (status === 'approved' || status === 'closed') return 'passed'
  if (status === 'followup') return 'waiting_input'
  if (status === 'remanded') return 'remanded'
  return 'failed'
}

function reviewKindForStage(stage: TangStage): TangReviewRecord['kind'] | undefined {
  if (stage === 'countersign' || stage === 'user-approval') return 'approval'
  if (stage === 'zhongshu-report' || stage === 'case-closure' || stage === 'chronicle') return 'closure'
  return undefined
}

function phaseStatusLabel(stage: TangStage, status: TangStatus): string {
  if (status === 'waiting_input' && stage === 'requirement-clarification') return '待补充需求'
  if (status === 'waiting_approval' && (stage === 'countersign' || stage === 'user-approval')) return '等待会签'
  if (status === 'waiting_approval' && stage === 'case-closure') return '等待结案'
  return statusLabel(status)
}

function completedStageLabel(stage: TangStage): string {
  const labels: Record<TangStage, string> = {
    intake: '已受理',
    'requirement-clarification': '已澄清',
    'zhongshu-draft': '已起草',
    'menxia-review': '已审议',
    countersign: '已会签',
    'user-approval': '已批准',
    'shangshu-dispatch': '已领旨',
    'ministry-execution': '已执行',
    'menxia-acceptance': '已验收',
    'zhongshu-report': '已奏报',
    'case-closure': '已结案',
    chronicle: '已归档',
  }
  return labels[stage]
}

function displayedRecordStatus(status: TangStatus, hasLaterStage: boolean): TangStatus {
  if (!hasLaterStage) return status
  return status === 'pending' || status === 'running' || status === 'waiting_input' || status === 'waiting_approval'
    ? 'succeeded'
    : status
}

function displayedRecordStatusLabel(stage: TangStage, status: TangStatus): string {
  if (status === 'succeeded' || status === 'passed') return completedStageLabel(stage)
  return phaseStatusLabel(stage, status)
}

interface TangClarification {
  readonly wait: QuestionWait
  readonly questions: readonly QuestionItem[]
}

interface TangClarificationDraft {
  readonly selected: readonly string[]
  readonly custom: string
}

function stageLabel(stage: TangStage): string {
  const labels: Record<TangStage, string> = {
    intake: '受理需求', 'requirement-clarification': '需求澄清', 'zhongshu-draft': '中书起草', 'menxia-review': '门下审议',
    countersign: '两省会签', 'user-approval': '用户审批', 'shangshu-dispatch': '尚书领旨',
    'ministry-execution': '六部执行', 'menxia-acceptance': '门下验收',
    'zhongshu-report': '中书奏报', 'case-closure': '用户结案', chronicle: '史官归档',
  }
  return labels[stage]
}

function formatRecordTime(time: number): string {
  if (!Number.isFinite(time)) return ''
  return new Date(time).toLocaleTimeString('zh-CN', {
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  })
}

const OFFICE_CARD_SUMMARIES: Readonly<Record<TangOffice, string>> = {
  zhongshu: '需求与方案',
  menxia: '审议与验收',
  shangshu: '统筹与调度',
  personnel: '仓库与模块',
  revenue: '数据与性能',
  rites: '契约与体验',
  war: '功能与代码',
  justice: '质量与安全',
  works: '构建与发布',
}

const OFFICE_ORNAMENT_PATHS: Readonly<Record<TangOffice, readonly string[]>> = {
  zhongshu: [
    'M7 42c2-7 8-11 15-11 0-8 6-13 13-13 5-5 14-3 16 4 7-1 13 4 13 11s-6 12-13 11c-5 7-15 11-25 8-9-1-15-5-19-10Zm21 2c0-7 5-12 12-12 6 0 10 4 10 9s-4 9-9 9c-4 0-7-3-7-6 0-3 2-5 5-5 2 0 4 2 4 4 0 2-2 4-4 4-4 0-7-3-7-7Z',
    'M8 42c14 6 30 6 49-6-10 14-28 21-44 13Z',
  ],
  menxia: [
    'M25 9h14l-2 9 7 8-12 9-12-9 7-8Z',
    'M7 18h18l7 8-6 7H13l-6-7Zm50 0H39l-7 8 6 7h13l6-7Z',
    'M8 31c5-6 15-7 21 0-3 9-16 12-21 5Zm7 0c3-2 7-2 10 0-2 4-8 5-10 0Z',
    'M56 31c-5-6-15-7-21 0 3 9 16 12 21 5Zm-7 0c-3-2-7-2-10 0 2 4 8 5 10 0Z',
    'M21 39l11-7 11 7 8-3-5 16-10-4-4 8-4-8-10 4-10-16Z',
  ],
  shangshu: [
    'M32 7c7 5 9 14 0 21-9-6-8-16 0-21Z',
    'M37 29c2-10 10-15 19-12 0 9-7 15-19 12Z',
    'M37 35c11-3 19 2 19 12-9 3-17-2-19-12Z',
    'M32 37c8 6 7 16 0 21-8-5-8-15 0-21Z',
    'M27 35c-2 10-10 15-19 12 0-10 8-15 19-12Z',
    'M27 29c-11 3-18-3-19-12 9-3 17 2 19 12Z',
    'M32 26a6 6 0 1 1 0 12 6 6 0 0 1 0-12Z',
  ],
  personnel: [
    'M8 32h48',
    'M16 32a5 5 0 1 0 10 0 5 5 0 0 0-10 0ZM27 32a5 5 0 1 0 10 0 5 5 0 0 0-10 0ZM38 32a5 5 0 1 0 10 0 5 5 0 0 0-10 0Z',
  ],
  revenue: [
    'M32 9a23 23 0 1 1 0 46 23 23 0 0 1 0-46ZM32 17a15 15 0 1 1 0 30 15 15 0 0 1 0-30Z',
    'M25 25h14v14H25Z',
  ],
  rites: [
    'M8 17h21v11H18v19h29V35H36V17h20',
    'M13 12v10M51 12v10M13 42v10M51 42v10',
  ],
  war: [
    'M8 17l12-8 12 8 12-8 12 8M8 33l12-8 12 8 12-8 12 8M8 49l12-8 12 8 12-8 12 8',
    'M20 9v48M44 9v48',
  ],
  justice: [
    'M8 32l15-15 15 15-15 15ZM26 32l15-15 15 15-15 15Z',
    'M32 11v42',
  ],
  works: [
    'M11 11h42v42H11ZM11 25h42M11 39h42M25 11v42M39 11v42',
    'M18 18h28v28H18Z',
  ],
}

interface TangFilledOrnament {
  readonly source: string
  readonly viewBox: string
  readonly width: number
  readonly height: number
}

const FILLED_OFFICE_ORNAMENTS: Readonly<Partial<Record<TangOffice, TangFilledOrnament>>> = {
  zhongshu: { source: CLOUD_ORNAMENT_SOURCE, viewBox: '0 0 517.48 265.65', width: 517.48, height: 265.65 },
  menxia: { source: TAOTIE_ORNAMENT_SOURCE, viewBox: '0 0 325.06 178.14', width: 325.06, height: 178.14 },
  shangshu: { source: BAOXIANG_ORNAMENT_SOURCE, viewBox: '0 0 167.79 167.57', width: 167.79, height: 167.57 },
}

function ornamentMaskMarkup(source: string): string {
  const svgStart = source.indexOf('>')
  const svgEnd = source.lastIndexOf('</svg>')
  if (svgStart < 0 || svgEnd < 0) return ''
  return source
    .slice(svgStart + 1, svgEnd)
    .replace(/<defs>[\s\S]*?<\/defs>/g, '')
    .replace(/\sclass="cls-1"/g, ' fill="#000"')
}

function TangOfficeOrnament({ office, className }: { readonly office: TangOffice, readonly className: string }) {
  const maskId = `tang-ornament-${useId().replace(/:/g, '')}`
  const filled = FILLED_OFFICE_ORNAMENTS[office]
  if (filled !== undefined) {
    const cropBottom = office === 'shangshu'
    return (
      <span
        className={className}
        aria-hidden="true"
        data-filled-ornament=""
        data-ornament-office={office}
        {...(cropBottom ? { 'data-crop-bottom': '' } : {})}
      >
        <svg className="tang-filled-ornament-art" viewBox={filled.viewBox} preserveAspectRatio="xMinYMin meet" focusable="false">
          <defs>
            <mask id={maskId} maskUnits="userSpaceOnUse" x="0" y="0" width={filled.width} height={filled.height}>
              <g fill="#fff" dangerouslySetInnerHTML={{ __html: ornamentMaskMarkup(filled.source) }} />
            </mask>
          </defs>
          <rect width={filled.width} height={filled.height} fill="currentColor" mask={`url(#${maskId})`} />
        </svg>
      </span>
    )
  }
  return (
    <svg className={className} viewBox="0 0 64 64" aria-hidden="true" focusable="false" data-ornament-office={office}>
      {OFFICE_ORNAMENT_PATHS[office].map((path, index) => (
        <path key={index} d={path} fillRule="evenodd" clipRule="evenodd" />
      ))}
    </svg>
  )
}

function officeFromLabel(label: string | undefined): TangOffice | undefined {
  if (label === undefined) return undefined
  return TANG_OFFICE_DEFINITIONS.find(office => label.includes(`[${office.name}]`))?.id
}

function tangCaseReviewOf(pending: readonly PendingInteraction[]): TangCaseReview | undefined {
  for (const wait of pending) {
    if (wait.kind !== 'question') continue
    for (const question of wait.payload.questions) {
      if (question.detail === undefined) continue
      if (question.id === TANG_APPROVAL_QUESTION_ID
        && question.intent?.kind === 'plan-review'
        && question.intent.approve === TANG_APPROVE_LABEL) {
        return { kind: 'approval', wait, question }
      }
      if (question.id === TANG_CLOSURE_QUESTION_ID
        && question.options?.some(option => option.label === TANG_CLOSE_LABEL) === true) {
        return { kind: 'closure', wait, question }
      }
    }
  }
  return undefined
}

function tangClarificationOf(pending: readonly PendingInteraction[]): TangClarification | undefined {
  for (const wait of pending) {
    if (wait.kind !== 'question' || wait.payload.questions.length === 0) continue
    if (wait.payload.questions.every(question => question.id.startsWith(TANG_CLARIFICATION_QUESTION_PREFIX))) {
      return { wait, questions: wait.payload.questions }
    }
  }
  return undefined
}

function locatedChildren(
  catalogs: SessionListState['subagentsByParent'],
  rootSessionId: SessionId,
): LocatedChild[] {
  const found: LocatedChild[] = []
  const visited = new Set<SessionId>()
  const visit = (parentSessionId: SessionId, depth: number): void => {
    if (visited.has(parentSessionId)) return
    visited.add(parentSessionId)
    const catalog = catalogs[parentSessionId]
    if (catalog === undefined) return
    for (const entry of catalog.entries) {
      if (entry.kind !== 'child') continue
      found.push({ entry, parentSessionId, depth })
      visit(entry.id, depth + 1)
    }
  }
  visit(rootSessionId, 0)
  return found
}

function formatTokens(value: number): string {
  if (value < 1_000) return String(value)
  if (value < 1_000_000) return `${(value / 1_000).toFixed(value < 10_000 ? 1 : 0)}K`
  return `${(value / 1_000_000).toFixed(value < 10_000_000 ? 1 : 0)}M`
}

function traceInputTokens(trace: TangDepartmentTrace): number {
  return trace.usage.uncachedInputTokens + trace.usage.cacheReadTokens + trace.usage.cacheWriteTokens
}

function traceTime(time: number | undefined): string {
  if (time === undefined || !Number.isFinite(time) || time <= 0) return '等待日志'
  return new Intl.DateTimeFormat('zh-CN', {
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(time)
}

function TangCourt({
  sessionId, useSession, useSessions, openChild, refresh, setCatalogOpen, stopTask, routeSettings, loadModels,
  loadTraces, initialOpen,
}: TangCourtProps) {
  const summary = useSessions(state => state.byId[sessionId])
  const preset = summary?.agentPreset
  const catalogs = useSessions(state => state.subagentsByParent)
  const blank = useSession(snapshot => snapshot.blank)
  const timeline = useSession(snapshot => snapshot.views.get('tang-governance')) ?? EMPTY_TIMELINE
  const pendingInteractions = useSession(snapshot => snapshot.pending)
  const isRoot = summary?.origin !== 'subagent'
  const [open, setOpen] = useState(initialOpen ?? isRoot)
  const [selected, setSelected] = useState<TangOffice | null>(null)
  const [stopping, setStopping] = useState(false)
  const [catalog, setCatalog] = useState<TangModelCatalog | null>(null)
  const [catalogError, setCatalogError] = useState<string | null>(null)
  const [savingOffice, setSavingOffice] = useState<TangDepartment | null>(null)
  const [routeError, setRouteError] = useState<Partial<Record<TangDepartment, string>>>({})
  const [traces, setTraces] = useState<readonly TangDepartmentTrace[]>([])
  const traceCacheRef = useRef(new Map<string, TangDepartmentTrace>())
  const traceActivityRef = useRef(new Map<string, LocatedChild['entry']['activity']>())
  const [traceUnavailable, setTraceUnavailable] = useState(0)
  const [approvalFeedback, setApprovalFeedback] = useState('')
  const [reviewPanel, setReviewPanel] = useState<TangReviewRecord['kind'] | null>(null)
  const [reviewChoice, setReviewChoice] = useState('')
  const [approvalBusy, setApprovalBusy] = useState(false)
  const [approvalError, setApprovalError] = useState<string | null>(null)
  const [clarificationIndex, setClarificationIndex] = useState(0)
  const [clarificationDrafts, setClarificationDrafts] = useState<Record<string, TangClarificationDraft>>({})
  const [clarificationBusy, setClarificationBusy] = useState(false)
  const [clarificationError, setClarificationError] = useState<string | null>(null)
  const [collapsedTraceIds, setCollapsedTraceIds] = useState<ReadonlySet<string>>(() => new Set())
  const [expandedTraceRow, setExpandedTraceRow] = useState<string | null>(null)
  const [courtLeft, setCourtLeft] = useState<number>()
  const triggerRef = useRef<HTMLButtonElement>(null)
  const routes = useSyncExternalStore(
    listener => routeSettings.subscribe(listener),
    () => routeSettings.getSnapshot(),
  )

  useLayoutEffect(() => {
    if (!open) return
    const hostHeader = triggerRef.current?.closest('header')
    if (hostHeader === null || hostHeader === undefined) return
    const alignToHost = () => { setCourtLeft(Math.max(0, Math.round(hostHeader.getBoundingClientRect().left))) }
    alignToHost()
    const observer = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(alignToHost)
    observer?.observe(hostHeader)
    window.addEventListener('resize', alignToHost)
    return () => {
      observer?.disconnect()
      window.removeEventListener('resize', alignToHost)
    }
  }, [open])

  const children = useMemo(() => locatedChildren(catalogs, sessionId), [catalogs, sessionId])
  const byOffice = useMemo(() => {
    const map = new Map<TangOffice, LocatedChild>()
    for (const child of children) {
      const office = officeFromLabel(child.entry.label)
      if (office !== undefined) map.set(office, child)
    }
    return map
  }, [children])
  const modelChoices = useMemo(() => catalog?.groups.flatMap(group => group.models.map(model => ({
    key: JSON.stringify([group.id, model.id]),
    provider: group.id,
    providerName: group.name,
    model,
  }))) ?? [], [catalog])
  const orderedTraces = useMemo(() => orderDepartmentTraces(traces), [traces])
  const chronologicalSegments = useMemo(() => projectTraceTimeline(traces), [traces])
  const timelineSegments = useMemo(() => groupTimelineByDepartment(chronologicalSegments), [chronologicalSegments])
  const nestedMinistryKeys = useMemo(() => new Set(timelineSegments.flatMap((segment, index) => (
    segment.trace.office === 'shangshu'
      ? shangshuExecutionSegments(timelineSegments, index).map(child => child.key)
      : []
  ))), [timelineSegments])
  const runningOffices = useMemo(() => new Set(children.flatMap((child): TangOffice[] => {
    if (child.entry.activity !== 'running') return []
    const office = officeFromLabel(child.entry.label)
    return office === undefined ? [] : [office]
  })), [children])
  const runningTraceIds = useMemo(() => new Set<string>(children.flatMap(child => (
    child.entry.activity === 'running' ? [child.entry.id] : []
  ))), [children])
  const hasRunningMinistry = TANG_OFFICE_DEFINITIONS.some(definition => (
    definition.tier === 'ministry' && runningOffices.has(definition.id)
  ))
  const caseReview = useMemo(() => tangCaseReviewOf(pendingInteractions), [pendingInteractions])
  const clarification = useMemo(() => tangClarificationOf(pendingInteractions), [pendingInteractions])
  const traceChildrenKey = children.map(child => [
    child.parentSessionId, child.entry.id, child.entry.activity, child.depth,
  ].join(':')).join('|')

  useEffect(() => {
    if (preset !== 'tang' || !open) return
    const parents = new Set<SessionId>([sessionId, ...children.map(child => child.entry.id)])
    for (const parent of parents) {
      setCatalogOpen(parent, true)
      refresh(parent)
    }
    const timer = setInterval(() => {
      for (const parent of parents) refresh(parent)
    }, 3_000)
    return () => {
      clearInterval(timer)
      for (const parent of parents) setCatalogOpen(parent, false)
    }
  }, [preset, open, sessionId, children, refresh, setCatalogOpen])

  useEffect(() => {
    if (preset !== 'tang' || !open) return
    let active = true
    setCatalogError(null)
    void loadModels(sessionId).then(
      value => { if (active) setCatalog(value) },
      error => {
        if (!active) return
        setCatalogError(error instanceof Error ? error.message : String(error))
      },
    )
    return () => { active = false }
  }, [preset, open, sessionId, loadModels])

  useEffect(() => {
    if (preset !== 'tang' || !open) return
    let active = true
    let timer: ReturnType<typeof setTimeout> | undefined
    const fallback = (child: LocatedChild): TangDepartmentTrace | undefined => {
      const office = officeFromLabel(child.entry.label)
      if (office === undefined) return undefined
      return buildDepartmentTrace({
        sessionId: child.entry.id,
        office,
        ...(child.entry.label === undefined ? {} : { label: child.entry.label }),
        depth: child.depth,
        activity: child.entry.activity,
        events: [],
      })
    }
    const childIds = new Set<string>(children.map(child => child.entry.id))
    for (const id of traceCacheRef.current.keys()) {
      if (!childIds.has(id)) traceCacheRef.current.delete(id)
    }
    for (const id of traceActivityRef.current.keys()) {
      if (!childIds.has(id)) traceActivityRef.current.delete(id)
    }
    const refreshIds = new Set<string>()
    for (const child of children) {
      const previousActivity = traceActivityRef.current.get(child.entry.id)
      if (previousActivity !== child.entry.activity) refreshIds.add(child.entry.id)
      traceActivityRef.current.set(child.entry.id, child.entry.activity)
      if (traceCacheRef.current.has(child.entry.id)) continue
      const initial = fallback(child)
      if (initial !== undefined) traceCacheRef.current.set(child.entry.id, initial)
    }
    const publish = (): void => {
      setTraces(children.flatMap(child => {
        const trace = traceCacheRef.current.get(child.entry.id)
        return trace === undefined ? [] : [trace]
      }))
    }
    publish()
    const pull = async (): Promise<void> => {
      const targets = children.filter((child) => {
        const cached = traceCacheRef.current.get(child.entry.id)
        return child.entry.activity === 'running'
          || refreshIds.has(child.entry.id)
          || cached === undefined
          || cached.status === 'pending'
          || cached.status === 'running'
      })
      if (targets.length === 0) {
        setTraceUnavailable(0)
        return
      }
      const loaded = await loadTraces(targets)
      if (!active) return
      const unavailable = new Set(loaded.unavailableIds)
      for (const entry of loaded.entries) {
        const cached = traceCacheRef.current.get(entry.sessionId)
        if (unavailable.has(entry.sessionId) && cached !== undefined) continue
        traceCacheRef.current.set(entry.sessionId, entry)
        refreshIds.delete(entry.sessionId)
      }
      publish()
      setTraceUnavailable(unavailable.size)
      const hasRunning = children.some(child => child.entry.activity === 'running')
      if (hasRunning || unavailable.size > 0) {
        timer = setTimeout(() => { void pull() }, hasRunning ? 1_000 : 2_500)
      }
    }
    void pull()
    return () => {
      active = false
      if (timer !== undefined) clearTimeout(timer)
    }
  }, [preset, open, traceChildrenKey, loadTraces])

  useEffect(() => {
    if (caseReview === undefined) return
    setOpen(true)
    setReviewPanel(caseReview.kind)
    setReviewChoice(caseReview.kind === 'approval' ? TANG_APPROVE_LABEL : TANG_CLOSE_LABEL)
    setApprovalFeedback('')
    setApprovalBusy(false)
    setApprovalError(null)
  }, [caseReview?.wait.key])

  useEffect(() => {
    if (clarification === undefined) return
    setOpen(true)
    setClarificationIndex(0)
    setClarificationDrafts(Object.fromEntries(clarification.questions.map(question => [
      question.id,
      { selected: [], custom: '' },
    ])))
    setClarificationBusy(false)
    setClarificationError(null)
  }, [clarification?.wait.key])

  if (preset !== 'tang') return null

  const latestForOffice = (office: TangOffice): TangTimelineEntry | undefined => timeline.entries.findLast(entry => entry.office === office)
  const statusForOffice = (office: TangOffice): TangStatus | 'idle' => {
    const child = byOffice.get(office)
    const latest = latestForOffice(office)
    const currentReview = timeline.reviews.at(-1)
    if (caseReview?.kind === 'closure' && office === 'zhongshu') return 'waiting_approval'
    if (caseReview?.kind === 'approval' && (office === 'zhongshu' || office === 'menxia')) return 'waiting_approval'
    if (currentReview?.status === 'waiting'
      && (office === 'zhongshu' || (currentReview.kind === 'approval' && office === 'menxia'))) return 'waiting_approval'
    if (currentReview?.status === 'followup' && office === 'zhongshu') return 'waiting_input'
    const trace = orderedTraces.findLast(entry => entry.office === office)
    if (runningOffices.has(office) || (office === 'shangshu' && hasRunningMinistry)) return 'running'
    if (latest?.status === 'stopped' || latest?.status === 'failed' || latest?.status === 'remanded') return latest.status
    const recorded = [
      ...(latest === undefined ? [] : [{ status: latest.status, time: latest.time }]),
      ...(trace === undefined ? [] : [{ status: trace.status, time: trace.updatedAt ?? trace.startedAt ?? 0 }]),
    ].sort((left, right) => right.time - left.time)[0]
    if (recorded !== undefined && recorded.status !== 'pending' && recorded.status !== 'running') return recorded.status
    return recorded?.status
      ?? (child === undefined ? 'idle' : 'pending')
  }
  const traceTokens = orderedTraces.reduce((total, trace) => total + traceTokenTotal(trace.usage), 0)
  const selectedDefinition = selected === null ? undefined : TANG_OFFICE_DEFINITIONS.find(office => office.id === selected)
  const selectedChild = selected === null ? undefined : byOffice.get(selected)
  const selectedIsMinistry = selected !== null && !TANG_DEPARTMENTS.some(office => office === selected)
  const selectedEvents = selected === null ? [] : timeline.entries.filter(entry => entry.office === selected)
  const selectedStageEvents = [...selectedEvents.reduce((latest, event) => {
    const previous = latest.get(event.stage)
    if (previous === undefined || event.time >= previous.time) latest.set(event.stage, event)
    return latest
  }, new Map<TangStage, TangTimelineEntry>()).values()]
  const coordinatorRecords: readonly TangDialogRecord[] = (selectedIsMinistry ? selectedEvents : selectedStageEvents)
    .map((event): TangDialogRecord => ({
      key: `event:${event.key}`,
      time: event.time,
      stage: event.stage,
      title: event.title,
      summary: event.summary,
      status: event.status,
    }))
    .sort((left, right) => left.time - right.time)
  const selectedRecords = selectedIsMinistry && selected !== null
    ? projectMinistryDialogRecords(selected, traces, coordinatorRecords)
    : coordinatorRecords
  const activeClarificationQuestion = clarification?.questions[clarificationIndex]
  const archivedReview = reviewPanel === null
    ? undefined
    : timeline.reviews.findLast(review => review.kind === reviewPanel)
  const displayedReview = reviewPanel === null
    ? undefined
    : caseReview?.kind === reviewPanel
      ? {
          kind: caseReview.kind,
          caseId: timeline.entries.at(-1)?.caseId ?? '当前案卷',
          title: caseReview.question.question,
          detail: caseReview.question.detail ?? '',
          options: caseReview.question.options ?? [],
          status: 'waiting' as const,
          pending: true as const,
        }
      : archivedReview === undefined ? undefined : { ...archivedReview, pending: false as const }

  const officeStatusLabel = (office: TangOffice, status: TangStatus | 'idle'): string => {
    if (status === 'waiting_input' && office === 'zhongshu' && timeline.reviews.at(-1)?.status === 'followup') return '结案前跟进'
    if (status === 'waiting_input' && office === 'zhongshu') return '待补充需求'
    if (status === 'waiting_approval' && caseReview?.kind === 'approval' && (office === 'zhongshu' || office === 'menxia')) return '等待会签'
    if (status === 'waiting_approval' && caseReview?.kind === 'closure' && office === 'zhongshu') return '等待结案'
    return statusLabel(status)
  }

  const toggleTraceCollapsed = (sessionId: string): void => {
    setCollapsedTraceIds(current => {
      const next = new Set(current)
      if (next.has(sessionId)) next.delete(sessionId)
      else next.add(sessionId)
      return next
    })
  }

  const toggleTraceRow = (key: string): void => {
    setExpandedTraceRow(current => current === key ? null : key)
  }

  const saveRoute = async (office: TangDepartment, route: TangOfficeRoute | undefined): Promise<void> => {
    setSavingOffice(office)
    setRouteError(current => ({ ...current, [office]: undefined }))
    try {
      if (route === undefined) await routeSettings.unset(office)
      else await routeSettings.set(office, route)
    } catch (error) {
      setRouteError(current => ({
        ...current,
        [office]: error instanceof Error ? error.message : String(error),
      }))
    } finally {
      setSavingOffice(current => current === office ? null : current)
    }
  }

  const departmentControls = (office: TangDepartment) => {
    const route = routes.value?.[office]
    const explicitChoice = route?.provider === undefined || route.model === undefined
      ? undefined
      : modelChoices.find(choice => choice.provider === route.provider && choice.model.id === route.model)
    const inheritedChoice = catalog === null
      ? undefined
      : modelChoices.find(choice => choice.provider === catalog.current.provider && choice.model.id === catalog.current.model)
    const effectiveChoice = explicitChoice ?? inheritedChoice
    const modelValue = explicitChoice?.key ?? (route?.provider !== undefined && route.model !== undefined ? '__custom__' : '__inherit__')
    const reasoning = effectiveChoice?.model.reasoning
    const reasoningValue = route?.reasoningEffort ?? '__default__'
    const busy = savingOffice === office
    const disabled = busy || catalog === null || routes.status !== 'ready' || !routes.writable
    return (
      <div className="tang-route-controls" aria-label={`${TANG_OFFICE_DEFINITIONS.find(item => item.id === office)?.name ?? office}模型路由`}>
        <label className="tang-route-field model">
          <select
            aria-label={`${office}模型选择`}
            value={modelValue}
            disabled={disabled}
            onChange={(event) => {
              const key = event.currentTarget.value
              if (key === '__inherit__') {
                void saveRoute(office, undefined)
                return
              }
              const choice = modelChoices.find(item => item.key === key)
              if (choice === undefined) return
              void saveRoute(office, {
                provider: choice.provider,
                model: choice.model.id,
                ...(route?.maxTokens === undefined ? {} : { maxTokens: route.maxTokens }),
              })
            }}
          >
            <option value="__inherit__">继承上级{inheritedChoice === undefined ? '' : ` · ${inheritedChoice.model.name}`}</option>
            {route?.provider !== undefined && route.model !== undefined && explicitChoice === undefined && (
              <option value="__custom__">{route.provider} · {route.model}</option>
            )}
            {catalog?.groups.map(group => (
              <optgroup key={group.id} label={group.name}>
                {modelChoices.filter(choice => choice.provider === group.id).map(choice => (
                  <option key={choice.key} value={choice.key}>{choice.model.name}</option>
                ))}
              </optgroup>
            ))}
          </select>
        </label>
        <label className="tang-route-field effort">
          <select
            aria-label={`${office}思考等级选择`}
            value={reasoningValue}
            disabled={disabled || reasoning === undefined}
            onChange={(event) => {
              const provider = explicitChoice?.provider ?? catalog?.current.provider
              const model = explicitChoice?.model.id ?? catalog?.current.model
              if (provider === undefined || model === undefined) return
              const effort = event.currentTarget.value
              void saveRoute(office, {
                provider,
                model,
                ...(effort === '__default__' ? {} : { reasoningEffort: effort }),
                ...(route?.maxTokens === undefined ? {} : { maxTokens: route.maxTokens }),
              })
            }}
          >
            <option value="__default__">模型默认</option>
            {route?.reasoningEffort !== undefined && reasoning?.efforts.every(effort => effort.id !== route.reasoningEffort) === true && (
              <option value={route.reasoningEffort}>{route.reasoningEffort}</option>
            )}
            {reasoning?.efforts.map(effort => <option key={effort.id} value={effort.id}>{effort.name}</option>)}
          </select>
        </label>
        {(routeError[office] ?? catalogError) !== null && (routeError[office] ?? catalogError) !== undefined && (
          <div className="tang-route-error">{routeError[office] ?? catalogError}</div>
        )}
      </div>
    )
  }

  const card = (office: typeof TANG_OFFICE_DEFINITIONS[number]) => {
    const status = statusForOffice(office.id)
    const department = TANG_DEPARTMENTS.includes(office.id as TangDepartment) ? office.id as TangDepartment : undefined
    return (
        <div key={office.id} className="tang-office-node">
          <article className={`tang-card ${status}`} data-tier={office.tier}>
            <TangOfficeOrnament office={office.id} className="tang-card-ornament" />
            <button type="button" className="tang-card-summary" onClick={() => { setSelected(office.id) }}>
            <span className="tang-card-top">
              <span className="tang-office-title"><span className="tang-name">{office.name}</span></span>
              <span className="tang-status"><span className="tang-dot" /><span>{officeStatusLabel(office.id, status)}</span></span>
            </span>
            <span className="tang-duty">{OFFICE_CARD_SUMMARIES[office.id]}</span>
          </button>
          {department !== undefined && departmentControls(department)}
        </article>
      </div>
    )
  }

  const handleStop = async (): Promise<void> => {
    setStopping(true)
    try {
      await stopTask(sessionId, children.map(child => child.entry.id))
    } finally {
      setStopping(false)
    }
  }

  const respondToCaseReview = async (decision: 'confirm' | 'remand' | 'cancel'): Promise<void> => {
    if (caseReview === undefined || approvalBusy) return
    const feedback = approvalFeedback.trim()
    if (decision === 'remand' && feedback === '') {
      setApprovalError(caseReview.kind === 'approval'
        ? '请先写明需要中书、门下补充或修改的内容。'
        : '请先写明需要补充的交付、验证或结案内容。')
      return
    }
    setApprovalBusy(true)
    setApprovalError(null)
    try {
      const result = decision === 'cancel'
        ? {
          ok: false as const,
          error: { code: 'cancelled' as const, message: `the user cancelled the Tang task during ${caseReview.kind} review`, details: {} },
        }
        : {
          ok: true as const,
          value: {
            sessionId,
            answer: {
              answers: [{
                id: caseReview.question.id,
                selected: decision === 'confirm'
                  ? [caseReview.kind === 'approval' ? TANG_APPROVE_LABEL : reviewChoice || TANG_CLOSE_LABEL]
                  : [],
                ...(decision === 'remand' ? { custom: feedback } : {}),
              }],
            },
          },
        }
      const receipt = await caseReview.wait.respond(result)
      if (!receipt.accepted) throw new Error(`审批回复被拒绝：${receipt.reason}`)
      if (decision === 'cancel') await stopTask(sessionId, children.map(child => child.entry.id))
    } catch (error) {
      setApprovalBusy(false)
      setApprovalError(error instanceof Error ? error.message : String(error))
    }
  }

  const chooseClarificationOption = (question: QuestionItem, label: string): void => {
    setClarificationDrafts(current => {
      const draft = current[question.id] ?? { selected: [], custom: '' }
      const selected = question.multiSelect === true
        ? (draft.selected.includes(label)
            ? draft.selected.filter(value => value !== label)
            : [...draft.selected, label])
        : [label]
      return { ...current, [question.id]: { selected, custom: question.multiSelect === true ? draft.custom : '' } }
    })
  }

  const updateClarificationCustom = (question: QuestionItem, custom: string): void => {
    setClarificationDrafts(current => {
      const draft = current[question.id] ?? { selected: [], custom: '' }
      return {
        ...current,
        [question.id]: {
          selected: question.multiSelect === true ? draft.selected : [],
          custom,
        },
      }
    })
  }

  const respondToClarification = async (cancel: boolean): Promise<void> => {
    if (clarification === undefined || clarificationBusy) return
    const answers = clarification.questions.map((question) => {
      const draft = clarificationDrafts[question.id] ?? { selected: [], custom: '' }
      const custom = draft.custom.trim()
      return {
        id: question.id,
        selected: [...draft.selected],
        ...(custom === '' ? {} : { custom }),
      }
    })
    if (!cancel && answers.some(answer => answer.selected.length === 0 && answer.custom === undefined)) {
      setClarificationError('请完成每个问题，或在“其他方案”中填写你的决定。')
      return
    }
    setClarificationBusy(true)
    setClarificationError(null)
    try {
      const receipt = await clarification.wait.respond(cancel
        ? {
            ok: false as const,
            error: { code: 'cancelled' as const, message: 'the user cancelled Tang requirement clarification', details: {} },
          }
        : {
            ok: true as const,
            value: { sessionId, answer: { answers } },
          })
      if (!receipt.accepted) throw new Error(`澄清回复被拒绝：${receipt.reason}`)
    } catch (error) {
      setClarificationBusy(false)
      setClarificationError(error instanceof Error ? error.message : String(error))
    }
  }

  return (
    <>
      <button ref={triggerRef} type="button" data-tang-trigger onClick={() => { setOpen(value => !value) }} title={blank ? '配置三省模型与思考等级' : '三省六部任务总览'}>
        <i />{blank ? '三省配置' : '三省六部'}
      </button>
      {open && createPortal(
        <section data-tang-court data-new-session={blank ? 'true' : undefined} aria-label={blank ? '三省六部新会话配置' : '三省六部任务总览'} style={courtLeft === undefined ? undefined : { left: `${courtLeft}px` }}>
          <div className="tang-shell">
            <main className="tang-main">
              <header className="tang-head">
                <div className="tang-brand">
                  <svg className="tang-logo" viewBox="0 0 48 48" role="img" aria-label="三省六部九叶徽记">
                    <title>三省六部九叶徽记</title>
                    <defs>
                      <linearGradient id="tang-logo-petal-gradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0" stopColor="#efad88" />
                        <stop offset="0.62" stopColor="#cd795b" />
                        <stop offset="1" stopColor="#884335" />
                      </linearGradient>
                      <linearGradient id="tang-logo-frame-gradient" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0" stopColor="#8f5643" />
                        <stop offset="0.3" stopColor="#a66a51" />
                        <stop offset="0.64" stopColor="#8e5543" />
                        <stop offset="1" stopColor="#7d4c3c" />
                      </linearGradient>
                    </defs>
                    <rect className="tang-logo-plate" x="2.5" y="2.5" width="43" height="43" rx="12" />
                    <rect className="tang-logo-plate-inner" x="8" y="8" width="32" height="32" rx="8.8" />
                    <g className="tang-logo-mark" transform="translate(0 1)">
                      <path d="M24 22C22.8 19.5 21.2 17.2 21.2 12.7 21.2 8.9 22.5 6.1 24 6.1s2.8 2.8 2.8 6.6c0 4.5-1.6 6.8-2.8 9.3Z" />
                      <path d="M24 22C22.8 19.5 21.2 17.2 21.2 12.7 21.2 8.9 22.5 6.1 24 6.1s2.8 2.8 2.8 6.6c0 4.5-1.6 6.8-2.8 9.3Z" transform="rotate(120 24 24)" />
                      <path d="M24 22C22.8 19.5 21.2 17.2 21.2 12.7 21.2 8.9 22.5 6.1 24 6.1s2.8 2.8 2.8 6.6c0 4.5-1.6 6.8-2.8 9.3Z" transform="rotate(240 24 24)" />
                    </g>
                    <g className="tang-logo-accent" transform="translate(0 1)">
                      {[40, 80, 160, 200, 280, 320].map(angle => (
                        <path
                          key={angle}
                          d={[40, 80, 280, 320].includes(angle)
                            ? 'M24 20.3c-2.4-2.9-2.2-7.2 0-11.2 2.2 4 2.4 8.3 0 11.2Z'
                            : 'M24 19.3c-1.8-2.2-1.7-5.5 0-8.2 1.7 2.7 1.8 6 0 8.2Z'}
                          transform={`rotate(${angle} 24 24)`}
                        />
                      ))}
                    </g>
                    <circle className="tang-logo-node" cx="24" cy="25" r="2.2" />
                  </svg>
                  <div>
                    <h1 className="tang-kicker">三省六部</h1>
                    <div className="tang-sub">
                      <span>{blank ? '新会话配置' : '当前任务'}</span><b>{blank ? '三省模型与思考等级' : timeline.entries.at(-1)?.caseId ?? '当前会话'}</b>
                    </div>
                  </div>
                </div>
                <div className="tang-actions">
                  {!blank && <button type="button" className="danger" disabled={stopping} onClick={() => { void handleStop() }}>{stopping ? '正在叫停…' : '叫停任务'}</button>}
                  <button type="button" onClick={() => { setOpen(false) }}>{blank ? '返回新会话' : '返回对话'}</button>
                </div>
              </header>
              <section className="tang-org-chart" aria-label="三省六部组织架构图">
                <section className="tang-review-domain" aria-label="中书省与门下省审议区域">
                  <div className="tang-org-level tang-org-review">
                    {TANG_OFFICE_DEFINITIONS.filter(office => office.id === 'zhongshu' || office.id === 'menxia').map(card)}
                  </div>
                </section>
                <div className="tang-org-link tang-org-link--review" aria-hidden="true">
                  <i className="tang-link-in-left" /><i className="tang-link-in-right" />
                  <i className="tang-link-bus" /><i className="tang-link-out" />
                </div>
                <section className="tang-shangshu-domain" aria-label="尚书省及六部管辖区域">
                  <div className="tang-org-level tang-org-executive">
                    {TANG_OFFICE_DEFINITIONS.filter(office => office.id === 'shangshu').map(card)}
                  </div>
                  <div className="tang-org-link tang-org-link--ministries" aria-hidden="true">
                    <i className="tang-link-in" /><i className="tang-link-bus" />
                    {Array.from({ length: 6 }, (_, index) => <i key={index} className="tang-link-drop" />)}
                  </div>
                  <div className="tang-org-level tang-org-ministries">
                    {TANG_OFFICE_DEFINITIONS.filter(office => office.tier === 'ministry').map(card)}
                  </div>
                </section>
              </section>
            </main>
            <aside className="tang-timeline">
              <div className="tang-trace-head">
                <div><h2>调用轨迹</h2><div className="tang-timeline-meta">部门调用与执行阶段</div></div>
                <div className="tang-trace-head-stats" aria-label="调用轨迹统计">
                  <span><b>{orderedTraces.length}</b>调用</span>
                  <span><b>{formatTokens(traceTokens)}</b>令牌</span>
                </div>
              </div>
              <div className="tang-trace-list" role="list" aria-label="实际部门调用大纲">
                {timelineSegments.map((segment, index) => {
                  const { trace } = segment
                  if (nestedMinistryKeys.has(segment.key)) return null
                  const isDepartment = TANG_DEPARTMENTS.includes(trace.office as TangDepartment)
                  const displayStatus = (isDepartment ? runningOffices.has(trace.office) : runningTraceIds.has(trace.sessionId))
                    ? 'running'
                    : trace.office === 'shangshu'
                    && hasRunningMinistry
                    && (trace.status === 'pending' || trace.status === 'succeeded' || trace.status === 'passed')
                    ? 'running'
                    : trace.status
                  const nextSameOffice = timelineSegments.slice(index + 1).find(entry => entry.trace.office === trace.office)
                  const traceReviews = trace.office !== 'zhongshu'
                    ? []
                    : timeline.reviews.filter(review => review.time >= segment.startedAt
                      && review.time < (nextSameOffice?.startedAt ?? Number.POSITIVE_INFINITY))
                  const invocationTitle = trace.invocationTitle ?? trace.title
                  const invocationPhase = !segment.continuation
                    && !segment.phases.some(phase => phase.title === invocationTitle)
                    ? [{
                        stage: 'intake' as const,
                        title: invocationTitle,
                        ...(trace.summary === undefined ? {} : { summary: trace.summary }),
                        status: segment.phases.length > 0 ? 'succeeded' as const : trace.status,
                        updatedAt: trace.startedAt ?? segment.startedAt,
                        reviewKind: undefined,
                      }]
                    : []
                  const recordedPhases = [
                    ...invocationPhase,
                    ...segment.phases.map(phase => ({ ...phase, reviewKind: reviewKindForStage(phase.stage) })),
                    ...traceReviews.map(review => ({
                      stage: review.kind === 'approval' ? 'user-approval' as const : 'case-closure' as const,
                      title: review.title,
                      summary: reviewStatusLabel(review.kind, review.status),
                      status: reviewTangStatus(review.status),
                      updatedAt: review.time,
                      reviewKind: review.kind,
                    })),
                  ].sort((left, right) => left.updatedAt - right.updatedAt)
                  // Keep the real catalog invocation as the first durable row.
                  // Later progress milestones supplement it instead of replacing it.
                  const phaseAttempts = recordedPhases
                  // A retry is an implementation detail of one workflow stage, not a
                  // second user-facing phase. Keep the latest attempt for an identical
                  // stage/title pair while retaining genuinely distinct work in order.
                  const phases = phaseAttempts.filter((phase, phaseIndex) => !phaseAttempts
                    .slice(phaseIndex + 1)
                    .some(later => later.stage === phase.stage && later.title === phase.title))
                  const executionChildren = trace.office === 'shangshu'
                    ? shangshuExecutionSegments(timelineSegments, index)
                    : []
                  const displayedPhaseCount = phases.length + executionChildren.reduce(
                    (total, childSegment) => total + Math.max(1, childSegment.phases.length), 0,
                  )
                  const executionSessions = new Set(executionChildren.map(child => child.trace.sessionId))
                  const displayedTraceTokens = traceTokenTotal(trace.usage) + orderedTraces.reduce(
                    (total, childTrace) => total + (executionSessions.has(childTrace.sessionId) ? traceTokenTotal(childTrace.usage) : 0), 0,
                  )
                  const childRows = trace.office === 'shangshu'
                    ? [
                        ...phases.map((phase, phaseIndex) => ({ kind: 'phase' as const, phase, phaseIndex, time: phase.updatedAt })),
                        ...executionChildren.map(child => ({ kind: 'ministry' as const, segment: child, time: child.updatedAt })),
                      ].sort((left, right) => left.time - right.time)
                    : phases.map((phase, phaseIndex) => ({ kind: 'phase' as const, phase, phaseIndex, time: phase.updatedAt }))
                  if (!isDepartment) {
                    const rowKey = `${segment.key}:summary`
                    const expanded = expandedTraceRow === rowKey
                    return (
                      <button
                        type="button"
                        role="listitem"
                        key={segment.key}
                        className={`tang-trace-item is-ministry ${displayStatus}${expanded ? ' is-expanded' : ''}`}
                        aria-expanded={expanded}
                        onClick={() => { toggleTraceRow(rowKey) }}
                      >
                        <span className="tang-trace-rail"><i /></span>
                        <span className="tang-trace-body">
                          <TangOfficeOrnament office={trace.office} className="tang-trace-ornament" />
                          <span className="tang-trace-row">
                            <span className="tang-trace-office"><em>{segment.continuation ? '续' : String(index + 1).padStart(2, '0')}</em>{trace.officeName}</span>
                            <span className="tang-trace-state tang-trace-indicator" aria-label={statusLabel(displayStatus)} title={statusLabel(displayStatus)} />
                          </span>
                          <strong className="tang-trace-title">{trace.title}</strong>
                          {trace.summary !== undefined && <span className="tang-trace-summary">{trace.summary}</span>}
                          <span className="tang-trace-meta">
                            <time>{traceTime(segment.updatedAt)}</time>
                            <span>令牌 {formatTokens(traceTokenTotal(trace.usage))}</span>
                          </span>
                        </span>
                      </button>
                    )
                  }
                  const collapsed = collapsedTraceIds.has(segment.key)
                  return (
                    <Fragment key={segment.key}>
                      <button
                        type="button"
                        role="listitem"
                        className={`tang-trace-item is-department ${displayStatus}${collapsed ? ' is-collapsed' : ''}`}
                        aria-expanded={!collapsed}
                        onClick={() => { toggleTraceCollapsed(segment.key) }}
                      >
                        <span className="tang-trace-rail"><i /></span>
                        <span className="tang-trace-body">
                          <TangOfficeOrnament office={trace.office} className="tang-trace-ornament" />
                          <span className="tang-trace-row">
                            <span className="tang-trace-office"><em>{String(index + 1).padStart(2, '0')}</em>{trace.officeName}</span>
                            <span className="tang-trace-state-wrap"><span className="tang-trace-state">{statusLabel(displayStatus)}</span></span>
                          </span>
                          <span className="tang-trace-stats">
                            <span><b>{displayedPhaseCount}</b>阶段</span>
                            <span><b>{formatTokens(displayedTraceTokens)}</b>令牌</span>
                          </span>
                        </span>
                      </button>
                      {!collapsed && childRows.map((childRow, childIndex) => {
                        if (childRow.kind === 'ministry') {
                          const childSegment = childRow.segment
                          const childTrace = childSegment.trace
                          const childStatus = runningTraceIds.has(childTrace.sessionId) ? 'running' : childTrace.status
                          const rowKey = `${childSegment.key}:summary`
                          const expanded = expandedTraceRow === rowKey
                          return (
                            <button
                              type="button"
                              role="listitem"
                              key={childSegment.key}
                              className={`tang-trace-item is-ministry ${childStatus}${expanded ? ' is-expanded' : ''}`}
                              aria-expanded={expanded}
                              onClick={() => { toggleTraceRow(rowKey) }}
                            >
                              <span className="tang-trace-rail"><i /></span>
                              <span className="tang-trace-body">
                                <TangOfficeOrnament office={childTrace.office} className="tang-trace-ornament" />
                                <span className="tang-trace-row">
                                  <span className="tang-trace-office"><em>{String(index + childIndex + 1).padStart(2, '0')}</em>{childTrace.officeName}</span>
                                  <span className="tang-trace-state tang-trace-indicator" aria-label={statusLabel(childStatus)} title={statusLabel(childStatus)} />
                                </span>
                                <strong className="tang-trace-title">{childTrace.title}</strong>
                                {childTrace.summary !== undefined && <span className="tang-trace-summary">{childTrace.summary}</span>}
                                <span className="tang-trace-meta">
                                  <time>{traceTime(childSegment.updatedAt)}</time>
                                  <span>令牌 {formatTokens(traceTokenTotal(childTrace.usage))}</span>
                                </span>
                              </span>
                            </button>
                          )
                        }
                        const { phase, phaseIndex } = childRow
                        const rowKey = `${segment.key}:${phase.updatedAt}:${phaseIndex}`
                        const expanded = expandedTraceRow === rowKey
                        return (
                          <button
                            type="button"
                            role="listitem"
                            key={rowKey}
                            className={`tang-trace-item is-phase ${phase.status}${expanded ? ' is-expanded' : ''}`}
                            aria-expanded={expanded}
                            onClick={() => {
                              if (phase.reviewKind !== undefined) setReviewPanel(phase.reviewKind)
                              else toggleTraceRow(rowKey)
                            }}
                          >
                            <span className="tang-trace-rail"><i /></span>
                            <span className="tang-trace-body">
                              <span className="tang-trace-row">
                                <span className="tang-trace-phase-label">阶段 {String(phaseIndex + 1).padStart(2, '0')} · {stageLabel(phase.stage)}</span>
                                <span
                                  className="tang-trace-state tang-trace-indicator"
                                  aria-label={phaseStatusLabel(phase.stage, phase.status)}
                                  title={phaseStatusLabel(phase.stage, phase.status)}
                                />
                              </span>
                              <strong className="tang-trace-title">{phase.title}</strong>
                              {phase.summary !== undefined && <span className="tang-trace-summary">{phase.summary}</span>}
                              <span className="tang-trace-meta"><time>{traceTime(phase.updatedAt)}</time></span>
                            </span>
                          </button>
                        )
                      })}
                    </Fragment>
                  )
                })}
              </div>
              {orderedTraces.length === 0 && <div className="tang-empty">当前会话尚未创建部门 Agent；首次实际派发后将在这里生成轨迹。</div>}
              {traceUnavailable > 0 && <div className="tang-trace-warning">{traceUnavailable} 个部门的历史暂时不可用，已保留调用位置并将自动重试。</div>}
            </aside>
          </div>
        </section>,
        document.body,
      )}
      {open && clarification !== undefined && activeClarificationQuestion !== undefined && createPortal(
        <div className="tang-clarification-backdrop">
          <section className="tang-clarification-dialog" role="dialog" aria-modal="true" aria-labelledby="tang-clarification-title">
            <header className="tang-clarification-header">
              <div>
                <div className="tang-clarification-kicker">中书省 · 需求澄清</div>
                <h2 id="tang-clarification-title">请补充一个关键决定</h2>
                <p>回答会通过标准问询通道回传到原中书省会话，不会重新开始分析。</p>
              </div>
              <div className="tang-clarification-progress">{clarificationIndex + 1} / {clarification.questions.length}</div>
            </header>
            <div className="tang-clarification-body">
              <div className="tang-clarification-label">{activeClarificationQuestion.header ?? '需求边界'}</div>
              <div className="tang-clarification-question">{activeClarificationQuestion.question}</div>
              {activeClarificationQuestion.detail !== undefined && (
                <div className="tang-clarification-detail"><MarkdownText text={activeClarificationQuestion.detail} /></div>
              )}
              <div className="tang-clarification-options">
                {activeClarificationQuestion.options?.map(option => {
                  const selected = clarificationDrafts[activeClarificationQuestion.id]?.selected.includes(option.label) === true
                  return (
                    <button
                      key={option.label}
                      type="button"
                      className={`tang-clarification-option${selected ? ' selected' : ''}`}
                      aria-pressed={selected}
                      disabled={clarificationBusy}
                      onClick={() => { chooseClarificationOption(activeClarificationQuestion, option.label) }}
                    >
                      <i />
                      <span><b>{option.label}</b>{option.description !== undefined && <small>{option.description}</small>}</span>
                    </button>
                  )
                })}
              </div>
              <label className="tang-clarification-custom">
                <span>其他方案或补充说明</span>
                <textarea
                  value={clarificationDrafts[activeClarificationQuestion.id]?.custom ?? ''}
                  disabled={clarificationBusy}
                  placeholder="选项不适用时，可直接写下你的要求……"
                  onChange={(event) => { updateClarificationCustom(activeClarificationQuestion, event.currentTarget.value) }}
                />
              </label>
            </div>
            <footer className="tang-clarification-footer">
              <div className="tang-clarification-error" role="status">{clarificationError}</div>
              <div className="tang-clarification-actions">
                <button type="button" disabled={clarificationBusy} onClick={() => { void respondToClarification(true) }}>取消问询</button>
                {clarificationIndex > 0 && <button type="button" disabled={clarificationBusy} onClick={() => { setClarificationIndex(index => index - 1) }}>上一个</button>}
                {clarificationIndex < clarification.questions.length - 1
                  ? <button type="button" className="submit" disabled={clarificationBusy} onClick={() => { setClarificationIndex(index => index + 1) }}>下一个</button>
                  : <button type="button" className="submit" disabled={clarificationBusy} onClick={() => { void respondToClarification(false) }}>{clarificationBusy ? '正在回传…' : '提交给中书省'}</button>}
              </div>
            </footer>
          </section>
        </div>,
        document.body,
      )}
      {open && displayedReview !== undefined && createPortal(
        <div className="tang-approval-backdrop">
          <section className="tang-approval-dialog" data-review-kind={displayedReview.kind} data-review-status={displayedReview.status} role="dialog" aria-modal="true" aria-labelledby="tang-approval-title">
            <header className="tang-approval-header">
              <div>
                <div className="tang-approval-kicker">{displayedReview.kind === 'approval' ? '会签审察 · 用户决策' : '案卷结案 · 最终交付'}</div>
                <h2 id="tang-approval-title">{displayedReview.kind === 'approval' ? '中书门下会签方案' : '三省六部结案汇报'}</h2>
                <p>{displayedReview.title}</p>
              </div>
              <div className="tang-approval-header-actions">
                <div className="tang-approval-seal"><span>{reviewSealLabel(displayedReview.kind, displayedReview.status)}</span><small>{displayedReview.caseId}</small></div>
                <button type="button" className="tang-approval-close" aria-label="隐藏面板" onClick={() => { setReviewPanel(null) }}>×</button>
              </div>
            </header>
            <div className="tang-approval-layout">
              <aside className="tang-approval-guide">
                <span className="tang-approval-code">{displayedReview.kind === 'approval' ? '第一关 · 会签' : '第九关 · 结案'}</span>
                <h3>{displayedReview.kind === 'approval' ? '审察重点' : '结案核对'}</h3>
                {displayedReview.kind === 'approval'
                  ? <ol><li>需求范围与验收标准</li><li>架构、技术栈与权限</li><li>渐进开发阶段与独立验证</li><li>风险、回滚与未决事项</li></ol>
                  : <ol><li>实际变更与批准范围</li><li>六部调度与阶段证据</li><li>测试、验收与遗留风险</li><li>最终产物与史官记录</li></ol>}
                {displayedReview.pending && displayedReview.kind === 'closure' && (
                  <div className="tang-closure-options" aria-label="结案前操作选择">
                    <span>结案方式</span>
                    {displayedReview.options.filter(option => option.label !== TANG_REMAND_LABEL).map(option => (
                      <button
                        key={option.label}
                        type="button"
                        className={reviewChoice === option.label ? 'selected' : ''}
                        aria-pressed={reviewChoice === option.label}
                        disabled={approvalBusy}
                        onClick={() => { setReviewChoice(option.label) }}
                      >
                        <b>{option.label}</b>
                        {option.description !== undefined && <small>{option.description}</small>}
                      </button>
                    ))}
                  </div>
                )}
                <div className="tang-approval-rule"><i />{displayedReview.pending
                  ? displayedReview.kind === 'approval' ? '等待你的会签决定；可先隐藏面板' : '等待你的结案决定；可先隐藏面板'
                  : reviewStatusLabel(displayedReview.kind, displayedReview.status)}</div>
              </aside>
              <article className="tang-approval-document" aria-label={displayedReview.kind === 'approval' ? '会签方案全文' : '最终结案汇报'}>
                <div className="tang-approval-document-head"><span>{displayedReview.kind === 'approval' ? '两省会签方案' : '终稿与史官记录'}</span><b>{displayedReview.pending ? '等待处理' : '历史结果'}</b></div>
                <div className="tang-approval-markdown"><MarkdownText text={displayedReview.detail} /></div>
              </article>
            </div>
            {displayedReview.pending && <footer className="tang-approval-footer">
              <label className="tang-approval-feedback">
                <span>补充意见 <small>驳回时必填</small></span>
                <textarea
                  value={approvalFeedback}
                  disabled={approvalBusy}
                  placeholder={displayedReview.kind === 'approval' ? '例：第二阶段需增加回滚方案，并补充 Windows 端验证……' : '例：补充性能验证结果，并说明遗留风险的处理计划……'}
                  onChange={(event) => { setApprovalFeedback(event.currentTarget.value) }}
                />
              </label>
              <div className="tang-approval-actions">
                <div className="tang-approval-error" role="status">{approvalError}</div>
                <div className="tang-approval-buttons">
                  <button type="button" className="cancel" disabled={approvalBusy} onClick={() => { void respondToCaseReview('cancel') }}>取消任务</button>
                  <button type="button" className="remand" disabled={approvalBusy || approvalFeedback.trim() === ''} onClick={() => { void respondToCaseReview('remand') }}>补充并驳回</button>
                  <button type="button" className="approve" disabled={approvalBusy} onClick={() => { void respondToCaseReview('confirm') }}>{approvalBusy ? '正在提交…' : displayedReview.kind === 'approval' ? '批准执行' : reviewChoice === TANG_CLOSE_LABEL ? '确认结案' : '执行所选操作'}</button>
                </div>
              </div>
            </footer>}
          </section>
        </div>,
        document.body,
      )}
      {selectedDefinition !== undefined && createPortal(
        <div className="tang-dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelected(null) }}>
          <section className="tang-dialog" role="dialog" aria-modal="true" aria-label={`${selectedDefinition.name}详情`}>
            <header className="tang-dialog-head">
              <div><h3>{selectedDefinition.name}</h3></div>
              <button type="button" className="close" aria-label="关闭" onClick={() => { setSelected(null) }}>×</button>
            </header>
            <div className="tang-dialog-section"><h4>当前职责</h4><div>{selectedDefinition.duty.replace('API／UI', '接口与界面')}</div></div>
            {selectedDefinition.id === 'zhongshu' && (timeline.reviews.length > 0 || caseReview !== undefined) && (
              <div className="tang-dialog-section">
                <h4>案卷审议</h4>
                <div className="tang-review-shortcuts">
                  {(caseReview?.kind === 'approval' || timeline.reviews.some(review => review.kind === 'approval')) && (
                    <button type="button" onClick={() => { setSelected(null); setReviewPanel('approval') }}>查看会签方案与结果</button>
                  )}
                  {(caseReview?.kind === 'closure' || timeline.reviews.some(review => review.kind === 'closure')) && (
                    <button type="button" onClick={() => { setSelected(null); setReviewPanel('closure') }}>查看结案汇报与结果</button>
                  )}
                </div>
              </div>
            )}
            <div className="tang-dialog-section tang-dialog-record-section">
              <h4>执行记录</h4>
              {selectedRecords.length === 0 && <div className="tang-dialog-note">尚无该部门的执行记录。</div>}
              {selectedRecords.length > 0 && <div className="tang-dialog-records">
                {selectedRecords.map((record, index) => {
                  const displayStatus = selectedIsMinistry
                    ? record.status
                    : displayedRecordStatus(record.status, index < selectedRecords.length - 1)
                  return <article key={record.key} className="tang-dialog-event" data-status={displayStatus}>
                    <i className="tang-dialog-event-dot" aria-hidden="true" />
                    <div className="tang-dialog-event-head">
                      <span className="tang-dialog-event-stage">{String(index + 1).padStart(2, '0')} · {stageLabel(record.stage)}</span>
                      <span className="tang-dialog-event-status">{displayedRecordStatusLabel(record.stage, displayStatus)}</span>
                    </div>
                    <strong>{record.title}</strong>
                    {record.summary !== undefined && <p>{record.summary}</p>}
                    <footer className="tang-dialog-event-foot">
                      {record.time > 0
                        ? <time dateTime={new Date(record.time).toISOString()}>{formatRecordTime(record.time)}</time>
                        : <span>等待日志</span>}
                    </footer>
                  </article>
                })}
              </div>}
            </div>
            <p className="tang-dialog-note">记录已按实际发生时间排序；完整消息与统计可进入对话查看。</p>
            <footer className="tang-dialog-footer">
              {selectedChild !== undefined && <button type="button" onClick={() => {
                openChild({ parentSessionId: selectedChild.parentSessionId, childSessionId: selectedChild.entry.id, mode: selectedChild.entry.mode })
                setSelected(null)
                setOpen(false)
              }}>进入完整对话</button>}
            </footer>
          </section>
        </div>,
        document.body,
      )}
    </>
  )
}

function TangNewSessionCourt(props: TangNewSessionCourtProps) {
  const blank = props.useSession(snapshot => snapshot.blank)
  if (!blank) return null
  return <TangCourt {...props} initialOpen={false} />
}

/** Required Client services. */
export const inject = ['sessions', 'slots', 'conversationEvents', 'conversationViews', 'settingsScope', 'connection']

/** Register the Tang event projection and session header entry point. */
export function apply(ctx: ClientContext): void {
  const sessions = ctx.sessions as unknown as ISessions
  const connection = ctx.get('connection') as TangClientConnection
  const routeSettings = ctx.settingsScope.bind<TangDepartmentRoutes>({ namespace: TANG_SETTINGS_NAMESPACE })
  ctx.effect(() => {
    if (document.getElementById(STYLE_ID) !== null) return () => {}
    const style = document.createElement('style')
    style.id = STYLE_ID
    style.dataset.plugin = 'dsh-tang-governance'
    style.textContent = `${CSS}\n${TECH_CSS}\n${TRACE_CSS}\n${APPROVAL_CSS}`
    document.head.appendChild(style)
    return () => { style.remove() }
  }, 'tang-governance: styles')
  ctx.conversationEvents.register(progressDefinition)
  ctx.conversationEvents.register(reviewDefinition)
  ctx.conversationViews.register(timelineView)
  const courtInject = (sessionId: SessionId): TangCourtInjected => ({
    openChild: address => { sessions.openSubagent(address) },
    refresh: parentSessionId => { void sessions.refreshSubagents(parentSessionId) },
    setCatalogOpen: (parentSessionId, open) => { sessions.setSubagentCatalogOpen(parentSessionId, open) },
    stopTask: async (rootSessionId, childIds) => {
      const targets = [rootSessionId, ...childIds]
      await Promise.all(targets.map(async (id) => {
        const session = sessions.binding(id)?.session
        if (session !== undefined && session.getSnapshot().running) await session.cancel()
      }))
      const root = sessions.binding(rootSessionId)?.session
      if (root !== undefined) {
        await root.prompt([{
          type: 'text',
          text: '用户已在三省六部面板点击“叫停任务”。立即停止派发，中断仍在运行的所有后代 Agent，使用 tang_progress 把当前阶段记录为 stopped，并汇报已完成和未完成事项。未经用户再次明确指示不得恢复。',
        }], 'queue')
      }
    },
    routeSettings,
    loadModels: async (rootSessionId) => {
      const response = await connection.api.sessions.models({ sessionId: rootSessionId })
      if (!response.result.ok) {
        throw new Error(`${response.result.error.code}: ${response.result.error.message}`)
      }
      return response.result.value
    },
    loadTraces: async (children) => {
      const unavailableIds: string[] = []
      const entries = await Promise.all(children.map(async (child): Promise<TangDepartmentTrace | null> => {
        const office = officeFromLabel(child.entry.label)
        if (office === undefined) return null
        const fallback = (): TangDepartmentTrace => buildDepartmentTrace({
          sessionId: child.entry.id,
          office,
          ...(child.entry.label === undefined ? {} : { label: child.entry.label }),
          depth: child.depth,
          activity: child.entry.activity,
          events: [],
        })
        try {
          const response = await connection.api.subagents.history({
            parentSessionId: child.parentSessionId,
            childSessionId: child.entry.id,
            mode: child.entry.mode,
            maxMessages: 50,
          })
          if (!response.result.ok) {
            unavailableIds.push(child.entry.id)
            return fallback()
          }
          const { value } = response.result
          const tokenUsage = value.projections?.values.tokenUsage
          return buildDepartmentTrace({
            sessionId: child.entry.id,
            office,
            ...(child.entry.label === undefined ? {} : { label: child.entry.label }),
            depth: child.depth,
            activity: child.entry.activity,
            events: value.events.map(entry => entry.event),
            ...(tokenUsage === undefined ? {} : { tokenUsage }),
          })
        } catch {
          unavailableIds.push(child.entry.id)
          return fallback()
        }
      }))
      return { entries: entries.filter(entry => entry !== null), unavailableIds }
    },
  })
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions',
    id: 'tang-governance',
    order: 12,
    inject: courtInject,
  }, TangCourt))
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left',
    id: 'tang-governance-new-session',
    order: 12,
    inject: courtInject,
  }, TangNewSessionCourt))
}
