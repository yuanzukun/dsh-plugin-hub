/** Pure projection helpers for the Tang department-call outline. */
import {
  parseTangProgress, TANG_DEPARTMENTS, TANG_MINISTRY_OFFICES, TANG_OFFICE_DEFINITIONS,
  type TangMinistry, type TangOffice, type TangStage, type TangStatus,
} from '../contracts.ts'

/** Browser-safe subset of a durable session event used by the trace projector. */
export interface TangTraceEvent {
  readonly type: string
  readonly seq: number
  readonly time: number
  readonly data: unknown
}

/** Whole-session token buckets supplied by Harness's tokenUsage projection. */
export interface TangTraceUsage {
  readonly uncachedInputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens: number
  readonly cacheWriteTokens: number
}

/** One durable progress milestone recorded inside a department invocation. */
export interface TangTracePhase {
  readonly stage: TangStage
  readonly title: string
  readonly summary?: string
  readonly status: TangStatus
  readonly updatedAt: number
}

/** One actual department Agent invocation displayed in the task outline. */
export interface TangDepartmentTrace {
  readonly sessionId: string
  readonly office: TangOffice
  readonly officeName: string
  readonly depth: number
  /** Stable catalog label describing why this invocation was created. */
  readonly invocationTitle?: string
  readonly title: string
  readonly summary?: string
  readonly stage?: TangStage
  readonly status: TangStatus
  readonly startedAt?: number
  readonly updatedAt?: number
  readonly phases: readonly TangTracePhase[]
  readonly usage: TangTraceUsage
}

/** A detail row keeps its invocation identity, independently of province grouping. */
export interface TangDialogRecord {
  readonly key: string
  readonly time: number
  readonly stage: TangStage
  readonly title: string
  readonly summary: string | undefined
  readonly status: TangStatus
}

/** Ministry work lives in child sessions; coordinator progress is only a supplement. */
export function projectMinistryDialogRecords(
  office: TangOffice,
  traces: readonly TangDepartmentTrace[],
  coordinatorRecords: readonly TangDialogRecord[],
): TangDialogRecord[] {
  const records = traces.filter(trace => trace.office === office).flatMap(trace => {
    if (trace.phases.length > 0) {
      return trace.phases.map((phase, index): TangDialogRecord => ({
        key: `child:${trace.sessionId}:phase:${index}`,
        time: phase.updatedAt,
        stage: phase.stage,
        title: phase.title,
        summary: phase.summary,
        status: phase.status,
      }))
    }
    // A completed Agent invocation remains evidence even without tang_progress.
    return [{
      key: `child:${trace.sessionId}:invocation`,
      time: trace.updatedAt ?? trace.startedAt ?? 0,
      stage: trace.stage ?? 'ministry-execution',
      title: trace.title,
      summary: trace.summary,
      status: trace.status,
    } satisfies TangDialogRecord]
  })
  // Only suppress an exact mirrored event, never different tasks sharing a stage.
  const mirrored = (record: TangDialogRecord): boolean => records.some(child =>
    child.time === record.time && child.stage === record.stage
    && child.title === record.title && child.status === record.status
    && child.summary === record.summary)
  return [...records, ...coordinatorRecords.filter(record => !mirrored(record))]
    .sort((left, right) => (left.time || Infinity) - (right.time || Infinity))
}

/** One chronologically contiguous portion of a real department invocation. */
export interface TangTimelineSegment {
  /** Stable UI identity; never used to address the underlying child session. */
  readonly key: string
  /** The unchanged invocation that owns these phases and all invocation-level statistics. */
  readonly trace: TangDepartmentTrace
  readonly phases: readonly TangTracePhase[]
  readonly startedAt: number
  readonly updatedAt: number
  readonly continuation: boolean
}

/** Inputs retained by the subagent catalog and its latest history page. */
export interface TangTraceInput {
  readonly sessionId: string
  readonly office: TangOffice
  readonly label?: string
  readonly depth: number
  readonly activity: 'running' | 'inactive'
  readonly events: readonly TangTraceEvent[]
  readonly tokenUsage?: unknown
}

const ZERO_USAGE: TangTraceUsage = {
  uncachedInputTokens: 0,
  outputTokens: 0,
  cacheReadTokens: 0,
  cacheWriteTokens: 0,
}

function tokenBucket(record: Record<string, unknown>, key: keyof TangTraceUsage): number {
  const value = record[key]
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : 0
}

/** Normalize the wire projection so a temporarily absent token-meter capability renders as zero. */
export function parseTraceUsage(value: unknown): TangTraceUsage {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return ZERO_USAGE
  const record = value as Record<string, unknown>
  return {
    uncachedInputTokens: tokenBucket(record, 'uncachedInputTokens'),
    outputTokens: tokenBucket(record, 'outputTokens'),
    cacheReadTokens: tokenBucket(record, 'cacheReadTokens'),
    cacheWriteTokens: tokenBucket(record, 'cacheWriteTokens'),
  }
}

/** Sum every provider-billed input bucket plus generated output. */
export function traceTokenTotal(usage: TangTraceUsage): number {
  return usage.uncachedInputTokens + usage.cacheReadTokens + usage.cacheWriteTokens + usage.outputTokens
}

/** Keep every invocation on one forward-only rail, ordered by its first durable event. */
export function orderDepartmentTraces(traces: readonly TangDepartmentTrace[]): TangDepartmentTrace[] {
  return traces
    .map((trace, index) => ({ trace, index }))
    .sort((left, right) => {
      const leftTime = left.trace.startedAt ?? left.trace.updatedAt ?? Number.POSITIVE_INFINITY
      const rightTime = right.trace.startedAt ?? right.trace.updatedAt ?? Number.POSITIVE_INFINITY
      return leftTime - rightTime || left.index - right.index
    })
    .map(item => item.trace)
}

/**
 * Project immutable invocations onto one execution-time rail.
 * Adjacent phases owned by the same invocation form one segment. If another
 * invocation executes in between, the resumed work becomes a continuation.
 */
export function projectTraceTimeline(traces: readonly TangDepartmentTrace[]): TangTimelineSegment[] {
  const events = traces.flatMap((trace, traceIndex) => {
    if (trace.phases.length === 0) {
      return [{
        trace,
        traceIndex,
        phaseIndex: -1,
        time: trace.updatedAt ?? trace.startedAt ?? Number.POSITIVE_INFINITY,
      }]
    }
    return trace.phases.map((phase, phaseIndex) => {
      const invocationStart = trace.startedAt
      const time = phaseIndex === 0
        && invocationStart !== undefined
        && Number.isFinite(invocationStart)
        ? Math.min(invocationStart, phase.updatedAt)
        : phase.updatedAt
      return { trace, traceIndex, phaseIndex, time }
    })
  }).sort((left, right) => left.time - right.time
    || left.traceIndex - right.traceIndex
    || left.phaseIndex - right.phaseIndex)

  const groups: Array<{ trace: TangDepartmentTrace; phases: TangTracePhase[]; anchorTime: number }> = []
  for (const event of events) {
    const previous = groups.at(-1)
    if (previous?.trace.sessionId === event.trace.sessionId) {
      if (event.phaseIndex >= 0) previous.phases.push(event.trace.phases[event.phaseIndex]!)
    } else {
      groups.push({
        trace: event.trace,
        phases: event.phaseIndex < 0 ? [] : [event.trace.phases[event.phaseIndex]!],
        anchorTime: event.time,
      })
    }
  }

  const occurrences = new Map<string, number>()
  const segments = groups.map((group): TangTimelineSegment => {
    const occurrence = occurrences.get(group.trace.sessionId) ?? 0
    occurrences.set(group.trace.sessionId, occurrence + 1)
    const rawStartedAt = group.anchorTime
      ?? group.trace.startedAt
      ?? group.trace.updatedAt
    const rawUpdatedAt = group.phases.at(-1)?.updatedAt
      ?? group.trace.updatedAt
      ?? group.trace.startedAt
    // Infinity is useful only as a sort sentinel. Never expose it to date
    // formatting or other display consumers.
    const startedAt = rawStartedAt !== undefined && Number.isFinite(rawStartedAt) ? rawStartedAt : 0
    const updatedAt = rawUpdatedAt !== undefined && Number.isFinite(rawUpdatedAt) ? rawUpdatedAt : startedAt
    return {
      key: `${group.trace.sessionId}:timeline:${occurrence}`,
      trace: group.trace,
      phases: group.phases,
      startedAt,
      updatedAt,
      continuation: occurrence > 0,
    }
  })

  // Ministries are children of one Shangshu execution block. Their events may
  // occur between Shangshu's dispatch and completion milestones, but that does
  // not mean the supervising invocation resumed in a separate workflow period.
  const timeline: TangTimelineSegment[] = []
  for (const segment of segments) {
    if (segment.trace.office !== 'shangshu' || !segment.continuation) {
      timeline.push(segment)
      continue
    }
    const ownerIndex = timeline.findLastIndex(candidate => candidate.trace.sessionId === segment.trace.sessionId)
    const intervening = ownerIndex < 0 ? [] : timeline.slice(ownerIndex + 1)
    const belongsToSameExecution = ownerIndex >= 0 && intervening.every(candidate => (
      TANG_MINISTRY_OFFICES.includes(candidate.trace.office as TangMinistry)
    ))
    if (!belongsToSameExecution) {
      timeline.push(segment)
      continue
    }
    const owner = timeline[ownerIndex]!
    timeline[ownerIndex] = {
      ...owner,
      phases: [...owner.phases, ...segment.phases],
      updatedAt: Math.max(owner.updatedAt, segment.updatedAt),
    }
  }
  return timeline
}

/** Ministries belonging to one Shangshu execution block, stopping at the next governing office. */
export function shangshuExecutionSegments(
  timeline: readonly TangTimelineSegment[], shangshuIndex: number,
): TangTimelineSegment[] {
  if (timeline[shangshuIndex]?.trace.office !== 'shangshu') return []
  const following = timeline.slice(shangshuIndex + 1)
  const boundary = following.findIndex(segment => !TANG_MINISTRY_OFFICES.includes(segment.trace.office as TangMinistry))
  const block = boundary < 0 ? following : following.slice(0, boundary)
  return block.filter(segment => TANG_MINISTRY_OFFICES.includes(segment.trace.office as TangMinistry))
}

function sumTraceUsage(traces: readonly TangDepartmentTrace[]): TangTraceUsage {
  return traces.reduce<TangTraceUsage>((total, trace) => ({
    uncachedInputTokens: total.uncachedInputTokens + trace.usage.uncachedInputTokens,
    outputTokens: total.outputTokens + trace.usage.outputTokens,
    cacheReadTokens: total.cacheReadTokens + trace.usage.cacheReadTokens,
    cacheWriteTokens: total.cacheWriteTokens + trace.usage.cacheWriteTokens,
  }), ZERO_USAGE)
}

/**
 * Collapse every invocation of the same governing Department into one durable
 * rail card. Its invocation markers and milestones remain chronological inside
 * that card. All Ministry invocations are children of the single Shangshu card.
 */
export function groupTimelineByDepartment(
  chronological: readonly TangTimelineSegment[],
): TangTimelineSegment[] {
  const ministries = chronological
    .filter(segment => TANG_MINISTRY_OFFICES.includes(segment.trace.office as TangMinistry))
    .sort((left, right) => left.updatedAt - right.updatedAt || left.startedAt - right.startedAt)
  return TANG_DEPARTMENTS.flatMap((office) => {
    const departments = chronological
      .filter(segment => segment.trace.office === office)
      .sort((left, right) => left.startedAt - right.startedAt || left.updatedAt - right.updatedAt)
    if (departments.length === 0) return office === 'shangshu' ? ministries : []
    const invocations = [...new Map(departments.map(segment => [segment.trace.sessionId, segment.trace])).values()]
    const phases = departments.flatMap((segment): TangTracePhase[] => {
      const invocationTitle = segment.trace.invocationTitle ?? segment.trace.title
      const invocation = !segment.continuation && !segment.phases.some(phase => phase.title === invocationTitle)
        ? [{
            stage: 'intake' as const,
            title: invocationTitle,
            ...(segment.trace.summary === undefined ? {} : { summary: segment.trace.summary }),
            status: segment.phases.length > 0 ? 'succeeded' as const : segment.trace.status,
            updatedAt: segment.trace.startedAt ?? segment.startedAt,
          }]
        : []
      return [...invocation, ...segment.phases]
    }).sort((left, right) => left.updatedAt - right.updatedAt)
    const latest = departments.reduce((current, segment) => (
      segment.updatedAt >= current.updatedAt ? segment : current
    ))
    const firstPhaseTitle = phases[0]?.title ?? latest.trace.title
    const officeName = TANG_OFFICE_DEFINITIONS.find(definition => definition.id === office)?.name ?? latest.trace.officeName
    const trace: TangDepartmentTrace = {
      sessionId: `department:${office}`,
      office,
      officeName,
      depth: Math.min(...invocations.map(invocation => invocation.depth)),
      invocationTitle: firstPhaseTitle,
      title: officeName,
      ...(latest.trace.summary === undefined ? {} : { summary: latest.trace.summary }),
      ...(phases.at(-1)?.stage === undefined ? {} : { stage: phases.at(-1)!.stage }),
      status: latest.trace.status,
      startedAt: departments[0]!.startedAt,
      updatedAt: latest.updatedAt,
      phases,
      usage: sumTraceUsage(invocations),
    }
    const department: TangTimelineSegment = {
      key: `department:${office}`,
      trace,
      phases,
      startedAt: departments[0]!.startedAt,
      updatedAt: latest.updatedAt,
      continuation: false,
    }
    return office === 'shangshu' ? [department, ...ministries] : [department]
  })
}

function progressFromEvent(event: TangTraceEvent) {
  if (event.type !== 'tool/call') return null
  if (typeof event.data !== 'object' || event.data === null) return null
  const data = event.data as { readonly name?: unknown; readonly arguments?: unknown }
  if (data.name !== 'tang_progress' || typeof data.arguments !== 'string') return null
  try {
    return parseTangProgress(JSON.parse(data.arguments))
  } catch {
    return null
  }
}

function lastTurnReason(events: readonly TangTraceEvent[]): string | undefined {
  const terminal = events.findLast(event => event.type === 'turn/end')
  if (terminal === undefined || typeof terminal.data !== 'object' || terminal.data === null) return undefined
  const reason = (terminal.data as { readonly reason?: unknown }).reason
  if (typeof reason !== 'object' || reason === null) return undefined
  const kind = (reason as { readonly kind?: unknown }).kind
  return typeof kind === 'string' ? kind : undefined
}

function traceStatus(input: TangTraceInput, progressStatus: TangStatus | undefined): TangStatus {
  if (progressStatus === 'waiting_input'
    || progressStatus === 'waiting_approval'
    || progressStatus === 'remanded'
    || progressStatus === 'failed'
    || progressStatus === 'stopped'
    || progressStatus === 'skipped') return progressStatus
  if (input.activity === 'running') return 'running'
  if (progressStatus === 'passed' || progressStatus === 'succeeded') return progressStatus
  const reason = lastTurnReason(input.events)
  if (reason === 'completed') return 'succeeded'
  if (reason === 'aborted') return 'stopped'
  if (reason === 'error' || reason === 'max-tokens' || reason === 'blocked' || reason === 'interrupted') return 'failed'
  return 'pending'
}

function labelSummary(label: string | undefined, officeName: string): string {
  const stripped = label?.replace(/^\[[^\]]+\]\s*/, '').trim()
  return stripped === undefined || stripped === '' ? `${officeName}部门调用` : stripped
}

/** Build one outline row from an observed child session and its durable records. */
export function buildDepartmentTrace(input: TangTraceInput): TangDepartmentTrace {
  const definition = TANG_OFFICE_DEFINITIONS.find(office => office.id === input.office)
  if (definition === undefined) throw new Error(`unknown Tang office: ${input.office}`)
  const progressTransitions = input.events.flatMap((event): TangTracePhase[] => {
    const progress = progressFromEvent(event)
    if (progress === null) return []
    return [{
      stage: progress.stage,
      title: progress.title,
      ...(progress.summary === undefined ? {} : { summary: progress.summary }),
      status: progress.status,
      updatedAt: event.time,
    }]
  })
  const phases: TangTracePhase[] = []
  const transitional = new Set<TangStatus>(['pending', 'running', 'waiting_input', 'waiting_approval'])
  for (const transition of progressTransitions) {
    const previous = phases.at(-1)
    if (previous?.stage === transition.stage && transitional.has(previous.status)) {
      phases[phases.length - 1] = transition
      continue
    }
    if (previous !== undefined && transitional.has(previous.status)) {
      phases[phases.length - 1] = {
        ...previous,
        status: previous.status === 'waiting_approval' ? 'passed' : 'succeeded',
      }
    }
    phases.push(transition)
  }
  const latestPhase = phases.at(-1)
  if (input.office === 'zhongshu'
    && input.activity === 'running'
    && latestPhase?.stage === 'requirement-clarification'
    && (latestPhase.status === 'succeeded' || latestPhase.status === 'passed')) {
    phases.push({
      stage: 'zhongshu-draft',
      title: '正在起草需求与方案',
      summary: '需求已经澄清，中书省正在整理需求文档与初版方案。',
      status: 'running',
      updatedAt: input.events.at(-1)?.time ?? latestPhase.updatedAt,
    })
  }
  const progress = phases.at(-1)
  const fallback = labelSummary(input.label, definition.name)
  const title = progress?.title.trim() || fallback
  const summary = progress?.summary?.trim() || (title === fallback ? undefined : fallback)
  const startedAt = input.events.at(0)?.time
  const updatedAt = input.events.at(-1)?.time
  return {
    sessionId: input.sessionId,
    office: input.office,
    officeName: definition.name,
    depth: input.depth,
    invocationTitle: fallback,
    title,
    ...(summary === undefined ? {} : { summary }),
    ...(progress === null || progress === undefined ? {} : { stage: progress.stage }),
    status: traceStatus(input, progress?.status),
    ...(startedAt === undefined ? {} : { startedAt }),
    ...(updatedAt === undefined ? {} : { updatedAt }),
    phases,
    usage: parseTraceUsage(input.tokenUsage),
  }
}
