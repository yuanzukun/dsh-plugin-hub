/** Package companion reserved for Harness invariant discovery. */
import type { Context } from '@deepseek-ai/cordis'

export const name = 'tang-governance-invariant'

/** The plugin stores no custom Session event vocabulary requiring reconstruction checks. */
export function apply(_ctx: Context): void {}
