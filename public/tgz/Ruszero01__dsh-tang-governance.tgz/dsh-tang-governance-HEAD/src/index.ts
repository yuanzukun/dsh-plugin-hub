/** Host installer for the Tang governance preset and Web client. */
import { randomUUID } from 'node:crypto'
import { readFile, rename, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-agent-presets'

export const name = 'tang-governance'
export const inject = ['agentPresets']

const PRESET_ID = 'tang'
const MARKER = '.dsh-tang-governance.json'
const TOOL_ROW = "\n# Managed by dsh-tang-governance.\n- id: tang-governance-tool\n  name: 'dsh-tang-governance/tool'\n"

interface ManagedMarker {
  readonly package: 'dsh-tang-governance'
  readonly presetVersion: 1
}

async function atomicWrite(path: string, content: string): Promise<void> {
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`
  await writeFile(temporary, content, 'utf8')
  await rename(temporary, path)
}

async function markerAt(directory: string): Promise<ManagedMarker | null> {
  try {
    const value = JSON.parse(await readFile(join(directory, MARKER), 'utf8')) as Partial<ManagedMarker>
    return value.package === 'dsh-tang-governance' && value.presetVersion === 1
      ? { package: value.package, presetVersion: value.presetVersion }
      : null
  } catch {
    return null
  }
}

async function finishManagedPreset(compositionPath: string): Promise<void> {
  const directory = dirname(compositionPath)
  const composition = await readFile(compositionPath, 'utf8')
  if (!composition.includes("name: 'dsh-tang-governance/tool'")) {
    await atomicWrite(compositionPath, composition.trimEnd() + TOOL_ROW)
  }
  await atomicWrite(join(directory, 'preset.yml'), [
    'name: 三省六部模式',
    'description: 中书起草、门下封驳、用户审批、尚书执行、六部分工、门下验收与中书归档。',
    'order: 5',
    '',
  ].join('\n'))
  await atomicWrite(join(directory, MARKER), `${JSON.stringify({
    package: 'dsh-tang-governance',
    presetVersion: 1,
  } satisfies ManagedMarker, null, 2)}\n`)
}

/** Install a user-root preset derived from the target Harness version's standard preset. */
export async function apply(ctx: Context): Promise<void> {
  const existing = (await ctx.agentPresets.list()).find(preset => preset.id === PRESET_ID)
  if (existing === undefined) {
    await ctx.agentPresets.copy('standard', PRESET_ID, '三省六部模式')
    const copied = await ctx.agentPresets.resolve(PRESET_ID)
    await finishManagedPreset(copied.path)
    ctx.logger.info('installed Tang governance preset "tang" from this Harness version\'s standard preset')
    return
  }

  const directory = dirname(existing.path)
  if (await markerAt(directory) === null) {
    ctx.logger.warn('preset "tang" already exists and is not managed by dsh-tang-governance; leaving it unchanged')
    return
  }
  await finishManagedPreset(existing.path)
}
