/** Stable office identifiers used by tools, prompts, and the Web client. */
export const TANG_OFFICES = [
  'zhongshu',
  'menxia',
  'shangshu',
  'personnel',
  'revenue',
  'rites',
  'war',
  'justice',
  'works',
] as const

export type TangOffice = typeof TANG_OFFICES[number]

/** The three offices whose model route is user-selectable in the organization chart. */
export const TANG_DEPARTMENTS = ['zhongshu', 'menxia', 'shangshu'] as const

export type TangDepartment = typeof TANG_DEPARTMENTS[number]

/** The six execution-only offices available to Shangshu. */
export const TANG_MINISTRY_OFFICES = ['personnel', 'revenue', 'rites', 'war', 'justice', 'works'] as const

export type TangMinistry = typeof TANG_MINISTRY_OFFICES[number]

/** Settings namespace shared by the Host router and browser controls. */
export const TANG_SETTINGS_NAMESPACE = 'tang-governance'

/** Stable question id used to route the mandatory plan review into the Tang panel. */
export const TANG_APPROVAL_QUESTION_ID = 'tang-user-approval'

/** Stable question id used to route the final case report into the Tang panel. */
export const TANG_CLOSURE_QUESTION_ID = 'tang-final-report'

/** Prefix used to route Zhongshu requirement clarification into the Tang dashboard. */
export const TANG_CLARIFICATION_QUESTION_PREFIX = 'tang-clarification:'

/** Exact option labels shared by the approval tool, authority check, and browser modal. */
export const TANG_APPROVE_LABEL = '批准执行'
export const TANG_REMAND_LABEL = '驳回修改'
export const TANG_CLOSE_LABEL = '确认结案'

/** One office's optional override over the route inherited from its parent agent. */
export interface TangOfficeRoute {
  readonly provider?: string
  readonly model?: string
  readonly reasoningEffort?: string
  readonly maxTokens?: number
}

/** Durable user-selected routes for the three Departments. */
export type TangDepartmentRoutes = Partial<Record<TangDepartment, TangOfficeRoute>>

/** Durable workflow stages recorded through ordinary tool calls. */
export const TANG_STAGES = [
  'intake',
  'requirement-clarification',
  'zhongshu-draft',
  'menxia-review',
  'countersign',
  'user-approval',
  'shangshu-dispatch',
  'ministry-execution',
  'menxia-acceptance',
  'zhongshu-report',
  'case-closure',
  'chronicle',
] as const

export type TangStage = typeof TANG_STAGES[number]

/** Status values shown on the task timeline. */
export const TANG_STATUSES = [
  'pending',
  'running',
  'waiting_input',
  'waiting_approval',
  'succeeded',
  'passed',
  'remanded',
  'failed',
  'stopped',
  'skipped',
] as const

export type TangStatus = typeof TANG_STATUSES[number]

/** Arguments and result of one tang_progress call. */
export interface TangProgressRecord {
  readonly caseId: string
  readonly stage: TangStage
  readonly office: TangOffice
  readonly status: TangStatus
  readonly title: string
  readonly summary?: string
  readonly artifactPath?: string
}

/** Display metadata for the fixed organization chart. */
export interface TangOfficeDefinition {
  readonly id: TangOffice
  readonly name: string
  readonly english: string
  readonly duty: string
  readonly tier: 'department' | 'ministry'
}

export const TANG_OFFICE_DEFINITIONS: readonly TangOfficeDefinition[] = [
  { id: 'zhongshu', name: '中书省', english: 'Secretariat', duty: '需求理解、方案起草、会签与最终奏报', tier: 'department' },
  { id: 'menxia', name: '门下省', english: 'Chancellery', duty: '独立审查、封驳、验收与放行', tier: 'department' },
  { id: 'shangshu', name: '尚书省', english: 'Department of State Affairs', duty: '统筹实现、拆分阶段、调度六部', tier: 'department' },
  { id: 'personnel', name: '吏部', english: 'Personnel', duty: '仓库结构、模块边界、归属依赖与协作编排', tier: 'ministry' },
  { id: 'revenue', name: '户部', english: 'Revenue', duty: '数据状态、存储迁移、依赖资源与性能容量', tier: 'ministry' },
  { id: 'rites', name: '礼部', english: 'Rites', duty: 'API／界面契约、兼容可达性、文档与体验', tier: 'ministry' },
  { id: 'war', name: '兵部', english: 'War', duty: '业务功能、核心代码、重构与应用迁移', tier: 'ministry' },
  { id: 'justice', name: '刑部', english: 'Justice', duty: '缺陷复现、测试回归、安全审计与质量修复', tier: 'ministry' },
  { id: 'works', name: '工部', english: 'Works', duty: '构建工具、运行环境、集成打包与部署发布', tier: 'ministry' },
]

/** Parse and validate model-produced progress arguments. */
export function parseTangProgress(value: unknown): TangProgressRecord | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null
  const record = value as Record<string, unknown>
  if (typeof record.case_id !== 'string' || record.case_id.trim() === '') return null
  if (!TANG_STAGES.includes(record.stage as TangStage)) return null
  if (!TANG_OFFICES.includes(record.office as TangOffice)) return null
  if (!TANG_STATUSES.includes(record.status as TangStatus)) return null
  if (typeof record.title !== 'string' || record.title.trim() === '') return null
  if (record.summary !== undefined && typeof record.summary !== 'string') return null
  if (record.artifact_path !== undefined && typeof record.artifact_path !== 'string') return null
  return {
    caseId: record.case_id,
    stage: record.stage as TangStage,
    office: record.office as TangOffice,
    status: record.status as TangStatus,
    title: record.title,
    ...(record.summary === undefined ? {} : { summary: record.summary }),
    ...(record.artifact_path === undefined ? {} : { artifactPath: record.artifact_path }),
  }
}
