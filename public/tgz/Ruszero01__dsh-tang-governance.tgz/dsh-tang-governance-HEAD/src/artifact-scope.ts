/** Submission boundaries for governance artifacts, not a filesystem sandbox. */
export function assertCaseId(caseId: string): void {
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(caseId)) throw new Error('case_id must be a filesystem-safe case id')
}

/** Only unambiguous workspace-relative artifacts owned by this case are accepted. */
export function assertCaseArtifact(path: string, caseId: string, field: string): void {
  assertCaseId(caseId)
  const normalized = path.replace(/\\/g, '/').replace(/^\.\//, '')
  const prefix = `.tang/cases/${caseId}/`
  if (!normalized.startsWith(prefix) || normalized.length <= prefix.length
    || normalized.split('/').some(segment => segment === '..' || segment === '.' || segment === ''
      || /[:\x00-\x1f]/.test(segment) || /[. ]$/.test(segment))) {
    throw new Error(`${field} must use a workspace-relative artifact under ${prefix}; shared evidence directories, other cases, absolute paths and traversal are not allowed`)
  }
}

/** Evidence can contain commands/source files. Validate explicit .tang references. */
export function assertCaseReferences(values: readonly string[], caseId: string, field: string): void {
  assertCaseId(caseId)
  for (const value of values) {
    const tokens = value.match(/[^\s`'"<>()[\]{},;，；。]+/g) ?? []
    for (const token of tokens) {
      if (/(?:^|[\\/])\.tang(?:[\\/]|$)/i.test(token)) assertCaseArtifact(token, caseId, field)
    }
  }
}
