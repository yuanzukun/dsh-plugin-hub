/** Tang workflow coordinator tools and system instructions. */
import { createHash } from 'node:crypto'
import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import type { AgentOptions, PreStepDecision } from '@deepseek-ai/dsh-agent'
import type { ContentBlock, LlmCallConfig, LlmModelReasoningInfo, UserMessage } from '@deepseek-ai/dsh-llm'
import { ReasoningEffortId } from '@deepseek-ai/dsh-llm/brand'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'
import type {} from '@deepseek-ai/dsh-subagent'
import { SessionId, type SessionEvent } from '@deepseek-ai/dsh-session'
import { assertCaseArtifact, assertCaseId, assertCaseReferences } from './artifact-scope.ts'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type {} from '@deepseek-ai/dsh-user-questions'
import {
  parseTangProgress, TANG_APPROVAL_QUESTION_ID, TANG_APPROVE_LABEL, TANG_CLARIFICATION_QUESTION_PREFIX, TANG_CLOSE_LABEL,
  TANG_CLOSURE_QUESTION_ID, TANG_DEPARTMENTS, TANG_MINISTRY_OFFICES, TANG_OFFICES,
  TANG_REMAND_LABEL, TANG_SETTINGS_NAMESPACE, TANG_STAGES, TANG_STATUSES,
  type TangDepartmentRoutes, type TangMinistry, type TangOffice, type TangOfficeRoute, type TangProgressRecord,
} from './contracts.ts'

export const name = 'tang-governance-tool'
export const inject = ['tools', 'systemPrompt', 'subagents', 'userQuestions', 'llm']

export interface Config {
  /** Subagent backend registered in the target Harness profile. */
  readonly subagentProvider?: string
  /** Automatically dispatch the first user requirement to Zhongshu. */
  readonly autoDispatch?: boolean
  /** Optional provider/model route per office. Omitted offices inherit the parent route. */
  readonly offices?: Partial<Record<TangOffice, TangOfficeRoute>>
}

const OfficeRouteSchema: z<TangOfficeRoute> = z.object({
  provider: z.string(),
  model: z.string(),
  reasoningEffort: z.string(),
  maxTokens: z.number().min(1),
})

const DepartmentRoutesSchema: z<TangDepartmentRoutes> = z.object({
  zhongshu: OfficeRouteSchema,
  menxia: OfficeRouteSchema,
  shangshu: OfficeRouteSchema,
})

const OFFICE_LABELS: Record<TangOffice, string> = {
  zhongshu: '中书省',
  menxia: '门下省',
  shangshu: '尚书省',
  personnel: '吏部',
  revenue: '户部',
  rites: '礼部',
  war: '兵部',
  justice: '刑部',
  works: '工部',
}

const MINISTRIES = new Set<TangOffice>(TANG_MINISTRY_OFFICES)
const DEPARTMENTS = new Set<TangOffice>(['zhongshu', 'menxia', 'shangshu'])
const MINISTRY_DOMAINS = {
  personnel: 'repository-governance',
  revenue: 'data-dependencies',
  rites: 'interfaces-documentation',
  war: 'application-code',
  justice: 'quality-security',
  works: 'infrastructure-release',
} as const satisfies Record<TangMinistry, string>
const MINISTRY_ROLES = {
  personnel: new Set(['analysis', 'implementation', 'documentation', 'integration']),
  revenue: new Set(['analysis', 'implementation', 'verification']),
  rites: new Set(['analysis', 'implementation', 'documentation', 'verification']),
  war: new Set(['implementation']),
  justice: new Set(['analysis', 'implementation', 'verification']),
  works: new Set(['analysis', 'implementation', 'verification', 'integration']),
} as const satisfies Record<TangMinistry, ReadonlySet<string>>
const MINISTRY_MANDATES: Record<TangMinistry, string> = {
  personnel: 'Own repository topology, module and package boundaries, ownership, workspace wiring, dependency order, task handoffs, and bounded repository-structure changes. Do not absorb business behavior, release engineering, or final acceptance.',
  revenue: 'Own data and state models, persistence and migrations, dependencies and licenses, resource budgets, caching, capacity, and performance-sensitive changes with measurable evidence. Do not absorb unrelated product behavior or final acceptance.',
  rites: 'Own API, schema, and UI contracts, compatibility, accessibility, user-facing behavior, documentation, and contract-facing implementation with observable experience checks. Do not own unrelated infrastructure or final acceptance.',
  war: 'Own application features, core source changes, refactors, and code migrations. Stay within application-code surfaces and do not absorb build or release work.',
  justice: 'Own defect reproduction, test assets and harnesses, regression coverage, security and permission audits, and bounded quality or security remediation. Keep verification evidence explicit; Menxia remains the independent final acceptance authority.',
  works: 'Own build systems, developer tooling, runtime environments, infrastructure, cross-package integration, packaging, deployment, release automation, and release-readiness evidence. Do not absorb product-feature implementation.',
}

const REASONING_EFFORT_ORDER = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra'] as const
const GENERIC_OMISSION_REASON = /^(?:无|无需|不需要|未涉及|不涉及|not needed|none|n\/?a|unnecessary)[。.!！\s]*$/i
const WORKSPACE_KNOWLEDGE_RELATIVE_PATH = '.tang/workspace-knowledge.md'
const KNOWLEDGE_DATA_START = '<!-- TANG_WORKSPACE_KNOWLEDGE_DATA_START'
const KNOWLEDGE_DATA_END = 'TANG_WORKSPACE_KNOWLEDGE_DATA_END -->'
const KNOWLEDGE_KINDS = ['decision', 'constraint', 'pattern', 'pitfall', 'verification'] as const
const KNOWLEDGE_STATES = ['provisional', 'confirmed', 'superseded'] as const
const knowledgeLocks = new Map<string, Promise<void>>()

const TANG_CASE_SCALES = ['small', 'medium', 'large'] as const
type TangCaseScale = typeof TANG_CASE_SCALES[number]

const CASE_SCALE_POLICY = {
  small: {
    targetTokens: 4_000,
    review: 'Concise single-pass review of scope, feasibility, regression risk, and acceptance criteria.',
    execution: 'Prefer one bounded phase and the minimum justified offices; reuse accepted artifacts and avoid ceremonial loops.',
  },
  medium: {
    targetTokens: 8_000,
    review: 'Normal review of interfaces, compatibility, failure modes, verification, and rollback concerns.',
    execution: 'Use a small number of dependency-ordered phases and only offices justified by changed surfaces.',
  },
  large: {
    targetTokens: 16_000,
    review: 'Deep review of architecture, migrations, security, compatibility, rollout, rollback, and unresolved choices.',
    execution: 'Multiple risk-ordered phases with explicit checkpoints and broader verification where justified.',
  },
} as const satisfies Record<TangCaseScale, {
  readonly targetTokens: number
  readonly review: string
  readonly execution: string
}>

type KnowledgeKind = typeof KNOWLEDGE_KINDS[number]
type KnowledgeState = typeof KNOWLEDGE_STATES[number]

interface KnowledgeEvidence {
  readonly caseId: string
  readonly artifact: string
  readonly note: string
}

interface WorkspaceKnowledgeEntry {
  readonly id: string
  readonly key: string
  readonly kind: KnowledgeKind
  readonly topic: string
  readonly scope: string
  readonly summary: string
  readonly details: string
  readonly state: KnowledgeState
  readonly sourceCases: readonly string[]
  readonly evidence: readonly KnowledgeEvidence[]
  readonly supersedes: readonly string[]
  readonly updatedAt: string
}

interface WorkspaceKnowledgeStore {
  readonly version: 1
  readonly entries: readonly WorkspaceKnowledgeEntry[]
}

interface KnowledgeUpsertInput {
  readonly key: string
  readonly kind: KnowledgeKind
  readonly topic: string
  readonly scope: string
  readonly summary: string
  readonly details: string
  readonly state: Exclude<KnowledgeState, 'superseded'>
  readonly evidence: readonly { readonly artifact: string; readonly note: string }[]
  readonly supersedes?: readonly string[]
}

interface WorkspaceKnowledgeArgs {
  readonly operation: 'head' | 'details' | 'sources' | 'upsert' | 'no_change'
  readonly case_id?: string
  readonly knowledge_ids?: readonly string[]
  readonly source_artifacts?: readonly string[]
  readonly entries?: readonly KnowledgeUpsertInput[]
  readonly reason?: string
}

const EMPTY_KNOWLEDGE_STORE: WorkspaceKnowledgeStore = { version: 1, entries: [] }

function knowledgePath(cwd: string): string {
  return resolve(cwd, WORKSPACE_KNOWLEDGE_RELATIVE_PATH)
}

function markdownCell(value: string): string {
  return value.replace(/\|/g, '\\|').replace(/\r?\n/g, ' ').trim()
}

function knowledgeId(key: string): string {
  return `K-${createHash('sha256').update(key).digest('hex').slice(0, 10).toUpperCase()}`
}

function renderKnowledgeHead(store: WorkspaceKnowledgeStore): string {
  const rows = [...store.entries]
    .filter(entry => entry.state !== 'superseded')
    .sort((left, right) => left.key.localeCompare(right.key))
    .map(entry => `| ${entry.id} | ${entry.kind} | ${markdownCell(entry.topic)} | ${markdownCell(entry.scope)} | ${entry.state} | ${entry.sourceCases.join(', ')} | ${markdownCell(entry.summary)} |`)
  return [
    '## 渐进披露入口',
    '',
    '- 新案只预载本节。先用索引判断是否存在相关经验，不要默认读取全部详情。',
    '- 需要依据时调用 `tang_workspace_knowledge` 的 `details`；只有需要核对原始事实时再调用 `sources`。',
    '- `key` 是跨案唯一语义键；同一知识必须更新原键，不得换名重复追加。',
    '- 详情只保留可复用的决定、约束、模式、踩坑和验证经验；案情流水留在来源案卷。',
    '',
    '## 知识索引',
    '',
    '| ID | 类型 | 主题 | 适用范围 | 状态 | 来源案卷 | 一句话结论 |',
    '| --- | --- | --- | --- | --- | --- | --- |',
    ...(rows.length === 0 ? ['| — | — | 暂无可复用知识 | — | — | — | 新案结案时按需沉淀 |'] : rows),
  ].join('\n')
}

function renderKnowledgeEntry(entry: WorkspaceKnowledgeEntry): string {
  const evidence = entry.evidence.map(item => `- [${item.caseId}] \`${item.artifact}\` — ${item.note}`)
  return [
    `### ${entry.id} · ${entry.topic}`,
    '',
    `- 唯一键：\`${entry.key}\``,
    `- 类型：${entry.kind}`,
    `- 适用范围：${entry.scope}`,
    `- 状态：${entry.state}`,
    `- 来源案卷：${entry.sourceCases.join(', ')}`,
    ...(entry.supersedes.length === 0 ? [] : [`- 取代条目：${entry.supersedes.join(', ')}`]),
    '',
    '#### 结论',
    '',
    entry.summary,
    '',
    '#### 经验详情',
    '',
    entry.details,
    '',
    '#### 原案证据',
    '',
    ...(evidence.length === 0 ? ['- 无'] : evidence),
  ].join('\n')
}

function renderKnowledgeDocument(store: WorkspaceKnowledgeStore): string {
  const active = [...store.entries].sort((left, right) => left.key.localeCompare(right.key))
  const encoded = Buffer.from(JSON.stringify(store), 'utf8').toString('base64')
  return [
    '# 工作区知识案卷',
    '',
    '> 本文件是当前工作区所有案卷共同维护的唯一知识源。索引用于快速定位，详情用于按需展开，原始事实仍以标注的案卷文件为准。',
    '> 文件由 `tang_workspace_knowledge` 结构化维护；请勿手工复制条目或把执行流水追加到这里。',
    '',
    '<!-- TANG_WORKSPACE_KNOWLEDGE_HEAD_START -->',
    renderKnowledgeHead(store),
    '<!-- TANG_WORKSPACE_KNOWLEDGE_HEAD_END -->',
    '',
    '## 知识详情',
    '',
    ...(active.length === 0 ? ['暂无条目。'] : active.flatMap(entry => [renderKnowledgeEntry(entry), ''])),
    KNOWLEDGE_DATA_START,
    encoded,
    KNOWLEDGE_DATA_END,
    '',
  ].join('\n')
}

function isKnowledgeEntry(value: unknown): value is WorkspaceKnowledgeEntry {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false
  const record = value as Record<string, unknown>
  return typeof record.id === 'string'
    && typeof record.key === 'string'
    && KNOWLEDGE_KINDS.includes(record.kind as KnowledgeKind)
    && typeof record.topic === 'string'
    && typeof record.scope === 'string'
    && typeof record.summary === 'string'
    && typeof record.details === 'string'
    && KNOWLEDGE_STATES.includes(record.state as KnowledgeState)
    && Array.isArray(record.sourceCases)
    && record.sourceCases.length > 0
    && record.sourceCases.every(item => typeof item === 'string')
    && Array.isArray(record.evidence)
    && record.evidence.length > 0
    && record.evidence.every(item => typeof item === 'object' && item !== null
      && typeof (item as Record<string, unknown>).caseId === 'string'
      && typeof (item as Record<string, unknown>).artifact === 'string'
      && typeof (item as Record<string, unknown>).note === 'string')
    && Array.isArray(record.supersedes)
    && record.supersedes.every(item => typeof item === 'string')
    && typeof record.updatedAt === 'string'
}

function parseKnowledgeDocument(content: string): WorkspaceKnowledgeStore {
  const start = content.indexOf(KNOWLEDGE_DATA_START)
  const end = content.indexOf(KNOWLEDGE_DATA_END, start + KNOWLEDGE_DATA_START.length)
  if (start === -1 || end === -1) {
    throw new Error(`${WORKSPACE_KNOWLEDGE_RELATIVE_PATH} is not a Tang-managed knowledge document`)
  }
  const encoded = content.slice(start + KNOWLEDGE_DATA_START.length, end).trim()
  let value: unknown
  try {
    value = JSON.parse(Buffer.from(encoded, 'base64').toString('utf8'))
  } catch {
    throw new Error(`${WORKSPACE_KNOWLEDGE_RELATIVE_PATH} contains invalid canonical data`)
  }
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error(`${WORKSPACE_KNOWLEDGE_RELATIVE_PATH} contains invalid canonical data`)
  }
  const record = value as Record<string, unknown>
  if (record.version !== 1 || !Array.isArray(record.entries) || !record.entries.every(isKnowledgeEntry)) {
    throw new Error(`${WORKSPACE_KNOWLEDGE_RELATIVE_PATH} uses an unsupported knowledge schema`)
  }
  const store = value as WorkspaceKnowledgeStore
  const ids = new Set<string>()
  const keys = new Set<string>()
  for (const entry of store.entries) {
    if (entry.id !== knowledgeId(entry.key)) throw new Error(`knowledge id does not match semantic key: ${entry.key}`)
    if (ids.has(entry.id) || keys.has(entry.key)) throw new Error(`duplicate workspace knowledge entry: ${entry.id}`)
    ids.add(entry.id)
    keys.add(entry.key)
    const sourceCases = new Set(entry.sourceCases)
    for (const caseId of entry.sourceCases) validCaseId(caseId, `${entry.id} source case`)
    for (const evidence of entry.evidence) {
      validCaseId(evidence.caseId, `${entry.id} evidence case`)
      normalizedCaseArtifact(evidence.artifact, `${entry.id} evidence artifact`, evidence.caseId)
      if (!sourceCases.has(evidence.caseId)) throw new Error(`${entry.id} evidence cites an unlisted source case`)
    }
  }
  for (const entry of store.entries) {
    for (const supersededId of entry.supersedes) {
      if (!ids.has(supersededId)) throw new Error(`${entry.id} supersedes unknown knowledge id: ${supersededId}`)
    }
  }
  return store
}

async function readKnowledgeStore(cwd: string): Promise<WorkspaceKnowledgeStore> {
  try {
    return parseKnowledgeDocument(await readFile(knowledgePath(cwd), 'utf8'))
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return EMPTY_KNOWLEDGE_STORE
    throw error
  }
}

async function writeKnowledgeStore(cwd: string, store: WorkspaceKnowledgeStore): Promise<void> {
  const path = knowledgePath(cwd)
  await mkdir(dirname(path), { recursive: true })
  const temporaryPath = `${path}.${process.pid}.${Date.now()}.tmp`
  try {
    await writeFile(temporaryPath, renderKnowledgeDocument(store), 'utf8')
    await rename(temporaryPath, path)
  } finally {
    await rm(temporaryPath, { force: true })
  }
}

async function ensureKnowledgeDocument(cwd: string): Promise<WorkspaceKnowledgeStore> {
  const store = await readKnowledgeStore(cwd)
  if (store === EMPTY_KNOWLEDGE_STORE) {
    const path = knowledgePath(cwd)
    await mkdir(dirname(path), { recursive: true })
    try {
      await writeFile(path, renderKnowledgeDocument(store), { encoding: 'utf8', flag: 'wx' })
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error
      return await readKnowledgeStore(cwd)
    }
  }
  return store
}

async function withKnowledgeLock<T>(path: string, operation: () => Promise<T>): Promise<T> {
  const previous = knowledgeLocks.get(path) ?? Promise.resolve()
  let release!: () => void
  const current = new Promise<void>(resolve => { release = resolve })
  const queued = previous.then(() => current)
  knowledgeLocks.set(path, queued)
  await previous
  try {
    return await operation()
  } finally {
    release()
    if (knowledgeLocks.get(path) === queued) knowledgeLocks.delete(path)
  }
}

async function knowledgeHeadForSession(cwd: string | undefined): Promise<string> {
  if (cwd === undefined || cwd.trim() === '') {
    return `${renderKnowledgeHead(EMPTY_KNOWLEDGE_STORE)}\n\n> 当前会话未提供工作目录，无法持久化共享知识。`
  }
  try {
    return renderKnowledgeHead(await ensureKnowledgeDocument(cwd))
  } catch (error) {
    return `${renderKnowledgeHead(EMPTY_KNOWLEDGE_STORE)}\n\n> 共享知识载入失败：${error instanceof Error ? error.message : String(error)}`
  }
}

function promptWithKnowledgeHead(prompt: string, head: string): string {
  const newline = prompt.indexOf('\n')
  const block = [
    `<tang-workspace-knowledge-head path="${WORKSPACE_KNOWLEDGE_RELATIVE_PATH}">`,
    head,
    '</tang-workspace-knowledge-head>',
  ].join('\n')
  return newline === -1
    ? `${prompt}\n${block}`
    : `${prompt.slice(0, newline + 1)}${block}\n${prompt.slice(newline + 1)}`
}
const SYSTEM_PROMPT = String.raw`
You are the coordinator of the Tang governance development mode. This is an executable software-delivery protocol, not historical role-play.

Authority and delegation:
- The top-level agent is the coordinator. It may delegate only Zhongshu, Menxia, and Shangshu work.
- Shangshu is an execution governor, not a catch-all implementer. It reads the approved artifacts, plans each phase, delegates bounded work, waits for dependency-complete reports, and verifies phase evidence. It must not edit product files itself.
- Before delegating any Ministry in a phase, Shangshu must call tang_plan_ministries. The plan accounts for all Six Ministries: selected offices receive typed assignments and every omitted office receives a concrete reason. Ministry routing in earlier drafts is advisory; approved user-visible scope is fixed, but Shangshu must correct an ill-fitted office assignment. After each child explicitly reports success or failure, Shangshu records its evidence with tang_record_ministry_result; dependent assignments cannot start until every dependency is recorded succeeded.
- Every ministry inherits Shangshu's provider and model. Each tang_delegate call for a Ministry cites an assignment_id from the accepted phase plan and uses that assignment's reasoning_effort. A ministry only executes its assignment and reports success or failure; it cannot approve, remand, reinterpret scope, or speak for the user.
- Zhongshu, Menxia, and Shangshu may pass or remand work inside their jurisdiction. Menxia is the independent review and final acceptance authority.
- Use tang_delegate with the exact office id. Every child prompt must begin with TANG_OFFICE:<office-id> and state its inputs, authority, required artifacts, and independently verifiable completion condition.

Six Ministries responsibility matrix:
- Personnel (吏部), domain repository-governance: repository maps, module/package ownership, workspace and dependency wiring, task handoffs, and bounded repository-structure changes.
- Revenue (户部), domain data-dependencies: schemas and state, persistence and migrations, dependencies and licenses, caching, resource/capacity budgets, performance changes, and measurements.
- Rites (礼部), domain interfaces-documentation: API/schema/UI contracts, compatibility, accessibility, user-facing behavior, documentation, contract-facing implementation, and experience checks.
- War (兵部), domain application-code: product behavior, core source changes, refactors, application migrations, and focused implementation evidence.
- Justice (刑部), domain quality-security: defect reproduction, test assets and harnesses, regression coverage, security/permission audits, and bounded quality or security remediation.
- Works (工部), domain infrastructure-release: build systems, developer tooling, runtime environments, infrastructure, cross-package integration, packaging, deployment, release automation, and release-readiness checks.
- Before submitting a phase plan, Shangshu performs one fixed responsibility scan across all Six Ministries: Personnel for repository topology, ownership, module boundaries, workspace wiring, or dependency-order changes; Revenue for data, state, storage, migration, dependency, license, resource, cache, capacity, or performance changes; Rites for API/schema/UI contracts, compatibility, accessibility, documentation, or user-facing behavior; War for product behavior and application source implementation; Justice for defects, tests, quality, security, permissions, or regression work; Works for build, tooling, runtime, infrastructure, cross-package integration, packaging, deployment, or release work. Each office must appear either in assignments or omissions exactly once at office level.
- A selected Ministry must produce a concrete artifact, code/configuration change, measurement, or independently inspectable evidence consumed by the phase. Do not assign an office merely to restate the approved documents or produce ceremonial commentary.
- An omission is still part of responsibility planning. Its reason must cite a concrete fact from the approved phase or changed-surface scan; generic phrases such as "not needed", "none", or "不需要" are invalid. Multiple bounded assignments for one selected office are allowed when justified.
- Do not activate all Ministries ceremonially and do not begin from a preferred office combination. Use only the offices justified by changed surfaces and risks, explicitly record omissions, give each assignment one bounded responsibility, and let Shangshu coordinate dependencies across whichever offices the scan selects.

Case-scale proportionality:
- small: a bounded, low-risk change with few affected surfaces and clear acceptance. Keep artifacts concise, use one Menxia review pass unless it finds a concrete blocker, avoid repeated countersign loops, and let Shangshu prefer one bounded execution phase with the minimum justified offices. Reuse existing child sessions and artifacts when possible.
- medium: multiple related changes, an interface or compatibility concern, or moderate uncertainty. Use normal review depth and a small number of dependency-ordered phases.
- large: cross-cutting architecture, migrations, security/permission risk, broad compatibility, rollout complexity, or substantial unknowns. Use deep review, explicit risk checkpoints, and phased execution.
- Scale is revisable, not a trap. When evidence shows the current scale is wrong, record one concrete reclassification, preserve completed artifacts, and continue from them. Never restart the whole workflow merely to change scale.
- Reduce token use primarily by avoiding unnecessary agents, repeated review loops, duplicate repository reconnaissance, and oversized artifacts. Output caps are generous safety rails; do not deliberately consume them and do not truncate necessary evidence just to hit a target.

Required flow:
1. The runtime automatically dispatches the first user requirement to Zhongshu before your first model request. Do not answer or implement the requirement directly and do not create a duplicate Zhongshu child. Record intake with tang_progress, acknowledge the dispatched child, and act only as coordinator. Create a case id and use .tang/cases/<case-id>/ as the case directory. The runtime also injects the compact head of .tang/workspace-knowledge.md into Zhongshu before case analysis. Treat that file as the workspace-wide canonical knowledge source: use the injected index first, call tang_workspace_knowledge details only for relevant entries, and call sources only when the original case evidence must be checked. Do not preload the full document.
2. Zhongshu owns a continuous clarification gate from intake until its draft is accepted for Menxia review; clarification is not a one-time opening check. Before drafting it inspects only enough workspace context to identify ambiguity. Before claiming the requirement is clear, before writing artifacts, and again before reporting completion, it must check whether any missing user decision would materially change scope, scale, architecture direction, behavior, or acceptance. If such a decision is found at any time—including during repository inspection or after provisional artifacts were written—Zhongshu must stop, treat those artifacts as provisional, record requirement-clarification as waiting_input, call tang_raise_clarification with one to three blocking questions, and end its turn. It must not guess, hide the choice in a "pending user decisions" table, report drafting complete, or permit Menxia delegation. Zhongshu must never invoke a generic/default user-question mechanism or ask the user directly; only the coordinator may open the user interaction channel through tang_request_clarification. The coordinator relays the reported bundle, waits for the answer, and resumes the same Zhongshu conversation. After answers arrive Zhongshu records requirement-clarification as succeeded and revalidates the draft. When no blocking ambiguity exists, Zhongshu still records requirement-clarification as succeeded before zhongshu-draft becomes running. Requirements include goals, non-goals, constraints, user-visible behavior, failure modes, acceptance criteria, and exactly one case_scale: small, medium, or large. The draft solution records decision-level architecture direction, affected capability surfaces, compatibility constraints, alternatives, and risks; it must not prescribe function-level code, exact patches, file-by-file implementation steps, or Ministry assignments. Zhongshu assesses only requirement magnitude, changed surfaces, uncertainty, and risk; it must not select Ministries, assign offices, or produce the execution phase plan. Ask only blocking questions, offer two to four concrete choices when possible, put the recommended choice first, and never restart Zhongshu after clarification.
3. Delegate Menxia with the same case_scale to review independently. Menxia writes 03-review.md and 04-spec.md. Its review depth is proportional to the scale: small gets a concise scope/feasibility/regression check; medium adds interface, compatibility, failure-mode, and rollback review; large adds architecture, migration, security, rollout, and unresolved-choice review. The spec is normative and testable: it defines scope, contracts, acceptance criteria, verification expectations, failure handling, risk, and rollback without becoming a code recipe or assigning Ministries. Menxia may remand an under- or over-classified scale with concrete evidence, but must not plan Ministry routing or write Shangshu's execution phases.
4. Return Menxia changes to Zhongshu. Repeat review only for concrete unresolved issues until both explicitly countersign the same scale and spec. Record every remand and pass; do not create ceremonial review loops for a small bounded task.
5. MANDATORY USER GATE: record user-approval as waiting_approval, read the countersigned requirements and spec, then call tang_request_approval with a complete Markdown proposal that lets the user review scale, scope, architecture, acceptance criteria, verification expectations, risks, and unresolved choices without leaving the Tang panel. Do not create Shangshu or any ministry before tang_request_approval returns approved and user-approval is recorded as passed. A remand records user-approval as remanded and returns the user's feedback to Zhongshu/Menxia. A cancelled approval stops the task. Silence, dismissal, conversational optimism, or an ambiguous answer is not approval.
6. After approval only, delegate Shangshu with the approved spec and case_scale. Shangshu alone writes 05-phased-development.md and owns execution planning. This document defines phase objectives, changed surfaces, boundaries, dependencies, Ministry deliverables, verification, risks, checkpoints, and rollback; it does not dictate function bodies, exact patches, or other code-level implementation choices that belong to the selected Ministry. A small case normally fits one bounded phase, a medium case usually needs only a few dependency-ordered phases, and a large case may use multiple risk-ordered phases with checkpoints; these are defaults, not hard limits. For each phase Shangshu classifies changed surfaces, risks, deliverables, and dependencies, then applies the same procedure to every Ministry: compare the phase with that Ministry's declared domain and roles, assign it when matched or record a concrete omission when unmatched. Shangshu then calls tang_plan_ministries, delegates only the selected assignments in dependency order, and records every returned result with tang_record_ministry_result. No Ministry is preferred, mandatory, exempt, or governed by an office-specific routing shortcut. Every selected assignment must contribute a concrete artifact, bounded code/configuration change, measurement, or inspectable evidence used by the phase, plus its own observable verification. A failed dependency blocks downstream work and requires a revised phase plan or remand. Prefer lighter reasoning for bounded mechanical work and deeper reasoning for architecture, review, or uncertain defects. The runtime maps this desired effort to the selected model's advertised levels and falls back to its default when necessary. Six Ministries always inherit Shangshu's provider/model and never select a model themselves.
7. After implementation and tests, delegate Menxia with the approved case_scale for final acceptance against 04-spec.md and 05-phased-development.md verification. A remand returns to Shangshu; a pass proceeds to Zhongshu.
8. Zhongshu writes 06-final-report.md and 07-chronicle.md as the case-local report and raw audit source, summarizing changes, phase evidence, tests, unresolved risks, Ministry dispatch, and user decisions. It then performs a separate knowledge-distillation pass against .tang/workspace-knowledge.md. This shared document is the only cross-case knowledge source: reuse an existing semantic key when the topic already exists, correct or supersede stale knowledge instead of duplicating it, cite the current case id and exact .tang/cases/<case-id>/ artifact evidence, and retain only reusable decisions, constraints, patterns, pitfalls, or verification lessons. Do not copy the case timeline, status narration, or generic advice. Call tang_workspace_knowledge upsert for reusable findings, or no_change with a concrete reason when the case adds none. Other offices may use head/details/sources to retrieve knowledge progressively, but only Zhongshu may maintain it. After Menxia acceptance is recorded as passed, record case-closure as waiting_approval, then call tang_submit_final_report with the complete Markdown report. Add only task-specific verification_options that are genuinely useful before closure—for example starting this task's development server for manual testing, opening a generated artifact, or running an optional platform check. Each option carries a bounded instruction the coordinator can actually execute; do not add generic ceremony. If the user selects one, the root coordinator performs that follow-up itself, updates the report/evidence, records case-closure as waiting_approval again, and calls tang_submit_final_report again so every manual-test result or follow-up choice remains inside the Tang dashboard. The coordinator must never use a generic/default question tool to ask whether manual testing passed or to collect follow-up feedback. A user confirmation records case-closure as passed and closes the case; a remand is automatically routed by the runtime to the existing Zhongshu conversation (or a recovery Zhongshu child for legacy sessions). The coordinator must wait, never analyze or implement the feedback itself, never invent user questions, and never create a duplicate Zhongshu. Zhongshu records the remand, checks affected requirements and evidence, and raises any blocking clarification through tang_raise_clarification; the coordinator only relays it through tang_request_clarification. Zhongshu reports the needed review/execution/acceptance steps and revises the final report before the coordinator submits closure again; cancellation stops the task while preserving artifacts.

Stop semantics:
- The user may stop, pause, or cancel at any time, including while approval or children are active. Treat any clear stop instruction as highest priority.
- On stop: do not start new work; use list_agents, interrupt_agent, or the known child ids to interrupt active descendants; record the current stage as stopped; preserve artifacts; report exactly what completed and what remains. Resume only after a later explicit user instruction.

Documents and structure:
- Keep every case artifact, including Ministry checklists, logs and evidence, under .tang/cases/<case-id>/ (use its evidence/ subdirectory when useful). Never create workspace-level .tang/evidence or .tang/reports directories. Submission tools reject out-of-case .tang artifact references; submit workspace-relative paths. Source code and project tests remain in their normal repository locations. Keep reusable plugin configuration in .tang/config.json when needed. Keep cross-case knowledge only in .tang/workspace-knowledge.md via tang_workspace_knowledge; never create per-case copies of that knowledge base.
- Treat 01-requirements.md through 04-spec.md as decision and acceptance artifacts, and 05-phased-development.md as a phase contract. They may name proven affected components when useful, but must not pre-write code, prescribe function-level algorithms, or turn review into file-by-file implementation instructions.
- Every approval/remand must name the reviewed artifact and concrete reason. Never approve from a summary when the referenced file can be read.
- Use tang_progress for every semantic stage transition. It updates department status and leaves a durable audit record; do not replace it with prose-only status updates. The Web call trace separately follows the real child Agent sessions.

If the current user message begins with TANG_OFFICE, you are a delegated office, not the coordinator. Follow only that office's authority, complete the bounded assignment, and report success or failure to your parent. Do not advance the global workflow yourself.
`.trim()

function agentOptions(route: TangOfficeRoute | undefined): AgentOptions | undefined {
  if (route === undefined) return undefined
  const options: AgentOptions = {
    ...(route.provider === undefined ? {} : { provider: route.provider }),
    ...(route.model === undefined ? {} : { model: route.model }),
    ...(route.maxTokens === undefined ? {} : { maxTokens: route.maxTokens }),
  }
  return Object.keys(options).length === 0 ? undefined : options
}

function suggestedCaseScale(requirement: readonly ContentBlock[]): TangCaseScale {
  const text = requirement.flatMap(block => block.type === 'text' ? [block.text] : []).join('\n')
  const nonTextBlocks = requirement.filter(block => block.type !== 'text').length
  const complexSignals = text.match(/架构|迁移|重构|安全|权限|数据库|部署|发布|插件|多模块|跨平台|兼容|性能|并发|调度|framework|plugin|architecture|migration|refactor|security|database|deploy/gi)?.length ?? 0
  if (text.length > 1_200 || complexSignals >= 3 || nonTextBlocks >= 4) return 'large'
  if (text.length > 280 || complexSignals >= 1 || nonTextBlocks > 0) return 'medium'
  return 'small'
}

function caseScalePolicyBlock(scale: TangCaseScale): string {
  const policy = CASE_SCALE_POLICY[scale]
  return [
    '<tang-case-scale>',
    `case_scale: ${scale}`,
    `review_policy: ${policy.review}`,
    `execution_policy: ${policy.execution}`,
    `soft_output_target: ${policy.targetTokens}`,
    'The output target is guidance only, never a request or context limit. Produce all evidence needed to finish safely; reduce token use through concise artifacts, reuse, and fewer unnecessary agents rather than truncating an active assignment.',
    'If evidence changes the scale, preserve existing artifacts, record the reason, and continue at the revised scale instead of restarting.',
    'This scale does not change the selected provider/model and does not authorize one Department to plan another Department\'s work.',
    '</tang-case-scale>',
  ].join('\n')
}

function promptWithCaseScale(prompt: string, scale: TangCaseScale): string {
  const newline = prompt.indexOf('\n')
  const marker = `TANG_CASE_SCALE:${scale}\n${caseScalePolicyBlock(scale)}`
  return newline === -1
    ? `${prompt}\n${marker}`
    : `${prompt.slice(0, newline + 1)}${marker}\n${prompt.slice(newline + 1)}`
}

function departmentRoutes(config: Config): TangDepartmentRoutes {
  return Object.fromEntries(TANG_DEPARTMENTS.flatMap(office => {
    const route = config.offices?.[office]
    return route === undefined ? [] : [[office, route]]
  })) as TangDepartmentRoutes
}

function applyRequestRoute(resolved: LlmCallConfig, route: TangOfficeRoute): LlmCallConfig {
  const changesModel = route.provider !== undefined || route.model !== undefined
  const { reasoningEffort: _inheritedReasoningEffort, ...withoutInheritedReasoningEffort } = resolved
  const base = changesModel ? withoutInheritedReasoningEffort : resolved
  return {
    ...base,
    ...(route.provider === undefined ? {} : { provider: route.provider }),
    ...(route.model === undefined ? {} : { model: route.model }),
    ...(route.reasoningEffort === undefined ? {} : { reasoningEffort: ReasoningEffortId(route.reasoningEffort) }),
    ...(route.maxTokens === undefined ? {} : { maxTokens: route.maxTokens }),
  }
}

function compatibleReasoningEffort(
  requested: string,
  reasoning: LlmModelReasoningInfo | undefined,
): string | undefined {
  const supported = reasoning?.efforts.map(effort => String(effort.id)) ?? []
  if (supported.length === 0) return undefined

  const desired = requested.trim().toLowerCase()
  const exact = supported.find(effort => effort.toLowerCase() === desired)
  if (exact !== undefined) return exact

  const defaultEffort = reasoning?.defaultEffort === undefined ? undefined : String(reasoning.defaultEffort)
  if (defaultEffort !== undefined && supported.includes(defaultEffort)) return defaultEffort

  const desiredRank = REASONING_EFFORT_ORDER.indexOf(desired as typeof REASONING_EFFORT_ORDER[number])
  if (desiredRank === -1) return supported[0]
  return supported
    .map((effort, index) => ({
      effort,
      index,
      rank: REASONING_EFFORT_ORDER.indexOf(effort.toLowerCase() as typeof REASONING_EFFORT_ORDER[number]),
    }))
    .filter(item => item.rank !== -1)
    .sort((left, right) => Math.abs(left.rank - desiredRank) - Math.abs(right.rank - desiredRank)
      || left.rank - right.rank
      || left.index - right.index)[0]?.effort ?? supported[0]
}

function replaceReasoningEffort(resolved: LlmCallConfig, effort: string | undefined): LlmCallConfig {
  const { reasoningEffort: _previousEffort, ...withoutReasoningEffort } = resolved
  return effort === undefined
    ? withoutReasoningEffort
    : { ...withoutReasoningEffort, reasoningEffort: ReasoningEffortId(effort) }
}

function pluginMessage(text: string, summary: string): UserMessage {
  const content = Object.freeze([{ type: 'text' as const, text }])
  const source = Object.freeze({
    kind: 'plugin' as const,
    plugin: 'dsh-tang-governance',
    form: 'notice' as const,
    summary,
  })
  return Object.freeze({
    id: crypto.randomUUID(),
    role: 'user' as const,
    content,
    source,
  }) as unknown as UserMessage
}

function originalRequirement(messages: readonly UserMessage[]): ContentBlock[] {
  return messages
    .filter(message => message.source.kind === 'user')
    .flatMap(message => message.content)
}

function hasEnteredUserRequirement(events: readonly SessionEvent[]): boolean {
  return events.some(event => event.type === 'user/message' && event.data.source.kind === 'user')
}

function callerOffice(events: readonly SessionEvent[]): TangOffice | null | undefined {
  const descriptorEvent = events.findLast(event => event.type === 'subagent/descriptor')
  if (descriptorEvent?.type !== 'subagent/descriptor') return null
  const label = descriptorEvent.data.label
  if (label === undefined) return undefined
  const found = Object.entries(OFFICE_LABELS).find(([, officeName]) => label.includes(`[${officeName}]`))
  return found?.[0] as TangOffice | undefined
}

function toolResultText(event: SessionEvent<'tool/result'>): string {
  return event.data.message.content[0].content
    .filter(block => block.type === 'text')
    .map(block => block.text)
    .join('')
}

function userApprovedExecution(events: readonly SessionEvent[]): boolean {
  for (let index = events.length - 1; index >= 0; index--) {
    const progress = events[index]
    if (progress?.type !== 'tool/call' || progress.data.name !== 'tang_progress') continue
    let args: unknown
    try { args = JSON.parse(progress.data.arguments) } catch { continue }
    if (typeof args !== 'object' || args === null
      || (args as Record<string, unknown>).stage !== 'user-approval'
      || (args as Record<string, unknown>).status !== 'passed') continue
    for (let approvalIndex = index - 1; approvalIndex >= 0; approvalIndex--) {
      const call = events[approvalIndex]
      if (call?.type !== 'tool/call'
        || (call.data.name !== 'tang_request_approval' && call.data.name !== 'ask_user_question')) continue
      const result = events.slice(approvalIndex + 1, index).find(event => event.type === 'tool/result'
        && event.data.message.source.callId === call.data.callId)
      if (result?.type === 'tool/result' && result.data.error === undefined
        && result.data.message.content[0].isError !== true
        && toolResultText(result).includes(TANG_APPROVE_LABEL)) return true
    }
  }
  return false
}

function successfulResultFor(
  events: readonly SessionEvent[],
  call: SessionEvent<'tool/call'>,
  afterIndex: number,
): boolean {
  const result = events.slice(afterIndex + 1).find(event => event.type === 'tool/result'
    && event.data.message.source.callId === call.data.callId)
  return result?.type === 'tool/result'
    && result.data.error === undefined
    && result.data.message.content[0].isError !== true
}

function latestAcceptedMinistryPlan(events: readonly SessionEvent[]): MinistryPlanArgs | undefined {
  for (let index = events.length - 1; index >= 0; index--) {
    const call = events[index]
    if (call?.type !== 'tool/call' || call.data.name !== 'tang_plan_ministries') continue
    if (!successfulResultFor(events, call, index)) continue
    try { return ministryPlanArgs(JSON.parse(call.data.arguments), false) } catch { return undefined }
  }
  return undefined
}

function acceptedMinistryAssignment(
  events: readonly SessionEvent[],
  assignmentId: string,
): MinistryAssignment | undefined {
  for (let index = events.length - 1; index >= 0; index--) {
    const call = events[index]
    if (call?.type !== 'tool/call' || call.data.name !== 'tang_plan_ministries') continue
    if (!successfulResultFor(events, call, index)) continue
    try {
      const assignment = ministryPlanArgs(JSON.parse(call.data.arguments), false).assignments
        .find(item => item.assignment_id === assignmentId)
      if (assignment !== undefined) return assignment
    } catch { return undefined }
  }
  return undefined
}

function assignmentWasDelegated(events: readonly SessionEvent[], assignmentId: string): boolean {
  for (let index = events.length - 1; index >= 0; index--) {
    const call = events[index]
    if (call?.type !== 'tool/call' || call.data.name !== 'tang_delegate') continue
    let args: unknown
    try { args = JSON.parse(call.data.arguments) } catch { continue }
    if (typeof args !== 'object' || args === null
      || (args as Record<string, unknown>).assignment_id !== assignmentId) continue
    if (successfulResultFor(events, call, index)) return true
  }
  return false
}

function assignmentSucceeded(events: readonly SessionEvent[], assignmentId: string): boolean {
  for (let index = events.length - 1; index >= 0; index--) {
    const call = events[index]
    if (call?.type !== 'tool/call' || call.data.name !== 'tang_record_ministry_result') continue
    let args: unknown
    try { args = JSON.parse(call.data.arguments) } catch { continue }
    if (typeof args !== 'object' || args === null
      || (args as Record<string, unknown>).assignment_id !== assignmentId) continue
    if ((args as Record<string, unknown>).status !== 'succeeded') return false
    return successfulResultFor(events, call, index)
  }
  return false
}

function hasPassedStage(events: readonly SessionEvent[], stage: TangProgressRecord['stage']): boolean {
  for (let index = events.length - 1; index >= 0; index--) {
    const call = events[index]
    if (call?.type !== 'tool/call' || call.data.name !== 'tang_progress') continue
    let args: unknown
    try { args = JSON.parse(call.data.arguments) } catch { continue }
    if (typeof args !== 'object' || args === null
      || (args as Record<string, unknown>).stage !== stage
      || (args as Record<string, unknown>).status !== 'passed') continue
    if (successfulResultFor(events, call, index)) return true
  }
  return false
}

function assertProgressAuthority(
  office: TangOffice,
  status: typeof TANG_STATUSES[number],
  events: readonly SessionEvent[],
): void {
  const caller = callerOffice(events)
  if (caller === null) return
  if (caller === undefined) throw new Error('Tang progress is unavailable to an unrecognized delegated role')
  if (caller !== office) throw new Error(`${OFFICE_LABELS[caller]} may record progress only for itself`)
  const ministryStatuses: readonly typeof TANG_STATUSES[number][] = ['running', 'succeeded', 'failed', 'stopped']
  if (MINISTRIES.has(caller) && !ministryStatuses.includes(status)) {
    throw new Error(`${OFFICE_LABELS[caller]} has execution-only authority and may report only running, succeeded, failed, or stopped`)
  }
}

function assertDelegationAuthority(office: TangOffice, events: readonly SessionEvent[]): void {
  const caller = callerOffice(events)
  if (caller === null) {
    if (!DEPARTMENTS.has(office)) throw new Error('The coordinator delegates Departments; only Shangshu delegates Ministries')
    if (office === 'shangshu' && !userApprovedExecution(events)) {
      throw new Error('Shangshu cannot start before a successful Tang approval selecting "批准执行" and a passed user-approval milestone')
    }
    return
  }
  if (caller === 'shangshu' && MINISTRIES.has(office)) return
  const callerName = caller === undefined ? 'unrecognized delegated role' : OFFICE_LABELS[caller]
  throw new Error(`${callerName} has no authority to delegate ${OFFICE_LABELS[office]}`)
}

interface ProgressArgs {
  readonly case_id: string
  readonly stage: TangProgressRecord['stage']
  readonly office: TangOffice
  readonly status: TangProgressRecord['status']
  readonly title: string
  readonly summary?: string
  readonly artifact_path?: string
}

interface DelegateArgs {
  readonly office: TangOffice
  readonly description: string
  readonly prompt: string
  readonly case_scale?: TangCaseScale
  readonly reasoning_effort?: string
  readonly assignment_id?: string
}

/** Reconstruct the closure decision from durable successful tool results, not process memory. */
function closureRemandIndex(events: readonly SessionEvent[]): number {
  for (let index = events.length - 1; index >= 0; index--) {
    const result = events[index]
    if (result?.type !== 'tool/result' || result.data.error !== undefined
      || result.data.message.content[0].isError === true) continue
    const call = events.slice(0, index).findLast(event => event.type === 'tool/call'
      && event.data.callId === result.data.message.source.callId)
    if (call?.type !== 'tool/call' || call.data.name !== 'tang_submit_final_report') continue
    return toolResultText(result).startsWith(TANG_REMAND_LABEL) ? index : -1
  }
  return -1
}

interface ApprovalArgs {
  readonly case_id: string
  readonly title: string
  readonly proposal_markdown: string
}

interface ClarificationQuestion {
  readonly id: string
  readonly question: string
  readonly header?: string
  readonly detail?: string
  readonly options?: readonly { readonly label: string; readonly description?: string }[]
  readonly multi_select?: boolean
}

interface ClarificationArgs {
  readonly case_id: string
  readonly zhongshu_id: string
  readonly questions: readonly ClarificationQuestion[]
}

interface RaiseClarificationArgs {
  readonly case_id: string
  readonly questions: readonly ClarificationQuestion[]
}

type MinistryDomain = typeof MINISTRY_DOMAINS[TangMinistry]
type MinistryRole = 'analysis' | 'implementation' | 'documentation' | 'verification' | 'integration'

interface MinistryAssignment {
  readonly assignment_id: string
  readonly office: TangMinistry
  readonly domain: MinistryDomain
  readonly role: MinistryRole
  readonly objective: string
  readonly deliverables: readonly string[]
  readonly verification: string
  readonly reasoning_effort: string
  readonly depends_on?: readonly string[]
}

interface MinistryOmission {
  readonly office: TangMinistry
  readonly reason: string
}

interface MinistryPlanArgs {
  readonly case_id: string
  readonly phase: string
  readonly changes_code: boolean
  readonly assignments: readonly MinistryAssignment[]
  readonly omissions: readonly MinistryOmission[]
}

interface MinistryResultArgs {
  readonly case_id: string
  readonly phase: string
  readonly assignment_id: string
  readonly office: TangMinistry
  readonly status: 'succeeded' | 'failed'
  readonly summary: string
  readonly evidence: readonly string[]
}

interface FinalReportArgs {
  readonly case_id: string
  readonly title: string
  readonly report_markdown: string
  readonly verification_options?: readonly {
    readonly label: string
    readonly description: string
    readonly instruction: string
  }[]
}

function progressArgs(value: unknown, validateScope = true): ProgressArgs {
  const parsed = parseTangProgress(value)
  if (parsed === null) throw new Error('invalid tang_progress arguments')
  const args = value as ProgressArgs
  if (validateScope) {
    assertCaseId(args.case_id)
    if (args.artifact_path !== undefined) assertCaseArtifact(args.artifact_path, args.case_id, 'artifact_path')
  }
  return value as ProgressArgs
}

function delegateArgs(value: unknown): DelegateArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_delegate arguments must be an object')
  }
  const record = value as Record<string, unknown>
  if (!TANG_OFFICES.includes(record.office as TangOffice)) throw new Error('tang_delegate office is invalid')
  if (typeof record.description !== 'string' || record.description.trim() === '') {
    throw new Error('tang_delegate description is required')
  }
  if (typeof record.prompt !== 'string' || record.prompt.trim() === '') throw new Error('tang_delegate prompt is required')
  if (record.case_scale !== undefined && !TANG_CASE_SCALES.includes(record.case_scale as TangCaseScale)) {
    throw new Error('tang_delegate case_scale must be small, medium, or large')
  }
  if (record.reasoning_effort !== undefined && typeof record.reasoning_effort !== 'string') {
    throw new Error('tang_delegate reasoning_effort must be a string')
  }
  if (record.assignment_id !== undefined && typeof record.assignment_id !== 'string') {
    throw new Error('tang_delegate assignment_id must be a string')
  }
  return record as unknown as DelegateArgs
}

function approvalArgs(value: unknown): ApprovalArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_request_approval arguments must be an object')
  }
  const record = value as Record<string, unknown>
  if (typeof record.case_id !== 'string' || record.case_id.trim() === '') {
    throw new Error('tang_request_approval case_id is required')
  }
  if (typeof record.title !== 'string' || record.title.trim() === '') {
    throw new Error('tang_request_approval title is required')
  }
  if (typeof record.proposal_markdown !== 'string' || record.proposal_markdown.trim() === '') {
    throw new Error('tang_request_approval proposal_markdown is required')
  }
  return record as unknown as ApprovalArgs
}

function clarificationArgs(value: unknown): ClarificationArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_request_clarification arguments must be an object')
  }
  const record = value as Record<string, unknown>
  const caseId = nonEmptyString(record.case_id, 'tang_request_clarification case_id')
  const zhongshuId = nonEmptyString(record.zhongshu_id, 'tang_request_clarification zhongshu_id')
  if (!Array.isArray(record.questions) || record.questions.length === 0 || record.questions.length > 3) {
    throw new Error('tang_request_clarification questions must contain one to three items')
  }
  const ids = new Set<string>()
  const questions = record.questions.map((value, index): ClarificationQuestion => {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
      throw new Error(`questions[${index}] must be an object`)
    }
    const item = value as Record<string, unknown>
    const id = nonEmptyString(item.id, `questions[${index}].id`)
    if (ids.has(id)) throw new Error(`duplicate clarification question id: ${id}`)
    ids.add(id)
    let options: ClarificationQuestion['options']
    if (item.options !== undefined) {
      if (!Array.isArray(item.options) || item.options.length < 2 || item.options.length > 4) {
        throw new Error(`questions[${index}].options must contain two to four choices`)
      }
      options = item.options.map((value, optionIndex) => {
        if (typeof value !== 'object' || value === null || Array.isArray(value)) {
          throw new Error(`questions[${index}].options[${optionIndex}] must be an object`)
        }
        const option = value as Record<string, unknown>
        const label = nonEmptyString(option.label, `questions[${index}].options[${optionIndex}].label`)
        if (option.description !== undefined && typeof option.description !== 'string') {
          throw new Error(`questions[${index}].options[${optionIndex}].description must be a string`)
        }
        return { label, ...(option.description === undefined ? {} : { description: option.description }) }
      })
    }
    if (item.header !== undefined && typeof item.header !== 'string') throw new Error(`questions[${index}].header must be a string`)
    if (item.detail !== undefined && typeof item.detail !== 'string') throw new Error(`questions[${index}].detail must be a string`)
    if (item.multi_select !== undefined && typeof item.multi_select !== 'boolean') {
      throw new Error(`questions[${index}].multi_select must be a boolean`)
    }
    return {
      id,
      question: nonEmptyString(item.question, `questions[${index}].question`),
      ...(item.header === undefined ? {} : { header: item.header }),
      ...(item.detail === undefined ? {} : { detail: item.detail }),
      ...(options === undefined ? {} : { options }),
      ...(item.multi_select === undefined ? {} : { multi_select: item.multi_select }),
    }
  })
  return { case_id: caseId, zhongshu_id: zhongshuId, questions }
}

function raiseClarificationArgs(value: unknown): RaiseClarificationArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_raise_clarification arguments must be an object')
  }
  const parsed = clarificationArgs({ ...(value as Record<string, unknown>), zhongshu_id: 'pending-relay' })
  return { case_id: parsed.case_id, questions: parsed.questions }
}

function nonEmptyString(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${field} is required`)
  return value
}

function stringList(value: unknown, field: string, allowEmpty = false): readonly string[] {
  if (!Array.isArray(value) || (!allowEmpty && value.length === 0)
    || value.some(item => typeof item !== 'string' || item.trim() === '')) {
    throw new Error(`${field} must be ${allowEmpty ? 'an' : 'a non-empty'} array of non-empty strings`)
  }
  return value as string[]
}

function ministryPlanArgs(value: unknown, validateScope = true): MinistryPlanArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_plan_ministries arguments must be an object')
  }
  const record = value as Record<string, unknown>
  const caseId = nonEmptyString(record.case_id, 'tang_plan_ministries case_id')
  if (validateScope) assertCaseId(caseId)
  nonEmptyString(record.phase, 'tang_plan_ministries phase')
  if (typeof record.changes_code !== 'boolean') throw new Error('tang_plan_ministries changes_code must be boolean')
  if (!Array.isArray(record.assignments) || record.assignments.length === 0) {
    throw new Error('tang_plan_ministries assignments must be a non-empty array')
  }
  if (!Array.isArray(record.omissions)) throw new Error('tang_plan_ministries omissions must be an array')

  const assignments = record.assignments.map((value, index): MinistryAssignment => {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
      throw new Error(`assignments[${index}] must be an object`)
    }
    const item = value as Record<string, unknown>
    const office = item.office as TangMinistry
    if (!TANG_MINISTRY_OFFICES.includes(office)) throw new Error(`assignments[${index}].office is invalid`)
    if (item.domain !== MINISTRY_DOMAINS[office]) {
      throw new Error(`${OFFICE_LABELS[office]} accepts only domain ${MINISTRY_DOMAINS[office]}`)
    }
    if (typeof item.role !== 'string' || !MINISTRY_ROLES[office].has(item.role)) {
      throw new Error(`${OFFICE_LABELS[office]} does not accept role ${String(item.role)}`)
    }
    const dependsOn = item.depends_on === undefined
      ? undefined
      : stringList(item.depends_on, `assignments[${index}].depends_on`, true)
    const assignment: MinistryAssignment = {
      assignment_id: nonEmptyString(item.assignment_id, `assignments[${index}].assignment_id`),
      office,
      domain: item.domain as MinistryDomain,
      role: item.role as MinistryRole,
      objective: nonEmptyString(item.objective, `assignments[${index}].objective`),
      deliverables: stringList(item.deliverables, `assignments[${index}].deliverables`),
      verification: nonEmptyString(item.verification, `assignments[${index}].verification`),
      reasoning_effort: nonEmptyString(item.reasoning_effort, `assignments[${index}].reasoning_effort`),
      ...(dependsOn === undefined ? {} : { depends_on: dependsOn }),
    }
    if (validateScope) {
      assertCaseReferences(assignment.deliverables, caseId, `assignments[${index}].deliverables`)
      assertCaseReferences([assignment.verification], caseId, `assignments[${index}].verification`)
    }
    return assignment
  })

  const omissions = record.omissions.map((value, index): MinistryOmission => {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
      throw new Error(`omissions[${index}] must be an object`)
    }
    const item = value as Record<string, unknown>
    const office = item.office as TangMinistry
    if (!TANG_MINISTRY_OFFICES.includes(office)) throw new Error(`omissions[${index}].office is invalid`)
    const reason = nonEmptyString(item.reason, `omissions[${index}].reason`)
    if (GENERIC_OMISSION_REASON.test(reason.trim())) {
      throw new Error(`${OFFICE_LABELS[office]} omission must cite a concrete phase fact or unchanged surface`)
    }
    return { office, reason }
  })

  const ids = new Set<string>()
  for (const assignment of assignments) {
    if (ids.has(assignment.assignment_id)) throw new Error(`duplicate Ministry assignment id: ${assignment.assignment_id}`)
    ids.add(assignment.assignment_id)
  }
  const assignedOffices = new Set(assignments.map(assignment => assignment.office))
  const omittedOffices = new Set<TangMinistry>()
  for (const omission of omissions) {
    if (omittedOffices.has(omission.office)) throw new Error(`duplicate omission for ${OFFICE_LABELS[omission.office]}`)
    if (assignedOffices.has(omission.office)) throw new Error(`${OFFICE_LABELS[omission.office]} cannot be both assigned and omitted`)
    omittedOffices.add(omission.office)
  }
  for (const office of TANG_MINISTRY_OFFICES) {
    if (!assignedOffices.has(office) && !omittedOffices.has(office)) {
      throw new Error(`tang_plan_ministries must assign or explain omission of ${OFFICE_LABELS[office]}`)
    }
  }
  for (const assignment of assignments) {
    for (const dependency of assignment.depends_on ?? []) {
      if (!ids.has(dependency)) throw new Error(`${assignment.assignment_id} depends on unknown assignment ${dependency}`)
      if (dependency === assignment.assignment_id) throw new Error(`${assignment.assignment_id} cannot depend on itself`)
    }
  }
  return {
    case_id: record.case_id as string,
    phase: record.phase as string,
    changes_code: record.changes_code,
    assignments,
    omissions,
  }
}

function ministryResultArgs(value: unknown): MinistryResultArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_record_ministry_result arguments must be an object')
  }
  const record = value as Record<string, unknown>
  const office = record.office as TangMinistry
  if (!TANG_MINISTRY_OFFICES.includes(office)) throw new Error('tang_record_ministry_result office is invalid')
  if (record.status !== 'succeeded' && record.status !== 'failed') {
    throw new Error('tang_record_ministry_result status must be succeeded or failed')
  }
  const caseId = nonEmptyString(record.case_id, 'tang_record_ministry_result case_id')
  const evidence = stringList(record.evidence, 'tang_record_ministry_result evidence')
  assertCaseReferences(evidence, caseId, 'tang_record_ministry_result evidence')
  return {
    case_id: caseId,
    phase: nonEmptyString(record.phase, 'tang_record_ministry_result phase'),
    assignment_id: nonEmptyString(record.assignment_id, 'tang_record_ministry_result assignment_id'),
    office,
    status: record.status,
    summary: nonEmptyString(record.summary, 'tang_record_ministry_result summary'),
    evidence,
  }
}

function finalReportArgs(value: unknown): FinalReportArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_submit_final_report arguments must be an object')
  }
  const record = value as Record<string, unknown>
  let verificationOptions: FinalReportArgs['verification_options']
  if (record.verification_options !== undefined) {
    if (!Array.isArray(record.verification_options)) {
      throw new Error('tang_submit_final_report verification_options must be an array')
    }
    const labels = new Set<string>()
    const parsedOptions: Array<{ label: string, description: string, instruction: string }> = []
    record.verification_options.forEach((value, index) => {
      if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        throw new Error(`verification_options[${index}] must be an object`)
      }
      const option = value as Record<string, unknown>
      const label = nonEmptyString(option.label, `verification_options[${index}].label`)
      // Closure and remand are always supplied by the runtime. Treat model-generated
      // aliases and duplicate follow-ups as harmless redundancy instead of failing a
      // completed run before the user can see the report.
      if (label.includes(TANG_CLOSE_LABEL) || label.includes(TANG_REMAND_LABEL) || labels.has(label)) {
        return
      }
      labels.add(label)
      parsedOptions.push({
        label,
        description: nonEmptyString(option.description, `verification_options[${index}].description`),
        instruction: nonEmptyString(option.instruction, `verification_options[${index}].instruction`),
      })
    })
    verificationOptions = parsedOptions
  }
  return {
    case_id: nonEmptyString(record.case_id, 'tang_submit_final_report case_id'),
    title: nonEmptyString(record.title, 'tang_submit_final_report title'),
    report_markdown: nonEmptyString(record.report_markdown, 'tang_submit_final_report report_markdown'),
    ...(verificationOptions === undefined ? {} : { verification_options: verificationOptions }),
  }
}

function validCaseId(value: unknown, field: string): string {
  const caseId = nonEmptyString(value, field)
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(caseId)) {
    throw new Error(`${field} must be a filesystem-safe case id`)
  }
  return caseId
}

function normalizedCaseArtifact(value: unknown, field: string, caseId?: string): string {
  const artifact = nonEmptyString(value, field).replace(/\\/g, '/')
  if (artifact.includes('/../') || artifact.endsWith('/..') || artifact.startsWith('../')) {
    throw new Error(`${field} must not traverse outside the case directory`)
  }
  const prefix = caseId === undefined ? '.tang/cases/' : `.tang/cases/${caseId}/`
  if (!artifact.startsWith(prefix) || !artifact.endsWith('.md')) {
    throw new Error(`${field} must reference a Markdown artifact under ${prefix}`)
  }
  return artifact
}

function workspaceKnowledgeArgs(value: unknown): WorkspaceKnowledgeArgs {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('tang_workspace_knowledge arguments must be an object')
  }
  const record = value as Record<string, unknown>
  const operation = record.operation
  if (!['head', 'details', 'sources', 'upsert', 'no_change'].includes(operation as string)) {
    throw new Error('tang_workspace_knowledge operation is invalid')
  }
  if (operation === 'head') return { operation: 'head' }

  if (operation === 'details') {
    const ids = stringList(record.knowledge_ids, 'tang_workspace_knowledge knowledge_ids')
    return { operation, knowledge_ids: [...new Set(ids)] }
  }

  if (operation === 'sources') {
    const artifacts = stringList(record.source_artifacts, 'tang_workspace_knowledge source_artifacts')
      .map((artifact, index) => normalizedCaseArtifact(artifact, `source_artifacts[${index}]`))
    return { operation, source_artifacts: [...new Set(artifacts)] }
  }

  const caseId = validCaseId(record.case_id, 'tang_workspace_knowledge case_id')
  if (operation === 'no_change') {
    return {
      operation,
      case_id: caseId,
      reason: nonEmptyString(record.reason, 'tang_workspace_knowledge reason'),
    }
  }

  if (!Array.isArray(record.entries) || record.entries.length === 0) {
    throw new Error('tang_workspace_knowledge upsert requires at least one entry')
  }
  const keys = new Set<string>()
  const entries = record.entries.map((value, index): KnowledgeUpsertInput => {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
      throw new Error(`entries[${index}] must be an object`)
    }
    const item = value as Record<string, unknown>
    const key = nonEmptyString(item.key, `entries[${index}].key`).trim().toLowerCase()
    if (key.includes('..') || !/^[a-z0-9][a-z0-9._/-]*$/.test(key)) {
      throw new Error(`entries[${index}].key must be a stable lowercase semantic key`)
    }
    if (keys.has(key)) throw new Error(`duplicate knowledge key in one update: ${key}`)
    keys.add(key)
    if (!KNOWLEDGE_KINDS.includes(item.kind as KnowledgeKind)) {
      throw new Error(`entries[${index}].kind is invalid`)
    }
    if (item.state !== 'provisional' && item.state !== 'confirmed') {
      throw new Error(`entries[${index}].state must be provisional or confirmed`)
    }
    if (!Array.isArray(item.evidence) || item.evidence.length === 0) {
      throw new Error(`entries[${index}].evidence must cite at least one current-case artifact`)
    }
    const evidence = item.evidence.map((value, evidenceIndex) => {
      if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        throw new Error(`entries[${index}].evidence[${evidenceIndex}] must be an object`)
      }
      const evidenceRecord = value as Record<string, unknown>
      return {
        artifact: normalizedCaseArtifact(
          evidenceRecord.artifact,
          `entries[${index}].evidence[${evidenceIndex}].artifact`,
          caseId,
        ),
        note: nonEmptyString(evidenceRecord.note, `entries[${index}].evidence[${evidenceIndex}].note`),
      }
    })
    const supersedes = item.supersedes === undefined
      ? undefined
      : [...new Set(stringList(item.supersedes, `entries[${index}].supersedes`, true))]
    return {
      key,
      kind: item.kind as KnowledgeKind,
      topic: nonEmptyString(item.topic, `entries[${index}].topic`),
      scope: nonEmptyString(item.scope, `entries[${index}].scope`),
      summary: nonEmptyString(item.summary, `entries[${index}].summary`),
      details: nonEmptyString(item.details, `entries[${index}].details`),
      state: item.state,
      evidence,
      ...(supersedes === undefined ? {} : { supersedes }),
    }
  })
  return { operation: 'upsert', case_id: caseId, entries }
}

function upsertWorkspaceKnowledge(
  store: WorkspaceKnowledgeStore,
  caseId: string,
  inputs: readonly KnowledgeUpsertInput[],
): { readonly store: WorkspaceKnowledgeStore; readonly updatedIds: readonly string[] } {
  const entries = [...store.entries]
  const byId = new Map(entries.map((entry, index) => [entry.id, index]))
  const byKey = new Map(entries.map((entry, index) => [entry.key, index]))
  const updatedIds: string[] = []
  const now = new Date().toISOString()

  for (const input of inputs) {
    const id = knowledgeId(input.key)
    const previousIndex = byKey.get(input.key)
    const previous = previousIndex === undefined ? undefined : entries[previousIndex]
    const collidingIndex = byId.get(id)
    if (previousIndex === undefined && collidingIndex !== undefined && entries[collidingIndex]?.key !== input.key) {
      throw new Error(`knowledge id collision between ${input.key} and ${entries[collidingIndex]?.key ?? 'unknown key'}`)
    }
    const supersedes = [...new Set(input.supersedes ?? [])]
    if (supersedes.includes(id)) throw new Error(`${id} cannot supersede itself`)
    for (const supersededId of supersedes) {
      const index = byId.get(supersededId)
      if (index === undefined) throw new Error(`cannot supersede unknown knowledge id: ${supersededId}`)
      const target = entries[index]
      if (target === undefined) continue
      entries[index] = { ...target, state: 'superseded', updatedAt: now }
    }
    const newEvidence: KnowledgeEvidence[] = input.evidence.map(item => ({
      caseId,
      artifact: item.artifact,
      note: item.note,
    }))
    const evidence = [...(previous?.evidence ?? [])]
    for (const item of newEvidence) {
      if (!evidence.some(existing => existing.caseId === item.caseId
        && existing.artifact === item.artifact && existing.note === item.note)) evidence.push(item)
    }
    const entry: WorkspaceKnowledgeEntry = {
      id,
      key: input.key,
      kind: input.kind,
      topic: input.topic,
      scope: input.scope,
      summary: input.summary,
      details: input.details,
      state: input.state,
      sourceCases: [...new Set([...(previous?.sourceCases ?? []), caseId])],
      evidence,
      supersedes: [...new Set([...(previous?.supersedes ?? []), ...supersedes])],
      updatedAt: now,
    }
    if (previousIndex === undefined) {
      byId.set(id, entries.length)
      byKey.set(input.key, entries.length)
      entries.push(entry)
    } else {
      entries[previousIndex] = entry
      byId.set(id, previousIndex)
    }
    updatedIds.push(id)
  }
  return { store: { version: 1, entries }, updatedIds }
}

function promptWithReasoning(prompt: string, reasoningEffort: string | undefined): string {
  if (reasoningEffort === undefined) return prompt
  const newline = prompt.indexOf('\n')
  const marker = `TANG_REASONING_EFFORT:${reasoningEffort}`
  return newline === -1
    ? `${prompt}\n${marker}`
    : `${prompt.slice(0, newline)}\n${marker}${prompt.slice(newline)}`
}

function promptWithMinistryMandate(prompt: string, assignment: MinistryAssignment): string {
  const newline = prompt.indexOf('\n')
  const mandate = [
    '<tang-ministry-assignment>',
    `assignment_id: ${assignment.assignment_id}`,
    `domain: ${assignment.domain}`,
    `role: ${assignment.role}`,
    `mandate: ${MINISTRY_MANDATES[assignment.office]}`,
    `objective: ${assignment.objective}`,
    `deliverables: ${assignment.deliverables.join(' | ')}`,
    `verification: ${assignment.verification}`,
    `depends_on: ${(assignment.depends_on ?? []).join(', ') || 'none'}`,
    'Stay inside this mandate. Report success or failure with concrete artifact paths and verification evidence; do not advance or approve the global workflow.',
    '</tang-ministry-assignment>',
  ].join('\n')
  return newline === -1
    ? `${prompt}\n${mandate}`
    : `${prompt.slice(0, newline + 1)}${mandate}\n${prompt.slice(newline + 1)}`
}

function delegatedReasoning(events: readonly SessionEvent[]): string | undefined {
  for (const event of events) {
    if (event.type !== 'user/message') continue
    for (const block of event.data.content) {
      if (block.type !== 'text') continue
      const match = /^TANG_REASONING_EFFORT:([^\s]+)$/m.exec(block.text)
      if (match?.[1] !== undefined) return match[1]
    }
  }
  return undefined
}

const PROGRESS_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['case_id', 'stage', 'office', 'status', 'title'],
  properties: {
    case_id: { type: 'string', description: 'Stable case id used under .tang/cases/<case-id>/.' },
    stage: { type: 'string', enum: [...TANG_STAGES], description: 'Workflow stage.' },
    office: { type: 'string', enum: [...TANG_OFFICES], description: 'Office responsible for this transition.' },
    status: { type: 'string', enum: [...TANG_STATUSES], description: 'New stage status.' },
    title: { type: 'string', description: 'Short user-facing milestone title.' },
    summary: { type: 'string', description: 'Concrete outcome, reason for remand, or approval condition.' },
    artifact_path: { type: 'string', description: 'Workspace-relative artifact under .tang/cases/<case_id>/ only; no shared evidence folder, absolute path, traversal or other case.' },
  },
}

const PROGRESS_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['recorded', 'caseId', 'stage', 'status'],
  properties: {
    recorded: { type: 'boolean', const: true },
    caseId: { type: 'string' },
    stage: { type: 'string', enum: [...TANG_STAGES] },
    status: { type: 'string', enum: [...TANG_STATUSES] },
  },
}

const DELEGATE_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['office', 'description', 'prompt'],
  properties: {
    office: { type: 'string', enum: [...TANG_OFFICES], description: 'Office to activate.' },
    description: { type: 'string', description: 'Short 3–8 word task label shown on the organization card.' },
    prompt: { type: 'string', description: 'Complete bounded assignment, beginning with TANG_OFFICE:<office-id>.' },
    case_scale: { type: 'string', enum: [...TANG_CASE_SCALES], description: 'Required for Menxia and Shangshu. The countersigned requirement magnitude controls proportional review depth and soft output guidance without changing provider/model or imposing a hard request limit.' },
    reasoning_effort: { type: 'string', description: 'Required for a Ministry. Desired complexity level for this assignment; the runtime maps it to the selected model capability or its default before dispatch.' },
    assignment_id: { type: 'string', description: 'Required for a Ministry. Must reference an assignment in the latest accepted tang_plan_ministries phase plan.' },
  },
}

const DELEGATE_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['office', 'subagentId'],
  properties: {
    office: { type: 'string', enum: [...TANG_OFFICES] },
    subagentId: { type: 'string' },
  },
}

const MINISTRY_PLAN_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['case_id', 'phase', 'changes_code', 'assignments', 'omissions'],
  properties: {
    case_id: { type: 'string', description: 'Stable Tang case id.' },
    phase: { type: 'string', description: 'Approved development phase being routed.' },
    changes_code: { type: 'boolean', description: 'Whether this phase changes source, configuration, tests, build, or infrastructure code.' },
    assignments: {
      type: 'array',
      minItems: 1,
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['assignment_id', 'office', 'domain', 'role', 'objective', 'deliverables', 'verification', 'reasoning_effort'],
        properties: {
          assignment_id: { type: 'string', description: 'Unique id within this phase, cited by tang_delegate.' },
          office: { type: 'string', enum: [...TANG_MINISTRY_OFFICES] },
          domain: { type: 'string', enum: [...new Set(Object.values(MINISTRY_DOMAINS))] },
          role: { type: 'string', enum: ['analysis', 'implementation', 'documentation', 'verification', 'integration'] },
          objective: { type: 'string' },
          deliverables: { type: 'array', minItems: 1, items: { type: 'string' }, description: 'Source changes or concrete outputs. Every .tang artifact must be under .tang/cases/<case_id>/, including Ministry checklists and evidence.' },
          verification: { type: 'string', description: 'Independent command or observable completion evidence.' },
          reasoning_effort: { type: 'string', description: 'Desired reasoning complexity for this bounded assignment. It need not name an exact provider level; runtime capability mapping prevents unsupported-level failures.' },
          depends_on: { type: 'array', items: { type: 'string' } },
        },
      },
    },
    omissions: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['office', 'reason'],
        properties: {
          office: { type: 'string', enum: [...TANG_MINISTRY_OFFICES] },
          reason: { type: 'string', description: 'Concrete reason this office is unnecessary for the phase.' },
        },
      },
    },
  },
}

const MINISTRY_PLAN_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['caseId', 'phase', 'assignments', 'assessedOffices'],
  properties: {
    caseId: { type: 'string' },
    phase: { type: 'string' },
    assignments: { type: 'number' },
    assessedOffices: { type: 'number', const: 6 },
  },
}

const MINISTRY_RESULT_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['case_id', 'phase', 'assignment_id', 'office', 'status', 'summary', 'evidence'],
  properties: {
    case_id: { type: 'string' },
    phase: { type: 'string' },
    assignment_id: { type: 'string', description: 'Assignment from an accepted tang_plan_ministries plan that was actually delegated.' },
    office: { type: 'string', enum: [...TANG_MINISTRY_OFFICES] },
    status: { type: 'string', enum: ['succeeded', 'failed'] },
    summary: { type: 'string', description: 'Concrete outcome reported by the Ministry and assessed by Shangshu.' },
    evidence: { type: 'array', minItems: 1, items: { type: 'string' }, description: 'Artifact paths, commands, observations, or failure evidence. Every .tang artifact must be workspace-relative under .tang/cases/<case_id>/, not a shared evidence directory.' },
  },
}

const MINISTRY_RESULT_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['assignmentId', 'office', 'status'],
  properties: {
    assignmentId: { type: 'string' },
    office: { type: 'string', enum: [...TANG_MINISTRY_OFFICES] },
    status: { type: 'string', enum: ['succeeded', 'failed'] },
  },
}

const CLARIFICATION_QUESTIONS_PARAMETER = {
  type: 'array' as const,
  minItems: 1,
  maxItems: 3,
  description: 'Only blocking requirement questions. Prefer choices and keep the batch compact.',
  items: {
    type: 'object' as const,
    additionalProperties: false,
    required: ['id', 'question'],
    properties: {
      id: { type: 'string' as const, description: 'Stable id echoed to Zhongshu with the answer.' },
      question: { type: 'string' as const, description: 'One precise missing decision.' },
      header: { type: 'string' as const, description: 'Short group label.' },
      detail: { type: 'string' as const, description: 'Optional context explaining why this decision matters.' },
      options: {
        type: 'array' as const,
        minItems: 2,
        maxItems: 4,
        description: 'Concrete choices. Put the recommended option first and mark it in the label.',
        items: {
          type: 'object' as const,
          additionalProperties: false,
          required: ['label'],
          properties: {
            label: { type: 'string' as const },
            description: { type: 'string' as const },
          },
        },
      },
      multi_select: { type: 'boolean' as const, description: 'Allow multiple choices when the decisions are independent.' },
    },
  },
}

const CLARIFICATION_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['case_id', 'zhongshu_id', 'questions'],
  properties: {
    case_id: { type: 'string', description: 'Tang case awaiting requirement clarification.' },
    zhongshu_id: { type: 'string', description: 'Existing continuable Zhongshu child id that requested clarification.' },
    questions: CLARIFICATION_QUESTIONS_PARAMETER,
  },
}

const RAISE_CLARIFICATION_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['case_id', 'questions'],
  properties: {
    case_id: { type: 'string', description: 'Tang case whose raw requirement needs clarification before drafting.' },
    questions: CLARIFICATION_QUESTIONS_PARAMETER,
  },
}

const RAISE_CLARIFICATION_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['caseId', 'zhongshuId', 'messageId'],
  properties: {
    caseId: { type: 'string' },
    zhongshuId: { type: 'string' },
    messageId: { type: 'string' },
  },
}

const CLARIFICATION_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['caseId', 'zhongshuId', 'answers', 'messageId'],
  properties: {
    caseId: { type: 'string' },
    zhongshuId: { type: 'string' },
    answers: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['id', 'selected'],
        properties: {
          id: { type: 'string' },
          selected: { type: 'array', items: { type: 'string' } },
          custom: { type: 'string' },
        },
      },
    },
    messageId: { type: 'string' },
  },
}

const APPROVAL_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['case_id', 'title', 'proposal_markdown'],
  properties: {
    case_id: { type: 'string', description: 'Stable Tang case id currently awaiting approval.' },
    title: { type: 'string', description: 'Short heading for the countersigned proposal.' },
    proposal_markdown: {
      type: 'string',
      description: 'Complete review copy covering case scale, scope, architecture, acceptance criteria, verification expectations, risks, and unresolved choices. Execution phases remain Shangshu-owned after approval.',
    },
  },
}

const APPROVAL_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['caseId', 'decision'],
  properties: {
    caseId: { type: 'string' },
    decision: { type: 'string', enum: ['approved', 'remanded'] },
    feedback: { type: 'string' },
  },
}

const FINAL_REPORT_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['case_id', 'title', 'report_markdown'],
  properties: {
    case_id: { type: 'string', description: 'Stable Tang case id ready for closure.' },
    title: { type: 'string', description: 'Short final-report heading.' },
    report_markdown: { type: 'string', description: 'Complete final report and chronicle rendered in the Tang case panel.' },
    verification_options: {
      type: 'array',
      description: 'Optional task-specific actions the user may request before closure. Include only useful actions the coordinator can actually perform.',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['label', 'description', 'instruction'],
        properties: {
          label: { type: 'string', description: 'Short user-facing choice, such as “启动开发服务器并手动测试”.' },
          description: { type: 'string', description: 'What the user can verify after choosing this action.' },
          instruction: { type: 'string', description: 'Bounded coordinator instruction executed before presenting closure again.' },
        },
      },
    },
  },
}

const FINAL_REPORT_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['caseId', 'decision'],
  properties: {
    caseId: { type: 'string' },
    decision: { type: 'string', enum: ['closed', 'remanded', 'followup'] },
    feedback: { type: 'string' },
    selectedOption: { type: 'string' },
    instruction: { type: 'string' },
    zhongshuId: { type: 'string' },
    messageId: { type: 'string' },
    nextAction: { type: 'string' },
    interactionRule: { type: 'string' },
  },
}

const WORKSPACE_KNOWLEDGE_PARAMETERS: ToolDefinition['parameters'] = {
  type: 'object',
  additionalProperties: false,
  required: ['operation'],
  properties: {
    operation: {
      type: 'string',
      enum: ['head', 'details', 'sources', 'upsert', 'no_change'],
      description: 'Read the compact index, expand selected knowledge, inspect cited case artifacts, or let Zhongshu maintain the canonical workspace source.',
    },
    case_id: { type: 'string', description: 'Current case id. Required for upsert and no_change.' },
    knowledge_ids: {
      type: 'array',
      description: 'Exact IDs from the injected head. Required for details.',
      items: { type: 'string' },
    },
    source_artifacts: {
      type: 'array',
      description: 'Exact .tang/cases/... Markdown paths cited by a knowledge entry. Required for sources.',
      items: { type: 'string' },
    },
    entries: {
      type: 'array',
      description: 'Reusable findings to create or update. Search the head first and reuse an existing semantic key instead of duplicating it.',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['key', 'kind', 'topic', 'scope', 'summary', 'details', 'state', 'evidence'],
        properties: {
          key: { type: 'string', description: 'Stable lowercase semantic key, e.g. windows/display-lifecycle.' },
          kind: { type: 'string', enum: [...KNOWLEDGE_KINDS] },
          topic: { type: 'string' },
          scope: { type: 'string', description: 'Where this finding applies and where it does not.' },
          summary: { type: 'string', description: 'One concise reusable conclusion for the index.' },
          details: { type: 'string', description: 'Structured rationale, pitfall, remedy, and validation knowledge; never a chronological case log.' },
          state: { type: 'string', enum: ['provisional', 'confirmed'] },
          evidence: {
            type: 'array',
            items: {
              type: 'object',
              additionalProperties: false,
              required: ['artifact', 'note'],
              properties: {
                artifact: { type: 'string', description: 'Exact current-case Markdown artifact under .tang/cases/<case-id>/.' },
                note: { type: 'string', description: 'Which fact in the artifact supports this knowledge.' },
              },
            },
          },
          supersedes: {
            type: 'array',
            description: 'Older knowledge IDs made obsolete by this entry.',
            items: { type: 'string' },
          },
        },
      },
    },
    reason: { type: 'string', description: 'Concrete reason the current case adds no reusable cross-case knowledge.' },
  },
}

const WORKSPACE_KNOWLEDGE_OUTPUT: ToolDefinition['output']['schema'] = {
  type: 'object',
  additionalProperties: false,
  required: ['operation', 'path'],
  properties: {
    operation: { type: 'string', enum: ['head', 'details', 'sources', 'upsert', 'no_change'] },
    path: { type: 'string' },
    content: { type: 'string' },
    knowledgeIds: { type: 'array', items: { type: 'string' } },
    updatedIds: { type: 'array', items: { type: 'string' } },
    decision: { type: 'string' },
  },
}

/** Register Tang prompt policy, delegation, and durable progress tools. */
export function apply(ctx: Context, config: Config = {}): void {
  const configuredDepartments = departmentRoutes(config)
  let readDepartmentRoutes = (): TangDepartmentRoutes => configuredDepartments
  ctx.inject(['settings'], (settingsCtx) => {
    const scope = settingsCtx.settings.register(
      settingsNamespace(TANG_SETTINGS_NAMESPACE),
      DepartmentRoutesSchema,
      { base: configuredDepartments },
    )
    readDepartmentRoutes = () => scope.get()
    settingsCtx.effect(() => () => { readDepartmentRoutes = () => configuredDepartments })
  })

  const routeFor = (office: TangOffice): TangOfficeRoute | undefined => {
    const routes = readDepartmentRoutes()
    if (TANG_DEPARTMENTS.includes(office as typeof TANG_DEPARTMENTS[number])) {
      return routes[office as typeof TANG_DEPARTMENTS[number]]
    }
    const shangshu = routes.shangshu
    if (shangshu === undefined) return undefined
    const { reasoningEffort: _shangshuReasoning, ...inheritedModelRoute } = shangshu
    return Object.keys(inheritedModelRoute).length === 0 ? undefined : inheritedModelRoute
  }

  ctx.systemPrompt.section({ name: 'tang:governance', order: 118, text: SYSTEM_PROMPT })

  ctx.on('tools/pre-execute', async (exec, next) => {
    if (exec.name === 'ask_user_question' && exec.agent !== undefined
      && callerOffice(exec.agent.session.events) === null
      && closureRemandIndex(exec.agent.session.events) >= 0) {
      return {
        kind: 'deny',
        reason: '结案驳回由中书省处理。等待中书省汇报；如其提出阻塞问题，只能用 tang_request_clarification 原样转交，不得由协调器自行提问。',
      }
    }
    return next()
  })

  ctx.on('agent/request', async ({ agent }, next): Promise<LlmCallConfig> => {
    const resolved = await next()
    const office = callerOffice(agent.session.events)
    if (office === null || office === undefined) return resolved
    const configured = routeFor(office)
    const routed = configured === undefined ? resolved : applyRequestRoute(resolved, configured)
    if (!MINISTRIES.has(office)) return routed

    const desiredEffort = delegatedReasoning(agent.session.events)
    if (desiredEffort === undefined) return routed
    const modelInfo = await ctx.llm.resolveModelInfo(routed.provider, routed.model)
    return replaceReasoningEffort(routed, compatibleReasoningEffort(desiredEffort, modelInfo.reasoning))
  })

  ctx.on('agent/pre-step', async ({ agent, signal }, next): Promise<PreStepDecision> => {
    const decision = await next()
    if (decision.kind === 'reject' || config.autoDispatch === false) return decision
    if (callerOffice(agent.session.events) !== null || hasEnteredUserRequirement(agent.session.events)) return decision
    const requirement = originalRequirement(decision.messages)
    if (requirement.length === 0) return decision

    const existing = (await ctx.subagents.listChildren(agent.session.header.id, signal))
      .find(entry => entry.kind === 'child' && entry.mode === 'continuable' && entry.label.includes('[中书省]'))
    let childId = existing?.id
    if (childId === undefined) {
      const caseScale = suggestedCaseScale(requirement)
      const route = routeFor('zhongshu')
      const options = agentOptions(route)
      const knowledgeHead = await knowledgeHeadForSession(agent.session.header.cwd)
      const zhongshuPrompt = promptWithKnowledgeHead(promptWithCaseScale('TANG_OFFICE:zhongshu\n你是中书省。需求澄清是从接案到提交门下省前持续生效的门禁，不是开头只检查一次。收到原始需求后，先阅读运行时注入的工作区知识索引头，只在索引显示确有相关条目时调用 tang_workspace_knowledge 的 details；只有需要核对原始证据时才调用 sources，不得一开始加载整份知识文档。随后检查是否存在会实质改变范围、量级、技术方向、用户可见行为或验收方式的缺失决定；在检查仓库后、起草过程中以及报告完成前若新发现此类决定，也必须重新触发同一门禁。你在任何时刻都不得调用默认／通用用户提问机制，不得直接向用户提问；用户问询只能由协调器发起。发现阻塞决定时，立即停止起草，把已写内容视为暂定，不得报告“需求明确”或“起草完成”，不得进入门下省；先用 tang_progress 将 requirement-clarification 记录为 waiting_input，再调用 tang_raise_clarification 提交 1～3 个结构化问题，优先给出 2～4 个具体选项并把推荐项放在第一位，然后结束本轮等待。协调器会调用 tang_request_clarification 通过标准问询界面取得答案，并续接当前中书省会话。收到 <tang-clarification-answers> 后把 requirement-clarification 记录为 succeeded，复核答案是否解决全部阻塞项，再将 zhongshu-draft 记录为 running 并继续。若确认无需澄清，也必须先用 tang_progress 把 requirement-clarification 记录为 succeeded，再将 zhongshu-draft 记录为 running。只有门禁通过后，才按 small／medium／large 判断量级，并写入 .tang/cases/<case-id>/01-requirements.md 与 02-draft-solution.md；提交前必须再做一次阻塞决定检查。在两个文档及回报中写明 case_scale、判断依据与不确定性。前期文档只写决策级架构方向、规范、范围、风险与验收，不得写函数级实现、精确补丁或逐文件开发步骤。引用共享知识时必须保留知识 ID；若其状态为 provisional 或与当前仓库事实冲突，应核对来源案卷并以当前证据为准。你只负责需求量级、范围和方案，不得选择六部、安排跨部门工作或编写尚书省的执行阶段，也不得直接实现功能。\n\n原始需求如下：', caseScale), knowledgeHead)
      const request = {
        label: '[中书省] 分析需求并起草方案',
        prompt: [{
          type: 'text' as const,
          text: zhongshuPrompt,
        }, ...requirement],
        parent: agent,
        ...(options === undefined ? {} : { agentOptions: options }),
      }
      const started = await ctx.subagents.startContinuable({
        provider: config.subagentProvider ?? 'spawn',
        label: request.label,
        request,
        signal,
      })
      childId = started.childId
    }

    return {
      kind: 'enter',
      messages: [...decision.messages, pluginMessage([
        '<tang-runtime-dispatch>',
        `运行时已将本次原始需求强制派发给中书省，子 Agent ID：${childId}。`,
        '你是顶层协调器，不得直接分析、设计或实现用户需求，也不得重复创建中书省。',
        '本轮只允许：调用 tang_progress 记录 intake/zhongshu-draft，向用户说明已进入三省六部流程，并等待或检查中书省汇报后再派门下省复核。',
        '</tang-runtime-dispatch>',
      ].join('\n'), '已自动派发中书省')],
    }
  })

  ctx.tools.register({
    name: 'tang_workspace_knowledge',
    description: 'Progressively read or maintain the one canonical workspace knowledge document. Use head first, details only for selected IDs, and sources only to inspect cited original case artifacts. Only Zhongshu may upsert reusable knowledge or record that a case adds none.',
    parameters: WORKSPACE_KNOWLEDGE_PARAMETERS,
    output: {
      schema: WORKSPACE_KNOWLEDGE_OUTPUT,
      render: (_args, value) => {
        const result = value as unknown as { readonly operation: string; readonly content?: string; readonly knowledgeIds?: readonly string[]; readonly updatedIds?: readonly string[]; readonly decision?: string }
        if (result.content !== undefined) return [{ type: 'text', text: result.content }]
        const ids = result.updatedIds ?? result.knowledgeIds ?? []
        return [{ type: 'text', text: `工作区知识 · ${result.operation}${ids.length === 0 ? '' : ` · ${ids.join(', ')}`}${result.decision === undefined ? '' : ` · ${result.decision}`}` }]
      },
    },
    async execute(value, exec) {
      const args = workspaceKnowledgeArgs(value)
      const agent = exec.agent
      if (agent === undefined) throw new Error('tang_workspace_knowledge requires a calling agent')
      const cwd = agent.session.header.cwd
      if (cwd === undefined || cwd.trim() === '') throw new Error('tang_workspace_knowledge requires a session working directory')
      const path = knowledgePath(cwd)

      if (args.operation === 'head') {
        const store = await ensureKnowledgeDocument(cwd)
        return {
          operation: args.operation,
          path: WORKSPACE_KNOWLEDGE_RELATIVE_PATH,
          content: renderKnowledgeHead(store),
          knowledgeIds: store.entries.filter(entry => entry.state !== 'superseded').map(entry => entry.id),
        }
      }

      if (args.operation === 'details') {
        const store = await ensureKnowledgeDocument(cwd)
        const selected = (args.knowledge_ids ?? []).map((id) => {
          const entry = store.entries.find(candidate => candidate.id === id)
          if (entry === undefined) throw new Error(`unknown workspace knowledge id: ${id}`)
          return entry
        })
        return {
          operation: args.operation,
          path: WORKSPACE_KNOWLEDGE_RELATIVE_PATH,
          content: selected.map(renderKnowledgeEntry).join('\n\n'),
          knowledgeIds: selected.map(entry => entry.id),
        }
      }

      if (args.operation === 'sources') {
        const store = await ensureKnowledgeDocument(cwd)
        const referenced = new Set(store.entries.flatMap(entry => entry.evidence.map(item => item.artifact)))
        const artifacts = args.source_artifacts ?? []
        for (const artifact of artifacts) {
          if (!referenced.has(artifact)) throw new Error(`source artifact is not cited by workspace knowledge: ${artifact}`)
        }
        const sections = await Promise.all(artifacts.map(async artifact => [
          `## 原始案卷 · ${artifact}`,
          '',
          await readFile(resolve(cwd, artifact), 'utf8'),
        ].join('\n')))
        return {
          operation: args.operation,
          path: WORKSPACE_KNOWLEDGE_RELATIVE_PATH,
          content: sections.join('\n\n'),
          knowledgeIds: store.entries
            .filter(entry => entry.evidence.some(item => artifacts.includes(item.artifact)))
            .map(entry => entry.id),
        }
      }

      if (callerOffice(agent.session.events) !== 'zhongshu') {
        throw new Error('only Zhongshu may maintain workspace knowledge')
      }
      if (args.operation === 'no_change') {
        await ensureKnowledgeDocument(cwd)
        return {
          operation: args.operation,
          path: WORKSPACE_KNOWLEDGE_RELATIVE_PATH,
          decision: `no reusable knowledge from ${args.case_id}: ${args.reason}`,
        }
      }

      return await withKnowledgeLock(path, async () => {
        const store = await ensureKnowledgeDocument(cwd)
        const result = upsertWorkspaceKnowledge(store, args.case_id ?? '', args.entries ?? [])
        await writeKnowledgeStore(cwd, result.store)
        return {
          operation: args.operation,
          path: WORKSPACE_KNOWLEDGE_RELATIVE_PATH,
          updatedIds: result.updatedIds,
          knowledgeIds: result.store.entries.filter(entry => entry.state !== 'superseded').map(entry => entry.id),
          decision: `workspace knowledge updated from ${args.case_id}`,
        }
      })
    },
  })

  ctx.tools.register({
    name: 'tang_progress',
    description: 'Record one Three Departments and Six Ministries workflow transition. Call this for every pass, remand, approval wait, approval result, execution stage, stop, failure, and completion.',
    parameters: PROGRESS_PARAMETERS,
    output: {
      schema: PROGRESS_OUTPUT,
      render: (args) => {
        const parsed = progressArgs(args, false)
        return [{ type: 'text', text: `${parsed.stage}: ${parsed.status} — ${parsed.title}` }]
      },
    },
    execute: async (value, exec) => {
      const args = progressArgs(value)
      if (exec.agent === undefined) throw new Error('tang_progress requires a calling agent')
      assertProgressAuthority(args.office, args.status, exec.agent.session.events)
      return { recorded: true as const, caseId: args.case_id, stage: args.stage, status: args.status }
    },
  })

  ctx.tools.register({
    name: 'tang_plan_ministries',
    description: 'Register Shangshu\'s structured responsibility scan and dispatch plan for one approved phase. All Six Ministries are assessed without a preferred combination: each is assigned within its mandate or omitted with a concrete changed-surface reason, and Shangshu coordinates dependencies among the selected offices.',
    parameters: MINISTRY_PLAN_PARAMETERS,
    output: {
      schema: MINISTRY_PLAN_OUTPUT,
      render: (_args, value) => {
        const result = value as { readonly caseId: string; readonly phase: string; readonly assignments: number; readonly assessedOffices: number }
        return [{ type: 'text', text: `六部职责已逐项评估 · ${result.phase} · 启用 ${result.assignments} 项任务` }]
      },
    },
    async execute(value, exec) {
      const args = ministryPlanArgs(value)
      if (exec.agent === undefined || callerOffice(exec.agent.session.events) !== 'shangshu') {
        throw new Error('only Shangshu may register a Six Ministries dispatch plan')
      }
      return { caseId: args.case_id, phase: args.phase, assignments: args.assignments.length, assessedOffices: 6 }
    },
  })

  ctx.tools.register({
    name: 'tang_record_ministry_result',
    description: 'Record Shangshu\'s structured assessment of one delegated Ministry assignment. Dependencies unlock only after this tool records succeeded with concrete evidence.',
    parameters: MINISTRY_RESULT_PARAMETERS,
    output: {
      schema: MINISTRY_RESULT_OUTPUT,
      render: (_args, value) => {
        const result = value as { readonly assignmentId: string; readonly office: TangMinistry; readonly status: 'succeeded' | 'failed' }
        return [{ type: 'text', text: `${result.assignmentId} · ${OFFICE_LABELS[result.office]} · ${result.status}` }]
      },
    },
    async execute(value, exec) {
      const args = ministryResultArgs(value)
      if (exec.agent === undefined || callerOffice(exec.agent.session.events) !== 'shangshu') {
        throw new Error('only Shangshu may record a Ministry assignment result')
      }
      const assignment = acceptedMinistryAssignment(exec.agent.session.events, args.assignment_id)
      if (assignment === undefined) throw new Error(`unknown Ministry assignment_id: ${args.assignment_id}`)
      if (assignment.office !== args.office) {
        throw new Error(`${args.assignment_id} belongs to ${OFFICE_LABELS[assignment.office]}, not ${OFFICE_LABELS[args.office]}`)
      }
      if (!assignmentWasDelegated(exec.agent.session.events, args.assignment_id)) {
        throw new Error(`${args.assignment_id} cannot report a result before successful delegation`)
      }
      return { assignmentId: args.assignment_id, office: args.office, status: args.status }
    },
  })

  ctx.tools.register({
    name: 'tang_raise_clarification',
    description: 'Zhongshu-only lifecycle clarification gate. Whenever a blocking user decision is discovered before or during drafting, report it to the coordinator. Never ask the user directly or use a generic question mechanism. This creates the structured relay request that the coordinator must present through tang_request_clarification.',
    parameters: RAISE_CLARIFICATION_PARAMETERS,
    output: {
      schema: RAISE_CLARIFICATION_OUTPUT,
      render: (_args, value) => {
        const result = value as unknown as { readonly caseId: string; readonly zhongshuId: string }
        return [{ type: 'text', text: `clarification raised · ${result.caseId} · waiting for coordinator relay from ${result.zhongshuId}` }]
      },
    },
    async execute(value, exec) {
      const args = raiseClarificationArgs(value)
      const child = exec.agent
      if (child === undefined || callerOffice(child.session.events) !== 'zhongshu') {
        throw new Error('only Zhongshu may raise requirement clarification')
      }
      const messageId = await ctx.subagents.reportFrom(
        child,
        [{
          type: 'text',
          text: [
            '<tang-clarification-request>',
            `case_id: ${args.case_id}`,
            `zhongshu_id: ${child.id}`,
            JSON.stringify({ questions: args.questions }),
            'The Zhongshu workflow is blocked and any existing draft is provisional. Call tang_request_clarification with this exact case_id, zhongshu_id, and questions. Do not delegate Menxia or accept a draft-complete report until answers are relayed and Zhongshu revalidates the draft.',
            '</tang-clarification-request>',
          ].join('\n'),
        }],
        { delivery: 'next-step', signal: exec.signal },
      )
      return { caseId: args.case_id, zhongshuId: child.id, messageId }
    },
  })

  ctx.tools.register({
    name: 'tang_request_clarification',
    description: 'Relay Zhongshu\'s blocking requirement questions through the standard user-question channel, then continue the same Zhongshu child with the structured answers. Use only questions Zhongshu reported; do not ask speculative or non-blocking questions.',
    parameters: CLARIFICATION_PARAMETERS,
    output: {
      schema: CLARIFICATION_OUTPUT,
      render: (_args, value) => {
        const result = value as unknown as { readonly caseId: string; readonly zhongshuId: string; readonly answers: readonly unknown[] }
        return [{ type: 'text', text: `clarification answered · ${result.caseId} · ${result.answers.length} answers relayed to ${result.zhongshuId}` }]
      },
    },
    async execute(value, exec) {
      const args = clarificationArgs(value)
      const parent = exec.agent
      if (parent === undefined) throw new Error('tang_request_clarification requires a calling coordinator')
      if (callerOffice(parent.session.events) !== null) {
        throw new Error('Zhongshu reports clarification questions; only the coordinator may open the user interaction channel')
      }
      const remandIndex = closureRemandIndex(parent.session.events)
      if (remandIndex >= 0) {
        const reported = parent.session.events.slice(remandIndex + 1).some(event => {
          if (event.type !== 'user/message' || event.data.source.kind !== 'subagent-report'
            || event.data.source.senderSessionId !== args.zhongshu_id) return false
          const text = event.data.content.filter(block => block.type === 'text').map(block => block.text).join('\n')
          return text.includes('<tang-clarification-request>')
            && text.split('\n').includes(`case_id: ${args.case_id}`)
            && text.split('\n').includes(JSON.stringify({ questions: args.questions }))
        })
        if (!reported) {
          throw new Error('Closure remand questions must be relayed unchanged from a new Zhongshu tang_raise_clarification report; the coordinator cannot invent them.')
        }
      }
      const wireToOriginal = new Map<string, string>()
      const questions = args.questions.map((question) => {
        const wireId = `${TANG_CLARIFICATION_QUESTION_PREFIX}${args.case_id}:${question.id}`
        wireToOriginal.set(wireId, question.id)
        return {
          id: wireId,
          question: question.question,
          ...(question.header === undefined ? {} : { header: question.header }),
          ...(question.detail === undefined ? {} : { detail: question.detail }),
          ...(question.options === undefined ? {} : { options: [...question.options] }),
          ...(question.multi_select === undefined ? {} : { multiSelect: question.multi_select }),
        }
      })
      const result = await ctx.userQuestions.ask({ questions, agent: parent, signal: exec.signal })
      const answers = result.answers.map(answer => ({
        id: wireToOriginal.get(answer.id) ?? answer.id,
        selected: [...answer.selected],
        ...(answer.custom === undefined ? {} : { custom: answer.custom }),
      }))
      const messageId = await ctx.subagents.followup(
        parent,
        SessionId(args.zhongshu_id),
        [{
          type: 'text',
          text: [
            'TANG_OFFICE:zhongshu',
            '<tang-clarification-answers>',
            `case_id: ${args.case_id}`,
            JSON.stringify({ answers }),
            'Continue the existing requirement analysis from these answers. Preserve prior artifacts and revise only affected assumptions, case scale, requirements, or solution sections.',
            '</tang-clarification-answers>',
          ].join('\n'),
        }],
        {
          source: { kind: 'coordinator', form: 'relay', senderSessionId: parent.id },
          signal: exec.signal,
        },
      )
      return { caseId: args.case_id, zhongshuId: args.zhongshu_id, answers, messageId }
    },
  })

  ctx.tools.register({
    name: 'tang_request_approval',
    description: 'Submit the complete countersigned Tang proposal to the user. The call blocks until the user approves, remands with feedback, or cancels the task.',
    parameters: APPROVAL_PARAMETERS,
    output: {
      schema: APPROVAL_OUTPUT,
      render: (_args, value) => {
        const result = value as { readonly caseId: string; readonly decision: 'approved' | 'remanded'; readonly feedback?: string }
        return [{
          type: 'text',
          text: result.decision === 'approved'
            ? `${TANG_APPROVE_LABEL} · ${result.caseId}`
            : `${TANG_REMAND_LABEL} · ${result.caseId}${result.feedback === undefined ? '' : ` · ${result.feedback}`}`,
        }]
      },
    },
    async execute(value, exec) {
      const args = approvalArgs(value)
      if (exec.agent === undefined) throw new Error('tang_request_approval requires the root coordinator')
      const result = await ctx.userQuestions.ask({
        agent: exec.agent,
        signal: exec.signal,
        questions: [{
          id: TANG_APPROVAL_QUESTION_ID,
          header: '三省会签方案',
          question: args.title,
          detail: args.proposal_markdown,
          options: [
            { label: TANG_APPROVE_LABEL, description: '方案通过后交由尚书省分阶段实施。' },
            { label: TANG_REMAND_LABEL, description: '返回中书、门下修订方案后重新上报。' },
          ],
          intent: { kind: 'plan-review', approve: TANG_APPROVE_LABEL },
        }],
      })
      const answer = result.answers[0]
      if (answer?.id !== TANG_APPROVAL_QUESTION_ID) {
        throw new Error('Tang approval returned no matching answer')
      }
      if (answer.selected.includes(TANG_APPROVE_LABEL)) {
        return { caseId: args.case_id, decision: 'approved' as const }
      }
      const feedback = answer.custom?.trim()
      if (feedback !== undefined && feedback !== '') {
        return { caseId: args.case_id, decision: 'remanded' as const, feedback }
      }
      if (answer.selected.includes(TANG_REMAND_LABEL)) {
        return { caseId: args.case_id, decision: 'remanded' as const }
      }
      throw new Error('Tang approval answer did not approve or remand the proposal')
    },
  })

  ctx.tools.register({
    name: 'tang_submit_final_report',
    description: 'Submit the complete accepted Tang implementation report and chronicle for user closure confirmation. Remands are automatically routed to Zhongshu: wait for its report, never handle feedback or invent questions yourself. Only relay Zhongshu clarification via tang_request_clarification. After an explicit verification follow-up the coordinator executes it and calls this tool again; never use a generic question tool for manual-test results.',
    parameters: FINAL_REPORT_PARAMETERS,
    output: {
      schema: FINAL_REPORT_OUTPUT,
      render: (_args, value) => {
        const result = value as { readonly caseId: string; readonly decision: 'closed' | 'remanded' | 'followup'; readonly feedback?: string; readonly selectedOption?: string; readonly zhongshuId?: string }
        return [{
          type: 'text',
          text: result.decision === 'closed'
            ? `${TANG_CLOSE_LABEL} · ${result.caseId}`
            : result.decision === 'followup'
              ? `结案前跟进 · ${result.caseId} · ${result.selectedOption ?? '用户选择'} · 由协调器执行后更新报告并再次调用 tang_submit_final_report；不得使用默认提问工具`
              : `${TANG_REMAND_LABEL} · ${result.caseId} · 已转交中书省 ${result.zhongshuId}；等待中书省处理，协调器不得自行处理意见或提问${result.feedback === undefined ? '' : ` · ${result.feedback}`}`,
        }]
      },
    },
    async execute(value, exec) {
      const args = finalReportArgs(value)
      if (exec.agent === undefined || callerOffice(exec.agent.session.events) !== null) {
        throw new Error('tang_submit_final_report requires the root coordinator')
      }
      if (!hasPassedStage(exec.agent.session.events, 'menxia-acceptance')) {
        throw new Error('Tang final report requires a successful menxia-acceptance passed milestone')
      }
      const result = await ctx.userQuestions.ask({
        agent: exec.agent,
        signal: exec.signal,
        questions: [{
          id: TANG_CLOSURE_QUESTION_ID,
          header: '三省六部结案',
          question: args.title,
          detail: args.report_markdown,
          options: [
            { label: TANG_CLOSE_LABEL, description: '确认交付与验收记录，完成本案归档。' },
            ...(args.verification_options ?? []).map(option => ({ label: option.label, description: option.description })),
            { label: TANG_REMAND_LABEL, description: '将补充意见交回中书省梳理，再按需复核、执行与验收。' },
          ],
        }],
      })
      const answer = result.answers[0]
      if (answer?.id !== TANG_CLOSURE_QUESTION_ID) throw new Error('Tang final report returned no matching answer')
      if (answer.selected.includes(TANG_CLOSE_LABEL)) return { caseId: args.case_id, decision: 'closed' as const }
      const followup = args.verification_options?.find(option => answer.selected.includes(option.label))
      if (followup !== undefined) {
        return {
          caseId: args.case_id,
          decision: 'followup' as const,
          selectedOption: followup.label,
          instruction: followup.instruction,
          nextAction: 'execute_then_resubmit_final_report' as const,
          interactionRule: 'Execute the instruction, update the report, then call tang_submit_final_report again. Do not use a generic/default question tool for test results or feedback.',
        }
      }
      const feedback = answer.custom?.trim()
      if ((feedback !== undefined && feedback !== '') || answer.selected.includes(TANG_REMAND_LABEL)) {
        const parent = exec.agent
        const prompt = [
          'TANG_OFFICE:zhongshu',
          '<tang-closure-remand>',
          `case_id: ${args.case_id}`,
          '用户未确认结案。你是此次驳回的唯一受理部门，继续现有案卷，不要另起案件。',
          '先记录 case-closure 为 remanded、zhongshu-report 为 running；核对原案需求、规范、验收证据与报告，分析意见并提出处理方案。',
          '如意见不足以确定范围或验收，记录 requirement-clarification 为 waiting_input，调用 tang_raise_clarification 提交结构化问题，然后结束本轮等待协调器转交答案；不得直接向用户提问或调用默认提问工具。',
          '不要自行实现代码或替其他部门验收。范围或方案变化须门下复核及必要的用户批准；执行变更交尚书省，完成后由门下重新验收。只修正文档也须说明依据，不要制造无意义重跑。',
          '处理完成后更新本案报告与证据，向协调器汇报下一步；协调器只能调度及转交，不得代替你分析驳回、猜测用户意图或自拟问题。',
          JSON.stringify({ title: args.title, feedback: feedback || null, report_markdown: args.report_markdown }),
          '</tang-closure-remand>',
        ].join('\n')
        const children = await ctx.subagents.listChildren(parent.session.header.id, exec.signal)
        const existing = children.findLast(entry => entry.kind === 'child'
          && entry.mode === 'continuable' && entry.label.includes('[中书省]'))
        let zhongshuId = existing?.id
        let messageId: string | undefined
        if (zhongshuId !== undefined) {
          messageId = await ctx.subagents.followup(parent, zhongshuId, [{ type: 'text', text: prompt }], {
            source: { kind: 'coordinator', form: 'relay', senderSessionId: parent.id },
            signal: exec.signal,
          })
        } else {
          if (children.some(entry => entry.kind === 'diagnostic')) {
            throw new Error('Cannot resolve Zhongshu history for closure remand; retry routing after history becomes available. The coordinator must not handle the feedback itself.')
          }
          const options = agentOptions(routeFor('zhongshu'))
          const label = `[中书省] 结案驳回 · ${args.case_id}`
          const started = await ctx.subagents.startContinuable({
            provider: config.subagentProvider ?? 'spawn', label,
            request: { parent,
              prompt: [{ type: 'text', text: promptWithKnowledgeHead(prompt, await knowledgeHeadForSession(parent.session.header.cwd)) }],
              ...(options === undefined ? {} : { agentOptions: options }),
            },
            signal: exec.signal,
          })
          zhongshuId = started.childId
        }
        return {
          caseId: args.case_id, decision: 'remanded' as const,
          ...(feedback ? { feedback } : {}), zhongshuId,
          ...(messageId === undefined ? {} : { messageId }),
          nextAction: 'wait_for_zhongshu' as const,
          interactionRule: 'Remand feedback has been routed to Zhongshu. Do not analyze, implement, or ask questions yourself. Wait for its report; only relay its blocking questions through tang_request_clarification, then continue the necessary review, execution, acceptance and report steps.',
        }
      }
      throw new Error('Tang final report answer did not close or remand the case')
    },
  })

  ctx.tools.register({
    name: 'tang_delegate',
    description: 'Start one continuable Tang office agent. The coordinator delegates Departments; Shangshu delegates Ministries. Returns immediately with the durable child id.',
    parameters: DELEGATE_PARAMETERS,
    output: {
      schema: DELEGATE_OUTPUT,
      render: (_args, value) => {
        const record = value as { office: TangOffice; subagentId: string }
        return [{ type: 'text', text: `started ${OFFICE_LABELS[record.office]} as subagent ${record.subagentId}` }]
      },
    },
    async execute(value, exec) {
      const args = delegateArgs(value)
      const parent = exec.agent
      if (parent === undefined) throw new Error('tang_delegate requires a calling agent')
      assertDelegationAuthority(args.office, parent.session.events)
      let assignment: MinistryAssignment | undefined
      if (MINISTRIES.has(args.office)) {
        if (args.reasoning_effort === undefined || args.reasoning_effort.trim() === '') {
          throw new Error('Shangshu must choose reasoning_effort for every Ministry delegation')
        }
        if (args.assignment_id === undefined || args.assignment_id.trim() === '') {
          throw new Error('Shangshu must cite assignment_id from an accepted tang_plan_ministries plan')
        }
        const plan = latestAcceptedMinistryPlan(parent.session.events)
        if (plan === undefined) throw new Error('Shangshu must register tang_plan_ministries before delegating a Ministry')
        assignment = plan.assignments.find(item => item.assignment_id === args.assignment_id)
        if (assignment === undefined) throw new Error(`unknown Ministry assignment_id: ${args.assignment_id}`)
        if (assignment.office !== args.office) {
          throw new Error(`${args.assignment_id} belongs to ${OFFICE_LABELS[assignment.office]}, not ${OFFICE_LABELS[args.office]}`)
        }
        if (assignment.reasoning_effort !== args.reasoning_effort) {
          throw new Error(`${args.assignment_id} requires reasoning_effort ${assignment.reasoning_effort}`)
        }
        for (const dependency of assignment.depends_on ?? []) {
          if (!assignmentSucceeded(parent.session.events, dependency)) {
            throw new Error(`${args.assignment_id} is blocked until ${dependency} is recorded succeeded`)
          }
        }
      } else if (args.reasoning_effort !== undefined) {
        throw new Error('reasoning_effort is chosen by Shangshu only when delegating a Ministry')
      } else if (args.assignment_id !== undefined) {
        throw new Error('assignment_id is used by Shangshu only when delegating a Ministry')
      }
      const expectedPrefix = `TANG_OFFICE:${args.office}`
      if (!args.prompt.trimStart().startsWith(expectedPrefix)) {
        throw new Error(`tang_delegate prompt must begin with ${expectedPrefix}`)
      }
      const provider = config.subagentProvider ?? 'spawn'
      const caseScale = DEPARTMENTS.has(args.office) ? (args.case_scale ?? 'medium') : undefined
      const route = routeFor(args.office)
      const options = agentOptions(route)
      const boundedPrompt = assignment === undefined ? args.prompt : promptWithMinistryMandate(args.prompt, assignment)
      const scaledPrompt = caseScale === undefined ? boundedPrompt : promptWithCaseScale(boundedPrompt, caseScale)
      const knowledgePrompt = args.office === 'zhongshu'
        ? promptWithKnowledgeHead(scaledPrompt, await knowledgeHeadForSession(parent.session.header.cwd))
        : scaledPrompt
      const request = {
        label: `[${OFFICE_LABELS[args.office]}] ${args.description}`,
        prompt: [{ type: 'text', text: promptWithReasoning(knowledgePrompt, args.reasoning_effort) }] as ContentBlock[],
        parent,
        ...(options === undefined ? {} : { agentOptions: options }),
      }
      const started = await ctx.subagents.startContinuable({
        provider,
        label: request.label,
        request,
        signal: exec.signal,
      })
      return { office: args.office, subagentId: started.childId }
    },
  })
}

export { MINISTRIES }
