window.__ModuleLoader__.load({
  id: 'dsh-quick-restart',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useEffect, useRef, useState } = React;
    let createPortal = null;
    try {
      createPortal = require('react-dom').createPortal ?? null;
    } catch {
      createPortal = null;
    }

    const STYLE_ID = 'dsh-quick-restart-style';

    const EN = {
      menu: 'Account menu',
      more: 'More',
      signedIn: 'Signed in',
      settings: 'Settings',
      contactUs: 'Feedback',
      quickRestart: 'Quick Restart',
      signOut: 'Sign out',
      signIn: 'Sign in',
      cancel: 'Cancel',
      ok: 'OK',
      restartTitle: 'Quick Restart',
      restartBody: 'DSH will quit and relaunch now. Running work will be interrupted.',
      restartAction: 'Restart now',
      restartingTitle: 'Restarting DSH',
      restartingBody: 'The window will close and reopen automatically.',
      signOutTitle: 'Sign out',
      signOutBody: 'Sign out of the current account?',
      signOutAction: 'Sign out',
      restartFailed: 'Restart failed',
      restartTimeout: 'Restart is taking longer than expected. DSH is still running; please quit and reopen it manually',
      signOutFailed: 'Sign out failed',
      errorTitle: 'Something went wrong',
    };

    const ZH = {
      menu: '账号菜单',
      more: '更多',
      signedIn: '已登录',
      settings: '设置',
      contactUs: '意见反馈',
      quickRestart: '快速重启',
      signOut: '退出登录',
      signIn: '登录',
      cancel: '取消',
      ok: '好的',
      restartTitle: '快速重启',
      restartBody: 'DSH 将立即退出并重新启动，正在运行的任务会被中断。',
      restartAction: '立即重启',
      restartingTitle: '正在重启 DSH',
      restartingBody: '窗口将关闭并自动重新打开。',
      signOutTitle: '退出登录',
      signOutBody: '确定要退出当前账号吗？',
      signOutAction: '退出登录',
      restartFailed: '重启失败',
      restartTimeout: '重启耗时过长，DSH 仍在运行。请手动退出并重新打开 DSH',
      signOutFailed: '退出登录失败',
      errorTitle: '操作失败',
    };

    const CSS = [
      '.qr-root{position:relative;display:inline-flex;flex:1;min-width:0}',
      '.qr-anchor{width:100%}',
      '.qr-trigger{user-select:none;border-radius:var(--dsw-radius-md);width:100%;height:44px;color:var(--dsw-alias-label-primary);font:inherit;cursor:pointer;background:0 0;border:0;align-items:center;gap:8px;padding:6px;font-size:14px;display:flex}',
      '.qr-trigger[data-collapsed=true]{box-sizing:border-box;justify-content:center;gap:0;width:36px;height:36px;padding:0}',
      '.qr-trigger:hover{background:var(--dsw-alias-interactive-bg-hover)}',
      '.qr-avatar{corner-shape:round;background:var(--dsw-alias-bg-skeleton);width:24px;height:24px;color:var(--dsw-alias-label-tertiary);border-radius:50%;flex:none;justify-content:center;align-items:center;display:flex;overflow:hidden}',
      '.qr-avatarImage{corner-shape:round;object-fit:cover;border-radius:50%;width:100%;height:100%;display:block}',
      '.qr-label{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}',
      '.qr-trigger[data-signed-out=true]:not([data-collapsed=true]){height:32px;padding:6px 2px 6px 6px;line-height:20px}',
      '.qr-menu{position:fixed;z-index:1100;box-sizing:border-box;padding:4px;display:flex;flex-direction:column;gap:0;border:0;min-width:144px;max-width:360px;border-radius:var(--dsw-radius-lg);isolation:isolate;--dsw-elevation-stroke-color:var(--dsw-alias-border-l1);box-shadow:var(--dsw-elevation-prominent)}',
      '.qr-menuMaterial{position:absolute;inset:0;z-index:-1;border-radius:inherit;background:var(--dsw-menu-surface-fill,var(--dsw-alias-bg-layer-2));backdrop-filter:var(--dsw-menu-backdrop-filter);pointer-events:none}',
      '.qr-viewport{display:flex;flex-direction:column;min-height:0;position:relative;z-index:1}',
      '.qr-itemWrap{position:relative}',
      '.qr-item{display:flex;align-items:center;gap:6px;width:100%;min-height:34px;padding:6px 8px;border:none;border-radius:var(--dsw-radius-md);background:transparent;cursor:pointer;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);text-align:left;font-family:inherit}',
      '.qr-item:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}',
      '.qr-item:focus-visible:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);outline:none}',
      '.qr-item:disabled{opacity:.4;cursor:not-allowed}',
      '.qr-itemIcon{display:inline-flex;flex:none;width:14px;height:14px;align-items:center;justify-content:center;color:var(--dsw-alias-menu-icon)}',
      '.qr-itemIcon svg{width:14px;height:14px}',
      '.qr-itemLabel{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.qr-shortcut{flex:none;margin-inline-start:auto;display:inline-flex;align-items:center;gap:2px;color:var(--dsw-alias-label-caption);font-size:11px;line-height:16px}',
      '.qr-shortcutSep{color:var(--dsw-alias-label-caption);font-size:11px;line-height:16px}',
      '.qr-key{font:inherit;color:inherit;background:none;border:0;padding:0}',
      '.qr-overlay{position:fixed;inset:0;z-index:1200;display:flex;align-items:center;justify-content:center;background:var(--dsw-alias-bg-mask-1,rgba(0,0,0,.4))}',
      '.qr-dialog{box-sizing:border-box;width:min(380px,calc(100vw - 32px));padding:20px;border-radius:var(--dsw-radius-panel);background:var(--dsw-alias-bg-layer-2);box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-primary)}',
      '.qr-dialogTitle{margin:0 0 8px;font-size:16px;line-height:24px;font-weight:600}',
      '.qr-dialogBody{margin:0;font-size:13px;line-height:20px;color:var(--dsw-alias-label-secondary,var(--dsw-alias-label-primary));word-break:break-word}',
      '.qr-dialogFooter{display:flex;justify-content:flex-end;gap:8px;margin-top:16px}',
      '.qr-btn{border-radius:var(--dsw-radius-md);padding:7px 14px;font-size:13px;line-height:18px;cursor:pointer;border:1px solid var(--dsw-alias-border-l2);background:transparent;color:var(--dsw-alias-label-primary);font-family:inherit}',
      '.qr-btn:hover{background:var(--dsw-alias-interactive-bg-hover)}',
      '.qr-btnPrimary{background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-layer-2);border-color:transparent}',
      '.qr-btnPrimary:hover{opacity:.9;background:var(--dsw-alias-label-primary)}',
      '.qr-spinner{display:inline-block;width:14px;height:14px;margin-right:6px;border-radius:50%;border:2px solid var(--dsw-alias-border-l2);border-top-color:var(--dsw-alias-label-primary);animation:qr-spin .8s linear infinite;vertical-align:-2px}',
      '@keyframes qr-spin{to{transform:rotate(360deg)}}',
    ].join('\n');

    function makeIcon(children) {
      return function Icon(props) {
        return h('svg', {
          width: props?.size ?? 16,
          height: props?.size ?? 16,
          viewBox: '0 0 16 16',
          fill: 'none',
          'aria-hidden': 'true',
          focusable: 'false',
        }, children);
      };
    }

    const IconGear = makeIcon([
      h('circle', { key: 'c', cx: '8', cy: '8', r: '2.1', stroke: 'currentColor', strokeWidth: '1.4' }),
      h('path', {
        key: 'p',
        d: 'M8 1.5v1.6M8 12.9v1.6M1.5 8h1.6M12.9 8h1.6M3.4 3.4l1.1 1.1M11.5 11.5l1.1 1.1M12.6 3.4l-1.1 1.1M4.5 11.5l-1.1 1.1',
        stroke: 'currentColor',
        strokeWidth: '1.4',
        strokeLinecap: 'round',
      }),
    ]);

    const IconSend = makeIcon([
      h('path', {
        key: 'p',
        d: 'M2.3 8.1 13.7 2.6 11.1 13.8 8.1 9.8 2.3 8.1Z',
        stroke: 'currentColor',
        strokeWidth: '1.4',
        strokeLinejoin: 'round',
      }),
    ]);

    const IconRefresh = makeIcon([
      h('path', {
        key: 'a',
        d: 'M13.3 8a5.3 5.3 0 1 1-1.6-3.8',
        stroke: 'currentColor',
        strokeWidth: '1.4',
        strokeLinecap: 'round',
      }),
      h('path', {
        key: 'b',
        d: 'M11.7 1.6v2.8H8.9',
        stroke: 'currentColor',
        strokeWidth: '1.4',
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
      }),
    ]);

    const IconLogout = makeIcon([
      h('path', { key: 'a', d: 'M6.2 2.6H3.4v10.8h2.8', stroke: 'currentColor', strokeWidth: '1.4', strokeLinecap: 'round', strokeLinejoin: 'round' }),
      h('path', { key: 'b', d: 'M9.4 5.1 12.6 8l-3.2 2.9M6.4 8h6', stroke: 'currentColor', strokeWidth: '1.4', strokeLinecap: 'round', strokeLinejoin: 'round' }),
    ]);

    const IconUser = makeIcon([
      h('circle', { key: 'a', cx: '8', cy: '5.2', r: '2.4', stroke: 'currentColor', strokeWidth: '1.4' }),
      h('path', { key: 'b', d: 'M3.4 13.3c.5-2.4 2.3-3.7 4.6-3.7s4.1 1.3 4.6 3.7', stroke: 'currentColor', strokeWidth: '1.4', strokeLinecap: 'round' }),
    ]);

    const IconEllipsis = makeIcon([
      h('circle', { key: 'a', cx: '3.4', cy: '8', r: '1.2', fill: 'currentColor' }),
      h('circle', { key: 'b', cx: '8', cy: '8', r: '1.2', fill: 'currentColor' }),
      h('circle', { key: 'c', cx: '12.6', cy: '8', r: '1.2', fill: 'currentColor' }),
    ]);

    function renderShortcutKeys(keys) {
      const nodes = [];
      keys.forEach((key, index) => {
        if (key === '+') {
          nodes.push(h('span', { key: 'sep-' + index, className: 'qr-shortcutSep' }, '+'));
          return;
        }
        if (index > 0) nodes.push(h('span', { key: 'sep-' + index, className: 'qr-shortcutSep' }, '+'));
        nodes.push(h('kbd', { key: 'key-' + index, className: 'qr-key' }, key));
      });
      return nodes;
    }

    async function apply(ctx) {
      ctx.effect(() => ctx.locale.register('dshQuickRestart', { en: EN, zh: ZH }), 'dsh-quick-restart: locale');

      ctx.effect(() => {
        let element = document.getElementById(STYLE_ID);
        if (!element) {
          element = document.createElement('style');
          element.id = STYLE_ID;
          document.head.append(element);
        }
        element.textContent = CSS;
        return () => {
          element?.remove();
        };
      }, 'dsh-quick-restart: styles');

      const requestJson = async (action) => {
        const response = await fetch('/dsh-quick-restart/' + action, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          cache: 'no-store',
          body: JSON.stringify({
            locale: ctx.locale.getSnapshot().active,
            timezoneOffsetSeconds: -new Date().getTimezoneOffset() * 60,
          }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'request failed (' + response.status + ')');
        return data;
      };

      let desktopSupported = false;
      for (let attempt = 0; attempt < 8 && !desktopSupported; attempt += 1) {
        if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 400));
        try {
          const status = await requestJson('status');
          desktopSupported = Boolean(status && status.supported);
        } catch (error) {
          console.warn('[dsh-quick-restart] restart capability probe failed (attempt ' + (attempt + 1) + ')', error);
        }
      }
      if (!desktopSupported) {
        console.warn('[dsh-quick-restart] quick restart is only available in the Windows DSH desktop app; the shipped account menu stays in place.');
        return;
      }

      function QuickRestartLauncher(props) {
        const { wide = true, settingsOpen = false, settingsShortcut, openSettings } = props;
        const dictionary = () => (String(document.documentElement.lang || '').toLowerCase().startsWith('zh') ? ZH : EN);
        const translate = (key) => (typeof props.t === 'function' ? props.t(key) : (dictionary()[key] ?? key));
        const [open, setOpen] = useState(false);
        const [account, setAccount] = useState({ loading: true, signedIn: false, name: null, avatarUrl: null });
        const [avatarFailed, setAvatarFailed] = useState(false);
        const [dialog, setDialog] = useState(null);
        const [busy, setBusy] = useState(false);
        const [restartLog, setRestartLog] = useState(null);
        const [menuPos, setMenuPos] = useState(null);
        const triggerRef = useRef(null);
        const menuRef = useRef(null);
        const firstItemRef = useRef(null);

        const loadAccount = () => {
          requestJson('account')
            .then((data) => {
              setAccount({ loading: false, signedIn: Boolean(data.signedIn), name: data.name ?? null, avatarUrl: data.avatarUrl ?? null });
              setAvatarFailed(false);
            })
            .catch(() => {
              setAccount({ loading: false, signedIn: false, name: null, avatarUrl: null });
            });
        };

        useEffect(() => {
          loadAccount();
        }, []);

        useEffect(() => {
          if (open) loadAccount();
        }, [open]);

        useEffect(() => {
          if (settingsOpen) setOpen(false);
        }, [settingsOpen]);

        useEffect(() => {
          if (!open) {
            setMenuPos(null);
            return undefined;
          }
          const rect = triggerRef.current?.getBoundingClientRect();
          if (rect) {
            const estimatedWidth = 200;
            const left = Math.min(Math.max(rect.left, 12), Math.max(12, window.innerWidth - estimatedWidth - 12));
            const bottom = Math.max(12, window.innerHeight - rect.top + 4);
            setMenuPos({ left, bottom });
          }
          const close = () => setOpen(false);
          const onPointerDown = (event) => {
            const target = event.target;
            if (menuRef.current?.contains(target)) return;
            if (triggerRef.current?.contains(target)) return;
            setOpen(false);
          };
          document.addEventListener('pointerdown', onPointerDown, true);
          window.addEventListener('resize', close);
          window.addEventListener('scroll', close, true);
          return () => {
            document.removeEventListener('pointerdown', onPointerDown, true);
            window.removeEventListener('resize', close);
            window.removeEventListener('scroll', close, true);
          };
        }, [open]);

        useEffect(() => {
          if (open) firstItemRef.current?.focus();
        }, [open]);

        useEffect(() => {
          if (!dialog) return undefined;
          const onKeyDown = (event) => {
            if (event.key === 'Escape') setDialog(null);
          };
          document.addEventListener('keydown', onKeyDown);
          return () => document.removeEventListener('keydown', onKeyDown);
        }, [dialog]);

        useEffect(() => {
          if (dialog?.kind !== 'restarting') return undefined;
          const timer = setTimeout(() => {
            setDialog({
              kind: 'error',
              message: translate('restartTimeout') + (restartLog ? ' — ' + restartLog : ''),
            });
          }, 12000);
          return () => clearTimeout(timer);
        }, [dialog, restartLog]);

        const openContact = () => {
          const config = globalThis.__DSH_CONTACT_CONFIG__ ?? {};
          const base = typeof config.contactFormUrl === 'string' && config.contactFormUrl
            ? config.contactFormUrl
            : 'https://trtgsjkv6r.feishu.cn/share/base/form/shrcnlCoGElW7MQznGy9r3YYXcg';
          try {
            window.open(new URL(base).toString(), '_blank', 'noopener,noreferrer');
          } catch {
            window.open(base, '_blank', 'noopener,noreferrer');
          }
        };

        const select = (id) => {
          setOpen(false);
          if (id === 'settings') {
            openSettings?.();
            triggerRef.current?.focus?.();
            return;
          }
          if (id === 'contact') {
            openContact();
            return;
          }
          if (id === 'restart') {
            setDialog({ kind: 'restart' });
            return;
          }
          if (id === 'signout') {
            setDialog({ kind: 'signout' });
            return;
          }
          if (id === 'signin') {
            openSettings?.();
          }
        };

        const confirmRestart = async () => {
          setBusy(true);
          try {
            const data = await requestJson('restart');
            if (data && data.status === 'restarting') {
              setRestartLog(data.logPath ?? null);
              setDialog({ kind: 'restarting' });
            } else {
              const reason = data?.reason || data?.status || 'unknown error';
              setDialog({
                kind: 'error',
                message: translate('restartFailed') + ': ' + reason + (data?.logPath ? ' — ' + data.logPath : ''),
              });
            }
          } catch (error) {
            setDialog({ kind: 'error', message: translate('restartFailed') + ': ' + (error?.message ?? String(error)) });
          }
          setBusy(false);
        };

        const confirmSignOut = async () => {
          setBusy(true);
          try {
            await requestJson('signout');
            setDialog(null);
            loadAccount();
          } catch (error) {
            setDialog({ kind: 'error', message: translate('signOutFailed') + ': ' + (error?.message ?? String(error)) });
          }
          setBusy(false);
        };

        const onMenuKeyDown = (event) => {
          if (event.key === 'Escape') {
            event.preventDefault();
            setOpen(false);
            triggerRef.current?.focus?.();
            return;
          }
          if (event.key === 'Tab') {
            setOpen(false);
            return;
          }
          if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp' && event.key !== 'Home' && event.key !== 'End') return;
          event.preventDefault();
          const buttons = Array.from(menuRef.current?.querySelectorAll('[role="menuitem"]:not(:disabled)') ?? []);
          if (buttons.length === 0) return;
          const current = buttons.indexOf(document.activeElement);
          let next;
          if (event.key === 'Home') next = 0;
          else if (event.key === 'End') next = buttons.length - 1;
          else if (event.key === 'ArrowDown') next = current < 0 ? 0 : (current + 1) % buttons.length;
          else next = current < 0 ? buttons.length - 1 : (current - 1 + buttons.length) % buttons.length;
          buttons[next]?.focus();
        };

        const items = [
          { id: 'settings', label: translate('settings'), Icon: IconGear, shortcut: settingsShortcut },
          { id: 'contact', label: translate('contactUs'), Icon: IconSend },
          { id: 'restart', label: translate('quickRestart'), Icon: IconRefresh },
          account.signedIn
            ? { id: 'signout', label: translate('signOut'), Icon: IconLogout }
            : { id: 'signin', label: translate('signIn'), Icon: IconUser },
        ];

        const trigger = h('div', { className: 'qr-anchor' },
          h('button', {
            ref: triggerRef,
            type: 'button',
            className: 'qr-trigger',
            'data-collapsed': !wide,
            'data-signed-out': !account.signedIn,
            'aria-label': translate('menu'),
            'aria-haspopup': 'menu',
            'aria-expanded': open,
            title: account.signedIn && account.name ? account.name : translate('menu'),
            onClick: () => setOpen((value) => !value),
          }, [
            account.signedIn
              ? h('span', {
                  key: 'avatar',
                  className: 'qr-avatar',
                  'data-avatar-status': account.avatarUrl && !avatarFailed ? 'ready' : 'fallback',
                }, account.avatarUrl && !avatarFailed
                  ? h('img', {
                      className: 'qr-avatarImage',
                      src: account.avatarUrl,
                      alt: '',
                      referrerPolicy: 'no-referrer',
                      onError: () => setAvatarFailed(true),
                    })
                  : h(IconUser))
              : h(IconEllipsis, { key: 'fallback', size: 14 }),
            wide ? h('span', { key: 'label', className: 'qr-label' }, account.signedIn ? (account.name || translate('signedIn')) : translate('more')) : null,
          ]));

        let menuNode = null;
        if (open && menuPos) {
          const menu = h('div', {
            ref: menuRef,
            role: 'menu',
            className: 'qr-menu',
            style: { left: menuPos.left + 'px', bottom: menuPos.bottom + 'px' },
            onClick: (event) => event.stopPropagation(),
            onKeyDown: onMenuKeyDown,
          }, [
            h('div', { key: 'material', className: 'qr-menuMaterial', 'aria-hidden': 'true' }),
            h('div', { key: 'viewport', className: 'qr-viewport', role: 'presentation' },
              items.map((item, index) => h('div', { key: item.id, className: 'qr-itemWrap' },
                h('button', {
                  ref: index === 0 ? firstItemRef : null,
                  type: 'button',
                  role: 'menuitem',
                  className: 'qr-item',
                  'aria-keyshortcuts': item.shortcut?.aria,
                  onClick: () => select(item.id),
                }, [
                  h('span', { key: 'icon', className: 'qr-itemIcon' }, h(item.Icon)),
                  h('span', { key: 'label', className: 'qr-itemLabel' }, item.label),
                  item.shortcut
                    ? h('span', { key: 'shortcut', className: 'qr-shortcut', 'aria-hidden': 'true' }, renderShortcutKeys(item.shortcut.keys ?? []))
                    : null,
                ])))),
          ]);
          menuNode = createPortal ? createPortal(menu, document.body) : menu;
        }

        let dialogNode = null;
        if (dialog) {
          const restarting = dialog.kind === 'restarting';
          const title = dialog.kind === 'restart' ? translate('restartTitle')
            : restarting ? translate('restartingTitle')
              : dialog.kind === 'signout' ? translate('signOutTitle')
                : translate('errorTitle');
          const bodyText = dialog.kind === 'restart' ? translate('restartBody')
            : restarting ? translate('restartingBody')
              : dialog.kind === 'signout' ? translate('signOutBody')
                : dialog.message;
          const buttons = [];
          if (restarting) {
            /* no buttons */
          } else if (dialog.kind === 'restart') {
            buttons.push(h('button', { key: 'cancel', type: 'button', className: 'qr-btn', autoFocus: busy, onClick: () => setDialog(null) }, translate('cancel')));
            buttons.push(h('button', { key: 'ok', type: 'button', className: 'qr-btn qr-btnPrimary', disabled: busy, onClick: confirmRestart }, translate('restartAction')));
          } else if (dialog.kind === 'signout') {
            buttons.push(h('button', { key: 'cancel', type: 'button', className: 'qr-btn', autoFocus: busy, onClick: () => setDialog(null) }, translate('cancel')));
            buttons.push(h('button', { key: 'ok', type: 'button', className: 'qr-btn qr-btnPrimary', disabled: busy, onClick: confirmSignOut }, translate('signOutAction')));
          } else {
            buttons.push(h('button', { key: 'ok', type: 'button', className: 'qr-btn qr-btnPrimary', autoFocus: busy, onClick: () => setDialog(null) }, translate('ok')));
          }
          const panel = h('div', { className: 'qr-overlay', role: 'presentation' },
            h('div', { className: 'qr-dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
              h('h2', { className: 'qr-dialogTitle' }, title),
              h('p', { className: 'qr-dialogBody' },
                restarting ? h('span', { className: 'qr-spinner', 'aria-hidden': 'true' }) : null,
                bodyText),
              buttons.length > 0 ? h('div', { className: 'qr-dialogFooter' }, buttons) : null));
          dialogNode = createPortal ? createPortal(panel, document.body) : panel;
        }

        return h('div', { className: 'qr-root' }, [trigger, menuNode, dialogNode]);
      }

      ctx.slots.inject('settings.launcher', () => {
        try {
          return ctx.slots.register({
            name: 'settings.launcher',
            priority: -10,
            locale: 'dshQuickRestart',
          }, QuickRestartLauncher);
        } catch (error) {
          console.warn('[dsh-quick-restart] another account-menu launcher is already registered at this priority; keeping it', error);
          return () => {};
        }
      });
    }

    return {
      inject: ['slots', 'locale'],
      apply,
    };
  },
});
