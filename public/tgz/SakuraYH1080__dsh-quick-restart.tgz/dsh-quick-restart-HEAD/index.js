import { spawn } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';

const PREFIX = '/dsh-quick-restart';
const RESTART_STATUS = 'restarting';
const RESTART_LOG = path.join(os.tmpdir(), 'dsh-quick-restart.log');

function clientMetadata(body) {
  const version = process.env.DSH_CLIENT_VERSION || (typeof body?.version === 'string' && body.version.trim() ? body.version.trim() : '');
  const locale = typeof body?.locale === 'string' && body.locale ? body.locale : 'en';
  const timezoneOffsetSeconds = Number.isFinite(body?.timezoneOffsetSeconds) ? body.timezoneOffsetSeconds : 0;
  return { version: version || 'unknown', locale, timezoneOffsetSeconds };
}

/** Whether the running Host is inside the packaged DSH desktop app on Windows. */
export function desktopRestartInfo() {
  const execPath = process.execPath;
  const base = path.basename(execPath);
  const platform = process.platform;
  const win32 = platform === 'win32';
  const exeMatch = /^DeepSeek Harness(\.exe)?$/i.test(base);
  const electronNode = Boolean(process.versions?.electron) || process.env.ELECTRON_RUN_AS_NODE === '1';
  const hasParent = typeof process.ppid === 'number' && process.ppid > 0;
  const supported = win32 && exeMatch && electronNode && hasParent;
  return {
    supported,
    platform,
    execPath,
    execBase: base,
    electronNode,
    electronVersion: process.versions?.electron ?? null,
    hasParent,
    mainPid: hasParent ? process.ppid : 0,
    hostPid: process.pid,
    logPath: RESTART_LOG,
  };
}

function psQuote(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

export function buildHelperScript({ mainPid, hostPid, exe, workDir, port, logPath = RESTART_LOG, launchArgs = [] }) {
  const argumentList = launchArgs.length > 0
    ? ' -ArgumentList ' + launchArgs.map((value) => psQuote(value)).join(',')
    : '';
  return [
    '$ErrorActionPreference = \'SilentlyContinue\'',
    `$log = ${psQuote(logPath)}`,
    'function Log($message) { try { Add-Content -LiteralPath $log -Value ((Get-Date).ToString(\'o\') + " " + $message) } catch { } }',
    'Log "helper start"',
    `$mainPid = ${Number(mainPid)}`,
    `$hostPid = ${Number(hostPid)}`,
    `$exe = ${psQuote(exe)}`,
    `$workDir = ${psQuote(workDir)}`,
    `$port = ${Number(port) || 0}`,
    'Start-Sleep -Milliseconds 900',
    'Log "killing Electron main"',
    `if ($mainPid -gt 0) { & taskkill.exe /F /T /PID $mainPid 2>&1 | Out-Null }`,
    'Start-Sleep -Milliseconds 300',
    'Log "killing Host process"',
    `if ($hostPid -gt 0 -and $hostPid -ne $mainPid) { & taskkill.exe /F /PID $hostPid 2>&1 | Out-Null }`,
    '$deadline = (Get-Date).AddSeconds(12)',
    'while ((Get-Date) -lt $deadline) {',
    '  $alive = @(Get-Process -Id $mainPid,$hostPid -ErrorAction SilentlyContinue)',
    '  if ($alive.Count -eq 0) { break }',
    '  Log ("still alive: " + (($alive | ForEach-Object { $_.Id }) -join \',\'))',
    '  Start-Sleep -Milliseconds 200',
    '}',
    '$alive = @(Get-Process -Id $mainPid,$hostPid -ErrorAction SilentlyContinue)',
    'foreach ($process in $alive) { Log ("force stop " + $process.Id); Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue }',
    'if ($port -gt 0) {',
    '  $portDeadline = (Get-Date).AddSeconds(8)',
    '  while ((Get-Date) -lt $portDeadline) {',
    '    $listeners = @(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)',
    '    if ($listeners.Count -eq 0) { break }',
    '    foreach ($listener in $listeners) { if ($listener.OwningProcess -gt 0) { Log ("killing port listener " + $listener.OwningProcess); & taskkill.exe /F /PID $listener.OwningProcess 2>&1 | Out-Null } }',
    '    Start-Sleep -Milliseconds 200',
    '  }',
    '}',
    '$stillAlive = @(Get-Process -Id $mainPid,$hostPid -ErrorAction SilentlyContinue)',
    'if ($stillAlive.Count -gt 0) {',
    '  Log "abort relaunch: DSH processes are still alive"',
    '  exit 1',
    '}',
    'if (Test-Path -LiteralPath $exe) {',
    '  Start-Sleep -Milliseconds 200',
    '  Log ("relaunching " + $exe)',
    '  Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue',
    `  Start-Process -FilePath $exe -WorkingDirectory $workDir${argumentList}`,
    '} else {',
    '  Log ("abort relaunch: executable not found: " + $exe)',
    '  exit 1',
    '}',
  ].join('\n');
}

/**
 * Start the detached restart helper. The outer PowerShell starts a second hidden PowerShell and
 * exits immediately, so the actual helper is not part of the DSH process tree when we kill it.
 */
export function spawnHelper(script) {
  const inner = Buffer.from(script, 'utf16le').toString('base64');
  const outer = [
    `$inner = ${psQuote(inner)}`,
    "Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList '-NoProfile','-NonInteractive','-EncodedCommand',$inner",
  ].join('\n');
  return new Promise((resolve) => {
    let settled = false;
    const settle = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    let child;
    try {
      child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', Buffer.from(outer, 'utf16le').toString('base64')], {
        stdio: 'ignore',
        windowsHide: true,
      });
    } catch (error) {
      settle({ helperPid: null, error: error instanceof Error ? error.message : String(error) });
      return;
    }
    child.once('error', (error) => settle({ helperPid: null, error: error instanceof Error ? error.message : String(error) }));
    child.once('spawn', () => settle({ helperPid: child.pid ?? null }));
    const timer = setTimeout(() => settle({ helperPid: child.pid ?? null }), 1000);
    timer.unref?.();
    child.unref();
  });
}

async function accountSnapshot(ctx, body) {
  const account = ctx.get('deepseekAccount');
  if (!account) return { signedIn: false, reason: 'no-account-service' };
  const client = clientMetadata(body);
  const state = await account.getState();
  const signedIn = Boolean(state && state.status === 'credential-stored');
  let profile = null;
  if (signedIn) {
    const outcome = await account.getProfile(client).catch(() => null);
    if (outcome && outcome.status === 'ready' && outcome.value) profile = outcome.value;
  }
  return {
    signedIn,
    name: profile?.name ?? profile?.contact ?? null,
    avatarUrl: profile?.avatarUrl ?? null,
  };
}

async function signOutAccount(ctx, body) {
  const account = ctx.get('deepseekAccount');
  if (!account) return { ok: false, error: 'account service unavailable' };
  try {
    await account.signOut(clientMetadata(body));
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
  return { ok: true };
}

async function readJsonBody(req) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > 65536) throw new Error('request body too large');
    chunks.push(chunk);
  }
  if (total === 0) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new Error('invalid JSON body');
  }
}

function sendJson(res, status, body) {
  if (res.headersSent) return;
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  });
  res.end(JSON.stringify(body));
}

async function restart(ctx) {
  const webServer = ctx.get('webServer');
  const port = webServer && typeof webServer.port === 'number' ? webServer.port : 0;
  const info = desktopRestartInfo();
  if (!info.supported) {
    return {
      status: 'unsupported',
      reason: `quick restart needs the DSH desktop app on Windows (platform=${info.platform}, exec=${info.execBase}, electronNode=${info.electronNode})`,
      ...info,
    };
  }
  const script = buildHelperScript({
    mainPid: info.mainPid,
    hostPid: info.hostPid,
    exe: info.execPath,
    workDir: path.dirname(info.execPath),
    port,
    logPath: info.logPath,
  });
  const spawned = await spawnHelper(script);
  if (spawned.error) {
    return { status: 'failed', reason: spawned.error, ...info };
  }
  return { status: RESTART_STATUS, helperPid: spawned.helperPid, ...info };
}

function createHandler(ctx) {
  return async function handler(req, res) {
    let rejection = 503;
    try {
      const connection = ctx.get('connection');
      const value = connection && typeof connection.requestRejection === 'function' ? connection.requestRejection(req) : undefined;
      if (typeof value === 'number') rejection = value;
      else if (value === undefined && connection) rejection = 0;
    } catch {
      rejection = 503;
    }
    if (rejection !== 0) {
      sendJson(res, rejection, { error: 'unauthorized' });
      return;
    }
    if (req.method !== 'POST') {
      sendJson(res, 405, { error: 'method not allowed' });
      return;
    }
    const pathname = (req.url ?? '').split('?')[0];
    const action = pathname.slice(PREFIX.length);
    try {
      if (action === '/account') {
        sendJson(res, 200, await accountSnapshot(ctx, await readJsonBody(req)));
        return;
      }
      if (action === '/signout') {
        const result = await signOutAccount(ctx, await readJsonBody(req));
        sendJson(res, result.ok ? 200 : 500, result);
        return;
      }
      if (action === '/status') {
        sendJson(res, 200, desktopRestartInfo());
        return;
      }
      if (action === '/restart') {
        sendJson(res, 200, await restart(ctx));
        return;
      }
      sendJson(res, 404, { error: 'not found' });
    } catch (error) {
      sendJson(res, 500, { error: error instanceof Error ? error.message : String(error) });
    }
  };
}

export const inject = ['webServer'];

export function apply(ctx) {
  ctx.effect(() => {
    try {
      return ctx.webServer.register({ kind: 'prefix', path: PREFIX, handler: createHandler(ctx) });
    } catch (error) {
      console.warn('[dsh-quick-restart] route already registered; keeping the existing handler', error);
      return () => {};
    }
  }, 'dsh-quick-restart: routes');
}
