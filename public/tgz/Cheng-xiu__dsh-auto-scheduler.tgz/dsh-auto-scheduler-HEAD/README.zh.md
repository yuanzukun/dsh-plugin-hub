中文 | [English](README.md)

# dsh-auto-scheduler

DeepSeek Harness（DSH）定时自动工作插件：在侧边栏填写工作目标与工作时间，到点 DSH 自动新建会话并开始工作，到停止时间自动中断 agent 并停止会话（会话保留可回看）。

## 功能

- **Host 端常驻调度**：定时器跑在 dsh web 宿主进程内，网页关掉、手机锁屏也准点触发（但 dsh web 进程本身必须运行；错过即跳过，不做补跑）。
- **自动开始 / 自动停止**：到开始时间自动新建 Web GUI 会话并发送任务；到停止时间自动中断当前回合并停止会话。
- **两种模式**：
  - **默认模式**：允许 agent 向你提问，一切保留默认设置。
  - **静默模式**：不向用户提问（禁用 ask_user_question 工具 + 静默 persona），danger-full-access 全权限，任务完成前不停止工作（到停止时间仍会被外部停止）。
- **ds 谷峰时段预设**：北京时间 12:00-14:00、18:00-次日 9:00（UTC+8）一键快速填充开始/停止时间。
- **时区自动换算**：面板按你系统的本机时区显示/输入，保存时自动转为 UTC 存储；谷峰预设会按本机时区换算显示。
- **重复**：仅一次 / 每天。

## 安装

### 手动安装（推荐）

```sh
dsh plugin --profile web add github:Cheng-xiu/dsh-auto-scheduler#v0.1.4
```

只需要这一条命令；`dsh plugin add` 会自动把插件注册进 bundle。

### 一键安装脚本（Windows）

下载安装脚本并运行（或克隆仓库后运行 `install.cmd`）：

```bat
curl -o install.cmd https://raw.githubusercontent.com/Cheng-xiu/dsh-auto-scheduler/v0.1.4/install.cmd
install.cmd            :: 可选：install.cmd <profile>，默认 profile 为 web
```

### 一键安装脚本（macOS / Linux）

```sh
curl -o install.sh https://raw.githubusercontent.com/Cheng-xiu/dsh-auto-scheduler/v0.1.4/install.sh
chmod +x install.sh && ./install.sh   # 可选：./install.sh <profile>
```

然后**重启 dsh web**。重启后侧边栏出现「自动工作」入口。

## 使用

1. 打开侧边栏「自动工作」面板。
2. 填写工作目标、模式（默认/静默）、开始时间、停止时间、重复方式；或点击谷峰时段预设快速填充。
3. 保存。到点后 dsh 自动新建会话并发送任务，面板显示运行状态与下次执行倒计时。
4. 「立即执行」可随时手动触发（停止时间 = 现在 + 原时长）。

## 数据与安全

- 任务数据保存在 host 端：`DSH_HOME/dsh-auto-scheduler.json`（默认 `~/.dsh/dsh-auto-scheduler.json`），浏览器关掉不丢失。
- 面板 API 仅允许 loopback（本机）或 `--trusted-host` 放行的来源访问，陌生来源一律 403。
- **静默模式 = 无人值守全权限执行，风险高**，请只在信任的任务上使用。

## 工作原理

- 宿主进程每 20 秒检查一次调度；到期后走与 Web GUI 完全相同的会话路径（`apiProxy.sessions.create/prompt/cancel`）。
- 静默模式使用插件自带的 agent preset `dsh-auto-scheduler-silent`（标准预设的复刻：静默 persona + 禁用提问工具），启动时同步到 `~/.dsh/.agent-presets/`。
- 会话标题自动命名为「[自动] 目标前缀」，方便在会话列表中找到。

## 常见问题

- **重启后侧边栏没有入口**：执行 `dsh --profile web --dump-config | findstr auto-scheduler`；若没有该行说明安装未生效，重新执行安装命令。客户端面板在启动时注入，安装/升级后必须重启。
- **pnpm store / allowBuilds 报错**：本插件零依赖、无构建脚本；按 `dsh plugin add` 打印的 pnpm 提示操作（例如把打印的 key 加进 profile 的 `pnpm-workspace.yaml` 的 `allowBuilds`）后重试。
- **任务没触发**：到点时 dsh web 进程必须正在运行；错过的窗口按设计直接跳过。

## 许可证

MIT
