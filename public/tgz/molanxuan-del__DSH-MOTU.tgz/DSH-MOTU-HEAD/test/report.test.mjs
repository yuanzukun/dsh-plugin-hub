/**
 * 任务报告（report）渲染器。
 *
 * 对话里是一张摘要卡；「下载」导出的是**一份自包含的 HTML 报告网页**。
 *
 * 报告按需生成：先给结论与必要证据，细节按需展开，避免每轮重复总结。
 * 这里钉三件事：
 *   1. **自包含** —— 页面不许引用任何外部资源、不许发请求（离线可读）；
 *   2. **确定性** —— 同一份 spec 必须得到同一份字节（内容全部来自 spec，页面里没有时间戳）；
 *   3. **不猜** —— 规格写错就报错，缺结论就拒绝，不生成一份"看着像"的空报告。
 */

import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { it } from 'node:test'
import { JSDOM } from 'jsdom'

import { setupDom } from '../scripts/dom-env.mjs'
import { renderers } from '../lib/renderers/manifest.js'

const spec = renderers.find((item) => item.id === 'report')

function loadClient(t) {
  const dom = setupDom({ scripts: true })
  dom.window.document.documentElement.dataset.theme = 'light'
  let client
  dom.window.__ModuleLoader__ = { load({ factory }) { client = factory(() => { throw new Error('no react') }) } }
  dom.window.eval(readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8'))
  t.after(() => dom.window.close())
  return { dom, client }
}

const env = () => ({
  loadEngine: async () => ({}),
  container: () => setupDom({ scripts: true }).window.document.createElement('div'),
  clearContainer: () => {},
  theme: 'light',
  presentation: { fontFamily: 'system-ui, sans-serif', fontSize: 13 },
  settings: {},
  behaviour: {},
  limits: spec.limits,
  nextId: () => 'report-test',
})

it('场景规范中的每份报告示例都能解析、渲染并导出完整解释', async t => {
  const { dom, client } = loadClient(t)
  const guide = readFileSync(new URL('../skill/references/report.md', import.meta.url), 'utf8')
  const examples = [...guide.matchAll(/^```report\r?\n([\s\S]*?)^```/gm)]
  assert.ok(examples.length >= 3, '应包含基本示例以及因果排错、方案比较示例')
  for (const [, source] of examples) {
    const spec = client.internals.reportSpecOf(source)
    const drawn = await client.internals.ADAPTERS.report.render(source, { ...env(), measure: false })
    const svg = new dom.window.DOMParser().parseFromString(drawn.markup, 'image/svg+xml')
    assert.equal(svg.querySelector('parsererror'), null, spec.title)
    const document = new dom.window.DOMParser().parseFromString(drawn.snapshot().data, 'text/html')
    assert.ok(document.body.textContent.includes(spec.verdict), '导出页保留完整结论')
    for (const section of spec.sections) {
      for (const explanation of section.items) assert.ok(document.body.textContent.includes(explanation), '必要解释不能在导出中丢失')
      if (section.flow) assert.ok(document.querySelector('section .flow svg'), '因果链实际画成图')
      if (section.table) assert.ok(document.querySelector('section table'), '取舍实际展示为表格')
    }
  }
})

const SAMPLE = {
  title: '修好了调色板串色',
  round: '第 18 轮 · 2026-10-19',
  status: 'done',
  verdict: '定位并修掉同名类互相覆盖的根因。',
  badges: [
    { tone: 'done', text: '已完成' },
    { tone: 'info', text: '仅本机验证' },
  ],
  facts: ['类名是文档级的', '改成内容哈希前缀'],
  meta: { 基线: '0.17.0', 验证: '243 单测' },
  notice: { tone: 'warn', text: '未测长对话。' },
  notes: ['前缀来自内容哈希，不破坏确定性。'],
  sections: [
    { title: '用户能感知到的变化', items: ['两张异色图不再互相污染'] },
    { title: '改了什么', table: { head: ['文件', '改动'], rows: [['lib/client.js', '类名加前缀']] } },
    { title: '验证与未测', items: ['npm test 通过'], details: { summary: '未测范围', items: ['长对话'] } },
  ],
  sources: [{ label: '改动', text: 'lib/client.js' }],
}

it('报告网页包含结论与分节，且下载的是 HTML', async (t) => {
  const { client } = loadClient(t)
  const drawn = await client.internals.ADAPTERS.report.render(JSON.stringify(SAMPLE), env())
  const snapshot = drawn.snapshot()
  assert.equal(snapshot.extension, 'html')
  assert.equal(snapshot.mimeType, 'text/html')
  assert.match(snapshot.data, /^<!doctype html>/i)
  assert.match(snapshot.data, /修好了调色板串色/)
  assert.match(snapshot.data, /定位并修掉同名类互相覆盖的根因/)
  assert.match(snapshot.data, /用户能感知到的变化/)
  assert.match(snapshot.data, /已完成/)
  assert.match(snapshot.data, /badge done/, '显式徽章要按 tone 上色')
  assert.match(snapshot.data, /<table>/, '改动表要真的渲染成表格')
  assert.match(snapshot.data, /未测范围/, '未验证范围要进折叠块')
  assert.match(snapshot.data, /来源/, '来源要单独成节')
})

it('页面自包含：不引用外部资源，也不发请求', async (t) => {
  const { client } = loadClient(t)
  const drawn = await client.internals.ADAPTERS.report.render(JSON.stringify(SAMPLE), env())
  const html = drawn.snapshot().data
  for (const banned of ['<script src', '<link ', '<img', 'http://', 'https://', '@import', 'fetch(']) {
    assert.equal(html.includes(banned), false, `页面不该出现 ${banned}`)
  }
  // 唯一允许的脚本是切换深浅色那段内联逻辑
  assert.match(html, /<script>[\s\S]*<\/script>/, '应当有内联的深浅色脚本')
  assert.match(html, /http-equiv="Content-Security-Policy"/, '下载页自己也要带 CSP，不能只靠 ASCII 路由')
  assert.match(html, /connect-src 'none'/, '独立报告的 CSP 应禁止网络请求')
})

it('同一份 spec 得到同一份字节（页面里没有时间戳）', async (t) => {
  const { client } = loadClient(t)
  const once = (await client.internals.ADAPTERS.report.render(JSON.stringify(SAMPLE), env())).snapshot().data
  const twice = (await client.internals.ADAPTERS.report.render(JSON.stringify(SAMPLE), env())).snapshot().data
  assert.equal(once, twice)
})

it('摘要卡是合法 SVG，且提示查看 / 下载完整网页', async (t) => {
  const { dom, client } = loadClient(t)
  const drawn = await client.internals.ADAPTERS.report.render(JSON.stringify(SAMPLE), env())
  const parsed = new dom.window.DOMParser().parseFromString(drawn.markup, 'image/svg+xml')
  assert.equal(parsed.querySelector('parsererror'), null, '摘要卡必须是合法 XML')
  assert.match(drawn.markup, /查看/)
  assert.match(drawn.markup, /下载/)
  assert.equal([...drawn.markup.matchAll(/\s(fill|stroke)=""/g)].length, 0, '不能有空色')
})

it('窄屏摘要按容器排版，长内容明确省略但完整报告不丢信息', async (t) => {
  const { dom, client } = loadClient(t)
  const target = dom.window.document.createElement('div')
  target.getBoundingClientRect = () => ({ width: 320, height: 0, top: 0, left: 0, right: 320, bottom: 0 })
  const source = {
    title: '长标题测试'.repeat(20),
    status: 'partial',
    verdict: '这是一段需要在全文中完整保留的交付结论。'.repeat(20),
    facts: Array.from({ length: 5 }, (_, index) => `证据${index + 1}：${'详细验证说明。'.repeat(15)}`),
    sections: [{ title: '相关流程', flow: { nodes: [{ id: 'a', label: '输入' }, { id: 'b', label: '结果' }] } }],
  }
  const drawn = await client.internals.ADAPTERS.report.render(JSON.stringify(source), { ...env(), target, measure: false })
  const svg = new dom.window.DOMParser().parseFromString(drawn.markup, 'image/svg+xml')
  assert.equal(svg.querySelector('parsererror'), null)
  const viewBox = svg.documentElement.getAttribute('viewBox').split(/\s+/).map(Number)
  assert.equal(viewBox[2], 320, '卡片应在当前宽度排版，不能把680宽的正文整体缩小')
  const titles = [...svg.querySelectorAll('text[font-size="17"]')]
  assert.equal(titles.length, 2, '长标题要换行并限制摘要高度')
  assert.ok(Number(titles[1].getAttribute('y')) - Number(titles[0].getAttribute('y')) >= 17, '标题行不能重叠')
  assert.match(titles.at(-1).textContent, /…$/)
  const bodyText = [...svg.querySelectorAll('text[font-size="14"]')].map(node => node.textContent)
  assert.ok(bodyText.length > 0, '窄屏正文仍用可读字号')
  assert.ok(bodyText.some(line => line.endsWith('…')), '正文截断要可见')
  const visibleText = [...svg.querySelectorAll('text')].map(node => node.textContent).join('')
  assert.match(visibleText, /摘要有省略/)
  assert.doesNotMatch(visibleText, /证据5/)
  const hints = [...svg.querySelectorAll('text[font-size="12"]')]
  assert.ok(hints.every(node => Number(node.getAttribute('y')) < viewBox[3]), '底部提示不能被画布裁掉')
  target.getBoundingClientRect = () => ({ width: 280 })
  const narrow = await client.internals.ADAPTERS.report.render(JSON.stringify(source), { ...env(), target, measure: false })
  const narrowSvg = new dom.window.DOMParser().parseFromString(narrow.markup, 'image/svg+xml')
  assert.ok(narrowSvg.querySelectorAll('text[font-size="12"]').length > 1, '不足一行的全文入口提示应换行')

  const full = new dom.window.DOMParser().parseFromString(drawn.snapshot().data, 'text/html')
  assert.equal(full.querySelector('h1').textContent, source.title)
  assert.equal(full.querySelector('.verdict').textContent, source.verdict)
  assert.deepEqual([...full.querySelectorAll('.facts li')].map(node => node.textContent), source.facts)
})

it('窄屏长轮次与徽章换行，正文不会压在徽章上', async (t) => {
  const { dom, client } = loadClient(t)
  const target = dom.window.document.createElement('div')
  target.getBoundingClientRect = () => ({ width: 320 })
  const source = {
    title: '验收结果', status: 'partial', verdict: '核心功能通过，宿主验收待完成。',
    round: '项目验证与验收记录'.repeat(10),
    badges: [
      { tone: 'partial', text: '仅本地测试通过尚待宿主验收' },
      { tone: 'info', text: '需要保留原始数据以备复查' },
    ],
  }
  const drawn = await client.internals.ADAPTERS.report.render(JSON.stringify(source), { ...env(), target, measure: false })
  const svg = new dom.window.DOMParser().parseFromString(drawn.markup, 'image/svg+xml')
  const round = [...svg.querySelectorAll('text[font-size="12"]')].filter(node => node.textContent.includes('项目验证') || node.textContent.endsWith('…'))
  assert.equal(round.length, 2)
  assert.match(round.at(-1).textContent, /…$/)
  const badges = [...svg.querySelectorAll('rect[rx="11"]')]
  assert.equal(badges.length, 2)
  assert.ok(badges.every(node => Number(node.getAttribute('x')) + Number(node.getAttribute('width')) <= 320), '徽章不能超出窄屏画布')
  assert.ok(Number(badges[1].getAttribute('y')) >= Number(badges[0].getAttribute('y')) + Number(badges[0].getAttribute('height')), '徽章换行后互不重叠')
  const verdictY = Number(svg.querySelector('text[font-size="14"]').getAttribute('y'))
  assert.ok(verdictY > Number(badges[1].getAttribute('y')) + Number(badges[1].getAttribute('height')), '正文位于徽章之后')
})

it('独立报告默认折叠，支持全部展开收起并在打印后恢复阅读状态', async (t) => {
  const { client } = loadClient(t)
  const source = {
    ...SAMPLE,
    sections: [
      { title: '实现细节', details: { summary: '查看实现', items: ['实现证据'] } },
      { title: '验证细节', details: { summary: '查看验证', items: ['验证证据'] } },
    ],
  }
  const drawn = await client.internals.ADAPTERS.report.render(JSON.stringify(source), { ...env(), measure: false })
  const page = new JSDOM(drawn.snapshot().data, { runScripts: 'dangerously' })
  t.after(() => page.window.close())
  const { document, Event } = page.window
  const details = [...document.querySelectorAll('details')]
  const expand = document.getElementById('expand')
  assert.equal(details.length, 2)
  assert.deepEqual(details.map(node => node.open), [false, false])
  assert.equal(expand.textContent, '全部展开')
  expand.click()
  assert.deepEqual(details.map(node => node.open), [true, true])
  assert.equal(expand.textContent, '全部收起')
  expand.click()
  assert.deepEqual(details.map(node => node.open), [false, false])
  assert.equal(expand.textContent, '全部展开')

  details[0].querySelector('summary').click()
  assert.deepEqual(details.map(node => node.open), [true, false], '用户可只展开需要的细节')
  details[1].querySelector('summary').click()
  await new Promise(resolve => page.window.setTimeout(resolve, 0))
  assert.equal(expand.textContent, '全部收起', '单独展开所有细节后，全局按钮应同步')
  details[1].querySelector('summary').click()
  await new Promise(resolve => page.window.setTimeout(resolve, 0))
  assert.equal(expand.textContent, '全部展开', '单独收起一项后，全局按钮应同步')
  let printed = false
  page.window.print = () => {
    page.window.dispatchEvent(new Event('beforeprint'))
    page.window.dispatchEvent(new Event('beforeprint'))
    assert.deepEqual(details.map(node => node.open), [true, true], '打印不能漏掉折叠内容')
    assert.equal(details[1].querySelector('li').textContent, '验证证据')
    printed = true
    page.window.dispatchEvent(new Event('afterprint'))
  }
  document.getElementById('print').click()
  assert.equal(printed, true, '打印按钮应调用实际打印入口')
  assert.deepEqual(details.map(node => node.open), [true, false], '打印后恢复原先的混合展开状态')
  details[0].open = false
  page.window.dispatchEvent(new Event('afterprint'))
  assert.deepEqual(details.map(node => node.open), [false, false], '重复打印结束事件不能撤销新的阅读操作')
  expand.click()
  assert.deepEqual(details.map(node => node.open), [true, true], '打印后仍能继续操作折叠控件')
})

it('没有 flow 的旧报告规格照常渲染，不出现流程图结构（向后兼容）', async (t) => {
  const { client } = loadClient(t)
  const parsed = client.internals.reportSpecOf(JSON.stringify(SAMPLE))
  assert.equal(parsed.sections.every((section) => section.flow === null), true)
  const html = client.internals.reportHtml(parsed)
  assert.doesNotMatch(html, /class="flow"/)
  const drawn = await client.internals.ADAPTERS.report.render(JSON.stringify(SAMPLE), env())
  assert.doesNotMatch(drawn.markup, /含流程图/)
  assert.match(drawn.markup, /这是摘要卡/)
})

it('sections[].flow 生成内联 SVG 流程图，文字被转义', async (t) => {
  const { client } = loadClient(t)
  const flow = {
    direction: 'LR',
    nodes: [
      { id: 'a', label: '输入 <script>', sub: '需求' },
      { id: 'b', label: '处理' },
      { id: 'c', label: '输出' },
    ],
    edges: [
      { from: 'a', to: 'b', label: '解析' },
      { from: 'b', to: 'c' },
    ],
  }
  const value = { ...SAMPLE, sections: [{ title: '改动流程', flow }] }
  const parsed = client.internals.reportSpecOf(JSON.stringify(value))
  assert.equal(parsed.sections[0].flow.nodes.length, 3)
  const html = client.internals.reportHtml(parsed)
  assert.match(html, /<svg/, '报告页应当含内联 SVG')
  assert.match(html, /改动流程/)
  assert.match(html, /输入 &lt;script&gt;/, '流程图文字必须转义')
  assert.doesNotMatch(html, /输入 <script>/, '不能把标记带进页面')
})

it('流程图规格写错就报错', async (t) => {
  const { client } = loadClient(t)
  const base = (flow) => ({ ...SAMPLE, sections: [{ title: '流程', flow }] })
  const cases = [
    [base({ direction: 'XX', nodes: [{ id: 'a', label: 'a' }, { id: 'b', label: 'b' }] }), /direction 只能是/],
    [base({ nodes: [{ id: 'a', label: 'a' }] }), /至少 2 个节点/],
    [base({ nodes: Array.from({ length: 7 }, (unused, index) => ({ id: `n${index}`, label: `n${index}` })) }), /最多 6 个/],
    [base({ nodes: [{ id: 'a', label: 'a' }, { id: 'a', label: 'b' }] }), /id 不能重复/],
    [base({ nodes: [{ id: 'a', label: 'a' }, { id: 'b', label: 'b' }], edges: [{ from: 'a', to: 'zzz' }] }), /to 指向不存在的节点/],
  ]
  for (const [value, pattern] of cases) {
    assert.throws(() => client.internals.reportSpecOf(JSON.stringify(value)), pattern)
  }
})

it('规格写错就报错，不生成"看着像"的空报告', async (t) => {
  const { client } = loadClient(t)
  const cases = [
    [{ ...SAMPLE, status: '差不多完成' }, /status 未知/],
    [{ ...SAMPLE, title: '  ' }, /title 不能为空/],
    [{ ...SAMPLE, verdict: '' }, /verdict 不能为空/],
    [{ ...SAMPLE, sections: [{ title: '没有条目' }] }, /sections\[0\]\.items/],
    [{ ...SAMPLE, sections: 'nope' }, /sections 必须是数组/],
    [{ ...SAMPLE, meta: 'nope' }, /meta 必须是对象或/],
    [{ ...SAMPLE, badges: [{ tone: 'done' }] }, /badges\[0\]\.text 不能为空/],
    [{ ...SAMPLE, badges: [{ tone: 'nope', text: 'x' }] }, /badges\[0\]\.tone 未知/],
    [{ ...SAMPLE, notice: { tone: 'nope', text: 'x' } }, /notice\.tone 未知/],
    [{ ...SAMPLE, sections: [{ title: 't', table: { head: ['a'], rows: [['a', 'b']] } }] }, /rows\[0\] 必须与表头同列数/],
    [{ ...SAMPLE, sources: [{ text: '' }] }, /sources\[0\]\.text 不能为空/],
  ]
  for (const [value, pattern] of cases) {
    await assert.rejects(() => client.internals.ADAPTERS.report.render(JSON.stringify(value), env()), pattern)
  }
})

it('归一化后的规格可以再次解析（归档 report.json 回读）', (t) => {
  const { client } = loadClient(t)
  const once = client.internals.reportSpecOf(JSON.stringify(SAMPLE))
  const twice = client.internals.reportSpecOf(JSON.stringify(once))
  assert.deepEqual(twice, once)
  assert.ok(Array.isArray(once.meta) && once.meta.length > 0)
})

it('识别只认"结论 + 状态"这一对，不抢矩阵与指标卡', (t) => {
  const { client } = loadClient(t)
  const detect = client.internals.ADAPTERS.report.detect
  assert.equal(detect(JSON.stringify(SAMPLE)), true)
  assert.equal(detect(JSON.stringify({ items: [{ label: 'a', value: '1' }] })), false, '指标卡不该被抢')
  assert.equal(detect(JSON.stringify({ cases: [{ name: 'a', status: 'pass' }] })), false, '矩阵不该被抢')
  assert.equal(detect('flowchart TD\n  A --> B'), false)
})

it('归档只发一次，且尊重任务报告开关', async (t) => {
  const { dom, client } = loadClient(t)
  const calls = []
  let taskReport = true
  dom.window.fetch = async (url, options = {}) => {
    calls.push({ url: String(url), method: options.method ?? 'GET' })
    if (String(url).endsWith('/config')) {
      return { ok: true, json: async () => ({ value: { settings: { taskReport } } }) }
    }
    if (String(url).endsWith('/reports') && options.method === 'POST') {
      return { ok: true, json: async () => ({ ok: true, value: { id: 'x' } }) }
    }
    return { ok: true, json: async () => ({ ok: true, value: {} }) }
  }
  const spec = { title: 't', verdict: 'v', status: 'done' }
  await client.internals.archiveReport(spec, '<!doctype html>')
  await client.internals.archiveReport(spec, '<!doctype html>')
  assert.equal(calls.filter(call => call.method === 'POST').length, 1, '同一份报告只 POST 一次')

  await client.internals.archiveReport({ ...spec, title: 't2' }, '<!doctype html>')
  assert.equal(calls.filter(call => call.method === 'POST').length, 2, '新报告要再 POST')

  taskReport = false
  await client.internals.archiveReport({ ...spec, title: 't3' }, '<!doctype html>')
  assert.equal(calls.filter(call => call.method === 'POST').length, 2, '关闭后不能再归档')
})

it('设置页预览不归档示例报告', async (t) => {
  const { dom, client } = loadClient(t)
  const calls = []
  dom.window.fetch = async (url, options = {}) => {
    calls.push({ url: String(url), method: options.method ?? 'GET' })
    return { ok: true, json: async () => ({ ok: true, value: { settings: { taskReport: true } } }) }
  }
  await client.internals.ADAPTERS.report.render(JSON.stringify(SAMPLE), { ...env(), measure: false })
  assert.equal(calls.length, 0, '预览走同一个适配器，但不能写报告库')
})

it('manifest 条目齐全', () => {
  assert.equal(spec.output, 'svg', '对话里是 SVG 摘要卡')
  assert.deepEqual([...spec.languages], ['report'])
  assert.deepEqual([...spec.assets], [])
  assert.equal(spec.eager, true, '报告在长回复末尾，必须立即渲染并归档')
  assert.equal(spec.promptNote, undefined, '常驻规则由宿主固定行承担，避免同一句出现两次')
  assert.ok(spec.syntaxHint.includes('badges') && spec.syntaxHint.includes('table'), '语法提示要讲新块')
  assert.doesNotThrow(() => JSON.parse(spec.sample))
})

it('表格与来源里的标记被转义，不会变成 HTML', async (t) => {
  const { client } = loadClient(t)
  const source = {
    ...SAMPLE,
    sections: [{ title: '转义', table: { head: ['列'], rows: [['<b>']] } }],
    sources: [{ label: '来源', text: '<script>' }],
  }
  const html = (await client.internals.ADAPTERS.report.render(JSON.stringify(source), env())).snapshot().data
  assert.match(html, /&lt;b&gt;/)
  assert.match(html, /&lt;script&gt;/)
  assert.doesNotMatch(html, /<b>/)
})
