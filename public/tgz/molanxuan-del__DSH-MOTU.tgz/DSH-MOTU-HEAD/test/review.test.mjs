/**
 * The review protocol and the SVG preview checks.
 *
 * These are the trust boundary between "the model wrote something" and "the
 * user may see a picture": the same fingerprint on both halves, no external
 * resources, no malformed XML, and no confirmation without a successful
 * preview.
 */

import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { it } from 'node:test'

import { createVisualReview, previewEcharts, previewSvg } from '../lib/preview.js'

const require = createRequire(import.meta.url)
const core = require('../lib/review-core.cjs')

const GOOD = `<svg viewBox="0 0 240 120" xmlns="http://www.w3.org/2000/svg">
  <title>测试图</title>
  <desc>一张用于验收测试的图</desc>
  <rect x="8" y="8" width="224" height="104" rx="8" fill="#f4f6f9"/>
  <text x="20" y="60" font-size="14" fill="#22303f">你好，验收</text>
</svg>`

it('提取围栏、裸 SVG 与未闭合片段', () => {
  const fenced = core.extractSvgCandidates('前文\n```svg\n' + GOOD + '\n```\n后文')
  assert.equal(fenced.length, 1)
  assert.equal(fenced[0].complete, true)
  assert.equal(fenced[0].fingerprint, core.fingerprint('svg', GOOD))

  const raw = core.extractSvgCandidates('说明\n' + GOOD + '\n结束')
  assert.equal(raw.length, 1)
  assert.equal(raw[0].complete, true)

  const open = core.extractSvgCandidates('正在画\n<svg viewBox="0 0 10 10"><title>x</title><desc>y</desc>')
  assert.equal(open.length, 1)
  assert.equal(open[0].complete, false)

  assert.equal(core.extractSvgCandidates('```js\nconst svg = 1\n```').length, 0)
  assert.equal(core.extractSvgCandidates('普通说明').length, 0)
})

it('指纹忽略首尾空白，但区分不同源码', () => {
  assert.equal(core.fingerprint('svg', `  ${GOOD}  `), core.fingerprint('svg', GOOD))
  assert.notEqual(core.fingerprint('svg', GOOD), core.fingerprint('svg', GOOD.replace('你好', '再见')))
})

it('ECharts 也是验收候选，语言与指纹独立于 SVG', () => {
  const source = JSON.stringify({ xAxis: { type: 'category', data: ['A'] }, series: [{ type: 'bar', data: [1] }] })
  const list = core.extractVisualCandidates('```echarts\n' + source + '\n```')
  assert.equal(list.length, 1)
  assert.equal(list[0].language, 'echarts')
  assert.equal(list[0].fingerprint, core.fingerprint('echarts', source))
  assert.notEqual(list[0].fingerprint, core.fingerprint('svg', source))
  assert.equal(core.isReviewable('echarts', source), true)
  assert.equal(core.isReviewable('mermaid', 'flowchart TD\n A --> B'), false)
})

it('ECharts 只接受 JSON：option 赋值和单引号会被拒绝，合法 JSON 能出预览', async () => {
  const bad = await previewEcharts("option = { xAxis: { type: 'category' }, series: [{ type: 'bar', data: [1] }] };")
  assert.equal(bad.status, 'error')
  assert.ok(bad.checks.some((check) => check.id === 'json'))
  const goodSource = JSON.stringify({ xAxis: { type: 'category', data: ['A', 'B'] }, yAxis: { type: 'value' }, series: [{ type: 'bar', data: [1, 2] }] })
  const good = await previewEcharts(goodSource)
  assert.equal(good.status, 'ok')
  assert.ok(['image', 'structure'].includes(good.previewKind))
  assert.ok(good.checks.every((check) => check.status !== 'error'))
})

it('预览协议可往返解析', () => {
  const text = core.previewProtocol({
    status: 'ok',
    fingerprint: 'v1:abc',
    previewKind: 'image',
    checks: [{ status: 'error', id: 'xml', detail: '坏掉了' }],
  })
  const parsed = core.parseReviewResult(text)
  assert.equal(parsed.kind, 'preview')
  assert.equal(parsed.status, 'ok')
  assert.equal(parsed.fingerprint, 'v1:abc')
  assert.deepEqual(parsed.checks, [{ status: 'error', id: 'xml', detail: '坏掉了' }])
  assert.equal(core.parseReviewResult(core.confirmProtocol({ status: 'confirmed', fingerprint: 'v1:abc', accepted: true })).kind, 'confirm')
})

it('合法 SVG 通过结构检查，并在可用时生成预览图', async () => {
  const result = await previewSvg(GOOD)
  assert.equal(result.status, 'ok')
  assert.ok(['image', 'structure'].includes(result.previewKind))
  assert.ok(result.checks.every((check) => check.status !== 'error'))
  if (result.previewKind === 'image') {
    assert.ok(result.png.length > 0)
    assert.ok(result.width > 0 && result.height > 0)
  }
})

it('外部资源、脚本与事件属性被拒绝', async () => {
  const external = await previewSvg(GOOD.replace('<rect', '<image href="https://example.com/x.png"/><rect'))
  assert.equal(external.status, 'error')
  assert.ok(external.checks.some((check) => check.id === 'security-external'))

  const script = await previewSvg(GOOD.replace('<rect', '<script>alert(1)</script><rect'))
  assert.equal(script.status, 'error')
  assert.ok(script.checks.some((check) => check.id === 'security-script'))

  const event = await previewSvg(GOOD.replace('<rect', '<rect onload="x()"'))
  assert.equal(event.status, 'error')
  assert.ok(event.checks.some((check) => check.id === 'security-event'))
})

it('缺 title/desc 只警告；重复 id、缺失引用、空图和文字越界会拒绝', async () => {
  const noTitle = await previewSvg(GOOD.replace('<title>测试图</title>', ''))
  assert.equal(noTitle.status, 'ok', '无障碍标题缺失不应阻断视觉预览')
  assert.ok(noTitle.checks.some((check) => check.id === 'title' && check.status === 'warning'))

  const duplicate = await previewSvg(GOOD.replace('<rect', '<defs><linearGradient id="same"/><linearGradient id="same"/></defs><rect'))
  assert.equal(duplicate.status, 'error')
  assert.ok(duplicate.checks.some((check) => check.id === 'ids'))

  const missing = await previewSvg(GOOD.replace('fill="#f4f6f9"', 'fill="url(#missing)"'))
  assert.equal(missing.status, 'error')
  assert.ok(missing.checks.some((check) => check.id === 'refs'))

  const empty = await previewSvg('<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><title>x</title><desc>y</desc></svg>')
  assert.equal(empty.status, 'error')
  assert.ok(empty.checks.some((check) => check.id === 'empty'))

  const overflow = await previewSvg(`<svg viewBox="0 0 100 50" xmlns="http://www.w3.org/2000/svg"><title>x</title><desc>y</desc><text x="95" y="20" font-size="12">这是一段很长很长超出画布的文字</text></svg>`)
  assert.equal(overflow.status, 'error')
  assert.ok(overflow.checks.some((check) => check.id === 'overflow'))
})

it('未闭合或非法 XML 不会生成预览', async () => {
  const broken = await previewSvg('<svg viewBox="0 0 100 50"><title>x</title><desc>y</desc>')
  assert.equal(broken.status, 'error')
  assert.ok(broken.checks.some((check) => check.id === 'xml'))
  assert.equal(broken.png, undefined)
})

it('确认必须先有成功预览，接受/拒绝分别落到状态', async () => {
  const definitions = new Map()
  const images = []
  const ctx = {
    get(name) {
      if (name === 'tools') return { register: (definition) => { definitions.set(definition.name, definition); return () => {} } }
      if (name === 'attachments') return { saveImage: async (input) => { images.push(input); return { attachmentId: 'att-1', mediaType: 'image/png', bytes: input.data.length, width: 320, height: 160 } } }
      return undefined
    },
    logger: { warn() {} },
  }
  const review = createVisualReview({ ctx })
  assert.equal(review.available, true)
  const preview = definitions.get('preview_visual')
  const confirm = definitions.get('confirm_visual')
  assert.ok(preview && confirm)

  const fp = core.fingerprint('svg', GOOD)
  const before = await confirm.execute({ fingerprint: fp, accept: true }, { agent: { id: 's1' } })
  assert.equal(before.status, 'error')

  const previewed = await preview.execute({ language: 'svg', source: GOOD }, { agent: { id: 's1' } })
  assert.equal(previewed.status, 'ok')
  assert.equal(previewed.fingerprint, fp)
  assert.equal(images.length, 1)
  const content = preview.output.render({}, previewed)
  assert.equal(content[0].type, 'text')
  assert.equal(content[1].type, 'image', '预览图必须以图像内容块回到模型')
  assert.equal(content[1].attachment.attachmentId, 'att-1')
  const meta = preview.output.presentationMeta({}, previewed)
  assert.doesNotThrow(() => JSON.parse(JSON.stringify(meta)), 'presentationMeta 必须是可无损 JSON 化的值')
  assert.ok(!('image' in preview.output.presentationMeta({}, { ...previewed, image: undefined })), '没有图片时不能留下 undefined 字段')

  const accepted = await confirm.execute({ fingerprint: fp, accept: true }, { agent: { id: 's1' } })
  assert.equal(accepted.status, 'confirmed')
  const rejected = await confirm.execute({ fingerprint: fp, accept: false, reason: '标签挤在一起' }, { agent: { id: 's1' } })
  assert.equal(rejected.status, 'rejected')
})

it('回合边界只提醒未确认的 SVG，并限制为两次', () => {
  const ctx = { get: () => undefined, logger: { warn() {} } }
  const review = createVisualReview({ ctx })
  review.observe({ id: 's2' }, { type: 'turn/start', data: { turn: 1 } })
  review.observe({ id: 's2' }, {
    type: 'assistant/message',
    data: { turn: 1, message: { content: [{ type: 'text', text: `\`\`\`svg\n${GOOD}\n\`\`\`` }] } },
  })
  const first = review.steerFor({ id: 's2' }, 1)
  assert.match(first, /preview_visual/)
  const second = review.steerFor({ id: 's2' }, 1)
  assert.match(second, /preview_visual/)
  assert.equal(review.steerFor({ id: 's2' }, 1), '')

  const fp = core.fingerprint('svg', GOOD)
  review.recordPreview('s2', fp, { status: 'ok', fingerprint: fp, checks: [] })
  review.recordConfirm('s2', fp, true)
  assert.equal(review.steerFor({ id: 's2' }, 1), '')
})
