/** Real renderers and browser lifecycle; only the model response is simulated. */
import assert from 'node:assert/strict'
import { join } from 'node:path'

export async function checkRepairUi(browser, fixture, out) {
  const page = await browser.newPage({ viewport: { width: 375, height: 900 } })
  const errors = []
  page.on('pageerror', error => errors.push(error.message))
  const fixed = 'flowchart LR\n A[原图修复] --> B[保持会话]'
  const original = 'flowchart LR\n A[broken'
  const requests = []
  await page.route('**/dsh-visual-kit/repair', async route => {
    requests.push(route.request().postDataJSON())
    await route.fulfill({ json: { ok: true, value: { text: `【修正后的源码】\n\`\`\`mermaid\n${fixed}\n\`\`\`` } } })
  })
  try {
    await page.request.post(fixture.url + '/dsh-visual-kit/config', { data: { behavior: { selfRepair: true }, agent: { taskReport: false } } })
    await page.goto(fixture.url + '/?onlyLive')
    await page.evaluate(() => ready)
    await page.evaluate(source => addBlock('repair-browser', 'mermaid', source), original)
    await page.locator('#repair-browser .vk-error').waitFor()
    await page.locator('#repair-browser button').filter({ hasText: /^反馈并修复$/ }).click()
    await page.locator('#repair-browser .vk-figure[data-vk-display-state="ready"]').waitFor()
    assert.equal(requests.length, 1)
    assert.equal(requests[0].sessionId, 'fixture-session')
    assert.equal(await page.locator('#repair-browser pre code').first().textContent(), original)
    assert.match(await page.locator('#repair-browser .vk-canvas').textContent(), /原图修复/)
    await page.evaluate(() => { document.documentElement.dataset.theme = 'dark'; document.body.append(document.createElement('div')) })
    await page.waitForFunction(() => document.querySelector('#repair-browser .vk-figure')?.dataset.vkTheme === 'dark')
    await page.locator('#repair-browser .vk-figure[data-vk-display-state="ready"]').waitFor()
    assert.equal(await page.locator('#repair-browser .vk-figure').count(), 1)
    await page.evaluate(() => { motu.internals.SessionProbe({ sessionId: 'another-session' }); document.querySelector('#chat').replaceChildren() })
    await page.evaluate(source => { motu.internals.SessionProbe({ sessionId: 'fixture-session' }); addBlock('repair-remounted', 'mermaid', source) }, original)
    await page.locator('#repair-remounted .vk-figure[data-vk-display-state="ready"]').waitFor()
    assert.match(await page.locator('#repair-remounted .vk-canvas').textContent(), /原图修复/)

    const report = { title: '后台修图已回到原会话', status: 'partial', verdict: '修正后的图保留在原位置，切换会话后仍能查看。', facts: ['真实浏览器已验证渲染和回填。', '真实模型生成仍待宿主验收。'], sections: [{ title: '验证范围', details: { summary: '查看验证细节', items: ['主题重绘、窄屏阅读和会话切换。'] } }] }
    await page.evaluate(source => { document.documentElement.dataset.theme = 'light'; addBlock('readable-report', 'report', source) }, JSON.stringify(report))
    await page.locator('#readable-report .vk-figure[data-vk-display-state="ready"]').waitFor()
    const before = await page.locator('#readable-report .vk-canvas svg').getAttribute('viewBox')
    const snapshot = await page.evaluate(() => document.querySelector('#readable-report .vk-figure').__vkHandle.snapshot())
    assert.equal(snapshot.extension, 'html')
    assert.match(snapshot.data, /^<!doctype html>/)
    const downloading = page.waitForEvent('download')
    await page.locator('#readable-report [data-vk-action="snapshot"]').click()
    const download = await downloading
    assert.match(download.suggestedFilename(), /\.html$/)
    const stream = await download.createReadStream()
    const chunks = []
    for await (const chunk of stream) chunks.push(chunk)
    assert.match(Buffer.concat(chunks).toString('utf8'), /^<!doctype html>/)
    await page.locator('#readable-report [data-vk-action="view"]').click()
    await page.frameLocator('.vk-report-viewer-frame').getByRole('heading', { name: report.title, exact: true }).waitFor()
    await page.locator('.vk-report-viewer-bar button').click()
    assert.equal(await page.locator('#readable-report .vk-figure').getAttribute('data-vk-scale'), '1')
    await page.locator('#readable-report').scrollIntoViewIfNeeded()
    await page.screenshot({ path: join(out, 'report-summary-mobile.png') })
    await page.setViewportSize({ width: 1000, height: 900 })
    await page.waitForFunction(previous => document.querySelector('#readable-report .vk-canvas svg').getAttribute('viewBox') !== previous, before)
    assert.equal(await page.locator('#readable-report .vk-figure').getAttribute('data-vk-scale'), '1')
    const reader = await browser.newPage({ viewport: { width: 375, height: 900 } })
    try {
      await reader.setContent(snapshot.data)
      assert.equal(await reader.locator('details').evaluate(node => node.open), false)
      await reader.getByRole('button', { name: '全部展开' }).click()
      assert.equal(await reader.locator('details').evaluate(node => node.open), true)
      assert.equal(await reader.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true)
      await reader.screenshot({ path: join(out, 'report-reader-mobile.png'), fullPage: true })
    } finally { await reader.close() }
    assert.deepEqual(errors, [])
  } finally { await page.close() }
  return ['反馈修复：真实 Mermaid 原位重画、主题重绘和原会话重新挂载', '报告阅读：375px 摘要保持字号、尺寸重排、完整 HTML 查看与细节折叠']
}
