/**
 * Vendor every renderer engine, record its integrity, and generate the skill.
 *
 *   npm run vendor
 *
 * Three products, all derived from the manifest so they can never disagree with
 * it:
 *
 *   vendor/<renderer>/<file>   the engine builds, copied out of node_modules
 *   vendor/integrity.json      sha256, byte size and engine version per file —
 *                              the host half checks against this at startup and
 *                              when serving, so a truncated or hand-edited
 *                              engine is caught instead of failing mysteriously
 *   skill/SKILL.md + skill/references/<id>.md
 *                              what the agent reads when it decides to draw
 *
 * The engines are copied rather than bundled because they are what the browser
 * loads lazily, one per renderer, only when a conversation first uses it.
 *
 * @module dsh-visual-kit/scripts/vendor
 */

import { createHash } from 'node:crypto'
import { copyFileSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { renderers } from '../lib/renderers/manifest.js'
import { rendererCost } from '../lib/index.js'
import { styles } from '../lib/styles.js'

const here = dirname(fileURLToPath(import.meta.url))
const root = join(here, '..')
const modules = join(root, 'node_modules')
const vendorDir = join(root, 'vendor')
const skillDir = join(root, 'skill')

/** A markdown code fence, spelled once so the generated text stays readable. */
const F = '```'

/**
 * The mistake each engine's grammar trips on most often.
 *
 * The browser half's error card suggests the same things (`fixHint` in
 * `lib/client.js`), so both halves teach one lesson and a repeat failure costs
 * a glance instead of a round trip. Edit both together.
 *
 * @type {Record<string, string[]>}
 */
const PITFALLS = {
  mermaid: [
    '节点文字含括号、方括号或引号时**整段加引号**：写 `A["文字（含括号）"]`，不要写 `A[文字（含括号）]`。',
    '形状括号必须成对：`[]` 矩形、`()` 圆角、`[()]` 圆柱、`{}` 菱形。**只有旗形是左开口**的 `id>文字]` —— 把方括号塞进旗形（`id>["文字"]`）会直接 `Parse error`；要方框就写 `id["文字"]`。',
    '子图标题写成 `subgraph 名称["标题"]`；`end` 必须单独一行。',
    '**边标签里有裸双引号会 `Parse error`**：`A -->|说明| B` 的标签内不要放 `"` —— 改用 `「」` 或单引号，或把整段标签括起来并把内层引号转义。',
  ],
  graphviz: [
    '属性写成 `key="value"`；含空格或标点的标签必须加引号（`label="含 空格"`）。',
    '节点名不要用 `graph` / `node` / `edge` 这些保留字。',
    '每条语句以 `;` 结尾，整个图包在一对花括号里。',
  ],
  nomnoml: [
    '框是 `[文字]`、箭头是 `->`；连线标签写在箭头**前**：`[A] 是 -> [B]`。',
    '没有 `<choice>` 这类语法，尖括号会被当普通文本；判定就画普通方框。',
    '中文要加 `#padding: 22`，否则按西文字宽估算会溢出。',
  ],
  'vega-lite': [
    '必须有 `mark` 与 `data`；字段引用写在 `encoding.x.field`。',
    '这是 Vega-Lite，不是 Vega：不要写 `signals` / `marks` 这类运行时语法；叠加用 `layer`。',
  ],
  echarts: [
    'JSON 里不能有注释或尾随逗号；`series` 每项必须带 `type`，数据放在 `series.data`。',
    '配置必须是一段 JSON 对象，不能写 `option = {...}` 赋值、单引号或函数 formatter；formatter 用字符串模板，如 `"{value}s"`。',
  ],
  isometric: [
    'kind 只能是 solid 或 voxel；两种都是 JSON，不能有注释或尾随逗号。',
    '颜色写语义令牌（amber/blue/green/purple/red/ink/muted）或 #rrggbb；voxel 的 palette 键必须是单个字符。',
    'voxel 的 layers 与 shapes 二选一；用 shapes 时只有会放置体素的形状需要 fill（collapse 是挖空，不需要）。',
    '不要自己算缩放与取景 —— 引擎会自动把场景放进画布，你只描述有什么、在哪、什么颜色。',
    '需要转动或切开看内部时用 \u0060\u0060\u0060isometric-interactive；静态图用 \u0060\u0060\u0060isometric。',
  ],
  svg: [
    '手写 SVG 没有语法可错，但必须带 `<title>` 与 `<desc>`；`viewBox` 用 `0 0 680 高`（高 ≤ 400），否则会被画布裁切。',
    '宿主提供 `preview_visual` / `confirm_visual` 时，写完 SVG 先预览并检查图像；确认无误后再调用 `confirm_visual`，未确认不要当作已交付。',
  ],
  report: [
    '**正文必须是一个 JSON 对象**：栅栏里不要写「结论：…」这种行文，也不要写 Markdown 列表 —— 直接写 `{ "title": "…", "status": "done", "verdict": "…" }`。',
    'JSON 用英文双引号，不能有注释或尾随逗号；先写 `title/status/verdict`，其余字段按需要选用，不必凑齐。',
    '只写实际跑过的验证；没跑就写「未验证」，不要写「应该没问题」。',
    'verdict 回答用户当前最关心的问题：排错给原因与处理结果，比较给推荐与条件，分析给发现与边界；不要写成操作流水账。',
    '改动表只列真实改过的文件；不要把计划、建议或未做的改动写进去。',
    '状态与徽章要一致：`partial` 时不要给「已完成」徽章。',
    '`sections[].flow` 画内联 SVG 流程图：2–6 个节点，`nodes[].id` 唯一，`edges[].from/to` 必须指向已声明的 id；不要写坐标、颜色或 SVG 源码。',
    '只有流程图能帮助理解本次结论时才加 `flow`；不要画报告如何生成、解析或归档的流程来填版面。',
  ],
}

/**
 * One-line fallback for a renderer without a pitfalls entry.
 *
 * @param {object} spec - the renderer.
 * @returns {string[]} its pitfall lines.
 */
function pitfallsOf(spec) {
  return PITFALLS[spec.id] ?? [spec.syntaxHint ?? '']
}

/**
 * Hash a file's bytes.
 *
 * @param {string} path - the file.
 * @returns {{ sha256: string, bytes: number }} its digest and size.
 */
function digest(path) {
  const bytes = readFileSync(path)
  return { sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length }
}

/**
 * The installed version of an npm package.
 *
 * @param {string} name - package name.
 * @returns {string} its version, or 'unknown' when the package is absent.
 */
function versionOf(name) {
  try {
    return JSON.parse(readFileSync(join(modules, name, 'package.json'), 'utf8')).version
  } catch {
    return 'unknown'
  }
}

// ---------------------------------------------------------------------------
// 1. Copy the engines and hash them.
// ---------------------------------------------------------------------------

mkdirSync(vendorDir, { recursive: true })

/** @type {Record<string, {sha256: string, bytes: number, pkg: string, version: string}>} */
const integrity = {}
const missing = []

for (const spec of renderers) {
  for (const asset of spec.assets) {
    const source = join(modules, asset.pkg, asset.from)
    const target = join(vendorDir, asset.path)
    let info
    try {
      info = digest(source)
    } catch {
      missing.push(`${asset.pkg} (${asset.from})`)
      continue
    }
    mkdirSync(dirname(target), { recursive: true })
    copyFileSync(source, target)
    const version = versionOf(asset.pkg)
    integrity[asset.path] = { sha256: info.sha256, bytes: info.bytes, pkg: asset.pkg, version }
    console.log(
      `${spec.id.padEnd(11)} ${asset.path.padEnd(28)} ${(info.bytes / 1024).toFixed(0).padStart(6)} KB  ${asset.pkg}@${version}`,
    )
  }
}

if (missing.length > 0) {
  console.error(`\n缺少依赖: ${missing.join(', ')}`)
  console.error('先运行: npm install')
  process.exit(1)
}

writeFileSync(
  join(vendorDir, 'integrity.json'),
  `${JSON.stringify({ generatedAt: new Date().toISOString(), assets: integrity }, null, 2)}\n`,
  'utf8',
)
console.log(`\nvendor/integrity.json  ${Object.keys(integrity).length} 个文件`)

// ---------------------------------------------------------------------------
// 2. Generate the skill: the body the agent loads on demand, plus one
//    reference page per renderer.
// ---------------------------------------------------------------------------

mkdirSync(join(skillDir, 'references'), { recursive: true })

// 成本数字从同一份计算里取，避免像上一版那样手写后漂掉
const costRows = [...renderers]
  .sort((a, b) => rendererCost(a, {}, false).figureTokens - rendererCost(b, {}, false).figureTokens)
  .map((spec) => `${spec.label} ≈ ${rendererCost(spec, {}, false).figureTokens}`)
  .join('，')

const selectionRows = renderers
  .map((spec) => `| ${spec.when} | ${spec.label} | ${spec.languages.map((l) => `${F}${l}`).join(' / ')} | [${spec.id}.md](references/${spec.id}.md) |`)
  .join('\n')

/**
 * Per-renderer material that belongs on its own reference page.
 *
 * These sections used to sit in SKILL.md, where every reader paid for all eight
 * renderers whether or not they used them — and the syntax and pitfall sections
 * were verbatim duplicates of what the reference pages already carried. The
 * body is read whole, the reference page is read when it is needed, so the
 * detail belongs here.
 *
 * @param {object} spec - the renderer.
 * @returns {string} extra markdown for that page, or ''.
 */
function extraFor(spec) {
  if (spec.id === 'report') {
    return `
## 什么时候写

仅在**用户明确要求报告，或复杂结果确实需要留存**时写。查阅文件、运行命令或小改动本身不构成写报告的理由，简短任务直接用自然语言总结。用户明确要求时，研究或解释结果也可以成报告。

## 怎么写得容易读

1. **先给结论**：\`title/status/verdict\` 足以组成一份最小报告；一句话说清结果及对用户的影响。
2. **只留必要证据**：\`facts\` 通常 1–3 条，用于支撑结论或指出影响使用的限制，不复述结论。
3. **按需展开**：复杂内容才用 \`sections\`；比较多项时用 \`table\`，实现细节放 \`details\`。没有内容的字段直接省略。
4. **限制不能藏起来**：影响交付或下一步操作的风险放在结论或要点中，次要技术细节再折叠。
5. **避免重复**：正文、\`verdict\`、\`facts\` 和各节承担不同信息；不要把同一段结论、验证或风险换种说法写多次。

## 先选场景，再组织解释

先确认读者要弄懂什么、做什么决定，再选一个主场景。混合任务只补缺少的部分，不把所有场景的提纲拼起来。下面是要回答的问题，不是必须照抄的章节名。

| 场景 | 必须说明白的问题 | 有助理解的表达 |
| --- | --- | --- |
| 故障排查 / 代码审查 | 用户在什么条件下看到什么异常？证据指向哪一步，为什么会导致这个结果？排除了什么解释？如何修复、怎样验证、还有什么没确认？审查发现给触发条件、影响及文件位置。 | 小型因果链用 flow，边上注明触发或传递关系；修复前后用相同条件对照。没有定位根因时写假设和验证办法，不能画成确定因果。 |
| 方案比较 / 决策建议 | 目标和约束是什么？各方案按同一组维度有何差异？为什么推荐这一项，接受了什么代价？什么条件改变后应换方案？ | table 横向比较成本、效果、风险等实际相关维度；建议和理由用完整句子说明。没有测量就写定性依据，不编评分。 |
| 实施交付 / 进度汇报 | 原来怎样、现在怎样，用户可以做什么？哪些已落地、哪些只做了计划？验证覆盖了什么范围，剩余阻塞影响什么，下一步由谁做什么？ | 前后对照表、验证矩阵；只有步骤或依赖确有变化时画流程。命令成功不等于功能验收，代码完成不等于部署完成。 |
| 数据分析 / 实验结果 | 数据来自哪里，时间范围、单位、样本和比较基线是什么？主要发现是多少、对判断有什么影响？有哪些异常、缺失或不确定性？ | 趋势用折线、类别比较用柱状图、关系用散点；图后解释读数与业务含义。相关关系不直接写成因果，未采集数据不能补成观测值。 |
| 原理讲解 / 架构说明 | 系统要解决什么问题？各部分负责什么，输入如何经过它们变成输出？关键机制为什么有效，边界或失败路径是什么？ | 结构图交代归属与边界，流程或时序图交代运行过程；用一个具体输入走通路径，首次出现的术语给简短解释。 |
| 行动计划 / 路线图 | 想达到什么结果，验收条件是什么？先后顺序由哪些依赖决定？每步的产物、负责人和阻塞是什么？如何调整或回退？ | 依赖图或里程碑表；只有时间依据充分时才画时间线。负责人、日期未知就标待定，计划不能冒充已经完成。 |

## 让话说完整

- **从问题到答案**：结论直接回答用户的问题；依据说明观察到了什么、如何支持结论；解释它对使用或决策的影响。确需行动时写清下一步、执行者和完成条件，不强加无用的下一步。
- **解释因果和取舍**：不要只写“已优化”“问题在缓存”“方案 A 更好”。写成“在什么条件下，哪个环节发生什么，因此造成什么结果；对应改动为什么能改变结果”。证据不足时用“推测”，并写还缺哪项验证。
- **让每节能独立读懂**：用具体标题；\`items\` 中写完整解释句，需要时用两三句交代上下文、理由与例子，不堆术语或文件名。重要解释放正文，代码、命令日志等复核细节再进 \`details\`。
- **按复杂度分配篇幅**：\`facts\` 的 1–3 条只是摘要建议，不能成为省略依据、原理或重要限制的借口。复杂问题在 \`sections\` 展开；简单问题无需凑章节。面向非开发者时先讲可感知的行为，再解释实现细节。
- **证据可复核**：测试注明对象、条件、实际结果和未覆盖范围；数据与外部结论给来源及口径；推断写出推理依据。示例中的数字、测试、文件和结果均不可冒充本次事实。
- **状态描述对象明确**：\`done\` 只表示本次请求的目标已完成；研究完成不代表假设已证实，方案完成不代表已经实施。未完成目标用 \`partial/blocked/failed\`，并说清影响。

## 让图表承担解释

1. 画之前先写出图要回答的一个问题，例如“修复在哪一步阻止了错误回写”。如果图只是把已有标题连起来，或画报告生成过程，就省略。
2. \`sections[].flow\` 适合 2–6 个节点的小型关系或流程，连线标清方向与含义；比较用 \`table\`，表头包含比较维度、单位或条件。不要把所有信息都塞进 flow。
3. 趋势、统计、复杂结构需要专用图时，在报告附近另用**当前启用的** ECharts、Mermaid、Graphviz 或手写 SVG 等代码块。先读该渲染器参考页并遵循当前绘图偏好；不要给 report 发明 chart/html/svg 字段，也不要把图表栅栏塞进 \`items\` 字符串。
4. 图标题点明对象和要看的关系；节点使用具体名称，数字说明单位、时间与基线，颜色或符号有图例；同一概念在图文中使用同一名称。假设关系应在标注和说明中注明。
5. 图旁用一两句指出“看哪里、说明什么、有什么限制”。图和文字互补，不逐项复述图中所有标签。独立图未嵌入导出报告时，\`sections\` 仍保留关键读数和解释，让导出的报告能够单独读懂；不要伪称附图已随报告导出。

## 场景写法示例

以下均是演示事实，不是本项目已验证的结果。实际输出必须换成本轮证据；示例结构可以调整，不必照抄章节。

### 排错：把原因、修复机制和验证连起来

\`\`\`report
{
  "title": "为什么修正后的图仍没有显示",
  "status": "partial",
  "verdict": "修复结果到达后，展示校验仍拿它与旧源码比较，导致新图被当作过期结果丢弃。已调整校验，真实宿主中的模型链路仍待验证。",
  "facts": ["演示验证：同一错误输入修正后，新图通过校验并显示；切换会话后的旧结果仍被拒绝。"],
  "sections": [
    {
      "title": "结果到达了，为什么仍然不显示",
      "items": ["原代码块保留旧文本，而后台返回的是修正文本。旧校验要求两者相等，所以即使修正文本能正常绘图，也会被拒绝。问题发生在结果接纳阶段，而不是图形引擎。"],
      "flow": {
        "nodes": [{"id":"fixed","label":"修正源码返回"},{"id":"check","label":"与旧源码比较"},{"id":"drop","label":"新图被丢弃"}],
        "edges": [{"from":"fixed","to":"check","label":"接纳前校验"},{"from":"check","to":"drop","label":"文本不一致"}]
      }
    },
    {
      "title": "修复的作用和剩余边界",
      "items": ["改为按原始源码版本绑定修正内容，展示校验读取当前有效内容；会话或原始源码变动仍会使旧结果失效。这样既能接纳本次修复，也能阻止过期结果覆盖新图。", "演示中只完成模拟修复结果的验证。下一步由维护者在真实宿主触发一次修复，以原图出现且不新增可见会话作为验收条件。"]
    }
  ]
}
\`\`\`

### 比较：推荐必须带适用条件和代价

\`\`\`report
{
  "title": "离线预览如何选择展示方式",
  "status": "done",
  "verdict": "在只需阅读和离线导出的前提下，建议先用静态 SVG；若必须悬停查数或筛选系列，再选择交互图表。本结论是方案建议，尚未实施。",
  "sections": [
    {
      "title": "按本次需求比较",
      "table": {
        "head": ["维度", "静态 SVG", "交互图表"],
        "rows": [["读者操作", "阅读、缩放", "悬停、筛选等配置支持的操作"], ["导出范围", "图形可独立阅读", "静态快照不保留交互"], ["维护代价", "管理图形与布局", "还需管理实例、事件与销毁"]]
      },
      "items": ["当前目标没有查询和筛选需求，额外交互带来的收益有限，所以优先静态 SVG。代价是读者不能在图中按需查看隐藏数据；如果这成为必需操作，应改选交互图表。以上是能力比较，不是性能实测。"]
    }
  ]
}
\`\`\`

## 发出前检查是否讲清楚

- 不看操作日志，读者能否说出答案是什么、凭什么相信、对自己有什么影响？
- 图中每条关系和每个数字是否有依据，图文是否一致，关键单位、图例与限制是否齐全？
- 建议、计划、实际完成和验证结果是否分开？重要限制是否仍在显眼位置？
- 必要时读者能否知道下一步具体做什么？去掉的只是重复信息，还是连理解结论所需的解释也删掉了？

## 纪律

- 只写实际发生的事；不确定就写不确定。
- 不要求每份报告都有改动表、轮次、徽章、来源或流程图；不要为了填满模板补写无用内容。
- 同一轮只写一份；对话正文简短指向报告，不再复制整份报告内容。
- 报告页与摘要卡都跟随当前风格；正文里不要指定颜色、字号或版式。
- 自动归档到项目的 \`.dsh/visual-kit/reports/\`，正文里不需要贴路径。

## 可选流程图

确有需要时，在一节中使用 \`flow: { "direction": "LR", "nodes": [{ "id": "a", "label": "请求" }, { "id": "b", "label": "响应" }], "edges": [{ "from": "a", "to": "b" }] }\`。节点与边描述实际任务中的关系；没有关系需要解释时省略。
`
  }
  if (spec.id === 'echarts') {
    return `
## 交互模式

需要悬停数值、图例筛选或区间缩放时，用 \`\`\`echarts-interactive 输出 ECharts JSON。使用内联数据，配置不超过 256 KiB、数据总量不超过 10,000 点，不写函数、HTML 提示框或外部资源。提示框使用 richText；需要区间缩放时声明 dataZoom，图例筛选时声明 legend。

交互初始化失败只尝试一次静态降级；降级失败保留源码与错误说明。配置页可关闭交互模式，普通 echarts 不受影响。
`
  }
  if (spec.id === 'svg') {
    return `
## 设计系统

选用手写 \`\`\`svg 后遵循当前视觉风格的整图设计规范；画法选择以当前绘图偏好与用户要求为准。以下是各风格共用的可读性要求，不额外指定配色、圆角或字号来覆盖当前风格。

- **画布**：\`<svg viewBox="0 0 680 高" width="100%" role="img">\`，左边距 40，卡片间留白充足。
- **构图**：先确定阅读顺序与主体，再安放标题、分区、说明和图例；不要把所有内容机械地套入相同卡片。
- **视觉语言**：配色、圆角、边框、连线和字号取当前风格的规则，保持全图一致；参考示例的暖色不是所有风格的强制要求。
- **连线与标注**：箭头表达真实方向，路径避开文字和节点；标签靠近对应对象，长文手动换行，不重叠、不出界。
- **字号层级**：标题、分区标题、正文与注释有明确主次，字号随画布比例协调；代码路径可用 \`ui-monospace\`。
- **无障碍**：每个图带 \`<title>\` 与一句 \`<desc>\`。
- 布局模式：对照＝两块语义色面板并排；时间线＝竖线＋圆点＋卡片；路线＝阶梯上行；循环＝横链＋虚线回路。
`
  }
  return ''
}

/**
 * The part-recipe table for the isometric reference page.
 *
 * A part is a shorthand that expands into primitives, so the model writes one
 * line instead of placing every plate and foot. Listed here rather than only in
 * the renderer's syntax hint because the parameters are what make them usable.
 *
 * @returns {string} the markdown section.
 */
function partSection() {
  const rows = [
    ['base', '底座 + 四角支脚，给场景一个落地感', 'size, thickness, footHeight, feet'],
    ['stack', '分层堆叠：每层一块板，层间留空', 'layers, size, gap, thickness, colors[]'],
    ['rack', '机架：四柱 + 顶底 + 槽位', 'size, height, slots, post'],
    ['grid', '阵列：集群 / 机柜排 / 节点网格', 'count[列,行], size, spacing'],
    ['tower', '塔楼：角柱 + 楼板', 'size, floors, floorHeight, slab, post'],
    ['dial', '表盘：盘面 + 表圈 + 指针', 'r, height, needle（弧度 0..1）, needleColor'],
    ['rail', '导轨 + 滑台 + 两端限位', 'length, gauge, rail, carriage, carriageAt(0..1), carriageColor'],
    ['post', '立柱 + 底座法兰 + 卡箍', 'height, r, clampAt(0..1), clampColor'],
  ].map(([name, what, params]) => '| `' + name + '` | ' + what + ' | ' + params + ' |').join('\n')
  return [
    '## 零件配方',
    '',
    '图元是积木，配方是成品件。写 `{ "type": "part", "part": "stack", "layers": 3 }` 比一个个摆板子省得多，也更不容易摆歪。公共参数是 `at`（中心）、`color`、`label`。',
    '',
    '| 配方 | 是什么 | 参数 |',
    '| --- | --- | --- |',
    rows,
    '',
    '`case` 可以是数字（立方体）或 `[宽, 深, 高]`（扁柜子）——宽而矮的场景塞进立方体会浪费大半画幅。',
    '',
    '关系检查会跑在配方上：引线必须落在某个配方或图元的包围盒内。**配方内部不做互穿判定**——它的几何是展开出来的，只有包围盒，而按包围盒判互穿会报出并不存在的重叠。',
    '',
  ].join('\n')
}
/**
 * The pre-flight checklist for a figure.
 *
 * Ported from the Anatomy skill's craft notes, where every entry is traced to a
 * figure that was rejected for it. Kept short and phrased as things that go wrong,
 * because that is what makes a rule memorable enough to be applied.
 *
 * @returns {string} the markdown section.
 */
function checklistSection() {
  return [
    '## 出图前的自检',
    '',
    '每条都对应一次真实返工（前几条借鉴自 Anatomy 的工艺笔记，那里每条都记着是哪张图被谁驳回的）。',
    '',
    '- **线停在半空**：手写 SVG 里每条开放路径都要落在别的笔画、圆点或轮廓上。一条没有落点的线，读者会以为它指向别处。',
    '- **纹理画到一半断掉**：刻度、螺栓点、肋条要么结束在真实边界上，要么淡出。硬切在面中间读起来像坏了。',
    '- **靠眼睛调一张特写**：手调的键在 1× 下看着对，实际可能有几百处深度序错误（Anatomy 初版猛禽：54 处间隙问题、323 处深度序问题，全是截图看不出来的）。**先测量，再看。**',
    '- **抽象堆叠**：浮着的板子代表"层"，读者认不出是什么。做成抽屉、托盘、导轨上的滑台。',
    '- **一块大平板**：大面配几条线太平。拆成底座 + 滑台 + 零件，加沟槽、螺丝、标尺。',
    '- **文字塞进图里**：文字进标题、图例与说明；图内只留必要标注（编号引线是有意的，但不要每块都标）。',
    '- **颜色铺满**：留一处高亮告诉眼睛先看哪里，其余克制。',
    '- **指针瞬移**：一切移动都要缓动，慢到能跟上。',
    '- **照抄参考图**：取气质与完成度，物件自己造。',
    '',
    '等距与体素还有一条硬检查（`npm run check:renderers` 会跑）：物体不得互穿、引线必须落在图元上、图例项必须有对应物体。包含不算缺陷——球在壳里、城在球里是这些图的常用构造。',
    '',
  ].join('\n')
}
writeFileSync(
  join(skillDir, 'SKILL.md'),
  `# 可视化输出

用带语言的代码块输出图，DSH 会把它渲染成真正的图；写错语法不会破坏对话，只会显示一张错误卡片。

**动手前先读你打算用的那一种的参考页**：语法、易错点与完整示例都在那里。本页只讲选型与纪律 —— 把每个渲染器的细节都摊在这里，等于让每次读取都为十一种渲染器付费。

需要输出报告时，先读 [报告表达规范](references/report.md)：按任务场景组织结论、依据和解释，选择能说明问题的图表；不要只填字段或堆关键词，也不要为精简省略必要解释。

## 选型

| 要表达什么 | 用什么 | 栅栏 | 参考页 |
| --- | --- | --- | --- |
${selectionRows}

## 成本纪律

- 图由浏览器渲染，**渲染本身不花 token**；花 token 的是你写进对话的源码，而它会留在对话里、之后每轮都被重读。
- 同一份内容**语法越声明式越省**。一张典型图的源码代价（估算）：${costRows}。优先选够用的最小语法。
- **不要重复画同一张图**。
- 大段 HTML/长文档**写成文件并给出路径**，不要贴进对话（省 92–99% 的上下文）。

## 失败处理

- 语法错误会保留原始代码块并显示错误卡片，改对后自动重新渲染。
- 图上「反馈」按钮把经过截断的源码与诊断记录到本机，并尝试复制诊断；不会自动发给作者或自动修改插件。
- 交互图表的反馈附带模式、原始失败阶段与降级结果。静态错误的「反馈并修复」由后台 subagent 修正源码并在原位置重画，不新开可见会话，不修改插件文件。
` + checklistSection(),
  'utf8',
)

for (const spec of renderers) {
  const versions = spec.assets.length === 0
    // 自绘渲染器不加载任何第三方引擎：参考页要说明这一点，而不是留一个空的"引擎："
    ? '内置于插件（无第三方引擎，投影在本地计算）'
    : spec.assets
        .map((asset) => `${asset.pkg}@${integrity[asset.path]?.version ?? 'unknown'}`)
        .join(', ')
  const fontNote = {
    stack: '字体使用宿主应用的字体栈，与正文同字号（13px），无需你处理。',
    'single-family': '该引擎只能指定**单一字体族**（CSS 字体栈无效）。中文必须显式写字体，否则标签会缺字。',
    embedded: '该引擎自带字体。',
  }[spec.fontPolicy ?? 'stack']

  writeFileSync(
    join(skillDir, 'references', `${spec.id}.md`),
    `# ${spec.label}

${spec.usage}

- 栅栏：${spec.languages.map((l) => `${F}${l}`).join(' / ')}
- 引擎：${versions}
- 字体：${fontNote}

## 语法

${spec.syntaxHint}

## 易错点

${pitfallsOf(spec)
  .map((line) => `- ${line}`)
  .join('\n')}

## 完整示例

${F}${spec.languages[0]}
${spec.sample}
${F}
` + extraFor(spec) + (spec.id === 'isometric' ? partSection() : ''),
    'utf8',
  )
}

console.log(`skill/SKILL.md + skill/references/*.md  ${renderers.length + 1} 个文件`)
console.log(`\n完成：${Object.values(integrity).reduce((sum, item) => sum + item.bytes, 0) / 1024 / 1024} MB 引擎产物`)
