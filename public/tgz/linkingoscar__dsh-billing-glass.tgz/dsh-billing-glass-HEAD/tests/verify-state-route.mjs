// 聚合路由集成冒烟：用 mock ctx 直接驱动 apply()，
// 验证 /api/billing-glass/state 的 sessionId 传递、会话费用、
// DeepSeek 余额缓存 TTL 与 POST 强刷路由（不访问真实网络）。
import { test, mock, after } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const temp = mkdtempSync(join(tmpdir(), "dsh-billing-glass-state-"));
process.env.DSH_HOME = temp;
// The response fixture describes an off-peak Sunday. Real wall-clock time made
// the same route switch prices (and day/month buckets) depending on the test run.
process.env.TZ = "UTC";
mock.timers.enable({ apis: ["Date"], now: Date.parse("2026-09-20T12:00:00Z") });
after(() => mock.timers.reset());

let fetchCalls = 0;
let balanceTotal = 100;
globalThis.fetch = async (_url) => {
  fetchCalls += 1;
  const body = JSON.stringify({
    is_available: true,
    balance_infos: [{ total_balance: balanceTotal, granted_balance: 10, topped_up_balance: 90, currency: "CNY" }]
  });
  return {
    ok: true,
    status: 200,
    text: async () => body,
    json: async () => JSON.parse(body)
  };
};

const { apply, rejectUnauthorizedRequest } = await import("../lib/index.js");

const routes = new Map();
let sessionHandler = null;
const ctx = {
  get(name) {
    if (name === "sessionPersistence") {
      return {
        readStoredRevision: async () => "r1",
        readRaw: async () => ({
          content: [
            JSON.stringify({ type: "request/header", time: Date.now(), data: { header: { config: { provider: "deepseek-official", model: "deepseek-v4-pro" } } } }),
            JSON.stringify({
              type: "assistant/message",
              time: Date.now(),
              data: {
                message: { id: "m1", source: { provider: "deepseek-official", model: "deepseek-v4-pro" } },
                usage: { inputTokens: 1_000_000, cacheReadTokens: 0, outputTokens: 500_000 }
              }
            })
          ].join("\n")
        })
      };
    }
    if (name === "agentDefaultModel") {
      return { currentSelection: () => ({ provider: "deepseek-official", model: "deepseek-v4-pro" }) };
    }
    if (name === "dshHomePath") return (...parts) => join(temp, ...parts);
    return null;
  },
  credentials: {
    resolve: async (ref) => (ref === "DEEPSEEK_API_KEY" ? { value: "sk-test" } : void 0)
  },
  webServer: {
    register(descriptor) { routes.set(descriptor.path, descriptor.handler); }
  },
  on(event, handler) { if (event === "session/event") sessionHandler = handler; },
  effect(fn) { fn(); },
  logger: { warn() {}, error() {}, info() {} }
};

apply(ctx);
const stateHandler = routes.get("/api/billing-glass/state");
const refreshBalanceHandler = routes.get("/api/billing-glass/refresh-balance");
assert.ok(typeof stateHandler === "function", "state 路由已注册");
assert.ok(typeof refreshBalanceHandler === "function", "refresh-balance 路由已注册");

function request(handler, url, method = "GET") {
  return new Promise((resolve) => {
    let body = "";
    const res = {
      writeHead(status) { res.status = status; },
      end(chunk) { body += chunk; res.status = res.status ?? 200; resolve({ status: res.status, body: JSON.parse(body) }); }
    };
    handler({ url, method }, res).catch(() => {});
  });
}

test("state 路由：sessionId 驱动会话费用与活跃供应商，DeepSeek 余额可返回", async () => {
  sessionHandler({ id: "s1" }, {
    type: "request/header",
    time: Date.now(),
    data: { header: { config: { provider: "deepseek-official", model: "deepseek-v4-pro" } } }
  });
  sessionHandler({ id: "s1" }, {
    type: "assistant/message",
    time: Date.now(),
    data: {
      message: { id: "m2", source: { provider: "deepseek-official", model: "deepseek-v4-pro" } },
      usage: { inputTokens: 2_000_000, cacheReadTokens: 0, outputTokens: 1_000_000 }
    }
  });
  const { status, body } = await request(stateHandler, "/api/billing-glass/state?sessionId=s1");
  assert.equal(status, 200);
  assert.equal(body.ok, true);
  assert.equal(body.sessionId, "s1");
  assert.equal(body.activeProvider, "deepseek");
  assert.equal(body.activeModel, "deepseek-v4-pro");
  const deepseek = body.providers.find((p) => p.id === "deepseek");
  assert.ok(deepseek, "DeepSeek provider 行存在");
  assert.equal(deepseek.balance.total, 100);
  assert.ok(deepseek.session !== null, "会话费用存在");
  assert.equal(deepseek.session.calls, 2, "replay m1 + live m2 去重后 union 为两条");
  assert.ok(deepseek.session.costUsd > 0, "会话费用 USD > 0");
  assert.ok(deepseek.session.costNative > 0, "会话费用原生币种 > 0");
  assert.equal(deepseek.session.nativeCurrency, "CNY");
  assert.equal(deepseek.keyConfigured, true);
});

/** 递归键排序（golden 对比用的规范化视图）。
 * @param {any} value
 * @returns {any}
 */
function sortedKeys(value) {
  if (Array.isArray(value)) return value.map(sortedKeys);
  if (value !== null && typeof value === "object") {
    /** @type {Record<string, unknown>} */
    const out = {};
    for (const key of Object.keys(value).sort()) out[key] = sortedKeys(value[key]);
    return out;
  }
  return value;
}

test("state 路由 golden 快照：响应契约与基线一致（UPDATE_SNAPSHOT=1 重录）", async () => {
  const { body } = await request(stateHandler, "/api/billing-glass/state?sessionId=s1");
  const normalized = sortedKeys(body);
  const goldenPath = join(dirname(fileURLToPath(import.meta.url)), "fixtures", "state-route.golden.json");
  if (process.env.UPDATE_SNAPSHOT === "1" || !existsSync(goldenPath)) {
    writeFileSync(goldenPath, JSON.stringify(normalized, null, 2) + "\n", "utf8");
    assert.ok(true, process.env.UPDATE_SNAPSHOT === "1" ? "golden 快照已重录" : "golden 快照首次生成");
    return;
  }
  const golden = JSON.parse(readFileSync(goldenPath, "utf8"));
  assert.deepEqual(normalized, golden, "state 响应偏离 golden 基线：若为有意契约变更，请 UPDATE_SNAPSHOT=1 重录并在 PR 中肉眼审查 diff");
});

test("POST refresh-balance 绕过 DeepSeek 余额缓存，GET state 保持只读", async () => {
  const before = fetchCalls;
  await request(stateHandler, "/api/billing-glass/state?sessionId=s1");
  assert.equal(fetchCalls, before, "缓存命中不重复请求余额接口");
  balanceTotal = 88;
  await request(refreshBalanceHandler, "/api/billing-glass/refresh-balance?providerId=deepseek", "POST");
  assert.equal(fetchCalls, before + 1, "POST 强刷绕过缓存重新请求余额接口");
  const { body } = await request(stateHandler, "/api/billing-glass/state?sessionId=s1");
  assert.equal(body.providers.find((p) => p.id === "deepseek").balance.total, 88, "强刷后 GET 拿到新余额");
  const rejected = await request(refreshBalanceHandler, "/api/billing-glass/refresh-balance?providerId=deepseek", "GET");
  assert.equal(rejected.status, 405, "GET 调用强刷路由被拒绝");
});

test("state 路由：未知模型 fail closed，计入 unpricedCalls 而不是 0 元", async () => {
  sessionHandler({ id: "s1" }, {
    type: "request/header",
    time: Date.now(),
    data: { header: { config: { provider: "groq", model: "brand-new-model" } } }
  });
  sessionHandler({ id: "s1" }, {
    type: "assistant/message",
    time: Date.now(),
    data: {
      message: { id: "m3", source: { provider: "groq", model: "brand-new-model" } },
      usage: { inputTokens: 1000, cacheReadTokens: 0, outputTokens: 100 }
    }
  });
  const { body } = await request(stateHandler, "/api/billing-glass/state?sessionId=s1");
  const groq = body.providers.find((p) => p.id === "groq");
  assert.ok(groq, "groq provider 行存在");
  assert.equal(groq.session.unpricedCalls, 1);
  assert.equal(groq.session.costNative, 0);
  assert.equal(groq.session.costUsd, 0);
});

test("state 路由：未传 sessionId 时回退后台配置供应商", async () => {
  const { body } = await request(stateHandler, "/api/billing-glass/state");
  assert.equal(body.activeProvider, null);
  assert.equal(body.configuredProvider, "deepseek");
});

test("v0.1.2 connection 拒绝策略保护插件精确路由，v0.1.1 缺失时兼容放行", () => {
  let status = null;
  let body = "";
  const res = { writeHead(value) { status = value; }, end(value) { body = String(value); } };
  assert.equal(rejectUnauthorizedRequest({ get: () => ({ requestRejection: () => 401 }) }, {}, res), true);
  assert.equal(status, 401);
  assert.equal(JSON.parse(body).error, "unauthorized");
  assert.equal(rejectUnauthorizedRequest({ get: () => undefined }, {}, res), false);
});

test("清理临时目录", () => {
  rmSync(temp, { recursive: true, force: true });
});
