// 宿主契约验证：inject 声明的服务必须真实存在，且配置读取路径可用
// 背景：曾因注入不存在的 `settingsScope` 服务，插件永远停在
//      "pending (waiting for service: settingsScope)" 而无法激活。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const ASAR = '/Applications/DeepSeek Harness.app/Contents/Resources/app.asar';

let pass = 0, fail = 0;
const check = (n, c, e = '') => { if (c) { pass++; console.log('  ✅ ' + n); } else { fail++; console.log('  ❌ ' + n + '  → ' + e); } };

const src = fs.readFileSync(path.join(ROOT, 'lib', 'client.js'), 'utf8');

console.log('\n=== H1: inject 声明 ===');
const m = src.match(/exports\.inject\s*=\s*\[([^\]]*)\]/);
check('exports.inject 存在', !!m);
const inject = m[1].split(',').map(s => s.trim().replace(/["']/g, '')).filter(Boolean);
console.log('  声明: [' + inject.join(', ') + ']');
check('不再注入 settingsScope', !inject.includes('settingsScope'), inject.join(','));
check('不再注入不存在的服务', inject.every(s => s !== 'settingsScope'));

// 关键回归：可被用户禁用的服务绝不能进 inject。
// configForms 由 @deepseek-ai/dsh-client-ui-settings 提供，用户可在 profile 的
// cordis.patch.yml 里 `enabled: false` 关掉它（本机 desktop profile 就是如此）。
// 一旦注入，缺失时 Cordis 会无限等待 → 插件永久 pending。
console.log('\n=== H1b: 可禁用服务不得进 inject ===');
const PATCH_FILE = '/Users/delinger/.dsh/profiles/desktop/cordis.patch.yml';
if (fs.existsSync(PATCH_FILE)) {
  const patch = fs.readFileSync(PATCH_FILE, 'utf8');
  const disabled = [];
  patch.split('\n').forEach((line, i) => {
    if (/enabled:\s*false/.test(line)) {
      for (let j = i; j >= 0; j--) {
        if (/- id:/.test(patch.split('\n')[j])) { disabled.push(patch.split('\n')[j].trim()); break; }
      }
    }
  });
  console.log('  本机 desktop profile 被禁用的条目: ' + (disabled.length ? disabled.join(', ') : '(无)'));
  const settingsOff = /ui-settings[\s\S]{0,80}enabled:\s*false/.test(patch);
  if (settingsOff) console.log('  ⚠️  检测到 dsh-client-ui-settings 被禁用 → configForms 不可用');
  check('configForms 未被注入（因其可被禁用）', !inject.includes('configForms'),
    'configForms 会因 ui-settings 被禁用而导致 pending');
  check('configForms 改为运行时探测', /ctx\.configForms\s*&&\s*typeof ctx\.configForms\.get/.test(src));
  check('无配置服务时仍渲染（不返回 null）', !/if \(!scope\)\s*return null/.test(src));
} else {
  check('configForms 未被注入', !inject.includes('configForms'));
}

console.log('\n=== H2: 宿主 bundle 中是否存在这些服务 ===');
let asar = '';
if (fs.existsSync(ASAR)) {
  // ⚠️ 用宿主自带的 Node（runtime/bin/node）跑本套件时，Electron 的 asar fs
  // 包装器会拦截 `readFileSync(app.asar)` 并报
  // "ENOENT, not found in app.asar" —— 它把 asar **当成目录**处理。
  // 解法是 ELECTRON_NO_ASAR=1（Electron 官方开关），在 run.mjs 里设。
  // 这里再兜一层：真读不出来就跳过这一节，别让整轮回归红掉。
  try {
    asar = fs.readFileSync(ASAR).toString('latin1');
  } catch (e) {
    console.log('  ⚠️  读不到宿主 asar（' + ((e && e.code) || e) + '）—— 跳过本节。');
    console.log('     若在 Electron Node 下跑，请设 ELECTRON_NO_ASAR=1');
  }
}
if (asar) {
  console.log('  已读取宿主 asar (' + (asar.length / 1048576).toFixed(0) + ' MB)');
  // 宿主里真实出现过的客户端服务名（从 inject 组合里提取）
  const known = new Set();
  const re = /const inject = \[([\s\S]{0,300}?)\];/g;
  let mm;
  while ((mm = re.exec(asar))) {
    mm[1].split(',').map(x => x.trim().replace(/["'`]/g, '')).filter(Boolean).forEach(x => known.add(x));
  }
  console.log('  宿主已知客户端服务 (' + known.size + ' 个，含 ' + [...known].slice(0, 8).join(', ') + ' ...)');
  for (const svc of inject) {
    check('宿主提供服务 "' + svc + '"', known.has(svc), known.has(svc) ? '' : '宿主 inject 组合中未出现');
  }
  check('settingsScope 在宿主中不存在（故不能注入）', !known.has('settingsScope'));
} else {
  console.log('  ⚠️  未找到宿主 asar，跳过（' + ASAR + '）');
}

console.log('\n=== H3: 配置读取路径（configForms）===');
check('优先使用 ctx.configForms.get', /ctx\.configForms\s*&&\s*typeof ctx\.configForms\.get/.test(src));
check('保留 settingsScope 兼容回退', /ctx\.settingsScope\s*&&\s*typeof ctx\.settingsScope\.bind/.test(src));
check('有 normalizeScope 统一形态', /function normalizeScope/.test(src));
check('有 readScopeConfig 安全读取', /function readScopeConfig/.test(src));
// 无配置服务时必须有提示。
//
// ⚠️ 文案别改回「使用默认配置（设置项不持久化）」—— 那是误导：
// 用户会以为自己的设置丢了，而实际上插件已经能自己保存（见
// client.js 的 saveConfig：桥在则落盘、不在则 localStorage）。
// 那句话是「开关点不动」这个 bug 的帮凶之一：用户看不到真实原因。
//
// 岛移除后 apply() 里不再有「未取得配置服务」这句 —— 因为现在没有
// 「降级到默认配置」这回事：设置面板照样工作，物理刘海由 app 读文件。
// 改为断言「不再宣称会降级」。
check('无配置服务时不再宣称「降级到默认配置」',
  !/未取得配置服务/.test(src), '那句过时的降级告警还在');
check('有配置源诊断输出（便于排查）', /配置源: /.test(src));

console.log('\n=== H4: 运行期行为（用真实宿主形态的 ctx 驱动）===');
// 桩 window/document 以便执行 client.js
let captured = null;
globalThis.window = { __ModuleLoader__: { load(cfg) { captured = cfg; } } };
const mkEl = () => ({ id: '', textContent: '', style: {}, children: [], appendChild(c) { this.children.push(c); return c; }, addEventListener() {} });
globalThis.document = { getElementById: () => null, createElement: () => mkEl(), head: mkEl(), body: mkEl() };
new Function(src)();

const reactStub = {
  createElement: (t, p, ...c) => ({ type: t, props: p || {}, children: c.flat().filter(x => x != null && x !== false) }),
  useState: (v) => [v, () => {}], useEffect: () => {}, useMemo: (fn) => fn(),
  useSyncExternalStore: (s, g) => g(),
};
const mod = captured.factory((n) => { if (n === 'react') return reactStub; throw new Error('nf'); });

// 模拟宿主真实 configForms：ctx.configForms.get(ns) → { value, set, watch }
const makeCtx = (getter) => {
  const registered = [];
  return {
    ctx: {
      configForms: { get: getter },
      sessions: { list: { getSnapshot: () => ({ activeId: 's1' }) } },
      slots: { inject: (s, f) => { try { f(); } catch (e) {} }, register: (meta, comp) => { registered.push({ meta, comp }); return meta.id; } },
    },
    registered,
  };
};

const bind = mod.bindConfigScope;
check('bindConfigScope 已导出', typeof bind === 'function');

// 形态 1：{ value, set, watch }（configForms 真实形态）
{
  let store = { enabled: true, placement: 'notch' };
  const { ctx } = makeCtx(() => ({
    get value() { return store; },
    set: (p) => { store = { ...store, ...p }; },
    watch: () => () => {},
  }));
  const scope = bind(ctx);
  check('形态1(configForms value/set/watch) 绑定成功', !!scope);
  check('形态1 getSnapshot 读到值', scope && scope.getSnapshot().placement === 'notch', JSON.stringify(scope && scope.getSnapshot()));
  check('形态1 update 可写', !!(scope && typeof scope.update === 'function'));
  if (scope) { scope.update({ placement: 'floating' }); check('形态1 写入生效', scope.getSnapshot().placement === 'floating', scope.getSnapshot().placement); }
}

// 形态 2：{ getSnapshot, subscribe, update }（快照存储）
{
  let v = { enabled: false };
  const { ctx } = makeCtx(() => ({ getSnapshot: () => v, subscribe: () => () => {}, update: (p) => { v = { ...v, ...p }; } }));
  const scope = bind(ctx);
  check('形态2(快照存储) 绑定成功', !!scope && scope.getSnapshot().enabled === false);
}

// 形态 3：无任何配置服务
{
  const scope = bind({ sessions: {}, slots: {} });
  check('形态3(无配置服务) 返回 null 而非抛错', scope === null);
}

// 形态 4：configForms.get 抛错 → 应回退而非崩
{
  const scope = bind({ configForms: { get: () => { throw new Error('boom'); } }, sessions: {}, slots: {} });
  check('形态4(configForms 抛错) 降级为 null 不崩', scope === null);
}

console.log('\n=== H5: apply() 在真实 configForms 下完整挂载 ===');
{
  let store = { enabled: true, placement: 'notch', platformMode: 'auto', glowEffect: true, expandOnHover: true, showSubagentCount: true, scale: 1.0 };
  const { ctx, registered } = makeCtx(() => ({
    get value() { return store; },
    set: (p) => { store = { ...store, ...p }; },
    watch: () => () => {},
  }));
  let threw = null;
  const warns = [];
  const ow = console.warn; console.warn = (m) => warns.push(String(m));
  try { mod.apply(ctx); } catch (e) { threw = e.message; }
  console.warn = ow;
  check('apply() 未抛异常', threw === null, threw);
  check('未产生「未取得配置服务」告警', !warns.some(w => /未取得配置服务/.test(w)), JSON.stringify(warns));
  check('注册了 2 个 slot', registered.length === 2, 'got ' + registered.length);
}

console.log('\n=== H6: apply() 在无配置服务时仍能工作（不被缺服务阻断）===');
{
  const { ctx, registered } = makeCtx(null);
  delete ctx.configForms;
  let threw = null;
  const warns = [];
  const ow = console.warn; console.warn = (m) => warns.push(String(m));
  try { mod.apply(ctx); } catch (e) { threw = e.message; }
  console.warn = ow;
  check('无配置服务时 apply() 不抛异常', threw === null, threw);
  // 不再要求「降级告警」：岛移除后没有降级路径了 ——
  // 设置面板照样工作（自己存配置），物理刘海由 app 读同一份文件。
  check('无配置服务也不阻断功能（2 个 slot 都注册了）',
    registered.length === 2, 'got ' + registered.length);
  check('没有把「拿不到配置服务」当成错误（不应有相关告警）',
    !warns.some((w) => /未取得配置服务/.test(w)), JSON.stringify(warns));
}

console.log('\n=== H7: 服务端命名空间契约（dsh-settings）===');
const srv = fs.readFileSync(path.join(ROOT, 'lib', 'index.js'), 'utf8');
const nsMatch = srv.match(/const NS = '([^']+)'/);
check('服务端声明 NS', !!nsMatch, '未找到 const NS');
const NS = nsMatch && nsMatch[1];
console.log('  命名空间: ' + NS);
// @deepseek-ai/dsh-settings 要求：小写连字符标识符，重复注册抛错
check('NS 为小写连字符标识符（合法）', /^[a-z][a-z0-9]*(-[a-z0-9]+)*$/.test(NS), NS);
check('服务端 inject 为 [settings]', /export const inject = \['settings'\]/.test(srv), srv.match(/export const inject = \[[^\]]*\]/) && srv.match(/export const inject = \[[^\]]*\]/)[0]);
check('register 调用签名正确 (ns, schema, {base})', /ctx\.settings\.register\(\s*NS,\s*Config,\s*\{\s*base:/.test(srv));
// 2026-06:降级路径改走统一 log()（同时写诊断文件），不再用 console.warn。
// 断言跟着行为走：只要「catch 里有输出」即可，不绑定具体 API。
check('register 失败被 try/catch 捕获', /catch\s*\(error\)[\s\S]{0,200}log\(/.test(srv));
check('降级日志走统一 log()（GUI 启动时 console 用户看不到）',
  !/catch\s*\(error\)[\s\S]{0,200}console\.warn/.test(srv));
check('诊断文件落在应用数据目录', /plugin-diagnose\.log/.test(srv));
// 🔴 ESM 里没有 require。第一版在 apply() 里写 require('node:fs')造日志，
// 抛的 ReferenceError 被外层 catch 吞掉 → logFile 恒为 null →
// **诊断日志永远不生成，而且看不出任何异常**。真踩过。
check('ESM 作用域内不得使用 require()',
  !/[^\w.\$]require\(\s*['"]node:/.test(srv.replace(/\/\/[^\n]*/g, '')),
  (srv.match(/[^\w.\$]require\(\s*['"]node:[^\n]*/) || [])[0] || '');

// 🔴 node:https **不读** HTTPS_PROXY（只有 curl / undici 会）。
// 国内网络与带 MITM 的环境下 github.com 直连不通，插件下载 app 会静默失败。
// 本项目真踩过：诊断日志里只有一句 unable to verify the first certificate。
check('resolveProxy 读取代理设置', /export function resolveProxy/.test(srv));
check('resolveProxy 支持 HTTPS_PROXY/https_proxy/HTTP_PROXY',
  /HTTPS_PROXY/.test(srv) && /https_proxy/.test(srv)
  && /HTTP_PROXY/.test(srv) && /http_proxy/.test(srv));
check('尊重 NO_PROXY（本地 profile 也要能直连）', /NO_PROXY|no_proxy/.test(srv));
check('用 CONNECT 隧道而不是把代理地址当主机', /method: .CONNECT./.test(srv));
check('httpsGet 直连失败才回退代理（代理本身可能不可用）',
  /先直连/.test(srv) && /catch \(directErr\)/.test(srv));
check('两次失败都带进错误信息（要能区分直连失败 / 代理失败）',
  /直连失败（/.test(srv) && /也失败（/.test(srv));
// 🔴 绝不能为了「能下载」去关证书校验 —— 那是把最后一道防线拆掉。
//
// 2026-10-10 收紧口径：原来这里是「全文件不许出现 rejectUnauthorized:false」。
// 但后来加了一处**只读探测**（proxyIssuerName：连上去取对端证书名字就断，
// 不传任何数据），它确实需要临时放宽才能握手成功。于是断言改成表达真正的
// 纪律 —— **放宽只能存在于那个只读函数里，且全局只能有一处**：
if (!/NODE_TLS_REJECT_UNAUTHORIZED/.test(srv)) {
  const codeOnly = srv.split('\n').filter((l) => !/^\s*(\*|\/\/)/.test(l)).join('\n');
  const relaxed = (codeOnly.match(/rejectUnauthorized\s*:\s*false/g) || []).length;
  check('不得为了下载而关闭 TLS 校验（放宽至多一处，且只在只读探测里）',
    relaxed <= 1 && (relaxed === 0 || /proxyIssuerName/.test(srv)),
    '放宽处数=' + relaxed);
} else {
  check('不得为了下载而关闭 TLS 校验（全局开关必须不存在）', false, 'NODE_TLS_REJECT_UNAUTHORIZED 出现了');
}
// 与上一条**并存**才完整：既要严禁「关掉校验」，又要真的能过企业 MITM。
// 做法是把系统钥匙串里被信任的 CA 也纳入信任集合（Node 官方
// `--use-system-ca` 的等价物）—— 证书链照常严格校验，只是信任源变多。
check('读系统钥匙串的根证书（企业 MITM / 抓包环境）',
  /find-certificate/.test(srv) && /SystemRootCertificates\.keychain/.test(srv)
  && /System\.keychain/.test(srv));
check('只在 macOS 上读钥匙串（其它平台不执行 security）',
  /process\.platform === 'darwin'/.test(srv) && /\/usr\/bin\/security/.test(srv));
check('httpsGet 把系统 CA 交给 TLS（不是只信内置 CA）',
  /const trustCA = tlsTrustOptions\(\)/.test(srv) && /opts\.ca = trustCA/.test(srv));
check('系统 CA 有进程内缓存（不每次请求都读钥匙串）',
  /_systemCACache/.test(srv));
// 首次安装必须预写一份**明确**的默认配置。
// 否则文件不存在 → UI 读到空对象 → 那套取反逻辑会写进 notchEnabled:false
// → 用户明明想开岛，反而把岛关掉（本机实测复现两轮，症状与"没装好"一样）。
check('首次安装预写默认配置（防 UI 取反把岛写关）',
  /首次安装：写入默认配置/.test(srv) && /existsSync\(cfgFile\)/.test(srv));
check('预写默认值只在新装时（已有配置不覆盖用户意愿）',
  /if \(!nodeFs\.existsSync\(cfgFile\)\)/.test(srv));
// 这两条都是「证书修好之后才第一次被跑到」的路径 —— 之前 TLS 从没通过，
// 所以下载安装这条线**整条都没被执行过**，藏了两个 bug。
// ① 302：`releases/latest` 必须「不跟随」才能读到 Location。
check('releases/latest 用 followRedirects:false 读 302',
  /followRedirects = true/.test(srv) && /if \(!followRedirects\)/.test(srv)
  && /followRedirects: false/.test(srv));
// ② `fsp` 导的是 node:fs/promises，cp 直接挂模块上；
//    写成 fsp.promises.cp 会取到 undefined。
check('解压落位用 fs/promises 的 cp（不是 fsp.promises.cp）',
  /fsp\.cp\(/.test(srv) && !/fsp\.promises\.cp\(/.test(srv));

// ── 大文件下载的鲁棒性（2026-10-14 真机实测踩出来的）──
//
// 153MB 的安装包在限速直连上爬了 42 分钟后连接僵死：对外 443 全没了，
// 下载的 promise 却永不 settle —— `req.setTimeout` 只管「socket 完全
// 无数据」的窗口，拦不住半死连接；全量缓冲还把宿主堆顶到 +150MB。
// 岛永远不出现、也永远不报错，比直接失败更糟。四条纪律：
check('大文件流式落盘（不整包进内存）',
  /sink = null/.test(srv) && /createWriteStream\(destPath\)/.test(srv) && /sha256File/.test(srv));
check('下载有停滞看门狗与总时限（半死连接必须被掐断）',
  /stallMs/.test(srv) && /budgetMs/.test(srv) && /下载停滞/.test(srv) && /总时限/.test(srv));
check('安装包逐源回退（直连放弃换镜像，摘要源与 zip 源解耦）',
  /downloadAssetWithFallback/.test(srv) && (srv.match(/downloadAssetWithFallback\(/g) || []).length >= 3,
  '出现次数 = ' + (srv.match(/downloadAssetWithFallback\(/g) || []).length);
check('302 跳转不丢自定义参数（大下载跳 CDN 时刹车必须还在）',
  /sink, stallMs, budgetMs, minBps,/.test(srv));
check('每个源下完独立核 SHA256', /SHA256 不符/.test(srv));
check('两轮择速：速率底线让慢源早让位，兜底轮不限速（慢的也要）',
  /minBps/.test(srv) && /择速/.test(srv) && /兜底轮/.test(srv) && /低于底线/.test(srv));
check('拷贝/清理关闭 Electron asar 拦截（.asar 目标路径会被当压缩包解析，只在 Electron 宿主里复现）',
  /withNoAsar/.test(srv) && /process\.noAsar = true/.test(srv)
  && /withNoAsar\(\(\) =>\s*\n?\s*fsp\.cp/.test(srv));
check('staged 落位：拷暂存→验完整→原子换入（目标永不半写）',
  /placeWindowsStaged/.test(srv) && /renameSync\(staged, target\)/.test(srv));
check('诊断日志用顶层静态 import 的 fs/path',
  /import fsSync from 'node:fs'/.test(srv) && /import pathSync from 'node:path'/.test(srv));
check('settings 服务缺失时也有告警', /settings 服务不可用/.test(srv));
// 客户端与服务端 NS 必须一致
const cliNs = (src.match(/const NS = "([^"]+)"/) || [])[1];
check('客户端 NS 与服务端一致', cliNs === NS, cliNs + ' vs ' + NS);
// 客户端 configForms.get 也用同一 NS
check('configForms.get 使用同一 NS', new RegExp('configForms\\.get\\(NS\\)').test(src));

// ── peerDependencies 的写法直接决定「插件管理器里能不能装上」 ──
//
// 实测（Windows 11 + DSH 0.2.0-rc.2，2026-10-10）：peerDeps 全写 `*` 时，
// `pnpm add git+https://.../dsh-deepisland.git` 直接失败：
//   [ERR_PNPM_FETCH_404] @deepseek-ai/dsh-compact: Not Found
//
// 原因：`@deepseek-ai/*` 这些包的 npm `latest` 标签停在远古版本
// （dsh-settings 的 latest = 0.0.1-rc.1，DSH 实际用的是 0.2.0-rc.2），
// 而那个远古版本的依赖树里引用了 `dsh-compact` —— 这个包从未发布到公共
// registry，于是整棵解析树 404。`*` 让 pnpm 跟着 latest 走 → 装到远古版 → 404。
// 钉死精确版本后 404 消失（已实测）。
//
// 之所以要加断言：这个失败**完全不报错在插件这一侧**，只表现为
// 「插件管理器里报错」，很容易被当成网络/代理问题去查，方向从一开始就错。
console.log('\n=== peerDependencies 写法（决定能不能被插件管理器装上）===');
{
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const peers = pkg.peerDependencies || {};
  const names = Object.keys(peers);
  const deep = names.filter((n) => n.startsWith('@deepseek-ai/'));

  // 参照物：本机 desktop profile 里界面装的 dsh-our-free-model —— 它能正常加载，
  // 声明方式是 ^4.0.2 / ^0.1.2-rc.1 || ^0.1.7-rc.2 || ^0.2.0-rc.1（多版本 or）。
  // 照它的样子写，别自创写法。
  const wildcards = deep.filter((n) => peers[n] === '*' || peers[n] === '' || peers[n] === 'x');
  check('peerDependencies 里没有裸 *（会跟 latest 装到远古版 → dsh-compact 404）',
    wildcards.length === 0, wildcards.join(', '));

  const ws = deep.filter((n) => peers[n].startsWith('workspace:'));
  check('不用 workspace: 协议（profile 若无 workspace 定义，pnpm 不解析，链接链断）',
    ws.length === 0, ws.join(', '));

  const pinned = deep.filter((n) => /^\d/.test(peers[n]));
  check('@deepseek-ai/* 不用裸精确版本（宿主版本升一个小版本就整bundle 被跳过）',
    pinned.length === 0, pinned.map((n) => n + '=' + peers[n]).join(', '));

  const ors = deep.filter((n) => peers[n].includes('||'));
  check('rc 包用多版本 or（照 dsh-our-free-model 的写法，容纳 rc 演进）',
    ors.length >= 3, ors.length + ' 个用了 ||');

  check('dsh-client-ui-* 覆盖 0.2.0-rc.2（当前 DSH 版本）',
    ['@deepseek-ai/dsh-client-ui-primitives', '@deepseek-ai/dsh-client-ui-settings',
     '@deepseek-ai/dsh-client-ui-slots'].every((n) => peers[n].includes('0.2.0-rc.2')),
    String(peers['@deepseek-ai/dsh-client-ui-settings']));
  check('schemastery 用 ^3.18.4（公共 registry 的 latest 就是它）',
    peers['@deepseek-ai/schemastery'] === '^3.18.4',
    String(peers['@deepseek-ai/schemastery']));
}

console.log('\n' + '='.repeat(50));
console.log('宿主契约验证: 通过 ' + pass + ' / 失败 ' + fail);
console.log('='.repeat(50));
globalThis.__results = globalThis.__results || {};
globalThis.__results.contract = { pass, fail };
