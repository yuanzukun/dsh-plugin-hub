import { readFileSync } from 'node:fs'
import { Tokenizer } from 'tokenizers'

const json = readFileSync('F:/deepSeek/.models/kompress-v2-base/tokenizer.json', 'utf8')
const tokenizer = await Tokenizer.fromString(json)
const text = 'The build FAILED with status 500 at /usr/lib/python3.so checking 0x7fff2038'
const enc = tokenizer.encode(text, true)
console.log('ids len:', enc.ids.length)
console.log('tokens:', enc.tokens.slice(0, 16).join('|'))
console.log('attention:', enc.attentionMask.slice(0, 10).join(','))
console.log('offsets?', Array.isArray(enc.offsets) ? JSON.stringify(enc.offsets.slice(0, 6)) : 'n/a')
console.log('encodeBatch:', typeof tokenizer.encodeBatch)
const words = ['The', 'build', 'FAILED', '500', '/usr/lib/python3.so']
const batch = tokenizer.encodeBatch(words.map((w) => [w]), false)
console.log('batch lens:', batch.map((e) => e.ids.length).join(','))
console.log('batch toks[3]:', batch[3].tokens.join('|'))
console.log('PROBE OK')