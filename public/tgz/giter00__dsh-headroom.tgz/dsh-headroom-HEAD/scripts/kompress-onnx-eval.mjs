/**
 * Kompress-v2-base ONNX integration evaluation for dsh-headroom.
 *
 * Covers:
 *   1. quality   — compression ratio + key-fact retention, heuristic vs ONNX
 *   2. efficiency— words/sec and end-to-end latency per corpus/backend
 *   3. LLM-impact— QA-fact survival through compression (answerability)
 *   4. recursion — repeated/idempotent compression stability
 *
 * Usage: node scripts/kompress-onnx-eval.mjs
 */
import { performance } from 'node:perf_hooks'
import {
  DEFAULT_LIMITS,
  compressContentBlocks,
  compressContentBlocksAsync,
  resolveLimits
} from '../lib/compress.js'
import { createOnnxScorer } from '../lib/kompress-onnx.js'

const MODEL_DIR = process.env.KOMPRESS_MODEL_DIR ?? 'F:/deepSeek/.models/kompress-v2-base'
const HF_DIR = process.env.KOMPRESS_HF_DIR ?? 'F:/deepSeek/.models/hf'
const ROUNDS = 3

// ── corpora ────────────────────────────────────────────────────────────────
const logCorpus = Array.from({ length: 60 }, (_, i) => {
  if (i % 12 === 0) return `2026-08-24T01:${String(i).padStart(2, '0')}:11Z ERROR api-gateway upstream timeout request_id=0x${(0x7f000000 + i).toString(16)} path=/v1/users/${i} retry_after=3.5s`
  if (i % 7 === 0) return `INFO  worker-${i} processed batch size=128 elapsed=42ms checksum=a3f${i.toString(16)}`
  return `DEBUG handler route=/api/items/${i} cache_hit=${i % 3 === 0} duration_ms=${10 + i}`
}).join('\n')

const proseEn = [
  'The migration plan ships in version 3.14 and requires PostgreSQL 16 or newer.',
  'A rollback is possible until 2026-09-01 by running scripts/rollback-v2.sh with the --dry-run flag first.',
  'The build failed with status 500 at /usr/lib/python3.so because of an IndexError inside libsystem_kernel.dylib.',
  'Engineers should pin dependency @deepseek-ai/cordis to 4.0.1-rc.4 and set NODE_OPTIONS=--max-old-space-size=4096.',
  'Latency dropped from 820ms to 140ms after enabling the connection pool at pool_size=32.'
].join(' ').repeat(6)

const proseMixed = [
  '部署计划：版本 3.14 需要 PostgreSQL 16，回滚脚本位于 scripts/rollback-v2.sh。',
  '构建在 /usr/lib/python3.so 失败（状态码 500），错误类型 IndexError 出自 libsystem_kernel.dylib。',
  '延迟从 820ms 降到 140ms，连接池大小 pool_size=32，重试次数 retry=3。',
  '依赖锁定 @deepseek-ai/cordis 4.0.1-rc.4，内存参数 NODE_OPTIONS=--max-old-space-size=4096。'
].join(' ').repeat(8)

const qaDoc = [
  'Incident report INC-2291: the payment service failed at 03:14 UTC with exit code 137.',
  'The root cause was a memory limit of 512MB exceeded by worker pid=0x9f3a.',
  'Mitigation: scale replicas from 4 to 12 and raise the limit to 2048MB.',
  'The fix landed in commit 7c15ab3 and shipped in release v2.9.0.',
  'Dashboard: https://grafana.internal/d/payments?from=1700000000'
].join(' ')

const corpora = [
  { name: 'log-fold-target', text: logCorpus, facts: ['ERROR', '500', '/v1/users/', '0x7f'] },
  { name: 'prose-en', text: proseEn, facts: ['3.14', 'PostgreSQL', 'rollback-v2.sh', '--dry-run', 'IndexError', 'libsystem_kernel.dylib', '4.0.1-rc.4', '820ms', '140ms'] },
  { name: 'prose-mixed-cjk', text: proseMixed, facts: ['3.14', 'PostgreSQL', 'scripts/rollback-v2.sh', '/usr/lib/python3.so', 'IndexError', '820ms', '140ms', 'pool_size=32', '@deepseek-ai/cordis'] },
  { name: 'qa-doc', text: qaDoc, facts: ['INC-2291', '03:14', '137', '512MB', '0x9f3a', '2048MB', '7c15ab3', 'v2.9.0'] }
]

// ── helpers ────────────────────────────────────────────────────────────────
const pct = (a, b) => b > 0 ? Math.round((1 - a / b) * 1000) / 10 : 0
const jaccard = (a, b) => {
  const sa = new Set(a.split(/\s+/))
  const sb = new Set(b.split(/\s+/))
  let inter = 0
  for (const w of sa) if (sb.has(w)) inter += 1
  return sa.size + sb.size - inter === 0 ? 1 : Math.round(inter / (sa.size + sb.size - inter) * 1000) / 10
}
const factRetention = (compressed, facts) =>
  `${facts.filter((f) => compressed.includes(f)).length}/${facts.length}`

function kompressLimits(scorer) {
  return resolveLimits({
    ...DEFAULT_LIMITS,
    textStrategy: 'kompress',
    minChars: 80,
    // Mirror the plugin's auto-calibration: the exported model scores high,
    // so top-k keep-ratio is required for meaningful compression.
    kompress: { ...(scorer ? { scorer, targetRatio: 0.55 } : {}) }
  })
}

async function main() {
  console.log('loading Kompress-v2-base ONNX …')
  const tLoad0 = performance.now()
  const built = await createOnnxScorer({
    modelDir: MODEL_DIR,
    hfLocalDir: HF_DIR,
    modelFile: 'onnx_kompress-int8-wo.onnx'
  })
  if (!built.ok) {
    console.error('ONNX INIT FAILED:', built.error)
    process.exit(1)
  }
  console.log(`loaded in ${Math.round(performance.now() - tLoad0)}ms (${built.info.modelFile})\n`)

  const heurLimits = kompressLimits(null)
  const onnxLimits = kompressLimits(built.scorer)

  // ── 1+2. quality & efficiency ──────────────────────────────────────────
  console.log('=== 1) QUALITY (ratio ↑ better, facts kept x/y, overlap = word Jaccard vs heuristic) ===')
  console.log('corpus'.padEnd(18), '| orig→heu | ratio | facts | || orig→onx | ratio | facts | overlap')
  const results = []
  for (const { name, text, facts } of corpora) {
    const h = compressContentBlocks([{ type: 'text', text }], { limits: heurLimits })
    const o = await compressContentBlocksAsync([{ type: 'text', text }], { limits: onnxLimits })
    const hOut = h.blocks[0].text
    const oOut = o.blocks[0].text
    results.push({ name, text, hOut, oOut, facts })
    console.log(
      name.padEnd(18),
      `| ${text.length}→${hOut.length} | ${pct(hOut.length, text.length)}% | ${factRetention(hOut, facts).padEnd(5)}`,
      `|| ${text.length}→${oOut.length} | ${pct(oOut.length, text.length)}% | ${factRetention(oOut, facts).padEnd(5)} | ${jaccard(hOut, oOut)}`
    )
  }

  console.log('\n=== 2) EFFICIENCY (end-to-end ms over full corpus, avg of 3; words/sec) ===')
  for (const { name, text } of corpora) {
    const words = text.split(/\s+/).length
    // warmup
    compressContentBlocks([{ type: 'text', text }], { limits: heurLimits })
    await compressContentBlocksAsync([{ type: 'text', text }], { limits: onnxLimits })
    let hMs = 0
    let oMs = 0
    for (let r = 0; r < ROUNDS; r += 1) {
      let t0 = performance.now()
      compressContentBlocks([{ type: 'text', text }], { limits: heurLimits })
      hMs += performance.now() - t0
      t0 = performance.now()
      await compressContentBlocksAsync([{ type: 'text', text }], { limits: onnxLimits })
      oMs += performance.now() - t0
    }
    const hAvg = (hMs / ROUNDS).toFixed(1)
    const oAvg = (oMs / ROUNDS).toFixed(1)
    console.log(
      name.padEnd(18),
      `words=${String(words).padStart(6)}`,
      `| heuristic ${hAvg.padStart(8)}ms (${Math.round(words / (hMs / ROUNDS / 1000))} w/s)`,
      `| onnx-int8 ${oAvg.padStart(8)}ms (${Math.round(words / (oMs / ROUNDS / 1000))} w/s)`
    )
  }

  // ── 3. LLM-impact: QA answerability through compression ───────────────
  console.log('\n=== 3) LLM IMPACT — QA facts surviving compression (qa-doc) ===')
  const qa = results.find((r) => r.name === 'qa-doc')
  const questions = [
    ['When did the payment service fail?', ['03:14']],
    ['What was the exit code?', ['137']],
    ['What was the memory limit that got exceeded?', ['512MB']],
    ['Which commit fixed it?', ['7c15ab3']],
    ['Which release shipped the fix?', ['v2.9.0']]
  ]
  for (const [backend, out] of [['heuristic', qa.hOut], ['onnx', qa.oOut]]) {
    const verdicts = questions.map(([q, keys]) => {
      const ok = keys.every((k) => out.includes(k))
      return `${ok ? 'PASS' : 'FAIL'}(${keys.filter((k) => !out.includes(k)).join(',') || '-'})`
    }).join(' ')
    console.log(`${backend.padEnd(10)} chars=${out.length} ${verdicts}`)
  }
  console.log('\n--- onnx-compressed qa-doc (for manual review) ---')
  console.log(qa.oOut.slice(0, 900))

  // ── 4. recursion / idempotency stability ──────────────────────────────
  console.log('\n=== 4) RECURSION STABILITY (5 rounds re-compression, both backends) ===')
  for (const [label, limits] of [['heuristic', heurLimits], ['onnx', onnxLimits]]) {
    let current = proseEn
    const sizes = []
    let crashed = false
    try {
      for (let round = 0; round < 5; round += 1) {
        const out = typeof limits.kompress.scorer === 'function'
          ? await compressContentBlocksAsync([{ type: 'text', text: current }], { limits })
          : compressContentBlocks([{ type: 'text', text: current }], { limits })
        current = out.changed ? out.blocks[0].text : current
        sizes.push(current.length)
        if (!Number.isFinite(current.length) || current.length === 0) throw new Error('empty output')
      }
    } catch (err) {
      crashed = true
      console.log(`${label}: CRASH ${err.message}`)
    }
    if (!crashed) {
      // Ratio-mode re-compression converges geometrically toward the
      // must-keep/high-score core (like re-saving a JPEG). Require: strictly
      // non-growing after round 2, and a <2% delta in the last step.
      const nonGrowing = sizes[2] <= sizes[1] && sizes[3] <= sizes[2] && sizes[4] <= sizes[3]
      const settled = Math.abs(sizes[4] - sizes[3]) <= Math.max(32, sizes[3] * 0.02)
      console.log(`${label.padEnd(10)} sizes: ${sizes.join(' → ')} ${nonGrowing && settled ? 'CONVERGED ✓' : 'DIVERGING ✗'}`)
    }
  }

  // Marker-guard check: block containing the retrieval hint must never be re-stashed.
  const guarded = 'retrieve full original with headroom_retrieve '.repeat(200)
  const g1 = compressContentBlocks([{ type: 'text', text: guarded }], { limits: heurLimits })
  const g2 = await compressContentBlocksAsync([{ type: 'text', text: guarded }], { limits: onnxLimits })
  console.log(`marker-guard: heuristic changed=${g1.changed} onnx changed=${g2.changed} (expect false/false)`)

  console.log('\nEVAL DONE')
}

main().catch((err) => {
  console.error('EVAL CRASHED:', err)
  process.exit(1)
})
