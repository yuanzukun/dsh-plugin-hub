import { InferenceSession, Tensor } from 'onnxruntime-node'

const MODEL = process.env.KOMPRESS_MODEL ?? 'F:/deepSeek/.models/kompress-v2-base/onnx_kompress-int8-wo.onnx'
const session = await InferenceSession.create(MODEL, { graphOptimizationLevel: 'all' })
console.log('inputNames:', JSON.stringify(session.inputNames))
console.log('outputNames:', JSON.stringify(session.outputNames))

const seqLen = 16
const feeds = {}
for (const name of session.inputNames) {
  const data = new BigInt64Array(seqLen).fill(1n)
  feeds[name] = new Tensor('int64', data, [1, seqLen])
}
const outputs = await session.run(feeds)
for (const [name, tensor] of Object.entries(outputs)) {
  console.log('output', name, '| type:', tensor.type, '| dims:', JSON.stringify(tensor.dims), '| sample[0..3]:', Array.from(tensor.data.slice(0, 4)).map(Number))
}
console.log('PROBE OK')