import { performance } from 'node:perf_hooks'
import { createOnnxScorer } from '../lib/kompress-onnx.js'

const built = await createOnnxScorer({
  modelDir: 'F:/deepSeek/.models/kompress-v2-base',
  hfLocalDir: 'F:/deepSeek/.models/hf'
})
if (!built.ok) {
  console.log('INIT FAIL:', built.error)
  process.exit(1)
}
console.log('info:', JSON.stringify(built.info))

const words = ['The', 'build', 'FAILED', 'with', 'status', '500', 'at', '/usr/lib/python3.so', '.',
  'checking', '0x7fff2038', 'and', 'IndexError', '--verbose', 'flag']
await built.scorer(words, { start: 0 }) // warmup
const t0 = performance.now()
const scores = await built.scorer(words, { start: 0 })
const ms = (performance.now() - t0).toFixed(1)
words.forEach((w, i) => console.log(w.padEnd(24), scores[i].toFixed(3)))
console.log('latency(ms):', ms)