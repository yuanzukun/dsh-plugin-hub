/**
 * Tests for the real Kompress-v2-base ONNX scorer integration.
 *
 * Model-dependent cases are skipped automatically when the local model files
 * are absent (CI / fresh clones): set KOMPRESS_MODEL_DIR / KOMPRESS_HF_DIR or
 * download the model to F:/deepSeek/.models per README.
 *
 * Run: node tests/kompress-onnx.test.js
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'

import { compressKompressTextAsync } from '../lib/kompress.js'
import { compressTextBlockAsync, resolveLimits } from '../lib/compress.js'
import { createOnnxScorer } from '../lib/kompress-onnx.js'
import { normalizeConfig } from '../lib/index.js'

const MODEL_DIR = process.env.KOMPRESS_MODEL_DIR ?? 'F:/deepSeek/.models/kompress-v2-base'
const HF_DIR = process.env.KOMPRESS_HF_DIR ?? 'F:/deepSeek/.models/hf'
const modelAvailable = existsSync(`${MODEL_DIR}/onnx_kompress-int8-wo.onnx`)
  && existsSync(`${HF_DIR}/kompress-v2-base/tokenizer.json`)

const SAMPLE = [
  'The migration ships in version 3.14 and needs PostgreSQL 16.',
  'Rollback via scripts/rollback-v2.sh --dry-run before 2026-09-01.',
  'Build failed status 500 at /usr/lib/python3.so IndexError libsystem_kernel.dylib.',
  'Pin @deepseek-ai/cordis 4.0.1-rc.4 latency fell 820ms to 140ms pool_size=32.'
].join(' ').repeat(6)

test('normalizeConfig validates kompress.scorer/onnx passthrough', () => {
  const cfg = normalizeConfig({ kompress: { scorer: 'onnx', onnx: { modelDir: 'X', maxLength: 4096 } } })
  assert.equal(cfg.kompress.scorer, 'onnx')
  assert.equal(cfg.kompress.onnx.modelDir, 'X')
  assert.equal(cfg.kompress.onnx.maxLength, 4096)
  const def = normalizeConfig({})
  assert.equal(def.kompress.scorer, 'heuristic')
  assert.deepEqual(def.kompress.onnx, {})
})

test('createOnnxScorer reports graceful failure without config', async () => {
  const built = await createOnnxScorer({})
  assert.equal(built.ok, false)
  assert.match(built.error, /modelDir/)
})

test('createOnnxScorer reports graceful failure with missing dirs', async () => {
  // Use a distinct model name: transformers.js negative-caches failed config
  // lookups per model name, and we must not poison the real model's entry.
  const built = await createOnnxScorer({ modelDir: 'Z:/nope', hfLocalDir: 'Z:/nope2', modelName: 'missing-model-test' })
  assert.equal(built.ok, false)
})

test('compressKompressTextAsync falls back to heuristic when scorer throws', async () => {
  const limits = resolveLimits({
    textStrategy: 'kompress',
    minChars: 80,
    kompress: {
      scorer: async () => { throw new Error('boom') },
      targetRatio: 0.55
    }
  })
  const out = await compressKompressTextAsync(SAMPLE, { ...limits.kompress })
  // Heuristic fallback still produces a valid compression.
  assert.ok(out === null || (typeof out === 'string' && out.length > 0 && out.length < SAMPLE.length))
})

test('compressTextBlockAsync honors minChars guard', async () => {
  const out = await compressTextBlockAsync('short text', { limits: resolveLimits({ minChars: 4000 }) })
  assert.equal(out.changed, false)
})

test('marker guard blocks re-compression of retrieval hints (async path)', async () => {
  const guarded = 'retrieve full original with headroom_retrieve '.repeat(200)
  const out = await compressTextBlockAsync(guarded, { limits: resolveLimits({ minChars: 80 }) })
  assert.equal(out.changed, false)
})

test('async pipeline mirrors sync pipeline shape on heuristic scorer', async () => {
  const { compressContentBlocks, compressContentBlocksAsync } = await import('../lib/compress.js')
  const limits = resolveLimits({ textStrategy: 'kompress', minChars: 80 })
  const syncOut = compressContentBlocks([{ type: 'text', text: SAMPLE }], { limits })
  const asyncOut = await compressContentBlocksAsync([{ type: 'text', text: SAMPLE }], { limits })
  assert.equal(syncOut.changed, asyncOut.changed)
  assert.equal(syncOut.strategy, asyncOut.strategy)
  assert.equal(syncOut.blocks[0].text, asyncOut.blocks[0].text)
})

if (modelAvailable) {
  test('ONNX scorer produces sane contextual scores', async () => {
    const built = await createOnnxScorer({ modelDir: MODEL_DIR, hfLocalDir: HF_DIR })
    assert.equal(built.ok, true, `scorer init failed: ${built.error ?? ''}`)
    const words = ['The', 'build', 'FAILED', 'with', 'status', '500', '/usr/lib/python3.so']
    const scores = await built.scorer(words, { start: 0, freq: new Map() })
    assert.equal(scores.length, words.length)
    for (const s of scores) {
      assert.ok(Number.isFinite(s) && s >= 0 && s <= 1, `score in [0,1], got ${s}`)
    }
    // Facts must not be scored below generic filler by wide margins.
    assert.ok(scores[6] > 0.5, `path token scored ${scores[6]}`)
  })

  test('ONNX end-to-end: ratio compression with fact retention', async () => {
    const built = await createOnnxScorer({ modelDir: MODEL_DIR, hfLocalDir: HF_DIR })
    assert.equal(built.ok, true)
    const limits = resolveLimits({
      textStrategy: 'kompress',
      minChars: 80,
      kompress: { scorer: built.scorer, targetRatio: 0.55 }
    })
    const out = await compressKompressTextAsync(SAMPLE, { ...limits.kompress })
    assert.ok(out !== null)
    assert.ok(out.length < SAMPLE.length * 0.85, `expected meaningful shrink, got ${out.length}/${SAMPLE.length}`)
    for (const fact of ['3.14', 'PostgreSQL', 'rollback-v2.sh', 'IndexError', '4.0.1-rc.4']) {
      assert.ok(out.includes(fact), `fact "${fact}" must survive`)
    }
  })

  test('ONNX repeated compression converges (bounded, never empties)', async () => {
    const built = await createOnnxScorer({ modelDir: MODEL_DIR, hfLocalDir: HF_DIR })
    const limits = resolveLimits({
      textStrategy: 'kompress',
      minChars: 80,
      kompress: { scorer: built.scorer, targetRatio: 0.55 }
    })
    let current = SAMPLE
    const sizes = []
    for (let round = 0; round < 5; round += 1) {
      const out = await compressKompressTextAsync(current, { ...limits.kompress })
      if (out === null) break
      current = out
      sizes.push(current.length)
    }
    assert.ok(sizes.length >= 2)
    assert.ok(sizes[sizes.length - 1] > 0, 'never collapses to empty')
    for (let i = 1; i < sizes.length; i += 1) {
      assert.ok(sizes[i] <= sizes[i - 1], 'monotonic non-growing under re-compression')
    }
  })
} else {
  test('ONNX model not present locally — skipping model-dependent cases', { skip: true }, () => {})
}
