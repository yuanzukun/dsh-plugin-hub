/**
 * Idempotent install of the dsh-desktop-windowos exe plus desktop shortcut.
 * @module dsh-desktop-plugin/installer
 */

import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import * as fs from 'node:fs'
import * as net from 'node:net'
import * as os from 'node:os'
import * as path from 'node:path'
import type { ResolvedConfig } from './config.js'

/** Only http(s) URLs are accepted for proxies/mirror prefixes — anything else
 *  (notably values starting with `-`) would flow into spawn args as curl
 *  options instead of arguments. */
function isHttpUrl(value: string): boolean {
  return /^https?:\/\//i.test(value)
}

/** Strip path-separator and traversal characters from user-settable file
 *  names (shortcut names) so they can never escape their target directory. */
function safeFileName(name: string): string {
  const cleaned = name.replace(/[\\/:*?"<>|]/g, '_').replace(/\.{2,}/g, '_').trim()
  return cleaned === '' ? 'shortcut' : cleaned
}

/** Refuse to write outside `baseDir` — defense against config-derived
 *  traversal (installDir/shortcut names) reaching writeFile. */
function ensureWithin(baseDir: string, target: string): string {
  const resolvedBase = path.resolve(baseDir)
  const resolved = path.resolve(target)
  if (resolved !== resolvedBase && !resolved.startsWith(resolvedBase + path.sep)) {
    throw new Error(`refusing to write outside ${resolvedBase}: ${resolved}`)
  }
  return resolved
}

/** Public GitHub asset mirrors (prefix + asset URL), last-resort tier for
 *  proxy-less networks; every transfer through them is verified against the
 *  API's own size/digest metadata by the caller. */
const ASSET_MIRRORS = ['https://ghproxy.com/', 'https://gh-proxy.com/', 'https://ghfast.top/']

/** Local proxy ports worth probing (Clash/v2rayN coverage; 7897 included —
 *  a real-world case where 7890/7891 both missed). */
const LOCAL_PROXY_PORTS = ['7890', '7891', '7897', '7898', '10808', '10809']

/** One download route: direct, through a proxy, or through a mirror prefix. */
export type DownloadRoute = { kind: 'direct' } | { kind: 'proxy', url: string } | { kind: 'mirror', prefix: string }

/** Environment proxies for the route chain, in standard precedence order.
 *  Non-http(s) values are dropped — they must never reach spawn args. */
export function envProxies(): string[] {
  const list: string[] = []
  for (const key of ['HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'all_proxy'] as const) {
    const value = process.env[key]
    if (value !== undefined && value !== '' && isHttpUrl(value) && !list.includes(value)) list.push(value)
  }
  return list
}

/** The ordered chain: direct (overseas) → env proxies → probed local ports
 *  (proxied users) → public mirrors (proxy-less blocked networks). */
export async function downloadRoutes(): Promise<DownloadRoute[]> {
  const routes: DownloadRoute[] = [{ kind: 'direct' }]
  for (const url of envProxies()) routes.push({ kind: 'proxy', url })
  const alive = await Promise.all(LOCAL_PROXY_PORTS.map(async port => {
    const url = `http://127.0.0.1:${port}`
    return await proxyAlive(url) ? url : null
  }))
  for (const url of alive) {
    if (url !== null && !envProxies().includes(url)) routes.push({ kind: 'proxy', url })
  }
  for (const prefix of ASSET_MIRRORS) routes.push({ kind: 'mirror', prefix })
  return routes
}

/** Build the URL one route actually fetches. */
export function routeUrl(route: DownloadRoute, url: string): string {
  return route.kind === 'mirror' ? `${route.prefix}${url}` : url
}

/** Size (+optional sha256 digest) verification for downloaded assets —
 *  what makes mirror transfers trustworthy. */
export function verifyBytes(bytes: Buffer, size: number, digest?: string): boolean {
  if (Number.isFinite(size) && bytes.length !== size) return false
  if (digest === undefined) return true
  const hex = digest.replace(/^sha256:/, '')
  if (hex === digest) return true // unknown algorithm: size-only contract
  const got = createHash('sha256').update(bytes).digest('hex')
  return got.toLowerCase() === hex.toLowerCase()
}

/** Fakeable host boundary; every effect the installer can take. */
export interface InstallerDeps {
  readFile(path: string): string
  exists(path: string): boolean
  mkdir(dir: string): void
  writeFile(path: string, data: Buffer): void
  /** Resolve the user's real desktop directory (OneDrive-redirection safe). */
  desktopDir(): Promise<string>
  /** Fetch a URL's body as JSON text (GitHub API). */
  fetchText(url: string): Promise<string>
  /** Fetch a URL's body as bytes (release asset); walks the direct/proxy/
   *  mirror route chain and discards transfers failing `verify`. */
  fetchBytes(url: string, signal?: AbortSignal, verify?: (bytes: Buffer) => boolean): Promise<Buffer>
  /** Create/refresh a desktop .lnk pointing at the exe. */
  createShortcut(exePath: string, workDir: string, name: string): Promise<void>
  /** Read an exe's embedded product version, '' when unreadable. */
  readExeVersion(path: string): Promise<string>
  /** Rename/move a file (works on a running exe on Windows). */
  rename(from: string, to: string): void
  /** Best-effort delete; missing files are fine. */
  removeFile(path: string): void
}

/** Outcome of one ensureInstalled run. */
export interface InstallResult {
  exePath: string
  /** The exe was missing and has just been downloaded. */
  downloaded: boolean
  /** The desktop shortcut was created/refreshed. */
  shortcut: boolean
}

/** Outcome of one ensureUpdated run. */
export interface UpdateResult {
  exePath: string
  /** The exe was replaced with a newer release. */
  updated: boolean
  fromVersion: string
  toVersion: string
}

/** Outcome of one ensureWebShortcut run. */
export interface WebShortcutResult {
  /** Absolute path of the .url file; empty when creation is disabled. */
  path: string
  /** The web shortcut was created/refreshed. */
  created: boolean
}

/** Absolute path of the desktop exe under the configured install dir. */
export function exePathOf(config: ResolvedConfig): string {
  return `${config.installDir}\\dsh-desktop-windowos.exe`
}

/** Prefix a release-asset URL with the configured mirror when present.
 *  Only http(s) prefixes are honored — a crafted `assetProxy` (e.g. starting
 *  with `-`) must never reach spawn args or change the effective URL. */
export function resolveAssetUrl(config: ResolvedConfig, url: string): string {
  return config.assetProxy !== '' && isHttpUrl(config.assetProxy)
    ? `${config.assetProxy}${url}`
    : url
}

/**
 * Pick the desktop exe asset (download URL + version) from a GitHub release
 * JSON body. The version comes from the `dsh-desktop-windowos-v<semver>.exe`
 * asset name; entries without a parseable version report ''.
 */
export function pickExeAsset(body: string): { url: string, version: string } {
  const meta = pickExeAssetMeta(body)
  return { url: meta.url, version: meta.version }
}

/** Same as pickExeAsset but also carries the API's size/digest metadata,
 *  which powers integrity verification for proxied and mirrored downloads. */
export function pickExeAssetMeta(body: string): { url: string, version: string, size: number, digest?: string } {
  const release = JSON.parse(body) as {
    assets?: Array<{ name: string, browser_download_url: string, size?: number, digest?: string }>
  }
  const asset = release.assets?.find(candidate => candidate.name.endsWith('.exe'))
  if (asset === undefined) throw new Error('latest release has no .exe asset')
  const version = /^dsh-desktop-windowos-v(\d+(?:\.\d+)*)\.exe$/.exec(asset.name)?.[1] ?? ''
  return {
    url: asset.browser_download_url,
    version,
    size: asset.size ?? Number.NaN,
    digest: asset.digest,
  }
}

/** Dot-numeric compare: negative when a<b, 0 when equal, positive when a>b. */
export function compareVersions(a: string, b: string): number {
  const pa = a.split('.').map(Number)
  const pb = b.split('.').map(Number)
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0)
    if (d !== 0) return d
  }
  return 0
}

/** 1s TCP probe so dead proxy ports don't burn curl timeouts. */
function proxyAlive(proxy: string): Promise<boolean> {
  return new Promise(resolve => {
    const authority = proxy.replace(/^https?:\/\//, '').replace(/\/$/, '')
    const idx = authority.lastIndexOf(':')
    if (idx === -1) { resolve(false); return }
    const port = Number(authority.slice(idx + 1))
    if (!Number.isInteger(port) || port <= 0) { resolve(false); return }
    const socket = net.connect({ host: authority.slice(0, idx), port })
    const settle = (ok: boolean) => { socket.destroy(); resolve(ok) }
    socket.setTimeout(1000, () => settle(false))
    socket.once('connect', () => settle(true))
    socket.once('error', () => settle(false))
  })
}

/** One curl run for a route (proxy adds -x, mirror fetches prefix+url).
 *  Aborting `signal` kills the curl child so job cancellation stays prompt.
 *  The final URL must be http(s) — leading `-` would parse as an option. */
function curlRoute(route: DownloadRoute, url: string, tmp: string, signal?: AbortSignal): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const finalUrl = routeUrl(route, url)
    if (!isHttpUrl(finalUrl)) {
      reject(new Error(`refusing non-http(s) download URL: ${finalUrl}`))
      return
    }
    const args = [
      '--silent', '--show-error', '--location', '--fail', '--retry', '1',
      '--connect-timeout', '8', '--speed-time', '30', '--speed-limit', '1024', '--max-time', '120',
      '--user-agent', 'dsh-desktop-plugin', '--output', tmp, finalUrl,
    ]
    if (route.kind === 'proxy') args.push('-x', route.url)
    const child = spawn('curl', args, { stdio: 'ignore', windowsHide: true })
    const onAbort = () => { child.kill() }
    if (signal !== undefined && !signal.aborted) signal.addEventListener('abort', onAbort, { once: true })
    child.on('error', error => { fs.rmSync(tmp, { force: true }); reject(error) })
    child.on('exit', code => {
      signal?.removeEventListener('abort', onAbort)
      if (signal?.aborted) {
        fs.rmSync(tmp, { force: true })
        reject(new Error(`download aborted: ${url}`))
        return
      }
      if (code !== 0) {
        fs.rmSync(tmp, { force: true })
        reject(new Error(`curl exit ${code} for ${url}`))
        return
      }
      try { resolve(fs.readFileSync(tmp)) } catch (error) { reject(error) } finally { fs.rmSync(tmp, { force: true }) }
    })
  })
}

/** Single-quote escape for PowerShell string literals. */
function psQuote(value: string): string {
  return value.replaceAll('\'', '\'\'')
}

/** Production deps over node:fs, global fetch, curl, and PowerShell. */
export function nodeDeps(): InstallerDeps {
  return {
    readFile: path => fs.readFileSync(path, 'utf8'),
    exists: path => fs.existsSync(path),
    mkdir: dir => fs.mkdirSync(dir, { recursive: true }),
    writeFile: (path, data) => fs.writeFileSync(path, data),
    // [Environment]::GetFolderPath follows the known-desktop redirection
    // (OneDrive etc.) that a naive %USERPROFILE%\Desktop join would miss.
    desktopDir: () => new Promise((resolve, reject) => {
      const child = spawn('powershell', ['-NoProfile', '-Command', "[Environment]::GetFolderPath('Desktop')"], {
        windowsHide: true,
      })
      let out = ''
      child.stdout.on('data', chunk => { out += chunk })
      child.on('error', reject)
      child.on('exit', code => (code === 0 ? resolve(out.trim()) : reject(new Error(`desktopDir exit ${code}`))))
    }),
    // The API JSON is small and works over plain fetch.
    fetchText: async url => {
      const response = await fetch(url, {
        headers: { 'User-Agent': 'dsh-desktop-plugin', Accept: 'application/vnd.github+json' },
        signal: AbortSignal.timeout(15_000),
      })
      if (!response.ok) throw new Error(`GitHub API ${response.status} for ${url}`)
      return response.text()
    },
    // Release assets are multi-MB; Node's fetch stalls on some networks where
    // system curl succeeds. One download walks the whole route chain —
    // direct → env proxies → probed local ports → public mirrors — and the
    // optional `verify` callback (size/digest from the API) discards any
    // transfer that fails integrity so the next route is tried instead.
    fetchBytes: async (url, signal, verify) => {
      // Fixed temp root under os.tmpdir() (never TEMP/cwd-derived): download
      // scratch files must stay inside a known-safe directory.
      const tmpBase = path.join(os.tmpdir(), 'dsh-desktop-plugin')
      fs.mkdirSync(tmpBase, { recursive: true })
      const tmp = path.join(tmpBase, `download-${process.pid}-${Date.now()}.exe`)
      try {
        let firstError: unknown
        for (const route of await downloadRoutes()) {
          try {
            const bytes = await curlRoute(route, url, tmp, signal)
            if (verify === undefined || verify(bytes)) return bytes
          } catch (error) {
            if (signal?.aborted) throw error
            firstError ??= error
          }
        }
        throw firstError instanceof Error ? firstError : new Error(`all download routes failed for ${url}`)
      } finally {
        fs.rmSync(tmp, { force: true })
      }
    },
    createShortcut: (exePath, workDir, name) => new Promise((resolve, reject) => {
      const script = [
        '$ws = New-Object -ComObject WScript.Shell',
        `$lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) '${psQuote(name)}.lnk'))`,
        `$lnk.TargetPath = '${psQuote(exePath)}'`,
        `$lnk.WorkingDirectory = '${psQuote(workDir)}'`,
        `$lnk.IconLocation = '${psQuote(exePath)},0'`,
        '$lnk.Save()',
      ].join('\n')
      const child = spawn('powershell', ['-NoProfile', '-Command', script], {
        stdio: 'ignore',
        windowsHide: true,
      })
      child.on('error', reject)
      child.on('exit', code => (code === 0 ? resolve() : reject(new Error(`shortcut exit ${code}`))))
    }),
    readExeVersion: path => new Promise(resolve => {
      const child = spawn('powershell', ['-NoProfile', '-Command', `(Get-Item -LiteralPath '${psQuote(path)}').VersionInfo.ProductVersion`], {
        windowsHide: true,
      })
      let out = ''
      child.stdout.on('data', chunk => { out += chunk })
      child.on('error', () => resolve(''))
      child.on('exit', code => (code === 0 ? resolve(out.trim()) : resolve('')))
    }),
    rename: (from, to) => fs.renameSync(from, to),
    removeFile: path => fs.rmSync(path, { force: true }),
  }
}

/**
 * Pick the release asset URL for the desktop exe from a GitHub release JSON body.
 * @param body - releases/latest JSON text.
 * @returns the browser_download_url of the sole `.exe` asset.
 * @throws when the release has no exe asset.
 */
export function pickExeAssetUrl(body: string): string {
  const release = JSON.parse(body) as { assets?: Array<{ name: string, browser_download_url: string }> }
  const asset = release.assets?.find(candidate => candidate.name.endsWith('.exe'))
  if (asset === undefined) throw new Error('latest release has no .exe asset')
  return asset.browser_download_url
}

/**
 * Ensure the exe exists (downloading from the repo's latest GitHub Release
 * when missing) and the desktop shortcut points at it. Safe to re-run.
 * @param config - resolved plugin configuration.
 * @param deps - host boundary to fake in tests.
 * @param signal - cooperative cancellation for the download, when the caller owns one.
 * @returns what happened during this run.
 */
export async function ensureInstalled(config: ResolvedConfig, deps: InstallerDeps, signal?: AbortSignal): Promise<InstallResult> {
  const exePath = ensureWithin(config.installDir, exePathOf(config))
  let downloaded = false
  if (!deps.exists(exePath)) {
    const body = await deps.fetchText(`https://api.github.com/repos/${config.repoSlug}/releases/latest`)
    const asset = pickExeAssetMeta(body)
    const assetUrl = resolveAssetUrl(config, asset.url)
    const bytes = await deps.fetchBytes(assetUrl, signal, got => verifyBytes(got, asset.size, asset.digest))
    deps.mkdir(config.installDir)
    deps.writeFile(exePath, bytes)
    downloaded = true
  }
  let shortcut = false
  if (config.createShortcut) {
    await deps.createShortcut(exePath, config.installDir, safeFileName(config.shortcutName))
    shortcut = true
  }
  return { exePath, downloaded, shortcut }
}

/**
 * Ensure a desktop `.url` shortcut opens the DSH web UI in the default
 * browser, borrowing the desktop exe's icon when that exe is installed.
 * Independent of the exe download; safe to re-run.
 * @param config - resolved plugin configuration.
 * @param deps - host boundary to fake in tests.
 * @returns what happened during this run.
 */
export async function ensureWebShortcut(config: ResolvedConfig, deps: InstallerDeps): Promise<WebShortcutResult> {
  if (!config.createWebShortcut) return { path: '', created: false }
  const desktopDir = await deps.desktopDir()
  const name = safeFileName(config.webShortcutName)
  const urlPath = ensureWithin(desktopDir, `${desktopDir}\\${name}.url`)
  // The desktop migrates the default URL to a credential-free login entry.
  // Keep that entry on subsequent plugin activations, but honor explicit URLs.
  if (/^http:\/\/127\.0\.0\.1:3080\/?$/.test(config.webUrl) && deps.exists(urlPath)) {
    const existing = deps.readFile(urlPath)
    if (/^\s*\[InternetShortcut\]\s*$/im.test(existing.replace(/^\uFEFF/, '')) &&
        /^URL=dsh-desktop-web:\/\/open\s*$/im.test(existing)) {
      return { path: urlPath, created: false }
    }
  }
  const lines = ['[InternetShortcut]', `URL=${config.webUrl}`]
  const exePath = exePathOf(config)
  if (deps.exists(exePath)) {
    lines.push(`IconFile=${exePath}`, 'IconIndex=0')
  }
  deps.writeFile(urlPath, Buffer.from(`${lines.join('\r\n')}\r\n`, 'utf8'))
  return { path: urlPath, created: true }
}

/**
 * Upgrade the installed exe when a newer GitHub Release exists. Windows
 * allows renaming a running exe, so the swap renames the old one aside and
 * writes the new in place — safe even while the app is running. Safe to
 * re-run; a missing exe is left to ensureInstalled.
 * @param config - resolved plugin configuration.
 * @param deps - host boundary to fake in tests.
 * @returns what happened during this run.
 */
export async function ensureUpdated(config: ResolvedConfig, deps: InstallerDeps): Promise<UpdateResult> {
  const exePath = ensureWithin(config.installDir, exePathOf(config))
  const none: UpdateResult = { exePath, updated: false, fromVersion: '', toVersion: '' }
  if (!deps.exists(exePath)) return none
  const body = await deps.fetchText(`https://api.github.com/repos/${config.repoSlug}/releases/latest`)
  const asset = pickExeAssetMeta(body)
  if (asset.version === '') return none
  const current = await deps.readExeVersion(exePath)
  if (current === '' || compareVersions(asset.version, current) <= 0) return none
  const bytes = await deps.fetchBytes(
    resolveAssetUrl(config, asset.url),
    undefined,
    got => verifyBytes(got, asset.size, asset.digest),
  )
  const oldPath = `${exePath}.old`
  deps.removeFile(oldPath)
  deps.rename(exePath, oldPath)
  deps.writeFile(exePath, bytes)
  return { exePath, updated: true, fromVersion: current, toVersion: asset.version }
}
