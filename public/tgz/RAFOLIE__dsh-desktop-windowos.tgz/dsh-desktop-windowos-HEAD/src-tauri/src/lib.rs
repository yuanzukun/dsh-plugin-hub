//! App wiring: tray icon + menu, window close→hide, DSH lifecycle, and the
//! task-completion event monitor.

mod explorer_compat;
mod dsh;
mod startup_policy;
mod backend_update;
mod npm_operation;
mod web_shortcut;
mod menu;
mod monitor;
mod directory_picker;
mod update;

use tauri::{
    menu::{Menu, MenuItem},
    tray::{TrayIconBuilder, TrayIconEvent, MouseButton, MouseButtonState},
    AppHandle, Emitter, Manager, WindowEvent, Wry,
};

/// AppUserModelID stamped on toasts; must match the registry registration in
/// `ensure_toast_aumid` and the tauri.conf identifier.
pub(crate) const TOAST_AUMID: &str = "com.dsh.desktop";

static SHELL_REVEALED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
fn reveal_shell(app: &tauri::AppHandle) {
    if !SHELL_REVEALED.swap(true, std::sync::atomic::Ordering::SeqCst) {
        if let Some(window) = app.get_webview_window("main") { let _ = window.show(); }
    }
}
#[tauri::command]
fn window_shell_ready(app: tauri::AppHandle) { reveal_shell(&app); }

#[tauri::command]
fn app_web_open_status() -> String { web_shortcut::status() }

/// Pull half of the status contract: `dsh-status` is push-only and the reload
/// re-push can be missed, so a freshly (re)loaded page asks for the last report
/// instead of waiting on an event it can no longer catch.
#[tauri::command]
fn dsh_current_status() -> serde_json::Value { dsh::current_status().unwrap_or(serde_json::Value::Null) }

/// Frontend-invoked retry after a failed start.
#[tauri::command]
fn dsh_retry(app: AppHandle) {
    dsh::retry(app);
}

/// Frontend-invoked npx download consent after `notfound` (or as an error
/// fallback): persists the choice and runs the npx candidate.
#[tauri::command]
fn dsh_download(app: AppHandle) {
    dsh::download_and_start(app);
}

/// Frontend-invoked one-click global install: npm i -g @deepseek-ai/dsh,
/// then startup leads with the freshly installed global dsh. The registry
/// is optional and whitelisted Rust-side (probe winner or user's pick).
#[tauri::command]
fn dsh_install_npm(app: AppHandle, registry: Option<String>) {
    dsh::install_global_npm(app, registry.as_deref());
}

/// Frontend-invoked registry speed probe for the install-source chooser.
#[tauri::command]
fn dsh_npm_probe() -> serde_json::Value {
    dsh::npm_probe()
}

// --- 设置 tab:壳自身偏好。改动即时落盘;置顶项额外当场应用到窗口。 ---

/// Settings-tab payload: persisted shell prefs + 数据目录 + 实时注册表自启状态。
#[tauri::command]
fn app_get_shell_settings() -> serde_json::Value {
    serde_json::json!({
        "closeAction": dsh::close_action(),
        "trayClickAction": dsh::tray_click_action(),
        "alwaysOnTop": dsh::always_on_top(),
        "autostart": dsh::autostart::enabled(),
        "uiTheme": dsh::ui_theme(),
        "uiLocale": dsh::ui_locale(),
        "uiLocaleResolved": dsh::resolved_locale(),
        "appDataDir": dsh::shell_data_dir(),
    })
}

#[tauri::command]
fn app_set_close_action(action: String) {
    dsh::set_close_action(&action);
}

/// Settings tab「外观」segment: persist the shell skin + the scheme handed
/// to the webview on next launch.
#[tauri::command]
fn app_set_ui_theme(theme: String) -> Result<(), String> {
    dsh::set_ui_theme(&theme)
}

/// Settings tab「语言 / Language」segment: persist locale and rebuild the
/// tray menu in place so the switch is truly live everywhere. Returns the
/// resolved locale so the frontend can render without a second round-trip.
#[tauri::command]
fn app_set_ui_locale(app: AppHandle, locale: String) -> String {
    dsh::set_ui_locale(&locale);
    rebuild_tray_menu(&app);
    update_tray_tooltip(&app);
    dsh::resolved_locale()
}

#[tauri::command]
fn app_set_tray_click_action(app: AppHandle, action: String) -> Result<(), String> {
    dsh::set_tray_click_action(&action)?;
    update_tray_tooltip(&app);
    Ok(())
}
fn tray_tooltip() -> String {
    let hint = if dsh::tray_click_action() == "single" {
        dsh::ui_txt6("单击打开", "單擊開啟", "Click to open", "クリックして開く", "클릭하여 열기", "Один щелчок — открыть")
    } else {
        dsh::ui_txt6("双击打开", "雙擊開啟", "Double-click to open", "ダブルクリックして開く", "두 번 클릭하여 열기", "Двойной щелчок — открыть")
    };
    format!("DeepSeek Harness — {hint}")
}
fn update_tray_tooltip(app: &AppHandle) {
    if let Some(tray) = app.tray_by_id("main-tray") { let _ = tray.set_tooltip(Some(tray_tooltip())); }
}
fn tray_opens_window(action: &str, event: &TrayIconEvent) -> bool {
    match event {
        TrayIconEvent::Click { button: MouseButton::Left, button_state: MouseButtonState::Up, .. } => action == "single",
        TrayIconEvent::DoubleClick { button: MouseButton::Left, .. } => action != "single",
        _ => false,
    }
}

/// Tray menu built for the current locale (ids stay stable; only labels flip).
fn build_tray_menu<M: Manager<Wry>>(manager: &M) -> tauri::Result<Menu<Wry>> {
    let (t_open, t_restart, t_restart_app, t_update, t_env, t_quit) =
        match dsh::resolved_locale().as_str() {
            "zh-Hant" => (
                "開啟 DSH",
                "重啟 dsh web（後端）",
                "前後端重啟",
                "檢查前端更新",
                "環境資訊",
                "退出（關閉 DSH）",
            ),
            "en" => (
                "Open DSH",
                "Restart dsh web (backend)",
                "Restart shell & backend",
                "Check for updates",
                "Environment info",
                "Quit (stops DSH)",
            ),
            "ja" => (
                "DSH を開く",
                "dsh web（バックエンド）を再起動",
                "シェルとバックエンドを再起動",
                "更新を確認",
                "環境情報",
                "終了（DSH も停止）",
            ),
            "ko" => (
                "DSH 열기",
                "dsh web(백엔드) 재시작",
                "셸·백엔드 재시작",
                "업데이트 확인",
                "환경 정보",
                "종료(DSH 중지)",
            ),
            "ru" => (
                "Открыть DSH",
                "Перезапустить dsh web (бэкенд)",
                "Перезапуск оболочки и бэкенда",
                "Проверить обновления",
                "Сведения о среде",
                "Выход (остановить DSH)",
            ),
            _ => (
                "Open DSH",
                "重启 dsh web(后端)",
                "前后端重启",
                "检查前端更新",
                "环境信息",
                "退出(关闭 DSH)",
            ),
        };
    let open = MenuItem::with_id(manager, "open", t_open, true, None::<&str>)?;
    // Backend-only restart: relaunches the dsh web process, not the app.
    let restart = MenuItem::with_id(manager, "restart", t_restart, true, None::<&str>)?;
    let restart_app_item =
        MenuItem::with_id(manager, "restart-app", t_restart_app, true, None::<&str>)?;
    let update = MenuItem::with_id(manager, "update", t_update, true, None::<&str>)?;
    let env = MenuItem::with_id(manager, "env", t_env, true, None::<&str>)?;
    let quit = MenuItem::with_id(manager, "quit", t_quit, true, None::<&str>)?;
    Menu::with_items(manager, &[&open, &restart, &restart_app_item, &update, &env, &quit])
}

/// Swap the existing tray icon's menu after a live locale change. The
/// on_menu_event handler from setup stays bound (ids are stable).
fn rebuild_tray_menu(app: &AppHandle) {
    if let Some(tray) = app.tray_by_id("main-tray") {
        match build_tray_menu(app).and_then(|menu| tray.set_menu(Some(menu))) {
            Ok(()) => {}
            Err(err) => dsh::log_write(
                dsh::LogLevel::Warn,
                &format!("[dsh-desktop] tray menu rebuild failed: {err}"),
            ),
        }
    }
}

#[tauri::command]
fn app_set_autostart(enable: bool) -> Result<(), String> {
    dsh::autostart::set(enable)
}

#[tauri::command]
fn app_set_always_on_top(app: AppHandle, enable: bool) {
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.set_always_on_top(enable);
    }
    dsh::set_always_on_top(enable);
}

/// Frontend-invoked by the webchat mount flow (issue #10): returns the
/// browser-session token from ~/.dsh/.credentials.yaml when the running dsh
/// enforces BrowserAuth; None (legacy dsh) → the iframe uses a plain URL.
#[tauri::command]
fn dsh_browser_session_token() -> Option<String> {
    dsh::browser_session_token()
}

/// Frontend-invoked on every ready edge (v1.6.49): the final webchat iframe
/// URL for the current backend, adapting to its auth model — plain URL for
/// pre-0.1.2 dsh, token-exchange + WebView2 cookie plant for 0.1.2+
/// BrowserAuth, `?token=` URL for interim builds. The iframe must not mount
/// before this resolves (it would land on the 401 page otherwise).
///
/// MUST stay async: the flow parks up to ~12s (token wait + bounded HTTP) and
/// its cookie plant round-trips through the main thread (`with_webview`) — a
/// sync command would block the main thread itself and deadlock the plant.
#[tauri::command]
async fn dsh_webchat_url(app: AppHandle) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || dsh::webchat_auth_flow(&app))
        .await
        .map_err(|e| format!("webchat auth resolver panicked: {e}"))
}

/// Frontend-invoked environment facts for the env panel.
#[tauri::command]
fn env_info(app: AppHandle) -> serde_json::Value {
    dsh::env_info(&app)
}

/// Frontend-invoked "open this directory in Explorer" for env-panel paths.
#[tauri::command]
fn open_path(app: AppHandle, path: String) {
    use tauri_plugin_opener::OpenerExt;
    let _ = app.opener().open_path(path, None::<&str>);
}

/// Tail of the shared dsh.log for the log tab of the secondary panel.
#[tauri::command]
fn log_tail(lines: usize) -> Vec<String> {
    dsh::log_tail(lines.clamp(50, 1000))
}

/// Panel「重启」: restart the dsh web backend (same flow as the tray entry —
/// teardown, clear the port, re-run the startup chain; the shell's boot view
/// and webchat iframe re-attach through the usual events).
#[tauri::command]
fn dsh_restart_backend(app: AppHandle) {
    dsh::restart(app);
}

/// Panel/tray「前后端重启」: fresh app process onto the same exe,
/// owned DSH torn down — the new instance re-runs the whole chain.
#[tauri::command]
fn app_full_restart(app: AppHandle) {
    update::restart_app(&app);
}

/// 更新 tab: npm dist-tags (latest/next) for @deepseek-ai/dsh.
#[tauri::command]
async fn dsh_npm_channels() -> Result<serde_json::Value, String> {
    tauri::async_runtime::spawn_blocking(|| update::dsh_npm_channels().ok_or_else(|| "Could not query npm channels".to_string())).await.map_err(|e| e.to_string())?
}

/// 更新 tab「检查应用更新」: same as the tray check — narrated with toasts.
#[tauri::command]
fn dsh_self_update_check(app: AppHandle) {
    update::check_now(app);
}

/// 更新 tab: latest GitHub release tag for the app card, per channel
/// (stable=default / dev=prerelease).
#[tauri::command]
fn app_latest_stable(channel: Option<String>) -> serde_json::Value {
    update::app_latest_stable(channel.as_deref().unwrap_or("stable"))
        .unwrap_or(serde_json::Value::Null)
}

/// 更新 tab「立即更新」(app): runs the real on-demand self-update — check,
/// download with integrity verification, swap, auto-restart when newer.
#[tauri::command]
fn app_self_update(app: AppHandle) {
    update::check_now(app);
}

/// 更新 tab: persisted shell update prefs (channel + auto-update switch).
#[tauri::command]
fn app_get_update_config() -> serde_json::Value {
    let (channel, auto) = dsh::app_update_config();
    serde_json::json!({ "channel": channel, "autoUpdate": auto })
}

#[tauri::command]
fn app_set_update_config(channel: Option<String>, autoUpdate: Option<bool>) {
    let (cur_channel, cur_auto) = dsh::app_update_config();
    let ch = channel.unwrap_or(cur_channel);
    let au = autoUpdate.unwrap_or(cur_auto);
    dsh::set_app_update_config(&ch, au);
    dsh::log_write(
        dsh::LogLevel::Info,
        &format!("[dsh-desktop] update config saved: channel={ch}, autoUpdate={au}"),
    );
}

#[tauri::command]
async fn dsh_backend_source() -> Result<backend_update::Source, String> {
    tauri::async_runtime::spawn_blocking(backend_update::source).await.map_err(|e| e.to_string())
}
#[tauri::command]
fn dsh_backend_update_status() -> Option<backend_update::Job> { backend_update::status() }
#[tauri::command]
fn dsh_backend_upgrade(app: AppHandle, target: String, expected_path: String, expected_version: String, allow_downgrade: bool, expected_pid: u64, allow_external: bool) -> Result<backend_update::Job, String> {
    backend_update::start(app, target, expected_path, expected_version, allow_downgrade, expected_pid, allow_external)
}

/// Roll back the global dsh to the version saved before the last upgrade.
/// Runs in a background thread so the UI stays responsive during the
/// npm install (which can take minutes).
#[tauri::command]
fn dsh_rollback_dsh(app: AppHandle) -> Result<String, String> {
    if backend_update::busy() { return Err("An update is already running".into()); }
    let app = app.clone();
    std::thread::spawn(move || {
        if let Err(e) = dsh::rollback_dsh_to_previous() {
            dsh::log_write(
                dsh::LogLevel::Error,
                &format!("[dsh-desktop] rollback failed: {e}"),
            );
            return;
        }
        dsh::stop_backend(&app);
        dsh::startup(app.clone());
    });
    Ok("回滚中…".to_string())
}

/// One-paste AI context: env facts + this session's log as a markdown
/// bundle, saved beside the log and returned so the panel can also put it
/// on the clipboard. Solves "AI has to hunt through the whole DSH install".
#[tauri::command]
fn diagnostic_export(app: AppHandle) -> Result<serde_json::Value, String> {
    let (date, time, stamp) = dsh::local_time_parts();
    let info = dsh::env_info(&app);
    let version = app.package_info().version.to_string();
    let exe = tauri::utils::platform::current_exe()
        .map(|p| p.display().to_string())
        .unwrap_or_default();
    let log_dir = std::path::PathBuf::from(
        std::env::var("LOCALAPPDATA").unwrap_or_else(|_| ".".to_string()),
    )
    .join("dsh-desktop");
    let session_log = std::fs::read_to_string(log_dir.join("dsh.log"))
        .unwrap_or_else(|_| "(读取失败)".to_string());

    let mut content = String::new();
    content.push_str("# DSH Desktop 诊断包\n\n");
    content.push_str(&format!("- 生成时间: {date} {time}\n"));
    content.push_str(&format!("- 应用: v{version} ({exe})\n"));
    content.push_str(&format!("- 日志目录: {}\n\n", log_dir.display()));
    content.push_str("## 环境配置 (env_info)\n\n");
    content.push_str("```json\n");
    content.push_str(
        &serde_json::to_string_pretty(&info).unwrap_or_else(|_| "{}".to_string()),
    );
    content.push_str("\n```\n\n");
    content.push_str("## 本次会话日志 (dsh.log,仅壳事件)\n\n");
    content.push_str("~~~text\n");
    content.push_str(&session_log);
    content.push_str("\n~~~\n");

    let path = log_dir.join(format!("diagnostics-{stamp}.md"));
    std::fs::create_dir_all(&log_dir)
        .and_then(|_| std::fs::write(&path, &content))
        .map_err(|e| format!("诊断包写入失败:{e}"))?;
    dsh::log_write(
        dsh::LogLevel::Info,
        &format!("[dsh-desktop] diagnostic bundle exported: {}", path.display()),
    );
    Ok(serde_json::json!({
        "path": path.display().to_string(),
        "dir": log_dir.display().to_string(),
        "content": content,
    }))
}

/// Tray「环境信息」: show the window and open the env overlay. The shell stays
/// loaded next to the webchat iframe, so this is a plain event — no navigation.
fn open_env_page(app: &AppHandle) {
    show_main_window(app);
    let _ = app.emit("show-env", ());
}

/// Frontend-invoked custom dsh path from the notfound dialog: validates it
/// exists, persists it, and retries startup with it leading the chain.
#[tauri::command]
fn dsh_custom_path(app: AppHandle, path: String) -> Result<(), String> {
    dsh::set_custom_path(&app, path)
}

/// Frontend-invoked exit from the notfound choice.
#[tauri::command]
fn dsh_exit(app: AppHandle) {
    dsh::teardown(&app);
    app.exit(0);
}

// --- Titlebar window controls, as app commands. The frontend window-plugin
// calls (plugin:window|*) silently no-op'd in this setup while custom
// commands (the same channel env_info uses) worked fine; driving the window
// from Rust needs no capability entries and sidesteps that entirely. ---

#[tauri::command]
fn window_minimize(app: AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.minimize();
    }
}

#[tauri::command]
fn window_toggle_maximize(app: AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        let maximized = w.is_maximized().unwrap_or(false);
        if maximized {
            let _ = w.unmaximize();
        } else {
            let _ = w.maximize();
        }
    }
}

/// Same path as the native X would take: CloseRequested → hide to tray.
#[tauri::command]
fn window_close(app: AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.close();
    }
}

/// Titlebar drag: invoked on mousedown in the drag strip. The OS caption
/// semantics (move, and double-click → maximize) come along for free.
#[tauri::command]
fn window_start_drag(app: AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.start_dragging();
    }
}

#[tauri::command]
fn window_is_maximized(app: AppHandle) -> bool {
    app.get_webview_window("main")
        .and_then(|w| w.is_maximized().ok())
        .unwrap_or(false)
}

/// Show and focus the main window (tray double-click / Open DSH menu item /
/// toast "打开窗口" button / second-instance relaunch).
pub(crate) fn show_main_window(app: &AppHandle) {
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.show();
        let _ = window.unminimize();
        let _ = window.set_focus();
    }
}

/// Quit path: tear down our DSH subprocess tree, then exit. Attached mode tears
/// down to nothing and leaves the pre-existing instance running.
fn quit_dsh(app: &AppHandle) {
    dsh::teardown(app);
    app.exit(0);
}

/// Resolve where a webview download lands (issue #6): always the user's
/// Downloads folder, keeping WebView2's proposed file name when present and
/// falling back to a timestamped name for blob-style URLs that carry none.
/// Existing files get " (n)" suffixes instead of being overwritten.
fn download_target(proposed: &std::path::Path, url: &str) -> std::path::PathBuf {
    let downloads = std::env::var_os("USERPROFILE")
        .map(std::path::PathBuf::from)
        .unwrap_or_else(std::env::temp_dir)
        .join("Downloads");
    let _ = std::fs::create_dir_all(&downloads);

    let name = proposed
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .filter(|n| !n.trim().is_empty() && !n.eq_ignore_ascii_case("download"))
        .or_else(|| name_from_url(url))
        .unwrap_or_else(|| {
            let secs = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0);
            format!("dsh-download-{secs}")
        });

    let ext = std::path::Path::new(&name)
        .extension()
        .map(|e| format!(".{}", e.to_string_lossy()))
        .unwrap_or_default();
    let stem = name.trim_end_matches(&ext).to_string();
    let mut candidate = downloads.join(&name);
    let mut n = 1;
    while candidate.exists() {
        candidate = downloads.join(format!("{stem} ({n}){ext}"));
        n += 1;
    }
    candidate
}

/// Last path segment of the URL with percent-encoding resolved; `None` for
/// endpoint-only URLs (and blob:, which never carries a usable name).
fn name_from_url(url: &str) -> Option<String> {
    fn hex(c: u8) -> Option<u8> {
        match c {
            b'0'..=b'9' => Some(c - b'0'),
            b'a'..=b'f' => Some(c - b'a' + 10),
            b'A'..=b'F' => Some(c - b'A' + 10),
            _ => None,
        }
    }
    let raw = url.split(['?', '#']).next()?.rsplit('/').next()?;
    if raw.is_empty() {
        return None;
    }
    let b = raw.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        if b[i] == b'%' && i + 2 < b.len() {
            if let (Some(h), Some(l)) = (hex(b[i + 1]), hex(b[i + 2])) {
                out.push(h * 16 + l);
                i += 3;
                continue;
            }
        }
        out.push(b[i]);
        i += 1;
    }
    (!out.is_empty()).then(|| String::from_utf8_lossy(&out).into_owned())
}

/// Windows toast identity for a portable bare exe. tauri-plugin-notification
/// stamps toasts with the app identifier as AppUserModelID, but Windows only
/// displays toasts for an AUMID registered via an installer's Start Menu
/// shortcut — and we deliberately ship without an installer. Register the AUMID
/// through the documented registry alternative instead (the same method other
/// portable apps use); without it Windows silently drops every toast.
/// Idempotent; a failure only degrades toast attribution, never the app.
#[cfg(windows)]
fn ensure_toast_aumid() {
    use winreg::enums::HKEY_CURRENT_USER;
    use winreg::RegKey;

    // Must equal the tauri.conf.json identifier the notification stamps.
    const AUMID: &str = TOAST_AUMID;
    let register = |exe: &std::path::Path| -> std::io::Result<()> {
        let hkcu = RegKey::predef(HKEY_CURRENT_USER);
        let (key, _) = hkcu.create_subkey(format!(
            r"Software\Classes\AppUserModelId\{AUMID}"
        ))?;
        key.set_value("DisplayName", &"DeepSeek Harness")?;
        // Strip the `\\?\` verbatim prefix current_exe() can carry — Windows
        // expects a plain path here for the toast attribution icon.
        let exe_path = exe.display().to_string();
        let exe_path = exe_path.strip_prefix(r"\\?\").unwrap_or(&exe_path);
        key.set_value("IconUri", &exe_path)?;
        Ok(())
    };
    match tauri::utils::platform::current_exe() {
        Ok(exe) => {
            if let Err(e) = register(&exe) {
                eprintln!("[dsh-desktop] toast AUMID registration failed: {e}");
            }
        }
        Err(e) => eprintln!("[dsh-desktop] toast AUMID registration skipped: {e}"),
    }
}

/// Keep the tray icon pinned to the taskbar. Windows 11 identifies tray icons
/// by exe path under `HKCU\Control Panel\NotifyIconSettings` and defaults new
/// identities to the hidden overflow; `IsPromoted = 1` is exactly the value
/// Windows writes when a user unhides an icon. Without this the placement
/// resets into the overflow on every launch. Retried briefly because the key
/// only appears shortly after the tray icon registers. A failure is cosmetic
/// and never blocks the app.
#[cfg(windows)]
fn ensure_tray_promoted() {
    use winreg::enums::{HKEY_CURRENT_USER, KEY_READ, KEY_WRITE};
    use winreg::RegKey;

    let Ok(exe) = tauri::utils::platform::current_exe() else { return };
    let exe = exe
        .display()
        .to_string()
        .strip_prefix(r"\\?\")
        .unwrap_or(&exe.display().to_string())
        .to_lowercase();
    let root = RegKey::predef(HKEY_CURRENT_USER)
        .open_subkey_with_flags(r"Control Panel\NotifyIconSettings", KEY_READ | KEY_WRITE);
    let Ok(root) = root else { return };
    for key in root.enum_keys().flatten() {
        let Ok(sub) = root.open_subkey_with_flags(&key, KEY_READ | KEY_WRITE) else { continue };
        let Ok(path) = sub.get_value::<String, _>("ExecutablePath") else { continue };
        if path.to_lowercase() != exe { continue }
        let _: std::io::Result<()> = sub.set_value("IsPromoted", &1u32);
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {    tauri::Builder::default()
        // Registered first: a second launch (e.g. toast foreground activation,
        // or the user double-clicking the exe again) focuses the existing window
        // instead of starting a second instance.
        .plugin(tauri_plugin_single_instance::init(|app, args, _cwd| {
            if web_shortcut::requested(&args) { web_shortcut::open(app.clone()); }
            else { show_main_window(app); }
        }))
        .plugin(tauri_plugin_opener::init())
        .manage(dsh::DshState::new())
        .invoke_handler(tauri::generate_handler![directory_picker::pick_workspace_directory, window_shell_ready, app_web_open_status, dsh_current_status, dsh_retry, dsh_download, dsh_custom_path, dsh_install_npm, dsh_npm_probe, env_info, open_path, log_tail, diagnostic_export, dsh_restart_backend, app_full_restart, dsh_npm_channels, dsh_backend_source, dsh_backend_update_status, dsh_backend_upgrade, dsh_self_update_check, app_latest_stable, app_self_update, app_get_update_config, app_set_update_config, app_get_shell_settings, dsh_browser_session_token, dsh_webchat_url, dsh_rollback_dsh, app_set_ui_theme, app_set_ui_locale, app_set_close_action, app_set_tray_click_action, app_set_autostart, app_set_always_on_top, dsh_exit, window_minimize, window_toggle_maximize, window_close, window_start_drag, window_is_maximized])
        .setup(|app| {
            // Session-start log rotation (ComfyUI-style) before anything logs
            // or spawns: previous session archived under a timestamped name.
            dsh::rotate_log(app.handle());

            #[cfg(windows)]
            ensure_toast_aumid();
            #[cfg(windows)]
            if let Err(error) = web_shortcut::install() {
                dsh::log_write(dsh::LogLevel::Warn, &format!("Web shortcut registration failed: {error}"));
            }

            // The window is built here (not in tauri.conf.json) so it can carry
            // a new-window handler: every new-window request (target=_blank
            // links, window.open from the link menu) is handed to the system
            // default browser instead of being silently denied by wry.
            let opener_app = app.handle().clone();
            tauri::WebviewWindowBuilder::new(
                app,
                "main",
                tauri::WebviewUrl::App("index.html".into()),
            )
            .title("DeepSeek Harness")
            .inner_size(1280.0, 800.0)
            .min_inner_size(720.0, 520.0)
            // Custom title bar: the shell stays loaded for the whole session
            // (boot view + webchat iframe + env overlay), so the bar lives in
            // the page itself and the native frame is dropped entirely.
            .decorations(false)
            .visible(false)
            .initialization_script(&format!("if (window === window.top) {{ window.__DSH_INITIAL_THEME__ = {}; }}", serde_json::to_string(&dsh::ui_theme()).unwrap()))
            // Runs in every frame on document creation; self-guards on
            // `location.origin === 'http://127.0.0.1:3080'` so it installs the
            // link context menu exactly inside the webchat iframe.
            .initialization_script(&menu::init_script())
            .initialization_script(include_str!("directory-picker.js"))
            // WebView2's default drag-drop handler swallows file drops before
            // the page sees them, so HTML5 drag-and-drop (image attachments)
            // only works with the handler disabled — the tauri-documented
            // requirement for browser-parity dnd on Windows. Clipboard access
            // rides along for image paste.
            .disable_drag_drop_handler()
            .enable_clipboard_access()
            // Native Ctrl +/-/0 and Ctrl+wheel zoom for the embedded webchat
            // (issue #5): webview-level, so they work even while focus sits
            // inside the 3080 iframe.
            .zoom_hotkeys_enabled(true)
            // Color scheme comes from the「外观」preference instead of
            // WebView2's default (issue #8): explicit dark/light wins, and
            // "system" follows HKCU personalization. Applied at window
            // CREATION only — tauri-runtime-wry forwards the window theme
            // into WebView2's preferred color scheme once, at build time
            // (set_theme after that touches just the native chrome), so a
            // change needs an app restart to reach the embedded page.
            .theme(Some(match dsh::ui_theme().as_str() {
                "light" => tauri::Theme::Light,
                "dark" => tauri::Theme::Dark,
                _ if dsh::system_apps_dark() => tauri::Theme::Dark,
                _ => tauri::Theme::Light,
            }))
            // Session-log/blob downloads from the embedded webchat died
            // silently without a handler (issue #6). Land them in Downloads.
            .on_download(|_webview, event| {
                use tauri::webview::DownloadEvent;
                match event {
                    DownloadEvent::Requested { url, destination } => {
                        *destination = download_target(&destination, url.as_str());
                        true
                    }
                    DownloadEvent::Finished { url, path, success } => {
                        if success {
                            let name = path
                                .as_ref()
                                .and_then(|p| p.file_name())
                                .map(|n| n.to_string_lossy().into_owned())
                                .unwrap_or_else(|| url.to_string());
                            crate::update::toast(&format!(
                                "{}: {name}",
                                dsh::ui_txt6("下载完成", "下載完成", "Download finished", "ダウンロード完了", "다운로드 완료", "Загрузка завершена")
                            ));
                            let shown = path
                                .as_ref()
                                .map(|p| p.display().to_string())
                                .unwrap_or_else(|| url.to_string());
                            dsh::log_write(
                                dsh::LogLevel::Info,
                                &format!("[dsh-desktop] download finished: {shown}"),
                            );
                        }
                        success
                    }
                    _ => false,
                }
            })
            .on_new_window(move |url, _features| {
                let app = opener_app.clone();
                let url = url.to_string();
                tauri::async_runtime::spawn(async move {
                    use tauri_plugin_opener::OpenerExt;
                    // Log failures instead of swallowing them: issue #7's
                    // "links do nothing" reports were impossible to diagnose
                    // from user-side logs alone.
                    if let Err(err) = app.opener().open_url(&url, None::<&str>) {
                        dsh::log_write(
                            dsh::LogLevel::Error,
                            &format!("[dsh-desktop] open_url failed for {url}: {err}"),
                        );
                    }
                });
                tauri::webview::NewWindowResponse::Deny
            })
            // F5 (or any webview reload) remounts the shell page, which
            // missed the original `ready` emit — re-announce the current
            // backend state so the fresh page doesn't sit on the boot
            // spinner while the backend is actually up.
            .on_page_load(|webview, payload| {
                use tauri::webview::PageLoadEvent;
                if payload.event() == PageLoadEvent::Finished
                    && !payload.url().to_string().starts_with("about:")
                {
                    let app = webview.app_handle().clone();
                    std::thread::spawn(move || dsh::emit_current_status(&app));
                }
            })
            .build()?;

            // A broken frontend must not leave an invisible application forever.
            let reveal_app = app.handle().clone();
            std::thread::spawn(move || {
                std::thread::sleep(std::time::Duration::from_secs(5));
                reveal_shell(&reveal_app);
            });

            // Note: the webview color scheme (issue #8) is picked up at the
            // `.theme(...)` above during window CREATION — tauri-runtime-wry
            // forwards the window theme into WebView2's preferred color
            // scheme only once, at build time (set_theme after that touches
            // just the native chrome). A mid-session OS flip therefore needs
            // an app restart to reach the page.

            // Restore the settings-tab「窗口置顶」preference up front, so a
            // user with it enabled never sees one unpinned frame.
            if dsh::always_on_top() {
                if let Some(w) = app.get_webview_window("main") {
                    let _ = w.set_always_on_top(true);
                }
            }

            // Tray menu labels follow the persisted locale (see
            // app_set_ui_locale for the live-rebuild path).
            let menu = build_tray_menu(app.handle())?;

            TrayIconBuilder::with_id("main-tray")
                .icon(
                    app.default_window_icon()
                        .expect("default window icon missing")
                        .clone(),
                )
                .tooltip(tray_tooltip())
                .menu(&menu)
                // Left-click follows the saved activation mode; right-click keeps the menu.
                .show_menu_on_left_click(false)
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "open" => show_main_window(app),
                    "restart" => dsh::restart(app.clone()),
                    "restart-app" => update::restart_app(app),
                    "update" => update::check_now(app.clone()),
                    "env" => open_env_page(app),
                    "quit" => quit_dsh(app),
                    _ => {}
                })
                .on_tray_icon_event(|tray, event| {
                    if tray_opens_window(&dsh::tray_click_action(), &event) {
                        show_main_window(tray.app_handle());
                    }
                })
                .build(app)?;

            // Tray icon pinning: Windows creates the per-icon settings key
            // only moments after the tray registers, so retry briefly on a
            // side thread — never block startup on it.
            std::thread::spawn(|| {
                for _ in 0..5 {
                    ensure_tray_promoted();
                    std::thread::sleep(std::time::Duration::from_secs(2));
                }
            });

            // DSH lifecycle (probe/spawn/wait) and the event monitor run on their
            // own blocking threads; both share the AppHandle. The self-update
            // check runs in parallel — the boot page's version pill narrates it.
            let lifecycle = app.handle().clone();
            std::thread::spawn(move || dsh::startup(lifecycle));
            let monitor_app = app.handle().clone();
            std::thread::spawn(move || monitor::run(monitor_app));
            if web_shortcut::requested(&std::env::args().collect::<Vec<_>>()) {
                web_shortcut::open(app.handle().clone());
            }
            update::spawn_check(app.handle().clone());

            Ok(())
        })
        .on_window_event(|window, event| {
            // X behavior follows the settings tab: hide to tray (default,
            // DSH keeps running) or quit outright via the same path as the
            // tray「退出」entry. Only tray「退出」always exits regardless.
            if window.label() == "main" {
                if let WindowEvent::CloseRequested { api, .. } = event {
                    api.prevent_close();
                    if dsh::close_action() == "exit" {
                        quit_dsh(window.app_handle());
                    } else {
                        let _ = window.hide();
                    }
                }
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}


#[cfg(test)]
mod tray_tests {
    use super::*;
    fn click(button: MouseButton, state: MouseButtonState) -> TrayIconEvent {
        TrayIconEvent::Click { id: "fixture".into(), position: tauri::PhysicalPosition::new(0.0, 0.0),
            rect: tauri::Rect::default(), button, button_state: state }
    }
    #[test]
    fn tray_gestures_respect_mode_and_ignore_other_buttons() {
        let up = click(MouseButton::Left, MouseButtonState::Up);
        assert!(tray_opens_window("single", &up));
        assert!(!tray_opens_window("double", &up));
        for mode in ["single", "double"] {
            assert!(!tray_opens_window(mode, &click(MouseButton::Left, MouseButtonState::Down)));
            assert!(!tray_opens_window(mode, &click(MouseButton::Right, MouseButtonState::Up)));
            assert!(!tray_opens_window(mode, &click(MouseButton::Middle, MouseButtonState::Up)));
            let double = TrayIconEvent::DoubleClick { id: "fixture".into(), position: tauri::PhysicalPosition::new(0.0, 0.0), rect: tauri::Rect::default(), button: MouseButton::Left };
            assert_eq!(tray_opens_window(mode, &double), mode == "double");
        }
    }
    #[cfg(feature = "native-smoke")]
    #[test]
    #[ignore = "Creates only an isolated blank native window; no user backend or tray interaction"]
    fn native_window_restore() {
        let mut context = tauri::generate_context!();
        context.config_mut().identifier = "com.dsh.desktop.restore-test".into();
        let app = tauri::Builder::default().any_thread().build(context).expect("isolated app");
        let profile = std::env::temp_dir().join(format!("dsh-tray-restore-{}", uuid::Uuid::new_v4()));
        let window = tauri::WebviewWindowBuilder::new(&app, "main", tauri::WebviewUrl::External("about:blank".parse().unwrap()))
            .title("DSH isolated restore check").data_directory(profile).inner_size(360.0, 180.0).build().unwrap();
        let handle = app.handle().clone();
        let (tx, rx) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                let pause = || std::thread::sleep(std::time::Duration::from_millis(350));
                window.minimize().unwrap(); pause(); assert!(window.is_minimized().unwrap());
                show_main_window(&handle); pause(); assert!(!window.is_minimized().unwrap()); assert!(window.is_visible().unwrap());
                window.hide().unwrap(); pause(); assert!(!window.is_visible().unwrap());
                show_main_window(&handle); pause(); assert!(window.is_visible().unwrap()); assert!(!window.is_minimized().unwrap());
                window.maximize().unwrap(); pause();
                window.minimize().unwrap(); pause();
                show_main_window(&handle); pause(); assert!(!window.is_minimized().unwrap()); assert!(window.is_maximized().unwrap());
            }));
            let _ = tx.send(result.is_ok()); handle.exit(0);
        });
        app.run_return(|_, _| {});
        assert!(rx.recv_timeout(std::time::Duration::from_secs(5)).unwrap());
    }
}
