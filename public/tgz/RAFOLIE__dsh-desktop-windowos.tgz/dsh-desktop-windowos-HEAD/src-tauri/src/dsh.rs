//! DSH (DeepSeek Harness) lifecycle: readiness probe, spawn, teardown.
//!
//! Launch strategy — local-first, download only on explicit consent:
//!   1. `DSH_CMD` env override (optional `DSH_CWD`) leads the chain;
//!      for source-checkout development (`pnpm dsh web` in the repo).
//!   2. `dsh web` — a globally installed `dsh` found on PATH (npm/pnpm -g).
//!   3. Project-local install — `node_modules\.bin\dsh.cmd` searched in the
//!      exe's directory, the working directory, then the user profile.
//!   4. `npx @deepseek-ai/dsh web` — downloads the package, so it runs
//!      automatically only after the user picked "download" once (persisted
//!      in settings.json); otherwise a "notfound" event asks the user to
//!      choose download or exit.
//! Each candidate has its own readiness window; early exit or timeout falls
//! through to the next, and every attempt is logged to dsh.log and reported in
//! the final error. The shell either *attaches* to a DSH already listening on
//! 127.0.0.1:3080 or *spawns* its own tree; only a DSH we spawned is torn down
//! on exit, an attached instance is left untouched.

use std::collections::VecDeque;
use std::fs::OpenOptions;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use serde_json::{json, Value};
use tauri::{AppHandle, Emitter, Manager};
use uuid::Uuid;

const DSH_ORIGIN: &str = "http://127.0.0.1:3080";
const DSH_BASE: &str = "http://127.0.0.1:3080";

/// Readiness window for the single-command `DSH_CMD` chain.
const DSH_CMD_WINDOW: Duration = crate::startup_policy::INSTALLED_WINDOW;
/// Readiness window for the npx candidate: its first run downloads the full
/// package (500+ dependencies) before booting, which took over two minutes
/// in practice — five minutes leaves headroom for slow links.
const NPX_FIRST_RUN_WINDOW: Duration = crate::startup_policy::NPX_WINDOW;
/// Cold profile composition can exceed a minute. Missing commands still exit immediately.
const GLOBAL_WINDOW: Duration = crate::startup_policy::INSTALLED_WINDOW;
/// Interval between readiness probes.
const PROBE_INTERVAL: Duration = Duration::from_secs(1);

#[cfg(windows)]
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

/// Local port the DSH web server listens on; also the anchor for finding an
/// attached instance's PID at restart time.
const DSH_PORT: u16 = 3080;

/// A DSH subprocess we spawned (and therefore own the lifecycle of).
struct DshInner {
    pid: u32,
}

/// True while teardown/restart intentionally kill the owned child — the
/// supervisor watcher must not treat those exits as crashes.
static INTENTIONAL_STOP: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
/// Consecutive short-lived respawns; the crash-loop guard's trip counter.
static QUICK_DEATHS: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);

/// Managed state holding the owned subprocess, if any.
/// `None` ⇒ attached mode (do not kill on exit).
pub struct DshState {
    inner: Mutex<Option<DshInner>>,
}

impl DshState {
    pub fn new() -> Self {
        Self {
            inner: Mutex::new(None),
        }
    }
}

/// One launch attempt in the candidate chain.
struct Candidate {
    /// Human label surfaced in `dsh-status` events and error reports.
    label: String,
    /// Shell command executed through `cmd /C`.
    cmd: String,
    /// Working directory for the child.
    cwd: String,
    /// How long this candidate may take to become ready.
    window: Duration,
}

/// Build the launch chain, local-first. `DSH_CMD` (with optional `DSH_CWD`)
/// leads but no longer replaces the chain — a stale override falls through to
/// the saved custom path, the PATH-global `dsh` (found via `where dsh`,
/// covering the npm global `dsh`/`dsh.cmd` pair), a project-local
/// `node_modules\.bin\dsh.cmd`, and the npx download the user consented to.
/// An empty chain means "no local DSH" — startup reports `notfound` and the
/// boot page asks the user.
/// The default working directory is `%USERPROFILE%\.dsh` — a dsh-specific,
/// always-writable dir that never depends on a repo location or install path.
/// Pinning ALL candidates to the same cwd ensures the session workspace scope
/// stays consistent across candidate switches and dsh upgrades (issue: user
/// reported conversations "disappearing" after the working directory changed).
/// A stale `DSH_CWD` pointing at a deleted directory falls back to the same
/// fixed dir instead of failing every spawn with "directory name invalid"
/// (os error 267).
fn candidates() -> Vec<Candidate> {
    let home = std::env::var("USERPROFILE").unwrap_or_else(|_| ".".to_string());
    // Fixed cwd: dsh-specific dir under the user profile. Every candidate
    // (and every dsh version) shares this, so the session workspace scope
    // never changes between launches.
    let cwd = std::env::var("DSH_CWD")
        .ok()
        .filter(|dir| Path::new(dir).is_dir())
        .unwrap_or_else(|| {
            let dsh_home = Path::new(&home).join(".dsh");
            let _ = std::fs::create_dir_all(&dsh_home);
            dsh_home.display().to_string()
        });
    let mut list = Vec::new();
    if let Ok(cmd) = std::env::var("DSH_CMD") {
        if !cmd.trim().is_empty() {
            // User-owned command string: never rewritten (also means the
            // rc.8+ auto browser-open is theirs to manage via --no-open).
            list.push(Candidate {
                label: "自定义启动命令".to_string(),
                cmd,
                cwd: cwd.clone(),
                window: DSH_CMD_WINDOW,
            });
        }
    }
    if let Some(path) = custom_dsh_path() {
        list.push(Candidate {
            label: format!("自定义路径({path})"),
            cmd: format!("\"{path}\" web{}", no_open_suffix(&path)),
            cwd: cwd.clone(),
            window: GLOBAL_WINDOW,
        });
    }
    if dsh_on_path() {
        // Absolute path: a GUI-started process can carry a PATH that cmd's
        // own re-resolution doesn't honor for bare `dsh` (2026-08-18 home
        // report: "'dsh' 不是内部或外部命令" from the GUI chain).
        let via = where_first("dsh").unwrap_or_else(|| "dsh".to_string());
        list.push(Candidate {
            label: "dsh web".to_string(),
            cmd: format!("\"{via}\" web{}", no_open_suffix(&via)),
            cwd: cwd.clone(),
            window: GLOBAL_WINDOW,
        });
    }
    if let Some((shim, root)) = find_local_install() {
        list.push(Candidate {
            label: format!("本地安装({})", root.display()),
            cmd: format!("\"{}\" web{}", shim.display(), no_open_suffix(&shim.display().to_string())),
            cwd: cwd.clone(),
            window: GLOBAL_WINDOW,
        });
    }
    if prefer_npx() {
        list.push(npx_candidate(cwd));
    }
    // Deduplicate only identical commands/workspaces or verified package targets.
    let mut identities = std::collections::HashSet::new();
    list.retain(|candidate| {
        let target = candidate.cmd.strip_prefix('"').and_then(|s| s.split_once('"'))
            .filter(|(_, args)| matches!(args.trim(), "web" | "web --no-open"))
            .and_then(|(path, _)| crate::startup_policy::cli_root(Path::new(path)));
        let key = target.map(|p| format!("package:{}", p.display()).to_lowercase())
            .unwrap_or_else(|| candidate.cmd.clone());
        identities.insert((key, candidate.cwd.clone()))
    });
    list
}

/// Shell command string for invoking the dsh CLI with a subcommand (e.g.
/// `plugin --profile web add pkg@ver`), resolved through the same local-first
/// discovery as the launch chain. DSH_CMD is deliberately skipped: it is a
/// raw command string that may carry its own `web` argument and cannot be
/// reliably re-targeted. `None` when no usable dsh exists.
pub(crate) fn dsh_cli_command(sub: &str) -> Option<String> {
    if let Some(path) = custom_dsh_path() {
        return Some(format!("\"{path}\" {sub}"));
    }
    if dsh_on_path() {
        // Absolute shim path — immune to GUI-env PATH quirks (see candidates).
        let via = where_first("dsh").unwrap_or_else(|| "dsh".to_string());
        return Some(format!("\"{via}\" {sub}"));
    }
    if let Some((shim, _root)) = find_local_install() {
        return Some(format!("\"{}\" {sub}", shim.display()));
    }
    None
}

/// Read package metadata without launching a profile. No stale capability cache.
fn no_open_suffix(dsh_path: &str) -> &'static str {
    let capability = crate::startup_policy::no_open(Path::new(dsh_path));
    supervision_log(&format!("--no-open read-only capability: {capability:?}"));
    if capability == crate::startup_policy::Capability::Unknown {
        supervision_log("unrecognized CLI wrapper or package layout: launching without --no-open; DSH may open its own browser");
    }
    if capability == crate::startup_policy::Capability::Supported { " --no-open" } else { "" }
}

fn npx_candidate(cwd: String) -> Candidate {
    Candidate {
        label: "npx 下载并启动".to_string(),
        cmd: "npx --yes @deepseek-ai/dsh web".to_string(),
        cwd,
        window: NPX_FIRST_RUN_WINDOW,
    }
}

/// True if a `dsh` command (npm/pnpm global install) resolves on PATH.
fn dsh_on_path() -> bool {
    let mut command = Command::new("where");
    command.arg("dsh");
    apply_no_window(&mut command);
    command.status().map(|s| s.success()).unwrap_or(false)
}

/// Directories searched for a project-local DSH install
/// (`node_modules\.bin\dsh.cmd`), in order: next to the exe (the "download
/// the exe, `pnpm add` beside it" setup), the working directory, then the
/// user profile. Returns the shim and its owning root.
fn find_local_install() -> Option<(PathBuf, PathBuf)> {
    let mut roots: Vec<PathBuf> = Vec::new();
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            roots.push(dir.to_path_buf());
        }
    }
    if let Ok(cwd) = std::env::current_dir() {
        roots.push(cwd);
    }
    if let Ok(home) = std::env::var("USERPROFILE") {
        let home = PathBuf::from(home);
        if !roots.contains(&home) {
            roots.push(home);
        }
    }
    roots.into_iter().find_map(|root| {
        let shim = root.join("node_modules").join(".bin").join("dsh.cmd");
        shim.is_file().then_some((shim, root))
    })
}

/// User preferences persisted beside dsh.log: `preferNpx` set once the user
/// picks "download" (later cold starts run npx directly), and `customDshPath`
/// a user-entered dsh location that outlives the notfound dialog. Best-effort
/// — an unreadable file just reads empty.
fn settings_path() -> PathBuf {
    log_path()
        .parent()
        .unwrap_or_else(|| Path::new("."))
        .join("settings.json")
}

fn read_settings() -> Value {
    std::fs::read_to_string(settings_path())
        .ok()
        .and_then(|text| {
            // Tolerate a UTF-8 BOM (Notepad/PowerShell rewrites leave one);
            // serde_json rejects it and would silently reset every pref.
            let text = text.strip_prefix('\u{feff}').unwrap_or(&text);
            serde_json::from_str::<Value>(text).ok()
        })
        .unwrap_or_else(|| json!({}))
}

fn write_settings(map: Value) {
    let _ = std::fs::write(settings_path(), serde_json::to_string(&map).unwrap_or_default());
}

fn prefer_npx() -> bool {
    read_settings()
        .get("preferNpx")
        .and_then(|x| x.as_bool())
        .unwrap_or(false)
}

fn save_prefer_npx(value: bool) {
    let mut settings = read_settings();
    settings["preferNpx"] = json!(value);
    write_settings(settings);
}

/// App self-update preferences persisted in settings.json:
/// channel = "stable"(default) | "dev"; auto_update default true.
pub(crate) fn app_update_config() -> (String, bool) {
    let s = read_settings();
    let channel = s["appUpdateChannel"].as_str().unwrap_or("stable").to_string();
    let auto = s["appAutoUpdate"].as_bool().unwrap_or(true);
    (channel, auto)
}

pub(crate) fn set_app_update_config(channel: &str, auto: bool) {
    let mut settings = read_settings();
    settings["appUpdateChannel"] = json!(if channel == "dev" { "dev" } else { "stable" });
    settings["appAutoUpdate"] = json!(auto);
    write_settings(settings);
}

// --- 设置 tab:壳自身偏好(窗口行为),与更新偏好同住 settings.json ---

/// Close-button behavior: "tray"(default, hide with DSH running) | "exit".
pub(crate) fn close_action() -> String {
    read_settings()
        .get("closeAction")
        .and_then(|x| x.as_str())
        .unwrap_or("tray")
        .to_string()
}

pub(crate) fn set_close_action(action: &str) {
    let mut settings = read_settings();
    settings["closeAction"] = json!(if action == "exit" { "exit" } else { "tray" });
    write_settings(settings);
}

/// Tray activation defaults to the existing double-click behavior.
pub(crate) fn tray_click_action() -> String {
    if read_settings()["trayClickAction"].as_str() == Some("single") { "single" } else { "double" }.into()
}
pub(crate) fn set_tray_click_action(action: &str) -> Result<(), String> {
    if !matches!(action, "single" | "double") { return Err("Invalid tray click action".into()); }
    save_tray_click_action(&settings_path(), action)
}
fn save_tray_click_action(path: &Path, action: &str) -> Result<(), String> {
    if !matches!(action, "single" | "double") { return Err("Invalid tray click action".into()); }
    let mut settings: Value = match std::fs::read_to_string(path) {
        Ok(text) => serde_json::from_str(text.trim_start_matches('\u{feff}')).map_err(|e| format!("Cannot read settings: {e}"))?,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => json!({}),
        Err(e) => return Err(e.to_string()),
    };
    if !settings.is_object() { return Err("Settings must be an object".into()); }
    settings["trayClickAction"] = json!(action);
    std::fs::write(path, serde_json::to_vec(&settings).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())
}

#[cfg(test)]
mod tray_settings_tests {
    use super::*;
    #[test]
    fn saves_reloadable_mode_and_preserves_other_settings() {
        let path = std::env::temp_dir().join(format!("dsh-tray-settings-{}.json", uuid::Uuid::new_v4()));
        std::fs::write(&path, "\u{feff}{\"closeAction\":\"tray\",\"customDshPath\":\"test-path\"}").unwrap();
        for mode in ["single", "double"] {
            save_tray_click_action(&path, mode).unwrap();
            let doc: Value = serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
            assert_eq!(doc["trayClickAction"], mode);
            assert_eq!(doc["customDshPath"], "test-path");
        }
        let before = std::fs::read(&path).unwrap();
        assert!(save_tray_click_action(&path, "invalid").is_err());
        assert_eq!(std::fs::read(&path).unwrap(), before);
        std::fs::write(&path, "invalid JSON").unwrap();
        assert!(save_tray_click_action(&path, "single").is_err());
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "invalid JSON");
        std::fs::remove_file(path).unwrap();
    }
}

/// Keep the main window above all others; applied live and restored on startup.
pub(crate) fn always_on_top() -> bool {
    read_settings()
        .get("alwaysOnTop")
        .and_then(|x| x.as_bool())
        .unwrap_or(false)
}

pub(crate) fn set_always_on_top(on: bool) {
    let mut settings = read_settings();
    settings["alwaysOnTop"] = json!(on);
    write_settings(settings);
}

/// Shell UI theme: "system"(default) | "dark" | "light". Read at window
/// creation to pin the webview color scheme (issue #8), and served to the
/// settings tab's「外观」segmented control.
pub(crate) fn ui_theme() -> String {
    read_settings()
        .get("uiTheme")
        .and_then(|x| x.as_str())
        .unwrap_or("system")
        .to_string()
}

pub(crate) fn set_ui_theme(theme: &str) -> Result<(), String> {
    let value = match theme {
        "dark" => "dark",
        "light" => "light",
        _ => "system",
    };
    let mut settings = read_settings();
    settings["uiTheme"] = json!(value);
    let path = settings_path();
    let staged = path.with_extension("theme.tmp");
    let bytes = serde_json::to_vec(&settings).map_err(|e| e.to_string())?;
    std::fs::write(&staged, bytes).map_err(|e| e.to_string())?;
    std::fs::rename(&staged, &path).map_err(|e| e.to_string())
}

/// Shell UI locale preference: "system"(default) | "zh" | "zh-Hant" | "en" |
/// "ja" | "ko" | "ru". Drives the tray menu and every user-facing toast;
/// live switch goes through app_set_ui_locale.
pub(crate) fn ui_locale() -> String {
    read_settings()
        .get("uiLocale")
        .and_then(|x| x.as_str())
        .unwrap_or("system")
        .to_string()
}

pub(crate) fn set_ui_locale(locale: &str) {
    let value = match locale {
        "en" | "ja" | "ko" | "ru" | "zh-Hant" => locale,
        "system" => "system",
        _ => "system",
    };
    let mut settings = read_settings();
    settings["uiLocale"] = json!(value);
    write_settings(settings);
}

/// Map a Windows LANGID to one of the shell's supported locales. Languages
/// we don't ship fall back to "en" (the international fallback; policy:
/// unadapted languages default to English). Pure so every branch is
/// unit-testable without touching OS state.
fn langid_to_locale(langid: u16) -> &'static str {
    match langid {
        // zh-Hant: Taiwan / Hong Kong / Macau + neutral Hant
        0x0404 | 0x0C04 | 0x1404 | 0x0004 => "zh-Hant",
        // zh-Hans: PRC / Singapore
        0x0804 | 0x1004 => "zh",
        _ => match langid & 0x3FF {
            0x09 => "en",
            0x11 => "ja",
            0x12 => "ko",
            0x19 => "ru",
            // any other Chinese sublang is still Chinese (adapted)
            0x04 => "zh",
            // everything else (fr/de/es/...) is unadapted → English
            _ => "en",
        },
    }
}

#[cfg(windows)]
fn system_locale() -> String {
    use windows_sys::Win32::Globalization::GetUserDefaultUILanguage;
    let langid = unsafe { GetUserDefaultUILanguage() };
    langid_to_locale(langid).to_string()
}

#[cfg(not(windows))]
fn system_locale() -> String {
    "en".to_string()
}

/// The concrete locale to render: an explicit preference wins, "system"
/// follows the Windows UI language (resolved at every call — app start for
/// the webview scheme, per rebuild for the tray, per fetch for the panel).
pub(crate) fn resolved_locale() -> String {
    let pref = ui_locale();
    if pref != "system" {
        return pref;
    }
    system_locale()
}

/// Pick the current-locale string for shell-originated toasts/menus.
/// Argument order: [zh] [zh-Hant] [en] [ja] [ko] [ru].
pub(crate) fn ui_txt6<'a>(
    zh: &'a str,
    hant: &'a str,
    en: &'a str,
    ja: &'a str,
    ko: &'a str,
    ru: &'a str,
) -> &'a str {
    match resolved_locale().as_str() {
        "zh-Hant" => hant,
        "en" => en,
        "ja" => ja,
        "ko" => ko,
        "ru" => ru,
        _ => zh,
    }
}

#[cfg(all(test, windows))]
mod locale_tests {
    use super::langid_to_locale;

    #[test]
    fn langid_mapping_covers_supported_languages() {
        // Simplified: PRC / Singapore
        assert_eq!(langid_to_locale(0x0804), "zh");
        assert_eq!(langid_to_locale(0x1004), "zh");
        // Traditional: Taiwan / Hong Kong / Macau / neutral
        assert_eq!(langid_to_locale(0x0404), "zh-Hant");
        assert_eq!(langid_to_locale(0x0C04), "zh-Hant");
        assert_eq!(langid_to_locale(0x1404), "zh-Hant");
        assert_eq!(langid_to_locale(0x0004), "zh-Hant");
        // en / ja / ko / ru (a representative full LANGID each)
        assert_eq!(langid_to_locale(0x0409), "en");
        assert_eq!(langid_to_locale(0x0411), "ja");
        assert_eq!(langid_to_locale(0x0412), "ko");
        assert_eq!(langid_to_locale(0x0419), "ru");
        // unadapted languages default to English (fr / af / primary 0)
        assert_eq!(langid_to_locale(0x040C), "en"); // French
        assert_eq!(langid_to_locale(0x0436), "en"); // Afrikaans
        assert_eq!(langid_to_locale(0x0000), "en");
    }
}

#[cfg(test)]
mod cwd_tests {
    use super::*;

    #[test]
    fn all_candidates_share_the_same_cwd() {
        std::env::remove_var("DSH_CWD");
        let list = candidates();
        if list.len() > 1 {
            let first = &list[0].cwd;
            assert!(
                list.iter().all(|c| &c.cwd == first),
                "all candidates must share the same cwd"
            );
        }
    }
}

#[cfg(test)]
mod browser_session_tests {
    use super::{
        browser_session_token_from_yaml, capture_launch_token, child_tail_clear,
        parse_session_cookie, wait_launch_token, Duration,
    };

    #[test]
    fn browserauth_yaml_yields_token() {
        let yaml = "version: 1\nclient-connection:\n  browser-session: Tq1v2x9kA33bbZz7cC0dEe4fF5gG6hH7iI8jJ9kK0lL\n";
        assert_eq!(
            browser_session_token_from_yaml(yaml).as_deref(),
            Some("Tq1v2x9kA33bbZz7cC0dEe4fF5gG6hH7iI8jJ9kK0lL")
        );
    }

    #[test]
    fn provider_refs_yaml_yields_none() {
        // 0.1.1-rc.2 shape: provider OAuth refs only — must NOT be mistaken
        // for a browser-session token.
        let yaml = "version: 1\nrefs:\n  ZAI_CODING: 14011c49abcd.efgh1234\n  DEEPSEEK: 14011c49abcd.efgh1234\n";
        assert!(browser_session_token_from_yaml(yaml).is_none());
    }

    #[test]
    fn malformed_yaml_yields_none() {
        assert!(browser_session_token_from_yaml("::: not yaml {").is_none());
    }

    #[test]
    fn blank_or_short_token_yields_none() {
        assert!(browser_session_token_from_yaml("client-connection:\n  browser-session: \"   \"\n").is_none());
        assert!(browser_session_token_from_yaml("client-connection:\n  browser-session: short\n").is_none());
    }

    #[test]
    fn exchange_setcookie_parses() {
        // Shape captured live from dsh 0.1.5-rc.1's token exchange.
        let header = "dsh-auth-t1vK1KKW=v1.eyJ2ZXJzaW9uIjoxLCJhdXRob3JpdHkiOiIxMjcuMC4wLjE6MzA4MCJ9.utc3ZWoBuhWzJbAdCNF412P2lqO; Max-Age=2592000; Path=/; Expires=Sat, 10 Oct 2026 06:38:19 GMT; HttpOnly; SameSite=Strict";
        let cookie = parse_session_cookie(header).expect("valid exchange cookie");
        assert_eq!(cookie.name, "dsh-auth-t1vK1KKW");
        assert!(cookie.value.starts_with("v1."));
        assert_eq!(cookie.max_age, 2_592_000);
    }

    #[test]
    fn foreign_or_stunted_cookies_rejected() {
        assert!(parse_session_cookie("sessionid=abc1234567890123456789; Path=/").is_none());
        assert!(parse_session_cookie("dsh-auth-x=tooshort; Max-Age=1").is_none());
        assert!(parse_session_cookie("not a header").is_none());
    }

    #[test]
    fn launch_token_lifecycle() {
        // One test body: LAUNCH_TOKEN is a process-global, so the extract /
        // clear / ignore phases must run serially, not as parallel tests.
        capture_launch_token(
            "dsh web: http://127.0.0.1:3080/?token=TUnh16K7tUeypkLegjJvDqfr9B8SNm2SebqR58ldYao (LAN: http://192.168.1.5:3080/?token=other)",
        );
        assert_eq!(
            wait_launch_token(Duration::from_millis(0)).as_deref(),
            Some("TUnh16K7tUeypkLegjJvDqfr9B8SNm2SebqR58ldYao")
        );
        child_tail_clear();
        assert_eq!(wait_launch_token(Duration::from_millis(0)), None);
        // Non-announce lines (including look-alikes) must not re-arm it.
        capture_launch_token("some unrelated dsh web output line");
        assert_eq!(wait_launch_token(Duration::from_millis(0)), None);
    }
}

/// Directory holding dsh.log / settings.json — the「应用数据目录」row.
pub(crate) fn shell_data_dir() -> Option<String> {
    log_path()
        .parent()
        .map(|p| p.to_string_lossy().into_owned())
}

// --- 开机自启(设置 tab):HKCU Run 键,实时查注册表,不落 settings.json ---

#[cfg(windows)]
pub(crate) mod autostart {
    use winreg::enums::{HKEY_CURRENT_USER, KEY_SET_VALUE};
    use winreg::RegKey;

    const RUN_SUBKEY: &str = r"Software\Microsoft\Windows\CurrentVersion\Run";
    const VALUE_NAME: &str = "DeepSeek Harness";

    pub(crate) fn enabled() -> bool {
        RegKey::predef(HKEY_CURRENT_USER)
            .open_subkey(RUN_SUBKEY)
            .and_then(|k| k.get_value::<String, _>(VALUE_NAME))
            .is_ok()
    }

    pub(crate) fn set(enable: bool) -> Result<(), String> {
        if !enable {
            // Absent value/key counts as disabled — deleting twice must not error.
            return match RegKey::predef(HKEY_CURRENT_USER).open_subkey_with_flags(RUN_SUBKEY, KEY_SET_VALUE) {
                Ok(key) => match key.delete_value(VALUE_NAME) {
                    Ok(()) => Ok(()),
                    Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
                    Err(e) => Err(e.to_string()),
                },
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
                Err(e) => Err(e.to_string()),
            };
        }
        let exe = tauri::utils::platform::current_exe().map_err(|e| e.to_string())?;
        // Quote the path (spaces are legal); strip the `\\?\` verbatim prefix
        // current_exe() can carry, same as the toast AUMID registration.
        let path = exe.display().to_string();
        let path = path.strip_prefix(r"\\?\").unwrap_or(&path);
        let (key, _) = RegKey::predef(HKEY_CURRENT_USER)
            .create_subkey(RUN_SUBKEY)
            .map_err(|e| e.to_string())?;
        key.set_value(VALUE_NAME, &format!("\"{path}\""))
            .map_err(|e| e.to_string())
    }
}

#[cfg(not(windows))]
pub(crate) mod autostart {
    pub(crate) fn enabled() -> bool {
        false
    }
    pub(crate) fn set(_enable: bool) -> Result<(), String> {
        Err("仅支持 Windows".into())
    }
}

/// User-entered dsh executable (dsh.cmd/dsh.exe) saved from the notfound
/// dialog; `None` when unset or the file no longer exists (self-healing).
pub(crate) fn custom_dsh_path() -> Option<String> {
    read_settings()
        .get("customDshPath")
        .and_then(|x| x.as_str())
        .map(str::to_string)
        .filter(|path| Path::new(path).is_file())
}

/// One RPC probe against `/api/<endpoint>` with the client-request envelope.
/// Returns the HTTP status (0 = unreachable/timeout) and the parsed JSON body
/// when one came back. ureq 2.x hands every 4xx/5xx over as
/// `Err(Error::Status(code, resp))` — normalized here so the verdict logic
/// sees one shape (the v1.6.47 "401 = alive" branch sat on the `Ok` path and
/// was dead code for exactly this reason, issues #10/#12).
fn rpc_probe(endpoint: &str) -> (u16, Option<Value>) {
    rpc_probe_at(DSH_BASE, endpoint)
}
fn rpc_probe_at(base: &str, endpoint: &str) -> (u16, Option<Value>) {
    let body = json!({
        "type": "client-request",
        "rpcId": Uuid::new_v4().to_string(),
        "method": endpoint,
        "payload": {}
    });
    let response = ureq::post(&format!("{base}/api/{endpoint}"))
        // Match the host authority so the /api trust fence (Origin vs Host) passes.
        .set("Origin", base)
        .timeout(Duration::from_secs(3))
        .send_json(body);
    match response {
        Ok(r) => (r.status(), r.into_json::<Value>().ok()),
        Err(ureq::Error::Status(status, r)) => (status, r.into_json::<Value>().ok()),
        Err(_) => (0, None),
    }
}

/// Whether one probe result proves a dsh web owns port 3080.
/// 401: the `/api` fence of a BrowserAuth build (0.1.2+) — dsh is alive, we
/// just lack credentials. 200 plus a `server-response` RPC envelope: dsh
/// answered the gateway itself; `require_ok` additionally demands
/// `result.ok == true` (the pre-0.1.2 contract on host.describe). Anything
/// else — including 404 — proves nothing: 404 is NOT "a foreign service"
/// on 0.1.2+ (it is that generation's normal answer for a deleted endpoint,
/// issue #12), so the caller falls through to another endpoint instead.
fn probe_result_alive(status: u16, body: Option<&Value>, require_ok: bool) -> bool {
    if status == 401 {
        return true;
    }
    if status != 200 {
        return false;
    }
    let Some(v) = body else { return false };
    if v.get("type").and_then(|t| t.as_str()) != Some("server-response") {
        return false;
    }
    !require_ok || v.get("result").and_then(|r| r.get("ok")) == Some(&json!(true))
}

/// Probe 3080 once; true if a dsh web of any supported generation answers.
/// A plain TCP connect is not enough — an open port is not necessarily DSH.
/// Endpoint ladder (issue #12):
///   1. `host.describe` (dot-named, ≤0.1.1): 200+ok = healthy old dsh;
///      401 = BrowserAuth fence (0.1.2+ answered before routing).
///   2. `session/list` (slash-named, exists on every 0.1.2+ build): 401 =
///      fence; 200 + server-response envelope = the typert gateway itself
///      (an empty-payload probe yields `ok:false`/`arguments-invalid` — still
///      a dsh-shaped answer, so only the envelope is required).
/// Both miss ⇒ not a dsh we know (foreign service or nothing listening).
pub(crate) fn probe_ready_once() -> bool {
    let (status, body) = rpc_probe("host.describe");
    if probe_result_alive(status, body.as_ref(), true) {
        return true;
    }
    if status == 404 {
        // host.describe was deleted in the 0.1.2 unary-apiproxy→remote
        // migration; some builds route-404 before the auth fence can 401.
        let (status2, body2) = rpc_probe("session/list");
        return probe_result_alive(status2, body2.as_ref(), false);
    }
    false
}

// Browser requests follow this lifecycle rather than a separate short deadline.
static START_GATE: Mutex<()> = Mutex::new(());
static START_STATUS: Mutex<Option<Value>> = Mutex::new(None);
static START_ACTIVE: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
struct StartupGuard;
impl StartupGuard {
    fn new() -> Self {
        START_ACTIVE.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        Self
    }
}
impl Drop for StartupGuard {
    fn drop(&mut self) { START_ACTIVE.fetch_sub(1, std::sync::atomic::Ordering::SeqCst); }
}
pub(crate) fn startup_active() -> bool { START_ACTIVE.load(std::sync::atomic::Ordering::SeqCst) > 0 }
pub(crate) fn startup_terminal() -> bool {
    START_STATUS.lock().ok().and_then(|v| v.as_ref().map(|s| matches!(s["status"].as_str(), Some("error" | "notfound")))).unwrap_or(false)
}
fn startup_report(app: &AppHandle, value: Value) {
    if let Ok(mut state) = START_STATUS.lock() { *state = Some(value.clone()); }
    let _ = app.emit("dsh-status", value);
}
/// Last status reported to the shell frontend (see `startup_report`).
/// `None` until the first report — a freshly (re)loaded page pulls this
/// instead of depending on having caught the original event.
pub(crate) fn current_status() -> Option<Value> {
    START_STATUS.lock().ok().and_then(|s| s.clone())
}
fn startup_progress(app: &AppHandle, candidate: &Candidate, started: Instant, phase: &str) {
    startup_report(app, json!({"status":"starting", "method":candidate.label,
        "phase":phase, "elapsed":started.elapsed().as_secs(), "budget":candidate.window.as_secs()}));
}

/// Outcome of one candidate attempt.
enum Attempt {
    Ready,
    Failed(String),
    Blocked(String),
}


/// Emit `ready` repeatedly for a short window instead of once. The boot page's
/// listener registers only after the embedded webview finishes loading, which
/// races the fast local readiness probe — a one-shot emit can be missed and
/// leave the window stuck on the boot spinner.
/// Re-announce the backend state to a freshly (re)loaded shell page. F5
/// reloads the webview; the fresh frontend missed the original `ready` emit
/// and would sit on the boot spinner forever while the backend is actually
/// up — the backend itself never restarted. Idempotent with the normal
/// startup flow (the frontend collapses ready re-emits into transitions).
pub(crate) fn emit_current_status(app: &AppHandle) {
    // Let the fresh page's listener register first.
    std::thread::sleep(Duration::from_millis(600));
    for _ in 0..5 {
        if probe_ready_once() {
            let attached = app.state::<DshState>().inner.lock().unwrap().is_none();
            let _ = app.emit(
                "dsh-status",
                json!({ "status": "ready", "attached": attached, "method": "页面重载" }),
            );
            return;
        }
        std::thread::sleep(Duration::from_millis(400));
    }
    if let Some(snapshot) = START_STATUS.lock().ok().and_then(|s| s.clone()) {
        let _ = app.emit("dsh-status", snapshot);
    }
}

fn emit_ready(app: &AppHandle, attached: bool, method: Option<String>) {
    startup_report(app, json!({"status":"ready", "attached":attached, "method":method}));
    let app2 = app.clone();
    std::thread::spawn(move || {
        for _ in 0..10 {
            let mut payload = json!({ "status": "ready", "attached": attached });
            if let Some(m) = &method {
                payload["method"] = json!(m);
            }
            let _ = app2.emit("dsh-status", payload);
            std::thread::sleep(Duration::from_millis(400));
        }
    });
}

/// Drive startup from a background thread. Emits `dsh-status` events:
/// `{status:"starting",method}` per attempt, then either
/// `{status:"ready",attached,method}` or `{status:"error",message}` with every
/// attempt's failure reason.
pub fn startup(app: AppHandle) {
    let Ok(_gate) = START_GATE.try_lock() else { return; };
    let _lifecycle = StartupGuard::new();
    startup_report(&app, json!({"status":"starting", "phase":"discovering"}));
    // Attach path: DSH already up — never spawn, never kill on exit.
    if probe_ready_once() {
        emit_ready(&app, true, None);
        return;
    }

    let mut failures: Vec<String> = Vec::new();
    let chain = candidates();
    // No local DSH and no consented download: hand the choice to the user
    // instead of silently pulling 500+ dependencies.
    if chain.is_empty() {
        startup_report(&app, json!({ "status": "notfound" }));
        return;
    }
    for candidate in chain {
        let _ = app.emit(
            "dsh-status",
            json!({ "status": "starting", "method": candidate.label }),
        );
        match try_candidate(&app, &candidate) {
            Attempt::Ready => return,
            Attempt::Failed(reason) => {
                supervision_warn(&format!("candidate {} failed; trying next available source", candidate.label));
                failures.push(format!("「{}」{}", candidate.label, reason));
            }
            Attempt::Blocked(reason) => {
                startup_report(&app, json!({"status":"error", "message":reason}));
                return;
            }
        }
    }
    startup_report(&app, json!({
        "status": "error",
        "message": format!("所有启动方式均失败:\n{}", failures.join("\n")),
    }));
}

/// Spawn one candidate and poll until ready, early exit, or window expiry.
/// One candidate attempt: spawn, wait for readiness, early-exit, or window
/// expiry. The child's console tail is kept in memory — on early exit it
/// names the real cause (e.g. pnpm's fresh-release cooldown silently
/// skipping a profile bundle → "cannot resolve profile bundle"), and a
/// missing-bundle death triggers one cooldown-bypassed repair + respawn of
/// the same candidate before giving up.
fn try_candidate(app: &AppHandle, candidate: &Candidate) -> Attempt {
    log_attempt(candidate);
    for attempt in 0..2 {
        child_tail_clear();
        let (mut child, drained) = match spawn_command(&candidate.cmd, &candidate.cwd) {
            Ok(c) => c,
            Err(e) => return Attempt::Failed(format!("无法启动({e})\n")),
        };
        let pid = child.id();
        let started = Instant::now();
        loop {
            startup_progress(app, candidate, started, "waiting");
            let ready = probe_ready_once();
            let exit = if ready { Ok(None) } else { child.try_wait() };
            let verdict = crate::startup_policy::poll(ready, matches!(exit, Ok(Some(_))), started.elapsed(), candidate.window);
            if verdict == crate::startup_policy::Poll::Ready {
                // The state keeps only the pid (for teardown's tree kill); the
                // Child handle moves to the supervisor thread, which reaps the
                // process and reacts to unexpected exits.
                let state = app.state::<DshState>();
                *state.inner.lock().unwrap() = Some(DshInner { pid });
                INTENTIONAL_STOP.store(false, std::sync::atomic::Ordering::Relaxed);
                emit_ready(app, false, Some(candidate.label.clone()));
                let app2 = app.clone();
                std::thread::spawn(move || supervise_child(app2, child, pid, Instant::now()));
                return Attempt::Ready;
            }
            // A missing command exits immediately; surface that instead of
            // waiting out the whole window — with the child's own last words.
            match exit {
                Ok(Some(status)) => {
                    // stdout/stderr reader threads can lag the process exit.
                    // Drain with a bound: an inherited pipe held by a grandchild
                    // must never block failure reporting indefinitely.
                    let drain_until = Instant::now() + Duration::from_millis(500);
                    for _ in 0..2 {
                        if drained.recv_timeout(drain_until.saturating_duration_since(Instant::now())).is_err() { break; }
                    }
                    let all_tail = child_tail_last(CHILD_TAIL_CAP);
                    if let Some(path) = crate::startup_policy::writer_lock_path(&all_tail) {
                        supervision_warn("profile writer lock timeout; startup chain stopped (lock preserved)");
                        let owner = std::fs::metadata(&path).ok().filter(|m| m.is_file() && m.len() <= 64)
                            .and_then(|_| std::fs::read_to_string(&path).ok())
                            .and_then(|s| s.trim().parse::<u32>().ok())
                            .map(|pid| format!("锁文件记录 PID {pid}（是否仍在写入需核实）"))
                            .unwrap_or_else(|| "无法核实锁的占用进程".into());
                        return Attempt::Blocked(format!("DSH profile 写入锁等待超时：{path}\n{owner}。请等待其他 DSH 安装/初始化完成后重试；若持续失败，确认相关写入进程已停止后再人工处理残留锁。桌面程序未删除此锁。"));
                    }
                    let tail = child_tail_last(8);
                    let excerpt = child_tail_digest(4);
                    if !excerpt.is_empty() {
                        log_write(
                            LogLevel::Error,
                            &format!("candidate died early ({status}); last output: {excerpt}"),
                        );
                    }
                    // File-level self-heals before signature matching: a
                    // corrupt settings.yaml (YAML writer dropped the colon
                    // space) kills every candidate identically, so check the
                    // file itself rather than the child's wording.
                    if attempt == 0 && settings_yaml_selfheal() {
                        supervision_log("settings.yaml repaired; retrying the same candidate");
                        break; // respawn the candidate once
                    }
                    if attempt == 0 && !tail.is_empty() {
                        if let Some(pkg) = missing_bundle(&tail) {
                            if repair_profile_bundle(&pkg) {
                                supervision_log(&format!(
                                    "bundle repair installed {pkg}; retrying the same candidate"
                                ));
                                break; // respawn the candidate once
                            }
                            return Attempt::Failed(format!(
                                "进程提前退出({status})——缺少 profile 包 {pkg}(疑似 pnpm 新发布冷却期拦截)\n手动修复:在 %USERPROFILE%\\.dsh\\profiles\\web 执行 pnpm add --save-exact {pkg} --config.minimumReleaseAge=0\n完整日志:面板→日志,或 %LOCALAPPDATA%\\dsh-desktop\\dsh.log\n{}",
                                tail.join("\n")
                            ));
                        }
                    }
                    let excerpt = if tail.is_empty() {
                        String::new()
                    } else {
                        format!("\n{}", tail.join("\n"))
                    };
                    return Attempt::Failed(format!("进程提前退出({status}){excerpt}\n"));
                }
                Ok(None) => {}
                Err(e) => {
                    kill_tree(pid);
                    let _ = child.wait();
                    return Attempt::Failed(format!("无法查询子进程({e})\n"));
                }
            }
            if verdict == crate::startup_policy::Poll::Timeout {
                supervision_warn(&format!("candidate readiness timeout after {} seconds (budget {} seconds)", started.elapsed().as_secs(), candidate.window.as_secs()));
                kill_tree(pid);
                let _ = child.wait();
                let excerpt = child_tail_digest(4);
                return Attempt::Failed(format!(
                    "等待 {} 秒后仍未就绪{}\n",
                    candidate.window.as_secs(),
                    if excerpt.is_empty() {
                        String::new()
                    } else {
                        format!(",最后输出: {excerpt}")
                    }
                ));
            }
            std::thread::sleep(PROBE_INTERVAL);
        }
    }
    unreachable!("repair path always returns or respawns exactly once")
}

/// Rolling tail of the current DSH child's console output. The full stream
/// is deliberately NOT written to dsh.log (unbounded, and DSH keeps its own
/// logs) — but crash causes like "cannot resolve profile bundle" only ever
/// appear on the child's stderr, so the last lines stay in memory for error
/// payloads and the auto-repair signature.
static CHILD_TAIL: Mutex<VecDeque<String>> = Mutex::new(VecDeque::new());
const CHILD_TAIL_CAP: usize = 60;

/// Launch token printed once on the child's stdout by BrowserAuth-enabled
/// dsh builds (0.1.2+): `dsh web: http://127.0.0.1:3080/?token=<base64url>`.
/// Refreshed on every respawn (each process mints its own) and cleared with
/// the tail when we stop owning that child. Attach mode has no stdout to
/// watch — the webchat then leans on the still-valid planted cookie (its
/// signing secret in ~/.dsh/.credentials.yaml is persistent).
static LAUNCH_TOKEN: Mutex<Option<String>> = Mutex::new(None);

/// The browser-session cookie minted by the launch-token exchange, kept for
/// non-webview consumers: the session monitor's mux WebSocket and its
/// session/list title lookup authenticate with a `Cookie:` header (issue #18 —
/// the exchange used to feed only the WebView2 jar, so every Rust-side /api
/// call stayed unauthenticated and session toasts silently never fired).
/// Also persisted beside the marker so a shell restart still sees the cookie
/// the webview keeps in its own jar (attach mode mints none of its own).
/// Same trust domain as dsh's own persistent token in ~/.dsh/.credentials.yaml.
static SESSION_COOKIE: Mutex<Option<(String, String, u64)>> = Mutex::new(None);

fn planted_cookie_store_path() -> std::path::PathBuf {
    planted_cookie_marker_path()
        .parent()
        .unwrap_or_else(|| Path::new("."))
        .join("webauth-session.cookie")
}

/// Remember an exchanged `dsh-auth-…` cookie for Rust-side /api consumers
/// (memory + `%LOCALAPPDATA%\dsh-desktop\webauth-session.cookie`, two lines:
/// `name=value` and the unix expiry). Best effort on both paths.
fn store_session_cookie(cookie: &SessionCookie) {
    let expires_at = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs().saturating_add(cookie.max_age))
        .unwrap_or(0);
    if let Ok(mut slot) = SESSION_COOKIE.lock() {
        *slot = Some((cookie.name.clone(), cookie.value.clone(), expires_at));
    }
    let _ = std::fs::write(
        planted_cookie_store_path(),
        format!("{}={}\n{}\n", cookie.name, cookie.value, expires_at),
    );
}

/// `name=value` for a `Cookie:` header — the in-memory exchange result when
/// fresh, else the persisted one from a previous run of this or an earlier
/// shell process (the signing secret is persistent, so the cookie outlives
/// both processes). None when we never exchanged or the stored one expired.
pub(crate) fn session_cookie_pair() -> Option<String> {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    if let Ok(slot) = SESSION_COOKIE.lock() {
        if let Some((name, value, expires_at)) = slot.as_ref() {
            if *expires_at > now {
                return Some(format!("{name}={value}"));
            }
        }
    }
    let text = std::fs::read_to_string(planted_cookie_store_path()).ok()?;
    let mut lines = text.lines();
    let pair = lines.next()?.trim().to_string();
    let expires_at = lines.next()?.trim().parse::<u64>().ok()?;
    let valid = expires_at > now
        && pair.starts_with("dsh-auth-")
        && pair.split_once('=').is_some_and(|(n, v)| !n.is_empty() && v.len() >= 24);
    valid.then_some(pair)
}

/// Prefix of the announce line; the token is the base64url run that follows.
/// Matched by `find` (not strip_prefix) so console noise around the line or
/// the LAN-hint suffix cannot hide it.
const TOKEN_ANNOUNCE: &str = "dsh web: http://127.0.0.1:3080/?token=";

/// Pull the launch token out of one stdout/stderr line, if it is the announce.
fn capture_launch_token(line: &str) {
    let Some(pos) = line.find(TOKEN_ANNOUNCE) else {
        return;
    };
    let rest = &line[pos + TOKEN_ANNOUNCE.len()..];
    let token: String = rest
        .chars()
        .take_while(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_'))
        .collect();
    if token.len() >= 20 {
        if let Ok(mut slot) = LAUNCH_TOKEN.lock() {
            *slot = Some(token);
        }
        supervision_log("BrowserAuth launch token captured from dsh web output");
    }
}

/// The captured token, waiting briefly when the ready probe raced ahead of
/// the announce line (both land within a second or two of the port binding).
fn wait_launch_token(timeout: Duration) -> Option<String> {
    let deadline = Instant::now() + timeout;
    loop {
        if let Ok(slot) = LAUNCH_TOKEN.lock() {
            if let Some(token) = slot.clone() {
                return Some(token);
            }
        }
        if Instant::now() >= deadline {
            return None;
        }
        std::thread::sleep(Duration::from_millis(200));
    }
}

fn child_tail_push(line: String) {
    if let Ok(mut tail) = CHILD_TAIL.lock() {
        if tail.len() >= CHILD_TAIL_CAP {
            tail.pop_front();
        }
        tail.push_back(line);
    }
}

/// Last `n` lines of the child's console output, oldest first.
pub(crate) fn child_tail_last(n: usize) -> Vec<String> {
    CHILD_TAIL
        .lock()
        .map(|t| t.iter().rev().take(n).rev().cloned().collect())
        .unwrap_or_default()
}

fn child_tail_clear() {
    if let Ok(mut tail) = CHILD_TAIL.lock() {
        tail.clear();
    }
    if let Ok(mut slot) = LAUNCH_TOKEN.lock() {
        *slot = None;
    }
}

/// One-line digest of the tail for log lines.
pub(crate) fn child_tail_excerpt(max_lines: usize) -> String {
    child_tail_last(max_lines).join(" ⏎ ")
}

/// Meaningful digest for error surfaces: Node dumps put the real message
/// ABOVE the stack — the last N lines are often just closing braces and the
/// engine banner (2026-08-25 report: the log showed "} } ⏎ Node.js v24.13.0"
/// while the actual "plugin tree failed to load" line sat unread in the
/// ring). Find the FIRST error-looking headline and excerpt from there,
/// falling back to the plain tail.
pub(crate) fn child_tail_digest(max_lines: usize) -> String {
    let tail = child_tail_last(CHILD_TAIL_CAP);
    if let Some(pos) = tail.iter().position(|line| {
        line.starts_with("Error")
            || line.contains("Cannot find")
            || line.contains("failed to")
            || line.contains("ERR_")
            || line.contains("FATAL")
            || line.contains("Exception")
    }) {
        let end = (pos + max_lines).min(tail.len());
        return tail[pos..end].join(" ⏎ ");
    }
    child_tail_excerpt(max_lines)
}

/// Keep the tail ring fed; runs on its own thread per stream and ends at
/// EOF when the child dies. Every line also passes the launch-token sniffer
/// (the announce rides this same stdout).
fn pump_tail<R: std::io::Read>(stream: R) {
    use std::io::BufRead;
    for line in std::io::BufReader::new(stream).lines() {
        match line {
            Ok(l) => {
                capture_launch_token(&l);
                child_tail_push(l);
            }
            Err(_) => break,
        }
    }
}

/// The package named by dsh's fatal `cannot resolve profile bundle "<pkg>"`
/// — the signature of a bundle pnpm's fresh-release cooldown silently
/// skipped during install (seen 2026-08-18: exit-0 sync, missing bundle,
/// crash loop with zero UI feedback).
fn missing_bundle(tail: &[String]) -> Option<String> {
    const MARKER: &str = "cannot resolve profile bundle \"";
    for line in tail.iter().rev() {
        if let Some(pos) = line.find(MARKER) {
            let rest = &line[pos + MARKER.len()..];
            if let Some(end) = rest.find('"') {
                let pkg = &rest[..end];
                if !pkg.is_empty() {
                    return Some(pkg.to_string());
                }
            }
        }
    }
    None
}

/// Bundle repair runs at most once per app session — a failing repair must
/// not turn into a second crash loop.
static BUNDLE_REPAIR_DONE: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// Install a missing bundle into the web profile with the fresh-release
/// cooldown bypassed — the same override plugin sync uses. Returns whether
/// the caller should retry the candidate.
fn repair_profile_bundle(pkg: &str) -> bool {
    if BUNDLE_REPAIR_DONE.swap(true, std::sync::atomic::Ordering::SeqCst) {
        log_write(
            LogLevel::Warn,
            "[dsh-desktop] bundle repair skipped: already attempted this session",
        );
        return false;
    }
    // Strict name sanity — this string is headed for a shell command.
    let clean = pkg
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, '@' | '/' | '-' | '.' | '_'));
    if !clean {
        log_write(
            LogLevel::Warn,
            &format!("[dsh-desktop] bundle repair skipped: odd package name {pkg:?}"),
        );
        return false;
    }
    let Some(pnpm) = pnpm_path() else {
        log_write(LogLevel::Warn, "[dsh-desktop] bundle repair skipped: pnpm not found");
        return false;
    };
    let home = std::env::var("USERPROFILE").unwrap_or_default();
    let profile_dir = Path::new(&home).join(".dsh").join("profiles").join("web");
    if !profile_dir.is_dir() {
        log_write(
            LogLevel::Warn,
            "[dsh-desktop] bundle repair skipped: web profile dir missing",
        );
        return false;
    }
    supervision_log(&format!("bundle repair: pnpm add {pkg} into web profile (cooldown bypassed)"));
    let cmd = format!(
        "cd /d \"{}\" && \"{}\" add --save-exact {pkg} --config.minimumReleaseAge=0",
        profile_dir.display(),
        pnpm.display()
    );
    run_bounded(&cmd, Duration::from_secs(300), "bundle repair")
}

/// Settings self-heal runs at most once per app session.
static SETTINGS_HEAL_DONE: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// Self-heal `~/.dsh/settings.yaml` when a YAML writer dropped the space
/// after a mapping colon (`key:value` — invalid YAML). 2026-08-18 incident:
/// the web UI's serializer emitted `reasoningEfforts:max`, the hot reload
/// crash-looped dsh web, and the desktop showed an empty window with endless
/// startup retries. Guarded by a full parse both before (is it actually
/// broken?) and after (did the fix make it valid?) — a fix that still fails
/// to parse is refused, and the original is always backed up first.
fn settings_yaml_selfheal() -> bool {
    if SETTINGS_HEAL_DONE.swap(true, std::sync::atomic::Ordering::SeqCst) {
        return false;
    }
    let home = std::env::var("USERPROFILE").unwrap_or_default();
    let path = Path::new(&home).join(".dsh").join("settings.yaml");
    let Ok(text) = std::fs::read_to_string(&path) else {
        return false;
    };
    if yaml_parses(&text) {
        return false; // healthy — the crash is something else
    }
    let backup = path.with_extension("yaml.dshbak");
    let _ = std::fs::copy(&path, &backup);
    let fixed = fix_yaml_colon_spacing(&text);
    if !yaml_parses(&fixed) {
        log_write(
            LogLevel::Error,
            &format!(
                "[dsh-desktop] settings.yaml 解析失败且冒号空格修复无效;手动编辑 {} 保证每个 key: 后有空格(原文件已备份 {})",
                path.display(),
                backup.display()
            ),
        );
        return false;
    }
    match std::fs::write(&path, &fixed) {
        Ok(()) => {
            log_write(
                LogLevel::Warn,
                &format!(
                    "[dsh-desktop] settings.yaml 自动修复:为缺失空格的 key: 补空格(疑似 Web UI 序列化器缺陷,建议反馈);原文件备份 {}",
                    backup.display()
                ),
            );
            true
        }
        Err(e) => {
            log_write(
                LogLevel::Error,
                &format!("[dsh-desktop] settings.yaml 修复写入失败:{e}"),
            );
            false
        }
    }
}

/// Full-file YAML parse check (round-trip guard: nothing invalid is ever
/// written back).
fn yaml_parses(text: &str) -> bool {
    serde_yaml::from_str::<serde_yaml::Value>(text).is_ok()
}

/// Insert the missing space in block-mapping `key:value` lines. Lines inside
/// literal/indented block scalars (`|` or `>`) are left untouched so string
/// content is never rewritten.
fn fix_yaml_colon_spacing(text: &str) -> String {
    let mut out = String::with_capacity(text.len() + 16);
    let mut block_indent: Option<usize> = None;
    for line in text.lines() {
        let indent = line.len() - line.trim_start().len();
        if let Some(depth) = block_indent {
            if line.trim().is_empty() || indent > depth {
                out.push_str(line);
                out.push('\n');
                continue;
            }
            block_indent = None;
        }
        if let Some(fixed) = fix_one_colon(line) {
            out.push_str(&fixed);
        } else {
            let trimmed = line.trim_end();
            if trimmed.ends_with('|') || trimmed.ends_with('>') {
                block_indent = Some(indent);
            }
            out.push_str(line);
        }
        out.push('\n');
    }
    out
}

/// `key:value` → `key: value` for one line, when the first colon is
/// immediately followed by a non-space, non-comment character. Quoted keys
/// are left alone (conservative).
fn fix_one_colon(line: &str) -> Option<String> {
    let indent_len = line.len() - line.trim_start().len();
    let rest = &line[indent_len..];
    let rest = rest.strip_prefix("- ").unwrap_or(rest);
    let colon = rest.find(':')?;
    let (key, value) = rest.split_at(colon);
    let value = &value[1..];
    if value.is_empty() || value.starts_with(' ') || value.starts_with('\t') || value.starts_with('#') {
        return None;
    }
    if key.trim().is_empty() || key.contains('"') || key.contains('\'') {
        return None;
    }
    let prefix_len = line.len() - rest.len();
    Some(format!(
        "{}{}: {}",
        &line[..prefix_len],
        key,
        value
    ))
}

/// pnpm as an absolute path: PATH first, then the npm-global fallback (GUI
/// processes can start with a PATH that doesn't resolve .cmd shims).
fn pnpm_path() -> Option<PathBuf> {
    where_first("pnpm")
        .map(PathBuf::from)
        .or_else(|| {
            std::env::var("APPDATA")
                .ok()
                .map(|a| Path::new(&a).join("npm").join("pnpm.cmd"))
                .filter(|p| p.is_file())
        })
}

/// Run one hidden shell command with a hard kill at the cap (repairs can be
/// big installs; nothing downstream may stall on them).
pub(crate) fn run_bounded(cmd: &str, cap: Duration, what: &str) -> bool {
    let mut command = Command::new("cmd");
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        command.raw_arg(format!("/S /C \"{cmd}\""));
        command.creation_flags(CREATE_NO_WINDOW);
    }
    #[cfg(not(windows))]
    {
        command.arg("/C").arg(cmd);
    }
    command.env("CI", "true");
    let Ok(mut child) = command.spawn() else {
        log_write(
            LogLevel::Warn,
            &format!("[dsh-desktop] {what} spawn failed: {cmd}"),
        );
        return false;
    };
    let deadline = Instant::now() + cap;
    loop {
        match child.try_wait() {
            Ok(Some(status)) => {
                let ok = status.success();
                log_write(
                    if ok { LogLevel::Info } else { LogLevel::Warn },
                    &format!(
                        "[dsh-desktop] {what} {} (exit {})",
                        if ok { "ok" } else { "FAILED" },
                        status.code().unwrap_or(-1)
                    ),
                );
                return ok;
            }
            Ok(None) if Instant::now() > deadline => {
                let _ = child.kill();
                let _ = child.wait();
                log_write(LogLevel::Warn, &format!("[dsh-desktop] {what} timed out ({cap:?}, killed)"));
                return false;
            }
            Ok(None) => std::thread::sleep(Duration::from_millis(500)),
            Err(e) => {
                log_write(LogLevel::Warn, &format!("[dsh-desktop] {what} wait failed: {e}"));
                return false;
            }
        }
    }
}

/// Log severity for the shell's own event log.
#[derive(Clone, Copy)]
pub(crate) enum LogLevel {
    Info,
    Warn,
    Error,
}

impl LogLevel {
    fn tag(self) -> &'static str {
        match self {
            LogLevel::Info => "INFO",
            LogLevel::Warn => "WARN",
            LogLevel::Error => "ERROR",
        }
    }
}

/// Local time via GetLocalTime — this is a Windows-only shell, so raw FFI
/// beats pulling a datetime crate. Returns (date, time, filename stamp):
/// ("2026-08-18", "12:40:03", "2026-08-18T12-40-03-123").
#[cfg(windows)]
pub(crate) fn local_time_parts() -> (String, String, String) {
    #[repr(C)]
    struct SysTime {
        year: u16,
        month: u16,
        _dow: u16,
        day: u16,
        hour: u16,
        minute: u16,
        second: u16,
        millis: u16,
    }
    extern "system" {
        fn GetLocalTime(system_time: *mut SysTime);
    }
    let mut st = SysTime {
        year: 0,
        month: 0,
        _dow: 0,
        day: 0,
        hour: 0,
        minute: 0,
        second: 0,
        millis: 0,
    };
    unsafe { GetLocalTime(&mut st) };
    (
        format!("{:04}-{:02}-{:02}", st.year, st.month, st.day),
        format!("{:02}:{:02}:{:02}", st.hour, st.minute, st.second),
        format!(
            "{:04}-{:02}-{:02}T{:02}-{:02}-{:02}-{:03}",
            st.year, st.month, st.day, st.hour, st.minute, st.second, st.millis
        ),
    )
}

#[cfg(not(windows))]
pub(crate) fn local_time_parts() -> (String, String, String) {
    ("1970-01-01".into(), "00:00:00".into(), "1970-01-01T00-00-00-000".into())
}

/// Append one raw line to the shared log (no timestamp/level) — session
/// banner lines only.
fn log_raw(line: &str) {
    use std::io::Write;
    let path = log_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(&path) {
        let _ = writeln!(file, "{line}");
    }
}

/// The one writer for shell events: `[YYYY-MM-DD HH:MM:SS] [LEVEL] message`.
/// Everything the shell wants remembered goes through here so the log tab
/// and diagnostic bundles read uniformly. DSH's own server output is NOT
/// logged (it keeps its own logs under ~/.dsh/logs) — this log records only
/// the shell's startup and runtime events, a few dozen lines per session.
pub(crate) fn log_write(level: LogLevel, message: &str) {
    use std::io::Write;
    let (date, time, _) = local_time_parts();
    let path = log_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(&path) {
        let _ = writeln!(file, "[{date} {time}] [{}] {message}", level.tag());
    }
}

/// Shell event at Info level (shorthand for the common case).
fn supervision_log(line: &str) {
    log_write(LogLevel::Info, line);
}

/// Shell event at Warn level.
fn supervision_warn(line: &str) {
    log_write(LogLevel::Warn, line);
}

/// First `where <name>` hit, windowless.
pub(crate) fn where_first(name: &str) -> Option<String> {
    let mut command = Command::new("where");
    command.arg(name);
    apply_no_window(&mut command);
    let output = command.output().ok()?;
    if !output.status.success() {
        return None;
    }
    let text = console_decode(&output.stdout);
    text.lines()
        .next()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .map(str::to_string)
}

/// One captured run of a program (`node --version` style). No-window flags
/// matter here: env_info now runs at startup, and a flashing console per
/// probe (node/powershell) would pop terminals on every launch.
fn run_capture(program: &str, args: &[&str]) -> Option<String> {
    use std::io::Read;
    let mut command = Command::new(program);
    command.args(args);
    apply_no_window(&mut command);
    let mut child = command
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::null())
        .spawn()
        .ok()?;
    // read_to_end + console_decode: read_to_string would hard-fail on
    // non-UTF-8 console bytes (GBK output never reached the panel at all).
    let mut out_bytes = Vec::new();
    if let Some(mut stdout) = child.stdout.take() {
        let _ = stdout.read_to_end(&mut out_bytes);
    }
    let _ = child.wait();
    let trimmed = console_decode(&out_bytes).trim().to_string();
    (!trimmed.is_empty()).then_some(trimmed)
}

/// Pid currently listening on the DSH port.
pub(crate) fn port_listener_pid() -> Option<u32> {
    let mut command = Command::new("netstat");
    command.args(["-ano", "-p", "tcp"]);
    apply_no_window(&mut command);
    let output = command.output().ok()?;
    let text = console_decode(&output.stdout);
    let suffix = format!(":{DSH_PORT}");
    text.lines().find_map(|line| {
        let fields: Vec<&str> = line.split_whitespace().collect();
        (fields.len() >= 5 && fields[0] == "TCP" && fields[1].ends_with(&suffix) && fields[4] != "0")
            .then(|| fields[4].parse::<u32>().ok())
            .flatten()
    })
}

/// Who owns the DSH port: pid, command line, and whether the parent chain
/// leads back to this app (ours) or to an external instance. PowerShell does
/// the chain walk; JSON keeps the boundary parse-free.
pub(crate) fn port_owner_info() -> Option<Value> {
    let pid = port_listener_pid()?;
    let script = format!(
        "$p = Get-CimInstance Win32_Process -Filter 'ProcessId={pid}'; \
         if ($null -eq $p) {{ exit 1 }}; \
         $names = @($p.Name); $cur = $p; $owned = $false; \
         for ($i = 0; $i -lt 5 -and $null -ne $cur; $i++) {{ \
           if ($cur.Name -eq 'dsh-desktop-windowos.exe') {{ $owned = $true; break }}; \
           $cur = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $cur.ParentProcessId); \
           if ($null -ne $cur) {{ $names += $cur.Name }} \
         }}; \
         [pscustomobject]@{{ pid = $p.ProcessId; cmd = $p.CommandLine; chain = ($names -join ' <- '); owned = $owned }} | ConvertTo-Json -Compress"
    );
    let output = run_capture("powershell", &["-NoProfile", "-Command", &script])?;
    serde_json::from_str(&output).ok()
}

/// Plugin package versions installed in the user's web profile.
fn profile_plugin_versions() -> Value {
    let read_version = |name: &str| -> Value {
        let home = std::env::var("USERPROFILE").unwrap_or_default();
        let manifest = Path::new(&home)
            .join(".dsh")
            .join("profiles")
            .join("web")
            .join("node_modules")
            .join(name)
            .join("package.json");
        std::fs::read_to_string(manifest)
            .ok()
            .and_then(|text| serde_json::from_str::<Value>(&text).ok())
            .and_then(|doc| doc["version"].as_str().map(str::to_string))
            .map(Value::String)
            .unwrap_or(Value::Null)
    };
    json!({
        "dshDesktopPlugin": read_version("dsh-desktop-plugin"),
        "dshmarket": read_version("dshmarket"),
    })
}

/// Last `n` lines of the shared shell log for the console pane.
pub(crate) fn log_tail(n: usize) -> Vec<String> {
    std::fs::read_to_string(log_path())
        .map(|text| {
            let lines: Vec<&str> = text.lines().collect();
            let start = lines.len().saturating_sub(n);
            lines[start..].iter().map(|l| l.to_string()).collect()
        })
        .unwrap_or_default()
}

/// Total bytes under `dir`, bounded: the walk stops counting past 50k files
/// (returns the partial sum) so a huge profile tree can't stall env_info.
fn dir_size_bounded(dir: &Path) -> Option<u64> {
    fn walk(dir: &Path, seen: &mut u32, total: &mut u64) {
        const MAX_FILES: u32 = 50_000;
        let Ok(entries) = std::fs::read_dir(dir) else { return };
        for entry in entries.flatten() {
            if *seen >= MAX_FILES {
                return;
            }
            let Ok(meta) = entry.metadata() else { continue };
            if meta.is_dir() {
                walk(&entry.path(), seen, total);
            } else {
                *seen += 1;
                *total += meta.len();
            }
        }
    }
    if !dir.is_dir() {
        return None;
    }
    let (mut seen, mut total) = (0u32, 0u64);
    walk(dir, &mut seen, &mut total);
    Some(total)
}

/// The version of the dsh package actually serving `web`: read from the
/// running process's own command line when possible (points at the real
/// install even in attach mode), else derived from the dsh launcher on PATH
/// or a local install.
fn dsh_web_version() -> Option<String> {
    crate::backend_update::running_version()
}

/// Environment facts for the env panel, modelled on Comfy Desktop's
/// StatusFactPanel data shape: every field is gathered independently and
/// degrades to null — the panel never hangs on a probe.
pub fn env_info(app: &AppHandle) -> Value {
    let home = std::env::var("USERPROFILE").unwrap_or_default();
    let settings = read_settings();
    let profile_dir = Path::new(&home).join(".dsh").join("profiles").join("web");
    let install_dir = tauri::utils::platform::current_exe()
        .ok()
        .and_then(|exe| exe.parent().map(|p| p.display().to_string()));
    let info = json!({
        "app": {
            "version": app.package_info().version.to_string(),
            "installDir": install_dir,
        },
        "dsh": {
            "portAnswering": probe_ready_once(),
            "webVersion": dsh_web_version(),
            "owner": port_owner_info(),
            "dshCmd": std::env::var("DSH_CMD").ok().filter(|v| !v.trim().is_empty()),
            "dshCwd": std::env::var("DSH_CWD").ok().filter(|v| !v.trim().is_empty()),
            "customPath": settings.get("customDshPath").and_then(Value::as_str),
            "whereDsh": where_first("dsh"),
            "localInstall": find_local_install().map(|(shim, root)| json!({ "shim": shim.display().to_string(), "root": root.display().to_string() })),
            "preferNpx": prefer_npx(),
        },
        "node": {
            "path": where_first("node"),
            "version": run_capture("node", &["--version"]),
        },
        "plugins": profile_plugin_versions(),
        "profileDir": profile_dir.display().to_string(),
        "logDir": log_path().parent().map(|p| p.display().to_string()),
        // Where the DSH child actually runs: explicit override, else the
        // effective default (user profile).
        "workspaceDir": std::env::var("DSH_CWD")
            .ok()
            .filter(|v| !v.trim().is_empty())
            .or_else(|| Some(home.clone()))
            .filter(|v| !v.is_empty()),
        "cacheDir": Option::<String>::None,
        "profileSizeBytes": dir_size_bounded(&profile_dir),
        "logTail": log_tail(25),
    });
    // The probes run windowless; leave a breadcrumb in the shared log so the
    // panel's log tab shows that a gather just happened (and when).
    supervision_log("env_info gathered (port/where/node/plugins)");
    info
}

/// Watch the owned DSH child and heal the stack when it dies unexpectedly
/// (a DSH crash, or dshmarket's self-restart killing the host for an update).
/// Expected exits (teardown / tray restart) set INTENTIONAL_STOP first.
fn supervise_child(app: AppHandle, mut child: Child, pid: u32, spawned_at: Instant) {
    supervision_log(&format!("supervisor armed for dsh web pid {pid}"));
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) => {}
            Err(_) => return,
        }
        std::thread::sleep(Duration::from_millis(500));
    }
    let _ = child.wait(); // reap
    if INTENTIONAL_STOP.load(std::sync::atomic::Ordering::Relaxed) {
        supervision_log(&format!("supervised dsh web (pid {pid}) stopped intentionally"));
        return;
    }
    supervision_log(&format!("supervised dsh web (pid {pid}) exited unexpectedly; healing"));
    // The child's last words name the real cause (e.g. a cooldown-skipped
    // profile bundle) — keep them in the log and in user-facing errors.
    let excerpt = child_tail_digest(6);
    if !excerpt.is_empty() {
        log_write(LogLevel::Error, &format!("[child] {excerpt}"));
    }
    // Crash-loop guard: three consecutive children that lived under 30s stop
    // the auto-respawn and surface an error instead of spinning forever.
    if spawned_at.elapsed() < Duration::from_secs(30) {
        let deaths = QUICK_DEATHS.fetch_add(1, std::sync::atomic::Ordering::SeqCst) + 1;
        if deaths >= 3 {
            supervision_warn(&format!("supervised dsh web (pid {pid}) crashed 3x quickly; auto-respawn stopped"));
            let _ = app.emit(
                "dsh-status",
                json!({ "status": "error", "message": format!("DSH 反复意外退出,已停止自动重启{}\n完整日志:面板→日志,或 %LOCALAPPDATA%\\dsh-desktop\\dsh.log;可用托盘「重启 dsh web(后端)」重试", if excerpt.is_empty() { String::new() } else { format!("\n最近输出: {excerpt}") }) }),
            );
            return;
        }
    } else {
        QUICK_DEATHS.store(0, std::sync::atomic::Ordering::SeqCst);
    }
    // dshmarket's restart helper races a replacement onto 3080 ~1.5s after
    // the host dies; that replacement is an orphan outside our supervision
    // (a later quit would not stop it), so let it land, clear the port, and
    // spawn our own child instead.
    std::thread::sleep(Duration::from_millis(2500));
    kill_port_listeners();
    let deadline = Instant::now() + Duration::from_secs(10);
    while probe_ready_once() && Instant::now() < deadline {
        std::thread::sleep(Duration::from_millis(500));
    }
    // startup() re-emits `ready`, and the persistent shell reloads its
    // webchat iframe on that event — no window.eval navigation to a page
    // we no longer control.
    startup(app.clone());
}

/// Frontend "使用此路径启动" from the notfound dialog: remember the
/// user-entered dsh executable and retry startup with it leading the chain.
/// Returns Err with a user-facing message when the path does not exist.
pub fn set_custom_path(app: &AppHandle, raw: String) -> Result<(), String> {
    let path = raw.trim().trim_matches('"').to_string();
    if path.is_empty() {
        return Err("路径不能为空".to_string());
    }
    if !Path::new(&path).is_file() {
        return Err(format!("找不到文件:{path}(需要 dsh.cmd 或 dsh.exe 的完整路径)"));
    }
    let mut settings = read_settings();
    settings["customDshPath"] = json!(path);
    write_settings(settings);
    teardown(app);
    let app2 = app.clone();
    std::thread::spawn(move || startup(app2));
    Ok(())
}

/// The two npm registries the one-click installer may use, probed in
/// parallel at boot; the faster becomes the default and the UI offers the
/// other as an explicit choice.
pub const REGISTRY_NPMJS: &str = "https://registry.npmjs.org";
pub const REGISTRY_NPMMIRROR: &str = "https://registry.npmmirror.com";

/// Time one GET of the package's /latest metadata in ms; None when the
/// registry is unreachable within 4s.
fn probe_registry_ms(base: &str) -> Option<u128> {
    let start = std::time::Instant::now();
    let reached = ureq::get(&format!("{base}/@deepseek-ai/dsh/latest"))
        .timeout(Duration::from_secs(4))
        .call()
        .is_ok();
    reached.then(|| start.elapsed().as_millis())
}

/// Probe both registries in parallel (bounded by one timeout window). The
/// JSON feeds the boot page's source chooser; `fastest` is null when both
/// are unreachable (the UI then falls back to the plain npm default).
pub fn npm_probe() -> Value {
    let npmjs = std::thread::spawn(|| probe_registry_ms(REGISTRY_NPMJS));
    let mirror = std::thread::spawn(|| probe_registry_ms(REGISTRY_NPMMIRROR));
    let npmjs_ms = npmjs.join().unwrap_or(None);
    let mirror_ms = mirror.join().unwrap_or(None);
    let fastest = match (npmjs_ms, mirror_ms) {
        (Some(a), Some(b)) => Some(if a <= b { "npmjs" } else { "npmmirror" }),
        (Some(_), None) => Some("npmjs"),
        (None, Some(_)) => Some("npmmirror"),
        (None, None) => None,
    };
    json!({ "npmjsMs": npmjs_ms, "npmmirrorMs": mirror_ms, "fastest": fastest })
}

/// Frontend "一键全局安装并启动": run `npm install -g @deepseek-ai/dsh`
/// (optionally pinned to one of the two probed registries) and retry
/// startup — afterwards `where dsh` leads the chain permanently. The
/// install (500+ packages) can take minutes; it runs on its own thread and
/// reports progress through the usual `dsh-status` events.
pub fn install_global_npm(app: AppHandle, registry: Option<&str>) {
    if crate::backend_update::busy() || startup_active() { return; }
    // Whitelist: only the two probed registries may enter the command line.
    // Owned because the install thread outlives this call.
    let url = registry
        .filter(|u| *u == REGISTRY_NPMJS || *u == REGISTRY_NPMMIRROR)
        .map(str::to_string);
    let app2 = app.clone();
    std::thread::spawn(move || {
        let (label, spec) = match url {
            Some(u) if u == REGISTRY_NPMMIRROR => (
                "npm 全局安装中(国内镜像,约 1-3 分钟)",
                format!("npm install -g @deepseek-ai/dsh --registry={u}"),
            ),
            Some(u) => (
                "npm 全局安装中(官方源,约 1-3 分钟)",
                format!("npm install -g @deepseek-ai/dsh --registry={u}"),
            ),
            None => (
                "npm 全局安装中(约 1-3 分钟)",
                "npm install -g @deepseek-ai/dsh".to_string(),
            ),
        };
        let _ = app2.emit(
            "dsh-status",
            json!({ "status": "starting", "method": label }),
        );
        let mut command = Command::new("cmd");
        #[cfg(windows)]
        {
            use std::os::windows::process::CommandExt;
            command.raw_arg(format!("/S /C \"{spec}\""));
        }
        #[cfg(not(windows))]
        {
            command.arg("-c").arg(&spec);
        }
        command
            .current_dir(std::env::var("USERPROFILE").unwrap_or_else(|_| ".".to_string()))
            .stdout(log_stdio())
            .stderr(null_stdio());
        apply_no_window(&mut command);
        match command.output() {
            Ok(output) if output.status.success() => {
                retry(app2);
            }
            Ok(output) => {
                let _ = app2.emit(
                    "dsh-status",
                    json!({
                        "status": "error",
                        "message": format!(
                            "npm 全局安装失败(退出码 {})。详见日志 {}\\dsh.log,或改用「下载并启动(npx)」/手动路径。",
                            output.status.code().unwrap_or(-1),
                            std::env::var("LOCALAPPDATA").unwrap_or_default(),
                        ),
                    }),
                );
            }
            Err(error) => {
                let _ = app2.emit(
                    "dsh-status",
                    json!({ "status": "error", "message": format!("无法运行 npm(需要已安装 Node.js):{error}") }),
                );
            }
        }
    });
}

/// Re-arm after a failure: tear down any stale owned subprocess, then startup.
pub fn retry(app: AppHandle) {
    if crate::backend_update::busy() || startup_active() { return; }
    teardown(&app);
    let app2 = app.clone();
    std::thread::spawn(move || startup(app2));
}

/// Frontend "下载并启动" after `notfound` (or as an error fallback): persist the
/// consent so future cold starts include the npx candidate automatically, then
/// run exactly that candidate now.
pub fn download_and_start(app: AppHandle) {
    if crate::backend_update::busy() || startup_active() { return; }
    save_prefer_npx(true);
    teardown(&app);
    let app2 = app.clone();
    std::thread::spawn(move || {
        let Ok(_gate) = START_GATE.try_lock() else { return; };
        let _lifecycle = StartupGuard::new();
        startup_report(&app2, json!({"status":"starting", "phase":"discovering"}));
        if probe_ready_once() { emit_ready(&app2, true, None); return; }
        let home = std::env::var("USERPROFILE").unwrap_or_else(|_| ".".to_string());
        let cwd = std::env::var("DSH_CWD")
            .ok()
            .filter(|dir| Path::new(dir).is_dir())
            .unwrap_or_else(|| {
                let fixed = Path::new(&home).join(".dsh");
                let _ = std::fs::create_dir_all(&fixed);
                fixed.display().to_string()
            });
        let candidate = npx_candidate(cwd);
        let _ = app2.emit(
            "dsh-status",
            json!({ "status": "starting", "method": candidate.label }),
        );
        if let Attempt::Failed(reason) | Attempt::Blocked(reason) = try_candidate(&app2, &candidate) {
            startup_report(
                &app2,
                json!({
                    "status": "error",
                    "message": format!("「{}」{}", candidate.label, reason),
                }),
            );
        }
    });
}

/// Tray "重启 dsh web(后端)": tear down + re-run the startup chain. The shell
/// stays loaded the whole time: a `starting` event swaps it back to the boot
/// view, and the chain's `ready` events reload the webchat iframe — the same
/// flow as a cold start, no page navigation involved.
/// Stop the DSH backend unconditionally: tear down the owned tree (if we
/// spawned it) and clear whatever still listens on 3080 — an attached
/// external instance included. The full app restart uses this: leaving a
/// stale attached backend behind meant plugins announcing 「重启后生效」
/// never actually loaded (2026-08-19 report).
pub fn stop_backend(app: &AppHandle) {
    teardown(app);
    kill_port_listeners();
}

pub fn restart(app: AppHandle) {
    if crate::backend_update::busy() || startup_active() { return; }
    // Pop the window first so a restart triggered while hidden in the tray is
    // visibly underway instead of looking like a no-op.
    crate::show_main_window(&app);
    std::thread::spawn(move || {
        let _lifecycle = StartupGuard::new();
        let _ = app.emit(
            "dsh-status",
            json!({ "status": "starting", "method": "正在重启 dsh web" }),
        );
        stop_backend(&app);
        // Wait for the old instance to stop answering so startup's attach
        // probe cannot latch onto the dying server and report ready.
        let deadline = Instant::now() + Duration::from_secs(10);
        while probe_ready_once() && Instant::now() < deadline {
            std::thread::sleep(Duration::from_millis(500));
        }
        startup(app.clone());
    });
}

/// Kill any process still listening on the DSH port: an attached instance we
/// never spawned, or a straggler the owned-tree taskkill missed. Locale-safe:
/// matches the numeric local-address column, not the state text.
fn kill_port_listeners() {
    let mut command = Command::new("netstat");
    command.args(["-ano", "-p", "tcp"]);
    apply_no_window(&mut command);
    let Ok(output) = command.output() else {
        return;
    };
    let text = console_decode(&output.stdout);
    let suffix = format!(":{DSH_PORT}");
    for line in text.lines() {
        let fields: Vec<&str> = line.split_whitespace().collect();
        if fields.len() >= 5
            && fields[0] == "TCP"
            && fields[1].ends_with(&suffix)
            && fields[4] != "0"
        {
            if let Ok(pid) = fields[4].parse::<u32>() {
                kill_tree(pid);
            }
        }
    }
}

/// Tear down the owned subprocess tree (if we spawned one). Safe to call from
/// attached mode — it is a no-op then.
pub fn teardown(app: &AppHandle) {
    INTENTIONAL_STOP.store(true, std::sync::atomic::Ordering::Relaxed);
    let state = app.state::<DshState>();
    let mut guard = state.inner.lock().unwrap();
    if let Some(inner) = guard.take() {
        // Child::kill only reaps the cmd shim on Windows; taskkill /T kills the
        // whole node tree so no orphan keeps holding 3080. The supervisor
        // thread reaps the Child and stays quiet (intentional stop).
        kill_tree(inner.pid);
    }
}

/// Append an attempt header so failures are attributable.
fn log_attempt(candidate: &Candidate) {
    log_write(
        LogLevel::Info,
        &format!("===== 启动尝试: {} =====", candidate.label),
    );
}

/// Spawn a shell command detached, no console window, with stdout+stderr
/// piped into the bounded in-memory tail ring (crash causes stay visible;
/// the unbounded stream is NOT logged — DSH keeps its own logs).
fn spawn_command(cmd: &str, cwd: &str) -> std::io::Result<(Child, std::sync::mpsc::Receiver<()>)> {
    let mut command = Command::new("cmd");
    // pnpm/npx/dsh are .cmd shims on Windows, so route through cmd /C; the
    // candidate command is a shell command string either way. Pass it via
    // `raw_arg` as `/S /C "…"`: std's automatic quoting would re-wrap the
    // whole string and backslash-escape the inner quotes around
    // space-containing paths, which cmd then misparses — `/S` strips only
    // the outermost quote pair, preserving our inner quotes verbatim.
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        command.raw_arg(format!("/S /C \"{cmd}\""));
    }
    #[cfg(not(windows))]
    {
        command.arg("/C").arg(cmd);
    }
    crate::explorer_compat::configure(&mut command)?;
    command.current_dir(cwd);
    command.stdout(Stdio::piped()).stderr(Stdio::piped());
    apply_no_window(&mut command);
    let mut child = command.spawn()?;
    let (sent, drained) = std::sync::mpsc::channel();
    if let Some(out) = child.stdout.take() {
        let sent = sent.clone();
        std::thread::spawn(move || { pump_tail(out); let _ = sent.send(()); });
    }
    if let Some(err) = child.stderr.take() {
        std::thread::spawn(move || { pump_tail(err); let _ = sent.send(()); });
    }
    Ok((child, drained))
}

/// Rotate the log ComfyUI-style at session start: archive the previous
/// session under a timestamped name, keep only the 20 newest archives, and
/// banner the fresh file. Runs before any child spawns, so every later
/// append handle lands on the new file.
pub(crate) fn rotate_log(app: &AppHandle) {
    let path = log_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
        if path.exists() {
            let (_, _, stamp) = local_time_parts();
            let _ = std::fs::rename(&path, path.with_file_name(format!("dsh.log_{stamp}.log")));
            let mut archives: Vec<_> = std::fs::read_dir(parent)
                .map(|rd| {
                    rd.filter_map(|e| e.ok())
                        .map(|e| e.path())
                        .filter(|p| {
                            p.file_name()
                                .map(|n| n.to_string_lossy().starts_with("dsh.log_"))
                                .unwrap_or(false)
                        })
                        .collect()
                })
                .unwrap_or_default();
            archives.sort();
            while archives.len() > 20 {
                let _ = std::fs::remove_file(&archives[0]);
                archives.remove(0);
            }
        }
    }
    let (date, time, _) = local_time_parts();
    let version = app.package_info().version.to_string();
    let exe = tauri::utils::platform::current_exe()
        .map(|p| p.display().to_string())
        .unwrap_or_default();
    let dir = path
        .parent()
        .map(|p| p.display().to_string())
        .unwrap_or_default();
    log_raw(&format!("** dsh-desktop session: {date} {time}"));
    log_raw(&format!("** app: v{version} ({exe})"));
    log_raw(&format!("** log dir: {dir}"));
}

/// Two append handles to the same log file, one each for stdout/stderr.
fn log_streams() -> std::io::Result<(Stdio, Stdio)> {
    let path = log_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let stdout = OpenOptions::new().create(true).append(true).open(&path)?;
    let stderr = stdout.try_clone()?;
    Ok((Stdio::from(stdout), Stdio::from(stderr)))
}

/// One append handle to the log (stdout only).
fn log_stdio() -> Stdio {
    match log_streams() {
        Ok((stdout, _)) => stdout,
        Err(_) => Stdio::null(),
    }
}

fn null_stdio() -> Stdio {
    Stdio::null()
}

fn log_path() -> std::path::PathBuf {
    let base = std::env::var("LOCALAPPDATA").unwrap_or_else(|_| ".".to_string());
    std::path::PathBuf::from(base)
        .join("dsh-desktop")
        .join("dsh.log")
}

/// Kill a process *tree* by root PID. `cmd /C …` → node is a grandchild; `/T`
/// walks the tree so nothing survives on 3080.
pub(crate) fn kill_tree(pid: u32) {
    let mut command = Command::new("taskkill");
    command.args(["/PID", &pid.to_string(), "/T", "/F"]);
    apply_no_window(&mut command);
    let _ = command.status();
}

#[cfg(windows)]
fn apply_no_window(command: &mut Command) {
    use std::os::windows::process::CommandExt;
    command.creation_flags(CREATE_NO_WINDOW);
}

#[cfg(not(windows))]
fn apply_no_window(_command: &mut Command) {}

/// Decode captured console output. Windowless children (CREATE_NO_WINDOW)
/// print in the console code page — GBK on zh-CN systems — so raw UTF-8
/// decoding mangled every non-ASCII path (`where dsh` hit → garbled spawn
/// target, issue #4). Valid UTF-8 still wins so chcp 65001 machines and
/// ASCII output are untouched.
pub(crate) fn console_decode(bytes: &[u8]) -> String {
    if let Ok(text) = std::str::from_utf8(bytes) {
        return text.to_string();
    }
    oem_decode(bytes).unwrap_or_else(|| String::from_utf8_lossy(bytes).into_owned())
}

/// Best-effort decode via the system OEM code page; `None` keeps the caller's
/// lossy fallback alive on non-Windows or conversion failure.
#[cfg(windows)]
fn oem_decode(bytes: &[u8]) -> Option<String> {
    use windows_sys::Win32::Globalization::{MultiByteToWideChar, CP_OEMCP, MB_PRECOMPOSED};
    if bytes.is_empty() {
        return None;
    }
    // No MB_ERR_INVALID_CHARS: unmappable bytes become the default char
    // instead of failing the whole buffer.
    let flags = MB_PRECOMPOSED;
    unsafe {
        let len = MultiByteToWideChar(
            CP_OEMCP,
            flags,
            bytes.as_ptr(),
            bytes.len() as i32,
            std::ptr::null_mut(),
            0,
        );
        if len <= 0 {
            return None;
        }
        let mut wide = vec![0u16; len as usize];
        let written = MultiByteToWideChar(
            CP_OEMCP,
            flags,
            bytes.as_ptr(),
            bytes.len() as i32,
            wide.as_mut_ptr(),
            len,
        );
        if written <= 0 {
            return None;
        }
        Some(String::from_utf16_lossy(&wide[..written as usize]))
    }
}

#[cfg(not(windows))]
fn oem_decode(_bytes: &[u8]) -> Option<String> {
    None
}

/// Windows personalization「应用选择浅色」switch (HKCU). Defaults to dark
/// when the key is absent, matching stock Windows styling.
///
/// Read once at window creation: tauri-runtime-wry forwards the window theme
/// into WebView2's preferred color scheme ONLY at build time, so the shell
/// pins the scheme explicitly instead of trusting the runtime default (which
/// surfaced as issue #8's dark-page-on-light-system report).
pub(crate) fn system_apps_dark() -> bool {
    use winreg::enums::HKEY_CURRENT_USER;
    let hkcu = winreg::RegKey::predef(HKEY_CURRENT_USER);
    hkcu.open_subkey("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize")
        .and_then(|k| k.get_value::<u32, _>("AppsUseLightTheme"))
        .map(|light| light == 0)
        .unwrap_or(true)
}

/// Locate `~/.dsh/.credentials.yaml`, refusing suspicious USERPROFILE
/// values (empty or containing `..` traversal segments).
fn credentials_yaml_path() -> Option<std::path::PathBuf> {
    let home = std::env::var("USERPROFILE").ok()?;
    if home.is_empty() || home.split(['/', '\\']).any(|seg| seg == "..") {
        return None;
    }
    Some(Path::new(&home).join(".dsh").join(".credentials.yaml"))
}

/// Extract the browser-session token from the text of
/// `~/.dsh/.credentials.yaml` as written by BrowserAuth-enabled dsh builds
/// (`client-connection.browser-session`). Defensive: missing keys, foreign
/// shapes (e.g. 0.1.1-rc.2's provider `refs` map), malformed YAML and blank
/// values all yield None — the caller then falls back to token-less URLs.
fn browser_session_token_from_yaml(text: &str) -> Option<String> {
    let value: serde_yaml::Value = serde_yaml::from_str(text).ok()?;
    let token = value
        .get("client-connection")?
        .get("browser-session")?
        .as_str()?
        .trim();
    let usable = !token.is_empty()
        && token.len() >= 20
        && token.chars().all(|c| !c.is_whitespace() && !c.is_control());
    usable.then(|| token.to_string())
}

/// Read the browser-session token from the live credentials file.
pub(crate) fn browser_session_token() -> Option<String> {
    let path = credentials_yaml_path()?;
    let text = std::fs::read_to_string(path).ok()?;
    browser_session_token_from_yaml(&text)
}

// --- webchat URL resolution: adapt to the dsh version's auth model (v1.6.49)
//
// dsh 0.1.2+ replaced the persistent yaml token with a per-process launch
// token (stdout-announced once) plus a signed browser cookie (HttpOnly,
// SameSite=Strict, 30 days, minted by GET /?token=<launch>). The shell page
// itself is tauri.localhost while the webchat iframe is 127.0.0.1:3080 — a
// cross-site embedding — so the Strict cookie is NEVER attached inside the
// iframe (verified live: the plain ?token= iframe lands on the 401 page).
// The working path: Rust performs the exchange itself, then plants the very
// same cookie into WebView2's jar as SameSite=None+Secure (127.0.0.1 is a
// trustworthy origin; the server only verifies the signed value, never the
// SameSite attribute). The iframe then loads the plain URL carrying it.

/// A `dsh-auth-…` browser-session cookie minted by the token exchange.
struct SessionCookie {
    name: String,
    value: String,
    max_age: u64,
}

/// Parse the exchange redirect's `Set-Cookie` header
/// (`dsh-auth-…=v1.…; Max-Age=2592000; Path=/; …`). Only `dsh-auth-` names
/// ever pass — a foreign 303 must not plant anything in the webview jar.
fn parse_session_cookie(header: &str) -> Option<SessionCookie> {
    let (pair, attrs) = header.split_once(';')?;
    let (name, value) = pair.split_once('=')?;
    let name = name.trim();
    let value = value.trim();
    if !name.starts_with("dsh-auth-") || value.len() < 24 {
        return None;
    }
    let mut max_age = 30 * 24 * 3600;
    for attr in attrs.split(';') {
        if let Some(v) = attr.trim().strip_prefix("Max-Age=") {
            if let Ok(secs) = v.trim().parse::<u64>() {
                max_age = secs;
            }
        }
    }
    Some(SessionCookie {
        name: name.to_string(),
        value: value.to_string(),
        max_age,
    })
}

/// Marker noting which planted cookie should still be sitting in the WebView2
/// jar. Purely advisory (the jar is the real state and HttpOnly cookies can't
/// be re-read without COM ceremony) — it decides whether an auth-less attach
/// mode deserves the "cannot authenticate this backend" hint.
fn planted_cookie_marker_path() -> std::path::PathBuf {
    log_path()
        .parent()
        .unwrap_or_else(|| Path::new("."))
        .join("webauth-cookie.marker")
}

/// Remember the planted cookie's expiry; any write failure is ignored (the
/// marker only gates a UI hint, never a functional path).
fn mark_planted_cookie(expires_at_unix: u64) {
    let _ = std::fs::write(planted_cookie_marker_path(), expires_at_unix.to_string());
}

/// Whether a cookie we planted should still be alive in the jar.
fn planted_cookie_alive() -> bool {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    std::fs::read_to_string(planted_cookie_marker_path())
        .ok()
        .and_then(|text| text.trim().parse::<u64>().ok())
        .is_some_and(|expires| expires > now)
}

/// One redirect-refusing GET. ureq 2.x hands 4xx/5xx back as
/// Err(Error::Status(code, response)); normalize to (status, response) with
/// 0 = unreachable/timeout so callers treat it as "let the iframe show it".
fn http_get_no_redirect(url: &str) -> (u16, Option<ureq::Response>) {
    let agent = ureq::AgentBuilder::new().redirects(0).build();
    match agent.get(url).timeout(Duration::from_secs(3)).call() {
        Ok(resp) => (resp.status(), Some(resp)),
        Err(ureq::Error::Status(code, resp)) => (code, Some(resp)),
        Err(_) => (0, None),
    }
}

/// Plant the exchanged cookie in WebView2's jar as SameSite=None + Secure so
/// the cross-site iframe carries it (the server never checks the SameSite
/// attribute — only the signature and expiry inside the value). Runs the COM
/// sequence on the main thread via with_webview and waits for its verdict.
fn inject_webview2_cookie(app: &AppHandle, cookie: &SessionCookie) -> bool {
    let Some(webview_window) = app.get_webview_window("main") else {
        supervision_warn("webchat auth: main webview missing; cookie not planted");
        return false;
    };
    let name = cookie.name.clone();
    let value = cookie.value.clone();
    let max_age = cookie.max_age;
    let (tx, rx) = std::sync::mpsc::channel::<Result<(), String>>();
    let dispatched = webview_window.with_webview(move |webview| {
        let verdict = (|| -> Result<(), String> {
            #[cfg(windows)]
            unsafe {
                use webview2_com::Microsoft::Web::WebView2::Win32::{
                    ICoreWebView2_2, COREWEBVIEW2_COOKIE_SAME_SITE_KIND_NONE,
                };
                use windows::core::{Interface, HSTRING};
                let core = webview
                    .controller()
                    .CoreWebView2()
                    .map_err(|e| format!("CoreWebView2: {e}"))?;
                let core2: ICoreWebView2_2 = core.cast().map_err(|e| format!("cast ICoreWebView2_2: {e}"))?;
                let manager = core2
                    .CookieManager()
                    .map_err(|e| format!("CookieManager: {e}"))?;
                let jar_cookie = manager
                    .CreateCookie(
                        &HSTRING::from(name.as_str()),
                        &HSTRING::from(value.as_str()),
                        &HSTRING::from("127.0.0.1"),
                        &HSTRING::from("/"),
                    )
                    .map_err(|e| format!("CreateCookie: {e}"))?;
                // SameSite=None is the whole point: Strict (as issued) would
                // never attach inside the cross-site iframe. Secure rides
                // along so None stays valid; loopback is a trustworthy origin.
                let _ = jar_cookie.SetIsHttpOnly(true);
                let _ = jar_cookie.SetIsSecure(true);
                let _ = jar_cookie.SetSameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND_NONE);
                let expires = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map(|d| d.as_secs().saturating_add(max_age))
                    .unwrap_or(0) as f64;
                let _ = jar_cookie.SetExpires(expires);
                manager
                    .AddOrUpdateCookie(&jar_cookie)
                    .map_err(|e| format!("AddOrUpdateCookie: {e}"))?;
                mark_planted_cookie(expires as u64);
                Ok(())
            }
            #[cfg(not(windows))]
            {
                let _ = (name, value, max_age);
                Err("cookie plant is Windows-only".to_string())
            }
        })();
        let _ = tx.send(verdict);
    });
    if let Err(e) = dispatched {
        supervision_warn(&format!("webchat auth: cookie plant dispatch failed: {e}"));
        return false;
    }
    match rx.recv_timeout(Duration::from_secs(3)) {
        Ok(Ok(())) => true,
        Ok(Err(e)) => {
            supervision_warn(&format!("webchat auth: cookie plant failed: {e}"));
            false
        }
        Err(_) => {
            supervision_warn("webchat auth: cookie plant timed out");
            false
        }
    }
}

/// Resolve the webchat iframe URL for the current backend (frontend invokes
/// this on every ready edge and only mounts/reloads the iframe afterwards):
///
///   1. GET `/` answers 200 → pre-0.1.2 dsh, no auth — plain URL (today's
///      behavior byte-for-byte).
///   2. 401 → BrowserAuth build:
///      a. captured process token (spawn mode) → exchange GET `/?token=` →
///         303 Set-Cookie → plant into WebView2 → plain URL;
///      b. no token but the legacy persistent yaml token (interim builds)
///         → URL carries `?token=` (those builds accept it per request);
///      c. neither → plain URL plus a `webchat-auth-hint` event so the shell
///         can explain the dead iframe (attached instance, expired cookie).
///
/// Bounded (~10s worst case); every failure degrades to the plain URL and
/// never blocks the boot.
pub fn webchat_auth_flow(app: &AppHandle) -> String {
    let plain = format!("{DSH_ORIGIN}/");
    let (status, _) = http_get_no_redirect(&plain);
    supervision_log(&format!("webchat auth: index probe answered HTTP {status}"));
    match status {
        200 | 0 => return plain,
        401 => {}
        other => {
            supervision_warn(&format!("webchat auth: index answered HTTP {other}; using plain URL"));
            return plain;
        }
    }
    supervision_log("webchat auth: browser authentication required; resolving a token");
    if let Some(token) = wait_launch_token(Duration::from_secs(6)) {
        supervision_log("webchat auth: exchanging the captured launch token");
        let exchange_url = format!("{DSH_BASE}/?token={token}");
        let (status, response) = http_get_no_redirect(&exchange_url);
        if status == 303 {
            let header = response
                .as_ref()
                .and_then(|resp| resp.header("set-cookie"));
            let exchanged = header.and_then(parse_session_cookie);
            // The minted cookie is valid server-side regardless of whether the
            // webview plant succeeds — keep it for the session monitor (#18).
            if let Some(cookie) = &exchanged {
                store_session_cookie(cookie);
            }
            let planted = exchanged
                .is_some_and(|cookie| inject_webview2_cookie(app, &cookie));
            if planted {
                supervision_log("webchat auth: launch token exchanged, session cookie planted");
                return plain;
            }
            supervision_warn("webchat auth: token accepted but the cookie plant failed; iframe may 401");
            return plain;
        }
        if status == 200 {
            // Interim BrowserAuth build serving the index directly on ?token=.
            supervision_log("webchat auth: index served on the token URL (interim build)");
            return exchange_url;
        }
        supervision_warn(&format!("webchat auth: token exchange answered HTTP {status}"));
    } else {
        supervision_log("webchat auth: no launch token available (attached backend or pre-announce race)");
    }
    if let Some(token) = browser_session_token() {
        supervision_log("webchat auth: falling back to the persistent yaml token");
        return format!("{DSH_BASE}/?token={token}");
    }
    if !planted_cookie_alive() {
        let _ = app.emit("webchat-auth-hint", ());
    }
    plain
}

/// Default-browser handoff must use the process launch URL, not the plain URL
/// returned after planting a cookie in the separate embedded WebView2 profile.
pub(crate) fn external_browser_url() -> Result<String, &'static str> {
    let plain = format!("{DSH_ORIGIN}/");
    let (status, _) = http_get_no_redirect(&plain);
    if status == 200 { return Ok(plain); }
    if status != 401 { return Err("failed"); }
    let token = wait_launch_token(Duration::from_secs(6)).or_else(browser_session_token).ok_or("auth")?;
    browser_handoff(&plain, &token, |url| http_get_no_redirect(url).0)
}

fn browser_handoff(plain: &str, token: &str, probe: impl FnOnce(&str) -> u16) -> Result<String, &'static str> {
    let mut url = tauri::Url::parse(&plain).map_err(|_| "failed")?;
    url.query_pairs_mut().append_pair("token", token);
    let result = url.to_string();
    // DSH BrowserAuth permits repeated exchanges for the lifetime of the
    // process token. Validate without redirects, then let the browser mint its
    // own cookie. Never copy the WebView cookie into an external profile.
    let status = probe(&result);
    match status { 200 | 303 => Ok(result), 401 | 403 => Err("auth"), _ => Err("failed") }
}

#[cfg(test)]
mod browser_handoff_tests {
    use super::*;
    #[test]
    fn verifies_token_and_encodes_legacy_values() {
        let result = browser_handoff("http://127.0.0.1:3080/", "example token&next=elsewhere", |url| {
            let parsed = tauri::Url::parse(url).unwrap();
            let pairs: Vec<_> = parsed.query_pairs().collect();
            assert_eq!(pairs.len(), 1);
            assert_eq!(pairs[0].1, "example token&next=elsewhere");
            assert_eq!(parsed.host_str(), Some("127.0.0.1"));
            303
        }).unwrap();
        assert!(result.starts_with("http://127.0.0.1:3080/?token="));
        assert!(browser_handoff("http://127.0.0.1:3080/", "example", |_| 200).is_ok());
    }
    #[test]
    fn failed_exchange_never_returns_a_login_url() {
        for status in [0, 302, 401, 403, 404, 500] {
            let failure = browser_handoff("http://127.0.0.1:3080/", "private-test-token", |_| status).unwrap_err();
            assert!(!failure.contains("private-test-token"));
            assert_eq!(failure, if matches!(status, 401 | 403) { "auth" } else { "failed" });
        }
    }
}

/// Roll back the global dsh install to the last known-good version
/// (saved before the upgrade that broke it).
pub(crate) fn rollback_dsh_to_previous() -> Result<(), String> {
    let version = read_previous_dsh_version()
        .ok_or_else(|| "没有保存的回滚版本".to_string())?;
    semver::Version::parse(&version).map_err(|_| "保存的回滚版本无效".to_string())?;
    let npm = where_first("npm")
        .ok_or_else(|| "未找到 npm(需要已安装 Node.js)".to_string())?;
    let cmd = format!("\"{npm}\" install -g @deepseek-ai/dsh@{version}");
    let ok = run_bounded(&cmd, Duration::from_secs(600), "dsh rollback");
    if ok {
        log_write(LogLevel::Info, &format!("[dsh-desktop] rolled back dsh to {version}"));
        Ok(())
    } else {
        Err(format!("回滚到 {version} 失败——详见日志标签页"))
    }
}

/// Path of the "known-good dsh version" marker written before each upgrade
/// so the shell can offer a rollback if the new version is incompatible.
fn previous_version_path() -> std::path::PathBuf {
    Path::new(&std::env::var("USERPROFILE").unwrap_or_default())
        .join(".dsh")
        .join(".previous_dsh_version")
}

/// Save the current dsh CLI version before an upgrade so the shell can
/// offer a rollback if the new version is incompatible (issue #11 scenario).
pub(crate) fn save_previous_version(version: &str) -> Result<(), String> {
    semver::Version::parse(version).map_err(|e| e.to_string())?;
    std::fs::write(previous_version_path(), version).map_err(|e| e.to_string())
}

/// The last known-good dsh version saved before an upgrade.
pub(crate) fn read_previous_dsh_version() -> Option<String> {
    let text = std::fs::read_to_string(previous_version_path()).ok()?;
    let trimmed = text.trim().to_string();
    (!trimmed.is_empty()).then_some(trimmed)
}

#[cfg(all(test, windows))]
mod tests {
    use super::*;

    #[test]
    #[ignore = "Isolated fake CLI; run alone because child output uses a shared ring"]
    fn isolated_child_exit_drains_lock_error() {
        let dir = std::env::temp_dir().join(format!("dsh-fake-cli-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        let shim = dir.join("fake.cmd");
        let lock = dir.join("node_modules.lock");
        std::fs::write(&lock, std::process::id().to_string()).unwrap();
        std::fs::write(&shim, format!("@echo off\r\necho atomic-write: timed out waiting for the writer lock at {}\r\nexit /b 17\r\n", lock.display())).unwrap();
        child_tail_clear();
        let (mut child, drained) = spawn_command(&format!("\"{}\"", shim.display()), &dir.display().to_string()).unwrap();
        assert_eq!(child.wait().unwrap().code(), Some(17));
        for _ in 0..2 { drained.recv_timeout(Duration::from_secs(2)).unwrap(); }
        assert_eq!(crate::startup_policy::writer_lock_path(&child_tail_last(CHILD_TAIL_CAP)), Some(lock.display().to_string()));
        assert_eq!(std::fs::read_to_string(&lock).unwrap(), std::process::id().to_string());
        child_tail_clear();
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn gbk_console_bytes_decode_as_paths() {
        // "小鱼的dsh" in GBK (issue #4-style Chinese-username home dir).
        let gbk = [0xd0, 0xa1, 0xd3, 0xe3, 0x5c, 0x64, 0x73, 0x68]; // 小鱼\dsh
        let text = console_decode(&gbk);
        assert!(text.contains("小鱼"), "decoded: {text}");
        assert!(text.ends_with("\\dsh"));
    }

    #[test]
    fn valid_utf8_still_wins() {
        assert_eq!(console_decode("ascii/path".as_bytes()), "ascii/path");
        assert_eq!(console_decode("héllo".as_bytes()), "héllo");
    }

    #[test]
    fn probe_verdict_covers_every_supported_generation() {
        let ok = json!({"type":"server-response","result":{"ok":true}});
        // ≤0.1.1: host.describe 200 + ok envelope.
        assert!(probe_result_alive(200, Some(&ok), true));
        // 0.1.2+ BrowserAuth fence: 401 with no body at all.
        assert!(probe_result_alive(401, None, true));
        // 0.1.2 deleted host.describe: 404 proves nothing by itself.
        assert!(!probe_result_alive(404, None, true));
        // 0.1.2+ session/list with an empty probe payload: HTTP 200 with an
        // arguments-invalid envelope — still the typert gateway answering.
        let args_err = json!({"type":"server-response","result":{"ok":false,"error":{"code":"gateway/arguments-invalid"}}});
        assert!(!probe_result_alive(200, Some(&args_err), true));
        assert!(probe_result_alive(200, Some(&args_err), false));
        // A random 200 JSON page is not an RPC envelope; no body is not either.
        assert!(!probe_result_alive(200, Some(&json!({"hello":"world"})), false));
        assert!(!probe_result_alive(200, None, false));
        // Unreachable (0) and other statuses never count.
        assert!(!probe_result_alive(0, None, false));
        assert!(!probe_result_alive(502, None, false));
    }
}


#[cfg(test)]
mod live_backend_compatibility {
    use super::*;
    #[test]
    #[ignore = "Requires isolated real backend; driven by tests/backend-compatibility.cjs"]
    fn exact_backend_auth_contract() {
        let base = std::env::var("DSH_COMPAT_BASE").expect("isolated base URL");
        assert!(base.starts_with("http://127.0.0.1:"));
        let launch = std::env::var("DSH_COMPAT_LAUNCH").expect("isolated launch URL");
        let shim = std::env::var("DSH_COMPAT_SHIM").expect("isolated CLI shim");
        assert!(matches!(crate::startup_policy::no_open(Path::new(&shim)), crate::startup_policy::Capability::Supported));
        let (status, body) = rpc_probe_at(&base, "host.describe");
        let alive = if status == 404 {
            let (status, body) = rpc_probe_at(&base, "session/list");
            probe_result_alive(status, body.as_ref(), false)
        } else { probe_result_alive(status, body.as_ref(), true) };
        assert!(alive, "real backend did not satisfy readiness contract");
        assert_eq!(http_get_no_redirect(&format!("{base}/")).0, 401);
        let (status, response) = http_get_no_redirect(&launch);
        assert_eq!(status, 303, "launch exchange contract changed");
        let cookie = parse_session_cookie(response.as_ref().and_then(|r| r.header("Set-Cookie")).expect("auth cookie")).expect("recognized session cookie");
        assert!(cookie.max_age > 0);
        assert_eq!(browser_handoff(&format!("{base}/"), tauri::Url::parse(&launch).unwrap().query_pairs().find(|(k,_)| k == "token").unwrap().1.as_ref(), |url| http_get_no_redirect(url).0).is_ok(), true);
    }
}
