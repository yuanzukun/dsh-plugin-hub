import { test } from 'node:test'
import assert from 'node:assert/strict'
import { svgPathToLottie, buildLottie } from '../src/index.js'

test('svgPathToLottie parses M C L Z', () => {
  const s = svgPathToLottie('M0 0 C10 0 10 10 20 10 L20 20 Z')
  assert.equal(s.c, true)
  assert.equal(s.v.length, 3) // M + C + L (Z closes, no new vertex)
  assert.deepEqual(s.v[0], [0, 0])
  assert.deepEqual(s.i[1], [10 - 20, 10 - 10]) // in tangent toward c2
  assert.deepEqual(s.o[0], [10 - 0, 0 - 0])    // out tangent toward c1
})

test('svgPathToLottie handles H V', () => {
  const s = svgPathToLottie('M5 5 H10 V15 L5 15 Z')
  assert.equal(s.v.length, 4)
  assert.deepEqual(s.v[1], [10, 5])
  assert.deepEqual(s.v[2], [10, 15])
})

test('buildLottie produces valid structure with rect + text', () => {
  const l = buildLottie({
    frame: { w: 100, h: 200, bg: '#ffffff', name: 't' },
    fps: 60,
    durationMs: 1000,
    layers: [
      { type: 'rect', id: 'r1', x: 0, y: 0, w: 50, h: 20, r: 4, fill: '#ff0000', slideUp: 10 },
      { type: 'text', id: 't1', text: 'Hi', x: 10, y: 10, size: 16, color: '#000000' },
    ],
  })
  assert.equal(l.v, '5.7.4')
  assert.equal(l.fr, 60)
  assert.equal(l.op, 60)
  assert.equal(l.w, 100)
  assert.equal(l.h, 200)
  // bg layer + 2 layers
  assert.equal(l.layers.length, 3)
  const textLayer = l.layers.find((x) => x.ty === 5)
  assert.ok(textLayer)
  assert.equal(textLayer.t.d.k[0].s.t, 'Hi')
})

test('buildLottie embeds image asset as base64 data URI', async () => {
  const fs = await import('node:fs')
  const os = await import('node:os')
  const path = await import('node:path')
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lottie-'))
  const img = path.join(dir, 'p.png')
  fs.writeFileSync(img, Buffer.from('89504e470d0a1a0a', 'hex')) // tiny PNG header
  const l = buildLottie({
    frame: { w: 10, h: 10 },
    fps: 30,
    durationMs: 500,
    layers: [{ type: 'image', id: 'i1', path: img, x: 0, y: 0, w: 5, h: 5 }],
  })
  assert.equal(l.assets.length, 1)
  assert.match(l.assets[0].p, /^data:image\/png;base64,/)
})

test('buildLottie gradient rect', () => {
  const l = buildLottie({
    frame: { w: 50, h: 50 },
    fps: 60,
    durationMs: 1000,
    layers: [{ type: 'rect', id: 'g1', x: 0, y: 0, w: 50, h: 10, gradient: ['#61adf8', '#8fd1fa'] }],
  })
  const rect = l.layers[0]
  const grad = rect.shapes.find((s) => s.ty === 'gf')
  assert.ok(grad, 'gradient shape exists')
})
