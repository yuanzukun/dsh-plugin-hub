/**
 * dsh-figma-to-lottie — Figma/SVG to Lottie animation compiler for DeepSeek Harness.
 *
 * Extracts the SVG→Lottie compilation pipeline (path parsing, bezier tangents,
 * keyframe easing) into two agent-callable tools:
 *
 *   - lottie_compile_shape : convert an SVG path `d` string into a Lottie
 *     shape value `{ i, o, v, c }` (bezier in/out tangents + vertices).
 *   - lottie_compile        : assemble a complete self-contained Lottie JSON
 *     document from a frame, layers and keyframe specs.
 *
 * Pure ESM, zero build step — the published package is the runtime code.
 */

import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { dirname, join, isAbsolute, resolve } from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'dsh-figma-to-lottie'
export const inject = ['tools']

// ---------------------------------------------------------------- pure core

const hexToRgb = (hex) => {
  const h = String(hex).replace('#', '')
  const v = parseInt(h, 16)
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255].map((n) => n / 255)
}

const round = (n, p = 4) => Math.round(n * 10 ** p) / 10 ** p

const frameOf = (ms, fps) => (ms / 1000) * fps

/**
 * Parse an SVG path `d` string (subset: M C V H L Z) into a Lottie shape
 * `{ i, o, v, c }`. Cubic beziers map control points to in/out tangents.
 */
export function svgPathToLottie(d) {
  const tokens = d.match(/[a-zA-Z]|-?\d*\.?\d+(?:e-?\d+)?/g)
  const v = []
  const iArr = []
  const oArr = []
  let cx = 0
  let cy = 0
  let i = 0
  while (i < tokens.length) {
    const cmd = tokens[i++]
    if (cmd === 'M') {
      cx = +tokens[i++]
      cy = +tokens[i++]
      v.push([cx, cy])
      iArr.push([0, 0])
      oArr.push([0, 0])
    } else if (cmd === 'C') {
      const c1x = +tokens[i++]
      const c1y = +tokens[i++]
      const c2x = +tokens[i++]
      const c2y = +tokens[i++]
      const x = +tokens[i++]
      const y = +tokens[i++]
      oArr[oArr.length - 1] = [round(c1x - cx), round(c1y - cy)]
      iArr.push([round(c2x - x), round(c2y - y)])
      oArr.push([0, 0])
      v.push([x, y])
      cx = x
      cy = y
    } else if (cmd === 'V') {
      const y = +tokens[i++]
      oArr.push([0, 0])
      iArr.push([0, 0])
      v.push([cx, y])
      cy = y
    } else if (cmd === 'H') {
      const x = +tokens[i++]
      oArr.push([0, 0])
      iArr.push([0, 0])
      v.push([x, cy])
      cx = x
    } else if (cmd === 'L') {
      const x = +tokens[i++]
      const y = +tokens[i++]
      oArr.push([0, 0])
      iArr.push([0, 0])
      v.push([x, y])
      cx = x
      cy = y
    } else if (cmd === 'Z') {
      oArr[oArr.length - 1] = [0, 0]
    }
  }
  return { i: iArr, o: oArr, v, c: true }
}

const DEFAULT_BEZIER = {
  p1x: 0.4838709533214569,
  p1y: 0.23936650156974792,
  p2x: 0.4000000059604645,
  p2y: 1.399999976158142,
}

/**
 * Build a complete Lottie JSON document from a compact layer spec.
 *
 * @param {object} spec
 *   - frame: { w, h, bg? } — canvas size in px, optional background hex.
 *   - fps: frames per second (default 60).
 *   - durationMs: total animation length.
 *   - bezier: { p1x, p1y, p2x, p2y } easing (defaults to a slide-up ease).
 *   - layers: array of layer specs:
 *       { type: 'rect', id, x, y, w, h, r?, fill?, gradient?: [c1hex,c2hex],
 *         opacity?: 0-100, slideUp?: px, startMs?, endMs? }
 *       { type: 'path', id, d, x?, y?, fill?, opacity?, startMs?, endMs? }
 *       { type: 'image', id, path, x, y, w, h, startMs?, endMs? }
 *       { type: 'text', id, text, x, y, size, color?, startMs?, endMs? }
 */
export function buildLottie(spec) {
  const { frame, layers = [], durationMs, bezier = DEFAULT_BEZIER } = spec
  const fps = spec.fps ?? 60
  const op = Math.round((durationMs / 1000) * fps)
  const b = { ...DEFAULT_BEZIER, ...bezier }
  const out = []
  const assets = []
  let imgIndex = 0

  const easingKf = (startMs, startVal, endVal) => [
    { t: 0, s: startVal, h: 1 },
    { t: round(frameOf(startMs, fps)), s: startVal, o: { x: [b.p1x], y: [b.p1y] } },
    { t: op, s: endVal, i: { x: [b.p2x], y: [b.p2y] } },
  ]

  const anim = (startMs, endVal, startVal) => ({
    a: 1,
    k: easingKf(startMs ?? 0, startVal ?? [0], endVal),
  })

  const slidePos = (startMs, restX, restY, slideUp) => ({
    a: 1,
    k: [
      { t: 0, s: [restX, restY + (slideUp ?? 0)], h: 1 },
      { t: round(frameOf(startMs, fps)), s: [restX, restY + (slideUp ?? 0)], o: { x: [b.p1x], y: [b.p1y] } },
      { t: op, s: [restX, restY], i: { x: [b.p2x], y: [b.p2y] } },
    ],
  })

  for (const L of layers) {
    const startMs = L.startMs ?? 0
    const endMs = L.endMs ?? durationMs
    const opacity = L.opacity ?? 100

    if (L.type === 'rect') {
      const shapes = []
      if (L.gradient) {
        const [c1, c2] = L.gradient.map(hexToRgb)
        shapes.push({
          ty: 'gf', nm: 'Grad', d: 1, t: 1,
          s: { a: 0, k: [-L.w / 2, 0] }, e: { a: 0, k: [L.w / 2, 0] },
          h: 0, l: 0, g: { p: 3, k: { a: 0, k: [0, ...c1, 1, ...c2] } },
        })
      } else {
        shapes.push({ ty: 'fl', nm: 'Fill', c: { a: 0, k: hexToRgb(L.fill ?? '#000000') }, o: { a: 0, k: opacity } })
      }
      shapes.push({
        ty: 'rc', nm: 'Rect', d: 1,
        p: { a: 0, k: [0, 0] }, s: { a: 0, k: [L.w, L.h] }, r: { a: 0, k: L.r ?? 0 },
      })
      const cx = L.x + L.w / 2
      const cy = L.y + L.h / 2
      out.push({
        ty: 4, nm: L.id, ind: 0, ddd: 0,
        ks: {
          o: L.opacityAnim ? anim(startMs, [opacity]) : { a: 0, k: opacity },
          r: { a: 0, k: 0 },
          p: L.slideUp ? slidePos(startMs, cx, cy, L.slideUp) : { a: 0, k: [cx, cy, 0] },
          a: { a: 0, k: [0, 0, 0] },
          s: { a: 0, k: [100, 100, 100] },
        },
        ao: 0, ip: 0, op, st: 0, bm: 0, sr: 1, shapes,
      })
    } else if (L.type === 'path') {
      const shape = svgPathToLottie(L.d)
      out.push({
        ty: 4, nm: L.id, ind: 0, ddd: 0,
        ks: {
          o: { a: 0, k: opacity },
          r: { a: 0, k: 0 },
          p: { a: 0, k: [(L.x ?? 0), (L.y ?? 0), 0] },
          a: { a: 0, k: [0, 0, 0] },
          s: { a: 0, k: [100, 100, 100] },
        },
        ao: 0, ip: 0, op, st: 0, bm: 0, sr: 1,
        shapes: [
          { ty: 'sh', nm: 'Path', d: 1, ks: { a: 0, k: shape } },
          { ty: 'fl', nm: 'Fill', c: { a: 0, k: hexToRgb(L.fill ?? '#000000') }, o: { a: 0, k: opacity } },
        ],
      })
    } else if (L.type === 'image') {
      const id = `img_${imgIndex++}`
      const data = readFileSync(L.path)
      assets.push({
        id, w: L.w, h: L.h, u: '', p: `data:image/png;base64,${data.toString('base64')}`, e: 0,
      })
      const cx = L.x + L.w / 2
      const cy = L.y + L.h / 2
      out.push({
        ty: 2, nm: L.id, ind: 0, ddd: 0, refId: id,
        ks: {
          o: { a: 0, k: opacity },
          r: { a: 0, k: 0 },
          p: { a: 0, k: [cx, cy, 0] },
          a: { a: 0, k: [0, 0, 0] },
          s: { a: 0, k: [100, 100, 100] },
        },
        ao: 0, ip: 0, op, st: 0, bm: 0, sr: 1,
      })
    } else if (L.type === 'text') {
      out.push({
        ty: 5, nm: L.id, ind: 0, ddd: 0,
        ks: {
          o: { a: 0, k: opacity },
          r: { a: 0, k: 0 },
          p: { a: 0, k: [L.x, L.y, 0] },
          a: { a: 0, k: [0, 0, 0] },
          s: { a: 0, k: [100, 100, 100] },
        },
        ao: 0, ip: 0, op, st: 0, bm: 0, sr: 1,
        t: {
          d: {
            k: [{
              s: {
                s: L.size, f: L.font ?? 'Inter', t: L.text, fc: hexToRgb(L.color ?? '#000000'),
                j: 0, tr: 0, lh: L.size * 1.2, ls: 0, ps: 0,
              },
              t: 0,
            }],
          },
          p: {}, m: { g: 1, a: { a: 0, k: [0, 0] } }, a: { a: 0, k: [0, 0, 0] },
        },
      })
    }
  }

  let ind = out.length
  for (const l of out) l.ind = ind--

  return {
    v: '5.7.4', fr: fps, ip: 0, op,
    w: frame.w, h: frame.h, nm: frame.name ?? 'lottie',
    ddd: 0,
    assets,
    layers: out,
    ...(frame.bg
      ? {
          // background as first layer
          layers: [
            {
              ty: 4, nm: 'bg', ind: out.length + 1, ddd: 0,
              ks: {
                o: { a: 0, k: 100 }, r: { a: 0, k: 0 },
                p: { a: 0, k: [frame.w / 2, frame.h / 2, 0] },
                a: { a: 0, k: [0, 0, 0] }, s: { a: 0, k: [100, 100, 100] },
              },
              ao: 0, ip: 0, op, st: 0, bm: 0, sr: 1,
              shapes: [
                { ty: 'rc', nm: 'Rect', d: 1, p: { a: 0, k: [0, 0] }, s: { a: 0, k: [frame.w, frame.h] }, r: { a: 0, k: 0 } },
                { ty: 'fl', nm: 'Fill', c: { a: 0, k: hexToRgb(frame.bg) }, o: { a: 0, k: 100 } },
              ],
            },
            ...out,
          ],
        }
      : {}),
  }
}

// ---------------------------------------------------------------- tools

const renderText = (_args, value) => [{ type: 'text', text: value }]

export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'lottie_compile_shape',
    description:
      'Parse an SVG path `d` string (commands M, C, V, H, L, Z) into a Lottie shape value ' +
      '{ i, o, v, c } with bezier in/out tangents. Use this to inspect how an SVG path ' +
      'translates into Lottie before compiling a full animation.',
    parameters: {
      d: { type: 'string', required: true, description: 'The SVG path `d` attribute string.' },
    },
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute(args) {
      return JSON.stringify(svgPathToLottie(args.d))
    },
  }))

  ctx.tools.register(defineTool({
    name: 'lottie_compile',
    description:
      'Compile a complete self-contained Lottie JSON document from a compact layer spec. ' +
      'Input is a JSON object: { frame: { w, h, bg?, name? }, fps?, durationMs, bezier?, layers: [...] }. ' +
      'Layer types: rect (x,y,w,h,r?,fill?,gradient?[2 hex],slideUp?,opacity?,startMs?,endMs?), ' +
      'path (d,x?,y?,fill?,opacity?), image (path,x,y,w,h), text (text,x,y,size,color?,font?). ' +
      'Returns the Lottie JSON string. Use this to produce animated assets from design data.',
    parameters: {
      spec: { type: 'string', required: true, description: 'JSON string of the layer spec as described in the description.' },
      outPath: { type: 'string', description: 'Optional absolute path to write the .lottie.json file. When omitted, the JSON is returned as text.' },
    },
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute(args) {
      const spec = typeof args.spec === 'string' ? JSON.parse(args.spec) : args.spec
      const lottie = buildLottie(spec)
      const json = JSON.stringify(lottie, null, 2)
      if (args.outPath) {
        const p = isAbsolute(args.outPath) ? args.outPath : resolve(process.cwd(), args.outPath)
        mkdirSync(dirname(p), { recursive: true })
        writeFileSync(p, json)
        return `Wrote ${p} (${(json.length / 1024).toFixed(1)} KB, ${lottie.layers.length} layers, ${lottie.op} frames @ ${lottie.fr}fps)`
      }
      return json
    },
  }))
}
