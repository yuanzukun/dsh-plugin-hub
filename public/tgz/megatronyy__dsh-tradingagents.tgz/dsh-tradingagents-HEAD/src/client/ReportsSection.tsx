/**
 * The "投研报告" (Research Reports) settings section: a history list of every
 * archived /trading-agent analysis, with a full-report detail view. List and
 * detail are two states of one section — the list loads from the plugin's
 * host route, a row click fetches that report's markdown and renders it.
 * @module dsh-tradingagents/client/ReportsSection
 */
import { useCallback, useEffect, useState } from 'react'
import { MarkdownText } from '@deepseek-ai/dsh-client-ui-primitives'
import type { ReportsDictionary } from './locales.ts'

/** One history row from GET /tradingagents/reports. */
export interface ReportEntry {
  id: string
  ticker: string
  name: string
  date: string
  createdAt: string
  direction: string
  reason: string
}

/** The trade-plan half of the decision record from GET …/<id>/decision. */
interface DecisionPlan {
  action?: string
  confidence?: number
  entry?: string
  stop?: string
  targets?: string[]
  positionPct?: number
}

export interface ReportsSectionProps {
  t: (key: keyof ReportsDictionary) => string
}

/** Direction badge color keyed by the trader's verdict vocabulary. */
const directionStyle = (direction: string): React.CSSProperties => ({
  color: /看多|偏多/.test(direction)
    ? 'var(--dsw-alias-state-success-primary)'
    : /看空|偏空/.test(direction)
      ? 'var(--dsw-alias-state-error-primary)'
      : 'var(--dsw-alias-label-secondary)',
})

/** Plan facts as label/value chips; skipped entirely when the record has none. */
function planChips(plan: DecisionPlan, t: (key: keyof ReportsDictionary) => string): { label: string; value: string }[] {
  const chips = [
    { label: t('planAction'), value: plan.action ?? '' },
    { label: t('planConfidence'), value: plan.confidence === undefined ? '' : `${plan.confidence}%` },
    { label: t('planEntry'), value: plan.entry ?? '' },
    { label: t('planStop'), value: plan.stop ?? '' },
    { label: t('planTargets'), value: plan.targets?.join(' → ') ?? '' },
    { label: t('planPosition'), value: plan.positionPct === undefined ? '' : `${plan.positionPct}%` },
  ]
  return chips.filter(chip => chip.value !== '')
}

export function ReportsSection({ t }: ReportsSectionProps): JSX.Element {
  const [reports, setReports] = useState<ReportEntry[] | undefined>(undefined)
  const [loadFailed, setLoadFailed] = useState(false)
  const [detail, setDetail] = useState<{ entry: ReportEntry; markdown: string; plan?: DecisionPlan } | undefined>(undefined)

  useEffect(() => {
    let cancelled = false
    fetch('/tradingagents/reports', { headers: { accept: 'application/json' } })
      .then(async response => {
        if (!response.ok) throw new Error(String(response.status))
        const body = await response.json() as { reports?: ReportEntry[] }
        if (!cancelled) setReports(body.reports ?? [])
      })
      .catch(() => { if (!cancelled) setLoadFailed(true) })
    return () => { cancelled = true }
  }, [])

  const openDetail = useCallback((entry: ReportEntry) => {
    void fetch(`/tradingagents/reports/${encodeURIComponent(entry.id)}`, { headers: { accept: 'application/json' } })
      .then(async response => {
        if (!response.ok) throw new Error(String(response.status))
        const body = await response.json() as { markdown?: string }
        setDetail({ entry, markdown: body.markdown ?? '' })
        // The decision sidecar is a separate, optional fetch: reports saved
        // before it existed (or with no plan stated) simply render without it.
        void fetch(`/tradingagents/reports/${encodeURIComponent(entry.id)}/decision`, { headers: { accept: 'application/json' } })
          .then(async response => {
            if (!response.ok) return
            const record = await response.json() as { plan?: DecisionPlan }
            setDetail(current => current === undefined || current.entry.id !== entry.id
              ? current
              : { ...current, plan: record.plan })
          })
          .catch(() => {})
      })
      .catch(() => setLoadFailed(true))
  }, [])

  const headingStyle: React.CSSProperties = { margin: '0 0 4px', fontSize: 16, color: 'var(--dsw-alias-label-primary)' }
  const mutedStyle: React.CSSProperties = { color: 'var(--dsw-alias-label-secondary)', fontSize: 13 }

  if (detail !== undefined) {
    const chips = detail.plan === undefined ? [] : planChips(detail.plan, t)
    return (
      <section aria-label={t('title')}>
        <button
          type="button"
          onClick={() => { setDetail(undefined) }}
          style={{ border: 'none', background: 'transparent', color: 'var(--dsw-alias-brand-primary)', cursor: 'pointer', padding: 0, marginBottom: 12 }}
        >
          {t('back')}
        </button>
        {chips.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            {chips.map(chip => (
              <span
                key={chip.label}
                style={{
                  border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 6, padding: '2px 10px', fontSize: 13,
                  color: 'var(--dsw-alias-label-primary)', background: 'var(--dsw-alias-fill-secondary, transparent)',
                  ...(/^(买入|Buy)/.test(chip.value) ? directionStyle('看多') : /^(卖出|Sell)/.test(chip.value) ? directionStyle('看空') : {}),
                }}
              >
                {chip.label}：<strong>{chip.value}</strong>
              </span>
            ))}
          </div>
        )}
        <MarkdownText text={detail.markdown} />
      </section>
    )
  }

  return (
    <section aria-label={t('title')}>
      <h2 style={headingStyle}>{t('title')}</h2>
      <p style={{ ...mutedStyle, marginTop: 0 }}>{t('intro')}</p>
      {loadFailed && <p style={{ color: 'var(--dsw-alias-state-error-primary)' }}>{t('loadFailed')}</p>}
      {reports === undefined && !loadFailed && <p style={mutedStyle}>…</p>}
      {reports?.length === 0 && (
        <div style={{ padding: '24px 0', textAlign: 'center' }}>
          <p style={{ ...mutedStyle, margin: 0 }}>{t('empty')}</p>
          <p style={{ ...mutedStyle, margin: '4px 0 0' }}>{t('emptyHint')}</p>
        </div>
      )}
      {reports !== undefined && reports.length > 0 && (
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
          <thead>
            <tr>
              {[t('colDate'), t('colInstrument'), t('colDirection'), t('colReason'), ''].map(label => (
                <th key={label} style={{ textAlign: 'left', padding: '8px 10px', borderBottom: '1px solid var(--dsw-alias-border-l2)', color: 'var(--dsw-alias-label-secondary)', fontWeight: 500 }}>{label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {reports.map(entry => (
              <tr key={entry.id} onClick={() => { openDetail(entry) }} style={{ cursor: 'pointer' }} aria-label={`${entry.name} ${entry.ticker}`}>
                <td style={{ padding: '8px 10px', borderBottom: '1px solid var(--dsw-alias-border-l1)', color: 'var(--dsw-alias-label-secondary)', whiteSpace: 'nowrap' }}>{entry.date}</td>
                <td style={{ padding: '8px 10px', borderBottom: '1px solid var(--dsw-alias-border-l1)', color: 'var(--dsw-alias-label-primary)' }}>{entry.name}（{entry.ticker}）</td>
                <td style={{ padding: '8px 10px', borderBottom: '1px solid var(--dsw-alias-border-l1)', ...directionStyle(entry.direction), whiteSpace: 'nowrap' }}>{entry.direction}</td>
                <td style={{ padding: '8px 10px', borderBottom: '1px solid var(--dsw-alias-border-l1)', color: 'var(--dsw-alias-label-primary)' }}>{entry.reason}</td>
                <td style={{ padding: '8px 10px', borderBottom: '1px solid var(--dsw-alias-border-l1)', color: 'var(--dsw-alias-brand-primary)', whiteSpace: 'nowrap' }}>{t('view')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  )
}
