/**
 * Locale dictionaries for the reports page.
 * @module dsh-tradingagents/client/locales
 */

export interface ReportsDictionary {
  nav: string
  title: string
  intro: string
  colDate: string
  colInstrument: string
  colDirection: string
  colReason: string
  empty: string
  emptyHint: string
  view: string
  back: string
  loadFailed: string
  runNew: string
  planAction: string
  planConfidence: string
  planEntry: string
  planStop: string
  planTargets: string
  planPosition: string
}

export const zh: ReportsDictionary = {
  nav: '投研报告',
  title: '投研报告 · 历史分析',
  intro: '每次 /trading-agent 分析完成后自动归档于此。点击行查看完整报告。',
  colDate: '日期',
  colInstrument: '标的',
  colDirection: '方向',
  colReason: '结论',
  empty: '暂无历史报告',
  emptyHint: '在会话中输入 /trading-agent 600519 发起第一次分析',
  view: '查看',
  back: '← 返回列表',
  loadFailed: '报告列表加载失败',
  runNew: '开始新分析：/trading-agent <代码或名称>',
  planAction: '动作',
  planConfidence: '信心',
  planEntry: '入场',
  planStop: '止损',
  planTargets: '目标',
  planPosition: '仓位',
}

export const en: ReportsDictionary = {
  nav: 'Research Reports',
  title: 'Research Reports · History',
  intro: 'Every /trading-agent analysis is archived here automatically. Click a row for the full report.',
  colDate: 'Date',
  colInstrument: 'Instrument',
  colDirection: 'Direction',
  colReason: 'Verdict',
  empty: 'No reports yet',
  emptyHint: 'Run /trading-agent 600519 in a session to create the first one',
  view: 'View',
  back: '← Back to list',
  loadFailed: 'Failed to load the report list',
  runNew: 'Start an analysis: /trading-agent <ticker>',
  planAction: 'Action',
  planConfidence: 'Conviction',
  planEntry: 'Entry',
  planStop: 'Stop',
  planTargets: 'Targets',
  planPosition: 'Position',
}
