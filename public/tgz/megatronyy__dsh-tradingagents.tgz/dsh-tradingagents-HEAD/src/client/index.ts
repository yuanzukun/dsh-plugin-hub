/**
 * dsh-tradingagents, browser half. Contributes the "投研报告" section to the
 * settings page: the history list of archived analyses and their full
 * reports. The section talks to this plugin's host routes only.
 *
 * Context shapes are structural (the loader provides the real Cordis
 * context), mirroring the approach of this plugin's host half.
 * @module dsh-tradingagents/client
 */
import { createElement as h } from 'react'
import { en, zh, type ReportsDictionary } from './locales.ts'
import { ReportsSection } from './ReportsSection.tsx'

/** Locale namespace owning this page's copy. */
const LOCALE_NS = 'dsh-tradingagents'

interface LocaleService {
  register(namespace: string, dicts: Record<string, Record<string, string>>): unknown
  bind(namespace: string): (key: string) => string
}

interface SlotsService {
  inject(name: string, register: () => unknown): void
  register(options: Record<string, unknown>, component: () => unknown): unknown
}

interface TradingClientContext {
  effect(callback: () => unknown, label?: string): void
  locale: LocaleService
  slots: SlotsService
}

/** Required services: locale for the section copy, slots for the section seat. */
export const inject = ['slots', 'locale']

/**
 * Client plugin body: register dictionaries and the settings section.
 * @param ctx - client cordis context.
 */
export function apply(ctx: TradingClientContext): void {
  ctx.effect(() => ctx.locale.register(LOCALE_NS, {
    zh: zh as unknown as Record<string, string>,
    en: en as unknown as Record<string, string>,
  }), 'tradingagents: reports dictionaries')
  const t = ctx.locale.bind(LOCALE_NS) as (key: keyof ReportsDictionary) => string

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'tradingagents-reports',
    order: 46,
    label: () => t('nav'),
    locale: LOCALE_NS,
    inject: () => ({ t }),
  }, () => h(ReportsSection, { t })))
}
