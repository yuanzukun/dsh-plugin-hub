/**
 * dsh-tradingagents, host plugin. Registers the `/trading-agent` slash
 * command (modeled on dsh-agent-teams' command registration): one invocation
 * runs the full 14-role analysis pipeline through the harness LLM service
 * and returns the complete Markdown report, which is also saved under
 * ~/.dsh/tradingagents/reports/.
 * @module dsh-tradingagents
 */
import type { Context } from '@deepseek-ai/cordis'
import { runAnalysis } from './pipeline.ts'
import * as report from './report.ts'
import type { LlmService } from './llm.ts'

/** The commands-service surface this plugin touches (structural). */
interface CommandsService {
  register(definition: {
    name: string
    description: string
    input?: { hint: string }
    handler: (invocation: CommandInvocationLike) =>
      | { kind: 'success'; text?: string }
      | { kind: 'error'; text: string }
      | Promise<{ kind: 'success'; text?: string } | { kind: 'error'; text: string }>
  }): () => void
}

/** The invocation surface the handler touches (structural: agent carries the live model route). */
interface CommandInvocationLike {
  rawInput: string
  signal: AbortSignal
  agent?: {
    session?: { requestHeader?: () => { config?: { provider?: string; model?: string } } | undefined }
    options?: { provider?: string; model?: string }
  }
}

/** The webServer surface this plugin touches (structural). */
interface WebServerService {
  register(route: {
    kind: 'exact' | 'prefix'
    path: string
    handler: (req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse) => void | Promise<void>
  }): () => void
}

/**
 * Resolve the model route for an analysis from the invoking agent's live
 * session configuration (the same source dsh-agent-teams snapshots for team
 * members), falling back to the agent's descriptor options.
 */
function routeOf(llm: LlmService, invocation: CommandInvocationLike, signal: AbortSignal): Promise<{ provider: string; model: string; reasoningEffort?: string }> {
  const current = invocation.agent?.session?.requestHeader?.()?.config
  const provider = current?.provider ?? invocation.agent?.options?.provider
  const model = current?.model ?? invocation.agent?.options?.model
  return llm.resolveCallConfig({
    ...(provider === undefined || model === undefined ? {} : { provider, model }),
  }, signal)
}

/** The llm service is required; commands and webServer register when present. */
export const inject = ['llm']

const USAGE = '用法：/trading-agent <股票代码或名称> [关注点]\n例如：/trading-agent 600519\n例如：/trading-agent 调研比亚迪，短线能否创新高，仓位 80% 成本 180\n完整分析约需数分钟（14 个角色：分析师 → 多空辩论 → 风控 → 交易决策）。\n历史报告：设置 → 投研报告，或 GET /tradingagents/reports。'

/**
 * Plugin body: publish the command into the host catalog and serve the
 * history-report catalog under /tradingagents.
 * @param ctx - host cordis context carrying the llm service.
 */
export function apply(ctx: Context): void {
  const llm = (ctx as Context & { llm: LlmService }).llm
  ctx.inject(['commands'], (commandCtx) => {
    commandCtx.effect(() => (commandCtx as Context & { commands: CommandsService }).commands.register({
      name: 'trading-agent',
      description: 'A股多智能体深度分析：14 角色协作（分析师/多空辩论/风控/交易员），生成完整投研报告',
      input: { hint: '股票代码或名称，可附关注点，如：600519 或 调研茅台短线' },
      handler: async invocation => {
        const query = invocation.rawInput.trim()
        if (query === '') return { kind: 'error', text: USAGE }
        try {
          const route = await routeOf(llm, invocation, invocation.signal)
          const result = await runAnalysis(llm, route, query, () => {}, invocation.signal)
          const markdown = report.composeReport(result)
          let pathNote = ''
          try {
            pathNote = `\n\n> 完整报告已保存：${await report.saveReport(result, markdown)}`
          } catch {
            // Report persistence is best-effort; the returned text is complete on its own.
          }
          return { kind: 'success', text: `${markdown}${pathNote}` }
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error)
          return invocation.signal.aborted
            ? { kind: 'error', text: '分析已取消。' }
            : { kind: 'error', text: `分析失败：${message}` }
        }
      },
    }), 'tradingagents: /trading-agent command')
  })

  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(() => (webCtx as Context & { webServer: WebServerService }).webServer.register({
      kind: 'prefix',
      path: '/tradingagents',
      handler: (req, res) => { void handleReportsRequest(req, res) },
    }), 'tradingagents: reports routes')
  })
}

/** Serve the history-report catalog: list JSON and one report's markdown. */
async function handleReportsRequest(req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse): Promise<void> {
  const send = (status: number, body: string, contentType: string): void => {
    res.writeHead(status, { 'content-type': contentType, 'cache-control': 'no-store' })
    res.end(body)
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    send(405, JSON.stringify({ error: 'method not allowed' }), 'application/json')
    return
  }
  const pathname = decodeURIComponent(new URL(req.url ?? '/', 'http://localhost').pathname)
  if (pathname === '/tradingagents/reports') {
    send(200, JSON.stringify({ reports: await report.listReports() }), 'application/json')
    return
  }
  const stem = '/tradingagents/reports/'
  if (pathname.startsWith(stem)) {
    const rest = pathname.slice(stem.length)
    if (rest.endsWith('/decision')) {
      const decision = await report.readDecision(rest.slice(0, -'/decision'.length))
      if (decision === undefined) {
        send(404, JSON.stringify({ error: 'decision record not found' }), 'application/json')
        return
      }
      send(200, JSON.stringify(decision), 'application/json')
      return
    }
    const markdown = await report.readReportMarkdown(rest)
    if (markdown === undefined) {
      send(404, JSON.stringify({ error: 'report not found' }), 'application/json')
      return
    }
    send(200, JSON.stringify({ markdown }), 'application/json')
    return
  }
  send(404, JSON.stringify({ error: 'not found', hint: 'GET /tradingagents/reports' }), 'application/json')
}
