/**
 * Final report assembly: one self-contained Markdown document per analysis
 * (summary table up front, every role's full output, data appendix), written
 * under ~/.dsh/tradingagents/reports/ and returned as the command text.
 * @module dsh-tradingagents/report
 */
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import type { AnalysisResult } from './pipeline.ts'
import { composeDecisionRecord, mergedPlan, type DecisionRecord } from './decision.ts'

const REPORTS_DIR = join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'tradingagents', 'reports')

/** Compose the full Markdown report for one analysis result. */
export function composeReport(result: AnalysisResult): string {
  const { intent, data, analystReports, debateTurns, managerReport, traderFirst, riskDebate, riskManagerReport, traderFinal } = result
  const quote = data.quote
  const now = new Date()
  const lines: string[] = []

  lines.push(`# ${intent.name}（${intent.ticker}）多智能体投研报告`)
  lines.push('')
  lines.push(`- 分析日期：${now.toLocaleString('zh-CN', { hour12: false })}（数据截至 ${data.tradeDate}）`)
  if (quote !== undefined) {
    lines.push(`- 现价：${quote.price}（今日 ${quote.changePercent >= 0 ? '+' : ''}${quote.changePercent}%）｜总市值 ${(quote.totalMarketCap / 1e12).toFixed(2)}万亿｜PE(TTM) ${quote.peTtm}`)
    lines.push(`- 主力资金：今日净流入 ${(quote.mainNetInflow / 1e8).toFixed(2)}亿（占成交 ${quote.mainNetInflowPercent}%）｜换手率 ${quote.turnoverRate}%`)
  }
  if (intent.focusAreas.length > 0) lines.push(`- 用户关注：${intent.focusAreas.join('、')}`)
  if (intent.specificQuestions.length > 0) lines.push(`- 用户问题：${intent.specificQuestions.map(q => `「${q}」`).join(' ')}`)
  if (data.missing.length > 0) lines.push(`- 数据缺口：${data.missing.join('、')}（对应分析维度置信度下降）`)
  lines.push('')

  lines.push('## 一、结论速览')
  lines.push('')
  lines.push(`**最终决策（交易员）**：${traderFinal.verdict?.direction ?? '—'} —— ${traderFinal.verdict?.reason ?? ''}`)
  lines.push('')
  lines.push('| 阶段 | 角色 | 方向 | 一句话结论 |')
  lines.push('| --- | --- | --- | --- |')
  for (const report of analystReports) {
    lines.push(`| 分析 | ${report.label} | ${report.verdict?.direction ?? '—'} | ${report.verdict?.reason ?? ''} |`)
  }
  lines.push(`| 辩论裁决 | 投研经理 | ${managerReport.verdict?.direction ?? '—'} | ${managerReport.verdict?.reason ?? ''} |`)
  lines.push(`| 风控审核 | 风控经理 | ${riskManagerReport.verdict?.direction ?? '—'} | ${riskManagerReport.verdict?.reason ?? ''} |`)
  lines.push(`| 最终决策 | 交易员 | ${traderFinal.verdict?.direction ?? '—'} | ${traderFinal.verdict?.reason ?? ''} |`)
  lines.push('')

  const planBlock = planSummaryLines(result)
  if (planBlock.length > 0) {
    lines.push('**交易计划速览**（机读版随报告存为 `<id>.decision.json`）')
    lines.push('')
    lines.push('| 动作 | 信心 | 入场 | 止损 | 目标 | 仓位 |')
    lines.push('| --- | --- | --- | --- | --- | --- |')
    lines.push(`| ${planBlock[0]} | ${planBlock[1]} | ${planBlock[2]} | ${planBlock[3]} | ${planBlock[4]} | ${planBlock[5]} |`)
    lines.push('')
  }

  lines.push('## 二、交易员最终决策')
  lines.push('')
  lines.push(stripVerdict(traderFinal.text))
  lines.push('')

  lines.push('## 三、投研经理裁决')
  lines.push('')
  lines.push(stripVerdict(managerReport.text))
  lines.push('')

  lines.push('## 四、风控审核')
  lines.push('')
  lines.push(stripVerdict(riskManagerReport.text))
  lines.push('')

  lines.push('## 五、多空辩论')
  lines.push('')
  for (const turn of debateTurns) {
    lines.push(`### ${turn.side === 'bull' ? '多头' : '空头'} · 第 ${turn.round} 轮`)
    lines.push('')
    lines.push(stripVerdict(turn.text))
    lines.push('')
  }

  lines.push('## 六、风控三方辩论')
  lines.push('')
  lines.push('### 激进方')
  lines.push('')
  lines.push(stripVerdict(riskDebate.aggressive))
  lines.push('')
  lines.push('### 保守方')
  lines.push('')
  lines.push(stripVerdict(riskDebate.conservative))
  lines.push('')
  lines.push('### 中性方')
  lines.push('')
  lines.push(stripVerdict(riskDebate.neutral))
  lines.push('')

  lines.push('## 七、分析师报告')
  lines.push('')
  for (const report of analystReports) {
    lines.push(`### ${report.label}`)
    lines.push('')
    lines.push(stripVerdict(report.text))
    lines.push('')
  }

  lines.push('## 附录：数据切片')
  lines.push('')
  lines.push('```')
  lines.push(`K线与指标：${data.indicators === undefined ? '缺失' : JSON.stringify(data.indicators)}`)
  lines.push(`新闻条数：${data.news.length}；快讯条数：${data.globalNews.length}`)
  lines.push(`资金流历史（近5日，亿元）：${data.fundFlowHistory.slice(-5).map(row => `${row.date.slice(5)}=${(row.mainNet / 1e8).toFixed(1)}`).join(', ') || '缺失'}`)
  lines.push(`板块排名（前5）：${data.boardFlows.slice(0, 5).map(row => `${row.name}${(row.mainNet / 1e8).toFixed(0)}亿`).join(', ') || '缺失'}`)
  lines.push(`龙虎榜：${data.lhb.length === 0 ? '近期无记录' : data.lhb.map(row => `${row.tradeDate}净买${(row.netBuy / 1e8).toFixed(1)}亿`).join(', ')}`)
  lines.push(`财务报告期：${data.fundamentals.map(row => row.reportDate).join(', ') || '缺失'}`)
  lines.push('```')
  lines.push('')
  lines.push('---')
  lines.push('')
  lines.push('*本报告由 dsh-tradingagents 多智能体管线生成（14 个角色：7 分析师并行研究 → 多空 2 轮辩论 → 投研经理裁决 → 交易员方案 → 风控三方辩论 → 风控经理审核 → 交易员最终决策）。架构源自 [TradingAgents-AShare](https://github.com/KylinMountain/TradingAgents-AShare)。数据来自公开行情接口，不构成投资建议。*')

  return lines.join('\n')
}

/** Drop the machine verdict block from a role's text for display. */
function stripVerdict(text: string): string {
  return text.replace(/<!--\s*VERDICT:.*?-->/gs, '').trim()
}

/**
 * One table row of trade-plan facts for the report header: six display cells
 * (action, confidence, entry, stop, targets, position). An empty array means
 * no plan value existed anywhere — the block is skipped entirely.
 */
function planSummaryLines(result: AnalysisResult): string[] {
  const plan = mergedPlan(result)
  const cells = [
    plan.action ?? '—',
    plan.confidence === undefined ? '—' : `${plan.confidence}%`,
    plan.entry ?? '—',
    plan.stop ?? '—',
    plan.targets?.join(' → ') ?? '—',
    plan.positionPct === undefined ? '—' : `${plan.positionPct}%`,
  ]
  return cells.every(cell => cell === '—') ? [] : cells
}

/** One history-list row served to the reports page. */
export interface ReportEntry {
  /** File id (filename without extension); also the detail-request key. */
  id: string
  ticker: string
  name: string
  /** Data cutoff date (YYYY-MM-DD). */
  date: string
  createdAt: string
  direction: string
  reason: string
}

const INDEX_PATH = join(REPORTS_DIR, 'reports-index.json')

/** File extension of the structured-decision sidecar next to each report. */
const DECISION_EXT = '.decision.json'

/**
 * Persist the report file, its structured-decision sidecar, and an index
 * entry so the reports page lists it without re-parsing the markdown.
 * @returns the written markdown file path.
 */
export async function saveReport(result: AnalysisResult, markdown: string): Promise<string> {
  await mkdir(REPORTS_DIR, { recursive: true })
  const compactDate = result.data.tradeDate.replaceAll('-', '')
  const id = `${result.intent.ticker}-${compactDate}-${Date.now().toString(36)}`
  const path = join(REPORTS_DIR, `${id}.md`)
  await writeFile(path, markdown, 'utf8')
  const decision = composeDecisionRecord(result, id)
  await writeFile(join(REPORTS_DIR, `${id}${DECISION_EXT}`), JSON.stringify(decision, null, 1), 'utf8')
  const entry: ReportEntry = {
    id,
    ticker: result.intent.ticker,
    name: result.intent.name,
    date: result.data.tradeDate,
    createdAt: decision.createdAt,
    direction: result.traderFinal.verdict?.direction ?? '—',
    reason: result.traderFinal.verdict?.reason ?? '',
  }
  try {
    const existing = await readIndex()
    existing.push(entry)
    await writeFile(INDEX_PATH, JSON.stringify(existing, null, 1), 'utf8')
  } catch {
    // Index maintenance is best-effort; the list endpoint falls back to scanning.
  }
  return path
}

async function readIndex(): Promise<ReportEntry[]> {
  try {
    const raw = JSON.parse(await readFile(INDEX_PATH, 'utf8')) as unknown
    if (!Array.isArray(raw)) return []
    return raw.filter((entry): entry is ReportEntry =>
      typeof entry === 'object' && entry !== null && typeof (entry as ReportEntry).id === 'string')
  } catch {
    return []
  }
}

/**
 * Every report currently on disk, newest first. The index is the fast path;
 * files missing from it (reports written before the index existed) are
 * parsed from their markdown header on the fly and folded in.
 */
export async function listReports(): Promise<ReportEntry[]> {
  const [indexed, files] = await Promise.all([
    readIndex(),
    readdir(REPORTS_DIR).catch(() => [] as string[]),
  ])
  const known = new Set(indexed.map(entry => entry.id))
  const scanned: ReportEntry[] = []
  for (const file of files) {
    if (!file.endsWith('.md')) continue
    const id = file.slice(0, -3)
    if (known.has(id)) continue
    const parsed = await parseReportHeader(id)
    if (parsed !== undefined) scanned.push(parsed)
  }
  const all = [...indexed, ...scanned]
  all.sort((left, right) => right.id.localeCompare(left.id))
  return all
}

/** Extract the list-row facts from a report's own markdown (fallback path). */
async function parseReportHeader(id: string): Promise<ReportEntry | undefined> {
  try {
    const markdown = await readFile(join(REPORTS_DIR, `${id}.md`), 'utf8')
    const title = /^#\s+(.+)$/m.exec(markdown)?.[1] ?? ''
    const named = /^(.+?)（([0-9]{6})）/.exec(title)
    const decision = /\*\*最终决策（交易员）\*\*：(\S+)\s*(?:——\s*(.*))?$/m.exec(markdown)
    return {
      id,
      ticker: named?.[2] ?? id.slice(0, 6),
      name: named?.[1] ?? (title || id),
      date: id.slice(7, 15).replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3'),
      createdAt: '',
      direction: decision?.[1] ?? '—',
      reason: (decision?.[2] ?? '').trim(),
    }
  } catch {
    return undefined
  }
}

/** Load one report's markdown by id; ids are bare filenames by construction. */
export async function readReportMarkdown(id: string): Promise<string | undefined> {
  if (!/^[a-z0-9][a-z0-9-]*$/i.test(id)) return undefined
  const path = resolve(REPORTS_DIR, `${id}.md`)
  if (!path.startsWith(resolve(REPORTS_DIR))) return undefined
  try {
    return await readFile(path, 'utf8')
  } catch {
    return undefined
  }
}

/**
 * Load one report's structured decision record by id. Reports saved before
 * the sidecar existed have none — undefined means "no record", not an error.
 */
export async function readDecision(id: string): Promise<DecisionRecord | undefined> {
  if (!/^[a-z0-9][a-z0-9-]*$/i.test(id)) return undefined
  const path = resolve(REPORTS_DIR, `${id}${DECISION_EXT}`)
  if (!path.startsWith(resolve(REPORTS_DIR))) return undefined
  try {
    const parsed = JSON.parse(await readFile(path, 'utf8')) as unknown
    if (typeof parsed !== 'object' || parsed === null) return undefined
    const record = parsed as Partial<DecisionRecord>
    return typeof record.ticker === 'string' && typeof record.plan === 'object'
      ? parsed as DecisionRecord
      : undefined
  } catch {
    return undefined
  }
}

/** Reports directory (exported for tests and diagnostics). */
export const reportsDirectory = REPORTS_DIR
