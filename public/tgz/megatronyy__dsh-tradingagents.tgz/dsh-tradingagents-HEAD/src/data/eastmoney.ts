/**
 * Public market-data endpoints for the A-share pipeline — the same wire the
 * original project reached through akshare, called directly with fetch.
 *
 * Endpoint selection was verified against the live services from this
 * network: Tencent hosts the OHLCV klines (the eastmoney push2his host
 * hangs behind TLS renegotiation here), the eastmoney push2delay host
 * serves quotes/board flows/fund flows (the realtime push2 host shares the
 * same protection), and the eastmoney datacenter/search/np-weblist hosts
 * serve statements, news, and the flash feed. Every function is
 * independently fallible: the collector wraps each one so a blocked source
 * degrades to a "data missing" note instead of failing the analysis.
 * @module dsh-tradingagents/data/eastmoney
 */
import type { Bar } from './indicators.ts'

const HEADERS: Record<string, string> = {
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  referer: 'https://quote.eastmoney.com/',
}

async function getJson<T>(url: string, timeoutMs = 15000): Promise<T> {
  const controller = new AbortController()
  const timer = setTimeout(() => { controller.abort() }, timeoutMs)
  try {
    const response = await fetch(url, { headers: HEADERS, signal: controller.signal })
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return await response.json() as T
  } finally {
    clearTimeout(timer)
  }
}

async function getText(url: string, timeoutMs = 15000): Promise<string> {
  const controller = new AbortController()
  const timer = setTimeout(() => { controller.abort() }, timeoutMs)
  try {
    const response = await fetch(url, { headers: HEADERS, signal: controller.signal })
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return await response.text()
  } finally {
    clearTimeout(timer)
  }
}

/** Strip a JSONP wrapper: `cb({...})` → `{...}`. */
function unwrapJsonp(text: string): string {
  const start = text.indexOf('(')
  const end = text.lastIndexOf(')')
  return start >= 0 && end > start ? text.slice(start + 1, end) : text
}

async function getJsonp<T>(url: string, timeoutMs = 15000): Promise<T> {
  return JSON.parse(unwrapJsonp(await getText(url, timeoutMs))) as T
}

/** Exchange prefix: 'sh'/'sz' for Tencent, '1'/'0' for eastmoney secids. */
export function exchangeOf(ticker: string): { tencent: 'sh' | 'sz'; eastmoney: '1' | '0' } | undefined {
  if (/^(60|68|9)/.test(ticker)) return { tencent: 'sh', eastmoney: '1' }
  if (/^(00|30|2)/.test(ticker)) return { tencent: 'sz', eastmoney: '0' }
  return undefined
}

/** Whether this ticker is an A-share the data layer knows how to address. */
export function isAShareTicker(ticker: string): boolean {
  return /^[0-9]{6}$/.test(ticker) && exchangeOf(ticker) !== undefined
}

/** Resolve a search keyword (name or code) to an A-share ticker. */
export async function searchTicker(keyword: string): Promise<string | undefined> {
  interface Suggest {
    QuotationCodeTable?: {
      Data?: { Code: string; Name: string; MktNum: string; SecurityType: string }[]
    }
  }
  if (isAShareTicker(keyword.trim())) return keyword.trim()
  const url = `https://searchadapter.eastmoney.com/api/suggest/get?input=${encodeURIComponent(keyword)}&type=14&count=8`
  const data = await getJson<Suggest>(url)
  const rows = data.QuotationCodeTable?.Data ?? []
  const hit = rows.find(item => isAShareTicker(item.Code) && exchangeOf(item.Code)?.eastmoney === item.MktNum)
    ?? rows.find(item => isAShareTicker(item.Code))
  return hit?.Code
}

/** Realtime-ish snapshot from the eastmoney delayed-quote host. */
export interface QuoteSnapshot {
  name: string
  ticker: string
  price: number
  changePercent: number
  volume: number
  amount: number
  turnoverRate: number
  volumeRatio: number
  high: number
  low: number
  open: number
  previousClose: number
  totalMarketCap: number
  peTtm: number
  mainNetInflow: number
  mainNetInflowPercent: number
}

export async function fetchQuote(ticker: string): Promise<QuoteSnapshot> {
  interface Ulist {
    data?: { diff?: Record<string, number | string>[] }
  }
  const fields = 'f2,f3,f5,f6,f8,f10,f12,f14,f15,f16,f17,f18,f20,f23,f62,f184'
  const url = `https://push2delay.eastmoney.com/api/qt/ulist.np/get?secids=${exchangeOf(ticker)?.eastmoney}.${ticker}&fields=${fields}&fltt=2&invt=2`
  const data = await getJson<Ulist>(url)
  const row = data.data?.diff?.[0]
  if (row === undefined) throw new Error(`no quote for ${ticker}`)
  const num = (key: string): number => {
    const value = row[key]
    return typeof value === 'number' ? value : Number(value)
  }
  return {
    name: String(row.f14),
    ticker: String(row.f12),
    price: num('f2'),
    changePercent: num('f3'),
    volume: num('f5'),
    amount: num('f6'),
    turnoverRate: num('f8'),
    volumeRatio: num('f10'),
    high: num('f15'),
    low: num('f16'),
    open: num('f17'),
    previousClose: num('f18'),
    totalMarketCap: num('f20'),
    peTtm: num('f23'),
    mainNetInflow: num('f62'),
    mainNetInflowPercent: num('f184'),
  }
}

/** Daily forward-adjusted OHLCV bars (Tencent), up to `count` most recent. */
export async function fetchDailyBars(ticker: string, count = 320): Promise<Bar[]> {
  interface Kline {
    code: number
    data?: Record<string, { qfqday?: (string | number)[][]; day?: (string | number)[][] }>
  }
  const symbol = `${exchangeOf(ticker)?.tencent}${ticker}`
  const url = `https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=${symbol},day,,,${count},qfq`
  const data = await getJson<Kline>(url)
  const entry = data.data?.[symbol]
  const rows = entry?.qfqday ?? entry?.day
  if (rows === undefined || rows.length === 0) throw new Error(`no bars for ${ticker}`)
  const bars: Bar[] = []
  for (const row of rows) {
    if (row.length < 6) continue
    bars.push({
      date: String(row[0]),
      open: Number(row[1]),
      close: Number(row[2]),
      high: Number(row[3]),
      low: Number(row[4]),
      volume: Number(row[5]),
    })
  }
  if (bars.length === 0) throw new Error(`no parsable bars for ${ticker}`)
  return bars
}

/** Per-day main-force net inflow history (yuan), oldest first. */
export async function fetchFundFlowHistory(ticker: string, days = 30): Promise<{ date: string; mainNet: number }[]> {
  interface Fflow {
    data?: { klines?: string[] }
  }
  const url = `https://push2delay.eastmoney.com/api/qt/stock/fflow/daykline/get?lmt=${days}&klt=101&secid=${exchangeOf(ticker)?.eastmoney}.${ticker}`
    + `&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65`
  const data = await getJson<Fflow>(url)
  return (data.data?.klines ?? []).map(line => {
    const parts = line.split(',')
    return { date: parts[0], mainNet: Number(parts[1]) }
  })
}

/** Industry board fund-flow ranking (top N by main-force net inflow today). */
export interface BoardFlow {
  name: string
  changePercent: number
  mainNet: number
  mainNetPercent: number
}

export async function fetchBoardFundFlow(limit = 15): Promise<BoardFlow[]> {
  interface Clist {
    data?: { diff?: Record<string, number | string>[] }
  }
  const url = 'https://push2delay.eastmoney.com/api/qt/clist/get?pn=1&pz=30&po=1&np=1&fltt=2&invt=2&fid=f62&fs=m:90+t:2'
    + '&fields=f12,f14,f3,f62,f184'
  const data = await getJson<Clist>(url)
  return (data.data?.diff ?? []).slice(0, limit).map(row => ({
    name: String(row.f14),
    changePercent: Number(row.f3),
    mainNet: Number(row.f62),
    mainNetPercent: Number(row.f184),
  }))
}

/** Stock-specific news from the eastmoney search API. */
export interface NewsItem {
  title: string
  content: string
  date: string
}

export async function fetchStockNews(ticker: string, limit = 20): Promise<NewsItem[]> {
  interface SearchBody {
    result?: {
      cmsArticleWebOld?: {
        data?: { title?: string; content?: string; date?: string }[]
      }
    }
  }
  const param = JSON.stringify({
    uid: '',
    keyword: ticker,
    type: ['cmsArticleWebOld'],
    client: 'web',
    clientType: 'web',
    clientVersion: 'curr',
    param: {
      cmsArticleWebOld: {
        searchScope: 'default',
        sort: 'time',
        pageIndex: 1,
        pageSize: limit,
        preTag: '<em>',
        postTag: '</em>',
      },
    },
  })
  const url = `https://search-api-web.eastmoney.com/search/jsonp?cb=cb&param=${encodeURIComponent(param)}`
  const body = await getJsonp<SearchBody>(url)
  const clean = (text: string): string => text.replaceAll('<em>', '').replaceAll('</em>', '').trim()
  return (body.result?.cmsArticleWebOld?.data ?? [])
    .filter(row => row.title !== undefined)
    .map(row => ({
      title: clean(row.title ?? ''),
      content: clean(row.content ?? '').slice(0, 200),
      date: row.date ?? '',
    }))
}

/** Global market flash news (7x24 feed) for macro context. */
export async function fetchGlobalNews(limit = 20): Promise<NewsItem[]> {
  interface FastNews {
    data?: { fastNewsList?: { title?: string; summary?: string; showTime?: string }[] }
  }
  const url = `https://np-weblist.eastmoney.com/comm/web/getFastNewsList?client=web&biz=web_724&fastColumn=102&sortEnd=&pageSize=${limit}&req_trace=${Date.now()}`
  const data = await getJson<FastNews>(url)
  return (data.data?.fastNewsList ?? [])
    .filter(row => row.title !== undefined)
    .map(row => ({
      title: row.title ?? '',
      content: (row.summary ?? '').slice(0, 160),
      date: row.showTime ?? '',
    }))
}

/** Dragon-tiger list rows for one ticker on a trade date, if listed. */
export interface LhbRow {
  tradeDate: string
  reason: string
  netBuy: number
  buyAmount: number
  sellAmount: number
}

export async function fetchLhb(ticker: string, tradeDate: string): Promise<LhbRow[]> {
  interface Center {
    result?: { data?: Record<string, unknown>[] }
  }
  const filter = encodeURIComponent(`(TRADE_DATE='${tradeDate}')(SECURITY_CODE="${ticker}")`)
  const url = `https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_DAILYBILLBOARD_DETAILSNEW&columns=ALL&filter=${filter}&pageSize=10&source=WEB&client=WEB`
  const data = await getJson<Center>(url)
  return (data.result?.data ?? []).map(row => ({
    tradeDate: String(row.TRADE_DATE ?? '').slice(0, 10),
    reason: String(row.EXPLANATION ?? ''),
    netBuy: Number(row.BILLBOARD_NET_AMT ?? 0),
    buyAmount: Number(row.BILLBOARD_BUY_AMT ?? 0),
    sellAmount: Number(row.BILLBOARD_SELL_AMT ?? 0),
  }))
}

/** Limit-up pool summary for a trade date (best-effort; token-gated upstream). */
export async function fetchLimitUpPool(tradeDate: string): Promise<{ count: number; leaders: string[] }> {
  interface ZtPool {
    data?: { pool?: { name?: string }[] }
  }
  const compact = tradeDate.replaceAll('-', '')
  const url = `https://push2ex.eastmoney.com/getTopicZTPool?ut=7eea3edca687e283f647bcdcd0f124a3&dpt=wz.ztzt&Pageindex=0&pagesize=200&sort=fbt%3Aasc&date=${compact}`
  const data = await getJson<ZtPool>(url)
  const pool = data.data?.pool ?? []
  return { count: pool.length, leaders: pool.slice(0, 10).map(row => row.name ?? '') }
}

/** Main financial-indicator rows (per report period), newest first. */
export interface FundamentalsRow {
  reportDate: string
  eps: number
  roe: number
  revenue: number
  revenueYoy: number
  netProfit: number
  netProfitYoy: number
  grossMargin: number
  netMargin: number
  debtRatio: number
}

export async function fetchFundamentals(ticker: string, periods = 6): Promise<FundamentalsRow[]> {
  interface Center {
    result?: { data?: Record<string, unknown>[] }
  }
  const secuCode = `${ticker}.${exchangeOf(ticker)?.eastmoney === '1' ? 'SH' : 'SZ'}`
  const filter = encodeURIComponent(`(SECUCODE="${secuCode}")`)
  const url = `https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_F10_FINANCE_MAINFINADATA&columns=ALL&filter=${filter}&pageNumber=1&pageSize=${periods}&sortTypes=-1&sortColumns=REPORT_DATE&source=HSF10&client=PC`
  const data = await getJson<Center>(url)
  return (data.result?.data ?? []).map(row => {
    const num = (...keys: string[]): number => {
      for (const key of keys) {
        const value = row[key]
        if (typeof value === 'number') return value
        if (typeof value === 'string' && value !== '' && !Number.isNaN(Number(value))) return Number(value)
      }
      return Number.NaN
    }
    return {
      reportDate: String(row.REPORT_DATE ?? '').slice(0, 10),
      eps: num('EPSJB', 'BASIC_EPS'),
      roe: num('ROEJQ', 'WEIGHT_AVG_ROE'),
      revenue: num('TOTALOPERATEREVE', 'TOTAL_OPERATE_INCOME'),
      revenueYoy: num('TOTALOPERATEREVETZ', 'TOTAL_OPERATE_INCOME_SQ'),
      netProfit: num('PARENTNETPROFIT', 'PARENT_NETPROFIT'),
      netProfitYoy: num('PARENTNETPROFITTZ', 'PARENT_NETPROFIT_SQ'),
      grossMargin: num('XSMLL', 'GROSS_PROFIT_RATIO'),
      netMargin: num('XSJLL', 'NET_PROFIT_RATIO'),
      debtRatio: num('ZCFZL', 'DEBT_ASSET_RATIO'),
    }
  })
}

type StatementKey = 'RPT_DMSK_FN_BALANCE' | 'RPT_DMSK_FN_INCOME' | 'RPT_DMSK_FN_CASHFLOW'

async function fetchStatement(ticker: string, reportName: StatementKey, periods: number): Promise<Record<string, unknown>[]> {
  interface Center {
    result?: { data?: Record<string, unknown>[] }
  }
  const secuCode = `${ticker}.${exchangeOf(ticker)?.eastmoney === '1' ? 'SH' : 'SZ'}`
  const filter = encodeURIComponent(`(SECUCODE="${secuCode}")`)
  const url = `https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=${reportName}&columns=ALL&filter=${filter}&pageNumber=1&pageSize=${periods}&sortTypes=-1&sortColumns=REPORT_DATE&source=HSF10&client=PC`
  const data = await getJson<Center>(url)
  return data.result?.data ?? []
}

const numOf = (row: Record<string, unknown>, ...keys: string[]): number => {
  for (const key of keys) {
    const value = row[key]
    if (typeof value === 'number') return value
    if (typeof value === 'string' && value !== '' && !Number.isNaN(Number(value))) return Number(value)
  }
  return Number.NaN
}

/** One balance-sheet row (yuan), newest first. */
export interface StatementRow {
  reportDate: string
  totalAssets: number
  totalLiabilities: number
  monetaryFunds: number
  inventory: number
  goodwill: number
  totalEquity: number
}

export async function fetchBalanceSheet(ticker: string, periods = 4): Promise<StatementRow[]> {
  const rows = await fetchStatement(ticker, 'RPT_DMSK_FN_BALANCE', periods)
  return rows.map(row => ({
    reportDate: String(row.REPORT_DATE ?? '').slice(0, 10),
    totalAssets: numOf(row, 'TOTAL_ASSETS', 'TOTALASSETS'),
    totalLiabilities: numOf(row, 'TOTAL_LIABILITIES', 'TOTAL_LIAB'),
    monetaryFunds: numOf(row, 'MONETARYFUNDS', 'MONETARY_FUNDS'),
    inventory: numOf(row, 'INVENTORY', 'INVENTORY_AMT'),
    goodwill: numOf(row, 'GOODWILL'),
    totalEquity: numOf(row, 'TOTAL_EQUITY', 'TOTAL_PARENT_EQUITY'),
  }))
}

/** One income-statement row (yuan). */
export interface IncomeRow {
  reportDate: string
  revenue: number
  operatingCost: number
  sellingExpense: number
  adminExpense: number
  financeExpense: number
  rdExpense: number
  netProfit: number
}

export async function fetchIncomeStatement(ticker: string, periods = 4): Promise<IncomeRow[]> {
  const rows = await fetchStatement(ticker, 'RPT_DMSK_FN_INCOME', periods)
  return rows.map(row => ({
    reportDate: String(row.REPORT_DATE ?? '').slice(0, 10),
    revenue: numOf(row, 'TOTAL_OPERATE_INCOME'),
    operatingCost: numOf(row, 'OPERATE_COST'),
    sellingExpense: numOf(row, 'SALE_EXPENSE'),
    adminExpense: numOf(row, 'MANAGE_EXPENSE'),
    financeExpense: numOf(row, 'FINANCE_EXPENSE'),
    rdExpense: numOf(row, 'RESEARCH_EXPENSE'),
    netProfit: numOf(row, 'PARENT_NETPROFIT'),
  }))
}

/** One cash-flow-statement row (yuan). */
export interface CashflowRow {
  reportDate: string
  operatingCashflow: number
  investingCashflow: number
  financingCashflow: number
  freeCashflow: number
}

export async function fetchCashflowStatement(ticker: string, periods = 4): Promise<CashflowRow[]> {
  const rows = await fetchStatement(ticker, 'RPT_DMSK_FN_CASHFLOW', periods)
  return rows.map(row => ({
    reportDate: String(row.REPORT_DATE ?? '').slice(0, 10),
    operatingCashflow: numOf(row, 'NETCASH_OPERATE'),
    investingCashflow: numOf(row, 'NETCASH_INVEST'),
    financingCashflow: numOf(row, 'NETCASH_FINANCE'),
    freeCashflow: numOf(row, 'FREE_CASHFLOW'),
  }))
}
