/**
 * Technical indicator math over daily OHLCV bars, ported from the original
 * project's stockstats usage (the exact indicator set its market analyst
 * prompt names). Pure functions, no I/O — unit-testable in isolation.
 * @module dsh-tradingagents/data/indicators
 */

/** One daily bar, all fields raw numbers as they came off the wire. */
export interface Bar {
  readonly date: string
  readonly open: number
  readonly close: number
  readonly high: number
  readonly low: number
  readonly volume: number
  /** Turnover in yuan (成交额), when the source provides it. */
  readonly amount?: number
}

const last = (values: readonly (number | undefined)[]): number | undefined => values[values.length - 1]

function sma(values: readonly number[], window: number): number[] {
  const out: number[] = []
  let sum = 0
  for (let i = 0; i < values.length; i++) {
    sum += values[i]
    if (i >= window) sum -= values[i - window]
    out.push(i >= window - 1 ? sum / window : Number.NaN)
  }
  return out
}

function ema(values: readonly number[], window: number): number[] {
  const k = 2 / (window + 1)
  const out: number[] = []
  let prev = values[0]
  for (let i = 0; i < values.length; i++) {
    prev = i === 0 ? values[0] : values[i] * k + prev * (1 - k)
    out.push(prev)
  }
  return out
}

function stdDev(values: readonly number[], window: number): number[] {
  const means = sma(values, window)
  return values.map((_, i) => {
    if (i < window - 1) return Number.NaN
    let acc = 0
    for (let j = i - window + 1; j <= i; j++) acc += (values[j] - means[i]) ** 2
    return Math.sqrt(acc / window)
  })
}

/** Simple-moving-average of the closing prices over `window` days. */
export function closeSma(bars: readonly Bar[], window: number): number | undefined {
  if (bars.length < window) return undefined
  return last(sma(bars.map(bar => bar.close), window))
}

/** Exponential-moving-average of the closing prices over `window` days. */
export function closeEma(bars: readonly Bar[], window: number): number | undefined {
  if (bars.length < window) return undefined
  return last(ema(bars.map(bar => bar.close), window))
}

/** RSI-14 (Wilder). */
export function rsi(bars: readonly Bar[], window = 14): number | undefined {
  if (bars.length <= window) return undefined
  let gains = 0
  let losses = 0
  for (let i = 1; i <= window; i++) {
    const delta = bars[i].close - bars[i - 1].close
    if (delta >= 0) gains += delta
    else losses -= delta
  }
  let avgGain = gains / window
  let avgLoss = losses / window
  for (let i = window + 1; i < bars.length; i++) {
    const delta = bars[i].close - bars[i - 1].close
    avgGain = (avgGain * (window - 1) + Math.max(delta, 0)) / window
    avgLoss = (avgLoss * (window - 1) + Math.max(-delta, 0)) / window
  }
  if (avgLoss === 0) return 100
  return 100 - 100 / (1 + avgGain / avgLoss)
}

/** MACD(12,26,9): returns dif (macd), dea (macds), histogram (macdh). */
export function macd(bars: readonly Bar[]): { dif: number; dea: number; histogram: number } | undefined {
  const closes = bars.map(bar => bar.close)
  if (closes.length < 35) return undefined
  const fast = ema(closes, 12)
  const slow = ema(closes, 26)
  const difSeries = closes.map((_, i) => fast[i] - slow[i])
  const deaSeries = ema(difSeries, 9)
  const dif = last(difSeries)
  const dea = last(deaSeries)
  if (dif === undefined || dea === undefined) return undefined
  return { dif, dea, histogram: (dif - dea) * 2 }
}

/** Bollinger(20, 2): mid band plus upper/lower. */
export function boll(bars: readonly Bar[], window = 20, mult = 2): { mid: number; ub: number; lb: number } | undefined {
  const closes = bars.map(bar => bar.close)
  if (closes.length < window) return undefined
  const mid = last(sma(closes, window))
  const dev = last(stdDev(closes, window))
  if (mid === undefined || dev === undefined) return undefined
  return { mid, ub: mid + mult * dev, lb: mid - mult * dev }
}

/** Average True Range over `window` days (Wilder smoothing). */
export function atr(bars: readonly Bar[], window = 14): number | undefined {
  if (bars.length <= window) return undefined
  const trs: number[] = []
  for (let i = 1; i < bars.length; i++) {
    const bar = bars[i]
    const prevClose = bars[i - 1].close
    trs.push(Math.max(bar.high - bar.low, Math.abs(bar.high - prevClose), Math.abs(bar.low - prevClose)))
  }
  let value = trs.slice(0, window).reduce((acc, tr) => acc + tr, 0) / window
  for (let i = window; i < trs.length; i++) value = (value * (window - 1) + trs[i]) / window
  return value
}

/** Volume-weighted moving average of the close over `window` days. */
export function vwma(bars: readonly Bar[], window = 20): number | undefined {
  if (bars.length < window) return undefined
  let pv = 0
  let vv = 0
  for (let i = bars.length - window; i < bars.length; i++) {
    pv += bars[i].close * bars[i].volume
    vv += bars[i].volume
  }
  return vv === 0 ? undefined : pv / vv
}

/**
 * The indicator snapshot the market analyst prompt expects, mirroring the
 * original project's `get_indicators` tool output (calc_map keys).
 */
export function indicatorSnapshot(bars: readonly Bar[]): Record<string, string> {
  const round = (value: number | undefined): string =>
    value === undefined || !Number.isFinite(value) ? 'N/A' : String(Math.round(value * 100) / 100)
  return {
    close_50_sma: round(closeSma(bars, 50)),
    close_200_sma: round(closeSma(bars, 200)),
    close_10_ema: round(closeEma(bars, 10)),
    rsi: round(rsi(bars)),
    macd: round(macd(bars)?.dif),
    macds: round(macd(bars)?.dea),
    macdh: round(macd(bars)?.histogram),
    boll: round(boll(bars)?.mid),
    boll_ub: round(boll(bars)?.ub),
    boll_lb: round(boll(bars)?.lb),
    atr: round(atr(bars)),
    vwma: round(vwma(bars)),
  }
}

/**
 * Compact volume-price narrative table for the VPA analyst: the last N days
 * with per-day volume z-score (relative to the prior 20-day mean/std) and
 * elementary candle anatomy the VPA framework reasons over.
 */
export function vpaTable(bars: readonly Bar[], days = 30): string {
  if (bars.length < 25) return 'VPA 数据不足'
  const lines: string[] = ['日期 | 开盘 | 收盘 | 最高 | 最低 | 涨跌幅% | 量比分 | K线形态']
  const window = 20
  const start = Math.max(window, bars.length - days)
  for (let i = start; i < bars.length; i++) {
    const bar = bars[i]
    const prior = bars.slice(i - window, i)
    const meanVolume = prior.reduce((acc, b) => acc + b.volume, 0) / prior.length
    const variance = prior.reduce((acc, b) => acc + (b.volume - meanVolume) ** 2, 0) / prior.length
    const std = Math.sqrt(variance)
    const z = std === 0 ? 0 : (bar.volume - meanVolume) / std
    const change = ((bar.close - bars[i - 1].close) / bars[i - 1].close) * 100
    const range = bar.high - bar.low
    const body = Math.abs(bar.close - bar.open)
    const upperShadow = bar.high - Math.max(bar.close, bar.open)
    const lowerShadow = Math.min(bar.close, bar.open) - bar.low
    let shape: string
    if (range > 0 && body / range < 0.3 && upperShadow > body * 2) shape = '射击十字星/长上影'
    else if (range > 0 && body / range < 0.3 && lowerShadow > body * 2) shape = '锤头线/长下影'
    else if (range > 0 && body / range < 0.3) shape = '十字星'
    else if (body / range > 0.7) shape = bar.close >= bar.open ? '高实体阳线' : '高实体阴线'
    else shape = bar.close >= bar.open ? '短阳线' : '短阴线'
    lines.push(
      `${bar.date} | ${bar.open} | ${bar.close} | ${bar.high} | ${bar.low} | ${(Math.round(change * 100) / 100)} | ${(Math.round(z * 10) / 10)} | ${shape}`,
    )
  }
  return lines.join('\n')
}
