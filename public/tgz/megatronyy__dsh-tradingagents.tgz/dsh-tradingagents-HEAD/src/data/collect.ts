/**
 * Data collection: every source fetched in parallel with its own timeout,
 * failures degrade to per-source "missing" notes (the original project's
 * `_safe` philosophy — an analysis never dies because one feed is blocked).
 * The collected bundle is then sliced into per-analyst context blocks.
 * @module dsh-tradingagents/data/collect
 */
import {
  fetchBoardFundFlow, fetchCashflowStatement, fetchDailyBars, fetchFundamentals, fetchFundFlowHistory,
  fetchGlobalNews, fetchIncomeStatement, fetchLhb, fetchLimitUpPool, fetchQuote, fetchStockNews,
  fetchBalanceSheet, isAShareTicker,
  type BoardFlow, type CashflowRow, type FundamentalsRow, type IncomeRow, type LhbRow, type NewsItem,
  type QuoteSnapshot, type StatementRow,
} from './eastmoney.ts'
import { indicatorSnapshot, vpaTable, type Bar } from './indicators.ts'

/** Everything one analysis run works from. */
export interface MarketData {
  ticker: string
  tradeDate: string
  quote?: QuoteSnapshot
  bars?: Bar[]
  indicators?: Record<string, string>
  vpa?: string
  news: NewsItem[]
  globalNews: NewsItem[]
  fundFlowHistory: { date: string; mainNet: number }[]
  boardFlows: BoardFlow[]
  lhb: LhbRow[]
  limitUp?: { count: number; leaders: string[] }
  fundamentals: FundamentalsRow[]
  balanceSheet: StatementRow[]
  incomeStatement: IncomeRow[]
  cashflow: CashflowRow[]
  missing: string[]
}

async function safe<T>(label: string, missing: string[], task: () => Promise<T>): Promise<T | undefined> {
  try {
    return await task()
  } catch {
    missing.push(label)
    return undefined
  }
}

const yi = (value: number): string => `${(value / 1e8).toFixed(2)}亿`
const percent = (value: number): string => `${value.toFixed(2)}%`

/**
 * Collect all sources for one ticker. `tradeDate` defaults to the latest bar
 * date (works pre-market and on holidays).
 */
export async function collectMarketData(ticker: string): Promise<MarketData> {
  if (!isAShareTicker(ticker)) throw new Error(`${ticker} 不是可识别的 A 股代码`)
  const missing: string[] = []
  const [quote, bars, fundFlowHistory, boardFlows, news, globalNews, lhb, limitUp, fundamentals, balanceSheet, incomeStatement, cashflow] = await Promise.all([
    safe('实时行情快照', missing, () => fetchQuote(ticker)),
    safe('历史K线', missing, () => fetchDailyBars(ticker, 320)),
    safe('个股资金流', missing, () => fetchFundFlowHistory(ticker, 30)),
    safe('板块资金流', missing, () => fetchBoardFundFlow(15)),
    safe('个股新闻', missing, () => fetchStockNews(ticker, 20)),
    safe('财经快讯', missing, () => fetchGlobalNews(20)),
    safe('龙虎榜', missing, () => fetchLhb(ticker, tradeDateOf(new Date()))),
    safe('涨停池', missing, () => fetchLimitUpPool(tradeDateOf(new Date()))),
    safe('财务主要指标', missing, () => fetchFundamentals(ticker, 6)),
    safe('资产负债表', missing, () => fetchBalanceSheet(ticker, 4)),
    safe('利润表', missing, () => fetchIncomeStatement(ticker, 4)),
    safe('现金流量表', missing, () => fetchCashflowStatement(ticker, 4)),
  ])

  const tradeDate = bars !== undefined && bars.length > 0 ? bars[bars.length - 1].date : tradeDateOf(new Date())
  const indicators = bars !== undefined ? indicatorSnapshot(bars) : undefined
  const vpa = bars !== undefined ? vpaTable(bars, 30) : undefined

  return {
    ticker,
    tradeDate,
    quote,
    bars,
    indicators,
    vpa,
    news: news ?? [],
    globalNews: globalNews ?? [],
    fundFlowHistory: fundFlowHistory ?? [],
    boardFlows: boardFlows ?? [],
    lhb: lhb ?? [],
    limitUp,
    fundamentals: fundamentals ?? [],
    balanceSheet: balanceSheet ?? [],
    incomeStatement: incomeStatement ?? [],
    cashflow: cashflow ?? [],
    missing,
  }
}

/** Most recent plausible A-share trade date for `now` (weekends roll back). */
export function tradeDateOf(now: Date): string {
  const date = new Date(now)
  while (date.getDay() === 0 || date.getDay() === 6) date.setDate(date.getDate() - 1)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

const newsBlock = (items: NewsItem[], limit = 15): string =>
  items.slice(0, limit).map(item => `- [${item.date}] ${item.title}：${item.content}`).join('\n')

/** Per-analyst data slices, mirroring the original tool assignments. */
export function marketSlice(data: MarketData): string {
  if (data.bars === undefined || data.indicators === undefined) return 'K线/指标数据缺失，请明确说明置信度下降'
  const recent = data.bars.slice(-10).map(bar =>
    `${bar.date} 开${bar.open} 收${bar.close} 高${bar.high} 低${bar.low} 量${Math.round(bar.volume)}`).join('\n')
  const quote = data.quote === undefined ? '' : `\n实时快照：现价 ${data.quote.price}（${percent(data.quote.changePercent)}），今日区间 ${data.quote.low}–${data.quote.high}，换手 ${percent(data.quote.turnoverRate)}，量比 ${data.quote.volumeRatio}`
  return `最近10个交易日K线：\n${recent}${quote}\n\n技术指标（当前值）：\n${Object.entries(data.indicators).map(([key, value]) => `${key}=${value}`).join(' ')}`
}

export function newsSlice(data: MarketData): string {
  return `个股新闻（${data.quote?.name ?? data.ticker}）：\n${newsBlock(data.news) || '无新闻数据'}\n\n财经快讯（宏观/市场）：\n${newsBlock(data.globalNews, 12) || '无快讯数据'}`
}

export function socialSlice(data: MarketData): string {
  const limitUp = data.limitUp === undefined ? '涨停池数据缺失' : `今日涨停 ${data.limitUp.count} 家，代表：${data.limitUp.leaders.join('、') || '—'}`
  return `新闻热度线索：\n${newsBlock(data.news, 10) || '无'}\n\n市场情绪面板：\n${limitUp}\n今日个股涨跌幅：${data.quote === undefined ? '缺失' : percent(data.quote.changePercent)}\n换手率：${data.quote === undefined ? '缺失' : percent(data.quote.turnoverRate)}`
}

export function fundamentalsSlice(data: MarketData): string {
  if (data.fundamentals.length === 0 && data.balanceSheet.length === 0) return '财务数据缺失，请明确说明置信度下降'
  const main = data.fundamentals.map(row =>
    `${row.reportDate}：EPS ${row.eps}，ROE ${percent(row.roe)}，营收 ${yi(row.revenue)}（同比 ${percent(row.revenueYoy)}），归母净利 ${yi(row.netProfit)}（同比 ${percent(row.netProfitYoy)}），毛利率 ${percent(row.grossMargin)}，净利率 ${percent(row.netMargin)}，资产负债率 ${percent(row.debtRatio)}`).join('\n')
  const balance = data.balanceSheet[0] === undefined ? '' : `\n资产负债表（${data.balanceSheet[0].reportDate}）：总资产 ${yi(data.balanceSheet[0].totalAssets)}，总负债 ${yi(data.balanceSheet[0].totalLiabilities)}，货币资金 ${yi(data.balanceSheet[0].monetaryFunds)}，存货 ${yi(data.balanceSheet[0].inventory)}，商誉 ${yi(data.balanceSheet[0].goodwill)}`
  const income = data.incomeStatement[0] === undefined ? '' : `\n利润表（${data.incomeStatement[0].reportDate}）：营收 ${yi(data.incomeStatement[0].revenue)}，营业成本 ${yi(data.incomeStatement[0].operatingCost)}，销售费 ${yi(data.incomeStatement[0].sellingExpense)}，管理费 ${yi(data.incomeStatement[0].adminExpense)}，财务费 ${yi(data.incomeStatement[0].financeExpense)}，研发费 ${yi(data.incomeStatement[0].rdExpense)}，归母净利 ${yi(data.incomeStatement[0].netProfit)}`
  const cash = data.cashflow.map(row => `${row.reportDate}：经营现金流 ${yi(row.operatingCashflow)}，投资 ${yi(row.investingCashflow)}，筹资 ${yi(row.financingCashflow)}，自由现金流 ${yi(row.freeCashflow)}`).join('\n')
  return `财务主要指标（各报告期）：\n${main || '缺失'}${balance}${income}\n\n现金流量表：\n${cash || '缺失'}`
}

export function macroSlice(data: MarketData): string {
  const boards = data.boardFlows.map(row =>
    `${row.name}：涨跌 ${percent(row.changePercent)}，主力净流入 ${yi(row.mainNet)}（占比 ${percent(row.mainNetPercent)})`).join('\n')
  return `今日行业板块主力资金排名（净流入前列）：\n${boards || '板块资金流数据缺失'}\n\n相关新闻：\n${newsBlock(data.news, 8) || '无'}`
}

export function smartMoneySlice(data: MarketData): string {
  const flow = data.fundFlowHistory.slice(-10).map(row => `${row.date}：主力净流入 ${yi(row.mainNet)}`).join('\n')
  const quote = data.quote === undefined ? '' : `今日主力净流入 ${yi(data.quote.mainNetInflow)}（占成交 ${percent(data.quote.mainNetInflowPercent)}），换手率 ${percent(data.quote.turnoverRate)}`
  const lhb = data.lhb.map(row => `${row.tradeDate} ${row.reason}：净买入 ${yi(row.netBuy)}（买 ${yi(row.buyAmount)} / 卖 ${yi(row.sellAmount)})`).join('\n')
  return `${quote}\n\n近10日主力资金：\n${flow || '资金流历史缺失'}\n\n龙虎榜：\n${lhb || '近期无龙虎榜记录'}`
}

export function volumePriceSlice(data: MarketData): string {
  return data.vpa ?? '量价数据缺失'
}
