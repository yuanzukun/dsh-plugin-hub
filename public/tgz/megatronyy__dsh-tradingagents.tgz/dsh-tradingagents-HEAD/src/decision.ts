/**
 * Structured decision record: one analysis distilled into a machine-readable
 * JSON document persisted next to its Markdown report (`<id>.decision.json`).
 * Direction and per-role verdicts come from the machine blocks; the trade
 * plan merges the trader's final verdict with the risk manager's stop and
 * targets (the risk review owns those constraints), with prose fallback
 * recovery already applied upstream. This record is the foundation for
 * follow-up features — accuracy tracking, memory, notifications — which
 * read decisions back without re-parsing Markdown.
 * @module dsh-tradingagents/decision
 */
import type { AnalysisResult } from './pipeline.ts'
import type { Verdict } from './llm.ts'

/** Bump when fields are added or semantics change; readers stay permissive. */
export const DECISION_SCHEMA_VERSION = 1

/** Quote facts frozen at analysis time (the baseline later tracking compares against). */
export interface DecisionQuote {
  price: number
  changePercent: number
  tradeDate: string
  totalMarketCap: number
  peTtm: number
}

/** One role's verdict row: every report-producing stage gets one. */
export interface DecisionRoleVerdict {
  role: string
  label: string
  direction: string
  reason: string
}

/** The merged trade plan; absent fields were never stated by any role. */
export interface DecisionPlan {
  action?: string
  confidence?: number
  entry?: string
  stop?: string
  targets?: string[]
  positionPct?: number
  /** Roles the values were merged from, for provenance. */
  sources: string[]
  /** True when at least one value was recovered from prose, not a machine block. */
  fromText?: boolean
}

/** The full record; `id` is filled in at persistence time. */
export interface DecisionRecord {
  schemaVersion: number
  id: string
  createdAt: string
  ticker: string
  name: string
  tradeDate: string
  quote?: DecisionQuote
  query: {
    focusAreas: string[]
    specificQuestions: string[]
    userContext: Record<string, unknown>
  }
  dataGaps: string[]
  roles: DecisionRoleVerdict[]
  manager: DecisionRoleVerdict
  riskManager: DecisionRoleVerdict
  final: DecisionRoleVerdict
  plan: DecisionPlan
}

const pickVerdict = (verdict: Verdict | undefined): Pick<Verdict, 'direction' | 'reason'> => ({
  direction: verdict?.direction ?? '—',
  reason: verdict?.reason ?? '',
})

/**
 * The effective trade plan for one analysis: the trader's own values for
 * action/confidence/entry/position, with stop and targets filled from the
 * risk manager when the trader omitted them — the risk review is the stage
 * mandated to state those constraints. Shared by the decision record and the
 * report's plan summary so the two can never disagree.
 */
export function mergedPlan(result: AnalysisResult): DecisionPlan {
  const trader = result.traderFinal.verdict
  const risk = result.riskManagerReport.verdict
  const plan: DecisionPlan = {
    ...(trader?.action === undefined ? {} : { action: trader.action }),
    ...(trader?.confidence === undefined ? {} : { confidence: trader.confidence }),
    ...(trader?.entry === undefined && risk?.entry === undefined ? {} : { entry: trader?.entry ?? risk?.entry }),
    ...(trader?.stop === undefined && risk?.stop === undefined ? {} : { stop: trader?.stop ?? risk?.stop }),
    ...(trader?.targets === undefined && risk?.targets === undefined ? {} : { targets: trader?.targets ?? risk?.targets }),
    ...(trader?.positionPct === undefined ? {} : { positionPct: trader.positionPct }),
    sources: [],
  }
  const planKeys = ['action', 'confidence', 'entry', 'stop', 'targets', 'positionPct'] as const
  const contributed = (verdict: Verdict | undefined): boolean =>
    verdict !== undefined && planKeys.some(key => verdict[key] !== undefined && verdict[key] === plan[key])
  if (contributed(trader)) plan.sources.push('trader')
  if (contributed(risk)) plan.sources.push('riskManager')
  if (trader?.fromText === true || risk?.fromText === true) plan.fromText = true
  return plan
}

/**
 * Distill one analysis result into a {@link DecisionRecord}. The plan prefers
 * the trader's own values (action/confidence/entry/position) and fills stop
 * and targets from the risk manager when the trader omitted them — the risk
 * review is the stage mandated to state those constraints.
 */
export function composeDecisionRecord(result: AnalysisResult, id: string): DecisionRecord {
  const { intent, data, analystReports, managerReport, riskManagerReport, traderFinal } = result
  const plan = mergedPlan(result)

  return {
    schemaVersion: DECISION_SCHEMA_VERSION,
    id,
    createdAt: new Date().toISOString(),
    ticker: intent.ticker,
    name: intent.name,
    tradeDate: data.tradeDate,
    ...(data.quote === undefined ? {} : {
      quote: {
        price: data.quote.price,
        changePercent: data.quote.changePercent,
        tradeDate: data.tradeDate,
        totalMarketCap: data.quote.totalMarketCap,
        peTtm: data.quote.peTtm,
      },
    }),
    query: {
      focusAreas: intent.focusAreas,
      specificQuestions: intent.specificQuestions,
      userContext: intent.userContext,
    },
    dataGaps: data.missing,
    roles: analystReports.map(report => ({ role: report.role, label: report.label, ...pickVerdict(report.verdict) })),
    manager: { role: 'manager', label: managerReport.label, ...pickVerdict(managerReport.verdict) },
    riskManager: { role: 'risk_manager', label: riskManagerReport.label, ...pickVerdict(riskManagerReport.verdict) },
    final: { role: 'trader', label: traderFinal.label, ...pickVerdict(traderFinal.verdict) },
    plan,
  }
}
