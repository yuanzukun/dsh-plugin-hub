/**
 * LLM access for the analysis pipeline: one role call is one resolved-route
 * streaming completion whose text is collected. The touched surface of the
 * harness `ctx.llm` service is declared structurally (the loader provides
 * the real runtime), keeping this external package free of monorepo-internal
 * type dependencies — the same approach dsh-market takes.
 * @module dsh-tradingagents/llm
 */
import { createUserMessage, type Message } from '@deepseek-ai/dsh-llm'

/** The llm-service surface this plugin touches (structural). */
export interface LlmService {
  resolveCallConfig(route: { provider?: string; model?: string } | Record<string, never>, signal?: AbortSignal): Promise<{
    provider: string
    model: string
    reasoningEffort?: string
  }>
  stream(options: {
    provider: string
    model: string
    reasoningEffort?: string
    system?: string
    messages: Message[]
    temperature?: number
    maxTokens?: number
    signal?: AbortSignal
  }): AsyncIterable<{ type: string; index?: number; text?: string } & Record<string, unknown>>
}

/** Progress sink the pipeline reports role transitions through. */
export type Progress = (line: string) => void

export interface AskOptions {
  system: string
  user: string
  temperature?: number
  signal?: AbortSignal
}

/**
 * Run one role completion and collect its text. Streaming chunks are read
 * until the stream ends; chunk shapes are matched defensively (text blocks
 * arrive under either `text` or nested delta conventions).
 */
export async function askLlm(llm: LlmService, route: { provider: string; model: string; reasoningEffort?: string }, options: AskOptions): Promise<string> {
  const parts: string[] = []
  const chunkTypes = new Map<string, number>()
  for await (const chunk of llm.stream({
    provider: route.provider,
    model: route.model,
    ...(route.reasoningEffort === undefined ? {} : { reasoningEffort: route.reasoningEffort as never }),
    system: options.system,
    messages: [createUserMessage({ content: [{ type: 'text', text: options.user }], source: { kind: 'user' } })],
    ...(options.temperature === undefined ? {} : { temperature: options.temperature }),
    ...(options.signal === undefined ? {} : { signal: options.signal }),
  })) {
    chunkTypes.set(chunk.type, (chunkTypes.get(chunk.type) ?? 0) + 1)
    const text = chunkText(chunk)
    if (text !== undefined) parts.push(text)
  }
  const text = parts.join('').trim()
  // One structured line per role call: empty completions surface here first.
  console.error(`[dsh-tradingagents] role call "${options.system.slice(0, 20).replace(/\n/g, ' ')}…" chunks=${JSON.stringify([...chunkTypes])} textLen=${text.length}`)
  return text
}

/**
 * Extract displayable text from one stream chunk. The adapter protocol emits
 * `text-delta` for answer text and `reasoning-delta` for model reasoning —
 * only the former belongs in a role report.
 */
function chunkText(chunk: { type: string } & Record<string, unknown>): string | undefined {
  if (chunk.type === 'text-delta' && typeof chunk.text === 'string') return chunk.text
  return undefined
}

/** One role report: full text plus its parsed machine verdict. */
export interface RoleOutput {
  text: string
  verdict?: Verdict
}

/**
 * Parsed verdict: direction/reason come from the `<!-- VERDICT: {...} -->`
 * block; the trade-plan keys are optional and only present when the role
 * stated a concrete value (decision-carrying roles emit them via
 * {@link ../prompts.ts~DECISION_VERDICT_RULE}).
 */
export interface Verdict {
  direction: string
  reason: string
  /** Normalized action: 买入 / 卖出 / 观望 (BUY/SELL/HOLD aliases mapped). */
  action?: string
  /** Self-assessed conviction, 0-100. */
  confidence?: number
  /** Entry zone or price as free text (no unit). */
  entry?: string
  /** Stop-loss price as free text (no unit). */
  stop?: string
  /** Profit targets, nearest first. */
  targets?: string[]
  /** Suggested position size, 0-100 (percent, unit stripped). */
  positionPct?: number
  /** True for keys recovered from the prose instead of the machine block. */
  fromText?: boolean
}

/** Map English aliases onto the canonical action vocabulary. */
function normalizeAction(value: string): string | undefined {
  const upper = value.trim().toUpperCase()
  if (upper === 'BUY' || value.includes('买入')) return '买入'
  if (upper === 'SELL' || value.includes('卖出')) return '卖出'
  if (upper === 'HOLD' || value.includes('观望')) return '观望'
  return undefined
}

const priceList = (value: unknown): string[] | undefined => {
  if (!Array.isArray(value)) return undefined
  const items = value.filter((item): item is string | number => typeof item === 'string' || typeof item === 'number')
  return items.length === 0 ? undefined : items.map(String)
}

const boundedNumber = (value: unknown, min: number, max: number): number | undefined => {
  const num = typeof value === 'number' ? value : typeof value === 'string' ? Number(value.replace(/[^\d.]/g, '')) : NaN
  return Number.isFinite(num) && num >= min && num <= max ? num : undefined
}

const textOrUndefined = (value: unknown): string | undefined => {
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  return trimmed === '' || trimmed === '—' || trimmed === '-' ? undefined : trimmed
}

/** Parse the trailing `<!-- VERDICT: {...} -->` machine block from a role report. */
export function parseVerdict(text: string): Verdict | undefined {
  const match = /<!--\s*VERDICT:\s*(\{.*?\})\s*-->/s.exec(text)
  if (match?.[1] === undefined) return undefined
  try {
    const parsed = JSON.parse(match[1]) as Record<string, unknown>
    if (typeof parsed.direction !== 'string' || parsed.direction === '') return undefined
    return {
      direction: parsed.direction,
      reason: typeof parsed.reason === 'string' ? parsed.reason : '',
      action: typeof parsed.action === 'string' ? normalizeAction(parsed.action) : undefined,
      confidence: boundedNumber(parsed.confidence, 0, 100),
      entry: textOrUndefined(parsed.entry),
      stop: textOrUndefined(parsed.stop),
      targets: priceList(parsed.targets),
      positionPct: boundedNumber(parsed.positionPct, 0, 100),
    }
  } catch {
    return undefined
  }
}

/**
 * Recover trade-plan facts a decision role stated in prose but left out of
 * its machine block: the trader's mandated closing line (最终交易建议：买入)
 * and the risk manager's mandated price line (目标价：23.50；止损价：20.48).
 * Returns undefined when the prose states nothing usable.
 */
export function parsePlanFromText(text: string): Pick<Verdict, 'action' | 'stop' | 'targets' | 'fromText'> | undefined {
  const action = /最终交易建议[：:]\s*(买入|卖出|观望|BUY|SELL|HOLD)/i.exec(text)?.[1]
  const stop = /止损价?[：:]\s*([0-9]+(?:\.[0-9]+)?)/.exec(text)?.[1]
  const targetMatch = /目标价?[：:]\s*([0-9]+(?:\.[0-9]+)?(?:\s*[、,，/]\s*[0-9]+(?:\.[0-9]+)?)*)/.exec(text)?.[1]
  const targets = targetMatch?.split(/\s*[、,，/]\s*/).filter(item => item !== '')
  const normalized = action === undefined ? undefined : normalizeAction(action)
  if (normalized === undefined && stop === undefined && targets === undefined) return undefined
  return {
    ...(normalized === undefined ? {} : { action: normalized }),
    ...(stop === undefined ? {} : { stop }),
    ...(targets === undefined || targets.length === 0 ? {} : { targets }),
    fromText: true,
  }
}

/**
 * A decision role's effective verdict: the parsed machine block enriched
 * with prose-recovered keys the model failed to echo there. Machine-block
 * values always win over prose for the same key.
 */
export function effectiveVerdict(text: string, verdict: Verdict | undefined): Verdict | undefined {
  if (verdict === undefined) return undefined
  const recovered = parsePlanFromText(text)
  if (recovered === undefined) return verdict
  const action = verdict.action ?? recovered.action
  const stop = verdict.stop ?? recovered.stop
  const targets = verdict.targets ?? recovered.targets
  const usedProse = (action !== undefined && action === recovered.action)
    || (stop !== undefined && stop === recovered.stop)
    || (targets !== undefined && targets === recovered.targets)
  return {
    ...verdict,
    ...(action === undefined ? {} : { action }),
    ...(stop === undefined ? {} : { stop }),
    ...(targets === undefined ? {} : { targets }),
    ...(usedProse ? { fromText: true } : {}),
  }
}

/** Extract the first JSON object from a model reply (intent parsing). */
export function extractJson<T>(text: string): T | undefined {
  const stripped = text.replace(/^```(?:json)?\s*/gm, '').replace(/\s*```$/gm, '')
  const start = stripped.indexOf('{')
  const end = stripped.lastIndexOf('}')
  if (start < 0 || end <= start) return undefined
  try {
    return JSON.parse(stripped.slice(start, end + 1)
      .replace(/,\s*([}\]])/g, '$1')) as T
  } catch {
    return undefined
  }
}
