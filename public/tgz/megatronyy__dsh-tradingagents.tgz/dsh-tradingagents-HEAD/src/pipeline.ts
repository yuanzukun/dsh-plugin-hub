/**
 * The 14-role analysis pipeline, ported from TradingAgents-AShare's LangGraph
 * orchestration into plain async functions over the harness LLM service:
 *
 *   7 analysts (parallel) → bull/bear debate (2 rounds, each side sees the
 *   other's latest argument) → research manager verdict → trader plan →
 *   3-way risk debate (aggressive/conservative/neutral) → risk manager
 *   review → final trader decision.
 *
 * Every role call is one LLM completion with its own system prompt; progress
 * lines surface each transition to the command output.
 * @module dsh-tradingagents/pipeline
 */
import { collectMarketData, marketSlice, newsSlice, socialSlice, fundamentalsSlice, macroSlice, smartMoneySlice, volumePriceSlice, type MarketData } from './data/collect.ts'
import { parseIntent, type TradingIntent } from './intent.ts'
import { askLlm, effectiveVerdict, parseVerdict, type LlmService, type Progress, type RoleOutput } from './llm.ts'
import * as P from './prompts.ts'

type Route = { provider: string; model: string; reasoningEffort?: string }

/** One completed analyst (or debate/manager) report. */
export interface RoleReport extends RoleOutput {
  role: string
  label: string
}

const ANALYSTS: { role: string; label: string; system: string; slice: (data: MarketData) => string }[] = [
  { role: 'market', label: '市场技术分析师', system: P.marketAnalyst, slice: marketSlice },
  { role: 'news', label: '新闻与宏观分析师', system: P.newsAnalyst, slice: newsSlice },
  { role: 'social', label: '社交舆情分析师', system: P.socialAnalyst, slice: socialSlice },
  { role: 'fundamentals', label: '基本面分析师', system: P.fundamentalsAnalyst, slice: fundamentalsSlice },
  { role: 'macro', label: '宏观与板块分析师', system: P.macroAnalyst, slice: macroSlice },
  { role: 'smart_money', label: '机构资金分析师', system: P.smartMoneyAnalyst, slice: smartMoneySlice },
  { role: 'volume_price', label: '量价分析师', system: P.volumePriceAnalyst, slice: volumePriceSlice },
]

const FOCUS_BLOCK = (intent: TradingIntent): string => intent.focusAreas.length === 0 && intent.specificQuestions.length === 0
  ? ''
  : `\n\n【用户视角】\n重点关注：${intent.focusAreas.join('、') || '无特定偏好'}\n具体问题：${intent.specificQuestions.map(q => `「${q}」`).join(' ') || '无'}\n用户上下文：${JSON.stringify(intent.userContext) !== '{}' ? JSON.stringify(intent.userContext, null, 1) : '未提供'}`

const DEBATE_ROUNDS = 2

/** Run the whole analysis for one command input. Returns every stage's report. */
export async function runAnalysis(
  llm: LlmService,
  route: Route,
  query: string,
  progress: Progress,
  signal?: AbortSignal,
): Promise<AnalysisResult> {
  progress(`▶ 意图解析：${query.trim().slice(0, 40)}`)
  const intent = await parseIntent(llm, route, query)

  progress(`▶ 数据采集：${intent.ticker}`)
  const data = await collectMarketData(intent.ticker)
  intent.name = data.quote?.name ?? intent.ticker
  if (data.missing.length > 0) progress(`· 数据缺口（已降级继续）：${data.missing.join('、')}`)

  const header = `${P.roleHeader(data.tradeDate, intent.name, intent.ticker)}${FOCUS_BLOCK(intent)}`
  const analystReportsBlock = (): string => analystReports.map(report => `### ${report.label}\n${report.text}`).join('\n\n')

  // 1. Analysts — parallel, each with its own data slice.
  progress(`▶ 7 位分析师并行研究中（${intent.name} ${intent.ticker}）`)
  const analystReports = await Promise.all(ANALYSTS.map(async analyst => {
    const text = await askLlm(llm, route, {
      system: `${header}\n\n${analyst.system}`,
      user: `以下是你的分析数据：\n\n${analyst.slice(data)}`,
      signal,
    })
    return { role: analyst.role, label: analyst.label, text, verdict: parseVerdict(text) } satisfies RoleReport
  }))
  for (const report of analystReports) {
    progress(`· ${report.label}：${report.verdict?.direction ?? '完成'}——${report.verdict?.reason ?? ''}`.trimEnd())
  }

  // 2. Bull/bear debate — each round sees the other side's latest argument.
  const debateTurns: { round: number; side: 'bull' | 'bear'; text: string }[] = []
  let bullText = ''
  let bearText = ''
  for (let round = 1; round <= DEBATE_ROUNDS; round++) {
    progress(`▶ 多空辩论 第 ${round}/${DEBATE_ROUNDS} 轮`)
    const debateContext = `分析师报告：\n${analystReportsBlock()}`
    const bullRound = askLlm(llm, route, {
      system: `${header}\n\n${P.bullResearcher}`,
      user: `${debateContext}\n\n${round === 1 ? '本轮为首轮：请提出你最核心的多头论点。' : `空头上一轮观点：\n${bearText}\n\n请正面回应并反驳其核心论点，再强化你的多头论证。`}`,
      signal,
    })
    bullText = await bullRound
    debateTurns.push({ round, side: 'bull', text: bullText })
    progress(`· 多头第 ${round} 轮完成（${parseVerdict(bullText)?.direction ?? ''}）`)
    bearText = await askLlm(llm, route, {
      system: `${header}\n\n${P.bearResearcher}`,
      user: `${debateContext}\n\n${round === 1 ? '本轮为首轮：请提出你最核心的空头论点。' : `多头上一轮观点：\n${bullText}\n\n请正面回应并反驳其核心论点，再强化你的空头论证。`}`,
      signal,
    })
    debateTurns.push({ round, side: 'bear', text: bearText })
    progress(`· 空头第 ${round} 轮完成（${parseVerdict(bearText)?.direction ?? ''}）`)
  }

  // 3. Research manager — adjudicate the debate into an executable plan.
  progress('▶ 投研经理裁决')
  const debateBlock = debateTurns.map(turn => `#### ${turn.side === 'bull' ? '多头' : '空头'} · 第 ${turn.round} 轮\n${turn.text}`).join('\n\n')
  const managerReport = await roleCall(llm, route, header, P.researchManager, '投研经理',
    `分析师报告：\n${analystReportsBlock()}\n\n本轮辩论历史：\n${debateBlock}`)
  progress(`· 投研经理：${managerReport.verdict?.direction ?? ''}——${managerReport.verdict?.reason ?? ''}`.trimEnd())

  // 4. Trader's first plan from the manager's program.
  progress('▶ 交易员制定初步方案')
  const marketContext = `标的：${intent.name}（${intent.ticker}），现价 ${data.quote?.price ?? 'N/A'}，今日 ${data.quote?.changePercent ?? 'N/A'}%\n${marketSlice(data)}`
  const userContextText = `用户上下文：${JSON.stringify(intent.userContext) !== '{}' ? JSON.stringify(intent.userContext, null, 1) : '未提供持仓信息，按新建仓处理'}`
  const traderFirst = await askLlm(llm, route, {
    system: `${header}\n\n${P.trader}`,
    user: `请基于分析团队对 ${intent.name} 的综合研究，评估并执行投资方案。\n\n市场上下文：\n${marketContext}\n\n${userContextText}\n\n研究经理方案内容：\n${managerReport.text}`,
    signal,
  })

  // 5. Three-way risk debate over the trader's plan.
  progress('▶ 风控三方辩论')
  const riskContext = (other: string): string => `交易员初步方案：\n${traderFirst}\n\n上下文：\n市场：${marketSlice(data)}\n基本面：${fundamentalsSlice(data)}\n${other}`
  const [aggressiveText, conservativeText] = await Promise.all([
    askLlm(llm, route, { system: `${header}\n\n${P.aggressiveRisk}`, user: riskContext('（本轮为首轮发言）'), signal }),
    askLlm(llm, route, { system: `${header}\n\n${P.conservativeRisk}`, user: riskContext('（本轮为首轮发言）'), signal }),
  ])
  const neutralText = await askLlm(llm, route, {
    system: `${header}\n\n${P.neutralRisk}`,
    user: riskContext(`激进观点：\n${aggressiveText}\n\n保守观点：\n${conservativeText}`),
    signal,
  })
  progress('· 风控三方辩论完成')

  // 6. Risk manager review. Its plan keys (stop/targets) also feed the
  // structured decision record, so prose fallback recovery applies here.
  progress('▶ 风控经理审核')
  const riskManagerReport = await roleCall(llm, route, header, P.riskManager, '风控经理',
    `交易员方案：\n${traderFirst}\n\n市场上下文：\n${marketContext}\n\n${userContextText}\n\n风控辩论历史：\n激进：\n${aggressiveText}\n\n保守：\n${conservativeText}\n\n中性：\n${neutralText}`)
  riskManagerReport.verdict = effectiveVerdict(riskManagerReport.text, riskManagerReport.verdict)
  progress(`· 风控经理：${riskManagerReport.verdict?.direction ?? ''}`)

  // 7. Final trader decision with the risk feedback folded in.
  progress('▶ 交易员最终决策')
  const traderFinalText = await askLlm(llm, route, {
    system: `${header}\n\n${P.trader}`,
    user: `请基于分析团队对 ${intent.name} 的综合研究，评估并执行投资方案。\n\n市场上下文：\n${marketContext}\n\n${userContextText}\n\n上一版交易员方案：\n${traderFirst}\n\n当前风控反馈：\n${riskManagerReport.text}\n\n研究经理方案内容：\n${managerReport.text}`,
    signal,
  })
  const traderFinal: RoleReport = { role: 'trader', label: '交易员', text: traderFinalText, verdict: effectiveVerdict(traderFinalText, parseVerdict(traderFinalText)) }
  progress(`· 交易员：${traderFinal.verdict?.direction ?? ''}——${traderFinal.verdict?.reason ?? ''}`.trimEnd())

  return {
    intent,
    data,
    analystReports,
    debateTurns,
    managerReport,
    traderFirst,
    riskDebate: { aggressive: aggressiveText, conservative: conservativeText, neutral: neutralText },
    riskManagerReport,
    traderFinal,
  }
}

async function roleCall(llm: LlmService, route: Route, header: string, system: string, label: string, user: string, signal?: AbortSignal): Promise<RoleReport> {
  const text = await askLlm(llm, route, { system: `${header}\n\n${system}`, user, signal })
  return { role: label, label, text, verdict: parseVerdict(text) }
}

/** Everything one analysis produced; the report writer consumes this. */
export interface AnalysisResult {
  intent: TradingIntent
  data: MarketData
  analystReports: RoleReport[]
  debateTurns: { round: number; side: 'bull' | 'bear'; text: string }[]
  managerReport: RoleReport
  traderFirst: string
  riskDebate: { aggressive: string; conservative: string; neutral: string }
  riskManagerReport: RoleReport
  traderFinal: RoleReport
}
