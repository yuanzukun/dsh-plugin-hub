/**
 * Natural-language intent parsing for /trading-agent input, ported from the
 * original project's intent_parser: an LLM call produces the structured
 * intent (ticker / focus areas / specific questions / account context), with
 * deterministic fallbacks when the reply is unusable.
 * @module dsh-tradingagents/intent
 */
import { intentParser } from './prompts.ts'
import { askLlm, extractJson, type LlmService } from './llm.ts'
import { isAShareTicker, searchTicker } from './data/eastmoney.ts'

/** Parsed trading intent. */
export interface TradingIntent {
  ticker: string
  name: string
  focusAreas: string[]
  specificQuestions: string[]
  userContext: Record<string, unknown>
  rawQuery: string
}

interface IntentReply {
  ticker?: string | null
  focus_areas?: unknown
  specific_questions?: unknown
  user_context?: unknown
}

/**
 * Parse the command input into a {@link TradingIntent}. The LLM extracts the
 * structured fields (converting company names to A-share codes); this layer
 * owns the deterministic parts: ticker normalization plus a search-API
 * fallback for names the model missed.
 */
export async function parseIntent(llm: LlmService, route: { provider: string; model: string; reasoningEffort?: string }, query: string): Promise<TradingIntent> {
  const trimmed = query.trim()
  let reply: IntentReply | undefined
  try {
    reply = extractJson<IntentReply>(await askLlm(llm, route, {
      system: intentParser,
      user: trimmed,
      temperature: 0,
    }))
  } catch {
    reply = undefined
  }

  const list = (value: unknown): string[] =>
    Array.isArray(value) && value.every(item => typeof item === 'string') ? value as string[] : []

  const userContext = (value: unknown): Record<string, unknown> =>
    typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : {}

  const candidate = typeof reply?.ticker === 'string' ? reply.ticker.replace(/\.(SH|SZ|sh|sz)$/, '') : ''
  let ticker: string | undefined = isAShareTicker(candidate) ? candidate : undefined
  let name = ''
  if (ticker === undefined) {
    // Fallback: treat the whole query's first word(s) as a search keyword.
    const keyword = trimmed.split(/[\s,，]+/)[0] ?? ''
    if (keyword !== '') {
      try {
        ticker = await searchTicker(keyword)
      } catch {
        ticker = undefined
      }
    }
  }
  if (ticker === undefined) {
    throw new Error(`无法从指令中解析出 A 股标的（尝试过的代码/关键词：${candidate || query.trim().slice(0, 20)}）。请直接使用 6 位股票代码，例如 /trading-agent 600519`)
  }

  return {
    ticker,
    name,
    focusAreas: list(reply?.focus_areas),
    specificQuestions: list(reply?.specific_questions),
    userContext: userContext(reply?.user_context),
    rawQuery: trimmed,
  }
}
