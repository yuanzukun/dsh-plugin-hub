import { describe, expect, it, vi, afterEach } from 'vitest'
import { effectiveVerdict, extractJson, parsePlanFromText, parseVerdict, type LlmService } from '../src/llm.ts'
import { parseIntent } from '../src/intent.ts'
import * as eastmoney from '../src/data/eastmoney.ts'

afterEach(() => {
  vi.restoreAllMocks()
})

describe('parseVerdict', () => {
  it('parses a well-formed verdict block', () => {
    const verdict = parseVerdict('结论……\n<!-- VERDICT: {"direction": "偏多", "reason": "主力回流入场"} -->')
    expect(verdict).toEqual({ direction: '偏多', reason: '主力回流入场' })
  })

  it('tolerates whitespace and multiline JSON', () => {
    const verdict = parseVerdict('x\n<!--   VERDICT:  {\n "direction": "看空",\n "reason": "破位"\n}   -->\ny')
    expect(verdict?.direction).toBe('看空')
  })

  it('returns undefined on a missing or malformed block', () => {
    expect(parseVerdict('no block here')).toBeUndefined()
    expect(parseVerdict('<!-- VERDICT: {oops -->')).toBeUndefined()
    expect(parseVerdict('<!-- VERDICT: {"direction": "", "reason": "x"} -->')).toBeUndefined()
  })

  it('parses the optional trade-plan keys and normalizes aliases', () => {
    const verdict = parseVerdict('<!-- VERDICT: {"direction": "偏多", "reason": "回踩低吸", "action": "BUY", "confidence": "65", "entry": "1250-1265", "stop": "1235", "targets": ["1300", 1350], "positionPct": "30%"} -->')
    expect(verdict?.action).toBe('买入')
    expect(verdict?.confidence).toBe(65)
    expect(verdict?.entry).toBe('1250-1265')
    expect(verdict?.stop).toBe('1235')
    expect(verdict?.targets).toEqual(['1300', '1350'])
    expect(verdict?.positionPct).toBe(30)
  })

  it('drops placeholder and out-of-range plan values instead of guessing', () => {
    const verdict = parseVerdict('<!-- VERDICT: {"direction": "中性", "reason": "数据不足", "action": "观望", "confidence": 900, "entry": "—", "stop": "", "targets": []} -->')
    expect(verdict?.action).toBe('观望')
    expect(verdict?.confidence).toBeUndefined()
    expect(verdict?.entry).toBeUndefined()
    expect(verdict?.stop).toBeUndefined()
    expect(verdict?.targets).toBeUndefined()
  })

  it('keeps unknown actions out rather than passing them through', () => {
    const verdict = parseVerdict('<!-- VERDICT: {"direction": "看多", "reason": "x", "action": "加杠杆梭哈"} -->')
    expect(verdict?.action).toBeUndefined()
  })
})

describe('parsePlanFromText', () => {
  it('recovers the trader closing line and the risk-manager price line', () => {
    const plan = parsePlanFromText('方案正文……\n目标价：23.50；止损价：20.48\n最终交易建议：买入')
    expect(plan).toEqual({ action: '买入', stop: '20.48', targets: ['23.50'], fromText: true })
  })

  it('handles multiple targets and SELL/HOLD aliases', () => {
    const plan = parsePlanFromText('止损:12.3 目标价：15、16.5 最终交易建议：SELL')
    expect(plan?.action).toBe('卖出')
    expect(plan?.stop).toBe('12.3')
    expect(plan?.targets).toEqual(['15', '16.5'])
  })

  it('returns undefined when the prose states nothing usable', () => {
    expect(parsePlanFromText('纯正文，没有约束数字')).toBeUndefined()
  })
})

describe('effectiveVerdict', () => {
  it('fills missing plan keys from prose while machine values win', () => {
    const verdict = parseVerdict('正文……目标价：25；止损价：20.5\n<!-- VERDICT: {"direction": "偏多", "reason": "x", "stop": "21"} -->')
    const effective = effectiveVerdict('正文……目标价：25；止损价：20.5', verdict)
    expect(effective?.stop).toBe('21')
    expect(effective?.targets).toEqual(['25'])
    expect(effective?.fromText).toBe(true)
  })

  it('returns the machine verdict untouched when prose has nothing', () => {
    const verdict = parseVerdict('<!-- VERDICT: {"direction": "中性", "reason": "x"} -->')
    expect(effectiveVerdict('正文', verdict)).toBe(verdict)
    expect(effectiveVerdict('正文', undefined)).toBeUndefined()
  })
})

describe('extractJson', () => {
  it('extracts JSON from fenced replies', () => {
    expect(extractJson<{ ticker: string }>('```json\n{"ticker": "600519"}\n```')).toEqual({ ticker: '600519' })
  })

  it('tolerates trailing commas and prose around the object', () => {
    expect(extractJson<{ a: number[] }>('好的，结果是 {"a": [1, 2,]} 请查收')).toEqual({ a: [1, 2] })
  })

  it('returns undefined when no object exists', () => {
    expect(extractJson('纯文本回复')).toBeUndefined()
  })
})

/** Fake llm that replies with canned per-call texts, recording every request. */
class FakeLlm implements LlmService {
  readonly calls: { system: string; user: string }[] = []

  constructor(private readonly replies: string[]) {}

  async resolveCallConfig(): Promise<{ provider: string; model: string }> {
    return { provider: 'test', model: 'fake' }
  }

  async *stream(options: { system?: string; messages: readonly { content: readonly unknown[] }[] }): AsyncIterable<{ type: string; text: string }> {
    const first = options.messages[0]?.content[0] as { text?: string } | undefined
    this.calls.push({ system: options.system ?? '', user: first?.text ?? '' })
    yield { type: 'text-delta', text: this.replies[this.calls.length - 1] ?? '{}' }
  }
}

describe('parseIntent', () => {
  const route = { provider: 'test', model: 'fake' }

  it('uses the model-parsed ticker and fields', async () => {
    const llm = new FakeLlm(['{"ticker": "600519.SH", "focus_areas": ["量价"], "specific_questions": ["能否新高"], "user_context": {"current_position_pct": 80}}'])
    const intent = await parseIntent(llm, route, '调研茅台短线')
    expect(intent.ticker).toBe('600519')
    expect(intent.focusAreas).toEqual(['量价'])
    expect(intent.specificQuestions).toEqual(['能否新高'])
    expect(intent.userContext).toEqual({ current_position_pct: 80 })
  })

  it('falls back to the search API when the model cannot resolve the name', async () => {
    const llm = new FakeLlm(['{"ticker": null}'])
    const spy = vi.spyOn(eastmoney, 'searchTicker').mockResolvedValue('300750')
    const intent = await parseIntent(llm, route, '宁德时代怎么样')
    expect(intent.ticker).toBe('300750')
    expect(spy).toHaveBeenCalled()
  })

  it('throws a teaching error when nothing resolves', async () => {
    const llm = new FakeLlm(['完全无法解析的回复'])
    vi.spyOn(eastmoney, 'searchTicker').mockResolvedValue(undefined)
    await expect(parseIntent(llm, route, '????')).rejects.toThrow(/无法从指令中解析出 A 股标的/)
  })

  it('accepts a bare six-digit code without a wire call when the model fails', async () => {
    const llm = new FakeLlm(['not json at all'])
    const spy = vi.spyOn(eastmoney, 'searchTicker')
    const intent = await parseIntent(llm, route, '002594 关注比亚迪刀片电池')
    expect(intent.ticker).toBe('002594')
    expect(spy).toHaveBeenCalledWith('002594')
  })
})
