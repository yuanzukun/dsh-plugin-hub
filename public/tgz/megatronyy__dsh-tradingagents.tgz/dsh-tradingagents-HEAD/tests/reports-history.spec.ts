import { mkdtemp, mkdir, rm, writeFile, readdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'

/**
 * History-report catalog tests against a scratch directory: index maintenance
 * on save, header fallback parsing for pre-index files, and path-traversal
 * safety on detail reads.
 */

// Point the module's reports directory at a scratch dir via DSH_HOME.
const scratch = await mkdtemp(join(tmpdir(), 'dsh-ta-reports-'))
process.env.DSH_HOME = join(scratch, 'home')
vi.resetModules()
const report = await import('../src/report.ts')

const sampleAnalysis = {
  intent: { ticker: '600519', name: '贵州茅台', focusAreas: [], specificQuestions: [], userContext: {}, rawQuery: '600519' },
  data: { ticker: '600519', tradeDate: '2026-08-21', missing: [] },
  analystReports: [],
  debateTurns: [],
  managerReport: { role: 'm', label: '', text: '', verdict: undefined },
  traderFirst: '',
  riskDebate: { aggressive: '', conservative: '', neutral: '' },
  riskManagerReport: { role: 'm', label: '', text: '', verdict: undefined },
  traderFinal: { role: 'trader', label: '交易员', text: '', verdict: { direction: '偏多', reason: '支撑低吸' } },
} as never

const legacyMarkdown = [
  '# 美的集团（000333）多智能体投研报告',
  '',
  '**最终决策（交易员）**：偏空 —— 破位叠加流出',
  '',
].join('\n')

beforeAll(async () => {
  await mkdir(join(scratch, 'home', 'tradingagents', 'reports'), { recursive: true })
  await writeFile(join(scratch, 'home', 'tradingagents', 'reports', '000333-20260821-legacy00.md'), legacyMarkdown, 'utf8')
})

afterAll(async () => {
  await rm(scratch, { recursive: true, force: true })
})

describe('history catalog', () => {
  it('saveReport writes the file and appends an index entry', async () => {
    const path = await report.saveReport(sampleAnalysis, '# 贵州茅台（600519）多智能体投研报告')
    expect(path.endsWith('.md')).toBe(true)
    const listed = await report.listReports()
    const saved = listed.find(entry => entry.ticker === '600519')
    expect(saved).toBeDefined()
    expect(saved?.direction).toBe('偏多')
    expect(saved?.reason).toBe('支撑低吸')
    expect(saved?.date).toBe('2026-08-21')
  })

  it('folds pre-index legacy files in via header parsing, newest first', async () => {
    await report.saveReport(sampleAnalysis, '# x')
    const listed = await report.listReports()
    const legacy = listed.find(entry => entry.id === '000333-20260821-legacy00')
    expect(legacy).toBeDefined()
    expect(legacy?.name).toBe('美的集团')
    expect(legacy?.ticker).toBe('000333')
    expect(legacy?.direction).toBe('偏空')
    expect(legacy?.reason).toBe('破位叠加流出')
    expect(legacy?.date).toBe('2026-08-21')
    // Newest ids sort ahead of the legacy one.
    expect(listed[0]?.id > legacy!.id).toBe(true)
  })

  it('reads a saved report back by id', async () => {
    const markdown = '# 贵州茅台（600519）多智能体投研报告'
    await report.saveReport(sampleAnalysis, markdown)
    const listed = await report.listReports()
    const newest = listed[0]
    const loaded = await report.readReportMarkdown(newest!.id)
    expect(loaded).toBe(markdown)
  })

  it('refuses traversal and malformed ids', async () => {
    expect(await report.readReportMarkdown('../reports-index')).toBeUndefined()
    expect(await report.readReportMarkdown('..%2Fevil')).toBeUndefined()
    expect(await report.readReportMarkdown('a/b')).toBeUndefined()
    expect(await report.readReportMarkdown('missing-file')).toBeUndefined()
  })

  it('keeps the on-disk catalog to markdown, sidecars, plus the index', async () => {
    const files = await readdir(report.reportsDirectory)
    expect(files.every(file => file.endsWith('.md') || file.endsWith('.decision.json') || file === 'reports-index.json')).toBe(true)
    expect(files).toContain('reports-index.json')
  })

  it('writes a structured-decision sidecar next to each saved report', async () => {
    await report.saveReport(sampleAnalysis, '# 计划边车')
    const listed = await report.listReports()
    const newest = listed[0]
    const decision = await report.readDecision(newest!.id)
    expect(decision).toBeDefined()
    expect(decision?.schemaVersion).toBe(1)
    expect(decision?.id).toBe(newest!.id)
    expect(decision?.ticker).toBe('600519')
    expect(decision?.final.direction).toBe('偏多')
    expect(decision?.plan.sources).toEqual([])
    // Sidecars never surface as separate list rows.
    expect(listed.some(entry => entry.id.includes('decision'))).toBe(false)
  })

  it('reads decisions back with traversal and shape guards', async () => {
    expect(await report.readDecision('../reports-index')).toBeUndefined()
    expect(await report.readDecision('a/b')).toBeUndefined()
    expect(await report.readDecision('000333-20260821-legacy00')).toBeUndefined()
  })
})
