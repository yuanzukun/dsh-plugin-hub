import { describe, expect, it } from 'vitest'
import { atr, boll, closeEma, closeSma, indicatorSnapshot, macd, rsi, vpaTable, vwma, type Bar } from '../src/data/indicators.ts'

/** Deterministic bar series builder: linear closes, fixed OHLC spread, growing volume. */
function makeBars(count: number): Bar[] {
  const bars: Bar[] = []
  for (let i = 0; i < count; i++) {
    const close = 100 + i
    bars.push({
      date: `2026-${String(Math.floor(i / 28) + 1).padStart(2, '0')}-${String((i % 28) + 1).padStart(2, '0')}`,
      open: close - 1,
      close,
      high: close + 2,
      low: close - 2,
      volume: 1000 + i * 10,
    })
  }
  return bars
}

const close = (value: number): string => String(value)
void close

describe('moving averages', () => {
  it('closeSma averages exactly the trailing window', () => {
    const bars = makeBars(60)
    // closes 100..159; the last 50 bars are 110..159
    expect(closeSma(bars, 50)).toBeCloseTo((110 + 159) / 2, 10)
  })

  it('returns undefined when there are fewer bars than the window', () => {
    expect(closeSma(makeBars(49), 50)).toBeUndefined()
    expect(closeEma(makeBars(9), 10)).toBeUndefined()
  })

  it('closeEma weights the latest bars more than a flat sma', () => {
    const bars = makeBars(30)
    const ema = closeEma(bars, 10)
    const sma = closeSma(bars, 10)
    if (ema === undefined || sma === undefined) throw new Error('undefined average')
    // Rising series: EMA sits above the simple mean.
    expect(ema).toBeGreaterThan(sma)
  })
})

describe('rsi and macd', () => {
  it('rsi reaches 100 on a strictly rising series', () => {
    expect(rsi(makeBars(40))).toBe(100)
  })

  it('rsi reaches 0 on a strictly falling series', () => {
    const bars = makeBars(40).map((bar, index) => ({ ...bar, close: 200 - index }))
    expect(rsi(bars)).toBe(0)
  })

  it('macd reports dif, dea, and a positive histogram on a rising series', () => {
    const result = macd(makeBars(60))
    if (result === undefined) throw new Error('undefined macd')
    expect(result.dif).toBeGreaterThan(0)
    expect(result.histogram).toBeGreaterThan(0)
  })

  it('macd needs at least 35 bars', () => {
    expect(macd(makeBars(34))).toBeUndefined()
  })
})

describe('volatility and volume', () => {
  it('boll places the mid between the bands', () => {
    const result = boll(makeBars(40))
    if (result === undefined) throw new Error('undefined boll')
    expect(result.lb).toBeLessThan(result.mid)
    expect(result.mid).toBeLessThan(result.ub)
  })

  it('atr is positive on moving bars and zero-width on flat bars', () => {
    expect(atr(makeBars(40))).toBeGreaterThan(0)
    const flat = Array.from({ length: 30 }, (_, i) => ({ date: `d${i}`, open: 50, close: 50, high: 50, low: 50, volume: 100 }) satisfies Bar)
    expect(atr(flat)).toBe(0)
  })

  it('vwma weights closes by volume', () => {
    const bars: Bar[] = [
      { date: 'd1', open: 1, close: 10, high: 10, low: 10, volume: 1 },
      { date: 'd2', open: 1, close: 20, high: 20, low: 20, volume: 3 },
    ]
    // (10*1 + 20*3) / 4 = 17.5
    expect(vwma(bars, 2)).toBeCloseTo(17.5, 10)
  })
})

describe('snapshot and vpa table', () => {
  it('indicatorSnapshot exposes the exact keys the analyst prompt names', () => {
    const snapshot = indicatorSnapshot(makeBars(220))
    expect(Object.keys(snapshot).sort()).toEqual([
      'atr', 'boll', 'boll_lb', 'boll_ub', 'close_10_ema', 'close_200_sma', 'close_50_sma',
      'macd', 'macdh', 'macds', 'rsi', 'vwma',
    ])
    expect(snapshot.rsi).toBe('100')
    expect(snapshot.close_50_sma).not.toBe('N/A')
    expect(snapshot.close_200_sma).not.toBe('N/A')
  })

  it('marks insufficient history as N/A instead of throwing', () => {
    const snapshot = indicatorSnapshot(makeBars(60))
    expect(snapshot.close_200_sma).toBe('N/A')
    expect(snapshot.close_50_sma).not.toBe('N/A')
  })

  it('vpaTable flags a long-upper-shadow climax bar', () => {
    const bars = makeBars(60)
    bars[59] = { date: '2026-03-01', open: 160, close: 161, high: 200, low: 159, volume: 100000 }
    const table = vpaTable(bars, 5)
    expect(table).toContain('2026-03-01')
    expect(table).toContain('射击十字星/长上影')
  })

  it('vpaTable reports insufficient data gracefully', () => {
    expect(vpaTable(makeBars(10))).toBe('VPA 数据不足')
  })
})
