import { afterEach, describe, expect, it, vi } from 'vitest'
import type { LlmService } from '../src/llm.ts'
import * as collect from '../src/data/collect.ts'
import { runAnalysis } from '../src/pipeline.ts'
import { composeReport } from '../src/report.ts'

afterEach(() => {
  vi.restoreAllMocks()
  vi.resetModules()
})

const route = { provider: 'test', model: 'fake' }

/** Fake llm whose replies are keyed by a role marker in the system prompt. */
class RoleLlm implements LlmService {
  /** Detection order matters: longer markers first so substrings never steal a match. */
  private static readonly ROLE_MARKERS = [
    '交易意图解析器', '市场技术分析师', '新闻与宏观分析师', '社交舆情分析师', '基本面分析师', '宏观与板块分析师', '机构资金分析师', '量价分析师',
    '多头研究员', '空头研究员', '投研经理', '风控委员会审核官', '激进风控', '保守风控', '中性风控', '交易员',
  ]

  private readonly seen: string[] = []

  async resolveCallConfig(): Promise<{ provider: string; model: string }> {
    return { provider: 'test', model: 'fake' }
  }

  async *stream(options: { system?: string; messages: readonly { content: readonly unknown[] }[] }): AsyncIterable<{ type: string; text: string }> {
    const system = options.system ?? ''
    const role = RoleLlm.ROLE_MARKERS.find(marker => system.includes(marker)) ?? 'unknown'
    this.seen.push(role)
    // Decision roles answer with plan data: the trader states action only in
    // prose (exercising fallback recovery) and the risk manager states stop
    // and targets only in prose; everything else uses the bare verdict.
    const text = role === '交易员'
      ? `交易方案正文。\n最终交易建议：买入\n<!-- VERDICT: {"direction": "偏多", "reason": "测试结论", "confidence": 65, "entry": "1250-1265", "positionPct": 30} -->`
      : role === '风控委员会审核官'
        ? `风控审核正文。\n目标价：1350；止损价：1235\n<!-- VERDICT: {"direction": "偏多", "reason": "约束到位"} -->`
        : `【${role}的完整分析正文，含数据引用与结论。】\n<!-- VERDICT: {"direction": "偏多", "reason": "测试结论"} -->`
    yield { type: 'text-delta', text }
  }

  calls(): string[] {
    return [...this.seen]
  }
}

/** Deterministic minimal market data used in place of the live wire. */
function stubMarketData() {
  vi.spyOn(collect, 'collectMarketData').mockResolvedValue({
    ticker: '600519',
    tradeDate: '2026-08-21',
    quote: {
      name: '贵州茅台', ticker: '600519', price: 1272.83, changePercent: -1.45, volume: 33472, amount: 42.78e8,
      turnoverRate: 0.27, volumeRatio: 0.8, high: 1291.5, low: 1272.01, open: 1288, previousClose: 1291.5,
      totalMarketCap: 1.599e12, peTtm: 19.54, mainNetInflow: -5.94e8, mainNetInflowPercent: -13.88,
    },
    bars: Array.from({ length: 60 }, (_, i) => ({
      date: `2026-07-${String(i + 1).padStart(2, '0')}`, open: 1200 + i, close: 1201 + i, high: 1203 + i, low: 1199 + i, volume: 10000 + i * 10,
    })),
    indicators: { close_50_sma: '1275.5', rsi: '55.2', macd: '3.1', macds: '2.8', macdh: '0.6', boll: '1270', boll_ub: '1300', boll_lb: '1240', atr: '18.4', vwma: '1273', close_10_ema: '1280', close_200_sma: 'N/A' },
    vpa: 'VPA 表格占位',
    news: [{ title: '年报发布', content: '营收增长', date: '2026-08-20' }],
    globalNews: [{ title: '美联储动态', content: '利率预期', date: '2026-08-21' }],
    fundFlowHistory: [{ date: '2026-08-21', mainNet: -5.9e8 }],
    boardFlows: [{ name: '白酒', changePercent: -1.2, mainNet: -12e8, mainNetPercent: -5.5 }],
    lhb: [],
    limitUp: { count: 42, leaders: ['某股'] },
    fundamentals: [],
    balanceSheet: [],
    incomeStatement: [],
    cashflow: [],
    missing: ['涨停池（测试）'],
  })
}

describe('runAnalysis', () => {
  it('drives the full 14-role pipeline in order with debate rounds', async () => {
    stubMarketData()
    const llm = new RoleLlm()
    const progress: string[] = []
    const result = await runAnalysis(llm, route, '600519', line => { progress.push(line) })

    // 7 analysts + 4 debate turns + manager + trader-first + 3 risk debaters + risk manager + trader-final
    const calls = llm.calls()
    expect(calls.filter(role => role === '市场技术分析师')).toHaveLength(1)
    expect(calls.filter(role => role === '多头研究员')).toHaveLength(2)
    expect(calls.filter(role => role === '空头研究员')).toHaveLength(2)
    expect(calls.filter(role => role === '投研经理')).toHaveLength(1)
    expect(calls.filter(role => role === '交易员')).toHaveLength(2)
    expect(calls.filter(role => role === '中性风控')).toHaveLength(1)
    expect(calls.filter(role => role === '风控委员会审核官')).toHaveLength(1)
    // The bear's round-2 prompt quotes the bull's round-2 argument (adversarial visibility).
    expect(result.intent.ticker).toBe('600519')
    expect(result.traderFinal.verdict?.direction).toBe('偏多')
    // Plan keys reach the final verdict: trader's machine block plus prose action,
    // risk manager's prose stop/targets recovered by fallback parsing.
    expect(result.traderFinal.verdict?.action).toBe('买入')
    expect(result.traderFinal.verdict?.entry).toBe('1250-1265')
    expect(result.riskManagerReport.verdict?.stop).toBe('1235')
    expect(result.riskManagerReport.verdict?.targets).toEqual(['1350'])
    expect(result.traderFinal.verdict?.fromText).toBe(true)
    expect(progress.some(line => line.includes('多空辩论 第 2/2 轮'))).toBe(true)
    expect(progress.some(line => line.includes('数据缺口'))).toBe(true)
  })
})

describe('composeReport', () => {
  it('assembles the summary table, every section, and strips machine blocks', async () => {
    stubMarketData()
    const llm = new RoleLlm()
    const result = await runAnalysis(llm, route, '600519', () => {})
    const markdown = composeReport(result)

    expect(markdown.startsWith('# 贵州茅台（600519）多智能体投研报告')).toBe(true)
    expect(markdown).toContain('## 一、结论速览')
    expect(markdown).toContain('| 阶段 | 角色 | 方向 | 一句话结论 |')
    expect(markdown).toContain('| 分析 | 市场技术分析师 | 偏多 | 测试结论 |')
    expect(markdown).toContain('## 二、交易员最终决策')
    expect(markdown).toContain('## 三、投研经理裁决')
    expect(markdown).toContain('## 四、风控审核')
    expect(markdown).toContain('### 多头 · 第 1 轮')
    expect(markdown).toContain('### 空头 · 第 2 轮')
    expect(markdown).toContain('### 激进方')
    expect(markdown).toContain('## 七、分析师报告')
    expect(markdown).toContain('数据缺口：涨停池（测试）')
    // The trade-plan summary row surfaces the merged plan (prose-recovered
    // action, machine entry/position, prose stop and target).
    expect(markdown).toContain('**交易计划速览**')
    expect(markdown).toContain('| 买入 | 65% | 1250-1265 | 1235 | 1350 | 30% |')
    // Machine verdict blocks never leak into the human-facing report.
    expect(markdown).not.toContain('<!-- VERDICT')
    expect(markdown).toContain('TradingAgents-AShare')
  })
})

describe('command registration', () => {
  it('registers /trading-agent and handles empty input plus a full run', async () => {
    stubMarketData()
    // Same fresh module graph for the spy and the plugin under test (resetModules
    // clears the registry between tests), so the handler sees the mocked save.
    const reportMod = await import('../src/report.ts')
    const saveSpy = vi.spyOn(reportMod, 'saveReport').mockResolvedValue('test-report.md')
    const registered: { name: string; handler: (invocation: { rawInput: string; signal: AbortSignal }) => Promise<{ kind: string; text?: string }> }[] = []
    const ctx = {
      effect: (callback: () => unknown): void => { const dispose = callback(); void dispose },
      inject: (services: string[], callback: (scoped: unknown) => void): void => {
        if (services.includes('commands')) {
          callback({
            effect: (callback: () => unknown): void => { const dispose = callback(); void dispose },
            commands: {
              register: (definition: (typeof registered)[number]) => {
                registered.push(definition)
                return () => {}
              },
            },
          })
        }
      },
      llm: new RoleLlm(),
    }
    const { apply } = await import('../src/index.ts')
    apply(ctx as never)

    expect(registered).toHaveLength(1)
    expect(registered[0]?.name).toBe('trading-agent')

    const empty = await registered[0]!.handler({ rawInput: '   ', signal: new AbortController().signal })
    expect(empty.kind).toBe('error')
    expect(empty.text).toContain('用法')

    const done = await registered[0]!.handler({ rawInput: '600519', signal: new AbortController().signal })
    expect(done.kind).toBe('success')
    expect(done.text).toContain('多智能体投研报告')
    expect(done.text).toContain('test-report.md')
    expect(saveSpy).toHaveBeenCalled()
  })
})
