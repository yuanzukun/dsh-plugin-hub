import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  exchangeOf, fetchDailyBars, fetchQuote, fetchStockNews, isAShareTicker, searchTicker,
} from '../src/data/eastmoney.ts'


function mockFetch(handler: (url: string) => Promise<{ status?: number; body: string }>): void {
  vi.stubGlobal('fetch', (async (input: unknown) => {
    const url = String(input)
    const reply = await handler(url)
    return new Response(reply.body, { status: reply.status ?? 200, headers: { 'content-type': 'application/json' } })
  }) as typeof fetch)
}

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('ticker addressing', () => {
  it('maps prefixes to exchanges', () => {
    expect(exchangeOf('600519')).toEqual({ tencent: 'sh', eastmoney: '1' })
    expect(exchangeOf('688981')).toEqual({ tencent: 'sh', eastmoney: '1' })
    expect(exchangeOf('002594')).toEqual({ tencent: 'sz', eastmoney: '0' })
    expect(exchangeOf('300750')).toEqual({ tencent: 'sz', eastmoney: '0' })
    expect(exchangeOf('830799')).toBeUndefined()
    expect(exchangeOf('AAPL')).toBeUndefined()
  })

  it('accepts only six-digit A-share codes', () => {
    expect(isAShareTicker('600519')).toBe(true)
    expect(isAShareTicker('600519.SH')).toBe(false)
    expect(isAShareTicker('00700')).toBe(false)
    expect(isAShareTicker('60051')).toBe(false)
  })
})

describe('searchTicker', () => {
  it('passes a valid code through without any wire call', async () => {
    let called = false
    mockFetch(async () => {
      called = true
      return { body: '{}' }
    })
    expect(await searchTicker('  600519 ')).toBe('600519')
    expect(called).toBe(false)
  })

  it('picks the A-share hit matching the market', async () => {
    mockFetch(async () => ({
      body: JSON.stringify({
        QuotationCodeTable: {
          Data: [
            { Code: '016455', Name: '某基金', MktNum: '9', SecurityType: '8' },
            { Code: '600519', Name: '贵州茅台', MktNum: '1', SecurityType: '1' },
          ],
        },
      }),
    }))
    expect(await searchTicker('茅台')).toBe('600519')
  })
})

describe('fetchQuote', () => {
  it('parses the ulist row into the snapshot', async () => {
    mockFetch(async () => ({
      body: JSON.stringify({
        data: { diff: [{ f2: 1272.83, f3: -1.45, f5: 33472, f6: 4278311022, f8: 0.27, f10: 0.8, f12: '600519', f14: '贵州茅台', f15: 1291.5, f16: 1272.01, f17: 1288, f18: 1291.5, f20: 1599041000000, f23: 19.54, f62: -593631536, f184: -13.88 }] },
      }),
    }))
    const quote = await fetchQuote('600519')
    expect(quote.name).toBe('贵州茅台')
    expect(quote.price).toBe(1272.83)
    expect(quote.changePercent).toBe(-1.45)
    expect(quote.mainNetInflow).toBe(-593631536)
    expect(quote.volumeRatio).toBe(0.8)
  })

  it('throws when the host returns no row', async () => {
    mockFetch(async () => ({ body: JSON.stringify({ data: { diff: [] } }) }))
    await expect(fetchQuote('600519')).rejects.toThrow(/no quote/)
  })
})

describe('fetchDailyBars', () => {
  it('parses Tencent qfq rows in order', async () => {
    mockFetch(async () => ({
      body: JSON.stringify({
        code: 0,
        data: { sh600519: { qfqday: [['2026-08-20', '1300', '1310', '1320', '1290', '25000'], ['2026-08-21', '1310', '1272.8', '1315', '1270', '33472']] } },
      }),
    }))
    const bars = await fetchDailyBars('600519')
    expect(bars).toHaveLength(2)
    expect(bars[1]).toEqual({ date: '2026-08-21', open: 1310, close: 1272.8, high: 1315, low: 1270, volume: 33472 })
  })

  it('falls back to the unadjusted day array', async () => {
    mockFetch(async () => ({
      body: JSON.stringify({
        code: 0,
        data: { sz002594: { day: [['2026-08-21', '250', '255', '256', '249', '900000']] } },
      }),
    }))
    const bars = await fetchDailyBars('002594')
    expect(bars[0]?.close).toBe(255)
  })
})

describe('fetchStockNews', () => {
  it('unwraps JSONP, strips highlight tags, and caps content length', async () => {
    const payload = {
      result: {
        cmsArticleWebOld: {
          data: [
            { title: '<em>贵州茅台</em>发布年报', content: 'x'.repeat(400), date: '2026-08-21 09:00:00' },
            { content: 'no title row should be dropped' },
          ],
        },
      },
    }
    mockFetch(async () => ({ body: `cb(${JSON.stringify(payload)})` }))
    const news = await fetchStockNews('600519')
    expect(news).toHaveLength(1)
    expect(news[0]?.title).toBe('贵州茅台发布年报')
    expect(news[0]?.content.length).toBeLessThanOrEqual(200)
  })
})
