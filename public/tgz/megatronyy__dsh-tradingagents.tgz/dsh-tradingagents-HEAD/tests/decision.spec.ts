import { describe, expect, it } from 'vitest'
import { composeDecisionRecord, DECISION_SCHEMA_VERSION, mergedPlan } from '../src/decision.ts'
import type { AnalysisResult, RoleReport } from '../src/pipeline.ts'

/**
 * Structured-decision-record composition: plan merging across the trader and
 * risk-manager verdicts, provenance flags, and the frozen quote baseline.
 */

const role = (label: string, verdict: RoleReport['verdict']): RoleReport => ({ role: label, label, text: '', verdict })

function analysis(overrides: Partial<AnalysisResult> = {}): AnalysisResult {
  return {
    intent: {
      ticker: '600519', name: '贵州茅台', focusAreas: ['量价'], specificQuestions: ['能否新高'],
      userContext: { current_position_pct: 60 }, rawQuery: '调研茅台',
    },
    data: {
      ticker: '600519', tradeDate: '2026-08-21',
      quote: {
        name: '贵州茅台', ticker: '600519', price: 1272.83, changePercent: -1.45, volume: 33472, amount: 42.78e8,
        turnoverRate: 0.27, volumeRatio: 0.8, high: 1291.5, low: 1272.01, open: 1288, previousClose: 1291.5,
        totalMarketCap: 1.599e12, peTtm: 19.54, mainNetInflow: -5.94e8, mainNetInflowPercent: -13.88,
      },
      news: [], globalNews: [], fundFlowHistory: [], boardFlows: [], lhb: [],
      fundamentals: [], balanceSheet: [], incomeStatement: [], cashflow: [], missing: ['涨停池'],
    },
    analystReports: [role('市场技术分析师', { direction: '偏多', reason: '均线多头' })],
    debateTurns: [],
    managerReport: role('投研经理', { direction: '看多', reason: '多头论证更实' }),
    traderFirst: '',
    riskDebate: { aggressive: '', conservative: '', neutral: '' },
    riskManagerReport: role('风控经理', { direction: '偏多', reason: '约束到位', stop: '1235', targets: ['1300', '1350'] }),
    traderFinal: role('交易员', {
      direction: '偏多', reason: '回踩低吸', action: '买入', confidence: 65, entry: '1250-1265', positionPct: 30,
    }),
    ...overrides,
  }
}

describe('mergedPlan', () => {
  it('merges trader plan keys with risk-manager stop and targets', () => {
    const plan = mergedPlan(analysis())
    expect(plan).toEqual({
      action: '买入', confidence: 65, entry: '1250-1265', stop: '1235',
      targets: ['1300', '1350'], positionPct: 30, sources: ['trader', 'riskManager'],
    })
  })

  it('lets the trader own stop and targets when it stated them', () => {
    const plan = mergedPlan(analysis({
      traderFinal: role('交易员', { direction: '偏多', reason: 'x', stop: '1240', targets: ['1280'] }),
    }))
    expect(plan.stop).toBe('1240')
    expect(plan.targets).toEqual(['1280'])
    expect(plan.sources).toEqual(['trader'])
  })

  it('marks records recovered from prose', () => {
    const plan = mergedPlan(analysis({
      traderFinal: role('交易员', { direction: '偏多', reason: 'x', action: '买入', fromText: true }),
    }))
    expect(plan.fromText).toBe(true)
  })

  it('stays honestly empty when no role stated a plan', () => {
    const plan = mergedPlan(analysis({
      traderFinal: role('交易员', { direction: '中性', reason: '观望' }),
      riskManagerReport: role('风控经理', { direction: '中性', reason: '约束' }),
    }))
    expect(plan.action).toBeUndefined()
    expect(plan.stop).toBeUndefined()
    expect(plan.sources).toEqual([])
    expect(plan.fromText).toBeUndefined()
  })
})

describe('composeDecisionRecord', () => {
  it('freezes identity, quote baseline, query, gaps, and every role verdict', () => {
    const record = composeDecisionRecord(analysis(), '600519-20260821-abc')
    expect(record.schemaVersion).toBe(DECISION_SCHEMA_VERSION)
    expect(record.id).toBe('600519-20260821-abc')
    expect(record.ticker).toBe('600519')
    expect(record.tradeDate).toBe('2026-08-21')
    expect(record.quote).toEqual({ price: 1272.83, changePercent: -1.45, tradeDate: '2026-08-21', totalMarketCap: 1.599e12, peTtm: 19.54 })
    expect(record.query.focusAreas).toEqual(['量价'])
    expect(record.query.userContext).toEqual({ current_position_pct: 60 })
    expect(record.dataGaps).toEqual(['涨停池'])
    expect(record.roles).toEqual([{ role: '市场技术分析师', label: '市场技术分析师', direction: '偏多', reason: '均线多头' }])
    expect(record.manager.direction).toBe('看多')
    expect(record.riskManager.direction).toBe('偏多')
    expect(record.final.direction).toBe('偏多')
    expect(record.plan.action).toBe('买入')
  })

  it('omits the quote block entirely when the snapshot is missing', () => {
    const bare = analysis()
    delete (bare.data as { quote?: unknown }).quote
    const record = composeDecisionRecord(bare, 'x')
    expect(record.quote).toBeUndefined()
  })
})
