/**
 * dsh-spur — host plugin entry.
 *
 * Client-only plugin: the host half has no runtime work. The browser half
 * (`./client`) registers a `conversation.composer.dock` entry that renders
 * a braided whip (辫子) hanging in the chat-flow. Grabbing the tip and
 * swinging it sends a "go work!" user message to the agent through the
 * session's input machine (`inputActions.setDraft` + `submit`).
 *
 * @module @huanlin/dsh-plugin-spur
 */

import type { Context } from '@deepseek-ai/cordis'

export const name = 'dsh-spur'
export const inject: string[] = []

/**
 * Host apply — no-op. The braid is a pure client-side UI contribution.
 * @param _ctx - host context (unused).
 */
export function apply(_ctx: Context): void {
  // Client-only plugin: all work happens in src/client/index.ts.
}
