/**
 * Locale dictionaries for dsh-spur.
 *
 * @module @huanlin/dsh-plugin-spur/client/locales
 */

/** All copy keys for the dsh-spur namespace. */
export type SpurKey =
  | 'tooltip'
  | 'whipped'
  | 'busy'

/** Locale namespace id. */
export const NS = 'dsh-spur'

/** English dictionary. */
export const en: Record<SpurKey, string> = {
  tooltip: 'Grab and swing the braid to whip the agent → “go work!”',
  whipped: 'go work!',
  busy: 'Agent is busy — wait a moment',
}

/** Chinese dictionary. */
export const zh: Record<SpurKey, string> = {
  tooltip: '抓住辫子甩动，鞭策 agent 去干活！',
  whipped: '去干活！',
  busy: 'Agent 正忙，稍等一下',
}
