/**
 * Verlet-integration rope physics for the braid.
 *
 * A chain of points connected by distance constraints. Point 0 is pinned
 * (the anchor at the top); the last point is the grabbable tip. Gravity
 * pulls free points downward; damping bleeds velocity over time.
 *
 * Interaction model:
 *   - `setTip(x, y)` — while dragging, pin the tip to the mouse position.
 *     The previous-position fields are set equal to the new position so
 *     the verlet step does not impart spurious velocity from direct
 *     placement.
 *   - `releaseTip(vx, vy)` — on mouse-up, unpin the tip and give it the
 *     last observed mouse velocity by backdating its previous position.
 *   - `update(dt)` — one verlet step + constraint relaxation.
 *
 * Separated from the React component so the physics is unit-testable
 * without a DOM.
 *
 * @module @huanlin/dsh-plugin-spur/client/physics
 */

/** One verlet point: current position + previous-frame position. */
export interface VerletPoint {
  x: number
  y: number
  /** Previous-frame x (verlet velocity = x - px). */
  px: number
  /** Previous-frame y. */
  py: number
  /** Whether this point is fixed (anchor) or free. */
  pinned: boolean
}

/** Tunable rope parameters. */
export interface RopeConfig {
  /** Number of segments (points = segments + 1). */
  segments: number
  /** Rest length of each segment in pixels. */
  segmentLength: number
  /** Gravitational acceleration in px/s². */
  gravity: number
  /** Velocity damping factor per step (0 = full stop, 1 = no damping). */
  damping: number
  /** Distance-constraint relaxation iterations per step. */
  iterations: number
}

/**
 * A verlet rope: a chain of points with distance constraints.
 *
 * Coordinate system: absolute screen pixels (the SVG overlay is
 * `position: fixed; inset: 0`).
 */
export class Rope {
  points: VerletPoint[]
  readonly config: RopeConfig
  private anchorX: number
  private anchorY: number
  /** When non-null, the tip is pinned to this position (drag mode). */
  private tipPin: { x: number; y: number } | null = null

  constructor(anchorX: number, anchorY: number, config: RopeConfig) {
    this.config = config
    this.anchorX = anchorX
    this.anchorY = anchorY
    this.points = []
    for (let i = 0; i <= config.segments; i++) {
      const y = anchorY + i * config.segmentLength
      this.points.push({
        x: anchorX,
        y,
        px: anchorX,
        py: y,
        pinned: i === 0,
      })
    }
  }

  /** Move the anchor (point 0) to a new position, translating all points. */
  setAnchor(x: number, y: number): void {
    const dx = x - this.anchorX
    const dy = y - this.anchorY
    this.anchorX = x
    this.anchorY = y
    for (const p of this.points) {
      p.x += dx
      p.y += dy
      p.px += dx
      p.py += dy
    }
  }

  /**
   * Pin the tip to a screen position (drag mode). While pinned, the verlet
   * step skips the tip and the constraint solver treats it as fixed.
   */
  setTip(x: number, y: number): void {
    this.tipPin = { x, y }
    const tip = this.points[this.points.length - 1]
    if (tip !== undefined) {
      tip.x = x
      tip.y = y
      tip.px = x
      tip.py = y
      tip.pinned = true
    }
  }

  /**
   * Release the tip, imparting the given velocity (px/frame at 60fps).
   * Sets the previous position so the next verlet step carries momentum.
   */
  releaseTip(vxPerFrame: number, vyPerFrame: number): void {
    this.tipPin = null
    const tip = this.points[this.points.length - 1]
    if (tip === undefined) return
    tip.pinned = false
    tip.px = tip.x - vxPerFrame
    tip.py = tip.y - vyPerFrame
  }

  /** Current tip speed in px/frame (verlet velocity magnitude). */
  tipSpeed(): number {
    const tip = this.points[this.points.length - 1]
    if (tip === undefined) return 0
    const vx = tip.x - tip.px
    const vy = tip.y - tip.py
    return Math.sqrt(vx * vx + vy * vy)
  }

  /** Read-only view of the point positions (for rendering). */
  get pathPoints(): readonly { x: number; y: number }[] {
    return this.points
  }

  /**
   * One physics step.
   * @param dt - frame delta in seconds (e.g. 1/60).
   */
  update(dt: number): void {
    const { gravity, damping, iterations, segmentLength } = this.config

    // Verlet integration.
    for (const p of this.points) {
      if (p.pinned) continue
      const vx = (p.x - p.px) * damping
      const vy = (p.y - p.py) * damping
      p.px = p.x
      p.py = p.y
      p.x += vx
      p.y += vy + gravity * dt * dt
    }

    // Constraint relaxation: enforce segment rest lengths.
    for (let iter = 0; iter < iterations; iter++) {
      for (let i = 0; i < this.points.length - 1; i++) {
        const a = this.points[i]!
        const b = this.points[i + 1]!
        const dx = b.x - a.x
        const dy = b.y - a.y
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 0.0001) continue
        const diff = (dist - segmentLength) / dist
        const ax = dx * 0.5 * diff
        const ay = dy * 0.5 * diff
        if (!a.pinned) {
          a.x += ax
          a.y += ay
        }
        if (!b.pinned) {
          b.x -= ax
          b.y -= ay
        }
      }
    }

    // Re-assert the tip pin after constraint relaxation (drag mode keeps
    // the tip locked to the mouse even as constraints pull it).
    if (this.tipPin !== null) {
      const tip = this.points[this.points.length - 1]
      if (tip !== undefined) {
        tip.x = this.tipPin.x
        tip.y = this.tipPin.y
      }
    }
  }
}
