/**
 * dsh-spur — browser half.
 *
 * Single bundle, dual entry: this is the client half (exports `./client`).
 * Host half ships via `.` (see `src/index.ts`).
 *
 * One registration:
 *   - `conversation.composer.dock` list slot (id `dsh-spur`, order 50) —
 *     renders the braided whip. The dock is the band under the composer
 *     card; the braid itself is a `position: fixed` SVG overlay that hangs
 *     into the chat area from a screen-fixed anchor at the top-right.
 *
 * @module @huanlin/dsh-plugin-spur/client
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the shell's SlotMap merge (conversation.composer.dock)
// + SessionStandardProps (useInput, inputActions).
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { Braid } from './Braid.tsx'
import { dicts } from './dictionaries.ts'
import { en, NS, zh, type SpurKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The braid tooltip + whipped flash copy. */
    'dsh-spur': SpurKey
  }
}

/** Required services: slots + locale. */
export const inject = ['slots', 'locale']

/**
 * Client plugin body: register the braid in the composer dock.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-spur: dictionaries')

  ctx.effect(() => {
    let dispose: (() => void) | undefined
    const sync = (): void => {
      dispose?.()
      dispose = undefined
      const store = ctx.get('betterLocale') as
        | { register(ns: string, dicts: Record<string, Record<string, string>>): () => void }
        | undefined
      if (store !== undefined) {
        dispose = store.register(NS, dicts)
      }
    }
    sync()
    const unsubscribe = ctx.locale.subscribe(sync)
    return () => {
      unsubscribe()
      dispose?.()
    }
  }, 'dsh-spur: better-locale override dicts')

  // The braid hangs from a screen-fixed anchor (top-right of the viewport)
  // and is always visible while a session is active (the dock is session-
  // scoped, so hero mode — no session — naturally hides it).
  ctx.slots.inject('conversation.composer.dock', () =>
    ctx.slots.register({
      name: 'conversation.composer.dock',
      id: 'dsh-spur',
      order: 50,
      locale: NS,
    }, Braid),
  )
}
