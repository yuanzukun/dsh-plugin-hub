/**
 * dictionaries.ts — the 19 better-locale override languages for the spur
 * copy, keyed by language id. Each dictionary carries the same key set as
 * `en`/`zh` in `./locales.ts` (enforced by the `Record<SpurKey, string>`
 * annotation), matching the better-locale store's `LocaleDict` contract.
 *
 * The apply function registers these into `ctx.betterLocale` (the override
 * store) under `NS`, so when the user selects an override language through
 * dsh-plugin-better-locale (and DSH is on 'en', whose slot the override
 * borrows), the braid copy renders in the override language.
 *
 * @module @huanlin/dsh-plugin-spur/client/dictionaries
 */

import type { SpurKey } from './locales.ts'

/** All override-language dictionaries for the `NS` namespace. */
export const dicts: Record<string, Record<SpurKey, string>> = {
  ja: {
    tooltip: '編み込みの先端をつかんで振り、エージェントを叱咤しましょう → 「go work!」',
    whipped: 'go work!',
    busy: 'エージェントが作業中です。少々お待ちください',
  },
  de: {
    tooltip: 'Flechte am Ende greifen und schwingen, um den Agenten anzutreiben → „go work!“',
    whipped: 'go work!',
    busy: 'Agent ist beschäftigt — einen Moment warten',
  },
  fr: {
    tooltip: 'Attrapez et balancez la tresse pour stimuler l’agent → « go work! »',
    whipped: 'go work!',
    busy: 'L’agent est occupé — patientez un instant',
  },
  pt: {
    tooltip: 'Pegue na ponta e balance a trança para incitar o agent → «go work!»',
    whipped: 'go work!',
    busy: 'O agent está ocupado — aguarde um momento',
  },
  ko: {
    tooltip: '땋은 머리 끝을 잡고 휘둘러 에이전트를 재촉하세요 → “go work!”',
    whipped: 'go work!',
    busy: '에이전트가 바쁩니다. 잠시 기다려 주세요',
  },
  ar: {
    tooltip: 'أمسك طرف الجديلة وحرّكها لتحفّز الوكيل → «go work!»',
    whipped: 'go work!',
    busy: 'الوكيل مشغول — انتظر قليلاً',
  },
  hi: {
    tooltip: 'चोटी के सिरे को पकड़कर घुमाएँ और एजेंट को काम पर लगाएँ → “go work!”',
    whipped: 'go work!',
    busy: 'एजेंट व्यस्त है — कुछ क्षण प्रतीक्षा करें',
  },
  id: {
    tooltip: 'Pegang ujung jalinan dan ayunkan untuk menyemangati agen → “go work!”',
    whipped: 'go work!',
    busy: 'Agen sedang sibuk — tunggu sebentar',
  },
  tr: {
    tooltip: 'Örgünün ucunu tutup sallayarak ajanı harekete geçirin → “go work!”',
    whipped: 'go work!',
    busy: 'Ajan meşgul — bir dakika bekleyin',
  },
  vi: {
    tooltip: 'Nắm đầu dây tết và vung để thúc giục agent → “go work!”',
    whipped: 'go work!',
    busy: 'Agent đang bận — hãy chờ một chút',
  },
  th: {
    tooltip: 'จับปลายเปียแล้วแกว่งเพื่อกระตุ้นให้ agent ทำงาน → “go work!”',
    whipped: 'go work!',
    busy: 'agent กำลังยุ่ง — โปรดรอสักครู่',
  },
  ru: {
    tooltip: 'Возьмитесь за кончик косы и взмахните, чтобы поторопить агента → «go work!»',
    whipped: 'go work!',
    busy: 'Агент занят — подождите немного',
  },
  it: {
    tooltip: 'Afferra la punta della treccia e agitala per spronare l’agente → «go work!»',
    whipped: 'go work!',
    busy: 'L’agente è occupato — attendi un attimo',
  },
  nl: {
    tooltip: 'Pak het uiteinde van de vlecht vast en zwaai om de agent aan te sporen → “go work!”',
    whipped: 'go work!',
    busy: 'Agent is bezig — wacht even',
  },
  sv: {
    tooltip: 'Ta tag i änden av flätan och svinga för att sporra agenten → “go work!”',
    whipped: 'go work!',
    busy: 'Agenten är upptagen — vänta en stund',
  },
  pl: {
    tooltip: 'Chwyć koniec warkocza i zamachnij się, aby zmotywować agenta → „go work!”',
    whipped: 'go work!',
    busy: 'Agent jest zajęty — poczekaj chwilę',
  },
  'zh-HK': {
    tooltip: '捉住辮子尾用力揮動，鞭策 agent 去開工！',
    whipped: '去開工！',
    busy: 'Agent 而家好忙，請稍等',
  },
  'zh-TW': {
    tooltip: '抓住辮子末端揮動，鞭策 agent 去工作！',
    whipped: '去工作！',
    busy: 'Agent 目前忙碌中，請稍候',
  },
  'zh-MO': {
    tooltip: '抓住辮子尾揮動，鞭策 agent 去做嘢！',
    whipped: '去做嘢！',
    busy: 'Agent 依家好忙，請稍等',
  },
}