/**
 * Braid — the braided whip (辫子) component.
 *
 * Renders a `position: fixed` SVG overlay containing a verlet rope. The
 * rope hangs from a screen-fixed anchor near the top-right of the viewport
 * into the chat area. The tip is a grabbable circle (`pointer-events: auto`
 * on an otherwise `pointer-events: none` overlay).
 *
 * Interaction:
 *   - mousedown on tip → start drag, pin tip to mouse.
 *   - mousemove → tip follows mouse, velocity tracked (exponential moving
 *     average for stability).
 *   - mouseup → release tip with last velocity. If speed exceeds the
 *     threshold, send "go work!" to the agent:
 *       1. Save the current draft (restored after submit completes).
 *       2. `inputActions.setDraft('go work!')`
 *       3. `inputActions.submit()`
 *       4. On phase returning to 'plain', restore the saved draft.
 *
 * The draft save/restore avoids clobbering the user's in-progress text.
 *
 * @module @huanlin/dsh-plugin-spur/client/Braid
 */

import { useCallback, useEffect, useRef, useState } from 'react'
import type { MouseEvent as ReactMouseEvent } from 'react'
import { createPortal } from 'react-dom'
import type { PropsRuntime, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: SlotMap merge for 'conversation.composer.dock' + SessionStandardProps.
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { Rope, type RopeConfig } from './physics.ts'
import css from './Braid.module.css'

/** Full props: dock runtime share (InputZone owner + session kit) + locale seat. */
type BraidProps = PropsRuntime<'conversation.composer.dock'> & PropsLocale<'dsh-spur'>

/** Rope tuning: 10 segments × 16px = 160px hanging length. */
const ROPE_CONFIG: RopeConfig = {
  segments: 10,
  segmentLength: 16,
  gravity: 1400,
  damping: 0.96,
  iterations: 5,
}

/** Mouse speed (px/ms) above which a release counts as a whip. */
const WHIP_SPEED_THRESHOLD = 2.0

/** The message sent to the agent on a successful whip. */
const WHIP_MESSAGE = 'go work!'

/** Screen offset of the anchor from the top-right corner. */
const ANCHOR_OFFSET_RIGHT = 48
const ANCHOR_OFFSET_TOP = 72

/** Frame dt used by the physics step (fixed 60fps assumption). */
const FRAME_DT = 1 / 60

/** Velocity smoothing factor (exponential moving average). */
const VELOCITY_SMOOTHING = 0.4

/** How long the whip-crack flash stays visible (ms). */
const WHIP_FLASH_MS = 800

/**
 * Render the braided whip.
 * @param props - dock runtime share + locale seat.
 * @returns the braid anchor + fixed SVG overlay (ported to document.body).
 */
export function Braid({ input, inputActions, useInput, t }: BraidProps) {
  const pathRef = useRef<SVGPathElement | null>(null)
  const tipRef = useRef<SVGCircleElement | null>(null)
  const ropeRef = useRef<Rope | null>(null)
  const rafRef = useRef<number>(0)
  const draggingRef = useRef(false)
  const mouseRef = useRef({ x: 0, y: 0, lastX: 0, lastY: 0, lastT: 0, vx: 0, vy: 0 })
  const savedDraftRef = useRef<string | null>(null)
  const [restoring, setRestoring] = useState(false)
  const [whipped, setWhipped] = useState(false)
  const [mounted, setMounted] = useState(false)

  const phase = useInput(s => s.phase)

  // Restore saved draft after the submit transaction completes (phase
  // returns to 'plain' after passing through 'adjudicating' → 'submitting').
  useEffect(() => {
    if (!restoring || phase !== 'plain') return
    const saved = savedDraftRef.current
    if (saved !== null) {
      inputActions.setDraft(saved)
      savedDraftRef.current = null
    }
    setRestoring(false)
  }, [restoring, phase, inputActions])

  // Portal target (document.body) — set after mount to avoid SSR issues.
  useEffect(() => {
    setMounted(true)
  }, [])

  /** Compute the screen-fixed anchor position (top-right of viewport). */
  const getAnchorPos = useCallback((): { x: number; y: number } => {
    if (typeof window === 'undefined') return { x: 0, y: 0 }
    return {
      x: window.innerWidth - ANCHOR_OFFSET_RIGHT,
      y: ANCHOR_OFFSET_TOP,
    }
  }, [])

  // Initialize / reposition the rope when the anchor moves (viewport resize).
  useEffect(() => {
    const init = (): void => {
      const pos = getAnchorPos()
      if (ropeRef.current === null) {
        ropeRef.current = new Rope(pos.x, pos.y, ROPE_CONFIG)
      } else {
        ropeRef.current.setAnchor(pos.x, pos.y)
      }
    }
    init()
    const onResize = (): void => init()
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
    }
  }, [getAnchorPos])

  // Animation loop: physics step + direct DOM updates (no React re-render).
  useEffect(() => {
    const tick = (): void => {
      const rope = ropeRef.current
      const path = pathRef.current
      const tip = tipRef.current
      if (rope !== null && path !== null) {
        rope.update(FRAME_DT)
        const pts = rope.pathPoints
        if (pts.length > 0) {
          // Build the braid stroke path through all points.
          let d = `M ${pts[0]!.x.toFixed(1)} ${pts[0]!.y.toFixed(1)}`
          for (let i = 1; i < pts.length; i++) {
            d += ` L ${pts[i]!.x.toFixed(1)} ${pts[i]!.y.toFixed(1)}`
          }
          path.setAttribute('d', d)

          // Position the grabbable tip circle at the last point.
          const tipPt = pts[pts.length - 1]!
          if (tip !== null) {
            tip.setAttribute('cx', tipPt.x.toFixed(1))
            tip.setAttribute('cy', tipPt.y.toFixed(1))
          }
        }
      }
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(rafRef.current)
    }
  }, [])

  // Global mouse handlers during drag.
  useEffect(() => {
    const onMouseMove = (e: MouseEvent): void => {
      if (!draggingRef.current) return
      const now = performance.now()
      const dt = now - mouseRef.current.lastT
      if (dt > 0) {
        const instVx = (e.clientX - mouseRef.current.lastX) / dt
        const instVy = (e.clientY - mouseRef.current.lastY) / dt
        // Exponential moving average for a stable velocity reading.
        mouseRef.current.vx = mouseRef.current.vx * (1 - VELOCITY_SMOOTHING) + instVx * VELOCITY_SMOOTHING
        mouseRef.current.vy = mouseRef.current.vy * (1 - VELOCITY_SMOOTHING) + instVy * VELOCITY_SMOOTHING
      }
      mouseRef.current.lastX = e.clientX
      mouseRef.current.lastY = e.clientY
      mouseRef.current.lastT = now
      mouseRef.current.x = e.clientX
      mouseRef.current.y = e.clientY

      const rope = ropeRef.current
      if (rope !== null) {
        rope.setTip(e.clientX, e.clientY)
      }
    }

    const onMouseUp = (): void => {
      if (!draggingRef.current) return
      draggingRef.current = false

      const speed = Math.hypot(mouseRef.current.vx, mouseRef.current.vy)
      const rope = ropeRef.current
      if (rope !== null) {
        // Release with the last frame's velocity (px/frame ≈ px/ms * 16).
        rope.releaseTip(mouseRef.current.vx * 16, mouseRef.current.vy * 16)
      }

      if (speed > WHIP_SPEED_THRESHOLD) {
        // Whip! Send "go work!" to the agent.
        if (phase === 'plain') {
          savedDraftRef.current = input.draft
          inputActions.setDraft(WHIP_MESSAGE)
          inputActions.submit()
          setRestoring(true)
        }
        setWhipped(true)
        window.setTimeout(() => setWhipped(false), WHIP_FLASH_MS)
      }
    }

    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('mouseup', onMouseUp)
    return () => {
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('mouseup', onMouseUp)
    }
  }, [phase, input, inputActions])

  const onTipMouseDown = useCallback((e: ReactMouseEvent): void => {
    e.preventDefault()
    e.stopPropagation()
    draggingRef.current = true
    mouseRef.current.x = mouseRef.current.lastX = e.clientX
    mouseRef.current.y = mouseRef.current.lastY = e.clientY
    mouseRef.current.lastT = performance.now()
    mouseRef.current.vx = 0
    mouseRef.current.vy = 0

    const rope = ropeRef.current
    if (rope !== null) {
      rope.setTip(e.clientX, e.clientY)
    }
  }, [])

  // The anchor div is a zero-size lifecycle placeholder inside the dock.
  // The visible braid is the fixed SVG overlay (ported to document.body to
  // escape any ancestor transform/overflow clipping).
  return (
    <div className={css.anchor} aria-hidden>
      {mounted && createPortal(
        <svg
          className={css.overlay}
          data-whipped={whipped || undefined}
          aria-hidden
        >
          {/* The braid cord: a thick tapered stroke. */}
          <path
            ref={pathRef}
            className={css.braid}
            d=""
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* The grabbable tip. */}
          <circle
            ref={tipRef}
            className={css.tip}
            r="11"
            cx={0}
            cy={0}
            onMouseDown={onTipMouseDown}
          >
            <title>{t('tooltip')}</title>
          </circle>
        </svg>,
        document.body,
      )}
    </div>
  )
}
