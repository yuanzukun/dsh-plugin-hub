/**
 * Unit tests for the verlet rope physics.
 *
 * @module @huanlin/dsh-plugin-spur/tests/physics.spec
 */
import { describe, expect, it } from 'vitest'
import { Rope, type RopeConfig } from '../src/client/physics.ts'

const TEST_CONFIG: RopeConfig = {
  segments: 5,
  segmentLength: 10,
  gravity: 1000,
  damping: 0.98,
  iterations: 4,
}

describe('Rope', () => {
  it('initializes all points at the anchor, hanging straight down', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    const pts = rope.pathPoints
    expect(pts).toHaveLength(6) // segments + 1
    expect(pts[0]).toMatchObject({ x: 100, y: 50, pinned: true })
    expect(pts[5]).toMatchObject({ x: 100, y: 100, pinned: false })
  })

  it('point 0 stays pinned after update', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    rope.update(1 / 60)
    const pts = rope.pathPoints
    expect(pts[0]!.x).toBe(100)
    expect(pts[0]!.y).toBe(50)
  })

  it('gravity pulls free points downward', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    const tipBefore = rope.pathPoints[5]!
    rope.update(1 / 60)
    rope.update(1 / 60)
    rope.update(1 / 60)
    const tipAfter = rope.pathPoints[5]!
    // The tip should have moved downward (gravity) subject to constraints.
    // With 5 segments of length 10, max y is 50 + 50 = 100. Gravity pulls
    // past that, constraints pull back. Net: tip y increases initially.
    expect(tipAfter.y).toBeGreaterThanOrEqual(tipBefore.y)
  })

  it('setTip pins the tip to the given position', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    rope.setTip(200, 300)
    rope.update(1 / 60)
    const tip = rope.pathPoints[5]!
    expect(tip.x).toBe(200)
    expect(tip.y).toBe(300)
  })

  it('releaseTip imparts velocity to the tip', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    rope.setTip(100, 100) // pin first
    rope.releaseTip(10, 0) // release with rightward velocity
    const speed = rope.tipSpeed()
    expect(speed).toBeCloseTo(10, 1) // sqrt(10^2 + 0^2) = 10
  })

  it('tipSpeed is zero for a freshly initialized rope', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    expect(rope.tipSpeed()).toBe(0)
  })

  it('setAnchor translates all points by the delta', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    const before = rope.pathPoints.map(p => ({ x: p.x, y: p.y }))
    rope.setAnchor(120, 60)
    const after = rope.pathPoints
    for (let i = 0; i < before.length; i++) {
      expect(after[i]!.x).toBe(before[i]!.x + 20)
      expect(after[i]!.y).toBe(before[i]!.y + 10)
    }
  })

  it('constraints maintain approximate segment lengths after update', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    // Perturb the tip to create tension.
    rope.setTip(150, 200)
    rope.update(1 / 60)
    rope.update(1 / 60)
    // Release and let constraints settle.
    rope.releaseTip(0, 0)
    for (let i = 0; i < 20; i++) rope.update(1 / 60)

    const pts = rope.pathPoints
    for (let i = 0; i < pts.length - 1; i++) {
      const dx = pts[i + 1]!.x - pts[i]!.x
      const dy = pts[i + 1]!.y - pts[i]!.y
      const dist = Math.sqrt(dx * dx + dy * dy)
      // After relaxation, segment length should be close to rest length (10).
      expect(dist).toBeCloseTo(10, 0)
    }
  })

  it('damping reduces tip velocity over time', () => {
    const rope = new Rope(100, 50, TEST_CONFIG)
    rope.setTip(100, 100)
    rope.releaseTip(20, 0)
    const speed0 = rope.tipSpeed()

    // Run several steps; gravity will add some y-velocity, but x-velocity
    // (which started at 20) should decrease due to damping.
    for (let i = 0; i < 10; i++) rope.update(1 / 60)

    // The tip's x-velocity component should have decreased.
    const tip = rope.pathPoints[5]!
    const vx = tip.x - tip.px
    expect(Math.abs(vx)).toBeLessThan(20)
    expect(speed0).toBeGreaterThan(0)
  })

  it('handles zero-length rope (single point)', () => {
    const config: RopeConfig = { ...TEST_CONFIG, segments: 0 }
    const rope = new Rope(100, 50, config)
    expect(rope.pathPoints).toHaveLength(1)
    expect(rope.pathPoints[0]!.pinned).toBe(true)
    rope.update(1 / 60) // should not throw
  })
})
