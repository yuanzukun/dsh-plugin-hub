/**
 * Locale dictionaries for dsh-spur.
 *
 * @module @huanlin/dsh-plugin-spur/client/locales
 */
/** All copy keys for the dsh-spur namespace. */
export type SpurKey = 'tooltip' | 'whipped' | 'busy';
/** Locale namespace id. */
export declare const NS = "dsh-spur";
/** English dictionary. */
export declare const en: Record<SpurKey, string>;
/** Chinese dictionary. */
export declare const zh: Record<SpurKey, string>;
