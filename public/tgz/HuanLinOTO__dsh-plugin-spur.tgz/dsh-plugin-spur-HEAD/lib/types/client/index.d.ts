/**
 * dsh-spur — browser half.
 *
 * Single bundle, dual entry: this is the client half (exports `./client`).
 * Host half ships via `.` (see `src/index.ts`).
 *
 * One registration:
 *   - `conversation.composer.dock` list slot (id `dsh-spur`, order 50) —
 *     renders the braided whip. The dock is the band under the composer
 *     card; the braid itself is a `position: fixed` SVG overlay that hangs
 *     into the chat area from a screen-fixed anchor at the top-right.
 *
 * @module @huanlin/dsh-plugin-spur/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type SpurKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The braid tooltip + whipped flash copy. */
        'dsh-spur': SpurKey;
    }
}
/** Required services: slots + locale. */
export declare const inject: string[];
/**
 * Client plugin body: register the braid in the composer dock.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
