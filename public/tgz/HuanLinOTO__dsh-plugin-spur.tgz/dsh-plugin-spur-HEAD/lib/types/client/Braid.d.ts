/**
 * Braid — the braided whip (辫子) component.
 *
 * Renders a `position: fixed` SVG overlay containing a verlet rope. The
 * rope hangs from a screen-fixed anchor near the top-right of the viewport
 * into the chat area. The tip is a grabbable circle (`pointer-events: auto`
 * on an otherwise `pointer-events: none` overlay).
 *
 * Interaction:
 *   - mousedown on tip → start drag, pin tip to mouse.
 *   - mousemove → tip follows mouse, velocity tracked (exponential moving
 *     average for stability).
 *   - mouseup → release tip with last velocity. If speed exceeds the
 *     threshold, send "go work!" to the agent:
 *       1. Save the current draft (restored after submit completes).
 *       2. `inputActions.setDraft('go work!')`
 *       3. `inputActions.submit()`
 *       4. On phase returning to 'plain', restore the saved draft.
 *
 * The draft save/restore avoids clobbering the user's in-progress text.
 *
 * @module @huanlin/dsh-plugin-spur/client/Braid
 */
import type { PropsRuntime, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** Full props: dock runtime share (InputZone owner + session kit) + locale seat. */
type BraidProps = PropsRuntime<'conversation.composer.dock'> & PropsLocale<'dsh-spur'>;
/**
 * Render the braided whip.
 * @param props - dock runtime share + locale seat.
 * @returns the braid anchor + fixed SVG overlay (ported to document.body).
 */
export declare function Braid({ input, inputActions, useInput, t }: BraidProps): import("react").JSX.Element;
export {};
