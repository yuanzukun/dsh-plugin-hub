/**
 * Verlet-integration rope physics for the braid.
 *
 * A chain of points connected by distance constraints. Point 0 is pinned
 * (the anchor at the top); the last point is the grabbable tip. Gravity
 * pulls free points downward; damping bleeds velocity over time.
 *
 * Interaction model:
 *   - `setTip(x, y)` — while dragging, pin the tip to the mouse position.
 *     The previous-position fields are set equal to the new position so
 *     the verlet step does not impart spurious velocity from direct
 *     placement.
 *   - `releaseTip(vx, vy)` — on mouse-up, unpin the tip and give it the
 *     last observed mouse velocity by backdating its previous position.
 *   - `update(dt)` — one verlet step + constraint relaxation.
 *
 * Separated from the React component so the physics is unit-testable
 * without a DOM.
 *
 * @module @huanlin/dsh-plugin-spur/client/physics
 */
/** One verlet point: current position + previous-frame position. */
export interface VerletPoint {
    x: number;
    y: number;
    /** Previous-frame x (verlet velocity = x - px). */
    px: number;
    /** Previous-frame y. */
    py: number;
    /** Whether this point is fixed (anchor) or free. */
    pinned: boolean;
}
/** Tunable rope parameters. */
export interface RopeConfig {
    /** Number of segments (points = segments + 1). */
    segments: number;
    /** Rest length of each segment in pixels. */
    segmentLength: number;
    /** Gravitational acceleration in px/s². */
    gravity: number;
    /** Velocity damping factor per step (0 = full stop, 1 = no damping). */
    damping: number;
    /** Distance-constraint relaxation iterations per step. */
    iterations: number;
}
/**
 * A verlet rope: a chain of points with distance constraints.
 *
 * Coordinate system: absolute screen pixels (the SVG overlay is
 * `position: fixed; inset: 0`).
 */
export declare class Rope {
    points: VerletPoint[];
    readonly config: RopeConfig;
    private anchorX;
    private anchorY;
    /** When non-null, the tip is pinned to this position (drag mode). */
    private tipPin;
    constructor(anchorX: number, anchorY: number, config: RopeConfig);
    /** Move the anchor (point 0) to a new position, translating all points. */
    setAnchor(x: number, y: number): void;
    /**
     * Pin the tip to a screen position (drag mode). While pinned, the verlet
     * step skips the tip and the constraint solver treats it as fixed.
     */
    setTip(x: number, y: number): void;
    /**
     * Release the tip, imparting the given velocity (px/frame at 60fps).
     * Sets the previous position so the next verlet step carries momentum.
     */
    releaseTip(vxPerFrame: number, vyPerFrame: number): void;
    /** Current tip speed in px/frame (verlet velocity magnitude). */
    tipSpeed(): number;
    /** Read-only view of the point positions (for rendering). */
    get pathPoints(): readonly {
        x: number;
        y: number;
    }[];
    /**
     * One physics step.
     * @param dt - frame delta in seconds (e.g. 1/60).
     */
    update(dt: number): void;
}
