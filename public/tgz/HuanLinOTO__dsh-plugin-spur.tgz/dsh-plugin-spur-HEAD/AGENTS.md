# dsh-spur — Agent Guide

## Plugin overview

Bundle-style DSH plugin that renders a braided whip (辫子) in the chat-flow. The user grabs the tip and swings it; a fast enough swing sends a `go work!` user message to the agent.

## Key conventions

- **Bundle form**: `cordis.patch.yml` inserts one plugin row; `package.json` has `dsh.bundle.patch`. No source patches to DSH staging.
- **Client-only**: the host half (`src/index.ts`) has an empty `apply`. All work is in the browser half (`src/client/`).
- **Single slot registration**: `conversation.composer.dock` (list, session scope, id `dsh-spur`, order 50). The dock is the band under the composer card; the braid is a `position: fixed` SVG overlay ported to `document.body`.
- **Peer deps**: cordis + react + react-dom + `@deepseek-ai/dsh-client-*` (provided by host). Zero runtime npm deps.
- **Physics**: verlet-integration rope (`src/client/physics.ts`), separated from the React component for unit testability.

## File responsibilities

| File | Role |
|------|------|
| `src/index.ts` | Host entry: `name`, empty `apply` (client-only plugin) |
| `src/invariant.ts` | `./invariant` companion (empty installer: slot registration is HMR-proven) |
| `src/client/index.ts` | Client entry: `inject = ['slots', 'locale']`, registers `conversation.composer.dock` entry + locale namespace |
| `src/client/Braid.tsx` | The braid component: verlet rope SVG overlay + drag interaction + message sending |
| `src/client/physics.ts` | `Rope` class: verlet integration + distance constraints (`setTip` / `releaseTip` / `update`) |
| `src/client/locales.ts` | English + Chinese dictionaries for the `dsh-spur` namespace |
| `tests/physics.spec.ts` | Unit tests for the `Rope` class |

## Commands

```sh
pnpm run typecheck    # tsc --noEmit (resolves DSH src through ../dsh)
pnpm test             # vitest run (physics unit tests)
pnpm run build        # tsc + tsdown → lib/index.js, lib/invariant.js, lib/client.js
```

## How the message is sent

The braid uses the session's input machine — the same path the InputBar uses:

1. Read current draft from `input.draft` (owner prop from `InputZone`).
2. Check `input.phase === 'plain'` (don't whip while the machine is busy).
3. Save the draft to a ref.
4. `inputActions.setDraft('go work!')`
5. `inputActions.submit()`
6. Watch `useInput(s => s.phase)`; when it returns to `'plain'`, restore the saved draft via `inputActions.setDraft(saved)`.

## Gotchas

- The SVG overlay is ported to `document.body` via `createPortal` to escape any ancestor `transform` / `overflow: hidden` that would create a containing block for `position: fixed`.
- The anchor position is screen-fixed (top-right of viewport, offset 48px right / 72px top). It does not track the composer's position on scroll — `position: fixed` keeps it in place.
- The tip's `pointer-events: auto` is the only grabbable surface; the rest of the overlay is `pointer-events: none` (click-through).
- Velocity is smoothed with an exponential moving average (factor 0.4) to avoid spurious threshold crossings from single-frame jitter.
- The whip speed threshold is 2.0 px/ms. Adjust `WHIP_SPEED_THRESHOLD` in `Braid.tsx` to tune sensitivity.
