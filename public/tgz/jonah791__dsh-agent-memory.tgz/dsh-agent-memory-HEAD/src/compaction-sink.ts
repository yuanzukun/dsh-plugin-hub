/**
 * 压缩即记忆（DESIGN.md 通道 C：compaction 联动）
 *
 * 订阅会话事件流（session/event firehose），把每次成功的会话压缩 checkpoint
 * 保底存档为 L3 情景记忆（episodic）——**智能体核心联动（2026-08-15 主人定调）**：
 * - compaction/start   → 记录事务（按 compactionId）
 * - compaction/summary → 记录摘要文本
 * - compaction/end（无 error）→ 原文保底落库（scope = 会话 cwd 的 workspace）
 *   + **inbox 通知（wakeup=true 自动送达）**：压缩完成即唤醒送达，把决策权交给
 *   爱丽丝——提炼与否/如何组织/记忆库健康，由爱丽丝自主决定（理由记入 source.reason）
 * - **不再写哨兵/不再重启**：压缩在进程内已完整，零打断当前思维（忙时排队等
 *   当前 turn 结束，空闲立即处理）；压缩时 agent 必醒着（活跃期决策发起），
 *   不存在睡眠被打断的场景（2026-08-16 主人定调：完成即送达，不等主人下一条消息）
 * 失败（end 带 error）不落库不通知。
 *
 * ⚠ **「落库失败」不是静默，也不再能「下次再试」**（2026-11-12 修正，台账 lh-2659bafb）：
 * 旧注释写「落库失败静默（幂等，下次压缩再试）」——**半句是假的**：
 * `compaction/end` 处理时 pending 记录在 L131 就已删除，而下一次压缩是新 `compactionId`
 * ⇒ 这一条 checkpoint 的原文**永不重试**。于是「提交了但没入档」变成不可发现的事故
 * （既不落库、也不落日志、也不通知）。现改为：失败**落侧车 JSONL**
 * （`memory-compaction-sink-failures.jsonl`：compactionId + 错误 + 时间 + scope），
 * 工具面不阻塞、不影响会话，但事后可查、可数。
 *
 * **v0.11.0 存档粒度修正（2026-09-26 实测）**：标题此前带精确时刻 ⇒ 每次压缩都躲过
 * `store.remember` 的 title 指纹查重（store.ts L167：knowledge/episodic 同标题自动合并），
 * 8.5 小时内落下 6 条内容层层包含的平行快照。现改为**日粒度合并键**，同日多次压缩
 * 自动并入一条；精确时刻移入正文抬头，合并后仍能分清哪段是哪次。
 */

import type { Context } from '@deepseek-ai/cordis'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { MemoryStore } from './store.ts'
import { COLD_CHECKPOINT_TAG } from './store.ts'
import { workspaceIdOf } from './scope.ts'
import { appendJsonl } from './access-trace.ts'

declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'dsh-agent-memory': { kind: 'dsh-agent-memory' }
  }
}

/** 单个压缩事务的跟踪记录 */
interface CompactionRecord {
  summary?: string
}

/** 落库依赖 */
export interface CompactionSinkDeps {
  store: MemoryStore
  /**
   * 落库失败侧车路径（JSONL）。缺省 = 不落盘（测试/嵌入式场景），
   * 但**生产装配必须给**——否则「提交了但没入档」又变回不可发现。
   */
  failureTracePath?: string
  /** 侧车轮转阈值（字节；≤0 = 不轮转，缺省不轮转）。 */
  failureTraceMaxBytes?: number
}

/** 一条「保底存档失败」记录（侧车落盘形状；字段即事后排查所需全部信息）。 */
export interface CompactionSinkFailure {
  /** 落盘时刻（ms）——**由写入方注入**，纯函数不取时钟。 */
  atMs: number
  /** 压缩事务 id（对应会话事件里的 compactionId；主机排查的第一把钥匙）。 */
  compactionId: string
  sessionId: string
  scope: string
  /** 错误文本（`Error.message` 或 `String(err)`；不落堆栈，避免侧车无限膨胀）。 */
  error: string
}

/**
 * 把 `catch` 到的未知错误规整成一行文本（纯函数）。
 *
 * 为什么不落 `err.stack`：侧车要能被反复 grep 与计数，堆栈里全是路径与噪声；
 * 真正需要的两个问题是「哪次压缩」与「为什么」——前者是 compactionId，后者是 message。
 * 异常值不是 Error（字符串 / 对象 / undefined 都可能）时按 `String()` 兜，绝不抛。
 * @param err - catch 到的任意值
 * @returns 非空文本（永不返回空串，否则侧车读数含糊）
 */
export function describeSinkError(err: unknown): string {
  if (err instanceof Error) {
    const msg = err.message.trim()
    return msg.length > 0 ? msg : err.name
  }
  if (typeof err === 'string') return err.trim().length > 0 ? err : '(空字符串错误)'
  try {
    return String(err)
  } catch {
    return '(错误值不可字符串化)'
  }
}

/**
 * 把「本地相对 UTC 的偏移分钟数」渲染为显式时区标注。
 * @param offsetMinutes - 东正西负（如 UTC+8 → `480`，UTC-5 → `-300`，UTC+5:30 → `330`）
 * @returns 形如 `UTC+08:00` / `UTC-05:00` / `UTC+05:30` 的标注
 */
export function utcOffsetLabel(offsetMinutes: number): string {
  const p2 = (n: number) => String(n).padStart(2, '0')
  const sign = offsetMinutes < 0 ? '-' : '+'
  const abs = Math.abs(offsetMinutes)
  return `UTC${sign}${p2(Math.floor(abs / 60))}:${p2(abs % 60)}`
}

/**
 * 把时刻渲染为「本地时间 + 显式时区」的标题片段。
 *
 * 不用 `toISOString()`：它恒为 UTC 却长得像本地时间——读者会把「09-22 05:35 发生的压缩」
 * 读成「09-21 21:35」（2026-09-22 实测，我自己被误导过一次）。判据（AGENTS.md §5.9 规则 6）：
 * 读数必须自带范围标注 ⇒ 时间必须带时区，否则是虚数。
 * @param d - 目标时刻
 * @returns 形如 `2026-09-22 05:35 UTC+08:00`（分钟精度；秒及以下截断）
 */
export function formatLocalStamp(d: Date): string {
  const p2 = (n: number) => String(n).padStart(2, '0')
  const ymd = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`
  const hm = `${p2(d.getHours())}:${p2(d.getMinutes())}`
  return `${ymd} ${hm} ${utcOffsetLabel(-d.getTimezoneOffset())}`
}

/**
 * 把时刻渲染为**日粒度**（本地日 + 显式时区），用作 checkpoint 存档的**合并键**。
 *
 * 为什么需要它（2026-09-26 实测）：`store.remember` 对 episodic 走 title 指纹查重
 * （store.ts L167），标题带精确时刻 ⇒ 每次压缩都算「新标题」⇒ 8.5 小时落 6 条平行快照，
 * 内容层层包含。日粒度让同日多次压缩落到同一条（标签并集 + 正文追加）。
 *
 * 时区必须显式（§5.9 规则 6）：**日界随时区而变**——不标时区的「2026-09-26」是虚数。
 * @param d - 目标时刻
 * @returns 形如 `2026-09-26 UTC+08:00`
 */
export function dayStampOf(d: Date): string {
  const p2 = (n: number) => String(n).padStart(2, '0')
  const ymd = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`
  return `${ymd} ${utcOffsetLabel(-d.getTimezoneOffset())}`
}

/**
 * 安装压缩即记忆联动。
 * @param ctx - 插件上下文（session/event firehose）
 * @param deps - 存储依赖
 */
export function installCompactionSink(ctx: Context, deps: CompactionSinkDeps): void {
  // sessionId → compactionId → 记录
  const pending = new Map<string, Map<string, CompactionRecord>>()

  ctx.on('session/event', (session, event) => {
    // compaction/* 是 compaction 插件的扩展事件类型（官方 SessionEventMap 不含），
    // 运行时确有这些字段（实测会话日志）；此处收窄类型避免声明合并依赖。
    const ev = event as unknown as {
      type: string
      data: {
        compactionId: string
        error?: unknown
        summary?: unknown
      }
    }
    if (ev.type === 'compaction/start') {
      let byId = pending.get(session.id)
      if (byId === undefined) {
        byId = new Map()
        pending.set(session.id, byId)
      }
      byId.set(ev.data.compactionId, {})
      return
    }
    if (ev.type === 'compaction/summary') {
      const rec = pending.get(session.id)?.get(ev.data.compactionId)
      if (rec === undefined) return
      const summary = ev.data.summary
      rec.summary = Array.isArray(summary)
        ? summary.map((block) => (block?.type === 'text' ? block.text : '')).filter((t) => t.length > 0).join('\n')
        : undefined
      return
    }
    if (ev.type !== 'compaction/end') return
    const byId = pending.get(session.id)
    const rec = byId?.get(ev.data.compactionId)
    if (rec === undefined) return
    byId?.delete(ev.data.compactionId)
    if (ev.data.error !== undefined) return // 失败不落库
    const text = rec.summary
    if (text === undefined || text.trim().length === 0) return
    const cwd = session.header?.cwd
    const scope = cwd === undefined ? 'global' : workspaceIdOf(cwd)
    const now = new Date()
    // 标题 = 日粒度合并键（同日多次压缩并入一条）；精确时刻进正文抬头（见文件头 v0.11.0 说明）
    const title = `会话压缩检查点 · ${dayStampOf(now)}`
    // 保底存档（fire-and-forget：不阻塞会话事件流）
    const notify = (entryId: string) => {
      // 智能体核心（2026-08-16 主人定调：压缩完成自动送达）：wakeup=true——
      // 空闲立即唤醒处理；忙则当前思维结束后处理（压缩时 agent 必醒着，无睡眠打断）；
      // 决策（提炼/归档/整理）归爱丽丝
      const agent = ctx.agents?.get(session.id)
      if (agent === undefined) return
      const text = '[memory] 会话刚完成一次压缩，checkpoint 原文已存档为条目 ' + entryId
        + '（scope=' + scope + '）。是否提炼记忆版、如何组织，由你决定。'
      try {
        agent.send(
          createUserMessage({ content: [{ type: 'text', text }], source: { kind: 'dsh-agent-memory' } }),
          'next-turn',
          true, // wakeup=true：压缩完成即自动送达（主人 2026-08-16：不等主人下一条消息）
        )
      } catch { /* 通知失败不阻塞；原文已存档，不会丢 */ }
    }
    void deps.store.remember({
      kind: 'episodic',
      title,
      body: `> 压缩于 ${formatLocalStamp(now)}\n\n${text}`,
      // 两个标签，语义不同、都要盖：
      // - `compaction`：分类（「这是压缩相关条目」），历史条目也用它
      // - `COLD_CHECKPOINT_TAG`：**读取侧判据**（v0.22.1）——让本条从一落库起就退出
      //   活跃检索面。理由见 types.ts::COLD_CHECKPOINT_TAG 的读数：这类条目是「容器」，
      //   包含几乎所有查询词 ⇒ 在归档前的窗口期里靠词命中累加霸榜，一次命中 25KB 噪音。
      //   与 archived 互补（归档后靠 archived 挡），回查走 get(id) 或 includeArchive ✓
      tags: ['compaction', COLD_CHECKPOINT_TAG],
      scope,
      level: null,
      bucket: null,
      source: { sessionId: session.id, reason: 'compaction/end' },
    }).then((result) => { notify(result.id) }).catch((err: unknown) => {
      // ⚠ **不许空吞**（2026-11-12 · 台账 lh-2659bafb）：pending 已删、下次是新 compactionId
      // ⇒ 「下次压缩再试」不存在。这一条原文**就此永久丢失**，唯一能做的就是把它记下来。
      // 侧车写入本身吞错（appendJsonl 恒不抛）：证据层坏了也不能把压缩流程带崩。
      const path = deps.failureTracePath
      if (path === undefined || path === '') return
      const record: CompactionSinkFailure = {
        atMs: Date.now(),
        compactionId: ev.data.compactionId,
        sessionId: session.id,
        scope,
        error: describeSinkError(err),
      }
      void appendJsonl(path, record, deps.failureTraceMaxBytes ?? 0)
    })
  })
}
