/**
 * @studyzy/dsh-web-remote-access/startup — a fork of `@deepseek-ai/dsh-web-app/startup` that
 * parses the `dsh --profile web` flag family (`--host`, `--port`,
 * `--trusted-host`, `--web_token`) and its `--help` text, then provides the
 * immutable values as {@link WEB_STARTUP_SERVICE}. Ordinary rows inject that
 * service before reading it from lazy config. The web token exists only for
 * an all-interfaces bind (`--host 0.0.0.0`): the explicit `--web_token` wins,
 * then `$DSH_WEB_TOKEN`, then a fresh random token minted at startup. A
 * loopback bind runs token-less (`webToken` ''), so its printed URL opens
 * directly without any grant.
 *
 * The flag parse and bounded-exit wiring is a vendored port of
 * `@deepseek-ai/dsh-cmdline`'s `parseCmdline` (MIT). This bundle forks the
 * official startup, and depending on that rc package pulled an unsatisfied
 * `dsh-invariants` peer into every profile install (the harness resolves
 * out-of-tree peers at runtime, but pnpm still warns). Inlining the ~40 lines
 * keeps consumers install-clean and independent of rc churn.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Stable Cordis plugin name. */
export declare const name = "web-startup";
/** Services required before the flags can be resolved. */
export declare const inject: string[];
/** Service provided by this ordinary plugin and injected by flag-configured rows. */
export declare const WEB_STARTUP_SERVICE = "webStartup";
/** Environment variable that supplies the web token when no `--web_token` is given. */
export declare const WEB_TOKEN_ENV = "DSH_WEB_TOKEN";
/** What the web rows read from {@link WEB_STARTUP_SERVICE}. */
export interface WebStartupValues {
    /** Whether this invocation opens the default browser after startup. */
    openBrowser: boolean;
    /** `--host`, absent when the invocation did not name one. */
    host?: string;
    /** `--port`, absent when the invocation did not name one. */
    port?: number;
    /** Explicit `--trusted-host` authorities, in argument order. */
    trustedHosts: string[];
    /** The active web token: `--web_token`, else `$DSH_WEB_TOKEN`, else a fresh random one on an all-interfaces bind; empty (no gate) on a loopback bind. */
    webToken: string;
}
/** Test hooks: randomness, the environment seam, and the output streams. */
export declare const internals: {
    /** Mint the random fallback token; randomBytes(32) → base64url by default. */
    mintRandomToken: () => string;
    /** Read the `DSH_WEB_TOKEN` environment variable. */
    envWebToken: () => string | undefined;
    /** Process stream commander output is written to; tests replace these to capture text. */
    stdout: {
        write(chunk: string): unknown;
    };
    stderr: {
        write(chunk: string): unknown;
    };
};
/**
 * Parse and provide the Web invocation as an ordinary Cordis service. The
 * command's action publishes the flags this invocation named plus the resolved
 * web token; a non-numeric `--port` is a usage error, so on rejection (and on
 * `--help`) nothing is provided.
 * @param ctx - plugin context carrying the command line.
 */
export declare function apply(ctx: Context): void;
