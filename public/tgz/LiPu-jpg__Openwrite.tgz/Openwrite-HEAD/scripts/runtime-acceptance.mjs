// Exercise process lifecycle against the installed wheel, using only isolated state.
import assert from 'node:assert/strict'
import { readFile, writeFile, cp, mkdir, rm, readdir } from 'node:fs/promises'
import { pathToFileURL } from 'node:url'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

export async function acceptRuntime(installed, home, temporary) {
  const { ManagedRuntime, stopOwnedProcess } = await import(pathToFileURL(join(installed, 'packages/openwrite-bridge/lib/managed-runtime.js')).href)
  const artifacts = join(installed, 'release')
  const root = join(home, 'openwrite')
  const first = new ManagedRuntime(root, artifacts)
  const second = new ManagedRuntime(root, artifacts)
  try {
    const [a, b] = await Promise.all([first.ensure(), second.ensure()])
    await acceptSystemPython(installed, first.child.spawnfile, temporary)
    const native = spawnSync(first.child.spawnfile, ['-I', '-X', 'utf8', '-c', 'import sys, onnxruntime, fastembed; from cryptography.hazmat.backends.openssl.backend import backend; assert sys.flags.utf8_mode; print("\\u2713"); assert "CPUExecutionProvider" in onnxruntime.get_available_providers(); assert backend.openssl_version_text()'], { cwd: root, encoding: 'utf8', timeout: 60_000 })
    assert.equal(native.status, 0, `Native dependency import failed: ${native.stderr}`)
    assert.notEqual(a.baseUrl, b.baseUrl, 'instances choose separate free ports')
    assert.equal((await fetch(a.baseUrl + '/api/health')).status, 401)
    assert.equal((await fetch(a.baseUrl + '/api/project/init', { method: 'POST', headers: { 'X-OpenWrite-Studio': '1' } })).status, 401)
    const health = await fetch(a.baseUrl + '/api/health', { headers: { Authorization: 'Bearer ' + a.token } })
    assert.equal((await health.json()).contract_version, 1)
    const novel = join(temporary, 'backend-中文作品-100%')
    await mkdir(novel)
    const initializedAt = Date.now()
    // Cold workspace initialization includes filesystem and Git work. Allow
    // slower native runners to finish, without retrying this write operation.
    const initializationTimeoutMs = 60_000
    console.log('Backend: initializing empty Unicode workspace; stdout paused:', second.child.stdout.isPaused())
    try {
      const initialized = await fetch(b.baseUrl + '/api/project/init', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + b.token, 'Content-Type': 'application/json', 'X-OpenWrite-Studio': '1', 'X-OpenWrite-Workspace-Root': encodeURIComponent(novel), 'X-OpenWrite-Workspace-Root-Encoding': 'uri' },
        body: JSON.stringify({ novel_id: 'backend-test', title: '后端初始化验收', author: '初始化作者', language: 'zh-CN', project_path: novel }),
        signal: AbortSignal.timeout(initializationTimeoutMs),
      })
      assert.equal(initialized.status, 200)
      const payload = await initialized.json()
      assert.equal((payload.data ?? payload).initialized, true)
      const project = (payload.data ?? payload).project
      assert.equal(project.metadata.author, '初始化作者')
      const metadataUrl = b.baseUrl + '/api/project/metadata'
      const metadataHeaders = { Authorization: 'Bearer ' + b.token, 'Content-Type': 'application/json', 'X-OpenWrite-Studio': '1', 'X-OpenWrite-Workspace-Root': encodeURIComponent(novel), 'X-OpenWrite-Workspace-Root-Encoding': 'uri' }
      const metadataBody = JSON.stringify({ author: '交付作者', expected_revision: project.metadata_revision })
      const updated = await fetch(metadataUrl, { method: 'POST', headers: metadataHeaders, body: metadataBody, signal: AbortSignal.timeout(15_000) })
      assert.equal(updated.status, 200)
      assert.equal((await updated.json()).metadata.author, '交付作者')
      assert.equal((await fetch(metadataUrl, { method: 'POST', headers: metadataHeaders, body: metadataBody, signal: AbortSignal.timeout(15_000) })).status, 409)
      assert.equal((await fetch(metadataUrl, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-OpenWrite-Studio': '1' }, body: metadataBody, signal: AbortSignal.timeout(15_000) })).status, 401)
      // Native packaged-Core regression: passive POST queries must not become workspace changes.
      const manuscript = '# 第一章\n\n只读回归正文。\n'
      const manuscriptPath = 'data/manuscript/arc_001/ch_001.md'
      const manuscriptDirectory = join(novel, 'data/novels/backend-test/data/manuscript/arc_001')
      await mkdir(manuscriptDirectory, { recursive: true })
      await writeFile(join(manuscriptDirectory, 'ch_001.md'), manuscript)
      const editing = async body => {
        const response = await fetch(b.baseUrl + '/api/manuscript-editing', {
          method: 'POST', headers: metadataHeaders, body: JSON.stringify(body), signal: AbortSignal.timeout(15_000),
        })
        const payload = await response.json()
        assert.equal(response.status, 200, JSON.stringify(payload))
        return { payload, mutated: response.headers.get('X-OpenWrite-Mutated') }
      }
      const epoch = async () => {
        const response = await fetch(b.baseUrl + '/api/workspace/context', { headers: metadataHeaders })
        assert.equal(response.status, 200)
        return (await response.json()).context_epoch
      }
      const saved = await editing({ action: 'checkpoint', chapter_id: 'ch_001' })
      assert.equal(saved.mutated, '1')
      const beforeReads = await epoch()
      for (const action of ['annotations', 'annotations', 'annotations', 'versions', 'version', 'compare']) {
        const read = await editing({ action, chapter_id: 'ch_001', version_id: saved.payload.version_id })
        assert.equal(read.mutated, '0')
        assert.equal(await epoch(), beforeReads)
      }
      const quote = '只读回归正文。'
      const start = manuscript.indexOf(quote)
      const annotation = await editing({ action: 'annotate', chapter_id: 'ch_001', revision: saved.payload.source_revision,
        quote, start_hint: start, end_hint: start + quote.length, note: '原生验收批注' })
      assert.equal(annotation.mutated, '1')
      assert.equal(await epoch(), beforeReads + 1)
      const read = await editing({ action: 'annotations', chapter_id: 'ch_001' })
      assert.equal(read.payload.annotations[0].annotation_id, annotation.payload.annotation_id)
      assert.equal(await epoch(), beforeReads + 1)
      const documentWrite = await fetch(b.baseUrl + '/api/document', {
        method: 'PUT', headers: metadataHeaders, body: JSON.stringify({ path: manuscriptPath, content: manuscript + '真实修改。\n' }),
        signal: AbortSignal.timeout(15_000),
      })
      assert.equal(documentWrite.status, 200)
      assert.equal(documentWrite.headers.get('X-OpenWrite-Mutated'), '1')
      await documentWrite.json()
      assert.equal(await epoch(), beforeReads + 2)
      console.log('Backend: Unicode initialization complete', Date.now() - initializedAt, 'ms')
    } catch (error) {
      console.error('Backend initialization diagnostics:', { elapsed: Date.now() - initializedAt, timeoutMs: initializationTimeoutMs, stdoutPaused: second.child.stdout.isPaused(), files: await readdir(novel, { recursive: true }) })
      if (process.platform === 'win32') {
        const { diagnoseInitialization } = await import('./windows-runtime-diagnostic.mjs')
        await diagnoseInitialization(second.child.spawnfile, temporary, stopOwnedProcess)
      }
      throw error
    }
    const previousUrl = a.baseUrl
    await stopOwnedProcess(first.child)
    const recovered = await first.ensure()
    assert.equal(first.status().phase, 'ready', `expected auto-recovery, got ${JSON.stringify(first.status())}`)
    assert.match(first.status().message, /in-progress writing and review tasks require an explicit retry/)
    assert.notEqual(recovered.baseUrl, previousUrl)
    assert.equal((await fetch(recovered.baseUrl + '/api/health', { headers: { Authorization: 'Bearer ' + b.token } })).status, 401)
    await first.dispose()
    assert.equal(second.status().phase, 'ready', 'one plugin cannot stop another instance')
    assert.equal((await fetch(b.baseUrl + '/api/health', { headers: { Authorization: 'Bearer ' + b.token } })).status, 200)
    const previous = await readFile(join(root, 'active.json'), 'utf8')
    const bad = join(temporary, 'corrupt-release')
    await mkdir(bad)
    const manifest = JSON.parse(await readFile(join(artifacts, 'runtime-manifest.json')))
    await cp(join(artifacts, 'runtime-manifest.json'), join(bad, 'runtime-manifest.json'))
    await writeFile(join(bad, manifest.wheel.file), 'interrupted upgrade')
    const failed = new ManagedRuntime(root, bad)
    await assert.rejects(failed.ensure(), /Package verification failed; reinstall OpenWrite/)
    assert.equal(await readFile(join(root, 'active.json'), 'utf8'), previous)
    await failed.dispose()
    await rm(bad, { recursive: true })
    const rollback = new ManagedRuntime(root, artifacts)
    try { await rollback.ensure(); assert.equal(rollback.status().phase, 'ready') }
    finally { await rollback.dispose() }
    return ['supplied-python-runtime', 'native-dependency-load', 'native-backend-project-init', 'project-metadata-update', 'readonly-post-invalidation', 'manuscript-mutation-invalidation', 'multiple-instances', 'dynamic-ports', 'backend-auth', 'crash-recovery', 'owned-process-cleanup', 'failed-upgrade-preserves-active', 'rollback']
  } finally { await first.dispose(); await second.dispose() }
}

/** Exercise the exact bundled Core with an existing interpreter, without downloading or pip. */
export async function acceptSystemPython(installed, pythonPath, temporary) {
  const { ManagedRuntime } = await import(pathToFileURL(join(installed, 'packages/openwrite-bridge/lib/managed-runtime.js')).href)
  const root = join(temporary, 'supplied-python-runtime')
  const runtime = new ManagedRuntime(root, join(installed, 'release'), { pythonPath })
  runtime.extract = async () => { throw new Error('Supplied Python must not download a runtime') }
  try {
    const connection = await runtime.ensure()
    assert.equal(runtime.status().phase, 'ready')
    assert.equal(runtime.child.spawnfile, pythonPath)
    assert.equal((await fetch(connection.baseUrl + '/api/health')).status, 401)
    const headers = { Authorization: `Bearer ${connection.token}` }
    const response = await fetch(connection.baseUrl + '/api/health', { headers })
    assert.equal(response.status, 200)
    const manifest = JSON.parse(await readFile(join(installed, 'release/runtime-manifest.json')))
    assert.equal((await response.json()).core_version, manifest.core_version)
    const page = await fetch(connection.baseUrl + '/', { headers })
    assert.equal(page.status, 200)
    assert.match(await page.text(), /OpenWrite/)
    assert.equal((await readdir(root)).includes('binaries'), false)
    console.log('Supplied Python: real bundled Core health, authentication and Studio assets passed')
  } finally { await runtime.dispose() }
}
