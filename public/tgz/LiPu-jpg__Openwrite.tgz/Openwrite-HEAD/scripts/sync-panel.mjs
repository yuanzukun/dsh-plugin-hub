import { cp, mkdir, rm } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { join } from 'node:path'

const root = fileURLToPath(new URL('../', import.meta.url))
const source = join(root, 'packages/studio-panel')
const destination = join(root, 'node_modules/@dsh-novel/studio-panel')

// pnpm Git installs do not preserve npm's local-dependency symlinks. Stage a
// real bundled package on every build so tarball and source installs agree.
await rm(destination, { recursive: true, force: true })
await mkdir(destination, { recursive: true })
for (const entry of ['lib', 'vendor', 'cordis.patch.yml', 'package.json', 'LICENSE', 'README.md']) {
  await cp(join(source, entry), join(destination, entry), {
    recursive: true,
    filter: path => !path.endsWith('.map') && !path.endsWith('.tsbuildinfo'),
  })
}
