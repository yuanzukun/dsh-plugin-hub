// Git installs build here only after the user authorizes this package in pnpm.
// Precompiled Release tarballs need no install script or sibling checkout.
import { access, readFile, stat, writeFile } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const root = fileURLToPath(new URL('../', import.meta.url))
const sourceArchive = await access(new URL('../.git', import.meta.url)).then(() => false, () => true)
if (sourceArchive) {
  // pnpm's Git provider ignores local file dependencies. Include the panel
  // and mount that relative module only in a source archive; the release
  // tarball built from a git checkout keeps the bundled package identity.
  const path = new URL('../package.json', import.meta.url)
  const pkg = JSON.parse(await readFile(path, 'utf8'))
  pkg.files = [...new Set([...pkg.files, 'packages/studio-panel/vendor', 'packages/studio-panel/lib', 'packages/studio-panel/cordis.patch.yml', 'packages/studio-panel/package.json', 'packages/studio-panel/LICENSE', 'packages/studio-panel/README.md'])]
  delete pkg.dependencies['@dsh-novel/studio-panel']
  pkg.bundledDependencies = pkg.bundledDependencies.filter(name => name !== '@dsh-novel/studio-panel')
  if (pkg.bundledDependencies.length === 0) delete pkg.bundledDependencies
  pkg.exports['./panel'] = './packages/studio-panel/lib/index.js'
  await writeFile(path, JSON.stringify(pkg, null, 2) + '\n')
  const patchPath = new URL('../cordis.patch.yml', import.meta.url)
  const patch = await readFile(patchPath, 'utf8')
  await writeFile(patchPath, patch.replace("name: '@dsh-novel/studio-panel'", 'name: ./packages/studio-panel/lib/index.js'))
}
const manifest = JSON.parse(await readFile(new URL('../release/runtime-manifest.json', import.meta.url), 'utf8'))
let built = false
await access(new URL('../release/' + manifest.wheel.file, import.meta.url))
// The plugin version is baked into the client bundle as the preset identity
// (`openwrite-<version>`), so a package.json edited after the last build
// leaves the bundle naming the previous release. A build that only checks
// whether the outputs exist packs that stale identity, and the host then
// answers `preset "openwrite-<old>" not found`. Rebuild whenever the manifest
// is newer than the artifacts it feeds.
const manifestStamp = (await stat(new URL('../package.json', import.meta.url))).mtimeMs
for (const dir of ['packages/openwrite-bridge', 'packages/studio-panel']) {
  const outputs = [
    new URL(`../${dir}/lib/index.js`, import.meta.url),
    new URL(`../${dir}/lib/${dir.endsWith('openwrite-bridge') ? 'preset-tools.js' : 'client.js'}`, import.meta.url),
  ]
  let newest = 0
  try { for (const file of outputs) newest = Math.max(newest, (await stat(file)).mtimeMs) } catch { newest = 0 }
  if (newest !== 0 && newest >= manifestStamp) continue
  built = true
  for (const args of [['ci', '--ignore-scripts', '--no-audit', '--no-fund'], ['run', 'build']]) {
    const result = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', args, { cwd: root + dir, stdio: 'inherit', shell: process.platform === 'win32' })
    if (result.status !== 0) throw new Error(`${dir}: ${args.join(' ')} failed`)
  }
}
// Provenance must be refreshed whenever the source tree no longer matches the
// recorded hash, not merely when this run happened to build. Gating on `built`
// alone means "edit src/, then pack without rebuilding" publishes a tarball
// whose release/source.json still names the previous tree — and that file is
// gitignored, so release-report.mjs's dirty check cannot see it either.
let provenanceStale = true
try {
  provenanceStale = !JSON.parse(await readFile(new URL('../release/source.json', import.meta.url), 'utf8')).sourceTreeSha256
} catch { /* missing or unreadable: regenerate */ }
if (built || provenanceStale) {
  const result = spawnSync(process.execPath, [fileURLToPath(new URL('./release-provenance.mjs', import.meta.url))], { cwd: root, stdio: 'inherit' })
  if (result.status !== 0) throw new Error('Release provenance generation failed')
}
await import('./sync-panel.mjs')
