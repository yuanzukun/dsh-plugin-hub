import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, writeFile, readFile, readdir, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { createHash } from 'node:crypto'
import { createServer } from 'node:http'
import { spawn } from 'node:child_process'
import { EventEmitter } from 'node:events'
import { PassThrough } from 'node:stream'
import { ManagedRuntime, UnsupportedRuntimePlatformError, sanitizeDiagnostic, stopOwnedProcess, buildChildEnv } from '../lib/managed-runtime.js'
import { StudioClient } from '../lib/client.js'

test('unsupported runtime is actionable and never becomes a network error or starts installation', async t => {
  const root = await fixture(t)
  await writeFile(join(root, 'runtime-manifest.json'), JSON.stringify({ platforms: {} }))
  const runtime = new ManagedRuntime(join(root, 'runtime'), root)
  const client = new StudioClient({ baseUrl: 'http://127.0.0.1:1', timeoutMs: 1000, connect: () => runtime.ensure() })
  await assert.rejects(client.getJson('/api/health'), error => {
    assert.equal(error.code, 'RUNTIME_PLATFORM_UNSUPPORTED')
    assert.equal(error.status, 503)
    assert.match(error.message, /mode: external/)
    assert.match(error.message, /File tools/)
    return true
  })
  assert.deepEqual(await readdir(root), ['runtime-manifest.json'])
  assert.equal(new UnsupportedRuntimePlatformError('android/arm64').code, 'RUNTIME_PLATFORM_UNSUPPORTED')
  await runtime.dispose()
})

async function fixture(t) {
  const root = await mkdtemp(join(tmpdir(), 'openwrite-managed-test-'))
  t.after(() => rm(root, { recursive: true, force: true }))
  return root
}

test('cross-process installation lease waits, cancels, and can be reacquired', async t => {
  const root = await fixture(t)
  const first = new ManagedRuntime(root, root)
  const second = new ManagedRuntime(root, root)
  const unlock = await first.lock(new AbortController().signal)
  const controller = new AbortController()
  const waiting = second.lock(controller.signal)
  setTimeout(() => controller.abort(), 30)
  await assert.rejects(waiting, { name: 'AbortError' })
  assert.equal(second.status().phase, 'waiting')
  await unlock()
  await (await second.lock(new AbortController().signal))()
})

test('untrusted local wheel fails before creating an environment; old active generation survives', async t => {
  const root = await fixture(t)
  const artifacts = join(root, 'artifacts')
  await mkdir(artifacts)
  await writeFile(join(root, 'active.json'), '{"generation":"old"}')
  await writeFile(join(artifacts, 'core.whl'), 'tampered')
  await writeFile(join(artifacts, 'runtime-manifest.json'), JSON.stringify({ platforms: { [`${process.platform}-${process.arch}`]: {} }, wheel: { file: 'core.whl', sha256: '0'.repeat(64) }, requirements: { file: 'requirements.lock', sha256: '0'.repeat(64) } }))
  const runtime = new ManagedRuntime(root, artifacts)
  await assert.rejects(runtime.ensure(), /verification failed/)
  assert.equal(runtime.status().phase, 'error')
  assert.equal(await readFile(join(root, 'active.json'), 'utf8'), '{"generation":"old"}')
  assert.equal((await readdir(root)).includes('environments'), false)
  await runtime.dispose()
  await assert.rejects(runtime.ensure(), /removed/)
})

test('interrupted downloads remove partial files; retry verifies and reuses the cache', async t => {
  const root = await fixture(t)
  const payload = Buffer.alloc(32 * 1024, 7)
  let calls = 0
  const server = createServer((_req, res) => {
    calls++
    res.writeHead(200, { 'content-length': payload.length })
    res.write(payload.subarray(0, 16))
    if (calls > 1) res.end(payload.subarray(16))
  })
  await new Promise(done => server.listen(0, '127.0.0.1', done))
  t.after(() => { server.closeAllConnections(); server.close() })
  const item = { url: `http://127.0.0.1:${server.address().port}/uv.zip`, sha256: createHash('sha256').update(payload).digest('hex'), executable: 'uv' }
  const runtime = new ManagedRuntime(root, root)
  await assert.rejects(runtime.download(item, AbortSignal.timeout(100)))
  assert.deepEqual(await readdir(join(root, 'cache')), [])
  const path = await runtime.download(item, new AbortController().signal)
  assert.deepEqual(await readFile(path), payload)
  assert.equal(await runtime.download(item, new AbortController().signal), path)
  assert.equal(calls, 2)
})

test('slow origins fall back to a mirror; checksums still gate the result', async t => {
  const root = await fixture(t)
  const payload = Buffer.alloc(64 * 1024, 9)
  let originCalls = 0
  const origin = createServer((_req, res) => {
    originCalls++
    res.writeHead(200, { 'content-length': payload.length })
    res.write(payload.subarray(0, 16)) // trickle, then go silent: below the slow threshold
  })
  let mirrorCalls = 0
  const mirror = createServer((_req, res) => {
    mirrorCalls++
    res.writeHead(200, { 'content-length': payload.length })
    res.end(payload)
  })
  await new Promise(done => origin.listen(0, '127.0.0.1', done))
  await new Promise(done => mirror.listen(0, '127.0.0.1', done))
  t.after(() => { origin.closeAllConnections(); origin.close(); mirror.closeAllConnections(); mirror.close() })
  const previous = {
    OPENWRITE_DOWNLOAD_SLOW_MS: process.env.OPENWRITE_DOWNLOAD_SLOW_MS,
    OPENWRITE_DOWNLOAD_MIRRORS: process.env.OPENWRITE_DOWNLOAD_MIRRORS,
  }
  process.env.OPENWRITE_DOWNLOAD_SLOW_MS = '50'
  process.env.OPENWRITE_DOWNLOAD_MIRRORS = `http://127.0.0.1:${mirror.address().port}/`
  t.after(() => {
    for (const [key, value] of Object.entries(previous)) {
      if (value === undefined) delete process.env[key]
      else process.env[key] = value
    }
  })
  const item = { url: `http://127.0.0.1:${origin.address().port}/uv.zip`, sha256: createHash('sha256').update(payload).digest('hex'), executable: 'uv' }
  const runtime = new ManagedRuntime(root, root)
  const path = await runtime.download(item, new AbortController().signal)
  assert.deepEqual(await readFile(path), payload)
  assert.equal(originCalls, 1)
  assert.equal(mirrorCalls, 1)
})

test('package index overrides pass the child env allowlist; credentials still do not', () => {
  const env = buildChildEnv({
    UV_DEFAULT_INDEX: 'https://pypi.tuna.tsinghua.edu.cn/simple',
    UV_INDEX_URL: 'https://mirrors.aliyun.com/pypi/simple/',
    PIP_INDEX_URL: 'https://pypi.tuna.tsinghua.edu.cn/simple',
    PIP_TRUSTED_HOST: 'pypi.tuna.tsinghua.edu.cn',
    UV_HTTP_TIMEOUT: '120',
  })
  assert.equal(env.UV_DEFAULT_INDEX, 'https://pypi.tuna.tsinghua.edu.cn/simple')
  assert.equal(env.UV_INDEX_URL, 'https://mirrors.aliyun.com/pypi/simple/')
  assert.equal(env.PIP_INDEX_URL, 'https://pypi.tuna.tsinghua.edu.cn/simple')
  assert.equal(env.PIP_TRUSTED_HOST, 'pypi.tuna.tsinghua.edu.cn')
  assert.equal(env.UV_HTTP_TIMEOUT, '120')
})

test('owned process stops and diagnostics conceal credential-bearing errors', async () => {
  const child = spawn(process.execPath, ['-e', 'setInterval(()=>{},1000)'], { detached: process.platform !== 'win32', stdio: 'ignore' })
  await new Promise((done, reject) => { child.once('spawn', done); child.once('error', reject) })
  await stopOwnedProcess(child)
  assert.ok(child.exitCode !== null || child.signalCode !== null)
  const message = sanitizeDiagnostic('https://user:password@example.test/a?token=abc&key=def authorization: Bearer-secret api_key=xyz')
  for (const secret of ['user:password', 'abc', 'def', 'Bearer-secret', 'xyz']) assert.equal(message.includes(secret), false)
})

test('Unicode workspace headers survive HTTP byte restrictions without changing ASCII identities', async () => {
  const { workspaceRootHeaders } = await import('../lib/client.js')
  for (const path of ['/tmp/中文作品-100%', 'C:\\作者\\中文作品']) {
    const headers = new Headers(workspaceRootHeaders(path))
    assert.equal(headers.get('x-openwrite-workspace-root-encoding'), 'uri')
    assert.equal(decodeURIComponent(headers.get('x-openwrite-workspace-root')), path)
    assert.equal(new Headers(workspaceRootHeaders(path, true)).get('x-openwrite-workspace-root'), headers.get('x-openwrite-workspace-root'))
  }
  assert.deepEqual(workspaceRootHeaders('/tmp/book%20literal'), { 'X-OpenWrite-Workspace-Root': '/tmp/book%20literal' })
})

const BACKEND = `
const { createServer } = require('node:http')
const { createInterface } = require('node:readline')
const { appendFileSync } = require('node:fs')
const crash = process.env.OPENWRITE_CRASH || ''
if (crash === 'during-start') process.exit(Number(process.env.OPENWRITE_EXIT_CODE || 9))
const crashMs = Number(process.env.OPENWRITE_CRASH_MS || 0)
const log = process.env.OPENWRITE_POST_LOG
const rl = createInterface({ input: process.stdin })
rl.once('line', line => {
  const token = JSON.parse(line).token
  const server = createServer((req, res) => {
    if (log && req.method !== 'GET') appendFileSync(log, req.method + ' ' + (req.url || '') + '\\n')
    if ((req.url || '').startsWith('/api/health')) {
      if (req.headers.authorization !== 'Bearer ' + token) { res.writeHead(401); res.end(); return }
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ core_version: 'test-core', contract_version: 1 }))
      return
    }
    if ((req.url || '').startsWith('/api/write')) {
      if (process.env.OPENWRITE_HANG_WRITE) return
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ ok: true, data: { accepted: true } }))
      return
    }
    res.writeHead(404); res.end()
  })
  server.listen(0, '127.0.0.1', () => {
    process.stdout.write(JSON.stringify({ port: server.address().port }) + '\\n')
    if (crash === 'after-ready' || crashMs) setTimeout(() => process.exit(Number(process.env.OPENWRITE_EXIT_CODE || 7)), crashMs || 60)
  })
})
`

async function prepared(t) {
  const root = await fixture(t)
  const artifacts = join(root, 'artifacts')
  await mkdir(artifacts)
  const wheel = Buffer.from('wheel')
  const requirements = Buffer.from('req')
  await writeFile(join(artifacts, 'core.whl'), wheel)
  await writeFile(join(artifacts, 'requirements.lock'), requirements)
  const manifest = {
    schema: 1, dsh: '0.1.2-rc.1', python_version: '3.12', core_version: 'test-core', contract_version: 1,
    platforms: { [`${process.platform}-${process.arch}`]: {
      uv: { url: 'http://127.0.0.1/uv', sha256: '0'.repeat(64), executable: 'uv' },
      python: { url: 'http://127.0.0.1/py', sha256: '0'.repeat(64), executable: 'python' },
    } },
    wheel: { file: 'core.whl', sha256: createHash('sha256').update(wheel).digest('hex') },
    requirements: { file: 'requirements.lock', sha256: createHash('sha256').update(requirements).digest('hex') },
  }
  await writeFile(join(artifacts, 'runtime-manifest.json'), JSON.stringify(manifest))
  const parsed = JSON.parse(await readFile(join(artifacts, 'runtime-manifest.json'), 'utf8'))
  const generation = createHash('sha256').update(JSON.stringify(parsed)).digest('hex').slice(0, 24)
  const envDir = join(root, 'environments', generation)
  await mkdir(join(envDir, process.platform === 'win32' ? 'Scripts' : 'bin'), { recursive: true })
  await writeFile(join(envDir, '.complete'), generation)
  await writeFile(join(envDir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python'), '')
  return { root, artifacts }
}

function backendSpawn(t, extraEnv = {}, recorded = []) {
  const spawnFn = (command, args, options) => {
    recorded.push({ command, args: [...args], env: { ...(options.env ?? {}) } })
    if (args.includes('tools.managed_runtime')) {
      return spawn(process.execPath, ['-e', BACKEND], {
        ...options,
        env: { ...options.env, ...extraEnv() },
      })
    }
    return spawn(command, args, options)
  }
  return spawnFn
}

async function waitPhase(runtime, phase, timeout = 8_000) {
  const start = Date.now()
  while (Date.now() - start < timeout) {
    if (runtime.status().phase === phase) return runtime.status()
    await new Promise(resolve => setTimeout(resolve, 20))
  }
  throw new Error(`timed out waiting for ${phase}, last ${JSON.stringify(runtime.status())}`)
}

function trackUnhandled(t) {
  const seen = []
  const on = reason => { seen.push(reason) }
  process.on('unhandledRejection', on)
  t.after(() => process.removeListener('unhandledRejection', on))
  return seen
}

function abortableDelay(ms, value, options) {
  return new Promise((resolve, reject) => {
    const abort = () => {
      const error = new Error('aborted')
      error.name = 'AbortError'
      reject(error)
    }
    if (options?.signal?.aborted) { abort(); return }
    const timer = setTimeout(() => resolve(value), ms)
    options?.signal?.addEventListener('abort', () => { clearTimeout(timer); abort() }, { once: true })
  })
}

test('child env allowlist drops provider keys and keeps proxy/cert/OS start vars', () => {
  const env = buildChildEnv({
    OPENAI_API_KEY: 'sk-test', ANTHROPIC_API_KEY: 'ant-test', LLM_API_KEY: 'llm-test',
    PATH: '/bin', HTTP_PROXY: 'http://proxy.example:8080', SSL_CERT_FILE: '/certs/ca.pem',
    HOME: '/home/author', SYSTEMROOT: 'C:\\\\Windows',
  }, { PYTHONNOUSERSITE: '1', PYTHONUTF8: '1', UV_CACHE_DIR: '/tmp/uv' })
  for (const key of ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'LLM_API_KEY']) assert.equal(env[key], undefined)
  assert.equal(env.PATH, '/bin')
  assert.equal(env.HTTP_PROXY, 'http://proxy.example:8080')
  assert.equal(env.SSL_CERT_FILE, '/certs/ca.pem')
  assert.equal(env.PYTHONUTF8, '1')
  assert.equal(env.PYTHONNOUSERSITE, '1')
  assert.equal(env.UV_CACHE_DIR, '/tmp/uv')
})

test('no_proxy values are sanitized: bracketed IPv6 literals break httpx client construction', () => {
  // DSH's loopback bypass appends "[::1]" for undici; httpx parses each entry
  // as host:port and throws InvalidURL before any request leaves the process.
  const env = buildChildEnv({
    NO_PROXY: '192.168.2.88,.local,localhost,127.0.0.1,::1,[::1]',
    no_proxy: 'localhost, [::1] ,internal.example,,',
  })
  assert.equal(env.NO_PROXY, '192.168.2.88,.local,localhost,127.0.0.1,::1')
  assert.equal(env.no_proxy, 'localhost,internal.example')
  // Entries without brackets are untouched; non-no_proxy vars are not rewritten.
  const passthrough = buildChildEnv({ NO_PROXY: 'localhost,::1', HTTPS_PROXY: 'http://127.0.0.1:7897' })
  assert.equal(passthrough.NO_PROXY, 'localhost,::1')
  assert.equal(passthrough.HTTPS_PROXY, 'http://127.0.0.1:7897')
})

test('ready managed child auto-restarts with backoff; cap leaves a retryable error', async t => {
  const previous = {
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
    LLM_API_KEY: process.env.LLM_API_KEY,
  }
  Object.assign(process.env, { OPENAI_API_KEY: 'sk-test', ANTHROPIC_API_KEY: 'ant-test', LLM_API_KEY: 'llm-test' })
  t.after(() => {
    for (const [key, value] of Object.entries(previous)) {
      if (value === undefined) delete process.env[key]
      else process.env[key] = value
    }
  })
  const { root, artifacts } = await prepared(t)
  const recorded = []
  const delays = []
  const crash = { value: '' }
  const runtime = new ManagedRuntime(root, artifacts, {
    spawn: backendSpawn(t, () => ({ OPENWRITE_CRASH: crash.value, OPENWRITE_EXIT_CODE: '7' }), recorded),
    delay: async (ms, value, options) => {
      delays.push(ms)
      if (options?.signal?.aborted) { const error = new Error('aborted'); error.name = 'AbortError'; throw error }
      return value
    },
    restartLimit: 2,
    backoffMs: [11, 22],
  })
  t.after(() => runtime.dispose())
  const first = await runtime.ensure()
  assert.equal(runtime.status().phase, 'ready')
  assert.ok(first.token)
  assert.equal((await fetch(first.baseUrl + '/api/health')).status, 401)
  const backendSpawns = () => recorded.filter(item => item.args.includes('tools.managed_runtime'))
  assert.equal(backendSpawns()[0].env.OPENAI_API_KEY, undefined)
  assert.equal(backendSpawns()[0].env.ANTHROPIC_API_KEY, undefined)
  assert.equal(backendSpawns()[0].env.LLM_API_KEY, undefined)
  assert.equal(backendSpawns()[0].env.PYTHONUTF8, '1')
  crash.value = 'after-ready'
  await stopOwnedProcess(runtime.child)
  const recovering = await waitPhase(runtime, 'recovering')
  assert.match(recovering.message, /recovering/i)
  assert.match(recovering.error ?? '', /exit 7|signal/)
  const recovered = await waitPhase(runtime, 'ready')
  assert.match(recovered.message, /explicit retry/)
  assert.doesNotMatch(recovered.message, /(?:writing|review) tasks? (?:were |was )?(?:recovered|resumed)/i)
  assert.ok(delays.includes(11) || delays.includes(22))
  await waitPhase(runtime, 'error', 12_000)
  assert.match(runtime.status().message, /Retry manually/)
  assert.match(runtime.status().error ?? '', /exit 7|signal/)
  crash.value = ''
  const retried = await runtime.ensure()
  assert.equal(runtime.status().phase, 'ready')
  assert.equal((await fetch(retried.baseUrl + '/api/health', { headers: { Authorization: 'Bearer ' + retried.token } })).status, 200)
  await runtime.dispose()
  assert.equal(runtime.status().phase, 'uninstalled')
  assert.equal(runtime.child, undefined)
})

test('cancel, dispose and a stale child exit do not revive or clobber a newer connection', async t => {
  const { root, artifacts } = await prepared(t)
  const recorded = []
  const runtime = new ManagedRuntime(root, artifacts, {
    spawn: backendSpawn(t, () => ({}), recorded),
    delay: async (ms, value, options) => {
      if (options?.signal?.aborted) { const error = new Error('aborted'); error.name = 'AbortError'; throw error }
      return value
    },
    restartLimit: 3,
    backoffMs: [5, 5, 5],
  })
  t.after(() => runtime.dispose())
  const a = await runtime.ensure()
  const childA = runtime.child
  await runtime.cancel()
  await stopOwnedProcess(childA)
  await new Promise(resolve => setTimeout(resolve, 80))
  assert.notEqual(runtime.status().phase, 'recovering')
  assert.notEqual(runtime.status().phase, 'ready')
  const b = await runtime.ensure()
  assert.equal(runtime.status().phase, 'ready')
  const spawnsBeforeDispose = recorded.filter(item => item.args.includes('tools.managed_runtime')).length
  await runtime.dispose()
  await new Promise(resolve => setTimeout(resolve, 50))
  assert.equal(recorded.filter(item => item.args.includes('tools.managed_runtime')).length, spawnsBeforeDispose)
  await assert.rejects(runtime.ensure(), /removed/)
  assert.notEqual(a.baseUrl, b.baseUrl)
})

test('concurrent ensure starts one process; an old exit leaves the new connection', async t => {
  const { root, artifacts } = await prepared(t)
  t.mock.method(globalThis, 'fetch', async url => {
    if (String(url).includes('/api/health')) {
      return new Response(JSON.stringify({ core_version: 'test-core', contract_version: 1 }), { status: 200, headers: { 'content-type': 'application/json' } })
    }
    return new Response('{}', { status: 404 })
  })
  let port = 18080
  const children = []
  const spawnFn = () => {
    const child = new EventEmitter()
    const current = port++
    child.stdin = new PassThrough()
    child.stdout = new PassThrough()
    child.stderr = new PassThrough()
    child.exitCode = null
    child.signalCode = null
    child.kill = () => { child.exitCode = 1; child.emit('exit', 1, null) }
    child.stdin.once('data', () => child.stdout.write(JSON.stringify({ port: current }) + '\n'))
    children.push(child)
    return child
  }
  const runtime = new ManagedRuntime(root, artifacts, { spawn: spawnFn, delay: async () => undefined, restartLimit: 3, backoffMs: [1] })
  const [one, two] = await Promise.all([runtime.ensure(), runtime.ensure()])
  assert.equal(one.baseUrl, two.baseUrl)
  assert.equal(children.length, 1)
  runtime.connection = undefined
  const next = await runtime.ensure()
  assert.equal(children.length, 2)
  assert.notEqual(next.baseUrl, one.baseUrl)
  children[0].emit('exit', 1, null)
  assert.equal(runtime.status().phase, 'ready')
  assert.equal((await runtime.ensure()).baseUrl, next.baseUrl)
  await runtime.dispose()
})

test('cached connection is health-probed; a zombie backend is torn down and recovered', async t => {
  const { root, artifacts } = await prepared(t)
  let healthy = true
  t.mock.method(globalThis, 'fetch', async url => {
    if (String(url).includes('/api/health')) {
      // Only the first backend turns zombie; the replacement must come up healthy.
      if (!healthy && String(url).includes(':19090')) {
        return new Response(JSON.stringify({ error: 'zombie' }), { status: 502 })
      }
      return new Response(JSON.stringify({ core_version: 'test-core', contract_version: 1 }), { status: 200, headers: { 'content-type': 'application/json' } })
    }
    return new Response('{}', { status: 404 })
  })
  let port = 19090
  const children = []
  const spawnFn = () => {
    const child = new EventEmitter()
    child.stdin = new PassThrough()
    child.stdout = new PassThrough()
    child.stderr = new PassThrough()
    child.exitCode = null
    child.signalCode = null
    child.kill = () => { child.exitCode = 1; child.emit('exit', 1, null) }
    child.stdin.once('data', () => child.stdout.write(JSON.stringify({ port: port++ }) + '\n'))
    children.push(child)
    return child
  }
  const runtime = new ManagedRuntime(root, artifacts, { spawn: spawnFn, delay: async () => undefined, restartLimit: 3, backoffMs: [1] })
  t.after(() => runtime.dispose())
  const first = await runtime.ensure()
  assert.equal(runtime.status().phase, 'ready')
  assert.equal(children.length, 1)
  // Healthy connection is handed out as-is, without spawning anything new.
  assert.equal((await runtime.ensure()).baseUrl, first.baseUrl)
  assert.equal(children.length, 1)
  // Process alive but no longer serving: probe fails, backend is replaced.
  healthy = false
  const second = await runtime.ensure()
  assert.equal(children.length, 2)
  assert.notEqual(second.baseUrl, first.baseUrl)
  assert.equal(runtime.status().phase, 'ready')
  // ... and the recovered connection is usable again.
  healthy = true
  assert.equal((await runtime.ensure()).baseUrl, second.baseUrl)
  assert.equal(children.length, 2)
})

test('backend stderr is mirrored to state/logs/backend.log for postmortem diagnosis', async t => {
  const { root, artifacts } = await prepared(t)
  t.mock.method(globalThis, 'fetch', async url => String(url).includes('/api/health')
    ? new Response(JSON.stringify({ core_version: 'test-core', contract_version: 1 }), { status: 200, headers: { 'content-type': 'application/json' } })
    : new Response('{}', { status: 404 }))
  const spawnFn = () => {
    const child = new EventEmitter()
    child.stdin = new PassThrough()
    child.stdout = new PassThrough()
    child.stderr = new PassThrough()
    child.exitCode = null
    child.signalCode = null
    child.kill = () => { child.exitCode = 1; child.emit('exit', 1, null) }
    child.stdin.once('data', () => child.stdout.write(JSON.stringify({ port: 19191 }) + '\n'))
    return child
  }
  const runtime = new ManagedRuntime(root, artifacts, { spawn: spawnFn, delay: async () => undefined, restartLimit: 3, backoffMs: [1] })
  t.after(() => runtime.dispose())
  await runtime.ensure()
  assert.equal(runtime.status().phase, 'ready')
  const current = runtime.child
  current.stderr.write('embedding probe thread stuck in import numpy\n')
  // The debounced writer flushes within a few hundred milliseconds.
  await new Promise(resolve => setTimeout(resolve, 400))
  const log = await readFile(join(root, 'state', 'logs', 'backend.log'), 'utf8')
  assert.match(log, /embedding probe thread stuck in import numpy/)
})

test('in-flight generate is not replayed when the managed child is recovered', async t => {
  const { root, artifacts } = await prepared(t)
  const log = join(root, 'posts.log')
  await writeFile(log, '')
  const runtime = new ManagedRuntime(root, artifacts, {
    spawn: backendSpawn(t, () => ({ OPENWRITE_POST_LOG: log, OPENWRITE_HANG_WRITE: '1' }), []),
    delay: async (ms, value, options) => {
      if (options?.signal?.aborted) { const error = new Error('aborted'); error.name = 'AbortError'; throw error }
      return value
    },
    backoffMs: [5],
    restartLimit: 3,
  })
  t.after(() => runtime.dispose())
  const connection = await runtime.ensure()
  const hung = fetch(connection.baseUrl + '/api/write', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + connection.token, 'content-type': 'application/json' },
    body: JSON.stringify({ chapter_id: 'ch_1' }),
  })
  const hungFailure = hung.then(() => { throw new Error('in-flight write completed after backend crash') }, error => error)
  await new Promise(resolve => setTimeout(resolve, 40))
  await stopOwnedProcess(runtime.child)
  await waitPhase(runtime, 'ready')
  assert.ok(await hungFailure)
  assert.equal((await readFile(log, 'utf8')).trim().split('\n').filter(Boolean).length, 1)
  assert.match(runtime.status().message, /in-progress writing and review tasks require an explicit retry/)
  assert.doesNotMatch(runtime.status().message, /(?:writing|review) tasks? (?:were |was )?(?:recovered|resumed)/i)
})

test('recovery start failures retry up to the cap without an unhandled rejection', async t => {
  const seen = trackUnhandled(t)
  const { root, artifacts } = await prepared(t)
  const recorded = []
  let backendStarts = 0
  const runtime = new ManagedRuntime(root, artifacts, {
    spawn: backendSpawn(t, () => {
      backendStarts += 1
      // First process stays up. The next two recovery starts fail; later ones succeed until the cap test.
      if (backendStarts === 2 || backendStarts === 3 || backendStarts >= 5) {
        return { OPENWRITE_CRASH: 'during-start', OPENWRITE_EXIT_CODE: '9' }
      }
      return {}
    }, recorded),
    delay: async (ms, value, options) => {
      if (options?.signal?.aborted) { const error = new Error('aborted'); error.name = 'AbortError'; throw error }
      return value
    },
    restartLimit: 4,
    backoffMs: [5, 5, 5, 5],
  })
  t.after(() => runtime.dispose())
  await runtime.ensure()
  assert.equal(backendStarts, 1)
  await stopOwnedProcess(runtime.child)
  await waitPhase(runtime, 'ready')
  assert.ok(backendStarts >= 4, `recovery must retry failed starts, got ${backendStarts} spawns`)
  await new Promise(resolve => setTimeout(resolve, 50))
  assert.equal(seen.length, 0, `unhandledRejection would take down dsh: ${seen.map(String).join('; ')}`)

  await stopOwnedProcess(runtime.child)
  await waitPhase(runtime, 'error')
  await new Promise(resolve => setTimeout(resolve, 50))
  assert.equal(seen.length, 0)
  assert.match(runtime.status().message, /Retry manually/)
  assert.equal(runtime.status().phase, 'error')
})

test('cancel and dispose during recovery wait do not reject unhandled or start a backend', async t => {
  const seen = trackUnhandled(t)
  const { root, artifacts } = await prepared(t)
  const recorded = []
  const runtime = new ManagedRuntime(root, artifacts, {
    spawn: backendSpawn(t, () => ({}), recorded),
    delay: abortableDelay,
    restartLimit: 5,
    backoffMs: [30_000],
  })
  t.after(() => runtime.dispose())
  await runtime.ensure()
  const afterReady = recorded.filter(item => item.args.includes('tools.managed_runtime')).length
  await stopOwnedProcess(runtime.child)
  await waitPhase(runtime, 'recovering')
  assert.equal(recorded.filter(item => item.args.includes('tools.managed_runtime')).length, afterReady)
  await runtime.cancel()
  await new Promise(resolve => setTimeout(resolve, 80))
  assert.equal(runtime.status().phase, 'cancelled')
  assert.equal(recorded.filter(item => item.args.includes('tools.managed_runtime')).length, afterReady)
  assert.equal(seen.length, 0, `cancel leaked unhandledRejection: ${seen.map(String).join('; ')}`)

  const second = new ManagedRuntime(root, artifacts, {
    spawn: backendSpawn(t, () => ({}), recorded),
    delay: abortableDelay,
    restartLimit: 5,
    backoffMs: [30_000],
  })
  t.after(() => second.dispose())
  await second.ensure()
  const beforeDispose = recorded.filter(item => item.args.includes('tools.managed_runtime')).length
  await stopOwnedProcess(second.child)
  await waitPhase(second, 'recovering')
  await second.dispose()
  await new Promise(resolve => setTimeout(resolve, 80))
  assert.equal(second.status().phase, 'uninstalled')
  assert.equal(recorded.filter(item => item.args.includes('tools.managed_runtime')).length, beforeDispose)
  assert.equal(seen.length, 0, `dispose leaked unhandledRejection: ${seen.map(String).join('; ')}`)
})

