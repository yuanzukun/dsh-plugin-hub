import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { novelEffect, novelPolicyDenial } from '../lib/tool-policy.js'
import { registerNovelTools, workspaceContextFromExec } from '../lib/tools.js'
import { StudioClient, StudioError } from '../lib/client.js'

test('every registered novel tool has a conservative effect; mixed actions do not inherit read access', () => {
  const tools = []
  registerNovelTools({ tools: { register: tool => tools.push(tool) } }, () => { throw new Error('No API call allowed') }, { timeoutMs: 1000, outputDir: '/unused' })
  assert.equal(tools.length, 90)
  for (const tool of tools) assert.ok(['read', 'write', 'generate'].includes(novelEffect(tool.name, {})))
  assert.equal(novelEffect('novel_model_benchmark', { action: 'get' }), 'read')
  assert.equal(novelEffect('novel_model_benchmark', { action: 'run' }), 'generate')
  assert.equal(novelEffect('novel_document_change_plan', { action: 'preview' }), 'write')
  assert.equal(novelEffect('novel_reference_library_action', { action: 'import' }), 'write')
  assert.equal(novelEffect('novel_unknown_future_action', { action: 'read' }), 'write')
  assert.equal(novelEffect('novel_manuscript_acceptance', {}), 'read')
  assert.equal(novelEffect('novel_export_preflight', {}), 'read')
  assert.equal(novelEffect('novel_export', {}), 'write')
  assert.equal(novelEffect('novel_task_retry', {}), 'generate')
  assert.equal(novelEffect('novel_task_cancel', {}), 'write')
})

test('host write policy and plan state independently gate generation and changes', () => {
  for (const mode of ['read-only', 'workspace-write']) for (const active of [true, false]) {
    const ctx = { get: name => name === 'sandboxPolicy' ? { resolve: () => ({ mode }) } : undefined }
    const agent = { ctx: { get: () => ({ get: () => ({ active }) }) }, session: {} }
    const denied = mode === 'read-only' || active
    for (const name of ['novel_doc_write', 'novel_write_chapter', 'novel_revision_apply']) {
      assert.equal(Boolean(novelPolicyDenial(ctx, { name, agent, arguments: {} })), denied)
    }
    assert.equal(novelPolicyDenial(ctx, { name: 'novel_doc_read', agent, arguments: {} }), undefined)
  }
  assert.match(novelPolicyDenial({ get: () => undefined }, { name: 'novel_doc_write', arguments: {} }), /POLICY_REQUIRED/)
  assert.match(novelPolicyDenial({ get: () => undefined }, { name: 'novel_doc_write', agent: { ctx: { get: () => undefined }, session: {} }, arguments: {} }), /READ_ONLY/)
})

test('real dsh tool registry isolates 90 tools by preset and disposes them', async () => {
  const { Context } = await import('@deepseek-ai/cordis')
  const { ToolRuntime } = await import('@deepseek-ai/dsh-tools')
  const { createScope } = await import('@deepseek-ai/dsh-scope')
  const preset = await import('../lib/preset-tools.js')
  const root = new Context()
  let wireSchemas
  const sections = []
  root.provide('systemPrompt', { tools: provider => { wireSchemas = provider; return () => {} }, section: value => { sections.push(value); return () => {} }, getSectionOrder: () => 0 })
  root.provide('novelDomain', { toolOptions: { timeoutMs: 600_000 }, clientFactory: () => () => { throw new Error('No backend calls in catalog inspection') } })
  await root.plugin(ToolRuntime)
  const writing = {}, normal = {}
  const scope = createScope(root, writing)
  try {
    await scope.ctx.plugin(preset)
    assert.equal(root.tools.schemas().filter(tool => tool.name.startsWith('novel_')).length, 0)
    assert.equal(root.tools.schemas(normal).filter(tool => tool.name.startsWith('novel_')).length, 0)
    Object.assign(writing, { ctx: scope.ctx, session: {} })
    const denied = await root.tools.execute({ callId: 'policy-denied', name: 'novel_doc_write', arguments: {}, agent: writing, signal: new AbortController().signal })
    assert.equal(denied.isError, true)
    assert.match(JSON.stringify(denied), /OPENWRITE_READ_ONLY/)
    const tools = root.tools.schemas(writing)
    assert.equal(tools.filter(tool => tool.name.startsWith('novel_')).length, 90)
    console.log(JSON.stringify({ measurement: 'native-tool-schema', tools: tools.length, utf8Bytes: Buffer.byteLength(JSON.stringify(tools)), tokenizer: 'not-measured' }))
    root.provide('codeRuntime', { language: 'typescript' })
    const ptcAgent = {}
    const ptcScope = createScope(root, ptcAgent)
    try {
      await ptcScope.ctx.plugin(preset, { presentation: 'ptc' })
      assert.deepEqual(wireSchemas({ scope: ptcAgent }).schemas.map(tool => tool.name), ['run_code'])
      assert.equal(root.tools.schemas(writing).length, 90, 'PTC must not change another preset')
      const sdk = sections.find(value => value.name === 'tools:sdk').text({ scope: ptcAgent })
      assert.ok(sdk.includes('novel_doc_read'))
      console.log(JSON.stringify({ measurement: 'ptc-presentation', schemaBytes: Buffer.byteLength(JSON.stringify(wireSchemas({ scope: ptcAgent }).schemas)), sdkBytes: Buffer.byteLength(sdk), tokenizer: 'not-measured' }))
    } finally { await ptcScope.dispose() }
    await scope.dispose()
    assert.equal(root.tools.schemas(writing).length, 0)
  } finally { await root.fiber.dispose() }
})

test('workspace context fails closed for missing, relative, and unknown roots', async () => {
  const exec = header => workspaceContextFromExec({ name: 'novel_doc_read', callId: 'c1', agent: { session: { header } } })
  assert.throws(() => exec({}), error => error.code === 'WORKSPACE_CONTEXT_MISSING')
  assert.throws(() => exec({ cwd: '' }), error => error.code === 'WORKSPACE_CONTEXT_MISSING')
  assert.throws(() => exec({ cwd: 'relative/path' }), error => error.code === 'WORKSPACE_ROOT_INVALID' && error.details.reason === 'not_absolute')
  assert.throws(() => exec({ cwd: '/definitely-not-an-openwrite-workspace-root' }), error => error.code === 'WORKSPACE_ROOT_INVALID' && error.details.reason === 'not_found')
})

test('stale revision is returned as CONFLICT and does not look like success', async t => {
  const workspace = await mkdtemp(join(tmpdir(), 'openwrite-policy-ws-'))
  t.after(() => rm(workspace, { recursive: true, force: true }))
  t.mock.method(globalThis, 'fetch', async () => new Response(JSON.stringify({ error: 'revision changed', code: 'CONFLICT' }), {
    status: 409, headers: { 'content-type': 'application/json' },
  }))
  const client = new StudioClient({ baseUrl: 'http://127.0.0.1:9', timeoutMs: 1_000 }).scoped({ workspaceRoot: workspace })
  const tools = []
  registerNovelTools({ tools: { register: tool => tools.push(tool) } }, () => client, { timeoutMs: 1_000, outputDir: join(workspace, 'out') })
  const exec = { signal: new AbortController().signal, name: 'novel_outline_edit', callId: 'c1', agent: { session: { header: { cwd: workspace } } } }
  await assert.rejects(
    () => tools.find(tool => tool.name === 'novel_outline_edit').execute({ operation: 'rename', revision: 'stale-rev' }, exec),
    error => error instanceof StudioError && error.status === 409 && error.code === 'CONFLICT',
  )
})
