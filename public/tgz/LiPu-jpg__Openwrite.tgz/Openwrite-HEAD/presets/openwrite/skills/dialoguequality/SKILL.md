---
name: dialoguequality
description: Use when user wants to analyze dialogue style, extract speech patterns, compare character voices, or detect AI-sounding dialogue. Triggers include "对话", "口头禅", "角色声音", "对白", "AI味对话".
user-invocable: false
---

Language: follow the author's current conversation language for responses and help; preserve the manuscript language. Translate these instructions when presenting them.

# 对话质量系统

用于分析角色对白、提取说话习惯、检查角色声音是否区分明显，以及识别 AI 味对话问题。

## 当前数据来源

对话分析不要只盯着对白片段本身。当前推荐读取顺序是：

1. `data/manuscript/arc_*/ch_*.md` — 实际章节正文
2. `src/characters/*.md` — 角色单源文档
3. `data/style/composed.md` — 当前作品风格约束
4. `src/outline.md` / canonical packet — 本章戏剧位置与章节目标

如果需要完整判断某章对白是否失真，优先结合 `novel_review_chapter` 或 `novel_chapter_work` 的章节 packet，而不是只看几行台词。

## 可用工具

| 工具 | 说明 |
|------|------|
| `novel_manuscript_metrics(chapter_id=…)` | 章节可量化信号：字数、句长、对白占比等 |
| `novel_review_chapter(chapter_id=…, domains=["prose","character"])` | 对整章做审查，可发现台词失真、解释性对话、套路对白 |
| `novel_chapter_work(chapter_id=…)` | 章节工作 brief：戏剧位置、出场角色、章节目标 |

## 什么时候用

- 角色说话越来越像同一个人
- 想提取某角色口头禅、句长、问句比例
- 怀疑一段对白太工整、太礼貌、太像 AI 写的
- 想比较两个角色的声音有没有拉开

## 工作方式

### 1. 读取章节信号

先定位章节，再读可量化指标：

```text
用户: 分析一下林月在第六章的对话风格

AI: 调用 novel_manuscript_metrics(chapter_id="ch_006")
```

重点观察返回里的：

- 字数与对白占比：这一章是谁在说话
- 句长相关指标：偏短还是偏长
- 出场角色：林月是否真的有戏份

没有工具会直接给出"对白指纹"；上面的指标加上正文摘录就是判断依据。
需要整章判断时再调用 `novel_review_chapter(chapter_id="ch_006", domains=["prose","character"])`。

### 2. 结合角色档案复核

提取完后，要对照 `src/characters/*.md`：

- 角色身份是否和说话方式一致
- 是否符合性格、教育程度、职业背景
- 是否保留了角色特有的回避方式、攻击方式、冷幽默或停顿习惯

### 3. 识别 AI 味对白

重点查这些问题：

#### 过度礼貌

- 普通熟人反复说“请”“劳烦”“阁下”
- 同事或熟人之间说话像正式公文

#### 解释性对话

- A 向 B 解释 B 本来就知道的事
- 台词承担“给读者讲设定”的任务，而不是人物交流

#### 完美逻辑

- 每句话都有正面回应
- 没有打断、沉默、敷衍、转移话题
- 像在辩论，不像在说话

#### 套路表达

- “受教了”“所言极是”“你说得对”
- “我很生气”“我很震惊”这类直接把情绪说出来
- “嘴角微微上扬”“眼中闪过一丝”这类套路型动作标签

#### 角色同声化

- 不同角色句长接近
- 用词层次相同
- 职位、年龄、教育背景、社交方式没有反映在对白里

## 检查清单

### 角色声音

- 主角是否有稳定的思维口癖
- 配角是否有可识别的用词边界
- 高压状态下的说话方式是否会变化

### 对话结构

- 是否有人答非所问
- 是否有停顿、省略、打断
- 是否存在大量“解释给读者听”的台词

### 风格一致性

- 是否符合 `data/style/composed.md`
- 是否符合章节当前戏剧位置
- 是否和上一章衔接自然

## 输出建议格式

```text
对话检查结果：ch_006 / 林月

1. 角色声音
- 句长偏短，命令句比例高，符合技术组长的控制型表达
- 高频表达偏直接，几乎不解释理由，角色识别度高

2. 问题
- 第 3 段存在解释性对话，林月不该向熟悉项目的人完整解释背景
- 第 6 段礼貌度偏高，不像她一贯说话方式

3. 修改建议
- 删掉完整解释，改成一句结论 + 一个动作
- 把“请你尽快处理”改成“今天收掉”
```

## 示例

### 示例 1：识别解释性对话

```text
❌
"你也知道，我们项目组最近一直在做那套老系统重构，所以今天才会出这种问题。"

✅
"老系统又炸了。"
```

原因：后者更像熟人之间的真实说话方式，信息由上下文承担，不靠台词硬讲。

### 示例 2：识别角色同声化

```text
❌ 陈明 / 林月 / 赵磊都用类似的完整句式解释问题

✅
陈明：偏技术比喻、偏自嘲
林月：短句、结论先行
赵磊：口语化、插科打诨
```

## 注意

- `novel_manuscript_metrics` 提供可量化信号，判断"说话指纹"要靠它加上正文摘录
- `novel_review_chapter` 适合看“对白放在整章里是否成立”
- 真要改对白，必须结合人物文档和章节戏剧位置一起判断
