---
name: foreshadowing-system
description: Use when user wants to manage foreshadowing (伏笔), track story hooks, or check pending reveals. Triggers include "伏笔", "埋伏笔", "待回收", "伏笔状态".
user-invocable: false
---

Language: follow the author's current conversation language for responses and help; preserve the manuscript language. Translate these instructions when presenting them.

# 伏笔管理系统

管理小说中的伏笔和悬念，确保故事线索连贯。

## 核心概念

伏笔（foreshadowing）是作者在前面章节埋下的线索，后面再回收。

**伏笔状态**：
- `埋伏` - 已埋下，等待回收
- `待收` - 即将回收
- `已收` - 已回收
- `废弃` - 放弃的伏笔

**伏笔层级**：
- `主线` - 核心剧情伏笔
- `支线` - 次要剧情伏笔
- `彩蛋` - 趣味小彩蛋

## 可用工具

| 工具 | 说明 |
|------|------|
| `novel_foreshadowing(action="create")` | 创建伏笔节点（仅作者本轮已授权该精确变更时的一次性写入） |
| `novel_foreshadowing(action="update")` | 更新伏笔状态 |
| `novel_change_plan(action="structured", change_kind="foreshadowing", step="preview"/"apply")` | 伏笔 DAG 的逐项预览/确认维护（**默认路径**） |
| `novel_continuity` | 未回收伏笔、人物状态漂移、时间线一致性报告 |

## 使用示例

### 创建伏笔

```
用户: 在第三章埋一个伏笔，关于主角的神秘身世

AI: 好的，伏笔 DAG 的维护走变更计划两阶段确认。
先 `novel_change_plan(action="structured", change_kind="foreshadowing", step="preview", change={…})`，
把 diff 展示给作者；作者确认后才 `step="apply"` 并传回 `preview_token`。
仅当作者在本轮已明确授权这条精确变更时，才可用直接入口
`novel_foreshadowing(action="create", node_id="f001", content="主角发现自己体内有一道封印的神秘力量", weight=9, layer="主线", target_chapter="ch_015")`。

结果: ✅ 伏笔已创建
- ID: f001
- 内容: 主角发现自己体内有一道封印的神秘力量
- 权重: 9
- 层级: 主线
- 预期回收: 第15章
```

### 查看待回收伏笔

```
用户: 有哪些待回收的伏笔？

AI: 让我读一下连续性报告……
调用 `novel_continuity`（无参数，项目级）。

结果:
- f001: 主角身世之谜 (权重9, 主线)
- f003: 师父的秘密 (权重7, 主线)
- f005: 神秘玉佩 (权重6, 支线)
```

### 更新伏笔状态

```
用户: 第八章回收了 f003 的伏笔，更新状态

AI: 同样走两阶段确认：`novel_change_plan(action="structured", change_kind="foreshadowing", step="preview", change={…})`
→ 展示 → `step="apply"`。作者本轮已授权时可用
`novel_foreshadowing(action="update", node_id="f003", status="paid-off")`。

结果: ✅ f003 状态已更新为「已收」
```

### 验证伏笔DAG

```
用户: 检查伏笔有没有问题

AI: 让我读一下连续性报告……
调用 `novel_continuity`（无参数，项目级）。

结果:
- ✅ DAG有效，无环
- ✅ 无孤立引用
- ⚠️  提示: 有3个伏笔超期未收
```

## 创建伏笔的时机

在写作时，AI 应该主动识别并建议创建伏笔：

1. **建立悬念时** - "主角做了一个奇怪的梦..."
2. **引入神秘元素时** - "某个配角的来历不明..."
3. **埋下线索时** - "桌上放着一封未拆的信..."
4. **暗示未来事件时** - "天气预报说三天后会下大雨..."

## 伏笔设计原则

1. **可识别性** - 伏笔要能被读者注意到
2. **合理性** - 回收时要有合理的解释
3. **权重分配** - 重要伏笔高权重，主线权重≥7
4. **时机控制** - 埋设和回收之间要有足够铺垫

## DAG验证规则

1. **无环** - 伏笔之间不能循环依赖
2. **有向** - 边必须从伏笔指向回收点
3. **可达** - 每个待收伏笔必须有明确的回收章节
