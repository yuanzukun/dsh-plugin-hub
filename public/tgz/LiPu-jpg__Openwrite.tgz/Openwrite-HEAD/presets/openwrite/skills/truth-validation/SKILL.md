---
name: truth-validation
description: Use when user wants to validate story consistency, check for plot holes, or verify state changes. Triggers include "验证", "一致性", "检查逻辑", "状态冲突".
user-invocable: false
---

Language: follow the author's current conversation language for responses and help; preserve the manuscript language. Translate these instructions when presenting them.

# 真相文件验证系统

验证真相文件与章节内容的一致性，确保故事逻辑连贯。

## 核心概念

真相文件是记录世界当前状态的 Markdown 文件，包括：
- `current_state.md` - 世界当前状态
- `ledger.md` - 资源账本
- `relationships.md` - 角色关系矩阵

相关运行时文件（用于一致性校验）：
- `data/foreshadowing/dag.yaml` - 伏笔状态
- `data/hierarchy.yaml` 与 `data/compressed/` - 章节摘要与压缩信息

## 验证问题类型

| 严重程度 | 类型 | 说明 |
|---------|------|------|
| critical | 状态矛盾 | 章节内容与真相文件矛盾 |
| critical | 时间悖论 | 时间线出现矛盾 |
| warning | 叙事缺失 | 状态变化没有叙事支持 |
| warning | 伏笔异常 | 伏笔未回收就消失 |
| info | 回溯编辑 | 暗示状态变化发生在前章 |

## 可用工具

| 工具 | 说明 |
|------|------|
| `validate_truth` | 验证真相文件与章节的一致性 |

## 使用示例

### 验证最新章节

```
用户: 检查一下最新章节有没有问题

AI: 让我验证一下...
[COMMAND] validate_truth {
  "chapter_id": "latest"
}

结果:
- ✅ 状态矛盾: 无
- ✅ 时间悖论: 无
- ⚠️  叙事缺失: 1个
  - 主角境界从筑基初期跳到筑基中期，但章节中没有突破描写
- ✅ 伏笔异常: 无
- ✅ 回溯编辑: 无

建议: 在第5章添加主角修炼的过渡场景
```

### 验证指定章节

```
用户: 第3章有没有逻辑问题？

AI:
[COMMAND] validate_truth {
  "chapter_id": "ch_003"
}

结果:
- ❌ 状态矛盾: 1个
  - 真相文件记录主角在青河镇，但章节中主角出现在青云宗
- ✅ 时间悖论: 无
- ⚠️  叙事缺失: 2个
...
```

## 常见问题及修复

### 1. 状态矛盾

**问题**: 真相文件说主角在A地，但章节中主角在B地

**修复**: 
- 检查是否是穿越/传送情节
- 如果是，更新真相文件中的位置
- 如果不是，修复章节内容

### 2. 时间悖论

**问题**: 章节说"三天后"，但上一章到这章只过了一天

**修复**:
- 添加过渡段落说明时间流逝
- 或者修正天数

### 3. 叙事缺失

**问题**: 真相文件记录主角境界提升，但章节中没有描写

**修复**:
- 添加修炼/突破的场景
- 或者回退真相文件中的状态

## 验证时机

建议在以下时机进行验证：
1. 写完章节后
2. 审查章节前
3. 重大剧情转折前
4. 发现逻辑问题时

## 与伏笔系统的关系

验证系统会检查：
- 待回收伏笔是否在预期章节被回收
- 已埋伏笔是否在章节中得到呼应
- 是否有伏笔未声明就被回收
