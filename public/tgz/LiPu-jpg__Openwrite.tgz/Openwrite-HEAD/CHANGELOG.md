# Changelog

## 0.2.19

- 修复部分安装（pnpm 隔离布局）下「OpenWrite 创作」预设从 agent 预设列表消失、DoG 工具不可用：vendor/dsh-dog 运行时不再裸导入 `@deepseek-ai/dsh-home-paths` 与 `@deepseek-ai/dsh-tools` 两个 peer 宿主包（在该布局下从 vendor 目录不可解析，导致 openwrite-dog 条目导入失败、`openwriteDog` 服务未注册、预设不注册），`dshHomePath` 与 `defineTool` 改为插件内自包含实现，升级/重装后无需再手动补 junction（[#74](https://github.com/LiPu-jpg/Openwrite/issues/74)）。
- 修复 `novel_*` 工具的对象/数组类参数：模型把 `edits`/`change`/`data` 等 `type: 'json'` 参数输出为 JSON 字符串时，插件在校验前先做 `JSON.parse` 归一化，change-plan 预览/确认门控与 asset `data` 字段恢复可用；参数无法解析或类型不符时报错文案带参数名与实际类型（[#75](https://github.com/LiPu-jpg/Openwrite/issues/75)）。

## 0.2.18

- 修正 0.2.17 的 `auto:cheapest`：零价模型（不限于 `:free` 后缀，如 OpenRouter 上定价 0/0 的模型）不再参与比价，自动落到付费低价模型上——免费模型可用性不稳定，低价策略不应选中它们（Core 5.8.9）。

## 0.2.17

- 模型档案新增自动选模：把档案的模型名写成 `auto:cheapest` 或 `auto:popular` 即可。`auto:cheapest` 在每次解析档案时实时拉取服务商的 `/models` 价格目录（缓存一小时），按"文本对话、上下文 ≥32K、最大输出 ≥4K"过滤并排除 `:free`/`:batch`/动态定价条目，自动选用 prompt+completion 总价最低的模型，价格变动会自动跟随；`auto:popular`（OpenRouter）直接路由到官方 `openrouter/auto`，由社区实际用量自动挑选模型。解析结果记录在 `auto_select` 字段里便于溯源，目录拉取失败自动回退到缓存，静态模型档案不受影响（Core 5.8.8）。

## 0.2.16

- 补漏 #64/#67：字数精简重试耗尽后保留下来的草稿，其 `length_out_of_range`/`length_warning` 标记与后置校验问题（`validation_issues`）现在会持久化进草稿产物（Core 5.8.7）。此前 0.2.15 只覆盖了运行内存态：产物文件里这两个标记为空，导出/审阅侧无法追溯该章曾发生字数越界。

## 0.2.15

- 修复 #63/#66：Windows 上残留 `project.lock` 不再永久阻断写章/审稿。Core 5.8.6 用 Windows 正确的进程存活探测（`OpenProcess`/`GetExitCodeProcess`）替换 POSIX 语义的 `os.kill(pid, 0)`（在 Windows 上它会抛 `OSError [WinError 87]` 且未被捕获），死进程持有的残留锁自动判陈旧并清理；无法验证存活时按"初始化宽限后视为陈旧"兜底。锁被占用时的报错现在带上占用者 operation、pid、起始时间与锁文件路径，不再显示误导性的 `[WinError 87] 参数错误`；写章/审稿的阶段标签改由流水线在真正进入生成时上报，文件锁失败不再被误报为"模型生成失败"。
- 修复 #64/#67：`continuous_write` 单章失败不再整队终止。`max_failures` 连续失败上限按字面语义生效——未达上限时记录该章失败并继续下一章，达到上限才优雅返回 `max_failures_reached`；任务取消仍会立即中止。字数精简重试耗尽后不再丢弃已完成初稿：最后一版正文标记 `length_out_of_range` 保留为草稿（附字数告警），导出前可人工去水或分章。
- 修复 #68：「模型横评」运行期间详情接口不再恒 400。产物契约 `model_benchmark_v1` 的 `status` 枚举补齐实时态 `running`/`cancelling` 与终态 `cancelled`，进行中的记录与已取消的记录都可以正常读取。
- 修复 #69：推理模型评审不再因输出预算地板锁死 4096 而全域 `MODEL_OUTPUT_TRUNCATED`。Core 5.8.6 在 usage 中观察到思维链（reasoning tokens）后把评审输出预算地板抬到 16384，安全门同享；截断后先按翻倍预算原批重试一次，仍失败才二分，且二分不再沿用旧地板。
- #65 部分落地：README 说明界面语言切换（Settings → General → Language，面板已内置英文词典）；Agent persona 增加语言跟随约定（始终用用户对话语言回复）。英文版 persona/skills 与后端信息英文化留待后续版本。

## 0.2.14

- 修复 #60：桥接层转发前消毒 `NO_PROXY`/`no_proxy`（剥掉会令 httpx 构造即失败的 `[::1]` 类带括号 IPv6 字面量），系统代理场景下模型连接测试不再误报"服务商拒绝了请求"；Core 5.8.5 把 httpx 构造期异常归类为本地配置错误（HTTP 412）。`Studio request failed` 附带底层 `error.cause` 便于诊断。
- 修复 #61：Core 5.8.5 启动时预热 numpy/fastembed 重依赖（请求线程里首次 import 会在 Windows 模块加载器里永久卡死），`run_embedding_probe()` 增加硬超时，收尾阶段限时 10 秒、超时强制退出，杜绝"活着但不服务"的僵尸后端；桥接层复用就绪连接前做带超时的健康探活，子进程 stderr 落盘 `state/logs/backend.log`（末尾 64 KiB）可事后取证。

## 0.2.13

- 修复 #57：浏览器代理和 Agent 客户端只在实际写操作成功后通知数据变更，批注与版本读取不再触发自维持刷新循环。
- Core 升至 5.8.4：HTTP action 契约声明查询/预览语义，通过 `X-OpenWrite-Mutated` 告知桥接层；只读请求不再递增工作区 `context_epoch`。旧 Core 的批注/版本查询保留兼容分类。
- 批注 effect 使用正文与修订事件刷新，不再响应无关的 workspace 失效；等待真实修改的读取结果时保留批注，切换作品或章节时清空旧批注并忽略迟到响应。
- 正文编辑动作按 manuscript 通知，确保保存、批注、版本恢复仍会触发界面刷新。

## 0.2.12

- 修复 #50–#52：DSH 0.2 按版本 ID 注册 OpenWrite 预设，技能使用包内绝对路径；0.1 保留目录发现和工作流实现。
- 会话导航适配 `uiWorkspace.openSession`，工作台按主视图持有的会话挂载，进入作品后等待投影就绪再激活创作视图。客户端基础修法来自 PR #53。
- DoG 适配条目配置与主视图导航，不再调用已移除的 settings/catalog 接口或等待不存在的 `current` 字段；补齐 Connection 声明上下文的 Web 依赖，让调试面板真正读取数据。
- 修复 #54：连续审读按章节内容签名刷新，保留正文与滚动 DOM；真实修订变化或手动刷新仍重新取正文。
- Core 升至 5.8.3 / contract 1：模型连接测试使用配置的输出预算，避免 32-token 上限耗尽推理额度；补充托管配置目录说明。
- 客户端验收覆盖预设选择、会话导航及三个工作台页签实际出现、点击创作后工作台可操作及 DoG 真实数据响应；修正 Windows smoke 的 ESM 文件 URL。Windows Electron 原生恢复仍须实机复测。

## 0.2.11

- 修复 #45：根包及内嵌子包的兼容声明覆盖精确宿主 `0.2.0-rc.2`，保留 `0.1.2-rc.1` / `0.1.5-alpha.1`。
- 工作台适配 turn-tail list 槽位，DoG 适配 `sessionStatus`；客户端初始化失败会回滚部分注册并输出可读错误。
- 补充旧包子包授权与 profile 备份恢复说明。Windows Electron 桌面端恢复链路尚未实机复测。
- 包含 #44 的 minimap CSS 修复。Core 仍为 5.8.2 / contract 1。

## 0.2.7

- 未解决批注显示在正文上方的「作者选区批注」条，点击即可定位。
- 正文里的批注颜色和下划线加重，避免几乎看不见。
- 「修订」页签在有未解决批注时显示数量。

## 0.2.6

- 批注输入框可以点击和输入；不再被选区保护的 `preventDefault` 挡住焦点。

## 0.2.5

- 覆盖层按整段 IR 文本定位，粗体/拆节点的引文和 `//**…**` 标记也能画中。
- 正文滚动或窗口缩放后重新对齐覆盖层，不再停在第一次绘制的位置。
- 「定位」会选中并滚到原文，而不只改侧栏状态。

## 0.2.4

- 创作工作台支持选区批注：保存后绑定范围，重复引文不取第一处；未保存先保存再核对。
- 批注使用固定颜色，旧记录缺颜色时显示琥珀；覆盖层不写入 Markdown。
- 可插入人物状态变化和指向关系两种内部标记；同名人物需明确选择。有效标记不计入字数和默认导出。
- Core 5.8.1：批注记录增加可选 `color`。不回退 0.2.3 的迁移、环境允许列表和自动恢复。

## 0.2.3

- 受管理后端自动恢复失败不再把未处理 Promise 抛给宿主；dsh 保持运行。
- 恢复过程中的启动失败按同一上限继续退避重试，而不是只试一次。
- 恢复等待期间取消或卸载不产生未处理错误，也不会再拉起后端。

## 0.2.2

- 旧安装迁移同时处理 bundle 登记和 `dependencies`，通过宿主 `dsh plugin remove` 删除 `@dsh-novel/openwrite-bridge`、`@dsh-novel/studio-panel`、`@dsh-external/dsh-dog`；备份失败可恢复，不改用户 `node_modules` 源码，不删除作者预设。
- 受管理后端异常退出后有限次退避自动恢复；取消、卸载和宿主退出不复活。恢复不重放付费请求。
- Python / uv 子进程改为允许列表环境，不再整包继承 `process.env`。
- 补齐 leftover-deps、自动恢复、环境允许列表、Workspace/revision/未认证策略的回归测试。真实模型费用测量未执行。

## 2026-08-23 - dsh 原生创作工作台

- OpenWrite 改为无界面领域后端；`NovelDomainService` 统一工具、同源 API 代理和轻量 revision 失效流。
- 顶层插件视图收敛为「创作 / 资料 / 任务」，默认工作流彻底移除 iframe 与重复导航。
- 新增原生 Vditor 正文编辑器：1.2 秒自动保存、version 乐观锁、409 草稿保护、显式覆盖。
- 新增共享 `NovelWorkbenchStore`、会话头作品状态、输入章节上下文、Turn 写操作汇总。
- 44 个常用工具归入八类原生卡片；大纲默认只展开当前章节路径。
- Vditor 主运行时随插件打包，辅助资源由 dsh 同源提供；增加原生路由、无 iframe 与多工作台 smoke 门禁。

## 未发布

- 安装器默认从 `Fun10165/dsh-dog` 获取固定的 `v1.2.0`，原子安装到
  `$DSH_HOME/extensions/dsh-dog`，构建后只挂载 web profile；已有安装可复用，也可用
  `DSH_DOG_DIR` 指向开发工作树或用 `DSH_DOG_AUTO_INSTALL=0` 跳过。获取失败会在清理
  临时目录后尝试禁用 Git HTTP(S) 代理直连；DoG 以当前会话 Workspace 为图根，静态
  `dog.workspaceRoot` 只作兜底，切换作品不再需要改配置或重启。
- 评审体系升级为 review v2：原 37 项恰好映射到六个计分域和一个硬门禁，使用有正文
  证据才得分的累加机制；`quality_score`、`coverage`、`gate_status`、
  `delivery_status` 分离，issue 不再直接扣分，severity 与 `revision_priority` 独立。
- 评审 DoG 改为 47 节点分层图（上下文、六域、门禁、确定性聚合、37 个 legacy leaf），
  全部使用程序 verifier；交付图扩为
  `writing → review → revision → application → rereview → closure` 六阶段。
- 「图谱」新增 React Flow + ELK 的评审/交付 DAG，可选章节、筛选异常/blocker、折叠六域、
  展开 37 项并查看 score/coverage/evidence/issue/provenance；Studio 新增只读
  `GET /api/dog/graphs`，不会运行 verifier 或模型。
- 新增框架内模型测试台与第 63 个工具 `novel_model_benchmark`：通过 OpenWrite profile
  和 LiteLLM-compatible gateway 固定上下文 hash，隔离运行多写作模型 × 独立评审模型，
  artifact 写入 `data/novels/{id}/data/benchmarks/`，不修改全局路由或正式正文。
- 模型测试默认进入 OpenWrite 公共生产写章与评审管线；每个候选/重复轮次使用完整作品
  沙箱并保留 Chapter Run V2、记忆、工作流与提交证据。裸 `_creative_write` 路径仅作为
  显式 `creative` 诊断模式。
- 框架内候选失败现在也保留公共入口、Run V2 ID、阶段状态、失败阶段与安全错误码；未完成
  `commit` 的可靠性失败不会进入评审或获得质量分，旧 artifact 在 UI 中仍按执行模式显示
  正确入口。
- 模型测试统一归一 OpenRouter/OpenAI-compatible/LiteLLM 的 token 与实际费用，汇总输入、
  输出、推理用量和费用覆盖率；明确免费的 `$0` 与未知费用分开显示，并提供本次调用的综合
  有效价 `/ 1M tokens`，不冒充模型目录单价。
- 审稿卡和任务列表优先显示 v2 质量分、覆盖率、门禁/交付状态，并分别展示
  `critical/warning/info` 评审严重度与 `blocker/high/medium/low` 修订优先级。
- 新增 DAG/benchmark HTTP 生命周期测试、bridge tool/proxy smoke、Python/TypeScript
  parity/无环/stale 测试，以及优质/当前/故障三类合成 golden fixtures 与 v1/v2 双轨校准。

- dsh-dog 进一步融合：同步评审、conductor 与后台 `chapter_review` 任务统一物化
  分层评审查询图（保留 `1..37` legacy leaf）；修正维度参数为 OpenWrite 要求的
  `1..37` 整数数组并加入阈值校验。
- 新增章节交付总图：以正文 SHA、评审 `source_revision`、修订提案状态和复评结果
  串联 `writing → review → revision → application → rereview → closure`；应用修订后强制进入待复评，
  只有当前正文复评通过才标记 `readyForDelivery`。同步工具、后台任务和 conductor
  均会刷新交付快照，并新增 `dog-delivery-query` 技能。
- 修复智能导入的 DOCX/EPUB 二进制文件被提前文本解码、空任务项目无法解析
  `novel_id` 的问题；补齐导入格式依赖和 DoG 契约测试（含真实 dsh-dog 图校验）。

- 「审稿」tab 并入「写作」（原总览）三分段：总览 ⇄ 正文 ⇄ 审稿，Studio iframe
  三合一；tab 总数 10 → 9，标签更名「写作」
- 搜索 tab 点击即读：结果行可点击，内联预览经 GET /api/document 取全文，
  命中行 ±2 行带行号高亮，返回钮回列表——查到的资料不再需要跳去别处看
- 任务 tab 补管理闭环：行悬停 取消（pending/running/awaiting_confirmation，
  confirm 门）与 重试（failed 且 recoverable）按钮，走 host 代理新增的模式
  白名单 `tasks/{id}/cancel|retry`
- 任务 tab 评审结果可见化：完成的 chapter_review 行内嵌分数徽章（分档着色），
  点击展开问题清单（severity 着色 + 维度 + 摘要，≤10 条）——conductor 经 HTTP
  跑的评审与 agent 工具跑的同样可见
- 设计令牌归一：本轮新增样式全部映射回平台既有词汇，清除自造令牌
- conductor 新增 dsh 原生深度研究路线（`research.py`）：headless 会话用平台
  自带 web_search 联网调研并综合成报告，落库 OpenWrite 报告目录（研究 tab
  直接可见）——绕开博查 Key 依赖，零额外凭据；实测两份真实报告入库
- 研究 tab 补「发起研究」：问题输入 → type=research 托管任务（进度在任务 tab，
  可恢复错误如搜索凭据缺失原样透传）；host 白名单增补 `tasks` 写路径
  （修复研究提交被代理 405 拦截的遗漏）
- 「总览」「正文」两个 tab 合并为一个「总览」：原生工具箱条 + 分段切换
  （总览 ⇄ 正文），单一 Studio iframe 经 hash 片段导航切换（不整页重载，
  编辑器状态保留）；tab 总数 11 → 10
- 总览 tab 原生工具箱条：导出 md/txt/epub（经代理二进制安全下载）、同步项目、
  导入章节（文件选择 → 预览切章计划/冲突 → 确认/强制覆盖）——补齐 Studio
  「工具与设置」抽屉在 dsh 侧最后一个无 UI 缺口；代理改二进制安全透传并放宽超时至 60s，
  写白名单增补 sync / import/preview / import
- conductor 落地（`conductor/`）：无人值守写章流水线——写章/评审/修订回炉全部
  走 OpenWrite 后台任务系统（phase 轮询、预算超时显式取消、recoverable 原生
  retry），回炉经 revision_from_review → regenerate → apply 修订闭环（含客户端
  锚点预过滤）；可选 --agent-guidance 用 dsh SDK bundled 会话综合改写指导。
  同步端点 /api/write、/api/review 因孤儿化服务端任务被弃用于编排路径
- 新增 --review-only（对成稿章节只跑评审门）；实测 ch_001~004 全流程，
  ch_003 修订回炉 0 → 35 分
- 根目录 `skills/` 移除：技能唯一来源是 `presets/*/skills/`（内容相同，根副本无任何引用）
- `scripts/verify.sh` / `dev.sh` 导出 `NO_PROXY`：系统代理指向本机时
  （HTTP_PROXY=127.0.0.1:*），探活与验证请求不再被代理劫持而全部误报失败
- DESIGN.md / README 与实现对齐：补 studio-panel 组件章节；「组合与启动」改为
  profile bundle 安装路径（`overlays/` patch 层方案已废弃）；技能章节改为预设自带 skills/
- studio-panel：新增「研究」tab（深度研究报告库，主从布局 + 全文渲染 + 运行环境就绪态）
  与「搜索」tab（项目资料检索：350ms 防抖、canonical scope 下拉、命中词高亮、
  加载/空态/服务端 warning 提示）；「图谱」tab 补齐连续性面——伏笔校验错误块与 ⚠ 角标、
  事实账本（truth 三文档渲染）、章节工作流列表；新增 search-harness 逻辑级测试
  （真实 bundle 组件 + DOM shim 驱动防抖→fetch→渲染流）
- openwrite-bridge 从 14 扩到 **62 个 `novel_*` 工具**，OpenWrite Studio 动作面全覆盖
  （修订闭环、任务中心、后台连写、章节运行、滚动大纲、叙事预测、风格/参考库/规则、
  深度研究、模型配置、项目生命周期等）；刻意不桥接 `/api/chat` 与 `/api/agent/*`，
  agent 会话层唯一归属 dsh
- 移除 `novel_chat_goethe`：不再回调 OpenWrite 内部 agent，草案生成由 dsh agent 自身完成
- goethe/dante 预设 persona 更新完整工具面；删章改走 `novel_chapter_delete` 服务端三重确认
- `subagent_goethe` 只读面补 `novel_asset_read`、`novel_continuity`
- studio-panel：新增「大纲」「资产」「任务」「图谱」原生视图 tab 与 `novel_review_chapter`
  评审报告卡；host 侧 `GET /studio-panel/api/*` 只读代理（透传状态码/错误体，
  写操作仍只走 agent 工具）。「资产」tab 含资料库（参考作品）分组；「图谱」tab 为
  伏笔分层看板 + 人物关系环形图（类型过滤、密度自适应）
- 配套 OpenWrite 侧改动（在 OpenWrite 仓库，未提交）：嵌入检测改为
  参数/被嵌/sessionStorage 三重判定；修复 start() 覆盖 shell 主题的问题；
  `applyShellTheme` 实时联动 Vditor 编辑器主题；嵌入时隐藏 Studio 主题切换按钮；
  **修复嵌入模式从未生效的根因——Studio CSP `script-src 'self'` 拦截内联脚本，
  启动逻辑移到外部 `embed-boot.js`**；嵌入时不再自动弹新手引导
- studio-panel：iframe 带 `?embed=dsh&theme=` 参数，跟随 shell 深浅色主题实时联动
- 配套 OpenWrite 侧改动（在 OpenWrite 仓库，未提交）：`OPENWRITE_FRAME_ANCESTORS`
  可配置嵌入白名单、`embed-dsh.css` 皮肤（嵌入时隐藏 Studio 内置 agent 入口）、
  index.html 启动脚本
- 新增 `scripts/verify.sh` 一键集成验证

## 0.1.0

- 首个版本：`@dsh-novel/openwrite-bridge`（14 个 `novel_*` 工具）、
  `@dsh-novel/studio-panel`（「稿件」tab 内嵌完整 Studio）、
  goethe/dante 双 agent 预设（persona 移植自 OpenWrite）、13 个移植技能、
  `install.sh` / `dev.sh` 脚本
