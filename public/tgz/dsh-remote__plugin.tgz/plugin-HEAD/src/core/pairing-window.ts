/**
 * pairing-window — "让屏幕上永远有一张能用的码"这条策略。
 *
 * 为什么要有这一层（而不是在启动时发一张就完事）：取证
 * `docs/legacy-spec/host-plugin-runtime.md` §6.2。旧实现把它写成挂在状态快照里的
 * 3 秒循环，并且明确记着**三条 stale 判据各自防的事故**：
 *
 * - `!active` → 防"永远没有码"（一次发布失败之后就再也不发了）；
 * - `generationChanged` → 防"中继重启后一直挂一张死码"：中继的 pending-pair 表是内存的，
 *   重启即清空，那张码的 TTL 还没到但已经没人认得了；
 * - `剩余寿命 < 安全余量` → 防"用户扫到一个刚刚过期的码"。**2026-10-26 从"半程"
 *   改成固定余量**：半程 + 3s 轮询 ⇒ 一张码在 status.json 里的实际存活期只有
 *   `ttl/2 ~ ttl`（线上 TTL 180s ⇒ 每 90 秒换一张），而换码**不会**作废旧码
 *   （中继的 pending 表里它一直活到自己的 TTL），所以早换的唯一效果是让屏幕上的
 *   二维码频繁变脸、`pair token issued` 刷屏（实测一晚 409 条）。改成"剩余不到
 *   30 秒才换"之后：屏幕上的码稳定 ~150 秒，而换码那一刻仍有 30 秒余量
 *   （认领是一个来回，秒级；30 秒是十倍安全系数）。
 *   ⚠️ **余量不许压到 0**（到期才换）：那样用户扫到的码可能只剩几秒，
 *   一次慢一点的扫码就撞 `invalid_or_expired`。
 *
 * 新实现再加第四条判据，它是这次重写才有的能力：
 *
 * - `consumed` → 这张码已经被某部手机用掉了（`peer-joined` 带回的就是它的 token）。
 *   旧实现只能等半程刷新，于是"第二部手机要等新码"最坏要等半个 TTL；
 *   而 e2e 连跑多轮时每一轮都要一张**新码**（一次性码不可复用），
 *   没有这条判据的话多轮取证要么很慢、要么只能靠重启宿主。
 *
 * 还有一条不可让步的**发布闸门**：`relay === 'online'` 才发。
 * 因为 `RelayClient.raw()` 对非 OPEN 的 socket 是静默丢弃（`transport/relay.ts`），
 * 断连时"本地记了一张码、远端根本没收到"= 表里多一条永远配不上的 PSK，
 * 而 status.json 里却显示它有效（取证 §6.2 第 5 行）。
 *
 * 本模块是纯逻辑：不认 socket、不认 cordis、时钟与发布动作都由调用方注入，
 * 所以上面四条判据每一条都有单测（旧实现这三条**一条都没测过**）。
 */
import { createHash } from 'node:crypto'
import type { Clock } from '../ports/index.js'

/**
 * 一张码在日志里的**代号**：码文本的 sha256 前 8 位。
 *
 * 为什么日志里不能出现那个 6 位码（2026-10-06 审计）：它**就是认领凭据本身**，
 * 而插件的日志落在 stdout——`HANDOFF.md` §2 与 `pill/routes.ts` 那条注释都写着
 * "stdout 是会被翻出来贴进 issue 的那种地方"，同一条纪律在 `pill/routes.ts` 里已经
 * 落实成 `tokenLength` + `epoch`。本文件与 `index.ts` 的 `publishPairing` 当时漏了，
 * 变成**同一个 stdout 上一半守纪律一半不守**。
 *
 * 取哈希而不是干脆不记，是因为"是哪一版码"在排错时真的有用（同一个代号能把
 * 发布、消费、被拒这三条行串起来），而 sha256 前 8 位推不回 10⁶ 空间里的任何一码。
 */
export function tokenHandle(token: string): string {
  return createHash('sha256').update(token).digest('hex').slice(0, 8)
}

/** 当前挂在 status.json 里的那张码。 */
export interface ActivePair {
  token: string
  /** 发起 `pair-begin` 的时刻；TTL 的两条基线都以它为准（见 §6.3 末尾那条不一致的记录）。 */
  createdAt: number
  expiresAt: number
  /** 发布时中继的代次；代次变了说明中继的 pending 表已经清空，这张码是死的。 */
  generation: number
}

export interface WindowInput {
  active: ActivePair | null
  now: number
  /** 中继当前代次。 */
  generation: number
  /** 每张码的请求寿命（毫秒）；服务端 `pair-ready.ttlMs` 落地后以它为准。 */
  ttlMs: number
}

/** 需要重新发布的原因；返回 null 表示这张码仍然可用。 */
export function staleReason(input: WindowInput): string | null {
  const { active, now, ttlMs, generation } = input
  if (!active) return 'no-active-pair'
  if (active.generation !== generation) return 'relay-generation-changed'
  if (active.expiresAt < now) return 'expired'
  if (active.expiresAt < now + rotateMarginMs(ttlMs)) return 'near-expiry'
  return null
}

/**
 * 换码的安全余量（2026-10-26，原判据是 `ttlMs / 2`）。
 *
 * 30 秒的出处：认领是**一个来回**（手机扫码 → 建连 → `pair-begin-client` → 中继 `claim`），
 * 真机上通常 1–3 秒；30 秒是十倍余量，同时把"屏幕上的码多久变一次"从 90 秒拉到 150 秒
 * （线上 TTL 180s）—— 换码本身不会作废旧码，变脸快只剩坏处（拍屏/慢扫的人对不上
 * 屏幕上那张、日志被 `pair token issued` 刷屏）。
 *
 * ⚠️ 上限仍是半程：TTL 很短时（判据里 20s、自建中继有人会把 TTL 收紧）余量不许超过
 * 寿命的一半，否则一张码刚发出来就被判"该换了"—— 3 秒一轮的换码风暴，
 * 屏幕上永远没有能用的码（2026-10-04 的现场，`pairOnStartSec=0` 那档踩过）。
 */
const ROTATE_MARGIN_MS = 30_000

function rotateMarginMs(ttlMs: number): number {
  return Math.min(ROTATE_MARGIN_MS, ttlMs / 2)
}

export interface WindowDeps {
  clock: Clock
  /** 中继此刻是否在线。 */
  relayOnline(): boolean
  /** 中继当前代次。 */
  generation(): number
  /** 发一张新码，返回它的三个时间量；失败返回 null（保留旧码继续展示）。 */
  publish(ttlMs: number): { token: string; createdAt: number; expiresAt: number } | null
  /** 每轮最多发布几张：发布失败（socket 未 OPEN）时不许原地打转。 */
  maxPublishPerTick?: number
  log(message: string, fields?: Record<string, string | number | boolean | undefined>): void
}

/**
 * 由调用方按节拍驱动（本仓库里是 `StatusFile.start()` 的 3 秒 tick——
 * 旧实现就是挂在这里，理由是"反正每 3 秒就要写一次状态"）。
 *
 * 刻意**不自带定时器**：定时器属于宿主，一个纯策略类不该再占一只。
 */
export class PairingWindow {
  active: ActivePair | null = null
  private requestedTtlMs: number | undefined

  constructor(
    private readonly deps: WindowDeps,
    private readonly pairSec: number,
    /** 未自动发码（`pairOnStartSec <= 0`）时那张"用户点出来的码"按多长 TTL 老化。 */
    private readonly defaultTtlMs = 120_000,
  ) {}

  /** 服务端权威 TTL（`pair-ready.ttlMs`）：落地后覆盖请求值，并修正已挂出的那张码。 */
  applyServerTtl(pairingToken: string, ttlMs: number): void {
    if (ttlMs > 0) this.requestedTtlMs = ttlMs
    if (this.active && this.active.token === pairingToken) {
      // 基线用**发起时刻**（createdAt），不是 pair-ready 到达时刻：
      // 两条基线不一致时本地会比中继早失效（偏危险方向），取证 §6.3 末尾。
      this.active = { ...this.active, expiresAt: this.active.createdAt + ttlMs }
    }
  }

  /** 这张码已被某部手机用掉（`peer-joined` 带回的 token 就是它）。 */
  markConsumed(pairingToken: string): void {
    if (this.active?.token === pairingToken) {
      this.deps.log('pairing code consumed, publishing a fresh one', { code: tokenHandle(pairingToken) })
      this.active = null
    }
  }

  /**
   * 这张码在中继那边**已经废了**（`pair-fail`：expired / already_used / invalid_or_expired）。
   *
   * 与 `markConsumed` 的区别只在这条日志：那一条说"被用掉了"，而这一条是"中继不认它"
   * ——排错时两者要分得开（一个是正常路径，一个是失败路径）。
   */
  forget(pairingToken: string): void {
    if (this.active?.token === pairingToken) {
      this.deps.log('pairing code rejected by the relay, dropping it', { code: tokenHandle(pairingToken) })
      this.active = null
    }
  }

  /**
   * 认领一张**别处**发出去的码（手工 `/drc pair`、或 status 之外的入口）。
   * 不认领的话窗口会认为"没有活动码"而再发一张，于是同一台主机挂两张有效码——
   * 手机扫的是屏幕上那张，取错密钥就是全线解不开（多码事故的原样）。
   */
  adopt(created: { token: string; createdAt: number; expiresAt: number }): void {
    this.active = { ...created, generation: this.deps.generation() }
  }

  /**
   * 此刻这张码还能不能递给用户；返回原因字符串表示"不能"，null 表示仍然可用。
   *
   * 与 `tick()` 的换码判据同一套（代次变了 / 已过期 / 剩余不足安全余量），只是**不发布**。
   * 为什么要有这一口：`tick()` 挂在 3 秒的状态节拍上，而用户点的那条"刷新"是即时的
   * —— 少了这一判，中继重启后屏幕上那张码在中继那边已经死了（它的 pending 表是内存的），
   * 本地 TTL 却还没到，两次 tick 之间的那次刷新会把死码原样递回去，用户干等一整个 TTL。
   */
  staleNow(): string | null {
    return staleReason({
      active: this.active,
      now: this.deps.clock.now(),
      generation: this.deps.generation(),
      ttlMs: this.ttlMs(),
    })
  }

  /**
   * 一轮检查。返回"这一轮是否发布了新码"。
   *
   * **"要不要自动补发"与"要不要刷新已经挂出去的那张"是两件事**（2026-10-06）：
   * 原来第一行 `if (pairSec <= 0) return false` 把两件事一起掐了，于是
   * `pairOnStartSec` 默认 0 的机器上 `generation-changed` 与 `near-expiry`
   * 两条判据**永不生效** —— 中继重启后屏上那张码已经死了，而"刷新"因为本地
   * 未过期会原样返回它，用户只能干等 TTL。现在只在"没有活动码且不自动发码"时早退。
   */
  tick(): boolean {
    if (this.pairSec <= 0 && this.active === null) return false
    // 发布闸门：**不在线就一张都不发**。`RelayClient.raw()` 对非 OPEN 的 socket 是静默丢弃，
    // 只记本地就会留下"status.json 显示有效、中继那边根本没收到"的死码（取证 §6.2）。
    if (!this.deps.relayOnline()) return false
    let published = false
    const max = this.deps.maxPublishPerTick ?? 1
    for (let attempt = 0; attempt < max; attempt++) {
      const ttlMs = this.ttlMs()
      const reason = staleReason({
        active: this.active,
        now: this.deps.clock.now(),
        generation: this.deps.generation(),
        ttlMs,
      })
      if (!reason) {
        // 不需要新码。`expiresAt` 已由 `applyServerTtl` 在那张码的 `pair-ready` 到达时
        // 按服务端权威值重算过（见它的注释），这里**刻意不再**算第二遍：同一个 ttlMs
        // 在两个地方各算一次，迟早会算出两个不同的 expiresAt，而那种分歧的表现是
        // "手机上这张码看起来还剩很久、实际刚过期"——比少一条注释难查得多。
        return published
      }
      const created = this.deps.publish(ttlMs)
      if (!created) {
        this.deps.log('pairing publish failed', { reason })
        return published
      }
      this.active = { ...created, generation: this.deps.generation() }
      this.deps.log('pairing published', { reason, code: tokenHandle(created.token), ttlMs })
      published = true
    }
    return published
  }

  /**
   * 请求值来自 `pairOnStartSec`；服务端一旦回过 `ttlMs` 就以它为准。
   *
   * `pairOnStartSec <= 0`（默认）时不能拿 `pairSec*1000` 当基线——那会得到 1 秒，
   * 于是"已经挂出去的那张"每次 tick 都被判成该换、3 秒换一张（永远没有能用的码）。
   * 这一档用 `defaultTtlMs`（调用方传的是配置里的 `pairTtlMs`）：屏幕上那张码是
   * 用户点出来的，它按常规 TTL 老化。
   */
  private ttlMs(): number {
    if (this.requestedTtlMs !== undefined) return this.requestedTtlMs
    return this.pairSec > 0 ? Math.max(1_000, this.pairSec * 1_000) : this.defaultTtlMs
  }
}
