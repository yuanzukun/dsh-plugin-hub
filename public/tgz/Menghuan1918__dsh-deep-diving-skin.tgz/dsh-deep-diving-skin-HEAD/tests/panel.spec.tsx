// @vitest-environment jsdom
/**
 * The configuration page, driven through the props the renderer hands it:
 * the derived `view`/`t` shares plus the injected settings face.
 */
import { act, createElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { zh } from '../src/client/locales.ts'
import { SkinPanel, toDataUrl, type SkinPanelProps } from '../src/client/panel.tsx'
import { DEFAULT_SKIN, UPLOAD_MAX_BYTES, type SkinConfig } from '../src/skin-config.ts'

declare global {
  // eslint-disable-next-line no-var
  var IS_REACT_ACT_ENVIRONMENT: boolean | undefined
}
globalThis.IS_REACT_ACT_ENVIRONMENT = true

/** Dictionary lookup with the same `{name}` interpolation the renderer's `t` uses. */
function translate(key: string, params?: Record<string, unknown>): string {
  const template = (zh as Record<string, string>)[key] ?? key
  return template.replace(/\{(\w+)\}/g, (_match, name: string) => String(params?.[name] ?? ''))
}

interface Harness {
  readonly root: Root
  readonly container: HTMLElement
  readonly save: ReturnType<typeof vi.fn>
  readonly reset: ReturnType<typeof vi.fn>
  publish(next: SkinConfig): void
  render(overrides?: Partial<SkinPanelProps>): void
}

let harness: Harness | undefined

function setup(initial: SkinConfig = { ...DEFAULT_SKIN }): Harness {
  let snapshot = initial
  const listeners = new Set<() => void>()
  const container = document.createElement('div')
  document.body.append(container)
  const root = createRoot(container)
  const save = vi.fn(async (patch: Partial<SkinConfig>): Promise<SkinConfig> => ({ ...snapshot, ...patch }))
  const reset = vi.fn(async (): Promise<SkinConfig> => ({ ...DEFAULT_SKIN }))

  const created: Harness = {
    root,
    container,
    save,
    reset,
    publish(next) {
      snapshot = next
      for (const listener of [...listeners]) listener()
    },
    render(overrides) {
      act(() => {
        // The props object is exactly SkinPanelProps: no cast, so a shape the
        // renderer would not supply fails to compile here.
        root.render(createElement(SkinPanel, {
          view: 'page',
          useConfig: <S,>(selector: (config: SkinConfig) => S): S => selector(snapshot),
          t: translate,
          save,
          reset,
          ...overrides,
        }))
      })
    },
  }
  created.render()
  return created
}

function inputByValue(container: HTMLElement, value: string): HTMLInputElement {
  const found = [...container.querySelectorAll('input')].find(input => input.value === value)
  if (found === undefined) throw new Error(`no input carrying the value ${JSON.stringify(value)}`)
  return found
}

function typeInto(input: HTMLInputElement | HTMLTextAreaElement, value: string): void {
  const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set
  setter?.call(input, value)
  act(() => { input.dispatchEvent(new Event('input', { bubbles: true })) })
}

function buttonByText(container: HTMLElement, label: string): HTMLButtonElement {
  const found = [...container.querySelectorAll('button')].find(button => button.textContent === label)
  if (found === undefined) throw new Error(`no button labelled ${JSON.stringify(label)}`)
  return found
}

async function click(button: HTMLButtonElement): Promise<void> {
  await act(async () => { button.dispatchEvent(new MouseEvent('click', { bubbles: true })) })
}

beforeEach(() => { harness = setup() })

afterEach(() => {
  const current = harness
  harness = undefined
  if (current === undefined) return
  act(() => { current.root.unmount() })
  current.container.remove()
})

describe('configuration page', () => {
  it('renders the current configuration', () => {
    const current = harness!
    expect(inputByValue(current.container, DEFAULT_SKIN.text)).toBeInstanceOf(HTMLInputElement)
    expect(inputByValue(current.container, DEFAULT_SKIN.color)).toBeInstanceOf(HTMLInputElement)
    expect(current.container.querySelector<HTMLInputElement>('input[type="checkbox"]')!.checked).toBe(true)
    expect(current.container.querySelector<HTMLInputElement>('input[type="number"]')!.value).toBe('3')
  })

  it('renders the row summary without the form', () => {
    const current = setup()
    current.render({ view: 'summary' })
    expect(current.container.textContent).toBe(zh.summary)
  })

  it('renders the form for the Settings section, which passes no view', () => {
    const current = harness!
    current.render({ view: undefined })
    expect(inputByValue(current.container, DEFAULT_SKIN.text)).toBeInstanceOf(HTMLInputElement)
    expect(current.container.querySelector('input[type="file"]')).not.toBeNull()
    expect(current.container.textContent).not.toBe(zh.summary)
  })

  it('saves an edited draft', async () => {
    const current = harness!
    typeInto(inputByValue(current.container, DEFAULT_SKIN.text), '祈祷中')
    typeInto(inputByValue(current.container, DEFAULT_SKIN.color), '#3366ff')
    await click(buttonByText(current.container, zh.save))

    expect(current.save).toHaveBeenCalledWith({ ...DEFAULT_SKIN, text: '祈祷中', color: '#3366ff' })
    expect(current.container.textContent).toContain(zh.saved)
  })

  it('reports a host that accepted the write but discarded a field', async () => {
    const current = harness!
    // An older host answers 200 and drops the fields it does not know. The
    // real store republishes whatever the host returned, so the stub does too.
    current.save.mockImplementationOnce(async () => {
      current.publish({ ...DEFAULT_SKIN })
      return { ...DEFAULT_SKIN }
    })
    typeInto(inputByValue(current.container, DEFAULT_SKIN.text), '祈祷中')
    await click(buttonByText(current.container, zh.save))

    expect(current.container.textContent).toContain('宿主丢弃了')
    expect(current.container.textContent).toContain('text')
    // The draft re-seeds from what the host actually stored.
    expect(inputByValue(current.container, DEFAULT_SKIN.text)).toBeInstanceOf(HTMLInputElement)
  })

  it('reports a refused save', async () => {
    const current = harness!
    current.save.mockRejectedValueOnce(new Error('icon must be empty or a URL'))
    await click(buttonByText(current.container, zh.save))

    expect(current.container.textContent).toContain(zh.saveFailed)
    expect(current.container.textContent).toContain('icon must be empty or a URL')
  })

  it('resets every field', async () => {
    const current = harness!
    typeInto(inputByValue(current.container, DEFAULT_SKIN.text), '祈祷中')
    await click(buttonByText(current.container, zh.resetAll))

    expect(current.reset).toHaveBeenCalledTimes(1)
    expect(inputByValue(current.container, DEFAULT_SKIN.text)).toBeInstanceOf(HTMLInputElement)
  })

  it('re-seeds the draft when the stored configuration changes', () => {
    const current = harness!
    current.publish({ ...DEFAULT_SKIN, text: '来自宿主的文本' })
    current.render()
    expect(inputByValue(current.container, '来自宿主的文本')).toBeInstanceOf(HTMLInputElement)
  })

  it('refuses an oversized icon upload', () => {
    const current = harness!
    const file = new File([new Uint8Array(UPLOAD_MAX_BYTES + 1)], 'big.gif', { type: 'image/gif' })
    const picker = current.container.querySelector<HTMLInputElement>('input[type="file"]')!
    Object.defineProperty(picker, 'files', { value: [file], configurable: true })
    act(() => { picker.dispatchEvent(new Event('change', { bubbles: true })) })

    expect(current.container.textContent).toContain(zh.saveFailed)
    expect(current.container.textContent).toContain('1025 KB')
  })
})

describe('icon upload', () => {
  it('reads a small file as a data URI', async () => {
    const file = new File(['<svg xmlns="http://www.w3.org/2000/svg"/>'], 'icon.svg', { type: 'image/svg+xml' })
    const uri = await toDataUrl(file)

    expect(uri.startsWith('data:image/svg+xml;base64,')).toBe(true)
    expect(Buffer.from(uri.split(',')[1]!, 'base64').toString('utf8')).toContain('<svg')
  })
})
