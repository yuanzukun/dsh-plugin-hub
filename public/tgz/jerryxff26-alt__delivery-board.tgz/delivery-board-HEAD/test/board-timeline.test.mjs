import { test } from 'node:test'
import assert from 'node:assert/strict'

import { createProject, addCard, archiveCard, moveCard, appendLog } from '../lib/delivery.js'
import { renderBoardHtml } from '../lib/board-html.js'
import { boardStrings, cardTimeline, renderTimeline, renderColumns, renderCard } from '../lib/board-view.js'
import { demoState } from './fixtures/demo-state.mjs'

const NOW = new Date(2026, 9, 26, 9, 0, 0).getTime() // local Mon 2026-10-26 09:00
const HAN = /[\u3400-\u9fff]/

function at(daysAgo) {
  return new Date(NOW - daysAgo * 86400000).toISOString()
}

function timedState() {
  let s = createProject({ customer: 'ACME', template: 'governance' })
  s = addCard(s, { title: 'Shipped one', stage: 'plan', owner: 'bob', due: '2026-10-20' })
  s = addCard(s, { title: 'Late one', stage: 'plan', owner: 'amy', due: '2026-10-01' })
  s = addCard(s, { title: 'Future <b>xss</b>', stage: 'plan', due: '2026-11-15' })
  s = addCard(s, { title: 'Old archived', stage: 'plan' })
  const last = s.pipeline[s.pipeline.length - 1]
  for (const stage of s.pipeline.slice(1)) s = moveCard(s, { cardId: 'c1', toStage: stage.id })
  s = moveCard(s, { cardId: 'c2', toStage: s.pipeline[1].id })
  s = archiveCard(s, { cardId: 'c4' })
  // Pin every timestamp relative to NOW so the calendar layout is deterministic.
  const created = { c1: 30, c2: 20, c3: 3, c4: 40 }
  s.cards = s.cards.map((card) => ({ ...card, createdAt: at(created[card.id]), ...(card.id === 'c4' ? { archivedAt: at(10) } : {}) }))
  let step = 0
  s.logs = s.logs.map((entry) => entry.cardId === 'c1' && entry.type === 'handoff' ? { ...entry, ts: at(25 - 3 * step++) } : entry.cardId === 'c2' && entry.type === 'handoff' ? { ...entry, ts: at(5) } : entry)
  return { s, last }
}

test('en and zh string tables have identical keys', () => {
  const en = Object.keys(boardStrings('en-US')).sort()
  const zh = Object.keys(boardStrings('zh-CN')).sort()
  assert.deepEqual(zh, en)
  for (const key of en) assert.equal(typeof boardStrings('zh-CN')[key], typeof boardStrings('en-US')[key], key)
})

test('cardTimeline derives stage segments and a shipped date from handoff logs', () => {
  const { s, last } = timedState()
  const c1 = cardTimeline(s.cards.find((c) => c.id === 'c1'), s, NOW)
  assert.equal(c1.start, Date.parse(at(30)))
  assert.equal(c1.segments[0].stage, 'plan')
  assert.equal(c1.segments[0].end, Date.parse(at(25)))
  assert.equal(c1.segments.length, s.pipeline.length - 1)
  assert.ok(c1.shipped != null, 'terminal handoff marks the card shipped')
  assert.ok(c1.segments.every((seg) => seg.stage !== last.id))
  const c2 = cardTimeline(s.cards.find((c) => c.id === 'c2'), s, NOW)
  assert.equal(c2.shipped, null)
  assert.equal(c2.segments.at(-1).end, NOW, 'open segment runs to now')
  const c4 = cardTimeline(s.cards.find((c) => c.id === 'c4'), s, NOW)
  assert.equal(c4.archivedAt, Date.parse(at(10)))
  assert.equal(c4.segments.at(-1).end, c4.archivedAt)
})

test('renderTimeline draws a calendar axis with today, gridlines and markers', () => {
  const { s } = timedState()
  const html = renderTimeline(s, { now: NOW, locale: 'en-US', strings: boardStrings('en-US'), query: '', owner: '', interactive: true })
  assert.match(html, /class="tl-today"/)
  assert.match(html, /Today · Oct 26/)
  assert.match(html, /class="tl-month/)
  assert.match(html, /Nov 2026/)
  assert.ok((html.match(/class="tl-line week/g) ?? html.match(/tl-week/g) ?? []).length >= 4, 'weekly gridlines')
  assert.match(html, /class="tl-due overdue"/, 'overdue due marker for c2')
  assert.match(html, /class="tl-ship"/, 'shipped marker for c1')
  assert.match(html, /class="tl-arch"/, 'archived marker for c4')
  assert.match(html, /data-action="edit"/)
  assert.ok(!html.includes('<b>xss</b>'))
  assert.match(html, /Future &lt;b&gt;xss&lt;\/b&gt;/)
  assert.ok(!HAN.test(html), 'en timeline has no Han characters')
  // Shipped card is not flagged overdue even though its due date passed.
  const shippedRow = html.split('data-card-id="c1"')[1].split('class="tl-row')[0]
  assert.ok(!shippedRow.includes('overdue'))
})

test('renderTimeline localizes to zh and handles undated and empty states', () => {
  let s = createProject({ customer: 'ACME', template: 'governance' })
  s = addCard(s, { title: 'No dates', stage: 'plan' })
  s.cards = s.cards.map((card) => ({ ...card, createdAt: undefined }))
  s.logs = []
  const zh = renderTimeline(s, { now: NOW, locale: 'zh-CN', strings: boardStrings('zh-CN'), query: '', owner: '' })
  assert.match(zh, /tl-empty/)
  assert.match(zh, /tl-undated/)
  assert.match(zh, /No dates/)
  assert.ok(HAN.test(zh))
  const { s: full } = timedState()
  const filtered = renderTimeline(full, { now: NOW, locale: 'en-US', strings: boardStrings('en-US'), query: 'nothing-matches', owner: '' })
  assert.match(filtered, /tl-empty/)
})

test('board page ships a Timeline switch and a hidden client-rendered timeline', () => {
  const { s } = timedState()
  const html = renderBoardHtml(s, { endpoint: '/api/state', revision: 'r1', locale: 'en-US' })
  assert.match(html, /id="timeline-view"/)
  assert.match(html, /<section id="timeline" class="timeline-panel"[^>]*hidden><\/section>/)
  assert.match(html, /function renderTimeline/)
  assert.match(html, /function cardTimeline/)
  assert.match(html, /prefers-color-scheme: dark/)
  const zh = renderBoardHtml(s, { locale: 'zh-CN' })
  assert.match(zh, /时间线/)
})

test('board boot only bakes in an explicit locale so the browser can choose', () => {
  const { s } = timedState()
  const html = renderBoardHtml(s, { endpoint: '/api/state', revision: 'r1' })
  assert.match(html, /"locale":null/)
  assert.match(renderBoardHtml(s, { locale: 'zh-CN' }), /"locale":"zh-CN"/)
})

test('columns over a WIP limit show a quiet warn-only note (no screaming badge)', () => {
  let s = createProject({ customer: 'WIP', template: 'lite' })
  s = { ...s, pipeline: s.pipeline.map((stage) => (stage.id === 'doing' ? { ...stage, wipLimit: 1 } : stage)) }
  s = addCard(s, { title: 'One', stage: 'doing' })
  s = addCard(s, { title: 'Two', stage: 'doing' })
  const ui = { interactive: true, query: '', owner: '', limits: {}, strings: boardStrings('en-US') }
  const html = renderColumns(s, ui)
  assert.match(html, /class="wip-note"/)
  assert.match(html, /Over WIP/)
  assert.equal((html.match(/class="wip-note"/g) ?? []).length, 1)
  // Quiet columns / timeline: no per-stage rainbow style attribute
  assert.doesNotMatch(html, /style="--stage:/)
})

test('renderCard is title+meta with grab drag and localized menu', () => {
  const { s } = timedState()
  const card = s.cards.find((c) => c.id === 'c2')
  const en = renderCard(card, s, true, boardStrings('en-US'))
  assert.match(en, /draggable="true"/)
  assert.match(en, /is-overdue/)
  assert.doesNotMatch(en, /class="card-top"|class="drag-hint"|class="cid"/)
  assert.match(en, /class="card-menu"/)
  assert.ok(!HAN.test(en))
  const zh = renderCard(card, s, true, boardStrings('zh-CN'))
  assert.match(zh, /卡片操作/)
  assert.match(zh, /class="due overdue"/)
  assert.ok(HAN.test(zh))
  const shipped = renderCard(s.cards.find((c) => c.id === 'c1'), s, true, boardStrings('en-US'))
  assert.ok(!shipped.includes('is-overdue'))
})

test('terminal-stage cards show as done with their due date on the face', () => {
  let s = createProject({ customer: 'ACME', template: 'lite' })
  const terminal = s.pipeline[s.pipeline.length - 1].id
  s = addCard(s, { title: 'Shipped work', stage: terminal, owner: 'amy', due: '2026-10-19' })
  s = addCard(s, { title: 'Open work', stage: s.pipeline[1].id, owner: 'bob', due: '2026-11-20' })
  const done = renderCard(s.cards[0], s, true, boardStrings('en-US'))
  assert.match(done, /class="[^"]*is-done/)
  assert.match(done, /class="done-meta"[^>]*>✓ 2026-10-19/)
  assert.doesNotMatch(done, /class="due/)
  assert.ok(!HAN.test(done))
  const open = renderCard(s.cards[1], s, true, boardStrings('en-US'))
  assert.doesNotMatch(open, /is-done|done-meta/)
  assert.match(open, /class="due"/)
  const zh = renderCard(s.cards[0], s, true, boardStrings('zh-CN'))
  assert.match(zh, /class="[^"]*is-done/)
  assert.match(zh, /已完成/)
})

test('a card built straight into the terminal stage ships on its due date', () => {
  let s = createProject({ customer: 'ACME', template: 'lite' })
  const terminal = s.pipeline[s.pipeline.length - 1].id
  s = addCard(s, { title: 'Shipped work', stage: terminal, start: '2026-10-16', due: '2026-10-19' })
  const tl = cardTimeline(s.cards[0], s, NOW)
  assert.equal(tl.shipped, new Date(2026, 9, 19).getTime())
  assert.equal(tl.scheduleStart, new Date(2026, 9, 16).getTime())
})

test('timeline bars use shared accent — no per-stage --stage vars or stage-dot', () => {
  const { s } = timedState()
  const html = renderTimeline(s, { interactive: false, query: '', owner: '', locale: 'en-US', strings: boardStrings('en-US'), now: Date.parse('2026-10-28T12:00:00+08:00') })
  assert.doesNotMatch(html, /style="[^"]*--stage:/)
  assert.doesNotMatch(html, /stage-dot/)
})

test('timeline draws schedule bar when start and due are both set', () => {
  let s = createProject({ customer: 'Sched', template: 'lite' })
  s = addCard(s, { title: 'Spanned', stage: 'doing', owner: 'Ada', start: '2026-10-20', due: '2026-10-28' })
  s = addCard(s, { title: 'Due only', stage: 'doing', due: '2026-10-30' })
  s.cards = s.cards.map((card) => ({ ...card, createdAt: at(card.id === 'c1' ? 10 : 2) }))
  const html = renderTimeline(s, { now: NOW, locale: 'en-US', strings: boardStrings('en-US'), query: '', owner: '', interactive: false })
  assert.match(html, /class="tl-sched"/)
  assert.match(html, /Schedule \(start→due\)/)
  // due-only still uses ◆, not a schedule bar alone for that card
  const dueOnly = html.split('data-card-id="c2"')[1].split('class="tl-row')[0]
  assert.match(dueOnly, /class="tl-due/)
  assert.doesNotMatch(dueOnly, /class="tl-sched/)
  const spanned = html.split('data-card-id="c1"')[1].split('class="tl-row')[0]
  assert.match(spanned, /class="tl-sched/)
  assert.doesNotMatch(spanned, /class="tl-due/)
})
