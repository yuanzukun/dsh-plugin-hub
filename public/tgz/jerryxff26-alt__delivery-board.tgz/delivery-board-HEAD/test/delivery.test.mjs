import { test } from 'node:test'
import assert from 'node:assert/strict'

import {
  createProject,
  addCard,
  moveCard,
  archiveCard,
  restoreCard,
  updateCard,
  appendLog,
  resolveLog,
  setDodDone,
  addDodItem,
  archiveBoard,
  archiveBoardSlug,
  setStageHidden,
  addStage,
  updateStage,
  removeStage,
  renderBoard,
  renderWeekly,
  normalizeDodItems,
  dodProgress,
  TEMPLATES,
} from '../lib/delivery.js'

test('createProject uses the default ToB pipeline', () => {
  const s = createProject({ customer: 'ACME' })
  assert.equal(s.customer, 'ACME')
  assert.equal(s.template, 'default')
  assert.deepEqual(
    s.pipeline.map((p) => p.id),
    TEMPLATES.default.stages.map((p) => p.id),
  )
  assert.ok(s.pipeline.every((p) => p.gates === undefined))
})

test('createProject supports the governance template', () => {
  const s = createProject({ customer: 'ACME', template: 'governance' })
  assert.equal(s.template, 'governance')
  assert.deepEqual(
    s.pipeline.map((p) => p.id),
    ['plan', 'analyze', 'design', 'build', 'test', 'deploy', 'live'],
  )
  assert.ok(s.pipeline.every((p) => p.gates === undefined))
})


test('createProject supports the lite template (short pipeline)', () => {
  const s = createProject({ customer: 'ACME', template: 'lite' })
  assert.equal(s.template, 'lite')
  assert.deepEqual(
    s.pipeline.map((p) => p.id),
    ['backlog', 'doing', 'review', 'live'],
  )
  assert.deepEqual(
    s.pipeline.map((p) => p.name),
    ['Backlog', 'Doing', 'Review', 'Live'],
  )
  assert.ok(s.pipeline.every((p) => p.gates === undefined))
  assert.equal(TEMPLATES.lite.name, 'Lite Pipeline')
})

test('renderBoard empty columns use actionable copy', () => {
  const s = createProject({ customer: 'ACME', template: 'lite' })
  const board = renderBoard(s)
  assert.match(board, /\(empty — add a card, or drag one here\)/)
  assert.doesNotMatch(board, /^ {2}\(empty\)$/m)
})

test('createProject accepts custom stages and rejects bad input', () => {
  const s = createProject({
    customer: 'ACME',
    stages: [{ name: 'Discovery', gates: ['Confirmed'] }],
  })
  assert.equal(s.template, 'custom')
  assert.equal(s.pipeline[0].name, 'Discovery')
  assert.equal(s.pipeline[0].gates, undefined)
  assert.throws(() => createProject({ customer: '  ' }), /customer is required/)
  assert.throws(() => createProject({ customer: 'A', template: 'nope' }), /unknown template/)
})

test('addCard stores acceptance criteria and DoD', () => {
  let s = createProject({ customer: 'ACME' })
  s = addCard(s, {
    title: 'SSO login',
    stage: 'ba',
    owner: 'carol',
    due: '2026-10-20',
    acceptance: ['SSO supported', 'Legacy accounts compatible'],
    dod: 'PRD reviewed\nTest cases written',
  })
  const c = s.cards[0]
  assert.equal(c.id, 'c1')
  assert.deepEqual(c.acceptance, ['SSO supported', 'Legacy accounts compatible'])
  assert.deepEqual(c.dod, [
    { text: 'PRD reviewed', done: false },
    { text: 'Test cases written', done: false },
  ])
  assert.throws(() => addCard(s, { title: 'x', stage: 'nope' }), /unknown stage/)
  assert.throws(() => addCard(s, { title: ' ', stage: 'dev' }), /title is required/)
})

test('moveCard hands off across stages and logs the audit trail', () => {
  let s = createProject({ customer: 'ACME' })
  s = addCard(s, { title: 'SSO login', stage: 'ba', owner: 'carol' })
  s = moveCard(s, { cardId: 'c1', toStage: 'tl', owner: 'dave', note: 'PRD reviewed' })
  const card = s.cards[0]
  assert.equal(card.stage, 'tl')
  assert.equal(card.owner, 'dave')
  const last = s.logs[s.logs.length - 1]
  assert.equal(last.type, 'handoff')
  assert.ok(last.text.includes('BA Analysis'))
  assert.ok(last.text.includes('TL Design'))
  assert.ok(last.text.includes('PRD reviewed'))
  assert.throws(() => moveCard(s, { cardId: 'c9', toStage: 'dev' }), /unknown card/)
  assert.throws(() => moveCard(s, { cardId: 'c1', toStage: 'nope' }), /unknown stage/)
})

test('appendLog validates type and text', () => {
  const s = createProject({ customer: 'ACME' })
  assert.throws(() => appendLog(s, { type: 'nope', text: 'x' }), /invalid log type/)
  assert.throws(() => appendLog(s, { type: 'risk', text: ' ' }), /text is required/)
  const s2 = appendLog(s, { type: 'risk', text: 'Tight schedule', cardId: 'c1' })
  assert.equal(s2.logs[0].cardId, 'c1')
  assert.equal(s.logs.length, 0) // immutable
})

test('renderBoard shows risks and DoD progress', () => {
  let s = createProject({ customer: 'ACME' })
  s = addCard(s, {
    title: 'SSO login', stage: 'dev', owner: 'erin', due: '2026-10-25',
    dod: [{ text: 'PRD reviewed', done: true }, { text: 'Tests written', done: false }],
  })
  s = appendLog(s, { type: 'blocker', text: 'Waiting on client UAT env' })
  const board = renderBoard(s)
  assert.ok(board.includes('# ACME Delivery Board'))
  assert.ok(board.includes('## Development'))
  assert.doesNotMatch(board, /Gates:/)
  assert.ok(board.includes('[c1] SSO login @erin'))
  assert.match(board, /DoD 1\/2/)
  assert.ok(board.includes('Waiting on client UAT env'))
})

test('renderWeekly covers handoffs and risks', () => {
  let s = createProject({ customer: 'ACME' })
  s = addCard(s, { title: 'SSO login', stage: 'ba' })
  s = moveCard(s, { cardId: 'c1', toStage: 'dev' })
  s = appendLog(s, { type: 'risk', text: 'Understaffed' })
  const md = renderWeekly(s, 'Week of Oct 12')
  assert.ok(md.includes('# ACME Delivery Weekly (Week of Oct 12)'))
  assert.ok(md.includes('## Handoffs this week'))
  assert.ok(md.includes('BA Analysis → Development'))
  assert.ok(md.includes('Understaffed'))
})

test('weekly report filters handoffs to a real seven-day reporting window', () => {
  const state = createProject({ customer: 'ACME' })
  state.logs = [
    { ts: '2026-01-01T00:00:00Z', type: 'handoff', text: 'historical handoff' },
    { ts: new Date('2026-10-05T00:00:00').toISOString(), type: 'handoff', text: 'first day handoff' },
    { ts: new Date('2026-10-11T23:59:59').toISOString(), type: 'handoff', text: 'last day handoff' },
    { ts: new Date('2026-10-12T00:00:00').toISOString(), type: 'handoff', text: 'next week handoff' },
    { ts: '2026-01-01T00:00:00Z', type: 'blocker', text: 'unresolved blocker' },
  ]
  const report = renderWeekly(state, 'Test period', '2026-10-05')
  assert.match(report, /2026-10-05.*2026-10-11/)
  assert.match(report, /first day handoff/)
  assert.match(report, /last day handoff/)
  assert.doesNotMatch(report, /historical handoff|next week handoff/)
  assert.match(report, /unresolved blocker/)
  assert.throws(() => renderWeekly(state, '', '2026-02-30'), /week_start/)
  assert.throws(() => renderWeekly(state, '', 'not-a-date'), /week_start/)
})

test('archiveCard hides archived cards by default and includes explicit marks and counts on request', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, { title: 'Archived feature', stage: 'dev', owner: 'erin', due: '2026-10-25' })
  state = addCard(state, { title: 'Active feature', stage: 'dev' })
  state = appendLog(state, { type: 'risk', text: 'Original risk', cardId: 'c1' })
  const original = structuredClone(state)
  const archived = archiveCard(state, { cardId: 'c1' })

  assert.deepEqual(state, original)
  assert.equal(archived.version, 3)
  assert.equal(archived.cards.length, 2)
  assert.equal(archived.cards[1], state.cards[1])
  assert.equal(archived.cards[0].archivedAt, archived.updatedAt)
  assert.equal(new Date(archived.cards[0].archivedAt).toISOString(), archived.cards[0].archivedAt)
  assert.deepEqual(archived.logs.slice(0, -1), state.logs)
  assert.equal(archived.logs.at(-1).type, 'decision')
  assert.equal(archived.logs.at(-1).cardId, 'c1')
  assert.equal(archived.logs.at(-1).ts, archived.cards[0].archivedAt)
  assert.match(archived.logs.at(-1).text, /archived/)

  const activeBoard = renderBoard(archived)
  assert.doesNotMatch(activeBoard, /Archived feature|\[c1\]/)
  assert.match(activeBoard, /\[c2\] Active feature/)
  assert.match(activeBoard, /## Development \(Dev\) · 1\n/)
  assert.match(activeBoard, /Original risk/)
  assert.equal(renderBoard(archived, { includeArchived: false }), activeBoard)

  const fullBoard = renderBoard(archived, { includeArchived: true })
  assert.match(fullBoard, /Cards: 1 active \/ 1 archived/)
  assert.match(fullBoard, /## Development \(Dev\) · 2 \(1 archived\)/)
  assert.match(fullBoard, /\[c1\] Archived feature @erin \(due 2026-10-25\) \[archived\]/)
  assert.match(fullBoard, /\[c2\] Active feature/)
})

test('restoreCard retains identity, all card fields and the complete history', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, {
    title: 'SSO login', stage: 'ba', owner: 'carol', due: '2026-10-20',
    acceptance: ['SSO supported'], dod: ['Test cases written'],
  })
  state = moveCard(state, { cardId: 'c1', toStage: 'dev', owner: 'erin', note: 'Design approved' })
  state = appendLog(state, { type: 'blocker', text: 'Client approval pending', cardId: 'c1' })
  const card = structuredClone(state.cards[0])
  const original = structuredClone(state)
  const archived = archiveCard(state, { cardId: 'c1' })
  const archivedSnapshot = structuredClone(archived)
  const restored = restoreCard(archived, { cardId: 'c1' })

  assert.deepEqual(state, original)
  assert.deepEqual(archived, archivedSnapshot)
  assert.equal(restored.version, 3)
  assert.deepEqual(restored.cards, [{ ...card, archivedAt: null }])
  assert.deepEqual(restored.logs.slice(0, -2), state.logs)
  assert.deepEqual(restored.logs.slice(0, -1), archived.logs)
  assert.equal(restored.logs.at(-1).type, 'decision')
  assert.equal(restored.logs.at(-1).cardId, 'c1')
  assert.match(restored.logs.at(-1).text, /restored/)
  assert.match(renderBoard(restored), /\[c1\] SSO login @erin/)
  assert.doesNotMatch(renderBoard(restored), /\[archived\]/)
})

test('archive and restore are idempotent and audit only actual transitions', () => {
  const state = addCard(createProject({ customer: 'ACME' }), { title: 'Feature', stage: 'dev' })
  assert.equal(restoreCard(state, { cardId: 'c1' }), state)
  const archived = archiveCard(state, { cardId: 'c1' })
  assert.equal(archived.logs.length, 1)
  assert.equal(archiveCard(archived, { cardId: 'c1' }), archived)
  const restored = restoreCard(archived, { cardId: 'c1' })
  assert.equal(restored.logs.length, 2)
  assert.equal(restoreCard(restored, { cardId: 'c1' }), restored)
  const rearchived = archiveCard(restored, { cardId: 'c1' })
  assert.equal(rearchived.logs.length, 3)
  assert.deepEqual(rearchived.logs.map((l) => l.type), ['decision', 'decision', 'decision'])
  assert.equal(rearchived.cards[0].id, 'c1')
})

test('moving or updating archived cards requires restoration first', () => {
  const initial = addCard(createProject({ customer: 'ACME' }), { title: 'Feature', stage: 'ba' })
  const archived = archiveCard(initial, { cardId: 'c1' })
  const snapshot = structuredClone(archived)
  assert.throws(() => moveCard(archived, { cardId: 'c1', toStage: 'dev', owner: 'erin' }), /archived.*restore.*first/)
  assert.throws(() => moveCard(archived, { cardId: 'c1', toStage: 'nope' }), /archived.*restore.*first/)
  for (const changes of [
    {}, { title: 'Changed' }, { owner: 'erin' }, { due: null },
    { acceptance: ['Approved'] }, { dod: ['Ready'] }, { due: 'not-a-date' },
  ]) {
    assert.throws(() => updateCard(archived, { cardId: 'c1', ...changes }), /archived.*restore.*first/)
  }
  assert.deepEqual(archived, snapshot)
  const restored = restoreCard(archived, { cardId: 'c1' })
  const edited = updateCard(restored, { cardId: 'c1', title: 'Changed' })
  assert.equal(edited.cards[0].title, 'Changed')
  assert.equal(moveCard(edited, { cardId: 'c1', toStage: 'dev' }).cards[0].stage, 'dev')
})

test('archive, restore and update reject unknown card IDs without changing state', () => {
  const state = addCard(createProject({ customer: 'ACME' }), { title: 'Feature', stage: 'dev' })
  const snapshot = structuredClone(state)
  for (const operation of [archiveCard, restoreCard, updateCard]) {
    assert.throws(() => operation(state, { cardId: 'c99', title: 'Changed' }), /unknown card: c99/)
  }
  assert.deepEqual(state, snapshot)
})

test('addCard allocates above the numeric maximum, including archived cards and gaps', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, { title: 'First', stage: 'dev' })
  state = addCard(state, { title: 'Second', stage: 'dev' })
  state = addCard(state, { title: 'Third', stage: 'dev' })
  state = archiveCard(state, { cardId: 'c3' })
  state = { ...state, cards: state.cards.filter((c) => c.id !== 'c2') }
  state = addCard(state, { title: 'Fourth', stage: 'dev' })
  assert.deepEqual(state.cards.map((c) => c.id), ['c1', 'c3', 'c4'])
  assert.equal(state.cards[1].archivedAt != null, true)

  // A legacy state without a sequence still uses numeric, not lexical, order.
  const legacy = createProject({ customer: 'ACME' })
  legacy.cards = [
    { ...state.cards[0], id: 'c9' },
    { ...state.cards[0], id: 'c10' },
    { ...state.cards[0], id: 'external-id' },
  ]
  assert.equal(addCard(legacy, { title: 'Eleventh', stage: 'dev' }).cards.at(-1).id, 'c11')
})

test('addCard does not reuse IDs when the highest card or all cards are removed externally', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, { title: 'First', stage: 'dev' })
  state = addCard(state, { title: 'Second', stage: 'dev' })
  state = { ...state, cards: state.cards.filter((c) => c.id !== 'c2') }
  state = addCard(state, { title: 'Third', stage: 'dev' })
  assert.equal(state.cards.at(-1).id, 'c3')
  state = { ...state, cards: [] }
  assert.equal(addCard(state, { title: 'Fourth', stage: 'dev' }).cards[0].id, 'c4')
})

test('addCard reserves IDs recorded in legacy history after external removals', () => {
  let state = createProject({ customer: 'ACME' })
  state = appendLog(state, { type: 'handoff', text: 'Removed card history', cardId: 'c12' })
  state = appendLog(state, { type: 'risk', text: 'Unlinked risk' })
  const added = addCard(state, { title: 'New feature', stage: 'dev' })
  assert.equal(added.cards[0].id, 'c13')
  assert.deepEqual(added.logs, state.logs)
})

test('weekly snapshots exclude archived cards while keeping in-window handoffs and historical risks', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, { title: 'Completed feature', stage: 'dev' })
  state = addCard(state, { title: 'Active feature', stage: 'dev' })
  state.logs = [
    { ts: new Date('2026-10-06T12:00:00').toISOString(), type: 'handoff', text: 'Completed feature handoff', cardId: 'c1' },
    { ts: '2026-01-01T00:00:00Z', type: 'handoff', text: 'Old handoff', cardId: 'c1' },
    { ts: '2026-01-01T00:00:00Z', type: 'risk', text: 'Historical unresolved risk', cardId: 'c1' },
  ]
  const history = structuredClone(state.logs)
  const archived = archiveCard(state, { cardId: 'c1' })
  const report = renderWeekly(archived, 'Test period', '2026-10-05')
  assert.match(report, /- Development: 1 card\(s\)/)
  assert.match(report, /2026-10-05.*2026-10-11/)
  assert.match(report, /Completed feature handoff/)
  assert.match(report, /Historical unresolved risk/)
  assert.doesNotMatch(report, /Old handoff/)
  assert.deepEqual(archived.logs.slice(0, -1), history)
  assert.match(renderWeekly(restoreCard(archived, { cardId: 'c1' }), '', '2026-10-05'), /- Development: 2 card\(s\)/)
})

test('updateCard edits partial fields immutably without moving cards or changing identity', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, {
    title: 'Feature', stage: 'ba', owner: 'carol', due: '2026-10-20',
    acceptance: ['Original criterion'], dod: ['Original DoD'],
  })
  state = addCard(state, { title: 'Other feature', stage: 'dev' })
  state = appendLog(state, { type: 'progress', text: 'Spec ready', cardId: 'c1' })
  const snapshot = structuredClone(state)
  const edited = updateCard(state, { cardId: 'c1', title: '  Updated feature  ' })
  assert.deepEqual(state, snapshot)
  assert.notEqual(edited, state)
  assert.notEqual(edited.cards, state.cards)
  assert.notEqual(edited.cards[0], state.cards[0])
  assert.equal(edited.cards[1], state.cards[1])
  assert.deepEqual(edited.cards[0], { ...state.cards[0], title: 'Updated feature' })
  assert.deepEqual(edited.logs.slice(0, -1), state.logs)
  assert.equal(edited.logs.at(-1).type, 'decision')
  assert.equal(edited.logs.at(-1).cardId, 'c1')
  assert.equal(edited.logs.at(-1).ts, edited.updatedAt)
  assert.match(edited.logs.at(-1).text, /updated: title/)

  const allFields = updateCard(edited, {
    cardId: 'c1', owner: '  erin  ', due: '2028-02-29',
    acceptance: '  New criterion  \n\nSecond criterion', dod: ['  Ready  ', '', 'Tested'],
  })
  assert.deepEqual(allFields.cards[0], {
    ...edited.cards[0], owner: 'erin', due: '2028-02-29',
    acceptance: ['New criterion', 'Second criterion'],
    dod: [{ text: 'Ready', done: false }, { text: 'Tested', done: false }],
  })
  assert.equal(allFields.logs.length, edited.logs.length + 1)
  assert.match(allFields.logs.at(-1).text, /updated: owner, due, acceptance, dod/)
})

test('updateCard supports explicit clears and leaves omitted or undefined fields unchanged', () => {
  const state = addCard(createProject({ customer: 'ACME' }), {
    title: 'Feature', stage: 'dev', owner: 'erin', due: '2026-10-20',
    acceptance: ['Confirmed'], dod: ['Tested'],
  })
  const cleared = updateCard(state, { cardId: 'c1', owner: null, due: null, acceptance: null, dod: [] })
  assert.deepEqual(cleared.cards[0], { ...state.cards[0], owner: '', due: null, acceptance: [], dod: [] })
  assert.equal(cleared.logs.length, 1)
  assert.equal(updateCard(state, { cardId: 'c1' }), state)
  assert.equal(updateCard(state, { cardId: 'c1', title: undefined, owner: undefined, due: undefined, acceptance: undefined, dod: undefined }), state)
  assert.equal(updateCard(state, {
    cardId: 'c1', title: ' Feature ', owner: ' erin ', due: '2026-10-20', acceptance: 'Confirmed', dod: ['Tested'],
  }), state)
  assert.equal(state.logs.length, 0)
})

test('updateCard rejects empty titles and ignores fields outside its editable API', () => {
  const state = addCard(createProject({ customer: 'ACME' }), { title: 'Feature', stage: 'ba' })
  for (const title of ['', '  ', null]) {
    assert.throws(() => updateCard(state, { cardId: 'c1', title }), /title is required/)
  }
  assert.equal(updateCard(state, {
    cardId: 'c1', id: 'c9', stage: 'dev', archivedAt: new Date().toISOString(), createdAt: 'changed',
  }), state)
})

test('addCard and updateCard consistently reject invalid due dates and accept actual calendar dates', () => {
  const initial = createProject({ customer: 'ACME' })
  const state = addCard(initial, { title: 'Feature', stage: 'dev', due: '2026-10-20' })
  const snapshot = structuredClone(state)
  for (const due of [
    'not-a-date', '2026-02-29', '2026-02-30', '2026-04-31', '1900-02-29',
    '2026-13-01', '2026-00-10', '2026-10-00', '2026-1-01',
    '2026-10-20T00:00:00Z', ' 2026-10-20 ', 0, false, ['2026-10-20'], {},
  ]) {
    assert.throws(() => addCard(initial, { title: 'Bad date', stage: 'dev', due }), /due.*valid date.*YYYY-MM-DD/)
    assert.throws(() => updateCard(state, { cardId: 'c1', title: 'Changed', due }), /due.*valid date.*YYYY-MM-DD/)
  }
  // Empty string clears due (same as null) rather than rejecting.
  assert.equal(addCard(initial, { title: 'Cleared due', stage: 'dev', due: '' }).cards[0].due, null)
  assert.deepEqual(state, snapshot)
  assert.deepEqual(initial.cards, [])
  assert.equal(addCard(initial, { title: 'Leap day', stage: 'dev', due: '2000-02-29' }).cards[0].due, '2000-02-29')
  assert.equal(updateCard(state, { cardId: 'c1', due: '2028-02-29' }).cards[0].due, '2028-02-29')
  assert.equal(addCard(initial, { title: 'No due date', stage: 'dev', due: null }).cards[0].due, null)
  assert.equal(addCard(initial, { title: 'Default due date', stage: 'dev' }).cards[0].due, null)
})

test('version 3 cards missing archivedAt or using null remain active without migration', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, { title: 'Legacy feature', stage: 'dev' })
  state = addCard(state, { title: 'Null archive feature', stage: 'dev' })
  state.cards[1] = { ...state.cards[1], archivedAt: null }
  delete state.lastCardNumber
  const snapshot = structuredClone(state)

  assert.equal(Object.hasOwn(state.cards[0], 'archivedAt'), false)
  assert.match(renderBoard(state), /\[c1\] Legacy feature/)
  assert.match(renderBoard(state), /\[c2\] Null archive feature/)
  assert.match(renderBoard(state), /## Development \(Dev\) · 2\n/)
  assert.match(renderBoard(state, { includeArchived: true }), /Cards: 2 active \/ 0 archived/)
  assert.match(renderWeekly(state, '', '2026-10-05'), /- Development: 2 card\(s\)/)
  assert.equal(restoreCard(state, { cardId: 'c1' }), state)
  assert.equal(restoreCard(state, { cardId: 'c2' }), state)
  assert.equal(updateCard(state, { cardId: 'c1', owner: 'erin' }).cards[0].owner, 'erin')
  assert.equal(moveCard(state, { cardId: 'c2', toStage: 'test' }).cards[1].stage, 'test')
  assert.equal(addCard(state, { title: 'Next feature', stage: 'dev' }).cards.at(-1).id, 'c3')
  assert.equal(archiveCard(state, { cardId: 'c2' }).cards[1].archivedAt != null, true)
  assert.deepEqual(state, snapshot)
  assert.equal(state.version, 3)
})

test('same-stage owner change records a decision, not a handoff, and stays out of the weekly report', async () => {
  const { applyAction } = await import('../lib/actions.js')
  let state = addCard(createProject({ customer: 'ACME' }), { title: 'Feature', stage: 'dev', owner: 'carol' })
  const before = state.logs.length
  state = moveCard(state, { cardId: 'c1', toStage: 'dev', owner: 'dave' })
  assert.equal(state.cards[0].stage, 'dev')
  assert.equal(state.cards[0].owner, 'dave')
  assert.equal(state.logs.length, before + 1)
  const entry = state.logs.at(-1)
  assert.equal(entry.type, 'decision')
  assert.equal(entry.cardId, 'c1')
  assert.match(entry.text, /owner changed: carol → dave \(stage unchanged: Development\)/)
  assert.equal(state.logs.some((l) => l.type === 'handoff'), false)
  const weekly = renderWeekly(state) // current week, which contains the entry above
  assert.doesNotMatch(weekly, /Development → Development/)
  assert.match(weekly, /## Handoffs this week\n- none/)

  // Same path through the shared action layer (tools, slash commands, live board).
  const viaAction = applyAction(state, 'move', { card_id: 'c1', to_stage: 'dev', owner: 'erin', note: 'rebalanced' })
  assert.equal(viaAction.logs.at(-1).type, 'decision')
  assert.match(viaAction.logs.at(-1).text, /dave → erin .*: rebalanced$/)
  // Unchanged owner and no note is a no-op.
  assert.equal(applyAction(state, 'move', { card_id: 'c1', to_stage: 'dev', owner: 'dave' }), state)
  assert.equal(moveCard(state, { cardId: 'c1', toStage: 'dev' }), state)
  // A real stage change still records a handoff.
  const handed = moveCard(state, { cardId: 'c1', toStage: 'test', owner: 'erin' })
  assert.equal(handed.logs.at(-1).type, 'handoff')
  assert.match(handed.logs.at(-1).text, /Development → Testing/)
})

test('renderWeekly omits Next bets when empty and includes optional next-bet notes', () => {
  const state = createProject({ customer: 'ACME' })
  const bare = renderWeekly(state, 'Week', '2026-10-05')
  assert.doesNotMatch(bare, /## Next bets|TODO/)
  assert.match(bare, /## Risks & blockers\n- none/)
  const withNotes = renderWeekly(state, 'Week', '2026-10-05', 'Ship SSO\nClient demo')
  assert.match(withNotes, /## Next bets\n- Ship SSO\n- Client demo/)
  const asArray = renderWeekly(state, 'Week', '2026-10-05', ['Prep UAT', '  '])
  assert.match(asArray, /## Next bets\n- Prep UAT\n/)
  assert.doesNotMatch(asArray, /## Next bets\n- Prep UAT\n-\n/)
})

test('resolveLog marks risk/blocker resolved; board and weekly only show open items', () => {
  let state = createProject({ customer: 'ACME' })
  state = addCard(state, { title: 'SSO', stage: 'dev' })
  state = appendLog(state, { type: 'progress', text: 'Working', cardId: 'c1' })
  state = appendLog(state, { type: 'risk', text: 'Understaffed', cardId: 'c1' })
  state = appendLog(state, { type: 'blocker', text: 'Waiting on UAT', cardId: 'c1' })
  // Legacy entry without resolvedAt stays open
  state.logs.push({ ts: '2026-01-01T00:00:00Z', type: 'risk', text: 'Legacy open risk' })

  assert.match(renderBoard(state), /Open risks \/ blockers · 3/)
  assert.match(renderBoard(state), /Understaffed/)
  assert.match(renderWeekly(state, '', '2026-10-05'), /Understaffed/)
  assert.match(renderWeekly(state, '', '2026-10-05'), /Legacy open risk/)

  const resolved = resolveLog(state, { index: 1 })
  assert.notEqual(resolved, state)
  assert.ok(resolved.logs[1].resolvedAt)
  assert.equal(resolved.logs[1].resolvedAt, resolved.updatedAt)
  assert.equal(resolved.logs[2].resolvedAt, undefined)
  assert.doesNotMatch(renderBoard(resolved), /Understaffed/)
  assert.match(renderBoard(resolved), /Open risks \/ blockers · 2/)
  assert.match(renderBoard(resolved), /Waiting on UAT/)
  assert.doesNotMatch(renderWeekly(resolved, '', '2026-10-05'), /Understaffed/)
  assert.match(renderWeekly(resolved, '', '2026-10-05'), /Waiting on UAT/)

  // Idempotent
  assert.equal(resolveLog(resolved, { index: 1 }), resolved)
  assert.throws(() => resolveLog(state, { index: 0 }), /not a risk or blocker/)
  assert.throws(() => resolveLog(state, { index: 99 }), /unknown log index/)
  assert.throws(() => resolveLog(state, { index: -1 }), /unknown log index/)
  assert.throws(() => resolveLog(state, { index: 1.5 }), /unknown log index/)
})

test('applyAction resolve and log share the board/tool mutation path', async () => {
  const { applyAction } = await import('../lib/actions.js')
  let state = appendLog(createProject({ customer: 'ACME' }), { type: 'blocker', text: 'Blocked' })
  state = applyAction(state, 'log', { type: 'risk', text: 'Schedule slip', card_id: 'c1' })
  assert.equal(state.logs.length, 2)
  state = applyAction(state, 'resolve', { log_index: 0 })
  assert.ok(state.logs[0].resolvedAt)
  assert.equal(state.logs[1].resolvedAt, undefined)
  assert.throws(() => applyAction(state, 'resolve', { log_index: '0' }), /log_index must be a non-negative integer/)
})

test('normalizeDodItems migrates legacy strings and setDodDone ticks items', () => {
  assert.deepEqual(normalizeDodItems('A\nB'), [
    { text: 'A', done: false },
    { text: 'B', done: false },
  ])
  assert.deepEqual(normalizeDodItems(['A', { text: 'B', done: true, doneAt: '2026-11-02T09:00:00.000Z', doneBy: 'Ada' }]), [
    { text: 'A', done: false },
    { text: 'B', done: true, doneAt: '2026-11-02T09:00:00.000Z', doneBy: 'Ada' },
  ])
  let state = createProject({ customer: 'ACME', template: 'lite' })
  state = addCard(state, { title: 'Feature', stage: 'doing', owner: 'Ada', dod: ['PRD', 'Tests'] })
  assert.deepEqual(dodProgress(state.cards[0]), { done: 0, total: 2 })
  const checked = setDodDone(state, { cardId: 'c1', index: 0, done: true })
  assert.equal(checked.cards[0].dod[0].done, true)
  assert.ok(checked.cards[0].dod[0].doneAt)
  assert.equal(checked.cards[0].dod[0].doneBy, 'Ada')
  assert.deepEqual(dodProgress(checked.cards[0]), { done: 1, total: 2 })
  // Ticking never blocks moves.
  assert.equal(moveCard(checked, { cardId: 'c1', toStage: 'review' }).cards[0].stage, 'review')
  assert.equal(setDodDone(checked, { cardId: 'c1', index: 0, done: true }), checked)
  const added = addDodItem(checked, { cardId: 'c1', text: 'Docs' })
  assert.equal(added.cards[0].dod.length, 3)
  assert.throws(() => setDodDone(state, { cardId: 'c1', index: 9 }), /unknown DoD index/)
})

test('start must be on or before due', () => {
  const state = createProject({ customer: 'ACME', template: 'lite' })
  assert.throws(
    () => addCard(state, { title: 'Bad', stage: 'doing', start: '2026-11-10', due: '2026-11-01' }),
    /start \(2026-11-10\) must be on or before due \(2026-11-01\)/,
  )
  const ok = addCard(state, { title: 'Ok', stage: 'doing', start: '2026-11-01', due: '2026-11-10' })
  assert.equal(ok.cards[0].start, '2026-11-01')
  assert.throws(
    () => updateCard(ok, { cardId: 'c1', start: '2026-11-20' }),
    /start \(2026-11-20\) must be on or before due \(2026-11-10\)/,
  )
})

test('archiveBoard snapshots then resets empty board keeping pipeline', () => {
  let state = createProject({ customer: 'Tiffany', template: 'default' })
  state = addCard(state, { title: 'A', stage: 'ba' })
  state = appendLog(state, { type: 'risk', text: 'Slip' })
  state = setStageHidden(state, { stageId: 'ba', hidden: true })
  const { archive, next } = archiveBoard(state)
  assert.equal(archive.customer, 'Tiffany')
  assert.equal(archive.cards.length, 1)
  assert.equal(archive.logs.length, 1)
  assert.ok(archive.archivedAt)
  assert.equal(next.customer, 'Tiffany')
  assert.equal(next.template, 'default')
  assert.deepEqual(next.pipeline.map((s) => s.id), state.pipeline.map((s) => s.id))
  assert.deepEqual(next.cards, [])
  assert.deepEqual(next.logs, [])
  assert.deepEqual(next.hiddenStages, ['ba'])
  assert.equal(archiveBoardSlug('Tiffany Cosmetics'), 'tiffany-cosmetics')
})

test('pipeline stages can be added, updated and removed safely after init', () => {
  let state = createProject({ customer: 'ACME', template: 'governance' })
  state = addCard(state, { title: 'On build', stage: 'build' })
  const added = addStage(state, { name: 'Hardening', after: 'test', role: 'Sec', gates: ['Scan clean'] })
  assert.equal(added.template, 'custom')
  assert.ok(added.pipeline.some((s) => s.id === 'hardening' && s.name === 'Hardening' && s.gates === undefined))
  assert.match(added.logs.at(-1).text, /Stage "Hardening"/)

  const renamed = updateStage(added, { stageId: 'hardening', name: 'Security Hardening', role: 'Security' })
  assert.equal(renamed.pipeline.find((s) => s.id === 'hardening').name, 'Security Hardening')
  assert.equal(renamed.pipeline.find((s) => s.id === 'hardening').role, 'Security')
  assert.equal(renamed.pipeline.find((s) => s.id === 'hardening').gates, undefined)

  assert.throws(() => removeStage(added, { stageId: 'build' }), /still has 1 card/)
  const migrated = removeStage(added, { stageId: 'build', migrateTo: 'test' })
  assert.equal(migrated.cards[0].stage, 'test')
  assert.equal(migrated.pipeline.some((s) => s.id === 'build'), false)
  const emptied = removeStage(migrated, { stageId: 'hardening' })
  assert.equal(emptied.pipeline.some((s) => s.id === 'hardening'), false)
  const only = createProject({ customer: 'X', stages: [{ name: 'Solo' }] })
  assert.throws(() => removeStage(only, { stageId: only.pipeline[0].id }), /last stage/)
})

test('soft WIP limits warn on board and weekly without blocking moves', () => {
  let state = createProject({ customer: 'ACME', template: 'governance' })
  state = updateStage(state, { stageId: 'build', wipLimit: 1 })
  assert.equal(state.pipeline.find((s) => s.id === 'build').wipLimit, 1)
  state = addCard(state, { title: 'One', stage: 'build' })
  state = addCard(state, { title: 'Two', stage: 'build' })
  const board = renderBoard(state)
  assert.match(board, /WIP 2\/1 ⚠ over/)
  assert.match(board, /Soft WIP warnings · 1/)
  assert.match(board, /Build \(build\): 2\/1 WIP/)
  // Soft: move into an over-limit stage still works.
  state = addCard(state, { title: 'Incoming', stage: 'design' })
  const moved = moveCard(state, { cardId: 'c3', toStage: 'build' })
  assert.equal(moved.cards.find((c) => c.id === 'c3').stage, 'build')
  assert.match(renderBoard(moved), /WIP 3\/1 ⚠ over/)
  assert.match(renderWeekly(moved, '', '2026-10-05'), /Build: 3 card\(s\) \(WIP 3\/1 over\)/)
  const cleared = updateStage(moved, { stageId: 'build', wipLimit: null })
  assert.equal(cleared.pipeline.find((s) => s.id === 'build').wipLimit, undefined)
  assert.doesNotMatch(renderBoard(cleared), /WIP |Soft WIP/)
  assert.throws(() => updateStage(state, { stageId: 'build', wipLimit: 0 }), /wipLimit must be a positive integer/)
})

test('weekly report lists shipped, risk burn-down and next bets', () => {
  let state = createProject({ customer: 'ACME', template: 'governance' })
  state = addCard(state, { title: 'Go live feature', stage: 'deploy' })
  state = addCard(state, { title: 'Parked item', stage: 'build' })
  state = moveCard(state, { cardId: 'c1', toStage: 'live', note: 'released' })
  // Force handoff into the reporting window
  state = {
    ...state,
    logs: state.logs.map((l) => (
      l.type === 'handoff' ? { ...l, ts: new Date('2026-10-07T10:00:00').toISOString() } : l
    )),
  }
  state = appendLog(state, { type: 'risk', text: 'Vendor delay', cardId: 'c1' })
  state = resolveLog(state, { index: state.logs.length - 1 })
  state = {
    ...state,
    logs: state.logs.map((l, i) => (
      i === state.logs.length - 1 ? { ...l, resolvedAt: new Date('2026-10-08T12:00:00').toISOString() } : l
    )),
  }
  state = archiveCard(state, { cardId: 'c2' })
  state = {
    ...state,
    cards: state.cards.map((c) => (
      c.id === 'c2' ? { ...c, archivedAt: new Date('2026-10-09T09:00:00').toISOString() } : c
    )),
    logs: state.logs.map((l) => (
      l.text.includes('archived') ? { ...l, ts: new Date('2026-10-09T09:00:00').toISOString() } : l
    )),
  }
  const report = renderWeekly(state, 'Week', '2026-10-05', 'Bet on SSO\nBet on billing')
  assert.match(report, /## Shipped this week\n- \[c1\] Go live feature → Live\n- \[c2\] Parked item \(archived\)/)
  assert.match(report, /## Risks resolved this week\n- \[risk\] Vendor delay/)
  assert.match(report, /## Next bets\n- Bet on SSO\n- Bet on billing/)
  assert.doesNotMatch(report, /## Next week/)
  const empty = renderWeekly(createProject({ customer: 'X' }), '', '2026-10-05')
  assert.match(empty, /## Shipped this week\n- none/)
  assert.match(empty, /## Risks resolved this week\n- none/)
  assert.doesNotMatch(empty, /## Next bets/)
})

test('resolve stage by name (case-insensitive) and list candidates on miss', () => {
  const s = createProject({ customer: 'X', template: 'lite' })
  const withCard = addCard(s, { title: 'API', stage: 'Doing' })
  assert.equal(withCard.cards[0].stage, 'doing')
  const moved = moveCard(withCard, { cardId: 'API', toStage: 'review' })
  assert.equal(moved.cards[0].stage, 'review')
  assert.equal(moved.logs.at(-1).cardId, 'c1')
  assert.throws(() => addCard(s, { title: 'x', stage: 'nope' }), /Candidates:/)
  assert.throws(() => moveCard(withCard, { cardId: 'missing', toStage: 'doing' }), /Candidates:/)
})

test('ambiguous card title lists matches', () => {
  let s = createProject({ customer: 'X', template: 'lite' })
  s = addCard(s, { title: 'Dup', stage: 'backlog' })
  s = addCard(s, { title: 'Dup', stage: 'doing' })
  assert.throws(() => moveCard(s, { cardId: 'Dup', toStage: 'review' }), /ambiguous card/)
})

test('stage after=name and migrate_to=name resolve', () => {
  let s = createProject({ customer: 'X', template: 'lite' })
  s = addCard(s, { title: 'A', stage: 'doing' })
  s = addStage(s, { name: 'Hardening', after: 'Doing' })
  assert.ok(s.pipeline.some((x) => x.name === 'Hardening'))
  const doingIdx = s.pipeline.findIndex((x) => x.id === 'doing')
  assert.equal(s.pipeline[doingIdx + 1].name, 'Hardening')
  const hid = s.pipeline.find((x) => x.name === 'Hardening').id
  s = moveCard(s, { cardId: 'A', toStage: 'Hardening' })
  assert.equal(s.cards.find((c) => c.title === 'A').stage, hid)
  s = removeStage(s, { stageId: 'Hardening', migrateTo: 'Doing' })
  assert.ok(!s.pipeline.some((x) => x.name === 'Hardening'))
  assert.equal(s.cards.find((c) => c.title === 'A').stage, 'doing')
})

test('setStageHidden persists view preference and scrubbing on removeStage', () => {
  let state = createProject({ customer: 'Hide', template: 'lite' })
  state = addCard(state, { title: 'A', stage: 'doing' })
  const hidden = setStageHidden(state, { stageId: 'Backlog', hidden: true })
  assert.deepEqual(hidden.hiddenStages, ['backlog'])
  assert.equal(setStageHidden(hidden, { stageId: 'backlog', hidden: true }), hidden)
  const shown = setStageHidden(hidden, { stageId: 'backlog', hidden: false })
  assert.equal(shown.hiddenStages, undefined)
  let withHidden = setStageHidden(state, { stageId: 'review', hidden: true })
  withHidden = setStageHidden(withHidden, { stageId: 'live', hidden: true })
  const removed = removeStage(withHidden, { stageId: 'review' })
  assert.deepEqual(removed.hiddenStages, ['live'])
  assert.ok(!removed.pipeline.some((stage) => stage.id === 'review'))
  // Weekly ignores hide preference (still reports the card stage).
  const week = renderWeekly(setStageHidden(state, { stageId: 'doing', hidden: true }), '', '2020-01-06')
  assert.match(week, /Doing|doing|A/)
})

test('addCard stores trimmed description and omits empty', () => {
  let state = createProject({ customer: 'D', template: 'lite' })
  state = addCard(state, { title: 'A', stage: 'doing', description: '  hello  ' })
  assert.equal(state.cards[0].description, 'hello')
  state = addCard(state, { title: 'B', stage: 'doing', description: '   ' })
  assert.equal(state.cards[1].description, undefined)
  assert.ok(!('description' in state.cards[1]))
})

test('updateCard sets and clears description', () => {
  let state = createProject({ customer: 'D', template: 'lite' })
  state = addCard(state, { title: 'A', stage: 'doing', description: 'first' })
  state = updateCard(state, { cardId: 'c1', description: '  second  ' })
  assert.equal(state.cards[0].description, 'second')
  state = updateCard(state, { cardId: 'c1', description: '' })
  assert.equal(state.cards[0].description, undefined)
  assert.ok(!('description' in state.cards[0]))
})

test('auto logs keep English text and structured event for display localization', () => {
  let state = createProject({ customer: 'ACME', template: 'lite' })
  state = addCard(state, { title: 'API', stage: 'backlog', owner: 'Ada' })
  state = moveCard(state, { cardId: 'c1', toStage: 'doing', note: 'go' })
  const handoff = state.logs.at(-1)
  assert.equal(handoff.type, 'handoff')
  assert.equal(handoff.text, '"API" moved from Backlog → Doing: go')
  assert.deepEqual(handoff.event, {
    kind: 'move', title: 'API', from: 'Backlog', to: 'Doing', fromId: 'backlog', toId: 'doing', note: 'go',
  })
  state = archiveCard(state, { cardId: 'c1' })
  assert.equal(state.logs.at(-1).event.kind, 'archive')
  assert.equal(state.logs.at(-1).text, '"API" archived')
})
