// dsh-voice-mic 一键部署端到端测试：
// 用 mock ctx 驱动 host 插件，在 7861 端口完整走一遍部署流程并清理
const registered = [];
const ctx = {
  webServer: { register: (spec) => { registered.push(spec); return () => {}; } },
  effect: (fn) => { fn(); return () => {}; },
};

const mod = await import('../lib/index.js');
mod.apply(ctx, { port: 7862 });

const responses = [];
const res = {
  writeHead: (status) => { responses.push({ status }); },
  end: (body) => { responses[responses.length - 1].body = body; },
};
const req = (path, method = 'GET') => ({
  method,
  url: path,
  headers: { host: '127.0.0.1:3080' },
  async *[Symbol.asyncIterator]() { /* 空请求体 */ },
});
const handler = registered[0].handler;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

console.log('触发一键部署…');
await handler(req('/dsh-voice-mic/v1/backend/deploy', 'POST'), res);
if (responses[responses.length - 1].status !== 202) {
  console.error('deploy 未返回 202');
  process.exit(1);
}

let finalJob = null;
for (let i = 0; i < 90; i++) {
  await sleep(2000);
  responses.length = 0;
  await handler(req('/dsh-voice-mic/v1/backend/status'), res);
  const st = JSON.parse(responses[0].body);
  const job = st.job ?? {};
  const logTail = (job.log ?? []).slice(-2).join(' | ');
  console.log(`[${i}] state=${job.state} progress=${(job.progress ?? 0).toFixed(2)} ${logTail}`);
  finalJob = job;
  if (job.state === 'done' || job.state === 'error') break;
}

if (!finalJob || finalJob.state !== 'done') {
  console.error(`部署未成功（state=${finalJob?.state} message=${finalJob?.message}）`);
  process.exit(1);
}

// 再查一次状态确认服务健康
responses.length = 0;
await handler(req('/dsh-voice-mic/v1/backend/status'), res);
const st = JSON.parse(responses[0].body);
console.log(`运行状态: running=${st.running} ready=${st.health?.ready} python=${st.python.version} deps=${st.deps} model=${st.model.ready}`);

// 清理：停止后端
await handler(req('/dsh-voice-mic/v1/backend/stop', 'POST'), res);
await sleep(1500);
responses.length = 0;
await handler(req('/dsh-voice-mic/v1/backend/status'), res);
const st2 = JSON.parse(responses[0].body);
console.log(`停止后: running=${st2.running}`);
console.log('\n✓ 一键部署端到端测试通过');
