// dsh-voice-mic 激活验证脚本：在「重启 dsh web 之后」运行
// 检查：客户端 bundle 可下发、host 路由已注册、配置合并正确
// 用法：node test/verify-install.mjs [baseUrl]   （默认 http://127.0.0.1:3080）
const base = (process.argv[2] ?? 'http://127.0.0.1:3080').replace(/\/+$/, '');
const results = [];

async function check(name, fn) {
  try {
    await fn();
    results.push(['PASS', name]);
  } catch (err) {
    results.push(['FAIL', `${name} — ${err.message}`]);
  }
}

await check('客户端 bundle 可下发（/plugins/dsh-voice-mic/client.js 200）', async () => {
  const res = await fetch(`${base}/plugins/dsh-voice-mic/client.js`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  if (!text.includes('dsh-voice-mic')) throw new Error('内容不含插件 id');
  if (!text.includes('__ModuleLoader__')) throw new Error('内容不是自注册脚本');
});

await check('host 配置路由（/dsh-voice-mic/v1/config 返回 JSON）', async () => {
  const res = await fetch(`${base}/dsh-voice-mic/v1/config`);
  const ct = res.headers.get('content-type') ?? '';
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  if (!ct.includes('application/json')) throw new Error(`content-type=${ct}（可能是 SPA 回退页，host 未加载插件）`);
  const data = await res.json();
  if (!data.ok) throw new Error('ok 字段为假');
  if (typeof data.hotkey !== 'string' || typeof data.lang !== 'string') throw new Error('配置字段缺失');
});

await check('host 健康路由（/dsh-voice-mic/v1/health）', async () => {
  const res = await fetch(`${base}/dsh-voice-mic/v1/health`);
  const ct = res.headers.get('content-type') ?? '';
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  if (!ct.includes('application/json')) throw new Error(`content-type=${ct}`);
  const data = await res.json();
  if (!data.ok || data.plugin !== 'dsh-voice-mic') throw new Error('health 载荷不对');
});

for (const [status, name] of results) console.log(`[${status}] ${name}`);
const failed = results.filter(([s]) => s === 'FAIL').length;
console.log(failed === 0 ? '\n全部通过：插件已激活 ✓' : `\n${failed} 项失败：若刚安装请先重启 dsh web`);
process.exit(failed === 0 ? 0 : 1);
