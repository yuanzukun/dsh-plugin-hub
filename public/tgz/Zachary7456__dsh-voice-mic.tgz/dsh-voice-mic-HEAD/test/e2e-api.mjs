// dsh-voice-mic 云端 API 链路测试：完全按插件 apiTranscribe 的协议发请求
// 用法：node test/e2e-api.mjs [apiBase 默认 http://127.0.0.1:7861] [key 默认 test]
import assert from 'node:assert/strict';

const [,, baseArg = 'http://127.0.0.1:7861/v1', key = 'test', model = 'mock-model'] = process.argv;
const base = baseArg.replace(/\/+$/, '');

// 与 lib/client.js encodeWav16kMono 一致的 0.8 秒静音 WAV
const n = Math.floor(16000 * 0.8);
const buffer = new ArrayBuffer(44 + n * 2);
const view = new DataView(buffer);
const writeStr = (o, s) => { for (let i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i)); };
writeStr(0, 'RIFF');
view.setUint32(4, 36 + n * 2, true);
writeStr(8, 'WAVE');
writeStr(12, 'fmt ');
view.setUint32(16, 16, true);
view.setUint16(20, 1, true);
view.setUint16(22, 1, true);
view.setUint32(24, 16000, true);
view.setUint32(28, 32000, true);
view.setUint16(32, 2, true);
view.setUint16(34, 16, true);
writeStr(36, 'data');
view.setUint32(40, n * 2, true);
const wav = new Blob([buffer], { type: 'audio/wav' });

const form = new FormData();
form.append('file', wav, 'audio.wav');
form.append('model', model);
form.append('response_format', 'json');
form.append('language', 'zh-cn');

const resp = await fetch(`${base}/audio/transcriptions`, {
  method: 'POST',
  headers: { authorization: `Bearer ${key}` },
  body: form,
});
console.log(`HTTP ${resp.status}`);
const data = await resp.json().catch(() => ({}));
console.log('响应:', JSON.stringify(data));
assert.equal(resp.ok, true, '请求应成功');
assert.equal(typeof data.text, 'string', '应返回 text 字段');
assert.ok(data.text.length > 0, '模拟服务器应返回非空文本');
console.log('\n✓ 云端 API 链路（multipart 上传 + 响应解析）正常');
