// dsh-voice-mic 冒烟测试：在 Node 里 mock 浏览器 / cordis ctx，验证两个半插件可加载
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const clientPath = fileURLToPath(new URL('../lib/client.js', import.meta.url));

// ---------- 1. client 半：mock window/document/React ----------
const captured = {};
const styleEls = [];
global.window = {
  __ModuleLoader__: { load: (spec) => { captured.spec = spec; } },
  addEventListener: () => {},
  removeEventListener: () => {},
};
global.document = {
  querySelector: () => null,
  createElement: (tag) => ({ tag, dataset: {}, style: {}, textContent: '', appendChild() {} }),
  head: { appendChild() {} },
  body: { appendChild() {} },
};
global.localStorage = { getItem: () => null, setItem: () => {} };
global.requestAnimationFrame = (fn) => fn();
global.setTimeout = setTimeout;
global.clearTimeout = clearTimeout;
global.fetch = async () => { throw new Error('no network in smoke test'); };

const reactStub = {
  createElement: (type, props, ...children) => ({ type, props, children }),
  useState: (initial) => [initial, () => {}],
  useRef: (initial) => ({ current: initial }),
  useCallback: (fn) => fn,
  useEffect: () => {},
};

require(clientPath); // 执行自注册脚本：只应注册 factory，不抛错
assert.ok(captured.spec, 'client bundle 应调用 window.__ModuleLoader__.load');
assert.equal(captured.spec.id, 'dsh-voice-mic');

const mod = {};
const fakeRequire = (name) => {
  if (name === 'react') return reactStub;
  throw new Error(`unexpected require: ${name}`);
};
const api = captured.spec.factory(fakeRequire);
assert.equal(typeof api.apply, 'function', 'client 应导出 apply');
assert.deepEqual([...api.inject].sort(), ['conversation', 'sessions', 'slots'], 'client inject 应含 slots/conversation/sessions');
console.log('✓ client 半：factory 注册与导出形状正确');

// ---------- 2. server 半：mock cordis ctx ----------
const { name, inject, apply } = await import('../lib/index.js');
assert.equal(name, 'dsh-voice-mic');
assert.deepEqual([...inject], ['webServer']);

const registered = [];
const effects = [];
const ctx = {
  webServer: { register: (spec) => { registered.push(spec); return () => {}; } },
  effect: (fn, label) => { effects.push(label); fn(); return () => {}; },
};
apply(ctx, { hotkey: 'alt+x' });
assert.equal(registered.length, 1, '应注册 webServer 路由');
assert.equal(registered[0].kind, 'prefix');
assert.equal(registered[0].path, '/dsh-voice-mic/v1');

// 直接驱动 handler，验证 /config 合并逻辑（config > env > 默认）
const responses = [];
const res = {
  writeHead: (status, headers) => responses.push({ status, headers }),
  end: (body) => responses[responses.length - 1].body = body,
};
const req = (path, headers = {}) => ({
  method: 'GET',
  url: path,
  headers: { host: '127.0.0.1:3080', ...headers },
});
await registered[0].handler(req('/dsh-voice-mic/v1/config'), res);
const cfg = JSON.parse(responses[0].body);
assert.equal(cfg.hotkey, 'alt+x', 'config 覆盖生效');
assert.equal(cfg.lang, 'zh-CN', '默认值兜底');
assert.equal(cfg.maxDurationSec, 120);

responses.length = 0;
await registered[0].handler(req('/dsh-voice-mic/v1/config', { 'sec-fetch-site': 'cross-site' }), res);
assert.equal(responses[0].status, 403, 'cross-site 应被拒绝');
console.log('✓ server 半：路由注册、配置合并与信任校验正常');

// /backend/status 路由存在且返回结构正确（python/模型/服务状态视环境而定，不深断言）
responses.length = 0;
await registered[0].handler(req('/dsh-voice-mic/v1/backend/status'), res);
const st = JSON.parse(responses[0].body);
assert.equal(st.ok, true, 'backend/status 应返回 ok');
assert.equal(typeof st.python, 'object');
assert.equal(typeof st.model, 'object');
assert.equal(typeof st.running, 'boolean');
assert.ok(st.baseUrl.startsWith('http://127.0.0.1:'), 'baseUrl 应为本地地址');
console.log('✓ server 半：backend/status 路由结构正常');

console.log('\n冒烟测试全部通过');
