#!/usr/bin/env pwsh
# dsh-voice-mic 模型下载与布置脚本（Windows PowerShell）
# 用法：./test/setup-model.ps1 [-ModelDir <目录>]  默认 ~/.dsh/voice/sensevoice
param(
  [string]$ModelDir = (Join-Path $HOME ".dsh\voice\sensevoice"),
  [string]$WorkDir = (Join-Path $env:TEMP "dsh-voice-mic-model")
)
$ErrorActionPreference = "Stop"
$Url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2025-09-09.tar.bz2"
$Tar = Join-Path $WorkDir "sense-voice-int8.tar.bz2"
$Extracted = Join-Path $WorkDir "sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2025-09-09"

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
New-Item -ItemType Directory -Force -Path $ModelDir | Out-Null

$already = (Test-Path (Join-Path $ModelDir "model.int8.onnx")) -and (Test-Path (Join-Path $ModelDir "tokens.txt"))
if ($already) {
  Write-Host "模型已就绪于 $ModelDir，跳过下载。"
  exit 0
}

Write-Host "下载模型包（约 158MB）…"
if (-not (Test-Path $Tar)) {
  curl.exe -L --retry 5 --retry-delay 3 -o $Tar $Url
  if ($LASTEXITCODE -ne 0) { throw "下载失败" }
}
Write-Host "解压…"
if (Test-Path $Extracted) { Remove-Item $Extracted -Recurse -Force }
tar -xjf $Tar -C $WorkDir
if ($LASTEXITCODE -ne 0) { throw "解压失败" }

Write-Host "复制模型文件到 $ModelDir …"
Copy-Item (Join-Path $Extracted "model.int8.onnx") $ModelDir -Force
Copy-Item (Join-Path $Extracted "tokens.txt") $ModelDir -Force
# ITN 中文数字规范化文件（可选）
foreach ($f in @("itn_zh_number.fst", "itn_zh_number.far")) {
  $src = Join-Path $Extracted $f
  if (Test-Path $src) { Copy-Item $src $ModelDir -Force }
}
Write-Host "完成。启动后端：python server/asr_server.py"
Write-Host "（或设置环境变量 DSH_VOICE_MIC_MODEL_DIR 指向其他目录）"
