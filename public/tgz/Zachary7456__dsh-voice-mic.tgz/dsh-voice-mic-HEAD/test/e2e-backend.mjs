// dsh-voice-mic 后端端到端测试：POST wav 到本地 ASR 服务并打印识别结果
// 用法：node test/e2e-backend.mjs <wav文件路径> [backendUrl 默认 http://127.0.0.1:7860]
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const [,, wavPath, backend = 'http://127.0.0.1:7860'] = process.argv;
if (!wavPath) {
  console.error('用法: node test/e2e-backend.mjs <wav文件> [backendUrl]');
  process.exit(2);
}
const base = backend.replace(/\/+$/, '');

const health = await fetch(`${base}/health`).then((r) => r.json()).catch(() => null);
if (!health?.ok) {
  console.error(`后端不在线（${base}）`);
  process.exit(1);
}
if (!health.ready) {
  console.error(`后端在线但模型未就绪（source=${health.source ?? 'null'}）。请先启动 python server/asr_server.py 并等待模型加载。`);
  process.exit(1);
}
console.log(`后端就绪（source=${health.source}），发送 ${wavPath} …`);

const audio = readFileSync(fileURLToPath(wavPath.startsWith('file:') ? wavPath : new URL('file://' + wavPath.replace(/\\/g, '/'))));
const form = new FormData();
form.append('audio', new Blob([audio], { type: 'audio/wav' }), 'test.wav');
const started = Date.now();
const res = await fetch(`${base}/v1/asr`, { method: 'POST', body: form });
const data = await res.json().catch(() => ({}));
console.log(`HTTP ${res.status} 用时 ${Date.now() - started}ms`);
if (!res.ok) {
  console.error('请求失败:', JSON.stringify(data));
  process.exit(1);
}
console.log('识别语言:', data.language ?? '?');
console.log('识别文本:', data.text ?? '(空)');
if (!(data.text ?? '').trim()) {
  console.log('提示:', data.hint ?? '');
  process.exit(1);
}
console.log('✓ 端到端转写成功');
