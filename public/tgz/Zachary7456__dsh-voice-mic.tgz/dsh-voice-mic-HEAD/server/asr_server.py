#!/usr/bin/env python3
"""
dsh-voice-mic 可选本地语音识别后端
====================================

基于 sherpa-onnx + SenseVoiceSmall 的离线转写服务，供 dsh-voice-mic 插件调用。
音频不出本机，无需 API key，无需 PyTorch（比 FunASR 官方依赖轻得多）。

使用方法
--------
1. 安装依赖：
   pip install -r requirements.txt
2. 启动服务（首次启动会自动从 ModelScope 下载模型，约 230MB）：
   python asr_server.py
   可选参数： --host 127.0.0.1 --port 7860
3. 在 dsh-voice-mic 插件设置里把「后端地址」填为 http://127.0.0.1:7860

接口
----
POST /v1/asr    multipart 表单，字段 audio=wav 文件（16kHz 单声道，插件会自动转码）
                → {"text": "...", "language": "zh", "elapsed_ms": 123}
GET  /health    → {"ok": true, "model": "sense-voice", "ready": true}
"""

import argparse
import io
import os
import re
import time
import wave

import numpy as np
import sherpa_onnx
import uvicorn
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="dsh-voice-mic ASR backend")

# 服务只绑定 127.0.0.1，CORS 放开所有来源即可：
# 浏览器从 DSH Web GUI（http://127.0.0.1:<端口>）直接 POST 音频到这里
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

MODEL_SCOPE_ID = "pengzhendong/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17"
MODEL_HF_ID = "csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17"

recognizer = None


def local_model_dir() -> str:
    """本地模型目录：环境变量 DSH_VOICE_MIC_MODEL_DIR，默认 ~/.dsh/voice/models/sensevoice-small-int8"""
    env = os.environ.get("DSH_VOICE_MIC_MODEL_DIR", "").strip()
    if env:
        return env
    model_type = os.environ.get("DSH_VOICE_MIC_MODEL_TYPE", "sensevoice-small-int8")
    return os.path.join(os.path.expanduser("~"), ".dsh", "voice", "models", model_type)


def find_model_files(directory: str):
    """在目录里灵活查找 model*.onnx 与 tokens.txt。"""
    try:
        files = os.listdir(directory)
    except OSError:
        return None, None
    model = next((f for f in files if re.match(r"^model.*\.onnx$", f)), None)
    tokens = "tokens.txt" if "tokens.txt" in files else None
    if model is None or tokens is None:
        return None, None
    return os.path.join(directory, model), os.path.join(directory, tokens)


def load_model():
    """加载本地模型：引擎由 DSH_VOICE_MIC_MODEL_TYPE 决定（sensevoice / paraformer）。

    模型目录由一键部署自动布置（模型文件 + tokens.txt）；也可以手动从
    sherpa-onnx 官方 release 下载对应模型包解压放入目录。
    """
    global recognizer
    local = local_model_dir()
    model_path, tokens_path = find_model_files(local)
    if model_path and tokens_path:
        engine = os.environ.get("DSH_VOICE_MIC_MODEL_TYPE", "sensevoice")
        if engine == "paraformer":
            recognizer = sherpa_onnx.OfflineRecognizer.from_paraformer(
                model=model_path,
                tokens=tokens_path,
                num_threads=2,
                debug=False,
                provider="cpu",
            )
        else:
            kwargs = {
                "model": model_path,
                "tokens": tokens_path,
                "num_threads": 2,
                "use_itn": False,  # 默认不开 ITN（依赖额外 fst/far 文件）
                "debug": False,
                "provider": "cpu",
            }
            # ITN 需要中文数字 fst/far；同目录存在则启用
            fst = os.path.join(local, "itn_zh_number.fst")
            far = os.path.join(local, "itn_zh_number.far")
            if os.path.exists(fst) and os.path.exists(far):
                kwargs["use_itn"] = True
                kwargs["rule_fsts"] = fst
                kwargs["rule_fars"] = far
            recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(**kwargs)
        app.state.model_source = f"local:{local}"
        app.state.model_engine = engine
        return
    try:
        recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
            model=MODEL_SCOPE_ID,
            tokens=f"{MODEL_SCOPE_ID}/tokens.txt",
            num_threads=2,
            use_itn=False,  # 在线模式不依赖 ITN 文件（部分源缺文件会加载失败）
            debug=False,
            provider="cpu",
        )
        app.state.model_source = "modelscope"
        app.state.model_engine = "sensevoice"
    except Exception:
        recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
            model=MODEL_HF_ID,
            tokens=f"{MODEL_HF_ID}/tokens.txt",
            num_threads=2,
            use_itn=False,
            debug=False,
            provider="cpu",
        )
        app.state.model_source = "huggingface"
        app.state.model_engine = "sensevoice"


def read_wav_16k(data: bytes) -> np.ndarray:
    """解析 wav 并强制转成 16kHz 单声道 float32。"""
    try:
        with wave.open(io.BytesIO(data), "rb") as wf:
            nch = wf.getnchannels()
            sampwidth = wf.getsampwidth()
            rate = wf.getframerate()
            raw = wf.readframes(wf.getnframes())
        if sampwidth == 2:
            audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        elif sampwidth == 4:
            audio = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0
        else:
            raise ValueError(f"unsupported sampwidth {sampwidth}")
        if nch > 1:
            audio = audio.reshape(-1, nch).mean(axis=1)
        if rate != 16000:
            # 简单线性重采样（16k 目标，语音场景足够）
            import math

            target_len = max(1, round(len(audio) * 16000 / rate))
            idx = np.linspace(0, len(audio) - 1, target_len)
            audio = np.interp(idx, np.arange(len(audio)), audio).astype(np.float32)
        return audio
    except Exception as exc:
        raise ValueError(f"wav 解析失败: {exc}") from exc


@app.on_event("startup")
def startup():
    if not getattr(app.state, "skip_model", False):
        load_model()


@app.get("/health")
def health():
    return {"ok": True, "model": getattr(app.state, "model_engine", "sense-voice"),
            "ready": recognizer is not None,
            "skip_model": getattr(app.state, "skip_model", False),
            "source": getattr(app.state, "model_source", None)}


@app.post("/v1/asr")
async def asr(audio: UploadFile = File(...)):
    if recognizer is None:
        raise HTTPException(status_code=503, detail="模型未就绪")
    data = await audio.read()
    if not data:
        raise HTTPException(status_code=400, detail="空音频")
    try:
        samples = read_wav_16k(data)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    stream = recognizer.create_stream()
    start = time.perf_counter()
    stream.accept_waveform(16000, samples)
    recognizer.decode_stream(stream)
    text = stream.result.text.strip()
    elapsed_ms = int((time.perf_counter() - start) * 1000)

    if not text:
        return {"text": "", "language": "", "elapsed_ms": elapsed_ms,
                "hint": "未识别到内容，请检查录音是否清晰、时间是否太短"}

    lang = ""
    # SenseVoice 输出形如 "<|zh|><|NEUTRAL|><|Speech|><|woitn|>你好"
    if "|zh|" in text:
        lang = "zh"
    elif "|en|" in text:
        lang = "en"
    cleaned = text.split("|woitn|>")[-1].strip()
    return {"text": cleaned, "language": lang, "elapsed_ms": elapsed_ms}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="dsh-voice-mic local ASR server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--no-model", action="store_true",
                        help="启动时不加载模型（仅测试服务连通性）")
    args = parser.parse_args()
    app.state.skip_model = args.no_model or os.environ.get("DSH_VOICE_MIC_SKIP_MODEL") == "1"
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")
