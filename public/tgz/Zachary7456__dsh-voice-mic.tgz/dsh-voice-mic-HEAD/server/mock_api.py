#!/usr/bin/env python3
"""
dsh-voice-mic 云端 API 模式的本地模拟服务器（仅用于功能测试）
===============================================================

模拟一个 OpenAI 兼容的 /v1/audio/transcriptions 端点，
返回固定文本，用于在没有真实 API 密钥时验证插件的完整链路：
录音 → WAV → multipart 上传 → 响应解析 → 实时上屏。

用法：
    python mock_api.py --port 7861
插件设置里：
    识别引擎 = 云端 API
    API 地址 = http://127.0.0.1:7861
    API 密钥 = test（任意非空）
    模型     = mock-model
然后点「测试 API 连接」应显示连通正常；点麦克风说话，
停止后输入框会回填"[模拟识别] …"。
"""
import argparse

import uvicorn
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="dsh-voice-mic mock OpenAI-compatible ASR")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def log_requests(request, call_next):
    print(f"[mock] {request.method} {request.url.path}", flush=True)
    return await call_next(request)


@app.get("/health")
def health():
    return {"ok": True, "mock": True}


@app.post("/v1/audio/transcriptions")
async def transcribe(
    file: UploadFile = File(...),
    model: str = Form(...),
    response_format: str = Form("json"),
    language: str | None = Form(None),
):
    data = await file.read()
    return {
        "text": f"[模拟识别] 收到音频 {len(data)} 字节，模型 {model}，语言 {language or '自动'}",
        "model": model,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="mock OpenAI-compatible ASR server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7861)
    args = parser.parse_args()
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
