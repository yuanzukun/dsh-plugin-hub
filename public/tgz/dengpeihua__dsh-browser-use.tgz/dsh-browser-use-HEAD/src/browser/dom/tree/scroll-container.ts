/**
 * Module overview
 * Responsibility: Browser DOM scroll-container detection used by the DOM service.
 * Usage: Runs after CDP DOM, accessibility, and layout snapshots are captured and contributes stable data for snapshot indexes, positioning, and rendering.
 * State and failure boundaries: Frame ownership, backend node IDs, model reference numbers, and incremental state must remain consistent across navigation and OOPIF changes.
 * Maintenance: When changing heuristics, verify cross-frame, dynamic-page, Shadow DOM, state-restoration, adjacent-test, and public-type paths.
 */

/**
 * Scroll Container Detection
 *
 * Builds a map of scrollable containers for elements outside the viewport.
 * Relies on renderInfo.scrollableContainerId being pre-computed in initRenderInfo.
 */

import type { EnhancedDOMTreeNode } from '../types/dom-node';
import { nodeKey } from '../utils/index';

/** Maps scroll container index → container node */
export type ScrollContainerMap = Map<number, EnhancedDOMTreeNode>;

/**
 * Build scroll container map for all expanded viewport elements.
 * Uses pre-computed scrollableContainerId to avoid parent chain walks.
 *
 * @param root - Pruned tree to iterate
 * @param lookup - nodeKey → un-pruned node (containers may have been pruned away)
 */
export function buildScrollContainerMap(
  root: EnhancedDOMTreeNode,
  lookup?: Map<string, EnhancedDOMTreeNode>,
): ScrollContainerMap {
  const scrollContainerMap: ScrollContainerMap = new Map();
  const containerToIndex = new Map<number, number>();
  let nextIndex = 1; // 0 is reserved for the main page

  // Build backendNodeId → node index from lookup for resolving scrollable containers
  const containerById = new Map<number, EnhancedDOMTreeNode>();
  if (lookup) {
    for (const node of lookup.values()) {
      if (node.renderInfo?.isScrollable) {
        containerById.set(node.backendNodeId, node);
      }
    }
  }

  // Virtual lists may render only visible rows: there need not be an off-screen
  // child to trigger registration. Keep the scrollable container itself usable.
  for (const [id, node] of containerById) {
    const sr = node.snapshotNode?.scrollRects
    const cr = node.snapshotNode?.clientRects
    if (!node.renderInfo.isVisible || !sr || !cr || cr.width <= 0 || cr.height <= 0) continue
    if (sr.height <= cr.height + 1 && sr.width <= cr.width + 1) continue
    const index = nextIndex++
    containerToIndex.set(id, index)
    scrollContainerMap.set(index, node)
    node.renderInfo.isHorizontalScroll = sr.height <= cr.height + 1 && sr.width > cr.width + 1
  }

  const visit = (node: EnhancedDOMTreeNode): void => {
    const containerId = node.renderInfo?.scrollableContainerId;
    if (
      node.renderInfo?.expandedViewportPosition !== undefined &&
      containerId !== undefined
    ) {
      const expandDir = node.renderInfo.expandedViewportPosition;
      let index = containerToIndex.get(containerId);
      if (index === undefined) {
        const containerNode = containerById.get(containerId);
        if (containerNode) {
          index = nextIndex++;
          containerToIndex.set(containerId, index);
          scrollContainerMap.set(index, containerNode);
          // Mark scroll direction on the container node
          if (containerNode.renderInfo) {
            containerNode.renderInfo.isHorizontalScroll =
              expandDir === 'left' || expandDir === 'right';
          }
        }
      }
      if (index !== undefined) {
        node.renderInfo.scrollContainerIndex = index;
        const originalNode = lookup?.get(nodeKey(node));
        if (originalNode?.renderInfo) {
          originalNode.renderInfo.scrollContainerIndex = index;
        }
      }
    }

    for (const child of node.childrenNodes ?? []) {
      visit(child);
    }
    for (const shadowRoot of node.shadowRoots ?? []) {
      visit(shadowRoot);
    }
    if (node.contentDocument) {
      visit(node.contentDocument);
    }
  };

  visit(root);
  return scrollContainerMap;
}
