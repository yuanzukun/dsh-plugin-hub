// smoke.ts - 纯逻辑冒烟测试（node scripts/smoke.ts；Node >= 22 原生跑 .ts）
// 覆盖：resolveRtkPath 探测、shQuote round-trip、白名单/黑名单校验、schema 结构、argv 构造
import { shQuote, resolveRtkPath } from "../src/rtk.ts";
import {
  CATEGORIES,
  validateCategoryArgs,
  META_BLACKLIST,
  rtkOutputSchema,
  rtkParametersSchema,
} from "../src/tools.ts";
import {
  rewriteDecision,
  buildRewriteReason,
  hasShellControlOps,
} from "../src/routing/gate.ts";

let failed = 0;
function check(name: string, cond: boolean, detail = "") {
  console.log(
    `${cond ? "PASS" : "FAIL"} ${name}${detail ? " - " + detail : ""}`,
  );
  if (!cond) failed++;
}

// ── P1：shQuote round-trip（含单引号/空格/emoji/空串）──
{
  const cases: Array<[string, string]> = [
    ["status", "status"],
    ["--oneline", "--oneline"],
    ["hello world", "'hello world'"],
    ["it's", "'it'\\''s'"],
    ["", "''"],
    ["path/with space", "'path/with space'"],
    ["emoji-🚀-arg", "'emoji-🚀-arg'"],
    ["a$b`c", "'a$b`c'"],
  ];
  for (const [input, expected] of cases) {
    check(
      `P1 shQuote(${JSON.stringify(input)})`,
      shQuote(input) === expected,
      `${shQuote(input)}`,
    );
  }
  // round-trip：quote 后拼进 command，shell 语义下应还原原串（模拟 sh 单引号解析）
  const roundTrip = (s: string) => {
    const q = shQuote(s);
    if (!q.startsWith("'")) return q;
    return q.slice(1, -1).replace(/'\\''/g, "'");
  };
  for (const [input] of cases) {
    check(`P1 roundtrip(${JSON.stringify(input)})`, roundTrip(input) === input);
  }
}

// ── P2：resolveRtkPath 本机探测 ──
{
  try {
    const r = resolveRtkPath();
    check(
      "P2 本机 rtk 解析成功",
      typeof r.path === "string" && r.path.length > 0,
      `${r.path} (${r.source})`,
    );
  } catch (e) {
    console.log(
      `SKIP P2（本机无 rtk）- ${(e as Error).message.split("\n")[0]}`,
    );
  }
  try {
    resolveRtkPath("/definitely/not/exist/rtk");
    check("P2 不存在路径应 throw", false);
  } catch (e) {
    check(
      "P2 不存在路径 throw + 含安装提示",
      (e as Error).message.includes("Install rtk"),
    );
  }
}

// ── P3：白名单/黑名单校验逻辑 ──
{
  const git = CATEGORIES.find((c) => c.name === "git")!;
  const search = CATEGORIES.find((c) => c.name === "search")!;
  const err = CATEGORIES.find((c) => c.name === "err")!;

  check(
    "P3 git 前缀工具任意 args 放行",
    validateCategoryArgs(git, ["status"]) === null,
  );
  check("P3 git 空参数拒绝", validateCategoryArgs(git, []) !== null);
  check(
    "P3 search 白名单内放行",
    validateCategoryArgs(search, ["grep", "TODO", "."]) === null,
  );
  check(
    "P3 search 白名单外拒绝",
    validateCategoryArgs(search, ["docker", "ps"]) !== null,
  );
  check(
    "P3 err 前缀工具任意命令放行",
    validateCategoryArgs(err, ["npm", "install"]) === null,
  );
  // 黑名单：所有无前缀工具硬拒绝元命令
  for (const cat of CATEGORIES) {
    if (cat.prefix !== "") continue;
    const bad = validateCategoryArgs(cat, ["init"]);
    check(
      `P3 ${cat.name} 拒绝元命令 init`,
      bad !== null && bad.includes("元命令"),
    );
    const runReject = validateCategoryArgs(cat, ["run"]);
    check(`P3 ${cat.name} 拒绝 run（sh -c 透传）`, runReject !== null);
  }
  check(
    "P3 黑名单含 16 个元命令",
    META_BLACKLIST.size === 16,
    `${META_BLACKLIST.size}`,
  );
}

// ── P4：argv 构造语义（prefix 与白名单协作）──
{
  const build = (cat: { prefix: string }, args: string[]) => [
    "/x/rtk",
    ...(cat.prefix ? [cat.prefix] : []),
    ...args,
  ];
  check(
    "P4 rtk_git argv",
    JSON.stringify(build({ prefix: "git" }, ["status"])) ===
      JSON.stringify(["/x/rtk", "git", "status"]),
  );
  check(
    "P4 rtk_search argv（无前缀，args[0] 即子命令）",
    JSON.stringify(build({ prefix: "" }, ["grep", "x", "."])) ===
      JSON.stringify(["/x/rtk", "grep", "x", "."]),
  );
  check(
    "P4 rtk_err argv",
    JSON.stringify(build({ prefix: "err" }, ["npm", "i"])) ===
      JSON.stringify(["/x/rtk", "err", "npm", "i"]),
  );
}

// ── P5：schema 结构断言（DSH ValueSchemaSpec 合规）──
{
  const out = rtkOutputSchema as {
    additionalProperties?: unknown;
    properties?: Record<
      string,
      { type?: string; oneOf?: unknown[]; required?: boolean }
    >;
  };
  check(
    "P5 output.additionalProperties 是 boolean",
    out.additionalProperties === false,
  );
  for (const f of [
    "stdout",
    "stderr",
    "exitCode",
    "timedOut",
    "truncated",
    "durationMs",
    "rtkCommand",
    "rtkVersion",
  ]) {
    check(`P5 output.${f} 存在`, out.properties?.[f] !== undefined);
  }
  check(
    "P5 output.exitCode 用 oneOf 表达 null",
    Array.isArray(out.properties?.exitCode?.oneOf) &&
      out.properties!.exitCode!.oneOf!.length === 2,
  );

  // dsh-tools 把 parameters 视为扁平的属性映射（每个 key 是一个 property schema），不再有 type/properties 包装。
  const params = rtkParametersSchema as Record<
    string,
    { type?: string; required?: boolean; additionalProperties?: unknown }
  >;
  check("P5 params.args 存在", params.args !== undefined);
  check("P5 params.args required", params.args?.required === true);
  check(
    "P5 params.env additionalProperties 是 boolean（非 schema 对象）",
    params.env?.additionalProperties === true,
  );
}

// ── P6：类别完整性（9 个 + doctor；无 rtk_run）──
{
  check("P6 共 9 个宽类别", CATEGORIES.length === 9, `${CATEGORIES.length}`);
  check("P6 不存在 rtk_run 工具", !CATEGORIES.some((c) => c.name === "run"));
  check(
    "P6 全部类别名唯一",
    new Set(CATEGORIES.map((c) => c.name)).size === CATEGORIES.length,
  );
  // 每个无前缀类别的白名单与黑名单不相交
  for (const cat of CATEGORIES) {
    if (!cat.subcommands) continue;
    const overlap = cat.subcommands.filter((s) => META_BLACKLIST.has(s));
    check(
      `P6 ${cat.name} 白名单与黑名单无交集`,
      overlap.length === 0,
      overlap.join(","),
    );
  }
}

// ── P7：softRewriteBash 软改写（v2：deny 语义 + 参数级改写 + 管道放行）──
{
  // deny 语义与定向提示
  const d1 = rewriteDecision("bash", { command: "git status" });
  check(
    "P7 git status 触发 deny",
    d1?.kind === "deny",
    d1?.kind,
  );
  check(
    "P7 提示含 rtk_git 与等价 args",
    d1?.reason.includes("rtk_git") === true &&
      d1?.reason.includes('["status"]') === true,
  );
  check(
    "P7 提示以 [rtk soft-rewrite] 开头（模型可识别）",
    d1?.reason.startsWith("[rtk soft-rewrite]") === true,
  );

  // subcommand-keep 改写：grep TODO . -> rtk_search(["grep","TODO","."])
  const d2 = rewriteDecision("bash", { command: "grep TODO ." });
  check(
    "P7 grep 改写到 rtk_search 且保留子命令",
    d2?.kind === "deny" &&
      d2.reason.includes("rtk_search") &&
      d2.reason.includes('["grep","TODO","."]'),
  );

  // prefix-strip 改写：git log --oneline -n 20 -> rtk_git(["log","--oneline","-n","20"])
  const d3 = rewriteDecision("bash", { command: "git log --oneline -n 20" });
  check(
    "P7 git 复合参数改写正确",
    d3?.reason.includes('["log","--oneline","-n","20"]') === true,
  );

  // 管道/串联/子 shell 不拦（rtk 无法单次等价改写）
  for (const cmd of [
    "git add . && git commit -m x",
    "cat f | grep x",
    "echo $(date)",
    "ls > out.txt",
  ]) {
    check(
      `P7 复合命令放行: ${cmd}`,
      rewriteDecision("bash", { command: cmd }) === undefined,
    );
    check(`P7 控制符检测: ${cmd}`, hasShellControlOps(cmd) === true);
  }

  // 非 bash 工具与非覆盖命令不拦
  check("P7 rtk_git 工具不触发", rewriteDecision("rtk_git", { args: ["status"] }) === undefined);
  check("P7 未覆盖命令放行 (node)", rewriteDecision("bash", { command: "node server.js" }) === undefined);
  check("P7 空 command 放行", rewriteDecision("bash", { command: "" }) === undefined);

  // 映射表完整性：每个映射的 tool 都在 enabledTools 命名空间内
  const validTools = new Set([
    ...CATEGORIES.map((c) => `rtk_${c.name}`),
    "rtk_doctor",
  ]);
  // 通过 buildRewriteReason 抽查若干代表命令的 tool 名
  const probes = ["git status", "ls .", "cargo build", "vitest", "pnpm list", "docker ps", "curl http://x"];
  let allValid = true;
  for (const c of probes) {
    const r = buildRewriteReason(c);
    const m = r.match(/请改用：(rtk_[a-z]+)/);
    if (!m || !validTools.has(m[1]!)) allValid = false;
  }
  check("P7 映射表 tool 名全部存在于工具集", allValid);
}

console.log(failed === 0 ? "\nALL PASS" : `\n${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
