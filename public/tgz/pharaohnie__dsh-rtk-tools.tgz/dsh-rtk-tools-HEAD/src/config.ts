// config.ts - dsh-rtk-tools 配置 schema（Schemastery）
// 修正记录（评审 v3 要点）：
// - 除 rtkPath 外其余字段带 default（loader 实测可能不填充 schema 默认值，apply 里另有 DEFAULT_CONFIG 兜底合并）
// - rtkPath 可选（z.string().optional()）：不设置则走探测链 Config > RTK_BIN > PATH > ~/.local/bin > ~/.cargo/bin > Homebrew
import z from '@deepseek-ai/schemastery'

export const CONFIG_TOOL_NAMES = [
  'git', 'search', 'build', 'test', 'pkg', 'infra', 'cloud', 'err', 'summary', 'doctor',
] as const

export const Config = z.object({
  /** rtk binary 路径覆盖；schema 无 default 即可选键，不设置则自动探测 */
  rtkPath: z.string().description('rtk binary 路径覆盖；留空自动探测（RTK_BIN > PATH > ~/.local/bin > ~/.cargo/bin > Homebrew）'),
  /** 默认子进程超时（ms）；每次调用可用 timeoutMs 参数覆盖 */
  defaultTimeoutMs: z.number().default(30_000).description('rtk 子进程默认超时毫秒数（默认 30000）'),
  /** 前台 stdout 捕获预算（字节）；透传给 DSH ShellExecRequest.stdoutMaxBytes */
  stdoutMaxBytes: z.number().default(200_000).description('前台 stdout 捕获预算字节（默认 200000，超出截断并 spill 到磁盘）'),
  /** 是否注入 systemPrompt section 引导模型优先使用 rtk_* 工具 */
  injectSystemPromptSection: z.boolean().default(true).description('是否在 systemPrompt 注入 rtk_* 使用引导（默认 true）'),
  /** 是否启用 bash 软改写（softRewriteBash）：监听 bash 工具调用，对已被 rtk_* 覆盖的低价值命令提示改用 rtk_*（默认开启 true） */
  softRewriteBash: z.boolean().default(true).description('是否启用 bash 软改写：对 bash 低价值命令提示改用 rtk_*（默认开启 true）'),
  /** 启用的工具子集（默认全部 10 个） */
  enabledTools: z.array(z.string()).default([...CONFIG_TOOL_NAMES]).description('启用的 rtk_* 工具子集（默认全部）'),
})

export interface RtkPluginConfig {
  rtkPath?: string
  defaultTimeoutMs: number
  stdoutMaxBytes: number
  injectSystemPromptSection: boolean
  softRewriteBash: boolean
  enabledTools: string[]
}

export const DEFAULT_CONFIG: RtkPluginConfig = {
  defaultTimeoutMs: 30_000,
  stdoutMaxBytes: 200_000,
  injectSystemPromptSection: true,
  softRewriteBash: true,
  enabledTools: [...CONFIG_TOOL_NAMES],
}

/** env 覆盖（优先级 rawConfig > env > DEFAULT_CONFIG） */
export function envConfigOverrides(env: NodeJS.ProcessEnv = process.env): Partial<RtkPluginConfig> {
  const o: Partial<RtkPluginConfig> = {}
  if (env.RTK_BIN) o.rtkPath = env.RTK_BIN
  if (env.RTK_DEFAULT_TIMEOUT_MS && Number.isFinite(Number(env.RTK_DEFAULT_TIMEOUT_MS))) o.defaultTimeoutMs = Number(env.RTK_DEFAULT_TIMEOUT_MS)
  if (env.RTK_STDOUT_MAX_BYTES && Number.isFinite(Number(env.RTK_STDOUT_MAX_BYTES))) o.stdoutMaxBytes = Number(env.RTK_STDOUT_MAX_BYTES)
  if (env.RTK_SOFT_REWRITE_BASH === 'true') o.softRewriteBash = true
  if (env.RTK_SOFT_REWRITE_BASH === 'false') o.softRewriteBash = false
  return o
}
