// tools.ts - 10 个 Tool 的定义（9 宽类别 + rtk_doctor）
//
// 评审修正记录（v3 要点）：
// - P0-1：category 不进 argv。有真实 rtk 子命令前缀的（git/err/summary）用 prefix 固定；
//   无前缀的（search/build/test/pkg/infra/cloud）args[0] 必须命中该类别白名单（真实 rtk 子命令）。
// - P0-2：不暴露 rtk_run（rtk 自带 run = sh -c 透传，会绕过 DSH 沙箱）。全局黑名单硬拒绝元命令。
// - P0-4：env 参数 additionalProperties 必须 boolean -> 用 true + execute 运行时校验 value 全为 string。
// - P1#1：render 闭包正确捕获 args（渲染头含实际命令）。
// - P0-5：M0 不做 background（run_in_background 不暴露），避免 jobs.start 句柄复杂度。
// - P0-6：systemPrompt 字段名在 index.ts 修正为 {name, order, text}。
// - P1（实测反馈）：默认 workdir 继承会话工作区（resolveSessionWorkdir 对齐 bash tool resolveWorkdir 语义）。
import path from "node:path";
import { defineTool } from "@deepseek-ai/dsh-tools";
import {
  runRtkCommand,
  resolveRtkPath,
  knownRtkVersion,
  type RtkRunResult,
} from "./rtk.ts";

/** rtk 元命令/危险命令黑名单（所有无前缀工具的 args[0] 硬拒绝） */
export const META_BLACKLIST = new Set([
  "init",
  "hook",
  "hook-audit",
  "rewrite",
  "trust",
  "untrust",
  "verify",
  "learn",
  "telemetry",
  "config",
  "discover",
  "session",
  "cc-economics",
  "proxy",
  "pipe",
  "run",
]);

export interface RtkCategory {
  /** Tool 短名（rtk_<name>） */
  name: string;
  /** 固定的真实 rtk 子命令前缀（git/err/summary）；'' 表示 args[0] 就是子命令 */
  prefix: string;
  /** args[0] 白名单（prefix 为空时生效）；null 表示不校验（prefix 工具的 args 是被代理命令的参数） */
  subcommands: string[] | null;
  description: string;
  examples: string[];
}

/** 9 个宽类别（覆盖 rtk 60+ 真实子命令；归类依据 t7 映射核对表 58/68 正确项 + 修正 8 项） */
export const CATEGORIES: RtkCategory[] = [
  {
    name: "git",
    prefix: "git",
    subcommands: null,
    description:
      "运行 rtk git <args>：任意 git 子命令（status/log/diff/show/add/commit/push/pull/branch/fetch/stash/worktree/checkout/reset/merge/rebase/cherry-pick/tag/remote/...），紧凑输出节省 59-80% token。git 操作优先用本工具而不是 bash。",
    examples: [
      '["status"]',
      '["log","--oneline","-n","20"]',
      '["diff","HEAD~1"]',
      '["add","-A"]',
      '["commit","-m","msg"]',
      '["push"]',
    ],
  },
  {
    name: "search",
    prefix: "",
    subcommands: [
      "ls",
      "tree",
      "read",
      "grep",
      "rg",
      "find",
      "wc",
      "env",
      "json",
      "log",
      "deps",
      "summary",
      "format",
      "smart",
    ],
    description:
      '运行 token 优化的文件/搜索命令。args[0] 必须是：ls/tree/read/grep/rg/find/wc/env/json/log/deps/summary/format/smart 之一，其余元素透传。输出比原生命令小 60-75%。例：["grep","TODO","."], ["ls","src"], ["read","file.ts"], ["find","*.rs","."]',
    examples: [
      '["grep","TODO","."]',
      '["ls","src"]',
      '["read","src/main.rs"]',
      '["find","*.ts","src"]',
      '["json","config.json"]',
      '["env","-f","AWS"]',
    ],
  },
  {
    name: "build",
    prefix: "",
    subcommands: [
      "cargo",
      "tsc",
      "lint",
      "next",
      "prettier",
      "ruff",
      "golangci-lint",
      "rubocop",
      "mvn",
      "gradlew",
      "sbt",
      "dotnet",
      "php",
      "phpunit",
      "pest",
      "paratest",
      "phpstan",
      "pint",
      "ecs",
      "artisan",
    ],
    description:
      '运行 token 优化的构建/lint 命令。args[0] 必须是：cargo/tsc/lint/next/prettier/ruff/golangci-lint/rubocop/mvn/gradlew/sbt/dotnet/php 系列 之一，其余元素透传。节省 70-87%。例：["cargo","build"], ["tsc"], ["lint"], ["next","build"]',
    examples: [
      '["cargo","build"]',
      '["tsc"]',
      '["lint"]',
      '["prettier","--check","."]',
      '["next","build"]',
      '["ruff","check"]',
    ],
  },
  {
    name: "test",
    prefix: "",
    subcommands: [
      "jest",
      "vitest",
      "pytest",
      "go",
      "cargo",
      "rake",
      "rspec",
      "playwright",
      "mvn",
      "gradlew",
      "sbt",
      "dotnet",
      "php",
      "phpunit",
      "pest",
      "paratest",
    ],
    description:
      '运行 token 优化的测试命令（默认只显示失败）。args[0] 必须是：jest/vitest/pytest/go/cargo/rake/rspec/playwright/mvn/gradlew/sbt/dotnet/php 系列 之一，其余元素透传。节省 60-99.5%。例：["vitest"], ["pytest"], ["cargo","test"]',
    examples: [
      '["vitest"]',
      '["pytest"]',
      '["cargo","test"]',
      '["jest"]',
      '["playwright","test"]',
      '["go","test","./..."]',
    ],
  },
  {
    name: "pkg",
    prefix: "",
    subcommands: ["pnpm", "npm", "npx", "pip", "uv", "cargo", "prisma"],
    description:
      '运行 token 优化的包管理命令。args[0] 必须是：pnpm/npm/npx/pip/uv/cargo/prisma 之一，其余元素透传。节省 70-90%。例：["pnpm","list"], ["pnpm","install"], ["npm","run","build"]',
    examples: [
      '["pnpm","list"]',
      '["pnpm","install"]',
      '["npm","run","build"]',
      '["pip","list"]',
      '["uv","run","pytest"]',
    ],
  },
  {
    name: "infra",
    prefix: "",
    subcommands: ["docker", "kubectl", "oc", "aws", "glab", "gt", "pulumi"],
    description:
      '运行 token 优化的基础设施命令。args[0] 必须是：docker/kubectl/oc/aws/glab/gt/pulumi 之一，其余元素透传。节省 26-85%。例：["docker","ps"], ["kubectl","get","pods"]',
    examples: [
      '["docker","ps"]',
      '["docker","logs","<container>"]',
      '["kubectl","get","pods"]',
      '["aws","sts","get-caller-identity"]',
    ],
  },
  {
    name: "cloud",
    prefix: "",
    subcommands: ["curl", "wget", "psql"],
    description:
      '运行 token 优化的网络/数据库客户端命令。args[0] 必须是：curl/wget/psql 之一，其余元素透传。HTTP 响应自动截断+可恢复。节省 65-70%。例：["curl","https://api.example.com"]',
    examples: [
      '["curl","-s","https://api.example.com"]',
      '["wget","https://example.com/file"]',
      '["psql","-c","SELECT 1"]',
    ],
  },
  {
    name: "err",
    prefix: "err",
    subcommands: null,
    description:
      '运行 rtk err <cmd>：执行任意命令但只显示 errors/warnings（过滤正常输出）。适合检查嘈杂命令的问题。节省 70-90%。例：["npm","install"], ["make","all"]',
    examples: ['["npm","install"]', '["make","all"]', '["cargo","build"]'],
  },
  {
    name: "summary",
    prefix: "summary",
    subcommands: null,
    description:
      '运行 rtk summary <cmd>：执行任意命令并给出 2 行启发式摘要。适合超长输出的快速把握。节省 70-90%。例：["npm","test"], ["docker","build"]',
    examples: ['["npm","test"]', '["docker","build"]', '["cargo","test"]'],
  },
];

/** 纯函数：校验一个类别的 args（白名单 + 黑名单）。通过返回 null，拒绝返回错误消息（可测）。 */
export function validateCategoryArgs(
  cat: RtkCategory,
  args: string[],
): string | null {
  if (!Array.isArray(args) || args.length === 0) {
    return `args 不能为空：第一个元素应是 rtk 子命令，如 ${cat.examples[0]}`;
  }
  if (cat.prefix === "") {
    const first = args[0]!;
    if (META_BLACKLIST.has(first)) {
      return `"${first}" 是 rtk 元命令/危险命令（改写用户配置、装 hook、sh -c 透传等），未通过 rtk_* 工具暴露。如确需运行请直接使用 bash 工具。`;
    }
    if (cat.subcommands && !cat.subcommands.includes(first)) {
      return `"${first}" 不在 rtk_${cat.name} 的子命令白名单（${cat.subcommands.join("/")}）中。请换正确的 rtk_* 工具，或使用 bash。`;
    }
  }
  return null;
}

/** 统一 output schema（canonical RtkRunResult 形状；exitCode 用 oneOf 表达 number|null） */
export const rtkOutputSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    stdout: { type: "string", required: true },
    stderr: { type: "string", required: true },
    exitCode: {
      oneOf: [{ type: "integer" }, { type: "null" }],
      required: true,
    },
    signal: { type: "string" },
    timedOut: { type: "boolean", required: true },
    truncated: { type: "boolean", required: true },
    spillPath: { type: "string" },
    durationMs: { type: "integer", required: true },
    rtkCommand: { type: "array", items: { type: "string" }, required: true },
    rtkVersion: { type: "string", required: true },
  },
} as const;

/**
 * 统一 parameters schema（9 个类别工具同构）
 *
 * 注意：dsh-tools 的 `defineTool({parameters})` 把 `parameters` 视为**扁平的属性映射**
 * （每个 key 是一个 property schema），由 `parameterSchemaSpecToJsonSchema` 自动包成
 * `{type:'object', properties:{...}}`。这里**不能再**用 `{type:'object', properties: {...}}`
 * 二次包装，否则会触发 "parameters.type must be a value schema object" 错误。
 *
 * 另：`as const` 仅影响 TS 推断，运行时仍为普通对象，不影响 schema 编译。
 */
export const rtkParametersSchema = {
  args: {
    type: "array",
    items: { type: "string" },
    required: true,
    description:
      "传给 rtk 的参数（不含 rtk 本身）。有类别前缀的工具（git/err/summary）从子命令开始；无前缀的工具 args[0] 必须是白名单内的 rtk 子命令。",
  },
  workdir: { type: "string", description: "工作目录（默认继承会话工作区）" },
  timeoutMs: { type: "number", description: "超时毫秒数（默认 30000）" },
  env: {
    type: "object",
    additionalProperties: true,
    description: "附加环境变量（值为字符串），与宿主环境合并",
  },
} as const;

/** 渲染 model 可见文本（bash tool 风格：输出 + [exit code: N]） */
export function renderRtkResult(v: RtkRunResult, argv: string[]): string {
  const shown = argv.slice(1).join(" ") || "(rtk)";
  const meta: string[] = [];
  if (v.durationMs > 0) meta.push(`${v.durationMs}ms`);
  if (v.truncated)
    meta.push(
      v.spillPath ? `truncated, full output: ${v.spillPath}` : "truncated",
    );
  if (v.timedOut) meta.push("TIMED OUT");
  const head = `[rtk ${shown}${meta.length ? " · " + meta.join(" · ") : ""}]`;
  const parts = [head];
  if (v.stdout) parts.push(v.stdout);
  if (v.stderr) parts.push(`[stderr]\n${v.stderr}`);
  if (v.exitCode !== 0 && v.exitCode !== null)
    parts.push(`[exit code: ${v.exitCode}]`);
  if (v.exitCode === null && v.signal) parts.push(`[killed by ${v.signal}]`);
  return parts.join("\n");
}

export interface MakeToolDeps {
  getShell: () => unknown;
  config: { defaultTimeoutMs: number; stdoutMaxBytes: number };
}

/** 构造一个类别 Tool（含白名单校验 + 主/降级执行通道） */
export function makeRtkTool(cat: RtkCategory, deps: MakeToolDeps) {
  return defineTool({
    name: `rtk_${cat.name}`,
    description: `${cat.description}\n\n示例 args：\n${cat.examples.map((e) => `  ${e}`).join("\n")}\n\n返回 { stdout, stderr, exitCode, timedOut, truncated, spillPath?, durationMs, rtkCommand, rtkVersion }。`,
    parameters: rtkParametersSchema,
    output: {
      schema: rtkOutputSchema,
      render: (args: { args?: string[] }, v: RtkRunResult) =>
        [
          {
            type: "text",
            text: renderRtkResult(v, v.rtkCommand ?? args?.args ?? []),
          },
        ] as never,
    },
    async execute(
      args: {
        args: string[];
        workdir?: string;
        timeoutMs?: number;
        env?: Record<string, unknown>;
      },
      exec: { signal?: AbortSignal },
    ) {
      // 白名单/黑名单校验（P0-1/P0-2 核心防线）
      const invalid = validateCategoryArgs(cat, args.args);
      if (invalid) throw new Error(`rtk_${cat.name}: ${invalid}`);
      // env 运行时校验（P0-4：additionalProperties:true 的类型补足）
      let env: Record<string, string> | undefined;
      if (args.env !== undefined) {
        env = {};
        for (const [k, val] of Object.entries(args.env)) {
          if (typeof val !== "string")
            throw new Error(
              `rtk_${cat.name}: env.${k} 的值必须是 string（收到 ${typeof val}）`,
            );
          env[k] = val;
        }
      }
      const rtk = resolveRtkPath();
      const argv: string[] = [
        rtk.path,
        ...(cat.prefix ? [cat.prefix] : []),
        ...args.args,
      ];
      return runRtkCommand({
        argv,
        getShell: deps.getShell,
        workdir: resolveSessionWorkdir(args.workdir, exec), // P1 修复：默认继承会话工作区
        timeoutMs: args.timeoutMs ?? deps.config.defaultTimeoutMs,
        stdoutMaxBytes: deps.config.stdoutMaxBytes,
        signal: exec?.signal,
        env,
      });
    },
  });
}

/** 会话工作区解析（对齐 bash tool resolveWorkdir 语义）：
 *  - 不传 workdir -> 用会话 cwd（exec.agent.session.header.cwd）
 *  - 相对 workdir -> 按会话 cwd 解析为绝对路径
 *  - 绝对 workdir -> 原样
 *  - 会话 cwd 不可得 -> 返回 undefined（executor 默认兜底） */
function resolveSessionWorkdir(modelWorkdir: string | undefined, exec: unknown): string | undefined {
  const headerCwd = (exec as { agent?: { session?: { header?: { cwd?: unknown } } } } | undefined)?.agent?.session?.header?.cwd;
  const sessionCwd = typeof headerCwd === "string" && headerCwd.length > 0 ? headerCwd : undefined;
  if (modelWorkdir === undefined) return sessionCwd;
  if (sessionCwd !== undefined && !path.isAbsolute(modelWorkdir)) return path.resolve(sessionCwd, modelWorkdir);
  return modelWorkdir;
}

/** rtk_doctor：诊断 rtk 安装状态 */
export function makeDoctorTool(deps: MakeToolDeps) {
  return defineTool({
    name: "rtk_doctor",
    description:
      "诊断 rtk 安装：二进制路径、来源、版本、候选路径与安装指引。rtk_* 工具报错时先用它定位。",
    parameters: {},
    output: {
      schema: rtkOutputSchema,
      render: (_args: unknown, v: RtkRunResult) =>
        [{ type: "text", text: v.stdout }] as never,
    },
    async execute(_args: unknown, _exec: unknown) {
      const lines: string[] = ["rtk doctor - 诊断安装状态："];
      try {
        const rtk = resolveRtkPath();
        lines.push(`  ✓ 找到 rtk: ${rtk.path}（来源: ${rtk.source}）`);
        lines.push(
          `  ✓ 版本: ${knownRtkVersion() || "(未探测，运行任意 rtk_* 后回填)"}`,
        );
        lines.push("  ✓ rtk_* 工具就绪。");
      } catch (e) {
        lines.push(`  ✗ ${(e as Error).message}`);
      }
      lines.push("环境变量: RTK_BIN 可覆盖路径；Config.rtkPath 优先级最高。");
      const argv = ["rtk", "doctor"];
      return {
        stdout: lines.join("\n"),
        stderr: "",
        exitCode: 0,
        signal: "",
        timedOut: false,
        truncated: false,
        spillPath: "",
        durationMs: 0,
        rtkCommand: argv,
        rtkVersion: knownRtkVersion(),
      } satisfies RtkRunResult;
    },
  });
}
