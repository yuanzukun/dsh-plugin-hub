// index.ts - dsh-rtk-tools 入口
//
// 把 rtk（Rust Token Killer）的 60+ token 压缩子命令按宽类别暴露成 DSH 模型可调用 Tool。
// 主路径 ctx.shell.run（command 字符串经 shQuote 转义；保沙箱/审批/spill/jobs 治理），
// 降级 execFile（shell 服务异常时保功能）。
//
// 评审修正落点（v3）：
// - inject 含 shell 硬依赖（对齐 bash tool 范式，t5 2.1）
// - systemPrompt.section 用 {name, order, text}（P0-6）
// - 不 import @deepseek-ai/cordis：ctx 用窄化字面量类型（context-mode 范式），peerDeps 仅 dsh-tools + schemastery
// - peerDeps 不声明 cordis（本插件零 cordis import；P0-7 的版本问题随之消解）
import { DEFAULT_CONFIG, envConfigOverrides, type RtkPluginConfig } from './config.ts'
import { resolveRtkPath, probeRtkVersion, knownRtkVersion } from './rtk.ts'
import { CATEGORIES, makeRtkTool, makeDoctorTool, type MakeToolDeps } from './tools.ts'
import { registerSoftRewrite } from './routing/gate.ts'
import { buildSoftRewriteAdvice } from './routing/advice.ts'
import type { PluginEventEmitter } from './types/dsh-events.ts'

export { Config } from './config.ts'

export const name = 'dsh-rtk-tools'

// 硬依赖：tools（注册 Tool）、shell（执行通道）、systemPrompt（section）
export const inject = ['tools', 'shell', 'systemPrompt']

/** 窄化 ctx（官方 Context 的字面量子集；完整类型可 import type { Context } from '@deepseek-ai/cordis'） */
interface RtkCtx extends PluginEventEmitter {
  tools: { register(def: unknown): unknown }
  systemPrompt: { section(s: unknown): unknown }
  get(serviceName: string): unknown
  effect(fn: () => (() => void) | void): unknown
}

const SYSTEM_PROMPT_ORDER = 130 // 避开 dsh-context-mode 的 140 与 run_code 区段

const SYSTEM_PROMPT_TEXT = [
  '优先使用 rtk_* 工具代替 bash 跑 shell 命令，输出节省 60-90% token：',
  '- rtk_git（任意 git 子命令）、rtk_search（ls/read/grep/find 等 14 个）、rtk_build（cargo/tsc/lint 等）',
  '- rtk_test（vitest/pytest/cargo test 等）、rtk_pkg（pnpm/npm/pip 等）、rtk_infra（docker/kubectl/aws 等）',
  '- rtk_cloud（curl/wget/psql）、rtk_err（任意命令只看错误）、rtk_summary（任意命令 2 行摘要）',
  '无对应 rtk_* 工具的命令仍用 bash。rtk 未安装或异常时调 rtk_doctor 诊断。',
].join('\n')

export function apply(ctx: RtkCtx, rawConfig: Partial<RtkPluginConfig> = {}): void {
  // 配置合并（loader 实测可能不填 schema 默认值 -> DEFAULT_CONFIG 兜底；优先级 rawConfig > env > 默认）
  const config: RtkPluginConfig = { ...DEFAULT_CONFIG, ...envConfigOverrides(), ...rawConfig }

  // 启动探测 rtk（失败仅告警不阻塞插件挂载；Tool 执行时才真正报错）
  try {
    const rtk = resolveRtkPath(config.rtkPath)
    console.log(`[dsh-rtk-tools] rtk resolved: ${rtk.path} (${rtk.source})`)
    void probeRtkVersion(config.rtkPath).then((v) => {
      if (v) console.log(`[dsh-rtk-tools] rtk version: ${v}`)
    })
  } catch (e) {
    console.warn(`[dsh-rtk-tools] ${(e as Error).message.split('\n')[0]}`)
    console.warn('[dsh-rtk-tools] rtk_* 工具将在调用时报错（rtk_doctor 可诊断），插件继续挂载。')
  }
  // config.rtkPath 存在时让 resolve 链感知（resolveRtkPath 每次带参重探测，TTL 缓存）
  if (config.rtkPath) {
    try { resolveRtkPath(config.rtkPath) } catch { /* 已告警 */ }
  }

  const deps: MakeToolDeps = {
    getShell: () => ctx.get('shell'),
    config: { defaultTimeoutMs: config.defaultTimeoutMs, stdoutMaxBytes: config.stdoutMaxBytes },
  }

  // 注册 9 个宽类别 Tool
  for (const cat of CATEGORIES) {
    if (!config.enabledTools.includes(cat.name)) continue
    ctx.tools.register(makeRtkTool(cat, deps))
  }

  // 注册 rtk_doctor
  if (config.enabledTools.includes('doctor')) {
    ctx.tools.register(makeDoctorTool(deps))
  }

  // systemPrompt 引导（可选）
  if (config.injectSystemPromptSection !== false) {
    try {
      ctx.systemPrompt.section({ name: 'rtk-tools', order: SYSTEM_PROMPT_ORDER, text: SYSTEM_PROMPT_TEXT })
    } catch (e) {
      console.warn(`[dsh-rtk-tools] systemPrompt.section 注册失败: ${(e as Error).message}`)
    }
  }

  // 软改写：softRewriteBash 启用时注册 pre-execute deny（带定向改写 reason，与 rtk hook 同构）
  if (config.softRewriteBash) {
    try {
      registerSoftRewrite(ctx, true)
      console.log('[dsh-rtk-tools] softRewriteBash 启用：已注册 bash 低价值命令定向 deny（pre-execute，reason 含等价 rtk_* 调用示例）')
    } catch (e) {
      console.warn('[dsh-rtk-tools] softRewriteBash 注册失败（不影响插件运行）:', (e as Error).message)
    }
  }

  // 软改写提示引导（systemPrompt 注入，与现有 rtk 引导协同）
  if (config.softRewriteBash && config.injectSystemPromptSection !== false) {
    try {
      const adviceText = buildSoftRewriteAdvice({ enabled: true })
      if (adviceText) {
        ctx.systemPrompt.section({ name: 'rtk-soft-rewrite', order: 131, text: adviceText })
      }
    } catch (e) {
      console.warn(`[dsh-rtk-tools] softRewriteBash systemPrompt 注入失败: ${(e as Error).message}`)
    }
  }

  // fiber 处置（清缓存；版本留待下次预热）
  ctx.effect(() => () => {
    // resolve/version 缓存是模块级的，跨 fiber 复用无害；这里只打点
    console.log('[dsh-rtk-tools] disposed')
  })

  console.log(`[dsh-rtk-tools] ${CATEGORIES.filter((c) => config.enabledTools.includes(c.name)).length + (config.enabledTools.includes('doctor') ? 1 : 0)} tools registered, version=${knownRtkVersion() || 'unknown'}`)
}
