// routing/gate.ts — softRewriteBash 软改写（pre-execute 拦截 + 定向 deny 提示）
//
// v2 改进（2026-08-25 用户实测反馈）：
// - kind:'ask' 在审批禁用的部署里表现为自动拒绝，模型只看到 "the user rejected tool \"bash\""，
//   我们写的 reason 根本送不到模型 -> 改为 kind:'deny'（deny 的 reason 是唯一可靠送达模型的通道，
//   与 rtk 官方 Claude Code PreToolUse hook 的 deny+redirect 消息同构）。
// - reason 含【等价调用示例】（参数级改写），模型首次触达无需依赖 CLAUDE.md 即可照抄纠正路由。
// - hasShellControlOps 检查真正生效：管道/串联/重定向命令不做等价改写提示（rtk 单次调用无法覆盖），放行。
// - 与 P0 黑名单（元命令硬拒绝）正交：本门禁只针对「已被 rtk_* 覆盖的低价值单命令」。

import type { PluginEventEmitter } from '../types/dsh-events.ts'

/** 改写模式：
 *  - prefix-strip：bash 首词是 rtk 工具的固定前缀（git），args = 去掉首词后的剩余部分（rtk_git）
 *  - subcommand-keep：bash 首词本身就是 rtk 子命令（ls/grep/cargo/pnpm/docker/curl...），args = [首词, ...剩余] */
interface RtkMapping {
  tool: string
  mode: 'prefix-strip' | 'subcommand-keep'
  saving: string
}

/** 已被 rtk_* 工具覆盖的 bash 低价值命令映射（与 tools.ts CATEGORIES 白名单同源核对） */
const BASH_TO_RTK_MAP: Record<string, RtkMapping> = {
  // rtk_git（prefix-strip）
  git: { tool: 'rtk_git', mode: 'prefix-strip', saving: '59-80%' },
  // rtk_search（subcommand-keep）
  ls: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '65%' },
  tree: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '65%' },
  read: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '60%' },
  grep: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '75%' },
  rg: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '75%' },
  find: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '70%' },
  wc: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '75%' },
  env: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '70%' },
  json: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '80%' },
  deps: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '70%' },
  smart: { tool: 'rtk_search', mode: 'subcommand-keep', saving: '70%' },
  // rtk_build（subcommand-keep）
  cargo: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '80-87%' },
  tsc: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '83%' },
  lint: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '84%' },
  prettier: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '70%' },
  next: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '87%' },
  ruff: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '80%' },
  mvn: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '75%' },
  gradlew: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '75%' },
  dotnet: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '75%' },
  rubocop: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '80%' },
  golangci: { tool: 'rtk_build', mode: 'subcommand-keep', saving: '80%' }, // golangci-lint 的首词
  // rtk_test（subcommand-keep）
  jest: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '99.5%' },
  vitest: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '99.5%' },
  pytest: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '90%' },
  go: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '90%' }, // go test 场景为主
  rake: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '90%' },
  rspec: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '60%' },
  playwright: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '94%' },
  sbt: { tool: 'rtk_test', mode: 'subcommand-keep', saving: '85%' },
  // rtk_pkg（subcommand-keep）
  npm: { tool: 'rtk_pkg', mode: 'subcommand-keep', saving: '70-90%' },
  pnpm: { tool: 'rtk_pkg', mode: 'subcommand-keep', saving: '70-90%' },
  npx: { tool: 'rtk_pkg', mode: 'subcommand-keep', saving: '70-90%' },
  pip: { tool: 'rtk_pkg', mode: 'subcommand-keep', saving: '80%' },
  uv: { tool: 'rtk_pkg', mode: 'subcommand-keep', saving: '80%' },
  prisma: { tool: 'rtk_pkg', mode: 'subcommand-keep', saving: '88%' },
  // rtk_infra（subcommand-keep）
  docker: { tool: 'rtk_infra', mode: 'subcommand-keep', saving: '85%' },
  kubectl: { tool: 'rtk_infra', mode: 'subcommand-keep', saving: '85%' },
  oc: { tool: 'rtk_infra', mode: 'subcommand-keep', saving: '85%' },
  aws: { tool: 'rtk_infra', mode: 'subcommand-keep', saving: '26-85%' },
  glab: { tool: 'rtk_infra', mode: 'subcommand-keep', saving: '80%' },
  pulumi: { tool: 'rtk_infra', mode: 'subcommand-keep', saving: '80%' },
  gt: { tool: 'rtk_infra', mode: 'subcommand-keep', saving: '80%' },
  // rtk_cloud（subcommand-keep）
  curl: { tool: 'rtk_cloud', mode: 'subcommand-keep', saving: '65-70%' },
  wget: { tool: 'rtk_cloud', mode: 'subcommand-keep', saving: '65%' },
  psql: { tool: 'rtk_cloud', mode: 'subcommand-keep', saving: '65-70%' },
}

/** 提取 bash 命令字符串的首个命令词（小写） */
export function firstCommandWord(command: string): string | null {
  if (!command) return null
  const m = command.trim().match(/^[A-Za-z0-9_.-]+/)
  return m ? m[0].toLowerCase() : null
}

/** 检测命令是否包含 shell 控制运算符（管道/串联/重定向/子 shell/命令替换）——此类命令不做等价改写 */
export function hasShellControlOps(command: string): boolean {
  return /[|&;<>()$`\n]/.test(command)
}

/** 把命令剩余部分切成建议 args 数组（简单空白切分 + 去包裹引号；仅用于提示展示，模型会自行校正格式） */
function suggestRestArgs(rest: string): string[] {
  if (!rest) return []
  return rest.split(/\s+/).filter(Boolean).map((t) => t.replace(/^["']|["']$/g, ''))
}

/** 构造定向 deny reason：含等价 rtk 调用示例（参数级改写），模型可直接照抄 */
export function buildRewriteReason(command: string): string {
  const trimmed = command.trim()
  const first = firstCommandWord(trimmed)!
  const mapping = BASH_TO_RTK_MAP[first]
  const rest = trimmed.slice(first.length).trim()
  const restTokens = suggestRestArgs(rest)
  const args =
    mapping.mode === 'prefix-strip'
      ? restTokens
      : [first, ...restTokens]
  const example = `${mapping.tool}({"args":${JSON.stringify(args)}})`
  return (
    `[rtk soft-rewrite] 该 bash 命令已被 rtk 覆盖（节省 ${mapping.saving} token）。` +
    `请改用：${example}。` +
    `本次已拦截以引导改写；如确需原生 bash 输出（如复杂管道或多步串联），请拆分为单命令分别调用对应 rtk_* 工具，或在插件配置中关闭 softRewriteBash。`
  )
}

/** 软改写决策：bash 单命令的首词命中映射表 → 返回 deny（带定向改写提示）；否则 undefined（放行）。
 *  不拦：非 bash 工具 / 空 command / 含控制运算符（管道/串联/子 shell）/ 首词不在映射表。 */
export function rewriteDecision(name: string, args: unknown): { kind: 'deny'; reason: string } | undefined {
  if (name !== 'bash') return undefined
  if (args == null || typeof args !== 'object') return undefined
  const record = args as Record<string, unknown>
  const command = record.command
  if (typeof command !== 'string' || command.length === 0) return undefined
  if (hasShellControlOps(command)) return undefined // 复合命令：rtk 无法单次等价改写，放行
  const first = firstCommandWord(command)
  if (!first) return undefined
  if (!(first in BASH_TO_RTK_MAP)) return undefined
  return { kind: 'deny', reason: buildRewriteReason(command) }
}

/** 注册软改写门禁（tools/pre-execute 瀑布事件；参考 context-mode routing/gate.ts 语义） */
export function registerSoftRewrite(ctx: PluginEventEmitter, enabled: boolean) {
  if (!enabled) return
  ctx.on('tools/pre-execute', async (exec, next) => {
    try {
      const decision = rewriteDecision(exec?.name, exec?.arguments)
      if (decision) return decision
      return next()
    } catch (e) {
      // 门禁自身异常不阻塞调用（fail-open 放行）
      console.warn('[dsh-rtk-tools] softRewriteBash 门禁异常（fail-open）:', (e as Error).message)
      return next()
    }
  })
}
