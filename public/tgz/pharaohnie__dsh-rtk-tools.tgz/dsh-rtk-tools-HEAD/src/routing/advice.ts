// routing/advice.ts — softRewriteBash 提示文案（systemPrompt 注入，与现有 rtk 引导协同）
// 当 softRewriteBash 启用时，本提示在 systemPrompt 中额外注入软引导规则。

export interface SoftRewriteAdviceDeps {
  enabled: boolean
}

export function buildSoftRewriteAdvice(deps: SoftRewriteAdviceDeps): string {
  if (!deps.enabled) return ''
  return `## rtk 软改写引导（softRewriteBash 启用）
- 当你打算用 bash 执行常见开发命令（git、grep、cargo、pnpm、docker、curl 等）时，先检查是否已有对应的 rtk_* 工具：
  - git 操作 → rtk_git；文件搜索/读取 → rtk_search；构建/lint → rtk_build；测试 → rtk_test；包管理 → rtk_pkg；基础设施 → rtk_infra；网络/DB → rtk_cloud；错误过滤 → rtk_err；智能摘要 → rtk_summary。
- rtk 工具已注册为模型可调用的 defineTool，执行时自动走 rtk 二进制（节省 60-90% token），并保留 DSH shell 治理（沙箱/审批/spill）。
- 软引导只提示不阻止：你仍可选择继续用 bash（如复杂管道、多步串联）；但对于单命令低价值场景（如 git status、ls、grep 简单搜索），优先选用 rtk_* 可显著减少上下文消耗。`
}
