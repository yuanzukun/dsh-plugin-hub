// rtk.ts - rtk binary 解析 + 命令执行
//
// 评审修正记录（v3 要点，对照 DSH_RTK_PLAN_v2_REVIEW_REPORT.md）：
// - P0-3：DSH ShellExecRequest 只有 command: string，没有 argv 字段
//   -> 主路径：argv 经 shQuote() POSIX 单引号转义拼成 command 字符串，走 ctx.shell.run（保治理栈）
//   -> 降级路径：ctx.shell.run 抛基础设施错误时用 child_process.execFile 直接 argv spawn（无 tokenize 风险）
// - P0-1：category 不得进 argv -- 本模块只接受「真实 rtk 子命令已就位」的 argv，拼接/校验在 tools.ts 完成
// - P1#4：避免 execFileSync 阻塞 -- 路径探测全部用同步 fs 探测固定候选（微秒级），版本探测异步且仅预热
// - execFile 降级截断按 Buffer 字节累计（不按字符 slice，防切碎多字节字符，评审 P1#2）
import { execFile } from 'node:child_process'
import { existsSync, accessSync, constants } from 'node:fs'
import { homedir } from 'node:os'
import path from 'node:path'

export interface RtkResolveResult { path: string; source: string }

/** 解析结果缓存（TTL 30s；缓存键含 configPath 参数，避免不同路径互相污染；resolve 失败缓存 null 会在 TTL 后重试） */
let cachedResolve: RtkResolveResult | null = null
let cachedAt = 0
let cachedPathArg: string | null = null
let cachedVersion = ''
const RESOLVE_TTL_MS = 30_000

/** POSIX 单引号转义：把单个参数安全地放进 `sh -c` 命令字符串。
 *  规则：安全字符集直接透出；否则单引号包裹，内部单引号转义为 '\''（close/escape/reopen）。 */
export function shQuote(s: string): string {
  if (s.length === 0) return "''"
  if (/^[A-Za-z0-9_@%+=:,./-]+$/.test(s)) return s
  return "'" + s.replace(/'/g, "'\\''") + "'"
}

/** PATH 搜索 rtk（纯同步 fs 探测，不 spawn which） */
function findInPath(): string | null {
  const p = process.env.PATH ?? ''
  for (const dir of p.split(':')) {
    if (!dir) continue
    const cand = path.join(dir, 'rtk')
    try {
      if (existsSync(cand)) {
        accessSync(cand, constants.X_OK)
        return cand
      }
    } catch { /* 不可执行 -> 继续找 */ }
  }
  return null
}

/** 解析 rtk binary 路径。
 *  configPath 显式指定时是唯一候选（失败即抛错，不静默 fallback，避免用户配置被忽略）；
 *  否则按 RTK_BIN > PATH > ~/.local/bin > ~/.cargo/bin > Homebrew 探测链。
 *  找不到 throw（含安装提示）；调用方负责降级/友好报错。 */
export function resolveRtkPath(configPath?: string): RtkResolveResult {
  const now = Date.now()
  if (cachedResolve && now - cachedAt < RESOLVE_TTL_MS && cachedPathArg === (configPath ?? null)) return cachedResolve

  // ── configPath 显式指定：唯一候选，失败即抛错（不 fallback） ──
  if (configPath) {
    try {
      accessSync(configPath, constants.X_OK)
      cachedResolve = { path: configPath, source: 'config' }
      cachedAt = now
      cachedPathArg = configPath
      return cachedResolve
    } catch {
      cachedResolve = null
      cachedAt = now
      cachedPathArg = configPath
      throw new Error(
        `rtk binary not found at configured path: ${configPath}（不存在或不可执行）。\n` +
        `请检查 Config.rtkPath / RTK_BIN 设置；或移除以改用自动探测。\n` +
        `Install rtk (Apache-2.0):\n` +
        `  brew install rtk\n` +
        `  curl -fsSL https://raw.githubusercontent.com/rtk-ai/rtk/master/install.sh | sh\n` +
        `  cargo install --git https://github.com/rtk-ai/rtk`,
      )
    }
  }

  // ── 无 configPath：探测链 ──
  const candidates: Array<{ path: string; source: string }> = []
  if (process.env.RTK_BIN) candidates.push({ path: process.env.RTK_BIN, source: 'env' })
  const inPath = findInPath()
  if (inPath) candidates.push({ path: inPath, source: 'path' })
  const home = homedir()
  const userLocal = path.join(home, '.local', 'bin', 'rtk')
  if (existsSync(userLocal)) candidates.push({ path: userLocal, source: 'default-user' })
  const cargo = path.join(home, '.cargo', 'bin', 'rtk')
  if (existsSync(cargo)) candidates.push({ path: cargo, source: 'cargo' })
  for (const hb of ['/opt/homebrew/bin/rtk', '/usr/local/bin/rtk']) {
    if (existsSync(hb)) candidates.push({ path: hb, source: 'homebrew' })
  }

  for (const c of candidates) {
    try {
      accessSync(c.path, constants.X_OK)
      cachedResolve = { path: c.path, source: c.source }
      cachedAt = now
      cachedPathArg = configPath ?? null
      return cachedResolve
    } catch { /* 尝试下一个候选 */ }
  }
  // 失败也短暂缓存，避免高频重探测；TTL 后自然重试（用户可能中途安装）
  cachedResolve = null
  cachedAt = now
  cachedPathArg = configPath ?? null
  throw new Error(
    `rtk binary not found. Tried: ${candidates.map((c) => `${c.source}:${c.path}`).join(', ') || '(no candidates)'}\n` +
    `Install rtk (Apache-2.0):\n` +
    `  brew install rtk\n` +
    `  curl -fsSL https://raw.githubusercontent.com/rtk-ai/rtk/master/install.sh | sh\n` +
    `  cargo install --git https://github.com/rtk-ai/rtk\n` +
    `Then set PATH or RTK_BIN, or configure dsh-rtk-tools rtkPath.\n` +
    `You can still use the bare bash tool; output just won't be token-optimized.`,
  )
}

/** 异步探测 rtk 版本（结果缓存；启动时 fire-and-forget 预热，失败静默） */
export function probeRtkVersion(rtkPath?: string): Promise<string> {
  return new Promise((resolve) => {
    let p: string
    try {
      p = resolveRtkPath(rtkPath).path
    } catch { resolve(''); return }
    execFile(p, ['--version'], { timeout: 3000 }, (err, stdout) => {
      if (err) { resolve(''); return }
      const m = (stdout ?? '').match(/(\d+\.\d+\.\d+)/)
      cachedVersion = m?.[1] ?? (stdout ?? '').trim()
      resolve(cachedVersion)
    })
  })
}

export function knownRtkVersion(): string {
  return cachedVersion
}

/** 统一执行结果（output schema 的 canonical 形状） */
export interface RtkRunResult {
  stdout: string
  stderr: string
  exitCode: number | null
  signal: string
  timedOut: boolean
  truncated: boolean
  spillPath: string
  durationMs: number
  rtkCommand: string[]
  rtkVersion: string
}

interface CollectedLike { text?: string; truncated?: boolean; spillPath?: string }

/** ShellRunResult.stdout 可能是 CollectedOutput 对象（{text,truncated,spillPath}）或字符串（简化执行器）；统一映射 */
function textOf(o: unknown): { text: string; truncated: boolean; spillPath: string } {
  if (typeof o === 'string') return { text: o, truncated: false, spillPath: '' }
  if (o && typeof o === 'object') {
    const r = o as CollectedLike
    return {
      text: typeof r.text === 'string' ? r.text : '',
      truncated: r.truncated === true,
      spillPath: typeof r.spillPath === 'string' ? r.spillPath : '',
    }
  }
  return { text: '', truncated: false, spillPath: '' }
}

export interface RunRtkOptions {
  /** 已完成白名单校验的完整 argv（argv[0] 是 rtk binary 路径） */
  argv: string[]
  getShell: () => unknown
  workdir?: string
  timeoutMs: number
  stdoutMaxBytes: number
  signal?: AbortSignal
  env?: Record<string, string>
}

/** 执行一条 rtk 命令：主路径 ctx.shell（保沙箱/审批/spill/jobs 治理），降级 execFile（仅基础设施失败时）。 */
export async function runRtkCommand(opts: RunRtkOptions): Promise<RtkRunResult> {
  const start = Date.now()
  const rtk = resolveRtkPath()
  const version = knownRtkVersion()

  // ── 主路径：ctx.shell.run（官方 ShellExecRequest：command 字符串 + 治理字段）──
  const shell = opts.getShell() as
    | { resolve?: (req: unknown) => unknown; run?: (spec: unknown) => Promise<unknown> }
    | undefined
  if (shell && typeof shell.resolve === 'function' && typeof shell.run === 'function') {
    const command = opts.argv.map(shQuote).join(' ')
    const request: Record<string, unknown> = {
      command,
      timeoutMs: opts.timeoutMs,
      stdoutMaxBytes: opts.stdoutMaxBytes,
      ...(opts.workdir !== undefined ? { workdir: opts.workdir } : {}),
      ...(opts.env !== undefined ? { env: opts.env } : {}),
      ...(opts.signal !== undefined ? { signal: opts.signal } : {}),
    }
    let res: unknown
    try {
      res = await shell.run(shell.resolve(request))
    } catch (e) {
      // 基础设施失败（executor 异常）-> 降级 execFile，保功能可用
      console.warn(`[dsh-rtk-tools] ctx.shell.run failed (${(e as Error).message}), falling back to execFile (no DSH governance)`)
      return execRtkDirect(opts, start, version)
    }
    const r = res as {
      exitCode?: number | null; signal?: string | null; timedOut?: boolean; aborted?: boolean
      stdout?: unknown; stderr?: unknown
    }
    const out = textOf(r.stdout)
    const err = textOf(r.stderr)
    return {
      stdout: out.text,
      stderr: err.text,
      exitCode: typeof r.exitCode === 'number' ? r.exitCode : r.exitCode === null ? null : -1,
      signal: typeof r.signal === 'string' ? r.signal : '',
      timedOut: r.timedOut === true,
      truncated: out.truncated || err.truncated,
      spillPath: out.spillPath || err.spillPath,
      durationMs: Date.now() - start,
      rtkCommand: opts.argv,
      rtkVersion: version,
    }
  }

  // ── 降级路径：shell 服务未挂载 -> execFile 直接 argv spawn ──
  console.warn('[dsh-rtk-tools] ctx.shell unavailable, using execFile directly (no DSH sandbox/approval governance)')
  return execRtkDirect(opts, start, version)
}

/** execFile 降级：argv 直接 spawn（无 shell tokenize 风险）；截断按 Buffer 字节累计。 */
function execRtkDirect(opts: RunRtkOptions, start: number, version: string): Promise<RtkRunResult> {
  return new Promise((resolve) => {
    const cap = opts.stdoutMaxBytes
    let timedOut = false
    let killed = false
    const child = execFile(opts.argv[0]!, opts.argv.slice(1), {
      cwd: opts.workdir,
      timeout: opts.timeoutMs,
      maxBuffer: Math.max(cap * 4, 10 * 1024 * 1024), // execFile 自身缓冲上限给足，手动截断
      env: opts.env ? { ...process.env, ...opts.env } : process.env,
      signal: opts.signal,
      killSignal: 'SIGTERM',
    }, (err, stdout, stderr) => {
      const exitCode = err && typeof (err as { code?: number }).code === 'number'
        ? (err as { code: number }).code
        : err && err.killed ? null
          : 0
      const signalName = err && err.killed && typeof (err as { signal?: string }).signal === 'string'
        ? (err as { signal: string }).signal
        : ''
      timedOut = err?.name === 'TimeoutError' || (err as { killed?: boolean } | undefined)?.killed === true && timedOut
      // 按字节截断（保 head；rtk 输出已被压缩，通常远小于 cap）
      let outText = stdout ?? ''
      let errText = stderr ?? ''
      let truncated = false
      if (Buffer.byteLength(outText, 'utf8') > cap) {
        outText = Buffer.from(outText, 'utf8').subarray(0, cap).toString('utf8')
        truncated = true
      }
      resolve({
        stdout: outText,
        stderr: errText,
        exitCode: err && exitCode === 0 ? null : exitCode,
        signal: signalName,
        timedOut,
        truncated,
        spillPath: '',
        durationMs: Date.now() - start,
        rtkCommand: opts.argv,
        rtkVersion: version,
      })
    })
    // execFile 回调 err.code 已承载退出码；这里只处理 abort 语义标记
    if (opts.signal) {
      opts.signal.addEventListener('abort', () => { killed = true; try { child.kill('SIGTERM') } catch { /* already exited */ } }, { once: true })
    }
    void killed
  })
}
