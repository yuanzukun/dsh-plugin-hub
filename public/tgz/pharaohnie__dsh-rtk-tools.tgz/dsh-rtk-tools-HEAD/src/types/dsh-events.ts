// types/dsh-events.ts — 本插件所用 DSH 事件的本地显式类型（仅 pre-execute）。
// 签名对照 @deepseek-ai/dsh-tools/lib/types/index.d.ts，避免 gate.ts 使用 as never。
import type { PreToolDecision, ToolExecution } from '@deepseek-ai/dsh-tools'

/** tools/pre-execute 监听器（瀑布）：放行必 return next()，短路返回 deny/ask 决策。 */
export type PreExecuteListener = (
  exec: ToolExecution,
  next: () => Promise<PreToolDecision>,
) => Promise<PreToolDecision>

/** 插件侧事件注册器：仅覆盖 softRewriteBash 使用的 pre-execute。 */
export interface PluginEventEmitter {
  on(name: 'tools/pre-execute', listener: PreExecuteListener): unknown
}
