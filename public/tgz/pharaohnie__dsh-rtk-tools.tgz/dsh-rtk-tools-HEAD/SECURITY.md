# Security Policy

## Scope

This plugin executes the external `rtk` binary (Apache-2.0, installed by the
user) as a subprocess via DSH's `ctx.shell` channel (with `execFile` fallback).
It does not bundle binaries, transmit data off-machine, or read credentials.

## Trust model

- Commands are assembled from model-provided arguments after whitelist
  validation (real rtk subcommands per category) and a hard blacklist that
  rejects rtk meta-commands (`init`/`hook`/`trust`/`config`/`rewrite`/`learn`/
  `proxy`/`pipe`/`run`/...). `rtk run` (raw `sh -c` passthrough) is never exposed.
- The primary execution path goes through `ctx.shell`, preserving DSH
  sandbox/approval/spill governance. The `execFile` fallback engages only when
  the shell service is unavailable or fails, and logs a warning.
- `env` arguments are runtime-validated to be string values only.

## Reporting

Report suspected vulnerabilities with the affected rtk version and a minimal
reproduction to the plugin maintainer.
