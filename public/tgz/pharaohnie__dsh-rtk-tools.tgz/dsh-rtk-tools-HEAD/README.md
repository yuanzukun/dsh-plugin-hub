# dsh-rtk-tools

DSH 插件：把 [rtk (Rust Token Killer)](https://github.com/rtk-ai/rtk) 的 60+ 个 token 优化子命令暴露成模型可调用的 Tool，shell 输出节省 60-90% token（filter / grouping / truncation / dedup 四大策略，由 rtk 二进制实现）。

## 安装

```bash
# 1. 先安装 rtk（本插件不打包二进制）
brew install rtk
# 或: curl -fsSL https://raw.githubusercontent.com/rtk-ai/rtk/master/install.sh | sh
# 或: cargo install --git https://github.com/rtk-ai/rtk

# 2. 挂载插件（web profile）
dsh plugin --profile web add <path-to-this-directory>
# 重启 DSH 生效
```

## 工具（10 个）

| 工具 | 用途 | args 示例 |
|---|---|---|
| `rtk_git` | 任意 git 子命令（59-80% 节省） | `["status"]`、`["log","--oneline","-n","20"]` |
| `rtk_search` | ls/tree/read/grep/rg/find/wc/env/json/log/deps/summary/format/smart（60-75%） | `["grep","TODO","."]`、`["read","file.ts"]` |
| `rtk_build` | cargo/tsc/lint/next/prettier/ruff/golangci-lint/rubocop/mvn/gradlew/sbt/dotnet/php 系（70-87%） | `["cargo","build"]`、`["tsc"]` |
| `rtk_test` | jest/vitest/pytest/go/cargo/rake/rspec/playwright/mvn/gradlew/sbt/dotnet/php 系（60-99.5%） | `["vitest"]`、`["pytest"]` |
| `rtk_pkg` | pnpm/npm/npx/pip/uv/cargo/prisma（70-90%） | `["pnpm","list"]` |
| `rtk_infra` | docker/kubectl/oc/aws/glab/gt/pulumi（26-85%） | `["docker","ps"]` |
| `rtk_cloud` | curl/wget/psql（65-70%） | `["curl","-s","https://..."]` |
| `rtk_err` | 任意命令只看 errors/warnings（70-90%） | `["npm","install"]` |
| `rtk_summary` | 任意命令 2 行智能摘要（70-90%） | `["npm","test"]` |
| `rtk_doctor` | 诊断 rtk 安装状态 | `{}` |

**不暴露**（安全设计）：`rtk run`（sh -c 透传，会绕过 DSH 沙箱）及 15 个元命令（init/hook/discover/config/rewrite/trust/telemetry 等）--如确需运行请直接使用 bash 工具。

## 设计要点

- **执行通道**：主路径 `ctx.shell.run`（参数经 POSIX 单引号转义拼 command 字符串），自动继承 DSH 沙箱/审批/spill/jobs 治理；shell 服务异常时降级 `execFile` 直接 argv spawn。
- **白名单校验**：无前缀工具的 `args[0]` 必须命中该类别白名单（真实 rtk 子命令）；全局黑名单硬拒绝元命令。
- **canonical output**：`{ stdout, stderr, exitCode(number|null), timedOut, truncated, spillPath?, durationMs, rtkCommand, rtkVersion }`；截断输出 spill 到磁盘，模型可用 read 工具读 `spillPath`。
- 与 dsh-context-mode 正交：一个管大文件检索/知识库，一个管 shell 输出压缩，可共存。

## 配置

```yaml
# dsh profile 配置（可选）
- id: rtk-tools
  name: dsh-rtk-tools
  # config:
  #   rtkPath: /opt/homebrew/bin/rtk
  #   defaultTimeoutMs: 30000
  #   stdoutMaxBytes: 200000
  #   injectSystemPromptSection: true
  #   enabledTools: [git, search, test, doctor]
```

环境变量：`RTK_BIN`（路径覆盖）、`RTK_DEFAULT_TIMEOUT_MS`、`RTK_STDOUT_MAX_BYTES`。

## 验证

```bash
cd <path-to-this-directory>
node scripts/smoke.ts        # 冒烟测试（resolveRtkPath / shQuote / 白名单 / schema）
```

## License

- 本插件：Apache License 2.0
- rtk 二进制：Apache License 2.0（本插件不分发 rtk 二进制，用户自行安装）
