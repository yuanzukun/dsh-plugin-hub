# dsh-naiwa-theme

一个用于 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) Web 界面的奶蛙主题插件。

> 非官方、非商业的娱乐向项目。

## 功能

- 奶黄、奶油白和嫩绿色主题配色，支持深色与浅色模式。
- 会话空状态保留半颗奶蛙头背景，并将标题改为“嘎嘎滴辣虾”。
- 标题图标替换为抱腹大笑的奶蛙标记。
- 输入框发送按钮替换为奶蛙头像。
- 顶层会话开始运行时播放短爬行音效，完成后播放大笑音效。
- 历史会话加载和子代理状态变化不会触发提示音。
- 尊重系统的“减少动态效果”设置。

## 兼容性

当前版本在 DeepSeek Harness `0.1.0-rc.5` 源码版上开发和测试。插件对空状态标题的修改依赖当前 Web UI 结构；若 Harness 后续调整对应 DOM，可能需要同步更新选择器。

## 安装

### 从 GitHub 安装

已安装 `dsh` CLI：

```powershell
dsh plugin --profile web add github:DevourerM/dsh-naiwa-theme
```

从 DeepSeek Harness 源码运行：

```powershell
cd D:\path\to\deepseek-harness
pnpm dsh plugin --profile web add github:DevourerM/dsh-naiwa-theme
```

Git 安装会通过 `prepare` 构建浏览器包。pnpm 10 可能要求先在 `$DSH_HOME/profiles/web/pnpm-workspace.yaml` 中允许该构建：

```yaml
allowBuilds:
  dsh-naiwa-theme: true
```

按 pnpm 输出的提示添加后，重新运行安装命令。

### 从 tarball 安装

下载 Release 中的 `dsh-naiwa-theme-<version>.tgz`，然后执行：

```powershell
dsh plugin --profile web add .\dsh-naiwa-theme-0.5.0.tgz
```

### 从 npm 安装

包发布到 npm 后可以使用：

```powershell
dsh plugin --profile web add dsh-naiwa-theme
```

安装完成后重启 DSH；若页面仍使用旧资源，请按 `Ctrl + F5` 强制刷新。

## 更新与移除

```powershell
dsh plugin --profile web update dsh-naiwa-theme
dsh plugin --profile web remove dsh-naiwa-theme
```

源码版在命令前加 `pnpm`：

```powershell
pnpm dsh plugin --profile web remove dsh-naiwa-theme
```

## 本地开发

需要 Node.js。项目没有第三方构建依赖：

```powershell
pnpm run build
pnpm test
```

构建会将 CSS、三张主题图片和两段 MP3 内嵌进根目录的 `client.js`，运行时不依赖外部静态资源路径。

本地链接安装：

```powershell
cd D:\path\to\deepseek-harness
pnpm dsh plugin --profile web add D:\path\to\dsh-naiwa-theme
```

打包发布文件：

```powershell
pnpm test
pnpm pack
```

## 项目结构

```text
assets/                       原始图像和音频素材
src/client.template.js        浏览器端插件模板
src/index.js                  Host 端入口
styles/theme.css              主题样式
scripts/build.mjs             自包含构建脚本
tests/build.test.mjs          构建与状态转换测试
cordis.patch.yml              DSH Profile 组合包配置层
client.js                     构建后的浏览器包
index.js                      构建后的 Host 入口
```

## 素材与版权说明

- 本项目部分角色参考、图像参考及音频素材整理自互联网。
- 部分图像素材使用 GPT Image 2 生成或辅助制作。
- 两段界面提示音由互联网来源视频中的音轨截取和编辑。
- 本项目仅用于非商业娱乐、学习和插件开发交流；相关角色、原始图片、视频和音频的权利归各自权利人所有。
- 如果你是相关素材的权利人并希望调整署名或移除内容，请通过 GitHub Issue 联系维护者。

MIT License 适用于本项目自行编写的插件代码，不自动改变第三方素材或参考形象原有的权利状态。详情见 [ASSETS_NOTICE.md](./ASSETS_NOTICE.md)。

## License

插件代码采用 [MIT License](./LICENSE)。
