export const name = 'naiwa-theme'

// 主题的功能全部运行在 Web 客户端；保留这个入口以满足 DSH bundle 结构。
export function apply() {}
