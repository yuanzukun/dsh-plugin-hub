import { readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')

async function read(relativePath) {
  return readFile(resolve(root, relativePath))
}

const [hostSource, clientTemplateBuffer, cssBuffer, peek, headButton, laughMark, sendSound, laugh] = await Promise.all([
  read('src/index.js'),
  read('src/client.template.js'),
  read('styles/theme.css'),
  read('assets/naiwa-peek.webp'),
  read('assets/naiwa-head-button.webp'),
  read('assets/naiwa-laugh-mark.png'),
  read('assets/naiwa-send-crawl.mp3'),
  read('assets/naiwa-complete-laugh.mp3')
])

const replacements = new Map([
  ['__THEME_CSS__', JSON.stringify(cssBuffer.toString('utf8'))],
  ['__PEEK_DATA_URI__', JSON.stringify(`data:image/webp;base64,${peek.toString('base64')}`)],
  ['__HEAD_BUTTON_DATA_URI__', JSON.stringify(`data:image/webp;base64,${headButton.toString('base64')}`)],
  ['__LAUGH_MARK_DATA_URI__', JSON.stringify(`data:image/png;base64,${laughMark.toString('base64')}`)],
  ['__SEND_SOUND_DATA_URI__', JSON.stringify(`data:audio/mpeg;base64,${sendSound.toString('base64')}`)],
  ['__LAUGH_DATA_URI__', JSON.stringify(`data:audio/mpeg;base64,${laugh.toString('base64')}`)]
])

let clientSource = clientTemplateBuffer.toString('utf8')
for (const [placeholder, value] of replacements) {
  const occurrences = clientSource.split(placeholder).length - 1
  if (occurrences !== 1) {
    throw new Error(`${placeholder} should occur exactly once, found ${occurrences}`)
  }
  clientSource = clientSource.replace(placeholder, value)
}

if (/__[A-Z][A-Z0-9_]+__/.test(clientSource)) {
  throw new Error('An unresolved build placeholder remains in client.js')
}

await Promise.all([
  writeFile(resolve(root, 'index.js'), hostSource),
  writeFile(resolve(root, 'client.js'), clientSource)
])

console.log(`Built dsh-naiwa-theme (${Buffer.byteLength(clientSource)} byte client bundle).`)
