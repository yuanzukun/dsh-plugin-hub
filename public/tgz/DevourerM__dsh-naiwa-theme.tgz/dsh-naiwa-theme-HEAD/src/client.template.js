window.__ModuleLoader__.load({
  id: 'dsh-naiwa-theme',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    const React = require('react')

    const THEME_CSS = __THEME_CSS__
    const PEEK_DATA_URI = __PEEK_DATA_URI__
    const HEAD_BUTTON_DATA_URI = __HEAD_BUTTON_DATA_URI__
    const LAUGH_MARK_DATA_URI = __LAUGH_MARK_DATA_URI__
    const SEND_SOUND_DATA_URI = __SEND_SOUND_DATA_URI__
    const LAUGH_DATA_URI = __LAUGH_DATA_URI__

    const THEME_TOKENS = {
      '--dsw-alias-bg-base': { light: '#fbfcf7', dark: '#11130f' },
      '--dsw-alias-bg-layer-1': { light: '#ffffff', dark: '#191c16' },
      '--dsw-alias-bg-layer-2': { light: '#f5f7ed', dark: '#20241c' },
      '--dsw-alias-bg-layer-3': { light: '#edf1df', dark: '#292e22' },
      '--dsw-alias-bg-module-platform': { light: '#f9f8ee', dark: '#191c16' },
      '--dsw-alias-border-l1': { light: 'rgba(60, 70, 42, 0.10)', dark: 'rgba(232, 239, 211, 0.10)' },
      '--dsw-alias-border-l2': { light: 'rgba(60, 70, 42, 0.18)', dark: 'rgba(232, 239, 211, 0.17)' },
      '--dsw-alias-border-l3': { light: 'rgba(60, 70, 42, 0.28)', dark: 'rgba(232, 239, 211, 0.27)' },
      '--dsw-alias-brand-primary': { light: '#d9ad00', dark: '#f1c936' },
      '--dsw-alias-brand-text': { light: '#756000', dark: '#f7dc6b' },
      '--dsw-alias-button-primary-fill': { light: '#efc52f', dark: '#e8c135' },
      '--dsw-alias-button-primary-fill-hover': { light: '#d9ad00', dark: '#f5d253' },
      '--dsw-alias-button-info-fill': { light: '#5d9d45', dark: '#72b659' },
      '--dsw-alias-button-info-hover': { light: '#4c8b36', dark: '#86c86d' },
      '--dsw-alias-label-primary': { light: '#25291f', dark: '#f5f7ed' },
      '--dsw-alias-label-secondary': { light: '#5e6653', dark: '#cbd2bd' },
      '--dsw-alias-label-tertiary': { light: '#858e78', dark: '#929b86' },
      '--dsw-alias-foreground': { light: '#303629', dark: '#eef2e5' },
      '--dsw-alias-interactive-bg-hover': { light: 'rgba(105, 149, 67, 0.10)', dark: 'rgba(132, 188, 91, 0.11)' },
      '--dsw-alias-interactive-bg-active': { light: 'rgba(105, 149, 67, 0.18)', dark: 'rgba(132, 188, 91, 0.19)' },
      '--dsw-alias-state-success-primary': { light: '#4e913d', dark: '#79c363' },
      '--dsw-specific-sidebar-fill': { light: '#fff8d9', dark: '#17190f' },
      '--dsw-specific-sidebar-item-hover': { light: 'rgba(225, 188, 38, 0.11)', dark: 'rgba(241, 201, 54, 0.08)' },
      '--dsw-specific-sidebar-item-active': { light: 'rgba(225, 188, 38, 0.20)', dark: 'rgba(241, 201, 54, 0.15)' },
      '--dsw-specific-bubble': { light: '#fff8dc', dark: '#24271c' },
      '--dsw-specific-input-major': { light: 'rgba(255, 255, 251, 0.94)', dark: 'rgba(29, 33, 26, 0.94)' },
      '--dsw-specific-menu': { light: '#fffef9', dark: '#20231c' },
      '--dsw-specific-selector': { light: '#eef2e4', dark: '#292e23' },
      '--dsw-specific-tip': { light: '#344028', dark: '#e9eedf' }
    }

    function installStyles() {
      const style = document.createElement('style')
      style.dataset.plugin = 'dsh-naiwa-theme'
      style.dataset.pluginCss = 'true'
      style.textContent = `:root{--naiwa-theme-head-button:url("${HEAD_BUTTON_DATA_URI}");--naiwa-theme-laugh-mark:url("${LAUGH_MARK_DATA_URI}")}\n${THEME_CSS}`
      document.head.appendChild(style)
      return () => style.remove()
    }

    function PeekingBackdrop() {
      return React.createElement(
        'div',
        { className: 'naiwa-theme-peek-layer', 'aria-hidden': 'true' },
        React.createElement('img', {
          className: 'naiwa-theme-peek-image',
          src: PEEK_DATA_URI,
          alt: '',
          draggable: false
        })
      )
    }

    const HERO_COPY = new Map([
      ['探索未至之境', '嘎嘎滴辣虾'],
      ['Into the Unknown', '嘎嘎滴辣虾']
    ])

    function installBrandChrome() {
      const originalTitle = document.title
      const originalText = new Map()
      const classed = new Set()

      const addClass = (element, className) => {
        if (element === null || element.classList.contains(className)) return
        element.classList.add(className)
        classed.add(element)
      }

      const decorateHero = (element) => {
        addClass(element, 'naiwa-hero-title')
        let row = element?.parentElement ?? null
        for (let depth = 0; row !== null && depth < 3; depth += 1) {
          if (typeof row.querySelector === 'function' && row.querySelector('svg') !== null) {
            addClass(row, 'naiwa-hero-row')
            break
          }
          row = row.parentElement
        }
      }

      const scan = () => {
        document.title = '奶蛙 Harness'

        if (typeof NodeFilter !== 'undefined' && document.createTreeWalker !== undefined) {
          const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)
          let node = walker.nextNode()
          while (node !== null) {
            const value = (node.nodeValue ?? '').trim()
            const replacement = HERO_COPY.get(value)
            if (replacement !== undefined) {
              if (!originalText.has(node)) originalText.set(node, node.nodeValue)
              node.nodeValue = (node.nodeValue ?? '').replace(value, replacement)
              decorateHero(node.parentElement)
            } else if (value === '嘎嘎滴辣虾') {
              decorateHero(node.parentElement)
            }
            node = walker.nextNode()
          }
        }

        const sessionButtons = document.querySelectorAll(
          "button[aria-label='新建会话'],button[aria-label='New session']"
        )
        for (const button of sessionButtons) {
          const label = button.querySelector('span')
          if (label === null) {
            addClass(button, 'naiwa-brand-wordmark')
          }
        }
      }

      scan()
      const observer = new MutationObserver(scan)
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['aria-label']
      })

      return () => {
        observer.disconnect()
        document.title = originalTitle
        for (const [node, value] of originalText) {
          if (node.isConnected) node.nodeValue = value
        }
        for (const element of classed) {
          element.classList.remove('naiwa-brand-wordmark', 'naiwa-hero-title', 'naiwa-hero-row')
        }
      }
    }

    function createAudioPlayer(dataUri, volume) {
      const audio = new Audio(dataUri)
      audio.preload = 'auto'
      audio.volume = volume

      let disposed = false
      let audioContext = null
      let bufferPromise = null
      let source = null

      const fallback = () => {
        audio.currentTime = 0
        const result = audio.play()
        result?.catch?.(() => {})
      }

      const unlock = () => {
        if (audioContext !== null) {
          void audioContext.resume()
          return
        }
        const AudioContextClass = window.AudioContext ?? window.webkitAudioContext
        if (AudioContextClass === undefined) return
        audioContext = new AudioContextClass()
        void audioContext.resume()
        bufferPromise = fetch(dataUri)
          .then(response => response.arrayBuffer())
          .then(buffer => audioContext.decodeAudioData(buffer))
      }

      document.addEventListener('pointerdown', unlock, { capture: true, passive: true })

      return {
        play() {
          if (audioContext === null || bufferPromise === null) {
            fallback()
            return
          }
          void audioContext.resume()
          bufferPromise.then((buffer) => {
            if (disposed) return
            try { source?.stop() } catch {}
            source = audioContext.createBufferSource()
            source.buffer = buffer
            source.connect(audioContext.destination)
            source.start()
          }).catch(fallback)
        },
        dispose() {
          disposed = true
          document.removeEventListener('pointerdown', unlock, true)
          try { source?.stop() } catch {}
          audio.pause()
          audio.removeAttribute('src')
          audio.load()
          if (audioContext !== null) void audioContext.close()
        }
      }
    }

    function installSessionSounds(ctx) {
      const sendPlayer = createAudioPlayer(SEND_SOUND_DATA_URI, 0.52)
      const completionPlayer = createAudioPlayer(LAUGH_DATA_URI, 0.72)
      let previous = new Map()
      let celebrationTimer = null

      const celebrate = () => {
        const root = document.documentElement
        root?.classList.remove('naiwa-theme-celebrate')
        // Force a style flush so consecutive quick completions restart the animation.
        void root?.offsetWidth
        root?.classList.add('naiwa-theme-celebrate')
        if (celebrationTimer !== null) clearTimeout(celebrationTimer)
        celebrationTimer = setTimeout(() => {
          root?.classList.remove('naiwa-theme-celebrate')
          celebrationTimer = null
        }, 1300)
      }

      const remember = (snapshot) => {
        previous = new Map(snapshot.ids.map(id => [id, snapshot.byId[id]?.running === true]))
      }

      remember(ctx.sessions.list.getSnapshot())
      const unsubscribe = ctx.sessions.list.subscribe(() => {
        const snapshot = ctx.sessions.list.getSnapshot()
        let started = false
        let completed = false

        for (const id of snapshot.ids) {
          const row = snapshot.byId[id]
          if (row === undefined || row.origin === 'subagent') continue
          if (previous.get(id) !== true && row.running === true) started = true
          if (previous.get(id) === true && row.running === false) completed = true
        }

        remember(snapshot)
        if (started) sendPlayer.play()
        if (completed) {
          celebrate()
          completionPlayer.play()
        }
      })

      return () => {
        if (celebrationTimer !== null) clearTimeout(celebrationTimer)
        document.documentElement?.classList.remove('naiwa-theme-celebrate')
        unsubscribe()
        sendPlayer.dispose()
        completionPlayer.dispose()
      }
    }

    const inject = ['theme', 'sessions', 'slots']

    function apply(ctx) {
      ctx.effect(
        () => ctx.theme.overrideTokens('dsh-naiwa-theme', THEME_TOKENS),
        'naiwa-theme: neutral milk-frog palette'
      )
      ctx.effect(installStyles, 'naiwa-theme: image and control styles')
      ctx.effect(installBrandChrome, 'naiwa-theme: restrained brand chrome')
      ctx.effect(() => installSessionSounds(ctx), 'naiwa-theme: send and completion sounds')
      ctx.slots.inject('shell.overlay', () => ctx.slots.register({
        name: 'shell.overlay',
        id: 'naiwa-theme-peeking-background',
        order: -100
      }, PeekingBackdrop))
    }

    exports.inject = inject
    exports.apply = apply
    return module.exports
  }
})
