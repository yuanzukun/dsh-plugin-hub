import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import test from 'node:test'
import vm from 'node:vm'

const root = resolve(import.meta.dirname, '..')

test('package declares the runtime and theme client edges', async () => {
  const pkg = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8'))
  assert.equal(pkg.name, 'dsh-naiwa-theme')
  assert.equal(pkg.version, '0.5.0')
  assert.equal(pkg.dsh.client.platform, 'web')
  assert.ok(pkg.dsh.client.inject.includes('@deepseek-ai/dsh-client-runtime'))
  assert.ok(pkg.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-theme'))
  assert.ok(pkg.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-slots'))
})

test('built client embeds the restrained visual set and both sounds', async () => {
  const client = await readFile(resolve(root, 'client.js'), 'utf8')
  assert.match(client, /window\.__ModuleLoader__\.load\(/)
  assert.equal((client.match(/data:image\/webp;base64,/g) ?? []).length, 2)
  assert.equal((client.match(/data:image\/png;base64,/g) ?? []).length, 1)
  assert.equal((client.match(/data:audio\/mpeg;base64,/g) ?? []).length, 2)
  assert.match(client, /naiwa-theme-peek-layer/)
  assert.match(client, /aria-label='发送消息'/)
  assert.match(client, /naiwa-brand-wordmark/)
  assert.match(client, /嘎嘎滴辣虾/)
  assert.match(client, /naiwa-hero-title/)
  assert.match(client, /naiwa-hero-row > :first-child > svg/)
  assert.match(client, /naiwa-theme-celebrate/)
  assert.doesNotMatch(client, /naiwa-theme-wave-image|naiwa-theme-sleep-image|naiwa-theme-charms-image/)
  assert.doesNotMatch(client, /欢迎来到奶蛙 Harness|奶蛙栖息地|奶蛙设置|奶蛙标准模式|奶蛙可写|召唤奶蛙/)
  assert.doesNotMatch(client, /button\[aria-haspopup='listbox'\]/)
  assert.doesNotMatch(client, /naiwa-theme-widget|naiwa-theme-mascot/)
  assert.doesNotMatch(client, /__[A-Z][A-Z0-9_]+__/)
})

test('client plays send and completion sounds on top-level transitions', async () => {
  const client = await readFile(resolve(root, 'client.js'), 'utf8')
  let definition
  let playCount = 0
  let snapshot = {
    ids: ['main'],
    byId: { main: { id: 'main', running: false } }
  }
  let subscriber
  let registration
  let redundantTextWrites = 0
  let heroTextWrites = 0
  const rootClasses = new Set()
  const makeClassList = set => ({
    contains: value => set.has(value),
    add: (...values) => values.forEach(value => set.add(value)),
    remove: (...values) => values.forEach(value => set.delete(value))
  })
  const heroRowClasses = new Set()
  const heroTitleClasses = new Set()
  const heroRow = {
    classList: makeClassList(heroRowClasses),
    parentElement: null,
    querySelector: selector => selector === 'svg' ? {} : null
  }
  const heroTitle = {
    classList: makeClassList(heroTitleClasses),
    parentElement: heroRow
  }
  const heroTextNode = {
    nodeType: 3,
    isConnected: true,
    parentElement: heroTitle,
    _value: '探索未至之境',
    get nodeValue() { return this._value },
    set nodeValue(value) { heroTextWrites += 1; this._value = value }
  }
  const sessionLabelNode = {
    nodeType: 3,
    isConnected: true,
    _value: '召唤奶蛙',
    get nodeValue() { return this._value },
    set nodeValue(value) { redundantTextWrites += 1; this._value = value }
  }
  const sessionButtonClasses = new Set()
  const sessionButton = {
    classList: {
      contains: value => sessionButtonClasses.has(value),
      add: value => sessionButtonClasses.add(value),
      remove: value => sessionButtonClasses.delete(value)
    },
    getAttribute: name => name === 'aria-label' ? '新建会话' : null,
    querySelector: selector => selector === 'span' ? { childNodes: [sessionLabelNode] } : null
  }
  const document = {
    body: {},
    title: 'DeepSeek Harness',
    documentElement: {
      offsetWidth: 100,
      classList: {
        add: value => rootClasses.add(value),
        remove: value => rootClasses.delete(value)
      }
    },
    head: { appendChild() {} },
    createElement: () => ({ dataset: {}, remove() {} }),
    createTreeWalker: () => {
      let visited = false
      return { nextNode: () => visited ? null : (visited = true, heroTextNode) }
    },
    querySelector: () => null,
    querySelectorAll: selector => selector === 'textarea[placeholder]' ? [] : [sessionButton],
    addEventListener() {},
    removeEventListener() {}
  }
  class FakeMutationObserver {
    observe() {}
    disconnect() {}
  }
  class FakeAudio {
    play() { playCount += 1; return Promise.resolve() }
    pause() {}
    load() {}
    removeAttribute() {}
  }
  const loaderWindow = { __ModuleLoader__: { load: value => { definition = value } } }
  vm.runInNewContext(client, {
    Audio: FakeAudio,
    MutationObserver: FakeMutationObserver,
    NodeFilter: { SHOW_TEXT: 4 },
    clearTimeout() {},
    document,
    fetch: () => Promise.reject(new Error('unused')),
    setTimeout: () => 1,
    window: loaderWindow,
    console
  })
  const plugin = definition.factory((id) => {
    assert.equal(id, 'react')
    return { createElement() {} }
  })
  const effects = []
  plugin.apply({
    effect(factory) { effects.push(factory()); return effects.at(-1) },
    theme: { overrideTokens: () => () => {} },
    sessions: {
      list: {
        getSnapshot: () => snapshot,
        subscribe: fn => { subscriber = fn; return () => { subscriber = undefined } }
      }
    },
    slots: {
      inject(name, factory) {
        assert.equal(name, 'shell.overlay')
        return factory()
      },
      register(config, component) {
        registration = { config, component }
        return () => {}
      }
    }
  })

  assert.deepEqual([...plugin.inject], ['theme', 'sessions', 'slots'])
  assert.equal(registration.config.id, 'naiwa-theme-peeking-background')
  assert.equal(typeof registration.component, 'function')
  assert.equal(redundantTextWrites, 0)
  assert.equal(heroTextWrites, 1)
  assert.equal(heroTextNode.nodeValue, '嘎嘎滴辣虾')
  assert.ok(heroTitleClasses.has('naiwa-hero-title'))
  assert.ok(heroRowClasses.has('naiwa-hero-row'))
  assert.equal(sessionButtonClasses.has('naiwa-new-session'), false)
  assert.equal(playCount, 0)

  snapshot = { ids: ['main'], byId: { main: { id: 'main', running: true } } }
  subscriber()
  assert.equal(playCount, 1)
  snapshot = { ids: ['main'], byId: { main: { id: 'main', running: false } } }
  subscriber()
  assert.equal(playCount, 2)
  assert.ok(rootClasses.has('naiwa-theme-celebrate'))

  snapshot = { ids: ['main'], byId: { main: { id: 'main', running: false } } }
  subscriber()
  assert.equal(playCount, 2)
  effects.reverse().forEach(dispose => dispose?.())
})

test('subagent completion does not trigger the laugh', async () => {
  const client = await readFile(resolve(root, 'client.js'), 'utf8')
  assert.match(client, /row\.origin === 'subagent'/)
})
