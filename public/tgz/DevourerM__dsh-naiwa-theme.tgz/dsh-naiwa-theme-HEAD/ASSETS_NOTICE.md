# Assets Notice

This repository is a non-commercial fan project.

- Some character references, image references, video clips, and audio sources were collected from the Internet.
- Some image assets were generated or assisted with GPT Image 2.
- The interface sound effects were edited from audio tracks in Internet-sourced videos.
- Rights in the original characters and third-party source materials remain with their respective rights holders.

The MIT License in this repository applies to the original plugin code. It does not relicense third-party materials, source references, character rights, or audio/video content beyond permissions held by the project maintainer.

Rights holders may open a GitHub Issue to request attribution changes or removal.
