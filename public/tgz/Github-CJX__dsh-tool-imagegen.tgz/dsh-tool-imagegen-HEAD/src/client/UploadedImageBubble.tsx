/**
 * The shadowed `user` node renderer, registered into `conversation.chat.node`
 * for key 'user' at priority -1 (the platform's UserMessageNodeView sits at
 * priority 0; the lowest priority wins, so every user message flows through
 * this view).
 *
 * It is a faithful replica of the shipped user bubble — same row/stack/bubble
 * chrome, same hover clock + copy actions — extended with this plugin's
 * `uploaded-image` blocks (text-model uploads): those render inline through
 * the plugin's own loopback attachment bridge (the platform's loadImage only
 * authorizes `image` blocks). The model-facing envelope text (prefixed with
 * UPLOAD_ENVELOPE_PREFIX) is filtered out of the bubble; the user sees the
 * picture and their own words.
 *
 * IMPORTANT: reference images are drawn with plain `<img>` elements resolved
 * through the load face — NOT through the attachment package's ImageGallery.
 * ImageGallery is an internal component of @deepseek-ai/dsh-client-ui-attachment
 * whose client module exports only { apply, inject }; importing it yields
 * `undefined` at runtime, which made this renderer crash with React error #130
 * on its very first message (the entry then abdicated and every user bubble
 * fell back to the shipped renderer, exposing the raw model-facing envelope).
 *
 * The same hazard applies to every primitive this file used to import by name:
 * DSH 2.0.10's @deepseek-ai/dsh-client-ui-primitives no longer exports
 * `MessageText`, so that import was `undefined` and reproduced exactly that
 * crash/abdication. All primitives now resolve through {@link primitive} with
 * inline fallbacks, and user text renders as plain text.
 */

import { memo, useCallback, useEffect, useMemo, useRef, useState, type ComponentType, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
// Namespace import on purpose: this package's named exports drift between DSH
// releases (2.0.10 replaced `MessageText` with a `projectUserText` that returns
// the projected nodes itself). A missing named export is NOT a build error —
// it is `undefined` at runtime, and rendering `<undefined>` makes React throw
// error #130, which ABDICATES this shadowed entry. Every user bubble would then
// fall back to the shipped renderer and leak the raw model-facing envelope.
// Each primitive is therefore resolved through one defensive lookup below.
import * as primitivesModule from '@deepseek-ai/dsh-client-ui-primitives'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type { ContentBlock } from '@deepseek-ai/dsh-llm/types'
import { envelopeRequestText, UPLOAD_ENVELOPE_PREFIX, type UploadedImageBlock } from './protocol.ts'
import css from './uploaded-image-bubble.module.css'

/** Defensive primitive lookup: an absent export degrades to a fallback, never throws. */
function primitive<T>(name: string, fallback: T): T {
  const value = (primitivesModule as unknown as Record<string, unknown>)[name]
  return value === undefined ? fallback : value as T
}

/**
 * Resolve the first primitive name that this build actually ships. Icon exports
 * are renamed between releases without being part of a published contract —
 * `IconCopyOutline16` became `IconCopyOutlineRegular` — so each icon is looked
 * up under every name it has carried.
 * @param names - candidate export names, most recent first.
 * @param fallback - rendered when none of them exists.
 * @returns the first shipped component, or the fallback.
 */
function primitiveIcon<T>(names: string[], fallback: T): T {
  for (const name of names) {
    const value = (primitivesModule as unknown as Record<string, unknown>)[name]
    if (value !== undefined) return value as T
  }
  return fallback
}

/** Stand-in for an icon that this DSH build no longer ships. */
function NoIcon(): ReactNode {
  return null
}

/** Tooltip stand-in: render the labelled child unchanged. */
function PassthroughTooltip(props: { children?: ReactNode }): ReactNode {
  return props.children ?? null
}

/** Serialize one block for the fallback inspector without throwing on cycles. */
function safeJson(value: unknown): string {
  try {
    return JSON.stringify(value, null, 2) ?? ''
  } catch {
    return '[unserializable content block]'
  }
}

/** JsonBlock stand-in: same disclosure shape, no primitive dependency. */
function PlainJsonBlock(props: { label: string; payload: unknown }): ReactNode {
  return (
    <details className={css.jsonFallback}>
      <summary>{props.label}</summary>
      <pre className={css.jsonFallbackBody}>{safeJson(props.payload)}</pre>
    </details>
  )
}

/** Clipboard stand-in: the standard async API, reporting success like the primitive. */
async function fallbackWriteClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    return false
  }
}

const IconCheckOutline16 = primitiveIcon<ComponentType>(['IconCheckOutlineRegular', 'IconCheckOutline16'], NoIcon)
const IconCopyOutline16 = primitiveIcon<ComponentType>(['IconCopyOutlineRegular', 'IconCopyOutline16'], NoIcon)
const Tooltip = primitive<ComponentType<{ children?: ReactNode }>>('Tooltip', PassthroughTooltip)
const JsonBlock = primitive<ComponentType<{ label: string; payload: unknown; truncatedLabel?: (total: number) => string }>>('JsonBlock', PlainJsonBlock)
const writeClipboard = primitive<(text: string) => Promise<boolean>>('writeClipboard', fallbackWriteClipboard)

/** Props the composed chat-node entry receives (owner + standard seats). */
export type UploadedImageBubbleProps =
  PropsRuntime<'conversation.chat.node'>
  & PropsLocale<'dsh-imagegen'>

/** The translated text seat the copy action and clock read. */
type Translate = UploadedImageBubbleProps['t']

/** Message timestamp carrier in the transcript node data. */
type NodeTime = string | number | Date | undefined

/** Two-digit zero pad for the clock. */
function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n)
}

/**
 * Format a message time as a clock (same-day) or date + clock (older), with
 * the same calendar-day grouping as the shipped bubble.
 */
function formatClock(time: NodeTime, t: Translate): string | undefined {
  if (time === undefined) return undefined
  const date = new Date(time)
  if (Number.isNaN(date.getTime())) return undefined
  const now = new Date()
  const clock = `${pad2(date.getHours())}:${pad2(date.getMinutes())}`
  if (date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth() && date.getDate() === now.getDate()) {
    return clock
  }
  const params = { y: date.getFullYear(), m: date.getMonth() + 1, d: date.getDate() }
  const dateLabel = date.getFullYear() === now.getFullYear() ? t('clock.md', params) : t('clock.ymd', params)
  return `${dateLabel} ${clock}`
}

/**
 * Display projection of reference forms in a user bubble — the shipped
 * `projectUserText` replication: plain-text `/name` / `@name` word-boundary
 * tokens decorate as chips, everything else stays plain text. Text renders as
 * plain React text (the shipped projection does the same); it must NOT depend
 * on a text primitive, whose name changed across DSH releases.
 */
function projectUserText(text: string): ReactNode {
  const pattern = /(^|\s)([/@][\w-]+)(?=\s|$)/g
  const parts: ReactNode[] = []
  let cursor = 0
  let match: RegExpExecArray | null
  while ((match = pattern.exec(text)) !== null) {
    const tokenStart = match.index + (match[1]?.length ?? 0)
    const label = match[2] ?? ''
    if (tokenStart > cursor) parts.push(text.slice(cursor, tokenStart))
    parts.push(
      <span
        key={tokenStart}
        className={css.refChip}
        data-ref-chip={label.startsWith('@') ? 'subagent' : 'skill'}
      >
        {label}
      </span>,
    )
    cursor = tokenStart + label.length
  }
  if (parts.length === 0) return text
  if (cursor < text.length) parts.push(text.slice(cursor))
  return <>{parts}</>
}

/** The hover copy action (shipped MessageIconActions replication, copy only). */
function CopyAction({ text, t }: { text: string; t: Translate }) {
  const [copied, setCopied] = useState(false)
  const pending = useRef(false)
  const timer = useRef<number | null>(null)
  const epoch = useRef(0)

  useEffect(() => () => {
    epoch.current += 1
    pending.current = false
    if (timer.current !== null) window.clearTimeout(timer.current)
  }, [])

  const onCopy = useCallback(() => {
    if (copied || pending.current) return
    const generation = epoch.current
    pending.current = true
    void writeClipboard(text).then((ok) => {
      if (generation !== epoch.current) return
      pending.current = false
      if (!ok) return
      setCopied(true)
      timer.current = window.setTimeout(() => {
        timer.current = null
        setCopied(false)
      }, 1000)
    })
  }, [copied, text])

  return (
    <Tooltip label={copied ? t('copied') : t('copy')} side="bottom">
      <button
        type="button"
        className={css.action}
        aria-label={copied ? t('copied') : t('copy')}
        onClick={onCopy}
      >
        {copied ? <IconCheckOutline16 /> : <IconCopyOutline16 />}
      </button>
    </Tooltip>
  )
}

/** Narrow one content block to a text block. */
function isTextBlock(block: ContentBlock): block is Extract<ContentBlock, { type: 'text' }> {
  return block !== null && typeof block === 'object' && 'type' in block && block.type === 'text' && typeof block.text === 'string'
}

/** Narrow one content block to a platform `image` block. */
function isImageBlock(block: ContentBlock): block is Extract<ContentBlock, { type: 'image' }> {
  return block !== null && typeof block === 'object' && 'type' in block && block.type === 'image' && block.attachment !== undefined
}

/** Narrow one content block to this plugin's uploaded-image block. */
function isUploadedImageBlock(block: ContentBlock): block is UploadedImageBlock {
  return block !== null && typeof block === 'object' && 'type' in block && block.type === 'uploaded-image' && block.attachment !== undefined
}

/** A usable display name for one attachment (ref name or fallback). */
function attachmentName(attachment: ImageAttachmentRef): string {
  if (typeof attachment.name === 'string' && attachment.name !== '') return attachment.name
  return typeof attachment.mediaType === 'string' && attachment.mediaType === 'image/gif' ? 'image.gif' : 'image.png'
}

/** Resolve one attachment and render it as an `<img>` (self-drawn gallery). */
function BubbleImage(props: {
  attachment: ImageAttachmentRef
  load: (attachment: ImageAttachmentRef) => Promise<string>
  /** Single images render large; several render as square tiles. */
  tile: boolean
  onView: (url: string, name: string) => void
  t: Translate
}) {
  const { attachment, load, tile, onView, t } = props
  const [url, setUrl] = useState<string | undefined>(undefined)
  const [failed, setFailed] = useState<string | undefined>(undefined)

  useEffect(() => {
    let alive = true
    load(attachment)
      .then((resolved) => { if (alive) setUrl(resolved) })
      .catch((error: unknown) => {
        if (alive) setFailed(error instanceof Error ? error.message : String(error))
      })
    return () => { alive = false }
  }, [load, attachment])

  if (url !== undefined) {
    const name = attachmentName(attachment)
    return (
      <button
        type="button"
        className={tile ? css.thumb : css.hero}
        title={name}
        aria-label={t('image.label')}
        onClick={() => onView(url, name)}
      >
        <img className={css.img} src={url} alt={name} loading="lazy" />
      </button>
    )
  }
  if (failed !== undefined) {
    return <span className={css.stateLine} role="status">{t('image.loadFailed')}</span>
  }
  return <span className={css.stateLine}>{t('image.loading')}</span>
}

/**
 * Fullscreen image overlay: dark backdrop, Esc / backdrop-click closes.
 *
 * Portaled to `document.body` for the same reason the generated-image viewer
 * is: the bubble sits inside the transcript's scroll container, where an
 * in-place `position: fixed` overlay can be trapped by an ancestor's stacking
 * or containing block and never appear above the page.
 */
function BubbleLightbox(props: { url: string; name: string; closeLabel: string; onClose: () => void }) {
  const { url, name, closeLabel, onClose } = props
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = previousOverflow
    }
  }, [onClose])
  if (typeof document === 'undefined') return null
  return createPortal(
    <div className={css.lightbox} role="dialog" aria-modal="true" aria-label={name} onClick={onClose}>
      <button type="button" className={css.lightboxClose} aria-label={closeLabel} onClick={onClose}>✕</button>
      <img
        className={css.lightboxImg}
        src={url}
        alt={name}
        onClick={(event) => event.stopPropagation()}
      />
    </div>,
    document.body,
  )
}

/**
 * Render one user message: images (platform `image` + plugin `uploaded-image`)
 * above the text bubble, then the hover actions column.
 * @param props - the chat-node owner share, standard seats, and locale seat.
 * @returns the user bubble row.
 */
export const UploadedImageBubble = memo(function UploadedImageBubble(props: UploadedImageBubbleProps) {
  const { node, loadImage, t, sessionId } = props
  // Shape guards: never throw on an unexpected node carrier — a throw would
  // abdicate this shadowed renderer and fall back to the shipped bubble,
  // which would show the raw model-facing envelope text.
  const record = node !== null && typeof node === 'object'
    ? (node as { data?: unknown }).data
    : undefined
  const message = record !== null && typeof record === 'object'
    ? record as { content?: unknown; time?: NodeTime }
    : undefined
  const content = Array.isArray(message?.content) ? message.content as ContentBlock[] : []
  const time = message?.time
  // The fullscreen overlay holds one image at a time (url + display name).
  const [viewing, setViewing] = useState<{ url: string; name: string } | undefined>(undefined)

  // Classify: envelope text is model-facing only (filtered out of the bubble);
  // platform images go through the native loader; plugin uploads go through
  // the plugin's attachment bridge; everything else lands in JsonBlock.
  const texts: string[] = []
  const images: ImageAttachmentRef[] = []
  const rest: ContentBlock[] = []
  for (const block of content) {
    if (isTextBlock(block)) {
      // Envelope text is model-facing only — except the user's own typed
      // request, which the host embeds in its third line: extract and show it.
      if (block.text.startsWith(UPLOAD_ENVELOPE_PREFIX)) {
        const request = envelopeRequestText(block.text)
        if (request !== undefined) texts.push(request)
        continue
      }
      texts.push(block.text)
      continue
    }
    if (isImageBlock(block)) {
      images.push(block.attachment)
      continue
    }
    if (isUploadedImageBlock(block)) {
      images.push(block.attachment)
      continue
    }
    rest.push(block)
  }
  const text = texts.join('')
  const showBubble = text !== '' || rest.length > 0

  // Every image — the platform's own `image` block or this plugin's
  // `uploaded-image` block — resolves through the loader the chat-node owner
  // supplies. Both block types carry a durable attachment reference that the
  // session log authorizes, so one loader covers both and the plugin never
  // serves bytes itself.
  const load = useCallback(
    (attachment: ImageAttachmentRef) => Promise.resolve(loadImage(attachment)).then((url) => {
      if (typeof url !== 'string' || url === '') throw new Error('图片地址不可用（会话未授权该附件）')
      return url
    }),
    [loadImage],
  )

  const clock = useMemo(() => formatClock(time, t), [time, t])
  const truncated = useCallback((total: number) => t('json.truncated', { total }), [t])
  const tile = images.length > 1

  return (
    <div className={css.userRow} data-time-hover-root>
      <div className={css.userStack}>
        {images.length > 0
          ? (
            <div className={css.images}>
              {images.map((attachment, index) => (
                <BubbleImage
                  key={`${String(attachment.attachmentId)}:${index}`}
                  attachment={attachment}
                  load={load}
                  tile={tile}
                  onView={(url, name) => setViewing({ url, name })}
                  t={t}
                />
              ))}
            </div>
          )
          : null}
        {showBubble && (
          <div className={css.bubble}>
            {projectUserText(text)}
            {rest.map((block, index) => (
              <JsonBlock
                key={index}
                label={t('message.extraBlock')}
                payload={block}
                truncatedLabel={truncated}
              />
            ))}
          </div>
        )}
      </div>
      <div className={css.actions}>
        {clock !== undefined ? <span className={css.timeStart}>{clock}</span> : null}
        <CopyAction text={text} t={t} />
      </div>
      {viewing !== undefined
        ? <BubbleLightbox url={viewing.url} name={viewing.name} closeLabel={t('image.closePreview')} onClose={() => setViewing(undefined)} />
        : null}
    </div>
  )
})
