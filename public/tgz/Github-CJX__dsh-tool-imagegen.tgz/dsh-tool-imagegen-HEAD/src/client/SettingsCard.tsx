/**
 * The dsh-tool-imagegen settings card: api_url, api_key (secret, display-only
 * "set" state), model (default gpt-image-2, hand-editable), size, count, and
 * the plugin switches. Registers into the official `plugins.item` slot — the
 * Plugins page's list of configurable plugins, where this entry is the card's
 * one-liner in `view: 'summary'` and its body in `view: 'page'` — bound to the
 * platform's own configuration-form service for the `dsh-imagegen` entry.
 *
 * Performance: the card subscribes to the whole staged-form snapshot, so every
 * keystroke rebuilds it. To keep typing smooth the field controls are memoized
 * and every per-field handler is referentially stable (built once from the
 * stable form actions) — a keystroke in one field re-renders only that field,
 * not all twenty.
 */

import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import { createSnapshotStore, type SnapshotStore } from '@deepseek-ai/dsh-client-store'
import { CardForm, booleanField, numberField, secretField, textField, type CardActions, type CardShell, type FieldState as CardFieldState } from './settings-form.ts'
import type { ImageGenScope } from './settings-scope.ts'
import { StorageSection, type MaintenanceCardFace } from './MaintenanceCard.tsx'
import css from './settings-card.module.css'

/**
 * Disclosure chevron. Drawn inline rather than taken from
 * `@deepseek-ai/dsh-client-ui-primitives`: that package's icon export names are
 * renamed between releases (2.0.10's `IconChevronDownOutline14` is
 * `IconChevronDownOutlineRegular` here), they are not part of a published
 * contract, and a missing export renders `undefined` — which makes React throw
 * and abdicates this slot entry, hiding the whole settings page. One 12px glyph
 * is not worth that coupling: it is decoration, and `currentColor` keeps the
 * host theme in charge of its colour.
 * @param props.className - the rotation class owned by the stylesheet.
 * @returns the chevron glyph.
 */
function Chevron({ className }: { className?: string }) {
  return (
    <svg className={className} width="12" height="12" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
      <path d="M4 6.5 8 10.5 12 6.5" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

/** The fields this card edits (the namespace's full schema). */
export interface ImageGenSettings {
  enabled?: boolean
  announceToAgent?: boolean
  apiUrl?: string
  apiKey?: string
  model?: string
  size?: string
  n?: number
  quality?: string
  output_format?: string
  background?: string
  style?: string
  moderation?: string
  watermark?: string
  /** Enable switches for all six optional params ("check to use this
   *  parameter"; off by default — the field is locked and the value is
   *  neither sent upstream nor advertised to the model). */
  quality_enabled?: boolean
  output_format_enabled?: boolean
  background_enabled?: boolean
  style_enabled?: boolean
  moderation_enabled?: boolean
  watermark_enabled?: boolean
}

/** What the card renders. */
export interface ImageGenSettingsCardState extends CardShell {
  /** Master switch. */
  enabled: CardFieldState
  /** System-prompt announcement flag. */
  announceToAgent: CardFieldState
  /** API base URL. */
  apiUrl: CardFieldState
  /** API key draft (the stored value is never rendered). */
  apiKey: CardFieldState
  /** Upstream model name (default gpt-image-2). */
  model: CardFieldState
  /** Image size. */
  size: CardFieldState
  /** Image count (1–4). */
  n: CardFieldState
  /** Optional quality (low/medium/high). */
  quality: CardFieldState
  /** Optional output format (png/jpeg/webp). */
  output_format: CardFieldState
  /** Optional background (transparent/opaque/auto). */
  background: CardFieldState
  /** Optional style (vivid/natural). */
  style: CardFieldState
  /** Optional moderation (low/medium/high). */
  moderation: CardFieldState
  /** Optional watermark (triw/none/auto). */
  watermark: CardFieldState
  /** Enable switches for the six optional parameters. */
  quality_enabled: CardFieldState
  output_format_enabled: CardFieldState
  background_enabled: CardFieldState
  style_enabled: CardFieldState
  moderation_enabled: CardFieldState
  watermark_enabled: CardFieldState
}

/** Enum suggestion lists for the optional upstream parameters (editable, not enforced). */
const ENUM_OPTIONS: Record<string, string[]> = {
  quality: ['low', 'medium', 'high'],
  output_format: ['png', 'jpeg', 'webp'],
  background: ['transparent', 'opaque', 'auto'],
  style: ['vivid', 'natural'],
  moderation: ['low', 'medium', 'high'],
  watermark: ['triw', 'none', 'auto'],
}

/** Official gpt-image-2 canvas sizes (最大边 ≤ 3840px；'auto' = 上游默认).
 *  A suggestion list only — any size the upstream accepts can be typed. */
const SIZE_OPTIONS = ['auto', '512x512', '1024x1024', '1536x1024', '1024x1536', '2048x2048', '2048x1152', '3840x2160', '2160x3840']

/** The registration-side face the card's slot entry injects. */
export interface ImageGenSettingsCardFace extends CardActions {
  hooks: {
    /** Card snapshot bound by the renderer as useImageGenSettingsCard. */
    imageGenSettingsCard: SnapshotStore<ImageGenSettingsCardState>
    /** Whether a secret (apiKey) is currently stored. */
    imageGenKeySet: SnapshotStore<boolean>
  }
  /** Storage-maintenance face for the embedded cleanup section (rc.7: one card per key). */
  maintenance: MaintenanceCardFace
}

/** Bridges the imagegen scope onto the card's staged form. */
export class ImageGenSettingsCardController {
  private readonly form: CardForm<ImageGenSettings>

  /** @param scope - the bound bridge scope for the dsh-imagegen namespace. */
  constructor(private readonly scope: ImageGenScope) {
    this.form = new CardForm(scope, [
      booleanField('enabled'),
      booleanField('announceToAgent'),
      textField('apiUrl'),
      secretField('apiKey'),
      textField('model'),
      textField('size'),
      numberField('n'),
      textField('quality'),
      textField('output_format'),
      textField('background'),
      textField('style'),
      textField('moderation'),
      textField('watermark'),
      booleanField('quality_enabled'),
      booleanField('output_format_enabled'),
      booleanField('background_enabled'),
      booleanField('style_enabled'),
      booleanField('moderation_enabled'),
      booleanField('watermark_enabled'),
    ], {
      // The redacted wire view never returns the key; a save's outcome is
      // judged by the namespace's secrets sidecar instead.
      secretSettled: () => this.scope.getKeySetSnapshot(),
    })
  }

  private projection(): ImageGenSettingsCardState {
    return {
      ...this.form.shell(),
      enabled: this.form.field('enabled'),
      announceToAgent: this.form.field('announceToAgent'),
      apiUrl: this.form.field('apiUrl'),
      apiKey: this.form.field('apiKey'),
      model: this.form.field('model'),
      size: this.form.field('size'),
      n: this.form.field('n'),
      quality: this.form.field('quality'),
      output_format: this.form.field('output_format'),
      background: this.form.field('background'),
      style: this.form.field('style'),
      moderation: this.form.field('moderation'),
      watermark: this.form.field('watermark'),
      quality_enabled: this.form.field('quality_enabled'),
      output_format_enabled: this.form.field('output_format_enabled'),
      background_enabled: this.form.field('background_enabled'),
      style_enabled: this.form.field('style_enabled'),
      moderation_enabled: this.form.field('moderation_enabled'),
      watermark_enabled: this.form.field('watermark_enabled'),
    }
  }

  /**
   * Build the face the card's slot registration injects.
   * @returns the card's snapshot, the key-set flag, and the form actions.
   */
  inject(): ImageGenSettingsCardFace {
    const cardStore = this.form.bind(() => this.projection())
    const keySetStore = createSnapshotStore(this.scope.getKeySetSnapshot())
    this.scope.subscribeKeySet(() => { keySetStore.set(this.scope.getKeySetSnapshot()) })
    return {
      hooks: {
        imageGenSettingsCard: cardStore,
        imageGenKeySet: keySetStore,
      },
      ...this.form.actions(),
    }
  }
}

/** Props the renderer binds for this card. */
export type ImageGenSettingsCardProps =
  PropsRuntime<'plugins.item'>
  & PropsLocale<'dsh-imagegen'>
  & InjectFace<ImageGenSettingsCardFace>

/**
 * Render the card.
 *
 * The Plugins page asks one registration for two different things: `view:
 * 'summary'` is the one-liner on the plugin's card in the list, and `view:
 * 'page'` is the body of the plugin's own page. Only the page draws the form —
 * returning the form for the summary would nest the whole card inside its own
 * list row.
 * @param props - the requested view, locale copy, the card snapshot, the
 *   injected maintenance face, and the form actions.
 * @returns the one-liner, the card, or nothing while the namespace is loading.
 */
export function ImageGenSettingsCard(props: ImageGenSettingsCardProps) {
  const { t, maintenance } = props
  const state = props.useImageGenSettingsCard(snapshot => snapshot)
  const keySet = props.useImageGenKeySet(snapshot => snapshot)
  const [open, setOpen] = useState(false)
  if (props.view === 'summary') return t('cardDescription')
  if (!state.available) return null
  const title = t('cardTitle')
  const blocked = !state.dirty || state.invalid || state.saving
  const disabled = !state.writable
  const fieldProps = {
    overriddenLabel: t('overridden'),
    resetLabel: t('reset'),
    invalidLabel: t('invalidNumber'),
    disabled,
    comboAriaLabel: t('comboAria'),
    comboEmptyLabel: t('comboEmpty'),
  }

  // Stable per-field handlers: the form actions (props.edit / props.resetField)
  // are cached by the slot renderer, so building each field's handler object
  // once lets the memoized ValueField/BooleanField controls skip re-rendering
  // when an unrelated field's snapshot changed.
  const handlers = useMemo(() => {
    const text = (field: string) => ({
      onEdit: (value: string) => { props.edit(field, value) },
      onReset: () => { props.resetField(field) },
      onClear: () => { props.resetField(field) },
    })
    const gated = (field: string) => ({
      onEdit: (value: string) => { props.edit(field, value) },
      onReset: () => { props.resetField(field) },
      onChecked: (checked: boolean) => { props.edit(`${field}_enabled`, checked ? 'true' : 'false') },
    })
    const flag = (field: string) => ({
      onEdit: (value: string) => { props.edit(field, value) },
      onReset: () => { props.resetField(field) },
    })
    return {
      apiKey: text('apiKey'),
      apiUrl: text('apiUrl'),
      model: text('model'),
      size: text('size'),
      quality: gated('quality'),
      output_format: gated('output_format'),
      background: gated('background'),
      style: gated('style'),
      moderation: gated('moderation'),
      watermark: gated('watermark'),
      n: text('n'),
      enabled: flag('enabled'),
      announceToAgent: flag('announceToAgent'),
    }
  }, [props.edit, props.resetField])

  if (!state.exposed) {
    return (
      <li className={css.card}>
        <button
          type="button"
          className={css.header}
          aria-expanded={open}
          aria-label={`${t(open ? 'collapse' : 'expand')}: ${title}`}
          onClick={() => { setOpen(!open) }}
        >
          <span className={css.headText}>
            <span className={css.name}>{title}</span>
            <span className={css.description}>{t('cardDescription')}</span>
          </span>
          <Chevron className={open ? css.chevronOpen : css.chevron} />
        </button>
        {open
          ? (
            <div className={css.body}>
              <p className={css.notExposed} role="status">{t('notExposed')}</p>
            </div>
          )
          : null}
      </li>
    )
  }
  return (
    <li className={css.card}>
      <button
        type="button"
        className={css.header}
        aria-expanded={open}
        aria-label={`${t(open ? 'collapse' : 'expand')}: ${title}`}
        onClick={() => { setOpen(!open) }}
      >
        <span className={css.headText}>
          <span className={css.name}>{title}</span>
          <span className={css.description}>{t('cardDescription')}</span>
        </span>
        {state.dirty ? <span className={css.pending}>{t('unsaved')}</span> : null}
        <Chevron className={open ? css.chevronOpen : css.chevron} />
      </button>
      {open
        ? (
          <div className={css.body}>
            {!state.writable ? <p className={css.readOnly} role="status">{t('readOnly')}</p> : null}
            <ValueField
              id="dsh-imagegen-settings-apikey"
              label={t('fieldApiKey')}
              hint={keySet ? t('apiKeySet') : t('fieldApiKeyHelp')}
              placeholder="sk-…"
              secret
              {...fieldProps}
              {...state.apiKey}
              overridden={false}
              onEdit={handlers.apiKey.onEdit}
              onReset={handlers.apiKey.onReset}
              clearLabel={t('apiKeyClear')}
              onClear={handlers.apiKey.onClear}
              canClear={keySet}
            />
            <ValueField
              id="dsh-imagegen-settings-apiurl"
              label={t('fieldApiUrl')}
              hint={t('fieldApiUrlHelp')}
              placeholder="https://api.ephone.ai/v1"
              {...fieldProps}
              {...state.apiUrl}
              onEdit={handlers.apiUrl.onEdit}
              onReset={handlers.apiUrl.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-model"
              label={t('fieldModel')}
              hint={t('fieldModelHelp')}
              placeholder="gpt-image-2"
              {...fieldProps}
              {...state.model}
              onEdit={handlers.model.onEdit}
              onReset={handlers.model.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-size"
              label={t('fieldSize')}
              hint={t('fieldSizeHelp')}
              placeholder="auto"
              comboOptions={SIZE_OPTIONS}
              {...fieldProps}
              {...state.size}
              onEdit={handlers.size.onEdit}
              onReset={handlers.size.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-quality"
              label={t('fieldQuality')}
              hint={state.quality_enabled.text === 'true' ? t('fieldQualityHelp') : t('fieldGatedHint')}
              placeholder={t('fieldOptionalPlaceholder')}
              comboOptions={ENUM_OPTIONS.quality}
              checked={state.quality_enabled.text === 'true'}
              onChecked={handlers.quality.onChecked}
              {...fieldProps}
              {...state.quality}
              locked={state.quality_enabled.text !== 'true'}
              onEdit={handlers.quality.onEdit}
              onReset={handlers.quality.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-output-format"
              label={t('fieldOutputFormat')}
              hint={state.output_format_enabled.text === 'true' ? t('fieldOutputFormatHelp') : t('fieldUnsupportedHint')}
              placeholder={t('fieldOptionalPlaceholder')}
              comboOptions={ENUM_OPTIONS.output_format}
              checked={state.output_format_enabled.text === 'true'}
              onChecked={handlers.output_format.onChecked}
              {...fieldProps}
              {...state.output_format}
              locked={state.output_format_enabled.text !== 'true'}
              onEdit={handlers.output_format.onEdit}
              onReset={handlers.output_format.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-background"
              label={t('fieldBackground')}
              hint={state.background_enabled.text === 'true' ? t('fieldBackgroundHelp') : t('fieldGatedHint')}
              placeholder={t('fieldOptionalPlaceholder')}
              comboOptions={ENUM_OPTIONS.background}
              checked={state.background_enabled.text === 'true'}
              onChecked={handlers.background.onChecked}
              {...fieldProps}
              {...state.background}
              locked={state.background_enabled.text !== 'true'}
              onEdit={handlers.background.onEdit}
              onReset={handlers.background.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-style"
              label={t('fieldStyle')}
              hint={state.style_enabled.text === 'true' ? t('fieldStyleHelp') : t('fieldUnsupportedHint')}
              placeholder={t('fieldOptionalPlaceholder')}
              comboOptions={ENUM_OPTIONS.style}
              checked={state.style_enabled.text === 'true'}
              onChecked={handlers.style.onChecked}
              {...fieldProps}
              {...state.style}
              locked={state.style_enabled.text !== 'true'}
              onEdit={handlers.style.onEdit}
              onReset={handlers.style.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-moderation"
              label={t('fieldModeration')}
              hint={state.moderation_enabled.text === 'true' ? t('fieldModerationHelp') : t('fieldGatedHint')}
              placeholder={t('fieldOptionalPlaceholder')}
              comboOptions={ENUM_OPTIONS.moderation}
              checked={state.moderation_enabled.text === 'true'}
              onChecked={handlers.moderation.onChecked}
              {...fieldProps}
              {...state.moderation}
              locked={state.moderation_enabled.text !== 'true'}
              onEdit={handlers.moderation.onEdit}
              onReset={handlers.moderation.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-watermark"
              label={t('fieldWatermark')}
              hint={state.watermark_enabled.text === 'true' ? t('fieldWatermarkHelp') : t('fieldUnsupportedHint')}
              placeholder={t('fieldOptionalPlaceholder')}
              comboOptions={ENUM_OPTIONS.watermark}
              checked={state.watermark_enabled.text === 'true'}
              onChecked={handlers.watermark.onChecked}
              {...fieldProps}
              {...state.watermark}
              locked={state.watermark_enabled.text !== 'true'}
              onEdit={handlers.watermark.onEdit}
              onReset={handlers.watermark.onReset}
            />
            <ValueField
              id="dsh-imagegen-settings-count"
              label={t('fieldCount')}
              hint={t('fieldCountHelp')}
              placeholder="1"
              {...fieldProps}
              {...state.n}
              onEdit={handlers.n.onEdit}
              onReset={handlers.n.onReset}
            />
            <BooleanField
              id="dsh-imagegen-settings-enabled"
              label={t('fieldEnabled')}
              hint={t('fieldEnabledHelp')}
              inheritLabel={t('inherit')}
              onLabel={t('on')}
              offLabel={t('off')}
              {...fieldProps}
              {...state.enabled}
              onEdit={handlers.enabled.onEdit}
              onReset={handlers.enabled.onReset}
            />
            <BooleanField
              id="dsh-imagegen-settings-announce"
              label={t('fieldAnnounce')}
              hint={t('fieldAnnounceHelp')}
              inheritLabel={t('inherit')}
              onLabel={t('on')}
              offLabel={t('off')}
              {...fieldProps}
              {...state.announceToAgent}
              onEdit={handlers.announceToAgent.onEdit}
              onReset={handlers.announceToAgent.onReset}
            />
            <div className={css.footer}>
              {state.failed ? <p className={css.failed} role="status">{t('failed')}</p> : null}
              <button
                type="button"
                className={css.discard}
                disabled={!state.dirty || state.saving}
                onClick={props.discard}
              >
                {t('discard')}
              </button>
              <button
                type="button"
                className={css.save}
                disabled={blocked}
                onClick={props.save}
              >
                {t(!state.saving ? 'save' : 'saving')}
              </button>
            </div>
            <StorageSection t={t} fetchFn={maintenance.fetchFn} />
          </div>
        )
        : null}
    </li>
  )
}

/** Props every field control needs regardless of its value type. */
interface FieldProps {
  /** Stable id associating the label with its control. */
  id: string
  /** Visible label. */
  label: string
  /** One-line explanation rendered under the control. */
  hint: string
  /** Draft text this control renders. */
  text: string
  /** True when saving would leave a user-layer entry for this field. */
  overridden: boolean
  /** True when the draft is not a value this field accepts. */
  invalid: boolean
  /** Copy for the overridden badge. */
  overriddenLabel: string
  /** Copy for the reset control. */
  resetLabel: string
  /** Copy shown in place of the hint while the draft is invalid. */
  invalidLabel: string
  /** Disables every control (read-only document, or an unavailable namespace). */
  disabled: boolean
  /** aria-label of the combo toggle button. */
  comboAriaLabel?: string
  /** Copy for the combo panel's empty-suggestion row. */
  comboEmptyLabel?: string
  /** Stage draft text. */
  onEdit: (text: string) => void
  /** Stage a clear so the field re-inherits the composition layer. */
  onReset: () => void
}

/**
 * A staged value field; `secret` renders a password control and
 * `comboOptions` renders a self-drawn editable combo (input + option panel
 * styled as part of the card — the native datalist popup looked detached
 * from the card). Suggestions are hints only: any typed value is kept,
 * the panel filters by substring, and the current draft is marked.
 * Memoized: with stable handlers + primitive props it re-renders only when
 * its own draft changed, not when a sibling field was edited.
 */
const ValueField = memo(function ValueField(props: FieldProps & {
  /** Render a password control. */
  secret?: boolean
  /** Placeholder shown while the draft is empty. */
  placeholder?: string
  /** Label of the dedicated clear control (secret fields). */
  clearLabel?: string
  /** Stage a clear of the stored secret. */
  onClear?: () => void
  /** Whether a stored secret exists (enables the clear control). */
  canClear?: boolean
  /** Suggestion values for the editable combo. */
  comboOptions?: string[]
  /** When present, renders a "use this parameter" checkbox before the label.
   *  Unchecked locks the control and (host-side) drops the parameter from the
   *  upstream request and the tool schema. */
  checked?: boolean
  /** Stage the enable-switch state the checkbox edits. */
  onChecked?: (checked: boolean) => void
  /** Parameter disabled by its unchecked enable box (locks the input only —
   *  the checkbox itself must stay clickable so it can be turned on). */
  locked?: boolean
}) {
  const [open, setOpen] = useState(false)
  const [focusIndex, setFocusIndex] = useState(0)
  const comboRef = useRef<HTMLDivElement>(null)

  // Close on outside pointer-down or Escape while the panel is open.
  useEffect(() => {
    if (!open) return
    const onDown = (event: PointerEvent) => {
      if (event.target instanceof Node && comboRef.current?.contains(event.target) === false) {
        setOpen(false)
      }
    }
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('pointerdown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('pointerdown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  const needle = props.text.trim().toLowerCase()
  // Filter by substring while typing, BUT show every option when the current
  // text is an exact option value — otherwise opening the panel with the
  // default value (e.g. "1024x1024") already in the box filters the list down
  // to that single option and the dropdown looks empty of alternatives.
  const exactMatch = props.comboOptions !== undefined
    && props.comboOptions.includes(props.text.trim())
  const matches = props.comboOptions !== undefined
    ? (exactMatch
      ? props.comboOptions
      : props.comboOptions.filter(option => option.toLowerCase().includes(needle)))
    : []
  // Reset the arrow-key position when typing narrows the suggestions.
  useEffect(() => { setFocusIndex(0) }, [needle])

  const combo = props.comboOptions !== undefined
    ? (
      <div className={css.combo} ref={comboRef}>
        <input
          id={props.id}
          className={props.invalid ? css.comboInputInvalid : css.comboInput}
          type="text"
          autoComplete="off"
          role="combobox"
          aria-expanded={open}
          aria-controls={`${props.id}-options`}
          aria-activedescendant={open && matches[focusIndex] !== undefined
            ? `${props.id}-option-${focusIndex}`
            : undefined}
          {...props.invalid ? { 'aria-invalid': true } : {}}
          value={props.text}
          placeholder={props.placeholder ?? ''}
          disabled={props.disabled || props.locked === true}
          onChange={(event) => { props.onEdit(event.target.value) }}
          onClick={() => { if (!props.disabled && props.locked !== true && !open) setOpen(true) }}
          onFocus={() => { if (!props.disabled && props.locked !== true && props.text.trim() !== '') setOpen(true) }}
          onKeyDown={(event) => {
            if (event.key === 'ArrowDown') {
              event.preventDefault()
              setOpen(true)
              setFocusIndex(Math.min(focusIndex + 1, Math.max(matches.length - 1, 0)))
            } else if (event.key === 'ArrowUp') {
              event.preventDefault()
              setOpen(true)
              setFocusIndex(Math.max(focusIndex - 1, 0))
            } else if (event.key === 'Enter' && open && matches[focusIndex] !== undefined) {
              event.preventDefault()
              props.onEdit(matches[focusIndex])
              setOpen(false)
            }
          }}
        />
        <button
          type="button"
          className={css.comboToggle}
          aria-label={props.comboAriaLabel}
          aria-expanded={open}
          disabled={props.disabled || props.locked === true}
          onClick={() => { setOpen(!open) }}
        >
          <Chevron />
        </button>
        {open
          ? (
            <div className={css.comboPanel} id={`${props.id}-options`} role="listbox">
              {matches.length === 0
                ? <div className={css.comboEmpty}>{props.comboEmptyLabel}</div>
                : matches.map((option, index) => (
                  <button
                    type="button"
                    id={`${props.id}-option-${index}`}
                    key={option}
                    role="option"
                    aria-selected={option === props.text.trim()}
                    className={option === props.text.trim()
                      ? `${css.comboOption} ${css.comboOptionSelected}`
                      : css.comboOption}
                    onMouseEnter={() => { setFocusIndex(index) }}
                    onMouseDown={(event) => { event.preventDefault() }}
                    onClick={() => { props.onEdit(option); setOpen(false) }}
                  >
                    {option}
                  </button>
                ))}
            </div>
          )
          : null}
      </div>
    )
    : null

  return (
    <div className={css.field}>
      <div className={css.head}>
        <label className={css.label} htmlFor={props.id}>{props.label}</label>
        {props.overridden
          ? (
            <span className={css.badges}>
              <span className={css.badge}>{props.overriddenLabel}</span>
              <button
                type="button"
                className={css.reset}
                disabled={props.disabled}
                onClick={props.onReset}
              >
                {props.resetLabel}
              </button>
            </span>
          )
          : null}
        {props.secret === true && props.canClear === true
          ? (
            <button
              type="button"
              className={css.reset}
              disabled={props.disabled}
              onClick={props.onClear}
            >
              {props.clearLabel ?? props.resetLabel}
            </button>
          )
          : null}
      </div>
      <div className={css.comboRow}>
        {props.checked !== undefined && props.onChecked !== undefined
          ? (
            <input
              type="checkbox"
              className={css.enableCheck}
              aria-label={props.label}
              checked={props.checked}
              disabled={props.disabled}
              onChange={(event) => { props.onChecked(event.target.checked) }}
            />
          )
          : null}
        {combo ?? (
          <input
            id={props.id}
            className={props.invalid ? css.inputInvalid : css.input}
            type={props.secret === true ? 'password' : 'text'}
            autoComplete={props.secret === true ? 'off' : undefined}
            {...props.invalid ? { 'aria-invalid': true } : {}}
            value={props.text}
            placeholder={props.placeholder ?? ''}
            disabled={props.disabled || props.locked === true}
            onChange={(event) => { props.onEdit(event.target.value) }}
          />
        )}
      </div>
      <p className={props.invalid ? css.invalid : css.hint}>
        {props.invalid ? props.invalidLabel : props.hint}
      </p>
    </div>
  )
})

/** A staged boolean field: 继承 / 开 / 关. Memoized like ValueField. */
const BooleanField = memo(function BooleanField(props: FieldProps & {
  /** Copy for the inherit option. */
  inheritLabel: string
  /** Copy for the on option. */
  onLabel: string
  /** Copy for the off option. */
  offLabel: string
}) {
  return (
    <div className={css.field}>
      <div className={css.head}>
        <label className={css.label} htmlFor={props.id}>{props.label}</label>
        {props.overridden
          ? (
            <span className={css.badges}>
              <span className={css.badge}>{props.overriddenLabel}</span>
              <button
                type="button"
                className={css.reset}
                disabled={props.disabled}
                onClick={props.onReset}
              >
                {props.resetLabel}
              </button>
            </span>
          )
          : null}
      </div>
      <select
        id={props.id}
        className={css.select}
        value={props.text}
        disabled={props.disabled}
        onChange={(event) => { props.onEdit(event.target.value) }}
      >
        <option value="">{props.inheritLabel}</option>
        <option value="true">{props.onLabel}</option>
        <option value="false">{props.offLabel}</option>
      </select>
      <p className={css.hint}>{props.hint}</p>
    </div>
  )
})
