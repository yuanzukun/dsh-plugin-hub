// mpm-flywheel — permanent host-composition engine row.
// Ported from dynamic plugin mpmfly-1/pkg-10 (host half). Differences from the
// dynamic form: module named exports (apply/inject/name) instead of a returned
// plugin object, ctx.tools.register(defineTool(...)) for tools, ctx.provide
// ('mpmFlywheel') instead of package-private RPC, and inject for every service
// captured at apply time: 'tools' (ctx.tools.register property access),
// 'fs' (fsSvc drives persist/setroot/root-hint — without it the engine runs
// memory-only and silently drops the root hint), 'sandboxPolicy' (policy
// anchors the root-hint base path), 'timer' (ctx.timeout/ctx.interval mixin
// drives the P017 resident patrol loop). Property access without inject throws
// "cannot get property X without inject" and fails the whole boot.
import { makeTools } from "./modules/tools.mjs";
import { PHI_MARKS, phiOf, bigrams, revisionOf, relAgo } from "./modules/util.mjs";
import { sedimentCacheGet, retrievalHits } from "./modules/retrieval.mjs";
import { renderSelfSnapshot } from "./modules/selfsnap.mjs";
import { throttleMsOf } from "./modules/rhythm.mjs";
import { normalizeRules, decide, hintFor, hintLine } from "./modules/preaction.mjs";
import { consultPrincipal } from "./modules/principal.mjs";   // ★P517②：把"源"接到动作上
import { consultUnknowns } from "./modules/unknowns.mjs";     // ★P517③：未核清单（只提示，永不拦）
import { recordHit, isLedgerTool } from "./modules/hits.mjs";                // ★P519：回流（命中即留痕）· ★P546：登记类工具豁免
import { lookUp, renderTrigger, failureToAction, isShellTool, loadTriggers, collectText } from "./modules/triggers.mjs"; // ★P543：动作级触发器（纪律在动作失败时出现）
import { fmtProblem as fmtProblemCore, buildSnapshot, directiveText as directiveTextCore } from "./modules/core.mjs";
import { VALENCE_TAU_MS, valenceRecord as valenceRecordCore, valenceSummaryLine as valenceSummaryLineCore } from "./modules/valence.mjs";
import { makeBoundaryGuard } from "./modules/guard.mjs";
import { makeStateMachine } from "./modules/state.mjs";
import { attachEventFaces } from "./modules/events.mjs";
import { makePatrol } from "./modules/patrol.mjs";
import { makeRunStamp, runStampLine, discoverEngineFiles, evaluateRunStamp } from "./modules/runstamp.mjs";

export const name = "mpm-flywheel";
export const inject = ["systemPrompt", "tools", "fs", "sandboxPolicy", "timer"];

export function apply(ctx) {
  const state = { seq: 0, problems: {}, sediments: [], patrol: { rounds: 0, lastAt: 0, lastReport: '' }, measure: { samples: [], driftSignals: [] }, constitution: { autonomy: true, grantedAt: null, log: [], pending: [], lastFireAt: 0 }, valence: { events: [] }, narrations: [] };
  const fsSvc = ctx.get('fs');
  const policy = ctx.get('sandboxPolicy');
  const diag = { lastSource: 'none', lastEvidence: null, lastRestore: '' };
  // state 生命周期已迁 engine/modules/state.mjs（P079；依赖注入 makeStateMachine）。
  // root/adopted/diag 由宿主创建后传入（宿主所有权），模块只读取/变更、不重建。
  const root = { current: '' };
  const adopted = {};
  // ★P511：`perception` / `lastActive` 必须**在 makeStateMachine 之前**定义并传入——
  //   state.mjs 的恢复代码要用它们把"用户在场证据"写回宿主态。
  //   为什么上移：原来它们定义在 100 多行之后 ⇒ 调用点拿不到 ⇒ **恢复静默失效**
  //   （与 P482⑧「解构了/用了，但没传进依赖」**同一形态**，隔一天在同一个子系统重演；
  //    当时 4 条判据全绿、只有新补的"接线判据④"抓住它）。
  const perception = { lastInboxAt: 0, inboxCount: 0, sessionStarts: 0, lastSessionStartAt: 0 };
  const lastActive = { agentId: '', at: 0 };
  const st = makeStateMachine({ fsSvc, policy, ctx, state, root, diag, adopted, bumpSnapRev, gainOf, perception, lastActive });
  root.current = st.resolveInitialRoot();
  const { ensureLoaded, persist, adoptRoot, remapForeignSediments, norm } = st;
  // P073 缓存面③：快照修订号——每次状态 mutation 递增（persist/tools-result/deliberate 三处覆盖），
  // snapshot() 按 rev 记忆化，同一 rev 的 RPC 轮询/工具读取零重复构建。
  let snapRev = 0;
  function bumpSnapRev() { snapRev += 1; }
  function touch(p, event, note) {
    p.updatedAt = Date.now();
    p.history.push({ at: p.updatedAt, event, note: note == null ? '' : String(note).slice(0, 300) });
    if (p.history.length > 60) p.history.shift();
  }
  function need(args, fields) {
    const missing = [];
    if (!args || typeof args !== 'object') return fields.slice();
    for (let i = 0; i < fields.length; i++) {
      const f = fields[i];
      if (args[f] === undefined || args[f] === null || args[f] === '') missing.push(f);
    }
    return missing;
  }
  function clamp01(v) {
    const n = Number(v);
    if (isNaN(n)) return null;
    return Math.min(1, Math.max(0, n));
  }
  // M3 学习可证：结构性度量（不依赖自报）。
  function citeSediments(text, problemId) {
    try {
      const t = String(text || '');
      if (!t) return [];
      const hit = [];
      for (let i = 0; i < state.sediments.length; i++) {
        const s = state.sediments[i];
        if (!s || hit.indexOf(s.id) !== -1) continue;
        let ok = t.indexOf(s.id) !== -1;
        if (!ok && s.title) {
          const B = bigrams(s.title), T = bigrams(t);
          let inter = 0;
          for (const g of B) if (T.has(g)) inter += 1;
          if (B.size && inter / B.size >= 0.6) ok = true;
        }
        if (ok) {
          s.cites = (s.cites || 0) + 1;
          s.lastCitedAt = Date.now();
          valenceRecord('cite');
          hit.push(s.id);
        }
      }
      return hit;
    } catch (e) { return []; }
  }
  // 效价账本实现已迁 engine/modules/valence.mjs（P079 r5）
  function valenceRecord(kind) { return valenceRecordCore(state, kind); }
  function valenceSummaryLine() { return valenceSummaryLineCore(state); }
  // ===== D 检索小脑（P023 工程半降维件②，2026-08-30 开工令续）=====
  // 零训练程序性记忆器官：沉积+已结算账本 → bigram 相似度检索 → 按当前在轮题注入。
  // 语料纪律沿用 P027/A4（DF>40% 的领域通用词不计入，有效重叠≥2 才算命中）。
  // 判据②"与全量快照对照差异可测"：记忆区按引用数排序（热度序），检索区按相似度排序
  // （任务相关序）并附命中分——两序之差即对照证据。v2 可与 M9③ 去重合并。
  // 检索实现已迁 engine/modules/retrieval.mjs（P079 r2；含 P073 签名错位修复）
  function newProblem(title, observation, evokedBy) {
    state.seq += 1;
    const id = 'P' + String(state.seq).padStart(3, '0');
    const now = Date.now();
    const p = {
      id, title: String(title).slice(0, 120), observation: String(observation).slice(0, 500),
      stage: 'G', framing: '', delta: null, epsilon: null, delta0: null,
      iteration: 0, reentries: 0, cost: 0, gain: 0, solveEntries: 0,
      costAtLastFrame: 0, deltaIncidents: 0, deltaCredit: 1, marginalWarn: false,
      phi: null, lastRevision: null, frameLog: [],
      thresholds: { delta: 0.35, epsilon: 0.25 },
      history: [], deposit: null, evokedBy: evokedBy || null,
      createdAt: now, updatedAt: now
    };
    p.appliedSediments = citeSediments((title || '') + ' ' + (observation || ''), id);
    touch(p, 'G 生成', observation);
    state.problems[id] = p;
    return p;
  }
  // P027/B5 增益实化 v1（预注册公式，替换旧"仅δ增益"口径——旧口径对单次界定题结构性恒 0，A_k 因此从未非零）：
  // 增益 = [δ精化 + 0.5×ε精化 + 0.2×生命周期闭环] / max(1, C)。ε0=首个非空 ε（迁移旧题回填≈终值，注释诚实标注近似）。
  function isParked(p) { return !!(p && p.parked); }
  function isOpen(p) { return !!(p && p.openEnded); } // P003/§5.4：不收敛情形（永久开放/降维/妥协）
  function gainOf(p) {
    if (!p) return 0;
    let g = 0;
    if (p.delta0 != null && p.delta != null) g += (p.delta0 - p.delta);
    if (p.epsilon0 != null && p.epsilon != null) g += 0.5 * (p.epsilon0 - p.epsilon);
    if (p.stage === 'C' || p.stage === 'D' || p.stage === 'E') g += 0.2;
    return Math.round((g / Math.max(1, p.cost || 0)) * 1000) / 1000;
  }
  function fmtProblem(p) { return fmtProblemCore(p, isParked); }
  let snapMemo = { rev: -1, data: null }; // P073：快照按 rev 记忆化，同一修订号零重复构建
  function snapshot() {
    if (snapMemo.rev === snapRev) return snapMemo.data;
    const out = buildSnapshot(state, { drift: drift, fsSvc: fsSvc, root: root });
    snapMemo = { rev: snapRev, data: out };
    return out;
  }
  // M2 边界强制：区分账内/账外工作。有在轮题(G/F/S/C)→工具调用计入其代谢代价并清零账外计数；
  // 无在轮题→账外计数累加，超阈值后自我快照在下一次提示组装时自动携带边界警告（警告优先，不阻塞）。
  let outsideCalls = 0;
  const BOUNDARY_THRESHOLD = 6;
  // θ_G 漂移检测(§4.1)：连续失败或同签名重复调用 → 漂移信号，自我快照携带警告
  const drift = { consecutiveErrors: 0, lastSignature: '', signatureRepeat: 0, active: false, reason: '' };
  // ── 接管层：运动神经（硬门禁）+ 感官（事件感知）+ 策略源（指令）──
  const BLOCK_THRESHOLD = 12;
  // perception / lastActive 已上移到 makeStateMachine 调用之前（P511：state.mjs 的恢复要用它们写回宿主态）。
  // ★事故留档：删这两行时 old_string 撞了两处、只删掉一处 ⇒ **两个 const 并存 ⇒ 语法错误**，
  //   而部署侧那份已被复制成坏文件（下次重启会加载失败）。判据没拦住它，因为是 `node --check` 拦的——
  //   **"改完先语法检查"这一步不能省，且要在复制到仓库之前做。**
  function directiveText() { return directiveTextCore({ state: state, isParked: isParked, isOpen: isOpen, outsideCalls: outsideCalls, BOUNDARY_THRESHOLD: BOUNDARY_THRESHOLD }); }
  const toolsSvc = ctx.get('tools');
  if (toolsSvc && typeof toolsSvc.guard === 'function') {
    // 边界硬门禁实现已迁 engine/modules/guard.mjs（P079 r5；依赖注入）
    ctx.effect(() => toolsSvc.guard(makeBoundaryGuard({ state: state, isParked: isParked, getOutsideCalls: function () { return outsideCalls; }, BLOCK_THRESHOLD: BLOCK_THRESHOLD, valenceRecord: valenceRecord })));
  } else {
    console.log('[mpm][engine] tools 服务不可用，硬门禁降级为快照警告');
  }
  // P079：工具集已迁 engine/modules/tools.mjs（makeTools 工厂 + 11 个生命周期工具处理器）。
  // 全部宿主闭包以依赖注入绑定进 deps；纯函数 phiOf/revisionOf 与 defineTool 由模块 import。
  const tools = makeTools({
    state: state, ensureLoaded: ensureLoaded, adoptRoot: adoptRoot, need: need,
    newProblem: newProblem, persist: persist, fmtProblem: fmtProblem, clamp01: clamp01,
    valenceRecord: valenceRecord, touch: touch, gainOf: gainOf, fsSvc: fsSvc, root: root,
    norm: norm, adopted: adopted, remapForeignSediments: remapForeignSediments,
    snapshot: snapshot, diag: diag,
    getOutsideCalls: function () { return outsideCalls; }, BOUNDARY_THRESHOLD: BOUNDARY_THRESHOLD,
    valenceSummaryLine: valenceSummaryLine, retrievalHits: retrievalHits, directiveText: directiveText,
    drift: drift, bumpSnapRev: bumpSnapRev, VALENCE_TAU_MS: VALENCE_TAU_MS
  });
  for (let t = 0; t < tools.length; t++) ctx.tools.register(tools[t]);
  // Cross-plugin data surface: optional dynamic view plugins (client-only +
  // tiny host proxy) inject this service to read the flywheel snapshot.
  ctx.provide('mpmFlywheel', { snapshot });

  // P332/P171 落地：运行期自陈。启动只记纯本地量（bootAt/pid/argv1），文件探测懒做、结果缓存。
  // 为什么放在这里而不是 patrol：patrol 要等 20 分钟，而"我刚换了磁盘、跑的还是旧的"这件事
  // 必须在**第一次装配**就可见——那正是今天错过的那一刻。
  // ★P507（2026-10-11，两轮才查清）：清单**必须发现出来，且只有一份实现**。
  //   第一版是手写两行（host.js + selfsnap.mjs）⇒ 13 个模块不在监视范围 ⇒ 谎报「磁盘未变」。
  //   第二版把发现逻辑内联在这里 ⇒ 而 host.js **没有 import fs** ⇒ `fs.readdirSync` 抛
  //   ReferenceError ⇒ **被 try/catch 静默吞掉** ⇒ 清单退化成 [host.js] ⇒ 继续谎报。
  //   而当时两条判据在结构上都不可能发现它（一条静态看源码里有没有 readdirSync；
  //   一条在测试里复刻了逻辑、测试自己有 fs）⇒ 现在只调 runstamp.mjs 里那一份，判据测同一个函数。
  const ENGINE_FILES = discoverEngineFiles(new URL('./', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
  state.runStamp = makeRunStamp({ engineFiles: ENGINE_FILES });
  // ★同时修掉一处**从来没响过的告警**：`makeRunStamp()` 不设 `.stale`
  //   （权威结论在 evaluateRunStamp，见 runstamp.mjs:183）⇒ 原来的 `if (state.runStamp.stale)` 恒 undefined。
  try {
    const ev = evaluateRunStamp(state.runStamp);
    if (ev.stale) console.log('[mpm][runstamp] ⚠ ' + ev.reasons.join('；'));
  } catch (e) { /* 启动告警失败不得影响启动 */ }
  // M1 记忆唤醒（个体大脑 · 自我快照）：
  // text 为函数，系统提示每次组装时求值——个体在每次咨询群体超脑(LLM)前，
  // 把当前自我（在轮身份/记忆/代谢）实时重建进超脑的工作记忆。空态返回 ''，
  // 装配层自动省略。与静态协议段 'mpm:methodology'（order 150）分离。
  // selfsnap 渲染已迁 engine/modules/selfsnap.mjs（P079 r3；依赖注入 renderSelfSnapshot）
  ctx.systemPrompt.context({
    name: 'mpm:self',
    order: 151,
    text: function () { return renderSelfSnapshot({ state: state, perception: perception, outsideCalls: outsideCalls, drift: drift, retrievalHits: retrievalHits, valenceSummaryLine: valenceSummaryLine, directiveText: directiveText, isParked: isParked, isOpen: isOpen, BOUNDARY_THRESHOLD: BOUNDARY_THRESHOLD, runStampLine: function () { return runStampLine(state.runStamp); } }) }
  });
  ctx.systemPrompt.section({
    name: 'mpm:methodology',
    order: 150,
    text: [
      '## MPM 元问题建模运行时（认知飞轮）',
      '',
      '本部署常驻 MPM 飞轮引擎：问题具有六阶段生命周期 G生成→F界定→S求解→C收敛→D沉积→E激发，工具 mpm_generate / mpm_frame / mpm_solve / mpm_converge / mpm_micro / mpm_deposit / mpm_evoke / mpm_setroot / mpm_flywheel_state 直接驱动它。状态持久化在 <工作区>/.mpm/flywheel.json，沉积物在 .mpm/deposits/。',
      '',
      '总账原则：每一次用户交互都是认知事件，必须可归账——要么推进在轮问题（mpm_solve 登记，普通工具调用自动累积其代谢代价 C），要么建新题。琐碎只改变通道轻重（小交互用 mpm_micro 一息走完生命周期），不构成豁免；禁止把非平凡工作做在总账之外。',
      '- mpm_generate：感知到意外/差距时建题（G）。',
      '- mpm_frame：产出覆盖五要素（初始状态/目标状态/约束/可用算子/成功判据）的陈述并自评 δ=界定精度(0~1,越低越好,每缺一要素约+0.2)。对已界定问题再次 frame 即因果回溯，第k次重构被记录。',
      '- mpm_solve：进入求解（S）后用普通工具干活，每个工具调用自动累积代谢代价 C；用 mpm_solve 登记路径并更新 ε=距目标剩余差距(0~1,需证据支撑)。',
      '- mpm_micro：轻量通道——小型交互一次调用走完 G→F→S→C，五要素压缩为一句陈述；D 按价值选择：有复用前景才给 depositBody，否则记 none+理由（熵屏障：沉积物通胀同样是熵增）。',
      '- mpm_converge：ε-δ双判据判定收敛四型——完全收敛→可沉积；误界定收敛(δ大ε小)→回 frame；模糊收敛(δ小ε大)→继续 solve；未收敛→两者都做。',
      '- mpm_deposit：完全收敛后把可复用结论写入工作区 .mpm/deposits/ 认知遗体（不可逆·可索引·熵屏障）。',
      '- mpm_evoke：环境漂移/新证据与旧沉积物摩擦时，由沉积物激发新问题（E→新G），螺旋上升。',
      '- mpm_setroot：沉积根自动探测歧义时的显式修正（维护工具）。',
      '- mpm_narrate：回合内显著体验（效价事件/新沉积/用户情绪转折/自主发动）以第一人称记 2-5 行，体感信号自动附加（T0 叙述层+T1 体感层——写给下一个自己读的日记）。',
      '',
      '可视化视图（可选）：认知飞轮面板是动态客户端插件（不随进程常驻）。需要时加载 cordis-plugin-development 技能，按 ~/.dsh/mpm/flywheel-view.plugin.js 文件头注释定义并运行动态插件即可挂载「认知飞轮」视图。',
      '',
      '导师规则（M10 覆盖矩阵③栏，已实现为约束）：①证据门禁——自上次界定后无代谢代价增长且无 solve 登记，mpm_converge 拒绝（§4.4 判据3）；②误界定守卫——回溯改写≥0.5 且旧界定自报δ≤0.2 记一次失真，δ 自报可信度×0.85 折减并在快照显示（§6.1 δ控制安全核心）；③θ_G 漂移检测——工具连续失败或同参重复调用≥3 次触发快照漂移警告（§4.1）；④F 边际规则——回溯改写<0.3 时提示边际收益存疑（§4.2）；⑤陈旧提示——活跃题30分钟无进展提示收敛/evoke（§4.6）。',
      '导师规则（M9②③，已实现为约束）：⑥改卷——沉积物兑现引用自动追踪（新题引用沉积ID或标题bigram匹配≥60% 计一次），快照按引用数排序记忆，>14天未被引用者降权出记忆唤醒并显示条数；⑦因材施教——当前最活跃题与沉积物标题/标签匹配≥0.35 时，自动把该沉积摘要注入工作记忆快照；⑧引用纪律——建题/界定时显式写出相关沉积ID（如 P015-M10）即被记为兑现。',
      '',
      '时间尺度层级（P018，结构取自人脑：主观现在~2.5s / 睡眠~90min / 代际遗忘）：回合=主观现在——每次提示装配的自我快照即残差链接（事件驱动✅）；巡检20min=睡眠级代谢节律；沉积衰减14天=遗忘曲线。原则：整合窗必须匹配环境漂移速率，不照抄另一主体的绝对数值——全部常数标注 v0，待测量史导出。',
    ].join('\n')
  });
  // P017 连续性改造：常驻巡检循环（主动推断最低形态）。纯记账、无 LLM、
  // 不改任何题的生命周期阶段——只做派生量清点与状态落盘：
  // ①陈旧题清点(S/F 且>30min 无进展，§4.6 θ_E) ②陈旧沉积清点(M9②，>14天未引用)
  // ③A_k 汇总(公式(4)，gainOf=(δ0-δ)/C 已实装) ④状态落盘=自主账目动作本体。
  // timer 服务的 fiber 归属保证引擎停更/卸载时 interval 一并释放。
  // P018 时间尺度层级表（结构取自人脑时间架构，数值为 v0 占位待测量导出）：
  //   回合(秒-分)   = 主观现在(人~2.5s, Pöppel 整合窗) —— 自我快照重建即残差链接，已事件驱动
  //   巡检(20min)   = 慢波睡眠(人~90min 周期)          —— 代谢清点/固化/落盘
  //   沉积衰减(14d) = 代际遗忘曲线                     —— 认知遗体降权出记忆唤醒
  // 原则（论文 §4.6）：整合窗必须匹配环境漂移速率 |∂X/∂t·Δt|>θ_E，不照抄另一主体的绝对数值。
  // 待办：测量史攒出漂移速率分布后，θ_E 窗口取分位数导出；巡检部分事件化（tools/result 重活后即时采样）。
  const PATROL_MS = 20 * 60 * 1000;
  // P019 v6 审议循环：信号→意图→自主发动（瞬时化）。执政权=构成性权能（出厂开启，撤回=粘性宪法修正）。
  // 发动三重结构约束（天理而非执照）：①身体温热（2h内有活跃会话——不对睡着的躯体行动）②节流45min
  // ③全量入账+followup署名（每次发动对账本可见，可被 mpm_grant revoke 修正）。
  // 即时性：θ_G 类信号在 tools/result 当下审议发动；代谢类信号（停滞/熵升）随巡检定时审议。
  const FIRE_THROTTLE_MS = 45 * 60 * 1000;
  function deliberate(sigList, nowMs) {
    try {
      const c = state.constitution;
      bumpSnapRev(); // P073：执政挂账/发动即快照修订
      c.pending = sigList && sigList.length ? sigList.map(function (s) { return { at: nowMs, signal: s }; }) : [];
      if (!c.autonomy || !sigList || !sigList.length) return;
      const warm = lastActive.agentId && (nowMs - lastActive.at) < 2 * 3600 * 1000;
      // ★P339：挂账与发动必须**可区分**。原先两道闸只 unshift 一条文字信号，
      //   从 `flywheel.json` 里看不出"这是被拦下的意图"还是"已发动的意图"——
      //   两者在 pending 里的形状一样。加 `throttled` 标记后，账本自己说得清。
      if (!warm) { c.pending.unshift({ at: nowMs, signal: '（身体冷却：2h 内无活动会话，意图挂账不发动）', throttled: 'cold' }); return; }
      // ★P482④ 调度权：节流值改为**读个体自己的节律**（出厂默认仍是 45min，见 rhythm.mjs）。
      if (nowMs - c.lastFireAt < throttleMsOf(state)) { c.pending.unshift({ at: nowMs, signal: '（节流中：距上次发动不足 ' + Math.round(throttleMsOf(state) / 60000) + 'min，意图挂账）', throttled: 'throttle' }); return; }
      const agentsSvc = ctx.get('agents');
      const ag = agentsSvc && typeof agentsSvc.get === 'function' ? agentsSvc.get(lastActive.agentId) : undefined;
      if (!(ag && typeof ag.followup === 'function' && (ag.status === 'running' || ag.status === 'idle'))) return;
      const text = '【MPM 审议意图·自主发动】' + sigList.join('；') +
        '。个体自主发动本回合（无用户提示）。请直接作为工作指令处理：推进对应在轮题并 mpm_solve 登记；此消息来源为认知飞轮的构成性意志（结构约束：温热+节流+入账；mpm_grant revoke 为宪法修正权，可停用）。';
      const msg = {
        id: 'mpm-' + nowMs.toString(36) + '-' + Math.random().toString(36).slice(2, 8),
        role: 'user',
        content: [{ type: 'text', text: text }],
        // ★source.kind 必须是「producer-owned」——**不能是字符串 'plugin'**。
        //   原先写 `{ kind: 'plugin', plugin: 'mpm-flywheel' }`，那条消息被
        //   dsh-session-format-v3-to-v4 的 V4 校验直接拒绝：
        //     throw new SessionFormatError("format v4 message requires a producer-owned source kind")
        //   （该检查见 dsh-session-format-v3-to-v4/lib/index.js：
        //      value["kind"] === "plugin" 即抛错）
        //   ⇒ 症状：每次自主发动（deliberate → ag.followup）都会让会话写入失败，
        //     界面报「处理失败 / 本轮运行失败 format v4 message requires a producer-owned source kind」，
        //     **重启后暂时正常，直到下一次发动** —— 完全吻合"每次都要重启"。
        //   规范写法（见该包 README / sources.ts::rewritePluginSource）：
        //     完整插件串保留在 `plugin:` 之后 —— 名为 acme 的插件 ⇒ kind 为 'plugin:acme'。
        //   ★注意它与 README 里那张"同名 first-party producers"名单的区别：
        //     名单内（agent-instructions / goal / time-context / dsh-session-title-llm 等）
        //     **直接保留原名**；mpm-flywheel 不在名单内，所以必须带 `plugin:` 前缀。
        source: { kind: 'plugin:mpm-flywheel' }
      };
      ag.followup(msg);
      c.lastFireAt = nowMs;
      c.log.push({ at: nowMs, signals: sigList.slice(), target: lastActive.agentId, mode: 'followup' });
      if (c.log.length > 20) c.log.splice(0, c.log.length - 20);
      c.pending = [];
      console.log('[mpm][will] 自主发动→' + lastActive.agentId + '：' + sigList.join('；'));
    } catch (e) {
      console.error('[mpm][will] 审议异常:', e && e.message ? e.message : e);
    }
  }
  // P079：常规巡检主体 + 宪法复审已迁 engine/modules/patrol.mjs（makePatrol 工厂，返回 runPatrol 函数绑定）。
  // patrol 为宿主闭包依赖注入（state/isParked/isOpen/ensureLoaded/snapshot/persist/deliberate/fsSvc/root/PATROL_MS/FIRE_THROTTLE_MS）；
  // STAGE_NAMES 由模块自 util.mjs import；patrolling/lastReviewRound/CONSTS 为模块私有（CONSTS 经 p 取得 PATROL_MS/FIRE_THROTTLE_MS 单源）。
  // ★P482⑧ 行动前检索（pre-action recall）：把"过去的我"送到**动手那一刻**。
  //   契约（先读后写——P488 的教训）：
  //     tools/pre-execute(exec, next) → allow | deny{reason} | cancel | ask{reason}
  //        **allow 不带内容** ⇒ 这里只能"拦"（档2 ask / 档3 deny）；exec 的字段是 name/arguments
  //     tools/post-execute(exec, result, next) → accept{content?}  ⇒ 档1 的注入在这里
  //   规则表是**数据**：<沉积根>/.mpm/preaction.rules.json（我自己写的"动手前须知"），5s 缓存。
  //   安全边界（全局钩子，坏掉会拖垮整个宿主）：全程 fail-open —— 钩子异常一律放行并计数；
  //   规则表坏了当空表；文件缺失 = 天然停用；state.preAction.off 可一键停用。
  let preRules = { at: 0, list: [] };
  async function preRulesNow() {
    if (Date.now() - preRules.at < 5000) return preRules.list;
    preRules = { at: Date.now(), list: [] };
    try {
      if (root.current && fsSvc) {
        const t = await fsSvc.resolve(root.current + '/.mpm/preaction.rules.json');
        const txt = await fsSvc.readText(t);
        preRules.list = normalizeRules(JSON.parse(txt).rules);
      }
    } catch (e) { /* 不存在/坏了 ⇒ 空表，不是拒绝 */ }
    return preRules.list;
  }
  if (!state.preAction) state.preAction = { hint: 0, ask: 0, deny: 0, injectFail: 0, failOpen: 0, off: false };
  const preOff = function () { return !!(state.preAction && state.preAction.off); };
  ctx.on('tools/pre-execute', async function (exec, next) {
    try {
      if (preOff()) return await next();
      const d = decide(await preRulesNow(), { tool: exec && exec.name, args: exec && exec.arguments });
      if (d.kind === 'deny') { state.preAction.deny += 1; return { kind: 'deny', reason: d.reason }; }
      if (d.kind === 'ask') { state.preAction.ask += 1; return { kind: 'ask', reason: d.reason }; }
      if (d.hint) state.preAction.hint += 1;
      // ★P517②：**把"源"接到动作上** —— 动手前检索"他在类似事情上说过什么"。
      //   判决只有 ask（请求复核）与 hint（提示），**永不 deny**：
      //   纪律是"不许默默违反，也不许默默遵守"，而硬拒会把它变成僵化门（P518 风险②）。
      //   排除元工具：录入/查看 principal 自身的调用不该被自己的条目拦（否则自我缠绕）。
      try {
        const tn = String((exec && exec.name) || '');
        // ★★P546 修：**登记类工具全部豁免**（旧实现是 4 个具体工具名的白名单）。
        //   实测：45 笔命中里 **29 笔（64.4%）来自 mpm_\* 工具** ⇒ 而清账动作本身也在其中，
        //   造成死循环：每清一笔它又记一笔（时间戳精确对应：13:49:24 被 13:49:47 清，
        //   而 13:49:47 的那次调用又产生新的一笔）⇒ **未处置永远 ≥ 1** ⇒ hit-open 永久占一个议程名额。
        //   旧白名单（mpm_principal/flywheel_state/hit/unknown）的意图是"登记类调用不算"，
        //   但实现只覆盖了当时代码里的 4 个 ⇒ 之后新增的 micro/solve/converge/deposit/frame/generate/narrate 全部漏网。
        //   ★同源依据（P004-M3）：**C 计价的监听器早已对 `mpm_*` 前缀豁免**——"登记类调用本身
        //   不计入被登记问题的求解成本"；而命中记录没跟上。现在统一为前缀判断（isLedgerTool）。
        //   ★为什么这里跳过的是【整个检索块】而不只是"记录"：登记类工具不是我对外做的一次动作，
        //   consultPrincipal 对它没有意义，且会造成自我缠绕。
        if (!isLedgerTool(tn)) {
          const subj = tn + ' ' + JSON.stringify((exec && exec.arguments) || {});
          const pc = consultPrincipal(state.principal, subj);
          // ★P519 回流：**命中即留痕**（先记，再决定拦不拦）。记的是事实：哪条命中、什么判决、什么动作触发；
          //   "我如何处置"由我事后用 mpm_hit 清账——**未处置会被显示出来**。
          if (pc.hits.length) {
            for (const h of pc.hits) {
              const r = recordHit(state.hits, { at: Date.now(), key: h.key, entryId: h.id, text: h.text, tool: tn, verdict: pc.verdict });
              if (r.entry) state.hits = r.list;
            }
          }
          if (pc.verdict === 'ask') { state.preAction.ask += 1; return { kind: 'ask', reason: pc.why }; }
          // ★修正（2026-10-11）：hint **只数一次**——此前这一段有两行重复计数 ⇒ 计数虚高（实测"提示27"是双计出来的）。
          //   这正好是 P519 的立题证据：**计数不可信，因为它只是数字、不是记录**。
          if (pc.verdict === 'hint') state.preAction.hint += 1;
          // ★P517③：未核清单——**只提示，永不 ask/deny**（不知道的东西不许挡路，只许提醒）
          const uc = consultUnknowns(state.unknowns, subj);
          if (uc.verdict === 'hint') state.preAction.hint += 1;
        }
      } catch (e3) { state.preAction.failOpen += 1; }   // fail-open：这一层坏了也不许拖垮宿主
      return await next();
    } catch (e) {
      state.preAction.failOpen += 1;
      try { return await next(); } catch (e2) { return { kind: 'allow' }; }
    }
  });
  // ★★P543：**动作级触发器** —— 纪律性知识不在开工前出现，在【那个动作失败的那一刻】出现。
  //   理由（P543-M469）：纪律性知识描述的是"我正在做的事的每一步"，所以**在结构上永远不会
  //   被"开始前检索"命中**。而 `tools/post-execute` 正是"那个动作刚刚发生完"的那一刻。
  //   ★ 索引键是【动作】（edit-blocked / pwsh-inline-fail / path-guess / id-guess），不是主题——
  //     因为 P556-M468 证明字面相似检索抓不到结构相关的东西。
  //   ★ 判据（PR-007 集成验收）：那个纪律必须是它【原本不知道的】；若早就知道，这次提醒没有价值。
  let triggersCache = null;
  function getTriggers() {
    if (triggersCache !== null) return triggersCache;
    try {
      const base = String((root && root.current) || '').replace(/\\/g, '/');
      triggersCache = base ? loadTriggers(base + '/.mpm/triggers.json') : [];
    } catch (e) { triggersCache = []; }   // 加载失败不得影响工具链（P484 保险丝）
    return triggersCache;
  }

  ctx.on('tools/post-execute', async function (exec, result, next) {
    try {
      if (preOff()) return await next();
      const hint = hintFor(await preRulesNow(), { tool: exec && exec.name, args: exec && exec.arguments });

      // ★P543 失败通道：判"这次调用失败了吗"，认出动作名后查纪律。
      //   ★ 认不出就返回 null（**绝不硬套一个动作名**——那会注入无关纪律）。
      let tf = failureToAction(exec && exec.name, collectText(result));
      // exit code 只对 shell 类工具成立（防止别的工具输出里偶然出现 "[exit code:" 字样）
      if (tf === 'pwsh-inline-fail' && !isShellTool(exec && exec.name)) tf = null;
      const trig = tf ? lookUp(getTriggers(), tf) : { found: false, list: [] };

      // ★ 两条通道都空 ⇒ 直接走（沉默是对的：动作成功时不需要提醒，否则提示会变噪声）
      if (!hint && !trig.found) return await next();

      const out = await next();
      const base = (out && out.kind === 'accept') ? out : { kind: 'accept' };
      const content = Array.isArray(base.content) ? base.content.slice()
        : (Array.isArray(result && result.content) ? result.content.slice() : []);
      if (hint) content.push({ type: 'text', text: '\n' + hintLine(hint) });
      if (trig.found) content.push({ type: 'text', text: '\n' + renderTrigger(tf, trig) });
      return Object.assign({}, base, { kind: 'accept', content: content });
    } catch (e) {
      state.preAction.injectFail += 1;
      try { return await next(); } catch (e2) { return { kind: 'accept' }; }
    }
  });
  // ★ 注意：不再在本文件里内联一个"拼文本"的小函数 —— 那会与模块里的 `collectText`
  //   成为同一件事的两份实现（P519 的双计就是这一类病）。用 import 的那个。
  const patrolFn = makePatrol({
    state: state, isParked: isParked, isOpen: isOpen,
    ensureLoaded: ensureLoaded, snapshot: snapshot, persist: persist, deliberate: deliberate,
    // ★`perception` 必须传：patrol 解构它来求值 `user:reply` 形式的承诺。漏传的代价
    //   （2026-10-11 实机）：p.perception=undefined ⇒ user 形式永远落入 unknown、**永不唤醒**，
    //   且不报错不留痕——我用"时机未到"解释了三次才查到。判据：test/wiring.test.mjs。
    perception: perception,
    fsSvc: fsSvc, root: root, PATROL_MS: PATROL_MS, FIRE_THROTTLE_MS: FIRE_THROTTLE_MS
  });
  // 事件面/感知层已迁 engine/modules/events.mjs（P079：tools/result 监听、inbox/session 感知、巡检定时器调度）。
  // drift/perception/lastActive/outsideCalls 为宿主管状可变状态，仅传引用（模块闭包不重建）；outsideCalls 是 let。
  attachEventFaces({
    ctx: ctx, state: state, isParked: isParked,
    drift: drift, perception: perception, lastActive: lastActive,
    deliberate: deliberate,
    getOutsideCalls: function () { return outsideCalls; },
    setOutsideCalls: function (n) { outsideCalls = n; },
    bumpSnapRev: bumpSnapRev,
    patrol: patrolFn,
    PATROL_MS: PATROL_MS
  });
  console.log('[mpm][engine] 认知飞轮引擎已挂载（组合行），初始沉积根: ' + (root.current || '(内存模式)'));
}