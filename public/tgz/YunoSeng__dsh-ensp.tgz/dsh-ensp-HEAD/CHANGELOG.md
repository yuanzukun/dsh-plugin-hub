# Changelog

本项目的所有重要改动都记录在这里，格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [Unreleased]

## [0.3.2] - 2026-11-10

### Added

- **新增 `ensp_ref`（第 8 个工具）**：把题目 `.docx` / 课件 `.pptx` 一次转成工作区里的 `.txt`
  （按修改时间缓存），返回字符数、行数与开头预览；之后用检索工具查文本，不必反复解析 Office 文件。
- **命令速查补「8.5 双机热备（HRP + VRRP）」**：`hrp enable`、`hrp interface … remote`、
  `hrp track interface`、`hrp preempt delay`、`hrp mirror session enable`、`hrp priority`，
  VRRP 分组 active-standby 实现负载分担，以及 `display hrp state` / `display vrrp brief` /
  `display ospf peer brief` 三条验证命令与报错对照。

### Docs

- SKILL 新增「§0.4 参考文档可能本身就是错的」：小错（命令语法、视图、显示命令名）自行改用设备接受的写法
  并在交付里注明；大错（拓扑或地址规划矛盾、关键步骤缺失、策略方向相反）停下来告知用户。
  插件提示词与 MCP instructions 同步这一条。

## [0.3.1] - 2026-11-10

### Fixed

- **`ensp_cli` 的 `expect` 被写成嵌套数组时直接报参数错误**：现在接受 `expect: [["a","b"], "c"]`，
  数组内所有条件都要满足，不再浪费一轮。
- **`ensp_shot` 只给 `device` 不给 `target` 时报「needs device」**：现在自动按 `target:"device"` 处理，
  并对同一设备的相邻截图做重复帧检测（和 `ensp_capture` 一致）。

## [0.3.0] - 2026-11-09

### Added

- **`ensp_gui` 新增 `wait_ports`**：一次调用等到端口开放/关闭（`{"op":"wait_ports","ports":[2000],"timeout_ms":300000}`），
  返回等了多久、哪些端口已通，不必再用 `Start-Sleep` 盲等。
- **`ensp_gui` 新增 `free_ports`**：清掉仍占着控制台端口的残留进程（eNSP 退出后偶尔会留下僵尸监听），
  返回被杀掉的 pid 和仍占用端口。

### Fixed

- **`start_all` 全都没起来时自动重试**：第一次点启动后若没有任何端口开放，自动重新全选再点一次启动；
  仍然失败时提示用 `{"op":"kill"}` 重开拓扑。
- **`ensp_cli` 参数误用更早报错**：`device` 传了 `"FW,AR,SW"` 这种多设备串、或 `port` 传 0 时直接给出
  正确写法（`devices:[…]`），不再连到奇怪的端口上返回误导性回显。

## [0.2.9] - 2026-11-09

### Added

- **`ensp_capture` 支持 `expect`**：条目里给断言数组，工具先用 telnet 跑一遍核对，
  不过就不截图（返回 `skipped: true` 与缺失项），省掉「拍完再看一眼」的回合。
- **`ensp_doc` 自带结构校验**：生成后直接比对模板与成品的段数/非空段/图片数，返回 `verification`
  （`textUnchanged` 为 false 时说明纯截图版正文被改动）；不必再自己写脚本数。
- **`ensp_doc` 模板路径模糊匹配**：中文文件名多一个空格、全角括号也能匹配上，返回 `notes` 说明匹配结果。
- **`ensp_doc` 自动清理过程截图**：`clean_probe`（默认 true）删除成品图目录里 `_` 开头的调试图片。

## [0.2.8] - 2026-11-03

### Added

- **`ensp_cli` 新增 `passwords`**：一次传候选口令列表，工具按顺序自动重试登录并回报用到的那一个，
  省掉「猜一个、失败、再猜一个」的回合；仍然只接受题目/用户给出的口令，不生成变体。

### Fixed

- **截图冻住时不再闷头重拍**：`ensp_capture` 会比较同一设备的相邻截图，字节完全相同时提示
  「窗口可能没刷新」并在返回里给出 `duplicateOf`。

## [0.2.7] - 2026-11-03

### Added

- **新增 `ensp_capture`（第 7 个工具）**：一次调用完成「开设备窗口 → 激活 → 补回车唤醒 → 逐条打字 →
  等回显 → 重新激活 → 截图 → 关窗」的整套取证流程，清单式传入 `shots:[{device, commands, out}]`。
- **`ensp_cli` 新增 `expect`**：与 `commands` 等长的断言数组，未命中就在 `checks[]` 里标出，
  并给一个总的 `ok`；不用把整段回显读回来判断。

### Fixed

- **`ensp_capture` 反复弹同一个设备的窗口**：清单里同一设备出现多次时，中间那次不再关窗。
- **登录失败不知道口令该从哪来**：错误信息直接写明「只用题目或用户给的口令，不要猜变体」。

### Docs

- SKILL 新增「用 `expect` 让工具判对错」「批量取证 `ensp_capture`」两节；命令速查补口令表；
  插件提示词与 MCP server instructions 同步。

## [0.2.5] - 2026-11-03

### Added

- **`ensp_cli` 新增 `devices`**：一次调用配多台设备（`devices:[{device, commands, …}]`），内部并行跑，
  单台失败只在它那一项回 `error`，不影响其它设备。
- **`ensp_shot` 新增 `shots`**：一次调用截多张图，适合「一台设备一段回显 + 主窗口 + 全屏」这种成批取证。
- **SKILL 新增「效率铁律」**：工具只占几分钟，真正的成本是回合数——互不依赖的调用要并行发、
  多设备一次下发、截图成批、核对以文本为主、要问用户的事一次问完。
- **内置命令速查 `skills/ensp-automation/reference/commands.md`**：把 VRP 常用命令按机型固化
  （通用、交换 VLAN、ARP 安全、防火墙基础、安全策略、源 NAT/NAPT/Easy-IP、目的 NAT 与 NAT Server、
  双向 NAT、路由、验证命令），并附「报错 → 处理」对照表。
- **`ensp_cli` 新增 `output_file`**：完整回显同时写盘，返回值多一个 `transcript` 路径，
  用于对抗上层对超长工具结果的压缩。

### Fixed

- **控制台空闲超时导致窗口打字丢字符**：控制台闲置后提示
  `Configuration console time out, please press any key to log on`，第一个按键只用于唤醒。
  `open()` 现在会识别并补回车，`echo_to_window` 先激活窗口发一个空回车，逐字符间隔 0.02 s → 0.05 s。
- **设备窗口截图拿到旧画面**：窗口被遮挡或不在前台时窗口 DC 不重绘。截图前统一
  `RedrawWindow(+RDW_UPDATENOW)` + `UpdateWindow`，回显截图前再激活一次窗口。

### Docs

- SKILL 补：切换拓扑的可靠做法（`{"op":"open","path":…}`，`.topo` 不要当命令行参数传给 `eNSP_Client.exe`）、
  自绘保存对话框只能截图后真实点击、USG6000V 默认凭据、长回显被压缩时的三种对策、先 `display` 再下发、
  设备图标名与 VRP 主机名的区别、无人值守场景下的降级默认值，以及「重置拓扑目录不等于设备复位」
  「会话表查询有时间窗」两条坑。

## [0.2.4] - 2026-11-03

### Added

- **模板模式支持 `anchor: "#picN"`**：按「模板里第 N 张图所在的段落」定位，用于把实际拓扑图
  插在题目自带的参考拓扑图正下方——有些题目图后面直接接正文、没有 `图1 …` 图注，只能靠图片
  定位。有图注的继续用 `heading: "图1"`。

### Docs

- 交付规范补一条：**纯截图版第一个 section 永远是实际拓扑图**，插在题目参考拓扑图正下方，
  不加任何文字说明（成品顺序：题目拓扑图 → 图注 → 实际拓扑图 → 操作步骤）。
  `index.js` 提示词与 `mcp/instructions.js` 同步。

## [0.2.3] - 2026-10-29

### Added

- **`ensp_doc` 新增 `template_path`**：直接用老师发的原始题目 `.docx` 当「纯截图版」的底，
  原文、题号、排版一个字不动，把每个 section 的截图依次填进对应 `步骤N` 标题下面的空白段落
  （空白段落不够时按最后一个空段的格式新建，截图居中、宽度 13.5 cm）。
  - `section.heading` 写 `步骤3` 这种短标识即可自动匹配，也可以用 `anchor` 指定任意行首文字。
  - 找不到锚点会报错并列出缺哪些，不会悄悄生成一份空文档。
  - 这一步以前要临时写一段 python-docx 脚本（半小时起步），现在是一次工具调用的参数。

### Fixed

- **`save` 在 S5700 上卡在「请输入文件名」**：S5700 在 `[Y/N]` 之后还会问
  `Please input the file name ( *.cfg, *.zip ) [vrpcfg.zip]:`，旧逻辑等提示符等到超时、
  `saved.ok` 为 false。现在识别到这个提问就补一个回车（用默认的 `vrpcfg.zip`），保存后正常回
  `Save the configuration successfully.`。
- **`ensp_doc` 的截图相对路径失效**：python 子进程的工作目录不是 DSH 工作区，
  传 `工作区/截图/x.png` 会报 `missing image`。现在图片路径进 manifest 之前统一按工作区解析。
- **模板里的「空文本框」被当成非空行**：老师给的模板常用无图片的文本框当照片框，
  旧判定见 `w:drawing`/`w:pict` 就跳过，导致截图滑到下一个标题下面。现在只有真正带图片关系
  的段落才算已占用，图片会被放进文本框内部（宽度按框宽收一点，避免溢出）。

### Docs

- SKILL 交付清单补「纯截图版用 `template_path` 填原题文档」的做法。

## [0.2.2] - 2026-10-29

### Added

- **`ensp_cli` 新增 `new_password`**：USG6000V 用出厂口令首次登录时会强制改密
  （`The password needs to be changed. Change now? [Y/N]:`）。旧版要么把这个提示当成超时，
  要么在答 `N` 之后被设备踢回 `Login authentication`。现在传 `new_password`，工具会按
  `Y → 旧口令 → 新口令 → 确认新口令` 走完，登录后会话直接用新口令。

### Fixed

- **防火墙控制台登录判定失效**：`waitFor()` 返回文本后会把缓冲区清空，`loginIfNeeded()`
  再去读 `this.buffer` 就是空的，于是用户名/口令被当成普通命令打进 `Username:` 提示符。
  改为把 `waitFor()` 的返回文本传进登录流程。顺带处理 `Please Press ENTER.` 与
  「又出现一次 `Username:` = 口令错误」两种情况，错误信息也从超时变成
  `console authentication failed for user "admin" (wrong password?)`。
- **`save` 在 AR2220 上必然失败**：旧实现先发 `save`、等确认提示、再发 `y`；AR2220 已经把
  提示符弹回来了，这个 `y` 就成了 `Error: Unrecognized command found at '^' position.`，
  `saved.ok` 恒为 false。改成一次性写 `save\ny\n`（LF 换行，不夹 `\r`），
  S3700 / AR2220 / USG6000V 都会回 `Save the configuration successfully` /
  `Configuration file had been saved successfully`。

### Docs

- SKILL 错误目录补防火墙登录/改密、`save` 的 AR 时序两条记录，并注明
  **eNSP 只有「保存拓扑」（主窗口 Ctrl+S）才会把设备配置写回 `.topo` 目录**：
  只做设备 `save` 然后结束进程，重开拓扑仍会回到初始配置。

## [0.2.1] - 2026-10-29

### Fixed

- **`ensp_cli` 的 `echo_to_window` 从来不提交命令**：回显把每行结尾写成 `\r`，而桥的
  `type_text` 明确跳过 `\r`（只把 `\n` 映射成 VK_RETURN），于是命令被逐字打进设备窗口后
  一直躺在输入缓冲里，截图只有命令行、没有回显。改成 `\n` 后能正常执行并截到完整输出。
- 回显的默认停顿加大：`echo_gap_ms` 600 → 900，`echo_settle_ms` 1200 → 1800，避免长回显
  还没打印完就截图。

### Docs

- SKILL 错误目录补两条：首条命令超时且 partial output 只有 `##`（设备没就绪，加大
  `command_timeout_ms` 重试）、回显截图缺输出（旧版 `\r` 问题）。

## [0.2.0] - 2026-10-29

### Added

- **MCP 服务器**：同一套六个工具现在也能以 MCP（stdio）形式提供，供 Claude Desktop、
  Claude Code、Cursor、Trae、Cline 等客户端使用。
  - `mcp/server.js` 通过调用 `apply()` 注册工具，复用 DSH 插件用的同一批工具对象
    （同名、同 schema、同 handler），两边行为不会漂移。
  - `mcp/protocol.js` 手写 stdio JSON-RPC 传输，**插件保持零运行时依赖**。
  - `mcp/instructions.js` 把 SKILL.md 里的硬性规则搬成 MCP server instructions。
  - `bin/dsh-ensp-mcp.mjs` 命令行入口，支持 `--workspace`、`--no-restrict`、
    `--mode job|serve`、`--python`、`--version`、`--help`。
- `test/mcp-smoke.mjs` 离线冒烟测试（`npm test`）：协议握手与版本回落、JSON Schema
  映射与必填项、拓扑解析、工作区边界、未知工具/方法错误码，共 24 项断言，不需要
  eNSP、Python 或管理员权限。

### Changed

- `package.json` 增加 `bin`、`scripts.test`、`./mcp` 导出与 `mcp`/`bin`/`test` 文件项。

## [0.1.0] - 2026-10-27

### Added

- 首个可用版本：六个工具（`ensp_status`、`ensp_gui`、`ensp_shot`、`ensp_cli`、
  `ensp_topo`、`ensp_doc`）、`ensp-automation` 技能与系统提示注入。
- 提权 GUI 桥（`lib/bridge.py`，经 `ShellExecuteW("runas")` 启动），一整套界面动作
  只付一次进程启动成本；真实点击带 `expect` 归属校验，抢不到前台就拒绝输入。
- 设备窗口只走"双击画布图标"路径（外部 `ShowWindow` 会被 eNSP 撤销）；最小化的
  主窗口/控制台自动 `SW_RESTORE` 后操作（最小化窗口坐标是 -32000 废值）。
- `ensp_cli` 改配置后自动 `save`（自动应答 `[Y/N]`），返回 `saved.ok`。
- `start_all` / `stop_all` 点完工具栏后轮询控制台端口，不用猜启动耗时。

[Unreleased]: https://github.com/YunoSeng/dsh-ensp/compare/v0.3.2...HEAD
[0.3.2]: https://github.com/YunoSeng/dsh-ensp/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/YunoSeng/dsh-ensp/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.9...v0.3.0
[0.2.9]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.8...v0.2.9
[0.2.8]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.7...v0.2.8
[0.2.7]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.6...v0.2.7
[0.2.6]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.5...v0.2.6
[0.2.5]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.4...v0.2.5
[0.2.4]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.3...v0.2.4
[0.2.3]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/YunoSeng/dsh-ensp/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/YunoSeng/dsh-ensp/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/YunoSeng/dsh-ensp/releases/tag/v0.1.0
