/**
 * 宿主词典运行时 patch：开关开时把宿主 model 命名空间 zh 词典里的
 * `effort.providerDefault` 词条从 'Default' 改成 '默认'。
 *
 * 为什么这样做：Default 是宿主 ModelSelect.tsx 自己合成的伪菜单项（L127/L133），
 * 它取的是浏览器半 locale 服务的 `t('effort.providerDefault')` 词条，不是数据层——
 * Node 半遮蔽 `resolveModelInfo` 碰不到这里。而宿主 LocaleRuntime 的 `register` 禁止同
 * ns+locale 重复注册，故只能直接 mutate 已注册的词典对象里的词条值，然后手动调 publish
 * bump revision 让 localeSeat 缓存失效、t 函数换新引用、已挂载的 outlet 重渲染。
 *
 * 卸载时恢复原状、再 publish 一次；宿主自身的 register disposer 仍会调一次 publish，
 * 那次是幂等的（revision 再涨一次、词条值已是原始值），不冲突。
 */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
// ctx.locale 服务面（LocaleRuntime）——这里故意不 import 它的类型，避免触发 private 守卫
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { Flags } from '@/client/model'
import type { DecodedScope } from '@/client/scope'

/** 宿主内部结构的 hack 接口：只列我们实际要碰的属性，其余假装不存在 */
interface LocaleRuntimeHack {
    /** ns → locale(lower) → 词典对象（plain object） */
    dicts: Map<string, Map<string, Record<string, string>>>
    /** 手动 bump revision 通知 outlets 重渲染 */
    publish(active: string, localeChanged: boolean, locales?: readonly unknown[]): void
    /** 当前快照：publish 需要 active 和 locales */
    snapshot: { active: string; locales: readonly unknown[] }
}

const MODEL_NS = 'model'
const TARGET_KEY = 'effort.providerDefault'
/** LocaleRuntime.localeKey() 是 toLowerCase，直接用小写 'zh' */
const ZH_LOWER = 'zh'

/** 宿主 locales.ts 里 zh 词典的原始值（和 en 一样写的 'Default'） */
const ORIGINAL = 'Default'
const LOCALIZED = '默认'

/**
 * 设置 zh 词典里目标词条的值；值未变时跳过 publish（revision 保持不变，已挂载的 outlet
 * 不需要重渲染——词条值没变嘛）。
 */
function patchZhDict(runtime: LocaleRuntimeHack, localized: boolean): void {
    const zhDict = runtime.dicts.get(MODEL_NS)?.get(ZH_LOWER)
    // model NS 必然已在宿主 boot 期注册；缺席（理论不可能）静默跳过，不抛错、不 publish
    if (zhDict === undefined) return
    const value = localized ? LOCALIZED : ORIGINAL
    if (zhDict[TARGET_KEY] === value) return
    zhDict[TARGET_KEY] = value
    runtime.publish(runtime.snapshot.active, false, runtime.snapshot.locales)
}

/**
 * 挂上词典 patch 逻辑：启动时按开关状态设置一次，scope 变化（用户切开关）时重新 patch，
 * fiber 卸载时恢复原状。
 *
 * @param ctx - 父 fiber 的 ctx
 * @param scope - 本插件命名空间的 decode 后段视图（读 localizeEfforts 开关）
 */
export function applyLocalePatch(ctx: ClientContext, scope: DecodedScope<Flags>): void {
    const runtime = ctx.locale as unknown as LocaleRuntimeHack

    const patch = (): void => {
        const flags = scope.getSnapshot().value
        const localized = flags?.userExperience.localizeEfforts ?? false
        patchZhDict(runtime, localized)
    }

    patch()
    const scopeUnsub = scope.subscribe(patch)

    ctx.effect(() => () => {
        scopeUnsub()
        const zhDict = runtime.dicts.get(MODEL_NS)?.get(ZH_LOWER)
        if (zhDict !== undefined && zhDict[TARGET_KEY] === LOCALIZED) {
            zhDict[TARGET_KEY] = ORIGINAL
            runtime.publish(runtime.snapshot.active, false, runtime.snapshot.locales)
        }
    })
}
