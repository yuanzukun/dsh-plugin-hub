/** 浏览器半纯映射层：`tikaflow-model-fix` 版本快照段 <-> 卡片配置（五组布尔 + excludes 列表）。跨半共享的常量、类型、解析函数单一来源在 `src/shared/`；本文件只保留 UI 层：组的行键表与渲染顺序、快照↔配置的 UI 派生、验证与探测候选的拍取与目标收敛。 */

import type { PluginConfig } from '@/shared/types'
import { isPlainObject, providersOf } from '@/shared/types'
import { EFFORT_LEVELS } from '@/shared/constants'
import { CONFIG_VERSION, DEFAULT_CONFIG, FIELD_KEYS, COMPAT_KEYS, USER_EXPERIENCE_KEYS, BEHAVIOR_KEYS, parseSnapshot, versionKey } from '@/shared/config-schema'

export const VERSION_KEY = versionKey(CONFIG_VERSION)

export type Group = 'autoFill' | 'allowUpdate' | 'compat' | 'behavior' | 'userExperience'

export const GROUP_KEYS: Record<Group, readonly RowKey[]> = {
    autoFill: FIELD_KEYS,
    allowUpdate: FIELD_KEYS,
    compat: COMPAT_KEYS,
    behavior: BEHAVIOR_KEYS,
    userExperience: USER_EXPERIENCE_KEYS,
}

/** 瓦片顺序（含动态集合瓦片「排除提供方」）：自动填充 / 允许更新 / 兼容性 / 排除提供方 / 用户体验 / UI 与行为 */
export const TILE_ORDER: readonly (Group | 'excludes')[] = ['autoFill', 'allowUpdate', 'compat', 'excludes', 'userExperience', 'behavior']

/** 全部布尔配置组：脏检测遍历用，由 TILE_ORDER 派生（去掉动态集合瓦片），顺序无关紧要 */
const GROUPS: readonly Group[] = TILE_ORDER.filter((tile): tile is Group => tile !== 'excludes')

/** 组内行键全集（词典键映射与各组行表的类型） */
export type RowKey =
    | (typeof FIELD_KEYS)[number]
    | (typeof COMPAT_KEYS)[number]
    | (typeof BEHAVIOR_KEYS)[number]
    | (typeof USER_EXPERIENCE_KEYS)[number]

/** 卡片侧消费的完整当前配置（与 PluginConfig 同形：五组布尔 + excludes + efforts） */
export type Flags = PluginConfig

/** 解码命名空间整段：只读当前版本快照（键见 `VERSION_KEY`）；段非法、快照缺失或非法均回退默认。永不返回 undefined（返回 undefined 会让宿主 scope 永挂 loading） */
export function decodeSection(section: unknown): Flags {
    return isPlainObject(section) ? parseSnapshot(section[VERSION_KEY]) ?? DEFAULT_CONFIG : DEFAULT_CONFIG
}

/** 组内布尔对象的视图：组的值类型是 union，类型收窄只在此处发生一次 */
function rowsOf(flags: Flags, group: Group): Record<string, boolean> {
    return flags[group] as unknown as Record<string, boolean>
}

export function groupValue(flags: Flags, group: Group, key: RowKey): boolean {
    return rowsOf(flags, group)[key] === true
}

/** 跟随**实际生效**的判据：插件开关开着且宿主「允许 Agent 为子智能体选择模型」那段设置未开启（宿主那段开启时路由由模型自挑，跟随会推翻其合法选择）。
 * `hostEnabled` 由浏览器半读宿主 `subagent-model-selection-settings` 段得出；段读不到记 `undefined`＝视为未开启（与 Node 半 `subagent.ts` 的 try/catch 口径一致） */
export function followingActive(flags: Flags, hostEnabled: boolean | undefined): boolean {
    return groupValue(flags, 'userExperience', 'followParent') && !hostEnabled
}

/** 组总控的当前显示值：组内全为开才显示开，部分选中显示关，点击即整组补全为开（口径见 docs/decisions.md「宿主与卡片」） */
export function masterValue(flags: Flags, group: Group): boolean {
    return GROUP_KEYS[group].every((key) => groupValue(flags, group, key))
}

/** 整组同置：把 group 的全部行设为 value，返回新对象（不改入参） */
export function applyGroup(flags: Flags, group: Group, value: boolean): Flags {
    const rows: Record<string, boolean> = {}
    for (const key of GROUP_KEYS[group]) rows[key] = value
    return { ...flags, [group]: rows } as Flags
}

/** 单格取反：把 group.key 翻转，返回新对象（不改入参） */
export function toggleCell(flags: Flags, group: Group, key: RowKey): Flags {
    const rows = { ...rowsOf(flags, group) }
    rows[key] = !rows[key]
    return { ...flags, [group]: rows } as Flags
}

/** 排除列表逐项比较（顺序敏感）：草稿只由已存值经增删派生，顺序不会自行漂移；插入顺序是用户意图的一部分 */
function sameIdList(a: readonly string[], b: readonly string[]): boolean {
    if (a.length !== b.length) return false
    return a.every((id, index) => id === b[index])
}

/** 布尔组 + 排除列表逐项比较，判断草稿相对已存配置是否有改动（`efforts` 是运行时记忆，不参与比较） */
export function isDirty(draft: Flags, saved: Flags): boolean {
    for (const group of GROUPS) {
        for (const key of GROUP_KEYS[group]) {
            if (groupValue(draft, group, key) !== groupValue(saved, group, key)) return true
        }
    }
    return !sameIdList(draft.excludes, saved.excludes)
}

/** 从 `llm-pi-ai` 的 user 层取提供方 id（与 Node 半 fix 遍历的 `descriptor.user.providers` 同一事实源，故「命中」判定与本插件真实会跳过的集合零漂移）；非纯对象、无 providers 一律视为空 */
export function providerIdsOf(user: unknown): string[] {
    return Object.keys(providersOf(user) ?? {})
}

/** 命中的排除项集合：既决定标签的命中高亮，其 size 即 summary 徽标的命中数 */
export function resolveHits(excludes: readonly string[], providerIds: readonly string[]): ReadonlySet<string> {
    const live = new Set(providerIds)
    return new Set(excludes.filter((id) => live.has(id)))
}

/** 新增排除项：已存在则原样返回（调用方先行拦截重复，此处只保证幂等）；不改入参 */
export function addExclude(flags: Flags, id: string): Flags {
    if (flags.excludes.includes(id)) return flags
    return { ...flags, excludes: [...flags.excludes, id] }
}

/** 删除排除项：不存在的 id 原样返回；不改入参 */
export function removeExclude(flags: Flags, id: string): Flags {
    const index = flags.excludes.indexOf(id)
    if (index < 0) return flags
    const excludes = [...flags.excludes]
    excludes.splice(index, 1)
    return { ...flags, excludes }
}

/** 排除项 id 的合法性规则：逐字复制宿主 models 页新增提供方时的 route id 校验（同一权威规则，两侧不得自行放宽） */
export const EXCLUDE_ID_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/

/** 一个待验证的「提供方 / 模型」：附带该模型在配置里声明的推理级别（`reasoningEfforts` 的键，按 `EFFORT_LEVELS` 由低到高排序去重；无该字段即 `[]`，表示不带档位探测） */
export interface VerifyCandidate {
    provider: string
    model: string
    efforts: string[]
}

/** 选择键：模型 id 可含 '/'，故取二元组序列化而非字符串拼接（同一口径与 Node 半 `src/probe-report.ts` 的去重键一致） */
export function verifyKey(provider: string, model: string): string {
    return JSON.stringify([provider, model])
}

/** 候选遍历的唯一实现（验证与探测共用）：保持录入顺序；提供方非对象、无 models 数组、模型无 id 的行一律跳过 */
function candidatesOf(user: unknown, keep: (provider: string, candidate: VerifyCandidate) => boolean): VerifyCandidate[] {
    const candidates: VerifyCandidate[] = []
    for (const [provider, entry] of Object.entries(providersOf(user) ?? {})) {
        if (!isPlainObject(entry) || !Array.isArray(entry.models)) continue
        for (const model of entry.models) {
            if (!isPlainObject(model) || typeof model.id !== 'string' || model.id === '') continue
            const declared = isPlainObject(model.reasoningEfforts) ? model.reasoningEfforts : undefined
            // 档位取配置里的键（即模型页送出、宿主校验的那个 id），并按规范次序归一
            const efforts = declared === undefined ? [] : EFFORT_LEVELS.filter((level) => Object.hasOwn(declared, level))
            const candidate: VerifyCandidate = { provider, model: model.id, efforts: [...efforts] }
            if (keep(provider, candidate)) candidates.push(candidate)
        }
    }
    return candidates
}

/** 从 `llm-pi-ai` 的 user 层拍全量候选清单，验证与探测共用 */
export function verifyCandidatesOf(user: unknown): VerifyCandidate[] {
    return candidatesOf(user, () => true)
}

/** 「未填充」判据：无档位声明，或只声明了 `off` */
export function isUnfilled(efforts: readonly string[]): boolean {
    return efforts.length === 0 || efforts.every((effort) => effort === 'off')
}

/** 探测档位的请求计划：每个模型按 `EFFORT_LEVELS` 由低到高各试一档；off 仅当模型已声明时才探测 */
export function probeTargetsOf(candidates: readonly VerifyCandidate[]): VerifyTarget[] {
    return candidates.map((candidate) => ({
        provider: candidate.provider,
        model: candidate.model,
        efforts: EFFORT_LEVELS.filter((level) => level !== 'off' || candidate.efforts.includes('off')),
    }))
}

/** 一次诊断的请求计划里的一条：一个待跑的「提供方 / 模型」。验证只验模型本身（一条不带 `reasoningEffort` 的请求，`efforts` 缺省）；探测档位才带上「这轮要试的档位」逐档展开 */
export interface VerifyTarget {
    provider: string
    model: string
    /** 本轮要逐档试的档位（仅探测档位携带）：缺省即一次不带档位参数的请求 */
    efforts?: string[]
}

/** 从勾选的候选算出验证的请求计划：每模型一条不带 `reasoningEffort` 的请求。不带参数验的是用户实际会走的那条路径——端点可能有自己的默认推理级别，发 `off` 验出来的结论与默认路径未必一致 */
export function verifyTargets(
    candidates: readonly VerifyCandidate[],
    keys: ReadonlySet<string>,
): VerifyTarget[] {
    return candidates
        .filter((candidate) => keys.has(verifyKey(candidate.provider, candidate.model)))
        .map((candidate) => ({ provider: candidate.provider, model: candidate.model }))
}

/** 该组是否已全选：部分选中时仍显示「全选」，全选中才翻成「取消全选」，与官方 `allVisibleCandidatesPicked` 同语义。按钮文案与点击方向必须共用本函数（判据不同步即出现「文案显示取消全选、点击却是全选」） */
export function groupAllPicked(picked: ReadonlySet<string>, models: readonly VerifyCandidate[]): boolean {
    return models.every((candidate) => picked.has(verifyKey(candidate.provider, candidate.model)))
}

/** 分组「全选 / 取消全选」：已全选则整组移出，否则整组加入。返回新集合（不改入参、只动本组的键） */
export function toggleGroupPicks(picked: ReadonlySet<string>, models: readonly VerifyCandidate[]): ReadonlySet<string> {
    const next = new Set(picked)
    const remove = groupAllPicked(next, models)
    for (const candidate of models) {
        const key = verifyKey(candidate.provider, candidate.model)
        if (remove) next.delete(key)
        else next.add(key)
    }
    return next
}
