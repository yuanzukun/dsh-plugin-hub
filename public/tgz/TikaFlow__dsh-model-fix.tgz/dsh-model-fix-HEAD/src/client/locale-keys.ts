/** 卡片文案的键契约（浏览器半）：命名空间、键名联合、宿主 ui-slots 的类型表并入，以及「配置项 → 文案键」的四张映射。
 * 这里只管「有哪些键、配置项对上哪个键」，键各自说了什么见 locale-zh.ts 与 locale-en.ts。四张映射按用途分：同一轴上「标题」与「释义」本是两句话，故行名与行内释义、组标题与组释义各成一张 */

import type {} from '@deepseek-ai/dsh-client-ui-slots'
import type { Group, RowKey } from '@/client/model'

export const CARD_NS = 'settings.modelFix'

export type CardKey =
    | 'title'
    | 'tabLabel'
    | 'description'
    | 'colAutoFill'
    | 'colAllowUpdate'
    | 'colCompat'
    | 'colExcludes'
    | 'colUserExperience'
    | 'masterAll'
    | 'hintAutoFill'
    | 'hintAllowUpdate'
    | 'hintCompat'
    | 'hintExcludes'
    | 'hintUserExperience'
    | 'rowReasoning'
    | 'rowContext'
    | 'rowImage'
    | 'rowDisableDeveloper'
    | 'rowDisableStore'
    | 'rowRememberEfforts'
    | 'rowDefaultHigh'
    | 'rowForgetRemoved'
    | 'rowFollowParent'
    | 'rowSelfTuneEffort'
    | 'rowLocalizeEfforts'
    | 'rowShowOriginalEfforts'
    | 'rowLooseMatch'
    | 'rowSafeFill'
    | 'rowAlwaysReasoning'
    | 'tipReasoning'
    | 'tipContext'
    | 'tipImage'
    | 'tipDisableDeveloper'
    | 'tipDisableStore'
    | 'tipRememberEfforts'
    | 'tipDefaultHigh'
    | 'tipForgetRemoved'
    | 'tipFollowParent'
    | 'tipSelfTuneEffort'
    | 'tipLocalizeEfforts'
    | 'tipShowOriginalEfforts'
    | 'tipLooseMatch'
    | 'tipSafeFill'
    | 'tipAlwaysReasoning'
    | 'excludePlaceholder'
    | 'excludeAdd'
    | 'excludeInvalid'
    | 'excludeDuplicate'
    | 'excludeHits'
    | 'excludeHit'
    | 'excludeUnmatched'
    | 'excludeRemove'
    | 'save'
    | 'saving'
    | 'saveDone'
    | 'cancel'
    | 'unsaved'
    | 'expand'
    | 'collapse'
    | 'force'
    | 'forceBusy'
    | 'forceConfirm'
    | 'forceGo'
    | 'close'
    | 'forceDone'
    | 'forceNone'
    | 'forceFailed'
    | 'restore'
    | 'restoreBusy'
    | 'restoreConfirm'
    | 'restoreGo'
    | 'restoreDone'
    | 'restoreFailed'
    | 'writebackTimeout'
    | 'verify'
    | 'verifyTitle'
    | 'verifyDesc'
    | 'verifyTabModels'
    | 'verifyTabRecords'
    | 'verifyQuota'
    | 'verifyGo'
    | 'verifyStop'
    | 'verifySelectAll'
    | 'verifyDeselectAll'
    | 'verifyEmpty'
    | 'recordsEmpty'
    | 'verifyCommand'
    | 'verifyLine'
    | 'verifyLinePlain'
    | 'verifyLineProvider'
    | 'verifySkipped'
    | 'verifyOutUsable'
    | 'verifyOutUnsupported'
    | 'verifyOutUnreachable'
    | 'verifyOutQuota'
    | 'verifyOutCredential'
    | 'verifyOutRateLimit'
    | 'verifyOutTimeout'
    | 'verifyOutAborted'
    | 'verifyOutOther'
    | 'verifyStopped'
    | 'verifyStoppedLine'
    | 'verifyDoneModels'
    | 'verifyFailed'
    | 'verifyFinished'
    // 探测档位：与验证弹层共用外壳与行模板（复用 verifyOut* / verifySkipped / verifyStopped / 全选文案），只有标题、开关、快捷勾选键与收尾几行是它自己的说法
    | 'probe'
    | 'probeTitle'
    | 'probeTabRecords'
    | 'probeDesc'
    | 'probeQuota'
    | 'probeAutoWrite'
    | 'probeAutoWriteTip'
    | 'probeDropUnsupported'
    | 'probeDropUnsupportedTip'
    | 'probeSelectUnfilled'
    | 'probeDeselectUnfilled'
    | 'probeGo'
    | 'probeStop'
    | 'probeCommand'
    | 'probeDone'
    | 'probeFilled'
    | 'probeFillSkipped'
    | 'probeFillFailed'
    | 'probeStoppedLine'
    // 宿主 TerminalBlock 的展示文案：键名与官方安装页 terminalLabels(t) 的映射对齐（`DSH/packages/client/ui-plugin-manager/…/locales.ts`）
    | 'terminalCommandLine'
    | 'terminalSignal'
    | 'terminalExitCode'
    | 'terminalNoExitCode'
    | 'terminalRunning'
    | 'terminalFailed'
    | 'terminalDone'
    | 'terminalCopy'
    | 'terminalCopied'
    | 'terminalNoOutput'
    | 'clearEffortsTitle'
    | 'clearEffortsConfirm'
    | 'clearEffortsKeep'
    | 'clearEffortsGo'
    | 'clearEffortsDone'
    | 'clearEffortsFailed'
    | 'loading'
    | 'unavailable'
    | 'readOnly'
    | 'star'
    | 'feedback'
    | 'issueBody'
    // 输入框工具行的两枚 chip：常驻入口 + 跟随状态灯（亮绿＝实际生效中、灰＝未生效）
    | 'chipModelOpt'
    | 'chipFollowOn'
    | 'chipFollowOnTitle'
    | 'chipFollowOff'
    | 'chipFollowOffTitle'
    | 'chipFollowFail'
    // 「UI 与行为」组：七个可见性开关 + 一条恒定展示行（插件管理，不绑配置、不可关闭）
    | 'colBehavior'
    | 'hintBehavior'
    | 'rowShowInModels'
    | 'rowShowInBuiltinPlugins'
    | 'rowShowInComposer'
    | 'rowShowFollowStatus'
    | 'rowShowInPluginManager'
    | 'rowBackToChat'
    | 'rowShowInFloat'
    | 'rowClassicSetting'
    | 'tipShowInModels'
    | 'tipShowInBuiltinPlugins'
    | 'tipShowInComposer'
    | 'tipShowFollowStatus'
    | 'tipShowInPluginManager'
    | 'tipBackToChat'
    | 'tipShowInFloat'
    | 'tipClassicSetting'
    // 模型优化设置卡片：输入框 chip 与悬浮按钮共用同一句提示
    | 'tipOpenSettingCard'
    // 「返回对话」悬浮按钮自身的文案
    | 'backToChat'
    // 「返回对话」按钮跟随当前会话状态的提示
    | 'backToChatRunning'
    | 'backToChatSubagentsOne'
    | 'backToChatSubagentsOther'
    | 'backToChatWaitingApproval'
    | 'backToChatPlanReview'
    | 'backToChatWaitingAnswer'
    | 'backToChatCompleted'
    // 经典设置按钮自身的文案
    | 'classicSettingLabel'

declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.modelFix': CardKey
    }
}

/** 组内行键的展示文案映射（组件按 GROUP_KEYS 取键） */
export const ROW_KEYS: Record<RowKey, CardKey> = {
    reasoning: 'rowReasoning',
    context: 'rowContext',
    image: 'rowImage',
    disableDeveloper: 'rowDisableDeveloper',
    disableStore: 'rowDisableStore',
    rememberEfforts: 'rowRememberEfforts',
    defaultHigh: 'rowDefaultHigh',
    forgetRemoved: 'rowForgetRemoved',
    followParent: 'rowFollowParent',
    showInModels: 'rowShowInModels',
    showInBuiltinPlugins: 'rowShowInBuiltinPlugins',
    showInComposer: 'rowShowInComposer',
    showFollowStatus: 'rowShowFollowStatus',
    backToChat: 'rowBackToChat',
    showInFloat: 'rowShowInFloat',
    classicSetting: 'rowClassicSetting',
    selfTune: 'rowSelfTuneEffort',
    localizeEfforts: 'rowLocalizeEfforts',
    showOriginalEfforts: 'rowShowOriginalEfforts',
    looseMatch: 'rowLooseMatch',
    safeFill: 'rowSafeFill',
    alwaysReasoning: 'rowAlwaysReasoning',
}

/** 配置组（瓦片）标题键映射 */
export const COLUMN_KEYS: Record<Group, CardKey> = {
    autoFill: 'colAutoFill',
    allowUpdate: 'colAllowUpdate',
    compat: 'colCompat',
    behavior: 'colBehavior',
    userExperience: 'colUserExperience',
}

/** 配置组释义键映射（瓦片展开体首行） */
export const HINT_KEYS: Record<Group, CardKey> = {
    autoFill: 'hintAutoFill',
    allowUpdate: 'hintAllowUpdate',
    compat: 'hintCompat',
    behavior: 'hintBehavior',
    userExperience: 'hintUserExperience',
}

/** 行内设置项的 tooltip 释义键映射（瓦片展开体每行的帮助气泡） */
export const TIP_KEYS: Record<RowKey, CardKey> = {
    reasoning: 'tipReasoning',
    context: 'tipContext',
    image: 'tipImage',
    disableDeveloper: 'tipDisableDeveloper',
    disableStore: 'tipDisableStore',
    rememberEfforts: 'tipRememberEfforts',
    defaultHigh: 'tipDefaultHigh',
    forgetRemoved: 'tipForgetRemoved',
    followParent: 'tipFollowParent',
    showInModels: 'tipShowInModels',
    showInBuiltinPlugins: 'tipShowInBuiltinPlugins',
    showInComposer: 'tipShowInComposer',
    showFollowStatus: 'tipShowFollowStatus',
    backToChat: 'tipBackToChat',
    showInFloat: 'tipShowInFloat',
    classicSetting: 'tipClassicSetting',
    selfTune: 'tipSelfTuneEffort',
    localizeEfforts: 'tipLocalizeEfforts',
    showOriginalEfforts: 'tipShowOriginalEfforts',
    looseMatch: 'tipLooseMatch',
    safeFill: 'tipSafeFill',
    alwaysReasoning: 'tipAlwaysReasoning',
}
