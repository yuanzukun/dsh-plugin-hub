/** 验证与探测记录区的纯文案层：TerminalBlock 展示文案、结论→文案键对照、记录行合成；零状态、零 React。 */

import type { TerminalBlockLabels } from '@deepseek-ai/dsh-client-ui-primitives'
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
import type { CardKey } from '@/client/locale-keys'
import { isProviderBlocking } from '@/shared/verify-progress'
import type { ProbeOutcome, VerifyProbedFrame } from '@/shared/verify-progress'

/** 宿主 TerminalBlock 展示文案（该包无语言回退，经 t() 提供）；`commandLine` 是 devDep 未跟上的新增必填字段（见 docs/host/「契约漂移点」） */
type TerminalLabels = TerminalBlockLabels & { commandLine: (line: number) => string }

export function terminalLabelsOf(t: TranslateNS<'settings.modelFix'>): TerminalLabels {
    return {
        commandLine: (n) => t('terminalCommandLine', { n: String(n) }),
        signal: (signal) => t('terminalSignal', { signal }),
        exitCode: (code) => t('terminalExitCode', { code: String(code) }),
        noExitCode: t('terminalNoExitCode'),
        running: t('terminalRunning'),
        failed: t('terminalFailed'),
        done: t('terminalDone'),
        copy: t('terminalCopy'),
        copied: t('terminalCopied'),
        noOutput: t('terminalNoOutput'),
        collapseAria: '',
        collapse: '',
        expandAria: () => '',
        expand: () => '',
    }
}

/** 探测结论→文案键对照；aborted 只占类型位（中止不入账） */
const OUTCOME_KEYS: Record<ProbeOutcome, CardKey> = {
    usable: 'verifyOutUsable',
    'unsupported-effort': 'verifyOutUnsupported',
    unreachable: 'verifyOutUnreachable',
    quota: 'verifyOutQuota',
    credential: 'verifyOutCredential',
    'rate-limit': 'verifyOutRateLimit',
    timeout: 'verifyOutTimeout',
    aborted: 'verifyOutAborted',
    other: 'verifyOutOther',
}

/** 一条探测结论记录行；provider 级失败不带模型与档位，带 skipped 时补剩余条数 */
export function verifyLineOf(frame: VerifyProbedFrame, t: TranslateNS<'settings.modelFix'>): string {
    const result = t(OUTCOME_KEYS[frame.outcome])
    const line = isProviderBlocking(frame.outcome)
        ? t('verifyLineProvider', { provider: frame.provider, result })
        : frame.effort === undefined
            ? t('verifyLinePlain', { provider: frame.provider, model: frame.model, result })
            : t('verifyLine', { provider: frame.provider, model: frame.model, effort: frame.effort, result })
    return frame.skipped === undefined ? line : `${line}${t('verifySkipped', { count: String(frame.skipped) })}`
}
