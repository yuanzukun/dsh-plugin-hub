/**
 * 跨半共享的纯常量（零 Node 依赖、零 schemastery、零非基线 `@deepseek-ai/*`）。
 * 两半均**直连**本层（统一经 `@/shared/constants` 别名导入），不经任何 facade 中转；
 * Node 专属常量（含 `node:path` 的 `CACHE_FILE`、拉取参数等）仍留 `src/constants.ts`。
 *
 * 本文件是浏览器半能安全值导入的唯一跨半来源（`eslint.config.ts` 的 client 纯度门禁在 @/ 值导入里只放行 `@/shared`）。
 * 往本文件加任何 `node:`、`schemastery` 或非基线 `@deepseek-ai/*` 的值导入都会破坏浏览器半产物——勿加。
 */

/** 模型配置读写目标命名空间（harness 的 llm-pi-ai）：小写连字符字面量，由 settings 服务在注册/读写时校验 */
export const API_NS = 'llm-pi-ai'
/** 自有配置命名空间（带发布者前缀，避免与其他插件抢占通用名字；fix 即填充/修复），由插件导出的 Config schema 注册（src/index.ts） */
export const PLUGIN_NS = 'tikaflow-model-fix'

/** 插件名（= npm 包名）：Node 半日志前缀与 User-Agent、浏览器半 `export const name` 与样式标签 HMR 标记共用 */
export const PLUGIN_NAME = 'dsh-model-fix'

/**
 * 验证进度流的路由：Node 半经 `connection.fetch` 注册的 exact 路径（宿主要求落在 `/api` 之下）。
 * 浏览器半用 `VERIFY_STREAM_URL` 那一份——宿主约定浏览器一律走文档相对路由，服务端 key 保持绝对。
 */
export const VERIFY_STREAM_ROUTE = `/api/${PLUGIN_NS}/verify`
/** 同一路由的文档相对形式（去掉前导斜杠），供浏览器半 `fetch` 直接使用 */
export const VERIFY_STREAM_URL = VERIFY_STREAM_ROUTE.slice(1)

/**
 * 「探测式填充」进度流的路由：与验证流同型（同一 exact 注册面、同样的 `buffered` 请求体、同样的 SSE 回包），
 * 只是执行器与用途不同——逐档试出哪些推理级别真能用，随后写回补全。
 */
export const PROBE_STREAM_ROUTE = `/api/${PLUGIN_NS}/probe`
/** 同一路由的文档相对形式（去掉前导斜杠），供浏览器半 `fetch` 直接使用 */
export const PROBE_STREAM_URL = PROBE_STREAM_ROUTE.slice(1)

/** 推理级别取值，与 harness 的 ModelThinkingLevel 一致（由低到高：浏览器半取「最低档位」即取首个命中项） */
export const EFFORT_LEVELS = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const

/** 当前代码支持的配置版本（新 NS 内的快照版本）；配置 schema 变化时递增，并在 upgrade.ts 中追加升级步骤 */
export const CONFIG_VERSION = 8

/** 版本快照键前缀，段内键形如 version-N */
export const VERSION_PREFIX = 'version-'
