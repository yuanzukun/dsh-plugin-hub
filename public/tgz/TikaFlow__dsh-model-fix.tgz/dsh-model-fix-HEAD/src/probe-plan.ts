import { LEVELS } from '@/constants'
import type { VerifyProbe } from '@/shared/verify-progress'
import { isPlainObject } from '@/shared/types'

/** 探测计划层（纯函数、零 ctx）：把浏览器半发来的未信任载荷校验并展开为待跑清单；两条硬闸配额见 `ProbeLimits` */

/** 一个提供方的探测组：组内顺序执行即「每 provider 单并发」的结构保证 */
export interface ProviderProbeGroup {
    provider: string
    /** 各探测在原数组中的下标（结果按此回填，汇总与顺序无关） */
    indexes: number[]
    probes: VerifyProbe[]
}

/** 一轮请求的两条硬闸（约束烧掉的额度）：真正发出的请求数与计划模型数；超出即拒绝而非静默截断（截断会让用户以为「全查过了」） */
interface ProbeLimits {
    /** 真正会发出的请求数上限（计划条目一条即一次请求） */
    maxProbes: number
    /** 计划模型数上限（按「提供方 / 模型」去重） */
    maxModels: number
}

/** 验证的配额：每模型一条请求（不带档位参数），请求数即勾选模型数，封顶 200（超出即拒绝，用户可减少勾选重来） */
export const VERIFY_LIMITS: ProbeLimits = { maxProbes: 200, maxModels: Number.POSITIVE_INFINITY }
/** 探测档位的配额：全量展开为「模型数 × 至多 7 档」（off 仅当模型已声明时才探测），故模型数封顶 200（至多 1400 次最小请求） */
export const PROBE_LIMITS: ProbeLimits = { maxProbes: 1400, maxModels: 200 }

/** 校验并展开请求载荷为清单：条目不带 `efforts`（或空数组）即一条不带档位的请求（验证的每个模型都长这样）；带 `efforts` 的条目（探测档位）按档位逐条展开；非法条目或超出 `limits` 一律拒绝（返回 undefined） */
export function planProbes(payload: unknown, limits: ProbeLimits = VERIFY_LIMITS): VerifyProbe[] | undefined {
    if (!isPlainObject(payload)) return
    const models = payload.models
    if (!Array.isArray(models) || models.length === 0) return
    const probes: VerifyProbe[] = []
    const plannedModels = new Set<string>()
    for (const entry of models) {
        if (!isPlainObject(entry)) return
        const { provider, model, efforts } = entry
        if (typeof provider !== 'string' || provider === '' || typeof model !== 'string' || model === '') return
        // 模型数按「提供方 / 模型」去重计
        plannedModels.add(JSON.stringify([provider, model]))
        if (plannedModels.size > limits.maxModels) return
        if (efforts === undefined || (Array.isArray(efforts) && efforts.length === 0)) {
            // 没有档位要试：这条不带档位的请求本身就是被验对象
            probes.push({ provider, model })
            if (probes.length > limits.maxProbes) return
            continue
        }
        if (!Array.isArray(efforts)) return
        for (const effort of efforts) {
            // 档位须落在 harness 支持的取值内（入参来自浏览器，仍按不可信输入校验）
            if (typeof effort !== 'string' || !LEVELS.has(effort)) return
            probes.push({ provider, model, effort })
            // 清单一条即一次真实请求，故请求数取清单长度
            if (probes.length > limits.maxProbes) return
        }
    }
    return probes
}

/** 按 provider 分组，组内保持探测原序；组序为提供方首次出现序 */
export function groupProbesByProvider(probes: readonly VerifyProbe[]): ProviderProbeGroup[] {
    const byProvider = new Map<string, ProviderProbeGroup>()
    probes.forEach((probe, index) => {
        let group = byProvider.get(probe.provider)
        if (group === undefined) {
            group = { provider: probe.provider, indexes: [], probes: [] }
            byProvider.set(probe.provider, group)
        }
        group.indexes.push(index)
        group.probes.push(probe)
    })
    return [...byProvider.values()]
}

/** 校验并展开未信任载荷、按提供方分组返回待跑清单（入参非法即抛出）。
 * 与执行拆两步：`done` 帧须等整轮结束才发，而探测档位的整轮含收敛写回，故计划先交到调用方手里（它还要拿模型清单写配置） */
export function planProbeGroups(payload: unknown, limits: ProbeLimits, rejectMessage: string): ProviderProbeGroup[] {
    const probes = planProbes(payload, limits)
    if (probes === undefined) throw new Error(rejectMessage)
    return groupProbesByProvider(probes)
}
