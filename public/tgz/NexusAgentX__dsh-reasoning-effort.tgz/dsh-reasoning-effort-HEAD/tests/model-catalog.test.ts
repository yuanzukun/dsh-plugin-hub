import { describe, expect, it } from 'vitest'
import { REASONING_LEVELS } from '../src/config'
import {
  modelCatalog as catalog,
  resolveModelCapacity,
  resolveModelEfforts,
  resolveModelInput,
} from '../src/model-catalog'

type NumberOrNull = number | null

interface CatalogEntry {
  readonly model: string
  readonly aliases: readonly string[]
  readonly input: readonly ('text' | 'image')[]
  readonly contextWindow: number | null
  readonly maxOutputTokens: number | null
  readonly pricing: {
    readonly currency: string
    readonly unit: string
    readonly input: NumberOrNull
    readonly output: NumberOrNull
    readonly cacheRead: NumberOrNull
    readonly cacheWrite: NumberOrNull
    readonly region?: string
    readonly conditions?: string
    readonly tiers?: readonly Record<string, unknown>[]
  }
  readonly reasoningEfforts: Record<string, string | null>
  readonly sources: { readonly capabilities: string, readonly pricing: string }
}

const entries = catalog.models as readonly unknown[] as readonly CatalogEntry[]
const allowedLevels = new Set<string>(REASONING_LEVELS)
const textOnlyModels = new Set([
  'deepseek-v4-flash',
  'deepseek-v4-pro',
  'qwen3.7-max',
  'glm-5.3',
  'mimo-v2.5-pro',
  'hy3',
])
const expectedModels = [
  'gpt-5.4', 'gpt-5.5', 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna', 'gpt-6-astra',
  'gpt-6-sol', 'gpt-6-luna', 'gpt-6.1-sol',
  'claude-opus-4.6', 'claude-opus-4.7', 'claude-opus-4.8', 'claude-opus-5', 'claude-opus-5-5',
  'claude-sonnet-4.6', 'claude-sonnet-5', 'claude-sonnet-5-5',
  'claude-fable-5', 'claude-fable-5-1', 'claude-haiku-5-5',
  'deepseek-v4-flash', 'deepseek-v4-pro', 'deepseek-v4-flash-vision-exp', 'deepseek-flash',
  'gemini-3.7-flash', 'gemini-3.8-flash', 'gemini-4-argon',
  'grok-4.5', 'grok-4.6', 'grok-4.7',
  'qwen3.7-max', 'qwen3.7-plus',
  'qwen3.7-flash', 'qwen3.8-max', 'qwen3.8-27b',
  'qwen3.8-flash', 'qwen3.8-omni-flash',
  'kimi-k3',
  'glm-5.3',
  'glm-5.3-flash', 'glm-5.3-flashx',
  'mimo-v2.5',
  'mimo-v2.5-pro', 'mimo-v2.6-pro', 'mimo-v2.6-flash', 'mimo-v2.6-pro-ultraspeed',
  'hy3',
  'sensenova-6.8-flash-lite', 'sensenova-u1.5-lite', 'sensenova-u1.5-fast',
  'MiniMax-M3', 'MiniMax-M3.1-Flash-Preview',
] as const

function isNonNegativeNumberOrNull(value: unknown): value is NumberOrNull {
  return value === null || (typeof value === 'number' && Number.isFinite(value) && value >= 0)
}

describe('model catalog', () => {
  it('contains exactly the curated 52 unique models', () => {
    expect(catalog.version).toBe(1)
    expect(entries).toHaveLength(52)
    expect(new Set(entries.map(entry => entry.model)).size).toBe(52)
    expect(entries.map(entry => entry.model).sort()).toEqual([...expectedModels].sort())
  })

  it('keeps complete, typed metadata and an explicit off level', () => {
    for (const entry of entries) {
      expect(entry.aliases).toEqual(expect.any(Array))
      expect(entry.aliases.every(alias => typeof alias === 'string' && alias.length > 0)).toBe(true)
      expect(entry.input).toEqual(textOnlyModels.has(entry.model) ? ['text'] : ['text', 'image'])
      expect(entry.contextWindow === null || (Number.isInteger(entry.contextWindow) && entry.contextWindow > 0)).toBe(true)
      expect(entry.maxOutputTokens === null || (Number.isInteger(entry.maxOutputTokens) && entry.maxOutputTokens > 0)).toBe(true)
      expect(entry.pricing.currency).toBe('USD')
      expect(entry.pricing.unit).toBe('per_million_tokens')
      expect(isNonNegativeNumberOrNull(entry.pricing.input)).toBe(true)
      expect(isNonNegativeNumberOrNull(entry.pricing.output)).toBe(true)
      expect(isNonNegativeNumberOrNull(entry.pricing.cacheRead)).toBe(true)
      expect(isNonNegativeNumberOrNull(entry.pricing.cacheWrite)).toBe(true)
      expect(entry.reasoningEfforts.off).toBeNull()
      expect(Object.keys(entry.reasoningEfforts).every(level => allowedLevels.has(level))).toBe(true)
      expect(Object.entries(entry.reasoningEfforts).every(([level, wire]) =>
        level === 'off' ? wire === null : wire === level)).toBe(true)
      for (const tier of entry.pricing.tiers ?? []) {
        expect(typeof tier.condition).toBe('string')
        for (const [key, value] of Object.entries(tier)) {
          if (key !== 'condition') expect(isNonNegativeNumberOrNull(value)).toBe(true)
        }
      }
      expect(new URL(entry.sources.capabilities).protocol).toBe('https:')
      expect(new URL(entry.sources.pricing).protocol).toBe('https:')
    }
  })

  it('resolves the curated 2026-09 additions', () => {
    expect(resolveModelEfforts('gpt-6-astra')).toEqual({
      off: null,
      low: 'low',
      medium: 'medium',
      high: 'high',
      xhigh: 'xhigh',
      max: 'max',
    })
    expect(resolveModelInput('gpt-6-astra')).toEqual(['text', 'image'])
    expect(resolveModelCapacity('openai/gpt-6-astra')).toEqual({
      contextWindow: 1050000,
      maxTokens: 128000,
    })

    // Both the canonical dashed id and the dotted spelling providers publish
    // normalize to the same key, and the bare model name is an explicit alias.
    for (const modelId of ['claude-fable-5-1', 'claude-fable-5.1', 'fable-5.1', 'anthropic/claude-fable-5.1']) {
      expect(resolveModelEfforts(modelId)).toEqual({
        off: null,
        low: 'low',
        medium: 'medium',
        high: 'high',
        xhigh: 'xhigh',
        max: 'max',
      })
      expect(resolveModelInput(modelId)).toEqual(['text', 'image'])
      expect(resolveModelCapacity(modelId)).toEqual({
        contextWindow: 1000000,
        maxTokens: 128000,
      })
    }

    // `deepseek-v4.1-flash` is the spelling aggregators publish for the same
    // model; without its alias it fuzzy-matched the retired flash entry and
    // reported that entry's text-only input.
    for (const modelId of ['deepseek-flash', 'DeepSeek/DeepSeek-Flash', 'deepseek-v4.1-flash']) {
      expect(resolveModelEfforts(modelId)).toEqual({ off: null, low: 'low', high: 'high', max: 'max' })
      expect(resolveModelInput(modelId)).toEqual(['text', 'image'])
      expect(resolveModelCapacity(modelId)).toEqual({
        contextWindow: 1000000,
        maxTokens: 384000,
      })
    }

    expect(resolveModelEfforts('gemini-3.8-flash')).toEqual({
      off: null,
      low: 'low',
      medium: 'medium',
      high: 'high',
    })
    expect(resolveModelInput('gemini-3.8-flash')).toEqual(['text', 'image'])
    expect(resolveModelCapacity('google/gemini-3.8-flash')).toEqual({
      contextWindow: 1048576,
      maxTokens: 65536,
    })
  })

  it('resolves the curated 2026-10 family additions', () => {
    const cases = [
      {
        modelId: 'gpt-6-sol',
        efforts: { off: null, low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' },
        capacity: { contextWindow: 1050000, maxTokens: 128000 },
      },
      {
        modelId: 'openai/gpt-6.1-sol',
        efforts: { off: null, low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' },
        capacity: { contextWindow: 1050000, maxTokens: 128000 },
      },
      {
        modelId: 'anthropic/claude-opus-5.5',
        efforts: { off: null, low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' },
        capacity: { contextWindow: 1000000, maxTokens: 128000 },
      },
      {
        modelId: 'claude-sonnet-5.5',
        efforts: { off: null, low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' },
        capacity: { contextWindow: 1000000, maxTokens: 128000 },
      },
      {
        modelId: 'claude-haiku-5-5',
        efforts: { off: null, low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' },
        capacity: { contextWindow: 1000000, maxTokens: 128000 },
      },
      {
        modelId: 'google/gemini-4-argon',
        efforts: { off: null, low: 'low', medium: 'medium', high: 'high' },
        capacity: { contextWindow: 1048576, maxTokens: 32768 },
      },
      {
        modelId: 'grok-4.7',
        efforts: { off: null, low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh' },
        capacity: { contextWindow: 500000, maxTokens: 500000 },
      },
      {
        modelId: 'qwen3.8-omni-flash',
        efforts: { off: null, low: 'low', medium: 'medium', xhigh: 'xhigh' },
        capacity: { contextWindow: 1000000, maxTokens: 131072 },
      },
      {
        modelId: 'glm-5.3-flashx',
        efforts: { off: null, low: 'low', high: 'high', max: 'max' },
        capacity: { contextWindow: 1000000, maxTokens: 131072 },
      },
      {
        modelId: 'mimo-v2.6-pro',
        efforts: { off: null, high: 'high' },
        capacity: { contextWindow: 1048576, maxTokens: 131072 },
      },
      {
        modelId: 'mimo-v2.6-flash',
        efforts: { off: null, high: 'high' },
        capacity: { contextWindow: 1048576, maxTokens: 131072 },
      },
    ] as const

    for (const { modelId, efforts, capacity } of cases) {
      expect(resolveModelEfforts(modelId)).toEqual(efforts)
      expect(resolveModelInput(modelId)).toEqual(['text', 'image'])
      expect(resolveModelCapacity(modelId)).toEqual(capacity)
    }
  })

  it('resolves the curated SenseTime and MiniMax models', () => {
    expect(resolveModelEfforts('sensenova-6.8-flash-lite')).toEqual({
      off: null,
      low: 'low',
      medium: 'medium',
      high: 'high',
    })
    expect(resolveModelInput('SenseTime/SenseNova-6.8-Flash-Lite')).toEqual(['text', 'image'])
    expect(resolveModelCapacity('sensenova-6.8-flash-lite')).toEqual({
      contextWindow: 262144,
      maxTokens: 65536,
    })

    for (const modelId of ['sensenova-u1.5-lite', 'sensenova-u1.5-fast']) {
      expect(resolveModelEfforts(modelId)).toEqual({ off: null })
      expect(resolveModelInput(`SenseTime/${modelId}`)).toEqual(['text', 'image'])
      expect(resolveModelCapacity(modelId)).toBeUndefined()
    }

    expect(resolveModelEfforts('MiniMax/MiniMax-M3')).toEqual({ off: null, high: 'high' })
    expect(resolveModelInput('MiniMax-M3')).toEqual(['text', 'image'])
    expect(resolveModelCapacity('MiniMax-M3')).toEqual({
      contextWindow: 1000000,
      maxTokens: 512000,
    })

    expect(resolveModelEfforts('MiniMax-M3.1-Flash-Preview')).toEqual({
      off: null,
      low: 'low',
      medium: 'medium',
      high: 'high',
      xhigh: 'xhigh',
      max: 'max',
    })
    expect(resolveModelInput('minimax-m3-1-flash-preview')).toEqual(['text', 'image'])
    expect(resolveModelCapacity('MiniMax-M3.1-Flash-Preview')).toEqual({
      contextWindow: 1000000,
      maxTokens: 512000,
    })
  })

  it('does not include an open-weight Qwen model', () => {
    expect(entries.filter(entry => entry.model.includes('qwen3.6'))).toEqual([])
    expect(entries.map(entry => entry.model)).not.toContain('qwen3.8-2.4t-a95b')
  })

  it('resolves normalized user model identifiers without a provider', () => {
    expect(resolveModelEfforts('DeepSeek/DEEPSEEK_V4_FLASH')).toEqual({ off: null, high: 'high', max: 'max' })
  })

  it('resolves curated input modalities without a provider', () => {
    expect(resolveModelInput('DeepSeek/DEEPSEEK_V4_FLASH')).toEqual(['text'])
    expect(resolveModelInput('deepseek-v4-flash-vision-exp')).toEqual(['text', 'image'])
    expect(resolveModelInput('mimo-v2.5-pro')).toEqual(['text'])
  })

  it('resolves curated capacities without a provider', () => {
    expect(resolveModelCapacity('DeepSeek/DEEPSEEK_V4_FLASH')).toEqual({
      contextWindow: 1048576,
      maxTokens: 393216,
    })
    expect(resolveModelCapacity('deepseek-v4-pro')).toEqual({
      contextWindow: 1048576,
      maxTokens: 393216,
    })
    // pi-ai reads `maxTokens`, so the catalog's `maxOutputTokens` spelling is
    // translated by the resolver before it reaches a model entry.
    expect(resolveModelCapacity('gpt-5.4')).toEqual({
      contextWindow: 1050000,
      maxTokens: 128000,
    })
  })

  it('resolves no capacity for an unknown or underspecified model', () => {
    expect(resolveModelCapacity('unknown-model')).toBeUndefined()
    expect(resolveModelCapacity('gpt-5.4-2026-08-15')).toBeUndefined()
  })

  it('accepts a high-confidence typo with a unique best candidate', () => {
    expect(resolveModelEfforts('claude-sonet-4.6')).toEqual({
      off: null,
      low: 'low',
      medium: 'medium',
      high: 'high',
      xhigh: 'xhigh',
      max: 'max',
    })
  })

  it('skips suffix variants, low-confidence names, and ambiguous candidates', () => {
    expect(resolveModelEfforts('gpt-5.4-2026-08-15')).toBeUndefined()
    expect(resolveModelEfforts('claude-opus')).toBeUndefined()
    expect(resolveModelEfforts('claude-opus-4.x')).toBeUndefined()
  })
})
