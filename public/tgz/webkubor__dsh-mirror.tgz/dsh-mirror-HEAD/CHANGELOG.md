# 更新日志

本项目遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

## [0.8.7](https://github.com/webkubor/dsh-mirror/compare/v0.8.6...v0.8.7) (2026-10-18)


### 🐛 Bug Fixes

* **release:** 自动解除机器人 review thread 阻塞并添加定时发版巡检 ([539409f](https://github.com/webkubor/dsh-mirror/commit/539409fd8e88771083bbe922fcca43f6420414fe))

## [0.8.6](https://github.com/webkubor/dsh-mirror/compare/v0.8.5...v0.8.6) (2026-10-12)


### 🐛 Bug Fixes

* **release:** blocked 不再一读到就判死 ([23ad7f8](https://github.com/webkubor/dsh-mirror/commit/23ad7f80e871c69769267d32c6e607c453b6ba96))
* **release:** 删掉 checks.listForRef 那层判据，只认 mergeable_state ([91f1a65](https://github.com/webkubor/dsh-mirror/commit/91f1a656f2301377f33d3c985d2b829e83e8a381))

## [0.8.5](https://github.com/webkubor/dsh-mirror/compare/v0.8.4...v0.8.5) (2026-10-12)


### 🐛 Bug Fixes

* **release:** 以 mergeable_state 为门，不再等所有 check 跑完 ([2a7222d](https://github.com/webkubor/dsh-mirror/commit/2a7222d50911d5e74e929908f6e2c80c9b5543ee))

## [0.8.4](https://github.com/webkubor/dsh-mirror/compare/v0.8.3...v0.8.4) (2026-10-12)


### 🐛 Bug Fixes

* **mirror:** 记忆 tab 从展示页改成控制面板 —— 说真话，砍掉自嗨 ([6dd6dab](https://github.com/webkubor/dsh-mirror/commit/6dd6dab30446c174b34fd0a9b56b7c8fda2bfc10))
* **release:** auto-merge 挂不上时兜底直接合并 ([6e6386f](https://github.com/webkubor/dsh-mirror/commit/6e6386fd71e2866ab69de5dc86aed0a79eeda969))
* **release:** mergeable_state 是异步的，unknown 要等而不是放弃 ([11ed5b1](https://github.com/webkubor/dsh-mirror/commit/11ed5b1e0b00237800f200291bd64a2e3a75b754))
* **release:** 等 check 跑完再挂 auto-merge ([22ce960](https://github.com/webkubor/dsh-mirror/commit/22ce96068cf04f5ef133d594c9c9c68b45d44519))


### 📝 Documentation

* DEV_NOTES 顶部加迁移指针（不改历史正文） ([2340099](https://github.com/webkubor/dsh-mirror/commit/2340099d01955516031f299aaa55b2e47c6087be))
* 安装命令改为官方 npx 写法 ([70e7137](https://github.com/webkubor/dsh-mirror/commit/70e7137da1da9472a7c00f2bf2292a6aa5384f40))
* 安装说明改到桌面端，profile 名不再写死 web ([aae1442](https://github.com/webkubor/dsh-mirror/commit/aae1442bd44d0d6716af02595b01294106b85d02))
* 底部推荐区改为一张全家桶预览图 + 一行装齐命令 ([d0dd87c](https://github.com/webkubor/dsh-mirror/commit/d0dd87c8972808fccb0e573a5570dab6bf78f98a))


### 🛠️ CI / Build

* **release:** 接上 release-please，发版从此零人工 ([d23b495](https://github.com/webkubor/dsh-mirror/commit/d23b49555c647693ff4d9127e9e86a2a4cb84cc9))

## [0.8.3] - 2026-09-27

### 📛 包装升级：徽章换成立体大款式 + 接入 README 门禁

- 8 个徽章从 `flat-square` 换成 `for-the-badge`（规则要求立体大徽章，此前一直没执行）
- 新增 `scripts/readme-gate.mjs`：README 首屏四条契约，
  挂在 `prepublishOnly` 上，以后再改 README 不合规会直接拦住发布

## [0.8.2] - 2026-09-27

### 🔧 引导词区的三种"看不见"状态修好了（浏览器实测发现）

用 lite-browser 实测记忆 tab 后发现的三个问题，都是**界面在骗人**：

- **CSS 变量名全猜错** —— 写了 `--dsw-alias-feedback-error` 等不存在的 token，
  导致「红线加粗边线」被主题默认值覆盖，视觉上完全没生效。现改用 bloom 主题
  真源（`state-error-primary` / `bg-layer-1/2` / `label-primary`）。
  p100/p90 与 p60 的边线对比度现在能被量出来。
- **未注入条目污染主列表** —— 被预算挤掉的条目原本和生效的混在一起列出，
  4 条没生效的占 4 行，把生效的挤下去。现主列表只列真正进了系统提示的，
  未注入的收进折叠区。
- **空态 / 错误态 / 诊断全部静默消失** —— `guidance/` 为空、端点失联、
  文件格式写错，界面上都干干净净什么都看不到，用户会以为这功能不存在。
  现在三种情况都有明确提示：
  - 空态说明这个功能是什么、怎么开始用、格式长什么样
  - 端点失联时明说"引导词照常注入，只是这里看不到"（别让人误以为引导词失效了）
  - 扫描诊断（缺 description / 超 32KB）列出来，可展开看是哪个文件

## [0.8.1] - 2026-09-27

### 🪞 记忆 tab 里能看到你的引导词了

系统提示里注入的引导词此前对人是黑盒 —— 改了文件不知道有没有生效，
预算不够哪条被挤掉也不知道。

现在记忆 tab 顶部新增「手写引导词」段：

- 每条标 priority / 注入状态 / 文件名 / tags
- 被预算挤掉的条目顶部黄条明示，绝不静默丢
- 红线（priority ≥ 90）单独加粗边线，让最严的规矩不会被淹没
- 不依赖有没有偏好记忆 —— 没有偏好也能看到引导词

数据走新建的 `GET /dsh-mirror/guidance` 端点，与 system prompt
注入用的是同一个扫描缓存，前后状态一致。

## [0.8.0] - 2026-09-27

### 📝 手写引导词：人能往记忆里写话了

在这之前，这颗镜子只单向工作 —— 模型记你，你只能看。你自己的规矩（走什么流程、
什么绝不做）没有地方放：写在 `~/.dsh/memory/` 的文件里从来没被读过，
写给模型的系统提示更是没有入口。

现在 `~/.dsh/memory/guidance/` 成为你的手写入口，30 秒内注入每个会话：

- **只注入一行摘要** —— 每条引导词在系统提示里占一行（`description`），
  全文用新增的 `memory_read` 工具按需取。所以 30 条引导词也只占 30 行，
  而不是 30 篇文档压在每轮请求上
- **目录分三类，只有一类进提示** —— `guidance/` 注入、`reference/` 按需读、
  `archive/` 不读。资料（清单、盘点）不再和指令混在一起
- **预算封顶 + 明示截断** —— 超出预算按 `priority` 截断，并且**在提示里明确写出
  哪条没进去**。红线被挤掉而你不知道，比报错更糟
- **没有 `description` 就不注入** —— 逼作者写摘要，这是目录不烂掉的关键
- **看得见** —— 新增 `GET /dsh-mirror/guidance` 端点，记忆 tab 能看到本次注入了
  哪些、哪条被预算挤掉了

引导词与偏好记忆是两条独立的线：引导词你手写、不衰减、优先级更高；
偏好记忆模型自己记、会遗忘。两者都进系统提示，引导词排在前面。

## [0.7.2] - 2026-09-26

### 🏷️ 完整 TypeScript 类型支持

- **类型定义导出**：新增 `types/index.d.ts`，导出完整的记忆契约（`MemoryItem`、`MemoryKind`、`strengthOf`、`findSimilar` 等核心算法定义）。
- **工程统一规范**：补充 `npm run check` 静态语法巡检与 `tsconfig.json`。

## [0.7.0] - 2026-09-18

### 记忆 tab 从「记录列表」变成「一张画像」

原来打开记忆 tab，看到的是一份数据库视图：每条记录平权排列，下面跟一行
`强度 3.7 / 确认 5 次 / 2 天前`，四类记忆混在一个流里只靠一个小徽章区分。
人从里面读不出自己是谁。

现在它是一张画像：

- **一句话速写** —— 顶部直接给出被印证最多的那条判断，那就是模型眼里最认定你的一条
- **强度就是字重** —— 越被印证的判断字越重越实，弱的退成灰字。不再显示「强度 3.7」
  这种对人没有意义的数字
- **证据折进判断里** —— 正面只放抽象后的判断，点「看是哪几次」才展开它从哪些具体
  事件来的。技术细节不占版面，但追溯链还在
- **红线单独成块** —— 四类不该长得一样。红线是越界有代价的硬约束，给它唯一的朱砂色，
  并且不参与遗忘
- **「正在淡忘」折叠区** —— 会遗忘是这个插件最独特的机制，以前完全看不见

视觉上：画像头一层极淡光晕，卡片依次浮起、hover 微微上抬，强度条从左展开，
印证次数用小横条计量。所有动效在系统「减少动态效果」下自动关闭，关掉后信息结构不变。
内容限宽 860px 居中 —— 超宽屏上铺满会把每行拉到 100+ 字，判断本身就读不下去了。

### 其它

- README 重做：加了 npm / 下载量 / topic 徽章、记忆 tab 实拍图，以及「装它和不装它
  的区别」对照表；三段开发笔记移到 [DEV_NOTES.md](./DEV_NOTES.md)，README 只留用户向内容
- 新增 `npm run deploy`：直接同步到 web profile，改完刷新页面就能看到，不必等发版

> 数据契约没有变化，`index.js` 未改动，升级不影响已有记忆。

## [0.6.3] - 2026-09-17

### 包名迁移

- `name` 从 `@webkubor/dsh-user-mirror` 迁到 `@dsh-plugins/dsh-user-mirror`（org scope）。
  原因：org 名比个人账号名得体，读起来是「dsh-plugins 项目组的插件」，而不是「
  webkubor 这个人的玩具」。
  旧的 `@webkubor/dsh-user-mirror@0.6.2` 不删 —— 按 `dsh-plugins` 顶层 README 的规则，
  只挂 deprecate 指向新名，`npm unpublish` 一律不碰（虽然月下载为 0，但流程一致）。
- version 跳到 **0.6.3**（跳过 0.6.2 —— 那是 0.6.1 改名 + 一次空内容的占位重发，
  详见下方 0.6.2 节）。

### 修复

- **client.js 注册 id 与 package.json 的 name 对齐**：迁移到 org scope 时漏改了
  `__ModuleLoader__.load({ id })`，宿主按 `package.json` 的 name 找注册项，
  对不上就**静默不挂载** —— 类型检查和普通单测都发现不了，只有打开页面才会发现
  那个 tab / 入口不见了。dsh-llm-hub 在 0.6.3 上发生过同形状的事故。

### 新增

- **测试**：新增 `test/plugin-id.test.mjs` 守卫这条 regression。
  守卫不写死期望值，而是分别从 `package.json` 和 `client.js` 里读 —— 写死期望值的断言
  在改名时非但拦不住，反而成了钉住旧名的锚。`npm test` 已在 `package.json` 的
  `scripts` 里接好。

## [0.6.2] - 2026-09-17

### 发布占位

- 与 0.6.1 内容等同的一次重发，发布在 `@webkubor/dsh-user-mirror` scope 下。
  0.6.2 **没有对应的 commit**（包名迁移过程中、工作区处于混合状态时发出的占位重发，
  本仓库 git 树里没有这个版本），也没有 tag —— 它只是在 npm 注册表上占着 0.6.2
  这个号码。

  本条按 git 证据如实记录：编一份看起来完整的清单，比留一句「查不到」更坏。

  补这节的原因是发布工作流（参 `dsh-llm-hub/.github/workflows/publish.yml` 的同样处理）
  的 Release 步骤要从 CHANGELOG 取对应小节，取不到就 `process.exit(1)`：缺小节意味着
  `gh workflow run publish.yml -f tag=v0.6.2` 这类补发会直接失败。

## [0.6.1] - 2026-09-17 之前

### 基础版本（从 npm tarball 恢复）

- **记忆模型**：强度 = 命中次数 × 时间衰减，半衰期默认 30 天，容量上限 20 条，
  按 token 预算（默认 500）注入。
- **同主题覆盖**：英文实体（`r2` / `picx` / `main` 这类技术语境里的主题标签）+ 中文
  二元组重叠双通道判定。已知边界：完全换词的纯中文同义句会漏检 —— 真要修得上 embedding，
  不值得为此加重量级依赖。
- **工具**：`mirror_remember(text, kind, reason)`（记 + 写明为什么记）、
  `mirror_forget(text, reason)`（按同主题匹配撤掉，v0.6 把原来的 `mirror_preferences`
  替换成它 —— 只能写不能撤的话，一条记错的东西要么等半个月衰减、要么等同主题新说法
  覆盖它，期间一直污染每一轮的系统提示）。
- **故意不提供查询工具**：记忆本来就在 system prompt 里，再给查询工具就是第二条
  读路径，白占常驻 token。
- **UI**：「对话 / 轨迹」之后多一个「记忆」tab，每条带分类 + 内容 + `reason` +
  强度/确认次数/最后确认时间，右上 ✕ 两段式删除（DELETE/POST 限定 + 同源校验，
  GET 一律 405，免得被预取或前进后退重放误删）。
- **状态球**：用 npm 上的 [ai-orb](https://github.com/webkubor/ai-orb) 本体（host 端按
  同源静态资源下发 `/dsh-mirror/vendor/ai-orb/`），不是抄一份进来；升 ai-orb 只需升
  依赖，没有副本要同步。
- **cordis 挂载**：单行 `insert` —— `id: dsh-mirror`、`name: dsh-user-mirror`，由
  `dsh.bundle.patch` 自动 insert。
- **强约束**：只能装在提供 `storageDomain` + `webServer` 的 profile 上（也就是 web），
  headless 上两个服务都缺 —— 依赖路径在 README「安装」节明写。
