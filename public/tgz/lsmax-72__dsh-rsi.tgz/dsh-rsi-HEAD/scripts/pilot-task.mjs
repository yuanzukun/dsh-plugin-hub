import assert from 'node:assert/strict';
import {cp, readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {mkdirSync, openSync, closeSync, fsyncSync, writeFileSync, renameSync, appendFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {LlmAdapter, createUserMessage} from '@deepseek-ai/dsh-llm';
import {auditRequests} from './audit-session-requests.mjs';
import {Session,buildForkSeed} from '@deepseek-ai/dsh-session';
import {waitForLearning} from './swe-learning-settlement.mjs';
import {taskProtocol,taskHistoryGuidance} from './task-input.mjs';

export const name = 'rsi-pilot-task';
export const inject = ['llm', 'agents', 'sessions', 'sessionPersistence', 'skills', 'tools'];

// The same official agent executes both arms. RSI is absent from the baseline patch.
export function apply(ctx, config) {
  assert.ok(['baseline', 'rsi'].includes(config.arm));
  const dir = '/state/pilot/' + config.instanceId;
  mkdirSync(dir, {recursive:true});
  let compaction;
  if(config.continuousState)ctx.inject(['compaction'],scope=>{compaction=scope.compaction;});
  const blocked = [];
  const requests = [], results = [], sessions = new Map(), phaseResults = [], learningSettlements = [];
  let learningAttempts = 0;
  let foreground = 0, phaseCalls = 0, phaseLimit, deadline, initialized = false, currentPhase = 'setup';
  const dispatchLimit = config.dispatchLimit ?? 50;
  const wallTimeMs = config.wallTimeMs ?? 1200000;
  const git = (...args) => execFileSync('git', args, {cwd:'/workspace', encoding:'utf8',
    env:config.baselineDate?{...process.env,GIT_AUTHOR_DATE:config.baselineDate,GIT_COMMITTER_DATE:config.baselineDate}:process.env});
  const durable = (path, value) => {
    const tmp = path + '.tmp';
    writeFileSync(tmp, typeof value === 'string' ? value : JSON.stringify(value, null, 2));
    const fd = openSync(tmp, 'r'); try {fsyncSync(fd);} finally {closeSync(fd);}
    renameSync(tmp, path);
    const parent = openSync(dir, 'r'); try {fsyncSync(parent);} finally {closeSync(parent);}
  };
  const ledger = () => durable(dir + '/model-requests.json', requests);
  // A native turn can be cancelled before its first dispatch or tool result.
  ledger();durable(dir+'/tool-results.json',results);
  const patchSnapshots=[];let previousPatch;
  mkdirSync(dir+'/patch-snapshots',{recursive:true});
  const patch = () => {
    if (!initialized) return;
    git('add', '-A');
    const body=git('diff', '--cached', '--binary', 'HEAD'),sha256=createHash('sha256').update(body).digest('hex');
    durable(dir + '/prediction.patch',body);
    if(sha256!==previousPatch){
      durable(dir+'/patch-snapshots/'+sha256+'.patch',body);
      patchSnapshots.push({sha256,phase:currentPhase,requestOrdinal:foreground,observedAt:Date.now(),nonempty:body.length>0});
      durable(dir+'/patch-snapshots.json',patchSnapshots);previousPatch=sha256;
    }
    return sha256;
  };
  ctx.on('session/event', (session, event) => {
    if (!sessions.has(session.id)) {
      sessions.set(session.id, session);
      durable(dir + '/' + session.id + '.header.json', session.header);
    }
    // Mirror published native events as well as retaining official persistence in /state/home.
    const file = dir + '/source-events.jsonl';
    appendFileSync(file, JSON.stringify({sessionId:session.id, event}) + '\n');
    const fd = openSync(file, 'r'); try {fsyncSync(fd);} finally {closeSync(fd);}
  });
  ctx.on('llm/stream', async function*(options, next) {
    const background = options.sessionId.startsWith('rsi-');
    if (background && learningAttempts >= (config.learningDispatchLimit ?? config.learningCallBudget ?? 30)) {
      blocked.push({sessionId:options.sessionId,phase:'learning',reason:'EXPERIMENT_CALL_CAP',time:Date.now()});
      durable(dir + '/blocked-dispatches.json',blocked);
      throw Object.assign(new Error('Experiment learning dispatch limit reached'),{code:'BUDGET_EXHAUSTED'});
    }
    if (background) learningAttempts++;
    if (!background && (foreground >= dispatchLimit || phaseCalls >= phaseLimit)) throw new Error('Pilot foreground dispatch limit reached');
    if (!background) {foreground++; phaseCalls++;}
    const session = sessions.get(options.sessionId);let prefixEndSeq,inheritedEventCount=0;
    if (session) {
      await ctx.sessions.flush(session);prefixEndSeq=session.snapshotEvents().at(-1)?.seq;inheritedEventCount=session.inheritedEventCount;
    }
    else {
      // The native background bridge writes persistence directly and flushes before stream.
      assert.ok(background, 'Foreground request has no observed native session');
      const handle = await ctx.sessionPersistence.open(options.sessionId,'read');
      try {
        const stored = await handle.read();
        prefixEndSeq=stored.events.at(-1)?.seq;inheritedEventCount=handle.inheritedEventCount;
        const restored = Session.fromRestore(options.sessionId,stored.events,handle.header,handle.inheritedEventCount,stored.eventState);
        assert.deepEqual([...restored.deriveMessages()],options.messages);
      } finally {await handle.close();}
    }
    const request = {sessionId:options.sessionId, phase:background?'learning':currentPhase,
      prefixEndSeq,inheritedEventCount,purpose:options.purpose??'task',messages:structuredClone(options.messages), status:'DISPATCHING', usage:null, reasoningBlocks:[], reasoningDeltas:[], finish:null, observedAt:Date.now()};
    requests.push(request); patch(); ledger();
    try {
      for await (const chunk of next()) {
        if (chunk.type === 'reasoning-delta') request.reasoningDeltas.push({index:chunk.index,text:chunk.text});
        if (chunk.type === 'block-end' && chunk.block.type === 'reasoning') {request.reasoningBlocks.push(structuredClone(chunk.block)); ledger();}
        if (chunk.type === 'finish') {request.finish=structuredClone(chunk.reason); ledger();}
        if (chunk.type === 'usage') {request.usage = chunk.usage; ledger();}
        yield chunk;
      }
      request.status = 'RETURNED';
    } catch (error) {request.status = 'ERROR'; request.error = error.message; throw error;}
    finally {request.reasoningChars=request.reasoningDeltas.reduce((n,b)=>n+[...(b.text??'')].length,0);request.reasoningSha256=createHash('sha256').update(JSON.stringify({blocks:request.reasoningBlocks,deltas:request.reasoningDeltas})).digest('hex');request.finishedAt = Date.now(); ledger();}
  });
  ctx.on('tools/result', (execution, result) => {
    results.push({name:execution.name,callId:execution.callId,args:execution.arguments,isError:result.isError===true,phase:currentPhase,requestOrdinal:foreground,observedAt:Date.now(),patchSha256:patch()});
    durable(dir + '/tool-results.json', results); patch();
  });
  if (config.fixture) {
    class Fixture extends LlmAdapter {
      async resolveModel(provider,model){return {provider,id:model,name:model,context:{contextWindow:262144},defaultMaxTokens:8192};}
      async *stream(options) {
        if(options.purpose==='compaction'){
          const block={type:'text',text:'已完成前序隔离任务；原始日志保留在会话记录。当前任务须重新读取源码。'};
          yield {type:'block-start',index:0,blockType:'text'};yield {type:'block-end',index:0,block};
          yield {type:'usage',usage:{inputTokens:13,outputTokens:7,totalTokens:20}};yield {type:'finish',reason:{kind:'stop'}};return;
        }
        if (options.sessionId.startsWith('rsi-')) {
          assert.ok(config.fixtureLearning);
          const block={type:'text',text:options.tools?.length?'No reusable skill candidates.':'[]'};
          yield {type:'block-start',index:0,blockType:'text'};
          yield {type:'block-end',index:0,block};
          yield {type:'usage',usage:{inputTokens:13,outputTokens:7,totalTokens:20}};
          yield {type:'finish',reason:{kind:'stop'}};return;
        }
        const n = requests.filter(r=>r.sessionId===options.sessionId && r.purpose!=='compaction').length;
        if (config.interruptCheckpoint && n === 2) {
          console.log('RSI_CHECKPOINT_READY');
          await new Promise(()=>{});
        }
        if(config.continuousState && config.priorTaskLogs?.length && n===1){
          const previous=config.priorTaskLogs.at(-1);
          const block={type:'tool-call',id:'fixture-history-read-'+options.sessionId,name:'read',arguments:JSON.stringify({file_path:'/state/home/sessions/'+previous.relativePath})};
          yield {type:'block-start',index:0,blockType:block.type};yield {type:'block-end',index:0,block};
          yield {type:'usage',usage:{inputTokens:13,outputTokens:7,totalTokens:20}};yield {type:'finish',reason:{kind:'tool-calls'}};return;
        }
        const writeOrdinal=config.continuousState && config.priorTaskLogs?.length?2:1;
        const block = n === writeOrdinal ? {type:'tool-call', id:config.continuousState?'fixture-write-'+options.sessionId:'fixture-write', name:'write',
          arguments:JSON.stringify({file_path:'/workspace/preflight-marker.txt', content:'isolated change\n'})}
          : {type:'text', text:'固定响应检查完成。'};
        yield {type:'block-start', index:0, blockType:block.type};
        yield {type:'block-end', index:0, block};
        yield {type:'usage', usage:{inputTokens:13, outputTokens:7, totalTokens:20}};
        yield {type:'finish', reason:{kind:n===writeOrdinal?'tool-calls':'stop'}};
      }
    }
    ctx.effect(()=>ctx.llm.registerAdapter(['pilot-fixture'], new Fixture()));
  }
  ctx.effect(()=>{
    const alive = setInterval(()=>{}, 1000);
    const timer = setTimeout(async()=>{
      let rsi;
      try {
        await cp('/opt/task-source', '/workspace', {recursive:true,verbatimSymlinks:true});
        git('init'); git('config','user.name','lsmax'); git('config','user.email','liushuai072002@163.com');
        git('add','-f','-A'); git('commit','-m','Pilot task baseline'); initialized = true;
        const baselineTree = git('write-tree').trim();
        if (config.expectedTree) assert.equal(baselineTree,config.expectedTree,'Task source tree mismatch');
        const djangoVersion = execFileSync('python',['-c','import django; print(django.get_version())'],{cwd:'/workspace',encoding:'utf8'}).trim();
        if (config.expectedVersion) assert.equal(djangoVersion,config.expectedVersion,'Task/scorer Django version mismatch');
        // get() is the official optional-service lookup; no hidden plugin dependency in baseline.
        rsi = ctx.get('rsi');
        if (config.arm === 'rsi') {assert.ok(rsi); await rsi.ready;}
        else assert.equal(rsi, undefined, 'Baseline must not instantiate RSI');
        // Restored preferences override startup defaults. Disable learning via
        // the normal settings API on the isolated copy before task execution.
        if(config.assetConsumptionOnly) await rsi.request('settings',{cwd:'/workspace',settings:{learningEnabled:false,dailyCallBudget:0}});
        const snapshot = async()=>rsi ? await rsi.request('snapshot',{cwd:'/workspace'}) : null;
        const before = await snapshot();
        if (before) assert.equal(before.settings.dailyCallBudget, config.learningCallBudget ?? 30);
        if(config.assetConsumptionOnly) assert.equal(before.settings.learningEnabled,false,'Consumption replay must not learn');
        const exportedBefore = rsi ? await rsi.request('export',{cwd:'/workspace'}) : null;
        durable(dir + '/initial.json', {arm:config.arm, baselineTree, settings:before?.settings??null,
          baselineCommitTime:git('show','-s','--format=%ct','HEAD').trim(),
          djangoVersion,
          priorTaskLogs:config.priorTaskLogs??[], assets:exportedBefore, toolSchemas:ctx.tools.schemas().map(t=>t.name),
          skillCandidates:await ctx.skills.list({cwd:'/workspace'})});
        const task = JSON.parse(await readFile('/opt/rsi/task.json','utf8'));
        if (!config.fixture && config.instanceId !== 'preflight') assert.equal(task.instance_id,config.instanceId,'Task image/public ID mismatch');
        const phases = config.phases ?? [{name:config.assetConsumptionOnly?'consumption':'task',prompt:task.problem_statement,protocol:taskProtocol}];
        for (const phase of phases) {
          assert.match(phase.name,/^[a-zA-Z0-9_-]+$/);
          currentPhase = phase.name; phaseCalls = 0; phaseLimit = phase.dispatchLimit ?? dispatchLimit;
          if (phase.resetWorkspace) {git('reset','--hard','HEAD');git('clean','-fdx');}
          const phaseStartedAt=Date.now();
          const id = 'pilot-' + config.instanceId + '-' + phase.name;
          if(config.assetConsumptionOnly) assert.notEqual(id,config.priorTaskLogs?.at(-1)?.sessionId,'Replay must use a fresh native session');
          const protocol=phase.protocol===taskProtocol?phase.protocol+'\n'+taskHistoryGuidance(id,config.priorTaskLogs??[]):phase.protocol;
          let inheritance;
          const parent=config.continuousState?config.priorTaskLogs?.at(-1):undefined;
          if(parent){
            const reader=await ctx.sessionPersistence.open(parent.sessionId,'read');
            try{
              const saved=await reader.read(),last=saved.events.at(-1);
              assert.ok(last && saved.events.filter(e=>e.type==='turn/end').length,'Missing closed parent task');
              const restored=Session.fromRestore(parent.sessionId,saved.events,reader.header,reader.inheritedEventCount,saved.eventState);
              inheritance={seed:buildForkSeed(saved.events,last.seq),inheritedEventCount:saved.events.length,meta:{cwd:'/workspace',parentSession:parent.sessionId,isSeeded:true}};
              durable(dir+'/history-inheritance.json',{parentSessionId:parent.sessionId,inheritedEventCount:saved.events.length,parentLastSeq:last.seq,parentDerivedMessagesSha256:createHash('sha256').update(JSON.stringify([...restored.deriveMessages()])).digest('hex'),parentMessages:[...restored.deriveMessages()].map(m=>({id:m.id,role:m.role,contentSha256:createHash('sha256').update(JSON.stringify(m.content)).digest('hex')})),parentEventsSha256:createHash('sha256').update(JSON.stringify(saved.events)).digest('hex')});
            }finally{await reader.close();}
          }
          const handle = await ctx.agents.create({sessionId:id, meta:{cwd:'/workspace'},...inheritance,
            agentOptions:{provider:config.fixture?'pilot-fixture':'qwen', model:config.fixture?'fixture':'qwen3.8-27b', maxTokens:8192}});
          if(config.fixtureCompact && parent){
            assert.ok(config.fixture && config.continuousState);
            const result=await compaction.compactNow(handle.agent,AbortSignal.timeout(30000));
            assert.ok(result,'Native fixture compaction did not select a useful span');
            durable(dir+'/fixture-compaction.json',result);
          }
          deadline = setTimeout(()=>handle.agent.cancel({kind:'hook',reason:'Pilot wall time limit reached'}),wallTimeMs);
          if(parent)handle.agent.inject(createUserMessage({source:{kind:'benchmark-protocol',form:'source-reset'},content:[{type:'text',text:'当前任务已恢复为本题初始源码。此前工具结果仅属于前序任务；不能将其当作本题当前代码、测试或补丁状态。请以本题问题和当前工具结果为准。'}]}));
          if(protocol)handle.agent.inject(createUserMessage({source:{kind:'benchmark-protocol',form:'instructions'},content:[{type:'text',text:protocol}]}));
          handle.agent.followup(createUserMessage({source:{kind:'user'},content:[{type:'text',text:phase.prompt}]}));
          await handle.agent.whenIdle(); await ctx.sessions.flush(handle.agent.session); clearTimeout(deadline); patch();
          durable(dir + '/prediction-' + phase.name + '.patch',git('diff','--cached','--binary','HEAD'));
          const stored = await ctx.sessionPersistence.open(id,'read');
          const outcome = await stored.read(); await stored.close();
          const stopReason = outcome.events.filter(e=>e.type==='turn/end').at(-1)?.data.reason;
          phaseResults.push({phase:phase.name, sessionId:id, stopReason, startedAt:phaseStartedAt, finishedAt:Date.now(), wallMs:Date.now()-phaseStartedAt, requests:requests.filter(r=>r.sessionId===id).length});
          durable(dir + '/phases.json', phaseResults);
          const end=outcome.events.filter(e=>e.type==='turn/end').at(-1);
          const settled=await waitForLearning({rsi,snapshot,sessionId:id,turn:end.data.turn,endSeq:end.seq,captureExpected:['completed','error','max-tokens','blocked'].includes(end.data.reason.kind),maxWaitMs:config.settleMs ?? 90000,
            persist:(state,progress)=>{durable(dir+'/scheduler.json',state);durable(dir+'/learning-wait.json',progress);}});
          learningSettlements.push(settled);durable(dir+'/learning-settlements.json',learningSettlements);
        }
        const after = await snapshot();
        if (rsi) durable(dir + '/assets.json', await rsi.request('export',{cwd:'/workspace'}));
        // Shutdown first: aborted background calls must settle before final usage and request audit.
        const shutdownStartedAt=Date.now();
        await ctx.root.fiber.dispose();
        const shutdownFinishedAt=Date.now();
        const audit = requests.length?await auditRequests(dir + '/model-requests.json', process.env.DSH_HOME + '/sessions', dir + '/reconstruction.json'):[];
        if(!requests.length)durable(dir+'/reconstruction.json',[]);
        const receipt = {runnerStatus:'COMPLETED', formalBenchmark:!!config.formal, arm:config.arm, fixture:!!config.fixture,
          instanceId:config.instanceId, officialResolved:null, taskDispatches:foreground,
          nativeFiberDisposed:true,shutdownStartedAt,shutdownFinishedAt,
          backgroundDispatches:requests.length-foreground, phases:phaseResults,learningSettlements,
          before, after, blockedDispatches:blocked, learningDispatchLimit:config.learningDispatchLimit, toolResults:results, logReconstructionMatches:requests.length>0,noObservedModelRequests:requests.length===0,
          knownTokens:requests.reduce((n,r)=>n+(r.usage?.totalTokens??0),0),
          unknownUsage:requests.filter(r=>!r.usage).length,
          limitation:config.fixture?'Fixed responses validate runner plumbing; no effectiveness result.':config.formal?'One fixed formal arm; use paired official reports to interpret effect.':'Default-flow pilot; not a formal paired benchmark.'};
        durable(dir + '/receipt.json', receipt);
        console.log(JSON.stringify(receipt)); process.exit(0);
      } catch (error) {
        clearTimeout(deadline);
        try {patch(); ledger(); for (const session of sessions.values()) await ctx.sessions.flush(session);}
        catch (saveError) {durable(dir + '/save-error.json', {error:saveError.message});}
        durable(dir + '/failure.json', {runnerStatus:'ERROR', classification:'UNCLASSIFIED', officialResolved:null,
          error:error.message, phases:phaseResults, observedRequests:requests.length,
          unknownUsage:requests.filter(r=>!r.usage).length});
        console.error(error.stack); process.exit(1);
      }
    },0);
    return ()=>{clearInterval(alive);clearTimeout(timer);clearTimeout(deadline);};
  });
}
