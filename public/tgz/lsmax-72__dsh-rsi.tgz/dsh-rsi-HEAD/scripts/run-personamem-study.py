#!/usr/bin/env python3
"""Coordinate frozen PersonaMem users; all learning stays in the native plugin."""
import argparse,ast,hashlib,json,math,os,random,re,subprocess,sys,time
from datetime import datetime,timezone,timedelta
from pathlib import Path
from personamem_answer_diagnostics import diagnose_answer_format,official_parser_controls

def known_usage(row):
    # An all-zero interrupted adapter receipt is not evidence of free upstream generation.
    value=(row.get('usage') or {}).get('totalTokens')
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>0

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');os.replace(tmp,path)
def grader_from_source(path):
    source=path.read_text();klass=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='Evaluation')
    method=next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name=='extract_answer')
    assert hashlib.sha256(ast.get_source_segment(source,method).encode()).hexdigest()=='a619e9665cc3d12e82de4876843c979cbd3e6e6781a8fe1c184fd697583935ae'
    namespace={'re':re};code=ast.Module(body=[ast.ClassDef(name='Evaluation',bases=[],keywords=[],body=[method],decorator_list=[])],type_ignores=[])
    exec(compile(ast.fix_missing_locations(code),'official-answer-method','exec'),namespace);grader=namespace['Evaluation']()
    for text,key,correct in [('<final_answer>(b)</final_answer>','(b)',True),('<final_answer>(a)</final_answer>','(b)',False),('<final_answer>(a) (b)</final_answer>','(b)',False)]:assert bool(grader.extract_answer(text,key)[0])==correct
    grader.parserHealth=official_parser_controls(grader)
    return grader

STRICT_LEARNING_POLICY='require-complete'
PARTIAL_LEARNING_POLICY='evaluate-closed-bounded-failure'
NATIVE_LEARNING_POLICY='evaluate-closed-native-failure-v2'

def protocol_kind(freeze):
    policy=freeze.get('learningFailurePolicy',STRICT_LEARNING_POLICY)
    assert policy in [STRICT_LEARNING_POLICY,PARTIAL_LEARNING_POLICY,NATIVE_LEARNING_POLICY],'Unknown frozen learning failure policy'
    replication=freeze.get('cohortKind')=='preexposed-development-replication'
    if freeze.get('status')=='FROZEN_PERSONAMEM_REPLICATION':assert replication,'Replication cohort label missing'
    if not replication:assert freeze.get('independenceClaim',True) is True,'Independence declaration contradicts cohort'
    if replication:assert freeze.get('status')=='FROZEN_PERSONAMEM_REPLICATION' and freeze.get('independenceClaim') is False,'Preexposed users cannot be labelled independent'
    return policy,replication

def learning_outcome(folder,receipt,arm,policy,call_limit=None,expected_l0=None):
    # Legacy receipts remain readable under their original strict default.
    if 'learningFailurePolicy' in receipt:assert receipt['learningFailurePolicy']==policy,'Receipt changed frozen learning policy'
    if arm=='baseline':return {'status':'NOT_APPLICABLE','complete':None}
    disposition=receipt.get('learningDisposition')
    if disposition is None:
        assert receipt.get('status')!='COMPLETED' or policy==STRICT_LEARNING_POLICY,'Opt-in answering receipt omitted learning outcome'
        return {'status':'LEGACY_COMPLETED' if receipt.get('status')=='COMPLETED' else 'NOT_COMPLETED_OR_UNKNOWN','complete':True if receipt.get('status')=='COMPLETED' else None}
    assert disposition.get('policy')==policy,'Learning disposition changed frozen policy'
    state=folder/'learning.json';assert state.is_file() and receipt.get('learningStateSha256')==sha(state),'Learning state receipt missing or changed'
    learning=json.loads(state.read_text());assert learning.get('disposition')==disposition,'Learning state/disposition mismatch'
    if policy==NATIVE_LEARNING_POLICY:
        assert learning.get('callLimit')==call_limit and learning.get('expectedL0')==expected_l0,'Gate counters differ from frozen budget/public history'
        native=folder/'native-learning-runs.json';assert native.is_file() and learning.get('nativeEvidenceSha256')==sha(native),'Native failure journals missing/changed'
        background=[r for r in json.loads((folder/'model-requests.json').read_text()) if r['phase']=='learning']
        arguments={'policy':policy,'settled':learning['settled'],'snapshot':learning['snapshot'],'activeCount':learning['activeCount'],'expectedL0':expected_l0,'callLimit':call_limit,'requests':background,'nativeRuns':json.loads(native.read_text())}
        check=subprocess.run(['node',str(Path(__file__).with_name('check-personamem-native-learning.mjs'))],input=json.dumps(arguments),text=True,capture_output=True,timeout=30)
        assert check.returncode==0,'Native learning gate replay rejected: '+check.stderr[-2000:]
        assert json.loads(check.stdout)==disposition,'Native replay/disposition mismatch'
        return disposition
    if disposition.get('status')=='COMPLETED':
        assert disposition.get('complete') is True and learning.get('settled') is True,'Completed learner has no settlement evidence'
    else:
        assert policy==PARTIAL_LEARNING_POLICY and disposition.get('status')=='FAILED_CLOSED_BOUNDED' and disposition.get('complete') is False,'Partial learner requires predeclared opt-in policy'
        assert disposition.get('foregroundMayUseExistingAssets') is True and disposition.get('learningFailureIsNotAnswerScore') is True
        jobs=learning['snapshot']['jobs'];failed=[j for j in jobs if j['status']!='completed']
        assert failed and all(j['status'] in ['failed','paused'] and j.get('stages',{}).get('failure',{}).get('code') in ['ABORTED','BUDGET_EXHAUSTED'] for j in failed),'Non-bounded failure cannot enter opt-in estimate'
        assert [{k:j.get(k) if k!='code' else j['stages']['failure']['code'] for k in ['id','status','code','error']} for j in failed]==disposition['failedJobs'],'Failed-job provenance mismatch'
        requests=json.loads((folder/'model-requests.json').read_text());background=[r for r in requests if r['phase']=='learning']
        assert background and all(r.get('status') in ['RETURNED','ERROR','INCOMPLETE'] for r in background),'Partial learner ledger is not closed'
        if any(j['stages']['failure']['code']=='BUDGET_EXHAUSTED' for j in failed):
            blocked=json.loads((folder/'blocked-dispatches.json').read_text());assert any(r['reason']=='EXPERIMENT_CALL_CAP' for r in blocked),'No actual cap-stop receipt'
    return disposition

def summarize(root,freeze,scorer,official_source):
    # Offline only. Scores and keys are never passed to probe-runner or any Agent.
    diagnostic_digest=sha(Path(diagnose_answer_format.__code__.co_filename))
    if (root/'results.json').exists():
        previous=json.loads((root/'results.json').read_text())
        assert previous.get('reporterScriptSha256')==sha(Path(__file__)) and previous.get('answerDiagnosticsModuleSha256')==diagnostic_digest,'Saved report has a different reporter/diagnostic revision; preserve it and write a separate audit'
    for path,digest in freeze['scorerInputSha256'].items():assert sha(Path(path))==digest
    policy,replication=protocol_kind(freeze)
    grader=grader_from_source(official_source);keys=json.loads((scorer/'answers.json').read_text());users=[];total=0;unknown=0
    records=json.loads((root/'runs.json').read_text()) if (root/'runs.json').exists() else []
    for case in freeze['cases']:
        user={'personaId':case['personaId'],'arms':[]};histories=[];time_contexts=[]
        for arm in ['baseline','rsi']:
            out=root/('persona-'+case['personaId']+'-'+arm);folder=out/'state/pilot'/('persona-'+case['personaId'])
            record=next((r for r in records if r['personaId']==case['personaId'] and r['arm']==arm),None)
            if not record:continue
            requests=json.loads((folder/'model-requests.json').read_text()) if (folder/'model-requests.json').exists() else []
            wire=[json.loads(l) for l in (out/'gateway.log').read_text().splitlines() if l.strip()] if (out/'gateway.log').exists() else []
            sent=[r for r in wire if r.get('request') and r.get('model')]
            assert len(sent)==len(requests),'Gateway/native ledger mismatch; withhold paired result'
            assert all(r['enableThinking'] is False and 'developer' not in r['messageRoles'] for r in sent)
            rows=json.loads((folder/'answers.json').read_text()) if (folder/'answers.json').exists() else []
            assert len({q['questionId'] for q in rows})==len(rows) and all(q['questionId'] in case['questionIds'] for q in rows)
            scores=[{'questionId':q['questionId'],'correct':bool(grader.extract_answer(q['response'],keys[q['questionId']])[0]),'formatDiagnostic':diagnose_answer_format(q['response']),'completed':(q.get('stopReason') or {}).get('kind')=='completed','answerAvailable':bool(q['response'].strip()),'responseSha256':hashlib.sha256(q['response'].encode()).hexdigest()} for q in rows]
            receipt=json.loads((folder/'receipt.json').read_text()) if (folder/'receipt.json').exists() else {}
            if receipt:assert not receipt.get('fixture') and receipt.get('formalPersonaMemEvaluation'),'Only real frozen PersonaMem runs may enter the report'
            expected_l0=None
            if policy==NATIVE_LEARNING_POLICY and arm=='rsi':
                public=root/'public'/('persona-'+case['personaId']+'.json');assert public.is_file() and sha(public)==case['publicInputSha256'],'Frozen public source missing/changed'
                expected_l0=sum(m['role'] in ['user','assistant'] for m in json.loads(public.read_text())['history'])
            learning=learning_outcome(folder,receipt,arm,policy,freeze.get('budgets',{}).get('backgroundCallsPerUser'),expected_l0)
            historical_time_status=None
            if receipt and freeze.get('requiresCommonHistoricalTimeNote'):
                # A failed learner has not constructed an answering request. Require the
                # note for every answered arm, but preserve pre-answer failure costs.
                pre_answer_failure=(receipt.get('status')=='ERROR' and not rows
                    and receipt.get('foregroundRequests')==0
                    and all(r['phase']=='learning' for r in requests))
                if pre_answer_failure:
                    historical_time_status='NOT_REACHED_PREANSWER_FAILURE'
                else:
                    assert receipt.get('commonHistoricalTimeNote') is True and receipt.get('historicalContextSha256'),'Common history time context missing'
                    time_contexts.append(receipt['historicalContextSha256'])
                    historical_time_status='VERIFIED_BY_ANSWERING_RECEIPT'
            known=sum(r['usage']['totalTokens'] for r in requests if known_usage(r));missing=sum(not known_usage(r) for r in requests);total+=known;unknown+=missing
            if (folder/'import.json').exists():histories.append(json.loads((folder/'import.json').read_text())['historySha256'])
            user['arms'].append({'arm':arm,'runnerReturnCode':record.get('returncode'),'runnerStatus':receipt.get('status'),'scores':scores,'accuracy':sum(q['correct'] for q in scores)/len(scores) if len(scores)==freeze['questionCountPerUser'] else None,'knownTokens':known,'unknownActualUsage':missing,'foregroundTokens':sum(r['usage']['totalTokens'] for r in requests if known_usage(r) and r['phase']!='learning'),'backgroundTokens':sum(r['usage']['totalTokens'] for r in requests if known_usage(r) and r['phase']=='learning'),'gatewayLedgerMatches':True,'historicalTimeContextStatus':historical_time_status,'runnerError':receipt.get('error'),'runnerClassification':receipt.get('classification'),'learningDisposition':learning})
        assert len(set(histories))<=1,'Paired user history changed'
        assert len(set(time_contexts))<=1,'Paired historical time context changed'
        users.append(user)
    complete=all(len(u['arms'])==2 and all(a['accuracy'] is not None and a['runnerReturnCode']==0 and a['runnerStatus']=='COMPLETED' for a in u['arms']) for u in users)
    result={'cohortKind':freeze.get('cohortKind','originally-selected-independent-users'),'populationProvenance':freeze.get('populationProvenance'),'independenceClaim':not replication,'learningFailurePolicy':policy,'completedLearners':sum(a['learningDisposition']['complete'] is True for u in users for a in u['arms'] if a['arm']=='rsi'),'closedBoundedFailedLearners':sum(a['learningDisposition']['status']=='FAILED_CLOSED_BOUNDED' for u in users for a in u['arms'] if a['arm']=='rsi'),'status':('COMPLETE_PREEXPOSED_SAVED_RESULTS' if replication else 'COMPLETE_INDEPENDENT_SAVED_RESULTS') if complete else 'INCOMPLETE_WITHHOLD_FULL_PAIRED_ESTIMATE','users':users,'plannedUsers':len(users),'knownTokens':total,'unknownActualUsage':unknown,'officialScorerControlsPassed':3,'officialParserDiagnostics':grader.parserHealth,'requiredFormatFailures':sum(not q['formatDiagnostic']['valid'] for u in users for a in u['arms'] for q in a['scores']),'reportedAccuracyMethod':'PINNED_OFFICIAL_EXTRACT_ANSWER_UNCHANGED','scoresReturnedToLearning':False,'smallSampleLimit':'Eight correlated user clusters; not the full benchmark or a universal causal guarantee.','baselineMacroAccuracy':None,'rsiMacroAccuracy':None,'pairedAccuracyDifference':None,'userClusterBootstrap95':None,'bootstrapDraws':0,'reporterScriptSha256':sha(Path(__file__)),'answerDiagnosticsModuleSha256':diagnostic_digest}
    if complete:
        delta=[u['arms'][1]['accuracy']-u['arms'][0]['accuracy'] for u in users];rng=random.Random(freeze['selectionSeed']);boot=sorted(sum(rng.choices(delta,k=len(delta)))/len(delta) for _ in range(10000))
        result.update(baselineMacroAccuracy=sum(u['arms'][0]['accuracy'] for u in users)/len(users),rsiMacroAccuracy=sum(u['arms'][1]['accuracy'] for u in users)/len(users),pairedAccuracyDifference=sum(delta)/len(delta),userClusterBootstrap95=[boot[249],boot[9749]],bootstrapDraws=10000)
    write(root/'results.json',result);return result

def utc_day_headroom(now):
    assert now.tzinfo is not None
    now=now.astimezone(timezone.utc)
    return ((now+timedelta(days=1)).replace(hour=0,minute=0,second=0,microsecond=0)-now).total_seconds()

def wait_for_learning_day(root,instance,freeze):
    # Wait before recording or dispatching an arm; learning keeps its original budget.
    if freeze.get('learningFailurePolicy')!=NATIVE_LEARNING_POLICY:return
    required=freeze['budgets']['learningWallSecondsPerUser']+300
    while True:
        now=datetime.now(timezone.utc);remaining=utc_day_headroom(now)
        if remaining>=required:return
        notice={'status':'WAITING_BEFORE_DISPATCH_FOR_UTC_DAY','observedAt':now.isoformat(),'requiredHeadroomSeconds':required,'remainingDaySeconds':remaining,'realModelRequests':0}
        write(root/(instance+'-utc-day-wait.json'),notice);print(json.dumps(notice),flush=True)
        time.sleep(min(60,remaining+1))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--proposal',type=Path,required=True);p.add_argument('--public',type=Path,required=True);p.add_argument('--scorer',type=Path,required=True);p.add_argument('--official-source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--image',default='dsh-rsi-formal:django__django-11119');p.add_argument('--freeze-only',action='store_true');p.add_argument('--resume',action='store_true');p.add_argument('--report-only',action='store_true');args=p.parse_args()
    project=Path(__file__).resolve().parent.parent;root=args.output.resolve();root.mkdir(parents=True,exist_ok=True);frozen=root/'freeze.json'
    if not frozen.exists():
        assert args.freeze_only,'Freeze the concrete protocol before the first independent dispatch'
        assert not any(root.iterdir()),'Preserve every previous attempt'
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=project,text=True).strip()
        assert os.environ.get('RSI_MODEL_UPSTREAM'),'Use the authorized model service'
        proposal=json.loads(args.proposal.read_text());persona=proposal['persona'];assert len(persona['cases'])==8 and persona['questionCountPerUser']==4
        cohort=proposal.get('cohortKind','originally-selected-independent-users');replication=cohort=='preexposed-development-replication'
        policy=proposal.get('learningFailurePolicy',STRICT_LEARNING_POLICY)
        assert policy in [STRICT_LEARNING_POLICY,PARTIAL_LEARNING_POLICY,NATIVE_LEARNING_POLICY]
        if replication:assert proposal.get('independenceClaim') is False,'Declare known exposure explicitly'
        grader_from_source(args.official_source)
        hashes={str(f.relative_to(project)):sha(f) for name in ['src','adapters','vendor','lib','scripts'] for f in sorted((project/name).rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.suffix not in ['.pyc','.pyo']}
        for name in ['package.json','package-lock.json','cordis.patch.yml']:hashes[name]=sha(project/name)
        public_root=root/'public';public_root.mkdir()
        for case in persona['cases']:
            source=args.public/('persona-'+case['personaId']+'.json');assert sha(source)==case['publicInputSha256']
            (public_root/source.name).write_bytes(source.read_bytes())
        freeze={'status':'FROZEN_PERSONAMEM_REPLICATION' if replication else 'FROZEN_INDEPENDENT_PERSONAMEM','independenceClaim':not replication,'learningFailurePolicy':policy,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),'inputSha256':hashes,'model':proposal['model'],'upstreamSha256':hashlib.sha256(os.environ['RSI_MODEL_UPSTREAM'].encode()).hexdigest(),'taskImageId':subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',args.image],text=True).strip(),'taskTag':args.image,'selectionSeed':proposal['selectionSeed'],'questionCountPerUser':persona['questionCountPerUser'],'cases':persona['cases'],'budgets':persona['budgetProposal'],'sourceProposalSha256':sha(args.proposal),'populationProvenance':proposal.get('supersedesForNewDispatchOnly'),'cohortKind':proposal.get('cohortKind','originally-selected-independent-users'),'requiresCommonHistoricalTimeNote':persona.get('sameHistoricalTimeExplanationBothArms',False),'datasetProvenance':proposal.get('datasetProvenance'),'scorerInputSha256':{str(f.resolve()):sha(f) for f in [args.scorer/'answers.json',args.official_source]},'frozenAt':datetime.now(timezone.utc).isoformat(),'diagnosticSampling':'For each user, first two preselected questions and first four delivered Memory references per question. Label direct/partial/unrelated, source attribution and answer correspondence without feeding scores back. All body lengths and request occurrences counted automatically.', 'retryPolicy':'No automatic retry, budget expansion, rescue learning or answer feedback. '+('Only verified closed ABORTED or recorded call-cap failures may answer with existing assets; v2 additionally replays native journals and quota receipts; live, unclassified, capture and infrastructure failures stop scale-out.' if policy in [PARTIAL_LEARNING_POLICY,NATIVE_LEARNING_POLICY] else 'Stop scale-out on incomplete native learning.'),'armsByUser':{c['personaId']:['baseline','rsi'] if i%2==0 else ['rsi','baseline'] for i,c in enumerate(persona['cases'])}}
        write(frozen,freeze)
    freeze=json.loads(frozen.read_text())
    if args.report_only:print(json.dumps(summarize(root,freeze,args.scorer,args.official_source)));return
    if args.freeze_only:print(json.dumps({'status':freeze['status'],'freezeSha256':sha(frozen),'realModelRequests':0}));return
    records=json.loads((root/'runs.json').read_text()) if (root/'runs.json').exists() else []
    assert args.resume or not records,'Use resume only for terminal preserved arms, never silently retry'
    assert all(r.get('returncode')==0 and r.get('status')=='CLOSED' for r in records),'Incomplete/ambiguous attempts require a separate audit; no automatic retry'
    for case in freeze['cases']:
        persona=case['personaId'];instance='persona-'+persona
        for arm in freeze['armsByUser'][persona]:
            if any(r['personaId']==persona and r['arm']==arm for r in records):continue
            out=root/(instance+'-'+arm);b=freeze['budgets'];learning=b['backgroundCallsPerUser'] if arm=='rsi' else 0
            argv=[sys.executable,'-B',str(project/'scripts/probe-runner.py'),'--persona-protocol',str(frozen),'--persona-input',str(root/'public'/(instance+'.json')),'--image',freeze['taskTag'],'--arm',arm,'--instance',instance,'--output',str(out),'--dispatch-limit',str(b['foregroundCallsPerQuestion']),'--request-limit',str(learning+freeze['questionCountPerUser']*b['foregroundCallsPerQuestion']),'--learning-call-budget',str(b['backgroundCallsPerUser']),'--learning-dispatch-limit',str(learning),'--wall-seconds',str(b['wallSecondsPerQuestion']),'--settle-seconds',str(b['learningWallSecondsPerUser'])]
            if arm=='rsi':wait_for_learning_day(root,instance,freeze)
            record={'personaId':persona,'arm':arm,'status':'RUNNING','runDir':str(out),'startedAt':datetime.now(timezone.utc).isoformat()};records.append(record);write(root/'runs.json',records);print(json.dumps(record),flush=True)
            with (root/(out.name+'.runner.log')).open('w') as log:code=subprocess.run(argv,cwd=project,stdout=log,stderr=subprocess.STDOUT).returncode
            record.update(status='CLOSED',returncode=code,finishedAt=datetime.now(timezone.utc).isoformat());write(root/'runs.json',records)
            print(json.dumps(record),flush=True)
            if code:
                summarize(root,freeze,args.scorer,args.official_source);raise SystemExit('Stop scale-out: inspect the preserved failure; no unplanned recovery or retry.')
            if arm=='rsi':
                subprocess.run([sys.executable,'-B',str(project/'scripts/personamem-diagnostics.py'),'--run',str(out),'--instance',instance,'--output',str(out/'diagnostics.json')],cwd=project,check=True,stdout=subprocess.DEVNULL)
    print(json.dumps(summarize(root,freeze,args.scorer,args.official_source)),flush=True)
if __name__=='__main__':main()
