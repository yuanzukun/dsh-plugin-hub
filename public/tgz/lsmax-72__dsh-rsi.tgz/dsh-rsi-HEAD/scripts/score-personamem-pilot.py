#!/usr/bin/env python3
"""Grade saved answers with the pinned official method; never invoke a model or learner."""
import argparse,ast,hashlib,json,re
from pathlib import Path
from personamem_answer_diagnostics import diagnose_answer_format
def grade_saved_answer(grader,row,answer):
    # Correctness follows the official answer method; native termination is a separate health signal.
    correct,_=grader.extract_answer(row['response'],answer)
    reason=row.get('stopReason') or {}
    return {'correct':bool(correct),'formatDiagnostic':diagnose_answer_format(row['response']),'completed':reason.get('kind')=='completed','answerAvailable':bool(row['response'].strip()),'stopReason':row.get('stopReason')}

p=argparse.ArgumentParser();p.add_argument('--experiment',type=Path,required=True);p.add_argument('--scorer',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--instance',default='persona-0');p.add_argument('--rsi-dir',default='rsi');args=p.parse_args()
if args.output.exists():p.error('Preserve previous scores; choose an unused output path')
raw=args.scorer/'raw';provenance=json.loads((raw/'provenance.json').read_text());source=(raw/'inference_standalone_openai.py').read_text();assert hashlib.sha256(source.encode()).hexdigest()==provenance['files']['inference_standalone_openai.py']['sha256']
tree=ast.parse(source);klass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Evaluation');method=next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name=='extract_answer');assert hashlib.sha256(ast.get_source_segment(source,method).encode()).hexdigest()=='a619e9665cc3d12e82de4876843c979cbd3e6e6781a8fe1c184fd697583935ae'
# Compile only the unchanged official grading method; upstream client imports are never executed.
namespace={'re':re};code=ast.Module(body=[ast.ClassDef(name='Evaluation',bases=[],keywords=[],body=[method],decorator_list=[])],type_ignores=[]);exec(compile(ast.fix_missing_locations(code),'official-answer-method','exec'),namespace);grader=namespace['Evaluation']()
for response,key,expected in [('<final_answer>(b)</final_answer>','(b)',True),('<final_answer>(a)</final_answer>','(b)',False),('<final_answer>(a) (b)</final_answer>','(b)',False)]:assert grader.extract_answer(response,key)[0] is expected
keys=json.loads((args.scorer/'answers.json').read_text());arms=[]
for arm in ['baseline','rsi']:
 root=args.experiment/(args.rsi_dir if arm=='rsi' else arm);folder=root/'state/pilot'/args.instance;receipt=json.loads((folder/'receipt.json').read_text());assert not receipt.get('fixture',False)
 requests=json.loads((folder/'model-requests.json').read_text());wire=[json.loads(l) for l in (root/'gateway.log').read_text().splitlines() if l.strip()];assert len([r for r in wire if r.get('request') and r.get('model')])==len(requests)
 observed=json.loads((folder/'answers.json').read_text()) if (folder/'answers.json').exists() else [];scores=[]
 for row in observed:
  grade=grade_saved_answer(grader,row,keys[row['questionId']]);scores.append({'questionId':row['questionId'],**grade,'knownTokens':sum(r['usage']['totalTokens'] for r in requests if r['sessionId']==row['sessionId'] and r['usage']),'responseSha256':hashlib.sha256(row['response'].encode()).hexdigest(),'allHistoricalTextPresent':row['allHistoricalTextPresent']})
 imported=json.loads((folder/'import.json').read_text());learning=json.loads((folder/'learning.json').read_text()) if (folder/'learning.json').exists() else None
 row={'arm':arm,'runnerStatus':receipt['status'],'questionScores':scores,'answered':len(scores),'expectedQuestions':len(keys),'normallyCompletedQuestions':sum(q['completed'] for q in scores),'accuracy':sum(q['correct'] for q in scores)/len(scores) if len(scores)==len(keys) else None,'learningFailureCodes':[j['stages'].get('failure',{}).get('code') for j in learning['snapshot']['jobs'] if j['status']!='completed'] if learning else [],'historySha256':imported['historySha256'],'cutoff':imported['cutoff'],'foregroundRequests':receipt['foregroundRequests'],'learningRequests':receipt['learningRequests'],'foregroundTokens':sum(r['usage']['totalTokens'] for r in requests if r['phase']!='learning' and r['usage']),'learningTokens':sum(r['usage']['totalTokens'] for r in requests if r['phase']=='learning' and r['usage']),'knownTokens':sum(r['usage']['totalTokens'] for r in requests if r['usage']),'unknownActualRequestUsage':sum(r['usage'] is None for r in requests),'gatewayLedgerMatches':True,'scorerResultsReturnedToLearning':False};arms.append(row)
assert arms[0]['historySha256']==arms[1]['historySha256'] and arms[0]['cutoff']==arms[1]['cutoff'];r={'status':'DEVELOPMENT_PILOT_ONLY','users':1,'arms':arms,'knownTokensTotal':sum(a['knownTokens'] for a in arms),'sameFullHistoryBothArms':True,'officialScorerControlsPassed':3,'scorerOnlyAnswers':True,'confidenceInterval':None,'reasonNoInterval':'One development user; correlated questions. Native learning failures are not wrong answers or zero accuracy. Future intervals cluster by user.','independentEffectClaim':False};args.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
