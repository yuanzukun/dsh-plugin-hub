/**
 * dsh-code-review 插件,node 半(宿主侧)。
 *
 * 职责:给宿主 Web 服务器注册一个「本地 diff 文件读取」路由,供浏览器半
 * 的「路径查看 chip」点击时读取会话里出现的本地路径指向的 .diff/.patch
 * 文件内容(浏览器无法直接读本地文件,必须由宿主代读)。
 *
 * 安全边界(只读本地 diff 文件,最小暴露面):
 * - 仅 GET;路径必须绝对(支持 ~ 展开)、且以 .diff/.patch 结尾;
 * - 文件必须存在、是普通文件、大小 ≤ 5MB;
 * - 只返回 JSON 文本内容,不设 CORS(任何跨源页面都读不到响应体);
 * - 响应 no-store,不落任何缓存。
 *
 * 路由注册与 webServer 就绪解耦:用 ctx.inject 延迟到服务可用时执行,
 * webServer 缺失的装配(如 headless)里回调不执行,插件行本身不报错。
 */
import { stat, readFile } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { homedir } from 'node:os'
import { isAbsolute, join, resolve } from 'node:path'

/** 浏览器半请求的固定路由路径(与插件 bundle 路径 /plugins/* 不冲突)。 */
export const DIFF_ROUTE_PATH = '/dsh-code-review/diff'
/** 单文件读取上限(5MB,防误点超大文件拖垮宿主)。 */
export const MAX_DIFF_BYTES = 5 * 1024 * 1024

// —— 最小上下文形状(只取用到的 cordis 成员,不引入官方类型依赖)——

/** webServer 服务的最小形状(register 注册命名路由)。 */
export interface WebServerLike {
  register(route: {
    kind: 'exact'
    path: string
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>
  }): () => void
}

/** 插件 apply 收到的宿主上下文最小形状(cordis Context 结构兼容)。 */
export interface CodeReviewCtx {
  /** 服务可用时执行回调(webServer 缺失时回调不执行,不阻塞插件)。 */
  inject(
    deps: readonly string[],
    callback: (ctx: CodeReviewCtx & { webServer: WebServerLike }) => unknown,
  ): unknown
  /** 注册一个作用域 effect,返回的 disposer 在插件卸载时执行。 */
  effect(fn: () => void | (() => void), name?: string): unknown
}

// —— 本地 diff 文件读取(纯函数,单测覆盖)——

/** 路径解析失败的原因(供测试与错误响应使用)。 */
export type DiffLoadError = 'invalid-path' | 'not-found' | 'not-file' | 'too-large' | 'read-error'

/** loadDiffText 的返回:成功带文本;失败带原因与 HTTP 状态码。 */
export type DiffLoadResult =
  | { ok: true; text: string }
  | { ok: false; error: DiffLoadError; status: number }

/**
 * 校验并规范化浏览器传来的路径字符串。
 *
 * 规则:trim 后必须非空、不含 NUL;支持 `~` 前缀展开为 home 目录;
 * 展开后必须是绝对路径且以 .diff/.patch 结尾(大小写不敏感)。
 * 返回规范化后的绝对路径,不合法返回 null。不触盘。
 */
export function resolveDiffPath(raw: string): string | null {
  let p = raw.trim()
  if (p === '' || p.includes('\0')) return null
  if (p.startsWith('~/')) p = join(homedir(), p.slice(2))
  if (!isAbsolute(p)) return null
  if (!/\.(?:diff|patch)$/i.test(p)) return null
  return resolve(p)
}

/**
 * 读取一个已校验的本地 diff 文件内容(UTF-8)。
 * 失败原因映射:不存在/解引用失败 → not-found;不是普通文件 → not-file;
 * 超过大小上限 → too-large;其他 IO 错误 → read-error。
 */
export async function loadDiffText(absPath: string): Promise<DiffLoadResult> {
  try {
    const st = await stat(absPath)
    if (!st.isFile()) return { ok: false, error: 'not-file', status: 400 }
    if (st.size > MAX_DIFF_BYTES) return { ok: false, error: 'too-large', status: 413 }
    const text = await readFile(absPath, 'utf8')
    return { ok: true, text }
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT' || (err as NodeJS.ErrnoException).code === 'ENOTDIR') {
      return { ok: false, error: 'not-found', status: 404 }
    }
    return { ok: false, error: 'read-error', status: 500 }
  }
}

/** 发送 JSON 响应(统一头:no-store + nosniff,不设 CORS)。 */
function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  })
  res.end(payload)
}

/**
 * 路由处理器:解析 ?path= 参数 → 校验 → 读文件 → 返回
 * { ok: true, text } 或 { ok: false, error }。
 */
async function handleDiffRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
    return
  }
  let raw = ''
  try {
    raw = new URL(req.url ?? '/', 'http://localhost').searchParams.get('path') ?? ''
  } catch {
    sendJson(res, 400, { ok: false, error: 'invalid-path' })
    return
  }
  const abs = resolveDiffPath(raw)
  if (abs === null) {
    sendJson(res, 400, { ok: false, error: 'invalid-path' })
    return
  }
  const result = await loadDiffText(abs)
  if (!result.ok) {
    sendJson(res, result.status, { ok: false, error: result.error })
    return
  }
  sendJson(res, 200, { ok: true, text: result.text })
}

/**
 * 插件 apply:注册本地 diff 文件读取路由。webServer 可用时执行;
 * 缺失时静默跳过(回调不执行),浏览器半的路径 chip 会显示读取失败。
 */
export function apply(ctx: CodeReviewCtx): void {
  ctx.inject(['webServer'], (srv) => {
    srv.effect(() => {
      // register 返回 disposer;插件卸载/HMR 重载时自动摘除路由。
      const unregister = srv.webServer.register({
        kind: 'exact',
        path: DIFF_ROUTE_PATH,
        handler: handleDiffRequest,
      })
      return unregister
    }, `dsh-code-review: ${DIFF_ROUTE_PATH} diff file route`)
  })
}
