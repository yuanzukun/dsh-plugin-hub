/**
 * dsh-code-review 插件,node 半(宿主侧)。
 *
 * 职责(两个路由):
 * 1. 「本地 diff 文件读取」GET /dsh-code-review/diff:浏览器半的「路径
 *    查看 chip」点击时读取会话里出现的本地路径指向的 .diff/.patch 文件
 *    内容(浏览器无法直接读本地文件,必须由宿主代读)。
 * 2. 「AI 审查暂存」POST /dsh-code-review/ai-review:浏览器半「AI 审查」
 *    按钮点击时,把会话里的 diff 文本暂存为临时文件并返回绝对路径 ——
 *    主 agent 随后创建干净上下文的 sub agent,把该路径写进任务说明,
 *    sub agent 直接读文件拿 diff(prompt 短小,主对话上下文不被大
 *    diff 污染;diff 不内联进用户消息,也就不经过 composer 的
 *    引用/@ 解析)。
 *
 * 安全边界(最小暴露面):
 * - GET 仅读:路径必须绝对(支持 ~ 展开)、且以 .diff/.patch 结尾;
 *   文件必须存在、是普通文件、大小 ≤ 5MB;
 * - POST 仅写自有临时目录:内容必须形似 git diff、大小 ≤ 5MB、目录内
 *   文件数有上限,文件名服务端生成(调用方不可控路径),0600 权限,
 *   过期(24h)自动清理;
 * - 只收发 JSON,不设 CORS(任何跨源页面都读不到响应体);
 * - 响应 no-store,不落任何缓存。
 *
 * 路由注册与 webServer 就绪解耦:用 ctx.inject 延迟到服务可用时执行,
 * webServer 缺失的装配(如 headless)里回调不执行,插件行本身不报错。
 */
import { randomBytes } from 'node:crypto'
import { mkdir, readdir, readFile, stat, unlink, writeFile } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { homedir, tmpdir } from 'node:os'
import { isAbsolute, join, resolve } from 'node:path'

/** 浏览器半请求的固定路由路径(与插件 bundle 路径 /plugins/* 不冲突)。 */
export const DIFF_ROUTE_PATH = '/dsh-code-review/diff'
/** AI 审查暂存路由:POST diff 文本,返回暂存文件绝对路径。 */
export const AI_REVIEW_ROUTE_PATH = '/dsh-code-review/ai-review'
/** 单文件读取上限(5MB,防误点超大文件拖垮宿主)。 */
export const MAX_DIFF_BYTES = 5 * 1024 * 1024
/** AI 审查暂存目录内的文件数上限(防刷接口写满磁盘)。 */
export const MAX_REVIEW_FILES = 1000
/** AI 审查暂存文件的保留时长(超过即随下次写入清理)。 */
export const REVIEW_FILE_TTL_MS = 24 * 60 * 60 * 1000
/** 暂存文件名前缀(清理时只匹配本插件命名约定的文件)。 */
const REVIEW_FILE_PREFIX = 'review-'

// —— 最小上下文形状(只取用到的 cordis 成员,不引入官方类型依赖)——

/** webServer 服务的最小形状(register 注册命名路由)。 */
export interface WebServerLike {
  register(route: {
    kind: 'exact'
    path: string
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>
  }): () => void
}

/** 插件 apply 收到的宿主上下文最小形状(cordis Context 结构兼容)。 */
export interface CodeReviewCtx {
  /** 服务可用时执行回调(webServer 缺失时回调不执行,不阻塞插件)。 */
  inject(
    deps: readonly string[],
    callback: (ctx: CodeReviewCtx & { webServer: WebServerLike }) => unknown,
  ): unknown
  /** 注册一个作用域 effect,返回的 disposer 在插件卸载时执行。 */
  effect(fn: () => void | (() => void), name?: string): unknown
}

// —— 本地 diff 文件读取(纯函数,单测覆盖)——

/** 路径解析失败的原因(供测试与错误响应使用)。 */
export type DiffLoadError = 'invalid-path' | 'not-found' | 'not-file' | 'too-large' | 'read-error'

/** loadDiffText 的返回:成功带文本;失败带原因与 HTTP 状态码。 */
export type DiffLoadResult =
  | { ok: true; text: string }
  | { ok: false; error: DiffLoadError; status: number }

/**
 * 校验并规范化浏览器传来的路径字符串。
 *
 * 规则:trim 后必须非空、不含 NUL;支持 `~` 前缀展开为 home 目录;
 * 展开后必须是绝对路径且以 .diff/.patch 结尾(大小写不敏感)。
 * 返回规范化后的绝对路径,不合法返回 null。不触盘。
 */
export function resolveDiffPath(raw: string): string | null {
  let p = raw.trim()
  if (p === '' || p.includes('\0')) return null
  if (p.startsWith('~/')) p = join(homedir(), p.slice(2))
  if (!isAbsolute(p)) return null
  if (!/\.(?:diff|patch)$/i.test(p)) return null
  return resolve(p)
}

/**
 * 读取一个已校验的本地 diff 文件内容(UTF-8)。
 * 失败原因映射:不存在/解引用失败 → not-found;不是普通文件 → not-file;
 * 超过大小上限 → too-large;其他 IO 错误 → read-error。
 */
export async function loadDiffText(absPath: string): Promise<DiffLoadResult> {
  try {
    const st = await stat(absPath)
    if (!st.isFile()) return { ok: false, error: 'not-file', status: 400 }
    if (st.size > MAX_DIFF_BYTES) return { ok: false, error: 'too-large', status: 413 }
    const text = await readFile(absPath, 'utf8')
    return { ok: true, text }
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT' || (err as NodeJS.ErrnoException).code === 'ENOTDIR') {
      return { ok: false, error: 'not-found', status: 404 }
    }
    return { ok: false, error: 'read-error', status: 500 }
  }
}

/** 发送 JSON 响应(统一头:no-store + nosniff,不设 CORS)。 */
function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  })
  res.end(payload)
}

/**
 * 路由处理器:解析 ?path= 参数 → 校验 → 读文件 → 返回
 * { ok: true, text } 或 { ok: false, error }。
 */
async function handleDiffRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
    return
  }
  let raw = ''
  try {
    raw = new URL(req.url ?? '/', 'http://localhost').searchParams.get('path') ?? ''
  } catch {
    sendJson(res, 400, { ok: false, error: 'invalid-path' })
    return
  }
  const abs = resolveDiffPath(raw)
  if (abs === null) {
    sendJson(res, 400, { ok: false, error: 'invalid-path' })
    return
  }
  const result = await loadDiffText(abs)
  if (!result.ok) {
    sendJson(res, result.status, { ok: false, error: result.error })
    return
  }
  sendJson(res, 200, { ok: true, text: result.text })
}

// —— AI 审查暂存(纯函数 + IO,单测覆盖)——

/**
 * 文本是否形似 git diff(服务端入口校验)。
 *
 * 判定口径与浏览器半 diff-parse.ts 的 isDiffText 完全一致(从源码抄,
 * 不凭印象写):有 `diff --git ` 头即真;否则要求「hunk 头 + 文件标记」
 * 同时出现。POST 是网络入口,不能信任客户端已经校验过。
 */
export function looksLikeDiffText(text: string): boolean {
  const lines = text.split('\n')
  if (lines.some((line) => line.startsWith('diff --git '))) return true
  const hasHunk = lines.some((line) => /^@@ -\d+/.test(line))
  const hasFileMark = lines.some((line) => /^(---|\+\+\+) \S/.test(line))
  return hasHunk && hasFileMark
}

/** AI 审查暂存目录(系统临时目录下的自有子目录)。 */
function reviewDir(): string {
  return join(tmpdir(), 'dsh-code-review')
}

/**
 * 清理暂存目录里过期的 review 文件(mtime 超过 TTL)。
 * 逐个独立 try/catch:单个文件删除失败(如并发删除竞态)不影响其余。
 * 只匹配本插件的命名前缀,绝不触碰目录里其他来源的文件。
 */
async function pruneReviewFiles(): Promise<void> {
  const dir = reviewDir()
  const entries = await readdir(dir).catch(() => [] as string[])
  const cutoff = Date.now() - REVIEW_FILE_TTL_MS
  await Promise.all(entries.map(async (name) => {
    if (!name.startsWith(REVIEW_FILE_PREFIX) || !name.endsWith('.diff')) return
    try {
      const st = await stat(join(dir, name))
      if (st.mtimeMs < cutoff) await unlink(join(dir, name))
    } catch {
      // 文件消失/不可 stat:无需处理(过期清理是尽力而为)。
    }
  }))
}

/** saveReviewDiff 的失败原因(供测试与错误响应使用)。 */
export type ReviewSaveError = 'empty-text' | 'not-a-diff' | 'too-large' | 'too-many-files' | 'write-error'

/** saveReviewDiff 的返回:成功带暂存路径;失败带原因与 HTTP 状态码。 */
export type ReviewSaveResult =
  | { ok: true; path: string }
  | { ok: false; error: ReviewSaveError; status: number }

/**
 * 校验并把 diff 文本暂存为临时文件,返回绝对路径。
 *
 * 文件名服务端生成(时间戳 + 随机后缀),调用方不能指定路径;权限 0600。
 * 写入前先做过期清理并检查文件数上限(防接口被刷写满磁盘)。
 */
export async function saveReviewDiff(text: string): Promise<ReviewSaveResult> {
  if (text.trim() === '') return { ok: false, error: 'empty-text', status: 400 }
  if (Buffer.byteLength(text, 'utf8') > MAX_DIFF_BYTES) return { ok: false, error: 'too-large', status: 413 }
  if (!looksLikeDiffText(text)) return { ok: false, error: 'not-a-diff', status: 400 }
  try {
    const dir = reviewDir()
    // 0700:目录归宿主进程用户私有,其他系统用户不可列举/读写。
    await mkdir(dir, { recursive: true, mode: 0o700 })
    await pruneReviewFiles()
    const entries = await readdir(dir)
    const count = entries.filter((name) => name.startsWith(REVIEW_FILE_PREFIX) && name.endsWith('.diff')).length
    if (count >= MAX_REVIEW_FILES) return { ok: false, error: 'too-many-files', status: 429 }
    const path = join(dir, `${REVIEW_FILE_PREFIX}${Date.now()}-${randomBytes(5).toString('hex')}.diff`)
    await writeFile(path, text, { mode: 0o600 })
    return { ok: true, path }
  } catch (err) {
    console.warn('[dsh-code-review] AI 审查暂存写入失败:', err)
    return { ok: false, error: 'write-error', status: 500 }
  }
}

/**
 * 读取请求体(JSON),带字节上限:
 * Content-Length 预检 + 流式累计双重限制,超限即断开并返回 413,
 * 防止恶意/异常的大请求体占内存。
 * 客户端中途断开时 node 只保证发 'close'(不保证 'error'),补上
 * close 兜底让 promise 必然 settle(finish 有 settled 守卫,正常
 * 结束后到达的 close 是幂等空操作,res 不会悬挂)。
 */
function readJsonBody(req: IncomingMessage, maxBytes: number): Promise<{ ok: true; value: unknown } | { ok: false; status: number; error: string }> {
  return new Promise((resolvePromise) => {
    const declared = Number(req.headers['content-length'] ?? '0')
    if (Number.isFinite(declared) && declared > maxBytes) {
      resolvePromise({ ok: false, status: 413, error: 'too-large' })
      return
    }
    const chunks: Buffer[] = []
    let total = 0
    let settled = false
    const finish = (result: { ok: true; value: unknown } | { ok: false; status: number; error: string }): void => {
      if (settled) return
      settled = true
      resolvePromise(result)
    }
    req.on('data', (chunk: Buffer) => {
      total += chunk.length
      // 流式累计上限:chunked 传输没有 Content-Length,只能边收边判。
      if (total > maxBytes) {
        req.destroy()
        finish({ ok: false, status: 413, error: 'too-large' })
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => {
      try {
        finish({ ok: true, value: JSON.parse(Buffer.concat(chunks).toString('utf8')) })
      } catch {
        finish({ ok: false, status: 400, error: 'invalid-json' })
      }
    })
    req.on('error', () => finish({ ok: false, status: 400, error: 'read-error' }))
    // 客户端断开兜底:没有 end/error 的连接断开也要 settle。
    req.on('close', () => finish({ ok: false, status: 400, error: 'read-error' }))
  })
}

/**
 * AI 审查暂存路由处理器:POST JSON { text } → 校验形似 diff →
 * 暂存临时文件 → 返回 { ok: true, path }。
 *
 * 同源守卫(为什么写路由必须做而 GET 不用):
 * - 宿主对命名路由是无鉴权直调,本路由是「持久写」,恶意网页可用
 *   text/plain 的 no-cors fetch(简单请求,免 CORS 预检)跨源灌数据;
 *   GET 路由跨源本就读不到响应体(SOP),没有等价暴露。
 * - Content-Type 限定 application/json:跨源 JS 设不了这个头(会转
 *   预检,而本路由无 CORS 放行 → 预检失败),廉价 CSRF 路径即被关死;
 *   插件自身的 fetch 恒同源、恒带此头,不受影响。
 * - Sec-Fetch-Site 为 cross-site 直接拒绝;头缺失时放行(curl 调试与
 *   不发送该头的老浏览器兼容)。
 * - 残余风险(DNS rebinding 对以上检查免疫)需要 Host 校验才能关死,
 *   但那会破坏非回环绑定的部署形态,记 backlog 不在本次处理。
 */
async function handleAiReviewRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
  if (req.method !== 'POST') {
    sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
    return
  }
  const contentType = req.headers['content-type'] ?? ''
  if (!contentType.toLowerCase().startsWith('application/json')) {
    sendJson(res, 415, { ok: false, error: 'unsupported-media-type' })
    return
  }
  const fetchSite = req.headers['sec-fetch-site']
  if (typeof fetchSite === 'string' && fetchSite.toLowerCase() === 'cross-site') {
    sendJson(res, 403, { ok: false, error: 'cross-site-denied' })
    return
  }
  const body = await readJsonBody(req, MAX_DIFF_BYTES)
  if (!body.ok) {
    sendJson(res, body.status, { ok: false, error: body.error })
    return
  }
  const text = (body.value as { text?: unknown }).text
  if (typeof text !== 'string') {
    sendJson(res, 400, { ok: false, error: 'invalid-json' })
    return
  }
  const result = await saveReviewDiff(text)
  if (!result.ok) {
    sendJson(res, result.status, { ok: false, error: result.error })
    return
  }
  sendJson(res, 200, { ok: true, path: result.path })
}

/**
 * 插件 apply:注册两个路由。webServer 可用时执行;缺失时静默跳过
 * (回调不执行),浏览器半的路径 chip / AI 审查按钮会显示读取失败。
 */
export function apply(ctx: CodeReviewCtx): void {
  ctx.inject(['webServer'], (srv) => {
    srv.effect(() => {
      // register 返回 disposer;插件卸载/HMR 重载时自动摘除路由。
      const unregisterDiff = srv.webServer.register({
        kind: 'exact',
        path: DIFF_ROUTE_PATH,
        handler: handleDiffRequest,
      })
      const unregisterAi = srv.webServer.register({
        kind: 'exact',
        path: AI_REVIEW_ROUTE_PATH,
        handler: handleAiReviewRequest,
      })
      return () => {
        unregisterDiff()
        unregisterAi()
      }
    }, `dsh-code-review: ${DIFF_ROUTE_PATH} + ${AI_REVIEW_ROUTE_PATH} routes`)
  })
}
