/**
 * 本地 diff 路径检测(纯逻辑,不依赖 DOM,可在 Node 里单测)。
 *
 * 目标:在对话文本里捕获「绝对路径指向的 .diff/.patch 文件」,
 * 形如 /Users/xxx/project/patch.diff、~/tmp/foo.patch。
 * 两类消费:
 * - cleanDiffPath:整段字符串恰好是一个路径(用于反引号内联 code 元素,
 *   文本 = 路径本身,允许首尾成对包裹符如引号/括号);
 * - findDiffPaths:在一段文本里扫描出全部路径(用于普通文本节点与
 *   bash 工具结果文本)。
 *
 * 匹配口径:
 * - 起点:/ 或 ~/(绝对路径;`/` 前允许冒号等标点,覆盖「diff:/tmp/x.diff」
 *   这类紧凑写法,`(`「[」等自然放行);
 * - 起点前不能是单词字符或斜杠,且 `/` 后不能紧跟 `/` —— 挡掉相对路径
 *   (x/y.diff)、URL(http://host/a.diff)与协议相对(//host/a.diff);
 * - 终点必须落在 .diff 或 .patch 后缀上,后缀后不能是路径连续字符
 *   (字母数字/横线/斜杠,或「点 + 单词」),避免把 a.diff.txt 误切成
 *   a.diff、把 foo.diff/bar.txt 切错;「a.diff.」(英文句号+空白/结束)
 *   正常命中;
 * - 路径内部不允许空白(含空格路径在聊天文本里无法可靠区分边界)。
 */

/** 绝对路径:/ 开头,前无单词字符/斜杠,后不紧跟第二个 /。 */
const ABS_ALT = '(?<![\\w/])/(?!/)[^\\s]*?\\.(?:diff|patch)'
/** home 简写:~ 开头必须跟 /,前缀约束同绝对路径。 */
const TILDE_ALT = '(?<![\\w/])~/[^\\s]*?\\.(?:diff|patch)'
/** 后缀后不能是:单词字符 / 横线 / 斜杠 / 「点 + 单词」。 */
const SUFFIX_BOUNDARY = '(?![\\w\\-/]|\\.(?=\\w))'

/** 全局扫描正则(g 用于 matchAll);后缀边界对两个分支统一生效。 */
const PATH_RE = new RegExp(`(?:${ABS_ALT}|${TILDE_ALT})${SUFFIX_BOUNDARY}`, 'gi')

/** 首尾成对包裹符:code 元素文本常见形态,清理后再做整串匹配。 */
const WRAPPERS: ReadonlyArray<readonly [string, string]> = [
  ['"', '"'],
  ["'", "'"],
  ['`', '`'],
  ['(', ')'],
  ['[', ']'],
  ['{', '}'],
  ['<', '>'],
  ['「', '」'],
  ['『', '』'],
  ['（', '）'],
  ['【', '】'],
]

/** 循环剥掉首尾成对包裹符(支持多层嵌套,如 `(/tmp/x.diff)`)。 */
function unwrap(s: string): string {
  let t = s
  let changed = true
  while (changed) {
    changed = false
    for (const [left, right] of WRAPPERS) {
      if (t.length > left.length + right.length && t.startsWith(left) && t.endsWith(right)) {
        t = t.slice(left.length, -right.length)
        changed = true
        // 从最外一层重新剥(成对性由循环保证)。
        break
      }
    }
  }
  return t
}

/**
 * 在一段文本里扫描全部匹配路径(去重,保留首次出现顺序)。
 */
export function findDiffPaths(text: string): string[] {
  const out: string[] = []
  const seen = new Set<string>()
  for (const match of text.matchAll(PATH_RE)) {
    const p = match[0]
    if (seen.has(p)) continue
    seen.add(p)
    out.push(p)
  }
  return out
}

/**
 * 判断一段文本是否「整段就是一个路径」(用于内联 code 元素)。
 * 先剥首尾包裹符,再要求:开头是 / 或 ~、文本里恰好命中一个路径、
 * 且命中结果与清理后的文本完全一致。不满足返回 null。
 */
export function cleanDiffPath(raw: string): string | null {
  const cleaned = unwrap(raw.trim())
  if (cleaned === '' || !cleaned.startsWith('/') && !cleaned.startsWith('~/')) {
    return null
  }
  const matches = findDiffPaths(cleaned)
  if (matches.length !== 1 || matches[0] !== cleaned) return null
  return cleaned
}
