/**
 * node 半路由逻辑单元测试(Node 直跑,不启动真实服务器)。
 * 覆盖:
 * - resolveDiffPath:绝对路径/~ 展开/非法路径/非 diff 后缀/相对路径;
 * - loadDiffText:正常读取、不存在、目录、超大文件;
 * - apply + mock webServer:register 收到路由,handler 对合法/非法参数
 *   分别返回正确 JSON 与状态码。
 */
import { build } from 'esbuild'
import { mkdirSync, mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'

const dir = mkdtempSync(join(tmpdir(), 'dsh-cr-node-test-'))
const entry = join(dir, 'entry.mjs')
writeFileSync(entry, `
import * as mod from ${JSON.stringify(join(process.cwd(), 'src/index.ts'))}
globalThis.__test = mod
`)
await build({
  entryPoints: [entry],
  bundle: true,
  platform: 'node',
  format: 'esm',
  outfile: join(dir, 'out.mjs'),
  logLevel: 'silent',
})
await import('file://' + join(dir, 'out.mjs'))
const { resolveDiffPath, loadDiffText, apply, DIFF_ROUTE_PATH, MAX_DIFF_BYTES } = globalThis.__test

let failed = 0
function check(name, actual, expected) {
  const a = JSON.stringify(actual)
  const e = JSON.stringify(expected)
  if (a === e) {
    console.log(`ok - ${name}`)
  } else {
    failed += 1
    console.log(`FAIL - ${name}\n  actual:   ${a}\n  expected: ${e}`)
  }
}
function checkTrue(name, actual) {
  if (actual) console.log(`ok - ${name}`)
  else { failed += 1; console.log(`FAIL - ${name}: got ${JSON.stringify(actual)}`) }
}

// —— resolveDiffPath ——
check('绝对路径原样', resolveDiffPath('/tmp/foo.diff'), resolve('/tmp/foo.diff'))
check('~ 展开', resolveDiffPath('~/a.patch'), resolve(process.env.HOME ?? '', 'a.patch'))
check('带尾随空串/空白', resolveDiffPath('  /tmp/foo.diff  '), resolve('/tmp/foo.diff'))
check('相对路径拒绝', resolveDiffPath('tmp/foo.diff'), null)
check('非 diff 后缀拒绝', resolveDiffPath('/tmp/foo.txt'), null)
check('含 NUL 拒绝', resolveDiffPath('/tmp/foo.diff\0x'), null)
check('空串拒绝', resolveDiffPath(''), null)
check('后缀大小写不敏感', resolveDiffPath('/tmp/FOO.PATCH'), resolve('/tmp/FOO.PATCH'))

// —— loadDiffText ——
const okPath = join(dir, 'ok.diff')
writeFileSync(okPath, 'diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n')
check('正常读取', await loadDiffText(okPath), { ok: true, text: 'diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n' })
check('不存在 → not-found', await loadDiffText(join(dir, 'missing.diff')), { ok: false, error: 'not-found', status: 404 })
const subdir = join(dir, 'subdir.diff')
mkdirSync(subdir)
check('目录 → not-file', await loadDiffText(subdir), { ok: false, error: 'not-file', status: 400 })
mkdirSync(join(dir, 'bigdir'), { recursive: true })
writeFileSync(join(dir, 'bigdir', 'big.diff'), Buffer.alloc(MAX_DIFF_BYTES + 1))
check('超大 → too-large', await loadDiffText(join(dir, 'bigdir', 'big.diff')), { ok: false, error: 'too-large', status: 413 })

// —— apply + mock webServer:路由注册与 handler ——
let registered = null
let effectName = null
let effectDisposerCalled = false
const fakeCtx = {
  inject: (deps, callback) => {
    check('inject 依赖含 webServer', deps, ['webServer'])
    callback(fakeCtx)
  },
  effect: (fn, name) => {
    effectName = name
    const disposer = fn()
    effectDisposerCalled = true
    return disposer
  },
  webServer: {
    register: (route) => {
      registered = route
      return () => {}
    },
  },
}
apply(fakeCtx)
checkTrue('webServer.register 被调用', registered !== null)
check('路由路径', registered.path, DIFF_ROUTE_PATH)
check('路由类型', registered.kind, 'exact')

/** 构造假的 req/res,handler 返回 (status, body) 元组。 */
function callHandler(req) {
  return new Promise((resolvePromise) => {
    const res = {
      headers: null,
      writeHead(status, headers) { this.headers = { status, ...headers } },
      end(body) { resolvePromise({ status: this.headers.status, body }) },
    }
    registered.handler(req, res)
  })
}

const okRun = await callHandler({ method: 'GET', url: `?path=${encodeURIComponent(okPath)}` })
check('handler 正常返回 200', okRun.status, 200)
const okBody = JSON.parse(okRun.body)
checkTrue('handler 内容为 ok+text', okBody.ok === true && typeof okBody.text === 'string' && okBody.text.startsWith('diff --git'))
const badRun = await callHandler({ method: 'GET', url: '?path=/etc/passwd' })
check('非 diff 后缀 400', badRun.status, 400)
check('非 diff 后缀错误类型', JSON.parse(badRun.body).error, 'invalid-path')
const missingRun = await callHandler({ method: 'GET', url: '?path=' + encodeURIComponent(join(dir, 'gone.diff')) })
check('缺失文件 404', missingRun.status, 404)
check('缺失文件错误类型', JSON.parse(missingRun.body).error, 'not-found')
const noParamRun = await callHandler({ method: 'GET', url: '' })
check('无 path 参数 400', noParamRun.status, 400)
const postRun = await callHandler({ method: 'POST', url: `?path=${encodeURIComponent(okPath)}` })
check('非 GET 405', postRun.status, 405)
checkTrue('effect 回调执行且返回 disposer', effectDisposerCalled)
// 清掉测试目录(环境干净)。
rmSync(dir, { recursive: true, force: true })

console.log(failed === 0 ? '\nall node-route tests passed' : `\n${failed} FAILED`)
process.exit(failed === 0 ? 0 : 1)
