/**
 * node 半路由逻辑单元测试(Node 直跑,不启动真实服务器)。
 * 覆盖:
 * - resolveDiffPath:绝对路径/~ 展开/非法路径/非 diff 后缀/相对路径;
 * - loadDiffText:正常读取、不存在、目录、超大文件;
 * - looksLikeDiffText / saveReviewDiff:AI 审查暂存的校验、写入、过期清理
 *   (暂存目录是真实系统临时目录,测试自己创建的文件在结尾统一清理);
 * - apply + mock webServer:register 收到两条路由,GET/POST handler 对
 *   合法/非法参数分别返回正确 JSON 与状态码。
 */
import { build } from 'esbuild'
import { mkdirSync, mkdtempSync, writeFileSync, rmSync, utimesSync, existsSync, unlinkSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { EventEmitter } from 'node:events'

const dir = mkdtempSync(join(tmpdir(), 'dsh-cr-node-test-'))
const entry = join(dir, 'entry.mjs')
writeFileSync(entry, `
import * as mod from ${JSON.stringify(join(process.cwd(), 'src/index.ts'))}
globalThis.__test = mod
`)
await build({
  entryPoints: [entry],
  bundle: true,
  platform: 'node',
  format: 'esm',
  outfile: join(dir, 'out.mjs'),
  logLevel: 'silent',
})
await import('file://' + join(dir, 'out.mjs'))
const {
  resolveDiffPath, loadDiffText, apply, DIFF_ROUTE_PATH, AI_REVIEW_ROUTE_PATH, MAX_DIFF_BYTES,
  looksLikeDiffText, saveReviewDiff,
} = globalThis.__test

let failed = 0
function check(name, actual, expected) {
  const a = JSON.stringify(actual)
  const e = JSON.stringify(expected)
  if (a === e) {
    console.log(`ok - ${name}`)
  } else {
    failed += 1
    console.log(`FAIL - ${name}\n  actual:   ${a}\n  expected: ${e}`)
  }
}
function checkTrue(name, actual) {
  if (actual) console.log(`ok - ${name}`)
  else { failed += 1; console.log(`FAIL - ${name}: got ${JSON.stringify(actual)}`) }
}

// —— resolveDiffPath ——
check('绝对路径原样', resolveDiffPath('/tmp/foo.diff'), resolve('/tmp/foo.diff'))
check('~ 展开', resolveDiffPath('~/a.patch'), resolve(process.env.HOME ?? '', 'a.patch'))
check('带尾随空串/空白', resolveDiffPath('  /tmp/foo.diff  '), resolve('/tmp/foo.diff'))
check('相对路径拒绝', resolveDiffPath('tmp/foo.diff'), null)
check('非 diff 后缀拒绝', resolveDiffPath('/tmp/foo.txt'), null)
check('含 NUL 拒绝', resolveDiffPath('/tmp/foo.diff\0x'), null)
check('空串拒绝', resolveDiffPath(''), null)
check('后缀大小写不敏感', resolveDiffPath('/tmp/FOO.PATCH'), resolve('/tmp/FOO.PATCH'))

// —— loadDiffText ——
const okPath = join(dir, 'ok.diff')
writeFileSync(okPath, 'diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n')
check('正常读取', await loadDiffText(okPath), { ok: true, text: 'diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n' })
check('不存在 → not-found', await loadDiffText(join(dir, 'missing.diff')), { ok: false, error: 'not-found', status: 404 })
const subdir = join(dir, 'subdir.diff')
mkdirSync(subdir)
check('目录 → not-file', await loadDiffText(subdir), { ok: false, error: 'not-file', status: 400 })
mkdirSync(join(dir, 'bigdir'), { recursive: true })
writeFileSync(join(dir, 'bigdir', 'big.diff'), Buffer.alloc(MAX_DIFF_BYTES + 1))
check('超大 → too-large', await loadDiffText(join(dir, 'bigdir', 'big.diff')), { ok: false, error: 'too-large', status: 413 })

// —— apply + mock webServer:路由注册与 handler ——
let registered = []
let effectName = null
let effectDisposerCalled = false
const fakeCtx = {
  inject: (deps, callback) => {
    check('inject 依赖含 webServer', deps, ['webServer'])
    callback(fakeCtx)
  },
  effect: (fn, name) => {
    effectName = name
    const disposer = fn()
    effectDisposerCalled = true
    return disposer
  },
  webServer: {
    register: (route) => {
      registered.push(route)
      return () => {}
    },
  },
}
apply(fakeCtx)
checkTrue('webServer.register 被调用两次', registered.length === 2)
check('diff 路由路径', registered[0].path, DIFF_ROUTE_PATH)
check('AI 审查路由路径', registered[1].path, AI_REVIEW_ROUTE_PATH)
check('路由类型', registered.map((r) => r.kind), ['exact', 'exact'])

/** 构造假的 req/res,handler 返回 (status, body) 元组。 */
function callHandler(route, req) {
  return new Promise((resolvePromise) => {
    const res = {
      headers: null,
      writeHead(status, headers) { this.headers = { status, ...headers } },
      end(body) { resolvePromise({ status: this.headers.status, body }) },
    }
    route.handler(req, res)
  })
}

const okRun = await callHandler(registered[0], { method: 'GET', url: `?path=${encodeURIComponent(okPath)}` })
check('handler 正常返回 200', okRun.status, 200)
const okBody = JSON.parse(okRun.body)
checkTrue('handler 内容为 ok+text', okBody.ok === true && typeof okBody.text === 'string' && okBody.text.startsWith('diff --git'))
const badRun = await callHandler(registered[0], { method: 'GET', url: '?path=/etc/passwd' })
check('非 diff 后缀 400', badRun.status, 400)
check('非 diff 后缀错误类型', JSON.parse(badRun.body).error, 'invalid-path')
const missingRun = await callHandler(registered[0], { method: 'GET', url: '?path=' + encodeURIComponent(join(dir, 'gone.diff')) })
check('缺失文件 404', missingRun.status, 404)
check('缺失文件错误类型', JSON.parse(missingRun.body).error, 'not-found')
const noParamRun = await callHandler(registered[0], { method: 'GET', url: '' })
check('无 path 参数 400', noParamRun.status, 400)
const postRun = await callHandler(registered[0], { method: 'POST', url: `?path=${encodeURIComponent(okPath)}` })
check('非 GET 405', postRun.status, 405)
checkTrue('effect 回调执行且返回 disposer', effectDisposerCalled)

// —— looksLikeDiffText(判定口径与浏览器半 isDiffText 一致)——
checkTrue('looksLike:diff --git 头', looksLikeDiffText('diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n'))
checkTrue('looksLike:裸 patch(hunk+文件标记)', looksLikeDiffText('--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n'))
checkTrue('looksLike:普通文本否', !looksLikeDiffText('hello world\nfoo bar\n'))
checkTrue('looksLike:只有 hunk 头否', !looksLikeDiffText('@@ -1 +1 @@\n-x\n+y\n'))
checkTrue('looksLike:空串否', !looksLikeDiffText(''))

// —— saveReviewDiff(AI 审查暂存;写入真实系统临时目录,记录路径待清理)——
const cleanupPaths = []
{
  const sample = 'diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n'
  const saved = await saveReviewDiff(sample)
  checkTrue('save:成功返回路径', saved.ok === true && typeof saved.path === 'string' && saved.path.endsWith('.diff'))
  if (saved.ok) {
    cleanupPaths.push(saved.path)
    check('save:文件内容与输入一致', readFileSync(saved.path, 'utf8'), sample)
    checkTrue('save:文件落在 dsh-code-review 目录', saved.path.includes(join(tmpdir(), 'dsh-code-review')))
    checkTrue('save:文件名是服务端命名约定', /review-\d+-[0-9a-f]+\.diff$/.test(saved.path))
  }
  check('save:空文本拒绝', await saveReviewDiff('   '), { ok: false, error: 'empty-text', status: 400 })
  check('save:非 diff 文本拒绝', await saveReviewDiff('hello'), { ok: false, error: 'not-a-diff', status: 400 })
  check('save:超上限拒绝', await saveReviewDiff('diff --git a/a b/a\n' + 'x'.repeat(MAX_DIFF_BYTES)), { ok: false, error: 'too-large', status: 413 })
  // 过期清理:手工放置一个 mtime 超过 TTL 的旧文件,下次写入应清掉。
  const reviewDir = join(tmpdir(), 'dsh-code-review')
  const stalePath = join(reviewDir, 'review-1000000000000-deadbeef.diff')
  writeFileSync(stalePath, 'stale')
  const staleTime = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
  utimesSync(stalePath, staleTime, staleTime)
  const saved2 = await saveReviewDiff(sample)
  if (saved2.ok) cleanupPaths.push(saved2.path)
  checkTrue('save:过期文件被清理', !existsSync(stalePath))
  // 非本插件命名约定的文件不能被清理误伤。
  const bystander = join(reviewDir, 'someone-else.txt')
  writeFileSync(bystander, 'x')
  utimesSync(bystander, staleTime, staleTime)
  const saved3 = await saveReviewDiff(sample)
  if (saved3.ok) cleanupPaths.push(saved3.path)
  checkTrue('save:无关文件不误伤', existsSync(bystander))
  unlinkSync(bystander)
}

// —— POST /dsh-code-review/ai-review handler ——
/** 构造可发 data/end 事件的假 req(POST 体流式)。
 * 默认带合法同源头(application/json,无 Sec-Fetch-Site = curl 兼容口径),
 * 测试按需覆盖;传 undefined 值可模拟缺头。 */
function postReq(body, headers = {}) {
  const req = new EventEmitter()
  req.method = 'POST'
  req.url = '/'
  req.headers = { 'content-type': 'application/json', ...headers }
  // 事件在 handler 挂好监听后异步发射(setImmediate 保证先 attach 后 emit)。
  setImmediate(() => {
    if (body !== null) {
      const chunk = Buffer.from(body, 'utf8')
      // 分两段发射,覆盖多 chunk 累计路径。
      req.emit('data', chunk.subarray(0, Math.ceil(chunk.length / 2)))
      req.emit('data', chunk.subarray(Math.ceil(chunk.length / 2)))
    }
    req.emit('end')
  })
  return req
}
{
  const aiRoute = registered[1]
  const sample = 'diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-x\n+y\n'
  const okPost = await callHandler(aiRoute, postReq(JSON.stringify({ text: sample })))
  check('ai:POST 正常 200', okPost.status, 200)
  const okPostBody = JSON.parse(okPost.body)
  checkTrue('ai:返回 ok+path', okPostBody.ok === true && typeof okPostBody.path === 'string')
  if (okPostBody.ok) {
    cleanupPaths.push(okPostBody.path)
    check('ai:暂存内容一致', readFileSync(okPostBody.path, 'utf8'), sample)
  }
  const getRun = await callHandler(aiRoute, { method: 'GET', url: '/' })
  check('ai:非 POST 405', getRun.status, 405)
  // —— 同源守卫(共识修复 P1 #1)——
  const textPlain = await callHandler(aiRoute, postReq(JSON.stringify({ text: sample }), { 'content-type': 'text/plain' }))
  check('ai:非 application/json 415', textPlain.status, 415)
  check('ai:415 错误类型', JSON.parse(textPlain.body).error, 'unsupported-media-type')
  const noType = await callHandler(aiRoute, postReq(JSON.stringify({ text: sample }), { 'content-type': undefined }))
  check('ai:缺 Content-Type 415', noType.status, 415)
  const crossSite = await callHandler(aiRoute, postReq(JSON.stringify({ text: sample }), { 'sec-fetch-site': 'cross-site' }))
  check('ai:cross-site 403', crossSite.status, 403)
  check('ai:403 错误类型', JSON.parse(crossSite.body).error, 'cross-site-denied')
  const sameSite = await callHandler(aiRoute, postReq(JSON.stringify({ text: sample }), { 'sec-fetch-site': 'same-origin' }))
  check('ai:same-origin 放行 200', sameSite.status, 200)
  if (JSON.parse(sameSite.body).ok) cleanupPaths.push(JSON.parse(sameSite.body).path)
  const charsetOk = await callHandler(aiRoute, postReq(JSON.stringify({ text: sample }), { 'content-type': 'application/json; charset=utf-8' }))
  check('ai:带 charset 的 json 放行 200', charsetOk.status, 200)
  if (JSON.parse(charsetOk.body).ok) cleanupPaths.push(JSON.parse(charsetOk.body).path)
  const badJson = await callHandler(aiRoute, postReq('not-json'))
  check('ai:非 JSON 400', badJson.status, 400)
  check('ai:非 JSON 错误类型', JSON.parse(badJson.body).error, 'invalid-json')
  const noText = await callHandler(aiRoute, postReq(JSON.stringify({ foo: 1 })))
  check('ai:缺 text 字段 400', noText.status, 400)
  const notDiff = await callHandler(aiRoute, postReq(JSON.stringify({ text: 'plain text' })))
  check('ai:非 diff 内容 400', notDiff.status, 400)
  check('ai:非 diff 错误类型', JSON.parse(notDiff.body).error, 'not-a-diff')
  // Content-Length 预检:声明超限直接 413,不读流。
  const bigDeclared = await callHandler(aiRoute, postReq(null, { 'content-length': String(MAX_DIFF_BYTES + 1) }))
  check('ai:Content-Length 超限 413', bigDeclared.status, 413)
  // chunked 流式累计超限:分段发射超过上限的数据。
  const chunkedReq = new EventEmitter()
  chunkedReq.method = 'POST'
  chunkedReq.url = '/'
  chunkedReq.headers = { 'content-type': 'application/json' }
  chunkedReq.destroy = () => { chunkedReq.destroyed = true }
  const overflowPromise = callHandler(aiRoute, chunkedReq)
  setImmediate(() => {
    const mb = Buffer.alloc(1024 * 1024, 120)
    for (let i = 0; i < 6; i += 1) chunkedReq.emit('data', mb)
  })
  const overflow = await overflowPromise
  check('ai:chunked 超限 413', overflow.status, 413)
  checkTrue('ai:chunked 超限销毁连接', chunkedReq.destroyed === true)
  // 客户端中途断开兜底(共识修复 P2 #5):只发 close 不发 end,promise 也必须 settle。
  const closedReq = new EventEmitter()
  closedReq.method = 'POST'
  closedReq.url = '/'
  closedReq.headers = { 'content-type': 'application/json' }
  const closedPromise = callHandler(aiRoute, closedReq)
  setImmediate(() => {
    closedReq.emit('data', Buffer.from('{"text":"diff'))
    closedReq.emit('close')
  })
  const closed = await closedPromise
  check('ai:中途断开 400', closed.status, 400)
  check('ai:中途断开错误类型', JSON.parse(closed.body).error, 'read-error')
}
checkTrue('effect 名称含两条路由', String(effectName).includes(DIFF_ROUTE_PATH) && String(effectName).includes(AI_REVIEW_ROUTE_PATH))

// 清理:测试创建的暂存文件 + 测试目录(不留垃圾在真实系统临时目录)。
for (const p of cleanupPaths) {
  try { unlinkSync(p) } catch { /* 已消失则忽略 */ }
}
rmSync(dir, { recursive: true, force: true })

console.log(failed === 0 ? '\nall node-route tests passed' : `\n${failed} FAILED`)
process.exit(failed === 0 ? 0 : 1)
