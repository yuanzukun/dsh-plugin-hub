/**
 * diff-path 路径检测纯逻辑单元测试(Node 直跑,无 DOM)。
 * 覆盖:绝对路径/~ 路径、后缀大小写、尾随标点、多路径、URL/相对路径剔除、
 * 内联 code 整串匹配(cleanDiffPath,含包裹符)、去重。
 */
import { build } from 'esbuild'
import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const dir = mkdtempSync(join(tmpdir(), 'dsh-cr-path-test-'))
const entry = join(dir, 'entry.mjs')
writeFileSync(entry, `
import { findDiffPaths, cleanDiffPath } from ${JSON.stringify(join(process.cwd(), 'src/client/diff-path.ts'))}
globalThis.__test = { findDiffPaths, cleanDiffPath }
`)
await build({
  entryPoints: [entry],
  bundle: true,
  platform: 'node',
  format: 'esm',
  outfile: join(dir, 'out.mjs'),
  logLevel: 'silent',
})
await import('file://' + join(dir, 'out.mjs'))
const { findDiffPaths, cleanDiffPath } = globalThis.__test

let failed = 0
function check(name, actual, expected) {
  const a = JSON.stringify(actual)
  const e = JSON.stringify(expected)
  if (a === e) {
    console.log(`ok - ${name}`)
  } else {
    failed += 1
    console.log(`FAIL - ${name}\n  actual:   ${a}\n  expected: ${e}`)
  }
}

// —— findDiffPaths:普通文本 ——
check('单一路径', findDiffPaths('看下 diff:/tmp/x.diff'), ['/tmp/x.diff'])
check('~/ 路径', findDiffPaths('已生成 ~/work/p.patch'), ['~/work/p.patch'])
check('后跟中文标点', findDiffPaths('文件在/Users/yangzhe/a.diff,请查看'), ['/Users/yangzhe/a.diff'])
check('后跟英文句号', findDiffPaths('保存到/tmp/c.diff。'), ['/tmp/c.diff'])
check('后跟英文句号+空格', findDiffPaths('save to /tmp/c.diff.'), ['/tmp/c.diff'])
check('后跟闭合括号', findDiffPaths('(保存到 /tmp/b.diff) 完成'), ['/tmp/b.diff'])
check('多路径去重保序', findDiffPaths('/tmp/a.diff 和 /tmp/b.patch 以及 /tmp/a.diff'), ['/tmp/a.diff', '/tmp/b.patch'])
check('后缀大小写不敏感', findDiffPaths('/tmp/A.DIFF'), ['/tmp/A.DIFF'])
check('相对路径不匹配', findDiffPaths('看看 src/x.diff'), [])
check('URL 不匹配', findDiffPaths('https://host/a.patch 和 http://h/b.diff'), [])
check('协议相对 URL 不匹配', findDiffPaths('//host/a.patch'), [])
check('非 diff 后缀不匹配', findDiffPaths('文件在/tmp/x.txt'), [])
check('diff.txt 不切成半截', findDiffPaths('/tmp/foo.diff.txt'), [])
check('目录名含 .diff 不误切', findDiffPaths('/tmp/foo.diff/bar.txt'), [])
check('路径内带多余文字截断', findDiffPaths('路径 /tmp/x.diff (1.2KB) 已备好'), ['/tmp/x.diff'])
check('空文本', findDiffPaths(''), [])

// —— cleanDiffPath:内联 code 元素整串匹配 ——
check('整串路径', cleanDiffPath('/tmp/x.diff'), '/tmp/x.diff')
check('整串 ~/ 路径', cleanDiffPath('~/foo/a.patch'), '~/foo/a.patch')
check('带括号包裹', cleanDiffPath('(/tmp/x.diff)'), '/tmp/x.diff')
check('带引号包裹', cleanDiffPath('"/tmp/x.diff"'), '/tmp/x.diff')
check('带中文括号包裹', cleanDiffPath('（/tmp/x.diff）'), '/tmp/x.diff')
check('不带 / 前缀不匹配', cleanDiffPath('x.diff'), null)
check('相对路径不匹配', cleanDiffPath('src/x.diff'), null)
check('多路径不匹配', cleanDiffPath('/tmp/a.diff b.diff'), null)
check('纯文本不匹配', cleanDiffPath('/tmp/x.diff 请查看'), null)
check('空串不匹配', cleanDiffPath(''), null)

console.log(failed === 0 ? '\nall path-detect tests passed' : `\n${failed} FAILED`)
process.exit(failed === 0 ? 0 : 1)
