# Changelog

## 1.4.5 — a deck is cells, not one cell

- **A text-card clip stops being one picture.** Six 1280x720 title cards that
  differ only in their body text scanned as `0 cuts · median shot 30.15s`, and
  the planner — which can only spill *inside* a shot — spent one cell on the
  whole thing, so every `detail` level produced the same single-cell sheet. The
  scan had already proved the case (`detectTextMotion`); it now hands the marks
  to the layout: `markTimes` reads the same changed-share band the scan uses,
  `markShots` turns them into a partition (a mark within 1.5 s of the previous
  one or of the tail is dropped; fewer than 2 survivors means no partition, so
  at most 24 cells can come this way), and `planCells` breaks there. The 30 s
  deck now gets **6 cells, one per card, 359 vision tokens at `auto`**, with the
  spans exactly on the card boundaries (was 1 cell, 192 tokens).
- **The cut count stays honest.** The header still says `0 cuts` — there is no
  cut — and the note says where the cells came from instead of promising a map:
  `6 of those moves are the cells below, one card each (0 cuts stays the honest
  count: the cards change, the cutter does not)`. The cut thresholds are
  untouched on purpose: the relaxation that would make a 6 % card a cut would
  make every caption line a shot.
- **`README` and `docs/DESIGN.md` said a slide changing only its text block is a
  `partial` cut.** It is not: 1–6 % changed is below the 10 % event floor and
  lands in `noise`, which is why the deck needed its own path (§2.6).
- Suite is 339 tests (337 pass, 2 skip for a missing ffmpeg on the host).

## 1.4.4 — the tarball is the package

- **First release on npm.** `npm i dsh-video-vision` then
  `npx dsh-video-vision-install`; the checkout route still works and is what the
  installer does either way.
- **The shebangs are LF again.** `git ls-files --eol` showed
  `bin/install.mjs`, `bin/selfcheck.mjs` and `test/manifest.test.mjs` committed
  with CRLF, which made `pnpm pack` refuse the package outright
  (`ERR_PNPM_BIN_CRLF`) — and would have made `npx` fail on Linux and macOS
  even if it had gone out. `.gitattributes` has said `* text=auto eol=lf` since
  1.0.0; the working tree now agrees with it.
- **No test scratch in the tarball.** One test hardlinks the machine's ffmpeg into
  `test/.tmp/path-*/` and deletes it in `t.after`; when a run was interrupted the
  leftover 99 MB `ffmpeg.exe` was packed into the first tarball and 36 MB came
  out the other end. `test/.tmp` was already in `.gitignore` but `files` listed
  `test` wholesale; it is now excluded by both `files` and a `.npmignore`.
  The tarball is **693 KB, 62 files**, biggest entry a 199 KB screenshot.
- Docs: the test count in both READMEs and `docs/EVIDENCE.md` was stale at 314;
  the suite is 331 tests (329 pass, 2 skip for a missing ffmpeg on the host).

## 1.4.3 — the OCR probe gets the environment it needs

- **The probe no longer inherits a stripped environment.** 1.4.2 asked the host
  which OCR languages it has by starting PowerShell, but handed it whatever
  `env` record reached `ocrBackend()` — on Windows CI that was a test's
  `{ PATH: '' }`, which left PowerShell unable to find its own dependency and
  the call hung until the 20 s bound, so `ocrBackend()` answered "unavailable"
  on two of the three runner images while the third passed. The probe now
  spawns with `{ ...process.env, ...env }` (the caller only overrides) and the
  bound is 60 s, enough for a cold runner to load WinRT.

## 1.4.2 — a Windows Server without an OCR language is a picture, not a crash

- **Windows CI stopped failing on a bare `OCR failed (1): `.** The native
  engine was chosen whenever `powershell.exe` existed, so a Windows Server
  runner — `Windows.Media.Ocr` present, its recogniser language pack absent —
  looked usable and then made `bin/ocr-batch.ps1` exit 1. Two symptoms
  followed: the engine's explanation went to stdout while the caller only
  collected stderr, so the error ended in a bare colon; and the read that
  should have fallen back to pictures threw instead. The backend now asks the
  host what it can recognise (`ocr-batch.ps1 -Probe`, one 20 s-bounded call,
  memoised per process) and reports `no recogniser language is (Windows Server
  ships without one)`; the failure text also quotes stdout, so the next
  version of this bug names itself.
- **The chosen language is now explicit.** `chooseOcrLanguage()` picks
  `zh-Hans-CN`, then any `zh-hans` variant, then English, then whatever the
  host has, and the batch script is told with `-Lang`. A host with
  English-only OCR reads English slides instead of being declared broken.
  `windowsProbeVerdict()`, `windowsBackendFromProbe()` and
  `probeWindowsOcr()` are exported for tests.

- **A local file is no longer mistaken for a B站 link.** `parseBilibili()` read
  the text for an id anywhere in the string, so `C:\videos\av12345.mp4` became
  video `av12345` and a temp directory called `pipeline-av6jp2` counted as a
  video too — that path went to the network and made one run in ~2 400 fail on
  a clip that was never online. A string that is not a URL and carries a path
  separator or a file extension is now a file.

### Fixed

- `video_read` on a Windows host with no OCR language pack now returns
  pictures with the usual "no readable text" note instead of `OCR failed (1): `.

## 1.4.1 — the marks move, the picture does not

- **A slide deck is no longer reported as an empty clip.** A clip whose frame
  is nearly constant and whose *marks* keep changing (captions, a leaderboard,
  a subtitle-only cut) used to come back as `static` from `video_outline`, as
  one `192`-token cell from `video_storyboard`, and as "nothing much here" to
  any model that called them first. `scanShots` now measures the local motion
  that a 12×7 block grid averages away — event count, density, and how much of
  the activity sits in the busiest quarter of the blocks — and only calls it
  when the picture holds still and no cut was found: `duration ≥ 20 s`,
  `cuts === 0`, `events ≥ 3`, `density < 0.15`, `busiest-quarter share ≥ 0.75`.
  A slow pan (density 0.76) and a strobing clip (0.90) are excluded by those
  last two; the 30 s repro is the only clip in the corpus that passes.
  `video_outline` gains the tag `text`, says `24 of 24 windows keep their
  picture and redraw their marks`, and points at `video_read`;
  `video_storyboard` prints the same sentence in its index; the four tool
  descriptions now say which of the two readers to call.
- **`video_read` no longer drops a screen that only swaps its wording.** The
  sampler compared 12×7 block means, where one line of text replacing another
  is a change of 0.000, so a frame 2.4 s after the previous one was skipped and
  its sentence was lost (11 screens for a 12-sentence clip). Dense mode now
  also samples on the frame's mean absolute pixel difference
  (`denseDelta: 0.5`; measured noise 0.07 against 1.59–3.09 per sentence), so
  the repro reads 12 screens with `[00:18–00:20] 第9句` back where it belongs.
  `frameDelta()` is exported.
- **OCR digits are no longer split or glued.** `第 1 0 句` becomes `第10句`,
  Chinese-to-digit spacing is removed, and full-width punctuation no longer
  keeps the space that follows it — while `分辨率 1280 720` stays untouched.
  The note printed when a file yields fewer than five screens no longer lists
  "a fixed layout whose only change is a subtitle line", which is exactly what
  the sampler above now reads.

### Measured

- The 30 s text clip that motivated the fix is the only corpus-adjacent file
  that trips the new rule, and it trips all three calls differently now:
  `video_outline` 0.79 s / 24 windows / 24 tagged `text` / 0 vision tokens;
  `video_storyboard` 1.17 s / 1 cell / 192 tokens, with the routing line on the
  fourth row of the index; `video_read` 3.63 s / **12 screens** (was 11) /
  0 image tokens. A slow pan of 750 frames scores density 0.76 and stays
  `static`; the flicker clip scores 0.90 and stays `static` too.

### Tests

**324** (was 237): notes for every clamp, the `dedupe:"global"` fold, keyframe
mode, audio-only probe/read/probe-refusal, the six-picture fallback, SRT/VTT/text
export, the tesseract TSV parser and reading order, CJK word joining, ASR chunk
planning and silence points, the whole `video_outline` path on a real clip,
the micro-motion verdict and its exclusions, the `text` tag and the routing
note, `frameDelta()` and the digit repair, and the plugin registering five
tools. 322 pass, 2 skip on a host without a second ffprobe or tesseract.
`bin/selfcheck.mjs --smoke --host`: 40/40.

## 1.4.0

### Added — two tools that answer without a picture

- **`video_outline` maps a whole file as text and draws nothing.** The file is
  cut into 4–60 equal windows; each row carries the cut count, the speech share,
  an eight-character intensity bar and up to two tags (`dark`, `static`,
  `quiet`, `busy`, `talk`), then `watch first:` ranks the windows worth
  opening and `next:` gives the exact `start`/`end` for `video_storyboard`
  or `video_read`. Cost: **zero vision tokens** — this is the call to make
  before spending 1 024 on a sheet. 40 s clip: 0.9 s, 8 windows. 70 s gameplay
  clip: 2.6 s, 24 cuts, 8 windows. Long files reuse the keyframe pass below.
- **`video_read` reads a file with sound and no picture.** An mp3, m4a or wav is
  now a transcript: the container's subtitle track first, then `DSH_ASR_CMD`,
  then the `transcriptFile` you pass. With none of the three it refuses with a
  sentence that names all three. `video_probe` on such a file reports the codec
  and returns `plan: null`; `video_storyboard`/`video_zoom` fail with
  "there is no picture to sample; video_read transcribes audio" instead of a
  generic decode error.
- **`video_read` returns pictures when the file has no readable text.**
  Handwriting, a phone pointed at a screen instead of a capture, a whiteboard: a
  fixed number of changed frames is decoded and composed into a **six-cell**
  sheet, and the text says these are pictures, not words. Zero screens used to
  mean an empty document and "call video_storyboard yourself".
- **`video_read` writes the result out** (`out`): `.srt`/`.vtt` are subtitle
  files, any other extension is `[mm:ss] text` lines, parent directories are
  created, and the last line reports the path and the count.
- **`video_storyboard` takes `dedupe:"global"`.** Repeats are folded inside a
  shot by default; `global` folds them across cuts too, and the shot that comes
  back to a picture already on the sheet is listed against that cell instead of
  spending a new one. The note says how many were dropped and how to keep them.
- **B站 play URLs are cached** for 10 minutes (`DSH_BILIBILI_PLAY_TTL_MS`) —
  probe, storyboard and read of the same clip no longer re-resolve the signed
  CDN link — and the **download cache has a budget**: 4 GB / 24 videos by
  default (`DSH_BILIBILI_CACHE_MB`, `DSH_BILIBILI_CACHE_MAX`), evicted by last
  use, never the file being read.
- **OCR works away from Windows.** `tesseract` on `PATH` is used wherever it
  is found, in TSV mode so line boxes survive; the words in a line are joined
  without spaces between CJK characters and with them between Latin words, and
  lines are ordered by reading position. `DSH_OCR_CMD` points at any other
  engine (one image path in, lines out); `DSH_OCR_BACKEND=off` disables OCR,
  `=tesseract` skips the Windows engine, `DSH_OCR_LANG` selects a model.
- **Long audio is transcribed in pieces.** Two hours of 16 kHz mono wav is
  230 MB and most engines truncate or die on it: the audio is now cut at a 45 s
  target, each cut moved onto the nearest silence midpoint (so a word is never
  split), a 12 s floor, two chunks in flight. All five knobs are environment
  variables (`DSH_ASR_CHUNK_SECONDS`, `_CHUNK_MIN`, `_PARALLEL`,
  `_SILENCE_DB`, `_SILENCE_MIN`); `0` seconds turns chunking off.

### Changed

- **Silent clamps now report themselves.** `maxScreens`, `start`/`end`,
  `duration`, `cells` (24 for a sheet, 9 for a zoom) are still clamped, but the
  result carries a `note:` line saying what was asked, what was used and what to
  pass instead. A window that starts past the end of the file is an error with
  the real duration in it, not an empty answer.
- **A cell is never smaller than a fifth of the source.** `auto` used to give
  every file 28 cells in a 1.76 Mpx sheet, so a 1440p sheet was 22 cells of
  302 px and 4K was 28 smears. The sheet now keeps its budget and spends it on
  fewer, bigger cells: 720p **28 → 28**, 1080p **28 → 21**, 1440p **28 → 11**,
  4K **28 → 5**, at the same ~1 024 tokens, and says
  `sheet reduced from N to M cells so text stays legible`.
- **A long file is analysed on its keyframes.** From ten minutes up, when
  keyframes are at least a second apart, the analysis pass decodes keyframes only
  — **2.7× faster on the two-hour lecture** — and the note says what a change
  shorter than that gap would hide, plus `DSH_SCAN_KEYFRAMES=off` to undo it.
- **B站 links that are not a single video say why.** A bangumi episode or series,
  a media page, a live room, a space list/collection, a `/list/` page and
  `opus`/`read`/t.bilibili text posts each get their own sentence instead of
  "can not understand this link".

### Measured

- The corpus is untouched by all of the above: 9 clips, **67 cells**,
  **3 648 vision tokens** (54.45 per cell), micro cut P 0.774 / R 1.000 /
  F1 0.872, mean clip F1 0.667, shot coverage 0.963, sheet PNG 152 677 B,
  manifest 477 chars.
- `video_outline` on `A_hardcuts_720p.mp4`: 0.94 s, 8 windows, 9 cuts,
  no image, no vision tokens. On a 70 s gameplay recording: 2.6 s, 8 windows,
  24 cuts of which 6 land in one window.
- The downscale rail at `detail:"auto"`, 16:9: 720p 28 cells, 1080p 21,
  1440p 11, 4K 5 — a 1440p sheet grows from 1.01 Mpx to 1.62 Mpx so its cells
  are 288 px tall, 1/5 of the source instead of 1/8.
- Audio-only probe and read on `talk.wav` (3 s sine): probe 5 lines with the
  codec and `plan: null`; read with a `transcriptFile` produces
  `# talk.wav — read as text · audio only · 2 lines · 00:03`.

### Tests

**314** (was 237): notes for every clamp, the `dedupe:"global"` fold, keyframe
mode, audio-only probe/read/probe-refusal, the six-picture fallback, SRT/VTT/text
export, the tesseract TSV parser and reading order, CJK word joining, ASR chunk
planning and silence points, the whole `video_outline` path on a real clip, and
the plugin registering five tools. 312 pass, 2 skip on a host without a second
ffprobe or tesseract. `bin/selfcheck.mjs --smoke --host`: 40/40.

## 1.3.4

### Added

- **The index now says which cells are worth zooming.** A dense sheet is small
  per cell, so a subtitle line or a line of code can vanish into a smear while
  the cell still looks like a perfectly good picture. Each cell is decoded at
  twice the cell size for the measurement only, the two scales are compared, and
  the index gets a `zoom:` line listing the cells that carry detail finer than a
  sheet pixel — those cell lines end in the word `zoom`.
  When every cell is in that state the line says so once instead of listing
  twenty-two numbers, and suggests `detail:"low"` for bigger cells instead.
  Cells with no fine detail (black frame, flat card, letterbox) are never marked.
- `DSH_VIDEO_ZOOM_MARKERS=0` turns the measurement off (it is skipped on
  readable sheets anyway, where it cannot change an answer).

### Measured

- 2560×1440 lecture, 150 s window: cells are shrunk 7.02×, all 5 flagged,
  `text under ~84px in the source is gone`.
- 720P Bilibili clip, 28 cells at 3.87×: 27 of 28 flagged — the one cell of pure
  sky is not.
- 720P corpus clips at 3.2×: nothing flagged, and the decode path is untouched
  (67 cells · 3 648 vision tokens · cut F1 0.872 · coverage 0.963 unchanged).
- Cost of the measurement where it runs: 2 286 ms vs 2 123 ms decode on the same
  window (within run-to-run noise — the integral-image ink measure is 4 lookups
  per pixel, not 25).

### Tests

237 (was 229): synthetic ink/stroke cases, the marker thresholds, the note
wording for one/many/all cells, and the manifest marker itself.

## 1.3.3

### Fixed — four things a reader hit on real files

- **ffmpeg 8 and later failed outright.** The frame decoder asked for `-vsync 0`,
  which ffmpeg 8 removed, and the tool died with `Unrecognized option 'vsync'`
  before reading a single frame. It now asks its own binary for its version once
  and picks the spelling that build understands — `-fps_mode passthrough` from
  5.1 on, `-vsync 0` before that — and if a build rejects the choice anyway, the
  decode is retried once with the other spelling.
- **A fixed layout whose only change is the subtitle returned 0 screens.** The
  whole-frame gate treats a 2 % change as "the same picture", so 21 sampled
  frames collapsed to one and the other three lines were thrown away. In dense
  mode the gate is now 0.004, a screen that contributes a line the previous one
  does not have counts as a new screen, and the sampled frames are the frames
  that get read.
- **The frames that were measured are now the frames that are read.** A seek to
  the timestamp of a 96x54 grid decodes a *slightly different* frame than the
  `fps` filter handed the grid pass, which on subtitle-only changes quoted the
  previous sentence and skipped the next. The dense pass writes the sampled
  frames in the same order the grids saw them, so frame N of the read is frame N
  of the measurement.
- **OCR sections were parsed only when the file was called `f…`.** The dense pass
  writes `d00001.png`, so every record came back empty. The section parser takes
  any stem now.
- A short clip with four real subtitle lines is reported, not discarded: the old
  "fewer than three screens means nothing was found" floor is replaced by
  "screens **or** ≥40 content characters", and the header, the note, the outline
  and the quoted body all come from that one list.
- The "this video may be handwritten / a camera recording" note no longer
  asserts a cause. It reports what was found and names the possibilities —
  handwriting, a phone pointed at a screen, no slides at all, or a fixed layout
  whose only change is a subtitle line.

### Measured

| | before | after |
| --- | --- | --- |
| 25 s, still frame, four subtitle lines | 0 screens | 4 screens, correct spans (2.7 s) |
| ffmpeg 8.0.1, any read | `Unrecognized option 'vsync'` | works (`-fps_mode passthrough`) |
| `D_slideshow_720p.mp4` (36 s, text cards) | 6 screens | 6 screens |
| 1:59:54 lecture, keyframe path | 53 screens / 7 663 chars | unchanged path, unchanged numbers |

### Tests

`224 → 229` (fps-flag fallback, the novel-line rule, the content floor, the
section parser).


## 1.3.2

### Added

- **A B站 link no longer has to be downloaded.** The CDN hands out a signed mp4
  link, so ffmpeg reads it in place: `video_probe` never touched the stream,
  and now `video_storyboard`, `video_zoom` and `video_read` can work on the URL
  too. `DSH_BILIBILI_STREAM=1` forces it, `=0` forces a download, and the
  default is `auto` — clips up to `DSH_BILIBILI_STREAM_MAX` seconds (300) are
  read from the network, longer ones are downloaded once and cached, because
  streaming a two-hour lecture twice costs more than keeping it.
- Every ffmpeg/ffprobe call site now passes the Referer and User-Agent the CDN
  requires, as one `-headers` argument with CRLF separators (a bare newline is
  parsed as a separate option and the CDN answers 403).
- `DSH_HTTP_REFERER` / `DSH_HTTP_UA` override those headers for other hosts.

### Measured

| | |
| --- | --- |
| `video_probe`, link, no download | 251 ms |
| `video_storyboard`, 57 s link, streamed | 5.7 s (1.9 s when cached locally) |
| `video_read`, 57 s link, streamed | 8.3 s (2 161 characters out of 14 screens) |
| 20 s of video decoded from the CDN | 1.6 s |
| one frame seeked at 40 s over HTTP | 0.5 s |

### Tests

`190 → 192` (stream mode parsing, header plumbing).

## 1.3.1

### Added — the transcript, and what is owed to it

- `transcriptFile` accepts SRT, WebVTT, or JSON (`[{start,end,text}]` /
  `{"segments":[…]}`) and is consulted **before** the embedded subtitle track and
  before `DSH_ASR_CMD`. Re-deriving captions you already have is the most
  expensive way to get them wrong.
- `~/.dsh/asr.json` can hold the command as well as a `terms` dictionary
  (`{"cmd": "…", "terms": {"地规": "递推"}}`). The environment still wins; the file
  exists because a desktop host does not inherit `setx` variables.
- Hallucinations are filtered client-side, because every engine invents speech
  over music: punctuation-only lines are dropped, and so are lines longer than 8 s
  at under 0.8 characters per second (real speech runs 2–6).
- The term dictionary is tried in both scripts. Measured: whisper `small`
  returns **Traditional** characters for Mandarin, so a key typed `地规` missed the
  `地規` it was written for — every key now also tries its Simplified/Traditional
  twins (≈50 pairs of characters a lecture actually contains).
- The term dictionary is tried in both scripts. Measured: whisper `small`
  returns **Traditional** characters for Mandarin, so a key typed `地规` missed the
  `地規` it was written for — every key now also tries its Simplified/Traditional
  twins (≈50 pairs of characters a lecture actually contains).
- The manifest reports what the filters did — `transcript: asr · 40 lines · 2
  suspect line(s) dropped · 3 term(s) fixed` — and now counts **cues**, not merged
  segments (a six-card slideshow used to say "1 segments").

### Changed

- Cell boundaries snap to silence midpoints (±1.5 s) once a transcript exists, so
  a card no longer ends in the middle of a sentence; a move that would leave a
  cell under 0.3 s is refused.
- `transcript: <source>` is printed with `file:srt` / `file:vtt` / `file:json`
  when a supplied file was used.

### Rejected after measuring

- Feeding speech density back into the cell count. A talking head is the same
  picture whether or not somebody is talking, so extra cells there buy nothing
  visible — `video_read` is the answer for a face and a voice, and `docs/DESIGN.md`
  §11 records the attempt and why it was dropped.

### Tests

- `219` tests (`node --test test/`), `--smoke` 17/17, `--smoke --host` 32/32, and
  the corpus battery unchanged at 67 cells / 3 648 tokens / F1 0.872 / coverage
  0.963.
## 1.3.0

### Added — speech, by proxy

- `DSH_ASR_CMD` is a speech-to-text hook: `src/asr.js` extracts the window's audio
  once (16 kHz mono PCM), runs the command with `{wav}` and `{out}` substituted,
  parses the SRT it writes or prints, and shifts the cues onto the file's clock so
  a cell at 40:00 is quoted by a line that says 40:00.
- Quotes go to the cell containing each line's midpoint — the rule the subtitle
  track already used, so a sentence is quoted once, on the right tile.
- A configured engine that fails now says so: `asr: unavailable · <reason>`.
  Before, a broken engine looked exactly like a video with no speech.
- `docs/DESIGN.md` §10 records why no model is bundled: package size, licence, and
  the measured 1.7 %-confidence result from the host's own recogniser.

### Fixed — windowed sheets disagreed with themselves

- With `start`/`end`, cell spans were printed on the window's clock while `frame@`
  and the `(cuts)` count were on the file's clock: a window at 40:00 showed
  `00:00.00-00:45.16`, claimed zero cuts, and never quoted a line of dialogue.
  Spans are now shifted once, after planning, in `src/pipeline.js`.

### Measured — two minutes of a 1:59:54 lecture, 2560x1440, 16 threads

| engine | transcript time | two hours, extrapolated | output |
|---|---|---|---|
| `faster-whisper` tiny (int8) | 2.5 s | ~2.5 min | garbled (`選抜` for 选法) |
| `faster-whisper` small (int8) | 15.5 s | ~15 min | readable, Traditional, `地规` for 递推 |
| `System.Speech` zh-CN (host) | 1.4 s | — | one 60-character line at 1.7 % confidence |

`--test` 197 passing. Corpus unchanged: 67 cells, 3 648 vision tokens, micro F1
0.872, coverage 0.963.

## 1.2.2

A 95-second clip of burned-in anime subtitles came back as "no text here". It is
text all the way through, and the two reasons it was missed both matter beyond
that clip.

### Fixed

- **The read crop cut the subtitle off.** It stopped at 91.5% of the frame
  height, which is exactly where burned-in subtitles sit, so a video whose whole
  content is a subtitle line produced nothing and `video_read` honestly reported
  the wrong thing. The crop now trims only the recorder's top bar and keeps the
  bottom edge; the geometric rules that drop a status bar (short line, very close
  to the edge) still apply, and a subtitle is a wide line, so it survives.
- **Short videos are sampled on the clock, not on keyframes.** Keyframes arrive
  every ~5 s, so a 95 s clip that cuts 28 times yielded ~20 looks at ~80 lines of
  dialogue. Under 15 minutes the frames are now sampled every 1.2 s; longer
  material keeps the keyframe path, where the cost is OCR rather than decode.

### Measured

| | 1.2.1 | 1.2.2 |
|---|---|---|
| 95 s subtitled B站 clip | 0 screens, "no text here" | **11 screens, 539 chars, 5.6 s** |
| 36 s text-card clip | 6 screens, 584 chars, 1.1 s | 6 screens, 593 chars, 1.3 s |
| 1:59:54 lecture | 91 s, 56 screens, 7 588 chars | **87 s, 53 screens, 7 663 chars** |

## 1.2.1

Board work — a lecture, a screen share, a whiteboard being written on — is one
shot from beginning to end. The planner took that literally and asked for one
cell, so eleven minutes of a lecture became one picture.

### Fixed

- **A cutless stretch is planned by what changed inside it.** Stretches longer
  than 90 s are now planned on a 12×7 block grid instead of on the whole-frame
  distance: a cell is added for each local peak of frame-to-frame change, at
  least 30 s apart, capped at 24 cells, and only when at least 2 % of the
  picture is new compared with every cell already chosen. Cell spans are rebuilt
  from the midpoints between those frames, so the timeline stays gapless.
- The global distance stays in charge everywhere else: a talking head, a still
  shot, a music video and a slideshow plan exactly as before (67 cells, 3 648
  vision tokens, cut F1 0.872, coverage 0.963 — unchanged).

### Measured

| | 1.2.0 | 1.2.1 |
|---|---|---|
| 19-minute lecture window | 4 cells (2×2) | **22 cells (4×6)** |
| its vision tokens | 1 024 | 1 024 (same sheet budget) |
| corpus battery | — | unchanged |

## 1.2.0

A video is raw material for the work that comes after it, not something to be
watched by proxy. This release follows that: `video_read` stops being a
deduplicator of frames and becomes a text extractor that knows when a screen has
nothing to say, and the plugin accepts a B站 link wherever it accepted a file.

### Added

- **B站 links as a source.** `video_probe`, `video_storyboard`, `video_zoom` and
  `video_read` all accept `bilibili.com/video/BV…`, a bare `BV…` id, an `av` id, or a
  `b23.tv` short link. The video is fetched from the public endpoints (one `durl`
  mp4 that already carries its audio), written to `$DSH_HOME/cache/video-vision/
  bilibili/` with a sidecar, and reused on the next call. `video_probe` on a link
  costs one HTTP call and **no download**.
- `DSH_BILIBILI_COOKIE` / `$DSH_HOME/bilibili-cookies.txt` raises the quality
  (720P anonymously, 1080P with a login cookie), `DSH_BILIBILI_MAX_HEIGHT` caps
  what gets downloaded, and a subtitle track published by B站 is muxed in and
  quoted per cell like any embedded subtitle.
- `video_read` says what it found instead of guessing: under three readable
  screens the result is a header, a note naming the likely reason (hand-writing,
  camera recording, no slides) and a pointer to `video_storyboard`.

### Fixed

- **Screen text is judged by shape, not by length.** A frame of hand-writing
  reaches OCR as eight to ten invented characters in a row, which passed every
  length test. Text that was actually read arrives with punctuation, a decimal
  point, a bracket or an `=`; that is the test now, so `亿天小釒一 0 立去千凸到` is
  dropped while `例题 3 … M(P)=44·m(P)` is kept.
- **Furniture is found by frequency.** The recorder's clock reads a different
  time on every frame, so an exact-line test never fired. Lines that occupy most
  screens are dropped on a digits-stripped key, but only when they are short and
  on nearly every screen, so `例题 1` and `例题 2` stay distinct.
- The header's screen count and the reported statistics now describe the same
  list (the post-dedupe one).

### Measured

| | 1.1.1 | 1.2.0 |
| --- | --- | --- |
| 2-hour lecture (`第二次课`) | 112 s · 56 screens · 10 134 chars | **91 s** · 56 screens · **7 588 chars** |
| 36-second text-card clip | 1.4 s · 6 screens | 1.1 s · 6 screens |
| hand-written summary video (B站, 34 min) | 4 screens of strokes | **0 screens**, one honest note |
| outline of the 2-hour lecture | examples 1-11 | examples 1-11, unchanged |

The character count went down while the screens stayed the same: what left was
the recorder, not the lecture. 188 tests, `--smoke` 17/17 (18 with ffprobe),
`--smoke --host` 32/32 (33 with ffprobe).

## 1.1.1

The first cut of `video_read` was tuned on one lecture, and the tuning was the
kind that looks fine on the file you tuned it on. Run against a second lecture it
kept the recorder's tab strip as if it were a slide title, and it dropped whole
screens whose text had come out of a hand-written frame.

### Fixed

- **Chrome removal is geometric, not a crop.** The slide area used to be a fixed
  crop of the frame, learned from the first lecture; on the next one it sliced
  the first character off a card whose text started at the left edge. The crop is
  now a conservative top/bottom trim, and the real filtering happens per OCR
  line: a short line near the top edge is a tab strip, a short line at the bottom
  is a status bar, a screen made of many very short lines is a chat panel, and a
  screen with no line long enough to be a sentence is a frame of hand-writing.
  None of those rules know which app was on screen.
- **Duplicates are merged twice.** OCR noise makes two readings of the same slide
  differ; the first pass merges at the documented similarity, a second pass at a
  looser one catches the pair whose second reading came out degraded.
- **Frames are grabbed a beat after the keyframe.** A keyframe can land
  mid-scroll or mid-dissolve, and OCR of a half-drawn screen is garbage that
  survives every similarity test.
- The chrome list matches case-insensitively — `Goodnotes` is not `goodnotes`.
- The screen count in the header was the pre-dedupe count.

### Measured

| | 1.1.0 | 1.1.1 |
| --- | --- | --- |
| 1:59:54 lecture, wall clock | 87 s | 112 s |
| screens quoted | 146 (with tab strips) | 56 |
| characters | 16 817 | 10 134 |
| examples found in the outline | 11 | 11 |

The older build quoted more text because it was quoting the recorder too, and
because it kept several degraded readings of the same slide. The number that
matters is the last row.

### Tests

174 tests (`node --test test/`), `--smoke` 18/18, `--smoke --host` 33/33.

## 1.1.0

### Added

- **`video_read` — read a video as timestamped text.** When the content is text
  on the screen (lectures, slide decks, screen recordings, coding sessions) a
  picture of it is the wrong representation: the contact sheet is capped at 1024
  vision tokens and unreadable at that size, while the text is what a model can
  quote, search and rewrite. The tool decodes **only keyframes**
  (`-skip_frame nokey`, ~6x cheaper than a full decode), clusters them by
  picture change, OCRs the slide area of each cluster once, merges screens that
  say the same thing (character-bigram similarity, because OCR noise makes exact
  matching useless), and emits an outline plus `[mm:ss] text` lines.

  Measured on a real 1:59:54 lecture at 2560x1440: **87 s**, 975 keyframes →
  388 clustered screens → 146 screens, **16.8k characters** — against 163 s for
  the same file through `video_storyboard`, which returns one 1024-token sheet
  whose slide text is too small to read.

  OCR uses the Windows engine (`Windows.Media.Ocr`, no download, no model). On
  other platforms the tool reports that it is unavailable and the picture path
  remains the answer.

### Changed

- The tool descriptions say which path to use when: `video_read` for text,
  `video_storyboard`/`video_zoom` when the picture *is* the content.

### Tests

- 171 tests (10 new for the pure parts of `read.js`: OCR cleanup, UI-chrome
  rejection, bigram similarity, screen merging, outline extraction, block-grid
  change).

## 1.0.1

### Fixed

- **A long file failed to probe when only ffmpeg was available.** The banner
  fallback ran `ffmpeg -i … -f null -`, and the null muxer decodes the whole
  input before discarding it — 130 s on a two-hour lecture against a 60 s
  budget, so the call died. It now passes `-t 0` and stops once the input is
  open, because every line the parser reads is already on stderr. Same 2 h
  file: **226 ms** end-to-end probe (measured on a 7053 s / 2 h composite with
  no ffprobe present). A full storyboard of that file now completes in 38.5 s.
- The banner parser let a **later audio stream overwrite the first**, so a file
  carrying AAC followed by a PCM/commentary track was reported as
  `pcm_s16le`. It is first-wins now, matching the rule already used for video
  streams. Both defects are pinned by `test/media.test.mjs`.
- `bin/install.mjs` no longer trusts a `node_modules` entry that resolves to a
  *different* checkout — it relinks it, the same way a stale `link:` dependency
  is repointed. Leaving it alone made edits appear to do nothing.
- `bin/install.mjs` removes a link with `rmdir`/`unlink` instead of a recursive
  delete. On Windows a recursive delete follows the junction and empties the
  checkout it was replacing, which is the one thing an installer must not do.
  Both paths are covered by `test/install.test.mjs`.

`161` tests, `--smoke` 16/16 (17 with ffprobe), `--smoke --host` 29/29.

## 1.0.0

First release. Drop-in replacement for `dsh-video-storyboard` / `dsh-video-understand`
(the tool names `video_probe`, `video_storyboard`, `video_zoom` and their argument
shapes are unchanged).

### Fixed after release-candidate testing
- `video_probe` returned the wrong shape (`{ text: { text, probe, plan } }`);
  the host answered `"value.text" must be a string`. The tool now returns the
  documented `{ text, images }`, and `bench/hostcheck.mjs` exercises the SUCCESS
  path of all three tools against the host's own schema engine, which is what
  would have caught it.
- `scanShots` treated `duration` as an absolute end time, so a windowed call
  (`start: 4, duration: 5`) scanned one second instead of five.
- Subtitle quoting never ran on a real file: `extractSubtitles` gated on
  `probe.streams`, and `probeVideo` returns only `hasSubtitle`. Fixed, and the
  branch is now covered by a test that passes a probe without a `streams` array.
- Dialogue was quoted on every cell it touched, because cues were grouped into
  sentences before attribution. Each raw cue is now attributed to the cell whose
  span holds its **midpoint** — a line that straddles a cut is quoted once.
- Speech detection called any sustained loud span "speech" (a music-only clip
  reported `speech 45 %`). Spans now carry a syllabic-modulation test
  (`levelSd >= 4 dB`, `hfSd >= 0.05`), so the manifest says
  `no speech · sound 86 %` over a music bed and `speech 48 %` over narration.
- The cell count was a quota. It is now a legibility limit: every shot gets a
  cell while cells stay at least 240 px wide, so a 25-shot montage shows 25 cells
  at the same 1 024 tokens a 4-cell sheet used to cost, and a portrait clip still
  merges. Corpus coverage moved 0.941 → 0.963.
- An unreadable file used to produce 400 characters of ffmpeg banner; errors are
  now `no video stream (this file is audio only)`, `file not found`,
  `not a file (it is a directory)`, and the path is stat-ed before any spawn.
- `runZoom` read `cell.data` where the compositor reads `cell.frame`, so every
  zoom sheet came back flat black; the `wanted` count also crashed on a TDZ
  reference before the fix.
- The sharpest-frame picker chose muzzle flashes and other exposure outliers;
  frames more than 1.8 MAD from a shot's median brightness are now demoted.
- `suggestDetail` claimed 20 cells / 1024 tokens for a 3 s clip; it now scales
  at 6 s per cell with a floor of 3.

### Docs and evidence
- `docs/EVIDENCE.md`: measured latency, sheet geometry, token cost, per-clip cut
  and coverage tables, edge cases and a threats-to-validity section.
- `docs/REAL-WORLD.md`: three unmodified captures from the machine, with what
  was actually readable in the rendered sheets.
- `docs/DESIGN.md`: why each threshold exists, including the clips that forced
  it.

### Analysis
- One ffmpeg pass reduces each frame to a 12x7 grid of luma **and** chroma block
  means, plus sharpness / detail / brightness scalars.
- Cut threshold derived per clip from `max(1.6, median + 7*MAD, p99*0.22)` — a
  fixed floor silently deleted real cuts from low-contrast footage.
- Five-way jump classification: `cut` / `partial` / `overlay` / `light` / `noise`.
- Flash rejection by picture restoration; dissolve detection as a transient
  (change that stops afterwards); hard cuts and flashes excluded from dissolve
  windows so a real cut cannot grow a phantom fade next to it.
- Optional deinterlace (`bwdif`) for interlaced sources.

### Layout
- The sheet is sized **per cell** (`sheetPixelsFor`), because the host bills an
  image by area, not by cell count: more moments cost the same tokens until a
  cell stops being legible.
- One cell per shot is the floor; shots are merged by weight when they outnumber
  the budget; extra cells must be 2.5x more novel than the "same picture"
  threshold.
- Cells are placed on the sharpest, most central frame of their span.
- Grid shape solved together with cell size from the area budget.

### Decoding and output
- Batched extraction: six cells per ffmpeg process, three processes in flight,
  one retry 80 ms earlier for stragglers.
- Pure-JS PNG encoder (no image library), hairline gutters, small corner badges,
  optional audio envelope band.
- Manifest: one fixed-shape line per cell, centisecond timecodes, no prose,
  `=cell N` for duplicate pictures, `textOnly` + `cellRange` paging, `24000`
  character budget.
- Analysis cache (6 entries, keyed by path+size+mtime+window+detail) so paging
  and repeats cost only formatting.

### Audio
- 8 kHz mono decode: 40 ms RMS envelope, speech spans, onsets, silences,
  loudness. No ASR model, no network, no key.
- Real subtitle tracks are extracted and quoted per cell.

### Evidence
- Nine synthetic clips with frame-exact ground truth (`bench/corpus`), a
  13-minute composite, and three unmodified screen captures from this machine.
- `bench/final.mjs` and `bench/accuracy.mjs` share a token estimator and a 0.5 s
  cut scorer against the corpus ground truth.
- `bin/selfcheck.mjs --smoke --host` runs 29 assertions, including the host's
  own `assertSupportedJsonSchema` and `validateJsonSchemaValue` on every tool.
- `node --test test/` — 161 tests, no network, hermetic temp dir.
