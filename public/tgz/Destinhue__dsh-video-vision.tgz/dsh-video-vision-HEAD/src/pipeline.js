/**
 * pipeline.js — the orchestration: probe → analyse → choose → decode → draw →
 * text.
 *
 * The shape of the work is chosen for wall-clock time, because a video tool
 * that takes 40 s to answer does not get used:
 *
 *   probe      ffprobe JSON (or the ffmpeg banner when ffprobe is absent)
 *   audio  ┐   decoded to 8 kHz mono and analysed here
 *   scan   ┘   one rawvideo pass at 96x54; cut detection, frame vectors
 *   plan       cells chosen from the scan, no extra decode
 *   decode     one ffmpeg process per group of cells, concurrent
 *   draw       pure JS compositing, no image library
 *
 * Both ffmpeg passes run at the same time, so a 5-minute film costs roughly one
 * decode of its own length rather than two.
 */

import { run, probeVideo, findFfmpeg, findFfprobe, displayAspect, uprightSize } from './media.js';
import { keyframeGap, keyframeMode, scanShots } from './scan.js';
import {
  planCells, planGrid, cellReadability, sheetPixelsFor, sheetPixelsForCells,
  DETAIL_PRESETS, suggestDetail, bestFrameIndex,
} from './layout.js';
import { extractCells, extractFrame } from './frames.js';
import { cellScale, zoomMarkers, ZOOM_MIN_SCALE } from './detail.js';
import { composeSheet } from './sheet.js';
import { encodePng } from './png.js';
import { analyzeAudio, extractSubtitles, groupCues, snapCellsToSpeech, timecode } from './timeline.js';
import { formatManifest } from './manifest.js';
import { loadTranscriptFile } from './transcript.js';
import { planOutline, outlineRows, outlineReport, spanOverlap } from './outline.js';
import { asrAvailable, asrCues, loadAsrSettings } from './asr.js';
import { isBilibili, bilibiliRejection, bilibiliFile, bilibiliStream, biliStreamMode, biliStreamLimit, bilibiliView, bilibiliPlay, bilibiliSubtitles, describeBilibili } from './bili.js';

export { DETAIL_PRESETS };
export { biliStreamMode, biliStreamLimit };

const MAX_CELLS_HARD = 24;

/**
 * A B站 link is not a path, so anything that decodes has to wait for the
 * download. `video_probe` deliberately does not call this: asking what a video
 * is should cost one HTTP request, not a hundred megabytes.
 */
async function resolveSource(rawInput, { ffmpegPath, signal, log } = {}) {
  if (!isBilibili(rawInput)) {
    // A B站 page that is not one video (an episode, a collection, a live room)
    // would otherwise fall through to the file path and be reported as a
    // missing file, which is true and useless.
    const why = bilibiliRejection(rawInput);
    if (why) throw new Error(why);
    return { path: rawInput, meta: null, download: null, stream: false };
  }
  const mode = biliStreamMode();
  if (mode !== 'off') {
    try {
      const view = await bilibiliView(rawInput, { signal });
      const short = Number(view.duration || 0) <= biliStreamLimit();
      if (mode === 'on' || short) {
        const s = await bilibiliStream(view, { signal, maxHeight: biliMaxHeight() });
        if (log) log(`streaming ${s.label} · ${Math.round((s.size || 0) / 1024)} KB · no download`);
        return { path: s.url, meta: s.meta, download: null, stream: true };
      }
      if (log) log(`long video (${Math.round(Number(view.duration || 0))} s) — downloading so later calls are local`);
    } catch (error) {
      if (log) log(`stream unavailable (${error.message}); downloading instead`);
    }
  }
  const file = await bilibiliFile(rawInput, { ffmpegPath, signal, log, maxHeight: biliMaxHeight() });
  return { path: file.path, meta: file.meta, download: file, stream: false };
}

/**
 * Probe for the two picture tools.
 *
 * A file with no video stream is not their input at all, so the media.js error
 * ("this file is audio only") is rewritten to name the tool that *can* read it
 * instead of leaving the model to guess whether the file was broken.
 */
async function probeForPicture(input, { ffmpegPath, ffprobePath }) {
  try {
    return await probeVideo(input, { ffmpegPath, ffprobePath });
  } catch (error) {
    const message = String(error?.message ?? error);
    if (!/audio only/i.test(message)) throw error;
    const next = new Error(`${message} — there is no picture to sample; video_read transcribes audio`);
    next.detail = error?.detail;
    throw next;
  }
}

/** Highest quality worth downloading; 1080p by default, override with the env. */
export function biliMaxHeight(env = process.env) {
  const n = Number(env.DSH_BILIBILI_MAX_HEIGHT);
  return Number.isFinite(n) && n >= 144 ? Math.floor(n) : 1080;
}

function sourceTitle(meta) {
  if (!meta) return '';
  const part = meta.pages > 1 && meta.partTitle ? ` · P${meta.page} ${meta.partTitle}` : '';
  return `${meta.title || meta.bvid}${part}`;
}

/**
 * Analysis cache. A long film is scanned once and re-used by every later call
 * in the session — a textOnly page-through then costs nothing but formatting,
 * and a zoom over a window the storyboard already covered skips its scan.
 * Keyed by identity (path, size, mtime) plus the window, so an edited or
 * replaced file never returns a stale plan.
 */
const CACHE_LIMIT = 6;
const analysisCache = new Map();

async function identityOf(input) {
  try {
    const { stat } = await import('node:fs/promises');
    const st = await stat(input);
    return `${input}|${st.size}|${Math.round(st.mtimeMs)}`;
  } catch {
    return `${input}|remote`;
  }
}

function cacheGet(key) {
  const hit = analysisCache.get(key);
  if (!hit) return null;
  analysisCache.delete(key);
  analysisCache.set(key, hit);
  return hit;
}

function cacheSet(key, value) {
  analysisCache.set(key, value);
  while (analysisCache.size > CACHE_LIMIT) {
    const oldest = analysisCache.keys().next().value;
    analysisCache.delete(oldest);
  }
}

/**
 * @param {object} opts
 * @param {string} opts.input          local path or ffmpeg-readable URL
 * @param {string} [opts.detail]       low | auto | high
 * @param {number} [opts.maxCells]
 * @param {number} [opts.start]
 * @param {number} [opts.end]
 * @param {number} [opts.duration]
 * @param {boolean} [opts.textOnly]    text index only: no decode, no image
 * @param {number[]} [opts.cellRange]  [first,last] 1-based cells to list
 * @param {boolean} [opts.transcript]  pull an embedded subtitle track (default true)
 * @param {boolean} [opts.band]        draw the audio band under the grid
 * @param {AbortSignal} [opts.signal]
 */
/**
 * The sentence a storyboard index prints when the scan says the marks are the
 * content. Exported so the wording can be tested without decoding a clip.
 */
export function textMotionNote(textMotion) {
  if (!textMotion) return null;
  return `${textMotion.reason} — video_read reads those marks as text, at no image cost; `
    + 'the cells below still say when each stretch begins';
}

export async function runStoryboard(opts) {
  const t = {};
  const started = Date.now();
  let clock = started;
  const mark = (k) => { t[k] = Date.now() - clock; clock = Date.now(); };

  const ffmpegPath = opts.ffmpegPath ?? await findFfmpeg();
  if (!ffmpegPath) throw new Error('ffmpeg not found — set DSH_FFMPEG_PATH or install ffmpeg');
  const ffprobePath = opts.ffprobePath ?? await findFfprobe();

  // ---- 0. source: a B站 link becomes a local file before anything else
  const source = await resolveSource(opts.input, { ffmpegPath, signal: opts.signal, log: opts.log });
  const input = source.path;
  mark('source');

  // ---- 1. probe
  const probe = await probeForPicture(input, { ffmpegPath, ffprobePath });
  mark('probe');
  const dur = probe.duration || 0;
  const start = clamp(Number(opts.start) || 0, 0, Math.max(0, dur - 0.2));
  const endAsked = Number(opts.end);
  const end = Number.isFinite(endAsked) && endAsked > start
    ? clamp(endAsked, start + 0.2, dur)
    : (Number(opts.duration) > 0 ? Math.min(dur, start + Number(opts.duration)) : dur);
  const window = Math.max(0.2, end - start);
  const notes = windowNotes({
    duration: dur, start, end,
    askedStart: Number(opts.start) || 0,
    askedEnd: Number(opts.end),
    askedDuration: Number(opts.duration),
  });

  const aspect = Number.isFinite(probe.aspect) && probe.aspect > 0
    ? probe.aspect
    : displayAspect(probe.coded.width, probe.coded.height, probe.sar, probe.rotation);
  const upright = uprightSize(probe.coded.width, probe.coded.height, probe.rotation);

  // ---- 2. analysis, reused across calls when the file has not changed
  const identity = await identityOf(input);
  const key = `${identity}|${start.toFixed(2)}|${window.toFixed(2)}|${opts.detail ?? 'auto'}|${opts.maxCells ?? ''}|${opts.pick ?? 'sharp'}`;
  let analysis = cacheGet(key);
  const fromCache = Boolean(analysis);

  if (!analysis) {
    // A two-hour recording costs a minute and a half to decode frame by frame
    // and then plans a sheet of twenty pictures. Reading keyframes only measured
    // 2.7x faster on exactly that file; it is tried only when the keyframes are
    // far enough apart to be worth skipping, and never on a short window.
    const asked = ['off', 'force'].includes(opts.keyframes) ? opts.keyframes
      : (['off', 'force'].includes(process.env.DSH_SCAN_KEYFRAMES) ? process.env.DSH_SCAN_KEYFRAMES : 'auto');
    const gapInfo = asked === 'off' ? { gap: null } : await keyframeGap({
      input, ffprobePath, signal: opts.signal,
    }).catch(() => ({ gap: null }));
    const mode = keyframeMode({ asked, duration: window, gap: gapInfo?.gap ?? null });
    const [scan, audio] = await Promise.all([
      scanShots({
        input, ffmpegPath, fps: probe.fps || 25, aspect,
        start, duration: window, signal: opts.signal,
        keyframes: mode.keyframes,
      }),
      probe.hasAudio
        ? analyzeAudio({ input, ffmpegPath, signal: opts.signal, duration: window, run })
          .catch((error) => ({ hasAudio: false, error: String(error?.message ?? error) }))
        : Promise.resolve({ hasAudio: false, skipped: true }),
    ]);
    analysis = { scan, audio, start, window, at: Date.now(), keyframeMode: mode, keyframeGap: gapInfo?.gap ?? null };
    cacheSet(key, analysis);
  }
  const { scan, audio } = analysis;
  // The sheet is still the right map of *when*; it is the wrong place to look
  // for *what*. Say so here, before the model concludes the clip is empty.
  const textNote = textMotionNote(scan.textMotion);
  if (textNote) notes.push(textNote);
  if (scan.keyframes) {
    const gap = analysis.keyframeGap;
    notes.push(`analysis read keyframes only${gap ? ` (one every ${gap.toFixed(1)} s)` : ''} — `
      + 'a change shorter than that gap is not seen; set DSH_SCAN_KEYFRAMES=off to decode every frame');
  }
  mark('analyse');

  // ---- 3. transcript, in the order of who pays for it
  //
  //   1. `transcriptFile` - the caller already has it. Free and exact.
  //   2. the container's subtitle track - free, exact, and often already there.
  //   3. ASR - costs a decode, a model run, and somebody's accuracy.
  let transcript = analysis.transcript ?? { cues: [], segments: [], source: null };
  let asrNote = null;
  if (opts.transcript !== false && opts.transcriptFile && !(transcript.cues && transcript.cues.length)) {
    const fromFile = loadTranscriptFile(opts.transcriptFile);
    transcript = { cues: fromFile.cues, segments: groupCues(fromFile.cues), source: `file:${fromFile.source}` };
    analysis.transcript = transcript;
  }
  if (opts.transcript !== false && probe.hasSubtitle && !analysis.transcript) {
    try {
      const subs = await extractSubtitles({ input, ffmpegPath, signal: opts.signal, run, probe });
      // Keep the RAW cues: the manifest attributes each line to the cell that
      // contains its midpoint, so one line is quoted once. `groupCues` merges
      // neighbouring lines into sentences and is only good for a summary count.
      if (subs.cues.length) {
        transcript = { cues: subs.cues, segments: groupCues(subs.cues), source: 'subtitle-track' };
      }
    } catch { /* a broken subtitle track must not fail the tool */ }
    analysis.transcript = transcript;
  }
  // ---- 3b. speech to text, only when nobody else already said it
  //
  // A subtitle track is a transcript someone else paid for: cheaper and far more
  // accurate than any recogniser. ASR is the fallback for the file that has
  // audio and no captions, and it is off unless `DSH_ASR_CMD` names an engine
  // (see src/asr.js for why the engine is not bundled).
  if (opts.transcript !== false && opts.asr !== false
    && !(transcript.cues && transcript.cues.length)
    && probe.hasAudio && asrAvailable()) {
    try {
      const settings = loadAsrSettings();
      const heard = await asrCues({
        ffmpegPath, input, start, end: start + window, signal: opts.signal, settings,
      });
      if (heard.cues.length) {
        transcript = {
          cues: heard.cues,
          segments: groupCues(heard.cues),
          source: 'asr',
          dropped: heard.dropped?.length ?? 0,
          terms: heard.terms ?? 0,
          chunks: heard.chunks ?? 1,
          chunked: Boolean(heard.chunked),
        };
        analysis.transcript = transcript;
      }
      if (heard.reason) asrNote = heard.reason;
      if (heard.dropped?.length) {
        // Reported, not hidden: a filter nobody can audit is indistinguishable
        // from a recogniser that stopped working.
        asrNote = `${heard.dropped.length} suspect segment(s) dropped`;
      }
    } catch (error) {
      asrNote = String(error?.message ?? error);
    }
  }
  mark('subtitle');

  // ---- 4. choose cells
  const detail = DETAIL_PRESETS[opts.detail] ? opts.detail : 'auto';
  // Leave `maxCells` unset unless the caller asked: the plan then decides from
  // the pixel cap and the picture's aspect how many moments still stay legible.
  const maxCells = opts.maxCells
    ? clamp(Math.round(Number(opts.maxCells)), 1, MAX_CELLS_HARD)
    : undefined;
  if (Number(opts.maxCells) > MAX_CELLS_HARD) {
    notes.push(`cells ${Math.round(Number(opts.maxCells))} capped at ${MAX_CELLS_HARD}`);
  }
  const plan = planCells({
    scan, audio, detail, maxCells, aspect: probe.aspect, srcHeight: upright.height,
    dedupe: opts.dedupe === 'global' ? 'global' : true,
  });
  if (plan.folded > 0) {
    const where = (plan.foldedCells ?? []).slice(0, 3)
      .map((f) => `${timecode(f.t0)}-${timecode(f.t1)} = cell ${f.cell}`).join(', ');
    notes.push(`${plan.folded} cell(s) dropped as repeats${where ? ` — ${where}` : ''}; pass dedupe "shots" to keep them`);
  }
  if (plan.reduced) {
    notes.push(`sheet reduced from ${plan.reduced.from} to ${plan.reduced.to} cells so text stays legible`);
  }
  if ((opts.pick ?? 'sharp') === 'middle') {
    const startT = scan.start ?? 0;
    for (const c of plan.cells) {
      const mid = (c.t0 + c.t1) / 2;
      c.frameIndex = Math.max(0, Math.min(scan.frames - 1, Math.round((mid - startT) * scan.effFps)));
      c.frameT = +(startT + (c.frameIndex + 0.5) / scan.effFps).toFixed(3);
    }
  }
  // Cell spans come out of the planner on the window's clock (0 = the first
  // frame we scanned). Everything downstream — the manifest, the cut counts and
  // the dialogue quotes — speaks the file's clock, so shift once here rather
  // than remembering to add `start` in three places.
  const shift = scan.start ?? 0;
  if (shift) {
    for (const c of plan.cells) {
      c.t0 = +(c.t0 + shift).toFixed(3);
      c.t1 = +(c.t1 + shift).toFixed(3);
    }
  }
  // Dialogue already knows where the sentences end. Move the boundaries there
  // rather than a tenth of a second into the next word: a card whose span cuts a
  // sentence in half quotes half a sentence on both cards.
  const snapped = transcript?.cues?.length
    ? snapCellsToSpeech(plan.cells, transcript.cues)
    : 0;
  if (snapped) plan.speechSnapped = snapped;

  if (plan.cells.length === 0) {
    return { empty: true, probe, scan, reason: scan.degraded ?? 'no cells' };
  }

  const only = Array.isArray(opts.cellRange) && opts.cellRange.length >= 2
    ? { from: Math.max(1, Math.round(opts.cellRange[0])), to: Math.round(opts.cellRange[1]) }
    : null;
  const listed = only
    ? plan.cells.filter((c) => c.index >= only.from && c.index <= only.to)
    : plan.cells;

  const grid = planGrid(plan.cells.length, aspect, {
    pixels: sheetPixelsForCells(plan.cells.length, detail, { aspect, srcHeight: upright.height }),
  });
  mark('plan');

  const base = {
    name: source.meta ? sourceTitle(source.meta) : basename(input),
    probe: { ...probe, width: upright.width, height: upright.height },
    scan, plan, audio, transcript, notes,
    asrNote: asrNote ?? undefined,
  };

  // ---- 5. textOnly: skip every pixel, keep every timestamp
  if (opts.textOnly) {
    const manifest = formatManifest({ ...base, sheet: null, only: listed.map((c) => c.index) });
    return {
      empty: false, textOnly: true, png: null,
      sheet: { grid, cells: plan.cells.length },
      manifest: `${shotHeader(scan, plan, start, window)}\n${manifest.text}`,
      scan, plan, probe, audio, transcript, fromCache, notes,
      timings: { ...t, total: Date.now() - started },
    };
  }

  // ---- 6. decode the chosen frames
  // A cell this small cannot hold a subtitle, so this is the only case where
  // measuring "what did the shrink eat" can change an answer — and therefore the
  // only case where it costs anything: a readable sheet decodes exactly as before.
  const scale = cellScale(upright.height, grid.cellH);
  const wantZoom = (opts.zoomMarkers ?? process.env.DSH_VIDEO_ZOOM_MARKERS !== '0') && scale >= ZOOM_MIN_SCALE;
  const extraction = await extractCells({
    input, ffmpegPath, cells: plan.cells,
    cellW: grid.cellW, cellH: grid.cellH, signal: opts.signal,
    oversample: wantZoom ? 2 : 1,
    measure: wantZoom,
  });
  mark('decode');

  // ---- 7. draw and encode
  const band = opts.band ?? (detail !== 'low' && audio?.envelope?.length > 0);
  const sheetPixels = composeSheet({
    grid,
    cells: plan.cells.map((c) => {
      const f = extraction.frames.get(c.index);
      return { index: c.index, frame: f?.data, width: f?.width, height: f?.height, dupOf: c.dupOf };
    }),
    audio: band
      ? {
        envelope: audio.envelope,
        speech: audio.speech ?? [],
        cuts: scan.cuts ?? [],
        t0: 0,
        t1: (audio.envelope.length / audio.binsPerSecond) || window,
      }
      : null,
  });
  const png = encodePng(sheetPixels.data, sheetPixels.width, sheetPixels.height);
  mark('draw');

  // Which cells are finer than the sheet can show: measured while decoding, so
  // the client can zoom three cells instead of re-reading twenty-two.
  const zoom = zoomMarkers(extraction.metrics, scale);

  const manifest = formatManifest({
    ...base,
    sheet: { pages: [{ grid }] },
    zoom,
    only: only ? listed.map((c) => c.index) : null,
  });

  return {
    empty: false,
    png,
    sheet: { grid, width: sheetPixels.width, height: sheetPixels.height, bytes: png.length },
    manifest: manifest.text,
    truncated: manifest.truncated,
    scan, plan, probe, audio, transcript, extraction, fromCache, zoom, notes,
    readability: cellReadability(grid.cellW, grid.cellH, upright.height),
    timings: { ...t, total: Date.now() - started },
    visionTokens: estimateVisionTokens(sheetPixels.width, sheetPixels.height),
  };
}

/** A one-line "where am I in the film" header for text-only pages. */
function shotHeader(scan, plan, start, window) {
  const s = scan.summary ?? {};
  return `${plan.cells.length} cells · ${s.shots ?? 0} shots over ${timecode(start)}-${timecode(start + window)} · median shot ${(s.medianShot ?? 0).toFixed(2)}s`;
}

/* ------------------------------------------------------------------- zoom */

/** Zoom: one window, few cells, everything bigger. */
export async function runZoom(opts) {
  const started = Date.now();
  const ffmpegPath = opts.ffmpegPath ?? await findFfmpeg();
  if (!ffmpegPath) throw new Error('ffmpeg not found — set DSH_FFMPEG_PATH or install ffmpeg');
  const ffprobePath = opts.ffprobePath ?? await findFfprobe();
  const source = await resolveSource(opts.input, { ffmpegPath, signal: opts.signal, log: opts.log });
  const input = source.path;
  const probe = await probeForPicture(input, { ffmpegPath, ffprobePath });
  const dur = probe.duration || 0;
  const start = clamp(Number(opts.start) || 0, 0, Math.max(0, dur - 0.1));
  const endAsked = Number(opts.end);
  const end = Number.isFinite(endAsked) && endAsked > start
    ? clamp(endAsked, start + 0.2, dur)
    : (Number(opts.duration) > 0 ? Math.min(dur, start + Number(opts.duration)) : Math.min(dur, start + 20));
  const window = Math.max(0.2, end - start);
  const notes = windowNotes({
    duration: dur, start, end,
    askedStart: Number(opts.start) || 0,
    askedEnd: Number(opts.end),
    askedDuration: Number(opts.duration),
  });
  const aspect = displayAspect(probe.coded.width, probe.coded.height, probe.sar, probe.rotation);
  const uprightH = uprightSize(probe.coded.width, probe.coded.height, probe.rotation).height;
  const wanted = clamp(Math.round(Number(opts.cells) || 3), 1, 9);
  if (Number(opts.cells) > 9) notes.push(`cells ${Math.round(Number(opts.cells))} capped at 9`);
  const pixels = sheetPixelsFor(wanted, 'ultra');
  let grid;
  let scan = null;
  let frames;

  if (wanted === 1) {
    grid = planGrid(1, aspect, { pixels });
    const at = opts.at != null ? clamp(Number(opts.at), start, start + window) : start + window / 2;
    const f = await extractFrame({
      input, ffmpegPath, t: at, width: grid.cellW, height: grid.cellH, signal: opts.signal,
    });
    frames = [{ index: 1, at, t0: null, t1: null, data: f.data, width: grid.cellW, height: grid.cellH }];
  } else {
    const key = `${await identityOf(input)}|${start.toFixed(2)}|${window.toFixed(2)}|zoom`;
    const cached = cacheGet(key);
    scan = cached?.scan ?? await scanShots({
      input, ffmpegPath, fps: probe.fps || 25, aspect,
      start, duration: window, signal: opts.signal, fullRate: true,
    });
    if (!cached) cacheSet(key, { scan, audio: { hasAudio: false }, start, window, at: Date.now() });
    // A zoom is not a storyboard: it means "show me N moments of this window",
    // so the window is cut into N equal slices and each slice contributes its
    // sharpest frame. Semantic planning would happily answer with one cell for
    // a single-shot window, which defeats the purpose.
    const effFps = scan.effFps || probe.fps || 25;
    const slice = window / wanted;
    const last = Math.max(0, scan.frames - 1);
    const use = [];
    for (let k = 0; k < wanted; k += 1) {
      const rel0 = slice * k;
      const rel1 = Math.min(window, rel0 + slice);
      const i0 = clamp(Math.round(rel0 * effFps), 0, last);
      const i1 = clamp(Math.round(rel1 * effFps) - 1, i0, last);
      const pick = bestFrameIndex(i0, i1, scan.vectors);
      use.push({
        index: k + 1,
        t0: rel0,
        t1: rel1,
        frameIndex: pick.i,
        frameT: +(start + (pick.i + 0.5) / effFps).toFixed(3),
      });
    }
    grid = planGrid(use.length, aspect, { pixels });
    const ex = await extractCells({
      input, ffmpegPath, cells: use, cellW: grid.cellW, cellH: grid.cellH, signal: opts.signal,
    });
    frames = use.map((c) => {
      const f = ex.frames.get(c.index);
      return {
        index: c.index, at: c.frameT,
        t0: c.t0 == null ? null : start + c.t0,
        t1: c.t1 == null ? null : start + c.t1,
        frame: f?.data, width: f?.width, height: f?.height,
      };
    });
  }

  const sheetPixels = composeSheet({ grid, cells: frames, audio: null });
  const png = encodePng(sheetPixels.data, sheetPixels.width, sheetPixels.height);

  const lines = [
    `${source.meta ? sourceTitle(source.meta) : basename(input)} · window ${timecode(start)}-${timecode(start + window)} · ${grid.cols}x${grid.rows} ${grid.cellW}x${grid.cellH}${scan ? ` · ${scan.summary.shots} shots` : ''}`,
    'cols: cell · frame@ · span',
  ];
  for (const f of frames) {
    lines.push(`${f.index} @${timecode(f.at)}${f.t0 != null ? ` ${timecode(f.t0)}-${timecode(f.t1)}` : ''}`);
  }
  for (const n of notes) lines.push(`note: ${n}`);

  return {
    png,
    sheet: { grid, width: sheetPixels.width, height: sheetPixels.height, bytes: png.length },
    manifest: lines.join('\n'),
    probe, notes,
    readability: cellReadability(grid.cellW, grid.cellH, uprightH),
    timings: { total: Date.now() - started },
    visionTokens: estimateVisionTokens(sheetPixels.width, sheetPixels.height),
  };
}

/* ------------------------------------------------------------------ probe */

/** Metadata plus a reading plan. No decode, no image. */
export async function runProbe(opts) {
  const started = Date.now();
  if (isBilibili(opts.input)) return await probeBilibili(opts.input, started);
  const why = bilibiliRejection(opts.input);
  if (why) throw new Error(why);
  const ffmpegPath = opts.ffmpegPath ?? await findFfmpeg();
  const ffprobePath = opts.ffprobePath ?? await findFfprobe();
  if (!ffmpegPath && !ffprobePath) throw new Error('no ffmpeg and no ffprobe found');
  const probe = await probeVideo(opts.input, { ffmpegPath, ffprobePath, allowAudioOnly: true });
  if (probe.hasVideo === false) return audioProbe(opts.input, probe, started);
  const upright = uprightSize(probe.coded.width, probe.coded.height, probe.rotation);
  const plan = suggestDetail({
    duration: probe.duration,
    aspect: probe.aspect || (upright.width / upright.height),
    hasAudio: probe.hasAudio,
    hasSubtitle: probe.hasSubtitle,
  });

  const lines = [
    `${basename(opts.input)} · ${timecode(probe.duration, { hours: true })} · ${upright.width}x${upright.height} · ${Math.round(probe.fps)}fps · ${probe.videoCodec}`,
  ];
  const bits = [];
  if (probe.rotation) bits.push(`rotation ${probe.rotation}°`);
  if (probe.bitrate) bits.push(`${(probe.bitrate / 1e6).toFixed(1)} Mbps`);
  bits.push(probe.hasAudio ? `audio ${probe.audioCodec ?? 'yes'}` : 'no audio');
  if (probe.hasSubtitle) bits.push('subtitle track present');
  lines.push(bits.join(' · '));
  lines.push(`plan: ${plan.detail} detail · ${plan.cells} cells · ~${plan.tokens} vision tokens · ${plan.windows} call${plan.windows > 1 ? 's' : ''}`);
  if (plan.note) lines.push(plan.note);
  lines.push(`elapsed ${Date.now() - started}ms`);

  return { text: lines.join('\n'), probe, plan };
}

/**
 * `video_probe` on a file with no picture.
 *
 * The useful answer is not "no video stream": it is the length, the codec, and
 * which of the other tools can still read the file. video_read can — a subtitle
 * track first, an ASR engine next, a transcript file instead of both.
 */
function audioProbe(input, probe, started) {
  const kbps = probe.bitrate ? ` · ${Math.round(probe.bitrate / 1000)} kbps` : '';
  const lines = [
    `${basename(input)} · ${timecode(probe.duration, { hours: true })} · audio only · ${probe.audioCodec ?? 'unknown codec'}${kbps}`,
    'no video stream — there is no picture to sample, so video_storyboard and video_zoom do not apply',
    'next: video_read quotes this file — a subtitle track first, then DSH_ASR_CMD — or pass a transcript file to skip the engine',
  ];
  if (probe.hasSubtitle) lines.push('subtitle track present: video_read quotes it as-is, no engine needed');
  lines.push(asrAvailable()
    ? 'transcribe: an ASR engine is configured, so video_read can quote the speech'
    : 'transcribe: no ASR engine configured — set DSH_ASR_CMD (or ~/.dsh/asr.json {"cmd": "..."}), or pass a transcript file to video_read');
  lines.push(`elapsed ${Date.now() - started}ms`);
  return { text: lines.join('\n'), probe, plan: null };
}

/* ---------------------------------------------------------------- outline */

/**
 * The whole file as rows of text: where the picture changes, where the camera
 * moves, where somebody talks. No frame is decoded into a picture, so the call
 * costs no vision tokens — it is the cheap first move on a file whose contents
 * are unknown.
 */
export async function runOutline(opts) {
  const started = Date.now();
  const ffmpegPath = opts.ffmpegPath ?? await findFfmpeg();
  if (!ffmpegPath) throw new Error('ffmpeg not found — set DSH_FFMPEG_PATH or install ffmpeg');
  const ffprobePath = opts.ffprobePath ?? await findFfprobe();
  const source = await resolveSource(opts.input, { ffmpegPath, signal: opts.signal, log: opts.log });
  const input = source.path;
  const probe = await probeForPicture(input, { ffmpegPath, ffprobePath });
  const duration = probe.duration || 0;
  const plan = planOutline({ duration, windows: opts.windows });

  const notes = [];
  if (plan.capped) notes.push(`windows ${plan.asked} capped at ${plan.count}`);

  const aspect = Number.isFinite(probe.aspect) && probe.aspect > 0
    ? probe.aspect
    : displayAspect(probe.coded.width, probe.coded.height, probe.sar, probe.rotation);

  // Keyframes when there is something to skip: the outline is a map, and a map
  // of a two-hour file drawn frame by frame costs more than the answer is worth.
  const asked = ['off', 'force'].includes(opts.keyframes) ? opts.keyframes
    : (['off', 'force'].includes(process.env.DSH_SCAN_KEYFRAMES) ? process.env.DSH_SCAN_KEYFRAMES : 'auto');
  const gapInfo = asked === 'off' ? { gap: null } : await keyframeGap({
    input, ffprobePath, signal: opts.signal,
  }).catch(() => ({ gap: null }));
  const mode = keyframeMode({ asked, duration: plan.span, gap: gapInfo?.gap ?? null });

  const [scan, audio] = await Promise.all([
    scanShots({
      input, ffmpegPath, fps: probe.fps || 25, aspect,
      start: 0, duration: plan.span, signal: opts.signal,
      keyframes: mode.keyframes,
    }),
    probe.hasAudio
      ? analyzeAudio({ input, ffmpegPath, signal: opts.signal, duration: plan.span, run })
        .catch((error) => ({ hasAudio: false, error: String(error?.message ?? error) }))
      : Promise.resolve({ hasAudio: false, skipped: true }),
  ]);

  const rows = outlineRows({
    plan,
    effFps: scan.effFps || probe.fps || 25,
    cuts: scan.cuts || [],
    motion: scan.motion,
    micro: scan.micro,
    textMotion: scan.textMotion,
    vectors: scan.vectors,
    speech: audio.speech || [],
    activity: audio.activity || [],
    silence: audio.silences || [],
  });

  const hasAudio = audio.hasAudio === true;
  const speechShare = plan.span > 0
    ? Math.min(1, spanOverlap(audio.speech || [], 0, plan.span) / plan.span)
    : 0;
  const text = outlineReport({
    title: source.meta ? sourceTitle(source.meta) : basename(input),
    duration,
    plan,
    rows,
    top: opts.top,
    totalCuts: (scan.cuts || []).length,
    speechShare,
    hasAudio,
    keyframeGap: scan.keyframes ? (gapInfo?.gap ?? null) : null,
    notes,
  });

  return {
    text,
    probe,
    plan,
    rows,
    timings: { total: Date.now() - started },
  };
}

/**
 * What a B站 link is, before any byte of video is fetched: title, part, length,
 * the quality we are allowed to download, and whether there is a subtitle track
 * to quote from. Costs three HTTP calls and no decode, so the model can decide

 * what to do next with a link in under a second.
 */
async function probeBilibili(rawInput, started) {
  const meta = await bilibiliView(rawInput);
  let play = null;
  try {
    play = await bilibiliPlay(meta);
  } catch (error) {
    play = { error: String(error?.message ?? error) };
  }
  const subs = meta.cid ? await bilibiliSubtitles(meta) : { cues: [], available: [], language: null };
  const subtitleLabel = subs.cues.length
    ? `${subs.cues.length} 条${subs.language ? `（${subs.language}）` : ''}`
    : (subs.available.length ? `未下载（可用 ${subs.available.join(' / ')}）` : '不可用');
  const plan = suggestDetail({
    duration: meta.duration,
    aspect: 16 / 9,
    hasAudio: true,
    hasSubtitle: subs.cues.length > 0,
  });
  const lines = [
    describeBilibili(meta, {
      qualityLabel: play?.label ? `${play.label}${play.size ? ` · ${(play.size / 1048576).toFixed(1)} MB` : ''}` : null,
      subtitles: subtitleLabel,
    }),
  ];
  if (play?.error) lines.push(`playurl: ${play.error}`);
  lines.push(`plan: ${plan.detail} detail · ${plan.cells} cells · ~${plan.tokens} vision tokens · ${plan.windows} call${plan.windows > 1 ? 's' : ''}`);
  if (plan.note) lines.push(plan.note);
  lines.push('next: video_storyboard (one sheet) · video_read (text of every screen) · video_zoom (one window, bigger)');
  lines.push(`elapsed ${Date.now() - started}ms`);
  return {
    text: lines.join('\n'),
    probe: {
      path: meta.url,
      duration: meta.duration,
      bvid: meta.bvid,
      page: meta.page,
      pages: meta.pages,
      title: meta.title,
      quality: play?.quality ?? null,
    },
    plan,
  };
}

/* ------------------------------------------------------------------ utils */

/**
 * Vision tokens for an image, mirroring the host's accounting: 42 px cells
 * (14 px patch, 3x downsample), a 544x544 minimum, and a 1024-token cap.
 * Used to report cost and to keep the sheet inside the cap.
 */
export function estimateVisionTokens(width, height) {
  const PATCH = 14;
  const CELL = PATCH * 3;
  const MIN_PIXELS = 544 * 544;
  const MAX_TOKENS = 1024;
  let w = width;
  let h = height;
  const px = w * h;
  if (px > 0 && px < MIN_PIXELS) {
    const scale = Math.sqrt(MIN_PIXELS / px);
    w = Math.trunc(w * scale);
    h = Math.trunc(h * scale);
  }
  const gw = Math.ceil(Math.ceil(w / PATCH) * PATCH / CELL);
  const gh = Math.ceil(Math.ceil(h / PATCH) * PATCH / CELL);
  const tokens = gh * (gw + 1) + 2;
  return tokens > MAX_TOKENS ? MAX_TOKENS : tokens;
}

const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

/**
 * Everything a window request lost, in the caller's own words.
 *
 * The planner clamps silently, because a clamp is not an error: asking for a
 * window past the end of the file should still return the part that exists. But
 * a clamped window reads exactly like a short file, so each clamp is reported
 * once, where the caller will see it.
 */
export function windowNotes({ duration = 0, start = 0, end = 0, askedStart = 0, askedEnd = NaN, askedDuration = NaN } = {}) {
  const notes = [];
  const askedEndFinite = Number.isFinite(askedEnd) && askedEnd > askedStart;
  if (askedStart > start + 0.05) {
    notes.push(`start ${timecode(askedStart)} moved to ${timecode(start)} — the file is ${timecode(duration)} long`);
  }
  if (Number.isFinite(askedEnd) && askedEnd <= askedStart) {
    notes.push(`end ${timecode(askedEnd)} is not after the start; ignored`);
  } else if (askedEndFinite && askedEnd > end + 0.05) {
    notes.push(`end ${timecode(askedEnd)} moved to ${timecode(end)} — the file is ${timecode(duration)} long`);
  }
  if (!askedEndFinite && Number.isFinite(askedDuration) && askedDuration > 0
    && askedStart + askedDuration > end + 0.05) {
    notes.push(`duration ${askedDuration}s runs past the end — window is ${timecode(start)}-${timecode(end)}`);
  }
  return notes;
}

function basename(p) {
  const s = String(p ?? '');
  const clean = s.split(/[?#]/)[0];
  const parts = clean.split(/[\\/]/);
  return parts[parts.length - 1] || s;
}

export { MAX_CELLS_HARD };
