/**
 * src/vendor.d.ts — ambient declarations required by the dynamic plugin runtime.
 *
 * React/JSX and @deepseek-ai/dsh-client-* types now resolve from the real
 * alpha.5 devDependencies; no ambient module shims remain here. The bundle
 * still externalizes react / react/jsx-runtime in build.mjs (platform modules
 * served by the DSH web shell).
 */
