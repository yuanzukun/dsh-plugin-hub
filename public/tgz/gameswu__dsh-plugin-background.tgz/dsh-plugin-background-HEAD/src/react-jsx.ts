/**
 * Typed wrappers around the react/jsx-runtime entrypoints.
 *
 * `@types/react` deliberately types the runtime `jsx`/`jsxs` `props` argument
 * as `unknown` (the JSX compiler owns prop checking). This plugin constructs
 * elements by calling the runtime functions directly, so a pair of thin generic
 * wrappers reintroduces `ComponentProps<T>` checking for intrinsics and for the
 * alpha.5 `@deepseek-ai/dsh-client-ui-primitives` components.
 */
import {
	Fragment,
	jsx as runtimeJsx,
	jsxs as runtimeJsxs
} from "react/jsx-runtime";
import type { ComponentProps, ElementType, Key, ReactElement } from "react";

export function jsx<T extends ElementType>(
	type: T,
	props: ComponentProps<T> & { key?: Key },
	key?: Key
): ReactElement {
	return runtimeJsx(type, props as never, key) as ReactElement;
}

export function jsxs<T extends ElementType>(
	type: T,
	props: ComponentProps<T> & { key?: Key },
	key?: Key
): ReactElement {
	return runtimeJsxs(type, props as never, key) as ReactElement;
}

export { Fragment };
