/**
 * dsh-webfetch — web page reader for DeepSeek Harness.
 *
 * Six read-only tools, zero runtime dependencies (node built-ins + global
 * fetch only):
 *   web_fetch    — fetch a URL and extract clean markdown or plain text
 *                  (headings, links, lists, code fences; scripts and styling
 *                  stripped), with a size cap and a bounded redirect chain
 *   web_links    — inventory every link on a page, resolved to absolute URLs,
 *                  deduplicated and capped
 *   web_feed     — read an RSS 2.0 / Atom feed and return a clean entry
 *                  listing (title, link, date, author, summary, content)
 *   web_headers  — inspect the HTTP status, response headers and redirect
 *                  chain of a URL without downloading the body (HEAD first,
 *                  automatic GET fallback)
 *   web_table    — extract the HTML tables of a page as structured rows
 *                  (header detection, colspan/rowspan grid expansion,
 *                  row/table caps)
 *   web_meta     — read the page's own metadata: title, description,
 *                  canonical, language, charset, robots, author, Open Graph
 *                  and article properties, Twitter cards, hreflang
 *                  alternates, feed autodiscovery, icons and JSON-LD blocks
 *
 * Safety model: http/https only, embedded URL credentials rejected, no
 * cookies or credentials sent, redirect hops limited, body size capped,
 * every request has a hard timeout, and only text/html, text/plain or
 * (for feeds) XML content types are parsed.
 *
 * @module dsh-webfetch
 */

import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import z from '@deepseek-ai/schemastery'
import { resolveProxyConf, type ProxyConf } from './proxy.ts'
import { buildWebfetchTools, type ToolSet } from './tools.ts'

/** Stable Cordis plugin name (also the config key under `plugins:`). */
export const name = 'dsh-webfetch'

/** Services required before tool registration can start. */
export const inject = ['agents', 'tools']

/** Plugin configuration, resolved with defaults by the loader. */
export interface Config {
  /** Per-request timeout in ms (1000–60000). */
  timeoutMs?: number
  /** Maximum accepted response size in bytes (10000–5000000). */
  maxBytes?: number
  /** Default extracted-content cap in characters (1000–200000). */
  maxChars?: number
  /** Maximum redirects to follow (0–10). */
  maxRedirects?: number
  /** User-Agent header value. */
  userAgent?: string
  /** http proxy URL (http://host:port); empty string disables; default: HTTP_PROXY env. */
  httpProxy?: string
  /** https proxy URL; empty string disables; default: HTTPS_PROXY env. */
  httpsProxy?: string
  /** NO_PROXY bypass list; default: NO_PROXY env. */
  noProxy?: string
}

/** Single source of truth for the default User-Agent (schema + resolveConfig). */
export const DEFAULT_USER_AGENT = 'dsh-webfetch/0.5 (DeepSeek Harness plugin)'

export const Config: z<Config> = z.object({
  timeoutMs: z.number().min(1_000).max(60_000).default(10_000),
  maxBytes: z.number().min(10_000).max(5_000_000).default(1_500_000),
  maxChars: z.number().min(1_000).max(200_000).default(50_000),
  maxRedirects: z.number().step(1).min(0).max(10).default(3),
  userAgent: z.string().max(200).default(DEFAULT_USER_AGENT),
  httpProxy: z.string().max(500),
  httpsProxy: z.string().max(500),
  noProxy: z.string().max(2000),
})

/** Config with every default resolved (all fields guaranteed). */
export interface ResolvedConfig {
  timeoutMs: number
  maxBytes: number
  maxChars: number
  maxRedirects: number
  userAgent: string
  proxy: ProxyConf
}

/** Resolve loader config into the effective runtime config. */
export function resolveConfig(config: Config, env: Record<string, string | undefined> = process.env): ResolvedConfig {
  return {
    timeoutMs: config.timeoutMs ?? 10_000,
    maxBytes: config.maxBytes ?? 1_500_000,
    maxChars: config.maxChars ?? 50_000,
    maxRedirects: config.maxRedirects ?? 3,
    userAgent: config.userAgent ?? DEFAULT_USER_AGENT,
    proxy: resolveProxyConf(env, { httpProxy: config.httpProxy, httpsProxy: config.httpsProxy, noProxy: config.noProxy }),
  }
}

/** Register both web tools on one agent; returns the disposer. */
function decorate(agent: Agent, tools: ToolSet): () => void {
  const disposers = Object.values(tools).map((definition) => agent.ctx.tools.register(definition))
  return () => {
    for (const dispose of disposers) {
      try {
        dispose()
      } catch {
        // already disposed
      }
    }
  }
}

/** Mount the web tools on every live agent and every future one. */
export function apply(ctx: Context, config: Config): void {
  const resolved = resolveConfig(config)
  const tools = buildWebfetchTools(resolved)
  const disposers = new Set<() => void>()

  const decorateAgent = (agent: Agent): void => {
    try {
      disposers.add(decorate(agent, tools))
    } catch (error) {
      ctx.logger('webfetch').warn(`tool registration for agent ${agent.id} failed: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  for (const agent of ctx.agents.list()) decorateAgent(agent)
  const off = ctx.on('agent/created', ({ agent }) => decorateAgent(agent))

  ctx.effect(() => () => {
    off()
    for (const dispose of disposers) {
      try {
        dispose()
      } catch {
        // already disposed
      }
    }
    disposers.clear()
  })
}
