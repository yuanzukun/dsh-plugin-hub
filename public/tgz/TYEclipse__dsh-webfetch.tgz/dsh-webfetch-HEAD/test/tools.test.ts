/**
 * Tests for tool definition assembly, config resolution, renderers and an
 * end-to-end web_feed execution against a local fixture server.
 *
 * ORACLE: test/oracle/anchors.py
 */

import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { createServer, type Server } from 'node:http'
import { resolveConfig } from '../src/index.ts'
import { buildWebfetchTools } from '../src/tools.ts'

describe('resolveConfig', () => {
  it('applies every default', () => {
    const resolved = resolveConfig({}, {})
    expect(resolved).toEqual({
      timeoutMs: 10_000,
      maxBytes: 1_500_000,
      maxChars: 50_000,
      maxRedirects: 3,
      userAgent: 'dsh-webfetch/0.6 (DeepSeek Harness plugin)',
      proxy: { httpProxy: '', httpsProxy: '', noProxy: '' },
    })
  })

  it('honours overrides', () => {
    const resolved = resolveConfig({ timeoutMs: 2_000, maxRedirects: 5, maxChars: 10_000 }, {})
    expect(resolved.timeoutMs).toBe(2_000)
    expect(resolved.maxRedirects).toBe(5)
    expect(resolved.maxChars).toBe(10_000)
    expect(resolved.maxBytes).toBe(1_500_000)
  })

  it('resolves proxy settings: config overrides env, empty string disables', () => {
    const env = { HTTP_PROXY: 'http://env-proxy:7897', HTTPS_PROXY: 'http://env-proxy:7897', NO_PROXY: 'localhost' }
    const fromEnv = resolveConfig({}, env)
    expect(fromEnv.proxy).toEqual({ httpProxy: 'http://env-proxy:7897', httpsProxy: 'http://env-proxy:7897', noProxy: 'localhost' })
    const overridden = resolveConfig({ httpsProxy: 'http://my-proxy:3128', httpProxy: '', noProxy: 'example.com' }, env)
    expect(overridden.proxy).toEqual({ httpProxy: '', httpsProxy: 'http://my-proxy:3128', noProxy: 'example.com' })
  })
})

describe('buildWebfetchTools', () => {
  const tools = buildWebfetchTools(resolveConfig({}))

  it('exposes all seven tools under their canonical names', () => {
    expect(Object.keys(tools).sort()).toEqual(['web_feed', 'web_fetch', 'web_headers', 'web_links', 'web_meta', 'web_sitemap', 'web_table'])
  })

  it('gives every tool a name, description, schema and executable', () => {
    for (const [key, definition] of Object.entries(tools)) {
      expect(definition.name).toBe(key)
      expect(definition.description.length).toBeGreaterThan(20)
      expect(definition.parameters).toBeDefined()
      expect(definition.output.schema).toBeDefined()
      expect(typeof definition.execute).toBe('function')
    }
  })

  it('renders a fetch result as text with title and content', () => {
    const block = tools.web_fetch.output.render(
      { url: 'https://x.test/' },
      {
        url: 'https://x.test/',
        finalUrl: 'https://x.test/',
        status: 200,
        title: 'Example',
        content: 'body text',
        truncated: false,
      },
    )
    expect(block[0]).toEqual({ type: 'text', text: 'HTTP 200 — title: Example\nbody text' })
  })

  it('renders a links result with the inventory', () => {
    const block = tools.web_links.output.render(
      { url: 'https://x.test/' },
      {
        url: 'https://x.test/',
        finalUrl: 'https://x.test/',
        status: 200,
        count: 1,
        links: [{ text: 'Home', href: 'https://x.test/home' }],
      },
    )
    expect(block[0]?.type).toBe('text')
    const textBlock = block[0] as { type: 'text'; text: string }
    expect(textBlock.text).toContain('Home — https://x.test/home')
  })

  it('renders a feed result as an entry listing', () => {
    const block = tools.web_feed.output.render(
      { url: 'https://x.test/feed.xml' },
      {
        url: 'https://x.test/feed.xml',
        finalUrl: 'https://x.test/feed.xml',
        status: 200,
        feedTitle: 'Example Feed',
        entryCount: 1,
        truncated: false,
        entries: [{ title: 'Post', url: 'https://x.test/post', published: 'Mon, 01 Jan 2024 10:00:00 GMT', summary: 'Short summary' }],
      },
    )
    expect(block[0]?.type).toBe('text')
    const textBlock = block[0] as { type: 'text'; text: string }
    expect(textBlock.text).toBe('feed: Example Feed\n1 entry from https://x.test/feed.xml\n1. Post — https://x.test/post\n   published: Mon, 01 Jan 2024 10:00:00 GMT\n   Short summary')
  })

  it('renders a table result with header and rows, and a no-table note', () => {
    const block = tools.web_table.output.render(
      { url: 'https://x.test/report' },
      {
        url: 'https://x.test/report',
        finalUrl: 'https://x.test/report',
        status: 200,
        tableCount: 1,
        totalTables: 1,
        truncated: false,
        tables: [{ index: 1, caption: 'Q3', cols: 2, header: ['Item', 'Qty'], rows: [['Widget', '3']] }],
      },
    )
    expect(block[0]).toEqual({
      type: 'text',
      text: '1 table(s) on https://x.test/report\ntable 1 — Q3 (2 columns)\n  [header] Item | Qty\n  Widget | 3',
    })
    const empty = tools.web_table.output.render(
      { url: 'https://x.test/none' },
      { url: 'https://x.test/none', finalUrl: 'https://x.test/none', status: 200, tableCount: 0, totalTables: 0, truncated: false, tables: [] },
    )
    expect(empty[0]).toEqual({ type: 'text', text: 'no tables found on https://x.test/none' })
  })
})

describe('web_feed end-to-end (fixture server)', () => {
  let server: Server
  let base: string

  /** Typed single-argument view of the tool (ToolDefinition.execute takes (args, exec)). */
  interface FeedResult {
    url: string
    finalUrl: string
    status: number
    feedTitle: string
    entryCount: number
    truncated: boolean
    entries: Array<{ title: string; url: string; published?: string; author?: string; summary?: string; content?: string }>
  }
  type FeedArgs = { url: string; maxItems?: number; includeContent?: boolean }
  const feedRun = (url: string, args: Partial<FeedArgs> = {}) => {
    const tools = buildWebfetchTools(resolveConfig({}, {}))
    const run = tools.web_feed.execute as (args: FeedArgs) => Promise<FeedResult>
    return run({ url, ...args })
  }

  beforeAll(async () => {
    server = createServer((req, res) => {
      const url = new URL(req.url ?? '/', 'http://localhost')
      if (url.pathname === '/feed') {
        res.writeHead(200, { 'content-type': 'application/rss+xml; charset=utf-8' })
        res.end(
          '<?xml version="1.0" encoding="UTF-8"?><rss version="2.0">'
          + '<channel><title>Fixture Feed</title>'
          + '<item><title>Alpha &amp; beta</title><link>/posts/alpha</link><pubDate>Mon, 01 Jan 2024 10:00:00 GMT</pubDate><description>One &mdash; two</description></item>'
          + '<item><title>Second</title><link>/posts/second</link><description>Another</description></item>'
          + '</channel></rss>',
        )
        return
      }
      if (url.pathname === '/not-a-feed') {
        res.writeHead(200, { 'content-type': 'text/html' })
        res.end('<html><body><p>just a page</p></body></html>')
        return
      }
      if (url.pathname === '/tables') {
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
        res.end('<html><body><h1>Report</h1>'
          + '<table><tr><th>Item</th><th>Qty</th></tr><tr><td>Widget</td><td>3</td></tr><tr><td>Gadget</td><td>5</td></tr></table>'
          + '<table><tr><td>plain</td></tr></table>'
          + '</body></html>')
        return
      }
      res.writeHead(404)
      res.end()
    })
    await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
    const address = server.address()
    if (address === null || typeof address === 'string') throw new Error('failed to bind fixture server')
    base = `http://127.0.0.1:${address.port}`
  })

  afterAll(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()))
  })

  it('parses a live RSS feed through the execute path', async () => {
    const result = await feedRun(`${base}/feed`, { maxItems: 1 })
    expect(result).toEqual({
      url: `${base}/feed`,
      finalUrl: `${base}/feed`,
      status: 200,
      feedTitle: 'Fixture Feed',
      entryCount: 1,
      truncated: false,
      entries: [{
        title: 'Alpha & beta',
        url: `${base}/posts/alpha`,
        published: 'Mon, 01 Jan 2024 10:00:00 GMT',
        summary: 'One — two',
      }],
    })
  })

  it('resolves relative entry links against the final feed URL', async () => {
    const result = await feedRun(`${base}/feed`, { maxItems: 2 })
    expect(result.entryCount).toBe(2)
    expect(result.entries[1]?.url).toBe(`${base}/posts/second`)
    expect(result.entries[1]?.published).toBeUndefined()
  })

  it('rejects a non-feed document with a clear error', async () => {
    await expect(feedRun(`${base}/not-a-feed`)).rejects.toThrow(/not a recognized RSS or Atom feed/)
  })

  it('rejects an unsupported protocol before any fetch', async () => {
    await expect(feedRun('file:///etc/passwd')).rejects.toThrow(/only http and https/)
  })

  interface TableResult {
    url: string
    finalUrl: string
    status: number
    tableCount: number
    totalTables: number
    truncated: boolean
    tables: Array<{ index: number; caption: string; cols: number; header: string[]; rows: string[][] }>
  }
  type TableArgs = { url: string; table?: number; maxTables?: number; maxRows?: number }
  const tableRun = (url: string, args: Partial<TableArgs> = {}) => {
    const tools = buildWebfetchTools(resolveConfig({}, {}))
    const run = tools.web_table.execute as (args: TableArgs) => Promise<TableResult>
    return run({ url, ...args })
  }

  const assertNoUndefined = (value: unknown, path = 'result'): void => {
    if (value === undefined) throw new Error(`undefined value at ${path}`)
    if (Array.isArray(value)) value.forEach((item, index) => assertNoUndefined(item, `${path}[${index}]`))
    else if (value !== null && typeof value === 'object') {
      for (const [key, inner] of Object.entries(value)) assertNoUndefined(inner, `${path}.${key}`)
    }
  }

  it('extracts tables through the execute path with header detection', async () => {
    const result = await tableRun(`${base}/tables`)
    expect(result.status).toBe(200)
    expect(result.tableCount).toBe(2)
    expect(result.totalTables).toBe(2)
    expect(result.truncated).toBe(false)
    expect(result.tables).toEqual([
      { index: 1, caption: '', cols: 2, header: ['Item', 'Qty'], rows: [['Widget', '3'], ['Gadget', '5']] },
      { index: 2, caption: '', cols: 1, header: [], rows: [['plain']] },
    ])
  })

  it('selects one table by position and rejects out-of-range positions', async () => {
    const result = await tableRun(`${base}/tables`, { table: 2 })
    expect(result.tableCount).toBe(1)
    expect(result.totalTables).toBe(2)
    expect(result.tables[0]?.rows).toEqual([['plain']])
    await expect(tableRun(`${base}/tables`, { table: 9 })).rejects.toThrow(/table #9 not found/)
    await expect(tableRun(`${base}/tables`, { table: 0 })).rejects.toThrow(/positive integer/)
  })

  it('keeps the web_table payload free of undefined values', async () => {
    assertNoUndefined(await tableRun(`${base}/tables`))
  })
})
