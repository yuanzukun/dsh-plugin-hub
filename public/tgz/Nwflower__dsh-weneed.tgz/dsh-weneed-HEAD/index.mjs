// index.mjs — dsh-weneed 插件入口（纯 ESM，零构建、零 DSH import 依赖）。
//
// 把「we need 模式」（思维链引导规范，源自 scp3500/oh-we-need，MIT）包装为 DSH 原生能力：
//   1. `weneed` 工具        —— agent 会话内按需注入：把规范写进当前 agent 的 system prompt
//                             （agent 作用域段，后续每轮推理常驻），并返回规范全文。
//   2. `/weneed` 命令       —— 人类一键开关：/weneed [on|off|status|install]。
//   3. `weneed_install` 工具 —— 把 WeNeed agent-preset 装配到用户预设根
//                             （~/.dsh/.agent-presets/weneed）：新会话选 WeNeed 预设 = 模式常驻。
//
// 形态沿 dsh-file-claim 已验证路径：纯 ESM + ctx 宿主服务（tools/commands/systemPrompt/
// agentPresets），不 import 任何 DSH 包 —— 注入器 junction 链接后零解析风险。

import { copyFileSync, existsSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { SPEC_META, WE_NEED_SPEC } from './spec.mjs'

const PRESET_ID = SPEC_META.id
const SECTION_NAME = SPEC_META.sectionName
const SECTION_ORDER = SPEC_META.sectionOrder
const PRESET_DIR = fileURLToPath(new URL('./preset/', import.meta.url))

// agentId → systemPrompt.section() 的 dispose 函数。agent 销毁时由 agent/disposed 清理。
const active = new Map()

function agentKey(agent) {
  return agent?.id ?? agent?.session?.id ?? null
}

// ---- 注入 / 移除 / 查询（命令与工具共用同一核心） ----

function enableFor(agent) {
  const key = agentKey(agent)
  if (!key) return { ok: false, message: '无法确定会话身份（缺少 agent）。' }
  if (active.has(key)) return { ok: true, already: true }
  const sp = agent?.ctx?.systemPrompt
  if (!sp || typeof sp.section !== 'function') {
    return { ok: false, message: 'systemPrompt 服务不可用，无法注入模式段。' }
  }
  try {
    const dispose = sp.section({ name: SECTION_NAME, order: SECTION_ORDER, text: WE_NEED_SPEC })
    active.set(key, dispose)
  } catch (e) {
    return { ok: false, message: '注入失败: ' + String(e) }
  }
  return { ok: true }
}

function disableFor(agent) {
  const key = agentKey(agent)
  if (!key) return { ok: false, message: '无法确定会话身份（缺少 agent）。' }
  const dispose = active.get(key)
  if (!dispose) return { ok: true, already: false }
  try { dispose() } catch { /* 段已随 agent 卸载，忽略 */ }
  active.delete(key)
  return { ok: true, already: true }
}

function statusFor(agent) {
  const key = agentKey(agent)
  return { enabled: key ? active.has(key) : false }
}

// ---- preset 装配：复制包内 preset/ 目录到用户预设根（默认幂等，force 覆盖已有） ----

function installPreset(ctx, force) {
  const ap = ctx?.get?.('agentPresets')
  const roots = ap?.roots
  if (!Array.isArray(roots)) {
    return { ok: false, message: 'agentPresets 服务不可用：无法定位预设根。' }
  }
  const userRoot = roots.find((r) => r?.trust === 'user')
  if (!userRoot?.path) {
    return { ok: false, message: '未配置 user 预设根（agent-presets.roots），无法装配。' }
  }
  const target = join(userRoot.path, PRESET_ID)
  const marker = join(target, 'agent.cordis.yml')
  const exists = existsSync(marker)
  if (exists && !force) {
    return { ok: true, already: true, message: 'WeNeed 预设已装配（幂等跳过）。加 force:true 可覆盖为插件完整版（7 条规范 + 完整工具集）。', path: target }
  }
  try {
    mkdirSync(target, { recursive: true })
    for (const f of ['agent.cordis.yml', 'preset.yml']) {
      const src = join(PRESET_DIR, f)
      if (existsSync(src)) copyFileSync(src, join(target, f))
    }
  } catch (e) {
    return { ok: false, message: '装配失败: ' + String(e) }
  }
  return {
    ok: true,
    overwritten: exists && force,
    message: exists && force
      ? 'WeNeed 预设已覆盖为插件完整版（首句锚定 + 7 条规范 + standard 全量工具）。新会话选择 WeNeed 生效；已开会话保持原组合。'
      : 'WeNeed 预设已装配。新会话在预设选择器里选 WeNeed，we need 模式常驻。',
    path: target,
  }
}

// ---- 工具 ----

const TOOL_SCHEMA = {
  type: 'object',
  properties: {
    ok: { type: 'boolean' },
    already: { type: 'boolean' },
    overwritten: { type: 'boolean' },
    enabled: { type: 'boolean' },
    action: { type: 'string' },
    message: { type: 'string' },
    spec: { type: 'string' },
    path: { type: 'string' },
  },
  required: ['message'],
  additionalProperties: false,
}

function renderText(v) {
  const lines = [v.message || '']
  if (v.path) lines.push('路径: ' + v.path)
  if (typeof v.spec === 'string' && v.spec) lines.push('\n' + v.spec)
  return lines.filter(Boolean).join('\n')
}

function defineTools(ctx) {
  const tools = ctx.get('tools')
  if (!tools || typeof tools.register !== 'function') return

  ctx.effect(() =>
    tools.register({
      name: 'weneed',
      description:
        'we need 思维模式：把「we need to ...」思维链引导规范注入当前会话的 system prompt（agent 作用域段，后续每轮推理常驻），并返回规范全文。action=off 移除，action=status 查询。',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['on', 'off', 'status'],
            description: 'on=注入（默认），off=移除，status=查询当前会话状态',
          },
        },
        required: [],
        additionalProperties: false,
      },
      output: {
        schema: TOOL_SCHEMA,
        render: (_args, v) => [{ type: 'text', text: renderText(v) }],
      },
      async execute(args, exec) {
        const action = args?.action ?? 'on'
        const agent = exec?.agent
        if (!agent) {
          return { ok: false, message: '调用缺少 agent 上下文，无法确定注入目标会话。', spec: WE_NEED_SPEC }
        }
        if (action === 'off') {
          const r = disableFor(agent)
          return {
            ok: r.ok,
            enabled: false,
            action,
            message: r.ok ? (r.already ? 'WeNeed 模式已关闭。' : 'WeNeed 模式本就未启用。') : r.message,
          }
        }
        if (action === 'status') {
          const s = statusFor(agent)
          return {
            ok: true,
            enabled: s.enabled,
            action,
            message: s.enabled
              ? 'WeNeed 模式已启用：当前会话的 system prompt 已注入 we need 思维段。'
              : 'WeNeed 模式未启用。调用 weneed（action=on）或 /weneed 开启；/weneed install 装配常驻预设。',
          }
        }
        const r = enableFor(agent)
        return {
          ok: r.ok,
          enabled: r.ok,
          action,
          message: r.ok
            ? (r.already
                ? 'WeNeed 模式已启用（重复注入跳过，段已在当前会话生效）。'
                : 'WeNeed 模式已注入当前会话：后续推理按 we need to 句式展开。')
            : r.message,
          spec: r.ok ? WE_NEED_SPEC : '',
        }
      },
    }),
  )

  ctx.effect(() =>
    tools.register({
      name: 'weneed_install',
      description:
        '把 WeNeed agent-preset（插件完整版：首句锚定 + 7 条规范 + standard 全量工具）装配到用户预设根（~/.dsh/.agent-presets/weneed）。默认幂等（已存在则跳过）；force:true 覆盖已有 preset，新会话选择 WeNeed 即生效。',
      parameters: {
        type: 'object',
        properties: {
          force: {
            type: 'boolean',
            description: 'true = 覆盖已装配的 weneed preset（默认 false 幂等跳过）',
          },
        },
        required: [],
        additionalProperties: false,
      },
      output: {
        schema: TOOL_SCHEMA,
        render: (_args, v) => [{ type: 'text', text: renderText(v) }],
      },
      async execute(args) {
        return installPreset(ctx, args?.force === true)
      },
    }),
  )
}

// ---- 人类命令 ----

function defineCommands(ctx) {
  const commands = ctx.get('commands')
  if (!commands || typeof commands.register !== 'function') return
  ctx.effect(() =>
    commands.register({
      name: 'weneed',
      description:
        'we need 思维模式：/weneed 开启（注入当前会话 system prompt），/weneed off 关闭，/weneed status 查询，/weneed install [force] 装配/覆盖 WeNeed 常驻预设。',
      input: { hint: '[on|off|status|install [force]]' },
      handler: async ({ agent, rawInput }) => {
        const arg = String(rawInput || '').trim().toLowerCase()
        if (arg === 'off') {
          const r = disableFor(agent)
          return {
            kind: r.ok ? 'success' : 'error',
            text: r.ok ? (r.already ? 'WeNeed 模式已关闭。' : 'WeNeed 模式本就未启用。') : r.message,
          }
        }
        if (arg === 'status') {
          const s = statusFor(agent)
          return {
            kind: 'success',
            text: s.enabled
              ? 'WeNeed 模式已启用：当前会话的 system prompt 已注入 we need 思维段。'
              : 'WeNeed 模式未启用。/weneed 开启；/weneed install 装配常驻预设。',
          }
        }
        if (arg === 'install' || arg.startsWith('install ')) {
          const force = arg.split(/\s+/).includes('force')
          const r = installPreset(ctx, force)
          return { kind: r.ok ? 'success' : 'error', text: renderText(r) }
        }
        const r = enableFor(agent)
        return {
          kind: r.ok ? 'success' : 'error',
          text: r.ok
            ? (r.already
                ? 'WeNeed 模式已启用（重复注入跳过）。'
                : 'WeNeed 模式已注入当前会话：后续推理按 we need to 句式展开。')
            : r.message,
        }
      },
    }),
  )
}

export default {
  name: 'dsh-weneed',
  inject: ['tools'],
  apply(ctx, config = {}) {
    const cfg = { autoEnable: false, ...config }

    defineTools(ctx)
    defineCommands(ctx)

    // 生命周期：agent 销毁时清理其注入段（段本身随 agent.ctx 卸载，这里只清 Map 防泄漏）。
    ctx.on('agent/disposed', ({ agent }) => {
      const key = agentKey(agent)
      if (!key) return
      const dispose = active.get(key)
      if (dispose) {
        try { dispose() } catch { /* 已随 agent 卸载 */ }
        active.delete(key)
      }
    })

    // 可选：新会话自动注入（config.autoEnable=true 时，模式默认常驻于每个新会话）。
    if (cfg.autoEnable) {
      ctx.on('agent/created', ({ agent }) => {
        const r = enableFor(agent)
        if (!r.ok) ctx.logger?.warn?.('[dsh-weneed] autoEnable 注入失败: ' + r.message)
      })
    }

    ctx.logger?.info?.('[dsh-weneed] 已加载：weneed / weneed_install 工具 + /weneed 命令（autoEnable=' + String(cfg.autoEnable) + '）')
  },
}
