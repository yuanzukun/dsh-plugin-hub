/**
 * 金额与 token 的显示格式化。
 *
 * 金额在插件内部一律以**微元 µ¥**（整数）存放与累加，只在这里换算成显示串；
 * 不足 ¥0.0001 的金额显示为 `<0.0001`，避免用一长串 0 假装精确。
 *
 * **货币标注只出现一次**：数值后跟 ISO 代码 `CNY`（人民币），配合金币图标表达
 * "这是钱"。因此这里不再输出 `¥` 符号 —— 图标 + 符号重复标注对用户是噪音。
 *
 * @module dsh-turn-cost/client/cost-format
 */

/** 1 元 = 1e6 微元。 */
const MICRO_PER_YUAN = 1_000_000

/** 低于该微元值（= 0.0001 元）时改用下限写法。 */
const DISPLAY_FLOOR_MICRO = 100

/** 人民币 ISO 代码（唯一的货币标注）。 */
const UNIT = 'CNY'

/**
 * 微元 → 金额显示串（数值 + 货币单位）。
 * @param micro - 金额（微元）。
 * @returns 例如 `0.0123 CNY`；零为 `0 CNY`；不足四位小数的正值为 `<0.0001 CNY`。
 */
export function formatCost(micro: number): string {
  if (!Number.isFinite(micro) || micro <= 0) return `0 ${UNIT}`
  if (micro < DISPLAY_FLOOR_MICRO) return `<0.0001 ${UNIT}`
  return `${(micro / MICRO_PER_YUAN).toFixed(4)} ${UNIT}`
}

/**
 * token 数的精确显示（千分位）。
 * @param count - token 数。
 * @returns 例如 `12,345`。
 */
export function formatTokens(count: number): string {
  if (!Number.isFinite(count) || count <= 0) return '0'
  return Math.round(count).toLocaleString('en-US')
}

/**
 * 缓存命中率（命中 / 全部提示侧输入）。
 * @param hit - 缓存命中输入的 token 数。
 * @param miss - 缓存未命中输入的 token 数。
 * @returns 例如 `93.4%`；没有输入时返回 null。
 */
export function formatHitRate(hit: number, miss: number): string | null {
  const total = hit + miss
  if (!Number.isFinite(total) || total <= 0) return null
  return `${((hit / total) * 100).toFixed(1)}%`
}

/**
 * 「金额（tokens）」组合串，用于弹窗明细行。
 * @param micro - 金额（微元）。
 * @param tokens - 该桶 token 数。
 * @returns 例如 `0.0012 CNY（1,234 tokens）` / `<0.0001 CNY（12 tokens）`。
 */
export function formatCostWithTokens(micro: number, tokens: number): string {
  return `${formatCost(micro)}（${formatTokens(tokens)} tokens）`
}

/**
 * provider id 列表的紧凑显示（超出 `max` 个时以 `…` 省略尾部）。
 *
 * 用于"未计价 provider"的标注：pill 位置窄，最多点名前两个；弹窗脚注可以多给一个。
 * @param providers - provider id 列表。
 * @param max - 最多显示几个（缺省 2）。
 * @returns 例如 `deepseek-account` / `a / b …`；空列表返回空串。
 */
export function formatProviders(providers: readonly string[], max = 2): string {
  const list = providers.filter(id => id !== '')
  if (list.length === 0) return ''
  if (list.length <= max) return list.join(' / ')
  return `${list.slice(0, max).join(' / ')} …`
}
