import assert from 'node:assert/strict'
import { test } from 'node:test'
import { availableAddresses, parseTemporaryAddresses, selectAddress, listenerUrl } from '../src/bind-address.ts'

const iface = (address: string, internal = false) => ({ address, internal, family: address.includes(':') ? 'IPv6' as const : 'IPv4' as const, netmask: '', mac: '', cidr: null, scopeid: 0 })

test('lists concrete IPv4 and IPv6 addresses without loopback, wildcard, link-local or scoped addresses', () => {
  assert.deepEqual(availableAddresses({ en0: [iface('192.168.1.7'), iface('2001:db8::7'), iface('192.168.1.7'), iface('fe80::1'), iface('0.0.0.0'), iface('::'), iface('::ffff:0.0.0.0'), iface('169.254.155.138'), iface('127.0.0.1', true), iface('::1', true)] }), ['192.168.1.7', '2001:db8::7'])
})

test('sorts IPv4 addresses ahead of IPv6 addresses', () => {
  assert.deepEqual(availableAddresses({ en0: [iface('2001:db8::7'), iface('192.168.1.7')] }), ['192.168.1.7', '2001:db8::7'])
})

test('drops OS-reported temporary and deprecated IPv6 addresses', () => {
  assert.deepEqual(
    availableAddresses({ en0: [iface('192.168.1.7'), iface('2001:db8::1'), iface('2001:db8::2')] }, new Set(['2001:db8::2'])),
    ['192.168.1.7', '2001:db8::1'],
  )
})

test('parses temporary and deprecated IPv6 literals from ifconfig and ip output', () => {
  const mac = 'en0: flags=8863\n\tinet6 2a02:db8::1 prefixlen 64 autoconf secured\n\tinet6 2a02:db8::2 prefixlen 64 deprecated autoconf temporary\n\tinet6 fe80::1%en0 prefixlen 64 scopeid 0x7'
  assert.deepEqual([...parseTemporaryAddresses(mac)], ['2a02:db8::2'])
  const linux = '2: enp0s3    inet6 2a02:db8::3/64 scope global temporary dynamic\n2: enp0s3    inet6 2a02:db8::4/64 scope global dynamic mngtmpaddr'
  assert.deepEqual([...parseTemporaryAddresses(linux)], ['2a02:db8::3'])
})

test('accepts one explicitly selected local IP including equivalent IPv6 spellings', () => {
  assert.equal(selectAddress('192.168.1.7', ['192.168.1.7']), '192.168.1.7')
  assert.equal(selectAddress('2001:0db8:0:0:0:0:0:7', ['2001:db8::7']), '2001:db8::7')
})

for (const host of ['0.0.0.0', '::', '::ffff:0.0.0.0', 'localhost', '192.168.1.99', '', 'fe80::1%en0']) {
  test(`rejects unavailable or non-concrete selection ${JSON.stringify(host)}`, () => {
    assert.throws(() => selectAddress(host, ['192.168.1.7']), /not a selectable local interface address/)
  })
}

test('formats HTTP and HTTPS URLs with IPv6 brackets', () => {
  assert.equal(listenerUrl('192.168.1.7', 3080, false), 'http://192.168.1.7:3080')
  assert.equal(listenerUrl('2001:db8::7', 3080, true), 'https://[2001:db8::7]:3080')
})
