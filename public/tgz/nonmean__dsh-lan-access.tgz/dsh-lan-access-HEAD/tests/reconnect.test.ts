import assert from 'node:assert/strict'
import { test } from 'node:test'
import { isLoopbackName, normalizeHost, originSurvivesRebind, reboundTarget, sameHostname } from '../src/client/reconnect.ts'

test('normalizes IPv6 literals and keeps IPv4/hostnames canonical', () => {
  assert.equal(normalizeHost('2001:0db8:0:0:0:0:0:7'), '[2001:db8::7]')
  assert.equal(normalizeHost('[2001:db8::7]'), '[2001:db8::7]')
  assert.equal(normalizeHost('192.168.1.7'), '192.168.1.7')
  assert.equal(normalizeHost('LOCALHOST'), 'localhost')
  assert.equal(sameHostname('[2001:db8::1]', '2001:0db8:0:0:0:0:0:1'), true)
})

test('recognizes loopback authorities', () => {
  for (const host of ['127.0.0.1', '127.1.2.3', 'localhost', '[::1]', '::1']) {
    assert.equal(isLoopbackName(host), true, host)
  }
  for (const host of ['192.168.0.101', '[2001:db8::1]', 'example.test']) {
    assert.equal(isLoopbackName(host), false, host)
  }
})

test('only a same-origin restart is observable', () => {
  // Enabling moves loopback -> concrete IP: the old page is cut off.
  assert.equal(originSurvivesRebind('127.0.0.1', true, '192.168.0.101'), false)
  assert.equal(originSurvivesRebind('localhost', true, '192.168.0.101'), false)
  // A page already on that exact address survives the same-origin restart.
  assert.equal(originSurvivesRebind('192.168.0.101', true, '192.168.0.101'), true)
  assert.equal(originSurvivesRebind('[2001:db8::1]', true, '2001:0db8::1'), true)
  // Disabling keeps loopback pages reachable and cuts LAN pages off.
  assert.equal(originSurvivesRebind('127.0.0.1', false, '192.168.0.101'), true)
  assert.equal(originSurvivesRebind('localhost', false, '192.168.0.101'), true)
  assert.equal(originSurvivesRebind('192.168.0.101', false, '192.168.0.101'), false)
})

test('builds the new origin and preserves the launch token in the link', () => {
  assert.deepEqual(reboundTarget('http://127.0.0.1:3080/?token=abc#frag', '192.168.0.101'), {
    origin: 'http://192.168.0.101:3080',
    href: 'http://192.168.0.101:3080/?token=abc',
  })
  assert.deepEqual(reboundTarget('http://127.0.0.1:3080/', '192.168.0.101'), {
    origin: 'http://192.168.0.101:3080',
    href: 'http://192.168.0.101:3080/',
  })
  assert.deepEqual(reboundTarget('https://127.0.0.1:3443/?token=t', '10.0.0.5'), {
    origin: 'https://10.0.0.5:3443',
    href: 'https://10.0.0.5:3443/?token=t',
  })
  assert.deepEqual(reboundTarget('http://127.0.0.1:3080/', '2001:db8::7'), {
    origin: 'http://[2001:db8::7]:3080',
    href: 'http://[2001:db8::7]:3080/',
  })
})
