import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Readable } from 'node:stream'
import { test } from 'node:test'
import { apply } from '../lib/index.js'
import { availableAddresses } from '../src/bind-address.ts'

function mount(saved) {
  const root = mkdtempSync(join(tmpdir(), 'lan-controller-'))
  const file = join(root, 'lan-access.json')
  if (saved !== undefined) writeFileSync(file, JSON.stringify(saved))
  const routes = new Map()
  const warnings = []
  let bindService
  const initialConfig = { host: '127.0.0.1', port: 3080, tls: { certFile: 'cert.pem', keyFile: 'key.pem' }, compression: 'gzip', compressionLevel: 1, compressionThresholdBytes: 1024 }
  const server = {
    host: '127.0.0.1', port: 3080, protocol: 'https:',
    getOrigin: () => `https://${server.host.includes(':') ? `[${server.host}]` : server.host}:3080`,
    register: route => { routes.set(route.path, route.handler); return () => routes.delete(route.path) },
  }
  const connection = { authenticatedUrl: base => `${base}?token=test-token` }
  const entry = {
    id: 'webserver', options: { name: '@deepseek-ai/dsh-host-webserver' },
    fiber: { config: initialConfig, update: (config, noSave) => {
      assert.equal(noSave, true)
      entry.fiber.config = config
      server.host = config.host
    } },
  }
  const ctx = {
    loader: { entries: () => [entry] },
    logger: { warn: message => warnings.push(message) },
    get: name => name === 'dshHomePath' ? (...parts) => join(root, ...parts) : name === 'webServer' ? server : name === 'connection' ? connection : undefined,
    provide: (name, value) => { if (name === 'lanAccess') bindService = value },
    inject: (deps, callback) => callback({ webServer: server, effect: setup => setup() }),
  }
  try { apply(ctx) } catch (error) { rmSync(root, { recursive: true }); throw error }
  async function request(method, body = undefined, headers = {}, path = '/lan-access') {
    const req = Readable.from(body === undefined ? [] : [Buffer.from(JSON.stringify(body))])
    Object.assign(req, { method, url: path, headers: { host: '127.0.0.1:3080', ...headers } })
    return await new Promise(resolve => {
      const res = { setHeader() {}, writeHead(status) { res.statusCode = status }, statusCode: 200, end(text) { resolve({ status: res.statusCode, ...JSON.parse(text) }) } }
      routes.get(path.split('?')[0])(req, res)
    })
  }
  return { file, warnings, request, server, entry, host: () => bindService.host, dispose: () => rmSync(root, { recursive: true }) }
}

test('legacy enabled settings boot loopback with a migration notice and leave the file intact', async () => {
  const app = mount({ enabled: true })
  try {
    assert.equal(app.host(), '127.0.0.1')
    const result = await app.request('GET')
    assert.equal(result.value.enabled, false)
    assert.equal(result.value.migrationRequired, true)
    assert.ok(app.warnings.length)
    assert.deepEqual(JSON.parse(readFileSync(app.file, 'utf8')), { enabled: true })
  } finally { app.dispose() }
})

test('invalid POST cannot persist or start a wildcard listener', async () => {
  const app = mount({ enabled: false })
  try {
    for (const bindHost of ['0.0.0.0', '::', 'localhost', '192.0.2.254']) {
      assert.equal((await app.request('POST', { enabled: true, bindHost })).status, 400)
    }
    assert.deepEqual(JSON.parse(readFileSync(app.file, 'utf8')), { enabled: false })
    assert.equal(app.host(), '127.0.0.1')
  } finally { app.dispose() }
})

test('enable and disable preserve TLS/compression and admit only the selected bind authority', async t => {
  const bindHost = availableAddresses()[0]
  if (bindHost === undefined) return t.skip('no non-loopback interface')
  const app = mount({ enabled: false })
  try {
    assert.equal((await app.request('POST', { enabled: true, bindHost })).status, 200)
    assert.equal(app.host(), bindHost)
    assert.deepEqual(app.entry.fiber.config.tls, { certFile: 'cert.pem', keyFile: 'key.pem' })
    assert.equal(app.entry.fiber.config.compression, 'gzip')
    const authority = bindHost.includes(':') ? `[${bindHost}]:3080` : `${bindHost}:3080`
    const state = await app.request('GET', undefined, { host: authority })
    assert.equal(state.status, 200)
    assert.equal(state.value.url, app.server.getOrigin())
    assert.equal((await app.request('GET', undefined, { host: 'attacker.example' })).status, 403)
    assert.equal((await app.request('GET', undefined, { host: authority, origin: 'https://attacker.example' })).status, 403)
    assert.equal((await app.request('POST', { enabled: false })).status, 200)
    assert.equal(app.host(), '127.0.0.1')
    assert.deepEqual(JSON.parse(readFileSync(app.file, 'utf8')), { enabled: false, bindHost })
  } finally { app.dispose() }
})


test('mints a loopback-only tokenized handoff URL for the selected bind', async t => {
  const bindHost = availableAddresses()[0]
  if (bindHost === undefined) return t.skip('no non-loopback interface')
  const app = mount({ enabled: false })
  try {
    const authority = bindHost.includes(':') ? `[${bindHost}]:3080` : `${bindHost}:3080`
    const handoff = await app.request('GET', undefined, {}, `/lan-access/handoff?host=${encodeURIComponent(bindHost)}`)
    assert.equal(handoff.status, 200)
    assert.equal(handoff.value.url, `https://${authority}?token=test-token`)
    // A remote LAN page must not receive the process launch token.
    const remote = await app.request('GET', undefined, { host: authority }, `/lan-access/handoff?host=${encodeURIComponent(bindHost)}`)
    assert.equal(remote.status, 403)
    // Only current interface literals are accepted, and the host is required.
    assert.equal((await app.request('GET', undefined, {}, '/lan-access/handoff?host=0.0.0.0')).status, 400)
    assert.equal((await app.request('GET', undefined, {}, '/lan-access/handoff')).status, 400)
    // The minted URL is never part of the ordinary GET state.
    assert.equal((await app.request('GET')).value.handoffUrl, undefined)
  } finally { app.dispose() }
})

test('missing settings start disabled without creating a file', async () => {
  const app = mount()
  try {
    assert.equal(app.host(), '127.0.0.1')
    const result = await app.request('GET')
    assert.equal(result.value.migrationRequired, false)
    assert.throws(() => readFileSync(app.file), { code: 'ENOENT' })
  } finally { app.dispose() }
})

test('enabled saved addresses unavailable on the machine fail visibly', () => {
  assert.throws(() => mount({ enabled: true, bindHost: '0.0.0.0' }), /not a selectable local interface address/)
  assert.throws(() => mount({ enabled: true, bindHost: '192.0.2.254' }), /not a selectable local interface address/)
})
