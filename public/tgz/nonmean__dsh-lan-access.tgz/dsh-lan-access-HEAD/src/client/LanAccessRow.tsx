/**
 * LAN-access preference row in the General settings section (the DSH
 * settings-row recipe: title/description left, control right, hairline
 * separator; the section column strips the trailing one).
 *
 * The row talks to the fenced /lan-access host route directly. Flipping the
 * switch persists the plugin-owned flag and restarts the web server to bind
 * the chosen concrete interface address. The listener binds ONE address, so a
 * page served from any other origin loses the server the moment the bind
 * moves: that page cannot confirm the change by polling (its origin will never
 * answer again). The row therefore reflects such a change optimistically and
 * points at the new address instead of reporting a reconnect failure; only a
 * restart on the page's own origin is polled.
 */
import { useCallback, useEffect, useRef, useState, useSyncExternalStore, type CSSProperties } from 'react'
import { LanAccessApiError, getHandoffUrl, getState, setEnabled, type LanAccessState } from './api.ts'
import { activeLocale, subscribeLocale, translate } from './locales.ts'
import { originSurvivesRebind, reboundTarget } from './reconnect.ts'

/** The registration-side injected face (empty — the row owns its own state). */
export interface LanAccessRowInjected {
  /** Marker field: no business face is shared with the apply world. */
  children?: never
}

/** Full component props of the row. */
export type LanAccessRowProps = LanAccessRowInjected

/** Poll cadence while the web server restarts on the page's own origin. */
const POLL_INTERVAL_MS = 600
/** Give up after this long without a reachable server. */
const POLL_TIMEOUT_MS = 15000

/** Re-render on locale switches (the DSH locale service is uSES-safe). */
function useLocale(): string {
  return useSyncExternalStore(subscribeLocale, activeLocale)
}

/** The current page hostname, or '' outside a browser. */
function pageHostname(): string {
  return typeof location !== 'undefined' ? location.hostname : ''
}

/** Map one failure to copy: network errors and the timeout get friendly text
 *  instead of the raw "Failed to fetch" the browser reports mid-restart. */
function messageOf(error: unknown, fallback: string): string {
  if (error instanceof LanAccessApiError) {
    if (error.code === 'timeout') return translate('timeout')
    if (error.code === 'network') return fallback
  }
  return error instanceof Error && error.message !== '' ? error.message : fallback
}

/** Sleep helper. */
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/* Row tokens, mirroring the native DSH Settings cell: 14/22 title, 12/18
 * secondary copy, 16px/0 cell padding, hairline separator. */
const rowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  padding: '16px 0',
  borderBottom: '0.5px solid var(--dsw-alias-border-l2)',
}
const textStyle: CSSProperties = {
  flex: 1,
  minWidth: 0,
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  paddingRight: 48,
}
const titleStyle: CSSProperties = {
  fontSize: 14,
  fontWeight: 400,
  lineHeight: '22px',
  color: 'var(--dsw-alias-label-primary)',
}
const descStyle: CSSProperties = {
  fontSize: 12,
  fontWeight: 400,
  lineHeight: '18px',
  color: 'var(--dsw-alias-label-tertiary)',
}
const addressRowStyle: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  alignItems: 'center',
  gap: 8,
  marginTop: 4,
}
const addressLabelStyle: CSSProperties = {
  fontSize: 14,
  lineHeight: '22px',
  color: 'var(--dsw-alias-label-secondary)',
}
const selectWrapStyle: CSSProperties = {
  position: 'relative',
  display: 'inline-flex',
  alignItems: 'center',
  minWidth: 0,
  maxWidth: '100%',
}
const selectStyle: CSSProperties = {
  appearance: 'none',
  WebkitAppearance: 'none',
  height: 36,
  maxWidth: '100%',
  padding: '0 34px 0 14px',
  border: 'none',
  borderRadius: 'var(--dsw-radius-md)',
  background: 'var(--dsw-alias-bg-module-platform)',
  font: 'inherit',
  fontSize: 14,
  lineHeight: '22px',
  color: 'var(--dsw-alias-label-primary)',
  textOverflow: 'ellipsis',
  cursor: 'pointer',
}
/** Border-drawn chevron (adapts to the label token in light/dark). */
const chevronStyle: CSSProperties = {
  position: 'absolute',
  right: 14,
  top: '50%',
  width: 7,
  height: 7,
  borderRight: '1.5px solid var(--dsw-alias-label-secondary)',
  borderBottom: '1.5px solid var(--dsw-alias-label-secondary)',
  transform: 'translateY(-70%) rotate(45deg)',
  pointerEvents: 'none',
}
const noticeStyle: CSSProperties = {
  fontSize: 12,
  fontWeight: 400,
  lineHeight: '18px',
  color: 'var(--dsw-alias-label-tertiary)',
}
const linkStyle: CSSProperties = {
  color: 'var(--dsw-alias-state-business-primary)',
  wordBreak: 'break-all',
}
const errorStyle: CSSProperties = {
  fontSize: 12,
  lineHeight: '18px',
  color: 'var(--dsw-alias-label-danger, #d92d20)',
}
const urlCodeStyle: CSSProperties = {
  fontSize: 12,
  lineHeight: '18px',
  color: 'var(--dsw-alias-label-primary)',
  background: 'var(--dsw-alias-bg-module-platform)',
  padding: '2px 8px',
  borderRadius: 6,
}
const copyStyle: CSSProperties = {
  border: 'none',
  background: 'transparent',
  padding: 0,
  font: 'inherit',
  fontSize: 12,
  lineHeight: '18px',
  color: 'var(--dsw-alias-state-business-primary)',
  cursor: 'pointer',
}
const urlRowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: 8,
  marginTop: 2,
}

/** Two-state switch matching the native DSH control (36x20 capsule, 16px thumb). */
function Switch(props: {
  checked: boolean
  disabled?: boolean
  label: string
  onChange: (next: boolean) => void
}) {
  const { checked, disabled, label, onChange } = props
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => { onChange(!checked) }}
      style={{
        position: 'relative',
        flex: '0 0 auto',
        boxSizing: 'border-box',
        width: 36,
        height: 20,
        padding: 2,
        border: 'none',
        borderRadius: 999,
        background: checked ? 'var(--dsw-alias-brand-primary)' : 'var(--dsw-alias-border-l3)',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transition: 'background 120ms ease',
      }}
    >
      <span
        style={{
          display: 'block',
          width: 16,
          height: 16,
          borderRadius: '50%',
          background: checked ? 'var(--dsw-alias-label-primary-foreground)' : 'var(--dsw-alias-switch-thumb)',
          transform: checked ? 'translateX(16px)' : 'none',
          transition: 'transform 120ms ease, background 120ms ease',
        }}
      />
    </button>
  )
}

/**
 * Render the LAN-access preference row.
 * @returns the row element tree.
 */
export function LanAccessRow(_props: LanAccessRowProps) {
  useLocale() // re-render on locale switch
  const [state, setState] = useState<LanAccessState | null>(null)
  const [bindHost, setBindHost] = useState('')
  const [reconnectUrl, setReconnectUrl] = useState<string | null>(null)
  const [reconnectHref, setReconnectHref] = useState<string | null>(null)
  const [notice, setNotice] = useState<'enabled' | 'disabled' | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [autoReconnect, setAutoReconnect] = useState(false)
  const handoffRef = useRef<string | null>(null)

  const load = useCallback(async (): Promise<void> => {
    // The settings seam may still be booting right after a page load, and a
    // rebind restart can cut the first reads — retry a few times before
    // reporting a failure.
    for (let attempt = 0; attempt < 6; attempt += 1) {
      try {
        const next = await getState()
        setState(next)
        setBindHost(next.bindHost ?? '')
        setError(null)
        return
      } catch (error) {
        const networkish = error instanceof LanAccessApiError
          && (error.code === 'network' || error.code === 'not-ready')
        if (!networkish) {
          setError(messageOf(error, translate('loadFailed')))
          return
        }
        if (attempt < 5) await sleep(700 + attempt * 500)
      }
    }
    setError(translate('loadFailed'))
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  // Navigate to the new origin once the host has minted its authenticated URL.
  // The old origin can never answer again; the new page presents the launch
  // token, mints its own session cookie, and reconnects for real.
  useEffect(() => {
    if (!autoReconnect || handoffRef.current === null) return
    const timer = window.setTimeout(() => {
      const target = handoffRef.current
      if (target !== null) window.location.replace(target)
    }, 800)
    return () => { window.clearTimeout(timer) }
  }, [autoReconnect])

  /** Apply one toggle; poll only when the page's own origin survives the rebind. */
  const toggle = useCallback(async (next: boolean): Promise<void> => {
    if (next && bindHost === '') {
      setError(translate('chooseAddress'))
      return
    }
    setBusy(true)
    setError(null)
    setNotice(null)
    setAutoReconnect(false)
    handoffRef.current = null
    const targetHost = next ? bindHost : '127.0.0.1'
    // The listener binds one concrete address. A page served from another
    // address loses the server when the bind moves and cannot poll for the
    // result; only a restart on this page's own origin is observable.
    const originSurvives = originSurvivesRebind(pageHostname(), next, bindHost)
    // The launch token is process-scoped; reboundTarget carries it across the
    // origin change when the current URL still has it.
    const target = next ? reboundTarget(window.location.href, bindHost) : undefined
    const targetOrigin = target?.origin ?? null
    setReconnectUrl(targetOrigin)
    setReconnectHref(target?.href ?? null)
    // The POST response is lost when the rebind restarts the server, so mint
    // the tokenized target URL now, while this origin can still answer.
    const handoff = next && !originSurvives ? await getHandoffUrl(bindHost) : null
    try {
      try {
        await setEnabled(next, bindHost || undefined)
      } catch (error) {
        // The rebind restarts the web server mid-request, which cuts the
        // POST's own connection: the write may still have landed, so a
        // network failure is not a failure. Anything else (fence, 4xx/5xx
        // envelope) fails loud.
        if (!(error instanceof LanAccessApiError) || error.code !== 'network') throw error
      }
      if (!originSurvives) {
        // The host persisted the write before rebinding, and this origin will
        // not answer again. Reflect the change and guide the user instead of
        // waiting out a reconnect that can never succeed.
        setState(prev => prev === null ? prev : {
          ...prev,
          enabled: next,
          host: targetHost,
          bindHost: next ? bindHost : prev.bindHost,
          pending: false,
          url: next ? targetOrigin : null,
        })
        setNotice(next ? 'enabled' : 'disabled')
        if (next && handoff !== null) {
          handoffRef.current = handoff
          setAutoReconnect(true)
        }
        return
      }
      // Same-origin restart: poll until the fresh state lands.
      const deadline = Date.now() + POLL_TIMEOUT_MS
      for (;;) {
        try {
          const fresh = await getState()
          if (fresh.ready && !fresh.pending && fresh.enabled === next && fresh.host === targetHost) {
            setState(fresh)
            setBindHost(fresh.bindHost ?? '')
            setReconnectUrl(null)
            setReconnectHref(null)
            setAutoReconnect(false)
            handoffRef.current = null
            break
          }
        } catch {
          // The web server is restarting.
        }
        if (Date.now() > deadline) {
          throw new LanAccessApiError('timeout', translate('timeout'))
        }
        await sleep(POLL_INTERVAL_MS)
      }
    } catch (error) {
      setReconnectUrl(null)
      setReconnectHref(null)
      setNotice(null)
      setAutoReconnect(false)
      handoffRef.current = null
      setError(messageOf(error, translate('saveFailed')))
    } finally {
      setBusy(false)
    }
  }, [bindHost])

  const enabled = state?.enabled ?? false
  const ready = state?.ready === true && !busy
  const addresses = state?.addresses ?? []
  const hasAddress = addresses.includes(bindHost)
  const selectDisabled = !ready || enabled
  const copyUrl = (): void => {
    if (state?.url === null || state?.url === undefined) return
    void navigator.clipboard?.writeText(state.url).then(() => {
      setCopied(true)
      setTimeout(() => { setCopied(false) }, 1200)
    }).catch(() => {})
  }

  return (
    <div style={rowStyle}>
      <div style={textStyle}>
        <div style={titleStyle}>{translate('title')}</div>
        <div style={descStyle}>{translate('desc')}</div>
        {state?.migrationRequired === true && (
          <div role="status" style={noticeStyle}>{translate('migration')}</div>
        )}
        <div style={addressRowStyle}>
          <span style={addressLabelStyle}>{translate('addressLabel')}</span>
          <span style={selectWrapStyle}>
            <select
              value={bindHost}
              disabled={selectDisabled}
              onChange={(event) => { setBindHost(event.currentTarget.value); setNotice(null); setAutoReconnect(false) }}
              style={{ ...selectStyle, opacity: selectDisabled ? 0.6 : 1, cursor: selectDisabled ? 'default' : 'pointer' }}
            >
              <option value="">{translate('chooseAddress')}</option>
              {bindHost !== '' && !hasAddress && <option value={bindHost}>{bindHost}</option>}
              {addresses.map(address => <option key={address} value={address}>{address}</option>)}
            </select>
            <span aria-hidden="true" style={chevronStyle} />
          </span>
        </div>
        {notice === 'enabled' && autoReconnect && (
          <div role="status" style={noticeStyle}>
            {translate('switching')}{' '}
            {reconnectUrl !== null && <code style={urlCodeStyle}>{reconnectUrl}</code>}
          </div>
        )}
        {notice === 'enabled' && !autoReconnect && reconnectUrl !== null && (
          <div role="status" style={noticeStyle}>
            {translate('switchedOn')}{' '}
            <a href={reconnectHref ?? reconnectUrl} style={linkStyle}>{reconnectUrl}</a>
          </div>
        )}
        {notice === 'disabled' && (
          <div role="status" style={noticeStyle}>{translate('switchedOff')}</div>
        )}
        {notice !== 'enabled' && state?.ready === true && state.enabled && state.url !== null && (
          <div style={urlRowStyle}>
            <span style={noticeStyle}>{translate('urlLabel')}</span>
            <code style={urlCodeStyle}>{state.url}</code>
            <button type="button" onClick={copyUrl} style={copyStyle}>
              {copied ? translate('copied') : translate('copy')}
            </button>
          </div>
        )}
        {state === null && !busy && <div style={noticeStyle}>{translate('loading')}</div>}
        {busy && <div style={noticeStyle}>{translate('applying')}</div>}
        {error !== null && <div role="alert" style={errorStyle}>{error}</div>}
      </div>
      <Switch
        checked={enabled}
        disabled={!ready || (!enabled && !hasAddress)}
        label={translate('title')}
        onChange={(next) => { void toggle(next) }}
      />
    </div>
  )
}
