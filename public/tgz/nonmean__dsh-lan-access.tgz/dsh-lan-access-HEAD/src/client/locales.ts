/**
 * zh/en copy for the LAN-access settings row, registered into the DSH locale
 * registry under the plugin namespace. `attachLocale` binds the client
 * locale service (provided by @deepseek-ai/dsh-client-locale) at apply time;
 * `translate` resolves the active locale through it, falling back to the
 * browser language when the service is absent (standalone/test compositions).
 */

/** Locale dictionary key space (one key per row string). */
export type LanAccessDict = {
  title: string
  desc: string
  urlLabel: string
  copy: string
  copied: string
  applying: string
  loading: string
  loadFailed: string
  saveFailed: string
  timeout: string
  addressLabel: string
  chooseAddress: string
  migration: string
  switchedOn: string
  switchedOff: string
  switching: string
}

/** Simplified Chinese copy. */
export const zh: LanAccessDict = {
  addressLabel: '监听地址',
  chooseAddress: '选择本机 IP 地址',
  migration: '旧版局域网设置需要选择具体 IP。当前仅监听回环地址，保存的设置尚未更改。',
  switchedOn: '局域网访问已开启。请打开以下地址继续：',
  switchedOff: '局域网访问已关闭，服务器现在仅监听回环地址。',
  switching: '局域网访问已开启，正在连接到新地址…',
  title: '局域网访问',
  desc: '选择一个本机 IP 地址，允许同一网络中的其他设备访问。切换后需打开新地址并重新认证。',
  urlLabel: '其他设备可访问',
  copy: '复制',
  copied: '已复制',
  applying: '正在应用更改，此页面将断开连接…',
  loading: '加载中…',
  loadFailed: '无法读取访问状态',
  saveFailed: '更改失败',
  timeout: '服务器重启后未能重新连接，请刷新页面重试',
}

/** English copy. */
export const en: LanAccessDict = {
  addressLabel: 'Bind address',
  chooseAddress: 'Select a local IP address',
  migration: 'The previous LAN setting needs a concrete IP. Serving loopback; saved settings have not been changed.',
  switchedOn: 'LAN access is on. Open the new address to continue:',
  switchedOff: 'LAN access is off. The server now listens on loopback only.',
  switching: 'LAN access is on. Reconnecting to the new address…',
  title: 'LAN access',
  desc: 'Choose one local IP for other devices to access. After switching, open the new address and authenticate again.',
  urlLabel: 'Other devices can open',
  copy: 'Copy',
  copied: 'Copied',
  applying: 'Applying change — this page will disconnect…',
  loading: 'Loading…',
  loadFailed: 'Failed to read the access state',
  saveFailed: 'Failed to apply the change',
  timeout: 'Could not reconnect after the server restart — refresh the page',
}

/** The plugin's locale namespace (dictionary registry key). */
export const LOCALE_NS = 'lan-access'

/** The locale service face this plugin consumes (subset of LocaleRuntime). */
export interface LanAccessLocaleService {
  getSnapshot(): { active: string }
  subscribe(fn: () => void): () => void
  register(ns: string, locale: string, dict: Record<string, string>): () => void
}

let service: LanAccessLocaleService | undefined

/** Bind the locale service (apply time); the row re-renders on locale switches. */
export function attachLocale(locale: LanAccessLocaleService): void {
  service = locale
}

/** Current active locale id ('zh' | 'en'), or a browser-language guess. */
export function activeLocale(): string {
  if (service !== undefined) return service.getSnapshot().active
  if (typeof navigator !== 'undefined') {
    const primary = (navigator.language ?? '').toLowerCase().split('-')[0]
    if (primary === 'zh') return 'zh'
  }
  return 'en'
}

/** Resolve one copy key in the active locale. */
export function translate(key: keyof LanAccessDict): string {
  const dict = activeLocale() === 'zh' ? zh : en
  return dict[key] ?? String(key)
}

/** React subscription seam for the active locale (useSyncExternalStore). */
export function subscribeLocale(fn: () => void): () => void {
  return service?.subscribe(fn) ?? (() => {})
}
