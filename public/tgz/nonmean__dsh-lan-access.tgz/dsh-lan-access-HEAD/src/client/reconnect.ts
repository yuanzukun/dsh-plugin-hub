/**
 * Pure rebind helpers for the LAN-access settings row.
 *
 * The listener binds ONE concrete interface address. A page served from any
 * other origin loses the server the moment the bind moves, so the row must
 * decide up front whether it can observe the restart at all. Keeping that
 * decision (and the new-origin construction) free of React makes it testable.
 */

/** Canonical WHATWG host form (IPv6 canonicalized and bracketed, lowercased). */
export function normalizeHost(host: string): string {
  const bracketed = host.includes(':') && !host.startsWith('[') ? `[${host}]` : host
  try {
    return new URL(`http://${bracketed}`).hostname.toLowerCase()
  } catch {
    return host.toLowerCase()
  }
}

/** Whether a hostname names the local loopback authority. */
export function isLoopbackName(host: string): boolean {
  const value = normalizeHost(host)
  return value === 'localhost' || value === '[::1]' || /^127(?:\.\d{1,3}){3}$/.test(value)
}

/** Whether two hostnames name the same interface literal (equivalent IPv6 spellings included). */
export function sameHostname(left: string, right: string): boolean {
  return normalizeHost(left) === normalizeHost(right)
}

/**
 * Whether a page served from `currentHost` can still reach the server after
 * the toggle is applied. Enabling survives only when the page is already on
 * the exact address being bound; disabling survives only on a loopback page.
 * @param currentHost - the page's hostname (WHATWG form).
 * @param enabled - the target state.
 * @param bindHost - the concrete address to bind when enabling.
 * @returns true when the same origin can poll for the restart.
 */
export function originSurvivesRebind(currentHost: string, enabled: boolean, bindHost: string): boolean {
  return enabled ? sameHostname(currentHost, bindHost) : isLoopbackName(currentHost)
}

/**
 * The listener URL an enable moves to, carrying the launch token when the
 * current URL still has one.
 * @param href - the current page URL.
 * @param bindHost - the concrete address to bind.
 * @returns display origin plus link href (token included).
 */
export function reboundTarget(href: string, bindHost: string): { origin: string; href: string } {
  const current = new URL(href)
  const target = new URL(current.href)
  target.hostname = normalizeHost(bindHost)
  target.search = ''
  target.hash = ''
  const token = current.searchParams.get('token')
  if (token !== null) target.searchParams.set('token', token)
  return { origin: target.origin, href: target.href }
}
