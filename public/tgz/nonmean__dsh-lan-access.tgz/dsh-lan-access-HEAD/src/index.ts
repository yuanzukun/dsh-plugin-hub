/** LAN-access controller with a persisted, explicitly selected local bind address. */
import { AsyncResource } from 'node:async_hooks'
import { execFile } from 'node:child_process'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { SettingsConflictError } from '@deepseek-ai/dsh-settings'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import type { Context } from '@deepseek-ai/cordis'
import { availableAddresses, selectAddress, listenerUrl, temporaryAddresses } from './bind-address.ts'

/** Bind host values the webserver schema accepts. */
export type LanAccessHost = string

/** File name of the plugin-owned persisted state under the harness home. */
export const LAN_ACCESS_STATE_FILE = 'lan-access.json'

/** The plugin's persisted state (owned by the plugin, not the settings plane). */
export interface LanAccessPersistedState {
  /** Whether the selected local interface should be exposed. */
  enabled: boolean
  /** Selected concrete local interface address. */
  bindHost?: string
}

/**
 * Absolute path of the plugin's state file. Prefers the harness-provided
 * `dshHomePath` helper (present under the web boot) and falls back to
 * `$DSH_HOME` / `~/.dsh` for bare compositions and tests.
 */
function lanAccessStatePath(ctx: Context): string {
  const dshHomePath = ctx.get('dshHomePath') as ((...segments: string[]) => string) | undefined
  if (typeof dshHomePath === 'function') return dshHomePath(LAN_ACCESS_STATE_FILE)
  const home = typeof process.env.DSH_HOME === 'string' && process.env.DSH_HOME.trim() !== ''
    ? process.env.DSH_HOME
    : join(homedir(), '.dsh')
  return join(home, LAN_ACCESS_STATE_FILE)
}

/** Read plugin-owned settings. Only a missing file uses the disabled default. */
function readPersistedState(ctx: Context): LanAccessPersistedState {
  let text: string
  try {
    text = readFileSync(lanAccessStatePath(ctx), 'utf8')
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') return { enabled: false }
    throw error
  }
  const raw: unknown = JSON.parse(text)
  if (raw === null || typeof raw !== 'object' || !('enabled' in raw) || typeof raw.enabled !== 'boolean'
    || ('bindHost' in raw && typeof raw.bindHost !== 'string')) {
    throw new Error(`LAN access: invalid state in ${lanAccessStatePath(ctx)}; expected { enabled: boolean, bindHost?: string }`)
  }
  return { enabled: raw.enabled, ...('bindHost' in raw && typeof raw.bindHost === 'string' ? { bindHost: raw.bindHost } : {}) }
}

/** Persist the selected address and enabled flag in the plugin-owned file. */
function persistState(ctx: Context, state: LanAccessPersistedState): void {
  const path = lanAccessStatePath(ctx)
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, JSON.stringify(state, null, 2) + '\n', 'utf8')
}

/** One webserver service slice this plugin reads. */
export interface LanAccessWebServer {
  readonly host: LanAccessHost
  readonly port: number | undefined
  readonly protocol: 'http:' | 'https:'
  getOrigin(): string
  register(route: {
    kind: 'exact' | 'prefix'
    path: string
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>
  }): () => void
}

/** One loader entry slice this plugin reads (the connection row's config). */
export interface LanAccessLoaderEntry {
  /** Fully-qualified entry id (group-prefixed; the address for loader.update). */
  id: string
  options: { name: string; config?: unknown }
  /** The entry's live fiber; its config is the post-interpolation resolved value. */
  fiber?: {
    config?: unknown
    /** Restart this fiber with new config; `noSave` suppresses a tree write-back. */
    update?(config: unknown, noSave?: boolean): void | Promise<void>
  }
}

/** The loader service face (structural subset of the cordis-plugin-loader tree). */
export interface LanAccessLoader {
  entries(): Iterable<LanAccessLoaderEntry>
  update(id: string, options: { config?: unknown }): Promise<void>
}

/** The host connection face used to mint an authenticated URL for the new origin. */
export interface LanAccessHostConnection {
  /** Append this process's launch token to a clean application URL. */
  authenticatedUrl(baseUrl: string): string
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    loader: LanAccessLoader
    webServer: LanAccessWebServer
    /** The live bind-host source the webserver row's `host` expression reads. */
    lanAccess: LanAccessBindService
  }
}

/**
 * The bind-host source service: the webserver row's composed config carries
 * `host: !!js ctx.get('lanAccess')?.host ?? '127.0.0.1'`, so EVERY webserver
 * fiber (re)start — the initial boot, a toggle-triggered restart, and the
 * post-boot user-patch re-apply alike — evaluates the CURRENT persisted
 * setting instead of a literal that a later patch layer can clobber.
 */
export interface LanAccessBindService {
  /** The host the webserver should bind, from the persisted setting. */
  readonly host: LanAccessHost
}

/** Stable Cordis plugin name (the loader row mounts this package). */
export const name = 'dsh-lan-access'

/** Services required before mounting: the loader tree (for the webserver row and the connection row's trusted hosts). */
export const inject = ['loader']

/** The webserver row's plugin name (matched by name — its entry id is group-prefixed). */
const WEBSERVER_PLUGIN = '@deepseek-ai/dsh-host-webserver'

/** The connection row whose resolved `trustedHosts` the /api fence uses. */
const CONNECTION_ROW = '@deepseek-ai/dsh-client-connection'

/** Request-body size bound of the POST write (defense against unbounded reads). */
const MAX_BODY_BYTES = 64 * 1024

/** An HTTP failure with a wire code and status. */
class LanAccessHttpError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly status = 400,
  ) {
    super(message)
  }
}

/* ── browser-trust fence (behaviorally identical to the /api gateway's fence
   in @deepseek-ai/dsh-client-connection; helpers restated because the package
   does not export them and this plugin must not depend on its internals).
   Host-header loopback or a configured trusted authority passes; cross-site
   browser markers refuse. This is a DNS-rebinding / cross-site defense, not
   authentication. */

function header(headers: IncomingMessage['headers'], name: string): string | undefined {
  const value = headers[name]
  return typeof value === 'string' ? value : undefined
}

/** Normalized URL of a Host-header authority, or undefined when unparsable. */
function parseAuthority(authority: string): URL | undefined {
  try {
    return new URL(`http://${authority}`)
  } catch {
    return undefined
  }
}

/** Whether a normalized URL hostname names the local loopback authority. */
function isLoopbackHostname(hostname: string): boolean {
  if (hostname === 'localhost' || hostname === '[::1]') return true
  const parts = hostname.split('.')
  return parts.length === 4
    && parts[0] === '127'
    && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255)
}

/** Canonical authority form: hostname, or hostname:port when a port was written. */
function canonicalAuthority(entry: string, entryUrl: URL): string {
  const port = entryUrl.port !== '' ? entryUrl.port : new URL(`https://${entry}`).port
  return port === '' ? entryUrl.hostname : `${entryUrl.hostname}:${port}`
}

/** Whether the request authority matches a trustedHosts entry (exact or port-less). */
function isTrustedAuthority(hostUrl: URL, trustedHosts: readonly string[]): boolean {
  return trustedHosts.some((entry) => {
    const entryUrl = parseAuthority(entry)
    if (entryUrl === undefined) return false
    return canonicalAuthority(entry, entryUrl) === entryUrl.hostname
      ? entryUrl.hostname === hostUrl.hostname
      : entryUrl.host === hostUrl.host
  })
}

/** Decide whether one request may reach the plugin route. */
function isTrustedApiRequest(req: IncomingMessage, trustedHosts: readonly string[], bindHost?: string): boolean {
  const host = header(req.headers, 'host')
  if (host === undefined) return false
  const hostUrl = parseAuthority(host)
  if (hostUrl === undefined) return false
  const bindHostname = bindHost === undefined ? undefined : new URL(listenerUrl(bindHost, 80, false)).hostname
  if (!isLoopbackHostname(hostUrl.hostname) && hostUrl.hostname !== bindHostname && !isTrustedAuthority(hostUrl, trustedHosts)) return false
  if (header(req.headers, 'sec-fetch-site') === 'cross-site') return false
  const origin = header(req.headers, 'origin')
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}

/* ── /lan-access route ──────────────────────────────────────────────────── */

/** Wire state of the LAN-access feature. */
export interface LanAccessState {
  /** Whether the webserver is up (false while booting). */
  ready: boolean
  /** The persisted enabled flag. */
  enabled: boolean
  /** The current webserver bind host. */
  host: LanAccessHost | null
  /** The current webserver port. */
  port: number | null
  /** Whether a bind change is currently being applied. */
  pending: boolean
  /** Selectable concrete local interface addresses. */
  addresses: string[]
  /** Saved interface selection, including while disabled. */
  bindHost: string | null
  /** Existing enabled settings need an explicit address before exposure. */
  migrationRequired: boolean
  /** The LAN URL to open from other devices, when one is served. */
  url: string | null
}

/** Read the connection row's resolved trusted authorities, live. */
function trustedHostsOf(loader: LanAccessLoader): string[] {
  for (const entry of loader.entries()) {
    if (entry.options.name !== CONNECTION_ROW) continue
    // Prefer the fiber's RESOLVED config (the post-interpolation value the
    // /api fence itself reads): the composed row carries
    // `trustedHosts: !!js ctx.webStartup.trustedHosts`, which only the
    // connection fiber may evaluate. The listener bind IP is accepted separately from these authorities.
    const fiberConfig = (entry as { fiber?: { config?: unknown } }).fiber?.config as
      { trustedHosts?: unknown } | undefined
    const raw = fiberConfig?.trustedHosts
    if (Array.isArray(raw)) return raw.filter((x): x is string => typeof x === 'string')
    return []
  }
  return []
}

/** Read a bounded JSON request body. */
async function readJsonBody(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = []
  let total = 0
  for await (const chunk of req) {
    const buffer = typeof chunk === 'string' ? Buffer.from(chunk) : chunk
    total += buffer.length
    if (total > MAX_BODY_BYTES) {
      throw new LanAccessHttpError('payload-too-large', 'request body too large', 413)
    }
    chunks.push(buffer)
  }
  if (total === 0) return null
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'))
  } catch {
    throw new LanAccessHttpError('bad-request', 'request body is not valid JSON', 400)
  }
}

/** Write one JSON response (the socket may die mid-rebind; never throw). */
function writeJson(res: ServerResponse, status: number, body: unknown): void {
  try {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
    res.end(JSON.stringify(body))
  } catch {
    /* the request already dropped (webserver restart) — nothing to answer */
  }
}

/* ── settings/credentials RPC proxy ───────────────────────────────────────
   The /api gateway pins the whole configuration plane (settings.*,
   credentials.*) to loopback even on trusted-host deployments. For a
   LAN-served GUI this plugin mirrors the settings + credentials domains on
   its own fenced route (/lan-access/rpc) so the remote Settings surfaces
   (Models provider directory, Plugins cards, Language/Appearance rows)
   work. The proxy reuses the same exposure boundary as the /api gateway:
   model-provider namespaces plus the web/product allowlist, redacted
   values, revision-fenced writes, and the same error codes. It is not a
   bypass — the route sits behind the identical browser-trust fence. */

/** Web-surface settings namespaces the /api proxy exposes (its allowlist mirror). */
const WEB_SETTINGS_NAMESPACES = [
  'agent-loop', 'shell', 'locale', 'permission', 'ui-conversation', 'ui-theme', 'web-search-deepseek',
] as const

/** Product-owned settings namespaces (the api-proxy's product allowlist mirror). */
const PRODUCT_SETTINGS_NAMESPACES = ['ui-onboarding', 'agent-presets'] as const

/** The llm service face used to enumerate configurable provider namespaces. */
interface LanAccessLlmService {
  listConfigurableProviders(): Array<{ settingsNs: string }>
}

/** The settings seam face (structural subset of SettingsProvider). */
interface LanAccessSettingsSeam {
  readonly writable: boolean
  readonly documentPath?: string
  describe(options?: { redactSecrets?: boolean }): unknown[]
  update(ns: string, patch: object, expectedRevision?: number): Promise<void>
  replace(ns: string, section: object, expectedRevision?: number): Promise<void>
  mutate(ns: string, ops: readonly unknown[], expectedRevision?: number): Promise<void>
  prepareDocument(): Promise<string | undefined>
}

/** Open one path with the OS default application (Finder/Explorer/xdg-open). */
function openWithSystem(path: string): void {
  if (process.platform === 'darwin') {
    execFile('open', [path], { timeout: 5000 }, () => {})
  } else if (process.platform === 'linux') {
    execFile('xdg-open', [path], { timeout: 5000 }, () => {})
  } else {
    execFile('cmd', ['/c', 'start', '', path], { timeout: 5000 }, () => {})
  }
}

/** The credentials seam face (structural subset of CredentialProvider). */
interface LanAccessCredentialsSeam {
  describe(ref: string): Promise<{ configured: boolean; source?: string; writable: boolean }>
  set(ref: string, value: string): Promise<void>
  unset(ref: string): Promise<void>
}

/** One RPC result envelope (mirror of the /api RpcResult wire form). */
type LanAccessRpcResult =
  | { ok: true; value: unknown }
  | { ok: false; error: { code: string; message: string; details: Record<string, unknown> } }

/** One RPC response envelope; rpcId echoes the request. */
interface LanAccessRpcResponse {
  rpcId: string
  result: LanAccessRpcResult
}

function rpcOk(rpcId: string, value: unknown): LanAccessRpcResponse {
  return { rpcId, result: { ok: true, value } }
}

function rpcErr(
  rpcId: string,
  code: string,
  message: string,
  details: Record<string, unknown> = {},
): LanAccessRpcResponse {
  return { rpcId, result: { ok: false, error: { code, message, details } } }
}

/** The settings namespaces this proxy serves — the api-proxy exposure mirror. */
function exposedSettingsNamespaces(ctx: Context): Set<string> {
  const exposed = new Set<string>(WEB_SETTINGS_NAMESPACES)
  for (const ns of PRODUCT_SETTINGS_NAMESPACES) exposed.add(ns)
  const llm = ctx.get('llm') as LanAccessLlmService | undefined
  for (const entry of llm?.listConfigurableProviders() ?? []) exposed.add(entry.settingsNs)
  return exposed
}

/** Map one redacted settings descriptor to its wire view (api-proxy namespaceView mirror). */
function namespaceViewOf(descriptor: {
  ns: unknown
  schema: unknown
  value: unknown
  base?: unknown
  user?: unknown
  applies: string
  revision: number
  secrets?: Array<{ path: readonly string[]; set: boolean }>
}): Record<string, unknown> {
  return {
    ns: String(descriptor.ns),
    schema: descriptor.schema,
    value: descriptor.value,
    ...descriptor.base === undefined ? {} : { base: descriptor.base },
    ...descriptor.user === undefined ? {} : { user: descriptor.user },
    applies: descriptor.applies,
    secrets: (descriptor.secrets ?? []).map(secret => ({ path: [...secret.path], set: secret.set })),
    revision: descriptor.revision,
  }
}

/** settings.update/replace/mutate with the api-proxy exposure + error mapping. */
async function settingsWriteRpc(
  ctx: Context,
  rpcId: string,
  ns: string,
  mode: 'update' | 'replace' | 'mutate',
  section: unknown,
  expectedRevision?: number,
): Promise<LanAccessRpcResponse> {
  const settings = ctx.get('settings') as LanAccessSettingsSeam | undefined
  if (settings === undefined) return rpcErr(rpcId, 'internal', 'settings service is absent')
  if (!exposedSettingsNamespaces(ctx).has(ns)) {
    return rpcErr(rpcId, 'settings-not-exposed', `settings namespace "${ns}" is not exposed to configuration clients`)
  }
  try {
    if (mode === 'update') await settings.update(ns, section as object, expectedRevision)
    else if (mode === 'replace') await settings.replace(ns, section as object, expectedRevision)
    else await settings.mutate(ns, section as readonly unknown[], expectedRevision)
  } catch (error: unknown) {
    if (error instanceof SettingsConflictError) {
      return rpcErr(rpcId, 'settings-conflict', error.message, {
        ns, expected: error.expected, actual: error.actual,
      })
    }
    return rpcErr(rpcId, 'settings-rejected', error instanceof Error ? error.message : String(error))
  }
  const descriptor = (settings.describe({ redactSecrets: true }) as Array<{ ns: unknown }>).find(candidate => String(candidate.ns) === ns)
  if (descriptor === undefined) {
    return rpcErr(rpcId, 'internal', `settings namespace "${ns}" was disposed after the ${mode}`)
  }
  return rpcOk(rpcId, namespaceViewOf(descriptor as Parameters<typeof namespaceViewOf>[0]))
}

/** Dispatch one proxied settings/credentials method (mirror of the /api domains). */
async function dispatchLanAccessRpc(ctx: Context, method: string, payload: unknown): Promise<LanAccessRpcResponse> {
  const record = (payload ?? {}) as Record<string, unknown>
  const rpcId = typeof record.rpcId === 'string' ? record.rpcId : 'lan-access'
  switch (method) {
    case 'settings.describe': {
      const settings = ctx.get('settings') as LanAccessSettingsSeam | undefined
      if (settings === undefined) return rpcErr(rpcId, 'internal', 'settings service is absent')
      const exposed = exposedSettingsNamespaces(ctx)
      return rpcOk(rpcId, {
        writable: settings.writable,
        hasDocument: settings.documentPath !== undefined,
        namespaces: (settings.describe({ redactSecrets: true }) as Parameters<typeof namespaceViewOf>[0][])
          .filter(descriptor => exposed.has(String(descriptor.ns)))
          .map(namespaceViewOf),
      })
    }
    case 'settings.update':
    case 'settings.replace':
    case 'settings.mutate': {
      const ns = record.ns
      if (typeof ns !== 'string') return rpcErr(rpcId, 'bad-request', 'expected a string "ns"')
      const expectedRevision = typeof record.expectedRevision === 'number' ? record.expectedRevision : undefined
      const section = method === 'settings.update' ? record.patch : method === 'settings.replace' ? record.section : record.ops
      return settingsWriteRpc(ctx, rpcId, ns, method.slice('settings.'.length) as 'update' | 'replace' | 'mutate', section, expectedRevision)
    }
    case 'settings.openDocument': {
      const settings = ctx.get('settings') as LanAccessSettingsSeam | undefined
      if (settings === undefined) return rpcErr(rpcId, 'internal', 'settings service is absent')
      let path: string | undefined
      try {
        path = await settings.prepareDocument()
      } catch (error: unknown) {
        return rpcErr(rpcId, 'internal', `settings document preparation failed: ${error instanceof Error ? error.message : String(error)}`)
      }
      if (path === undefined) return rpcErr(rpcId, 'internal', 'settings provider has no local document to open')
      openWithSystem(path)
      return rpcOk(rpcId, { opened: true })
    }
    case 'credentials.describe': {
      const credentials = ctx.get('credentials') as LanAccessCredentialsSeam | undefined
      if (credentials === undefined) return rpcErr(rpcId, 'internal', 'credentials service is absent')
      const refs = record.refs
      if (!Array.isArray(refs) || refs.some(ref => typeof ref !== 'string')) {
        return rpcErr(rpcId, 'bad-request', 'expected an array of string refs')
      }
      const entries: Record<string, unknown> = {}
      for (const ref of refs as string[]) {
        try {
          const info = await credentials.describe(credentialRef(ref))
          entries[ref] = {
            configured: info.configured,
            ...info.source === undefined ? {} : { source: info.source },
            writable: info.writable,
          }
        } catch (error: unknown) {
          return rpcErr(rpcId, 'credential-rejected', error instanceof Error ? error.message : String(error), { ref })
        }
      }
      return rpcOk(rpcId, { credentials: entries })
    }
    case 'credentials.set':
    case 'credentials.unset': {
      const credentials = ctx.get('credentials') as LanAccessCredentialsSeam | undefined
      if (credentials === undefined) return rpcErr(rpcId, 'internal', 'credentials service is absent')
      const ref = record.ref
      if (typeof ref !== 'string') return rpcErr(rpcId, 'bad-request', 'expected a string "ref"')
      try {
        if (method === 'credentials.set') {
          const value = record.value
          if (typeof value !== 'string') return rpcErr(rpcId, 'bad-request', 'expected a string "value"')
          await credentials.set(credentialRef(ref), value)
        } else {
          await credentials.unset(credentialRef(ref))
        }
      } catch (error: unknown) {
        return rpcErr(rpcId, 'credential-rejected', error instanceof Error ? error.message : String(error), { ref })
      }
      return rpcOk(rpcId, {})
    }
    default:
      return rpcErr(rpcId, 'not-found', `unknown lan-access rpc method "${method}"`)
  }
}

/** The /lan-access/rpc route handler: fenced, POST-only, envelope-mirroring. */
async function handleRpc(
  ctx: Context,
  loader: LanAccessLoader,
  req: IncomingMessage,
  res: ServerResponse,
  log?: (method: string, ok: boolean, code?: string, ns?: string, namespaces?: string[]) => void,
): Promise<void> {
  if (!isTrustedApiRequest(req, trustedHostsOf(loader), (ctx.get('webServer') as LanAccessWebServer | undefined)?.host)) {
    writeJson(res, 403, { ok: false, error: { code: 'forbidden', message: 'request origin is not trusted' } })
    return
  }
  if (req.method !== 'POST') {
    writeJson(res, 405, { ok: false, error: { code: 'method-error', message: 'method not allowed' } })
    return
  }
  const body = await readJsonBody(req)
  const record = (body ?? {}) as Record<string, unknown>
  if (typeof record.method !== 'string' || typeof record.payload !== 'object' || record.payload === null) {
    writeJson(res, 400, { ok: false, error: { code: 'bad-request', message: 'expected {"method", "payload"}' } })
    return
  }
  const rpcId = typeof record.rpcId === 'string' ? record.rpcId : 'lan-access'
  const response = await dispatchLanAccessRpc(ctx, record.method, { rpcId, ...(record.payload as object) })
  if (log !== undefined) {
    const ns = (record.payload as { ns?: unknown } | null)?.ns
    const namespaces = response.result.ok
      ? (response.result.value as { namespaces?: Array<{ ns: unknown }> } | null)?.namespaces?.map(view => String(view.ns))
      : undefined
    log(
      record.method,
      response.result.ok,
      response.result.ok ? undefined : response.result.error.code,
      typeof ns === 'string' ? ns : undefined,
      namespaces,
    )
  }
  writeJson(res, 200, response)
}


/**
 * Mount the LAN-access controller.
 * @param ctx - host context (loader injected).
 */
export function apply(ctx: Context): void {
  const loader = ctx.loader
  // The persisted flag, owned by the plugin (see `persistState`). Read once
  // at mount; the `/lan-access` POST advances it.
  const saved = readPersistedState(ctx)
  let migrationRequired = saved.enabled && saved.bindHost === undefined
  let currentEnabled = saved.enabled && !migrationRequired
  let currentBindHost = saved.bindHost
  if (currentEnabled) currentBindHost = selectAddress(currentBindHost!)
  if (migrationRequired) ctx.logger.warn('LAN access needs an explicit local IP; serving loopback until an address is selected in Settings → General')
  // The live bind-host source for the webserver row's `host` expression
  // (`!!js ctx.get('lanAccess')?.host ?? '127.0.0.1'`, composed by this
  // plugin's bundle patch). Provided by this fiber, which depends only on the
  // loader, so it survives every webserver restart.
  //
  // It is a stable snapshot advanced only by `enqueueApply`: a profile-config
  // reload must recompose the SAME host so the webserver is never restarted
  // inside an HMR transaction (which would bake that transaction's async
  // context into the new server and make every later settings write nest).
  ctx.provide('lanAccess', {
    get host(): LanAccessHost {
      return currentEnabled ? currentBindHost! : '127.0.0.1'
    },
  } satisfies LanAccessBindService)
  // Client boot diagnostics (the last few browser reports; debug aid).
  const diagReports: Array<{ at: number; data: unknown }> = []
  // RPC traffic log (the last 60 proxied calls; debug aid).
  const rpcTraffic: Array<{ at: number; method: string; ok: boolean; code?: string; ns?: string; namespaces?: string[] }> = []
  const logRpc = (method: string, ok: boolean, code?: string, ns?: string, namespaces?: string[]): void => {
    rpcTraffic.push({ at: Date.now(), method, ok, code, ns, namespaces })
    if (rpcTraffic.length > 60) rpcTraffic.shift()
  }
  // Serialized bind application: concurrent toggles queue; the chain stays
  // fulfilled so one failure cannot strand later writes.
  let applying: Promise<void> = Promise.resolve()
  let pendingCount = 0
  // A clean async context captured at mount. A settings write runs the profile
  // reload inside an HMR transaction; a webserver restarted from within that
  // transaction inherits its context, and every later settings write would
  // then be rejected as nested. Running the bind convergence in this scope
  // keeps the restarted webserver on a clean context.
  const applyScope = new AsyncResource('dsh-lan-access:apply')

  const serverOf = (): LanAccessWebServer | undefined =>
    ctx.get('webServer') as LanAccessWebServer | undefined

  const warn = (phase: string, error: unknown): void => {
    ctx.logger.warn('[dsh-lan-access] %s: %s', phase, error instanceof Error ? error.message : String(error))
  }

  /** Find the webserver loader entry by plugin name (its id is group-prefixed). */
  const webserverEntry = (): LanAccessLoaderEntry | undefined => {
    for (const entry of loader.entries()) {
      if (entry.options.name === WEBSERVER_PLUGIN) return entry
    }
    return undefined
  }

  /** Queue one bind convergence; no-ops when the webserver already binds the desired host. */
  const enqueueApply = (enabled: boolean, bindHost = currentBindHost, persist = false): Promise<void> => {
    pendingCount += 1
    const task = applying.then(() => applyScope.runInAsyncScope(async () => {
      const server = serverOf()
      const selected = enabled ? selectAddress(bindHost ?? '') : bindHost
      const desiredHost = enabled ? selected! : '127.0.0.1'
      if (persist) persistState(ctx, { enabled, ...(selected === undefined ? {} : { bindHost: selected }) })
      currentBindHost = selected
      if (persist) migrationRequired = false
      // Advance the service snapshot first: a later recompose of the webserver
      // row (from `lanAccess.host`) must see the value we converge to.
      currentEnabled = enabled
      if (server === undefined) return
      if (server.host === desiredHost) return
      const entry = webserverEntry()
      if (entry === undefined) {
        throw new Error('webserver loader entry not found')
      }
      // Restart the webserver fiber with the new host + the current port. Use
      // the fiber's own `update(config, true)` (the loader's no-save restart
      // path) rather than `loader.update`: the latter persists the composed
      // tree back to cordis.yml, whose Include watcher then hot-reloads the
      // whole subtree and restarts the webserver inside an HMR transaction —
      // tainting it so every later settings write nests. The restart still
      // cascades to dependent rows (the /api fence accepts the concrete bind IP), and the bundle
      // patch's `host` expression reads the live `lanAccess` service, so a
      // later recomposition converges to the same host.
      const fiber = entry.fiber
      if (fiber?.update === undefined) {
        throw new Error('webserver fiber does not support config updates')
      }
      if (fiber.config === null || typeof fiber.config !== 'object') throw new Error('webserver resolved config is unavailable')
      await fiber.update({ ...fiber.config, host: desiredHost }, true)
    }))
    applying = task.catch(() => {})
    void task.finally(() => { pendingCount -= 1 }).catch(() => {})
    return task
  }

  /** Converge the webserver bind to the persisted setting once both sides exist. */
  const align = (): void => {
    if (serverOf() === undefined) return
    void enqueueApply(currentEnabled).catch(error => warn('align', error))
  }

  const stateOf = async (): Promise<LanAccessState> => {
    const server = serverOf()
    const enabled = currentEnabled
    return {
      ready: server?.port !== undefined,
      enabled,
      bindHost: currentBindHost ?? null,
      migrationRequired,
      host: server?.host ?? null,
      port: server?.port ?? null,
      pending: pendingCount > 0 || (server !== undefined && server.host !== (enabled ? currentBindHost : '127.0.0.1')),
      addresses: availableAddresses(undefined, temporaryAddresses()),
      url: enabled && server?.port !== undefined ? server.getOrigin() : null,
    }
  }

  // The fenced route + boot alignment. This child fiber reloads after a
  // rebind (the webserver service disappears and returns), re-registering
  // the route on the fresh server.
  ctx.inject(['webServer'], (httpCtx) => {
    httpCtx.effect(() => httpCtx.webServer.register({
      kind: 'exact',
      path: '/lan-access',
      handler: (req, res) => {
        void handle(req, res).catch((error: unknown) => {
          if (error instanceof LanAccessHttpError) {
            writeJson(res, error.status, { ok: false, error: { code: error.code, message: error.message } })
            return
          }
          writeJson(res, 500, {
            ok: false,
            error: { code: 'internal', message: error instanceof Error ? error.message : String(error) },
          })
        })
      },
    }), 'dsh-lan-access: /lan-access route')

    // Tokenized handoff for a bind move. The client fetches this *before* the
    // toggle because the rebind cuts off the POST response: the new origin can
    // then present the process launch token (which is authority-independent)
    // and mint its own session cookie instead of retrying the dead origin.
    httpCtx.effect(() => httpCtx.webServer.register({
      kind: 'exact',
      path: '/lan-access/handoff',
      handler: (req, res) => {
        void handleHandoff(req, res).catch((error: unknown) => {
          writeJson(res, 500, {
            ok: false,
            error: { code: 'internal', message: error instanceof Error ? error.message : String(error) },
          })
        })
      },
    }), 'dsh-lan-access: /lan-access/handoff route')

    // The settings/credentials RPC proxy (mirrors the loopback-pinned /api
    // configuration plane for LAN-served pages; same fence, same envelopes).
    httpCtx.effect(() => httpCtx.webServer.register({
      kind: 'exact',
      path: '/lan-access/rpc',
      handler: (req, res) => {
        void handleRpc(ctx, loader, req, res, (method, ok, code, ns, namespaces) => logRpc(method, ok, code, ns, namespaces)).catch((error: unknown) => {
          writeJson(res, 500, {
            ok: false,
            error: { code: 'internal', message: error instanceof Error ? error.message : String(error) },
          })
        })
      },
    }), 'dsh-lan-access: /lan-access/rpc route')

    // Client boot diagnostics: browsers POST their ledger state after boot;
    // GET reads the last reports (debug aid for LAN settings issues).
    httpCtx.effect(() => httpCtx.webServer.register({
      kind: 'exact',
      path: '/lan-access/diag',
      handler: (req, res) => {
        void (async () => {
          if (!isTrustedApiRequest(req, trustedHostsOf(loader), (ctx.get('webServer') as LanAccessWebServer | undefined)?.host)) {
            writeJson(res, 403, { ok: false, error: { code: 'forbidden', message: 'request origin is not trusted' } })
            return
          }
          if (req.method === 'POST') {
            const body = await readJsonBody(req)
            diagReports.push({ at: Date.now(), data: body })
            if (diagReports.length > 20) diagReports.shift()
            writeJson(res, 200, { ok: true })
            return
          }
          writeJson(res, 200, { ok: true, value: { reports: diagReports, traffic: rpcTraffic } })
        })().catch((error: unknown) => {
          writeJson(res, 500, {
            ok: false,
            error: { code: 'internal', message: error instanceof Error ? error.message : String(error) },
          })
        })
      },
    }), 'dsh-lan-access: /lan-access/diag route')
    align()
  })

  /**
   * Mint the authenticated URL the page should navigate to after a bind move.
   * Only the loopback page may ask: it is the machine that can reach the new
   * concrete address, and the process launch token must not leak to a remote
   * LAN browser.
   */
  async function handleHandoff(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const server = serverOf()
    if (!isTrustedApiRequest(req, trustedHostsOf(loader), server?.host)) {
      writeJson(res, 403, { ok: false, error: { code: 'forbidden', message: 'request origin is not trusted' } })
      return
    }
    if (req.method !== 'GET') {
      writeJson(res, 405, { ok: false, error: { code: 'method-error', message: 'method not allowed' } })
      return
    }
    const hostHeader = header(req.headers, 'host')
    const hostUrl = hostHeader === undefined ? undefined : parseAuthority(hostHeader)
    if (hostUrl === undefined || !isLoopbackHostname(hostUrl.hostname)) {
      writeJson(res, 403, { ok: false, error: { code: 'forbidden', message: 'handoff is only available to the loopback page' } })
      return
    }
    const url = new URL(req.url ?? '/', 'http://dsh.internal')
    const target = url.searchParams.get('host')
    if (target === null) {
      writeJson(res, 400, { ok: false, error: { code: 'bad-request', message: 'expected ?host=<local IP>' } })
      return
    }
    let selected: string
    try {
      selected = selectAddress(target)
    } catch (error) {
      writeJson(res, 400, { ok: false, error: { code: 'bad-request', message: error instanceof Error ? error.message : String(error) } })
      return
    }
    if (server === undefined || server.port === undefined) {
      writeJson(res, 503, { ok: false, error: { code: 'not-ready', message: 'webserver is not ready' } })
      return
    }
    const connection = ctx.get('connection') as LanAccessHostConnection | undefined
    if (connection === undefined) {
      writeJson(res, 503, { ok: false, error: { code: 'unavailable', message: 'connection service is absent' } })
      return
    }
    const baseUrl = listenerUrl(selected, server.port, server.protocol === 'https:')
    writeJson(res, 200, { ok: true, value: { url: connection.authenticatedUrl(baseUrl) } })
  }

  /** One /lan-access request: GET reads state, POST persists and applies. */
  async function handle(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const url = new URL(req.url ?? '/', 'http://dsh.internal')
    if (url.pathname !== '/lan-access') {
      writeJson(res, 404, { ok: false, error: { code: 'not-found', message: 'not found' } })
      return
    }
    if (!isTrustedApiRequest(req, trustedHostsOf(loader), (ctx.get('webServer') as LanAccessWebServer | undefined)?.host)) {
      writeJson(res, 403, { ok: false, error: { code: 'forbidden', message: 'request origin is not trusted' } })
      return
    }
    if (req.method === 'GET') {
      writeJson(res, 200, { ok: true, value: await stateOf() })
      return
    }
    if (req.method === 'POST') {
      const payload = await readJsonBody(req)
      if (payload === null || typeof payload !== 'object' || typeof (payload as { enabled?: unknown }).enabled !== 'boolean') {
        throw new LanAccessHttpError('bad-request', 'expected {"enabled": boolean}')
      }
      const enabled = (payload as { enabled: boolean }).enabled
      const bindHost = 'bindHost' in payload ? payload.bindHost : currentBindHost
      if (bindHost !== undefined && typeof bindHost !== 'string') {
        throw new LanAccessHttpError('bad-request', 'bindHost must be a concrete local IP address')
      }
      if (enabled) {
        try { selectAddress(bindHost ?? '') } catch (error) {
          throw new LanAccessHttpError('bad-request', error instanceof Error ? error.message : String(error))
        }
      }
      await enqueueApply(enabled, bindHost, true)
      writeJson(res, 200, { ok: true, value: await stateOf() })
      return
    }
    writeJson(res, 405, { ok: false, error: { code: 'method-error', message: 'method not allowed' } })
  }
}
