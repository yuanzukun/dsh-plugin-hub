/** Concrete interface addresses accepted by the LAN bind controller. */
import { execFileSync } from 'node:child_process'
import { isIP } from 'node:net'
import { networkInterfaces } from 'node:os'

/** Normalize an IP literal for comparison; scoped addresses cannot form browser URLs. */
function normalize(address: string): string | undefined {
  if (address.includes('%') || isIP(address) === 0) return undefined
  const host = isIP(address) === 6 ? `[${address}]` : address
  return new URL(`http://${host}`).hostname
}

/** IPv4 link-local (APIPA) addresses never carry a routable LAN endpoint. */
function isIpv4LinkLocal(address: string): boolean {
  return /^169\.254\./.test(address)
}

/**
 * Parse `ifconfig` (BSD/macOS) or `ip -o addr show` (Linux) output for IPv6
 * privacy/deprecated literals. Both spell the flags `temporary` and
 * `deprecated`; BSD adds `prefixlen`, Linux adds `/prefix`.
 * @param output - combined OS command output.
 * @returns lowercased address literals to hide from the selector.
 */
export function parseTemporaryAddresses(output: string): Set<string> {
  const addresses = new Set<string>()
  for (const line of output.split('\n')) {
    const match = /inet6\s+([0-9a-f:]+)(?:%\S+)?(?:\/\d+)?\s+(.*)$/i.exec(line)
    if (match !== null && /\b(?:temporary|deprecated)\b/i.test(match[2])) {
      addresses.add(match[1].toLowerCase())
    }
  }
  return addresses
}

/** How long an OS address-flag probe stays fresh. */
const TEMPORARY_TTL_MS = 30_000
let temporaryCache: { at: number; addresses: ReadonlySet<string> } | undefined

/**
 * OS-reported IPv6 privacy/deprecated addresses, cached. Node's
 * `networkInterfaces()` exposes no temporary flag, so macOS/Linux are asked
 * directly; anything unavailable falls back to the full list.
 * @param now - clock injection for tests.
 * @returns lowercased address literals to hide from the selector.
 */
export function temporaryAddresses(now = Date.now()): ReadonlySet<string> {
  if (temporaryCache !== undefined && now - temporaryCache.at < TEMPORARY_TTL_MS) {
    return temporaryCache.addresses
  }
  const addresses = new Set<string>()
  try {
    const linux = process.platform === 'linux'
    const output = execFileSync(linux ? 'ip' : 'ifconfig', linux ? ['-o', 'addr', 'show'] : [], {
      encoding: 'utf8', timeout: 1500, windowsHide: true,
    })
    for (const address of parseTemporaryAddresses(output)) addresses.add(address)
  } catch {
    /* ifconfig/ip unavailable: keep every address (the safe fallback) */
  }
  temporaryCache = { at: now, addresses }
  return addresses
}

/**
 * List selectable local IPv4 and IPv6 addresses: excludes loopback, wildcards,
 * scoped and link-local literals, and addresses the OS reports as temporary or
 * deprecated. IPv4 addresses sort first.
 * @param interfaces - OS interface snapshot.
 * @param excluded - lowercased address literals to omit (OS privacy flags).
 * @returns distinct concrete addresses suitable for browser URLs.
 */
export function availableAddresses(
  interfaces = networkInterfaces(),
  excluded: ReadonlySet<string> = new Set<string>(),
): string[] {
  const addresses = Object.values(interfaces).flatMap(entries => (entries ?? [])
    .filter(entry => !entry.internal && normalize(entry.address) !== undefined
      && !['0.0.0.0', '[::]', '[::ffff:0:0]'].includes(normalize(entry.address)!)
      && !entry.address.startsWith('127.')
      && normalize(entry.address) !== '[::1]'
      && !/^fe[89ab]/i.test(entry.address)
      && !isIpv4LinkLocal(entry.address)
      && !excluded.has(entry.address.toLowerCase()))
    .map(entry => entry.address))
  return [...new Set(addresses)]
    .sort((left, right) => Number(isIP(left) === 6) - Number(isIP(right) === 6))
}

/** Validate the operator's selected address against current interfaces.
 * @param host - selected IP literal.
 * @param addresses - currently selectable addresses.
 * @returns the matching OS address.
 */
export function selectAddress(host: string, addresses = availableAddresses()): string {
  const normalized = normalize(host)
  const selected = normalized === undefined ? undefined : addresses.find(address => normalize(address) === normalized)
  if (selected === undefined) {
    throw new Error(`LAN access: ${JSON.stringify(host)} is not a selectable local interface address; choose an address listed in Settings → General`)
  }
  return selected
}

/** Format the concrete listener URL, including IPv6 brackets.
 * @param host - concrete IP literal.
 * @param port - listener port.
 * @param tls - whether HTTPS is enabled.
 * @returns browser URL for this listener.
 */
export function listenerUrl(host: string, port: number, tls: boolean): string {
  return `${tls ? 'https' : 'http'}://${isIP(host) === 6 ? `[${host}]` : host}:${port}`
}
