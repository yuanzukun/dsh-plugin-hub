// Bundles the captain Web client half into the DSH `__ModuleLoader__` format.
//
// The DSH Web host loads every client bundle as a CommonJS module wrapped in
// `window.__ModuleLoader__.load({ id, factory: (require) => { ... } })`, where
// `require` resolves peer externals such as `react` and `react/jsx-runtime`.
// A plain `tsc` emit produces unbundled ESM (`import ... from ...`), which the
// browser module system cannot consume and which breaks the whole Web surface.
//
// This step therefore:
//   1. bundles src/client.ts (+ all local client modules) into one CommonJS
//      file with `react` / `react/jsx-runtime` left as `require(...)` externals,
//   2. wraps it in the required loader call, and
//   3. overwrites lib/client.js and removes the superseded ESM artifacts.
import { build } from 'esbuild'
import { rm, writeFile } from 'node:fs/promises'

const result = await build({
  entryPoints: ['src/client.ts'],
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  jsx: 'automatic',
  external: ['react', 'react/jsx-runtime'],
  write: false,
  minify: false,
  sourcemap: false,
  logLevel: 'info',
})

const code = result.outputFiles[0].text

const wrapped = [
  'window.__ModuleLoader__.load({ id: "captain-dsh-plugin", factory: (require) => {',
  'var module = { exports: {} };',
  'var exports = module.exports;',
  code,
  'return module.exports;',
  '} });',
  '',
].join('\n')

// Note: the per-module ESM outputs under lib/client/ stay in place. The pure
// ones (nodeCatalog, state) are loaded directly by node --test; the shipped
// browser entry is exclusively the bundled lib/client.js below.
await writeFile('lib/client.js', wrapped)
await rm('lib/client.js.map', { force: true })

console.log(`wrote lib/client.js (${wrapped.length} bytes, wrapped __ModuleLoader__ bundle)`)