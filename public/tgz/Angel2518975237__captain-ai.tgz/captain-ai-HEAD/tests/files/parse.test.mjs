import assert from 'node:assert/strict'
import { crc32 } from 'node:zlib'
import test from 'node:test'

import { detectKind, parseDocx, parseFile } from '../../lib/files/parse.js'

test('detectKind maps extensions and falls back to txt', () => {
  assert.equal(detectKind('resume.pdf'), 'pdf')
  assert.equal(detectKind('resume.docx'), 'docx')
  assert.equal(detectKind('notes.md'), 'md')
  assert.equal(detectKind('notes.markdown'), 'md')
  assert.equal(detectKind('notes.txt'), 'txt')
  assert.equal(detectKind('no-extension'), 'txt')
})

test('markdown and txt pass through verbatim', async () => {
  const md = '# 求职偏好\n- 远程'
  assert.equal(await parseFile('md', Buffer.from(md)), md)
  assert.equal(await parseFile('txt', Buffer.from('hello')), 'hello')
})

/** Build a minimal uncompressed (store) ZIP, just enough for mammoth to read. */
function zip(files) {
  const encoder = new TextEncoder()
  const chunks = []
  const central = []
  let offset = 0
  for (const { name, data } of files) {
    const nameBuf = encoder.encode(name)
    const crc = crc32(data)
    const local = Buffer.alloc(30)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)
    local.writeUInt16LE(0, 8) // store
    local.writeUInt32LE(crc, 14)
    local.writeUInt32LE(data.length, 18)
    local.writeUInt32LE(data.length, 22)
    local.writeUInt16LE(nameBuf.length, 26)
    chunks.push(local, nameBuf, data)

    const cd = Buffer.alloc(46)
    cd.writeUInt32LE(0x02014b50, 0)
    cd.writeUInt16LE(20, 4)
    cd.writeUInt16LE(20, 6)
    cd.writeUInt16LE(0, 10)
    cd.writeUInt32LE(crc, 16)
    cd.writeUInt32LE(data.length, 20)
    cd.writeUInt32LE(data.length, 24)
    cd.writeUInt16LE(nameBuf.length, 28)
    cd.writeUInt32LE(offset, 42)
    central.push(cd, nameBuf)

    offset += 30 + nameBuf.length + data.length
  }
  const cdSize = central.reduce((n, b) => n + b.length, 0)
  const eocd = Buffer.alloc(22)
  eocd.writeUInt32LE(0x06054b50, 0)
  eocd.writeUInt16LE(files.length, 8)
  eocd.writeUInt16LE(files.length, 10)
  eocd.writeUInt32LE(cdSize, 12)
  eocd.writeUInt32LE(offset, 16)
  return Buffer.concat([...chunks, ...central, eocd])
}

function minimalDocx(text) {
  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>${text}</w:t></w:r></w:p></w:body></w:document>`
  return zip([
    { name: '[Content_Types].xml', data: Buffer.from('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>') },
    { name: '_rels/.rels', data: Buffer.from('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>') },
    { name: 'word/document.xml', data: Buffer.from(documentXml) },
  ])
}

test('parseDocx extracts plain text from a minimal DOCX', async () => {
  const text = await parseDocx(minimalDocx('Hello Captain'))
  assert.match(text, /Hello Captain/)
})
