import assert from 'node:assert/strict'
import { Readable } from 'node:stream'
import test from 'node:test'

import { CaptainStore } from '../../lib/store/service.js'
import { ProfileOnboarding } from '../../lib/profile/onboarding.js'
import { CaptainGateway } from '../../lib/web/gateway.js'

const PROFILE = {
  targetRoles: ['AI 产品经理'], adjacentRoles: [], excludedRoles: [], locations: ['上海', '远程'],
  companyPreferences: ['AI 原生产品'], excludedCompaniesOrIndustries: ['纯销售岗'],
  desiredResponsibilities: ['从用户问题到产品闭环'], desiredDecisionRights: ['参与产品路线决策'],
  strengths: [{ capability: 'Agentic Workflow', evidence: '完成可恢复的公司筛查工作流' }],
  hardConstraints: ['不接受单休'], unknowns: ['最低薪资仍需确认'], privacyRestrictions: ['简历手机号不得发送到网络工具'],
}

function makeReq({ method = 'GET', url = '/api/captain/status', body } = {}) {
  const req = new Readable({ read() {} })
  req.method = method
  req.url = url
  if (body !== undefined) req.push(Buffer.from(body))
  req.push(null)
  return req
}

function makeRes() {
  const res = {
    statusCode: 200,
    headers: {},
    chunks: [],
    writeHead(status, headers) { this.statusCode = status; this.headers = headers ?? {} },
    end(chunk) { if (chunk) this.chunks.push(Buffer.from(chunk)) },
    body() { return Buffer.concat(this.chunks).toString('utf8') },
  }
  return res
}

function makeGateway() {
  const store = new CaptainStore()
  const onboarding = new ProfileOnboarding(store, 'workflow-v0.3')
  const gateway = new CaptainGateway(store, onboarding)
  const routes = []
  const webServer = { register: (route) => { routes.push(route); return () => {} } }
  gateway.register({ webServer })
  return { store, gateway, handler: routes[0].handler, routes }
}

async function call(handler, method, url, body) {
  const req = makeReq({ method, url, body })
  const res = makeRes()
  await handler(req, res)
  return { status: res.statusCode, json: JSON.parse(res.body()) }
}

test('gateway registers a prefix route under /api/captain', () => {
  const { routes } = makeGateway()
  assert.equal(routes.length, 1)
  assert.equal(routes[0].kind, 'prefix')
  assert.equal(routes[0].path, '/api/captain')
})

test('GET /status and /history start empty', async () => {
  const { handler } = makeGateway()
  const status = await call(handler, 'GET', '/api/captain/status')
  assert.equal(status.status, 200)
  assert.deepEqual(status.json, { profile: null, run: null })

  const history = await call(handler, 'GET', '/api/captain/history')
  assert.equal(history.status, 200)
  assert.deepEqual(history.json, { history: [] })
})

test('onboarding flow: begin -> draft -> confirm over the API', async () => {
  const { handler } = makeGateway()

  const began = await call(handler, 'POST', '/api/captain/onboarding/begin', JSON.stringify({ sessionId: 's1' }))
  assert.equal(began.status, 200)
  assert.equal(began.json.route, 'submit_profile')
  const runId = began.json.run.runId
  assert.equal(began.json.run.status, 'profile_missing')

  const drafted = await call(handler, 'POST', '/api/captain/profile/draft', JSON.stringify({
    runId, expectedVersion: began.json.run.checkpointVersion, profileId: 'angel', content: PROFILE,
  }))
  assert.equal(drafted.status, 200)
  assert.equal(drafted.json.route, 'confirm_profile')
  const { profile } = drafted.json

  const confirmed = await call(handler, 'POST', '/api/captain/profile/confirm', JSON.stringify({
    runId, expectedVersion: drafted.json.run.checkpointVersion, profileId: 'angel', profileVersion: profile.version,
  }))
  assert.equal(confirmed.status, 200)
  assert.equal(confirmed.json.route, 'submit_opportunity')

  const status = await call(handler, 'GET', '/api/captain/status')
  assert.equal(status.json.profile.status, 'confirmed')
  assert.equal(status.json.profile.contentHash, profile.contentHash)
})

test('applyExtractedDraft promotes a fresh run through P1→P2→P4/P5 and returns the live node', () => {
  const { store } = makeGateway()
  const onboarding = new ProfileOnboarding(store, 'workflow-v0.3')
  // No source for one field so gap triage keeps the draft editable (P4).
  const gappy = { ...PROFILE, locations: [] }
  const status = onboarding.applyExtractedDraft('sX', 'profile-sX', gappy)
  assert.equal(status.route, 'answer_gaps')
  assert.equal(status.run.status, 'awaiting_profile_input')
  assert.equal(status.run.currentNode, 'P4')
  assert.ok(status.gaps.some((gap) => gap.path === '$.locations'))

  // A complete draft advances straight to confirmation (P5).
  const complete = onboarding.applyExtractedDraft('sY', 'profile-sY', PROFILE)
  assert.equal(complete.route, 'confirm_profile')
  assert.equal(complete.run.status, 'awaiting_profile_confirmation')
  assert.equal(complete.run.currentNode, 'P5')
})

test('rejects unknown route, bad JSON and stale version with stable codes', async () => {
  const { handler } = makeGateway()

  const unknown = await call(handler, 'GET', '/api/captain/nope')
  assert.equal(unknown.status, 404)
  assert.equal(unknown.json.error.code, 'NOT_FOUND')

  const badJson = await call(handler, 'POST', '/api/captain/note', '{not json')
  assert.equal(badJson.status, 400)
  assert.equal(badJson.json.error.code, 'INVALID_JSON')

  const began = await call(handler, 'POST', '/api/captain/onboarding/begin', JSON.stringify({ sessionId: 's2' }))
  const stale = await call(handler, 'POST', '/api/captain/profile/draft', JSON.stringify({
    runId: began.json.run.runId, expectedVersion: 999, profileId: 'angel', content: PROFILE,
  }))
  assert.equal(stale.status, 409)
  assert.match(stale.json.error.code, /VERSION_CONFLICT/)
})

test('note round-trips through the API with version guard', async () => {
  const { store, handler } = makeGateway()
  const profile = store.confirmProfile('angel', store.saveProfileDraft('angel', PROFILE).version)
  const opportunityId = store.createOpportunity({ company: '某 AI 创业公司', role: '产品经理', profile, workflowVersion: 'workflow-v0.3' })

  const saved = await call(handler, 'POST', '/api/captain/note', JSON.stringify({
    opportunityId, text: '面试后确认产品决策权偏弱', interviewStage: '一面', expectedVersion: 0,
  }))
  assert.equal(saved.status, 200)
  assert.equal(saved.json.version, 1)

  const conflict = await call(handler, 'POST', '/api/captain/note', JSON.stringify({
    opportunityId, text: '并发覆盖', interviewStage: '一面', expectedVersion: 0,
  }))
  assert.equal(conflict.status, 409)

  const history = await call(handler, 'GET', '/api/captain/history')
  assert.equal(history.json.history[0].userNote, '面试后确认产品决策权偏弱')
})

test('source upload parses markdown and persists a private source', async () => {
  const { store, handler } = makeGateway()

  const uploaded = await call(handler, 'POST', '/api/captain/source', JSON.stringify({
    filename: 'prefs.md', contentBase64: Buffer.from('# 求职偏好\n- 远程').toString('base64'),
  }))
  assert.equal(uploaded.status, 201)
  assert.equal(uploaded.json.source.kind, 'md')
  assert.equal(uploaded.json.source.filename, 'prefs.md')
  assert.match(uploaded.json.source.text, /远程/)

  const [stored] = store.listSources()
  assert.equal(stored.contentHash, uploaded.json.source.contentHash)
  assert.equal(stored.text, '# 求职偏好\n- 远程')
})

const EVAL_SCORES = {
  personalization: 4, companyFactTrustworthiness: 3, recommendationReasoning: 4, unknownHonesty: 2, interviewQuestionSpecificity: 5,
}

test('human eval saves and lists with score validation', async () => {
  const { handler } = makeGateway()

  const saved = await call(handler, 'POST', '/api/captain/eval', JSON.stringify({
    caseName: '某 AI 创业公司产品经理岗位', profileVersion: 'angel-v1', workflowVersion: 'workflow-v0.3',
    scores: EVAL_SCORES, issues: ['融资只引用了搜索摘要'], strengths: ['问题有针对性'], conclusion: '有限通过',
  }))
  assert.equal(saved.status, 201)
  assert.equal(saved.json.eval.scores.unknownHonesty, 2)

  const listed = await call(handler, 'GET', '/api/captain/evals')
  assert.equal(listed.status, 200)
  assert.equal(listed.json.evals.length, 1)
  assert.equal(listed.json.evals[0].caseName, '某 AI 创业公司产品经理岗位')

  const bad = await call(handler, 'POST', '/api/captain/eval', JSON.stringify({
    caseName: 'x', profileVersion: 'v1', workflowVersion: 'v2', scores: { ...EVAL_SCORES, personalization: 9 }, issues: [], strengths: [], conclusion: 'x',
  }))
  assert.equal(bad.status, 400)
  assert.match(bad.json.error.code, /INVALID_SCORE/)
})

test('GET /profile/template streams a downloadable markdown template', async () => {
  const { handler } = makeGateway()
  const req = makeReq({ method: 'GET', url: '/api/captain/profile/template' })
  const res = makeRes()
  await handler(req, res)
  assert.equal(res.statusCode, 200)
  assert.match(res.headers['content-disposition'], /^attachment/)
  const body = res.body()
  assert.match(body, /Captain 求职决策 Profile 模板/)
  assert.match(body, /目标岗位/)
})

test('GET /node/:id returns the inspectable skill contract, unknown ids 404', async () => {
  const { handler } = makeGateway()

  const known = await call(handler, 'GET', '/api/captain/node/P1')
  assert.equal(known.status, 200)
  assert.equal(known.json.id, 'P1')
  assert.match(known.json.markdown, /# Role/)
  assert.match(known.json.markdown, /Guardrails/)

  const unknown = await call(handler, 'GET', '/api/captain/node/ZZZ')
  assert.equal(unknown.status, 404)
  assert.match(unknown.json.error.code, /NOT_FOUND/)
})

test('chat without a runtime LLM degrades to a clear 501', async () => {
  const { handler } = makeGateway()
  const res = await call(handler, 'POST', '/api/captain/chat', JSON.stringify({ messages: [{ role: 'user', content: '你好' }] }))
  assert.equal(res.status, 501)
  assert.equal(res.json.error.code, 'CHAT_UNAVAILABLE')
})

test('parseProfileJson tolerates a duplicated payload and markdown fences', async () => {
  const { parseProfileJson } = await import('../../lib/web/gateway.js')
  const obj = {
    targetRoles: ['AI 产品经理'], adjacentRoles: [], excludedRoles: [], locations: ['上海'], workMode: null,
    salaryMinimum: null, salaryExpected: '25K', salaryBasis: null, companyPreferences: [],
    excludedCompaniesOrIndustries: [], desiredResponsibilities: [], desiredDecisionRights: [],
    strengths: [], decisionPriorities: [], hardConstraints: [], unknowns: [], privacyRestrictions: [],
  }
  const doubled = JSON.stringify(obj) + JSON.stringify(obj)
  // bare doubled payload
  const bare = parseProfileJson(doubled)
  assert.ok(bare)
  assert.deepEqual(bare.locations, ['上海'])
  assert.equal(bare.salaryExpected, '25K')
  // wrapped in a markdown fence
  const fenced = parseProfileJson('```json\n' + doubled + '\n```')
  assert.ok(fenced)
  assert.deepEqual(fenced.targetRoles, ['AI 产品经理'])
  // prose preamble + duplicated payload
  const prose = parseProfileJson('好的，这是抽取结果：\n' + doubled + '\n希望有帮助。')
  assert.ok(prose)
  assert.deepEqual(prose.locations, ['上海'])
  // no object at all -> undefined
  assert.equal(parseProfileJson('没有找到任何有效信息。'), undefined)
})
