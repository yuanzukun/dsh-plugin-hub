import assert from 'node:assert/strict'
import test from 'node:test'

import { createResearchPlan, validateResearchPlan } from '../lib/research/planner.js'
import { reviewEvidence } from '../lib/evidence/review.js'
import { validateReportClaims } from '../lib/report/validator.js'

test('research planner creates a bounded dependency-valid plan', () => {
  const plan = createResearchPlan({ company: '某 AI 创业公司', role: '产品经理' })
  validateResearchPlan(plan)
  assert.equal(plan.maxWorkers, 4)
  assert.equal(plan.targetedResearchLimit, 1)
  assert.ok(plan.tasks.every((task) => task.question.length > 0))
})

test('Evidence Reviewer is independent and rejects search snippets', () => {
  const draft = { evidenceId: 'e1', authorAgentId: 'worker-1', company: '某 AI 创业公司', claim: '完成 A 轮融资', sourceUrl: 'https://example.com/result', sourceKind: 'search_snippet', locator: '搜索摘要', accessedAt: new Date().toISOString() }
  assert.throws(() => reviewEvidence(draft, 'worker-1'), /SELF_REVIEW_FORBIDDEN/)
  const review = reviewEvidence(draft, 'reviewer-1')
  assert.equal(review.status, 'rejected')
  assert.match(review.reasons[0], /搜索摘要/)
})

test('unknown salary cannot be phrased as a match', () => {
  const result = validateReportClaims([{ claimId: 'salary-1', topic: 'salary', statement: '薪资基本符合预期', confidence: 'unknown', evidenceIds: [], profileItemIds: ['salary-min'] }], new Set())
  assert.equal(result.valid, false)
  assert.ok(result.failures.some((failure) => failure.code === 'UNKNOWN_AS_MATCH'))
})
