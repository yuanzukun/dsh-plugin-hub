import assert from 'node:assert/strict'
import test from 'node:test'

import { createResearchPlan } from '../../lib/research/planner.js'
import { ResearchOrchestrator } from '../../lib/research/orchestrator.js'

function fakeSubagents({ failTaskIds = new Set() } = {}) {
  const calls = []
  const runtime = {
    async start(provider, request) {
      const taskId = String(request.label).replace('captain-research:', '')
      calls.push({ provider, taskId, request })
      if (failTaskIds.has(taskId)) throw new Error('WORKER_BOOT_FAILED')
      return { result: { output: [{ type: 'text', text: 'done' }], structured: { claims: [{ statement: 'x', sourceUrl: 'https://x' }] }, stopReason: 'done' } }
    },
  }
  return { runtime, calls }
}

test('fanOut runs the plan DAG in dependency order with bounded concurrency', async () => {
  const { runtime, calls } = fakeSubagents()
  const orchestrator = new ResearchOrchestrator(runtime, 'spawn')
  const plan = createResearchPlan({ company: 'Acme', role: '产品经理' })

  const outcomes = await orchestrator.fanOut(plan, { id: 'parent' }, new AbortController().signal)

  assert.equal(outcomes.length, 4)
  assert.ok(outcomes.every((o) => o.status === 'ok'))

  // company-identity (depth 0) must be scheduled before every other task.
  const ids = calls.map((c) => c.taskId)
  assert.equal(ids[0], 'company-identity')
  assert.deepEqual(new Set(ids.slice(1)), new Set(['business-health', 'role-reality', 'employment-risk']))

  // Every worker is scoped to web_search/web_read and carries the evidence schema.
  for (const call of calls) {
    assert.equal(call.provider, 'spawn')
    assert.deepEqual(call.request.toolFilter, { allow: ['web_search', 'web_read'] })
    assert.equal(call.request.outputSchema.type, 'object')
    assert.deepEqual(call.request.prompt[0], { type: 'text', text: call.request.prompt[0].text })
  }
})

test('a failed dependency marks dependents as DEPENDENCY_FAILED without cancelling siblings', async () => {
  const { runtime } = fakeSubagents({ failTaskIds: new Set(['company-identity']) })
  const orchestrator = new ResearchOrchestrator(runtime, 'spawn')
  const plan = createResearchPlan({ company: 'Acme', role: '产品经理' })

  const outcomes = await orchestrator.fanOut(plan, { id: 'parent' }, new AbortController().signal)
  const byId = new Map(outcomes.map((o) => [o.taskId, o]))

  assert.equal(byId.get('company-identity').status, 'failed')
  assert.equal(byId.get('company-identity').error, 'WORKER_BOOT_FAILED')
  // All three dependents of company-identity are skipped (not spawned).
  for (const id of ['business-health', 'role-reality', 'employment-risk']) {
    assert.equal(byId.get(id).status, 'failed')
    assert.equal(byId.get(id).error, 'DEPENDENCY_FAILED')
  }
})

test('an already-aborted signal short-circuits all workers', async () => {
  const { runtime, calls } = fakeSubagents()
  const orchestrator = new ResearchOrchestrator(runtime, 'spawn')
  const plan = createResearchPlan({ company: 'Acme', role: '产品经理' })
  const controller = new AbortController()
  controller.abort()

  const outcomes = await orchestrator.fanOut(plan, { id: 'parent' }, controller.signal)
  assert.equal(calls.length, 0)
  assert.ok(outcomes.every((o) => o.status === 'failed' && o.error === 'CANCELLED'))
})
