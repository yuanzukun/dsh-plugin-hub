import assert from 'node:assert/strict'
import test from 'node:test'

import { buildHistoryXlsx } from '../../lib/export/xlsx.js'

test('buildHistoryXlsx emits a valid zip with escaped and defused cells', () => {
  const rows = [{
    opportunityId: 'o1', company: '某 AI 创业公司', role: '产品经理', screenedAt: '2026-09-06T00:00:00.000Z',
    profileVersion: 'angel-v1', workflowVersion: 'v0.3', verdict: '有限通过', userNote: '=cmd() 与 <script>alert(1)</script>',
  }]
  const buffer = buildHistoryXlsx(rows)

  // ZIP local file header magic.
  assert.equal(buffer.readUInt32LE(0), 0x04034b50)
  // End-of-central-directory magic present.
  assert.ok(buffer.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06])) > 0)

  const text = buffer.toString('utf8')
  assert.match(text, /公司/)
  assert.match(text, /某 AI 创业公司/)
  assert.match(text, /有限通过/)
  // Formula injection defused: leading '='
  assert.match(text, /'=cmd\(\)/)
  // XML special characters escaped.
  assert.match(text, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/)
})

test('buildHistoryXlsx handles an empty history (header only)', () => {
  const buffer = buildHistoryXlsx([])
  assert.equal(buffer.readUInt32LE(0), 0x04034b50)
  assert.match(buffer.toString('utf8'), /我的备注/)
})
