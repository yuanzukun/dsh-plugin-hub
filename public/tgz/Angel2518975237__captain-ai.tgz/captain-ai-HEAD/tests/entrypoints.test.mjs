import assert from 'node:assert/strict'
import test from 'node:test'

test('exports stable Host and bundled Client plugin identities', async () => {
  const host = await import('../lib/index.js')

  assert.equal(host.name, 'captain')
  assert.equal(typeof host.apply, 'function')

  // The Client half ships for the browser module system: a CommonJS module
  // wrapped in window.__ModuleLoader__.load({ id, factory }). Load it with a
  // stubbed loader and assert the fire-factory exposes the plugin contract.
  let registration
  const originalWindow = globalThis.window
  globalThis.window = { __ModuleLoader__: { load: (reg) => { registration = reg } } }
  try {
    await import('../lib/client.js')
  } finally {
    globalThis.window = originalWindow
  }

  assert.ok(registration, 'client registers via window.__ModuleLoader__.load')
  assert.equal(registration.id, 'captain-dsh-plugin')
  assert.equal(typeof registration.factory, 'function')

  const reactStub = { useSyncExternalStore: () => null, useMemo: () => null, useState: (v) => [v, () => {}], createElement: () => null }
  const jsxRuntimeStub = { jsx: () => null, jsxs: () => null, Fragment: Symbol('frag') }
  const client = registration.factory((id) => {
    if (id === 'react') return reactStub
    if (id === 'react/jsx-runtime') return jsxRuntimeStub
    throw new Error(`unexpected external require: ${id}`)
  })

  assert.equal(client.name, 'captain-client')
  assert.equal(typeof client.apply, 'function')
  assert.deepEqual(client.inject, ['slots'])
})

test('ships all 18 inspectable workflow nodes', async () => {
  const { CAPTAIN_NODES } = await import('../lib/client/nodeCatalog.js')
  assert.equal(CAPTAIN_NODES.length, 18)
  assert.deepEqual(
    CAPTAIN_NODES.map((node) => node.id),
    ['C0', 'P1', 'P2', 'P3', 'P4', 'P5', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10', 'E1', 'E2'],
  )
})

test('Captain UI controller opens, navigates and closes deterministically', async () => {
  const { captainUiState } = await import('../lib/client/state.js')
  captainUiState.open('console')
  assert.equal(captainUiState.getSnapshot().open, true)
  captainUiState.navigate('history')
  assert.equal(captainUiState.getSnapshot().view, 'history')
  captainUiState.close()
  assert.equal(captainUiState.getSnapshot().open, false)
})
