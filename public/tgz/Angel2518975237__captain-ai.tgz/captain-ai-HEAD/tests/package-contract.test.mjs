import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

const root = new URL('../', import.meta.url)

test('declares additive DSH Host and Client package seams', async () => {
  const pkg = JSON.parse(await readFile(new URL('package.json', root), 'utf8'))
  const patch = await readFile(new URL('cordis.patch.yml', root), 'utf8')

  assert.equal(pkg.dsh.client.platform, 'web')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(pkg.exports['./client'], './lib/client.js')
  assert.match(patch, /id: captain/)
  assert.match(patch, /name: captain-dsh-plugin/)
})

test('client registers only additive sidebar and overlay seats', async () => {
  const source = await readFile(new URL('src/client.ts', root), 'utf8')
  assert.match(source, /sidebar\.footer\.action/)
  assert.match(source, /shell\.overlay/)
  assert.doesNotMatch(source, /name: ['"]root['"]/)
  assert.doesNotMatch(source, /name: ['"]sidebar['"]/)
  assert.doesNotMatch(source, /name: ['"]conversation['"]/)
})
