import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { main } from '../../lib/cli/main.js'

const dir = mkdtempSync(join(tmpdir(), 'captain-cli-'))

test('--help prints usage and returns 0', async () => {
  assert.equal(await main(['--help']), 0)
})

test('profile template writes the template file', async () => {
  const out = join(dir, 'profile.md')
  assert.equal(await main(['profile', 'template', out]), 0)
  assert.match(readFileSync(out, 'utf8'), /Profile|求职|模板|岗位|城市/)
})

test('profile import parses a markdown source', async () => {
  process.env.CAPTAIN_STORE_PATH = ':memory:'
  const file = join(dir, 'prefs.md')
  writeFileSync(file, '# 求职偏好\n- 远程 上海\n')
  assert.equal(await main(['profile', 'import', file]), 0)
})

test('history export writes an xlsx (empty store)', async () => {
  process.env.CAPTAIN_STORE_PATH = ':memory:'
  const out = join(dir, 'history.xlsx')
  assert.equal(await main(['history', 'export', out]), 0)
  const buffer = readFileSync(out)
  assert.equal(buffer.readUInt32LE(0), 0x04034b50) // PK magic
})

test('run inspect reports RUN_NOT_FOUND for a missing run', async () => {
  process.env.CAPTAIN_STORE_PATH = ':memory:'
  assert.equal(await main(['run', 'inspect', 'nope']), 1)
})

test('unknown command returns 2', async () => {
  assert.equal(await main(['bogus']), 2)
})
