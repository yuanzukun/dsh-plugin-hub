import assert from 'node:assert/strict'
import test from 'node:test'

import { CaptainStore } from '../lib/store/service.js'
import { canTransition } from '../lib/runtime/state-machine.js'
import { ProfileOnboarding } from '../lib/profile/onboarding.js'

const PROFILE = {
  targetRoles: ['AI 产品经理'], adjacentRoles: [], excludedRoles: [], locations: ['上海', '远程'],
  companyPreferences: ['AI 原生产品'], excludedCompaniesOrIndustries: ['纯销售岗'],
  desiredResponsibilities: ['从用户问题到产品闭环'], desiredDecisionRights: ['参与产品路线决策'],
  strengths: [{ capability: 'Agentic Workflow', evidence: '完成可恢复的公司筛查工作流' }],
  hardConstraints: ['不接受单休'], unknowns: ['最低薪资仍需确认'], privacyRestrictions: ['简历手机号不得发送到网络工具'],
}

test('Profile requires explicit draft then confirmation and preserves versions', () => {
  const store = new CaptainStore()
  const draft = store.saveProfileDraft('angel', PROFILE)
  assert.equal(draft.status, 'draft')
  assert.equal(store.getConfirmedProfile(), undefined)
  const confirmed = store.confirmProfile('angel', draft.version)
  assert.equal(confirmed.status, 'confirmed')
  assert.equal(store.getConfirmedProfile()?.contentHash, draft.contentHash)
  assert.throws(() => store.confirmProfile('angel', draft.version), /PROFILE_NOT_DRAFT/)
  store.close()
})

test('workflow checkpoints reject stale writers', () => {
  const store = new CaptainStore()
  const run = store.createRun('session-1', 'workflow-v0.3')
  const routed = store.transitionRun(run.runId, 0, 'profile_missing', 'P1', { reason: 'no confirmed Profile' })
  assert.equal(routed.checkpointVersion, 1)
  assert.throws(() => store.transitionRun(run.runId, 0, 'profile_draft', 'P2'), /VERSION_CONFLICT/)
  assert.equal(canTransition('profile_missing', 'profile_draft'), true)
  assert.equal(canTransition('profile_missing', 'researching'), false)
  store.close()
})

test('history identity includes versions and note remains user-owned', () => {
  const store = new CaptainStore()
  const profile = store.confirmProfile('angel', store.saveProfileDraft('angel', PROFILE).version)
  const opportunityId = store.createOpportunity({ company: '某 AI 创业公司', role: '产品经理', profile, workflowVersion: 'workflow-v0.3', screenedAt: '2026-09-06T00:00:00.000Z' })
  const saved = store.saveUserNote(opportunityId, '面试后确认产品决策权偏弱', '一面', 0)
  assert.equal(saved.version, 1)
  assert.throws(() => store.saveUserNote(opportunityId, '并发覆盖', '一面', 0), /VERSION_CONFLICT/)
  const [row] = store.listHistory()
  assert.equal(row.profileVersion, 'angel-v1')
  assert.equal(row.workflowVersion, 'workflow-v0.3')
  assert.equal(row.userNote, '面试后确认产品决策权偏弱')
  assert.equal(row.interviewStage, '一面')
  store.close()
})

test('P1-P5 routes missing fields through dialogue before explicit confirmation', () => {
  const store = new CaptainStore()
  const onboarding = new ProfileOnboarding(store, 'workflow-v0.3')
  const started = onboarding.begin('session-profile')
  assert.equal(started.route, 'submit_profile')

  const incomplete = { ...PROFILE, targetRoles: [] }
  const withGaps = onboarding.submitDraft(started.run.runId, started.run.checkpointVersion, 'angel', incomplete)
  assert.equal(withGaps.route, 'answer_gaps')
  assert.ok(withGaps.gaps.some((gap) => gap.path === '$.targetRoles'))
  assert.throws(() => store.confirmProfile('angel', withGaps.profile.version), /PROFILE_GAPS_REMAIN/)

  const ready = onboarding.submitDraft(withGaps.run.runId, withGaps.run.checkpointVersion, 'angel', PROFILE)
  assert.equal(ready.route, 'confirm_profile')
  assert.equal(store.getConfirmedProfile(), undefined)

  const confirmed = onboarding.confirm(ready.run.runId, ready.run.checkpointVersion, 'angel', ready.profile.version)
  assert.equal(confirmed.route, 'submit_opportunity')
  assert.equal(confirmed.profile.status, 'confirmed')
  store.close()
})
