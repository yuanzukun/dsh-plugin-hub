import { useSyncExternalStore } from 'react'
import type { SidebarFooterActionOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client'

import { captainUiState } from './state.js'

function CompassIcon(): JSX.Element {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19">
      <circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <path d="m9 15 2-5 4-2-2 5-4 2Z" fill="currentColor" />
      <circle cx="12" cy="12" r="1" fill="var(--captain-sand)" />
    </svg>
  )
}

export function CaptainSidebarAction({ wide }: SidebarFooterActionOwnerProps): JSX.Element {
  const state = useSyncExternalStore(captainUiState.subscribe, captainUiState.getSnapshot)

  return (
    <button
      className={`captain-sidebar-action${state.open ? ' is-active' : ''}`}
      type="button"
      aria-label="打开 Captain 控制台"
      aria-pressed={state.open}
      title="Captain 控制台"
      onClick={() => (state.open ? captainUiState.close() : captainUiState.open())}
    >
      <span className="captain-sidebar-action__icon"><CompassIcon /></span>
      {wide ? <span>Captain 控制台</span> : null}
    </button>
  )
}
