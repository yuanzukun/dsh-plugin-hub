import { useState } from 'react'

import { saveHumanEval, type HumanEvalScores } from './api.js'

const DIMENSIONS: Array<{ key: keyof HumanEvalScores; label: string }> = [
  { key: 'personalization', label: '是否结合个人偏好' },
  { key: 'companyFactTrustworthiness', label: '公司事实是否可信' },
  { key: 'recommendationReasoning', label: '建议是否有充分理由' },
  { key: 'unknownHonesty', label: '未知项是否诚实' },
  { key: 'interviewQuestionSpecificity', label: '面试问题是否具体' },
]

const INITIAL: HumanEvalScores = {
  personalization: 3, companyFactTrustworthiness: 3, recommendationReasoning: 3, unknownHonesty: 3, interviewQuestionSpecificity: 3,
}

/** Human E1 eval form: five-dimension rubric plus findings and a verdict. */
export function EvalForm(): JSX.Element {
  const [caseName, setCaseName] = useState('')
  const [scores, setScores] = useState<HumanEvalScores>(INITIAL)
  const [issues, setIssues] = useState('')
  const [strengths, setStrengths] = useState('')
  const [conclusion, setConclusion] = useState('')
  const [state, setState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle')

  const submit = (): void => {
    setState('saving')
    const lines = (value: string) => value.split('\n').map((item) => item.trim()).filter(Boolean)
    saveHumanEval({
      caseName: caseName || '未命名案例', profileVersion: 'angel-v1', workflowVersion: 'workflow-v0.3',
      scores, issues: lines(issues), strengths: lines(strengths), conclusion: conclusion || '未填写结论',
    }).then(() => setState('saved')).catch(() => setState('error'))
  }

  return <section className="captain-eval" aria-label="评价本次报告">
    <h2>评价本次报告</h2>
    <label>案例<input value={caseName} onChange={(event) => setCaseName(event.target.value)} placeholder="例如：某 AI 创业公司产品经理" /></label>
    {DIMENSIONS.map((dimension) => (
      <label key={dimension.key}>{dimension.label}
        <input type="number" min={1} max={5} value={scores[dimension.key]} onChange={(event) => setScores((prev) => ({ ...prev, [dimension.key]: Number(event.target.value) }))} />
      </label>
    ))}
    <label>发现的问题（每行一条）<textarea value={issues} onChange={(event) => setIssues(event.target.value)} /></label>
    <label>亮点（每行一条）<textarea value={strengths} onChange={(event) => setStrengths(event.target.value)} /></label>
    <label>总体结论<input value={conclusion} onChange={(event) => setConclusion(event.target.value)} /></label>
    <button type="button" onClick={submit} disabled={state === 'saving'}>{state === 'saving' ? '保存中…' : state === 'saved' ? '已保存 ✓' : '提交评价'}</button>
    {state === 'error' ? <p>保存失败</p> : null}
  </section>
}
