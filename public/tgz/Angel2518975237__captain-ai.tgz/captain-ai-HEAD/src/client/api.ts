/** Typed fetch client for the allowlisted `/api/captain/*` Web gateway. */

export interface CaptainHistoryRow {
  opportunityId: string
  company: string
  role: string
  screenedAt: string
  profileVersion: string
  workflowVersion: string
  verdict?: string
  decision?: string
  interviewStage?: string
  userNote: string
  noteUpdatedAt?: string
}

export interface CaptainRunState {
  status: string
  currentNode: string
  updatedAt: string
}

export interface CaptainStatus {
  profile: unknown
  run?: CaptainRunState | null
}

interface ErrorEnvelope {
  error?: { code?: string; message?: string }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init)
  const body = (await res.json().catch(() => ({}))) as T & ErrorEnvelope
  if (!res.ok) {
    throw new Error(body.error?.message ?? `HTTP ${res.status}`)
  }
  return body as T
}

export function fetchCaptainHistory(): Promise<{ history: CaptainHistoryRow[] }> {
  return request('/api/captain/history')
}

export function fetchCaptainStatus(): Promise<CaptainStatus> {
  return request('/api/captain/status')
}

export function saveCaptainNote(input: {
  opportunityId: string
  text: string
  interviewStage?: string
  expectedVersion?: number
}): Promise<{ version: number; updatedAt: string }> {
  return request('/api/captain/note', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  })
}

/** Trigger a browser download of the Excel history export. */
export function downloadCaptainHistoryXlsx(): void {
  const anchor = document.createElement('a')
  anchor.href = '/api/captain/export.xlsx'
  anchor.download = 'captain-history.xlsx'
  document.body.append(anchor)
  anchor.click()
  anchor.remove()
}

export interface HumanEvalScores {
  personalization: number
  companyFactTrustworthiness: number
  recommendationReasoning: number
  unknownHonesty: number
  interviewQuestionSpecificity: number
}

export function saveHumanEval(input: {
  caseName: string
  profileVersion: string
  workflowVersion: string
  scores: HumanEvalScores
  issues: string[]
  strengths: string[]
  conclusion: string
}): Promise<{ eval: unknown }> {
  return request('/api/captain/eval', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  })
}

export interface CaptainSource {
  sourceId: string
  kind: string
  filename: string
  byteSize: number
  text: string
  createdAt: string
}

/** Upload a local file for Agent-parsing; the host parses PDF/DOCX/MD/TXT. */
export function uploadCaptainSource(input: { filename: string; contentBase64: string }): Promise<{ source: CaptainSource }> {
  return request('/api/captain/source', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  })
}

/** A `ProfileContent` field: capability + supporting evidence. */
export interface CaptainStrength { capability: string; evidence: string }
/** Structured ProfileContent the host extracts from an uploaded source. */
export interface CaptainProfileContent {
  targetRoles: string[]
  adjacentRoles: string[]
  excludedRoles: string[]
  locations: string[]
  workMode?: string
  salaryMinimum?: string
  salaryExpected?: string
  salaryBasis?: string
  companyPreferences: string[]
  excludedCompaniesOrIndustries: string[]
  desiredResponsibilities: string[]
  desiredDecisionRights: string[]
  strengths: CaptainStrength[]
  decisionPriorities?: string[]
  hardConstraints: string[]
  unknowns: string[]
  privacyRestrictions: string[]
}
export interface CaptainGap { path: string; code: string; message: string; critical: boolean }
export type CaptainProfileRoute = 'submit_profile' | 'submit_opportunity' | 'answer_gaps' | 'confirm_profile'

/** Extract the FULL source into structured Profile fields (no truncation). */
export function extractCaptainProfile(input: { text: string; sessionId?: string; profileId?: string }): Promise<{ content: CaptainProfileContent; gaps: CaptainGap[]; run?: CaptainRunState | null; route?: CaptainProfileRoute }> {
  return request('/api/captain/profile/extract', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  })
}

/** Trigger a browser download of the standard Profile template. */
export function downloadCaptainProfileTemplate(): void {
  const anchor = document.createElement('a')
  anchor.href = '/api/captain/profile/template'
  anchor.download = 'captain-profile-template.md'
  document.body.append(anchor)
  anchor.click()
  anchor.remove()
}

export interface CaptainChatMessage {
  role: 'user' | 'assistant'
  content: string
  /** Optional durable image attachment carried by a user message. */
  image?: CaptainImageRef | null
}

export interface CaptainImageRef {
  attachmentId: string
  mediaType: string
  bytes: number
  width: number
  height: number
  name?: string
}

/** Upload a pasted/dropped image; the host stores it and returns a durable ref. */
export function uploadCaptainAttachment(input: { mediaType: string; data: string; name?: string }): Promise<{ attachment: CaptainImageRef }> {
  return request('/api/captain/attachment', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  })
}

/** One model turn inside the Captain overlay, using the current default DSH model. */
export function sendCaptainChat(input: { messages: CaptainChatMessage[] }): Promise<{ reply: string }> {
  // Serialize to the gateway's wire format: `content` is a string for plain
  // text, or a block array when the user message carries a pasted image.
  const messages = input.messages.map((message) => {
    if (!message.image) return { role: message.role, content: message.content }
    return {
      role: message.role,
      content: [
        ...(message.content ? [{ type: 'text', text: message.content }] : []),
        { type: 'image', attachment: message.image },
      ],
    }
  })
  return request('/api/captain/chat', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ messages }),
  })
}

/** Fetch the inspectable prompt contract for one Workflow node. */
export function fetchCaptainNodeDoc(id: string): Promise<{ id: string; markdown: string }> {
  return request(`/api/captain/node/${encodeURIComponent(id)}`)
}
