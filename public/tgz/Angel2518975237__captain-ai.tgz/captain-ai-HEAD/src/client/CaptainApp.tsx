import { useEffect, useRef, useState, useSyncExternalStore } from 'react'

import {
  downloadCaptainHistoryXlsx, downloadCaptainProfileTemplate, extractCaptainProfile, fetchCaptainHistory, fetchCaptainNodeDoc,
  fetchCaptainStatus, saveCaptainNote, sendCaptainChat, uploadCaptainAttachment, uploadCaptainSource,
  type CaptainChatMessage, type CaptainHistoryRow, type CaptainImageRef, type CaptainProfileContent, type CaptainSource,
} from './api.js'
import { EvalForm } from './EvalForm.js'
import { CaptainMarkdown } from './markdown.js'
import { CAPTAIN_NODES, type CaptainNodeMeta } from './nodeCatalog.js'
import type { CaptainUiController } from './state.js'
import { captainUiState } from './state.js'

interface CaptainAppProps {
  ui: CaptainUiController
}

function CloseIcon(): JSX.Element {
  return <svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20"><path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
}

function BrandMark(): JSX.Element {
  return <div className="captain-brand-mark" aria-hidden="true"><span>✦</span></div>
}

/** Default avatar for any crew member (current user). */
function CrewAvatar(): JSX.Element {
  return (
    <div className="captain-crew-avatar" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="20" height="20">
        <circle cx="12" cy="9" r="3.4" fill="currentColor" opacity=".92" />
        <path d="M5 18.6c0-2.6 3.1-4.4 7-4.4s7 1.8 7 4.4c0 .5-.4.9-.9.9H5.9c-.5 0-.9-.4-.9-.9Z" fill="currentColor" opacity=".92" />
      </svg>
      <span>船员</span>
    </div>
  )
}

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      const result = reader.result
      if (typeof result !== 'string') return reject(new Error('无法读取该文件'))
      const raw = result.split(',')[1]
      resolve(raw ?? '')
    }
    reader.onerror = () => reject(new Error('文件读取失败'))
    reader.readAsDataURL(file)
  })
}

/**
 * Render the fully-extracted `ProfileContent` as a compact markdown summary so
 * every dimension (意向城市 / 期望薪资 / 核心优势 / 决策优先级 / 底线条件 …)
 * surfaces in the console, not just the source's opening lines.
 */
function renderProfileSummary(content: CaptainProfileContent): string {
  const list = (items: string[] | undefined): string => {
    if (!items || items.length === 0) return '（未提供）'
    return items.map((item) => `- ${item}`).join('\n')
  }
  const strengths = content.strengths.length > 0
    ? content.strengths.map((s) => `- ${s.capability}${s.evidence && s.evidence !== '未提供证据' ? ` —— ${s.evidence}` : ''}`).join('\n')
    : '（未提供）'
  const sections = [
    `**目标岗位**\n${list(content.targetRoles)}`,
    `**可接受相近岗位**\n${list(content.adjacentRoles)}`,
    `**意向城市**\n${list(content.locations)}`,
    content.salaryMinimum || content.salaryExpected || content.salaryBasis
      ? `**薪资**\n${[content.salaryMinimum && `最低：${content.salaryMinimum}`, content.salaryExpected && `期望：${content.salaryExpected}`, content.salaryBasis && `口径：${content.salaryBasis}`].filter(Boolean).join('；')}`
      : `**薪资**\n（未提供）`,
    `**核心优势**\n${strengths}`,
    `**决策优先级 / 关键取舍**\n${list(content.decisionPriorities)}`,
    `**底线条件 / 硬性排除**\n${list(content.hardConstraints)}`,
    `**期待职责**\n${list(content.desiredResponsibilities)}`,
    `**期望决策权**\n${list(content.desiredDecisionRights)}`,
    `**公司偏好**\n${list(content.companyPreferences)}`,
    `**排除的行业 / 公司**\n${list(content.excludedCompaniesOrIndustries)}`,
    `**暂不确定**\n${list(content.unknowns)}`,
  ]
  return sections.join('\n\n')
}

// ---- live voyage rail -----------------------------------------------------

const PHASES: Array<{ key: string; label: string; nodes: string[] }> = [
  { key: 'entry', label: '入口', nodes: ['C0'] },
  { key: 'profile', label: '上船 · Profile', nodes: ['P1', 'P2', 'P3', 'P4', 'P5'] },
  { key: 'screen', label: '调查海域 · 筛查', nodes: ['S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10'] },
  { key: 'eval', label: '生成判断 · 评测', nodes: ['E1', 'E2'] },
]

function nodeOrder(id: string): number {
  const idx = CAPTAIN_NODES.findIndex((n) => n.id === id)
  return idx >= 0 ? idx : 999
}

/** A rich node card: id, kind, title, purpose, composition. Highlighted when
 *  it is the run's current node; marked done when already behind it. */
function VoyageNodeCard({ meta, state, onSelect }: { meta: CaptainNodeMeta; state: 'done' | 'active' | 'pending'; onSelect: () => void }): JSX.Element {
  return (
    <button className={`captain-voyage-node${state === 'active' ? ' is-active' : ''}${state === 'done' ? ' is-done' : ''}`} type="button" onClick={onSelect}>
      <span className="captain-voyage-node__top">
        <span className="captain-voyage-node__id">{meta.id}</span>
        <span className="captain-voyage-node__kind">{meta.kind}</span>
        {state === 'active' ? <span className="captain-voyage-node__live">当前</span> : state === 'done' ? <span className="captain-voyage-node__done">✓</span> : null}
      </span>
      <strong className="captain-voyage-node__title">{meta.title}</strong>
      <span className="captain-voyage-node__purpose">{meta.purpose}</span>
      {state === 'active' ? <span className="captain-voyage-node__composed">{meta.composedOf}</span> : null}
    </button>
  )
}

function VoyageRail({ currentNode, status }: { currentNode?: string; status?: string }): JSX.Element {
  const [selectedId, setSelectedId] = useState<string>(currentNode ?? 'P1')
  const currentIdx = currentNode ? nodeOrder(currentNode) : -1
  const effective = selectedId

  return (
    <aside className="captain-voyage" aria-label="实时航程节点">
      <header className="captain-voyage__head">
        <span>航程节点</span>
        <small className={currentNode ? 'is-live' : ''}>{currentNode ? '实时跟随中' : '待命'}</small>
      </header>
      <div className="captain-voyage__status">
        <span className={`captain-voyage__status-dot${currentNode ? ' is-active' : ''}`} />
        <strong>{currentNode ?? '尚未开始'}</strong>
        <small>{status ?? '等待任务启动'}</small>
      </div>
      <ol className="captain-voyage__list">
        {PHASES.map((phase) => {
          const phaseActive = phase.nodes.includes(currentNode ?? '')
          return (
            <li key={phase.key} className={phaseActive ? 'is-active' : ''}>
              <span className="captain-voyage__phase-label">{phase.label}</span>
              <div className="captain-voyage__nodes">
                {phase.nodes.map((id) => {
                  const meta = CAPTAIN_NODES.find((n) => n.id === id)
                  if (!meta) return null
                  const idx = nodeOrder(id)
                  const state: 'done' | 'active' | 'pending' = currentIdx >= 0 && idx < currentIdx ? 'done' : id === currentNode ? 'active' : 'pending'
                  return <VoyageNodeCard key={id} meta={meta} state={state} onSelect={() => setSelectedId(id)} />
                })}
              </div>
            </li>
          )
        })}
      </ol>
      <VoyageNodeContract id={effective} isActive={effective === currentNode} />
      <footer className="captain-voyage__foot">
        <span>目标</span><strong>生成一份可执行的判断</strong>
      </footer>
    </aside>
  )
}

/** Fetch and show the selected node's design contract (skill prompt). */
function VoyageNodeContract({ id, isActive }: { id: string; isActive: boolean }): JSX.Element | null {
  const [doc, setDoc] = useState<{ id: string; markdown: string } | null>(null)
  const [state, setState] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle')
  const [open, setOpen] = useState(isActive)

  useEffect(() => {
    if (!open) return
    let cancelled = false
    setState('loading')
    fetchCaptainNodeDoc(id)
      .then((result) => { if (!cancelled) { setDoc(result); setState('ready') } })
      .catch(() => { if (!cancelled) { setDoc(null); setState('error') } })
    return () => { cancelled = true }
  }, [id, open])

  const sections = state === 'ready' && doc ? splitSkillSections(doc.markdown) : null
  const meta = CAPTAIN_NODES.find((n) => n.id === id)

  if (!meta) return null
  return (
    <section className={`captain-voyage-contract${open ? ' is-open' : ''}`}>
      <button className="captain-voyage-contract__toggle" type="button" onClick={() => setOpen((v) => !v)}>
        <span><strong>{id}</strong><small>{open ? '收起设计契约' : '查看设计契约（提示词）'}</small></span>
        <span>{open ? '−' : '+'}</span>
      </button>
      {open ? <div className="captain-voyage-contract__body">
        {state === 'loading' ? <p className="captain-privacy">正在读取节点设计契约…</p>
          : state === 'error' ? <p className="captain-privacy">未能读取该节点的设计契约。</p>
          : sections ? sections.map((section) => (
            CAPTAIN_SKILL_SECTIONS.includes(section.title)
              ? <details open key={section.title} className="captain-voyage-contract__section"><summary>{section.title}</summary><pre>{section.body.trim()}</pre></details>
              : null
          ))
          : <p className="captain-privacy">该节点暂无公开内容。</p>}
      </div> : null}
    </section>
  )
}

const CAPTAIN_SKILL_SECTIONS = ['Role', 'Entry conditions', 'Instructions', 'Guardrails', 'Exit']

function splitSkillSections(markdown: string): Array<{ title: string; body: string }> | null {
  const lines = markdown.split('\n')
  const blocks: Array<{ title: string; body: string }> = []
  let current: { title: string; body: string } | null = null
  for (const line of lines) {
    const match = /^#\s+(.+)$/.exec(line)
    if (match) {
      current = { title: match[1].trim(), body: '' }
      blocks.push(current)
    } else if (current) {
      current.body += (current.body ? '\n' : '') + line
    }
  }
  return blocks.length > 0 ? blocks : null
}

function ChatBubble({ message }: { message: CaptainChatMessage }): JSX.Element {
  const isAgent = message.role === 'assistant'
  return (
    <div className={`captain-message ${isAgent ? 'captain-message--agent' : 'captain-message--user'}`}>
      {isAgent ? <BrandMark /> : <CrewAvatar />}
      <div>
        <strong>{isAgent ? 'Captain' : '船员'}</strong>
        <div className="captain-message__body">
          {isAgent ? <CaptainMarkdown>{message.content}</CaptainMarkdown> : <>
            {message.image ? <img className="captain-message__image" src={`/api/captain/image/${encodeURIComponent(message.image.attachmentId)}`} alt="已粘贴的图片" /> : null}
            {message.content ? <p>{message.content}</p> : null}
          </>}
        </div>
      </div>
    </div>
  )
}

function usePollRun(): void {
  useEffect(() => {
    let cancelled = false
    const load = () => {
      fetchCaptainStatus()
        .then((status) => { if (!cancelled) captainUiState.setRun(status.run ?? null) })
        .catch(() => { /* keep last known run */ })
    }
    load()
    const timer = setInterval(load, 3500)
    return () => { cancelled = true; clearInterval(timer) }
  }, [])
}

function ConsoleView(): JSX.Element {
  const messages = useSyncExternalStore(captainUiState.subscribe, captainUiState.getMessages)
  const run = useSyncExternalStore(captainUiState.subscribe, captainUiState.getSnapshot).run
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [uploadState, setUploadState] = useState<'idle' | 'uploading' | 'done'>('idle')
  const [uploaded, setUploaded] = useState<CaptainSource | null>(null)
  const [pendingImage, setPendingImage] = useState<CaptainImageRef | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const threadRef = useRef<HTMLDivElement>(null)

  usePollRun()

  const WELCOME = '欢迎上船。你可以直接上传简历、求职偏好或已有的个人档案，我来解析代填；也可以下载标准模板，填好后再交给我。或在下方直接输入，我来回答。'
  useEffect(() => {
    if (captainUiState.getMessages().length === 0) {
      captainUiState.replaceMessages([{ role: 'assistant', content: WELCOME }])
    }
  }, [])

  useEffect(() => {
    const node = threadRef.current
    if (node) node.scrollTop = node.scrollHeight
  }, [messages, busy])

  const append = (message: CaptainChatMessage) => captainUiState.setMessages((prev) => [...prev, message])

  // Engagement = the conversation has moved past the single opening greeting
  // (any user message, any reply, or a parsed upload). Once engaged, the hero
  // intro collapses so the dialog fully owns the column instead of floating
  // above it and shrinking the chat.
  const engaged = messages.length > 1

  const handlePickFile = () => fileInputRef.current?.click()

  const handleFileSelected = async (file: File | null) => {
    if (!file) return
    setUploadState('uploading')
    setNotice(`正在解析「${file.name}」…`)
    try {
      const contentBase64 = await readFileAsBase64(file)
      const { source } = await uploadCaptainSource({ filename: file.name, contentBase64 })
      setUploaded(source)
      setNotice('正在结构化抽取全部字段（意向城市 / 薪资 / 优势 / 底线…）')
      const { content, run } = await extractCaptainProfile({ text: source.text, sessionId: 'captain-console', profileId: 'profile-captain-console' })
      if (run) captainUiState.setRun(run)
      setUploadState('done')
      const summary = renderProfileSummary(content)
      append({ role: 'assistant', content: `已收到「${source.filename}」（${source.kind}，约 ${(source.byteSize / 1024).toFixed(1)} KB）。完整抽取结果如下：\n\n${summary}` })
      setNotice('')
    } catch (err) {
      setUploadState('idle')
      setNotice(`上传解析失败：${err instanceof Error ? err.message : String(err)}`)
    }
  }

  const handleSend = async () => {
    const text = input.trim()
    const image = pendingImage
    if (busy || (text.length === 0 && !image)) return
    const next = [...captainUiState.getMessages(), { role: 'user' as const, content: text, image: image ?? null }]
    setInput('')
    setPendingImage(null)
    captainUiState.replaceMessages(next)
    setBusy(true)
    try {
      const { reply } = await sendCaptainChat({ messages: next })
      captainUiState.setMessages((prev) => [...prev, { role: 'assistant', content: reply }])
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      captainUiState.setMessages((prev) => [...prev, { role: 'assistant', content: `（对话暂不可用：${message}）` }])
    } finally {
      setBusy(false)
    }
  }

  /** Upload a pasted/dropped image to the durable attachment store and hold its ref. */
  const handlePastedImage = async (file: File) => {
    const data = await readFileAsBase64(file)
    const mediaType = file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/webp' || file.type === 'image/gif'
      ? file.type
      : 'image/png'
    setNotice('正在上传图片…')
    try {
      const { attachment } = await uploadCaptainAttachment({ mediaType, data, name: file.name })
      setPendingImage(attachment)
      setNotice('')
    } catch (err) {
      setNotice(`图片上传失败：${err instanceof Error ? err.message : String(err)}`)
    }
  }

  const handlePaste = (event: React.ClipboardEvent<HTMLInputElement>) => {
    const items = event.clipboardData?.items
    if (!items) return
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile()
        if (file) {
          event.preventDefault()
          void handlePastedImage(file)
          return
        }
      }
    }
  }

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    const files = event.dataTransfer?.files
    if (files && files.length > 0) {
      const first = files[0]
      if (first.type.startsWith('image/')) {
        event.preventDefault()
        void handlePastedImage(first)
      }
    }
  }

  const handleKeyDown = (event: { key: string; nativeEvent: { isComposing: boolean }; preventDefault: () => void }) => {
    if (event.key === 'Enter' && !event.nativeEvent.isComposing) {
      event.preventDefault()
      void handleSend()
    }
  }

  const handleDownloadTemplate = () => downloadCaptainProfileTemplate()

  return <main className="captain-main">
    {!engaged ? <header className="captain-hero">
      <div><span className="captain-kicker">B · 风暴值守</span><h1>先确认你要驶向哪里。</h1><p>我会读取你的求职偏好，缺什么只问关键问题；确认 Profile 后，再开始公司与岗位筛查。</p></div>
      <div className="captain-weather"><span>航行状态</span><strong>{uploaded ? '收到资料' : '等待 Profile'}</strong><small>检查点会自动保存</small></div>
    </header> : null}
    {!engaged ? <div className="captain-paths">
      <button type="button" onClick={handlePickFile} disabled={uploadState === 'uploading'}><span>01</span><strong>上传资料，由 Agent 解析</strong><small>支持简历、偏好文档与补充说明</small></button>
      <button type="button" onClick={handleDownloadTemplate}><span>02</span><strong>下载 Profile 标准模板</strong><small>自己填写，完成后重新上传</small></button>
    </div> : null}

    <section className="captain-chat-card">
      <div className="captain-thread" ref={threadRef} aria-live="polite">
        {messages.map((message, index) => <ChatBubble key={index} message={message} />)}
        {busy ? <div className="captain-message captain-message--agent"><BrandMark /><div><strong>Captain</strong><div className="captain-message__body"><p className="captain-typing">正在思考…</p></div></div></div> : null}
        {notice ? <p className="captain-notice">{notice}</p> : null}
      </div>

      <div className="captain-composer">
        <button type="button" aria-label="上传本地文件" title="上传本地文件" onClick={handlePickFile} disabled={uploadState === 'uploading'}>＋</button>
        <div className="captain-composer__input">
          {pendingImage ? <span className="captain-image-preview"><img src={`/api/captain/image/${encodeURIComponent(pendingImage.attachmentId)}`} alt="待发送图片" /><button type="button" aria-label="移除图片" onClick={() => setPendingImage(null)}>×</button></span> : null}
          <input aria-label="给 Captain 发消息" placeholder="给 Captain 发消息，或粘贴/拖拽一张图片…" value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={handleKeyDown} onPaste={handlePaste} disabled={busy} />
        </div>
        <button className="captain-send" type="button" aria-label="发送" onClick={() => void handleSend()} disabled={busy || (input.trim().length === 0 && !pendingImage)}>↑</button>
      </div>
      <p className="captain-privacy">资料默认仅保存在本机 Captain Store；粘贴的图片会交给 DSH 的 vision 模型识别后再回复。</p>
    </section>
    <input ref={fileInputRef} type="file" accept=".pdf,.docx,.md,.markdown,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/markdown,text/plain" hidden onChange={(event) => { void handleFileSelected(event.target.files?.[0] ?? null); event.target.value = '' }} />
  </main>
}

function HistoryView(): JSX.Element {
  const [history, setHistory] = useState<CaptainHistoryRow[]>([])
  const [phase, setPhase] = useState<'loading' | 'ready' | 'error'>('loading')
  const [error, setError] = useState('')
  const [showEval, setShowEval] = useState(false)

  useEffect(() => {
    let cancelled = false
    fetchCaptainHistory()
      .then(({ history: rows }) => { if (!cancelled) { setHistory(rows); setPhase('ready') } })
      .catch((err: unknown) => { if (!cancelled) { setError(err instanceof Error ? err.message : String(err)); setPhase('error') } })
    return () => { cancelled = true }
  }, [])

  const editNote = (opportunityId: string, text: string) => {
    setHistory((rows) => rows.map((row) => (row.opportunityId === opportunityId ? { ...row, userNote: text } : row)))
  }

  const persistNote = (row: CaptainHistoryRow) => {
    saveCaptainNote({ opportunityId: row.opportunityId, text: row.userNote }).catch((err: unknown) => {
      setError(err instanceof Error ? err.message : String(err))
    })
  }

  return <main className="captain-main captain-history">
    <header className="captain-hero"><div><span className="captain-kicker">航海日志</span><h1>历史航程</h1><p>一条航程 = 公司 × 岗位 × 筛查日期 × Profile 版本 × Workflow 版本。</p></div><div><button className="captain-export" type="button" onClick={() => setShowEval((v) => !v)}>评价本次报告</button> <button className="captain-export" type="button" onClick={() => downloadCaptainHistoryXlsx()}>导出 Excel</button></div></header>
    {phase === 'loading' ? <p className="captain-privacy">正在读取本机 Captain Store…</p>
      : phase === 'error' ? <p className="captain-privacy">读取失败：{error}</p>
      : history.length === 0 ? <p className="captain-privacy">还没有航程记录。先在「当前航程」创建一次筛查。</p>
      : <>
        <div className="captain-table-wrap"><table><thead><tr><th>公司 / 岗位</th><th>筛查日期</th><th>版本</th><th>结论</th><th>我的面试备注</th><th></th></tr></thead><tbody>
          {history.map((row) => (
            <tr key={row.opportunityId}>
              <td><strong>{row.company}</strong><small>{row.role}</small></td>
              <td>{row.screenedAt.slice(0, 10)}</td>
              <td><small>{row.profileVersion}</small><small>{row.workflowVersion}</small></td>
              <td><span className="captain-verdict">{row.verdict ?? '—'}</span></td>
              <td><textarea aria-label="我的面试备注" value={row.userNote} onChange={(event) => editNote(row.opportunityId, event.target.value)} onBlur={() => persistNote(row)} placeholder="记录真实面试体验、团队感受或后续判断…" /><small>自动保存在本机 Captain Store</small></td>
              <td><button type="button">打开</button></td>
            </tr>
          ))}
        </tbody></table></div>
        {error ? <p className="captain-privacy">保存失败：{error}</p> : null}
      </>}
    {showEval ? <EvalForm /> : null}
  </main>
}

export function CaptainApp({ ui }: CaptainAppProps): JSX.Element | null {
  const state = useSyncExternalStore(ui.subscribe, ui.getSnapshot)
  if (!state.open) return null

  return <div className="captain-shell" role="dialog" aria-modal="true" aria-label="Captain 控制台">
    <div className="captain-topbar">
      <div className="captain-brand"><BrandMark /><span><strong>Captain 控制台</strong><small>Career Navigation System</small></span></div>
      <blockquote>“It’s not just about living forever, the trick is living with yourself forever.”</blockquote>
      <button className="captain-close" type="button" onClick={() => ui.close()} aria-label="关闭 Captain 控制台"><CloseIcon /></button>
    </div>
    <div className="captain-workspace">
      <nav className="captain-nav" aria-label="Captain 导航">
        <button className={state.view === 'console' ? 'is-active' : ''} type="button" onClick={() => ui.navigate('console')}><span>⌁</span>当前航程</button>
        <button className={state.view === 'history' ? 'is-active' : ''} type="button" onClick={() => ui.navigate('history')}><span>≋</span>历史航程</button>
        <div className="captain-nav__bottom"><span>风暴值守</span><small>workflow-v0.3</small></div>
      </nav>
      {state.view === 'history' ? <HistoryView /> : <ConsoleView />}
      <VoyageRail currentNode={state.run?.currentNode} status={state.run?.status} />
    </div>
  </div>
}
