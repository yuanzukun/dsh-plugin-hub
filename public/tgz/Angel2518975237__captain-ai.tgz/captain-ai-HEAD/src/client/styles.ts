const STYLE_ID = 'captain-console-styles'

const CSS = String.raw`
:root {
  --captain-ink: #14203c;
  --captain-muted: #5d6b8d;
  --captain-blue: #3e6bd8;
  --captain-violet: #6f63d8;
  --captain-sea: #eaf4ff;
  --captain-mist: #f4f6ff;
  --captain-line: rgba(72, 96, 158, .16);
  --captain-sand: #f2c879;
  --captain-white: #fff;
  --captain-shadow: 0 30px 90px rgba(24, 42, 92, .28);
  --captain-serif: Georgia, 'Songti SC', 'Songti SC', serif;
  --captain-sans: Inter, ui-sans-serif, system-ui, -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif;
}

.captain-sidebar-action {
  appearance: none; border: 0; background: transparent; color: inherit; cursor: pointer;
  display: flex; align-items: center; gap: 10px; min-width: 38px; width: 100%; height: 38px;
  padding: 0 10px; border-radius: 10px; font: 500 13px/1 var(--captain-sans); white-space: nowrap;
  transition: background .16s ease, color .16s ease;
}
.captain-sidebar-action:hover, .captain-sidebar-action.is-active { color: #536bd6; background: rgba(91, 109, 218, .11); }
.captain-sidebar-action__icon { display: grid; place-items: center; width: 20px; flex: 0 0 20px; }

.captain-shell {
  pointer-events: auto; position: fixed; inset: 12px; z-index: 9000; overflow: hidden;
  color: var(--captain-ink); background:
    radial-gradient(circle at 12% 4%, rgba(96, 190, 240, .22), transparent 30%),
    radial-gradient(circle at 82% 0%, rgba(148, 122, 233, .18), transparent 34%),
    linear-gradient(158deg, #f2faff 0%, #eef1ff 54%, #f6f3ff 100%);
  border: 1px solid rgba(78, 100, 170, .26); border-radius: 22px;
  box-shadow: var(--captain-shadow); font-family: var(--captain-sans);
}
.captain-shell *, .captain-shell *::before, .captain-shell *::after { box-sizing: border-box; }
.captain-shell button, .captain-shell input, .captain-shell textarea { font: inherit; }
.captain-shell ::selection { background: rgba(93, 122, 218, .2); }

.captain-topbar { height: 74px; display: grid; grid-template-columns: 270px minmax(260px, 1fr) 50px; align-items: center; gap: 24px; padding: 0 20px 0 24px; background: rgba(255,255,255,.62); border-bottom: 1px solid var(--captain-line); backdrop-filter: blur(18px); }
.captain-brand { display: flex; align-items: center; gap: 12px; }
.captain-brand > span { display: grid; gap: 3px; }
.captain-brand strong { font: 700 15px/1.1 var(--captain-serif); letter-spacing: .01em; }
.captain-brand small { color: var(--captain-muted); font-size: 9px; letter-spacing: .13em; text-transform: uppercase; }
.captain-brand-mark { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 50% 50% 46% 54%; color: #fff; background: linear-gradient(145deg, #476fcd, #7a67da); box-shadow: inset 0 0 0 1px rgba(255,255,255,.35), 0 8px 18px rgba(76, 89, 183, .26); transform: rotate(-5deg); }
.captain-brand-mark span { color: var(--captain-sand); transform: rotate(5deg); }
.captain-topbar blockquote { justify-self: center; margin: 0; color: #6473a0; font: italic 12px/1.4 var(--captain-serif); letter-spacing: .01em; }
.captain-close { display: grid; place-items: center; width: 40px; height: 40px; border: 1px solid var(--captain-line); border-radius: 50%; color: #596789; background: rgba(255,255,255,.7); cursor: pointer; transition: all .16s ease; }
.captain-close:hover { color: #344b9f; border-color: rgba(67,111,202,.5); transform: rotate(90deg); }

.captain-workspace { display: grid; grid-template-columns: 172px minmax(480px, 1fr) 300px; height: calc(100% - 74px); }
.captain-nav { position: relative; display: flex; flex-direction: column; gap: 7px; padding: 24px 14px; border-right: 1px solid var(--captain-line); background: rgba(242,247,255,.58); }
.captain-nav button { display: flex; align-items: center; gap: 9px; padding: 11px 12px; border: 0; border-radius: 11px; color: #657398; background: transparent; cursor: pointer; text-align: left; transition: all .16s ease; }
.captain-nav button span { font-size: 18px; }
.captain-nav button:hover, .captain-nav button.is-active { color: #385ba8; background: rgba(255,255,255,.84); box-shadow: 0 4px 18px rgba(64,83,142,.08); }
.captain-nav button.is-active { box-shadow: inset 3px 0 0 var(--captain-blue), 0 4px 18px rgba(64,83,142,.1); }
.captain-nav__bottom { margin-top: auto; display: grid; gap: 4px; padding: 13px 10px; border-top: 1px solid var(--captain-line); color: #57668e; }
.captain-nav__bottom span { font: 700 12px var(--captain-serif); }
.captain-nav__bottom small { color: #8a94af; font-size: 10px; }

.captain-main { min-width: 0; overflow: auto; padding: 34px clamp(24px, 4vw, 60px) 52px; }
.captain-main::-webkit-scrollbar { width: 10px; }
.captain-main::-webkit-scrollbar-thumb { background: rgba(80, 105, 170, .22); border-radius: 8px; }
.captain-hero { display: flex; justify-content: space-between; gap: 30px; align-items: flex-start; max-width: 900px; margin: 0 auto 26px; }
.captain-kicker { color: #4f6bd8; font: 700 10px/1 var(--captain-serif); letter-spacing: .18em; text-transform: uppercase; }
.captain-hero h1 { margin: 10px 0 10px; color: #1c3567; font: 500 clamp(26px, 3vw, 40px)/1.12 var(--captain-serif); letter-spacing: -.02em; }
.captain-hero p { max-width: 660px; margin: 0; color: var(--captain-muted); font-size: 13px; line-height: 1.8; }
.captain-weather { flex: 0 0 140px; display: grid; gap: 5px; padding: 15px 16px; border: 1px solid rgba(84,114,196,.2); border-radius: 14px; background: rgba(255,255,255,.58); box-shadow: 0 10px 26px rgba(64,82,148,.06); }
.captain-weather span, .captain-weather small { color: #8490ad; font-size: 10px; }
.captain-weather strong { color: #4f6bd8; font-size: 13px; }

.captain-chat-card { max-width: 900px; margin: 0 auto; padding: 24px; border: 1px solid rgba(81,107,183,.18); border-radius: 20px; background: rgba(255,255,255,.78); box-shadow: 0 20px 48px rgba(46,65,122,.1); }

.captain-message { display: flex; gap: 13px; align-items: flex-start; }
.captain-message .captain-brand-mark { flex: 0 0 38px; }
.captain-message strong { font: 700 13px var(--captain-serif); }
.captain-message--user { flex-direction: row-reverse; }

/* default avatar for the user, labeled 【船员】 */
.captain-crew-avatar { flex: 0 0 38px; display: grid; place-items: center; align-content: center; gap: 1px; width: 38px; height: 38px; border-radius: 50%; color: #4f6bd8; background: linear-gradient(145deg, #e8efff, #e8e4ff); border: 1px solid rgba(255,255,255,.9); box-shadow: 0 6px 16px rgba(70,95,180,.16); font: 700 8px/1 var(--captain-serif); }
.captain-crew-avatar span { opacity: .85; }
.captain-message--user .captain-crew-avatar { background: linear-gradient(145deg, #57246b, #9a5bd8); color: #ffe9b0; }

.captain-message__body { margin-top: 7px; }
.captain-message--user > div { max-width: 78%; padding: 12px 15px; border-radius: 16px 4px 16px 16px; background: rgba(94,116,209,.1); }
.captain-message--agent > div { max-width: 86%; }
.captain-message--user strong { color: #5a4ea6; }
.captain-message--user p { margin: 0; color: #3c4870; font-size: 13px; line-height: 1.8; }
.captain-message--agent p { margin: 0; color: #4c5a7e; font-size: 13px; line-height: 1.8; }

/* rendered markdown inside agent bubbles */
.captain-message__body .captain-md-p { margin: 0 0 9px; }
.captain-message__body .captain-md-p:last-child { margin-bottom: 0; }
.captain-message__body .captain-md-heading { margin: 12px 0 6px; color: #1c3567; line-height: 1.4; }
.captain-message__body .captain-md-code { padding: 1px 5px; border-radius: 5px; color: #4f3ea8; background: rgba(110,92,204,.1); font: 12px/1.5 ui-monospace, 'SF Mono', Menlo, monospace; }
.captain-message__body .captain-md-pre { margin: 10px 0; padding: 12px 14px; overflow: auto; border-radius: 10px; background: #1d2747; color: #dfe6ff; }
.captain-message__body .captain-md-pre .captain-md-code { padding: 0; color: inherit; background: transparent; }
.captain-message__body .captain-md-list { margin: 8px 0; padding-left: 22px; color: #4c5a7e; font-size: 13px; line-height: 1.8; }
.captain-message__body .captain-md-quote { margin: 8px 0; padding: 6px 12px; border-left: 3px solid var(--captain-blue); color: #6a7490; font-style: italic; background: rgba(93,122,218,.06); border-radius: 0 8px 8px 0; }
.captain-message__body a { color: #3e6bd8; text-decoration: underline; text-underline-offset: 2px; }
.captain-message__body .captain-md-hr { margin: 12px 0; border: 0; border-top: 1px solid var(--captain-line); }
.captain-message__image { display: block; max-width: 260px; max-height: 220px; margin-bottom: 8px; border-radius: 12px; border: 1px solid rgba(255,255,255,.9); box-shadow: 0 8px 22px rgba(50,70,130,.16); object-fit: contain; background: #f2f5ff; }

.captain-thread { display: grid; gap: 16px; max-height: 58vh; overflow: auto; margin: 22px 0; padding: 4px 4px 4px 1px; scroll-behavior: smooth; }
.captain-thread::-webkit-scrollbar { width: 8px; }
.captain-thread::-webkit-scrollbar-thumb { background: rgba(80, 105, 170, .2); border-radius: 8px; }
.captain-typing { color: #8a94af !important; font-style: italic; }
.captain-notice { color: #7b87a5; font-size: 10px; margin: 0; }
.captain-paths { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 22px 0; }
.captain-paths button { position: relative; display: grid; gap: 5px; padding: 16px 16px 16px 49px; border: 1px solid rgba(83,111,190,.19); border-radius: 14px; color: var(--captain-ink); background: linear-gradient(135deg, rgba(239,247,255,.88), rgba(246,242,255,.78)); text-align: left; cursor: pointer; transition: all .16s ease; }
.captain-paths button:hover { border-color: rgba(83,111,190,.46); transform: translateY(-1px); box-shadow: 0 10px 26px rgba(65,82,150,.1); }
.captain-paths button:disabled { opacity: .6; cursor: not-allowed; transform: none; box-shadow: none; }
.captain-paths button > span { position: absolute; top: 17px; left: 15px; color: #6a79b2; font: 700 10px var(--captain-serif); }
.captain-paths strong { font-size: 12px; }
.captain-paths small { color: #7b87a5; font-size: 10px; }
.captain-composer { display: grid; grid-template-columns: 36px 1fr 38px; gap: 8px; align-items: center; padding: 8px; border: 1px solid rgba(79,104,176,.22); border-radius: 14px; background: #fff; box-shadow: 0 8px 26px rgba(54,73,135,.08); }
.captain-composer:focus-within { border-color: rgba(62,107,216,.5); box-shadow: 0 0 0 3px rgba(62,107,216,.1), 0 8px 26px rgba(54,73,135,.08); }
.captain-composer button { display: grid; place-items: center; height: 36px; border: 0; border-radius: 10px; color: #627197; background: #f1f4fc; cursor: pointer; transition: all .14s ease; }
.captain-composer button:disabled { opacity: .55; cursor: not-allowed; }
.captain-composer input { min-width: 0; border: 0; outline: 0; color: var(--captain-ink); background: transparent; font-size: 12px; }
.captain-composer__input { display: flex; flex-direction: column; gap: 6px; min-width: 0; }
.captain-image-preview { position: relative; align-self: flex-start; }
.captain-image-preview img { display: block; max-width: 150px; max-height: 96px; border-radius: 9px; border: 1px solid rgba(79,104,176,.22); object-fit: contain; background: #f2f5ff; }
.captain-image-preview button { position: absolute; top: -7px; right: -7px; width: 20px; height: 20px; border-radius: 50%; font-size: 12px; line-height: 1; color: #fff; background: #607096; box-shadow: 0 2px 6px rgba(40,60,110,.3); }
.captain-composer .captain-send { color: #fff; background: linear-gradient(145deg, var(--captain-blue), var(--captain-violet)); }
.captain-composer .captain-send:hover:not(:disabled) { box-shadow: 0 6px 16px rgba(73,99,198,.35); }
.captain-composer .captain-send:disabled { background: #c6cde0; }
.captain-privacy { margin: 9px 2px 0; color: #98a1b8; font-size: 9px; }

/* live voyage rail */
.captain-voyage { min-width: 0; overflow: auto; padding: 20px 18px; border-left: 1px solid var(--captain-line); background: rgba(247,249,255,.72); display: flex; flex-direction: column; gap: 18px; }
.captain-voyage__head { display: flex; align-items: baseline; justify-content: space-between; }
.captain-voyage__head span { font: 700 14px var(--captain-serif); color: #1c3567; }
.captain-voyage__head small { color: #8a95ae; font-size: 10px; }
.captain-voyage__head small.is-live { color: var(--captain-blue); }
.captain-voyage__status { display: grid; gap: 4px; padding: 13px 14px; border: 1px solid rgba(84,114,196,.2); border-radius: 14px; background: rgba(255,255,255,.62); box-shadow: 0 8px 22px rgba(64,82,148,.07); }
.captain-voyage__status-dot { width: 9px; height: 9px; border-radius: 50%; background: #c2cbdd; box-shadow: 0 0 0 0 rgba(62,107,216,.5); }
.captain-voyage__status-dot.is-active { background: var(--captain-blue); animation: captain-pulse 1.8s infinite; }
@keyframes captain-pulse { 0% { box-shadow: 0 0 0 0 rgba(62,107,216,.4); } 70% { box-shadow: 0 0 0 9px rgba(62,107,216,0); } 100% { box-shadow: 0 0 0 0 rgba(62,107,216,0); } }
.captain-voyage__status strong { color: #385ba8; font: 700 13px var(--captain-sans); }
.captain-voyage__status small { color: #8a94af; font-size: 10px; }
.captain-voyage__list { list-style: none; margin: 0; padding: 0; display: grid; gap: 14px; }
.captain-voyage__list > li { position: relative; display: grid; gap: 7px; padding-left: 16px; }
.captain-voyage__list > li::before { content: ''; position: absolute; left: 4px; top: 5px; bottom: -9px; width: 1px; background: var(--captain-line); }
.captain-voyage__list > li:last-child::before { display: none; }
.captain-voyage__list > li::before { background: var(--captain-line); }
.captain-voyage__phase-label { color: #8994af; font: 700 9px var(--captain-serif); letter-spacing: .09em; text-transform: uppercase; }
.captain-voyage__nodes { display: grid; gap: 7px; }

/* rich per-node card: id, kind, title, purpose, composition */
.captain-voyage-node { display: grid; gap: 4px; padding: 9px 11px; border: 1px solid var(--captain-line); border-radius: 11px; color: inherit; background: rgba(255,255,255,.62); text-align: left; cursor: pointer; transition: all .18s ease; }
.captain-voyage-node:hover { border-color: rgba(83,111,190,.42); box-shadow: 0 6px 16px rgba(64,82,148,.08); }
.captain-voyage-node__top { display: flex; align-items: center; gap: 6px; }
.captain-voyage-node__id { font: 700 10px var(--captain-serif); color: #48586f; letter-spacing: .02em; }
.captain-voyage-node__kind { padding: 1px 5px; border-radius: 5px; color: #7b87a5; background: rgba(93,122,218,.09); font: 700 7px var(--captain-sans); letter-spacing: .05em; }
.captain-voyage-node__live { margin-left: auto; padding: 1px 6px; border-radius: 99px; color: #fff; background: linear-gradient(145deg, var(--captain-blue), var(--captain-violet)); font: 700 8px var(--captain-serif); }
.captain-voyage-node__done { margin-left: auto; color: #37a06b; font: 700 10px var(--captain-sans); }
.captain-voyage-node__title { font: 700 11px var(--captain-sans); color: #1c3567; }
.captain-voyage-node__purpose { color: #6a7590; font-size: 10px; line-height: 1.5; }
.captain-voyage-node.is-done { border-color: rgba(55,160,107,.22); background: rgba(238,246,241,.72); }
.captain-voyage-node.is-done .captain-voyage-node__title { color: #3c5468; }
.captain-voyage-node.is-active { border-color: transparent; background: linear-gradient(145deg, rgba(62,107,216,.16), rgba(122,103,218,.14)); box-shadow: 0 8px 18px rgba(80,96,200,.18); }
.captain-voyage-node.is-active .captain-voyage-node__id { color: var(--captain-blue); }
.captain-voyage-node.is-active .captain-voyage-node__title { color: #2b47a0; }
.captain-voyage-node__composed { padding-top: 4px; color: #5a66a0; font-size: 9px; line-height: 1.6; border-top: 1px dashed rgba(84,114,196,.25); }

/* active node design contract (skill prompt) */
.captain-voyage-contract { display: grid; gap: 0; border: 1px solid rgba(84,114,196,.22); border-radius: 12px; background: rgba(255,255,255,.66); overflow: hidden; }
.captain-voyage-contract__toggle { display: flex; align-items: center; justify-content: space-between; gap: 10px; width: 100%; padding: 11px 12px; border: 0; color: var(--captain-ink); background: rgba(240,244,255,.78); cursor: pointer; text-align: left; }
.captain-voyage-contract__toggle > span:first-child { display: grid; gap: 3px; }
.captain-voyage-contract__toggle strong { font: 700 12px var(--captain-serif); color: #1c3567; }
.captain-voyage-contract__toggle small { color: #8a95ae; font-size: 9px; }
.captain-voyage-contract__toggle > span:last-child { color: #6a79b2; font-size: 15px; }
.captain-voyage-contract__body { max-height: 46vh; overflow: auto; padding: 9px 11px; display: grid; gap: 8px; }
.captain-voyage-contract__body::-webkit-scrollbar { width: 7px; }
.captain-voyage-contract__body::-webkit-scrollbar-thumb { background: rgba(80,105,170,.2); border-radius: 8px; }
.captain-voyage-contract__section { border-top: 1px solid var(--captain-line); padding-top: 7px; }
.captain-voyage-contract__section:first-child { border-top: 0; padding-top: 0; }
.captain-voyage-contract__section summary { color: #4f6bd8; font: 700 10px var(--captain-serif); cursor: pointer; }
.captain-voyage-contract__section pre { margin: 7px 0 0; white-space: pre-wrap; word-break: break-word; color: #4c5a7e; font: 11px/1.6 ui-monospace, 'SF Mono', Menlo, monospace; }
.captain-voyage__foot { margin-top: auto; display: grid; gap: 3px; padding: 14px; border-top: 1px solid var(--captain-line); color: #57668e; }
.captain-voyage__foot span { color: #8a94af; font-size: 9px; }
.captain-voyage__foot strong { font: 700 12px var(--captain-serif); }

.captain-export { padding: 10px 14px; border: 1px solid rgba(72,102,188,.25); border-radius: 10px; color: #425fae; background: rgba(255,255,255,.72); cursor: pointer; transition: all .14s ease; }
.captain-export:hover { box-shadow: 0 6px 18px rgba(64,83,142,.1); }
.captain-table-wrap { overflow: auto; max-width: 1050px; margin: 0 auto; border: 1px solid var(--captain-line); border-radius: 16px; background: rgba(255,255,255,.74); box-shadow: 0 15px 42px rgba(50,68,128,.09); }
.captain-table-wrap table { width: 100%; border-collapse: collapse; font-size: 11px; }
.captain-table-wrap th { padding: 13px 14px; color: #8993aa; background: rgba(238,243,255,.65); font-size: 9px; font-weight: 600; text-align: left; white-space: nowrap; }
.captain-table-wrap td { padding: 14px; border-top: 1px solid var(--captain-line); color: #586581; vertical-align: top; }
.captain-table-wrap td:first-child, .captain-table-wrap td:nth-child(3) { display: grid; gap: 5px; }
.captain-table-wrap td small { display: block; color: #8f99af; font-size: 9px; }
.captain-table-wrap textarea { width: 270px; min-height: 72px; resize: vertical; padding: 9px 10px; border: 1px solid rgba(82,109,187,.2); border-radius: 9px; outline: none; color: #445170; background: #fff; font-size: 10px; line-height: 1.5; }
.captain-table-wrap textarea:focus { border-color: #6d7fd1; box-shadow: 0 0 0 3px rgba(102,124,208,.1); }
.captain-table-wrap td > button { border: 0; color: #4b66ba; background: transparent; cursor: pointer; }
.captain-verdict { display: inline-flex; padding: 5px 8px; border-radius: 99px; color: #94671c; background: #fff2d8; white-space: nowrap; }

@media (max-width: 1100px) {
  .captain-workspace { grid-template-columns: 66px minmax(440px, 1fr) 270px; }
  .captain-nav button { justify-content: center; padding: 10px; font-size: 0; }
  .captain-nav__bottom { display: none; }
  .captain-topbar { grid-template-columns: 240px 1fr 50px; }
}
@media (max-width: 820px) {
  .captain-shell { inset: 0; border-radius: 0; }
  .captain-workspace { grid-template-columns: 54px minmax(0, 1fr); }
  .captain-voyage { display: none; }
  .captain-topbar { grid-template-columns: 1fr 44px; }
  .captain-topbar blockquote { display: none; }
  .captain-main { padding: 24px 18px 36px; }
  .captain-weather { display: none; }
  .captain-paths { grid-template-columns: 1fr; }
}
`

export function ensureCaptainStyles(): () => void {
  const existing = document.getElementById(STYLE_ID)
  if (existing) return () => undefined
  const style = document.createElement('style')
  style.id = STYLE_ID
  style.textContent = CSS
  document.head.append(style)
  return () => style.remove()
}
