export type NodeKind = 'ROUTER' | 'AGENT' | 'FUNCTION' | 'HUMAN' | 'ORCHESTRATOR' | 'EVAL'

export interface CaptainNodeMeta {
  id: string
  title: string
  kind: NodeKind
  purpose: string
  composedOf: string
  capability: string
  phase: '入口' | 'Profile' | '筛查' | '评测'
}

export const CAPTAIN_NODES: readonly CaptainNodeMeta[] = [
  { id: 'C0', title: '航向识别与恢复', kind: 'ROUTER', purpose: '识别用户意图并恢复未完成航程', composedOf: 'AGENT 意图识别 + FUNCTION 幂等检查 + STORE 检查点', capability: 'Agentic Workflow · Context Engineering', phase: '入口' },
  { id: 'P1', title: 'Profile 入口', kind: 'AGENT', purpose: '判断是否已有 confirmed Profile，提供上传或模板两条路径', composedOf: 'AGENT 引导 + TOOL 文件接收 + STORE Profile 状态', capability: 'Agent Skill · Human-in-the-loop', phase: 'Profile' },
  { id: 'P2', title: '资料解析与代填', kind: 'AGENT', purpose: '解析用户资料并生成带来源引用的 Profile Draft', composedOf: 'AGENT 结构化抽取 + TOOL 文件读取 + FUNCTION 来源绑定', capability: 'Tool Calling · Prompt Engineering', phase: 'Profile' },
  { id: 'P3', title: 'Schema 与缺口识别', kind: 'FUNCTION', purpose: '校验结构并区分关键缺失、冲突和可选缺失', composedOf: 'FUNCTION Schema 校验 + AGENT 语义冲突检查', capability: 'Guardrails · Evals', phase: 'Profile' },
  { id: 'P4', title: '关键问题补齐', kind: 'HUMAN', purpose: '用最少问题补齐会影响判断的字段', composedOf: 'AGENT 自适应提问 + HUMAN 回答 + CHECKPOINT 暂停', capability: 'Human-in-the-loop · Context Engineering', phase: 'Profile' },
  { id: 'P5', title: 'Profile 确认与版本化', kind: 'HUMAN', purpose: '展示完整 Draft，获得明确确认后生成不可变版本', composedOf: 'HUMAN 确认 + FUNCTION Diff/Hash + STORE Version', capability: 'Guardrails · Agentic Workflow', phase: 'Profile' },
  { id: 'S1', title: '机会录入', kind: 'AGENT', purpose: '解析公司、岗位、JD、链接与用户补充资料', composedOf: 'AGENT 抽取 + TOOL 文件/图片读取 + FUNCTION 指纹去重', capability: 'Multimodal Tool Calling · MCP', phase: '筛查' },
  { id: 'S2', title: '公司实体消歧', kind: 'HUMAN', purpose: '避免同名公司或品牌主体错配', composedOf: 'AGENT 候选生成 + FUNCTION 实体匹配 + HUMAN Gate', capability: 'Human-in-the-loop · Guardrails', phase: '筛查' },
  { id: 'S3', title: '证据记忆与时效检查', kind: 'FUNCTION', purpose: '复用仍有效的事实，标记过期与缺失项', composedOf: 'STORE Evidence + FUNCTION Freshness Policy', capability: 'Context Engineering · Evals', phase: '筛查' },
  { id: 'S4', title: '研究计划', kind: 'ORCHESTRATOR', purpose: '按岗位风险动态拆分研究 DAG、预算与依赖', composedOf: 'AGENT Planner + FUNCTION DAG/预算校验', capability: 'Multi-Agent Orchestration · Agentic Workflow', phase: '筛查' },
  { id: 'S5', title: '并行研究', kind: 'ORCHESTRATOR', purpose: '让最少数量的专职 Worker 并行获取原始证据', composedOf: 'ORCHESTRATOR + SUBAGENTS + WEB/MCP/CLI Tools', capability: 'Multi-Agent Orchestration · Tool Calling', phase: '筛查' },
  { id: 'S6', title: '独立证据复核', kind: 'AGENT', purpose: '复核实体、日期、原文定位与来源独立性', composedOf: 'AGENT Reviewer + FUNCTION 去重/冲突检查', capability: 'Evals · Guardrails', phase: '筛查' },
  { id: 'S7', title: '上下文清单', kind: 'FUNCTION', purpose: '选择本次判断真正允许进入上下文的 Profile 与证据', composedOf: 'FUNCTION Context Selector + STORE ContextManifest', capability: 'Prompt & Context Engineering', phase: '筛查' },
  { id: 'S8', title: '个性化判断与补研', kind: 'AGENT', purpose: '分析匹配、风险和未知，必要时只补研一次', composedOf: 'AGENT Fit Analyst + ROUTER Targeted Research', capability: 'Agentic Workflow · Context Engineering', phase: '筛查' },
  { id: 'S9', title: '报告合成', kind: 'AGENT', purpose: '生成逐项可追溯、诚实表达未知的条件式建议', composedOf: 'AGENT Synthesizer + FUNCTION Claim Validator', capability: 'Prompt Engineering · Guardrails', phase: '筛查' },
  { id: 'S10', title: '决策与反馈闭环', kind: 'HUMAN', purpose: '保存用户决定、面试阶段、备注和 Profile 修改建议', composedOf: 'HUMAN Decision + STORE Notes + FUNCTION Proposal', capability: 'Human-in-the-loop · Memory', phase: '筛查' },
  { id: 'E1', title: '人工 Eval', kind: 'EVAL', purpose: '用五维量表和理由记录人工评审', composedOf: 'HUMAN Rubric + STORE EvalCase', capability: 'Evals · Human-in-the-loop', phase: '评测' },
  { id: 'E2', title: 'Quality Receipt', kind: 'EVAL', purpose: '异步计算质量收据，发现回归但不阻塞用户拿报告', composedOf: 'FUNCTION 指标 + AGENT Judge + REGRESSION CLI', capability: 'Evals · Guardrails · CLI', phase: '评测' },
] as const
