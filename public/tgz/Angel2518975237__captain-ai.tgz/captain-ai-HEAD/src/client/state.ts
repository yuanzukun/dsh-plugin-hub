export type CaptainView = 'console' | 'history'

export interface CaptainImageRef {
  attachmentId: string
  mediaType: string
  bytes: number
  width: number
  height: number
  name?: string
}

export interface CaptainChatMessage {
  role: 'user' | 'assistant'
  content: string
  image?: CaptainImageRef | null
}

export interface CaptainRunSnapshot {
  status: string
  currentNode: string
  updatedAt: string
}

export interface CaptainUiSnapshot {
  open: boolean
  view: CaptainView
  revision: number
  /** Live workflow run state, polled from /api/captain/status for the voyage rail. */
  run: CaptainRunSnapshot | null
}

class CaptainUiState {
  private snapshot: CaptainUiSnapshot = { open: false, view: 'console', revision: 0, run: null }
  private readonly listeners = new Set<() => void>()

  /** The independent chat loop lives inside the overlay and persists across view switches. */
  private messages: CaptainChatMessage[] = []

  readonly getSnapshot = (): CaptainUiSnapshot => this.snapshot
  readonly subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  readonly getMessages = (): CaptainChatMessage[] => this.messages
  readonly setMessages = (update: (prev: CaptainChatMessage[]) => CaptainChatMessage[]): void => {
    this.messages = update(this.messages)
    this.publish({})
  }
  readonly replaceMessages = (next: CaptainChatMessage[]): void => {
    this.messages = next
    this.publish({})
  }

  readonly setRun = (run: CaptainRunSnapshot | null): void => this.publish({ run })

  open(view: CaptainView = 'console'): void {
    this.publish({ open: true, view })
  }

  close(): void {
    this.publish({ open: false })
  }

  navigate(view: CaptainView): void {
    this.publish({ open: true, view })
  }

  private publish(next: Partial<CaptainUiSnapshot>): void {
    this.snapshot = { ...this.snapshot, ...next, revision: this.snapshot.revision + 1 }
    for (const listener of this.listeners) listener()
  }
}

export const captainUiState = new CaptainUiState()
export type CaptainUiController = CaptainUiState
