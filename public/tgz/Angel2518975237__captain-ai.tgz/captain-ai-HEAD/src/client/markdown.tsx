import React from 'react'

/**
 * Minimal, dependency-free Markdown renderer for captain chat bubbles.
 *
 * The DSH client bundle externalizes only `react` / `react/jsx-runtime`, so a
 * third-party Markdown parser would be a new dependency and a build-time
 * burden. This tiny renderer covers the shapes the Captain assistant actually
 * emits (headings, bold/italic/inline code, fenced code, ordered/unordered
 * lists, links, blockquotes, horizontal rules) and renders them as React
 * elements — so the chat no longer shows raw `**md**` text.
 */

function inline(text: string, keyBase: string): React.ReactNode[] {
  const parts: Array<{ text: string; kind: 'text' | 'bold' | 'italic' | 'code' | 'link'; href?: string }> = []
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\([^)]+\))/g
  let last = 0
  let m: RegExpExecArray | null
  let i = 0
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push({ text: text.slice(last, m.index), kind: 'text' as const })
    const tok = m[1]
    if (tok.startsWith('**')) parts.push({ text: tok.slice(2, -2), kind: 'bold' })
    else if (tok.startsWith('*')) parts.push({ text: tok.slice(1, -1), kind: 'italic' })
    else if (tok.startsWith('`')) parts.push({ text: tok.slice(1, -1), kind: 'code' })
    else {
      const md = /^\[([^\]]+)\]\(([^)]+)\)/.exec(tok)
      if (md) parts.push({ text: md[1], kind: 'link', href: md[2] })
      else parts.push({ text: tok, kind: 'text' })
    }
    last = re.lastIndex
    i++
  }
  if (last < text.length) parts.push({ text: text.slice(last), kind: 'text' as const })

  return parts.map((part, idx) => {
    const key = `${keyBase}-${idx}`
    switch (part.kind) {
      case 'bold': return <strong key={key}>{part.text}</strong>
      case 'italic': return <em key={key}>{part.text}</em>
      case 'code': return <code className="captain-md-code" key={key}>{part.text}</code>
      case 'link': return <a key={key} href={part.href} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>{part.text}</a>
      default: return <React.Fragment key={key}>{part.text}</React.Fragment>
    }
  })
}

export function CaptainMarkdown({ children: source }: { children: string }): JSX.Element {
  const lines = source.split('\n')
  const nodes: React.ReactNode[] = []
  let paragraph: string[] = []
  let inCode = false
  let codeBuf: string[] = []
  let codeLang = ''
  let listType: 'ul' | 'ol' | null = null
  let listItems: string[] = []
  let key = 0

  const flushParagraph = () => {
    if (paragraph.length) {
      const text = paragraph.join(' ')
      nodes.push(<p className="captain-md-p" key={`${key++}`}>{inline(text, `p${key}`)}</p>)
      paragraph = []
    }
  }
  const flushList = () => {
    if (listType && listItems.length) {
      const Tag = listType === 'ol' ? 'ol' : 'ul'
      nodes.push(
        <Tag className="captain-md-list" key={`${key++}`}>
          {listItems.map((item, idx) => <li key={`${key}-${idx}`}>{inline(item, `li${key}-${idx}`)}</li>)}
        </Tag>,
      )
    }
    listType = null
    listItems = []
  }

  for (const raw of lines) {
    const line = raw

    if (inCode) {
      if (/^```/.test(line)) {
        inCode = false
        nodes.push(
          <pre className="captain-md-pre" key={`${key++}`}>
            <code className="captain-md-code">{codeBuf.join('\n')}</code>
          </pre>,
        )
        codeBuf = []
        codeLang = ''
      } else {
        codeBuf.push(line)
      }
      continue
    }

    if (/^```/.test(line)) {
      flushParagraph()
      flushList()
      inCode = true
      codeLang = line.replace(/^```\s*/, '').trim()
      codeBuf = []
      continue
    }

    const heading = /^(#{1,6})\s+(.*)$/.exec(line)
    if (heading) {
      flushParagraph()
      flushList()
      const level = heading[1].length
      const Tag = (`h${Math.min(level, 6)}`) as keyof JSX.IntrinsicElements
      nodes.push(<Tag className="captain-md-heading" key={`${key++}`}>{inline(heading[2], `h${key}`)}</Tag>)
      continue
    }

    if (/^\s*(---|\*\*\*|___)\s*$/.test(line)) {
      flushParagraph()
      flushList()
      nodes.push(<hr className="captain-md-hr" key={`${key++}`} />)
      continue
    }

    const blockquote = /^>\s?(.*)$/.exec(line)
    if (blockquote) {
      flushParagraph()
      flushList()
      nodes.push(<blockquote className="captain-md-quote" key={`${key++}`}>{inline(blockquote[1], `q${key}`)}</blockquote>)
      continue
    }

    const ol = /^\s*\d+\.\s+(.*)$/.exec(line)
    const ul = /^\s*[-*+]\s+(.*)$/.exec(line)
    if (ol || ul) {
      flushParagraph()
      const body = (ol ?? ul)![1]
      const kind = ol ? 'ol' : 'ul'
      if (listType && listType !== kind) flushList()
      if (!listType) listType = kind
      listItems.push(body)
      continue
    }

    if (/^\s*$/.test(line)) {
      flushParagraph()
      flushList()
      continue
    }

    // plain text → accumulate into current paragraph
    flushList()
    paragraph.push(line)
  }
  if (inCode) {
    nodes.push(<pre className="captain-md-pre" key={`${key++}`}><code className="captain-md-code">{codeBuf.join('\n')}</code></pre>)
  }
  flushList()
  flushParagraph()

  return <React.Fragment>{nodes}</React.Fragment>
}
