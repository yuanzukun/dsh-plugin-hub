import { createHash, randomUUID } from 'node:crypto'
import { mkdirSync, readFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

import type { FileSourceRecord, HistoryRow, HumanEvalRecord, HumanEvalScores, ProfileContent, ProfileRecord, SourceKind, WorkflowRunRecord, WorkflowStatus } from '../domain/models.js'
import { validateProfileContent } from '../domain/validation.js'
import { assertTransition } from '../runtime/state-machine.js'

const MIGRATIONS = ['001-initial.sql', '002-sources.sql', '003-evals.sql'].map((file) => readFileSync(new URL(`../../migrations/${file}`, import.meta.url), 'utf8'))

function now(): string { return new Date().toISOString() }
function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`
  if (value && typeof value === 'object') return `{${Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableJson(item)}`).join(',')}}`
  return JSON.stringify(value)
}
function contentHash(value: unknown): string { return createHash('sha256').update(stableJson(value)).digest('hex') }

type SqlRow = Record<string, string | number | null>

export class CaptainStore {
  private readonly db: DatabaseSync

  constructor(path = ':memory:') {
    if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true, mode: 0o700 })
    this.db = new DatabaseSync(path)
    for (const migration of MIGRATIONS) this.db.exec(migration)
  }

  close(): void { this.db.close() }

  saveProfileDraft(profileId: string, content: ProfileContent, schemaVersion = '1.0.0'): ProfileRecord {
    const structuralIssues = validateProfileContent(content).filter((issue) => issue.code === 'invalid')
    if (structuralIssues.length > 0) throw new Error(`INVALID_PROFILE: ${structuralIssues.map((item) => `${item.path} ${item.message}`).join('; ')}`)
    const versionRow = this.db.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM profiles WHERE profile_id = ?').get(profileId) as SqlRow
    const version = Number(versionRow.version) + 1
    const createdAt = now()
    const hash = contentHash(content)
    this.db.prepare(`INSERT INTO profiles
      (profile_id, version, status, schema_version, content_hash, content_json, created_at)
      VALUES (?, ?, 'draft', ?, ?, ?, ?)`)
      .run(profileId, version, schemaVersion, hash, stableJson(content), createdAt)
    return { profileId, version, status: 'draft', schemaVersion, contentHash: hash, content, createdAt }
  }

  confirmProfile(profileId: string, version: number): ProfileRecord {
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const row = this.db.prepare('SELECT * FROM profiles WHERE profile_id = ? AND version = ?').get(profileId, version) as SqlRow | undefined
      if (!row) throw new Error('PROFILE_NOT_FOUND')
      if (row.status !== 'draft') throw new Error(`PROFILE_NOT_DRAFT: ${String(row.status)}`)
      const content = JSON.parse(String(row.content_json)) as ProfileContent
      const blocking = validateProfileContent(content).filter((issue) => issue.critical)
      if (blocking.length > 0) throw new Error(`PROFILE_GAPS_REMAIN: ${blocking.map((item) => item.path).join(', ')}`)
      const confirmedAt = now()
      this.db.prepare("UPDATE profiles SET status = 'superseded' WHERE status = 'confirmed'").run()
      this.db.prepare("UPDATE profiles SET status = 'confirmed', confirmed_at = ? WHERE profile_id = ? AND version = ?").run(confirmedAt, profileId, version)
      this.db.exec('COMMIT')
      return this.profileFromRow({ ...row, status: 'confirmed', confirmed_at: confirmedAt })
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  getConfirmedProfile(): ProfileRecord | undefined {
    const row = this.db.prepare("SELECT * FROM profiles WHERE status = 'confirmed' LIMIT 1").get() as SqlRow | undefined
    return row ? this.profileFromRow(row) : undefined
  }

  createRun(sessionId: string, skillVersion: string, profile?: ProfileRecord): WorkflowRunRecord {
    const timestamp = now()
    const run: WorkflowRunRecord = {
      runId: randomUUID(), sessionId, status: profile ? 'profile_confirmed' : 'created', currentNode: 'C0',
      skillVersion, checkpointVersion: 0, targetedResearchCount: 0, createdAt: timestamp, updatedAt: timestamp,
      ...(profile ? { profileId: profile.profileId, profileVersion: profile.version } : {}),
    }
    this.db.prepare(`INSERT INTO workflow_runs
      (run_id, session_id, profile_id, profile_version, status, current_node, skill_version, checkpoint_version, targeted_research_count, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(run.runId, run.sessionId, run.profileId ?? null, run.profileVersion ?? null, run.status, run.currentNode, run.skillVersion, 0, 0, timestamp, timestamp)
    return run
  }

  transitionRun(runId: string, expectedVersion: number, status: WorkflowStatus, currentNode: string, payload: unknown = {}): WorkflowRunRecord {
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const row = this.db.prepare('SELECT * FROM workflow_runs WHERE run_id = ?').get(runId) as SqlRow | undefined
      if (!row) throw new Error('RUN_NOT_FOUND')
      if (Number(row.checkpoint_version) !== expectedVersion) throw new Error(`VERSION_CONFLICT: expected ${expectedVersion}, actual ${String(row.checkpoint_version)}`)
      assertTransition(String(row.status) as WorkflowStatus, status)
      const nextVersion = expectedVersion + 1
      const timestamp = now()
      this.db.prepare('UPDATE workflow_runs SET status = ?, current_node = ?, checkpoint_version = ?, updated_at = ? WHERE run_id = ?')
        .run(status, currentNode, nextVersion, timestamp, runId)
      this.db.prepare('INSERT INTO checkpoints (run_id, version, status, current_node, payload_json, created_at) VALUES (?, ?, ?, ?, ?, ?)')
        .run(runId, nextVersion, status, currentNode, stableJson(payload), timestamp)
      this.db.exec('COMMIT')
      return this.getRun(runId) as WorkflowRunRecord
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  getRun(runId: string): WorkflowRunRecord | undefined {
    const row = this.db.prepare('SELECT * FROM workflow_runs WHERE run_id = ?').get(runId) as SqlRow | undefined
    return row ? this.runFromRow(row) : undefined
  }

  /** The most recently updated workflow run (for the sidebar's live voyage rail). */
  getLatestRun(): WorkflowRunRecord | undefined {
    const row = this.db
      .prepare('SELECT * FROM workflow_runs ORDER BY updated_at DESC LIMIT 1')
      .get() as SqlRow | undefined
    return row ? this.runFromRow(row) : undefined
  }

  /**
   * Bridge the latest run into the screening/research phase for a real task
   * (company × role). Walks only legal transitions from wherever the run sits
   * and returns the final run record; an unavailable hop is a silent no-op so
   * research still runs even when the run hasn't reached that stage yet. The
   * sidebar follows the returned `currentNode` through its `/status` poll.
   */
  startResearch(sessionId: string, company: string, role: string): WorkflowRunRecord {
    let run = this.getLatestRun() ?? this.createRun(sessionId, 'workflow-v0.3', this.getConfirmedProfile())
    const tryStep = (status: WorkflowStatus, node: string): void => {
      try {
        run = this.transitionRun(run.runId, run.checkpointVersion, status, node, { company, role })
      } catch {
        /* not reachable from the current stage — keep the last node */
      }
    }
    if (run.status === 'created' && this.getConfirmedProfile()) tryStep('profile_confirmed', 'P5')
    if (run.status === 'profile_confirmed') tryStep('opportunity_ready', 'S1')
    if (run.status === 'opportunity_ready' || run.status === 'awaiting_company_confirmation') tryStep('research_planned', 'S4')
    if (run.status === 'research_planned') tryStep('researching', 'S5')
    return run
  }

  /** Advance the latest run to a later screening node after research completes a phase. */
  finishResearchPhase(run: WorkflowRunRecord, nextStatus: WorkflowStatus, nextNode: string): WorkflowRunRecord {
    try {
      return this.transitionRun(run.runId, run.checkpointVersion, nextStatus, nextNode, {})
    } catch {
      return run
    }
  }

  createOpportunity(input: { company: string; role: string; profile: ProfileRecord; workflowVersion: string; screenedAt?: string }): string {
    const opportunityId = randomUUID()
    const screenedAt = input.screenedAt ?? now()
    this.db.prepare(`INSERT INTO opportunities
      (opportunity_id, company, role, screened_at, profile_id, profile_version, workflow_version, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(opportunityId, input.company, input.role, screenedAt, input.profile.profileId, input.profile.version, input.workflowVersion, now())
    return opportunityId
  }

  saveUserNote(opportunityId: string, text: string, interviewStage: string | undefined, expectedVersion?: number): { version: number; updatedAt: string } {
    const existing = this.db.prepare('SELECT version FROM user_notes WHERE opportunity_id = ?').get(opportunityId) as SqlRow | undefined
    const actual = existing ? Number(existing.version) : 0
    if (expectedVersion !== undefined && actual !== expectedVersion) throw new Error(`VERSION_CONFLICT: expected ${expectedVersion}, actual ${actual}`)
    const version = actual + 1
    const updatedAt = now()
    this.db.prepare(`INSERT INTO user_notes (note_id, opportunity_id, text, interview_stage, version, updated_at, source)
      VALUES (?, ?, ?, ?, ?, ?, 'user')
      ON CONFLICT(opportunity_id) DO UPDATE SET text = excluded.text, interview_stage = excluded.interview_stage,
        version = excluded.version, updated_at = excluded.updated_at`)
      .run(randomUUID(), opportunityId, text, interviewStage ?? null, version, updatedAt)
    return { version, updatedAt }
  }

  listHistory(): HistoryRow[] {
    const rows = this.db.prepare(`SELECT o.*, n.text AS user_note, n.interview_stage, n.updated_at AS note_updated_at,
      (SELECT decision FROM user_decisions d WHERE d.opportunity_id = o.opportunity_id ORDER BY d.created_at DESC LIMIT 1) AS decision
      FROM opportunities o LEFT JOIN user_notes n ON n.opportunity_id = o.opportunity_id ORDER BY o.screened_at DESC`).all() as SqlRow[]
    return rows.map((row) => ({
      opportunityId: String(row.opportunity_id), company: String(row.company), role: String(row.role), screenedAt: String(row.screened_at),
      profileVersion: `${String(row.profile_id)}-v${String(row.profile_version)}`, workflowVersion: String(row.workflow_version),
      verdict: row.verdict ? String(row.verdict) : undefined, decision: row.decision ? String(row.decision) : undefined,
      interviewStage: row.interview_stage ? String(row.interview_stage) : undefined, userNote: row.user_note ? String(row.user_note) : '',
      noteUpdatedAt: row.note_updated_at ? String(row.note_updated_at) : undefined,
    }))
  }

  saveSource(input: { kind: SourceKind; filename: string; text: string; profileId?: string; byteSize?: number }): FileSourceRecord {
    const sourceId = randomUUID()
    const byteSize = input.byteSize ?? Buffer.byteLength(input.text, 'utf8')
    const hash = contentHash(input.text)
    const createdAt = now()
    this.db.prepare(`INSERT INTO sources
      (source_id, profile_id, kind, filename, byte_size, content_hash, status, text_content, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 'private', ?, ?)`)
      .run(sourceId, input.profileId ?? null, input.kind, input.filename, byteSize, hash, input.text, createdAt)
    return { sourceId, kind: input.kind, filename: input.filename, byteSize, contentHash: hash, text: input.text, createdAt, ...(input.profileId ? { profileId: input.profileId } : {}) }
  }

  listSources(): FileSourceRecord[] {
    const rows = this.db.prepare('SELECT * FROM sources ORDER BY created_at ASC').all() as SqlRow[]
    return rows.map((row) => ({
      sourceId: String(row.source_id), kind: String(row.kind) as SourceKind, filename: String(row.filename),
      byteSize: Number(row.byte_size), contentHash: String(row.content_hash), text: String(row.text_content), createdAt: String(row.created_at),
      ...(row.profile_id ? { profileId: String(row.profile_id) } : {}),
    }))
  }

  saveHumanEval(input: { caseName: string; profileVersion: string; workflowVersion: string; scores: HumanEvalScores; issues: string[]; strengths: string[]; conclusion: string }): HumanEvalRecord {
    const evalId = randomUUID()
    const createdAt = now()
    this.db.prepare(`INSERT INTO evals
      (eval_id, case_name, profile_version, workflow_version, scores_json, issues_json, strengths_json, conclusion, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(evalId, input.caseName, input.profileVersion, input.workflowVersion, stableJson(input.scores), stableJson(input.issues), stableJson(input.strengths), input.conclusion, createdAt)
    return { evalId, caseName: input.caseName, profileVersion: input.profileVersion, workflowVersion: input.workflowVersion, scores: input.scores, issues: input.issues, strengths: input.strengths, conclusion: input.conclusion, createdAt }
  }

  listHumanEvals(): HumanEvalRecord[] {
    const rows = this.db.prepare('SELECT * FROM evals ORDER BY created_at DESC').all() as SqlRow[]
    return rows.map((row) => ({
      evalId: String(row.eval_id), caseName: String(row.case_name), profileVersion: String(row.profile_version), workflowVersion: String(row.workflow_version),
      scores: JSON.parse(String(row.scores_json)) as HumanEvalScores, issues: JSON.parse(String(row.issues_json)) as string[],
      strengths: JSON.parse(String(row.strengths_json)) as string[], conclusion: String(row.conclusion), createdAt: String(row.created_at),
    }))
  }

  private profileFromRow(row: SqlRow): ProfileRecord {
    return {
      profileId: String(row.profile_id), version: Number(row.version), status: String(row.status) as ProfileRecord['status'],
      schemaVersion: String(row.schema_version), contentHash: String(row.content_hash), content: JSON.parse(String(row.content_json)) as ProfileContent,
      createdAt: String(row.created_at), ...(row.confirmed_at ? { confirmedAt: String(row.confirmed_at) } : {}),
    }
  }

  private runFromRow(row: SqlRow): WorkflowRunRecord {
    return {
      runId: String(row.run_id), sessionId: String(row.session_id), status: String(row.status) as WorkflowStatus,
      currentNode: String(row.current_node), skillVersion: String(row.skill_version), checkpointVersion: Number(row.checkpoint_version),
      targetedResearchCount: Number(row.targeted_research_count), createdAt: String(row.created_at), updatedAt: String(row.updated_at),
      ...(row.opportunity_id ? { opportunityId: String(row.opportunity_id) } : {}),
      ...(row.profile_id ? { profileId: String(row.profile_id) } : {}),
      ...(row.profile_version !== null ? { profileVersion: Number(row.profile_version) } : {}),
    }
  }
}
