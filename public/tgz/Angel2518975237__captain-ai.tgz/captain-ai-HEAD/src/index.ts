import type { Context } from '@deepseek-ai/cordis'

import { CaptainService } from './service.js'
import { registerCaptainTools } from './tools/captain-tools.js'
import { CaptainGateway } from './web/gateway.js'

export const name = 'captain'
export const inject: string[] = ['webServer', 'tools', 'subagents']

/**
 * Captain Host entry. Owns the durable store and the onboarding state machine,
 * exposes the allowlisted `/api/captain/*` Web gateway, and registers the
 * `captain_research` tool that drives bounded multi-agent research.
 */
export function apply(ctx: Context): void {
  const service = new CaptainService(ctx)
  const gateway = new CaptainGateway(service.store, service.profile, {
    getLlm: () => ctx.get('llm') as unknown as import('./web/gateway.js').CaptainLlm | undefined,
    getModelSelection: () => {
      const model = ctx.get('agentDefaultModel')
      const selection = model?.currentSelection()
      if (!selection?.provider || !selection?.model) return undefined
      return { provider: selection.provider, model: selection.model, reasoningEffort: selection.reasoningEffort }
    },
    getAttachments: () => ctx.get('attachments') as unknown as import('./web/gateway.js').CaptainAttachments | undefined,
    getVisionModel: () => {
      const model = ctx.get('agentDefaultModel')
      const base = model?.currentSelection()
      if (!base?.provider) return undefined
      if (base.model.includes('vision')) return { provider: base.provider, model: base.model, reasoningEffort: base.reasoningEffort }
      // The current default model isn't vision-capable; prefer the DeepSeek
      // vision model on the same provider route (the user asked for
      // deepseek-v4-flash-vision by default).
      const visionId = base.provider.includes('deepseek') || base.model.includes('deepseek')
        ? 'deepseek-v4-flash-vision-exp'
        : base.model
      return { provider: base.provider, model: visionId, reasoningEffort: base.reasoningEffort }
    },
  })

  ctx.effect(() => gateway.register(ctx), 'captain: web gateway')
  ctx.effect(() => registerCaptainTools(ctx, service.store), 'captain: tools')
  ctx.effect(() => {
    ctx.logger('captain').info('Captain host ready')
    return () => undefined
  }, 'captain: host lifecycle')
}

export { CaptainService }
export { CaptainGateway } from './web/gateway.js'
export { ProfileOnboarding } from './profile/onboarding.js'
export { CaptainStore } from './store/service.js'
