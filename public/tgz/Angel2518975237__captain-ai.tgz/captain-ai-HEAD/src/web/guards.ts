import type { IncomingMessage, ServerResponse } from 'node:http'

/** Maximum accepted request body for Captain API routes. */
export const MAX_BODY_BYTES = 1024 * 1024

/** A stable, JSON-only error envelope every Captain route returns on failure. */
export interface ApiErrorBody {
  error: { code: string; message: string }
}

export function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(payload),
  })
  res.end(payload)
}

export function sendError(res: ServerResponse, status: number, code: string, message: string): void {
  sendJson(res, status, { error: { code, message } })
}

/**
 * Read a JSON request body into memory with a hard size bound. Empty bodies
 * resolve to `{}` so callers can treat "no payload" and "`{}`" uniformly.
 * Rejects with a stable code string so the dispatcher can map it to 4xx.
 */
export function readJsonBody(req: IncomingMessage, maxBytes = MAX_BODY_BYTES): Promise<unknown> {
  return new Promise((resolve, reject) => {
    let size = 0
    let overflow = false
    const chunks: Buffer[] = []
    req.on('data', (chunk: Buffer) => {
      size += chunk.length
      if (size > maxBytes) {
        overflow = true
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => {
      if (overflow) return reject(new Error('BODY_TOO_LARGE'))
      const raw = Buffer.concat(chunks).toString('utf8')
      if (raw.trim() === '') return resolve({})
      try {
        resolve(JSON.parse(raw))
      } catch {
        reject(new Error('INVALID_JSON'))
      }
    })
    req.on('error', reject)
  })
}

/** Narrow an unknown parsed body to a string-keyed record. */
export function asRecord(value: unknown): Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value) ? (value as Record<string, unknown>) : {}
}

/** Require a non-empty string field, throwing a stable code on absence. */
export function requireString(record: Record<string, unknown>, key: string): string {
  const value = record[key]
  if (typeof value !== 'string' || value.length === 0) throw new Error(`MISSING_STRING:${key}`)
  return value
}

/** Require a non-negative-integer field, throwing a stable code on absence. */
export function requireInteger(record: Record<string, unknown>, key: string): number {
  const value = record[key]
  if (!Number.isInteger(value) || (value as number) < 0) throw new Error(`MISSING_INTEGER:${key}`)
  return value as number
}
