import { readFileSync } from 'node:fs'
import type { IncomingMessage, ServerResponse } from 'node:http'

import type { HumanEvalScores, ProfileContent, ProfileRecord, WorkflowRunRecord } from '../domain/models.js'
import { validateProfileContent, type ValidationIssue } from '../domain/validation.js'
import { buildHistoryXlsx } from '../export/xlsx.js'
import { detectKind, parseFile } from '../files/parse.js'
import { ProfileOnboarding, type OnboardingStatus } from '../profile/onboarding.js'
import { CaptainStore } from '../store/service.js'
import { asRecord, readJsonBody, requireInteger, requireString, sendError, sendJson } from './guards.js'

/**
 * Minimal structural surface of the `webServer` service injected by the Web
 * profile (`@deepseek-ai/dsh-host-webserver`). Declared locally so the plugin
 * typechecks without depending on that package's version; the real service is
 * a strict superset of this shape.
 */
export interface CaptainWebServer {
  register(route: {
    kind: 'exact' | 'prefix'
    path: string
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>
  }): () => void
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    webServer: CaptainWebServer
  }
}

type Handler = (req: IncomingMessage, res: ServerResponse) => void | Promise<void>

/** Minimal, dependency-free view of the `agentDefaultModel` service. */
interface ModelSelectionRef {
  provider: string
  model: string
  reasoningEffort?: string
}

/** Minimal, dependency-free view of the `llm.stream` chunk protocol. */
interface LlmChunk {
  type: 'text-delta' | 'reasoning-delta' | 'block-end' | 'finish' | 'usage' | 'tool-call-delta' | 'block-start'
  text?: string
  block?: { type: string; text?: string }
}

/** Minimal structural surface of a durable image attachment ref. */
export interface CaptainImageRef {
  attachmentId: string
  mediaType: string
  bytes: number
  width: number
  height: number
  name?: string
}

/** A content block the captain chat can carry (text, or a durable image). */
export type CaptainContentBlock =
  | { type: 'text'; text: string }
  | { type: 'image'; attachment: CaptainImageRef }

/** Minimal structural surface of the `llm` service injected by the Host. */
export interface CaptainLlm {
  stream(options: {
    provider: string
    model: string
    reasoningEffort?: string
    system?: string
    messages: CaptainLlmMessage[]
    signal?: AbortSignal
  }): AsyncIterable<LlmChunk>
}

/** A hand-built one-shot message, structurally matching dsh-llm's Message. */
export interface CaptainLlmMessage {
  id: string
  role: 'user' | 'assistant'
  content: CaptainContentBlock[]
  source: { kind: 'user' } | { kind: 'model'; provider: string; model: string }
}

/** Minimal surface of the durable attachment store (`ctx.attachments`). */
export interface CaptainAttachments {
  saveImage(input: { data: Uint8Array; mediaType: string; name?: string }): Promise<CaptainImageRef>
  readImage(ref: CaptainImageRef, signal?: AbortSignal): Promise<{ ref: CaptainImageRef; data: Uint8Array }>
}

/**
 * The runtime `llm` service is optional (the plugin also runs headless where no
 * model route is mounted). The gateway resolves it lazily via the accessor below
 * so the chat endpoint degrades to a clear 501 instead of crashing at boot.
 */
export interface CaptainRuntimeDeps {
  getLlm: () => CaptainLlm | undefined
  getModelSelection: () => ModelSelectionRef | undefined
  /** Resolve a vision-capable model for image-aware chat, or undefined when none is mounted. */
  getVisionModel: () => ModelSelectionRef | undefined
  getAttachments: () => CaptainAttachments | undefined
}

/** Map a thrown stable code to an HTTP status; unknown errors become 500. */
function statusFor(error: Error): number {
  const code = error.message
  if (code === 'BODY_TOO_LARGE') return 413
  if (code === 'INVALID_JSON' || code.startsWith('MISSING_') || code.startsWith('INVALID_SCORE')) return 400
  if (code.startsWith('VERSION_CONFLICT') || code.startsWith('PROFILE_INPUT_NOT_ALLOWED') || code.startsWith('PROFILE_CONFIRM_NOT_ALLOWED')) return 409
  if (code.startsWith('INVALID_PROFILE') || code.startsWith('PROFILE_GAPS_REMAIN')) return 422
  if (code === 'RUN_NOT_FOUND' || code === 'PROFILE_NOT_FOUND' || code === 'IMAGE_NOT_FOUND') return 404
  if (code === 'CHAT_UNAVAILABLE' || code === 'MODEL_UNAVAILABLE' || code === 'ATTACHMENTS_UNAVAILABLE') return 501
  if (code === 'EXTRACT_NO_JSON') return 422
  if (code.startsWith('EXTRACT_FAILED')) return 502
  if (code.startsWith('INVALID_IMAGE')) return 400
  return 500
}

const SCORE_KEYS: Array<keyof HumanEvalScores> = ['personalization', 'companyFactTrustworthiness', 'recommendationReasoning', 'unknownHonesty', 'interviewQuestionSpecificity']

function parseScores(record: Record<string, unknown>): HumanEvalScores {
  const scores = {} as HumanEvalScores
  for (const key of SCORE_KEYS) {
    const value = record[key]
    if (!Number.isInteger(value) || (value as number) < 1 || (value as number) > 5) throw new Error(`INVALID_SCORE:${key}`)
    scores[key] = value as number
  }
  return scores
}

function parseStringArray(record: Record<string, unknown>, key: string): string[] {
  const value = record[key]
  if (!Array.isArray(value) || !value.every((item) => typeof item === 'string')) throw new Error(`MISSING_ARRAY:${key}`)
  return value as string[]
}

/**
 * Extract the first balanced JSON object from a model's raw reply (tolerating
 * markdown fences and any preamble). Returns the coerced `ProfileContent` or
 * `undefined` when no object could be parsed. Array fields are minimally
 * normalized so downstream validation reports gaps rather than crashing.
 */
/**
 * Extract a single complete JSON object from raw model text. Unlike a naive
 * `first{`→`last}` slice, this is string- and escape-aware and brace-balanced,
 * so it tolerates the model wrapping the object in prose / markdown fences and
 * even emitting it more than once back-to-back (the DeepSeek route often
 * repeats the payload); `JSON.parse` then receives exactly one object.
 */
function firstJsonObject(raw: string): Record<string, unknown> | undefined {
  let candidate = raw.trim()
  const fence = candidate.match(/```(?:json)?\s*([\s\S]*?)```/i)
  if (fence) candidate = fence[1].trim()
  const start = candidate.indexOf('{')
  if (start < 0) return undefined

  let depth = 0
  let inString = false
  let escaped = false
  for (let i = start; i < candidate.length; i += 1) {
    const ch = candidate[i]
    if (inString) {
      if (escaped) escaped = false
      else if (ch === '\\') escaped = true
      else if (ch === '"') inString = false
      continue
    }
    if (ch === '"') inString = true
    else if (ch === '{') depth += 1
    else if (ch === '}') {
      depth -= 1
      if (depth === 0) {
        const slice = candidate.slice(start, i + 1)
        try {
          const parsed = JSON.parse(slice) as unknown
          return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed as Record<string, unknown> : undefined
        } catch {
          return undefined
        }
      }
    }
  }
  return undefined
}

/**
 * Extract and coerce a `ProfileContent` from a model's raw reply (tolerating
 * markdown fences, prose, and duplicated payloads). Returns `undefined` when no
 * object could be parsed. Array fields are minimally normalized so downstream
 * validation reports gaps rather than crashing.
 */
function parseProfileJson(raw: string): ProfileContent | undefined {
  const parsed = firstJsonObject(raw)
  if (!parsed) return undefined
  const r = parsed
  const bridge = (keys: string[], fallback: string[] = []): string[] => {
    const k = keys.find((key) => Array.isArray(r[key]))
    return k ? (r[k] as unknown[]).map((v) => String(v)) : fallback
  }
  const text = (...keys: string[]): string | undefined => {
    const k = keys.find((key) => typeof r[key] === 'string' && (r[key] as string).trim() !== '' && /\S/.test(r[key] as string))
    return k ? (r[k] as string) : undefined
  }
  const strengths = (Array.isArray(r.strengths) ? r.strengths : [])
    .filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object')
    .map((item) => ({
      capability: String((item as Record<string, unknown>).capability ?? '').trim(),
      evidence: String((item as Record<string, unknown>).evidence ?? '').trim() || '未提供证据',
    }))
    .map((item) => (item.capability === '' ? { capability: '（未命名能力）', evidence: item.evidence } : item))
  return {
    targetRoles: bridge(['targetRoles'], ['未指定目标岗位']),
    adjacentRoles: bridge(['adjacentRoles']),
    excludedRoles: bridge(['excludedRoles']),
    locations: bridge(['locations'], ['未指定城市']),
    ...(text('workMode') ? { workMode: text('workMode') } : {}),
    ...(text('salaryMinimum') ? { salaryMinimum: text('salaryMinimum') } : {}),
    ...(text('salaryExpected') ? { salaryExpected: text('salaryExpected') } : {}),
    ...(text('salaryBasis') ? { salaryBasis: text('salaryBasis') } : {}),
    companyPreferences: bridge(['companyPreferences']),
    excludedCompaniesOrIndustries: bridge(['excludedCompaniesOrIndustries']),
    desiredResponsibilities: bridge(['desiredResponsibilities'], ['未指定期待职责']),
    desiredDecisionRights: bridge(['desiredDecisionRights']),
    strengths,
    ...(bridge(['decisionPriorities']).length > 0 ? { decisionPriorities: bridge(['decisionPriorities']) } : {}),
    hardConstraints: bridge(['hardConstraints'], ['未指定底线条件']),
    unknowns: bridge(['unknowns']),
    privacyRestrictions: bridge(['privacyRestrictions']),
  }
}

/**
 * The allowlisted, same-origin Captain API. The Web profile already fences
 * `/api/*` behind its browser-trust check; this gateway adds method/body
 * guards and a strict, JSON-only contract over the durable store and the
 * onboarding state machine. Private Profile text is never written to logs.
 */
export class CaptainGateway {
  /** Full refs of this session's saved images, keyed by attachmentId, so the thumbnail route can read them back verbatim. */
  private readonly imageRefs = new Map<string, CaptainImageRef>()

  constructor(
    private readonly store: CaptainStore,
    private readonly onboarding: ProfileOnboarding,
    private readonly runtime?: CaptainRuntimeDeps,
  ) {}

  /** Register the `/api/captain` prefix route; returns its disposer. */
  register(ctx: { webServer: CaptainWebServer }): () => void {
    return ctx.webServer.register({ kind: 'prefix', path: '/api/captain', handler: (req, res) => this.dispatch(req, res) })
  }

  private async dispatch(req: IncomingMessage, res: ServerResponse): Promise<void> {
    try {
      const url = new URL(req.url ?? '/', 'http://localhost')
      const subpath = (url.pathname.slice('/api/captain'.length) || '/').replace(/\/+$/, '') || '/'
      const method = req.method ?? 'GET'

      if (method === 'GET' && subpath === '/status') return this.getStatus(res)
      if (method === 'GET' && subpath === '/history') return this.getHistory(res)
      if (method === 'GET' && subpath === '/export.xlsx') return this.exportHistory(res)
      if (method === 'GET' && subpath === '/evals') return this.listEvals(res)
      if (method === 'POST' && subpath === '/eval') return await this.saveEval(req, res)
      if (method === 'POST' && subpath === '/onboarding/begin') return await this.begin(req, res)
      if (method === 'POST' && subpath === '/profile/draft') return await this.submitDraft(req, res)
      if (method === 'POST' && subpath === '/profile/confirm') return await this.confirm(req, res)
      if (method === 'POST' && subpath === '/note') return await this.saveNote(req, res)
      if (method === 'POST' && subpath === '/source') return await this.uploadSource(req, res)
      if (method === 'POST' && subpath === '/profile/extract') return await this.extractProfile(req, res)
      if (method === 'POST' && subpath === '/attachment') return await this.saveAttachment(req, res)
      if (method === 'GET' && subpath.startsWith('/image/')) return await this.getAttachmentImage(res, subpath.slice('/image/'.length))
      if (method === 'GET' && subpath === '/profile/template') return await this.getProfileTemplate(res)
      if (method === 'GET' && subpath.startsWith('/node/')) return await this.getNodeDoc(res, subpath.slice('/node/'.length))
      if (method === 'POST' && subpath === '/chat') return await this.chat(req, res)

      return sendError(res, 404, 'NOT_FOUND', `unknown captain route: ${method} ${subpath}`)
    } catch (error) {
      const message = error instanceof Error ? error.message : 'UNKNOWN_ERROR'
      sendError(res, statusFor(error instanceof Error ? error : new Error(message)), error instanceof Error ? message : 'UNKNOWN_ERROR', message)
    }
  }

  private getStatus(res: ServerResponse): void {
    const run = this.store.getLatestRun()
    sendJson(res, 200, {
      profile: this.store.getConfirmedProfile() ?? null,
      run: run ? { status: run.status, currentNode: run.currentNode, updatedAt: run.updatedAt } : null,
    })
  }

  private getHistory(res: ServerResponse): void {
    sendJson(res, 200, { history: this.store.listHistory() })
  }

  private exportHistory(res: ServerResponse): void {
    const buffer = buildHistoryXlsx(this.store.listHistory())
    res.writeHead(200, {
      'content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'content-disposition': 'attachment; filename="captain-history.xlsx"',
      'cache-control': 'no-store',
      'content-length': String(buffer.length),
    })
    res.end(buffer)
  }

  private listEvals(res: ServerResponse): void {
    sendJson(res, 200, { evals: this.store.listHumanEvals() })
  }

  private async saveEval(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const record = {
      caseName: requireString(body, 'caseName'),
      profileVersion: requireString(body, 'profileVersion'),
      workflowVersion: requireString(body, 'workflowVersion'),
      conclusion: requireString(body, 'conclusion'),
      scores: parseScores(asRecord(body.scores)),
      issues: parseStringArray(body, 'issues'),
      strengths: parseStringArray(body, 'strengths'),
    }
    sendJson(res, 201, { eval: this.store.saveHumanEval(record) })
  }

  private async begin(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const sessionId = requireString(body, 'sessionId')
    sendJson(res, 200, this.onboarding.begin(sessionId))
  }

  private async submitDraft(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const runId = requireString(body, 'runId')
    const expectedVersion = requireInteger(body, 'expectedVersion')
    const profileId = requireString(body, 'profileId')
    const content = body.content as ProfileContent
    if (typeof content !== 'object' || content === null) throw new Error('MISSING_STRING:content')
    sendJson(res, 200, this.onboarding.submitDraft(runId, expectedVersion, profileId, content))
  }

  private async confirm(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const runId = requireString(body, 'runId')
    const expectedVersion = requireInteger(body, 'expectedVersion')
    const profileId = requireString(body, 'profileId')
    const profileVersion = requireInteger(body, 'profileVersion')
    sendJson(res, 200, this.onboarding.confirm(runId, expectedVersion, profileId, profileVersion))
  }

  private async saveNote(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const opportunityId = requireString(body, 'opportunityId')
    const text = requireString(body, 'text')
    const interviewStage = typeof body.interviewStage === 'string' && body.interviewStage.length > 0 ? body.interviewStage : undefined
    const expectedVersion = Number.isInteger(body.expectedVersion) ? (body.expectedVersion as number) : undefined
    sendJson(res, 200, this.store.saveUserNote(opportunityId, text, interviewStage, expectedVersion))
  }

  private async uploadSource(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const filename = requireString(body, 'filename')
    const contentBase64 = requireString(body, 'contentBase64')
    const buffer = Buffer.from(contentBase64, 'base64')
    if (buffer.length === 0) throw new Error('MISSING_STRING:contentBase64')
    const kind = detectKind(filename)
    const text = await parseFile(kind, buffer)
    const source = this.store.saveSource({ kind, filename, text, byteSize: buffer.length })
    sendJson(res, 201, { source })
  }

  /**
   * Structured Profile extraction (P2/P3): run the model over the FULL raw
   * source text and map it into every `ProfileContent` field — locations,
   * salary, strengths, decision priorities, hard constraints, etc. Returns the
   * parsed content plus the validation gaps the caller should confirm.
   * Deliberately does NOT truncate the source (the previous client preview cut
   * to 300 chars and dropped all later sections); only the security-level byte
   * cap in `readJsonBody` still applies.
   */
  private async extractProfile(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const text = requireString(body, 'text')
    if (text.trim().length === 0) throw new Error('MISSING_STRING:text')

    const llm = this.runtime?.getLlm()
    const selection = this.runtime?.getModelSelection()
    if (!llm || !selection) throw new Error('CHAT_UNAVAILABLE')

    const system = [
      '你是 Captain 控制台的求职 Profile 结构化抽取器。',
      '把用户提供的原始资料（简历 / 求职偏好 / 标准模板填写稿）抽取成一个严格的 JSON 对象，字段必须覆盖整个 Profile 的全部维度，不要只抽取开头部分。',
      '严格按下面 schema 输出，只输出 JSON（一行，不要 markdown 代码块、不要解释）：',
      JSON.stringify({
        targetRoles: ['string'], adjacentRoles: ['string'], excludedRoles: ['string'],
        locations: ['string'], workMode: 'string|null', salaryMinimum: 'string|null',
        salaryExpected: 'string|null', salaryBasis: 'string|null',
        companyPreferences: ['string'], excludedCompaniesOrIndustries: ['string'],
        desiredResponsibilities: ['string'], desiredDecisionRights: ['string'],
        strengths: [{ capability: 'string', evidence: 'string' }],
        decisionPriorities: ['string'], hardConstraints: ['string'],
        unknowns: ['string'], privacyRestrictions: ['string'],
      }),
      '规则：',
      '- locations 对应“目标城市/地区/意向城市”；salaryExpected/salaryMinimum 对应“期望薪资/最低可接受薪资”。',
      '- strengths 对应“核心优势/能力”，每项给出 capability 和 evidence；证据缺失时就地写“未提供证据”。',
      '- decisionPriorities 对应“关键取舍规则/决策优先级”；hardConstraints 对应“硬性排除 + 底线条件 + 特殊机会绝对底线”。',
      '- 文中没有提到的字段给空数组 [] 或 null（workMode/salary* 为 null），不要编造。',
      '- 文中明确写“不确定”或留空的，归到 unknowns 数组，不要假装有值。',
    ].join('\n')

    const userPrompt = `原始资料如下（全文，请完整阅读并抽取，不要只取开头）：\n\n${text}`

    let reply = ''
    try {
      const stream = llm.stream({
        provider: selection.provider,
        model: selection.model,
        reasoningEffort: selection.reasoningEffort,
        system,
        messages: [{
          id: `captain-extract-${Date.now()}`,
          role: 'user',
          content: [{ type: 'text', text: userPrompt }],
          source: { kind: 'user' },
        }],
      })
      for await (const chunk of stream) {
        if (chunk.type === 'text-delta' && chunk.text) reply += chunk.text
        else if (chunk.type === 'block-end' && chunk.block?.type === 'text' && chunk.block.text) reply += chunk.block.text
        else if (chunk.type === 'finish') break
      }
    } catch (error) {
      throw new Error(`EXTRACT_FAILED: ${error instanceof Error ? error.message : 'unknown'}`)
    }

    const content = parseProfileJson(reply.trim())
    if (!content) throw new Error('EXTRACT_NO_JSON')
    const gaps = validateProfileContent(content).filter((issue) => issue.critical)
    // Advance the live voyage run through the Profile-input phases (P1→P2→P4/P5)
    // so the sidebar rail tracks real progress from the upload/parse task, not
    // a run stuck on `created`/C0. sessionId/profileId stay stable across polls.
    const sessionId = typeof body.sessionId === 'string' && body.sessionId.length > 0 ? body.sessionId : 'captain-console'
    const profileId = typeof body.profileId === 'string' && body.profileId.length > 0 ? body.profileId : `profile-${sessionId}`
    const advanced = this.onboarding.applyExtractedDraft(sessionId, profileId, content)
    sendJson(res, 200, {
      content, gaps,
      run: { status: advanced.run.status, currentNode: advanced.run.currentNode, updatedAt: advanced.run.updatedAt },
      route: advanced.route,
    })
  }

  /** Accept a base64 image from a pasted/dropped file and durably store it. */
  private async saveAttachment(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const attachments = this.runtime?.getAttachments()
    if (!attachments) throw new Error('ATTACHMENTS_UNAVAILABLE')
    const body = asRecord(await readJsonBody(req))
    const mediaType = requireString(body, 'mediaType')
    const data = requireString(body, 'data')
    const name = typeof body.name === 'string' && body.name.length > 0 ? body.name : undefined
    if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(mediaType)) throw new Error('INVALID_IMAGE_MEDIA_TYPE')
    const bytes = Buffer.from(data, 'base64')
    if (bytes.length === 0) throw new Error('MISSING_STRING:data')
    const attachment = await attachments.saveImage({ data: new Uint8Array(bytes), mediaType, name })
    this.imageRefs.set(attachment.attachmentId, attachment)
    sendJson(res, 201, { attachment })
  }

  /** Stream a stored attachment image back to the browser for the thumbnail. */
  private async getAttachmentImage(res: ServerResponse, attachmentId: string): Promise<void> {
    const attachments = this.runtime?.getAttachments()
    if (!attachments) throw new Error('ATTACHMENTS_UNAVAILABLE')
    const ref = this.imageRefs.get(attachmentId)
    if (!ref) throw new Error('IMAGE_NOT_FOUND')
    const stored = await attachments.readImage(ref)
    const mediaType = stored.ref.mediaType || 'image/png'
    res.writeHead(200, {
      'content-type': mediaType,
      'cache-control': 'private, max-age=31536000, immutable',
      'content-length': stored.data.byteLength,
    })
    res.end(Buffer.from(stored.data))
  }

  /** Stream the private Profile template as a browser download. */
  private async getProfileTemplate(res: ServerResponse): Promise<void> {
    const path = this.assetPath('profile-template.md')
    const content = readFileSync(path)
    res.writeHead(200, {
      'content-type': 'text/markdown; charset=utf-8',
      'content-disposition': 'attachment; filename="captain-profile-template.md"',
      'cache-control': 'no-store',
      'content-length': String(content.length),
    })
    res.end(content)
  }

  // Whitelist of inspectable Workflow node ids (C0, P1–P5, S1–S10, E1–E2).
  private static readonly NODE_IDS = new Set(['C0', 'P1', 'P2', 'P3', 'P4', 'P5', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10', 'E1', 'E2'])

  /** Return the inspectable prompt contract for one Workflow node. */
  private async getNodeDoc(res: ServerResponse, nodeId: string): Promise<void> {
    if (!/^[A-Z][0-9]{1,2}$/.test(nodeId) || !CaptainGateway.NODE_IDS.has(nodeId)) {
      return sendError(res, 404, 'NOT_FOUND', `unknown captain node: ${nodeId}`)
    }
    const path = this.skillPath(`${nodeId}.md`)
    let content: Buffer
    try {
      content = readFileSync(path)
    } catch {
      return sendError(res, 404, 'NOT_FOUND', `no skill contract for node ${nodeId}`)
    }
    sendJson(res, 200, { id: nodeId, markdown: content.toString('utf8') })
  }

  /**
   * Single-turn Captain chat: run the current default DSH model over the
   * posted conversation and stream back the assembled reply. Intentionally
   * model-level (not an Agent) so the console is a light, isolated loop — the
   * user asked for a conversation inside the Captain overlay, not a subagent.
   *
   * A user message may carry a durable image block (attached via
   * `POST /attach`). When any turned message contains an image, the model
   * route is upgraded to a vision-capable model so the DSH vision model
   * (deepseek-v4-flash-vision) recognizes the screenshot/picture.
   */
  private async chat(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = asRecord(await readJsonBody(req))
    const rawMessages = body.messages
    if (!Array.isArray(rawMessages) || rawMessages.length === 0) throw new Error('MISSING_STRING:messages')

    const llm = this.runtime?.getLlm()
    const selection = this.runtime?.getModelSelection()
    if (!llm || !selection) throw new Error('CHAT_UNAVAILABLE')

    const messages = rawMessages.map((item, index): CaptainLlmMessage => {
      const record = asRecord(item)
      const role = record.role
      if (role !== 'user' && role !== 'assistant') throw new Error('INVALID_CHAT_ROLE')

      const content = record.content
      const blocks: CaptainContentBlock[] = []
      if (typeof content === 'string' && content.length > 0) {
        blocks.push({ type: 'text', text: content })
      } else if (Array.isArray(content)) {
        for (const block of content) {
          const b = asRecord(block)
          if (b.type === 'text' && typeof b.text === 'string' && b.text.length > 0) {
            blocks.push({ type: 'text', text: b.text })
          } else if (b.type === 'image' && typeof (b.attachment as Record<string, unknown> | undefined)?.attachmentId === 'string') {
            const a = asRecord(b.attachment as Record<string, unknown>)
            blocks.push({ type: 'image', attachment: { attachmentId: String(a.attachmentId), mediaType: String(a.mediaType), bytes: Number(a.bytes), width: Number(a.width), height: Number(a.height), ...(typeof a.name === 'string' ? { name: a.name } : {}) } })
          }
        }
      }
      if (blocks.length === 0) throw new Error('MISSING_STRING:content')

      return {
        id: `captain-${Date.now()}-${index}`,
        role,
        content: blocks,
        source: role === 'user' ? { kind: 'user' } : { kind: 'model', provider: selection.provider, model: selection.model },
      }
    })

    const hasImage = messages.some((message) => message.content.some((block) => block.type === 'image'))
    const route = hasImage ? (this.runtime?.getVisionModel() ?? selection) : selection
    const provider = route.provider
    const model = route.model
    const reasoningEffort = route.reasoningEffort

    const system = [
      '你是 Captain 控制台里的求职决策助手。',
      '请用简体中文、语气专业克制地回答；对不确定的事实明确说“不确定”，不要编造。',
      '你正在帮助用户进行公司岗位筛查与求职偏好梳理。回答尽量具体、可执行。',
      ...(hasImage ? ['用户可能粘贴了一张图片（截图、简历页、岗位 JD 等），请仔细识别其中的文字与信息，并据此继续回答。'] : []),
    ].join('\n')

    let reply = ''
    try {
      const stream = llm.stream({ provider, model, reasoningEffort, system, messages })
      for await (const chunk of stream) {
        if (chunk.type === 'text-delta' && chunk.text) reply += chunk.text
        else if (chunk.type === 'block-end' && chunk.block?.type === 'text' && chunk.block.text) reply += chunk.block.text
        else if (chunk.type === 'finish') break
      }
    } catch (error) {
      throw new Error(`CHAT_STREAM_FAILED: ${error instanceof Error ? error.message : 'unknown'}`)
    }

    sendJson(res, 200, { reply: reply.trim() || '（本次对话没有返回文字。）' })
  }

  /** Resolve a packaged asset (profile template) under the installed plugin root. */
  private assetPath(name: string): string {
    return new URL(`../../assets/${name}`, import.meta.url).pathname
  }

  /** Resolve a packaged Skill contract under the installed plugin root. */
  private skillPath(name: string): string {
    return new URL(`../../skills/nodes/${name}`, import.meta.url).pathname
  }
}

export type { OnboardingStatus, ProfileContent, ProfileRecord, WorkflowRunRecord, Handler }
export { parseProfileJson }
