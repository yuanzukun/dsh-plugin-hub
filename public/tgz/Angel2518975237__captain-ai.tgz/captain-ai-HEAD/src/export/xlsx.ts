import type { HistoryRow } from '../domain/models.js'
import { buildZip } from './zip.js'

/** Escape XML special characters inside element text and attribute values. */
function xmlEscape(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

/**
 * Defuse spreadsheet formula injection: cells that begin with `=`, `+`, `-`,
 * `@`, or a control character get a leading apostrophe so they are always
 * treated as literal text, never as a formula.
 */
function excelCellText(value: string): string {
  const text = value.replace(/[\u0000-\u001f]/g, ' ')
  return /^[=+\-@]/.test(text) ? `'${text}` : text
}

function columnName(index: number): string {
  let name = ''
  let n = index
  while (n >= 0) {
    name = String.fromCharCode((n % 26) + 65) + name
    n = Math.floor(n / 26) - 1
  }
  return name
}

function sheetRow(rowIndex: number, cells: string[]): string {
  const tds = cells.map((cell, index) => {
    const ref = `${columnName(index)}${rowIndex}`
    const escaped = xmlEscape(excelCellText(cell))
    return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${escaped}</t></is></c>`
  }).join('')
  return `<row r="${rowIndex}">${tds}</row>`
}

function worksheetXml(rows: string[][]): string {
  const body = rows.map((cells, index) => sheetRow(index + 1, cells)).join('')
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`
}

const CONTENT_TYPES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`

const ROOT_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`

const WORKBOOK = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="航程" sheetId="1" r:id="rId1"/></sheets></workbook>`

const WORKBOOK_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`

/** Build a single-sheet "航程" workbook from the history rows. */
export function buildHistoryXlsx(rows: HistoryRow[]): Buffer {
  const header = ['公司', '岗位', '筛查日期', 'Profile 版本', 'Workflow 版本', '结论', '决定', '面试阶段', '我的备注']
  const body = rows.map((row) => [
    row.company, row.role, row.screenedAt.slice(0, 10), row.profileVersion, row.workflowVersion,
    row.verdict ?? '', row.decision ?? '', row.interviewStage ?? '', row.userNote,
  ])
  return buildZip([
    { name: '[Content_Types].xml', data: Buffer.from(CONTENT_TYPES) },
    { name: '_rels/.rels', data: Buffer.from(ROOT_RELS) },
    { name: 'xl/workbook.xml', data: Buffer.from(WORKBOOK) },
    { name: 'xl/_rels/workbook.xml.rels', data: Buffer.from(WORKBOOK_RELS) },
    { name: 'xl/worksheets/sheet1.xml', data: Buffer.from(worksheetXml([header, ...body])) },
  ])
}
