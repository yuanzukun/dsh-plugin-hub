export type EvidenceReviewStatus = 'accepted' | 'needs_review' | 'rejected' | 'unknown'

export interface EvidenceDraft {
  evidenceId: string
  authorAgentId: string
  company: string
  claim: string
  sourceUrl: string
  sourceKind: 'original' | 'search_snippet' | 'aggregator' | 'user_provided'
  locator?: string
  publishedAt?: string
  accessedAt: string
}

export interface EvidenceReview {
  evidenceId: string
  status: EvidenceReviewStatus
  reasons: string[]
  reviewerAgentId: string
}

export function reviewEvidence(draft: EvidenceDraft, reviewerAgentId: string): EvidenceReview {
  if (draft.authorAgentId === reviewerAgentId) throw new Error('SELF_REVIEW_FORBIDDEN')
  const reasons: string[] = []
  if (draft.sourceKind === 'search_snippet') reasons.push('搜索摘要不是可接受的核心证据。')
  if (draft.sourceKind === 'aggregator') reasons.push('聚合页必须继续定位到原始来源。')
  if (!draft.locator?.trim()) reasons.push('缺少原文定位信息。')
  try { new URL(draft.sourceUrl) } catch { reasons.push('来源 URL 无效。') }
  if (!draft.claim.trim()) reasons.push('事实主张为空。')
  if (reasons.length === 0) return { evidenceId: draft.evidenceId, status: 'accepted', reasons: [], reviewerAgentId }
  const hardReject = draft.sourceKind === 'search_snippet' || !draft.claim.trim()
  return { evidenceId: draft.evidenceId, status: hardReject ? 'rejected' : 'needs_review', reasons, reviewerAgentId }
}
