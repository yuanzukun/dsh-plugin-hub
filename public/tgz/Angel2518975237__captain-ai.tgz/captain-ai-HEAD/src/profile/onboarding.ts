import type { ProfileContent, ProfileRecord, WorkflowRunRecord } from '../domain/models.js'
import { validateProfileContent, type ValidationIssue } from '../domain/validation.js'
import { CaptainStore } from '../store/service.js'

export interface OnboardingStatus {
  run: WorkflowRunRecord
  route: 'submit_profile' | 'submit_opportunity' | 'answer_gaps' | 'confirm_profile'
  profile?: ProfileRecord
  gaps: ValidationIssue[]
}

export class ProfileOnboarding {
  constructor(private readonly store: CaptainStore, private readonly skillVersion: string) {}

  begin(sessionId: string): OnboardingStatus {
    const profile = this.store.getConfirmedProfile()
    const run = this.store.createRun(sessionId, this.skillVersion, profile)
    if (profile) return { run, route: 'submit_opportunity', profile, gaps: [] }
    const missing = this.store.transitionRun(run.runId, 0, 'profile_missing', 'P1', { route: 'onboarding' })
    return { run: missing, route: 'submit_profile', gaps: [] }
  }

  submitDraft(runId: string, expectedVersion: number, profileId: string, content: ProfileContent): OnboardingStatus {
    const run = this.store.getRun(runId)
    if (!run) throw new Error('RUN_NOT_FOUND')
    if (!['profile_missing', 'awaiting_profile_input'].includes(run.status)) throw new Error(`PROFILE_INPUT_NOT_ALLOWED: ${run.status}`)
    if (run.checkpointVersion !== expectedVersion) throw new Error(`VERSION_CONFLICT: expected ${expectedVersion}, actual ${run.checkpointVersion}`)
    const profile = this.store.saveProfileDraft(profileId, content)
    const draftRun = this.store.transitionRun(runId, expectedVersion, 'profile_draft', 'P2', { profileId, profileVersion: profile.version })
    const gaps = validateProfileContent(content).filter((issue) => issue.critical)
    const next = gaps.length > 0
      ? this.store.transitionRun(runId, draftRun.checkpointVersion, 'awaiting_profile_input', 'P4', { gapPaths: gaps.map((gap) => gap.path) })
      : this.store.transitionRun(runId, draftRun.checkpointVersion, 'awaiting_profile_confirmation', 'P5', { profileId, profileVersion: profile.version })
    return { run: next, route: gaps.length > 0 ? 'answer_gaps' : 'confirm_profile', profile, gaps }
  }

  /**
   * Apply an already-extracted Profile draft to the live run and advance it
   * through the Profile-input phases (P1 → P2 → P4/P5). The sidebar's voyage
   * rail follows the returned run, so uploading + parsing a source now drives
   * visible progress instead of leaving the run on `created`/`C0`.
   *
   * Re-entrant: submitting the same profileId again bumps its version and
   * re-runs the gap triage (an unconfirmed draft is re-editable — the state
   * machine allows `awaiting_profile_confirmation → profile_draft`).
   */
  applyExtractedDraft(sessionId: string, profileId: string, content: ProfileContent): OnboardingStatus {
    let run = this.store.getLatestRun()
    if (!run) run = this.store.createRun(sessionId, this.skillVersion, this.store.getConfirmedProfile())
    // A confirmed profile skips the input phase entirely.
    if (run.status === 'profile_confirmed') return { run, route: 'submit_opportunity', profile: this.store.getConfirmedProfile(), gaps: [] }
    // Bring a fresh/un-started run to `profile_missing`/P1 so submitDraft can act.
    if (run.status === 'created') run = this.store.transitionRun(run.runId, run.checkpointVersion, 'profile_missing', 'P1', { route: 'onboarding' })
    // Re-edit an already-drafted-but-unconfirmed profile by falling back to its input phase.
    if (run.status === 'awaiting_profile_confirmation') run = this.store.transitionRun(run.runId, run.checkpointVersion, 'profile_draft', 'P2', { profileId })
    if (run.status === 'awaiting_profile_input' || run.status === 'profile_missing') {
      return this.submitDraft(run.runId, run.checkpointVersion, profileId, content)
    }
    // Already past the Profile phase (research onward) — report the live run
    // untoueed, only surfacing any validation gaps for the caller.
    return { run, route: 'submit_opportunity', profile: this.store.getConfirmedProfile(), gaps: validateProfileContent(content).filter((issue) => issue.critical) }
  }

  confirm(runId: string, expectedVersion: number, profileId: string, profileVersion: number): OnboardingStatus {
    const run = this.store.getRun(runId)
    if (!run) throw new Error('RUN_NOT_FOUND')
    if (run.status !== 'awaiting_profile_confirmation') throw new Error(`PROFILE_CONFIRM_NOT_ALLOWED: ${run.status}`)
    if (run.checkpointVersion !== expectedVersion) throw new Error(`VERSION_CONFLICT: expected ${expectedVersion}, actual ${run.checkpointVersion}`)
    const profile = this.store.confirmProfile(profileId, profileVersion)
    const confirmedRun = this.store.transitionRun(runId, expectedVersion, 'profile_confirmed', 'P5', { profileId, profileVersion, contentHash: profile.contentHash })
    return { run: confirmedRun, route: 'submit_opportunity', profile, gaps: [] }
  }
}
