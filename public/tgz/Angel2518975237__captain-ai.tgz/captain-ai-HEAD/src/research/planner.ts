export interface ResearchTask {
  taskId: string
  question: string
  category: 'company' | 'business' | 'role' | 'employment'
  dependencies: string[]
  preferredSources: string[]
  required: boolean
}

export interface ResearchPlan {
  tasks: ResearchTask[]
  maxWorkers: number
  maxSourcesPerTask: number
  targetedResearchLimit: 1
}

export function createResearchPlan(input: { company: string; role: string; knownSalary?: boolean }): ResearchPlan {
  const tasks: ResearchTask[] = [
    { taskId: 'company-identity', question: `核验 ${input.company} 的法律主体、官网与核心产品。`, category: 'company', dependencies: [], preferredSources: ['company_official', 'registry'], required: true },
    { taskId: 'business-health', question: `核验 ${input.company} 的业务阶段、融资与近期经营信号。`, category: 'business', dependencies: ['company-identity'], preferredSources: ['company_official', 'investor_or_registry', 'reputable_original_reporting'], required: true },
    { taskId: 'role-reality', question: `核验 ${input.role} 的真实职责、汇报关系与决策权。`, category: 'role', dependencies: ['company-identity'], preferredSources: ['job_original', 'company_official'], required: true },
    { taskId: 'employment-risk', question: `核验工作地点、制度、合同与${input.knownSalary ? '薪资口径' : '可获得的薪资信息'}。`, category: 'employment', dependencies: ['company-identity'], preferredSources: ['job_original', 'company_official', 'employee_first_party'], required: true },
  ]
  return { tasks, maxWorkers: Math.min(4, tasks.length), maxSourcesPerTask: 5, targetedResearchLimit: 1 }
}

export function validateResearchPlan(plan: ResearchPlan): void {
  if (plan.tasks.length < 1 || plan.tasks.length > 6) throw new Error('INVALID_TASK_COUNT')
  if (plan.maxWorkers < 1 || plan.maxWorkers > 4 || plan.maxWorkers > plan.tasks.length) throw new Error('INVALID_WORKER_BUDGET')
  if (plan.targetedResearchLimit !== 1) throw new Error('INVALID_TARGETED_RESEARCH_LIMIT')
  const ids = new Set(plan.tasks.map((task) => task.taskId))
  if (ids.size !== plan.tasks.length) throw new Error('DUPLICATE_TASK_ID')
  for (const task of plan.tasks) for (const dependency of task.dependencies) if (!ids.has(dependency)) throw new Error(`UNKNOWN_DEPENDENCY: ${dependency}`)
  const visiting = new Set<string>(); const visited = new Set<string>()
  const visit = (id: string): void => {
    if (visiting.has(id)) throw new Error('CYCLIC_RESEARCH_PLAN')
    if (visited.has(id)) return
    visiting.add(id)
    const task = plan.tasks.find((item) => item.taskId === id) as ResearchTask
    task.dependencies.forEach(visit)
    visiting.delete(id); visited.add(id)
  }
  plan.tasks.forEach((task) => visit(task.taskId))
}
