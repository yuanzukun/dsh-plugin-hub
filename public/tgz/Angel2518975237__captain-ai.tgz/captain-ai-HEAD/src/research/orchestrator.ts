import type { ResearchPlan, ResearchTask } from './planner.js'

/**
 * Minimal structural surface of the DSH multi-agent seam, verified in
 * `docs/spikes/dsh-multi-agent.md` against `@deepseek-ai/dsh-subagent` 0.1.1-rc.2.
 * Declared locally so the plugin typechecks without depending on that package;
 * the real `ctx.subagents` is a strict superset. At runtime the caller passes
 * `ctx.subagents` and the `exec.agent` from a registered tool.
 */
export interface ContentBlock { type: string; text?: string }
export interface SubagentResult { output: ContentBlock[]; structured?: unknown; stopReason: string }
export interface SubagentRun { result: SubagentResult }
export interface SubagentStartRequest {
  label?: string
  prompt: ContentBlock[]
  parent: unknown
  signal: AbortSignal
  toolFilter?: { allow?: string[]; deny?: string[] }
  outputSchema?: Record<string, unknown>
}
export interface SubagentRuntimeLike {
  start(provider: string, request: SubagentStartRequest): Promise<SubagentRun>
}

export type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue }

export interface WorkerOutcome {
  taskId: string
  status: 'ok' | 'failed'
  structured?: JsonValue
  error?: string
}

/** Evidence Draft output contract the research workers must satisfy. */
export const EVIDENCE_OUTPUT_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    claims: { type: 'array', items: { type: 'object', properties: { statement: { type: 'string' }, sourceUrl: { type: 'string' }, locator: { type: 'string' } }, required: ['statement', 'sourceUrl'] } },
    conflicts: { type: 'array', items: { type: 'string' } },
    unknowns: { type: 'array', items: { type: 'string' } },
    inaccessibleSources: { type: 'array', items: { type: 'string' } },
  },
  required: ['claims'],
}

function depthOf(tasks: ResearchTask[], id: string, memo: Map<string, number>): number {
  const cached = memo.get(id)
  if (cached !== undefined) return cached
  const task = tasks.find((item) => item.taskId === id) as ResearchTask
  const depth = task.dependencies.reduce((max, dep) => Math.max(max, depthOf(tasks, dep, memo) + 1), 0)
  memo.set(id, depth)
  return depth
}

async function mapConcurrent<T, R>(items: T[], limit: number, signal: AbortSignal, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length)
  let next = 0
  async function runner(): Promise<void> {
    while (next < items.length && !signal.aborted) {
      const index = next
      next += 1
      results[index] = await fn(items[index])
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, runner))
  return results.filter((item) => item !== undefined)
}

/**
 * Bounded, dependency-aware multi-agent research fan-out (S5). Runs the plan
 * DAG level by level, never exceeding `maxWorkers` concurrent workers, scoping
 * each worker to web_search/web_read via `toolFilter`, and requiring the
 * Evidence output schema. Independent task failure never cancels a sibling;
 * a task whose dependency failed is recorded as `DEPENDENCY_FAILED`.
 */
export class ResearchOrchestrator {
  constructor(private readonly subagents: SubagentRuntimeLike, private readonly provider = 'spawn') {}

  async fanOut(plan: ResearchPlan, parent: unknown, signal: AbortSignal): Promise<WorkerOutcome[]> {
    const outcomes: WorkerOutcome[] = []
    const failed = new Set<string>()
    const levels = new Map<number, ResearchTask[]>()
    const memo = new Map<string, number>()
    for (const task of plan.tasks) {
      const depth = depthOf(plan.tasks, task.taskId, memo)
      const bucket = levels.get(depth) ?? []
      bucket.push(task)
      levels.set(depth, bucket)
    }

    for (let depth = 0; levels.has(depth); depth += 1) {
      if (signal.aborted) {
        for (let d = depth; levels.has(d); d += 1) {
          for (const task of levels.get(d) as ResearchTask[]) {
            outcomes.push({ taskId: task.taskId, status: 'failed', error: 'CANCELLED' })
          }
        }
        break
      }
      const level = levels.get(depth) as ResearchTask[]
      const runnable: ResearchTask[] = []
      for (const task of level) {
        if (task.dependencies.some((dep) => failed.has(dep))) {
          outcomes.push({ taskId: task.taskId, status: 'failed', error: 'DEPENDENCY_FAILED' })
          failed.add(task.taskId)
        } else {
          runnable.push(task)
        }
      }
      const results = await mapConcurrent(runnable, plan.maxWorkers, signal, (task) => this.runOne(task, parent, signal))
      for (const outcome of results) {
        outcomes.push(outcome)
        if (outcome.status === 'failed') failed.add(outcome.taskId)
      }
    }
    return outcomes
  }

  private async runOne(task: ResearchTask, parent: unknown, signal: AbortSignal): Promise<WorkerOutcome> {
    if (signal.aborted) return { taskId: task.taskId, status: 'failed', error: 'CANCELLED' }
    try {
      const run = await this.subagents.start(this.provider, {
        label: `captain-research:${task.taskId}`,
        prompt: [{ type: 'text', text: task.question }],
        parent,
        signal,
        toolFilter: { allow: ['web_search', 'web_read'] },
        outputSchema: EVIDENCE_OUTPUT_SCHEMA,
      })
      return { taskId: task.taskId, status: 'ok', structured: run.result.structured as JsonValue | undefined }
    } catch (error) {
      return { taskId: task.taskId, status: 'failed', error: error instanceof Error ? error.message : 'WORKER_FAILED' }
    }
  }
}
