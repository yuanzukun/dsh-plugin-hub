import { join } from 'node:path'

import { Service, type Context } from '@deepseek-ai/cordis'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'

import { ProfileOnboarding } from './profile/onboarding.js'
import { CaptainStore } from './store/service.js'

declare module '@deepseek-ai/cordis' {
  interface Context {
    captain: CaptainService
  }
}

export class CaptainService extends Service {
  readonly store: CaptainStore
  readonly profile: ProfileOnboarding

  constructor(ctx: Context, dbPath?: string) {
    super(ctx, 'captain')
    const resolved = dbPath ?? join(resolveDshHome(), 'storages', 'captain', 'captain.sqlite')
    this.store = new CaptainStore(resolved)
    this.profile = new ProfileOnboarding(this.store, 'workflow-v0.3')
    ctx.effect(() => () => this.store.close(), 'captain: close store')
  }
}
