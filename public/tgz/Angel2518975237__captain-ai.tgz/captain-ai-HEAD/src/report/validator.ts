export interface ReportClaim {
  claimId: string
  topic: string
  statement: string
  confidence: 'high' | 'medium' | 'low' | 'unknown'
  evidenceIds: string[]
  profileItemIds: string[]
}

export interface ReportValidation {
  valid: boolean
  failures: Array<{ claimId: string; code: string; message: string }>
}

const MATCH_LANGUAGE = /符合|匹配|满足|达标|合适/

export function validateReportClaims(claims: ReportClaim[], acceptedEvidenceIds: ReadonlySet<string>): ReportValidation {
  const failures: ReportValidation['failures'] = []
  for (const claim of claims) {
    const rejectedRefs = claim.evidenceIds.filter((id) => !acceptedEvidenceIds.has(id))
    if (rejectedRefs.length > 0) failures.push({ claimId: claim.claimId, code: 'UNACCEPTED_EVIDENCE', message: `引用了未通过复核的 Evidence：${rejectedRefs.join(', ')}` })
    if (claim.confidence !== 'unknown' && claim.evidenceIds.length === 0) failures.push({ claimId: claim.claimId, code: 'UNCITED_FACT', message: '非未知主张必须引用 Evidence。' })
    if (claim.topic === 'salary' && claim.confidence === 'unknown' && MATCH_LANGUAGE.test(claim.statement)) failures.push({ claimId: claim.claimId, code: 'UNKNOWN_AS_MATCH', message: '薪资未知时不得表达为符合或匹配。' })
    if (/个人|偏好|红线|能力/.test(claim.topic) && claim.profileItemIds.length === 0) failures.push({ claimId: claim.claimId, code: 'MISSING_PROFILE_REFERENCE', message: '个性化判断必须引用 Profile Item。' })
  }
  return { valid: failures.length === 0, failures }
}
