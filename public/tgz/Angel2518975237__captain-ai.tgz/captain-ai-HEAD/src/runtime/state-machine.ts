import type { WorkflowStatus } from '../domain/models.js'

const TRANSITIONS: Readonly<Record<WorkflowStatus, readonly WorkflowStatus[]>> = {
  created: ['profile_missing', 'profile_confirmed', 'cancelled'],
  profile_missing: ['profile_draft', 'paused', 'cancelled'],
  profile_draft: ['awaiting_profile_input', 'awaiting_profile_confirmation', 'failed_recoverable', 'cancelled'],
  awaiting_profile_input: ['profile_draft', 'awaiting_profile_confirmation', 'paused', 'cancelled'],
  awaiting_profile_confirmation: ['profile_draft', 'profile_confirmed', 'paused', 'cancelled'],
  profile_confirmed: ['opportunity_ready', 'paused', 'cancelled'],
  opportunity_ready: ['awaiting_company_confirmation', 'research_planned', 'failed_recoverable', 'cancelled'],
  awaiting_company_confirmation: ['opportunity_ready', 'research_planned', 'paused', 'cancelled'],
  research_planned: ['researching', 'failed_recoverable', 'cancelled'],
  researching: ['evidence_review', 'partial', 'failed_recoverable', 'cancelled'],
  evidence_review: ['context_selected', 'partial', 'failed_recoverable', 'cancelled'],
  context_selected: ['fit_analysis', 'failed_recoverable', 'cancelled'],
  fit_analysis: ['targeted_research', 'report_validating', 'failed_recoverable', 'cancelled'],
  targeted_research: ['evidence_review', 'partial', 'failed_recoverable', 'cancelled'],
  report_validating: ['report_ready', 'failed_recoverable', 'failed_terminal', 'cancelled'],
  report_ready: ['awaiting_user_decision', 'completed'],
  awaiting_user_decision: ['completed', 'paused', 'cancelled'],
  completed: [],
  paused: ['profile_missing', 'awaiting_profile_input', 'awaiting_profile_confirmation', 'opportunity_ready', 'awaiting_company_confirmation', 'research_planned', 'awaiting_user_decision', 'cancelled'],
  partial: ['evidence_review', 'context_selected', 'report_validating', 'paused', 'cancelled'],
  failed_recoverable: ['profile_draft', 'opportunity_ready', 'research_planned', 'researching', 'evidence_review', 'report_validating', 'paused', 'cancelled'],
  failed_terminal: [],
  cancelled: [],
}

export function canTransition(from: WorkflowStatus, to: WorkflowStatus): boolean {
  return TRANSITIONS[from].includes(to)
}

export function assertTransition(from: WorkflowStatus, to: WorkflowStatus): void {
  if (!canTransition(from, to)) throw new Error(`INVALID_TRANSITION: ${from} -> ${to}`)
}

export const workflowTransitions = TRANSITIONS
