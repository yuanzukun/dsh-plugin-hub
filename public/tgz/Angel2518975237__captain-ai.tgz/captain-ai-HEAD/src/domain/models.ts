export type ProfileStatus = 'draft' | 'confirmed' | 'superseded'
export type WorkflowStatus =
  | 'created'
  | 'profile_missing'
  | 'profile_draft'
  | 'awaiting_profile_input'
  | 'awaiting_profile_confirmation'
  | 'profile_confirmed'
  | 'opportunity_ready'
  | 'awaiting_company_confirmation'
  | 'research_planned'
  | 'researching'
  | 'evidence_review'
  | 'context_selected'
  | 'fit_analysis'
  | 'targeted_research'
  | 'report_validating'
  | 'report_ready'
  | 'awaiting_user_decision'
  | 'completed'
  | 'paused'
  | 'partial'
  | 'failed_recoverable'
  | 'failed_terminal'
  | 'cancelled'

export interface ProfileContent {
  targetRoles: string[]
  adjacentRoles: string[]
  excludedRoles: string[]
  locations: string[]
  workMode?: string
  salaryMinimum?: string
  salaryExpected?: string
  salaryBasis?: string
  companyPreferences: string[]
  excludedCompaniesOrIndustries: string[]
  desiredResponsibilities: string[]
  desiredDecisionRights: string[]
  strengths: Array<{ capability: string; evidence: string }>
  /** 关键取舍规则 / 决策优先级（例如“成熟导师 vs 更大名义范围如何取舍”）。 */
  decisionPriorities?: string[]
  hardConstraints: string[]
  unknowns: string[]
  privacyRestrictions: string[]
}

export interface ProfileRecord {
  profileId: string
  version: number
  status: ProfileStatus
  schemaVersion: string
  contentHash: string
  content: ProfileContent
  createdAt: string
  confirmedAt?: string
}

export interface WorkflowRunRecord {
  runId: string
  sessionId: string
  opportunityId?: string
  profileId?: string
  profileVersion?: number
  status: WorkflowStatus
  currentNode: string
  skillVersion: string
  checkpointVersion: number
  targetedResearchCount: number
  createdAt: string
  updatedAt: string
}

export interface HistoryRow {
  opportunityId: string
  company: string
  role: string
  screenedAt: string
  profileVersion: string
  workflowVersion: string
  verdict?: string
  decision?: string
  interviewStage?: string
  userNote: string
  noteUpdatedAt?: string
}

export type SourceKind = 'md' | 'txt' | 'pdf' | 'docx'

export interface FileSourceRecord {
  sourceId: string
  profileId?: string
  kind: SourceKind
  filename: string
  byteSize: number
  contentHash: string
  text: string
  createdAt: string
}

/** Five-dimension human eval rubric (E1). Each score is 1–5. */
export interface HumanEvalScores {
  personalization: number
  companyFactTrustworthiness: number
  recommendationReasoning: number
  unknownHonesty: number
  interviewQuestionSpecificity: number
}

export interface HumanEvalRecord {
  evalId: string
  caseName: string
  profileVersion: string
  workflowVersion: string
  scores: HumanEvalScores
  issues: string[]
  strengths: string[]
  conclusion: string
  createdAt: string
}
