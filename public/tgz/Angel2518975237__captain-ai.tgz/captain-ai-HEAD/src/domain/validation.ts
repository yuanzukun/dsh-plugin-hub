import type { ProfileContent } from './models.js'

export interface ValidationIssue {
  path: string
  code: 'missing' | 'invalid' | 'conflict'
  message: string
  critical: boolean
}

const isStringArray = (value: unknown): value is string[] =>
  Array.isArray(value) && value.every((item) => typeof item === 'string')

export function validateProfileContent(value: unknown): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return [{ path: '$', code: 'invalid', message: 'Profile 必须是对象。', critical: true }]
  }
  const record = value as Record<string, unknown>
  const arrays: Array<[keyof ProfileContent, boolean]> = [
    ['targetRoles', true], ['adjacentRoles', false], ['excludedRoles', false],
    ['locations', true], ['companyPreferences', false], ['excludedCompaniesOrIndustries', false],
    ['desiredResponsibilities', true], ['desiredDecisionRights', false],
    ['hardConstraints', true], ['unknowns', false], ['privacyRestrictions', false],
  ]
  for (const [key, critical] of arrays) {
    if (!isStringArray(record[key])) {
      issues.push({ path: `$.${key}`, code: 'invalid', message: `${key} 必须是字符串数组。`, critical })
    } else if (critical && (record[key] as string[]).length === 0) {
      issues.push({ path: `$.${key}`, code: 'missing', message: `${key} 至少需要一项。`, critical: true })
    }
  }
  // Optional string-array field: validated only when present (so older drafts
  // that predate the field stay valid).
  if (record.decisionPriorities !== undefined && !isStringArray(record.decisionPriorities)) {
    issues.push({ path: '$.decisionPriorities', code: 'invalid', message: 'decisionPriorities 必须是字符串数组。', critical: false })
  }
  if (!Array.isArray(record.strengths)) {
    issues.push({ path: '$.strengths', code: 'invalid', message: 'strengths 必须是能力与证据数组。', critical: true })
  } else {
    record.strengths.forEach((item, index) => {
      if (!item || typeof item !== 'object' || typeof (item as { capability?: unknown }).capability !== 'string' || typeof (item as { evidence?: unknown }).evidence !== 'string') {
        issues.push({ path: `$.strengths[${index}]`, code: 'invalid', message: '每项能力必须包含 capability 和 evidence。', critical: true })
      }
    })
    if (record.strengths.length === 0) issues.push({ path: '$.strengths', code: 'missing', message: '至少需要一项带证据的能力。', critical: true })
  }
  return issues
}

export function assertValidProfileContent(value: unknown): asserts value is ProfileContent {
  const issues = validateProfileContent(value)
  if (issues.length > 0) throw new Error(`INVALID_PROFILE: ${issues.map((item) => `${item.path} ${item.message}`).join('; ')}`)
}
