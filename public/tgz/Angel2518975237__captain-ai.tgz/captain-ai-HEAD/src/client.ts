import type { Context } from '@deepseek-ai/cordis'
import React from 'react'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'

import { CaptainApp } from './client/CaptainApp.js'
import { CaptainSidebarAction } from './client/CaptainSidebarAction.js'
import { captainUiState } from './client/state.js'
import { ensureCaptainStyles } from './client/styles.js'

export const name = 'captain-client'
export const inject = ['slots']

export function apply(ctx: Context): void {
  ctx.effect(ensureCaptainStyles, 'captain: styles')

  ctx.slots.inject('sidebar.footer.action', () =>
    ctx.slots.register(
      {
        name: 'sidebar.footer.action',
        id: 'captain-console',
        order: 20,
        label: 'Captain 控制台',
      },
      CaptainSidebarAction,
    ),
  )

  ctx.slots.inject('shell.overlay', () =>
    ctx.slots.register(
      {
        name: 'shell.overlay',
        id: 'captain-console-overlay',
        order: 20,
        inject: () => ({ ui: captainUiState }),
      },
      CaptainApp,
    ),
  )
}

export { CaptainApp, CaptainSidebarAction, captainUiState, React }
