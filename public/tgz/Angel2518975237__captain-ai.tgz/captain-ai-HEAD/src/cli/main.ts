import { readFileSync, writeFileSync } from 'node:fs'
import { basename, join } from 'node:path'

import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'

import { buildHistoryXlsx } from '../export/xlsx.js'
import { detectKind, parseFile } from '../files/parse.js'
import { CaptainStore } from '../store/service.js'

const USAGE = `Captain CLI — 复现、调试与 Eval 入口（与 Web 共用同一 Store/Workflow）

用法:
  captain history export <output.xlsx>    导出历史航程为 Excel
  captain run inspect <run_id>            查看一次运行
  captain profile template <output.md>    输出标准 Profile 模板
  captain profile import <file>           解析简历/偏好文件并保存为 Source（md/txt/pdf/docx）
  captain --help                          显示帮助
`

function openStore(): CaptainStore {
  const path = process.env.CAPTAIN_STORE_PATH ?? join(resolveDshHome(), 'storages', 'captain', 'captain.sqlite')
  return new CaptainStore(path)
}

export async function main(argv: string[]): Promise<number> {
  const [cmd, sub, ...rest] = argv
  try {
    if (!cmd || cmd === '--help' || cmd === '-h') {
      process.stdout.write(USAGE)
      return 0
    }
    if (cmd === 'history' && sub === 'export') return exportHistory(rest)
    if (cmd === 'run' && sub === 'inspect') return inspectRun(rest)
    if (cmd === 'profile' && sub === 'template') return writeTemplate(rest)
    if (cmd === 'profile' && sub === 'import') return await importProfile(rest)
    process.stderr.write(`unknown command: ${cmd} ${sub ?? ''}\n${USAGE}`)
    return 2
  } catch (error) {
    process.stderr.write(`captain: ${error instanceof Error ? error.message : String(error)}\n`)
    return 1
  }
}

function exportHistory(args: string[]): number {
  const output = args[0]
  if (!output) throw new Error('history export 需要 <output.xlsx>')
  const store = openStore()
  try {
    const rows = store.listHistory()
    writeFileSync(output, buildHistoryXlsx(rows))
    process.stdout.write(`exported ${rows.length} 条航程 -> ${output}\n`)
    return 0
  } finally {
    store.close()
  }
}

function inspectRun(args: string[]): number {
  const runId = args[0]
  if (!runId) throw new Error('run inspect 需要 <run_id>')
  const store = openStore()
  try {
    const run = store.getRun(runId)
    if (!run) throw new Error(`RUN_NOT_FOUND: ${runId}`)
    process.stdout.write(`${JSON.stringify(run, null, 2)}\n`)
    return 0
  } finally {
    store.close()
  }
}

function writeTemplate(args: string[]): number {
  const output = args[0]
  if (!output) throw new Error('profile template 需要 <output.md>')
  const template = readFileSync(new URL('../../assets/profile-template.md', import.meta.url), 'utf8')
  writeFileSync(output, template)
  process.stdout.write(`template -> ${output}\n`)
  return 0
}

async function importProfile(args: string[]): Promise<number> {
  const file = args[0]
  if (!file) throw new Error('profile import 需要 <file>')
  const buffer = readFileSync(file)
  const kind = detectKind(file)
  const text = await parseFile(kind, buffer)
  const store = openStore()
  try {
    const source = store.saveSource({ kind, filename: basename(file), text, byteSize: buffer.length })
    process.stdout.write(`${JSON.stringify(source, null, 2)}\n`)
    return 0
  } finally {
    store.close()
  }
}
