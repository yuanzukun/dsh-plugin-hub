import mammoth from 'mammoth'

import type { SourceKind } from '../domain/models.js'

export type { SourceKind } from '../domain/models.js'

const KIND_BY_EXT: Record<string, SourceKind> = { pdf: 'pdf', docx: 'docx', md: 'md', markdown: 'md' }

/** Map a filename to its source kind; unknown extensions fall back to `txt`. */
export function detectKind(filename: string): SourceKind {
  const ext = filename.toLowerCase().split('.').pop() ?? ''
  return KIND_BY_EXT[ext] ?? 'txt'
}

/** Extract plain text from a DOCX buffer. */
export async function parseDocx(buffer: Buffer): Promise<string> {
  const result = await mammoth.extractRawText({ buffer })
  return result.value
}

/** Extract plain text from a PDF buffer (pdfjs-dist legacy build, no worker). */
export async function parsePdf(buffer: Buffer): Promise<string> {
  const { getDocument } = await import('pdfjs-dist/legacy/build/pdf.mjs')
  const document = await getDocument({
    data: new Uint8Array(buffer),
    useWorkerFetch: false,
    isEvalSupported: false,
    useSystemFonts: true,
  }).promise
  const parts: string[] = []
  for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
    const page = await document.getPage(pageNumber)
    const content = await page.getTextContent()
    parts.push(content.items.map((item) => ('str' in item ? item.str : '')).join(' '))
  }
  await document.destroy()
  return parts.join('\n')
}

/**
 * Parse a raw source buffer into plain text. Markdown/TXT are returned
 * verbatim (their structure is preserved for the Profile parser).
 */
export async function parseFile(kind: SourceKind, buffer: Buffer): Promise<string> {
  switch (kind) {
    case 'pdf': return parsePdf(buffer)
    case 'docx': return parseDocx(buffer)
    case 'md':
    case 'txt': return buffer.toString('utf8')
  }
}
