import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-subagent'
import { defineTool } from '@deepseek-ai/dsh-tools'

import { createResearchPlan, validateResearchPlan } from '../research/planner.js'
import { ResearchOrchestrator, type SubagentRuntimeLike } from '../research/orchestrator.js'
import type { CaptainStore } from '../store/service.js'

/**
 * Register the Captain host tool that drives real multi-agent company research
 * (PRD S5). It is the runtime wiring over `ResearchOrchestrator`: the tool's
 * `execute` builds a bounded plan, fans out `ctx.subagents.start(...)` workers
 * scoped to `web_search`/`web_read`, returns the structured outcomes, and
 * advances the workflow run through the S/E nodes so the console sidebar
 * follows the real task in real time.
 */
export function registerCaptainTools(ctx: Context, store: CaptainStore): () => void {
  return ctx.tools.register(defineTool({
    name: 'captain_research',
    description: '针对一家公司和一个岗位，启动有界多智能体研究（1–4 个 worker，仅用 web_search/web_read），返回结构化证据草案。',
    parameters: {
      company: { type: 'string', required: true },
      role: { type: 'string', required: true },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          outcomes: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                taskId: { type: 'string', required: true },
                status: { type: 'string', required: true },
                structured: { type: 'json' },
                error: { type: 'string' },
              },
            },
          },
        },
      },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    timeoutMs: 180000,
    async execute(args, exec) {
      // Advance the run into the research phase (S4→S5) so the sidebar follows.
      const sessionId = String(exec.agent?.id ?? `research-${Date.now()}`)
      let run = store.startResearch(sessionId, args.company, args.role)
      const plan = createResearchPlan({ company: args.company, role: args.role })
      validateResearchPlan(plan)
      const orchestrator = new ResearchOrchestrator(ctx.subagents as unknown as SubagentRuntimeLike)
      const outcomes = await orchestrator.fanOut(plan, exec.agent, exec.signal)
      // Evidence done → independent review (S6). Later synthesis/eval nodes advance from here.
      run = store.finishResearchPhase(run, 'evidence_review', 'S6')
      return { outcomes, currentNode: run.currentNode }
    },
  }))
}
