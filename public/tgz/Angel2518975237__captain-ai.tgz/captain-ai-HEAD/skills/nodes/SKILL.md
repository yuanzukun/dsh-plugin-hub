---
name: captain-node-catalog
description: Inspect Captain workflow node prompts C0, P1-P5, S1-S10, E1-E2. Use when explaining, reviewing, testing, or changing one of Captain's workflow nodes.
---

# Captain Node Catalog

Treat every sibling `{node_id}.md` file as the authoritative prompt contract for
that node. Read only the node files needed for the current task. Preserve the
declared input/output schema, allowed tools, guardrails and exit conditions.

Never expose hidden chain-of-thought. A UI inspector may show the written Skill
instructions, structured inputs/outputs, tool events and policy decisions.
