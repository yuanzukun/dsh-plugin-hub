---
name: captain-node-schemas
description: Validate Captain node outputs against the shared JSON Schema. Use when implementing, testing, replaying, or diagnosing structured workflow outputs.
---

# Captain Node Schemas

Use `captain-node-outputs.schema.json` as the public structured-output contract.
Reject unknown node IDs, invalid discriminators, missing required properties and
cross-record references that the deterministic runtime cannot resolve.

Schema repair may be attempted once and must not invent user facts or Evidence.
