PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS profiles (
  profile_id TEXT NOT NULL,
  version INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft', 'confirmed', 'superseded')),
  schema_version TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  content_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  confirmed_at TEXT,
  PRIMARY KEY (profile_id, version)
);
CREATE UNIQUE INDEX IF NOT EXISTS one_confirmed_profile
  ON profiles(status) WHERE status = 'confirmed';

CREATE TABLE IF NOT EXISTS opportunities (
  opportunity_id TEXT PRIMARY KEY,
  company TEXT NOT NULL,
  role TEXT NOT NULL,
  screened_at TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  profile_version INTEGER NOT NULL,
  workflow_version TEXT NOT NULL,
  verdict TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(company, role, screened_at, profile_id, profile_version, workflow_version)
);

CREATE TABLE IF NOT EXISTS workflow_runs (
  run_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  opportunity_id TEXT,
  profile_id TEXT,
  profile_version INTEGER,
  status TEXT NOT NULL,
  current_node TEXT NOT NULL,
  skill_version TEXT NOT NULL,
  checkpoint_version INTEGER NOT NULL DEFAULT 0,
  targeted_research_count INTEGER NOT NULL DEFAULT 0 CHECK(targeted_research_count BETWEEN 0 AND 1),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(opportunity_id) REFERENCES opportunities(opportunity_id)
);

CREATE TABLE IF NOT EXISTS node_runs (
  node_run_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  node_id TEXT NOT NULL,
  attempt INTEGER NOT NULL,
  status TEXT NOT NULL,
  input_ref TEXT,
  output_ref TEXT,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  error_code TEXT,
  UNIQUE(run_id, node_id, attempt),
  FOREIGN KEY(run_id) REFERENCES workflow_runs(run_id)
);

CREATE TABLE IF NOT EXISTS checkpoints (
  run_id TEXT NOT NULL,
  version INTEGER NOT NULL,
  status TEXT NOT NULL,
  current_node TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(run_id, version),
  FOREIGN KEY(run_id) REFERENCES workflow_runs(run_id)
);

CREATE TABLE IF NOT EXISTS user_notes (
  note_id TEXT PRIMARY KEY,
  opportunity_id TEXT NOT NULL UNIQUE,
  text TEXT NOT NULL,
  interview_stage TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'user' CHECK(source = 'user'),
  FOREIGN KEY(opportunity_id) REFERENCES opportunities(opportunity_id)
);

CREATE TABLE IF NOT EXISTS user_decisions (
  decision_id TEXT PRIMARY KEY,
  opportunity_id TEXT NOT NULL,
  decision TEXT NOT NULL,
  reason TEXT,
  next_action TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(opportunity_id) REFERENCES opportunities(opportunity_id)
);
