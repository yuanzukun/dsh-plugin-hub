CREATE TABLE IF NOT EXISTS sources (
  source_id TEXT PRIMARY KEY,
  profile_id TEXT,
  kind TEXT NOT NULL CHECK (kind IN ('md', 'txt', 'pdf', 'docx')),
  filename TEXT NOT NULL,
  byte_size INTEGER NOT NULL,
  content_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'private' CHECK (status = 'private'),
  text_content TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS sources_profile_idx ON sources(profile_id);
