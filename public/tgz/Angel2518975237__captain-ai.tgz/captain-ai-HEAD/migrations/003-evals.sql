CREATE TABLE IF NOT EXISTS evals (
  eval_id TEXT PRIMARY KEY,
  case_name TEXT NOT NULL,
  profile_version TEXT NOT NULL,
  workflow_version TEXT NOT NULL,
  scores_json TEXT NOT NULL,
  issues_json TEXT NOT NULL,
  strengths_json TEXT NOT NULL,
  conclusion TEXT NOT NULL,
  created_at TEXT NOT NULL
);
