import { createReadStream } from 'node:fs'
import { link, lstat, mkdir, open, readdir, stat, unlink } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, extname, join, resolve } from 'node:path'
import { randomUUID } from 'node:crypto'

export const name = 'dsh-upload-manager'
export const inject = ['webServer']

export const API_PATH = '/api/dsh-uploads'
export const DOWNLOAD_PATH = '/api/dsh-uploads/download'
export const DEFAULT_MAX_FILE_BYTES = 100 * 1024 * 1024
export const DEFAULT_TOTAL_MAX_BYTES = 1024 * 1024 * 1024

class HttpError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
  }
}

export function resolveUploadRoot(env = process.env) {
  const dshHome = env.DSH_HOME?.trim() || join(homedir(), '.dsh')
  return resolve(env.DSH_UPLOAD_DIR?.trim() || join(dshHome, 'uploads'))
}

function positiveInteger(value, fallback) {
  const configured = Number(value)
  return Number.isSafeInteger(configured) && configured > 0 ? configured : fallback
}

export function resolveMaxFileBytes(env = process.env) {
  return positiveInteger(env.DSH_UPLOAD_MAX_BYTES, DEFAULT_MAX_FILE_BYTES)
}

export function resolveTotalMaxBytes(env = process.env) {
  return positiveInteger(env.DSH_UPLOAD_TOTAL_MAX_BYTES, DEFAULT_TOTAL_MAX_BYTES)
}

export function sanitizeUploadName(value) {
  const decoded = String(value || '').normalize('NFC')
  let safe = basename(decoded)
    .replace(/[\\/\u0000-\u001f\u007f]/g, '_')
    .replace(/^\.+/, '')
    .trim()

  if (!safe) safe = 'upload.bin'
  if (safe.startsWith('.upload-')) safe = `file-${safe}`

  if (safe.length > 180) {
    const extension = extname(safe).slice(0, 24)
    const stem = safe.slice(0, Math.max(1, 180 - extension.length))
    safe = `${stem}${extension}`
  }
  return safe
}

export function isSafeStoredName(value) {
  return typeof value === 'string'
    && value.length > 0
    && value.length <= 180
    && value === basename(value)
    && value !== '.'
    && value !== '..'
    && !value.startsWith('.upload-')
    && !/[\\/\u0000-\u001f\u007f]/.test(value)
}

function requestUrl(req) {
  return new URL(req.url || '/', 'http://dsh.internal')
}

function queryName(req) {
  const value = requestUrl(req).searchParams.get('name')
  if (!isSafeStoredName(value)) throw new HttpError(400, 'invalid file name')
  return value
}

function uploadHeaderName(req) {
  const value = header(req.headers, 'x-file-name')
  if (value === undefined || value.length === 0) {
    throw new HttpError(400, 'x-file-name header is required')
  }
  try {
    return sanitizeUploadName(decodeURIComponent(value))
  } catch {
    throw new HttpError(400, 'x-file-name must be URI encoded UTF-8')
  }
}

function header(headers, key) {
  const value = headers[key]
  return typeof value === 'string' ? value : undefined
}

function parseAuthority(authority) {
  try {
    return new URL(`http://${authority}`)
  } catch {
    return undefined
  }
}

function canonicalAuthority(entry, entryUrl) {
  const port = entryUrl.port !== '' ? entryUrl.port : new URL(`https://${entry}`).port
  return port === '' ? entryUrl.hostname : `${entryUrl.hostname}:${port}`
}

function assertTrustedAuthority(entry) {
  const entryUrl = parseAuthority(entry)
  if (entryUrl !== undefined && canonicalAuthority(entry, entryUrl) === entry.toLowerCase()) return
  throw new Error(`dsh-upload-manager: trusted host ${JSON.stringify(entry)} is not a bare host[:port] authority`)
}

function isLoopbackHostname(hostname) {
  if (hostname === 'localhost' || hostname === '[::1]') return true
  const parts = hostname.split('.')
  return parts.length === 4
    && parts[0] === '127'
    && parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) <= 255)
}

function isTrustedAuthority(hostUrl, trustedHosts) {
  return trustedHosts.some((entry) => {
    const entryUrl = parseAuthority(entry)
    if (entryUrl === undefined) return false
    return canonicalAuthority(entry, entryUrl) === entryUrl.hostname
      ? entryUrl.hostname === hostUrl.hostname
      : entryUrl.host === hostUrl.host
  })
}

export function isTrustedUploadRequest(req, trustedHosts = []) {
  const host = header(req.headers, 'host')
  if (host === undefined) return false
  const hostUrl = parseAuthority(host)
  if (hostUrl === undefined) return false
  if (!isLoopbackHostname(hostUrl.hostname) && !isTrustedAuthority(hostUrl, trustedHosts)) return false
  if (header(req.headers, 'sec-fetch-site') === 'cross-site') return false

  const origin = header(req.headers, 'origin')
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}

function sendJson(res, status, value) {
  const body = JSON.stringify(value)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  })
  res.end(body)
}

function sendError(res, error, onError) {
  if (error instanceof HttpError) {
    sendJson(res, error.status, { error: error.message })
    return
  }
  onError?.(error)
  sendJson(res, 500, { error: 'internal server error' })
}

function methodNotAllowed(res, methods) {
  res.writeHead(405, { allow: methods.join(', '), 'content-length': 0 })
  res.end()
}

async function writeRequestToFile(req, target, maxBytes, limitStatus, limitMessage) {
  const declared = Number(header(req.headers, 'content-length'))
  if (Number.isFinite(declared) && declared > maxBytes) {
    req.resume()
    throw new HttpError(limitStatus, limitMessage)
  }

  const handle = await open(target, 'wx', 0o600)
  let bytes = 0
  try {
    for await (const chunk of req) {
      bytes += chunk.length
      if (bytes > maxBytes) {
        req.resume()
        throw new HttpError(limitStatus, limitMessage)
      }
      await handle.write(chunk)
    }
    await handle.sync()
    return bytes
  } finally {
    await handle.close()
  }
}

function numberedName(name, index) {
  if (index === 0) return name
  const extension = extname(name).slice(0, 24)
  const stem = name.slice(0, name.length - extname(name).length)
  const suffix = ` (${index})`
  const maxStemLength = Math.max(1, 180 - extension.length - suffix.length)
  return `${stem.slice(0, maxStemLength)}${suffix}${extension}`
}

async function publishUnique(tempPath, root, requestedName) {
  for (let index = 0; index < 10_000; index += 1) {
    const name = numberedName(requestedName, index)
    const target = join(root, name)
    try {
      await link(tempPath, target)
      await unlink(tempPath)
      return { name, path: target }
    } catch (error) {
      if (error?.code === 'EEXIST') continue
      throw error
    }
  }
  throw new HttpError(409, 'too many files share this name')
}

function fileRecord(root, name, info) {
  return {
    name,
    path: join(root, name),
    size: info.size,
    modifiedAt: info.mtime.toISOString(),
  }
}

export async function listUploadedFiles(root) {
  await mkdir(root, { recursive: true, mode: 0o700 })
  const entries = await readdir(root, { withFileTypes: true })
  const files = []
  for (const entry of entries) {
    if (!entry.isFile() || entry.name.startsWith('.upload-')) continue
    try {
      const info = await stat(join(root, entry.name))
      files.push(fileRecord(root, entry.name, info))
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
  }
  files.sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt) || a.name.localeCompare(b.name))
  return files
}

export async function sweepUploadTemps(root) {
  await mkdir(root, { recursive: true, mode: 0o700 })
  const entries = await readdir(root, { withFileTypes: true })
  let removed = 0
  for (const entry of entries) {
    if (!entry.name.startsWith('.upload-')) continue
    try {
      await unlink(join(root, entry.name))
      removed += 1
    } catch (error) {
      if (error?.code !== 'ENOENT' && error?.code !== 'EISDIR' && error?.code !== 'EPERM') throw error
    }
  }
  return removed
}

async function requireRegularFile(root, name) {
  const target = join(root, name)
  let info
  try {
    info = await lstat(target)
  } catch (error) {
    if (error?.code === 'ENOENT') throw new HttpError(404, 'file not found')
    throw error
  }
  if (!info.isFile()) throw new HttpError(400, 'not a regular file')
  return { target, info }
}

function asciiDownloadName(name) {
  const value = name.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_')
  return value || 'download'
}

export function contentDisposition(name) {
  return `attachment; filename="${asciiDownloadName(name)}"; filename*=UTF-8''${encodeURIComponent(name)}`
}

function contentType(name) {
  const extension = extname(name).toLowerCase()
  return ({
    '.txt': 'text/plain; charset=utf-8',
    '.md': 'text/markdown; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.pdf': 'application/pdf',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.zip': 'application/zip',
  })[extension] || 'application/octet-stream'
}

export function createHandlers(options = {}) {
  const root = resolve(options.root || resolveUploadRoot())
  const maxFileBytes = positiveInteger(options.maxFileBytes, resolveMaxFileBytes())
  const totalMaxBytes = positiveInteger(options.totalMaxBytes, resolveTotalMaxBytes())
  const trustedHosts = Array.isArray(options.trustedHosts) ? [...options.trustedHosts] : []
  const onError = typeof options.onError === 'function' ? options.onError : undefined
  for (const entry of trustedHosts) assertTrustedAuthority(entry)

  let mutationTail = Promise.resolve()
  const enqueueMutation = (operation) => {
    const current = mutationTail.then(operation, operation)
    mutationTail = current.catch(() => {})
    return current
  }

  const requireTrusted = (req) => {
    if (!isTrustedUploadRequest(req, trustedHosts)) throw new HttpError(403, 'forbidden')
  }

  const api = async (req, res) => {
    try {
      requireTrusted(req)

      if (req.method === 'GET' || req.method === 'HEAD') {
        const files = await listUploadedFiles(root)
        const usedBytes = files.reduce((sum, file) => sum + file.size, 0)
        if (req.method === 'HEAD') {
          res.writeHead(200, { 'cache-control': 'no-store', 'content-length': 0 })
          res.end()
          return
        }
        sendJson(res, 200, { root, maxFileBytes, totalMaxBytes, usedBytes, files })
        return
      }

      if (req.method === 'POST') {
        await enqueueMutation(async () => {
          await mkdir(root, { recursive: true, mode: 0o700 })
          const requestedName = uploadHeaderName(req)
          const declared = Number(header(req.headers, 'content-length'))
          if (Number.isFinite(declared) && declared > maxFileBytes) {
            req.resume()
            throw new HttpError(413, `file exceeds ${maxFileBytes} bytes`)
          }

          const files = await listUploadedFiles(root)
          const usedBytes = files.reduce((sum, file) => sum + file.size, 0)
          const remainingBytes = totalMaxBytes - usedBytes
          if (remainingBytes <= 0) {
            req.resume()
            throw new HttpError(507, 'upload storage quota exceeded')
          }

          const allowedBytes = Math.min(maxFileBytes, remainingBytes)
          const quotaLimited = allowedBytes < maxFileBytes
          const tempPath = join(root, `.upload-${randomUUID()}.tmp`)
          try {
            const size = await writeRequestToFile(
              req,
              tempPath,
              allowedBytes,
              quotaLimited ? 507 : 413,
              quotaLimited ? 'upload storage quota exceeded' : `file exceeds ${maxFileBytes} bytes`,
            )
            const published = await publishUnique(tempPath, root, requestedName)
            const info = await stat(published.path)
            sendJson(res, 201, {
              root,
              file: fileRecord(root, published.name, { size, mtime: info.mtime }),
            })
          } finally {
            await unlink(tempPath).catch(() => {})
          }
        })
        return
      }

      if (req.method === 'DELETE') {
        await enqueueMutation(async () => {
          const fileName = queryName(req)
          const { target } = await requireRegularFile(root, fileName)
          await unlink(target)
          sendJson(res, 200, { deleted: fileName })
        })
        return
      }

      methodNotAllowed(res, ['GET', 'HEAD', 'POST', 'DELETE'])
    } catch (error) {
      sendError(res, error, onError)
    }
  }

  const download = async (req, res) => {
    try {
      requireTrusted(req)
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        methodNotAllowed(res, ['GET', 'HEAD'])
        return
      }
      const fileName = queryName(req)
      const { target, info } = await requireRegularFile(root, fileName)
      res.writeHead(200, {
        'content-type': contentType(fileName),
        'content-length': info.size,
        'content-disposition': contentDisposition(fileName),
        'cache-control': 'private, no-store',
        'x-content-type-options': 'nosniff',
      })
      if (req.method === 'HEAD') {
        res.end()
        return
      }
      const stream = createReadStream(target)
      stream.on('error', (error) => res.destroy(error))
      stream.pipe(res)
    } catch (error) {
      sendError(res, error, onError)
    }
  }

  return { root, maxFileBytes, totalMaxBytes, api, download }
}

export async function apply(ctx, config = {}) {
  const handlers = createHandlers({
    trustedHosts: config.trustedHosts,
    onError: (error) => ctx.logger.error(error instanceof Error ? error : new Error(String(error))),
  })
  await sweepUploadTemps(handlers.root)

  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: API_PATH,
    handler: handlers.api,
  }), 'dsh-upload-manager: upload/list/delete route')

  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: DOWNLOAD_PATH,
    handler: handlers.download,
  }), 'dsh-upload-manager: download route')
}
