# Changelog

All notable changes to this project are documented in this file.

## [1.0.0] - 2026-08-14

### Added

- Arbitrary local-file upload control in the DeepSeek Harness Web composer.
- Image-like pending file cards above the composer without visible draft text.
- Hidden input-reference serialization that adds stored file paths only at submission time.
- Failed-send restoration and successful-send cleanup for pending files.
- Fixed upload directory with configurable per-file and total quotas.
- Settings page file list with download and delete actions.
- Host/Origin trust checks aligned with the built-in Harness Web API.
- Atomic unique-name publication and startup cleanup of interrupted temporary uploads.
