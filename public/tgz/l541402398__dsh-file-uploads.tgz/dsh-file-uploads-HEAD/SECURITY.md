# Security Policy

## Supported versions

Security fixes are applied to the latest release.

## Reporting a vulnerability

Please do not open a public issue for an undisclosed vulnerability. Use GitHub's **Report a vulnerability** private reporting feature on this repository. Include reproduction steps, affected routes or files, expected impact, and any proposed mitigation.

The plugin intentionally follows the DeepSeek Harness Web trusted-host and Origin fence. It does not implement independent user authentication; public deployments should protect the entire Harness Web service with an authenticated reverse proxy.
