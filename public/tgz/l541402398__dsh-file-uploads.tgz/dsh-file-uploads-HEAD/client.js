window.__ModuleLoader__.load({
  id: 'dsh-file-uploads',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const React = require('react')
    const API_PATH = '/api/dsh-uploads'
    const DOWNLOAD_PATH = '/api/dsh-uploads/download'
    const SOURCE = 'local-upload-files'
    const HIDDEN_LABEL = '__dsh_upload_hidden__:'

    function errorMessage(error) {
      return error instanceof Error ? error.message : String(error)
    }

    async function responseJson(response) {
      const body = await response.json().catch(() => ({}))
      if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`)
      return body
    }

    async function uploadFile(file) {
      const response = await fetch(API_PATH, {
        method: 'POST',
        headers: {
          'content-type': 'application/octet-stream',
          'x-file-name': encodeURIComponent(file.name),
        },
        body: file,
      })
      return (await responseJson(response)).file
    }

    function downloadUrl(name) {
      return `${DOWNLOAD_PATH}?name=${encodeURIComponent(name)}`
    }

    function modelLine(file) {
      return `上传文件：\`${file.path}\``
    }

    function serializedFile(file) {
      return `\n${modelLine(file)}`
    }

    function stripSerializedFiles(draft, files) {
      const lines = new Set(files.map(modelLine))
      return String(draft || '')
        .split('\n')
        .filter((line) => !lines.has(line.trim()))
        .join('\n')
        .replace(/^\n+|\n+$/g, '')
    }

    function legacyUploadPaths(draft) {
      const paths = []
      for (const line of String(draft || '').split('\n')) {
        const match = line.trim().match(/^上传文件：\s*`([^`]+)`$/)
        if (match) paths.push(match[1])
      }
      return paths
    }

    function stripLegacyPaths(draft, paths) {
      const remove = new Set(paths)
      return String(draft || '')
        .split('\n')
        .filter((line) => {
          const match = line.trim().match(/^上传文件：\s*`([^`]+)`$/)
          return !match || !remove.has(match[1])
        })
        .join('\n')
        .replace(/^\n+|\n+$/g, '')
    }

    class FileDraftController {
      constructor(ctx) {
        this.ctx = ctx
        this.pending = new Map()
        this.inFlight = new Map()
        this.refIndex = new Map()
        this.listeners = new Map()
        this.expiry = new Map()
        this.serializing = new Set()
        this.migrated = new Set()
        this.counter = 0
      }

      pendingFor(sessionId) {
        return this.pending.get(String(sessionId)) || []
      }

      subscribe(sessionId, listener) {
        const key = String(sessionId)
        let set = this.listeners.get(key)
        if (!set) {
          set = new Set()
          this.listeners.set(key, set)
        }
        set.add(listener)
        return () => {
          set.delete(listener)
          if (set.size === 0) this.listeners.delete(key)
        }
      }

      publish(sessionId) {
        const set = this.listeners.get(String(sessionId))
        if (!set) return
        for (const listener of set) listener()
      }

      scope(sessionId) {
        const actx = this.ctx.sessions.scope(sessionId)
        if (!actx) throw new Error('当前会话尚未就绪')
        return { actx, shell: this.ctx.conversation.input.for(actx) }
      }

      insertReference(sessionId, entry) {
        const { actx, shell } = this.scope(sessionId)
        const input = shell.snapshot
        if (!input || input.phase !== 'plain') return false
        return actx.bail(actx, 'slash/input-insert-reference', {
          reference: {
            source: SOURCE,
            ref: entry.ref,
            label: `${HIDDEN_LABEL}${entry.ref}`,
            clipboardText: '',
          },
          span: {
            start: input.draft.length,
            end: input.draft.length,
            draftRev: input.draftRev,
          },
        }) === true
      }

      attach(sessionId, file) {
        const key = String(sessionId)
        this.clearInFlight(key)
        const entry = { ...file, ref: `${key}-${++this.counter}` }
        if (!this.insertReference(sessionId, entry)) {
          throw new Error('输入框正忙，请稍后重新选择该文件')
        }
        const next = [...this.pendingFor(key), entry]
        this.pending.set(key, next)
        this.refIndex.set(entry.ref, { sessionId: key, entry })
        this.publish(key)
        return entry
      }

      remove(sessionId, ref) {
        const key = String(sessionId)
        const entries = this.pendingFor(key)
        const entry = entries.find((item) => item.ref === ref)
        if (!entry) return
        const { shell } = this.scope(sessionId)
        const input = shell.snapshot
        const occurrence = input.occurrences.find((item) => item.source === SOURCE && item.ref === ref)
        if (occurrence) {
          shell.setDraft(input.draft.slice(0, occurrence.offset) + input.draft.slice(occurrence.offset + 1))
        }
        const next = entries.filter((item) => item.ref !== ref)
        if (next.length > 0) this.pending.set(key, next)
        else this.pending.delete(key)
        this.refIndex.delete(ref)
        this.publish(key)
      }

      fileForRef(ref) {
        return this.refIndex.get(ref)?.entry
      }

      markSerializing(ref) {
        const record = this.refIndex.get(ref)
        if (record) this.serializing.add(record.sessionId)
      }

      reconcile(sessionId, occurrences) {
        const key = String(sessionId)
        const entries = this.pendingFor(key)
        if (entries.length === 0) return
        const refs = new Set(
          (occurrences || [])
            .filter((item) => item.source === SOURCE)
            .map((item) => item.ref),
        )
        const missing = entries.filter((entry) => !refs.has(entry.ref))
        if (missing.length === 0) return

        if (this.serializing.delete(key)) {
          this.pending.delete(key)
          this.inFlight.set(key, entries)
          const previous = this.expiry.get(key)
          if (previous) previous()
          this.expiry.set(key, this.ctx.timeout(() => this.clearInFlight(key), 30_000))
          this.publish(key)
          return
        }

        for (const entry of missing) this.refIndex.delete(entry.ref)
        const next = entries.filter((entry) => refs.has(entry.ref))
        if (next.length > 0) this.pending.set(key, next)
        else this.pending.delete(key)
        this.publish(key)
      }

      restoreFailed(sessionId) {
        const key = String(sessionId)
        const entries = this.inFlight.get(key)
        if (!entries || entries.length === 0) return
        const expiry = this.expiry.get(key)
        if (expiry) expiry()
        this.expiry.delete(key)
        this.inFlight.delete(key)

        const { shell } = this.scope(sessionId)
        const cleaned = stripSerializedFiles(shell.snapshot.draft, entries)
        shell.setDraft(cleaned)

        const restored = []
        for (const entry of entries) {
          if (this.insertReference(sessionId, entry)) restored.push(entry)
          else this.refIndex.delete(entry.ref)
        }
        if (restored.length > 0) this.pending.set(key, restored)
        this.publish(key)
      }

      clearInFlight(sessionId) {
        const key = String(sessionId)
        const expiry = this.expiry.get(key)
        if (expiry) expiry()
        this.expiry.delete(key)
        const entries = this.inFlight.get(key) || []
        for (const entry of entries) this.refIndex.delete(entry.ref)
        this.inFlight.delete(key)
      }

      async migrateLegacy(sessionId, draft) {
        const key = String(sessionId)
        if (this.migrated.has(key)) return
        this.migrated.add(key)
        const paths = legacyUploadPaths(draft)
        if (paths.length === 0) return

        try {
          const body = await responseJson(await fetch(API_PATH, { cache: 'no-store' }))
          const wanted = new Set(paths)
          const files = body.files.filter((file) => wanted.has(file.path))
          if (files.length === 0) return
          const { shell } = this.scope(sessionId)
          shell.setDraft(stripLegacyPaths(shell.snapshot.draft, files.map((file) => file.path)))
          for (const file of files) this.attach(sessionId, file)
        } catch (error) {
          console.error('[dsh-upload-manager] legacy draft migration failed', error)
        }
      }

      dispose() {
        for (const cancel of this.expiry.values()) cancel()
        this.expiry.clear()
        this.pending.clear()
        this.inFlight.clear()
        this.refIndex.clear()
        this.listeners.clear()
        this.serializing.clear()
        this.migrated.clear()
      }
    }

    function usePending(controller, sessionId) {
      const [, render] = React.useState(0)
      React.useEffect(
        () => controller.subscribe(sessionId, () => render((value) => value + 1)),
        [controller, sessionId],
      )
      return controller.pendingFor(sessionId)
    }

    function UploadControl(props) {
      const input = props.useInput((state) => state) || props.input
      const pickerRef = React.useRef(null)
      const [busy, setBusy] = React.useState(false)
      const [status, setStatus] = React.useState('')

      async function onPick(event) {
        const files = Array.from(event.currentTarget.files || [])
        event.currentTarget.value = ''
        if (files.length === 0) return

        setBusy(true)
        setStatus(`正在上传 ${files.length} 个文件…`)
        let attached = 0
        const failures = []
        try {
          for (const file of files) {
            try {
              const stored = await uploadFile(file)
              props.controller.attach(props.sessionId, stored)
              attached += 1
            } catch (error) {
              failures.push(`${file.name}: ${errorMessage(error)}`)
            }
          }
          setStatus(failures.length === 0
            ? `已添加 ${attached} 个待发送文件`
            : `已添加 ${attached} 个，失败 ${failures.length} 个：${failures.join('；')}`)
        } finally {
          setBusy(false)
        }
      }

      const disabled = busy || !input || input.phase !== 'plain'
      return React.createElement(
        'div',
        { className: 'dsh-upload-control', title: status || '上传本地文件并加入本次消息' },
        React.createElement('input', {
          ref: pickerRef,
          className: 'dsh-upload-picker',
          type: 'file',
          multiple: true,
          onChange: onPick,
        }),
        React.createElement(
          'button',
          {
            type: 'button',
            className: 'dsh-upload-button',
            disabled,
            'aria-label': busy ? '正在上传文件' : '上传文件',
            onClick: () => pickerRef.current?.click(),
          },
          React.createElement('span', { className: 'dsh-upload-icon', 'aria-hidden': true }, busy ? '…' : '↑'),
          React.createElement('span', null, busy ? '上传中' : '文件'),
        ),
        React.createElement('span', { className: 'dsh-upload-live', 'aria-live': 'polite' }, status),
      )
    }

    function PendingFileRail(props) {
      const input = props.useInput((state) => state)
      const promptError = props.useSession((session) => session.promptError) || null
      const files = usePending(props.controller, props.sessionId)

      React.useEffect(() => {
        props.controller.migrateLegacy(props.sessionId, input?.draft || '')
        props.controller.reconcile(props.sessionId, input?.occurrences || [])
      }, [props.controller, props.sessionId, input?.draftRev])

      React.useEffect(() => {
        if (promptError) props.controller.restoreFailed(props.sessionId)
      }, [props.controller, props.sessionId, promptError])

      if (files.length === 0) return null
      return React.createElement(
        'div',
        { className: 'dsh-upload-rail', 'aria-label': '待发送文件' },
        files.map((file) => React.createElement(
          'div',
          { className: 'dsh-upload-chip', key: file.ref },
          React.createElement('span', { className: 'dsh-upload-chip-icon', 'aria-hidden': true }, '▤'),
          React.createElement(
            'span',
            { className: 'dsh-upload-chip-copy' },
            React.createElement('strong', { title: file.name }, file.name),
            React.createElement('small', null, sizeText(file.size)),
          ),
          React.createElement(
            'button',
            {
              type: 'button',
              'aria-label': `移除 ${file.name}`,
              title: '从本次消息移除',
              onClick: () => props.controller.remove(props.sessionId, file.ref),
            },
            '×',
          ),
        )),
      )
    }

    function sizeText(bytes) {
      if (bytes < 1024) return `${bytes} B`
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`
      if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MiB`
      return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GiB`
    }

    function dateText(value) {
      try {
        return new Intl.DateTimeFormat('zh-CN', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
        }).format(new Date(value))
      } catch {
        return value
      }
    }

    function UploadSettingsSection() {
      const [state, setState] = React.useState({
        loading: true,
        root: '',
        maxFileBytes: 0,
        totalMaxBytes: 0,
        usedBytes: 0,
        files: [],
        error: '',
      })
      const [deleting, setDeleting] = React.useState('')

      async function refresh() {
        setState((current) => ({ ...current, loading: true, error: '' }))
        try {
          const response = await fetch(API_PATH, { cache: 'no-store' })
          const body = await responseJson(response)
          setState({
            loading: false,
            root: body.root,
            maxFileBytes: body.maxFileBytes,
            totalMaxBytes: body.totalMaxBytes,
            usedBytes: body.usedBytes,
            files: body.files,
            error: '',
          })
        } catch (error) {
          setState((current) => ({ ...current, loading: false, error: errorMessage(error) }))
        }
      }

      React.useEffect(() => {
        refresh()
      }, [])

      async function remove(name) {
        if (!globalThis.confirm(`确定删除“${name}”吗？此操作不可恢复。`)) return
        setDeleting(name)
        try {
          const response = await fetch(`${API_PATH}?name=${encodeURIComponent(name)}`, { method: 'DELETE' })
          await responseJson(response)
          await refresh()
        } catch (error) {
          setState((current) => ({ ...current, error: errorMessage(error) }))
        } finally {
          setDeleting('')
        }
      }

      return React.createElement(
        'section',
        { className: 'dsh-upload-settings' },
        React.createElement(
          'div',
          { className: 'dsh-upload-settings-head' },
          React.createElement(
            'div',
            null,
            React.createElement('h2', null, '上传文件'),
            React.createElement('p', null, '管理从输入框上传到 Harness 容器中的文件。'),
          ),
          React.createElement(
            'button',
            { type: 'button', className: 'dsh-upload-refresh', disabled: state.loading, onClick: refresh },
            state.loading ? '刷新中…' : '刷新',
          ),
        ),
        React.createElement(
          'div',
          { className: 'dsh-upload-root' },
          React.createElement('span', null, '固定目录'),
          React.createElement('code', null, state.root || '读取中…'),
          state.maxFileBytes
            ? React.createElement('small', null, `单文件上限 ${sizeText(state.maxFileBytes)}`)
            : null,
          state.totalMaxBytes
            ? React.createElement('small', null, `已使用 ${sizeText(state.usedBytes)} / ${sizeText(state.totalMaxBytes)}`)
            : null,
        ),
        state.error ? React.createElement('div', { className: 'dsh-upload-error' }, state.error) : null,
        !state.loading && state.files.length === 0
          ? React.createElement('div', { className: 'dsh-upload-empty' }, '当前没有已上传文件。')
          : null,
        React.createElement(
          'div',
          { className: 'dsh-upload-list' },
          state.files.map((file) => React.createElement(
            'div',
            { className: 'dsh-upload-row', key: file.name },
            React.createElement(
              'div',
              { className: 'dsh-upload-file-info' },
              React.createElement('strong', { title: file.name }, file.name),
              React.createElement('span', null, `${sizeText(file.size)} · ${dateText(file.modifiedAt)}`),
              React.createElement('code', { title: file.path }, file.path),
            ),
            React.createElement(
              'div',
              { className: 'dsh-upload-actions' },
              React.createElement('a', { href: downloadUrl(file.name), download: file.name }, '下载'),
              React.createElement(
                'button',
                { type: 'button', disabled: deleting === file.name, onClick: () => remove(file.name) },
                deleting === file.name ? '删除中…' : '删除',
              ),
            ),
          )),
        ),
      )
    }

    const CSS = `
      [data-decoration="chip"][title^="${HIDDEN_LABEL}"]{display:none!important}
      .dsh-upload-control{display:flex;align-items:center;min-width:0}
      .dsh-upload-picker,.dsh-upload-live{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
      .dsh-upload-button{height:28px;border:0;border-radius:14px;padding:0 9px;display:inline-flex;align-items:center;gap:4px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;cursor:pointer}
      .dsh-upload-button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
      .dsh-upload-button:disabled{opacity:.55;cursor:wait}
      .dsh-upload-icon{font-size:15px;line-height:1;font-weight:600}
      .dsh-upload-rail{box-sizing:border-box;width:100%;max-width:var(--dsh-composer-card-max-width);margin:0 auto 6px;padding:0 var(--dsh-composer-side-clearance);display:flex;gap:8px;overflow-x:auto;scrollbar-width:none}
      .dsh-upload-rail::-webkit-scrollbar{display:none}
      .dsh-upload-chip{min-width:180px;max-width:260px;height:54px;box-sizing:border-box;display:flex;align-items:center;gap:9px;padding:8px 8px 8px 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;background:var(--dsw-specific-input-major);box-shadow:var(--dsw-shadow-lv1);color:var(--dsw-alias-label-primary)}
      .dsh-upload-chip-icon{width:28px;height:28px;display:grid;place-items:center;flex:none;border-radius:8px;background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary);font-size:16px}
      .dsh-upload-chip-copy{display:flex;flex-direction:column;min-width:0;flex:1}
      .dsh-upload-chip-copy strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;line-height:18px}
      .dsh-upload-chip-copy small{color:var(--dsw-alias-label-secondary);font-size:10px;line-height:14px}
      .dsh-upload-chip>button{width:24px;height:24px;border:0;border-radius:50%;background:transparent;color:var(--dsw-alias-label-secondary);font-size:18px;line-height:20px;cursor:pointer;flex:none}
      .dsh-upload-chip>button:hover{background:var(--dsw-alias-interactive-bg-hover-danger);color:var(--dsw-alias-state-error-primary)}
      .dsh-upload-settings{display:flex;flex-direction:column;gap:16px;min-width:0;padding:4px 2px 24px;color:var(--dsw-alias-label-primary)}
      .dsh-upload-settings-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px}
      .dsh-upload-settings h2{margin:0;font-size:20px;line-height:28px}
      .dsh-upload-settings p{margin:4px 0 0;color:var(--dsw-alias-label-secondary);font-size:13px;line-height:20px}
      .dsh-upload-refresh,.dsh-upload-actions button,.dsh-upload-actions a{border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:transparent;color:var(--dsw-alias-label-primary);padding:6px 11px;font:inherit;font-size:12px;line-height:18px;text-decoration:none;cursor:pointer}
      .dsh-upload-refresh:hover:not(:disabled),.dsh-upload-actions button:hover:not(:disabled),.dsh-upload-actions a:hover{background:var(--dsw-alias-interactive-bg-hover)}
      .dsh-upload-root{display:grid;grid-template-columns:auto minmax(0,1fr);gap:5px 12px;align-items:center;padding:12px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;background:var(--dsw-specific-input-major)}
      .dsh-upload-root span{font-size:12px;color:var(--dsw-alias-label-secondary)}
      .dsh-upload-root code{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px}
      .dsh-upload-root small{grid-column:2;color:var(--dsw-alias-label-secondary)}
      .dsh-upload-error{padding:10px 12px;border-radius:8px;background:var(--dsw-alias-interactive-bg-hover-danger);color:var(--dsw-alias-state-error-primary);font-size:12px}
      .dsh-upload-empty{padding:24px;text-align:center;color:var(--dsw-alias-label-secondary);border:1px dashed var(--dsw-alias-border-l2);border-radius:10px}
      .dsh-upload-list{display:flex;flex-direction:column;border-top:1px solid var(--dsw-alias-border-l2)}
      .dsh-upload-row{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:12px 2px;border-bottom:1px solid var(--dsw-alias-border-l2)}
      .dsh-upload-file-info{display:flex;flex-direction:column;min-width:0;gap:2px}
      .dsh-upload-file-info strong,.dsh-upload-file-info code{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .dsh-upload-file-info strong{font-size:13px}
      .dsh-upload-file-info span,.dsh-upload-file-info code{font-size:11px;color:var(--dsw-alias-label-secondary)}
      .dsh-upload-actions{display:flex;flex:none;gap:7px}
      .dsh-upload-actions button{color:var(--dsw-alias-state-error-primary)}
      @media (max-width:640px){.dsh-upload-row{align-items:flex-start;flex-direction:column}.dsh-upload-actions{width:100%}.dsh-upload-actions a,.dsh-upload-actions button{flex:1;text-align:center}.dsh-upload-chip{min-width:160px}}
    `

    const inject = ['slots', 'sessions', 'inputTriggers', 'conversation', 'timer']

    function apply(ctx) {
      const controller = new FileDraftController(ctx)
      ctx.effect(() => () => controller.dispose(), 'dsh-upload-manager: draft-file state')
      ctx.effect(() => ctx.inputTriggers.registerSource({
        trigger: '@',
        name: SOURCE,
        order: 10_000,
        candidates: async () => [],
        onPick: () => undefined,
        codec: {
          clipboardText: () => '',
          serialize: async (ref) => {
            const file = controller.fileForRef(ref)
            if (!file) throw new Error('待发送文件已失效，请重新上传')
            controller.markSerializing(ref)
            return serializedFile(file)
          },
        },
      }), 'dsh-upload-manager: hidden file reference codec')

      ctx.effect(() => {
        const style = document.createElement('style')
        style.dataset.plugin = 'dsh-file-uploads'
        style.textContent = CSS
        document.head.appendChild(style)
        return () => style.remove()
      }, 'dsh-upload-manager: styles')

      ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
        name: 'conversation.input.left',
        id: 'local-file-upload',
        order: -20,
        label: '上传文件',
      }, (props) => React.createElement(UploadControl, { ...props, controller })))

      ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
        name: 'conversation.input.dock',
        id: 'local-file-upload-rail',
        order: 80,
        label: '待发送文件',
      }, (props) => React.createElement(PendingFileRail, { ...props, controller })))

      ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: 'uploaded-files',
        order: 30,
        label: '上传文件',
      }, UploadSettingsSection))
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  },
})
