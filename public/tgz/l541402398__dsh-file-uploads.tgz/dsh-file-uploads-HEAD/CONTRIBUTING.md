# Contributing

Issues and pull requests are welcome.

## Development

Requirements:

- Node.js 22 or newer
- DeepSeek Harness Web profile compatible with `0.1.0-rc.6`

Run the checks:

```sh
npm test
npm run check
```

For local profile testing, link the package into a disposable Web profile and restart that profile:

```sh
dsh plugin --profile web add "link:/absolute/path/to/dsh-file-uploads"
```

Please keep Host and Client side effects Cordis-fiber-owned and include regression tests for storage, routing, or trust-boundary changes.
