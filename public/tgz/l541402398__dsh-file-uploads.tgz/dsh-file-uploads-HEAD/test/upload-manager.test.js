import assert from 'node:assert/strict'
import { createServer, request } from 'node:http'
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import test from 'node:test'

import {
  API_PATH,
  DOWNLOAD_PATH,
  contentDisposition,
  createHandlers,
  isSafeStoredName,
  sanitizeUploadName,
} from '../index.js'

test('sanitizes uploaded names and rejects unsafe lookup names', () => {
  assert.equal(sanitizeUploadName('../../报告.txt'), '报告.txt')
  assert.equal(sanitizeUploadName('.upload-secret'), 'upload-secret')
  assert.equal(sanitizeUploadName(''), 'upload.bin')
  assert.equal(isSafeStoredName('报告.txt'), true)
  assert.equal(isSafeStoredName('../报告.txt'), false)
  assert.equal(isSafeStoredName('a/b.txt'), false)
  assert.match(contentDisposition('报告.txt'), /filename\*=UTF-8''/)
  assert.doesNotMatch(contentDisposition('a"b.txt'), /filename="a"b/)
})

test('uploads, uniquely names, lists, downloads, and deletes files', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-upload-manager-'))
  const handlers = createHandlers({ root, maxFileBytes: 1024 })
  const server = createServer((req, res) => {
    const pathname = new URL(req.url || '/', 'http://x').pathname
    const handler = pathname === DOWNLOAD_PATH ? handlers.download : pathname === API_PATH ? handlers.api : null
    if (!handler) {
      res.writeHead(404)
      res.end()
      return
    }
    Promise.resolve(handler(req, res)).catch((error) => {
      res.writeHead(500)
      res.end(String(error))
    })
  })

  await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve))
    await rm(root, { recursive: true, force: true })
  })

  const address = server.address()
  const base = `http://127.0.0.1:${address.port}`
  const upload = async (name, body) => {
    const response = await fetch(`${base}${API_PATH}`, {
      method: 'POST',
      headers: {
        'content-type': 'application/octet-stream',
        'x-file-name': encodeURIComponent(name),
      },
      body,
    })
    return { response, body: await response.json() }
  }

  const crossOrigin = await fetch(`${base}${API_PATH}`, {
    method: 'POST',
    headers: {
      origin: 'https://evil.example',
      'x-file-name': 'blocked.txt',
    },
    body: 'blocked',
  })
  assert.equal(crossOrigin.status, 403)

  const first = await upload('demo.txt', 'first')
  assert.equal(first.response.status, 201)
  assert.equal(first.body.file.name, 'demo.txt')
  assert.equal(first.body.file.path, join(root, 'demo.txt'))

  const second = await upload('demo.txt', 'second')
  assert.equal(second.response.status, 201)
  assert.equal(second.body.file.name, 'demo (1).txt')
  assert.equal(await readFile(join(root, 'demo.txt'), 'utf8'), 'first')
  assert.equal(await readFile(join(root, 'demo (1).txt'), 'utf8'), 'second')

  const listResponse = await fetch(`${base}${API_PATH}`)
  const list = await listResponse.json()
  assert.equal(listResponse.status, 200)
  assert.equal(list.root, root)
  assert.deepEqual(list.files.map((file) => file.name).sort(), ['demo (1).txt', 'demo.txt'])

  const downloadResponse = await fetch(`${base}${DOWNLOAD_PATH}?name=${encodeURIComponent('demo.txt')}`)
  assert.equal(downloadResponse.status, 200)
  assert.equal(await downloadResponse.text(), 'first')
  assert.match(downloadResponse.headers.get('content-disposition'), /demo\.txt/)

  const traversal = await fetch(`${base}${API_PATH}?name=${encodeURIComponent('../demo.txt')}`, { method: 'DELETE' })
  assert.equal(traversal.status, 400)

  const deleted = await fetch(`${base}${API_PATH}?name=${encodeURIComponent('demo.txt')}`, { method: 'DELETE' })
  assert.equal(deleted.status, 200)
  assert.equal((await deleted.json()).deleted, 'demo.txt')

  const missing = await fetch(`${base}${DOWNLOAD_PATH}?name=${encodeURIComponent('demo.txt')}`)
  assert.equal(missing.status, 404)
})

test('enforces the configured upload byte limit', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-upload-limit-'))
  const handlers = createHandlers({ root, maxFileBytes: 4 })
  const server = createServer((req, res) => handlers.api(req, res))
  await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve))
    await rm(root, { recursive: true, force: true })
  })

  const address = server.address()
  const response = await fetch(`http://127.0.0.1:${address.port}${API_PATH}`, {
    method: 'POST',
    headers: { 'x-file-name': 'large.bin' },
    body: '12345',
  })
  assert.equal(response.status, 413)
  assert.match((await response.json()).error, /exceeds/)
})

test('rejects untrusted authorities for list and download routes', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-upload-trust-'))
  const handlers = createHandlers({ root })
  const server = createServer((req, res) => handlers.api(req, res))
  await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve))
    await rm(root, { recursive: true, force: true })
  })

  const address = server.address()
  const status = await new Promise((resolve, reject) => {
    const req = request({
      host: '127.0.0.1',
      port: address.port,
      path: API_PATH,
      headers: { host: 'evil.example' },
    }, (res) => {
      res.resume()
      res.on('end', () => resolve(res.statusCode))
    })
    req.on('error', reject)
    req.end()
  })
  assert.equal(status, 403)
})

test('enforces a total storage quota and reports usage', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-upload-quota-'))
  await writeFile(join(root, 'existing.bin'), '1234')
  const handlers = createHandlers({ root, maxFileBytes: 10, totalMaxBytes: 6 })
  const server = createServer((req, res) => handlers.api(req, res))
  await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve))
    await rm(root, { recursive: true, force: true })
  })

  const address = server.address()
  const base = `http://127.0.0.1:${address.port}${API_PATH}`
  const listing = await fetch(base)
  const body = await listing.json()
  assert.equal(body.usedBytes, 4)
  assert.equal(body.totalMaxBytes, 6)

  const response = await fetch(base, {
    method: 'POST',
    headers: { 'x-file-name': 'too-large.bin' },
    body: '123',
  })
  assert.equal(response.status, 507)
  assert.match((await response.json()).error, /quota/)
})

test('sweeps crash-left upload temp files', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-upload-temp-'))
  try {
    await writeFile(join(root, '.upload-stale.tmp'), 'partial')
    await writeFile(join(root, 'keep.txt'), 'keep')
    const { sweepUploadTemps } = await import('../index.js')
    assert.equal(await sweepUploadTemps(root), 1)
    assert.deepEqual((await readdir(root)).sort(), ['keep.txt'])
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('keeps numbered duplicate names within the lookup limit', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-upload-long-name-'))
  const handlers = createHandlers({ root, maxFileBytes: 1024 })
  const server = createServer((req, res) => handlers.api(req, res))
  await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve))
    await rm(root, { recursive: true, force: true })
  })

  const address = server.address()
  const base = `http://127.0.0.1:${address.port}${API_PATH}`
  const name = `${'a'.repeat(176)}.txt`
  const upload = () => fetch(base, {
    method: 'POST',
    headers: { 'x-file-name': name },
    body: 'x',
  }).then((response) => response.json())
  await upload()
  const second = await upload()
  assert.equal(second.file.name.length <= 180, true)
  assert.equal(isSafeStoredName(second.file.name), true)
})
