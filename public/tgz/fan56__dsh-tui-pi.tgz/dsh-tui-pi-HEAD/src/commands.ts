/**
 * Slash-command integration with dsh's own command registry.
 *
 * dsh-tui-pi never re-implements a command: autocomplete lists
 * `ctx.commands.list(agent)` and submission routes through
 * `executeCommand(ctx.commands, agent, line, signal)`. Anything that is not a
 * resolvable command falls through to the model as an ordinary prompt, so
 * every command registered by dsh packages (plan, compact, feedback, export,
 * permission, goal, …) works here unchanged and future registrations appear
 * automatically.
 *
 * One exemption: TUI-owned commands that never touch the receiving agent
 * (model pickers, settings browser, session info/resume) are dispatched
 * locally when no live agent exists — dsh's execute path addresses an agent
 * and would mint a throwaway session just to run them.
 */

import { homedir } from 'node:os'
import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import {
  parseCommand,
  type CommandDescriptor,
  type CommandExecution,
  type CommandResult,
} from '@deepseek-ai/dsh-commands'
import type { SkillSummary } from '@deepseek-ai/dsh-skill'
import type { AutocompleteItem, AutocompleteProvider, AutocompleteSuggestions } from '@earendil-works/pi-tui'
import {
  buildNativeSkillCandidates,
  completionLabel,
  isUserSkill,
  mergeMixedSkillItems,
} from './skills.ts'
import type { UsageRecorder } from './usage.ts'
import type { DshSessionBridge } from './session.ts'

function tokenAtCursor(line: string, cursorCol: number): { token: string; start: number } | undefined {
  const upto = line.slice(0, cursorCol)
  const match = /(^|\s)\/([a-z][a-z0-9_-]*)?$/u.exec(upto)
  if (match === null) return undefined
  const start = match.index + (match[1] ?? '').length
  return { token: upto.slice(start), start }
}

/**
 * Structural mirror of dsh-attachment's rc.8 `EncodedImageAttachment` —
 * declared locally (not imported) because the rc.7 closure does not export
 * that interface yet, and this file must typecheck against either closure.
 */
interface EncodedImageAttachment {
  mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif'
  data: string
  name?: string
}

/**
 * Call `commands.execute` across dsh-commands API versions.
 *
 * rc.7 signature: execute(agent, line, signal)               — 3 params
 * rc.8 signature: execute(agent, line, images, signal)       — 4 params
 *
 * The overloaded declaration accepts both call shapes so callers always
 * pass `(commands, agent, line, signal)`.  The implementation body
 * dispatches to the correct argument count: for rc.7 the 3-arg form
 * (signal in position 3); for rc.8 the 4-arg form (empty images array
 * in position 3, signal in position 4).
 *
 * @internal — exported for unit testing.
 */
export function executeCommand(
  commands: { execute: (...args: never[]) => unknown },
  agent: Agent,
  line: string,
  signal: AbortSignal,
): Promise<CommandExecution | undefined>
export function executeCommand(
  commands: { execute: (...args: never[]) => unknown },
  agent: Agent,
  line: string,
  images: readonly EncodedImageAttachment[],
  signal: AbortSignal,
): Promise<CommandExecution | undefined>
export function executeCommand(
  commands: { execute: (...args: never[]) => unknown },
  agent: Agent,
  line: string,
  imagesOrSignal: readonly EncodedImageAttachment[] | AbortSignal,
  maybeSignal?: AbortSignal,
): Promise<CommandExecution | undefined> {
  if (maybeSignal !== undefined) {
    // Explicit 4-arg call: caller provided images + signal directly.
    return (commands.execute as (...args: unknown[]) => unknown)(
      agent, line, imagesOrSignal, maybeSignal,
    ) as Promise<CommandExecution | undefined>
  }
  // Caller passed only (agent, line, signal) — route by runtime arity.
  // rc.8 added an `images` parameter before `signal`; detect via .length
  // and insert an empty images array when needed. Known limit of arity
  // probing: a future execute() that gains a default parameter or ANOTHER
  // inserted parameter would misroute — if slash commands break after a
  // dsh upgrade again, re-check this signature first (both rc.7 and rc.8
  // use plain named parameters, so .length is exact today).
  const signal = imagesOrSignal as AbortSignal
  if (commands.execute.length >= 4) {
    return (commands.execute as (...args: unknown[]) => unknown)(
      agent, line, [], signal,
    ) as Promise<CommandExecution | undefined>
  }
  return (commands.execute as (...args: unknown[]) => unknown)(
    agent, line, signal,
  ) as Promise<CommandExecution | undefined>
}

/** A TUI-owned command body that needs no receiving agent. */
export type LocalCommandHandler =
  (rawInput: string, signal: AbortSignal) => CommandResult | Promise<CommandResult>

export class CommandService {
  private readonly ctx: Context
  private readonly bridge: DshSessionBridge
  /** TUI-owned command bodies, dispatchable without a live agent. */
  private readonly local = new Map<string, LocalCommandHandler>()
  /**
   * Optional usage memory backing frequency-sorted completions. Undefined in
   * tests / degraded setups: the completion list then stays name-sorted.
   */
  private readonly usage: UsageRecorder | undefined

  constructor(ctx: Context, bridge: DshSessionBridge, usage?: UsageRecorder) {
    this.ctx = ctx
    this.bridge = bridge
    this.usage = usage
  }

  /**
   * Register a local command body (the same handler the ctx.commands
   * registration wraps). It is dispatched directly when no live agent
   * exists, avoiding a throwaway session for agentless commands.
   */
  registerLocal(name: string, handler: LocalCommandHandler): void {
    this.local.set(name, handler)
  }

  /**
   * Try to run `line` as a dsh slash command.
   * @returns `handled: true` when the line was admitted as a command (the
   *   caller must not forward it to the model), with an optional `error` or
   *   success `text` to surface; `handled: false` when it is not a command.
   */
  async tryExecute(line: string, signal: AbortSignal): Promise<{ handled: boolean; error?: string; text?: string }> {
    const parsed = parseCommand(line)
    if (parsed === undefined) return { handled: false }

    const commands = this.ctx.get('commands')
    if (commands === undefined) return { handled: false }

    // Agentless local commands never warm the session — /resume or /session
    // on a fresh TUI must not mint a session just to run.
    const localHandler = this.local.get(parsed.name)
    if (localHandler !== undefined && this.bridge.getAgent() === undefined) {
      try {
        const result = await localHandler(parsed.rawInput, signal)
        if (result.kind === 'error') return { handled: true, error: result.text }
        // Successful invocation — count it for frequency-sorted completions.
        this.usage?.record(parsed.name)
        return { handled: true, ...result.text === undefined ? {} : { text: result.text } }
      } catch (error: unknown) {
        const message = error instanceof Error ? error.message : String(error)
        return { handled: true, error: message }
      }
    }

    // Commands address a live agent; warm the session when it does not exist.
    let agent: Agent
    try {
      agent = await this.bridge.ensureAgent()
    } catch (error: unknown) {
      // Warm-up failed (e.g. provider not configured) — surface instead of
      // rejecting into an unhandled promise rejection.
      const message = error instanceof Error ? error.message : String(error)
      return { handled: true, error: message }
    }
    if (commands.find(agent, parsed.name) === undefined) {
      // Syntactically a command but unregistered → treat as ordinary text so
      // the model still sees it (matches "unknown command" falling through).
      // When the name IS a user-invocable skill, this line is the harness's
      // `/name` skill gesture: the prompt lands on the model untouched and
      // tool-skill's agent/pre-step injects the rendered skill content —
      // count it so completions rank the skill by real usage. (Names outside
      // parseCommand's charset never get here; those gestures stay uncounted,
      // an accepted edge. Without a recorder the registry probe is skipped
      // entirely — no skills.list() round-trip for plain fall-throughs.)
      if (this.usage !== undefined && (await this.isUserSkillName(parsed.name))) {
        this.usage.record(parsed.name)
      }
      return { handled: false }
    }

    try {
      const execution = await executeCommand(commands, agent, line, signal)
      if (execution === undefined) return { handled: false }
      if (execution.result.kind === 'error') return { handled: true, error: execution.result.text }
      // Successful invocation — count it for frequency-sorted completions.
      this.usage?.record(parsed.name)
      return { handled: true, ...execution.result.text === undefined ? {} : { text: execution.result.text } }
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error)
      return { handled: true, error: message }
    }
  }

  /**
   * Effective command descriptors for the current agent. Warms the session on
   * first use so `/` autocompletes before any prompt was sent.
   */
  async list(): Promise<readonly CommandDescriptor[]> {
    const commands = this.ctx.get('commands')
    if (commands === undefined) return []
    try {
      const agent = await this.bridge.ensureAgent()
      return commands.list(agent)
    } catch {
      // Session warm-up failed (e.g. provider not configured) — no completions.
      return []
    }
  }

  /** pi-tui autocomplete provider over the live command registry. */
  autocompleteProvider(): AutocompleteProvider {
    return {
      triggerCharacters: ['/'],
      getSuggestions: async (
        lines: string[],
        cursorLine: number,
        cursorCol: number,
        options: { signal: AbortSignal },
      ): Promise<AutocompleteSuggestions | null> => {
        const line = lines[cursorLine] ?? ''
        const at = tokenAtCursor(line, cursorCol)
        if (at === undefined) return null
        // Only complete the command name itself (leading token, no arguments yet).
        if (at.start !== 0 && line.slice(0, at.start).trim() !== '') return null


        // Generic `/` completion: commands and the user skills' native `/name`
        // rows in one mixed list, ordered most-used first (usage table) with
        // display name as tie-break, filtered by the token after the slash.
        const query = at.token.slice(1).toLowerCase()
        const descriptors = await this.list()
        const commandItems: AutocompleteItem[] = descriptors
          .filter(d => query === '' || d.name.toLowerCase().startsWith(query))
          .map(d => ({
            value: `/${d.name}`,
            label: completionLabel('command', `/${d.name}`),
            description: d.description,
            kind: 'command' as const,
          }))
        const nativeSkillItems = await this.nativeSkillCandidates()
        const items = mergeMixedSkillItems(commandItems, nativeSkillItems, query, this.usage?.snapshot())
        if (items.length === 0) return null
        return { items, prefix: at.token } satisfies AutocompleteSuggestions
      },
      applyCompletion: (
        lines: string[],
        cursorLine: number,
        cursorCol: number,
        item: AutocompleteItem,
        prefix: string,
      ) => {
        const line = lines[cursorLine] ?? ''
        const at = tokenAtCursor(line, cursorCol)
        if (at === undefined) return { lines, cursorLine, cursorCol }
        const before = line.slice(0, at.start)
        const after = line.slice(cursorCol)
        // All completions (commands and skills) get the trailing-space
        // separator which readies the line for arguments.
        const completed = `${before}${item.value} ${after}`
        const nextLines = lines.slice()
        nextLines[cursorLine] = completed
        return {
          lines: nextLines,
          cursorLine,
          cursorCol: before.length + item.value.length + 1,
        }
      },
    }
  }

  /**
   * The live (optional) `ctx.skills` registry's user-invocable summaries,
   * scoped to the current agent/cwd. An absent or failing service yields none.
   */
  private async listSkills(): Promise<readonly SkillSummary[]> {
    const skills = this.ctx.get('skills')
    if (skills === undefined) return []
    const agent = this.bridge.getAgent()
    const cwd = agent?.session.header.cwd ?? process.cwd()
    try {
      return await skills.list({ scope: agent, cwd })
    } catch {
      return []
    }
  }

  /** Native `/name` skill candidates for the mixed `/` command list. */
  private async nativeSkillCandidates(): Promise<AutocompleteItem[]> {
    return buildNativeSkillCandidates(await this.listSkills())
  }

  /**
   * Whether `name` matches a user-invocable skill in the live registry —
   * the confirmation that a fall-through line is a genuine skill gesture.
   * An absent or failing skills registry answers false (nothing counted).
   */
  private async isUserSkillName(name: string): Promise<boolean> {
    const lower = name.toLowerCase()
    const skills = await this.listSkills()
    return skills.some(skill => isUserSkill(skill) && skill.name.toLowerCase() === lower)
  }
}
