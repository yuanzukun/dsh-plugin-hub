/**
 * /login and /logout — the terminal counterparts of pi-agent's credential
 * management, built on the Models category's add-provider flow.
 *
 * /login opens a searchable provider directory (including already-configured
 * routes, so a re-login can overwrite a key), collects one API key through the
 * masked EditField, and commits the provider profile + credential the same way
 * the web Models page does. An optional argument names a provider directly:
 * `/login openai` jumps straight to the key editor on a unique match and opens
 * the picker filtered to the matches otherwise.
 *
 * /logout lists the providers with a stored credential (an async
 * credentials.describe probe per ref), lets the user pick one, and removes
 * both the credential and the llm-pi-ai provider profile — a full
 * unsubscribe. The profile half is what takes the provider's models out of
 * /model: the llm-pi-ai adapter registers a route for every
 * `llm-pi-ai.providers` key, so a logout that dropped only the key would
 * leave the models listed (and a picked one would fail at request time).
 * A re-login re-subscribes the provider and serves the installed pi-ai
 * catalog's current model list.
 *
 * The pure decision logic (`resolveLoginTarget`, `listLogoutCandidates`,
 * `commitLogout`) is unit-tested in test/login.test.mjs.
 */

import type { Context } from '@deepseek-ai/cordis'
import type { SettingsForms } from '@deepseek-ai/dsh-settings'
import { type OverlayHandle, type TUI } from '@earendil-works/pi-tui'
import { wrapFramedOverlay } from './frame.ts'
import { autoColumns, TablePanel } from './panels.ts'
import {
  catalogEntry,
  deriveKeyRef,
  directoryProviderEntries,
  PROVIDER_CATALOG,
  providerProfileFor,
  type ProviderCatalogEntry,
} from './provider-catalog.ts'
import { CUSTOM_PROVIDER_ID, CustomProviderFlow, customProviderEntry } from './custom-provider.ts'
import { AddProviderFlow, commitProvider } from './settings.ts'
import type { TuiTheme } from './theme/index.ts'
import { t } from './i18n/index.ts'

/**
 * The llm-pi-ai settings namespace (same id the /settings browser uses).
 * dsh-settings 0.1.2-alpha.3 removed the runtime settingsNamespace() helper:
 * a plain literal is the supported spelling — register() brand-checks it at
 * the type level (SettingsNamespaceInput) and validates the same pattern at
 * runtime (parseSettingsNamespace).
 */
const LLM_PI_AI_NS = 'llm-pi-ai'

/**
 * Resolve a `/login <provider>` argument against the picker directory:
 * case-insensitive exact match on the route id or display name first, then a
 * case-insensitive prefix match on either. Returns the matching entries in
 * directory order — the caller reads the length: 0 = unknown, 1 = unique
 * (jump straight to the key editor), >1 = show the picker filtered to the
 * matches.
 */
export function resolveLoginTarget(
  input: string,
  entries: readonly ProviderCatalogEntry[],
): ProviderCatalogEntry[] {
  const needle = input.trim().toLowerCase()
  if (needle === '') return []
  const exact = entries.filter(
    entry => entry.id.toLowerCase() === needle || entry.name.toLowerCase() === needle,
  )
  if (exact.length > 0) return exact
  return entries.filter(
    entry => entry.id.toLowerCase().startsWith(needle) || entry.name.toLowerCase().startsWith(needle),
  )
}

/** One configured llm-pi-ai provider considered by the /logout picker. */
export interface LogoutProvider {
  /** llm-pi-ai providers dict key. */
  id: string
  /** Credential reference: the profile's `apiKeyEnv`, else the derived ref. */
  ref: string
  /** Profile displayName, when set. */
  displayName?: string
  /** Hand-declared route (no installed catalog entry) — see handDeclaredLogouts. */
  declared?: boolean
}

/** A logout candidate: a logged-in provider with its picker label. */
export interface LogoutCandidate {
  id: string
  ref: string
  /** Picker label: displayName, else catalog name, else the route key. */
  name: string
  /** Hand-declared route: logout drops only the key, never the profile. */
  declared: boolean
}

/**
 * Filter the configured llm-pi-ai providers down to the logged-in ones — a
 * provider is a logout candidate when its credential ref is configured. The
 * caller supplies the configured judgment (from async credentials.describe
 * probes); the filtering and label resolution stay pure.
 */
export function listLogoutCandidates(
  providers: readonly LogoutProvider[],
  configuredRefs: ReadonlySet<string>,
): LogoutCandidate[] {
  return providers
    .filter(provider => configuredRefs.has(provider.ref))
    .map(provider => ({
      id: provider.id,
      ref: provider.ref,
      name: provider.displayName !== undefined && provider.displayName !== ''
        ? provider.displayName
        : catalogEntry(provider.id)?.name ?? provider.id,
      declared: provider.declared === true,
    }))
}

/**
 * Logout candidates from one resolved llm-pi-ai settings section value: one
 * per `providers` dict entry, with the credential ref taken from the
 * profile's own `apiKeyEnv` when it names one (a hand-edited profile may
 * point anywhere — deriving from the route id would unset an unrelated key
 * and strand the real one), falling back to the conventional derived ref.
 */
export function logoutCandidatesFromSection(section: unknown): LogoutProvider[] {
  const providers = (typeof section === 'object' && section !== null
    ? (section as { providers?: unknown }).providers
    : undefined)
  if (typeof providers !== 'object' || providers === null) return []
  return Object.entries(providers as Record<string, unknown>).map(([id, profile]) => {
    const p = typeof profile === 'object' && profile !== null
      ? profile as { displayName?: unknown; apiKeyEnv?: unknown }
      : undefined
    const displayName = p?.displayName
    const apiKeyEnv = p?.apiKeyEnv
    return {
      id,
      ref: typeof apiKeyEnv === 'string' && apiKeyEnv !== '' ? apiKeyEnv : deriveKeyRef(id),
      displayName: typeof displayName === 'string' && displayName !== '' ? displayName : undefined,
    }
  })
}

/**
 * Which logout candidates are hand-declared routes — profiles with no
 * installed catalog entry. The live configurable-provider directory's
 * `declared` flag decides when available; otherwise the static catalog
 * mirror stands in (an unknown route key is a hand declaration). A
 * hand-declared profile carries `api`/`baseURL`/`models` that /login
 * cannot re-create (its directory excludes declared routes), so deleting
 * it on logout would be unrecoverable data loss.
 */
export function handDeclaredLogouts(
  ids: readonly string[],
  directory: ReadonlyArray<{ provider: string; declared?: boolean }> | undefined,
): ReadonlySet<string> {
  if (directory !== undefined) {
    const declared = new Map(directory.map(entry => [entry.provider, entry.declared === true]))
    return new Set(ids.filter(id => declared.get(id) === true))
  }
  return new Set(ids.filter(id => catalogEntry(id) === undefined))
}

/** Outcome of the /login flow. */
export type LoginFlowResult =
  | { kind: 'unknown'; target: string }
  | { kind: 'cancelled' }
  | { kind: 'configured'; name: string }

export interface LoginFlowOptions {
  ctx: Context
  tui: TUI
  theme: TuiTheme
  /** Focus target to restore when the flow closes (usually the editor). */
  restoreFocus: () => void
  /** Error sink for writes that fail after the editor already closed. */
  onError: (message: string) => void
  /** Optional `/login <provider>` target (route id or display name). */
  target?: string
}

/** Outcome of the /logout flow. */
export type LogoutFlowResult =
  | { kind: 'none' }
  | { kind: 'cancelled' }
  | { kind: 'removed'; name: string }
  | { kind: 'removed-incomplete'; name: string; error: string }
  | { kind: 'removed-key-only'; name: string }
  | { kind: 'failed'; name: string; cause?: string }

export interface LogoutFlowOptions {
  ctx: Context
  tui: TUI
  theme: TuiTheme
  /** Focus target to restore when the flow closes (usually the editor). */
  restoreFocus: () => void
  /** Error sink for a failed credential removal (transcript notice). */
  onError: (message: string) => void
}

/**
 * Structural face of the credentials seam the /logout flow needs: the async
 * configured probe and the unset. Kept local like settings.ts's CredentialSeam
 * so this module does not hard-depend on `@deepseek-ai/dsh-credentials`.
 */
interface LogoutCredentialSeam {
  describe?(ref: string): Promise<{ configured: boolean }>
  unset(ref: string): Promise<void>
}

/** Async seams the logout commit drives (see `commitLogout`). */
export interface LogoutCommitSeams {
  /** Remove the stored credential (`credentials.unset`). */
  unset(ref: string): Promise<void>
  /**
   * Remove the provider profile; resolves the write error, else `undefined`.
   * Omitted for hand-declared routes — their profile is unrecoverable by
   * /login, so logout drops only the key (`removed-key-only`).
   */
  removeProfile?(id: string): Promise<string | undefined>
}

/**
 * Commit one logout: unset the credential first (the security-critical
 * half), then — unless the caller omitted the profile seam (a hand-declared
 * route) — remove the provider profile, the half that takes the provider's
 * models out of /model, because the llm-pi-ai adapter registers a route for
 * every `llm-pi-ai.providers` key. The sequencing is the contract: a failed
 * unset must not touch the profile, and a failed profile removal must not
 * undo the unset — the outcome reports what actually happened instead.
 */
export async function commitLogout(
  candidate: LogoutCandidate,
  seams: LogoutCommitSeams,
): Promise<LogoutFlowResult> {
  try {
    await seams.unset(candidate.ref)
  } catch (cause) {
    return {
      kind: 'failed',
      name: candidate.name,
      cause: cause instanceof Error ? cause.message : String(cause),
    }
  }
  if (seams.removeProfile === undefined) {
    return { kind: 'removed-key-only', name: candidate.name }
  }
  const profileError = await seams.removeProfile(candidate.id)
  return profileError === undefined
    ? { kind: 'removed', name: candidate.name }
    : { kind: 'removed-incomplete', name: candidate.name, error: profileError }
}

/** Structural face of the llm service's configurable-provider directory. */
interface LlmDirectorySeam {
  listConfigurableProviders?: () => Array<{ provider: string; settingsNs?: string; declared?: boolean }>
}

/** Live llm-pi-ai configurable-provider directory entries, or `undefined`. */
function llmPiAiDirectory(ctx: Context): ReadonlyArray<{ provider: string; declared?: boolean }> | undefined {
  const llm = ctx.get('llm') as LlmDirectorySeam | undefined
  if (llm?.listConfigurableProviders === undefined) return undefined
  try {
    return llm.listConfigurableProviders()
      .filter(entry => entry.settingsNs === LLM_PI_AI_NS)
      .map(entry => (
        entry.declared !== undefined
          ? { provider: entry.provider, declared: entry.declared }
          : { provider: entry.provider }
      ))
  } catch {
    return undefined
  }
}

/**
 * Every picker entry for /login: the synthetic "Custom provider…" entry first
 * (the hand-declared-route form), then all configurable routes, including
 * already-configured ones (a re-login overwrites the key), but never
 * hand-declared routes — a re-login must not overwrite a hand-declared
 * api/baseURL/models profile with the catalog's.
 */
function loginDirectoryEntries(ctx: Context): readonly ProviderCatalogEntry[] {
  const directory = llmPiAiDirectory(ctx)
  const entries = directory !== undefined && directory.length > 0
    ? directoryProviderEntries(directory, new Set())
    : PROVIDER_CATALOG
  return [customProviderEntry(), ...entries]
}

/** Route ids a custom provider id must not collide with (catalog + live). */
function takenRouteIds(ctx: Context): Set<string> {
  const ids = new Set(PROVIDER_CATALOG.map(entry => entry.id))
  for (const entry of llmPiAiDirectory(ctx) ?? []) ids.add(entry.provider)
  return ids
}

/** Serialized llm-pi-ai profile write for /login (revision read at execution time). */
async function writeProviderProfile(settings: SettingsForms, entry: ProviderCatalogEntry): Promise<string | undefined> {
  try {
    await settings.mutate(
      LLM_PI_AI_NS,
      [{ op: 'set', path: ['providers', entry.id], value: providerProfileFor(entry) }],
      settings.describe().find(desc => desc.ns === LLM_PI_AI_NS)?.revision,
    )
  } catch (error) {
    return error instanceof Error ? error.message : String(error)
  }
  return undefined
}

/**
 * Serialized llm-pi-ai profile removal for /logout (revision read at
 * execution time). Resolves the mutate error, or `undefined` on success —
 * an unset through an absent path is already satisfied, and a revision
 * conflict from a concurrent removal counts too: the desired state already
 * holds, so the profile is re-read and a vanished entry reports success.
 */
async function removeProviderProfile(settings: SettingsForms, id: string): Promise<string | undefined> {
  const profileSection = (): unknown => {
    const desc = settings.describe().find(d => d.ns === LLM_PI_AI_NS)
    const providers = (desc?.value as { providers?: unknown } | undefined)?.providers
    return typeof providers === 'object' && providers !== null
      ? (providers as Record<string, unknown>)[id]
      : undefined
  }
  try {
    await settings.mutate(
      LLM_PI_AI_NS,
      [{ op: 'unset', path: ['providers', id] }],
      settings.describe().find(desc => desc.ns === LLM_PI_AI_NS)?.revision,
    )
  } catch (error) {
    return profileSection() === undefined
      ? undefined
      : error instanceof Error ? error.message : String(error)
  }
  return undefined
}

/**
 * Open the provider login flow. Resolves when the flow closes: `configured`
 * names the provider whose key was stored (a `notice` outcome — committed
 * profile without a credentials service — counts as configured too),
 * `cancelled` when the user escaped without committing, and `unknown` when a
 * `/login <provider>` argument matched no route. Focus returns to
 * `restoreFocus` on close.
 */
export async function openLoginFlow(options: LoginFlowOptions): Promise<LoginFlowResult> {
  const settings = options.ctx.get('settings')
  if (settings === undefined) throw new Error('settings service is not available')

  const entries = loginDirectoryEntries(options.ctx)
  const target = options.target?.trim() ?? ''
  let pickerEntries = entries
  let initialEntry: ProviderCatalogEntry | undefined
  if (target !== '') {
    const matches = resolveLoginTarget(target, entries)
    if (matches.length === 1) {
      initialEntry = matches[0]!
    } else if (matches.length > 1) {
      pickerEntries = matches
    } else {
      return { kind: 'unknown', target }
    }
  }

  let committedName: string | undefined
  let overlay: OverlayHandle | undefined
  return new Promise<LoginFlowResult>(resolve => {
    const flow = new AddProviderFlow(options.tui, options.theme, {
      entries: pickerEntries,
      ...(initialEntry !== undefined ? { initialEntry } : {}),
      // The "Custom provider…" entry routes to the chained hand-declared-
      // route form instead of the plain key editor.
      customEntryId: CUSTOM_PROVIDER_ID,
      customFlow: done => new CustomProviderFlow({
        tui: options.tui,
        theme: options.theme,
        takenIds: takenRouteIds(options.ctx),
        onCommit: (entry, key) => commitProvider(
          options.ctx,
          () => writeProviderProfile(settings, entry),
          entry,
          key,
        ).then(result => {
          if (result === undefined || result.notice !== undefined) committedName = entry.name
          return result
        }),
        onExit: () => {
          done()
          overlay?.hide()
          options.restoreFocus()
          resolve(committedName === undefined ? { kind: 'cancelled' } : { kind: 'configured', name: committedName })
        },
        onError: options.onError,
      }),
      onCommit: (entry, key) => commitProvider(
        options.ctx,
        () => writeProviderProfile(settings, entry),
        entry,
        key,
      ).then(result => {
        // A full success (undefined), and the no-credentials-service `notice`
        // alike, mean the provider is configured now.
        if (result === undefined || result.notice !== undefined) committedName = entry.name
        return result
      }),
      onExit: () => {
        overlay?.hide()
        options.restoreFocus()
        resolve(committedName === undefined ? { kind: 'cancelled' } : { kind: 'configured', name: committedName })
      },
      onError: options.onError,
    })
    overlay = options.tui.showOverlay(wrapFramedOverlay(options.theme, flow), { width: '80%', maxHeight: '80%' })
  })
}

/**
 * Open the provider logout flow: list the providers with a stored credential,
 * and on selection remove both the key and the settings.yaml provider entry
 * (see `commitLogout` for the ordering) — with the profile gone, the llm
 * service deregisters the route and the provider's models leave /model
 * immediately. A hand-declared route keeps its profile (`removed-key-only`):
 * /login cannot re-create its api/baseURL/models. Resolves `removed` after
 * both writes land, `removed-incomplete` when the key went but the profile
 * write failed, `failed` when the unset rejected, `none` when nothing is
 * logged in, and `cancelled` when the user escapes. Focus returns to
 * `restoreFocus` on close.
 */
export async function openLogoutFlow(options: LogoutFlowOptions): Promise<LogoutFlowResult> {
  const settings = options.ctx.get('settings')
  if (settings === undefined) throw new Error('settings service is not available')
  const credentials = options.ctx.get('credentials') as LogoutCredentialSeam | undefined

  const piDesc = settings.describe().find(desc => desc.ns === LLM_PI_AI_NS)
  const candidates = logoutCandidatesFromSection(piDesc?.value ?? {})
  const declared = handDeclaredLogouts(candidates.map(candidate => candidate.id), llmPiAiDirectory(options.ctx))

  // No credential store in this process → there is nothing to unset.
  if (credentials?.describe === undefined) return { kind: 'none' }
  const probes = await Promise.all(candidates.map(async provider => {
    try {
      const info = await credentials.describe!(provider.ref)
      return info.configured === true
    } catch {
      // A failing probe must not break the list — the provider reads as
      // logged out, same as the Models status column.
      return false
    }
  }))
  const configuredRefs = new Set(candidates.filter((_, index) => probes[index]).map(provider => provider.ref))
  const loggedIn = listLogoutCandidates(
    candidates.map(provider => ({ ...provider, declared: declared.has(provider.id) })),
    configuredRefs,
  )
  if (loggedIn.length === 0) return { kind: 'none' }

  // Bound here (not inside finish) so the guards' narrowing of `settings`
  // and `credentials` carries into the commit's closures. A hand-declared
  // route omits the profile seam: /login cannot re-create its
  // api/baseURL/models, so logout must not delete them.
  const commit = (candidate: LogoutCandidate): Promise<LogoutFlowResult> =>
    commitLogout(candidate, {
      unset: ref => credentials.unset(ref),
      ...(candidate.declared ? {} : { removeProfile: (id: string) => removeProviderProfile(settings, id) }),
    })

  return new Promise(resolve => {
    const list = new TablePanel(options.theme, {
      title: t('login.title.logout'),
      // Auto layout: PROVIDER fits its content, KEY REF runs to the edge.
      columns: autoColumns(
        [{ key: 'label', title: t('login.col.provider'), cap: 28 }, { key: 'description', title: t('login.col.keyRef') }],
        loggedIn,
        (candidate, key) => (key === 'description' ? candidate.ref : candidate.name),
      ),
      rows: loggedIn,
      renderCell: (candidate, column) => (column.key === 'description' ? candidate.ref : candidate.name),
      onSelect: candidate => finish(candidate),
      onCancel: () => finish(undefined),
    })
    // Framed overlay: 13 list rows + 4 frame rows fit inside 75% of 24 rows.
    const overlay = options.tui.showOverlay(wrapFramedOverlay(options.theme, list), { width: '80%', maxHeight: '75%' })
    function finish(candidate: LogoutCandidate | undefined): void {
      overlay.hide()
      options.restoreFocus()
      if (candidate === undefined) {
        resolve({ kind: 'cancelled' })
        return
      }
      void commit(candidate).then(result => {
        if (result.kind === 'failed') {
          const cause = result.cause === undefined ? '' : `: ${result.cause}`
          options.onError(t('login.error.removeFailed', { name: result.name, cause }))
        } else if (result.kind === 'removed-incomplete') {
          options.onError(t('login.error.removeIncomplete', { name: result.name, error: result.error }))
        }
        resolve(result)
      })
    }
  })
}
