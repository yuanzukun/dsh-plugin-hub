/**
 * Custom provider login — the /login flow's hand-declared-route entry
 * ("Custom provider…"): the terminal counterpart of the web Models page's
 * add-custom-provider form for enterprise/third-party gateways pi-ai does
 * not ship.
 *
 * The entry composes the same hand-declared llm-pi-ai profile shape the
 * upstream package documents (`providers.<id>` with `apiKeyEnv`, `api`,
 * `baseURL`, `models`, `displayName`) — see the llm-pi-ai README's
 * `acme-gateway` example — and commits through the SAME `commitProvider`
 * chain as a catalog login (profile write + credentials.set). After the
 * write the llm service re-registers the route in place, so the provider's
 * models appear in /model without a restart.
 *
 * UI: a chained sequence of `EditField` windows (one field per step, the
 * Add-provider key-editor pattern) inside the SAME framed overlay the
 * /login picker already owns — step N's commit advances to step N+1, Esc
 * abandons the whole flow, and the final step (the masked API key) commits
 * for real. Pure parse/validate/build helpers live at the top so the field
 * contracts stay unit-testable without a TTY.
 */

import type { Component, TUI } from '@earendil-works/pi-tui'
import { t } from './i18n/index.ts'
import { EditField, type CommitResult } from './settings.ts'
import type { CustomProviderDraft, ProviderCatalogEntry } from './provider-catalog.ts'
import type { TuiTheme } from './theme/index.ts'

export type { CustomProviderDraft }

/** Route id of the synthetic "Custom provider…" picker entry. */
export const CUSTOM_PROVIDER_ID = 'custom'

/**
 * The wire protocols a hand-declared route may name (llm-pi-ai's
 * `supportedProtocols`, most-reached first — the first is the form default).
 */
export const SUPPORTED_PROTOCOLS = ['openai-completions', 'openai-responses', 'anthropic-messages'] as const

/** The synthetic directory entry the /login picker prepends. */
export function customProviderEntry(): ProviderCatalogEntry {
  return {
    id: CUSTOM_PROVIDER_ID,
    name: t('custprov.entry.name'),
    // Runtime-built entry: the hint resolves NOW (unlike the static catalog,
    // whose frozen-table hints carry i18n keys until render time).
    hint: t('custprov.entry.hint'),
    catalogRoute: false,
  }
}

// ------------------------------------------------------ pure field parsers --

/** Parse outcome shared by every field (EditField's `parse` contract). */
export type FieldOutcome =
  | { kind: 'value'; value: string }
  | { kind: 'error'; error: string }

/**
 * Route id validation: a settings path segment (`providers.<id>`), so it
 * must be a lowercase slug — letters, digits, dashes; 2–40 chars; no dots
 * (a dot would nest the yaml path), no uppercase, and it must not collide
 * with an existing catalog/configured route (a colliding hand-declared
 * profile would shadow the pi-ai catalog route of the same name).
 */
export function parseCustomProviderId(text: string, takenIds: ReadonlySet<string>): FieldOutcome {
  const id = text.trim().toLowerCase()
  if (id === '') return { kind: 'error', error: t('custprov.error.idEmpty') }
  if (id.length < 2 || id.length > 40) return { kind: 'error', error: t('custprov.error.idLength') }
  if (!/^[a-z0-9][a-z0-9-]*$/.test(id)) {
    return { kind: 'error', error: t('custprov.error.idChars') }
  }
  if (takenIds.has(id)) return { kind: 'error', error: t('custprov.error.idTaken', { id }) }
  return { kind: 'value', value: id }
}

/** Display name validation: optional, one line, capped. */
export function parseCustomDisplayName(text: string): FieldOutcome {
  const name = text.trim().replace(/\s+/g, ' ')
  if (name === '') return { kind: 'value', value: '' }
  if (name.length > 40) return { kind: 'error', error: t('custprov.error.nameLength') }
  return { kind: 'value', value: name }
}

/**
 * Protocol validation: empty falls back to the default (the most-reached
 * protocol, first of `supportedProtocols`); anything else must name one of
 * the supported ids (case-insensitive).
 */
export function parseCustomProtocol(text: string): FieldOutcome {
  const value = text.trim().toLowerCase()
  if (value === '') return { kind: 'value', value: SUPPORTED_PROTOCOLS[0] }
  const match = SUPPORTED_PROTOCOLS.find(protocol => protocol === value)
  if (match === undefined) {
    return { kind: 'error', error: t('custprov.error.protocol', { list: SUPPORTED_PROTOCOLS.join(', ') }) }
  }
  return { kind: 'value', value: match }
}

/** Base URL validation: an http(s) URL without spaces or a fragment. */
export function parseCustomBaseUrl(text: string): FieldOutcome {
  const url = text.trim()
  if (url === '') return { kind: 'error', error: t('custprov.error.baseUrlEmpty') }
  if (!/^https?:\/\/\S+$/.test(url)) {
    return { kind: 'error', error: t('custprov.error.baseUrlFormat') }
  }
  return { kind: 'value', value: url }
}

/**
 * Model list validation: comma- or whitespace-separated ids, de-duplicated
 * in entry order, at least one, each 1–80 chars. The ids are wire model ids
 * exactly as the gateway echoes them back.
 */
export function parseCustomModels(text: string): FieldOutcome {
  const ids = [...new Set(text.split(/[\s,]+/).map(id => id.trim()).filter(id => id !== ''))]
  if (ids.length === 0) return { kind: 'error', error: t('custprov.error.modelsEmpty') }
  if (ids.some(id => id.length > 80)) return { kind: 'error', error: t('custprov.error.modelLength') }
  if (ids.length > 50) return { kind: 'error', error: t('custprov.error.modelsMax') }
  return { kind: 'value', value: ids.join(',') }
}

/** Build the hand-declared catalog entry the commit chain consumes. */
export function buildCustomEntry(draft: CustomProviderDraft): ProviderCatalogEntry {
  return {
    id: draft.id,
    name: draft.displayName !== '' ? draft.displayName : draft.id,
    hint: t('custprov.hint.declared'),
    catalogRoute: false,
    api: draft.api,
    baseURL: draft.baseURL,
    models: draft.models.split(',').map(id => ({ id })),
    ...(draft.displayName !== '' ? { displayName: draft.displayName } : {}),
  }
}

// ------------------------------------------------------------- the flow --

/** Options for the chained custom-provider form. */
export interface CustomProviderFlowOptions {
  tui: TUI
  theme: TuiTheme
  /** Route ids the custom id must not collide with (catalog + configured). */
  takenIds: ReadonlySet<string>
  /**
   * Edit an existing hand-declared route: the draft prefills from the live
   * profile, the id step is dropped (the route key is immutable — a rename
   * would strand the stored credential), and the final key step accepts an
   * EMPTY value (= keep the currently stored key, profile-only edit).
   */
  edit?: CustomProviderDraft
  /**
   * Commit the built entry + API key — the SAME chain the /login key editor
   * uses (profile write through the caller's serialized settings mutate,
   * then `commitProvider`'s credentials.set). In edit mode the key may be
   * '' (keep the stored one — the commit handler decides).
   */
  onCommit: (entry: ProviderCatalogEntry, key: string) => Promise<CommitResult | undefined>
  /** Pop the whole flow (Esc anywhere, or right after a successful commit). */
  onExit: () => void
  /** Error sink for writes that fail after the form already closed. */
  onError: (message: string) => void
}

interface StepSpec {
  /** Field label shown in the editor title. */
  label: string
  /** One-line guidance under the title. */
  subtitle: string
  /** Prefill (already-committed value when re-entering a step). */
  initial: string
  secret?: boolean
  /** Draft field the commit stashes the value into; undefined on the key step. */
  draftField?: keyof Pick<CustomProviderDraft, 'id' | 'displayName' | 'api' | 'baseURL' | 'models'>
  /** Validate the typed text; intermediate steps just normalize + accept. */
  parse: (text: string) => FieldOutcome
}

/**
 * The chained form: one EditField at a time, advanced on each step's
 * successful commit. The final step (the masked API key) runs the real
 * `onCommit`; a failed commit keeps the editor open with the inline ✘ (Enter
 * retries). Esc at any step abandons the whole flow — same contract as the
 * add-provider key editor. Rendered inside the /login flow's framed overlay
 * (the caller hosts this component).
 */
export class CustomProviderFlow implements Component {
  private readonly tui: TUI
  private readonly theme: TuiTheme
  private readonly options: CustomProviderFlowOptions
  private readonly draft: CustomProviderDraft
  private step = 0
  private editor: EditField

  constructor(options: CustomProviderFlowOptions) {
    this.tui = options.tui
    this.theme = options.theme
    this.options = options
    this.draft = options.edit !== undefined ? { ...options.edit } : { id: '', displayName: '', api: '', baseURL: '', models: '' }
    this.editor = this.buildEditor()
  }

  /** The step specs, in form order; edit mode drops the id step (immutable). */
  private specs(): StepSpec[] {
    const steps: StepSpec[] = [
      {
        label: t('custprov.step.id'),
        subtitle: t('custprov.step.idHint'),
        initial: this.draft.id,
        draftField: 'id',
        parse: text => parseCustomProviderId(text, this.options.takenIds),
      },
      {
        label: t('custprov.step.displayName'),
        subtitle: t('custprov.step.displayNameHint'),
        initial: this.draft.displayName,
        draftField: 'displayName',
        parse: parseCustomDisplayName,
      },
      {
        label: t('custprov.step.protocol'),
        subtitle: t('custprov.step.protocolHint', {
          list: SUPPORTED_PROTOCOLS.join(' · '),
          default: SUPPORTED_PROTOCOLS[0],
        }),
        initial: this.draft.api,
        draftField: 'api',
        parse: parseCustomProtocol,
      },
      {
        label: t('custprov.step.baseUrl'),
        subtitle: t('custprov.step.baseUrlHint'),
        initial: this.draft.baseURL,
        draftField: 'baseURL',
        parse: parseCustomBaseUrl,
      },
      {
        label: t('custprov.step.models'),
        subtitle: t('custprov.step.modelsHint'),
        initial: this.draft.models,
        draftField: 'models',
        parse: parseCustomModels,
      },
      {
        label: t('custprov.step.apiKey'),
        // Edit mode spells out that empty keeps the stored key; a fresh
        // create demands one (a keyless route cannot serve a request).
        subtitle: this.options.edit !== undefined
          ? t('custprov.step.apiKeyHintEdit')
          : t('custprov.step.apiKeyHint'),
        initial: '',
        secret: true,
        parse: text => {
          const key = text.trim()
          if (key === '' && this.options.edit === undefined) {
            return { kind: 'error', error: t('custprov.error.keyEmpty') }
          }
          return { kind: 'value', value: key }
        },
      },
    ]
    return this.options.edit !== undefined ? steps.slice(1) : steps
  }

  /** Build the EditField for the current step; commits advance or finalize. */
  private buildEditor(): EditField {
    const specs = this.specs()
    const spec = specs[this.step]!
    const total = specs.length
    // Set once THIS editor's onCommit ran (a plain advance or the real
    // commit): EditField's onDone fires for both a successful commit AND an
    // Esc, and only the former may advance the chain — an Esc before any
    // commit abandons the whole flow (the key-editor contract).
    let committedThisStep = false
    return new EditField(this.tui, {
      title: t('custprov.step.title', { current: this.step + 1, total, label: spec.label }),
      subtitle: spec.subtitle,
      initial: spec.initial,
      ...(spec.secret === true ? { secret: true } : {}),
      parse: spec.parse,
      onCommit: async outcome => {
        if (outcome.kind !== 'value') return undefined
        const value = String(outcome.value)
        // Stash the normalized value (comma-joined models, default protocol…)
        // so re-entering the step prefills it. The final step (the API key)
        // carries no draft field — it goes straight into the commit.
        if (spec.draftField !== undefined) this.draft[spec.draftField] = value
        committedThisStep = true
        if (this.step < total - 1) return undefined // plain advance
        return this.options.onCommit(buildCustomEntry(this.draft), value)
      },
      onDone: () => {
        // Esc (or a submit that never reached onCommit) abandons the whole
        // flow; closing during a pending final write also lands here with
        // the write already in the chain — exit either way.
        if (!committedThisStep || this.step >= specs.length - 1) {
          this.options.onExit()
          return
        }
        this.step += 1
        this.editor = this.buildEditor()
        this.tui.requestRender()
      },
      onError: message => this.options.onError(message),
    }, this.theme)
  }

  invalidate(): void {
    this.editor.invalidate()
  }

  render(width: number): string[] {
    return this.editor.render(width)
  }

  handleInput(data: string): void {
    this.editor.handleInput(data)
  }
}
