/**
 * Session bridge between the dsh tree and the TUI.
 *
 * Responsibilities:
 * - lazy agent creation on first prompt (openma runner pattern)
 * - prompt delivery via agent.followup()
 * - session-event subscription filtered to the bridge's session
 * - O(1) incremental stats maintained as events arrive (footer reads these —
 *   never re-scans the session log, per the pi-turbo findings)
 * - resume of persisted sessions (log replay into stats + transcript)
 */

import type { Context } from '@deepseek-ai/cordis'
import type { Agent, AgentHandle, AssistantStreamFrame, ModelSelection, ModelSelectionRef } from '@deepseek-ai/dsh-agent'
import { installModelSelection } from '@deepseek-ai/dsh-agent'
import { assistantStreamFirstTokenTime, createUserMessage, type ReasoningEffortId, type StreamChunk, type TokenUsage } from '@deepseek-ai/dsh-llm'
import { SettingsConflictError, type SettingsPathOp } from '@deepseek-ai/dsh-settings'
import { SessionId, SessionLogOffset, type Session, type SessionEvent } from '@deepseek-ai/dsh-session'
import { readAppendSystem } from './append-system.ts'
import { AttentionBoard, type AttentionInfo, type AttentionRow } from './attention.ts'
import type { AttentionJevSource } from './attention-jev.ts'
import { statSync } from 'node:fs'
import { join } from 'node:path'
import type { AgentView, SubagentDescriptorData } from './dsh-events.ts'
import { descriptorModelRoute, isAgentEnd, isAgentStart, isDcpCompactionNotice, isLlmRetry, isSubagentDescriptor, isTuiPluginInjection } from './dsh-events.ts'
import { loadModelProfiles, modelProfilesPath, resolvePinnedProfile } from './model-profiles.ts'
import { installSpawnToolFence, markTuiSurface } from './subagent-policy.ts'
import type { PendingPromptView } from './steer-flow.ts'
import { RemoteSessionTail } from './remote-tail.ts'
import { sessionLogRoot } from './sessions.ts'
import { estimateContentTokens, estimateTextTokens } from './tokens.ts'
import { projectKeyFor } from './session-dir.ts'

/**
 * Register the APPEND_SYSTEM.md section on ONE agent's scoped context, so the
 * user's orchestrator identity applies to the TUI's main agent ONLY. A section
 * registered from the TUI plugin's own (unscoped) context lands in the GLOBAL
 * prompt layer, which every assembly merges - including every subagent's -
 * and an "I am an orchestrator, never execute anything yourself" identity
 * riding on child agents defeats its own purpose. Through the agent's scoped
 * ctx (`agentCtx.systemPrompt` is caller-bound via cordis's traceable
 * services) the section lands in that agent's own scope layer, which nothing
 * else merges: subagent scopes are created without a parent binding, so the
 * children never see it. Same mechanism dsh-subagent uses for per-child
 * personas. Disposal is owned by the agent ctx (`ScopedLayers.effect` runs on
 * `ctx.effect`), so the section dies with the agent.
 */
function installAppendSystem(agentCtx: Context): void {
  const appendSystem = readAppendSystem()   // read once at session startup and cache
  agentCtx.systemPrompt.section({
    name: 'dsh-tui-pi:append-system',
    order: 200,
    text: () => appendSystem,
  })
}

export interface BridgeCallbacks {
  /** One session-log event for the bridge's session, in log order. */
  onEvent(event: SessionEvent): void
  /**
   * One live streaming delta of the bridge's session, delivered as an
   * `agent/assistant-stream` chunk frame (dsh 0.1.5-rc.1 moved the deltas off
   * the `session/event` firehose; the log only records settlements). The
   * turn/step come from the attempt's start frame. Drives the transcript's
   * typewriter and the think/tool phase machine between settlements.
   */
  onStreamDelta?(turn: number, step: number, chunk: StreamChunk): void
  /** Whole-agent lifecycle transition. */
  onStatus(status: 'idle' | 'running'): void
  /**
   * Watched remote session is idle and queued follow-ups await: the bridge
   * already took the writer lock; rebind locally (like a manual /resume)
   * then drain takePendingRemoteFollowups(). Throw ⇒ back to watching;
   * the poll retries. Absent ⇒ queuing still works, waits for manual resume.
   */
  onRemotePromotable?(sessionId: string): Promise<void>
  /** Live snapshot of tracked subagent (child session) rows, on any change. */
  onLive(agents: readonly AgentView[]): void
  /**
   * A tracked child produced one more assistant message — the "rounds" the
   * policy caps (round = one assistant message / LLM round-trip, counted on
   * the child's own `assistant/message` events, not on `turn/end`).
   */
  onRoundCount?(childId: string, count: number): void
}

/**
 * Per-child transcript buffer cap. 2000 events covers a long delegated task's
 * assistant/tool/user rows (~a few hundred KB at worst) while bounding a
 * runaway child; the viewer flags truncation instead of dropping silently.
 */
const CHILD_LOG_CAP = 2000

/**
 * Cadence of the per-child round-count reconcile. The TUI's discovery and
 * fold assume child `session/event` streams bubble here, but in some
 * deployments a subagent's own events never reach this plugin — the child
 * shows up only through the parent's `tool-workflow/agent-start`, so
 * "rounds" stays 0 and the `maxRounds` policy never fires. The reconcile
 * re-derives each child's round count from its authoritative session log
 * (`ctx.sessions`) as a fallback; it only ever moves the count UP past what
 * streamed events already recorded, so the two sources never double count.
 * Rounds are counted on `assistant/message` events (one per LLM round-trip) —
 * a one-shot child never advances `turn/end` while it works.
 */
const ROUND_RECONCILE_MS = 600

/**
 * One-shot cold-start re-seed delay (see the constructor's late-seed leg 2):
 * the first-boot legacy settings.yaml import is fs-local and runs right
 * after the loader settles, so by this point the composed default is final.
 * Overridable via the constructor `lateSeedMs` option (test seam).
 */
const LATE_DEFAULT_SEED_MS = 2500

/** Tail marker for `llm/retry` events (no text content — the row shows it is re-working). */
const RETRY_MARKER = '↻ retry'

/**
 * Estimated tokens of a `tool/result` event's text payload (the tool output
 * that enters the next request). Defensive: reads through an `unknown` shape
 * and never throws. dsh 0.1.7: the result is a role 'tool' message whose
 * `message.content` IS the flat `{ type: 'text', text }` block list — the
 * old nested `content[*].content` tool-result block shape is gone (a V3 log
 * is migrated to V4 framing before it can be read).
 */
function estimateToolResultTokens(data: unknown): number {
  const content = (data as { message?: { content?: unknown } }).message?.content
  if (!Array.isArray(content)) return 0
  const parts: string[] = []
  for (const block of content) {
    if (block === null || typeof block !== 'object') continue
    const b = block as { type?: unknown; text?: unknown }
    if (b.type === 'text' && typeof b.text === 'string') parts.push(b.text)
  }
  return estimateTextTokens(parts.join('\n'))
}

/**
 * Bound of a child's live streaming buffer (text + reasoning deltas): enough
 * to extract the last content line of any real stream, bounded so a runaway
 * child cannot grow the fold unboundedly. Trimmed at line boundaries.
 */
const CHILD_STREAM_CAP = 16_384
/**
 * Live in-flight `tok/s` warmup: a rate computed over the first few hundred
 * ms of a stream is mostly TTFT jitter (2 tokens in 80ms reads as 25 tok/s).
 * The window must be at least this old before `getChildLiveTps` reports.
 */
const LIVE_TPS_WARMUP_MS = 500

/** Strip ANSI SGR escape sequences (the only escapes collected into assistant text). */
function stripAnsi(text: string): string {
  return text.replace(/\x1b\[[0-9;]*m/g, '')
}

/**
 * Last visible text line of an `assistant/message` event's content, or
 * undefined when it carries no text block. Defensive: reads through an
 * `unknown` shape (the declaring package's content model is not imported
 * here) and never throws — a missing/unexpected field simply yields nothing.
 */
function lastTextLine(data: unknown): string | undefined {
  const content = (data as { message?: { content?: unknown } })?.message?.content
  if (!Array.isArray(content)) return undefined
  let blockText: string | undefined
  for (const block of content) {
    const b = block as { type?: string; text?: unknown }
    if (b?.type === 'text' && typeof b.text === 'string' && b.text !== '') {
      blockText = b.text
    }
  }
  if (blockText === undefined) return undefined
  // Last non-blank line of the text body, whitespace-folded so a wrapped/
  // CRLF stream collapses onto one row.
  const body = stripAnsi(blockText).replace(/\r\n/g, '\n').replace(/\r/g, '\n')
  const lines = body.split('\n')
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim()
    if (line === '') continue
    return line.replace(/\s+/g, ' ')
  }
  return undefined
}

/**
 * Append one delta to a child's bounded streaming buffer, trimming whole head
 * lines past CHILD_STREAM_CAP (amortized O(1) per delta — the trim only
 * fires when the buffer outgrows the cap, and each firing drops at least one
 * whole line). The buffer feeds the live content tail: its last non-blank
 * line is what the compact agent row shows while the child streams.
 */
function bumpChildStream(buffer: string, delta: string): string {
  let next = buffer + delta
  while (next.length > CHILD_STREAM_CAP) {
    const nl = next.indexOf('\n')
    if (nl === -1) {
      next = next.slice(-Math.floor(CHILD_STREAM_CAP / 2))
      break
    }
    next = next.slice(nl + 1)
  }
  return next
}

/** Last visible, whitespace-folded line of a raw streaming buffer (see lastTextLine). */
function lastBufferLine(buffer: string): string | undefined {
  const body = stripAnsi(buffer).replace(/\r\n/g, '\n').replace(/\r/g, '\n')
  const lines = body.split('\n')
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim()
    if (line === '') continue
    return line.replace(/\s+/g, ' ')
  }
  return undefined
}

/**
 * First-token time of an `assistant/message`'s embedded stream — the decode
 * window's start. Defensive: the stream is required by the event type but
 * the fold consumes foreign fixtures and replayed logs, and a missing or
 * odd-shaped stream must read as "no timed window", never throw.
 */
function firstTokenOf(stream: unknown): number | undefined {
  return Array.isArray(stream) ? assistantStreamFirstTokenTime(stream) : undefined
}

/** Incrementally maintained footer statistics (all O(1) reads). */
export interface BridgeStats {
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  /** User + assistant surface messages observed. */
  msgCount: number
  toolCallCount: number
  /** Per-route cache-hit rate: cacheReadTokens ÷ billed input (input + cacheRead + cacheWrite) accumulated within the current provider/model segment; reset when the route changes. */
  cacheHitRate?: number
  /**
   * Cache-hit rate of the LATEST assistant/message's own usage —
   * cacheReadTokens ÷ billed input of that single request (input +
   * cacheRead + cacheWrite), the pi-powerline-footer / pi-tui footer
   * semantics. `undefined` until the first usage-bearing assistant/message;
   * never session-cumulative, so a route change shows up on the next message
   * without an explicit reset.
   */
  lastMessageCacheHitRate?: number
  /**
   * Current context occupancy estimate — the value the footer's Context
   * segment divides by the model window: the latest assistant/message's
   * billed input + output plus a CJK estimate of every message appended
   * after it (they enter the next request). NOT the `inputTokens` total —
   * that accumulator only grows within a route segment (it resets when the
   * provider/model route changes), while this tracks the current context so
   * the display follows the latest request and drops after a compaction.
   */
  contextTokens: number
}

/**
 * Cumulative decode-speed accounting — the true generation rate. The window
 * per billed message is first token → assembled `assistant/message` (the
 * same definition as the host's sessionStats projection: TTFT and tool time
 * stay out), tokens are that message's `usage.outputTokens`. All zeros
 * until the first usage-bearing message with a readable embedded stream.
 */
export interface DecodeStats {
  /** Summed decode wall time (ms) over the decode-timed messages. */
  decodeMs: number
  /** Summed provider output tokens over the same decode-timed messages. */
  decodeTokens: number
}

/**
 * Per-model-route attribution of one session's LLM traffic — the "models
 * this session actually billed" view. The route comes from the latest
 * `request/header` before each message; usage-less messages are not
 * attributed (nothing to bill).
 */
export interface RouteUsageStats {
  /** The `provider/model` route. */
  route: string
  /** Billed assistant messages attributed to this route. */
  requests: number
  /** Output tokens billed on this route. */
  outputTokens: number
  /** Decode wall time (ms) attributed to this route. */
  decodeMs: number
  /** Output tokens over the same decode-timed messages. */
  decodeTokens: number
}

export class DshSessionBridge {
  private readonly ctx: Context
  private readonly callbacks: BridgeCallbacks
  private handle: AgentHandle | undefined
  private creating: Promise<AgentHandle> | undefined
  private resuming: Promise<AgentHandle> | undefined
  /** Target id of the in-flight resume — see `resume()`/`getResumingSessionId()`. */
  private resumeTargetId: SessionId | undefined
  /** Active cross-process read-only view (see watchRemote). */
  private remoteTail: RemoteSessionTail | undefined
  /** Session watched read-only right now. */
  private remoteWatchId: string | undefined
  /** Follow-ups typed while watching — sent once promotion wins the lock. */
  private readonly remoteFollowups: string[] = []
  private promotingRemote = false
  private promoteTimer: ReturnType<typeof setInterval> | undefined
  /** Test seam + tuning for the watcher (interval/decoder injection). */
  private readonly remoteTailOptions: { intervalMs?: number; decode?(file: string): Promise<string> }
  private readonly promoteIntervalMs: number
  /** Serializes watch-lifecycle ops against the promotion poll. */
  private opChain: Promise<void> = Promise.resolve()
  private runExclusive<T>(op: () => Promise<T>): Promise<T> {
    const next = this.opChain.then(op, op)
    this.opChain = next.then(() => undefined, () => undefined)
    return next
  }
  private readonly disposers: Array<() => void> = []
  private sessionId: SessionId | undefined
  /** Agent preset id to pass to `meta.agentPreset` on the next `createSession`. */
  private agentPreset: string | undefined
  private selection: ModelSelection | undefined
  /**
   * Whether `selectionRef.current` holds a LIVE USER choice (`/model`,
   * `/think`) rather than a seed. The document-updated re-seed must never
   * clobber a user pick, but MUST be allowed to replace its own earlier
   * seed (see the cold-start comments in the constructor).
   */
  private selectionUserPinned = false
  /** Mutable live selection installed into the agent; `/model` mutates `current`. */
  private readonly selectionRef: ModelSelectionRef = { current: undefined, assembled: undefined }
  /** Mirror of the agent's `agent/status`; `isRunning()` reads this. */
  private running = false
  private readonly stats: BridgeStats = {
    inputTokens: 0,
    outputTokens: 0,
    cacheReadTokens: 0,
    cacheWriteTokens: 0,
    msgCount: 0,
    toolCallCount: 0,
    contextTokens: 0,
  }
  /**
   * Usage snapshot of the LATEST assistant/message — the exact billed context
   * of the last request (input = uncached, cache read/write billed on top;
   * output = that request's own output). The footer's context segment prices
   * this plus `pendingTokens` (see BridgeStats.contextTokens). `undefined`
   * until the first assistant/message arrives.
   */
  private lastUsage: TokenUsage | undefined
  /**
   * CJK-estimated tokens of every message appended AFTER the latest
   * assistant/message (user prompts, tool results, streamed text deltas) —
   * they enter the next request. Reset to 0 by the next assistant/message,
   * whose usage snapshot then covers them exactly.
   */
  private pendingTokens = 0
  /**
   * Decode-speed accounting of the MAIN session (see {@link DecodeStats}) —
   * summed first-token → message windows and their output tokens, attributed
   * per route below. Reset by replay/detach like the rest of the stats.
   */
  private decodeMs = 0
  private decodeTokens = 0
  /**
   * The route of the LATEST `request/header` — every billed message between
   * two headers belongs to it. Route attribution is replay-safe because the
   * headers are log events like the messages they prefix.
   */
  private currentRoute: string | undefined
  /** Per-route usage attribution of the main session (insertion-ordered). */
  private readonly routeUsage = new Map<string, RouteUsageStats>()
  /**
   * Per-child decode-speed accounting (see {@link DecodeStats}) — the
   * subagent viewer's cumulative `tok/s`. Event-path only, like the child
   * token totals; a redelivered `assistant/message` double-counts (same
   * accepted exposure as the streamed round ledger).
   */
  private readonly childDecode = new Map<string, DecodeStats>()
  /**
   * Per-child LIVE decode window: opened by the first streamed delta after
   * the previous message settled, closed by the next `assistant/message`.
   * Feeds the in-flight `~N tok/s` (an estimate — the exact output count is
   * only known at settlement).
   */
  private readonly childLive = new Map<string, { firstTokenAt: number; tokens: number }>()
  /** Live subagent rows keyed by child session id. */
  private readonly agentViews = new Map<string, AgentView>()
  /** Child session ids whose own events we fold into the agent views. */
  private readonly childSessions = new Set<string>()
  /**
   * Per-child event ring buffer — the raw transcript the subagent viewer
   * renders. Capped so a runaway child cannot grow the process unboundedly;
   * the oldest events drop off (the viewer shows a "history truncated" hint
   * when the cap is hit).
   */
  private readonly childLogs = new Map<string, SessionEvent[]>()
  /**
   * Per-child bounded streaming buffer (text + reasoning deltas) — the live
   * content tail the compact agent row shows while the child streams. The
   * assembled `assistant/message` replaces it with the authoritative last
   * line and deletes the entry.
   */
  private readonly childStreams = new Map<string, string>()
  /**
   * Per-child assistant-message count — the "rounds" the policy caps. One
   * increment per `assistant/message` (an LLM round-trip), counted on the
   * child's OWN events. Settled children keep counting (a continuable child
   * resumes later), so the count stays authoritative for the viewer and the
   * wrap-up policy.
   */
  private readonly roundCounts = new Map<string, number>()
  /**
   * The EVENT path's own absolute per-child assistant-message count — its
   * ledger of streamed `assistant/message` events it has actually received.
   * The reconcile derives its own count from the session log; the displayed
   * "rounds" is `max(streamed, reconciled)` (see foldTracked). Keeping the
   * two ledgers separate is what makes a message the reconcile already
   * counted immune to a second count when its streamed event arrives late.
   */
  private readonly streamedRoundCounts = new Map<string, number>()
  /**
   * Per-child usage snapshot of the latest assistant/message (see
   * `lastUsage` for the main session) — the exact billed context of the
   * child's last request, the `contextTokens` baseline.
   */
  private readonly childUsage = new Map<string, TokenUsage>()
  /**
   * Per-child CJK-estimated tokens of messages appended after the latest
   * assistant/message (see `pendingTokens` for the main session) — the
   * `contextTokens` increment that makes the compact `X/Y` follow live.
   */
  private readonly childPending = new Map<string, number>()
  /**
   * Per-child dsh-dcp compaction count — one per `user/message` notice whose
   * source is `{ kind: 'plugin', plugin: 'dsh-dcp', form: 'notice' }`. The
   * viewer's picker rows read this via `getChildCompactionCount` so the user
   * sees at a glance whether DCP actually compacted inside a child.
   */
  private readonly childCompactionCounts = new Map<string, number>()
  /**
   * Per-child session-log length already reconciled (see
   * reconcileChildRounds). Incremental high-water, so the reconcile scans
   * only newly-appended events.
   */
  private readonly reconciledLen = new Map<string, number>()
  /** Per-child round count derived from the session log by the reconcile. */
  private readonly reconciledCount = new Map<string, number>()
  /**
   * Session ids that can own tracked children (this session first, then every
   * tracked child — delegation nests). Used to match `parentSession` headers
   * and to fold workflow events of the parent log.
   */
  private readonly trackedSessions = new Set<string>()
  /** `${runId}:${seq}` → childId, for `tool-workflow/agent-end` pairing. */
  private readonly runSeqToChild = new Map<string, string>()
  /**
   * Session id → the open attempt's turn/step, pinned by `agent/assistant-stream`
   * start frames so chunk frames (which carry no turn/step) can drive the same
   * fold paths the old firehose `assistant/chunk` events did. Cleared on end.
   */
  private readonly openAttempts = new Map<string, { turn: number; step: number }>()

  constructor(ctx: Context, callbacks: BridgeCallbacks, options: {
    remoteTailOptions?: { intervalMs?: number; decode?(file: string): Promise<string> }
    promoteIntervalMs?: number
    lateSeedMs?: number
  } = {}) {
    this.ctx = ctx
    this.callbacks = callbacks
    this.remoteTailOptions = options.remoteTailOptions ?? {}
    this.promoteIntervalMs = options.promoteIntervalMs ?? 1000
    // Footer cold start: seed ONLY the cwd `.dsh-profile` pin here — the pin
    // reads local files, so it is stable from the very first frame. The
    // composed default (`agentDefaultModel`) is deliberately NOT read yet: on
    // a host first boot the legacy settings.yaml import lands asynchronously
    // AFTER this constructor, and an eager read would freeze the built-in
    // default into `selectionRef.current` — which seedSelectionFromDefault
    // then treats as a live user choice and refuses to overwrite. The footer
    // renders its empty-model branch until the re-seeds below fill it;
    // "the footer may arrive a little late" is the agreed trade (session
    // creation itself re-seeds anyway).
    this.selection = this.pinnedRouteSelection()
    // Late seed, leg 1 — `settings/document-updated`: once the settings
    // document settles (the first-boot settings.yaml import, a /settings
    // write, …), force a re-seed while it is still safe: no live session
    // (a session is bound to the selection it was created under) and no
    // user choice (a /model pick outranks every default). FORCE matters:
    // the first document-updated can fire while the import has NOT landed
    // yet (the host's first describe pass), and that early seed leaves the
    // built-in default in `selectionRef.current` — a plain re-seed would
    // treat it as a live choice and keep it frozen. Forcing re-derives the
    // composed default, which by the import's own event is the imported
    // value. Idempotent and inert once a session exists or the user chose.
    this.disposers.push(ctx.on('settings/document-updated', () => {
      if (this.handle === undefined && !this.selectionUserPinned) this.seedSelectionFromDefault(true)
    }))
    // Late seed, leg 2 — one-shot unref timer: belt-and-braces for the
    // ordering where every document-updated fires before this constructor's
    // subscription arms (or none follows the import). The first-boot import
    // is fs-local and runs right after the loader settles, so a few seconds
    // in, the composed default is final; one recompute converges the footer.
    const lateSeed = setTimeout(() => {
      if (this.handle === undefined && !this.selectionUserPinned) this.seedSelectionFromDefault(true)
    }, options.lateSeedMs ?? LATE_DEFAULT_SEED_MS)
    lateSeed.unref?.()
    this.disposers.push(() => clearTimeout(lateSeed))
    this.disposers.push(ctx.on('session/event', (session: Session, event: SessionEvent) => {
      const sessionKey = String(session.id)
      // Discover subagent children by session header — the deployment may
      // never emit tool-workflow events (the firehose is not scope-filtered,
      // so child sessions arrive here too). The gate is shared with the
      // reconcile tick's live-store sweep (`reconcileLiveFromStore`).
      if (this.adoptChildSession(session, event.time)) this.emitLive()
      // Fold workflow + child events for every tracked session.
      if (this.trackedSessions.has(sessionKey)) {
        this.foldTracked(sessionKey, event)
      }
      // Buffer the child's OWN log for the viewer (not the parent's workflow
      // rows, which carry no child transcript). The buffer is capped; the
      // viewer reports truncation when the head dropped off.
      if (this.childSessions.has(sessionKey)) {
        this.appendChildLog(sessionKey, event)
      }
      if (this.sessionId !== undefined && session.id === this.sessionId) {
        this.applyEvent(event)
        this.callbacks.onEvent(event)
      }
    }))
    // dsh 0.1.5-rc.1: the incremental streaming deltas left the firehose (it
    // now delivers settlements only) and moved to per-agent
    // `agent/assistant-stream` frames — start pins the attempt's turn/step,
    // chunk frames carry the raw deltas, end closes the attempt. Root-scope
    // listening sees every agent; frames route by session id: the bridge's
    // own session drives the transcript/typewriter + occupancy estimate,
    // tracked children fold into the live rows' content tail.
    this.disposers.push(ctx.on('agent/assistant-stream', ({ agent, frame }: { agent: Agent; frame: AssistantStreamFrame }) => {
      try {
        this.onStreamFrame(String(agent.id), frame)
      } catch {
        // A malformed frame must never take the bridge down.
      }
    }))
    this.disposers.push(ctx.on('agent/status', ({ agent, status }: { agent: { id: string }; status: 'idle' | 'running' }) => {
      if (this.handle === undefined || agent.id !== this.handle.agent.id) return
      this.running = status === 'running'
      this.callbacks.onStatus(status)
    }))
    // Round-count reconcile fallback: keep "rounds" and the maxRounds policy
    // live even when a child's own events never bubble to this plugin (see
    // ROUND_RECONCILE_MS). Runs regardless of whether the viewer is open — the
    // cap must still fire while the child works in the background.
    const reconcile = setInterval(() => {
      try {
        // Live-store sweep first (dsh 0.1.7-rc.2 companion): a child adopted
        // here is in childSessions before the round reconcile scans it, so a
        // recovered child gets its rounds the same tick.
        this.reconcileLiveFromStore()
        this.reconcileChildRounds()
        // The projection-backed reconciliation rides the same cadence but is
        // async and self-guarded (never overlaps itself).
        void this.reconcileLiveWithProjection()
        // Attention ranking re-observe (heuristic recompute is a map walk;
        // the jev layer self-debounces inside its source).
        this.updateAttention()
      } catch {
        // A throwing reconcile must never take the process down.
      }
    }, ROUND_RECONCILE_MS)
    reconcile.unref?.()
    this.disposers.push(() => clearInterval(reconcile))
  }

  /** Whether a `reconcileLiveWithProjection` pass is already in flight. */
  private projectionReconcileInFlight = false

  /**
   * Shared child-adoption gate for the two discovery paths: the firehose
   * `session/event` fold (constructor) and the reconcile tick's live-store
   * sweep (`reconcileLiveFromStore`). A session whose parent is a tracked
   * session AND is marked as delegated is a child; the descriptor event
   * later refines the label/provider.
   *
   * Guard: a child is `origin: 'subagent'` OR a delegation budget
   * `delegationDepth > 0`. Both markers are written together by dsh's
   * childSessionMeta (spawn AND in-process fork children alike), so in
   * practice the origin alone carries the decision; the budget clause
   * only future-proofs the gate against a child that carries the budget
   * without the origin. The budget test MUST be a VALUE test, not a
   * field-presence test: the jsonl persistence backend materialises
   * `delegationDepth: 0` on every restored header (write `?? 0`, read
   * unconditionally), so a presence test would pull user-facing
   * `Session.fork` conversations and other non-child restored sessions
   * onto the live board / Ctrl+G.
   *
   * @returns whether a new view was adopted (caller emits).
   */
  private adoptChildSession(session: Session, startedAt: number): boolean {
    const sessionKey = String(session.id)
    const header = session.header
    if (header?.parentSession === undefined
      || (header.origin !== 'subagent' && (header.delegationDepth ?? 0) <= 0)
      || !this.trackedSessions.has(String(header.parentSession))
      || this.agentViews.has(sessionKey)) return false
    this.agentViews.set(sessionKey, {
      childId: sessionKey,
      parentSession: String(header.parentSession),
      // Current dsh children always carry the origin, so in practice the
      // label is `subagent <id8>`; the `fork` label only fires for the
      // defensive budget-without-origin shape above.
      label: header.origin === undefined
        ? `fork ${sessionKey.slice(0, 8)}`
        : `subagent ${sessionKey.slice(0, 8)}`,
      startedAt,
      tokens: 0,
      rounds: 0,
      retries: 0,
      contextTokens: 0,
    })
    this.childSessions.add(sessionKey)
    this.trackedSessions.add(sessionKey)
    return true
  }

  /**
   * Live-store sweep — the corpus-level companion to
   * `reconcileLiveWithProjection` (dsh 0.1.7-rc.2). `listDescendants` walked
   * the complete Session corpus on rc.1 but recurses parent CATALOGS on
   * rc.2, so a child whose catalog branch is corrupt/unreadable — or whose
   * catalog entry is missing entirely — is omitted from the authoritative
   * listing with no diagnostic row of its own. Every still-working child
   * necessarily resides in the process, and the store's live list is the one
   * enumeration that depends on no catalog: this sweep re-runs the shared
   * adoption gate over `sessions.list()` each tick and picks up what both
   * the firehose (burst-lost creation events) and the catalog walk missed.
   * Merge discipline is the bridge-wide one — only ADD (the
   * `agentViews.has` guard makes it idempotent and never resurrects a
   * settled view); rounds/settlement continue through the ordinary fold
   * paths once the child is in `childSessions`/`trackedSessions`. Cost is
   * one header check per process-resident session per tick — no persistence
   * read, and children of previous runs are not resident after a restart,
   * so they cannot be resurrected onto the board.
   */
  private reconcileLiveFromStore(): void {
    const sessions = this.ctx.get('sessions') as
      | { list?(): readonly Session[] }
      | undefined
    if (sessions?.list === undefined) return
    let changed = false
    for (const session of sessions.list()) {
      if (this.adoptChildSession(session, Date.now())) changed = true
    }
    if (changed) this.emitLive()
  }

  /**
   * Correct the live view against the host's authoritative descendant
   * listing (`SubagentRuntime.listDescendants`, projection-backed — no
   * firehose dependency). Two failure shapes this fixes:
   *
   * 1. Burst under-count: parallel spawns all pass the guard before their
   *    events reach the firehose fold, so `getLiveChildren` reads low and
   *    the maxAgents cap overshoots until events catch up. The authoritative
   *    `activity: 'running'` list re-adds the missing children (as
   *    header-discovery-shaped views) within one reconcile tick.
   * 2. The dead-at-zero counts of children whose own events never bubble to
   *    this plugin: a discovered-but-eventless child still gets its view
   *    (rounds then come from `reconcileChildRounds`' log scan, which needs
   *    the child IN `childSessions` — this pass is what adds it).
   *
   * Merge discipline: only ADD missing live children and only SETTLE views
   * the listing reports inactive-and-one-shot — never remove, never
   * resurrect a settled continuable (its listing row is `inactive` while it
   * idles between turns). Runs best-effort: an absent/unshaped subagents
   * service or a throwing listing is silently skipped.
   *
   * dsh 0.1.7-rc.2: the listing recurses parent CATALOGS instead of walking
   * the complete Session corpus — a child behind a corrupt/unreadable
   * catalog branch is reported only as a branch diagnostic, and a truly
   * catalog-less orphan is invisible (no row at all). Diagnostic rows are
   * skipped here; the {@link reconcileLiveFromStore} sweep is the
   * corpus-level companion that keeps such children off the blind spot.
   */
  private async reconcileLiveWithProjection(): Promise<void> {
    if (this.projectionReconcileInFlight) return
    const root = this.sessionId
    if (root === undefined) return
    // ctx.get (NOT property access) — see the sessions accessor note above.
    // Inline rc.2 `SubagentDescendantListEntry` union: child rows (catalog
    // walk) and branch diagnostics share the list; `kind` has been on every
    // row since rc.1, so the discriminator is floor-safe.
    const subagents = this.ctx.get('subagents') as
      | {
          listDescendants(rootSessionId: SessionId, signal?: AbortSignal): Promise<
            readonly (
              | {
                  readonly kind: 'child'
                  readonly id: SessionId
                  readonly activity: 'running' | 'inactive'
                  readonly mode?: 'one-shot' | 'continuable'
                  readonly label?: string
                  readonly hasChildren?: boolean
                  readonly parentId?: SessionId
                  readonly depth?: number
                }
              | {
                  readonly kind: 'diagnostic'
                  readonly id: SessionId
                  readonly reason: 'corrupt' | 'unsupported' | 'unavailable'
                }
            )[]
          >
        }
      | undefined
    if (subagents?.listDescendants === undefined) return
    this.projectionReconcileInFlight = true
    try {
      const entries = await subagents.listDescendants(root)
      const rootKey = String(root)
      let changed = false
      for (const entry of entries) {
        // A branch diagnostic (corrupt/unavailable/unsupported) names no
        // child row — skipping it here is what the sweep above covers for.
        if (entry.kind === 'diagnostic') continue
        const childKey = String(entry.id)
        if (childKey === rootKey) continue
        // A running child this bridge never discovered (burst, or its events
        // never bubbled). Register it header-discovery-shaped; descriptor
        // refinement (label/mode/route) follows from the listing itself. A
        // child already on the board needs no listing re-add — its own events
        // drive the fold. (The existence guard lives HERE, not on the loop
        // head: the settle arm below must still reach existing views — a
        // loop-head guard made it dead code and stale one-shots lingered on
        // the board holding maxAgents slots.)
        if (entry.activity === 'running') {
          if (this.agentViews.has(childKey)) continue
          this.agentViews.set(childKey, {
            childId: childKey,
            parentSession: entry.parentId !== undefined ? String(entry.parentId) : undefined,
            ...(entry.mode !== undefined ? { mode: entry.mode } : {}),
            ...(entry.label !== undefined ? { label: entry.label } : { label: `subagent ${childKey.slice(0, 8)}` }),
            startedAt: Date.now(),
            tokens: 0,
            rounds: 0,
            retries: 0,
            contextTokens: 0,
          })
          this.childSessions.add(childKey)
          this.trackedSessions.add(childKey)
          changed = true
        }
        // Settle a one-shot child the listing reports inactive: its listing
        // row is authoritative (a missed `turn/end` fold would otherwise
        // keep it on the live board forever, holding a maxAgents slot).
        else if (entry.mode === 'one-shot') {
          const view = this.agentViews.get(childKey)
          if (view !== undefined && view.outcome === undefined && view.injectedAt === undefined) {
            this.agentViews.set(childKey, { ...view, outcome: 'completed', endedAt: Date.now() })
            changed = true
          }
        }
        // Inactive continuable: idling between turns — deliberately left
        // live. Its turn-end fold (or a later pass) settles it.
      }
      if (changed) this.emitLive()
    } catch {
      // Projection unavailable or the listing threw — firehose fold remains
      // the source of truth for this tick.
    } finally {
      this.projectionReconcileInFlight = false
    }
  }

  /**
   * Re-derive each tracked child's round count from its own session log
   * (`ctx.sessions`), the authoritative append-only facts. The firehose
   * assumption behind discovery/fold is unreliable in some deployments — a
   * child is listed from the parent's `tool-workflow/agent-start` but its own
   * `assistant/message` events never arrive, which leaves both the rounds
   * display and the `maxRounds` policy dead at 0. This corrects the count UP
   * past whatever the streamed events already recorded (never down, never
   * re-adding what events counted), and fires `onRoundCount` so the cap still
   * guards a child whose events were never delivered. Rounds are counted on
   * `assistant/message` (one per LLM round-trip — `turn/end` is structurally
   * inert for a one-shot child that never leaves its single turn). Scans only
   * newly-appended events per child.
   */
  private reconcileChildRounds(): void {
    // ctx.get (NOT property access): `sessions` is not in this plugin's
    // inject list, and a cordis Context property access for a non-injected
    // service throws "cannot get property ... without inject" — the property
    // form silently killed every reconcile tick behind the interval's catch.
    const sessions = this.ctx.get('sessions') as
      | { get(id: SessionId): Session | undefined }
      | undefined
    if (sessions === undefined) return
    let viewsChanged = false
    for (const childId of this.childSessions) {
      const session = sessions.get(SessionId(childId))
      if (session === undefined) continue
      // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in
      // favor of projection registration / handle.read() pagination. Kept on
      // this HOT path deliberately — the reconcile is already incremental
      // (the reconciledLen watermark scans only new events per tick), and the
      // projection successor serves folds, not raw assistant/message counts.
      // (T14 review.)
      const events = session.snapshotEvents()
      const len = events.length
      let from = this.reconciledLen.get(childId) ?? 0
      // A torn-down / re-seeded child session restarts its log — recount it.
      if (from > len) {
        this.reconciledLen.set(childId, 0)
        this.reconciledCount.set(childId, 0)
        from = 0
      }
      if (from >= len) continue
      let added = 0
      let descriptor: SessionEvent & { type: 'subagent/descriptor'; data: SubagentDescriptorData } | undefined
      for (let i = from; i < len; i++) {
        const event = events[i]!
        if (event.type === 'assistant/message') added += 1
        else if (isSubagentDescriptor(event)) descriptor = event
      }
      const absolute = (this.reconciledCount.get(childId) ?? 0) + added
      this.reconciledLen.set(childId, len)
      this.reconciledCount.set(childId, absolute)
      const current = this.roundCounts.get(childId) ?? 0
      if (absolute > current) {
        this.roundCounts.set(childId, absolute)
        this.callbacks.onRoundCount?.(childId, absolute)
      }
      // Label refinement for children whose descriptor never reaches the
      // firehose. A BACKGROUND continuable child (dsh-subagent-registry's
      // use_agent background leg, any native continuable spawn) gets its
      // descriptor written as part of the child's constructor seed — and
      // constructor seeds do not emit `session/event` (dsh-session's
      // firstLiveSeq contract), so the foldTracked refinement at the
      // `subagent/descriptor` case never fires and the view keeps the
      // discovery label `subagent <id8>` forever. The user then cannot tell
      // a registered agent's background run from an anonymous spawn. The
      // in-process log here is authoritative (seeds included), so the scan
      // above picks the descriptor up and the same refinement rules as the
      // event path apply: provider/mode always, label only when present.
      // Foreground one-shot children already refined over the firehose are
      // a no-op (the change gate below compares before setting).
      if (descriptor !== undefined) {
        const view = this.agentViews.get(childId)
        if (view !== undefined
          && (view.provider !== descriptor.data.provider
            || view.mode !== descriptor.data.mode
            || (descriptor.data.label !== undefined && view.label !== descriptor.data.label))) {
          this.agentViews.set(childId, {
            ...view,
            provider: descriptor.data.provider,
            mode: descriptor.data.mode,
            ...(descriptor.data.label === undefined ? {} : { label: descriptor.data.label }),
          })
          viewsChanged = true
        }
      }
    }
    if (viewsChanged) this.emitLive()
  }

  /** Snapshot of the incremental stats (footer reads this O(1)). */
  getStats(): BridgeStats {
    return { ...this.stats }
  }

  /**
   * The MAIN session's decode-speed accounting: the cumulative window sums
   * plus the per-route attribution (the "models this session billed" list,
   * first-request order). Defensive copies — callers may hold the snapshot.
   */
  getDecodeStats(): DecodeStats & { routes: readonly RouteUsageStats[] } {
    return {
      decodeMs: this.decodeMs,
      decodeTokens: this.decodeTokens,
      routes: [...this.routeUsage.values()].map(entry => ({ ...entry })),
    }
  }

  /** One child's cumulative decode-speed accounting (viewer header). */
  getChildDecodeStats(childId: string): DecodeStats {
    return this.childDecode.get(childId) ?? { decodeMs: 0, decodeTokens: 0 }
  }

  /**
   * One child's LIVE in-flight decode rate (tok/s), while a message is
   * streaming: estimated streamed tokens over the live window's elapsed
   * time. Undefined before a short warmup (an absurd rate over the first
   * few hundred ms) and whenever no window is open. The settled
   * `getChildDecodeStats` average replaces it once the message lands.
   */
  getChildLiveTps(childId: string, now: number = Date.now()): number | undefined {
    const live = this.childLive.get(childId)
    if (live === undefined) return undefined
    if (now - live.firstTokenAt < LIVE_TPS_WARMUP_MS) return undefined
    return live.tokens / ((now - live.firstTokenAt) / 1000)
  }

  /** Current session id, when one exists. */
  getSessionId(): SessionId | undefined {
    return this.sessionId
  }

  /**
   * Session id a `resume()` is currently loading, when one is in flight;
   * `undefined` once the resume settles (then `getSessionId()` reports it
   * instead, or nothing on failure). Published synchronously before any
   * await so pollers see it for the WHOLE load: the startup retention
   * janitor unions this with the current id — deleting the target
   * directory mid-load would destroy the log the resume is reading.
   */
  getResumingSessionId(): SessionId | undefined {
    return this.resumeTargetId
  }

  /** Sorted snapshot of every tracked child (running and settled), with the
   *  policy's hard-stop records composed in (they live off-view — see
   *  markChildHardStopped). */
  getAgentViews(): readonly AgentView[] {
    return [...this.agentViews.values()].sort(
      (a, b) => a.startedAt - b.startedAt || a.childId.localeCompare(b.childId),
    ).map(view => {
      const hs = this.hardStopRecords.get(view.childId)
      return hs === undefined || view.hardStop !== undefined ? view : { ...view, hardStop: hs }
    })
  }

  /**
   * Attach the attention ranking's jev upgrade source (heuristic-only when
   * undefined) and the live maxRounds reader for the ranking's state table.
   * Wired once by the host; the source self-debounces and self-guards.
   */
  attachAttentionSource(source: AttentionJevSource | undefined, capReader: () => number): void {
    this.attentionSource = source
    this.attentionCapReader = capReader
  }

  /** Re-observe the attention ranking; driven by the reconcile tick. */
  private updateAttention(): void {
    const views = this.getLiveChildren()
    const cap = this.attentionCapReader?.() ?? 0
    this.attentionBoard.update(views, cap)
    this.attentionSource?.tick(this.attentionBoard, views, cap)
  }

  /** One child's current attention info (heuristic base; jev once it has judged). */
  getAttention(childId: string): AttentionInfo | undefined {
    return this.attentionBoard.get(childId)
  }

  /** The spin-strike state for one child (the early-stop ladder's input). */
  getSpinState(childId: string): { streak: number; lastStrikeAt: number } {
    return this.attentionBoard.spinState(childId)
  }

  /** All attention rows, highest score first (picker sort, status board). */
  getAttentionRows(): readonly AttentionRow[] {
    return this.attentionBoard.rows()
  }

  /** The guard deny-copy hint: the top attention-worthy live child, when one ranks above ok. */
  getAttentionHint(): { label: string; detail: string } | undefined {
    return this.attentionBoard.topHint()
  }

  /** Children still running (`outcome` unset) — the live count the guard caps. */
  getLiveChildren(): readonly AgentView[] {
    return this.getAgentViews().filter(view => view.outcome === undefined)
  }

  /** The buffered transcript of one child, in log order (capped, maybe truncated). */
  getChildLog(childId: string): readonly SessionEvent[] {
    return this.childLogs.get(childId) ?? []
  }

  /** Assistant-message count of one child ("rounds" — the policy cap unit). */
  getRoundCount(childId: string): number {
    return this.roundCounts.get(childId) ?? 0
  }

  /** dsh-dcp compaction count of one child (viewer picker rows). */
  getChildCompactionCount(childId: string): number {
    return this.childCompactionCounts.get(childId) ?? 0
  }

  /** Whether one child settled (a continuable child may resume later). */
  isChildSettled(childId: string): boolean {
    return this.agentViews.get(childId)?.outcome !== undefined
  }

  /** True when the child's buffered transcript dropped its oldest events. */
  isChildLogTruncated(childId: string): boolean {
    return (this.childLogs.get(childId)?.length ?? 0) >= CHILD_LOG_CAP
  }

  /** Queue one user prompt, creating the session lazily on first use. */
  async prompt(text: string): Promise<void> {
    if (this.remoteTail !== undefined) {
      // Lockless viewer: never refuse, QUEUE. The promote poll sends it the
      // moment the driver goes idle and we win the writer lock.
      this.remoteFollowups.push(text)
      return
    }
    const handle = await this.ensureSession()
    const message = createUserMessage({
      content: [{ type: 'text', text }],
      source: { kind: 'user' },
    })
    handle.agent.followup(message)
  }

  /** While a remote watch is active input QUEUES instead of driving. */
  isReadOnlyView(): boolean {
    return this.remoteTail !== undefined
  }

  /** Follow-ups typed while watching, oldest first; takes them all. */
  takePendingRemoteFollowups(): string[] {
    return this.remoteFollowups.splice(0)
  }

  /**
   * READ-ONLY cross-process view: another dsh process drives this session
   * (the single-writer guard refused our cold resume), so sync DISPLAY from
   * its persisted log instead — poll-decode, emit durable events through
   * the same render pipeline a live session uses. Contract: latency ≈ poll
   * interval, streaming detail omitted, every turn's final assistant
   * message arrives. Replaces any prior binding; ends via stopRemoteWatch
   * on dispose or the next resume.
   */
  watchRemote(sessionId: string): Promise<void> {
    return this.runExclusive(() => this.watchRemoteInner(sessionId))
  }

  private async watchRemoteInner(sessionId: string): Promise<void> {
    await this.stopRemoteWatch()
    // The jsonl backend's own dir derivation — no cwd, no view.
    const cwd = await this.headerCwdOf(sessionId)
    if (cwd === undefined) throw new Error(`cannot locate the log of ${sessionId} for read-only viewing`)
    const dir = join(sessionLogRoot(), projectKeyFor(cwd), sessionId)
    // The artifact name carries the format generation since the V3 format
    // (session.v3.jsonl[.zstd]); legacy sessions keep session.jsonl[.zstd].
    // Prefer the current generation, compressed over raw; when nothing is
    // on disk yet, fall back to the legacy canonical name — the tail
    // tolerates a not-yet-existing file.
    const candidates = [
      'session.v3.jsonl.zstd',
      'session.v3.jsonl',
      'session.jsonl.zstd',
      'session.jsonl',
    ]
    let file = join(dir, 'session.jsonl.zstd')
    for (const name of candidates) {
      const candidate = join(dir, name)
      try {
        statSync(candidate)
        file = candidate
        break
      } catch {
        // Not this name — try the next one.
      }
    }
    // The firehose gate uses this id; harmless cross-process (nothing in
    // THIS process will publish for it) and required so a later local agent
    // for the SAME id (post-switch) re-binds cleanly.
    this.sessionId = SessionId(sessionId)
    this.handle = undefined
    this.remoteWatchId = sessionId
    const tail = new RemoteSessionTail(file, {
      onEvents: events => {
        // A stopped tail's in-flight final tick must not paint after detach.
        if (this.remoteTail !== tail) return
        for (const raw of events) {
          const event = raw as unknown as SessionEvent
          // Per-event containment mirrors the firehose listener contract:
          // one unsupported/malformed row must not kill the rest of the
          // view batch. Projection and render dispatch are contained
          // SEPARATELY so a projection gap cannot suppress rendering.
          try {
            this.applyEvent(event)
          } catch {
            /* projection drift — the view row still renders below */
          }
          try {
            this.callbacks.onEvent(event)
            if (event.type === 'turn/start') {
              this.running = true
              this.callbacks.onStatus('running')
            } else if (event.type === 'turn/end') {
              this.running = false
              this.callbacks.onStatus('idle')
            }
          } catch {
            /* contained — keep rendering the remaining events */
          }
        }
      },
    }, this.remoteTailOptions)
    this.remoteTail = tail
    // Deterministic backfill before returning: callers may render/report
    // immediately; live ticks continue on the poll cadence afterwards.
    await tail.tickOnce()
    tail.start()
    // Promotion lives OUTSIDE the event stream: one independent poll checks
    // (queue non-empty ∧ driver idle ∵ running flag ∧ lock winnable). This
    // keeps takeover state transitions off the render path entirely.
    if (this.promoteTimer === undefined) {
      this.promoteTimer = setInterval(() => void this.maybePromoteRemote(), this.promoteIntervalMs)
    }
  }

  private async stopRemoteWatch(): Promise<void> {
    if (this.promoteTimer !== undefined) {
      clearInterval(this.promoteTimer)
      this.promoteTimer = undefined
    }
    this.remoteWatchId = undefined
    if (this.remoteTail === undefined) return
    this.remoteTail.stop()
    this.remoteTail = undefined
  }

  /**
   * Promote poll tick: viewer + queued follow-ups + watched driver gone →
   * attempt the takeover (onRemotePromotable rebuilds the UI via resume +
   * queue drain); an owned session still refuses the resume and we retry
   * next tick. All async sequencing stays in THIS loop — never inside
   * event callbacks.
   */
  private maybePromoteRemote(): Promise<void> {
    return this.runExclusive(async () => {
      await this.maybePromoteRemoteInner()
    })
  }

  private async maybePromoteRemoteInner(): Promise<void> {
    if (this.promotingRemote || this.running) return
    const id = this.remoteWatchId
    if (id === undefined || this.remoteFollowups.length === 0) return
    const promote = this.callbacks.onRemotePromotable
    if (promote === undefined) return
    this.promotingRemote = true
    await this.stopRemoteWatch() // ends the view BEFORE any UI rebuild
    try {
      await promote(id)
      this.promotingRemote = false
    } catch {
      // The takeover failed — the other process still owns the session (the
      // host lease refused the resume) or the rebuild broke: back to
      // spectating; a later poll retries once the owner lets go.
      this.promotingRemote = false
      await this.watchRemote(id).catch(() => {})
    }
  }

  /** The live agent, creating the session lazily when needed. */
  async ensureAgent(): Promise<Agent> {
    const handle = await this.ensureSession()
    return handle.agent
  }

  /** The live agent when a session already exists (no creation side effect). */
  getAgent(): Agent | undefined {
    return this.handle?.agent
  }

  /**
   * Snapshot of the live agent's PENDING prompts — submitted but not yet
   * claimed by the inbox (docs/design-steer-followup.md: the only removable /
   * re-routeable stage). Reads the agent's own inbox projection O(1): the
   * next-step list (steering, `↪`) then next-turn (queued follow-ups,
   * `⏳`). Each view keeps the original message identity so a promote
   * re-sends the exact queued object. Empty without a live agent.
   */
  getPendingPrompts(): readonly PendingPromptView[] {
    const agent = this.handle?.agent
    if (agent === undefined) return []
    const fold = (message: { content: ReadonlyArray<{ type: string; text?: string }> }): string => {
      let text = ''
      for (const block of message.content) {
        if (block.type === 'text' && typeof block.text === 'string') {
          text += (text === '' ? '' : ' ') + block.text
        }
      }
      return text.trim()
    }
    const views: PendingPromptView[] = []
    for (const message of agent.inbox.nextStep) {
      views.push({ id: String(message.id), text: fold(message), target: 'next-step', message })
    }
    for (const message of agent.inbox.nextTurn) {
      views.push({ id: String(message.id), text: fold(message), target: 'next-turn', message })
    }
    return views
  }

  /** Whether the bridge's agent is mid-turn (mirror of `agent/status`). */
  isRunning(): boolean {
    return this.running
  }

  /**
   * Abort the bridge's agent mid-turn, mirroring the web client's stop
   * button: the host-side `session.cancel` handler calls
   * `agent.cancel({ kind: 'user' }, { keepInbox: true })`
   * (dsh-host-apiproxy), and that is exactly what the agent's public
   * synchronous `cancel(cause, options)` API takes. `keepInbox` preserves
   * queued prompts for a later turn; the active driver's AbortSignal fires
   * and status converges to `idle` via the existing subscription. The API
   * is fire-and-forget — the returned promise resolves once the call is
   * made, not when the turn settles.
   * @returns false when there is no agent or it is not running; true once
   *   the cancellation was issued.
   */
  async cancelActiveTurn(): Promise<boolean> {
    const agent = this.handle?.agent
    if (agent === undefined || !this.running) return false
    try {
      agent.cancel({ kind: 'user' }, { keepInbox: true })
      return true
    } catch {
      // Cancellation must never take the input path down with it.
      return false
    }
  }

  /**
   * Abort ONE live child subagent mid-turn. The structural face is the same
   * `cancel(cause, options)` the parent path uses; the handle comes from the
   * agents registry by the child's session id — the exact idiom the maxAgents
   * prune backstop uses (src/subagent-policy.ts), because the wire-level
   * `session.cancel` refuses subagent-owned sessions ("use subagent delivery")
   * and a BACKGROUND/continuable child otherwise survives the parent turn's
   * cancel outright (dsh-subagent owns the child's handle; the parent's
   * AbortSignal only binds it until inbox acceptance). `keepInbox` preserves
   * a continuable child's queued work — this stops the running turn, it does
   * not evict the child.
   * @returns false when the child is not live in this process or the cancel
   *   call threw; true once the cancellation was issued.
   */
  cancelChild(childId: string): boolean {
    let agent: { cancel(cause: unknown, options?: { keepInbox?: boolean }): void } | undefined
    try {
      agent = this.ctx.agents.get(SessionId(childId))
    } catch {
      return false // foreign/missing registry — nothing to stop
    }
    if (agent === undefined) return false
    try {
      agent.cancel({ kind: 'user' }, { keepInbox: true })
      return true
    } catch {
      return false
    }
  }

  /**
   * Abort EVERY live (not settled) child. The everything-stop's subagent leg:
   * cancelling the parent only kills FOREGROUND children (they ride the tool
   * call's abort signal) — background/continuable children keep burning LLM
   * rounds after the parent turn is gone, so the stop enumerates them from
   * the tracker and cancels each one.
   * @returns how many children a cancellation was issued for.
   */
  cancelAllChildren(): number {
    let stopped = 0
    for (const view of this.getLiveChildren()) {
      if (this.cancelChild(view.childId)) stopped += 1
    }
    return stopped
  }

  /**
   * Record that the maxRounds policy hard-stopped one child (the `⏻`
   * marker): folded into the child's view so every render surface — the
   * compact line, the picker row, the viewer transcript marker row — shows
   * the stop as policy, not a failure. Called by the policy's host wiring
   * after a successful `cancelChild`; a stop that found nothing live is
   * deliberately not recorded (the child settled on its own in time).
   */
  markChildHardStopped(childId: string, round: number, cap: number, early?: true): void {
    // The record lives in its OWN map, not on the view: fold updates spread
    // the view snapshot captured at their own event-dispatch time, and the
    // cancel races those events — a hardStop folded onto the view object was
    // observably overwritten by the in-flight `turn/end` spread. The map is
    // authoritative; getAgentViews composes it onto the returned views.
    this.hardStopRecords.set(childId, { round, cap, ...(early !== undefined ? { early } : {}) })
    this.emitLive()
  }

  /** Hard stops the maxRounds policy executed, keyed by child session id. */
  private readonly hardStopRecords = new Map<string, { round: number; cap: number; early?: true }>()
  /** Attention ranking (heuristic base + optional jev layer) — see src/attention.ts. */
  private readonly attentionBoard = new AttentionBoard()
  private attentionSource: AttentionJevSource | undefined
  private attentionCapReader: (() => number) | undefined

  /**
   * Whether ANY LLM work is in flight: the bridge's own mid-turn status OR
   * at least one live child. The keymap's running gate reads this — with
   * background children keeping the lights on after the parent turn ended,
   * the Esc stop must still arm (previously it went blind exactly when only
   * subagents were running).
   */
  hasRunningWork(): boolean {
    return this.running || this.getLiveChildren().length > 0
  }

  /** Dispose the live agent (if any) and stop event subscriptions. */
  async dispose(): Promise<void> {
    await this.stopRemoteWatch()
    for (const dispose of this.disposers.splice(0)) {
      try { dispose() } catch { /* contained */ }
    }
    const handle = this.handle
    this.handle = undefined
    this.sessionId = undefined
    this.running = false
    this.agentViews.clear()
    this.childSessions.clear()
    this.childLogs.clear()
    this.childStreams.clear()
    this.roundCounts.clear()
    this.streamedRoundCounts.clear()
    this.childUsage.clear()
    this.childPending.clear()
    this.childCompactionCounts.clear()
    this.reconciledLen.clear()
    this.reconciledCount.clear()
    this.trackedSessions.clear()
    this.runSeqToChild.clear()
    this.childDecode.clear()
    this.childLive.clear()
    if (handle !== undefined) await handle.dispose()
  }

  /**
   * Detach the live agent WITHOUT tearing down the event subscriptions —
   * `/new` wants a fresh session while the renderer keeps receiving events.
   * The agent handle is disposed, the session id cleared, and the
   * incremental stats zeroed (the footer must not carry the old session's
   * numbers); the disposers stay installed, and the session-id filter
   * re-binds on the next lazy creation. The subagent tracker is cleared and
   * an empty `onLive` is emitted so the renderer drops the agents block.
   */
  async detachCurrent(): Promise<void> {
    const handle = this.handle
    this.handle = undefined
    this.sessionId = undefined
    this.running = false
    this.stats.inputTokens = 0
    this.stats.outputTokens = 0
    this.stats.cacheReadTokens = 0
    this.stats.cacheWriteTokens = 0
    this.stats.msgCount = 0
    this.stats.toolCallCount = 0
    this.stats.cacheHitRate = undefined
    this.stats.lastMessageCacheHitRate = undefined
    this.stats.contextTokens = 0
    this.lastUsage = undefined
    this.pendingTokens = 0
    this.decodeMs = 0
    this.decodeTokens = 0
    this.currentRoute = undefined
    this.routeUsage.clear()
    this.agentViews.clear()
    this.childSessions.clear()
    this.childLogs.clear()
    this.childStreams.clear()
    this.roundCounts.clear()
    this.streamedRoundCounts.clear()
    this.childUsage.clear()
    this.childPending.clear()
    this.childCompactionCounts.clear()
    this.reconciledLen.clear()
    this.reconciledCount.clear()
    this.trackedSessions.clear()
    this.runSeqToChild.clear()
    this.childDecode.clear()
    this.childLive.clear()
    this.emitLive()
    if (handle !== undefined) await handle.dispose()
  }

  /**
   * Historical cwd for a session, from the persistence header list — the
   * log lives under THAT project key. All access best-effort: an absent
   * service or odd host yields undefined and the arm stays UNGUARDED
   * (fail-open, never locks a decoy), never breaks the resume.
   */
  private async headerCwdOf(sessionId: string): Promise<string | undefined> {
    try {
      const persistence = (this.ctx as Context & { get?(key: string): unknown }).get?.('sessionPersistence') as
        | { list?: () => Promise<Array<{ id: unknown; cwd?: unknown }>> }
        | undefined
      const stored = (await persistence?.list?.().catch(() => [])) ?? []
      const header = stored.find(candidate => String(candidate.id) === sessionId)
      return typeof header?.cwd === 'string' && header.cwd !== '' ? header.cwd : undefined
    } catch {
      return undefined
    }
  }

  /**
   * Tear down the current live binding — the shared prelude of every session
   * switch (resume, fork): stop the remote watch, dispose the handle, clear
   * the subagent tracker and re-seed the model selection (a live /model or
   * /think choice survives the switch; otherwise the composed default
   * applies). The renderer keeps its live snapshot across the teardown (it
   * must survive theme-switch rebuilds), so an empty `onLive` emit is
   * required to drop the previous session's agents block before the next
   * session's events rebuild it.
   */
  private async teardownLiveBinding(): Promise<void> {
    await this.stopRemoteWatch()
    const handle = this.handle
    this.handle = undefined
    this.sessionId = undefined
    this.running = false
    this.agentViews.clear()
    this.childSessions.clear()
    this.trackedSessions.clear()
    this.runSeqToChild.clear()
    this.emitLive()
    if (handle !== undefined) await handle.dispose()
    this.seedSelectionFromDefault()
  }

  /**
   * Fork-and-switch: create a NEW session seeded with a balanced
   * completed-turn prefix of the current session's log, then rebind this
   * bridge to it — the resume lifecycle (teardown, tracker clear, rebind)
   * over `agents.create` instead of `agents.resume`. The new session carries
   * durable fork lineage (`parentSession` + `isSeeded` + the inherited
   * prefix length) and composes under `presetId` (`meta.agentPreset`) — a
   * seeded USER session, deliberately NOT a subagent child (no
   * `origin`/delegationDepth, so /resume keeps it and the tracker ignores
   * it). The seed must be sliced from the live session BEFORE calling this —
   * the in-memory snapshot is the stable source. The teardown runs FIRST:
   * `markTuiSurface` provides a cordis service on the agent scope and two
   * live agents cannot coexist on it (the /new cycle only works because
   * dispose reclaims the service before the next create). A failed create
   * therefore leaves the old session DETACHED but fully resumable.
   * @param seed contiguous-from-0 events ending at a `turn/end` (non-empty).
   * @param parentSessionId the session the seed came from (durable lineage).
   * @param presetId the preset id the new session composes under.
   */
  async forkCurrentSession(seed: readonly SessionEvent[], parentSessionId: SessionId, presetId: string | undefined): Promise<AgentHandle> {
    // Teardown FIRST (see docblock): the old agent's scope holds the TUI
    // surface service the new agent's setup must provide.
    await this.teardownLiveBinding()
    const handle = await this.createSession({ seed, parentSessionId, presetId })
    this.handle = handle
    this.sessionId = handle.agent.session.id
    this.trackedSessions.add(String(this.sessionId))
    return handle
  }

  /**
   * Resume a persisted session: tear down the live agent (disposers are kept —
   * the session-id filter re-binds to the resumed id) and load the persisted
   * session in its place. The caller replays `handle.agent.session.snapshotEvents()`
   * through `replay()` to rebuild stats/transcript — clear the transcript
   * BEFORE replaying (the renderer's echo dedupe must not see replayed user
   * messages next to a stale local echo). (snapshotEvents is dsh 0.1.7
   * soft-deprecated upstream; the raw-event replay call sites keep it with a
   * T14 note each.) Serialized: concurrent calls share
   * the single in-flight resume.
   */
  async resume(sessionId: SessionId): Promise<AgentHandle> {
    if (this.resuming !== undefined) return this.resuming
    // Publish the target synchronously, before the task's first await:
    // retention polls `getResumingSessionId()` between its walk and each
    // removal, and the target directory must read as protected for the
    // entire load — not only after the handle lands. A concurrent
    // `resume(other)` returns the in-flight promise above WITHOUT
    // touching this field, so it always names the id actually loading.
    this.resumeTargetId = sessionId
    const task = (async () => {
      await this.teardownLiveBinding()
      // Attach arm: the session may already be LIVE in this process — e.g.
      // created by the feishu bot's /new or resumed by it. agents.resume
      // refuses live sessions ("cannot prepare session while it is live"),
      // so adopt the SAME agent instead: both surfaces drive one instance.
      // The handle is deliberately not ours (no-op dispose) — the creator's
      // lifecycle rules apply. The create/resume setup installers
      // (surface marker, model selection, APPEND_SYSTEM, spawn fence) do not
      // re-run here; the bot-created agent carries its own model selection.
      const live = this.ctx.agents.get(SessionId(sessionId))
      if (live !== undefined) {
        const adopted: AgentHandle & { adopted?: true } = {
          agent: live,
          dispose: async () => { /* owned by its creator */ },
          adopted: true,
        }
        this.handle = adopted
        this.sessionId = sessionId
        this.trackedSessions.add(String(sessionId))
        // Sync the running flag: an adopted agent may be mid-turn (the bot
        // is driving it) and no status transition will fire — without this
        // the TUI shows idle while the session works.
        if (live.status === 'running') {
          this.running = true
          this.callbacks.onStatus('running')
        }
        return adopted
      }
      // Cold arm — cross-process single-writer arbitration is the HOST's
      // job since 0.1.5: `agents.resume` opens the write handle under the
      // host's kernel lease, and a session another process drives refuses
      // here with SessionAlreadyOwnedError (surfaces as the /resume
      // read-only fallback).
      this.handle = await this.ctx.agents.resume({
        resumeSessionId: sessionId,
        agentOptions: this.selection ?? {},
        // Install the mutable selection so `/model` can live-switch the route,
        // the APPEND_SYSTEM.md section on this agent ONLY (never its
        // subagents), and the spawn-tool hide so the agent sees a single
        // `use_agent` delegation entry. The surface marker scopes the live
        // disableSubagent guard to THIS agent (resume runs setup too, so a
        // resumed session is re-marked without relying on persisted meta).
        setup: async agentCtx => {
          markTuiSurface(agentCtx)
          installModelSelection(agentCtx, this.selectionRef)
          installAppendSystem(agentCtx)
          installSpawnToolFence(agentCtx)
        },
      })
      this.sessionId = sessionId
      this.trackedSessions.add(String(sessionId))
      return this.handle
    })()
    this.resuming = task
    try {
      return await task
    } finally {
      this.resuming = undefined
      this.resumeTargetId = undefined
    }
  }

  /**
   * Replay a persisted session log into the transcript and stats — the second
   * half of a resume (call after `resume()`). Stats are rebuilt from zero so
   * the footer reflects the resumed session only; replaying the same log
   * twice is idempotent. V3 logs carry no streaming chunks at all — the
   * finalized `assistant/message` holds the full text (and its embedded
   * stream, which replay never needs).
   */
  replay(events: readonly SessionEvent[]): void {
    this.stats.inputTokens = 0
    this.stats.outputTokens = 0
    this.stats.cacheReadTokens = 0
    this.stats.cacheWriteTokens = 0
    this.stats.msgCount = 0
    this.stats.toolCallCount = 0
    this.stats.cacheHitRate = undefined
    this.stats.lastMessageCacheHitRate = undefined
    this.stats.contextTokens = 0
    this.lastUsage = undefined
    this.pendingTokens = 0
    this.decodeMs = 0
    this.decodeTokens = 0
    this.currentRoute = undefined
    this.routeUsage.clear()
    const sessionId = this.sessionId
    for (const event of events) {
      // Replay feeds the parent log only — fold its persisted workflow events
      // through the same tracking logic so the agents view is rebuilt; child
      // live events arrive via the subscription after resume.
      if (sessionId !== undefined && this.trackedSessions.has(String(sessionId))) {
        this.foldTracked(String(sessionId), event)
      }
      this.applyEvent(event)
      this.callbacks.onEvent(event)
    }
  }

  /** Update incremental stats from one event — one pass over the event only. */
  private applyEvent(event: SessionEvent): void {
    switch (event.type) {
      case 'user/message':
        this.stats.msgCount += 1
        // The prompt enters the NEXT request — priced into the occupancy now.
        this.pendingTokens += estimateContentTokens((event.data as { content?: unknown }).content)
        this.stats.contextTokens = this.contextTokens()
        break
      case 'assistant/message': {
        this.stats.msgCount += 1
        for (const block of event.data.message.content) {
          if (block.type === 'tool-call') this.stats.toolCallCount += 1
        }
        const usage: TokenUsage | undefined = event.data.usage
        if (usage !== undefined) {
          // The assembled message finalizes the request: its usage snapshot is
          // now the exact billed context (input + cache + output) and the
          // pending estimate restarts from what follows it. A usage-less
          // message (adapter reported none) leaves the baseline untouched —
          // pending already holds the streamed chunk estimate accumulated for
          // this message, a reasonable stand-in until the next billed message.
          this.lastUsage = usage
          this.pendingTokens = 0
          this.stats.inputTokens += usage.inputTokens
          this.stats.outputTokens += usage.outputTokens
          this.stats.cacheReadTokens += usage.cacheReadTokens ?? 0
          this.stats.cacheWriteTokens += usage.cacheWriteTokens ?? 0
          // CH is session-cumulative by design: hit rate = ΣcacheRead /
          // (Σinput + ΣcacheRead + ΣcacheWrite) over the whole session's
          // input traffic — output tokens never enter (cache hit is an
          // input-side metric), and a provider/model route change does NOT
          // reset the counters; the rate describes the session, not one
          // route's prompt cache.
          const billedInput = this.stats.inputTokens + this.stats.cacheReadTokens + this.stats.cacheWriteTokens
          this.stats.cacheHitRate = billedInput > 0
            ? (this.stats.cacheReadTokens / billedInput) * 100
            : undefined
          // The per-message companion: the same formula over THIS request's
          // usage only (pi-tui footer semantics). A message without usage
          // leaves the previous snapshot standing, mirroring lastUsage.
          const latestPromptTokens = usage.inputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)
          this.stats.lastMessageCacheHitRate = latestPromptTokens > 0
            ? ((usage.cacheReadTokens ?? 0) / latestPromptTokens) * 100
            : undefined
        }
        // Decode-speed accounting (first token → this event's log time, the
        // sessionStats projection's decode window). Needs BOTH a billed usage
        // and a readable embedded stream; the window is clamped positive so
        // a clock-skewed settlement adds nothing.
        const firstToken = firstTokenOf(event.data.stream)
        if (usage !== undefined && firstToken !== undefined && event.time > firstToken) {
          const windowMs = event.time - firstToken
          this.decodeMs += windowMs
          this.decodeTokens += usage.outputTokens
          if (this.currentRoute !== undefined) {
            let entry = this.routeUsage.get(this.currentRoute)
            if (entry === undefined) {
              entry = { route: this.currentRoute, requests: 0, outputTokens: 0, decodeMs: 0, decodeTokens: 0 }
              this.routeUsage.set(this.currentRoute, entry)
            }
            entry.requests += 1
            entry.outputTokens += usage.outputTokens
            entry.decodeMs += windowMs
            entry.decodeTokens += usage.outputTokens
          }
        }
        this.stats.contextTokens = this.contextTokens()
        break
      }
      case 'assistant/attempt':
        // A settled attempt that produced no surface message (failed, retried,
        // cancelled). No transcript, stats, or occupancy effect — the next
        // billed assistant/message carries the step's real usage.
        break
      case 'tool/result':
        // Tool results enter the next request — priced into the occupancy.
        this.pendingTokens += estimateToolResultTokens(event.data)
        this.stats.contextTokens = this.contextTokens()
        break
      case 'request/header': {
        // The route snapshot prefixes every billed message until the next
        // one — the per-route TPS attribution's only route source. Read
        // through the typed EpochHeader (config.provider/model are plain
        // strings); a headerless session attributes nothing.
        const config = event.data.header.config
        if (typeof config.provider === 'string' && typeof config.model === 'string') {
          this.currentRoute = `${config.provider}/${config.model}`
        }
        break
      }
      default:
        break
    }
  }

  /**
   * One `agent/assistant-stream` frame of any session in the process (dsh
   * 0.1.5-rc.1 moved the live deltas off the firehose). Chunk frames carry no
   * turn/step — the attempt's start frame pinned them in {@link openAttempts}.
   */
  private onStreamFrame(sessionKey: string, frame: AssistantStreamFrame): void {
    if (frame.type === 'start') {
      this.openAttempts.set(sessionKey, { turn: frame.turn, step: frame.step })
      return
    }
    if (frame.type === 'end') {
      this.openAttempts.delete(sessionKey)
      return
    }
    const chunk = frame.chunk
    if ((chunk.type !== 'text-delta' && chunk.type !== 'reasoning-delta') || (chunk.text ?? '') === '') {
      return
    }
    const delta = chunk.text ?? ''
    if (this.sessionId !== undefined && sessionKey === String(this.sessionId)) {
      // The bridge's own session: the occupancy estimate follows the stream
      // (both text and reasoning are priced — usage.outputTokens includes
      // reasoning tokens at snapshot time), and the transcript's typewriter
      // plus the think/tool phase machine stay live between settlements.
      const attempt = this.openAttempts.get(sessionKey)
      const turn = attempt?.turn ?? 0
      const step = attempt?.step ?? 0
      this.pendingTokens += estimateTextTokens(delta)
      this.stats.contextTokens = this.contextTokens()
      this.callbacks.onStreamDelta?.(turn, step, chunk)
      return
    }
    if (this.trackedSessions.has(sessionKey) && this.childSessions.has(sessionKey)) {
      this.foldChildStreamDelta(sessionKey, delta)
    }
  }

  /**
   * Fold one streaming delta of a tracked CHILD into the live row: the
   * content tail (text AND reasoning — never a tool name, always the child's
   * own output) and the pending-occupancy estimate. The assembled
   * `assistant/message` later replaces the tail with the authoritative last
   * line and resets the estimate against real usage.
   */
  private foldChildStreamDelta(sessionId: string, delta: string): void {
    const view = this.agentViews.get(sessionId)
    if (view === undefined) return
    const buffer = bumpChildStream(this.childStreams.get(sessionId) ?? '', delta)
    this.childStreams.set(sessionId, buffer)
    // Live decode window: the first delta after a settlement opens it at
    // NOW (the true first-token instant is a few ms earlier — within the
    // display noise), later deltas accumulate the streamed-token estimate.
    // The settled `assistant/message` closes it (foldTracked).
    const estimated = estimateTextTokens(delta)
    const live = this.childLive.get(sessionId)
    if (live === undefined) this.childLive.set(sessionId, { firstTokenAt: Date.now(), tokens: estimated })
    else live.tokens += estimated
    const lastLine = lastBufferLine(buffer)
    this.childPending.set(sessionId, (this.childPending.get(sessionId) ?? 0) + estimateTextTokens(delta))
    const contextTokens = this.childContextTokens(sessionId)
    const lineChanged = lastLine !== undefined && lastLine !== view.lastLine
    const contextChanged = contextTokens !== view.contextTokens
    if (lineChanged || contextChanged) {
      this.agentViews.set(sessionId, {
        ...view,
        ...(lineChanged ? { lastLine } : {}),
        ...(contextChanged ? { contextTokens } : {}),
      })
      this.emitLive()
    }
  }

  /**
   * The current context-occupancy estimate: the latest assistant/message's
   * billed input (uncached + cache read + cache write) and output, plus the
   * CJK estimate of every message appended after it. Before the first
   * assistant/message the pending estimate alone stands in for the whole
   * current context.
   */
  private contextTokens(): number {
    if (this.lastUsage === undefined) return this.pendingTokens
    return this.lastUsage.inputTokens
      + (this.lastUsage.cacheReadTokens ?? 0)
      + (this.lastUsage.cacheWriteTokens ?? 0)
      + this.lastUsage.outputTokens
      + this.pendingTokens
  }

  /**
   * The current context-occupancy estimate of one child (the `X` in the
   * compact line's `X/Y`): the child's latest assistant/message billed input
   * + output plus the CJK estimate of messages appended after it. Before the
   * child's first assistant/message the pending estimate alone stands in.
   */
  private childContextTokens(childId: string): number {
    const usage = this.childUsage.get(childId)
    const pending = this.childPending.get(childId) ?? 0
    if (usage === undefined) return pending
    return usage.inputTokens
      + (usage.cacheReadTokens ?? 0)
      + (usage.cacheWriteTokens ?? 0)
      + usage.outputTokens
      + pending
  }

  /**
   * Fold one event of a tracked session into the agent views (workflow events
   * of the parent log + the child's own log). O(1) per event — Maps/Sets only,
   * never a session-log scan. Emits `onLive` when a view actually changed.
   * @returns whether a view changed (and `onLive` was emitted).
   */
  private foldTracked(sessionId: string, event: SessionEvent): boolean {
    let changed = false
    if (isAgentStart(event)) {
      // Workflow member: register with the workflow label + start time.
      if (!this.agentViews.has(event.data.childId)) {
        this.agentViews.set(event.data.childId, {
          childId: event.data.childId,
          label: event.data.label,
          startedAt: event.time,
          tokens: 0,
          rounds: 0,
          retries: 0,
          contextTokens: 0,
        })
        this.runSeqToChild.set(`${event.data.runId}:${event.data.seq}`, event.data.childId)
        this.childSessions.add(event.data.childId)
        this.trackedSessions.add(event.data.childId)
        changed = true
      }
    } else if (isAgentEnd(event)) {
      const childId = this.runSeqToChild.get(`${event.data.runId}:${event.data.seq}`)
      const existing = childId === undefined ? undefined : this.agentViews.get(childId)
      if (childId !== undefined && existing !== undefined && existing.outcome === undefined) {
        this.agentViews.set(childId, {
          ...existing,
          outcome: event.data.outcome,
          endedAt: event.time,
        })
        changed = true
      }
    }
    if (this.childSessions.has(sessionId)) {
      const view = this.agentViews.get(sessionId)
      if (view !== undefined) {
        if (isSubagentDescriptor(event)) {
          // The continuable descriptor carries the declared child route
          // (agentProvider/agentModel/agentReasoningEffort); one-shot
          // descriptors don't — their route lands via `request/header`
          // below. `view.provider` stays the subagent transport name.
          const route = descriptorModelRoute(event.data)
          const routeChanged = (route !== undefined && route !== view.modelRoute)
            || (event.data.mode === 'continuable'
              && event.data.agentReasoningEffort !== undefined
              && view.thinking !== event.data.agentReasoningEffort)
          if (view.provider !== event.data.provider
            || view.mode !== event.data.mode
            || (event.data.label !== undefined && view.label !== event.data.label)
            || routeChanged) {
            this.agentViews.set(sessionId, {
              ...view,
              provider: event.data.provider,
              mode: event.data.mode,
              ...(event.data.label === undefined ? {} : { label: event.data.label }),
              ...(route !== undefined ? { modelRoute: route } : {}),
              ...(event.data.mode === 'continuable' && event.data.agentReasoningEffort !== undefined
                ? { thinking: event.data.agentReasoningEffort }
                : {}),
            })
            changed = true
          }
        } else if (event.type === 'request/header') {
          // The child's effective LLM call config (provider/model +
          // reasoning effort) — the ONE-SHOT route source (one-shot
          // descriptors carry no route; every child writes its first
          // `request/header` before its first request). Overwrites the
          // descriptor-derived route on later header changes (/model inside
          // a continuable child) — the latest snapshot is the truth.
          const config = (event.data as { header?: { config?: { provider?: unknown; model?: unknown; reasoningEffort?: unknown } } }).header?.config
          const provider = typeof config?.provider === 'string' ? config.provider : undefined
          const model = typeof config?.model === 'string' ? config.model : undefined
          const route = provider !== undefined && model !== undefined ? `${provider}/${model}` : undefined
          const effort = typeof config?.reasoningEffort === 'string' ? config.reasoningEffort : undefined
          if ((route !== undefined && route !== view.modelRoute)
            || (effort !== undefined && effort !== view.thinking)) {
            this.agentViews.set(sessionId, {
              ...view,
              ...(route !== undefined ? { modelRoute: route } : {}),
              ...(effort !== undefined ? { thinking: effort } : {}),
            })
            changed = true
          }
        } else if (event.type === 'assistant/message') {
          // Round counting is view-independent: every assistant message of the
          // child is one round (one LLM round-trip), counted even once the
          // view settled — continuable children resume. `turn/end` is NOT the
          // round unit: a one-shot child never leaves its single turn, so its
          // rounds would stay frozen at 0 while it works.
          // The event path keeps its OWN absolute streamed count and merges
          // it with the reconcile's log-derived count by max() — the two
          // ledgers never double count. A message the reconcile already
          // counted (its `assistant/message` reached the session log first)
          // must not be counted AGAIN when that same event arrives late here:
          // the reconcile only moves the count up, so a naive `current + 1`
          // would inflate it permanently. Caveat: "absolute" holds only while
          // the firehose delivers each event at most once — there is no seq
          // de-dup, so a redelivered `assistant/message` inflates the
          // streamed ledger permanently (the previous `current + 1` counter
          // had the same exposure).
          const streamed = (this.streamedRoundCounts.get(sessionId) ?? 0) + 1
          this.streamedRoundCounts.set(sessionId, streamed)
          const count = Math.max(streamed, this.roundCounts.get(sessionId) ?? 0)
          if (count !== (this.roundCounts.get(sessionId) ?? 0)) {
            this.roundCounts.set(sessionId, count)
            this.callbacks.onRoundCount?.(sessionId, count)
          }
          const usage = event.data.usage
          const delta = usage === undefined
            ? 0
            : usage.inputTokens + usage.outputTokens
              + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)
          // The assembled message finalizes the child's request: its usage is
          // now the exact billed context baseline and the pending estimate
          // restarts from what follows it. A usage-less message leaves both
          // untouched — pending still holds the streamed chunk estimate
          // accumulated for this message, a reasonable approximation until the
          // next billed message replaces it.
          if (usage !== undefined) {
            this.childUsage.set(sessionId, usage)
            this.childPending.set(sessionId, 0)
          }
          // Child decode-speed accounting — the same window as the main
          // session (first token → settlement), feeding the viewer header's
          // cumulative `tok/s`. Settling also closes the live in-flight
          // window; the next streamed delta re-opens it for the next message.
          const childFirstToken = firstTokenOf(event.data.stream)
          if (usage !== undefined && childFirstToken !== undefined && event.time > childFirstToken) {
            const acc = this.childDecode.get(sessionId) ?? { decodeMs: 0, decodeTokens: 0 }
            acc.decodeMs += event.time - childFirstToken
            acc.decodeTokens += usage.outputTokens
            this.childDecode.set(sessionId, acc)
          }
          this.childLive.delete(sessionId)
          const lastLine = lastTextLine(event.data)
          // A landed assistant message proves the last request round-tripped
          // successfully — clear the llm/retry markers so `↻N≤M` does not
          // linger on the row after the retry succeeded (dsh emits no
          // retry-cleared event).
          const retryCleared = view.retries !== 0 || view.maxRetries !== undefined
          const tokensChanged = delta > 0
          const lineChanged = lastLine !== undefined && lastLine !== view.lastLine
          const roundsChanged = count !== view.rounds
          const contextTokens = this.childContextTokens(sessionId)
          const contextChanged = contextTokens !== view.contextTokens
          if (tokensChanged || lineChanged || roundsChanged || contextChanged || retryCleared) {
            // One set: neither delta nor lastLine nor rounds nor contextTokens
            // nor the retry clear may clobber the others. The assembled
            // message is authoritative for the content tail — its streaming
            // buffer is spent.
            this.agentViews.set(sessionId, {
              ...view,
              ...(tokensChanged ? { tokens: view.tokens + delta } : {}),
              ...(lineChanged ? { lastLine } : {}),
              ...(roundsChanged ? { rounds: count } : {}),
              ...(contextChanged ? { contextTokens } : {}),
              ...(retryCleared ? { retries: 0, maxRetries: undefined } : {}),
            })
            changed = true
          }
          this.childStreams.delete(sessionId)
        } else if (event.type === 'user/message') {
          // The child's own prompts/injects enter its next request — the
          // occupancy follows (the content tail is never touched here). A
          // dsh-dcp compaction notice (plugin `notice` form) also tallies the
          // per-child compaction count the viewer's picker rows read.
          if (isDcpCompactionNotice(event)) {
            this.childCompactionCounts.set(
              sessionId,
              (this.childCompactionCounts.get(sessionId) ?? 0) + 1,
            )
          }
          // A dsh-tui-pi plugin injection (maxRounds wrap-up, Ctrl+G steer)
          // marks the view: the compact line and the viewer surface `⚡` so
          // the user can see the policy actually fired.
          const injectionChanged = isTuiPluginInjection(event) && view.injectedAt === undefined
          this.childPending.set(
            sessionId,
            (this.childPending.get(sessionId) ?? 0)
              + estimateContentTokens((event.data as { content?: unknown }).content),
          )
          const contextTokens = this.childContextTokens(sessionId)
          const contextChanged = contextTokens !== view.contextTokens
          if (contextChanged || injectionChanged) {
            this.agentViews.set(sessionId, {
              ...view,
              ...(injectionChanged ? { injectedAt: event.time } : {}),
              ...(contextChanged ? { contextTokens } : {}),
            })
            changed = true
          }
        } else if (event.type === 'tool/result') {
          // Tool results enter the child's next request — the occupancy
          // follows (the content tail shows the child's own output only).
          this.childPending.set(
            sessionId,
            (this.childPending.get(sessionId) ?? 0) + estimateToolResultTokens(event.data),
          )
          const contextTokens = this.childContextTokens(sessionId)
          if (contextTokens !== view.contextTokens) {
            this.agentViews.set(sessionId, { ...view, contextTokens })
            changed = true
          }
        } else if (isLlmRetry(event)) {
          // No text content — surface a fixed marker so the row shows the
          // child is (re)working. Merged into one set so the retry counters
          // and the marker can't clobber each other.
          const retryChanged = view.retries !== event.data.retry || view.maxRetries !== event.data.maxRetries
          const lineChanged = view.lastLine !== RETRY_MARKER
          if (retryChanged || lineChanged) {
            this.agentViews.set(sessionId, {
              ...view,
              ...(retryChanged
                ? { retries: event.data.retry, maxRetries: event.data.maxRetries }
                : {}),
              ...(lineChanged ? { lastLine: RETRY_MARKER } : {}),
            })
            changed = true
          }
        } else if (event.type === 'tool/call') {
          // Tool invocations do NOT touch the content tail: the compact row
          // shows the child's own output (assistant text/reasoning), never a
          // tool name. Only the lastTool activity marker is maintained.
          if (view.lastTool !== event.data.name) {
            this.agentViews.set(sessionId, { ...view, lastTool: event.data.name })
            changed = true
          }
        } else if (event.type === 'request/context') {
          const contextWindow = event.data.contextWindow
          if (typeof contextWindow === 'number' && view.contextWindow !== contextWindow) {
            this.agentViews.set(sessionId, { ...view, contextWindow })
            changed = true
          }
        } else if (event.type === 'turn/end' && view.outcome === undefined) {
          // Best-effort settle for header-discovered children (no workflow
          // outcome event): the child's turn closed — the widget drops it.
          this.agentViews.set(sessionId, { ...view, outcome: 'completed', endedAt: event.time })
          changed = true
        } else if (event.type === 'turn/start') {
          // Two clears on every turn/start:
          //  - outcome/endedAt only when the child was previously settled
          //    (a continuable child resumed); for a fresh view outcome is
          //    already undefined, so this is a no-op.
          //  - retries/maxRetries unconditionally — a fresh turn starts
          //    with no pending retry, and stale markers from the previous
          //    run must not survive on a continuable child. For new views
          //    retries is already 0, so this is also a no-op there.
          const outcomeCleared = view.outcome !== undefined
          const retryCleared = view.retries !== 0 || view.maxRetries !== undefined
          if (outcomeCleared || retryCleared) {
            this.agentViews.set(sessionId, {
              ...view,
              ...(outcomeCleared ? { outcome: undefined, endedAt: undefined } : {}),
              ...(retryCleared ? { retries: 0, maxRetries: undefined } : {}),
            })
            changed = true
          }
        }
      }
    }
    if (changed) this.emitLive()
    return changed
  }

  /** Push the current agent views (stable order) to the renderer. */
  private emitLive(): void {
    this.callbacks.onLive(this.getAgentViews())
  }

  /** Append one child-session event to its transcript buffer, dropping the oldest at the cap. */
  private appendChildLog(childId: string, event: SessionEvent): void {
    let log = this.childLogs.get(childId)
    if (log === undefined) {
      log = []
      this.childLogs.set(childId, log)
    }
    if (log.length >= CHILD_LOG_CAP) log.shift()
    log.push(event)
  }

  private async ensureSession(): Promise<AgentHandle> {
    // A resume in flight would otherwise race this check: the handle is only
    // set when resume completes, so a prompt fired mid-resume must not start
    // a second agent creation. Await it — on success the handle is ready for
    // reuse; on failure fall through to the normal creation path.
    if (this.resuming !== undefined) {
      try {
        await this.resuming
      } catch {
        // Resume failed — fall through to create a fresh session.
      }
    }
    if (this.handle !== undefined) return this.handle
    if (this.creating !== undefined) return this.creating
    const creation = this.createSession()
    this.creating = creation
    try {
      this.handle = await creation
      this.sessionId = this.handle.agent.session.id
      this.trackedSessions.add(String(this.sessionId))
      return this.handle
    } finally {
      this.creating = undefined
    }
  }

  /**
   * Seed `selection`/`selectionRef` for a new session. Precedence:
   * 1. a `.dsh-profile` directory pin found up the cwd tree — the pin means
   *    "this tree always starts on X", so it deliberately outranks even a
   *    leftover in-process /model choice;
   * 2. the composed global default (`agent-default-model`), which must not
   *    clobber a live user choice: `/model`/`/think` before the first prompt
   *    write the ref, and that choice survives session creation (pin absent).
   *
   * `force` (the cold-start re-seed path) skips the "keep the existing ref"
   * branch in 2: an earlier seed may have captured the BUILT-IN default
   * before the first-boot settings import landed, and that stale seed is not
   * a user choice — the composed default is re-derived instead. A pin or a
   * user choice is unaffected (pins re-apply at 1; callers guard user
   * choices before forcing).
   */
  private seedSelectionFromDefault(force = false): void {
    const pinned = this.pinnedRouteSelection()
    if (pinned !== undefined) {
      this.selection = pinned
      this.selectionRef.current = { ...pinned }
      return
    }
    if (!force && this.selectionRef.current !== undefined) {
      this.selection = { ...this.selectionRef.current }
      return
    }
    this.selection = this.composedDefaultSelection()
    this.selectionRef.current = this.selection === undefined ? undefined : { ...this.selection }
  }

  /** The nearest `.dsh-profile` pin as a selection — best-effort, never throws. */
  private pinnedRouteSelection(): ModelSelection | undefined {
    try {
      const pinned = resolvePinnedProfile(loadModelProfiles(modelProfilesPath()), process.cwd())
      const route = pinned?.defaultModel
      if (pinned === undefined || route === undefined) return undefined
      return {
        provider: route.provider,
        model: route.model,
        ...(route.reasoningEffort === undefined ? {} : { reasoningEffort: route.reasoningEffort as ReasoningEffortId }),
      }
    } catch {
      return undefined
    }
  }

  /** The composed global default (`agent-default-model`) as a plain selection. */
  private composedDefaultSelection(): ModelSelection | undefined {
    const sel = this.ctx.get('agentDefaultModel')?.currentSelection()
    return sel === undefined
      ? undefined
      : {
          provider: sel.provider,
          model: sel.model,
          ...sel.reasoningEffort === undefined ? {} : { reasoningEffort: sel.reasoningEffort },
        }
  }

  /** Create the agent with the composed default model selection. */
  /**
   * Create the agent with the composed default model selection. `fork`
   * seeds the new session with a balanced completed-turn prefix of another
   * session's log (the preset-switch "Fork & switch" path): durable lineage
   * (`parentSession` + `isSeeded` + the inherited prefix length) plus the
   * fork's own `agentPreset` — recording the preset is what keeps the
   * session's history reconstructable (a cold read that dropped it would
   * rebuild turns under the wrong composition, the same rule
   * `childSessionMeta` documents for subagent children).
   */
  private async createSession(fork?: { seed: readonly SessionEvent[]; parentSessionId: SessionId; presetId: string | undefined }): Promise<AgentHandle> {
    this.seedSelectionFromDefault()
    const sessionId = crypto.randomUUID()
    const cwd = process.cwd()
    // A fork records ITS OWN preset (what the new session composes under —
    // possibly none, keeping meta.agentPreset absent); a plain create
    // records the current selection.
    const presetMeta = fork !== undefined
      ? fork.presetId !== undefined ? { agentPreset: fork.presetId } : {}
      : this.agentPreset !== undefined ? { agentPreset: this.agentPreset } : {}
    const meta: {
      cwd: string
      agentPreset?: string
      parentSession?: SessionId
      isSeeded?: boolean
    } = {
      cwd,
      ...presetMeta,
      ...(fork !== undefined ? { parentSession: fork.parentSessionId, isSeeded: true } : {}),
    }
    return await this.ctx.agents.create({
      sessionId: SessionId(sessionId),
      meta,
      ...(fork === undefined ? {} : {
        seed: fork.seed,
        inheritedEventCount: SessionLogOffset(fork.seed.length),
      }),
      agentOptions: this.selection ?? {},
      // Install the mutable selection so `/model` can live-switch the route,
      // the APPEND_SYSTEM.md section on this agent ONLY (never its
      // subagents), and the spawn-tool hide so the agent sees a single
      // `use_agent` delegation entry. The surface marker scopes the live
      // disableSubagent guard to THIS agent.
      setup: async agentCtx => {
        markTuiSurface(agentCtx)
        installModelSelection(agentCtx, this.selectionRef)
        installAppendSystem(agentCtx)
        installSpawnToolFence(agentCtx)
      },
    })
  }

  /** The model selection shown in the footer (live value after `/model`). */
  getSelection(): ModelSelection | undefined {
    return this.selectionRef.current ?? this.selection
  }

  /** Apply a live model switch (`/model` selector outcome). */
  setSelection(next: ModelSelection): void {
    this.selectionUserPinned = true
    this.selectionRef.current = { ...next }
    this.selection = { ...next }
  }

  /** Set the agent preset for the next session creation. */
  setAgentPreset(presetId: string | undefined): void {
    this.agentPreset = presetId
  }

  /** Whether the current session has any turns (blank = preset can be changed). */
  isSessionBlank(): boolean {
    if (this.sessionId === undefined) return true
    const agent = this.getAgent()
    return agent === undefined || agent.session.seq === 0
  }
}

/**
 * Persist the default model selection. Preferred path: the
 * `agent-default-model` service's `saveSelection`, the official API (a
 * settings.replace, last-write-wins). The namespace is read live by that
 * service — the change takes effect on the next lazy session creation
 * (`/new` or the next prompt) and survives restarts. Without the service,
 * fall back to a direct settings mutate (with one optimistic-concurrency
 * retry). Best-effort: a deployment without a settings provider is skipped
 * silently; a failed write returns its error message for the caller to
 * surface.
 * @returns undefined on success, the failure message otherwise.
 */
export async function persistDefaultModel(ctx: Context, selection: ModelSelection): Promise<string | undefined> {
  const service = ctx.get('agentDefaultModel') as
    | { saveSelection?: (next: ModelSelection) => unknown }
    | undefined
  if (service?.saveSelection !== undefined) {
    try {
      // The service API takes the whole selection and writes through
      // settings.replace (last-write-wins, no revision check). It may be
      // sync or async — awaiting covers both.
      await service.saveSelection(selection)
      return undefined
    } catch (error) {
      return error instanceof Error ? error.message : String(error)
    }
  }
  const settings = ctx.get('settings')
  if (settings === undefined) return undefined
  // dsh-settings 0.1.2-alpha.3 removed the runtime settingsNamespace() helper:
  // a plain literal is the supported spelling (type-level brand check plus the
  // host's runtime parseSettingsNamespace validation).
  const ns = 'agent-default-model'
  // The descriptor carries the namespace's revision (optimistic-concurrency
  // token for mutate) and proves the schema registration that validates the
  // field names below; the write itself rejects when the namespace is
  // unregistered (no descriptor either).
  const ops: SettingsPathOp[] = [
    { op: 'set', path: ['provider'], value: selection.provider },
    { op: 'set', path: ['model'], value: selection.model },
  ]
  if (selection.reasoningEffort === undefined) {
    // Unset so a stale override is dropped from the stored yaml document too.
    ops.push({ op: 'unset', path: ['reasoningEffort'] })
  } else {
    ops.push({ op: 'set', path: ['reasoningEffort'], value: selection.reasoningEffort })
  }
  // One retry after a concurrent writer moved the namespace (fresh revision);
  // a second conflict surfaces the raw error for the caller.
  for (let attempt = 0; ; attempt++) {
    const descriptor = settings.describe().find(d => d.ns === ns)
    try {
      await settings.mutate(ns, ops, descriptor?.revision)
      return undefined
    } catch (error) {
      if (attempt === 0 && error instanceof SettingsConflictError) continue
      return error instanceof Error ? error.message : String(error)
    }
  }
}

// Reload survival for the current session. `/reload` evicts this plugin's
// entire user-code module closure from the ESM/CJS caches, so module-level
// state does not survive — but the reload happens in the SAME dsh process, so
// process-global state does. These two helpers stash the current session id on
// `globalThis` before a reload tears this fiber down, and the freshly re-imported
// module consumes it in the new fiber so the TUI resumes the previously current
// session instead of lazily creating a fresh one on the next prompt. A real dsh
// process restart resets the stash, so a fresh start still lazily creates a new
// session. The stash is one-shot: `takeStashedSessionId` reads and deletes.

const LAST_SESSION_ID_KEY = Symbol.for('dsh-tui-pi.lastSessionId')

/**
 * Stash the current session id on the process-global store so a subsequent
 * hot-reload in the same process can resume it. Pass undefined to clear the
 * stash (no session current).
 */
export function stashSessionIdForReload(id: SessionId | undefined): void {
  const store = globalThis as Record<symbol, unknown>
  if (id === undefined) {
    delete store[LAST_SESSION_ID_KEY]
  } else {
    store[LAST_SESSION_ID_KEY] = String(id)
  }
}

/**
 * Consume (read-and-delete) a previously stashed session id, or undefined when
 * none was stashed. One-shot: a second call returns undefined.
 */
export function takeStashedSessionId(): SessionId | undefined {
  const store = globalThis as Record<symbol, unknown>
  const raw = store[LAST_SESSION_ID_KEY]
  delete store[LAST_SESSION_ID_KEY]
  return typeof raw === 'string' ? SessionId(raw) : undefined
}
