/**
 * Session TUI overlays: the `/session` info panel and the `/resume`
 * persisted-session picker — terminal counterparts of the web surface's
 * session management. Both speak the shared FW table language (panels.ts):
 * the picker is a TablePanel and the info panel a read-only auto table
 * (autoColumns + booktabs rules), each in a framed overlay with
 * `restoreFocus` on close.
 */

import type { Context } from '@deepseek-ai/cordis'
import type { SessionEvent, SessionHeader, SessionId } from '@deepseek-ai/dsh-session'
import { getKeybindings, matchesKey, type Component, type TUI } from '@earendil-works/pi-tui'
import { readdir, stat } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, join } from 'node:path'
import { SESSION_LOG_FILE_NAMES } from './retention.ts'
import { isCorruptLogError } from './log-repair.ts'
import { emitNotice } from './notice-bridge.ts'
import { wrapFramedOverlay } from './frame.ts'
import { t } from './i18n/index.ts'
import {
  autoColumns,
  columnWidths,
  MARKER_W,
  padCell,
  panelThemeFns,
  TablePanel,
  tableHeaderLine,
  tableRuleLine,
  TABLE_SEP,
  type TableColumn,
} from './panels.ts'
import { BOLD, RESET, type TuiTheme } from './theme/index.ts'
import { clipToWidth, visibleWidth } from './text.ts'

// ------------------------------------------------------------- `/session` panel --

/** Everything the `/session` info panel renders (snapshot, built by the caller). */
export interface SessionPanelData {
  id: string | undefined
  cwd: string | undefined
  createdAt: number | undefined
  /** "provider/model", or already including the reasoning effort. */
  model: string | undefined
  effort: string | undefined
  msgCount: number
  toolCallCount: number
  /** Per-route-segment totals (reset when the provider/model route changes) — see the panel title note. */
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  status: 'idle' | 'running' | 'none'
  eventCount: number | undefined
  parentSession: string | undefined
  /**
   * Session-wide decode speed (tok/s): Σ output tokens / Σ first-token →
   * settlement wall time. Undefined while nothing has been billed — reads
   * as em-dash, never as 0.
   */
  overallTps?: number
  /**
   * Per-route attribution — the models this session actually billed (the
   * `/session` "models" row). Each entry carries the route, its billed
   * message count / output tokens, and its own decode speed when known.
   */
  routes?: ReadonlyArray<{
    route: string
    requests: number
    outputTokens: number
    tps?: number
  }>
  /**
   * Latest session title text (the host's folded `session/title` snapshot).
   * Rendered on the panel's heading line — the height budget (20 rows for a
   * 24-row terminal) has no spare row for a table entry.
   */
  title: string | undefined
  /** Whether the rename affordance is wired (live session + title service mounted). */
  canRename: boolean
}

/** Result of one rename attempt, phrased for the panel's note line. */
export interface RenameOutcome {
  ok: boolean
  note: string
  /** The accepted (normalized) title, on success — the panel re-renders its heading from it. */
  title?: string
}

/**
 * The synchronous rename contract the caller hands the panel. Sync on
 * purpose: `SessionTitleService.rename` appends a log event synchronously
 * and throws synchronously, so the caller translates that into an outcome
 * without the panel needing an async/pend state.
 */
export type SessionRenameFn = (title: string) => RenameOutcome

/** Fit cap for the FIELD column (the longest label is "tokens in/out"). */
const FIELD_CAP = 12

/** Route short name for the models row: the tail after the provider slash. */
function shortRoute(route: string): string {
  const slash = route.indexOf('/')
  return slash < 0 ? route : route.slice(slash + 1)
}

/**
 * The `/session` key-value rows, in display order — pure so the panel's data
 * contract stays unit-testable. Values are PLAIN text: the panel clips/pads
 * them through the shared FW table helpers and paints afterwards.
 *
 * The 20-row budget on a 24-row terminal is exact, so the two token-count
 * pairs share rows (in/out, cache r/w) and the freed slots carry the decode
 * speed and the per-model breakdown.
 */
export function sessionInfoRows(data: SessionPanelData): ReadonlyArray<{ field: string; value: string }> {
  const models = data.routes === undefined || data.routes.length === 0
    ? undefined
    : data.routes
      .map(route => `${shortRoute(route.route)} ${route.requests}×${formatTokCount(route.outputTokens)}${route.tps === undefined ? '' : ` ${Math.round(route.tps)}t/s`}`)
      .join(' · ')
  return [
    { field: t('resume.field.session'), value: data.id ?? '—' },
    { field: t('resume.field.cwd'), value: data.cwd ?? '—' },
    { field: t('resume.field.created'), value: data.createdAt === undefined ? '—' : new Date(data.createdAt).toLocaleString() },
    { field: t('resume.field.model'), value: data.model ?? '—' },
    { field: t('resume.field.think'), value: data.effort ?? '—' },
    { field: t('resume.field.status'), value: data.status },
    { field: t('resume.field.messages'), value: String(data.msgCount) },
    { field: t('resume.field.toolcalls'), value: String(data.toolCallCount) },
    { field: t('resume.field.tokInOut'), value: `${data.inputTokens} / ${data.outputTokens}` },
    { field: t('resume.field.cacheRW'), value: `${data.cacheReadTokens} / ${data.cacheWriteTokens}` },
    { field: t('resume.field.speed'), value: data.overallTps === undefined ? '—' : `${Math.round(data.overallTps)} tok/s` },
    { field: t('resume.field.models'), value: models ?? '—' },
    { field: t('resume.field.events'), value: data.eventCount === undefined ? '—' : String(data.eventCount) },
    // Same short form the /resume rows use — a parent id is a pointer, not
    // something to read in full.
    { field: t('resume.field.parent'), value: data.parentSession === undefined ? '—' : clipToWidth(data.parentSession, 8) },
  ]
}

/** Compact token count for the models row: `12.3k` above 10k, plain below. */
function formatTokCount(tokens: number): string {
  return tokens >= 10_000 ? `${(tokens / 1000).toFixed(1)}k` : String(tokens)
}

/**
 * One-shot info panel in the shared FW auto-table style: FIELD fits its
 * content (capped), VALUE runs to the right edge and clips (never wraps),
 * width-exact padded cells under the booktabs rule trio — the same table
 * language as the /resume picker and every other panel. Esc closes; when
 * `onRename` is wired, `r` enters an inline rename edit on the same 20-row
 * budget (the input line replaces the hint line, never a table row):
 * Enter commits through {@link SessionRenameFn}, Esc returns to the table.
 */
export class SessionInfoPanel implements Component {
  private readonly theme: TuiTheme
  private readonly data: SessionPanelData
  private readonly onClose: () => void
  private readonly onRename: SessionRenameFn | undefined
  /** Rename edit state: only one of these is live at a time. */
  private editing = false
  private buffer = ''
  /** Accepted/failed rename note; shown on the hint line until the next keypress. */
  private note: RenameOutcome | undefined
  /** The live heading title after a committed rename (the snapshot data is stale then). */
  private titleOverride: string | undefined

  constructor(theme: TuiTheme, data: SessionPanelData, onClose: () => void, onRename?: SessionRenameFn) {
    this.theme = theme
    this.data = data
    this.onClose = onClose
    this.onRename = onRename
  }

  invalidate(): void {}

  render(width: number): string[] {
    // Scope note rides on the title line (no extra row: the panel must stay
    // at 20 rows so the framed overlay keeps its bottom border on a 24-row
    // terminal). The heading carries the session title when one exists (same
    // zero-row trick); the token totals are per provider/model route segment
    // — they reset on a route change — while messages/events are session-wide.
    const fns = panelThemeFns(this.theme)
    const title = this.titleOverride ?? this.data.title
    const heading = title !== undefined && title !== ''
      ? t('resume.headingTitle', { title })
      : t('resume.headingPlain')
    const lines: string[] = [fns.accent(BOLD + clipToWidth(heading, width) + RESET)]
    if (this.data.id === undefined) {
      lines.push('')
      lines.push(fns.muted(clipToWidth(t('resume.empty'), width)))
      lines.push('')
      lines.push(fns.subtle(clipToWidth(t('resume.hintClose'), width)))
      return lines
    }

    // Auto layout: FIELD fits its content (capped), VALUE is flex — it takes
    // the remainder and clips, so long values (cwd, full session id) never wrap.
    const rows = sessionInfoRows(this.data)
    const columns = autoColumns(
      [
        { key: 'field', title: t('resume.col.field'), cap: FIELD_CAP },
        { key: 'value', title: t('resume.col.value') },
      ],
      rows,
      (row, key) => (key === 'value' ? row.value : row.field),
    )
    const widths = columnWidths(width - MARKER_W, columns)

    // The booktabs trio seals the table right under the title (no gap row):
    // TOP ┬ / header / MID ┼ / rows / BOTTOM ┴. Total height stays at 20 rows
    // so the framed overlay keeps its bottom border on a 24-row terminal.
    lines.push(fns.subtle(clipToWidth(tableRuleLine(widths, '┬'), width)))
    lines.push(fns.subtle(clipToWidth(tableHeaderLine(columns, widths), width)))
    lines.push(fns.subtle(clipToWidth(tableRuleLine(widths, '┼'), width)))
    for (const row of rows) {
      // Clip plain text BEFORE applying ANSI (iron rule 3). The flex column
      // is additionally clamped to the space actually left on the row (the
      // MIN_FLEX_WIDTH floor can push the layout past `width` on narrow
      // terminals), so the painted line never needs a second clip — cutting
      // ANSI-carrying text would leave a dangling SGR fragment behind.
      const fieldCell = padCell(row.field, widths[0]!)
      const remaining = width - MARKER_W - visibleWidth(TABLE_SEP) - visibleWidth(fieldCell)
      const valueCell = padCell(row.value, Math.min(widths[1]!, Math.max(remaining, 0)))
      const paintedValue = row.field === t('resume.field.status') && this.data.status === 'running'
        ? fns.accent(valueCell)
        : fns.muted(valueCell)
      lines.push(`${' '.repeat(MARKER_W)}${fieldCell}${TABLE_SEP}${paintedValue}`)
    }
    lines.push(fns.subtle(clipToWidth(tableRuleLine(widths, '┴'), width)))
    lines.push(this.hintLine(width, fns))
    return lines
  }

  /** The panel's last line: the rename input while editing, else the key hint (with a transient note). */
  private hintLine(width: number, fns: ReturnType<typeof panelThemeFns>): string {
    if (this.editing) {
      const cursor = '▏'
      const body = this.buffer === ''
        ? clipToWidth(t('resume.renameEmpty', { cursor }), width)
        : clipToWidth(t('resume.renameEdit', { buffer: this.buffer, cursor }), width)
      const failed = this.note !== undefined && !this.note.ok ? `✗ ${this.note.note} · ` : ''
      const suffix = clipToWidth(`${failed}${t('resume.hintEdit')}`, Math.max(width - visibleWidth(body) - 1, 0))
      return fns.accent(clipToWidth(`${body} ${suffix}`, width))
    }
    if (this.note !== undefined) {
      const mark = this.note.ok ? '✓' : '✗'
      const next = ` · ${this.data.canRename ? t('resume.hintRename') : t('resume.hintClose')}`
      return fns.accent(clipToWidth(`${mark} ${this.note.note}${next}`, width))
    }
    const hint = this.data.canRename ? t('resume.hintRename') : t('resume.hintClose')
    return fns.subtle(clipToWidth(hint, width))
  }

  handleInput(data: string): void {
    const kb = getKeybindings()
    if (this.editing) {
      if (kb.matches(data, 'tui.select.cancel')) {
        this.editing = false
        this.buffer = ''
        this.note = undefined
        return
      }
      if (kb.matches(data, 'tui.select.confirm')) {
        this.commitRename()
        return
      }
      if (data === '\x7f' || matchesKey(data, 'backspace')) {
        this.buffer = this.buffer.slice(0, -1)
        this.note = undefined
        return
      }
      // Printable accumulation, paste-tolerant: an IME composition or a
      // bracketed paste arrives as one multi-char chunk — accept it whole
      // when every char is printable (control keys were matched above).
      if (data.length > 0 && [...data].every(ch => ch.charCodeAt(0) >= 0x20 && ch.charCodeAt(0) !== 0x7f)) {
        this.buffer += data
        this.note = undefined
      }
      return
    }
    if (this.data.canRename && data === 'r') {
      this.editing = true
      this.buffer = this.titleOverride ?? this.data.title ?? ''
      this.note = undefined
      return
    }
    this.note = undefined
    if (kb.matches(data, 'tui.select.cancel') || kb.matches(data, 'tui.select.confirm')) {
      this.onClose()
    }
  }

  /** Commit the edit through the caller's rename fn; a failure keeps the edit open. */
  private commitRename(): void {
    if (this.onRename === undefined) return
    const title = this.buffer.trim()
    if (title === '') {
      this.note = { ok: false, note: t('resume.titleEmpty') }
      return
    }
    let outcome: RenameOutcome
    try {
      outcome = this.onRename(title)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      outcome = { ok: false, note: message }
    }
    this.note = outcome
    if (outcome.ok) {
      this.titleOverride = outcome.title ?? title
      this.editing = false
      this.buffer = ''
    }
  }
}

/**
 * Open the `/session` info panel; resolves when the user closes it. Focus
 * returns to `restoreFocus` on close — it must re-focus the CURRENT editor
 * instance, which may have been rebuilt under a theme hot-swap while the
 * panel was open (pi-tui's hide would otherwise restore focus to the stale
 * pre-overlay editor and swallow subsequent input). `onRename` wires the
 * panel's `r` rename edit; omit it (or leave `canRename` false in the data)
 * when no live session or no title service exists and the panel stays
 * read-only.
 */
export async function showSessionInfo(
  tui: TUI,
  theme: TuiTheme,
  data: SessionPanelData,
  restoreFocus: () => void,
  onRename?: SessionRenameFn,
): Promise<void> {
  await new Promise<void>(resolve => {
    const panel = new SessionInfoPanel(theme, data, () => {
      overlay.hide()
      restoreFocus()
      resolve()
    }, onRename)
    // maxHeight only ever slices (never stretches), and the framed overlay
    // needs 4 extra rows for its borders: cap high so the bottom border
    // survives on small terminals (24 rows: 20 panel rows + 4 frame rows).
    const overlay = tui.showOverlay(wrapFramedOverlay(theme, panel), { width: '70%', maxHeight: '100%' })
  })
}

// ------------------------------------------------------------- `/resume` picker --
// Each row is labelled with the session's first-message preview (the first
// direct human prompt) so sessions are distinguishable without opening them;
// fallback rows show the header label (cwd basename · short id).

/**
 * The `sessionPersistence` service surface we use (registered by the profile).
 * Shared with the /history browser, whose session picker reuses the same
 * list/inspect vocabulary.
 */
export interface SessionPersistence {
  /**
   * Lightweight read of persisted session metadata. dsh 0.1.5-rc.1 wraps each
   * header in a `{header, revision, sizeBytes}` snapshot; 0.1.2 returned bare
   * headers — `headerOf` normalizes both.
   */
  list(signal?: AbortSignal): Promise<Array<SessionHeader | { header: SessionHeader }>>
  /**
   * Legacy (≤ 0.1.2) one-shot validated read. dsh 0.1.5-rc.1 removed it —
   * `readPersistedSession` routes through `open` + a read-handle drain
   * instead; the two share this seam's structural type.
   */
  inspect?(id: SessionId, signal?: AbortSignal): Promise<{ meta: SessionHeader; events: readonly SessionEvent[] }>
  /**
   * dsh 0.1.5-rc.1: validated cold read = `open(id, 'read')` + a full
   * `read()` drain on the returned handle, header riding the handle.
   */
  open?(sessionId: SessionId, access: 'read' | 'write', options?: { signal?: AbortSignal }): Promise<{
    header: SessionHeader
    read(offset?: number, length?: number, options?: { signal?: AbortSignal }): Promise<{ events: readonly SessionEvent[] }>
    close(): Promise<void>
  }>
}

/**
 * Normalize one `persistence.list()` entry to its bare {@link SessionHeader}:
 * the 0.1.5-rc.1 host returns `{header, ...}` snapshots where 0.1.2 returned
 * the header directly.
 */
export function headerOf(entry: SessionHeader | { header: SessionHeader }): SessionHeader {
  return (entry as { header?: SessionHeader }).header ?? (entry as SessionHeader)
}

/**
 * Validated cold read of one stored session's full log, `{meta, events}` —
 * the shared body of the /resume pre-check, /session info, and the preview
 * harvest. Routes the two host seam generations: the 0.1.5 `open` + read-
 * handle drain when present, else the legacy one-shot `inspect`.
 */
export async function readPersistedSession(
  persistence: SessionPersistence,
  id: SessionId,
): Promise<{ meta: SessionHeader; events: readonly SessionEvent[] }> {
  if (typeof persistence.open === 'function') {
    const handle = await persistence.open(id, 'read')
    try {
      const events: SessionEvent[] = []
      let offset = 0
      for (;;) {
        const batch = await handle.read(offset)
        if (batch.events.length === 0) break
        events.push(...batch.events)
        offset += batch.events.length
      }
      return { meta: handle.header, events }
    } finally {
      await handle.close()
    }
  }
  if (typeof persistence.inspect !== 'function') {
    throw new Error(t('resume.noBackend'))
  }
  return await persistence.inspect(id)
}

/**
 * How many of the most recent candidates get a first-message preview before
 * the picker opens. Older sessions fall back to the header label, so the
 * picker stays fast even with a long history. Shared with the /history
 * session picker (same enrichment vocabulary, same cap).
 */
export const PREVIEW_SESSION_CAP = 30

/**
 * Visible-width cap for the DIR column. Fitted column widths scan EVERY
 * candidate row, not just the visible ones, and real cwds span 12–67 chars
 * (measured over the local session store; the 67-char deep repo path blew
 * the column out to ~70 and starved the flex SESSION tail). 32 keeps the
 * 90th-percentile cwd (~31 chars) fully visible and clips only the deep
 * outliers — longer paths truncate with an ellipsis. Shared with the
 * /history session picker.
 */
export const RESUME_DIR_CAP = 32

/**
 * Only sessions with log activity inside this window appear in `/resume`
 * (mtime semantics, same as the Updated column and the sort). The DEFAULT of
 * the resume-filter precedence chain (settings.yaml `dsh-tui.resume.maxAgeDays`
 * > `DSH_TUI_RESUME_MAX_AGE_DAYS` > this constant), deliberately coupled in
 * VALUE with its retention twin `RETENTION_MAX_AGE_DAYS` (src/retention.ts):
 * the two 90s are one product decision ("a quarter is the working set") but
 * serve different masters (this one HIDES picker rows, retention DELETES
 * logs), so they are separate constants — change them together.
 * Boundary semantics match retention: the boundary case survives in both
 * (retention deletes strictly-older-than, the picker keeps
 * not-older-than).
 */
export const RESUME_MAX_AGE_DAYS = 90

/**
 * Minimum on-disk log size for a session to appear in `/resume` — the
 * DEFAULT of the same precedence chain (`dsh-tui.resume.minBytes` >
 * `DSH_TUI_RESUME_MIN_BYTES` > this constant). This is the COMPRESSED size
 * — `stat().size` of `session.jsonl` or `session.jsonl.zstd`, whichever
 * exists — read from the same stat the mtime walk already does (zero extra
 * IO, no decompression). A session below 1KB is a stub or a false start,
 * not worth a picker row — but a real short conversation (a few commands
 * and replies) is typically far larger, so a 1KB floor keeps e2e/demo
 * stubs out of the picker without hiding genuine small sessions.
 */
export const RESUME_MIN_BYTES = 1024

/**
 * Explicit `dsh-tui.resume` overrides from settings.yaml — the USER layer
 * of the settings document (theme-settings.ts hands the raw section
 * through), so every field is `unknown`: a hand-edited file can carry
 * anything. Absent fields are simply not overridden; present-but-invalid
 * ones are rejected by `resolveResumeConfig` with one notice each.
 */
export interface ResumeSettingsInput {
  maxAgeDays?: unknown
  minBytes?: unknown
}

/** The `/resume` display-filter knobs after settings/env resolution. */
export interface ResumeConfig {
  /** Keep sessions with activity no older than this many days. */
  maxAgeDays: number
  /** Keep sessions whose compressed on-disk log is at least this many bytes. */
  minBytes: number
}

/**
 * One env slot parsed: a finite number passing `accept`, or undefined when
 * absent/garbage (an `accept` rejection is garbage too — it falls to the
 * default silently, same contract as src/retention.ts).
 */
function finiteEnv(
  raw: string | undefined,
  accept: (value: number) => boolean = () => true,
): number | undefined {
  if (raw === undefined || raw.trim() === '') return undefined
  const value = Number(raw)
  return Number.isFinite(value) && accept(value) ? value : undefined
}

/**
 * Narrow one explicit settings field: a finite number passing `accept`, or
 * undefined (absent, or present-but-invalid). An invalid value emits one
 * notice through the shared bridge (src/notice-bridge.ts) naming the
 * field and its raw value, so a hand-edited settings.yaml is debuggable;
 * the caller falls to the next level. The picker is opened with the TUI
 * long up, so these typically deliver straight to the sink.
 */
function explicitSetting(
  section: ResumeSettingsInput | undefined,
  key: keyof ResumeSettingsInput,
  accept: (value: number) => boolean,
): number | undefined {
  const raw = section?.[key]
  if (raw === undefined) return undefined
  if (typeof raw !== 'number' || !Number.isFinite(raw) || !accept(raw)) {
    emitNotice(
      t('resume.settingInvalid', { key, value: JSON.stringify(raw) }),
    )
    return undefined
  }
  return raw
}

/**
 * Resolve the `/resume` display-filter knobs through the same precedence
 * chain as retention (src/retention.ts): an explicit settings.yaml value
 * (`dsh-tui.resume.*`) outranks the environment variables
 * (`DSH_TUI_RESUME_MAX_AGE_DAYS` / `DSH_TUI_RESUME_MIN_BYTES`), which
 * outrank the defaults — settings is what the user deliberately persisted.
 * An invalid settings value emits one notice (shared bridge) and falls to
 * the next level; an invalid env value falls back silently to the
 * default. Validity:
 * the age window must be > 0 (0 would empty the picker), the byte floor
 * must be an integer >= 0 (0 legitimately lifts the floor for stubs) — at
 * BOTH layers. A fractional byte floor like 20480.5 is garbage even though
 * it parses finite and positive: `stat().size` is integral, so a
 * fractional floor would silently bar exactly-at-the-boundary logs
 * (20480 < 20480.5) without the user ever seeing why.
 * Pure; `process.env` and the settings section are passed explicitly so
 * tests can pin them.
 */
export function resolveResumeConfig(
  env: Record<string, string | undefined> = process.env,
  settings?: ResumeSettingsInput,
): ResumeConfig {
  const sMaxAgeDays = explicitSetting(settings, 'maxAgeDays', value => value > 0)
  const sMinBytes = explicitSetting(settings, 'minBytes', value => Number.isInteger(value) && value >= 0)
  const maxAgeDays = sMaxAgeDays ?? finiteEnv(env.DSH_TUI_RESUME_MAX_AGE_DAYS)
  const minBytes = sMinBytes ?? finiteEnv(
    env.DSH_TUI_RESUME_MIN_BYTES,
    value => Number.isInteger(value) && value >= 0,
  )
  return {
    maxAgeDays: maxAgeDays !== undefined && maxAgeDays > 0 ? maxAgeDays : RESUME_MAX_AGE_DAYS,
    minBytes: minBytes ?? RESUME_MIN_BYTES,
  }
}

/** Concurrent `inspect` calls while enriching previews. */
const PREVIEW_CONCURRENCY = 6

/**
 * The jsonl persistence root guess: `$DSH_SESSION_ROOT`, else
 * `$DSH_HOME/sessions`, else `~/.dsh/sessions` — the dsh CLI convention. Only
 * used for the mtime-based last-update enrichment; a mismatched root simply
 * leaves the picker sorted by `createdAt` (the pre-existing behavior).
 * Deliberate contrast with retention's `sessionStoreRoot()`
 * (src/retention.ts), which ignores `$DSH_SESSION_ROOT`: that walk aims
 * `fs.rm` and must resolve exactly the tree the core writer appends to,
 * while this one only enriches/filters picker rows — a wrong root here
 * degrades display, it never deletes anything.
 */
export function sessionLogRoot(): string {
  if (process.env.DSH_SESSION_ROOT !== undefined && process.env.DSH_SESSION_ROOT !== '') {
    return process.env.DSH_SESSION_ROOT
  }
  const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
  return join(home, 'sessions')
}

/** How many ms one day holds — same vocabulary as src/retention.ts. */
const DAY_MS = 24 * 60 * 60 * 1000

/**
 * One session log's stat snapshot from the walk: last write plus the
 * COMPRESSED on-disk size (both from the same `stat` call).
 */
export interface SessionLogStat {
  mtimeMs: number
  size: number
}

/**
 * Best-effort session-id → log-stat map from the jsonl store's files: one
 * walk of `<root>/<project>/<session>/session.jsonl[.zstd]`, one stat per
 * existing log name (mtime + compressed size, zero extra IO; when both
 * names exist the NEWEST mtime wins and carries its own size — retention's
 * walk vocabulary). Session directory names are
 * the path-encoded session ids — UUID ids encode to themselves, so the
 * common case matches by name; an encoded mismatch just misses the map and
 * falls back to `createdAt`. Any failure resolves an empty map (the picker
 * degrades to creation-order sorting and the activity filter fails open).
 */
export async function loadSessionLastUpdates(root: string = sessionLogRoot()): Promise<Map<string, SessionLogStat>> {
  const updates = new Map<string, SessionLogStat>()
  let projects: string[]
  try {
    projects = (await readdir(root, { withFileTypes: true }))
      .filter(entry => entry.isDirectory())
      .map(entry => entry.name)
  } catch {
    return updates
  }
  for (const project of projects) {
    let sessionDirs: string[]
    try {
      sessionDirs = (await readdir(join(root, project), { withFileTypes: true }))
        .filter(entry => entry.isDirectory())
        .map(entry => entry.name)
    } catch {
      continue
    }
    for (const dir of sessionDirs) {
      // Same last-activity vocabulary as retention's walk: a session's
      // activity is the NEWEST mtime across BOTH log names — the raw and
      // the compressed file may coexist (mid-compression, or a kept raw
      // copy), and breaking on the first existing suffix would hide an
      // active session behind its stale sibling and drop it from /resume
      // via the age filter. The size rides the SAME stat as the winning
      // mtime, so the minBytes filter judges the file that proves the
      // activity.
      let newest: SessionLogStat | undefined
      for (const name of SESSION_LOG_FILE_NAMES) {
        try {
          const info = await stat(join(root, project, dir, name))
          if (newest === undefined || info.mtimeMs > newest.mtimeMs) {
            newest = { mtimeMs: info.mtimeMs, size: info.size }
          }
        } catch {
          // Not this suffix — try the next one.
        }
      }
      if (newest !== undefined && newest.mtimeMs > 0) updates.set(dir, newest)
    }
  }
  return updates
}

/**
 * Order resumable candidates by LAST update (newest first): the mtime map
 * when a log file is known, else the header's `createdAt`. Ties fall back to
 * `createdAt` then the id, so the order is deterministic. Pure — the mtime
 * walk lives in `loadSessionLastUpdates`.
 *
 * The ordering is FIXED — no sort spec, no dynamic field, ever. Every key is
 * coerced to a finite number (or a plain string) before the comparator sees
 * it, so a corrupted log stat cannot inject a NaN into the ordering.
 */
function lastUpdateSortKey(
  header: SessionHeader,
  logStats: ReadonlyMap<string, SessionLogStat>,
): { mtime: number; created: number; id: string } {
  const stat = logStats.get(String(header.id))
  const mtime = typeof stat?.mtimeMs === 'number' && Number.isFinite(stat.mtimeMs)
    ? stat.mtimeMs
    : header.createdAt
  const created = typeof header.createdAt === 'number' && Number.isFinite(header.createdAt)
    ? header.createdAt
    : 0
  return { mtime, created, id: String(header.id) }
}

export function orderSessionsByLastUpdate(
  headers: readonly SessionHeader[],
  logStats: ReadonlyMap<string, SessionLogStat>,
): SessionHeader[] {
  return headers.slice().sort((a, b) => {
    const ka = lastUpdateSortKey(a, logStats)
    const kb = lastUpdateSortKey(b, logStats)
    if (kb.mtime !== ka.mtime) return kb.mtime - ka.mtime
    if (kb.created !== ka.created) return kb.created - ka.created
    return kb.id.localeCompare(ka.id)
  })
}

/** Knobs of the `/resume` display filter; `now` is injected so it is testable. */
export interface ResumeActivityPolicy {
  /** Keep sessions with activity no older than this many days. */
  maxAgeDays: number
  /** Keep sessions whose compressed on-disk log is at least this many bytes. */
  minBytes: number
  /** Reference time, ms since the epoch. */
  now: number
}

/**
 * The `/resume` display filter: only sessions with RECENT activity and a
 * real log body get a picker row. Age follows the same value the Updated
 * column and the sort show — the walked mtime when known, else the header's
 * `createdAt` — with retention's boundary semantics (exactly `maxAgeDays`
 * old survives; only strictly older is dropped). Size is the compressed
 * on-disk `stat().size`, inclusive at `minBytes` (1024 passes, 1023 does
 * not). A session MISSING from the stat map fails OPEN on size: the walk is
 * best-effort (unknown root, path-encoded id mismatch) and must never empty
 * the picker by itself — but its age still applies through `createdAt`.
 * Pure; the exclusion of the current session and subagent children happens
 * upstream in `pickPersistedSession` and is untouched by this filter.
 */
export function filterSessionsByLastActivity(
  headers: readonly SessionHeader[],
  logStats: ReadonlyMap<string, SessionLogStat>,
  policy: ResumeActivityPolicy,
): SessionHeader[] {
  const ageCutoff = policy.now - policy.maxAgeDays * DAY_MS
  return headers.filter(header => {
    const stat = logStats.get(String(header.id))
    if (stat === undefined) return header.createdAt >= ageCutoff
    return stat.mtimeMs >= ageCutoff && stat.size >= policy.minBytes
  })
}

/** Hard character cap for a preview string; the list column clips it further. */
const PREVIEW_MAX_CHARS = 140

/** Join the text blocks of a message's content into one trimmed string. */
function textOfContent(content: unknown): string {
  if (typeof content === 'string') return content.trim()
  if (!Array.isArray(content)) return ''
  let text = ''
  for (const block of content) {
    if (block && typeof block === 'object' && (block as { type?: unknown }).type === 'text') {
      const blockText = (block as { text?: unknown }).text
      if (typeof blockText === 'string') text += blockText + ' '
    }
  }
  return text.trim()
}

/**
 * The session's "first sentence": the first direct human prompt, falling
 * back to the first non-injected user-role text (goal/cron/recall prompts),
 * then the first assistant message. Synthetic context injects (workspace
 * instructions, runtime reminders) are skipped entirely — they precede the
 * first real prompt and read as noise.
 *
 * The skip list spells the 0.1.7 producer-kind vocabulary: the shared
 * 'plugin' kind is gone (producers declare their own merge-extensible
 * kinds), so the known synthetic kinds — 'system-prompt', 'tool',
 * 'model-selection', 'user-approval', 'skill-invocation', 'ptc-mode',
 * 'tool-registry' — are enumerated explicitly, and any UNKNOWN kind still
 * falls through to the fallback tier (the documented consumer default).
 */
export function previewOfEvents(events: readonly SessionEvent[]): string | undefined {
  // Synthetic producer kinds whose user-role rows are never a session title.
  // 'plugin' and 'agent-instructions' are the pre-0.1.7 spellings still
  // present in migrated legacy logs.
  const SYNTHETIC_KINDS = new Set([
    'system-prompt', 'tool', 'model-selection', 'user-approval',
    'skill-invocation', 'ptc-mode', 'tool-registry', 'plugin', 'agent-instructions',
  ])
  let fallbackUser: string | undefined
  let fallbackAssistant: string | undefined
  for (const event of events) {
    if (event.type === 'user/message') {
      const message = event.data as { role?: string; source?: { kind?: string }; content?: unknown }
      const text = textOfContent(message?.content)
      if (!text) continue
      const kind = message?.source?.kind
      if (kind === 'user') return text
      if (kind !== undefined && SYNTHETIC_KINDS.has(kind)) continue
      if (fallbackUser === undefined) fallbackUser = text
    } else if (event.type === 'assistant/message') {
      const message = (event.data as { message?: { content?: unknown } }).message
      const text = textOfContent(message?.content)
      if (text && fallbackAssistant === undefined) fallbackAssistant = text
    }
  }
  return fallbackUser ?? fallbackAssistant
}

/** Collapse control chars/whitespace and clip a raw message into a one-line preview. */
export function normalizePreview(text: string, maxChars = PREVIEW_MAX_CHARS): string {
  const oneLine = text.replace(/[\x00-\x1f\x7f]+/g, ' ').replace(/\s+/g, ' ').trim()
  return oneLine.length <= maxChars ? oneLine : `${oneLine.slice(0, maxChars)}…`
}

/**
 * The picker row's SESSION-column label: the first-message preview when one
 * was read, else the header label (cwd basename · short id). `corrupt`
 * prepends the ⚠ marker — the same pre-read `inspect` that harvests previews
 * already diagnosed this log as corrupt, and selecting the row will offer an
 * in-place repair instead of a dead end. Pure so the marker contract is
 * unit-testable without a store.
 */
export function resumeRowTitle(header: SessionHeader, preview: string | undefined, corrupt: boolean): string {
  const base = preview ?? `${basename(header.cwd ?? '?')} · ${clipToWidth(String(header.id), 8)}`
  return corrupt ? `⚠ ${base}` : base
}

/**
 * Best-effort first-message preview per session id; failures map to
 * undefined, and failures matching the corrupt-log fingerprint additionally
 * record the id in `corruptIds` — zero extra IO (the inspect calls already
 * ran for the previews), so the ⚠ rows stay a free byproduct of enrichment.
 * Exported for the /history session picker, which reuses the exact same
 * enrichment (same concurrency, same corrupt fingerprint).
 */
export async function loadSessionPreviews(
  persistence: SessionPersistence,
  ids: readonly SessionId[],
): Promise<{ previews: Map<string, string | undefined>; corruptIds: Set<string> }> {
  const previews = new Map<string, string | undefined>()
  const corruptIds = new Set<string>()
  let cursor = 0
  const workers = Array.from({ length: Math.min(PREVIEW_CONCURRENCY, ids.length) }, async () => {
    while (cursor < ids.length) {
      const index = cursor++
      const id = ids[index]
      let preview: string | undefined
      try {
        const { events } = await readPersistedSession(persistence, id)
        const text = previewOfEvents(events)
        if (text) preview = normalizePreview(text)
      } catch (error) {
        preview = undefined
        const message = error instanceof Error ? error.message : String(error)
        if (isCorruptLogError(message)) corruptIds.add(String(id))
      }
      previews.set(String(id), preview)
    }
  })
  await Promise.all(workers)
  return { previews, corruptIds }
}

/**
 * Validate one persisted session's log without publishing it — the /resume
 * pre-check: a corrupt target must be rejected BEFORE the current live agent
 * is torn down. Throws when persistence is missing or the log fails to load.
 *
 * dsh 0.1.5-rc.1 removed the one-shot `inspect` from the service: validated
 * cold reads go through `open(id, 'read')` + a full `read()` drain, with the
 * header riding the handle.
 */
export async function inspectPersistedSession(
  ctx: Context,
  id: SessionId,
): Promise<{ meta: SessionHeader; events: readonly SessionEvent[] }> {
  const persistence = ctx.get('sessionPersistence') as SessionPersistence | undefined
  if (persistence === undefined) {
    throw new Error(t('resume.noPersistence'))
  }
  return await readPersistedSession(persistence, id)
}

/** Outcome of the `/resume` picker, so the caller can phrase its reply. */
export type PickSessionResult =
  /** The store holds no other resumable session at all. */
  | { kind: 'empty' }
  /**
   * Resumable sessions exist, but the display filter (age window / byte
   * floor) hid every one of them. The effective knobs ride along so the
   * caller can name the window that emptied the list and point at the
   * `dsh-tui.resume.*` knobs that widen it, instead of reporting "no
   * sessions" over a store full of filtered-out ones. `hidden` counts the
   * candidates the filter dropped.
   */
  | { kind: 'empty-filtered'; hidden: number; maxAgeDays: number; minBytes: number }
  | { kind: 'cancelled' }
  | { kind: 'picked'; id: SessionId; header: SessionHeader }

/**
 * Whether a persisted session header may be resumed as this TUI's main
 * conversation. Subagent children — spawn and fork-driven alike, both marked
 * `origin: 'subagent'` + `delegationDepth >= 1` — are excluded: resuming one
 * would misplace it in the recursion budget. Everything else is resumable.
 *
 * The budget test MUST be a value test, not a field-presence test: the jsonl
 * persistence backend writes `delegationDepth: header.delegationDepth ?? 0`
 * and reads it back unconditionally, so EVERY header from
 * `persistence.list()` carries the field — top-level sessions and
 * user-facing `Session.fork` conversations as `0`. A presence test
 * (`=== undefined`) would filter out every persisted session and leave
 * `/resume` with an empty list.
 */
export function isResumableSessionHeader(header: SessionHeader): boolean {
  return header.origin !== 'subagent' && (header.delegationDepth ?? 0) === 0
}

/**
 * Open the persisted-session picker. Resolves with the picked session,
 * `cancelled` when dismissed, `empty` when no other resumable session
 * exists, or `empty-filtered` when resumable sessions exist but the
 * display filter (age/size) hid them all — the two empties read
 * differently to the user (nothing stored vs. adjust the window). Throws
 * when the profile has no persistence backend. Focus returns to
 * `restoreFocus` on close. `resumeSettings` is the explicit
 * `dsh-tui.resume` section from settings.yaml (the user layer, read by the
 * caller through `readSessionManagementExplicit`) — the picker resolves it
 * against the environment and the defaults per open, so a committed
 * settings change applies to the next /resume without a restart.
 */
export async function pickPersistedSession(
  ctx: Context,
  tui: TUI,
  theme: TuiTheme,
  excludeSessionId: string | undefined,
  restoreFocus: () => void,
  resumeSettings?: ResumeSettingsInput,
): Promise<PickSessionResult> {
  const persistence = ctx.get('sessionPersistence') as SessionPersistence | undefined
  if (persistence === undefined) {
    throw new Error(t('resume.noPersistence'))
  }
  let headers: SessionHeader[]
  try {
    headers = (await persistence.list()).map(headerOf)
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    throw new Error(t('resume.listFailed', { message }))
  }
  const candidates = headers
    .filter(isResumableSessionHeader)
    .filter(header => String(header.id) !== excludeSessionId)
  // Order by last update (mtime of the jsonl log when known, else createdAt)
  // so a session the user touched yesterday-but-created-last-month surfaces
  // above newer-created stale ones. The mtime walk is best-effort: an
  // unknown root keeps the previous createdAt ordering.
  const lastUpdates = await loadSessionLastUpdates()
  // Display filter: only sessions active within the age window AND with a
  // log of at least `minBytes` (compressed) get a row — knobs resolved per
  // open through the precedence chain (settings explicit > env > default,
  // `resolveResumeConfig`). Applied between the walk and the sort so both
  // consume the same stats; a list this empties resolves one of the two
  // empties below, so the user can tell "nothing stored" apart from
  // "the window hid them".
  const resumeConfig = resolveResumeConfig(process.env, resumeSettings)
  const visible = filterSessionsByLastActivity(candidates, lastUpdates, {
    maxAgeDays: resumeConfig.maxAgeDays,
    minBytes: resumeConfig.minBytes,
    now: Date.now(),
  })
  const ordered = orderSessionsByLastUpdate(visible, lastUpdates)
  if (ordered.length === 0) {
    return candidates.length === 0
      ? { kind: 'empty' }
      : {
          kind: 'empty-filtered',
          hidden: candidates.length,
          maxAgeDays: resumeConfig.maxAgeDays,
          minBytes: resumeConfig.minBytes,
        }
  }

  // Enrich the most recent candidates with their first-message preview so the
  // rows are distinguishable at a glance; older ones fall back to the header
  // label (cwd + short id). Logs the enrichment inspect diagnosed as corrupt
  // get the ⚠ marker — a free byproduct of the same calls, never a new scan.
  const { previews, corruptIds } = await loadSessionPreviews(
    persistence,
    ordered.slice(0, PREVIEW_SESSION_CAP).map(header => header.id),
  )

  const rows = ordered.map(header => {
    const id = String(header.id)
    const updated = lastUpdates.get(id)?.mtimeMs ?? header.createdAt
    return {
      value: id,
      header,
      session: resumeRowTitle(header, previews.get(id), corruptIds.has(id)),
      when: new Date(updated).toLocaleString(),
      dir: header.cwd ?? t('resume.noCwd'),
    }
  })

  return new Promise<PickSessionResult>(resolve => {
    // Auto layout: UPDATED and DIR fit their content, SESSION runs to the
    // edge (previews are often CJK, so it gets the flexible tail). DIR is
    // capped — fitted widths scan EVERY candidate row, so one deep cwd
    // would otherwise eat the session column (see RESUME_DIR_CAP).
    const columns: readonly TableColumn[] = autoColumns(
      [
        { key: 'when', title: t('resume.col.updated'), cap: 26 },
        { key: 'dir', title: t('resume.col.dir'), cap: RESUME_DIR_CAP },
        { key: 'session', title: t('resume.col.session') },
      ],
      rows,
      (row, key) => row[key as 'session' | 'when' | 'dir'],
    )
    const list = new TablePanel(theme, {
      title: t('resume.title'),
      columns,
      rows,
      renderCell: (row, column) => row[column.key as 'session' | 'when' | 'dir'],
      onSelect: row => finish(row.header),
      onCancel: () => finish(undefined),
    })

    // Framed overlay: 13 list rows + 4 frame rows fit inside 75% of 24 rows.
    const overlay = tui.showOverlay(wrapFramedOverlay(theme, list), { width: '80%', maxHeight: '75%' })

    function finish(picked: SessionHeader | undefined): void {
      overlay.hide()
      restoreFocus()
      resolve(picked === undefined
        ? { kind: 'cancelled' }
        : { kind: 'picked', id: picked.id, header: picked })
    }
  })
}
