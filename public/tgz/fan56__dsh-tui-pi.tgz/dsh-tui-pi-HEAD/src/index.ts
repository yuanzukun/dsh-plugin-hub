/**
 * dsh-tui-pi — pi-style terminal UI for DeepSeek Harness.
 *
 * Cordis plugin entry, mounted as a dsh profile bundle (`dsh.bundle.patch`).
 * The TUI runs in-process inside the dsh tree: it renders with
 * `@earendil-works/pi-tui`, talks to dsh services directly (ctx.agents,
 * ctx.commands, session events), and keeps dsh's slash commands untouched.
 *
 * @module dsh-tui-pi
 */

import type { Context } from '@deepseek-ai/cordis'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { hardExit } from './hard-exit.ts'
// Types only (erased at emit). The runtime import is deliberately avoided:
// the registry-published dsh-skill lib imports host-closure siblings
// (@deepseek-ai/dsh-scope, dsh-llm — peers of it, but absent from a plugin
// repo's own dependency graph), which dies under pnpm's isolated layout.
// The host injects the real service at runtime; these types only shape the
// provider object this plugin hands it.
import type { SkillCandidate, SkillDefinition, SkillProvider } from '@deepseek-ai/dsh-skill'

/** Mirrors dsh-skill's bundled-skill rank (a non-load-bearing ordering hint;
 *  the constant is hardcoded there too). Local copy — see the type-import
 *  note above for why dsh-skill is not loaded at runtime here. */
const BUNDLED_SKILL_RANK = 600
import { SessionId, type SessionEvent } from '@deepseek-ai/dsh-session'
// Loads dsh-tool-todo's SessionEventMap augmentation, which adds the
// 'todo/write' whole-list snapshot to the host's session event union
// (alpha.3 moved the TodoItem/'todo/write' declarations out of dsh-session;
// the root entry re-exports the types module).
import type {} from '@deepseek-ai/dsh-tool-todo'
import { Loader } from '@earendil-works/pi-tui'
import { CommandService, type LocalCommandHandler } from './commands.ts'
import type { ModelSelection } from '@deepseek-ai/dsh-agent'
import { FooterHint, PowerlineFooter, type FooterDataSource, type FooterHints } from './footer.ts'
import { GitBranchWatcher } from './git.ts'
import { ensureAppendSystemFile, dshHome, migrateAgentsMdTodoSection } from './append-system.ts'
import { TranscriptRenderer } from './messages.ts'
import type { PanelHeight } from './activity.ts'
import { AGENT_TICK_MS, ExternalWidgetFile, LiveWidgets } from './live-widgets.ts'
import { latestWorkflowRunDir, openWorkflowOverlayPanel, readWorkflowOverlayManifest } from './workflow-overlay-panel.ts'
import { displayPermissionPreset } from './permission.ts'
import { pickEffort, pickModel, pickPermission, pickPreset, pickTheme } from './selectors.ts'
import { DshSessionBridge, persistDefaultModel, stashSessionIdForReload, takeStashedSessionId, type BridgeCallbacks } from './session.ts'
import {
  bindTuiConfig,
  currentCacheHitMode,
  currentRememberPreset,
  currentThemePreference,
  readAskUserExplicit,
  readFooterHintsPreference,
  readIconSetPreference,
  readJevAttentionMode,
  readLanguagePreference,
  readPanelHeightPreference,
  readRememberPreset,
  readSessionManagementExplicit,
  readSubagentLimits,
  readThemePreference,
  subscribeThemeSettings,
  writeLanguagePreference,
  writeThemePreference,
  type TuiSettings,
} from './theme-settings.ts'
// The plugin's user-facing configuration schema. Exported at the module root:
// the loader reads `plugin.Config` off the entry module and projects every
// `.volatile()` field into the settings surface (the 0.1.7 replacement of the
// 0.1.5 runtime registration call).
export { Config } from './theme-settings.ts'
import { currentLocale, initI18n, listLocales, setLocale, t } from './i18n/index.ts'
import {
  loadWorkspacePresets,
  rememberedPresetFor,
  saveWorkspacePresets,
  withRememberedPreset,
  workspacePresetsPath,
} from './workspace-presets.ts'
import { applyIconSet, resolveIconSet, stopIcon, type IconSet } from './icons.ts'
import { readAgentMaxRounds } from './agent-runtime.ts'
import { detectNerdFontAvailable } from './font-detect.ts'
import { openAgentManager } from './agents.ts'
import { openSettingsBrowser } from './settings.ts'
import { CustomProviderFlow } from './custom-provider.ts'
import { openPluginsPanel, type PluginManagerSeam } from './plugins.ts'
import { openSearchOverlay } from './search.ts'
import { openSkillsManagerPanel } from './skills-manager.ts'
import { openLoginFlow, openLogoutFlow } from './login.ts'
import { reloadPlugin } from './reload.ts'
import { runSessionRetentionOnce } from './retention.ts'
import { setNoticeSink } from './notice-bridge.ts'
import {
  collectStartupSummary,
  formatResumeCommand,
  parseResumeArg,
  resolveProfileName,
  type StartupSummary,
} from './startup-info.ts'
import { inspectPersistedSession, pickPersistedSession, sessionLogRoot, showSessionInfo } from './sessions.ts'
import { decodeTps } from './tokens.ts'
import {
  isCorruptLogError,
  locateSessionLog,
  repairFailureNotice,
  repairSessionLog,
} from './log-repair.ts'
import { openRepairConfirmDialog } from './repair-dialog.ts'
import { projectKeyFor } from './session-dir.ts'
import { SessionAlreadyOwnedError } from '@deepseek-ai/dsh-session-persistence'
import { emitNotice } from './notice-bridge.ts'
import { applySubagentPolicy } from './subagent-policy.ts'
import { installSubagentStatusTool } from './subagent-status-tool.ts'
import { createJevAttentionSource } from './attention-jev.ts'
import { openSubagentViewer } from './subagent-viewer.ts'
import { openHistoryBrowser } from './history.ts'
import { openForkAtTurnDialog } from './history-fork.ts'
import { commandUsagePath, CommandUsageTracker } from './usage.ts'
import {
  buildUserPrompt,
  decideSubmitPath,
  deliverToAgent,
  promotePending,
  removeFromInbox,
  steerUnavailableNotice,
  turnEndedQueuedNotice,
  type PromptRoute,
  type QueueActionResult,
} from './steer-flow.ts'
import { openSubmitRouteDialog } from './route-dialog.ts'
import {
  BtwController,
  btwIdleNotice,
  btwUsage,
  buildBtwSnapshot,
  parseBtwInput,
  resolveSnapshotLimit,
} from './btw.ts'
import { BtwOverlayWire } from './btw-overlay.ts'
import { openPendingQueuePanel } from './queue-panel.ts'
import type { AgentView } from './dsh-events.ts'
import { ansiFg, BOLD, RESET, resolveTheme, type ThemePreference, type TuiTheme } from './theme/index.ts'
import { rgbIsLight } from './theme/palette.ts'
import { discoverThemes, scanThemeDir, userThemesDir } from './theme/registry.ts'
import { clipToWidth } from './text.ts'
import { type KeyAction } from './keymap.ts'
import { keybindingsPath, loadKeyBindings, openHotkeysManager } from './hotkeys.ts'
import { startTui, type TuiHandle } from './tui.ts'
import { currentPreset, fetchPresetRoster, findPresetByName, formatPresetLabel, initialPresetIndex, peekNextPreset, type PresetEntry, type PresetState } from './preset.ts'
import { completedTurnSeed, openPresetConfirmDialog, performPresetSwitch } from './preset-dialog.ts'
import { openStopConfirmDialog } from './stop-dialog.ts'
import { registerAskUserProvider, resolveAskUserTimeouts } from './ask-user.ts'
import { askLanguageChoice, type AskSeam, type LanguageOutcome } from './language-ask.ts'
import { checkHostSupport } from './host-version.ts'

export const name = 'dsh-tui-pi'

/**
 * Delay (ms) before a double-Ctrl+C quit actually fires — a held key's first
 * auto-repeat lands inside the 500ms double-press window looking like a
 * deliberate second press, and a follow-up `key-repeat` (arriving within
 * ~30-50ms) aborts the quit before this timer ever fires.
 */
const QUIT_CONFIRM_MS = 200

/**
 * The TUI drives the agent factory and registers slash commands. The render
 * effect also touches `ctx.systemPrompt` (ask-user guidance section) and the
 * ask-user provider effect touches `ctx.userQuestions`; `ctx.skills` serves
 * the bundled usage/config guide (registered at the top of apply) — cordis
 * throws on property access for services missing from this list (not
 * undefined), so every `ctx.<service>` access anywhere in this plugin must be
 * declared here.
 */
export const inject = ['agents', 'commands', 'skills', 'userQuestions', 'systemPrompt']

// --- Bundled skill -----------------------------------------------------------

/** Provider name under `ctx.skills`; doubles as the skill name. */
const SKILL_PROVIDER_NAME = 'dsh-tui-pi-config'

/** Packaged skill body; `../skills/` resolves to the package root from both lib/ and src/. */
const SKILL_BODY_URL = new URL('../skills/dsh-tui-pi-config/SKILL.md', import.meta.url)

/** Resource base served with the skill so its relative links resolve. */
const SKILL_RESOURCE_BASE = {
  kind: 'directory',
  path: fileURLToPath(new URL('../skills/dsh-tui-pi-config/', import.meta.url)),
} as const

const SKILL_INVOCATION = { modelInvocable: true, userInvocable: true } as const

/** Routing description; must stay identical to the SKILL.md frontmatter (asserted in tests). */
const SKILL_DESCRIPTION = 'dsh TUI 增强套件使用与配置指南。凡涉及 TUI 主题/面板/footer、界面语言、子代理并发与轮数限制、模型收藏与隐藏、会话保留与 /resume 过滤、ask_user 超时、preset 记忆，或要配置 dsh-tui 段时先读本指南：插件配置 entry `dsh-tui` 的 17 键（language/theme/panelHeight/maxAgents/maxRounds/maxRoundsGrace/disableSubagent/registeredOnly/footerHints/cacheHitMode/iconSet/rememberPreset/favoriteModels/hiddenModels/retention/resume/askUser）、DSH_TUI_* 环境变量、快速上手向导、keybindings.json 与 /hotkeys。触发词：tui、主题、theme、面板、footer、语言、language、收藏模型、隐藏模型、保留策略、panelHeight、resume、preset。'

const SKILL_CANDIDATE: SkillCandidate = {
  name: SKILL_PROVIDER_NAME,
  description: SKILL_DESCRIPTION,
  invocation: SKILL_INVOCATION,
  provider: SKILL_PROVIDER_NAME,
  source: 'bundled',
  resourceBase: SKILL_RESOURCE_BASE,
  rank: BUNDLED_SKILL_RANK,
  locator: SKILL_BODY_URL,
}

const skillProvider: SkillProvider = {
  name: SKILL_PROVIDER_NAME,
  list: () => Promise.resolve([SKILL_CANDIDATE]),
  async get(_candidate): Promise<SkillDefinition> {
    return {
      name: SKILL_CANDIDATE.name,
      description: SKILL_CANDIDATE.description,
      invocation: SKILL_CANDIDATE.invocation,
      provider: SKILL_CANDIDATE.provider,
      source: SKILL_CANDIDATE.source,
      resourceBase: SKILL_RESOURCE_BASE,
      content: stripFrontmatter(await readFile(SKILL_BODY_URL, 'utf8')),
    }
  },
}

/**
 * Strip a leading YAML frontmatter block (`---` / body / `---`) from a skill
 * markdown file. `SkillDefinition.content` must be the instruction body after
 * metadata removal — the same shape the filesystem provider serves — so the
 * bundled SKILL.md, which keeps its frontmatter for the GitHub/manual install
 * paths, has the block removed when served through {@link skillProvider.get}.
 * Tolerant by design: input that does not open with a `---` line, or whose
 * frontmatter block is never closed, is returned unchanged. Mirrors the
 * delimiter semantics of the upstream skill-filesystem provider.
 */
export function stripFrontmatter(raw: string): string {
  const firstLineEnd = raw.indexOf('\n')
  if (firstLineEnd < 0 || raw.slice(0, firstLineEnd).replace(/\r$/, '') !== '---') return raw
  let lineStart = firstLineEnd + 1
  while (lineStart <= raw.length) {
    const nextNewline = raw.indexOf('\n', lineStart)
    const lineEnd = nextNewline < 0 ? raw.length : nextNewline
    if (raw.slice(lineStart, lineEnd).replace(/\r$/, '') === '---') {
      return raw.slice(nextNewline < 0 ? raw.length : nextNewline + 1).trim()
    }
    if (nextNewline < 0) return raw
    lineStart = nextNewline + 1
  }
  return raw
}

export function apply(ctx: Context, config: TuiSettings): void {
  // Bind the loader-resolved entry config: every field is a live Volatile
  // reference the loader swaps in place on a volatile-only commit, so every
  // theme-settings reader (readThemePreference, readSubagentLimits, …) sees
  // the latest committed values through `.get()` from here on. A test driving
  // `apply(ctx)` without a loader passes nothing — the readers then degrade
  // to the schema defaults.
  bindTuiConfig(config)
  // Host floor guard, before any side effect: a host older than the peer
  // floor would only crash deeper in boot with raw TypeErrors (the
  // alpha-era and rc/stable-era host APIs diverged), so warn in plain
  // language and exit cleanly instead. Exit code 1 (the boot did not
  // happen) but no stack trace. The env opt-out exists for unit tests that
  // drive apply() with a fake ctx; an unresolvable closure fails open
  // inside checkHostSupport.
  if (process.env.DSH_TUI_SKIP_HOST_CHECK !== '1') {
    const check = checkHostSupport()
    if (!check.ok) {
      console.warn(check.message)
      hardExit(1)
    }
    if (check.version === undefined) {
      console.warn('[dsh-tui-pi] could not resolve the dsh host version next to the plugin; skipping the host floor check.')
    }
  }
  // `inject = ['skills']` guarantees the service exists on every real host;
  // register unconditionally so a missing service fails loud instead of
  // silently dropping the bundled usage/config guide.
  ctx.skills.registerProvider(() => skillProvider)
  let handle: TuiHandle | undefined
  // Theme registry: bundled themes/ plus $DSH_HOME/themes (user overrides
  // bundled by name). Built ONCE per apply() and handed to every resolveTheme
  // / pickTheme call site (startup, the settings hot-reload sink, the /theme
  // handler), so a custom theme named by DSH_TUI_THEME or by the persisted
  // preference resolves through the same snapshot. `themeUserNames` marks
  // which registry ids are user-owned (for the picker's "user theme" /
  // "built-in" labels).
  const themeRegistry = discoverThemes({ home: dshHome() })
  const themeUserNames = new Set(scanThemeDir(userThemesDir(dshHome())).keys())
  // Live-session handle for the startup janitor (assigned inside the
  // render effect below, where the bridge is constructed): retention
  // polls the CURRENT session id at selection time and again right
  // before every directory removal, so it must read through a ref that
  // the effect fills in — the same mutable-binding pattern as the
  // applyThemeRef sinks below.
  let bridgeRef: DshSessionBridge | undefined
  // APPEND_SYSTEM.md (pi's convention; dsh side ~/.dsh/APPEND_SYSTEM.md): a
  // user-editable file appended to the system prompt of the MAIN agent this
  // TUI creates - and to no subagent (an orchestrator identity riding on the
  // children defeats its own purpose). The section is registered on the
  // agent's scoped context inside DshSessionBridge's create/resume setup
  // (see installAppendSystem in session.ts); the text provider reads the
  // file at each assembly, so edits apply to the next request without a
  // restart or watcher, and empty content contributes nothing.
  //
  // The TUI's own todo-lifecycle guidance rides the same file (idempotent
  // marker); a fresh file is seeded with the orchestrator template. The
  // legacy AGENTS.md delivery is migrated out. All best-effort.
  void ensureAppendSystemFile()
  void migrateAgentsMdTodoSection()
  /**
   * Live theme hot-reload sink, wired to the settings/document-updated
   * subscription: a committed
   * `dsh-tui` theme change (this TUI's /theme write included) is applied to
   * the running TUI. Set inside runTui once the renderer exists; the first
   * commit can only follow a user write, long after startup.
   */
  let applyThemeRef: ((pref: ThemePreference) => void) | undefined
  /**
   * Live panel-height hot-reload sink, wired to the same subscription: a
   * committed `dsh-tui` panelHeight change re-budgets the fixed think/tool
   * panels above the chat input. Armed inside runTui once the widgets exist.
   */
  let applyPanelHeightRef: ((height: PanelHeight) => void) | undefined
  /**
   * Live footer-hints hot-reload sink, wired to the same subscription: a
   * committed `dsh-tui` footerHints change repaints the footer hint bar with
   * the new segment selection. Armed inside runTui once the TUI exists.
   */
  let applyFooterHintsRef: ((hints: FooterHints) => void) | undefined
  /**
   * Live icon-set hot-reload sink, wired to the same subscription: a committed
   * `dsh-tui` iconSet change re-resolves the risky glyphs (an 'auto' change
   * resolves against the startup font-detection snapshot) and repaints the
   * footer/notices/panels that carry them. Armed inside runTui once the TUI
   * exists.
   */
  let applyIconSetRef: ((set: IconSet) => void) | undefined

  ctx.effect(async () => {
    // The theme bundle is built once at TUI startup and held by every
    // component, so the persisted preference must land before startTui — the
    // startup readers resolve the bound entry config synchronously (volatile
    // references, already seeded by the loader before apply ran; a
    // config-less deployment degrades to the schema defaults). The
    // subscription below keeps later commits (the /theme picker, the
    // /settings browser, an external patch edit) hot-applying through
    // applyThemeRef / applyPanelHeightRef / applyFooterHintsRef.
    // Panel height FIRST, theme second: a single commit of both fields (a
    // config reset, an external edit) must not replay at the wrong
    // height. setPanelHeight re-budgets the fixed think/tool panels; the
    // setTheme replay that follows already renders at that new height.
    // applyTheme carries the theme-bundle identity guard, so a height-only
    // commit never triggers a second rebuild.
    subscribeThemeSettings(ctx, (pref, height, footerHints, iconSet, language) => {
      setLocale(language)
      applyPanelHeightRef?.(height)
      applyThemeRef?.(pref)
      applyFooterHintsRef?.(footerHints)
      applyIconSetRef?.(iconSet)
    })
    // Session log retention (deferred, abortable, fire-and-forget): prune
    // jsonl session directories outside the retention window so the store
    // the core only appends to never grows unbounded. The pass starts 3s
    // after apply returns, so its fs walk — and the result notice that once
    // read as "boot hangs until the cleanup line prints" — stays entirely
    // off the first-frame window. unref'd so the timer never holds a dying
    // process; the teardown disposer aborts the signal so /quit never waits
    // behind an in-flight `rm`. Knobs still resolve through the precedence
    // chain (settings explicit > env > default). Silent and non-fatal; the
    // pass reports through the shared notice bridge only when it actually
    // removed something; process-global one-shot so a /reload re-running
    // apply does not start a second pass (src/retention.ts).
    const retentionAbort = new AbortController()
    const retentionTimer = setTimeout(() => {
      void runSessionRetentionOnce({
        signal: retentionAbort.signal,
        getSessionId: () => {
          const id = bridgeRef?.getSessionId()
          return id === undefined ? undefined : String(id)
        },
        // An in-flight /resume target is as load-bearing as the current
        // session: the load reads the target's log directory for its whole
        // duration, and deleting it mid-flight would destroy the log being
        // replayed (review Major 2 — the exclusion set is current ∪ pending).
        getResumingSessionId: () => {
          const id = bridgeRef?.getResumingSessionId()
          return id === undefined ? undefined : String(id)
        },
        // Explicit dsh-tui.retention overrides from the profile patch (the
        // descriptor's user layer — a settings-less deployment degrades to
        // env/defaults).
        readSettings: async () => (await readSessionManagementExplicit(ctx))?.retention,
      }).catch(() => undefined)
    }, 3000)
    retentionTimer.unref?.()
    const themePreference = await readThemePreference(ctx)
    const panelHeight = await readPanelHeightPreference(ctx)
    const footerHints = await readFooterHintsPreference(ctx)
    // UI language (`dsh-tui.language`, default 'en'): discover the language
    // files and activate the persisted id BEFORE the TUI's first frame, so
    // the boot UI speaks it from the start. The settings/document-updated
    // subscription re-applies later commits live via setLocale. An unknown id
    // degrades to 'en' inside initI18n.
    initI18n({ id: await readLanguagePreference(ctx), warn: message => emitNotice(message) })
    // Icon-set self-adaptation: probe the platform once at startup (the
    // memoised snapshot shared with every later 'auto' resolution), resolve
    // the persisted mode against it and push the result into src/icons.ts
    // BEFORE the TUI's first frame — so the footer renders the right
    // separator from frame one, never a late plain→powerline flicker.
    const iconSetPreference = await readIconSetPreference(ctx)
    const nerdfontAvailable = await detectNerdFontAvailable()
    applyIconSet(resolveIconSet(iconSetPreference, nerdfontAvailable))
    const presetRoster = await fetchPresetRoster(ctx)
    // Preset memory (`dsh-tui.rememberPreset`, default ON): the last /preset
    // selection committed in THIS workspace (keyed by the session backend's
    // project key of the cwd) becomes the launch selection — runTui seeds it
    // into both the footer state AND `bridge.setAgentPreset`, so the FIRST
    // session of the day composes under the remembered preset instead of the
    // server default. A stale id (preset renamed/removed upstream) degrades
    // to the stock default-selection behavior; memory off skips the read
    // entirely.
    const rememberedPresetId = (await readRememberPreset(ctx))
      ? rememberedPresetFor(loadWorkspacePresets(workspacePresetsPath()), projectKeyFor(process.cwd()))
      : undefined
    // Startup configuration snapshot (mcp/skills/plugins readout under the
    // welcome banner): best-effort by contract — no loader service or a
    // throwing entry walk degrades to undefined and the banner renders
    // alone. Sync and bounded (one readdir per skills dir, one entry walk).
    const startupInfo = collectStartupSummary(ctx)
    // The launcher's inner arguments (`dsh --profile tui --resume <id>`):
    // provided by the launcher before the tree mounts, so the boot-intent
    // resume is readable here. Absent on embedding hosts without a command
    // line — undefined then, and the TUI starts fresh as before.
    const cmdlineArgs = (ctx.get('cmdlineArgs') as { get(): readonly string[] } | undefined)?.get()
    let disposer: (() => void) | undefined
    try {
      disposer = runTui(themePreference, panelHeight, footerHints, nerdfontAvailable, presetRoster, startupInfo, cmdlineArgs, rememberedPresetId)
    } catch (error) {
      // An async-effect failure after startTui would otherwise orphan the
      // terminal in raw mode — the disposer never registers, so nothing ever
      // restores the TTY. Clean up and rethrow so cordis logs the error
      // instead of silently leaking the TUI.
      handle?.dispose()
      handle = undefined
      throw error
    }
    // Cordis teardown also stops the deferred retention pass: a /quit must
    // never wait behind an in-flight prune (the janitor's own abort checks
    // land it at the next loop boundary; an un-fired timer is just cleared).
    return () => {
      clearTimeout(retentionTimer)
      retentionAbort.abort()
      disposer?.()
    }
  }, 'dsh-tui-pi.render')

  /**
   * Build the TUI and its slash commands for the resolved theme preference,
   * panel height and footer-hint selection. Declared as a hoisted function so
   * the effect body stays a thin wrapper: the whole build runs inside the
   * try/catch above, so any failure disposes the TUI handle before the error
   * reaches cordis. Returns the effect disposer handed back to cordis on
   * teardown.
   */
  function runTui(themePreference: ThemePreference, panelHeight: PanelHeight, footerHints: FooterHints, nerdfontAvailable: boolean, presetRoster: import('./preset.ts').PresetEntry[], startupInfo: StartupSummary | undefined, cmdlineArgs: readonly string[] | undefined, rememberedPresetId: string | undefined): () => void {
    // User keybindings (`~/.dsh/keybindings.json`): a partial map of the app
    // keys, read once per TUI start — `/reload` re-runs apply() and re-reads
    // it. Broken entries surface as notices instead of breaking startup.
    const keyFile = keybindingsPath(dshHome())
    const keyBindings = loadKeyBindings(keyFile)
    // Preset state: /preset owns the selection (Tab is deliberately unbound —
    // switching is an explicit, confirmed action). The roster is fetched once
    // at startup from the host's `agentPresets` registry (dsh 0.1.7
    // declarative presets); an empty roster (no service / no presets)
    // disables the feature gracefully (/preset errors, footer shows
    // plain "dsh"). The initial selection is the workspace's REMEMBERED
    // preset when preset memory is on and the id is still on the roster
    // (initialPresetIndex prefers it), else the roster's own default row,
    // else `standard`, else the first-listed one. Without memory the launch
    // selection is a local display only: before the user switches via
    // /preset, NO `meta.agentPreset` is sent at session create, so the
    // registry's deployment default (`default`/`selectedDefault` config of
    // the agent-preset-registry entry) governs. WITH memory the remembered
    // id is ALSO seeded into the bridge below (bridge.setAgentPreset), which
    // is the point: the first session of the launch composes under the
    // remembered preset, not the server default. We deliberately seed ONLY a
    // remembered id, never DEFAULT_PRESET_ID — that would override the
    // server-side default with a client-side assumption.
    const rememberedPresetEntry = rememberedPresetId !== undefined
      ? presetRoster.find(preset => preset.id === rememberedPresetId)
      : undefined
    const presetState: PresetState = { roster: presetRoster, index: initialPresetIndex(presetRoster, rememberedPresetEntry?.id) }
    // Docked-modal liveness (the ask-user questions panel): while a question
    // is pending the panel owns the keyboard — the keymap treats it like an
    // open overlay (see tui.ts), and refocusEditor must not steal focus from
    // it. Flipped by the panel through its setModalActive dep.
    let askUserActive = false
    const ui = startTui({
      onSubmit: text => {
        void submit(text)
      },
      keyBindings: keyBindings.bindings,
      // App-level keys (pi interrupt chain): Esc while LLM work runs is a
      // deliberate double-press — the first press arms the window (with
      // feedback), the second within 500ms opens the stop-everything
      // CONFIRMATION dialog (main turn + every running subagent); stopping
      // everything is a read-before-confirm action, not a timer race.
      // popup/autocomplete first, and an idle Esc (any editor) is an
      // anti-misfire no-op. "Running" covers background subagents too —
      // children keep working after the parent turn ends, and the stop must
      // still reach them (bridge.hasRunningWork).
      // Ctrl+C cancels a running task or clears the editor — a second press
      // within 500ms quits — and Ctrl+D quits only on an empty editor.
      // Ctrl+G opens the subagent picker while children run. All decisions
      // live in keymap.ts.
      isRunning: () => bridge.hasRunningWork(),
      getRunningAgents: () => bridge.getLiveChildren().length,
      hasSession: () => bridge.getSessionId() !== undefined,
      dockedModalActive: () => askUserActive,
      onKeyAction: (action: KeyAction) => {
        switch (action.kind) {
          case 'interrupt-arm-stop':
            // First Esc while LLM work runs: the stop is ARMED, not fired —
            // a second Esc within the window opens the confirmation dialog,
            // so a stray Esc can never kill a running task. The notice keeps
            // the armed first press from feeling dead and states the
            // contract explicitly.
            renderer.renderNotice(t('tui.esc.armStop'), 'info')
            break
          case 'interrupt-cancel': {
            // Second Esc while LLM work runs (main turn and/or subagents):
            // open the stop-everything CONFIRMATION dialog. The old flow
            // auto-fired the stop after a 200ms window — that confirmed the
            // press timing, never the intent, and the gesture's reach had
            // grown to every running subagent. The dialog states the blast
            // radius (what is running right now) and waits for Enter; Esc
            // inside it cancels and keeps everything running. While the
            // overlay is up the keymap yields it every app key, so further
            // Esc presses land in the dialog, never straight at the task.
            void confirmAndStop()
            break
          }
          case 'ctrl-c-cancel': {
            // First Ctrl+C mid-turn: cancel straight away with the same
            // on-screen feedback as Esc ×2 (mirrors the web client's stop
            // button; keepInbox preserves the queue).
            void stopTask()
            break
          }
          case 'ctrl-c-clear':
            // First Ctrl+C while idle: clear the editor (pi app.clear); a
            // second press within 500ms quits.
            ui.editor.setText('')
            ui.requestRender()
            break
          case 'ctrl-c-quit': {
            // Double Ctrl+C quits — but a held key must not. The terminal
            // re-sends a held Ctrl+C every ~30-50ms after the OS repeat delay,
            // and the FIRST repeat can land inside the 500ms double-press
            // window looking exactly like a deliberate second press. So the
            // quit is confirmed, not immediate: it fires after
            // QUIT_CONFIRM_MS unless a `key-repeat` arrives (a repeat betrays
            // a held key → abort), while another HUMAN-speed press during the
            // window (a deliberate mash) quits right away.
            if (quitConfirmTimer !== undefined) {
              clearTimeout(quitConfirmTimer)
              quitConfirmTimer = undefined
              void disposeAndExit(0)
              break
            }
            renderer.renderNotice(t('tui.esc.quitArmed', { icon: stopIcon() }), 'info')
            quitConfirmTimer = setTimeout(() => {
              quitConfirmTimer = undefined
              void disposeAndExit(0)
            }, QUIT_CONFIRM_MS)
            break
          }
          case 'key-repeat':
            // Auto-repeat of a held key — betrays a hold, never a double:
            // abort a pending Ctrl+C quit confirmation. (The double-Esc stop
            // has no timer anymore — its confirmation is the dialog, which
            // ignores held keys through the keymap's repeat filter.)
            if (action.key === 'ctrl-c' && quitConfirmTimer !== undefined) {
              clearTimeout(quitConfirmTimer)
              quitConfirmTimer = undefined
              renderer.renderNotice(t('tui.esc.quitAborted'), 'info')
            }
            break
          case 'ctrl-d-quit':
            void disposeAndExit(0)
            break
          case 'model-picker':
            // Ctrl+L: pi app.model.select — open the model/think picker.
            void modelHandler('', new AbortController().signal)
            break
          case 'subagent-viewer':
            // Ctrl+G: open the subagent picker → transcript viewer while
            // children run (modal overlay; Esc closes, x ×2 stops the child
            // while it runs / closes when settled).
            void openSubagentViewer(ctx, ui.tui, ui.theme, bridge, refocusEditor)
            break
          case 'session-search': {
            // Ctrl+Alt+F (the legacy ESC+^F encoding most terminals send —
            // ctrl+shift+f stays pi-tui's built-in transcript search):
            // dispatch through the /search command's handler so both entry
            // points share one path (result replies included).
            void searchHandler('', new AbortController().signal)
            break
          }
          case 'queue-panel': {
            // Ctrl+O: manage pending routed prompts — d removes one from the
            // inbox, s promotes it to an immediate steer (with the same
            // race fallback as the submit dialog). Degrade/error outcomes
            // mirror into the buffered transcript notice channel so they
            // survive theme rebuilds.
            void openPendingQueuePanel(ui.tui, ui.theme, {
              readItems: () => bridge.getPendingPrompts(),
              onRemove: item => {
                const agent = bridge.getAgent()
                if (agent === undefined) return { kind: 'error' as const, error: t('tui.session.none') }
                const result = removeFromInbox(agent.inbox, item)
                // Review B1: a successful revoke must retire the transcript
                // badge — the echo bubble becomes an explicit canceled line
                // instead of a permanent ⏳/↪ ghost.
                if (result.kind === 'removed') {
                  renderer.resolvePendingEcho({ id: item.message.id, text: item.text }, 'canceled')
                }
                return result
              },
              onPromote: item => {
                const agent = bridge.getAgent()
                if (agent === undefined) return { kind: 'error' as const, error: t('tui.session.none') }
                const result = promotePending(agent, item)
                if (result.kind === 'promoted' && result.degraded) {
                  // Review S3: the steer degraded back into the queue — flip
                  // the badge to ⏳ queued so it tells the truth.
                  renderer.rebadgePendingEcho({ id: item.message.id, text: item.text }, 'queued')
                } else if (result.kind === 'error') {
                  // Review B1/S2: promote failed for good (the recovery
                  // re-queue threw too) — the badge becomes an explicit
                  // not-delivered line instead of a ghost.
                  renderer.resolvePendingEcho({ id: item.message.id, text: item.text }, 'failed')
                }
                return result
              },
              onOutcome: (result: QueueActionResult) => {
                if (result.kind === 'promoted' && result.degraded) {
                  renderer.renderNotice(steerUnavailableNotice(), 'info')
                } else if (result.kind === 'error') {
                  renderer.renderNotice(result.error, 'error')
                }
              },
              // v0.20.1: a persistent refresh failure (threshold reached)
              // surfaces once as a buffered warning — never silently stale.
              onRefreshError: message => renderer.renderNotice(message, 'warning'),
              restoreFocus: refocusEditor,
              shouldStayOpen: () => bridge.getSessionId() !== undefined,
            })
            break
          }
          case 'workflow-overlay': {
            // Ctrl+K: the workflow overlay — rendering comes from the
            // dsh-workflow package through the generic widget manifest; the
            // freshest run under the workspace anchors the view.
            const manifest = readWorkflowOverlayManifest()
            const runDir = manifest !== undefined ? latestWorkflowRunDir(process.cwd()) : undefined
            if (manifest === undefined || runDir === undefined) {
              renderer.renderNotice(t('tui.workflowOverlay.none'), 'info')
              break
            }
            const locale = currentLocale().id.startsWith('zh') ? 'zh' : 'en'
            void openWorkflowOverlayPanel(ui.tui, ui.theme, {
              manifest,
              runDir,
              locale,
              restoreFocus: () => ui.requestRender(),
            }).then(opened => {
              if (!opened) renderer.renderNotice(t('tui.workflowOverlay.none'), 'info')
            })
            break
          }
          default:
            break
        }
      },
      themePreference,
      themeRegistry,
    })
    handle = ui
    /**
     * Focus restoration with the PanelHost preemption guard (review S6):
     * every flow overlay closes through this. When ANOTHER capturing surface
     * is still up — an overlay, or the docked ask-user panel preempting the
     * route dialog / queue panel mid-flow — that surface owns the keyboard:
     * yanking focus to the editor would orphan it (visible but
     * keyboard-dead). All of this plugin's overlays capture focus, so
     * `hasOverlay()` is the exact "an overlay holds the keyboard" test, and
     * `askUserActive` covers the docked questions panel; the ordinary close
     * path lands here only after the last surface went away, and still
     * re-focuses the CURRENT editor instance (rebuilt on theme swap).
     */
    const refocusEditor = (): void => {
      if (ui.tui.hasOverlay() || askUserActive) return
      ui.tui.setFocus(ui.editor)
    }
    // Live theme preference, tracked so terminal-following (below) can tell
    // 'auto' (follow the terminal) from an explicit light/dark pin.
    let themePreferenceRef: ThemePreference = themePreference
    /**
     * Pending Ctrl+C quit confirmation (see the `ctrl-c-quit` case): armed by
     * a double press, fired after QUIT_CONFIRM_MS, aborted by a `key-repeat`
     * (held key) or torn down with the TUI.
     */
    let quitConfirmTimer: ReturnType<typeof setTimeout> | undefined
    /**
     * The double-Esc stop flow: the confirmation dialog first (it states
     * what is running and waits for Enter), then the everything-stop. The
     * dialog is modal, so a mashing user cannot double-commit — every key
     * while it is up goes to the dialog, and a cancel simply returns.
     */
    const confirmAndStop = async (): Promise<void> => {
      const outcome = await openStopConfirmDialog(
        ui.tui,
        ui.theme,
        bridge.isRunning(),
        bridge.getLiveChildren().length,
        refocusEditor,
      )
      if (outcome === 'stop') await stopTask()
    }
    /**
     * Stop the whole task — the everything-stop: the main turn (mirroring
     * the web client's stop button, `agent.cancel({ kind: 'user' }, {
     * keepInbox: true })` via the bridge), btw side calls, AND every live
     * subagent. The children leg is what makes this "everything": cancelling
     * the parent only kills foreground children (they ride the tool call's
     * abort signal) — background/continuable children survive it and would
     * keep burning LLM rounds (bridge.cancelAllChildren). Fired by the
     * dialog's Stop choice (double-Esc) and the first Ctrl+C mid-task.
     */
    const stopTask = async (): Promise<void> => {
      renderer.renderNotice(t('tui.stop.stopping', { icon: stopIcon() }), 'info')
      // The stop gesture is the everything-stop: side calls die with the turn.
      btwController.cancelAll()
      const cancelled = await bridge.cancelActiveTurn()
      const stoppedChildren = bridge.cancelAllChildren()
      // State raced idle between the decision and the cancel calls — nothing
      // to cancel (e.g. the task settled while the dialog was up).
      if (!cancelled && stoppedChildren === 0) renderer.renderNotice(t('tui.stop.nothingRunning'), 'info')
    }
    // Arm the settings hot-reload sink now that the renderer exists (see apply()).
    applyThemeRef = (pref: ThemePreference): void => {
      themePreferenceRef = pref
      // 'auto' subscribes to the terminal's live color-scheme pushes; an
      // explicit pin opts out. resolveTheme guards env-pinned displays.
      ui.tui.setTerminalColorSchemeNotifications(pref === 'auto')
      applyTheme(resolveTheme(process.env, pref, themeRegistry))
    }

    const renderer = new TranscriptRenderer(ui.transcript, ui.theme, () => ui.requestRender(), startupInfo)
    // Startup notices for a broken/misleading keybindings file — the TUI keeps
    // running with defaults; the panel shows the same warnings via /hotkeys.
    for (const warning of keyBindings.warnings) {
      renderer.renderNotice(t('tui.keys.warningPrefix', { warning }), 'error')
    }
    // Arm the shared notice sink now that the TUI is up. Every operator
    // trace that fired before this point — invalid dsh-tui.retention/resume values, a
    // missing userQuestions service, the janitor's result line — has been
    // queueing on the bridge (src/notice-bridge.ts); registering here
    // drains that batch as stacked transient notices above the footer
    // instead of raw stderr lines (which would scribble over the
    // alt-screen frame). Later emissions deliver directly. If the TUI
    // never gets here (headless), everything stays pending and is
    // silently dropped.
    setNoticeSink(message => ui.showNotice(message))
    // Live widgets, pinned around the chat window: the Todos panel plus the
    // fixed think/tool status panels ABOVE the input (one of each, refreshed
    // in place, hidden while empty), and the running-agent activity merged
    // into the last-request area BELOW the editor. Owned here — fed by
    // session events and the bridge's subagent fold, ticked by the live
    // timer, recolored by applyTheme.
    const liveWidgets = new LiveWidgets(
      ui.widgets, ui.lastRequest, ui.theme, () => ui.requestRender(), panelHeight,
      // Live maxRounds for the compact running-agent lines' `round N/M` — read
      // at every rebuild (the /agents limits panel hot-applies).
      () => readSubagentLimits(ctx).maxRounds,
    )
    // Sibling-plugin widget files ($DSH_HOME/tui-widgets/*.lines — the
    // generic file seam; the writer owns content, this is a dumb renderer).
    const externalWidgetFile = new ExternalWidgetFile(() => ui.theme)
    ui.widgets.addChild(externalWidgetFile)
    // Arm the panel-height hot-reload sink now that the widgets exist: a committed
    // panelHeight change re-budgets the think/tool panels — they are
    // self-drawing, so the next frame already renders at the new height.
    applyPanelHeightRef = (height: PanelHeight): void => {
      liveWidgets.setPanelHeight(height)
    }

    // Terminal resize: pi-tui re-renders every component at the new columns,
    // but bordered panel rows were padded to the OLD box width — a narrowing
    // terminal wraps every row and shatters the fixed-height panels. Relayout
    // the transcript (replay-buffer rebuild) on the next frame: pi-tui's own
    // resize render is nextTick + 16ms throttled, so the rebuilt panels win
    // the race and the first new-width frame is already intact. The trailing
    // 0ms timer coalesces resize-event storms from terminal drags. The
    // listener is per-runTui and removed in the effect disposer below, so a
    // /reload never leaks one.
    let relayoutTimer: NodeJS.Timeout | undefined
    const onResize = (): void => {
      if (relayoutTimer !== undefined) clearTimeout(relayoutTimer)
      relayoutTimer = setTimeout(() => {
        relayoutTimer = undefined
        renderer.relayout()
      }, 0)
    }
    process.stdout.on('resize', onResize)

    // Working/idle indicator in the fixed dock (hidden while idle).
    let loader: Loader | undefined
    let agentStatus: 'idle' | 'running' = 'idle'
    const setStatus = (status: 'idle' | 'running'): void => {
      agentStatus = status
      if (status === 'running') {
        if (loader === undefined) {
          loader = new Loader(
            ui.tui,
            text => BOLD + ansiFg(ui.theme.palette.accent) + text + RESET,
            text => BOLD + ansiFg(ui.theme.palette.accent) + text + RESET,
            t('tui.status.working'),
          )
          ui.status.addChild(loader)
          loader.start()
        }
      } else if (loader !== undefined) {
        loader.stop()
        ui.status.removeChild(loader)
        loader = undefined
        ui.requestRender()
      }
    }

    // Permission knob events (preset switch, sandbox mode, approval policy)
    // paint nothing in the transcript — they only change the editor's
    // permission badge — so the renderer's default no-op must be compensated
    // with a repaint request here. The badge reads the cached current preset
    // (see the provider below), so a knob change must refresh the cache too.
    const PERMISSION_KNOB_EVENTS = new Set(['permission/preset', 'sandbox/mode', 'approval/policy'])
    const bridgeCallbacks: BridgeCallbacks = {
      onEvent: (event: SessionEvent) => {
        renderer.applyEvent(event)
        // Think/tool activity, todos and the panel phase machine: the fixed
        // live surfaces above the chat input, never transcript blocks.
        liveWidgets.applyEvent(event)
        if (event.type === 'todo/write') {
          liveWidgets.renderTodos(event.data.todos)
        }
        if (event.type === 'turn/end') {
          // Review B1, widened in v0.20.1 to EVERY ended turn: any turn end
          // can strand routed badges whose messages never got claimed AND no
          // longer exist in the inbox — aborted/failed turns are the obvious
          // case, but a `blocked` turn (pre-step rejecter) already removed
          // the claimed batch from the inbox without ever producing a
          // user/message, and an empty enter ends as `completed` while its
          // echo badge stays behind. Both used to leave permanent ⏳/↪
          // ghosts. Safe to run unconditionally: the alive-check below
          // resolves only echoes whose message id is gone from BOTH inbox
          // boundaries (getPendingPrompts = next-step ∪ next-turn), so
          // entries still queued for a later turn stay pending.
          const alive = new Set(bridge.getPendingPrompts().map(prompt => String(prompt.message.id)))
          renderer.prunePendingEchoes(messageId => alive.has(String(messageId)))
        }
        if (PERMISSION_KNOB_EVENTS.has(event.type)) {
          refreshPermissionPreset()
          ui.requestRender()
        }
      },
      onStreamDelta: (turn: number, step: number, chunk: { type: string; text?: string }) => {
        // The streaming typewriter in the transcript and the think/tool phase
        // machine both live on the deltas — dsh 0.1.5-rc.1 delivers them as
        // `agent/assistant-stream` frames, no longer as firehose events.
        renderer.applyStreamChunk(turn, step, chunk)
        liveWidgets.applyStreamDelta(chunk)
      },
      onStatus: setStatus,
      onLive: (agents: readonly AgentView[]) => {
        liveWidgets.renderAgents(agents)
      },
    }
    const bridgeCallbacksWithTakeover: BridgeCallbacks = {
      ...bridgeCallbacks,
      onRemotePromotable: async (idRaw: string) => {
        // Queued follow-ups won the takeover race at an ownership boundary:
        // take over EXACTLY like a manual /resume, then flush the queue.
        btwController.cancelAll()
        const resumed = await bridge.resume(SessionId(idRaw))
        refreshPermissionPreset()
        renderer.clear()
        liveWidgets.clear()
        const session = resumed.agent.session
        const adopted = 'adopted' in resumed && resumed.adopted === true
        // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
        // projection registration / sessionPersistence.handle.read() pagination. Kept
        // here deliberately — this path re-consumes RAW events (renderer/stats
        // replay), which the projection successor does not serve. (T14 review.)
        bridge.replay(adopted ? session.snapshotEvents() : session.snapshotEvents().filter(event => event.seq < session.firstLiveSeq))
        for (const text of bridge.takePendingRemoteFollowups()) {
          await bridge.prompt(text)
        }
        emitNotice(t('tui.takeover.writeLock'))
        ui.requestRender()
      },
    }
    const bridge = new DshSessionBridge(ctx, bridgeCallbacksWithTakeover)
    bridgeRef = bridge
    // Preset memory's creation-time leg: seed the remembered selection so the
    // FIRST session creation (the lazy create on the first submitted prompt)
    // records `meta.agentPreset` — without this the launch selection would be
    // footer cosmetics while the server default composed the session. Only a
    // roster-validated id is ever seeded (see presetState above).
    if (rememberedPresetEntry !== undefined) bridge.setAgentPreset(rememberedPresetEntry.id)
    // Subagent fine-grained control, all in-process (see subagent-policy.ts):
    // a tools.guard denies spawn-tool calls once `maxAgents` children run
    // (workflow fan-out, which bypasses the tool pipeline, is pruned on
    // `subagent/start`), and the round ladder injects one wrap-up at a
    // child's cap and hard-stops it after the grace window — the per-agent
    // tier reads the agent file's frontmatter `maxRounds` through the
    // registry contract. Limits are read live from the `dsh-tui` settings
    // entry config (/agents → l limits).
    const subagentPolicy = applySubagentPolicy(ctx, {
      getLive: () => bridge.getLiveChildren(),
      getRoundCount: childId => bridge.getRoundCount(childId),
      isSettled: childId => bridge.isChildSettled(childId),
      cancelChild: childId => bridge.cancelChild(childId),
      getAttentionHint: () => bridge.getAttentionHint(),
      getSpinState: childId => bridge.getSpinState(childId),
    }, readAgentMaxRounds)
    // Wire the policy into the callback object the bridge ACTUALLY holds:
    // `bridgeCallbacksWithTakeover` is a spread copy taken before this point,
    // so assigning on `bridgeCallbacks` would write to an object the bridge
    // never reads — the round ladder would silently never run (this exact
    // disconnect was the real "maxRounds is ignored" bug).
    bridgeCallbacksWithTakeover.onRoundCount = (childId, count) => subagentPolicy.onRoundCount(childId, count)
    // The `⏻` marker fold: a force-stopped child is policy enforcement, and
    // every render surface shows it as such. Assigned unconditionally — a
    // definedness check here would skip the wiring forever (the sink starts
    // unset by definition).
    subagentPolicy.onHardStop = ({ childId, round, cap, early }) => bridge.markChildHardStopped(childId, round, cap, early)

    // subagent_status: the model-facing live board — served from the same
    // bridge views and policy counters the TUI renders, so the model never
    // has to probe spawn tools or re-derive state to plan its fan-outs. The
    // maxAgents denial message points here.
    ctx.effect(() => installSubagentStatusTool(ctx, {
      views: () => bridge.getAgentViews(),
      stats: () => subagentPolicy.getStats(),
      attention: () => {
        const rows = bridge.getAttentionRows()
        return rows.length > 0 ? rows : undefined
      },
    }) ?? (() => {}), 'dsh-tui-pi:subagent_status')

    // Attention ranking's jev upgrade source (Charter #6, jev-optional): the
    // bridge's reconcile tick re-observes the always-on heuristic ranking
    // every 600ms; this source adds the debounced jev pass when the
    // `jevAttention` setting is 'auto' AND a key is configured — otherwise
    // everything stays heuristic and nothing leaves the machine. The probe
    // degrades to heuristic-only when @aiwayds/dsh-jev-core is unresolvable.
    bridge.attachAttentionSource(
      createJevAttentionSource({ modeReader: () => readJevAttentionMode(ctx) }),
      () => readSubagentLimits(ctx).maxRounds,
    )

    // Ask-user-question provider: the upstream `dsh-tool-ask-user` tool calls
    // `ctx.userQuestions.ask()` while its tool call is pending, and the
    // provider returns a canonical `{ answers: [{ id, selected, custom? }] }`
    // envelope that the tool surfaces back to the model as the tool result.
    // We host a single DOCKED panel per request — pinned above the chat input
    // in the askUser dock slot (the Todos-panel look, not a floating
    // overlay), taking focus while open. Focus falls back through
    // restoreFocus (the current editor instance — it is rebuilt on theme
    // swap); the theme is passed as a live getter so a mid-panel hot-swap
    // re-renders with the new palette. Provider registration failure
    // semantics live in registerAskUserProvider: DUPLICATE_PROVIDER yields to
    // the prior UI, anything else fails loudly.
    ctx.effect(() => registerAskUserProvider(ctx, {
      tui: ui.tui,
      theme: () => ui.theme,
      // Ask-surface claim routing: the panel answers questions asked by the
      // session this bridge drives (dsh-ask-router fans out, first answer wins).
      getSessionId: () => bridge.getSessionId(),
      // Auto-answer timeouts (settings > env > defaults), re-read per ask.
      resolveTimeouts: async () => resolveAskUserTimeouts(await readAskUserExplicit(ctx)),
      restoreFocus: refocusEditor,
      mount: component => {
        ui.askUser.addChild(component)
        ui.requestRender()
        return () => {
          ui.askUser.removeChild(component)
          ui.requestRender()
        }
      },
      setModalActive: active => {
        askUserActive = active
      },
    }), 'dsh-tui-pi: ask-user-question provider')

    // System prompt guidance: nudge the model toward conservative use of
    // `ask_user_question`. The upstream `dsh-tool-ask-user` is a single
    // tool-call pause, and over-using it (e.g. for trivial decisions, for
    // rhetorical questions, or for things the model can decide itself)
    // turns the TUI into a stuttering questionnaire. The order rides the
    // host's centrally allocated PTC_ONLY position — alpha.3's
    // getSectionOrder(name) replaced the numeric constants and the old
    // 100–199 section bucket; PTC_ONLY is the tool-behavior region that sits
    // after the deployment persona and ahead of every per-tool section, so
    // the rule still reads as part of the tooling contract.
    ctx.effect(() => ctx.systemPrompt.section({
      name: 'dsh-tui:ask-user',
      order: ctx.systemPrompt.getSectionOrder('PTC_ONLY'),
      text:
        '## ask_user_question\n\n'
        + 'Use `ask_user_question` ONLY when you genuinely need the human to: confirm a decision, '
        + 'pick among concrete options, or supply missing information you cannot infer. Do NOT use it for: '
        + 'trivial choices you can make yourself; rhetorical or open-ended exploration; or multiple '
        + 'optionally-related decisions in one call (split, or skip). Prefer 1–3 questions per call, each '
        + 'with 2–4 concise options. Add a recommendation by putting it first and appending "(Recommended)". '
        + 'When you DO ask: phrasings should be unambiguous and options should be mutually exclusive. '
        + 'Never ask what you could decide from existing context.\n',
    }), 'dsh-tui-pi: ask-user system-prompt section')

    /**
     * One O(events) fold of the session log into the effective preset, stored
     * for the badge provider. Runs once per session (ensure/resume, see the
     * call sites) and once per knob change — never on the render path, which
     * is what makes the provider's read O(1). Clearing to undefined is the
     * right answer for an absent agent/preset service: the provider then
     * hides the badge.
     */
    let permissionPreset: string | undefined
    const refreshPermissionPreset = (): void => {
      const presets = ctx.get('permissionPresets')
      const agent = bridge.getAgent()
        permissionPreset = presets === undefined || agent === undefined
          ? undefined
          : presets.current(agent.session)
    }

    // Usage memory for the slash completion list: successful commands and
    // skill gestures bump per-name counters persisted under $DSH_HOME. The
    // disk copy is authoritative — a /reload swaps this plugin fiber and the
    // fresh tracker re-reads the file, so counts survive hot reloads too.
    const commandUsage = new CommandUsageTracker(commandUsagePath())
    const commands = new CommandService(ctx, bridge, commandUsage)
    // Wiring through the handle: the editor is rebuilt on theme hot-swap, and
    // these providers are re-applied to the replacement instance.
    ui.setEditorAutocompleteProvider(commands.autocompleteProvider())

    // One registration for both dispatch surfaces: CommandService.registerLocal
    // (direct dispatch when no agent exists — no throwaway session) plus
    // ctx.commands.register (discovery + lifecycle events against a live
    // agent). Agentless bodies go through both, so autocomplete matches web.
    const registerLocalCommand = (
      name: string,
      description: string,
      handler: LocalCommandHandler,
    ): void => {
      commands.registerLocal(name, handler)
      ctx.effect(() => ctx.commands.register({
        name,
        description,
        handler: invocation => handler(invocation.rawInput, invocation.signal),
      }), `dsh-tui-pi: /${name}`)
    }

    /** Error message for notices — unknown catch values stringify safely. */
    const messageOf = (e: unknown): string => e instanceof Error ? e.message : String(e)

    // ------------------------------------------------------------ /btw (TUI-owned; ADR 0001) --
    // By-the-way side questions: one tool-less one-shot model call over a
    // read-only recent-conversation snapshot, streaming into a framed
    // overlay. Nothing enters the session log, the inbox, or any main-line
    // model request. Placed here (not an independent plugin) because the
    // deliverable — overlay, focus, cancellation timing — only exists inside
    // dsh-tui-pi; see docs/adr/0001-btw-tui-owned-command.md.
    const btwWire = new BtwOverlayWire({
      tui: ui.tui,
      theme: () => ui.theme,
      restoreFocus: refocusEditor,
    })
    const btwSnapshotLimit = resolveSnapshotLimit(process.env.DSH_TUI_BTW_CONTEXT_MESSAGES)
    const btwController = new BtwController({
      stream: options => {
        const llm = ctx.get('llm')
        if (llm === undefined) throw new Error(t('tui.btw.noLlm'))
        return llm.stream({
          provider: options.provider,
          model: options.model,
          ...(options.reasoningEffort === undefined ? {} : { reasoningEffort: options.reasoningEffort }),
          messages: options.messages,
          system: options.system,
          ...(options.signal === undefined ? {} : { signal: options.signal }),
        })
      },
      resolveSelection: () => {
        const selection = bridge.getSelection()
        return selection === undefined
          ? undefined
          : { provider: selection.provider, model: selection.model, reasoningEffort: selection.reasoningEffort }
      },
      buildSnapshot: () => {
        const agent = bridge.getAgent()
        return agent === undefined
          ? []
          // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
          // projection registration / sessionPersistence.handle.read() pagination. Kept
          // here deliberately — this path re-consumes RAW events (renderer/stats
          // replay), which the projection successor does not serve. (T14 review.)
          : buildBtwSnapshot(agent.session.snapshotEvents(), btwSnapshotLimit)
      },
      requestRender: () => ui.requestRender(),
      notify: (message, kind) => renderer.renderNotice(message, kind),
      onRunStarted: run => btwWire.open(run),
      onOverlayRequestedClose: () => btwWire.requestClose(),
      hasCapturingSurface: () => ui.tui.hasOverlay() || askUserActive,
    })
    btwWire.attach(btwController)

    const btwHandler: LocalCommandHandler = async rawInput => {
      const parsed = parseBtwInput(rawInput)
      if (parsed.kind === 'empty') {
        const opened = btwController.openReview()
        return opened === 'live'
          ? { kind: 'success' as const, text: t('tui.btw.backOnScreen') }
          : opened === 'review'
          ? { kind: 'success' as const, text: t('tui.btw.lastShown') }
          : { kind: 'success' as const, text: btwUsage() }
      }
      if (parsed.kind === 'error') return { kind: 'error' as const, text: parsed.error }
      // btw is by-the-way by definition: the main line must be running (and
      // this must be the live view, not a read-only remote one) — when idle,
      // a normal prompt is strictly better (tools, history, full context).
      if (!(bridge.isRunning() && !bridge.isReadOnlyView())) {
        return { kind: 'error' as const, text: btwIdleNotice() }
      }
      const result = btwController.submit({
        question: parsed.question,
        ...(parsed.modelOverride === undefined ? {} : { modelOverride: parsed.modelOverride }),
      })
      switch (result.kind) {
        case 'started':
          return { kind: 'success' as const, text: t('tui.btw.started') }
        case 'queued':
          return { kind: 'success' as const, text: t('tui.btw.queued', { position: result.position }) }
        case 'rejected':
          return { kind: 'error' as const, text: t('tui.btw.rejected', { reason: result.reason }) }
      }
    }
    registerLocalCommand('btw', t('tui.cmd.btw.description'), btwHandler)

    // ------------------------------------------- TUI-owned slash commands --
    // Web-surface parity: `model` is a browser client contribution there and
    // `export` a web-only download plugin — the terminal gets native
    // equivalents registered here, so the autocomplete catalog matches web.
    // Agentless bodies are registered through both ctx.commands (discovery,
    // lifecycle events against a live agent) and CommandService.registerLocal
    // (direct dispatch when no agent exists — no throwaway session).

    const modelHandler: LocalCommandHandler = async () => {
      const picked = await pickModel(
        ctx, ui.tui, ui.theme, bridge.getSelection(),
        refocusEditor,
      )
      if (picked === undefined) return { kind: 'success' as const, text: t('tui.model.unchanged') }
      const llm = ctx.get('llm')
      if (llm !== undefined) {
        await llm.resolveCallConfig({ provider: picked.provider, model: picked.model })
      }
      bridge.setSelection(picked)
      const persistError = await persistDefaultModel(ctx, picked)
      ui.requestRender()
      const modelText = picked.reasoningEffort === undefined
        ? t('tui.model.selected', { id: `${picked.provider}/${picked.model}` })
        : t('tui.model.selectedThink', { id: `${picked.provider}/${picked.model}`, effort: String(picked.reasoningEffort) })
      return {
        kind: 'success' as const,
        text: persistError === undefined ? modelText : t('tui.persist.failed', { text: modelText, error: persistError }),
      }
    }
    registerLocalCommand('model', t('tui.cmd.model.description'), modelHandler)

    // /agents: manage agent definition markdown files (model, think level,
    // spawn depth) — the terminal counterpart of pi's /fun-agent-cfg. An
    // optional argument preselects one agent by name.
    const agentsHandler: LocalCommandHandler = async rawInput => {
      const trimmed = rawInput?.trim() ?? ''
      const result = await openAgentManager(
        ctx, ui.tui, ui.theme, refocusEditor,
        trimmed === '' ? undefined : trimmed,
        () => subagentPolicy.getStats(),
      )
      if (result === undefined) return { kind: 'success' as const, text: t('tui.agents.unchanged') }
      return { kind: 'success' as const, text: result }
    }
    registerLocalCommand('agents', t('tui.cmd.agents.description'), agentsHandler)

    // /subagents: the command twin of Ctrl+G — pick a running (or recently
    // settled) subagent and inspect its live transcript in the 80% viewer.
    // Same flow as the key path; empty board closes immediately.
    const subagentsHandler: LocalCommandHandler = async () => {
      await openSubagentViewer(ctx, ui.tui, ui.theme, bridge, refocusEditor)
      return { kind: 'success' as const, text: t('tui.subagents.viewerClosed') }
    }
    registerLocalCommand('subagents', t('tui.cmd.subagents.description'), subagentsHandler)

    // /think: cycle the current model's reasoning effort without re-picking
    // the model. A no-session /think still lands in the selection ref and
    // survives the lazy session creation (bridge seeds only an empty ref).
    const thinkHandler: LocalCommandHandler = async () => {
      const current = bridge.getSelection()
      if (current === undefined) {
        return { kind: 'error' as const, text: t('tui.think.noModel') }
      }
      const result = await pickEffort(ctx, ui.tui, ui.theme, current, refocusEditor)
      if (result.kind === 'unsupported') {
        return {
          kind: 'error' as const,
          text: t('tui.think.unsupported', { id: `${current.provider}/${current.model}` }),
        }
      }
      if (result.kind === 'cancelled') return { kind: 'success' as const, text: t('tui.think.unchanged') }
      if (result.effort === 'default') {
        const next = { provider: current.provider, model: current.model }
        bridge.setSelection(next)
        const persistError = await persistDefaultModel(ctx, next)
        ui.requestRender()
        const thinkText = t('tui.think.providerDefault', { id: `${current.provider}/${current.model}` })
        return {
          kind: 'success' as const,
          text: persistError === undefined ? thinkText : t('tui.persist.failed', { text: thinkText, error: persistError }),
        }
      }
      const next = {
        provider: current.provider,
        model: current.model,
        reasoningEffort: result.effort,
      }
      bridge.setSelection(next)
      const persistError = await persistDefaultModel(ctx, next)
      ui.requestRender()
      const thinkText = t('tui.think.set', { effort: String(result.effort), id: `${current.provider}/${current.model}` })
      return {
        kind: 'success' as const,
        text: persistError === undefined ? thinkText : t('tui.persist.failed', { text: thinkText, error: persistError }),
      }
    }
    registerLocalCommand('think', t('tui.cmd.think.description'), thinkHandler)

    /**
     * Record one committed preset as THIS workspace's remembered selection
     * (`$DSH_HOME/workspace-presets.json`, keyed by the session backend's
     * project key of the cwd — the same grouping /resume and the writer lock
     * use). Honors the LIVE `dsh-tui.rememberPreset` toggle (off = no read at
     * startup, no write here; the file is kept so flipping back restores the
     * last choices). Never throws: memory is best-effort, a failed save is a
     * notice.
     */
    const persistRememberedPreset = (presetId: string): void => {
      try {
        if (!currentRememberPreset(ctx)) return
        const path = workspacePresetsPath()
        const doc = withRememberedPreset(loadWorkspacePresets(path), projectKeyFor(process.cwd()), presetId)
        const error = saveWorkspacePresets(path, doc)
        if (error !== undefined) renderer.renderNotice(t('tui.preset.memorySaveFailed', { error }), 'error')
      } catch {
        // A broken store must never fail the switch itself.
      }
    }

    // /preset: switch the agent preset — an EXPLICIT action that takes effect
    // immediately by starting a NEW session on the chosen preset. Every entry
    // path (picker Enter, `/preset <name>`, `/preset next`) funnels into
    // performPresetSwitch: with a live session a confirmation dialog gates the
    // switch (the current session stays resumable via /resume; the dialog
    // suggests /handoff for carry-over), without one the selection applies
    // directly (the first submit already creates the session on it).
    const presetHandler: LocalCommandHandler = async rawInput => {
      if (presetState.roster.length === 0) {
        return { kind: 'error' as const, text: t('tui.preset.none') }
      }
      const arg = rawInput?.trim() ?? ''
      let target: PresetEntry | undefined
      if (arg === '') {
        // Picker overlay — Enter leads into the confirmation flow below.
        const picked = await pickPreset(ui.tui, ui.theme, presetState, refocusEditor)
        if (picked !== undefined) target = presetState.roster.find(p => p.id === picked)
      } else if (arg.toLowerCase() === 'next') {
        // Nothing to rotate to on a single-entry roster (the switch would
        // re-confirm the same preset) — keep that a quiet no-op.
        target = presetState.roster.length > 1 ? peekNextPreset(presetState) : undefined
      } else {
        target = findPresetByName(presetState, arg)
        if (target === undefined) {
          return { kind: 'error' as const, text: t('tui.preset.unknown', { name: arg }) }
        }
      }
      if (target === undefined) return { kind: 'success' as const, text: t('tui.preset.unchanged') }
      const outcome = await performPresetSwitch(presetState, target, {        hasLiveSession: () => bridge.getAgent() !== undefined,
        confirmSwitch: (name, restart) =>
          openPresetConfirmDialog(ui.tui, ui.theme, name, restart, refocusEditor)
            .then(outcome => (outcome === 'cancelled' ? 'cancel' : outcome)),
        commit: async presetId => {
          bridge.setAgentPreset(presetId)
          await startNewSession()
          ui.requestRender()
        },
        forkCommit: async presetId => {
          const liveId = bridge.getSessionId()
          const agent = bridge.getAgent()
          if (agent === undefined) {
            // Raced to no-session while the dialog was up: nothing to carry —
            // degrade to the fresh path.
            await startNewSession()
            bridge.setAgentPreset(presetId)
            ui.requestRender()
            return
          }
          // Snapshot BEFORE anything tears the binding down — the in-memory
          // log is the stable source (dispose drops the registry handle), and
          // slicing here keeps the running turn out of the seed (the same
          // completed-turn rule /new obeys by cancelling it).
          // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
          // projection registration / sessionPersistence.handle.read() pagination. Kept
          // here deliberately — this path re-consumes RAW events (renderer/stats
          // replay), which the projection successor does not serve. (T14 review.)
          const seed = completedTurnSeed(agent.session.snapshotEvents())
          if (seed.length === 0) {
            // No completed turn to carry — a fork is indistinguishable from a
            // fresh start.
            await startNewSession()
            bridge.setAgentPreset(presetId)
            ui.requestRender()
            return
          }
          try {
            // forkCurrentSession tears the old binding down BEFORE creating
            // (the surface service cannot host two live agents) and records
            // the preset only after the create succeeded: a fork failure
            // leaves the old session DETACHED but fully resumable via
            // /resume, the recorded agentPreset untouched, and the selection
            // rolled back by performPresetSwitch.
            const handle = await bridge.forkCurrentSession(seed, agent.session.id, presetId)
            bridge.setAgentPreset(presetId)
            // Switching sessions cancels any in-flight btw — same contract as
            // /new and /resume (its snapshot belongs to the session left).
            btwController.cancelAll()
            refreshPermissionPreset()
            renderer.clear()
            liveWidgets.clear()
            // Replay the carried history (the /resume contract): the fork's
            // whole point is keeping the conversation visible — an echo line
            // would make it indistinguishable from /new — and the stats
            // rebuild rides the same replay. `firstLiveSeq` excludes nothing
            // published (constructor seeds never emit).
            const session = handle.agent.session
            // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
            // projection registration / sessionPersistence.handle.read() pagination. Kept
            // here deliberately — this path re-consumes RAW events (renderer/stats
            // replay), which the projection successor does not serve. (T14 review.)
            bridge.replay(session.snapshotEvents().filter(event => event.seq < session.firstLiveSeq))
            ui.requestRender()
          } catch (error) {
            // The recorded-preset guarantee above holds through the create.
            // A create failure leaves the old binding torn down (teardown
            // precedes the create): re-attach the previously live session.
            // A throw AFTER the bind (pure in-memory view work) keeps the
            // healthy fork session — restoring the old one there would
            // detach it; noted, not recoverable here.
            if (liveId !== undefined && bridge.getSessionId() === undefined) {
              await restoreLiveSession(liveId)
            }
            ui.requestRender()
            throw error
          }
        },
      })
      // Preset memory's recording leg: a COMMITTED switch (fresh, fork, or a
      // degraded fork — every switched path above seeds the same id) is the
      // moment the workspace's memory is written. Lives AFTER the switch so
      // a failed commit never records; the toggle is read LIVE, so a
      // /settings change applies without a restart. Best-effort: a failed
      // save is a notice, never a failed switch.
      if (outcome.switched) persistRememberedPreset(target.id)
      return { kind: 'success' as const, text: outcome.message }
    }
    registerLocalCommand('preset', t('tui.cmd.preset.description'), presetHandler)

    // Model profiles moved to the dsh-profile-switch plugin (ask-user based,
    // surface-agnostic). What stays HERE is the live-selection bridge it
    // consumes: the TUI's /model + /think ride the same selection ref, and
    // the plugin's /profile-switch applies through it so a switch stays live
    // in the current conversation. Agent model/think values still compose at
    // spawn from the frontmatter baseline ⊕ the pinned profile's overrides
    // (src/agent-runtime.ts), and new sessions still seed from the tree pin
    // (src/session.ts) — the shared $DSH_HOME/model-profiles.json store is
    // read-side only for this plugin now.
    ctx.provide('dshTuiModelSelection', {
      apply: (selection: ModelSelection) => {
        bridge.setSelection(selection)
        ui.requestRender()
      },
      current: () => bridge.getSelection(),
    })

    /**
     * The host session-title seam (`@deepseek-ai/dsh-session-title`), read
     * structurally like every other optional host service: the host base
     * bundle mounts it (with the first-prompt LLM provider), but a stripped
     * profile without it must only degrade the /session panel to read-only,
     * never crash it. The rename error contract is duck-typed by name — the
     * class itself lives behind a module graph (zod) this plugin
     * deliberately does not import.
     */
    const sessionTitleSeam = ((): {
      get(session: unknown): { title: string } | undefined
      rename(session: unknown, title: string): { title: string }
    } | undefined => {
      try {
        return ctx.get('sessionTitle') as { get(session: unknown): { title: string } | undefined, rename(session: unknown, title: string): { title: string } } | undefined
      } catch {
        return undefined
      }
    })()

    const sessionHandler: LocalCommandHandler = async () => {
      const agent = bridge.getAgent()
      const stats = bridge.getStats()
      const decode = bridge.getDecodeStats()
      const selection = bridge.getSelection()
      const header = agent?.session.header
      const liveSession = agent?.session
      const titleOf = liveSession === undefined ? undefined : sessionTitleSeam?.get(liveSession)?.title
      await showSessionInfo(ui.tui, ui.theme, {
        id: agent === undefined ? undefined : String(agent.session.id),
        cwd: header?.cwd,
        createdAt: header?.createdAt,
        model: selection === undefined ? undefined : `${selection.provider}/${selection.model}`,
        effort: selection === undefined || selection.reasoningEffort === undefined
          ? (selection === undefined ? undefined : t('tui.session.effortDefault'))
          : String(selection.reasoningEffort),
        msgCount: stats.msgCount,
        toolCallCount: stats.toolCallCount,
        inputTokens: stats.inputTokens,
        outputTokens: stats.outputTokens,
        cacheReadTokens: stats.cacheReadTokens,
        cacheWriteTokens: stats.cacheWriteTokens,
        overallTps: decodeTps(decode.decodeMs, decode.decodeTokens),
        routes: decode.routes.map(route => ({
          route: route.route,
          requests: route.requests,
          outputTokens: route.outputTokens,
          tps: decodeTps(route.decodeMs, route.decodeTokens),
        })),
        status: agent === undefined ? 'none' : agentStatus,
        eventCount: agent === undefined ? undefined : agent.session.seq,
        parentSession: header?.parentSession === undefined ? undefined : String(header.parentSession),
        title: titleOf,
        canRename: liveSession !== undefined && sessionTitleSeam !== undefined,
      }, refocusEditor, liveSession === undefined || sessionTitleSeam === undefined
        ? undefined
        : (title) => {
            try {
              const snapshot = sessionTitleSeam.rename(liveSession, title)
              return { ok: true, note: t('tui.session.renamed', { title: snapshot.title }), title: snapshot.title }
            } catch (error) {
              // The one input-blaming failure gets a panel-friendly phrase;
              // anything else (disposed service, non-live session) rides its
              // own message into the panel's note line.
              if (error instanceof Error && error.name === 'SessionTitleInvalidError') {
                return { ok: false, note: t('tui.session.titleEmpty') }
              }
              throw error
            }
          })
      return { kind: 'success' as const, text: agent === undefined ? t('tui.session.none') : t('tui.session.infoShown') }
    }
    registerLocalCommand('session', t('tui.cmd.session.description'), sessionHandler)

    // /resume: pick a persisted session, validate its log, swap the live
    // agent for it, and rebuild transcript + stats from the stored events.
    // The post-pick body (validate → resume → replay, corrupt-log repair,
    // write-lease fallback) lives in resumeTarget so /search reuses the
    // exact same path for its hits.
    const resumeTarget = async (target: { id: SessionId }) => {
      // The selected row's resume path: swap the live agent for the target
      // and rebuild transcript + stats from the stored events. Shared by the
      // direct hit and the post-repair re-entry so both behave identically
      // (including the WriterLockedError read-only fallback).
      const resumeAndReplay = async () => {
        let resumed: Awaited<ReturnType<DshSessionBridge['resume']>>
        // Switching sessions cancels any in-flight btw (Q5b) — its snapshot
        // belongs to the session being left.
        btwController.cancelAll()
        try {
          resumed = await bridge.resume(target.id)
        } catch (error: unknown) {
          const message = messageOf(error)
          if (error instanceof SessionAlreadyOwnedError) {
            // The host's kernel write lease refused the cold resume: another
            // process drives this session. Rather than a dead end, degrade to
            // a READ-ONLY view synced from its persisted log — final replies
            // arrive (poll-delayed, without streaming detail); input is
            // refused until /resume or /new.
            try {
              await bridge.watchRemote(target.id)
              refreshPermissionPreset()
              renderer.clear()
              liveWidgets.clear()
              ui.requestRender()
              return {
                kind: 'success' as const,
                text: t('tui.resume.watching', { id: clipToWidth(String(target.id), 8) }),
              }
            } catch (watchError: unknown) {
              return {
                kind: 'error' as const,
                text: t('tui.resume.watchFailed', { id: clipToWidth(String(target.id), 8), error: messageOf(watchError) }),
              }
            }
          }
          return {
            kind: 'error' as const,
            text: t('tui.resume.failed', { error: message }),
          }
        }
        // Seed the badge cache for the resumed session (its pin event may have
        // been emitted before the bridge's session-id filter re-bound).
        refreshPermissionPreset()
        // Clear BEFORE replay: the renderer's local-echo dedupe must not see
        // replayed user messages next to a stale prompt echo. The live widget
        // drops the previous session's todos too (its agents already went via
        // the bridge's onLive([]) on resume reset).
        renderer.clear()
        liveWidgets.clear()
        // Replay seed history only: events at or above firstLiveSeq were
        // published in-process and arrive again through the session/event
        // subscription (replaying them would double-count stats and echo).
        // Seeds entered through construction never published — replaying them
        // exactly once covers the stored log with zero overlap, zero gap.
        const session = resumed.agent.session
        // Adopted live sessions (attach arm): EVERY event in the log was
        // published before this surface started tracking it — the firehose
        // dropped all of them, so replay unfiltered or the transcript misses
        // everything the other surface did. Cold resumes keep the firstLiveSeq
        // filter (seeded history replays once; live events re-arrive).
        const adopted = 'adopted' in resumed && resumed.adopted === true
        // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
        // projection registration / sessionPersistence.handle.read() pagination. Kept
        // here deliberately — this path re-consumes RAW events (renderer/stats
        // replay), which the projection successor does not serve. (T14 review.)
        bridge.replay(adopted ? session.snapshotEvents() : session.snapshotEvents().filter(event => event.seq < session.firstLiveSeq))
        ui.requestRender()
        return {
          kind: 'success' as const,
          text: t('tui.resume.done', { id: clipToWidth(String(target.id), 8), count: session.seq }),
        }
      }

      // Corrupt-log branch: the repair rewrites user data on disk, so it is
      // gated behind an explicit confirmation dialog — it never runs
      // silently, and Cancel falls back to the plain failure text.
      const offerCorruptedLogRepair = async (message: string) => {
        // Locate BEFORE asking (feishu-surface order): a log that cannot be
        // grounded on disk gives the dialog nothing to confirm.
        const persistence = ctx.get('sessionPersistence') as
          | { list?: () => Promise<Array<{ id: unknown; cwd?: unknown }>> }
          | undefined
        const logPath = await locateSessionLog(persistence, String(target.id), sessionLogRoot())
        if (logPath === undefined) {
          return {
            kind: 'error' as const,
            text: t('tui.repair.logMissing', { id: clipToWidth(String(target.id), 8) }),
          }
        }
        if (await openRepairConfirmDialog(ui.tui, ui.theme, refocusEditor) !== 'repair') {
          return {
            kind: 'error' as const,
            text: t('tui.resume.cannot', { id: clipToWidth(String(target.id), 8), error: message }),
          }
        }
        // repairSessionLog maps its own failures to results; the catch is a
        // defensive floor so the dispatch never sees an exception.
        let notice: string | undefined
        try {
          notice = repairFailureNotice(await repairSessionLog(logPath))
        } catch (error: unknown) {
          const detail = messageOf(error)
          notice = t('tui.repair.failed', { error: detail })
        }
        if (notice !== undefined) return { kind: 'error' as const, text: notice }
        // A verified-clean log now sits under the canonical name — re-enter
        // the selected row's resume path.
        return resumeAndReplay()
      }

      // Validate the target log before tearing down the current agent: a
      // corrupt log must leave the live session untouched.
      try {
        await inspectPersistedSession(ctx, target.id)
      } catch (error: unknown) {
        const message = messageOf(error)
        if (isCorruptLogError(message)) {
          return offerCorruptedLogRepair(message)
        }
        return { kind: 'error' as const, text: t('tui.resume.cannot', { id: clipToWidth(String(target.id), 8), error: message }) }
      }
      return resumeAndReplay()
    }

    const resumeHandler: LocalCommandHandler = async () => {
      let picked: Awaited<ReturnType<typeof pickPersistedSession>>
      try {
        const currentId = bridge.getSessionId()
        // Explicit dsh-tui.resume overrides from the profile patch (the
        // descriptor's user layer): the picker resolves them against
        // env/defaults per open, so a committed settings change applies to
        // the next /resume.
        const resumeSettings = (await readSessionManagementExplicit(ctx))?.resume
        picked = await pickPersistedSession(
          ctx, ui.tui, ui.theme,
          currentId === undefined ? undefined : String(currentId),
          refocusEditor,
          resumeSettings,
        )
      } catch (error: unknown) {
        const message = messageOf(error)
        return { kind: 'error' as const, text: message }
      }
      if (picked.kind === 'empty') {
        return { kind: 'error' as const, text: t('tui.resume.noneOther') }
      }
      if (picked.kind === 'empty-filtered') {
        // Sessions exist but the display window hid them all — name the
        // window and the knobs so the user knows what to adjust instead of
        // reading "nothing to resume" over a store full of old sessions.
        const floor = picked.minBytes >= 1024
          ? `${Math.round(picked.minBytes / 1024)}KB`
          : `${picked.minBytes}B`
        return {
          kind: 'error' as const,
          text: t('tui.resume.windowEmpty', { days: picked.maxAgeDays, floor }),
        }
      }
      if (picked.kind === 'cancelled') return { kind: 'success' as const, text: t('tui.resume.cancelled') }
      return resumeTarget({ id: picked.id })
    }
    registerLocalCommand('resume', t('tui.cmd.resume.description'), resumeHandler)

    // /search: cross-session full-text search over the sessionQuery FTS
    // index (enabled by this bundle's patch override of the stock
    // session-query-sqlite row). A hit resumes through resumeTarget — the
    // same path a /resume pick takes.
    const searchHandler: LocalCommandHandler = async () => {
      const seam = ctx.get('sessionQuery') as { searchSessions?: unknown } | undefined
      if (seam?.searchSessions === undefined) {
        return { kind: 'error' as const, text: t('tui.search.unavailable') }
      }
      const picked = await openSearchOverlay({
        ctx,
        tui: ui.tui,
        theme: ui.theme,
        restoreFocus: refocusEditor,
      })
      if (picked === undefined) return { kind: 'success' as const, text: t('tui.search.cancelled') }
      if (picked.child) {
        // The hit lives in a subagent child session: resuming it as the
        // main conversation would misplace the recursion budget, so Enter
        // opens the read-only cold browse (/history <id>) over its stored
        // log instead — the content is fully readable, nothing is resumed.
        return historyHandler(picked.id, new AbortController().signal)
      }
      return resumeTarget({ id: SessionId(picked.id) })
    }
    registerLocalCommand('search', t('tui.cmd.search.description'), searchHandler)

    // /history: the read-only two-pane look-back (ADR 0003) — left pane lists
    // the browsed session's completed turns, right pane shows the selected
    // turn's replies; Enter/c refills the editor with the turn's prompt (a
    // plain setText, never submitted). Bare /history browses the CURRENT live
    // session (snapshot at open — no live updates while it stays open);
    // /history <sessionId> cold-reads a stored log (no writer lock). `s`
    // swaps the browsed session through a /resume-style picker. Nothing here
    // writes a session log or takes the writer lock.
    const historyHandler: LocalCommandHandler = async rawInput => {
      const arg = rawInput?.trim() ?? ''
      const result = await openHistoryBrowser({
        ctx,
        tui: ui.tui,
        theme: ui.theme,
        getSessionId: () => {
          const id = bridge.getSessionId()
          return id === undefined ? undefined : String(id)
        },
        // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
        // projection registration / sessionPersistence.handle.read() pagination. Kept
        // here deliberately — this path re-consumes RAW events (renderer/stats
        // replay), which the projection successor does not serve. (T14 review.)
        getLiveEvents: () => bridge.getAgent()?.session.snapshotEvents(),
        copyToEditor: text => {
          ui.editor.setText(text)
          ui.requestRender()
        },
        confirmForkAtTurn: (turnLabel, totalTurns, cold) => {
          // Cold browse: the fork detaches the LIVE session — the dialog must
          // name it (short id) instead of hiding its fate.
          const liveId = bridge.getSessionId()
          return openForkAtTurnDialog(
            ui.tui, ui.theme, turnLabel, totalTurns,
            cold && liveId !== undefined ? clipToWidth(liveId, 8) : undefined,
            refocusEditor,
          ).then(outcome => outcome === 'fork')
        },
        forkAtTurn: async (seed, parentSessionId) => {
          const liveId = bridge.getSessionId()
          // Cancel the btw context snapshot first — the switch strands it
          // (the /new contract).
          btwController.cancelAll()
          bridge.setAgentPreset(currentPreset(presetState)?.id)
          try {
            const handle = await bridge.forkCurrentSession(seed, SessionId(parentSessionId), currentPreset(presetState)?.id)
            refreshPermissionPreset()
            renderer.clear()
            liveWidgets.clear()
            // Replay the carried history (the /resume contract) — for a fork
            // the seed IS the point, so it replays in full (`firstLiveSeq`
            // covers seed + end-seed).
            const session = handle.agent.session
            // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
            // projection registration / sessionPersistence.handle.read() pagination. Kept
            // here deliberately — this path re-consumes RAW events (renderer/stats
            // replay), which the projection successor does not serve. (T14 review.)
            bridge.replay(session.snapshotEvents().filter(event => event.seq < session.firstLiveSeq))
            ui.requestRender()
          } catch (error) {
            // The bridge tears the live binding down BEFORE the create, so a
            // failed create leaves no live session: re-attach the previously
            // live one (a failing re-attach reports itself — never silent).
            // The selection was never touched (fork keeps the current preset).
            if (liveId !== undefined && bridge.getSessionId() === undefined) {
              await restoreLiveSession(liveId)
            }
            ui.requestRender()
            throw error
          }
        },
        reportError: message => renderer.renderNotice(message, 'error'),
        restoreFocus: refocusEditor,
        requestRender: () => ui.requestRender(),
      }, arg === '' ? undefined : arg)
      return { kind: result.error ? 'error' as const : 'success' as const, text: result.text }
    }
    registerLocalCommand('history', t('tui.cmd.history.description'), historyHandler)

    // Auto-resume after a hot-reload: a `/reload` stashes the previously
    // current session id before this fiber's teardown, and the freshly
    // re-imported module consumes it best-effort here so the next prompt
    // continues that session instead of lazily creating a fresh one. The stash
    // is already one-shot-consumed by takeStashedSessionId, so on ANY failure
    // we fall back silently to today's behavior (next prompt creates a new
    // session); the apply must never crash on this. Guarded against re-entrant
    // reloads: if a second reload happens while this runs, takeStashedSessionId
    // returns undefined and the block no-ops.
    const stashedSessionId = takeStashedSessionId()
    if (stashedSessionId !== undefined) {
      void (async () => {
        try {
          const resumed = await bridge.resume(stashedSessionId)
          // Mirror the /resume flow: seed the badge cache, drop the previous
          // session's render state, and replay only the seed history.
          refreshPermissionPreset()
          renderer.clear()
          liveWidgets.clear()
          const session = resumed.agent.session
          // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
          // projection registration / sessionPersistence.handle.read() pagination. Kept
          // here deliberately — this path re-consumes RAW events (renderer/stats
          // replay), which the projection successor does not serve. (T14 review.)
          bridge.replay(session.snapshotEvents().filter(event => event.seq < session.firstLiveSeq))
          ui.requestRender()
        } catch { /* best-effort: fall back to lazy session creation */ }
      })()
    }

    // Boot-intent resume: `dsh --profile <name> --resume <id>` — the flag
    // family the exit hint prints. Only when no reload stash claimed the
    // fiber: the stash is the NEWER intent (the session live when the user
    // hit /reload), while the boot flag describes a launch long past.
    // Mirrors the /resume flow's validate-first contract: a bad id or a
    // corrupt log surfaces as a buffered notice and the TUI continues as a
    // fresh session instead of failing the boot.
    const bootResumeId = parseResumeArg(cmdlineArgs ?? [])
    if (stashedSessionId === undefined && bootResumeId !== undefined) {
      void (async () => {
        try {
          await inspectPersistedSession(ctx, SessionId(bootResumeId))
          const resumed = await bridge.resume(SessionId(bootResumeId))
          refreshPermissionPreset()
          renderer.clear()
          liveWidgets.clear()
          const session = resumed.agent.session
          // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
          // projection registration / sessionPersistence.handle.read() pagination. Kept
          // here deliberately — this path re-consumes RAW events (renderer/stats
          // replay), which the projection successor does not serve. (T14 review.)
          bridge.replay(session.snapshotEvents().filter(event => event.seq < session.firstLiveSeq))
          ui.requestRender()
        } catch (error: unknown) {
          const message = messageOf(error)
          renderer.renderNotice(t('tui.boot.resumeFailed', { id: clipToWidth(bootResumeId, 8), error: message }), 'error')
        }
      })()
    }

    // Agentless guard: dsh's own /export addresses a live agent and would
    // mint a throwaway session just to report there is nothing to export —
    // CommandService routes this locally only when no agent exists, and
    // falls back to the dsh path when one does (behavior unchanged there).
    commands.registerLocal('export', async () => ({
      kind: 'error' as const,
      text: t('tui.export.noSession'),
    }))
    ctx.effect(() => ctx.commands.register({
      name: 'export',
      description: t('tui.cmd.export.description'),
      input: { hint: '[path]' },
      handler: async invocation => {
        // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
        // projection registration / sessionPersistence.handle.read() pagination. Kept
        // here deliberately — this path re-consumes RAW events (renderer/stats
        // replay), which the projection successor does not serve. (T14 review.)
        const events = invocation.agent.session.snapshotEvents()
        const fallback = join(homedir(), 'Downloads', `dsh-session-${clipToWidth(String(invocation.agent.session.id), 8)}.jsonl`)
        const target = invocation.rawInput.trim() === '' ? fallback : resolve(invocation.rawInput.trim())
        await mkdir(dirname(target), { recursive: true })
        await writeFile(target, events.map(event => JSON.stringify(event)).join('\n') + '\n')
        return { kind: 'success' as const, text: t('tui.export.done', { count: events.length, path: target }) }
      },
    }), 'dsh-tui-pi: /export')

    // /new: detach the live agent (and clear the on-screen transcript) so
    // the next prompt opens a brand-new session. The escape hatch for
    // "current session has images in history, the next model doesn't accept
    // them" — and any other case where the user wants a clean slate.
    // detachCurrent keeps the event subscriptions alive (dispose() would
    // splice them away and no future message would ever render again).
    /**
     * Detach the live session and reset the surfaces — the ONE body /new and
     * the preset switch share (a preset applies only to a NEW session, so a
     * confirmed switch runs the same detach/clear path; never a copy of it).
     */
    const startNewSession = async (): Promise<void> => {
      // A new session strands the btw context snapshot — cancel first (Q5b).
      btwController.cancelAll()
      try { await bridge.detachCurrent() } catch { /* contained */ }
      // No agent → the badge cache must not serve the old session's preset
      // to a later one (the next prompt re-seeds it).
      refreshPermissionPreset()
      renderer.clear()
      // The widget's agents already cleared via the bridge's onLive([]); drop
      // the previous session's todos too.
      liveWidgets.clear()
    }

    /**
     * Best-effort re-attach of a previously live session after a FAILED
     * fork: the bridge tears the live binding down before the seeded create
     * (its setup must compose in a clean scope), so a failed fork leaves no
     * live session. Rebuilds the transcript from the resumed log; a failing
     * re-attach itself is reported through the buffered notice channel
     * (never silently swallowed — the user must know the live session is
     * gone from the keyboard) and resolves anyway: the next prompt starts a
     * fresh session.
     */
    const restoreLiveSession = async (liveId: string): Promise<void> => {
      try {
        const restored = await bridge.resume(SessionId(liveId))
        refreshPermissionPreset()
        renderer.clear()
        liveWidgets.clear()
        const session = restored.agent.session
        // dsh 0.1.7 soft-deprecation: snapshotEvents is deprecated upstream in favor of
        // projection registration / sessionPersistence.handle.read() pagination. Kept
        // here deliberately — this path re-consumes RAW events (renderer/stats
        // replay), which the projection successor does not serve. (T14 review.)
        bridge.replay(session.snapshotEvents().filter(event => event.seq < session.firstLiveSeq))
      } catch (error) {
        const detail = messageOf(error)
        renderer.renderNotice(
          'could not re-attach the previous session — it stays resumable via /resume;'
          + ` the next prompt starts a fresh one (${detail})`,
          'error',
        )
      }
      ui.requestRender()
    }

    const newHandler: LocalCommandHandler = async () => {
      await startNewSession()
      return { kind: 'success' as const, text: t('tui.new.done') }
    }
    registerLocalCommand('new', t('tui.cmd.new.description'), newHandler)

    // /settings: text-based configuration browser — the terminal counterpart
    // of the web GUI's settings surface. Enumerates ctx.settings.describe()
    // (one descriptor per settings-bearing plugin entry) and walks each
    // entry's schema (drill-ins, cycle rows, inline editors,
    // reset-to-defaults), writing through settings.mutate path ops.
    const settingsHandler: LocalCommandHandler = async () => {
      if (ctx.get('settings') === undefined) {
        return { kind: 'error' as const, text: t('tui.settings.unavailable') }
      }
      const changes = await openSettingsBrowser({
        ctx,
        tui: ui.tui,
        theme: ui.theme,
        restoreFocus: refocusEditor,
        // The hand-declared-route edit form flows in from here so
        // settings.ts stays free of the custom-provider import cycle.
        buildProviderEditFlow: ({ draft, onCommit, onExit, onError }) => new CustomProviderFlow({
          tui: ui.tui,
          theme: ui.theme,
          takenIds: new Set(),
          edit: draft,
          onCommit,
          onExit,
          onError,
        }),
        onError: message => {
          // Buffered notice: the settings browser outlives the write, so the
          // line must survive a theme hot-swap (the doc.clear() rebuild).
          renderer.renderNotice(message, 'error')
        },
      })
      if (changes < 0) return { kind: 'error' as const, text: t('tui.settings.noNamespaces') }
      return {
        kind: 'success' as const,
        text: changes === 0
          ? t('tui.settings.noChanges')
          : changes === 1
            ? t('tui.settings.appliedOne', { count: changes })
            : t('tui.settings.appliedMany', { count: changes }),
      }
    }
    registerLocalCommand('settings', t('tui.cmd.settings.description'), settingsHandler)

    // /plugins: bundle manager over the base pluginManager service — the
    // terminal counterpart of the web profile's plugin page (Enter toggles,
    // d uninstalls behind a confirm, i installs a spec after an inspect
    // preview, / filters).
    const pluginsHandler: LocalCommandHandler = async () => {
      const error = await openPluginsPanel({
        tui: ui.tui,
        theme: ui.theme,
        manager: ctx.get('pluginManager') as PluginManagerSeam | undefined,
        restoreFocus: refocusEditor,
        onError: message => renderer.renderNotice(message, 'error'),
      })
      return error === undefined
        ? { kind: 'success' as const, text: '' }
        : { kind: 'error' as const, text: error }
    }
    registerLocalCommand('plugins', t('tui.cmd.plugins.description'), pluginsHandler)

    // /skills: standalone skill browser with Installed/Available dual mode.
    // Enter/Space toggles or symlinks; Tab switches views; Esc exits.
    const skillsHandler: LocalCommandHandler = async () => {
      const agent = bridge.getAgent()
      openSkillsManagerPanel(ctx, ui.tui, ui.theme, refocusEditor, agent ?? undefined, () => {})
      return { kind: 'success' as const, text: t('tui.skills.opened') }
    }
    registerLocalCommand('skills', t('tui.cmd.skills.description'), skillsHandler)

    // /theme: pick a color scheme and apply it immediately — the choice is
    // persisted to the dsh-tui entry config (a volatile-only write: the
    // document-updated subscription re-applies the same value anyway, an
    // idempotent echo) and hot-swapped into the running TUI: footer hint,
    // editor border and the whole transcript repaint on the next frame, no
    // restart needed. The settings guard mirrors /settings: without the
    // service there is nowhere to write.
    const themeHandler: LocalCommandHandler = async () => {
      if (ctx.get('settings') === undefined) {
        return { kind: 'error' as const, text: t('tui.settings.unavailable') }
      }
      // Preselect from the live settings value (which may have changed since
      // startup via the /settings browser), not the startup snapshot. The
      // picker lists the registry themes (user + built-in) after the
      // constant auto/light/dark rows.
      const picked = await pickTheme(ui.tui, ui.theme, currentThemePreference(ctx), refocusEditor, {
        themes: themeRegistry,
        userNames: themeUserNames,
      })
      if (picked === undefined) return { kind: 'success' as const, text: t('tui.theme.unchanged') }
      const writeError = await writeThemePreference(ctx, picked)
      if (writeError !== undefined) return { kind: 'error' as const, text: writeError }
      // DSH_TUI_THEME pins the display regardless of the preference — don't
      // claim the pick was applied when it wasn't. Compare against the
      // env-free resolution of the same pick (the bundle cache makes the
      // reference comparison exact); 'auto' is skipped — it was never
      // env-pin-sensitive (its display follows the terminal either way).
      const applied = resolveTheme(process.env, picked, themeRegistry)
      applyTheme(applied)
      const expected = picked === 'auto' ? undefined : resolveTheme({}, picked, themeRegistry)
      if (expected !== undefined && applied !== expected) {
        return {
          kind: 'success' as const,
          text: t('tui.theme.pinned', { value: String(process.env.DSH_TUI_THEME) }),
        }
      }
      return { kind: 'success' as const, text: t('tui.theme.applied', { name: picked }) }
    }
    registerLocalCommand('theme', t('tui.cmd.theme.description'), themeHandler)

    // /language — switch the UI language. Language files live in the bundled
    // locales/ directory plus the user's ~/.dsh/locales (one JSON file per
    // language; adding one needs no code). Bare `/language` asks through the
    // native ask-user panel (src/language-ask.ts) — the same docked question
    // UI the model uses, so it answers on any registered surface (the TUI, a
    // phone through dsh-feishu) with first answer wins. `/language <id>`
    // switches directly. Either way the switch applies live (the next repaint
    // speaks it) and persists the choice to `dsh-tui.language`.
    const installedLanguages = (): string =>
      listLocales().map(locale => `${locale.id} (${locale.name})`).join(', ')
    const applyLanguage = async (id: string) => {
      if (!setLocale(id)) {
        return { kind: 'error' as const, text: t('command.language.unknown', { id, list: installedLanguages() }) }
      }
      const persistError = await writeLanguagePreference(ctx, id)
      const active = currentLocale()
      const switched = t('command.language.switched', { name: active.name, id: active.id })
      return {
        kind: 'success' as const,
        text: persistError === undefined
          ? switched
          : `${switched} ${t('command.language.persistFailed', { error: persistError })}`,
      }
    }
    const languageHandler: LocalCommandHandler = async (rawInput, signal) => {
      const arg = rawInput.trim()
      if (arg !== '') return applyLanguage(arg)
      const ask = ctx.get('userQuestions') as AskSeam | undefined
      if (ask === undefined) {
        return {
          kind: 'error' as const,
          text: t('command.language.unavailable', { list: installedLanguages() }),
        }
      }
      // Scope the ask to the live session when there is one (only the
      // surfaces driving it are asked); a fresh TUI asks agentless.
      let outcome: LanguageOutcome
      try {
        outcome = await askLanguageChoice(ask, { agent: bridge.getAgent(), signal })
      } catch (error) {
        return {
          kind: 'error' as const,
          text: t('command.language.askFailed', {
            error: error instanceof Error ? error.message : String(error),
          }),
        }
      }
      if (outcome.kind === 'picked') return applyLanguage(outcome.id)
      if (outcome.kind === 'unknown') {
        return { kind: 'error' as const, text: t('command.language.unknown', { id: outcome.text, list: installedLanguages() }) }
      }
      // Picked the active language, declined the question, or it was never
      // answered — nothing changed.
      return { kind: 'success' as const, text: t('command.language.unchanged') }
    }
    registerLocalCommand('language', t('command.language.description'), languageHandler)

    // /reload: hot-reload this plugin from the current source — re-imports the
    // module and its dependencies (picking up src changes after `pnpm build`)
    // and swaps the plugin runtime. The old fiber is disposed, so the TUI and
    // the live agent bridge are torn down; the session log persists and can be
    // rejoined with /resume. Failures before the swap leave the TUI untouched.
    const reloadHandler: LocalCommandHandler = async () => ({
      kind: 'success' as const,
      text: await reloadPlugin(ctx, import.meta.url),
    })
    registerLocalCommand('reload', t('tui.cmd.reload.description'), reloadHandler)

    // /hotkeys — pi's keybinding browser, in the /agents select-panel style:
    // a field list of the app keys, Enter opens an editor that writes
    // ~/.dsh/keybindings.json and live-applies the change (no /reload).
    const hotkeysHandler: LocalCommandHandler = async () => {
      const summary = await openHotkeysManager(ui.tui, ui.theme, {
        filePath: keyFile,
        apply: bindings => ui.setKeyBindings(bindings),
        restoreFocus: refocusEditor,
      })
      return { kind: 'success' as const, text: summary ?? t('tui.hotkeys.unchanged') }
    }
    registerLocalCommand('hotkeys', t('tui.cmd.hotkeys.description'), hotkeysHandler)

    // /login: register provider credentials — the terminal counterpart of
    // pi-agent's /login, on the Models category's add-provider flow. Opens a
    // searchable provider directory (including already-configured routes, so
    // a re-login can overwrite a key), collects one API key through the masked
    // editor, and commits the provider profile + credential the way the web
    // Models page does. An optional argument names the provider: `/login
    // openai` jumps straight to the key editor on a unique match and to a
    // filtered picker otherwise.
    const loginHandler: LocalCommandHandler = async rawInput => {
      if (ctx.get('settings') === undefined) {
        return { kind: 'error' as const, text: t('tui.settings.unavailable') }
      }
      const result = await openLoginFlow({
        ctx,
        tui: ui.tui,
        theme: ui.theme,
        restoreFocus: refocusEditor,
        onError: message => renderer.renderNotice(message, 'error'),
        target: rawInput?.trim() ?? '',
      })
      if (result.kind === 'unknown') {
        return {
          kind: 'error' as const,
          text: t('tui.login.unknownProvider', { name: result.target }),
        }
      }
      if (result.kind === 'cancelled') return { kind: 'success' as const, text: t('tui.login.cancelled') }
      return { kind: 'success' as const, text: t('tui.login.configured', { name: result.name }) }
    }
    registerLocalCommand('login', t('tui.cmd.login.description'), loginHandler)

    // /logout: unsubscribe a provider — pi-agent's /logout on the dsh side.
    // Lists the providers with a stored credential; on selection removes the
    // key AND the profile patch's llm-pi-ai provider entry, so the provider's models
    // leave /model right away (the llm-pi-ai adapter keeps a route
    // registered for every profile key). /login re-subscribes and serves
    // the installed catalog's current model list.
    const logoutHandler: LocalCommandHandler = async () => {
      if (ctx.get('settings') === undefined) {
        return { kind: 'error' as const, text: t('tui.settings.unavailable') }
      }
      const result = await openLogoutFlow({
        ctx,
        tui: ui.tui,
        theme: ui.theme,
        restoreFocus: refocusEditor,
        onError: message => renderer.renderNotice(message, 'error'),
      })
      if (result.kind === 'none') {
        return { kind: 'success' as const, text: t('tui.logout.none') }
      }
      if (result.kind === 'cancelled') return { kind: 'success' as const, text: t('tui.logout.cancelled') }
      if (result.kind === 'failed') {
        const cause = result.cause === undefined ? '' : `: ${result.cause}`
        return { kind: 'error' as const, text: t('tui.logout.failed', { name: result.name, cause }) }
      }
      if (result.kind === 'removed-incomplete') {
        return {
          kind: 'error' as const,
          text: t('tui.logout.incomplete', { name: result.name, error: result.error }),
        }
      }
      if (result.kind === 'removed-key-only') {
        return {
          kind: 'success' as const,
          text: t('tui.logout.keyOnly', { name: result.name }),
        }
      }
      return {
        kind: 'success' as const,
        text: t('tui.logout.done', { name: result.name }),
      }
    }
    registerLocalCommand('logout', t('tui.cmd.logout.description'), logoutHandler)

    // ------------------------------------------------- powerline footer + git --
    const git = new GitBranchWatcher(process.cwd())
    git.onChange = () => ui.requestRender()
    ui.setEditorBranchProvider(() => git.getBranch())
    // Permission badge: the live session's effective preset under the web
    // client's display conventions (danger-full-access → "Full access").
    // Reads the cached current preset — O(1) per render, never a session-log
    // fold (that lives in refreshPermissionPreset, once per session/knob
    // change). Falls back to a live fold only while the cache is unprimed:
    // the session's initial pin event can be dropped by the bridge's
    // session-id filter (which binds only after agent creation completes),
    // so until the ensure/resume seed lands, the fallback keeps the badge
    // correct at the price of one fold per frame — bounded by the short
    // creation window.
    ui.setEditorPermissionProvider(() => {
      const presets = ctx.get('permissionPresets')
      const agent = bridge.getAgent()
      if (presets === undefined || agent === undefined) return undefined
      const current = permissionPreset ?? presets.current(agent.session)
      return displayPermissionPreset(current, presets.optionOf(current).name)
    })

    let contextWindow: number | undefined
    let contextWindowKey = ''
    const footerSource: FooterDataSource = {
      getStats: () => bridge.getStats(),
      getSelection: () => bridge.getSelection(),
      getBranch: () => git.getBranch(),
      getPreset: () => formatPresetLabel(currentPreset(presetState)),
      // Live read per render (like FooterHint's hints getter): a committed
      // cacheHitMode change shows on the next repaint, no watch plumbing.
      getCacheHitMode: () => currentCacheHitMode(ctx),
      getContextWindow: () => {
        const selection = bridge.getSelection()
        if (selection === undefined) return undefined
        const key = `${selection.provider}/${selection.model}`
        if (key !== contextWindowKey) {
          contextWindowKey = key
          contextWindow = undefined
          const llm = ctx.get('llm')
          if (llm !== undefined) {
            void llm.resolveModelInfo(selection.provider, selection.model).then(info => {
              const window = info.context?.contextWindow
              if (contextWindowKey === key && typeof window === 'number') {
                contextWindow = window
                ui.requestRender()
              }
            }).catch(() => { /* unknown window → footer degrades gracefully */ })
          }
        }
        return contextWindow
      },
    }
    ui.footer.clear()
    ui.footer.addChild(new PowerlineFooter(footerSource, () => ui.theme))
    // Keybinding hint, added *after* the clear above: a single width-clipped
    // row (never word-wraps) reading the live footer-hints selection through
    // its getter — a /settings toggle applies on the next repaint, and the
    // theme colors follow `ui.theme` (see FooterHint in footer.ts).
    let footerHintsRef: FooterHints = footerHints
    const footerHint = new FooterHint(() => ui.theme, () => footerHintsRef)
    ui.footer.addChild(footerHint)
    // Arm the footer-hints hot-reload sink now that the TUI exists (see apply()).
    applyFooterHintsRef = (hints: FooterHints): void => {
      footerHintsRef = hints
      ui.requestRender()
    }
    // Arm the icon-set hot-reload sink: a committed iconSet change hot-applies the
    // risky glyphs (an 'auto' change resolves against the startup font-
    // detection snapshot, matching the startup glyph choice) and repaints the
    // footer/notices/panels that carry them on the next frame.
    applyIconSetRef = (set: IconSet): void => {
      applyIconSet(resolveIconSet(set, nerdfontAvailable))
      ui.requestRender()
    }

    /**
     * Hot-apply a theme bundle to the running TUI: the transcript rebuilds
     * from its replay buffer, the dock/editor swap to the new bundle, and the
     * spinner (when mid-turn) is recreated with the new accent. Per-piece
     * requestRenders coalesce into the single next-throttled frame, so the
     * switch repaints once. No-op on the unchanged bundle — the settings
     * watch echoes this TUI's own /theme write, and the theme modules are
     * singletons.
     */
    const applyTheme = (theme: TuiTheme): void => {
      if (theme === ui.theme) return
      renderer.setTheme(theme)
      liveWidgets.setTheme(theme)
      ui.applyTheme(theme)
      if (loader !== undefined) {
        loader.stop()
        ui.status.removeChild(loader)
        loader = undefined
        setStatus(agentStatus)
      }
    }

    // 'auto' refinement (the cmux/gostty case): COLORFGBG is often absent or
    // wrong inside multiplexers, so the synchronous startup guess may be
    // wrong. Ask the terminal itself — CSI ?996n color-scheme query first
    // (Ghostty/cmux, kitty, iTerm answer), then the OSC 11 background color
    // as ground truth — and hot-apply when the answer differs. Both queries
    // time out silently on quiet terminals; the startup resolution stands.
    if (themePreference === 'auto') {
      ui.tui.setTerminalColorSchemeNotifications(true)
      void (async () => {
        const scheme = await ui.tui.queryTerminalColorScheme({ timeoutMs: 200 }).catch(() => undefined)
        if (scheme === 'light' || scheme === 'dark') {
          applyTheme(resolveTheme(process.env, scheme, themeRegistry))
          return
        }
        const background = await ui.tui.queryTerminalBackgroundColor({ timeoutMs: 200 }).catch(() => undefined)
        if (background !== undefined) {
          applyTheme(resolveTheme(process.env, rgbIsLight(background) ? 'light' : 'dark', themeRegistry))
        }
      })()
    }
    // Follow the terminal's live light/dark switches (CSI 997 pushes) while
    // the preference is 'auto' — the terminal flips its OS appearance and the
    // TUI repaints on the next frame, no restart. Explicit pins ignore it.
    const stopTerminalFollow = ui.tui.onTerminalColorSchemeChange(scheme => {
      if (themePreferenceRef !== 'auto') return
      applyTheme(resolveTheme(process.env, scheme, themeRegistry))
    })

    // Live clock: the footer is the only thing that changes each second.
    const clockTimer = setInterval(() => ui.requestRender(), 1000)
    clockTimer.unref?.()

    // Live Todos/Agents widget: spinner + elapsed refresh ~10x/sec while
    // children run (tickLive no-ops when nothing runs).
    const liveTimer = setInterval(() => liveWidgets.tickLive(), AGENT_TICK_MS)
    liveTimer.unref?.()

    /**
     * Modal commands keep an overlay open for as long as the user browses
     * (model/effort pickers, settings browser, session panel, resume list),
     * and plugin flows hold the editor just as long: /wiki onboard parks the
     * user in ask-user panels, /vault backup|restore push over the network.
     * /language rides the same ask-user panel (src/language-ask.ts) — its
     * auto-answer window is minutes, and with the timeouts disabled it waits
     * indefinitely, so the generic guard must not cut it off mid-question.
     * The generic guard would fire mid-flow and echo a spurious
     * "aborted due to timeout" — those run with a never-aborting signal
     * instead.
     *
     * profile-switch/profile-cfg are registered by the external
     * @aiwayds/dsh-profile-switch package, but every plugin command routes
     * through this dispatcher, so their names belong here all the same
     * (dropping them in 2.16.0 re-introduced the timeout).
     */
    const MODAL_COMMANDS = new Set(['settings', 'model', 'think', 'session', 'resume', 'history', 'theme', 'language', 'permission', 'agents', 'subagents', 'login', 'logout', 'skills', 'preset', 'profile-switch', 'profile-cfg', 'wiki', 'vault'])

    /** Route one submitted line: dsh slash command first, model prompt second. */
    const submit = async (text: string): Promise<void> => {
      const line = text.trim()
      if (line === '') return
      const tokens = line.startsWith('/') ? line.slice(1).split(/\s+/) : []
      const name = tokens[0]?.toLowerCase()
      let executeLine = line
      const signal = name !== undefined && MODAL_COMMANDS.has(name)
        ? new AbortController().signal
        : AbortSignal.timeout(90_000)
      // Bare /permission (no arguments) opens the preset picker — UI sugar
      // over dsh's canonical command: a picked row is replayed as
      // `/permission <name>` through the normal execute path below, so the
      // switch stays canonical while the echo keeps the user's original line.
      // `/permission <name>` passes straight through. Without a composed
      // preset service there is nothing to pick and the bare line falls
      // through to the model like any other unregistered command.
      if (name === 'permission' && tokens.length === 1) {
        const presets = ctx.get('permissionPresets')
        if (presets !== undefined) {
          const agent = bridge.getAgent()
          const current = agent === undefined ? undefined : presets.current(agent.session)
          let picked: string | undefined
          try {
            picked = await pickPermission(ctx, ui.tui, ui.theme, current, refocusEditor)
          } catch (error: unknown) {
            // Picker failure (preset service or overlay error) — pickPermission
            // restores focus itself before rejecting, so the editor is usable
            // again; surface the failure in the transcript like every other
            // dispatch error. Buffered notice: this line is the only record of
            // the failure and must survive a theme-switch rebuild (doc.clear()).
            const message = messageOf(error)
            renderer.renderNotice(message, 'error')
            return
          }
          if (picked === undefined || picked === 'custom') {
            // Cancelled — or the derived custom state, which is display-only
            // and not a switch target (mirrors the web client's popup
            // filtering). Either way nothing changed.
            renderer.renderCommandEcho(line, undefined, t('tui.permission.unchanged'))
            return
          }
          executeLine = `/permission ${picked}`
        }
      }
      let command: Awaited<ReturnType<CommandService['tryExecute']>>
      try {
        command = await commands.tryExecute(executeLine, signal)
      } catch (error: unknown) {
        // Dispatch itself failed (outside every contained path) — surface in
        // the transcript instead of an unhandled rejection killing the TUI.
        // Buffered notice: this line is the only record of the failure and
        // must survive a theme-switch rebuild (doc.clear()).
        const message = messageOf(error)
        renderer.renderNotice(message, 'error')
        return
      }
      if (command.handled) {
        renderer.renderCommandEcho(line, command.error, command.text)
        return
      }
      // Submit routing (docs/design-steer-followup.md §二.1): while the agent
      // runs, the dialog decides steer vs follow-up — Esc cancels and the
      // draft goes back into the editor untouched. Idle → direct send (the
      // two primitives are equivalent there: both wake a fresh turn).
      if (decideSubmitPath(bridge.isRunning() && !bridge.isReadOnlyView()) === 'dialog') {
        const route = await openSubmitRouteDialog(ui.tui, ui.theme, text, refocusEditor)
        if (route === undefined) {
          // Review S1: restore the RAW submitted text — restoring the trimmed
          // line used to mangle multi-line drafts (leading/trailing blank
          // lines silently dropped). setText places the cursor at the end of
          // the restored draft; nothing was sent.
          ui.editor.setText(text)
          ui.requestRender()
          return
        }
        deliverRoutedPrompt(text, route)
        return
      }
      // The ` ● last-request` line tracks MODEL prompts only — setting it for
      // slash commands or cancelled dialogs left stale residue below the
      // editor for text that never ran.
      liveWidgets.setLastRequest(line)
      renderer.renderPromptEcho(line)
      const wasWatching = bridge.isReadOnlyView()
      try {
        await bridge.prompt(line)
        if (wasWatching) emitNotice(t('tui.steer.queuedFollowup'))
      } catch (error: unknown) {
        // Buffered notice: the failure line is the only on-screen record and
        // must survive a theme-switch rebuild (doc.clear()).
        const message = messageOf(error)
        renderer.renderNotice(message, 'error')
      }
      // Session (re)created by the prompt: seed the badge cache. The initial
      // permission pin event was likely dropped by the session-id filter,
      // which binds only after agent creation completes.
      refreshPermissionPreset()
    }

    /**
     * Deliver one routed prompt to the LIVE agent with the pending-badge
     * echo (`⏳ queued` / `↪ steer`) and the design's race fallback: the
     * delivery defers out of the await stack into a microtask (SteerInputPanel
     * timing defense), `deliverToAgent` re-checks the driver status at flush
     * time, and every badge reaches a truthful end state — a steer that can
     * no longer land flips its badge to ⏳ queued (review S3), a failed
     * delivery marks the bubble ✘ not delivered instead of leaving a ghost
     * (review B1).
     */
    const deliverRoutedPrompt = (raw: string, route: PromptRoute): void => {
      const agent = bridge.getAgent()
      if (agent === undefined) {
        // Running without a handle cannot deliver — say so instead of
        // dropping the message silently.
        renderer.renderNotice(t('tui.steer.noSession'), 'error')
        return
      }
      const message = buildUserPrompt(raw)
      renderer.renderPendingEcho(raw, route === 'steer' ? 'steer' : 'queued', message.id)
      liveWidgets.setLastRequest(raw)
      queueMicrotask(() => {
        const outcome = deliverToAgent(agent, message, route)
        if (outcome.outcome === 'degraded') {
          renderer.rebadgePendingEcho({ id: message.id }, 'queued')
          renderer.renderNotice(turnEndedQueuedNotice(), 'info')
        } else if (outcome.outcome === 'error') {
          renderer.resolvePendingEcho({ id: message.id }, 'failed')
          renderer.renderNotice(outcome.error, 'error')
        }
        ui.requestRender()
      })
    }

    /**
     * The TUI owns the product lifetime in this profile (openma contract):
     * dispose the agent, then the whole root runtime, then exit. Runs once —
     * concurrent Ctrl+C presses share the single shutdown task.
     */
    let exitTask: Promise<void> | undefined
    const disposeAndExit = async (code: number): Promise<void> => {
      exitTask ??= (async () => {
        clearInterval(clockTimer)
        clearInterval(liveTimer)
        git.dispose()
        // Capture the session id BEFORE the bridge clears it on dispose —
        // the exit hint below prints it once the terminal is back.
        const exitSessionId = bridge.getSessionId()
        try { await bridge.dispose() } catch { /* contained */ }
        ui.dispose()
        setNoticeSink(undefined)
        try { await ctx.root.fiber.dispose() } catch { /* contained */ }
        // pi-style exit hint: the terminal is released (alt-screen exited,
        // cooked mode restored), nothing else prints after the tree's
        // teardown, so the one-line resume recipe is the last thing on
        // screen. Skipped when no session was ever created (nothing to
        // resume) — mirroring pi.
        if (exitSessionId !== undefined) {
          // DIM SGR (not a theme color): the hint prints after the TUI's
          // theme machinery is gone; dim is universally supported.
          process.stdout.write(`\n\x1b[2m${t('tui.exit.resumeHint', { command: formatResumeCommand(resolveProfileName(ctx), String(exitSessionId)) })}\x1b[0m\n`)
        }
        hardExit(code)
      })()
      return exitTask
    }

    return async () => {
      if (relayoutTimer !== undefined) clearTimeout(relayoutTimer)
      process.stdout.removeListener('resize', onResize)
      stopTerminalFollow()
      clearInterval(clockTimer)
      clearInterval(liveTimer)
      git.dispose()
      btwController.dispose()
      applyThemeRef = undefined
      applyPanelHeightRef = undefined
      applyFooterHintsRef = undefined
      // Detach the shared notice sink with this TUI: a producer finishing
      // during teardown must not write into a dead surface (anything it
      // emits afterwards queues for the next registration — a failed
      // /reload rollback re-registers and consumes it once).
      setNoticeSink(undefined)
      // Stop the TUI FIRST, before the (possibly slow) agent teardown: the
      // terminal must be released while the fiber is still alone with it.
      // Deferring tui.stop() until after `await bridge.dispose()` lets any
      // fire-and-forget disposal (e.g. /reload's fiber swap) start a fresh
      // TUI while this one still holds the terminal — the late stop then
      // disables raw mode and pauses stdin out from under the new TUI.
      handle?.dispose()
      handle = undefined
      // Stash the current session BEFORE the bridge clears its sessionId on
      // dispose, so a same-process hot-reload (/reload) can resume it in the
      // fresh fiber. On shutdown the process exits and the stash dies with it
      // (harmless) — only /reload in the same process consumes it.
      stashSessionIdForReload(bridge.getSessionId())
      if (quitConfirmTimer !== undefined) clearTimeout(quitConfirmTimer)
      subagentPolicy.dispose()
      try { await bridge.dispose() } catch { /* contained */ }
    }
  }
}
