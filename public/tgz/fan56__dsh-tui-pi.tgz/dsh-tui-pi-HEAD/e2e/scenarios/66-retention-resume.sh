#!/usr/bin/env bash
# Scenario 66 — retention janitor + /resume display filter + startup config
# summary. Four phases, each a fresh TUI launch then quit_tui:
#
#   A. retention age rule (MAX_AGE_DAYS=2) + startup summary line
#      (mcp/skills/plugins + a profile-root `tui` line under the banner)
#      + the janitor's result surfacing as a transient footer notice.
#   B. disable hatch — MAX_COUNT=0 (the explicit "off" knob) leaves an
#      already-aged session alive (janitor is fully disabled, not just
#      a partial no-op).
#   C. /resume filter defaults — a small stub is hidden by the byte floor,
#      a large enough session surfaces with its preview text and the
#      `Updated` / `Dir` column headers.
#   D. /resume empty-filtered notice — when sessions exist but the window
#      hides them all, the picker reports the explicit "adjust
#      dsh-tui.resume.*" hint instead of the plain "no other sessions"
#      empty-store copy.
set -u
. "$(dirname "$0")/../lib/common.sh"
scenario 'retention janitor + /resume display filter + startup summary'

# --- container-only guard ----------------------------------------------------
# The prep phase below wipes $HOME/.dsh/sessions with `rm -rf`. Inside the
# podman e2e container that path is the disposable fixture store, but on the
# host it is the user's REAL session library — never run this scenario
# outside the container.
if [ ! -d /e2e/scenarios ]; then
  warn 'not running inside the podman e2e container — skipping (prep would wipe $HOME/.dsh/sessions)'
  summary
  exit 0
fi

# --- seeder prerequisite: locate the host's persistence backend entry ----------
# seed_session imports the real `@deepseek-ai/dsh-session-persistence-jsonl`
# backend from the global dsh closure. That closure is installed as one
# `npm install -g @deepseek-ai/dsh` and may land in EITHER layout (see the
# release.yml comment: nested or npm's flat layout), so probe both candidates
# under `npm root -g` in order — first existing wins. Resolution runs BEFORE
# any fixture write/delete on purpose: a silently broken import would turn
# every seed_session into a no-op, and Phase A's `[[ -d ]]` "removed" checks
# would then pass vacuously while only the survivor check errors — a
# misleading "janitor over-deleted" picture for whoever debugs the run.
NPM_GLOBAL_ROOT="$(npm root -g 2>/dev/null || true)"
PERSISTENCE_CANDIDATES=(
  "$NPM_GLOBAL_ROOT/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-session-persistence-jsonl/lib/index.js"
  "$NPM_GLOBAL_ROOT/@deepseek-ai/dsh-session-persistence-jsonl/lib/index.js"
)

# Echo the first existing backend entry path; return 1 when no candidate
# exists (the caller fail-fasts with the full candidate list).
resolve_persistence_entry() {
  local candidate
  for candidate in "${PERSISTENCE_CANDIDATES[@]}"; do
    if [[ -f $candidate ]]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

if ! PERSISTENCE_ENTRY="$(resolve_persistence_entry)"; then
  # Print EVERY candidate by iterating the array — hard-coded [0]/[1] indices
  # would silently hide a third candidate added later. The raw `npm root -g`
  # value goes out too: that probe is `|| true`-guarded, so a failing npm
  # collapses to an empty root and every candidate degenerates to
  # `/@deepseek-ai/...`. Without the raw value that reads as "the global
  # layout moved" when the real fault is "npm root -g did not answer".
  bad 'cannot resolve @deepseek-ai/dsh-session-persistence-jsonl for the seeder'
  info "npm root -g => '$NPM_GLOBAL_ROOT' (empty means the probe itself failed)"
  for candidate in "${PERSISTENCE_CANDIDATES[@]}"; do
    info "  tried: $candidate"
  done
  info 'host global layout changed? update PERSISTENCE_CANDIDATES above'
  summary
  exit 1
fi
info "persistence backend entry (nested-or-flat): $PERSISTENCE_ENTRY"

# --- in-script helper: write a single seeded session directory -----------------
# Layout matches dsh's session-persistence backend:
#   $HOME/.dsh/sessions/<project>/<id>/session.v4.jsonl.zstd
#
# `<project>` is the path-ENCODED cwd (per dsh-session-persistence-jsonl
# `projectKey`): every `/` (and `\`, `:`) becomes `-`, leading `-` runs are
# stripped, and the result is wrapped in `--...--`. Inside the container the
# tmux start dir (-c /app) makes cwd=/app, so the project dir MUST be
# `--app--`. A literal `e2e-proj` would never be discovered by the janitor
# or the /resume walk. `<id>` must be a strict lowercase hex UUID
# (`encodeSegment` passes UUID chars through verbatim, but any non-hex
# character gets `~XXXX`-escaped and the on-disk name would no longer match
# the live id).
#
# The artifact is a real zstd-frame container produced by the actual encoder
# chain of `@deepseek-ai/dsh-session-persistence-jsonl` (two checksummed
# frames: the header record and the event batch). Calling the real encoder —
# not hand-writing JSONL — is what `persistence.list()` expects: a one-line
# `parseHeaderMeta` over the first zstd frame feeds the picker, and the
# janitor / size floor read the on-disk file size from the `meta` revision.
# Through 0.2.0-rc.2 the backend exported its class as `default` and the
# seeder built a stripped instance via `Object.create(...prototype)`. Since
# 0.2.1-rc.2 the module is a cordis PLUGIN (`{ name, Config, apply }`) and the
# class is internal, so the seeder instead ports the backend's ~15-line
# `encodeMaterialization` glue verbatim and keeps the real encoding
# primitives: `sessionFormatCatalog.encodeCurrentHeader` /
# `.encodeCurrentEvent` (from `@deepseek-ai/dsh-session-format-catalog`, a
# direct dependency resolved THROUGH the backend entry so the nested-or-flat
# global layouts both work) plus node:zlib zstd with the backend's exact
# checksum params. That chain is byte-identical across 0.2.0-rc.2 and
# 0.2.1-rc.2 (the backend's own `toHeaderLine`/`eventLine`/
# `encodeMaterialization` call exactly these two catalog functions).
# Filler rows use **unique** per-event random bytes
# (NOT a repeating pattern) — zstd crushes repetition, so a uniform pad
# would never reach the size floor no matter how many events we add; random
# bytes keep the on-disk zstd size near the JSONL body size. The pad loop
# is **bounded by the on-disk file size**: each iteration ENCODES + WRITES +
# STATS, and stops as soon as `stat().size >= targetBytes` (sessions.ts
# reads that stat, never the decompressed body). The final on-disk size
# is logged to stdout for the record.
#
# Host API contract (dsh 0.1.2-alpha.4): the artifact is the unseeded
# materialization — `meta` stays the logical unseeded SessionHeader
# (isSeeded absent) and the inherited event count is 0 (the backend's
# `toHeaderLine` requires cut === 0 for an unseeded header). The encoder
# primitives are resolved at runtime relative to the DYNAMICALLY RESOLVED
# backend entry path (`resolve_persistence_entry` probes `npm root -g` for
# both the nested and npm-flat global layouts) and passed to node as its
# first argument — no hard-coded global closure location.
seed_session() {
  local project="$1" id="$2" preview="$3" size_bytes="${4:-}"
  local dir="$HOME/.dsh/sessions/$project/$id"
  local out="$dir/session.v4.jsonl.zstd"
  mkdir -p "$dir"
  local now_ms
  now_ms="$(date +%s)000"
  local target_bytes="${size_bytes:-0}"
  local final_size
  final_size="$(node --input-type=module - "$PERSISTENCE_ENTRY" "$out" "$id" "$preview" "$now_ms" "$target_bytes" <<'NODE'
import { writeFile, stat } from "node:fs/promises";
import { randomBytes } from "node:crypto";
import { pathToFileURL } from "node:url";
import { createRequire } from "node:module";
import { constants, zstdCompress } from "node:zlib";
import { promisify } from "node:util";

const [entryPath, outPath, id, preview, nowMs, targetBytesStr] = process.argv.slice(2);
const targetBytes = Number(targetBytesStr) || 0;

// Entry path resolved by resolve_persistence_entry() (nested-or-flat global
// layout) and handed over as the first node argument. Since 0.2.1-rc.2 the
// backend module is a plugin (name + Config + apply) with the class
// internal, so the entry serves as the resolution ANCHOR for the format
// catalog — a direct dependency of the backend package in either layout.
// NOTE: this script runs inside a quoted heredoc nested in a command
// substitution, so bash scans every line of it while hunting the closing
// paren: keep parens balanced per statement, no apostrophes and no
// backticks anywhere below (the seed_session prose uses the same rule).
const requireFromBackend = createRequire(entryPath);
const { sessionFormatCatalog } = await import(pathToFileURL(requireFromBackend.resolve("@deepseek-ai/dsh-session-format-catalog")).href);

// Encoder glue ported verbatim from the backend: the catalog encodes the
// header line and every event, and the physical artifact is two zstd frames
// (checksum flag on) concatenated — header, then the event batch. This
// chain is byte-identical through 0.2.0-rc.2 and 0.2.1-rc.2 (the backend
// calls exactly these two catalog functions from its own encoder glue).
const zstdFrame = promisify(zstdCompress);
const CHECKSUM_OPTIONS = { params: { [constants.ZSTD_c_checksumFlag]: 1 } };

function toHeaderLine(meta, inheritedEventCount) {
  const cut = inheritedEventCount ?? 0;
  if (!meta.isSeeded && cut !== 0) {
    throw new Error("unseeded session header inherited event count must be 0");
  }
  return sessionFormatCatalog.encodeCurrentHeader({ ...meta, delegationDepth: meta.delegationDepth ?? 0 }, cut);
}

function eventLines(events) {
  return events.map((event) => JSON.stringify(sessionFormatCatalog.encodeCurrentEvent(event))).join("\n");
}

async function encodeMaterialization(meta, inheritedEventCount, events) {
  const header = JSON.stringify(toHeaderLine(meta, inheritedEventCount)) + "\n";
  if (events.length === 0) return zstdFrame(header, CHECKSUM_OPTIONS);
  const body = eventLines(events) + "\n";
  const headerFrame = await zstdFrame(header, CHECKSUM_OPTIONS);
  const eventFrame = await zstdFrame(body, CHECKSUM_OPTIONS);
  return Buffer.concat([headerFrame, eventFrame]);
}

// dsh 0.1.5-rc.1: the encoder now takes the logical header directly plus
// an inherited-event-count argument, and the header must already stamp
// the current format version. The old storage wrapper object is gone.
// dsh 0.1.7-rc.1: the current Session format version is v4 — encodeCurrent
// refuses any other ("encodeCurrent requires Session format v4").
const meta = {
  version: 4,
  id,
  createdAt: Number(nowMs),
  cwd: "/app",
  delegationDepth: 0,
  // The released V2 and V3 header audit requires the isSeeded key to be
  // present. Absent means legacy format and gets refused.
  isSeeded: false,
};

const events = [
  {
    type: "user/message",
    seq: 0,
    time: Number(nowMs),
    // Two seed-boundary requirements from @deepseek-ai/dsh-session that
    // `list()` never exercises (it reads only the header frame) but
    // `inspect()` enforces via Session.fromRestore replay:
    //   1. surfaceOp — a user/message is surface-eligible and MUST carry the
    //      marker ("session event \"user/message\" is surface-eligible and
    //      requires a surfaceOp marker"); plain "append" is the transcript
    //      origin.
    //   2. message id — the data of a user/message IS the identified message;
    //      assertMessageEventShape rejects it without a non-empty string id
    //      ("session event at seq 0 lacks an identified message").
    surfaceOp: "append",
    data: {
      id: `${id}-m0`,
      content: [{ type: "text", text: preview }],
      source: { kind: "user" },
      role: "user",
    },
  },
];

// Pad with filler rows drawn from the real session-event vocabulary (members
// of KNOWN_SESSION_EVENT_TYPES — confirmed at source level). Random hex `pad`
// keeps the on-disk zstd from crushing below the byte floor. The filler
// rotation spans 4 distinct real event types; each event gets a strictly
// increasing time (+1ms per event) and a strictly sequential seq (the seed
// user/message keeps seq 0). Loop bounds: BATCH=16 events per iteration,
// MAX_ITER=10 iterations — even with very small per-event contributions the
// bounded loop lands the floor before the compression work becomes a wall-
// clock problem. Each iteration ENCODES AND WRITES, then stats the on-disk
// file: that stat is what `sessions.ts` reads (it never decompresses, so the
// on-disk number IS the number the minBytes floor judges).
const BATCH = 16;
const MAX_ITER = 10;
// Filler rows are plain user messages with hex text: the V3 read path runs a
// strict payload audit (unaudited members on knob events like
// permission/preset are REFUSED on read, which would break the preview
// harvest), while audited user/message text is opaque and arbitrary — the
// hex still defeats compression for the byte-floor padding.
let onDisk = 0;
if (targetBytes > 0) {
  for (let iter = 0; iter < MAX_ITER; iter++) {
    const content = await encodeMaterialization(meta, 0, events);
    await writeFile(outPath, content);
    const info = await stat(outPath);
    onDisk = info.size;
    if (onDisk >= targetBytes) break;
    const startSeq = events.length;
    for (let i = 0; i < BATCH; i++) {
      events.push({
        type: "user/message",
        seq: startSeq + i,
        time: Number(nowMs) + startSeq + i,
        surfaceOp: "append",
        data: {
          id: `${id}-p${startSeq + i}`,
          role: "user",
          source: { kind: "user" },
          content: [{ type: "text", text: randomBytes(350).toString("hex") }],
        },
      });
    }
  }
} else {
  const content = await encodeMaterialization(meta, 0, events);
  await writeFile(outPath, content);
  const info = await stat(outPath);
  onDisk = info.size;
}

process.stdout.write(String(onDisk));
NODE
)"
  # Closes the last vacuous-pass channel: the entry file can exist and still
  # break at RUNTIME (host API drift, a throwing import, an encoder signature
  # change). Without this guard the seeder would fail silently, no session dir
  # would ever be written, and Phase A's `[[ -d ]]` "removed" assertions would
  # pass vacuously. Diagnostics go to stderr on purpose — every call site
  # redirects stdout to /dev/null, which would swallow the verdict.
  [[ -n "$final_size" ]] || {
    bad "seeder failed to produce the zstd artifact for $id (check the node stack above) — this is a SEEDER fault, NOT the janitor wrongly removing anything" >&2
    summary >&2
    exit 1
  }
  info "seeded $id: ${final_size} bytes on disk"
}

# --- prep: clean any prior state on the test fixture paths ---------------------
rm -rf "$HOME/.dsh/sessions"
mkdir -p "$HOME/.dsh/sessions"

# =============================================================================
# Phase A — retention age rule + startup config summary
# =============================================================================
scenario 'Phase A: retention MAX_AGE_DAYS=2 + startup summary line'

# Seed 4 doomed-old session dirs (backdated mtime) and 1 fresh survivor.
# Distinct ids so the test is reproducible if the janitor reads them.
PROJ='--app--'
seed_session "$PROJ" a1e2f3a4-0001-4000-8000-00000000aa01 'old aaaa log' >/dev/null
seed_session "$PROJ" a1e2f3a4-0002-4000-8000-00000000aa02 'old bbbb log' >/dev/null
seed_session "$PROJ" a1e2f3a4-0003-4000-8000-00000000aa03 'old cccc log' >/dev/null
seed_session "$PROJ" a1e2f3a4-0004-4000-8000-00000000aa04 'old dddd log' >/dev/null
seed_session "$PROJ" a1e2f3a4-0005-4000-8000-00000000aa05 'fresh survivor' >/dev/null

# Backdate every artifact so the age rule's mtime test sees them as >2 days old.
BACKDATE_TS="$(date -d '-10 days' +%Y%m%d%H%M.%S)"
touch -t "$BACKDATE_TS" \
  "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0001-4000-8000-00000000aa01/session.v4.jsonl.zstd" \
  "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0002-4000-8000-00000000aa02/session.v4.jsonl.zstd" \
  "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0003-4000-8000-00000000aa03/session.v4.jsonl.zstd" \
  "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0004-4000-8000-00000000aa04/session.v4.jsonl.zstd"

# Edge fixtures: a flat file at the sessions root (must NOT be treated as a
# session) and an empty subdir inside the project bucket (must NOT be
# treated as a session).
touch "$HOME/.dsh/sessions/stray-flat.jsonl"
mkdir -p "$HOME/.dsh/sessions/$PROJ/empty-dir"

# Launch with the age rule active. MIN_IDLE_HOURS=0 disables the idle guard
# so a freshly-touched-but-backdated file is still age-eligible for removal.
start_tui 'DSH_TUI_RETENTION_MAX_AGE_DAYS=2 DSH_TUI_RETENTION_MIN_IDLE_HOURS=0'
wait_tui_up 120 || summary

# Retention is fire-and-forget at startup; give it a moment to settle before
# asserting on the filesystem. The janitor's pass is bounded by the file walk,
# which is fast in this fixture size.
sleep 3

if [[ -d "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0001-4000-8000-00000000aa01" ]]; then
  bad 'old-01 dir survived age rule (should be removed)'
else
  ok 'old-01 dir removed by age rule'
fi
if [[ -d "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0002-4000-8000-00000000aa02" ]]; then
  bad 'old-02 dir survived age rule (should be removed)'
else
  ok 'old-02 dir removed by age rule'
fi
if [[ -d "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0003-4000-8000-00000000aa03" ]]; then
  bad 'old-03 dir survived age rule (should be removed)'
else
  ok 'old-03 dir removed by age rule'
fi
if [[ -d "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0004-4000-8000-00000000aa04" ]]; then
  bad 'old-04 dir survived age rule (should be removed)'
else
  ok 'old-04 dir removed by age rule'
fi
if [[ -d "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0005-4000-8000-00000000aa05" ]]; then
  ok 'fresh-05 dir survives age rule (not backdated)'
else
  bad 'fresh-05 dir was wrongly removed'
fi
if [[ -f "$HOME/.dsh/sessions/stray-flat.jsonl" ]]; then
  ok 'flat file at sessions root survives (not a session dir)'
else
  bad 'flat file at sessions root was wrongly removed'
fi
if [[ -d "$HOME/.dsh/sessions/$PROJ/empty-dir" ]]; then
  ok 'empty subdir survives (no session.jsonl inside)'
else
  bad 'empty subdir was wrongly removed'
fi

# --- retention result notice: transient line above the footer -----------------
# The janitor no longer writes raw stderr; its result surfaces once as a
# muted notice above the footer that auto-dismisses after 8s
# (NOTICE_AUTO_DISMISS_MS in src/tui.ts). The pass settled during the sleep
# above, so capture NOW — inside the 8s window — before asserting.
PANE="$(capture)"
assert_contains 'retention result surfaces as a footer notice' \
  'Session retention: removed' "$PANE"
assert_not_contains 'old raw-stderr retention prefix never reaches the pane' \
  'dsh-tui-pi] session retention' "$PANE"

# --- startup summary line: mcp N · skills X/Y · plugins N, plus a `tui` row --
PANE="$(capture)"
assert_matches 'startup summary line shows mcp/skills/plugins counts' \
  'mcp [0-9]+ · skills [0-9]+/[0-9]+ · plugins [0-9]+' "$PANE"
# The profile name itself is a single line ("tui") directly under the banner.
# The banner Text adds paddingX=1, so the captured line carries a leading
# space — anchor on a leading-whitespace + exact "tui" word so a longer
# label like "tui-foo" does not spuriously match.
if printf '%s\n' "$PANE" | grep -qE '^[[:space:]]+tui([[:space:]]|$)'; then
  ok 'startup summary line shows the profile name (tui)'
else
  bad 'profile-name line "tui" missing from startup summary; pane tail:'
  printf '%s\n' "$PANE" | tail -10 | sed 's/^/    | /'
fi

quit_tui 'Phase A quit' || summary

# =============================================================================
# Phase B — disable hatch (MAX_COUNT=0 turns the janitor off)
# =============================================================================
scenario 'Phase B: retention MAX_COUNT=0 disables the janitor'

# Seed another doomed-old dir. With MAX_COUNT=0 the janitor is fully disabled
# so this dir must survive (it would be removed by the age rule from Phase A).
seed_session "$PROJ" a1e2f3a4-0006-4000-8000-00000000aa06 'doomed old log' >/dev/null
touch -t "$BACKDATE_TS" \
  "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0006-4000-8000-00000000aa06/session.v4.jsonl.zstd"

# The test wants MAX_COUNT=0 to be the explicit "off" hatch. Set MIN_IDLE_HOURS
# to 0 too so the (theoretical) age-rule's idle guard does not gate us; the
# whole point of MAX_COUNT=0 is that none of the rules fire at all.
start_tui 'DSH_TUI_RETENTION_MAX_COUNT=0 DSH_TUI_RETENTION_MIN_IDLE_HOURS=0 DSH_TUI_RETENTION_MAX_AGE_DAYS=2'
wait_tui_up 120 || summary

# Give the (disabled) fire-and-forget pass the same time window it would have
# used if it had been enabled. A passing test means the file is still there.
sleep 3

if [[ -d "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0006-4000-8000-00000000aa06" ]]; then
  ok 'doomed-06 dir survives when MAX_COUNT=0 (janitor disabled)'
else
  bad 'doomed-06 dir was removed even with MAX_COUNT=0 (hatch failed)'
fi

quit_tui 'Phase B quit' || summary

# =============================================================================
# Phase C — /resume display filter defaults
# =============================================================================
scenario 'Phase C: /resume surfaces the large session and hides the stub'

# Reset the store so Phase C's filter test is independent of the previous
# janitor state. Seed two sessions under the path-encoded project dir:
#   - alpha  : preview "resume-row-alpha hello world", padded to ≥25KB
#   - stub   : preview "stub tiny log", ~200B (well below the default 1KB floor)
rm -rf "$HOME/.dsh/sessions"
mkdir -p "$HOME/.dsh/sessions"
PROJ='--app--'
seed_session "$PROJ" \
  a1e2f3a4-0007-4000-8000-00000000aa07 \
  'resume-row-alpha hello world' 25000
seed_session "$PROJ" \
  a1e2f3a4-0008-4000-8000-00000000aa08 \
  'stub tiny log'

# Belt-and-braces evidence for the seeded byte sizes: the floor keeps alpha
# only if the on-disk zstd is above 1024B (sessions.ts reads stat().size,
# never the decompressed body). ls -la into stdout so any future debug
# session has the ground truth without re-running the seeder.
ls -la \
  "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0007-4000-8000-00000000aa07/session.v4.jsonl.zstd" \
  "$HOME/.dsh/sessions/$PROJ/a1e2f3a4-0008-4000-8000-00000000aa08/session.v4.jsonl.zstd"

# Plain launch — no retention/resume env. The picker's defaults (30d / 1KB)
# must drop stub (size) and keep alpha.
start_tui ''
wait_tui_up 120 || summary

ensure_editor_ready 'editor focused before /resume' || true
send '/resume' Enter
wait_pane '/resume picker opens' 15 '● Resume session'
PANE="$(capture)"
assert_contains 'picker shows the large session (alpha) row' \
  'resume-row-alpha' "$PANE"
assert_not_contains 'picker hides the stub (size filter)' \
  'stub tiny log' "$PANE"
assert_contains 'picker renders the Updated column header' 'UPDATED' "$PANE"
assert_contains 'picker renders the Dir column header' 'DIR' "$PANE"

esc_until_gone '/resume picker closes on Esc' 'Resume session'
quit_tui 'Phase C quit' || summary

# =============================================================================
# Phase D — empty-filtered notice (sessions exist, window hides them all)
# =============================================================================
scenario 'Phase D: empty-filtered notice vs. plain empty-store copy'

# Same store from Phase C — alpha is large, stub is tiny. With minBytes set
# astronomically high, BOTH get filtered out, so the picker resolves the
# `empty-filtered` branch (not the plain `empty` branch).
start_tui 'DSH_TUI_RESUME_MIN_BYTES=999999999'
wait_tui_up 120 || summary

ensure_editor_ready 'editor focused before /resume (minBytes floor)' || true
send '/resume' Enter
# The empty-filtered notice is a short error text — it may render in the
# picker's empty-state slot OR in the command's error toast, depending on
# the flow. Either way the substring must reach the pane.
wait_pane 'empty-filtered notice appears' 15 'No sessions within the resume window'

PANE="$(capture)"
assert_contains 'empty-filtered notice names the resume window' \
  'No sessions within the resume window' "$PANE"
assert_contains 'empty-filtered notice points at the dsh-tui.resume.* knobs' \
  'adjust dsh-tui.resume.*' "$PANE"
assert_not_contains 'alpha row must not appear under the high minBytes floor' \
  'resume-row-alpha' "$PANE"
assert_not_contains 'must NOT report the plain empty-store copy' \
  'No other persisted sessions to resume.' "$PANE"

esc_until_gone '/resume picker closes on Esc' 'Resume session'
quit_tui 'Phase D quit' || summary

summary
exit 0
