# Slash commands

| Command | What it does |
|---|---|
| `/model` | Two-stage provider/model picker + thinking level; `f` favorite, `h` hide, `/` filter (persisted). |
| `/think` | Reasoning-effort picker (`Off`/`High`/`Max`). |
| `/session` | Read-only info: id, cwd, model, token usage, event count. |
| `/resume` | Pick a persisted session (newest first), validate its log, restore it. |
| `/history` | Read-only two-pane look-back (see [history](history.md)): completed turns on the left, the selected turn's replies on the right; `Enter`/`c` refills the editor with the turn's prompt, `s` swaps sessions, `/history <id>` cold-reads a stored log. |
| `/new` | Detach the current session; the next prompt opens a fresh one. |
| `/btw` | By-the-way side question while the main task runs — one tool-less model call over a recent-conversation snapshot, streamed into a temporary overlay (long answers follow the tail; `↑`/`↓` line-scroll, PgUp/PgDn page). Never kept in the session; idle main line refuses it; `--model provider/model` overrides the route; bare `/btw` reopens the last answer (`DSH_TUI_BTW_CONTEXT_MESSAGES` sizes the snapshot). |
| `/settings` | Text-based settings browser (namespaces, schema walk, secrets masked). |
| `/export` | Write the current session log as JSONL. |
| `/permission` | Permission-preset picker (read-only / workspace-write / danger-full-access). |
| `/theme` | Color-scheme picker (`auto`/`light`/`dark`), applies immediately. |
| `/preset` | Switch the agent preset (`<name>` direct, `next` cycles) — confirmed with a dialog and applied by starting a NEW session on it. |
| `/profile-switch` | *(dsh-profile-switch plugin)* Bind this tree to a model profile via ask-user; live-switches the current session through the TUI bridge. |
| `/profile-cfg` | *(dsh-profile-switch plugin)* Configure profiles (new / edit / save-current / rename / delete) via ask-user. |
| `/agents` | Manage agent markdown files + subagent limits (`maxAgents`, `maxRounds`). |
| `/subagents` | Pick a running/recent subagent and watch its live transcript; `Enter` steers it. |
| `/skills` | Manage user skills (installed and available). |
| `/reload` | Hot-reload the plugin from source after `pnpm build`. |
| `/login` | Log in to a provider (or `/login openai`); **Custom provider…** adds any OpenAI/Anthropic-compatible gateway. |
| `/logout` | Remove a provider's stored key and profile. |
| `/plugins` | Plugin manager: bundle table (`Enter` toggle · `i` install by spec · `d` uninstall behind a confirm · `/` filter); changes report applied / restart-required / failed inline (see [plugins-manager](plugins-manager.md)). |
| `/search` | Cross-session full-text search over every stored session (FTS index): `Enter` opens a hit (resume; `↳` subagent-child hits browse read-only), `n` more, `q` new query (see [search](search-selection-images.md)). Also on `Ctrl+Alt+F` (the chord `Ctrl+Shift+F` stays pi-tui's built-in transcript search). |
| `/hotkeys` | Keybinding browser and live editor. |

Model-list auto-sync for hand-declared (baseURL) providers is no longer a built-in command: the separate `@aiwayds/dsh-model-sync` plugin (a default dependency of this package) keeps those routes' model lists up to date on its own schedule.

Anything else falls through to the model as an ordinary prompt; dsh-native commands (`plan`, `compact`, `feedback`, `goal`, …) work unchanged.

*`/btw` in action — a side question answered in a temporary overlay while the main turn keeps running (the main line never sees it):*

https://github.com/user-attachments/assets/8f9b9754-b860-49be-b6e0-933585f6181d

---

[← Back to README](../../README.md)
