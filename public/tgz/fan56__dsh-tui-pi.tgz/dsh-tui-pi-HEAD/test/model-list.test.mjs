/**
 * /model picker favorites/hidden/filter tests — the pure list assembly
 * (src/model-list.ts), the ListController/TablePanel skip-unselectable and
 * filter-input machinery (src/panels.ts), and the settings read/write
 * wrappers (readModelPrefs/writeModelPref in src/theme-settings.ts, driven
 * through a fake in-memory settings provider — nothing touches
 * ~/.dsh/settings.yaml). Runs against the built lib/ (pnpm build && pnpm test).
 */

import test from 'node:test'
import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import { createVolatile } from '@deepseek-ai/cosmokit'
import {
  buildModelRows,
  canHideModelRow,
  compareListedModels,
  matchesModelFilter,
  modelKey,
  narrowStringList,
  toggleStringList,
} from '../lib/model-list.js'
import { ListController, TablePanel } from '../lib/panels.js'
import {
  bindTuiConfig,
  readModelPrefs,
  resolveTuiSettings,
  THEME_SETTINGS_NAMESPACE,
  writeModelPref,
} from '../lib/theme-settings.js'
import { githubLight } from '../lib/theme/palette.js'

const MODELS = [
  { provider: 'deepseek', id: 'deepseek-chat', name: 'DeepSeek Chat' },
  { provider: 'deepseek', id: 'deepseek-reasoner', name: 'DeepSeek Reasoner' },
  { provider: 'zhipu', id: 'glm-4.7', name: 'GLM-4.7' },
]

const stripAnsi = line => line.replace(/\x1b\[[0-9;]*m/g, '')
/** Minimal theme the panel reads (palette only). */
const theme = { palette: githubLight }

// ------------------------------------------------------------ pure helpers --

test('modelKey composes the provider/id settings key', () => {
  assert.equal(modelKey({ provider: 'deepseek', id: 'deepseek-chat' }), 'deepseek/deepseek-chat')
})

test('toggleStringList appends absent keys in order and removes present ones', () => {
  const added = toggleStringList(['a/b'], 'c/d')
  assert.deepEqual(added, ['a/b', 'c/d'], 'absent key appended (join order)')
  assert.deepEqual(toggleStringList(added, 'a/b'), ['c/d'], 'present key removed')
  const source = ['x']
  toggleStringList(source, 'y')
  assert.deepEqual(source, ['x'], 'input array never mutated')
})

test('narrowStringList keeps only string entries', () => {
  assert.deepEqual(narrowStringList(['a', 42, null, 'b']), ['a', 'b'])
  assert.deepEqual(narrowStringList('nope'), [])
  assert.deepEqual(narrowStringList(undefined), [])
})

test('canHideModelRow: h is refused on a favorite row (unfavorite first, then hide)', () => {
  const [chat, reasoner, glm] = MODELS
  assert.equal(
    canHideModelRow({ kind: 'model', section: 'favorite', model: chat }),
    false,
    'favorite row refuses hide — it would silently persist hiddenModels with no visual feedback',
  )
  assert.equal(canHideModelRow({ kind: 'model', section: 'normal', model: reasoner }), true)
  assert.equal(
    canHideModelRow({ kind: 'model', section: 'hidden', model: glm }),
    true,
    'hidden row still toggles back to visible',
  )
})

test('matchesModelFilter is a case-insensitive substring match on name/id/provider', () => {
  const glm = { provider: 'zhipu', id: 'glm-4.7', name: 'GLM-4.7' }
  assert.equal(matchesModelFilter(glm, ''), true, 'empty query matches everything')
  assert.equal(matchesModelFilter(glm, 'glm'), true)
  assert.equal(matchesModelFilter(glm, 'GLM'), true)
  assert.equal(matchesModelFilter(glm, 'zhipu'), true)
  assert.equal(matchesModelFilter(glm, '4.7'), true)
  assert.equal(matchesModelFilter(glm, 'kimi'), false)
})

test('matchesModelFilter: whitespace-separated keywords AND-match, each token may hit a different field', () => {
  const glm = { provider: 'zhipu', id: 'glm-4.7-flash', name: 'GLM-4.7 Flash' }
  assert.equal(matchesModelFilter(glm, 'glm flash'), true, 'both tokens hit (id/name)')
  assert.equal(matchesModelFilter(glm, 'flash zhipu'), true, 'one token on the name, one on the provider')
  assert.equal(matchesModelFilter(glm, 'GLM FLASH'), true, 'tokens are lower-cased')
  assert.equal(matchesModelFilter(glm, '  glm    flash '), true, 'extra whitespace tolerated')
  assert.equal(matchesModelFilter(glm, 'glm kimi'), false, 'every token must hit somewhere')
  assert.equal(matchesModelFilter(glm, '   '), true, 'whitespace-only query matches everything')
})

test('compareListedModels: provider aggregates first, then the MODEL-column label, id tiebreak', () => {
  const chat = { provider: 'deepseek', id: 'deepseek-chat', name: 'DeepSeek Chat' }
  const glm = { provider: 'zhipu', id: 'glm-4.7', name: 'GLM-4.7' }
  assert.ok(compareListedModels(chat, glm) < 0, 'provider aggregation outranks the label')
  const reasoner = { provider: 'deepseek', id: 'deepseek-reasoner', name: 'DeepSeek Reasoner' }
  assert.ok(compareListedModels(chat, reasoner) < 0, 'label alphabetical within a provider')
  // No hyphens/spaces in these labels: ICU collation orders '-' after ' ',
  // which would entangle the fallback check with punctuation weighting.
  const unnamed = { provider: 'deepseek', id: 'mmmmodel', name: '' }
  const named = { provider: 'deepseek', id: 'zzz', name: 'Chat' }
  assert.ok(compareListedModels(unnamed, named) > 0, 'empty name falls back to the id as the label')
  const tieA = { provider: 'deepseek', id: 'a', name: 'Same Label' }
  const tieB = { provider: 'deepseek', id: 'b', name: 'Same Label' }
  assert.ok(compareListedModels(tieA, tieB) < 0, 'identical labels fall through to the id')
  assert.equal(compareListedModels(chat, chat), 0)
})

// ---------------------------------------------------------- buildModelRows --

test('buildModelRows: favorites → divider → normal → hidden header + hidden models', () => {
  const rows = buildModelRows(MODELS, ['zhipu/glm-4.7'], ['deepseek/deepseek-reasoner'])
  assert.deepEqual(
    rows.map(row => row.kind),
    ['model', 'divider', 'model', 'hiddenHeader', 'model'],
  )
  const [fav, , normal, header, hidden] = rows
  assert.equal(fav.section, 'favorite')
  assert.equal(fav.model.id, 'glm-4.7')
  assert.equal(normal.section, 'normal')
  assert.equal(normal.model.id, 'deepseek-chat')
  assert.equal(header.count, 1)
  assert.equal(hidden.section, 'hidden')
  assert.equal(hidden.model.id, 'deepseek-reasoner')
})

test('buildModelRows: no favorites means no divider row', () => {
  const rows = buildModelRows(MODELS, [], [])
  assert.deepEqual(rows.map(row => row.kind), ['model', 'model', 'model'])
  assert.ok(rows.every(row => row.section === 'normal'))
})

test('buildModelRows: favorites render sorted (join order is persistence-only); stale keys are skipped', () => {
  const rows = buildModelRows(MODELS, ['zhipu/glm-4.7', 'deepseek/deepseek-reasoner', 'ghost/old-model'], [])
  assert.deepEqual(
    rows.filter(row => row.kind === 'model').map(row => row.model.id),
    ['deepseek-reasoner', 'glm-4.7', 'deepseek-chat'],
    'favorites re-sorted by provider/label (not the zhipu-first join order), normal after',
  )
  assert.deepEqual(rows.map(row => row.kind), ['model', 'model', 'divider', 'model'])
})

// Listing order as pickModel collects it: a Promise.all race across
// providers, interleaved by resolve speed.
const JUMBLED = [
  { provider: 'zhipu', id: 'glm-4.7', name: 'GLM-4.7' },
  { provider: 'anthropic', id: 'claude-opus-4', name: 'Claude Opus 4' },
  { provider: 'deepseek', id: 'deepseek-chat', name: 'DeepSeek Chat' },
  { provider: 'anthropic', id: 'claude-haiku-4', name: 'Claude Haiku 4' },
  { provider: 'zhipu', id: 'glm-4.5-air', name: 'GLM-4.5-Air' },
  { provider: 'deepseek', id: 'deepseek-reasoner', name: 'DeepSeek Reasoner' },
]

test('buildModelRows aggregates every section by provider, alphabetical within', () => {
  const rows = buildModelRows(
    JUMBLED,
    ['zhipu/glm-4.7', 'deepseek/deepseek-chat'],
    ['anthropic/claude-opus-4', 'deepseek/deepseek-reasoner'],
  )
  assert.deepEqual(
    rows.map(row =>
      row.kind === 'model' ? `${row.section}:${row.model.provider}/${row.model.id}` : row.kind),
    [
      'favorite:deepseek/deepseek-chat',
      'favorite:zhipu/glm-4.7',
      'divider',
      'normal:anthropic/claude-haiku-4',
      'normal:zhipu/glm-4.5-air',
      'hiddenHeader',
      'hidden:anthropic/claude-opus-4',
      'hidden:deepseek/deepseek-reasoner',
    ],
    'favorite/normal/hidden all provider-grouped alphabetical, not listing order',
  )
  assert.equal(rows.find(row => row.kind === 'hiddenHeader').count, 2)
})

test('buildModelRows: a favorited hidden model appears once, in favorites', () => {
  const rows = buildModelRows(MODELS, ['deepseek/deepseek-reasoner'], ['deepseek/deepseek-reasoner'])
  assert.equal(rows.filter(row => row.kind === 'hiddenHeader').length, 0, 'hidden section empty → dropped')
  assert.deepEqual(
    rows.filter(row => row.kind === 'model').map(row => `${row.section}:${row.model.id}`),
    ['favorite:deepseek-reasoner', 'normal:deepseek-chat', 'normal:glm-4.7'],
  )
})

test('buildModelRows with a filter prunes each section and drops the Hidden section', () => {
  // Filter 'deepseek': favorite + one normal match; the hidden deepseek
  // reasoner must NOT resurface as a Hidden row.
  const rows = buildModelRows(
    MODELS,
    ['deepseek/deepseek-reasoner'],
    ['deepseek/deepseek-reasoner', 'zhipu/glm-4.7'],
    'deepseek',
  )
  assert.deepEqual(
    rows.map(row => row.kind),
    ['model', 'divider', 'model'],
    'pinned structure kept, only matching rows per section, no Hidden section',
  )
  assert.equal(rows[0].section, 'favorite')
  assert.equal(rows[2].section, 'normal')

  // A filter matching only normals drops the divider too (no visible favorites).
  const noFav = buildModelRows(MODELS, ['zhipu/glm-4.7'], [], 'chat')
  assert.deepEqual(noFav.map(row => row.kind), ['model'])

  // An empty-ish (whitespace) filter behaves like no filter.
  assert.deepEqual(buildModelRows(MODELS, [], [], '  ').length, 3)
})

// --------------------------------------------- ListController skip logic --

test('ListController: up/down step over unselectable rows', () => {
  // Row 1 (divider) and row 3 (header) are unselectable.
  const selectableAt = i => i !== 1 && i !== 3
  const c = new ListController(() => 5, 12, selectableAt)
  c.down()
  assert.equal(c.index, 2, 'down from 0 skips the divider at 1')
  c.up()
  assert.equal(c.index, 0, 'up from 2 skips back over the divider')
  c.setIndex(4)
  c.up()
  assert.equal(c.index, 2, 'up from 4 skips the header at 3')
  c.setIndex(0)
  c.up()
  assert.equal(c.index, 0, 'clamped at the top')
  c.setIndex(4)
  c.down()
  assert.equal(c.index, 4, 'clamped at the bottom')
})

test('ListController: pageUp/pageDown land past structural rows onto selectable ones', () => {
  // Rows 0..9, every even row unselectable (dividers).
  const c = new ListController(() => 10, 4, i => i % 2 === 1)
  c.pageDown()
  assert.equal(c.index, 5, 'target 4 is unselectable → snaps to 5 scanning forward')
  c.pageDown()
  assert.equal(c.index, 9, 'clamped to last selectable')
  c.pageUp()
  assert.equal(c.index, 5, 'pageUp target scans backward onto a selectable row')
})

test('ListController: setIndex snaps off an unselectable row; all-unselectable keeps the cursor', () => {
  const c = new ListController(() => 3, 12, i => i !== 2)
  c.setIndex(2)
  assert.equal(c.index, 1, 'snaps upward to the nearest selectable row')
  const stuck = new ListController(() => 3, 12, () => false)
  stuck.setIndex(2)
  assert.equal(stuck.index, 0, 'no selectable row anywhere → cursor stays')
  stuck.down()
  stuck.up()
  assert.equal(stuck.index, 0)
})

// ------------------------------------------------- TablePanel integration --

/** Build a small model table panel with structural rows for render/input tests. */
function makePanel(overrides = {}) {
  const rows = [
    { kind: 'model', section: 'favorite', model: { provider: 'd', id: 'fav', name: 'Favorite One' } },
    { kind: 'divider' },
    { kind: 'model', section: 'normal', model: { provider: 'd', id: 'a', name: 'Model A' } },
    { kind: 'hiddenHeader', count: 1 },
    { kind: 'model', section: 'hidden', model: { provider: 'd', id: 'gone', name: 'Hidden One' } },
  ]
  const options = {
    title: '● Model',
    columns: [
      { key: 'model', title: 'Model', width: 14 },
      { key: 'provider', title: 'Provider', flex: true },
    ],
    rows,
    renderCell: (row, column) =>
      column.key === 'provider'
        ? row.model.provider
        : (row.section === 'favorite' ? `★ ${row.model.name}` : row.model.name),
    isSelectable: row => row.kind === 'model',
    specialRow: (row, width) => {
      if (row.kind === 'divider') return '─'.repeat(Math.max(1, width))
      if (row.kind === 'hiddenHeader') return `─ Hidden (${String(row.count)}) ─`
      return undefined
    },
    dimRow: row => row.kind === 'model' && row.section === 'hidden',
    onSelect: () => {},
    onCancel: () => {},
    ...overrides,
  }
  return { options, panel: new TablePanel(theme, options) }
}

test('TablePanel renders divider/header full-width lines, dim hidden rows, ★ favorites', () => {
  const { panel } = makePanel()
  const lines = panel.render(50).map(stripAnsi)
  const divider = lines.find(line => line.startsWith('  ────') && !line.includes('┬'))
  assert.ok(divider !== undefined, 'full-width ─ divider line rendered')
  assert.ok(lines.some(line => line.includes('─ Hidden (1) ─')), 'dim hidden-section header rendered')
  assert.ok(!lines.some(line => line.includes('▸') && line.includes('Hidden (')), 'header never carries the selection marker')
  assert.ok(lines.some(line => line.includes('★ Favorite One')), 'favorite row shows the ★ prefix')
  assert.ok(lines.some(line => line.includes('Hidden One')), 'hidden model listed under its header')
})

test('TablePanel navigation skips structural rows and Enter selects the cursor model', () => {
  const picked = []
  const { panel } = makePanel({ onSelect: row => picked.push(row.model.id) })
  panel.handleInput('\x1b[B') // down: favorite → normal (skips divider)
  assert.equal(panel.selectedRow().model.id, 'a')
  panel.handleInput('\x1b[B') // down: normal → hidden (skips header)
  assert.equal(panel.selectedRow().model.id, 'gone')
  panel.handleInput('\r') // Enter selects the hidden model directly
  assert.deepEqual(picked, ['gone'])
  panel.handleInput('\x1b[A') // up: hidden → normal (skips header again)
  assert.equal(panel.selectedRow().model.id, 'a')
})

test('TablePanel shortcuts f/h fire outside input mode', () => {
  const calls = []
  const { panel } = makePanel({ shortcuts: { f: () => calls.push('f'), h: () => calls.push('h') } })
  panel.handleInput('f')
  panel.handleInput('H'.toLowerCase())
  assert.deepEqual(calls, ['f', 'h'])
})

test('TablePanel filter mode: / engages, keystrokes bypass shortcuts, Enter applies, Esc clears', () => {
  const MODEL_FOOTER = '↑↓ navigate · Enter select · f favorite · h hide · / filter · Esc back'
  let query = ''
  const shortcutCalls = []
  const { options, panel } = makePanel({
    shortcuts: { f: () => shortcutCalls.push('f') },
    footer: MODEL_FOOTER,
    filter: {
      getQuery: () => query,
      onQueryChange: next => {
        // Caller-style live rebuild: filter the full row set by the new query.
        query = next
        const all = makePanel().options.rows
        options.rows = all.filter(
          row => row.kind !== 'model' || row.model.name.toLowerCase().includes(query),
        )
      },
    },
  })

  panel.handleInput('/') // engage
  panel.handleInput('f') // must accumulate into the query, NOT fire the shortcut
  panel.handleInput('a')
  assert.deepEqual(shortcutCalls, [], 'shortcuts suspended while the input line is engaged')
  assert.equal(query, 'fa')
  let lines = panel.render(60).map(stripAnsi)
  assert.ok(lines.some(line => line.startsWith('Filter: fa_')), 'live query shown while typing')
  assert.ok(!lines.some(line => line.includes('Model A')), 'rows narrowed live by the caller rebuild')
  assert.ok(!lines.some(line => line.includes('Hidden One')), 'hidden section pruned by the filter too')
  assert.ok(lines.some(line => line.includes('★ Favorite One')), 'matching favorite stays pinned with its divider')
  assert.ok(lines.at(-1).includes('Enter apply'), 'footer swaps to the input-mode hints')

  panel.handleInput('\r') // Enter applies and leaves input mode
  lines = panel.render(100).map(stripAnsi)
  assert.ok(lines.some(line => line.startsWith('Filter: fa')), 'applied filter stays visible as a reminder')
  assert.ok(lines.at(-1).includes('Esc'), 'footer back to navigation hints')

  panel.handleInput('\x1b') // Esc clears the applied filter before closing
  assert.equal(query, '', 'Esc cleared the applied filter')
  lines = panel.render(60).map(stripAnsi)
  assert.ok(!lines.some(line => line.startsWith('Filter:')), 'cleared filter line gone')
  assert.ok(lines.some(line => line.includes('Favorite One')), 'full list restored')

  let cancelled = 0
  const closing = makePanel({ onCancel: () => { cancelled++ } }).panel
  closing.handleInput('\x1b')
  assert.equal(cancelled, 1, 'Esc without any filter closes the panel')
})

test('filter query change lands the cursor on the first match, not the stale index', () => {
  // pickModel's rebuild(undefined, true) path: the caller rebuilds rows from
  // the live query and resets the cursor to the top — a bare resync would
  // clamp the stale index (2 → 1, GLM Flash) instead of the first match.
  const models = [
    { provider: 'zhipu', id: 'glm-air', name: 'GLM Air' },
    { provider: 'zhipu', id: 'glm-flash', name: 'GLM Flash' },
    { provider: 'moonshot', id: 'kimi', name: 'Kimi' },
  ]
  let query = ''
  const { options, panel } = makePanel({
    rows: buildModelRows(models, [], []),
    filter: {
      getQuery: () => query,
      onQueryChange: next => {
        query = next
        options.rows = buildModelRows(models, [], [], query)
        if (!panel.focusRow(() => true)) panel.resyncCursor()
      },
    },
  })
  // buildModelRows order: moonshot sorts before zhipu → Kimi, GLM Air, GLM Flash.
  panel.handleInput('\x1b[B')
  panel.handleInput('\x1b[B')
  assert.equal(panel.selectedRow().model.id, 'glm-flash', 'cursor parked on the last row')
  panel.handleInput('/')
  for (const key of 'glm') panel.handleInput(key)
  assert.equal(query, 'glm')
  assert.equal(
    panel.selectedRow()?.model.id,
    'glm-air',
    'cursor reset onto the FIRST match (a bare resyncCursor would clamp to glm-flash)',
  )
})

test('TablePanel focusRow/resyncCursor keep the cursor on a selectable row across rebuilds', () => {
  const { options, panel } = makePanel()
  // Caller-style rebuild: reassign options.rows, then focus the toggled model.
  panel.focusRow(row => row.kind === 'model' && row.model.id === 'gone')
  assert.equal(panel.selectedRow().model.id, 'gone')
  panel.focusRow(row => row.kind === 'model' && row.model.id === 'missing')
  assert.equal(panel.selectedRow().model.id, 'gone', 'unknown target leaves the cursor alone')
  // Swap rows so the cursor lands on a structural row, then resync.
  options.rows = [options.rows[0], { kind: 'divider' }]
  panel.resyncCursor()
  assert.equal(panel.selectedRow().kind, 'model', 'cursor snapped off the divider')
})

test('TablePanel.focusRow reports a miss; the caller fallback resync keeps the cursor alive', () => {
  // Regression (S1): with a filter applied, hiding the cursor row removes it
  // from rows entirely (the Hidden section stays pruned while filtering).
  // focusRow(keepKey) must report the miss so the caller can resyncCursor —
  // otherwise the cursor strands out of range: selectedRow() undefined, no
  // ▸ marker rendered, arrow keys dead.
  const { options, panel } = makePanel()
  options.rows = [
    { kind: 'model', section: 'normal', model: { provider: 'd', id: 'a', name: 'Model A' } },
    { kind: 'model', section: 'normal', model: { provider: 'd', id: 'b', name: 'Model B' } },
  ]
  assert.equal(panel.focusRow(row => row.kind === 'model' && row.model.id === 'a'), true)
  assert.equal(panel.focusRow(row => row.kind === 'model' && row.model.id === 'b'), true)
  assert.equal(panel.selectedRow().model.id, 'b')

  // The h-toggle rebuild: 'b' is hidden and the active filter keeps its row
  // out of the list — focusRow('b') misses now.
  options.rows = [options.rows[0]]
  assert.equal(
    panel.focusRow(row => row.kind === 'model' && row.model.id === 'b'),
    false,
    'vanished row reports a miss instead of silently keeping the stale index',
  )
  panel.resyncCursor() // the caller-side rebuild fallback
  const row = panel.selectedRow()
  assert.ok(row !== undefined && row.kind === 'model', 'cursor re-clamped onto a selectable row')
  assert.equal(row.model.id, 'a')
  assert.ok(
    panel.render(60).map(stripAnsi).some(line => line.includes('▸')),
    'the ▸ selection marker renders again after the fallback',
  )
})

// --------------------------------------------------- settings read/write --

/**
 * Fake of the settings-service surface (same shape as theme-settings.test.mjs):
 * a mutate applies the path ops AND swaps the volatile references — the
 * loader's volatile-only commit — so the read/write round trip is driven
 * without a loader.
 */
function makeHarness(ctx) {
  const section = {}
  let revision = 0
  return {
    describe() {
      return [{ ns: THEME_SETTINGS_NAMESPACE, revision, value: section, user: undefined }]
    },
    async mutate(ns, ops) {
      for (const op of ops) {
        if (op.op === 'set') section[op.path[0]] = op.value
        if (op.op === 'unset') delete section[op.path[0]]
      }
      revision += 1
      bindTuiConfig(configFrom(section))
      ctx.emit('settings/document-updated', ns, revision)
      return undefined
    },
  }
}

/** Volatile references over the committed section (defaults fill the rest). */
function configFrom(section) {
  const base = resolveTuiSettings({})
  const out = {}
  for (const [key, ref] of Object.entries(base)) {
    out[key] = key in section ? createVolatile(section[key]) : ref
  }
  return out
}

test('readModelPrefs defaults to empty lists and writeModelPref round-trips via mutate', async () => {
  const ctx = new Context()
  bindTuiConfig(resolveTuiSettings({}))
  const settings = makeHarness(ctx)
  ctx.provide('settings', settings)

  assert.deepEqual(await readModelPrefs(ctx), { favoriteModels: [], hiddenModels: [] })

  assert.equal(await writeModelPref(ctx, 'favoriteModels', ['zhipu/glm-4.7', 'd/a']), undefined)
  assert.equal(await writeModelPref(ctx, 'hiddenModels', ['d/gone']), undefined)
  assert.deepEqual(await readModelPrefs(ctx), {
    favoriteModels: ['zhipu/glm-4.7', 'd/a'],
    hiddenModels: ['d/gone'],
  })

  // The write landed as an entry path mutation, not a whole-file rewrite.
  const section = settings.describe().find(d => d.ns === THEME_SETTINGS_NAMESPACE).value
  assert.deepEqual(section.favoriteModels, ['zhipu/glm-4.7', 'd/a'])
})

test('readModelPrefs narrows malformed values; settings-less deployments degrade', async () => {
  const ctx = new Context()
  bindTuiConfig(resolveTuiSettings({}))
  const settings = makeHarness(ctx)
  ctx.provide('settings', settings)

  await settings.mutate(THEME_SETTINGS_NAMESPACE, [
    { op: 'set', path: ['favoriteModels'], value: ['ok', 42, null, {}, 'also-ok'] },
    { op: 'set', path: ['hiddenModels'], value: 'garbage' },
  ])
  assert.deepEqual(await readModelPrefs(ctx), { favoriteModels: ['ok', 'also-ok'], hiddenModels: [] })

  await settings.mutate(THEME_SETTINGS_NAMESPACE, [{ op: 'unset', path: ['favoriteModels'] }])
  assert.deepEqual((await readModelPrefs(ctx)).favoriteModels, [])

  // No bound entry config: reads degrade empty; no settings service: writes
  // report instead of throwing.
  const bare = new Context()
  bindTuiConfig(undefined)
  assert.deepEqual(await readModelPrefs(bare), { favoriteModels: [], hiddenModels: [] })
  assert.equal(
    await writeModelPref(bare, 'favoriteModels', ['d/a']),
    'Settings service is not available.',
  )
})
