/**
 * Session preview logic lock — /resume rows are labelled with the session's
 * first-message preview so sessions are distinguishable at a glance. Runs
 * against the built lib/ (npm run build && npm test).
 */

import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, rm, utimes, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  RESUME_MAX_AGE_DAYS,
  RESUME_MIN_BYTES,
  filterSessionsByLastActivity,
  loadSessionLastUpdates,
  normalizePreview,
  pickPersistedSession,
  previewOfEvents,
  isResumableSessionHeader,
  resolveResumeConfig,
  sessionInfoRows,
  orderSessionsByLastUpdate,
} from '../lib/sessions.js'
import { stashSessionIdForReload, takeStashedSessionId } from '../lib/session.js'
import { resetNoticeBridge, setNoticeSink, takePendingNotices } from '../lib/notice-bridge.js'

/**
 * Run fn with BOTH terminal-output channels captured — console.warn AND the
 * raw process.stderr.write it funnels into — and return every captured
 * chunk. Nothing reaches the terminal while captured.
 */
async function captureTerminalOutput(fn) {
  const chunks = []
  const originalWrite = process.stderr.write
  const originalWarn = console.warn
  process.stderr.write = chunk => { chunks.push(String(chunk)); return true }
  console.warn = (...args) => { chunks.push(args.join(' ') + '\n') }
  try {
    await fn()
  } finally {
    process.stderr.write = originalWrite
    console.warn = originalWarn
  }
  return chunks
}

const userMsg = (text, sourceKind = 'user', extra = {}) => ({
  type: 'user/message',
  seq: 1,
  time: 0,
  data: { role: 'user', source: { kind: sourceKind }, content: [{ type: 'text', text }], ...extra },
})

const assistantMsg = text => ({
  type: 'assistant/message',
  seq: 2,
  time: 0,
  data: { turn: 1, step: 1, message: { role: 'assistant', content: [{ type: 'text', text }] } },
})

test('previewOfEvents returns the first direct human prompt, skipping earlier injects', () => {
  const events = [
    userMsg('<system-reminder>\nworkspace instructions…', 'agent-instructions'),
    userMsg('Current runtime context…', 'plugin'),
    userMsg('帮我改一下 rms-locations 的接口', 'user'),
    userMsg('（后续的人类消息不参与第一句）', 'user'),
  ]
  assert.equal(previewOfEvents(events), '帮我改一下 rms-locations 的接口')
})

test('previewOfEvents ignores tool-result user messages', () => {
  const events = [
    { type: 'user/message', seq: 1, time: 0, data: { role: 'user', source: { kind: 'tool', callId: 'c1' }, content: [{ type: 'tool_result', toolCallId: 'c1' }] } },
    userMsg('真正的问题在这里', 'user'),
  ]
  assert.equal(previewOfEvents(events), '真正的问题在这里')
})

test('previewOfEvents prefers the human prompt over an earlier assistant reply', () => {
  const events = [assistantMsg('我看到了工作区说明。'), userMsg('继续做 geo-service 的 TTL 检查')]
  assert.equal(previewOfEvents(events), '继续做 geo-service 的 TTL 检查')
})

test('previewOfEvents falls back to the first assistant message when only injects exist', () => {
  const events = [userMsg('<system-reminder>…', 'agent-instructions'), assistantMsg('收到，我先检查这几个服务。')]
  assert.equal(previewOfEvents(events), '收到，我先检查这几个服务。')
})

test('previewOfEvents prefers real non-injected user text (goal/cron) over the assistant reply', () => {
  const events = [assistantMsg('收到。'), userMsg('每天分析一次 friction 数据并出报表', 'goal')]
  assert.equal(previewOfEvents(events), '每天分析一次 friction 数据并出报表')
})

test('previewOfEvents returns undefined for logs without messages', () => {
  assert.equal(previewOfEvents([{ type: 'command/run', seq: 0, time: 0, data: {} }]), undefined)
  assert.equal(previewOfEvents([]), undefined)
})

test('normalizePreview collapses whitespace and control chars to one line', () => {
  assert.equal(normalizePreview('  你好呀,\n\n介绍一下 你自己  '), '你好呀, 介绍一下 你自己')
  assert.equal(normalizePreview('a\x00b\tc'), 'a b c')
})

test('normalizePreview clips over-long previews with an ellipsis', () => {
  const long = 'x'.repeat(200)
  const clipped = normalizePreview(long)
  assert.equal(clipped.length, 141)
  assert.ok(clipped.endsWith('…'))
  assert.equal(normalizePreview('短文本'), '短文本')
  // Folded reload stash round-trip (no extra test block): process-global
  // stash holds the current session id across a hot-reload.
  assert.equal(takeStashedSessionId(), undefined)
  assert.equal(takeStashedSessionId(), undefined)
  stashSessionIdForReload('session-a')
  assert.equal(takeStashedSessionId(), 'session-a')
  assert.equal(takeStashedSessionId(), undefined)
  stashSessionIdForReload('session-b')
  stashSessionIdForReload(undefined)
  assert.equal(takeStashedSessionId(), undefined)
  assert.equal(takeStashedSessionId(), undefined)
})


// ---------------------------------------------------------------------------
// /resume filter: `isResumableSessionHeader` excludes every delegated child
// (spawn AND fork-driven — both carry `origin: 'subagent'` +
// `delegationDepth >= 1`); resuming one as the TUI's main conversation would
// misplace it in the recursion budget. Everything else stays resumable.
// The budget test is a VALUE test on purpose — see the persisted-shapes test
// below for why field presence would break /resume entirely.

test('isResumableSessionHeader excludes spawn subagent children', () => {
  assert.equal(isResumableSessionHeader({ origin: 'subagent' }), false)
  assert.equal(isResumableSessionHeader({ origin: 'subagent', delegationDepth: 2 }), false)
})

test('isResumableSessionHeader excludes budget-marked children even without the origin', () => {
  // Defensive shape (current dsh always writes the origin too): a header
  // carrying only a positive budget is still a delegated child.
  assert.equal(isResumableSessionHeader({ delegationDepth: 1, parentSession: 'p' }), false)
})

test('isResumableSessionHeader keeps user-facing forks and root sessions resumable', () => {
  // In-memory `Session.fork` lineage is parentSession + seedLength only — a
  // forked conversation is a real session the user may want to resume.
  assert.equal(isResumableSessionHeader({ parentSession: 'p', seedLength: 2 }), true)
  assert.equal(isResumableSessionHeader({}), true)
})

test('isResumableSessionHeader handles persisted shapes (jsonl round-trip materialises delegationDepth: 0)', () => {
  // Regression guard: the jsonl persistence backend writes
  // `delegationDepth: header.delegationDepth ?? 0` and reads the field back
  // unconditionally, so EVERY header from persistence.list() carries it —
  // non-child sessions as 0. These are the exact shapes observed on disk
  // (590-session survey of ~/.dsh/sessions). A field-presence test
  // (`delegationDepth === undefined`) returns false for all of them and
  // leaves /resume with an empty list.
  const persistedRoot = { delegationDepth: 0 } // top-level conversation
  const persistedUserFork = { parentSession: 'p', seedLength: 112416, delegationDepth: 0 }
  const persistedSpawn = { origin: 'subagent', parentSession: 'p', delegationDepth: 1 }
  const persistedForkChild = { origin: 'subagent', parentSession: 'p', seedLength: 4, delegationDepth: 1 }
  assert.equal(isResumableSessionHeader(persistedRoot), true)
  assert.equal(isResumableSessionHeader(persistedUserFork), true)
  assert.equal(isResumableSessionHeader(persistedSpawn), false)
  assert.equal(isResumableSessionHeader(persistedForkChild), false)
})


// ---------------------------------------------------------------------------
// /session info rows: `sessionInfoRows` is the pure data contract of the
// /session panel's auto table (the FW table language shared with every other
// panel). The panel clips/pads/paints these plain values; here we lock the
// row set, the order and the missing-value fallbacks.

const fullPanelData = {
  id: '12345678-9abc-def0-1234-56789abcdef0',
  cwd: '/tmp/work',
  createdAt: new Date('2026-01-02T03:04:05').getTime(),
  model: 'deepseek/v4-flash',
  effort: 'medium',
  msgCount: 3,
  toolCallCount: 7,
  inputTokens: 100,
  outputTokens: 200,
  cacheReadTokens: 300,
  cacheWriteTokens: 400,
  overallTps: 86.4,
  routes: [
    { route: 'deepseek/deepseek-v4-flash', requests: 2, outputTokens: 12_345, tps: 86.4 },
    { route: 'opencode-go/hy3', requests: 1, outputTokens: 500, tps: undefined },
  ],
  status: 'running',
  eventCount: 42,
  parentSession: 'parent-session-id',
}

test('sessionInfoRows renders every stat in display order with plain values', () => {
  const rows = sessionInfoRows(fullPanelData)
  assert.deepEqual(rows.map(row => row.field), [
    'session', 'cwd', 'created', 'model', 'think', 'status', 'messages',
    'tool calls', 'tok in/out', 'cache r/w', 'speed', 'models', 'events', 'parent',
  ])
  const byField = Object.fromEntries(rows.map(row => [row.field, row.value]))
  assert.equal(byField.session, fullPanelData.id) // full id — the flex VALUE column clips, never hides it
  assert.equal(byField.cwd, '/tmp/work')
  assert.ok(byField.created.length > 0)
  assert.equal(byField.model, 'deepseek/v4-flash')
  assert.equal(byField.think, 'medium')
  assert.equal(byField.status, 'running')
  assert.equal(byField.messages, '3')
  assert.equal(byField['tool calls'], '7')
  assert.equal(byField['tok in/out'], '100 / 200')
  assert.equal(byField['cache r/w'], '300 / 400')
  assert.equal(byField.speed, '86 tok/s')
  assert.equal(byField.models, 'deepseek-v4-flash 2×12.3k 86t/s · hy3 1×500', 'short routes, billed counts, per-model tps')
  assert.equal(byField.events, '42')
})

test('sessionInfoRows falls back to em-dash and clips the parent id to 8 columns', () => {
  const rows = sessionInfoRows({
    ...fullPanelData,
    id: undefined,
    cwd: undefined,
    createdAt: undefined,
    model: undefined,
    effort: undefined,
    overallTps: undefined,
    routes: undefined,
    eventCount: undefined,
    parentSession: 'parent-session-id',
  })
  const byField = Object.fromEntries(rows.map(row => [row.field, row.value]))
  for (const field of ['session', 'cwd', 'created', 'model', 'think', 'speed', 'models', 'events']) {
    assert.equal(byField[field], '—', field)
  }
  assert.equal(byField.parent, 'parent-s') // same short form the /resume rows use
})

// Narrow-width regression (review B1): the panel must clip the plain VALUE
// text BEFORE painting it with ANSI. When the terminal is narrower than the
// content, the MIN_FLEX_WIDTH floor can push the layout past `width`; a
// clip applied to the painted line would cut mid-SGR and leave a dangling
// `\x1b[38;2;` fragment on screen.
test('SessionInfoPanel at narrow width clips plain text before ANSI — no dangling SGR fragment', async () => {
  const { SessionInfoPanel } = await import('../lib/sessions.js')
  const { buildTheme } = await import('../lib/theme/index.js')
  const { githubDark } = await import('../lib/theme/palette.js')
  const theme = buildTheme(githubDark)
  const panel = new SessionInfoPanel(theme, fullPanelData, () => {})
  for (const width of [20, 24, 30, 40, 80]) {
    for (const line of panel.render(width)) {
      // No unterminated SGR: every escape sequence is a complete CSI …m
      assert.doesNotMatch(line, /\x1b\[[0-9;]*(?:$|[^0-9;m])/, `width ${width}: dangling escape in ${JSON.stringify(line)}`)
      // Visible width never exceeds the requested width
      const { visibleWidth } = await import('../lib/text.js')
      assert.ok(visibleWidth(line) <= width, `width ${width}: line too wide (${visibleWidth(line)})`)
    }
  }
})

// Heading scope note (review S2, retired): the old "tokens: current route"
// annotation described a per-route-segment accounting that no longer exists —
// the totals have been session-cumulative since the 0.1.7 cache-hit rework —
// so the heading reads plain. Still one line, no extra row (the panel is
// height-budgeted for a 24-row terminal).
test('SessionInfoPanel title renders the plain session heading', async () => {
  const { SessionInfoPanel } = await import('../lib/sessions.js')
  const { buildTheme } = await import('../lib/theme/index.js')
  const { githubDark } = await import('../lib/theme/palette.js')
  const theme = buildTheme(githubDark)
  const panel = new SessionInfoPanel(theme, fullPanelData, () => {})
  const lines = panel.render(80)
  assert.match(lines[0], /ⓘ session/, 'plain heading, no stale token-scope claim')
  assert.equal(lines.length, 20)
})

// ------------------------------------------------- last-update ordering --

/** Minimal resumable header fixture. */
function headerOf(id, createdAt) {
  return { version: 0, id: { toString: () => id }, sessionId: id, createdAt, cwd: '/tmp' }
}

test('orderSessionsByLastUpdate: mtime wins over createdAt, newest first', () => {
  const old = headerOf('old-but-fresh', 1_000)
  const fresh = headerOf('created-newer', 9_000)
  const stale = headerOf('created-older', 5_000)
  const updates = new Map([
    // created earliest, touched latest → first
    ['old-but-fresh', { mtimeMs: 99_000, size: 4096 }],
    ['created-older', { mtimeMs: 50_000, size: 4096 }],
    // 'created-newer' has no stat → falls back to createdAt 9_000 → last
  ])
  const ordered = orderSessionsByLastUpdate([old, fresh, stale], updates)
  assert.deepEqual(ordered.map(h => h.sessionId), ['old-but-fresh', 'created-older', 'created-newer'])
})

test('orderSessionsByLastUpdate: empty map degrades to createdAt desc with deterministic ties', () => {
  const a = headerOf('a', 100)
  const b = headerOf('b', 200)
  const ordered = orderSessionsByLastUpdate([a, b], new Map())
  assert.deepEqual(ordered.map(h => h.sessionId), ['b', 'a'])
})

test('orderSessionsByLastUpdate: a corrupted (non-finite) stat cannot poison the ordering', () => {
  const a = headerOf('a', 100)
  const b = headerOf('b', 200)
  const updates = new Map([
    // NaN mtime from a corrupted stat must degrade to the header createdAt,
    // never leak NaN into the comparator (a NaN would make sort unstable).
    ['a', { mtimeMs: Number.NaN, size: 4096 }],
    ['b', { mtimeMs: Infinity, size: 4096 }],
  ])
  const ordered = orderSessionsByLastUpdate([a, b], updates)
  assert.deepEqual(ordered.map(h => h.sessionId), ['b', 'a'])
})

test('loadSessionLastUpdates walks <root>/<project>/<session>/session.jsonl mtimes', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-tui-sess-'))
  try {
    const when = (ms) => new Date(ms)
    await mkdir(join(dir, 'proj-a', 'sess-1'), { recursive: true })
    await writeFile(join(dir, 'proj-a', 'sess-1', 'session.jsonl'), 'x'.repeat(2048), 'utf8')
    await utimes(join(dir, 'proj-a', 'sess-1', 'session.jsonl'), when(111), when(111))
    // zstd-compressed sibling naming (raw magic bytes — 4 bytes on disk)
    await mkdir(join(dir, 'proj-b', 'sess-2'), { recursive: true })
    await writeFile(join(dir, 'proj-b', 'sess-2', 'session.jsonl.zstd'), Buffer.from([0x28, 0xb5, 0x2f, 0xfd]))
    await utimes(join(dir, 'proj-b', 'sess-2', 'session.jsonl.zstd'), when(222), when(222))
    // Empty project dir and a plain file must not break the walk.
    await mkdir(join(dir, 'proj-empty'), { recursive: true })
    await writeFile(join(dir, 'stray.txt'), 'x', 'utf8')

    const updates = await loadSessionLastUpdates(dir)
    // One stat per log: mtime AND the compressed on-disk size (byte-exact).
    assert.deepEqual(updates.get('sess-1'), { mtimeMs: 111, size: 2048 })
    assert.deepEqual(updates.get('sess-2'), { mtimeMs: 222, size: 4 })
    assert.equal(updates.size, 2)
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})

test('loadSessionLastUpdates resolves an empty map for a missing root', async () => {
  const updates = await loadSessionLastUpdates(join(tmpdir(), 'dsh-tui-nope-' + Date.now()))
  assert.equal(updates.size, 0)
})

test('loadSessionLastUpdates: raw + zstd coexist → the NEWEST mtime wins and carries its own size', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-tui-dual-'))
  try {
    const when = (ms) => new Date(ms)
    const session = join(dir, 'proj', 'sess-dual')
    await mkdir(session, { recursive: true })
    await writeFile(join(session, 'session.jsonl'), 'x'.repeat(4096), 'utf8')
    await utimes(join(session, 'session.jsonl'), when(100), when(100))
    await writeFile(join(session, 'session.jsonl.zstd'), 'y'.repeat(64), 'utf8')
    await utimes(join(session, 'session.jsonl.zstd'), when(300), when(300))
    const updates = await loadSessionLastUpdates(dir)
    // The compressed sibling is the NEWER log: its mtime AND its size win
    // (same last-activity vocabulary as retention's walk). Break-on-first
    // would have kept the stale raw mtime and hidden the session behind
    // its old sibling.
    assert.deepEqual(updates.get('sess-dual'), { mtimeMs: 300, size: 64 })
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})

test('filter + walk: an active zstd sibling rescues a session whose raw log went stale', async () => {
  // The review's failure shape: raw (8 days idle) + fresh zstd (1 day)
  // coexist — break-on-first keyed the STALE raw mtime and the age filter
  // dropped an actively-written session from /resume. The max-across-both
  // walk keeps it visible.
  const dir = await mkdtemp(join(tmpdir(), 'dsh-tui-rescue-'))
  try {
    const when = (ms) => new Date(ms)
    const NOW2 = 2_000_000_000_000
    const session = join(dir, 'proj', 'rescued')
    await mkdir(session, { recursive: true })
    await writeFile(join(session, 'session.jsonl'), 'x'.repeat(20 * 1024), 'utf8')
    await utimes(join(session, 'session.jsonl'), when(NOW2 - 8 * DAY), when(NOW2 - 8 * DAY))
    await writeFile(join(session, 'session.jsonl.zstd'), 'z'.repeat(20 * 1024), 'utf8')
    await utimes(join(session, 'session.jsonl.zstd'), when(NOW2 - DAY), when(NOW2 - DAY))
    const stats = await loadSessionLastUpdates(dir)
    assert.deepEqual(stats.get('rescued'), { mtimeMs: NOW2 - DAY, size: 20 * 1024 })
    const kept = filterSessionsByLastActivity(
      [headerOf('rescued', 0)],
      stats,
      { maxAgeDays: 30, minBytes: 1024, now: NOW2 },
    )
    assert.deepEqual(kept.map(h => h.sessionId), ['rescued'])
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})

// ------------------------------------------------ resume knob resolution --
// `resolveResumeConfig` is the precedence chain behind the display filter
// above: settings.yaml `dsh-tui.resume.*` (explicit, user layer) > the
// DSH_TUI_RESUME_* environment variables > the defaults. Same chain and
// same warn contract as retention (test/retention.test.mjs).

test('resolveResumeConfig: defaults when the environment is silent', () => {
  assert.deepEqual(resolveResumeConfig({}), { maxAgeDays: RESUME_MAX_AGE_DAYS, minBytes: 1024 })
  // An empty settings section is not an override either.
  assert.deepEqual(resolveResumeConfig({}, {}), {
    maxAgeDays: RESUME_MAX_AGE_DAYS,
    minBytes: RESUME_MIN_BYTES,
  })
})

test('resolveResumeConfig: valid env overrides apply; a 0-byte floor legitimately lifts the size gate', () => {
  assert.deepEqual(
    resolveResumeConfig({
      DSH_TUI_RESUME_MAX_AGE_DAYS: '30',
      DSH_TUI_RESUME_MIN_BYTES: '4096',
    }),
    { maxAgeDays: 30, minBytes: 4096 },
  )
  // minBytes 0 is a legal explicit choice: every walked session passes the
  // size gate (stubs and false starts included).
  assert.deepEqual(resolveResumeConfig({ DSH_TUI_RESUME_MIN_BYTES: '0' }), {
    maxAgeDays: RESUME_MAX_AGE_DAYS,
    minBytes: 0,
  })
})

test('resolveResumeConfig: invalid env values fall back SILENTLY to the defaults', async () => {
  // Non-numeric, empty, fractional bytes, or out of range (age must be
  // > 0 — 0 would empty the picker; bytes must be an integer >= 0). A
  // typo must never silently empty or gut the picker, and env fallbacks
  // never emit anything (only settings do).
  const bad = [
    { DSH_TUI_RESUME_MAX_AGE_DAYS: 'abc' },
    { DSH_TUI_RESUME_MAX_AGE_DAYS: '' },
    { DSH_TUI_RESUME_MAX_AGE_DAYS: '0' },
    { DSH_TUI_RESUME_MAX_AGE_DAYS: '-7' },
    { DSH_TUI_RESUME_MAX_AGE_DAYS: 'one week' },
    { DSH_TUI_RESUME_MIN_BYTES: 'small' },
    { DSH_TUI_RESUME_MIN_BYTES: '-1' },
    { DSH_TUI_RESUME_MIN_BYTES: '' },
    { DSH_TUI_RESUME_MIN_BYTES: '20480.5' },
    { DSH_TUI_RESUME_MIN_BYTES: '-0.5' },
  ]
  resetNoticeBridge()
  try {
    const chunks = await captureTerminalOutput(() => {
      for (const env of bad) {
        assert.deepEqual(
          resolveResumeConfig(env),
          { maxAgeDays: RESUME_MAX_AGE_DAYS, minBytes: RESUME_MIN_BYTES },
          JSON.stringify(env),
        )
      }
    })
    assert.deepEqual(chunks, [], 'env-level fallbacks are silent on every channel')
    assert.deepEqual(takePendingNotices(), [], 'and they emit no notice either')
  } finally {
    resetNoticeBridge()
  }
})

test('resolveResumeConfig: explicit settings outrank env; env outranks defaults', () => {
  // Settings is what the user deliberately persisted — it wins on every
  // knob over the ambient environment.
  assert.deepEqual(
    resolveResumeConfig(
      {
        DSH_TUI_RESUME_MAX_AGE_DAYS: '90',
        DSH_TUI_RESUME_MIN_BYTES: '65536',
      },
      { maxAgeDays: 14, minBytes: 1024 },
    ),
    { maxAgeDays: 14, minBytes: 1024 },
    'settings wins on every knob',
  )
  // No settings section: the env layer governs.
  assert.deepEqual(
    resolveResumeConfig({ DSH_TUI_RESUME_MAX_AGE_DAYS: '90' }, undefined),
    { maxAgeDays: 90, minBytes: RESUME_MIN_BYTES },
  )
  // A partial settings section overrides only the PRESENT fields; the
  // absent one keeps flowing through env → default.
  assert.deepEqual(
    resolveResumeConfig(
      { DSH_TUI_RESUME_MAX_AGE_DAYS: '90', DSH_TUI_RESUME_MIN_BYTES: '65536' },
      { maxAgeDays: 3 },
    ),
    { maxAgeDays: 3, minBytes: 65536 },
  )
})

test('resolveResumeConfig: invalid settings values emit exactly one notice each and fall to the next level', () => {
  resetNoticeBridge()
  const notices = []
  setNoticeSink(message => { notices.push(message) })
  try {
    // Type error and negative byte floor: each present-but-invalid field
    // is rejected with exactly one notice (shared bridge; the sink is
    // registered so delivery is direct), and the chain continues at the
    // env layer.
    const config = resolveResumeConfig(
      {
        DSH_TUI_RESUME_MAX_AGE_DAYS: '21',
        DSH_TUI_RESUME_MIN_BYTES: '8192',
      },
      { maxAgeDays: 'week', minBytes: -1 },
    )
    assert.deepEqual(
      config,
      { maxAgeDays: 21, minBytes: 8192 },
      'invalid settings fell through to env on every knob',
    )
    assert.equal(notices.length, 2, 'one notice per invalid field')
    assert.match(notices[0], /^settings dsh-tui\.resume\.maxAgeDays: invalid value "week" — falling back to environment\/default$/)
    assert.match(notices[1], /dsh-tui\.resume\.minBytes: invalid value -1 —/)

    // Invalid settings with no env either → the defaults (still one
    // notice per field).
    notices.length = 0
    assert.deepEqual(
      resolveResumeConfig({}, { maxAgeDays: Number.NaN, minBytes: 'later' }),
      { maxAgeDays: RESUME_MAX_AGE_DAYS, minBytes: RESUME_MIN_BYTES },
    )
    assert.equal(notices.length, 2)

    // Absent fields never notice; valid values never notice.
    notices.length = 0
    resolveResumeConfig({}, { maxAgeDays: 3, minBytes: undefined })
    assert.deepEqual(notices, [])
  } finally {
    resetNoticeBridge()
  }
})

test('resolveResumeConfig: boundaries — fractional age is a window, byte floor must be an integer >= 0', () => {
  resetNoticeBridge()
  const notices = []
  setNoticeSink(message => { notices.push(message) })
  try {
    // The age window only needs to be a finite number > 0: 0.5 days is a
    // legitimate (aggressive) window.
    assert.deepEqual(resolveResumeConfig({}, { maxAgeDays: 0.5 }), {
      maxAgeDays: 0.5,
      minBytes: RESUME_MIN_BYTES,
    })
    // maxAgeDays 0 would empty the picker — invalid, one notice, default.
    assert.deepEqual(resolveResumeConfig({}, { maxAgeDays: 0 }), {
      maxAgeDays: RESUME_MAX_AGE_DAYS,
      minBytes: RESUME_MIN_BYTES,
    })
    assert.equal(notices.length, 1)
    assert.match(notices[0], /dsh-tui\.resume\.maxAgeDays: invalid value 0 —/)
    notices.length = 0
    // A fractional byte floor is garbage even though positive (a
    // stat().size is integral) — rejected, one notice, default.
    assert.deepEqual(resolveResumeConfig({}, { minBytes: 20480.5 }), {
      maxAgeDays: RESUME_MAX_AGE_DAYS,
      minBytes: RESUME_MIN_BYTES,
    })
    assert.equal(notices.length, 1)
    assert.match(notices[0], /dsh-tui\.resume\.minBytes: invalid value 20480\.5 —/)
    notices.length = 0
    // Integer 0 is the documented "show every walked session" choice —
    // valid, no notice.
    assert.deepEqual(resolveResumeConfig({}, { minBytes: 0 }), {
      maxAgeDays: RESUME_MAX_AGE_DAYS,
      minBytes: 0,
    })
    assert.deepEqual(notices, [])
  } finally {
    resetNoticeBridge()
  }
})

test('resolveResumeConfig: a fractional env MIN_BYTES is invalid env — the floor stays the default boundary', async () => {
  // The env-layer twin of the settings case above: 20480.5 parses finite
  // and positive, so the old env layer accepted it — and because
  // `stat().size` is integral, exactly-20480-byte logs silently failed
  // the floor (20480 < 20480.5). A fractional byte floor is invalid env:
  // silent fall to the default, and the boundary stays inclusive.
  resetNoticeBridge()
  try {
    let config
    const chunks = await captureTerminalOutput(() => {
      config = resolveResumeConfig({ DSH_TUI_RESUME_MIN_BYTES: '20480.5' })
    })
    assert.deepEqual(config, {
      maxAgeDays: RESUME_MAX_AGE_DAYS,
      minBytes: RESUME_MIN_BYTES,
    }, 'fractional env floor falls to the default 1024')
    assert.deepEqual(chunks, [], 'env-level fallbacks are silent on every channel')
    assert.deepEqual(takePendingNotices(), [], 'and they emit no notice either')
    // The resolved default floor keeps its inclusive boundary: exactly
    // 1024B passes, 1023B does not (had 20480.5 won, 'at-min' would
    // have been dropped — the silent bar-raise symptom).
    const now = 2_000_000_000_000
    const headers = [headerOf('at-min', now), headerOf('one-short', now)]
    const stats = new Map([
      ['at-min', { mtimeMs: now, size: 1024 }],
      ['one-short', { mtimeMs: now, size: 1023 }],
    ])
    const kept = filterSessionsByLastActivity(headers, stats, {
      maxAgeDays: config.maxAgeDays,
      minBytes: config.minBytes,
      now,
    })
    assert.deepEqual(kept.map(h => h.sessionId), ['at-min'], 'exactly-1024B logs still pass the default floor')
  } finally {
    resetNoticeBridge()
  }
})

// --------------------------------------------------- /resume display filter --

const DAY = 24 * 60 * 60 * 1000
const NOW = 1_700_000_000_000
const BIG = { mtimeMs: NOW, size: 100 * 1024 }

test('filterSessionsByLastActivity: age boundary — 29d23h kept, exactly 30d kept, 30d+1s dropped', () => {
  const headers = [
    headerOf('almost-30d', NOW),
    headerOf('exactly-30d', NOW),
    headerOf('past-30d', NOW),
  ]
  const stats = new Map([
    ['almost-30d', { ...BIG, mtimeMs: NOW - 30 * DAY + 60 * 60 * 1000 }], // 29d23h
    ['exactly-30d', { ...BIG, mtimeMs: NOW - 30 * DAY }], // boundary survives
    ['past-30d', { ...BIG, mtimeMs: NOW - 30 * DAY - 1000 }], // strictly older
  ])
  const kept = filterSessionsByLastActivity(headers, stats, { maxAgeDays: 30, minBytes: 1024, now: NOW })
  assert.deepEqual(kept.map(h => h.sessionId), ['almost-30d', 'exactly-30d'])
})

test('filterSessionsByLastActivity: size boundary — exactly 1024B kept, 1023B dropped', () => {
  const headers = [headerOf('at-min', NOW), headerOf('one-short', NOW)]
  const stats = new Map([
    ['at-min', { mtimeMs: NOW, size: 1024 }],
    ['one-short', { mtimeMs: NOW, size: 1023 }],
  ])
  const kept = filterSessionsByLastActivity(headers, stats, { maxAgeDays: 30, minBytes: 1024, now: NOW })
  assert.deepEqual(kept.map(h => h.sessionId), ['at-min'])
})

test('filterSessionsByLastActivity: missing stat fails open on size, ages by createdAt', () => {
  const headers = [
    headerOf('unwalked-fresh', NOW - DAY), // no stat, recent createdAt → kept
    headerOf('unwalked-stale', NOW - 31 * DAY), // no stat, old createdAt → dropped
  ]
  const kept = filterSessionsByLastActivity(headers, new Map(), { maxAgeDays: 30, minBytes: 1024, now: NOW })
  assert.deepEqual(kept.map(h => h.sessionId), ['unwalked-fresh'])
})

test('filter + walk integration: sizes and mtimes come from the same stat on disk', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-tui-resume-'))
  try {
    const when = (ms) => new Date(ms)
    const NOW2 = 2_000_000_000_000
    const cases = [
      // [id, mtime, bytes, survives]
      ['fresh-big', NOW2 - DAY, 1024, true], // boundary size + fresh age
      ['fresh-small', NOW2 - DAY, 1023, false], // one byte short
      ['stale-big', NOW2 - 31 * DAY, 1024, false], // past the age window
      ['edge-age', NOW2 - 30 * DAY, 2048, true], // exactly 30d survives
    ]
    for (const [id, mtime, bytes] of cases) {
      await mkdir(join(dir, 'proj', id), { recursive: true })
      await writeFile(join(dir, 'proj', id, 'session.jsonl'), 'x'.repeat(bytes), 'utf8')
      await utimes(join(dir, 'proj', id, 'session.jsonl'), when(mtime), when(mtime))
    }
    const stats = await loadSessionLastUpdates(dir)
    assert.equal(stats.size, cases.length)
    const headers = cases.map(([id]) => headerOf(id, 0))
    const kept = filterSessionsByLastActivity(headers, stats, { maxAgeDays: 30, minBytes: 1024, now: NOW2 })
    assert.deepEqual(
      kept.map(h => h.sessionId),
      cases.filter(c => c[3] === true).map(c => c[0]),
    )
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})

test('filterSessionsByLastActivity: the shipped defaults keep a week-old small session visible', () => {
  // The regression this suite pins: a real short conversation (a handful of
  // commands and replies, ~2KB on disk) from two weeks ago used to vanish
  // from /resume under the old 7d/20KB defaults. The 30d/1KB window must
  // keep it, and an e2e/demo stub (~200B, three weeks old) must stay hidden.
  const headers = [
    headerOf('old-small', NOW),
    headerOf('old-stub', NOW),
  ]
  const stats = new Map([
    ['old-small', { mtimeMs: NOW - 14 * DAY, size: 2048 }], // 14d old, 2KB → kept
    ['old-stub', { mtimeMs: NOW - 21 * DAY, size: 200 }], // 21d old, 200B → hidden
  ])
  const kept = filterSessionsByLastActivity(
    headers,
    stats,
    { maxAgeDays: RESUME_MAX_AGE_DAYS, minBytes: RESUME_MIN_BYTES, now: NOW },
  )
  assert.deepEqual(kept.map(h => h.sessionId), ['old-small'])
})

// ------------------------------------------- picker empty-branch differentiation --
// `pickPersistedSession` must tell the caller WHY the list is empty: a
// store with no other resumable session resolves `empty`, while a store
// the age/size display filter emptied resolves `empty-filtered` with the
// effective knobs — the caller's reply names the window and the
// `dsh-tui.resume.*` knobs instead of "nothing to resume" (src/index.ts).
// Both branches return BEFORE any TUI surface is touched, so the tui and
// theme arguments are dummies here.

/** Minimal ctx fake exposing one fixed `sessionPersistence.list() result. */
function pickerContext(headers) {
  return {
    get(name) {
      return name === 'sessionPersistence'
        ? { list: async () => headers, inspect: async () => { throw new Error('not reached') } }
        : undefined
    },
  }
}

/** Pin $DSH_SESSION_ROOT at a temp store for one picker test body. */
async function withSessionRoot(fn) {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-tui-pick-'))
  const prev = process.env.DSH_SESSION_ROOT
  process.env.DSH_SESSION_ROOT = dir
  try {
    await fn(dir)
  } finally {
    if (prev === undefined) delete process.env.DSH_SESSION_ROOT
    else process.env.DSH_SESSION_ROOT = prev
    await rm(dir, { recursive: true, force: true })
  }
}

test('pickPersistedSession: an empty store resolves plain empty — nothing filtered, no TUI touched', async () => {
  await withSessionRoot(async () => {
    // No persisted session at all.
    assert.deepEqual(
      await pickPersistedSession(pickerContext([]), null, null, undefined, () => {}),
      { kind: 'empty' },
      'no other session → plain empty',
    )
    // The only persisted session IS the current one (excluded upstream of
    // the filter): still a plain empty, not a filtered one.
    assert.deepEqual(
      await pickPersistedSession(pickerContext([headerOf('current', 1)]), null, null, 'current', () => {}),
      { kind: 'empty' },
      'only the excluded current session → plain empty',
    )
  })
})

test('pickPersistedSession: candidates hidden by the filter resolve empty-filtered with the effective knobs', async () => {
  await withSessionRoot(async (dir) => {
    // One resumable session whose log is 100 days idle and comfortably
    // above the byte floor: inside the store, outside every window tried
    // below — the branch is genuinely the display filter's.
    const when = ms => new Date(ms)
    const session = join(dir, 'proj', 'stale')
    await mkdir(session, { recursive: true })
    await writeFile(join(session, 'session.jsonl'), 'x'.repeat(50 * 1024), 'utf8')
    const old = Date.now() - 100 * DAY
    await utimes(join(session, 'session.jsonl'), when(old), when(old))

    // Default knobs (7d / 20KB): the age window hid the only candidate.
    assert.deepEqual(
      await pickPersistedSession(pickerContext([headerOf('stale', 0)]), null, null, undefined, () => {}),
      {
        kind: 'empty-filtered',
        hidden: 1,
        maxAgeDays: RESUME_MAX_AGE_DAYS,
        minBytes: RESUME_MIN_BYTES,
      },
      'the age window hid the only candidate — knobs ride along',
    )

    // Explicit settings knobs are the ones reported (still filtered:
    // 100d idle > the 90d window) — the caller's reply names the window
    // that is actually in force.
    assert.deepEqual(
      await pickPersistedSession(
        pickerContext([headerOf('stale', 0)]), null, null, undefined, () => {},
        { maxAgeDays: 90 },
      ),
      { kind: 'empty-filtered', hidden: 1, maxAgeDays: 90, minBytes: RESUME_MIN_BYTES },
      'explicit settings knobs are the ones reported',
    )
  })
})

// ---------------------------------------------------------------------------
// /session rename: the panel's `r` edit writes through the caller's rename
// fn (the host session-title seam). The panel owns the edit state machine —
// `r` enters, printable keys accumulate, backspace erases, Enter commits,
// Esc cancels back to the table, a second Esc closes — all inside the
// panel's fixed 20-row budget (the input line REPLACES the hint line).

async function renameHarness(extraData = {}, rename = undefined) {
  const { SessionInfoPanel } = await import('../lib/sessions.js')
  const { buildTheme } = await import('../lib/theme/index.js')
  const { githubDark } = await import('../lib/theme/palette.js')
  const theme = buildTheme(githubDark)
  const calls = []
  const onClose = () => { calls.push('close') }
  const onRename = rename === undefined
    ? undefined
    : title => {
        calls.push(['rename', title])
        const outcome = rename(title)
        if (!(outcome instanceof Error)) return outcome
        throw outcome
      }
  const panel = new SessionInfoPanel(
    theme,
    { ...fullPanelData, canRename: onRename !== undefined, title: undefined, ...extraData },
    onClose,
    onRename,
  )
  return { panel, calls }
}

test('SessionInfoPanel shows the title on the heading line at the same 20 rows', async () => {
  const { panel } = await renameHarness({ title: 'ledger audit' })
  const lines = panel.render(80)
  assert.equal(lines.length, 20, 'the title rides the heading — no extra row')
  assert.match(lines[0], /ledger audit/, 'heading carries the title')
  assert.match(lines[0], /tokens: current route/, 'scope note survives')
})

test('SessionInfoPanel hint offers rename only when canRename is wired', async () => {
  const wired = (await renameHarness({}, () => ({ ok: true, note: 'ok' }))).panel.render(80).at(-1)
  assert.match(wired, /r rename/, 'wired panel advertises `r`')
  const bare = (await renameHarness({ canRename: false }, undefined)).panel
  assert.doesNotMatch(bare.render(80).at(-1), /r rename/, 'read-only panel keeps the plain hint')
})

test('SessionInfoPanel rename: r opens the edit, typing accumulates, Enter commits', async () => {
  const { panel, calls } = await renameHarness({}, title => ({ ok: true, note: `renamed to "${title}"`, title }))
  panel.handleInput('r')
  assert.doesNotMatch(panel.render(80).at(-1), /Esc to close/, 'edit mode replaces the hint line')
  for (const ch of 'weekly sync') panel.handleInput(ch)
  panel.handleInput('\x7f') // backspace: 'weekly syn'
  panel.handleInput('\r') // commit
  assert.deepEqual(calls.flat(), ['rename', 'weekly syn'], 'the edited buffer reaches the rename fn')
  const lines = panel.render(80)
  assert.match(lines[0], /weekly syn/, 'heading shows the accepted title')
  assert.match(lines.at(-1), /✓/, 'success note on the hint line')
})

test('SessionInfoPanel rename: paste-tolerant input (CJK chunk lands whole)', async () => {
  const { panel, calls } = await renameHarness({}, title => ({ ok: true, note: 'ok', title }))
  panel.handleInput('r')
  panel.handleInput('周会纪要') // one IME/paste chunk, not per-key
  panel.handleInput('\r')
  assert.deepEqual(calls, [['rename', '周会纪要']])
})

test('SessionInfoPanel rename: empty commit fails in place, Esc cancels back, second Esc closes', async () => {
  const { panel, calls } = await renameHarness({}, () => ({ ok: true, note: 'ok' }))
  panel.handleInput('r')
  panel.handleInput('\r') // empty buffer → refused, edit stays open
  assert.match(panel.render(80).at(-1), /✗/, 'failure note in the edit line')
  assert.deepEqual(calls, [], 'the rename fn never saw the empty buffer')
  panel.handleInput('x')
  assert.doesNotMatch(panel.render(80).at(-1), /✗/, 'a keypress clears the failure note')
  panel.handleInput('\x1b') // cancel → view mode, panel still open
  assert.match(panel.render(80).at(-1), /r rename/, 'back in view mode')
  panel.handleInput('\x1b') // second Esc closes
  assert.deepEqual(calls, ['close'])
})

test('SessionInfoPanel rename: a thrown rename keeps the edit open with the error', async () => {
  const { panel, calls } = await renameHarness(
    {},
    () => new Error('service disposed'),
  )
  panel.handleInput('r')
  panel.handleInput('x')
  panel.handleInput('\r')
  assert.equal(calls.length, 1, 'the rename fn ran')
  const last = panel.render(80).at(-1)
  assert.match(last, /✗/, 'failure note')
  assert.match(last, /service disposed/, 'the error message rides the note')
  // The buffer survives so the user can retry after fixing the cause.
  panel.handleInput('\r')
  assert.equal(calls.length, 2, 'retry commits the same buffer')
})

test('SessionInfoPanel ignores r when the rename seam is absent', async () => {
  const { panel, calls } = await renameHarness({ canRename: false })
  panel.handleInput('r') // no-op: falls through the key map
  assert.doesNotMatch(panel.render(80).at(-1), /rename ▸/, 'no edit mode')
  panel.handleInput('\x1b')
  assert.deepEqual(calls, ['close'], 'Esc still closes the read-only panel')
})
