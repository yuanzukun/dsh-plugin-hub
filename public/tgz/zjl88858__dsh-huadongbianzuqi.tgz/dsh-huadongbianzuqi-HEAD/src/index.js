/** Host entry for the browser-only 滑动变祖器 plugin. */
export function apply() {}
