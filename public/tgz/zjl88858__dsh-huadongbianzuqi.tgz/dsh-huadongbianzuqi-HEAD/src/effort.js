const DISPLAY_NAMES = Object.freeze({
  none: '牢梁',
  off: '牢梁',
  high: '梁子',
  max: '梁圣',
})

/** Return the UI-only name for an adapter-owned effort. */
export function effortDisplayName(effort) {
  return DISPLAY_NAMES[effort.id] ?? effort.name
}

/** Build a selection while preserving the adapter-owned effort id verbatim. */
export function selectionWithEffort(current, effortId) {
  return {
    provider: current.provider,
    model: current.model,
    reasoningEffort: effortId,
  }
}

/** Build the selection represented by one advertised model row. */
export function selectionForModel(group, model) {
  return {
    provider: group.id,
    model: model.id,
  }
}
