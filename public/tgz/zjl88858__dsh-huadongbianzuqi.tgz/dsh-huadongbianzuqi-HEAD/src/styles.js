export const styles = String.raw`
.hbz-root {
  position: relative;
  min-width: 0;
}

.hbz-trigger {
  display: flex;
  align-items: center;
  gap: 4px;
  min-width: 0;
  max-width: 240px;
  height: 28px;
  padding: 0 5px 0 8px;
  border: 0;
  border-radius: 24px;
  outline: none;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  font: inherit;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  cursor: pointer;
}

.hbz-trigger-avatar {
  flex: 0 0 auto;
  width: 24px;
  height: 24px;
  border: 1px solid var(--dsw-alias-state-business-primary);
  border-radius: 50%;
  object-fit: cover;
}

.hbz-trigger:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover);
}

.hbz-trigger:focus-visible {
  box-shadow: 0 0 0 2px var(--dsw-alias-border-l3);
}

.hbz-trigger:disabled {
  color: var(--dsw-alias-label-dimmed);
  cursor: default;
}

.hbz-model-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.hbz-effort-name,
.hbz-chevron {
  flex: 0 0 auto;
  color: var(--dsw-alias-label-caption);
}

.hbz-chevron {
  width: 14px;
  height: 14px;
  transition: transform 120ms ease;
}

.hbz-chevron-open {
  transform: rotate(180deg);
}

.hbz-panel {
  position: absolute;
  right: 0;
  bottom: calc(100% + 8px);
  z-index: 20;
  box-sizing: border-box;
  width: min(500px, calc(100vw - 24px));
  padding: 16px 18px 18px;
  overflow: hidden;
  border: 1px solid rgba(98, 166, 255, 0.28);
  border-radius: 20px;
  background:
    radial-gradient(circle at 50% -30%, rgba(31, 122, 211, 0.34), transparent 54%),
    linear-gradient(155deg, rgb(17, 29, 45), rgb(7, 14, 25) 72%);
  box-shadow: 0 18px 46px rgba(0, 0, 0, 0.34), inset 0 1px rgba(255, 255, 255, 0.08);
  color: rgb(235, 244, 255);
}

.hbz-model-row {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: 14px;
  padding-bottom: 15px;
  border-bottom: 1px solid rgba(124, 172, 229, 0.14);
  color: rgba(201, 220, 242, 0.66);
  font-size: 13px;
  line-height: 20px;
}

.hbz-model-select {
  min-width: 0;
  height: 36px;
  padding: 0 30px 0 12px;
  border: 1px solid rgba(129, 178, 235, 0.24);
  border-radius: 9px;
  outline: none;
  background: rgba(166, 198, 233, 0.09);
  color: rgb(235, 244, 255);
  font: inherit;
  font-size: 14px;
  text-overflow: ellipsis;
}

.hbz-model-select:focus-visible {
  box-shadow: 0 0 0 2px rgba(47, 161, 255, 0.42);
}

.hbz-slider-section {
  padding-top: 16px;
}

.hbz-heading {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
}

.hbz-title {
  display: block;
  color: rgb(235, 244, 255);
  font-size: 17px;
  line-height: 22px;
  font-weight: 650;
  letter-spacing: 0.08em;
}

.hbz-kicker {
  display: block;
  margin-top: 1px;
  color: rgba(103, 182, 255, 0.62);
  font-size: 9px;
  line-height: 12px;
  letter-spacing: 0.24em;
}

.hbz-current {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 4px 11px;
  border: 1px solid rgba(49, 167, 255, 0.32);
  border-radius: 999px;
  background: rgba(21, 128, 219, 0.12);
  color: rgb(89, 188, 255);
  font-size: 14px;
  line-height: 20px;
  font-weight: 600;
}

.hbz-current i {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: rgb(42, 174, 255);
  box-shadow: 0 0 8px rgb(42, 174, 255);
}

.hbz-machine {
  position: relative;
  height: 178px;
  margin: 0 -2px;
  border: 1px solid rgba(119, 167, 221, 0.18);
  border-radius: 12px;
  background:
    linear-gradient(180deg, rgba(218, 234, 249, 0.1), transparent 24%),
    repeating-linear-gradient(90deg, rgba(85, 161, 224, 0.025) 0 1px, transparent 1px 18px),
    rgba(5, 13, 23, 0.7);
  box-shadow: inset 0 0 22px rgba(0, 0, 0, 0.46);
}

.hbz-ruler {
  position: absolute;
  top: 10px;
  right: 58px;
  left: 58px;
  height: 32px;
  border-top: 1px solid rgba(184, 214, 242, 0.22);
  background:
    repeating-linear-gradient(90deg, rgba(202, 226, 247, 0.48) 0 1px, transparent 1px 11px) top / 100% 11px no-repeat,
    repeating-linear-gradient(90deg, rgba(202, 226, 247, 0.72) 0 1px, transparent 1px 55px) top / 100% 19px no-repeat;
  opacity: 0.74;
}

.hbz-rail {
  position: absolute;
  top: 78px;
  right: 46px;
  left: 46px;
  height: 13px;
  border: 1px solid rgba(216, 235, 255, 0.76);
  border-radius: 999px;
  background: linear-gradient(180deg, rgb(242, 249, 255), rgb(94, 119, 146) 38%, rgb(20, 35, 52) 56%, rgb(184, 207, 230));
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.66), 0 0 12px rgba(60, 160, 244, 0.18);
}

.hbz-rail-cap {
  position: absolute;
  top: 50%;
  width: 20px;
  height: 42px;
  border: 1px solid rgba(220, 237, 255, 0.5);
  border-radius: 5px;
  background: linear-gradient(90deg, rgb(43, 60, 80), rgb(191, 211, 230) 43%, rgb(50, 72, 96));
  box-shadow: inset 0 0 0 2px rgba(5, 12, 20, 0.44), 0 2px 5px rgba(0, 0, 0, 0.7);
  transform: translateY(-50%);
}

.hbz-rail-cap-left {
  left: -10px;
}

.hbz-rail-cap-right {
  right: -10px;
}

.hbz-knob {
  position: absolute;
  top: 29px;
  left: var(--hbz-knob-left);
  z-index: 3;
  box-sizing: border-box;
  width: 108px;
  height: 108px;
  padding: 7px;
  border: 1px solid rgba(223, 240, 255, 0.7);
  border-radius: 50%;
  background: conic-gradient(from 18deg, rgb(39, 58, 78), rgb(219, 235, 248), rgb(49, 70, 93), rgb(174, 201, 225), rgb(39, 58, 78));
  box-shadow: 0 6px 13px rgba(0, 0, 0, 0.64), 0 0 16px rgba(38, 159, 255, 0.46);
  transform: translateX(-50%);
  transition: left 180ms cubic-bezier(0.2, 0.8, 0.2, 1);
}

.hbz-knob-ring {
  display: block;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  padding: 4px;
  border: 3px solid rgb(47, 177, 255);
  border-radius: 50%;
  background: rgb(5, 19, 31);
  box-shadow: inset 0 0 8px rgb(37, 162, 255), 0 0 7px rgb(37, 162, 255);
}

.hbz-knob img {
  display: block;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
}

.hbz-range {
  position: absolute;
  top: 29px;
  right: 4px;
  left: 4px;
  z-index: 4;
  width: calc(100% - 8px);
  height: 108px;
  margin: 0;
  appearance: none;
  -webkit-appearance: none;
  border: 0;
  outline: none;
  background: transparent;
  cursor: pointer;
}

.hbz-range::-webkit-slider-runnable-track {
  height: 13px;
  background: transparent;
}

.hbz-range::-webkit-slider-thumb {
  width: 108px;
  height: 108px;
  margin-top: -47.5px;
  appearance: none;
  -webkit-appearance: none;
  border: 0;
  border-radius: 50%;
  background: transparent;
}

.hbz-range::-moz-range-track {
  height: 13px;
  background: transparent;
}

.hbz-range::-moz-range-thumb {
  width: 108px;
  height: 108px;
  border: 0;
  border-radius: 50%;
  background: transparent;
}

.hbz-range:focus-visible + .hbz-stations::before {
  opacity: 1;
}

.hbz-stations {
  position: absolute;
  right: 58px;
  bottom: 11px;
  left: 58px;
  height: 25px;
  pointer-events: none;
}

.hbz-stations::before {
  position: absolute;
  inset: -105px -7px -3px;
  border: 1px solid rgba(65, 177, 255, 0.56);
  border-radius: 11px;
  box-shadow: 0 0 0 2px rgba(36, 149, 240, 0.11);
  content: '';
  opacity: 0;
  transition: opacity 120ms ease;
}

.hbz-station {
  position: absolute;
  width: 72px;
  color: rgba(197, 216, 236, 0.66);
  font-size: 13px;
  line-height: 20px;
  text-align: center;
  transform: translateX(-50%);
  transition: color 160ms ease, text-shadow 160ms ease;
}

.hbz-station::before {
  position: absolute;
  top: -7px;
  left: 50%;
  width: 1px;
  height: 5px;
  background: rgba(197, 220, 242, 0.38);
  content: '';
}

.hbz-station-active {
  color: rgb(78, 187, 255);
  font-weight: 600;
  text-shadow: 0 0 10px rgba(43, 167, 255, 0.7);
}

.hbz-console {
  display: grid;
  grid-template-columns: 8px 1fr auto;
  align-items: center;
  gap: 8px;
  height: 34px;
  margin-top: 10px;
  padding: 0 13px;
  border: 1px solid rgba(97, 164, 220, 0.2);
  border-radius: 7px;
  background: linear-gradient(180deg, rgba(87, 130, 169, 0.13), rgba(1, 7, 13, 0.66));
  color: rgba(85, 187, 242, 0.7);
  font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
  font-size: 9px;
  line-height: 13px;
  letter-spacing: 0.22em;
}

.hbz-console strong {
  color: rgb(92, 196, 255);
  font-family: inherit;
  font-size: 13px;
  letter-spacing: 0.12em;
}

.hbz-console-light {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: rgb(43, 182, 255);
  box-shadow: 0 0 8px rgb(43, 182, 255);
}

.hbz-status {
  padding: 8px 0 2px;
  color: var(--dsw-alias-label-tertiary);
  font-size: 12px;
  line-height: 18px;
}

.hbz-error {
  margin-top: 10px;
  padding: 7px 8px;
  border-radius: 8px;
  background: var(--dsw-alias-interactive-bg-hover-danger);
  color: var(--dsw-alias-state-error-primary);
  font-size: 12px;
  line-height: 18px;
}

@media (prefers-reduced-motion: reduce) {
  .hbz-chevron,
  .hbz-knob,
  .hbz-station,
  .hbz-stations::before {
    transition: none;
  }
}
`
