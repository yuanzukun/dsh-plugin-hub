import * as React from 'react'
import {
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react'
import {
  effortDisplayName,
  selectionForModel,
  selectionWithEffort,
} from './effort.js'
import { styles } from './styles.js'

export const inject = ['modelDirectories', 'sessions', 'slots']

const AVATARS = [__HBZ_AVATAR_1__, __HBZ_AVATAR_2__, __HBZ_AVATAR_3__]

function avatarFor(effort, index) {
  const mapped = { none: 0, off: 0, high: 1, max: 2 }[effort?.id]
  return AVATARS[mapped ?? Math.min(index, AVATARS.length - 1)]
}

function Chevron({ open }) {
  return (
    <svg
      className={`hbz-chevron${open ? ' hbz-chevron-open' : ''}`}
      viewBox="0 0 14 14"
      fill="none"
      aria-hidden="true"
    >
      <path d="m3.5 5.25 3.5 3.5 3.5-3.5" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function SliderModelSelect({ locked, available, directory, load, select }) {
  const state = useSyncExternalStore(
    notify => directory.subscribe(notify),
    () => directory.getSnapshot(),
  )
  const [open, setOpen] = useState(false)
  const [pendingEffort, setPendingEffort] = useState(null)
  const [actionError, setActionError] = useState(null)
  const rootRef = useRef(null)
  const triggerRef = useRef(null)
  const panelId = useId()

  const choices = useMemo(() => state.groups.flatMap(group =>
    group.models.map(model => ({ group, model }))), [state.groups])
  const selectedIndex = state.current === null
    ? -1
    : choices.findIndex(({ group, model }) =>
      group.id === state.current.provider && model.id === state.current.model)
  const currentChoice = choices[selectedIndex]
  const reasoning = currentChoice?.model.reasoning
  const efforts = reasoning?.efforts ?? []
  const resolvedEffort = state.current?.reasoningEffort ?? reasoning?.defaultEffort
  const visibleEffort = pendingEffort ?? resolvedEffort
  const effortIndex = Math.max(0, efforts.findIndex(effort => effort.id === visibleEffort))
  const effortLabel = efforts[effortIndex] === undefined
    ? undefined
    : effortDisplayName(efforts[effortIndex])
  const effortAvatar = avatarFor(efforts[effortIndex], effortIndex)
  const modelLabel = currentChoice?.model.name ?? '选择模型'
  const busy = state.status === 'selecting'
  const progress = efforts.length <= 1 ? 0 : effortIndex / (efforts.length - 1) * 100

  useEffect(() => {
    if (available) load()
  }, [available, load])

  useEffect(() => {
    if (!open) return undefined
    const onPointerDown = (event) => {
      if (!rootRef.current?.contains(event.target)) setOpen(false)
    }
    const onKeyDown = (event) => {
      if (event.key !== 'Escape') return
      setOpen(false)
      queueMicrotask(() => triggerRef.current?.focus())
    }
    document.addEventListener('mousedown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('mousedown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  useEffect(() => {
    if (pendingEffort === null) return
    if (state.current?.reasoningEffort === pendingEffort || state.status === 'error') {
      setPendingEffort(null)
    }
  }, [pendingEffort, state.current?.reasoningEffort, state.status])

  useEffect(() => {
    if (locked) setOpen(false)
  }, [locked])

  if (!available) return null

  const chooseModel = async (index) => {
    const choice = choices[index]
    if (choice === undefined) return
    setActionError(null)
    const accepted = await select(selectionForModel(choice.group, choice.model))
    if (!accepted) setActionError(directory.getSnapshot().error ?? '模型切换失败')
  }

  const chooseEffort = async (index) => {
    const effort = efforts[index]
    if (effort === undefined || state.current === null) return
    setPendingEffort(effort.id)
    setActionError(null)
    const accepted = await select(selectionWithEffort(state.current, effort.id))
    if (!accepted) {
      setPendingEffort(null)
      setActionError(directory.getSnapshot().error ?? '档位切换失败')
    }
  }

  const triggerText = effortLabel === undefined ? modelLabel : `${modelLabel} ${effortLabel}`

  return (
    <div className="hbz-root" ref={rootRef}>
      <button
        ref={triggerRef}
        type="button"
        className="hbz-trigger"
        aria-label={`选择模型，当前 ${triggerText}`}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        disabled={locked}
        title={triggerText}
        onClick={() => {
          setOpen(value => !value)
          setActionError(null)
          if (!open) load()
        }}
      >
        {effortLabel !== undefined && (
          <img className="hbz-trigger-avatar" src={effortAvatar} alt="" />
        )}
        <span className="hbz-model-name">{modelLabel}</span>
        {effortLabel !== undefined && <span className="hbz-effort-name">{effortLabel}</span>}
        <Chevron open={open} />
      </button>

      {open && (
        <div id={panelId} className="hbz-panel" role="dialog" aria-label="滑动变祖器">
          <label className="hbz-model-row">
            <span>模型</span>
            <select
              className="hbz-model-select"
              value={selectedIndex < 0 ? '' : String(selectedIndex)}
              disabled={busy || choices.length === 0}
              onChange={event => { void chooseModel(Number(event.target.value)) }}
            >
              {selectedIndex < 0 && <option value="">选择模型</option>}
              {choices.map(({ group, model }, index) => (
                <option value={String(index)} key={`${group.id}/${model.id}`}>
                  {group.name} · {model.name}
                </option>
              ))}
            </select>
          </label>

          {state.status === 'loading' && choices.length === 0 && (
            <div className="hbz-status">正在加载模型目录...</div>
          )}

          {efforts.length > 0 && (
            <section className="hbz-slider-section" aria-label="推理档位">
              <div className="hbz-heading">
                <span>
                  <strong className="hbz-title">滑动变祖器</strong>
                  <small className="hbz-kicker">REASONING DRIVE</small>
                </span>
                <span className="hbz-current"><i />{effortLabel}</span>
              </div>
              <div className="hbz-machine">
                <div className="hbz-ruler" aria-hidden="true" />
                <div className="hbz-rail" aria-hidden="true">
                  <span className="hbz-rail-cap hbz-rail-cap-left" />
                  <span className="hbz-rail-cap hbz-rail-cap-right" />
                </div>
                <div
                  className="hbz-knob"
                  aria-hidden="true"
                  style={{ '--hbz-knob-left': `calc(${progress}% + ${58 - progress * 1.16}px)` }}
                >
                  <span className="hbz-knob-ring">
                    <img src={effortAvatar} alt="" />
                  </span>
                </div>
                <input
                  className="hbz-range"
                  type="range"
                  min="0"
                  max={String(Math.max(0, efforts.length - 1))}
                  step="1"
                  value={String(effortIndex)}
                  disabled={efforts.length <= 1}
                  aria-label="推理档位"
                  aria-valuetext={effortLabel}
                  style={{ '--hbz-progress': `${progress}%` }}
                  onChange={event => { void chooseEffort(Number(event.target.value)) }}
                />
                <div className="hbz-stations" aria-hidden="true">
                  {efforts.map((effort, index) => (
                    <span
                      className={`hbz-station${index === effortIndex ? ' hbz-station-active' : ''}`}
                      key={effort.id}
                      style={{ left: `${efforts.length <= 1 ? 50 : index / (efforts.length - 1) * 100}%` }}
                    >
                      {effortDisplayName(effort)}
                    </span>
                  ))}
                </div>
              </div>
              <div className="hbz-console" aria-hidden="true">
                <span className="hbz-console-light" />
                <span>SLIDE TO EVOLVE</span>
                <strong>{effortLabel}</strong>
              </div>
            </section>
          )}

          {reasoning !== undefined && efforts.length === 0 && (
            <div className="hbz-status">当前模型没有可选推理档位</div>
          )}
          {(actionError ?? state.error) !== null && (
            <div className="hbz-error" role="alert">{actionError ?? state.error}</div>
          )}
        </div>
      )}
    </div>
  )
}

export function apply(ctx) {
  ctx.effect(() => {
    const tag = document.createElement('style')
    tag.dataset.plugin = 'dsh-huadong-bianzuqi'
    tag.textContent = styles
    document.head.appendChild(tag)
    return () => tag.remove()
  })

  ctx.slots.inject('conversation.input.model', () => ctx.slots.register({
    name: 'conversation.input.model',
    priority: -10,
    inject: (sessionId) => {
      const directory = ctx.modelDirectories.directoryFor(sessionId)
      const available = ctx.sessions.subagentAddress(sessionId) === undefined
      return {
        available,
        directory: directory.store,
        load: () => {
          if (available) void directory.load().catch(() => {})
        },
        select: selection => available
          ? directory.select(selection).then(() => true, () => false)
          : Promise.resolve(false),
      }
    },
  }, SliderModelSelect))
}
