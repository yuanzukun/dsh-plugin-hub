import { describe, expect, test } from 'bun:test'
import {
  effortDisplayName,
  selectionForModel,
  selectionWithEffort,
} from '../src/effort.js'

describe('前端档位显示映射', () => {
  test.each([
    ['none', '牢梁'],
    ['off', '牢梁'],
    ['high', '梁子'],
    ['max', '梁圣'],
  ])('%s 只改变显示名', (id, label) => {
    expect(effortDisplayName({ id, name: id })).toBe(label)
  })

  test('未知档位保留适配器名称', () => {
    expect(effortDisplayName({ id: 'medium', name: 'Medium' })).toBe('Medium')
  })
})

describe('模型调用参数', () => {
  test('滑块提交原始 effort id', () => {
    expect(selectionWithEffort(
      { provider: 'deepseek-official', model: 'deepseek-v4-flash' },
      'max',
    )).toEqual({
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
      reasoningEffort: 'max',
    })
  })

  test('模型切换不擅自添加 effort id', () => {
    expect(selectionForModel(
      { id: 'deepseek-official' },
      { id: 'deepseek-v4-flash', reasoning: { defaultEffort: 'high' } },
    )).toEqual({
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
    })
  })
})
