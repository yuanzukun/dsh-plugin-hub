import { mkdir, rm } from 'node:fs/promises'

const pluginId = 'dsh-huadong-bianzuqi'
const outDir = new URL('./lib/', import.meta.url)

process.env.NODE_ENV = 'production'

async function pngDataUrl(path) {
  const bytes = await Bun.file(path).arrayBuffer()
  return `data:image/png;base64,${Buffer.from(bytes).toString('base64')}`
}

const avatars = await Promise.all([
  pngDataUrl('./knob-avatar1.png'),
  pngDataUrl('./knob-avatar2.png'),
  pngDataUrl('./knob-avatar3.png'),
])

await rm(outDir, { recursive: true, force: true })
await mkdir(outDir, { recursive: true })

const host = await Bun.build({
  entrypoints: ['./src/index.js'],
  outdir: './lib',
  target: 'node',
  format: 'esm',
  minify: true,
})

if (!host.success) {
  for (const log of host.logs) console.error(log)
  process.exitCode = 1
} else {
  const client = await Bun.build({
    entrypoints: ['./src/client.jsx'],
    target: 'browser',
    format: 'cjs',
    external: ['react'],
    jsx: {
      runtime: 'classic',
      factory: 'React.createElement',
      fragment: 'React.Fragment',
    },
    define: {
      __HBZ_AVATAR_1__: JSON.stringify(avatars[0]),
      __HBZ_AVATAR_2__: JSON.stringify(avatars[1]),
      __HBZ_AVATAR_3__: JSON.stringify(avatars[2]),
    },
    minify: true,
    write: false,
  })

  if (!client.success || client.outputs.length !== 1) {
    for (const log of client.logs) console.error(log)
    process.exitCode = 1
  } else {
    const code = await client.outputs[0].text()
    const externalModules = [...code.matchAll(/\brequire\("([^"]+)"\)/g)]
      .map(match => match[1])
    const unsupported = externalModules.filter(id => id !== 'react')
    if (unsupported.length > 0) {
      throw new Error(`Unsupported Harness client modules: ${[...new Set(unsupported)].join(', ')}`)
    }
    const embeddedAvatarCount = code.match(/data:image\/png;base64,/g)?.length ?? 0
    if (embeddedAvatarCount !== 3) {
      throw new Error(`Expected 3 embedded knob avatars, found ${embeddedAvatarCount}`)
    }
    const wrapped = [
      `window.__ModuleLoader__.load({ id: ${JSON.stringify(pluginId)}, factory: (require) => {`,
      'var module = { exports: {} }; var exports = module.exports;',
      code,
      'return module.exports; } });',
      '',
    ].join('\n')
    await Bun.write(new URL('./client.js', outDir), wrapped)
  }
}
