// ============================================================================
// dsh-plugin-integration —— Client 半（独立 bundle 形态 / standalone）
// ----------------------------------------------------------------------------
// 与动态形态（src/client.js）的唯一区别在「通信层」，UI 不变：
//   - host.call(method, args) → fetch('/api/plugin-integration/<method>', POST JSON)
//   - styles.insert(css) → 注入 <style> 标签
// ============================================================================

window.__ModuleLoader__.load({
  id: "dsh-plugin-integration",
  factory: require => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
    let React = require("react");

    function apply(ctx) {
  const slots = ctx.get('slots')
  if (slots === undefined) return

  const h = React.createElement
  const useState = React.useState
  const useEffect = React.useEffect

  const CSS = [
    '.pint-root{padding:4px 2px 24px;color:inherit;font-size:13px;line-height:1.55}',
    '.pint-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}',
    '.pint-title{margin:0 0 2px;font-size:18px;font-weight:600}',
    '.pint-muted{color:rgba(128,128,128,0.92);font-size:12px}',
    '.pint-summary{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}',
    '.pint-stat{flex:1 1 80px;min-width:70px;border:1px solid rgba(128,128,128,0.28);border-radius:8px;padding:8px 10px}',
    '.pint-stat-num{font-size:20px;font-weight:700}',
    '.pint-tabs{display:flex;flex-wrap:wrap;gap:4px;border-bottom:1px solid rgba(128,128,128,0.28);margin-bottom:12px}',
    '.pint-tab{padding:6px 12px;border:none;background:transparent;color:inherit;cursor:pointer;border-bottom:2px solid transparent;font-size:13px}',
    '.pint-tab-active{border-bottom-color:#4c8dff;font-weight:600}',
    '.pint-body{display:flex;flex-direction:column;gap:10px}',
    '.pint-card{border:1px solid rgba(128,128,128,0.28);border-radius:8px;padding:12px}',
    '.pint-card-title{font-weight:600;margin-bottom:8px}',
    '.pint-tag{display:inline-block;padding:1px 8px;margin:0 4px 4px 0;border-radius:999px;background:rgba(76,141,255,0.16);color:#4c8dff;font-size:11px}',
    '.pint-btn{padding:4px 10px;border:1px solid rgba(128,128,128,0.4);border-radius:6px;background:transparent;color:inherit;cursor:pointer;font-size:12px;white-space:nowrap}',
    '.pint-btn:disabled{opacity:0.45;cursor:not-allowed}',
    '.pint-btn-primary{border-color:#4c8dff;color:#4c8dff}',
    '.pint-btn-danger{border-color:#e5484d;color:#e5484d}',
    '.pint-btn-warn{border-color:#f5a623;color:#f5a623}',
    '.pint-plugin{border:1px solid rgba(128,128,128,0.28);border-radius:8px;padding:10px 12px}',
    '.pint-plugin-head{display:flex;align-items:center;justify-content:space-between;gap:10px}',
    '.pint-plugin-name{display:flex;align-items:center;font-weight:600;flex-wrap:wrap}',
    '.pint-icon{position:relative;width:20px;height:20px;border-radius:50%;background:rgba(76,141,255,0.18);display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;overflow:hidden;margin-right:6px}',
    '.pint-icon-letter{font-size:11px;font-weight:700;color:#4c8dff;line-height:1}',
    '.pint-icon-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}',
    '.pint-id{margin-left:8px;padding:0 6px;border-radius:4px;background:rgba(128,128,128,0.18);font-size:11px;color:inherit}',
    '.pint-protect{margin-left:6px;padding:0 6px;border-radius:4px;background:rgba(245,166,35,0.16);color:#f5a623;font-size:11px}',
    '.pint-unknown{margin-left:6px;padding:0 6px;border-radius:4px;background:rgba(128,128,128,0.18);color:rgba(128,128,128,0.95);font-size:11px}',
    '.pint-update{margin-left:6px;padding:0 6px;border-radius:4px;background:rgba(76,141,255,0.16);color:#4c8dff;font-size:11px}',
    '.pint-stars{color:#f5a623;font-size:12px;margin-left:8px}',
    '.pint-order{margin-left:8px;color:rgba(128,128,128,0.85);font-size:11px}',
    '.pint-tags{margin:6px 0 2px}',
    '.pint-cap{margin:2px 0}',
    '.pint-bound{margin:2px 0;color:rgba(128,128,128,0.9);font-size:12px}',
    '.pint-meta{display:flex;flex-wrap:wrap;gap:10px;margin-top:4px;align-items:center}',
    '.pint-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}',
    '.VOzbGW_panel{min-width:480px!important;min-height:360px!important;max-width:calc(100vw - 48px)!important;max-height:calc(100vh - 48px)!important}',
    '.pint-resize-handle{position:absolute;z-index:10;touch-action:none}',
    '.pint-resize-n{top:0;left:8px;right:8px;height:6px}',
    '.pint-resize-s{bottom:0;left:8px;right:8px;height:6px}',
    '.pint-resize-w{left:0;top:8px;bottom:8px;width:6px}',
    '.pint-resize-e{right:0;top:8px;bottom:8px;width:6px}',
    '.pint-resize-nw{top:0;left:0;width:14px;height:14px}',
    '.pint-resize-ne{top:0;right:0;width:14px;height:14px}',
    '.pint-resize-sw{bottom:0;left:0;width:14px;height:14px}',
    '.pint-resize-se{bottom:0;right:0;width:14px;height:14px}',
    '.pint-search{flex:1;min-width:160px;background:transparent;color:inherit;border:1px solid rgba(128,128,128,0.4);border-radius:6px;padding:5px 8px;font-size:12px}',
    '.pint-select{background:transparent;color:inherit;border:1px solid rgba(128,128,128,0.4);border-radius:6px;padding:5px 8px;font-size:12px}',
    '.pint-toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}',
    '.pint-overlap{border:1px solid rgba(128,128,128,0.28);border-radius:8px;padding:10px 12px}',
    '.pint-overlap-head{display:flex;justify-content:space-between;gap:8px;margin-bottom:4px}',
    '.pint-overlap-label{font-weight:600}',
    '.pint-overlap-items{display:flex;flex-direction:column;gap:6px;margin-top:6px}',
    '.pint-overlap-item{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:6px 8px;border-radius:6px;background:rgba(128,128,128,0.07)}',
    '.pint-overlap-active{background:rgba(48,164,108,0.14)}',
    '.pint-overlap-name{display:flex;align-items:center;flex-wrap:wrap}',
    '.pint-overlap-state{font-size:12px;color:rgba(128,128,128,0.9)}',
    '.pint-conflict{border:1px solid rgba(128,128,128,0.28);border-radius:8px;padding:10px 12px}',
    '.pint-conflict-head{display:flex;align-items:center;flex-wrap:wrap;gap:8px}',
    '.pint-badge{color:#fff;border-radius:4px;padding:1px 6px;font-size:11px}',
    '.pint-conflict-title{font-weight:600}',
    '.pint-fixes{margin-top:6px;display:flex;flex-direction:column;gap:6px}',
    '.pint-fix{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
    '.pint-empty{padding:14px;text-align:center;color:rgba(128,128,128,0.9)}',
    '.pint-msg{padding:8px 12px;border-radius:6px;margin-bottom:10px;font-size:12px}',
    '.pint-msg-ok{background:rgba(48,164,108,0.16)}',
    '.pint-msg-err{background:rgba(229,72,77,0.16)}',
    '.pint-warncard{border:1px solid rgba(245,166,35,0.5);border-radius:8px;padding:10px 12px;margin-bottom:8px}',
    '.pint-failed{padding:4px 0;color:#e5484d}',
    '.pint-failcard{border:1px solid rgba(229,72,77,0.4);border-radius:8px;padding:10px 12px}',
    '.pint-failcard-head{display:flex;align-items:center;flex-wrap:wrap;gap:8px}',
    '.pint-reason{display:flex;gap:8px;margin:4px 0}',
    '.pint-impact{margin:2px 0;color:rgba(128,128,128,0.9);font-size:12px}',
    '.pint-log-tabs{display:flex;gap:4px;border-bottom:1px solid rgba(128,128,128,0.28);margin-bottom:8px}',
    '.pint-log-toolbar{display:flex;gap:8px;align-items:center;margin-bottom:8px}',
    '.pint-log-item{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center;padding:6px 0;border-bottom:1px solid rgba(128,128,128,0.14)}',
    '.pint-log-time{color:rgba(128,128,128,0.9);font-size:11px;white-space:nowrap}',
    '.pint-log-action{font-weight:600;font-size:12px}',
    '.pint-log-detail{font-size:12px}',
    '.pint-log-msg{color:rgba(128,128,128,0.9);font-size:11px;flex-basis:100%}',
  ].join('\n')

  function injectStyle(css) {
    const style = document.createElement('style')
    style.textContent = css
    document.head.appendChild(style)
    return function () { if (style.parentNode) style.parentNode.removeChild(style) }
  }
  ctx.effect(function () { return injectStyle(CSS) })

  // 原生窗口缩放：给设置弹窗注入「四边 + 四角」8 个拖拽热区，并负责尺寸持久化。
  ctx.effect(function () {
    var ro = null
    var HANDLES = [['n', 'ns-resize'], ['s', 'ns-resize'], ['e', 'ew-resize'], ['w', 'ew-resize'], ['ne', 'nesw-resize'], ['sw', 'nesw-resize'], ['nw', 'nwse-resize'], ['se', 'nwse-resize']]
    function startDrag(dir, panel, ev) {
      ev.preventDefault()
      var startX = ev.clientX, startY = ev.clientY
      var startW = panel.offsetWidth, startH = panel.offsetHeight
      function onMove(e) {
        var dx = e.clientX - startX, dy = e.clientY - startY
        var w = startW, h = startH
        if (dir.indexOf('e') >= 0) w = startW + dx
        if (dir.indexOf('w') >= 0) w = startW - dx
        if (dir.indexOf('s') >= 0) h = startH + dy
        if (dir.indexOf('n') >= 0) h = startH - dy
        w = Math.max(480, Math.min(window.innerWidth - 48, w))
        h = Math.max(360, Math.min(window.innerHeight - 48, h))
        panel.style.width = w + 'px'
        panel.style.height = h + 'px'
      }
      function onUp() {
        document.removeEventListener('pointermove', onMove)
        document.removeEventListener('pointerup', onUp)
        document.removeEventListener('pointercancel', onUp)
      }
      document.addEventListener('pointermove', onMove)
      document.addEventListener('pointerup', onUp)
      document.addEventListener('pointercancel', onUp)
    }
    function attach(panel) {
      if (panel.__pintResize) return
      panel.__pintResize = true
      var s = null
      try { s = JSON.parse(localStorage.getItem('dsh.pluginIntegration.panelSize') || 'null') } catch (e) {}
      if (s && s.w && s.h) { panel.style.width = s.w + 'px'; panel.style.height = s.h + 'px' }
      HANDLES.forEach(function (hd) {
        var el = document.createElement('div')
        el.className = 'pint-resize-handle pint-resize-' + hd[0]
        el.style.cursor = hd[1]
        el.addEventListener('pointerdown', function (ev) { startDrag(hd[0], panel, ev) })
        panel.appendChild(el)
      })
      if (window.ResizeObserver) {
        ro = new ResizeObserver(function () {
          var r = panel.getBoundingClientRect()
          if (r.width > 0 && r.height > 0) { try { localStorage.setItem('dsh.pluginIntegration.panelSize', JSON.stringify({ w: Math.round(r.width), h: Math.round(r.height) })) } catch (e) {} }
        })
        ro.observe(panel)
      }
    }
    function scan() { var p = document.querySelector('.VOzbGW_panel'); if (p) attach(p) }
    scan()
    var mo = new MutationObserver(scan)
    mo.observe(document.body, { childList: true, subtree: true })
    return function () { mo.disconnect(); if (ro) ro.disconnect() }
  })

  function rpc(method, args) {
    return fetch('/api/plugin-integration/' + method, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(args || {}),
    }).then(function (r) { return r.json() })
  }

  const STATUS_META = { 'active': { text: '已生效', color: '#30a46c' }, 'inactive': { text: '已启用 · 未生效', color: '#f5a623' }, 'disabled': { text: '已停用', color: '#9aa0a6' }, 'failed': { text: '失效', color: '#e5484d' } }
  const OVERLAP_STATUS = { 'active': { text: '完全生效', color: '#30a46c' }, 'inactive': { text: '部分生效（客户端未生效）', color: '#f5a623' }, 'disabled': { text: '已停用', color: '#9aa0a6' }, 'failed': { text: '失效', color: '#e5484d' } }
  const TIME_ORDER = { '今日': 0, '三天内': 1, '一周内': 2, '一月内': 3, '更早': 4 }
  const ACTION_LABEL = { toggle: '启停', switch: '重叠切换', applyFix: '采用修复', markFailed: '标记失效', unmarkFailed: '取消失效', detectFailures: '失效检测', refreshStars: '刷新star', predictUpdateConflicts: '更新预判', reanalyze: '重新检测' }

  function StatusDot(props) { return h('span', { style: { display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: props.color || '#9aa0a6', marginRight: 6, flex: '0 0 auto' } }) }
  function Tag(props) { return h('span', { className: 'pint-tag' }, props.children) }
  function Btn(props) { const cls = 'pint-btn' + (props.kind === 'primary' ? ' pint-btn-primary' : '') + (props.kind === 'danger' ? ' pint-btn-danger' : '') + (props.kind === 'warn' ? ' pint-btn-warn' : ''); return h('button', { className: cls, disabled: props.disabled, onClick: props.onClick, title: props.title }, props.children) }
  function Card(props) { return h('div', { className: 'pint-card' }, props.title ? h('div', { className: 'pint-card-title' }, props.title) : null, props.children) }
  function Stars(props) { return h('span', { className: 'pint-stars' }, '★ ' + (props.n || 0)) }
  function Icon(props) {
    const p = props.p || {}
    const letter = String(p.label || p.entryId || '?').charAt(0).toUpperCase()
    return h('span', { className: 'pint-icon', title: p.label },
      h('span', { className: 'pint-icon-letter' }, letter),
      p.icon ? h('img', { className: 'pint-icon-img', src: p.icon, alt: '', loading: 'lazy', onError: function (e) { e.currentTarget.style.display = 'none' } }) : null
    )
  }

  function PluginCard(props) {
    const p = props.p
    const meta = STATUS_META[p.status] || STATUS_META.inactive
    return h('div', { className: 'pint-plugin' },
      h('div', { className: 'pint-plugin-head' },
        h('div', { className: 'pint-plugin-name' },
          h(Icon, { p: p }), h(StatusDot, { color: meta.color }), h('span', null, p.label),
          p.protected ? h('span', { className: 'pint-protect' }, '受保护') : null,
          p.markedFailed ? h('span', { className: 'pint-protect', style: { background: 'rgba(229,72,77,0.16)', color: '#e5484d' } }, '已判定失效') : null,
          p.hasUpdate ? h('span', { className: 'pint-update' }, '待更新 v' + (p.installedVersion || '?') + '→' + (p.latestVersion || '?')) : null,
          p.known === false ? h('span', { className: 'pint-unknown' }, '未知') : null,
          h('code', { className: 'pint-id' }, p.entryId),
          h(Stars, { n: p.stars }),
          h('span', { className: 'pint-order' }, p.installTime || '更早')
        ),
        h('div', { className: 'pint-actions' },
          p.toggleable !== false ? h(Btn, { kind: p.enabled ? 'danger' : 'primary', disabled: props.busy, onClick: function () { props.onToggle(p) } }, p.enabled ? '停用' : '启用') : h('span', { className: 'pint-muted' }, '受保护'),
          p.enabled && p.status !== 'failed' && !p.markedFailed ? h(Btn, { kind: 'warn', disabled: props.busy, onClick: function () { props.onMarkFailed(p) } }, '判定失效') : null,
          p.markedFailed ? h(Btn, { kind: 'primary', disabled: props.busy, onClick: function () { props.onUnmarkFailed(p) } }, '取消判定') : null,
          p.hasUpdate ? h(Btn, { kind: 'primary', disabled: props.busy, onClick: function () { props.onPreUpdate(p) } }, '预判更新') : null
        )
      ),
      h('div', { className: 'pint-tags' }, (p.tags || []).map(function (t) { return h(Tag, { key: t }, t) })),
      p.capability ? h('div', { className: 'pint-cap' }, p.capability) : null,
      p.boundary ? h('div', { className: 'pint-bound' }, '边界：' + p.boundary) : null,
      h('div', { className: 'pint-meta' }, h('span', { className: 'pint-muted' }, meta.text), p.repo ? h('span', { className: 'pint-muted' }, 'GitHub: ' + p.repo) : null, p.bundle ? h('span', { className: 'pint-muted' }, '包：' + p.bundle) : null)
    )
  }

  function OverlapCard(props) {
    const o = props.o
    return h('div', { className: 'pint-overlap' },
      h('div', { className: 'pint-overlap-head' }, h('span', { className: 'pint-overlap-label' }, o.label), h('span', { className: 'pint-muted' }, '已启用 ' + o.enabledCount + ' / ' + o.entries.length)),
      o.note ? h('div', { className: 'pint-bound' }, o.note) : null,
      h('div', { className: 'pint-overlap-items' }, o.entries.map(function (e) {
        const meta = OVERLAP_STATUS[e.status] || OVERLAP_STATUS.inactive
        const isActive = e.status === 'active'
        return h('div', { className: 'pint-overlap-item' + (isActive ? ' pint-overlap-active' : '') },
          h('div', { className: 'pint-overlap-name' }, h(StatusDot, { color: meta.color }), h('span', null, e.label), h('code', { className: 'pint-id' }, e.entryId)),
          h('div', { className: 'pint-overlap-state' }, meta.text),
          h('div', { className: 'pint-actions' },
            h(Btn, { kind: 'primary', disabled: props.busy || (isActive && e.enabled), onClick: function () { props.onSwitch(o, e) } }, '切换为此'),
            e.enabled ? h(Btn, { kind: 'danger', disabled: props.busy, onClick: function () { props.onDisableOne(e) } }, '停用') : null,
            e.enabled && e.status !== 'failed' ? h(Btn, { kind: 'warn', disabled: props.busy, onClick: function () { props.onMarkFailedEntry(e) } }, '判定失效') : null
          )
        )
      }))
    )
  }

  function ConflictCard(props) {
    const c = props.c
    const sevColor = c.severity === 'high' ? '#e5484d' : (c.severity === 'medium' ? '#f5a623' : '#9aa0a6')
    const sevLabel = c.severity === 'high' ? '高' : (c.severity === 'medium' ? '中' : '低')
    return h('div', { className: 'pint-conflict' },
      h('div', { className: 'pint-conflict-head' },
        h('span', { className: 'pint-badge', style: { background: sevColor } }, sevLabel),
        h('span', { className: 'pint-conflict-title' }, c.title),
        h('span', { className: 'pint-muted' }, c.type === 'coexistence' ? '共用性冲突' : '存在性冲突'),
        h('span', { className: 'pint-muted' }, '触发：' + (c.triggeredEntries || c.entries).join(', '))
      ),
      h('div', { className: 'pint-cap' }, c.desc),
      c.evidence ? h('div', { className: 'pint-bound' }, '依据：' + c.evidence) : null,
      h('div', { className: 'pint-fixes' }, (c.fixes || []).map(function (f) { return h('div', { className: 'pint-fix', key: f.id }, h(Btn, { kind: 'primary', disabled: props.busy, onClick: function () { props.onApplyFix(f) } }, '采用'), h('span', null, f.label)) }))
    )
  }

  function FailedCard(props) {
    const r = props.r
    const meta = STATUS_META[r.status] || STATUS_META.inactive
    const enableFix = (r.fixPlans || []).find(function (f) { return f.action === 'enable' && f.target })
    return h('div', { className: 'pint-failcard' },
      h('div', { className: 'pint-failcard-head' },
        h(StatusDot, { color: meta.color }), h('span', { style: { fontWeight: 600 } }, r.label), h('code', { className: 'pint-id' }, r.entryId),
        h('span', { className: 'pint-badge', style: { background: meta.color } }, meta.text),
        h('span', { style: { flex: 1 } }),
        enableFix ? h(Btn, { kind: 'primary', disabled: props.busy, onClick: function () { props.onFixEnable(enableFix) } }, '修复') : h(Btn, { disabled: true, title: '需手动修复' }, '需手动修复')
      ),
      (r.reasons || []).map(function (reason, i) { return h('div', { className: 'pint-reason', key: i }, h('span', { className: 'pint-muted' }, '原因'), h('span', null, reason)) }),
      (r.evidence || []).length > 0 ? h('div', { className: 'pint-bound' }, '依据：' + r.evidence.join('；')) : null,
      (r.fixPlans || []).map(function (f, i) {
        return h('div', { className: 'pint-fix', key: i },
          f.action === 'enable' ? h(Btn, { kind: 'primary', disabled: props.busy, onClick: function () { props.onFixEnable(f) } }, '启用') : h('span', { className: 'pint-muted' }, f.action === 'none' ? '—' : '手动'),
          h('span', null, f.label),
          h('span', { className: 'pint-impact' }, '影响：' + (f.impact || '无'))
        )
      })
    )
  }

  function App() {
    const [data, setData] = useState(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')
    const [tab, setTab] = useState('list')
    const [busy, setBusy] = useState(false)
    const [msg, setMsg] = useState(null)
    const [tagFilter, setTagFilter] = useState('')
    const [search, setSearch] = useState('')
    const [sortBy, setSortBy] = useState('installEpoch')
    const [sortDir, setSortDir] = useState('desc')
    const [timeFilter, setTimeFilter] = useState('all')
    const [updatesOnly, setUpdatesOnly] = useState(false)
    const [statusFilter, setStatusFilter] = useState('all')
    const [updateWarnings, setUpdateWarnings] = useState(null)
    const [failures, setFailures] = useState(null)
    const [usageData, setUsageData] = useState(null)
    const [showLog, setShowLog] = useState(false)
    const [logData, setLogData] = useState({ current: [], history: [] })
    const [logTab, setLogTab] = useState('current')
    const [lastDetected, setLastDetected] = useState(null)

    function refresh() { setLoading(true); return rpc('analyze').then(function (d) { setData(d); setError('') }).catch(function (e) { setError(String((e && e.message) || e)) }).finally(function () { setLoading(false) }) }
    useEffect(function () { refresh() }, [])
    useEffect(function () { if (tab === 'usage') onLoadUsage() }, [tab])

    function act(promise) { setBusy(true); setMsg(null); return promise.then(function (r) { setMsg(r); return r }).catch(function (e) { setMsg({ ok: false, error: String((e && e.message) || e) }) }).finally(function () { setBusy(false) }) }
    function onToggle(p) { act(rpc('toggle', { entryId: p.entryId, enabled: !p.enabled })).then(function () { refresh() }) }
    function onSwitch(o, e) { act(rpc('switch', { groupId: o.id, entryId: e.entryId })).then(function () { refresh() }) }
    function onDisableOne(e) { act(rpc('toggle', { entryId: e.entryId, enabled: false })).then(function () { refresh() }) }
    function onApplyFix(f) { act(rpc('applyFix', { fixId: f.id })).then(function () { refresh() }) }
    function onMarkFailed(p) { act(rpc('markFailed', { entryId: p.entryId })).then(function (r) { setMsg(r); refresh() }) }
    function onMarkFailedEntry(e) { act(rpc('markFailed', { entryId: e.entryId })).then(function (r) { setMsg(r); refresh() }) }
    function onUnmarkFailed(p) { act(rpc('unmarkFailed', { entryId: p.entryId })).then(function (r) { setMsg(r); refresh() }) }
    function onRefreshStars() { act(rpc('refreshStars')).then(function (r) { const results = r.results || []; const fresh = results.filter(function (x) { return typeof x.stars === 'number' && !x.cached }).length; const cached = results.filter(function (x) { return typeof x.stars === 'number' && x.cached }).length; const noRepo = results.filter(function (x) { return x.repo === null }).length; const fail = results.filter(function (x) { return typeof x.stars !== 'number' && x.repo !== null }).length; setMsg({ ok: true, message: '已刷新 star：新获取 ' + fresh + '，缓存 ' + cached + '，无仓库 ' + noRepo + '，失败 ' + fail + (r.rateLimited ? '（触发限流）' : '') }); refresh() }) }
    function onSyncUpdates() { act(rpc('syncUpdates')).then(function (r) { const n = (r && r.updated) ? r.updated.length : 0; setMsg({ ok: true, message: '已同步更新状态：' + n + ' 个插件有待更新' + (r && r.rateLimited ? '（GitHub 限流，部分未检测）' : '') }); refresh() }) }
    function onUpdateAll() { act(rpc('updatePlugins')).then(function (r) { if (!r || r.total === 0) { setMsg({ ok: true, message: (r && r.message) || '没有可更新的插件' }); return }; setMsg({ ok: true, message: '一键更新：成功 ' + r.okCount + ' / ' + r.total + (r.restartRequired ? '（需重启 DSH 生效）' : '') }); refresh() }) }
    function onPreUpdate(p) { act(rpc('predictUpdateConflicts', { entryIds: [p.entryId] })).then(function (r) { setUpdateWarnings(r.warnings || []) }) }
    function onDetectAll() { act(rpc('detectFailures', { entryIds: [] })).then(function (r) { setFailures(r.results || []) }) }
    function onFixEnable(f) { act(rpc('toggle', { entryId: f.target, enabled: true })).then(function () { refresh() }) }
    function onFixAll() { act(rpc('fixAllFailures')).then(function (r) { setMsg({ ok: true, message: '一键修复：已修复 ' + (r && r.fixedCount || 0) + ' / ' + (r && r.total || 0) }); setFailures(null); refresh() }) }
    function onManualRefresh() { setLoading(true); return rpc('reanalyze').then(function (d) { setData(d); setError(''); setLastDetected(new Date()); setMsg({ ok: true, message: '已重新检测' }) }).catch(function (e) { setError(String((e && e.message) || e)) }).finally(function () { setLoading(false) }) }
    function reloadLog() { rpc('getOperations').then(function (r) { setLogData({ current: (r && r.current) || [], history: (r && r.history) || [] }) }).catch(function () { setLogData({ current: [], history: [] }) }) }
    function onToggleLog() { const next = !showLog; setShowLog(next); if (next) reloadLog() }
    function onDeleteLog(id) { rpc('deleteOperation', { id: id }).then(function () { reloadLog() }) }
    function onClearLog(scope) { rpc('clearOperations', { scope: scope }).then(function () { reloadLog() }) }
    function onResetPanelSize() { try { localStorage.removeItem('dsh.pluginIntegration.panelSize') } catch (e) {}; var p = document.querySelector('.VOzbGW_panel'); if (p) { p.style.width = ''; p.style.height = '' } }
    function onLoadUsage() { rpc('getUsage').then(function (r) { setUsageData(r) }).catch(function () {}) }
    function onClearUsage() { act(rpc('clearUsage')).then(function () { setUsageData(null); onLoadUsage() }) }

    const tabs = [
      { id: 'list', label: '插件清单' },
      { id: 'overlap', label: '重叠切换' },
      { id: 'compat', label: '兼容检测' },
      { id: 'toggle', label: '启用 / 停用' },
      { id: 'failed', label: '失效插件' },
      { id: 'usage', label: '用量统计' },
    ]

    const markedPlugins = ((data && data.plugins) || []).filter(function (p) { return p.markedFailed })
    const suspiciousPlugins = ((data && data.plugins) || []).filter(function (p) { return !p.markedFailed && (p.status === 'inactive' || p.status === 'failed') })

    function filteredList() {
      let list = (data && data.plugins) || []
      list = list.filter(function (p) {
        if (tagFilter && p.tags.indexOf(tagFilter) < 0) return false
        if (timeFilter !== 'all' && p.installTime !== timeFilter) return false
        if (updatesOnly && !p.hasUpdate) return false
        if (statusFilter === 'enabled' && !p.enabled) return false
        if (statusFilter === 'disabled' && p.enabled) return false
        if (statusFilter === 'failed' && !p.markedFailed) return false
        if (search) { const q = String(search).toLowerCase(); const hay = String((p.label || '') + ' ' + (p.entryId || '') + ' ' + (p.moduleName || '') + ' ' + (p.bundle || '') + ' ' + (p.category || '')).toLowerCase(); if (hay.indexOf(q) < 0) return false }
        return true
      })
      list = list.slice()
      const dir = sortDir === 'asc' ? 1 : -1
      if (sortBy === 'stars') list.sort(function (a, b) { return ((a.stars || 0) - (b.stars || 0)) * dir })
      else if (sortBy === 'name') list.sort(function (a, b) { return String(a.label).localeCompare(String(b.label)) * dir })
      else if (sortBy === 'installIndex') list.sort(function (a, b) { return (a.installIndex - b.installIndex) * dir })
      else if (sortBy === 'installTime') list.sort(function (a, b) { return ((TIME_ORDER[a.installTime] || 9) - (TIME_ORDER[b.installTime] || 9)) * dir })
      else list.sort(function (a, b) { return ((a.installEpoch || 0) - (b.installEpoch || 0)) * dir })
      return list
    }

    return h('div', { className: 'pint-root' },
      h('div', { className: 'pint-header' },
        h('div', null, h('h2', { className: 'pint-title' }, '插件整合'), h('div', { className: 'pint-muted' }, '动态发现 · 分类 · 重叠切换 · 兼容检测 · 启停 · 失效检测 · 更新预判' + (lastDetected ? ' · 上次检测 ' + lastDetected.toLocaleTimeString('zh-CN', { hour12: false }) : ''))),
        h('div', { className: 'pint-actions' },
          h(Btn, { kind: 'warn', onClick: onResetPanelSize, title: '恢复设置窗口到默认 800×800' }, '重置窗口'),
          h(Btn, { kind: 'primary', onClick: onToggleLog }, showLog ? '收起日志' : '操作日志'),
          h(Btn, { kind: 'primary', disabled: loading, onClick: onManualRefresh }, loading ? '检测中…' : '重新检测')
        )
      ),
      showLog ? h(Card, { title: '操作日志' },
        h('div', { className: 'pint-log-tabs' },
          h('button', { className: 'pint-tab' + (logTab === 'current' ? ' pint-tab-active' : ''), onClick: function () { setLogTab('current') } }, '当前日志（本次启动）(' + logData.current.length + ')'),
          h('button', { className: 'pint-tab' + (logTab === 'history' ? ' pint-tab-active' : ''), onClick: function () { setLogTab('history') } }, '历史日志 (' + logData.history.length + ')')
        ),
        h('div', { className: 'pint-log-toolbar' },
          h(Btn, { kind: 'danger', onClick: function () { onClearLog(logTab) } }, '清空' + (logTab === 'current' ? '当前' : '历史')),
          h(Btn, { kind: 'danger', onClick: function () { onClearLog('all') } }, '清空全部')
        ),
        (function () {
          const list = logTab === 'current' ? logData.current : logData.history
          if (list.length === 0) return h('div', { className: 'pint-empty' }, logTab === 'current' ? '本次启动暂无操作记录' : '暂无历史日志')
          return list.map(function (o) {
            const t = o.ts ? new Date(o.ts).toLocaleString('zh-CN', { hour12: false }) : ''
            return h('div', { className: 'pint-log-item', key: o.id || ((o.ts || 0) + '-' + o.action + '-' + (o.detail || '')) },
              h('span', { className: 'pint-log-time' }, t),
              h('span', { className: 'pint-badge', style: { background: o.ok === false ? '#e5484d' : '#4c8dff' } }, o.ok === false ? '失败' : '成功'),
              h('span', { className: 'pint-log-action' }, ACTION_LABEL[o.action] || o.action),
              h('span', { className: 'pint-log-detail' }, o.detail),
              o.message ? h('span', { className: 'pint-log-msg' }, o.message) : null,
              h(Btn, { kind: 'danger', onClick: function () { onDeleteLog(o.id) } }, '删除')
            )
          })
        })()
      ) : null,
      msg ? h('div', { className: 'pint-msg ' + (msg.ok === false ? 'pint-msg-err' : 'pint-msg-ok') }, (msg.error || msg.message) || (msg.ok ? '操作成功' : '')) : null,
      error ? h('div', { className: 'pint-msg pint-msg-err' }, '加载失败：' + error) : null,
      data && data.ok ? h('div', { className: 'pint-summary' },
        h('div', { className: 'pint-stat' }, h('div', { className: 'pint-stat-num' }, data.summary.total), h('div', { className: 'pint-muted' }, '已装插件')),
        h('div', { className: 'pint-stat' }, h('div', { className: 'pint-stat-num' }, data.summary.enabled), h('div', { className: 'pint-muted' }, '已启用')),
        h('div', { className: 'pint-stat' }, h('div', { className: 'pint-stat-num' }, data.summary.active), h('div', { className: 'pint-muted' }, '已生效')),
        h('div', { className: 'pint-stat' }, h('div', { className: 'pint-stat-num', style: data.summary.conflicts > 0 ? { color: '#f5a623' } : undefined }, data.summary.conflicts), h('div', { className: 'pint-muted' }, '兼容冲突')),
        h('div', { className: 'pint-stat' }, h('div', { className: 'pint-stat-num', style: data.summary.pendingUpdateCount > 0 ? { color: '#4c8dff' } : undefined }, data.summary.pendingUpdateCount), h('div', { className: 'pint-muted' }, '待更新'))
      ) : null,
      h('div', { className: 'pint-tabs' }, tabs.map(function (t) { return h('button', { key: t.id, className: 'pint-tab' + (tab === t.id ? ' pint-tab-active' : ''), onClick: function () { setTab(t.id) } }, t.label) })),
      data && data.ok ? h('div', { className: 'pint-body' },
        tab === 'list' ? h('div', null,
          h('div', { className: 'pint-toolbar' },
            h('input', { className: 'pint-search', placeholder: '搜索名称/条目/模块/包…', value: search, onChange: function (e) { setSearch(e.target.value) } }),
            h('select', { className: 'pint-select', value: sortBy, onChange: function (e) { setSortBy(e.target.value) } },
              h('option', { value: 'installEpoch' }, '排序：入库时间'), h('option', { value: 'installTime' }, '入库分类'), h('option', { value: 'stars' }, 'star 数'), h('option', { value: 'name' }, '名称'), h('option', { value: 'installIndex' }, '安装顺序')),
            h(Btn, { disabled: busy, onClick: function () { setSortDir(sortDir === 'asc' ? 'desc' : 'asc') } }, sortDir === 'asc' ? '↑ 升序' : '↓ 降序'),
            h('select', { className: 'pint-select', value: timeFilter, onChange: function (e) { setTimeFilter(e.target.value) } },
              h('option', { value: 'all' }, '入库：全部'), h('option', { value: '今日' }, '今日'), h('option', { value: '三天内' }, '三天内'), h('option', { value: '一周内' }, '一周内'), h('option', { value: '一月内' }, '一月内'), h('option', { value: '更早' }, '更早')),
            h('select', { className: 'pint-select', value: tagFilter, onChange: function (e) { setTagFilter(e.target.value) } },
              h('option', { value: '' }, 'tag：全部'), (data.tagGroups || []).map(function (g) { return h('option', { key: g.tag, value: g.tag }, g.tag + ' (' + g.plugins.length + ')') })),
            h('select', { className: 'pint-select', value: statusFilter, onChange: function (e) { setStatusFilter(e.target.value) } },
              h('option', { value: 'all' }, '状态：全部'), h('option', { value: 'enabled' }, '已启用'), h('option', { value: 'disabled' }, '已停用'), h('option', { value: 'failed' }, '已失效')),
            h(Btn, { kind: 'primary', disabled: busy, onClick: onSyncUpdates }, '同步更新'),
            h(Btn, { kind: 'primary', disabled: busy, onClick: onUpdateAll, title: '更新所有「待更新」插件（npm/github 来源）' }, '一键更新'),
            h(Btn, { kind: 'primary', disabled: busy, onClick: onRefreshStars }, '刷新 star'),
            h(Btn, { kind: updatesOnly ? 'primary' : undefined, disabled: busy, onClick: function () { setUpdatesOnly(!updatesOnly) } }, updatesOnly ? '待更新 ✓' : '待更新')
          ),
          updateWarnings ? h(Card, { title: '更新冲突预判（' + updateWarnings.length + ' 条提示）' },
            updateWarnings.length === 0 ? h('div', { className: 'pint-empty' }, '未预判到新的兼容冲突 ✓') : updateWarnings.map(function (w, i) { return h('div', { className: 'pint-warncard', key: i }, h('div', { className: 'pint-conflict-head' }, h('span', { className: 'pint-badge', style: { background: w.severity === 'high' ? '#e5484d' : '#f5a623' } }, w.severity === 'high' ? '高' : '中'), h('span', { className: 'pint-conflict-title' }, w.title)), h('div', { className: 'pint-cap' }, w.desc)) }),
            h(Btn, { kind: 'primary', disabled: busy, onClick: function () { setUpdateWarnings(null) } }, '关闭')
          ) : null,
          filteredList().map(function (p) { return h(PluginCard, { key: p.entryId, p: p, busy: busy, onToggle: onToggle, onMarkFailed: onMarkFailed, onUnmarkFailed: onUnmarkFailed, onPreUpdate: onPreUpdate }) })
        ) : null,
        tab === 'overlap' ? h('div', null,
          h('div', { className: 'pint-muted', style: { marginBottom: 10 } }, '功能重叠组：同一能力由多个插件覆盖。「切换为此」停用组内其余；「停用」单方停用该插件；「判定失效」标记后纳入失效检测。'),
          (data.overlaps || []).map(function (o) { return h(OverlapCard, { key: o.id, o: o, busy: busy, onSwitch: onSwitch, onDisableOne: onDisableOne, onMarkFailedEntry: onMarkFailedEntry }) })
        ) : null,
        tab === 'compat' ? h('div', null,
          h('div', { className: 'pint-muted', style: { marginBottom: 10 } }, '兼容性检测：存在性冲突 = 只要共存就出问题；共用性冲突 = 同时启用才出问题。'),
          (data.conflicts || []).length > 0 ? data.conflicts.map(function (c) { return h(ConflictCard, { key: c.id, c: c, busy: busy, onApplyFix: onApplyFix }) }) : h('div', { className: 'pint-empty' }, '未检测到已触发的兼容性冲突 ✓'),
          (data.warnings || []).map(function (w, i) { return h('div', { key: i, className: 'pint-bound' }, '⚠ ' + w) })
        ) : null,
        tab === 'toggle' ? h('div', null,
          h('div', { className: 'pint-toolbar' }, h('input', { className: 'pint-search', placeholder: '搜索名称/条目/模块/包…', value: search, onChange: function (e) { setSearch(e.target.value) } })),
          h('div', { className: 'pint-muted', style: { marginBottom: 10 } }, '启用/停用插件（写入 profile 补丁，HMR 热重载即时生效）。核心受保护条目禁止停用，避免误停导致 DSH 无法进入。'),
          (data.plugins || []).filter(function (p) { const q = String(search).toLowerCase(); if (!q) return true; return String((p.label || '') + ' ' + p.entryId + ' ' + (p.moduleName || '') + ' ' + (p.bundle || '')).toLowerCase().indexOf(q) >= 0 }).map(function (p) { return h(PluginCard, { key: p.entryId, p: p, busy: busy, onToggle: onToggle, onMarkFailed: onMarkFailed, onUnmarkFailed: onUnmarkFailed, onPreUpdate: onPreUpdate }) })
        ) : null,
        tab === 'failed' ? h('div', null,
          h('div', { className: 'pint-toolbar' },
            h(Btn, { kind: 'primary', disabled: busy, onClick: onDetectAll }, '检测失效（标记 + 未生效）'),
            h(Btn, { kind: 'primary', disabled: busy, onClick: onFixAll, title: '自动修复所有可修复的失效插件' }, '一键修复'),
            h('span', { className: 'pint-muted' }, '标记失效 ' + markedPlugins.length + ' 个 · 可疑（未生效）' + suspiciousPlugins.length + ' 个')
          ),
          failures ? failures.map(function (r) { return h(FailedCard, { key: r.entryId, r: r, busy: busy, onFixEnable: onFixEnable }) }) : null,
          !failures && markedPlugins.length === 0 && suspiciousPlugins.length === 0 ? h('div', { className: 'pint-empty' }, '暂无失效/可疑插件') : null,
          !failures && (markedPlugins.length > 0 || suspiciousPlugins.length > 0) ? h('div', { className: 'pint-muted', style: { marginBottom: 8 } }, '点击「检测失效」查看具体失效原因与修复方案。') : null,
          !failures ? markedPlugins.map(function (p) { return h('div', { className: 'pint-plugin', key: p.entryId }, h('div', { className: 'pint-plugin-name' }, h(StatusDot, { color: '#e5484d' }), h('span', null, p.label), h('code', { className: 'pint-id' }, p.entryId)), h('div', { className: 'pint-bound' }, '已判定失效，点击「检测失效」获取原因。')) }) : null
        ) : null,
        tab === 'usage' ? h('div', null,
          h('div', { className: 'pint-toolbar' },
            h(Btn, { kind: 'primary', disabled: busy, onClick: onLoadUsage }, '刷新用量'),
            h(Btn, { kind: 'danger', disabled: busy, onClick: onClearUsage }, '清空'),
            h('span', { className: 'pint-muted' }, usageData ? ('总调用 ' + usageData.summary.totalCalls + ' 次 · 估算 token ' + usageData.summary.totalTokens) : '点击「刷新用量」加载')
          ),
          usageData ? h('div', null,
            h(Card, { title: '按插件统计' },
              (usageData.byPlugin || []).length === 0 ? h('div', { className: 'pint-empty' }, '暂无调用记录') :
              (usageData.byPlugin || []).map(function (g) { return h('div', { className: 'pint-plugin', key: g.entryId || '__unmapped__' }, h('div', { className: 'pint-plugin-head' }, h('div', { className: 'pint-plugin-name' }, h('span', null, g.label), g.entryId ? h('code', { className: 'pint-id' }, g.entryId) : null), h('div', { className: 'pint-muted' }, '调用 ' + g.calls + ' 次 · 估算 token ' + g.tokens)), h('div', { className: 'pint-bound' }, '工具：' + g.tools.join('、'))) })
            ),
            h(Card, { title: '按工具统计' },
              (usageData.byTool || []).length === 0 ? h('div', { className: 'pint-empty' }, '暂无调用记录') :
              (usageData.byTool || []).map(function (t) { return h('div', { className: 'pint-plugin', key: t.tool }, h('div', { className: 'pint-plugin-head' }, h('div', { className: 'pint-plugin-name' }, h('code', { className: 'pint-id' }, t.tool)), h('div', { className: 'pint-muted' }, '调用 ' + t.calls + ' 次 · 估算 token ' + t.tokens))) })
            )
          ) : h('div', { className: 'pint-empty' }, '点击「刷新用量」查看实时调用次数与 token 消耗')
        ) : null
      ) : null
    )
  }

  slots.inject('settings.section', function () {
    return slots.register(
      { name: 'settings.section', id: 'plugin-integration', order: 500, label: '插件整合' },
      function () { return h(App) }
    )
  })
    }
    exports.apply = apply;
    return module.exports;
  },
});
