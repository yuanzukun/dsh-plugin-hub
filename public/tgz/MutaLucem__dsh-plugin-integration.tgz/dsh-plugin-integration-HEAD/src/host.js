// ============================================================================
// dsh-plugin-integration —— Host 半（v1.3 增强版）
// ----------------------------------------------------------------------------
// 在 v1.2 基础上新增：
//   - 入库时间：记录「首次识别时间戳」到状态文件，分类为 今日/三天内/一周内/一月内/更早
//   - GitHub star：配置 repo 或从 package.json repository 派生，联网抓取并缓存
//   - 待更新：配置 latestVersion，与安装版本比较，标记 hasUpdate
// ============================================================================
export default function () {
'use strict'

const DEFAULT_CONFIG = {
  protected: ['ui-web-ui-compat'],
  plugins: {
    'tts': { label: 'Edge TTS 语音朗读', category: '音频语音', tags: ['语音朗读', '音频', '无障碍'], capability: '消息朗读按钮、自动朗读开关、语音设置面板', boundary: '仅朗读输出，不做语音识别输入' },
    'voice-input': { label: '语音输入（Web Speech）', category: '音频语音', tags: ['语音输入', '音频', '输入增强'], capability: '输入框麦克风按钮，浏览器语音识别填充草稿，可选自动发送', boundary: '仅浏览器 Web Speech，无本地识别' },
    'voice': { label: '语音输入（sherpa-onnx）', category: '音频语音', tags: ['语音输入', '音频', '输入增强'], capability: '麦克风按钮 + Ctrl+Space，可选本地 sherpa-onnx 识别', boundary: '需额外配置本地模型' },
    'dsh-window-kit': { label: 'Windows 原生桌面窗口', category: '桌面窗口', tags: ['桌面', '窗口', '工具'], capability: 'desktop_launch 工具，自动安装 WebView2 桌面窗口 + 快捷方式', boundary: '仅 Windows' },
    'deepeye-vision': { label: 'DeepEye 视觉（GLM-4V）', category: '视觉多模态', tags: ['视觉', '多模态', 'OCR', '工具'], capability: 'vision_describe/ocr/ask/layout/clipboard 看图与 OCR', boundary: '依赖智谱 GLM-4V-Flash 与 API Key' },
    'describe-image': { label: '图片描述工具', category: '视觉多模态', tags: ['视觉', '多模态', '工具'], capability: 'describe_image 工具：看图、OCR、图表、截图、翻译', boundary: '走统一图片描述管线' },
    'modlens': { label: 'Modlens 视觉', category: '视觉多模态', tags: ['视觉', '多模态', 'OCR', '工具'], capability: 'modlens_read_image：Antigravity CLI 看图 + OCR', boundary: '依赖 Antigravity CLI 引擎' },
    'dsh-context': { label: '上下文洞察', category: '调试监控', tags: ['上下文', '调试', '面板'], capability: '上下文窗口组成、历史、压缩、注入、模型切换可视化', boundary: '只读分析，不修改上下文' },
    'shortcuts': { label: '键盘快捷键', category: '输入增强', tags: ['快捷键', '效率', '输入增强'], capability: '34 个预注册功能 + 自定义快捷键录制', boundary: '仅键盘操作' },
    'dsh-market': { label: '插件市场', category: '插件管理', tags: ['插件管理', '市场', '安装'], capability: '浏览 / 搜索 / 一键安装社区插件', boundary: '市场安装，不含启停' },
    'plugin-console': { label: '插件控制台', category: '插件管理', tags: ['插件管理', '启停', '安装'], capability: '一键启用/停用插件，安装 GitHub 插件', boundary: '会写组合补丁' },
    'ui-web-ui-compat': { label: 'Web UI 兼容层', category: '系统', tags: ['系统', '兼容'], capability: 'web-ui-all 的桥接兼容层', boundary: '内部依赖' },
    'ui-web-ui-settings': { label: 'Web UI 设置', category: '设置界面', tags: ['设置', 'UI'], capability: 'Web UI 聚合插件专属设置页', boundary: '' },
    'ui-dsh-aionui-panel': { label: 'AionUI 右侧面板', category: '面板文件', tags: ['面板', '文件', '预览', 'SCM', 'UI'], capability: '右侧预览/文件树/变更面板，markdown/html/diff/csv/pdf 预览', boundary: '占用右侧详情列' },
    'ui-task-board': { label: '任务看板', category: '效率', tags: ['任务', '看板', '定时', '效率'], capability: '多列看板 + cron 定时执行任务', boundary: '浏览器端调度，需标签页打开' },
    'ui-git-graph': { label: 'Git 图', category: '开发工具', tags: ['Git', '可视化'], capability: 'Git 提交图可视化', boundary: '' },
    'pet': { label: '桌面宠物', category: '娱乐', tags: ['娱乐', '宠物'], capability: '桌面宠物', boundary: '' },
    'remote-web-ui': { label: '远程 Web UI', category: '远程', tags: ['远程', '网络'], capability: '远程 Web UI 访问', boundary: '' },
    'live-stats': { label: '实时统计', category: '监控', tags: ['统计', '监控'], capability: '实时统计显示', boundary: '' },
    'ssh': { label: 'SSH 远程运维', category: '远程运维', tags: ['SSH', '远程', '运维', '部署'], capability: '持久连接池、ssh_exec/upload/download/tunnel/cluster、Web 终端', boundary: '主机需用户在 GUI 配置' },
    'liangshen': { label: '梁神模式（Agent 预设）', category: 'Agent预设', tags: ['Agent预设', '模式', '锚定'], capability: '两阶段锚定 Minimal → Code Mode 的 agent preset', boundary: '默认预设由用户选择' },
    'ui-skin-center': { label: '皮肤中心', category: '皮肤主题', tags: ['皮肤', '主题', 'UI'], capability: '皮肤全家桶管理', boundary: '' },
    'dsh-minigames': { label: '小游戏面板', category: '娱乐', tags: ['娱乐', '游戏'], capability: '18 款离线小游戏右侧面板', boundary: '' },
    'dsh-zh': { label: '中文增强', category: '本地化', tags: ['本地化', '中文', 'UI'], capability: '中文界面修正、术语统一、统计行、中文优先提示', boundary: '' },
    'prompt-manager': { label: 'Lorebook 创作', category: '创作', tags: ['世界书', '角色卡', '创作', '提示词'], capability: '导入角色卡/世界书、Markdown lore、小说生成', boundary: '' },
    'better-sidebar': { label: 'VSCode 风格侧边栏', category: '面板文件', tags: ['侧边栏', '文件', '终端', 'Git', '面板', 'UI'], capability: 'explorer/editor/terminal/git/browser 右侧边栏，按会话隔离', boundary: '占用右侧详情列' },
  },
  overlaps: [
    { id: 'vision', label: '视觉 / 多模态（看图 · OCR）', tag: '视觉', entries: ['deepeye-vision', 'modlens', 'describe-image'], note: '多个看图/OCR 插件同时启用会导致工具冗余，建议只保留一个' },
    { id: 'voice-input', label: '语音输入（麦克风）', tag: '语音输入', entries: ['voice', 'voice-input'], note: '两个麦克风按钮会同时出现在输入框，容易冲突' },
    { id: 'right-panel', label: '右侧面板 / 文件管理', tag: '面板', entries: ['better-sidebar', 'ui-dsh-aionui-panel'], note: '两者都占用右侧详情/侧边栏区域，会互相遮挡' },
    { id: 'plugin-manager', label: '插件管理 / 市场', tag: '插件管理', entries: ['dsh-market', 'plugin-console'], note: '两个管理器都会读写组合补丁，可能互相覆盖' },
  ],
  compatRules: [
    { id: 'coexist-voice', type: 'coexistence', severity: 'medium', confidence: 'known', entries: ['voice', 'voice-input'], title: '语音输入插件并存', desc: 'voice 与 voice-input 都会在输入框挂载麦克风按钮，同时启用会出现两个麦克风入口与快捷键（Ctrl+Space）冲突。', evidence: '两者都声明 dsh.client 并注册 composer 输入区。', fixes: [
      { id: 'fix-voice-a', action: 'disable', target: 'voice-input', label: '停用「语音输入(Web Speech)」，保留 sherpa-onnx 本地识别' },
      { id: 'fix-voice-b', action: 'disable', target: 'voice', label: '停用「语音输入(sherpa-onnx)」，保留 Web Speech' },
    ] },
    { id: 'coexist-vision', type: 'coexistence', severity: 'medium', confidence: 'known', entries: ['deepeye-vision', 'modlens', 'describe-image'], title: '视觉/多模态插件并存', desc: '三个插件都注册看图类工具（vision_*、modlens_read_image、describe_image），功能重叠、消耗重复资源，可能引起工具选择混乱。', evidence: '当前运行时三个工具族同时可见。', fixes: [
      { id: 'fix-vision-a', action: 'disable', target: 'modlens', label: '停用 Modlens，保留 DeepEye + 图片描述' },
      { id: 'fix-vision-b', action: 'disable', target: 'deepeye-vision', label: '停用 DeepEye，保留 Modlens' },
    ] },
    { id: 'coexist-panel', type: 'coexistence', severity: 'high', confidence: 'known', entries: ['better-sidebar', 'ui-dsh-aionui-panel'], title: '右侧面板占用冲突', desc: 'better-sidebar 与 AionUI 面板都占用右侧详情列，同时启用会互相遮挡或覆盖。', evidence: '两者都注入 conversation 右侧详情区 Slot。', fixes: [
      { id: 'fix-panel-a', action: 'disable', target: 'ui-dsh-aionui-panel', label: '停用 AionUI 面板，保留 VSCode 侧边栏' },
      { id: 'fix-panel-b', action: 'disable', target: 'better-sidebar', label: '停用 VSCode 侧边栏，保留 AionUI 面板' },
    ] },
    { id: 'coexist-manager', type: 'coexistence', severity: 'medium', confidence: 'known', entries: ['dsh-market', 'plugin-console'], title: '插件管理器并存', desc: '插件市场与插件控制台都会读写组合补丁文件，同时启用可能产生互相覆盖的启停操作。', evidence: '两者都声明插件管理能力。', fixes: [
      { id: 'fix-manager-a', action: 'disable', target: 'plugin-console', label: '停用插件控制台，保留插件市场' },
      { id: 'fix-manager-b', action: 'disable', target: 'dsh-market', label: '停用插件市场，保留插件控制台' },
    ] },
  ],
}

const BASE_BUNDLES = ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app']

// ===================== 工具函数 =====================
function parentDir(p) { const i = Math.max(String(p).lastIndexOf('\\'), String(p).lastIndexOf('/')); return i < 0 ? String(p) : String(p).slice(0, i) }
function dirname(p) { const i = Math.max(String(p).lastIndexOf('\\'), String(p).lastIndexOf('/')); return i < 0 ? '.' : String(p).slice(0, i) }
function humanLabel(name) { const s = String(name || ''); const i = s.lastIndexOf('/'); return i >= 0 ? s.slice(i + 1) : s }
function timeCategory(epoch) {
  const now = Date.now()
  const diff = now - epoch
  const DAY = 86400000
  if (diff < DAY) return '今日'
  if (diff < 3 * DAY) return '三天内'
  if (diff < 7 * DAY) return '一周内'
  if (diff < 30 * DAY) return '一月内'
  return '更早'
}
function compareVersion(a, b) {
  const pa = String(a || '0').split('.').map(function (n) { const m = String(n).match(/\d+/); return m ? parseInt(m[0], 10) : 0 })
  const pb = String(b || '0').split('.').map(function (n) { const m = String(n).match(/\d+/); return m ? parseInt(m[0], 10) : 0 })
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0
    if (x !== y) return x > y ? 1 : -1
  }
  return 0
}
function repoFromUrl(repo) {
  if (repo && repo.url) {
    const m = String(repo.url).match(/github\.com[:/]([^/]+\/[^/.]+?)(?:\.git)?$/i)
    if (m) return m[1]
  }
  return null
}

function parsePatch(text) {
  const lines = String(text || '').split(/\r?\n/)
  const header = []; const blocks = []; let cur = null
  const flush = function () { if (cur) { blocks.push(cur); cur = null } }
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    if (/^-\s/.test(line)) { flush(); cur = { lines: [line] } }
    else if (cur) { cur.lines.push(line) }
    else { header.push(line) }
  }
  flush()
  return { header: header, blocks: blocks }
}
function blockId(block) { const m = block.lines[0].match(/-\s*id:\s*['"]?([^'"\s]+)['"]?/); return m ? m[1] : null }
function serializePatch(parsed) { const parts = parsed.header.slice(); for (const b of parsed.blocks) for (const l of b.lines) parts.push(l); return parts.join('\n') }
function setEntryDisabled(parsed, entryId, disabled) {
  let found = null
  for (const b of parsed.blocks) { if (blockId(b) === entryId) { found = b; break } }
  if (!found) {
    if (disabled === true) { parsed.blocks.push({ lines: ['- id: ' + entryId, '  disabled: true'] }); return true }
    return false
  }
  const before = found.lines.join('\n')
  let idx = -1
  for (let i = 0; i < found.lines.length; i++) { if (/^\s*disabled\s*:/.test(found.lines[i])) { idx = i; break } }
  const indentMatch = found.lines[0].match(/^(\s*)/)
  const subIndent = (indentMatch ? indentMatch[1] : '') + '  '
  if (disabled === true) {
    if (idx >= 0) found.lines[idx] = subIndent + 'disabled: true'
    else found.lines.splice(1, 0, subIndent + 'disabled: true')
  } else {
    if (idx >= 0) found.lines.splice(idx, 1)
    if (found.lines.length === 1) { const i2 = parsed.blocks.indexOf(found); if (i2 >= 0) parsed.blocks.splice(i2, 1) }
  }
  return found.lines.join('\n') !== before || parsed.blocks.indexOf(found) < 0
}
function readDisabledMap(text) {
  const map = {}
  const parsed = parsePatch(text)
  for (const b of parsed.blocks) {
    const id = blockId(b)
    if (id == null) continue
    let disabled = false
    for (const l of b.lines) { if (/^\s*disabled\s*:\s*true\s*$/.test(l)) disabled = true }
    if (disabled) map[id] = true
  }
  return map
}
function extractInsertedIds(text) {
  const ids = []
  const lines = String(text || '').split(/\r?\n/)
  let inInsert = false
  for (const line of lines) {
    if (/^\s*-\s*insert\s*:/.test(line)) { inInsert = true; continue }
    if (inInsert) {
      const m = line.match(/^\s*-\s*id:\s*['"]?([^'"\s]+)['"]?/)
      if (m) { ids.push(m[1]); continue }
      if (/^\s*-/.test(line)) inInsert = false
    }
  }
  return ids
}
function parseInsertRows(text) {
  const rows = []
  const lines = String(text || '').split(/\r?\n/)
  let inInsert = false; let pending = null
  const flush = function () { if (pending && pending.id && !pending.group) rows.push({ id: pending.id, name: pending.name }); pending = null }
  for (const line of lines) {
    if (/^-\s*insert\s*:/.test(line)) { flush(); inInsert = true; pending = null; continue }
    if (!inInsert) continue
    if (/^-\s*id\s*:/.test(line)) { inInsert = false; flush(); pending = null; continue }
    const m = line.match(/^\s+-\s*id:\s*['"]?([^'"\s]+)['"]?/)
    if (m) { flush(); pending = { id: m[1], name: null, group: false }; continue }
    const nm = line.match(/^\s*name:\s*['"]?([^'"\s]+)['"]?/)
    if (nm && pending) { pending.name = nm[1]; continue }
    if (pending && /^\s*group\s*:\s*true\s*$/.test(line)) { pending.group = true; continue }
  }
  flush()
  return rows
}
function mergeConfig(base, user) {
  if (!user || typeof user !== 'object') return base
  const out = {}
  out.protected = Array.isArray(user.protected) ? user.protected : (base.protected || [])
  const bp = (base && base.plugins && typeof base.plugins === 'object') ? base.plugins : {}
  const up = (user.plugins && typeof user.plugins === 'object') ? user.plugins : {}
  out.plugins = {}
  for (const k in bp) out.plugins[k] = bp[k]
  for (const k in up) out.plugins[k] = up[k]
  out.overlaps = Array.isArray(user.overlaps) ? user.overlaps : (base.overlaps || [])
  out.compatRules = Array.isArray(user.compatRules) ? user.compatRules : (base.compatRules || [])
  return out
}
function genericTags(keywords) {
  const tags = []
  const kws = (keywords || []).map(function (k) { return String(k).toLowerCase() })
  const has = function (t) { return kws.indexOf(t) >= 0 }
  if (has('vision') || has('ocr') || has('multimodal') || has('image')) tags.push('视觉')
  if (has('voice') || has('tts') || has('audio') || has('speech')) tags.push('音频')
  if (has('ssh') || has('remote')) tags.push('远程')
  if (has('git')) tags.push('Git')
  if (has('terminal')) tags.push('终端')
  if (has('market') || has('marketplace') || has('plugin-manager')) tags.push('插件管理')
  if (has('skin') || has('theme')) tags.push('皮肤')
  if (has('task') || has('board')) tags.push('任务')
  if (has('shortcut') || has('hotkey')) tags.push('快捷键')
  if (has('context')) tags.push('上下文')
  if (has('lorebook') || has('world-info') || has('tavern')) tags.push('世界书')
  return tags
}
function detectExistenceConflicts(profilePatchText, bundleEntryIds) {
  const conflicts = []
  const insertedIds = extractInsertedIds(profilePatchText)
  for (const id of insertedIds) {
    if (bundleEntryIds[id]) {
      conflicts.push({
        id: 'exist-double-' + id, type: 'existence', severity: 'high', confidence: 'structural',
        entries: [id], triggeredEntries: [id],
        title: '插件双重挂载（存在性冲突）',
        desc: '「' + id + '」同时通过 bundle 通道（' + bundleEntryIds[id] + '）和 profile 补丁手动 insert 挂载，会导致两个宿主实例 / 两个界面实例。',
        evidence: 'profile cordis.patch.yml 中存在对已安装 bundle 条目的手动 insert。',
        fixes: [{ id: 'fix-double-' + id, action: 'manual', target: id, label: '从 profile 补丁中移除「' + id + '」的手动 insert 行，仅保留 bundle 通道' }],
      })
    }
  }
  return conflicts
}

return {
  apply(ctx) {
    const fs = ctx.get('fs')
    const cm = ctx.get('clientModules')
    const tg = ctx.get('typertGateway')
    const settings = ctx.get('settings')
    const web = ctx.get('web')
    let cachedState = { markedFailed: [], installTimes: {}, stars: {}, usage: {} }
    let stateLoaded = false

    async function resolvePaths() {
      let profileRoot, home
      if (cm) {
        try {
          const g = cm.graph()
          const entries = (g && g.entries) || []
          for (const e of entries) {
            const cp = cm.clientPath(e.id)
            if (cp) {
              const n = String(cp).replace(/\\/g, '/')
              const i = n.indexOf('/node_modules/')
              if (i >= 0) {
                profileRoot = n.slice(0, i)
                const j = n.indexOf('/profiles/')
                home = j >= 0 ? n.slice(0, j) : parentDir(parentDir(profileRoot))
                break
              }
            }
          }
        } catch (err) { console.error('resolvePaths/clientModules:', err && err.message) }
      }
      if (!profileRoot && settings) {
        try { const doc = await settings.prepareDocument(); if (doc) { home = parentDir(doc); profileRoot = home + '/profiles/web' } } catch (err) { console.error('resolvePaths/settings:', err && err.message) }
      }
      return { profileRoot: profileRoot, home: home }
    }
    async function readFile(path) { const t = await fs.resolve(path); return await fs.readText(t) }
    async function resolveWritePolicy() {
      const sp = ctx.get('sandboxPolicy')
      if (!sp) return undefined
      const agents = ctx.get('agents')
      let session
      if (agents) { try { const a = agents.currentInitiator(); session = a && a.session } catch (e) {} }
      return sp.resolve(session ? { session } : {})
    }
    async function writeFile(path, content) {
      const t = await fs.resolve(path)
      const policy = await resolveWritePolicy()
      return await fs.writeText(t, content, undefined, undefined, policy)
    }
    async function getInventory() {
      if (!tg) return null
      try { const r = await tg.invoke({ namespace: 'pluginInventory', method: 'list', args: {} }); if (r && Array.isArray(r.entries)) return r.entries; return null } catch (err) { return null }
    }
    function getClientGraphIds() {
      const ids = new Set()
      if (!cm) return ids
      try { const g = cm.graph(); if (g && Array.isArray(g.entries)) for (const e of g.entries) if (e && e.id) ids.add(e.id) } catch (err) {}
      return ids
    }

    async function loadConfig(home) {
      let config = DEFAULT_CONFIG
      if (home) {
        try { const text = await readFile(home + '/dsh-plugin-integration.json'); config = mergeConfig(DEFAULT_CONFIG, JSON.parse(text)) } catch (err) {}
      }
      return config
    }
    async function loadState(home) {
      const base = { markedFailed: [], installTimes: {}, stars: {}, usage: {} }
      if (!home) return base
      try {
        const text = await readFile(home + '/dsh-plugin-integration.state.json')
        const s = JSON.parse(text)
        return {
          markedFailed: Array.isArray(s.markedFailed) ? s.markedFailed : [],
          installTimes: (s.installTimes && typeof s.installTimes === 'object') ? s.installTimes : {},
          stars: (s.stars && typeof s.stars === 'object') ? s.stars : {},
          usage: (s.usage && typeof s.usage === 'object') ? s.usage : {},
        }
      } catch (err) { return base }
    }
    async function saveState(home, st) {
      if (!home) return
      try { await writeFile(home + '/dsh-plugin-integration.state.json', JSON.stringify({ markedFailed: st.markedFailed || [], installTimes: st.installTimes || {}, stars: st.stars || {}, usage: st.usage || {} }, null, 2)) } catch (err) { console.error('saveState:', err && err.message) }
    }
    async function getState(home) {
      if (!stateLoaded) { cachedState = await loadState(home); stateLoaded = true }
      return cachedState
    }
    function ensureInstallTime(st, key) {
      if (!st.installTimes[key]) st.installTimes[key] = Date.now()
      return st.installTimes[key]
    }

    async function resolveBundle(profileRoot, bundleName) {
      const pkgPath = profileRoot + '/node_modules/' + bundleName + '/package.json'
      let pkg
      try { pkg = JSON.parse(await readFile(pkgPath)) } catch (err) { return null }
      const entries = []
      const patchRel = pkg.dsh && pkg.dsh.bundle && pkg.dsh.bundle.patch
      if (patchRel) {
        const rel = String(patchRel).replace(/^\.\//, '')
        try { const patchText = await readFile(dirname(pkgPath) + '/' + rel); for (const ins of parseInsertRows(patchText)) entries.push({ entryId: ins.id, moduleName: ins.name || bundleName }) } catch (err) {}
      }
      if (entries.length === 0) entries.push({ entryId: bundleName, moduleName: bundleName })
      return { bundle: bundleName, name: pkg.name || bundleName, description: pkg.description || '', keywords: pkg.keywords || [], version: pkg.version || '', repository: pkg.repository || null, entries: entries, pkgPath: pkgPath }
    }

    async function discoverBundles(profileRoot) {
      const discovered = []
      let pkgText = ''
      try { pkgText = await readFile(profileRoot + '/package.json') } catch (err) {}
      let bundles = []
      try { const pkg = JSON.parse(pkgText); const dsh = pkg && pkg.dsh; if (dsh && dsh.profile && Array.isArray(dsh.profile.bundles)) bundles = dsh.profile.bundles } catch (err) {}
      for (let i = 0; i < bundles.length; i++) {
        const bundleName = bundles[i]
        if (BASE_BUNDLES.indexOf(bundleName) >= 0) continue
        const info = await resolveBundle(profileRoot, bundleName)
        if (info) { info.installIndex = i; discovered.push(info) }
      }
      return discovered
    }

    function infoFor(entryId, config, meta) {
      const known = config.plugins && config.plugins[entryId]
      if (known) return known
      if (entryId && String(entryId).indexOf('ui-skin-') === 0) return { label: '皮肤：' + String(entryId).replace(/^ui-skin-/,''), category: '皮肤主题', tags: ['皮肤','主题','UI'], capability: '皮肤主题（由皮肤中心管理）', boundary: '' }
      return { label: humanLabel(meta && meta.name) || entryId, category: '其他', tags: genericTags(meta && meta.keywords), capability: (meta && meta.description) || '', boundary: '' }
    }

    async function analyzeFailure(entryId) {
      const paths = await resolvePaths()
      const config = await loadConfig(paths.home)
      const discovered = await discoverBundles(paths.profileRoot)
      let foundEntry = null, foundBundle = null
      for (const b of discovered) { for (const e of b.entries) { if (e.entryId === entryId) { foundEntry = e; foundBundle = b; break } } if (foundEntry) break }
      if (!foundEntry) return { ok: false, entryId: entryId, error: '未找到插件 ' + entryId }
      const moduleName = foundEntry.moduleName || foundBundle.name || ''
      const label = (function () { const c = config.plugins && config.plugins[entryId]; return c ? c.label : humanLabel(foundBundle.name) })()
      const reasons = []
      const evidence = []
      const fixPlans = []
      let profilePatchText = '', homePatchText = ''
      try { profilePatchText = await readFile(paths.profileRoot + '/cordis.patch.yml') } catch (err) {}
      try { homePatchText = await readFile(paths.home + '/cordis.patch.yml') } catch (err) {}
      const dProfile = readDisabledMap(profilePatchText)
      const dHome = readDisabledMap(homePatchText)
      const isDisabled = !!(dProfile[entryId] || dHome[entryId])
      let pkg = null
      try { pkg = JSON.parse(await readFile(foundBundle.pkgPath)) } catch (err) {}
      const hasClientDecl = !!(pkg && pkg.dsh && pkg.dsh.client && pkg.dsh.client.platform === 'web')
      let clientExists = false
      if (moduleName && cm) { try { clientExists = !!cm.clientPath(moduleName) } catch (err) {} }
      const inGraph = moduleName ? getClientGraphIds().has(moduleName) : false
      let fiberPhase = null
      const inv = await getInventory()
      if (inv) { const invE = inv.find(function (e) { return e.entryId === entryId }); if (invE) fiberPhase = invE.fiberPhase }
      let status
      if (isDisabled) {
        status = 'disabled'
        reasons.push('该插件已被停用（' + (dProfile[entryId] ? 'profile 补丁' : 'home 补丁') + ' 中 disabled: true）')
        evidence.push('cordis.patch.yml 存在 disabled 行')
        fixPlans.push({ action: 'enable', target: entryId, label: '启用该插件', impact: '重启 DSH 后生效，恢复该插件全部功能' })
      } else if (fiberPhase === 'failed') {
        status = 'failed'
        reasons.push('运行时加载失败（fiberPhase=failed）')
        evidence.push('loader 报告 fiber 阶段为 failed')
        fixPlans.push({ action: 'inspect', label: '查看宿主日志定位加载错误', impact: '修复加载错误后重启恢复' })
      } else if (!hasClientDecl) {
        status = 'inactive'
        reasons.push('该插件为 host-only（无 dsh.client 浏览器端声明），属正常情况，非失效')
        evidence.push('package.json 无 dsh.client.web 声明')
        fixPlans.push({ action: 'none', label: '无需处理', impact: '无' })
      } else if (!clientExists) {
        status = 'inactive'
        reasons.push('声明了 dsh.client，但客户端 bundle 未构建（缺少 ./client 产物）')
        evidence.push('exports["./client"] 指向的 bundle 文件不存在')
        fixPlans.push({ action: 'rebuild', label: '在插件目录执行 pnpm run build', impact: '重新构建后浏览器端恢复' })
      } else if (!inGraph) {
        status = 'inactive'
        reasons.push('客户端 bundle 存在但未进入生效图（可能被 patch 停用或未满足加载条件）')
        evidence.push('clientModules.graph() 中不存在该模块')
        fixPlans.push({ action: 'enable', target: entryId, label: '确认未 disabled 且 bundle 已构建，必要时启用', impact: '重启后生效' })
      } else {
        status = 'active'
        reasons.push('未发现明确失效原因：客户端已生效。若实际不可用，可能是功能层面部分失效（工具/Slot 被其它插件覆盖）')
        evidence.push('客户端 bundle 已在生效图中')
        fixPlans.push({ action: 'check-overlap', label: '查看「重叠切换」与「兼容检测」确认是否被覆盖', impact: '若重叠则切换/停用冲突方' })
      }
      return { ok: true, entryId: entryId, label: label, moduleName: moduleName, status: status, reasons: reasons, evidence: evidence, fixPlans: fixPlans }
    }

    async function markFailed(entryId) {
      if (!entryId) return { ok: false, error: '缺少 entryId' }
      const paths = await resolvePaths()
      const st = await getState(paths.home)
      if (st.markedFailed.indexOf(entryId) < 0) st.markedFailed.push(entryId)
      await saveState(paths.home, st)
      const analysis = await analyzeFailure(entryId)
      return { ok: true, entryId: entryId, message: '已标记为失效', analysis: analysis }
    }

    async function unmarkFailed(entryId) {
      if (!entryId) return { ok: false, error: '缺少 entryId' }
      const paths = await resolvePaths()
      const st = await getState(paths.home)
      st.markedFailed = st.markedFailed.filter(function (id) { return id !== entryId })
      await saveState(paths.home, st)
      return { ok: true, entryId: entryId, message: '已取消失效判定' }
    }

    async function detectFailures(entryIds) {
      let ids = entryIds
      if (!Array.isArray(ids) || ids.length === 0) {
        const paths = await resolvePaths()
        const st = await getState(paths.home)
        const marked = new Set(st.markedFailed)
        const data = await analyze()
        ids = data.plugins.filter(function (p) { return marked.has(p.entryId) || p.status === 'inactive' || p.status === 'failed' }).map(function (p) { return p.entryId })
      }
      const results = []
      for (const id of ids) results.push(await analyzeFailure(id))
      return { ok: true, results: results }
    }

    // 一键修复：对所有失效/可疑插件，应用其可自动修复的修复方案（action=enable）
    async function fixAllFailures() {
      const paths = await resolvePaths()
      const config = await loadConfig(paths.home)
      const st = await getState(paths.home)
      const marked = new Set(st.markedFailed)
      const data = await analyze()
      const ids = data.plugins.filter(function (p) { return marked.has(p.entryId) || p.status === 'inactive' || p.status === 'failed' }).map(function (p) { return p.entryId })
      const results = []
      for (const id of ids) {
        const a = await analyzeFailure(id)
        const enableFix = (a && a.fixPlans || []).find(function (f) { return f.action === 'enable' && f.target })
        if (enableFix) {
          const r = await applyToggle(enableFix.target, true)
          results.push({ entryId: id, label: a.label, fixed: !!(r && r.ok), message: (r && (r.message || r.error)) || '' })
        } else {
          results.push({ entryId: id, label: a.label, fixed: false, message: '需手动修复' })
        }
      }
      const fixedCount = results.filter(function (r) { return r.fixed }).length
      return { ok: true, results, fixedCount, total: results.length }
    }

    async function refreshStars() {
      const paths = await resolvePaths()
      const config = await loadConfig(paths.home)
      const st = await getState(paths.home)
      const discovered = await discoverBundles(paths.profileRoot)
      const results = []
      for (const b of discovered) {
        for (const e of b.entries) {
          const entryId = e.entryId
          const cfg = config.plugins && config.plugins[entryId]
          const repo = (cfg && cfg.repo) || repoFromUrl(b.repository)
          if (!repo) { results.push({ entryId: entryId, label: (cfg && cfg.label) || humanLabel(b.name), repo: null, stars: null, error: '未配置 GitHub 仓库' }); continue }
          if (!web) { results.push({ entryId: entryId, label: (cfg && cfg.label) || humanLabel(b.name), repo: repo, stars: null, error: 'web 服务不可用' }); continue }
          try {
            const res = await web.fetch({ url: 'https://api.github.com/repos/' + repo })
            if (res.statusCode === 200 && res.body && res.body.content) {
              const data = JSON.parse(res.body.content)
              const n = typeof data.stargazers_count === 'number' ? data.stargazers_count : null
              if (n !== null) { st.stars[entryId] = n; results.push({ entryId: entryId, label: (cfg && cfg.label) || humanLabel(b.name), repo: repo, stars: n }) }
              else results.push({ entryId: entryId, label: (cfg && cfg.label) || humanLabel(b.name), repo: repo, stars: null, error: '响应缺 stargazers_count' })
            } else {
              results.push({ entryId: entryId, label: (cfg && cfg.label) || humanLabel(b.name), repo: repo, stars: null, error: 'HTTP ' + res.statusCode })
            }
          } catch (err) {
            results.push({ entryId: entryId, label: (cfg && cfg.label) || humanLabel(b.name), repo: repo, stars: null, error: (err && err.message) || String(err) })
          }
        }
      }
      await saveState(paths.home, st)
      return { ok: true, results: results }
    }

    async function predictUpdateConflicts(entryIds) {
      const ids = entryIds || []
      const paths = await resolvePaths()
      const config = await loadConfig(paths.home)
      const data = await analyze()
      const plugins = data.plugins
      const enabledSet = new Set(plugins.filter(function (p) { return p.enabled }).map(function (p) { return p.entryId }))
      const targets = new Set(ids)
      const warnings = []
      // 1. 更新目标是否参与兼容规则
      for (const r of (config.compatRules || [])) {
        const involved = r.entries.filter(function (id) { return targets.has(id) })
        if (involved.length > 0 && r.entries.some(function (id) { return enabledSet.has(id) })) {
          warnings.push({ kind: 'rule', ruleId: r.id, title: r.title, desc: '更新涉及「' + r.title + '」规则，更新后该插件与组内其它插件（' + r.entries.join(', ') + '）的兼容关系可能变化。', severity: r.severity })
        }
      }
      // 2. 更新目标是否处于重叠组
      for (const o of (config.overlaps || [])) {
        const involved = o.entries.filter(function (id) { return targets.has(id) })
        if (involved.length > 0) {
          warnings.push({ kind: 'overlap', overlapId: o.id, title: o.label, desc: '更新涉及「' + o.label + '」重叠组（' + o.entries.join(', ') + '），更新后生效主体可能变化。', severity: 'medium' })
        }
      }
      // 3. 更新目标是否被保护
      for (const id of ids) { if ((config.protected || []).indexOf(id) >= 0) warnings.push({ kind: 'protected', title: '受保护条目', desc: '「' + id + '」为核心受保护条目，更新需格外谨慎。', severity: 'high' }) }
      return { ok: true, warnings: warnings, updateTargets: ids }
    }

    // ===== 用量统计（实时统计工具调用次数 + 估算 token 消耗） =====
    function estimateTokens(str) {
      const s = String(str == null ? '' : str)
      if (!s) return 0
      const ascii = (s.match(/[\x00-\x7f]/g) || []).length
      const other = s.length - ascii
      return Math.ceil(ascii / 4) + Math.ceil(other / 2)
    }
    function toolToEntryId(toolName) {
      const t = String(toolName || '')
      const exact = { 'describe_image': 'describe-image', 'desktop_launch': 'dsh-window-kit', 'plugin_integration': 'plugin-integration' }
      if (exact[t]) return exact[t]
      const prefixes = [['ssh_', 'ssh'], ['vision_', 'deepeye-vision'], ['modlens_', 'modlens'], ['prompt_', 'prompt-manager'], ['viking_', 'openviking-memory-runtime']]
      for (const p of prefixes) if (t.startsWith(p[0])) return p[1]
      return null
    }
    async function recordUsage(name, args, result) {
      const paths = await resolvePaths()
      const st = await getState(paths.home)
      // 跨 realm：直接用 JSON.stringify 串行化宿主对象（避免跨 realm 的 .map/.join）
      let argsStr = ''
      let contentStr = ''
      try { argsStr = JSON.stringify(args == null ? null : args) } catch (err) {}
      try { contentStr = JSON.stringify(result && result.content) } catch (err) {}
      const tokens = estimateTokens(argsStr) + estimateTokens(contentStr)
      const rec = st.usage[name] || { calls: 0, tokens: 0 }
      rec.calls += 1
      rec.tokens += tokens
      st.usage[name] = rec
      saveState(paths.home, st)
    }
    async function getUsage() {
      const paths = await resolvePaths()
      await loadConfig(paths.home)
      const st = await getState(paths.home)
      const byTool = Object.keys(st.usage || {}).sort().map(function (name) {
        const u = st.usage[name] || { calls: 0, tokens: 0 }
        return { tool: name, calls: u.calls || 0, tokens: u.tokens || 0, entryId: toolToEntryId(name) }
      })
      const byPluginMap = {}
      for (const t of byTool) {
        const key = t.entryId || '__unmapped__'
        const g = byPluginMap[key] || { entryId: t.entryId, calls: 0, tokens: 0, tools: [] }
        g.calls += t.calls; g.tokens += t.tokens; g.tools.push(t.tool)
        byPluginMap[key] = g
      }
      const byPlugin = Object.keys(byPluginMap).sort().map(function (k) {
        const g = byPluginMap[k]
        const label = g.entryId ? ((config.plugins && config.plugins[g.entryId] && config.plugins[g.entryId].label) || g.entryId) : '未归属'
        return { entryId: g.entryId, label: label, calls: g.calls, tokens: g.tokens, tools: g.tools }
      })
      const totalCalls = byTool.reduce(function (a, t) { return a + t.calls }, 0)
      const totalTokens = byTool.reduce(function (a, t) { return a + t.tokens }, 0)
      return { ok: true, byTool, byPlugin, summary: { totalCalls, totalTokens } }
    }
    async function clearUsage() {
      const paths = await resolvePaths()
      const st = await getState(paths.home)
      st.usage = {}
      await saveState(paths.home, st)
      return { ok: true, message: '已清空用量统计' }
    }
    ctx.on('tools/execute', async function (exec, next) {
      const result = await next()
      try { await recordUsage(exec.name, exec.arguments, result) } catch (err) { console.error('recordUsage:', err && err.message) }
      return result
    })

    async function analyze() {
      const result = {
        ok: true, profile: { root: null, patchPath: null, homePatchPath: null },
        summary: { total: 0, enabled: 0, disabled: 0, active: 0, failed: 0, conflicts: 0, coexistenceConflicts: 0, existenceConflicts: 0, overlapGroups: 0, protectedCount: 0, unknownCount: 0, markedFailedCount: 0, pendingUpdateCount: 0 },
        plugins: [], tagGroups: [], overlaps: [], conflicts: [], failedPlugins: [], warnings: [],
      }
      if (!fs) { result.ok = false; result.warnings.push('fs 服务不可用'); return result }
      const paths = await resolvePaths()
      const profileRoot = paths.profileRoot
      const home = paths.home
      result.profile.root = profileRoot
      result.profile.patchPath = profileRoot ? profileRoot + '/cordis.patch.yml' : null
      result.profile.homePatchPath = home ? home + '/cordis.patch.yml' : null
      if (!profileRoot) { result.ok = false; result.warnings.push('无法解析 profile 路径'); return result }

      const config = await loadConfig(home)
      const st = await getState(home)
      const markedSet = new Set(st.markedFailed)

      let profilePatchText = '', homePatchText = ''
      try { profilePatchText = await readFile(profileRoot + '/cordis.patch.yml') } catch (err) {}
      try { homePatchText = await readFile(home + '/cordis.patch.yml') } catch (err) {}
      const disabledByProfile = readDisabledMap(profilePatchText)
      const disabledByHome = readDisabledMap(homePatchText)

      const discovered = await discoverBundles(profileRoot)
      const bundleEntryIds = {}
      for (const b of discovered) for (const e of b.entries) bundleEntryIds[e.entryId] = b.bundle

      const inv = await getInventory()
      const invByEntry = {}
      if (inv) for (const e of inv) invByEntry[e.entryId] = e
      const clientIds = getClientGraphIds()

      const plugins = []
      const seen = {}
      let unknownCount = 0
      let pendingUpdateCount = 0
      for (const b of discovered) {
        const installEpoch = ensureInstallTime(st, b.bundle)
        const repo = repoFromUrl(b.repository)
        for (const e of b.entries) {
          const entryId = e.entryId
          const moduleName = e.moduleName || b.name || ''
          const info = infoFor(entryId, config, b)
          const isKnown = !!(config.plugins && config.plugins[entryId])
          if (!isKnown) unknownCount++
          const invE = invByEntry[entryId] || null
          const enabled = invE ? !!invE.enabled : (!disabledByProfile[entryId] && !disabledByHome[entryId])
          const fiberPhase = invE ? invE.fiberPhase : null
          const activeClient = moduleName ? clientIds.has(moduleName) : false
          const disabledBy = []
          if (disabledByProfile[entryId]) disabledBy.push('profile-patch')
          if (disabledByHome[entryId]) disabledBy.push('home-patch')
          const isProtected = (config.protected || []).indexOf(entryId) >= 0
          const marked = markedSet.has(entryId)
          const toggleable = disabledBy.indexOf('home-patch') < 0 && !isProtected
          const status = marked ? 'failed' : (!enabled ? 'disabled' : (fiberPhase === 'failed' ? 'failed' : (activeClient ? 'active' : 'inactive')))
          const stars = (st.stars && typeof st.stars[entryId] === 'number') ? st.stars[entryId] : 0
          const cfgEntry = config.plugins && config.plugins[entryId]
          const entryRepo = (cfgEntry && cfgEntry.repo) || repo
          const iconOwner = entryRepo ? String(entryRepo).split('/')[0] : null
          const icon = iconOwner ? 'https://github.com/' + iconOwner + '.png?size=96' : null
          const latestVersion = cfgEntry && cfgEntry.latestVersion
          const installedVersion = b.version || ''
          const hasUpdate = latestVersion ? compareVersion(latestVersion, installedVersion) > 0 : false
          if (hasUpdate) pendingUpdateCount++
          plugins.push({
            entryId: entryId, moduleName: moduleName, label: info.label || entryId, category: info.category || '其他',
            tags: info.tags || [], capability: info.capability || '', boundary: info.boundary || '',
            group: b.bundle, bundle: b.bundle, known: isKnown,
            enabled: enabled, fiberPhase: fiberPhase, activeClient: activeClient, disabledBy: disabledBy,
            toggleable: toggleable, protected: isProtected, markedFailed: marked, status: status,
            stars: stars, installIndex: (typeof b.installIndex === 'number') ? b.installIndex : 0,
            installEpoch: installEpoch, installTime: timeCategory(installEpoch),
            repo: entryRepo, icon: icon, installedVersion: installedVersion, latestVersion: latestVersion || null, hasUpdate: hasUpdate,
            reason: isProtected ? '核心条目，受保护' : (disabledBy.indexOf('home-patch') >= 0 ? '皮肤中心管理' : (marked ? '已判定失效' : '')),
          })
          seen[entryId] = true
        }
      }
      await saveState(paths.home, st)
      const skinIds = new Set()
      if (inv) for (const e of inv) if (e.entryId && String(e.entryId).indexOf('ui-skin-') === 0) skinIds.add(e.entryId)
      for (const id in disabledByHome) if (String(id).indexOf('ui-skin-') === 0) skinIds.add(id)
      for (const entryId of skinIds) {
        if (seen[entryId]) continue
        const invE = invByEntry[entryId] || null
        const moduleName = (invE && invE.moduleName) || ''
        plugins.push({
          entryId: entryId, moduleName: moduleName, label: '皮肤：' + String(entryId).replace(/^ui-skin-/,''), category: '皮肤主题',
          tags: ['皮肤', '主题', 'UI'], capability: '皮肤主题（由皮肤中心管理）', boundary: '',
          group: 'skins', bundle: 'dsh-skins', known: false,
          enabled: invE ? !!invE.enabled : !disabledByHome[entryId],
          fiberPhase: invE ? invE.fiberPhase : null, activeClient: moduleName ? clientIds.has(moduleName) : false,
          disabledBy: disabledByHome[entryId] ? ['home-patch'] : [],
          toggleable: false, protected: false, markedFailed: false, status: 'disabled', stars: 0, installIndex: 9999,
          installEpoch: 0, installTime: '更早', repo: null, icon: null, installedVersion: '', latestVersion: null, hasUpdate: false, reason: '皮肤中心管理',
        })
      }

      result.plugins = plugins
      result.summary.total = plugins.length
      result.summary.enabled = plugins.filter(function (p) { return p.enabled }).length
      result.summary.disabled = plugins.filter(function (p) { return !p.enabled }).length
      result.summary.active = plugins.filter(function (p) { return p.activeClient }).length
      result.summary.failed = plugins.filter(function (p) { return p.fiberPhase === 'failed' }).length
      result.summary.protectedCount = plugins.filter(function (p) { return p.protected }).length
      result.summary.unknownCount = unknownCount
      result.summary.markedFailedCount = plugins.filter(function (p) { return p.markedFailed }).length
      result.summary.pendingUpdateCount = pendingUpdateCount
      result.summary.overlapGroups = (config.overlaps || []).length
      result.failedPlugins = plugins.filter(function (p) { return p.fiberPhase === 'failed' }).map(function (p) { return { entryId: p.entryId, label: p.label, moduleName: p.moduleName, fiberPhase: p.fiberPhase } })

      const tagMap = {}
      for (const p of plugins) for (const t of p.tags) { (tagMap[t] = tagMap[t] || []).push(p.entryId) }
      result.tagGroups = Object.keys(tagMap).sort().map(function (t) { return { tag: t, plugins: tagMap[t] } })

      result.overlaps = (config.overlaps || []).map(function (o) {
        const entries = o.entries.map(function (id) {
          const p = plugins.find(function (x) { return x.entryId === id })
          return p ? { entryId: id, label: p.label, enabled: p.enabled, activeClient: p.activeClient, fiberPhase: p.fiberPhase, status: p.status } : { entryId: id, label: id, enabled: false, activeClient: false, fiberPhase: null, status: 'disabled' }
        })
        return { id: o.id, label: o.label, tag: o.tag, note: o.note, entries: entries, enabledCount: entries.filter(function (e) { return e.enabled }).length, activeCount: entries.filter(function (e) { return e.activeClient }).length }
      })

      const enabledSet = new Set(plugins.filter(function (p) { return p.enabled }).map(function (p) { return p.entryId }))
      const coexistence = []
      for (const r of (config.compatRules || [])) {
        const triggered = r.entries.filter(function (id) { return enabledSet.has(id) })
        if (triggered.length >= 2) coexistence.push({ id: r.id, type: r.type, severity: r.severity, confidence: r.confidence, title: r.title, desc: r.desc, evidence: r.evidence, entries: r.entries, triggeredEntries: triggered, fixes: r.fixes })
      }
      const existence = detectExistenceConflicts(profilePatchText, bundleEntryIds)
      result.conflicts = coexistence.concat(existence)
      result.summary.coexistenceConflicts = coexistence.length
      result.summary.existenceConflicts = existence.length
      result.summary.conflicts = result.conflicts.length

      if (result.summary.failed > 0) result.warnings.push('检测到 ' + result.summary.failed + ' 个插件加载失败（fiberPhase=failed），属于真实加载/兼容问题。')
      if (unknownCount > 0) result.warnings.push('有 ' + unknownCount + ' 个插件未在知识库中，已用 package.json 元数据自动填充基本信息。')
      return result
    }

    async function applyToggle(entryId, enabled) {
      if (!entryId) return { ok: false, error: '缺少 entryId' }
      const paths = await resolvePaths()
      if (!paths.profileRoot) return { ok: false, error: '无法解析 profile 路径' }
      const config = await loadConfig(paths.home)
      if (!enabled && (config.protected || []).indexOf(entryId) >= 0) return { ok: false, error: '「' + entryId + '」为核心条目，受保护，不允许停用（停用可能导致 DSH 无法进入）' }
      const patchPath = paths.profileRoot + '/cordis.patch.yml'
      let text = ''
      try { text = await readFile(patchPath) } catch (err) {}
      const parsed = parsePatch(text)
      const changed = setEntryDisabled(parsed, entryId, !enabled)
      if (!changed) return { ok: true, changed: false, restartRequired: false, entryId: entryId, enabled: enabled, message: enabled ? '插件本就处于启用状态' : '插件本就处于停用状态' }
      await writeFile(patchPath, serializePatch(parsed))
      return { ok: true, changed: true, restartRequired: true, entryId: entryId, enabled: enabled, message: (enabled ? '已启用' : '已停用') + '「' + entryId + '」，重启 DSH 后生效' }
    }

    async function applySwitch(groupId, entryId) {
      const paths = await resolvePaths()
      const config = await loadConfig(paths.home)
      const group = (config.overlaps || []).find(function (o) { return o.id === groupId })
      if (!group) return { ok: false, error: '未知重叠组 ' + groupId }
      if (group.entries.indexOf(entryId) < 0) return { ok: false, error: '该插件不在此重叠组内' }
      if (!paths.profileRoot) return { ok: false, error: '无法解析 profile 路径' }
      const patchPath = paths.profileRoot + '/cordis.patch.yml'
      let text = ''
      try { text = await readFile(patchPath) } catch (err) {}
      const parsed = parsePatch(text)
      let changed = false
      for (const id of group.entries) {
        if (id === entryId) { if (setEntryDisabled(parsed, id, false)) changed = true }
        else { if (setEntryDisabled(parsed, id, true)) changed = true }
      }
      if (changed) await writeFile(patchPath, serializePatch(parsed))
      return { ok: true, changed: changed, restartRequired: changed, groupId: groupId, entryId: entryId, message: '已切换到「' + entryId + '」（同组其余插件已停用），重启 DSH 后生效' }
    }

    async function applyFix(fixId) {
      const paths = await resolvePaths()
      const config = await loadConfig(paths.home)
      let fix = null
      for (const r of (config.compatRules || [])) { for (const f of r.fixes) { if (f.id === fixId) { fix = f; break } } if (fix) break }
      if (!fix) {
        let pt = ''
        if (paths.profileRoot) { try { pt = await readFile(paths.profileRoot + '/cordis.patch.yml') } catch (err) {} }
        const discovered = await discoverBundles(paths.profileRoot)
        const bundleEntryIds = {}
        for (const b of discovered) for (const e of b.entries) bundleEntryIds[e.entryId] = b.bundle
        for (const c of detectExistenceConflicts(pt, bundleEntryIds)) { for (const f of c.fixes) { if (f.id === fixId) { fix = f; break } } if (fix) break }
      }
      if (!fix) return { ok: false, error: '未知修复方案 ' + fixId }
      if (fix.action === 'manual') return { ok: true, changed: false, restartRequired: false, message: '需手动修复：' + fix.label }
      return applyToggle(fix.target, false)
    }

    harness.handle('analyze', function () { return analyze() })
    harness.handle('toggle', function (a) { return applyToggle(a && a.entryId, !!(a && a.enabled)) })
    harness.handle('switch', function (a) { return applySwitch(a && a.groupId, a && a.entryId) })
    harness.handle('applyFix', function (a) { return applyFix(a && a.fixId) })
    harness.handle('markFailed', function (a) { return markFailed(a && a.entryId) })
    harness.handle('unmarkFailed', function (a) { return unmarkFailed(a && a.entryId) })
    harness.handle('detectFailures', function (a) { return detectFailures(a && a.entryIds) })
    harness.handle('fixAllFailures', function () { return fixAllFailures() })
    harness.handle('refreshStars', function () { return refreshStars() })
    harness.handle('predictUpdateConflicts', function (a) { return predictUpdateConflicts(a && a.entryIds) })
    harness.handle('getUsage', function () { return getUsage() })
    harness.handle('clearUsage', function () { return clearUsage() })

    try {
      const tool = harness.defineTool({
        name: 'plugin_integration',
        description: '插件整合中心：动态发现已装插件、tag/star/入库时间、功能重叠与兼容检测、启用停用切换、失效判定与失效检测、GitHub star 抓取、待更新冲突预判。',
        parameters: { type: 'object', properties: {
          action: { type: 'string', enum: ['analyze', 'toggle', 'switch', 'applyFix', 'markFailed', 'unmarkFailed', 'detectFailures', 'refreshStars', 'predictUpdateConflicts'], description: 'analyze=查看分析；toggle=启停；switch=重叠切换；applyFix=应用修复；markFailed=判定失效；unmarkFailed=取消失效；detectFailures=失效检测；refreshStars=刷新 GitHub star；predictUpdateConflicts=更新冲突预判' },
          entryId: { type: 'string', description: '插件 loader 条目 id' },
          enabled: { type: 'boolean', description: 'toggle 的目标启用状态' },
          groupId: { type: 'string', description: '重叠组 id' },
          fixId: { type: 'string', description: '修复方案 id' },
          entryIds: { type: 'array', items: { type: 'string' }, description: 'detectFailures/predictUpdateConflicts 的条目 id 列表' },
        }, required: ['action'] },
        output: { schema: { type: 'object', additionalProperties: true }, render: function (_args, value) { return [{ type: 'text', text: JSON.stringify(value) }] } },
        execute: async function (args) {
          args = args || {}
          if (args.action === 'analyze') return analyze()
          if (args.action === 'toggle') return applyToggle(args.entryId, !!args.enabled)
          if (args.action === 'switch') return applySwitch(args.groupId, args.entryId)
          if (args.action === 'applyFix') return applyFix(args.fixId)
          if (args.action === 'markFailed') return markFailed(args.entryId)
          if (args.action === 'unmarkFailed') return unmarkFailed(args.entryId)
          if (args.action === 'detectFailures') return detectFailures(args.entryIds)
          if (args.action === 'refreshStars') return refreshStars()
          if (args.action === 'predictUpdateConflicts') return predictUpdateConflicts(args.entryIds)
          return { ok: false, error: '未知 action: ' + args.action }
        },
      })
      harness.registerTool(ctx, tool)
    } catch (err) { console.error('plugin_integration tool 注册失败:', err && err.message) }
  },
}
}
