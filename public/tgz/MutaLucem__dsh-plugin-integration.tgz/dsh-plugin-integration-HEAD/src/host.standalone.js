// ============================================================================
// dsh-plugin-integration —— Host 半（独立 bundle 形态 / standalone）
// ----------------------------------------------------------------------------
// 与动态插件形态（src/host.js）的唯一区别在「能力接线层」，核心发现/检测逻辑不变：
//   - 启停：写 `- id: X` + `disabled: true|false` 到 profile cordis.patch.yml，
//           由 profile 的 HMR 监听器（watchUserPatches → chokidar）热重载即时生效并持久化；
//           与官方 dsh-plugin-console 同一机制（加载器条目都嵌套在 include 子树下，
//           叶子 id 无法被 loader.update 解析，故不再走 ctx.loader.update）。
//   - RPC：harness.handle → ctx.webServer 注册 /api/plugin-integration 前缀路由。
//   - 工具：harness.defineTool/registerTool → ctx.tools.register(defineTool(...))。
//   - 状态：markedFailed/installTimes/stars 内存态（插件重载后重置；启停由补丁文件持久化）。
//   - 文件读写：Node 原生 fs（standalone 为宿主进程内一等插件，非 vm 沙箱）。
// ============================================================================
import { defineTool } from '@deepseek-ai/dsh-tools'
import { writeFile as fsWriteFile, readFile as fsReadFile } from 'node:fs/promises'
import { execFile, spawn } from 'node:child_process'

export const name = 'dsh-plugin-integration'
export const inject = ['webServer', 'tools', 'loader', 'clientModules', 'settings']

// 默认配置（与 config.default.json 一致；可被 ~/.dsh/dsh-plugin-integration.json 覆盖）
const DEFAULT_CONFIG = {
  protected: ['ui-web-ui-compat'],
  plugins: {
    'tts': { label: 'Edge TTS 语音朗读', category: '音频语音', tags: ['语音朗读', '音频', '无障碍'], capability: '消息朗读按钮、自动朗读开关、语音设置面板', boundary: '仅朗读输出，不做语音识别输入' },
    'voice-input': { label: '语音输入（Web Speech）', category: '音频语音', tags: ['语音输入', '音频', '输入增强'], capability: '输入框麦克风按钮，浏览器语音识别填充草稿，可选自动发送', boundary: '仅浏览器 Web Speech，无本地识别' },
    'voice': { label: '语音输入（sherpa-onnx）', category: '音频语音', tags: ['语音输入', '音频', '输入增强'], capability: '麦克风按钮 + Ctrl+Space，可选本地 sherpa-onnx 识别', boundary: '需额外配置本地模型' },
    'dsh-window-kit': { label: 'Windows 原生桌面窗口', category: '桌面窗口', tags: ['桌面', '窗口', '工具'], capability: 'desktop_launch 工具，自动安装 WebView2 桌面窗口 + 快捷方式', boundary: '仅 Windows' },
    'deepeye-vision': { label: 'DeepEye 视觉（GLM-4V）', category: '视觉多模态', tags: ['视觉', '多模态', 'OCR', '工具'], capability: 'vision_describe/ocr/ask/layout/clipboard 看图与 OCR', boundary: '依赖智谱 GLM-4V-Flash 与 API Key' },
    'describe-image': { label: '图片描述工具', category: '视觉多模态', tags: ['视觉', '多模态', '工具'], capability: 'describe_image 工具：看图、OCR、图表、截图、翻译', boundary: '走统一图片描述管线' },
    'modlens': { label: 'Modlens 视觉', category: '视觉多模态', tags: ['视觉', '多模态', 'OCR', '工具'], capability: 'modlens_read_image：Antigravity CLI 看图 + OCR', boundary: '依赖 Antigravity CLI 引擎' },
    'dsh-context': { label: '上下文洞察', category: '调试监控', tags: ['上下文', '调试', '面板'], capability: '上下文窗口组成、历史、压缩、注入、模型切换可视化', boundary: '只读分析，不修改上下文' },
    'shortcuts': { label: '键盘快捷键', category: '输入增强', tags: ['快捷键', '效率', '输入增强'], capability: '34 个预注册功能 + 自定义快捷键录制', boundary: '仅键盘操作' },
    'dsh-market': { label: '插件市场', category: '插件管理', tags: ['插件管理', '市场', '安装'], capability: '浏览 / 搜索 / 一键安装社区插件', boundary: '市场安装，不含启停' },
    'plugin-console': { label: '插件控制台', category: '插件管理', tags: ['插件管理', '启停', '安装'], capability: '一键启用/停用插件，安装 GitHub 插件', boundary: '会写组合补丁' },
    'ui-web-ui-compat': { label: 'Web UI 兼容层', category: '系统', tags: ['系统', '兼容'], capability: 'web-ui-all 的桥接兼容层', boundary: '内部依赖' },
    'ui-web-ui-settings': { label: 'Web UI 设置', category: '设置界面', tags: ['设置', 'UI'], capability: 'Web UI 聚合插件专属设置页', boundary: '' },
    'ui-dsh-aionui-panel': { label: 'AionUI 右侧面板', category: '面板文件', tags: ['面板', '文件', '预览', 'SCM', 'UI'], capability: '右侧预览/文件树/变更面板，markdown/html/diff/csv/pdf 预览', boundary: '占用右侧详情列' },
    'ui-task-board': { label: '任务看板', category: '效率', tags: ['任务', '看板', '定时', '效率'], capability: '多列看板 + cron 定时执行任务', boundary: '浏览器端调度，需标签页打开' },
    'ui-git-graph': { label: 'Git 图', category: '开发工具', tags: ['Git', '可视化'], capability: 'Git 提交图可视化', boundary: '' },
    'pet': { label: '桌面宠物', category: '娱乐', tags: ['娱乐', '宠物'], capability: '桌面宠物', boundary: '' },
    'remote-web-ui': { label: '远程 Web UI', category: '远程', tags: ['远程', '网络'], capability: '远程 Web UI 访问', boundary: '' },
    'live-stats': { label: '实时统计', category: '监控', tags: ['统计', '监控'], capability: '实时统计显示', boundary: '' },
    'ssh': { label: 'SSH 远程运维', category: '远程运维', tags: ['SSH', '远程', '运维', '部署'], capability: '持久连接池、ssh_exec/upload/download/tunnel/cluster、Web 终端', boundary: '主机需用户在 GUI 配置' },
    'liangshen': { label: '梁神模式（Agent 预设）', category: 'Agent预设', tags: ['Agent预设', '模式', '锚定'], capability: '两阶段锚定 Minimal → Code Mode 的 agent preset', boundary: '默认预设由用户选择' },
    'ui-skin-center': { label: '皮肤中心', category: '皮肤主题', tags: ['皮肤', '主题', 'UI'], capability: '皮肤全家桶管理', boundary: '' },
    'dsh-minigames': { label: '小游戏面板', category: '娱乐', tags: ['娱乐', '游戏'], capability: '18 款离线小游戏右侧面板', boundary: '' },
    'dsh-zh': { label: '中文增强', category: '本地化', tags: ['本地化', '中文', 'UI'], capability: '中文界面修正、术语统一、统计行、中文优先提示', boundary: '' },
    'prompt-manager': { label: 'Lorebook 创作', category: '创作', tags: ['世界书', '角色卡', '创作', '提示词'], capability: '导入角色卡/世界书、Markdown lore、小说生成', boundary: '' },
    'better-sidebar': { label: 'VSCode 风格侧边栏', category: '面板文件', tags: ['侧边栏', '文件', '终端', 'Git', '面板', 'UI'], capability: 'explorer/editor/terminal/git/browser 右侧边栏，按会话隔离', boundary: '占用右侧详情列' },
  },
  overlaps: [
    { id: 'vision', label: '视觉 / 多模态（看图 · OCR）', tag: '视觉', entries: ['deepeye-vision', 'modlens', 'describe-image'], note: '多个看图/OCR 插件同时启用会导致工具冗余，建议只保留一个' },
    { id: 'voice-input', label: '语音输入（麦克风）', tag: '语音输入', entries: ['voice', 'voice-input'], note: '两个麦克风按钮会同时出现在输入框，容易冲突' },
    { id: 'right-panel', label: '右侧面板 / 文件管理', tag: '面板', entries: ['better-sidebar', 'ui-dsh-aionui-panel'], note: '两者都占用右侧详情/侧边栏区域，会互相遮挡' },
    { id: 'plugin-manager', label: '插件管理 / 市场', tag: '插件管理', entries: ['dsh-market', 'plugin-console'], note: '两个管理器都会读写组合补丁，可能互相覆盖' },
  ],
  compatRules: [
    { id: 'coexist-voice', type: 'coexistence', severity: 'medium', confidence: 'known', entries: ['voice', 'voice-input'], title: '语音输入插件并存', desc: 'voice 与 voice-input 都会在输入框挂载麦克风按钮，同时启用会出现两个麦克风入口与快捷键（Ctrl+Space）冲突。', evidence: '两者都声明 dsh.client 并注册 composer 输入区。', fixes: [
      { id: 'fix-voice-a', action: 'disable', target: 'voice-input', label: '停用「语音输入(Web Speech)」，保留 sherpa-onnx 本地识别' },
      { id: 'fix-voice-b', action: 'disable', target: 'voice', label: '停用「语音输入(sherpa-onnx)」，保留 Web Speech' },
    ] },
    { id: 'coexist-vision', type: 'coexistence', severity: 'medium', confidence: 'known', entries: ['deepeye-vision', 'modlens', 'describe-image'], title: '视觉/多模态插件并存', desc: '三个插件都注册看图类工具（vision_*、modlens_read_image、describe_image），功能重叠、消耗重复资源，可能引起工具选择混乱。', evidence: '当前运行时三个工具族同时可见。', fixes: [
      { id: 'fix-vision-a', action: 'disable', target: 'modlens', label: '停用 Modlens，保留 DeepEye + 图片描述' },
      { id: 'fix-vision-b', action: 'disable', target: 'deepeye-vision', label: '停用 DeepEye，保留 Modlens' },
    ] },
    { id: 'coexist-panel', type: 'coexistence', severity: 'high', confidence: 'known', entries: ['better-sidebar', 'ui-dsh-aionui-panel'], title: '右侧面板占用冲突', desc: 'better-sidebar 与 AionUI 面板都占用右侧详情列，同时启用会互相遮挡或覆盖。', evidence: '两者都注入 conversation 右侧详情区 Slot。', fixes: [
      { id: 'fix-panel-a', action: 'disable', target: 'ui-dsh-aionui-panel', label: '停用 AionUI 面板，保留 VSCode 侧边栏' },
      { id: 'fix-panel-b', action: 'disable', target: 'better-sidebar', label: '停用 VSCode 侧边栏，保留 AionUI 面板' },
    ] },
    { id: 'coexist-manager', type: 'coexistence', severity: 'medium', confidence: 'known', entries: ['dsh-market', 'plugin-console'], title: '插件管理器并存', desc: '插件市场与插件控制台都会读写组合补丁文件，同时启用可能产生互相覆盖的启停操作。', evidence: '两者都声明插件管理能力。', fixes: [
      { id: 'fix-manager-a', action: 'disable', target: 'plugin-console', label: '停用插件控制台，保留插件市场' },
      { id: 'fix-manager-b', action: 'disable', target: 'dsh-market', label: '停用插件市场，保留插件控制台' },
    ] },
  ],
}

const BASE_BUNDLES = ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app']

function parentDir(p) { const i = Math.max(String(p).lastIndexOf('\\'), String(p).lastIndexOf('/')); return i < 0 ? String(p) : String(p).slice(0, i) }
function dirname(p) { const i = Math.max(String(p).lastIndexOf('\\'), String(p).lastIndexOf('/')); return i < 0 ? '.' : String(p).slice(0, i) }
function humanLabel(name) { const s = String(name || ''); const i = s.lastIndexOf('/'); return i >= 0 ? s.slice(i + 1) : s }
function timeCategory(epoch) { const now = Date.now(); const diff = now - epoch; const DAY = 86400000; if (diff < DAY) return '今日'; if (diff < 3 * DAY) return '三天内'; if (diff < 7 * DAY) return '一周内'; if (diff < 30 * DAY) return '一月内'; return '更早' }
function compareVersion(a, b) { const pa = String(a || '0').split('.').map(function (n) { const m = String(n).match(/\d+/); return m ? parseInt(m[0], 10) : 0 }); const pb = String(b || '0').split('.').map(function (n) { const m = String(n).match(/\d+/); return m ? parseInt(m[0], 10) : 0 }); for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const x = pa[i] || 0, y = pb[i] || 0; if (x !== y) return x > y ? 1 : -1 } return 0 }
function repoFromUrl(repo) { if (repo && repo.url) { const m = String(repo.url).match(/github\.com[:/]([^/]+\/[^/.]+?)(?:\.git)?$/i); if (m) return m[1] } return null }

function parseInsertRows(text) {
  const rows = []
  const lines = String(text || '').split(/\r?\n/)
  let inInsert = false; let pending = null
  const flush = function () { if (pending && pending.id && !pending.group) rows.push({ id: pending.id, name: pending.name }); pending = null }
  for (const line of lines) {
    if (/^-\s*insert\s*:/.test(line)) { flush(); inInsert = true; pending = null; continue }
    if (!inInsert) continue
    // 顶层 `- id:`（列 0）是新的覆盖块，结束 insert 块（如 dsh-vision-router 的 attachment-local 覆盖）
    if (/^-\s*id\s*:/.test(line)) { inInsert = false; flush(); pending = null; continue }
    // 缩进的 `- id:`：insert 内的条目（含组内 config 嵌套条目）
    const m = line.match(/^\s+-\s*id:\s*['"]?([^'"\s]+)['"]?/)
    if (m) { flush(); pending = { id: m[1], name: null, group: false }; continue }
    const nm = line.match(/^\s*name:\s*['"]?([^'"\s]+)['"]?/)
    if (nm && pending) { pending.name = nm[1]; continue }
    if (pending && /^\s*group\s*:\s*true\s*$/.test(line)) { pending.group = true; continue }
  }
  flush()
  return rows
}
function readDisabledMap(text) {
  const map = {}
  const lines = String(text || '').split(/\r?\n/)
  let curId = null
  for (const line of lines) {
    const m = line.match(/^\s*-\s*id:\s*['"]?([^'"\s]+)['"]?/)
    if (m) { curId = m[1]; continue }
    if (curId && /^\s*disabled\s*:\s*true\s*$/.test(line)) map[curId] = true
    if (/^\s*-/.test(line) && !/id:/.test(line)) curId = null
  }
  return map
}
function genericTags(keywords) {
  const tags = []
  const kws = (keywords || []).map(function (k) { return String(k).toLowerCase() })
  const has = function (t) { return kws.indexOf(t) >= 0 }
  if (has('vision') || has('ocr') || has('multimodal') || has('image')) tags.push('视觉')
  if (has('voice') || has('tts') || has('audio') || has('speech')) tags.push('音频')
  if (has('ssh') || has('remote')) tags.push('远程')
  if (has('git')) tags.push('Git')
  if (has('terminal')) tags.push('终端')
  if (has('market') || has('marketplace') || has('plugin-manager')) tags.push('插件管理')
  if (has('skin') || has('theme')) tags.push('皮肤')
  if (has('task') || has('board')) tags.push('任务')
  if (has('shortcut') || has('hotkey')) tags.push('快捷键')
  if (has('context')) tags.push('上下文')
  if (has('lorebook') || has('world-info') || has('tavern')) tags.push('世界书')
  return tags
}
function mergeConfig(base, user) {
  if (!user || typeof user !== 'object') return base
  const out = {}
  out.protected = Array.isArray(user.protected) ? user.protected : (base.protected || [])
  const bp = (base && base.plugins && typeof base.plugins === 'object') ? base.plugins : {}
  const up = (user.plugins && typeof user.plugins === 'object') ? user.plugins : {}
  out.plugins = {}
  for (const k in bp) out.plugins[k] = bp[k]
  for (const k in up) out.plugins[k] = up[k]
  out.overlaps = Array.isArray(user.overlaps) ? user.overlaps : (base.overlaps || [])
  out.compatRules = Array.isArray(user.compatRules) ? user.compatRules : (base.compatRules || [])
  out.githubToken = (typeof user.githubToken === 'string' && user.githubToken) ? user.githubToken : (base.githubToken || undefined)
  return out
}

// ===== 补丁读写（profile cordis.patch.yml 的 id/disabled 块） =====
function parsePatch(text) {
  const lines = String(text || '').split(/\r?\n/)
  const header = []; const blocks = []; let cur = null
  const flush = function () { if (cur) { blocks.push(cur); cur = null } }
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    if (/^-\s/.test(line)) { flush(); cur = { lines: [line] } }
    else if (cur) { cur.lines.push(line) }
    else { header.push(line) }
  }
  flush()
  return { header: header, blocks: blocks }
}
function blockId(block) { const m = block.lines[0].match(/-\s*id:\s*['"]?([^'"\s]+)['"]?/); return m ? m[1] : null }
function serializePatch(parsed) { const parts = parsed.header.slice(); for (const b of parsed.blocks) for (const l of b.lines) parts.push(l); return parts.join('\n') }
function setEntryDisabled(parsed, entryId, disabled) {
  let found = null
  for (const b of parsed.blocks) { if (blockId(b) === entryId) { found = b; break } }
  if (!found) {
    if (disabled === true) { parsed.blocks.push({ lines: ['- id: ' + entryId, '  disabled: true'] }); return true }
    return false
  }
  const before = found.lines.join('\n')
  let idx = -1
  for (let i = 0; i < found.lines.length; i++) { if (/^\s*disabled\s*:/.test(found.lines[i])) { idx = i; break } }
  const indentMatch = found.lines[0].match(/^(\s*)/)
  const subIndent = (indentMatch ? indentMatch[1] : '') + '  '
  if (disabled === true) {
    if (idx >= 0) found.lines[idx] = subIndent + 'disabled: true'
    else found.lines.splice(1, 0, subIndent + 'disabled: true')
  } else {
    if (idx >= 0) found.lines.splice(idx, 1)
    if (found.lines.length === 1) { const i2 = parsed.blocks.indexOf(found); if (i2 >= 0) parsed.blocks.splice(i2, 1) }
  }
  return found.lines.join('\n') !== before || parsed.blocks.indexOf(found) < 0
}
function extractInsertedIds(text) {
  const ids = []
  const lines = String(text || '').split(/\r?\n/)
  let inInsert = false
  for (const line of lines) {
    if (/^\s*-\s*insert\s*:/.test(line)) { inInsert = true; continue }
    if (inInsert) {
      const m = line.match(/^\s*-\s*id:\s*['"]?([^'"\s]+)['"]?/)
      if (m) { ids.push(m[1]); continue }
      if (/^\s*-/.test(line)) inInsert = false
    }
  }
  return ids
}
function detectExistenceConflicts(profilePatchText, bundleEntryIds) {
  const conflicts = []
  const insertedIds = extractInsertedIds(profilePatchText)
  for (const id of insertedIds) {
    if (bundleEntryIds[id]) {
      conflicts.push({
        id: 'exist-double-' + id, type: 'existence', severity: 'high', confidence: 'structural',
        entries: [id], triggeredEntries: [id],
        title: '插件双重挂载（存在性冲突）',
        desc: '「' + id + '」同时通过 bundle 通道（' + bundleEntryIds[id] + '）和 profile 补丁手动 insert 挂载，会导致两个宿主实例 / 两个界面实例。',
        evidence: 'profile cordis.patch.yml 中存在对已安装 bundle 条目的手动 insert。',
        fixes: [{ id: 'fix-double-' + id, action: 'manual', target: id, label: '从 profile 补丁中移除「' + id + '」的手动 insert 行，仅保留 bundle 通道' }],
      })
    }
  }
  return conflicts
}

export function apply(ctx) {
  const loader = ctx.get('loader')
  const cm = ctx.get('clientModules')
  const settings = ctx.get('settings')

  // 内存态（启停由补丁文件持久化；markedFailed/installTimes/stars 重载后重置；operations/updates 落盘）
  const state = { markedFailed: [], installTimes: {}, stars: {}, updates: {}, usage: {}, operations: [] }
  let config = DEFAULT_CONFIG
  const OPS_FILE = 'dsh-plugin-integration.operations.json'
  // 本次启动会话 id（区分「当前日志」与「历史日志」）
  const sessionId = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8)
  let opSeq = 0

  async function readFile(path) { return await fsReadFile(path, 'utf8') }
  async function writeFile(path, content) { return await fsWriteFile(path, content, 'utf8') }
  async function loadConfig(home) {
    if (home) {
      try { const text = await readFile(home + '/dsh-plugin-integration.json'); config = mergeConfig(DEFAULT_CONFIG, JSON.parse(text)) } catch (err) {}
    }
    return config
  }
  // ===== 操作日志（持久化到 ~/.dsh/dsh-plugin-integration.operations.json） =====
  let cachedHome = null
  async function getHome() { if (cachedHome) return cachedHome; cachedHome = await resolveHome(); return cachedHome }
  async function loadOperations(home) {
    if (!home) return []
    try { const text = await readFile(home + '/' + OPS_FILE); const a = JSON.parse(text); return Array.isArray(a) ? a : [] } catch (err) { return [] }
  }
  async function saveOperations(home) {
    if (!home) return
    try { await writeFile(home + '/' + OPS_FILE, JSON.stringify(state.operations || [], null, 2)) } catch (err) { console.error('saveOperations:', err && err.message) }
  }
  let opsLoaded = false
  async function ensureOps() {
    if (opsLoaded) return
    opsLoaded = true
    try {
      const h = await getHome()
      if (h && h.home) {
        const loaded = await loadOperations(h.home)
        if (Array.isArray(loaded) && loaded.length) {
          state.operations = loaded.map(function (o, i) { if (!o || typeof o !== 'object') o = {}; if (!o.id) o.id = 'legacy-' + (o.ts || 0) + '-' + i; if (!o.session) o.session = ''; return o })
        }
      }
    } catch (err) {}
  }
  async function logOperation(action, detail, message, ok) {
    await ensureOps()
    const rec = { id: sessionId + '-' + (++opSeq).toString(36), ts: Date.now(), session: sessionId, action: action || '', detail: detail || '', ok: !!ok, message: message || '' }
    state.operations.push(rec)
    if (state.operations.length > 500) state.operations = state.operations.slice(-500)
    try { const h = await getHome(); if (h && h.home) await saveOperations(h.home) } catch (err) { console.error('logOperation save:', err && err.message) }
    return rec
  }
  async function getOperations() {
    await ensureOps()
    const all = state.operations.slice().sort(function (a, b) { return (b.ts || 0) - (a.ts || 0) })
    return { ok: true, current: all.filter(function (o) { return o.session === sessionId }), history: all.filter(function (o) { return o.session !== sessionId }) }
  }
  async function deleteOperation(id) {
    await ensureOps()
    const before = state.operations.length
    state.operations = state.operations.filter(function (o) { return o.id !== id })
    const changed = state.operations.length !== before
    if (changed) { try { const h = await getHome(); if (h && h.home) await saveOperations(h.home) } catch (err) {} }
    return { ok: true, changed: changed, message: changed ? '已删除该记录' : '未找到该记录' }
  }
  async function clearOperations(scope) {
    await ensureOps()
    if (scope === 'current') state.operations = state.operations.filter(function (o) { return o.session !== sessionId })
    else if (scope === 'history') state.operations = state.operations.filter(function (o) { return o.session === sessionId })
    else state.operations = []
    try { const h = await getHome(); if (h && h.home) await saveOperations(h.home) } catch (err) {}
    return { ok: true, message: '已清空' }
  }
  // ===== star 缓存（持久化到 ~/.dsh/dsh-plugin-integration.stars.json，TTL 内复用） =====
  const STARS_FILE = 'dsh-plugin-integration.stars.json'
  const STARS_TTL_MS = 24 * 3600 * 1000
  async function loadStars(home) {
    if (!home) return {}
    try { const text = await readFile(home + '/' + STARS_FILE); const j = JSON.parse(text); return (j && typeof j === 'object' && !Array.isArray(j)) ? j : {} } catch (err) { return {} }
  }
  async function saveStars(home) {
    if (!home) return
    try { await writeFile(home + '/' + STARS_FILE, JSON.stringify(state.stars || {}, null, 2)) } catch (err) { console.error('saveStars:', err && err.message) }
  }
  let starsLoaded = false
  async function ensureStars() {
    if (starsLoaded) return
    starsLoaded = true
    try { const h = await getHome(); if (h && h.home) state.stars = await loadStars(h.home) } catch (err) {}
  }
  function starNumber(entryId) {
    const c = state.stars && state.stars[entryId]
    if (c && typeof c.n === 'number') return c.n
    if (typeof c === 'number') return c
    return 0
  }
  // ===== 更新状态缓存（持久化到 ~/.dsh/dsh-plugin-integration.updates.json） =====
  const UPDATES_FILE = 'dsh-plugin-integration.updates.json'
  async function loadUpdates(home) {
    if (!home) return {}
    try { const text = await readFile(home + '/' + UPDATES_FILE); const j = JSON.parse(text); return (j && typeof j === 'object' && !Array.isArray(j)) ? j : {} } catch (err) { return {} }
  }
  async function saveUpdates(home) {
    if (!home) return
    try { await writeFile(home + '/' + UPDATES_FILE, JSON.stringify(state.updates || {}, null, 2)) } catch (err) { console.error('saveUpdates:', err && err.message) }
  }
  let updatesLoaded = false
  async function ensureUpdates() {
    if (updatesLoaded) return
    updatesLoaded = true
    try { const h = await getHome(); if (h && h.home) state.updates = await loadUpdates(h.home) } catch (err) {}
  }
  async function readInstalledSpecs(profileRoot) {
    try { const pkg = JSON.parse(await readFile(profileRoot + '/package.json')); return (pkg && pkg.dependencies && typeof pkg.dependencies === 'object') ? pkg.dependencies : {} } catch (err) { return {} }
  }
  async function readLockCommits(profileRoot) {
    const map = {}
    try {
      const lock = await readFile(profileRoot + '/pnpm-lock.yaml')
      const re = /codeload\.github\.com\/([^/\s]+\/[^/\s]+)\/tar\.gz\/([0-9a-f]{40})/g
      let m
      while ((m = re.exec(lock))) map[m[1].toLowerCase()] = m[2]
    } catch (err) {}
    return map
  }
  function githubTokenHeaders() {
    const headers = { accept: 'application/json', 'user-agent': 'dsh-plugin-integration' }
    const token = (config.githubToken) || process.env.GITHUB_TOKEN || process.env.DSH_GITHUB_TOKEN
    if (token) headers.authorization = 'Bearer ' + token
    return headers
  }
  async function githubHead(repo) {
    const res = await fetch('https://api.github.com/repos/' + repo + '/commits/HEAD', { headers: githubTokenHeaders(), signal: AbortSignal.timeout(15000) })
    if (res.status === 403 || res.status === 429) throw new Error('RATE_LIMIT')
    if (!res.ok) throw new Error('HTTP ' + res.status)
    const j = await res.json()
    return (j && j.sha) ? j.sha : null
  }
  async function npmLatest(name) {
    const res = await fetch('https://registry.npmjs.org/' + encodeURIComponent(name) + '/latest', { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(15000) })
    if (!res.ok) throw new Error('HTTP ' + res.status)
    const j = await res.json()
    return (j && typeof j.version === 'string') ? j.version : null
  }
  // ===== 用量统计（实时统计工具调用次数 + 估算 token 消耗，持久化到 usage.json） =====
  const USAGE_FILE = 'dsh-plugin-integration.usage.json'
  async function loadUsage(home) {
    if (!home) return {}
    try { const text = await readFile(home + '/' + USAGE_FILE); const j = JSON.parse(text); return (j && typeof j === 'object' && !Array.isArray(j)) ? j : {} } catch (err) { return {} }
  }
  async function saveUsage(home) {
    if (!home) return
    try { await writeFile(home + '/' + USAGE_FILE, JSON.stringify(state.usage || {}, null, 2)) } catch (err) { console.error('saveUsage:', err && err.message) }
  }
  let usageLoaded = false
  let usageSaveTimer = null
  async function ensureUsage() {
    if (usageLoaded) return
    usageLoaded = true
    try { const h = await getHome(); if (h && h.home) state.usage = await loadUsage(h.home) } catch (err) {}
  }
  function scheduleUsageSave() {
    if (usageSaveTimer) return
    usageSaveTimer = setTimeout(function () { usageSaveTimer = null; (async function () { try { const h = await getHome(); if (h && h.home) await saveUsage(h.home) } catch (err) {} })() }, 1500)
  }
  function estimateTokens(str) {
    const s = String(str == null ? '' : str)
    if (!s) return 0
    const ascii = (s.match(/[\x00-\x7f]/g) || []).length
    const other = s.length - ascii
    return Math.ceil(ascii / 4) + Math.ceil(other / 2)
  }
  // 工具名 → 插件 entryId 的尽力映射（前缀 + 精确）
  function toolToEntryId(toolName) {
    const t = String(toolName || '')
    const exact = { 'describe_image': 'describe-image', 'desktop_launch': 'dsh-window-kit', 'plugin_integration': 'plugin-integration' }
    if (exact[t]) return exact[t]
    const prefixes = [
      ['ssh_', 'ssh'], ['vision_', 'deepeye-vision'], ['modlens_', 'modlens'],
      ['prompt_', 'prompt-manager'], ['viking_', 'openviking-memory-runtime'],
    ]
    for (const p of prefixes) if (t.startsWith(p[0])) return p[1]
    return null
  }
  function recordUsage(name, args, result) {
    const argsStr = JSON.stringify(args == null ? null : args)
    const contentStr = (result && Array.isArray(result.content)) ? result.content.map(function (b) { return (b && b.text) ? b.text : '' }).join('\n') : ''
    const tokens = estimateTokens(argsStr) + estimateTokens(contentStr)
    const rec = state.usage[name] || { calls: 0, tokens: 0 }
    rec.calls += 1
    rec.tokens += tokens
    state.usage[name] = rec
    scheduleUsageSave()
  }
  async function getUsage() {
    await ensureUsage()
    const byTool = Object.keys(state.usage).sort().map(function (name) {
      const u = state.usage[name] || { calls: 0, tokens: 0 }
      const entryId = toolToEntryId(name)
      return { tool: name, calls: u.calls || 0, tokens: u.tokens || 0, entryId: entryId }
    })
    const byPluginMap = {}
    for (const t of byTool) {
      const key = t.entryId || '__unmapped__'
      const g = byPluginMap[key] || { entryId: t.entryId, calls: 0, tokens: 0, tools: [] }
      g.calls += t.calls
      g.tokens += t.tokens
      g.tools.push(t.tool)
      byPluginMap[key] = g
    }
    const byPlugin = Object.keys(byPluginMap).sort().map(function (k) {
      const g = byPluginMap[k]
      const label = g.entryId ? ((config.plugins && config.plugins[g.entryId] && config.plugins[g.entryId].label) || g.entryId) : '未归属'
      return { entryId: g.entryId, label: label, calls: g.calls, tokens: g.tokens, tools: g.tools }
    })
    const totalCalls = byTool.reduce(function (a, t) { return a + t.calls }, 0)
    const totalTokens = byTool.reduce(function (a, t) { return a + t.tokens }, 0)
    return { ok: true, byTool, byPlugin, summary: { totalCalls, totalTokens } }
  }
  async function clearUsage() {
    state.usage = {}
    try { const h = await getHome(); if (h && h.home) await saveUsage(h.home) } catch (err) {}
    return { ok: true, message: '已清空用量统计' }
  }
  function describeAction(method, args, result) {
    const msg = result && (result.message || result.error) || ''
    switch (method) {
      case 'toggle': return { action: 'toggle', detail: (args && args.enabled ? '启用' : '停用') + '「' + (args && args.entryId) + '」', message: msg }
      case 'switch': return { action: 'switch', detail: '重叠组 ' + (args && args.groupId) + ' 切换到「' + (args && args.entryId) + '」', message: msg }
      case 'applyFix': return { action: 'applyFix', detail: '采用修复方案 ' + (args && args.fixId), message: msg }
      case 'markFailed': return { action: 'markFailed', detail: '标记失效「' + (args && args.entryId) + '」', message: msg }
      case 'unmarkFailed': return { action: 'unmarkFailed', detail: '取消失效「' + (args && args.entryId) + '」', message: msg }
      case 'detectFailures': return { action: 'detectFailures', detail: '失效检测（' + (result && result.results ? result.results.length : 0) + ' 项）', message: msg }
      case 'fixAllFailures': return { action: 'fixAllFailures', detail: '一键修复失效插件（' + (result && result.fixedCount ? result.fixedCount : 0) + '/' + (result && result.total ? result.total : 0) + '）', message: msg }
      case 'refreshStars': return { action: 'refreshStars', detail: '刷新 GitHub star', message: msg }
      case 'syncUpdates': return { action: 'syncUpdates', detail: '同步插件更新状态（' + ((result && result.updated) || []).length + ' 个待更新）', message: msg }
      case 'updatePlugins': return { action: 'updatePlugins', detail: '一键更新插件（' + (result && result.okCount ? result.okCount : 0) + '/' + (result && result.total ? result.total : 0) + '）', message: msg }
      case 'predictUpdateConflicts': return { action: 'predictUpdateConflicts', detail: '更新冲突预判（' + ((result && result.updateTargets) || []).length + ' 项）', message: msg }
      default: return { action: method, detail: '', message: msg }
    }
  }
  function resolveHome() {
    if (!cm) return settings ? Promise.resolve().then(function () { return null }) : Promise.resolve(null)
    try {
      const g = cm.graph()
      const entries = (g && g.entries) || []
      for (const e of entries) {
        const cp = cm.clientPath(e.id)
        if (cp) {
          const n = String(cp).replace(/\\/g, '/')
          const i = n.indexOf('/node_modules/')
          if (i >= 0) {
            const root = n.slice(0, i)
            const j = n.indexOf('/profiles/')
            return Promise.resolve({ profileRoot: root, home: j >= 0 ? n.slice(0, j) : parentDir(parentDir(root)) })
          }
        }
      }
    } catch (err) {}
    return Promise.resolve(null)
  }
  function getClientGraphIds() {
    const ids = new Set()
    if (!cm) return ids
    try { const g = cm.graph(); if (g && Array.isArray(g.entries)) for (const e of g.entries) if (e && e.id) ids.add(e.id) } catch (err) {}
    return ids
  }

  async function resolveBundle(profileRoot, bundleName) {
    const pkgPath = profileRoot + '/node_modules/' + bundleName + '/package.json'
    let pkg
    try { pkg = JSON.parse(await readFile(pkgPath)) } catch (err) { return null }
    const entries = []
    const patchRel = pkg.dsh && pkg.dsh.bundle && pkg.dsh.bundle.patch
    if (patchRel) {
      const rel = String(patchRel).replace(/^\.\//, '')
      try { const patchText = await readFile(dirname(pkgPath) + '/' + rel); for (const ins of parseInsertRows(patchText)) entries.push({ entryId: ins.id, moduleName: ins.name || bundleName }) } catch (err) {}
    }
    if (entries.length === 0) entries.push({ entryId: bundleName, moduleName: bundleName })
    return { bundle: bundleName, name: pkg.name || bundleName, description: pkg.description || '', keywords: pkg.keywords || [], version: pkg.version || '', repository: pkg.repository || null, entries: entries, pkgPath: pkgPath }
  }
  async function discoverBundles(profileRoot) {
    const discovered = []
    let pkgText = ''
    try { pkgText = await readFile(profileRoot + '/package.json') } catch (err) {}
    let bundles = []
    try { const pkg = JSON.parse(pkgText); const dsh = pkg && pkg.dsh; if (dsh && dsh.profile && Array.isArray(dsh.profile.bundles)) bundles = dsh.profile.bundles } catch (err) {}
    for (let i = 0; i < bundles.length; i++) {
      const bundleName = bundles[i]
      if (BASE_BUNDLES.indexOf(bundleName) >= 0) continue
      const info = await resolveBundle(profileRoot, bundleName)
      if (info) { info.installIndex = i; discovered.push(info) }
    }
    return discovered
  }
  function infoFor(entryId, meta) {
    const known = config.plugins && config.plugins[entryId]
    if (known) return known
    if (entryId && String(entryId).indexOf('ui-skin-') === 0) return { label: '皮肤：' + String(entryId).replace(/^ui-skin-/,''), category: '皮肤主题', tags: ['皮肤','主题','UI'], capability: '皮肤主题（由皮肤中心管理）', boundary: '' }
    return { label: humanLabel(meta && meta.name) || entryId, category: '其他', tags: genericTags(meta && meta.keywords), capability: (meta && meta.description) || '', boundary: '' }
  }
  function ensureInstallTime(key) { if (!state.installTimes[key]) state.installTimes[key] = Date.now(); return state.installTimes[key] }

  // 运行时启用状态：优先读 loader（权威），回退到补丁文件
  function runtimeDisabled() {
    const map = {}
    if (loader) {
      try { for (const e of loader.entries()) if (e.options && e.options.id && e.disabled) map[e.options.id] = true } catch (err) {}
    }
    return map
  }

  async function analyze() {
    const result = {
      ok: true, summary: { total: 0, enabled: 0, disabled: 0, active: 0, conflicts: 0, pendingUpdateCount: 0, markedFailedCount: 0, protectedCount: 0, unknownCount: 0 },
      plugins: [], tagGroups: [], overlaps: [], conflicts: [], failedPlugins: [], warnings: [],
    }
    const paths = await resolveHome()
    if (!paths || !paths.profileRoot) { result.ok = false; result.warnings.push('无法解析 profile 路径'); return result }
    await loadConfig(paths.home)
    await ensureStars()
    await ensureUpdates()
    const markedSet = new Set(state.markedFailed)
    const disabledMap = runtimeDisabled()
    const clientIds = getClientGraphIds()
    const discovered = await discoverBundles(paths.profileRoot)
    const bundleEntryIds = {}
    for (const b of discovered) for (const e of b.entries) bundleEntryIds[e.entryId] = b.bundle
    const plugins = []
    const seen = {}
    let unknownCount = 0, pendingUpdateCount = 0
    for (const b of discovered) {
      const installEpoch = ensureInstallTime(b.bundle)
      const repo = repoFromUrl(b.repository)
      for (const e of b.entries) {
        const entryId = e.entryId
        const moduleName = e.moduleName || b.name || ''
        const info = infoFor(entryId, b)
        const isKnown = !!(config.plugins && config.plugins[entryId])
        if (!isKnown) unknownCount++
        const enabled = !disabledMap[entryId]
        const activeClient = moduleName ? clientIds.has(moduleName) : false
        const isProtected = (config.protected || []).indexOf(entryId) >= 0
        const marked = markedSet.has(entryId)
        const status = marked ? 'failed' : (!enabled ? 'disabled' : (activeClient ? 'active' : 'inactive'))
        const stars = starNumber(entryId)
        const cfgEntry = config.plugins && config.plugins[entryId]
        const entryRepo = (cfgEntry && cfgEntry.repo) || repo
        const iconOwner = entryRepo ? String(entryRepo).split('/')[0] : null
        const icon = iconOwner ? 'https://github.com/' + iconOwner + '.png?size=96' : null
        const latestVersion = (cfgEntry && cfgEntry.latestVersion) || ((state.updates && state.updates[entryId] && typeof state.updates[entryId].latest === 'string') ? state.updates[entryId].latest : null)
        const installedVersion = b.version || ''
        const hasUpdate = (state.updates && state.updates[entryId] && state.updates[entryId].hasUpdate) ? true : (latestVersion ? compareVersion(latestVersion, installedVersion) > 0 : false)
        if (hasUpdate) pendingUpdateCount++
        plugins.push({
          entryId, moduleName, label: info.label || entryId, category: info.category || '其他',
          tags: info.tags || [], capability: info.capability || '', boundary: info.boundary || '',
          bundle: b.bundle, known: isKnown, enabled, activeClient, protected: isProtected, markedFailed: marked, status,
          stars, installIndex: b.installIndex, installEpoch, installTime: timeCategory(installEpoch),
          repo: entryRepo, icon, installedVersion, latestVersion: latestVersion || null, hasUpdate,
          toggleable: !isProtected,
        })
        seen[entryId] = true
      }
    }

    // 皮肤条目（由皮肤中心管理，互斥开关写在 home 补丁；非 profile bundle 内条目）
    let homePatchText = ''
    try { homePatchText = await readFile(paths.home + '/cordis.patch.yml') } catch (err) {}
    let profilePatchText = ''
    try { profilePatchText = await readFile(paths.profileRoot + '/cordis.patch.yml') } catch (err) {}
    const disabledByHome = readDisabledMap(homePatchText)
    const skinIds = new Set()
    for (const id in disabledByHome) if (String(id).indexOf('ui-skin-') === 0) skinIds.add(id)
    if (loader) { try { for (const e of loader.entries()) if (e && e.id && String(e.id).indexOf('ui-skin-') === 0) skinIds.add(e.id) } catch (err) {} }
    for (const entryId of skinIds) {
      if (seen[entryId]) continue
      const skinEnabled = !disabledByHome[entryId] && !disabledMap[entryId]
      plugins.push({
        entryId: entryId, moduleName: '', label: '皮肤：' + String(entryId).replace(/^ui-skin-/,''), category: '皮肤主题',
        tags: ['皮肤', '主题', 'UI'], capability: '皮肤主题（由皮肤中心管理）', boundary: '',
        bundle: 'dsh-skins', known: false, enabled: skinEnabled, activeClient: false, protected: false, markedFailed: false, status: skinEnabled ? 'inactive' : 'disabled',
        stars: 0, installIndex: 9999, installEpoch: 0, installTime: '更早', repo: null, icon: null, installedVersion: '', latestVersion: null, hasUpdate: false,
        toggleable: false,
      })
      seen[entryId] = true
    }

    result.plugins = plugins
    result.summary.total = plugins.length
    result.summary.enabled = plugins.filter(function (p) { return p.enabled }).length
    result.summary.disabled = plugins.filter(function (p) { return !p.enabled }).length
    result.summary.active = plugins.filter(function (p) { return p.activeClient }).length
    result.summary.protectedCount = plugins.filter(function (p) { return p.protected }).length
    result.summary.unknownCount = unknownCount
    result.summary.markedFailedCount = plugins.filter(function (p) { return p.markedFailed }).length
    result.summary.pendingUpdateCount = pendingUpdateCount

    const tagMap = {}
    for (const p of plugins) for (const t of p.tags) { (tagMap[t] = tagMap[t] || []).push(p.entryId) }
    result.tagGroups = Object.keys(tagMap).sort().map(function (t) { return { tag: t, plugins: tagMap[t] } })
    result.overlaps = (config.overlaps || []).map(function (o) {
      const entries = o.entries.map(function (id) { const p = plugins.find(function (x) { return x.entryId === id }); return p ? { entryId: id, label: p.label, enabled: p.enabled, activeClient: p.activeClient, status: p.status } : { entryId: id, label: id, enabled: false, activeClient: false, status: 'disabled' } })
      return { id: o.id, label: o.label, tag: o.tag, note: o.note, entries: entries, enabledCount: entries.filter(function (e) { return e.enabled }).length, activeCount: entries.filter(function (e) { return e.activeClient }).length }
    })
    const enabledSet = new Set(plugins.filter(function (p) { return p.enabled }).map(function (p) { return p.entryId }))
    const coexistence = []
    for (const r of (config.compatRules || [])) {
      const triggered = r.entries.filter(function (id) { return enabledSet.has(id) })
      if (triggered.length >= 2) coexistence.push({ id: r.id, type: r.type, severity: r.severity, confidence: r.confidence, title: r.title, desc: r.desc, evidence: r.evidence, entries: r.entries, triggeredEntries: triggered, fixes: r.fixes })
    }
    const existence = detectExistenceConflicts(profilePatchText, bundleEntryIds)
    result.conflicts = coexistence.concat(existence)
    result.summary.conflicts = result.conflicts.length
    return result
  }

  async function applyToggle(entryId, enabled) {
    if (!entryId) return { ok: false, error: '缺少 entryId' }
    const paths = await resolveHome()
    if (!paths || !paths.profileRoot) return { ok: false, error: '无法解析 profile 路径' }
    await loadConfig(paths.home)
    if (!enabled && (config.protected || []).indexOf(entryId) >= 0) return { ok: false, error: '「' + entryId + '」为核心条目，受保护，不允许停用（停用可能导致 DSH 无法进入）' }
    const patchPath = paths.profileRoot + '/cordis.patch.yml'
    let text = ''
    try { text = await readFile(patchPath) } catch (err) {}
    const parsed = parsePatch(text)
    const changed = setEntryDisabled(parsed, entryId, !enabled)
    if (!changed) return { ok: true, changed: false, restartRequired: false, entryId, enabled, message: enabled ? '插件本就处于启用状态' : '插件本就处于停用状态' }
    await writeFile(patchPath, serializePatch(parsed))
    return { ok: true, changed: true, restartRequired: false, entryId, enabled, message: (enabled ? '已启用' : '已停用') + '「' + entryId + '」，已写入补丁并热重载' }
  }

  async function applySwitch(groupId, entryId) {
    const paths = await resolveHome()
    await loadConfig(paths.home)
    const group = (config.overlaps || []).find(function (o) { return o.id === groupId })
    if (!group) return { ok: false, error: '未知重叠组 ' + groupId }
    if (group.entries.indexOf(entryId) < 0) return { ok: false, error: '该插件不在此重叠组内' }
    if (!paths || !paths.profileRoot) return { ok: false, error: '无法解析 profile 路径' }
    const patchPath = paths.profileRoot + '/cordis.patch.yml'
    let text = ''
    try { text = await readFile(patchPath) } catch (err) {}
    const parsed = parsePatch(text)
    let changed = false
    for (const id of group.entries) {
      if (id === entryId) { if (setEntryDisabled(parsed, id, false)) changed = true }
      else { if (setEntryDisabled(parsed, id, true)) changed = true }
    }
    if (changed) await writeFile(patchPath, serializePatch(parsed))
    return { ok: true, changed, restartRequired: false, groupId, entryId, message: '已切换到「' + entryId + '」（同组其余已停用），已写入补丁并热重载' }
  }

  async function applyFix(fixId) {
    const paths = await resolveHome()
    await loadConfig(paths.home)
    let fix = null
    for (const r of (config.compatRules || [])) { for (const f of r.fixes) { if (f.id === fixId) { fix = f; break } } if (fix) break }
    if (!fix) {
      let pt = ''
      if (paths && paths.profileRoot) { try { pt = await readFile(paths.profileRoot + '/cordis.patch.yml') } catch (err) {} }
      const discovered = await discoverBundles(paths.profileRoot)
      const bundleEntryIds = {}
      for (const b of discovered) for (const e of b.entries) bundleEntryIds[e.entryId] = b.bundle
      for (const c of detectExistenceConflicts(pt, bundleEntryIds)) { for (const f of c.fixes) { if (f.id === fixId) { fix = f; break } } if (fix) break }
    }
    if (!fix) return { ok: false, error: '未知修复方案 ' + fixId }
    if (fix.action === 'manual') return { ok: true, changed: false, restartRequired: false, message: '需手动修复：' + fix.label }
    return applyToggle(fix.target, false)
  }

  async function analyzeFailure(entryId) {
    const paths = await resolveHome()
    await loadConfig(paths.home)
    const discovered = await discoverBundles(paths.profileRoot)
    let foundEntry = null, foundBundle = null
    for (const b of discovered) { for (const e of b.entries) { if (e.entryId === entryId) { foundEntry = e; foundBundle = b; break } } if (foundEntry) break }
    if (!foundEntry) return { ok: false, entryId, error: '未找到插件 ' + entryId }
    const moduleName = foundEntry.moduleName || foundBundle.name || ''
    const label = (function () { const c = config.plugins && config.plugins[entryId]; return c ? c.label : humanLabel(foundBundle.name) })()
    const reasons = []
    const evidence = []
    const fixPlans = []
    let profilePatchText = '', homePatchText = ''
    try { profilePatchText = await readFile(paths.profileRoot + '/cordis.patch.yml') } catch (err) {}
    try { homePatchText = await readFile(paths.home + '/cordis.patch.yml') } catch (err) {}
    const dProfile = readDisabledMap(profilePatchText)
    const dHome = readDisabledMap(homePatchText)
    const isDisabled = !!(dProfile[entryId] || dHome[entryId])
    let pkg = null
    try { pkg = JSON.parse(await readFile(foundBundle.pkgPath)) } catch (err) {}
    const hasClientDecl = !!(pkg && pkg.dsh && pkg.dsh.client && pkg.dsh.client.platform === 'web')
    let clientExists = false
    if (moduleName && cm) { try { clientExists = !!cm.clientPath(moduleName) } catch (err) {} }
    const inGraph = moduleName ? getClientGraphIds().has(moduleName) : false
    let status
    if (isDisabled) {
      status = 'disabled'
      reasons.push('该插件已被停用（' + (dProfile[entryId] ? 'profile 补丁' : 'home 补丁') + ' 中 disabled: true）')
      evidence.push('cordis.patch.yml 存在 disabled 行')
      fixPlans.push({ action: 'enable', target: entryId, label: '启用该插件', impact: '热重载后生效，恢复该插件全部功能' })
    } else if (!hasClientDecl) {
      status = 'inactive'
      reasons.push('该插件为 host-only（无 dsh.client 浏览器端声明），属正常情况，非失效')
      evidence.push('package.json 无 dsh.client.web 声明')
      fixPlans.push({ action: 'none', label: '无需处理', impact: '无' })
    } else if (!clientExists) {
      status = 'inactive'
      reasons.push('声明了 dsh.client，但客户端 bundle 未构建（缺少 ./client 产物）')
      evidence.push('exports["./client"] 指向的 bundle 文件不存在')
      fixPlans.push({ action: 'rebuild', label: '在插件目录执行 pnpm run build', impact: '重新构建后浏览器端恢复' })
    } else if (!inGraph) {
      status = 'inactive'
      reasons.push('客户端 bundle 存在但未进入生效图（可能被 patch 停用或未满足加载条件）')
      evidence.push('clientModules.graph() 中不存在该模块')
      fixPlans.push({ action: 'enable', target: entryId, label: '确认未 disabled 且 bundle 已构建，必要时启用', impact: '热重载后生效' })
    } else {
      status = 'active'
      reasons.push('未发现明确失效原因：客户端已生效。若实际不可用，可能是功能层面部分失效（工具/Slot 被其它插件覆盖）')
      evidence.push('客户端 bundle 已在生效图中')
      fixPlans.push({ action: 'check-overlap', label: '查看「重叠切换」与「兼容检测」确认是否被覆盖', impact: '若重叠则切换/停用冲突方' })
    }
    return { ok: true, entryId, label, moduleName, status, reasons, evidence, fixPlans }
  }

  async function detectFailures(entryIds) {
    let ids = entryIds
    if (!Array.isArray(ids) || ids.length === 0) {
      const marked = new Set(state.markedFailed)
      const data = await analyze()
      ids = data.plugins.filter(function (p) { return marked.has(p.entryId) || p.status === 'inactive' || p.status === 'failed' }).map(function (p) { return p.entryId })
    }
    const results = []
    for (const id of ids) results.push(await analyzeFailure(id))
    return { ok: true, results }
  }

  // 一键修复：对所有失效/可疑插件，应用其可自动修复的修复方案（action=enable）
  async function fixAllFailures() {
    const data = await analyze()
    const marked = new Set(state.markedFailed)
    const ids = data.plugins.filter(function (p) { return marked.has(p.entryId) || p.status === 'inactive' || p.status === 'failed' }).map(function (p) { return p.entryId })
    const results = []
    for (const id of ids) {
      const a = await analyzeFailure(id)
      const enableFix = (a && a.fixPlans || []).find(function (f) { return f.action === 'enable' && f.target })
      if (enableFix) {
        const r = await applyToggle(enableFix.target, true)
        results.push({ entryId: id, label: a.label, fixed: !!(r && r.ok), message: (r && (r.message || r.error)) || '' })
      } else {
        results.push({ entryId: id, label: a.label, fixed: false, message: '需手动修复' })
      }
    }
    const fixedCount = results.filter(function (r) { return r.fixed }).length
    return { ok: true, results, fixedCount, total: results.length }
  }

  async function markFailed(entryId) {
    if (!entryId) return { ok: false, error: '缺少 entryId' }
    if (state.markedFailed.indexOf(entryId) < 0) state.markedFailed.push(entryId)
    const analysis = await analyzeFailure(entryId)
    return { ok: true, entryId, message: '已标记为失效', analysis }
  }
  async function unmarkFailed(entryId) {
    state.markedFailed = state.markedFailed.filter(function (id) { return id !== entryId })
    return { ok: true, entryId, message: '已取消失效判定' }
  }

  // 优先用显式 token，其次用 gh CLI 已登录的 token（会话内缓存，避免明文落盘）
  let ghTokenPromise = null
  function getGhToken() {
    if (ghTokenPromise) return ghTokenPromise
    ghTokenPromise = new Promise(function (resolve) {
      execFile('gh', ['auth', 'token'], { timeout: 5000, windowsHide: true }, function (err, stdout) {
        if (err) { resolve(null); return }
        const t = String(stdout || '').trim()
        resolve(t || null)
      })
    })
    return ghTokenPromise
  }

  async function githubStars(repo) {
    // 效仿 dsh-market（插件市场）：宿主进程内用 Node 原生 fetch 直连 GitHub API。
    const headers = { accept: 'application/json', 'user-agent': 'dsh-plugin-integration' }
    const token = (config.githubToken) || process.env.GITHUB_TOKEN || process.env.DSH_GITHUB_TOKEN || await getGhToken()
    if (token) headers.authorization = 'Bearer ' + token
    let lastErr
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const res = await fetch('https://api.github.com/repos/' + repo, {
          headers,
          signal: AbortSignal.timeout(15000),
        })
        if (res.status === 403 || res.status === 429) throw new Error('RATE_LIMIT')
        if (!res.ok) throw new Error('HTTP ' + res.status)
        const data = await res.json()
        return typeof data.stargazers_count === 'number' ? data.stargazers_count : null
      } catch (err) {
        lastErr = err
        const msg = (err && err.message) || String(err)
        if (msg === 'RATE_LIMIT') break // 不重试限流
        // 网络/超时类错误：短暂退避后重试
        if (attempt < 2) await new Promise(function (r) { setTimeout(r, 500 * (attempt + 1)) })
      }
    }
    throw lastErr || new Error('fetch failed')
  }

  async function refreshStars() {
    const paths = await resolveHome()
    await loadConfig(paths.home)
    await ensureStars()
    const discovered = await discoverBundles(paths.profileRoot)
    const now = Date.now()
    const results = []
    // 按 repo 去重：web-ui-all 等聚合包多个条目共享同一 GitHub 仓库，只请求一次。
    const byRepo = new Map()
    for (const b of discovered) {
      for (const e of b.entries) {
        const entryId = e.entryId
        const cfg = config.plugins && config.plugins[entryId]
        const repo = (cfg && cfg.repo) || repoFromUrl(b.repository)
        const label = (cfg && cfg.label) || humanLabel(b.name)
        if (!repo) { results.push({ entryId, label, repo: null, stars: null, error: '未配置 GitHub 仓库' }); continue }
        let g = byRepo.get(repo)
        if (!g) { g = { repo: repo, entries: [] }; byRepo.set(repo, g) }
        g.entries.push({ entryId, label })
      }
    }
    const targets = []
    for (const g of byRepo.values()) {
      const first = g.entries[0]
      const cached = state.stars[first.entryId]
      if (cached && typeof cached.n === 'number' && (now - (cached.at || 0)) < STARS_TTL_MS) {
        for (const en of g.entries) results.push({ entryId: en.entryId, label: en.label, repo: g.repo, stars: cached.n, cached: true })
      } else {
        targets.push(g)
      }
    }
    let rateLimited = false
    let idx = 0
    async function worker() {
      while (idx < targets.length) {
        const g = targets[idx++]
        if (rateLimited) {
          const cached = state.stars[g.entries[0].entryId]
          if (cached && typeof cached.n === 'number') { for (const en of g.entries) results.push({ entryId: en.entryId, label: en.label, repo: g.repo, stars: cached.n, cached: true, error: '限流，用缓存' }) }
          else { for (const en of g.entries) results.push({ entryId: en.entryId, label: en.label, repo: g.repo, stars: null, error: 'GitHub API 限流，未获取' }) }
          continue
        }
        try {
          const n = await githubStars(g.repo)
          if (n !== null) {
            const at = Date.now()
            for (const en of g.entries) state.stars[en.entryId] = { n: n, at: at }
            for (const en of g.entries) results.push({ entryId: en.entryId, label: en.label, repo: g.repo, stars: n })
          } else {
            for (const en of g.entries) results.push({ entryId: en.entryId, label: en.label, repo: g.repo, stars: null, error: '响应缺 stargazers_count' })
          }
        } catch (err) {
          const msg = (err && err.message) || String(err)
          if (msg === 'RATE_LIMIT') rateLimited = true
          const cached = state.stars[g.entries[0].entryId]
          if (cached && typeof cached.n === 'number') { for (const en of g.entries) results.push({ entryId: en.entryId, label: en.label, repo: g.repo, stars: cached.n, cached: true, error: msg }) }
          else { for (const en of g.entries) results.push({ entryId: en.entryId, label: en.label, repo: g.repo, stars: null, error: msg }) }
        }
      }
    }
    await Promise.all([worker(), worker(), worker()])
    await saveStars(paths.home)
    return { ok: true, results, rateLimited }
  }

  async function syncUpdates() {
    const paths = await resolveHome()
    await loadConfig(paths.home)
    await ensureUpdates()
    const discovered = await discoverBundles(paths.profileRoot)
    const specs = await readInstalledSpecs(paths.profileRoot)
    const lockCommits = await readLockCommits(paths.profileRoot)
    const results = []
    let rateLimited = false
    for (const b of discovered) {
      const spec = specs[b.bundle] || ''
      for (const e of b.entries) {
        const entryId = e.entryId
        const cfgEntry = config.plugins && config.plugins[entryId]
        const label = (cfgEntry && cfgEntry.label) || humanLabel(b.name)
        const installedVersion = b.version || ''
        let latest = (cfgEntry && cfgEntry.latestVersion) || null
        let hasUpdate = false
        let source = latest ? 'config' : 'none'
        let error = null
        if (!latest) {
          if (!spec || String(spec).startsWith('file:') || String(spec).startsWith('link:')) {
            source = 'local'
          } else if (String(spec).startsWith('github:')) {
            const gh = /^github:([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+?)(?:#.*)?$/.exec(String(spec))
            if (gh) {
              try {
                const head = await githubHead(gh[1])
                const current = lockCommits[gh[1].toLowerCase()] || null
                latest = head
                hasUpdate = !!(current && head && current !== head)
                source = 'github'
              } catch (err) {
                if ((err && err.message) === 'RATE_LIMIT') rateLimited = true
                error = (err && err.message) || String(err)
                source = 'github'
              }
            } else { source = 'unknown' }
          } else {
            try {
              const v = await npmLatest(b.bundle)
              latest = v
              hasUpdate = !!v && compareVersion(v, installedVersion) > 0
              source = 'npm'
            } catch (err) {
              error = (err && err.message) || String(err)
              source = 'npm'
            }
          }
        } else {
          hasUpdate = compareVersion(latest, installedVersion) > 0
        }
        state.updates[entryId] = { latest: latest || null, hasUpdate: !!hasUpdate, source: source, error: error || null, at: Date.now() }
        results.push({ entryId, label, installedVersion, latest: latest || null, hasUpdate: !!hasUpdate, source, error: error || null })
      }
    }
    await saveUpdates(paths.home)
    return { ok: true, results, rateLimited, updated: results.filter(function (r) { return r.hasUpdate }).map(function (r) { return r.entryId }) }
  }

  // 一键更新：对「待更新」插件逐个跑 `dsh plugin --profile <p> update <bundle>`
  function profileName(profileRoot) {
    const n = String(profileRoot || '').replace(/\\/g, '/').replace(/\/+$/, '')
    const i = n.lastIndexOf('/')
    return i >= 0 ? n.slice(i + 1) : 'web'
  }
  function runDshUpdate(profile, packageName) {
    return new Promise(function (resolve) {
      let child
      try {
        child = spawn('dsh', ['plugin', '--profile', profile, 'update', packageName], { shell: true, windowsHide: true, env: Object.assign({}, process.env, { CI: 'true' }), stdio: ['ignore', 'pipe', 'pipe'] })
      } catch (err) { resolve({ ok: false, error: 'spawn 失败：' + ((err && err.message) || String(err)) }); return }
      let out = ''
      const collect = function (chunk) { out = (out + String(chunk)).slice(-4096) }
      if (child.stdout) child.stdout.on('data', collect)
      if (child.stderr) child.stderr.on('data', collect)
      let settled = false
      const timer = setTimeout(function () { if (settled) return; settled = true; try { child.kill() } catch (e) {} resolve({ ok: false, error: '更新超时（10 分钟）', output: out.slice(-1500) }) }, 10 * 60 * 1000)
      child.on('error', function (e) { if (settled) return; settled = true; clearTimeout(timer); resolve({ ok: false, error: e.message, output: out.slice(-1500) }) })
      child.on('close', function (code) { if (settled) return; settled = true; clearTimeout(timer); resolve({ ok: code === 0, code: code, error: code === 0 ? null : ('exit ' + code), output: out.slice(-1500) }) })
    })
  }
  async function updatePlugins(entryIds) {
    const paths = await resolveHome()
    if (!paths || !paths.profileRoot) return { ok: false, error: '无法解析 profile 路径' }
    await loadConfig(paths.home)
    await ensureUpdates()
    const profile = profileName(paths.profileRoot)
    const data = await analyze()
    const specs = await readInstalledSpecs(paths.profileRoot)
    const entryBundle = {}
    for (const p of data.plugins) entryBundle[p.entryId] = p.bundle
    const targets = (Array.isArray(entryIds) && entryIds.length > 0) ? entryIds : data.plugins.filter(function (p) { return p.hasUpdate }).map(function (p) { return p.entryId })
    const bundles = []
    const seen = {}
    for (const id of targets) {
      const bn = entryBundle[id]
      if (!bn || seen[bn]) continue
      seen[bn] = true
      const spec = specs[bn] || ''
      if (String(spec).startsWith('file:') || String(spec).startsWith('link:')) continue
      bundles.push(bn)
    }
    if (bundles.length === 0) return { ok: true, results: [], okCount: 0, total: 0, message: '没有可更新的插件（npm/github 来源）' }
    const results = []
    for (const bn of bundles) {
      const r = await runDshUpdate(profile, bn)
      results.push({ bundle: bn, ok: r.ok, error: r.error || null, output: r.output || '' })
      // 更新后清掉该 bundle 的缓存，避免旧 hasUpdate 残留
      for (const k in state.updates) { const e = entryBundle[k]; if (e === bn) delete state.updates[k] }
      await saveUpdates(paths.home)
    }
    const okCount = results.filter(function (r) { return r.ok }).length
    return { ok: true, results, okCount, total: results.length, restartRequired: okCount > 0 }
  }

  async function predictUpdateConflicts(entryIds) {
    const ids = entryIds || []
    const data = await analyze()
    const enabledSet = new Set(data.plugins.filter(function (p) { return p.enabled }).map(function (p) { return p.entryId }))
    const targets = new Set(ids)
    const warnings = []
    for (const r of (config.compatRules || [])) {
      const involved = r.entries.filter(function (id) { return targets.has(id) })
      if (involved.length > 0 && r.entries.some(function (id) { return enabledSet.has(id) })) warnings.push({ kind: 'rule', title: r.title, desc: '更新涉及「' + r.title + '」规则，更新后与组内其它插件（' + r.entries.join(', ') + '）兼容关系可能变化。', severity: r.severity })
    }
    for (const o of (config.overlaps || [])) {
      const involved = o.entries.filter(function (id) { return targets.has(id) })
      if (involved.length > 0) warnings.push({ kind: 'overlap', title: o.label, desc: '更新涉及「' + o.label + '」重叠组，生效主体可能变化。', severity: 'medium' })
    }
    for (const id of ids) { if ((config.protected || []).indexOf(id) >= 0) warnings.push({ kind: 'protected', title: '受保护条目', desc: '「' + id + '」为核心受保护条目，更新需格外谨慎。', severity: 'high' }) }
    return { ok: true, warnings, updateTargets: ids }
  }

  async function reanalyze() {
    const r = await analyze()
    await logOperation('reanalyze', '重新检测插件状态（共 ' + (r && r.summary ? r.summary.total : 0) + ' 个插件）', (r && r.ok) ? '' : ((r && r.warnings && r.warnings[0]) || ''), !!(r && r.ok))
    return r
  }

  async function dispatch(method, args) {
    args = args || {}
    if (method === 'analyze') return analyze()
    if (method === 'reanalyze') return reanalyze()
    if (method === 'getOperations') return getOperations()
    if (method === 'deleteOperation') return deleteOperation(args.id)
    if (method === 'clearOperations') return clearOperations(args.scope)
    if (method === 'getUsage') return getUsage()
    if (method === 'clearUsage') return clearUsage()
    const result = await (function () {
      if (method === 'toggle') return applyToggle(args.entryId, !!args.enabled)
      if (method === 'switch') return applySwitch(args.groupId, args.entryId)
      if (method === 'applyFix') return applyFix(args.fixId)
      if (method === 'markFailed') return markFailed(args.entryId)
      if (method === 'unmarkFailed') return unmarkFailed(args.entryId)
      if (method === 'detectFailures') return detectFailures(args.entryIds)
      if (method === 'fixAllFailures') return fixAllFailures()
      if (method === 'refreshStars') return refreshStars()
      if (method === 'syncUpdates') return syncUpdates()
      if (method === 'updatePlugins') return updatePlugins(args.entryIds)
      if (method === 'predictUpdateConflicts') return predictUpdateConflicts(args.entryIds)
      return { ok: false, error: '未知 method: ' + method }
    })()
    const d = describeAction(method, args, result)
    await logOperation(d.action, d.detail, d.message, !!(result && result.ok !== false))
    return result
  }

  // 实时用量统计：每次工具执行后记录调用次数 + 估算 token 消耗
  ctx.on('tools/execute', async function (exec, next) {
    const result = await next()
    try { recordUsage(exec.name, exec.arguments, result) } catch (err) { console.error('recordUsage:', err && err.message) }
    return result
  })

  // HTTP RPC
  ctx.webServer.register({
    kind: 'prefix',
    path: '/api/plugin-integration',
    handler: async function (req, res) {
      try {
        const url = new URL(req.url || '/', 'http://x')
        const method = url.pathname.slice('/api/plugin-integration'.length).replace(/^\//, '')
        let args = {}
        if (req.method === 'POST') {
          let body = ''
          for await (const chunk of req) body += chunk
          try { args = JSON.parse(body || '{}') } catch (err) {}
        }
        const result = await dispatch(method, args)
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
        res.end(JSON.stringify(result))
      } catch (err) {
        res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
        res.end(JSON.stringify({ ok: false, error: (err && err.message) || String(err) }))
      }
    },
  })

  // 模型工具
  ctx.tools.register(defineTool({
    name: 'plugin_integration',
    description: '插件整合中心：动态发现已装插件、tag/star/入库时间、功能重叠与兼容检测、启用停用切换、失效判定与失效检测、GitHub star 抓取、待更新冲突预判。',
    parameters: {
      action: { type: 'string', enum: ['analyze', 'toggle', 'switch', 'applyFix', 'markFailed', 'unmarkFailed', 'detectFailures', 'fixAllFailures', 'refreshStars', 'syncUpdates', 'updatePlugins', 'predictUpdateConflicts'], description: 'analyze=查看分析；toggle=启停；switch=重叠切换；applyFix=应用修复；markFailed=判定失效；unmarkFailed=取消失效；detectFailures=失效检测；fixAllFailures=一键修复失效插件；refreshStars=刷新 GitHub star；syncUpdates=同步插件更新状态；updatePlugins=一键更新插件；predictUpdateConflicts=更新冲突预判', required: true },
      entryId: { type: 'string', description: '插件 loader 条目 id' },
      enabled: { type: 'boolean', description: 'toggle 的目标启用状态' },
      groupId: { type: 'string', description: '重叠组 id' },
      fixId: { type: 'string', description: '修复方案 id' },
      entryIds: { type: 'array', items: { type: 'string' }, description: 'detectFailures/predictUpdateConflicts 的条目 id 列表' },
    },
    output: { schema: { type: 'object', additionalProperties: true }, render: function (_args, value) { return [{ type: 'text', text: JSON.stringify(value) }] } },
    execute: async function (args) {
      args = args || {}
      return dispatch(args.action, { entryId: args.entryId, enabled: args.enabled, groupId: args.groupId, fixId: args.fixId, entryIds: args.entryIds })
    },
  }))
}
