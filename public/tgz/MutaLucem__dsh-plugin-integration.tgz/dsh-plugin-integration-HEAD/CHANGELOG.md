# 更新 / 修复记录（CHANGELOG）

本文件记录 `dsh-plugin-integration` 的版本演进、每次更新内容、修复的问题与已知缺陷，便于维护者回溯与后续迭代。

---

## [1.3.10] —— 待更新列表一键更新

### 新增

- 插件清单工具栏新增 **「一键更新」** 按钮：对「待更新」的插件（npm/github 来源）逐个执行 `dsh plugin --profile <p> update <bundle>`，返回「成功 X / 总数 Y」。
- 更新后自动清除对应 bundle 的更新缓存；更新完成需**重启 DSH** 生效（提示 `restartRequired`）。
- 新增 RPC/工具 action `updatePlugins`。

### 说明

- 仅 standalone 形态支持（需宿主进程内 `spawn` 调用 `dsh plugin update`）；动态形态运行在沙箱内、无 `child_process`，无法执行更新，故不提供该按钮。
- `file:`/`link:` 本地包不参与更新（无「更新」概念）。

---

## [1.3.9] —— 失效插件一键修复 + 单条修复

### 新增

- 「失效插件」页新增 **「一键修复」** 按钮：对所有失效/可疑插件，自动应用其可自动修复的方案（`action: enable`，即启用被停用/未生效的插件），返回「已修复 X / 总数 Y」。
- 每个失效信息框（`FailedCard`）右上角新增 **「修复」** 按钮：对有可自动修复方案的条目一键启用；无可自动修复方案的显示「需手动修复」。
- 新增 RPC/工具 action `fixAllFailures`；动态形态同步。

---

## [1.3.8] —— 实时用量统计（调用次数 + token 消耗）

### 新增

- 新增「用量统计」标签页：实时统计**正在运行的插件中，工具被模型调用的次数**与**估算 token 消耗累积**。
- 实现：宿主侧通过 `ctx.on('tools/execute', …)` 挂钩每次工具执行，记录工具名、调用次数；token 用量按工具入参 + 结果文本估算（ASCII 约 4 字符/token、CJK 约 2 字符/token）。
- 工具 → 插件尽力映射（`ssh_*`→ssh、`vision_*`→DeepEye、`viking_*`→OpenViking、`prompt_*`→Lorebook 等），未匹配的归入「未归属」。
- 展示：按插件聚合 + 按工具明细 + 总调用/总 token 汇总；支持「刷新」「清空」；数据持久化到 `~/.dsh/dsh-plugin-integration.usage.json`（防抖落盘）。
- 新增 RPC：`getUsage` / `clearUsage`。

### 说明

- token 为**估算值**（非模型账单级精确值），用于衡量各插件/工具的用量占比。

---

## [1.3.7] —— 同步插件更新状态

### 新增

- 插件清单工具栏新增「同步更新」按钮：对每个插件按其安装来源真实检测是否有更新——
  - **npm 包**（`^x.y.z` 等）：查 `registry.npmjs.org/<name>/latest`，与已装版本比较；
  - **github 包**（`github:owner/repo`）：查 GitHub HEAD 提交，与 `pnpm-lock.yaml` 里的已装提交比较（自动读 `gh` token，额度 5000/小时）；
  - **`file:`/`link:` 本地包**：不检测（本地开发）。
- 结果持久化到 `~/.dsh/dsh-plugin-integration.updates.json`，`analyze` 直接读缓存展示「待更新」；配置文件里手动填 `latestVersion` 仍可作为兜底覆盖。
- 新增 RPC / 工具 action `syncUpdates`，并写入操作日志。

---

## [1.3.6] —— 设置窗口拖拽缩放（四边 + 四角）

### 新增

- 给 DSH 设置弹窗注入 **8 个拖拽热区**（上/下/左/右四边 + 四个角），可像原生窗口一样从任意边/角拖拽缩放，光标随方向变化（`ns-resize`/`ew-resize`/`nwse-resize`/`nesw-resize`）；`min 480×360`，`max` 受视口上限约束（`100vw/vh − 48px`）。
- 标题栏「重置窗口」按钮一键恢复默认 800×800。
- 尺寸**持久化**到 `localStorage`（`dsh.pluginIntegration.panelSize`，像素宽高）：`MutationObserver` 检测弹窗出现并注入热区，`ResizeObserver` 记录拖拽结果，刷新/重开后恢复上次大小。

---

## [1.3.5] —— 去重 + 插件 logo + star 持久化/全量生效

### 修复：组条目导致插件重复显示

- `parseInsertRows` 现识别 `group: true` 的组条目并跳过，只保留叶子（运行时）条目。此前 `@openviking/dsh-memory-plugin` 这种「组 + 运行时」嵌套补丁会把组和运行时各列一条、标签同源导致「两个一模一样的插件」。聚合包（web-ui-all 12 条目）解析无回归。

### 新增：插件 logo

- 每个插件卡片左侧新增圆形头像：有 GitHub 仓库（`repo` 字段）时用仓库 owner 头像 `https://github.com/{owner}.png?size=96`（与插件市场一致）；无仓库或加载失败时回退为首字母圆形占位。

### 修复：star 刷新只部分生效 / 重启丢失

- **根因**：GitHub 未认证 API 限流（60 次/小时）+ star 仅存内存、重启即丢 + 聚合包多个条目共享同一仓库导致重复请求。
- **star 持久化**：写入 `~/.dsh/dsh-plugin-integration.stars.json`，重启后 `analyze` 自动加载，**重启即恢复 star**。
- **TTL 缓存（24h）**：TTL 内的条目刷新时直接复用缓存，**不再重复请求**，避免限流。
- **按 repo 去重**：web-ui-all 等聚合包多个条目共享同一 GitHub 仓库时只请求一次，结果同步到全部条目。
- **并发 3 + 遇限流即停 + 重试**：网络/超时自动退避重试 3 次；命中 403/429 立即停止后续请求，已有缓存的条目回退用缓存。
- **可选 GitHub Token**：读 `config.githubToken` 或 `GITHUB_TOKEN` / `DSH_GITHUB_TOKEN` 环境变量，配置后额度 5000 次/小时，彻底摆脱限流。
- **自动读取 `gh` CLI 已登录 token**：若以上都未配置，插件会在会话内自动执行 `gh auth token`（一次、缓存、不落盘）获取认证 token，额度 5000 次/小时，**无需任何手工配置即可绕过未认证限流**。同时修复 `mergeConfig` 之前丢弃顶层 `githubToken` 字段的问题。
- 客户端刷新提示改为「新获取 X，缓存 Y，失败 Z（触发限流）」。

---

## [1.3.4] —— 日志分当前/历史 + 删除；GitHub star 真实抓取

### 日志：分「当前日志 / 历史日志」并支持删除

- 操作日志面板内新增两个子标签：**当前日志（本次启动）** 与 **历史日志**（上次启动及更早）；每次 DSH 启动生成唯一会话 id，据此区分本次会话与历史记录。
- 每条日志新增**「删除」**按钮（按记录唯一 id 删除）；面板提供**「清空当前」「清空历史」「清空全部」**。
- 日志记录结构新增 `id` + `session` 字段，旧记录（无 id/session）载入时自动补齐，归入历史日志。
- 新增 RPC：`deleteOperation(id)`、`clearOperations(scope=current|history|all)`；`getOperations` 改为返回 `{current, history}`。

### 修复：GitHub star 真实抓取

- 弃用 `ctx.get('web').fetch`（该服务在本部署未注册，永远失败），**改为宿主进程内的 Node 原生 `fetch`**，与「插件市场」`dsh-market` 的 `updates.ts`/`registry.ts` 同一实现方式：直连 `https://api.github.com/repos/{owner}/{repo}` 读取 `stargazers_count`，带 `accept: application/json`、`user-agent`、`AbortSignal.timeout(8000)`。
- 对 GitHub 未认证限流（403/429）给出明确提示「GitHub API 限流，请稍后再试」。
- 客户端「刷新 star」完成后提示「成功 X，失败 Y」，便于识别无仓库/未联网/限流的条目。

---

## [1.3.3] —— 操作日志 + 重新检测反馈

### 新增：操作日志

- 标题栏「重新检测」**左侧**新增「操作日志」按钮，点击展开日志面板（再次点击收起）。
- 记录每次操作并**按时间倒序**展示：启停 / 重叠切换 / 采用修复 / 标记失效 / 取消失效 / 失效检测 / 刷新 star / 更新预判 / 重新检测；每条含**时间戳、成功/失败徽标、操作类型、详情、结果消息**。
- 日志**持久化**到 `~/.dsh/dsh-plugin-integration.operations.json`（上限 500 条滚动），面板提供「清空」。
- Host 侧集中记录：`dispatch()` 统一在每次变更操作后调用 `logOperation()`，模型工具 `plugin_integration` 的 `execute` 也改走 `dispatch`，HTTP 与工具两条入口日志一致。

### 修复：重新检测无反馈

- 「重新检测」原逻辑确实实装（重新跑 `analyze`），但结果无变化时界面毫无反馈，看起来像「没反应」。现改为专用 `reanalyze` RPC：重新检测后**弹出「已重新检测」提示 + 标题栏显示「上次检测 HH:MM:SS」**，并同步写入操作日志。

---

## [1.3.2] —— 修复 standalone 启停失败 + 恢复「失效插件」页

standalone 形态（`src/host.standalone.js` + `src/client.standalone.js`）在本机重启实测后报告的两个 bug 的修复。

### 关键修复

- **「启用/停用」「重叠切换」「采用修复」报 `cannot resolve entry ui-dsh-aionui-panel` → 已修复**：standalone 版误用 `loader.update(leafId, {disabled})`，但加载器条目都嵌套在 `include` 子树下（全量 id 形如 `include:<rowId>`，见 `cordis-plugin-loader` 的 `EntryTree.resolve` 按 `:` 拆段），按叶子 id 无法解析。已改为与官方 `dsh-plugin-console` 一致的**补丁写入**：向 `~/.dsh/profiles/web/cordis.patch.yml` 写 `- id: X` + `disabled: true|false`，由 profile 的 HMR 监听器（`watchUserPatches` → chokidar `registerConfig`）热重载**即时生效并持久化**（无需重启）。同时 `runtimeDisabled()` 改按叶子 id（`entry.options.id`）匹配，web-ui-all 各子插件的启用状态判定不再失真。
- **standalone 缺失「失效插件」页 → 已恢复**：补回 Host 的 `analyzeFailure` / `detectFailures` 方法与 RPC、工具 action 枚举；客户端恢复「失效插件」标签页 + `FailedCard`（失效原因 / 依据 / 修复方案 + 具体影响）。
- **standalone 补存在性冲突检测**：`analyze()` 现交叉比对 profile 补丁的手动 `insert` 与 bundle 通道，识别「双重挂载」存在性冲突（此前兼容页只出共用性冲突）。
- **写盘改用 Node 原生 fs**：standalone 是宿主进程内的一等 Cordis 插件（非 vm 沙箱），补丁读写改用 `node:fs/promises`（与 `dsh-plugin-console` 一致），规避 `dsh-fs-sandbox` 无会话上下文时回退 `workspace-write` 导致的写盘拒绝。

---

## [1.3.1] —— 独立 bundle 形态（standalone）适配修复

形态 B（`src/host.standalone.js` + `src/client.standalone.js`）在本机完成「安装 + 重启」实测，修复 4 个导致无法启动 / 客户端加载失败 / 面板空白 / 皮肤缺失的问题。

### 关键修复

- **`defineTool` 的 `parameters` 格式错误 → 启动崩溃**：工具参数误写成标准 JSON Schema 包装格式 `{ type:'object', properties:{…}, required:[…] }`，而 harness 的 `defineTool`（`@deepseek-ai/dsh-tools`）要求**平铺的「参数名 → 值 schema」映射**；编译器把 `type` 当参数名、发现其值 `'object'` 不是 schema 对象，抛 `parameters.type must be a value schema object`，宿主 `exit before readiness`。已改为平铺格式，顶层 `required:['action']` 改为 `action` 参数上的 `required:true`（与官方 `dsh-tool-bash` 一致）。

- **客户端 bundle 未注册 → client-modules 加载失败**：`client.standalone.js` 是纯 ESM（`export function apply`），但 client-modules 用经典 `<script>` 加载 bundle，要求 bundle 自调用 `window.__ModuleLoader__.load({ id, factory })` 注册。已改：`id:"dsh-plugin-integration"`，`factory` 内 `require("react")` 取 React，末尾 `exports.apply = apply; return module.exports`。

- **`inject` 未声明跨上下文服务 → 面板空白**：`inject` 只有 `['webServer','tools']`，却用 `ctx.get('clientModules'/'loader'/'fs'/'settings')`。bundle 插件跑在子上下文，`ctx.get()` 拿不到祖先上下文提供的服务（必须先 `inject` 声明）→ `clientModules` 为 undefined → `resolveHome()` 返回 null → `analyze` 短路为「无法解析 profile 路径」。已把 `loader`/`fs`/`clientModules`/`settings` 加入 `inject`。

- **缺少皮肤条目发现 → 插件清单缺一批**：standalone 版 `analyze()` 只遍历 profile `bundles`，漏掉 `ui-skin-*` 皮肤（皮肤由皮肤中心管理，互斥开关写在 `~/.dsh/cordis.patch.yml` 的 managed 区段，非 profile bundle）。已补「读 home 补丁 → `readDisabledMap` → 收集 `ui-skin-*` → push 皮肤主题条目」，并合并 `loader.entries()` 以覆盖启用中的皮肤。

### 已知环境限制

- `refreshStars` 用 `ctx.get('web')` 但 DSH 无 `web` 服务（`web.fetch({url})` 为猜错的服务名），点「刷新 star」会提示「web 服务不可用」；不影响核心分析，需先确认 DSH 正确的 HTTP fetch 服务名再补。

---

## [1.3.0] —— 入库时间 / GitHub star / 待更新预判（对应 `pint-1/pkg-10`）

### 插件清单页

- **入库时间分类**：记录「首次识别时间戳」到状态文件，分类为**今日 / 三天内 / 一周内 / 一月内 / 更早**；修复原先「入库#N」（bundle 数组位置）误导性显示。
- **双向排序**：所有排序选项（入库时间/入库分类/star 数/名称/安装顺序）支持**升序/降序**切换。
- **GitHub star**：新增「刷新 star」按钮，联网抓取 star；仓库优先取 `config.plugins[entryId].repo`，否则从 package.json 的 `repository.url` 自动派生（`repoFromUrl`）。
- **待更新筛选**：新增「待更新」过滤（`config.plugins[entryId].latestVersion` 与安装版本比较）；点「预判更新」判断此次更新是否与已存在插件形成新的兼容冲突（涉及兼容规则/重叠组/受保护条目），先告知再由用户决定。

### 关键修复

- **GitHub 仓库派生参数错配**：`repoFromPkg` 原期望接收 package.json 对象、却传入了 `repository` 对象，导致派生恒为 null；已改名 `repoFromUrl` 并修正调用。
- **`hasClientDecl` 逻辑被写乱**：重构时误写为带副作用的一元表达式，已还原为「读取 package.json → 判断 dsh.client.platform」。
- **`detectFailures` 混入字面 `\n`**：已修正为正常换行。

### 已知环境限制

- **GitHub star 抓取依赖 web 抓取 provider**：`web.fetch` 需 DSH 部署注册可用的 web 抓取 provider；当前部署未注册，`refreshStars` 返回「no usable web provider is registered」，star 数无法实际联网获取（仓库派生逻辑本身正确）。配置了 web provider 的部署即可正常抓取。
- **入库时间为「首次识别时间」**：`fs` 服务不暴露文件 mtime，故以「本插件首次识别该插件的时间」近似入库时间，向前准确。
- **待更新依赖手动配置 `latestVersion`**：无法可靠获取 npm/GitHub 最新版本，需用户在 `~/.dsh/dsh-plugin-integration.json` 里为插件填 `latestVersion`。

---

## [1.2.0] —— star / 入库 / 搜索 / 失效检测（对应 `pint-1/pkg-7`，写盘修复于 pkg-8）

### 关键修复：写盘沙箱策略（pkg-8）

- **问题**：动态插件的 `fs.writeText` 在未显式传入 `sandboxPolicy` 时，用 `sandboxPolicy.resolve()`（**无 session 上下文**）回退到部署默认 `workspace-write` 模式，导致写 `~/.dsh/profiles/web/cordis.patch.yml` 与状态文件被拒（`file access denied under workspace-write mode`），**「启用/停用」与「失效判定持久化」整体失效**。
- **修复**：新增 `resolveWritePolicy()`，通过 `agents.currentInitiator()` 取当前会话，用 `sandboxPolicy.resolve({ session })` 解析真实沙箱模式（本会话为 `danger-full-access`），写入时显式传入该策略。
- **验证**：`toggle` 启停真实写盘并可逆恢复；`markFailed` 状态文件成功落盘 `~/.dsh/dsh-plugin-integration.state.json`。
- **说明**：写入路径依赖「有会话上下文」——经动态工具 `plugin_integration` 由模型调用时具备；浏览器设置页直接 `host.call` 是否携带会话上下文视运行环境而定，若被 `workspace-write` 拦截，属动态插件沙箱的固有边界。

### 插件清单页

- 新增 **star 数显示**（`config.plugins[entryId].stars`，默认 0，用户可在 `~/.dsh/dsh-plugin-integration.json` 填充）与**按 star 数排序**。
- 新增 **入库顺序 `installIndex`**（= 在 `dsh.profile.bundles` 中的位置），支持「入库时间（新→旧）」排序与「最近入库 5/10」筛选。
- 新增 **搜索栏**（按名称/条目/模块/包模糊检索）。
- 新增 **判定失效**：可手动把「已启用但疑似未生效」的插件标记为失效。

### 重叠切换页

- 新增**清晰生效界定**：完全生效 / 部分生效（客户端未生效）/ 已停用 / 失效。
- 新增**单方停用**：可单独停用某个正生效插件，不影响组内其它插件。
- 新增**判定失效**：可标记显示生效的插件为失效并纳入检测。

### 启用 / 停用页

- 新增**搜索栏**检索。

### 失效插件页（新增）

- 集中展示**手动判定为失效**的插件 + **可疑（未生效/失效）**插件。
- **失效检测** `detectFailures`：诊断每个插件具体失效原因（host-only / 缺客户端 bundle / 被停用 / fiber 失败 / 未进生效图 / 已生效但疑似部分失效），附**依据**与**修复方案 + 具体影响**，由使用者决定是否修复。
- 失效判定持久化到 `~/.dsh/dsh-plugin-integration.state.json`。

### 新增 RPC

- `markFailed(entryId)` / `unmarkFailed(entryId)` / `detectFailures(entryIds?)`。

### 数据字段新增

- 每个插件新增 `stars`、`installIndex`、`status`（active/inactive/disabled/failed）、`markedFailed`。

---

## [1.1.0] —— 动态发现 + 外部配置 + 保护名单（对应 `pint-1/pkg-6`）

### 新增

- **动态发现**：运行时读 `dsh.profile.bundles` 并解析每个 bundle 的 `cordis.patch.yml`，**新装插件自动出现**，彻底取代硬编码 `BUNDLES` 清单。
- **外部配置 + 通用回退**：
  - 默认配置抽到 `config.default.json`（同时内置于 `src/host.js` 的 `DEFAULT_CONFIG`）；
  - 支持 `~/.dsh/dsh-plugin-integration.json` 用户覆盖（`plugins` 按 key 合并，`overlaps`/`compatRules`/`protected` 整体替换）；
  - 未知插件从 `package.json` 派生名称/描述/关键词标签（`genericTags`），界面打「未知」标记。
- **核心保护名单**：`protected` 中的条目（默认 `ui-web-ui-compat`）禁止停用——UI 显示「受保护」+ 禁用按钮，RPC 层 `applyToggle` 同样拦截，杜绝「误停核心条目导致 DSH 进不去」。
- **汇总新增字段**：`protectedCount`、`unknownCount`。

### 重构

- `KB` → `DEFAULT_CONFIG.plugins`；`OVERLAPS` → `DEFAULT_CONFIG.overlaps`；`COMPAT_RULES` → `DEFAULT_CONFIG.compatRules`。
- `BUNDLES`（硬编码 bundle→条目映射）→ `discoverBundles()` / `resolveBundle()` 动态解析。
- 新增 `parseInsertRows`（解析 `- insert:` 块的 id/name）、`mergeConfig`、`genericTags`、`humanLabel`。

### 修复

- **聚合包多 `insert` 块丢条目**：`web-ui-all` 的补丁是「多个 `- insert:` 块（每块一个条目）」结构，旧 `parseInsertRows` 在遇到下一个 `- insert:` 时把上一个待定条目丢弃，导致 12 个子插件只剩 1 个。已在「新 `- insert:` 前先 push 待定条目」修复。
- **`pet` 条目 `bound` 笔误**：应为 `boundary`（虽因空值无害，但已纠正统一）。

---

## [1.0.0] —— 首个完整版（对应 `pint-1/pkg-3`）

### 新增

- 插件清单 / 重叠切换 / 兼容检测 / 启用停用 四个标签页。
- 存在性冲突（双重挂载）与共用性冲突（4 条规则）检测 + 修复预案。
- 动态工具 `plugin_integration`（`analyze` / `toggle` / `switch` / `applyFix`）。
- 自实现轻量 YAML patch 编辑器。

---

## 版本演进历史（动态插件内部包版本）

| 包 | 变更 | 备注 |
|----|------|------|
| pkg-1 | 初版（Host + Client） | 工具注册失败（缺 `output` 定义） |
| pkg-2 | 修复工具注册（仅 Host） | **引入纰漏**：漏提交 Client，设置页丢失 |
| pkg-3 | 恢复 Client + 补存在性检测 | 恢复 `hasClientHalf` |
| pkg-4 | 动态发现重构（仅 Host） | **重复纰漏**：再次漏提交 Client |
| pkg-5 | 动态发现重构（Host + Client） | 发现聚合包多 insert 块解析 bug（仅识别出 1/12 子插件） |
| pkg-6 | 修复聚合包解析 + pet 笔误 | **当前版本**，全量验证通过 |

---

## 修复/排查指引（维护者手册）

### 场景 1：工具注册失败

- 检查 `harness.defineTool` 是否含 `output: { schema, render }`，`output.render` 是否返回 `[{ type:'text', text }]`，`execute` 是否为函数。
- 参考 `@deepseek-ai/dsh-cordis-host-runner/lib/types/guard.js` 的 `sandboxDefineTool`。

### 场景 2：设置页「插件整合」不出现

- 检查当前包 `hasClientHalf` 是否为 `true`（**教训：cordis_define 时必须同时提交 host 与 client，缺一不可**）。
- 检查 `slots.inject('settings.section')` 是否注册。

### 场景 3：聚合包子插件识别不全

- 检查 `parseInsertRows`：bundle 补丁可能是「单个 `- insert:` 多条目」或「多个 `- insert:` 每块一个条目」两种结构，务必在「新 `- insert:`」前先 push 上一个待定条目。

### 场景 4：新插件不显示

- 确认其已加入 `dsh.profile.bundles`（`dsh plugin add` 会自动追加）；
- 确认其补丁可被解析（`dsh.bundle.patch` 声明 + `insert` 行）；
- 若显示为「未知」，说明未入知识库——编辑 `~/.dsh/dsh-plugin-integration.json` 补一条 `plugins` 记录即可。

### 场景 5：启停后未生效

- 组合补丁在 DSH 启动时读取，写入后**必须重启**；这是预期行为。

### 场景 6：两个插件同名工具冲突（启动即崩）

- **现象**：`Error: tool "X" is already registered (for a per-agent variant, register through that agent's agent.ctx instead)`，宿主 `exit before readiness`。
- **定位**：在 profile 的 `node_modules` 里 `grep -rln "name: 'X'"`（或 `"X"`）找出所有注册该工具名的插件，确认两者是否都被挂载（bundle 的 `cordis.patch.yml` 里的 `insert`，或 profile 补丁手动 `insert`）。
- **共存**（优先级从高到低）：
  1. **让一方只保留非工具能力**：若其提供「关闭工具注册」的 config（如 `dsh-vision-router` 的 `tool: false`），在 profile `cordis.patch.yml` 用 `- id: <entry>` + `config:` 覆盖，工具由另一方提供。
  2. **恢复延迟挂载**：若一方有 `progressive` / `progressiveTools`，改回默认的延迟挂载可避免启动期冲突（但运行时按需挂载仍会撞名，非彻底方案）。
  3. **二选一停用**：无 config 开关时只能 `- id: <entry>` + `disabled: true`。
- **典型案例（2026-08）**：`dsh-vision-router` × `dsh-window-kit` 内置的 `deepeye-vision`（`dsh-plugin-deepeye`）都注册 `vision_describe` / `vision_ocr`。共存做法：profile `cordis.patch.yml` 覆盖 `vision-router` 为 `config: { tool: false }`——视觉路由保留，视觉工具由 deepeye 提供。

---

## 已知缺陷（待后续迭代）

1. **`fiberPhase` 运行时阶段缺失**：`pluginInventory` 为 Remote-only，动态插件经 `typertGateway` 直连失败时「加载失败」检测不可用。
2. **独立 bundle 安装需适配**：`harness.handle` / `host.call` / `styles.insert` 为动态专属内建，独立安装需适配为 HTTP 路由 + `fetch` / Typert Remote（核心发现逻辑不变）。
3. **语义信息仍需人维护**：能力边界/重叠/兼容规则是「语义」，只能靠外部配置录入；未知插件只给启发式标签。
4. **存在性冲突检测范围有限**：当前仅「双重挂载」；同工具名冲突（`tool "X" is already registered`）、同 Slot 抢占需结合运行时 `Tool.listTools` 与 Slot 占用交叉比对扩展。同工具名冲突目前只能靠报错人工定位、尚无自动检测，已有共存案例见「维护者手册 · 场景 6」。
