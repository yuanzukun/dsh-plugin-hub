# dsh-pdf — DeepSeek Harness PDF 阅读插件（中文说明）

![License](https://img.shields.io/badge/license-MIT-green)

一个 **DeepSeek Harness (DSH) 插件**，让 AI 助手读取**任意大小（无 64KB 限制）**的 PDF 文件：
通过 pdfjs-dist 提取完整 Unicode 文本层（中文、英文及其它文字系统），并对**扫描件/图片页自动 OCR**，
手写笔记也能变成可读文本。

## ✨ 功能

- **`read_pdf` 工具**：按页返回 PDF 文本（`pages="1-3"`、`"2"`、`"1,3-5"`、`"all"`）。
- **无 64KB 上限**：单文件默认上限 200MB（`maxFileBytes` 可配）。
- **全 Unicode 文本层**：中文、英文开箱即用。
- **自动 OCR 兜底**（`mode: auto`）：文本层不足的页面自动渲染并识别：
  - **Windows WinRT OCR**（主引擎，零安装）：使用系统自带 `zh-Hans-CN` + `en-US` 识别器；
  - **tesseract.js**（可选）：把 `chi_sim.traineddata(.gz)` 和 `eng.traineddata(.gz)` 放入 `<cacheDir>/tessdata/` 即启用。
- **模式控制**：`mode=text` 只读文本层（快）；`mode=ocr` 强制逐页 OCR；`ocrEngine=windows|tesseract` 指定引擎。
- **MIT 开源**：可自由使用、修改、再分发。

## 🚀 安装

```bash
# 1. 克隆
git clone https://github.com/henryxiao709/dsh-pdf.git
cd dsh-pdf

# 2. 安装公开依赖（pdfjs-dist、@napi-rs/canvas、tesseract.js）
npm install --ignore-scripts

# 3. 从你的 DSH 安装中链接 @deepseek-ai 依赖
node scripts/link-deps.mjs          # 自动探测 DSH_CHECKOUT / DSH_DATA / 常见路径
# 或：node scripts/link-deps.mjs "<dsh-data>/profiles/node_modules/@deepseek-ai"

# 4. 注入正在运行的 DSH（需已安装 dsh-super-injector）
#    对 DSH 的 AI 说：dev_install_package <本插件绝对路径>
#    或把插件加入 profile 的 dsh.profile.bundles，重启后自动装配
```

## 🧰 使用

```
read_pdf file_path=... [pages="1-3"] [mode=auto|text|ocr] [ocrEngine=auto|windows|tesseract] [maxCharsPerPage=20000]
```

每页结果带 `source` 字段：`text`（仅文本层）、`ocr`（仅 OCR）、`mixed`（两者合并）。

## ⚙️ 配置

插件注册了 **`dsh-pdf` 设置分区**（宿主 namespace + 设置界面卡片）：所有参数都可以在
DSH 设置界面（设置 → 插件 → dsh-pdf）里实时调整，改动立即生效并自动清除结果缓存。
`cordis.patch.yml` 中的值作为装配基准：

| 键 | 默认 | 说明 |
|---|---|---|
| `maxFileBytes` | 209715200 | 单次读取字节上限 |
| `readLimitPages` | 50 | 单次调用最多处理页数 |
| `ocrMinChars` | 120 | auto 模式下低于此字符数的页触发 OCR |
| `ocrScale` | 2 | 渲染缩放（2 ≈ 144 DPI） |
| `ocrEngine` | auto | auto / windows / tesseract |
| `ocrTimeoutMs` | 60000 | 单页 OCR 超时 |
| `maxCharsPerPage` | 20000 | 每页返回字符上限 |
| `cacheEntries` | 4 | 结果缓存条目数 |
| `cacheDir` | `%TEMP%/dsh-pdf` | OCR 脚本与临时图片目录 |

> **设置界面**：插件注册了 `dsh-pdf` 设置分区——以上所有参数都可以在 DSH
> 设置界面（设置 → 插件 → dsh-pdf）里实时调整，改动立即生效并自动清除
> 结果缓存。`cordis.patch.yml` 中的值作为装配基准。

## 📄 许可证

[MIT](LICENSE) © 2026 henryxiao709
