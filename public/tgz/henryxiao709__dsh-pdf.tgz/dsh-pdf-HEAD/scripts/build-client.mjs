#!/usr/bin/env node
// build-client.mjs — bundle src/client.jsx into lib/client.js in the format
// the DSH client module loader expects:
//
//   window.__ModuleLoader__.load({ id: "<package>", factory: (require) => {
//     ...cjs bundle...
//     return module.exports;
//   }});
//
// React and the @deepseek-ai client packages stay external — they are provided
// by the client runtime's module registry at load time.
import { build } from 'esbuild';
import { readFileSync, writeFileSync, rmSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const OUT = resolve(ROOT, 'lib', 'client.bundle.js');
const ID = '@dsh-external/dsh-pdf';

await build({
  entryPoints: [resolve(ROOT, 'src', 'client.jsx')],
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  jsx: 'automatic',
  outfile: OUT,
  logLevel: 'warning',
  external: [
    'react',
    'react/jsx-runtime',
    '@deepseek-ai/dsh-client-runtime/client',
    '@deepseek-ai/dsh-client-ui-slots',
    '@deepseek-ai/dsh-client-ui-primitives',
  ],
});

const bundle = readFileSync(OUT, 'utf8');
const wrapped = `window.__ModuleLoader__.load({ id: ${JSON.stringify(ID)}, factory: (require) => {\nvar module = { exports: {} };\nvar exports = module.exports;\n${bundle}\nreturn module.exports;\n} });\n`;
writeFileSync(resolve(ROOT, 'lib', 'client.js'), wrapped);
rmSync(OUT, { force: true });
console.log('built lib/client.js (' + wrapped.length + ' bytes)');
