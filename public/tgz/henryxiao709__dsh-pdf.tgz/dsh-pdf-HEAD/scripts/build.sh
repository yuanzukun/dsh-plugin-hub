#!/bin/bash
# dsh-pdf is a plain-ESM-JavaScript plugin (no TypeScript compile step).
# This script validates the package layout so the plugin production line
# (dev_build_plugin) can run uniformly for every plugin.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [ ! -f lib/index.js ]; then
  echo "build: lib/index.js missing" >&2
  exit 1
fi
if [ ! -f package.json ]; then
  echo "build: package.json missing" >&2
  exit 1
fi
echo "=== dsh-pdf: plain-js layout OK (no compile step) ==="
