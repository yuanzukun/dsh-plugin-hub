// dsh-pdf client card — renders the plugin's settings section inside the DSH
// settings UI (设置 → 插件 → dsh-pdf). Mirrors the official
// ui-settings-plugins card pattern: register a `settings.plugin.item` slot
// entry bound to the `dsh-pdf` settings namespace, with a staged form whose
// save writes through the settings scope.
import { jsx, jsxs } from 'react/jsx-runtime';
import { useSyncExternalStore, useState } from 'react';

export const name = '@dsh-external/dsh-pdf';
export const inject = ['slots', 'locale', 'settingsScope'];

const NS = 'dsh-pdf';
const SOURCE = 'dsh-pdf';

const FIELDS = [
  { key: 'ocrEngine', label: 'OCR 引擎 / OCR engine', kind: 'select', options: ['auto', 'windows', 'tesseract'] },
  { key: 'ocrScale', label: 'OCR 精度 / OCR scale', kind: 'number', hint: '渲染缩放，2 ≈ 144 DPI（越大越清晰越慢）' },
  { key: 'ocrMinChars', label: 'OCR 触发阈值 / OCR min chars', kind: 'number', hint: '文本层低于此字符数的页自动 OCR' },
  { key: 'ocrTimeoutMs', label: 'OCR 超时 / OCR timeout ms', kind: 'number' },
  { key: 'maxCharsPerPage', label: '每页字符上限 / Max chars per page', kind: 'number' },
  { key: 'maxFileBytes', label: '文件大小上限 / Max file bytes', kind: 'number' },
  { key: 'readLimitPages', label: '每调用页数上限 / Max pages per call', kind: 'number' },
  { key: 'cacheEntries', label: '结果缓存条目 / Cache entries', kind: 'number' },
  { key: 'cacheDir', label: '临时目录 / Cache dir', kind: 'text' },
];

const STYLE = `
.dshpdf-card{max-width:640px;color:var(--dsw-alias-label-primary);flex-direction:column;gap:6px;display:flex}
.dshpdf-card h4{margin:0;font-size:14px;font-weight:600}
.dshpdf-desc{color:var(--dsw-alias-label-tertiary);margin:0 0 6px;font-size:12px}
.dshpdf-field{flex-direction:column;gap:4px;padding:8px 0;display:flex}
.dshpdf-field+.dshpdf-field{border-top:1px solid var(--dsw-alias-border-l2)}
.dshpdf-head{align-items:center;gap:8px;display:flex}
.dshpdf-label{min-width:0;flex:1;font-size:13px;font-weight:500;line-height:1.5}
.dshpdf-badge{white-space:nowrap;color:var(--dsw-alias-label-tertiary);border-radius:999px;padding:1px 8px;font-size:11px;line-height:17px}
.dshpdf-input{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);height:32px;font:inherit;color:var(--dsw-alias-label-primary);border-radius:8px;padding:0 10px;font-size:13px;line-height:1.5;max-width:240px}
.dshpdf-input:focus-visible{border-color:var(--dsw-alias-brand-primary);outline:none}
.dshpdf-input:disabled{color:var(--dsw-alias-label-tertiary)}
.dshpdf-hint{color:var(--dsw-alias-label-tertiary);margin:0;font-size:12px;line-height:1.5}
.dshpdf-actions{display:flex;gap:8px;margin-top:10px;align-items:center}
.dshpdf-save{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);border-radius:8px;padding:6px 14px;font:inherit;font-size:13px;cursor:pointer}
.dshpdf-save:hover:not(:disabled){border-color:var(--dsw-alias-brand-primary)}
.dshpdf-save:disabled{color:var(--dsw-alias-label-tertiary);cursor:default}
.dshpdf-status{color:var(--dsw-alias-label-tertiary);font-size:12px}
.dshpdf-status[data-ok=true]{color:var(--dsw-alias-label-success, #4ade80)}
.dshpdf-status[data-err=true]{color:var(--dsw-alias-label-error, #f87171)}
`;

function ensureStyle() {
  if (typeof document === 'undefined') return;
  if (document.querySelector('style[data-plugin-css="dsh-pdf"]')) return;
  const tag = document.createElement('style');
  tag.dataset.plugin = 'dsh-pdf';
  tag.dataset.pluginCss = 'dsh-pdf';
  tag.textContent = STYLE;
  document.head.appendChild(tag);
}

/** Tiny snapshot store over a settings scope (no external deps). */
function createCardStore(scope) {
  const listeners = new Set();
  let snapshot = makeSnapshot(scope);
  const refresh = () => {
    snapshot = makeSnapshot(scope);
    for (const l of [...listeners]) l();
  };
  scope.subscribe(refresh);
  return {
    getSnapshot: () => snapshot,
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
  };
}

function makeSnapshot(scope) {
  const raw = scope.getSnapshot();
  const value = raw?.value ?? {};
  const base = raw?.base ?? {};
  const writable = raw?.writable !== false;
  const overridden = Object.fromEntries(FIELDS.map((f) => [f.key, !(f.key in base) || String(value[f.key]) !== String(base[f.key])]));
  return { value, base, writable, overridden };
}

function DshPdfCard(props) {
  ensureStyle();
  const { t } = props;
  const state = props.useDshPdfCard((s) => s);
  const [drafts, setDrafts] = useState(undefined);
  const [status, setStatus] = useState(undefined);
  const disabled = !state.writable;

  const edit = (key, text) => setDrafts((d) => ({ ...d, [key]: text }));
  const resetField = (key) => setDrafts((d) => ({ ...d, [key]: String(state.base[key] ?? '') }));
  const save = async () => {
    try {
      for (const f of FIELDS) {
        const raw = drafts[f.key];
        if (raw === undefined) continue;
        if (f.kind === 'number') {
          const n = Number(raw);
          if (!Number.isFinite(n)) { setStatus({ err: `${f.key}: 不是有效数字` }); return; }
          await props.scope.set(f.key, n);
        } else {
          await props.scope.set(f.key, raw);
        }
      }
      setStatus({ ok: t('saved') });
    } catch (e) {
      setStatus({ err: String(e?.message ?? e) });
    }
  };

  return jsxs('div', { className: 'dshpdf-card', children: [
    jsxs('h4', { children: [t('title')] }),
    jsx('p', { className: 'dshpdf-desc', children: t('description') }),
    ...FIELDS.map((f) => {
      const current = drafts[f.key] !== undefined ? drafts[f.key] : String(state.value[f.key] ?? '');
      return jsxs('div', { className: 'dshpdf-field', key: f.key, children: [
        jsxs('div', { className: 'dshpdf-head', children: [
          jsx('span', { className: 'dshpdf-label', children: f.label }),
          state.overridden[f.key] && jsx('span', { className: 'dshpdf-badge', children: t('overridden') }),
        ] }),
        f.kind === 'select'
          ? jsx('select', {
              className: 'dshpdf-input', disabled, value: current,
              onChange: (e) => edit(f.key, e.target.value),
              children: f.options.map((o) => jsx('option', { value: o, children: o }, o)),
            })
          : jsx('input', {
              className: 'dshpdf-input', disabled, value: current,
              type: f.kind === 'number' ? 'number' : 'text',
              onChange: (e) => edit(f.key, e.target.value),
            }),
        f.hint && jsx('p', { className: 'dshpdf-hint', children: f.hint }),
      ] });
    }),
    jsxs('div', { className: 'dshpdf-actions', children: [
      jsx('button', { className: 'dshpdf-save', disabled, onClick: save, children: t('save') }),
      status.ok && jsx('span', { className: 'dshpdf-status', 'data-ok': 'true', children: status.ok }),
      status.err && jsx('span', { className: 'dshpdf-status', 'data-err': 'true', children: status.err }),
    ] }),
  ] });
}

function DshPdfCardController(scope) {
  this.scope = scope;
  this.store = createCardStore(scope);
}
DshPdfCardController.prototype.inject = function inject() {
  return {
    hooks: { dshPdfCard: this.store },
    scope: this.scope,
  };
};

export function apply(ctx) {
  ensureStyle();
  const t = ctx.locale.bind(NS);
  ctx.effect(() => ctx.locale.register(NS, {
    zh: {
      title: 'dsh-pdf 设置',
      description: 'PDF 读取插件（中英文 + 扫描件 OCR）。修改立即生效。',
      overridden: '已覆盖',
      save: '保存',
      saved: '已保存 ✓',
    },
    en: {
      title: 'dsh-pdf settings',
      description: 'PDF reader plugin (Chinese/English + scanned-page OCR). Changes apply immediately.',
      overridden: 'overridden',
      save: 'Save',
      saved: 'Saved ✓',
    },
  }), 'dsh-pdf: card dictionaries');
  const controller = new DshPdfCardController(ctx.settingsScope.bind({ namespace: NS }));
  ctx.slots.inject('settings.plugin.item', function* () {
    yield ctx.slots.register({
      name: 'settings.plugin.item',
      id: 'dsh-pdf',
      order: 30,
      locale: NS,
      inject: () => controller.inject(),
    }, DshPdfCard);
  });
}
