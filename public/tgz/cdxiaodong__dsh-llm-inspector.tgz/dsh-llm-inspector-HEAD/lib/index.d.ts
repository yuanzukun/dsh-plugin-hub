/**
 * dsh-llm-inspector — 统一 LLM 请求/响应检查器
 *
 * 一个插件收编四类能力(按 config 开关):
 *   1. reasoning 控制   —— 挂 agent/request,改写 LlmCallConfig.reasoningEffort(调 budget / 关推理)
 *   2. external thinking —— 对加密推理的模型(OpenAI/Anthropic):关原生推理 + 注册 think 工具
 *                          + 注入 system prompt 强制先调 think,再从 llm/stream 抓回推理草稿
 *   3. 流量/包分析      —— 挂 llm/stream 拦截每个 chunk,统计 token / 抓取 reasoning 与 tool-call 块
 *   4. 会话落盘审计     —— 订阅 session/event,把命中的块写入日志目录
 *
 * 实现遵循 dsh-plugin-dev 实测规范:Service 基类提供能力、ctx.effect 管资源、
 * waterfall 钩子在卸载时由 cordis 自动回收。
 */
import { Context, Service } from 'cordis';
export declare const name = "dsh-llm-inspector";
/**
 * 可选宿主服务不用 inject 声明:cordis 仅允许访问已 inject 的服务,未声明直访会抛
 * "cannot get property without inject"。可选服务一律改用 ctx.get('name') 安全探测
 * (不存在返回 undefined 而非抛错),从而兼容未挂载 tools/systemPrompt 的宿主。
 */
export interface InspectorConfig {
    /** 目标 reasoning effort:'none' 关闭原生推理,或 adapter 支持的档位('low'/'medium'/'high')。 */
    reasoningEffort?: string;
    /** 是否启用外部思考导出(注册 think 工具 + 注入强制提示)。 */
    externalThinking?: boolean;
    /** 是否做流量/包分析(llm/stream 拦截统计)。 */
    trafficAnalysis?: boolean;
    /** 是否把命中块落盘审计。 */
    persistSession?: boolean;
    /** 落盘目录(相对 cwd)。 */
    logDir?: string;
    /** 强制提示词(可通过配置覆盖)。 */
    thinkPrompt?: string;
}
/** 判断一个 provider/model 是否属于"加密推理、需 think 骗法"的族。 */
export declare function isEncryptedReasoningProvider(provider: string): boolean;
export declare const DEFAULT_THINK_PROMPT: string;
export declare const THINK_TOOL_SCHEMA: {
    readonly type: "object";
    readonly properties: {
        readonly thoughts: {
            readonly type: "string";
            readonly description: "private scratchpad; not shown to user";
        };
    };
    readonly required: readonly ["thoughts"];
    readonly additionalProperties: false;
};
export interface TrafficStats {
    calls: number;
    chunks: number;
    reasoningChars: number;
    thinkCalls: number;
    thinkChars: number;
    byKind: Record<string, number>;
}
export declare class TrafficService extends Service {
    private config;
    stats: TrafficStats;
    constructor(ctx: Context, config: InspectorConfig);
    recordChunk(kind: string, text?: string): void;
    recordThink(text: string): void;
    recordCall(): void;
    snapshot(): TrafficStats;
}
export declare class AuditService extends Service {
    private config;
    private buffer;
    private timer;
    constructor(ctx: Context, config: InspectorConfig);
    log(tag: string, payload: unknown): void;
    flush(): Promise<void>;
}
export declare function apply(ctx: Context, config?: InspectorConfig): void;
declare const _default: {
    name: string;
    apply: typeof apply;
};
export default _default;
