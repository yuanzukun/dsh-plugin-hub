/**
 * dsh-llm-inspector — 统一 LLM 请求/响应检查器
 *
 * 一个插件收编四类能力(按 config 开关):
 *   1. reasoning 控制   —— 挂 agent/request,改写 LlmCallConfig.reasoningEffort(调 budget / 关推理)
 *   2. external thinking —— 对加密推理的模型(OpenAI/Anthropic):关原生推理 + 注册 think 工具
 *                          + 注入 system prompt 强制先调 think,再从 llm/stream 抓回推理草稿
 *   3. 流量/包分析      —— 挂 llm/stream 拦截每个 chunk,统计 token / 抓取 reasoning 与 tool-call 块
 *   4. 会话落盘审计     —— 订阅 session/event,把命中的块写入日志目录
 *
 * 实现遵循 dsh-plugin-dev 实测规范:Service 基类提供能力、ctx.effect 管资源、
 * waterfall 钩子在卸载时由 cordis 自动回收。
 */
import { Context, Service } from 'cordis'

export const name = 'dsh-llm-inspector'

/**
 * 可选宿主服务不用 inject 声明:cordis 仅允许访问已 inject 的服务,未声明直访会抛
 * "cannot get property without inject"。可选服务一律改用 ctx.get('name') 安全探测
 * (不存在返回 undefined 而非抛错),从而兼容未挂载 tools/systemPrompt 的宿主。
 */

export interface InspectorConfig {
  /** 目标 reasoning effort:'none' 关闭原生推理,或 adapter 支持的档位('low'/'medium'/'high')。 */
  reasoningEffort?: string
  /** 是否启用外部思考导出(注册 think 工具 + 注入强制提示)。 */
  externalThinking?: boolean
  /** 是否做流量/包分析(llm/stream 拦截统计)。 */
  trafficAnalysis?: boolean
  /** 是否把命中块落盘审计。 */
  persistSession?: boolean
  /** 落盘目录(相对 cwd)。 */
  logDir?: string
  /** 强制提示词(可通过配置覆盖)。 */
  thinkPrompt?: string
}

/** 判断一个 provider/model 是否属于"加密推理、需 think 骗法"的族。 */
export function isEncryptedReasoningProvider(provider: string): boolean {
  const p = provider.toLowerCase()
  return (
    p.includes('openai') ||
    p.includes('azure') ||
    p.includes('codex') ||
    p.includes('anthropic') ||
    p.includes('claude') ||
    p.includes('gemini') ||
    p.includes('google')
  )
}

export const DEFAULT_THINK_PROMPT = [
  '你可以使用一个名为 think 的工具作为你的私有草稿纸。',
  '在给出最终答案、修改代码或调用任何其他工具之前,必须先调用 think,',
  '把你的完整推理过程逐步写进 think 的 thoughts 参数。',
  'think 的内容不会展示给用户,请使用简洁的速记风格,无需润色。',
].join('')

export const THINK_TOOL_SCHEMA = {
  type: 'object',
  properties: {
    thoughts: {
      type: 'string',
      description: 'private scratchpad; not shown to user',
    },
  },
  required: ['thoughts'],
  additionalProperties: false,
} as const

// ---------------------------------------------------------------------------
// 流量/包分析 Service
// ---------------------------------------------------------------------------
export interface TrafficStats {
  calls: number
  chunks: number
  reasoningChars: number
  thinkCalls: number
  thinkChars: number
  byKind: Record<string, number>
}

export class TrafficService extends Service {
  stats: TrafficStats = { calls: 0, chunks: 0, reasoningChars: 0, thinkCalls: 0, thinkChars: 0, byKind: {} }

  constructor(ctx: Context, private config: InspectorConfig) {
    super(ctx as any, 'inspectorTraffic' as any)
  }

  recordChunk(kind: string, text = ''): void {
    this.stats.chunks++
    this.stats.byKind[kind] = (this.stats.byKind[kind] ?? 0) + 1
    if (kind === 'reasoning') this.stats.reasoningChars += text.length
  }

  recordThink(text: string): void {
    this.stats.thinkCalls++
    this.stats.thinkChars += text.length
  }

  recordCall(): void {
    this.stats.calls++
  }

  snapshot(): TrafficStats {
    return JSON.parse(JSON.stringify(this.stats))
  }
}

// ---------------------------------------------------------------------------
// 会话落盘 Service(懒写,资源用 ctx.effect 释放)
// ---------------------------------------------------------------------------
export class AuditService extends Service {
  private buffer: string[] = []
  private timer: ReturnType<typeof setInterval> | null = null

  constructor(ctx: Context, private config: InspectorConfig) {
    super(ctx as any, 'inspectorAudit' as any)
    ctx.effect(() => {
      if (!config.persistSession) return () => {}
      this.timer = setInterval(() => void this.flush(), 5000)
      // unref:不让审计定时器阻止宿主/测试进程退出
      this.timer.unref?.()
      return () => {
        if (this.timer) clearInterval(this.timer)
        void this.flush()
      }
    })
  }

  log(tag: string, payload: unknown): void {
    if (!this.config.persistSession) return
    this.buffer.push(JSON.stringify({ t: Date.now(), tag, payload }))
  }

  async flush(): Promise<void> {
    if (!this.buffer.length || !this.config.persistSession) return
    const lines = this.buffer.splice(0).join('\n') + '\n'
    try {
      const { appendFile, mkdir } = await import('node:fs/promises')
      const { join } = await import('node:path')
      const dir = this.config.logDir ?? '.dsh-inspector'
      await mkdir(dir, { recursive: true })
      await appendFile(join(dir, 'audit.jsonl'), lines, 'utf8')
    } catch {
      /* 落盘失败不阻断主流程 */
    }
  }
}

// ---------------------------------------------------------------------------
// 插件入口
// ---------------------------------------------------------------------------
export function apply(ctx: Context, config: InspectorConfig = {}): void {
  const cfg: InspectorConfig = {
    externalThinking: true,
    trafficAnalysis: true,
    persistSession: false,
    thinkPrompt: DEFAULT_THINK_PROMPT,
    ...config,
  }

  const traffic = new TrafficService(ctx, cfg)
  const audit = new AuditService(ctx, cfg)

  // -- ② 外部思考:注册 think 工具(schema 自动流入 LLM 请求体)------------
  const tools = ctx.get('tools' as any) as any
  if (cfg.externalThinking && tools?.register) {
    try {
      tools.register({
        name: 'think',
        description: 'private scratchpad; not shown to user',
        parameters: THINK_TOOL_SCHEMA,
        // 执行体仅为占位:真正价值在 thoughts 入参,经 llm/stream 被本插件抓回。
        execute: async () => ({ content: [{ type: 'text', text: '------' }] }),
      })
    } catch (e) {
      ctx.logger('dsh-llm-inspector').warn('注册 think 工具失败: %s', (e as Error).message)
    }
  }

  // -- ② 外部思考:往系统提示注入"先调 think"的强制指令 --------------------
  const systemPrompt = ctx.get('systemPrompt' as any) as any
  if (cfg.externalThinking && systemPrompt?.section) {
    try {
      systemPrompt.section('dsh-llm-inspector.think', () => cfg.thinkPrompt)
    } catch (e) {
      ctx.logger('dsh-llm-inspector').warn('注入 systemPrompt 失败: %s', (e as Error).message)
    }
  }

  // -- ① reasoning 控制:改写出站请求 --------------------------------------
  // cordis waterfall 语义:监听器签名为 (…args, next),调用 next(config) 把改写后的值传给下一级。
  if (cfg.reasoningEffort !== undefined) {
    ctx.on(
      'agent/request' as any,
      (callConfig: any, next: (v?: any) => any) => {
        if (callConfig && typeof callConfig === 'object') {
          callConfig.reasoningEffort = cfg.reasoningEffort
          audit.log('request.rewrite', { reasoningEffort: cfg.reasoningEffort })
        }
        return typeof next === 'function' ? next(callConfig) : callConfig
      },
      true,
    )
  }

  // -- ③ 流量/包分析 + think 抓回:拦截流式 chunk --------------------------
  if (cfg.trafficAnalysis || cfg.externalThinking) {
    ctx.on(
      'llm/stream' as any,
      (chunk: any, next: (v?: any) => any) => {
        if (chunk && typeof chunk === 'object') {
          traffic.recordCall()
          const kind = chunk.kind ?? chunk.type ?? 'unknown'
          traffic.recordChunk(kind, chunk.text ?? '')

          // think 工具调用块:抓回 thoughts 参数
          if (kind === 'tool-call' || kind === 'tool_call') {
            const tname = chunk.name ?? chunk.toolName ?? chunk.tool?.name
            if (tname === 'think') {
              const thoughts =
                chunk.args?.thoughts ?? chunk.input?.thoughts ?? chunk.arguments?.thoughts ?? ''
              if (typeof thoughts === 'string' && thoughts) {
                traffic.recordThink(thoughts)
                audit.log('think.capture', { thoughts })
              }
            }
          }
          if (kind === 'reasoning') audit.log('reasoning.chunk', { text: chunk.text ?? '' })
        }
        return typeof next === 'function' ? next(chunk) : chunk
      },
      true,
    )
  }

  // -- ④ 会话落盘:订阅持久化事件 ------------------------------------------
  if (cfg.persistSession) {
    ctx.on('session/event' as any, (event: any) => {
      const t = event?.type ?? event?.kind ?? ''
      if (t === 'assistant/message' || t === 'assistant/chunk') audit.log(t, event)
    })
  }

  ctx.logger('dsh-llm-inspector').info(
    '已启用 externalThinking=%s traffic=%s persist=%s effort=%s',
    cfg.externalThinking,
    cfg.trafficAnalysis,
    cfg.persistSession,
    cfg.reasoningEffort ?? '(不改)',
  )
}

export default { name, apply }
