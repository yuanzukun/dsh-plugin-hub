import { test } from 'node:test'
import assert from 'node:assert/strict'
import { Context } from 'cordis'
import * as plugin from '../lib/index.js'

const { apply, isEncryptedReasoningProvider, DEFAULT_THINK_PROMPT } = plugin

async function makeCtx(config) {
  const root = new Context()
  root.plugin({ name: 'dsh-llm-inspector', apply: (ctx) => apply(ctx, config) })
  await new Promise((r) => setTimeout(r, 200)) // 等插件就绪
  return root
}

// cordis 插件通过 root.scope 释放;测试结束统一 dispose,避免定时器/句柄挂住进程
async function teardown(root) {
  try { await root.dispose?.() } catch {}
}

test('纯函数:加密推理 provider 判定', () => {
  assert.ok(isEncryptedReasoningProvider('openai-responses'))
  assert.ok(isEncryptedReasoningProvider('azure-openai'))
  assert.ok(isEncryptedReasoningProvider('anthropic-messages'))
  assert.ok(isEncryptedReasoningProvider('google-gemini-cli'))
  assert.ok(!isEncryptedReasoningProvider('deepseek'))
  assert.ok(!isEncryptedReasoningProvider('ollama'))
})

test('reasoning 控制:agent/request 改写 reasoningEffort', async () => {
  const root = await makeCtx({ reasoningEffort: 'none', externalThinking: false, trafficAnalysis: false })
  // 模拟宿主 waterfall:末参是宿主终止函数(返回最终 config)
  const cfg = { provider: 'openai-responses', model: 'gpt-x', reasoningEffort: 'high' }
  const out = root.waterfall('agent/request', cfg, (v) => v)
  assert.equal(out.reasoningEffort, 'none')
  assert.equal(out.model, 'gpt-x') // 其余字段不动
})

test('不改 reasoning 时 config 原样穿过', async () => {
  const root = await makeCtx({ externalThinking: false, trafficAnalysis: false })
  const cfg = { reasoningEffort: 'medium' }
  const out = root.waterfall('agent/request', cfg, (v) => v)
  assert.equal(out.reasoningEffort, 'medium')
})

test('流量分析:llm/stream 统计 reasoning 与 think 块', async () => {
  const root = await makeCtx({ externalThinking: true, trafficAnalysis: true })
  root.waterfall('llm/stream', { kind: 'reasoning', text: '先分析问题…' }, (v) => v)
  root.waterfall('llm/stream', { kind: 'tool-call', name: 'think', args: { thoughts: '速记推理草稿' } }, (v) => v)
  root.waterfall('llm/stream', { kind: 'text', text: '最终答案' }, (v) => v)
  const svc = root.get('inspectorTraffic')
  assert.ok(svc, 'inspectorTraffic 服务应已注册')
  const s = svc.snapshot()
  assert.equal(s.chunks, 3)
  assert.equal(s.byKind.reasoning, 1)
  assert.equal(s.thinkCalls, 1)
  assert.ok(s.thinkChars > 0)
})

test('think 抓回:仅捕获名为 think 的工具调用', async () => {
  const root = await makeCtx({ externalThinking: true, trafficAnalysis: true })
  root.waterfall('llm/stream', { kind: 'tool-call', name: 'read', args: { path: '/x' } }, (v) => v)
  const s = root.get('inspectorTraffic').snapshot()
  assert.equal(s.thinkCalls, 0) // 其他工具不计入
})

test('落盘审计:命中块写入 audit.jsonl', async () => {
  const dir = new URL('./tmp-audit/', import.meta.url).pathname
  const root = await makeCtx({ externalThinking: true, trafficAnalysis: true, persistSession: true, logDir: dir })
  root.waterfall('llm/stream', { kind: 'tool-call', name: 'think', args: { thoughts: 'abc' } }, (v) => v)
  await root.get('inspectorAudit').flush()
  const { readFile } = await import('node:fs/promises')
  const content = await readFile(dir + 'audit.jsonl', 'utf8')
  assert.ok(content.includes('think.capture'))
  assert.ok(content.includes('abc'))
})

test('默认提示词含强制先调 think 指令', () => {
  assert.ok(DEFAULT_THINK_PROMPT.includes('think'))
  assert.ok(DEFAULT_THINK_PROMPT.includes('必须先调用'))
})
