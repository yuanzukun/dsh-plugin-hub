# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![Cartão de configurações](assets/settings-card.png)
Faça o seletor de diretório do espaço de trabalho do dsh ("Adicionar espaço de trabalho → Selecionar diretório do espaço de trabalho") abrir em um diretório **de sua escolha** — por exemplo `E:\python_project` — em vez do diretório pessoal do Windows.

## Instalação

Escolha uma das três formas abaixo e reinicie o `dsh web`:

```powershell
# 1) Pacote npm (quando publicado no npm)
dsh plugin --profile web add dsh-workspace-default-dir

# 2) Repositório GitHub (inclui lib/ pré-compilado, sem build local)
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) Diretório local (desenvolvimento / auto-hospedado)
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

Após reiniciar, uma entrada **Diretório padrão do espaço de trabalho** aparece em **Configurações**.

## Uso

Abra **Configurações → Diretório padrão do espaço de trabalho** (`设置 → 工作区默认目录`). Digite um caminho absoluto — por exemplo `E:\python_project` — e clique em **Salvar** (`保存`). O seletor de diretório "Adicionar espaço de trabalho" abrirá diretamente nessa pasta — sem reiniciar.

![Seletor de diretório aberto em E:\ComfyUI-aki-v3](assets/picker-dialog.png)

O cartão mostra sempre o diretório ativo (`当前生效`). Deixe o campo vazio e salve, ou clique em **Limpar** (`清除`), para voltar ao padrão (o diretório pessoal).

A mesma configuração está disponível na linha de comando:
```bash
dsh-workspace-default-dir set E:\python_project   # define o diretório padrão
dsh-workspace-default-dir get                     # mostra o padrão atual
dsh-workspace-default-dir clear                   # limpa (volta para home)
dsh-workspace-default-dir status                  # estado do patch e da config
```

O cartão da GUI e a CLI gravam a mesma variável `DSH_PICKER_INITIAL_DIR` (persistida com `setx`), portanto permanecem sincronizados.

## Comportamento e limitações

- **Cobre ambos os backends de seletor**: o diálogo nativo do Windows (via `IFileDialog::SetFolder`) e o seletor browse (usado quando o servidor web faz bind em um host não-loopback, ex. LAN `0.0.0.0`).
- **Fallback de registro**: os seletores corrigidos leem primeiro a variável de ambiente `DSH_PICKER_INITIAL_DIR` e depois diretamente `HKCU\Environment` — contornando o problema de ambiente obsoleto do Explorer (sem precisar reiniciá-lo após `setx`).
- **Autocura**: a cada inicialização do dsh, o plugin reaplica de forma idempotente os dois patches de backend, então uma atualização do dsh que restaure os arquivos originais é reparada automaticamente.
- É um plugin de **tipo patch**: modifica os dois arquivos do pacote de seletor dentro da instalação do dsh (idempotente, apenas aditivo). O backend browse carrega seu módulo corrigido na inicialização do dsh, então é preciso reiniciar o `dsh web` após instalar/atualizar; o diálogo nativo lê seu worker a cada abertura.
- Verificado em Windows + dsh 0.1.0-rc.6. Em outras plataformas/versões, se os pares de edição não coincidirem, um aviso é registrado e o patch é ignorado (o dsh ainda inicia).

## Licença

MIT — veja [LICENSE](LICENSE).