# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![Einstellungskarte](assets/settings-card.png)
Lassen Sie den Arbeitsbereichs-Verzeichnisauswahldialog von dsh („Arbeitsbereich hinzufügen → Arbeitsbereichsverzeichnis auswählen“) in einem **von Ihnen gewählten** Verzeichnis öffnen — z. B. `E:\python_project` — statt im Windows-Benutzerverzeichnis.

## Installation

Wählen Sie eine der drei folgenden Methoden und starten Sie dann `dsh web` neu:

```powershell
# 1) npm-Paket (sobald auf npm veröffentlicht)
dsh plugin --profile web add dsh-workspace-default-dir

# 2) GitHub-Repository (enthält vorgebautes lib/, kein lokaler Build nötig)
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) Lokales Verzeichnis (Entwicklung / Selbsthosting)
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

Nach dem Neustart erscheint unter **Einstellungen** der Eintrag **Standard-Arbeitsbereichsverzeichnis**.

## Verwendung

Öffnen Sie **Einstellungen → Standard-Arbeitsbereichsverzeichnis** (`设置 → 工作区默认目录`). Geben Sie einen absoluten Pfad ein — z. B. `E:\python_project` — und klicken Sie auf **Speichern** (`保存`). Der Verzeichnisauswahldialog „Arbeitsbereich hinzufügen“ öffnet sich danach direkt in diesem Ordner — ohne Neustart.

![Verzeichnisauswahl bei E:\ComfyUI-aki-v3](assets/picker-dialog.png)

Die Karte zeigt stets das aktuell aktive Verzeichnis (`当前生效`). Lassen Sie das Feld leer und speichern Sie, oder klicken Sie auf **Löschen** (`清除`), um zum Standard (Benutzerverzeichnis) zurückzukehren.

Dieselbe Einstellung ist auch von der Kommandozeile verfügbar:
```bash
dsh-workspace-default-dir set E:\python_project   # Standardverzeichnis setzen
dsh-workspace-default-dir get                     # aktuelles Standard anzeigen
dsh-workspace-default-dir clear                   # löschen (zurück zu home)
dsh-workspace-default-dir status                  # Patch- und Einstellungszustand
```

GUI-Karte und CLI schreiben dieselbe Variable `DSH_PICKER_INITIAL_DIR` (über `setx` persistent) und bleiben daher synchron.

## Verhalten und Einschränkungen

- **Beide Auswahl-Backends werden abgedeckt**: der native Windows-Dialog (über `IFileDialog::SetFolder`) und der Browse-Auswahldialog (verwendet, wenn der Webserver an einen Nicht-Loopback-Host bindet, z. B. LAN `0.0.0.0`).
- **Registry-Fallback**: Die gepatchten Auswahldialoge lesen zuerst die Umgebungsvariable `DSH_PICKER_INITIAL_DIR`, dann direkt `HKCU\Environment` — das umgeht das Problem einer veralteten Explorer-Umgebung (kein Explorer-Neustart nach `setx` nötig).
- **Selbstheilung**: Bei jedem dsh-Start wendet das Plugin die beiden kleinen Backend-Patches idempotent erneut an, sodass ein dsh-Upgrade, das die Originaldateien wiederherstellt, automatisch repariert wird.
- Dies ist ein **Patch-Typ**-Plugin: Es ändert die beiden Auswahl-Paketdateien in der dsh-Installation (idempotent, nur additiv). Das Browse-Backend lädt sein gepatchtes Modul beim dsh-Start, daher ist nach Installation/Upgrade ein `dsh web`-Neustart nötig; der native Dialog liest seinen Worker bei jedem Öffnen.
- Verifiziert unter Windows + dsh 0.1.0-rc.6. Auf anderen Plattformen/Versionen wird bei nicht übereinstimmenden Edit-Paaren eine Warnung protokolliert und der Patch übersprungen (dsh startet trotzdem).

## Lizenz

MIT — siehe [LICENSE](LICENSE).