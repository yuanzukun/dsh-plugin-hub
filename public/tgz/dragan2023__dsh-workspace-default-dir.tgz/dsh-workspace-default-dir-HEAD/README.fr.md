# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![Carte de paramètres](assets/settings-card.png)
Faites en sorte que le sélecteur de dossier d'espace de travail de dsh (`Ajouter un espace de travail → Sélectionner le dossier de l'espace de travail`) s'ouvre dans un dossier **de votre choix** — par exemple `E:\python_project` — au lieu du répertoire personnel Windows.

## Installation

Choisissez l'une des trois méthodes ci-dessous, puis redémarrez `dsh web` :

```powershell
# 1) Paquet npm (lorsqu'il sera publié sur npm)
dsh plugin --profile web add dsh-workspace-default-dir

# 2) Dépôt GitHub (lib/ précompilé inclus, aucune compilation locale requise)
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) Répertoire local (développement / auto-hébergé)
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

Après le redémarrage, une entrée **Répertoire par défaut de l'espace de travail** apparaît dans **Paramètres**.

## Utilisation

Ouvrez **Paramètres → Répertoire par défaut de l'espace de travail** (`设置 → 工作区默认目录`). Saisissez un chemin absolu — par exemple `E:\python_project` — puis cliquez sur **Enregistrer** (`保存`). Le sélecteur de dossier « Ajouter un espace de travail » s'ouvrira directement dans ce dossier — sans redémarrage.

![Sélecteur de dossier ouvert sur E:\ComfyUI-aki-v3](assets/picker-dialog.png)

La carte affiche toujours le répertoire actif (`当前生效`). Laissez le champ vide et enregistrez, ou cliquez sur **Effacer** (`清除`), pour revenir au défaut (le répertoire personnel).

Le même réglage est disponible en ligne de commande :
```bash
dsh-workspace-default-dir set E:\python_project   # définit le répertoire par défaut
dsh-workspace-default-dir get                     # affiche le répertoire actuel
dsh-workspace-default-dir clear                   # l'efface (retour à l'accueil)
dsh-workspace-default-dir status                  # état des correctifs et du réglage
```

La carte GUI et la CLI écrivent la même variable `DSH_PICKER_INITIAL_DIR` (persistée via `setx`), elles restent donc synchronisées.

## Comportement et limites

- **Les deux backends de sélecteur sont couverts** : la boîte de dialogue Windows native (via `IFileDialog::SetFolder`) et le sélecteur browse (utilisé lorsque le serveur web lie un hôte non-bouclé, ex. LAN `0.0.0.0`).
- **Repli registre** : les sélecteurs corrigés lisent d'abord la variable d'environnement `DSH_PICKER_INITIAL_DIR`, puis directement `HKCU\Environment` — contournant le problème d'environnement périmé d'Explorer (pas de redémarrage d'Explorer après `setx`).
- **Auto-réparation** : à chaque démarrage de dsh, le plugin réapplique de façon idempotente les deux petits correctifs, donc une mise à niveau de dsh qui restaure les fichiers d'origine est réparée automatiquement.
- C'est un plugin de **type correctif** : il modifie les deux fichiers du package de sélecteur dans l'installation dsh (idempotent, additif uniquement). Le backend browse charge son module corrigé au démarrage de dsh, donc un redémarrage de `dsh web` est nécessaire après installation/mise à niveau ; la boîte de dialogue native lit son worker à chaque ouverture.
- Vérifié sur Windows + dsh 0.1.0-rc.6. Sur d'autres plateformes/versions, si les paires d'édition ne correspondent pas, un avertissement est journalisé et le correctif est ignoré (dsh démarre quand même).

## Licence

MIT — voir [LICENSE](LICENSE).