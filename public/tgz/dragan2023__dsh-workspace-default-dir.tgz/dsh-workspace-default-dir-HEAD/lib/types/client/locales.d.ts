/** Locale copy for the workspace-default-dir settings card. zh is the key source, en mirrors it. */
export declare const zh: {
    title: string;
    description: string;
    current: string;
    currentUnset: string;
    inputLabel: string;
    inputHint: string;
    save: string;
    clear: string;
    saved: string;
    cleared: string;
    errorInvalid: string;
    errorGeneric: string;
    restartHint: string;
};
export declare const en: typeof zh;
/** Locale key union. */
export type WorkspaceDefaultDirKey = keyof typeof zh;
