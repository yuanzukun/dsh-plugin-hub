/**
 * The workspace-default-dir settings card: one path input bound to the host
 * /api/workspace-default-dir route. Rendered as a first-level settings page
 * (settings.section), the same shape dsh-pet uses.
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** Business face the slot entry injects (plain props — no hooks compartment). */
export interface WorkspaceDefaultDirFace {
    /** Fetch the currently effective value ('' when unset). */
    get(): Promise<string>;
    /** Persist a value ('' clears). */
    set(value: string): Promise<void>;
}
/** Props the renderer binds. */
export type WorkspaceDefaultDirSectionProps = PropsLocale<'workspace-default-dir'> & InjectFace<WorkspaceDefaultDirFace>;
/** Default face implementation over the host route. */
export declare function routeFace(): WorkspaceDefaultDirFace;
/**
 * Render the settings card.
 * @param props - locale copy plus injected face functions.
 * @returns the section.
 */
export declare function WorkspaceDefaultDirSection(props: WorkspaceDefaultDirSectionProps): ReactNode;
