/**
 * Browser half of dsh-workspace-default-dir: registers the settings card as a
 * first-level settings section. Pure UI — all data flows through the host
 * /api/workspace-default-dir route (no settings domain, no shared state).
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type WorkspaceDefaultDirKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Workspace default directory card copy. */
        'workspace-default-dir': WorkspaceDefaultDirKey;
    }
}
/** Required services. */
export declare const inject: string[];
/** Type-only export (export discipline: no value exports beyond the plugin contract). */
export type { WorkspaceDefaultDirFace, WorkspaceDefaultDirSectionProps } from './Card.tsx';
/**
 * Mount the settings card.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
