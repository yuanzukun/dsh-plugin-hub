/**
 * dsh-workspace-default-dir — host half.
 *
 * 1. Self-heals the directory-picker backends (native worker.cjs + browse
 *    index.js) so both honor DSH_PICKER_INITIAL_DIR; idempotent, never throws.
 * 2. Serves /api/workspace-default-dir (GET current value, POST persist) for
 *    the GUI settings card. Persisting writes the user-level environment
 *    variable (setx on Windows) plus a ~/.dsh/workspace-default-dir.json
 *    sidecar; the patched pickers read env -> HKCU\\Environment registry, so
 *    the change applies on the next picker open without a dsh restart.
 */
import type { Context } from '@deepseek-ai/cordis';
/** API path family. */
export declare const API_BASE = "/api/workspace-default-dir";
/**
 * The plugin's public entry.
 * @param ctx - host plugin context.
 * @param config - resolved composition config (unused; self-heal + routes only).
 */
export declare function apply(ctx: Context): void;
