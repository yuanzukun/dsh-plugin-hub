export declare const EDIT_DEFS: {
    native: string[][];
    browse: string[][];
};
/** @returns the dsh package root when this process is a dsh host (argv[1] = <dsh>/lib/bin.js), else null. */
export declare function dshRootFromArgv(argv?: string[]): string | null;
/** Candidate npm global roots that may contain @deepseek-ai/dsh. */
export declare function candidateGlobalRoots(): string[];
/** Picker file paths inside one dsh install root. */
export declare function pickerFilesOf(dshRoot: any): {
    native: string;
    browse: string;
};
/** Discover every existing picker file across plausible installs. */
export declare function discoverPickerFiles(): {
    native: never[];
    browse: never[];
};
/** Patch one file with a list of edit pairs. Returns { status, file, detail }. */
export declare function patchFile(file: any, edits: any): {
    file: any;
    status: string;
    detail?: undefined;
} | {
    file: any;
    status: string;
    detail: string[];
} | {
    file: any;
    status: string;
    detail: string;
};
/** Heal every discovered picker file. Never throws (boot-safe). */
export declare function healAll(): ({
    file: any;
    status: string;
    detail?: undefined;
} | {
    file: any;
    status: string;
    detail: string[];
} | {
    file: any;
    status: string;
    detail: string;
})[];
/** Read the current DSH_PICKER_INITIAL_DIR (env -> user registry). */
export declare function readInitialDir(): string | undefined;
/** Persist the user-level environment variable (Windows: setx writes the registry AND broadcasts). */
export declare function setInitialDir(value: any): Promise<string>;
