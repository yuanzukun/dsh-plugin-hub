# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![Settings card](assets/settings-card.png)
Make dsh's workspace directory picker (`Add workspace → Select workspace directory`) open at a directory **you** choose — for example `E:\python_project` — instead of the Windows user home.

## Install

Pick one of the three ways below, then restart `dsh web`:

```powershell
# 1) npm package (when published to npm)
dsh plugin --profile web add dsh-workspace-default-dir

# 2) GitHub repository (ships the prebuilt lib/, no local build required)
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) Local directory (development / self-hosted)
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

After restarting `dsh web`, a **Workspace default directory** entry appears under **Settings**.

## Usage

Open **Settings → Workspace default directory** (`设置 → 工作区默认目录`). Type an absolute path — for example `E:\python_project` — then click **Save** (`保存`). The next time you open the `Add workspace` directory picker it starts at that folder — no restart needed.

![Directory picker opening at E:\ComfyUI-aki-v3](assets/picker-dialog.png)

The card always shows the currently active directory (`当前生效`). Leave the input empty and save, or click **Clear** (`清除`), to return to the default (the user home).

The same setting is available on the command line:
```bash
dsh-workspace-default-dir set E:\python_project   # set the default directory
dsh-workspace-default-dir get                     # show the current default
dsh-workspace-default-dir clear                   # clear it (back to home)
dsh-workspace-default-dir status                  # patch & setting state
```

The GUI card and the CLI write the same `DSH_PICKER_INITIAL_DIR` (`setx`-persisted), so they stay in sync.

## Behavior & limitations

- **Both picker backends are covered**: the native Windows dialog (via `IFileDialog::SetFolder`) and the browse picker (used when the web server binds a non-loopback host, e.g. LAN `0.0.0.0`).
- **Registry fallback**: the patched pickers read `DSH_PICKER_INITIAL_DIR` from the process environment first, then straight from `HKCU\Environment` — bypassing the stale-Explorer-environment problem (no Explorer restart needed after `setx`).
- **Self-healing**: on every dsh boot the plugin idempotently re-applies the two small backend patches, so a dsh upgrade that restored the stock files is repaired automatically.
- This is a **patch-type** plugin: it modifies the two picker package files inside the dsh installation (idempotent, additive only). The browse backend loads its patched module at dsh startup, so one `dsh web` restart is needed after install/upgrade; the native dialog reads its worker on every open.
- Verified on Windows + dsh 0.1.0-rc.6. On other platforms/versions, if the edit pairs do not match, a warning is logged and the patch is skipped (dsh still boots).

## License

MIT — see [LICENSE](LICENSE).