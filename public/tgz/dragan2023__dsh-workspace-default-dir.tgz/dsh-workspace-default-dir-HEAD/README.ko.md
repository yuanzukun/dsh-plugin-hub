# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![설정 카드](assets/settings-card.png)
dsh(DeepSeek Harness)의 「작업영역 추가 → 작업영역 디렉터리 선택」 대화상자를 **내가 선택한 디렉터리**(예: `E:\python_project`)에서 열리도록 합니다. Windows 사용자 홈 대신에.

## 설치

아래 세 방법 중 하나로 설치한 후 `dsh web`을 재시작하세요:

```powershell
# 1) npm 패키지 (npm 공개 시)
dsh plugin --profile web add dsh-workspace-default-dir

# 2) GitHub 저장소 (빌드된 lib/ 포함, 로컬 빌드 불필요)
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) 로컬 디렉터리 (개발/자체 호스팅)
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

재시작 후 설정 페이지에 **작업영역 기본 디렉터리** 항목이 추가됩니다.

## 사용법

**설정 → 작업영역 기본 디렉터리**를 열고 절대 경로(예: `E:\python_project`)를 입력한 뒤 **저장**을 누르세요. 이후 「작업영역 추가」 디렉터리 선택기가 해당 폴더에서 바로 열립니다(재시작 불필요).

![E:\ComfyUI-aki-v3를 여는 디렉터리 선택기](assets/picker-dialog.png)

카드에는 항상 현재 적용 중인 디렉터리(`当前生效`)가 표시됩니다. 입력을 비운 채 저장하거나 **지우기**(`清除`)를 누르면 기본값(사용자 홈)으로 돌아갑니다.

같은 설정을 명령줄에서도 사용할 수 있습니다:
```bash
dsh-workspace-default-dir set E:\python_project   # 기본 디렉터리 설정
dsh-workspace-default-dir get                     # 현재 기본값 표시
dsh-workspace-default-dir clear                   # 지우기 (홈으로 복귀)
dsh-workspace-default-dir status                  # 패치·설정 상태
```

GUI 카드와 CLI는 동일한 `DSH_PICKER_INITIAL_DIR`(setx로 영구 저장)을 쓰므로 항상 동기화됩니다.

## 동작 및 제한

- **두 선택기 모두 지원**: 네이티브 Windows 대화상자(`IFileDialog::SetFolder`)와 browse 선택기(webserver가 127.0.0.1이 아닌 호스트, 예: LAN `0.0.0.0`에 바인딩될 때 사용).
- **레지스트리 폴백**: 패치된 선택기는 먼저 환경변수 `DSH_PICKER_INITIAL_DIR`, 없으면 `HKCU\Environment`를 직접 읽습니다(Explorer 환경변수 갱신 문제 회피, `setx` 후 Explorer 재시작 불필요).
- **자가 복구**: dsh가 시작될 때마다 두 백엔드 패치를 멱등하게 재적용하므로, dsh 업그레이드로 원본 파일이 복원돼도 자동으로 복구됩니다.
- **패치형** 플러그인: dsh 설치 디렉터리 안의 두 선택기 패키지 파일을 수정합니다(멱등·추가만). browse 백엔드는 dsh 시작 시 패치된 모듈을 로드하므로 설치/업그레이드 후 `dsh web`을 한 번 재시작해야 합니다. 네이티브 대화상자는 열 때마다 워커를 읽어 즉시 반영됩니다.
- Windows + dsh 0.1.0-rc.6에서 검증. 다른 플랫폼/버전에서 편집 쌍이 일치하지 않으면 경고를 기록하고 패치를 건너뜁니다(dsh는 부팅 가능).

## 라이선스

MIT — [LICENSE](LICENSE) 참조.