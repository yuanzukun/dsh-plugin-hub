import test from 'node:test'
import assert from 'node:assert/strict'
import { EDIT_DEFS } from '../src/patches.ts'

test('edit pairs are internally consistent', () => {
  const all = [...EDIT_DEFS.native, ...EDIT_DEFS.browse]
  assert.ok(all.length > 0)
  const news = all.map(([, n]) => n)
  assert.equal(new Set(news).size, news.length, 'new strings unique')
  for (const [o] of all) assert.ok(o.length > 0)
})
