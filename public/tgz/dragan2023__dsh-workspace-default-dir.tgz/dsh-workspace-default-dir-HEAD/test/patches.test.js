import test from "node:test";
import assert from "node:assert/strict";
import { copyFileSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { EDIT_DEFS, patchFile } from "../lib/patches.js";

const here = dirname(fileURLToPath(import.meta.url));
const fixtures = join(here, "fixtures");
const NATIVE_SRC = "C:\\Users\\Administrator\\AppData\\Roaming\\npm\\node_modules\\@deepseek-ai\\dsh\\node_modules\\@deepseek-ai\\dsh-host-directory-picker-native\\lib\\worker.cjs";
const BROWSE_SRC = "C:\\Users\\Administrator\\AppData\\Roaming\\npm\\node_modules\\@deepseek-ai\\dsh\\node_modules\\@deepseek-ai\\dsh-host-directory-picker-browse\\lib\\index.js";

mkdirSync(fixtures, { recursive: true });
copyFileSync(NATIVE_SRC, join(fixtures, "native.patched"));
copyFileSync(BROWSE_SRC, join(fixtures, "browse.patched"));

function reverseFile(name, edits) {
  let src = readFileSync(join(fixtures, name + ".patched"), "utf8");
  for (const [oldStr, newStr] of [...edits].reverse()) {
    src = src.split(newStr).join(oldStr);
  }
  return src;
}

test("native edit pairs round-trip and are idempotent", () => {
  const stock = reverseFile("native", EDIT_DEFS.native);
  assert.ok(!stock.includes("SLOT_SET_FOLDER"), "stock lacks SLOT_SET_FOLDER");
  assert.ok(!stock.includes("IID_ISHELL_ITEM"), "stock lacks IID_ISHELL_ITEM");
  assert.ok(!stock.includes("DSH_PICKER_INITIAL_DIR"), "stock lacks env marker");

  const stockFile = join(fixtures, "native.stock");
  writeFileSync(stockFile, stock, "utf8");
  const r1 = patchFile(stockFile, EDIT_DEFS.native);
  assert.equal(r1.status, "patched", JSON.stringify(r1));
  const patched = readFileSync(stockFile, "utf8");
  assert.ok(patched.includes("SLOT_SET_FOLDER = 12"));
  assert.ok(patched.includes("IID_ISHELL_ITEM"));
  assert.ok(patched.includes("SHCreateItemFromParsingName"));
  assert.ok(patched.includes("setFolder: (item)"));
  assert.ok(patched.includes("process.env.DSH_PICKER_INITIAL_DIR"));
  assert.ok(patched.includes("HKCU"), "registry hive");
  assert.ok(patched.includes("execFileSync(\"reg\", [\"query\""), "reg query call");

  const r2 = patchFile(stockFile, EDIT_DEFS.native);
  assert.equal(r2.status, "already", JSON.stringify(r2));
  assert.equal(readFileSync(stockFile, "utf8"), patched, "idempotent");
});

test("browse edit pairs round-trip and are idempotent", () => {
  const stock = reverseFile("browse", EDIT_DEFS.browse);
  assert.ok(!stock.includes("configuredInitialDir"), "stock lacks helper");

  const stockFile = join(fixtures, "browse.stock");
  writeFileSync(stockFile, stock, "utf8");
  const r1 = patchFile(stockFile, EDIT_DEFS.browse);
  assert.equal(r1.status, "patched", JSON.stringify(r1));
  const patched = readFileSync(stockFile, "utf8");
  assert.ok(patched.includes("configuredInitialDir()"));
  assert.ok(patched.includes("resolve(path ?? configuredInitialDir() ?? home)"));

  const r2 = patchFile(stockFile, EDIT_DEFS.browse);
  assert.equal(r2.status, "already", JSON.stringify(r2));
  assert.equal(readFileSync(stockFile, "utf8"), patched, "idempotent");
});

test("edit pairs are internally consistent", () => {
  const all = [...EDIT_DEFS.native, ...EDIT_DEFS.browse];
  const news = all.map(([, n]) => n);
  assert.equal(new Set(news).size, news.length, "new strings unique");
  for (const [o] of all) assert.ok(o.length > 0, "old strings non-empty");
});
