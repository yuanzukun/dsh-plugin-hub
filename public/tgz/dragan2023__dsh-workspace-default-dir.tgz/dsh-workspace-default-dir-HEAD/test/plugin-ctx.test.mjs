// Regression tests for the host apply()'s service access.
// 1) It must never touch an undeclared service via ctx.<name> (Cordis reflect
//    proxy throws "cannot get property X without inject").
// 2) The optional webServer must be waited for via ctx.inject, because the
//    webserver row itself waits on webStartup and is not yet provided when
//    this plugin's row applies — an eager ctx.get races it and loses the
//    route registration.
import test from 'node:test'
import assert from 'node:assert/strict'
import { apply } from '../lib/index.js'

/** Fake Cordis ctx: unknown property access throws (like the reflect proxy). */
function fakeCtx() {
  const services = {}
  let injectCb = null
  const target = {
    logger: { info() {}, warn() {} },
    get(name) { return services[name] },
    inject(deps, cb) { injectCb = cb },
    effect(fn, label) { return fn() },
    fiber: { state: 0 },
  }
  const ctx = new Proxy(target, {
    get(t, prop) {
      if (typeof prop === 'symbol') return Reflect.get(t, prop)
      if (prop in t) return Reflect.get(t, prop)
      throw new Error('cannot get property "' + String(prop) + '" without inject')
    },
  })
  return {
    ctx,
    provide: (name, value) => {
      services[name] = value
      if (injectCb) { const cb = injectCb; injectCb = null; cb({ ...target, ...services, get: (n) => services[n] }) }
    },
  }
}

test('apply() tolerates a webServer that never appears (headless-like)', () => {
  const { ctx } = fakeCtx()
  apply(ctx) // must not throw
  assert.ok(true)
})

test('apply() registers the API route once webServer becomes available (inject timing)', () => {
  const registered = []
  const { ctx, provide } = fakeCtx()
  apply(ctx)
  assert.equal(registered.length, 0, 'no route before webServer exists')
  provide('webServer', { register: (route) => { registered.push(route.path); return () => {} } })
  assert.deepEqual(registered, ['/api/workspace-default-dir'], 'route registered after webServer arrives')
})
