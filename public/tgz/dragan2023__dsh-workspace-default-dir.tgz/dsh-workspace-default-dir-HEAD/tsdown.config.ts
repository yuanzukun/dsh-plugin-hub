/**
 * Standalone build config for dsh-workspace-default-dir (family-workspace build).
 * Node half lib/ (host plugin: patches + settings domain) plus browser bundle
 * lib/client.js (closure-factory artifact for the GUI's __ModuleLoader__).
 */
import { clientBundle } from '../../shared/tsdown.client.ts'

export default clientBundle('dsh-workspace-default-dir', ['src/index.ts'], {
  libExternal: [
    '@deepseek-ai/dsh-settings',
  ],
})
