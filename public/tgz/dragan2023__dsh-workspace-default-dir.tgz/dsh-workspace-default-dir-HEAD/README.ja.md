# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![設定カード](assets/settings-card.png)
dsh（DeepSeek Harness）の「ワークスペース追加 → ワークスペースディレクトリを選択」ダイアログを、**自分で選んだディレクトリ**（例：`E:\python_project`）で開くようにします。Windows のユーザーホームの代わりに。

## インストール

次のいずれかの方法でインストールし、`dsh web` を再起動してください：

```powershell
# 1) npm パッケージ（npm 公開時）
dsh plugin --profile web add dsh-workspace-default-dir

# 2) GitHub リポジトリ（ビルド済み lib/ を含むためローカルビルド不要）
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) ローカルディレクトリ（開発/自分用）
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

再起動後、設定ページに **ワークスペースの既定ディレクトリ** が追加されます。

## 使い方

**設定 → ワークスペースの既定ディレクトリ** を開き、絶対パス（例：`E:\python_project`）を入力して **保存** を押します。以後、「ワークスペース追加」のディレクトリ選択はそのフォルダを直接開きます（再起動不要）。

![E:\ComfyUI-aki-v3 を開くディレクトリ選択](assets/picker-dialog.png)

カードには常に現在有効なディレクトリ（`当前生效`）が表示されます。入力を空のまま保存するか、**クリア**（`清除`）を押すと既定（ユーザーホーム）に戻ります。

コマンドラインでも同じ設定が使えます：
```bash
dsh-workspace-default-dir set E:\python_project   # 既定ディレクトリを設定
dsh-workspace-default-dir get                     # 現在の既定を表示
dsh-workspace-default-dir clear                   # クリア（ホームに戻す）
dsh-workspace-default-dir status                  # パッチと設定の状態
```

GUI カードと CLI は同じ `DSH_PICKER_INITIAL_DIR`（setx で永続化）を書き、常に同期されます。

## 動作と制限

- **両方のピッカーをカバー**：ネイティブ Windows ダイアログ（`IFileDialog::SetFolder`）と browse ピッカー（webserver が 127.0.0.1 以外、例：LAN `0.0.0.0` にバインドされた時に使用）。
- **レジストリのフォールバック**：パッチ済みピッカーはまず環境変数 `DSH_PICKER_INITIAL_DIR`、次に `HKCU\Environment` を直接読みます（Explorer の環境変数の古さ問題を回避、`setx` 後に Explorer 再起動不要）。
- **自己修復**：dsh 起動のたびに 2 つのバックエンドパッチを冪等に再適用し、dsh アップグレードで標準ファイルに戻っても自動修復します。
- **パッチ型**プラグインのため、dsh インストール内の 2 つのピッカーパッケージファイルを変更します（冪等・追加のみ）。browse バックエンドは dsh 起動時にパッチ済みモジュールを読み込むため、インストール/アップグレード後に `dsh web` の再起動が 1 回必要です。ネイティブダイアログは毎回ワーカーを読み込み即時反映されます。
- Windows + dsh 0.1.0-rc.6 で検証済み。他のプラットフォーム/バージョンで編集ペアが一致しない場合、警告をログ出力してパッチをスキップします（dsh は起動できます）。

## ライセンス

MIT — [LICENSE](LICENSE) を参照。