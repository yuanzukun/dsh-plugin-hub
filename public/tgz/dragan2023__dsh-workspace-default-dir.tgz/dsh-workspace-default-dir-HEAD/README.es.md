# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![Tarjeta de configuración](assets/settings-card.png)
Haz que el selector de directorio del espacio de trabajo de dsh ("Añadir espacio de trabajo → Seleccionar directorio del espacio de trabajo") se abra en un directorio **que tú elijas** — por ejemplo `E:\python_project` — en lugar del directorio de usuario de Windows.

## Instalación

Elige una de las tres formas siguientes y reinicia `dsh web`:

```powershell
# 1) Paquete npm (cuando se publique en npm)
dsh plugin --profile web add dsh-workspace-default-dir

# 2) Repositorio de GitHub (incluye lib/ precompilado, sin compilación local)
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) Directorio local (desarrollo / autoalojado)
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

Tras reiniciar, aparece una entrada **Directorio predeterminado del espacio de trabajo** en **Configuración**.

## Uso

Abre **Configuración → Directorio predeterminado del espacio de trabajo** (`设置 → 工作区默认目录`). Escribe una ruta absoluta — por ejemplo `E:\python_project` — y pulsa **Guardar** (`保存`). El selector de directorio "Añadir espacio de trabajo" se abrirá directamente en esa carpeta — sin reiniciar.

![Selector de directorio abierto en E:\ComfyUI-aki-v3](assets/picker-dialog.png)

La tarjeta muestra siempre el directorio activo (`当前生效`). Deja el campo vacío y guarda, o pulsa **Borrar** (`清除`), para volver al valor predeterminado (el directorio de usuario).

El mismo ajuste está disponible en la línea de comandos:
```bash
dsh-workspace-default-dir set E:\python_project   # fija el directorio predeterminado
dsh-workspace-default-dir get                     # muestra el predeterminado actual
dsh-workspace-default-dir clear                   # lo borra (vuelve a home)
dsh-workspace-default-dir status                  # estado del parche y del ajuste
```

La tarjeta GUI y la CLI escriben la misma variable `DSH_PICKER_INITIAL_DIR` (persistida con `setx`), así que permanecen sincronizadas.

## Comportamiento y limitaciones

- **Cubre ambos backends de selector**: el diálogo nativo de Windows (mediante `IFileDialog::SetFolder`) y el selector browse (usado cuando el servidor web enlaza un host no-loopback, p. ej. LAN `0.0.0.0`).
- **Respaldo por registro**: los selectores parcheados leen primero la variable de entorno `DSH_PICKER_INITIAL_DIR` y luego directamente `HKCU\Environment` — sorteando el problema de entorno obsoleto del Explorador (no hace falta reiniciar el Explorador tras `setx`).
- **Autocuración**: en cada arranque de dsh el plugin reaplica de forma idempotente los dos parches de backend, así que una actualización de dsh que restaure los archivos originales se repara automáticamente.
- Es un plugin de **tipo parche**: modifica los dos archivos del paquete de selector dentro de la instalación de dsh (idempotente, solo aditivo). El backend browse carga su módulo parcheado al arrancar dsh, por lo que hace falta un reinicio de `dsh web` tras instalar/actualizar; el diálogo nativo lee su worker en cada apertura.
- Verificado en Windows + dsh 0.1.0-rc.6. En otras plataformas/versiones, si los pares de edición no coinciden, se registra una advertencia y se omite el parche (dsh arranca igualmente).

## Licencia

MIT — ver [LICENSE](LICENSE).