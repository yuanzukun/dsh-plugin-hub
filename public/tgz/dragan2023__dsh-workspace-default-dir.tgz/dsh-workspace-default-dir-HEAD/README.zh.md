# dsh-workspace-default-dir

[English](README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · [한국어](README.ko.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Español](README.es.md) · [Português](README.pt.md) · [Русский](README.ru.md)
![设置卡片](assets/settings-card.png)
让 dsh（DeepSeek Harness）的「添加工作区 → 选择工作区目录」对话框默认打开在**你指定的目录**（例如 `E:\python_project`），而不是 Windows 用户主目录。

## 安装

三种方式任选其一，然后重启 `dsh web`：

```powershell
# 1) npm 包（发布到 npm 后可用）
dsh plugin --profile web add dsh-workspace-default-dir

# 2) GitHub 仓库（仓库内已含预构建 lib/，无需本地构建）
dsh plugin --profile web add https://github.com/dragan2023/dsh-workspace-default-dir

# 3) 本地目录（开发/自用）
dsh plugin --profile web add D:\path\to\dsh-workspace-default-dir
```

重启 `dsh web` 后，设置页出现 **工作区默认目录** 一项。

## 使用

打开 **设置 → 工作区默认目录**。输入绝对路径（例如 `E:\python_project`），点 **保存**。之后每次打开「添加工作区」目录选择器，都会直接定位到该目录——无需重启。

![目录选择器已定位到 E:\\ComfyUI-aki-v3](assets/picker-dialog.png)

卡片始终显示当前生效目录（`当前生效`）。输入留空保存，或点 **清除**，即恢复默认（用户主目录）。

同样可在命令行使用：
```bash
dsh-workspace-default-dir set E:\python_project   # 设置默认目录
dsh-workspace-default-dir get                     # 查看当前默认目录
dsh-workspace-default-dir clear                   # 清除（回到主目录）
dsh-workspace-default-dir status                  # 补丁与设置状态
```

GUI 卡片与 CLI 写的是同一个 `DSH_PICKER_INITIAL_DIR`（setx 持久化），二者始终同步。

## 行为与限制

- **两个选择器后端都覆盖**：原生 Windows 对话框（`IFileDialog::SetFolder`）与 browse 应用内选择器（webserver 绑定非 127.0.0.1，如局域网 `0.0.0.0` 时自动启用）。
- **注册表兜底**：补丁后的选择器先读进程环境变量 `DSH_PICKER_INITIAL_DIR`，没有则直接查 `HKCU\Environment`——绕开 Explorer 环境陈旧问题（`setx` 后无需重启 Explorer）。
- **启动自愈**：每次 dsh 启动插件幂等重打两个后端补丁，dsh 升级恢复原文件后自动修复。
- 属于**补丁型**插件：会修改 dsh 安装目录内两个选择器包文件（幂等、只增不改）。browse 后端在 dsh 启动时加载补丁模块，安装/升级后需重启一次 `dsh web`；原生对话框每次弹窗读 worker，即时生效。
- 已验证于 Windows + dsh 0.1.0-rc.6；其他平台/版本如编辑对不匹配会打印警告并跳过补丁（不影响 dsh 启动）。

## 许可

MIT，详见 [LICENSE](LICENSE)。