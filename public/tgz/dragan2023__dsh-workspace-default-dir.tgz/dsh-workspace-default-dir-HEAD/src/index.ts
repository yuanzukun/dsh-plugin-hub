/**
 * dsh-workspace-default-dir — host half.
 *
 * 1. Self-heals the directory-picker backends (native worker.cjs + browse
 *    index.js) so both honor DSH_PICKER_INITIAL_DIR; idempotent, never throws.
 * 2. Serves /api/workspace-default-dir (GET current value, POST persist) for
 *    the GUI settings card. Persisting writes the user-level environment
 *    variable (setx on Windows) plus a ~/.dsh/workspace-default-dir.json
 *    sidecar; the patched pickers read env -> HKCU\\Environment registry, so
 *    the change applies on the next picker open without a dsh restart.
 */

import { existsSync, statSync } from 'node:fs'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { healAll, readInitialDir, setInitialDir } from './patches.ts'

/** API path family. */
export const API_BASE = '/api/workspace-default-dir'

/** Response helper. */
function writeJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' })
  res.end(payload)
}

/** Read a small JSON request body. */
async function readJsonBody(req: IncomingMessage): Promise<Record<string, unknown> | undefined> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk as Buffer
    size += buffer.length
    if (size > 64 * 1024) return undefined
    chunks.push(buffer)
  }
  try {
    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return typeof parsed === 'object' && parsed !== null ? parsed as Record<string, unknown> : undefined
  } catch {
    return undefined
  }
}

/** Whether a value is a plausible absolute directory path. */
function isAbsolutePath(value: string): boolean {
  return /^(?:[A-Za-z]:[\\/]|[\\/]{2}[^\\/]+[\\/]+[^\\/]+)/.test(value)
}

/**
 * The plugin's public entry.
 * @param ctx - host plugin context.
 * @param config - resolved composition config (unused; self-heal + routes only).
 */
export function apply(ctx: Context): void {
  // 1. Self-heal the picker backends (boot-safe; a mismatch only logs).
  try {
    const results = healAll()
    for (const result of results) {
      if (result.status === 'patched') ctx.logger.info('[workspace-default-dir] patched %s', result.file)
      else if (result.status === 'mismatch') ctx.logger.warn('[workspace-default-dir] cannot patch %s — dsh version changed? run `dsh-workspace-default-dir patch`', result.file)
    }
  } catch (error) {
    ctx.logger.warn('[workspace-default-dir] self-heal skipped: %s', String(error))
  }

  // 2. Settings routes — wait for the optional webServer service.
  //    The webserver row itself waits on webStartup, so at plugin-apply time
  //    the service may not exist yet (racing it with ctx.get lost the route).
  //    ctx.inject runs the callback only when the service is up and never
  //    fires (harmlessly) when it is absent — the canonical optional-service
  //    pattern (same as dsh-settings' installSettingsSection).
  ctx.inject(['webServer'], (sctx) => {
    sctx.effect(() => {
      const disposers = [
        sctx.webServer.register({
        kind: 'exact',
        path: API_BASE,
        handler: (req, res) => {
          if (req.method !== 'GET' && req.method !== 'POST') {
            res.writeHead(405, { 'content-type': 'text/plain' })
            res.end('method not allowed')
            return
          }
          if (req.method === 'GET') {
            const value = readInitialDir()
            writeJson(res, 200, { initialDir: value ?? '' })
            return
          }
          void (async () => {
            try {
              const body = await readJsonBody(req)
              const raw = typeof body === 'object' && body !== null ? body.initialDir : undefined
              if (typeof raw !== 'string') {
                writeJson(res, 400, { error: 'initialDir must be a string' })
                return
              }
              const value = raw.trim()
              if (value !== '' && (!isAbsolutePath(value) || !existsSyncPath(value))) {
                writeJson(res, 400, { error: 'not an existing absolute directory: ' + value })
                return
              }
              await setInitialDir(value)
              writeJson(res, 200, { initialDir: value })
            } catch (error) {
              writeJson(res, 500, { error: String(error && typeof error === 'object' && 'message' in error ? error.message : error) })
            }
          })()
        },
      }),
    ]
      return () => { for (const dispose of disposers) dispose() }
    }, 'workspace-default-dir: routes')
  })
}

/** Exists-and-directory check. */
function existsSyncPath(value: string): boolean {
  try {
    return existsSync(value) && statSync(value).isDirectory()
  } catch {
    return false
  }
}
