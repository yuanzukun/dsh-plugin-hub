// @ts-nocheck — generated-style module shared with the standalone CLI build.
// dsh-workspace-default-dir: shared patch definitions + application for the
// directory-picker backends of @deepseek-ai/dsh.
//
// The two picker backends hardcode the picker's initial location (the native
// Win32 dialog never calls IFileDialog::SetFolder, and the browse backend
// defaults to homedir()). This module applies a minimal, idempotent patch so
// both honor DSH_PICKER_INITIAL_DIR (process env -> HKCU\\Environment registry
// fallback, which bypasses a stale Explorer environment after setx).
import { execFileSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

export const EDIT_DEFS = {
  "native": [
    [
      "const SLOT_RELEASE = 2;\nconst SLOT_SHOW = 3;\nconst SLOT_SET_OPTIONS = 9;\nconst SLOT_SET_TITLE = 17;\nconst SLOT_GET_RESULT = 20;",
      "const SLOT_RELEASE = 2;\nconst SLOT_SHOW = 3;\nconst SLOT_SET_OPTIONS = 9;\nconst SLOT_SET_FOLDER = 12;\nconst SLOT_SET_TITLE = 17;\nconst SLOT_GET_RESULT = 20;"
    ],
    [
      "const CLSID_FILE_OPEN_DIALOG = guidBytes(\"dc1c5a9c-e88a-4dde-a5a1-60f82a20aef7\");\nconst IID_IFILE_OPEN_DIALOG = guidBytes(\"d57c7288-d4ad-4768-be02-9d969532d960\");",
      "const CLSID_FILE_OPEN_DIALOG = guidBytes(\"dc1c5a9c-e88a-4dde-a5a1-60f82a20aef7\");\nconst IID_IFILE_OPEN_DIALOG = guidBytes(\"d57c7288-d4ad-4768-be02-9d969532d960\");\nconst IID_ISHELL_ITEM = guidBytes(\"43826d1e-e718-42ee-bc55-a1e261c37bfe\");"
    ],
    [
      "\tconst ole32 = koffi.load(\"ole32.dll\");\n\tconst user32 = koffi.load(\"user32.dll\");\n\tconst kernel32 = koffi.load(\"kernel32.dll\");",
      "\tconst ole32 = koffi.load(\"ole32.dll\");\n\tconst user32 = koffi.load(\"user32.dll\");\n\tconst kernel32 = koffi.load(\"kernel32.dll\");\n\tconst shell32 = koffi.load(\"shell32.dll\");"
    ],
    [
      "\tconst protoRelease = koffi.proto(\"uint32 __stdcall DshComRelease(void *self)\");",
      "\tconst protoRelease = koffi.proto(\"uint32 __stdcall DshComRelease(void *self)\");\n\tconst protoSetFolder = koffi.proto(\"int32 __stdcall DshDialogSetFolder(void *self, void *item)\");\n\tconst createItemFromParsingName = shell32.func(\"__stdcall\", \"SHCreateItemFromParsingName\", \"int32\", [\"str16\", \"void *\", \"void *\", \"void *\"]);"
    ],
    [
      "\t\tcurrentThreadId: () => getCurrentThreadId(),\n\t\tcreateFolderDialog: () => {",
      "\t\tcurrentThreadId: () => getCurrentThreadId(),\n\t\tcreateShellItem: (path) => {\n\t\t\tconst out = Buffer.alloc(pointerSize);\n\t\t\tconst created = createItemFromParsingName(path, null, IID_ISHELL_ITEM, out);\n\t\t\tif (created < 0) throw new Error(`SHCreateItemFromParsingName(${JSON.stringify(path)}) failed: HRESULT 0x${(created >>> 0).toString(16)}`);\n\t\t\treturn koffi.decode(out, \"void *\");\n\t\t},\n\t\treleaseShellItem: (item) => method(item, SLOT_RELEASE, protoRelease)(),\n\t\tcreateFolderDialog: () => {"
    ],
    [
      "\t\t\t\tsetTitle: (title) => method(dialog, SLOT_SET_TITLE, protoSetTitle)(title),",
      "\t\t\t\tsetTitle: (title) => method(dialog, SLOT_SET_TITLE, protoSetTitle)(title),\n\t\t\t\tsetFolder: (item) => method(dialog, SLOT_SET_FOLDER, protoSetFolder)(item),"
    ],
    [
      "function runFolderDialog(bindings, title, onShowing) {",
      "function runFolderDialog(bindings, title, initialPath, onShowing) {"
    ],
    [
      "\t\t\tcheck(dialog.setOptions(104), \"SetOptions\");\n\t\t\tcheck(dialog.setTitle(title), \"SetTitle\");\n\t\t\tonShowing(bindings.currentThreadId());",
      "\t\t\tcheck(dialog.setOptions(104), \"SetOptions\");\n\t\t\tcheck(dialog.setTitle(title), \"SetTitle\");\n\t\t\tif (initialPath !== void 0 && initialPath !== \"\") {\n\t\t\t\ttry {\n\t\t\t\t\tconst item = bindings.createShellItem(initialPath);\n\t\t\t\t\ttry {\n\t\t\t\t\t\tcheck(dialog.setFolder(item), \"SetFolder\");\n\t\t\t\t\t} finally {\n\t\t\t\t\t\tbindings.releaseShellItem(item);\n\t\t\t\t\t}\n\t\t\t\t} catch {\n\t\t\t\t\t// DSH_PICKER_INITIAL_DIR set but unusable — open the picker at its default location.\n\t\t\t\t}\n\t\t\t}\n\t\t\tonShowing(bindings.currentThreadId());"
    ],
    [
      "(async () => {\n\ttry {\n\t\tpost({\n\t\t\tkind: \"done\",\n\t\t\tpath: runFolderDialog(await loadWin32DialogBindings(), title, (threadId) => {",
      "(async () => {\n\ttry {\n\t\tlet initialDir = process.env.DSH_PICKER_INITIAL_DIR;\n\t\tif (initialDir === void 0 || initialDir === \"\") {\n\t\t\ttry {\n\t\t\t\t// Fallback: read the user-level env var straight from the registry, so a\n\t\t\t\t// dsh web launched from Explorer (which keeps a stale environment after\n\t\t\t\t// setx) still picks the configured initial directory.\n\t\t\t\tconst { execFileSync } = await import(\"node:child_process\");\n\t\t\t\tconst regOut = execFileSync(\"reg\", [\"query\", \"HKCU\\\\Environment\", \"/v\", \"DSH_PICKER_INITIAL_DIR\"], { encoding: \"utf8\", windowsHide: true });\n\t\t\t\tconst m = /DSH_PICKER_INITIAL_DIR\\s+REG_SZ\\s+(.+)/i.exec(regOut);\n\t\t\t\tif (m !== null && m[1].trim() !== \"\") initialDir = m[1].trim();\n\t\t\t} catch {\n\t\t\t\tinitialDir = void 0;\n\t\t\t}\n\t\t}\n\t\tpost({\n\t\t\tkind: \"done\",\n\t\t\tpath: runFolderDialog(await loadWin32DialogBindings(), title, initialDir, (threadId) => {"
    ]
  ],
  "browse": [
    [
      "import { mkdir, opendir, stat } from \"node:fs/promises\";\nimport { homedir } from \"node:os\";",
      "import { execFileSync } from \"node:child_process\";\nimport { mkdir, opendir, stat } from \"node:fs/promises\";\nimport { homedir } from \"node:os\";"
    ],
    [
      "/**\n* One listing row for a dirent, following symlinks to directories; null for\n* non-directories and broken/cyclic links (skipped silently — the browser\n* shows what can be entered, and a broken link cannot).\n*/",
      "/**\n* The configured initial directory for the picker: process env first, then the\n* user-level registry value (so a host launched from Explorer — which keeps a\n* stale environment after setx — still picks it up). Undefined when unset.\n* @returns the initial directory, or undefined to keep the host home default.\n*/\nfunction configuredInitialDir() {\n\tconst fromEnv = process.env.DSH_PICKER_INITIAL_DIR;\n\tif (fromEnv !== void 0 && fromEnv !== \"\") return fromEnv;\n\ttry {\n\t\tconst out = execFileSync(\"reg\", [\"query\", \"HKCU\\\\Environment\", \"/v\", \"DSH_PICKER_INITIAL_DIR\"], { encoding: \"utf8\", windowsHide: true });\n\t\tconst m = /DSH_PICKER_INITIAL_DIR\\s+REG_SZ\\s+(.+)/i.exec(out);\n\t\tif (m !== null && m[1].trim() !== \"\") return m[1].trim();\n\t} catch {\n\t\treturn void 0;\n\t}\n\treturn void 0;\n}\n/**\n* One listing row for a dirent, following symlinks to directories; null for\n* non-directories and broken/cyclic links (skipped silently — the browser\n* shows what can be entered, and a broken link cannot).\n*/"
    ],
    [
      "\t\tconst target = resolve(path ?? home);",
      "\t\tconst target = resolve(path ?? configuredInitialDir() ?? home);"
    ]
  ]
};

/** @returns the dsh package root when this process is a dsh host (argv[1] = <dsh>/lib/bin.js), else null. */
export function dshRootFromArgv(argv = process.argv) {
  try {
    if (argv.length < 2) return null;
    const bin = argv[1];
    if (typeof bin !== "string") return null;
    const base = basenameOf(bin);
    // <root>/lib/bin.js or <root>/lib/<any>.js
    const dir = dirname(bin);
    if (basenameOf(dir) !== "lib") return null;
    const root = dirname(dir);
    return existsSync(join(root, "package.json")) ? root : null;
  } catch {
    return null;
  }
}
function basenameOf(p) {
  return p.split(/[\\/]/).pop() ?? "";
}

/** Candidate npm global roots that may contain @deepseek-ai/dsh. */
export function candidateGlobalRoots() {
  const roots = [];
  if (process.env.APPDATA) roots.push(join(process.env.APPDATA, "npm", "node_modules"));
  try {
    const out = execFileSync(process.platform === "win32" ? "npm.cmd" : "npm", ["root", "-g"], { encoding: "utf8" });
    const line = (out || "").trim().split(/\r?\n/).pop()?.trim();
    if (line) roots.push(line);
  } catch {
    /* npm may be missing; ignore */
  }
  if (process.platform !== "win32") roots.push("/usr/local/lib/node_modules");
  return [...new Set(roots)].filter(Boolean);
}

/** Picker file paths inside one dsh install root. */
export function pickerFilesOf(dshRoot) {
  return {
    native: join(dshRoot, "node_modules", "@deepseek-ai", "dsh-host-directory-picker-native", "lib", "worker.cjs"),
    browse: join(dshRoot, "node_modules", "@deepseek-ai", "dsh-host-directory-picker-browse", "lib", "index.js")
  };
}

/** Discover every existing picker file across plausible installs. */
export function discoverPickerFiles() {
  const found = { native: [], browse: [] };
  const roots = [];
  const fromArgv = dshRootFromArgv();
  if (fromArgv) roots.push(fromArgv);
  // Only probe global npm roots when the running host did not already locate the files
  // (spawning npm.cmd on every boot is wasteful inside a dsh host process).
  const needsProbe = !fromArgv || !existsSync(pickerFilesOf(fromArgv).native) || !existsSync(pickerFilesOf(fromArgv).browse);
  if (needsProbe) {
    for (const globalRoot of candidateGlobalRoots()) roots.push(join(globalRoot, "@deepseek-ai", "dsh"));
  }
  for (const root of [...new Set(roots.filter(Boolean))]) {
    const files = pickerFilesOf(root);
    if (existsSync(files.native)) found.native.push(files.native);
    if (existsSync(files.browse)) found.browse.push(files.browse);
  }
  return found;
}

/**
* Apply one edit pair idempotently. Returns "applied" | "already" | "mismatch".
* The new content wins when both are present (old may be a prefix of new).
*/
function applyEdit(src, oldStr, newStr) {
  if (src.includes(newStr)) return "already";
  if (src.includes(oldStr)) {
    const count = src.split(oldStr).length - 1;
    if (count !== 1) return "mismatch";
    return { src: src.replace(oldStr, newStr), result: "applied" };
  }
  return "mismatch";
}

/** Patch one file with a list of edit pairs. Returns { status, file, detail }. */
export function patchFile(file, edits) {
  let src;
  try {
    src = readFileSync(file, "utf8");
  } catch {
    return { file, status: "missing" };
  }
  let changed = false;
  let detail = [];
  for (const [oldStr, newStr] of edits) {
    const r = applyEdit(src, oldStr, newStr);
    if (typeof r === "object") {
      src = r.src;
      changed = true;
      detail.push("applied");
    } else if (r === "already") {
      detail.push("already");
    } else {
      return { file, status: "mismatch", detail: detail.concat("mismatch") };
    }
  }
  if (changed) {
    try {
      writeFileSync(file, src, "utf8");
      return { file, status: "patched", detail };
    } catch (e) {
      return { file, status: "error", detail: String(e && e.message || e) };
    }
  }
  return { file, status: "already", detail };
}

/** Heal every discovered picker file. Never throws (boot-safe). */
export function healAll() {
  const found = discoverPickerFiles();
  const results = [];
  for (const file of found.native) results.push(patchFile(file, EDIT_DEFS.native));
  for (const file of found.browse) results.push(patchFile(file, EDIT_DEFS.browse));
  return results;
}

/** Read the current DSH_PICKER_INITIAL_DIR (env -> user registry). */
export function readInitialDir() {
  const fromEnv = process.env.DSH_PICKER_INITIAL_DIR;
  if (fromEnv !== void 0 && fromEnv !== "") return fromEnv;
  if (process.platform === "win32") {
    try {
      const out = execFileSync("reg", ["query", "HKCU\\Environment", "/v", "DSH_PICKER_INITIAL_DIR"], { encoding: "utf8", windowsHide: true });
      const m = /DSH_PICKER_INITIAL_DIR\s+REG_SZ\s+(.+)/i.exec(out);
      if (m !== null && m[1].trim() !== "") return m[1].trim();
    } catch {
      /* unset */
    }
  }
  return void 0;
}

/** Persist the user-level environment variable (Windows: setx writes the registry AND broadcasts). */
export async function setInitialDir(value) {
  if (process.platform === "win32") {
    execFileSync("setx", ["DSH_PICKER_INITIAL_DIR", value ?? ""], { stdio: "ignore", windowsHide: true });
  }
  // Record a JSON sidecar for reference on any platform.
  const fs = await import("node:fs");
  const os = await import("node:os");
  const path = await import("node:path");
  const file = path.join(os.homedir(), ".dsh", "workspace-default-dir.json");
  fs.writeFileSync(file, JSON.stringify({ initialDir: value ?? null, updatedAt: new Date().toISOString() }, null, 2) + "\n", "utf8");
  return file;
}
