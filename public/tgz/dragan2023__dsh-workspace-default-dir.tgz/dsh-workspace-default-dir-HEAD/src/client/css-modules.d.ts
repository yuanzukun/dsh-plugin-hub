/** CSS module typing (family preset). */
declare module '*.module.css' {
  const classes: Record<string, string>
  export default classes
}
