/**
 * The workspace-default-dir settings card: one path input bound to the host
 * /api/workspace-default-dir route. Rendered as a first-level settings page
 * (settings.section), the same shape dsh-pet uses.
 */

import { useEffect, useState, type ReactNode } from 'react'
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import css from './card.module.css'
import type { WorkspaceDefaultDirKey } from './locales.ts'

/** API base shared with the host half. */
const API = '/api/workspace-default-dir'

/** Error carrying the route's JSON error message. */
class ApiError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'ApiError'
  }
}

/** Read a JSON response, surfacing the route's error text. */
async function readJson<T>(response: Response): Promise<T> {
  let body: unknown
  try {
    body = await response.json()
  } catch {
    throw new ApiError(`HTTP ${response.status}: invalid JSON`)
  }
  if (!response.ok) {
    const message = typeof body === 'object' && body !== null && typeof (body as { error?: unknown }).error === 'string'
      ? (body as { error: string }).error
      : `HTTP ${response.status}`
    throw new ApiError(message)
  }
  return body as T
}

/** Business face the slot entry injects (plain props — no hooks compartment). */
export interface WorkspaceDefaultDirFace {
  /** Fetch the currently effective value ('' when unset). */
  get(): Promise<string>
  /** Persist a value ('' clears). */
  set(value: string): Promise<void>
}

/** Props the renderer binds. */
export type WorkspaceDefaultDirSectionProps =
  PropsLocale<'workspace-default-dir'>
  & InjectFace<WorkspaceDefaultDirFace>

/** Default face implementation over the host route. */
export function routeFace(): WorkspaceDefaultDirFace {
  return {
    async get() {
      const data = await readJson<{ initialDir: string }>(await fetch(API, { method: 'GET' }))
      return data.initialDir ?? ''
    },
    async set(value) {
      await readJson<{ initialDir: string }>(await fetch(API, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ initialDir: value }),
      }))
    },
  }
}

/**
 * Render the settings card.
 * @param props - locale copy plus injected face functions.
 * @returns the section.
 */
export function WorkspaceDefaultDirSection(props: WorkspaceDefaultDirSectionProps): ReactNode {
  const { t } = props
  const { get, set } = props
  const [value, setValue] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    get().then((current) => {
      if (!alive) return
      setValue(current)
    }, (reason: unknown) => {
      if (!alive) return
      setError(reason instanceof Error ? reason.message : String(reason))
    })
    return () => { alive = false }
  }, [get])

  const save = async (): Promise<void> => {
    setBusy(true)
    setError(null)
    setMessage(null)
    try {
      await set(value.trim())
      setMessage(value.trim() === '' ? t('cleared') : t('saved'))
    } catch (reason) {
      const message = reason instanceof Error ? reason.message : String(reason)
      setError(message.includes('HTTP') || message.includes('not an existing') ? t('errorInvalid') : t('errorGeneric') + ': ' + message)
    } finally {
      setBusy(false)
    }
  }

  const clear = async (): Promise<void> => {
    setBusy(true)
    setError(null)
    setMessage(null)
    try {
      await set('')
      setValue('')
      setMessage(t('cleared'))
    } catch (reason) {
      setError(t('errorGeneric') + ': ' + String(reason instanceof Error ? reason.message : reason))
    } finally {
      setBusy(false)
    }
  }

  const current = value.trim() === '' ? t('currentUnset') : value

  return (
    <div className={css.section}>
      <h2 className={css.heading}>{t('title')}</h2>
      <p className={css.description}>{t('description')}</p>
      <p className={css.current}>
        {t('current')}: <span className={css.currentValue}>{current}</span>
      </p>
      <label className={css.label} htmlFor="workspace-default-dir-path">{t('inputLabel')}</label>
      <div className={css.row}>
        <input
          id="workspace-default-dir-path"
          className={css.input}
          value={value}
          onChange={(event) => { setValue(event.target.value); setMessage(null); setError(null) }}
          placeholder="E:\\python_project"
          disabled={busy}
        />
        <button type="button" className={`${css.button} ${css.save}`} onClick={() => void save()} disabled={busy}>
          {t('save')}
        </button>
        <button type="button" className={`${css.button} ${css.clear}`} onClick={() => void clear()} disabled={busy}>
          {t('clear')}
        </button>
      </div>
      <p className={css.hint}>{t('inputHint')}</p>
      {message !== null ? <p className={`${css.status} ${css.ok}`}>{message}</p> : null}
      {error !== null ? <p className={`${css.status} ${css.error}`}>{error}</p> : null}
      <p className={css.hint}>{t('restartHint')}</p>
    </div>
  )
}
