/**
 * Browser half of dsh-workspace-default-dir: registers the settings card as a
 * first-level settings section. Pure UI — all data flows through the host
 * /api/workspace-default-dir route (no settings domain, no shared state).
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the settings-surface SlotMap merge ('settings.section').
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import { WorkspaceDefaultDirSection, routeFace, type WorkspaceDefaultDirFace } from './Card.tsx'
import { en, zh, type WorkspaceDefaultDirKey } from './locales.ts'

/** Locale namespace this plugin owns. */
const NS = 'workspace-default-dir'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Workspace default directory card copy. */
    'workspace-default-dir': WorkspaceDefaultDirKey
  }
}

/** Required services. */
export const inject = ['slots', 'locale']

/** Type-only export (export discipline: no value exports beyond the plugin contract). */
export type { WorkspaceDefaultDirFace, WorkspaceDefaultDirSectionProps } from './Card.tsx'

/**
 * Mount the settings card.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'workspace-default-dir: dictionaries')

  const face: WorkspaceDefaultDirFace = routeFace()

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: NS,
    order: 140,
    label: () => ctx.locale.bind(NS)('title'),
    locale: NS,
    inject: () => face,
  }, WorkspaceDefaultDirSection))
}
