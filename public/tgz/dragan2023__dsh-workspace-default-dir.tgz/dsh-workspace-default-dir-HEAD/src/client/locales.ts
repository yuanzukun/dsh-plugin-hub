/** Locale copy for the workspace-default-dir settings card. zh is the key source, en mirrors it. */

export const zh = {
  title: '工作区默认目录',
  description: '「添加工作区」目录选择器默认打开的路径。保存后下次打开选择器即生效，无需重启。',
  current: '当前生效',
  currentUnset: '未设置（打开用户主目录）',
  inputLabel: '默认目录路径',
  inputHint: '例如 E:\\python_project。留空并保存表示清除设置。',
  save: '保存',
  clear: '清除',
  saved: '已保存',
  cleared: '已清除',
  errorInvalid: '目录不存在或不是绝对路径',
  errorGeneric: '保存失败',
  restartHint: '注：browse 选择器（局域网模式）的代码补丁在 dsh 重启后加载；原生对话框即时生效。',
}

export const en: typeof zh = {
  title: 'Workspace default directory',
  description: 'The directory the workspace directory picker ("Add workspace") opens at. Saved on the next picker open — no restart needed.',
  current: 'Currently active',
  currentUnset: 'unset (opens at user home)',
  inputLabel: 'Default directory path',
  inputHint: 'e.g. E:\\python_project. Save empty to clear.',
  save: 'Save',
  clear: 'Clear',
  saved: 'Saved',
  cleared: 'Cleared',
  errorInvalid: 'Directory does not exist or is not an absolute path',
  errorGeneric: 'Save failed',
  restartHint: 'Note: the browse picker (LAN mode) loads its patched module after a dsh restart; the native dialog applies immediately.',
}

/** Locale key union. */
export type WorkspaceDefaultDirKey = keyof typeof zh
