# dsh-sciwork 架构

面向想给这个插件**写代码**或**改它**的人。读完你应该能回答：它由哪几块组成、数据往哪儿落、
哪些写动作被允许、为什么某些细节必须那样写。

- 包名 `dsh-sciwork`，版本 0.3.0，MIT，仓库 <https://github.com/58catmiao/dsh-sciwork>，作者 58catmiao。
- 安装：`dsh plugin --profile <profile> add dsh-sciwork`
- 安装与配置的动手步骤见 [INSTALL.md](./INSTALL.md)；本文件只讲结构、契约与取舍。

## 1. 它是什么

给 DSH 加一个**科研模式**：在 Origin 里把数据变成能投出去的图，以及一整套论文写作流程
（中译英、润色、看图写图注与 Results、结构与 Discussion、文献检索引用、回复审稿意见）。
两件事都围绕一个**实体科研库**工作，图和文献的可核查性都落在库里。

交付形态由三部分组成：

| 组成 | 内容 |
|---|---|
| agent preset | 「科研模式 · Research」，由 `cordis.patch.yml` 插入 profile 的 loader roster |
| 技能 | `skills/` 下 5 个：`research-studio`（总控与路由）、`origin-plot`、`paper-writing`、`literature-refs`、`journal-profile` |
| 「科研库」面板 | 宿主半边 `lib/*.js` + 客户端半边 `lib/client.js`，读写科研库 |

面板是**辅助视图**：它让用户自己看库、整理库、导入/归档/删除；**出图与改图一律由智能体走 Origin**（`origin-plot` 技能 + Origin MCP）。
面板自 2026-10-13 起不再自己出图，0.3.2 起连图卡上的「重画」也一并移除，见 §11。

## 2. 仓库结构

```
dsh-sciwork/
├─ package.json           # dsh.bundle.patch → cordis.patch.yml；dsh.client.platform = "web"
├─ cordis.patch.yml       # 插入 preset「科研模式 · Research」+ 面板宿主插件行 research-library
├─ lib/                   # 宿主半边（纯 Node ESM，零第三方依赖） + 客户端半边
│  ├─ index.js            #   connection.fetch 精确路由：POST /api/research/call + 挂宿主工具
│  ├─ actions.js          #   薄适配层：24 个旧动作名 → 执行器；命令台命令表
│  ├─ host/               #   0.3 能力层：errors / registry / guards / dispatch / receipts /
│  │                      #   engine / cli（与具体科研库无关的通用机制）
│  ├─ actions/            #   0.3 动作实现，按域分文件：library / draft / data / figure / refs /
│  │                      #   journal / project / system / action
│  ├─ adapters/python.js  #   research.py 契约 v1（子命令映射、参数拼装、超时覆盖）
│  ├─ projects.js         #   课题模型：七阶段机、产物 sha256、检查项、nextStep、原子写
│  ├─ migrate.js          #   旧库 → 0.3 形状：plan（只读）/ apply（备份 + 幂等 + 单课题回滚）
│  ├─ backup.js           #   库备份 zip + manifest 逐文件 sha256 + 恢复核对
│  ├─ tools.js            #   tool.expose 的动作 → sciwork_* 宿主工具（schema 窄化）
│  ├─ config.js           #   运行时路径解析（库根 / Python / Origin 插件目录），不写死本机路径
│  ├─ library.js          #   读库底座：路径闸门、快照、引用核查、草稿保存/新建
│  ├─ import.js           #   导入：落位（同名自动 -1）→ 需要时再跑 research.py 登记
│  ├─ archive.js          #   归档 / 恢复 / 真删
│  ├─ refmeta.js          #   CrossRef 抓元数据（只在用户点「抓取」时联网，不写文件）
│  ├─ table.js            #   读表 parseTable(text)
│  ├─ transform.js        #   数据变换算子（面板内计算，不经 Origin）
│  └─ client.js           #   浏览器半边：侧栏图标 + 中央页面（含新手引导），手写、无构建
├─ skills/                # 5 个技能，install.mjs 装到技能根
├─ library/               # 科研库骨架模板 + config.json + py.cmd + research.py + 12 份期刊档案
├─ scripts/               # 安装器、补丁预检、桌面体检、自检与门禁（cycle.mjs）
├─ docs/                  # 本文件与安装文档
└─ README.md
```

宿主半边 `lib/*.js` 是**零第三方依赖**的纯 Node ESM：只 import `node:fs` / `node:path` / `node:os` /
`node:child_process` / `node:url`，没有 `dependencies`。客户端 `lib/client.js` **手写**（等价于已构建产物），
**没有构建步骤**——改完刷新页面即可，不需要跑打包器。

## 3. 半边划分与生效时机

| 半边 | 文件 | 改完怎么生效 |
|---|---|---|
| 宿主 | `lib/*.js`、`package.json`、`cordis.patch.yml` | **必须重启 Harness** |
| 客户端 | `lib/client.js` | 刷新页面即可 |

宿主半边在 **Harness 启动时读进内存**，所以只刷新页面会变成「新按钮 + 旧宿主」：面板发了新动作名，
宿主只回一句 `未知动作：archive`。客户端的 `withHostHint()` 会把这句话补成「要重启 Harness」，别当没反应。

补丁同理：`cordis.patch.yml` 只在启动时被读，`broken` 状态也是激活那一刻写进记录的。
**重启并回读之前，只能报告「已写入」，不能说「已生效」。**

## 4. 面板接口契约

### 4.1 唯一端点

```
POST /api/research/call
```

端点在 `lib/index.js` 里由两个导出定义：`ENDPOINT = 'research/call'`、`ROUTE_PATH = '/api/' + ENDPOINT`。
客户端必须用同一个字符串。

### 4.2 Connection 信封

与 Connection 的 `rpcFetchHandler` 对齐（同一个包内的非导出函数，因此这里等价复刻）：

```jsonc
// 请求
{ "type": "client-request", "rpcId": "<id>", "method": "research/call", "payload": { "action": "...", "args": { } } }

// 成功
{ "type": "server-response", "rpcId": "<id>", "result": { "ok": true, "value": { } } }

// 失败
{ "type": "server-response", "rpcId": "<id>", "result": { "ok": false, "error": { "code": "...", "message": "...", "details": { } } } }
```

宿主的处理规则（`lib/index.js` 的 `envelopeResult()`）：

- body 不是 `client-request` → `gateway/bad-request`，消息 `invalid client-request message`；
- `body.method` 与端点不一致 → `gateway/bad-request`，消息 `method "<x>" does not match endpoint "research/call"`；
- `handleResearchCall` 自身抛错 → 包成 `internal` 错误信封，**不返回 500**（面板要看得见缺陷，而不是拿到一个 HTML 错误页）。

### 4.3 客户端怎么发

```js
ctx.get('connection').rpc.call('/api', 'research/call', { action, args })
```

`ClientConnectionRpc.call(channel, endpoint, payload, signal?)` 返回信封里的 `result` 原样，即
`{ok:true,value}` 或 `{ok:false,error}`。

### 4.4 错误码

面板认识并可分支处理的码（`lib/actions.js` 的 `KNOWN_CODES`）：

`bad-request` · `not-found` · `denied` · `busy` · `timeout` · `network` · `internal` · `cli-failed`

`describe(error)` 会把底层异常归一到这些码上（例如含 `ENOENT` 或「课题不存在」→ `not-found`；
含「锁 / lock / 正在出图」→ `busy`）。未知码不会让面板崩，只会显示原文。

## 5. 路径安全与写入边界

### 5.1 一切 path 都是库根相对路径

面板传的每一个 path 都按**库根相对路径**解释。`library.js:resolveInside()` 是最后一道闸门：
拒绝对路径、盘符、`..` 逃逸。任何绕不过它的路径都不可能被读到或写到库外。

### 5.2 可写目录与不可写文件

| 边界 | 取值 | 位置 |
|---|---|---|
| 面板可写目录白名单 | `projects/` · `refs/pdf/` · `submissions/` | `lib/archive.js:ALLOW_PREFIX` |
| 可就地编辑的正文 | `projects/<课题>/drafts/*.md\|.markdown\|.txt`（且必须已存在） | `lib/library.js:EDITABLE_RE` |
| 永远不可写 | `refs.json` · `project.json` · `config.json` · `_index.json` · `refs.bib` · `library.json` | `lib/library.js:NEVER_EDIT` |

**登记元数据永远不从面板改。** 要动文献登记只有一条合法路径：库脚本 `research.py remove-ref`
（脚本自己先备份 `refs.json`，再同步 `refs.bib`）；面板只负责把 key 传过去。
`refs.bib` 是派生物，手改没有意义。

### 5.3 导入

- **只复制，不移动**；同名**绝不覆盖**，自动 `a.csv` → `a-1.csv` → `a-2.csv`。
- 扩展名按目标白名单（`lib/import.js:ACCEPT`）：

  | 目标 | 允许的扩展名 |
  |---|---|
  | `data` | `.csv` `.tsv` `.txt` `.xlsx` `.xls` `.dat` `.json` `.jdx` `.dx` |
  | `figures` | `.png` `.jpg` `.jpeg` `.webp` `.svg` `.tif` `.tiff` `.pdf` `.eps` |
  | `drafts` | `.md` `.markdown` `.txt` |
  | `refs` | `.pdf` `.docx` `.doc` `.txt` `.md` `.ris` `.bib` `.enw` |
  | `project` / `submission` | 不接文件 |

- 大小上限：单文件 **32 MiB**，单批 **64 MiB**（`lib/import.js:LIMITS`）。
  更大的文件不走浏览器：弹层里填**本机绝对路径**，由宿主直接读盘（仍然只复制）。
- 文件名先过 `sanitizeName()`：取 basename、剥控制字符、替换 Windows 非法字符、去前导点、截到 120 字符。

### 5.4 子目录（可选）

只有 `data` / `figures` / `drafts` 三个目标支持（`lib/import.js:SUBDIR_TARGETS`）；
`refs` / `project` / `submission` 填了会**明确拒绝**并回 `bad-request`，**不静默忽略**。

规则：相对路径、最多 **3 层**（`MAX_SUBDIR_DEPTH = 3`）、不能写盘符、不能有 `.` / `..`、
每段 ≤60 字符、非法字符拒绝（`sanitizeSubdir()`）。落点再做一次 `path.relative(baseAbs, dirAbs)` 检查，
保证子目录怎么填都不越出这一类目录。

`importInfo` 会把 `subdirTargets` 与 `subdirMaxDepth` 一并返回，面板据此只在这三个目标上显示输入框。

> **一条设计教训（留作护栏）**：子目录归属**不能从路径倒推**。早期实现按目录名后缀判断导入目标，
> 于是子目录恰好叫 `refs/pdf` 时 `.csv` 会被误判成文献而拒收。现在由调用方按**导入目标**显式传
> `ACCEPT[target]`，不再猜。

### 5.5 读库是递归的

`lib/library.js` 的 `walkFiles()` 返回 `{abs, sub}`、`listSubdirs()` 列子目录，`MAX_SCAN_DEPTH = 4`；
`data/` `figures/` `drafts/` `tables/` 递归扫描，`opju/` 与 `origin/` 深 2 层；跳过以 `.` 开头的目录与文件。
`snapshot.projects[].folders` 给出每一类目录下的子文件夹（**含空文件夹**，面板显示成「（空）」而不是隐藏），
每个数据/图/草稿/表格条目带 `sub`（相对起点目录的 POSIX 子路径，根下直接放的是 `''`）。

### 5.6 改稿、归档、真删

- **改稿先备份**：`writeTextBackup()` 先 `copyFile` 出 `<文件名>.bak` 再写，回执里带 `beforeBytes`。
- **归档优先**：移到 `<库根>/.research/archive/<时间戳>/`，附 `manifest.json`；可整批或逐条 `restore`。
- **真删要输文件名**：一次一条，`confirm` 必须**逐字等于** `basename`；删前留 `<库根>/.research/_removed/<stamp>.json` 记录；
  **不进系统回收站**。
- 两者随后各跑一次 `reindex`；**索引重建失败不算动作失败**，回执里如实写进 `warnings`。
- **归档/真删只动磁盘文件，不动登记元数据**：删掉 PDF 后文献条目仍在 `refs.json` 里。面板在归档页把这件事写明，不假装删干净了。

### 5.7 快照与预览的上限

- `readText` 是**预览**通道：512 KB 上限并返回对象，数据表请走数据变换那条路（宿主自己读盘）。
- `readBinary` 上限 12 MiB（base64 走 JSON-RPC，别把宿主撑爆）；表预览上限 64 MiB。
- 数据 > 64 MiB 时明确报错，提示让智能体走 Origin 或分块，而不是静默截断。

## 6. 24 个宿主动作

`lib/actions.js` 的 `ACTIONS` 是权威清单，客户端与服务端必须逐项一致（自检会比对）。

**读**（不改库）

| 动作 | 作用 |
|---|---|
| `snapshot` | 库快照：课题、图、草稿、文献、数据、表格、投稿、期刊档案、归档批次 + `folders` / `sub` |
| `readText` | 文本预览（512 KB 上限） |
| `readBinary` | 二进制读盘（图片/PDF → base64，12 MiB 上限） |
| `tableColumns` | 一张数据表的列名 |
| `checkCitations` | 引用核查：缺失键 + 库里已知文献数（带「不证明内容支持」的说明） |
| `checkJournal` | 期刊合规体检：按档案逐条比对图件/字数/参考文献（见 §6.3） |
| `cliHint` | 一条给智能体的 `research.py` 命令模板（面板只展示，不执行） |
| `cliCommands` | 命令台的命令与参数元数据 |
| `transformOps` | 可用的数据变换算子与参数 |
| `tablePreview` | 表格预览（与 `parseTable` 同一套规则） |
| `importInfo` | 导入目标的扩展名白名单 + `subdirTargets` / `subdirMaxDepth` |

**写**（全部复用 `research.py` 或库内校验，面板不自己拼命令、不开第二条写入路径）

| 动作 | 作用 |
|---|---|
| `import` | 落位（同名 `-1`）→ 需要时跑 `add-ref` / `register-figure` / `new-project` / `add-submission` 登记 |
| `writeText` | 改草稿正文（写前 `.bak`） |
| `newDraft` | 新建草稿（只允许 `projects/<课题>/drafts/`） |
| `archive` | 归档到 `.research/archive/<时间戳>/` |
| `restore` | 整批或逐条恢复归档 |
| `remove` | 真删（`confirm` 逐字等于文件名，一次一条） |
| `removeRef` | 删文献登记 → `research.py remove-ref`（脚本自己备份 `refs.json` 并同步 `refs.bib`） |
| `fetchRefMeta` | 抓 CrossRef 元数据（**只在用户点「抓取」时才联网**，不写文件） |
| `runCli` | 命令台跑一条 `research.py` 子命令（危险命令需显式确认） |
| `tableTransform` | 数据变换（见 §6.1），产物落 `projects/<课题>/tables/` |
| `archiveInfo` | 归档批次与真删记录 |
| `exportPackage` | 打投稿包到 `submissions/packages/`（稿件 + 图 + 数据 + refs.bib + manifest，见 §6.3） |

### 6.1 数据变换

`lib/transform.js` 的 `TRANSFORM_OPS`，6 个算子：`normalize`（min–max / z-score / ÷最大值）、
`baseline`（减全局最小 / 两端线性基线）、`smooth`（滑动平均 / 滑动中值）、`peaks`（最小间距 + 最小相对峰高）、
`integrate`（梯形法，按连续段分开积，缺口不估算）、`linear`（`a*x+b`）。
**原始数据只读**：产物是新表，落在 `projects/<课题>/tables/`，参数与溯源记进
`<库根>/.research/transforms/<课题>/<名字>.json`。纯宿主计算，**不需要开 Origin**。

### 6.2 读表规则

`lib/table.js` 的 `parseTable(text)`：

- 首行含非数字单元格 → 当真表头；
- **没有表头**（真实仪器导出常这样，第一行就是数字）→ 按列序给通用列名 `#1` `#2` …，**首行算数据**；
- `NaN` / `NA` / `null` / `-` 与空单元格读成缺失（`null`），**不填充**。

面板的列下拉、`tablePreview`、`tableTransform` 共用这一套规则。

### 6.3 投稿闸门（0.2）

`checkJournal` 与 `exportPackage` 都只是 `research.py` 对应子命令的薄包装；判定逻辑、媒体元数据解析、zip 组装全在 `library/scripts/research.py`（`check_journal()` / `cmd_export_package()`）。

**`checkJournal` 回执**

```json
{ "ok": true, "project": "zt-ceremic", "journal": "nature", "journalName": "Nature",
  "manuscript": "projects/zt-ceremic/drafts/main.md",
  "checks": [{ "id": "figure.fig1.width", "group": "图件", "status": "pass",
               "detail": "图宽 89.0 mm（单栏 89 mm）", "source": "https://...", "confidence": "high" }],
  "counts": { "pass": 8, "warn": 4, "fail": 0, "na": 3 },
  "summary": "15 项：8 通过 / 4 提醒 / 0 不合格 / 3 不适用",
  "disclaimer": "期刊档案是默认值…以刊方现行要求为准" }
```

- 每个条目必带 `id` / `group` / `status` / `detail`；`status ∈ pass|warn|fail|na`。
- **档案里没有的数值一律 `na`**（例如未给字号上下限时字号项记 `na`），绝不拿通用默认值冒充期刊要求；结论会带上 `source` / `confidence` 与一句「以刊方现行要求为准」。
- 有 `fail` 时 `research.py` 退出码 1；面板仍显示完整表格，不中断。
- 图件尺寸/像素密度直接读文件头（PNG `pHYs`、JPEG JFIF、TIFF 标签、SVG 宽高/单位），不靠扩展名猜；数据变换或 Origin 导出留下的图注、journal 字段取自侧车 JSON。

**`exportPackage` 回执与产物**

```json
{ "ok": true, "package": "submissions/packages/zt-ceremic-20261019-140436.zip",
  "files": 7, "bytes": 3513, "missing": [], "counts": { "pass": 8, "warn": 4, "fail": 0, "na": 3 } }
```

- zip 内固定四个目录：`manuscript/`、`figures/`、`data/`、`refs.bib`，另有根级 `manifest.json`（逐文件 `sha256` / `bytes`）与 `checklist.md`（期刊 checklist + 本次体检结论）。
- 稿件按 `.md` → `.docx` → `.tex` 优先级挑一份；图件从图的侧车与磁盘收集；数据只收 `data/` 下文件；**缺什么写进 `missing`，不伪造空文件**。
- 打包纯标准库（`zipfile`），输出目录固定在 `submissions/packages/`，同名追加时间戳，绝不覆盖已有包。

## 7. 面板与 Origin 的边界（0.3.2 起）

- 面板**不再重画图**：`lib/replot.js`、`replot` 动作、锁文件 `.research/locks/origin.lock` 一并删除；
  图卡上只剩 看图 / 归档 / 删除 / 看侧车 JSON。
- 出图与改图统一由智能体走 `origin-plot` 技能 + Origin MCP；面板不启动、不访问、也不关闭任何 Origin 进程。
- 历史实现（venv 解释器 + `origin_mcp_server.py` + stdio JSON-RPC、锁 15 分钟过期、只新增不覆盖）留在 git 历史里，
  最后一个带它的版本是 `v0.3.1`。

## 8. 科研库工具链

`research.py`（随包模板在 `library/scripts/research.py`，安装后落在 `<库根>/.research/scripts/`）是**唯一的库写入口**：
纯标准库，16 个子命令。

| 子命令 | 作用 |
|---|---|
| `init` | 建/修复库骨架（幂等） |
| `status` | 库概况：课题数、文献数、已登记图数、期刊档案 |
| `new-project <slug> --title T --journal J` | 新建课题（建齐 data/figures/origin/drafts/notes/tables） |
| `list-projects` | 列课题（含每课题的图与稿） |
| `add-ref ...` | 文献入库（分配引用键 + 更新 `refs.bib`）；**无 DOI 且无 URL 会被拒，`exit 2`** |
| `list-refs [--project P] [--query Q]` | 列/搜文献 |
| `remove-ref (--key K \| --doi D)` | 删一条文献（删前备份 `refs.json`，并报出还在引用它的草稿） |
| `export-bib` | 重建 `refs.bib` |
| `add-submission ...` | 登记一次投稿（`--type` 是固定枚举） |
| `list-submissions` | 列/筛投稿记录 |
| `update-submission ...` | 更新投稿状态 / 记事件 / 改下一步 |
| `register-figure ...` | 登记一张图的溯源侧车 |
| `list-figures [--project P]` | 列已登记图 |
| `search <关键词> [--kind K]` | 跨课题检索（课题/图/稿/数据/文献/期刊/投稿） |
| `reindex` | 重建索引 |
| `check-citations --draft <路径> [--require-doi]` | **引用核查闸门** |

`research.py --help` 才是权威清单；参数名以它为准。

**引用闸门（硬约束）**：交稿前 `check-citations` 必须 `exit 0`。正文里出现未登记的引用键 → `exit 1` 并列出 `unknown`；
代码块与行内反引号里的 `[@key]` 被正确排除。脚本输出自带 `caveat` 字段——
**它只证明「引用键在库里、且该条带 DOI 或 URL」，不证明被引文献的内容真的支持那句话。**
转述时照实说。

**真源与所有权**：

- 文献真源是 `refs/refs.json`；`refs.bib` 是派生物，**不要手改**。
- 索引 `<库根>/.research/index/library.json` 由 `reindex` 重建；索引不是真源，真源是各条目自己的文件。
- 库文件由本插件接管：写入走 `research.py`，不手写库里的 JSON。

## 9. 自检与验证

三条自检都能**裸 node 复跑**，不需要装依赖：

```bash
node scripts/selftest-host.mjs      # 宿主数据层：路径闸门、快照、读文件
node scripts/selftest-actions.mjs   # 23 个动作 + 命令台 + 读表 + 写动作真跑（在临时库副本上）
node scripts/selftest-client.mjs    # 把 lib/client.js 当浏览器加载：真渲染 + 真点击
```

当前基线（2026-10-13 实测复跑）：

| 脚本 | 基线 |
|---|---|
| `scripts/selftest-host.mjs` | `exit 0` |
| `scripts/selftest-actions.mjs` | **141 通过 · 0 失败 · 1 跳过（夹具库；通过数随库内容浮动） · exit 0** |
| `scripts/selftest-client.mjs` | **172 通过 · 0 失败 · exit 0** |

要点：

- **两条基线都会随真库内容浮动。** 真库里没有对应样本时，相关断言打 `SKIP` 而不是假失败
  （`SKIP` = 没有草稿样本 / 没有存在的图文件样本）。
  数字变了先看 `SKIP` 条数与原因，别当成回归。
- 写动作**真跑**，但只跑在 `os.tmpdir()` 的**库副本**上；硬闸门 `snapshot.root === 副本` 不过就 `exit 2`，
  一个字节都不写。样本先种进副本，所以真库被清空也能跑。
- 客户端自检写动作全部用假信封挡住；并含**反向断言**（面板没有「重画」按钮）
  （数据页没有「出图」按钮、没有成组选择、头部没有「目标图对齐」；CSS 只出现官方 token）。

> **为什么必须有渲染自检**：这套自检抓到过三个只看代码看不出来的真 bug——
> 组件漏了第二个形参导致所有按钮标签被静默丢掉；把带 hook 的组件当普通函数直接调用导致 hook 顺序违规；
> 核查结果块在折叠分支里而按钮在卡头，折叠时点了什么都看不见。
> 写 Web 面板必须有一个「真渲染 + 真点击」的自检。

## 10. 已知限制与上游瑕疵

- **heatmap 不支持**（Origin 插件 `plotm` 不可用），改用 `contour_fill`。
- **`.otpu` 样式保存通道不可用**（`save -i/-t/-it` 静默不落盘），课题组样式以 **JSON 样式快照**侧车代替。
- `origin_plot_plan` 的 `plan_id` 存在服务端内存里，**重启即失效**。
- 首次 `origin_status` 会自动启动 Origin，需要 **5~45 秒**；页面很多时 `list_pages` 约 31 秒、
  单次 `close` 可达 59 秒，逼近 90 秒看门狗 —— 页多时先 `origin_pages_gc` 的 `dry_run` 报告，不要擅自清理。
- Origin 插件自述 28 或 62 个工具，**实测 74** 个；以实测工具表（`skills/origin-plot/references/origin-tools.json`）为准。
- `origin_figure` 的 `detail` 文案可能写 `proof_level=verified`，而同一次返回的字段是 `"unverified"`
  （此时 `verify.passed=true`、`n_fail=0`）。口径：**以 `verify.passed` + `verify.checks` 为准**，
  `proof_level` 当「样式读回等级」看。
- 传 `data_source`（文件路径分支）时 `graph_name` 参数**未被采用**；一律用**返回的 `graph` 字段**。
- `origin_simulate` 的结果强制带 `simulated: true`，写进稿子时必须标注为模拟，不得当实验数据。
- 期刊档案是**默认值**，不是刊方现行要求的权威副本：用户现场要求 > 期刊档案 > 通用默认。
  每份档案带 `sources` / `verifiedAt` / `confidence`，`confidence` 为 low 的字段留 `null`，**不猜数字**。

## 11. 主要设计决策

| 决策 | 为什么 |
|---|---|
| 用**精确 Fetch 路由** `connection.fetch.register({ path:'/api/research/call', methods:['POST'], requestBody:'buffered', fetch })`，而不是 `intercept('/api', …)` | 共享 RPC 通道**只允许一个拦截器**，官方 `api-gateway` 已占用。抢注成功后官方端点（`settings/describe`、`credentials/describe`、`agentPresets/list` …）全部落进 `!interceptor.matches(endpoint)` 的 404 分支，桌面欢迎流程失败会触发原生恢复对话框并改写 profile。精确路由在 `createSharedFetchHandler` 里**优先于**拦截器匹配，因此在 `/api` 前缀之下与 api-gateway 完全共存，还自动继承 Host/Origin 信任栅栏、浏览器会话认证与请求体上限。 |
| 宿主半边注册失败时**吞掉异常只记 error 日志** | 面板是辅助视图，不许因为一个注册冲突把**同一份补丁里的 preset** 也拖成激活失败。 |
| 面板**不自己做鉴权** | 它走 Harness 自己的 `/api` 通道，继承宿主侧 Host/Origin 栅栏 + 浏览器会话 cookie；不自己注册 HTTP 路由。 |
| 客户端**手写、无构建步骤** | 免掉打包器与产物同步问题；`lib/client.js` 就是一段 `window.__ModuleLoader__.load({id, factory})`，与在用 bundle 同构。客户端模块 `id` 用**包名**。 |
| `factory` 只收 `require` | 平台 seed 表里才有 React，只能 `require('react')` / `require('react-dom')`；其他服务一律 `ctx.get(name)` 惰性取。 |
| 两个挂点**同名** | `sidebar.panellist` 注册 `{id, order, label}`，`main` 注册 `{name, key}` —— **侧栏 id 必须与 main key 同名**，否则点了图标出不来页面。 |
| 只用官方设计 token | 渲染只许用 `Theme.listTokens` 那 14 个 `--dsw-*` token；不写自定义色值。 |
| 面板**不出图、也不重画** | 2026-10-13 起「直接出图 / 成组出图 / 目标图对齐」三个入口整体移除；0.3.2 按用户要求再删 `lib/replot.js`、`replot` 动作与图卡上的「重画」表单（连自动登记一起删）。面板只负责看、整理、归档/删除；出图与改图一律让智能体走 Origin（真 Origin、带 `verify` 与 `.json` 溯源）。读表规则与「变换」保留。 |
| 大文件走**本机绝对路径** | base64 走 JSON-RPC 有体积上限；让宿主直接读盘（只复制、不移动）比把几百 MB 塞进信封可靠。 |
| 登记索引**面板只读** | 索引与登记记录一旦能被就地编辑，引用可核查性就没了；所有元数据变更收敛到 `research.py` 一条路径。 |
| 三条硬约束 | 引用零编造可溯源（无 DOI/URL 不入库 + `check-citations` 闸门）、绝不抢占或强杀用户正在使用的 Origin、图 + 数据 + 参数可回溯（每张交付图有 `figures/<figN>.json` 侧车）。 |

## 12. 改这个仓库的注意事项

- **补丁条目只写 config**，不要再加 `name` / `insert`（会 duplicate loader entry id 导致启动失败）。
- **预设里每一行都要按「宿主会做 schema 校验」对待**：`cordis:group` 的子行不是黑盒，缺一个必填字段
  整条 preset 就变「（加载失败）」，而**顶层行校验查不出来**。改完必须跑补丁预检脚本。
- 新增插件行前，先拿 DSH 自带的**同构** profile / preset 逐字对照 config，再照抄，别凭印象写 config 键。
- 装技能时只动本包的 5 个技能目录，**不覆盖别人的技能目录**。
- 期刊档案与库数据**只追加与修正，不静默覆盖**；改动要写清「旧值 → 新值 + 依据」。
- 改 `lib/*.js`（宿主半边）**必须重启 Harness**；`lib/library.js`（递归扫描 / `folders` / `sub`）与
  `lib/import.js`（`args.subdir`）同样。改读库路径的代码时**先想清楚它在哪半边**。

## 13. 0.3 · 能力层与课题模型

0.2 的面板是一张 `switch(action)` 长表；0.3 把它拆成**一条能力清单 + 两块屏幕**。旧面板与旧动作名
原样保留，新能力从同一条执行器进出，所以「面板能做的」与「agent 能做的」不再各写一份。

### 13.1 动作登记表（`lib/host/registry.js`）

每个动作是一个普通对象：`id`（`domain.verb`）、`title`、`domain`、`params`（JSON Schema 子集）、
`effects`（`read` / `write` / `external`）、`engine`（`node` / `python` / `origin` / `system`）、
`confirm`（`never` / `write` / `always` / `legacy`）、`run(ctx, params)`，可选 `preview`、
`idempotent`、`ui`、`tool.expose`。

登记时全量校验，**先校验完再一起注册**：重复 `id` / 工具名 / 别名、读动作声明 `confirm` 非 `never`、
写动作 `confirm: never` 却没有 `idempotent: true`，都会在启动期就报错，而不是等用户点到才炸。
参数校验支持 `type` / `required` / `enum` / `default` / `minimum` / `maximum` / `minLength` /
`maxLength` / `pattern` / `items` / `additionalProperties`；字符串数字会窄化成数字。
**未声明键在 `additionalProperties !== false` 时原样透传**——`data.import` 的 `target` / `subdir` / `meta`
靠这条活。

### 13.2 执行器与确认令牌（`dispatch.js` / `guards.js`）

一次写动作是三步，而不是一次调用：

1. `action.plan` → 校验参数、跑可选 `preview`（会给 diff / writes / warnings），签发
   `{planId, token, paramsHash, expiresAt}`，**5 分钟有效**；
2. 用户确认（面板弹框 / agent 说明）；
3. `action.confirm`（或带 `planId + confirmToken` 直接调）→ 执行器核对
   **令牌哈希、动作 id、参数哈希、库根**，然后**先删计划再执行**（一次性，失败也不可复用）。

只带动作不带令牌 → `needs-confirmation`（这是正常的第一步，不是拒绝）；令牌错 / 过期 / 参数被改 /
跨库根 → `denied`。旧动作名（`remove` / `import` / `runCli` …）声明 `confirm: 'legacy'`：**同请求内
代签并立即消费令牌**，回执记 `confirmation: 'legacy-implicit'` 并附一条 warning。这就是「旧面板零改动」
与「写动作必须过令牌闸门」同时成立的办法。

写动作默认带幂等键（动作 + 参数 + 库根，10 分钟窗口）：网络重试撞上同一次调用时回放上次回执，
回执上标 `replayed: true`，不会把同一份文件写两遍。

### 13.3 回执（`lib/host/receipts.js`）

每次**写 / 外部**动作（成功或失败）都追加一行到 `<库根>/.research/receipts/<YYYY-MM>.jsonl`；读动作不留（面板每次刷新都会读，留了日志会被读操作淹掉，也让一次纯浏览改写库里的文件）：
`receiptId`（`r_<日期>_<hex>`）、动作、旧名、来源（panel / agent / cli）、参数哈希、确认方式、
耗时、写了哪些文件、warning、摘要、错误码。回执是「这次到底对库做了什么」的唯一权威记录；
`system.receipts` 读最近 N 条，`workflow.context` 只取最近 5 条。

### 13.4 课题是一等公民（`lib/projects.js`）

`projects/<slug>/project.json`（`schemaVersion: 1`）记阶段、产物与历史。七个阶段：
`topic → design → data → analysis → figure → draft → submission`，状态
`pending / active / done / skipped`，**同一时刻只有一个 active**。`project.stage.set` 只允许
前进/后退一步；跳阶段必须 `force` 并留下 warning。产物登记 `{kind, path, bytes, sha256, producedBy}`；
`project.get` 会把磁盘上有、登记表里没有的文件补进来（导入后忘登记也能看见）。

**双读**：有 `project.json` 就按 0.3 形状读；没有（或还是旧形状）就从目录合成只读视图，
并标 `legacyShape: true`。写动作遇到这种课题直接 `needs-migration`，**不会偷偷补写** project.json。

### 13.5 迁移与备份（`migrate.js` / `backup.js`）

`system.migrate` 分两步：`--plan` 只读列出「哪些课题要升级、会写哪些文件」；`--apply`
先建库备份（zip + manifest），再逐课题迁移，每个课题独立 try/catch，失败就把该课题回滚到迁移前，
并把这一轮写进 `.research/migration.json`。迁移**幂等**：已经 0.3 形状的课题跳过并计数。

`backup.js` 打的是「文件 + 逐文件 sha256」的 zip（不受 git 影响），恢复时先恢复空目录再按 manifest
逐文件核对，并明确报告 `byteIdentical`。演练规则：**迁移先跑副本，副本核对通过才动真库**。

### 13.6 宿主工具（`lib/tools.js`）

`tool.expose: true` 的动作注册成 `sciwork_<domain>_<verb>`（名字在动作里显式写死，不靠拼接猜）。
schema 会被窄化成 DSH 支持的子集（联合类型取第一个非 null、去掉 `minLength` / `maximum` / `format` 等
宿主不认的键）。读动作直接执行；写动作的工具说明里固定写「先 `sciwork_action_plan`，再
`sciwork_action_confirm``。返回 `{ok, value, receipt}`，失败抛 `Error` 并把 `code` / `details` 挂上去。

另有三个 meta 工具：`sciwork_action_catalog`（动作清单）、`sciwork_action_plan`、`sciwork_action_confirm`，
以及 `sciwork_workflow_context`（当前课题 + 阶段 + 待办 + 最近 5 条回执，**硬上限 4 KB**）。

### 13.7 两块屏幕（`ui.version`）

面板保留 v1（七个 tab 的旧界面），v2 是「工作台」，**0.3.6 起为默认**：今日 / 课题 / 库 / 数据 / 文献 / 设置。
开关是客户端 `localStorage['ui.version']`（新会话没有值 → `v2`；切过 `v1` 就记住）；切换是页签行右侧的一组分段按钮（「面板 | 工作台」），切到 v2 再切回来会回到上次停留的页签。
随时可切回。v2 的每一个写按钮都走「计划 → 弹框（列出会写的文件与 warning）→ 确认 → 回执 id」。

v2 的排版是**页头 + 分区**，不是平铺卡片（0.3.6，用户要求对齐 StudyHub 的秩序感；0.4.0 去 AI 味时把「概览」仪表整块删掉）：
页头（标题「科研库」+ 一行计数 + 中文主入口「快速登记 / 新建课题 / 导入数据」+ 纯文字「刷新 / 检查更新」）→ 「跨课题待办」表格（表头 + 行 + 行内操作；开放投稿的截止日也排进这张表，按到期日靠前）→ 课题两栏（左列表 / 右阶段条、产物速览、待办与阻塞、这个课题的近期变动）→ 页脚（最近回执 + 上次备份 / 库级提示 / 版本行）。
样式类：`rl-page__head` / `rl-section` / `rl-table` / `rl-wb__grid`，都由现有 DSH token 组合，不引第三方样式。窄屏（≤860px）下待办行降级成两列卡片、课题两栏收成一列。

**色板（0.3.7 起自带，0.4.0 换成对照宿主的灰阶）**：面板不引用宿主 `--dsw-alias-*` 颜色 token，自己定义一套 module 色。
`.rl-root` 定义 12 个变量 —— `--rl-bg / surf / surf2 / bd / bd2 / tx / mu / ac / ink / ok / warn / err`，
每个变量都写成 `--rl-k:#rrggbb` + `--rl-k:light-dark(#rrggbb,#rrggbb)` 两条（门禁只认这个形状：不许 rgba、不许三位 hex），
宿主切换明暗时由 CSS 自动取值；0.4.0 的取值来自宿主 neutral-bluish 阶、强调色只有一个蓝；
尺寸与动效另有 `--rl-s1…s8`（间距）、`--rl-r1…r3`（圆角 6 / 8 / 12）、`--rl-f1…f3`（字号 12 / 14 / 16）、`--rl-ease / --rl-d1 / --rl-d2`，阴影只留给弹层。取舍理由：
宿主主题 token 在不同主题下对比度不稳定（旧版出现正文发灰、按钮文字与底色接近的问题），
自带色板可把对比度写进门禁；但「自己造形」也自己造出了 AI 味（米白底 + 琥珀色大数字），所以 0.4.0 起改成抄宿主的形。
`scripts/selftest-client.mjs` 第 [6] 节会解析 `lib/client.js` 里的十六进制值，
断言正文 / 次级 / 主色在明暗两套下都 ≥ 4.5:1，并禁止重新引入宿主颜色 token。

「快速登记」弹层（`QuickModal`）不手抄表单：打开时只读一次 `library.cli_commands`，按 `CLI_COMMANDS` 里的 `title / label / type / optionsCn` 生成中文表单（必填在上、其余折进「更多选项」），提交时打包成 `system.cli_run {id, values}` 走同一条计划 → 确认链路。
面板没有对话通道，因此「生成指令」只复制指令、不假装一键执行。
导入弹窗在 v2 下收敛成「选文件 → 去处自动猜 → 更多选项折叠」，页头导入按钮只在 v1 显示。

### 13.8 阶段与阶段技能

科研模式只有 `research` 一个预设。阶段是课题 `project.json` 的 `stage` 字段
（`topic → design → data → analysis → figure → draft → submission`），换阶段走 `project.stage.set`
（写动作，仍然是 plan → confirm）；人格与工具集在所有阶段保持一致。

阶段的纪律、推荐工具与退出检查项收在技能 `skills/research-stages/SKILL.md`，由 `scripts/install.mjs`
装到用户级技能根，agent 在开工或换阶段时按需加载，不占常态上下文。

> 历史：0.3.0 初版曾按阶段拆成 6 个轻量预设（`sci-topic` 等），2026-10-21 按用户要求合并回单一模式。
> 理由：换预设等于换执行环境，会话上下文与会话内技能加载都会重置，而阶段本来就是课题的一项状态；
> 另外 `agent-preset` 没有工具白名单字段，原方案里所谓「阶段工具范围」只是人格约束，拆预设换不来硬隔离。

## 附录 A · 库根与路径解析

`lib/config.js` 是唯一的路径解析层，**任何模块都不许再写死本机路径**。
库根解析优先级（越靠前越优先，全部可缺省）：

1. 库内配置：`<库根>/.research/config.json` 的 `libraryRoot`（已经在一个库里时，它说了算）
2. 环境变量：`SCIWORK_LIBRARY`（旧名 `RESEARCH_LIBRARY` 仍兼容）
3. 随包的安装期快照 `library/config.json`（本机运维覆盖，已 gitignore；只在没有环境变量时生效）
4. 按 DSH 既有约定推断（`DSH_HOME`、`DSH_PROFILE`、`DSH_PROFILE_DIR`、`node_modules` 布局）
5. 兜底默认：`<用户目录>/Research`

> 0.2.1 之前第 2、3 步是反的：`loadSettings()` 把随包快照当成 `resolveLibraryRoot()` 的「显式配置」，
> 而该函数是 `configured || env(...)`，于是本机一份指向真库的 `library/config.json` 会压过环境变量，
> 「把库指到别处」（自检隔离副本、换库位置）静默失效。现在由 `envLibraryRoot()` 先看环境变量。

其他路径类环境变量：`SCIWORK_PYTHON`、`SCIWORK_ORIGIN_PLUGIN`。

所有 `resolve*` 函数**都不抛异常**，找不到返回 `null`，由调用方决定怎么退化
（面板是辅助视图，路径缺失必须变成一句人话，而不是一次崩溃）。

Python 解释器候选顺序（`pythonCandidates()`，与库内启动器 `py.cmd` 一致）：
显式 `interpreter` → `SCIWORK_PYTHON` → `<库根>/.venv` → `<库根>/.research/.venv` → Origin 插件目录的 `.venv` → `PATH`。

## 附录 B · 权威配置

`<库根>/.research/config.json` 是权威配置（`library/config.json` 只是安装模板）。字段：

| 字段 | 含义 |
|---|---|
| `schema` | 配置版本 |
| `libraryRoot` | 库根（安装器会在与本次库根不一致时就地校正） |
| `interpreter` | Python 解释器绝对路径 |
| `launcher` | 启动器路径（Windows 上是 `.research/bin/py.cmd`） |
| `origin.pluginDir` / `origin.server` | 上游 Origin 插件目录与 MCP server 脚本 |
| `origin.mcpServerName` / `origin.toolPrefix` | MCP 服务名与工具前缀（`mcp__origin__`） |
| `origin.neverHijackRunningInstance` | 恒为 `true`：绝不抢占用户正在用的 Origin |
| `defaults` | 默认期刊 / 图格式 / dpi / 语言 |
| `index` | 索引文件路径 |

## 附录 C · 面板挂点与新手引导

- 挂点：`slots.inject('sidebar.panellist', …)` 注册 `{name:'sidebar.panellist', id:'research-library', order:42, label:'科研库'}`；
  `slots.inject('main', …)` 注册 `{name:'main', key:'research-library'}`。
- 客户端模块：`exports.inject = ['slots']`，`exports.apply = apply`。
- 引导状态存 `localStorage`，键前缀 `research-panel-setup:`（`welcome` / `tour` / `step`），
  所以「看过一次就不再自动弹」；想重看随时点标题右边的**「引导」**。

## 附录 D · 期刊档案

随包 12 份（`nature` / `science` / `cell` / `ieee-trans` / `elsevier-generic` / `acs` / `plos-one` /
`mdpi` / `gbt-7714` / `chinese-core-journal` / `cnki-thesis` / `thesis-generic`）+ `_index.json` + `README.md`，
每份带 `sources` / `verifiedAt` / `confidence`。安装器**只补缺失的、绝不覆盖已有的**
（档案里可能有人工校对过的字段）。抓取当日的 confidence 分布以 `<库根>/journals/_index.json` 为准。
