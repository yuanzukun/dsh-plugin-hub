/**
 * Git worktree selection is an atomic view boundary: status, branch choices
 * and history must always come from the same checkout. A stale history row is
 * especially dangerous because its revert/cherry-pick action targets the
 * currently selected checkout.
 *
 * The status itself now comes from the shared git-status store (one snapshot
 * per session+cwd+worktree, one poller), so these tests observe the selection
 * through the rows it renders and through the scope each git call receives —
 * including the `repoRoot` a container's worktree listing must carry.
 */
// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { act } from 'react-dom/test-utils'
import { GitLens } from '../src/client/changes/GitLens.tsx'
import { createSidebarStore } from '../src/client/state.ts'
import { api, type GitStatusEntry, type GitStatusResult, type GitWorktree } from '../src/client/api.ts'
import type { BetterSidebarService } from '../src/client/service.ts'
import { t } from '../src/client/locales.ts'
import { SUBMENU_FLIP_ATTR } from '../src/client/menu-flip.ts'
import type { Context } from '../src/context-types.ts'

import { setupReactAct } from './test-utils.ts'
setupReactAct()

const MAIN = 'C:/repo/main'
const AGENT = 'C:/repo/agent'
/** A second linked checkout some tests introduce on a later inventory pass. */
const AGENT_2 = 'C:/repo/agent-2'

const inventories: GitWorktree[] = [
  { path: MAIN, branch: 'main', current: true, changes: 0 },
  { path: AGENT, branch: 'agent', current: false, changes: 1 },
]

function statusFor(target?: string): GitStatusResult {
  if (target === AGENT_2) return { isRepo: true, branch: 'agent-2', entries: [{ path: 'agent-2-change.ts', xy: ' M' }] }
  return target === AGENT
    ? { isRepo: true, branch: 'agent', entries: [{ path: 'agent-change.ts', xy: ' M' }] }
    : { isRepo: true, branch: 'main', entries: [{ path: 'main-change.ts', xy: ' M' }] }
}

/** One `git.graph` page for a checkout; the subject names the checkout. */
function graphFor(target?: string, index = 0, hasMore = false): Awaited<ReturnType<typeof api.gitGraph>> {
  const agent = target === AGENT
  const digit = agent ? 'a' : 'b'
  const suffix = index.toString(16).padStart(8, '0')
  return {
    isRepo: true,
    root: target ?? MAIN,
    entries: [{
      hash: `${digit.repeat(6)}${suffix.slice(-1)}`,
      hashFull: `${digit.repeat(32)}${suffix}`,
      parents: [],
      subject: agent ? `Agent checkout commit ${index}` : `Main checkout commit ${index}`,
      author: 'Test',
      date: '2026-08-20 00:00:00 +0800',
      refs: ['HEAD', agent ? 'agent' : 'main'],
      message: `${agent ? 'Agent' : 'Main'} checkout commit ${index}\n`,
    }],
    branches: [{ ref: `refs/heads/${agent ? 'agent' : 'main'}`, name: agent ? 'agent' : 'main', hashFull: `${digit.repeat(32)}${suffix}` }],
    hasMore,
    snapshot: `${digit}${suffix}`,
  }
}

function deferred<T>(): { promise: Promise<T>; resolve: (value: T) => void } {
  let resolvePromise!: (value: T) => void
  const promise = new Promise<T>((resolve) => { resolvePromise = resolve })
  return { promise, resolve: resolvePromise }
}

async function flushEffects(): Promise<void> {
  // Each round drains one promise hop: the refresh chain (listing → branch/log
  // → state) is several hops deep, and a shallow flush would assert on rows
  // that are still in flight.
  for (let round = 0; round < 5; round += 1) await act(async () => { await Promise.resolve() })
}

/** Mount one GitLens. Visible by default: a hidden tab owns no live git data
 *  — the shared status store only polls/loads while a consumer is on screen. */
function mountGit(
  root: Root,
  options: {
    scope?: { sessionId: string; cwd?: string }
    visible?: boolean
    ctx?: Context
  } = {},
): void {
  act(() => {
    root.render(createElement(GitLens, {
      scope: options.scope ?? { sessionId: 'session', cwd: MAIN },
      store: createSidebarStore(),
      onOpenFile: () => {},
      onPreview: () => {},
      selectedRef: null,
      visible: options.visible ?? true,
      ...(options.ctx === undefined ? {} : { ctx: options.ctx }),
    }))
  })
}

/** A detached container + root; every case here unmounts it in its own finally. */
function makeRoot(): { container: HTMLDivElement; root: Root } {
  const container = document.createElement('div')
  document.body.append(container)
  return { container, root: createRoot(container) }
}

/** Menu surfaces are portaled to document.body, not into the lens container. */
function menuItem(label: string): HTMLButtonElement {
  const item = [...document.querySelectorAll<HTMLButtonElement>('button[role="menuitem"]')]
    .find(button => button.textContent?.trim() === label)
  if (item === undefined) throw new Error(`menu item not found: ${label}`)
  return item
}

function openMoreSubmenu(container: HTMLElement, label: string): HTMLButtonElement[] {
  const trigger = container.querySelector<HTMLButtonElement>(`button[aria-label="${t('gitMoreActions')}"]`)
  if (trigger === null) throw new Error('More Actions button not found')
  act(() => { trigger.click() })
  const parent = menuItem(label)
  expect(parent.getAttribute('aria-haspopup')).toBe('menu')
  act(() => { parent.click() })
  return [...document.querySelectorAll<HTMLButtonElement>('[role="menu"] [role="menu"] button[role="menuitem"]')]
}

async function chooseMoreOption(container: HTMLElement, submenu: string, label: string): Promise<void> {
  const item = openMoreSubmenu(container, submenu).find(button => button.textContent?.trim() === label)
  if (item === undefined) throw new Error(`submenu option not found: ${label}`)
  await act(async () => { item.click() })
  await flushEffects()
}

function branchButton(container: HTMLElement): HTMLButtonElement {
  const button = container.querySelector<HTMLButtonElement>('[data-git-footer] button[aria-haspopup="menu"]')
  if (button === null) throw new Error('footer branch button not found')
  return button
}

afterEach(() => { vi.restoreAllMocks() })

describe('GitLens (changes tab, git lens) linked-worktree consistency', () => {
  it('refreshes status, branches and history together on auto and manual selection', async () => {
    vi.spyOn(api, 'gitWorktrees').mockResolvedValue(inventories)
    vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    const branch = vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    const graph = vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, _options, target) => graphFor(target))

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      mountGit(root)
      await flushEffects()

      // A clean primary + exactly one dirty linked checkout auto-selects the
      // linked checkout and loads every target-derived surface from it.
      expect(branchButton(container).textContent).toBe('agent*')
      expect(container.textContent).toContain('agent-change.ts')
      expect(container.textContent).toContain('Agent checkout commit')
      expect(container.textContent).not.toContain('Main checkout commit')
      expect(branch).toHaveBeenCalledWith(expect.anything(), AGENT)
      expect(graph).toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ count: 50 }), AGENT, expect.anything())
      // The repo / worktree pickers moved into More Actions (#944); the only
      // select left is the Graph section's own branch filter.
      expect([...container.querySelectorAll('select')]).toHaveLength(1)
      const options = openMoreSubmenu(container, t('worktree'))
      expect(options.map(button => button.textContent)).toEqual(['main · main (0)', 'agent · agent (1)'])
      await act(async () => { options[0]!.click() })
      await flushEffects()

      expect(branchButton(container).textContent).toBe('main*')
      expect(container.textContent).toContain('main-change.ts')
      expect(container.textContent).toContain('Main checkout commit')
      expect(container.textContent).not.toContain('Agent checkout commit')
      expect(branch).toHaveBeenLastCalledWith(expect.anything(), MAIN)
      // Re-read for the main checkout. GitLens passes `selectedWorktree`
      // straight through, and the primary checkout is spelled as "no
      // narrowing" (undefined) or by its own path depending on how it was
      // chosen — the rows above are the real evidence.
      expect([undefined, MAIN]).toContain(graph.mock.calls.at(-1)?.[2])
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('drops a late graph page when the selected worktree changes', async () => {
    const lateAgentPage = deferred<Awaited<ReturnType<typeof api.gitGraph>>>()
    vi.spyOn(api, 'gitWorktrees').mockResolvedValue(inventories)
    vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, options, target) => {
      // The SECOND agent page is the one that lands late.
      if (target === AGENT && options?.cursor !== undefined) return lateAgentPage.promise
      if (target === AGENT) return graphFor(AGENT, 0, true)
      return graphFor(MAIN)
    })

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      mountGit(root)
      await flushEffects()

      const loadMore = [...container.querySelectorAll<HTMLButtonElement>('[data-scm-section="graph"] button')]
        .find(button => button.textContent === t('graphLoadMore'))
      expect(loadMore).not.toBeUndefined()
      await act(async () => { loadMore!.click() })

      await chooseMoreOption(container, t('worktree'), 'main · main (0)')
      expect(container.textContent).toContain('Main checkout commit 0')

      lateAgentPage.resolve(graphFor(AGENT, 99))
      await flushEffects()
      expect(container.textContent).toContain('Main checkout commit 0')
      expect(container.textContent).not.toContain('Agent checkout commit 99')
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('lists a selected child repository with its repoRoot, running one full refresh', async () => {
    const WS = 'C:/ws'
    const REPO_A = 'C:/ws/a'
    const REPO_B = 'C:/ws/b'
    const repoBWorktrees: GitWorktree[] = [
      { path: REPO_B, branch: 'b-main', current: true, changes: 0 },
      { path: 'C:/ws/b-agent', branch: 'b-agent', current: false, changes: 2 },
    ]
    const worktrees = vi.spyOn(api, 'gitWorktrees').mockImplementation(async (scope) => (
      scope.repoRoot === REPO_B ? repoBWorktrees : []
    ))
    const status = vi.spyOn(api, 'gitStatus').mockImplementation(async (scope) => (
      // Attached sessions ignore the client's cwd override; repoRoot selects the child.
      scope.repoRoot === REPO_B
        ? { isRepo: true, branch: 'b-main', entries: [{ path: 'b-change.ts', xy: ' M' }], root: REPO_B, repositories: [REPO_B] }
        : { isRepo: true, branch: 'a-main', entries: [{ path: 'a-change.ts', xy: ' M' }], root: REPO_A, repositories: [REPO_A, REPO_B] }
    ))
    const branch = vi.spyOn(api, 'gitBranch').mockImplementation(async (scope) => (
      scope.repoRoot === REPO_B ? { current: 'b-main', names: ['b-main'] } : { current: 'a-main', names: ['a-main'] }
    ))
    vi.spyOn(api, 'gitGraph').mockResolvedValue(graphFor(undefined))

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      mountGit(root, { scope: { sessionId: 'session', cwd: WS } })
      await flushEffects()

      // The workspace container's child repositories retain their basename labels.
      const repoOptions = openMoreSubmenu(container, t('gitRepository'))
      expect(repoOptions.map(button => button.textContent)).toEqual(['a', 'b'])
      const listingsBefore = worktrees.mock.calls.length

      await act(async () => { repoOptions[1]!.click() })
      await flushEffects()

      // The listing carries the selected repoRoot — a container's own listing
      // is empty, so the child checkout's linked worktrees only appear when the
      // selection rides along.
      expect(worktrees.mock.calls.at(-1)![0]).toMatchObject({ sessionId: 'session', cwd: WS, repoRoot: REPO_B })
      // Exactly ONE full refresh for the switch (not a burst).
      expect(worktrees.mock.calls.length).toBe(listingsBefore + 1)
      // The shared status follows the same selection.
      expect(status.mock.calls.at(-1)![0]).toMatchObject({ sessionId: 'session', cwd: WS, repoRoot: REPO_B })
      expect(branchButton(container).title).toBe(`${t('branch')}: b-main*`)
      expect(container.querySelector('[data-path="b-change.ts"]')).not.toBeNull()
      expect(container.querySelector('[data-path="a-change.ts"]')).toBeNull()
      // Explicit repo selection keeps that repo's PRIMARY checkout, even with
      // one dirty linked checkout available; every derived call targets it.
      expect(branch).toHaveBeenLastCalledWith(expect.objectContaining({ repoRoot: REPO_B }), REPO_B)
      expect(openMoreSubmenu(container, t('worktree')).map(button => button.textContent))
        .toEqual(['b-main · b (0)', 'b-agent · b-agent (2)'])
      act(() => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })

      await chooseMoreOption(container, t('gitRepository'), 'a')
      expect(branchButton(container).title).toBe(`${t('branch')}: a-main*`)
      expect(container.querySelector('[data-path="a-change.ts"]')).not.toBeNull()
      expect(container.querySelector('[data-path="b-change.ts"]')).toBeNull()
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('never yanks the view off the auto-selected checkout on a later re-list', async () => {
    const LATER: GitWorktree[] = [
      { path: MAIN, branch: 'main', current: true, changes: 0 },
      { path: AGENT, branch: 'agent', current: false, changes: 0 },
      { path: AGENT_2, branch: 'agent-2', current: false, changes: 5 },
    ]
    const worktrees = vi.spyOn(api, 'gitWorktrees')
      .mockResolvedValueOnce(inventories)
      .mockResolvedValue(LATER)
    vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, _options, target) => graphFor(target))

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      mountGit(root)
      await flushEffects()
      expect(branchButton(container).textContent).toBe('agent*')

      // A later inventory pass prefers the brand-new dirty checkout; the user
      // never chose a checkout, but the ONE automatic pass already ran.
      const refresh = container.querySelector<HTMLButtonElement>(`[data-scm-section="changes"] button[aria-label="${t('refresh')}"]`)
      expect(refresh).not.toBeNull()
      await act(async () => { refresh!.click() })
      await flushEffects()
      expect(worktrees).toHaveBeenCalledTimes(2)

      expect(branchButton(container).textContent).toBe('agent*')
      expect(container.textContent).toContain('agent-change.ts')
      expect(container.textContent).not.toContain('agent-2-change.ts')
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('queues a manual refresh that lands while a refresh is in flight', async () => {
    const held = deferred<GitWorktree[]>()
    const worktrees = vi.spyOn(api, 'gitWorktrees')
      .mockReturnValueOnce(held.promise)
      .mockResolvedValue(inventories)
    vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, _options, target) => graphFor(target))

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      mountGit(root)
      await flushEffects()
      expect(worktrees).toHaveBeenCalledTimes(1)

      // Changes refresh lands while the mount's inventory pass is in flight.
      // Shared status already knows this is a repo, so the action is available.
      const refresh = container.querySelector<HTMLButtonElement>(`[data-scm-section="changes"] button[aria-label="${t('refresh')}"]`)
      expect(refresh).not.toBeNull()
      expect(refresh!.disabled).toBe(false)
      await act(async () => { refresh!.click() })
      await flushEffects()
      // Queued, not dropped and not started in parallel.
      expect(worktrees).toHaveBeenCalledTimes(1)

      held.resolve([])
      await flushEffects()
      // The queued pass ran and its listing landed: the dirty linked checkout
      // is selected and its rows are the ones on screen.
      expect(worktrees).toHaveBeenCalledTimes(2)
      expect(container.textContent).toContain('agent-change.ts')
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('stays quiet while hidden and catches up when the tab becomes visible', async () => {
    const worktrees = vi.spyOn(api, 'gitWorktrees').mockResolvedValue(inventories)
    const status = vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, _options, target) => graphFor(target))

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      // Mounted in a background pane: no fetch at all (no git processes for a
      // tab nobody is looking at).
      mountGit(root, { visible: false })
      await flushEffects()
      expect(worktrees).not.toHaveBeenCalled()
      expect(status).not.toHaveBeenCalled()

      // Bringing the tab on screen loads the lens through one pass.
      mountGit(root, { visible: true })
      await flushEffects()
      expect(worktrees).toHaveBeenCalledTimes(1)
      expect(status).toHaveBeenCalled()
      expect(container.textContent).toContain('agent-change.ts')
      expect(container.textContent).toContain('Agent checkout commit')
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('hands the inventory poll its AbortSignal and stops it when hidden', async () => {
    vi.useFakeTimers()
    const worktrees = vi.spyOn(api, 'gitWorktrees').mockResolvedValue(inventories)
    vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, _options, target) => graphFor(target))

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      mountGit(root)
      await flushEffects()
      expect(worktrees).toHaveBeenCalledTimes(1)

      // The 30s inventory cadence fires and carries the poller's signal.
      await act(async () => { await vi.advanceTimersByTimeAsync(30_000) })
      await flushEffects()
      expect(worktrees.mock.calls.length).toBe(2)
      const signal = worktrees.mock.calls[1]![1]
      expect(signal).toBeInstanceOf(AbortSignal)

      // Hiding the tab tears the poll down and aborts its signal: a slow host
      // answer can no longer publish state.
      mountGit(root, { visible: false })
      await flushEffects()
      expect((signal as AbortSignal).aborted).toBe(true)
      const callsWhileHidden = worktrees.mock.calls.length
      await act(async () => { await vi.advanceTimersByTimeAsync(120_000) })
      expect(worktrees.mock.calls.length).toBe(callsWhileHidden)
    } finally {
      act(() => { root.unmount() })
      container.remove()
      vi.useRealTimers()
    }
  })

  it('keeps branch switch and history failures in the view banner, not the footer action status', async () => {
    vi.spyOn(api, 'gitWorktrees').mockResolvedValue([
      { path: MAIN, branch: 'main', current: true, changes: 1 },
    ])
    vi.spyOn(api, 'gitStatus').mockResolvedValue({
      isRepo: true, branch: 'main', entries: [{ path: 'src/a.ts', xy: ' M' }],
    })
    vi.spyOn(api, 'gitBranch').mockResolvedValue({ current: 'main', names: ['main', 'feature'] })
    vi.spyOn(api, 'gitGraph').mockResolvedValue(graphFor(undefined))
    vi.spyOn(api, 'gitCheckout').mockRejectedValue(new Error('dirty worktree'))

    const container = document.createElement('div')
    document.body.append(container)
    const root: Root = createRoot(container)
    try {
      mountGit(root)
      await flushEffects()

      // The entire footer branch button opens a menu of PLAIN branch names;
      // the dirty marker belongs only to the footer label, never its options.
      expect(branchButton(container).textContent).toBe('main*')
      act(() => { branchButton(container).click() })
      expect([...document.querySelectorAll('[role="menuitem"]')].map(item => item.textContent)).toEqual(['main', 'feature'])
      await act(async () => { menuItem('feature').click() })
      await flushEffects()

      const banner = [...container.querySelectorAll<HTMLElement>('[role="alert"]')]
        .find(node => (node.textContent ?? '').includes(`${t('checkoutError')}: dirty worktree`))
      expect(banner).toBeDefined()
      const input = container.querySelector('[data-message-box] textarea')
      expect(input).not.toBeNull()
      // Branch/history failures are view-level, not the shared action channel.
      expect(banner!.parentElement).toBe(container.querySelector('[data-git-scroll]'))
      expect(container.querySelector('[data-git-footer] [role="alert"]')).toBeNull()
      expect(banner!.compareDocumentPosition(input!) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })
})

/**
 * Issue #988: the More Actions menu's repo/worktree rows open nested
 * submenus. The button-anchored menu used to skip the body attribute the
 * file-tree row menu publishes (menu-flip.ts), so layout.css never had the
 * tokens it needs to flip those submenus back inside the viewport — in a
 * right-docked sidebar they opened past the right edge and were unreachable.
 */
describe('GitLens (changes tab, git lens) More Actions submenu flip (#988)', () => {
  it('publishes the flip geometry while the menu is open and clears it on close', async () => {
    vi.spyOn(api, 'gitWorktrees').mockResolvedValue(inventories)
    vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockResolvedValue(graphFor(AGENT))

    const { container, root } = makeRoot()
    try {
      mountGit(root)
      await flushEffects()
      // The attribute's lifetime IS the mechanism's scope: closed menu, no
      // attribute (layout.css must not touch host-owned menus).
      expect(document.body.hasAttribute(SUBMENU_FLIP_ATTR)).toBe(false)

      // The trigger of a right-docked sidebar, above the viewport's midpoint.
      // Those coordinates have to produce BOTH flips: left (no right-hand room
      // for card + submenu) and down (more room below the top-edge row menu).
      const trigger = container.querySelector<HTMLButtonElement>(`button[aria-label="${t('gitMoreActions')}"]`)
      if (trigger === null) throw new Error('More Actions button not found')
      vi.spyOn(trigger, 'getBoundingClientRect').mockReturnValue(new DOMRect(976, 100, 24, 24))

      expect(openMoreSubmenu(container, t('worktree')).length).toBeGreaterThan(0)
      expect(document.body.getAttribute(SUBMENU_FLIP_ATTR)).toBe('down left')

      // Closing the menu drops the tokens: the next menu gets its own geometry.
      act(() => { trigger.click() })
      expect(document.body.hasAttribute(SUBMENU_FLIP_ATTR)).toBe(false)
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })
})

describe('GitLens (changes tab, git lens) change tree', () => {
  /** Mount with one changed-file inventory; every test picks its own entries. */
  async function mountTree(
    container: HTMLElement,
    root: Root,
    entries: GitStatusEntry[],
  ): Promise<void> {
    const changes = entries.filter(row => row.xy !== '  ').length
    vi.spyOn(api, 'gitWorktrees').mockResolvedValue([{ path: MAIN, branch: 'main', current: true, changes }])
    vi.spyOn(api, 'gitStatus').mockResolvedValue({ isRepo: true, branch: 'main', entries })
    vi.spyOn(api, 'gitBranch').mockResolvedValue({ current: 'main', names: ['main'] })
    vi.spyOn(api, 'gitGraph').mockResolvedValue(graphFor(undefined))
    mountGit(root)
    await flushEffects()
  }

  it('folds a directory row per group, independently of the same path on the other side', async () => {
    const { container, root } = makeRoot()
    try {
      await mountTree(container, root, [
        { path: 'src/a.ts', xy: ' M' }, // unstaged side
        { path: 'src/b.ts', xy: 'M ' }, // staged side
      ])

      const dir = (group: string): HTMLButtonElement =>
        container.querySelector<HTMLButtonElement>(`[data-group="${group}"] button[data-dir="src"]`)!
      // One 'src' row per group, independent of the sections' display order.
      expect(container.querySelectorAll('button[data-dir="src"]')).toHaveLength(2)
      expect(dir('unstaged').getAttribute('aria-expanded')).toBe('true')
      expect(dir('unstaged').querySelector('svg')).not.toBeNull()
      expect(container.querySelector('button[data-path="src/a.ts"]')).not.toBeNull()
      expect(container.querySelector('button[data-path="src/a.ts"]')!.querySelector('svg')).not.toBeNull()

      await act(async () => { dir('unstaged').click() })
      // Folded: the unstaged subtree is gone...
      expect(dir('unstaged').getAttribute('aria-expanded')).toBe('false')
      expect(container.querySelector('button[data-path="src/a.ts"]')).toBeNull()
      // ...while the staged group's own 'src' row stays open and keeps its file.
      expect(dir('staged').getAttribute('aria-expanded')).toBe('true')
      expect(container.querySelector('button[data-path="src/b.ts"]')).not.toBeNull()

      await act(async () => { dir('unstaged').click() })
      expect(container.querySelector('button[data-path="src/a.ts"]')).not.toBeNull()
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('compresses a single-child directory chain into one labelled row', async () => {
    const { container, root } = makeRoot()
    try {
      await mountTree(container, root, [
        { path: 'src/client/changes/a.ts', xy: ' M' },
        { path: 'src/client/changes/b.ts', xy: ' M' },
      ])

      // Three levels, one child each: one row, one label, two changes.
      const row = container.querySelector<HTMLButtonElement>('button[data-dir="src/client/changes"]')
      expect(row).not.toBeNull()
      expect(row!.textContent).toContain('src/client/changes')
      expect(container.querySelector('[data-group="unstaged"] [data-count]')?.textContent).toBe('2')
      // Both files hang under that one row.
      expect(container.querySelector('button[data-path="src/client/changes/a.ts"]')).not.toBeNull()
      expect(container.querySelector('button[data-path="src/client/changes/b.ts"]')).not.toBeNull()
      // Nothing on the staged side: no empty group and no tree rows.
      expect(container.querySelector('[data-group="staged"]')).toBeNull()
      expect(container.querySelectorAll('[data-group="staged"] [data-path]')).toHaveLength(0)
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('stages a file from a nested tree row and re-reads the shared status', async () => {
    const { container, root } = makeRoot()
    try {
      await mountTree(container, root, [{ path: 'src/deep/a.ts', xy: ' M' }])
      const stage = vi.spyOn(api, 'gitStage').mockResolvedValue({ ok: true })
      const statusSpy = vi.mocked(api.gitStatus)
      const statusCallsBefore = statusSpy.mock.calls.length

      const action = container.querySelector<HTMLButtonElement>(`button[aria-label="${t('stage')}"]`)
      expect(action).not.toBeNull()
      await act(async () => { action!.click() })
      await flushEffects()

      // The auto-selected primary checkout rides along as the worktree target.
      expect(stage).toHaveBeenCalledWith(expect.objectContaining({ sessionId: 'session' }), 'src/deep/a.ts', MAIN)
      expect(statusSpy.mock.calls.length).toBeGreaterThan(statusCallsBefore)
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('bands each group with its count and a labelled stage-all action', async () => {
    const { container, root } = makeRoot()
    try {
      await mountTree(container, root, [
        { path: 'src/a.ts', xy: ' M' },
        { path: 'docs/b.md', xy: ' M' },
        { path: 'src/c.ts', xy: 'M ' },
      ])

      const unstaged = container.querySelector<HTMLElement>('[data-group="unstaged"]')!
      const staged = container.querySelector<HTMLElement>('[data-group="staged"]')!
      expect(unstaged.textContent).toContain(t('gitChanges'))
      expect(staged.textContent).toContain(t('gitStagedChanges'))
      expect(unstaged.querySelector('[data-count]')?.textContent).toBe('2')
      expect(staged.querySelector('[data-count]')?.textContent).toBe('1')

      // The band's own action is the one that is NOT inside a row (directory
      // rows carry the same "Stage all" label for their own subtree).
      const stageAll = [...unstaged.querySelectorAll<HTMLButtonElement>(`button[aria-label="${t('stageAll')}"]`)]
        .find(button => button.closest('[data-row]') === null)
      const unstageAll = [...staged.querySelectorAll<HTMLButtonElement>(`button[aria-label="${t('unstageAll')}"]`)]
        .find(button => button.closest('[data-row]') === null)
      expect(stageAll).not.toBeUndefined()
      expect(unstageAll).not.toBeUndefined()

      const stage = vi.spyOn(api, 'gitStage').mockResolvedValue({ ok: true })
      await act(async () => { stageAll!.click() })
      await flushEffects()
      // "Stage all" stages the whole worktree: no path argument.
      expect(stage).toHaveBeenCalledWith(expect.objectContaining({ sessionId: 'session' }), undefined, MAIN)
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('stages and unstages a whole directory from its row action', async () => {
    const { container, root } = makeRoot()
    try {
      await mountTree(container, root, [
        { path: 'src/deep/a.ts', xy: ' M' }, // unstaged → the 'src/deep' row
        { path: 'docs/b.md', xy: 'M ' }, // staged → the 'docs' row
      ])
      const stage = vi.spyOn(api, 'gitStage').mockResolvedValue({ ok: true })
      const unstage = vi.spyOn(api, 'gitUnstage').mockResolvedValue({ ok: true })

      const dirAction = (path: string, label: string): HTMLButtonElement => {
        const row = container.querySelector<HTMLElement>(`[data-row="${path}"]`)
        expect(row).not.toBeNull()
        const button = row!.querySelector<HTMLButtonElement>(`button[aria-label="${label}"]`)
        expect(button).not.toBeNull()
        return button!
      }

      const unstagedDir = dirAction('src/deep', t('stageAll'))
      await act(async () => { unstagedDir.click() })
      await flushEffects()
      // The directory path stages the whole subtree (`git add -A -- <dir>`).
      expect(stage).toHaveBeenCalledWith(expect.objectContaining({ sessionId: 'session' }), 'src/deep', MAIN)

      const stagedDir = dirAction('docs', t('unstageAll'))
      await act(async () => { stagedDir.click() })
      await flushEffects()
      expect(unstage).toHaveBeenCalledWith(expect.objectContaining({ sessionId: 'session' }), 'docs', MAIN)

      // Neither click folded its row: the action is a sibling of the
      // disclosure button (and stops propagation anyway).
      expect(container.querySelector('button[data-dir="src/deep"]')!.getAttribute('aria-expanded')).toBe('true')
      expect(container.querySelector('button[data-path="src/deep/a.ts"]')).not.toBeNull()
      expect(container.querySelector('button[data-dir="docs"]')!.getAttribute('aria-expanded')).toBe('true')
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('resolves no icon for a status poll whose change list did not change', async () => {
    vi.useFakeTimers()
    const fileIcons: string[] = []
    const folderIcons: string[] = []
    /** The icon resolvers are the re-render probe: they run inside the rows,
     *  so one entry per call means one row actually re-rendered. */
    const service = {
      subscribe: () => () => {},
      fileIcon: (path: string) => { fileIcons.push(path); return null },
      folderIcon: (path: string, open: boolean) => { folderIcons.push(`${path}:${String(open)}`); return null },
    } as unknown as BetterSidebarService
    const ctx = { get: (name: string) => (name === 'betterSidebar' ? service : undefined) } as unknown as Context

    const { container, root } = makeRoot()
    try {
      vi.spyOn(api, 'gitWorktrees').mockResolvedValue([{ path: MAIN, branch: 'main', current: true, changes: 2 }])
      // Every poll answers with a fresh object and a fresh entries array (the
      // store's real shape). The FIRST answer carries no repository list and
      // the later ones do — a field OUTSIDE the change list moves, so the store
      // cannot preserve the snapshot identity and hands the lens a new array
      // whose content is equal. Only the CONTENT key plus the memoized rows
      // hold there; identity alone would rebuild the tree and re-render rows.
      let poll = 0
      vi.spyOn(api, 'gitStatus').mockImplementation(async () => {
        poll += 1
        return {
          isRepo: true,
          branch: 'main',
          ...(poll === 1 ? {} : { repositories: [MAIN] }),
          // One compressed directory row (folder icon) + its two file rows.
          entries: [{ path: 'src/deep/a.ts', xy: ' M' }, { path: 'src/deep/b.ts', xy: ' M' }],
        }
      })
      vi.spyOn(api, 'gitBranch').mockResolvedValue({ current: 'main', names: ['main'] })
      vi.spyOn(api, 'gitGraph').mockResolvedValue(graphFor(undefined))

      mountGit(root, { ctx })
      await flushEffects()
      expect(fileIcons).toEqual(['src/deep/a.ts', 'src/deep/b.ts'])
      expect(folderIcons).toEqual(['src/deep:true'])

      fileIcons.length = 0
      folderIcons.length = 0
      // Tick 1: a NEW snapshot object with an equal-content change list.
      await act(async () => { await vi.advanceTimersByTimeAsync(2_600) })
      await flushEffects()
      expect(fileIcons).toEqual([])
      expect(folderIcons).toEqual([])

      fileIcons.length = 0
      folderIcons.length = 0
      // Tick 2: a byte-identical answer (the store reuses the snapshot object).
      await act(async () => { await vi.advanceTimersByTimeAsync(2_600) })
      await flushEffects()
      expect(fileIcons).toEqual([])
      expect(folderIcons).toEqual([])
      // The probe measured stability, not loss: every row is still there.
      expect(container.querySelectorAll('[data-path]')).toHaveLength(2)
      expect(container.querySelectorAll('button[data-dir="src/deep"]')).toHaveLength(1)
    } finally {
      act(() => { root.unmount() })
      container.remove()
      vi.useRealTimers()
    }
  })

  /**
   * Issue #131: the added/deleted line counts the status answer carries are
   * what the file rows and the group headers print. The header's number is the
   * sum of the numbers under it, and a row git has no numstat for (an untracked
   * file, a binary blob) says so instead of printing an invented `+0 −0`.
   */
  describe('line counts (#131)', () => {
    /** One rendered row's/band's count cluster, as its data attributes. */
    function counted(container: HTMLElement, selector: string): { added: string | null; deleted: string | null; text: string } {
      const node = container.querySelector<HTMLElement>(selector)
      expect(node, selector).not.toBeNull()
      return {
        added: node!.getAttribute('data-added'),
        deleted: node!.getAttribute('data-deleted'),
        text: node!.textContent ?? '',
      }
    }

    it('prints each row its own counts and each band the sum of its members', async () => {
      const { container, root } = makeRoot()
      try {
        await mountTree(container, root, [
          { path: 'src/a.ts', xy: ' M', unstaged: { additions: 4, deletions: 2 } },
          { path: 'src/b.ts', xy: ' M', unstaged: { additions: 1, deletions: 0 } },
          { path: 'docs/c.md', xy: 'M ', staged: { additions: 3, deletions: 3 } },
        ])

        expect(counted(container, '[data-path="src/a.ts"] [data-lines="count"]'))
          .toEqual({ added: '4', deleted: '2', text: '+4−2' })
        expect(counted(container, '[data-path="src/b.ts"] [data-lines="count"]'))
          .toEqual({ added: '1', deleted: '0', text: '+1' })
        expect(counted(container, '[data-path="docs/c.md"] [data-lines="count"]'))
          .toEqual({ added: '3', deleted: '3', text: '+3−3' })

        // Each band's total IS the sum of the rows under it (4+1 / 2+0 and
        // 3 / 3) — and each group only counts its own members.
        expect(counted(container, '[data-group="unstaged"] [data-lines="group"]'))
          .toEqual({ added: '5', deleted: '2', text: '+5−2' })
        expect(counted(container, '[data-group="staged"] [data-lines="group"]'))
          .toEqual({ added: '3', deleted: '3', text: '+3−3' })

        // The same numbers, read back off the DOM: band = Σ members.
        const sumOf = (group: string, side: 'added' | 'deleted'): number =>
          [...container.querySelectorAll<HTMLElement>(`[data-group="${group}"] [data-path] [data-lines="count"]`)]
            .reduce((total, node) => total + Number(node.getAttribute(`data-${side}`)), 0)
        expect(sumOf('unstaged', 'added')).toBe(5)
        expect(sumOf('unstaged', 'deleted')).toBe(2)
      } finally {
        act(() => { root.unmount() })
        container.remove()
      }
    })

    it('marks a binary blob and invents no numbers for what git never diffs', async () => {
      const { container, root } = makeRoot()
      try {
        await mountTree(container, root, [
          { path: 'new.txt', xy: '??' },
          { path: 'blob.bin', xy: ' M', unstaged: { binary: true } },
        ])

        expect(container.querySelector('[data-path="blob.bin"] [data-lines="binary"]')?.textContent)
          .toBe(t('diffBinary'))
        // An untracked row already says so with its `U` badge — no second note.
        expect(container.querySelector('[data-path="new.txt"] [data-lines]')).toBeNull()
        // Neither row claims a count...
        expect(container.querySelector('[data-path="new.txt"] [data-lines="count"]')).toBeNull()
        expect(container.querySelector('[data-path="blob.bin"] [data-lines="count"]')).toBeNull()
        // ...and with nothing to sum, the band shows no total at all.
        expect(container.querySelector('[data-group="unstaged"] [data-lines="group"]')).toBeNull()
        // The count pill still reports how many files changed.
        expect(container.querySelector('[data-group="unstaged"] [data-count]')?.textContent).toBe('2')
      } finally {
        act(() => { root.unmount() })
        container.remove()
      }
    })

    it('republishes the numbers when only the counts moved (same paths, same porcelain)', async () => {
      vi.useFakeTimers()
      const { container, root } = makeRoot()
      try {
        vi.spyOn(api, 'gitWorktrees').mockResolvedValue([{ path: MAIN, branch: 'main', current: true, changes: 1 }])
        // Two answers with the SAME path and the SAME porcelain code: only the
        // line counts moved (more lines appended to an already-modified file).
        vi.spyOn(api, 'gitStatus')
          .mockResolvedValueOnce({
            isRepo: true, branch: 'main', entries: [{ path: 'src/a.ts', xy: ' M', unstaged: { additions: 1, deletions: 0 } }],
          })
          .mockResolvedValue({
            isRepo: true, branch: 'main', entries: [{ path: 'src/a.ts', xy: ' M', unstaged: { additions: 7, deletions: 0 } }],
          })
        vi.spyOn(api, 'gitBranch').mockResolvedValue({ current: 'main', names: ['main'] })
        vi.spyOn(api, 'gitGraph').mockResolvedValue(graphFor(undefined))

        mountGit(root)
        await flushEffects()
        expect(counted(container, '[data-path="src/a.ts"] [data-lines="count"]').added).toBe('1')

        // Past the store's automatic cadence (a 30 s baseline; see
        // docs/plans/2026-10-13-git-poll-ladder-and-idle-notify.md) — that
        // tick is what makes the second answer arrive at all.
        await act(async () => { await vi.advanceTimersByTimeAsync(31_000) })
        await flushEffects()
        // Both caches had to notice: the store's field-by-field snapshot
        // compare AND the lens's content key. Either one ignoring the counts
        // leaves the row printing its first reading forever.
        expect(counted(container, '[data-path="src/a.ts"] [data-lines="count"]').added).toBe('7')
        expect(counted(container, '[data-group="unstaged"] [data-lines="group"]').added).toBe('7')
      } finally {
        act(() => { root.unmount() })
        container.remove()
        vi.useRealTimers()
      }
    })

    it('gives each band its OWN side of a file changed on both sides, never the sum (#131 regression)', async () => {
      const { container, root } = makeRoot()
      try {
        // One file changed on both sides ('MM'): a one-line rewrite staged,
        // then five lines appended in the worktree. Each band must show its own
        // reading — summing them printed `+6 −1` on BOTH bands.
        await mountTree(container, root, [
          {
            path: 'a.txt',
            xy: 'MM',
            staged: { additions: 1, deletions: 1 },
            unstaged: { additions: 5, deletions: 0 },
          },
        ])

        expect(counted(container, '[data-group="unstaged"] [data-lines="group"]'))
          .toEqual({ added: '5', deleted: '0', text: '+5' })
        expect(counted(container, '[data-group="staged"] [data-lines="group"]'))
          .toEqual({ added: '1', deleted: '1', text: '+1−1' })
        // The path really is listed in both bands, each row printing its own
        // side's numbers (Staged before Changes — the Source Control order the
        // three bands took in #944).
        const rows = [...container.querySelectorAll<HTMLElement>('button[data-path="a.txt"] [data-lines="count"]')]
        expect(rows.map(node => `${node.getAttribute('data-added')}/${node.getAttribute('data-deleted')}`))
          .toEqual(['1/1', '5/0'])
      } finally {
        act(() => { root.unmount() })
        container.remove()
      }
    })
  })
})

/**
 * The lens lives in a REUSED tab instance (the workbench keeps one mounted
 * component per tab id and swaps `scope`), so a destructive confirmation armed
 * for a row of the previous project must not survive the swap: its `onConfirm`
 * closure carries that row's path while `gitScopeNow()` already reads the new
 * scope — the discard would land in the project that took over the pane.
 */
describe('GitLens (changes tab, git lens) scope swap', () => {
  it('drops a pending discard confirmation when the scope changes', async () => {
    // One primary checkout, so the view stays on MAIN's changed row.
    const onlyMain: GitWorktree[] = [{ path: MAIN, branch: 'main', current: true, changes: 1 }]
    vi.spyOn(api, 'gitWorktrees').mockResolvedValue(onlyMain)
    vi.spyOn(api, 'gitStatus').mockImplementation(async (_scope, target) => statusFor(target))
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, _options, target) => graphFor(target))
    const discard = vi.spyOn(api, 'gitDiscard')

    const { container, root } = makeRoot()
    try {
      mountGit(root, { scope: { sessionId: 's1', cwd: MAIN } })
      await flushEffects()

      const row = container.querySelector<HTMLElement>('[data-path="main-change.ts"]')
      if (row === null) throw new Error('changed row not found')
      act(() => {
        row.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: 20, clientY: 30 }))
      })
      const item = [...document.querySelectorAll<HTMLElement>('[role="menuitem"]')]
        .find(el => el.textContent === t('discard'))
      if (item === undefined) throw new Error('discard menu item not found')
      act(() => { item.click() })
      expect(document.querySelector('[role="dialog"]')).not.toBeNull()

      // Another session takes over the same mounted instance.
      mountGit(root, { scope: { sessionId: 's2', cwd: AGENT } })
      await flushEffects()

      expect(document.querySelector('[role="dialog"]')).toBeNull()
      expect(discard).not.toHaveBeenCalled()
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })

  it('does not carry a half-typed commit message into the next scope', async () => {
    // The Commit button asks only for a non-empty message and a staged row, so
    // a draft typed against the previous project would submit verbatim under
    // the new one — no confirmation in between. Driven through the submit
    // itself rather than the button's disabled state: what has to hold is that
    // the message is ABSENT, not merely that a gate is shut.
    const commit = vi.spyOn(api, 'gitCommit').mockResolvedValue({ ok: true })
    vi.spyOn(api, 'gitWorktrees').mockResolvedValue([{ path: MAIN, branch: 'main', current: true, changes: 1 }])
    vi.spyOn(api, 'gitStatus').mockResolvedValue({
      isRepo: true,
      branch: 'main',
      // 'M ' is a STAGED row: the commit path needs one to be reachable at all.
      entries: [{ path: 'staged.ts', xy: 'M ' }],
    })
    vi.spyOn(api, 'gitBranch').mockImplementation(async (_scope, target) => ({
      current: target === AGENT ? 'agent' : 'main',
      names: target === AGENT ? ['agent'] : ['main'],
    }))
    vi.spyOn(api, 'gitGraph').mockImplementation(async (_scope, _options, target) => graphFor(target))

    const { container, root } = makeRoot()
    // Re-queried on every use: a re-render may hand back a different node, and
    // a detached one keeps whatever its last render set.
    const box = (): HTMLTextAreaElement | null =>
      container.querySelector('[data-message-box] textarea')
    const typeInto = async (text: string): Promise<void> => {
      await act(async () => {
        const node = box()
        if (node === null) throw new Error('commit box not found')
        // Native setter: a plain `node.value =` leaves React's tracker behind.
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(node, text)
        node.dispatchEvent(new Event('input', { bubbles: true }))
      })
    }
    const submit = async (): Promise<void> => {
      await act(async () => {
        box()?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', ctrlKey: true, bubbles: true }))
      })
      await act(async () => { await Promise.resolve() })
    }
    try {
      mountGit(root, { scope: { sessionId: 's1', cwd: MAIN } })
      await flushEffects()
      await typeInto('fix: half typed in A')

      // Another session takes over the same mounted instance. The draft stays
      // behind with the project it was written for, so this submit finds no
      // message to send.
      mountGit(root, { scope: { sessionId: 's2', cwd: AGENT } })
      await flushEffects()
      await submit()
      expect(commit).not.toHaveBeenCalled()

      // Coming back to that project brings its own message back: the draft is
      // the state a kept-mounted tab holds on #712's behalf.
      mountGit(root, { scope: { sessionId: 's1', cwd: MAIN } })
      await flushEffects()
      await submit()
      expect(commit).toHaveBeenCalledTimes(1)
      expect(commit.mock.calls[0]?.[0]?.sessionId).toBe('s1')
      expect(commit.mock.calls[0]?.[1]).toBe('fix: half typed in A')
    } finally {
      act(() => { root.unmount() })
      container.remove()
    }
  })
})
