/**
 * Unsaved-draft protection: the dirty registry itself plus the close guard it
 * arms. The registry is fed by the editor host's toolbar report; the guard is
 * the sidebar's tab close (the X button, middle click, tab context menu, and
 * the tree's close-on-rename/delete all funnel through the same action).
 *
 * The close path is driven through the REAL Sidebar shell (same minimal fake
 * context as sidebar-crash.spec.tsx) so the test pins the behavior a user
 * actually gets, not a helper: cancel keeps the tab, confirm closes it.
 */
// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createElement, useEffect } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { act } from 'react-dom/test-utils'
import { renderRoot, setupReactAct } from './test-utils.ts'
import type { Context } from '../src/context-types.ts'
import { EditorHost } from '../src/client/EditorHost.tsx'
import { Sidebar } from '../src/client/Sidebar.tsx'
import { createBetterSidebarService, type BetterSidebarService, type FileViewerProps } from '../src/client/service.ts'
import { allLeaves, createSidebarStore, toggleBottomPanel, type SidebarStore } from '../src/client/state.ts'
import {
  clearEditorDirty, confirmDiscardDraft, dirtyCount, editorDirtyRevision,
  isEditorDirty, setEditorDirty, subscribeEditorDirty,
} from '../src/client/editor-dirty.ts'
import { clearRetargetedPath, closePathTabs, consumeRetargetedPath, pathTabKey, retargetPathTabs } from '../src/client/tree-mutations.ts'
import { flushDraftBackups, readDraftBackup, registerDraftSource, scheduleDraftBackup } from '../src/client/editor-draft-backup.ts'
import { createNativeSurface } from '../src/client/native/surface.ts'
import { createNativeTabRecords } from '../src/client/native/tab-adapter.tsx'

setupReactAct()

const fsRead = vi.fn()
// Partial mock: only the reads this spec drives are stubbed. The sidebar shell
// also touches `sessionPhase` / `api.sessionCwd` / the tree panel on mount, and
// a wholesale replacement breaks them (`No "sessionPhase" export …`).
vi.mock('../src/client/api.ts', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../src/client/api.ts')>()
  return {
    ...actual,
    api: {
      ...actual.api,
      fsRead: (...args: unknown[]) => fsRead(...args),
      fsTree: () => Promise.resolve({ path: '', entries: [], truncated: false }),
    },
  }
})

/** jsdom has no WebSocket; the sidebar's agent-terminals effect builds one. */
class FakeWebSocket {
  onmessage: ((event: { data: unknown }) => void) | null = null
  onclose: (() => void) | null = null
  onerror: (() => void) | null = null
  close = (): void => {}
  constructor(_url: string) {}
}

/** A viewer that reports a dirty toolbar and renders nothing else. */
function DirtyViewer({ onToolbarState }: FileViewerProps) {
  useEffect(() => {
    onToolbarState?.({ modes: false, mode: 'edit', dirty: true, editable: true, saveState: 'idle' })
  }, [onToolbarState])
  return createElement('div', null, 'dirty-viewer')
}

let sessionSeq = 0

interface Mounted {
  container: HTMLDivElement
  store: SidebarStore
  service: BetterSidebarService
  sessionId: string
  unmount: () => void
}

/** Mount the real Sidebar shell with one open editor tab (dirty viewer). */
function mountSidebarWithEditor(): Mounted {
  vi.stubGlobal('WebSocket', FakeWebSocket)
  const container = document.createElement('div')
  document.body.append(container)
  const store = createSidebarStore()
  const service = createBetterSidebarService(store)
  service.registerTab({
    id: 'editor',
    title: 'Files',
    dedupeKey: (tab) => tab.path,
    component: ({ ctx, store: tabStore, scope, tab, expanded, revealed, onToggleDir, onReferenceFile }) =>
      createElement(EditorHost, {
        ctx, store: tabStore, scope, tab,
        expanded: expanded ?? [], revealed: revealed ?? [],
        onToggleDir: onToggleDir ?? (() => {}), onReferenceFile: onReferenceFile ?? (() => {}),
      }),
  })
  service.registerFileViewer({
    id: 'mock-text', exts: ['ts'], priority: 0, fetchStrategy: 'fsRead', component: DirtyViewer,
  })
  const sessionId = `dirty-${++sessionSeq}`
  store.setSession(sessionId)
  // The plugin's own workbench hosts its tabs; without the panel open the tab
  // strip (and its close button) is not rendered at all.
  store.reduce(toggleBottomPanel)
  const localeSnapshot = { active: 'en' }
  // The session-list snapshot never carried a current-session field: the shell
  // binds its per-session state to the native surface's mounted seat.
  const sessionsSnapshot = { byId: { [sessionId]: { cwd: '/tmp' } } }
  const mounted = { getSnapshot: () => sessionId, subscribe: () => () => {} }
  const ctx = {
    locale: { subscribe: () => () => {}, getSnapshot: () => localeSnapshot },
    sessions: { list: { subscribe: () => () => {}, getSnapshot: () => sessionsSnapshot } },
    betterSidebar: service,
    get: (name: string) => name === 'betterSidebar'
      ? service
      : name === 'sidebarRight' ? { mounted } : undefined,
  } as unknown as Context
  service.openTab({ type: 'editor', title: 'a.ts', path: '/tmp/a.ts', id: 'editor:/tmp/a.ts' })
  const root: Root = createRoot(container)
  act(() => { root.render(createElement(Sidebar, { ctx, store })) })
  return {
    container, store, service, sessionId,
    unmount: () => {
      act(() => { root.unmount() })
      container.remove()
    },
  }
}

/** The a.ts tab's close button (the seeded Files home tab also has one). */
function closeButton(container: HTMLDivElement): HTMLButtonElement {
  const tabNode = Array.from(container.querySelectorAll('[title="a.ts"]'))
    .find(node => node.querySelector('button') !== null)
  const button = tabNode?.querySelector('button[aria-label="Close"], button[aria-label="关闭"]')
  if (button === undefined || button === null) throw new Error('close button not found')
  return button as HTMLButtonElement
}

function click(button: HTMLElement): void {
  act(() => { button.dispatchEvent(new MouseEvent('click', { bubbles: true })) })
}

function openTabIds(store: SidebarStore): string[] {
  const state = store.getSnapshot().state
  if (state === undefined) return []
  // The plugin's tabs live in its own bottom workbench (the main column
  // belongs to DSH's native right sidebar).
  return allLeaves(state.bottomSplits).flatMap(leaf => leaf.tabs).map(tab => tab.id)
}

beforeEach(() => {
  fsRead.mockReset()
  fsRead.mockResolvedValue({ kind: 'text', content: 'hello', size: 5 })
  // The registry is module-level: a previous test's draft must not leak in.
  for (const id of ['editor:/tmp/a.ts', 't1', 't2']) clearEditorDirty(id)
})

afterEach(() => {
  document.body.innerHTML = ''
  localStorage.clear()
  vi.unstubAllGlobals()
  vi.restoreAllMocks()
})

describe('editor-dirty registry', () => {
  it('registers a dirty tab and clears it again, bumping the revision each time', () => {
    const before = editorDirtyRevision()
    setEditorDirty('t1', true, 's1', '/tmp/a.ts')
    expect(isEditorDirty('t1', 's1')).toBe(true)
    expect(dirtyCount()).toBe(1)
    expect(isEditorDirty('t1', 'other')).toBe(false)
    expect(editorDirtyRevision()).toBeGreaterThan(before)

    const afterRegister = editorDirtyRevision()
    setEditorDirty('t1', true, 's1', '/tmp/a.ts')
    // Same entry twice is a no-op: no revision churn (the unload effect would
    // otherwise re-subscribe on every render).
    expect(editorDirtyRevision()).toBe(afterRegister)

    clearEditorDirty('t1', 's1')
    expect(isEditorDirty('t1', 's1')).toBe(false)
    expect(dirtyCount()).toBe(0)
    expect(editorDirtyRevision()).toBeGreaterThan(afterRegister)
  })

  it('keeps one record per session for the same tab id', () => {
    // The id is session-scoped: the native right column counts its own `tab1`…
    // and the workbench reuses `editor:<path>` across sessions, so both records
    // must be able to exist at once.
    setEditorDirty('t2', true, 's1', '/tmp/a.ts')
    setEditorDirty('t2', true, 's2', '/tmp/b.ts')
    expect(dirtyCount()).toBe(2)
    expect(isEditorDirty('t2', 's1')).toBe(true)
    expect(isEditorDirty('t2', 's2')).toBe(true)
  })

  it('a second session mounting the same tab id never clears the first session draft', () => {
    // Session A's editor holds a draft …
    setEditorDirty('tab1', true, 's1', '/tmp/a.ts')
    // … then B's editor mounts over the same native id and reports clean (its
    // mount always does: the toolbar has not reported yet), and B's body is
    // unmounted again. Neither may touch A's record: losing it disarms the
    // unload guard and a refresh drops A's draft without a word.
    setEditorDirty('tab1', false, 's2', '/tmp/b.ts')
    clearEditorDirty('tab1', 's2')
    expect(isEditorDirty('tab1', 's1')).toBe(true)
    expect(dirtyCount()).toBe(1)
    // Without a session the read is the conservative one: any session matches.
    expect(isEditorDirty('tab1')).toBe(true)
  })

  it('notifies subscribers and stops after unsubscribe', () => {
    const listener = vi.fn()
    const unsubscribe = subscribeEditorDirty(listener)
    setEditorDirty('t1', true, 's1', '/tmp/a.ts')
    expect(listener).toHaveBeenCalledTimes(1)
    clearEditorDirty('t1', 's1')
    expect(listener).toHaveBeenCalledTimes(2)
    unsubscribe()
    setEditorDirty('t1', true, 's1', '/tmp/a.ts')
    expect(listener).toHaveBeenCalledTimes(2)
  })

  it('confirmDiscardDraft passes clean tabs through and prompts for dirty ones', () => {
    const confirmSpy = vi.fn().mockReturnValue(false)
    vi.stubGlobal('confirm', confirmSpy)
    expect(confirmDiscardDraft('t1', 'sure?', 's1')).toBe(true)
    expect(confirmSpy).not.toHaveBeenCalled()

    setEditorDirty('t1', true, 's1', '/tmp/a.ts')
    expect(confirmDiscardDraft('t1', 'sure?', 's1')).toBe(false)
    expect(confirmSpy).toHaveBeenCalledWith('sure?')
    // Declined: the draft survives.
    expect(isEditorDirty('t1', 's1')).toBe(true)

    confirmSpy.mockReturnValue(true)
    expect(confirmDiscardDraft('t1', 'sure?', 's1')).toBe(true)
    // Confirmed: the entry is cleared so a follow-up close cannot re-prompt.
    expect(isEditorDirty('t1', 's1')).toBe(false)
    // Another session's same-numbered tab is untouched by that clear.
    setEditorDirty('t1', true, 's9', '/tmp/other.ts')
    confirmSpy.mockReturnValue(false)
    expect(confirmDiscardDraft('t1', 'sure?', 's1')).toBe(true)
    expect(isEditorDirty('t1', 's9')).toBe(true)
  })

  it('a confirmed discard drops the durable draft backup too, a declined one keeps it', () => {
    // The backup is the same draft: offering it back after the user chose to
    // discard would resurrect what they just dropped.
    const release = registerDraftSource('s1', '/tmp/durable.ts', () => 'live draft')
    scheduleDraftBackup('s1', '/tmp/durable.ts')
    flushDraftBackups()
    release()
    const confirmSpy = vi.fn().mockReturnValue(false)
    vi.stubGlobal('confirm', confirmSpy)
    setEditorDirty('t1', true, 's1', '/tmp/durable.ts')

    expect(confirmDiscardDraft('t1', 'sure?', 's1')).toBe(false)
    expect(readDraftBackup('s1', '/tmp/durable.ts', 'disk')).toBe('live draft')

    confirmSpy.mockReturnValue(true)
    expect(confirmDiscardDraft('t1', 'sure?', 's1')).toBe(true)
    expect(readDraftBackup('s1', '/tmp/durable.ts', 'disk')).toBeNull()
  })
})

describe('sidebar unload guard', () => {
  it('flushes a pending durable draft and blocks the unload while a draft is dirty', () => {
    const mounted = mountSidebarWithEditor()
    const release = registerDraftSource(mounted.sessionId, '/tmp/a.ts', () => 'pending draft')
    try {
      scheduleDraftBackup(mounted.sessionId, '/tmp/a.ts')
      // The throttle has not fired: only the unload guard's flush persists it.
      expect(readDraftBackup(mounted.sessionId, '/tmp/a.ts', 'hello')).toBeNull()
      const event = new Event('beforeunload', { cancelable: true })
      act(() => { window.dispatchEvent(event) })
      expect(readDraftBackup(mounted.sessionId, '/tmp/a.ts', 'hello')).toBe('pending draft')
      expect(event.defaultPrevented, 'a dirty draft still arms the browser prompt').toBe(true)
    } finally {
      release()
      mounted.unmount()
    }
  })
})

describe('tree close-on-delete', () => {
  it('keeps a dirty tab when the user declines, closes it on confirm', () => {
    const confirmSpy = vi.fn().mockReturnValue(false)
    vi.stubGlobal('confirm', confirmSpy)
    const store = createSidebarStore()
    const service = createBetterSidebarService(store)
    service.registerTab({ id: 'editor', title: 'Files', dedupeKey: (tab) => tab.path, component: () => null })
    store.setSession('tree-close')
    const ctx = { betterSidebar: service, get: (name: string) => name === 'betterSidebar' ? service : undefined } as unknown as Context
    service.openTab({ type: 'editor', title: 'a.ts', path: '/tmp/a.ts', id: 'editor:/tmp/a.ts' })
    setEditorDirty('editor:/tmp/a.ts', true, 'tree-close', '/tmp/a.ts')

    closePathTabs(ctx, store, '/tmp/a.ts', 'discard?')
    expect(confirmSpy).toHaveBeenCalledWith('discard?')
    expect(openTabIds(store)).toContain('editor:/tmp/a.ts')

    confirmSpy.mockReturnValue(true)
    closePathTabs(ctx, store, '/tmp/a.ts', 'discard?')
    expect(openTabIds(store)).not.toContain('editor:/tmp/a.ts')
  })
})

describe('tree rename/delete reconciliation', () => {
  /**
   * A session with the editor type registered and a real native surface
   * installed on the service, exactly like the client half does. Native tabs are
   * the DEFAULT place a file opens (with a native surface installed, `openTab`
   * never touches the bottom splits), so a reconciliation that only walked
   * `bottomSplits` skipped the tabs the user actually has open.
   */
  function mountNativeSession(): {
    store: ReturnType<typeof createSidebarStore>
    service: BetterSidebarService
    records: ReturnType<typeof createNativeTabRecords>
    close: ReturnType<typeof vi.fn>
    context: Context
  } {
    const close = vi.fn()
    const controller = {
      openTab: () => {}, openResource: () => {}, close, focus: () => {},
      mounted: { getSnapshot: () => 'native-scope', subscribe: () => () => {} },
      openTabIn: () => {}, openResourceIn: () => {}, closeIn: () => {},
    }
    const records = createNativeTabRecords()
    const surfaceCtx = {
      get: (name: string) => (name === 'sidebarRight' ? controller : undefined),
      sessions: { list: { subscribe: () => () => {}, getSnapshot: () => ({}) } },
    }
    const store = createSidebarStore()
    const service = createBetterSidebarService(store)
    service.registerTab({ id: 'editor', title: 'Files', dedupeKey: (tab) => tab.path, component: () => null })
    service.setSurface(createNativeSurface(surfaceCtx as never, records))
    store.setSession('native-scope')
    const context = { betterSidebar: service, get: (name: string) => name === 'betterSidebar' ? service : undefined } as unknown as Context
    return { store, service, records, close, context }
  }

  /** One editor record bound to a file, as a native open would mint it. The
   *  title defaults to the file name, i.e. what an open derives on its own. */
  const openNativeFile = (
    records: ReturnType<typeof createNativeTabRecords>,
    id: string,
    path: string,
    seat: { sessionId?: string; cwd?: string; title?: string } = {},
  ): void => {
    const sessionId = seat.sessionId ?? 'native-scope'
    records.ensure({
      sessionId,
      id,
      kind: 'editor',
      title: seat.title ?? path.slice(path.lastIndexOf('/') + 1),
      params: { path },
      scope: seat.cwd === undefined ? { sessionId } : { sessionId, cwd: seat.cwd },
    })
  }

  // Both registries are module-level: a leaked draft would break the
  // neighbouring suites' counts, and a leftover retarget marker would suppress
  // a later test's load.
  const TEST_IDS = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5']
  const TEST_SEATS = ['native-scope', 'other-scope']
  const resetModuleRegistries = (): void => {
    for (const id of TEST_IDS) {
      clearEditorDirty(id)
      for (const seat of TEST_SEATS) clearRetargetedPath(pathTabKey(seat, id))
    }
  }
  beforeEach(resetModuleRegistries)
  afterEach(resetModuleRegistries)

  it('retargets a native tab when the FILE it shows is renamed', () => {
    const { store, records, context } = mountNativeSession()
    openNativeFile(records, 'tab1', '/ws/dir/a.ts')

    retargetPathTabs(context, store, '/ws/dir/a.ts', '/ws/dir/b.ts')

    expect(records.get('native-scope', 'tab1')?.tab).toMatchObject({ path: '/ws/dir/b.ts', title: 'b.ts' })
    // The move is announced for the editor, which keeps its document (and any
    // unsaved draft) instead of reloading the new name. Each announcement is
    // claimed once — a second claim of the same move reports false, and so does
    // a move this tab was never told about.
    const key = pathTabKey('native-scope', 'tab1')
    expect(consumeRetargetedPath(key, '/ws/dir/a.ts', '/ws/dir/b.ts')).toBe(true)
    expect(consumeRetargetedPath(key, '/ws/dir/a.ts', '/ws/dir/b.ts')).toBe(false)
    expect(consumeRetargetedPath(key, '/ws/dir/a.ts', '/ws/elsewhere.ts')).toBe(false)
  })

  it('follows the new name in the title only when the title CAME from the name', () => {
    // The host's agent-opens push carries a title of its own (the model asked
    // for that file by a label it chose: `use-host-feeds` → `openFile(scope,
    // path, title)`), and a consumer plugin may label a page itself. A rename
    // carries along the title the opener DERIVED from the file name — the
    // basename — and leaves a chosen one as it is. Both tab spaces obey it.
    const { store, service, records, context } = mountNativeSession()
    openNativeFile(records, 'tab1', '/ws/a.ts')
    openNativeFile(records, 'tab2', '/ws/a.ts', { title: 'Plan draft' })
    service.openTab({ type: 'editor', title: 'Plan draft', path: '/ws/a.ts', target: 'bottom' })

    retargetPathTabs(context, store, '/ws/a.ts', '/ws/b.ts')

    // Derived: the chip follows the file…
    expect(records.get('native-scope', 'tab1')?.tab).toMatchObject({ path: '/ws/b.ts', title: 'b.ts' })
    // …authored: the path moves, the label stays.
    expect(records.get('native-scope', 'tab2')?.tab).toMatchObject({ path: '/ws/b.ts', title: 'Plan draft' })
    const bottom = allLeaves(store.getSnapshot().state!.bottomSplits)
      .flatMap(leaf => leaf.tabs).find(tab => tab.path !== undefined)
    expect(bottom).toMatchObject({ path: '/ws/b.ts', title: 'Plan draft' })
  })

  it('retargets a tab opened from a CHAT LINK (its address stores a workspace-relative path)', () => {
    // `fileAddressFor` spells a path inside the workspace relatively, so a tab
    // opened from chat holds `src/a.ts` while the tree renames by absolute path.
    // Comparing the two raw skipped exactly those tabs — the default way a file
    // reaches this column — and left them bound to the name the user had just
    // renamed away.
    const { store, records, context } = mountNativeSession()
    openNativeFile(records, 'tab2', 'src/a.ts', { cwd: '/ws' })

    retargetPathTabs(context, store, '/ws/src/a.ts', '/ws/src/b.ts')

    // The tab follows to the new name, spelled absolutely now: `fs.write`
    // resolves either spelling, and the record keeps the host's address until
    // the host navigates it again.
    expect(records.get('native-scope', 'tab2')?.tab.path).toBe('/ws/src/b.ts')
    // The announcement carries the tab's OWN old spelling — what its editor
    // compares against.
    expect(consumeRetargetedPath(pathTabKey('native-scope', 'tab2'), 'src/a.ts', '/ws/src/b.ts')).toBe(true)
  })

  it('keeps one seat\'s pending move when another seat clears its own (native ids restart per session)', () => {
    // `tab1` names a tab in EVERY conversation, so a rename reaches two seats at
    // once. Keyed by the id alone they shared one marker: whichever editor ran
    // its effect first (even one whose own path did not move — it clears what it
    // finds) wiped the other's pending move, and that editor reloaded the
    // renamed file with the draft this mechanism exists to protect.
    const { store, records, context } = mountNativeSession()
    openNativeFile(records, 'tab1', '/ws/a.ts')
    openNativeFile(records, 'tab1', '/ws/a.ts', { sessionId: 'other-scope' })

    retargetPathTabs(context, store, '/ws/a.ts', '/ws/b.ts')

    expect(records.get('native-scope', 'tab1')?.tab.path).toBe('/ws/b.ts')
    expect(records.get('other-scope', 'tab1')?.tab.path).toBe('/ws/b.ts')
    const here = pathTabKey('native-scope', 'tab1')
    const there = pathTabKey('other-scope', 'tab1')
    clearRetargetedPath(here)
    expect(consumeRetargetedPath(there, '/ws/a.ts', '/ws/b.ts')).toBe(true)
    expect(consumeRetargetedPath(here, '/ws/a.ts', '/ws/b.ts')).toBe(false)
  })

  it('keeps the loaded document when a rename moves an OPEN tab (the draft survives)', async () => {
    const mounted = mountSidebarWithEditor()
    try {
      await act(async () => { await Promise.resolve() })
      const readsBefore = fsRead.mock.calls.length
      const tabOf = (): { id: string; path?: string } => allLeaves(mounted.store.getSnapshot().state!.bottomSplits)
        .flatMap(leaf => leaf.tabs).find(candidate => candidate.path !== undefined)!
      const id = tabOf().id
      expect(isEditorDirty(id)).toBe(true)

      const context = {
        get: (name: string) => name === 'betterSidebar' ? mounted.service : undefined,
      } as unknown as Context
      act(() => { retargetPathTabs(context, mounted.store, '/tmp/a.ts', '/tmp/b.ts') })
      await act(async () => { await Promise.resolve() })

      // The tab follows the file…
      expect(tabOf().path).toBe('/tmp/b.ts')
      // …without re-reading it: a reload would replace the document with the
      // same bytes and drop the draft, which lives only in the editor.
      expect(fsRead.mock.calls.length).toBe(readsBefore)
      expect(isEditorDirty(id)).toBe(true)
    } finally {
      mounted.unmount()
    }
  })

  it('retargets the SUBTREE when a directory is renamed (both tab spaces)', () => {
    const { store, service, records, context } = mountNativeSession()
    openNativeFile(records, 'tab2', '/ws/dir/deep/a.ts')
    // …and one in the bottom workbench (`target: 'bottom'` is the one open that
    // stays in the plugin's own layout), which the old code DID walk but only
    // for an exact path match.
    service.openTab({ type: 'editor', title: 'c.ts', path: '/ws/dir/c.ts', target: 'bottom' })
    const before = records.get('native-scope', 'tab2')?.tab.path

    retargetPathTabs(context, store, '/ws/dir', '/ws/renamed')

    expect(before).toBe('/ws/dir/deep/a.ts')
    expect(records.get('native-scope', 'tab2')?.tab.path).toBe('/ws/renamed/deep/a.ts')
    const bottom = allLeaves(store.getSnapshot().state!.bottomSplits)
      .flatMap(leaf => leaf.tabs).find(tab => tab.path !== undefined)
    expect(bottom?.path).toBe('/ws/renamed/c.ts')
  })

  it('closes a native tab when its FILE is deleted, asking first when dirty', () => {
    const confirmSpy = vi.fn().mockReturnValue(false)
    vi.stubGlobal('confirm', confirmSpy)
    const { store, records, close, context } = mountNativeSession()
    openNativeFile(records, 'tab3', '/ws/a.ts')
    // The editor host registers the draft under the NATIVE tab id.
    setEditorDirty('tab3', true, 'native-scope', '/ws/a.ts')

    closePathTabs(context, store, '/ws/a.ts', 'discard?')
    expect(confirmSpy).toHaveBeenCalledWith('discard?')
    expect(records.has('native-scope', 'tab3')).toBe(true)
    expect(close).not.toHaveBeenCalled()

    confirmSpy.mockReturnValue(true)
    closePathTabs(context, store, '/ws/a.ts', 'discard?')
    expect(records.has('native-scope', 'tab3')).toBe(false)
    // The host's own tab really closes too (the record alone would leave an
    // empty pane behind).
    expect(close).toHaveBeenCalledWith('tab3')
  })

  it('closes native tabs under a deleted DIRECTORY', () => {
    const { store, records, context } = mountNativeSession()
    openNativeFile(records, 'tab4', '/ws/dir/deep/a.ts')
    openNativeFile(records, 'tab5', '/ws/other.ts')

    closePathTabs(context, store, '/ws/dir', 'discard?')

    expect(records.has('native-scope', 'tab4')).toBe(false)
    expect(records.has('native-scope', 'tab5')).toBe(true)
  })

  /** The file paths one session's bottom workbench has open (tree order). */
  const bottomPaths = (store: SidebarStore, sessionId: string): string[] => {
    const state = store.getSessionStates().get(sessionId)
    if (state === undefined) return []
    return allLeaves(state.bottomSplits)
      .flatMap(leaf => leaf.tabs)
      .flatMap(tab => (tab.path === undefined ? [] : [tab.path]))
  }

  it('retargets a BACKGROUND session\'s bottom-workbench page (every cached session is walked)', () => {
    // The bottom workbench is per session, and a file can live there on purpose
    // (`target: 'bottom'`) or in a layout persisted back when files landed in
    // the workbench. The reconciliation used to read the ACTIVE session's state
    // alone, so a background conversation's page kept the old path and its next
    // save recreated the renamed-away file — the same data problem, one
    // conversation over.
    const { store, service, context } = mountNativeSession()
    service.openTab(
      { type: 'editor', title: 'a.ts', path: '/ws/a.ts', target: 'bottom' },
      { sessionId: 'other-scope' },
    )
    expect(bottomPaths(store, 'other-scope')).toEqual(['/ws/a.ts'])
    expect(store.getSnapshot().sessionId).toBe('native-scope')

    retargetPathTabs(context, store, '/ws/a.ts', '/ws/b.ts')

    // The page follows the file in ITS session…
    expect(bottomPaths(store, 'other-scope')).toEqual(['/ws/b.ts'])
    // …while the session on screen is neither written to nor re-published: a
    // targeted write never touches the snapshot the shell renders from.
    expect(store.getSnapshot().sessionId).toBe('native-scope')
    expect(bottomPaths(store, 'native-scope')).toEqual([])
  })

  it('closes a BACKGROUND session\'s page on delete, asking about ITS draft', () => {
    const confirmSpy = vi.fn().mockReturnValue(true)
    vi.stubGlobal('confirm', confirmSpy)
    const { store, service, context } = mountNativeSession()
    service.openTab(
      { type: 'editor', title: 'a.ts', path: '/ws/a.ts', target: 'bottom' },
      { sessionId: 'other-scope' },
    )
    const row = allLeaves(store.getSessionStates().get('other-scope')!.bottomSplits)
      .flatMap(leaf => leaf.tabs).find(tab => tab.path === '/ws/a.ts')!
    // The editor behind that page registered its draft in ITS session, so the
    // question has to be asked there — read against the active session the
    // record would not be found and the tab would close unprompted.
    setEditorDirty(row.id, true, 'other-scope', '/ws/a.ts')

    closePathTabs(context, store, '/ws/a.ts', 'discard?')

    expect(confirmSpy).toHaveBeenCalledWith('discard?')
    expect(bottomPaths(store, 'other-scope')).toEqual([])
    expect(store.getSnapshot().sessionId).toBe('native-scope')
  })
})

describe('EditorHost dirty registration', () => {
  it('registers the open tab and clears it when the host unmounts', async () => {
    const store = createSidebarStore()
    const service = createBetterSidebarService(store)
    service.registerTab({ id: 'editor', title: 'Files', dedupeKey: (tab) => tab.path, component: () => null })
    service.registerFileViewer({ id: 'mock-text', exts: ['ts'], fetchStrategy: 'fsRead', component: DirtyViewer })
    store.setSession('editor-host-dirty')
    const ctx = { betterSidebar: service, get: (name: string) => name === 'betterSidebar' ? service : undefined } as unknown as Context
    service.openTab({ type: 'editor', title: 'a.ts', path: '/tmp/a.ts', id: 'editor:/tmp/a.ts' })
    const tab = allLeaves(store.getSnapshot().state!.bottomSplits).flatMap(leaf => leaf.tabs)
      .find(candidate => candidate.path === '/tmp/a.ts')!
    const mounted = renderRoot(createElement(EditorHost, {
      ctx, store, scope: { sessionId: 'editor-host-dirty' }, tab,
      expanded: [], revealed: [], onToggleDir: () => {}, onReferenceFile: () => {},
    }))
    await act(async () => { await Promise.resolve() })
    expect(isEditorDirty(tab.id, 'editor-host-dirty')).toBe(true)
    mounted.unmount()
    expect(isEditorDirty(tab.id, 'editor-host-dirty')).toBe(false)
  })
})

describe('close guard', () => {
  it('cancel keeps the tab open and confirm closes it', async () => {
    const confirmSpy = vi.fn()
    vi.stubGlobal('confirm', confirmSpy)
    const mounted = mountSidebarWithEditor()
    try {
      await act(async () => { await Promise.resolve() })
      expect(openTabIds(mounted.store)).toContain('editor:/tmp/a.ts')
      expect(isEditorDirty('editor:/tmp/a.ts', mounted.sessionId)).toBe(true)

      // Cancel: the tab survives and stays dirty.
      confirmSpy.mockReturnValue(false)
      click(closeButton(mounted.container))
      expect(confirmSpy).toHaveBeenCalledTimes(1)
      expect(openTabIds(mounted.store)).toContain('editor:/tmp/a.ts')
      expect(isEditorDirty('editor:/tmp/a.ts', mounted.sessionId)).toBe(true)

      // Confirm: the tab closes.
      confirmSpy.mockReturnValue(true)
      click(closeButton(mounted.container))
      expect(confirmSpy).toHaveBeenCalledTimes(2)
      expect(openTabIds(mounted.store)).not.toContain('editor:/tmp/a.ts')
    } finally {
      mounted.unmount()
    }
  })

  it('a clean tab closes without prompting', async () => {
    const confirmSpy = vi.fn().mockReturnValue(false)
    vi.stubGlobal('confirm', confirmSpy)
    const mounted = mountSidebarWithEditor()
    try {
      await act(async () => { await Promise.resolve() })
      clearEditorDirty('editor:/tmp/a.ts', mounted.sessionId)
      click(closeButton(mounted.container))
      expect(confirmSpy).not.toHaveBeenCalled()
      expect(openTabIds(mounted.store)).not.toContain('editor:/tmp/a.ts')
    } finally {
      mounted.unmount()
    }
  })
})
