/**
 * Host glue for the e2e lanes: page/asset URL construction, the authenticated
 * request context, and the host RPC. The transport contracts (one-time-token
 * launch URL, slash `/api` endpoints) live in ./host-protocol.ts; this
 * module only wires them to Playwright.
 *
 * Every lane consumes the same contract:
 * - `PAGE_URL` / `pageUrl({...})` for page.goto (the token URL performs the
 *   browser's token→cookie exchange),
 * - `sidebarApi(path)` for the plugin's own public routes,
 * - `createHostApi()` for an APIRequestContext carrying the auth cookie,
 * - `hostRpc(api, 'workspace.create', {...})` for the host's unary RPC.
 */
import { expect, request, type APIRequestContext, type Page } from '@playwright/test'
import { parseLaunchUrl, pageUrlWith, rpcAttempt } from './host-protocol'

const envUrl = process.env.DSH_E2E_URL
if (!envUrl) {
  throw new Error('DSH_E2E_URL is not set — boot a DSH web instance with the plugin mounted and point this lane at it (see scripts/e2e-mount.sh)')
}
// Re-bind with an explicit string type: closure bodies below do not inherit
// the guard's narrowing of envUrl.
const RAW_URL: string = envUrl

const LAUNCH = parseLaunchUrl(RAW_URL)

/** Origin for URL construction (a token URL would corrupt path joins). */
export const ORIGIN = LAUNCH.origin

/** page.goto target: the launch URL as printed (token included —
 *  navigating it exchanges the token for the cookie). */
export const PAGE_URL = LAUNCH.pageUrl

/** page.goto target with extra query stamps merged (token preserved). */
export function pageUrl(extra: Record<string, string>): string {
  return pageUrlWith(RAW_URL, extra)
}

/** Absolute URL for the plugin's own (public, unauthenticated) API route. */
export function sidebarApi(path: string): string {
  return `${ORIGIN}/sidebar/api/${path}`
}

/** Exchange the one-time launch token for the auth-cookie header pair: the
 *  token URL answers 303 with Set-Cookie (following the redirect would lose
 *  it, hence `redirect: 'manual'`). Pure aside from the injected fetch —
 *  unit tests stub it (tests/e2e-host-protocol.spec.ts). */
export async function exchangeLaunchCookie(
  launchUrl: string,
  fetchImpl: typeof fetch = fetch,
): Promise<string> {
  const res = await fetchImpl(launchUrl, { redirect: 'manual' })
  const setCookie = res.headers.get('set-cookie')
  if (setCookie === null) {
    throw new Error(`token exchange failed: HTTP ${res.status} carried no set-cookie — cannot authenticate /api seeding`)
  }
  return setCookie.split(';', 1)[0] ?? ''
}

/** The `name=value` pair of the auth cookie, once per process. */
let cookieHeader: string | undefined

/**
 * Exchange the launch token through Playwright's own request stack.
 *
 * {@link exchangeLaunchCookie} takes any `fetch`, but the Node global one
 * cannot stand in for a browser here: the host's static fallback answers a
 * plain Node GET of the token URL with an empty `405` and no `Set-Cookie`
 * (reproduced on both `0.1.5-rc.2` and `0.1.7-alpha.1`, so it is a harness
 * quirk rather than a host regression), which left every later `/api` call
 * unauthenticated and the lane's session seeding dead. Playwright's request
 * context speaks enough of a browser shape to complete the exchange, and
 * `maxRedirects: 0` keeps the `303` from being followed — following it drops
 * the `Set-Cookie` this exists to capture.
 * @param launchUrl - the token URL as printed by the host.
 * @returns the `name=value` cookie pair.
 */
export async function exchangeLaunchCookieViaPlaywright(launchUrl: string): Promise<string> {
  const context = await request.newContext()
  try {
    await context.get(launchUrl, { maxRedirects: 0 })
    const [cookie] = (await context.storageState()).cookies
    if (cookie === undefined) {
      throw new Error('token exchange produced no cookie — cannot authenticate /api seeding')
    }
    return `${cookie.name}=${cookie.value}`
  } finally {
    await context.dispose()
  }
}

/** The exchanged cookie pair, memoised for the process. */
async function authCookie(): Promise<string> {
  cookieHeader ??= await exchangeLaunchCookieViaPlaywright(RAW_URL)
  return cookieHeader
}

/** page.goto through the host auth. A plain navigation goes to PAGE_URL (the
 *  token URL performs the browser's exchange), but a STAMPED navigation
 *  cannot: the exchange answers `303 → /` and silently DROPS every sibling
 *  query param (the mount lane caught the desktop-shell stamps vanishing
 *  this way), so pre-seed the browser context with the exchanged cookie and
 *  navigate the stamped URL directly. Playwright gives every test a fresh
 *  context, so the seeding is per-call and idempotent. */
export async function gotoPage(page: Page, extra: Record<string, string> = {}): Promise<void> {
  if (Object.keys(extra).length > 0) {
    const header = await authCookie()
    const eq = header.indexOf('=')
    await page.context().addCookies([{
      name: header.slice(0, eq),
      value: header.slice(eq + 1),
      url: ORIGIN,
    }])
    await page.goto(pageUrlWith(ORIGIN, extra), { waitUntil: 'domcontentloaded' })
    return
  }
  await page.goto(pageUrl(extra), { waitUntil: 'domcontentloaded' })
}

/** Dismiss keyless onboarding before interacting with the shell. */
export async function dismissOnboarding(page: Page): Promise<void> {
  // alpha.5's Close belongs to Get started, not to another panel or dialog.
  const getStarted = page.getByRole('dialog', { name: 'Get started', exact: true })
  const buttons = [
    getStarted.getByRole('button', { name: 'Close', exact: true }),
    page.getByRole('button', { name: 'Continue', exact: true }),
    page.getByRole('button', { name: 'Configure later', exact: true }),
  ]
  try {
    await expect.poll(async () => {
      const counts = await Promise.all(buttons.map(button => button.count()))
      return counts.reduce((total, count) => total + count, 0)
    }, { timeout: 60_000 }).toBeGreaterThan(0)
  } catch {
    // A previously acknowledged onboarding may not appear again.
    return
  }
  for (let round = 0; round < 8; round++) {
    let dismissed = false
    for (const button of buttons) {
      if (await button.count() === 0) continue
      try {
        await button.click({ timeout: 4_000 })
        dismissed = true
        await page.waitForTimeout(1_000)
      } catch {
        // A stacked welcome notice can mask another onboarding step.
      }
    }
    if (!dismissed) break
  }
  await expect(getStarted).not.toBeVisible()
}

/** Authenticated request context for host RPC seeding (cookie attached). */
export async function createHostApi(): Promise<APIRequestContext> {
  return request.newContext({
    baseURL: ORIGIN,
    extraHTTPHeaders: { cookie: await authCookie() },
  })
}

/** The unwrapped `result` of a successful host RPC. */
export interface HostRpcOk<T> {
  ok: true
  value: T
}

let rpcCounter = 0

/** Call a host unary RPC (`'workspace.create'`, `'session.create'`, …).
 *  Throws with the response body when the HTTP call or the envelope result
 *  fails — the lanes' seeding treats any failure as fatal, so the error text
 *  carries everything a report needs. */
export async function hostRpc<T = unknown>(
  api: APIRequestContext,
  method: string,
  args: Record<string, unknown> = {},
): Promise<HostRpcOk<T>> {
  const attempt = rpcAttempt(method, args)
  rpcCounter += 1
  const rpcId = `e2e-${method}-${rpcCounter}`
  const res = await api.post(attempt.path, {
    data: { type: 'client-request', rpcId, method: attempt.method, payload: attempt.payload },
  })
  const bodyText = await res.text()
  if (!res.ok()) {
    throw new Error(`hostRpc ${method} [${attempt.path}] HTTP ${res.status()}: ${bodyText.slice(0, 400)}`)
  }
  let envelope: { type?: string; result?: { ok: true; value: T } | { ok: false; error: unknown } }
  try {
    envelope = JSON.parse(bodyText) as typeof envelope
  } catch {
    throw new Error(`hostRpc ${method} [${attempt.path}]: non-JSON response: ${bodyText.slice(0, 400)}`)
  }
  const result = envelope.result
  if (result === undefined || result.ok !== true) {
    throw new Error(`hostRpc ${method} [${attempt.path}] envelope error: ${bodyText.slice(0, 400)}`)
  }
  return result
}

/**
 * The host composer's editable. Role+name: the placeholder label only exists
 * on the empty composer, so this is for the first-message path — once the
 * session has content the accessible name changes.
 * @param page - the lane's page.
 */
export function composerLocator(page: Page) {
  return page.getByRole('textbox', { name: /^(Describe what you want to build|描述你想要构建)/ })
}

/**
 * The composer's editable once the session already has content — the
 * placeholder name is gone by then. Anchored on the host's composer slot
 * rather than a bare `[contenteditable]` match: the plugin's own CodeMirror
 * surface is also contenteditable and stays in the DOM (merely hidden) in
 * preview mode.
 * @param page - the lane's page.
 */
export function composerEditable(page: Page) {
  return page.locator('[data-slot="conversation.composer.bar"] [contenteditable="true"]').first()
}

/**
 * Send one message in the session the shell opened, so the conversation header
 * (and the native right Sidebar's corner control) exists: DSH renders the
 * header only for a session with content, while a freshly seeded blank
 * session shows the empty hero.
 *
 * DSH 0.1.5's composer is a Lexical contenteditable — `fill()` writes the DOM
 * but not the editor model, so the send button would stay disabled. Type real
 * keys instead.
 * @param page - the lane's page.
 */
export async function sendFirstMessage(page: Page): Promise<void> {
  const composer = composerLocator(page)
  await expect(composer).toBeVisible({ timeout: 60_000 })
  await composer.click()
  await page.keyboard.type('mount lane smoke')
  const send = page.getByRole('button', { name: /^(Send message|发送消息)$/ })
  await expect(send).toBeEnabled({ timeout: 30_000 })
  await send.click()
}
