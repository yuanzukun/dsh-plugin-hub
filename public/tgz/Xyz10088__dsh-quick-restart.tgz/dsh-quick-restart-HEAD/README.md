# dsh-quick-restart

> **装完新插件/新技能，点一下「刷新 DSH」就生效 —— 不用手动重启。**
> **New plugin or skill installed? One click on "Refresh DSH" and it's live — no manual restart.**

English | [中文](#中文)

---

## 中文

### ✨ 卖点：一键生效，告别手动重启

装完新插件（dsh-market 里安装的、或 `dsh plugin add` 装的）或新技能（放进 `~/.dsh/skills` 的）之后，**不用在终端里手动重启 dsh**——点一下侧边栏的「刷新 DSH」按钮：

1. 服务自动重启（后台完成，页面提示「请等待约 20 秒」）
2. 新插件 / 新技能全部加载生效
3. 服务恢复后**页面自动刷新**，无需任何手动操作

比命令行手动重启更省事：**一个按钮完成全部**，页面还会自己恢复。

### 功能

- 侧边栏底部「刷新 DSH」按钮，带在线状态灯（绿=在线 / 红=离线）
- 单击直接触发，无需二次确认；点击后弹出等待提示
- 服务恢复后页面**自动重载**，无需手动刷新
- 重启命令带 `--no-open`，不会额外打开浏览器页面
- 通过 `/dsh-health` 每 5 秒探测服务健康状态

### 安装

```sh
# 本地目录安装
dsh plugin --profile web add link:/path/to/dsh-quick-restart

# 或从 GitHub
dsh plugin --profile web add github:Xyz10088/dsh-quick-restart#main

# 或使用预构建包（推荐）
dsh plugin --profile web add https://github.com/Xyz10088/dsh-quick-restart/releases/download/v0.1.0/dsh-quick-restart-0.1.0.tgz
```

重启 `dsh web`，侧边栏底部即出现「刷新 DSH」按钮。

### 工作原理

- **host 半区**（`lib/index.js`）：注册 `POST /restart-dsh` 与 `GET /dsh-health` 路由；重启处理器以分离进程拉起重启脚本，脚本杀掉 3080 端口监听进程后重新启动 `dsh web`（`--no-open`）。
- **client 半区**（`lib/client.js`）：注册 `sidebar.footer.action` 槽位按钮；点击后 `POST /restart-dsh`，随后轮询 `/dsh-health`，观察到服务离线→恢复后自动 `location.reload()`。

> 注意：`lib/index.js` 中 `RESTART_SCRIPT` 常量默认指向 `C:\Users\Administrator\.dsh\desktop-launcher\restart-dsh-web.ps1`，不同机器请按需修改为你自己的重启/启动命令。

### 卸载

```sh
dsh plugin --profile web remove dsh-quick-restart
```

### License

MIT

---

## English

### ✨ Selling point: one click to activate, no manual restart

Installed a new plugin (from dsh-market or `dsh plugin add`) or a new skill (dropped into `~/.dsh/skills`)? No need to manually restart dsh from the terminal — just click the **"Refresh DSH"** button in the sidebar:

1. The service restarts in the background (a toast says "please wait ~20s")
2. New plugins / skills are all loaded and live
3. The page **auto-reloads** once the service is back — zero manual steps

Easier than a manual command-line restart: **one button does it all**, and the page recovers by itself.

### Features

- "Refresh DSH" button in the sidebar footer with a live status dot (green = online / red = offline)
- Single click triggers the refresh, no confirmation step; a toast appears on click
- Page **auto-reloads** once the service is back — no manual refresh needed
- Restart command uses `--no-open` so no extra browser tab is opened
- Probes service health via `/dsh-health` every 5 seconds

### Install

```sh
# from a local directory
dsh plugin --profile web add link:/path/to/dsh-quick-restart

# or from GitHub
dsh plugin --profile web add github:Xyz10088/dsh-quick-restart#main

# or use the prebuilt package (recommended)
dsh plugin --profile web add https://github.com/Xyz10088/dsh-quick-restart/releases/download/v0.1.0/dsh-quick-restart-0.1.0.tgz
```

Restart `dsh web`, and the "Refresh DSH" button appears at the sidebar footer.

### How it works

- **Host half** (`lib/index.js`): registers `POST /restart-dsh` and `GET /dsh-health` routes; the handler launches a detached restart script that kills the process listening on port 3080 and starts `dsh web` again (`--no-open`).
- **Client half** (`lib/client.js`): registers a button in the `sidebar.footer.action` slot; on click it POSTs `/restart-dsh`, then polls `/dsh-health` — once the service is observed down and then back up, it calls `location.reload()`.

> Note: the `RESTART_SCRIPT` constant in `lib/index.js` defaults to `C:\Users\Administrator\.dsh\desktop-launcher\restart-dsh-web.ps1` — adjust it to your own restart/launch command on other machines.

### Uninstall

```sh
dsh plugin --profile web remove dsh-quick-restart
```

### License

MIT
