<#
.SYNOPSIS
  dsh-proxy-auto 体检脚本：确认插件装好了、宿主依赖齐全、自测通过。

.DESCRIPTION
  一条命令给出可贴出来的结论，适合装完/升级后/出问题时先跑这个：

    1. 定位 DSH 安装与 profile（不写盘：内部用 install.ps1 -Check）
    2. 静态自检：插件文件齐全、patch 结构正确、宿主依赖存在、profile 已登记
    3. 运行两套自测（无 DSH 的机器上宿主相关用例会自动 SKIP）
    4. 打印诊断快照的关键字段（若插件已在运行）

.PARAMETER Profile
  要检查的 profile（默认 desktop）。

.PARAMETER SkipTests
  跳过自测（只做静态检查，最快）。

.EXAMPLE
  pwsh -File .\verify.ps1
  pwsh -File .\verify.ps1 -Profile web -SkipTests
#>
[CmdletBinding()]
param(
  [string]$Profile = 'desktop',
  [switch]$SkipTests
)

$ErrorActionPreference = 'Continue'
$root = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
# DSH_HOME → 否则用平台对应的主目录（USERPROFILE 只在 Windows 有；HOME 覆盖 Unix）。
$homeDir = if ($env:USERPROFILE) { $env:USERPROFILE } elseif ($env:HOME) { $env:HOME } else { (Get-Location).Path }
$dshHome = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $homeDir '.dsh' }
$statePath = Join-Path $dshHome 'cache/dsh-proxy-auto/state.json'
$failures = 0

function Section($title) { Write-Host ""; Write-Host "== $title" -ForegroundColor Cyan }

<#
  输出脱敏：本机用户名 / 主目录 / AppData 一律替换后再打印。
  理由：这份输出最常被贴到 issue 或聊天里求助，不该顺带暴露账户名与目录结构。
#>
function Mask($text) {
  $out = [string]$text
  if ($env:USERNAME) { $out = $out.Replace($env:USERNAME, '<user>') }
  if ($env:USERPROFILE) { $out = $out.Replace($env:USERPROFILE, '~') }
  if ($dshHome) { $out = $out.Replace($dshHome, '~/.dsh') }
  if ($env:APPDATA) { $out = $out.Replace($env:APPDATA, '<appdata>') }
  if ($env:LOCALAPPDATA) { $out = $out.Replace($env:LOCALAPPDATA, '<localappdata>') }
  $out = $out -replace '(?i)[A-Z]:\\Users\\[^\\]+', '<home>'
  return $out
}

function Ok($text) { Write-Host "  [OK]   $(Mask $text)" -ForegroundColor Green }
function Bad($text) { Write-Host "  [FAIL] $(Mask $text)" -ForegroundColor Red; $script:failures++ }
function Info($text) { Write-Host "  [info] $(Mask $text)" -ForegroundColor Gray }

Section '1. 静态自检（含 profile 登记）'
# 共用探测（与 install.ps1 同一份）：npm 全局形态 / Electron 桌面形态（app.asar）都能认。
. (Join-Path $root 'lib/resolve-dsh-install.ps1')
$dshInstall = Resolve-DshInstall
if ($dshInstall) { Info "DSH 安装：$dshInstall" }
$checkScript = Join-Path $root 'install.ps1'
if (Test-Path $checkScript) {
  # *>&1：把信息流也纳入管道——子脚本用 Write-Host 打印的内容同样要过脱敏（它不走管道是踩过的坑）。
  & $checkScript -Profile $Profile -Check *>&1 | ForEach-Object { Write-Host "  $(Mask $_)" }
  if ($LASTEXITCODE -ne 0) { Bad 'install.ps1 -Check 报告异常' }
} else {
  Bad "缺少 install.ps1（$checkScript）"
}

Section '1.5 宿主依赖（借宿主运行时实测；PowerShell 看不到 app.asar 内部）'
if ($dshInstall -match '\.asar') {
  $idx = $dshInstall.IndexOf('\resources\', [StringComparison]::OrdinalIgnoreCase)
  $appRoot = if ($idx -gt 0) { $dshInstall.Substring(0, $idx) } else { $dshInstall }
  $hostExe = @(Get-ChildItem -LiteralPath $appRoot -Filter '*.exe' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notmatch 'Uninstall|elevate' } | Select-Object -First 1).FullName
  $probeScript = Join-Path $root 'lib/probe-host-deps.mjs'
  $probe = $null
  if ($hostExe -and (Test-Path $probeScript)) {
    try {
      $savedRunAsNode = $env:ELECTRON_RUN_AS_NODE
      $env:ELECTRON_RUN_AS_NODE = '1'
      $probeText = (& $hostExe $probeScript 2>$null | Out-String)
      if ($null -eq $savedRunAsNode) { Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
      else { $env:ELECTRON_RUN_AS_NODE = $savedRunAsNode }
      $probe = $probeText | ConvertFrom-Json
    } catch { $probe = $null }
  }
  if ($probe) {
    Ok "宿主运行时：node $($probe.node)$(if ($probe.electron) { " / electron $($probe.electron)" })"
    foreach ($name in @('@deepseek-ai/schemastery', '@deepseek-ai/dsh-http-proxy', 'undici')) {
      $d = $probe.deps.$name
      if ($d.ok) { Ok "$name → $($d.resolved)" } else { Bad "$name 无法解析（插件运行期会缺这条腿）" }
    }
  } else {
    Info "未能运行宿主探针（hostExe=$(Mask $hostExe)）；asar 内的依赖无法在 PowerShell 侧验证"
  }
} else {
  # 非 asar 形态：用最朴素的 Test-Path 就够，不必起宿主进程。
  foreach ($pair in @(
      @('@deepseek-ai/schemastery', '宿主有 schemastery'),
      @('@deepseek-ai/dsh-http-proxy', '宿主有 dsh-http-proxy'),
      @('undici', '宿主有 undici')
    )) {
    $p = Join-Path $dshInstall "node_modules/$($pair[0])/package.json"
    if (Test-Path $p) { Ok "$($pair[1])" } else { Bad "$($pair[1])（缺 $p）" }
  }
}

Section '2. 运行环境'
Info "PowerShell : $($PSVersionTable.PSVersion)"
Info "平台       : $([System.Environment]::OSVersion.Platform)（$($PSVersionTable.Platform)）"
Info "Node       : $(try { (& node --version) } catch { '未找到' })"
# 注意：APPDATA 只在 Windows 存在；直接 Join-Path 会在 Linux/macOS 上抛错（曾经就这么崩）。
if ($env:APPDATA) {
  $dshPkg = Join-Path $env:APPDATA 'npm\node_modules\@deepseek-ai\dsh\package.json'
  if (Test-Path $dshPkg) {
    Ok "DSH 安装（npm 全局）：$(Split-Path $dshPkg -Parent)"
  } elseif ($dshInstall) {
    Ok "DSH 安装（已探测）：$dshInstall"
  } else {
    Info '未在默认位置找到 DSH（自定义安装属正常）'
  }
} else {
  Info '非 Windows：跳过系统代理注册表与默认安装位置检查（插件仍可用，走环境变量探测）'
}

if (-not $SkipTests) {
  Section '3. 自测'
  # 发布包未必带 test/（手工打的 zip、或安装方式未覆盖）：缺失时跳过，而不是误报"未通过"。
  $testFiles = @('test/standalone.mjs', 'test/selftest.mjs') | Where-Object { Test-Path (Join-Path $root $_) }
  if ($testFiles.Count -eq 0) {
    Info '本目录不含 test/，跳过自测（确认插件本身请在有源码的目录下运行）'
  } else {
    Push-Location $root
    try {
      foreach ($t in $testFiles) {
        & node $t
        if ($LASTEXITCODE -ne 0) { Bad "$t 未通过" } else { Ok "$t 通过" }
      }
    } finally {
      Pop-Location
    }
  }
}

Section '4. 运行状态（插件已加载时才有）'
if (Test-Path $statePath) {
  try {
    $state = Get-Content $statePath -Raw | ConvertFrom-Json
    Info "快照时间   : $($state.at)"
    Info "代理判定   : $(if ($state.proxy) { $state.proxy } else { '直连' })（依据：$($state.source)）"
    Info "dispatcher : $(if ($state.dispatcherPatched) { '已按代理路由' } else { '直连' })"
    Info "官方 seam  : $(if ($state.seamLoaded) { $state.seamRoute } else { '未装载' })"
    if ($state.probe) {
      $probeText = if ($state.probe.ok) { "成功 HTTP $($state.probe.status) / $($state.probe.ms) ms" } else { "失败（$($state.probe.error)）" }
      Info "自证探针   : $probeText"
    }
  } catch {
    Bad "快照无法解析：$statePath"
  }
} else {
  Info "尚无快照（$statePath）——插件可能未加载，或还没跑过一个检测周期"
}

Section '5. 仓库完整性（防止 git 元数据被安装流程碰坏）'
# 背景：GUI 里从 GitHub 安装同名插件时，若 profile 里原本是 link: 指向同一目录，
# 替换/回滚路径可能削掉 .git 的部分文件（HEAD / config / index / packed-refs）。
# 表现为 git 突然报 "not a git repository"。这里提前体检，别等 git 报错才发现。
$gitDir = Join-Path $root '.git'
if (-not (Test-Path $gitDir)) {
  Info '不是 git 检出（从 Release 的 zip 解压安装时属正常，无需处理）'
} else {
  $required = 'HEAD', 'config', 'objects', 'refs'
  $missing = @()
  foreach ($item in $required) {
    if (-not (Test-Path (Join-Path $gitDir $item))) { $missing += $item }
  }
  # index 只有在已有提交的仓库里才必然存在
  if (-not (Test-Path (Join-Path $gitDir 'index'))) { $missing += 'index' }

  if ($missing.Count -gt 0) {
    Bad ".git 元数据不完整，缺少：$($missing -join ', ')"
    Write-Host '         修复办法（工作区文件不会丢，提交都已在远端）：' -ForegroundColor Yellow
    Write-Host '           Move-Item .git .git.broken' -ForegroundColor Gray
    Write-Host '           git init -b main; git remote add origin <仓库地址>' -ForegroundColor Gray
    Write-Host '           git fetch origin --tags; git reset --mixed origin/main' -ForegroundColor Gray
  } else {
    # 让 git 自己确认一遍（比逐个文件更权威）
    $head = & git -C $root rev-parse --short HEAD 2>$null
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($head)) {
      Bad 'git 元数据文件都在，但 git 仍无法识别该仓库（可能指向了错误的目录或对象库损坏）'
    } else {
      $branch = & git -C $root rev-parse --abbrev-ref HEAD 2>$null
      Ok "git 仓库完好：$branch @ $head"
      $dirty = & git -C $root status --porcelain 2>$null
      if ($dirty) { Info "工作区有 $($dirty.Count) 处未提交改动（开发中属正常）" } else { Info '工作区干净' }
      $upstream = & git -C $root rev-parse --short origin/main 2>$null
      if ($upstream) {
        Info "本地 $head / origin/main $upstream$(if ($head -eq $upstream) { '（已同步）' } else { '（不一致，注意）' })"
      }
    }
  }
}

Section '结论'
if ($failures -eq 0) {
  Write-Host "  体检通过。若代理开着但抓不到墙外页面，请把上面第 4 节的内容贴出来排查。" -ForegroundColor Green
} else {
  Write-Host "  有 $failures 项失败，请看上面的 [FAIL] 行。" -ForegroundColor Red
}
exit $failures
