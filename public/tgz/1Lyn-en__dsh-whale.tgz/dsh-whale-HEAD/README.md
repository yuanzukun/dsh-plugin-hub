<div align="center">

<img src="assets/whale-icon.png" alt="dsh-whale" width="120" height="120" />

# 🐳 dsh-whale

> 鲸鱼不废话，少词办大事
>
> DeepSeek Harness (DSH) 极简语模式插件 — 砍掉 AI 的所有废话，节省 60-75% 输出 token

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![DSH Plugin](https://img.shields.io/badge/DSH-Plugin-blue.svg)](https://github.com/deepseek-ai/deepseek-harness)
[![dsh-plugin](https://img.shields.io/badge/topic-dsh--plugin-green.svg)](https://github.com/topics/dsh-plugin)

</div>

---

## 📊 Before / After

<p align="center">
  <img src="assets/before-after.png" alt="dsh-whale Before/After 对比" width="480" />
</p>

| 正常模式（69 token）                                                                                                               | 鲸鱼模式（18 token）                                                     |
| ---------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| "当然可以！你的 React 组件重新渲染的原因很可能是因为你在每次渲染时都创建了一个新的对象引用。我建议你使用 useMemo 来包裹这个对象。" | "新对象引用每次渲染。内联对象 prop = 新引用 = 重渲染。用 useMemo 包裹。" |

**节省：74% token，信息零丢失。**

---

## ⚡ 快速安装

```bash
# 从 GitHub 安装（推荐）
dsh plugin --profile web add github:1Lyn-en/dsh-whale

# 从 npm 安装
dsh plugin --profile web add @1lyn-en/dsh-whale

# 本地开发安装
npm pack
dsh plugin --profile web add ./1lyn-en-dsh-whale-0.1.0.tgz
```

安装后重启 `dsh web`，在对话中输入 `/whale` 即可激活。

---

## 🎚️ 六档模式

输入 `/whale` 后直接弹出模式下拉菜单（无需记忆参数）：

| 命令                      | 模式            | 效果                   | 节省率       |
| ------------------------- | --------------- | ---------------------- | ------------ |
| `/whale lite`             | 🐋 轻度         | 去客套话，保留完整句子 | ~40%         |
| `/whale` 或 `/whale full` | 🐳 标准（默认） | 去冠词，碎片化表达     | ~60%         |
| `/whale ultra`            | 🦈 极致         | 一个词能说清不用两个词 | ~75%         |
| `/whale wenyan-lite`      | 📜 文言轻度     | 半文言，去废话         | ~60%         |
| `/whale wenyan-full`      | 🏮 文言极致     | 纯文言文，之乎者也     | ~85%（字数） |
| `/whale off`              | 🌊 关闭         | 恢复正常说话           | —            |
| `/whale status`           | —               | 查看当前模式和所有选项 | —            |

### 文言文示例

> 白话："数据库连接池复用已打开的连接，避免每次请求新建连接和握手开销。"
>
> 文言："池蓄已开之连，不逐请而新开，省握手之费。"

---

## ✨ 客户端特性

### 🎛️ 模式下拉选择

输入 `/whale` 后直接弹出 6 档模式下拉菜单（DSH 原生 popupSelect 组件），无需记忆命令参数：

```
/whale  →  [关闭] [轻度] [标准] [极致] [文言·轻度] [文言·极致]
```

### 📊 Token 节省统计

每轮 AI 回复末尾自动显示 token 节省量，按字符类型加权估算（中文 1 token/字，英文 0.25 token/字符）：

```
🐳 已节省 156 token（62%）
```

### 🐋 会话头部鲸鱼按钮

会话头部显示赛博朋克霓虹风格鲸鱼图标，点击一键切换模式（关闭 ↔ 标准），开启时显示喷水动画。

### 🌊 全屏过渡动画

开启鲸鱼模式时，页面中央显示官方 DeepSeek 黑鲸 logo 渐变为赛博朋克霓虹鲸的过渡动画（像素瓦解效果，2.6 秒）。

### 🌃 赛博朋克主题（条件激活）

**进入鲸鱼模式后自动激活赛博朋克主题，退出后恢复 DSH 默认主题。**

主题切换与 logo 过渡动画联动：动画播放完毕后，整个界面从默认主题平滑切换为赛博朋克霓虹风格。选择「关闭」模式时立即恢复默认主题。

|                                 暗色赛博朋克                                 |                                    正常模式                                    |
| :--------------------------------------------------------------------------: | :----------------------------------------------------------------------------: |
| <img src="assets/cyberui/cyberui-dark.png" alt="CyberUI Dark" width="480" /> | <img src="assets/cyberui/cyberui-light.png" alt="CyberUI Light" width="480" /> |

**主题特性：**

- 霓虹色调配色（青/品红/紫渐变），毛玻璃卡片效果
- 自定义滚动条、发光边框、扫描线背景
- 代码块和表格赛博朋克风格渲染
- 侧边栏长标题优雅截断
- 时间线展开动画

|                                         代码表格                                         |                                          时间线展开                                           |
| :--------------------------------------------------------------------------------------: | :-------------------------------------------------------------------------------------------: |
| <img src="assets/cyberui/cyberui-code-table.png" alt="CyberUI Code Table" width="480" /> | <img src="assets/cyberui/cyberui-timeline-expanded.png" alt="CyberUI Timeline" width="480" /> |

|                                               侧边栏长标题                                               |
| :------------------------------------------------------------------------------------------------------: |
| <img src="assets/cyberui/cyberui-sidebar-long-title.png" alt="CyberUI Sidebar Long Title" width="480" /> |

> 主题仅在鲸鱼模式激活时生效，不影响默认 DSH 体验。刷新页面时若已在鲸鱼模式，主题自动恢复。

### ⌨️ 键盘快捷键

| 快捷键                 | 功能                            |
| ---------------------- | ------------------------------- |
| `Ctrl/Cmd + Shift + W` | 快速切换鲸鱼模式（关闭 ↔ 标准） |

### 📝 极简 Commit Message

```bash
/whale-commit    # 根据 git diff --staged 自动生成 ≤50 字符的 commit message
```

根据变更文件类型自动推断提交类型（feat/fix/docs/chore/ci/test/refactor）。

---

## 🔧 核心规则

**砍掉：**

- 冠词（a/an/the）
- 客套话（当然/没问题/很高兴帮你/sure/certainly）
- 填充词（其实/基本上/实际上/just/really/basically）
- 模糊表达（可能/也许/大概/may/might）
- 工具调用前的铺垫（直接调用，不说"我来帮你查"）
- 装饰性表格和 emoji（除非要求）
- 长错误日志（只引用最关键一行）

**保留：**

- 技术术语、代码、API 名、CLI 命令（一字不改）
- 否定词（not/never/no/only/except）— 意思不能变
- 数字、单位、精确值
- 用户使用的语言（中文问就中文答）

---

## 🛡️ 自动清晰度保护

以下场景自动临时退出鲸鱼模式，说清楚后再恢复：

- ⚠️ 安全警告 / 不可逆操作确认（删除、覆盖、发布）
- 📋 多步骤序列（碎片化可能导致顺序误解）
- ❓ 压缩本身产生歧义时
- 🔁 用户要求解释或重复问题时

> 命比 token 重要。

---

## ⚙️ 配置

### 设置默认模式

```bash
/whale-default full    # 设置默认模式为 full（重启后生效）
/whale-default ultra   # 设置默认模式为 ultra
```

### 持久化

- 模式选择自动保存到 DSH 用户设置
- 重启 `dsh web` 后保持当前模式
- 默认模式在新会话中自动激活

---

## 🌐 跨平台支持

本项目同时提供 Claude Code / Codex / Cursor 等平台兼容的 `SKILL.md`：

```bash
# Claude Code
/skill add https://raw.githubusercontent.com/1Lyn-en/dsh-whale/master/cross-platform/SKILL.md
```

---

## 🧪 开发

```bash
# 安装依赖
npm install

# 类型检查
npm run typecheck

# Lint
npm run lint
npm run lint:fix

# 格式化
npm run format
npm run format:check

# 运行测试
npm test

# 构建
npm run build

# 打包
npm run pack

# 本地安装测试
dsh plugin --profile web add ./1lyn-en-dsh-whale-0.1.0.tgz
```

### 项目结构

```
dsh-whale/
├── src/
│   ├── index.ts              # 插件入口（服务端）
│   ├── client.ts             # 客户端入口（popupSelect / token统计 / 鲸鱼按钮 / 过渡动画）
│   ├── types.ts              # 类型定义
│   ├── prompts/              # 6 档模式 prompt
│   │   ├── whale-lite.ts
│   │   ├── whale-full.ts     # 默认
│   │   ├── whale-ultra.ts
│   │   ├── wenyan-lite.ts
│   │   ├── wenyan-full.ts
│   │   ├── auto-clarity.ts   # 自动清晰度保护
│   │   └── index.ts
│   ├── commands/
│   │   ├── whale-command.ts  # /whale 命令
│   │   └── whale-commit.ts   # /whale-commit 极简 commit message
│   └── settings/
│       └── whale-settings.ts # 持久化设置
├── assets/
│   ├── whale-icon.png        # 项目 Logo
│   └── before-after.png      # 效果对比图
├── cross-platform/
│   └── SKILL.md              # Claude/Codex 兼容版
├── tests/
│   ├── command.test.ts
│   ├── commit.test.ts
│   ├── package.test.ts
│   └── prompt.test.ts
├── .github/workflows/ci.yml  # CI（typecheck + lint + format + build + test）
├── eslint.config.js          # ESLint 配置
├── vitest.config.ts          # Vitest 测试与覆盖率配置
├── .prettierrc               # Prettier 配置
├── cordis.patch.yml          # DSH 插件配置
├── package.json
├── tsconfig.json
└── README.md
```

---

## ❓ FAQ

**Q: 会影响代码生成质量吗？**
A: 不会。代码块、技术术语、API 名完全保留，只压缩自然语言描述。

**Q: 为什么叫鲸鱼？**
A: DeepSeek Harness 官方 IP 是黑色鲸鱼，鲸鱼沉默但智慧，符合"少说话多办事"的理念。

**Q: 支持哪些 DSH 版本？**
A: 支持 DSH 0.1.0-rc.6+，兼容 web profile。

---

## 📄 License

MIT © [1Lyn-en](https://github.com/1Lyn-en)
