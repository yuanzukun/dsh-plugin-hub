## Summary

<!-- 简要说明本 PR 做了什么、为什么 -->

## Checklist

- [ ] `npx tsc --noEmit` 通过
- [ ] `npm run build` 通过
- [ ] `npm test` 通过
- [ ] 若改动 Host（`src/index.ts` / `src/tools.ts`）：已在本地重启 DSH 验证
- [ ] 若改动 Client（`src/client/index.ts`）：`lib/client.js` 仍以 `window.__ModuleLoader__.load` 开头
- [ ] 若改动安装/开发流程或 README 结构：已同步更新 `README.en.md`
- [ ] 若新增/修改 `chunsun_*` 工具：已更新 `docs/tools.md`

## Test plan

<!-- 如何验证本 PR -->
