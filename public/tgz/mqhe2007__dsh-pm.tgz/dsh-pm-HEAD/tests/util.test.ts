import { describe, it, expect } from 'vitest'
import {
  shq,
  enc,
  parseEnv,
  upsertEnvLine,
  ACTIVE_REQ_STATUS,
  pickCurrentRequirement,
} from '../src/util'

describe('shq (shell 单引号转义)', () => {
  it('普通字符串用单引号包裹', () => {
    expect(shq('abc')).toBe("'abc'")
  })
  it('含单引号时按反斜杠转义', () => {
    // 输入 a'b  →  输出 'a'\''b'
    expect(shq("a'b")).toBe("'a'\\''b'")
  })
  it('空串返回两个连续单引号', () => {
    expect(shq('')).toBe("''")
  })
})

describe('enc (URL 组件编码)', () => {
  it('编码路径/中文/特殊字符', () => {
    expect(enc('a b/中文')).toBe(encodeURIComponent('a b/中文'))
  })
  it('已安全字符不重复编码', () => {
    expect(enc('abc-123')).toBe('abc-123')
  })
})

describe('parseEnv', () => {
  it('解析 KEY=value 并去除引号', () => {
    const env = parseEnv('A=1\nB="x y"\nC=\'z\'\n# comment\n')
    expect(env).toEqual({ A: '1', B: 'x y', C: 'z' })
  })
  it('跳过空行/注释/无等号行', () => {
    const env = parseEnv('\n# comment\nBADLINE\nD = 42\n')
    expect(env).toEqual({ D: '42' })
  })
  it('空输入返回空对象', () => {
    expect(parseEnv('')).toEqual({})
    expect(parseEnv(null as unknown as string)).toEqual({})
  })
  it('值允许等号', () => {
    expect(parseEnv('URL=http://a:1?x=2')).toEqual({ URL: 'http://a:1?x=2' })
  })
})

describe('upsertEnvLine', () => {
  it('已有 key 替换原行', () => {
    const out = upsertEnvLine('A=1\nB=2', 'A', '9')
    expect(out).toBe('A=9\nB=2')
  })
  it('无 key 时追加到末尾', () => {
    const out = upsertEnvLine('A=1\nB=2', 'C', '3')
    expect(out).toBe('A=1\nB=2\nC=3')
  })
  it('输入末尾带换行不产生多余空行', () => {
    expect(upsertEnvLine('A=1\n', 'B', '2')).toBe('A=1\nB=2')
  })
  it('空文本新增行（无前导空行）', () => {
    expect(upsertEnvLine('', 'K', 'v')).toBe('K=v')
  })
})

describe('ACTIVE_REQ_STATUS / pickCurrentRequirement', () => {
  it('状态集合不含终态', () => {
    expect(ACTIVE_REQ_STATUS).toContain('running')
    expect(ACTIVE_REQ_STATUS).not.toContain('completed')
    expect(ACTIVE_REQ_STATUS).not.toContain('abandoned')
  })

  it('全为终态时返回 null', () => {
    const all = [
      { id: 'a', status: 'completed', createdAt: '2026-08-21T10:00:00.000Z' },
      { id: 'b', status: 'abandoned', createdAt: '2026-08-21T11:00:00.000Z' },
    ]
    expect(pickCurrentRequirement(all)).toBeNull()
  })

  it('空列表返回 null', () => {
    expect(pickCurrentRequirement([])).toBeNull()
  })

  it('多个待处理选最新（createdAt 降序）', () => {
    const mixed = [
      { id: 'old', status: 'running', createdAt: '2026-08-21T08:00:00.000Z' },
      { id: 'new', status: 'pending', createdAt: '2026-08-21T12:00:00.000Z' },
      { id: 'done', status: 'completed', createdAt: '2026-08-21T13:00:00.000Z' },
    ]
    const pick = pickCurrentRequirement(mixed)
    expect(pick?.id).toBe('new')
  })

  it('createdAt 缺失回退 updatedAt', () => {
    const mixed = [
      { id: 'x', status: 'running', updatedAt: '2026-08-21T09:00:00.000Z' },
      { id: 'y', status: 'running', createdAt: '2026-08-21T10:00:00.000Z' },
    ]
    expect(pickCurrentRequirement(mixed)?.id).toBe('y')
  })
})
