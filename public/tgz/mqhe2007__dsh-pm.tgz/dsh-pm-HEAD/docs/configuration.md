# 配置说明

dsh-pm 通过工作区 `.env` 连接春笋（ChunSun）自部署实例。配置可在 GUI「项目管理」视图中填写，也可手动编辑 `.env`。

## 环境变量

| 变量 | 必填 | 默认值 | Secret | 说明 |
|------|------|--------|--------|------|
| `CHUNSUN_API_URL` | 否 | `http://localhost:11111/api/v1` | 否 | 春笋 API 根地址（末尾斜杠会自动去除） |
| `CHUNSUN_SECRET_KEY` | 是（接入后） | — | **是** | 项目密钥；Bearer 鉴权，写入 `.env` 后文件权限收紧为 `0600` |

读取逻辑见 `ChunsunService.loadConfig()`（[src/index.ts](../src/index.ts)）。

## 配置方式

### 方式一：GUI 连接向导（推荐）

1. 启动 DSH（如 `dsh web`）
2. 打开会话侧栏「项目管理」视图（`conversation.view`）
3. 填写 API URL 与 Secret Key，点击「保存并测试连接」

面板会依次触发 `config-read` → `config-save` → `status` RPC。Secret Key 在前端不回明文，仅显示「已保存」占位。

> Composer 上方状态条（`conversation.input.dock`）仅作实时状态展示，**不含配置入口**。

### 方式二：手动编辑 `.env`

在工作区根目录创建或编辑 `.env`：

```env
CHUNSUN_API_URL=http://localhost:11111/api/v1
CHUNSUN_SECRET_KEY=your-secret-key
```

与 [chunsun CLI](https://github.com/mqhe2007/chunsun) 使用同一套变量。

## Secret 环境变量（平台侧）

Agent 通过 `chunsun_env_get` 读取春笋平台上的 secret 环境变量时，需经 DSH 审批栈授权（会话内 `allowed-once`）。非 secret 变量直接返回。

## DSH 路径

| 项 | 默认位置 | 覆盖 |
|----|----------|------|
| Profile 目录 | `~/.dsh/profiles/<name>/` | `DSH_HOME` 环境变量 |
| 技能模板缓存 | `~/.dsh/skills/chunsun/` | — |

## 连接自检

| 手段 | 说明 |
|------|------|
| GUI「保存并测试连接」 | 验证插件 → 春笋链路 |
| `curl <apiUrl>/health` | 区分插件问题 vs 实例未启动 |
| Agent 调用 `chunsun_status` | 验证 Host 工具与密钥绑定 |

未配置 `CHUNSUN_SECRET_KEY` 时，面板显示「未连接」；health 可达但无法解析项目 ID。
