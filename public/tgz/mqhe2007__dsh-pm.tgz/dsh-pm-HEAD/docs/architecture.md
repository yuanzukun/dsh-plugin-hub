# 架构

dsh-pm 是 DSH（DeepSeek Harness）组合包插件，把 [春笋 ChunSun](https://github.com/mqhe2007/chunsun) 的项目交付能力接入 Agent 与 Web GUI。工作记忆与业务状态以春笋自部署实例为 **SSOT**（Single Source of Truth）。

## 数据流

```mermaid
flowchart LR
  subgraph dshHost [DSH Host]
    Service["ChunsunService\nsrc/index.ts"]
    Tools["28 chunsun_* tools\nsrc/tools.ts"]
  end
  subgraph dshClient [DSH Web Client]
    Dock["conversation.input.dock\n状态条"]
    View["conversation.view\n项目管理"]
    RemoteMount["$mount ./remote"]
  end
  subgraph chunsun [ChunSun Instance SSOT]
    API["/api/v1"]
  end
  Agent --> Tools
  Tools --> Service
  View --> RemoteMount --> Service
  Dock --> RemoteMount
  Service --> API
```

## 模块职责

| 路径 | 角色 |
|------|------|
| `src/index.ts` | `ChunsunService`（`TypertRemoteService`）：HTTP 代理、配置读写、业务逻辑；`@Remote` 方法供 Client RPC |
| `src/tools.ts` | 28 个 `chunsun_*` 模型工具，消费 `chunsun` 服务 |
| `src/typert.ts` / `src/remote.ts` | Host `./typert` 与 Client `./remote` 导出 |
| `src/client/index.ts` | Web GUI：`conversation.input.dock` 状态条 + `conversation.view`「项目管理」视图；`apply` 内 `$mount(./remote)` |
| `cordis.patch.yml` | 组合包 patch：注册 service + tools |
| `lib/` | `npm run build` 产物（gitignore） |

## Host 与 Client 边界

- **Host**（Node ESM）：DSH 启动时加载 `lib/index.js`、`lib/tools.js`；改动需**重启 DSH**。
- **Client**（lazy-CJS）：`lib/client.js` 经 `window.__ModuleLoader__.load` 注册；改动需**重新构建 + 刷新浏览器**。
- **Remote**：Client 必须 `await ctx.remote.$mount(...)` 挂载 `./remote`，才会出现 `ctx.remote.chunsun`；`dsh-api-remotes` 不会自动 mount 仓库外插件。

## 构建约束

- 必须用 **`tsc`** 构建 Host：`@Remote` 是 Stage 3 装饰器，需降级为 `__esDecorate`；tsdown/oxc 不支持。
- Client 的 `react` 保持 **external**，通过 `require("react")` 取壳层播种的 React。

## GUI 组件

| 插槽 | 功能 |
|------|------|
| `conversation.input.dock` | Composer 上方状态条：当前需求 / Run 轮次 / Step 数（只读） |
| `conversation.view`「项目管理」 | 项目总览、连接配置向导、需求进度 |

详见 [configuration.md](configuration.md) 与 [tools.md](tools.md)。
