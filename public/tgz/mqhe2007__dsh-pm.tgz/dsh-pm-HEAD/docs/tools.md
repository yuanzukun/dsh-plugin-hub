# 工具 API 参考

dsh-pm 向 DSH Agent 注册 **28 个** `chunsun_*` 模型工具（定义于 [src/tools.ts](../src/tools.ts)）。所有工具返回 JSON 文本块。

参数标注 **必填** 的为 required；其余可选。

---

## 连接 / 状态

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_status` | 报告春笋实例连接状态与当前工作区密钥绑定的项目信息 | — |

---

## 需求

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_requirement_list` | 列出当前项目下的需求（可按 status 过滤） | — |
| `chunsun_requirement_show` | 查看单个需求详情 | `requirementId` |
| `chunsun_requirement_create` | 创建需求 | `description` |
| `chunsun_requirement_update` | 更新需求（status/application/module/description 至少一个） | `requirementId` |

---

## Run

| 工具 | 说明 | 必填参数 | 备注 |
|------|------|----------|------|
| `chunsun_run_start` | 为需求开一个新交付 Run | `requirementId` | 已有 running Run 时返回 `RUN_ALREADY_RUNNING` |
| `chunsun_run_takeover` | 接管僵尸 Run：旧 Run 置 finished 并开新 Run | `requirementId` | |
| `chunsun_run_status` | Run 状态迁移 | `requirementId`, `status` | `completed` / `finished` / `abandoned`；`completed` 过平台硬门禁 |
| `chunsun_run_list` | 列出需求的全部 Run | `requirementId` | |
| `chunsun_run_remind` | 规则提醒：返回未满足的柔性约束 | `requirementId` | 建议每轮交付前调用 |

---

## Step

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_step_add` | 上报执行 Step | `requirementId`, `runId`, `kind`, `summary` |
| `chunsun_step_list` | 列出某 Run 的 Steps | `requirementId`, `runId` |

`kind` 可选值：`think` / `code` / `test` / `verify` / `ask_user` / `info` / `reflect`

---

## 验收场景 / 用例

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_scenario_list` | 列出需求验收场景 | `requirementId` |
| `chunsun_scenario_upsert` | 按 key upsert 验收场景 | `requirementId`, `key`, `title` |
| `chunsun_scenario_status` | 更新场景状态 | `requirementId`, `scenarioId`, `status` |
| `chunsun_case_list` | 列出需求的全部验收用例 | `requirementId` |
| `chunsun_case_upsert` | upsert 验收用例 | `requirementId`, `scenarioKey`, `title` |
| `chunsun_case_status` | 回写用例状态 | `requirementId`, `caseId`, `status` |

场景 `status`：`pending` / `passing` / `failing` / `blocked` / `waived`  
用例 `status`：`passed` / `failed` / `blocked` / `skipped`  
用例 `kind`：`unit` / `integration` / `e2e`；`executionPlan`：`auto` / `manual`

---

## 工作记忆

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_context_get` | 拉取需求工作记忆 Context | `requirementId` |
| `chunsun_context_put` | 写回工作记忆（snapshot 顶层 key 合并） | `requirementId`, `snapshot` |

---

## 环境变量（平台）

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_env_list` | 列出项目环境变量（不含明文） | — |
| `chunsun_env_get` | 获取单个环境变量生效值 | `key` |

secret 变量需 DSH 审批授权（见 [configuration.md](configuration.md)）。

---

## 缺陷

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_defect_list` | 列出缺陷（可按 status/severity 过滤） | — |
| `chunsun_defect_create` | 登记缺陷 | `title` |
| `chunsun_defect_show` | 查看单个缺陷详情 | `defectId` |
| `chunsun_defect_update` | 更新缺陷 | `defectId` |
| `chunsun_fix` | 派生修复需求并进入自主交付（缺陷 1:1） | `defectId` |

---

## 其他

| 工具 | 说明 | 必填参数 |
|------|------|----------|
| `chunsun_reset` | 全量重置需求：清工作记忆 + 场景/用例重置 pending + 开新 Run | `requirementId` |

---

## 常见错误

| 场景 | 典型返回 |
|------|----------|
| 未配置密钥 | `{ ok: false, error: "未配置 CHUNSUN_SECRET_KEY..." }` |
| 无 running Run | `{ ok: false, error: "当前没有 running 的 Run" }` |
| 春笋 HTTP 失败 | `{ ok: false, httpError: "HTTP ..." }` |
| secret 未授权 | `{ authorized: false, ... }` |
