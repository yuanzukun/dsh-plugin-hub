/**
 * 验证 dock「保存并测试连接」所走后端链路（真实依赖）：
 * 对齐 ChunsunService.statusFor 的端点与判定 —— /health + /auth/secret-key-info。
 * 只读，不写 .env。
 */
import { readFile } from 'node:fs/promises'

function parseEnv(text) {
  const out = {}
  for (const line of String(text || '').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
    if (!m) continue
    let val = m[2]
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1)
    out[m[1]] = val
  }
  return out
}

const assert = (cond, msg) => { if (!cond) throw new Error('ASSERT FAIL: ' + msg) }

async function main() {
  const env = parseEnv(await readFile(new URL('../.env', import.meta.url), 'utf8'))
  const apiUrl = (env.CHUNSUN_API_URL || '').replace(/\/+$/, '')
  const secretKey = env.CHUNSUN_SECRET_KEY || ''
  assert(apiUrl, '需要 CHUNSUN_API_URL')

  // 对齐 ChunsunService.httpJson / statusFor
  const req = async (path) => {
    const headers = { 'Content-Type': 'application/json' }
    if (secretKey) headers.Authorization = 'Bearer ' + secretKey
    const r = await fetch(apiUrl + path, { method: 'GET', headers })
    return { status: r.status, body: await r.json().catch(() => null) }
  }

  const health = await req('/health')
  assert(health.body && health.body.status === 'ok', '/health 未返回 ok: ' + JSON.stringify(health))

  // 有 secret key 时按 statusFor 判定 connected（secret-key-info.success === true）
  let connected = false
  let projectId = ''
  if (secretKey) {
    const info = await req('/auth/secret-key-info')
    connected = !!(info.body && info.body.success === true)
    assert(connected, '/auth/secret-key-info 未 connected: ' + JSON.stringify(info))
    projectId = info.body?.data?.projectId || ''
    assert(projectId, '未返回 projectId')
  }

  console.log('[真实依赖] /health=ok; secretKey=%s; connected=%s; projectId=%s', secretKey ? '有' : '无', connected, projectId || '—')
  console.log('PASS: dock 连接配置后端链路（/health + /auth/secret-key-info）真实依赖跑通')
}

main().catch((e) => { console.error(e); process.exit(1) })
