/**
 * Emit the browser half as DSH lazy-CJS:
 *   window.__ModuleLoader__.load({ id, factory: (require) => { ...; return module.exports } })
 * Official packages get this from the unpublished `clientBundle` tsdown preset;
 * outside the monorepo we reproduce the same wire shape with esbuild.
 */
import * as esbuild from 'esbuild'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'))
const outFile = join(root, 'lib/client.js')

const result = await esbuild.build({
  absWorkingDir: root,
  entryPoints: ['src/client/index.ts'],
  bundle: true,
  write: false,
  format: 'cjs',
  platform: 'browser',
  target: ['es2022'],
  external: ['react', 'react-dom', 'react/jsx-runtime', 'react/jsx-dev-runtime'],
  logLevel: 'silent',
})

// Match official DSH client bundles: bare `require("react")`, no esbuild __toESM
  // wrapper — that interop breaks when the ModuleLoader already returns an ESM namespace.
  // Also unwrap `.default` when named exports live only there.
  const body = result.outputFiles[0].text
  .replace(/^"use strict";\r?\n/, '')
  .replace(
    /var (\w+) = __toESM\(require\("(react(?:\/jsx-runtime|\/jsx-dev-runtime)?)"\), 1\);/g,
    'var $1 = require("$2"); if ($1 && $1.default && !$1.createElement && !$1.useState && !$1.jsx) $1 = $1.default;',
  )
  .trimEnd()

const wrapped = `window.__ModuleLoader__.load({
	id: ${JSON.stringify(pkg.name)},
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
${body.split('\n').map((line) => (line.length ? `\t\t${line}` : '')).join('\n')}
		return module.exports;
	}
});
`

await mkdir(dirname(outFile), { recursive: true })
await writeFile(outFile, wrapped)
await writeFile(
  join(root, 'lib/client.d.ts'),
  `export const inject: string[]\nexport function apply(ctx: any): void\n`,
)
console.log(`wrote ${outFile}`)
