/**
 * 验证 dock「当前交付焦点」选择逻辑（pickCurrentRequirement）：
 *  - 真实依赖：读取工作区 .env，向春笋平台拉取真实需求列表，跑真实选择逻辑；
 *  - 空状态分支：合成「全为终态/空列表」的输入，断言返回 null（dock 渲染友好空状态）。
 */
import { readFile } from 'node:fs/promises'
import { pickCurrentRequirement } from '../lib/index.js'

function parseEnv(text) {
  const out = {}
  for (const line of String(text || '').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
    if (!m) continue
    let val = m[2]
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1)
    out[m[1]] = val
  }
  return out
}

const assert = (cond, msg) => { if (!cond) throw new Error('ASSERT FAIL: ' + msg) }

async function main() {
  const env = parseEnv(await readFile(new URL('../.env', import.meta.url), 'utf8'))
  const apiUrl = (env.CHUNSUN_API_URL || '').replace(/\/+$/, '')
  const secretKey = env.CHUNSUN_SECRET_KEY || ''
  assert(apiUrl && secretKey, '需要 CHUNSUN_API_URL + CHUNSUN_SECRET_KEY')

  const h = async (path) => {
    const r = await fetch(apiUrl + path, { headers: { Authorization: 'Bearer ' + secretKey } })
    return r.json()
  }

  // 真实依赖：项目 + 需求列表（来自春笋平台）
  const info = await h('/auth/secret-key-info')
  assert(info && info.success && info.data?.projectId, 'secret-key-info 未返回 projectId')
  const projectId = info.data.projectId
  const reqResp = await h('/projects/' + projectId + '/requirements')
  assert(reqResp && reqResp.success && Array.isArray(reqResp.data), 'requirements 未返回数组')
  const requirements = reqResp.data

  // 统计真实分布，帮助断言
  const activeCount = requirements.filter((r) => ['pending', 'running', 'processing'].includes(r.status)).length

  // 跑真实选择逻辑
  const pick = pickCurrentRequirement(requirements)

  if (activeCount > 0) {
    // 策略 1：有待处理需求时，选中「最新」且仍在处理的那条
    assert(pick, '存在待处理需求时不应返回 null')
    assert(['pending', 'running', 'processing'].includes(pick.status), '选中的必须是待处理需求，实际 status=' + pick.status)
    // 必须是最近创建的一条待处理需求
    const newestActive = requirements
      .filter((r) => ['pending', 'running', 'processing'].includes(r.status))
      .sort((a, b) => Date.parse(b.createdAt || b.updatedAt) - Date.parse(a.createdAt || a.updatedAt))[0]
    assert(pick.id === newestActive.id, '应选最新待处理需求，期望 id=' + newestActive.id + ' 实际 id=' + pick.id)
    console.log('[策略1] 待处理需求存在: 选中 id=%s status=%s desc=%s', pick.id, pick.status, String(pick.description || '').slice(0, 24))
  } else {
    // 策略 2：没有待处理需求 → null（dock 渲染友好空状态）
    assert(pick === null, '没有待处理需求时应返回 null')
    console.log('[策略2] 无待处理需求: pick=null (dock 显示空状态)')
  }

  // 独立校验空状态分支（单元，纯函数）
  const allDone = [
    { id: 'a', status: 'completed', createdAt: '2026-08-21T10:00:00.000Z' },
    { id: 'b', status: 'abandoned', createdAt: '2026-08-21T11:00:00.000Z' },
  ]
  assert(pickCurrentRequirement(allDone) === null, '全为终态时应返回 null')
  assert(pickCurrentRequirement([]) === null, '空列表应返回 null')
  const mixed = [
    { id: 'old', status: 'running', createdAt: '2026-08-21T08:00:00.000Z' },
    { id: 'new', status: 'pending', createdAt: '2026-08-21T12:00:00.000Z' },
    { id: 'done', status: 'completed', createdAt: '2026-08-21T13:00:00.000Z' },
  ]
  const mixPick = pickCurrentRequirement(mixed)
  assert(mixPick && mixPick.id === 'new', '多个待处理需求应选最新，实际 id=' + (mixPick && mixPick.id))
  console.log('[空状态/多选] 全部通过')

  console.log('\nPASS: dock 选择逻辑验收通过（真实平台数据 + 空状态分支）')
}

main().catch((e) => { console.error(e); process.exit(1) })
