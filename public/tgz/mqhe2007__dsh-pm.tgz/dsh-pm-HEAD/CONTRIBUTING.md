# 贡献指南

感谢关注 dsh-pm！以下是本地开发与提交流程。

## 开发环境

- Node.js ≥ 24
- npm（本仓库构建）
- pnpm（DSH profile 管理插件，可选）
- 可运行的 DSH 实例（测试 Host / Client 集成）

## 本地流程

```sh
git clone https://github.com/mqhe2007/dsh-pm.git
cd dsh-pm
npm ci
npx tsc --noEmit    # 类型检查
npm run build       # 产物输出到 lib/
npm test            # Vitest 单元测试
```

### 迭代生效规则

| 改动范围 | 生效方式 |
|----------|----------|
| `src/index.ts`、`src/tools.ts`（Host） | 重新构建 + **重启 DSH** |
| `src/client/index.ts`（Client） | 重新构建 + **刷新浏览器** |
| `package.json` 依赖 | `npm install` 后重新构建 |

### 提交前校验

```sh
npx tsc --noEmit
npm run build
node --check lib/index.js && node --check lib/tools.js
head -1 lib/client.js | grep -q '__ModuleLoader__'
npm test
```

## 提 Pull Request

1. Fork 本仓库，从 `main` 创建功能分支
2. 保持改动聚焦；匹配现有代码风格
3. 若改动安装/开发流程或 README 结构，**同步更新 [README.en.md](README.en.md)**
4. 填写 PR 模板中的检查清单
5. 确保 CI 通过

## 文档

- 用户向文档：`docs/`（中文）
- 自述：[README.md](README.md)（中文）、[README.en.md](README.en.md)（英文）
- 改工具 API 时同步更新 [docs/tools.md](docs/tools.md)

## 行为准则

请在 issue 与 PR 中保持友善、具体、可复现。勿在公开渠道粘贴 `CHUNSUN_SECRET_KEY` 或其他密钥。
