<div align="center">

# dsh-pm

[中文](README.md) | **English**

[![CI](https://github.com/mqhe2007/dsh-pm/actions/workflows/ci.yml/badge.svg)](https://github.com/mqhe2007/dsh-pm/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D24-brightgreen)](package.json)

> **dsh-pm** (pm = project management) is powered by [ChunSun](https://github.com/mqhe2007/chunsun) — a first-class DeepSeek Harness (DSH) plugin that deeply integrates ChunSun’s AI-native project delivery platform.

dsh-pm lets DSH Agents deliver work autonomously around **requirements**: start Runs, report Steps, maintain acceptance scenarios/cases, read/write working memory, pass the hard `completed` gate, and track progress in session-level GUI panels (composer dock + “Project Management” view). Working memory and state live on your self-hosted ChunSun instance as the SSOT.

<img src="public/screenshot-1.png" alt="Composer dock: current requirement / Run / Step" width="100%" />

<img src="public/screenshot-2.png" alt="Project Management view: overview and connection setup" width="100%" />

**Quick links:** [Install](#quick-start-install-into-dsh) · [Configuration](docs/configuration.md) · [Tool API](docs/tools.md) · [Contributing](CONTRIBUTING.md)

> **Note:** Detailed docs under `docs/` are in Chinese.

</div>

## Structure

- `src/index.ts` — `ChunsunService` (`TypertRemoteService`, `@Remote` methods)
- `src/tools.ts` — 28 `chunsun_*` model tools
- `src/typert.ts` / `src/remote.ts` — Host `./typert` and Client `./remote` exports (external plugins must mount `./remote` themselves; `dsh-api-remotes` does not auto-mount)
- `src/client/index.ts` — Session-level delivery GUI (lazy-CJS): `conversation.input.dock` status bar + `conversation.view` “Project Management”; `$mount(./remote)` in `apply` before using `ctx.remote.chunsun`
- `cordis.patch.yml` — Bundle patch (service + tools)
- `lib/` — Build output from `npm run build` (gitignored)

See [docs/architecture.md](docs/architecture.md).

## Tools (Host)

28 `chunsun_*` tools covering: connection/status · requirements · Runs · Steps · scenarios/cases · working memory · env vars · defects · reset.

Full reference: [docs/tools.md](docs/tools.md).

## Environment variables

| Variable | Required | Default | Secret | Description |
|----------|----------|---------|--------|-------------|
| `CHUNSUN_API_URL` | No | `http://localhost:11111/api/v1` | No | ChunSun API base URL |
| `CHUNSUN_SECRET_KEY` | Yes (after setup) | — | **Yes** | Project secret (Bearer token) |

Configure in workspace `.env` or via the GUI “Project Management” view (“Save & test connection”). See [docs/configuration.md](docs/configuration.md).

## Quick start: install into DSH

### Prerequisites

- Node.js ≥ 24 + npm (for building this repo; matches CI / DSH runtime; Stage 3 decorators require `tsc`); pnpm (for DSH profile plugin management)
- A runnable DSH instance (examples use the `web` profile)
- Optional: self-hosted ChunSun instance (otherwise the UI shows “disconnected”)

### 1. Build the plugin (inside dsh-pm)

```sh
npm install
npm run build      # tsc → lib/ (aligned with package.json exports)
```

> You **must** use `tsc` (not tsdown): `@Remote` is a Stage 3 decorator; DSH loads bundle entries as native Node ESM and needs `tsc` to lower decorators to `__esDecorate`. tsdown/oxc leave bare `@Remote` in `.js` → `Invalid or unexpected token`.

### 2. Add to a DSH profile

```sh
dsh plugin --profile web add ./dsh-pm        # run from dsh-pm checkout
```

Equivalent to `pnpm add <absolute-path>` under `~/.dsh/profiles/web/`, then appending `dsh-pm` to `dsh.profile.bundles` when `dsh.bundle` is declared.

pnpm symlinks local path deps (`node_modules/dsh-pm -> your checkout`), so after the first add you only need rebuilds.

> If `dsh` is not on PATH:
> `node <dsh-checkout>/apps/cli/lib/bin.js plugin --profile web add ./dsh-pm`

> Manual equivalent: add `"dsh-pm": "file:/absolute/path/dsh-pm"` to profile `dependencies` and `"dsh-pm"` to `dsh.profile.bundles`, then `pnpm install` in the profile dir.

Install from GitHub:

```sh
dsh plugin --profile web add github:mqhe2007/dsh-pm
```

This runs the `prepare` build script. If pnpm blocks it, add the key from the error to `allowBuilds` in the profile’s `pnpm-workspace.yaml` and retry.

### 3. Start DSH and connect

```sh
dsh web            # or dsh --profile web
```

First-time setup: put `CHUNSUN_API_URL` and `CHUNSUN_SECRET_KEY` in workspace `.env` (same as chunsun CLI). Or use the GUI “Project Management” view to fill in and “Save & test connection” — the composer dock is read-only status, not configuration.

## Development

### Iteration loop

```text
edit src/*.ts  →  npm run build  →  takes effect
                                      ├─ Host (service/tools): restart DSH
                                      └─ Client (panel): refresh browser
```

- Host changes (`src/index.ts`, `src/tools.ts`): loaded at DSH startup — **restart DSH** required.
- Client changes (`src/client/index.ts`): served as `lib/client.js` (lazy-CJS) — **rebuild + refresh**; DSH `dev:web` watch may auto-reload.
- Dependency changes: `npm install` then rebuild.

### Pre-commit checks

```sh
npx tsc --noEmit
npm run build
node --check lib/index.js && node --check lib/tools.js
head -1 lib/client.js | grep -q '__ModuleLoader__'
npm test
ls lib/
```

### Debugging

| Layer | How |
|-------|-----|
| Build/types | `npx tsc --noEmit`; verify `lib/` exports; `lib/client.js` must start with `window.__ModuleLoader__.load({` |
| Host service/tools | DSH startup logs; call `chunsun_*` tools in a session; add logs in source if needed |
| Client panel | Browser DevTools Console + Network for `remote.chunsun.*` RPC |
| Wiring | GUI “Save & test connection” → `config-read` / `config-save` / `status`; `curl <apiUrl>/health` to isolate plugin vs instance issues |

### Pitfalls

- **After build, `node --check lib/index.js`**: output must not contain bare `@Remote`; expect `__esDecorate` / `Remote('status')`.
- **Client must be lazy-CJS**: `lib/client.js` must call `window.__ModuleLoader__.load({ id: "dsh-pm", factory })`.
- **`remote.chunsun` is not automatic**: external plugins must export `./remote` and `await ctx.remote.$mount(...)` in Client `apply`.
- **Keep `react` external**: factory uses `require("react")` from the shell.
- **Tool parameters are DSL, not JSON Schema**: map of property → schema; mark required per property (`regTool` in `src/tools.ts`).
- **npm cache EPERM**: `sudo chown -R $(id -u):$(id -g) ~/.npm` or `npm install --cache <dir>`.
- **Profile location**: `~/.dsh/profiles/<name>/` (override with `DSH_HOME`).

## Documentation

| Doc | Description |
|-----|-------------|
| [docs/configuration.md](docs/configuration.md) | Env vars, GUI connection, secret approval *(Chinese)* |
| [docs/tools.md](docs/tools.md) | 28 `chunsun_*` tool reference *(Chinese)* |
| [docs/architecture.md](docs/architecture.md) | Host / Client / ChunSun SSOT *(Chinese)* |
| [CONTRIBUTING.md](CONTRIBUTING.md) | Contributing guide |
| [CHANGELOG.md](CHANGELOG.md) | Release history |
| [SECURITY.md](SECURITY.md) | Security reporting |

## License

[MIT](LICENSE)
