# 安全策略

## 报告漏洞

请通过 [GitHub Security Advisories](https://github.com/mqhe2007/dsh-pm/security/advisories/new) **私下**报告安全漏洞。请勿在公开 Issue 中讨论可利用的安全问题。

## 敏感信息

dsh-pm 会读写工作区 `.env` 中的连接配置：

- `CHUNSUN_SECRET_KEY` 为 Bearer 密钥，写入后插件会尽力将文件权限设为 `0600`
- GUI 不回显明文密钥
- `chunsun_env_get` 读取平台 secret 变量需 DSH 审批授权

**请勿**在 Issue、PR、日志或截图中粘贴密钥、`.env` 全文或带 Authorization 头的 curl 命令。

## 支持版本

| 版本 | 支持 |
|------|------|
| 最新 `main` / 最新 Release | 是 |
| 更早版本 | 视情况 |

我们会在确认漏洞后尽快发布修复，并通过 GitHub Security Advisory 披露（含致谢，如适用）。
