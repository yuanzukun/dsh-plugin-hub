# Changelog

本文件记录 dsh-pm 的版本变更。格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)。

## [0.1.0] - 2026-08-24

### Added

- 初始开源发布：DSH 插件，由春笋（ChunSun）驱动的 AI 原生项目交付
- `ChunsunService` Host 服务（`@Remote` RPC）
- 28 个 `chunsun_*` 模型工具（需求 / Run / Step / 场景 / 用例 / 工作记忆 / 环境变量 / 缺陷）
- Web GUI：composer 状态条 +「项目管理」会话视图
- Vitest 单元测试与 GitHub Actions CI

[0.1.0]: https://github.com/mqhe2007/dsh-pm/releases/tag/v0.1.0
