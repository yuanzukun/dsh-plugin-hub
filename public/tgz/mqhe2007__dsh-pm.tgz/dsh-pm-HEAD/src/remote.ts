/**
 * Client Remote contribution — must be `$mount`ed; `dsh-api-remotes` only mounts in-repo packages.
 */
import { INVOCATIONS } from './typert-shared.js'

export const TYPERT_REMOTE = {
  package: 'dsh-pm',
  descriptors: [...INVOCATIONS],
}

export default TYPERT_REMOTE
