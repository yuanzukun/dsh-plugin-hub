// dsh-pm 春笋常驻规则注入（宿主层）。
//
// 春笋技能正文（SKILL.md）不再由本模块注册——DSH 的 `skill-filesystem` 会扫描
// `~/.dsh/skills/chunsun/SKILL.md`（官方 user-dsh 技能根）自动发现、加载并 watch 更新，
// 模板刷新（覆盖缓存文件）即自动生效，无需显式重注册，也不引入 runtime provider 的 rank 冲突。
//
// 本模块负责那部分 skill-filesystem 替代不了的：**常驻规则**（loop-rules），以及**启停开关**。
// 技能是按需加载的（模型调 skill 工具才进上下文），而 loop-rules（验收定义/停点/状态/边界/RRI）
// 是春笋设计为「始终生效」的规则，必须常驻——DSH 里没有 alwaysApply，等价物是
// `systemPrompt.variable` + 一个引用它的 `systemPrompt.section`。
//
// 启停开关走 DSH 官方 settings 服务：`settings.register('chunsun', { enabled })`，
// 部署级持久化；host 注入与 client GUI 都读同一 enabled，关闭则不注入常驻规则。
import z from '@deepseek-ai/schemastery'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'

/** 春笋 settings namespace（DSH settings 服务注册的键）。 */
export const CHUNSUN_SETTINGS_NS = settingsNamespace('chunsun')
/** 常驻规则 prompt 变量名（小写，DSH prompt 变量规则 ^[a-z][a-z0-9_]*$）。 */
export const CHUNSUN_RULES_VAR = 'chunsun_rules'

/** 春笋 settings schema：{ enabled } 启停开关（默认开启）。 */
export const ChunsunSettingsSchema = z.object({
  enabled: z.boolean().default(true),
})

/** 读缓存正文（无则空串）。 */
type Reader = () => Promise<{ loopRules: string }>

/** 模块级常驻规则缓存值：provider 读取的可变目标，刷新后更新立即生效。 */
const state: { cachedRules: string } = { cachedRules: '' }

/** 刷新常驻规则缓存值。 */
function refreshRules(t: { loopRules: string }): void {
  state.cachedRules = t.loopRules
}

/**
 * 宿主插件的 apply 初始化：
 *  1) 注册 `chunsun` settings namespace（启停开关，部署级持久化）；
 *  2) 读 enabled —— 关闭则不注入常驻规则变量/section。
 *
 * 用 `ctx.inject(['settings'], …)` 按需访问 settings 服务（首启可能尚未就绪），
 * namespace 注册与读取都挂当前插件的 fiber，生命周期一致。
 */
export function initChunsunSkill(ctx: any, reader: Reader): void {
  ctx.inject(['settings'], (sctx: any) => {
    const scope = sctx.settings.register(
      CHUNSUN_SETTINGS_NS,
      ChunsunSettingsSchema,
      { base: { enabled: true } },
    )
    if (!scope.get().enabled) return
    ctx.systemPrompt.variable(CHUNSUN_RULES_VAR, () => state.cachedRules)
    ctx.systemPrompt.section({
      name: 'chunsun:rules',
      order: 10,
      text: [
        '## 春笋自主交付常驻规则（始终生效）',
        '',
        '{{' + CHUNSUN_RULES_VAR + '}}',
      ].join('\n'),
    })
    void (async () => { refreshRules(await reader()) })()
  })
}

/** 由 ChunsunService.templateFetch 刷新成功后调用：更新常驻规则缓存值。 */
export function refreshChunsunSkill(ctx: any, reader: Reader): void {
  void (async () => { refreshRules(await reader()) })()
}
