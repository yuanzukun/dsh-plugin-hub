// dsh-pm Host 服务（由春笋 chunsun 驱动）：Client 面板的 RPC 后端 + 共享业务逻辑。
import { TypertRemoteService, Remote } from '@deepseek-ai/dsh-typert-protocol'
import { join } from 'node:path'
import { homedir } from 'node:os'
import { chmod, mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { refreshChunsunSkill } from './skills.js'
import { enc, parseEnv, pickCurrentRequirement, shq, upsertEnvLine } from './util.js'

export { ACTIVE_REQ_STATUS, pickCurrentRequirement } from './util.js'

const DEFAULT_API_URL = 'http://localhost:11111/api/v1'
/** 技能模板缓存根：~/.dsh/skills/chunsun/（DSH 官方 user-dsh 技能根）。 */
const SKILL_CACHE_DIR = join(homedir(), '.dsh', 'skills', 'chunsun')
/** 模板文件名清单（与 GET /harness/template 的 files key 对齐）。 */
const TEMPLATE_FILES = ['SKILL.md', 'loop-rules.md', 'commands.md', 'slash/chunsun.md', 'slash/chunsun-fix.md']

export class ChunsunService extends TypertRemoteService {
  static inject = ['fs', 'shell', 'sandboxPolicy']

  private readonly projectIdCache = new Map<string, string>()
  readonly grants = new Set<string>()

  constructor(ctx: any, config: any = {}) { super(ctx, 'chunsun') }

  /** 运行时由 static inject 注入的 fs 服务（基类 Context 类型未声明）。 */
  private get fs(): any { return (this.ctx as any).fs }

  /** 运行时由 static inject 注入的 shell 服务（基类 Context 类型未声明）。 */
  private get shell(): any { return (this.ctx as any).shell }

  /**
   * 构造写 `.env` 所用的沙箱策略：
   * 让围栏根对齐到「正在写的工作区」（连接面板传入的 cwd），而不是宿主级默认 session 的根。
   * 连接面板是用户 UI 操作（非模型写），写入目标就是用户当前选中的工作区，因此围栏根应随之。
   */
  private async envWritePolicy(cwd?: string): Promise<any> {
    const base = (this.ctx as any).sandboxPolicy?.resolve() ?? { mode: 'workspace-write', workspaceRoot: undefined }
    return { mode: base.mode, workspaceRoot: cwd || base.workspaceRoot }
  }

  async loadConfig(cwd?: string): Promise<{ apiUrl: string, secretKey: string }> {
    const cfg = { apiUrl: DEFAULT_API_URL, secretKey: '' }
    try {
      const opts: any = cwd ? { cwd } : {}
      const target = await this.fs.resolve('.env', opts)
      const text = await this.fs.readText(target)
      const env = parseEnv(text)
      if (env.CHUNSUN_API_URL) cfg.apiUrl = String(env.CHUNSUN_API_URL).replace(/\/+$/, '')
      if (env.CHUNSUN_SECRET_KEY) cfg.secretKey = String(env.CHUNSUN_SECRET_KEY)
    } catch (_e) { /* 读不到 .env 用默认 */ }
    return cfg
  }

  async httpJson(cfg: any, method: string, path: string, body?: unknown): Promise<any> {
    const m = String(method || 'GET').toUpperCase()
    const args = ['-sS', '-m', '15', '-X', m, '-H', 'Content-Type: application/json']
    if (cfg.secretKey) args.push('-H', 'Authorization: Bearer ' + cfg.secretKey)
    if (body !== undefined && body !== null) args.push('-d', JSON.stringify(body))
    args.push(cfg.apiUrl + path)
    const command = 'curl ' + args.map(shq).join(' ')
    const spec = this.shell.resolve({ command, timeoutMs: 20000, stdoutMaxBytes: 2097152 })
    const result = await this.shell.run(spec)
    const stdout = result.stdout ? result.stdout.text : ''
    const stderr = result.stderr ? result.stderr.text : ''
    let bodyObj: any = null
    try { bodyObj = JSON.parse(stdout) } catch (_e) { bodyObj = null }
    return { status: result.exitCode, body: bodyObj, raw: stdout, stderr }
  }

  async request(cfg: any, method: string, path: string, body?: unknown): Promise<any> {
    const r = await this.httpJson(cfg, method, path, body)
    if (r.body !== null) return r.body
    return { ok: false, httpError: 'HTTP ' + r.status, raw: r.raw, stderr: r.stderr }
  }

  async resolveProjectId(cfg: any): Promise<string> {
    const key = cfg.apiUrl + '|' + cfg.secretKey
    if (this.projectIdCache.has(key)) return this.projectIdCache.get(key)!
    const r = await this.request(cfg, 'GET', '/auth/secret-key-info')
    const pid = (r && r.success && r.data && r.data.projectId) ? r.data.projectId : ''
    if (pid) this.projectIdCache.set(key, pid)
    return pid
  }

  async apiCtxFromCwd(cwd?: string): Promise<{ cfg: any, projectId: string }> {
    const cfg = await this.loadConfig(cwd)
    const projectId = cfg.secretKey ? await this.resolveProjectId(cfg) : ''
    return { cfg, projectId }
  }

  reqBase(c: any, requirementId: string): string {
    return '/projects/' + enc(c.projectId) + '/requirements/' + enc(requirementId)
  }

  async remind(c: any, requirementId: string): Promise<{ reminders: string[] }> {
    const base = this.reqBase(c, requirementId)
    const reminders: string[] = []
    const runsResp = await this.request(c.cfg, 'GET', base + '/runs')
    const runs = (runsResp && runsResp.success && Array.isArray(runsResp.data)) ? runsResp.data : []
    const scenResp = await this.request(c.cfg, 'GET', base + '/scenarios')
    const scenarios = (scenResp && scenResp.success && Array.isArray(scenResp.data)) ? scenResp.data : []
    if (scenarios.length === 0) reminders.push('当前需求尚无任何验收场景——请先 upsert 至少一个 happy path 场景。')
    for (const s of scenarios) if (s.status === 'failing') reminders.push('场景「' + s.title + '」当前为 failing，需修复后置 passing。')
    const ctxResp = await this.request(c.cfg, 'GET', base + '/context')
    if (ctxResp && ctxResp.success && ctxResp.data && ctxResp.data.snapshot && Array.isArray(ctxResp.data.snapshot.openDecisions)) {
      const open = ctxResp.data.snapshot.openDecisions.length
      if (open > 0) reminders.push('存在 ' + open + ' 个未决 open decision，处理或更新后再继续。')
    }
    const running = runs.find((r: any) => r.status === 'running')
    if (running) {
      const stepsResp = await this.request(c.cfg, 'GET', base + '/runs/' + enc(running.id) + '/steps')
      const steps = (stepsResp && stepsResp.success && Array.isArray(stepsResp.data)) ? stepsResp.data : []
      if (steps.length >= 8 && !steps.some((s: any) => s.kind === 'test' || s.kind === 'verify')) reminders.push('当前 Run 已执行 ' + steps.length + ' 个 Step 尚无 test/verify——注意验收闭环。')
      let codeIdx = -1
      for (let i = steps.length - 1; i >= 0; i--) if (steps[i].kind === 'code') { codeIdx = i; break }
      if (codeIdx >= 0 && steps.length >= 4) {
        let hasReflectAfter = false
        for (let i = codeIdx + 1; i < steps.length; i++) if (steps[i].kind === 'reflect') { hasReflectAfter = true; break }
        if (!hasReflectAfter) reminders.push('当前 Run 已有 code Step 尚无 reflect——关键环节建议做一次评审-反思-改进（chunsun_step_add kind=reflect）。')
      }
    }
    return { reminders }
  }

  async statusFor(cfg: any): Promise<any> {
    const out: any = { apiUrl: cfg.apiUrl, hasSecretKey: cfg.secretKey.length > 0 }
    try {
      out.health = await this.request(cfg, 'GET', '/health')
      if (cfg.secretKey) {
        const p = await this.request(cfg, 'GET', '/auth/secret-key-info')
        out.project = p
        out.connected = !!(p && p.success === true)
      }
    } catch (e: any) { out.error = String(e && e.message ? e.message : e) }
    return out
  }

  @Remote('status')
  async status(args: { cwd?: string }): Promise<any> {
    const cfg = await this.loadConfig(args?.cwd)
    return this.statusFor(cfg)
  }

  @Remote('summary')
  async summary(args: { cwd?: string }): Promise<any> {
    const c = await this.apiCtxFromCwd(args?.cwd)
    const hasSecretKey = c.cfg.secretKey.length > 0
    if (!c.projectId) return { connected: false, apiUrl: c.cfg.apiUrl, hasSecretKey, requirements: [], current: null }
    const reqResp = await this.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/requirements')
    const requirements = (reqResp && reqResp.success && Array.isArray(reqResp.data)) ? reqResp.data : []
    const current = await this.currentDelivery(c, requirements)
    return {
      connected: true, apiUrl: c.cfg.apiUrl, hasSecretKey, projectId: c.projectId,
      requirements: requirements.map((r: any) => ({ id: r.id, description: r.description, status: r.status, updatedAt: r.updatedAt })),
      current,
    }
  }

  /** 当前交付焦点：取仍在处理的需求里最新一条（详见 pickCurrentRequirement）；无待处理需求时返回 null。 */
  private async currentDelivery(c: any, requirements: any[]): Promise<any> {
    const pick = pickCurrentRequirement(requirements)
    if (!pick) return null
    const base = this.reqBase(c, pick.id)
    const runsResp = await this.request(c.cfg, 'GET', base + '/runs')
    const runs = (runsResp && runsResp.success && Array.isArray(runsResp.data)) ? runsResp.data : []
    const run = runs.length ? runs[runs.length - 1] : null
    let stepCount = 0
    if (run) {
      const stepsResp = await this.request(c.cfg, 'GET', base + '/runs/' + enc(run.id) + '/steps')
      if (stepsResp && stepsResp.success && Array.isArray(stepsResp.data)) stepCount = stepsResp.data.length
    }
    return {
      requirement: { id: pick.id, description: pick.description, status: pick.status, updatedAt: pick.updatedAt },
      run: run ? { id: run.id, index: run.index, status: run.status } : null,
      stepCount,
    }
  }

  /** 项目总览：项目信息 + 统计（需求/完成率/缺陷）+ 最近活动，对齐平台「项目总览」页。 */
  @Remote('overview')
  async overview(args: { cwd?: string }): Promise<any> {
    const c = await this.apiCtxFromCwd(args?.cwd)
    const hasSecretKey = c.cfg.secretKey.length > 0
    if (!c.projectId) return { connected: false, apiUrl: c.cfg.apiUrl, hasSecretKey, project: null, activities: [] }
    const projResp = await this.request(c.cfg, 'GET', '/projects/' + enc(c.projectId))
    const project = (projResp && projResp.success && projResp.data) ? projResp.data : null
    const actResp = await this.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/activities?limit=20')
    const activities = (actResp && actResp.success && Array.isArray(actResp.data)) ? actResp.data : []
    return {
      connected: true, apiUrl: c.cfg.apiUrl, hasSecretKey, projectId: c.projectId,
      project, activities,
    }
  }

  @Remote('configRead')
  async configRead(args: { cwd?: string }): Promise<any> {
    const cfg = await this.loadConfig(args?.cwd)
    // 不回明文密钥：前端只显示「已保存」占位，避免密钥在会话/浏览器里明文可见。
    return { apiUrl: cfg.apiUrl, hasSecretKey: cfg.secretKey.length > 0 }
  }

  @Remote('configSave')
  async configSave(args: { cwd?: string, apiUrl: string, secretKey: string }): Promise<any> {
    const cwd = args?.cwd
    const apiUrl = String(args?.apiUrl || '').trim()
    const secretKey = String(args?.secretKey || '').trim()
    try {
      const target = await this.fs.resolve('.env', cwd ? { cwd } : {})
      let existing = ''
      try { existing = await this.fs.readText(target) } catch (_e) { existing = '' }
      let text = existing
      if (apiUrl) text = upsertEnvLine(text, 'CHUNSUN_API_URL', apiUrl)
      if (secretKey) text = upsertEnvLine(text, 'CHUNSUN_SECRET_KEY', secretKey)
      await this.fs.writeText(target, text, undefined, undefined, await this.envWritePolicy(cwd))
      // .env 含连接密钥（secret）；新建/重写后收紧为仅当前用户可读写。
      try { await chmod(target, 0o600) } catch (_e) { /* 平台 fs 可能不暴露路径，尽力而为 */ }
      const cfg = await this.loadConfig(cwd)
      return { saved: true, status: await this.statusFor(cfg) }
    } catch (e: any) {
      return { saved: false, error: String(e && e.message ? e.message : e) }
    }
  }

  /** 读取当前缓存模板目录（不存在返回空数组）。 */
  private async readCachedTemplate(): Promise<Record<string, string>> {
    const out: Record<string, string> = {}
    for (const rel of TEMPLATE_FILES) {
      try {
        out[rel] = await readFile(join(SKILL_CACHE_DIR, rel), 'utf8')
      } catch (_e) { /* 未缓存则跳过 */ }
    }
    return out
  }

  /** 落盘模板到缓存目录（原子覆盖）。 */
  private async writeCachedTemplate(files: Record<string, string>, templateVersion: string): Promise<void> {
    await mkdir(join(SKILL_CACHE_DIR, 'slash'), { recursive: true })
    for (const rel of TEMPLATE_FILES) {
      const body = files[rel]
      if (body === undefined || body === null) continue
      await writeFile(join(SKILL_CACHE_DIR, rel), String(body), 'utf8')
    }
    await writeFile(join(SKILL_CACHE_DIR, '.template-version'), templateVersion, 'utf8')
  }

  /** 模板缓存状态：版本 + 已缓存文件。 */
  @Remote('templateStatus')
  async templateStatus(args: { cwd?: string }): Promise<any> {
    const cfg = await this.loadConfig(args?.cwd)
    let version = ''
    let cachedFiles: string[] = []
    try {
      version = (await readFile(join(SKILL_CACHE_DIR, '.template-version'), 'utf8')).trim()
    } catch (_e) { /* 尚无缓存 */ }
    try {
      cachedFiles = (await readdir(join(SKILL_CACHE_DIR, 'slash'))).map((f: string) => 'slash/' + f)
        .concat((await readdir(SKILL_CACHE_DIR)).filter((f: string) => !f.startsWith('.') && !f.endsWith('.')))
    } catch (_e) { cachedFiles = [] }
    return {
      connected: !!(cfg.secretKey && cfg.apiUrl),
      apiUrl: cfg.apiUrl,
      hasSecretKey: cfg.secretKey.length > 0,
      templateVersion: version,
      cachedFiles,
    }
  }

  /** 拉取并缓存实例模板，返回模板版本 + 文件正文（供注入/设置页）。 */
  @Remote('templateFetch')
  async templateFetch(args: { cwd?: string }): Promise<any> {
    const cfg = await this.loadConfig(args?.cwd)
    if (!cfg.secretKey) return { ok: false, error: '未配置 CHUNSUN_SECRET_KEY，先在项目管理填连接配置' }
    const data = await this.request(cfg, 'GET', '/harness/template')
    if (!data || !data.success) return { ok: false, error: data?.error || '拉取模板失败', apiUrl: cfg.apiUrl }
    const payload = data.data
    const files: Record<string, string> = payload.files || {}
    const version = payload.templateVersion || ''
    await this.writeCachedTemplate(files, version)
    // 刷新后同步重注技能 + 常驻规则。
    try { refreshChunsunSkill(this.ctx, () => this.readTemplateForInject()) } catch (_e) { /* 注入失败不影响拉取结果 */ }
    return {
      ok: true,
      apiUrl: cfg.apiUrl,
      templateVersion: version,
      files,
      cachedFiles: TEMPLATE_FILES.filter((f) => files[f] !== undefined),
    }
  }

  /** 供注入用的缓存模板读取（内部，无 @Remote）——返回 SKILL.md 正文与 loop-rules。 */
  async readTemplateForInject(): Promise<{ skill: string; loopRules: string; version: string }> {
    const cached = await this.readCachedTemplate()
    return {
      skill: cached['SKILL.md'] || '',
      loopRules: cached['loop-rules.md'] || '',
      version: (await readFile(join(SKILL_CACHE_DIR, '.template-version'), 'utf8').catch(() => '' )).trim(),
    }
  }
}

export default ChunsunService
