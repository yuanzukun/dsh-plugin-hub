// dsh-pm 通用纯函数（无 IO、无宿主依赖）：供 Host 服务、工具与离线单测共用。
// 与 scripts/*.mjs 里重复的 parseEnv 保持一致（集成脚本走自己的副本，无需 import 宿主源码）。

/** shell 单引号安全转义：' -> '\''，整体再包一层单引号。 */
export function shq(s: string): string { return "'" + String(s).replace(/'/g, "'\\''") + "'" }

/** URL 路径组件编码。 */
export function enc(s: string): string { return encodeURIComponent(String(s)) }

/** 解析 `KEY=value` 风格的 .env 文本（去除单/双引号包裹的值）。 */
export function parseEnv(text: string): Record<string, string> {
  const out: Record<string, string> = {}
  for (const line of String(text || '').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
    if (!m) continue
    let val = m[2]
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1)
    out[m[1]] = val
  }
  return out
}

/** 在 .env 文本里 upsert 一个 KEY=value：已存在则替换该行，否则追加。输入末尾换行/空文本不产生多余空行。 */
export function upsertEnvLine(text: string, key: string, value: string): string {
  const raw = String(text || '').replace(/\r?\n+$/, '')
  if (raw === '') return key + '=' + value
  const lines = raw.split(/\r?\n/)
  let found = false
  const out: string[] = []
  for (const line of lines) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=/)
    if (m && m[1] === key) { out.push(key + '=' + value); found = true } else { out.push(line) }
  }
  if (!found) out.push(key + '=' + value)
  return out.join('\n')
}

/** 「待处理」需求的状态集合：尚未到达终态（completed/abandoned）的需求视为仍在处理。 */
export const ACTIVE_REQ_STATUS = ['pending', 'running', 'processing'] as const

/**
 * 从需求列表里选「当前交付焦点」：
 * 取仍在处理（待办/进行中/处理中）的需求中**最新**（createdAt 降序，缺失回退 updatedAt）的一条；
 * 没有任何待处理需求（全为 completed/abandoned 或空列表）时返回 null —— dock 据此渲染友好空状态。
 */
export function pickCurrentRequirement(requirements: any[]): any | null {
  const active = (requirements || [])
    .filter((r: any) => ACTIVE_REQ_STATUS.includes(r?.status))
    .slice()
    .sort((a: any, b: any) => {
      const ta = Date.parse(a?.createdAt || a?.updatedAt || '') || 0
      const tb = Date.parse(b?.createdAt || b?.updatedAt || '') || 0
      return tb - ta
    })
  return active[0] || null
}
