// dsh-pm 模型工具（由春笋 chunsun 驱动）：28 个 chunsun_* 工具，消费 `chunsun` 服务。
import { defineTool } from '@deepseek-ai/dsh-tools'
import { initChunsunSkill } from './skills.js'

export const name = 'dsh-pm-tools'
export const inject = ['chunsun', 'tools', 'approval', 'systemPrompt']

function enc(s: string): string { return encodeURIComponent(String(s)) }
function sessionCwd(exec: any): string | undefined {
  if (exec && exec.agent && exec.agent.session && exec.agent.session.header) return exec.agent.session.header.cwd
  return undefined
}

export function apply(ctx: any): void {
  const chunsun = ctx.chunsun

  // 春笋常驻规则（loop-rules）注入：技能正文由 DSH skill-filesystem 自动发现，无需在此注册。
  initChunsunSkill(ctx, () => chunsun.readTemplateForInject())

  async function apiCtx(exec: any) {
    return chunsun.apiCtxFromCwd(sessionCwd(exec))
  }

  function regTool(name: string, description: string, properties: any, required: string[], handler: (args: any, exec: any) => Promise<any>): void {
    // defineTool 的 parameters 是「属性名 → 值 schema」映射，必填以逐属性 required: true 标注
    // （不是 JSON Schema 的 { type:'object', properties, required } 形式）。
    const requiredSet = new Set(required || [])
    const parameters: Record<string, any> = {}
    for (const [key, spec] of Object.entries(properties || {})) {
      parameters[key] = { ...(spec as object), ...(requiredSet.has(key) ? { required: true } : {}) }
    }
    ctx.tools.register(defineTool({
      name,
      description,
      parameters,
      output: { schema: { type: 'array', items: { type: 'json' } }, render: (_a: any, v: any) => v },
      async execute(args: any, exec: any) {
        try {
          const result = await handler(args || {}, exec)
          return [{ type: 'text', text: JSON.stringify(result, null, 2) }]
        } catch (e: any) {
          return [{ type: 'text', text: JSON.stringify({ ok: false, error: String(e && e.message ? e.message : e) }, null, 2) }]
        }
      },
    }))
  }

  regTool('chunsun_status', '报告春笋自部署实例的连接状态与当前工作区密钥绑定的项目信息。', {}, [], async (_a, exec) => {
    const cfg = await chunsun.loadConfig(sessionCwd(exec))
    return chunsun.statusFor(cfg)
  })

  regTool('chunsun_requirement_list', '列出当前项目下的需求（可按 status 过滤）。', { status: { type: 'string' } }, [], async (args, exec) => {
    const c = await apiCtx(exec)
    const q = args.status ? '?status=' + enc(args.status) : ''
    return chunsun.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/requirements' + q)
  })

  regTool('chunsun_requirement_show', '查看单个需求详情。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/requirements/' + enc(args.requirementId))
  })

  regTool('chunsun_run_start', '为需求开一个新交付 Run；若已有 Run 在跑会返回 RUN_ALREADY_RUNNING。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'POST', chunsun.reqBase(c, args.requirementId) + '/runs', {})
  })

  regTool('chunsun_run_takeover', '接管僵尸 Run：把 running 旧 Run 置 finished 并开新 Run。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'POST', chunsun.reqBase(c, args.requirementId) + '/runs/takeover', {})
  })

  regTool('chunsun_run_status', 'Run 状态迁移（completed/finished/abandoned）；completed 会过平台硬门禁。', { requirementId: { type: 'string' }, status: { type: 'string' }, reason: { type: 'string' } }, ['requirementId', 'status'], async (args, exec) => {
    const c = await apiCtx(exec)
    const runsResp = await chunsun.request(c.cfg, 'GET', chunsun.reqBase(c, args.requirementId) + '/runs')
    const runs = (runsResp && runsResp.success && Array.isArray(runsResp.data)) ? runsResp.data : []
    const running = runs.find((r: any) => r.status === 'running')
    if (!running) return { ok: false, error: '当前没有 running 的 Run' }
    const body: any = { status: args.status }
    if (args.reason) body.endReason = args.reason
    return chunsun.request(c.cfg, 'PATCH', chunsun.reqBase(c, args.requirementId) + '/runs/' + enc(running.id), body)
  })

  regTool('chunsun_run_list', '列出需求的全部 Run。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'GET', chunsun.reqBase(c, args.requirementId) + '/runs')
  })

  regTool('chunsun_run_remind', '规则提醒层：返回当前需求未满足的柔性约束（进下一轮前调用）。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.remind(c, args.requirementId)
  })

  regTool('chunsun_step_add', '上报一个执行 Step（kind：think/code/test/verify/ask_user/info/reflect）。', { requirementId: { type: 'string' }, runId: { type: 'string' }, kind: { type: 'string' }, summary: { type: 'string' }, detail: { type: 'string' }, artifacts: { type: 'object', additionalProperties: true } }, ['requirementId', 'runId', 'kind', 'summary'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = { kind: args.kind, summary: args.summary }
    if (args.detail) body.detail = args.detail
    if (args.artifacts) body.artifacts = args.artifacts
    return chunsun.request(c.cfg, 'POST', chunsun.reqBase(c, args.requirementId) + '/runs/' + enc(args.runId) + '/steps', body)
  })

  regTool('chunsun_step_list', '列出某 Run 的 Steps。', { requirementId: { type: 'string' }, runId: { type: 'string' } }, ['requirementId', 'runId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'GET', chunsun.reqBase(c, args.requirementId) + '/runs/' + enc(args.runId) + '/steps')
  })

  regTool('chunsun_scenario_list', '列出需求验收场景（includeCases=true 时带用例）。', { requirementId: { type: 'string' }, includeCases: { type: 'boolean' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    const q = args.includeCases ? '?includeCases=true' : ''
    return chunsun.request(c.cfg, 'GET', chunsun.reqBase(c, args.requirementId) + '/scenarios' + q)
  })

  regTool('chunsun_scenario_upsert', '按 key upsert 验收场景（status：pending/passing/failing/blocked/waived）。', { requirementId: { type: 'string' }, key: { type: 'string' }, title: { type: 'string' }, description: { type: 'string' }, status: { type: 'string' } }, ['requirementId', 'key', 'title'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = { key: args.key, title: args.title }
    if (args.description) body.description = args.description
    if (args.status) body.status = args.status
    return chunsun.request(c.cfg, 'PUT', chunsun.reqBase(c, args.requirementId) + '/scenarios', body)
  })

  regTool('chunsun_scenario_status', '更新场景状态（pending/passing/failing/blocked/waived）。', { requirementId: { type: 'string' }, scenarioId: { type: 'string' }, status: { type: 'string' } }, ['requirementId', 'scenarioId', 'status'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'PATCH', chunsun.reqBase(c, args.requirementId) + '/scenarios/' + enc(args.scenarioId) + '/status', { status: args.status })
  })

  regTool('chunsun_case_upsert', 'upsert 验收用例（scenarioKey 传场景 key；kind：unit/integration/e2e；executionPlan：auto/manual）。', { requirementId: { type: 'string' }, scenarioKey: { type: 'string' }, title: { type: 'string' }, id: { type: 'string' }, kind: { type: 'string' }, executionPlan: { type: 'string' }, localPath: { type: 'string' } }, ['requirementId', 'scenarioKey', 'title'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = { scenarioKey: args.scenarioKey, title: args.title }
    if (args.id) body.id = args.id
    if (args.kind) body.kind = args.kind
    if (args.executionPlan) body.executionPlan = args.executionPlan
    if (args.localPath) body.localPath = args.localPath
    return chunsun.request(c.cfg, 'PUT', chunsun.reqBase(c, args.requirementId) + '/cases', body)
  })

  regTool('chunsun_case_status', '回写用例状态（passed/failed/blocked/skipped），executedBy 默认 agent。', { requirementId: { type: 'string' }, caseId: { type: 'string' }, status: { type: 'string' }, actualResult: { type: 'string' } }, ['requirementId', 'caseId', 'status'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = { status: args.status, executedBy: 'agent' }
    if (args.actualResult) body.actualResult = args.actualResult
    return chunsun.request(c.cfg, 'PATCH', chunsun.reqBase(c, args.requirementId) + '/cases/' + enc(args.caseId) + '/status', body)
  })

  regTool('chunsun_context_get', '拉取需求工作记忆 Context。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'GET', chunsun.reqBase(c, args.requirementId) + '/context')
  })

  regTool('chunsun_context_put', '写回需求工作记忆 Context（snapshot 顶层 key 合并）。', { requirementId: { type: 'string' }, snapshot: { type: 'object', additionalProperties: true } }, ['requirementId', 'snapshot'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'PUT', chunsun.reqBase(c, args.requirementId) + '/context', { snapshot: args.snapshot })
  })

  regTool('chunsun_reset', '全量重置需求：清工作记忆（保留澄清边界）+ 场景/用例重置 pending + 开新 Run。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'POST', chunsun.reqBase(c, args.requirementId) + '/reset', {})
  })

  regTool('chunsun_env_list', '列出项目环境变量（不含明文）。', {}, [], async (_args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/env-vars')
  })

  regTool('chunsun_env_get', '获取单个环境变量生效值；secret 变量需审批（会话内授权一次）。', { key: { type: 'string' } }, ['key'], async (args, exec) => {
    const c = await apiCtx(exec)
    const resp = await chunsun.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/env-vars/by-key/' + enc(args.key))
    if (!resp || !resp.success) return resp
    const item = resp.data
    if (!item.isSecret) return { key: item.key, value: item.value, source: 'platform', isSecret: false, description: item.description }
    const grantKey = c.projectId + '|' + args.key
    if (chunsun.grants.has(grantKey)) return { key: item.key, value: item.value, source: 'platform', isSecret: true, description: item.description, authorized: true, cached: true }
    if (ctx.approval === undefined) return { authorized: false, error: '审批服务不可用', key: item.key }
    let outcome: any
    try { outcome = await ctx.approval.request({ agent: exec.agent, toolName: 'chunsun_env_get', reason: '读取 secret 环境变量 ' + args.key }) } catch (_e) { outcome = 'unavailable' }
    if (outcome === 'allowed-once') { chunsun.grants.add(grantKey); return { key: item.key, value: item.value, source: 'platform', isSecret: true, description: item.description, authorized: true } }
    return { authorized: false, outcome, key: item.key }
  })

  regTool('chunsun_case_list', '列出需求的全部验收用例。', { requirementId: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'GET', chunsun.reqBase(c, args.requirementId) + '/cases')
  })

  regTool('chunsun_requirement_create', '创建需求。', { description: { type: 'string' }, application: { type: 'string' }, module: { type: 'string' } }, ['description'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = { description: args.description }
    if (args.application) body.application = args.application
    if (args.module) body.module = args.module
    return chunsun.request(c.cfg, 'POST', '/projects/' + enc(c.projectId) + '/requirements', body)
  })

  regTool('chunsun_requirement_update', '更新需求（status/application/module/description 至少一个）。', { requirementId: { type: 'string' }, status: { type: 'string' }, application: { type: 'string' }, module: { type: 'string' }, description: { type: 'string' } }, ['requirementId'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = {}
    if (args.status) body.status = args.status
    if (args.application) body.application = args.application
    if (args.module) body.module = args.module
    if (args.description) body.description = args.description
    if (Object.keys(body).length === 0) return { ok: false, error: '请提供至少一个要更新的字段' }
    return chunsun.request(c.cfg, 'PATCH', '/projects/' + enc(c.projectId) + '/requirements/' + enc(args.requirementId), body)
  })

  regTool('chunsun_defect_list', '列出缺陷（可按 status/severity 过滤）。', { status: { type: 'string' }, severity: { type: 'string' } }, [], async (args, exec) => {
    const c = await apiCtx(exec)
    const qs: string[] = []
    if (args.status) qs.push('status=' + enc(args.status))
    if (args.severity) qs.push('severity=' + enc(args.severity))
    const q = qs.length ? '?' + qs.join('&') : ''
    return chunsun.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/defects' + q)
  })

  regTool('chunsun_defect_create', '登记缺陷。', { title: { type: 'string' }, description: { type: 'string' }, severity: { type: 'string' }, application: { type: 'string' }, module: { type: 'string' } }, ['title'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = { title: args.title }
    if (args.description) body.description = args.description
    if (args.severity) body.severity = args.severity
    if (args.application) body.application = args.application
    if (args.module) body.module = args.module
    return chunsun.request(c.cfg, 'POST', '/projects/' + enc(c.projectId) + '/defects', body)
  })

  regTool('chunsun_defect_show', '查看单个缺陷详情。', { defectId: { type: 'string' } }, ['defectId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'GET', '/projects/' + enc(c.projectId) + '/defects/' + enc(args.defectId))
  })

  regTool('chunsun_defect_update', '更新缺陷（title/description/status/severity 至少一个）。', { defectId: { type: 'string' }, title: { type: 'string' }, description: { type: 'string' }, status: { type: 'string' }, severity: { type: 'string' } }, ['defectId'], async (args, exec) => {
    const c = await apiCtx(exec)
    const body: any = {}
    if (args.title) body.title = args.title
    if (args.description) body.description = args.description
    if (args.status) body.status = args.status
    if (args.severity) body.severity = args.severity
    if (Object.keys(body).length === 0) return { ok: false, error: '请提供至少一个要更新的字段' }
    return chunsun.request(c.cfg, 'PATCH', '/projects/' + enc(c.projectId) + '/defects/' + enc(args.defectId), body)
  })

  regTool('chunsun_fix', '派生唯一修复需求（缺陷 1:1）并进入自主交付：平台派生 origin=defect 的修复需求并把缺陷置 processing。', { defectId: { type: 'string' } }, ['defectId'], async (args, exec) => {
    const c = await apiCtx(exec)
    return chunsun.request(c.cfg, 'POST', '/projects/' + enc(c.projectId) + '/defects/' + enc(args.defectId) + '/convert-to-requirement', {})
  })
}
