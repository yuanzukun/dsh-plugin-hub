/**
 * Shared Typert invocation descriptors for Host (`./typert`) and Client (`./remote`).
 * Shape mirrors generated artifacts from `@deepseek-ai/dsh-typert-generator`.
 */
import { z } from 'zod'

const argsSchema = z.object({
  cwd: z.string().optional(),
}).passthrough()

const configSaveArgsSchema = z.object({
  cwd: z.string().optional(),
  apiUrl: z.string(),
  secretKey: z.string(),
}).passthrough()

const resultSchema = z.unknown()

function invocation(
  method: string,
  args: z.ZodType,
  argsSymbol: string,
  resultSymbol: string,
) {
  return {
    id: `dsh-pm#chunsun/${method}`,
    service: 'chunsun',
    namespace: 'chunsun',
    method,
    invocation: { kind: 'direct' as const },
    parameters: [
      {
        name: 'args',
        wire: 'args',
        source: 'json' as const,
        codec: {
          mode: 'strict' as const,
          typeSymbol: argsSymbol,
          schema: args,
        },
      },
    ],
    result: {
      mode: 'strict' as const,
      typeSymbol: resultSymbol,
      schema: resultSchema,
    },
  }
}

/** Host + Client share the same invocation list. */
export const INVOCATIONS = [
  invocation('status', argsSchema, 'dsh-pm#chunsun/status:args', 'dsh-pm#chunsun/status:result'),
  invocation('summary', argsSchema, 'dsh-pm#chunsun/summary:args', 'dsh-pm#chunsun/summary:result'),
  invocation('overview', argsSchema, 'dsh-pm#chunsun/overview:args', 'dsh-pm#chunsun/overview:result'),
  invocation('configRead', argsSchema, 'dsh-pm#chunsun/configRead:args', 'dsh-pm#chunsun/configRead:result'),
  invocation('configSave', configSaveArgsSchema, 'dsh-pm#chunsun/configSave:args', 'dsh-pm#chunsun/configSave:result'),
  invocation('templateStatus', argsSchema, 'dsh-pm#chunsun/templateStatus:args', 'dsh-pm#chunsun/templateStatus:result'),
  invocation('templateFetch', argsSchema, 'dsh-pm#chunsun/templateFetch:args', 'dsh-pm#chunsun/templateFetch:result'),
] as const
