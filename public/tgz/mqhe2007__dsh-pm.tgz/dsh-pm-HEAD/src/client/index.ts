// dsh-pm 客户端插件（由春笋 chunsun 驱动）。
// GUI 与会话/工作区强绑定：
//   A) conversation.input.dock —— 会话级常驻状态条，对齐原生 todo/goal/queue 布局；
//      纯实时状态展示：当前需求状态 + Run 轮次 + Step 数（不含配置入口，配置在「项目管理」视图）。
//   B) conversation.view「项目管理」—— 会话级整页视图，内建「总览」菜单（默认选中），
//      内容参考春笋平台项目总览页（统计条 + 需求进度 + 最近活动）。
import { createElement, Fragment, useCallback, useEffect, useState, type ReactNode } from 'react'
import TYPERT_REMOTE from '../remote.js'

export const inject = ['slots', 'remote', 'settingsScope']

function unwrap(result: any): any {
  if (result && typeof result === 'object' && 'ok' in result) {
    if (result.ok) return result.value
    throw new Error(result.error?.message || String(result.error || 'remote call failed'))
  }
  return result
}

/** 解析当前会话所属工作区（优先按 sessionIds 反查，回退最近工作区）。 */
function useWorkspace(useWorkspaces: any, sessionId?: string): any {
  if (typeof useWorkspaces !== 'function') return undefined
  return useWorkspaces((s: any) => {
    const items = s?.items
    if (!Array.isArray(items)) return undefined
    if (sessionId) {
      const bySession = items.find((w: any) => Array.isArray(w.sessionIds) && w.sessionIds.includes(sessionId))
      if (bySession) return bySession
    }
    return items.find((w: any) => w.workspaceId === s.recentWorkspaceId)
  })
}

const REQ_STATUS_LABEL: Record<string, string> = {
  pending: '待办', running: '进行中', processing: '处理中', abandoned: '已放弃', completed: '已完成',
}

/** 对齐春笋平台 REQ_STATUS_COLOR（running/processing 同色）。 */
const REQ_STATUS_COLOR: Record<string, string> = {
  pending: '#a3ab96', running: '#2563eb', processing: '#2563eb', abandoned: '#6b7280', completed: '#15803d',
}

function statusLabel(s: string | undefined): string {
  return REQ_STATUS_LABEL[s || ''] || s || '未知'
}

function statusColor(s: string | undefined): string {
  return REQ_STATUS_COLOR[s || ''] || '#6b7280'
}

function formatRel(ts: string | undefined): string {
  if (!ts) return ''
  const t = new Date(ts).getTime()
  if (Number.isNaN(t)) return String(ts).slice(0, 10)
  const diff = Date.now() - t
  const m = Math.floor(diff / 60000)
  if (m < 1) return '刚刚'
  if (m < 60) return m + ' 分钟前'
  const h = Math.floor(m / 60)
  if (h < 24) return h + ' 小时前'
  const d = Math.floor(h / 24)
  if (d < 7) return d + ' 天前'
  return String(ts).slice(0, 10)
}

const CSS = [
  // ---- dock：对齐原生 queue dock（居中、圆角顶、主题变量） ----
  '.chunsun-dock{box-sizing:border-box;width:calc(100% - var(--dsh-composer-side-clearance) - var(--dsh-composer-side-clearance) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));max-width:calc(var(--dsh-composer-card-max-width) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));margin:0 auto calc(0px - var(--dsh-composer-stack-gap) - 3px);padding:0 var(--dsh-composer-dock-inset);flex:none}',
  '.chunsun-dock-panel{background:var(--dsw-specific-tip);--dsh-scrollbar-thumb:var(--dsw-alias-scrollbar-bg-l2);--dsh-scrollbar-thumb-hover:var(--dsw-alias-scrollbar-hover-l2);border-radius:12px 12px 0 0;width:100%;padding:2px 0;position:relative;overflow:hidden}',
  '.chunsun-dock-panel:after{border:1px solid var(--dsw-alias-border-l1);border-radius:inherit;content:"";pointer-events:none;border-bottom:none;position:absolute;inset:0}',
  '.chunsun-dock-row{box-sizing:border-box;width:100%;height:36px;color:var(--dsw-alias-label-primary);text-align:left;align-items:center;gap:10px;padding:4px 12px;display:flex}',
  '.chunsun-dock-dot{width:8px;height:8px;border-radius:50%;flex:none;background:var(--dsw-alias-label-caption);display:inline-block}',
  '.chunsun-dock-dot-on{background:var(--dsw-alias-state-success-primary)}',
  '.chunsun-dock-dot-off{background:var(--dsw-alias-state-warn-primary)}',
  '.chunsun-dock-title{color:var(--dsw-alias-label-primary);flex:none;font-size:13px;font-weight:500;line-height:24px}',
  '.chunsun-dock-main{min-width:0;text-overflow:ellipsis;white-space:nowrap;flex:auto;font-size:13px;line-height:20px;display:flex;align-items:center;gap:8px;overflow:hidden}',
  '.chunsun-dock-desc{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-primary);font-size:12px;font-weight:400;line-height:20px}',
  '.chunsun-dock-sep{color:var(--dsw-alias-label-tertiary);flex:none}',
  '.chunsun-dock-meta{color:var(--dsw-alias-label-tertiary);flex:none;font-size:12px;white-space:nowrap}',
  '.chunsun-dock-reqid{flex:none;font-size:12px;color:var(--dsw-alias-label-secondary);white-space:nowrap}',
  '.chunsun-dock-connect{flex:none;padding:2px 10px;border:none;border-radius:6px;background:var(--dsw-alias-state-business-primary);color:#fff;font-size:12px;line-height:18px;cursor:pointer}',
  '.chunsun-dock-connect:hover{filter:brightness(1.06)}',
  '.chunsun-dock-connect--active{background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-label-secondary)}',
  '.chunsun-dock-config{border-top:1px solid var(--dsw-alias-border-l2);padding:10px 12px;background:var(--dsw-alias-bg-base)}',
  // ---- 通用：需求状态徽标 / 配置表单 ----
  '.chunsun-req-badge{display:inline-block;padding:1px 6px;border-radius:4px;font-size:10px;line-height:16px;color:#fff;flex:none}',
  '.chunsun-settings{display:flex;flex-direction:column;gap:8px}',
  '.chunsun-muted{color:var(--dsw-alias-label-tertiary);font-size:12px}',
  '.chunsun-field input{padding:6px 8px;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;font-size:12px;width:100%;box-sizing:border-box;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary)}',
  '.chunsun-actions{display:flex;gap:8px}',
  '.chunsun-actions button{padding:5px 12px;border-radius:6px;border:none;background:var(--dsw-alias-state-business-primary);color:#fff;cursor:pointer;font-size:12px}',
  '.chunsun-actions button.chunsun-ghost{background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-label-secondary)}',
  '.chunsun-pre{white-space:pre-wrap;background:var(--dsw-alias-bg-module-platform);padding:8px;border-radius:6px;font-size:11px;max-height:160px;overflow:auto;color:var(--dsw-alias-label-secondary)}',
  // ---- 项目管理视图 ----
  '.chunsun-pm{box-sizing:border-box;display:flex;height:100%;min-height:0;background:var(--dsw-alias-bg-base)}',
  '.chunsun-pm-menu{flex:none;width:116px;border-right:1px solid var(--dsw-alias-border-l2);padding:12px 8px;display:flex;flex-direction:column;gap:2px}',
  '.chunsun-pm-menu-item{font-size:13px;line-height:20px;color:var(--dsw-alias-label-secondary);padding:6px 10px;border-radius:8px;cursor:pointer}',
  '.chunsun-pm-menu-item:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  '.chunsun-pm-menu-item--active{color:var(--dsw-alias-state-business-primary);background:var(--dsw-alias-bg-module-platform);font-weight:500}',
  '.chunsun-pm-main{flex:1;min-width:0;padding:16px 20px;overflow-y:auto;display:flex;flex-direction:column;gap:12px}',
  '.chunsun-pm-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px;flex-wrap:wrap}',
  '.chunsun-pm-title{font-size:16px;font-weight:700;color:var(--dsw-alias-label-primary)}',
  '.chunsun-pm-desc{font-size:12px;color:var(--dsw-alias-label-tertiary);word-break:break-all}',
  '.chunsun-pm-head-actions{display:flex;align-items:center;gap:8px}',
  '.chunsun-pm-refresh{background:none;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:6px;font-size:12px;padding:3px 10px;cursor:pointer}',
  '.chunsun-pm-refresh:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  '.chunsun-stat-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(118px,1fr));gap:8px}',
  '.chunsun-stat-item{border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-module-platform);padding:10px 14px;display:flex;flex-direction:column;gap:2px;min-width:0;font:inherit;text-align:left}',
  '.chunsun-stat-value{font-size:22px;font-weight:700;line-height:1.1;color:var(--dsw-alias-label-primary)}',
  '.chunsun-stat-label{font-size:11px;color:var(--dsw-alias-label-tertiary)}',
  '.chunsun-panel{border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-base);padding:12px 14px;min-width:0}',
  '.chunsun-panel-title{font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary);margin-bottom:10px}',
  '.chunsun-meter-caption{font-size:11px;color:var(--dsw-alias-label-tertiary);margin:0 0 6px}',
  '.chunsun-meter-caption--spaced{margin-top:12px}',
  '.chunsun-progress-wrap{display:flex;align-items:center;gap:10px}',
  '.chunsun-progress{flex:1;height:6px;border-radius:999px;background:var(--dsw-alias-bg-module-platform);overflow:hidden}',
  '.chunsun-progress-fill{height:100%;border-radius:999px;background:var(--dsw-alias-state-business-primary)}',
  '.chunsun-progress-value{flex:none;font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary)}',
  '.chunsun-meter-stack{display:flex;height:8px;border-radius:999px;overflow:hidden;background:var(--dsw-alias-bg-module-platform)}',
  '.chunsun-meter-seg{min-width:2px;height:100%}',
  '.chunsun-meter-legend{display:flex;flex-wrap:wrap;gap:6px 14px;margin:8px 0 0;list-style:none;padding:0;font-size:11px;color:var(--dsw-alias-label-tertiary)}',
  '.chunsun-meter-legend li{display:inline-flex;align-items:center;gap:5px}',
  '.chunsun-meter-dot{width:8px;height:8px;border-radius:999px}',
  '.chunsun-activity{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}',
  '.chunsun-activity-item{display:flex;gap:10px;padding:7px 2px;border-bottom:1px solid var(--dsw-alias-border-l1);align-items:center;min-width:0}',
  '.chunsun-activity-item:last-child{border-bottom:none}',
  '.chunsun-activity-desc{flex:1;min-width:0;font-size:12px;color:var(--dsw-alias-label-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
  '.chunsun-activity-meta{flex:none;font-size:11px;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
  // ---- 菜单 / 平台链接 ----
  '.chunsun-pm-link{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--dsw-alias-state-business-primary);text-decoration:none;padding:8px 10px;border-radius:8px}',
  '.chunsun-pm-link:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  '.chunsun-pm-link-icon{font-size:11px;flex:none}',
  '.chunsun-stat-item--clickable{cursor:pointer;transition:background-color .15s ease}',
  '.chunsun-stat-item--clickable:hover{background:var(--dsw-alias-interactive-bg-hover)}',
  // ---- 看板 ----
  '.chunsun-board{display:flex;flex-direction:column;gap:12px;min-width:0}',
  '.chunsun-board-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px}',
  '.chunsun-board-cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;align-items:start}',
  '.chunsun-board-col{border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-module-platform);padding:8px;min-width:0}',
  '.chunsun-board-col-head{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary);padding:2px 4px 8px}',
  '.chunsun-board-col-count{color:var(--dsw-alias-label-tertiary);font-weight:400}',
  '.chunsun-board-card{border:1px solid var(--dsw-alias-border-l1);border-radius:10px;background:var(--dsw-alias-bg-base);padding:8px 10px;margin-bottom:8px;min-width:0}',
  '.chunsun-board-card:last-child{margin-bottom:0}',
  '.chunsun-board-card-desc{font-size:12px;line-height:18px;color:var(--dsw-alias-label-primary);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}',
  '.chunsun-board-card-meta{display:flex;align-items:center;gap:8px;margin-top:6px;font-size:11px;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
  '.chunsun-board-empty{padding:6px 4px;font-size:12px;color:var(--dsw-alias-label-tertiary)}',
  // ---- 连接配置页 ----
  '.chunsun-config-status{display:flex;flex-direction:column;gap:4px;margin-bottom:10px;font-size:12px;color:var(--dsw-alias-label-secondary)}',
].join('')

function insertPluginStyles(css: string): () => void {
  const existing = document.querySelector('style[data-dsh-pm="chunsun-panel"]')
  if (existing) existing.remove()
  const tag = document.createElement('style')
  tag.dataset.dshPm = 'chunsun-panel'
  tag.textContent = css
  document.head.append(tag)
  return () => { tag.remove() }
}

export async function apply(ctx: any): Promise<() => Promise<void>> {
  const disposeRemote = await ctx.remote.$mount(TYPERT_REMOTE)
  // Mount installs service key "remote.chunsun"; read without inject requirement.
  const chunsun = ctx.get('remote.chunsun')
  if (!chunsun) throw new Error('dsh-pm: remote.chunsun missing after $mount')

  const disposeStyles = insertPluginStyles(CSS)
  const slots = ctx.slots

  /** 通用轮询 hook：interval 毫秒拉一次 fn，cwd 变化即重拉。 */
  function usePoll(fn: () => void, cwd: string | undefined, interval: number): void {
    useEffect(() => {
      let alive = true
      const timer = ctx.get('timer')
      const wrapped = () => { if (alive) fn() }
      wrapped()
      let dispose = () => {}
      if (timer?.interval) dispose = timer.interval(wrapped, interval)
      return () => { alive = false; dispose() }
    }, [cwd, fn])
  }

  /** 交付摘要（需求 + 当前需求/run/step），dock 用，5s。 */
  function useChunsunSummary(cwd: string | undefined): { summary: any; refresh: () => void } {
    const [summary, setSummary] = useState<any>(null)
    const refresh = useCallback(() => {
      chunsun.summary({ cwd }).then((r: any) => setSummary(unwrap(r))).catch(() => {})
    }, [cwd])
    usePoll(refresh, cwd, 5000)
    return { summary, refresh }
  }

  /** 项目总览（项目 + 统计 + 活动），「总览」页用，10s + 手动刷新。 */
  function useChunsunOverview(cwd: string | undefined): { overview: any; refresh: () => void; refreshing: boolean } {
    const [overview, setOverview] = useState<any>(null)
    const [refreshing, setRefreshing] = useState(false)
    const refresh = useCallback(() => {
      setRefreshing(true)
      chunsun.overview({ cwd }).then((r: any) => {
        setOverview(unwrap(r))
      }).catch(() => {}).finally(() => { setRefreshing(false) })
    }, [cwd])
    usePoll(refresh, cwd, 10000)
    return { overview, refresh, refreshing }
  }

  /** 春笋启停开关：绑定 `chunsun` settings namespace，读/写 enabled（部署级持久化）。 */
  function useChunsunEnabled(): { enabled: boolean; setEnabled: (v: boolean) => Promise<void> } {
    const [enabled, setState] = useState(true)
    const scope = ctx.get('settingsScope')?.bind({ namespace: 'chunsun' })
    useEffect(() => {
      const snap = () => {
        const s = scope?.getSnapshot()
        if (s && s.status === 'ready' && typeof s.value?.enabled === 'boolean') setState(s.value.enabled)
      }
      snap()
      const off = scope?.subscribe(snap)
      return () => { off?.() }
    }, [scope])
    const setEnabled = useCallback(async (v: boolean) => { await scope?.set('enabled', v) }, [scope])
    return { enabled, setEnabled }
  }

  /** 连接向导（读/写工作区 .env），dock 与视图共用。 */
  function ChunsunConfigForm(props: { cwd?: string; onSaved?: (value?: any) => void; onCancel?: () => void }): ReactNode {
    const [apiUrl, setApiUrl] = useState('')
    const [secretKey, setSecretKey] = useState('')
    const [hasKey, setHasKey] = useState(false)
    const [status, setStatus] = useState<any>(null)
    const [saving, setSaving] = useState(false)

    useEffect(() => {
      let alive = true
      chunsun.configRead({ cwd: props.cwd }).then((r: any) => {
        if (!alive) return
        const cfg = unwrap(r)
        if (cfg?.apiUrl) setApiUrl(cfg.apiUrl)
        // configRead 不回明文密钥：只标记「已保存」，密码框用占位提示，不回填。
        setHasKey(!!cfg?.hasSecretKey)
      }).catch(() => {})
      return () => { alive = false }
    }, [props.cwd])

    function doSave() {
      setSaving(true)
      chunsun.configSave({ cwd: props.cwd, apiUrl, secretKey }).then((r: any) => {
        const value = unwrap(r)
        setStatus(value?.status || value)
        setSaving(false)
        props.onSaved?.(value)
      }).catch((e: any) => { setStatus({ error: String(e) }); setSaving(false) })
    }

    return createElement('div', { className: 'chunsun-settings' },
      createElement('div', { className: 'chunsun-muted' }, '配置当前工作区的连接'),
      createElement('div', { className: 'chunsun-field' },
        createElement('input', { value: apiUrl, onChange: (e: any) => setApiUrl(e.target.value), placeholder: '实例地址，如 http://localhost:11111/api/v1' }),
      ),
      createElement('div', { className: 'chunsun-field' },
        createElement('input', { value: secretKey, type: 'password', onChange: (e: any) => setSecretKey(e.target.value), placeholder: hasKey ? '已保存密钥，如需更换请输入' : 'Secret Key（sk_...）' }),
      ),
      createElement('div', { className: 'chunsun-actions' },
        createElement('button', { onClick: doSave, disabled: saving }, saving ? '保存中…' : '保存并测试连接'),
        props.onCancel ? createElement('button', { className: 'chunsun-ghost', onClick: props.onCancel }, '取消') : null,
      ),
      status ? createElement('pre', { className: 'chunsun-pre' }, JSON.stringify(status, null, 2)) : null,
    )
  }

  /** 当前需求徽标（状态色）。 */
  function ReqBadge(props: { status?: string }): ReactNode {
    return createElement('span', {
      className: 'chunsun-req-badge',
      style: { backgroundColor: statusColor(props.status) },
    }, statusLabel(props.status))
  }

  // ---- A) 会话级常驻 dock：composer 上方，对齐原生 queue dock 布局 ----
  function DockView(props: { useWorkspaces?: any; sessionId?: string }): ReactNode {
    const { enabled } = useChunsunEnabled()
    const cwd = useWorkspace(props.useWorkspaces, props.sessionId)?.path
    const { summary, refresh: refreshSummary } = useChunsunSummary(cwd)
    const [showConfig, setShowConfig] = useState(false)
    if (!enabled) return null
    if (!cwd) return null

    const connected = !!(summary && summary.connected)
    const current = (summary && summary.current) || null
    const needsConfig = !!(summary && !summary.hasSecretKey)
    // 只有「需要人工接入」的状态才在 dock 里给出连接入口：未配置 / 无法连接。
    // 已连接时 dock 保持纯粹的状态展示（对齐早期「dock 只做实时状态」的决定）。
    const showConnect = !!summary && (needsConfig || !connected)

    let main: ReactNode
    if (!summary) {
      main = createElement('span', { className: 'chunsun-dock-meta' }, '加载中…')
    } else if (needsConfig) {
      main = createElement('span', { className: 'chunsun-dock-meta' }, '未配置，点击「连接」完成接入')
    } else if (!connected) {
      main = createElement('span', { className: 'chunsun-dock-meta' }, '无法连接春笋实例')
    } else if (current && current.requirement) {
      const run = current.run
      main = createElement(Fragment, null,
        createElement(ReqBadge, { status: current.requirement.status }),
        createElement('span', { className: 'chunsun-dock-desc' }, String(current.requirement.description || '未命名需求').slice(0, 40)),
        run ? createElement(Fragment, null,
          createElement('span', { className: 'chunsun-dock-sep' }, '·'),
          createElement('span', { className: 'chunsun-dock-meta' }, '第 ' + run.index + ' 轮'),
        ) : null,
        current.stepCount > 0 ? createElement(Fragment, null,
          createElement('span', { className: 'chunsun-dock-sep' }, '·'),
          createElement('span', { className: 'chunsun-dock-meta' }, current.stepCount + ' 步'),
        ) : null,
      )
    } else {
      main = createElement('span', { className: 'chunsun-dock-meta' }, '暂无待处理需求')
    }

    return createElement('div', { className: 'chunsun-dock' },
      createElement('div', { className: 'chunsun-dock-panel' },
        createElement('div', { className: 'chunsun-dock-row' },
          createElement('span', { className: 'chunsun-dot chunsun-dock-dot ' + (connected ? 'chunsun-dock-dot-on' : 'chunsun-dock-dot-off') }),
          createElement('span', { className: 'chunsun-dock-title' }, '春笋'),
          current && current.requirement ? createElement('span', { className: 'chunsun-dock-reqid' }, String(current.requirement.id)) : null,
          createElement('div', { className: 'chunsun-dock-main' }, main),
          showConnect ? createElement('button', {
            className: 'chunsun-dock-connect' + (showConfig ? ' chunsun-dock-connect--active' : ''),
            onClick: () => setShowConfig((v) => !v),
            title: showConfig ? '收起连接配置' : '配置连接',
          }, showConfig ? '收起' : '连接') : null,
        ),
        showConfig ? createElement('div', { className: 'chunsun-dock-config' },
          createElement(ChunsunConfigForm, {
            cwd,
            // 保存后刷新摘要；若本次保存已确认连接成功（secret key 绑定到项目），
            // 自动收起表单，dock 回到纯状态展示。失败/未连接时保留表单便于用户改错。
            onSaved: (value: any) => {
              refreshSummary()
              if (value && value.status && value.status.connected) setShowConfig(false)
            },
          }),
        ) : null,
      ),
    )
  }

  // ---- B) 会话级整页视图：项目管理（总览 / 看板 / 连接配置 + 平台链接） ----
  const BOARD_COLUMNS = [
    { status: 'pending', label: statusLabel('pending') },
    { status: 'running', label: '进行中' },
    { status: 'completed', label: statusLabel('completed') },
    { status: 'abandoned', label: statusLabel('abandoned') },
  ]

  function OverviewPane(props: {
    title: string
    overview: any
    refreshing: boolean
    refresh: () => void
    onOpenBoard: () => void
  }): ReactNode {
    const connected = !!(props.overview && props.overview.connected)
    const project = (props.overview && props.overview.project) || null
    const stats = (project && project.statistics) || null
    const req = stats?.requirements || null
    const rates = stats?.rates || null
    const defects = stats?.defects || null
    const activities = (props.overview && Array.isArray(props.overview.activities)) ? props.overview.activities : []

    const reqTotal = Math.max(req?.total ?? 0, 0)
    const reqRunning = (req?.running ?? 0) + (req?.processing ?? 0)
    const defectUnresolved = (defects?.open ?? 0) + (defects?.processing ?? 0)
    const reqCompletion = rates?.requirementCompletionPct ?? 0
    const meter = [
      { key: 'pending', label: statusLabel('pending'), count: req?.pending ?? 0, color: statusColor('pending') },
      { key: 'running', label: '运行中', count: reqRunning, color: statusColor('running') },
      { key: 'abandoned', label: statusLabel('abandoned'), count: req?.abandoned ?? 0, color: statusColor('abandoned') },
      { key: 'completed', label: statusLabel('completed'), count: req?.completed ?? 0, color: statusColor('completed') },
    ].filter((s) => s.count > 0)

    return createElement(Fragment, null,
      createElement('div', { className: 'chunsun-pm-head' },
        createElement('div', null,
          createElement('div', { className: 'chunsun-pm-title' }, props.title),
          project?.description ? createElement('div', { className: 'chunsun-pm-desc' }, String(project.description)) : null,
        ),
        createElement('div', { className: 'chunsun-pm-head-actions' },
          createElement('span', { className: 'chunsun-dock-dot ' + (connected ? 'chunsun-dock-dot-on' : 'chunsun-dock-dot-off') }),
          createElement('span', { className: 'chunsun-muted' }, connected ? '已连接' : '未连接'),
          createElement('button', { className: 'chunsun-pm-refresh', onClick: props.refresh, disabled: props.refreshing }, props.refreshing ? '刷新中…' : '刷新'),
        ),
      ),
      createElement('div', { className: 'chunsun-stat-strip' },
        createElement('button', {
          className: 'chunsun-stat-item chunsun-stat-item--clickable',
          onClick: props.onOpenBoard,
          title: '查看需求看板',
        },
          createElement('span', { className: 'chunsun-stat-value' }, String(reqTotal)),
          createElement('span', { className: 'chunsun-stat-label' }, '需求总数'),
        ),
        createElement('div', { className: 'chunsun-stat-item' },
          createElement('span', { className: 'chunsun-stat-value' }, String(reqRunning)),
          createElement('span', { className: 'chunsun-stat-label' }, '运行中'),
        ),
        createElement('div', { className: 'chunsun-stat-item' },
          createElement('span', { className: 'chunsun-stat-value' }, String(req?.completed ?? 0)),
          createElement('span', { className: 'chunsun-stat-label' }, '已完成'),
        ),
        createElement('div', { className: 'chunsun-stat-item' },
          createElement('span', { className: 'chunsun-stat-value' }, String(defectUnresolved)),
          createElement('span', { className: 'chunsun-stat-label' }, '缺陷'),
        ),
      ),
      createElement('div', { className: 'chunsun-panel' },
        createElement('div', { className: 'chunsun-panel-title' }, '需求进度'),
        reqTotal > 0 ? createElement(Fragment, null,
          createElement('p', { className: 'chunsun-meter-caption' }, '完成率'),
          createElement('div', { className: 'chunsun-progress-wrap' },
            createElement('div', { className: 'chunsun-progress' },
              createElement('div', { className: 'chunsun-progress-fill', style: { width: Math.min(100, Math.max(0, reqCompletion)) + '%' } }),
            ),
            createElement('span', { className: 'chunsun-progress-value' }, String(reqCompletion) + '%'),
          ),
          createElement('p', { className: 'chunsun-meter-caption chunsun-meter-caption--spaced' }, '状态分布'),
          createElement('div', { className: 'chunsun-meter-stack', role: 'img', 'aria-label': '需求状态分布，共 ' + reqTotal + ' 项' },
            meter.map((s) => createElement('div', {
              key: s.key,
              className: 'chunsun-meter-seg',
              style: { width: Math.round((s.count / reqTotal) * 100) + '%', backgroundColor: s.color },
              title: s.label + ' · ' + s.count,
            })),
          ),
          createElement('ul', { className: 'chunsun-meter-legend' },
            meter.map((s) => createElement('li', { key: s.key },
              createElement('span', { className: 'chunsun-meter-dot', style: { backgroundColor: s.color } }),
              s.label + ' · ' + s.count,
            )),
          ),
        ) : createElement('div', { className: 'chunsun-muted' }, '暂无需求，可在对话中描述交付目标。'),
      ),
      createElement('div', { className: 'chunsun-panel' },
        createElement('div', { className: 'chunsun-panel-title' }, '最近活动'),
        activities.length === 0
          ? createElement('div', { className: 'chunsun-muted' }, '暂无活动')
          : createElement('ul', { className: 'chunsun-activity' },
            activities.map((a: any) => createElement('li', { key: a.id, className: 'chunsun-activity-item' },
              createElement('span', { className: 'chunsun-activity-desc', title: a.description }, String(a.description || a.action)),
              createElement('span', { className: 'chunsun-activity-meta' },
                (a.user && a.user.nickname ? String(a.user.nickname) : '系统') + ' · ' + formatRel(a.createdAt),
              ),
            )),
          ),
      ),
    )
  }

  function BoardPane(props: { requirements: any[]; refresh: () => void }): ReactNode {
    return createElement('div', { className: 'chunsun-board' },
      createElement('div', { className: 'chunsun-board-head' },
        createElement('div', { className: 'chunsun-pm-title' }, '看板'),
        createElement('button', { className: 'chunsun-pm-refresh', onClick: props.refresh }, '刷新'),
      ),
      createElement('div', { className: 'chunsun-board-cols' },
        BOARD_COLUMNS.map((c) => {
          const items = props.requirements.filter((r) =>
            r.status === c.status || (c.status === 'running' && r.status === 'processing'))
          return createElement('div', { key: c.status, className: 'chunsun-board-col' },
            createElement('div', { className: 'chunsun-board-col-head' },
              createElement('span', { className: 'chunsun-meter-dot', style: { backgroundColor: statusColor(c.status) } }),
              c.label,
              createElement('span', { className: 'chunsun-board-col-count' }, String(items.length)),
            ),
            items.length === 0
              ? createElement('div', { className: 'chunsun-board-empty' }, '无')
              : items.map((r: any) => createElement('div', { key: r.id, className: 'chunsun-board-card' },
                  createElement('div', { className: 'chunsun-board-card-desc', title: r.description }, String(r.description || r.id)),
                  createElement('div', { className: 'chunsun-board-card-meta' },
                    createElement('span', null, String(r.id).slice(0, 8)),
                    r.updatedAt ? createElement('span', null, String(r.updatedAt).slice(0, 10)) : null,
                  ),
                )),
          )
        }),
      ),
    )
  }

  function ConfigPane(props: { cwd: string; overview: any; refresh: () => void; refreshSummary: () => void }): ReactNode {
    const connected = !!(props.overview && props.overview.connected)
    const hasKey = !!(props.overview && props.overview.hasSecretKey)
    const project = (props.overview && props.overview.project) || null
    const apiUrl = (props.overview && props.overview.apiUrl) || ''
    const [templateStatus, setTemplateStatus] = useState<any>(null)
    const [refreshing, setRefreshing] = useState(false)
    const [templateResult, setTemplateResult] = useState<any>(null)
    const loadStatus = useCallback(() => {
      chunsun.templateStatus({ cwd: props.cwd }).then((r: any) => setTemplateStatus(unwrap(r))).catch(() => {})
    }, [props.cwd])
    useEffect(() => { loadStatus() }, [loadStatus])
    function doRefresh() {
      setRefreshing(true); setTemplateResult(null)
      chunsun.templateFetch({ cwd: props.cwd }).then((r: any) => { setTemplateResult(unwrap(r)); loadStatus() })
        .catch((e: any) => { setTemplateResult({ error: String(e) }) }).finally(() => { setRefreshing(false) })
    }
    const tv = (templateStatus && templateStatus.templateVersion) || ''
    return createElement('div', { className: 'chunsun-panel' },
      createElement('div', { className: 'chunsun-panel-title' }, '连接配置'),
      createElement('div', { className: 'chunsun-config-status' },
        createElement('div', null, '实例地址：', createElement('span', { className: 'chunsun-muted' }, apiUrl || '未配置')),
        createElement('div', null, '项目：', createElement('span', { className: 'chunsun-muted' }, project?.name || '—')),
        createElement('div', null, '状态：', createElement('span', { className: 'chunsun-muted' }, connected ? '已连接' : (hasKey ? '未连接' : '未配置'))),
      ),
      createElement(ChunsunConfigForm, {
        cwd: props.cwd,
        onSaved: () => { props.refresh(); props.refreshSummary() },
      }),
      createElement('div', { className: 'chunsun-config-status', style: { marginTop: '10px' } },
        createElement('div', null, 'harness 模板版本：', createElement('span', { className: 'chunsun-muted' }, tv || '尚未拉取')),
      ),
      createElement('div', { className: 'chunsun-actions' },
        createElement('button', { onClick: doRefresh, disabled: refreshing }, refreshing ? '刷新中…' : '刷新 harness 模板缓存'),
      ),
      templateResult ? createElement('pre', { className: 'chunsun-pre' }, JSON.stringify(templateResult, null, 2)) : null,
    )
  }

  /** DSH 设置页（settings.section，root 作用域）：春笋启停开关（部署级）。连接/密钥在工作区级，不在此。 */
  function SettingsPanel(props: { close?: () => void }): ReactNode {
    const { enabled, setEnabled } = useChunsunEnabled()
    const [saving, setSaving] = useState(false)
    return createElement('div', { className: 'chunsun-settings' },
      createElement('div', { className: 'chunsun-panel-title' }, '春笋'),
      createElement('div', { className: 'chunsun-config-status' },
        createElement('div', null, '启用春笋（dsh-pm 插件）',
          createElement('label', { style: { marginLeft: '8px' } },
            createElement('input', {
              type: 'checkbox',
              checked: enabled,
              disabled: saving,
              onChange: (e: any) => {
                const next = e.target.checked
                setSaving(true)
                setEnabled(next).finally(() => setSaving(false))
              },
            }),
          ),
        ),
        createElement('div', { className: 'chunsun-muted' },
          enabled
            ? '已启用：对话交付面板、项目管理视图与春笋常驻规则生效。'
            : '已停用：春笋交付面板与常驻规则不注入。连接配置与模板缓存在工作区级。',
        ),
      ),
    )
  }

  function ProjectManagementView(props: { useWorkspaces?: any; sessionId?: string }): ReactNode {
    const { enabled } = useChunsunEnabled()
    const workspace = useWorkspace(props.useWorkspaces, props.sessionId)
    const cwd = workspace?.path
    const { overview, refresh, refreshing } = useChunsunOverview(cwd)
    const { summary, refresh: refreshSummary } = useChunsunSummary(cwd)
    const [menu, setMenu] = useState('overview')
    if (!enabled) return null
    if (!cwd) {
      return createElement('div', { className: 'chunsun-pm' },
        createElement('div', { className: 'chunsun-pm-main' },
          createElement('div', { className: 'chunsun-muted' }, '未检测到当前会话所属工作区。'),
        ),
      )
    }

    const project = (overview && overview.project) || null
    const title = project?.name || workspace?.title || cwd.split('/').pop() || cwd
    const apiUrl = (overview && overview.apiUrl) || ''
    const platformUrl = apiUrl ? apiUrl.replace(/\/api\/v1\/?$/, '') : ''
    const requirements = (summary && Array.isArray(summary.requirements)) ? summary.requirements : []

    const menuItems = [
      { key: 'overview', label: '总览' },
      { key: 'board', label: '看板' },
      { key: 'config', label: '连接配置' },
    ]

    return createElement('div', { className: 'chunsun-pm' },
      createElement('nav', { className: 'chunsun-pm-menu' },
        menuItems.map((m) => createElement('div', {
          key: m.key,
          className: 'chunsun-pm-menu-item' + (menu === m.key ? ' chunsun-pm-menu-item--active' : ''),
          onClick: () => setMenu(m.key),
        }, m.label)),
        platformUrl ? createElement('a', {
          className: 'chunsun-pm-link',
          href: platformUrl,
          target: '_blank',
          rel: 'noreferrer',
          title: '打开春笋平台',
        }, '春笋平台', createElement('span', { className: 'chunsun-pm-link-icon' }, '↗')) : null,
      ),
      createElement('div', { className: 'chunsun-pm-main' },
        menu === 'overview' ? createElement(OverviewPane, { title, overview, refreshing, refresh, onOpenBoard: () => setMenu('board') }) : null,
        menu === 'board' ? createElement(BoardPane, { requirements, refresh: refreshSummary }) : null,
        menu === 'config' ? createElement(ConfigPane, { cwd, overview, refresh, refreshSummary }) : null,
      ),
    )
  }

  slots.inject('conversation.input.dock', () => slots.register(
    { name: 'conversation.input.dock', id: 'chunsun', order: 30, label: '春笋交付' },
    (props: any) => createElement(DockView, { useWorkspaces: props.useWorkspaces, sessionId: props.sessionId }),
  ))

  slots.inject('conversation.view', () => {
    const scope = ctx.get('settingsScope')?.bind({ namespace: 'chunsun' })
    let entry: (() => void) | null = null
    const reconcile = (): void => {
      const enabled = scope?.getSnapshot()?.value?.enabled !== false
      if (enabled && !entry) {
        entry = slots.register(
          { name: 'conversation.view', id: 'chunsun', order: 20, label: '项目管理' },
          (props: any) => createElement(ProjectManagementView, { useWorkspaces: props.useWorkspaces, sessionId: props.sessionId }),
        )
      } else if (!enabled && entry) {
        entry(); entry = null
      }
    }
    reconcile()
    const off = scope?.subscribe(reconcile)
    return () => { off?.(); entry?.(); entry = null }
  })

  slots.inject('settings.section', () => slots.register(
    { name: 'settings.section', id: 'chunsun', order: 30, label: '春笋' },
    (props: any) => createElement(SettingsPanel, { close: props?.close }),
  ))

  return async () => {
    disposeStyles()
    await disposeRemote()
  }
}
