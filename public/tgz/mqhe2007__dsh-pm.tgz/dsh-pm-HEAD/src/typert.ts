/**
 * Host Typert contribution — auto-registered by `dsh-typert-loader` via exports["./typert"].
 */
import { INVOCATIONS } from './typert-shared.js'

export const TYPERT = {
  package: 'dsh-pm',
  face: 'host' as const,
  schemas: [] as const,
  invocations: [...INVOCATIONS],
  model: {
    services: [] as const,
    events: [] as const,
    objects: [] as const,
  },
}

export default TYPERT
