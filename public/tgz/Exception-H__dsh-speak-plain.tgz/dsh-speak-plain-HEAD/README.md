# 说人话 · DSH 插件

让 DSH 的最终回答更容易听懂：用一个你选的模型润色最终回答，**默认显示润色版，原回答折叠、可随时点开查看**。主模型照常执行任务；润色只改表达，不改事实、条件与技术细节。

## 效果对比

同一段回答的“报告腔”与“说人话”两种呈现（红色框为对比前，蓝色框为对比后）：

**对比前：报告腔**

![对比前：报告腔](docs/compare-before.png)

**对比后：说人话（默认显示）**

![对比后：说人话](docs/compare-after.png)

## 安装

任选其一（Web profile 把 `desktop` 换成 `web`）：

1. 从 GitHub 安装：

   ```sh
   dsh plugin --profile desktop add -w "github:Exception-H/dsh-speak-plain"
   ```
2. 本地源码安装：

   ```sh
   git clone https://github.com/Exception-H/dsh-speak-plain.git
   dsh plugin --profile desktop add -w ./dsh-speak-plain
   ```
3. 使用发行版 `tgz`（已含编译产物）：

   ```sh
   dsh plugin --profile desktop add -w "完整路径/dsh-speak-plain-0.2.1.tgz"
   ```

安装后重启 DSH，打开「设置 → 说人话」，选择已在 DSH 配置好的渠道和模型，勾选“启用”并保存。之后新完成的普通主会话回答会自动润色；已有历史回答不会补跑。

插件不存储或索要 API Key，润色请求使用 DSH 已配置的模型路由，会额外消耗该模型的额度。发给润色模型的是最近一次用户提问、原回答中可改写的文字和你的表达偏好，不发送思考过程或完整工具日志。代码围栏、行内代码和 Markdown 链接等会先替换为保护标记，润色后校验并还原。

## 显示方式（0.2.1）

启用后，对“本轮最终回答”且润色已就绪的情况：**原回答默认折叠**，**润色版作为默认正文显示**，并显示“查看原回答”可随时展开原文。

实现方式：完全不接管或重写回答渲染。润色结果由 turn-tail 渲染；当它就绪时，通过其自身 DOM 找到同一轮前面最近的 `assistant-step` 回答行（DSH 原生渲染），加一个 CSS 类将其隐藏，并提供“查看原回答/收起原回答”开关切换。取消挂载时会移除隐藏标记。若找不到该行，则不隐藏（原回答照常显示），不会破坏聊天。中间工具步骤、运行中、失败、未润色的回答都不受影响。“查看原回答”显示的是 DSH 原生渲染（含代码、图片、思考等）。

## GenUI 兼容（0.1.1）

润色结果中的真实 `dsh-ui` 围栏由公开 GenUI embed 组件渲染，不再依赖宿主仅面向原回答的 DOM 接管。普通 Markdown 和代码示例保持原有显示；无法解析的组件保留代码并显示说明。

按钮动作绑定该条回答所属会话，本地交互状态与上方原组件分开保存。`panel:true` 围栏不在润色区重新发布或 append，避免同一面板重复执行；请在原会话面板中查看。图表、Mermaid、3D 等延迟资源继续使用已安装 GenUI 插件提供的资源地址。文件导航和导出能力并非对原插件工具栏的完整复制。

从旧版升级后需要重启 DSH。已有润色结果不需要重新调用模型，加载新前端后即可使用新渲染方式。升级不清空已有模型、提示词或结果。

## MVP 的边界

- 全局开关、渠道/模型选择、一段表达偏好；暂无每会话配置。
- 原回答流式显示不受影响，润色期间 DSH 仍显示该轮正在运行。结果出现在回合结束处，而非另一条用户消息。
- 仅处理正常 stop、无工具调用、未中断的最后回答。子代理、失败、输出截断和无正文回答不处理。
- 润色默认最多等待 60 秒。失败或取消保留原回答；不会自动反复重试、不会继续驱动主模型。
- 超过 60,000 个字符的原回答跳过，避免把超长内容发送给编辑模型。
- Chat 显示润色区；执行轨迹和后续主模型上下文仍使用原文。原生「复制回答」复制原文，润色区的「复制润色结果」复制润色版。
- 保护标记校验只能防止代码/链接丢失，不能保证语义绝对不变；重要结论请结合原文查看。
- 已保存的润色结果位于 DSH 当前 profile 的插件 storage-domain 数据中，刷新或重启后可恢复；卸载不会自动清理这些数据。

面向当前具有 `agent/turn-stopping`、`ctx.llm.stream()`、`storageDomain` 和 `conversation.chat.turnTail` 接口的 DSH。升级后如果这些接口发生变化，需要重新验证兼容性。

## 开发

```sh
pnpm install
pnpm run build
pnpm test
pnpm pack --pack-destination artifacts
```

Node.js 22.19+。宿主使用标准 ESM；浏览器产物符合 DSH ModuleLoader closure 格式，共享 DSH 的 React 和 Markdown 渲染器。

源码结构：`src/index.js` 注册领域、认证 RPC 和钩子；`src/service.js` 调用模型、等待和保存结果；`src/engine.js` 筛选回答与保护内容；`src/client.jsx` 提供设置和回合尾部显示。

安装前请参阅 `VALIDATION.md`，其中记录实际执行的检查及验证范围。

---

**致谢** [LINUX DO](https://linux.do/) ｜ **许可** [MIT](LICENSE)
