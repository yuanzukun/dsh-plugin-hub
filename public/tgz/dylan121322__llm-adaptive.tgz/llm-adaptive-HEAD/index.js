// llm-adaptive: adaptive 模型路由插件（2026-08-14 v2 — classifier_router 全功能移植）
//
// 在 /model 模型池选项中提供 "adaptive" 条目：选中后，每个 LLM 请求先由
// deepseek-v4-flash 分类器判任务难度（low/medium/high/critical），再按
// pool.json routing.levels 动态路由链转发到对应后端。已从 classifier_router.py
// 移植全部能力（2026-08-14）：
//   - 上下文感知：注入【会话目标滚动摘要 goal ≤300字】+【最近 ~10 轮对话
//     context ≤1500字】+ 延续/收尾/报错循环三条判定要点（同判定标准）
//   - 会话目标滚动摘要：每 20 轮 flash 重算一句话目标，失败降级空串
//   - sticky 防降档：判定下降时保持上一档（降级指示/收尾信号豁免）
//   - 动态路由链：读 pool.routing.levels（$active 展开、去重、默认链回退），
//     转发失败沿链逐个降级
//   - 分类器配置动态化：url/model/key 读 pool.classifier 节（key_ref →
//     ~/.dsh/.credentials.yaml，池 api_key 兜底）
//   - cause 可观测：每次决策记 plugin.log
//   - 缓存 120s（head[:100] + goal 指纹）；任何失败降级 medium，绝不阻断
//
// 分类与路由数据全部来自 dsh 自持池（~/.dsh/tools/cc-switch-sync/pool.json，
// 与 ~/.claude 零耦合）。
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import { readFileSync, appendFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const HOME = homedir();
const POOL_PATH = join(HOME, '.dsh/tools/cc-switch-sync/pool.json');
const CREDS_PATH = join(HOME, '.dsh/.credentials.yaml');
const LOG_FILE = join(HOME, '.dsh/hooks/plugin.log');

function diag(line) {
  try {
    appendFileSync(LOG_FILE, `${new Date().toISOString()} llm-adaptive ${line}\n`);
  } catch {
    // 诊断日志失败不影响主流程
  }
}

export const name = 'llm-adaptive';
export const inject = ['llm'];

// ── 自持池 / 凭据读取（每次请求重读，池变更即时生效）──
function readPool() {
  try {
    return JSON.parse(readFileSync(POOL_PATH, 'utf8'));
  } catch {
    return null;
  }
}

// .credentials.yaml 简易 kv 解析（dsh 凭据文件，chokidar 热发布）
function readCreds() {
  const out = {};
  try {
    for (const line of readFileSync(CREDS_PATH, 'utf8').split('\n')) {
      const m = /^([A-Za-z0-9_]+):\s*(.+?)\s*$/.exec(line);
      if (!m) continue;
      let v = m[2];
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      out[m[1]] = v;
    }
  } catch {
    // 读不到凭据时靠池内 api_key 兜底
  }
  return out;
}

// ── 分类器配置（pool.classifier 节动态化，硬编码值仅作兜底）──
const DEFAULT_CLASSIFIER_URL = 'https://api.deepseek.com/anthropic/v1/messages';
const DEFAULT_CLASSIFIER_MODEL = 'deepseek-v4-flash';

function classifierConfig(pool) {
  const c = pool?.classifier ?? {};
  const url = c.url || DEFAULT_CLASSIFIER_URL;
  const model = c.model || DEFAULT_CLASSIFIER_MODEL;
  let key = '';
  if (c.key_ref) key = readCreds()[c.key_ref] ?? '';
  if (!key) key = pool?.providers?.['deepseek-flash']?.api_key ?? pool?.providers?.['deepseek']?.api_key ?? '';
  return { url, model, key };
}

// ── 消息提取：最后用户文本 + 最近 ~10 轮上下文 ──
function textOf(block) {
  if (typeof block === 'string') return block;
  if (Array.isArray(block)) {
    return block
      .filter((b) => b?.type === 'text' && typeof b.text === 'string')
      .map((b) => b.text)
      .join(' ')
      .trim();
  }
  return '';
}

function lastUserText(messages) {
  if (!Array.isArray(messages)) return '';
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m?.role !== 'user') continue;
    const t = textOf(m.content);
    if (t) return t.slice(0, 500);
  }
  return '';
}

// 最近 ~10 轮 "role: text" 行，总长 ≤1500（对齐 classifier_router 的 context 注入）
function buildContext(messages) {
  if (!Array.isArray(messages)) return '';
  const lines = [];
  for (const m of messages.slice(-10)) {
    const t = textOf(m.content).replace(/\s+/g, ' ').slice(0, 200);
    if (t) lines.push(`${m.role ?? '?'}: ${t}`);
  }
  return lines.join('\n').slice(0, 1500);
}

// ── flash 分类调用（同 classifier_router._call_classifier）──
async function callClassifier(cfg, prompt) {
  if (!cfg.key) return null;
  const resp = await fetch(cfg.url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': cfg.key,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: cfg.model,
      max_tokens: 80,
      temperature: 0,
      system: '你是严格的 JSON 输出器，只输出合法 JSON。',
      messages: [{ role: 'user', content: prompt }],
    }),
    signal: AbortSignal.timeout(15000),
  });
  if (!resp.ok) return null;
  const data = await resp.json();
  const out = (data.content || [])
    .filter((b) => b?.type === 'text')
    .map((b) => b.text)
    .join('')
    .trim();
  const start = out.indexOf('{');
  const end = out.lastIndexOf('}');
  if (start === -1 || end === -1) return null;
  return JSON.parse(out.slice(start, end + 1));
}

// ── 分类 prompt（同 classifier_router._classify_prompt，判定标准逐字一致）──
const LEVELS = ['low', 'medium', 'high', 'critical'];

function classifyPrompt(stats, context, goal) {
  const last = String(stats.last_user_head ?? '').slice(0, 500);
  const parts = [
    '你是请求复杂度分类器。根据【会话目标 + 最近对话 + 用户当前这句话】判断所需模型能力。',
    '只输出 JSON: {"level": "low|medium|high|critical", "reason": "一句话"}\n',
    '重要：忽略工具数量和上下文长度，它们由客户端固定携带，与任务难度无关。\n',
    '判定标准：',
    '- low: 闲聊、问候、确认、查状态、读单个文件、任务收尾',
    '- medium: 单文件改动、明确的小功能、常规调试、写测试（默认档）',
    '- high: 跨多文件重构、架构调整、疑难 bug 根因分析、性能/安全专项、复杂任务的延续',
    '- critical: 从零设计完整系统、复杂算法实现、大规模迁移\n',
    '上下文判定要点：',
    '- 若当前这句话是【未完成大任务的延续/深化】（目标仍活跃）→ 不低于 medium，目标明确复杂时 high',
    '- 若当前这句话是【收尾/确认/致谢】（目标已完成）→ 可 low',
    '- 若用户在【报错循环】中（同样的问题反复出现）→ 不低于 high',
    '判不准时选 medium。\n',
  ];
  if (goal) parts.push(`会话目标(滚动摘要): ${goal.slice(0, 300)}`);
  if (context) parts.push(`最近对话:\n${context.slice(0, 1500)}`);
  parts.push(`用户当前这句话: ${JSON.stringify(last)}\n`);
  return parts.join('\n');
}

// ── 会话目标滚动摘要（同 classifier_router.summarize_goal，每 20 轮重算）──
const GOAL_RECALC_TURNS = 20;

async function summarizeGoal(messages, cfg) {
  const lines = [];
  for (const m of (messages ?? []).slice(-40)) {
    const t = textOf(m.content).replace(/\s+/g, ' ').slice(0, 200);
    if (t) lines.push(`${m.role ?? '?'}: ${t}`);
  }
  const text = lines.join('\n').slice(0, 2000);
  if (!text) return '';
  const prompt = [
    '你是会话目标提取器。从对话历史中提炼【用户正在推进的主要目标】。',
    '只输出 JSON: {"goal": "一句话(≤60字)"}',
    "规则:若任务已完成(收尾/致谢),goal 填'已完成:<任务名>'。\n",
    `对话历史:\n${text}\n`,
  ].join('\n');
  try {
    const result = await callClassifier(cfg, prompt);
    const goal = (result ?? {}).goal ?? '';
    return String(goal).trim().slice(0, 120);
  } catch {
    return '';
  }
}

// ── sticky 防降档（同 classifier_router）──
const LEVEL_RANK = { low: 0, medium: 1, high: 2, critical: 3 };

function levelIdx(level) {
  return LEVEL_RANK[String(level ?? '').trim().toLowerCase()] ?? 1;
}

function hasDowngradeIndicator(head) {
  const markers = [
    '先别', '不用管', '先不管', '就行', '够了', '到此为止', '收尾', '就这样',
    '结束', '别管', '算了', '简单', 'quick', 'just', 'enough', 'stop',
  ];
  return markers.some((m) => head.includes(m));
}

function isWrapup(context, head) {
  if (!context) return false;
  const headL = head.trim().toLowerCase();
  if (headL.length > 12) return false;
  if (['写', '改', '做', '查', '修', '加', '删', '建', '跑', '试', '看'].some((w) => headL.includes(w))) return false;
  const asstLines = context.split('\n').filter((ln) => ln.startsWith('assistant: '));
  if (!asstLines.length) return false;
  const last = asstLines[asstLines.length - 1].toLowerCase();
  return ['完成', '好了', '通过', '成功', '写完了', '修好了', '部署完成', '搞定', 'done', 'finished', 'passed'].some((w) => last.includes(w));
}

// ── 判档（同 classifier_router.classify_request 级联：L3 flash + sticky）──
let classifyCache = new Map(); // key -> {expiry, level, cause}
const CACHE_TTL = 120_000;

async function classify(text, context, goal, prevLevel, cfg) {
  const head = String(text ?? '').slice(0, 100);
  const cacheKey = goal ? `${head}|g:${goal.slice(0, 24)}` : head;
  const hit = classifyCache.get(cacheKey);
  if (hit && hit.expiry > Date.now()) return { level: hit.level, cause: hit.cause };

  let level = 'medium';
  let cause = 'llm';
  if (text) {
    try {
      const result = await callClassifier(cfg, classifyPrompt({ last_user_head: text }, context, goal));
      const lv = (result ?? {}).level ?? 'medium';
      if (LEVELS.includes(lv)) level = lv;
    } catch {
      level = 'medium'; // 失败降级 medium，绝不阻断
    }
  }

  // sticky：上一轮档位防降档（收尾/降级指示除外）
  if (prevLevel && levelIdx(level) < levelIdx(prevLevel)) {
    const headL = String(text ?? '').trim().toLowerCase();
    if (!hasDowngradeIndicator(headL) && !isWrapup(context, headL)) {
      level = prevLevel;
      cause = 'sticky';
    }
  }

  if (classifyCache.size > 256) classifyCache.clear();
  classifyCache.set(cacheKey, { expiry: Date.now() + CACHE_TTL, level, cause });
  return { level, cause };
}

// ── 动态路由链（同 classifier_router.resolve_level_route：读 pool.routing.levels）──
function resolveLevelRoute(pool, level) {
  const providers = pool?.providers ?? {};
  const active = pool?.active ?? '';
  const levels = pool?.routing?.levels ?? {};
  const defaultChain = {
    low: ['$active', 'deepseek-flash', 'deepseek'],
    medium: ['$active', 'deepseek-flash', 'deepseek'],
    high: ['$active', 'lmuai', 'lmuai-old', 'deepseek'],
    critical: ['$active', 'lmuai', 'lmuai-old', 'deepseek'],
  };
  const names = levels[level] ?? defaultChain[level] ?? defaultChain.medium;
  const expanded = [];
  for (const n of names) {
    if (n === '$active') {
      if (active && !expanded.includes(active)) expanded.push(active);
    } else if (!expanded.includes(n)) {
      expanded.push(n);
    }
  }
  const chain = [];
  for (const n of expanded) {
    const p = providers[n];
    if (p?.model && !chain.some(([pn]) => pn === n)) chain.push([n, p.model]);
  }
  return chain; // [(provider, model), ...]
}

// ── adaptive adapter：classify → 沿动态链转发（失败逐级降级）──
class AdaptiveAdapter extends LlmAdapter {
  constructor(ctx) {
    super();
    this.ctx = ctx;
    this.goalState = new Map(); // sessionKey -> {goal, turns}
    this.stickyState = new Map(); // sessionKey -> level
  }

  providerInfo(provider) {
    return { id: provider, name: 'adaptive' };
  }

  listModels(_provider) {
    return Promise.resolve([
      { provider: 'adaptive', id: 'adaptive', name: 'adaptive（按任务难度自动路由）' },
      { provider: 'adaptive', id: 'low', name: 'low（flash）' },
      { provider: 'adaptive', id: 'medium', name: 'medium（active 主模型）' },
      { provider: 'adaptive', id: 'high', name: 'high（lmuai-opus48）' },
      { provider: 'adaptive', id: 'critical', name: 'critical（lmuai）' },
    ]);
  }

  resolveModel(provider, model, _signal) {
    return Promise.resolve({ provider, id: model, name: model });
  }

  async *stream(options) {
    const pool = readPool();
    if (!pool?.providers) {
      yield { type: 'finish', reason: { kind: 'error', failure: { code: 'NO_POOL', message: 'llm-adaptive: 自持池不存在' } } };
      return;
    }
    const cfg = classifierConfig(pool);
    const messages = options.messages;
    const text = lastUserText(messages);
    const context = buildContext(messages);
    const sessionKey = options.session?.id ?? options.sessionId ?? null;

    // 会话目标滚动摘要（每 GOAL_RECALC_TURNS 轮重算，失败保持旧值）
    let goal = '';
    if (sessionKey) {
      const st = this.goalState.get(sessionKey) ?? { goal: '', turns: 0 };
      st.turns += 1;
      if (!st.goal || st.turns % GOAL_RECALC_TURNS === 0) {
        const fresh = await summarizeGoal(messages, cfg);
        if (fresh) st.goal = fresh;
      }
      this.goalState.set(sessionKey, st);
      goal = st.goal;
    }

    const prevLevel = sessionKey ? this.stickyState.get(sessionKey) : null;
    const { level, cause } = await classify(text, context, goal, prevLevel, cfg);
    if (sessionKey) this.stickyState.set(sessionKey, level);

    const chain = resolveLevelRoute(pool, level);
    diag(`level=${level} cause=${cause} goal=${Boolean(goal)} ctx=${Boolean(context)} prev=${prevLevel ?? '-'} chain=${chain.map(([p]) => p).join('>') || '-'}`);

    if (!chain.length) {
      yield {
        type: 'finish',
        reason: { kind: 'error', failure: { code: 'NO_ROUTE', message: `llm-adaptive: 档位 ${level} 无可用后端 provider` } },
      };
      return;
    }

    // 沿链转发：prepared 校验要求 options 的 provider/model 与 prepared 一致
    for (const [provider, model] of chain) {
      try {
        const prepared = await this.ctx.llm.prepareCall(
          { provider, model, ...(options.reasoningEffort === void 0 ? {} : { reasoningEffort: options.reasoningEffort }) },
          options.signal,
        );
        const forwarded = { ...options, provider, model };
        const inner = prepared.stream(forwarded);
        for await (const chunk of inner) yield chunk;
        return; // 成功
      } catch (error) {
        diag(`转发失败 ${provider}: ${String(error).slice(0, 200)}`);
      }
    }
    yield {
      type: 'finish',
      reason: { kind: 'error', failure: { code: 'TRANSPORT', message: 'llm-adaptive: 路由链全部后端转发失败' } },
    };
  }
}

export function apply(ctx) {
  const adapter = new AdaptiveAdapter(ctx);
  const directory = ctx.llm.registerConfigurableProviders([
    {
      provider: 'adaptive',
      displayName: 'adaptive（自动路由）',
      settingsNs: 'llm-adaptive',
      settingsPath: [],
    },
  ]);
  const registration = ctx.llm.registerAdapter(['adaptive'], adapter);
  diag('adapter registered');
  return () => {
    registration();
    directory();
  };
}
