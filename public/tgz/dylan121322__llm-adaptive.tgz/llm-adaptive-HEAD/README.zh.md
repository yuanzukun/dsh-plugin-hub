# llm-adaptive

[![Awesome DSH Plugin](https://awesome-dsh-plugin.com/badge.svg)](https://awesome-dsh-plugin.com)

[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的 adaptive 模型路由插件。在模型选择器（/model）中提供 `adaptive` 选项：每个 LLM 请求先由 flash 分类器判难度（low / medium / high / critical），再按配置驱动的路由链自动转发到对应后端 provider。

## 功能

- **请求级复杂度分类** —— `deepseek-v4-flash` 直连（不走代理，无递归）。
- **上下文感知判定** —— 分类 prompt 注入会话目标滚动摘要 + 最近对话（延续 / 收尾 / 报错循环三条判定要点）。
- **sticky 防降档** —— 任务中途判定下降时保持上一档，除非消息含明确降级指示或收尾信号。
- **配置驱动路由链** —— 路由链读 `pool.json` 的 `routing.levels`（`$active` 展开为当前活跃 provider，缺失回退默认链）；转发失败沿链逐个降级。
- **分类器配置动态化** —— URL / 模型 / key 引用从 `pool.json` 的 `classifier` 节读取（代码不硬编码密钥）。
- **失败安全** —— 任何分类失败降级 medium，绝不阻断请求。
- **可观测** —— 每次决策（档位、cause: llm/sticky/cache）写入插件日志。
- **120s 决策缓存** —— 按用户文本头部 + 目标指纹键控。

## 依赖

- DeepSeek Harness (dsh)
- 模型池文件 `~/.dsh/tools/cc-switch-sync/pool.json`，需包含：
  - `classifier` 节：`url` / `model` / `key_ref`（按 `~/.dsh/.credentials.yaml` 解析，池内 `api_key` 兜底）
  - `routing.levels`：`low` / `medium` / `high` / `critical` 路由链
- 分类器可用的 DeepSeek API key

池文件由 cc-switch-sync 的 import 工具生成（也可手写）。插件每次请求重读池，池改动即时生效。

## 安装

```bash
dsh plugin add llm-adaptive
```

本地开发（profile 内 file: 引用）：

```bash
cd ~/.dsh/profiles/web && npx pnpm@10 install   # 配合 "llm-adaptive": "file:plugins/llm-adaptive"
```

重启 dsh web 服务后，在 `/model` 选择 `adaptive（自动路由）`。

## 使用

1. 打开 `/model`，选择 `adaptive（自动路由）`。
2. 之后每个 LLM 请求先判档（low/medium/high/critical），再路由到该档位路由链的第一个可用 provider。
3. 决策日志（`level=… cause=… chain=…`）写入 `~/.dsh/hooks/plugin.log`。

选择器中也提供显式档位模型（`low` / `medium` / `high` / `critical`）可直接选用。

## 原理

为 `adaptive` provider 注册自定义 `LlmAdapter`：`stream()` 内 await 分类（async generator），再经 `ctx.llm.prepareCall` + `stream` 转发到目标后端（chunk 协议统一透传）。选择请求级适配器而非代理或请求层拦截，是因为 dsh 热切换配置且 prepared-call 契约要求 options 与 prepared 的 provider/model 一致。

## 许可

MIT
