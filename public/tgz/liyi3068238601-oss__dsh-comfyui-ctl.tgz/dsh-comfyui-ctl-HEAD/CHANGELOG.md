# Changelog

## 0.3.0 - 2026-10-04

- Support named ComfyUI `instances` with optional `defaultInstanceId` and per-call `instance_id` on all existing tools.
- Add `comfyui_instances_list` for discovering configured targets without requiring them to be online.
- Isolate each server's client, node cache, output directory and upload allowlist; named instances do not inherit legacy endpoint or path settings.
- Preserve legacy single-server configuration and tool calls through the `default` instance.
- Include instance identity in rendered and structured results, queue/history entries and output file references while preserving canonical DSH image attachments.
- Document non-blocking submissions (`wait: false`) for simultaneous generation on separate devices and HTTP retrieval of remote outputs.
- Keep nested directory outputs as reusable filename/subfolder references, and render pending history queries without requiring completed outputs.
- Pass caller cancellation to cached node requests and uploads; cancelling a wait does not interrupt server jobs or other instances.
- Add plugin-level dual-server isolation tests with deliberate task/file ID collisions, independent media and queue state, and offline/timeout/cancellation coverage.
- Verify nested configuration and unload/reload cleanup using real Cordis fibers with a test tools registry.

## 0.2.0 - 2026-08-31

- Package the plugin as an installable DeepSeek Harness profile bundle.
- Declare a clean-install dependency closure without unpublished DSH internals.
- Restrict local uploads to configured canonical roots, supported image signatures, safe virtual paths, and byte limits.
- Add response and media download byte limits.
- Register all tools through a disposable Cordis effect with partial-failure rollback.
- Remove retained abort listeners from generation polling.
- Keep inline attachment failures outside the canonical image array.
- Expand automated client, safety, lifecycle, and bundle tests.
- Correct README generation parameters and remove unimplemented template claims.
