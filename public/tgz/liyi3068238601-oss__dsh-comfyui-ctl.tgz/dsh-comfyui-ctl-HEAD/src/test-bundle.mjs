/** Manifest smoke test for installation as a DSH profile bundle. */

import { strict as assert } from 'node:assert'
import { readFile } from 'node:fs/promises'

const manifest = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'))
const patch = await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8')
assert.equal(manifest.dsh?.bundle?.patch, './cordis.patch.yml')
assert.ok(manifest.files.includes('cordis.patch.yml'))
assert.ok(manifest.files.includes('src/safety.js'))
assert.ok(manifest.files.includes('src/instances.js'))
assert.match(patch, /id:\s*comfyui-ctl/)
assert.match(patch, /name:\s*dsh-comfyui-ctl/)
console.log('Bundle manifest and cordis.patch.yml are consistent.')
