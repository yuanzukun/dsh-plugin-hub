/**
 * mock-server.mjs — a tiny canned ComfyUI for testing ComfyClient logic
 * without a real server. Run: node src/test.mjs
 * @module dsh-comfyui-ctl/mock-server
 */

import { createServer } from 'node:http'

/** A 1x1 transparent PNG. */
const PNG_BYTES = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC',
  'base64',
)

const SAMPLE_GRAPH = {
  '3': { class_type: 'KSampler', inputs: { seed: 42, steps: 20, cfg: 7 } },
  '4': { class_type: 'CheckpointLoaderSimple', inputs: { ckpt_name: 'model.safetensors' } },
  '9': { class_type: 'SaveImage', inputs: { filename_prefix: 'mock' } },
}

const OBJECT_INFO = {
  KSampler: {
    input: {
      required: {
        model: { [['MODEL']]: {} },
        seed: { [['INT']]: {} },
      },
    },
    output: [['LATENT']],
  },
  CheckpointLoaderSimple: {
    input: {
      required: { ckpt_name: { [['COMBO']]: ['model.safetensors'] } },
    },
    output: [['MODEL'], ['CLIP'], ['VAE']],
  },
  SaveImage: {
    input: {
      required: {
        images: { [['IMAGE']]: {} },
        filename_prefix: { [['STRING']]: {} },
      },
    },
    output: [['IMAGE']],
  },
}

/**
 * Start a canned ComfyUI server.
 * @param {{ port?: number }} [options]
 * @returns {Promise<{ server: import('node:http').Server, port: number, close: () => Promise<void> }>}
 */
export function startMockServer(options = {}) {
  const port = options.port ?? 0
  /** @type {{[id: string]: object}} */
  const history = {}
  /** @type {Array<object>} */
  const pending = []
  /** @type {Array<object>} */
  const running = []
  /** @type {import('node:http').Server} */
  let server

  function makeEntry(id, status) {
    return {
      prompt: [1, id, SAMPLE_GRAPH, {}, {}],
      outputs: { '9': { images: [{ filename: `ComfyUI_${id}.png`, subfolder: '', type: 'output' }] } },
      status,
    }
  }

  server = createServer((req, res) => {
    const url = new URL(req.url, `http://127.0.0.1:${port}`)
    const path = url.pathname
    const method = req.method ?? 'GET'
    const sendJson = (status, body) => {
      res.writeHead(status, { 'content-type': 'application/json' })
      res.end(JSON.stringify(body))
    }
    const readBody = () => new Promise((resolve) => {
      const chunks = []
      req.on('data', (chunk) => chunks.push(chunk))
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    })

    if (method === 'GET' && path === '/queue') {
      sendJson(200, { queue_running: running.slice(), queue_pending: pending.slice() })
      return
    }
    if (method === 'POST' && path === '/interrupt') {
      running.length = 0
      res.writeHead(200)
      res.end()
      return
    }
    if (method === 'POST' && path === '/queue') {
      void readBody().then((body) => {
        try {
          const parsed = JSON.parse(body)
          if (parsed.clear === true) pending.length = 0
          if (Array.isArray(parsed.delete)) {
            for (let i = pending.length - 1; i >= 0; i--) {
              if (parsed.delete.includes(pending[i][1])) pending.splice(i, 1)
            }
          }
        } catch {
          // ignore malformed
        }
        res.writeHead(200)
        res.end()
      })
      return
    }
    if (method === 'GET' && path.startsWith('/history/')) {
      const id = decodeURIComponent(path.slice('/history/'.length))
      sendJson(200, { [id]: history[id] })
      return
    }
    if (method === 'GET' && path === '/history') {
      const maxItems = Number(url.searchParams.get('max_items') ?? '20')
      const entries = Object.entries(history)
        .sort((a, b) => (b[1]?.status?.messages?.[0]?.[1]?.timestamp ?? 0) - (a[1]?.status?.messages?.[0]?.[1]?.timestamp ?? 0))
        .slice(0, maxItems)
      sendJson(200, Object.fromEntries(entries))
      return
    }
    if (method === 'POST' && path === '/prompt') {
      void readBody().then((body) => {
        try {
          const parsed = JSON.parse(body)
          const prompt = parsed.prompt ?? {}
          const nodeErrors = {}
          for (const [id, node] of Object.entries(prompt)) {
            if (node === null || typeof node !== 'object' || typeof node.class_type !== 'string') {
              nodeErrors[id] = { errors: [{ message: 'missing class_type' }] }
            }
          }
          if (Object.keys(nodeErrors).length > 0) {
            sendJson(400, { error: { message: 'Prompt validation failed' }, node_errors: nodeErrors })
            return
          }
          const id = `mock-${Math.random().toString(16).slice(2)}`
          history[id] = makeEntry(id, { status_str: 'pending', completed: false, messages: [] })
          pending.push([2, id, prompt, {}, {}])
          setTimeout(() => {
            const idx = pending.findIndex((item) => item[1] === id)
            if (idx >= 0) {
              const [item] = pending.splice(idx, 1)
              running.push(item)
            }
            const now = Date.now()
            history[id].status = {
              status_str: 'success',
              completed: true,
              messages: [
                ['execution_start', { prompt_id: id, timestamp: now - 500 }],
                ['execution_success', { prompt_id: id, timestamp: now }],
              ],
            }
          }, 400)
          sendJson(200, { prompt_id: id, number: 1, node_errors: {} })
        } catch {
          sendJson(400, { error: { message: 'malformed request' } })
        }
      })
      return
    }
    if (method === 'GET' && path === '/object_info') {
      sendJson(200, OBJECT_INFO)
      return
    }
    if (method === 'GET' && path.startsWith('/object_info/')) {
      const cls = decodeURIComponent(path.slice('/object_info/'.length))
      sendJson(200, { [cls]: OBJECT_INFO[cls] })
      return
    }
    if (method === 'GET' && path === '/system_stats') {
      sendJson(200, {
        system: {
          os: 'win32',
          ram_total: 34359738368,
          ram_free: 17179869184,
          comfyui_version: '0.3.50',
          python_version: '3.12.8',
          torch_version: '2.7.1',
        },
        devices: [
          { name: 'NVIDIA GeForce RTX 4090', type: 'cuda', index: 0, vram_total: 25769803776, vram_free: 21474836480 },
        ],
      })
      return
    }
    if (method === 'GET' && path === '/api/extensions') {
      sendJson(200, ['nodes-mock-extension', 'ComfyUI-Example'])
      return
    }
    if (method === 'GET' && path.startsWith('/models/')) {
      const folder = decodeURIComponent(path.slice('/models/'.length))
      if (folder === 'checkpoints') {
        sendJson(200, ['dreamshaper.safetensors', 'juggernautXL.safetensors'])
        return
      }
      if (folder === 'loras') {
        // plain-text line format, to exercise the tolerant parser
        res.writeHead(200, { 'content-type': 'text/plain' })
        res.end('add_detail.safetensors\nstyle_sdxl.safetensors\n')
        return
      }
      res.writeHead(404)
      res.end()
      return
    }
    if (method === 'POST' && path === '/upload/image') {
      void readBody().then((body) => {
        const nameMatch = /filename="([^"]+)"/.exec(body)
        const name = nameMatch ? nameMatch[1] : 'uploaded.png'
        const subfolderMatch = /name="subfolder"\r\n\r\n([^\r\n]*)/.exec(body)
        const subfolder = subfolderMatch ? subfolderMatch[1] : ''
        sendJson(200, { name, subfolder, type: 'input' })
      })
      return
    }
    if (method === 'GET' && path === '/view') {
      const filename = url.searchParams.get('filename') ?? 'unknown.png'
      res.writeHead(200, { 'content-type': 'image/png', 'content-length': PNG_BYTES.length })
      res.end(PNG_BYTES)
      void filename
      return
    }
    if (method === 'GET' && path === '/large') {
      const body = Buffer.alloc(1024, 0x61)
      res.writeHead(200, { 'content-type': 'text/plain', 'content-length': body.length })
      res.end(body)
      return
    }
    res.writeHead(404)
    res.end()
  })

  return new Promise((resolve) => {
    server.listen(port, '127.0.0.1', () => {
      const actualPort = /** @type {import('node:net').AddressInfo} */ (server.address()).port
      resolve({
        server,
        port: actualPort,
        close: () => new Promise((done) => server.close(() => done())),
      })
    })
  })
}
