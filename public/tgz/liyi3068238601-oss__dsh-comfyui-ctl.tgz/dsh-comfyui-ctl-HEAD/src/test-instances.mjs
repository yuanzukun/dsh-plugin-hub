/**
 * Black-box multi-instance contract tests for the registered plugin tools.
 * Run from the package root with: node src/test-instances.mjs
 */

import { strict as assert } from 'node:assert'
import { createServer } from 'node:http'
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { apply, Config } from './index.js'

const PROMPT_ID = 'same-prompt-id'
const FILENAME = 'same-output.png'
const PNG_BYTES = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC',
  'base64',
)

function deferred() {
  let resolve
  let reject
  const promise = new Promise((res, rej) => { resolve = res; reject = rej })
  return { promise, resolve, reject }
}

function json(res, value) {
  const body = Buffer.from(JSON.stringify(value))
  res.writeHead(200, { 'content-type': 'application/json', 'content-length': body.length })
  res.end(body)
}

async function requestBody(req) {
  const chunks = []
  for await (const chunk of req) chunks.push(Buffer.from(chunk))
  return Buffer.concat(chunks)
}

function makeHistory(instance, completed = true) {
  return {
    status: {
      status_str: completed ? 'success' : 'running',
      completed,
      messages: completed
        ? [['execution_start', { timestamp: 1 }], ['execution_success', { timestamp: 2 }]]
        : [['execution_start', { timestamp: 1 }]],
    },
    outputs: {
      '9': {
        images: [{ filename: FILENAME, subfolder: '', type: 'output' }],
        text: `${instance}-private-output-marker`,
      },
    },
  }
}

function createFixture(instance, imageBytes) {
  const requests = []
  const queue = {
    pending: true,
    running: true,
    runningClass: `${instance}Node`,
    interrupts: 0,
    deletes: [],
    submissions: [],
    historyCompleted: true,
  }
  const gates = new Map()
  const server = createServer(async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://127.0.0.1')
    const record = { method: req.method, path: url.pathname, query: url.search, body: undefined }
    requests.push(record)
    const key = `${req.method} ${url.pathname}`
    const pending = gates.get(key)
    if (pending?.length) {
      const gate = pending.shift()
      gate.entered.resolve(record)
      await gate.released.promise
      if (res.destroyed) return
    }

    try {
      if (req.method === 'GET' && url.pathname === '/queue') {
        const prompt = { '3': { class_type: queue.runningClass, inputs: {} } }
        return json(res, {
          queue_running: queue.running ? [[1, PROMPT_ID, prompt, {}, {}]] : [],
          queue_pending: queue.pending ? [[2, `pending-${instance}`, prompt, {}, {}]] : [],
        })
      }
      if (req.method === 'POST' && url.pathname === '/interrupt') {
        queue.interrupts += 1
        queue.running = false
        return json(res, { ok: true })
      }
      if (req.method === 'POST' && url.pathname === '/queue') {
        record.body = JSON.parse((await requestBody(req)).toString('utf8'))
        queue.deletes.push(record.body)
        if (record.body.clear === true || record.body.delete?.includes(`pending-${instance}`)) queue.pending = false
        return json(res, { ok: true })
      }
      if (req.method === 'GET' && (url.pathname === '/history' || url.pathname.startsWith('/history/'))) {
        const promptId = url.pathname.startsWith('/history/')
          ? decodeURIComponent(url.pathname.slice('/history/'.length))
          : PROMPT_ID
        if (promptId !== PROMPT_ID) return json(res, {})
        return json(res, { [promptId]: makeHistory(instance, queue.historyCompleted) })
      }
      if (req.method === 'GET' && url.pathname === '/view') {
        res.writeHead(200, { 'content-type': 'image/png', 'content-length': imageBytes.length })
        return res.end(imageBytes)
      }
      if (req.method === 'GET' && url.pathname.startsWith('/models/')) {
        return json(res, [`${instance}-checkpoint.safetensors`])
      }
      if (req.method === 'GET' && url.pathname === '/system_stats') {
        return json(res, {
          system: { comfyui_version: `${instance}-version`, python_version: '3.12', torch_version: '2.8' },
          devices: [{ name: `${instance}-GPU`, type: 'cuda', vram_total: 100, vram_free: 50 }],
        })
      }
      if (req.method === 'GET' && url.pathname === '/object_info') {
        return json(res, {
          [`${instance}Node`]: { input: { required: { marker: [`${instance}-definition`] } } },
          [`Only${instance}`]: { input: { required: {} } },
        })
      }
      if (req.method === 'GET' && url.pathname.startsWith('/object_info/')) {
        const nodeClass = decodeURIComponent(url.pathname.slice('/object_info/'.length))
        return json(res, {
          [nodeClass]: { input: { required: { marker: [`${instance}-direct-definition`] } } },
        })
      }
      if (req.method === 'GET' && url.pathname === '/api/extensions') {
        return json(res, [`extension-${instance}`])
      }
      if (req.method === 'POST' && url.pathname === '/upload/image') {
        record.body = (await requestBody(req)).toString('latin1')
        return json(res, { name: 'uploaded.png', subfolder: '', type: 'input' })
      }
      if (req.method === 'POST' && url.pathname === '/prompt') {
        record.body = JSON.parse((await requestBody(req)).toString('utf8'))
        queue.running = true
        queue.runningClass = Object.values(record.body.prompt ?? {})[0]?.class_type ?? `${instance}Node`
        queue.submissions.push(record.body)
        return json(res, { prompt_id: PROMPT_ID, number: 1 })
      }
      res.writeHead(404, { 'content-type': 'application/json' })
      return res.end(JSON.stringify({ error: `unexpected fixture request ${req.method} ${url.pathname}` }))
    } catch (error) {
      if (!res.destroyed) {
        res.writeHead(500, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ error: error instanceof Error ? error.message : String(error) }))
      }
    }
  })

  const listening = new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', () => {
      server.removeListener('error', reject)
      resolve()
    })
  })

  return {
    instance,
    requests,
    queue,
    server,
    async ready() {
      await listening
      return `http://127.0.0.1:${server.address().port}`
    },
    gateNext(method, pathname) {
      const gate = { entered: deferred(), released: deferred() }
      const gateKey = `${method} ${pathname}`
      const list = gates.get(gateKey) ?? []
      list.push(gate)
      gates.set(gateKey, list)
      return { entered: gate.entered.promise, release: () => gate.released.resolve() }
    },
    setHistoryCompleted(value) { queue.historyCompleted = value },
    setRunning(value) { queue.running = value },
    resetSubmissions() { queue.submissions.length = 0 },
    finishGeneration() {
      queue.historyCompleted = true
      queue.running = false
    },
    close() {
      return new Promise((resolve) => {
        if (!server.listening) return resolve()
        server.close(() => resolve())
        server.closeAllConnections?.()
      })
    },
  }
}

function assertJsonSchema(value, schema, path = '$') {
  const fail = (message) => assert.fail(`${path}: ${message}`)
  if (schema === undefined || schema === true) return
  if (schema.enum !== undefined && !schema.enum.includes(value)) fail(`value ${JSON.stringify(value)} is outside enum ${JSON.stringify(schema.enum)}`)
  if (schema.type === 'object') {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) fail('expected object')
    for (const key of schema.required ?? []) {
      if (!Object.hasOwn(value, key)) fail(`missing required property ${key}`)
    }
    for (const [key, child] of Object.entries(value)) {
      if (schema.properties?.[key] !== undefined) assertJsonSchema(child, schema.properties[key], `${path}.${key}`)
      else if (schema.additionalProperties === false) fail(`unexpected property ${key}`)
      else if (schema.additionalProperties !== undefined && typeof schema.additionalProperties === 'object') {
        assertJsonSchema(child, schema.additionalProperties, `${path}.${key}`)
      }
    }
  } else if (schema.type === 'array') {
    if (!Array.isArray(value)) fail('expected array')
    for (let index = 0; index < value.length; index += 1) assertJsonSchema(value[index], schema.items, `${path}[${index}]`)
  } else if (schema.type === 'string' && typeof value !== 'string') fail('expected string')
  else if (schema.type === 'boolean' && typeof value !== 'boolean') fail('expected boolean')
  else if (schema.type === 'integer' && !Number.isSafeInteger(value)) fail('expected safe integer')
  else if (schema.type === 'number' && (typeof value !== 'number' || !Number.isFinite(value))) fail('expected finite number')
}

function createHarness() {
  const tools = new Map()
  const images = new Map()
  let imageSequence = 0
  const ctx = {
    get(key) {
      if (key !== 'attachments') return undefined
      return {
        imageLimits: { mediaTypes: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'] },
        async saveImage({ data, mediaType, name }) {
          const attachmentId = `test-image-${++imageSequence}`
          const bytes = Buffer.from(data)
          images.set(attachmentId, { bytes, mediaType, name })
          return { attachmentId, mediaType, bytes: bytes.length, width: 1, height: 1, name }
        },
      }
    },
    effect(callback) { this.dispose = callback() },
    tools: {
      register(definition) {
        assert.equal(tools.has(definition.name), false, `duplicate registration ${definition.name}`)
        tools.set(definition.name, definition)
        return () => tools.delete(definition.name)
      },
    },
  }
  return { ctx, tools, images }
}

function textBlocks(tool, args, result) {
  const blocks = tool.output.render(args, result)
  assert.ok(Array.isArray(blocks), `${tool.name} render must return content blocks`)
  const texts = blocks.filter((block) => block?.type === 'text').map((block) => block.text)
  assert.ok(texts.length > 0, `${tool.name} render must contain a text block`)
  return { blocks, texts }
}

async function invoke(tools, name, args = {}, expectedInstance) {
  const tool = tools.get(name)
  assert.ok(tool, `missing registered tool ${name}`)
  const value = await tool.execute(args, { signal: new AbortController().signal })
  assertJsonSchema(value, tool.output.schema, `${name} result`)
  if (expectedInstance !== undefined) {
    assert.equal(value.instance_id, expectedInstance, `${name} result instance_id`)
    const { texts } = textBlocks(tool, args, value)
    assert.ok(texts.some((text) => text.includes(expectedInstance)), `${name} rendered text must identify ${expectedInstance}`)
  }
  return value
}

async function main() {
  const root = await mkdtemp(join(tmpdir(), 'dsh-comfyui-ctl-instances-'))
  const fixtureA = createFixture('alpha', Buffer.from('image-bytes-alpha'))
  const fixtureB = createFixture('beta', Buffer.from('image-bytes-beta'))
  let harnesses = []
  try {
    const [urlA, urlB] = await Promise.all([fixtureA.ready(), fixtureB.ready()])
    const rootA = join(root, 'uploads-alpha')
    const rootB = join(root, 'uploads-beta')
    const legacyRoot = join(root, 'uploads-legacy')
    const outputA = join(root, 'output-alpha')
    const legacyOutput = join(root, 'output-legacy')
    await Promise.all([rootA, rootB, legacyRoot, outputA, legacyOutput, join(outputA, 'renders', 'scene')].map((dir) => mkdir(dir, { recursive: true })))
    await Promise.all([
      writeFile(join(rootA, 'alpha.png'), PNG_BYTES),
      writeFile(join(rootB, 'beta.png'), PNG_BYTES),
      writeFile(join(legacyRoot, 'legacy.png'), PNG_BYTES),
      writeFile(join(outputA, 'only-alpha.png'), Buffer.from('alpha-directory-file')),
      writeFile(join(outputA, 'renders', 'scene', 'nested.png'), Buffer.from('nested-directory-file')),
      writeFile(join(legacyOutput, 'only-legacy.png'), Buffer.from('legacy-directory-file')),
    ])

    const config = Config({
      baseUrl: 'http://127.0.0.1:1',
      outputDir: legacyOutput,
      allowedUploadRoots: [legacyRoot],
      instances: [
        { id: 'alpha', baseUrl: urlA, outputDir: outputA, allowedUploadRoots: [rootA] },
        { id: 'beta', baseUrl: urlB, allowedUploadRoots: [rootB] },
      ],
      defaultInstanceId: 'alpha',
      requestTimeoutMs: 1_000,
      pollIntervalMs: 100,
      generateTimeoutMs: 1_000,
      maxInlineImages: 4,
      maxResponseBytes: 1024 * 1024,
      maxMediaBytes: 1024 * 1024,
      maxUploadBytes: 1024 * 1024,
    })
    const harness = createHarness()
    harnesses.push(harness)
    apply(harness.ctx, config)

    const originalNames = [
      'comfyui_queue_get', 'comfyui_interrupt', 'comfyui_queue_delete', 'comfyui_history_get',
      'comfyui_output_list', 'comfyui_output_get', 'comfyui_models_list', 'comfyui_system_stats',
      'comfyui_nodes_list', 'comfyui_upload_image', 'comfyui_generate',
    ]
    assert.equal(harness.tools.size, 12, '11 original tools plus comfyui_instances_list')
    for (const name of [...originalNames, 'comfyui_instances_list']) assert.ok(harness.tools.has(name), `tool registered: ${name}`)
    for (const name of originalNames) {
      const instance = harness.tools.get(name).parameters.properties.instance_id
      assert.deepEqual(instance?.enum, ['alpha', 'beta'], `${name} has dynamic instance_id enum`)
      assert.equal(instance?.type, 'string')
      assert.ok(!harness.tools.get(name).parameters.required.includes('instance_id'), `${name} keeps instance_id optional`)
    }

    const beforeList = fixtureA.requests.length + fixtureB.requests.length
    const instanceList = await invoke(harness.tools, 'comfyui_instances_list')
    assert.deepEqual(instanceList, {
      default_instance_id: 'alpha',
      instances: [
        { instance_id: 'alpha', base_url: urlA, is_default: true, output_source: 'directory' },
        { instance_id: 'beta', base_url: urlB, is_default: false, output_source: 'history' },
      ],
    })
    assert.equal(fixtureA.requests.length + fixtureB.requests.length, beforeList, 'instances_list performs no HTTP request')

    const cases = [
      ['comfyui_queue_get', {}],
      ['comfyui_interrupt', {}],
      ['comfyui_queue_delete', { prompt_ids: ['not-present'] }],
      ['comfyui_history_get', { prompt_id: PROMPT_ID }],
      ['comfyui_output_list', { source: 'history' }],
      ['comfyui_output_get', { filename: FILENAME }],
      ['comfyui_models_list', { folder: 'checkpoints' }],
      ['comfyui_system_stats', {}],
      ['comfyui_nodes_list', { node_class: 'betaNode' }],
      ['comfyui_upload_image', { path: join(rootB, 'beta.png') }],
      ['comfyui_generate', { prompt: { '3': { class_type: 'BetaWorkflowNode', inputs: {} } }, wait: false }],
    ]
    const results = new Map()
    for (const [name, args] of cases) results.set(name, await invoke(harness.tools, name, { ...args, instance_id: 'beta' }, 'beta'))

    const queueResult = results.get('comfyui_queue_get')
    assert.equal(queueResult.pending[0].instance_id, 'beta')
    assert.equal(queueResult.running[0].instance_id, 'beta')
    const historyResult = results.get('comfyui_history_get')
    assert.equal(historyResult.entries[0].instance_id, 'beta')
    assert.equal(historyResult.entries[0].outputs[0].files[0].instance_id, 'beta')
    const missingHistory = await invoke(harness.tools, 'comfyui_history_get', { prompt_id: 'absent-prompt', instance_id: 'beta' }, 'beta')
    assert.deepEqual(missingHistory.entries, [{ instance_id: 'beta', prompt_id: 'absent-prompt', present: false }])
    const listedHistoryFiles = results.get('comfyui_output_list').files
    assert.equal(listedHistoryFiles[0].instance_id, 'beta')
    assert.equal(results.get('comfyui_models_list').files[0], 'beta-checkpoint.safetensors')
    assert.equal(results.get('comfyui_system_stats').devices[0].name, 'beta-GPU')
    assert.equal(results.get('comfyui_nodes_list').node.input.required.marker[0], 'beta-direct-definition')
    assert.equal(results.get('comfyui_upload_image').filename, 'uploaded.png')
    assert.equal(results.get('comfyui_generate').prompt_id, PROMPT_ID)
    assert.equal((await invoke(harness.tools, 'comfyui_models_list', { folder: 'checkpoints' }, 'alpha')).files[0], 'alpha-checkpoint.safetensors')
    assert.equal((await invoke(harness.tools, 'comfyui_system_stats', {}, 'alpha')).devices[0].name, 'alpha-GPU')

    const outputAResult = await invoke(harness.tools, 'comfyui_output_list', { source: 'auto' }, 'alpha')
    assert.equal(outputAResult.source, 'directory')
    assert.ok(outputAResult.files.some((file) => file.filename === 'only-alpha.png' && file.instance_id === 'alpha'))
    assert.ok(outputAResult.files.some((file) => file.filename === 'nested.png' && file.subfolder === 'renders/scene' && file.instance_id === 'alpha'))
    assert.ok(outputAResult.files.every((file) => file.filename !== 'only-legacy.png'))
    const outputBResult = await invoke(harness.tools, 'comfyui_output_list', { source: 'auto', instance_id: 'beta' }, 'beta')
    assert.equal(outputBResult.source, 'history', 'beta does not inherit the top-level legacy outputDir')
    assert.ok(outputBResult.files.every((file) => file.filename !== 'only-legacy.png'))

    const uploadCountBeforeRejections = fixtureA.requests.filter((r) => r.path === '/upload/image').length
      + fixtureB.requests.filter((r) => r.path === '/upload/image').length
    await assert.rejects(harness.tools.get('comfyui_upload_image').execute({ path: join(rootB, 'beta.png'), instance_id: 'alpha' }, { signal: new AbortController().signal }), /outside the configured|allowed/i)
    await assert.rejects(harness.tools.get('comfyui_upload_image').execute({ path: join(rootA, 'alpha.png'), instance_id: 'beta' }, { signal: new AbortController().signal }), /outside the configured|allowed/i)
    await assert.rejects(harness.tools.get('comfyui_upload_image').execute({ path: join(legacyRoot, 'legacy.png'), instance_id: 'beta' }, { signal: new AbortController().signal }), /outside the configured|allowed/i)
    assert.equal(
      fixtureA.requests.filter((r) => r.path === '/upload/image').length + fixtureB.requests.filter((r) => r.path === '/upload/image').length,
      uploadCountBeforeRejections,
      'cross-instance and legacy upload roots are rejected before HTTP',
    )

    const beforeUnknown = fixtureA.requests.length + fixtureB.requests.length
    for (const [name, args] of cases) {
      await assert.rejects(
        harness.tools.get(name).execute({ ...args, instance_id: 'missing' }, { signal: new AbortController().signal }),
        /instance|one of|enum/i,
        `${name} rejects an unknown instance_id`,
      )
    }
    assert.equal(fixtureA.requests.length + fixtureB.requests.length, beforeUnknown, 'unknown instance ids trigger no HTTP')

    const directorySchema = harness.tools.get('comfyui_output_list').output.schema.properties.files.items
    assert.equal(directorySchema.additionalProperties, false, 'output-list file entries have a closed schema')
    assert.ok(directorySchema.properties.instance_id, 'output-list file schema declares instance_id')
    assert.equal(results.get('comfyui_output_get').image.instance_id, undefined, 'image metadata is canonical and has no routing field')

    const getImageA = await invoke(harness.tools, 'comfyui_output_get', { filename: FILENAME }, 'alpha')
    const getImageB = await invoke(harness.tools, 'comfyui_output_get', { filename: FILENAME, instance_id: 'beta' }, 'beta')
    assert.notEqual(getImageA.image.attachmentId, getImageB.image.attachmentId)
    assert.deepEqual(harness.images.get(getImageA.image.attachmentId).bytes, Buffer.from('image-bytes-alpha'))
    assert.deepEqual(harness.images.get(getImageB.image.attachmentId).bytes, Buffer.from('image-bytes-beta'))
    for (const image of [getImageA.image, getImageB.image]) {
      assert.deepEqual(Object.keys(image).sort(), ['attachmentId', 'bytes', 'height', 'mediaType', 'name', 'width'])
      assert.equal(image.mediaType, 'image/png')
    }

    const generateA = harness.tools.get('comfyui_generate')
    assert.equal(generateA.isConcurrencySafe, undefined, 'generate retains the host default exclusive classification')
    const prompt = { '3': { class_type: 'ControlledWorkflowNode', inputs: { seed: 42 } } }
    const gateA = fixtureA.gateNext('POST', '/prompt')
    const gateB = fixtureB.gateNext('POST', '/prompt')
    const submitA = generateA.execute({ prompt, wait: false }, { signal: new AbortController().signal })
    const submitB = generateA.execute({ prompt, wait: false, instance_id: 'beta' }, { signal: new AbortController().signal })
    await Promise.all([gateA.entered, gateB.entered])
    gateA.release()
    gateB.release()
    const [submittedA, submittedB] = await Promise.all([submitA, submitB])
    for (const [value, id, args] of [[submittedA, 'alpha', { prompt, wait: false }], [submittedB, 'beta', { prompt, wait: false, instance_id: 'beta' }]]) {
      assertJsonSchema(value, generateA.output.schema, 'comfyui_generate result')
      assert.equal(value.instance_id, id)
      assert.equal(value.prompt_id, PROMPT_ID)
      assert.ok(textBlocks(generateA, args, value).texts.some((text) => text.includes(id)))
    }

    const [generatedA, generatedB] = await Promise.all([
      generateA.execute({ prompt, wait: true }, { signal: new AbortController().signal }),
      generateA.execute({ prompt, wait: true, instance_id: 'beta' }, { signal: new AbortController().signal }),
    ])
    for (const [value, id] of [[generatedA, 'alpha'], [generatedB, 'beta']]) {
      assertJsonSchema(value, generateA.output.schema, 'comfyui_generate result')
      assert.equal(value.instance_id, id)
      assert.equal(value.prompt_id, PROMPT_ID, 'fixtures deliberately reuse prompt_id')
      assert.equal(value.status, 'success')
      assert.equal(value.outputs[0].files[0].instance_id, id)
      assert.deepEqual(harness.images.get(value.images[0].attachmentId).bytes, Buffer.from(`image-bytes-${id}`))
    }
    assert.ok(textBlocks(generateA, { prompt, wait: true }, generatedA).texts.some((text) => text.includes('alpha')))
    assert.ok(textBlocks(generateA, { prompt, wait: true, instance_id: 'beta' }, generatedB).texts.some((text) => text.includes('beta')))

    const queueDelete = harness.tools.get('comfyui_queue_delete')
    const betaInterruptsBeforeAlphaInterrupt = fixtureB.queue.interrupts
    await invoke(harness.tools, 'comfyui_queue_delete', { clear: true }, 'alpha')
    assert.equal((await invoke(harness.tools, 'comfyui_queue_get', {}, 'alpha')).pending_count, 0)
    assert.equal((await invoke(harness.tools, 'comfyui_queue_get', { instance_id: 'beta' }, 'beta')).pending_count, 1, 'clearing alpha leaves beta queue intact')
    await invoke(harness.tools, 'comfyui_interrupt', {}, 'alpha')
    assert.equal(fixtureA.queue.interrupts, 1)
    assert.equal(fixtureB.queue.interrupts, betaInterruptsBeforeAlphaInterrupt)
    const alphaAfterInterrupt = await invoke(harness.tools, 'comfyui_queue_get', {}, 'alpha')
    const betaAfterInterrupt = await invoke(harness.tools, 'comfyui_queue_get', { instance_id: 'beta' }, 'beta')
    assert.equal(alphaAfterInterrupt.running_count, 0, 'interrupt clears alpha running task')
    assert.equal(alphaAfterInterrupt.pending_count, 0, 'alpha running-task interrupt leaves its already-cleared queue empty')
    assert.equal(betaAfterInterrupt.running_count, 1, 'interrupting alpha leaves beta running task intact')
    assert.equal(betaAfterInterrupt.pending_count, 1, 'interrupting alpha leaves beta pending task intact')
    assert.equal(queueDelete.output.schema.properties.instance_id.type, 'string')

    const nodes = harness.tools.get('comfyui_nodes_list')
    const gateCacheA = fixtureA.gateNext('GET', '/object_info')
    const cacheAbort = new AbortController()
    const abortedCacheRead = nodes.execute({ search: 'Node' }, { signal: cacheAbort.signal })
    await gateCacheA.entered
    const betaNodes = await invoke(harness.tools, 'comfyui_nodes_list', { search: 'Only', instance_id: 'beta' }, 'beta')
    assert.deepEqual(betaNodes.matches, ['Onlybeta'], 'beta object_info is independent while alpha cache request is pending')
    cacheAbort.abort(new Error('cancel alpha cache request'))
    gateCacheA.release()
    await assert.rejects(abortedCacheRead, /cancel alpha cache request|abort/i)
    const alphaNodes = await invoke(harness.tools, 'comfyui_nodes_list', { search: 'Only' }, 'alpha')
    assert.deepEqual(alphaNodes.matches, ['Onlyalpha'], 'a cancelled object_info load does not poison alpha cache')
    assert.equal(fixtureA.requests.filter((r) => r.path === '/object_info').length, 2)
    assert.equal(fixtureB.requests.filter((r) => r.path === '/object_info').length, 1)

    const gateHistoryA = fixtureA.gateNext('GET', `/history/${PROMPT_ID}`)
    const waitAbort = new AbortController()
    const cancelledGenerate = generateA.execute({ prompt, wait: true }, { signal: waitAbort.signal })
    await gateHistoryA.entered
    waitAbort.abort(new Error('cancel waiting only'))
    gateHistoryA.release()
    await assert.rejects(cancelledGenerate, /cancel waiting only|abort/i)
    assert.equal(fixtureA.queue.interrupts, 1, 'cancellation while waiting never calls /interrupt')
    const betaAfterCancel = await invoke(harness.tools, 'comfyui_system_stats', { instance_id: 'beta' }, 'beta')
    assert.equal(betaAfterCancel.system.comfyui_version, 'beta-version')

    const gateUploadA = fixtureA.gateNext('POST', '/upload/image')
    const uploadAbort = new AbortController()
    const cancelledUpload = harness.tools.get('comfyui_upload_image').execute(
      { path: join(rootA, 'alpha.png') },
      { signal: uploadAbort.signal },
    )
    await gateUploadA.entered
    uploadAbort.abort(new Error('cancel alpha upload'))
    gateUploadA.release()
    await assert.rejects(cancelledUpload, /cancel alpha upload|abort/i)
    assert.equal(fixtureA.queue.interrupts, 1, 'cancelling upload does not interrupt a generation')
    assert.equal((await invoke(harness.tools, 'comfyui_system_stats', { instance_id: 'beta' }, 'beta')).system.comfyui_version, 'beta-version')

    fixtureA.setHistoryCompleted(false)
    const generationTimeout = await generateA.execute(
      { prompt, wait: true, timeout_ms: 100 },
      { signal: new AbortController().signal },
    )
    assertJsonSchema(generationTimeout, generateA.output.schema, 'timed-out comfyui_generate result')
    assert.equal(generationTimeout.instance_id, 'alpha')
    assert.equal(generationTimeout.status, 'timeout')
    assert.ok(textBlocks(generateA, { prompt, wait: true, timeout_ms: 100 }, generationTimeout).texts.some((text) => text.includes('alpha')))
    assert.equal(fixtureA.queue.interrupts, 1, 'generation wait timeout does not call /interrupt')
    fixtureA.setHistoryCompleted(true)
    assert.equal((await invoke(harness.tools, 'comfyui_system_stats', { instance_id: 'beta' }, 'beta')).system.comfyui_version, 'beta-version')

    fixtureA.setRunning(false)
    fixtureB.setRunning(false)
    fixtureA.setHistoryCompleted(false)
    fixtureB.setHistoryCompleted(false)
    fixtureA.resetSubmissions()
    fixtureB.resetSubmissions()
    const sequentialA = await generateA.execute({ prompt, wait: false }, { signal: new AbortController().signal })
    const sequentialB = await generateA.execute({ prompt, wait: false, instance_id: 'beta' }, { signal: new AbortController().signal })
    assert.equal(sequentialA.instance_id, 'alpha')
    assert.equal(sequentialB.instance_id, 'beta')
    assert.equal(sequentialA.prompt_id, PROMPT_ID)
    assert.equal(sequentialB.prompt_id, PROMPT_ID)
    assert.equal(fixtureA.queue.submissions.length, 1, 'sequential alpha wait:false submission reached alpha')
    assert.equal(fixtureB.queue.submissions.length, 1, 'sequential beta wait:false submission reached beta')
    const [runningA, runningB] = await Promise.all([
      invoke(harness.tools, 'comfyui_queue_get', {}, 'alpha'),
      invoke(harness.tools, 'comfyui_queue_get', { instance_id: 'beta' }, 'beta'),
    ])
    assert.equal(runningA.running_count, 1)
    assert.equal(runningB.running_count, 1)
    assert.equal(runningA.running[0].prompt_id, PROMPT_ID)
    assert.equal(runningB.running[0].prompt_id, PROMPT_ID)
    const [unfinishedA, unfinishedB] = await Promise.all([
      invoke(harness.tools, 'comfyui_history_get', { prompt_id: PROMPT_ID }, 'alpha'),
      invoke(harness.tools, 'comfyui_history_get', { prompt_id: PROMPT_ID, instance_id: 'beta' }, 'beta'),
    ])
    assert.equal(unfinishedA.entries[0].completed, false, 'alpha history stays unfinished until both submissions have landed')
    assert.equal(unfinishedB.entries[0].completed, false, 'beta history stays unfinished until both submissions have landed')
    fixtureA.finishGeneration()
    fixtureB.finishGeneration()
    const [finishedA, finishedB] = await Promise.all([
      invoke(harness.tools, 'comfyui_history_get', { prompt_id: PROMPT_ID }, 'alpha'),
      invoke(harness.tools, 'comfyui_history_get', { prompt_id: PROMPT_ID, instance_id: 'beta' }, 'beta'),
    ])
    assert.equal(finishedA.entries[0].completed, true)
    assert.equal(finishedB.entries[0].completed, true)
    assert.equal(runningA.instance_id, 'alpha')
    assert.equal(runningB.instance_id, 'beta')

    const gateTimeoutA = fixtureA.gateNext('GET', '/object_info')
    const timeoutHarness = createHarness()
    harnesses.push(timeoutHarness)
    apply(timeoutHarness.ctx, Config({
      instances: [
        { id: 'alpha', baseUrl: urlA },
        { id: 'beta', baseUrl: urlB },
      ],
      defaultInstanceId: 'alpha',
      requestTimeoutMs: 100,
      pollIntervalMs: 100,
      generateTimeoutMs: 1_000,
      maxInlineImages: 4,
      maxResponseBytes: 1024 * 1024,
      maxMediaBytes: 1024 * 1024,
      maxUploadBytes: 1024 * 1024,
    }))
    const timeoutNodes = timeoutHarness.tools.get('comfyui_nodes_list')
    const timedOut = timeoutNodes.execute({ search: 'Node' }, { signal: new AbortController().signal })
    await gateTimeoutA.entered
    await assert.rejects(timedOut, /timed out/i, 'alpha HTTP request observes the shared configured timeout')
    gateTimeoutA.release()
    const betaAfterTimeout = await invoke(timeoutHarness.tools, 'comfyui_system_stats', { instance_id: 'beta' }, 'beta')
    assert.equal(betaAfterTimeout.system.comfyui_version, 'beta-version')

    const legacyConfig = Config({
      baseUrl: urlB,
      outputDir: outputA,
      allowedUploadRoots: [rootA],
      requestTimeoutMs: 1_000,
      pollIntervalMs: 100,
      generateTimeoutMs: 1_000,
      maxInlineImages: 4,
      maxResponseBytes: 1024 * 1024,
      maxMediaBytes: 1024 * 1024,
      maxUploadBytes: 1024 * 1024,
    })
    const legacyHarness = createHarness()
    harnesses.push(legacyHarness)
    apply(legacyHarness.ctx, legacyConfig)
    const legacyList = await invoke(legacyHarness.tools, 'comfyui_instances_list')
    assert.deepEqual(legacyList, {
      default_instance_id: 'default',
      instances: [{ instance_id: 'default', base_url: urlB, is_default: true, output_source: 'directory' }],
    })
    assert.equal((await invoke(legacyHarness.tools, 'comfyui_queue_get')).instance_id, 'default')
    const legacyUpload = await invoke(legacyHarness.tools, 'comfyui_upload_image', { path: join(rootA, 'alpha.png') }, 'default')
    assert.equal(legacyUpload.instance_id, 'default')
    assert.equal((await invoke(legacyHarness.tools, 'comfyui_output_list', { source: 'auto' })).source, 'directory')

    const requestsBeforeOffline = fixtureA.requests.length
    await fixtureA.close()
    await assert.rejects(
      harness.tools.get('comfyui_queue_get').execute({}, { signal: new AbortController().signal }),
      /cannot reach|connect|fetch/i,
      'alpha becomes unavailable after its fixture server stops',
    )
    assert.equal(fixtureA.requests.length, requestsBeforeOffline, 'offline alpha receives no HTTP request')
    assert.equal((await invoke(harness.tools, 'comfyui_system_stats', { instance_id: 'beta' }, 'beta')).system.comfyui_version, 'beta-version')

    for (const fixture of [fixtureA, fixtureB]) {
      const unexpected = fixture.requests.filter((request) => ![
        '/queue', '/interrupt', '/history', `/history/${PROMPT_ID}`, '/history/absent-prompt', '/view', '/models/checkpoints', '/system_stats',
        '/object_info', '/object_info/alphaNode', '/object_info/betaNode', '/api/extensions', '/upload/image', '/prompt',
      ].includes(request.path))
      assert.deepEqual(unexpected, [], `${fixture.instance} fixture only received expected tool routes`)
    }

    harnesses.forEach((item) => item.ctx.dispose?.())
    harnesses = []
    console.log('Multi-instance black-box contract passed: 11 tool routes, schemas, routing, isolation, caching, inline images, abort, timeout, and legacy config.')
  } finally {
    for (const fixture of [fixtureA, fixtureB]) await fixture.close()
    for (const harness of harnesses) harness.ctx.dispose?.()
    await rm(root, { recursive: true, force: true })
  }
}

main().catch((error) => {
  console.error(error)
  process.exitCode = 1
})
