/**
 * ComfyClient — a standalone, dependency-free HTTP client for the ComfyUI
 * REST API. This module knows nothing about DSH: it can be reused verbatim
 * from a plain Node script, an MCP server wrapper, or any other host.
 *
 * Endpoints implemented (ComfyUI server, stable surface):
 * - GET  /queue                     running + pending execution items
 * - POST /interrupt                 interrupt the running job
 * - POST /queue                     {"clear":true} or {"delete":[ids]}
 * - GET  /history?max_items=N       recent generations
 * - GET  /history/{prompt_id}       one generation (incl. status/outputs)
 * - POST /prompt                    submit an API-format prompt graph
 * - GET  /object_info[/{class}]     node definitions
 * - GET  /system_stats              versions, RAM, per-device VRAM
 * - GET  /api/extensions            enabled custom-node extensions
 * - GET  /models/{folder}           model files of one folder
 * - POST /upload/image              multipart upload into the input dir
 * - GET  /view?filename&subfolder&type   fetch stored file bytes
 * @module dsh-comfyui-ctl/client
 */

/** Default ComfyUI server address (local desktop install). */
export const DEFAULT_BASE_URL = 'http://127.0.0.1:8188'
/** Default per-request timeout in milliseconds. */
export const DEFAULT_REQUEST_TIMEOUT_MS = 30_000
/** Default poll interval while waiting for a generation to finish. */
export const DEFAULT_POLL_INTERVAL_MS = 1_500
/** Default ceiling for wait-for-completion in milliseconds. */
export const DEFAULT_WAIT_TIMEOUT_MS = 300_000
/** Default cap for JSON and text response bodies. */
export const DEFAULT_MAX_RESPONSE_BYTES = 32 * 1024 * 1024
/** Default cap for one downloaded media file. */
export const DEFAULT_MAX_MEDIA_BYTES = 64 * 1024 * 1024
const MAX_ERROR_BODY_BYTES = 64 * 1024

/**
 * Combined abort signal: caller signal + hard timeout.
 * @param {number} ms - timeout in milliseconds
 * @param {AbortSignal|undefined} external - caller-owned signal
 */
function deadline(ms, external) {
  if (!Number.isFinite(ms) || ms <= 0) throw new Error('request timeout must be a positive finite number')
  const timer = AbortSignal.timeout(ms)
  return external === undefined ? timer : AbortSignal.any([timer, external])
}

async function readResponseBuffer(response, maxBytes) {
  if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0) throw new Error('response byte limit must be a positive integer')
  const declared = response.headers.get('content-length')
  if (declared !== null && Number.isFinite(Number(declared)) && Number(declared) > maxBytes) {
    throw new Error(`ComfyUI response exceeds the ${maxBytes}-byte limit`)
  }
  if (response.body === null) return Buffer.alloc(0)
  const reader = response.body.getReader()
  const chunks = []
  let total = 0
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      total += value.byteLength
      if (total > maxBytes) {
        await reader.cancel('response too large').catch(() => {})
        throw new Error(`ComfyUI response exceeds the ${maxBytes}-byte limit`)
      }
      chunks.push(Buffer.from(value))
    }
  } finally {
    reader.releaseLock()
  }
  return Buffer.concat(chunks, total)
}

async function readResponseText(response, maxBytes) {
  return (await readResponseBuffer(response, maxBytes)).toString('utf8')
}

async function readErrorBody(response) {
  try {
    return await readResponseText(response, MAX_ERROR_BODY_BYTES)
  } catch {
    return '[error response exceeded the readable limit]'
  }
}

/** Wait without retaining an abort listener after the timer settles. */
export function abortableSleep(ms, signal) {
  if (!Number.isFinite(ms) || ms < 0) return Promise.reject(new Error('sleep duration must be a non-negative finite number'))
  if (signal?.aborted === true) {
    return Promise.reject(signal.reason instanceof Error ? signal.reason : new Error('aborted'))
  }
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      clearTimeout(timer)
      signal?.removeEventListener('abort', onAbort)
      reject(signal?.reason instanceof Error ? signal.reason : new Error('aborted'))
    }
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort)
      resolve()
    }, ms)
    signal?.addEventListener('abort', onAbort, { once: true })
  })
}

/**
 * Extract a readable message from an error response body.
 * @param {string} body - raw response text
 * @returns {string|undefined} parsed detail, when present
 */
function errorDetail(body) {
  if (body === '') return undefined
  try {
    const parsed = JSON.parse(body)
    if (parsed && typeof parsed === 'object') {
      if (typeof parsed.error === 'object' && parsed.error !== null && typeof parsed.error.message === 'string') {
        return parsed.error.message
      }
      if (typeof parsed.error === 'string') return parsed.error
      if (typeof parsed.message === 'string') return parsed.message
    }
  } catch {
    // not JSON — fall through
  }
  const snippet = body.length > 300 ? `${body.slice(0, 300)}…` : body
  return snippet
}

/**
 * HTTP error carrying status and parsed ComfyUI error payload.
 */
export class ComfyHttpError extends Error {
  /**
   * @param {number} status - HTTP status code
   * @param {string} path - request path
   * @param {string|undefined} detail - server-provided detail
   * @param {unknown} [nodeErrors] - per-node validation errors from /prompt
   */
  constructor(status, path, detail, nodeErrors) {
    super(`ComfyUI ${path} failed with HTTP ${status}${detail === undefined ? '' : `: ${detail}`}`)
    this.name = 'ComfyHttpError'
    this.status = status
    this.path = path
    this.detail = detail
    this.nodeErrors = nodeErrors
  }
}

/**
 * Format ComfyUI /prompt node validation errors into a compact string.
 * @param {Record<string, {errors?: unknown[], class_type?: string}>|undefined} nodeErrors
 * @returns {string|undefined}
 */
export function formatNodeErrors(nodeErrors) {
  if (nodeErrors === undefined || nodeErrors === null || typeof nodeErrors !== 'object') return undefined
  const parts = []
  for (const [nodeId, info] of Object.entries(nodeErrors)) {
    const classType = typeof info?.class_type === 'string' ? info.class_type : 'unknown node'
    const messages = Array.isArray(info?.errors)
      ? info.errors.map((e) => {
        const detail = e && typeof e === 'object' && 'message' in e && typeof e.message === 'string' ? e.message : JSON.stringify(e)
        const extra = e && typeof e === 'object' && 'details' in e && e.details !== undefined && typeof e.details === 'string' ? ` (${e.details})` : ''
        return `${detail}${extra}`
      }).join('; ')
      : 'invalid'
    parts.push(`node ${nodeId} (${classType}): ${messages}`)
  }
  return parts.length === 0 ? undefined : parts.join(' | ')
}

/**
 * A thin async client over the ComfyUI HTTP API.
 */
export class ComfyClient {
  /**
   * @param {{ baseUrl?: string, requestTimeoutMs?: number, maxResponseBytes?: number, maxMediaBytes?: number }} [options]
   */
  constructor(options = {}) {
    this.baseUrl = (options.baseUrl ?? DEFAULT_BASE_URL).replace(/\/+$/, '')
    this.requestTimeoutMs = options.requestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS
    this.maxResponseBytes = options.maxResponseBytes ?? DEFAULT_MAX_RESPONSE_BYTES
    this.maxMediaBytes = options.maxMediaBytes ?? DEFAULT_MAX_MEDIA_BYTES
  }

  /**
   * Perform one request against the server.
   * @param {string} pathname - path beginning with "/"
   * @param {{ method?: string, json?: unknown, form?: FormData, signal?: AbortSignal,
   *           timeoutMs?: number, raw?: boolean, maxBytes?: number }} [init]
   * @returns {Promise<import('node:buffer').Buffer|unknown>} parsed JSON, text, or raw Buffer
   */
  async request(pathname, init = {}) {
    const { method = 'GET', json, form, signal, timeoutMs, raw = false } = init
    /** @type {RequestInit} */
    const fetchInit = { method, signal: deadline(timeoutMs ?? this.requestTimeoutMs, signal) }
    if (json !== undefined) {
      fetchInit.headers = { 'content-type': 'application/json' }
      fetchInit.body = JSON.stringify(json)
    } else if (form !== undefined) {
      fetchInit.body = form
    }
    let res
    try {
      res = await fetch(`${this.baseUrl}${pathname}`, fetchInit)
    } catch (cause) {
      if (signal?.aborted === true) throw cause
      if (cause instanceof Error && cause.name === 'TimeoutError') {
        throw new Error(`ComfyUI ${pathname} timed out after ${timeoutMs ?? this.requestTimeoutMs} ms`, { cause })
      }
      throw new Error(`cannot reach ComfyUI at ${this.baseUrl} (${cause instanceof Error ? cause.message : String(cause)})`, { cause })
    }
    if (raw) {
      if (!res.ok) {
        const body = await readErrorBody(res)
        throw new ComfyHttpError(res.status, pathname, errorDetail(body))
      }
      return readResponseBuffer(res, init.maxBytes ?? this.maxMediaBytes)
    }
    const body = res.ok
      ? await readResponseText(res, init.maxBytes ?? this.maxResponseBytes)
      : await readErrorBody(res)
    if (!res.ok) {
      let nodeErrors
      try {
        const parsed = JSON.parse(body)
        if (parsed && typeof parsed === 'object' && parsed.node_errors !== undefined) nodeErrors = parsed.node_errors
      } catch {
        // body was not JSON — no node errors to surface
      }
      throw new ComfyHttpError(res.status, pathname, errorDetail(body), nodeErrors)
    }
    if (body === '') return undefined
    try {
      return JSON.parse(body)
    } catch {
      return body
    }
  }

  /** GET /queue — running and pending items. */
  queue(opts = {}) {
    return this.request('/queue', opts)
  }

  /** POST /interrupt — abort the currently running generation. */
  interrupt(opts = {}) {
    return this.request('/interrupt', { method: 'POST', ...opts })
  }

  /**
   * POST /queue — clear all pending items, or delete specific pending ids.
   * @param {{ clear?: boolean, promptIds?: string[] }} [options]
   */
  async queueDelete(options = {}, opts = {}) {
    const body = options.clear === true
      ? { clear: true }
      : { delete: options.promptIds ?? [] }
    return this.request('/queue', { method: 'POST', json: body, ...opts })
  }

  /**
   * GET /history or /history/{id}.
   * @param {{ promptId?: string, maxItems?: number }} [options]
   */
  history(options = {}, opts = {}) {
    if (options.promptId !== undefined && options.promptId !== '') {
      return this.request(`/history/${encodeURIComponent(options.promptId)}`, opts)
    }
    const query = options.maxItems === undefined ? '' : `?max_items=${options.maxItems}`
    return this.request(`/history${query}`, opts)
  }

  /**
   * GET /object_info or /object_info/{class}.
   * @param {string} [nodeClass] - one node class name for its full definition
   */
  objectInfo(nodeClass, opts = {}) {
    return nodeClass === undefined || nodeClass === ''
      ? this.request('/object_info', opts)
      : this.request(`/object_info/${encodeURIComponent(nodeClass)}`, opts)
  }

  /** GET /system_stats — versions plus per-device memory. */
  systemStats(opts = {}) {
    return this.request('/system_stats', opts)
  }

  /** GET /api/extensions — enabled custom-node extension module names. */
  extensions(opts = {}) {
    return this.request('/api/extensions', opts)
  }

  /**
   * GET /models/{folder} — file names in one model folder.
   * Tolerates both JSON-array and plain-text line responses.
   * @param {string} folder - e.g. "checkpoints", "loras", "vae"
   */
  async modelsList(folder, opts = {}) {
    const text = await this.request(`/models/${encodeURIComponent(folder)}`, { ...opts, raw: false })
    if (Array.isArray(text)) return text.map(String)
    if (typeof text === 'string' && text.length > 0) {
      return text.split(/\r?\n/).map((line) => line.trim()).filter((line) => line !== '')
    }
    return []
  }

  /**
   * POST /upload/image — upload bytes into the input directory.
   * @param {{ data: Uint8Array, filename: string, subfolder?: string, overwrite?: boolean, type?: string }} upload
   */
  async uploadImage(upload, opts = {}) {
    const form = new FormData()
    form.append('image', new Blob([upload.data]), upload.filename)
    if (upload.subfolder !== undefined && upload.subfolder !== '') form.append('subfolder', upload.subfolder)
    form.append('type', upload.type ?? 'input')
    form.append('overwrite', upload.overwrite === true ? 'true' : 'false')
    const res = await this.request('/upload/image', { method: 'POST', form, ...opts })
    return res
  }

  /**
   * GET /view — fetch stored bytes (input/output/temp).
   * @param {{ filename: string, subfolder?: string, type?: string }} ref
   * @returns {Promise<{ bytes: import('node:buffer').Buffer, contentType: string }>}
   */
  async view(ref, opts = {}) {
    const query = new URLSearchParams({
      filename: ref.filename,
      subfolder: ref.subfolder ?? '',
      type: ref.type ?? 'output',
    })
    const res = await fetch(`${this.baseUrl}/view?${query.toString()}`, {
      signal: deadline(opts.timeoutMs ?? this.requestTimeoutMs, opts.signal),
    })
    if (!res.ok) {
      const body = await readErrorBody(res)
      throw new ComfyHttpError(res.status, '/view', errorDetail(body))
    }
    return {
      bytes: await readResponseBuffer(res, opts.maxBytes ?? this.maxMediaBytes),
      contentType: res.headers.get('content-type') ?? 'application/octet-stream',
    }
  }

  /**
   * POST /prompt — submit an API-format prompt graph.
   * @param {Record<string, {class_type: string, inputs: Record<string, unknown>}>} prompt
   * @param {string} [clientId] - caller identity used by the websocket feed
   * @returns {Promise<{ promptId: string, number?: number }>}
   */
  async submitPrompt(prompt, clientId, opts = {}) {
    const body = clientId === undefined ? { prompt } : { prompt, client_id: clientId }
    let res
    try {
      res = await this.request('/prompt', { method: 'POST', json: body, ...opts })
    } catch (cause) {
      if (cause instanceof ComfyHttpError && cause.nodeErrors !== undefined) {
        const formatted = formatNodeErrors(cause.nodeErrors)
        if (formatted !== undefined) throw new Error(`ComfyUI rejected the prompt — ${formatted}`, { cause })
      }
      throw cause
    }
    if (res === undefined || res === null || typeof res !== 'object' || typeof res.prompt_id !== 'string') {
      throw new Error(`ComfyUI /prompt returned no prompt_id: ${JSON.stringify(res)}`)
    }
    return { promptId: res.prompt_id, number: res.number }
  }

  /**
   * Poll /history/{id} until the generation completes.
   * @param {string} promptId
   * @param {{ pollMs?: number, timeoutMs?: number, signal?: AbortSignal }} [options]
   * @returns {Promise<{ promptId: string, completed: boolean, statusStr?: string, entry?: object }>}
   */
  async waitForCompletion(promptId, options = {}) {
    const pollMs = options.pollMs ?? DEFAULT_POLL_INTERVAL_MS
    const timeoutMs = options.timeoutMs ?? DEFAULT_WAIT_TIMEOUT_MS
    if (!Number.isFinite(pollMs) || pollMs <= 0) throw new Error('pollMs must be a positive finite number')
    if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new Error('timeoutMs must be a positive finite number')
    const deadlineAt = Date.now() + timeoutMs
    for (;;) {
      const entry = await this.historyEntry(promptId, options)
      if (entry !== undefined && entry.status?.completed === true) {
        return {
          promptId,
          completed: true,
          statusStr: typeof entry.status.status_str === 'string' ? entry.status.status_str : undefined,
          entry,
        }
      }
      if (Date.now() >= deadlineAt) {
        return { promptId, completed: false, statusStr: undefined, entry }
      }
      await abortableSleep(Math.min(pollMs, Math.max(0, deadlineAt - Date.now())), options.signal)
    }
  }

  /**
   * One history entry by prompt id (undefined when absent).
   * @param {string} promptId
   * @private use via waitForCompletion or tools
   */
  async historyEntry(promptId, opts = {}) {
    const res = await this.history({ promptId }, opts)
    if (res === undefined || res === null || typeof res !== 'object') return undefined
    return res[promptId]
  }
}
