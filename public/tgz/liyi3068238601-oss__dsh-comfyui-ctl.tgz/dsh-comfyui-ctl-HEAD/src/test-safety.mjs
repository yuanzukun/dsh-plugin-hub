/** Filesystem admission tests for path-based uploads. */

import { strict as assert } from 'node:assert'
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { normalizeComfySubfolder, normalizeUploadName, readAllowedImage } from './safety.js'

const PNG_BYTES = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC',
  'base64',
)

const root = await mkdtemp(join(tmpdir(), 'dsh-comfyui-ctl-safety-'))
const allowed = join(root, 'allowed')
const outside = join(root, 'outside')
await mkdir(allowed)
await mkdir(outside)
const image = join(allowed, 'image.png')
const mismatch = join(allowed, 'image.jpg')
const forbidden = join(outside, 'secret.png')
await writeFile(image, PNG_BYTES)
await writeFile(mismatch, PNG_BYTES)
await writeFile(forbidden, PNG_BYTES)

try {
  const admitted = await readAllowedImage(image, [allowed], 1024)
  assert.equal(admitted.originalName, 'image.png')
  assert.equal(admitted.mediaType, 'image/png')
  assert.deepEqual(admitted.data, PNG_BYTES)

  await assert.rejects(readAllowedImage(image, [], 1024), /uploads are disabled/)
  await assert.rejects(readAllowedImage(forbidden, [allowed], 1024), /outside the configured/)
  await assert.rejects(readAllowedImage(image, [allowed], 8), /exceeds maxUploadBytes/)
  await assert.rejects(readAllowedImage(mismatch, [allowed], 1024), /extension does not match/)
  assert.equal(normalizeComfySubfolder('references\\faces'), 'references/faces')
  assert.throws(() => normalizeComfySubfolder('../escape'), /must not contain/)
  assert.equal(normalizeUploadName('renamed.png', 'image.png'), 'renamed.png')
  assert.throws(() => normalizeUploadName('renamed.jpg', 'image.png', 'image/png'), /must match/)
  assert.throws(() => normalizeUploadName('../escape.png', 'image.png'), /plain file name/)
  console.log('Safety checks passed: root containment, byte cap, image signature, and virtual paths.')
} finally {
  await rm(root, { recursive: true, force: true })
}
