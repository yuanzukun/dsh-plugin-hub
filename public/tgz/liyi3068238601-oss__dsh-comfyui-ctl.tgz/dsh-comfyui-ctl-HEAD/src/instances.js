/** Instance configuration and fixed ComfyUI client routing. */
import { isAbsolute } from 'node:path'
import { ComfyClient } from './client.js'

function validateInstance(config) {
  let endpoint
  try {
    endpoint = new URL(config.baseUrl)
  } catch {
    throw new Error('baseUrl must be an absolute HTTP or HTTPS URL')
  }
  if (endpoint.protocol !== 'http:' && endpoint.protocol !== 'https:') {
    throw new Error('baseUrl must use HTTP or HTTPS')
  }
  if (endpoint.username !== '' || endpoint.password !== '') {
    throw new Error('baseUrl must not contain credentials')
  }
  if (endpoint.search !== '' || endpoint.hash !== '') {
    throw new Error('baseUrl must not contain a query or fragment')
  }
  if (config.outputDir !== undefined && config.outputDir !== ''
    && (typeof config.outputDir !== 'string' || !isAbsolute(config.outputDir))) {
    throw new Error('outputDir must be an absolute path when configured')
  }
  if (!Array.isArray(config.allowedUploadRoots)
    || config.allowedUploadRoots.some((root) => typeof root !== 'string' || root.trim() === '' || !isAbsolute(root))) {
    throw new Error('every allowedUploadRoots entry must be a non-empty absolute path')
  }
}

/**
 * Resolve legacy configuration or named instances without connecting to any server.
 * Only transport/wait/size settings are shared; paths and upload grants never inherit
 * from legacy configuration when named instances are present.
 */
export function createInstanceRegistry(config) {
  const configured = config.instances ?? []
  if (!Array.isArray(configured)) throw new Error('instances must be an array')
  const definitions = configured.length > 0 ? configured : [{
    id: 'default',
    baseUrl: config.baseUrl,
    outputDir: config.outputDir,
    allowedUploadRoots: config.allowedUploadRoots,
  }]
  const instances = new Map()
  for (const definition of definitions) {
    const id = definition?.id
    if (typeof id !== 'string' || id === '' || /\s|[\u0000-\u001f\u007f]/u.test(id)) {
      throw new Error('every instance id must be a non-empty string without whitespace or control characters')
    }
    if (instances.has(id)) throw new Error(`duplicate instance id: ${id}`)
    const resolved = {
      ...config,
      baseUrl: definition.baseUrl,
      outputDir: definition.outputDir,
      allowedUploadRoots: definition.allowedUploadRoots ?? [],
    }
    try {
      validateInstance(resolved)
    } catch (error) {
      throw new Error(`invalid ComfyUI instance "${id}": ${error.message}`, { cause: error })
    }
    resolved.allowedUploadRoots = [...resolved.allowedUploadRoots]
    instances.set(id, {
      id,
      config: resolved,
      client: new ComfyClient({
        baseUrl: resolved.baseUrl,
        requestTimeoutMs: resolved.requestTimeoutMs,
        maxResponseBytes: resolved.maxResponseBytes,
        maxMediaBytes: resolved.maxMediaBytes,
      }),
      objectInfoCache: undefined,
    })
  }
  const defaultInstanceId = config.defaultInstanceId ?? instances.keys().next().value
  if (!instances.has(defaultInstanceId)) {
    throw new Error(`defaultInstanceId must name a configured instance: ${[...instances.keys()].join(', ')}`)
  }
  return {
    instances,
    defaultInstanceId,
    select(id = defaultInstanceId) {
      const instance = instances.get(id)
      if (instance === undefined) throw new Error(`unknown ComfyUI instance: ${id}`)
      return instance
    },
  }
}
