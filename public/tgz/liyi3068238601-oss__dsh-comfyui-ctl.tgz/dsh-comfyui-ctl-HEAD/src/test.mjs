/**
 * test.mjs — self-test for ComfyClient against the canned mock server.
 * Run from the project root: node src/test.mjs
 * Exits non-zero on any failure. No dependencies beyond Node.
 * @module dsh-comfyui-ctl/test
 */

import { strict as assert } from 'node:assert'
import { startMockServer } from './mock-server.mjs'
import { abortableSleep, ComfyClient, ComfyHttpError } from './client.js'

let passed = 0
let failed = 0

function check(label, fn) {
  return Promise.resolve()
    .then(fn)
    .then(() => {
      passed += 1
      console.log(`  ok  ${label}`)
    })
    .catch((error) => {
      failed += 1
      console.error(`  FAIL ${label}\n      ${error instanceof Error ? error.message : String(error)}`)
    })
}

async function main() {
  const mock = await startMockServer()
  const client = new ComfyClient({ baseUrl: `http://127.0.0.1:${mock.port}` })
  console.log(`mock ComfyUI on 127.0.0.1:${mock.port}`)

  await check('queue summary', async () => {
    const queue = await client.queue()
    assert.ok(Array.isArray(queue.queue_running))
    assert.ok(Array.isArray(queue.queue_pending))
  })

  await check('interrupt', async () => {
    await client.interrupt()
  })

  await check('queueDelete clear', async () => {
    await client.queueDelete({ clear: true })
  })

  await check('queueDelete by ids', async () => {
    await client.queueDelete({ promptIds: ['mock-abc'] })
  })

  await check('submit + waitForCompletion', async () => {
    const { promptId } = await client.submitPrompt({
      '3': { class_type: 'KSampler', inputs: { seed: 42, steps: 20 } },
    })
    const result = await client.waitForCompletion(promptId, { pollMs: 50, timeoutMs: 5000 })
    assert.equal(result.completed, true)
    assert.equal(result.statusStr, 'success')
    assert.ok(result.entry.outputs['9'].images.length === 1)
    assert.equal(result.entry.outputs['9'].images[0].filename, `ComfyUI_${promptId}.png`)
  })

  await check('submit validation error surfaces node_errors', async () => {
    await assert.rejects(
      client.submitPrompt({ '1': { inputs: {} } }),
      (error) => error instanceof Error && /node 1/.test(error.message) && /class_type/.test(error.message),
    )
  })

  await check('history by id', async () => {
    const { promptId } = await client.submitPrompt({ '3': { class_type: 'KSampler', inputs: {} } })
    await client.waitForCompletion(promptId, { pollMs: 50, timeoutMs: 5000 })
    const res = await client.history({ promptId })
    assert.ok(res[promptId].status.completed === true)
  })

  await check('history list with max_items', async () => {
    const res = await client.history({ maxItems: 5 })
    const count = Object.keys(res).length
    assert.ok(count >= 1)
  })

  await check('object_info (full + single)', async () => {
    const full = await client.objectInfo()
    assert.ok('KSampler' in full)
    const single = await client.objectInfo('KSampler')
    assert.ok(single.KSampler.input.required.model !== undefined)
  })

  await check('system_stats', async () => {
    const stats = await client.systemStats()
    assert.equal(stats.devices[0].name, 'NVIDIA GeForce RTX 4090')
    assert.equal(stats.system.comfyui_version, '0.3.50')
  })

  await check('extensions', async () => {
    const ext = await client.extensions()
    assert.ok(ext.includes('ComfyUI-Example'))
  })

  await check('modelsList JSON folder', async () => {
    const files = await client.modelsList('checkpoints')
    assert.deepEqual(files, ['dreamshaper.safetensors', 'juggernautXL.safetensors'])
  })

  await check('modelsList plain-text folder', async () => {
    const files = await client.modelsList('loras')
    assert.deepEqual(files, ['add_detail.safetensors', 'style_sdxl.safetensors'])
  })

  await check('uploadImage', async () => {
    const res = await client.uploadImage({
      data: Buffer.from('fake-png-bytes'),
      filename: 'myphoto.png',
      subfolder: 'sub',
      overwrite: true,
    })
    assert.equal(res.name, 'myphoto.png')
    assert.equal(res.subfolder, 'sub')
    assert.equal(res.type, 'input')
  })

  await check('view returns bytes', async () => {
    const { bytes, contentType } = await client.view({ filename: 'ComfyUI_test.png', subfolder: '', type: 'output' })
    assert.ok(bytes.byteLength > 0)
    assert.equal(contentType, 'image/png')
  })

  await check('response byte limit rejects oversized content', async () => {
    const limited = new ComfyClient({ baseUrl: `http://127.0.0.1:${mock.port}`, maxResponseBytes: 128 })
    await assert.rejects(limited.request('/large'), /exceeds the 128-byte limit/)
  })

  await check('media byte limit rejects oversized content', async () => {
    const limited = new ComfyClient({ baseUrl: `http://127.0.0.1:${mock.port}`, maxMediaBytes: 16 })
    await assert.rejects(limited.view({ filename: 'ComfyUI_test.png' }), /exceeds the 16-byte limit/)
  })

  await check('abortableSleep removes settled listeners', async () => {
    const controller = new AbortController()
    const signal = controller.signal
    const originalAdd = signal.addEventListener.bind(signal)
    const originalRemove = signal.removeEventListener.bind(signal)
    let added = 0
    let removed = 0
    Object.defineProperty(signal, 'addEventListener', { value: (...args) => { added += 1; return originalAdd(...args) } })
    Object.defineProperty(signal, 'removeEventListener', { value: (...args) => { removed += 1; return originalRemove(...args) } })
    for (let index = 0; index < 12; index += 1) await abortableSleep(1, signal)
    assert.equal(added, 12)
    assert.equal(removed, 12)
  })

  await check('abortableSleep rejects cancellation', async () => {
    const controller = new AbortController()
    const waiting = abortableSleep(5000, controller.signal)
    controller.abort(new Error('cancelled by test'))
    await assert.rejects(waiting, /cancelled by test/)
  })

  await check('waitForCompletion timeout reports incomplete', async () => {
    const { promptId } = await client.submitPrompt({ '3': { class_type: 'KSampler', inputs: {} } })
    // The mock completes after ~400 ms; a 50 ms budget must time out.
    const result = await client.waitForCompletion(promptId, { pollMs: 20, timeoutMs: 50 })
    assert.equal(result.completed, false)
  })

  await check('unreachable server yields readable error', async () => {
    const dead = new ComfyClient({ baseUrl: 'http://127.0.0.1:1', requestTimeoutMs: 500 })
    await assert.rejects(dead.queue(), /cannot reach ComfyUI/)
  })

  await check('ComfyHttpError carries nodeErrors', async () => {
    try {
      const raw = new ComfyClient({ baseUrl: `http://127.0.0.1:${mock.port}` })
      await raw.request('/prompt', { method: 'POST', json: { prompt: { '1': { inputs: {} } } } })
      assert.fail('expected a 400')
    } catch (error) {
      assert.ok(error instanceof ComfyHttpError)
      assert.equal(error.status, 400)
      assert.ok(error.nodeErrors['1'] !== undefined)
    }
  })

  await mock.close()
  console.log(`\n${passed} passed, ${failed} failed`)
  process.exitCode = failed === 0 ? 0 : 1
}

main().catch((error) => {
  console.error(error)
  process.exitCode = 1
})
