/**
 * Small DSH tool-definition adapter with no dependency on unpublished host packages.
 * Converts the plugin's concise schema specs to JSON Schema and validates arguments.
 * @module dsh-comfyui-ctl/tool-definition
 */

function toJsonSchema(spec) {
  if (spec === undefined || spec === null || typeof spec !== 'object') return spec
  if (Array.isArray(spec)) return spec.map(toJsonSchema)
  const result = {}
  for (const [key, value] of Object.entries(spec)) {
    if (key === 'required') continue
    if (key === 'properties') {
      const properties = {}
      const required = []
      for (const [name, property] of Object.entries(value)) {
        properties[name] = toJsonSchema(property)
        if (property.required === true) required.push(name)
      }
      result.properties = properties
      if (required.length > 0) result.required = required
    } else {
      result[key] = toJsonSchema(value)
    }
  }
  return result
}

function parameterSchema(spec) {
  const properties = {}
  const required = []
  for (const [name, property] of Object.entries(spec)) {
    properties[name] = toJsonSchema(property)
    if (property.required === true) required.push(name)
  }
  return { type: 'object', properties, required, additionalProperties: false }
}

function validate(schema, value, path = '$') {
  const errors = []
  if (schema.enum !== undefined && !schema.enum.includes(value)) {
    errors.push(`${path} must be one of ${schema.enum.join(', ')}`)
    return errors
  }
  if (schema.type === 'object') {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) return [`${path} must be an object`]
    for (const name of schema.required ?? []) {
      if (!Object.hasOwn(value, name)) errors.push(`${path}.${name} is required`)
    }
    for (const [name, child] of Object.entries(value)) {
      const property = schema.properties?.[name]
      if (property !== undefined) errors.push(...validate(property, child, `${path}.${name}`))
      else if (schema.additionalProperties === false) errors.push(`${path}.${name} is not allowed`)
    }
  } else if (schema.type === 'array') {
    if (!Array.isArray(value)) return [`${path} must be an array`]
    if (schema.items !== undefined) {
      value.forEach((item, index) => errors.push(...validate(schema.items, item, `${path}[${index}]`)))
    }
  } else if (schema.type === 'string' && typeof value !== 'string') {
    errors.push(`${path} must be a string`)
  } else if (schema.type === 'boolean' && typeof value !== 'boolean') {
    errors.push(`${path} must be a boolean`)
  } else if (schema.type === 'number' && (typeof value !== 'number' || !Number.isFinite(value))) {
    errors.push(`${path} must be a finite number`)
  } else if (schema.type === 'integer' && !Number.isSafeInteger(value)) {
    errors.push(`${path} must be an integer`)
  }
  if (typeof value === 'number') {
    if (schema.minimum !== undefined && value < schema.minimum) errors.push(`${path} must be >= ${schema.minimum}`)
    if (schema.maximum !== undefined && value > schema.maximum) errors.push(`${path} must be <= ${schema.maximum}`)
  }
  return errors
}

/** Return a registry-ready DSH tool definition. */
export function defineTool(options) {
  if (typeof options.name !== 'string' || options.name === '') throw new Error('tool name must be a non-empty string')
  if (typeof options.execute !== 'function') throw new Error(`defineTool(${options.name}): execute must be a function`)
  const parameters = parameterSchema(options.parameters)
  const outputSchema = toJsonSchema(options.output.schema)
  const execute = options.execute
  return {
    ...options,
    parameters,
    output: { ...options.output, schema: outputSchema },
    async execute(args, exec) {
      const errors = validate(parameters, args)
      if (errors.length > 0) throw new Error(`invalid arguments for ${options.name}: ${errors.join('; ')}`)
      return execute(args, exec)
    },
  }
}
