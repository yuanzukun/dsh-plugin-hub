/**
 * test-apply.mjs — offline validation of the plugin's apply() body against the
 * bundled tool-definition adapter. Run: node src/test-apply.mjs
 * @module dsh-comfyui-ctl/test-apply
 */

import { strict as assert } from 'node:assert'
import { Context } from '@deepseek-ai/cordis'
import * as plugin from './index.js'

const { apply, Config } = plugin

/** Minimal fake context: tools.register captures definitions; get() returns nothing. */
const registered = new Map()
let effectDisposer
const fakeCtx = {
  get: () => undefined,
  effect: (callback) => {
    effectDisposer = callback()
  },
  tools: {
    register: (definition) => {
      if (registered.has(definition.name)) throw new Error(`duplicate tool: ${definition.name}`)
      registered.set(definition.name, definition)
      return () => registered.delete(definition.name)
    },
  },
}

const config = Config({})
console.log('config resolved:', JSON.stringify(config))

apply(fakeCtx, config)

console.log(`\n${registered.size} tool(s) registered:`)
for (const tool of registered.values()) {
  console.log(`  - ${tool.name}`)
}

const expected = [
  'comfyui_instances_list',
  'comfyui_queue_get',
  'comfyui_interrupt',
  'comfyui_queue_delete',
  'comfyui_history_get',
  'comfyui_output_list',
  'comfyui_output_get',
  'comfyui_models_list',
  'comfyui_system_stats',
  'comfyui_nodes_list',
  'comfyui_upload_image',
  'comfyui_generate',
]
const names = new Set(registered.keys())
assert.equal(registered.size, expected.length)
const missing = expected.filter((name) => !names.has(name))
if (missing.length > 0) {
  console.error(`\nMISSING tools: ${missing.join(', ')}`)
  process.exitCode = 1
} else {
  console.log('\nAll 12 tools registered cleanly through the bundled tool adapter.')
}

const generate = registered.get('comfyui_generate')
assert.ok(generate.output.schema.properties.inline_errors !== undefined)
assert.deepEqual(generate.parameters.required, ['prompt'])
await assert.rejects(generate.execute({}, { signal: new AbortController().signal }), /prompt is required/)
await assert.rejects(generate.execute({ prompt: {}, unexpected: true }, { signal: new AbortController().signal }), /unexpected is not allowed/)
const upload = registered.get('comfyui_upload_image')
assert.ok(upload.output.schema.properties.source_name !== undefined)
assert.equal(upload.output.schema.properties.source_path, undefined)
for (const tool of registered.values()) {
  if (tool.name === 'comfyui_instances_list') continue
  assert.deepEqual(tool.parameters.properties.instance_id.enum, ['default'])
  assert.ok(tool.output.schema.required.includes('instance_id'))
}
assert.deepEqual(await registered.get('comfyui_instances_list').execute({}, {}), {
  default_instance_id: 'default',
  instances: [{ instance_id: 'default', base_url: 'http://127.0.0.1:8188', is_default: true, output_source: 'history' }],
})
assert.equal(typeof effectDisposer, 'function')
effectDisposer()
assert.equal(registered.size, 0)

let active = 0
let disposed = 0
const failingCtx = {
  get: () => undefined,
  effect: (callback) => callback(),
  tools: {
    register: () => {
      if (active === 4) throw new Error('registration failed by test')
      active += 1
      return () => { active -= 1; disposed += 1 }
    },
  },
}
assert.throws(() => apply(failingCtx, config), /registration failed by test/)
assert.equal(active, 0)
assert.equal(disposed, 4)
console.log('Lifecycle cleanup passed for normal disposal and partial registration failure.')

assert.throws(() => apply(fakeCtx, { ...config, baseUrl: 'file:///tmp/comfyui' }), /HTTP or HTTPS/)
assert.throws(() => apply(fakeCtx, { ...config, baseUrl: 'http://user:secret@127.0.0.1:8188' }), /must not contain credentials/)
assert.throws(() => apply(fakeCtx, { ...config, allowedUploadRoots: ['relative/path'] }), /absolute path/)
assert.throws(() => apply(fakeCtx, { ...config, baseUrl: 'http://127.0.0.1:8188?secret=x' }), /query or fragment/)
assert.throws(() => apply(fakeCtx, { ...config, baseUrl: 'http://127.0.0.1:8188#path' }), /query or fragment/)
assert.throws(() => apply(fakeCtx, { ...config, outputDir: 'relative/output' }), /absolute path/)
assert.throws(() => Config({ instances: [{ id: 'missing-url' }] }), /baseUrl/)
assert.throws(() => apply(fakeCtx, Config({ instances: [{ id: '', baseUrl: 'http://localhost:8188' }] })), /instance id/)
assert.throws(() => apply(fakeCtx, Config({ instances: [{ id: 'has space', baseUrl: 'http://localhost:8188' }] })), /instance id/)
assert.throws(() => apply(fakeCtx, Config({ instances: [
  { id: 'same', baseUrl: 'http://localhost:8188' },
  { id: 'same', baseUrl: 'http://localhost:8189' },
] })), /duplicate instance id/)
assert.throws(() => apply(fakeCtx, Config({ defaultInstanceId: 'missing', instances: [{ id: 'local', baseUrl: 'http://localhost:8188' }] })), /defaultInstanceId/)
assert.throws(() => apply(fakeCtx, Config({ instances: [{ id: 'remote', baseUrl: 'file:///tmp/comfyui' }] })), /HTTP or HTTPS/)
assert.throws(() => apply(fakeCtx, Config({ instances: [{ id: 'remote', baseUrl: 'http://user:secret@localhost:8188' }] })), /must not contain credentials/)
assert.throws(() => apply(fakeCtx, Config({ instances: [{ id: 'remote', baseUrl: 'http://localhost:8188', allowedUploadRoots: ['relative/path'] }] })), /absolute path/)
assert.equal(registered.size, 0, 'invalid configuration must not register tools')
console.log('Configuration boundary checks passed.')

// The real Cordis fiber validates nested configuration and owns tool disposal.
// This uses a test tools registry rather than claiming a full DSH deployment.
const nativeCtx = new Context()
const nativeTools = new Map()
const releaseService = nativeCtx.provide('tools', {
  register(definition) {
    assert.equal(nativeTools.has(definition.name), false)
    nativeTools.set(definition.name, definition)
    return () => nativeTools.delete(definition.name)
  },
})
try {
  const fiber = nativeCtx.plugin(plugin, {
    instances: [
      { id: 'local', baseUrl: 'http://127.0.0.1:8188' },
      { id: 'remote', baseUrl: 'http://127.0.0.1:8189' },
    ],
    defaultInstanceId: 'remote',
  })
  await fiber
  assert.equal(nativeTools.size, 12)
  const listing = await nativeTools.get('comfyui_instances_list').execute({}, {})
  assert.equal(listing.default_instance_id, 'remote')
  assert.deepEqual(nativeTools.get('comfyui_generate').parameters.properties.instance_id.enum, ['local', 'remote'])
  await fiber.dispose()
  assert.equal(nativeTools.size, 0)
  const reloaded = nativeCtx.plugin(plugin, { instances: [{ id: 'replacement', baseUrl: 'http://127.0.0.1:8190' }] })
  await reloaded
  assert.deepEqual(nativeTools.get('comfyui_generate').parameters.properties.instance_id.enum, ['replacement'])
  await reloaded.dispose()
  assert.equal(nativeTools.size, 0)
} finally {
  releaseService()
}
console.log('Native Cordis load/dispose/reload passed with a test tools registry.')
