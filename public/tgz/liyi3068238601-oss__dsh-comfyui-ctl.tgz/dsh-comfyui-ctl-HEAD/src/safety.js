/**
 * Filesystem and media admission checks for local uploads.
 * @module dsh-comfyui-ctl/safety
 */

import { readFile, realpath, stat } from 'node:fs/promises'
import { basename, isAbsolute, relative } from 'node:path'

const IMAGE_MEDIA_BY_EXT = new Map([
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.webp', 'image/webp'],
  ['.gif', 'image/gif'],
])

function extensionOf(name) {
  const dot = name.lastIndexOf('.')
  return dot < 0 ? '' : name.slice(dot).toLowerCase()
}

/** Return the supported image media type proven by magic bytes. */
export function detectImageMediaType(data) {
  if (data.length >= 8 && data.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    return 'image/png'
  }
  if (data.length >= 3 && data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff) return 'image/jpeg'
  if (data.length >= 6) {
    const signature = data.subarray(0, 6).toString('ascii')
    if (signature === 'GIF87a' || signature === 'GIF89a') return 'image/gif'
  }
  if (data.length >= 12 && data.subarray(0, 4).toString('ascii') === 'RIFF'
    && data.subarray(8, 12).toString('ascii') === 'WEBP') return 'image/webp'
  return undefined
}

/** Validate one virtual ComfyUI subfolder and return slash-normalized text. */
export function normalizeComfySubfolder(value) {
  const normalized = (value ?? '').trim().replace(/\\/g, '/')
  if (normalized === '') return ''
  if (normalized.startsWith('/') || normalized.includes('\0')) throw new Error('subfolder must be a relative ComfyUI path')
  const parts = normalized.split('/')
  if (parts.some((part) => part === '' || part === '.' || part === '..')) {
    throw new Error('subfolder must not contain empty, current-directory, or parent-directory segments')
  }
  return parts.join('/')
}

/** Validate an upload file name without allowing path components. */
export function normalizeUploadName(value, fallback, mediaType) {
  const name = (value ?? '').trim() || fallback
  if (name === '' || name === '.' || name === '..' || name.includes('/') || name.includes('\\') || name.includes('\0')) {
    throw new Error('upload name must be a plain file name')
  }
  const extensionMediaType = IMAGE_MEDIA_BY_EXT.get(extensionOf(name))
  if (extensionMediaType === undefined) throw new Error('upload name must use png, jpg, jpeg, webp, or gif')
  if (mediaType !== undefined && extensionMediaType !== mediaType) {
    throw new Error('upload name extension must match the image content')
  }
  return name
}

function isInside(root, candidate) {
  const rel = relative(root, candidate)
  return rel === '' || (!rel.startsWith('..') && !isAbsolute(rel))
}

/**
 * Read an image only after its canonical path is contained by a configured root.
 * The default empty root list deliberately disables path-based uploads.
 */
export async function readAllowedImage(pathValue, allowedRoots, maxBytes) {
  const requested = pathValue.trim()
  if (requested === '' || !isAbsolute(requested)) throw new Error('path must be an absolute file path')
  if (!Array.isArray(allowedRoots) || allowedRoots.length === 0) {
    throw new Error('local path uploads are disabled; configure allowedUploadRoots first')
  }
  if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0) throw new Error('maxUploadBytes must be a positive integer')

  const canonicalFile = await realpath(requested)
  let admitted = false
  for (const rootValue of allowedRoots) {
    if (typeof rootValue !== 'string' || rootValue.trim() === '' || !isAbsolute(rootValue)) continue
    try {
      const canonicalRoot = await realpath(rootValue)
      const rootStats = await stat(canonicalRoot)
      if (rootStats.isDirectory() && isInside(canonicalRoot, canonicalFile)) {
        admitted = true
        break
      }
    } catch {
      // Missing or unreadable roots do not grant access.
    }
  }
  if (!admitted) throw new Error('path is outside the configured allowedUploadRoots')

  const fileStats = await stat(canonicalFile)
  if (!fileStats.isFile()) throw new Error('path must identify a regular file')
  if (fileStats.size > maxBytes) throw new Error(`upload exceeds maxUploadBytes (${maxBytes} bytes)`)
  const data = await readFile(canonicalFile)
  if (data.byteLength > maxBytes) throw new Error(`upload exceeds maxUploadBytes (${maxBytes} bytes)`)

  const actualMediaType = detectImageMediaType(data)
  if (actualMediaType === undefined) throw new Error('upload file is not a supported PNG, JPEG, WebP, or GIF image')
  const originalName = basename(canonicalFile)
  const extensionMediaType = IMAGE_MEDIA_BY_EXT.get(extensionOf(originalName))
  if (extensionMediaType !== actualMediaType) throw new Error('upload file extension does not match its image content')
  return { data, originalName, mediaType: actualMediaType }
}
