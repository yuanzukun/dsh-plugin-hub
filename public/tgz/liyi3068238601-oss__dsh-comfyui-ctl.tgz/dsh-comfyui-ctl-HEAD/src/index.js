/**
 * dsh-comfyui-ctl — ComfyUI cockpit for DeepSeek Harness.
 *
 * A native DSH plugin registering 12 agent tools over the standalone
 * ComfyClient (see ./client.js): queue control, history & outputs,
 * model/system inventory, upload, and prompt submission.
 *
 * Config uses the publicly published @deepseek-ai/schemastery; the tool
 * definition adapter ships with this plugin. The attachment service is obtained
 * via ctx.get('attachments') at execute time and used duck-typed, so no
 * additional runtime dependency is needed for image inlining.
 * @module dsh-comfyui-ctl
 */

import { randomUUID } from 'node:crypto'
import { readdir } from 'node:fs/promises'
import { extname, join, relative } from 'node:path'
import Schema from '@deepseek-ai/schemastery'
import { normalizeComfySubfolder, normalizeUploadName, readAllowedImage } from './safety.js'
import { defineTool } from './tool-definition.js'
import { createInstanceRegistry } from './instances.js'
import {
  ComfyHttpError,
  DEFAULT_MAX_MEDIA_BYTES,
  DEFAULT_MAX_RESPONSE_BYTES,
  DEFAULT_POLL_INTERVAL_MS,
  DEFAULT_REQUEST_TIMEOUT_MS,
  DEFAULT_WAIT_TIMEOUT_MS,
  formatNodeErrors,
} from './client.js'

export const name = 'dsh-comfyui-ctl'
export const inject = ['tools']

const InstanceConfig = Schema.object({
  id: Schema.string().required()
    .description('Unique ComfyUI instance ID without whitespace, e.g. local or gpu-server'),
  baseUrl: Schema.string().required()
    .description('Reachable ComfyUI HTTP or HTTPS server address'),
  outputDir: Schema.string()
    .description('Optional output directory accessible to the DSH process, not a remote filesystem path'),
  allowedUploadRoots: Schema.array(Schema.string()).default([])
    .description('DSH-local upload roots for this instance only; empty disables path uploads'),
})

export const Config = Schema.object({
  instances: Schema.array(InstanceConfig).default([])
    .description('Named ComfyUI instances; when non-empty, replaces legacy endpoint and path settings'),
  defaultInstanceId: Schema.string()
    .description('Default instance ID when tools omit instance_id; defaults to the first instance, or default in legacy mode'),
  baseUrl: Schema.string()
    .default('http://127.0.0.1:8188')
    .description('ComfyUI server base URL, e.g. http://127.0.0.1:8188'),
  requestTimeoutMs: Schema.number()
    .step(1).min(100).max(300_000)
    .default(DEFAULT_REQUEST_TIMEOUT_MS)
    .description('Per-request HTTP timeout in milliseconds'),
  pollIntervalMs: Schema.number()
    .step(1).min(100).max(30_000)
    .default(DEFAULT_POLL_INTERVAL_MS)
    .description('Poll interval while waiting for a generation to finish'),
  generateTimeoutMs: Schema.number()
    .step(1).min(1_000).max(30 * 60_000)
    .default(DEFAULT_WAIT_TIMEOUT_MS)
    .description('Default ceiling for comfyui_generate wait, in milliseconds'),
  maxInlineImages: Schema.number()
    .step(1).min(0).max(8)
    .default(4)
    .description('Maximum number of images inlined into one tool result'),
  maxResponseBytes: Schema.number()
    .step(1).min(64 * 1024).max(128 * 1024 * 1024)
    .default(DEFAULT_MAX_RESPONSE_BYTES)
    .description('Maximum bytes accepted from one ComfyUI JSON or text response'),
  maxMediaBytes: Schema.number()
    .step(1).min(64 * 1024).max(512 * 1024 * 1024)
    .default(DEFAULT_MAX_MEDIA_BYTES)
    .description('Maximum bytes downloaded for one ComfyUI media file'),
  maxUploadBytes: Schema.number()
    .step(1).min(64 * 1024).max(512 * 1024 * 1024)
    .default(DEFAULT_MAX_MEDIA_BYTES)
    .description('Maximum bytes read from one local upload file'),
  allowedUploadRoots: Schema.array(Schema.string())
    .default([])
    .description('Absolute directories allowed for local path uploads; empty disables path uploads'),
  outputDir: Schema.string()
    .description('Legacy output directory accessible to the DSH process; enables directory listing mode'),
})

/** Canonical model folders probed by comfyui_models_list without a folder argument. */
const MODEL_FOLDERS = [
  'checkpoints',
  'diffusion_models',
  'loras',
  'vae',
  'text_encoders',
  'clip',
  'clip_vision',
  'controlnet',
  'upscale_models',
  'embeddings',
  'style_models',
  'photomaker',
]

const IMAGE_MEDIA_BY_EXT = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
}

/**
 * The canonical image metadata shape, mirrored from the built-in read_image
 * tool so attachment refs stay interchangeable with the rest of the harness.
 */
const IMAGE_VALUE_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    attachmentId: { type: 'string', required: true },
    mediaType: { type: 'string', enum: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'], required: true },
    bytes: { type: 'integer', required: true },
    width: { type: 'integer', required: true },
    height: { type: 'integer', required: true },
    name: { type: 'string' },
  },
}

/** @param {string} filename */
function imageMediaTypeForName(filename) {
  return IMAGE_MEDIA_BY_EXT[extname(filename).toLowerCase()]
}

/**
 * Persist image bytes into the attachment store and return the canonical
 * image value for the tool output schema.
 * @param {import('@deepseek-ai/cordis').Context} ctx
 * @param {{ data: Uint8Array, mediaType: string, name: string }} input
 * @returns {Promise<object>} canonical image value
 */
async function saveImageValue(ctx, { data, mediaType, name }) {
  const attachments = ctx.get('attachments')
  if (attachments === undefined) {
    throw new Error('no attachment service is mounted in this deployment; the image cannot be inlined')
  }
  if (attachments.imageLimits !== undefined && !attachments.imageLimits.mediaTypes.includes(mediaType)) {
    throw new Error(`${mediaType} images are not accepted by this deployment`)
  }
  let ref
  try {
    ref = await attachments.saveImage({ data, mediaType, name })
  } catch (error) {
    const code = error !== null && typeof error === 'object' && 'code' in error ? error.code : undefined
    if (code === 'IMAGE_DIMENSION_TOO_LARGE' || code === 'IMAGE_TOO_MANY_PIXELS' || code === 'IMAGE_TOO_LARGE') {
      throw new Error(`image too large to inline (${code}); inspect it another way instead`, { cause: error })
    }
    throw error
  }
  return {
    attachmentId: ref.attachmentId,
    mediaType: ref.mediaType,
    bytes: ref.bytes,
    width: ref.width,
    height: ref.height,
    ...(ref.name === undefined ? {} : { name: ref.name }),
  }
}

/** Rebuild the content-block attachment ref from a canonical image value. */
function imageBlockFromValue(image) {
  if (image === undefined || image === null) return undefined
  return {
    type: 'image',
    attachment: {
      attachmentId: image.attachmentId,
      mediaType: image.mediaType,
      bytes: image.bytes,
      width: image.width,
      height: image.height,
      ...(image.name === undefined ? {} : { name: image.name }),
    },
  }
}

/** Compact summary of an API-format prompt graph. */
function summarizePrompt(prompt) {
  const ids = Object.keys(prompt)
  const classes = {}
  for (const id of ids) {
    const classType = prompt[id]?.class_type
    if (typeof classType === 'string') classes[classType] = (classes[classType] ?? 0) + 1
  }
  return { node_count: ids.length, classes }
}

/** Compact summary of one queue item tuple [number, prompt_id, prompt, extra, outputs]. */
function summarizeQueueItem(item, instanceId) {
  if (!Array.isArray(item)) return { instance_id: instanceId }
  const promptId = typeof item[1] === 'string' ? item[1] : undefined
  const prompt = item[2] !== null && typeof item[2] === 'object' ? item[2] : undefined
  return {
    instance_id: instanceId,
    ...(promptId === undefined ? {} : { prompt_id: promptId }),
    ...(prompt === undefined ? {} : summarizePrompt(prompt)),
  }
}

/** Compact, model-facing summary of one history entry. */
function summarizeHistoryEntry(promptId, entry, instanceId) {
  if (entry === undefined || entry === null || typeof entry !== 'object') {
    return { instance_id: instanceId, prompt_id: promptId, present: false }
  }
  const status = entry.status ?? {}
  const outputs = []
  const rawOutputs = entry.outputs ?? {}
  for (const [nodeId, nodeOut] of Object.entries(rawOutputs)) {
    if (nodeOut === null || typeof nodeOut !== 'object') continue
    const files = []
    for (const key of ['images', 'gifs', 'videos', 'audio']) {
      const items = nodeOut[key]
      if (!Array.isArray(items)) continue
      for (const item of items) {
        if (item !== null && typeof item === 'object' && typeof item.filename === 'string') {
          files.push({
            instance_id: instanceId,
            filename: item.filename,
            subfolder: typeof item.subfolder === 'string' ? item.subfolder : '',
            type: typeof item.type === 'string' ? item.type : 'output',
          })
        }
      }
    }
    outputs.push({ node_id: nodeId, files })
  }
  let startedAt
  let endedAt
  let errorSummary
  if (Array.isArray(status.messages)) {
    for (const msg of status.messages) {
      if (!Array.isArray(msg) || msg.length < 2 || msg[1] === null || typeof msg[1] !== 'object') continue
      const kind = msg[0]
      const payload = msg[1]
      if (kind === 'execution_start' && typeof payload.timestamp === 'number') startedAt = payload.timestamp
      if (kind === 'execution_success' && typeof payload.timestamp === 'number') endedAt = payload.timestamp
      if (kind === 'execution_error') {
        if (typeof payload.timestamp === 'number') endedAt = payload.timestamp
        const nodeType = typeof payload.node_type === 'string' ? payload.node_type : undefined
        const message = typeof payload.exception_message === 'string' ? payload.exception_message : undefined
        errorSummary = {
          ...(nodeType === undefined ? {} : { node_type: nodeType }),
          ...(message === undefined ? {} : { message }),
        }
      }
    }
  }
  return {
    instance_id: instanceId,
    prompt_id: promptId,
    present: true,
    status_str: typeof status.status_str === 'string' ? status.status_str : undefined,
    completed: status.completed === true,
    ...(startedAt === undefined ? {} : { started_at: startedAt }),
    ...(endedAt === undefined ? {} : { ended_at: endedAt }),
    ...(errorSummary === undefined ? {} : { error: errorSummary }),
    outputs,
  }
}

/**
 * Compose an abort signal honouring both the caller token and a hard timeout.
 * @param {number} ms - timeout in milliseconds
 * @param {AbortSignal|undefined} signal - caller-owned signal
 */
function deadline(ms, signal) {
  const timer = AbortSignal.timeout(ms)
  return signal === undefined ? timer : AbortSignal.any([timer, signal])
}

/**
 * Read a local file and upload it into ComfyUI's input directory.
 */
async function uploadLocalImage(client, args, config, signal) {
  signal?.throwIfAborted()
  const { data, originalName, mediaType } = await readAllowedImage(args.path, config.allowedUploadRoots, config.maxUploadBytes)
  const filename = normalizeUploadName(args.name, originalName, mediaType)
  const subfolder = normalizeComfySubfolder(args.subfolder)
  signal?.throwIfAborted()
  const res = await client.uploadImage({
    data,
    filename,
    subfolder,
    overwrite: args.overwrite,
  }, { signal })
  return {
    filename: res.name ?? filename,
    subfolder: res.subfolder ?? '',
    type: res.type ?? 'input',
    source_name: originalName,
    bytes: data.byteLength,
  }
}

export function apply(ctx, config) {
  const registry = createInstanceRegistry(config)
  ctx.effect(() => {
  const disposers = []
  const disposeAll = () => {
    for (;;) {
      const dispose = disposers.pop()
      if (dispose === undefined) break
      try { dispose() } catch { /* continue releasing the remaining registrations */ }
    }
  }
  const register = (definition) => {
    try {
      disposers.push(ctx.tools.register(definition))
    } catch (error) {
      disposeAll()
      throw error
    }
  }
  const instanceIds = [...registry.instances.keys()]
  const registerInstanceTool = (options) => register(defineTool({
    ...options,
    description: `${options.description} Select instance_id to target a configured server; omission uses ${registry.defaultInstanceId}.`,
    parameters: {
      ...options.parameters,
      instance_id: {
        type: 'string',
        enum: instanceIds,
        description: `Target ComfyUI instance (default: ${registry.defaultInstanceId}); preserve this ID for follow-up calls`,
      },
    },
    output: {
      ...options.output,
      schema: {
        ...options.output.schema,
        properties: {
          ...options.output.schema.properties,
          instance_id: { type: 'string', required: true },
        },
      },
      render: (args, value) => [
        { type: 'text', text: `ComfyUI instance: ${value.instance_id}` },
        ...options.output.render(args, value),
      ],
    },
    async execute(args, exec) {
      const instance = registry.select(args.instance_id)
      exec.signal?.throwIfAborted()
      try {
        const value = await options.execute(args, exec, instance)
        return { ...value, instance_id: instance.id }
      } catch (error) {
        if (exec.signal?.aborted) throw error
        throw new Error(`ComfyUI instance "${instance.id}": ${error instanceof Error ? error.message : String(error)}`, { cause: error })
      }
    },
  }))

  /** Cache completed object_info responses per server, never share caller signals. */
  async function cachedObjectInfo(instance, signal) {
    signal?.throwIfAborted()
    const now = Date.now()
    const cache = instance.objectInfoCache
    if (cache !== undefined && now - cache.ts < 60_000) return cache.value
    const value = await instance.client.objectInfo(undefined, { signal })
    instance.objectInfoCache = { ts: Date.now(), value }
    return value
  }

  register(defineTool({
    name: 'comfyui_instances_list',
    description: 'List configured ComfyUI instances and the default instance without contacting servers. Use the returned instance_id in generation, history, output, upload and queue calls. Submit wait=false to each target before polling to let separate servers generate simultaneously.',
    parameters: {},
    isConcurrencySafe: () => true,
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          default_instance_id: { type: 'string', required: true },
          instances: {
            type: 'array', required: true,
            items: {
              type: 'object', additionalProperties: false,
              properties: {
                instance_id: { type: 'string', required: true },
                base_url: { type: 'string', required: true },
                is_default: { type: 'boolean', required: true },
                output_source: { type: 'string', enum: ['directory', 'history'], required: true },
              },
            },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `ComfyUI instances (default: ${value.default_instance_id}):\n${value.instances.map((item) => `  ${item.instance_id}${item.is_default ? ' [default]' : ''}  ${item.base_url}  outputs: ${item.output_source}`).join('\n')}`,
      }],
    },
    async execute() {
      return {
        default_instance_id: registry.defaultInstanceId,
        instances: [...registry.instances.values()].map(({ id, client, config }) => ({
          instance_id: id,
          base_url: client.baseUrl,
          is_default: id === registry.defaultInstanceId,
          output_source: config.outputDir ? 'directory' : 'history',
        })),
      }
    },
  }))

  registerInstanceTool({
    name: 'comfyui_queue_get',
    description: 'Inspect the ComfyUI generation queue: the job currently running and the pending items, each with prompt_id and a node-class summary.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          running_count: { type: 'integer', required: true },
          pending_count: { type: 'integer', required: true },
          running: {
            type: 'array',
            items: { type: 'object', additionalProperties: true },
          },
          pending: {
            type: 'array',
            items: { type: 'object', additionalProperties: true },
          },
        },
      },
      render: (_args, value) => {
        const lines = [`ComfyUI queue: ${value.running_count} running, ${value.pending_count} pending`]
        for (const item of value.running) {
          lines.push(`  running  ${item.prompt_id}  ${JSON.stringify(item.classes ?? {})}`)
        }
        for (const item of value.pending) {
          lines.push(`  pending  ${item.prompt_id}  ${JSON.stringify(item.classes ?? {})}`)
        }
        return [{ type: 'text', text: lines.join('\n') }]
      },
    },
    isConcurrencySafe: () => true,
    async execute(_args, exec, instance) {
      const { client } = instance
      const queue = await client.queue({ signal: exec.signal })
      const running = Array.isArray(queue?.queue_running) ? queue.queue_running.map((item) => summarizeQueueItem(item, instance.id)) : []
      const pending = Array.isArray(queue?.queue_pending) ? queue.queue_pending.map((item) => summarizeQueueItem(item, instance.id)) : []
      return {
        running_count: running.length,
        pending_count: pending.length,
        running,
        pending,
      }
    },
  })

  registerInstanceTool({
    name: 'comfyui_interrupt',
    description: 'Interrupt the ComfyUI generation that is currently running. Pending items stay in the queue; use comfyui_queue_delete to remove them.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          interrupted: { type: 'boolean', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.interrupted ? 'ComfyUI: interrupted the running generation.' : 'ComfyUI: interrupt issued.' }],
    },
    async execute(_args, exec, instance) {
      const { client } = instance
      await client.interrupt({ signal: exec.signal })
      return { interrupted: true }
    },
  })

  registerInstanceTool({
    name: 'comfyui_queue_delete',
    description: 'Remove pending items from the ComfyUI queue: either clear all pending (clear=true) or delete specific prompt_ids. Does not interrupt the running job — use comfyui_interrupt for that.',
    parameters: {
      clear: { type: 'boolean', description: 'Clear all pending items (mutually exclusive with prompt_ids)' },
      prompt_ids: {
        type: 'array',
        items: { type: 'string' },
        description: 'Prompt ids of pending items to delete (mutually exclusive with clear)',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          cleared: { type: 'boolean' },
          deleted_count: { type: 'integer' },
          prompt_ids: { type: 'array', items: { type: 'string' } },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.cleared === true
          ? 'ComfyUI: cleared all pending queue items.'
          : `ComfyUI: removed ${value.deleted_count} pending item(s) from the queue.`,
      }],
    },
    async execute(args, exec, instance) {
      const { client } = instance
      const hasClear = args.clear === true
      const ids = args.prompt_ids ?? []
      if (hasClear && ids.length > 0) throw new Error('clear and prompt_ids are mutually exclusive')
      if (!hasClear && ids.length === 0) throw new Error('either clear=true or at least one prompt_id is required')
      await client.queueDelete({ clear: hasClear, promptIds: ids }, { signal: exec.signal })
      return { cleared: hasClear, deleted_count: ids.length, prompt_ids: ids }
    },
  })

  registerInstanceTool({
    name: 'comfyui_history_get',
    description: 'Query ComfyUI generation history. Omit prompt_id to list the most recent generations (max_items, default 20); pass prompt_id to inspect one generation, including its status and output files.',
    parameters: {
      prompt_id: { type: 'string', description: 'Specific prompt_id to inspect (optional)' },
      max_items: { type: 'number', description: 'How many recent generations to list (default 20, capped at 100)' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          count: { type: 'integer', required: true },
          entries: {
            type: 'array',
            items: { type: 'object', additionalProperties: true },
          },
        },
      },
      render: (_args, value) => {
        if (value.entries.length === 0) return [{ type: 'text', text: 'ComfyUI history: no matching entries.' }]
        const lines = [`ComfyUI history (${value.count} entr${value.count === 1 ? 'y' : 'ies'}):`]
        for (const entry of value.entries) {
          const state = entry.completed === true ? (entry.status_str ?? 'done') : 'pending'
          const files = (entry.outputs ?? []).flatMap((o) => o.files ?? []).map((f) => f.filename)
          lines.push(`  ${entry.prompt_id}  [${state}]${entry.error !== undefined ? ' ERROR' : ''}${files.length > 0 ? `  → ${files.slice(0, 4).join(', ')}${files.length > 4 ? ` +${files.length - 4} more` : ''}` : ''}`)
        }
        return [{ type: 'text', text: lines.join('\n') }]
      },
    },
    isConcurrencySafe: () => true,
    async execute(args, exec, instance) {
      const { client } = instance
      const maxItems = args.max_items === undefined ? 20 : Math.max(1, Math.min(Math.floor(args.max_items), 100))
      const res = await client.history({ promptId: args.prompt_id, maxItems }, { signal: exec.signal })
      const entries = []
      if (res !== undefined && res !== null && typeof res === 'object') {
        for (const [promptId, entry] of Object.entries(res)) {
          entries.push(summarizeHistoryEntry(promptId, entry, instance.id))
        }
      }
      if (args.prompt_id !== undefined && args.prompt_id !== '' && entries.length === 0) {
        entries.push({ instance_id: instance.id, prompt_id: args.prompt_id, present: false })
      }
      return { count: entries.length, entries }
    },
  })

  registerInstanceTool({
    name: 'comfyui_output_list',
    description: 'List ComfyUI-generated output files. source=history lists the most recent generations (server-agnostic); source=directory lists the configured outputDir (requires the outputDir config); source=auto uses directory when configured, history otherwise.',
    parameters: {
      source: {
        type: 'string',
        enum: ['auto', 'history', 'directory'],
        description: 'Where to list outputs from (default auto)',
      },
      limit: { type: 'number', description: 'Max entries (default 30, capped at 500)' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          source: { type: 'string', required: true },
          total: { type: 'integer', required: true },
          truncated: { type: 'boolean', required: true },
          files: {
            type: 'array',
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                instance_id: { type: 'string', required: true },
                filename: { type: 'string', required: true },
                subfolder: { type: 'string' },
                type: { type: 'string' },
                bytes: { type: 'integer' },
                modified_ms: { type: 'integer' },
              },
            },
          },
        },
      },
      render: (_args, value) => {
        if (value.files.length === 0) return [{ type: 'text', text: 'ComfyUI outputs: none found.' }]
        const lines = [`ComfyUI outputs (${value.source}, ${value.total} file${value.total === 1 ? '' : 's'}${value.truncated ? ', truncated' : ''}):`]
        for (const file of value.files) {
          const size = file.bytes === undefined ? '' : `  ${(file.bytes / 1024).toFixed(1)} KiB`
          lines.push(`  ${file.subfolder ? `${file.subfolder}/` : ''}${file.filename}${size}`)
        }
        return [{ type: 'text', text: lines.join('\n') }]
      },
    },
    isConcurrencySafe: () => true,
    async execute(args, exec, instance) {
      const { client, config } = instance
      const source = args.source ?? 'auto'
      const limit = args.limit === undefined ? 30 : Math.max(1, Math.min(Math.floor(args.limit), 500))
      const files = []

      if (source === 'directory' || (source === 'auto' && typeof config.outputDir === 'string' && config.outputDir !== '')) {
        const dir = config.outputDir
        if (!dir) throw new Error('directory listing requires outputDir for this instance; use source=history for remote outputs')
        let entries
        try {
          entries = await readdir(dir, { withFileTypes: true, recursive: true })
        } catch (error) {
          throw new Error(`cannot list outputDir ${dir}: ${error instanceof Error ? error.message : String(error)}`)
        }
        const stats = await Promise.all(entries
          .filter((entry) => entry.isFile())
          .map(async (entry) => {
            const full = join(entry.parentPath ?? entry.path, entry.name)
            const rel = relative(dir, full).replaceAll('\\', '/')
            const stat = await import('node:fs/promises').then((m) => m.stat(full))
            const split = rel.lastIndexOf('/')
            return {
              instance_id: instance.id,
              filename: rel.slice(split + 1),
              subfolder: split < 0 ? '' : rel.slice(0, split),
              type: 'output', bytes: stat.size, modified_ms: Math.floor(stat.mtimeMs),
            }
          }))
        stats.sort((a, b) => b.modified_ms - a.modified_ms)
        files.push(...stats.slice(0, limit))
        return { source: 'directory', total: stats.length, truncated: stats.length > limit, files }
      }

      const historyRes = await client.history({ maxItems: limit * 2 }, { signal: exec.signal })
      const seen = new Set()
      const collected = []
      if (historyRes !== undefined && historyRes !== null && typeof historyRes === 'object') {
        const summarized = Object.entries(historyRes).map(([id, entry]) => summarizeHistoryEntry(id, entry, instance.id))
        summarized.sort((a, b) => (b.started_at ?? 0) - (a.started_at ?? 0))
        for (const entry of summarized) {
          for (const nodeOut of entry.outputs) {
            for (const file of nodeOut.files) {
              const key = `${file.type}:${file.subfolder}:${file.filename}`
              if (seen.has(key)) continue
              seen.add(key)
              collected.push(file)
              if (collected.length >= limit) break
            }
            if (collected.length >= limit) break
          }
          if (collected.length >= limit) break
        }
      }
      files.push(...collected)
      return { source: 'history', total: files.length, truncated: false, files }
    },
  })

  registerInstanceTool({
    name: 'comfyui_output_get',
    description: 'Fetch one stored ComfyUI file (usually a generated image in the output dir) and return the image itself to the model when inline_image is true. filename is the file name from comfyui_output_list or history; subfolder/type must match that entry.',
    parameters: {
      filename: { type: 'string', required: true, description: 'File name as reported by comfyui_output_list or history' },
      subfolder: { type: 'string', description: 'Subfolder as reported by the listing (default empty)' },
      type: { type: 'string', enum: ['output', 'input', 'temp'], description: 'Storage type (default output)' },
      inline_image: { type: 'boolean', description: 'Inline the image into the result (default true)' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          filename: { type: 'string', required: true },
          subfolder: { type: 'string', required: true },
          type: { type: 'string', required: true },
          media_type: { type: 'string', required: true },
          bytes: { type: 'integer', required: true },
          image: IMAGE_VALUE_SCHEMA,
        },
      },
      render: (args, value) => {
        const header = `ComfyUI ${value.type} file ${value.filename} — ${value.media_type}, ${value.bytes} bytes`
        const blocks = [{ type: 'text', text: header }]
        if (value.image !== undefined) {
          const block = imageBlockFromValue(value.image)
          if (block !== undefined) blocks.push(block)
        }
        return blocks
      },
    },
    isConcurrencySafe: () => true,
    async execute(args, exec, instance) {
      const { client } = instance
      const type = args.type ?? 'output'
      const subfolder = args.subfolder ?? ''
      const { bytes, contentType } = await client.view(
        { filename: args.filename, subfolder, type },
        { signal: exec.signal },
      )
      let mediaType = imageMediaTypeForName(args.filename)
      if (mediaType === undefined) {
        const ct = contentType.split(';')[0].trim().toLowerCase()
        if (ct.startsWith('image/')) mediaType = ct
      }
      const value = {
        filename: args.filename,
        subfolder,
        type,
        media_type: mediaType ?? 'application/octet-stream',
        bytes: bytes.byteLength,
      }
      if (args.inline_image !== false && mediaType !== undefined) {
        const image = await saveImageValue(ctx, { data: bytes, mediaType, name: args.filename })
        value.image = image
      }
      return value
    },
  })

  registerInstanceTool({
    name: 'comfyui_models_list',
    description: 'List model files installed in ComfyUI. Without folder, probes the common folders and reports counts plus samples; with folder (e.g. "checkpoints", "loras", "vae"), returns the full file list of that folder.',
    parameters: {
      folder: { type: 'string', description: 'One model folder name (optional)' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          folders: {
            type: 'array',
            items: { type: 'object', additionalProperties: true },
          },
          folder: { type: 'string' },
          files: { type: 'array', items: { type: 'string' } },
          count: { type: 'integer' },
          truncated: { type: 'boolean' },
        },
      },
      render: (_args, value) => {
        if (value.folders !== undefined) {
          const lines = ['ComfyUI model folders:']
          for (const folder of value.folders) {
            if (folder.error !== undefined) {
              lines.push(`  ${folder.name}  (${folder.error})`)
            } else {
              const sample = folder.sample.length > 0 ? `  e.g. ${folder.sample.slice(0, 3).join(', ')}` : ''
              lines.push(`  ${folder.name}  ${folder.count} file(s)${sample}`)
            }
          }
          return [{ type: 'text', text: lines.join('\n') }]
        }
        const files = value.files ?? []
        const suffix = value.truncated === true ? ' (truncated)' : ''
        return [{
          type: 'text',
          text: `ComfyUI model folder ${value.folder}: ${value.count} file(s)${suffix}\n${files.join('\n')}`,
        }]
      },
    },
    isConcurrencySafe: () => true,
    async execute(args, exec, instance) {
      const { client } = instance
      if (args.folder !== undefined && args.folder.trim() !== '') {
        const folder = args.folder.trim()
        let files
        try {
          files = await client.modelsList(folder, { signal: exec.signal })
        } catch (error) {
          if (error instanceof ComfyHttpError && error.status === 404) {
            throw new Error(`ComfyUI has no /models/${folder} endpoint; check the folder name (e.g. "checkpoints", "loras", "vae")`)
          }
          throw error
        }
        const truncated = files.length > 500
        return { folder, files: files.slice(0, 500), count: files.length, truncated }
      }
      const results = await Promise.all(MODEL_FOLDERS.map(async (folder) => {
        try {
          const files = await client.modelsList(folder, { signal: exec.signal })
          return { name: folder, count: files.length, sample: files.slice(0, 20) }
        } catch (error) {
          if (exec.signal?.aborted) throw error
          return { name: folder, error: error instanceof Error ? error.message : String(error) }
        }
      }))
      return { folders: results }
    },
  })

  registerInstanceTool({
    name: 'comfyui_system_stats',
    description: 'ComfyUI system statistics: version info, RAM, and per-device VRAM (total/free). Useful before choosing generation settings or diagnosing OOM.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          system: { type: 'object', additionalProperties: true },
          devices: { type: 'array', items: { type: 'object', additionalProperties: true } },
        },
      },
      render: (_args, value) => {
        const lines = ['ComfyUI system stats:']
        if (value.system !== undefined) {
          lines.push(`  version ${value.system.comfyui_version ?? '?'}  python ${value.system.python_version ?? '?'}  torch ${value.system.torch_version ?? '?'}`)
          if (typeof value.system.ram_total === 'number') {
            const freeGb = (value.system.ram_free / 1024 ** 3).toFixed(1)
            const totalGb = (value.system.ram_total / 1024 ** 3).toFixed(1)
            lines.push(`  RAM ${freeGb} GiB free / ${totalGb} GiB`)
          }
        }
        for (const device of value.devices ?? []) {
          if (typeof device.vram_total === 'number') {
            const free = (device.vram_free / 1024 ** 3).toFixed(1)
            const total = (device.vram_total / 1024 ** 3).toFixed(1)
            lines.push(`  ${device.name ?? 'device'} (${device.type ?? '?'})  VRAM ${free} GiB free / ${total} GiB`)
          } else {
            lines.push(`  ${device.name ?? 'device'} (${device.type ?? '?'})`)
          }
        }
        return [{ type: 'text', text: lines.join('\n') }]
      },
    },
    isConcurrencySafe: () => true,
    async execute(_args, exec, instance) {
      const { client } = instance
      const res = await client.systemStats({ signal: exec.signal })
      return {
        system: res?.system ?? {},
        devices: Array.isArray(res?.devices) ? res.devices : [],
      }
    },
  })

  registerInstanceTool({
    name: 'comfyui_nodes_list',
    description: 'Query ComfyUI node classes and custom-node extensions. With node_class, returns that class definition (its inputs). With search, lists matching class names. Without arguments, lists enabled extensions and the total node-class count.',
    parameters: {
      search: { type: 'string', description: 'Substring filter over node class names (case-insensitive)' },
      node_class: { type: 'string', description: 'Exact node class name to inspect, e.g. "KSampler"' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          extensions: { type: 'array', items: { type: 'string' } },
          node_class_count: { type: 'integer' },
          matches: { type: 'array', items: { type: 'string' } },
          truncated: { type: 'boolean' },
          node: { type: 'object', additionalProperties: true },
        },
      },
      render: (_args, value) => {
        if (value.node !== undefined) {
          return [{ type: 'text', text: `ComfyUI node class definition (see canonical value for full inputs): ${Object.keys(value.node).join(', ')}` }]
        }
        const lines = []
        if (value.extensions !== undefined) {
          lines.push(`ComfyUI extensions (${value.extensions.length}): ${value.extensions.join(', ')}`)
        }
        if (value.node_class_count !== undefined) lines.push(`ComfyUI node classes: ${value.node_class_count}`)
        if (value.matches !== undefined) {
          lines.push(`Matches (${value.matches.length}${value.truncated === true ? ', truncated' : ''}): ${value.matches.join(', ')}`)
        }
        return [{ type: 'text', text: lines.length > 0 ? lines.join('\n') : 'ComfyUI nodes: no data.' }]
      },
    },
    isConcurrencySafe: () => true,
    async execute(args, exec, instance) {
      const { client } = instance
      if (args.node_class !== undefined && args.node_class.trim() !== '') {
        const res = await client.objectInfo(args.node_class.trim(), { signal: exec.signal })
        const node = res?.[args.node_class.trim()]
        if (node === undefined) throw new Error(`ComfyUI has no node class named "${args.node_class.trim()}"`)
        return { node }
      }
      const info = await cachedObjectInfo(instance, exec.signal)
      const classNames = Object.keys(info ?? {})
      const extensions = await client.extensions({ signal: exec.signal }).catch((error) => {
        if (exec.signal?.aborted) throw error
        return []
      })
      if (args.search !== undefined && args.search.trim() !== '') {
        const needle = args.search.trim().toLowerCase()
        const matches = classNames.filter((name) => name.toLowerCase().includes(needle)).sort()
        return {
          matches: matches.slice(0, 200),
          truncated: matches.length > 200,
          extensions: Array.isArray(extensions) ? extensions : [],
          node_class_count: classNames.length,
        }
      }
      return {
        extensions: Array.isArray(extensions) ? extensions : [],
        node_class_count: classNames.length,
      }
    },
  })

  registerInstanceTool({
    name: 'comfyui_upload_image',
    description: 'Upload a local image file into ComfyUI\'s input directory so it can be referenced by image-loading nodes (LoadImage). Returns the file name ComfyUI assigned, to be used in prompts.',
    parameters: {
      path: { type: 'string', required: true, description: 'Absolute image path contained by a configured allowedUploadRoots directory' },
      name: { type: 'string', description: 'Optional upload file name (default: basename of path)' },
      subfolder: { type: 'string', description: 'Optional input subfolder' },
      overwrite: { type: 'boolean', description: 'Overwrite an existing file with the same name (default false)' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          filename: { type: 'string', required: true },
          subfolder: { type: 'string', required: true },
          type: { type: 'string', required: true },
          source_name: { type: 'string', required: true },
          bytes: { type: 'integer', required: true },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `Uploaded ${value.source_name} → ComfyUI input: ${value.subfolder === '' ? '' : `${value.subfolder}/`}${value.filename} (${value.bytes} bytes)`,
      }],
    },
    async execute(args, exec, instance) {
      const { client, config } = instance
      return uploadLocalImage(client, args, config, exec.signal)
    },
  })

  registerInstanceTool({
    name: 'comfyui_generate',
    description: 'Submit an API-format workflow prompt to ComfyUI and optionally wait for the generation to finish. prompt is the graph object: node id → { class_type, inputs }. To generate on multiple servers simultaneously, submit wait=false to each instance_id before querying history. With wait=true (default), polls history until completion and inlines output images; on timeout returns prompt_id and instance_id for follow-up. Cancelling the wait does not interrupt the server job.',
    parameters: {
      prompt: {
        type: 'object',
        additionalProperties: true,
        required: true,
        description: 'API-format prompt graph: { node_id: { class_type, inputs } }',
      },
      wait: { type: 'boolean', description: 'Wait for completion (default true)' },
      timeout_ms: { type: 'number', description: 'Max wait in ms (default from plugin config, capped at 30 min)' },
      inline_images: { type: 'boolean', description: 'Inline output images into the result (default true)' },
      client_id: { type: 'string', description: 'Optional client id for tracking (auto-generated when omitted)' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          prompt_id: { type: 'string', required: true },
          submitted: { type: 'boolean', required: true },
          status: { type: 'string' },
          outputs: {
            type: 'array',
            items: { type: 'object', additionalProperties: true },
          },
          images: { type: 'array', items: IMAGE_VALUE_SCHEMA },
          inline_errors: { type: 'array', items: { type: 'string' } },
          error: { type: 'object', additionalProperties: true },
        },
      },
      render: (args, value) => {
        const blocks = []
        const header = [
          `ComfyUI generation submitted: prompt_id ${value.prompt_id}`,
          value.status === undefined ? '' : `  status: ${value.status}`,
        ].filter((line) => line !== '').join('\n')
        blocks.push({ type: 'text', text: header })
        if (value.error !== undefined) {
          blocks.push({ type: 'text', text: `  error: ${JSON.stringify(value.error)}` })
        }
        if (value.outputs !== undefined && value.outputs.length > 0) {
          const names = value.outputs.flatMap((o) => o.files ?? []).map((f) => f.filename)
          blocks.push({ type: 'text', text: `  outputs: ${names.join(', ')}` })
        }
        if (value.status === 'success') {
          for (const image of value.images ?? []) {
            const block = imageBlockFromValue(image)
            if (block !== undefined) blocks.push(block)
          }
        }
        if ((value.inline_errors ?? []).length > 0) {
          blocks.push({ type: 'text', text: `  inline warnings: ${value.inline_errors.join('; ')}` })
        }
        return blocks
      },
    },
    async execute(args, exec, instance) {
      const { client, config } = instance
      const prompt = args.prompt
      if (prompt === undefined || prompt === null || typeof prompt !== 'object' || Array.isArray(prompt)) {
        throw new Error('prompt must be an object mapping node ids to { class_type, inputs }')
      }
      const nodeIds = Object.keys(prompt)
      if (nodeIds.length === 0) throw new Error('prompt must contain at least one node')
      for (const id of nodeIds) {
        const node = prompt[id]
        if (node === null || typeof node !== 'object' || typeof node.class_type !== 'string') {
          throw new Error(`prompt node "${id}" must declare a class_type string`)
        }
      }
      const clientId = args.client_id ?? `dsh-comfyui-ctl-${randomUUID()}`
      const { promptId } = await client.submitPrompt(prompt, clientId, { signal: exec.signal })
      const wait = args.wait !== false
      if (!wait) return { prompt_id: promptId, submitted: true }

      const timeoutMs = Math.min(args.timeout_ms ?? config.generateTimeoutMs, 30 * 60_000)
      const result = await client.waitForCompletion(promptId, {
        pollMs: config.pollIntervalMs,
        timeoutMs,
        signal: exec.signal,
      })
      const base = { prompt_id: promptId, submitted: true }
      if (!result.completed) {
        return { ...base, status: 'timeout' }
      }
      const entry = summarizeHistoryEntry(promptId, result.entry, instance.id)
      if (entry.completed !== true || entry.status_str !== 'success') {
        return {
          ...base,
          status: entry.status_str ?? 'error',
          error: entry.error ?? { message: 'generation did not succeed' },
          outputs: entry.outputs,
        }
      }
      const outputs = entry.outputs
      const images = []
      const inlineErrors = []
      const maxInline = Math.max(0, Math.min(Math.floor(config.maxInlineImages), 8))
      if (args.inline_images !== false && maxInline > 0) {
        const fileQueue = []
        for (const nodeOut of outputs) {
          for (const file of nodeOut.files) {
            if (IMAGE_MEDIA_BY_EXT[extname(file.filename).toLowerCase()] !== undefined) {
              fileQueue.push(file)
            }
          }
        }
        let inlineCount = 0
        for (const file of fileQueue) {
          if (inlineCount >= maxInline) break
          try {
            const { bytes } = await client.view(
              { filename: file.filename, subfolder: file.subfolder, type: file.type },
              { signal: exec.signal },
            )
            const mediaType = imageMediaTypeForName(file.filename)
            const image = await saveImageValue(ctx, { data: bytes, mediaType, name: file.filename })
            images.push(image)
            inlineCount += 1
          } catch (error) {
            if (exec.signal?.aborted) throw error
            inlineErrors.push(error instanceof Error ? error.message : String(error))
          }
        }
      }
      return {
        ...base,
        status: 'success',
        outputs,
        images,
        ...(inlineErrors.length === 0 ? {} : { inline_errors: inlineErrors }),
      }
    },
  })
  return disposeAll
  }, 'dsh-comfyui-ctl: tools')
}
