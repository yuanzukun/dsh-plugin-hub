import type { KeyboardEvent as ReactKeyboardEvent, ReactElement } from 'react'
import { useEffect, useId, useRef, useState } from 'react'
import { IconChevronDownOutlineMedium } from '@deepseek-ai/dsh-client-ui-primitives'
import { TTS_VOICE_DESIGN_ASSET_ROUTE, TTS_VOICE_DESIGN_PRESETS } from '../../../shared.js'
import { hostRoute } from '../../host-route.js'

export const CUSTOM_VOICE_DESIGN_OPTION = '__custom__'

export function isPresetVoiceDesignPrompt(value: string): boolean {
  return TTS_VOICE_DESIGN_PRESETS.some((item) => item.prompt === value)
}

type VoiceDesignPreset = typeof TTS_VOICE_DESIGN_PRESETS[number]
const MINIMAL_VOICE_DESIGN_PRESET_IDS = new Set(['energetic-girl', 'liang-wenfeng', 'young-man', 'gentle-girlfriend'])

function VoicePresetAvatar({ preset, minimal }: { preset: VoiceDesignPreset, minimal: boolean }): ReactElement | null {
  if (minimal) return null
  return <img
    className="xmimo-tts-builtin-voice-avatar"
    src={hostRoute(`${TTS_VOICE_DESIGN_ASSET_ROUTE}/${preset.id}.webp`)}
    alt=""
    width={40}
    height={40}
    loading="lazy"
    aria-hidden="true"
  />
}

function CustomVoiceAvatar(): ReactElement {
  return <span className="xmimo-tts-builtin-voice-avatar xmimo-tts-custom-voice-avatar" aria-hidden="true">
    <svg viewBox="0 0 40 40" focusable="false">
      <circle cx="20" cy="14" r="6" />
      <path d="M9.5 31.5c1.7-6.2 5.2-9.3 10.5-9.3s8.8 3.1 10.5 9.3" />
      <path d="M31 8v8M27 12h8" />
    </svg>
  </span>
}

function VoicePresetCheck(): ReactElement { return <svg className="xmimo-tts-builtin-voice-check" viewBox="0 0 14 14" aria-hidden="true"><circle cx="7" cy="7" r="7" /><path d="m3.5 7 2.1 2.1 4.9-4.7" /></svg> }

interface VoiceDesignPresetPickerProps {
  value: string
  disabled: boolean
  label: string
  customLabel: string
  customSummary: string
  minimal?: boolean
  onChange: (value: string) => void
}

export function VoiceDesignPresetPicker({ value, disabled, label, customLabel, customSummary, minimal = false, onChange }: VoiceDesignPresetPickerProps): ReactElement {
  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement | null>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const optionRefs = useRef<Array<HTMLButtonElement | null>>([])
  const listboxId = useId()
  const visiblePresets = minimal
    ? TTS_VOICE_DESIGN_PRESETS.filter((preset) => MINIMAL_VOICE_DESIGN_PRESET_IDS.has(preset.id))
    : TTS_VOICE_DESIGN_PRESETS
  const selectedPresetIndex = visiblePresets.findIndex((item) => item.prompt === value)
  const selectedPreset = selectedPresetIndex < 0 ? undefined : visiblePresets[selectedPresetIndex]
  const selectedOptionIndex = selectedPresetIndex + (minimal ? 0 : 1)
  const optionCount = visiblePresets.length + (minimal ? 0 : 1)

  useEffect(() => {
    if (minimal || !open) return
    const closeOnOutsidePointer = (event: PointerEvent): void => {
      if (event.target instanceof Node && !rootRef.current?.contains(event.target)) setOpen(false)
    }
    document.addEventListener('pointerdown', closeOnOutsidePointer)
    return () => document.removeEventListener('pointerdown', closeOnOutsidePointer)
  }, [minimal, open])

  useEffect(() => {
    if (!minimal && disabled) setOpen(false)
  }, [disabled, minimal])

  const focusOption = (index: number): void => {
    const normalized = (index + optionCount) % optionCount
    requestAnimationFrame(() => optionRefs.current[normalized]?.focus())
  }

  const openAndFocus = (index: number): void => {
    setOpen(true)
    focusOption(index)
  }

  const choose = (next: string): void => {
    onChange(next)
    if (minimal) return
    setOpen(false)
    requestAnimationFrame(() => triggerRef.current?.focus())
  }

  const handleTriggerKeyDown = (event: ReactKeyboardEvent<HTMLButtonElement>): void => {
    if (event.key === 'ArrowDown') {
      event.preventDefault()
      openAndFocus(selectedOptionIndex)
    } else if (event.key === 'ArrowUp') {
      event.preventDefault()
      openAndFocus(selectedOptionIndex === 0 ? optionCount - 1 : selectedOptionIndex)
    } else if (event.key === 'Home') {
      event.preventDefault()
      openAndFocus(0)
    } else if (event.key === 'End') {
      event.preventDefault()
      openAndFocus(optionCount - 1)
    }
  }

  const handleOptionKeyDown = (event: ReactKeyboardEvent<HTMLButtonElement>, index: number): void => {
    if (event.key === 'ArrowDown') {
      event.preventDefault()
      focusOption(index + 1)
    } else if (event.key === 'ArrowUp') {
      event.preventDefault()
      focusOption(index - 1)
    } else if (event.key === 'Home') {
      event.preventDefault()
      focusOption(0)
    } else if (event.key === 'End') {
      event.preventDefault()
      focusOption(optionCount - 1)
    } else if (event.key === 'Escape') {
      event.preventDefault()
      setOpen(false)
      triggerRef.current?.focus()
    } else if (event.key === 'Tab') {
      setOpen(false)
    }
  }

  return <div className="xmimo-tts-voice-picker xmimo-tts-builtin-voice-picker" ref={rootRef}>
    {!minimal ? <button
      ref={triggerRef}
      type="button"
      className="xmimo-tts-voice-picker-trigger"
      disabled={disabled}
      aria-label={label}
      aria-haspopup="listbox"
      aria-expanded={open}
      aria-controls={open ? listboxId : undefined}
      onClick={() => { setOpen((current) => !current) }}
      onKeyDown={handleTriggerKeyDown}
    >
      {minimal ? null : selectedPreset === undefined ? <CustomVoiceAvatar /> : <VoicePresetAvatar preset={selectedPreset} minimal={minimal} />}
      <span className="xmimo-tts-voice-option-copy">
        <strong>{selectedPreset?.label ?? customLabel}</strong>
        <small>{selectedPreset?.summary ?? customSummary}</small>
      </span>
      {minimal
        ? <span className="xmimo-tts-voice-picker-text-caret" aria-hidden="true">⌄</span>
        : <IconChevronDownOutlineMedium className={open ? 'xmimo-tts-voice-picker-chevron xmimo-tts-voice-picker-chevron-open' : 'xmimo-tts-voice-picker-chevron'} size={14} />}
    </button> : null}
    {(minimal || open) ? <div id={listboxId} className="xmimo-tts-voice-picker-menu xmimo-tts-builtin-voice-menu" role="listbox" aria-label={label}>
      {!minimal ? <button
        ref={(node) => { optionRefs.current[0] = node }}
        type="button"
        role="option"
        aria-selected={selectedPreset === undefined}
        disabled={disabled}
        className={selectedPreset === undefined ? 'xmimo-tts-builtin-voice-option xmimo-tts-builtin-voice-option-selected xmimo-tts-builtin-voice-option-custom' : 'xmimo-tts-builtin-voice-option xmimo-tts-builtin-voice-option-custom'}
        onClick={() => { choose(CUSTOM_VOICE_DESIGN_OPTION) }}
        onKeyDown={(event) => { handleOptionKeyDown(event, 0) }}
      >
        <CustomVoiceAvatar />
        <span className="xmimo-tts-voice-option-copy"><strong>{customLabel}</strong><small>{customSummary}</small></span>
        {selectedPreset === undefined ? <VoicePresetCheck /> : null}
      </button> : null}
      {visiblePresets.map((preset, index) => <button
        key={preset.id}
        ref={(node) => { optionRefs.current[index + (minimal ? 0 : 1)] = node }}
        type="button"
        role="option"
        aria-selected={selectedPreset?.id === preset.id}
        disabled={disabled}
        className={selectedPreset?.id === preset.id ? 'xmimo-tts-builtin-voice-option xmimo-tts-builtin-voice-option-selected' : 'xmimo-tts-builtin-voice-option'}
        onClick={() => { choose(preset.prompt) }}
        onKeyDown={(event) => { handleOptionKeyDown(event, index + (minimal ? 0 : 1)) }}
      >
        <VoicePresetAvatar preset={preset} minimal={minimal} />
        <span className="xmimo-tts-voice-option-copy"><strong>{preset.label}</strong><small>{preset.summary}</small></span>
        {selectedPreset?.id === preset.id ? <VoicePresetCheck /> : null}
      </button>)}
    </div> : null}
  </div>
}
