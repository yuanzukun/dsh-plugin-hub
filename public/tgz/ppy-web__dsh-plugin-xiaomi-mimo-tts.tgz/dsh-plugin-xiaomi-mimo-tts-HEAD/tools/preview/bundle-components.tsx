import { useState } from 'react'
import pluginIcon from '../../assets/plugin-icons/avatar.webp'
import whaleGirlIcon from '../../assets/plugin-icons/preset.webp'

type PreviewLocale = 'zh' | 'en'

const COPY = {
  zh: {
    heading: '包含的组件',
    count: (total: number, running: number) => `共 ${total} 个 · ${running} 运行中`,
    running: '运行中',
    stopped: '已关闭',
    toggle: (name: string) => `切换${name}组件`,
    ttsTitle: 'MiMo & Seed TTS',
    ttsDescription: '为 DSH 添加 Xiaomi MiMo 与豆包语音朗读，支持豆包标准合成 2.0、声音复刻 2.0 和流式播放，并提供浏览器本地语音兜底和可选 UI 音效。',
    agentTitle: '鲸鱼娘 Agent 预设',
    agentDescription: '白饭续航、机灵嘴硬，会一本正经接梗，也会温柔陪伴和可靠办事。',
  },
  en: {
    heading: 'Included components',
    count: (total: number, running: number) => `${total} total · ${running} running`,
    running: 'Running',
    stopped: 'Disabled',
    toggle: (name: string) => `Toggle ${name} component`,
    ttsTitle: 'MiMo & Seed TTS',
    ttsDescription: 'Xiaomi MiMo and Doubao read-aloud for DSH, with Doubao Standard Synthesis 2.0, Voice Cloning 2.0, streaming playback, browser speech fallback, and optional UI sounds.',
    agentTitle: 'Whale Girl Agent preset',
    agentDescription: 'A rice-powered whale maid with deadpan wit, a soft heart, and reliable practical help.',
  },
} as const

export function BundleComponents({ locale }: { locale: PreviewLocale }) {
  const copy = COPY[locale]
  const [ttsEnabled, setTtsEnabled] = useState(true)
  const [agentEnabled, setAgentEnabled] = useState(false)
  const components = [
    { id: 'xiaomi-mimo-tts', icon: pluginIcon, title: copy.ttsTitle, description: copy.ttsDescription, module: 'dsh-xiaomi-tts', enabled: ttsEnabled, setEnabled: setTtsEnabled },
    { id: 'preset-whale-girl', icon: whaleGirlIcon, title: copy.agentTitle, description: copy.agentDescription, module: 'dsh-xiaomi-tts/whale-girl', enabled: agentEnabled, setEnabled: setAgentEnabled },
  ]

  return <section className="preview-bundle" aria-label={copy.heading}>
    <header className="preview-bundle-heading">
      <h2>{copy.heading}</h2>
      <span>{copy.count(components.length, components.filter((item) => item.enabled).length)}</span>
    </header>
    <ul className="preview-bundle-list">
      {components.map((component) => <li className="preview-bundle-item" key={component.id}>
        <img src={component.icon} alt="" aria-hidden="true" />
        <div className="preview-bundle-copy">
          <strong>{component.title}</strong>
          <p>{component.description}</p>
          <code>{component.id}</code>
          <code>{component.module}</code>
        </div>
        <span className={`preview-bundle-status${component.enabled ? ' preview-bundle-status-running' : ''}`}>
          {component.enabled ? copy.running : copy.stopped}
        </span>
        <label className="preview-bundle-switch">
          <input
            type="checkbox"
            role="switch"
            checked={component.enabled}
            aria-label={copy.toggle(component.title)}
            onChange={(event) => { component.setEnabled(event.target.checked) }}
          />
          <span aria-hidden="true" />
        </label>
      </li>)}
    </ul>
  </section>
}
