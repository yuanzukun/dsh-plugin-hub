# DSH 数学建模团队插件包

> ## 🎉 预祝 2026 数模国赛顺利！
>
> 愿所有参赛的同学：**题意读得准，模型站得住，代码一次跑通，图表一眼看懂，论文写完还有时间睡一觉。**
>
> 发题后别慌，记住七件事：先拆题 → 先跑最小可运行 → 主动攻击自己的模型 → 图一定审 → 交稿前逐页看渲染 PDF → 审查用两个不同模型各审一遍 → 三人三文件夹只提交自己的。
>
> **数模人，加油！** 🚀

> 🌍 **English**: [README_en.md](README_en.md) — bilingual docs: [team-collaboration.md](docs/team-collaboration.md) · [vision-subagent.md](docs/vision-subagent.md) · [attribution.md](docs/attribution.md) · [sample-run.md](docs/sample-run.md)

面向 **DeepSeek Harness** 的团队化数学建模工作流插件包。把参考成熟数学建模 Skill 仓库的方法论，整理成 **2 套可直接安装的 Agent 预设（preset）**，配合团队 **Gitee/GitHub 多文件夹协同**，实现多人在各自独立工作区互不干扰地协作完成数学建模竞赛题。

本仓库挂载于 GitHub Topic：**`dsh-plugin`**。

> ⚠️ **DSH 0.2.0 起，本仓库以「bundle 插件包」形式分发。** 0.2.0 的运行时**不再读取** `$DSH_HOME/.agent-presets/`（旧目录已无任何代码读取），预设必须由插件包声明。安装方式见 [安装](#安装)。

## 这是什么

在 DeepSeek Harness 中，一个Agent 预设（preset）就是一套岗位配置：包含 persona（角色职责）、可用的工具集、以及随预设安装的 **Skills**（岗位能力文档）。每个会话选择某个预设，就获得了该岗位的全部能力。

本包提供 **2 套岗位预设**：

| 预设 ID | 岗位 | 面向 | 核心能力 |
|---|---|---|---|
| `model-code` | 建模+编程 Agent | 2 名建模编程成员（共用） | 题目分析与建模、Python/MATLAB 求解、结果与图表产出、复现清单；含建模手/编程手/算法资料/可视化文档 |
| `paper` | 论文 Agent | 1 名论文成员 | 论文撰写（Word/LaTeX）、证据检索核验、独立评审质检门禁；含论文手/获奖评审/证据检索文档 |

### 每套预设包含
- `cordis.patch.yml` — **预设声明**（`@deepseek-ai/dsh-agent-preset` 行）：`persona` / 工具集 / skill 挂载，逐行见该文件的注释
- `package.json` — bundle 声明（`dsh.bundle.patch` 指向 `cordis.patch.yml`）
- `presets/<id>/skills/<name>/SKILL.md` — 岗位主技能（职责、流程、质量门禁、协同规则）
- `presets/<id>/skills/<name>/references/` — 随预设安装的方法论文档（按需加载）

### 关键特性
- **团队协同**：预设内置"Gitee 仓库三独立文件夹"协同协议（`member-a/` `member-b/` `member-c/`），各成员只提交自己文件夹，互不干扰
- **质量门禁**：建模终检 M1 / 最小可运行 P1 / **稳健性攻击终检 M2** / 编程终检 P2 / 证据大纲 W1 / 论文终检 W2
- **M2 稳健性攻击终检**：对每个核心模型做系统性"攻击"——提出模型 → 攻击模型 → 换方法验证 → 加误差 → 样本外检验 → 写清适用边界，防止"模型怀疑不足"，把经不起追问的结论拦在论文之外（含 2023 C 题真实攻击案例）
- **识图子代理（强制图审门禁）**：当主模型不支持图像输入时，用 `workflow` 派生一个**当前环境可用的视觉模型**子代理审查图表（自动探测 `inputModalities` 含 `image` 的模型，本环境已验证 `kimi-coding/kimi-for-coding`，但不硬编码模型名）。**所有正式图在 P2/W2 前必须逐张经识图审核 PASS 并记录在案**；FAIL 走「修改 → 重审」复验闭环直至 PASS——未走图审的图不能通过终检门禁
- **独立模型审查（双模型各审一遍）**：**Kimi K3-256K + DeepSeek V4.1 Flash** 两个模型各独立审一遍，交叉覆盖盲区——事实性/一致性/完备性/**模型攻击**/引用核验，编造数据当场拦截

## 模型分工方案

本方案按**能力互补**分工，**不指定具体模型**——请按你环境中实际可用的模型，依据下表标准配置（模型名不要硬编码）：

| 角色 | 能力要求 | 怎么选 |
|---|---|---|
| **主模型** | 世界知识广、判断敏锐、综合推理强 | 选你环境里**知识面/推理最强**的模型（题目理解、建模分析、论文写作、知识判断） |
| **编程** | 代码/工程能力强 | 选**编程能力最强**的模型（可与主模型不同），用 `workflow` 派它写代码、跑结果、编译转换 |
| **审查（≥2 个不同模型各审一遍）** | 与产出方不同厂商 / 不同能力侧重 | **至少挑两个不同模型各独立审一遍**，交叉覆盖盲区（一个偏知识/逻辑/口径，一个偏代码/复现/实现） |
| **识图** | 支持图像输入、成本可控 | 优先**经济型视觉模型**（高频轻量任务，成本优先） |

**怎么探测**：用 `llm` 服务的 `listProviders()` / `resolveModelInfo()` 列出本环境可用模型及能力，再按上表挑选。某角色找不到合适模型时，如实标注受限。

> **本环境已验证示例**（仅供参考，非强制）：主模型 Kimi K3 · 编程 DeepSeek V4.1 Flash · 审查 Kimi K3-256K + DeepSeek V4.1 Flash 双模型各审一遍 · 识图 DeepSeek V4.1 Flash（`deepseek-official/deepseek-flash`）或 Kimi K2.7 Code（`kimi-coding/kimi-for-coding`）。**可用任何满足上表能力的模型替代**。

## 独立模型审查（多个不同模型各审一遍，对抗式评审）

**为什么需要**：同一个模型既生产又验收，天然缺乏批判距离，编造的数值、口径不自洽、前后矛盾自己发现不了。用**多个不同厂商、不同能力侧重**的模型各审一遍，交叉覆盖彼此盲区。

**怎么做**：用 `workflow` 的 `agent(prompt, { provider, model })` 派发**两次**审查子代理，分别指定 **Kimi K3-256K** 与 **DeepSeek V4.1 Flash**；两份结论都要记录（各自 PASS/FAIL + 问题清单），任一方发现的问题都要按复验闭环修复并复审。

**审查维度**（两次都查）：
- **事实性**：headline 数值能否溯源到 results/ 与图表？有无编造？
- **一致性**：口径/符号/结论在摘要、正文、表、图之间是否自洽？
- **完备性**：是否覆盖全部子问题？
- **模型攻击**：针对每个核心模型质疑假设（工具变量成立性/关键参数取值/基准依赖/缺货截断/份额稳定），核对论文是否给出适用边界
- **引用核验**：参考文献真实存在且被正确引用？

**拦截实例（2023 C 题跑题实录）**：论文初稿出现编造数值"0.78"，独立审查发现该数在数据中不存在 → 拦截删除，改为诚实区间 (0.7,0.8)。

**与 M2 的关系**：M2（建模岗）在产出侧主动攻击模型；独立审查（论文岗）在交付侧用双模型复检论文——两道防线，一前一后。

## 可复用全局 skill

仓库自带一个可做**全局 skill** 安装的目录（放到 DSH 共享用户 skill 根，任何预设都能发现）：

- `skills/vision-subagent/` — 识图子代理（视觉质检）。安装：
  ```bash
  # 复制到 DSH 共享用户 skill 根，任意预设会话自动发现
  cp -R skills/vision-subagent ~/.agents/skills/vision-subagent
  # Windows:
  # Copy-Item -Recurse .\skills\vision-subagent "$env:USERPROFILE\.agents\skills\vision-subagent"
  ```
  DSH 的 `dsh-skill-filesystem` 会扫描 `~/.agents/skills/`、`~/.dsh/skills/`、项目 `.dsh/skills` 等共享根，放好后即被自动发现，无需改配置。

## 安装

### 前提
- DeepSeek Harness **0.2.0 及以上**（0.2.0 起预设只能由插件包声明）
- 把本仓库放在一个**长期存在**的本地路径：桌面端以 `link:` 方式引用本目录，**移动或删除目录会让预设失效**
- 安装会执行插件代码并要求 Full access / 审批

### 方式一：Web 插件页（推荐）
桌面端 → **设置 → 插件 → 安装本地 bundle**，选择**本仓库根目录**（含 `package.json` 的那一层）。

### 方式二：桌面端内置命令
桌面端 profile 只能由桌面端自带的 CLI 管理（全局 npm 装的 `dsh` 会拒绝）。`plugin` 子命令会把剩余参数转发给 profile 目录里的 pnpm，因此 `add` / `remove` / `list` 都可用：
```powershell
$env:ELECTRON_RUN_AS_NODE='1'
& 'F:\dsh\DeepSeek Harness.exe' --expose-internals `
  'F:\dsh\resources\app.asar\dsh\node_modules\@deepseek-ai\dsh-desktop-host\lib\cli.js' `
  plugin --profile desktop add "link:<本仓库绝对路径>"
# 列出已装插件
& 'F:\dsh\DeepSeek Harness.exe' --expose-internals `
  'F:\dsh\resources\app.asar\dsh\node_modules\@deepseek-ai\dsh-desktop-host\lib\cli.js' `
  plugin --profile desktop list
```

### 方式三：会话内 `plugin_manager`
让任意会话调用 `plugin_manager`，`action: install_bundle`，`target` 设为**本仓库绝对路径**。它会自行完成依赖安装与 bundle 选择。

安装成功后 profile 的 `package.json` 会多出一条依赖与一项 bundle；本仓库是以 `link:`（符号链接）方式挂载的，改完仓库内容**重启桌面端**即生效，无需重新安装。

### 验证安装
**重启桌面端**（关窗口只是隐藏到托盘，需从托盘菜单「退出」或结束所有 `DeepSeek Harness.exe`），新开会话时预设选择器中应出现 **`建模编程 Agent`** 与 **`论文 Agent`**；插件页中 `preset-model-code` / `preset-paper` 两行应为已激活，而不是「已损坏」。任一版本更新后，用 `cordis_inspect_query` 的 `Config.listConfigs` 按 `preset-<id>` 的 entry id 可核对声明解析到的包目录与配置。

### 从旧版（0.1.x / `.agent-presets`）迁移
- 0.1.x 的 `~/.dsh/.agent-presets/<id>/{preset.yml,agent.cordis.yml,skills/}` 目录在 0.2.0 **不再被读取**，可以删除（确认新预设可用后再删）。
- 旧 `agent.cordis.yml` **不要照抄**：0.1.x 的 `@deepseek-ai/dsh-workflow-worker-thread` 行在 0.2.0 已由 `@deepseek-ai/dsh-workflow-ptc` 取代，直接照抄会在激活时报错。
- 本仓库的 `cordis.patch.yml` 已按 0.2.0 内置 `cordis` 预设重建基线，并保留原有定制：两段岗位 persona、`tool-web.fetch: false`（只搜不抓）、`tool-todo.allowParallelInProgress: true`；skill 目录从**已安装的包**解析，不再指向预设目录。

## 快速开始（团队协同模式）

1. 在 Gitee/GitHub 建一个空私有仓库（团队共享）
2. 首次 clone 后按 `docs/团队协同.md` 初始化 `member-a/ member-b/ member-c/` 三文件夹基线
3. 2 名成员开 `model-code` 预设会话在各自独立工作区 clone，分别产出建模+编程交付物到自己的 `member-*` 文件夹并 push
4. 论文成员开 `paper` 预设会话，`git pull` 拉取 A、B 交付物，在 `member-c/` 撰写论文并 push
5. 全程只提交自己那个 `member-*` 文件夹，互不干扰

各岗位的开工口令模板见 `docs/团队协同.md`。

## 完整工作流（两套预设 + 团队协同）

### 流程图（细化版）

```mermaid
flowchart LR
    subgraph team["团队（3 人 · 3 独立工作区）"]
        direction TB
        A["成员 A（model-code 预设）"]
        B["成员 B（model-code 预设）"]
        C["成员 C（paper 预设）"]
    end

    subgraph mc["📐 建模编程岗（model-code）"]
        direction TB
        S1["① 建模阶段<br/>读题 → 检查附件 → 拆子问题<br/>→ 选模型 → 设计求解与验证方案"]
        G1["M1 建模终检<br/>题目要求有无遗漏？<br/>子问题覆盖？口径正确？"]
        D1["交付：题目分析报告.md<br/>术语表格.md"]
        S2["② 编程起步<br/>数据准备（清洗/退货/异常）<br/>→ 最小可运行代码 → 真实运行"]
        G2["P1 最小可运行<br/>能出真实结果？"]
        S3["③ M2 稳健性攻击终检<br/>识别攻击点 → 换法验证 → 加区间<br/>→ 样本外检验 → 写适用边界"]
        G3["M2 通过标准<br/>攻击清单/换法/区间/样本外<br/>/适用边界 五样齐备"]
        S4["④ 全量计算与出图<br/>三类图（raw/process/result）<br/>每类≥3 张覆盖全部子问题"]
        S5["⑤ 图表质检<br/>识图子代理逐张审核（强制）"]
        G4["P2 编程终检<br/>真实结果 · 复现清单完整<br/>未走图审的正式图不过"]
        D2["交付：results/ 结果表+复现清单.json<br/>figures/ 三类图"]
        S1 --> G1 --> D1 --> S2 --> G2 --> S3 --> G3 --> S4 --> S5 --> G4 --> D2
    end

    subgraph pp["📄 论文岗（paper）"]
        direction TB
        T1["① 拉取 A/B 交付物<br/>git pull member-a/b"]
        T2["② 建立证据支撑<br/>读分析报告/results/figures<br/>逐子问题记录证据清单 + 登记缺口"]
        T3["③ 证据检索与核验<br/>多源检索 → 综合去重 → 交叉核验引用"]
        T4["④ W1 证据大纲<br/>论文结构 × 证据映射<br/>+ 模型辩护清单（对应 M2）"]
        G5["W1 通过标准<br/>每章有证据 · 无孤立结论<br/>模型辩护清单齐备"]
        T5["⑤ 撰写论文<br/>Word（OMML）/ LaTeX（可选）<br/>官方模板适配 → 渲染 PDF"]
        T6["⑥ 图表质检<br/>识图子代理逐张审核（强制）"]
        T6b["⑦ 渲染 PDF 逐页审查（强制）<br/>每页转图 → 识图子代理逐页审<br/>表格超限/异常字体/过小字体/排版/空白页"]
        T7["⑧ 独立审查<br/>双模型各审一遍<br/>（K3-256K + V4.1 Flash）"]
        G6["W2 论文终检<br/>公式↔结果一致 · 无空表空图<br/>编号引用连续 · 适用边界已写清<br/>图审记录在案 · 渲染审查PASS · 独立评审 PASS"]
        D3["交付：完整论文.docx/pdf<br/>评审记录.md · 代码附录 · AI使用声明"]
        T1 --> T2 --> T3 --> T4 --> G5 --> T5 --> T6 --> T6b --> T7 --> G6 --> D3
    end

    D2 -->|"git add member-a/b<br/>commit · push"| REPO["Git 仓库<br/>member-a / member-b / member-c"]
    REPO -->|"git pull（只读他人文件夹）"| T1
    V1["🖼️ 识图子代理（全局 skill）<br/>探测视觉模型 → read_image<br/>FAIL → 修改 → 重审 → PASS"]
    V2["⚔️ 独立审查模型<br/>事实性/一致性/完备性<br/>模型攻击/引用核验"]
    V1 -.-> S5
    V1 -.-> T6
    V2 -.-> T7
```

### 门禁检查项明细

| 门禁 | 所属岗 | 检查什么 |
|---|---|---|
| **M1 建模终检** | 建模编程 | 题目要求是否全部有对应模型/方案；子问题有无遗漏；约束与评价口径是否理解正确 |
| **P1 最小可运行** | 建模编程 | 全量计算前先跑通最小可运行代码，确认能出真实结果 |
| **M2 稳健性攻击终检** | 建模编程 | 核心模型经受系统性攻击：识别威胁（3-5 个攻击点，如工具变量成立性/弹性取值/基准依赖/缺货截断/份额稳定）→ 换方法验证 → 加不确定区间 → 样本外检验 → 写清适用边界；攻击清单五样齐备才过 |
| **P2 编程终检** | 建模编程 | 所有子问题有真实运行结果与图表；数字有源；复现清单完整；**全部正式图经识图审核 PASS 且记录在案** |
| **W1 证据大纲** | 论文 | 论文结构 × 证据（图/表/结论）映射；无孤立结论；**含模型辩护清单**（对应 M2 攻击结果） |
| **W2 论文终检** | 论文 | 公式↔结果一致；无空表空图；图表覆盖全部子问题；编号引用连续；参考文献双向对应；模型适用边界已写清；**全部配图经识图审核 PASS 且记录在案**；**渲染 PDF 逐页审查 PASS 且记录在案**（表格超限/异常字体/过小字体/排版/空白页）；独立评审结果并入 |

### 强制图审 / 渲染审查 / 独立审查（贯穿全局）

- **图表质检（强制图审门禁）**：**优先用主模型直接 `read_image` 读图**（若其支持图像）；主模型不支持图像时，自动探测 `inputModalities` 含 `image` 的视觉模型（如 DeepSeek V4.1 Flash、`kimi-coding/kimi-for-coding`，不硬编码），用 `workflow` 派生视觉子代理逐张审核正式图（标题/坐标轴/图例/数据/空白遮挡/是否支撑结论）。**FAIL → 按缺陷修改 → 重审，循环直至 PASS**；每次"FAIL 原因 → 修改动作 → 重审结果"记录在案。**P2 和 W2 都强制：未走图审的图不能通过终检门禁。**
- **渲染 PDF 逐页审查（强制）**：成稿 PDF 后，把每一页渲染成图片（pdftoppm/PyMuPDF，300 DPI），用识图子代理**逐页**审查——表格超限/溢出/截断、异常字体（乱码/缺字）、过小字体不可读、排版不规范（重叠/错位/孤行孤页）、空白页/重复页、页眉页脚异常、图片模糊裁切、分页不合理。FAIL → 修正排版 → 重新渲染 → 重新逐页审，直至全部 PASS；记录留痕。**W2 强制：未做渲染逐页审查的论文不通过。**（更多检查项见 `自审框架.md`、`LaTeX格式规范.md`）
- **独立模型审查（≥2 个不同模型各审一遍）**：挑两个与产出方不同、能力侧重不同的模型各独立审一遍做对抗式评审——事实性（数值可溯源/无编造）、一致性（口径符号自洽）、完备性（子问题覆盖）、**模型攻击**（质疑工具变量成立性/参数取值/基准依赖/缺货截断/份额稳定）、引用核验（真实存在且引用正确）。W2 前必须执行，编造数据当场拦截。

### 团队协同要点

- **3 个独立工作区 + 1 个 Git 仓库 + 3 个文件夹**（member-a/b/c），三人各提交自己的文件夹，互不干扰
- 交付物契约：建模编程岗 6 件（分析报告/术语表/脚本/results/figures/复现清单）；论文岗 4 件（证据大纲/论文/评审记录/AI声明）
- 有界迭代：单轮评审最多 2 轮修复；预算耗尽输出决策备忘，绝不无限打磨

## 文档

- [团队协同说明](docs/团队协同.md) — 三文件夹协同协议、交接契约、各岗位开工口令
- [识图子代理](docs/识图子代理.md) — 主模型不读图时的视觉审查方案
- [方法论来源](docs/方法论来源.md) — 两套预设吸收的参考仓库内容清单
- [示例题目全流程跑通记录](docs/示例题目全流程跑通记录.md) — 用 2023 国赛 C 题真实跑通「建模→论文→评审」完整链路的验证记录
- [模型能力配置指南](docs/模型能力配置.md) — 模型能否读图、子代理白名单、常见报错对照（含 V4.1 Flash 图像能力声明修复实录）

**English docs**: [team-collaboration.md](docs/team-collaboration.md) · [vision-subagent.md](docs/vision-subagent.md) · [attribution.md](docs/attribution.md) · [sample-run.md](docs/sample-run.md) · [model-capabilities.md](docs/model-capabilities.md)


## 示例展示

用 2023 高教社杯 C 题真实跑通的成果展示（完整链路与数据见 [全流程跑通记录](docs/示例题目全流程跑通记录.md)）：

- [论文示例 `examples/论文示例.pdf`](examples/论文示例.pdf) — 33 页成稿论文（XeLaTeX 编译 + 18 幅正式图）
- `examples/figures/` 收录 15 幅成果图，涵盖 **原始数据(raw) / 建模过程(process) / 最终结果(result)** 三阶段，覆盖 Q1–Q3 全部子问题：

**Q1 品类/单品销量分布与关系**

![Q1 品类销量集中度](examples/figures/Q1_单品销量集中度.png)

![Q1 品类相关热力图](examples/figures/Q1_品类相关热力图.png)

| | |
|---|---|
| ![Q1 季节因子](examples/figures/Q1_季节因子.png) | ![Q1 周内因子](examples/figures/Q1_周内因子.png) |
| **季节因子**（夏/春节双高） | **周内因子**（周末高峰） |

| | |
|---|---|
| ![Q1 聚类树状图](examples/figures/process_Q1_品类聚类树状图.png) | ![Q1 原始日销量](examples/figures/raw_Q1_日销量时序.png) |
| **品类聚类** | **原始日销量时序** |

**Q2 品类量价与补货定价**

![Q2 回测收益对比](examples/figures/Q2_回测收益对比.png)

| | |
|---|---|
| ![Q2 量价弹性](examples/figures/Q2_量价弹性.png) | ![Q2 品类定价加成](examples/figures/Q2_品类定价加成.png) |
| **价格弹性估计** | **品类成本加成定价** |

**Q3 单品补货与定价**

| | |
|---|---|
| ![Q3 单品补货量](examples/figures/Q3_单品补货量.png) | ![Q3 单品收益](examples/figures/Q3_单品收益.png) |
| **入选单品补货量** | **单品收益** |

| | |
|---|---|
| ![Q3 单品定价](examples/figures/Q3_单品定价.png) | ![Q3 灵敏度分析](examples/figures/process_Q3_灵敏度分析.png) |
| **单品定价** | **满足率-收益灵敏度** |

## 方法论来源

本包的岗位方法论文档整理自（仅文档，脚本/工具源码未搬运）：

- [XiaoMaColtAI/math-modeling-skill](https://github.com/XiaoMaColtAI/math-modeling-skill) — 三阶段工作流（建模/编程/论文）、质量门禁、算法资料、科学可视化规范、复现清单。**已同步至 v1.3.0**（含新增《交付与截止时间协议》、图表契约 figure contract、各角色文档更新；上游 v1.3.0 自带的官方 DSH 预设包 `dsh-plugin/math-modeling-agent` 未并入——我们保留自己的双岗协同编排）。
- [sweetcornna/mathodology](https://github.com/sweetcornna/mathodology) — 获奖评审门禁（盲评/有界迭代）、证据检索、完整工作流方法论。**已同步最新**（含证据检索新增 paper_graph 既有技术/撤稿核验、two-level 分类路由等更新）

## License

MIT（最宽松许可证，仅要求保留版权声明）
