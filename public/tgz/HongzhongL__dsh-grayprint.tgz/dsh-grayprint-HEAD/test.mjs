import assert from 'node:assert/strict'

let plugin
const React = {
  Fragment: Symbol('Fragment'),
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState: value => [typeof value === 'function' ? value() : value, () => {}],
}
globalThis.window = {
  __ModuleLoader__: { load: ({ factory }) => { plugin = factory(() => React) } },
  localStorage: { getItem: () => null, setItem: () => {} },
}

await import(new URL('./lib/client.js', import.meta.url))

const { PROFILE, FIELDS, splitParagraphs, countText, countBlock, emptyTotals, polarity, verdictOf, createLiveConversation, createStore, zh, en } = plugin

function totals(texts) {
  const value = emptyTotals()
  for (const text of texts) {
    const counts = countText(text)
    value.blocks += 1
    value.paragraphs += counts.paragraphs
    value.blockLens.push(counts.chars)
    value.lens.push(...counts.paragraphLens)
    for (const field of FIELDS) value[field] += counts[field]
  }
  return value
}

const curly = countText('I’m planning this, and I’ll finish it.')
assert.equal(curly.openFP, 1)
assert.equal(curly.openImIll, 1)
assert.equal(countText('I’ll finish this now.').openImIll, 1)
assert.equal(countText('Now, let me inspect the project.').openLetMe, 1)
assert.equal(countText('We need to preserve the current behavior.').openWeNeed, 1)

const multiParagraph = 'We need to map the data first.\n\nLet me inspect the next section.\n\nI\'m checking the result.'
assert.deepEqual(splitParagraphs(multiParagraph), [
  'We need to map the data first.',
  'Let me inspect the next section.',
  "I'm checking the result.",
])
const multiCounts = countText(multiParagraph)
assert.equal(multiCounts.paragraphs, 3)
assert.deepEqual(multiCounts.paragraphLens, [30, 32, 24])
assert.equal(multiCounts.openWeNeed, 1)
assert.equal(multiCounts.openLetMe, 1)
assert.equal(multiCounts.openFP, 1)
assert.equal(multiCounts.openWe, 1)
assert.equal(multiCounts.openImIll, 1)
assert.equal(multiCounts.openWeLets, 1)
const multiTotals = totals([multiParagraph])
assert.equal(multiTotals.blocks, 1)
assert.equal(multiTotals.paragraphs, 3)
assert.deepEqual(multiTotals.lens, [30, 32, 24])
assert.equal(polarity(multiTotals).organization.signals, 2)

// 正文里重复出现不重复计分：每个内部段落只检查一次开头。
const repeatedInside = totals([
  "I'm checking. I'm still checking. I'll finish.\n\nWe need to plan. we should continue. let's finish.",
])
const repeatedPolarity = polarity(repeatedInside)
assert.equal(repeatedInside.paragraphs, 2)
assert.equal(repeatedInside.openImIll, 1)
assert.equal(repeatedInside.openWeLets, 1)
assert.equal(repeatedPolarity.axes[1].v, 0.5)
assert.equal(repeatedPolarity.axes.length, 2)
assert.deepEqual(repeatedPolarity.axes.map((axis) => axis.key), ['axisOpenFP', 'axisImIll'])
assert.equal(Object.hasOwn(repeatedPolarity, 'openWePer'), false)
assert.equal(Object.hasOwn(PROFILE.gray, 'openWeLetsRate'), false)
assert.equal(Object.hasOwn(PROFILE.current, 'openWeLetsRate'), false)
assert.equal(zh.axisPosition, '相对轴位置')
assert.equal(en.axisPosition, 'Relative axis position')
assert.match(zh.axisPositionHint, /不是命中率或模型概率/u)
assert.match(en.axisPositionHint, /not an opener rate or model probability/u)

const mutableBlock = { kind: 'reasoning', text: 'First paragraph.' }
const mutableBefore = countBlock(mutableBlock)
mutableBlock.text = 'First paragraph.\n\nSecond paragraph.'
const mutableAfter = countBlock(mutableBlock)
assert.equal(mutableBefore.paragraphs, 1)
assert.equal(mutableAfter.paragraphs, 2)
assert.notStrictEqual(mutableAfter, mutableBefore)

// 段落正文中的词不属于段首指纹，也不再产生任何“全文总命中”统计。
const bodyOnly = totals([
  "First, let me inspect this while we decide. I'll continue and let's verify it."
])
assert.equal(bodyOnly.openLetMe, 0)
assert.equal(bodyOnly.openWeNeed, 0)
assert.equal(bodyOnly.openImIll, 0)
assert.equal(bodyOnly.openWeLets, 0)
assert.equal(Object.hasOwn(bodyOnly, 'letMe'), false)
assert.equal(Object.hasOwn(bodyOnly, 'we'), false)

const exploratory = totals([
  'Let me inspect the files.',
  'Now, let me check the runtime.',
  'Let me try another route.',
  'We need to preserve the API.',
])
const exploratoryPolarity = polarity(exploratory)
assert.equal(exploratoryPolarity.organization.signals, 4)
assert.equal(exploratoryPolarity.organization.score, 0.25)

const weakOrganization = polarity(totals(['Let me inspect.', 'We need a plan.']))
assert.equal(weakOrganization.organization.score, null)

const korean = totals(Array.from({ length: 5 }, () => '다음 단계를 확인하고 계속 진행합니다.'))
assert.equal(verdictOf(korean, polarity(korean)).code, 'nonenglish')

const french = totals(Array.from({ length: 5 }, () => 'Je vais examiner le projet et continuer ensuite.'))
assert.equal(verdictOf(french, polarity(french)).code, 'weak-signal')

const planned = totals(Array.from({ length: 8 }, (_, index) => `We need to complete step ${index} and verify the result.`))
assert.equal(verdictOf(planned, polarity(planned)).code, 'current')

const grayscale = totals(Array.from({ length: PROFILE.grayMinParagraphs }, (_, index) => `I'm planning step ${index}. I'll implement it and I've checked the constraints.`))
assert.equal(verdictOf(grayscale, polarity(grayscale)).code, 'gray')
assert.ok(polarity(grayscale).score <= 1)

function fakeSessions() {
  let listSubscribers = 0
  let sessionSubscribers = 0
  const snapshot = {
    sessionId: 'session-1',
    nodes: [],
    partial: null,
  }
  const session = {
    getSnapshot: () => snapshot,
    subscribe: () => {
      sessionSubscribers += 1
      return () => { sessionSubscribers -= 1 }
    },
  }
  return {
    service: {
      list: {
        getSnapshot: () => ({ current: 'session-1' }),
        subscribe: () => {
          listSubscribers += 1
          return () => { listSubscribers -= 1 }
        },
      },
      binding: () => ({ session }),
    },
    counts: () => ({ listSubscribers, sessionSubscribers }),
  }
}

const liveFixture = fakeSessions()
const live = createLiveConversation(liveFixture.service)
assert.deepEqual(liveFixture.counts(), { listSubscribers: 1, sessionSubscribers: 1 })
live.dispose()
assert.deepEqual(liveFixture.counts(), { listSubscribers: 0, sessionSubscribers: 0 })

const storeFixture = fakeSessions()
const store = createStore(storeFixture.service)
assert.deepEqual(storeFixture.counts(), { listSubscribers: 1, sessionSubscribers: 1 })
store.dispose()
assert.deepEqual(storeFixture.counts(), { listSubscribers: 0, sessionSubscribers: 0 })

console.log('GrayPrint tests: all passed')
