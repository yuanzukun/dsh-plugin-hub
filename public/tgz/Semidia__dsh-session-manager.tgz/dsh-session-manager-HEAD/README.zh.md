# DSH 会话管理（Session Manager）

针对 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) Web 的客户端插件：
在侧边栏会话行上新增**右键菜单**，并在侧边栏底部新增**「会话管理」**入口。

它回应了社区里"三个点菜单选项太少、不如 Codex"的诉求。官方三个点菜单是写死的
（rc.6 没有公开的会话行操作插槽），所以本插件绕道实现：右键任意会话行弹出完整操作菜单，
底部按钮管理当前会话。

## 功能

**侧边栏会话行右键菜单：**

| 操作 | 实现 |
| --- | --- |
| 置顶聊天 / 取消置顶 | localStorage（`dsh.session-pins.v1`），与 [dsh-session-pins](https://github.com/alooshxl/dsh-session-pins) 共用 |
| 标记为未读 / 已读 | 本地状态（`dsh.session-unread.v1`），行尾显示未读圆点，打开会话自动标记已读 |
| 重命名聊天 | 官方 `sessions.binding(id).session.rename()` + 重命名对话框 |
| 归档聊天 | 官方 `workspaces.archiveSession()` |
| 在新聊天中继续 | 官方 `sessions.fork()` 并打开子会话 |
| 在资源管理器中打开 | 官方 `workspaces.openPath()` 打开该会话所属工作区目录 |
| 复制工作目录 | 工作区 `path` |
| 复制会话标题 / 会话 ID | 剪贴板（`writeClipboard`） |
| 复制深度链接 | 复制 `<origin>/?session=<id>`——装 [dsh-deeplink](https://github.com/qyw233/dsh-deeplink) 后可直接打开 |
| 在新窗口中打开 | `window.open(.../?session=<id>)`——需 dsh-deeplink 才能直达会话 |

**侧边栏底部「会话管理」（当前会话）：** 导出会话 ZIP、归档、Fork、复制标题 / ID。

**未实现**（rc.6 无后端）：在新工作树中继续、删除会话。

## 安装

```sh
dsh plugin --profile web add github:Semidia/dsh-session-manager#v0.1.1
# 深链推荐配套：
dsh plugin --profile web add github:qyw233/dsh-deeplink#main
dsh web
```

添加后重启一次 `dsh web` 并强制刷新。除给会话行加一个 `data-session-id` 属性的
**加性补丁**外，不改任何官方文件（见下）。

## 原理

- 给官方会话行加一行加性补丁：`data-session-id` 属性（`@deepseek-ai/dsh-client-ui-workspace`
  的 `SessionNodeItem`）。否则没有任何公开 API 能知道某行对应哪条会话。
- 插件注册捕获阶段 `contextmenu` 监听 + 公开 `shell.overlay` 插槽里的菜单，
  用 primitives `Menu`（portal + `getAnchorRect`）定位到光标处。
- 底部入口注册进公开的 `sidebar.footer.action` 插槽（加性单元，id `session-manager`，
  与 Session Pins 同槽）。
- 所有会话/工作区动作都走公开客户端服务（`sessions`、`workspaces`、`locale`、`slots`），
  不碰私有宿主 API。

> `data-session-id` 行补丁在安装的 `@deepseek-ai/dsh-client-ui-workspace` 包里，
> dsh 升级会被覆盖——升级后重打一行即可。

## 兼容性

目标版本 `@deepseek-ai/dsh@0.1.0-rc.6`。DSH 处于开发者预览期，新 RC 可能改动
本插件依赖的插槽契约，直到兼容性复核。

## 许可证

MIT
