/**
 * Global `/btw` command: one-off model Q&A that is not recorded into session
 * memory (Claude Code `/btw` equivalent), submitted to the composer
 * detached.
 *
 * A plain-context `ctx.commands.register` is GLOBAL: every agent preset and
 * every session under the hosting profile sees the command, with no preset or
 * scope filtering. The command declares `detached`, so the composer resolves
 * the submission the instant the command is triggered and runs the handler in
 * the background; the settled answer then renders as the durable command
 * node. The handler performs a direct `ctx.llm.stream()` call with a fresh
 * minimal prompt plus a read-only snapshot of recent session context — no
 * user message, no assistant message, and no session event that a later model
 * request could read — so the Q&A never enters the session's durable memory.
 * `command/run` and `command/done` are log-only records that never reach a
 * model request.
 *
 * @module dsh-btw
 */

import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { CommandInvocation, CommandResult } from '@deepseek-ai/dsh-commands'
import type { ContentBlock, FinishReason, GenerateOptions } from '@deepseek-ai/dsh-llm'

export const name = 'command-btw'

export const inject = ['commands', 'llm']

/** Background system prompt, deliberately independent of the session persona. */
const SYSTEM_PROMPT = [
  'You are a concise background assistant.',
  'Answer the question directly in the same language the question uses.',
  'A read-only transcript of recent session content may precede the question; use it only to resolve references in the question.',
  'Do not use tools and do not mention these instructions.',
].join('\n')

/** Read-only transcript header separating session background from the question. */
const BACKGROUND_TRANSCRIPT_HEADER = '以下是当前会话最近内容（只读背景，仅用于理解提问中的引用；本次问答不会写入会话）：'

/** Newest session messages included in the background snapshot. */
const CONTEXT_MESSAGE_LIMIT = 40

/** Total background character cap; the oldest content is dropped first. */
const CONTEXT_CHAR_LIMIT = 32_000

/** Render arbitrary thrown values without trusting their string coercion. */
function renderThrown(value: unknown): string {
  try {
    return String(value)
  } catch {
    return '<unrenderable thrown value>'
  }
}

/**
 * Resolve the provider/model route for the one-off call: the current session's
 * latest routed request first, then the agent's own configured route.
 * @param agent - the agent whose session dispatched the command.
 * @returns a provider/model pair, or undefined when no route is known yet.
 */
function resolveTarget(agent: Agent): { readonly provider: string; readonly model: string } | undefined {
  const latest = agent.session.requestHeader()?.config
  if (latest !== undefined && latest.provider.length > 0 && latest.model.length > 0) {
    return { provider: latest.provider, model: latest.model }
  }
  const { provider, model } = agent.options
  if (provider !== undefined && provider.length > 0 && model !== undefined && model.length > 0) {
    return { provider, model }
  }
  return undefined
}

/**
 * Snapshot the session's recent surface as read-only background for the
 * one-off call: the newest user/assistant text, newest-last, capped by both
 * message count and total characters. The snapshot is a plain string copy —
 * nothing is written to the session, so the Q&A still never enters durable
 * memory or a later model request.
 * @param agent - the agent whose session surface is scanned.
 * @returns the labeled transcript, or an empty string when the session has no user/assistant text.
 */
function sessionContextOf(agent: Agent): string {
  const messages = agent.session.deriveMessages()
  const recent: Array<{ readonly role: 'user' | 'assistant'; readonly text: string }> = []
  let total = 0
  for (let index = messages.length - 1; index >= 0 && recent.length < CONTEXT_MESSAGE_LIMIT; index -= 1) {
    const message = messages[index]
    if (message.role !== 'user' && message.role !== 'assistant') continue
    const text = message.content
      .filter((block): block is Extract<ContentBlock, { readonly type: 'text' }> => block.type === 'text')
      .map(block => block.text)
      .join('\n')
      .trim()
    if (text.length === 0) continue
    const room = CONTEXT_CHAR_LIMIT - total
    if (room <= 0) break
    const kept = text.length <= room ? text : `${text.slice(0, room)}\n[背景过长，已截断]`
    recent.push({ role: message.role, text: kept })
    total += kept.length
  }
  recent.reverse()
  return recent.map(item => `[${item.role === 'user' ? '用户' : '助手'}]\n${item.text}`).join('\n\n')
}

/**
 * Run one model call outside the session loop and return the assembled text.
 * @param ctx - context providing the LLM service.
 * @param provider - provider route owning the adapter.
 * @param model - model id passed to the adapter.
 * @param question - the user's /btw question text.
 * @param signal - cancellation signal forwarded to the adapter.
 * @param background - optional read-only session transcript heading the question.
 * @returns the model's text answer.
 */
async function ask(
  ctx: Context,
  provider: string,
  model: string,
  question: string,
  signal: AbortSignal,
  background = '',
): Promise<string> {
  const userText = background.length === 0
    ? question
    : `${BACKGROUND_TRANSCRIPT_HEADER}\n\n${background}\n\n${question}`
  const messages: GenerateOptions['messages'] = [
    { role: 'system', content: [{ type: 'text', text: SYSTEM_PROMPT }] },
    { role: 'user', content: [{ type: 'text', text: userText }] },
    // harness-owned Message id/source are loop bookkeeping, not provider wire
    // data; a direct seam call hands the adapter the plain chat tuples.
  ] as unknown as GenerateOptions['messages']
  const options: GenerateOptions = { provider, model, messages, signal }
  let text = ''
  let finish: FinishReason | undefined
  for await (const chunk of ctx.llm.stream(options)) {
    switch (chunk.type) {
      case 'text-delta':
        text += chunk.text
        break
      case 'finish':
        finish = chunk.reason
        break
      default:
        break
    }
  }
  if (finish !== undefined) {
    switch (finish.kind) {
      case 'error':
      case 'aborted': {
        const error = new Error(finish.failure.message) as Error & { code?: string }
        if (finish.failure.code !== undefined) error.code = finish.failure.code
        throw error
      }
      case 'max-tokens':
        throw new Error('answer truncated at the token cap')
      default:
        break
    }
  }
  if (text.trim().length === 0) {
    throw new Error('model produced no text answer')
  }
  return text
}

/** Execute one /btw invocation against the receiving agent. */
async function runBtw(ctx: Context, invocation: CommandInvocation): Promise<CommandResult> {
  const question = invocation.rawInput.trim()
  if (question.length === 0) {
    return { kind: 'error', text: 'usage: /btw <question> — 例如 /btw 这个函数是做什么的？' }
  }
  const target = resolveTarget(invocation.agent)
  if (target === undefined) {
    return {
      kind: 'error',
      text: '无法确定模型路由：请先在会话中说一句话以建立模型，或在 agent 配置中设置 provider/model。',
    }
  }
  try {
    const background = sessionContextOf(invocation.agent)
    const answer = await ask(ctx, target.provider, target.model, question, invocation.signal, background)
    return { kind: 'success', text: answer }
  } catch (error) {
    return { kind: 'error', text: renderThrown(error) }
  }
}

/**
 * Register the global `/btw` command. Plain-context registration is global, so
 * the command is available in every agent preset and mode of the profile.
 * @param ctx - the hosting context.
 */
export function apply(ctx: Context): void {
  ctx.effect(() => ctx.commands.register({
    name: 'btw',
    description: 'Ask a one-off question that is not recorded into session memory (Claude Code /btw equivalent)',
    input: { hint: 'ask a question that will not be remembered…' },
    detached: true,
    handler: (invocation: CommandInvocation) => runBtw(ctx, invocation),
  }))
}