# Design QA

**Final result: passed**

## Evidence

- Reference hierarchy: `/var/folders/tp/clqyc1110tx0q2q9vgvp6tj80000gn/T/codex-clipboard-a828ae76-6576-4642-bcb9-104a895622b0.png`
- Models, dark desktop: `docs/assets/models-dark-desktop.png`
- Models, light desktop: `docs/assets/models-light-desktop.png`
- Models Auth action area: `docs/assets/models-auth-actions-dark.png`
- Auth dialog, dark desktop: `docs/assets/auth-login-dark.png`
- Usage, dark desktop: `docs/assets/usage-dark-desktop.png`
- Usage, light desktop: `docs/assets/usage-light-desktop.png`
- Usage, light narrow: `docs/assets/usage-light-narrow.png`
- Usage, dark narrow: `docs/assets/usage-dark-narrow.png`
- Time range, light desktop: `docs/assets/usage-time-range-light.png`
- Rendered from the package installed by the standard DSH CLI in the active Web profile. The release gate replaces the local tarball with the immutable GitHub tag before publication is considered complete.

## Comparison pass

- Information hierarchy: one stable five-cell KPI strip, a compact continuous Token activity grid with month markers and mode controls, then a two-column model/tool row. Provider, model, cost, and source detail remain below the first visual summary. This preserves the reference hierarchy without copying its brand treatment.
- DSH fit: the page stays inside the native Settings modal and reuses its sidebar, content width, typography, semantic variables, Button, Pill, StateDot, input treatment, borders, and radii. The Models contribution is a compact extension above the unchanged native DeepSeek and add-provider cards.
- Typography and alignment: KPI and table values use tabular figures. Ranking names and values have fixed alignment; long identifiers truncate with title tooltips. Secondary labels, units, unknown counts, and price provenance use the host's lower-emphasis text tokens.
- Color and surfaces: light and dark renders use only DSH semantic variables. The five heat levels remain distinguishable in both themes, with text labels for price and connection states. No gradient, glass effect, glow, heavy shadow, or global CSS was introduced.
- Responsiveness: at 720 × 900, KPI cells reflow, rankings stack, filters wrap as whole controls, the refresh label stays intact, and the activity grid has no horizontal scrollbar. The second-precision calendar keeps shortcuts and actions inside the Settings viewport.
- States and interaction: loading skeletons respect reduced motion; empty and remote-error states have structured containers; connection failure is announced as status text; daily cells are keyboard-focusable and expose date, Token, and call labels; controls retain visible focus styling.
- Copy and icons: navigation and headings follow the final Models/Usage information architecture. Controls reuse DSH primitives and semantic tokens. The plugin-owned Usage navigation icon is a 16 px currentColor SVG passed through the generic section-icon seam.

## Known product limits

- Tool events do not contain an authoritative owning-plugin id in current DSH logs, so the rank is labeled “插件 / 工具” but reports durable tool names rather than inventing plugin attribution.
- OpenAI Codex browser OAuth is implemented and verified through the official sign-in boundary. Completing consent still requires the user on OpenAI's page; screenshots contain no authorization URL or account data.
- The Models extension requires the generic `settings.models.insights` and `settings.models.actions` seams. The plugin icon requires optional `settings.section.icon`; Host and Usage still load on the published rc6 seam set.
