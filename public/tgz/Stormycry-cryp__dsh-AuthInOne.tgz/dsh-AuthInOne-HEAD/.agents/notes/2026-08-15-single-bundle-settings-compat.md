# One Bundle owns the 47f compatibility surface

## Decision

DSH 47f's client module registry loads one browser entrypoint per package and
does not recognize package subpaths as additional client roster entries.
AuthInOne therefore keeps one `dsh-auth-in-one/client` entrypoint and divides
it internally into generic Settings owner, generic Models owner, and business
contribution modules.

The Bundle patch disables only the official `ui-settings-general` and
`ui-settings-models` rows, then inserts the ordinary `auth-in-one` row. The
generic owners are derived from those exact 47f runtime sources and preserve
their native General, Models, onboarding, Provider add/edit/remove, settings
document, and shell behavior. Their only additions are two Models child slots
and one generic settings-section icon projection. AuthInOne registers its
business UI through those slots.

The Host fingerprints the exact official owner package versions and client
artifacts before creating plugin state. A changed, missing, or native-seam host
fails with `AUTH_IN_ONE_COMPAT_UNSUPPORTED_DSH` instead of silently replacing
unknown owners or double-declaring slots. The client also rejects already
declared seams before mounting either compatibility owner.

## Alternatives not chosen

Subpath client entries cannot be discovered by the official registry. DOM
queries, portals, paste listeners, manual profile patches, and DSH checkout
changes violate the installation and ownership boundary. Replacing ui-slots
would widen the override without need; the icon projection is instead a child
slot of the replacement Settings shell.

## Verification

Unit coverage must prove exact-host acceptance and changed/missing-host
rejection. Release acceptance additionally requires standard plugin remove/add
against the untouched official 47f checkout, dump-config/package provenance,
and rendered Models/Usage checks followed by uninstall restoration.
