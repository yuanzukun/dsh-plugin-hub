# Vision fallback stays request-local and session-reconstructable

## Decision

AuthInOne implements vision fallback as plugin-owned `llm/stream` middleware. It does not modify the DSH agent loop, adapter implementations, attachment store, or session-event vocabulary.

The middleware delegates native multimodal routes unchanged. It activates only when the main route explicitly omits image input and the user-enabled fallback route explicitly declares image input. Missing modality metadata never authorizes either conclusion.

Before auxiliary dispatch, the plugin appends the exact image-reference request as a normal DSH `user/message` with `auth-in-one-vision-request` provenance. A successful or failed result is another normal `user/message` with the exact route, source-message identity, stable status, and provider-reported usage. This uses the LLM message-source extension point and keeps replay, resume, fork, persistence, and uninstall behavior inside existing DSH mechanisms.

The provider-bound main request filters the two plugin provenance rows and replaces only the source message's image blocks with the recorded description. DSH attachment storage retains the original image bytes and the original user message remains durable. A failed fallback returns a stable recoverable failure before a text-only main route is dispatched.

## Alternatives not chosen

A plugin database would create a second retention and fork authority for descriptions and usage. A custom required session-event type would make sessions unreadable after uninstall, while an informational type has no public external-plugin append API. Mutating `agent-loop` would violate the plugin architecture. Treating unknown model capability as text-only could intercept a native vision model.

## Verification

Keyless tests cover native multimodal pass-through, default-off behavior, multiple images, one-time auxiliary dispatch, durable provenance, provider-reported usage, resume/fork reuse, and sanitized upstream failure. UI tests cover explicit enablement and selection from routes whose adapters declare image input. Release acceptance still requires a built package installed through the standard remove/add path and rendered Models/Usage checks in dark, light, desktop, and 760 px narrow layouts.
