/** Exact-host guard for the bundled DSH 47f Settings compatibility owners. */
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, resolve } from 'node:path'

export interface CompatOwnerFingerprint {
  packageName: string
  version: string
  clientSha256: string
}

export const SUPPORTED_COMPAT_OWNERS: readonly CompatOwnerFingerprint[] = [
  {
    packageName: '@deepseek-ai/dsh-client-ui-settings-general',
    version: '0.1.0-rc.5',
    clientSha256: 'aa00cd16b683c1ef5d2fd4fcc61426f8f98b4f6f7d2da9b33e9da27b2f60b872',
  },
  {
    packageName: '@deepseek-ai/dsh-client-ui-settings-models',
    version: '0.1.0-rc.5',
    clientSha256: '7682232f037c305c9cbfd5b607beb6068b8c8885ff56256e05986d6fd002bd33',
  },
]

/** Validate independently discovered facts; exported for duplicate/new-host tests. */
export function assertSupportedCompatOwners(actual: readonly CompatOwnerFingerprint[]): void {
  for (const expected of SUPPORTED_COMPAT_OWNERS) {
    const found = actual.find(entry => entry.packageName === expected.packageName)
    if (found?.version === expected.version && found.clientSha256 === expected.clientSha256) continue
    const observed = found === undefined ? 'missing' : `${found.version} sha256:${found.clientSha256}`
    throw new Error(
      `AUTH_IN_ONE_COMPAT_UNSUPPORTED_DSH: ${expected.packageName} expected ${expected.version} `
      + `sha256:${expected.clientSha256}, observed ${observed}. Remove dsh-auth-in-one; this package only replaces the official DSH 47f Settings owners.`,
    )
  }
}

/** Resolve the active host's owner artifacts from the installed plugin location. */
export function discoverCompatOwners(anchor: string | URL = import.meta.url): CompatOwnerFingerprint[] {
  const require = createRequire(anchor)
  return SUPPORTED_COMPAT_OWNERS.map(expected => {
    const packageJsonPath = require.resolve(`${expected.packageName}/package.json`)
    const metadata = JSON.parse(readFileSync(packageJsonPath, 'utf8')) as { version?: unknown }
    const client = readFileSync(resolve(dirname(packageJsonPath), 'lib/client.js'))
    return {
      packageName: expected.packageName,
      version: typeof metadata.version === 'string' ? metadata.version : 'unknown',
      clientSha256: createHash('sha256').update(client).digest('hex'),
    }
  })
}

/** Fail before the service creates state when the static owner override is unsafe. */
export function assertCompatibleHost(): void {
  if (process.env.NODE_ENV === 'test') return
  assertSupportedCompatOwners(discoverCompatOwners())
}

/** Validate owner artifacts from a known DSH package-resolution anchor. */
export function assertCompatibleHostAt(anchor: string | URL): void {
  assertSupportedCompatOwners(discoverCompatOwners(anchor))
}
