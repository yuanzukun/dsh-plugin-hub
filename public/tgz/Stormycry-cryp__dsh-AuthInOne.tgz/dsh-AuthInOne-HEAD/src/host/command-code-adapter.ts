/** DSH-native adapter for Command Code's account-scoped generate endpoint. */

import { randomUUID } from 'node:crypto'
import {
  CallId, LlmAdapter, LlmError, type ContentBlock, type GenerateOptions, type LlmModelInfo, type StreamChunk, type TokenUsage,
  attributionHeaders,
} from '@deepseek-ai/dsh-llm'
import { readBoundedJson } from './bounded-json.ts'

const BASE_URL = 'https://api.commandcode.ai'
const MAX_LINE_BYTES = 1024 * 1024
const MAX_CATALOG_BYTES = 256 * 1024

function object(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function textOf(blocks: readonly ContentBlock[]): string {
  return blocks.flatMap(block => block.type === 'text' || block.type === 'reasoning' ? [block.text] : []).join('\n')
}

function wireMessages(options: GenerateOptions): readonly Record<string, unknown>[] {
  const messages: Record<string, unknown>[] = []
  for (const message of options.messages) {
    if (message.role === 'assistant') {
      messages.push({
        role: 'assistant',
        content: message.content.flatMap((block): Record<string, unknown>[] => {
          if (block.type === 'text') return [{ type: 'text', text: block.text }]
          if (block.type === 'reasoning') return [{ type: 'reasoning', text: block.text }]
          if (block.type === 'tool-call') {
            let input: unknown = {}
            try { input = JSON.parse(block.arguments) as unknown } catch { input = block.arguments }
            return [{ type: 'tool-call', toolCallId: block.id, toolName: block.name, input }]
          }
          return []
        }),
      })
      continue
    }
    const toolResults = message.content.filter(block => block.type === 'tool-result')
    if (toolResults.length > 0) {
      for (const result of toolResults) {
        if (result.type !== 'tool-result') continue
        messages.push({
          role: 'tool',
          content: [{
            type: 'tool-result', toolCallId: result.toolCallId, toolName: 'tool',
            output: { type: result.isError === true ? 'error-text' : 'text', value: textOf(result.content) },
          }],
        })
      }
      continue
    }
    messages.push({ role: 'user', content: [{ type: 'text', text: textOf(message.content) }] })
  }
  return messages
}

function usage(value: unknown): TokenUsage | undefined {
  const row = object(value)
  if (row === undefined) return undefined
  const input = typeof row.inputTokens === 'number' && Number.isFinite(row.inputTokens) ? row.inputTokens : undefined
  const output = typeof row.outputTokens === 'number' && Number.isFinite(row.outputTokens) ? row.outputTokens : undefined
  if (input === undefined || output === undefined || input < 0 || output < 0) return undefined
  const details = object(row.inputTokenDetails)
  const cacheRead = typeof details?.cacheReadTokens === 'number' ? details.cacheReadTokens : undefined
  const cacheWrite = typeof details?.cacheWriteTokens === 'number' ? details.cacheWriteTokens : undefined
  return {
    inputTokens: Math.max(0, input - (cacheRead ?? 0) - (cacheWrite ?? 0)),
    outputTokens: Math.max(0, output),
    ...cacheRead === undefined ? {} : { cacheReadTokens: Math.max(0, cacheRead) },
    ...cacheWrite === undefined ? {} : { cacheWriteTokens: Math.max(0, cacheWrite) },
  }
}

async function* lines(response: Response): AsyncGenerator<Record<string, unknown>> {
  if (response.body === null) throw new LlmError('Command Code response body was empty', 'UPSTREAM')
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  try {
    while (true) {
      const result = await reader.read()
      buffer += decoder.decode(result.value, { stream: !result.done })
      if (Buffer.byteLength(buffer) > MAX_LINE_BYTES) throw new LlmError('Command Code event exceeded the safe limit', 'UPSTREAM')
      let newline = buffer.indexOf('\n')
      while (newline >= 0) {
        const raw = buffer.slice(0, newline).trim().replace(/^data:\s*/, '')
        buffer = buffer.slice(newline + 1)
        if (raw.length > 0) {
          try {
            const parsed = object(JSON.parse(raw) as unknown)
            if (parsed !== undefined) yield parsed
          } catch {
            // Non-event lines carry no model output and are ignored.
          }
        }
        newline = buffer.indexOf('\n')
      }
      if (result.done) {
        const raw = buffer.trim().replace(/^data:\s*/, '')
        if (raw.length > 0) {
          try {
            const parsed = object(JSON.parse(raw) as unknown)
            if (parsed !== undefined) yield parsed
          } catch {
            // A trailing non-event line carries no model output.
          }
        }
        break
      }
    }
  } finally {
    reader.releaseLock()
  }
}

/** Command Code model discovery and NDJSON streaming with a Host token resolver. */
export class CommandCodeLlmAdapter extends LlmAdapter {
  private models: LlmModelInfo[] = [{ provider: 'command-code', id: 'deepseek/deepseek-v4-flash', name: 'DeepSeek V4 Flash' }]

  constructor(private readonly accessToken: (signal?: AbortSignal) => Promise<string>, private readonly request: typeof fetch = fetch) {
    super()
  }

  override providerInfo(provider: string): { id: string; name: string } {
    return { id: provider, name: 'Command Code' }
  }

  override async listModels(_provider: string): Promise<readonly LlmModelInfo[]> {
    try {
      const token = await this.accessToken()
      const response = await this.request(`${BASE_URL}/provider/v1/models`, {
        headers: { ...attributionHeaders(), authorization: `Bearer ${token}`, accept: 'application/json' },
        signal: AbortSignal.timeout(15_000),
      })
      if (response.ok) {
        const body = await readBoundedJson(response, MAX_CATALOG_BYTES)
        const rows = Array.isArray(body) ? body : Array.isArray(object(body)?.data) ? object(body)!.data as unknown[] : []
        const models = rows.flatMap((value): LlmModelInfo[] => {
          const row = object(value)
          const id = row?.id ?? row?.model
          return typeof id === 'string' && id.length > 0
            ? [{ provider: 'command-code', id, name: typeof row?.name === 'string' ? row.name : id }]
            : []
        })
        if (models.length > 0) this.models = models.slice(0, 256)
      }
    } catch {
      // The last known catalog remains selectable when discovery is unavailable.
    }
    return this.models.map(model => ({ ...model }))
  }

  override resolveModel(provider: string, model: string): Promise<LlmModelInfo & { context: { contextWindow: number } }> {
    const known = this.models.find(entry => entry.id === model)
    return Promise.resolve({
      provider, id: model, name: known?.name ?? model, inputModalities: ['text'], context: { contextWindow: 200_000 },
    })
  }

  override async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const token = await this.accessToken(options.signal)
    const response = await this.request(`${BASE_URL}/alpha/generate`, {
      method: 'POST',
      headers: {
        ...attributionHeaders(), authorization: `Bearer ${token}`, 'content-type': 'application/json',
        'user-agent': 'cli', 'x-command-code-version': '0.52.1', 'x-cli-environment': 'production',
        'x-taste-learning': 'false', 'x-co-flag': 'false', 'x-session-id': randomUUID(),
      },
      body: JSON.stringify({
        config: { date: new Date().toISOString().slice(0, 10), environment: process.platform },
        memory: '', taste: null, skills: null, permissionMode: 'standard', mode: 'agent',
        params: {
          model: options.model,
          messages: wireMessages(options),
          tools: options.tools?.map(tool => ({ name: tool.name, description: tool.description, input_schema: tool.parameters })) ?? [],
          system: options.system ?? '',
          max_tokens: options.maxTokens ?? 64_000,
          stream: true,
          ...options.temperature === undefined ? {} : { temperature: options.temperature },
          ...options.reasoningEffort === undefined ? {} : { reasoning_effort: options.reasoningEffort },
        },
      }),
      ...options.signal === undefined ? {} : { signal: options.signal },
    })
    if (!response.ok) throw new LlmError(`Command Code returned HTTP ${String(response.status)}`, 'UPSTREAM', { status: response.status })
    let text = ''
    let reasoning = ''
    let textOpen = false
    let reasoningOpen = false
    let nextIndex = 0
    let sawTool = false
    let terminalUsage: TokenUsage | undefined
    for await (const event of lines(response)) {
      if (event.type === 'text-delta' && typeof event.text === 'string') {
        if (!textOpen) { textOpen = true; yield { type: 'block-start', index: 0, blockType: 'text' } }
        text += event.text
        yield { type: 'text-delta', index: 0, text: event.text }
      } else if (event.type === 'reasoning-delta' && typeof event.text === 'string') {
        if (!reasoningOpen) { reasoningOpen = true; nextIndex = textOpen ? 1 : 0; yield { type: 'block-start', index: nextIndex, blockType: 'reasoning' } }
        reasoning += event.text
        yield { type: 'reasoning-delta', index: nextIndex, text: event.text }
      } else if (event.type === 'tool-call') {
        const index = (textOpen ? 1 : 0) + (reasoningOpen ? 1 : 0) + (sawTool ? 1 : 0)
        sawTool = true
        const id = CallId(typeof event.toolCallId === 'string' ? event.toolCallId : randomUUID())
        const name = typeof event.toolName === 'string' ? event.toolName : 'tool'
        const args = typeof event.input === 'string' ? event.input : JSON.stringify(event.input ?? event.args ?? {})
        yield { type: 'block-start', index, blockType: 'tool-call' }
        yield { type: 'tool-call-delta', index, id, name, argumentsDelta: args }
        yield { type: 'block-end', index, block: { type: 'tool-call', id, name, arguments: args } }
      } else if (event.type === 'finish-step' || event.type === 'finish') {
        terminalUsage ??= usage(event.totalUsage ?? event.usage)
      } else if (event.type === 'error') {
        throw new LlmError('Command Code upstream reported a stream error', 'UPSTREAM')
      }
    }
    if (textOpen) yield { type: 'block-end', index: 0, block: { type: 'text', text } }
    if (reasoningOpen) yield { type: 'block-end', index: nextIndex, block: { type: 'reasoning', text: reasoning } }
    if (terminalUsage !== undefined) yield { type: 'usage', usage: terminalUsage }
    yield { type: 'finish', reason: { kind: sawTool ? 'tool-calls' : 'stop' } }
  }
}
