/** Pure session-log fold for cross-session provider analytics. */

import type { SessionEvent, SessionHeader } from '@deepseek-ai/dsh-session'
import type { TokenUsage } from '@deepseek-ai/dsh-llm'
import type {
  AnalyticsQuery, DailyActivityView, ModelPriceView, OutputPriceBand, ProviderAnalyticsView,
  UsageRankView,
} from '../types.ts'

/** One complete logical session supplied by live memory or persistence. */
export interface SessionLogInput {
  readonly header: SessionHeader
  readonly events: readonly SessionEvent[]
}

interface CallRow {
  provider: string
  model: string
  time: number
  usage?: TokenUsage
  role: 'main' | 'vision-fallback'
}

interface RankedMutable {
  id: string
  label: string
  calls: number
  tokens: number
  cost: MutableCost
}

interface MutableCost {
  currency: string | null
  known: number
  exactCalls: number
  partialCalls: number
  unknownCalls: number
}

interface MutableUsage {
  uncachedInputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  reasoningTokens: number
  callsWithoutUsage: number
  callsWithoutCacheRead: number
  callsWithoutCacheWrite: number
  callsWithoutReasoning: number
}

const DAY_MS = 86_400_000

const emptyUsage = (): MutableUsage => ({
  uncachedInputTokens: 0,
  outputTokens: 0,
  cacheReadTokens: 0,
  cacheWriteTokens: 0,
  reasoningTokens: 0,
  callsWithoutUsage: 0,
  callsWithoutCacheRead: 0,
  callsWithoutCacheWrite: 0,
  callsWithoutReasoning: 0,
})

const emptyCost = (): MutableCost => ({
  currency: null,
  known: 0,
  exactCalls: 0,
  partialCalls: 0,
  unknownCalls: 0,
})

function isoDay(time: number, timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(time))
  const fields = Object.fromEntries(parts.map(part => [part.type, part.value]))
  return `${fields.year}-${fields.month}-${fields.day}`
}

const tokensOf = (usage: TokenUsage | undefined): number => usage === undefined
  ? 0
  : usage.inputTokens + usage.outputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)

const priceKey = (provider: string, model: string): string => `${provider}\u0000${model}`

/** Classify one catalog row by its USD output price per million tokens. */
export function outputPriceBandOf(price: ModelPriceView | undefined): Exclude<OutputPriceBand, 'all'> {
  const value = price?.outputPerMillion
  if (price?.currency !== 'USD' || value === undefined || !Number.isFinite(value) || value < 0) return 'unpriced'
  if (value < 1) return '0-1'
  if (value < 5) return '1-5'
  if (value < 15) return '5-15'
  return '15-plus'
}

function addUsage(target: MutableUsage, usage: TokenUsage | undefined): void {
  if (usage === undefined) {
    target.callsWithoutUsage += 1
    target.callsWithoutCacheRead += 1
    target.callsWithoutCacheWrite += 1
    target.callsWithoutReasoning += 1
    return
  }
  target.uncachedInputTokens += usage.inputTokens
  target.outputTokens += usage.outputTokens
  target.cacheReadTokens += usage.cacheReadTokens ?? 0
  target.cacheWriteTokens += usage.cacheWriteTokens ?? 0
  target.reasoningTokens += usage.reasoningTokens ?? 0
  if (usage.cacheReadTokens === undefined) target.callsWithoutCacheRead += 1
  if (usage.cacheWriteTokens === undefined) target.callsWithoutCacheWrite += 1
  if (usage.reasoningTokens === undefined) target.callsWithoutReasoning += 1
}

function addCost(target: MutableCost, call: CallRow, price: ModelPriceView | undefined): void {
  if (price === undefined || call.usage === undefined) {
    target.unknownCalls += 1
    return
  }
  if (target.currency !== null && target.currency !== price.currency) {
    target.unknownCalls += 1
    return
  }
  target.currency = price.currency
  const usage = call.usage
  const pairs: Array<[number | undefined, number | undefined]> = [
    [usage.inputTokens, price.uncachedInputPerMillion],
    [usage.outputTokens, price.outputPerMillion],
    [usage.cacheReadTokens, price.cacheReadPerMillion],
    [usage.cacheWriteTokens, price.cacheWritePerMillion],
  ]
  let partial = false
  for (const [tokens, rate] of pairs) {
    if (tokens === undefined || rate === undefined) {
      if (tokens !== undefined && tokens > 0 || rate !== undefined) partial = true
      continue
    }
    target.known += tokens * rate / 1_000_000
  }
  if (price.reasoningPerMillion !== undefined) {
    if (usage.reasoningTokens === undefined) partial = true
    else target.known += usage.reasoningTokens * price.reasoningPerMillion / 1_000_000
  }
  if (partial) target.partialCalls += 1
  else target.exactCalls += 1
}

function callsOf(log: SessionLogInput): CallRow[] {
  let route: { provider: string; model: string } | undefined
  const calls = new Map<string, CallRow>()
  for (const event of log.events) {
    if (event.type === 'request/context') {
      route = { provider: event.data.provider, model: event.data.model }
      continue
    }
    if (event.type !== 'assistant/chunk' && event.type !== 'assistant/message' && event.type !== 'step/end') continue
    const turn = event.data.turn
    const step = event.data.step
    const key = `${turn}:${step}`
    const existing = calls.get(key)
    if (existing === undefined) {
      if (route === undefined) continue
      calls.set(key, { ...route, time: event.time, role: 'main' })
    }
    const row = calls.get(key)
    if (row === undefined) continue
    if (event.type === 'assistant/chunk' && event.data.chunk.type === 'usage') row.usage = event.data.chunk.usage
    if (event.type === 'assistant/message' && event.data.usage !== undefined) row.usage = event.data.usage
  }
  for (const event of log.events) {
    if (event.type !== 'user/message') continue
    const source = event.data.source
    if (source.kind !== 'auth-in-one-vision-result' || source.status !== 'success') continue
    calls.set(`vision:${source.requestId}`, {
      provider: source.route.provider,
      model: source.route.model,
      time: event.time,
      role: 'vision-fallback',
      ...source.usage === undefined ? {} : { usage: source.usage },
    })
  }
  return [...calls.values()]
}

function streaks(days: readonly string[], today: string): { current: number; longest: number } {
  const sorted = [...new Set(days)].sort()
  let longest = 0
  let run = 0
  let previous: number | undefined
  for (const day of sorted) {
    const value = Date.parse(`${day}T00:00:00.000Z`)
    run = previous !== undefined && value - previous === DAY_MS ? run + 1 : 1
    longest = Math.max(longest, run)
    previous = value
  }
  let current = 0
  let cursor = Date.parse(`${today}T00:00:00.000Z`)
  const set = new Set(sorted)
  while (set.has(new Date(cursor).toISOString().slice(0, 10))) {
    current += 1
    cursor -= DAY_MS
  }
  return { current, longest }
}

/** Fold complete logical logs into a detached analytics view. */
export function foldProviderAnalytics(
  logs: readonly SessionLogInput[],
  query: AnalyticsQuery,
  prices: readonly ModelPriceView[],
  catalogVersion: string,
  now = Date.now(),
): ProviderAnalyticsView {
  if (!Number.isFinite(query.startTime) || !Number.isFinite(query.endTimeExclusive)
    || query.startTime >= query.endTimeExclusive) {
    throw new TypeError('analytics time range must have finite increasing UTC boundaries')
  }
  try {
    new Intl.DateTimeFormat('en', { timeZone: query.timeZone }).format(now)
  } catch {
    throw new TypeError(`unsupported analytics time zone ${query.timeZone}`)
  }
  const priceByRoute = new Map(prices.map(price => [priceKey(price.provider, price.model), price]))
  const routeMatches = (provider: string, model: string): boolean => {
    if (query.provider !== null && provider !== query.provider) return false
    if (query.outputPriceBand === 'all') return true
    return outputPriceBandOf(priceByRoute.get(priceKey(provider, model))) === query.outputPriceBand
  }
  const timeMatches = (time: number): boolean => time >= query.startTime && time < query.endTimeExclusive
  const usage = emptyUsage()
  const cost = emptyCost()
  const daily = new Map<string, { calls: number; tokens: number; cost: MutableCost }>()
  const providers = new Map<string, RankedMutable>()
  const models = new Map<string, RankedMutable>()
  const tools = new Map<string, RankedMutable>()
  const callRoles = {
    main: { calls: 0, tokens: 0, cost: emptyCost() },
    visionFallback: { calls: 0, tokens: 0, cost: emptyCost() },
  }
  const availableProviders = new Map<string, string>()
  const sessionIds = new Set<string>()
  let longestSessionMs = 0

  const rank = (table: Map<string, RankedMutable>, id: string, label = id): RankedMutable => {
    let row = table.get(id)
    if (row === undefined) {
      row = { id, label, calls: 0, tokens: 0, cost: emptyCost() }
      table.set(id, row)
    }
    return row
  }

  for (const log of logs) {
    const callsInTime = callsOf(log).filter(call => timeMatches(call.time))
    for (const call of callsInTime) availableProviders.set(call.provider, call.provider)
    const calls = callsInTime.filter(call => routeMatches(call.provider, call.model))
    if (calls.length > 0) sessionIds.add(log.header.id)
    const times = calls.map(call => call.time)
    if (times.length > 1) longestSessionMs = Math.max(longestSessionMs, Math.max(...times) - Math.min(...times))
    for (const call of calls) {
      const tokens = tokensOf(call.usage)
      const price = priceByRoute.get(priceKey(call.provider, call.model))
      const role = call.role === 'main' ? callRoles.main : callRoles.visionFallback
      role.calls += 1
      role.tokens += tokens
      addCost(role.cost, call, price)
      addUsage(usage, call.usage)
      addCost(cost, call, price)
      const day = isoDay(call.time, query.timeZone)
      const dayRow = daily.get(day) ?? { calls: 0, tokens: 0, cost: emptyCost() }
      dayRow.calls += 1
      dayRow.tokens += tokens
      addCost(dayRow.cost, call, price)
      daily.set(day, dayRow)
      const provider = rank(providers, call.provider)
      const model = call.role === 'main'
        ? rank(models, `${call.provider}/${call.model}`, call.model)
        : rank(models, `${call.provider}/${call.model}#vision-fallback`, `${call.model} · Vision fallback`)
      for (const row of [provider, model]) {
        row.calls += 1
        row.tokens += tokens
        addCost(row.cost, call, price)
      }
    }
    let route: { provider: string; model: string } | undefined
    for (const event of log.events) {
      if (event.type === 'request/context') {
        route = { provider: event.data.provider, model: event.data.model }
        continue
      }
      if (event.type !== 'tool/call' || !timeMatches(event.time) || route === undefined
        || !routeMatches(route.provider, route.model)) continue
      const row = rank(tools, event.data.name)
      row.calls += 1
    }
  }

  const activity: DailyActivityView[] = [...daily.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([date, value]) => ({
    date,
    calls: value.calls,
    tokens: value.tokens,
    costKnown: value.cost.known,
    costUnknownCalls: value.cost.unknownCalls + value.cost.partialCalls,
  }))
  const totalTokens = activity.reduce((sum, day) => sum + day.tokens, 0)
  const streak = streaks(activity.filter(day => day.tokens > 0).map(day => day.date), isoDay(now, query.timeZone))
  const ranked = (table: Map<string, RankedMutable>): UsageRankView[] => [...table.values()]
    .sort((left, right) => right.calls - left.calls || right.tokens - left.tokens || left.id.localeCompare(right.id))
    .map(row => ({ ...row, cost: { ...row.cost } }))

  return {
    generatedAt: now,
    query: { ...query },
    kpis: {
      calls: activity.reduce((sum, day) => sum + day.calls, 0),
      sessions: sessionIds.size,
      totalTokens,
      peakDailyTokens: activity.reduce((peak, day) => Math.max(peak, day.tokens), 0),
      longestSessionMs,
      currentStreakDays: streak.current,
      longestStreakDays: streak.longest,
    },
    usage,
    cost: { ...cost },
    callRoles: {
      main: { ...callRoles.main, cost: { ...callRoles.main.cost } },
      visionFallback: { ...callRoles.visionFallback, cost: { ...callRoles.visionFallback.cost } },
    },
    activity,
    providers: ranked(providers),
    models: ranked(models),
    tools: ranked(tools),
    availableProviders: [...availableProviders].map(([id, label]) => ({ id, label })),
    catalogVersion,
    prices,
  }
}
