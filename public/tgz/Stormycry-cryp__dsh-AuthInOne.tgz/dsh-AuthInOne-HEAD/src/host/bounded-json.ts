/** Host-side JSON response readers with an incremental byte ceiling. */

/**
 * Fetch one upstream resource without following redirects that could cross a credential origin.
 *
 * @param input Upstream request URL.
 * @param init Request metadata, including Host-only headers.
 * @param request Fetch implementation used by tests and the runtime.
 * @returns The first upstream response.
 */
export function fetchNoRedirect(input: RequestInfo | URL, init: RequestInit, request: typeof fetch = fetch): Promise<Response> {
  return request(input, { ...init, redirect: 'error' })
}

/**
 * Read a JSON response without buffering more than the configured byte limit.
 *
 * @param response Upstream response whose body is not yet consumed.
 * @param maxBytes Maximum accepted encoded response size.
 * @returns Parsed JSON, or `undefined` for an empty, oversized, or malformed body.
 */
export async function readBoundedJson(response: Response, maxBytes: number): Promise<unknown> {
  const declared = Number(response.headers.get('content-length'))
  if (Number.isFinite(declared) && declared > maxBytes) return undefined
  const reader = response.body?.getReader()
  if (reader === undefined) return undefined
  const chunks: Uint8Array[] = []
  let total = 0
  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      total += value.byteLength
      if (total > maxBytes) {
        await reader.cancel().catch(() => {
          // Cancellation is best-effort after the response is already rejected.
        })
        return undefined
      }
      chunks.push(value)
    }
  } finally {
    reader.releaseLock()
  }
  const body = new Uint8Array(total)
  let offset = 0
  for (const chunk of chunks) {
    body.set(chunk, offset)
    offset += chunk.byteLength
  }
  try {
    return JSON.parse(new TextDecoder().decode(body)) as unknown
  } catch {
    return undefined
  }
}
