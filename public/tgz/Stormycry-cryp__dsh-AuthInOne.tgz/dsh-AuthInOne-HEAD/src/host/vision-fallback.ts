/** Image-description fallback for text-only main-model requests. */

import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import {
  BlockAssembler,
  createUserMessage,
  deepFreeze,
  freezeMessage,
  isAgentLoopRequest,
  type ContentBlock,
  type GenerateOptions,
  type Message,
  type StreamChunk,
  type TokenUsage,
} from '@deepseek-ai/dsh-llm'
import type { Session } from '@deepseek-ai/dsh-session'

/** Persisted configuration for the optional vision fallback. */
export interface VisionFallbackConfig {
  enabled?: boolean
  provider?: string
  model?: string
  maxOutputTokens?: number
  timeoutMs?: number
}

/** Browser-safe resolved configuration and selectable vision routes. */
export interface VisionFallbackView {
  readonly enabled: boolean
  readonly provider: string
  readonly model: string
  readonly maxOutputTokens: number
  readonly timeoutMs: number
  readonly selectionAvailable: boolean
  readonly routes: readonly {
    readonly provider: string
    readonly providerName: string
    readonly model: string
    readonly modelName: string
    readonly accessType: 'account-auth' | 'api' | 'custom-api'
    readonly accountLabel: string | null
  }[]
}

/** Redacted Provider-instance facts used to filter and label vision candidates. */
export interface VisionProviderInstance {
  readonly id: string
  readonly name: string
  readonly active: boolean
  readonly configured: boolean
  readonly credentialConfigured: boolean | null
  readonly accessType: 'account-auth' | 'api' | 'custom-api'
  readonly accountLabel: string | null
}

interface VisionRoute {
  readonly provider: string
  readonly model: string
}

interface VisionRequestSource {
  readonly kind: 'auth-in-one-vision-request'
  readonly form: 'notice'
  readonly summary: string
  readonly requestId: string
  readonly sourceMessageId: string
  readonly route: VisionRoute
  readonly promptVersion: 1
  readonly maxOutputTokens: number
}

interface VisionResultSource {
  readonly kind: 'auth-in-one-vision-result'
  readonly form: 'notice'
  readonly summary: string
  readonly requestId: string
  readonly sourceMessageId: string
  readonly route: VisionRoute
  readonly status: 'success' | 'error'
  readonly usage?: TokenUsage
  readonly errorCode?: string
}

declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'auth-in-one-vision-request': VisionRequestSource
    'auth-in-one-vision-result': VisionResultSource
  }
}

const DEFAULT_MAX_OUTPUT_TOKENS = 512
const DEFAULT_TIMEOUT_MS = 60_000
const PROMPT = [
  'Describe the supplied image or images for a text-only coding assistant.',
  'Preserve visible text, layout, objects, relationships, state, and details relevant to the user request.',
  'When there are multiple images, distinguish them in order and compare them when useful.',
  'Return description text only. Do not claim details that are not visible.',
].join('\n')

/** Resolve optional fields into bounded runtime policy. */
export function resolveVisionFallbackConfig(config: VisionFallbackConfig | undefined): Required<VisionFallbackConfig> {
  const maxOutputTokens = config?.maxOutputTokens ?? DEFAULT_MAX_OUTPUT_TOKENS
  const timeoutMs = config?.timeoutMs ?? DEFAULT_TIMEOUT_MS
  if (!Number.isSafeInteger(maxOutputTokens) || maxOutputTokens < 64 || maxOutputTokens > 4_096) {
    throw new Error('vision fallback maxOutputTokens must be an integer from 64 through 4096')
  }
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1_000 || timeoutMs > 300_000) {
    throw new Error('vision fallback timeoutMs must be an integer from 1000 through 300000')
  }
  return {
    enabled: config?.enabled ?? false,
    provider: config?.provider?.trim() ?? '',
    model: config?.model?.trim() ?? '',
    maxOutputTokens,
    timeoutMs,
  }
}

function isHelper(message: Message): boolean {
  return message.source.kind === 'auth-in-one-vision-request'
    || message.source.kind === 'auth-in-one-vision-result'
}

function imagesOf(blocks: readonly ContentBlock[]): ContentBlock[] {
  const images: ContentBlock[] = []
  for (const block of blocks) {
    if (block.type === 'image') images.push(block)
    else if (block.type === 'tool-result') images.push(...imagesOf(block.content))
  }
  return images
}

function textOf(blocks: readonly ContentBlock[]): string {
  return blocks.map((block) => {
    if (block.type === 'text') return block.text
    if (block.type === 'tool-result') return textOf(block.content)
    return ''
  }).filter(Boolean).join('\n')
}

function withoutImages(blocks: readonly ContentBlock[]): ContentBlock[] {
  return blocks.flatMap((block): ContentBlock[] => {
    if (block.type === 'image') return []
    if (block.type === 'tool-result') return [{ ...block, content: withoutImages(block.content) }]
    return [block]
  })
}

function successfulResult(session: Session, sourceMessageId: string): Message | undefined {
  for (let index = session.events.length - 1; index >= 0; index -= 1) {
    const event = session.events[index]
    if (event?.type !== 'user/message') continue
    const source = event.data.source
    if (source.kind === 'auth-in-one-vision-result'
      && source.sourceMessageId === sourceMessageId
      && source.status === 'success') return event.data
  }
  return undefined
}

function existingRequest(session: Session, sourceMessageId: string, route: VisionRoute): Message | undefined {
  for (let index = session.events.length - 1; index >= 0; index -= 1) {
    const event = session.events[index]
    if (event?.type !== 'user/message') continue
    const source = event.data.source
    if (source.kind === 'auth-in-one-vision-request'
      && source.sourceMessageId === sourceMessageId
      && source.route.provider === route.provider
      && source.route.model === route.model) return event.data
  }
  return undefined
}

function appendUserMessage(session: Session, message: Message): Message {
  return session.append('user/message', message as Extract<Message, { role: 'user' }>, { surfaceOp: 'append' }).data
}

function terminalFailure(assembler: BlockAssembler): { code: string; message: string } | undefined {
  const finish = assembler.finish
  if (finish.kind === 'stop') return undefined
  if (finish.kind === 'error' || finish.kind === 'aborted') {
    return { code: finish.failure.code, message: finish.failure.message }
  }
  return { code: 'VISION_FALLBACK_INCOMPLETE', message: `vision fallback ended with ${finish.kind}` }
}

function safeFailure(code: string): StreamChunk {
  return {
    type: 'finish',
    reason: {
      kind: 'error',
      failure: {
        code: 'VISION_FALLBACK_FAILED',
        message: `Vision fallback failed (${code}). Check its Provider, model, and Host credential, then retry.`,
      },
    },
  }
}

/** List exact routes whose adapter explicitly declares image input. */
export async function listVisionRoutes(
  ctx: Context,
  instances?: readonly VisionProviderInstance[],
): Promise<VisionFallbackView['routes']> {
  const routes: Array<VisionFallbackView['routes'][number]> = []
  const usable = instances === undefined
    ? ctx.llm.listProviders().map(provider => ({
        id: provider.id, name: provider.name, active: true, configured: true,
        credentialConfigured: null, accessType: 'api' as const, accountLabel: null,
      }))
    : instances.filter(instance => instance.active && instance.configured && instance.credentialConfigured !== false)
  for (const provider of usable) {
    let models: Awaited<ReturnType<typeof ctx.llm.listModels>>
    try {
      models = await ctx.llm.listModels(provider.id)
    } catch {
      continue
    }
    for (const model of models) {
      try {
        const info = await ctx.llm.resolveModelInfo(provider.id, model.id)
        if (info.inputModalities?.includes('image') !== true) continue
        routes.push({
          provider: provider.id,
          providerName: provider.name,
          model: model.id,
          modelName: model.name,
          accessType: provider.accessType,
          accountLabel: provider.accountLabel,
        })
      } catch {
        // A single unavailable catalog entry does not hide other proven routes.
      }
    }
  }
  return routes
}

/** Install the request middleware without changing DSH's agent loop. */
export function installVisionFallback(
  ctx: Context,
  config: () => VisionFallbackConfig | undefined,
): void {
  const routed = new WeakSet<GenerateOptions>()

  ctx.on('llm/stream', (options, next): AsyncIterable<StreamChunk> => {
    if (routed.has(options) || !isAgentLoopRequest(options)) return next()

    return (async function* (): AsyncGenerator<StreamChunk> {
      const session = options.sessionId === undefined ? undefined : ctx.sessions.get(options.sessionId)
      if (session === undefined) {
        yield* next()
        return
      }
      const helperFree = options.messages.filter(message => !isHelper(message))
      const imageMessages = helperFree.filter(message => imagesOf(message.content).length > 0)
      if (imageMessages.length === 0) {
        if (helperFree.length === options.messages.length) yield* next()
        else {
          const clean = deepFreeze({ ...options, messages: helperFree })
          routed.add(clean)
          yield* ctx.llm.stream(clean)
        }
        return
      }

      const mainInfo = await ctx.llm.resolveModelInfo(options.provider, options.model, options.signal)
      if (mainInfo.inputModalities === undefined || mainInfo.inputModalities.includes('image')) {
        if (helperFree.length === options.messages.length) yield* next()
        else {
          const clean = deepFreeze({ ...options, messages: helperFree })
          routed.add(clean)
          yield* ctx.llm.stream(clean)
        }
        return
      }

      const policy = resolveVisionFallbackConfig(config())
      if (!policy.enabled) {
        yield* next()
        return
      }
      if (policy.provider.length === 0 || policy.model.length === 0) {
        yield safeFailure('VISION_FALLBACK_NOT_CONFIGURED')
        return
      }
      const fallbackInfo = await ctx.llm.resolveModelInfo(policy.provider, policy.model, options.signal)
      if (fallbackInfo.inputModalities?.includes('image') !== true) {
        yield safeFailure('VISION_FALLBACK_MODEL_HAS_NO_IMAGE_CAPABILITY')
        return
      }

      const descriptions = new Map<string, string>()
      for (const sourceMessage of imageMessages) {
        const sourceMessageId = String(sourceMessage.id)
        const cached = successfulResult(session, sourceMessageId)
        if (cached !== undefined) {
          descriptions.set(sourceMessageId, textOf(cached.content))
          continue
        }

        const route = { provider: policy.provider, model: policy.model }
        let requestMessage = existingRequest(session, sourceMessageId, route)
        if (requestMessage === undefined) {
          const requestId = randomUUID()
          requestMessage = appendUserMessage(session, createUserMessage({
            content: [
              { type: 'text', text: PROMPT },
              ...imagesOf(sourceMessage.content),
            ],
            source: {
              kind: 'auth-in-one-vision-request',
              form: 'notice',
              summary: 'Vision fallback request',
              requestId,
              sourceMessageId,
              route,
              promptVersion: 1,
              maxOutputTokens: policy.maxOutputTokens,
            },
          }))
        }
        const requestSource = requestMessage.source
        if (requestSource.kind !== 'auth-in-one-vision-request') throw new Error('vision fallback request provenance was lost')
        const deadline = AbortSignal.timeout(policy.timeoutMs)
        const signal = options.signal === undefined ? deadline : AbortSignal.any([options.signal, deadline])
        const sessionId = options.sessionId
        if (sessionId === undefined) throw new Error('vision fallback lost the owning session identity')
        const auxiliary = deepFreeze<GenerateOptions>({
          provider: policy.provider,
          model: policy.model,
          messages: [requestMessage],
          maxTokens: policy.maxOutputTokens,
          sessionId,
          signal,
        })
        routed.add(auxiliary)
        const assembler = new BlockAssembler()
        for await (const chunk of ctx.llm.stream(auxiliary)) assembler.push(chunk)
        const failure = terminalFailure(assembler)
        const description = assembler.blocks()
          .filter((block): block is Extract<ContentBlock, { type: 'text' }> => block.type === 'text')
          .map(block => block.text)
          .join('\n').trim()
        if (failure !== undefined || description.length === 0) {
          const code = failure?.code ?? 'VISION_FALLBACK_EMPTY_RESPONSE'
          appendUserMessage(session, createUserMessage({
            content: [{ type: 'text', text: `Vision fallback failed (${code}).` }],
            source: {
              kind: 'auth-in-one-vision-result',
              form: 'notice',
              summary: 'Vision fallback failed',
              requestId: requestSource.requestId,
              sourceMessageId,
              route,
              status: 'error',
              ...assembler.usage === undefined ? {} : { usage: assembler.usage },
              errorCode: code,
            },
          }))
          yield safeFailure(code)
          return
        }
        appendUserMessage(session, createUserMessage({
          content: [{ type: 'text', text: description }],
          source: {
            kind: 'auth-in-one-vision-result',
            form: 'notice',
            summary: 'Vision fallback description',
            requestId: requestSource.requestId,
            sourceMessageId,
            route,
            status: 'success',
            ...assembler.usage === undefined ? {} : { usage: assembler.usage },
          },
        }))
        descriptions.set(sourceMessageId, description)
      }

      const transformed = helperFree.map((message): Message => {
        const description = descriptions.get(String(message.id))
        if (description === undefined) return message
        return freezeMessage({
          id: message.id,
          role: message.role,
          content: [
            ...withoutImages(message.content),
            { type: 'text', text: `\n[Vision fallback description]\n${description}` },
          ],
          source: message.source,
        })
      })
      const request = deepFreeze({ ...options, messages: transformed })
      routed.add(request)
      yield* ctx.llm.stream(request)
    })()
  })
}
