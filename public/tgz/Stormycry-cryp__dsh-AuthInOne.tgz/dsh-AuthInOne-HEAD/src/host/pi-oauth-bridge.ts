/** DSH-owned transaction wrapper around the installed pi-ai OAuth protocol implementations. */

import { AuthProtocolError, type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts'

interface BridgeOAuthCredential {
  readonly type: 'oauth'
  readonly access: string
  readonly refresh: string
  readonly expires: number
  readonly [key: string]: unknown
}

type BridgeAuthEvent =
  | { readonly type: 'auth_url'; readonly url: string; readonly instructions?: string }
  | { readonly type: 'device_code'; readonly userCode: string; readonly verificationUri: string; readonly intervalSeconds?: number; readonly expiresInSeconds?: number }
  | { readonly type: 'info' | 'progress'; readonly message: string }

type BridgeAuthPrompt = { readonly signal?: AbortSignal } & (
  | { readonly type: 'text' | 'secret' | 'manual_code'; readonly message: string; readonly placeholder?: string }
  | { readonly type: 'select'; readonly message: string; readonly options: readonly { readonly id: string; readonly label: string }[] }
)

/** Structural subset of pi-ai's OAuth flow used without delegating storage. */
export interface BridgeOAuthAuth {
  login(interaction: {
    readonly signal?: AbortSignal
    prompt(prompt: BridgeAuthPrompt): Promise<string>
    notify(event: BridgeAuthEvent): void
  }): Promise<BridgeOAuthCredential>
  refresh(credential: BridgeOAuthCredential, signal?: AbortSignal): Promise<BridgeOAuthCredential>
}

function publicError(error: unknown): AuthProtocolError {
  const message = error instanceof Error ? error.message.toLowerCase() : ''
  if (message.includes('denied') || message.includes('access_denied')) return new AuthProtocolError('denied')
  if (message.includes('expired')) return new AuthProtocolError('expired')
  if (message.includes('state') && message.includes('mismatch')) return new AuthProtocolError('state-mismatch')
  if (message.includes('cancel') || message.includes('abort')) return new AuthProtocolError('cancelled')
  if (message.includes('invalid_grant') || message.includes('unauthorized') || message.includes('401') || message.includes('403')) {
    return new AuthProtocolError('refresh-rejected')
  }
  return new AuthProtocolError('network')
}

function stored(value: BridgeOAuthCredential): StoredOAuthCredential {
  if (!value.access || !value.refresh || !Number.isFinite(value.expires) || value.expires <= 0) {
    throw new AuthProtocolError('invalid-response')
  }
  const providerData = Object.fromEntries(Object.entries(value).filter(([key, entry]) => (
    key !== 'type' && key !== 'access' && key !== 'refresh' && key !== 'expires'
    && (typeof entry === 'string' || typeof entry === 'number' || typeof entry === 'boolean'
      || (Array.isArray(entry) && entry.length <= 512 && entry.every(item => typeof item === 'string')))
  ))) as Record<string, string | number | boolean | readonly string[]>
  return {
    version: 1, accessToken: value.access, refreshToken: value.refresh, expiresAt: value.expires,
    ...Object.keys(providerData).length === 0 ? {} : { providerData },
  }
}

function oauthCredential(value: StoredOAuthCredential): BridgeOAuthCredential {
  return {
    type: 'oauth', access: value.accessToken, refresh: value.refreshToken, expires: value.expiresAt,
    ...value.providerData,
  }
}

/** Converts one pi-ai protocol flow into the plugin's Host-only adapter contract. */
export class PiOAuthBridgeAdapter implements AuthProviderAdapter {
  constructor(
    readonly id: string,
    readonly name: string,
    private readonly oauth: BridgeOAuthAuth,
  ) {}

  async start(signal?: AbortSignal): Promise<AuthLoginHandle> {
    const controller = new AbortController()
    const combined = signal === undefined ? controller.signal : AbortSignal.any([controller.signal, signal])
    let resolveReady!: (value: Omit<AuthLoginHandle, 'completion' | 'cancel'>) => void
    let rejectReady!: (error: unknown) => void
    let readySettled = false
    let manualPrompt: { readonly message: string; readonly placeholder?: string } | undefined
    let submitManual: ((value: string) => void) | undefined
    const ready = new Promise<Omit<AuthLoginHandle, 'completion' | 'cancel'>>((resolve, reject) => {
      resolveReady = resolve
      rejectReady = reject
    })
    const notify = (event: BridgeAuthEvent): void => {
      if (readySettled) return
      if (event.type === 'auth_url') {
        readySettled = true
        resolveReady({ authorizationUrl: event.url, expiresAt: Date.now() + 10 * 60 * 1000 })
      } else if (event.type === 'device_code') {
        readySettled = true
        resolveReady({
          authorizationUrl: event.verificationUri,
          verificationUrl: event.verificationUri,
          userCode: event.userCode,
          expiresAt: Date.now() + (event.expiresInSeconds ?? 15 * 60) * 1_000,
        })
      }
    }
    const prompt = (request: BridgeAuthPrompt): Promise<string> => {
      if (request.type === 'text' && request.message.toLowerCase().includes('enterprise')) return Promise.resolve('')
      if (request.type !== 'manual_code') return Promise.reject(new AuthProtocolError('invalid-response'))
      manualPrompt = { message: request.message, ...request.placeholder === undefined ? {} : { placeholder: request.placeholder } }
      return new Promise((resolve, reject) => {
        const promptSignal = request.signal === undefined ? combined : AbortSignal.any([combined, request.signal])
        if (promptSignal.aborted) {
          reject(new AuthProtocolError('cancelled'))
          return
        }
        const abort = (): void => { reject(new AuthProtocolError('cancelled')) }
        promptSignal.addEventListener('abort', abort, { once: true })
        submitManual = value => {
          promptSignal.removeEventListener('abort', abort)
          submitManual = undefined
          resolve(value)
        }
      })
    }
    const completion = this.oauth.login({ signal: combined, prompt, notify }).then(stored, error => {
      const publicFailure = publicError(error)
      if (!readySettled) {
        readySettled = true
        rejectReady(publicFailure)
      }
      throw publicFailure
    })
    void completion.catch(() => undefined)
    const instructions = await ready
    await Promise.resolve()
    return {
      ...instructions,
      ...manualPrompt === undefined ? {} : {
        inputPrompt: {
          kind: 'authorization-code' as const,
          label: manualPrompt.message,
          ...manualPrompt.placeholder === undefined ? {} : { placeholder: manualPrompt.placeholder },
        },
        submit: (value: string) => {
          if (submitManual === undefined) throw new AuthProtocolError('invalid-response')
          submitManual(value)
        },
      },
      completion,
      cancel: () => { controller.abort() },
    }
  }

  async refresh(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential> {
    try {
      return stored(await this.oauth.refresh(oauthCredential(credential), signal))
    } catch (error) {
      throw publicError(error)
    }
  }

  revoke(_credential: StoredOAuthCredential, _signal?: AbortSignal): Promise<void> {
    // These compatibility protocols expose local logout but no common revocation method.
    return Promise.resolve()
  }
}
