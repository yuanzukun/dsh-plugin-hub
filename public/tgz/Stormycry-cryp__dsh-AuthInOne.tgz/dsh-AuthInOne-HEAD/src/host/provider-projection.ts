import type { AuthProviderView } from '../types.ts'

/** Facts that distinguish one configured Provider instance from an Auth catalog entry. */
export interface ProviderProjectionFacts {
  readonly provider: string
  readonly hasLiveRoute: boolean
  readonly hasProfile: boolean
  readonly authStatus: AuthProviderView['status'] | null
}

/** Return whether Models should expose a real Provider instance. */
export function shouldProjectProviderConnection(facts: ProviderProjectionFacts): boolean {
  return facts.provider === 'deepseek-official'
    || facts.hasLiveRoute
    || facts.hasProfile
    || facts.authStatus === 'connected'
    || facts.authStatus === 'needs-reauth'
}

/** Return whether an Auth state represents a stored account instance rather than a catalog transaction. */
export function isAuthProviderInstance(status: AuthProviderView['status']): boolean {
  return status === 'connected' || status === 'needs-reauth'
}
