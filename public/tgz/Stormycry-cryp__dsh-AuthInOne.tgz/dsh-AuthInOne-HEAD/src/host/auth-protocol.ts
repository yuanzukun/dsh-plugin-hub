/** Host-only OAuth protocol adapter for the official OpenAI Codex browser flow. */

import { createHash, randomBytes } from 'node:crypto'
import { createServer, type RequestListener, type Server } from 'node:http'
import type { AuthErrorCategory } from '../types.ts'

const DEFAULT_ISSUER = 'https://auth.openai.com'
const DEFAULT_CLIENT_ID = 'app_EMoamEEZ73f0CkXaXp7hrann'
const DEFAULT_PORTS = [1455, 1457] as const
const CALLBACK_PATH = '/auth/callback'
const AUTH_TIMEOUT_MS = 5 * 60 * 1000
const TOKEN_REQUEST_TIMEOUT_MS = 15 * 1000
const REFRESH_EARLY_MS = 60 * 1000
const MAX_TOKEN_RESPONSE_BYTES = 64 * 1024

const ERROR_MESSAGES: Record<AuthErrorCategory, string> = {
  cancelled: 'Authorization was cancelled.',
  expired: 'Authorization expired before it completed.',
  denied: 'OpenAI did not authorize this request.',
  'state-mismatch': 'The authorization callback did not match this login attempt.',
  'callback-unavailable': 'The local authorization callback could not start.',
  'token-exchange-failed': 'OpenAI rejected the authorization-code exchange.',
  'refresh-rejected': 'OpenAI rejected the stored refresh credential. Sign in again.',
  network: 'The Provider authorization service could not be reached.',
  'revocation-failed': 'The local credential was removed, but OpenAI could not confirm revocation.',
  'invalid-response': 'OpenAI returned an invalid authorization response.',
}

/** Error that carries only an allowlisted category and fixed public message. */
export class AuthProtocolError extends Error {
  constructor(readonly category: AuthErrorCategory) {
    super(ERROR_MESSAGES[category])
    this.name = 'AuthProtocolError'
  }
}

/** Host-only credential representation persisted through DSH credentials. */
export interface StoredOAuthCredential {
  readonly version: 1
  readonly accessToken: string
  readonly refreshToken: string
  readonly expiresAt: number
  readonly accountId?: string
  readonly email?: string
  /** Provider-specific Host-only request metadata; never projected through Remote DTOs. */
  readonly providerData?: Readonly<Record<string, string | number | boolean | readonly string[]>>
  readonly needsReauth?: true
}

/** Started login whose completion settles after the loopback callback. */
export interface AuthLoginHandle {
  readonly authorizationUrl: string
  readonly verificationUrl?: string
  readonly userCode?: string
  readonly inputPrompt?: {
    readonly kind: 'authorization-code'
    readonly label: string
    readonly placeholder?: string
  }
  readonly expiresAt: number
  readonly completion: Promise<StoredOAuthCredential>
  submit?(value: string): void
  cancel(): void
}

/** Host-only protocol operations implemented by an Auth Provider. */
export interface AuthProviderAdapter {
  readonly id: string
  readonly name: string
  start(signal?: AbortSignal): Promise<AuthLoginHandle>
  refresh(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>
  revoke(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<void>
}

export interface OpenAICodexOAuthOptions {
  readonly issuer?: string
  readonly clientId?: string
  readonly ports?: readonly number[]
  readonly timeoutMs?: number
  readonly requestTimeoutMs?: number
  readonly fetch?: typeof fetch
  readonly now?: () => number
}

interface TokenPayload {
  readonly access_token?: unknown
  readonly refresh_token?: unknown
  readonly expires_in?: unknown
  readonly id_token?: unknown
  readonly error?: unknown
}

function base64Url(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString('base64url')
}

function pkce(): { verifier: string; challenge: string } {
  const verifier = base64Url(randomBytes(64))
  const challenge = createHash('sha256').update(verifier).digest('base64url')
  return { verifier, challenge }
}

function decodeJwt(token: string | undefined): Record<string, unknown> | undefined {
  if (token === undefined) return undefined
  const parts = token.split('.')
  if (parts.length !== 3 || parts[1] === undefined) return undefined
  try {
    const parsed: unknown = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'))
    return typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)
      ? parsed as Record<string, unknown>
      : undefined
  } catch {
    return undefined
  }
}

function tokenIdentity(idToken: string | undefined, accessToken: string): Pick<StoredOAuthCredential, 'accountId' | 'email'> {
  let email: string | undefined
  let accountId: string | undefined
  for (const token of [idToken, accessToken]) {
    const claims = decodeJwt(token)
    if (claims === undefined) continue
    if (email === undefined && typeof claims.email === 'string') email = claims.email.toLowerCase()
    if (accountId === undefined && typeof claims.chatgpt_account_id === 'string') accountId = claims.chatgpt_account_id
    const namespace = claims['https://api.openai.com/auth']
    if (accountId === undefined && typeof namespace === 'object' && namespace !== null
      && typeof (namespace as Record<string, unknown>).chatgpt_account_id === 'string') {
      accountId = (namespace as Record<string, unknown>).chatgpt_account_id as string
    }
  }
  return {
    ...accountId === undefined ? {} : { accountId },
    ...email === undefined ? {} : { email },
  }
}

function jwtExpiry(token: string | undefined): number | undefined {
  const exp = decodeJwt(token)?.exp
  return typeof exp === 'number' && Number.isFinite(exp) && exp > 0 ? exp * 1000 : undefined
}

function credentialFromPayload(
  payload: TokenPayload,
  now: number,
  previous?: StoredOAuthCredential,
): StoredOAuthCredential {
  if (typeof payload.access_token !== 'string' || payload.access_token.length === 0) {
    throw new AuthProtocolError('invalid-response')
  }
  const refreshToken = typeof payload.refresh_token === 'string' && payload.refresh_token.length > 0
    ? payload.refresh_token
    : previous?.refreshToken
  if (refreshToken === undefined) throw new AuthProtocolError('invalid-response')
  const idToken = typeof payload.id_token === 'string' && payload.id_token.length > 0 ? payload.id_token : undefined
  const duration = typeof payload.expires_in === 'number' && Number.isFinite(payload.expires_in) && payload.expires_in > 0
    ? payload.expires_in * 1000
    : undefined
  const expiresAt = duration === undefined
    ? jwtExpiry(payload.access_token) ?? jwtExpiry(idToken) ?? now + 60 * 60 * 1000
    : now + duration
  const identity = tokenIdentity(idToken, payload.access_token)
  const accountId = identity.accountId ?? previous?.accountId
  const email = identity.email ?? previous?.email
  return {
    version: 1,
    accessToken: payload.access_token,
    refreshToken,
    expiresAt,
    ...accountId === undefined ? {} : { accountId },
    ...email === undefined ? {} : { email },
  }
}

async function boundedJson(response: Response): Promise<TokenPayload> {
  const declared = Number(response.headers.get('content-length'))
  if (Number.isFinite(declared) && declared > MAX_TOKEN_RESPONSE_BYTES) throw new AuthProtocolError('invalid-response')
  const reader = response.body?.getReader()
  if (reader === undefined) return {}
  const chunks: Uint8Array[] = []
  let size = 0
  try {
    while (true) {
      const next = await reader.read()
      if (next.done) break
      size += next.value.byteLength
      if (size > MAX_TOKEN_RESPONSE_BYTES) throw new AuthProtocolError('invalid-response')
      chunks.push(next.value)
    }
  } finally {
    reader.releaseLock()
  }
  const bytes = new Uint8Array(size)
  let offset = 0
  for (const chunk of chunks) {
    bytes.set(chunk, offset)
    offset += chunk.byteLength
  }
  try {
    const parsed: unknown = JSON.parse(new TextDecoder().decode(bytes))
    return typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed) ? parsed as TokenPayload : {}
  } catch {
    return {}
  }
}

function terminalRefresh(payload: TokenPayload): boolean {
  return payload.error === 'invalid_grant'
    || payload.error === 'refresh_token_expired'
    || payload.error === 'refresh_token_reused'
    || payload.error === 'refresh_token_invalidated'
}

function boundedSignal(timeoutMs: number, signal?: AbortSignal): AbortSignal {
  const timeout = AbortSignal.timeout(timeoutMs)
  return signal === undefined ? timeout : AbortSignal.any([signal, timeout])
}

function html(title: string, message: string): string {
  const escape = (value: string): string => value.replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character] ?? character)
  return `<!doctype html><html><head><meta charset="utf-8"><title>${escape(title)}</title></head><body><main><h1>${escape(title)}</h1><p>${escape(message)}</p></main></body></html>`
}

function close(server: Server): Promise<void> {
  return new Promise(resolve => {
    if (!server.listening) {
      resolve()
      return
    }
    server.close(() => { resolve() })
  })
}

async function listen(server: Server, port: number, host: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const onError = (error: Error): void => { server.off('listening', onListening); reject(error) }
    const onListening = (): void => { server.off('error', onError); resolve() }
    server.once('error', onError)
    server.once('listening', onListening)
    server.listen(port, host)
  })
}

function errorCode(error: unknown): string | undefined {
  return typeof error === 'object' && error !== null && 'code' in error
    ? String((error as { code?: unknown }).code)
    : undefined
}

interface CallbackServers {
  readonly port: number
  readonly servers: Server[]
}

async function bindLoopback(ports: readonly number[], handler: RequestListener): Promise<CallbackServers> {
  for (const port of ports) {
    if (!Number.isInteger(port) || port < 0 || port > 65535) continue
    const ipv4 = createServer(handler)
    try {
      await listen(ipv4, port, '127.0.0.1')
    } catch {
      await close(ipv4).catch(() => undefined)
      continue
    }
    const address = ipv4.address()
    if (address === null || typeof address === 'string') {
      await close(ipv4)
      continue
    }
    const boundPort = address.port
    const servers = [ipv4]
    const ipv6 = createServer(handler)
    try {
      await listen(ipv6, boundPort, '::1')
      servers.push(ipv6)
    } catch (error) {
      await close(ipv6).catch(() => undefined)
      if (errorCode(error) === 'EADDRINUSE') {
        await Promise.all(servers.map(server => close(server).catch(() => undefined)))
        continue
      }
    }
    return { port: boundPort, servers }
  }
  throw new AuthProtocolError('callback-unavailable')
}

/** Official OpenAI Codex OAuth browser adapter with Host-owned state and PKCE. */
export class OpenAICodexOAuthAdapter implements AuthProviderAdapter {
  readonly id = 'openai-codex'
  readonly name = 'OpenAI Codex'
  private readonly issuer: string
  private readonly clientId: string
  private readonly ports: readonly number[]
  private readonly timeoutMs: number
  private readonly requestTimeoutMs: number
  private readonly request: typeof fetch
  private readonly now: () => number

  constructor(options: OpenAICodexOAuthOptions = {}) {
    this.issuer = (options.issuer ?? DEFAULT_ISSUER).replace(/\/+$/, '')
    this.clientId = options.clientId ?? DEFAULT_CLIENT_ID
    this.ports = options.ports ?? DEFAULT_PORTS
    this.timeoutMs = options.timeoutMs ?? AUTH_TIMEOUT_MS
    this.requestTimeoutMs = options.requestTimeoutMs ?? TOKEN_REQUEST_TIMEOUT_MS
    this.request = options.fetch ?? fetch
    this.now = options.now ?? Date.now
  }

  async start(signal?: AbortSignal): Promise<AuthLoginHandle> {
    const state = base64Url(randomBytes(32))
    const codes = pkce()
    const controller = new AbortController()
    const combined = signal === undefined
      ? AbortSignal.any([controller.signal, AbortSignal.timeout(this.timeoutMs)])
      : AbortSignal.any([controller.signal, signal, AbortSignal.timeout(this.timeoutMs)])
    let settle!: (value: StoredOAuthCredential) => void
    let reject!: (reason: unknown) => void
    const completion = new Promise<StoredOAuthCredential>((resolve, rejectPromise) => {
      settle = resolve
      reject = rejectPromise
    })
    let consumed = false
    let servers: Server[] = []
    let redirectUri = ''
    const finish = async (error?: unknown, credential?: StoredOAuthCredential): Promise<void> => {
      if (consumed) return
      consumed = true
      await Promise.all(servers.map(server => close(server).catch(() => undefined)))
      if (credential !== undefined) settle(credential)
      else reject(error ?? new AuthProtocolError('cancelled'))
    }
    const handler: RequestListener = async (request, response) => {
      const url = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`)
      if (url.pathname !== CALLBACK_PATH) {
        response.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', connection: 'close' })
        response.end('Not Found')
        return
      }
      const callbackState = url.searchParams.get('state')
      if (callbackState !== state) {
        response.writeHead(400, { 'content-type': 'text/html; charset=utf-8', connection: 'close' })
        response.end(html('Authorization failed', ERROR_MESSAGES['state-mismatch']))
        return
      }
      const providerError = url.searchParams.get('error')
      if (providerError !== null) {
        response.writeHead(400, { 'content-type': 'text/html; charset=utf-8', connection: 'close' })
        response.end(html('Authorization declined', ERROR_MESSAGES.denied))
        await finish(new AuthProtocolError('denied'))
        return
      }
      const code = url.searchParams.get('code')
      if (code === null || code.length === 0) {
        response.writeHead(400, { 'content-type': 'text/html; charset=utf-8', connection: 'close' })
        response.end(html('Authorization failed', ERROR_MESSAGES['invalid-response']))
        return
      }
      try {
        if (redirectUri.length === 0) throw new AuthProtocolError('callback-unavailable')
        const credential = await this.exchange(code, codes.verifier, redirectUri, combined)
        response.writeHead(200, { 'content-type': 'text/html; charset=utf-8', connection: 'close' })
        response.end(html('Authorization complete', 'Return to DeepSeek Harness to continue.'))
        await finish(undefined, credential)
      } catch (error) {
        response.writeHead(502, { 'content-type': 'text/html; charset=utf-8', connection: 'close' })
        response.end(html('Authorization failed', error instanceof AuthProtocolError ? error.message : ERROR_MESSAGES.network))
        await finish(error instanceof AuthProtocolError ? error : new AuthProtocolError('network'))
      }
    }
    const bound = await bindLoopback(this.ports, handler)
    servers = bound.servers
    redirectUri = `http://localhost:${String(bound.port)}${CALLBACK_PATH}`
    const query = new URLSearchParams({
      response_type: 'code',
      client_id: this.clientId,
      redirect_uri: redirectUri,
      scope: 'openid profile email offline_access api.connectors.read api.connectors.invoke',
      code_challenge: codes.challenge,
      code_challenge_method: 'S256',
      id_token_add_organizations: 'true',
      codex_cli_simplified_flow: 'true',
      state,
      originator: 'codex_cli_rs',
    })
    const abort = (): void => {
      const category: AuthErrorCategory = controller.signal.aborted || signal?.aborted === true ? 'cancelled' : 'expired'
      void finish(new AuthProtocolError(category))
    }
    if (combined.aborted) abort()
    else combined.addEventListener('abort', abort, { once: true })
    void completion.finally(() => { combined.removeEventListener('abort', abort) }).catch(() => undefined)
    return {
      authorizationUrl: `${this.issuer}/oauth/authorize?${query.toString()}`,
      expiresAt: this.now() + this.timeoutMs,
      completion,
      cancel: () => { controller.abort() },
    }
  }

  private async exchange(
    code: string,
    verifier: string,
    redirectUri: string,
    signal?: AbortSignal,
  ): Promise<StoredOAuthCredential> {
    let response: Response
    try {
      response = await this.request(`${this.issuer}/oauth/token`, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          code,
          redirect_uri: redirectUri,
          client_id: this.clientId,
          code_verifier: verifier,
        }),
        ...signal === undefined ? {} : { signal },
      })
    } catch {
      throw new AuthProtocolError(signal?.aborted === true ? 'cancelled' : 'network')
    }
    const payload = await boundedJson(response)
    if (!response.ok) throw new AuthProtocolError('token-exchange-failed')
    return credentialFromPayload(payload, this.now())
  }

  async refresh(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential> {
    if (credential.needsReauth === true) throw new AuthProtocolError('refresh-rejected')
    if (credential.expiresAt > this.now() + REFRESH_EARLY_MS) return credential
    let response: Response
    const requestSignal = boundedSignal(this.requestTimeoutMs, signal)
    try {
      response = await this.request(`${this.issuer}/oauth/token`, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'refresh_token',
          client_id: this.clientId,
          refresh_token: credential.refreshToken,
        }),
        signal: requestSignal,
      })
    } catch {
      throw new AuthProtocolError(signal?.aborted === true ? 'cancelled' : 'network')
    }
    const payload = await boundedJson(response)
    if (!response.ok) {
      throw new AuthProtocolError(terminalRefresh(payload) ? 'refresh-rejected' : 'network')
    }
    return credentialFromPayload(payload, this.now(), credential)
  }

  async revoke(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<void> {
    let response: Response
    const requestSignal = boundedSignal(this.requestTimeoutMs, signal)
    try {
      response = await this.request(`${this.issuer}/oauth/revoke`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          token: credential.refreshToken,
          token_type_hint: 'refresh_token',
          client_id: this.clientId,
        }),
        signal: requestSignal,
      })
    } catch {
      throw new AuthProtocolError('revocation-failed')
    }
    await response.body?.cancel().catch(() => undefined)
    if (!response.ok) throw new AuthProtocolError('revocation-failed')
  }
}

/** Stable digest used for compare-and-swap credential updates. */
export function credentialGeneration(credential: StoredOAuthCredential): string {
  return createHash('sha256')
    .update(JSON.stringify([credential.accessToken, credential.refreshToken, credential.expiresAt]))
    .digest('hex')
}
