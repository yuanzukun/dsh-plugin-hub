/** OAuth credential persistence and refresh coordination over DSH credentials. */

import type { Context } from '@deepseek-ai/cordis'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import {
  AuthProtocolError,
  credentialGeneration,
  type AuthProviderAdapter,
  type StoredOAuthCredential,
} from './auth-protocol.ts'

const OPENAI_CODEX_CREDENTIAL_REF = credentialRef('DSH_AUTH_IN_ONE_OPENAI_CODEX_OAUTH')
const REFRESH_EARLY_MS = 60 * 1000

function parseCredential(value: string): StoredOAuthCredential {
  let parsed: unknown
  try {
    parsed = JSON.parse(value)
  } catch {
    throw new AuthProtocolError('invalid-response')
  }
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new AuthProtocolError('invalid-response')
  }
  const row = parsed as Record<string, unknown>
  const providerData = row.providerData
  const validProviderData = providerData === undefined || (
    typeof providerData === 'object' && providerData !== null && !Array.isArray(providerData)
    && Object.entries(providerData).every(([key, entry]) => key.length > 0 && key.length <= 64 && (
      typeof entry === 'string' || typeof entry === 'number' || typeof entry === 'boolean'
      || (Array.isArray(entry) && entry.length <= 512 && entry.every(item => typeof item === 'string'))
    ))
  )
  if (row.version !== 1
    || typeof row.accessToken !== 'string' || row.accessToken.length === 0
    || typeof row.refreshToken !== 'string' || row.refreshToken.length === 0
    || typeof row.expiresAt !== 'number' || !Number.isFinite(row.expiresAt)
    || (row.accountId !== undefined && typeof row.accountId !== 'string')
    || (row.email !== undefined && typeof row.email !== 'string')
    || !validProviderData
    || (row.needsReauth !== undefined && row.needsReauth !== true)) {
    throw new AuthProtocolError('invalid-response')
  }
  return parsed as StoredOAuthCredential
}

/** Store status safe for Host state projection after identity masking. */
export interface AuthCredentialStatus {
  readonly connected: boolean
  readonly needsReauth: boolean
  readonly email?: string
  readonly accountId?: string
}

/** Serializes DSH credential writes and deduplicates refresh for one Provider. */
export class DshOAuthCredentialStore {
  private mutation = Promise.resolve<unknown>(undefined)
  private refreshFlight: Promise<StoredOAuthCredential> | undefined
  private readonly ref

  constructor(private readonly ctx: Context, name = 'DSH_AUTH_IN_ONE_OPENAI_CODEX_OAUTH') {
    this.ref = name === 'DSH_AUTH_IN_ONE_OPENAI_CODEX_OAUTH'
      ? OPENAI_CODEX_CREDENTIAL_REF
      : credentialRef(name)
  }

  async read(): Promise<StoredOAuthCredential | undefined> {
    const resolved = await this.ctx.credentials.resolve(this.ref)
    return resolved === undefined ? undefined : parseCredential(resolved.value)
  }

  private enqueue<T>(task: () => Promise<T>): Promise<T> {
    const next = this.mutation.catch(() => undefined).then(task)
    this.mutation = next.catch(() => undefined)
    return next
  }

  write(credential: StoredOAuthCredential): Promise<void> {
    return this.enqueue(() => this.ctx.credentials.set(this.ref, JSON.stringify(credential)))
  }

  delete(): Promise<void> {
    return this.enqueue(() => this.ctx.credentials.unset(this.ref))
  }

  async status(): Promise<AuthCredentialStatus> {
    const credential = await this.read()
    if (credential === undefined) return { connected: false, needsReauth: false }
    return {
      connected: credential.needsReauth !== true,
      needsReauth: credential.needsReauth === true,
      ...credential.email === undefined ? {} : { email: credential.email },
      ...credential.accountId === undefined ? {} : { accountId: credential.accountId },
    }
  }

  /** Return a fresh access token, rotating the stored refresh token at most once per generation. */
  async accessToken(adapter: AuthProviderAdapter, signal?: AbortSignal): Promise<string> {
    const current = await this.read()
    if (current === undefined || current.needsReauth === true) throw new AuthProtocolError('refresh-rejected')
    if (current.expiresAt > Date.now() + REFRESH_EARLY_MS) return current.accessToken
    if (this.refreshFlight !== undefined) return (await this.refreshFlight).accessToken
    const startedGeneration = credentialGeneration(current)
    const refresh = (async (): Promise<StoredOAuthCredential> => {
      let fresh: StoredOAuthCredential
      try {
        fresh = await adapter.refresh(current, signal)
      } catch (error) {
        if (error instanceof AuthProtocolError && error.category === 'refresh-rejected') {
          await this.enqueue(async () => {
            const stored = await this.read()
            if (stored === undefined || credentialGeneration(stored) !== startedGeneration) return
            await this.ctx.credentials.set(this.ref, JSON.stringify({ ...stored, needsReauth: true }))
          })
        }
        throw error
      }
      return this.enqueue(async () => {
        const stored = await this.read()
        if (stored === undefined) throw new AuthProtocolError('cancelled')
        if (credentialGeneration(stored) !== startedGeneration) {
          if (stored.needsReauth !== true && stored.expiresAt > Date.now() + REFRESH_EARLY_MS) return stored
          throw new AuthProtocolError('refresh-rejected')
        }
        await this.ctx.credentials.set(this.ref, JSON.stringify(fresh))
        return fresh
      })
    })().finally(() => {
      if (this.refreshFlight === refresh) this.refreshFlight = undefined
    })
    this.refreshFlight = refresh
    return (await refresh).accessToken
  }
}
