/** Host-only account login coordination and DSH adapter activation. */

import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import type { AdapterRegistrationHandle, LlmAdapter } from '@deepseek-ai/dsh-llm'
import { resolveRetryPolicy } from '@deepseek-ai/dsh-llm'
import { PiAiAdapter, type ResolvedPiAiProviderProfile } from '@deepseek-ai/dsh-llm-pi-ai'
import { openaiCodexProvider } from '@earendil-works/pi-ai/providers/openai-codex'
import { createProvider, type Model, type Provider } from '@earendil-works/pi-ai'
import * as openAICompletionsApi from '@earendil-works/pi-ai/api/openai-completions'
import { anthropicProvider } from '@earendil-works/pi-ai/providers/anthropic'
import { githubCopilotProvider } from '@earendil-works/pi-ai/providers/github-copilot'
import { xaiProvider } from '@earendil-works/pi-ai/providers/xai'
import type { AuthErrorCategory, AuthProviderView, CodexUsageView, ProviderQuotaView } from '../types.ts'
import { AuthProtocolError, OpenAICodexOAuthAdapter, type AuthProviderAdapter } from './auth-protocol.ts'
import { DshOAuthCredentialStore } from './auth-store.ts'
import { CODEX_USAGE_SOURCE, fetchCodexUsage } from './codex-usage.ts'
import { KIMI_AUTH_SOURCE, KimiCodeDeviceAdapter } from './kimi-auth-protocol.ts'
import { KIMI_USAGE_SOURCE, fetchKimiUsage } from './kimi-usage.ts'
import { PiOAuthBridgeAdapter, type BridgeOAuthAuth } from './pi-oauth-bridge.ts'
import { CommandCodeCompatibilityAdapter, CursorCompatibilityAdapter } from './compat-auth-protocols.ts'
import { GOOGLE_ANTIGRAVITY_AUTH_SOURCE, GoogleAntigravityCompatibilityAdapter } from './google-antigravity-auth.ts'
import { KIRO_AUTH_SOURCE, KiroDeviceCompatibilityAdapter } from './kiro-auth-protocol.ts'
import { CommandCodeLlmAdapter } from './command-code-adapter.ts'
import { KiroLlmAdapter } from './kiro-llm-adapter.ts'
import { GoogleAntigravityLlmAdapter } from './google-antigravity-adapter.ts'
import { CursorSdkLlmAdapter } from './cursor-sdk-adapter.ts'

export const OPENAI_CODEX_PROVIDER = 'openai-codex'
export const KIMI_CODE_PROVIDER = 'kimi-code'
export const XAI_PROVIDER = 'xai'
export const ANTHROPIC_PROVIDER = 'anthropic'
export const GITHUB_COPILOT_PROVIDER = 'github-copilot'
export const COMMAND_CODE_PROVIDER = 'command-code'
export const CURSOR_PROVIDER = 'cursor'
export const GOOGLE_ANTIGRAVITY_PROVIDER = 'google-antigravity'
export const KIRO_PROVIDER = 'kiro'
const OPENAI_CODEX_AUTH_SOURCE = 'https://github.com/openai/codex/blob/main/codex-rs/app-server/README.md#auth-endpoints'

function unavailableAuth(
  id: string,
  name: string,
  method: AuthProviderView['method'],
  stability: AuthProviderView['stability'],
  sourceUrl: string,
  availabilityReason: NonNullable<AuthProviderView['availabilityReason']>,
): AuthProviderView {
  return {
    id,
    name,
    method,
    official: true,
    available: false,
    stability,
    sourceUrl,
    availabilityReason,
    status: 'signed-out',
    authorizationUrl: null,
    verificationUrl: null,
    userCode: null,
    inputPrompt: null,
    attemptId: null,
    expiresAt: null,
    accountLabel: null,
    errorCategory: null,
    error: null,
  }
}

/** Official-source parity entries that deliberately fail closed in this release. */
export const UNAVAILABLE_AUTH_PROVIDERS: readonly AuthProviderView[] = [
  unavailableAuth('qwen', 'Qwen', 'device-code', 'unsupported', 'https://github.com/QwenLM/qwen-code/blob/main/docs/users/configuration/auth.md', 'discontinued'),
]

function maskEmail(email: string | undefined): string | null {
  if (email === undefined) return null
  const at = email.indexOf('@')
  if (at <= 0) return null
  const local = email.slice(0, at)
  const visible = local.length <= 2 ? local.slice(0, 1) : `${local[0]}***${local.at(-1)}`
  return `${visible}${email.slice(at)}`
}

function maskAccount(accountId: string | undefined): string | null {
  if (accountId === undefined) return null
  return accountId.length <= 4 ? 'account-…' : `account-…${accountId.slice(-4)}`
}

interface PendingAttempt {
  readonly id: string
  readonly controller: AbortController
  cancelled: boolean
}

/** Minimal login engine surface, injectable for state-machine tests. */
export interface CodexAuthEngine {
  status(): Promise<{ connected: boolean; needsReauth: boolean; accountLabel: string | null }>
  login(signal: AbortSignal, onReady: (ready: {
    authorizationUrl: string
    verificationUrl?: string
    userCode?: string
    inputPrompt?: {
      kind: 'authorization-code'
      label: string
      placeholder?: string
    }
    expiresAt: number
  }) => void): Promise<string | null>
  submit?(value: string): void
  logout(signal?: AbortSignal): Promise<{ revocationError?: AuthProtocolError }>
}

/** Public identity and risk label for one Host-owned Auth transaction. */
export interface AuthCoordinatorDescriptor {
  readonly id: string
  readonly name: string
  readonly method: AuthProviderView['method']
  readonly stability: AuthProviderView['stability']
  readonly sourceUrl: string
  readonly official?: boolean
}

/** Browser OAuth state machine that never exposes an OAuth credential. */
export class CodexAuthCoordinator {
  private attempt: PendingAttempt | undefined
  private state: AuthProviderView

  constructor(
    private readonly engine: CodexAuthEngine,
    private readonly onConnected: () => void,
    private readonly onDisconnected: () => void,
    private readonly descriptor: AuthCoordinatorDescriptor = {
      id: OPENAI_CODEX_PROVIDER,
      name: 'OpenAI Codex',
      method: 'browser-oauth',
      stability: 'stable',
      sourceUrl: OPENAI_CODEX_AUTH_SOURCE,
    },
  ) {
    this.state = this.view('signed-out')
  }

  private view(
    status: AuthProviderView['status'],
    fields: Partial<Omit<AuthProviderView, 'id' | 'name' | 'method' | 'official' | 'status'>> = {},
  ): AuthProviderView {
    return {
      id: this.descriptor.id,
      name: this.descriptor.name,
      method: this.descriptor.method,
      official: this.descriptor.official ?? true,
      available: true,
      stability: this.descriptor.stability,
      sourceUrl: this.descriptor.sourceUrl,
      availabilityReason: null,
      status,
      authorizationUrl: null,
      verificationUrl: null,
      userCode: null,
      inputPrompt: null,
      attemptId: null,
      expiresAt: null,
      accountLabel: null,
      errorCategory: null,
      error: null,
      ...fields,
    }
  }

  snapshot(): AuthProviderView {
    return { ...this.state }
  }

  private failure(error: unknown): { category: AuthErrorCategory; message: string } {
    const protocol = error instanceof AuthProtocolError ? error : new AuthProtocolError('network')
    return { category: protocol.category, message: protocol.message }
  }

  async synchronize(): Promise<AuthProviderView> {
    if (this.attempt !== undefined) return this.snapshot()
    try {
      const current = await this.engine.status()
      if (current.needsReauth) {
        this.onDisconnected()
        this.state = this.view('needs-reauth', { accountLabel: current.accountLabel })
      } else if (current.connected) {
        this.onConnected()
        this.state = this.view('connected', { accountLabel: current.accountLabel })
      } else {
        this.onDisconnected()
        this.state = this.view('signed-out')
      }
    } catch (error) {
      const failure = this.failure(error)
      this.onDisconnected()
      this.state = this.view('error', { errorCategory: failure.category, error: failure.message })
    }
    return this.snapshot()
  }

  async start(): Promise<AuthProviderView> {
    if (this.state.status === 'connected') return this.snapshot()
    if (this.attempt !== undefined) return this.snapshot()
    const attempt: PendingAttempt = { id: randomUUID(), controller: new AbortController(), cancelled: false }
    this.attempt = attempt
    this.state = this.view('starting', { attemptId: attempt.id })

    let resolveReady!: (view: AuthProviderView) => void
    let rejectReady!: (error: unknown) => void
    let readySettled = false
    const ready = new Promise<AuthProviderView>((resolve, reject) => {
      resolveReady = resolve
      rejectReady = reject
    })
    void this.engine.login(attempt.controller.signal, ready => {
      if (this.attempt !== attempt) return
      this.state = this.view('pending', {
        authorizationUrl: ready.authorizationUrl,
        verificationUrl: ready.verificationUrl ?? null,
        userCode: ready.userCode ?? null,
        inputPrompt: ready.inputPrompt === undefined ? null : {
          kind: ready.inputPrompt.kind,
          label: ready.inputPrompt.label,
          placeholder: ready.inputPrompt.placeholder ?? null,
        },
        attemptId: attempt.id,
        expiresAt: ready.expiresAt,
      })
      if (!readySettled) {
        readySettled = true
        resolveReady(this.snapshot())
      }
    }).then(accountLabel => {
      if (this.attempt !== attempt) return
      this.attempt = undefined
      if (attempt.cancelled) return
      this.onConnected()
      this.state = this.view('connected', { accountLabel })
      if (!readySettled) {
        readySettled = true
        resolveReady(this.snapshot())
      }
    }, error => {
      if (this.attempt !== attempt) return
      this.attempt = undefined
      const failure = this.failure(error)
      const status = attempt.cancelled || failure.category === 'cancelled'
        ? 'cancelled'
        : failure.category === 'expired' ? 'expired' : 'error'
      this.state = this.view(status, { errorCategory: failure.category, error: failure.message })
      if (!readySettled) {
        readySettled = true
        rejectReady(error)
      }
    })
    return ready
  }

  cancel(attemptId: string): AuthProviderView {
    const attempt = this.attempt
    if (attempt === undefined || attempt.id !== attemptId) return this.snapshot()
    attempt.cancelled = true
    attempt.controller.abort()
    this.state = this.view('cancelled', {
      errorCategory: 'cancelled',
      error: new AuthProtocolError('cancelled').message,
    })
    return this.snapshot()
  }

  /** Submit one bounded one-time authorization value to the active Host transaction. */
  submit(attemptId: string, value: string): AuthProviderView {
    const attempt = this.attempt
    if (attempt === undefined || attempt.id !== attemptId || this.engine.submit === undefined) {
      throw new AuthProtocolError('invalid-response')
    }
    const trimmed = value.trim()
    if (trimmed.length === 0 || trimmed.length > 16 * 1024) throw new AuthProtocolError('invalid-response')
    this.engine.submit(trimmed)
    return this.snapshot()
  }

  async logout(): Promise<AuthProviderView> {
    const attempt = this.attempt
    if (attempt !== undefined) {
      attempt.cancelled = true
      attempt.controller.abort()
      this.attempt = undefined
    }
    const outcome = await this.engine.logout()
    this.onDisconnected()
    this.state = outcome.revocationError === undefined
      ? this.view('signed-out')
      : this.view('signed-out', {
          errorCategory: outcome.revocationError.category,
          error: outcome.revocationError.message,
        })
    return this.snapshot()
  }
}

/** Runtime bridge: the plugin owns OAuth while pi-ai supplies Codex transport and model metadata. */
export class OpenAICodexAuthRuntime {
  readonly coordinator: CodexAuthCoordinator
  readonly models: readonly { id: string; name: string }[]
  private readonly adapter: AuthProviderAdapter
  private readonly credentials: DshOAuthCredentialStore
  private registration: AdapterRegistrationHandle | undefined
  private disposed = false

  constructor(ctx: Context, oauth: AuthProviderAdapter = new OpenAICodexOAuthAdapter()) {
    this.adapter = oauth
    this.credentials = new DshOAuthCredentialStore(ctx)
    const nativeProvider = openaiCodexProvider()
    const piProvider = {
      ...nativeProvider,
      auth: {
        ...nativeProvider.auth,
        apiKey: {
          name: 'DSH-managed OpenAI Codex OAuth',
          resolve: ({ credential }: { credential?: { key?: string } }) => Promise.resolve(
            credential?.key === undefined ? undefined : { auth: { apiKey: credential.key }, source: 'DSH OAuth' },
          ),
        },
      },
    }
    const profile: ResolvedPiAiProviderProfile = {
      provider: OPENAI_CODEX_PROVIDER,
      displayName: 'OpenAI Codex',
      streamIdleTimeoutMs: 120_000,
      retryPolicy: resolveRetryPolicy(undefined, 'auth-in-one OpenAI Codex retryPolicy'),
      configuredMaxTokens: new Map(),
      piProvider,
    }
    const profiles = new Map([[OPENAI_CODEX_PROVIDER, profile]])
    this.models = profile.piProvider.getModels().map(model => ({ id: model.id, name: model.name }))
    const transport = new PiAiAdapter({
      profiles: () => profiles,
      resolveApiKey: async () => {
        try {
          return await this.credentials.accessToken(this.adapter)
        } catch (error) {
          if (error instanceof AuthProtocolError && error.category === 'refresh-rejected') this.deactivate()
          throw error
        }
      },
    })
    const activate = (): void => {
      if (this.disposed || this.registration !== undefined) return
      this.registration = ctx.llm.registerAdapter([OPENAI_CODEX_PROVIDER], transport)
    }
    this.coordinator = new CodexAuthCoordinator({
      status: async () => {
        const status = await this.credentials.status()
        return {
          connected: status.connected,
          needsReauth: status.needsReauth,
          accountLabel: maskEmail(status.email) ?? maskAccount(status.accountId),
        }
      },
      login: async (signal, onReady) => {
        const handle = await this.adapter.start(signal)
        onReady({
          authorizationUrl: handle.authorizationUrl,
          ...handle.verificationUrl === undefined ? {} : { verificationUrl: handle.verificationUrl },
          ...handle.userCode === undefined ? {} : { userCode: handle.userCode },
          expiresAt: handle.expiresAt,
        })
        const credential = await handle.completion
        if (signal.aborted) throw new AuthProtocolError('cancelled')
        await this.credentials.write(credential)
        if (signal.aborted) {
          await this.credentials.delete()
          throw new AuthProtocolError('cancelled')
        }
        return maskEmail(credential.email) ?? maskAccount(credential.accountId)
      },
      logout: async signal => {
        const credential = await this.credentials.read()
        await this.credentials.delete()
        let revocationError: AuthProtocolError | undefined
        if (credential !== undefined) {
          try {
            await this.adapter.revoke(credential, signal)
          } catch (error) {
            revocationError = error instanceof AuthProtocolError
              ? error
              : new AuthProtocolError('revocation-failed')
          }
        }
        return revocationError === undefined ? {} : { revocationError }
      },
    }, activate, () => { this.deactivate() })
  }

  private deactivate(): void {
    this.registration?.()
    this.registration = undefined
  }

  /** Read best-effort subscription windows with the Host-only credential. */
  async usage(signal?: AbortSignal): Promise<CodexUsageView> {
    const credential = await this.credentials.read()
    if (credential === undefined || credential.needsReauth === true) {
      return {
        status: 'signed-out',
        generatedAt: Date.now(),
        bestEffort: true,
        sourceUrl: CODEX_USAGE_SOURCE,
        windows: [],
        error: null,
      }
    }
    const accessToken = await this.credentials.accessToken(this.adapter, signal)
    const current = await this.credentials.read()
    return fetchCodexUsage(accessToken, current?.accountId, signal)
  }

  dispose(): void {
    this.disposed = true
    const pending = this.coordinator.snapshot().attemptId
    if (pending !== null) this.coordinator.cancel(pending)
    this.deactivate()
  }
}

const KIMI_MODELS: readonly Model<'openai-completions'>[] = [
  {
    id: 'k3', name: 'Kimi K3', api: 'openai-completions', provider: KIMI_CODE_PROVIDER,
    baseUrl: 'https://api.kimi.com/coding/v1', reasoning: true, input: ['text', 'image'],
    cost: { input: 3, output: 15, cacheRead: 0.3, cacheWrite: 0 }, contextWindow: 1_048_576, maxTokens: 131_072,
  },
  {
    id: 'kimi-for-coding', name: 'Kimi for Coding', api: 'openai-completions', provider: KIMI_CODE_PROVIDER,
    baseUrl: 'https://api.kimi.com/coding/v1', reasoning: true, input: ['text', 'image'],
    cost: { input: 0.95, output: 4, cacheRead: 0.19, cacheWrite: 0 }, contextWindow: 262_144, maxTokens: 32_768,
  },
  {
    id: 'kimi-for-coding-highspeed', name: 'Kimi for Coding HighSpeed', api: 'openai-completions', provider: KIMI_CODE_PROVIDER,
    baseUrl: 'https://api.kimi.com/coding/v1', reasoning: true, input: ['text', 'image'],
    cost: { input: 1.9, output: 8, cacheRead: 0.38, cacheWrite: 0 }, contextWindow: 262_144, maxTokens: 32_768,
  },
]

/** Kimi Code device login, DSH credential lifecycle, and managed model route. */
export class KimiCodeAuthRuntime {
  readonly coordinator: CodexAuthCoordinator
  readonly models = KIMI_MODELS.map(model => ({ id: model.id, name: model.name }))
  private readonly adapter: AuthProviderAdapter
  private readonly credentials: DshOAuthCredentialStore
  private registration: AdapterRegistrationHandle | undefined
  private disposed = false

  constructor(ctx: Context, oauth: AuthProviderAdapter = new KimiCodeDeviceAdapter()) {
    this.adapter = oauth
    this.credentials = new DshOAuthCredentialStore(ctx, 'DSH_AUTH_IN_ONE_KIMI_CODE_OAUTH')
    const piProvider = createProvider({
      id: KIMI_CODE_PROVIDER,
      name: 'Kimi Code',
      baseUrl: 'https://api.kimi.com/coding/v1',
      auth: {
        apiKey: {
          name: 'DSH-managed Kimi Code OAuth',
          resolve: ({ credential }: { credential?: { key?: string } }) => Promise.resolve(
            credential?.key === undefined ? undefined : { auth: { apiKey: credential.key }, source: 'DSH OAuth' },
          ),
        },
      },
      models: KIMI_MODELS,
      api: openAICompletionsApi,
    })
    const profile: ResolvedPiAiProviderProfile = {
      provider: KIMI_CODE_PROVIDER,
      displayName: 'Kimi Code',
      streamIdleTimeoutMs: 120_000,
      retryPolicy: resolveRetryPolicy(undefined, 'auth-in-one Kimi Code retryPolicy'),
      configuredMaxTokens: new Map(),
      piProvider,
    }
    const profiles = new Map([[KIMI_CODE_PROVIDER, profile]])
    const transport = new PiAiAdapter({
      profiles: () => profiles,
      resolveApiKey: async () => {
        try {
          return await this.credentials.accessToken(this.adapter)
        } catch (error) {
          if (error instanceof AuthProtocolError && error.category === 'refresh-rejected') this.deactivate()
          throw error
        }
      },
    })
    const activate = (): void => {
      if (this.disposed || this.registration !== undefined) return
      this.registration = ctx.llm.registerAdapter([KIMI_CODE_PROVIDER], transport)
    }
    this.coordinator = new CodexAuthCoordinator({
      status: async () => {
        const status = await this.credentials.status()
        return { connected: status.connected, needsReauth: status.needsReauth, accountLabel: null }
      },
      login: async (signal, onReady) => {
        const handle = await this.adapter.start(signal)
        onReady({
          authorizationUrl: handle.authorizationUrl,
          ...handle.verificationUrl === undefined ? {} : { verificationUrl: handle.verificationUrl },
          ...handle.userCode === undefined ? {} : { userCode: handle.userCode },
          expiresAt: handle.expiresAt,
        })
        const stored = await handle.completion
        if (signal.aborted) throw new AuthProtocolError('cancelled')
        await this.credentials.write(stored)
        if (signal.aborted) {
          await this.credentials.delete()
          throw new AuthProtocolError('cancelled')
        }
        return null
      },
      logout: async signal => {
        const stored = await this.credentials.read()
        await this.credentials.delete()
        let revocationError: AuthProtocolError | undefined
        if (stored !== undefined) {
          try {
            await this.adapter.revoke(stored, signal)
          } catch {
            revocationError = new AuthProtocolError('revocation-failed')
          }
        }
        return revocationError === undefined ? {} : { revocationError }
      },
    }, activate, () => { this.deactivate() }, {
      id: KIMI_CODE_PROVIDER,
      name: 'Kimi Code 设备登录',
      method: 'device-code',
      stability: 'experimental',
      sourceUrl: KIMI_AUTH_SOURCE,
    })
  }

  private deactivate(): void {
    this.registration?.()
    this.registration = undefined
  }

  /** Read best-effort Kimi Code subscription windows with the Host-only credential. */
  async quota(signal?: AbortSignal): Promise<ProviderQuotaView> {
    const credential = await this.credentials.read()
    if (credential === undefined || credential.needsReauth === true) {
      return {
        provider: KIMI_CODE_PROVIDER, status: 'signed-out', generatedAt: Date.now(), bestEffort: true,
        sourceUrl: KIMI_USAGE_SOURCE, windows: [], error: null,
      }
    }
    const accessToken = await this.credentials.accessToken(this.adapter, signal)
    return fetchKimiUsage(accessToken, signal)
  }

  dispose(): void {
    this.disposed = true
    const pending = this.coordinator.snapshot().attemptId
    if (pending !== null) this.coordinator.cancel(pending)
    this.deactivate()
  }
}

/** Shared DSH credential and model lifecycle for installed pi-ai OAuth protocols. */
export class SubscriptionAuthRuntime {
  readonly coordinator: CodexAuthCoordinator
  readonly models: readonly { id: string; name: string }[]
  private readonly adapter: AuthProviderAdapter
  private readonly credentials: DshOAuthCredentialStore
  private registration: AdapterRegistrationHandle | undefined
  private disposed = false

  constructor(ctx: Context, options: {
    readonly descriptor: AuthCoordinatorDescriptor
    readonly credentialRef: string
    readonly adapter?: AuthProviderAdapter
    readonly piProvider?: Provider
    readonly createTransport?: (
      accessToken: (signal?: AbortSignal) => Promise<string>,
      credential: () => Promise<import('./auth-protocol.ts').StoredOAuthCredential | undefined>,
    ) => LlmAdapter
  }) {
    if (options.adapter === undefined && options.piProvider?.auth.oauth === undefined) {
      throw new TypeError(`Auth runtime ${options.descriptor.id} requires an adapter or pi-ai OAuth`)
    }
    this.adapter = options.adapter ?? new PiOAuthBridgeAdapter(
      options.descriptor.id,
      options.descriptor.name,
      options.piProvider!.auth.oauth as BridgeOAuthAuth,
    )
    this.credentials = new DshOAuthCredentialStore(ctx, options.credentialRef)
    this.models = options.piProvider?.getModels().map(model => ({ id: model.id, name: model.name })) ?? []
    const piProvider = options.piProvider
    let transport: LlmAdapter | undefined
    if (piProvider !== undefined) {
    const profile: ResolvedPiAiProviderProfile = {
      provider: options.descriptor.id,
      displayName: options.descriptor.name,
      streamIdleTimeoutMs: 120_000,
      retryPolicy: resolveRetryPolicy(undefined, `auth-in-one ${options.descriptor.id} retryPolicy`),
      configuredMaxTokens: new Map(),
      piProvider,
    }
    const profiles = new Map([[options.descriptor.id, profile]])
      transport = new PiAiAdapter({
      profiles: () => profiles,
      resolveApiKey: async () => {
        try {
          return await this.credentials.accessToken(this.adapter)
        } catch (error) {
          if (error instanceof AuthProtocolError && error.category === 'refresh-rejected') this.deactivate()
          throw error
        }
      },
    })
    }
    transport ??= options.createTransport?.(
      async signal => this.credentials.accessToken(this.adapter, signal),
      () => this.credentials.read(),
    )
    const activate = (): void => {
      if (this.disposed || this.registration !== undefined || transport === undefined) return
      this.registration = ctx.llm.registerAdapter([options.descriptor.id], transport)
    }
    let activeHandle: import('./auth-protocol.ts').AuthLoginHandle | undefined
    this.coordinator = new CodexAuthCoordinator({
      status: async () => {
        const status = await this.credentials.status()
        return { connected: status.connected, needsReauth: status.needsReauth, accountLabel: null }
      },
      login: async (signal, onReady) => {
        const handle = await this.adapter.start(signal)
        activeHandle = handle
        onReady({
          authorizationUrl: handle.authorizationUrl,
          ...handle.verificationUrl === undefined ? {} : { verificationUrl: handle.verificationUrl },
          ...handle.userCode === undefined ? {} : { userCode: handle.userCode },
          ...handle.inputPrompt === undefined ? {} : { inputPrompt: handle.inputPrompt },
          expiresAt: handle.expiresAt,
        })
        const stored = await handle.completion.finally(() => {
          if (activeHandle === handle) activeHandle = undefined
        })
        if (signal.aborted) throw new AuthProtocolError('cancelled')
        await this.credentials.write(stored)
        if (signal.aborted) {
          await this.credentials.delete()
          throw new AuthProtocolError('cancelled')
        }
        return null
      },
      submit: value => {
        if (activeHandle?.submit === undefined) throw new AuthProtocolError('invalid-response')
        activeHandle.submit(value)
      },
      logout: async () => {
        await this.credentials.delete()
        return {}
      },
    }, activate, () => { this.deactivate() }, options.descriptor)
  }

  private deactivate(): void {
    this.registration?.()
    this.registration = undefined
  }

  /** Resolve this Provider's fresh Host-only access token for a plugin-owned auxiliary request. */
  accessToken(signal?: AbortSignal): Promise<string> {
    return this.credentials.accessToken(this.adapter, signal)
  }

  /** Read Provider-specific Host-only metadata for a plugin-owned auxiliary request. */
  credential(): Promise<import('./auth-protocol.ts').StoredOAuthCredential | undefined> {
    return this.credentials.read()
  }

  dispose(): void {
    this.disposed = true
    const pending = this.coordinator.snapshot().attemptId
    if (pending !== null) this.coordinator.cancel(pending)
    this.deactivate()
  }
}

/** Create compatibility runtimes with one common DSH transaction and credential lifecycle. */
export function createCompatibilityAuthRuntimes(ctx: Context): readonly SubscriptionAuthRuntime[] {
  return [
    new SubscriptionAuthRuntime(ctx, {
      descriptor: {
        id: XAI_PROVIDER, name: 'xAI Grok', method: 'device-code', stability: 'experimental',
        sourceUrl: 'https://github.com/xai-org/grok-build/blob/main/crates/codegen/xai-grok-pager/docs/user-guide/02-authentication.md',
      },
      credentialRef: 'DSH_AUTH_IN_ONE_XAI_OAUTH',
      piProvider: xaiProvider(),
    }),
    new SubscriptionAuthRuntime(ctx, {
      descriptor: {
        id: ANTHROPIC_PROVIDER, name: 'Anthropic 登录兼容', method: 'browser-oauth', stability: 'experimental',
        sourceUrl: 'https://github.com/anthropics/claude-code',
        official: false,
      },
      credentialRef: 'DSH_AUTH_IN_ONE_ANTHROPIC_OAUTH',
      piProvider: anthropicProvider(),
    }),
    new SubscriptionAuthRuntime(ctx, {
      descriptor: {
        id: GITHUB_COPILOT_PROVIDER, name: 'GitHub Copilot', method: 'device-code', stability: 'experimental',
        sourceUrl: 'https://docs.github.com/en/copilot/how-tos/copilot-sdk/setup/github-oauth',
      },
      credentialRef: 'DSH_AUTH_IN_ONE_GITHUB_COPILOT_OAUTH',
      piProvider: githubCopilotProvider(),
    }),
    new SubscriptionAuthRuntime(ctx, {
      descriptor: {
        id: COMMAND_CODE_PROVIDER, name: 'Command Code Auth', method: 'browser-oauth', stability: 'experimental',
        sourceUrl: 'https://commandcode.ai/docs/quickstart',
      },
      credentialRef: 'DSH_AUTH_IN_ONE_COMMAND_CODE_AUTH',
      adapter: new CommandCodeCompatibilityAdapter(),
      createTransport: accessToken => new CommandCodeLlmAdapter(accessToken),
    }),
    new SubscriptionAuthRuntime(ctx, {
      descriptor: {
        id: CURSOR_PROVIDER, name: 'Cursor 登录兼容', method: 'browser-oauth', stability: 'experimental',
        sourceUrl: 'https://docs.cursor.com/en/cli/reference/authentication',
        official: false,
      },
      credentialRef: 'DSH_AUTH_IN_ONE_CURSOR_OAUTH',
      adapter: new CursorCompatibilityAdapter(),
      createTransport: accessToken => new CursorSdkLlmAdapter(accessToken),
    }),
    new SubscriptionAuthRuntime(ctx, {
      descriptor: {
        id: GOOGLE_ANTIGRAVITY_PROVIDER, name: 'Google Antigravity 登录兼容', method: 'browser-oauth', stability: 'experimental',
        sourceUrl: GOOGLE_ANTIGRAVITY_AUTH_SOURCE,
        official: false,
      },
      credentialRef: 'DSH_AUTH_IN_ONE_GOOGLE_ANTIGRAVITY_OAUTH',
      adapter: new GoogleAntigravityCompatibilityAdapter(),
      createTransport: (accessToken, credential) => new GoogleAntigravityLlmAdapter(accessToken, credential),
    }),
    new SubscriptionAuthRuntime(ctx, {
      descriptor: {
        id: KIRO_PROVIDER, name: 'Kiro 设备登录兼容', method: 'device-code', stability: 'experimental',
        sourceUrl: KIRO_AUTH_SOURCE,
      },
      credentialRef: 'DSH_AUTH_IN_ONE_KIRO_OAUTH',
      adapter: new KiroDeviceCompatibilityAdapter(),
      createTransport: (accessToken, credential) => new KiroLlmAdapter(accessToken, credential),
    }),
  ]
}
