/** Best-effort subscription quota readers for compatibility Auth Providers. */

import type { ProviderQuotaView, ProviderQuotaWindowView } from '../types.ts'
import type { StoredOAuthCredential } from './auth-protocol.ts'
import { readBoundedJson } from './bounded-json.ts'

const MAX_QUOTA_RESPONSE_BYTES = 256 * 1024

function object(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function finite(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim().length > 0) {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return undefined
}

function pct(value: unknown): number | undefined {
  const parsed = finite(value)
  if (parsed === undefined) return undefined
  const normalized = parsed >= 0 && parsed <= 1 ? parsed * 100 : parsed
  return Math.min(100, Math.max(0, normalized))
}

function reset(value: unknown): number | null {
  if (typeof value === 'string') {
    const parsed = Date.parse(value)
    return Number.isFinite(parsed) ? parsed : null
  }
  const parsed = finite(value)
  if (parsed === undefined) return null
  return parsed < 10_000_000_000 ? parsed * 1_000 : parsed
}

function window(id: string, label: string, usedPercent: number, resetAt: number | null, windowSeconds: number | null): ProviderQuotaWindowView {
  return { id, label, usedPercent, remainingPercent: Math.max(0, 100 - usedPercent), resetAt, windowSeconds }
}

function unavailable(provider: string, sourceUrl: string): ProviderQuotaView {
  return {
    provider, status: 'unavailable', generatedAt: Date.now(), bestEffort: true,
    sourceUrl, windows: [], error: 'Subscription quota is temporarily unavailable.',
  }
}

function available(provider: string, sourceUrl: string, windows: readonly ProviderQuotaWindowView[]): ProviderQuotaView {
  return { provider, status: 'available', generatedAt: Date.now(), bestEffort: true, sourceUrl, windows, error: null }
}

async function json(input: string, token: string, init: RequestInit = {}, request: typeof fetch = fetch): Promise<Record<string, unknown> | undefined> {
  const response = await request(input, {
    ...init,
    headers: { accept: 'application/json', authorization: `Bearer ${token}`, ...Object.fromEntries(new Headers(init.headers)) },
    signal: init.signal ?? AbortSignal.timeout(15_000),
  })
  if (!response.ok) return undefined
  return object(await readBoundedJson(response, MAX_QUOTA_RESPONSE_BYTES))
}

function jwtSubject(token: string): string | undefined {
  const segment = token.split('.')[1]
  if (segment === undefined) return undefined
  try {
    const sub = object(JSON.parse(Buffer.from(segment, 'base64url').toString('utf8')) as unknown)?.sub
    return typeof sub === 'string' && sub.length > 0 ? sub : undefined
  } catch {
    return undefined
  }
}

/** Fetch xAI weekly credits, falling back to the legacy monthly pool. */
export async function fetchXaiQuota(token: string, signal?: AbortSignal, request: typeof fetch = fetch): Promise<ProviderQuotaView> {
  const sourceUrl = 'https://cli-chat-proxy.grok.com/v1/billing?format=credits'
  try {
    const subject = jwtSubject(token)
    if (subject !== undefined) {
      const body = await json(sourceUrl, token, {
        headers: {
          'x-xai-token-auth': 'xai-grok-cli', 'x-authenticateresponse': 'authenticate-response',
          'x-userid': subject, 'x-grok-client-version': '0.2.93',
        },
        ...signal === undefined ? {} : { signal },
      }, request)
      const config = object(body?.config)
      const period = object(config?.currentPeriod)
      const used = config?.creditUsagePercent === undefined ? 0 : pct(config.creditUsagePercent)
      const resetAt = reset(period?.end)
      if (period?.type === 'USAGE_PERIOD_TYPE_WEEKLY' && used !== undefined && resetAt !== null) {
        return available('xai', sourceUrl, [window('weekly', '7 days', used, resetAt, 7 * 24 * 60 * 60)])
      }
    }
    const monthlySource = 'https://cli-chat-proxy.grok.com/v1/billing'
    const body = await json(monthlySource, token, signal === undefined ? {} : { signal }, request)
    const config = object(body?.config)
    const limit = finite(object(config?.monthlyLimit)?.val)
    const used = finite(object(config?.used)?.val)
    if (limit !== undefined && limit > 0 && used !== undefined) {
      return available('xai', monthlySource, [window('monthly', 'Monthly', Math.min(100, used / limit * 100), reset(config?.billingPeriodEnd), null)])
    }
  } catch {
    // Best-effort quota errors are projected without upstream details.
  }
  return unavailable('xai', sourceUrl)
}

/** Fetch Anthropic OAuth usage windows. */
export async function fetchAnthropicQuota(token: string, signal?: AbortSignal, request: typeof fetch = fetch): Promise<ProviderQuotaView> {
  const sourceUrl = 'https://api.anthropic.com/api/oauth/usage'
  try {
    const body = await json(sourceUrl, token, {
      headers: {
        'content-type': 'application/json', 'user-agent': 'claude-cli/2.1.75 (external, cli)',
        'anthropic-beta': 'claude-code-20250219,oauth-2025-04-20',
      },
      ...signal === undefined ? {} : { signal },
    }, request)
    const windows: ProviderQuotaWindowView[] = []
    for (const [id, label, field, seconds] of [
      ['five-hour', '5 hours', 'five_hour', 5 * 60 * 60],
      ['weekly', '7 days', 'seven_day', 7 * 24 * 60 * 60],
      ['opus', 'Opus', 'seven_day_opus', 7 * 24 * 60 * 60],
      ['sonnet', 'Sonnet', 'seven_day_sonnet', 7 * 24 * 60 * 60],
    ] as const) {
      const row = object(body?.[field])
      const used = pct(row?.utilization)
      if (used !== undefined) windows.push(window(id, label, used, reset(row?.resets_at), seconds))
    }
    if (windows.length > 0) return available('anthropic', sourceUrl, windows)
  } catch {
    // Best-effort quota errors are projected without upstream details.
  }
  return unavailable('anthropic', sourceUrl)
}

/** Fetch Cursor included usage from the same API2 account host. */
export async function fetchCursorQuota(token: string, signal?: AbortSignal, request: typeof fetch = fetch): Promise<ProviderQuotaView> {
  const sourceUrl = 'https://api2.cursor.sh/aiserver.v1.DashboardService/GetCurrentPeriodUsage'
  try {
    const body = await json(sourceUrl, token, {
      method: 'POST', headers: { 'content-type': 'application/json', 'connect-protocol-version': '1' }, body: '{}',
      ...signal === undefined ? {} : { signal },
    }, request)
    const plan = object(body?.planUsage)
    const limit = finite(plan?.limit ?? plan?.limitCents ?? plan?.totalLimitCents)
    const remaining = finite(plan?.remaining ?? plan?.remainingCents)
    const spent = finite(plan?.includedSpend ?? plan?.usedCents ?? plan?.used ?? plan?.totalSpend)
    const used = pct(plan?.totalPercentUsed ?? plan?.percentUsed)
      ?? (limit !== undefined && limit > 0 && (spent !== undefined || remaining !== undefined)
        ? Math.min(100, (spent ?? Math.max(0, limit - remaining!)) / limit * 100)
        : undefined)
    const resetAt = reset(body?.billingCycleEnd ?? plan?.billingCycleEnd ?? body?.periodEnd)
    const windows: ProviderQuotaWindowView[] = []
    if (used !== undefined) windows.push(window('monthly', 'Included usage', used, resetAt, null))
    const firstParty = pct(plan?.autoPercentUsed)
    if (firstParty !== undefined) windows.push(window('first-party', 'First-party models', firstParty, resetAt, null))
    const api = pct(plan?.apiPercentUsed)
    if (api !== undefined) windows.push(window('api', 'API usage', api, resetAt, null))
    if (windows.length > 0) return available('cursor', sourceUrl, windows)
  } catch {
    // Best-effort quota errors are projected without upstream details.
  }
  return unavailable('cursor', sourceUrl)
}

function quotaRows(value: unknown): readonly Record<string, unknown>[] {
  const row = object(value)
  if (row === undefined) return []
  if (Array.isArray(row.quotaInfo)) return row.quotaInfo.flatMap((value): Record<string, unknown>[] => {
    const parsed = object(value)
    return parsed === undefined ? [] : [parsed]
  })
  const one = object(row.quotaInfo)
  if (one !== undefined) return [one]
  return Array.isArray(row.quotaInfos) ? row.quotaInfos.flatMap((value): Record<string, unknown>[] => {
    const parsed = object(value)
    return parsed === undefined ? [] : [parsed]
  }) : []
}

/** Fetch Antigravity quota embedded in the available-model response. */
export async function fetchAntigravityQuota(
  token: string,
  credential: StoredOAuthCredential,
  signal?: AbortSignal,
  request: typeof fetch = fetch,
): Promise<ProviderQuotaView> {
  const sourceUrl = 'https://daily-cloudcode-pa.googleapis.com/v1internal:fetchAvailableModels'
  const projectId = credential.providerData?.projectId
  if (typeof projectId !== 'string') return unavailable('google-antigravity', sourceUrl)
  try {
    const body = await json(sourceUrl, token, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ project: projectId }),
      ...signal === undefined ? {} : { signal },
    }, request)
    const models = object(body?.models)
    const byFamily = new Map<string, ProviderQuotaWindowView>()
    for (const [id, value] of Object.entries(models ?? {})) {
      for (const quota of quotaRows(value)) {
        const remaining = pct(finite(quota.remainingFraction) === undefined ? quota.remainingPercentage : finite(quota.remainingFraction)! * 100)
        if (remaining === undefined) continue
        const family = /gemini/i.test(id) ? 'gemini' : /claude|opus|sonnet|gpt/i.test(id) ? 'other' : undefined
        if (family !== undefined && !byFamily.has(family)) {
          byFamily.set(family, window(family, family === 'gemini' ? 'Gemini' : 'Claude / other', 100 - remaining, reset(quota.resetTime), null))
        }
      }
    }
    if (byFamily.size > 0) return available('google-antigravity', sourceUrl, [...byFamily.values()])
  } catch {
    // Best-effort quota errors are projected without upstream details.
  }
  return unavailable('google-antigravity', sourceUrl)
}
