/** Host-only Google Antigravity compatibility OAuth and project discovery. */

import { createHash, randomBytes } from 'node:crypto'
import { createServer } from 'node:http'
import { AuthProtocolError, type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts'
import { readBoundedJson } from './bounded-json.ts'

const DEFAULT_CLIENT_ID = '1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com'
const DEFAULT_CLIENT_SECRET = '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'
const AUTHORIZATION_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth'
const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token'
const CLOUD_CODE_ENDPOINT = 'https://cloudcode-pa.googleapis.com'
const DAILY_CLOUD_CODE_ENDPOINT = 'https://daily-cloudcode-pa.googleapis.com'
const CALLBACK_PORT = 51_121
const CALLBACK_PATH = '/callback'
const TIMEOUT_MS = 5 * 60 * 1_000
const MAX_RESPONSE_BYTES = 64 * 1024
const SCOPES = [
  'https://www.googleapis.com/auth/cloud-platform',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
  'https://www.googleapis.com/auth/cclog',
  'https://www.googleapis.com/auth/experimentsandconfigs',
]

export const GOOGLE_ANTIGRAVITY_AUTH_SOURCE = 'https://antigravity.google/docs'

export interface GoogleAntigravityAuthOptions {
  readonly clientId?: string
  readonly clientSecret?: string
  readonly authorizationEndpoint?: string
  readonly tokenEndpoint?: string
  readonly cloudCodeEndpoint?: string
  readonly dailyCloudCodeEndpoint?: string
  readonly callbackPort?: number
  readonly fetch?: typeof fetch
  readonly now?: () => number
}

function pkce(): { verifier: string; challenge: string } {
  const verifier = randomBytes(64).toString('base64url')
  return { verifier, challenge: createHash('sha256').update(verifier).digest('base64url') }
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function decodeEmail(token: string | undefined): string | undefined {
  const segment = token?.split('.')[1]
  if (segment === undefined) return undefined
  try {
    const email = record(JSON.parse(Buffer.from(segment, 'base64url').toString('utf8')) as unknown)?.email
    return typeof email === 'string' && email.length > 0 ? email.toLowerCase() : undefined
  } catch {
    return undefined
  }
}

function projectId(value: unknown): string | undefined {
  const body = record(value)
  if (body === undefined) return undefined
  for (const key of ['cloudaicompanionProject', 'projectId', 'project']) {
    const candidate = body[key]
    if (typeof candidate === 'string' && candidate.length > 0) return candidate
    const nested = record(candidate)?.id
    if (typeof nested === 'string' && nested.length > 0) return nested
  }
  return undefined
}

function requestSignal(signal?: AbortSignal): AbortSignal {
  const timeout = AbortSignal.timeout(30_000)
  return signal === undefined ? timeout : AbortSignal.any([signal, timeout])
}

function clientHeaders(accessToken: string): Record<string, string> {
  const platform = `${process.platform}/${process.arch}`
  return {
    authorization: `Bearer ${accessToken}`,
    accept: '*/*',
    'content-type': 'application/json',
    'user-agent': `antigravity/cli/1.0.13 (aidev_client; os_type=${platform.split('/')[0]}; arch=${platform.split('/')[1]})`,
  }
}

/** Antigravity login uses the desktop client's published OAuth identity but stores only in DSH. */
export class GoogleAntigravityCompatibilityAdapter implements AuthProviderAdapter {
  readonly id = 'google-antigravity'
  readonly name = 'Google Antigravity'
  private readonly clientId: string
  private readonly clientSecret: string
  private readonly authorizationEndpoint: string
  private readonly tokenEndpoint: string
  private readonly cloudCodeEndpoint: string
  private readonly dailyCloudCodeEndpoint: string
  private readonly callbackPort: number
  private readonly request: typeof fetch
  private readonly now: () => number

  constructor(options: GoogleAntigravityAuthOptions = {}) {
    this.clientId = options.clientId ?? process.env.GOOGLE_ANTIGRAVITY_CLIENT_ID ?? DEFAULT_CLIENT_ID
    this.clientSecret = options.clientSecret ?? process.env.GOOGLE_ANTIGRAVITY_CLIENT_SECRET ?? DEFAULT_CLIENT_SECRET
    this.authorizationEndpoint = options.authorizationEndpoint ?? AUTHORIZATION_ENDPOINT
    this.tokenEndpoint = options.tokenEndpoint ?? TOKEN_ENDPOINT
    this.cloudCodeEndpoint = options.cloudCodeEndpoint ?? CLOUD_CODE_ENDPOINT
    this.dailyCloudCodeEndpoint = options.dailyCloudCodeEndpoint ?? DAILY_CLOUD_CODE_ENDPOINT
    this.callbackPort = options.callbackPort ?? CALLBACK_PORT
    this.request = options.fetch ?? fetch
    this.now = options.now ?? Date.now
  }

  private async tokens(fields: Record<string, string>, signal?: AbortSignal): Promise<Record<string, unknown>> {
    let response: Response
    try {
      response = await this.request(this.tokenEndpoint, {
        method: 'POST',
        headers: { accept: 'application/json', 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(fields),
        signal: requestSignal(signal),
      })
    } catch {
      throw new AuthProtocolError(signal?.aborted === true ? 'cancelled' : 'network')
    }
    if (response.status === 400 || response.status === 401 || response.status === 403) throw new AuthProtocolError('refresh-rejected')
    if (!response.ok) throw new AuthProtocolError('network')
    const body = record(await readBoundedJson(response, MAX_RESPONSE_BYTES))
    if (body === undefined) throw new AuthProtocolError('invalid-response')
    return body
  }

  private async discoverProject(accessToken: string, signal?: AbortSignal): Promise<string> {
    const headers = clientHeaders(accessToken)
    const loaded = await this.request(`${this.cloudCodeEndpoint}/v1internal:loadCodeAssist`, {
      method: 'POST', headers, body: JSON.stringify({ metadata: { ideType: 'ANTIGRAVITY' } }), signal: requestSignal(signal),
    })
    if (loaded.ok) {
      const found = projectId(await readBoundedJson(loaded, MAX_RESPONSE_BYTES))
      if (found !== undefined) return found
    }
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const onboarded = await this.request(`${this.dailyCloudCodeEndpoint}/v1internal:onboardUser`, {
        method: 'POST',
        headers: { ...headers, 'x-goog-api-client': 'google-api-nodejs-client/10.3.0' },
        body: JSON.stringify({ tier_id: 'free-tier', metadata: { ide_type: 'ANTIGRAVITY', ide_name: 'antigravity' } }),
        signal: requestSignal(signal),
      })
      if (onboarded.ok) {
        const body = record(await readBoundedJson(onboarded, MAX_RESPONSE_BYTES))
        const found = projectId(body?.response ?? body)
        if (found !== undefined) return found
      } else if (onboarded.status !== 429 && onboarded.status < 500) {
        break
      }
      await new Promise(resolve => setTimeout(resolve, 2_000))
    }
    throw new AuthProtocolError('invalid-response')
  }

  async start(signal?: AbortSignal): Promise<AuthLoginHandle> {
    const controller = new AbortController()
    const combined = signal === undefined ? controller.signal : AbortSignal.any([controller.signal, signal])
    const state = randomBytes(32).toString('base64url')
    const proof = pkce()
    let redirectUri = `http://127.0.0.1:${this.callbackPort}${CALLBACK_PATH}`
    let resolveCode!: (code: string) => void
    let rejectCode!: (error: unknown) => void
    const code = new Promise<string>((resolve, reject) => { resolveCode = resolve; rejectCode = reject })
    const server = createServer((request, response) => {
      const url = new URL(request.url ?? '/', redirectUri)
      if (url.pathname !== CALLBACK_PATH) {
        response.writeHead(404).end()
        return
      }
      if (url.searchParams.get('state') !== state) {
        response.writeHead(400, { 'content-type': 'text/plain; charset=utf-8' }).end('Authorization state mismatch.')
        return
      }
      const error = url.searchParams.get('error')
      const authorizationCode = url.searchParams.get('code')
      if (error !== null || authorizationCode === null || authorizationCode.length === 0) {
        response.writeHead(400, { 'content-type': 'text/plain; charset=utf-8' }).end('Authorization was not completed.')
        rejectCode(new AuthProtocolError(error === 'access_denied' ? 'denied' : 'token-exchange-failed'))
        return
      }
      response.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }).end('Authorization completed. You can close this window.')
      resolveCode(authorizationCode)
    })
    await new Promise<void>((resolve, reject) => {
      server.once('error', () => { reject(new AuthProtocolError('callback-unavailable')) })
      server.listen(this.callbackPort, '127.0.0.1', () => { resolve() })
    })
    const address = server.address()
    if (address === null || typeof address === 'string') {
      server.close()
      throw new AuthProtocolError('callback-unavailable')
    }
    redirectUri = `http://127.0.0.1:${address.port}${CALLBACK_PATH}`
    const authorizationUrl = `${this.authorizationEndpoint}?${new URLSearchParams({
      response_type: 'code', client_id: this.clientId, redirect_uri: redirectUri, scope: SCOPES.join(' '),
      code_challenge: proof.challenge, code_challenge_method: 'S256', access_type: 'offline', prompt: 'consent', state,
    })}`
    const timeout = setTimeout(() => { rejectCode(new AuthProtocolError('expired')) }, TIMEOUT_MS)
    const abort = (): void => { rejectCode(new AuthProtocolError('cancelled')) }
    combined.addEventListener('abort', abort, { once: true })
    const completion = (async (): Promise<StoredOAuthCredential> => {
      try {
        const authorizationCode = await code
        const payload = await this.tokens({
          grant_type: 'authorization_code', client_id: this.clientId, client_secret: this.clientSecret,
          code: authorizationCode, redirect_uri: redirectUri, code_verifier: proof.verifier,
        }, combined)
        const accessToken = payload.access_token
        const refreshToken = payload.refresh_token
        const expiresIn = payload.expires_in
        if (typeof accessToken !== 'string' || accessToken.length === 0 || typeof refreshToken !== 'string' || refreshToken.length === 0
          || typeof expiresIn !== 'number' || !Number.isFinite(expiresIn) || expiresIn <= 0) throw new AuthProtocolError('invalid-response')
        const discoveredProject = await this.discoverProject(accessToken, combined)
        const email = decodeEmail(typeof payload.id_token === 'string' ? payload.id_token : accessToken)
        return {
          version: 1, accessToken, refreshToken, expiresAt: this.now() + expiresIn * 1_000 - 5 * 60 * 1_000,
          providerData: { projectId: discoveredProject },
          ...email === undefined ? {} : { email },
        }
      } finally {
        clearTimeout(timeout)
        combined.removeEventListener('abort', abort)
        server.close()
      }
    })()
    return { authorizationUrl, expiresAt: this.now() + TIMEOUT_MS, completion, cancel: () => { controller.abort() } }
  }

  async refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential> {
    const payload = await this.tokens({
      grant_type: 'refresh_token', client_id: this.clientId, client_secret: this.clientSecret,
      refresh_token: previous.refreshToken,
    }, signal)
    const accessToken = payload.access_token
    const refreshToken = payload.refresh_token
    const expiresIn = payload.expires_in
    if (typeof accessToken !== 'string' || accessToken.length === 0 || typeof expiresIn !== 'number' || !Number.isFinite(expiresIn)) {
      throw new AuthProtocolError('invalid-response')
    }
    const discovered = await this.discoverProject(accessToken, signal).catch(() => undefined)
    return {
      version: 1,
      accessToken,
      refreshToken: typeof refreshToken === 'string' && refreshToken.length > 0 ? refreshToken : previous.refreshToken,
      expiresAt: this.now() + expiresIn * 1_000 - 5 * 60 * 1_000,
      ...previous.email === undefined ? {} : { email: previous.email },
      ...discovered === undefined ? previous.providerData === undefined ? {} : { providerData: previous.providerData } : { providerData: { projectId: discovered } },
    }
  }

  revoke(_credential: StoredOAuthCredential): Promise<void> {
    return Promise.resolve()
  }
}
