/** Host-only Kiro Builder ID device flow over the public AWS SSO OIDC protocol. */

import { AuthProtocolError, type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts'
import { readBoundedJson } from './bounded-json.ts'

const REGION = 'us-east-1'
const START_URL = 'https://view.awsapps.com/start'
const SCOPES = ['codewhisperer:completions', 'codewhisperer:analysis', 'codewhisperer:conversations'] as const
const DEVICE_GRANT = 'urn:ietf:params:oauth:grant-type:device_code'
const REFRESH_GRANT = 'refresh_token'
const MAX_RESPONSE_BYTES = 64 * 1024

export const KIRO_AUTH_SOURCE = 'https://kiro.dev/docs/cli/authentication/'

export interface KiroDeviceAuthOptions {
  readonly oidcEndpoint?: string
  readonly fetch?: typeof fetch
  readonly now?: () => number
  readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>
  readonly clientName?: string
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function wait(milliseconds: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(new AuthProtocolError('cancelled'))
      return
    }
    const timer = setTimeout(resolve, milliseconds)
    signal.addEventListener('abort', () => {
      clearTimeout(timer)
      reject(new AuthProtocolError('cancelled'))
    }, { once: true })
  })
}

function trustedUrl(value: unknown): string | undefined {
  if (typeof value !== 'string' || !URL.canParse(value)) return undefined
  const parsed = new URL(value)
  return parsed.protocol === 'https:' ? parsed.href : undefined
}

/** Independent device transaction; it never inspects Kiro CLI files or an existing session. */
export class KiroDeviceCompatibilityAdapter implements AuthProviderAdapter {
  readonly id = 'kiro'
  readonly name = 'Kiro'
  private readonly oidcEndpoint: string
  private readonly request: typeof fetch
  private readonly now: () => number
  private readonly pause: (milliseconds: number, signal: AbortSignal) => Promise<void>
  private readonly clientName: string

  constructor(options: KiroDeviceAuthOptions = {}) {
    this.oidcEndpoint = (options.oidcEndpoint ?? `https://oidc.${REGION}.amazonaws.com`).replace(/\/+$/, '')
    this.request = options.fetch ?? fetch
    this.now = options.now ?? Date.now
    this.pause = options.sleep ?? wait
    this.clientName = options.clientName ?? 'dsh-auth-in-one'
  }

  private async post(path: string, body: Record<string, unknown>, signal?: AbortSignal): Promise<{ status: number; body: Record<string, unknown> | undefined }> {
    let response: Response
    try {
      const timeout = AbortSignal.timeout(30_000)
      response = await this.request(`${this.oidcEndpoint}${path}`, {
        method: 'POST',
        headers: { accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify(body),
        signal: signal === undefined ? timeout : AbortSignal.any([signal, timeout]),
      })
    } catch {
      throw new AuthProtocolError(signal?.aborted === true ? 'cancelled' : 'network')
    }
    const parsed = record(await readBoundedJson(response, MAX_RESPONSE_BYTES))
    return { status: response.status, body: parsed }
  }

  private credential(
    payload: Record<string, unknown> | undefined,
    registration: { clientId: string; clientSecret: string },
    previous?: StoredOAuthCredential,
  ): StoredOAuthCredential {
    const accessToken = payload?.accessToken
    const refreshToken = payload?.refreshToken
    const expiresIn = payload?.expiresIn
    if (typeof accessToken !== 'string' || accessToken.length === 0
      || (typeof refreshToken !== 'string' && previous === undefined)
      || typeof expiresIn !== 'number' || !Number.isFinite(expiresIn) || expiresIn <= 0) {
      throw new AuthProtocolError('invalid-response')
    }
    return {
      version: 1,
      accessToken,
      refreshToken: typeof refreshToken === 'string' && refreshToken.length > 0 ? refreshToken : previous!.refreshToken,
      expiresAt: this.now() + expiresIn * 1_000 - 60 * 1_000,
      providerData: {
        clientId: registration.clientId,
        clientSecret: registration.clientSecret,
        region: REGION,
        startUrl: START_URL,
        scopes: [...SCOPES],
      },
    }
  }

  async start(signal?: AbortSignal): Promise<AuthLoginHandle> {
    const controller = new AbortController()
    const combined = signal === undefined ? controller.signal : AbortSignal.any([controller.signal, signal])
    const registered = await this.post('/client/register', {
      clientName: this.clientName,
      clientType: 'public',
      scopes: [...SCOPES],
    }, combined)
    const clientId = registered.body?.clientId
    const clientSecret = registered.body?.clientSecret
    if (registered.status !== 200 || typeof clientId !== 'string' || clientId.length === 0
      || typeof clientSecret !== 'string' || clientSecret.length === 0) throw new AuthProtocolError('invalid-response')
    const registration = { clientId, clientSecret }
    const started = await this.post('/device_authorization', {
      clientId, clientSecret, startUrl: START_URL,
    }, combined)
    const deviceCode = started.body?.deviceCode
    const userCode = started.body?.userCode
    const verificationUrl = trustedUrl(started.body?.verificationUri)
    const authorizationUrl = trustedUrl(started.body?.verificationUriComplete) ?? verificationUrl
    const expiresIn = started.body?.expiresIn
    const interval = started.body?.interval
    if (started.status !== 200 || typeof deviceCode !== 'string' || deviceCode.length === 0
      || typeof userCode !== 'string' || userCode.length === 0 || authorizationUrl === undefined || verificationUrl === undefined
      || typeof expiresIn !== 'number' || !Number.isFinite(expiresIn) || expiresIn <= 0) throw new AuthProtocolError('invalid-response')
    let intervalMs = typeof interval === 'number' && Number.isFinite(interval) && interval > 0 ? interval * 1_000 : 5_000
    const expiry = AbortSignal.timeout(expiresIn * 1_000)
    const pollSignal = AbortSignal.any([combined, expiry])
    const completion = (async (): Promise<StoredOAuthCredential> => {
      while (true) {
        try {
          await this.pause(intervalMs, pollSignal)
        } catch {
          throw new AuthProtocolError(combined.aborted ? 'cancelled' : 'expired')
        }
        const token = await this.post('/token', {
          clientId, clientSecret, grantType: DEVICE_GRANT, deviceCode,
        }, pollSignal)
        if (token.status === 200) return this.credential(token.body, registration)
        const code = token.body?.error ?? token.body?.__type
        const normalized = typeof code === 'string' ? code.toLowerCase() : ''
        if (normalized.includes('authorizationpending')) continue
        if (normalized.includes('slowdown')) {
          intervalMs += 5_000
          continue
        }
        if (normalized.includes('accessdenied')) throw new AuthProtocolError('denied')
        if (normalized.includes('expiredtoken')) throw new AuthProtocolError('expired')
        if (token.status === 429 || token.status >= 500) continue
        throw new AuthProtocolError('invalid-response')
      }
    })()
    return {
      authorizationUrl, verificationUrl, userCode,
      expiresAt: this.now() + expiresIn * 1_000,
      completion,
      cancel: () => { controller.abort() },
    }
  }

  async refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential> {
    const clientId = previous.providerData?.clientId
    const clientSecret = previous.providerData?.clientSecret
    if (typeof clientId !== 'string' || typeof clientSecret !== 'string') throw new AuthProtocolError('refresh-rejected')
    const result = await this.post('/token', {
      clientId, clientSecret, grantType: REFRESH_GRANT, refreshToken: previous.refreshToken,
    }, signal)
    if (result.status === 400 || result.status === 401 || result.status === 403) throw new AuthProtocolError('refresh-rejected')
    if (result.status !== 200) throw new AuthProtocolError('network')
    return this.credential(result.body, { clientId, clientSecret }, previous)
  }

  revoke(_credential: StoredOAuthCredential): Promise<void> {
    return Promise.resolve()
  }
}
