/** Provider operations and cross-session usage analytics over DSH-owned facts. */

import { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { TypertRemoteService, Remote } from '@deepseek-ai/dsh-typert-protocol'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import type {} from '@deepseek-ai/dsh-agent-default-model'
import type {} from '@deepseek-ai/dsh-session-persistence'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import type { SettingsDescriptor } from '@deepseek-ai/dsh-settings'
// Typert-generated ./typert and ./remote artifacts import Zod at runtime.
import type {} from 'zod'
import { foldProviderAnalytics, type SessionLogInput } from './fold.ts'
import {
  KimiCodeAuthRuntime, OpenAICodexAuthRuntime, UNAVAILABLE_AUTH_PROVIDERS, createCompatibilityAuthRuntimes,
  type CodexAuthCoordinator,
} from './auth.ts'
import { PROVIDER_PLAN_PRESETS } from '../provider-plans.ts'
import { fetchNoRedirect, readBoundedJson } from './bounded-json.ts'
import { fetchAnthropicQuota, fetchAntigravityQuota, fetchCursorQuota, fetchXaiQuota } from './provider-quotas.ts'
import { isAuthProviderInstance, shouldProjectProviderConnection } from './provider-projection.ts'
import {
  installVisionFallback,
  listVisionRoutes,
  resolveVisionFallbackConfig,
  type VisionFallbackConfig,
  type VisionFallbackView,
} from './vision-fallback.ts'
import type {
  AnalyticsQuery, AuthProviderView, CodexUsageView, ModelPriceView, OutputPriceBand, PriceOverrideRequest, ProviderAnalyticsView,
  ProviderConnectionView, ProviderHubView, ProviderPlanPresetView, ProviderProbeView, ProviderQuotaView, SavePlanProviderRequest, SaveProviderRequest,
} from '../types.ts'
import { assertCompatibleHost } from './compat-host.ts'

export type * from '../types.ts'
export { foldProviderAnalytics, outputPriceBandOf } from './fold.ts'

const SETTINGS_NS = settingsNamespace('auth-in-one')
const PI_AI_NS = settingsNamespace('llm-pi-ai')
const DEEPSEEK_NS = settingsNamespace('llm-deepseek')
const DEEPSEEK_PROVIDER = 'deepseek-official'
const DEEPSEEK_KEY_REF = 'DEEPSEEK_API_KEY'
const DEEPSEEK_PUBLIC_BASE_URL = 'https://api.deepseek.com'
const DEFAULT_CATALOG_VERSION = 'deepseek-usd-2026-08-14'
const DEEPSEEK_PRICE_SOURCE = 'https://api-docs.deepseek.com/quick_start/pricing'
const MAX_PROVIDER_PROBE_BYTES = 256 * 1024

/** One configured catalog row before its source is attached. */
export interface ModelPriceConfig extends Omit<ModelPriceView, 'source'> {}

const DEFAULT_PRICES: readonly ModelPriceConfig[] = [
  {
    provider: DEEPSEEK_PROVIDER,
    model: 'deepseek-v4-flash',
    currency: 'USD',
    sourceUrl: DEEPSEEK_PRICE_SOURCE,
    updatedAt: '2026-08-14',
    effectiveDate: '2026-08-14',
    uncachedInputPerMillion: 0.14,
    cacheReadPerMillion: 0.0028,
    outputPerMillion: 0.28,
  },
  {
    provider: DEEPSEEK_PROVIDER,
    model: 'deepseek-v4-pro',
    currency: 'USD',
    sourceUrl: DEEPSEEK_PRICE_SOURCE,
    updatedAt: '2026-08-14',
    effectiveDate: '2026-08-14',
    uncachedInputPerMillion: 0.435,
    cacheReadPerMillion: 0.003625,
    outputPerMillion: 0.87,
  },
]

/** AuthInOne settings and composition config. */
export interface Config {
  /** Version identity for the composition-owned price rows. */
  catalogVersion?: string
  /** Auditable composition-owned model prices. Empty means every cost is unknown until overridden. */
  prices?: ModelPriceConfig[]
  /** User-owned rows replacing catalog rows for an exact provider/model pair. */
  overrides?: ModelPriceConfig[]
  /** Optional image-description route used only for explicitly text-only main models. */
  visionFallback?: VisionFallbackConfig
}

const priceSchema: z<ModelPriceConfig> = z.object({
  provider: z.string().required(),
  model: z.string().required(),
  currency: z.string().required(),
  sourceUrl: z.string().required(),
  updatedAt: z.string().required(),
  effectiveDate: z.string().required(),
  uncachedInputPerMillion: z.number().min(0),
  outputPerMillion: z.number().min(0),
  cacheReadPerMillion: z.number().min(0),
  cacheWritePerMillion: z.number().min(0),
  reasoningPerMillion: z.number().min(0),
})

/** Runtime validator for plugin config and its settings namespace. */
export const Config: z<Config> = z.object({
  catalogVersion: z.string().default(DEFAULT_CATALOG_VERSION),
  prices: z.array(priceSchema).default(DEFAULT_PRICES.map(price => ({ ...price }))),
  overrides: z.array(priceSchema).default([]),
  visionFallback: z.object({
    enabled: z.boolean().default(false),
    provider: z.string().default(''),
    model: z.string().default(''),
    maxOutputTokens: z.number().step(1).min(64).max(4_096).default(512),
    timeoutMs: z.number().step(1).min(1_000).max(300_000).default(60_000),
  }).default({ enabled: false, provider: '', model: '', maxOutputTokens: 512, timeoutMs: 60_000 }),
})

declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Provider management and cross-session analytics service. */
    authInOne: AuthInOneService
  }
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function getPath(source: unknown, path: readonly string[]): unknown {
  let value = source
  for (const segment of path) {
    if (!isObject(value)) return undefined
    value = value[segment]
  }
  return value
}

function stringField(source: unknown, key: string): string | undefined {
  if (!isObject(source)) return undefined
  const value = source[key]
  return typeof value === 'string' && value.length > 0 ? value : undefined
}

function credentialRefFor(provider: string, profile: unknown): string | undefined {
  return stringField(profile, 'apiKeyEnv')
    ?? (provider === DEEPSEEK_PROVIDER ? DEEPSEEK_KEY_REF : undefined)
}

function derivedCredentialRef(provider: string): string {
  const normalized = provider.toUpperCase().replaceAll(/[^A-Z0-9]+/g, '_').replaceAll(/^_+|_+$/g, '')
  return `${normalized || 'CUSTOM_PROVIDER'}_API_KEY`
}

function displayError(error: unknown): string {
  if (error instanceof Error) return error.message
  return String(error)
}

function assertPrice(value: PriceOverrideRequest): void {
  for (const [name, entry] of Object.entries(value)) {
    if (name.endsWith('PerMillion') && entry !== undefined
      && (typeof entry !== 'number' || !Number.isFinite(entry) || entry < 0)) {
      throw new TypeError(`${name} must be a non-negative finite number`)
    }
  }
  for (const key of ['provider', 'model', 'currency', 'sourceUrl', 'updatedAt', 'effectiveDate'] as const) {
    if (value[key].trim().length === 0) throw new TypeError(`${key} must be non-empty`)
  }
}

/** Remote service using DSH session logs, adapters, settings, and credentials as authorities. */
export class AuthInOneService extends TypertRemoteService {
  static inject = ['llm', 'sessions', 'sessionPersistence', 'agentDefaultModel', 'settings', 'credentials', 'attachments']
  static Config = Config

  private source: () => Config
  private readonly auth: OpenAICodexAuthRuntime
  private readonly kimiAuth: KimiCodeAuthRuntime
  private readonly authRuntimes: readonly {
    readonly coordinator: CodexAuthCoordinator
    readonly models: readonly { readonly id: string; readonly name: string }[]
    accessToken?(signal?: AbortSignal): Promise<string>
    credential?(): Promise<import('./auth-protocol.ts').StoredOAuthCredential | undefined>
    dispose(): void
  }[]
  private readonly authReady: Promise<void>

  constructor(ctx: Context, config: Config = {}) {
    super(ctx, 'authInOne')
    assertCompatibleHost()
    this.auth = new OpenAICodexAuthRuntime(ctx)
    this.kimiAuth = new KimiCodeAuthRuntime(ctx)
    this.authRuntimes = [this.auth, this.kimiAuth, ...createCompatibilityAuthRuntimes(ctx)]
    this.authReady = Promise.all(this.authRuntimes.map(runtime => runtime.coordinator.synchronize())).then(() => undefined)
    ctx.effect(() => () => {
      for (const runtime of this.authRuntimes) runtime.dispose()
    }, 'auth-in-one: managed Auth lifecycle')
    const entry: Config = {
      catalogVersion: config.catalogVersion ?? DEFAULT_CATALOG_VERSION,
      prices: config.prices ?? DEFAULT_PRICES.map(price => ({ ...price })),
      overrides: config.overrides ?? [],
      visionFallback: resolveVisionFallbackConfig(config.visionFallback),
    }
    this.source = () => entry
    installSettingsSection(ctx, SETTINGS_NS, Config, entry, {
      setSource: current => { this.source = current },
      onChange: () => {},
      validate: (value) => {
        const seen = new Set<string>()
        for (const price of [...value.prices ?? [], ...value.overrides ?? []]) {
          assertPrice(price)
          const key = `${price.provider}\u0000${price.model}`
          if (seen.has(key) && (value.overrides ?? []).includes(price)) continue
          if (seen.has(key)) throw new Error(`duplicate catalog price for ${price.provider}/${price.model}`)
          seen.add(key)
        }
      },
    })
    installVisionFallback(ctx, () => this.source().visionFallback)
  }

  private descriptors(): Map<string, SettingsDescriptor> {
    return new Map(this.ctx.settings.describe().map(entry => [String(entry.ns), entry]))
  }

  private authRuntime(provider: string): typeof this.authRuntimes[number] | undefined {
    return this.authRuntimes.find(runtime => runtime.coordinator.snapshot().id === provider)
  }

  private prices(): ModelPriceView[] {
    const settings = this.source()
    const merged = new Map<string, ModelPriceView>()
    for (const row of settings.prices ?? []) {
      merged.set(`${row.provider}\u0000${row.model}`, { ...row, source: 'catalog' })
    }
    for (const row of settings.overrides ?? []) {
      merged.set(`${row.provider}\u0000${row.model}`, { ...row, source: 'user' })
    }
    return [...merged.values()]
  }

  private async logs(signal?: AbortSignal): Promise<SessionLogInput[]> {
    const live = new Map(this.ctx.sessions.list().map(session => [String(session.id), session]))
    const logs: SessionLogInput[] = []
    for (const header of await this.ctx.sessionPersistence.list(signal)) {
      signal?.throwIfAborted()
      const session = live.get(String(header.id))
      if (session !== undefined) {
        logs.push({ header: session.header, events: session.events })
        live.delete(String(header.id))
        continue
      }
      const stored = await this.ctx.sessionPersistence.inspect(header.id, signal)
      logs.push({ header: stored.meta, events: stored.events })
    }
    for (const session of live.values()) logs.push({ header: session.header, events: session.events })
    return logs
  }

  /** Read cross-session provider usage from live and persisted DSH logs. */
  @Remote('analytics')
  async analytics(query: AnalyticsQuery, signal: AbortSignal): Promise<ProviderAnalyticsView> {
    const bands: readonly OutputPriceBand[] = ['all', '0-1', '1-5', '5-15', '15-plus', 'unpriced']
    if (!bands.includes(query.outputPriceBand)) {
      throw new TypeError(`unsupported output price band ${JSON.stringify(query.outputPriceBand)}`)
    }
    if (query.provider !== null && query.provider.length === 0) throw new TypeError('provider filter must be null or non-empty')
    const settings = this.source()
    return foldProviderAnalytics(
      await this.logs(signal),
      query,
      this.prices(),
      settings.catalogVersion ?? DEFAULT_CATALOG_VERSION,
    )
  }

  /** Read provider routes, connection state, models, and the future-Agent default. */
  @Remote('providers')
  async providers(): Promise<ProviderHubView> {
    await this.authReady
    await Promise.all(this.authRuntimes.map(runtime => runtime.coordinator.synchronize()))
    const active = new Map(this.ctx.llm.listProviders().map(provider => [provider.id, provider]))
    const configurable = new Map(this.ctx.llm.listConfigurableProviders().map(provider => [provider.provider, provider]))
    const authInstances = this.authRuntimes
      .map(runtime => runtime.coordinator.snapshot())
      .filter(auth => isAuthProviderInstance(auth.status))
    const ids = [...new Set([
      ...configurable.keys(),
      ...active.keys(),
      ...authInstances.map(auth => auth.id),
    ])]
    const descriptors = this.descriptors()
    const candidates = await Promise.all(ids.map(async (id): Promise<ProviderConnectionView | null> => {
      const live = active.get(id)
      const entry = configurable.get(id)
      const descriptor = entry === undefined ? undefined : descriptors.get(entry.settingsNs)
      const profile = entry === undefined ? undefined : getPath(descriptor?.value, entry.settingsPath)
      const runtime = this.authRuntime(id)
      const authCatalog = runtime?.coordinator.snapshot()
      const auth = authCatalog !== undefined && isAuthProviderInstance(authCatalog.status) ? authCatalog : undefined
      if (!shouldProjectProviderConnection({
        provider: id,
        hasLiveRoute: live !== undefined,
        hasProfile: profile !== undefined,
        authStatus: auth?.status ?? null,
      })) return null
      const ref = credentialRefFor(id, profile)
      const credential = ref === undefined ? undefined : await this.ctx.credentials.describe(credentialRef(ref))
      let models: ProviderConnectionView['models'] = []
      let modelError: string | null = null
      if (live !== undefined) {
        try {
          models = (await this.ctx.llm.listModels(id)).map(model => ({ id: model.id, name: model.name }))
        } catch (error) {
          modelError = displayError(error)
        }
      }
      if (auth !== undefined && models.length === 0) models = [...runtime!.models]
      return {
        id,
        name: live?.name ?? entry?.displayName ?? auth?.name ?? id,
        active: live !== undefined,
        configurable: entry !== undefined,
        declared: entry?.declared === true,
        configured: auth === undefined ? profile !== undefined : auth.status === 'connected',
        credentialConfigured: auth === undefined
          ? credential?.configured ?? (ref === undefined ? null : false)
          : auth.status === 'connected',
        credentialWritable: auth === undefined
          ? credential?.writable ?? (ref === undefined ? null : false)
          : true,
        authMode: auth === undefined ? 'api-key-only' : 'oauth',
        accessType: auth !== undefined ? 'account-auth' : entry?.declared === true ? 'custom-api' : 'api',
        accountLabel: auth?.accountLabel ?? null,
        settingsNs: entry?.settingsNs ?? null,
        baseURL: stringField(profile, 'baseURL') ?? (id === DEEPSEEK_PROVIDER ? DEEPSEEK_PUBLIC_BASE_URL : null),
        models,
        modelError,
      }
    }))
    const providers = candidates.filter((provider): provider is ProviderConnectionView => provider !== null)
    const selection = this.ctx.agentDefaultModel.currentSelection()
    return {
      generatedAt: Date.now(),
      defaultSelection: {
        provider: selection.provider,
        model: selection.model,
        ...selection.reasoningEffort === undefined ? {} : { reasoningEffort: String(selection.reasoningEffort) },
      },
      providers,
    }
  }

  /** List browser-safe official account-login states. */
  @Remote('authProviders')
  async authProviders(): Promise<readonly AuthProviderView[]> {
    await this.authReady
    return [...await Promise.all(this.authRuntimes.map(runtime => runtime.coordinator.synchronize())), ...UNAVAILABLE_AUTH_PROVIDERS]
  }

  /** Read the allowlisted vendor API and subscription-key presets. */
  @Remote('planProviders')
  planProviders(): readonly ProviderPlanPresetView[] {
    return PROVIDER_PLAN_PRESETS
  }

  /** Read OpenAI Codex subscription windows without exposing the bearer credential. */
  @Remote('codexUsage')
  async codexUsage(signal: AbortSignal): Promise<CodexUsageView> {
    await this.authReady
    return this.auth.usage(signal)
  }

  /** Read all implemented subscription quota windows without exposing credentials. */
  @Remote('providerQuotas')
  async providerQuotas(signal: AbortSignal): Promise<readonly ProviderQuotaView[]> {
    await this.authReady
    const codex = await this.auth.usage(signal)
    const codexQuota: ProviderQuotaView = {
      provider: 'openai-codex',
      status: codex.status,
      generatedAt: codex.generatedAt,
      bestEffort: true,
      sourceUrl: codex.sourceUrl,
      windows: codex.windows.map(window => ({
        id: window.id,
        label: window.id === 'primary' ? 'Primary window' : 'Secondary window',
        usedPercent: window.usedPercent,
        remainingPercent: window.remainingPercent,
        windowSeconds: window.windowSeconds,
        resetAt: window.resetAt,
      })),
      error: codex.error,
    }
    const compatibility = await Promise.all(this.authRuntimes.flatMap(runtime => {
      if (runtime.accessToken === undefined) return []
      const provider = runtime.coordinator.snapshot().id
      if (!['xai', 'anthropic', 'cursor', 'google-antigravity'].includes(provider)) return []
      return [(async (): Promise<ProviderQuotaView> => {
        let token: string
        try {
          token = await runtime.accessToken!(signal)
        } catch {
          return {
            provider, status: 'signed-out', generatedAt: Date.now(), bestEffort: true,
            sourceUrl: runtime.coordinator.snapshot().sourceUrl, windows: [], error: null,
          }
        }
        if (provider === 'xai') return fetchXaiQuota(token, signal)
        if (provider === 'anthropic') return fetchAnthropicQuota(token, signal)
        if (provider === 'cursor') return fetchCursorQuota(token, signal)
        const credential = await runtime.credential!()
        return credential === undefined
          ? {
              provider, status: 'signed-out', generatedAt: Date.now(), bestEffort: true,
              sourceUrl: runtime.coordinator.snapshot().sourceUrl, windows: [], error: null,
            }
          : fetchAntigravityQuota(token, credential, signal)
      })()]
    }))
    return [codexQuota, await this.kimiAuth.quota(signal), ...compatibility]
  }

  /** Begin the official OpenAI Codex browser OAuth flow on the Host. */
  @Remote('startAuth')
  async startAuth(provider: string): Promise<AuthProviderView> {
    await this.authReady
    const runtime = this.authRuntime(provider)
    if (runtime === undefined) throw new TypeError(`unsupported Auth provider ${provider}`)
    return runtime.coordinator.start()
  }

  /** Cancel one plugin-local OAuth attempt without affecting stored credentials. */
  @Remote('cancelAuth')
  async cancelAuth(provider: string, attemptId: string): Promise<AuthProviderView> {
    await this.authReady
    const runtime = this.authRuntime(provider)
    if (runtime === undefined) throw new TypeError(`unsupported Auth provider ${provider}`)
    return runtime.coordinator.cancel(attemptId)
  }

  /** Submit a one-time authorization value to the matching Host transaction. */
  @Remote('submitAuth')
  async submitAuth(provider: string, attemptId: string, value: string): Promise<AuthProviderView> {
    await this.authReady
    const runtime = this.authRuntime(provider)
    if (runtime === undefined) throw new TypeError(`unsupported Auth provider ${provider}`)
    return runtime.coordinator.submit(attemptId, value)
  }

  /** Sign out and remove one Host-only account credential. */
  @Remote('logoutAuth')
  async logoutAuth(provider: string): Promise<AuthProviderView> {
    await this.authReady
    const runtime = this.authRuntime(provider)
    if (runtime === undefined) throw new TypeError(`unsupported Auth provider ${provider}`)
    return runtime.coordinator.logout()
  }

  /** Save an OpenAI-compatible route or edit the official DeepSeek route. */
  @Remote('saveProvider')
  async saveProvider(request: SaveProviderRequest): Promise<void> {
    const provider = request.provider.trim()
    const displayName = request.displayName.trim()
    const baseURL = request.baseURL.trim().replace(/\/+$/, '')
    if (!/^[a-z0-9][a-z0-9._-]*$/i.test(provider)) throw new TypeError('provider must be a stable route id')
    if (displayName.length === 0) throw new TypeError('displayName must be non-empty')
    if (!URL.canParse(baseURL) || !baseURL.startsWith('http')) throw new TypeError('baseURL must be an HTTP(S) URL')
    if (request.models.length === 0) throw new TypeError('at least one model is required')
    for (const model of request.models) {
      if (model.id.trim().length === 0) throw new TypeError('model ids must be non-empty')
    }

    const directory = this.ctx.llm.listConfigurableProviders().find(entry => entry.provider === provider)
    const settingsNs = settingsNamespace(directory?.settingsNs ?? String(PI_AI_NS))
    const settingsPath = directory?.settingsPath ?? ['providers', provider]
    const current = getPath(this.ctx.settings.get(settingsNs), settingsPath)
    const keyRef = credentialRefFor(provider, current) ?? derivedCredentialRef(provider)
    if (settingsNs === DEEPSEEK_NS) {
      await this.ctx.settings.mutate(settingsNs, [
        { op: 'set', path: ['baseURL'], value: baseURL },
        { op: 'set', path: ['models'], value: request.models },
        { op: 'set', path: ['apiKeyEnv'], value: keyRef },
      ])
    } else {
      await this.ctx.settings.mutate(settingsNs, [{
        op: 'set',
        path: settingsPath,
        value: {
          apiKeyEnv: keyRef,
          displayName,
          api: request.api ?? 'openai-completions',
          baseURL,
          models: request.models,
          ...request.headers === undefined ? {} : { headers: request.headers },
        },
      }])
    }
    if (request.apiKey !== undefined) {
      const apiKey = request.apiKey.trim()
      if (apiKey.length === 0) throw new TypeError('apiKey must be non-empty when supplied')
      await this.ctx.credentials.set(credentialRef(keyRef), apiKey)
    }
  }

  /** Save one allowlisted vendor preset while keeping its API key write-only. */
  @Remote('savePlanProvider')
  async savePlanProvider(request: SavePlanProviderRequest): Promise<void> {
    const preset = PROVIDER_PLAN_PRESETS.find(entry => entry.id === request.presetId)
    if (preset === undefined) throw new TypeError(`unsupported Provider preset ${request.presetId}`)
    await this.saveProvider({
      provider: preset.provider,
      displayName: preset.name,
      baseURL: preset.baseURL,
      api: preset.api,
      apiKey: request.apiKey,
      models: preset.models.map(model => ({ id: model.id, name: model.name })),
    })
  }

  /** Probe the configured OpenAI-compatible `/models` endpoint without exposing credentials. */
  @Remote('probe')
  async probe(provider: string, signal: AbortSignal): Promise<ProviderProbeView> {
    const startedAt = performance.now()
    try {
      const auth = this.authRuntime(provider)?.coordinator.snapshot()
      if (auth !== undefined && isAuthProviderInstance(auth.status)) {
        const models = (await this.ctx.llm.listModels(provider)).map(model => model.id)
        return { ok: true, latencyMs: Math.round(performance.now() - startedAt), models, error: null }
      }
      const directory = this.ctx.llm.listConfigurableProviders().find(entry => entry.provider === provider)
      if (directory === undefined) throw new Error('provider does not expose editable connection metadata')
      const profile = getPath(this.ctx.settings.get(settingsNamespace(directory.settingsNs)), directory.settingsPath)
      const baseURL = stringField(profile, 'baseURL') ?? (provider === DEEPSEEK_PROVIDER ? DEEPSEEK_PUBLIC_BASE_URL : undefined)
      if (baseURL === undefined) throw new Error('provider has no HTTP base URL to test')
      const ref = credentialRefFor(provider, profile)
      const resolved = ref === undefined ? undefined : await this.ctx.credentials.resolve(credentialRef(ref))
      const configuredHeaders = isObject(profile) && isObject(profile.headers)
        ? Object.fromEntries(Object.entries(profile.headers).filter((entry): entry is [string, string] => typeof entry[1] === 'string'))
        : {}
      const api = stringField(profile, 'api') ?? 'openai-completions'
      const hasCredentialHeader = Object.keys(configuredHeaders).some(key => {
        const lower = key.toLowerCase()
        return lower === 'authorization' || lower === 'x-api-key'
      })
      const headers = {
        accept: 'application/json',
        ...configuredHeaders,
        ...api === 'anthropic-messages' ? { 'anthropic-version': '2023-06-01' } : {},
        ...resolved === undefined || hasCredentialHeader ? {} : api === 'anthropic-messages'
          ? { 'x-api-key': resolved.value }
          : { authorization: `Bearer ${resolved.value}` },
      }
      const modelsUrl = api === 'anthropic-messages'
        ? `${baseURL.replace(/\/+$/, '')}/v1/models`
        : `${baseURL.replace(/\/+$/, '')}/models`
      const response = await fetchNoRedirect(modelsUrl, { headers, signal })
      if (!response.ok) throw new Error(`provider returned HTTP ${String(response.status)}`)
      const body = await readBoundedJson(response, MAX_PROVIDER_PROBE_BYTES)
      const data = isObject(body) && Array.isArray(body.data) ? body.data : []
      const models = data.flatMap((item) => isObject(item) && typeof item.id === 'string' ? [item.id] : []).slice(0, 200)
      return { ok: true, latencyMs: Math.round(performance.now() - startedAt), models, error: null }
    } catch (error) {
      if (signal.aborted) throw error
      return { ok: false, latencyMs: Math.round(performance.now() - startedAt), models: [], error: displayError(error) }
    }
  }

  /** Save the model selection used for future Agents. */
  @Remote('saveDefault')
  async saveDefault(provider: string, model: string): Promise<void> {
    await this.ctx.llm.resolveModelInfo(provider, model)
    await this.ctx.agentDefaultModel.saveSelection({ provider, model })
  }

  /** Read the optional fallback and routes whose adapters explicitly declare image input. */
  @Remote('visionFallback')
  async visionFallback(): Promise<VisionFallbackView> {
    const value = resolveVisionFallbackConfig(this.source().visionFallback)
    const providers = (await this.providers()).providers.map(provider => ({
      id: provider.id,
      name: provider.name,
      active: provider.active,
      configured: provider.configured,
      credentialConfigured: provider.credentialConfigured,
      accessType: provider.accessType,
      accountLabel: provider.accountLabel,
    }))
    const routes = await listVisionRoutes(this.ctx, providers)
    return {
      ...value,
      selectionAvailable: !value.enabled || routes.some(route => route.provider === value.provider && route.model === value.model),
      routes,
    }
  }

  /** Save the fallback without ever accepting a credential or image payload. */
  @Remote('saveVisionFallback')
  async saveVisionFallback(request: VisionFallbackConfig): Promise<void> {
    const value = resolveVisionFallbackConfig(request)
    if (value.enabled) {
      if (value.provider.length === 0 || value.model.length === 0) {
        throw new TypeError('enabled vision fallback requires a Provider and model')
      }
      const info = await this.ctx.llm.resolveModelInfo(value.provider, value.model)
      if (info.inputModalities?.includes('image') !== true) {
        throw new TypeError('vision fallback model must explicitly declare image input')
      }
    }
    await this.ctx.settings.mutate(SETTINGS_NS, [{ op: 'set', path: ['visionFallback'], value }])
  }

  /** Add or replace one durable user-owned price row. */
  @Remote('savePriceOverride')
  async savePriceOverride(request: PriceOverrideRequest): Promise<void> {
    assertPrice(request)
    const current = this.source().overrides ?? []
    const next = current.filter(row => row.provider !== request.provider || row.model !== request.model)
    next.push({ ...request })
    await this.ctx.settings.mutate(SETTINGS_NS, [{ op: 'set', path: ['overrides'], value: next }])
  }
}

export default AuthInOneService
