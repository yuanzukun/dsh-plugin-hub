/** DSH-native Google Antigravity compatibility adapter over Cloud Code Assist SSE. */

import { randomUUID } from 'node:crypto'
import {
  CallId, LlmAdapter, LlmError, attributionHeaders,
  type ContentBlock, type GenerateOptions, type LlmModelInfo, type StreamChunk, type TokenUsage,
} from '@deepseek-ai/dsh-llm'
import type { StoredOAuthCredential } from './auth-protocol.ts'

const MODELS = ['gemini-3.6-flash', 'gemini-3.1-pro', 'gemini-3.1-flash-image', 'claude-sonnet-4-6', 'claude-opus-4-6-thinking', 'gpt-oss-120b-medium'] as const
const ENDPOINT = 'https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse'
const MAX_EVENT_BYTES = 1024 * 1024

function object(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function text(blocks: readonly ContentBlock[]): string {
  return blocks.flatMap(block => block.type === 'text' || block.type === 'reasoning' ? [block.text] : []).join('\n')
}

function contents(options: GenerateOptions): readonly Record<string, unknown>[] {
  return options.messages.flatMap(message => {
    if (message.role === 'assistant') {
      const parts = message.content.flatMap((block): Record<string, unknown>[] => {
        if (block.type === 'text') return [{ text: block.text }]
        if (block.type === 'tool-call') {
          let args: unknown = {}
          try { args = JSON.parse(block.arguments) as unknown } catch { args = { raw: block.arguments } }
          return [{ functionCall: { id: block.id, name: block.name, args } }]
        }
        return []
      })
      return [{ role: 'model', parts }]
    }
    const resultParts: Record<string, unknown>[] = []
    for (const block of message.content) {
      if (block.type === 'tool-result') {
        resultParts.push({ functionResponse: { id: block.toolCallId, name: 'tool', response: { output: text(block.content), isError: block.isError === true } } })
      } else if (block.type === 'text') {
        resultParts.push({ text: block.text })
      }
    }
    return [{ role: 'user', parts: resultParts }]
  })
}

function usage(value: unknown): TokenUsage | undefined {
  const row = object(value)
  if (row === undefined) return undefined
  const prompt = row.promptTokenCount
  const output = row.candidatesTokenCount
  if (typeof prompt !== 'number' || typeof output !== 'number') return undefined
  const cached = typeof row.cachedContentTokenCount === 'number' ? row.cachedContentTokenCount : undefined
  const reasoning = typeof row.thoughtsTokenCount === 'number' ? row.thoughtsTokenCount : undefined
  return {
    inputTokens: Math.max(0, prompt - (cached ?? 0)), outputTokens: Math.max(0, output),
    ...cached === undefined ? {} : { cacheReadTokens: Math.max(0, cached) },
    ...reasoning === undefined ? {} : { reasoningTokens: Math.max(0, reasoning) },
  }
}

async function* sse(response: Response): AsyncGenerator<Record<string, unknown>> {
  if (response.body === null) throw new LlmError('Antigravity response body was empty', 'UPSTREAM')
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  try {
    while (true) {
      const result = await reader.read()
      buffer += decoder.decode(result.value, { stream: !result.done })
      buffer = buffer.replaceAll('\r\n', '\n')
      if (Buffer.byteLength(buffer) > MAX_EVENT_BYTES) throw new LlmError('Antigravity event exceeded the safe limit', 'UPSTREAM')
      let boundary = buffer.indexOf('\n\n')
      while (boundary >= 0) {
        const frame = buffer.slice(0, boundary)
        buffer = buffer.slice(boundary + 2)
        const data = frame.split('\n').filter(line => line.startsWith('data:')).map(line => line.slice(5).trim()).join('')
        if (data.length > 0 && data !== '[DONE]') {
          try {
            const parsed = object(JSON.parse(data) as unknown)
            if (parsed !== undefined) yield parsed
          } catch {
            // Non-JSON keepalives are ignored.
          }
        }
        boundary = buffer.indexOf('\n\n')
      }
      if (result.done) break
    }
  } finally {
    reader.releaseLock()
  }
}

/** Antigravity account models using only the Host-owned OAuth credential and project id. */
export class GoogleAntigravityLlmAdapter extends LlmAdapter {
  constructor(
    private readonly accessToken: (signal?: AbortSignal) => Promise<string>,
    private readonly credential: () => Promise<StoredOAuthCredential | undefined>,
    private readonly request: typeof fetch = fetch,
  ) { super() }

  override providerInfo(provider: string): { id: string; name: string } {
    return { id: provider, name: 'Google Antigravity' }
  }

  override listModels(provider: string): Promise<readonly LlmModelInfo[]> {
    return Promise.resolve(MODELS.map(id => ({ provider, id, name: id, inputModalities: ['text'] })))
  }

  override resolveModel(provider: string, model: string): Promise<LlmModelInfo & { context: { contextWindow: number } }> {
    return Promise.resolve({ provider, id: model, name: model, inputModalities: ['text'], context: { contextWindow: 1_048_576 } })
  }

  override async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const token = await this.accessToken(options.signal)
    const stored = await this.credential()
    const projectId = stored?.providerData?.projectId
    if (typeof projectId !== 'string' || projectId.length === 0) throw new LlmError('Antigravity credential has no Cloud Code Assist project', 'AUTH')
    const response = await this.request(ENDPOINT, {
      method: 'POST',
      headers: {
        ...attributionHeaders(), authorization: `Bearer ${token}`, accept: 'text/event-stream', 'content-type': 'application/json',
        'user-agent': `antigravity/cli/1.0.13 (aidev_client; os_type=${process.platform}; arch=${process.arch})`,
        'x-goog-api-client': 'google-api-nodejs-client/10.3.0',
      },
      body: JSON.stringify({
        project: projectId,
        model: options.model,
        requestId: randomUUID(),
        userAgent: 'antigravity',
        request: {
          contents: contents(options),
          ...options.system === undefined ? {} : { systemInstruction: { role: 'user', parts: [{ text: options.system }] } },
          ...options.tools === undefined || options.tools.length === 0 ? {} : {
            tools: [{ functionDeclarations: options.tools.map(tool => ({ name: tool.name, description: tool.description, parameters: tool.parameters })) }],
          },
          generationConfig: {
            ...options.temperature === undefined ? {} : { temperature: options.temperature },
            ...options.maxTokens === undefined ? {} : { maxOutputTokens: options.maxTokens },
          },
        },
      }),
      ...options.signal === undefined ? {} : { signal: options.signal },
    })
    if (!response.ok) throw new LlmError(`Antigravity returned HTTP ${String(response.status)}`, 'UPSTREAM', { status: response.status })
    let nextIndex = 0
    let textIndex: number | undefined
    let textValue = ''
    let sawTool = false
    let tokenUsage: TokenUsage | undefined
    for await (const envelope of sse(response)) {
      const payload = object(envelope.response) ?? envelope
      tokenUsage = usage(payload.usageMetadata) ?? tokenUsage
      const candidates = Array.isArray(payload.candidates) ? payload.candidates : []
      for (const candidate of candidates) {
        const parts = object(object(candidate)?.content)?.parts
        if (!Array.isArray(parts)) continue
        for (const rawPart of parts) {
          const part = object(rawPart)
          if (typeof part?.text === 'string' && part.text.length > 0) {
            if (textIndex === undefined) { textIndex = nextIndex++; yield { type: 'block-start', index: textIndex, blockType: 'text' } }
            textValue += part.text
            yield { type: 'text-delta', index: textIndex, text: part.text }
          }
          const call = object(part?.functionCall)
          if (call !== undefined && typeof call.name === 'string') {
            sawTool = true
            const index = nextIndex++
            const id = CallId(typeof call.id === 'string' ? call.id : randomUUID())
            const args = JSON.stringify(call.args ?? {})
            yield { type: 'block-start', index, blockType: 'tool-call' }
            yield { type: 'tool-call-delta', index, id, name: call.name, argumentsDelta: args }
            yield { type: 'block-end', index, block: { type: 'tool-call', id, name: call.name, arguments: args } }
          }
        }
      }
    }
    if (textIndex !== undefined) yield { type: 'block-end', index: textIndex, block: { type: 'text', text: textValue } }
    if (tokenUsage !== undefined) yield { type: 'usage', usage: tokenUsage }
    yield { type: 'finish', reason: { kind: sawTool ? 'tool-calls' : 'stop' } }
  }
}
