/** Minimal DSH-native Kiro subscription transport over AWS event streams. */

import { randomUUID } from 'node:crypto'
import { crc32 } from 'node:zlib'
import {
  CallId, LlmAdapter, LlmError, attributionHeaders,
  type ContentBlock, type GenerateOptions, type LlmModelInfo, type StreamChunk, type TokenUsage,
} from '@deepseek-ai/dsh-llm'
import type { StoredOAuthCredential } from './auth-protocol.ts'

const KIRO_MODELS = [
  'kiro-auto', 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna', 'claude-sonnet-5', 'claude-opus-5',
  'claude-opus-4.8', 'claude-sonnet-4.6', 'deepseek-3.2', 'minimax-m2.5', 'glm-5', 'qwen3-coder-next',
] as const
const MAX_FRAME = 16 * 1024 * 1024

function object(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function text(blocks: readonly ContentBlock[]): string {
  return blocks.flatMap(block => block.type === 'text' || block.type === 'reasoning' ? [block.text] : []).join('\n')
}

function toolName(value: string): string {
  const cleaned = value.replaceAll(/[^A-Za-z0-9_-]/g, '_') || 'tool'
  return cleaned.slice(0, 64)
}

function modelId(value: string): string {
  return value.replace(/^kiro[-/]/, '').replace('kiro-auto', 'auto')
}

function wire(options: GenerateOptions): Record<string, unknown> {
  const conversationId = randomUUID()
  const history: Record<string, unknown>[] = []
  let current = ''
  for (const message of options.messages) {
    if (message.role === 'assistant') {
      const toolUses = message.content.flatMap(block => {
        if (block.type !== 'tool-call') return []
        let input: unknown = {}
        try { input = JSON.parse(block.arguments) as unknown } catch { input = { raw: block.arguments } }
        return [{ name: toolName(block.name), input, toolUseId: String(block.id).replaceAll(/[^A-Za-z0-9_-]/g, '_').slice(0, 64) }]
      })
      history.push({ assistantResponseMessage: { content: text(message.content), ...toolUses.length === 0 ? {} : { toolUses } } })
      continue
    }
    const results = message.content.flatMap(block => block.type === 'tool-result' ? [{
      content: [{ text: text(block.content) || '(empty result)' }],
      status: block.isError === true ? 'error' : 'success',
      toolUseId: String(block.toolCallId).replaceAll(/[^A-Za-z0-9_-]/g, '_').slice(0, 64),
    }] : [])
    const content = text(message.content)
    const userInputMessage = {
      content,
      modelId: modelId(options.model),
      origin: 'KIRO_CLI',
      ...results.length === 0 ? {} : { userInputMessageContext: { toolResults: results } },
    }
    history.push({ userInputMessage })
  }
  const last = history.at(-1)
  if (last !== undefined && object(last)?.userInputMessage !== undefined) {
    current = JSON.stringify(last)
    history.pop()
  }
  let currentMessage = current.length > 0
    ? object(JSON.parse(current) as unknown)?.userInputMessage as Record<string, unknown>
    : { content: 'Continue.', modelId: modelId(options.model), origin: 'KIRO_CLI' }
  if (options.system !== undefined && options.system.trim().length > 0) {
    currentMessage = { ...currentMessage, content: `${options.system}\n\n${String(currentMessage.content ?? '')}` }
  }
  if ((options.tools?.length ?? 0) > 0) {
    const tools = options.tools!.map(tool => ({
      toolSpecification: { name: toolName(tool.name), description: tool.description, inputSchema: { json: tool.parameters } },
    }))
    currentMessage = {
      ...currentMessage,
      userInputMessageContext: { ...object(currentMessage.userInputMessageContext), tools },
    }
  }
  return {
    conversationState: {
      chatTriggerType: 'MANUAL', agentContinuationId: randomUUID(), agentTaskType: 'vibe', conversationId,
      currentMessage: { userInputMessage: currentMessage },
      ...history.length === 0 ? {} : { history },
    },
  }
}

function parseHeaders(bytes: Uint8Array): Record<string, string> {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  const decoder = new TextDecoder()
  const headers: Record<string, string> = {}
  let offset = 0
  while (offset < bytes.length) {
    const nameLength = view.getUint8(offset); offset += 1
    if (offset + nameLength + 1 > bytes.length) throw new LlmError('Kiro event header was truncated', 'UPSTREAM')
    const name = decoder.decode(bytes.subarray(offset, offset + nameLength)); offset += nameLength
    const type = view.getUint8(offset); offset += 1
    if (type !== 7 || offset + 2 > bytes.length) throw new LlmError('Kiro event header type was unsupported', 'UPSTREAM')
    const valueLength = view.getUint16(offset, false); offset += 2
    if (offset + valueLength > bytes.length) throw new LlmError('Kiro event header value was truncated', 'UPSTREAM')
    headers[name] = decoder.decode(bytes.subarray(offset, offset + valueLength)); offset += valueLength
  }
  return headers
}

async function* events(body: ReadableStream<Uint8Array>): AsyncGenerator<{ headers: Record<string, string>; payload: Uint8Array }> {
  const reader = body.getReader()
  let buffered = new Uint8Array()
  try {
    while (true) {
      const result = await reader.read()
      if (result.value !== undefined) {
        const joined = new Uint8Array(buffered.length + result.value.length)
        joined.set(buffered); joined.set(result.value, buffered.length); buffered = joined
      }
      while (buffered.length >= 12) {
        const view = new DataView(buffered.buffer, buffered.byteOffset, buffered.byteLength)
        const total = view.getUint32(0, false)
        const headerLength = view.getUint32(4, false)
        if (total < 16 || total > MAX_FRAME || headerLength > total - 16) throw new LlmError('Kiro event frame was invalid', 'UPSTREAM')
        if (buffered.length < total) break
        const preludeChecksum = view.getUint32(8, false)
        const expectedPreludeChecksum = crc32(buffered.subarray(0, 8)) >>> 0
        const messageChecksum = view.getUint32(total - 4, false)
        const expectedMessageChecksum = crc32(buffered.subarray(0, total - 4)) >>> 0
        if (preludeChecksum !== expectedPreludeChecksum || messageChecksum !== expectedMessageChecksum) {
          throw new LlmError('Kiro event frame checksum was invalid', 'UPSTREAM')
        }
        yield {
          headers: parseHeaders(buffered.subarray(12, 12 + headerLength)),
          payload: buffered.subarray(12 + headerLength, total - 4),
        }
        buffered = buffered.slice(total)
      }
      if (result.done) break
    }
    if (buffered.length > 0) throw new LlmError('Kiro event stream ended mid-frame', 'UPSTREAM')
  } finally {
    reader.releaseLock()
  }
}

function usage(value: unknown): TokenUsage | undefined {
  const row = object(value)
  if (row === undefined) return undefined
  const input = row.uncachedInputTokens
  const output = row.outputTokens
  if (typeof input !== 'number' || !Number.isFinite(input) || input < 0
    || typeof output !== 'number' || !Number.isFinite(output) || output < 0) return undefined
  const cacheRead = row.cacheReadInputTokens
  const cacheWrite = row.cacheWriteInputTokens
  return {
    inputTokens: input,
    outputTokens: output,
    ...typeof cacheRead === 'number' && Number.isFinite(cacheRead) && cacheRead >= 0 ? { cacheReadTokens: cacheRead } : {},
    ...typeof cacheWrite === 'number' && Number.isFinite(cacheWrite) && cacheWrite >= 0 ? { cacheWriteTokens: cacheWrite } : {},
  }
}

/** Experimental Kiro CLI-wire adapter using only the credential created by this plugin. */
export class KiroLlmAdapter extends LlmAdapter {
  constructor(
    private readonly accessToken: (signal?: AbortSignal) => Promise<string>,
    private readonly credential: () => Promise<StoredOAuthCredential | undefined>,
    private readonly request: typeof fetch = fetch,
  ) { super() }

  override providerInfo(provider: string): { id: string; name: string } {
    return { id: provider, name: 'Kiro' }
  }

  override listModels(provider: string): Promise<readonly LlmModelInfo[]> {
    return Promise.resolve(KIRO_MODELS.map(id => ({ provider, id, name: id, inputModalities: ['text'] })))
  }

  override resolveModel(provider: string, model: string): Promise<LlmModelInfo & { context: { contextWindow: number } }> {
    return Promise.resolve({ provider, id: model, name: model, inputModalities: ['text'], context: { contextWindow: 200_000 } })
  }

  override async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const token = await this.accessToken(options.signal)
    const stored = await this.credential()
    const region = typeof stored?.providerData?.region === 'string' ? stored.providerData.region : 'us-east-1'
    const profileArn = typeof stored?.providerData?.profileArn === 'string' ? stored.providerData.profileArn : undefined
    const response = await this.request(`https://runtime.${region}.kiro.dev/`, {
      method: 'POST',
      headers: {
        ...attributionHeaders(), authorization: `Bearer ${token}`, 'content-type': 'application/x-amz-json-1.0',
        accept: 'application/vnd.amazon.eventstream',
        'x-amz-target': 'AmazonCodeWhispererStreamingService.GenerateAssistantResponse',
        'user-agent': 'aws-sdk-rust/1.3.15 ua/2.1 api/codewhispererstreaming/0.1.17975 lang/rust m/F app/AmazonQ-For-CLI',
        'x-amz-user-agent': 'aws-sdk-rust/1.3.15 api/codewhispererstreaming/0.1.17975',
        'x-amzn-codewhisperer-optout': 'true', 'amz-sdk-request': 'attempt=1; max=1',
        'amz-sdk-invocation-id': randomUUID(),
        ...profileArn === undefined ? {} : { 'x-amzn-kiro-profile-arn': profileArn },
      },
      body: JSON.stringify(wire(options)),
      ...options.signal === undefined ? {} : { signal: options.signal },
    })
    if (!response.ok) throw new LlmError(`Kiro returned HTTP ${String(response.status)}`, 'UPSTREAM', { status: response.status })
    if (response.body === null) throw new LlmError('Kiro returned an empty stream', 'UPSTREAM')
    const decoder = new TextDecoder()
    let textValue = ''
    let reasoningValue = ''
    let textOpen = false
    let reasoningOpen = false
    let textIndex = 0
    let reasoningIndex = 0
    let nextIndex = 0
    let sawTool = false
    let tokenUsage: TokenUsage | undefined
    const openTools = new Map<string, { index: number; id: ReturnType<typeof CallId>; name: string; args: string }>()
    for await (const frame of events(response.body)) {
      if (frame.headers[':message-type'] !== 'event') throw new LlmError('Kiro returned an event-stream exception', 'UPSTREAM')
      const eventType = frame.headers[':event-type']
      const payload = object(JSON.parse(decoder.decode(frame.payload)) as unknown)
      if (payload === undefined) continue
      if (eventType === 'assistantResponseEvent' && typeof payload.content === 'string') {
        if (!textOpen) { textOpen = true; textIndex = nextIndex++; yield { type: 'block-start', index: textIndex, blockType: 'text' } }
        textValue += payload.content
        yield { type: 'text-delta', index: textIndex, text: payload.content }
      } else if (eventType === 'reasoningContentEvent' && typeof payload.text === 'string') {
        if (!reasoningOpen) { reasoningOpen = true; reasoningIndex = nextIndex++; yield { type: 'block-start', index: reasoningIndex, blockType: 'reasoning' } }
        reasoningValue += payload.text
        yield { type: 'reasoning-delta', index: reasoningIndex, text: payload.text }
      } else if (eventType === 'toolUseEvent') {
        const key = typeof payload.toolUseId === 'string' ? payload.toolUseId : randomUUID()
        let tool = openTools.get(key)
        if (tool === undefined) {
          const id = CallId(key)
          tool = { index: nextIndex++, id, name: typeof payload.name === 'string' ? payload.name : 'tool', args: '' }
          openTools.set(key, tool)
          sawTool = true
          yield { type: 'block-start', index: tool.index, blockType: 'tool-call' }
        }
        if (typeof payload.input === 'string' && payload.input.length > 0) {
          tool.args += payload.input
          yield { type: 'tool-call-delta', index: tool.index, id: tool.id, name: tool.name, argumentsDelta: payload.input }
        }
        if (payload.stop === true) {
          yield { type: 'block-end', index: tool.index, block: { type: 'tool-call', id: tool.id, name: tool.name, arguments: tool.args } }
          openTools.delete(key)
        }
      } else if (eventType === 'metadataEvent') {
        tokenUsage = usage(payload.tokenUsage) ?? tokenUsage
      } else if (eventType === 'invalidStateEvent' || eventType === 'error') {
        throw new LlmError('Kiro upstream reported a request error', 'UPSTREAM')
      }
    }
    if (textOpen) yield { type: 'block-end', index: textIndex, block: { type: 'text', text: textValue } }
    if (reasoningOpen) yield { type: 'block-end', index: reasoningIndex, block: { type: 'reasoning', text: reasoningValue } }
    for (const tool of openTools.values()) {
      yield { type: 'block-end', index: tool.index, block: { type: 'tool-call', id: tool.id, name: tool.name, arguments: tool.args } }
    }
    if (tokenUsage !== undefined) yield { type: 'usage', usage: tokenUsage }
    yield { type: 'finish', reason: { kind: sawTool ? 'tool-calls' : 'stop' } }
  }
}
