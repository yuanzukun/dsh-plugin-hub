/** Host-only compatibility login protocols that are not supplied by pi-ai. */

import { createHash, randomBytes, randomUUID } from 'node:crypto'
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { AuthProtocolError, type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts'
import { readBoundedJson } from './bounded-json.ts'

const MAX_RESPONSE_BYTES = 64 * 1024
const REQUEST_TIMEOUT_MS = 15_000

function base64Url(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString('base64url')
}

function newPkce(): { verifier: string; challenge: string } {
  const verifier = base64Url(randomBytes(64))
  return { verifier, challenge: createHash('sha256').update(verifier).digest('base64url') }
}

function jwtFields(token: string): { expiresAt?: number; accountId?: string; email?: string } {
  const segment = token.split('.')[1]
  if (segment === undefined) return {}
  try {
    const value: unknown = JSON.parse(Buffer.from(segment, 'base64url').toString('utf8'))
    if (typeof value !== 'object' || value === null || Array.isArray(value)) return {}
    const row = value as Record<string, unknown>
    return {
      ...typeof row.exp === 'number' && Number.isFinite(row.exp) ? { expiresAt: row.exp * 1_000 - 5 * 60 * 1_000 } : {},
      ...typeof row.sub === 'string' && row.sub.length > 0 ? { accountId: row.sub } : {},
      ...typeof row.email === 'string' && row.email.length > 0 ? { email: row.email.toLowerCase() } : {},
    }
  } catch {
    return {}
  }
}

async function boundedJson(response: Response): Promise<Record<string, unknown> | undefined> {
  const value = await readBoundedJson(response, MAX_RESPONSE_BYTES)
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function wait(milliseconds: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(new AuthProtocolError('cancelled'))
      return
    }
    const timer = setTimeout(resolve, milliseconds)
    signal.addEventListener('abort', () => {
      clearTimeout(timer)
      reject(new AuthProtocolError('cancelled'))
    }, { once: true })
  })
}

function requestSignal(signal?: AbortSignal): AbortSignal {
  const timeout = AbortSignal.timeout(REQUEST_TIMEOUT_MS)
  return signal === undefined ? timeout : AbortSignal.any([signal, timeout])
}

/** Options used by Cursor mock-server tests. */
export interface CursorAuthOptions {
  readonly loginUrl?: string
  readonly pollUrl?: string
  readonly refreshUrl?: string
  readonly fetch?: typeof fetch
  readonly now?: () => number
  readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>
  readonly initialPollMs?: number
  readonly maxPolls?: number
}

/** Cursor's standalone PKCE poll login with DSH-owned persistence. */
export class CursorCompatibilityAdapter implements AuthProviderAdapter {
  readonly id = 'cursor'
  readonly name = 'Cursor'
  private readonly loginUrl: string
  private readonly pollUrl: string
  private readonly refreshUrl: string
  private readonly request: typeof fetch
  private readonly now: () => number
  private readonly pause: (milliseconds: number, signal: AbortSignal) => Promise<void>
  private readonly initialPollMs: number
  private readonly maxPolls: number

  constructor(options: CursorAuthOptions = {}) {
    this.loginUrl = options.loginUrl ?? 'https://cursor.com/loginDeepControl'
    this.pollUrl = options.pollUrl ?? 'https://api2.cursor.sh/auth/poll'
    this.refreshUrl = options.refreshUrl ?? 'https://api2.cursor.sh/auth/exchange_user_api_key'
    this.request = options.fetch ?? fetch
    this.now = options.now ?? Date.now
    this.pause = options.sleep ?? wait
    this.initialPollMs = options.initialPollMs ?? 1_000
    this.maxPolls = options.maxPolls ?? 150
  }

  async start(signal?: AbortSignal): Promise<AuthLoginHandle> {
    const controller = new AbortController()
    const combined = signal === undefined ? controller.signal : AbortSignal.any([controller.signal, signal])
    const { verifier, challenge } = newPkce()
    const uuid = randomUUID()
    const authorizationUrl = `${this.loginUrl}?${new URLSearchParams({ challenge, uuid, mode: 'login', redirectTarget: 'cli' })}`
    const completion = (async (): Promise<StoredOAuthCredential> => {
      let delay = this.initialPollMs
      let failures = 0
      for (let attempt = 0; attempt < this.maxPolls; attempt += 1) {
        await this.pause(delay, combined)
        let response: Response
        try {
          const url = `${this.pollUrl}?${new URLSearchParams({ uuid, verifier })}`
          response = await this.request(url, { signal: requestSignal(combined) })
        } catch {
          if (combined.aborted) throw new AuthProtocolError('cancelled')
          failures += 1
          if (failures >= 3) throw new AuthProtocolError('network')
          delay = Math.min(Math.ceil(delay * 1.2), 10_000)
          continue
        }
        if (response.status === 404) {
          failures = 0
          delay = Math.min(Math.ceil(delay * 1.2), 10_000)
          continue
        }
        if (!response.ok) {
          failures += 1
          if (failures >= 3 || (response.status !== 429 && response.status < 500)) throw new AuthProtocolError('denied')
          delay = Math.min(Math.ceil(delay * 1.2), 10_000)
          continue
        }
        const body = await boundedJson(response)
        const accessToken = body?.accessToken
        const refreshToken = body?.refreshToken
        if (typeof accessToken !== 'string' || accessToken.length === 0
          || typeof refreshToken !== 'string' || refreshToken.length === 0) throw new AuthProtocolError('invalid-response')
        const identity = jwtFields(accessToken)
        return {
          version: 1,
          accessToken,
          refreshToken,
          expiresAt: identity.expiresAt ?? this.now() + 60 * 60 * 1_000,
          ...identity.accountId === undefined ? {} : { accountId: identity.accountId },
          ...identity.email === undefined ? {} : { email: identity.email },
        }
      }
      throw new AuthProtocolError('expired')
    })()
    return {
      authorizationUrl,
      expiresAt: this.now() + 15 * 60 * 1_000,
      completion,
      cancel: () => { controller.abort() },
    }
  }

  async refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential> {
    let response: Response
    try {
      response = await this.request(this.refreshUrl, {
        method: 'POST',
        headers: { authorization: `Bearer ${previous.refreshToken}`, 'content-type': 'application/json' },
        body: '{}',
        signal: requestSignal(signal),
      })
    } catch {
      throw new AuthProtocolError(signal?.aborted === true ? 'cancelled' : 'network')
    }
    if (response.status === 401 || response.status === 403) throw new AuthProtocolError('refresh-rejected')
    if (!response.ok) throw new AuthProtocolError('network')
    const body = await boundedJson(response)
    const accessToken = body?.accessToken
    const refreshToken = body?.refreshToken
    if (typeof accessToken !== 'string' || accessToken.length === 0) throw new AuthProtocolError('invalid-response')
    const identity = jwtFields(accessToken)
    return {
      version: 1,
      accessToken,
      refreshToken: typeof refreshToken === 'string' && refreshToken.length > 0 ? refreshToken : previous.refreshToken,
      expiresAt: identity.expiresAt ?? this.now() + 60 * 60 * 1_000,
      ...identity.accountId === undefined ? {} : { accountId: identity.accountId },
      ...identity.email === undefined ? {} : { email: identity.email },
    }
  }

  revoke(_credential: StoredOAuthCredential): Promise<void> {
    return Promise.resolve()
  }
}

/** Options used by Command Code callback mock tests. */
export interface CommandCodeAuthOptions {
  readonly studioUrl?: string
  readonly callbackPorts?: readonly number[]
  readonly timeoutMs?: number
  readonly now?: () => number
}

interface CommandCallback {
  readonly apiKey: string
  readonly userId: string
}

function readCommandCallback(request: IncomingMessage, expectedState: string): Promise<CommandCallback> {
  return new Promise((resolve, reject) => {
    let total = 0
    const chunks: Uint8Array[] = []
    request.on('data', (chunk: Buffer) => {
      total += chunk.byteLength
      if (total > MAX_RESPONSE_BYTES) {
        reject(new AuthProtocolError('invalid-response'))
        request.destroy()
        return
      }
      chunks.push(chunk)
    })
    request.on('end', () => {
      try {
        const body: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        if (typeof body !== 'object' || body === null || Array.isArray(body)) throw new Error('invalid')
        const row = body as Record<string, unknown>
        if (row.state !== expectedState || typeof row.apiKey !== 'string' || row.apiKey.length === 0
          || typeof row.userId !== 'string' || row.userId.length === 0) throw new Error('invalid')
        resolve({ apiKey: row.apiKey, userId: row.userId })
      } catch {
        reject(new AuthProtocolError('state-mismatch'))
      }
    })
    request.on('error', () => { reject(new AuthProtocolError('network')) })
  })
}

function reply(response: ServerResponse, status: number, body: Record<string, unknown>, origin?: string): void {
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'access-control-allow-origin': origin ?? 'https://commandcode.ai',
    'access-control-allow-methods': 'POST, OPTIONS',
    'access-control-allow-headers': 'Content-Type',
  })
  response.end(JSON.stringify(body))
}

/** Command Code's account callback login without reading a local CLI credential. */
export class CommandCodeCompatibilityAdapter implements AuthProviderAdapter {
  readonly id = 'command-code'
  readonly name = 'Command Code'
  private readonly studioUrl: string
  private readonly callbackPorts: readonly number[]
  private readonly timeoutMs: number
  private readonly now: () => number

  constructor(options: CommandCodeAuthOptions = {}) {
    this.studioUrl = (options.studioUrl ?? 'https://commandcode.ai').replace(/\/+$/, '')
    this.callbackPorts = options.callbackPorts ?? [5959, 0]
    this.timeoutMs = options.timeoutMs ?? 2 * 60 * 1_000
    this.now = options.now ?? Date.now
  }

  async start(signal?: AbortSignal): Promise<AuthLoginHandle> {
    const controller = new AbortController()
    const combined = signal === undefined ? controller.signal : AbortSignal.any([controller.signal, signal])
    const state = base64Url(randomBytes(32))
    let settle!: (value: CommandCallback) => void
    let fail!: (error: unknown) => void
    const callback = new Promise<CommandCallback>((resolve, reject) => { settle = resolve; fail = reject })
    let server: ReturnType<typeof createServer> | undefined
    for (const port of this.callbackPorts) {
      const candidate = createServer((request, response) => {
        const origin = request.headers.origin === this.studioUrl ? this.studioUrl : undefined
        if (request.method === 'OPTIONS') {
          reply(response, 204, {}, origin)
          return
        }
        if (request.url !== '/callback' || request.method !== 'POST') {
          reply(response, 404, { success: false }, origin)
          return
        }
        void readCommandCallback(request, state).then(value => {
          reply(response, 200, { success: true }, origin)
          settle(value)
        }, error => {
          reply(response, 400, { success: false }, origin)
          if (!(error instanceof AuthProtocolError) || error.category !== 'state-mismatch') fail(error)
        })
      })
      const listening = await new Promise<boolean>(resolve => {
        candidate.once('error', () => { resolve(false) })
        candidate.listen(port, '127.0.0.1', () => { resolve(true) })
      })
      if (listening) {
        server = candidate
        break
      }
      candidate.close()
    }
    if (server === undefined) throw new AuthProtocolError('callback-unavailable')
    const address = server.address()
    if (address === null || typeof address === 'string') {
      server.close()
      throw new AuthProtocolError('callback-unavailable')
    }
    const callbackUrl = `http://127.0.0.1:${address.port}/callback`
    const authorizationUrl = `${this.studioUrl}/studio/auth/cli?${new URLSearchParams({ callback: callbackUrl, state })}`
    const timeout = setTimeout(() => { fail(new AuthProtocolError('expired')) }, this.timeoutMs)
    const abort = (): void => { fail(new AuthProtocolError('cancelled')) }
    combined.addEventListener('abort', abort, { once: true })
    const completion = callback.then(value => ({
      version: 1 as const,
      accessToken: value.apiKey,
      refreshToken: value.apiKey,
      expiresAt: Number.MAX_SAFE_INTEGER,
      accountId: value.userId,
    })).finally(() => {
      clearTimeout(timeout)
      combined.removeEventListener('abort', abort)
      server?.close()
    })
    return {
      authorizationUrl,
      expiresAt: this.now() + this.timeoutMs,
      completion,
      cancel: () => { controller.abort() },
    }
  }

  refresh(previous: StoredOAuthCredential): Promise<StoredOAuthCredential> {
    const { needsReauth: _needsReauth, ...credential } = previous
    return Promise.resolve({ ...credential, expiresAt: Number.MAX_SAFE_INTEGER })
  }

  revoke(_credential: StoredOAuthCredential): Promise<void> {
    return Promise.resolve()
  }
}
