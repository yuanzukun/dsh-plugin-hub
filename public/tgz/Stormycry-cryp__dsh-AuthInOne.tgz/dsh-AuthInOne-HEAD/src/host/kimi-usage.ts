/** Best-effort Kimi Code quota projection with no credential in its result. */

import type { ProviderQuotaView, ProviderQuotaWindowView } from '../types.ts'
import { readBoundedJson } from './bounded-json.ts'

export const KIMI_USAGE_SOURCE = 'https://api.kimi.com/coding/v1/usages'
const MAX_RESPONSE_BYTES = 64 * 1024

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function finite(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim().length > 0) {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return undefined
}

function percent(value: unknown): number | undefined {
  const parsed = finite(value)
  if (parsed === undefined) return undefined
  const normalized = parsed >= 0 && parsed <= 1 ? parsed * 100 : parsed
  return Math.min(100, Math.max(0, normalized))
}

function resetAt(row: Record<string, unknown>): number | null {
  const raw = row.resetTime ?? row.resetAt ?? row.reset_time ?? row.reset_at
  if (typeof raw === 'string') {
    const parsed = Date.parse(raw)
    return Number.isFinite(parsed) ? parsed : null
  }
  const numeric = finite(raw)
  if (numeric === undefined) return null
  return numeric < 10_000_000_000 ? numeric * 1_000 : numeric
}

function windowOf(
  id: string,
  label: string,
  value: unknown,
  durationSeconds: number | null,
  resetFallback?: Record<string, unknown>,
): ProviderQuotaWindowView | undefined {
  const row = record(value)
  if (row === undefined) return undefined
  const limit = finite(row.limit)
  let used = finite(row.used)
  if (used === undefined && limit !== undefined) {
    const remaining = finite(row.remaining)
    if (remaining !== undefined) used = limit - remaining
  }
  const usedPercent = limit !== undefined && limit > 0 && used !== undefined
    ? percent(used / limit)
    : percent(row.utilization ?? row.percent ?? row.usedPercent ?? row.used_percent)
  if (usedPercent === undefined) return undefined
  return {
    id,
    label,
    usedPercent,
    remainingPercent: Math.max(0, 100 - usedPercent),
    windowSeconds: durationSeconds,
    resetAt: resetAt(row) ?? (resetFallback === undefined ? null : resetAt(resetFallback)),
  }
}

function windowKind(item: Record<string, unknown>, detail: Record<string, unknown>, window: Record<string, unknown>): 'five-hour' | 'weekly' | undefined {
  const duration = finite(window.duration ?? item.duration ?? detail.duration)
  const unit = String(window.timeUnit ?? item.timeUnit ?? detail.timeUnit ?? '').toLowerCase()
  const text = [item.name, item.title, item.scope, detail.name, detail.title]
    .filter((value): value is string => typeof value === 'string').join(' ').toLowerCase()
  if ((unit.includes('minute') && duration === 300) || (unit.includes('hour') && duration === 5) || /(^|\b)5\s*(h|hour)/.test(text)) return 'five-hour'
  if ((unit.includes('day') && duration === 7) || (unit.includes('hour') && duration === 168) || /weekly|7\s*(d|day)/.test(text)) return 'weekly'
  return undefined
}

/** Parse only recognized Kimi windows; unknown fields never become invented quota. */
export function parseKimiUsage(value: unknown): readonly ProviderQuotaWindowView[] {
  const outer = record(value)
  if (outer === undefined) return []
  const nested = record(outer.data)
  const body = nested !== undefined && outer.usage == null && outer.limits == null ? nested : outer
  const windows = new Map<string, ProviderQuotaWindowView>()
  const weekly = windowOf('weekly', '7 days', body.usage, 7 * 24 * 60 * 60)
  if (weekly !== undefined) windows.set(weekly.id, weekly)
  if (Array.isArray(body.limits)) {
    for (const raw of body.limits) {
      const item = record(raw)
      if (item === undefined) continue
      const detail = record(item.detail) ?? item
      const window = record(item.window) ?? {}
      const kind = windowKind(item, detail, window)
      if (kind === undefined) continue
      const parsed = windowOf(
        kind,
        kind === 'five-hour' ? '5 hours' : '7 days',
        detail,
        kind === 'five-hour' ? 5 * 60 * 60 : 7 * 24 * 60 * 60,
        window,
      )
      if (parsed !== undefined) windows.set(kind, parsed)
    }
  }
  const total = windowOf('subscription', 'Subscription credits', body.totalQuota, null)
  if (total !== undefined) windows.set(total.id, total)
  return [...windows.values()]
}

/** Fetch Kimi quota without returning or logging the bearer token. */
export async function fetchKimiUsage(accessToken: string, signal?: AbortSignal, request: typeof fetch = fetch): Promise<ProviderQuotaView> {
  try {
    const timeout = AbortSignal.timeout(15_000)
    const response = await request(KIMI_USAGE_SOURCE, {
      headers: { accept: 'application/json', authorization: `Bearer ${accessToken}` },
      signal: signal === undefined ? timeout : AbortSignal.any([signal, timeout]),
    })
    if (!response.ok) throw new Error('unavailable')
    const body = await readBoundedJson(response, MAX_RESPONSE_BYTES)
    const windows = parseKimiUsage(body)
    if (windows.length === 0) throw new Error('unavailable')
    return {
      provider: 'kimi-code', status: 'available', generatedAt: Date.now(), bestEffort: true,
      sourceUrl: KIMI_USAGE_SOURCE, windows, error: null,
    }
  } catch (error) {
    if (signal?.aborted === true) throw error
    return {
      provider: 'kimi-code', status: 'unavailable', generatedAt: Date.now(), bestEffort: true,
      sourceUrl: KIMI_USAGE_SOURCE, windows: [], error: 'Kimi Code quota is temporarily unavailable.',
    }
  }
}
