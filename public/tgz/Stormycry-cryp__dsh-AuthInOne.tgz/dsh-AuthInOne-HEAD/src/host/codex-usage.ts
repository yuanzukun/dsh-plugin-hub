/** Best-effort OpenAI Codex subscription-limit projection. */

import type { CodexUsageView, CodexUsageWindowView } from '../types.ts'

export const CODEX_USAGE_SOURCE = 'https://chatgpt.com/backend-api/codex/usage'
const REQUEST_TIMEOUT_MS = 10_000
const MAX_RESPONSE_BYTES = 64 * 1024

interface CodexUsageOptions {
  readonly fetch?: typeof fetch
  readonly sourceUrl?: string
  readonly timeoutMs?: number
  readonly now?: () => number
}
function object(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

async function boundedJson(response: Response): Promise<unknown> {
  const declared = Number(response.headers.get('content-length'))
  if (Number.isFinite(declared) && declared > MAX_RESPONSE_BYTES) return undefined
  const reader = response.body?.getReader()
  if (reader === undefined) return undefined
  const chunks: Uint8Array[] = []
  let total = 0
  try {
    while (true) {
      const next = await reader.read()
      if (next.done) break
      total += next.value.byteLength
      if (total > MAX_RESPONSE_BYTES) return undefined
      chunks.push(next.value)
    }
  } finally {
    reader.releaseLock()
  }
  const bytes = new Uint8Array(total)
  let offset = 0
  for (const chunk of chunks) {
    bytes.set(chunk, offset)
    offset += chunk.byteLength
  }
  try {
    return JSON.parse(new TextDecoder().decode(bytes)) as unknown
  } catch {
    return undefined
  }
}

function windowOf(id: CodexUsageWindowView['id'], value: unknown): CodexUsageWindowView | undefined {
  const row = object(value)
  if (row === undefined) return undefined
  const usedPercent = row.used_percent
  if (typeof usedPercent !== 'number' || !Number.isFinite(usedPercent) || usedPercent < 0 || usedPercent > 100) return undefined
  const duration = row.limit_window_seconds
  const resetAt = row.reset_at
  return {
    id,
    usedPercent,
    remainingPercent: 100 - usedPercent,
    windowSeconds: typeof duration === 'number' && Number.isFinite(duration) && duration > 0 ? duration : null,
    resetAt: typeof resetAt === 'number' && Number.isFinite(resetAt) && resetAt > 0 ? resetAt * 1_000 : null,
  }
}

/** Fetch public quota percentages without projecting the bearer credential. */
export async function fetchCodexUsage(
  accessToken: string,
  accountId: string | undefined,
  signal?: AbortSignal,
  options: CodexUsageOptions = {},
): Promise<CodexUsageView> {
  const now = options.now ?? Date.now
  const sourceUrl = options.sourceUrl ?? CODEX_USAGE_SOURCE
  const request = options.fetch ?? fetch
  const timeout = AbortSignal.timeout(options.timeoutMs ?? REQUEST_TIMEOUT_MS)
  const requestSignal = signal === undefined ? timeout : AbortSignal.any([signal, timeout])
  const unavailable = (): CodexUsageView => ({
    status: 'unavailable',
    generatedAt: now(),
    bestEffort: true,
    sourceUrl,
    windows: [],
    error: 'Codex subscription usage is temporarily unavailable.',
  })
  try {
    const response = await request(sourceUrl, {
      headers: {
        accept: 'application/json',
        authorization: `Bearer ${accessToken}`,
        ...accountId === undefined ? {} : { 'chatgpt-account-id': accountId },
      },
      signal: requestSignal,
    })
    if (!response.ok) {
      await response.body?.cancel().catch(() => undefined)
      return unavailable()
    }
    const root = object(await boundedJson(response))
    const limits = object(root?.rate_limit)
    const windows = [
      windowOf('primary', limits?.primary_window),
      windowOf('secondary', limits?.secondary_window),
    ].filter((value): value is CodexUsageWindowView => value !== undefined)
    return windows.length === 0 ? unavailable() : {
      status: 'available',
      generatedAt: now(),
      bestEffort: true,
      sourceUrl,
      windows,
      error: null,
    }
  } catch {
    signal?.throwIfAborted()
    return unavailable()
  }
}
