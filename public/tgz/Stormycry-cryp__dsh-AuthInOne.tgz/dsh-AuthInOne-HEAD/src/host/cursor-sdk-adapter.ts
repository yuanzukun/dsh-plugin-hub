/** DSH adapter over Cursor's published SDK using only the plugin-owned account credential. */

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Agent, Cursor, JsonlLocalAgentStore, type SDKMessage } from '@cursor/sdk'
import {
  CallId, LlmAdapter, LlmError,
  type ContentBlock, type GenerateOptions, type LlmModelInfo, type StreamChunk,
} from '@deepseek-ai/dsh-llm'

const FALLBACK_MODELS = ['auto', 'composer-2.5', 'gpt-5', 'claude-4.5-sonnet'] as const

/** Narrow Cursor SDK run surface used by the adapter and its protocol tests. */
export interface CursorRunLike {
  stream(): AsyncGenerator<SDKMessage, void>
  cancel(): Promise<void>
}

/** Narrow Cursor SDK agent surface used by the adapter and its protocol tests. */
export interface CursorAgentLike {
  send(message: string, options: {
    model: { id: string }
    local: { customTools: Record<string, { description?: string; inputSchema?: Record<string, unknown>; execute: (args: Record<string, unknown>) => Promise<string> }> }
  }): Promise<CursorRunLike>
  close(): void
}

/** Injectable vendor SDK surface; production binds it to the published package. */
export interface CursorSdkFacade {
  listModels(apiKey: string): Promise<readonly { id: string; displayName: string }[]>
  createAgent(options: {
    apiKey: string
    model: { id: string }
    local: {
      cwd: string
      store: JsonlLocalAgentStore
      settingSources: []
      sandboxOptions: { enabled: true }
      customTools: Record<string, { description?: string; inputSchema?: Record<string, unknown>; execute: (args: Record<string, unknown>) => Promise<string> }>
    }
  }): Promise<CursorAgentLike>
}

const cursorSdk: CursorSdkFacade = {
  listModels: apiKey => Cursor.models.list({ apiKey }),
  createAgent: options => Agent.create(options as unknown as Parameters<typeof Agent.create>[0]) as Promise<CursorAgentLike>,
}

function text(blocks: readonly ContentBlock[]): string {
  return blocks.flatMap(block => block.type === 'text' || block.type === 'reasoning' ? [block.text] : []).join('\n')
}

function prompt(options: GenerateOptions): string {
  const transcript: string[] = []
  if (options.system?.trim()) transcript.push(`System instructions:\n${options.system.trim()}`)
  transcript.push('Do not use Cursor built-in filesystem, shell, browser, or network tools. Use only the DSH tools explicitly listed for this request.')
  for (const message of options.messages) {
    if (message.role === 'assistant') {
      const parts = message.content.flatMap(block => {
        if (block.type === 'text') return [block.text]
        if (block.type === 'reasoning') return [`[reasoning]\n${block.text}`]
        if (block.type === 'tool-call') return [`[tool call ${block.name} id=${String(block.id)}]\n${block.arguments}`]
        return []
      })
      transcript.push(`Assistant:\n${parts.join('\n')}`)
      continue
    }
    const parts = message.content.flatMap(block => {
      if (block.type === 'text') return [block.text]
      if (block.type === 'tool-result') return [`[tool result id=${String(block.toolCallId)} error=${String(block.isError === true)}]\n${text(block.content)}`]
      return []
    })
    transcript.push(`User:\n${parts.join('\n')}`)
  }
  return transcript.join('\n\n')
}

function toolMap(options: GenerateOptions, signal: AbortSignal): Record<string, {
  description?: string
  inputSchema?: Record<string, unknown>
  execute: (args: Record<string, unknown>) => Promise<string>
}> {
  return Object.fromEntries((options.tools ?? []).map(tool => [tool.name, {
    description: tool.description,
    inputSchema: tool.parameters,
    execute: () => new Promise<string>((_resolve, reject) => {
      if (signal.aborted) {
        reject(new Error('DSH turn ended before the tool result'))
        return
      }
      signal.addEventListener('abort', () => { reject(new Error('DSH turn ended before the tool result')) }, { once: true })
    }),
  }]))
}

function safeArguments(value: unknown): string {
  try {
    return JSON.stringify(value ?? {})
  } catch {
    return '{}'
  }
}

/** Experimental Cursor account route backed by the vendor SDK and an isolated temporary workspace. */
export class CursorSdkLlmAdapter extends LlmAdapter {
  private models: LlmModelInfo[] = FALLBACK_MODELS.map(id => ({ provider: 'cursor', id, name: id, inputModalities: ['text'] }))

  constructor(
    private readonly accessToken: (signal?: AbortSignal) => Promise<string>,
    private readonly sdk: CursorSdkFacade = cursorSdk,
  ) { super() }

  override providerInfo(provider: string): { id: string; name: string } {
    return { id: provider, name: 'Cursor' }
  }

  override async listModels(provider: string): Promise<readonly LlmModelInfo[]> {
    try {
      const token = await this.accessToken(AbortSignal.timeout(15_000))
      const rows = await this.sdk.listModels(token)
      const models = rows.flatMap((row): LlmModelInfo[] => row.id.trim().length === 0 ? [] : [{
        provider,
        id: row.id,
        name: row.displayName || row.id,
        inputModalities: ['text'],
      }])
      if (models.length > 0) this.models = models.slice(0, 256)
    } catch {
      // Keep the last known catalog when the account catalog is unavailable.
    }
    return this.models.map(model => ({ ...model }))
  }

  override resolveModel(provider: string, model: string): Promise<LlmModelInfo & { context: { contextWindow: number } }> {
    const known = this.models.find(entry => entry.id === model)
    return Promise.resolve({
      provider,
      id: model,
      name: known?.name ?? model,
      inputModalities: ['text'],
      context: { contextWindow: 200_000 },
    })
  }

  override async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const token = await this.accessToken(options.signal)
    const workspace = await mkdtemp(join(tmpdir(), 'dsh-auth-in-one-cursor-'))
    const controller = new AbortController()
    const combined = options.signal === undefined ? controller.signal : AbortSignal.any([controller.signal, options.signal])
    let agent: CursorAgentLike | undefined
    let run: CursorRunLike | undefined
    let cancelRequested = false
    const cancelRun = async (): Promise<void> => {
      if (run === undefined || cancelRequested) return
      cancelRequested = true
      await run.cancel()
    }
    const abort = (): void => { void cancelRun().catch(() => {}) }
    combined.addEventListener('abort', abort, { once: true })
    try {
      const tools = toolMap(options, combined)
      agent = await this.sdk.createAgent({
        apiKey: token,
        model: { id: options.model },
        local: {
          cwd: workspace,
          store: new JsonlLocalAgentStore(join(workspace, '.state')),
          settingSources: [],
          sandboxOptions: { enabled: true },
          customTools: tools,
        },
      })
      run = await agent.send(prompt(options), { model: { id: options.model }, local: { customTools: tools } })
      let nextIndex = 0
      let finishKind: 'stop' | 'tool-calls' = 'stop'
      const toolCalls = new Set<string>()
      for await (const message of run.stream()) {
        if (combined.aborted) throw new LlmError('Cursor request was cancelled', 'ABORTED')
        if (message.type === 'assistant') {
          for (const block of message.message.content) {
            if (block.type !== 'text' || block.text.length === 0) continue
            const index = nextIndex++
            yield { type: 'block-start', index, blockType: 'text' }
            yield { type: 'text-delta', index, text: block.text }
            yield { type: 'block-end', index, block: { type: 'text', text: block.text } }
          }
        } else if (message.type === 'thinking' && message.text.length > 0) {
          const index = nextIndex++
          yield { type: 'block-start', index, blockType: 'reasoning' }
          yield { type: 'reasoning-delta', index, text: message.text }
          yield { type: 'block-end', index, block: { type: 'reasoning', text: message.text } }
        } else if (message.type === 'tool_call' && message.status === 'running' && !toolCalls.has(message.call_id)) {
          if (!(message.name in tools)) throw new LlmError('Cursor requested an unavailable built-in tool', 'UPSTREAM')
          toolCalls.add(message.call_id)
          finishKind = 'tool-calls'
          const index = nextIndex++
          const id = CallId(message.call_id)
          const args = safeArguments(message.args)
          yield { type: 'block-start', index, blockType: 'tool-call' }
          yield { type: 'tool-call-delta', index, id, name: message.name, argumentsDelta: args }
          yield { type: 'block-end', index, block: { type: 'tool-call', id, name: message.name, arguments: args } }
          await cancelRun()
          break
        } else if (message.type === 'usage') {
          const usage = message.usage
          yield {
            type: 'usage',
            usage: {
              inputTokens: Math.max(0, usage.inputTokens),
              outputTokens: Math.max(0, usage.outputTokens),
              cacheReadTokens: Math.max(0, usage.cacheReadTokens),
              cacheWriteTokens: Math.max(0, usage.cacheWriteTokens),
              ...usage.reasoningTokens === undefined ? {} : { reasoningTokens: Math.max(0, usage.reasoningTokens) },
            },
          }
        } else if (message.type === 'status' && (message.status === 'ERROR' || message.status === 'EXPIRED')) {
          throw new LlmError('Cursor SDK reported a request failure', 'UPSTREAM')
        }
      }
      yield { type: 'finish', reason: { kind: finishKind } }
    } finally {
      combined.removeEventListener('abort', abort)
      controller.abort()
      agent?.close()
      await rm(workspace, { recursive: true, force: true })
    }
  }
}
