/** Host-only RFC 8628 adapter compatible with the Kimi Code device flow. */

import { randomUUID } from 'node:crypto'
import { arch, hostname, platform, release } from 'node:os'
import { AuthProtocolError, type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts'

const KIMI_OAUTH_HOST = 'https://auth.kimi.com'
const KIMI_PUBLIC_CLIENT_ID = '17e5f671-d194-4dfb-9706-5516cb48c098'
const DEVICE_GRANT = 'urn:ietf:params:oauth:grant-type:device_code'
const REQUEST_TIMEOUT_MS = 30_000
const DEFAULT_EXPIRES_SECONDS = 15 * 60
const DEFAULT_INTERVAL_SECONDS = 5
const MAX_RESPONSE_BYTES = 64 * 1024

export const KIMI_AUTH_SOURCE = 'https://github.com/MoonshotAI/kimi-code/blob/main/docs/en/reference/kimi-command.md#kimi-login'

/** Overrides for a local mock authorization server and deterministic polling tests. */
export interface KimiCodeDeviceOptions {
  readonly oauthHost?: string
  readonly clientId?: string
  readonly fetch?: typeof fetch
  readonly now?: () => number
  readonly requestTimeoutMs?: number
  readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>
  readonly deviceId?: string
}
function ascii(value: string): string {
  return value.replaceAll(/[^\u0020-\u007e]/g, '').trim() || 'unknown'
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

async function boundedRecord(response: Response): Promise<Record<string, unknown> | undefined> {
  const declared = Number(response.headers.get('content-length'))
  if (Number.isFinite(declared) && declared > MAX_RESPONSE_BYTES) return undefined
  const reader = response.body?.getReader()
  if (reader === undefined) return undefined
  const pieces: Uint8Array[] = []
  let total = 0
  try {
    while (true) {
      const next = await reader.read()
      if (next.done) break
      total += next.value.byteLength
      if (total > MAX_RESPONSE_BYTES) return undefined
      pieces.push(next.value)
    }
  } finally {
    reader.releaseLock()
  }
  const bytes = new Uint8Array(total)
  let offset = 0
  for (const piece of pieces) {
    bytes.set(piece, offset)
    offset += piece.byteLength
  }
  try {
    return record(JSON.parse(new TextDecoder().decode(bytes)) as unknown)
  } catch {
    return undefined
  }
}

function trustedUrl(value: unknown): string | undefined {
  if (typeof value !== 'string' || !URL.canParse(value)) return undefined
  const parsed = new URL(value)
  return parsed.protocol === 'https:' || parsed.protocol === 'http:' ? parsed.href : undefined
}

function credential(payload: Record<string, unknown> | undefined, now: number, previous?: StoredOAuthCredential): StoredOAuthCredential {
  const accessToken = payload?.access_token
  const refreshToken = payload?.refresh_token
  const expiresIn = payload?.expires_in
  if (typeof accessToken !== 'string' || accessToken.length === 0
    || (typeof refreshToken !== 'string' && previous === undefined)
    || typeof expiresIn !== 'number' || !Number.isFinite(expiresIn) || expiresIn <= 0) {
    throw new AuthProtocolError('invalid-response')
  }
  return {
    version: 1,
    accessToken,
    refreshToken: typeof refreshToken === 'string' && refreshToken.length > 0 ? refreshToken : previous!.refreshToken,
    expiresAt: now + expiresIn * 1_000,
  }
}

function defaultSleep(milliseconds: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, milliseconds)
    signal.addEventListener('abort', () => {
      clearTimeout(timer)
      reject(new DOMException('aborted', 'AbortError'))
    }, { once: true })
  })
}

/** Kimi Code device authorization, polling, and refresh; logout is local because no revoke endpoint is published. */
export class KimiCodeDeviceAdapter implements AuthProviderAdapter {
  readonly id = 'kimi-code'
  readonly name = 'Kimi Code'
  private readonly oauthHost: string
  private readonly clientId: string
  private readonly request: typeof fetch
  private readonly now: () => number
  private readonly requestTimeoutMs: number
  private readonly wait: (milliseconds: number, signal: AbortSignal) => Promise<void>
  private readonly headers: Readonly<Record<string, string>>

  constructor(options: KimiCodeDeviceOptions = {}) {
    this.oauthHost = (options.oauthHost ?? KIMI_OAUTH_HOST).replace(/\/+$/, '')
    this.clientId = options.clientId ?? KIMI_PUBLIC_CLIENT_ID
    this.request = options.fetch ?? fetch
    this.now = options.now ?? Date.now
    this.requestTimeoutMs = options.requestTimeoutMs ?? REQUEST_TIMEOUT_MS
    this.wait = options.sleep ?? defaultSleep
    this.headers = {
      accept: 'application/json',
      'content-type': 'application/x-www-form-urlencoded',
      'user-agent': 'dsh-auth-in-one/0.1.0-alpha.2',
      'x-msh-platform': 'kimi_code_cli',
      'x-msh-version': '0.1.0-alpha.2',
      'x-msh-device-name': ascii(hostname()),
      'x-msh-device-model': ascii(`${platform()} ${arch()}`),
      'x-msh-os-version': ascii(release()),
      'x-msh-device-id': options.deviceId ?? randomUUID(),
    }
  }

  private async post(path: string, fields: Record<string, string>, signal?: AbortSignal): Promise<{ status: number; body: Record<string, unknown> | undefined }> {
    const timeout = AbortSignal.timeout(this.requestTimeoutMs)
    const requestSignal = signal === undefined ? timeout : AbortSignal.any([signal, timeout])
    let response: Response
    try {
      response = await this.request(`${this.oauthHost}${path}`, {
        method: 'POST',
        headers: this.headers,
        body: new URLSearchParams(fields),
        signal: requestSignal,
      })
    } catch {
      throw new AuthProtocolError(signal?.aborted === true ? 'cancelled' : 'network')
    }
    return { status: response.status, body: await boundedRecord(response) }
  }

  async start(signal?: AbortSignal): Promise<AuthLoginHandle> {
    const controller = new AbortController()
    const started = await this.post('/api/oauth/device_authorization', { client_id: this.clientId }, signal)
    if (started.status !== 200) throw new AuthProtocolError('network')
    const deviceCode = started.body?.device_code
    const userCode = started.body?.user_code
    const verificationUrl = trustedUrl(started.body?.verification_uri)
    const authorizationUrl = trustedUrl(started.body?.verification_uri_complete) ?? verificationUrl
    if (typeof deviceCode !== 'string' || deviceCode.length === 0 || typeof userCode !== 'string' || userCode.length === 0
      || verificationUrl === undefined || authorizationUrl === undefined) throw new AuthProtocolError('invalid-response')
    const expiresSeconds = typeof started.body?.expires_in === 'number' && Number.isFinite(started.body.expires_in) && started.body.expires_in > 0
      ? started.body.expires_in : DEFAULT_EXPIRES_SECONDS
    let intervalMs = (typeof started.body?.interval === 'number' && Number.isFinite(started.body.interval) && started.body.interval > 0
      ? started.body.interval : DEFAULT_INTERVAL_SECONDS) * 1_000
    const expiresAt = this.now() + expiresSeconds * 1_000
    const expiry = AbortSignal.timeout(expiresSeconds * 1_000)
    const pollingSignal = signal === undefined
      ? AbortSignal.any([controller.signal, expiry])
      : AbortSignal.any([controller.signal, signal, expiry])
    const completion = (async (): Promise<StoredOAuthCredential> => {
      try {
        while (true) {
          await this.wait(intervalMs, pollingSignal)
          const result = await this.post('/api/oauth/token', {
            client_id: this.clientId,
            device_code: deviceCode,
            grant_type: DEVICE_GRANT,
          }, pollingSignal)
          if (result.status === 200) return credential(result.body, this.now())
          const code = result.body?.error
          if (code === 'authorization_pending') continue
          if (code === 'slow_down') {
            const serverInterval = result.body?.interval
            intervalMs = typeof serverInterval === 'number' && Number.isFinite(serverInterval) && serverInterval > 0
              ? Math.max(intervalMs + 5_000, serverInterval * 1_000)
              : intervalMs + 5_000
            continue
          }
          if (code === 'access_denied') throw new AuthProtocolError('denied')
          if (code === 'expired_token') throw new AuthProtocolError('expired')
          if (result.status === 429 || result.status >= 500) {
            intervalMs = Math.min(intervalMs * 2, 30_000)
            continue
          }
          throw new AuthProtocolError('invalid-response')
        }
      } catch (error) {
        if (error instanceof AuthProtocolError) throw error
        if (controller.signal.aborted || signal?.aborted === true) throw new AuthProtocolError('cancelled')
        if (expiry.aborted) throw new AuthProtocolError('expired')
        throw new AuthProtocolError('network')
      }
    })()
    return {
      authorizationUrl,
      verificationUrl,
      userCode,
      expiresAt,
      completion,
      cancel: () => { controller.abort() },
    }
  }

  async refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential> {
    if (previous.needsReauth === true) throw new AuthProtocolError('refresh-rejected')
    let delay = 1_000
    for (let attempt = 0; attempt < 3; attempt += 1) {
      if (attempt > 0) await this.wait(delay, signal ?? new AbortController().signal)
      const result = await this.post('/api/oauth/token', {
        client_id: this.clientId,
        grant_type: 'refresh_token',
        refresh_token: previous.refreshToken,
      }, signal)
      if (result.status === 200) return credential(result.body, this.now(), previous)
      if (result.status === 401 || result.status === 403 || result.body?.error === 'invalid_grant') {
        throw new AuthProtocolError('refresh-rejected')
      }
      if (result.status !== 429 && result.status < 500) throw new AuthProtocolError('network')
      delay *= 2
    }
    throw new AuthProtocolError('network')
  }

  revoke(_credential: StoredOAuthCredential, _signal?: AbortSignal): Promise<void> {
    // Kimi publishes local token removal plus console device management, but no OAuth revocation endpoint.
    return Promise.resolve()
  }
}
