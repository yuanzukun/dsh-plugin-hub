/** Self-contained AuthInOne installer and same-port DSH Web restart supervisor. */
import { spawn, spawnSync, type SpawnSyncReturns } from 'node:child_process'
import { constants } from 'node:fs'
import {
  chmod,
  copyFile,
  mkdir,
  readFile,
  realpath,
  rename,
  rm,
  writeFile,
} from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parseArgs } from 'node:util'
import { assertCompatibleHostAt } from './host/compat-host.ts'

const PACKAGE_NAME = 'dsh-auth-in-one'
const DEFAULT_PACKAGE_SPEC = 'github:Stormycry-cryp/dsh-AuthInOne#v0.2.0-alpha.4'
const DEFAULT_URL = 'http://127.0.0.1:3080/'
const DEFAULT_TIMEOUT_MS = 90_000
const HANDOFF_DELAY_MS = 3_000
const STATUS_VERSION = 1

type PublicAction = 'install' | 'uninstall' | 'status'
type RestartPhase = 'scheduled' | 'stopping' | 'starting' | 'ready' | 'failed'

export interface LaunchCommand {
  executable: string
  args: string[]
  cwd: string
}

export interface InstallerOptions {
  action: PublicAction
  profile: string
  url: URL
  sourceRoot?: string | undefined
  packageSpec: string
  timeoutMs: number
}

export interface RestartPlan {
  version: 1
  callerPid: number
  listenerPid?: number | undefined
  profile: string
  profileDir: string
  url: string
  port: number
  launch: LaunchCommand
  timeoutMs: number
  handoffDelayMs: number
  statusPath: string
  supervisorPath: string
}

export interface RestartStatus {
  version: 1
  phase: RestartPhase
  updatedAt: string
  profile: string
  url: string
  previousPid?: number | undefined
  replacementPid?: number | undefined
  recoveryCommand: string
  message: string
}

export interface InstallerRuntime {
  assertCompatibleHost(anchor: string): void
  run(command: LaunchCommand): SpawnSyncReturns<Buffer>
  findListeners(port: number): number[]
  processCwd(pid: number): string
  processCommand(pid: number): string
  processExists(pid: number): boolean
  signal(pid: number, signal: NodeJS.Signals): void
  start(command: LaunchCommand): Promise<number>
  startSupervisor(modulePath: string, planPath: string): Promise<number>
  probe(url: string): Promise<boolean>
  sleep(ms: number): Promise<void>
  now(): Date
}

function defaultRun(command: LaunchCommand): SpawnSyncReturns<Buffer> {
  return spawnSync(command.executable, command.args, {
    cwd: command.cwd,
    stdio: ['inherit', 'inherit', 'inherit'],
    shell: process.platform === 'win32',
  })
}

function lsof(args: readonly string[]): string {
  const result = spawnSync('lsof', args, { encoding: 'utf8' })
  if (result.error !== undefined) throw new Error(`lsof is required for safe same-port restart: ${result.error.message}`)
  if (result.status !== 0 && result.status !== 1) throw new Error(`lsof failed with exit code ${result.status ?? 1}`)
  return result.stdout
}

function defaultFindListeners(port: number): number[] {
  if (process.platform === 'win32') {
    throw new Error('AUTH_IN_ONE_RESTART_UNSUPPORTED_PLATFORM: automatic restart currently requires macOS or Linux')
  }
  return [...new Set(lsof(['-nP', `-iTCP:${port}`, '-sTCP:LISTEN', '-t'])
    .split(/\s+/)
    .filter(Boolean)
    .map(value => Number(value))
    .filter(Number.isSafeInteger))]
}

function defaultProcessCwd(pid: number): string {
  const line = lsof(['-a', '-p', String(pid), '-d', 'cwd', '-Fn'])
    .split('\n')
    .find(value => value.startsWith('n'))
  if (line === undefined || line.length === 1) throw new Error(`cannot resolve cwd for listener PID ${pid}`)
  return line.slice(1)
}

function defaultProcessCommand(pid: number): string {
  const result = spawnSync('ps', ['-p', String(pid), '-o', 'command='], { encoding: 'utf8' })
  if (result.status !== 0 || result.stdout.trim() === '') throw new Error(`cannot resolve command for listener PID ${pid}`)
  return result.stdout.trim()
}

async function defaultStart(command: LaunchCommand): Promise<number> {
  return new Promise((resolveStart, rejectStart) => {
    const child = spawn(command.executable, command.args, {
      cwd: command.cwd,
      detached: true,
      env: process.env,
      stdio: 'ignore',
      shell: false,
    })
    child.once('error', rejectStart)
    child.once('spawn', () => {
      if (child.pid === undefined) {
        rejectStart(new Error('replacement DSH process did not return a PID'))
        return
      }
      child.unref()
      resolveStart(child.pid)
    })
  })
}

function defaultStartSupervisor(modulePath: string, planPath: string): Promise<number> {
  return new Promise((resolveStart, rejectStart) => {
    const child = spawn(process.execPath, [modulePath, '__supervise', '--plan', planPath], {
      cwd: dirname(planPath),
      detached: true,
      env: process.env,
      stdio: 'ignore',
    })
    child.once('error', rejectStart)
    child.once('spawn', () => {
      if (child.pid === undefined) {
        rejectStart(new Error('restart supervisor did not return a PID'))
        return
      }
      child.unref()
      resolveStart(child.pid)
    })
  })
}

export const DEFAULT_RUNTIME: InstallerRuntime = {
  assertCompatibleHost: assertCompatibleHostAt,
  run: defaultRun,
  findListeners: defaultFindListeners,
  processCwd: defaultProcessCwd,
  processCommand: defaultProcessCommand,
  processExists(pid) {
    try {
      process.kill(pid, 0)
      return true
    } catch (error) {
      return (error as NodeJS.ErrnoException).code === 'EPERM'
    }
  },
  signal(pid, signal) { process.kill(pid, signal) },
  start: defaultStart,
  startSupervisor: defaultStartSupervisor,
  async probe(url) {
    try {
      const response = await fetch(url, { redirect: 'manual', signal: AbortSignal.timeout(2_000) })
      return response.status >= 200 && response.status < 400
    } catch {
      return false
    }
  },
  sleep: ms => new Promise(resolveSleep => setTimeout(resolveSleep, ms)),
  now: () => new Date(),
}

/** Parse the public bootstrap command without accepting path-like profile names or remote targets. */
export function parseInstallerArgs(argv: readonly string[]): InstallerOptions | { action: '__supervise'; planPath: string } {
  const parsed = parseArgs({
    args: [...argv],
    allowPositionals: true,
    strict: true,
    options: {
      profile: { type: 'string', default: 'web' },
      url: { type: 'string', default: DEFAULT_URL },
      'source-root': { type: 'string' },
      'package-spec': { type: 'string', default: DEFAULT_PACKAGE_SPEC },
      timeout: { type: 'string', default: String(DEFAULT_TIMEOUT_MS / 1_000) },
      plan: { type: 'string' },
    },
  })
  const [action, ...extra] = parsed.positionals
  if (extra.length > 0) throw new Error(`unexpected positional arguments: ${extra.join(' ')}`)
  if (action === '__supervise') {
    if (parsed.values.plan === undefined) throw new Error('__supervise requires --plan')
    return { action, planPath: resolve(parsed.values.plan) }
  }
  if (action !== 'install' && action !== 'uninstall' && action !== 'status') {
    throw new Error('usage: dsh-auth-in-one <install|uninstall|status> [--profile web] [--url http://127.0.0.1:3080/] [--source-root /path/to/DSH]')
  }
  const profile = parsed.values.profile ?? 'web'
  if (profile === '' || profile === '.' || profile === '..' || profile === 'node_modules' || /[/\\]/.test(profile)) {
    throw new Error(`invalid DSH profile name ${JSON.stringify(profile)}`)
  }
  const url = new URL(parsed.values.url ?? DEFAULT_URL)
  const loopback = url.hostname === '127.0.0.1' || url.hostname === '[::1]'
  if (url.protocol !== 'http:' || !loopback || url.username !== '' || url.password !== '' || url.pathname !== '/' || url.search !== '' || url.hash !== '') {
    throw new Error('restart URL must be a credential-free loopback HTTP origin ending in /')
  }
  const port = Number(url.port || '80')
  if (!Number.isSafeInteger(port) || port < 1 || port > 65_535) throw new Error('restart URL has an invalid port')
  const timeoutSeconds = Number(parsed.values.timeout)
  if (!Number.isFinite(timeoutSeconds) || timeoutSeconds < 10 || timeoutSeconds > 600) {
    throw new Error('--timeout must be between 10 and 600 seconds')
  }
  return {
    action,
    profile,
    url,
    sourceRoot: parsed.values['source-root'] === undefined ? undefined : resolve(parsed.values['source-root']),
    packageSpec: parsed.values['package-spec'] ?? DEFAULT_PACKAGE_SPEC,
    timeoutMs: Math.round(timeoutSeconds * 1_000),
  }
}

function dshHome(): string {
  const configured = process.env.DSH_HOME?.trim()
  const selected = configured === undefined || configured === '' ? join(homedir(), '.dsh') : configured
  const expanded = selected === '~'
    ? homedir()
    : selected[0] === '~' && (selected[1] === '/' || selected[1] === '\\')
      ? join(homedir(), selected.slice(2))
      : selected
  return resolve(expanded)
}

/** Resolve the profile directory without importing private DSH source modules. */
export function profileDirectory(profile: string): string {
  return join(dshHome(), 'profiles', profile)
}

async function isDshSourceRoot(path: string): Promise<boolean> {
  try {
    const manifest = JSON.parse(await readFile(join(path, 'package.json'), 'utf8')) as { scripts?: Record<string, unknown> }
    return typeof manifest.scripts?.dsh === 'string'
  } catch {
    return false
  }
}

function assertDshListener(command: string, pid: number): void {
  const normalized = command.replaceAll('\\', '/')
  if (/apps\/cli\/(?:src\/bin\.ts|lib\/bin\.js)(?:\s|$)/.test(normalized)) return
  if (/(?:^|\s|\/)dsh(?:\.cmd)?(?:\s|$)/.test(normalized)) return
  throw new Error(`AUTH_IN_ONE_RESTART_UNVERIFIED_PROCESS: PID ${pid} is not a recognizable DSH Host`)
}

async function resolveExecutable(command: string): Promise<string> {
  const lookup = spawnSync(process.platform === 'win32' ? 'where' : 'which', [command], { encoding: 'utf8' })
  if (lookup.status !== 0) throw new Error(`${command} was not found on PATH`)
  const first = lookup.stdout.split(/\r?\n/).find(Boolean)
  if (first === undefined) throw new Error(`${command} was not found on PATH`)
  return realpath(first)
}

interface ResolvedLaunch {
  plugin: LaunchCommand
  web: LaunchCommand
  compatibilityAnchor: string
  listenerPid?: number | undefined
}

/** Resolve one standard DSH launcher and refuse ambiguous or unrelated listeners. */
export async function resolveLaunch(options: InstallerOptions, runtime: InstallerRuntime = DEFAULT_RUNTIME): Promise<ResolvedLaunch> {
  const port = Number(options.url.port || '80')
  const listeners = runtime.findListeners(port)
  if (listeners.length > 1) throw new Error(`AUTH_IN_ONE_RESTART_AMBIGUOUS_PORT: ${port} has ${listeners.length} listeners`)
  const listenerPid = listeners[0]
  let listenerCwd: string | undefined
  if (listenerPid !== undefined) {
    assertDshListener(runtime.processCommand(listenerPid), listenerPid)
    listenerCwd = runtime.processCwd(listenerPid)
    if (!await runtime.probe(options.url.href)) throw new Error(`listener PID ${listenerPid} does not serve ${options.url.href}`)
  }

  const explicitRoot = options.sourceRoot
  const inferredRoot = listenerCwd !== undefined && await isDshSourceRoot(listenerCwd) ? listenerCwd : undefined
  const sourceRoot = explicitRoot ?? inferredRoot
  if (sourceRoot !== undefined) {
    if (!await isDshSourceRoot(sourceRoot)) throw new Error(`--source-root is not a DSH source checkout: ${sourceRoot}`)
    if (listenerCwd !== undefined && resolve(listenerCwd) !== resolve(sourceRoot)) {
      throw new Error(`running DSH cwd ${listenerCwd} does not match --source-root ${sourceRoot}`)
    }
    const prefix = ['dsh']
    return {
      plugin: { executable: 'pnpm', args: prefix, cwd: sourceRoot },
      web: { executable: 'pnpm', args: [...prefix, 'web', '--port', String(port)], cwd: sourceRoot },
      compatibilityAnchor: join(dshHome(), 'profiles', 'auth-in-one-resolution-anchor.cjs'),
      listenerPid,
    }
  }

  const dshBin = await resolveExecutable('dsh')
  return {
    plugin: { executable: dshBin, args: [], cwd: listenerCwd ?? process.cwd() },
    web: { executable: dshBin, args: ['web', '--port', String(port)], cwd: listenerCwd ?? process.cwd() },
    compatibilityAnchor: join(dshHome(), 'profiles', 'auth-in-one-resolution-anchor.cjs'),
    listenerPid,
  }
}

function recoveryCommand(launch: LaunchCommand): string {
  return [launch.executable, ...launch.args].map(argument => /^[A-Za-z0-9_./:@+-]+$/.test(argument)
    ? argument
    : JSON.stringify(argument)).join(' ')
}

async function writeJsonAtomic(path: string, value: unknown): Promise<void> {
  const temporary = `${path}.${process.pid}.tmp`
  await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 })
  await chmod(temporary, 0o600)
  await rename(temporary, path)
}

function statusFor(plan: RestartPlan, phase: RestartPhase, message: string, replacementPid?: number): RestartStatus {
  return {
    version: STATUS_VERSION,
    phase,
    updatedAt: new Date().toISOString(),
    profile: plan.profile,
    url: plan.url,
    previousPid: plan.listenerPid,
    replacementPid,
    recoveryCommand: recoveryCommand(plan.launch),
    message,
  }
}

async function waitUntil(predicate: () => boolean | Promise<boolean>, timeoutMs: number, runtime: InstallerRuntime): Promise<boolean> {
  const deadline = runtime.now().getTime() + timeoutMs
  while (runtime.now().getTime() < deadline) {
    if (await predicate()) return true
    await runtime.sleep(250)
  }
  return predicate()
}

/** Execute a detached same-port replacement from a credential-free serialized plan. */
export async function superviseRestart(plan: RestartPlan, runtime: InstallerRuntime = DEFAULT_RUNTIME): Promise<void> {
  let replacementPid: number | undefined
  try {
    if (plan.version !== STATUS_VERSION) throw new Error(`unsupported restart plan version ${String(plan.version)}`)
    const callerExited = await waitUntil(
      () => !runtime.processExists(plan.callerPid),
      Math.min(plan.timeoutMs, 10_000),
      runtime,
    )
    if (!callerExited) throw new Error(`installer PID ${plan.callerPid} did not exit before restart handoff`)
    await runtime.sleep(plan.handoffDelayMs)
    await writeJsonAtomic(plan.statusPath, statusFor(plan, 'stopping', 'Stopping the validated DSH Host.'))
    if (plan.listenerPid !== undefined) {
      const currentListeners = runtime.findListeners(plan.port)
      if (currentListeners.length > 1 || (currentListeners.length === 1 && currentListeners[0] !== plan.listenerPid)) {
        throw new Error(`AUTH_IN_ONE_RESTART_LISTENER_CHANGED: port ${plan.port} no longer belongs to validated PID ${plan.listenerPid}`)
      }
      if (currentListeners[0] === plan.listenerPid) {
        assertDshListener(runtime.processCommand(plan.listenerPid), plan.listenerPid)
        if (resolve(runtime.processCwd(plan.listenerPid)) !== resolve(plan.launch.cwd)) {
          throw new Error(`AUTH_IN_ONE_RESTART_LISTENER_CHANGED: PID ${plan.listenerPid} cwd changed before handoff`)
        }
        runtime.signal(plan.listenerPid, 'SIGTERM')
        const stopped = await waitUntil(() => !runtime.processExists(plan.listenerPid!), plan.timeoutMs, runtime)
        if (!stopped) throw new Error(`validated DSH PID ${plan.listenerPid} did not stop before timeout`)
      }
    }
    const portReleased = await waitUntil(() => runtime.findListeners(plan.port).length === 0, plan.timeoutMs, runtime)
    if (!portReleased) throw new Error(`port ${plan.port} did not become available before timeout`)
    await writeJsonAtomic(plan.statusPath, statusFor(plan, 'starting', 'Starting DSH on the original port.'))
    await runtime.start(plan.launch)
    const healthy = await waitUntil(() => runtime.probe(plan.url), plan.timeoutMs, runtime)
    if (!healthy) throw new Error(`replacement DSH did not become healthy at ${plan.url} before timeout`)
    const replacementListeners = runtime.findListeners(plan.port)
    if (replacementListeners.length !== 1) {
      throw new Error(`replacement port ${plan.port} has ${replacementListeners.length} listeners after startup`)
    }
    replacementPid = replacementListeners[0]
    assertDshListener(runtime.processCommand(replacementPid!), replacementPid!)
    await writeJsonAtomic(plan.statusPath, statusFor(plan, 'ready', 'DSH returned on the original URL.', replacementPid))
    await rm(plan.supervisorPath, { force: true })
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    await writeJsonAtomic(plan.statusPath, statusFor(plan, 'failed', message, replacementPid))
    throw error
  }
}

async function scheduleRestart(options: InstallerOptions, launch: ResolvedLaunch, runtime: InstallerRuntime): Promise<RestartPlan> {
  const profileDir = profileDirectory(options.profile)
  const stateDir = join(profileDir, '.auth-in-one')
  await mkdir(stateDir, { recursive: true, mode: 0o700 })
  await chmod(stateDir, 0o700)
  const nonce = `${Date.now()}-${process.pid}`
  const supervisorPath = join(stateDir, `restart-supervisor-${nonce}.mjs`)
  const planPath = join(stateDir, `restart-plan-${nonce}.json`)
  const statusPath = join(stateDir, 'restart-status.json')
  await copyFile(fileURLToPath(import.meta.url), supervisorPath, constants.COPYFILE_EXCL)
  await chmod(supervisorPath, 0o700)
  const plan: RestartPlan = {
    version: STATUS_VERSION,
    callerPid: process.pid,
    listenerPid: launch.listenerPid,
    profile: options.profile,
    profileDir,
    url: options.url.href,
    port: Number(options.url.port || '80'),
    launch: launch.web,
    timeoutMs: options.timeoutMs,
    handoffDelayMs: HANDOFF_DELAY_MS,
    statusPath,
    supervisorPath,
  }
  await writeJsonAtomic(planPath, plan)
  await writeJsonAtomic(statusPath, statusFor(plan, 'scheduled', 'Plugin mutation succeeded; same-port restart is scheduled.'))
  await runtime.startSupervisor(supervisorPath, planPath)
  return plan
}

function pluginCommand(base: LaunchCommand, options: InstallerOptions): LaunchCommand {
  const operation = options.action === 'install'
    ? ['add', options.packageSpec]
    : ['remove', PACKAGE_NAME]
  return {
    ...base,
    args: [...base.args, 'plugin', '--profile', options.profile, ...operation],
  }
}

/** Install or remove through the official DSH CLI, then schedule an exact same-port restart. */
export async function runInstaller(options: InstallerOptions, runtime: InstallerRuntime = DEFAULT_RUNTIME): Promise<RestartPlan | RestartStatus | undefined> {
  const profileDir = profileDirectory(options.profile)
  const statusPath = join(profileDir, '.auth-in-one', 'restart-status.json')
  if (options.action === 'status') {
    const status = JSON.parse(await readFile(statusPath, 'utf8')) as RestartStatus
    process.stdout.write(`${JSON.stringify(status, null, 2)}\n`)
    return status
  }
  const launch = await resolveLaunch(options, runtime)
  runtime.assertCompatibleHost(launch.compatibilityAnchor)
  const command = pluginCommand(launch.plugin, options)
  const result = runtime.run(command)
  if (result.error !== undefined) throw result.error
  if ((result.status ?? 1) !== 0) throw new Error(`official DSH plugin ${options.action} failed with exit code ${result.status ?? 1}`)
  const plan = await scheduleRestart(options, launch, runtime)
  process.stdout.write(
    `AuthInOne ${options.action} completed through the official DSH plugin CLI.\n`
    + `DSH will return at ${options.url.href}; check status with dsh-auth-in-one status --profile ${options.profile}.\n`,
  )
  return plan
}

async function main(): Promise<void> {
  const parsed = parseInstallerArgs(process.argv.slice(2))
  if (parsed.action === '__supervise') {
    const plan = JSON.parse(await readFile(parsed.planPath, 'utf8')) as RestartPlan
    try {
      await superviseRestart(plan)
    } finally {
      await rm(parsed.planPath, { force: true })
    }
    return
  }
  await runInstaller(parsed)
}

const invokedPath = process.argv[1] === undefined ? undefined : await realpath(process.argv[1]).catch(() => resolve(process.argv[1]!))
const modulePath = await realpath(fileURLToPath(import.meta.url)).catch(() => fileURLToPath(import.meta.url))
if (invokedPath === modulePath) {
  main().catch(error => {
    process.stderr.write(`dsh-auth-in-one: ${error instanceof Error ? error.message : String(error)}\n`)
    process.exitCode = 1
  })
}
