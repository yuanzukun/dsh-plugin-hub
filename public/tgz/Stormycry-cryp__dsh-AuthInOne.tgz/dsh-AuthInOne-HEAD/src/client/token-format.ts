/** Compact Token display plus an exact accessible label. */
export interface TokenDisplay {
  readonly text: string
  readonly exact: string
}

function trimmed(value: number, locale?: string): string {
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value)
}

/** Format non-negative finite Token counts using exact integers below 1M and M/B above it. */
export function formatTokens(value: number | null | undefined, locale?: string): TokenDisplay | null {
  if (value === null || value === undefined || !Number.isFinite(value) || value < 0) return null
  const exactNumber = new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(value)
  const text = value < 1_000_000
    ? exactNumber
    : value < 1_000_000_000
      ? `${trimmed(value / 1_000_000, locale)}M`
      : `${trimmed(value / 1_000_000_000, locale)}B`
  return { text, exact: `${exactNumber} Token` }
}
