import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from 'react'
import { IconCheckOutline16, IconChevronDownOutline14 } from '@deepseek-ai/dsh-client-ui-primitives'
import css from './SelectMenu.module.css'

/** One option in the plugin's DSH-styled accessible select. */
export interface SelectMenuOption<T extends string> {
  id: T
  label: string
  group?: string
  description?: string
  disabled?: boolean
}

/** Compact listbox select used where DSH has no complete select primitive. */
export function SelectMenu<T extends string>({
  value, options, onChange, ariaLabel, disabled = false, className, prefix,
}: {
  value: T
  options: readonly SelectMenuOption<T>[]
  onChange: (value: T) => void
  ariaLabel: string
  disabled?: boolean
  className?: string
  prefix?: ReactNode
}): ReactNode {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState(0)
  const root = useRef<HTMLDivElement>(null)
  const trigger = useRef<HTMLButtonElement>(null)
  const optionRefs = useRef<Array<HTMLButtonElement | null>>([])
  const listId = useId()
  const matchedIndex = options.findIndex(option => option.id === value)
  const selectedIndex = Math.max(0, matchedIndex)

  const nextEnabled = (from: number, direction: 1 | -1): number => {
    if (options.length === 0) return from
    let next = from
    for (let count = 0; count < options.length; count += 1) {
      next = (next + direction + options.length) % options.length
      if (options[next]?.disabled !== true) return next
    }
    return from
  }

  const close = (restoreFocus = false): void => {
    setOpen(false)
    if (restoreFocus) queueMicrotask(() => { trigger.current?.focus() })
  }

  const move = (direction: 1 | -1): void => {
    setActive(current => nextEnabled(current, direction))
  }

  const openAt = (index: number): void => {
    if (disabled || options.length === 0) return
    setActive(index)
    setOpen(true)
  }

  const selectActive = (): void => {
    const option = options[active]
    if (option === undefined || option.disabled === true) return
    onChange(option.id)
    close(true)
  }

  useEffect(() => {
    if (!open) return
    optionRefs.current[active]?.focus()
  }, [active, open])

  useEffect(() => {
    if (!open) return
    const onPointerDown = (event: PointerEvent): void => {
      if (!(event.target instanceof Node) || root.current?.contains(event.target) === true) return
      close()
    }
    document.addEventListener('pointerdown', onPointerDown)
    return () => { document.removeEventListener('pointerdown', onPointerDown) }
  }, [open])

  const onTriggerKeyDown = (event: KeyboardEvent<HTMLButtonElement>): void => {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault()
      openAt(event.key === 'ArrowUp' ? nextEnabled(selectedIndex, -1) : selectedIndex)
      return
    }
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      if (open) close()
      else openAt(selectedIndex)
      return
    }
    if (event.key === 'Escape' && open) {
      event.preventDefault()
      close(true)
    }
  }

  const onListKeyDown = (event: KeyboardEvent<HTMLDivElement>): void => {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault()
      move(event.key === 'ArrowDown' ? 1 : -1)
    } else if (event.key === 'Home' || event.key === 'End') {
      event.preventDefault()
      const index = event.key === 'Home'
        ? options.findIndex(option => option.disabled !== true)
        : options.findLastIndex(option => option.disabled !== true)
      if (index >= 0) setActive(index)
    } else if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      selectActive()
    } else if (event.key === 'Escape') {
      event.preventDefault()
      close(true)
    } else if (event.key === 'Tab') {
      close()
    }
  }

  const selected = matchedIndex < 0 ? undefined : options[matchedIndex]
  return (
    <div ref={root} className={`${css.root}${className === undefined ? '' : ` ${className}`}`}>
      <button
        ref={trigger}
        type="button"
        className={css.trigger}
        role="combobox"
        aria-label={ariaLabel}
        aria-expanded={open}
        aria-controls={listId}
        aria-haspopup="listbox"
        disabled={disabled}
        onClick={() => { if (open) close(); else openAt(selectedIndex) }}
        onKeyDown={onTriggerKeyDown}
      >
        {prefix}
        <span className={css.value} title={selected?.label}>{selected?.label ?? ''}</span>
        <IconChevronDownOutline14 className={css.chevron} size={14} />
      </button>
      {open ? (
        <div id={listId} className={css.list} role="listbox" aria-label={ariaLabel} onKeyDown={onListKeyDown}>
          {options.map((option, index) => (
            <div key={option.id}>
              {option.group !== undefined && option.group !== options[index - 1]?.group
                ? <div className={css.group} role="presentation">{option.group}</div>
                : null}
              <button
                ref={(node) => { optionRefs.current[index] = node }}
                type="button"
                role="option"
                aria-selected={option.id === value}
                className={css.option}
                disabled={option.disabled}
                tabIndex={index === active ? 0 : -1}
                onPointerMove={() => { if (option.disabled !== true) setActive(index) }}
                onClick={() => {
                  if (option.disabled === true) return
                  onChange(option.id)
                  close(true)
                }}
              >
                <span className={css.optionText}>
                  <span title={option.label}>{option.label}</span>
                  {option.description === undefined ? null : <small>{option.description}</small>}
                </span>
                {option.id === value ? <IconCheckOutline16 size={16} /> : null}
              </button>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  )
}
