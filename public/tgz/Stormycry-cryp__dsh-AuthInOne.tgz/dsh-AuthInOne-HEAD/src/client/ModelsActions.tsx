import type { ReactNode } from 'react'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import { AuthLoginAction, type AuthLoginActionInjected } from './AuthLoginAction.tsx'
import { PlanProviderAction, type PlanProviderActionInjected } from './PlanProviderAction.tsx'
import css from './ModelsActions.module.css'

/** Combined Models action injection for the single package-owned slot seat. */
export interface ModelsActionsInjected extends AuthLoginActionInjected, PlanProviderActionInjected {}

export type ModelsActionsProps =
  PropsRuntime<'settings.models.actions'>
  & PropsLocale<'settings.authInOne'>
  & InjectFace<ModelsActionsInjected>

/** Auth and API/subscription-key actions placed above DSH's native Provider buttons. */
export function ModelsActions(props: ModelsActionsProps): ReactNode {
  return (
    <div className={css.actions}>
      <AuthLoginAction {...props} />
      <PlanProviderAction {...props} />
    </div>
  )
}
