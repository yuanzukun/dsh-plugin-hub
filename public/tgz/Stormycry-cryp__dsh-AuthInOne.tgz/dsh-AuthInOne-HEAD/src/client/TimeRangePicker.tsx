import { createPortal } from 'react-dom'
import { useEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from 'react'
import { Button, IconChevronDownOutline14, IconChevronLeftOutline14, IconChevronRightOutline14 } from '@deepseek-ai/dsh-client-ui-primitives'
import { localSecondText, parseLocalSecond, recentRange, type TimeRangeValue } from './time-range.ts'
import css from './TimeRangePicker.module.css'

export type { TimeRangeValue } from './time-range.ts'

export interface TimeRangeLabels {
  aria: string
  start: string
  end: string
  timeZone: string
  cancel: string
  apply: string
  invalid: string
  previousMonth: string
  nextMonth: string
  days: readonly string[]
  shortcut: (days: 7 | 15 | 30) => string
  summary: (start: string, end: string) => string
}

function zoneLabel(timeZone: string, time: number): string {
  const offset = new Intl.DateTimeFormat(undefined, {
    timeZone,
    timeZoneName: 'longOffset',
  }).formatToParts(new Date(time)).find(part => part.type === 'timeZoneName')?.value ?? ''
  return `${timeZone}${offset.length === 0 ? '' : ` · ${offset}`}`
}

function monthDays(cursor: Date): Date[] {
  const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1)
  const gridStart = new Date(first)
  gridStart.setDate(first.getDate() - first.getDay())
  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(gridStart)
    date.setDate(gridStart.getDate() + index)
    return date
  })
}

function dayKey(date: Date): string {
  return localSecondText(date.getTime()).slice(0, 10)
}

/** DSH-styled local-time range control with a keyboard-operable calendar popover. */
export function TimeRangePicker({ value, onChange, labels }: {
  value: TimeRangeValue
  onChange: (value: TimeRangeValue) => void
  labels: TimeRangeLabels
}): ReactNode {
  const [open, setOpen] = useState(false)
  const [start, setStart] = useState(() => localSecondText(value.startTime))
  const [end, setEnd] = useState(() => localSecondText(value.endTimeExclusive - 1_000))
  const [preset, setPreset] = useState<TimeRangeValue['presetDays']>(value.presetDays)
  const [selectingEnd, setSelectingEnd] = useState(false)
  const [cursor, setCursor] = useState(() => new Date(value.endTimeExclusive - 1_000))
  const [position, setPosition] = useState({ left: 0, top: 0 })
  const root = useRef<HTMLDivElement>(null)
  const trigger = useRef<HTMLButtonElement>(null)
  const panel = useRef<HTMLDivElement>(null)
  const startInput = useRef<HTMLInputElement>(null)
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
  const days = useMemo(() => monthDays(cursor), [cursor])
  const parsedStart = parseLocalSecond(start)
  const parsedEnd = parseLocalSecond(end)
  const valid = parsedStart !== null && parsedEnd !== null && parsedStart <= parsedEnd

  const close = (restoreFocus = false): void => {
    setOpen(false)
    setStart(localSecondText(value.startTime))
    setEnd(localSecondText(value.endTimeExclusive - 1_000))
    setPreset(value.presetDays)
    if (restoreFocus) queueMicrotask(() => { trigger.current?.focus() })
  }

  useEffect(() => {
    if (!open) return
    const place = (): void => {
      const anchor = trigger.current?.getBoundingClientRect()
      if (anchor === undefined) return
      const width = Math.min(380, window.innerWidth - 24)
      const left = Math.max(12, Math.min(anchor.left, window.innerWidth - width - 12))
      const estimatedHeight = 492
      const top = anchor.bottom + 6 + estimatedHeight > window.innerHeight
        ? Math.max(12, anchor.top - estimatedHeight - 6)
        : anchor.bottom + 6
      setPosition({ left, top })
    }
    place()
    window.addEventListener('resize', place)
    window.addEventListener('scroll', place, true)
    queueMicrotask(() => { startInput.current?.focus() })
    const outside = (event: PointerEvent): void => {
      if (!(event.target instanceof Node)) return
      if (root.current?.contains(event.target) === true || panel.current?.contains(event.target) === true) return
      close()
    }
    const escape = (event: globalThis.KeyboardEvent): void => {
      if (event.key === 'Escape') close(true)
    }
    document.addEventListener('pointerdown', outside)
    document.addEventListener('keydown', escape)
    return () => {
      window.removeEventListener('resize', place)
      window.removeEventListener('scroll', place, true)
      document.removeEventListener('pointerdown', outside)
      document.removeEventListener('keydown', escape)
    }
  }, [open, value])

  const chooseDay = (date: Date): void => {
    const source = selectingEnd ? end : start
    const replacement = `${dayKey(date)} ${source.slice(11)}`
    if (selectingEnd) setEnd(replacement)
    else setStart(replacement)
    setPreset(null)
    setSelectingEnd(!selectingEnd)
  }

  const onDayKey = (event: KeyboardEvent<HTMLButtonElement>, date: Date): void => {
    const offset = event.key === 'ArrowLeft' ? -1 : event.key === 'ArrowRight' ? 1
      : event.key === 'ArrowUp' ? -7 : event.key === 'ArrowDown' ? 7 : 0
    if (offset === 0) return
    event.preventDefault()
    const next = new Date(date)
    next.setDate(date.getDate() + offset)
    setCursor(next)
    queueMicrotask(() => {
      panel.current?.querySelector<HTMLButtonElement>(`[data-day="${dayKey(next)}"]`)?.focus()
    })
  }

  const startDay = start.slice(0, 10)
  const endDay = end.slice(0, 10)
  const summary = value.presetDays === null
    ? labels.summary(localSecondText(value.startTime), localSecondText(value.endTimeExclusive - 1_000))
    : labels.shortcut(value.presetDays)
  return (
    <div ref={root} className={css.root}>
      <button
        ref={trigger}
        type="button"
        className={css.trigger}
        aria-label={`${labels.aria}: ${summary}; ${labels.timeZone}: ${zoneLabel(timeZone, value.endTimeExclusive - 1_000)}`}
        title={`${summary} · ${zoneLabel(timeZone, value.endTimeExclusive - 1_000)}`}
        aria-expanded={open}
        aria-haspopup="dialog"
        onClick={() => { setOpen(current => !current) }}
      >
        <span>{summary}</span>
        <IconChevronDownOutline14 size={14} />
      </button>
      {open ? createPortal((
        <div
          ref={panel}
          className={css.panel}
          role="dialog"
          aria-modal="false"
          aria-label={labels.aria}
          style={{ left: position.left, top: position.top }}
        >
          <div className={css.inputs}>
            <label><span>{labels.start}</span><input ref={startInput} value={start} onChange={event => { setStart(event.currentTarget.value); setPreset(null) }} /></label>
            <label><span>{labels.end}</span><input value={end} onChange={event => { setEnd(event.currentTarget.value); setPreset(null) }} /></label>
          </div>
          <p className={css.zone}>{labels.timeZone}: {zoneLabel(timeZone, parsedEnd ?? Date.now())}</p>
          {!valid ? <p className={css.error} role="alert">{labels.invalid}</p> : null}
          <div className={css.calendarHead}>
            <button type="button" aria-label={labels.previousMonth} onClick={() => { setCursor(current => new Date(current.getFullYear(), current.getMonth() - 1, 1)) }}><IconChevronLeftOutline14 size={14} /></button>
            <strong>{new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' }).format(cursor)}</strong>
            <button type="button" aria-label={labels.nextMonth} onClick={() => { setCursor(current => new Date(current.getFullYear(), current.getMonth() + 1, 1)) }}><IconChevronRightOutline14 size={14} /></button>
          </div>
          <div className={css.weekdays} aria-hidden="true">{labels.days.map(day => <span key={day}>{day}</span>)}</div>
          <div className={css.calendar} role="grid">
            {days.map(date => {
              const key = dayKey(date)
              const inRange = key >= startDay && key <= endDay
              return (
                <button
                  key={key}
                  type="button"
                  role="gridcell"
                  data-day={key}
                  data-outside={date.getMonth() !== cursor.getMonth() ? 'true' : 'false'}
                  data-range={inRange ? 'true' : 'false'}
                  aria-selected={key === startDay || key === endDay}
                  onClick={() => { chooseDay(date) }}
                  onKeyDown={event => { onDayKey(event, date) }}
                >{date.getDate()}</button>
              )
            })}
          </div>
          <div className={css.shortcuts}>
            {([7, 15, 30] as const).map(daysValue => (
              <button
                key={daysValue}
                type="button"
                data-selected={preset === daysValue ? 'true' : 'false'}
                onClick={() => {
                  const next = recentRange(daysValue)
                  setStart(localSecondText(next.startTime))
                  setEnd(localSecondText(next.endTimeExclusive - 1_000))
                  setPreset(daysValue)
                  setCursor(new Date(next.endTimeExclusive - 1_000))
                }}
              >{labels.shortcut(daysValue)}</button>
            ))}
          </div>
          <div className={css.actions}>
            <Button variant="outline" size="sm" onClick={() => { close(true) }}>{labels.cancel}</Button>
            <Button
              variant="primary"
              size="sm"
              disabled={!valid}
              onClick={() => {
                if (parsedStart === null || parsedEnd === null || parsedStart > parsedEnd) return
                onChange({ startTime: parsedStart, endTimeExclusive: parsedEnd + 1_000, presetDays: preset })
                setOpen(false)
              }}
            >{labels.apply}</Button>
          </div>
        </div>
      ), document.body) : null}
    </div>
  )
}
