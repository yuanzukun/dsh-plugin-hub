/** Applied local time range represented as exact UTC milliseconds for the Host. */
export interface TimeRangeValue {
  readonly startTime: number
  readonly endTimeExclusive: number
  readonly presetDays: 7 | 15 | 30 | null
}

const PATTERN = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/
const AMBIGUITY_SCAN_STEP_MS = 15 * 60 * 1000
const AMBIGUITY_SCAN_LIMIT_MS = 3 * 60 * 60 * 1000

function hasFields(
  time: number,
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
  second: number,
): boolean {
  const candidate = new Date(time)
  return candidate.getFullYear() === year && candidate.getMonth() === month - 1 && candidate.getDate() === day
    && candidate.getHours() === hour && candidate.getMinutes() === minute && candidate.getSeconds() === second
}

/** Format an instant as one local wall-clock second. */
export function localSecondText(time: number): string {
  const value = new Date(time)
  const part = (number: number): string => String(number).padStart(2, '0')
  return `${String(value.getFullYear())}-${part(value.getMonth() + 1)}-${part(value.getDate())} ${part(value.getHours())}:${part(value.getMinutes())}:${part(value.getSeconds())}`
}

/** Parse one local wall-clock second and reject DST gaps, folds, or calendar overflow. */
export function parseLocalSecond(value: string): number | null {
  const match = PATTERN.exec(value)
  if (match === null) return null
  const fields = match.slice(1).map(Number)
  const [year, month, day, hour, minute, second] = fields
  if (year === undefined || month === undefined || day === undefined || hour === undefined
    || minute === undefined || second === undefined) return null
  const parsed = new Date(year, month - 1, day, hour, minute, second, 0)
  const time = parsed.getTime()
  if (!hasFields(time, year, month, day, hour, minute, second)) return null
  for (let distance = AMBIGUITY_SCAN_STEP_MS; distance <= AMBIGUITY_SCAN_LIMIT_MS; distance += AMBIGUITY_SCAN_STEP_MS) {
    if (hasFields(time - distance, year, month, day, hour, minute, second)
      || hasFields(time + distance, year, month, day, hour, minute, second)) return null
  }
  return time
}

/** Inclusive-second shortcut translated to the Host's exclusive millisecond end. */
export function recentRange(days: 7 | 15 | 30, now = Date.now()): TimeRangeValue {
  const end = Math.floor(now / 1_000) * 1_000
  return { startTime: end - days * 86_400_000 + 1_000, endTimeExclusive: end + 1_000, presetDays: days }
}
