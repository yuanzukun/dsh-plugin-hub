import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import {
  Button, IconLinkOutline16, IconPlusOutline16, Modal, Pill, StateDot,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { AuthProviderView } from '../types.ts'
import { SelectMenu } from './SelectMenu.tsx'
import css from './AuthLoginAction.module.css'

/** Host operations consumed by the Models-page Auth action. */
export interface AuthLoginActionInjected {
  loadAuthProviders: () => Promise<readonly AuthProviderView[]>
  startAuth: (provider: string) => Promise<AuthProviderView>
  cancelAuth: (provider: string, attemptId: string) => Promise<AuthProviderView>
  submitAuth: (provider: string, attemptId: string, value: string) => Promise<AuthProviderView>
  logoutAuth: (provider: string) => Promise<AuthProviderView>
  notifyProviderChange: () => void
}

export type AuthLoginActionProps =
  PropsRuntime<'settings.models.actions'>
  & PropsLocale<'settings.authInOne'>
  & InjectFace<AuthLoginActionInjected>

type LoadState =
  | { status: 'idle' | 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; providers: readonly AuthProviderView[] }

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

const reasonKeys = {
  'third-party-registration-missing': 'authReason_thirdParty',
  'subscription-oauth-blocked': 'authReason_subscriptionBlocked',
  discontinued: 'authReason_discontinued',
  'sdk-adapter-required': 'authReason_sdkAdapter',
} as const

/** Full-width official-account login action placed above native add-provider buttons. */
export function AuthLoginAction({
  loadAuthProviders, startAuth, cancelAuth, submitAuth, logoutAuth, notifyProviderChange, t,
}: AuthLoginActionProps): ReactNode {
  const [open, setOpen] = useState(false)
  const [state, setState] = useState<LoadState>({ status: 'idle' })
  const [actionError, setActionError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const closeRequested = useRef(false)
  const [selectedId, setSelectedId] = useState('openai-codex')
  const [manualValue, setManualValue] = useState('')

  const acceptProviders = useCallback((providers: readonly AuthProviderView[]): void => {
    setState(providers.length === 0
      ? { status: 'error', message: t('authUnavailable') }
      : { status: 'ready', providers })
    setSelectedId(current => providers.some(provider => provider.id === current) ? current : providers[0]?.id ?? '')
  }, [t])
  const load = useCallback((): void => {
    setActionError(null)
    setState({ status: 'loading' })
    void loadAuthProviders().then(
      acceptProviders,
      error => { setState({ status: 'error', message: messageOf(error) }) },
    )
  }, [acceptProviders, loadAuthProviders])

  useEffect(() => {
    if (!open) return
    load()
  }, [load, open])

  useEffect(() => {
    if (!open) return
    const refresh = (): void => {
      void loadAuthProviders().then(acceptProviders, () => {})
    }
    const refreshVisible = (): void => {
      if (document.visibilityState === 'visible') refresh()
    }
    window.addEventListener('focus', refresh)
    document.addEventListener('visibilitychange', refreshVisible)
    return () => {
      window.removeEventListener('focus', refresh)
      document.removeEventListener('visibilitychange', refreshVisible)
    }
  }, [acceptProviders, loadAuthProviders, open])

  useEffect(() => {
    if (!open || state.status !== 'ready'
      || !state.providers.some(provider => provider.id === selectedId
        && (provider.status === 'pending' || provider.status === 'starting'))) return
    const timer = window.setInterval(() => {
      void loadAuthProviders().then(providers => {
        if (providers.length > 0) setState({ status: 'ready', providers })
      }, () => {})
    }, 2_000)
    return () => { window.clearInterval(timer) }
  }, [loadAuthProviders, open, selectedId, state])

  const provider = state.status === 'ready'
    ? state.providers.find(entry => entry.id === selectedId)
    : undefined
  const showUserCode = provider !== undefined && provider.userCode !== null
    && (provider.verificationUrl === null || provider.authorizationUrl === provider.verificationUrl)
  useEffect(() => { setManualValue('') }, [selectedId])
  const notifiedInstance = useRef<string | null>(null)
  useEffect(() => {
    const key = provider !== undefined && (provider.status === 'connected' || provider.status === 'needs-reauth')
      ? `${provider.id}:${provider.status}`
      : null
    if (key === null) {
      notifiedInstance.current = null
      return
    }
    if (notifiedInstance.current === key) return
    notifiedInstance.current = key
    notifyProviderChange()
  }, [notifyProviderChange, provider?.id, provider?.status])
  const updateProvider = (next: AuthProviderView): void => {
    setState(current => current.status === 'ready'
      ? { status: 'ready', providers: current.providers.map(entry => entry.id === next.id ? next : entry) }
      : { status: 'ready', providers: [next] })
  }

  const cancelPending = (): void => {
    if (busy) {
      closeRequested.current = true
      return
    }
    if (provider === undefined || provider.attemptId === null) {
      setOpen(false)
      return
    }
    setBusy(true)
    void cancelAuth(provider.id, provider.attemptId).then(
      () => { setOpen(false) },
      error => { setActionError(messageOf(error)) },
    ).finally(() => { setBusy(false) })
  }

  const statusKeys = {
    'signed-out': 'authStatus_signed_out',
    starting: 'authStatus_starting',
    pending: 'authStatus_pending',
    connected: 'authStatus_connected',
    cancelled: 'authStatus_cancelled',
    expired: 'authStatus_expired',
    'needs-reauth': 'authStatus_needs_reauth',
    error: 'authStatus_error',
  } as const
  const statusLabel = provider === undefined ? '' : t(statusKeys[provider.status])
  return (
    <>
      <button type="button" className={css.addAuth} onClick={() => { setActionError(null); setOpen(true) }}>
        <IconPlusOutline16 size={14} />
        {t('addAuthLogin')}
      </button>
      <Modal
        open={open}
        onClose={cancelPending}
        title={t('authTitle')}
        closeLabel={t('close')}
        description={t('authDescription')}
        className={css.dialog as string}
        footer={(
          <>
            <Button variant="outline" disabled={busy} onClick={cancelPending}>{t('cancel')}</Button>
            {provider?.status === 'connected' ? (
              <Button
                variant="outline"
                disabled={busy}
                onClick={() => {
                  setBusy(true)
                  void logoutAuth(provider.id).then(next => {
                    updateProvider(next)
                    notifyProviderChange()
                  })
                    .catch(error => { setActionError(messageOf(error)) })
                    .finally(() => { setBusy(false) })
                }}
              >
                {t('authLogout')}
              </Button>
            ) : provider?.status === 'pending' && provider.inputPrompt !== null ? (
              <Button
                variant="primary"
                disabled={busy || provider.attemptId === null || manualValue.trim().length === 0}
                onClick={() => {
                  if (provider.attemptId === null) return
                  setBusy(true)
                  void submitAuth(provider.id, provider.attemptId, manualValue).then(next => {
                    updateProvider(next)
                    setManualValue('')
                  }).catch(error => { setActionError(messageOf(error)) })
                    .finally(() => { setBusy(false) })
                }}
              >
                {t('authSubmit')}
              </Button>
            ) : (
              <Button
                variant="primary"
                disabled={busy || provider === undefined || !provider.available
                  || provider.status === 'pending' || provider.status === 'starting'}
                onClick={() => {
                  if (provider === undefined) return
                  closeRequested.current = false
                  setActionError(null)
                  setBusy(true)
                  void startAuth(provider.id).then(async next => {
                    if (closeRequested.current && next.attemptId !== null) {
                      await cancelAuth(next.id, next.attemptId)
                      setOpen(false)
                      return
                    }
                    updateProvider(next)
                  }).catch(error => { setActionError(messageOf(error)) })
                    .finally(() => { closeRequested.current = false; setBusy(false) })
                }}
              >
                {busy ? t('authStarting') : t('authStart')}
              </Button>
            )}
          </>
        )}
      >
        <div className={css.body} aria-busy={state.status === 'loading'}>
          <label className={css.field}>
            <span>{t('authProvider')}</span>
            <SelectMenu
              value={selectedId}
              ariaLabel={t('authProvider')}
              onChange={value => { setSelectedId(value); setActionError(null) }}
              options={state.status === 'ready' ? state.providers.map(entry => ({
                id: entry.id,
                label: `${entry.name} · ${t(entry.stability === 'stable' ? 'stable' : entry.stability === 'experimental' ? 'experimental' : 'unsupported')}`,
              })) : []}
            />
          </label>
          {state.status === 'loading' || state.status === 'idle' ? <div className={css.skeleton} /> : null}
          {state.status === 'error' ? <p className={css.error} role="alert">{state.message}</p> : null}
          {actionError !== null ? <p className={css.error} role="alert">{actionError}</p> : null}
          {provider !== undefined ? (
            <section className={css.providerCard} aria-live="polite">
              <div className={css.providerHead}>
                <span><StateDot state={provider.status === 'connected' ? 'done' : provider.status === 'error' ? 'error' : 'warning'} /> <strong>{provider.name}</strong></span>
                <Pill>{t(provider.stability === 'stable' ? 'stable' : provider.stability === 'experimental' ? 'experimental' : 'unsupported')}</Pill>
              </div>
              <p className={css.status}>{provider.available ? statusLabel : t(reasonKeys[provider.availabilityReason ?? 'third-party-registration-missing'])}</p>
              {provider.status === 'pending' && provider.authorizationUrl !== null ? (
                <div className={css.deviceAction}>
                  {showUserCode ? (
                    <div className={css.userCode}>
                      <span>{t('deviceUserCode')}</span>
                      <code>{provider.userCode}</code>
                    </div>
                  ) : null}
                  {provider.inputPrompt !== null ? (
                    <label className={css.manualField}>
                      <span>{t('authCode')}</span>
                      <input
                        type="text"
                        autoComplete="off"
                        spellCheck={false}
                        value={manualValue}
                        placeholder={provider.inputPrompt.placeholder ?? t('authCodePlaceholder')}
                        onChange={event => { setManualValue(event.target.value) }}
                      />
                    </label>
                  ) : null}
                  <a className={css.authLink} href={provider.authorizationUrl} target="_blank" rel="noreferrer">
                    <IconLinkOutline16 size={16} />
                    {t('authOpenOfficial')}
                  </a>
                </div>
              ) : null}
              {provider.status === 'error' && provider.error !== null
                ? <p className={css.error} role="alert">{provider.error}</p>
                : null}
              {provider.available ? <p className={css.security}>{t('authSecurity')}</p> : (
                <a className={css.sourceLink} href={provider.sourceUrl} target="_blank" rel="noreferrer">{t('officialSource')}</a>
              )}
            </section>
          ) : null}
        </div>
      </Modal>
    </>
  )
}
