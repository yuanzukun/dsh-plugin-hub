import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { Button, Pill, StateDot } from '@deepseek-ai/dsh-client-ui-primitives'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {
  ProviderHubView, ProviderProbeView, ProviderQuotaView, VisionFallbackConfig, VisionFallbackView,
} from '../types.ts'
import { SelectMenu } from './SelectMenu.tsx'
import css from './ModelsProviderStatus.module.css'

/** Host operations consumed by the Models-page enhancement. */
export interface ModelsProviderStatusInjected {
  loadProviders: () => Promise<ProviderHubView>
  loadProviderQuotas: () => Promise<readonly ProviderQuotaView[]>
  loadVisionFallback: () => Promise<VisionFallbackView>
  saveVisionFallback: (request: VisionFallbackConfig) => Promise<void>
  probe: (provider: string) => Promise<ProviderProbeView>
  logoutAuth: (provider: string) => Promise<void>
  saveDefault: (provider: string, model: string) => Promise<void>
  subscribeProviderChange: (listener: () => void) => () => void
}

export type ModelsProviderStatusProps =
  PropsRuntime<'settings.models.insights'>
  & PropsLocale<'settings.authInOne'>
  & InjectFace<ModelsProviderStatusInjected>

type ViewState =
  | { status: 'loading' }
  | { status: 'error' }
  | { status: 'ready'; snapshot: ProviderHubView }

const visionAccessCopy = {
  'account-auth': { group: 'visionGroup_account-auth', access: 'visionAccess_account-auth' },
  api: { group: 'visionGroup_api', access: 'visionAccess_api' },
  'custom-api': { group: 'visionGroup_custom-api', access: 'visionAccess_custom-api' },
} as const

/** Compact Host facts and operations placed above the native provider cards. */
export function ModelsProviderStatus({
  loadProviders, loadProviderQuotas, loadVisionFallback, saveVisionFallback,
  probe, logoutAuth, saveDefault, subscribeProviderChange, t,
}: ModelsProviderStatusProps): ReactNode {
  const [generation, setGeneration] = useState(0)
  const [state, setState] = useState<ViewState>({ status: 'loading' })
  const [selected, setSelected] = useState<Record<string, string>>({})
  const [probing, setProbing] = useState<string | null>(null)
  const [probeResult, setProbeResult] = useState<Record<string, ProviderProbeView>>({})
  const [saving, setSaving] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  const [quotas, setQuotas] = useState<Record<string, ProviderQuotaView>>({})
  const [vision, setVision] = useState<VisionFallbackView | null>(null)
  const [visionEnabled, setVisionEnabled] = useState(false)
  const [visionProvider, setVisionProvider] = useState('')
  const [visionModel, setVisionModel] = useState('')
  const [visionSaving, setVisionSaving] = useState(false)

  useEffect(() => {
    let current = true
    void loadProviders().then(
      (snapshot) => {
        if (!current) return
        setState({ status: 'ready', snapshot })
        setSelected(Object.fromEntries(snapshot.providers.map((provider) => {
          const fallback = provider.models[0]?.id ?? ''
          return [provider.id, provider.id === snapshot.defaultSelection.provider ? snapshot.defaultSelection.model : fallback]
        })))
      },
      () => { if (current) setState({ status: 'error' }) },
    )
    void loadProviderQuotas().then(
      value => { if (current) setQuotas(Object.fromEntries(value.map(quota => [quota.provider, quota]))) },
      () => { if (current) setQuotas({}) },
    )
    void loadVisionFallback().then(
      (value) => {
        if (!current) return
        setVision(value)
        setVisionEnabled(value.enabled)
        setVisionProvider(value.provider)
        setVisionModel(value.model)
      },
      () => { if (current) setVision(null) },
    )
    return () => { current = false }
  }, [generation, loadProviderQuotas, loadProviders, loadVisionFallback])

  useEffect(() => subscribeProviderChange(() => { setGeneration(value => value + 1) }), [subscribeProviderChange])

  const activeProviders = useMemo(
    () => state.status === 'ready' ? state.snapshot.providers.filter(provider => provider.active) : [],
    [state],
  )
  const visionProviders = useMemo(() => vision === null
    ? []
    : [...new Map(vision.routes.map(route => [route.provider, route])).values()]
      .sort((a, b) => a.accessType.localeCompare(b.accessType) || a.providerName.localeCompare(b.providerName))
      .map(route => ({
        id: route.provider,
        label: route.providerName,
        group: t(visionAccessCopy[route.accessType].group),
        description: `${t(visionAccessCopy[route.accessType].access)}${route.accountLabel === null ? '' : ` · ${route.accountLabel}`}`,
      })), [t, vision])
  const visionModels = useMemo(() => vision?.routes
    .filter(route => route.provider === visionProvider)
    .map(route => ({ id: route.model, label: route.modelName })) ?? [], [vision, visionProvider])
  const selectedVisionRoute = vision?.routes.find(route => route.provider === visionProvider && route.model === visionModel)
  const availableProviderOptions = visionProviders.length === 0
    ? [{ id: '', label: t('visionNoRoutes'), disabled: true }]
    : [{ id: '', label: t('visionChooseProvider') }, ...visionProviders]
  const providerOptions = vision !== null && visionProvider.length > 0
    && !visionProviders.some(option => option.id === visionProvider)
    ? [{ id: visionProvider, label: `${visionProvider} · ${t('visionUnavailable')}`, disabled: true }, ...availableProviderOptions]
    : availableProviderOptions
  const modelOptions = vision !== null && visionModel.length > 0
    && !visionModels.some(option => option.id === visionModel)
    ? [{ id: visionModel, label: `${visionModel} · ${t('visionUnavailable')}`, disabled: true }, ...visionModels]
    : visionModels

  const reload = (clearNotice = true): void => {
    setState({ status: 'loading' })
    if (clearNotice) setNotice(null)
    setGeneration(value => value + 1)
  }

  return (
    <section className={css.panel} aria-labelledby="provider-status-title" aria-busy={state.status === 'loading'}>
      <div className={css.heading}>
        <div>
          <h3 id="provider-status-title">{t('modelsStatus')}</h3>
          <p>{t('modelsStatusIntro')}</p>
        </div>
        <Button size="sm" variant="outline" onClick={() => { reload() }}>{t('refresh')}</Button>
      </div>
      {state.status === 'loading' ? <div className={css.skeleton} aria-label={t('loading')} /> : null}
      {state.status === 'error' ? (
        <div className={css.failure} role="alert">
          <span>{t('providersLoadError')}</span>
          <Button size="sm" variant="outline" onClick={() => { reload() }}>{t('retry')}</Button>
        </div>
      ) : null}
      {state.status === 'ready' ? (
        <>
          <article className={css.visionCard} aria-labelledby="vision-fallback-title">
            <div className={css.visionHead}>
              <div>
                <h4 id="vision-fallback-title">{t('visionFallbackTitle')}</h4>
                <p>{t('visionFallbackIntro')}</p>
              </div>
              <label className={css.switchLabel}>
                <input
                  type="checkbox"
                  checked={visionEnabled}
                  disabled={vision === null || visionSaving}
                  onChange={(event) => { setVisionEnabled(event.currentTarget.checked) }}
                />
                <span>{t(visionEnabled ? 'enabled' : 'disabled')}</span>
              </label>
            </div>
            <div className={css.visionGrid}>
              <label>
                <span>{t('visionProvider')}</span>
                <SelectMenu
                  value={visionProvider}
                  ariaLabel={t('visionProvider')}
                  disabled={vision === null || visionSaving}
                  onChange={(value) => {
                    setVisionProvider(value)
                    setVisionModel(vision?.routes.find(route => route.provider === value)?.model ?? '')
                  }}
                  options={providerOptions}
                />
              </label>
              <label>
                <span>{t('visionModel')}</span>
                <SelectMenu
                  value={visionModel}
                  ariaLabel={t('visionModel')}
                  disabled={vision === null || visionProvider.length === 0 || visionSaving}
                  onChange={setVisionModel}
                  options={modelOptions.length === 0
                    ? [{ id: '', label: t('noModels'), disabled: true }]
                    : modelOptions}
                />
              </label>
              <Button
                size="sm"
                variant="primary"
                disabled={vision === null || visionSaving || (visionEnabled && (visionProvider.length === 0 || visionModel.length === 0))}
                onClick={() => {
                  if (vision === null) return
                  setVisionSaving(true)
                  setNotice(null)
                  void saveVisionFallback({
                    enabled: visionEnabled,
                    provider: visionProvider,
                    model: visionModel,
                    maxOutputTokens: vision.maxOutputTokens,
                    timeoutMs: vision.timeoutMs,
                  }).then(
                    () => { reload(false); setNotice(t('visionSaved')) },
                    () => { setNotice(t('visionSaveError')) },
                  ).finally(() => { setVisionSaving(false) })
                }}
              >{visionSaving ? t('saving') : t('save')}</Button>
            </div>
            {vision?.enabled === true && !vision.selectionAvailable
              ? <p className={css.visionUnavailable} role="alert">{t('visionUnavailableHelp')}</p>
              : null}
            {selectedVisionRoute === undefined ? null : (
              <p className={css.visionQuota}>
                {t('visionQuota')
                  .replace('{provider}', selectedVisionRoute.providerName)
                  .replace('{access}', t(visionAccessCopy[selectedVisionRoute.accessType].access))
                  .replace('{account}', selectedVisionRoute.accountLabel ?? t('visionAccountNotApplicable'))}
              </p>
            )}
            <p className={css.visionBoundary}>{t('visionBoundary')}</p>
          </article>
          <div className={css.cards}>
            {state.snapshot.providers.map((provider) => {
              const connectionReady = provider.active && (provider.credentialConfigured !== false)
              const result = probeResult[provider.id]
              const model = selected[provider.id] ?? ''
              const quota = quotas[provider.id]
              const quotaReliable = quota !== undefined
                && quota.windows.length > 0
                && quota.windows.every(window => Number.isFinite(window.usedPercent)
                  && Number.isFinite(window.remainingPercent)
                  && window.usedPercent >= 0 && window.usedPercent <= 100
                  && window.remainingPercent >= 0 && window.remainingPercent <= 100
                  && Math.abs(window.usedPercent + window.remainingPercent - 100) < 0.01)
              const quotaLabel = (id: string, fallback: string): string => {
                if (id === 'primary') return t('primaryWindow')
                if (id === 'secondary') return t('secondaryWindow')
                if (id === 'five-hour') return t('fiveHourWindow')
                if (id === 'weekly') return t('weeklyWindow')
                if (id === 'subscription') return t('subscriptionCredits')
                return fallback
              }
              return (
                <article className={css.card} key={provider.id} data-provider={provider.id}>
                  <div className={css.cardHead}>
                    <span className={css.identity}>
                      <StateDot state={connectionReady ? 'done' : 'warning'} />
                      <strong>{provider.name}</strong>
                      <Pill>{t(provider.authMode === 'oauth' ? 'authOfficial' : 'apiKeyOnly')}</Pill>
                    </span>
                    <span className={css.connection}>{t(connectionReady ? 'connected' : provider.authMode === 'oauth' ? 'reconnectRequired' : 'notConnected')}</span>
                  </div>
                  <div className={css.controls}>
                    <label>
                      <span>{t('defaultModel')}</span>
                      <SelectMenu
                        value={model}
                        ariaLabel={`${provider.name} · ${t('defaultModel')}`}
                        disabled={provider.models.length === 0 || !provider.active || saving}
                        onChange={(value) => { setSelected(current => ({ ...current, [provider.id]: value })) }}
                        options={provider.models.length === 0
                          ? [{ id: '', label: t('noModels'), disabled: true }]
                          : provider.models.map(item => ({ id: item.id, label: item.name }))}
                      />
                    </label>
                    <div className={css.actions}>
                      {provider.authMode === 'api-key-only' ? <Button
                        size="sm"
                        variant="outline"
                        disabled={!provider.configurable || probing !== null}
                        onClick={() => {
                          setProbing(provider.id)
                          void probe(provider.id).then(
                            value => { setProbeResult(current => ({ ...current, [provider.id]: value })) },
                            () => { setProbeResult(current => ({ ...current, [provider.id]: { ok: false, latencyMs: 0, models: [], error: t('testFailed') } })) },
                          ).finally(() => { setProbing(null) })
                        }}
                      >
                        {probing === provider.id ? t('testing') : t('test')}
                      </Button> : <Button
                        size="sm"
                        variant="outline"
                        disabled={saving}
                        onClick={() => {
                          setSaving(true)
                          void logoutAuth(provider.id).then(() => { reload(false) })
                            .catch(() => { setNotice(t('loadError')) })
                            .finally(() => { setSaving(false) })
                        }}
                      >{t('authLogout')}</Button>}
                      <Button
                        size="sm"
                        variant="primary"
                        disabled={!provider.active || model.length === 0 || saving}
                        onClick={() => {
                          setSaving(true)
                          setNotice(null)
                          void saveDefault(provider.id, model).then(
                            () => { reload(false); setNotice(t('savedDefault')) },
                            () => { setNotice(t('loadError')) },
                          ).finally(() => { setSaving(false) })
                        }}
                      >
                        {t('saveDefault')}
                      </Button>
                    </div>
                  </div>
                  {quota !== undefined
                    && quota.status === 'available'
                    && quotaReliable
                    && provider.credentialConfigured === true ? (
                    <div className={css.codexUsage} aria-label={t('codexUsage')}>
                      <div className={css.usageHead}>
                        <strong>{provider.id === 'openai-codex' ? t('codexUsage') : `${provider.name} · ${t('planUsage')}`}</strong>
                        <span>{t('bestEffort')}</span>
                      </div>
                      {quota.windows.map(window => (
                        <div className={css.usageWindow} key={window.id}>
                          <div>
                            <span>{quotaLabel(window.id, window.label)}</span>
                            <span>{window.usedPercent.toLocaleString(undefined, { maximumFractionDigits: 1 })}% {t('used')} · {window.remainingPercent.toLocaleString(undefined, { maximumFractionDigits: 1 })}% {t('remaining')}</span>
                          </div>
                          <div
                            className={css.progress}
                            role="progressbar"
                            aria-label={`${quotaLabel(window.id, window.label)} · ${String(window.usedPercent)}% ${t('used')}`}
                            aria-valuemin={0}
                            aria-valuemax={100}
                            aria-valuenow={window.usedPercent}
                          >
                            <span style={{ width: `${String(window.usedPercent)}%` }} />
                          </div>
                          <small>
                            {window.windowSeconds === null ? t('windowUnknown') : `${Math.round(window.windowSeconds / 3_600).toLocaleString()} h`}
                            {' · '}
                            {window.resetAt === null ? t('resetUnknown') : `${t('resetsAt')} ${new Date(window.resetAt).toLocaleString()}`}
                          </small>
                        </div>
                      ))}
                    </div>
                  ) : null}
                  {provider.modelError !== null ? <p className={css.inlineError}>{t('modelCatalogError')}</p> : null}
                  {result !== undefined ? (
                    <p className={result.ok ? css.success : css.inlineError} role="status">
                      {result.ok ? `${t('testOk')} · ${String(result.latencyMs)} ms · ${String(result.models.length)}` : `${t('testFailed')}: ${result.error ?? t('unknown')}`}
                    </p>
                  ) : null}
                </article>
              )
            })}
          </div>
          {activeProviders.length === 0 ? <p className={css.inlineError}>{t('notConnected')}</p> : null}
          {notice !== null ? <p className={css.success} role="status" aria-live="polite">{notice}</p> : null}
          <p className={css.footnote}>{t('editBelow')}</p>
        </>
      ) : null}
    </section>
  )
}
