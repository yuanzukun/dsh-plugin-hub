import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { Button, IconLinkOutline16, IconPlusOutline16, Modal, Pill } from '@deepseek-ai/dsh-client-ui-primitives'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { ProviderPlanPresetView, SavePlanProviderRequest } from '../types.ts'
import { SelectMenu } from './SelectMenu.tsx'
import css from './PlanProviderAction.module.css'

function noteKey(id: string):
  | 'planNote_openai'
  | 'planNote_xai'
  | 'planNote_gemini'
  | 'planNote_kimi'
  | 'planNote_glm'
  | 'planNote_qwen'
  | 'planNote_anthropic' {
  if (id === 'openai-api') return 'planNote_openai'
  if (id === 'xai-api') return 'planNote_xai'
  if (id === 'gemini-api') return 'planNote_gemini'
  if (id === 'kimi-code-plan') return 'planNote_kimi'
  if (id === 'glm-coding-plan') return 'planNote_glm'
  if (id === 'qwen-coding-plan') return 'planNote_qwen'
  return 'planNote_anthropic'
}

/** Host operations consumed by the Models-page Plan/API action. */
export interface PlanProviderActionInjected {
  loadPlanProviders: () => Promise<readonly ProviderPlanPresetView[]>
  savePlanProvider: (request: SavePlanProviderRequest) => Promise<void>
}

export type PlanProviderActionProps =
  PropsRuntime<'settings.models.actions'>
  & PropsLocale<'settings.authInOne'>
  & InjectFace<PlanProviderActionInjected>

/** Vendor-published API/subscription-key setup without projecting the secret back to the browser. */
export function PlanProviderAction({ loadPlanProviders, savePlanProvider, t }: PlanProviderActionProps): ReactNode {
  const [open, setOpen] = useState(false)
  const [presets, setPresets] = useState<readonly ProviderPlanPresetView[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [status, setStatus] = useState<'idle' | 'loading' | 'saving' | 'saved' | 'error'>('idle')

  useEffect(() => {
    if (!open) return
    setStatus('loading')
    void loadPlanProviders().then(
      values => {
        setPresets(values)
        setSelectedId(values[0]?.id ?? '')
        setStatus('idle')
      },
      () => { setStatus('error') },
    )
  }, [loadPlanProviders, open])

  const selected = useMemo(() => presets.find(entry => entry.id === selectedId), [presets, selectedId])
  const close = (): void => {
    if (status === 'saving') return
    setApiKey('')
    setOpen(false)
  }
  return (
    <>
      <button type="button" className={css.addPlan} onClick={() => { setOpen(true) }}>
        <IconPlusOutline16 size={14} />
        {t('addPlanProvider')}
      </button>
      <Modal
        open={open}
        onClose={close}
        title={t('planTitle')}
        closeLabel={t('close')}
        description={t('planDescription')}
        className={css.dialog as string}
        footer={(
          <>
            <Button variant="outline" disabled={status === 'saving'} onClick={close}>{t('cancel')}</Button>
            <Button
              variant="primary"
              disabled={selected === undefined || apiKey.trim().length === 0 || status === 'saving'}
              onClick={() => {
                if (selected === undefined) return
                setStatus('saving')
                void savePlanProvider({ presetId: selected.id, apiKey }).then(
                  () => { setApiKey(''); setStatus('saved') },
                  () => { setStatus('error') },
                )
              }}
            >
              {status === 'saving' ? t('planSaving') : t('planSave')}
            </Button>
          </>
        )}
      >
        <div className={css.body} aria-busy={status === 'loading'}>
          <label className={css.field}>
            <span>{t('planProvider')}</span>
            <SelectMenu
              value={selectedId}
              ariaLabel={t('planProvider')}
              disabled={status === 'loading' || status === 'saving'}
              onChange={value => { setSelectedId(value); setStatus('idle') }}
              options={presets.map(entry => ({ id: entry.id, label: entry.name }))}
            />
          </label>
          {selected !== undefined ? (
            <section className={css.card}>
              <div className={css.head}>
                <strong>{selected.name}</strong>
                <Pill>{t(selected.method === 'plan-api-key' ? 'planApiKey' : 'apiKeyOnly')}</Pill>
              </div>
              <p className={css.note}>{t(noteKey(selected.id))}</p>
              <a className={css.source} href={selected.sourceUrl} target="_blank" rel="noreferrer">
                <IconLinkOutline16 size={16} />
                {t('officialSource')}
              </a>
              <dl className={css.meta}>
                <div><dt>Base URL</dt><dd title={selected.baseURL}>{selected.baseURL}</dd></div>
                <div><dt>{t('models')}</dt><dd>{selected.models.map(model => model.name).join(' · ')}</dd></div>
              </dl>
            </section>
          ) : null}
          <label className={css.field}>
            <span>API Key</span>
            <input
              type="password"
              value={apiKey}
              autoComplete="off"
              spellCheck={false}
              disabled={status === 'saving'}
              onChange={event => { setApiKey(event.currentTarget.value); setStatus('idle') }}
              placeholder={t('planKeyPlaceholder')}
            />
            <small>{t('planKeySecurity')}</small>
          </label>
          {status === 'saved' ? <p className={css.success} role="status">{t('planSaved')}</p> : null}
          {status === 'error' ? <p className={css.error} role="alert">{t('planError')}</p> : null}
        </div>
      </Modal>
    </>
  )
}
