import type { DailyActivityView } from '../types.ts'

/** Heatmap aggregation mode. */
export type ActivityMode = 'daily' | 'weekly' | 'cumulative'

const DAY_MS = 86_400_000
const DAILY_CALENDAR_DAYS = 365

/** Fixed GitHub-style daily calendar geometry. */
export interface DailyCalendarLayout {
  readonly days: readonly DailyActivityView[]
  readonly startRow: number
  readonly columns: number
}

function emptyDay(date: string): DailyActivityView {
  return { date, calls: 0, tokens: 0, costKnown: 0, costUnknownCalls: 0 }
}

function dailyWindow(activity: readonly DailyActivityView[], windowDays: number, endDate: string): DailyActivityView[] {
  const byDate = new Map(activity.map(day => [day.date, day]))
  const end = Date.parse(`${endDate}T00:00:00.000Z`)
  return Array.from({ length: windowDays }, (_, index) => {
    const date = new Date(end - (windowDays - index - 1) * DAY_MS).toISOString().slice(0, 10)
    return byDate.get(date) ?? emptyDay(date)
  })
}

function weeklySeries(days: readonly DailyActivityView[]): DailyActivityView[] {
  const weeks = new Map<string, DailyActivityView>()
  for (const day of days) {
    const time = Date.parse(`${day.date}T00:00:00.000Z`)
    const date = new Date(time)
    const monday = new Date(time - ((date.getUTCDay() + 6) % 7) * DAY_MS).toISOString().slice(0, 10)
    const current = weeks.get(monday) ?? emptyDay(monday)
    weeks.set(monday, {
      date: monday,
      calls: current.calls + day.calls,
      tokens: current.tokens + day.tokens,
      costKnown: current.costKnown + day.costKnown,
      costUnknownCalls: current.costUnknownCalls + day.costUnknownCalls,
    })
  }
  return [...weeks.values()]
}

/** Build a continuous daily calendar or its weekly/cumulative projection. */
export function activitySeries(
  activity: readonly DailyActivityView[],
  mode: ActivityMode,
  windowDays = 91,
  endDate = new Date().toISOString().slice(0, 10),
): DailyActivityView[] {
  const daily = dailyWindow(activity, windowDays, endDate)
  if (mode === 'daily') return daily
  const weekly = weeklySeries(daily)
  if (mode === 'cumulative') {
    let calls = 0
    let tokens = 0
    let costKnown = 0
    let costUnknownCalls = 0
    return weekly.map((day) => {
      calls += day.calls
      tokens += day.tokens
      costKnown += day.costKnown
      costUnknownCalls += day.costUnknownCalls
      return { ...day, calls, tokens, costKnown, costUnknownCalls }
    })
  }
  return weekly
}

/** Build a fixed 365-day calendar while preserving empty dates as zero-value cells. */
export function dailyCalendarLayout(
  activity: readonly DailyActivityView[],
  endDate: string,
): DailyCalendarLayout {
  const days = dailyWindow(activity, DAILY_CALENDAR_DAYS, endDate)
  const startRow = new Date(`${days[0]!.date}T00:00:00.000Z`).getUTCDay()
  return {
    days,
    startRow,
    columns: Math.ceil((startRow + days.length) / 7),
  }
}
