/** Plugin-owned 16px Usage navigation glyph. */
export function IconUsageBarsOutline16({ size = 16, className }: {
  size?: number
  className?: string
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect x="2.25" y="9.5" width="2.5" height="4" rx="1" fill="currentColor" />
      <rect x="6.75" y="6.5" width="2.5" height="7" rx="1" fill="currentColor" />
      <rect x="11.25" y="2.5" width="2.5" height="11" rx="1" fill="currentColor" />
    </svg>
  )
}
