import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { Button, IconRefreshOutline16, Pill } from '@deepseek-ai/dsh-client-ui-primitives'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { AnalyticsQuery, OutputPriceBand, ProviderAnalyticsView, UsageRankView } from '../types.ts'
import { activitySeries, dailyCalendarLayout, type ActivityMode } from './activity.ts'
import { SelectMenu } from './SelectMenu.tsx'
import { formatTokens } from './token-format.ts'
import { TimeRangePicker } from './TimeRangePicker.tsx'
import { recentRange, type TimeRangeValue } from './time-range.ts'
import css from './UsageSection.module.css'

export interface UsageSectionInjected {
  analytics: (query: AnalyticsQuery) => Promise<ProviderAnalyticsView>
}

export type UsageSectionProps =
  PropsRuntime<'settings.section'>
  & PropsLocale<'settings.authInOne'>
  & InjectFace<UsageSectionInjected>

function duration(value: number): string {
  const hours = Math.floor(value / 3_600_000)
  const minutes = Math.floor(value % 3_600_000 / 60_000)
  return hours > 0 ? `${String(hours)}h ${String(minutes)}m` : `${String(minutes)}m`
}

function costText(row: UsageRankView, unknown: string): string {
  const { cost } = row
  if (cost.currency === null || cost.exactCalls + cost.partialCalls === 0) return unknown
  return `${cost.currency} ${cost.known.toFixed(cost.known < 1 ? 4 : 2)}${cost.partialCalls + cost.unknownCalls > 0 ? ' +' : ''}`
}

function monthGroups(series: readonly { date: string }[]): Array<{ key: string; label: string; size: number }> {
  const groups: Array<{ key: string; label: string; size: number }> = []
  for (const point of series) {
    const key = point.date.slice(0, 7)
    const current = groups.at(-1)
    if (current?.key === key) current.size += 1
    else groups.push({ key, label: new Intl.DateTimeFormat(undefined, { month: 'short', timeZone: 'UTC' }).format(new Date(`${key}-01T00:00:00.000Z`)), size: 1 })
  }
  return groups
}

function dateInTimeZone(time: number, timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(time))
  const fields = Object.fromEntries(parts.map(part => [part.type, part.value]))
  return `${fields.year}-${fields.month}-${fields.day}`
}

function TokenValue({ value, unknown }: { value: number; unknown: string }): ReactNode {
  const display = formatTokens(value)
  if (display === null) return unknown
  return <span title={display.exact} aria-label={display.exact}>{display.text}</span>
}

function Ranking({ title, rows, unknown, labels, usage = true }: {
  title: string
  rows: readonly UsageRankView[]
  unknown: string
  labels: { name: string; calls: string; tokens: string; cost: string }
  usage?: boolean
}): ReactNode {
  return (
    <section className={css.ranking} data-usage={usage ? 'true' : 'false'}>
      <h3>{title}</h3>
      {rows.length === 0 ? <p className={css.emptySmall}>—</p> : (
        <div className={css.tableWrap}>
          <table>
            <thead><tr><th>{labels.name}</th><th>{labels.calls}</th>{usage ? <><th>{labels.tokens}</th><th>{labels.cost}</th></> : null}</tr></thead>
            <tbody>{rows.slice(0, 8).map(row => (
              <tr key={row.id}>
                <td title={row.id}>{row.label}</td>
                <td>{row.calls.toLocaleString()}</td>
                {usage ? <><td><TokenValue value={row.tokens} unknown={unknown} /></td><td>{costText(row, unknown)}</td></> : null}
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
    </section>
  )
}

function ModelConsumption({ snapshot, title, otherLabel, empty, tokenScope }: {
  snapshot: ProviderAnalyticsView
  title: string
  otherLabel: string
  empty: string
  tokenScope: string
}): ReactNode {
  const sorted = [...snapshot.models].sort((left, right) => right.tokens - left.tokens || left.id.localeCompare(right.id))
  const top = sorted.slice(0, 5)
  const tail = sorted.slice(5)
  const rows = tail.length === 0 ? top : [...top, {
    id: '__other__',
    label: otherLabel,
    calls: tail.reduce((sum, row) => sum + row.calls, 0),
    tokens: tail.reduce((sum, row) => sum + row.tokens, 0),
    cost: { currency: null, known: 0, exactCalls: 0, partialCalls: 0, unknownCalls: 0 },
  }]
  const total = snapshot.kpis.totalTokens
  return (
    <section className={css.modelConsumption}>
      <h3>{title}</h3>
      {rows.length === 0 || total <= 0 ? <p className={css.emptySmall}>{empty}</p> : (
        <div className={css.consumptionRows}>
          {rows.map(row => {
            const percentage = row.tokens / total * 100
            const display = formatTokens(row.tokens)
            const exact = display?.exact ?? ''
            return (
              <div className={css.consumptionRow} key={row.id} title={`${row.label} · ${exact} · ${percentage.toFixed(2)}%`}>
                <div className={css.consumptionHead}>
                  <span>{row.label}</span>
                  <strong aria-label={`${exact}, ${percentage.toFixed(2)}%`}>{display?.text ?? '—'} <small>{percentage.toFixed(1)}%</small></strong>
                </div>
                <div className={css.progress} role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Number(percentage.toFixed(2))} aria-label={row.label}>
                  <span style={{ width: `${String(Math.min(100, Math.max(0, percentage)))}%` }} />
                </div>
              </div>
            )
          })}
        </div>
      )}
      <p className={css.tokenScope}>{tokenScope}</p>
      <div className={css.bucketGrid}>
        {[
          ['Input', snapshot.usage.uncachedInputTokens],
          ['Output', snapshot.usage.outputTokens],
          ['Cache read', snapshot.usage.cacheReadTokens],
          ['Cache write', snapshot.usage.cacheWriteTokens],
          ['Reasoning', snapshot.usage.reasoningTokens],
        ].map(([label, value]) => {
          const display = formatTokens(value as number)
          return <span key={label as string} title={display?.exact}><b>{label}</b>{display?.text ?? '—'}</span>
        })}
      </div>
    </section>
  )
}

/** Cross-session Usage page driven by one Host-side filter query. */
export function UsageSection({ analytics, t }: UsageSectionProps): ReactNode {
  const [timeRange, setTimeRange] = useState<TimeRangeValue>(() => recentRange(30))
  const [provider, setProvider] = useState('')
  const [priceBand, setPriceBand] = useState<OutputPriceBand>('all')
  const [mode, setMode] = useState<ActivityMode>('daily')
  const [generation, setGeneration] = useState(0)
  const [snapshot, setSnapshot] = useState<ProviderAnalyticsView | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
  const query = useMemo<AnalyticsQuery>(() => ({
    startTime: timeRange.startTime,
    endTimeExclusive: timeRange.endTimeExclusive,
    timeZone,
    provider: provider.length === 0 ? null : provider,
    outputPriceBand: priceBand,
  }), [priceBand, provider, timeRange, timeZone])

  useEffect(() => {
    let current = true
    setLoading(true)
    setError(null)
    void analytics(query).then(
      value => { if (current) setSnapshot(value) },
      () => { if (current) setError(t('loadError')) },
    ).finally(() => { if (current) setLoading(false) })
    return () => { current = false }
  }, [analytics, generation, query, t])

  if (snapshot === null && loading) return <div className={css.page} aria-busy="true"><div className={css.heroSkeleton} /><div className={css.gridSkeleton} /></div>
  if (snapshot === null) return (
    <div className={css.page}><div className={css.failure} role="alert"><span>{error ?? t('loadError')}</span><Button variant="outline" size="sm" onClick={() => { setGeneration(value => value + 1) }}>{t('retry')}</Button></div></div>
  )

  const visibleDays = Math.max(1, Math.min(365, Math.ceil((query.endTimeExclusive - query.startTime) / 86_400_000)))
  const endDate = dateInTimeZone(query.endTimeExclusive - 1, query.timeZone)
  const dailyLayout = dailyCalendarLayout(snapshot.activity, endDate)
  const series = mode === 'daily'
    ? dailyLayout.days
    : activitySeries(snapshot.activity, mode, visibleDays, endDate)
  const maxTokens = series.reduce((max, day) => Math.max(max, day.tokens), 0)
  const months = monthGroups(series)
  const heatColumns = Math.max(mode === 'daily' ? dailyLayout.columns : series.length, 1)
  const heatLayout = mode === 'daily' ? 'calendar' : 'strip'
  const heatCellSize = mode === 'daily' ? 14 : 18
  const heatmapMaxWidth = heatColumns * heatCellSize + Math.max(0, heatColumns - 1) * 2
  const hasCalls = snapshot.kpis.calls > 0
  const total = formatTokens(snapshot.kpis.totalTokens)
  const peak = formatTokens(snapshot.kpis.peakDailyTokens)
  const visionTokens = formatTokens(snapshot.callRoles.visionFallback.tokens)
  const kpis = [
    [t('totalTokens'), total?.text ?? t('unknown'), total?.exact],
    [t('mainCalls'), snapshot.callRoles.main.calls.toLocaleString(), undefined],
    [t('visionFallbackCalls'), snapshot.callRoles.visionFallback.calls.toLocaleString(), undefined],
    [t('visionFallbackTokens'), visionTokens?.text ?? t('unknown'), visionTokens?.exact],
    [t('peakTokens'), peak?.text ?? t('unknown'), peak?.exact],
    [t('longestSession'), duration(snapshot.kpis.longestSessionMs), undefined],
    [t('currentStreak'), `${String(snapshot.kpis.currentStreakDays)} ${t('dayUnit')}`, undefined],
    [t('longestStreak'), `${String(snapshot.kpis.longestStreakDays)} ${t('dayUnit')}`, undefined],
  ] as const
  const priceOptions: Array<{ id: OutputPriceBand; label: string }> = [
    { id: 'all', label: t('allOutputPrices') },
    { id: '0-1', label: '$0–1' },
    { id: '1-5', label: '$1–5' },
    { id: '5-15', label: '$5–15' },
    { id: '15-plus', label: '$15+' },
    { id: 'unpriced', label: t('unpriced') },
  ]

  return (
    <div className={css.page} data-usage-page aria-busy={loading}>
      <header className={css.pageHead}><div><h2>{t('usageTitle')}</h2><p>{t('usageIntro')}</p></div></header>
      <div className={css.filters} aria-label={t('filters')}>
        <TimeRangePicker
          value={timeRange}
          onChange={setTimeRange}
          labels={{
            aria: t('timeRange'), start: t('startTime'), end: t('endTime'), timeZone: t('timeZone'),
            cancel: t('cancel'), apply: t('apply'), invalid: t('invalidTimeRange'), previousMonth: t('previousMonth'), nextMonth: t('nextMonth'),
            days: [t('sun'), t('mon'), t('tue'), t('wed'), t('thu'), t('fri'), t('sat')],
            shortcut: days => t(days === 7 ? 'recent7d' : days === 15 ? 'recent15d' : 'recent30d'),
            summary: (start, end) => `${start} ${t('to')} ${end}`,
          }}
        />
        <SelectMenu
          className={css.providerSelect as string}
          value={provider}
          ariaLabel={t('providerRanking')}
          onChange={setProvider}
          options={[{ id: '', label: t('allProviders') }, ...snapshot.availableProviders]}
        />
        <SelectMenu
          className={css.priceSelect as string}
          value={priceBand}
          ariaLabel={`${t('outputPrice')} · USD / 1M ${t('outputTokens')}`}
          onChange={setPriceBand}
          options={priceOptions}
        />
        <Button
          className={`${css.refreshButton as string}${loading ? ` ${css.refreshing as string}` : ''}`}
          variant="outline"
          size="sm"
          icon={<IconRefreshOutline16 size={16} />}
          disabled={loading}
          onClick={() => { setGeneration(value => value + 1) }}
        >{t('refresh')}</Button>
      </div>
      <p className={css.filterNote}>{t('outputPriceUnit')} · {timeZone}</p>
      {error !== null ? <div className={css.inlineFailure} role="alert">{error}</div> : null}
      {!hasCalls ? <div className={css.empty}>{t('empty')}</div> : (
        <>
          <section className={css.kpis} aria-label={t('usageTitle')}>
            {kpis.map(([label, value, exact]) => <div key={label} title={exact}><strong aria-label={exact}>{value}</strong><span>{label}</span></div>)}
          </section>
          <section className={css.activity}>
            <div className={css.sectionHead}>
              <div><h3>{t('tokenActivity')}</h3><p>{t('recentHeatmap')}</p></div>
              <div className={css.pills}>{(['daily', 'weekly', 'cumulative'] as const).map(value => <Pill key={value} active={mode === value} onClick={() => { setMode(value) }}>{t(value)}</Pill>)}</div>
            </div>
            <div className={css.heatmapFrame} style={{ maxWidth: `${String(heatmapMaxWidth)}px` }}>
              <div className={css.heatmap} data-layout={heatLayout} role="group" aria-label={t('tokenActivity')} style={{ gridTemplateColumns: `repeat(${String(heatColumns)}, minmax(0, 1fr))` }}>
                {series.map((day, index) => {
                  const level = day.tokens === 0 || maxTokens === 0 ? 0 : Math.max(1, Math.ceil(day.tokens / maxTokens * 4))
                  const token = formatTokens(day.tokens)
                  const label = `${day.date}: ${token?.exact ?? t('unknown')}, ${day.calls.toLocaleString()} ${t('calls')}`
                  return <button
                    key={day.date}
                    type="button"
                    className={css.heatCell}
                    data-level={level}
                    aria-label={label}
                    title={label}
                    style={mode === 'daily' && index === 0 ? { gridRowStart: dailyLayout.startRow + 1 } : undefined}
                  />
                })}
              </div>
              <div className={css.monthScale} aria-hidden="true">{months.map(month => <span key={month.key} style={{ flexGrow: month.size }}>{month.label}</span>)}</div>
            </div>
            <div className={css.legend} aria-label={t('heatLegend')}><span>{t('less')}</span>{[0, 1, 2, 3, 4].map(level => <i key={level} data-level={level} />)}<span>{t('more')}</span></div>
          </section>
          <div className={css.overviewGrid}>
            <ModelConsumption snapshot={snapshot} title={t('modelTokenConsumption')} otherLabel={t('otherModels')} empty={t('empty')} tokenScope={t('tokenScope')} />
            <Ranking title={t('toolRanking')} rows={snapshot.tools} unknown={t('unknown')} labels={{ name: t('name'), calls: t('callCount'), tokens: t('tokens'), cost: t('cost') }} usage={false} />
          </div>
          <section className={css.costSummary}>
            <div><span>{t('costKnown')}</span><strong>{snapshot.cost.currency === null ? t('unknown') : `${snapshot.cost.currency} ${snapshot.cost.known.toFixed(4)}`}</strong></div>
            <div><span>{t('costPartial')}</span><strong>{snapshot.cost.partialCalls.toLocaleString()}</strong></div>
            <div><span>{t('costUnknownCalls')}</span><strong>{snapshot.cost.unknownCalls.toLocaleString()}</strong></div>
            <p>{t('catalogVersion')}: <code>{snapshot.catalogVersion}</code> · {snapshot.prices.length === 0 ? t('noPrice') : `${String(snapshot.prices.length)} ${t('priceSource')}`}</p>
            {snapshot.prices.length > 0 ? <ul className={css.priceSources}>{snapshot.prices.slice(0, 6).map(price => (
              <li key={`${price.provider}/${price.model}`}><a href={price.sourceUrl} target="_blank" rel="noreferrer">{price.provider}/{price.model}</a><span>{t(price.source === 'user' ? 'userPriceSource' : 'catalogPriceSource')} · {t('effectiveDate')} {price.effectiveDate} · {price.currency} · {t('outputPrice')} {price.outputPerMillion ?? t('unknown')}</span></li>
            ))}</ul> : null}
          </section>
          <div className={css.rankings}>
            <Ranking title={t('providerRanking')} rows={snapshot.providers} unknown={t('unknown')} labels={{ name: t('name'), calls: t('callCount'), tokens: t('tokens'), cost: t('cost') }} />
            <Ranking title={t('modelRanking')} rows={snapshot.models} unknown={t('unknown')} labels={{ name: t('name'), calls: t('callCount'), tokens: t('tokens'), cost: t('cost') }} />
          </div>
        </>
      )}
    </div>
  )
}
