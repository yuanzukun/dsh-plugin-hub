/** Generic seams owned by the 47f compatibility layer. */
export const OWNED_COMPAT_SEAMS = [
  'settings.models.insights',
  'settings.models.actions',
  'settings.section.icon',
] as const

/** Return already-declared seams without coupling the guard to a Cordis type. */
export function existingCompatSeams(spec: (name: string) => unknown): string[] {
  return OWNED_COMPAT_SEAMS.filter(name => spec(name) !== undefined)
}
