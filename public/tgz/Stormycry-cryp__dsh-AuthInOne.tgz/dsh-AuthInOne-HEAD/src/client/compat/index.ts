/**
 * DSH 47f compatibility owners.
 *
 * These owners are generic infrastructure: they preserve the official
 * Settings and Models surfaces while declaring three contribution seats.
 * AuthInOne business registrations live in the package client entrypoint.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import './slots.ts'
import { existingCompatSeams } from './guard.ts'
import { apply as applySettingsOwner } from './vendor/general/client/index.ts'
import { apply as applyModelsOwner } from './vendor/models/client/index.ts'

/** Fail before declaring anything when a host already supplies the seams. */
export function assertCompatSeamsAbsent(ctx: ClientContext): void {
  const existing = existingCompatSeams(name => ctx.slots.spec(name as never))
  if (existing.length > 0) {
    throw new Error(`auth-in-one compat: native settings seams already exist: ${existing.join(', ')}`)
  }
}

/** Mount the two official-compatible generic owners. */
export function applyCompatOwners(ctx: ClientContext): void {
  assertCompatSeamsAbsent(ctx)
  applySettingsOwner(ctx)
  applyModelsOwner(ctx)
}
