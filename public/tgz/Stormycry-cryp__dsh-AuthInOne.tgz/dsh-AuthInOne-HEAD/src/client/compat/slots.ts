import type { ReactNode } from 'react'

/** Generic owner share for content mounted into the Models page. */
export interface ModelsCompatOwnerProps {
  children?: never
}

/** Generic owner share for a settings navigation icon. */
export interface SettingsSectionIconOwnerProps {
  sectionId: string
  children?: never
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    'settings.models.insights': { kind: 'single'; scope: 'root'; owner: ModelsCompatOwnerProps }
    'settings.models.actions': { kind: 'single'; scope: 'root'; owner: ModelsCompatOwnerProps }
    'settings.section.icon': { kind: 'list'; scope: 'root'; owner: SettingsSectionIconOwnerProps }
  }
}

/** Component signature accepted by the generic section-icon projection. */
export type SettingsSectionIconComponent = (props: SettingsSectionIconOwnerProps) => ReactNode
