/** AuthInOne settings contributions and package-owned Remote mount. */

import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { TypertRemoteContribution, TypertRemoteNamespaceMap } from '@deepseek-ai/dsh-typert-protocol'
import authInOneRemote from '../generated/remote.ts'
import type { AnalyticsQuery, VisionFallbackConfig } from '../types.ts'
import { applyCompatOwners } from './compat/index.ts'
import './compat/slots.ts'
import { IconUsageBarsOutline16 } from './IconUsageBarsOutline16.tsx'
import { ModelsActions, type ModelsActionsInjected } from './ModelsActions.tsx'
import { ModelsProviderStatus, type ModelsProviderStatusInjected } from './ModelsProviderStatus.tsx'
import { UsageSection, type UsageSectionInjected } from './UsageSection.tsx'
import { en, zh, type AuthInOneLocaleKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'settings.authInOne': AuthInOneLocaleKey
  }

}

const NS = 'settings.authInOne'

/** Platform services required before the browser half activates. */
export const inject = ['slots', 'locale', 'remote', 'connection']

/** Mount the package Remote and register Models and Usage surfaces. */
export async function apply(ctx: ClientContext): Promise<() => Promise<void>> {
  applyCompatOwners(ctx)
  const disposeRemote = await ctx.remote.$mount(authInOneRemote as TypertRemoteContribution)
  const remote = ctx.get('remote.authInOne') as TypertRemoteNamespaceMap['authInOne'] | undefined
  if (remote === undefined) {
    await disposeRemote()
    throw new Error('auth-in-one: mounted Remote namespace is unavailable')
  }
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'auth-in-one: dictionaries')
  const t = ctx.locale.bind(NS)
  const providerChangeListeners = new Set<() => void>()
  const notifyProviderChange = (): void => {
    for (const listener of [...providerChangeListeners]) listener()
  }
  const subscribeProviderChange = (listener: () => void): (() => void) => {
    providerChangeListeners.add(listener)
    return () => { providerChangeListeners.delete(listener) }
  }
  ctx.effect(() => () => { providerChangeListeners.clear() }, 'auth-in-one: Provider projection invalidation')
  const loadProviders: ModelsProviderStatusInjected['loadProviders'] = async () => {
    const result = await remote.providers()
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const probe: ModelsProviderStatusInjected['probe'] = async provider => {
    const result = await remote.probe(provider)
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const saveDefault: ModelsProviderStatusInjected['saveDefault'] = async (provider, model) => {
    const result = await remote.saveDefault(provider, model)
    if (!result.ok) throw new Error(result.error.message)
  }
  const loadProviderQuotas: ModelsProviderStatusInjected['loadProviderQuotas'] = async () => {
    const result = await remote.providerQuotas()
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const loadVisionFallback: ModelsProviderStatusInjected['loadVisionFallback'] = async () => {
    const result = await remote.visionFallback()
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const saveVisionFallback: ModelsProviderStatusInjected['saveVisionFallback'] = async (request: VisionFallbackConfig) => {
    const result = await remote.saveVisionFallback(request)
    if (!result.ok) throw new Error(result.error.message)
  }
  const analytics: UsageSectionInjected['analytics'] = async (query: AnalyticsQuery) => {
    const result = await remote.analytics(query)
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const loadAuthProviders: ModelsActionsInjected['loadAuthProviders'] = async () => {
    const result = await remote.authProviders()
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const startAuth: ModelsActionsInjected['startAuth'] = async provider => {
    const result = await remote.startAuth(provider)
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const cancelAuth: ModelsActionsInjected['cancelAuth'] = async (provider, attemptId) => {
    const result = await remote.cancelAuth(provider, attemptId)
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const submitAuth: ModelsActionsInjected['submitAuth'] = async (provider, attemptId, value) => {
    const result = await remote.submitAuth(provider, attemptId, value)
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const logoutAuth: ModelsActionsInjected['logoutAuth'] = async provider => {
    const result = await remote.logoutAuth(provider)
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const logoutProvider: ModelsProviderStatusInjected['logoutAuth'] = async provider => {
    await logoutAuth(provider)
  }
  const loadPlanProviders: ModelsActionsInjected['loadPlanProviders'] = async () => {
    const result = await remote.planProviders()
    if (!result.ok) throw new Error(result.error.message)
    return result.value
  }
  const savePlanProvider: ModelsActionsInjected['savePlanProvider'] = async request => {
    const result = await remote.savePlanProvider(request)
    if (!result.ok) throw new Error(result.error.message)
  }

  ctx.slots.inject('settings.models.insights', () => ctx.slots.register({
    name: 'settings.models.insights',
    locale: NS,
    inject: (): ModelsProviderStatusInjected => ({
      loadProviders, loadProviderQuotas, loadVisionFallback, saveVisionFallback,
      probe, logoutAuth: logoutProvider, saveDefault, subscribeProviderChange,
    }),
  }, ModelsProviderStatus))
  ctx.slots.inject('settings.models.actions', () => ctx.slots.register({
    name: 'settings.models.actions',
    locale: NS,
    inject: (): ModelsActionsInjected => ({
      loadAuthProviders, startAuth, cancelAuth, submitAuth, logoutAuth, notifyProviderChange, loadPlanProviders, savePlanProvider,
    }),
  }, ModelsActions))
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'usage',
    order: 12,
    label: () => t('usageNav'),
    locale: NS,
    inject: (): UsageSectionInjected => ({ analytics }),
  }, UsageSection))
  ctx.slots.inject('settings.section.icon', () => ctx.slots.register({
    name: 'settings.section.icon',
    id: 'usage',
    locale: NS,
  }, IconUsageBarsOutline16))

  return disposeRemote
}
