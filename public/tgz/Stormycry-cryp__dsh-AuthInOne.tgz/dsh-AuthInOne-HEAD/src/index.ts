/** AuthInOne Host plugin and Web client roster entry. */

export { AuthInOneService, Config, foldProviderAnalytics, outputPriceBandOf } from './host/index.ts'
export type * from './host/index.ts'
export { default } from './host/index.ts'
