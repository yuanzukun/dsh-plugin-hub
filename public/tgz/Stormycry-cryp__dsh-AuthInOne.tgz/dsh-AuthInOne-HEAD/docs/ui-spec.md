# DSH-native UI specification

## Navigation

AuthInOne does not add a top-level product destination. Provider operations stay under Settings → Models. Usage is a sibling Settings section ordered between Models and Plugins.

## Models contribution

The contribution begins after the native Models introduction and before Provider cards. It uses the host heading hierarchy, semantic text colors, outline and primary buttons, StateDot, Pill, native input treatment, and the existing content width. Each Provider row exposes redacted connection state, model selection, connection test, and future-session default routing. Credential and endpoint editing remain in the native cards below.

Loading uses a reduced-motion-safe skeleton. Remote failure includes a retry action. Probe results are status text with semantic success or error color; state is not conveyed by color alone.

## Usage section

The first screen presents one five-cell KPI strip, then Token activity as the dominant surface. The calendar uses the selected local-time range after deterministic UTC conversion, month scale, accessible daily buttons, a five-step semantic color scale, and daily, weekly, or cumulative controls. Model Token consumption and tool ranking form the next row; cost provenance and Provider/model rankings follow.

The filter bar contains a second-precision time-range calendar, Provider dropdown, USD output-price band, and text-plus-icon refresh action. The controls share one query context. At settings-panel widths below 900 px, time occupies the first row and the remaining controls reflow without splitting or clipping the refresh label.

Numbers use tabular figures. Unknown, partial, official-catalog, and user-override prices are labeled in text. Ranking labels truncate with their full value available through the title tooltip. The page has loading, empty, remote-error, missing-price, and connection-failure states.

At narrow widths, KPI cells reflow to two columns, rankings and insights become one column, filters stack when needed, and the calendar reduces its gap without horizontal overflow. All colors come from DSH semantic variables; there are no global selectors, fixed light-only colors, gradients, glass effects, or decorative animation.
