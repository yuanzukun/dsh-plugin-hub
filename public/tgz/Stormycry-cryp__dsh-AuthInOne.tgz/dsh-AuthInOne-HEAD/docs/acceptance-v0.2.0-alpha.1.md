# v0.2.0-alpha.1 interaction acceptance matrix

All applicable rows below are `PASS` for the published prerelease. Automated
evidence proves state transitions and failure paths; the official-47f column
records real interaction at `127.0.0.1:3080`. Personal Codex credentials were
not destructively logged out merely to repeat a transaction already covered by
Host tests; the real card, action, and non-Auth Provider isolation were checked.

## Models native behavior

| Requirement | Automated evidence | Official-47f real interaction | Status |
| --- | --- | --- | --- |
| Native Provider cards and visual language are preserved | Exact 47f runtime graph check; unmodified files byte-equal upstream; typecheck/build pass | DeepSeek and kimi cards rendered in the native list; edit dialogs opened and cancelled without card drift | PASS |
| Edit, delete, add Provider, and add custom Provider | Official Models implementation retained; owner graph gate covers every runtime dependency | Add Provider and Add Custom Provider opened and cancelled; DeepSeek edit opened; delete control remained on the custom Provider card | PASS |
| Default-model selection, connection test, and set-default | Projection/default tests pass | DeepSeek `/models` test returned `459 ms · 2`; model was selected and Set default returned `默认模型已更新` | PASS |
| Scroll, modal, mask, Escape, close, and focus behavior | Vendored owner tests plus SelectMenu keyboard/focus tests pass | Settings and Provider/Auth/custom-model dialogs opened, scrolled, cancelled, and closed at desktop and 760 px | PASS |
| Add Auth login is a distinct third action beside the two native add actions | Models owner declares `settings.models.actions`; component test covers the Auth action | Exactly one `添加 Auth 登录` rendered above the native add pair and opened the Auth catalog | PASS |
| Provider/model/time/price controls never fall back to native `select` | Boundary gate rejects native `select`; SelectMenu arrows, Enter, Escape, focus restoration, disabled and grouping tests pass | Provider, model, protocol, vision, time and price menus rendered as custom comboboxes; native select count = 0 | PASS |

## Auth interaction

| Requirement | Automated evidence | Official-47f real interaction | Status |
| --- | --- | --- | --- |
| Auth action opens the Provider catalog and selected Provider flow | Auth dialog/component and Host transaction tests pass | Catalog opened from the distinct Models action and showed the connected OpenAI Codex entry | PASS |
| Cancel selection/login leaves no card, default change, loading, error, or article residue | Cancellation and transaction tests pass | Cancel closed the catalog; article count stayed 4 and default stayed GPT-5.6 Luna | PASS |
| Only connected/reauthorization Auth instances become cards; no ghost catalog cards | Projection fixtures exclude catalog-only entries | Connected OpenAI Codex card visible; xAI and Anthropic ghost cards = 0 | PASS |
| Connected Auth model selection and set-default work without generic Base URL probe | Provider projection branches on Auth mode; component tests pass | Codex model combobox and Set default visible; Test connection absent on the Auth card | PASS |
| Logout removes the DSH credential/route/card without affecting native Providers | Host logout/dispose/credential-clear tests pass | `退出并清除凭据` is present on the connected card; destructive logout of the user's real Codex credential was intentionally not executed | PASS |
| Quota is wholly hidden unless upstream supplies complete computable percentages | Invalid, incomplete and non-computable quota tests pass | No error/placeholder quota block rendered; only reliable account/route consumption copy was shown | PASS |

## Vision fallback interaction

| Requirement | Automated evidence | Official-47f real interaction | Status |
| --- | --- | --- | --- |
| Independent Models block, default off, explicit text-only explanation | Default/toggle/copy tests pass | Block rendered default-off with `仅当主模型不支持图片输入时启用；原生多模态模型不会经过兜底` | PASS |
| Routes are configured and currently usable Auth, official API, or custom API instances only | Projection excludes catalog ghosts, missing credentials and unreadable model lists | Route menu contained connected Codex and configured kimi; unconfigured catalog entries were absent | PASS |
| Two-stage selection saves stable Provider instance id then model id; labels are not identity | DTO/config tests assert stable ids and same-label isolation | Codex instance then GPT-5.6 Luna selected, saved, reloaded, and preserved | PASS |
| Provider choices are grouped as Account Auth / API / Custom API and show access type | Grouping/description component tests pass | Menu showed `账号 Auth` and `API Provider` groups plus masked Codex account context | PASS |
| Models enter the route menu only through authoritative `inputModalities: image`; names are never guessed | Capability tests reject vision-like names with unknown capability | Codex listed only explicit image-capable GPT-5.4/5.5/5.6 entries; text-only DeepSeek was absent | PASS |
| Custom Provider models expose an explicit default-off Supports image input flag | Custom capability serialization/default tests pass | Custom Provider model editor showed the default-off `支持图片输入` checkbox; cancelling left no Provider residue | PASS |
| Save does not make a quota-consuming probe | Save/projection tests and source boundary audit pass | Provider/model saved immediately, reloaded, and later disabled without a connection-test call | PASS |
| Native image-capable main model passes through unchanged | Vision middleware test passes | Keyless dispatch test proves no fallback call; Models copy states the same behavior | PASS |
| Fallback runs only for explicit text-only main model while enabled; disable stops immediately | Middleware policy tests pass | Enabled route survived reload; toggling off and saving retained selection but disabled intervention | PASS |
| Loading, error, empty, and save failure remain understandable/retryable | Empty/error/save-failure and sanitized Host-error tests pass | Normal loading/save status cleared correctly; no stale error/loading article remained after cancel/reload | PASS |
| Invalid saved route is marked Currently unavailable, fails closed, and recovers only if the same route returns | Credential/provider/model disappearance and recovery tests pass | Real selected route availability and quota owner copy rendered; destructive credential expiry/removal used automated evidence | PASS |
| Copy identifies whose Auth/API quota an auxiliary call consumes | Locale/component tests pass | Copy named OpenAI Codex, `账号 Auth`, and the masked account | PASS |
| Multi-image, resume/fork reuse, route switching, upstream failure, and fail-closed behavior | Middleware/integration fixtures cover every path without paid calls | Settings remained stable across reload; no paid model call was required for the deterministic dispatch gate | PASS |
| No plugin image/secret persistence | Boundary/source audit pass | Profile patch remained `[]`; package/settings inspection found only stable route/model ids, while DSH owns attachments and credentials | PASS |

## Usage interaction and visual behavior

| Requirement | Automated evidence | Official-47f real interaction | Status |
| --- | --- | --- | --- |
| Nav icon is exactly three vertical `rect` bars using `currentColor` | Icon markup test passes | Light/dark/760 rendered SVG had 3 rects, 0 paths, all fills `currentColor` | PASS |
| Time and Provider filters share a row and use DSH-styled controls | Component tests pass | Desktop controls shared y=144 (refresh y=146 visual alignment); 760 stacked without overflow | PASS |
| Time editor has calendar, second precision, and 7/15/30-day shortcuts | Range/calendar tests pass | Dialog showed second-precision start/end fields, calendar grid, timezone, and all three shortcuts | PASS |
| Refresh control includes icon and preserves filters | Component logic test passes | Refresh control rendered its circular-arrow icon and remained in the filter group | PASS |
| Price filter means output-token price bands, not total cost | Fold/query tests pass | Label was `输出价格 · USD / 1M 输出 Token`; explanatory copy stated the same unit | PASS |
| Token values use readable small values and at most two decimals with M/B | Formatter tests pass | Current small totals stayed comma-readable; ranked percentages remained concise | PASS |
| Daily heatmap is 365 dates, seven rows, 53 columns, retained empty dates and month axis | Activity tests pass | DOM contained exactly 365 dated cells and 13 month labels; desktop/760 had no page overflow | PASS |
| Model Token panel uses progress bars; plugin/tool and model call counts remain distinct | Component/fold tests pass | Two model progressbars rendered; plugin/tool section and Provider/model tables remained separate | PASS |
| Vision-assist usage is attributed to the auxiliary route, separate from main | Fold and vision tests pass | KPI exposed distinct main and visual call/token buckets; current durable sample correctly showed zero visual calls | PASS |
| Vision attribution retains stable Provider/model identity, token/call counts, and reliable cost only | Fold/DTO tests pass | Provider/model tables kept identities; Codex cost displayed `未知` while priced DeepSeek showed USD 0.0021 | PASS |
| Missing usage/price stays unknown or unpriced | Fold/UI tests pass | Two unpriced calls were labeled `费用未知调用`; no guessed cost appeared | PASS |

## Installation and page-level acceptance

| Requirement | Evidence | Status |
| --- | --- | --- |
| Official 47f runtime sources/manifests/lock equal commit `47f9438`; protected docs excluded | DSH root `47f943859bef60e4160492346772ded9b24f765a`; runtime diff for `packages/ apps/ vendor/ package.json pnpm-lock.yaml` = 0; protected `M AGENTS.md` and `?? memory/` untouched | PASS |
| No seam worktree process, `--patch`, manual profile patch, source link, or copied bundle | 3080 process cwd was official DSH root; profile `cordis.patch.yml` = `[]`; dump-config/package manifest named only the installed Bundle | PASS |
| Official CLI remove makes compat/Auth/Usage/vision/Remote disappear while native Models remains | After remove: Auth=0, Usage nav=0, vision=0, two native cards and both native add actions remained; add dialog opened/cancelled | PASS |
| Build one unique TGZ and add through official CLI | `/tmp/dsh-authinone-final.ieuvdw/dsh-auth-in-one-0.2.0-alpha.1.tgz`; SHA-256 `834d491712976b4b79c9b693abc702aa3dbca9b156576e8c1729a91c6e53dca7` | PASS |
| Models and Usage screenshots: light/dark x desktop/760; no overflow or spacing drift | Eight screenshots under `/tmp/dsh-authinone-ui.XkhoLS`; desktop width 1280 and narrow width 760; document overflow false in every measured state | PASS |
| Real click chains pass and post-load console errors/warnings equal zero | Fresh installed page console result `[]`; Auth, native Provider, vision, Usage filters, theme and viewport chains exercised | PASS |
| Remove restores official Models completely; reinstalling identical TGZ reproduces accepted state | Remove dump restored original owner rows; reinstall SHA identical and returned Auth=1, vision=1, Usage=1, Codex connected=1, ghost=0, icon rects=3, console `[]` | PASS |

This matrix records the local and public-tag installation gates used for the
`v0.2.0-alpha.1` prerelease.
