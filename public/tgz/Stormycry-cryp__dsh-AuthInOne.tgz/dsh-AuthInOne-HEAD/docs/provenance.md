# Provenance audit

This audit covers the alpha.2 source, generated artifacts, documentation, CSS, screenshots, schema, tests, and packaged dependencies.

## Clean-room implementation

The plugin source, module boundaries, exported types, credential representation, Remote DTOs, state machines, settings fields, aggregation schema, React components, CSS modules, interaction copy, tests, and README prose were independently written for dsh-AuthInOne. No third-party plugin source fragment, README passage, CSS rule set, component tree, SQL schema, or test fixture was copied or vendored.

The local OpenCodex source export was read only to compare protocol ownership, cancellation, refresh, account-store, redaction, and UI/Host responsibility. Its proxy, multi-account pool, local credential import, catalog routing, constants table, source layout, API names, persistence formats, and UI structure were not adopted. The detailed read receipt is in [OpenCodex authentication comparison](design/opencodex-auth-comparison.md).

## Collision research

These public repositories were used only to identify existing capabilities and avoid presenting a duplicate single-purpose plugin as novel:

- `csiroqa/dsh-plugin-usage-report` for persistent usage, cost, budget, and activity-grid scope;
- `yoke233/dsh-openai-codex-auth` and `Hu9956/dsh-codex-provider` for the existence of Codex account flows and DSH credential integration;
- `Jesse-njx/dsh-polyglot` for OpenAI-compatible routing and per-Provider accounting scope;
- `cute-baobao/dsh-usage-meter` and `suimi8/dsh-cost-ledger` for persistent model/day and cost-ledger scope;
- `zhu1090093659/dsh-web-ui` for the breadth of community Web UI integrations.

None is a runtime dependency. AuthInOne differs by keeping Provider account login, Plan/API setup, native Models contributions, default routing, cross-session usage, price provenance, and model/tool analytics in one independently installable DSH bundle.

## Formal dependencies

| Package | Version | License | Use |
| --- | --- | --- | --- |
| `zod` | 4.4.3 | MIT | Runtime schema validation required by generated Typert artifacts |
| `@earendil-works/pi-ai` | 0.82.1 | MIT | Reviewed Provider transport and public-client helpers bundled into `lib/host.js` and the three small OAuth chunks |
| `@cursor/sdk` | 1.0.24 | Cursor SDK License and Terms of Service | Experimental Cursor transport bundled into `lib/host.js` |
| React and Testing Library | locked versions | MIT | Client and test development |
| TypeScript | locked version | Apache-2.0 | Compilation |
| Lightning CSS | locked version | MPL-2.0 | Client CSS bundling |

Standard DSH installation does not add pi-ai or Cursor SDK as separate Web-profile packages. Their required code is in the committed Host artifact. No dependency is used to read another product's credential store.

## Assets and trademarks

`docs/assets/cover.png` is the final user-approved generated cover. The repository does not include the third-party meme/reference image or superseded cover candidates. The README screenshots come from the standard-installed DSH page and contain no account, API key, authorization URL, user code, or token.

Provider names and logos remain the property of their respective owners. Their appearance communicates compatibility only and does not imply sponsorship, certification, partnership, or endorsement.

## Audit result

The alpha.2 provenance review found no unowned copied source or documentation. The package includes only independently written project code, DSH public extension usage, reviewed protocol behavior, generated build artifacts, declared formal dependencies, and the final approved assets.
