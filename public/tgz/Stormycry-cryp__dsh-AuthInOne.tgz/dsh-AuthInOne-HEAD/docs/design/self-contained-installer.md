# Self-contained installer and same-port restart

## Objective

Ship AuthInOne as one repository and one package. A user or Agent runs the AuthInOne bootstrap command; the package uses the official DSH plugin CLI to add or remove the Bundle, validates the exact supported DSH runtime before interruption, and replaces the running `web` Host on its original loopback port. No DSH source change, profile YAML edit, workspace link, temporary Web port, or second long-lived Host is required.

## Public command

```sh
pnpm dlx github:Stormycry-cryp/dsh-AuthInOne#v0.2.0-alpha.4 install --profile web
```

The bootstrap is the supported Agent-facing installation path. It accepts `--url` when the existing Host uses a non-default loopback port and `--source-root` for a DSH source checkout whose CLI is invoked as `pnpm dsh`. The default URL is `http://127.0.0.1:3080/`.

The bootstrap only supports a loopback HTTP URL and a standard DSH launch: an installed `dsh` executable or an explicitly supplied DSH source root. It does not replay arbitrary shell text or guess a service-manager configuration. Unsupported launch provenance fails before the running Host is stopped.

## Install sequence

1. Parse and validate the profile, loopback URL, optional DSH source root, and timeout.
2. Invoke the official DSH command `plugin --profile <profile> add <immutable package spec>` without patching DSH files.
3. Resolve the installed package from the profile and run the installed copy of the bootstrap. The transient `pnpm dlx` directory is not used by the detached supervisor.
4. Resolve the installed DSH compatibility-owner artifacts and run AuthInOne's exact version and SHA-256 guard before scheduling any stop.
5. Find the unique process listening on the requested port, verify its working directory and DSH launch provenance, then create a detached supervisor plan containing only process identifiers, paths, arguments, profile, URL, and timeouts. Environment values are inherited by the child process but are never serialized or logged.
6. Return from the install command. The detached installed-package supervisor waits for the caller to exit, sends `SIGTERM` only to the validated listener PID, waits for that PID and port to close, starts `dsh web` with the original working directory and port, and waits for the original URL to return HTTP success.

There is no alternate-port fallback. A healthy original Host is left running if compatibility or launch provenance cannot be established before handoff.

## Failure reporting and recovery

The detached supervisor writes one bounded, credential-free status document under the selected DSH profile with owner-only permissions. Status records the phase, timestamps, PID, URL, sanitized executable and arguments, and a recovery command. Replacement-process stdout and stderr are not persisted by the bootstrap. Status never records environment variables, credentials, authorization URLs, cookies, request headers, or Provider responses.

If installation fails, DSH remains running and the official CLI error is returned. If the old Host cannot be stopped, no replacement is started. If replacement startup fails after a successful stop, the status file reports the exact non-secret failure and the standard recovery command; it does not move to another port.

## Uninstall

The bootstrap also owns the symmetric removal path. It invokes the official DSH plugin remove command, then performs the same validated same-port replacement. Plugin settings, session data, and credential references remain subject to the existing DSH removal contract; the bootstrap does not delete user data.

## Acceptance gates

- Parser, loopback restriction, profile/path validation, command construction, preflight-before-stop ordering, exact-PID signaling, same-port restart, timeout, sanitized status, and failure recovery have deterministic tests.
- Typecheck, focused tests, build, package boundary verification, artifact normalization, and pack dry-run pass under a supported Node version.
- A packed artifact is installed into the official DSH `47f9438` target through the bootstrap, not by a workspace link or manual profile edit.
- The original `127.0.0.1:3080` listener PID is replaced, the URL returns, the profile contains the package and Bundle, and no secondary port remains.
- Browser acceptance confirms Models, Auth, vision fallback, Usage, and the three-bar Usage icon after a fresh same-port restart.
- Removal through the bootstrap restores the native Models surface on the same URL.

## Non-goals

- Changing the DSH core CLI or requiring a custom DSH build.
- Hot-loading a new Bundle into an already composed Host.
- Killing an unverified process, restarting arbitrary process managers, or preserving undocumented shell wrappers.
- Reading or migrating credentials from other products.
