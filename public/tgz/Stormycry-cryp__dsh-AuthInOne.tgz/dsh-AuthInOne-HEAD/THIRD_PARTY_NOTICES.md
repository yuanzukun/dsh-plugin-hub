# Third-party notices

The compatibility owner sources under `src/client/compat/vendor/` are derived
from DeepSeek Harness commit
`47f943859bef60e4160492346772ded9b24f765a`, specifically the runtime sources
of `@deepseek-ai/dsh-client-ui-settings-general` and
`@deepseek-ai/dsh-client-ui-settings-models`. AuthInOne changes only their
generic composition points so one Bundle can expose child slots on the
official 47f host. No AuthInOne authentication, Provider, usage, or vision
business logic is included in the vendored owner modules.

DeepSeek Harness is licensed under the MIT License:

Copyright (c) 2026 DeepSeek

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
