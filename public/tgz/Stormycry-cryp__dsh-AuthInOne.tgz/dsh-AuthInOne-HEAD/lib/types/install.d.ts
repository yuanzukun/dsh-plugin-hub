/** Self-contained AuthInOne installer and same-port DSH Web restart supervisor. */
import { type SpawnSyncReturns } from 'node:child_process';
type PublicAction = 'install' | 'uninstall' | 'status';
type RestartPhase = 'scheduled' | 'stopping' | 'starting' | 'ready' | 'failed';
export interface LaunchCommand {
    executable: string;
    args: string[];
    cwd: string;
}
export interface InstallerOptions {
    action: PublicAction;
    profile: string;
    url: URL;
    sourceRoot?: string | undefined;
    packageSpec: string;
    timeoutMs: number;
}
export interface RestartPlan {
    version: 1;
    callerPid: number;
    listenerPid?: number | undefined;
    profile: string;
    profileDir: string;
    url: string;
    port: number;
    launch: LaunchCommand;
    timeoutMs: number;
    handoffDelayMs: number;
    statusPath: string;
    supervisorPath: string;
}
export interface RestartStatus {
    version: 1;
    phase: RestartPhase;
    updatedAt: string;
    profile: string;
    url: string;
    previousPid?: number | undefined;
    replacementPid?: number | undefined;
    recoveryCommand: string;
    message: string;
}
export interface InstallerRuntime {
    assertCompatibleHost(anchor: string): void;
    run(command: LaunchCommand): SpawnSyncReturns<Buffer>;
    findListeners(port: number): number[];
    processCwd(pid: number): string;
    processCommand(pid: number): string;
    processExists(pid: number): boolean;
    signal(pid: number, signal: NodeJS.Signals): void;
    start(command: LaunchCommand): Promise<number>;
    startSupervisor(modulePath: string, planPath: string): Promise<number>;
    probe(url: string): Promise<boolean>;
    sleep(ms: number): Promise<void>;
    now(): Date;
}
export declare const DEFAULT_RUNTIME: InstallerRuntime;
/** Parse the public bootstrap command without accepting path-like profile names or remote targets. */
export declare function parseInstallerArgs(argv: readonly string[]): InstallerOptions | {
    action: '__supervise';
    planPath: string;
};
/** Resolve the profile directory without importing private DSH source modules. */
export declare function profileDirectory(profile: string): string;
interface ResolvedLaunch {
    plugin: LaunchCommand;
    web: LaunchCommand;
    compatibilityAnchor: string;
    listenerPid?: number | undefined;
}
/** Resolve one standard DSH launcher and refuse ambiguous or unrelated listeners. */
export declare function resolveLaunch(options: InstallerOptions, runtime?: InstallerRuntime): Promise<ResolvedLaunch>;
/** Execute a detached same-port replacement from a credential-free serialized plan. */
export declare function superviseRestart(plan: RestartPlan, runtime?: InstallerRuntime): Promise<void>;
/** Install or remove through the official DSH CLI, then schedule an exact same-port restart. */
export declare function runInstaller(options: InstallerOptions, runtime?: InstallerRuntime): Promise<RestartPlan | RestartStatus | undefined>;
export {};
//# sourceMappingURL=install.d.ts.map