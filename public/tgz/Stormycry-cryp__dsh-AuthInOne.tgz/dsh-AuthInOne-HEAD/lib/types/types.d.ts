/** Wire-safe Provider Insights data contracts. */
export type { VisionFallbackConfig, VisionFallbackView } from './host/vision-fallback.ts';
/** Disjoint USD output-token price bands used by Usage filtering. */
export type OutputPriceBand = 'all' | '0-1' | '1-5' | '5-15' | '15-plus' | 'unpriced';
/** One exact Usage query; end is exclusive after the UI's inclusive second. */
export interface AnalyticsQuery {
    readonly startTime: number;
    readonly endTimeExclusive: number;
    readonly timeZone: string;
    readonly provider: string | null;
    readonly outputPriceBand: OutputPriceBand;
}
/** Disjoint provider-reported usage buckets plus missing-value evidence. */
export interface UsageBucketsView {
    readonly uncachedInputTokens: number;
    readonly outputTokens: number;
    readonly cacheReadTokens: number;
    readonly cacheWriteTokens: number;
    readonly reasoningTokens: number;
    readonly callsWithoutUsage: number;
    readonly callsWithoutCacheRead: number;
    readonly callsWithoutCacheWrite: number;
    readonly callsWithoutReasoning: number;
}
/** One auditable model-price row, denominated per million tokens. */
export interface ModelPriceView {
    readonly provider: string;
    readonly model: string;
    readonly currency: string;
    readonly sourceUrl: string;
    readonly updatedAt: string;
    readonly effectiveDate: string;
    readonly uncachedInputPerMillion?: number;
    readonly outputPerMillion?: number;
    readonly cacheReadPerMillion?: number;
    readonly cacheWritePerMillion?: number;
    readonly reasoningPerMillion?: number;
    readonly source: 'catalog' | 'user';
}
/** Cost subtotal that never treats unknown buckets as zero-priced facts. */
export interface CostView {
    readonly currency: string | null;
    readonly known: number;
    readonly exactCalls: number;
    readonly partialCalls: number;
    readonly unknownCalls: number;
}
/** One heatmap day. */
export interface DailyActivityView {
    readonly date: string;
    readonly calls: number;
    readonly tokens: number;
    readonly costKnown: number;
    readonly costUnknownCalls: number;
}
/** One ranked usage row. */
export interface UsageRankView {
    readonly id: string;
    readonly label: string;
    readonly calls: number;
    readonly tokens: number;
    readonly cost: CostView;
}
/** Cross-session KPI values for the selected window. */
export interface InsightsKpisView {
    readonly calls: number;
    readonly sessions: number;
    readonly totalTokens: number;
    readonly peakDailyTokens: number;
    readonly longestSessionMs: number;
    readonly currentStreakDays: number;
    readonly longestStreakDays: number;
}
/** Provider-reported accounting split by conversation and vision-assist calls. */
export interface CallRoleSummaryView {
    readonly calls: number;
    readonly tokens: number;
    readonly cost: CostView;
}
/** Complete cross-session analytics result. */
export interface ProviderAnalyticsView {
    readonly generatedAt: number;
    readonly query: AnalyticsQuery;
    readonly kpis: InsightsKpisView;
    readonly usage: UsageBucketsView;
    readonly cost: CostView;
    readonly callRoles: {
        readonly main: CallRoleSummaryView;
        readonly visionFallback: CallRoleSummaryView;
    };
    readonly activity: readonly DailyActivityView[];
    readonly providers: readonly UsageRankView[];
    readonly models: readonly UsageRankView[];
    readonly tools: readonly UsageRankView[];
    /** Provider choices observed in the selected time range before Provider/price filtering. */
    readonly availableProviders: readonly {
        readonly id: string;
        readonly label: string;
    }[];
    readonly catalogVersion: string;
    readonly prices: readonly ModelPriceView[];
}
/** One selectable model from an active provider. */
export interface ProviderModelView {
    readonly id: string;
    readonly name: string;
}
/** Current provider connection and configuration metadata, without secrets. */
export interface ProviderConnectionView {
    readonly id: string;
    readonly name: string;
    readonly active: boolean;
    readonly configurable: boolean;
    readonly declared: boolean;
    readonly configured: boolean;
    readonly credentialConfigured: boolean | null;
    readonly credentialWritable: boolean | null;
    readonly authMode: 'api-key-only' | 'oauth';
    readonly accessType: 'account-auth' | 'api' | 'custom-api';
    readonly accountLabel: string | null;
    readonly settingsNs: string | null;
    readonly baseURL: string | null;
    readonly models: readonly ProviderModelView[];
    readonly modelError: string | null;
}
/** Protocols the Host may persist for a DSH pi-ai Provider profile. */
export type ProviderApi = 'openai-completions' | 'openai-responses' | 'anthropic-messages';
/** Browser-safe state of one official Host-managed account login. */
export type AuthErrorCategory = 'cancelled' | 'expired' | 'denied' | 'state-mismatch' | 'callback-unavailable' | 'token-exchange-failed' | 'refresh-rejected' | 'network' | 'revocation-failed' | 'invalid-response';
/** Browser-safe state of one official Host-managed account login. */
export interface AuthProviderView {
    readonly id: string;
    readonly name: string;
    readonly method: 'browser-oauth' | 'device-code';
    readonly official: boolean;
    readonly available: boolean;
    readonly stability: 'stable' | 'experimental' | 'unsupported';
    readonly sourceUrl: string;
    /** Stable public reason why an unavailable entry fails closed. */
    readonly availabilityReason: 'third-party-registration-missing' | 'subscription-oauth-blocked' | 'discontinued' | 'sdk-adapter-required' | null;
    readonly status: 'signed-out' | 'starting' | 'pending' | 'connected' | 'cancelled' | 'expired' | 'needs-reauth' | 'error';
    /** Official authorization URL; contains no access or refresh token. */
    readonly authorizationUrl: string | null;
    /** RFC 8628 verification URI without a device credential in the URL. */
    readonly verificationUrl: string | null;
    /** RFC 8628 short user code; never the Host-only device code. */
    readonly userCode: string | null;
    /** One-time value the user must submit to the Host to finish a compatibility flow. */
    readonly inputPrompt: {
        readonly kind: 'authorization-code';
        readonly label: string;
        readonly placeholder: string | null;
    } | null;
    /** Plugin-local opaque attempt id used only for cancellation. */
    readonly attemptId: string | null;
    readonly expiresAt: number | null;
    /** Masked email or account suffix; never a complete account identifier. */
    readonly accountLabel: string | null;
    /** Stable allowlisted category; no upstream body, URL query, or credential text. */
    readonly errorCategory: AuthErrorCategory | null;
    readonly error: string | null;
}
/** One best-effort Codex subscription limit window. */
export interface CodexUsageWindowView {
    readonly id: 'primary' | 'secondary';
    readonly usedPercent: number;
    readonly remainingPercent: number;
    readonly windowSeconds: number | null;
    readonly resetAt: number | null;
}
/** Browser-safe Codex subscription usage fetched with the plugin-owned credential. */
export interface CodexUsageView {
    readonly status: 'available' | 'signed-out' | 'unavailable';
    readonly generatedAt: number;
    readonly bestEffort: true;
    readonly sourceUrl: string;
    readonly windows: readonly CodexUsageWindowView[];
    readonly error: string | null;
}
/** One quota window returned by a subscription Provider. */
export interface ProviderQuotaWindowView {
    readonly id: string;
    readonly label: string;
    readonly usedPercent: number;
    readonly remainingPercent: number;
    readonly windowSeconds: number | null;
    readonly resetAt: number | null;
}
/** Browser-safe best-effort quota summary fetched with a Host-only credential. */
export interface ProviderQuotaView {
    readonly provider: string;
    readonly status: 'available' | 'signed-out' | 'unavailable';
    readonly generatedAt: number;
    readonly bestEffort: true;
    readonly sourceUrl: string;
    readonly windows: readonly ProviderQuotaWindowView[];
    readonly error: string | null;
}
/** One vendor-published API or subscription-key configuration preset. */
export interface ProviderPlanPresetView {
    readonly id: string;
    readonly name: string;
    readonly method: 'plan-api-key' | 'api-key';
    readonly availability: 'available' | 'restricted';
    readonly sourceUrl: string;
    readonly availabilityNote: string;
    readonly provider: string;
    readonly baseURL: string;
    readonly api: ProviderApi;
    readonly models: readonly ProviderModelView[];
}
/** Write-only API-key request for one allowlisted Provider preset. */
export interface SavePlanProviderRequest {
    readonly presetId: string;
    readonly apiKey: string;
}
/** Provider Hub control-plane snapshot. */
export interface ProviderHubView {
    readonly generatedAt: number;
    readonly defaultSelection: {
        readonly provider: string;
        readonly model: string;
        readonly reasoningEffort?: string;
    };
    readonly providers: readonly ProviderConnectionView[];
}
/** Editable provider fields accepted by the Host. Secrets are write-only. */
export interface SaveProviderRequest {
    readonly provider: string;
    readonly displayName: string;
    readonly baseURL: string;
    readonly api?: ProviderApi;
    readonly apiKey?: string;
    readonly models: readonly {
        readonly id: string;
        readonly name?: string;
        readonly contextWindow?: number;
        readonly maxTokens?: number;
    }[];
    readonly headers?: Readonly<Record<string, string>>;
}
/** Result of a Host-side OpenAI-compatible model-list probe. */
export interface ProviderProbeView {
    readonly ok: boolean;
    readonly latencyMs: number;
    readonly models: readonly string[];
    readonly error: string | null;
}
/** User-maintained price row. */
export interface PriceOverrideRequest {
    readonly provider: string;
    readonly model: string;
    readonly currency: string;
    readonly sourceUrl: string;
    readonly updatedAt: string;
    readonly effectiveDate: string;
    readonly uncachedInputPerMillion?: number;
    readonly outputPerMillion?: number;
    readonly cacheReadPerMillion?: number;
    readonly cacheWritePerMillion?: number;
    readonly reasoningPerMillion?: number;
}
//# sourceMappingURL=types.d.ts.map