/** Vendor-published API and subscription-key presets shown by the Models action. */
import type { ProviderPlanPresetView } from './types.ts';
/** Allowlisted Provider presets whose endpoints and model IDs have first-party sources. */
export declare const PROVIDER_PLAN_PRESETS: readonly ProviderPlanPresetView[];
//# sourceMappingURL=provider-plans.d.ts.map