/** Host-side JSON response readers with an incremental byte ceiling. */
/**
 * Fetch one upstream resource without following redirects that could cross a credential origin.
 *
 * @param input Upstream request URL.
 * @param init Request metadata, including Host-only headers.
 * @param request Fetch implementation used by tests and the runtime.
 * @returns The first upstream response.
 */
export declare function fetchNoRedirect(input: RequestInfo | URL, init: RequestInit, request?: typeof fetch): Promise<Response>;
/**
 * Read a JSON response without buffering more than the configured byte limit.
 *
 * @param response Upstream response whose body is not yet consumed.
 * @param maxBytes Maximum accepted encoded response size.
 * @returns Parsed JSON, or `undefined` for an empty, oversized, or malformed body.
 */
export declare function readBoundedJson(response: Response, maxBytes: number): Promise<unknown>;
//# sourceMappingURL=bounded-json.d.ts.map