/** Provider operations and cross-session usage analytics over DSH-owned facts. */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type VisionFallbackConfig, type VisionFallbackView } from './vision-fallback.ts';
import type { AnalyticsQuery, AuthProviderView, CodexUsageView, ModelPriceView, PriceOverrideRequest, ProviderAnalyticsView, ProviderHubView, ProviderPlanPresetView, ProviderProbeView, ProviderQuotaView, SavePlanProviderRequest, SaveProviderRequest } from '../types.ts';
export type * from '../types.ts';
export { foldProviderAnalytics, outputPriceBandOf } from './fold.ts';
/** One configured catalog row before its source is attached. */
export interface ModelPriceConfig extends Omit<ModelPriceView, 'source'> {
}
/** AuthInOne settings and composition config. */
export interface Config {
    /** Version identity for the composition-owned price rows. */
    catalogVersion?: string;
    /** Auditable composition-owned model prices. Empty means every cost is unknown until overridden. */
    prices?: ModelPriceConfig[];
    /** User-owned rows replacing catalog rows for an exact provider/model pair. */
    overrides?: ModelPriceConfig[];
    /** Optional image-description route used only for explicitly text-only main models. */
    visionFallback?: VisionFallbackConfig;
}
/** Runtime validator for plugin config and its settings namespace. */
export declare const Config: z<Config>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Provider management and cross-session analytics service. */
        authInOne: AuthInOneService;
    }
}
/** Remote service using DSH session logs, adapters, settings, and credentials as authorities. */
export declare class AuthInOneService extends TypertRemoteService {
    static inject: string[];
    static Config: z<Config>;
    private source;
    private readonly auth;
    private readonly kimiAuth;
    private readonly authRuntimes;
    private readonly authReady;
    constructor(ctx: Context, config?: Config);
    private descriptors;
    private authRuntime;
    private prices;
    private logs;
    /** Read cross-session provider usage from live and persisted DSH logs. */
    analytics(query: AnalyticsQuery, signal: AbortSignal): Promise<ProviderAnalyticsView>;
    /** Read provider routes, connection state, models, and the future-Agent default. */
    providers(): Promise<ProviderHubView>;
    /** List browser-safe official account-login states. */
    authProviders(): Promise<readonly AuthProviderView[]>;
    /** Read the allowlisted vendor API and subscription-key presets. */
    planProviders(): readonly ProviderPlanPresetView[];
    /** Read OpenAI Codex subscription windows without exposing the bearer credential. */
    codexUsage(signal: AbortSignal): Promise<CodexUsageView>;
    /** Read all implemented subscription quota windows without exposing credentials. */
    providerQuotas(signal: AbortSignal): Promise<readonly ProviderQuotaView[]>;
    /** Begin the official OpenAI Codex browser OAuth flow on the Host. */
    startAuth(provider: string): Promise<AuthProviderView>;
    /** Cancel one plugin-local OAuth attempt without affecting stored credentials. */
    cancelAuth(provider: string, attemptId: string): Promise<AuthProviderView>;
    /** Submit a one-time authorization value to the matching Host transaction. */
    submitAuth(provider: string, attemptId: string, value: string): Promise<AuthProviderView>;
    /** Sign out and remove one Host-only account credential. */
    logoutAuth(provider: string): Promise<AuthProviderView>;
    /** Save an OpenAI-compatible route or edit the official DeepSeek route. */
    saveProvider(request: SaveProviderRequest): Promise<void>;
    /** Save one allowlisted vendor preset while keeping its API key write-only. */
    savePlanProvider(request: SavePlanProviderRequest): Promise<void>;
    /** Probe the configured OpenAI-compatible `/models` endpoint without exposing credentials. */
    probe(provider: string, signal: AbortSignal): Promise<ProviderProbeView>;
    /** Save the model selection used for future Agents. */
    saveDefault(provider: string, model: string): Promise<void>;
    /** Read the optional fallback and routes whose adapters explicitly declare image input. */
    visionFallback(): Promise<VisionFallbackView>;
    /** Save the fallback without ever accepting a credential or image payload. */
    saveVisionFallback(request: VisionFallbackConfig): Promise<void>;
    /** Add or replace one durable user-owned price row. */
    savePriceOverride(request: PriceOverrideRequest): Promise<void>;
}
export default AuthInOneService;
//# sourceMappingURL=index.d.ts.map