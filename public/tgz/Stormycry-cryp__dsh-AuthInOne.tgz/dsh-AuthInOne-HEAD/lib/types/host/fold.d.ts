/** Pure session-log fold for cross-session provider analytics. */
import type { SessionEvent, SessionHeader } from '@deepseek-ai/dsh-session';
import type { AnalyticsQuery, ModelPriceView, OutputPriceBand, ProviderAnalyticsView } from '../types.ts';
/** One complete logical session supplied by live memory or persistence. */
export interface SessionLogInput {
    readonly header: SessionHeader;
    readonly events: readonly SessionEvent[];
}
/** Classify one catalog row by its USD output price per million tokens. */
export declare function outputPriceBandOf(price: ModelPriceView | undefined): Exclude<OutputPriceBand, 'all'>;
/** Fold complete logical logs into a detached analytics view. */
export declare function foldProviderAnalytics(logs: readonly SessionLogInput[], query: AnalyticsQuery, prices: readonly ModelPriceView[], catalogVersion: string, now?: number): ProviderAnalyticsView;
//# sourceMappingURL=fold.d.ts.map