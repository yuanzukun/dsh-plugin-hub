/** DSH-native adapter for Command Code's account-scoped generate endpoint. */
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
/** Command Code model discovery and NDJSON streaming with a Host token resolver. */
export declare class CommandCodeLlmAdapter extends LlmAdapter {
    private readonly accessToken;
    private readonly request;
    private models;
    constructor(accessToken: (signal?: AbortSignal) => Promise<string>, request?: typeof fetch);
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    listModels(_provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmModelInfo & {
        context: {
            contextWindow: number;
        };
    }>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
//# sourceMappingURL=command-code-adapter.d.ts.map