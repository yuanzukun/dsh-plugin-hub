/** OAuth credential persistence and refresh coordination over DSH credentials. */
import type { Context } from '@deepseek-ai/cordis';
import { type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts';
/** Store status safe for Host state projection after identity masking. */
export interface AuthCredentialStatus {
    readonly connected: boolean;
    readonly needsReauth: boolean;
    readonly email?: string;
    readonly accountId?: string;
}
/** Serializes DSH credential writes and deduplicates refresh for one Provider. */
export declare class DshOAuthCredentialStore {
    private readonly ctx;
    private mutation;
    private refreshFlight;
    private readonly ref;
    constructor(ctx: Context, name?: string);
    read(): Promise<StoredOAuthCredential | undefined>;
    private enqueue;
    write(credential: StoredOAuthCredential): Promise<void>;
    delete(): Promise<void>;
    status(): Promise<AuthCredentialStatus>;
    /** Return a fresh access token, rotating the stored refresh token at most once per generation. */
    accessToken(adapter: AuthProviderAdapter, signal?: AbortSignal): Promise<string>;
}
//# sourceMappingURL=auth-store.d.ts.map