/** Image-description fallback for text-only main-model requests. */
import type { Context } from '@deepseek-ai/cordis';
import { type TokenUsage } from '@deepseek-ai/dsh-llm';
/** Persisted configuration for the optional vision fallback. */
export interface VisionFallbackConfig {
    enabled?: boolean;
    provider?: string;
    model?: string;
    maxOutputTokens?: number;
    timeoutMs?: number;
}
/** Browser-safe resolved configuration and selectable vision routes. */
export interface VisionFallbackView {
    readonly enabled: boolean;
    readonly provider: string;
    readonly model: string;
    readonly maxOutputTokens: number;
    readonly timeoutMs: number;
    readonly selectionAvailable: boolean;
    readonly routes: readonly {
        readonly provider: string;
        readonly providerName: string;
        readonly model: string;
        readonly modelName: string;
        readonly accessType: 'account-auth' | 'api' | 'custom-api';
        readonly accountLabel: string | null;
    }[];
}
/** Redacted Provider-instance facts used to filter and label vision candidates. */
export interface VisionProviderInstance {
    readonly id: string;
    readonly name: string;
    readonly active: boolean;
    readonly configured: boolean;
    readonly credentialConfigured: boolean | null;
    readonly accessType: 'account-auth' | 'api' | 'custom-api';
    readonly accountLabel: string | null;
}
interface VisionRoute {
    readonly provider: string;
    readonly model: string;
}
interface VisionRequestSource {
    readonly kind: 'auth-in-one-vision-request';
    readonly form: 'notice';
    readonly summary: string;
    readonly requestId: string;
    readonly sourceMessageId: string;
    readonly route: VisionRoute;
    readonly promptVersion: 1;
    readonly maxOutputTokens: number;
}
interface VisionResultSource {
    readonly kind: 'auth-in-one-vision-result';
    readonly form: 'notice';
    readonly summary: string;
    readonly requestId: string;
    readonly sourceMessageId: string;
    readonly route: VisionRoute;
    readonly status: 'success' | 'error';
    readonly usage?: TokenUsage;
    readonly errorCode?: string;
}
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'auth-in-one-vision-request': VisionRequestSource;
        'auth-in-one-vision-result': VisionResultSource;
    }
}
/** Resolve optional fields into bounded runtime policy. */
export declare function resolveVisionFallbackConfig(config: VisionFallbackConfig | undefined): Required<VisionFallbackConfig>;
/** List exact routes whose adapter explicitly declares image input. */
export declare function listVisionRoutes(ctx: Context, instances?: readonly VisionProviderInstance[]): Promise<VisionFallbackView['routes']>;
/** Install the request middleware without changing DSH's agent loop. */
export declare function installVisionFallback(ctx: Context, config: () => VisionFallbackConfig | undefined): void;
export {};
//# sourceMappingURL=vision-fallback.d.ts.map