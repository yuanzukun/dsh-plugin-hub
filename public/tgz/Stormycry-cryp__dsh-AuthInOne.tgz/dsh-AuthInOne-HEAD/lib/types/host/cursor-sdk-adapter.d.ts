/** DSH adapter over Cursor's published SDK using only the plugin-owned account credential. */
import { JsonlLocalAgentStore, type SDKMessage } from '@cursor/sdk';
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
/** Narrow Cursor SDK run surface used by the adapter and its protocol tests. */
export interface CursorRunLike {
    stream(): AsyncGenerator<SDKMessage, void>;
    cancel(): Promise<void>;
}
/** Narrow Cursor SDK agent surface used by the adapter and its protocol tests. */
export interface CursorAgentLike {
    send(message: string, options: {
        model: {
            id: string;
        };
        local: {
            customTools: Record<string, {
                description?: string;
                inputSchema?: Record<string, unknown>;
                execute: (args: Record<string, unknown>) => Promise<string>;
            }>;
        };
    }): Promise<CursorRunLike>;
    close(): void;
}
/** Injectable vendor SDK surface; production binds it to the published package. */
export interface CursorSdkFacade {
    listModels(apiKey: string): Promise<readonly {
        id: string;
        displayName: string;
    }[]>;
    createAgent(options: {
        apiKey: string;
        model: {
            id: string;
        };
        local: {
            cwd: string;
            store: JsonlLocalAgentStore;
            settingSources: [];
            sandboxOptions: {
                enabled: true;
            };
            customTools: Record<string, {
                description?: string;
                inputSchema?: Record<string, unknown>;
                execute: (args: Record<string, unknown>) => Promise<string>;
            }>;
        };
    }): Promise<CursorAgentLike>;
}
/** Experimental Cursor account route backed by the vendor SDK and an isolated temporary workspace. */
export declare class CursorSdkLlmAdapter extends LlmAdapter {
    private readonly accessToken;
    private readonly sdk;
    private models;
    constructor(accessToken: (signal?: AbortSignal) => Promise<string>, sdk?: CursorSdkFacade);
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmModelInfo & {
        context: {
            contextWindow: number;
        };
    }>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
//# sourceMappingURL=cursor-sdk-adapter.d.ts.map