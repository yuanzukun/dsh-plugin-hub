/** Best-effort Kimi Code quota projection with no credential in its result. */
import type { ProviderQuotaView, ProviderQuotaWindowView } from '../types.ts';
export declare const KIMI_USAGE_SOURCE = "https://api.kimi.com/coding/v1/usages";
/** Parse only recognized Kimi windows; unknown fields never become invented quota. */
export declare function parseKimiUsage(value: unknown): readonly ProviderQuotaWindowView[];
/** Fetch Kimi quota without returning or logging the bearer token. */
export declare function fetchKimiUsage(accessToken: string, signal?: AbortSignal, request?: typeof fetch): Promise<ProviderQuotaView>;
//# sourceMappingURL=kimi-usage.d.ts.map