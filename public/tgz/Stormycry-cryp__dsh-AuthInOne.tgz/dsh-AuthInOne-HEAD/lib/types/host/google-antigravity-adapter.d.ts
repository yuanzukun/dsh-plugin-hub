/** DSH-native Google Antigravity compatibility adapter over Cloud Code Assist SSE. */
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { StoredOAuthCredential } from './auth-protocol.ts';
/** Antigravity account models using only the Host-owned OAuth credential and project id. */
export declare class GoogleAntigravityLlmAdapter extends LlmAdapter {
    private readonly accessToken;
    private readonly credential;
    private readonly request;
    constructor(accessToken: (signal?: AbortSignal) => Promise<string>, credential: () => Promise<StoredOAuthCredential | undefined>, request?: typeof fetch);
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmModelInfo & {
        context: {
            contextWindow: number;
        };
    }>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
//# sourceMappingURL=google-antigravity-adapter.d.ts.map