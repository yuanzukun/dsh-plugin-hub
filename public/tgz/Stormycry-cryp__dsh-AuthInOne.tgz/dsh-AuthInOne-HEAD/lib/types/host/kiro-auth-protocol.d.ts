/** Host-only Kiro Builder ID device flow over the public AWS SSO OIDC protocol. */
import { type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts';
export declare const KIRO_AUTH_SOURCE = "https://kiro.dev/docs/cli/authentication/";
export interface KiroDeviceAuthOptions {
    readonly oidcEndpoint?: string;
    readonly fetch?: typeof fetch;
    readonly now?: () => number;
    readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>;
    readonly clientName?: string;
}
/** Independent device transaction; it never inspects Kiro CLI files or an existing session. */
export declare class KiroDeviceCompatibilityAdapter implements AuthProviderAdapter {
    readonly id = "kiro";
    readonly name = "Kiro";
    private readonly oidcEndpoint;
    private readonly request;
    private readonly now;
    private readonly pause;
    private readonly clientName;
    constructor(options?: KiroDeviceAuthOptions);
    private post;
    private credential;
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>;
    revoke(_credential: StoredOAuthCredential): Promise<void>;
}
//# sourceMappingURL=kiro-auth-protocol.d.ts.map