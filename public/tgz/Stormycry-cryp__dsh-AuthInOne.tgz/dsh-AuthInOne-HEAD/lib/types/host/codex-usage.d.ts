/** Best-effort OpenAI Codex subscription-limit projection. */
import type { CodexUsageView } from '../types.ts';
export declare const CODEX_USAGE_SOURCE = "https://chatgpt.com/backend-api/codex/usage";
interface CodexUsageOptions {
    readonly fetch?: typeof fetch;
    readonly sourceUrl?: string;
    readonly timeoutMs?: number;
    readonly now?: () => number;
}
/** Fetch public quota percentages without projecting the bearer credential. */
export declare function fetchCodexUsage(accessToken: string, accountId: string | undefined, signal?: AbortSignal, options?: CodexUsageOptions): Promise<CodexUsageView>;
export {};
//# sourceMappingURL=codex-usage.d.ts.map