/** Host-only OAuth protocol adapter for the official OpenAI Codex browser flow. */
import type { AuthErrorCategory } from '../types.ts';
/** Error that carries only an allowlisted category and fixed public message. */
export declare class AuthProtocolError extends Error {
    readonly category: AuthErrorCategory;
    constructor(category: AuthErrorCategory);
}
/** Host-only credential representation persisted through DSH credentials. */
export interface StoredOAuthCredential {
    readonly version: 1;
    readonly accessToken: string;
    readonly refreshToken: string;
    readonly expiresAt: number;
    readonly accountId?: string;
    readonly email?: string;
    /** Provider-specific Host-only request metadata; never projected through Remote DTOs. */
    readonly providerData?: Readonly<Record<string, string | number | boolean | readonly string[]>>;
    readonly needsReauth?: true;
}
/** Started login whose completion settles after the loopback callback. */
export interface AuthLoginHandle {
    readonly authorizationUrl: string;
    readonly verificationUrl?: string;
    readonly userCode?: string;
    readonly inputPrompt?: {
        readonly kind: 'authorization-code';
        readonly label: string;
        readonly placeholder?: string;
    };
    readonly expiresAt: number;
    readonly completion: Promise<StoredOAuthCredential>;
    submit?(value: string): void;
    cancel(): void;
}
/** Host-only protocol operations implemented by an Auth Provider. */
export interface AuthProviderAdapter {
    readonly id: string;
    readonly name: string;
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    refresh(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>;
    revoke(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<void>;
}
export interface OpenAICodexOAuthOptions {
    readonly issuer?: string;
    readonly clientId?: string;
    readonly ports?: readonly number[];
    readonly timeoutMs?: number;
    readonly requestTimeoutMs?: number;
    readonly fetch?: typeof fetch;
    readonly now?: () => number;
}
/** Official OpenAI Codex OAuth browser adapter with Host-owned state and PKCE. */
export declare class OpenAICodexOAuthAdapter implements AuthProviderAdapter {
    readonly id = "openai-codex";
    readonly name = "OpenAI Codex";
    private readonly issuer;
    private readonly clientId;
    private readonly ports;
    private readonly timeoutMs;
    private readonly requestTimeoutMs;
    private readonly request;
    private readonly now;
    constructor(options?: OpenAICodexOAuthOptions);
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    private exchange;
    refresh(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>;
    revoke(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<void>;
}
/** Stable digest used for compare-and-swap credential updates. */
export declare function credentialGeneration(credential: StoredOAuthCredential): string;
//# sourceMappingURL=auth-protocol.d.ts.map