/** Host-only compatibility login protocols that are not supplied by pi-ai. */
import { type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts';
/** Options used by Cursor mock-server tests. */
export interface CursorAuthOptions {
    readonly loginUrl?: string;
    readonly pollUrl?: string;
    readonly refreshUrl?: string;
    readonly fetch?: typeof fetch;
    readonly now?: () => number;
    readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>;
    readonly initialPollMs?: number;
    readonly maxPolls?: number;
}
/** Cursor's standalone PKCE poll login with DSH-owned persistence. */
export declare class CursorCompatibilityAdapter implements AuthProviderAdapter {
    readonly id = "cursor";
    readonly name = "Cursor";
    private readonly loginUrl;
    private readonly pollUrl;
    private readonly refreshUrl;
    private readonly request;
    private readonly now;
    private readonly pause;
    private readonly initialPollMs;
    private readonly maxPolls;
    constructor(options?: CursorAuthOptions);
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>;
    revoke(_credential: StoredOAuthCredential): Promise<void>;
}
/** Options used by Command Code callback mock tests. */
export interface CommandCodeAuthOptions {
    readonly studioUrl?: string;
    readonly callbackPorts?: readonly number[];
    readonly timeoutMs?: number;
    readonly now?: () => number;
}
/** Command Code's account callback login without reading a local CLI credential. */
export declare class CommandCodeCompatibilityAdapter implements AuthProviderAdapter {
    readonly id = "command-code";
    readonly name = "Command Code";
    private readonly studioUrl;
    private readonly callbackPorts;
    private readonly timeoutMs;
    private readonly now;
    constructor(options?: CommandCodeAuthOptions);
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    refresh(previous: StoredOAuthCredential): Promise<StoredOAuthCredential>;
    revoke(_credential: StoredOAuthCredential): Promise<void>;
}
//# sourceMappingURL=compat-auth-protocols.d.ts.map