export interface CompatOwnerFingerprint {
    packageName: string;
    version: string;
    clientSha256: string;
}
export declare const SUPPORTED_COMPAT_OWNERS: readonly CompatOwnerFingerprint[];
/** Validate independently discovered facts; exported for duplicate/new-host tests. */
export declare function assertSupportedCompatOwners(actual: readonly CompatOwnerFingerprint[]): void;
/** Resolve the active host's owner artifacts from the installed plugin location. */
export declare function discoverCompatOwners(anchor?: string | URL): CompatOwnerFingerprint[];
/** Fail before the service creates state when the static owner override is unsafe. */
export declare function assertCompatibleHost(): void;
/** Validate owner artifacts from a known DSH package-resolution anchor. */
export declare function assertCompatibleHostAt(anchor: string | URL): void;
//# sourceMappingURL=compat-host.d.ts.map