/** Host-only account login coordination and DSH adapter activation. */
import type { Context } from '@deepseek-ai/cordis';
import type { LlmAdapter } from '@deepseek-ai/dsh-llm';
import { type Provider } from '@earendil-works/pi-ai';
import type { AuthProviderView, CodexUsageView, ProviderQuotaView } from '../types.ts';
import { AuthProtocolError, type AuthProviderAdapter } from './auth-protocol.ts';
export declare const OPENAI_CODEX_PROVIDER = "openai-codex";
export declare const KIMI_CODE_PROVIDER = "kimi-code";
export declare const XAI_PROVIDER = "xai";
export declare const ANTHROPIC_PROVIDER = "anthropic";
export declare const GITHUB_COPILOT_PROVIDER = "github-copilot";
export declare const COMMAND_CODE_PROVIDER = "command-code";
export declare const CURSOR_PROVIDER = "cursor";
export declare const GOOGLE_ANTIGRAVITY_PROVIDER = "google-antigravity";
export declare const KIRO_PROVIDER = "kiro";
/** Official-source parity entries that deliberately fail closed in this release. */
export declare const UNAVAILABLE_AUTH_PROVIDERS: readonly AuthProviderView[];
/** Minimal login engine surface, injectable for state-machine tests. */
export interface CodexAuthEngine {
    status(): Promise<{
        connected: boolean;
        needsReauth: boolean;
        accountLabel: string | null;
    }>;
    login(signal: AbortSignal, onReady: (ready: {
        authorizationUrl: string;
        verificationUrl?: string;
        userCode?: string;
        inputPrompt?: {
            kind: 'authorization-code';
            label: string;
            placeholder?: string;
        };
        expiresAt: number;
    }) => void): Promise<string | null>;
    submit?(value: string): void;
    logout(signal?: AbortSignal): Promise<{
        revocationError?: AuthProtocolError;
    }>;
}
/** Public identity and risk label for one Host-owned Auth transaction. */
export interface AuthCoordinatorDescriptor {
    readonly id: string;
    readonly name: string;
    readonly method: AuthProviderView['method'];
    readonly stability: AuthProviderView['stability'];
    readonly sourceUrl: string;
    readonly official?: boolean;
}
/** Browser OAuth state machine that never exposes an OAuth credential. */
export declare class CodexAuthCoordinator {
    private readonly engine;
    private readonly onConnected;
    private readonly onDisconnected;
    private readonly descriptor;
    private attempt;
    private state;
    constructor(engine: CodexAuthEngine, onConnected: () => void, onDisconnected: () => void, descriptor?: AuthCoordinatorDescriptor);
    private view;
    snapshot(): AuthProviderView;
    private failure;
    synchronize(): Promise<AuthProviderView>;
    start(): Promise<AuthProviderView>;
    cancel(attemptId: string): AuthProviderView;
    /** Submit one bounded one-time authorization value to the active Host transaction. */
    submit(attemptId: string, value: string): AuthProviderView;
    logout(): Promise<AuthProviderView>;
}
/** Runtime bridge: the plugin owns OAuth while pi-ai supplies Codex transport and model metadata. */
export declare class OpenAICodexAuthRuntime {
    readonly coordinator: CodexAuthCoordinator;
    readonly models: readonly {
        id: string;
        name: string;
    }[];
    private readonly adapter;
    private readonly credentials;
    private registration;
    private disposed;
    constructor(ctx: Context, oauth?: AuthProviderAdapter);
    private deactivate;
    /** Read best-effort subscription windows with the Host-only credential. */
    usage(signal?: AbortSignal): Promise<CodexUsageView>;
    dispose(): void;
}
/** Kimi Code device login, DSH credential lifecycle, and managed model route. */
export declare class KimiCodeAuthRuntime {
    readonly coordinator: CodexAuthCoordinator;
    readonly models: {
        id: string;
        name: string;
    }[];
    private readonly adapter;
    private readonly credentials;
    private registration;
    private disposed;
    constructor(ctx: Context, oauth?: AuthProviderAdapter);
    private deactivate;
    /** Read best-effort Kimi Code subscription windows with the Host-only credential. */
    quota(signal?: AbortSignal): Promise<ProviderQuotaView>;
    dispose(): void;
}
/** Shared DSH credential and model lifecycle for installed pi-ai OAuth protocols. */
export declare class SubscriptionAuthRuntime {
    readonly coordinator: CodexAuthCoordinator;
    readonly models: readonly {
        id: string;
        name: string;
    }[];
    private readonly adapter;
    private readonly credentials;
    private registration;
    private disposed;
    constructor(ctx: Context, options: {
        readonly descriptor: AuthCoordinatorDescriptor;
        readonly credentialRef: string;
        readonly adapter?: AuthProviderAdapter;
        readonly piProvider?: Provider;
        readonly createTransport?: (accessToken: (signal?: AbortSignal) => Promise<string>, credential: () => Promise<import('./auth-protocol.ts').StoredOAuthCredential | undefined>) => LlmAdapter;
    });
    private deactivate;
    /** Resolve this Provider's fresh Host-only access token for a plugin-owned auxiliary request. */
    accessToken(signal?: AbortSignal): Promise<string>;
    /** Read Provider-specific Host-only metadata for a plugin-owned auxiliary request. */
    credential(): Promise<import('./auth-protocol.ts').StoredOAuthCredential | undefined>;
    dispose(): void;
}
/** Create compatibility runtimes with one common DSH transaction and credential lifecycle. */
export declare function createCompatibilityAuthRuntimes(ctx: Context): readonly SubscriptionAuthRuntime[];
//# sourceMappingURL=auth.d.ts.map