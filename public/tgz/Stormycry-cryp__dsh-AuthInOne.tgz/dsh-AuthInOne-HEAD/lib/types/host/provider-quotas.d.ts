/** Best-effort subscription quota readers for compatibility Auth Providers. */
import type { ProviderQuotaView } from '../types.ts';
import type { StoredOAuthCredential } from './auth-protocol.ts';
/** Fetch xAI weekly credits, falling back to the legacy monthly pool. */
export declare function fetchXaiQuota(token: string, signal?: AbortSignal, request?: typeof fetch): Promise<ProviderQuotaView>;
/** Fetch Anthropic OAuth usage windows. */
export declare function fetchAnthropicQuota(token: string, signal?: AbortSignal, request?: typeof fetch): Promise<ProviderQuotaView>;
/** Fetch Cursor included usage from the same API2 account host. */
export declare function fetchCursorQuota(token: string, signal?: AbortSignal, request?: typeof fetch): Promise<ProviderQuotaView>;
/** Fetch Antigravity quota embedded in the available-model response. */
export declare function fetchAntigravityQuota(token: string, credential: StoredOAuthCredential, signal?: AbortSignal, request?: typeof fetch): Promise<ProviderQuotaView>;
//# sourceMappingURL=provider-quotas.d.ts.map