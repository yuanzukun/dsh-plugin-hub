/** Minimal DSH-native Kiro subscription transport over AWS event streams. */
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { StoredOAuthCredential } from './auth-protocol.ts';
/** Experimental Kiro CLI-wire adapter using only the credential created by this plugin. */
export declare class KiroLlmAdapter extends LlmAdapter {
    private readonly accessToken;
    private readonly credential;
    private readonly request;
    constructor(accessToken: (signal?: AbortSignal) => Promise<string>, credential: () => Promise<StoredOAuthCredential | undefined>, request?: typeof fetch);
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmModelInfo & {
        context: {
            contextWindow: number;
        };
    }>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
//# sourceMappingURL=kiro-llm-adapter.d.ts.map