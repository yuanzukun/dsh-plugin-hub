import type { AuthProviderView } from '../types.ts';
/** Facts that distinguish one configured Provider instance from an Auth catalog entry. */
export interface ProviderProjectionFacts {
    readonly provider: string;
    readonly hasLiveRoute: boolean;
    readonly hasProfile: boolean;
    readonly authStatus: AuthProviderView['status'] | null;
}
/** Return whether Models should expose a real Provider instance. */
export declare function shouldProjectProviderConnection(facts: ProviderProjectionFacts): boolean;
/** Return whether an Auth state represents a stored account instance rather than a catalog transaction. */
export declare function isAuthProviderInstance(status: AuthProviderView['status']): boolean;
//# sourceMappingURL=provider-projection.d.ts.map