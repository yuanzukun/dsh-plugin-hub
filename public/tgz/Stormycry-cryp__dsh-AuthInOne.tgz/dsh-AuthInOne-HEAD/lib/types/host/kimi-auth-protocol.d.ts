/** Host-only RFC 8628 adapter compatible with the Kimi Code device flow. */
import { type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts';
export declare const KIMI_AUTH_SOURCE = "https://github.com/MoonshotAI/kimi-code/blob/main/docs/en/reference/kimi-command.md#kimi-login";
/** Overrides for a local mock authorization server and deterministic polling tests. */
export interface KimiCodeDeviceOptions {
    readonly oauthHost?: string;
    readonly clientId?: string;
    readonly fetch?: typeof fetch;
    readonly now?: () => number;
    readonly requestTimeoutMs?: number;
    readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>;
    readonly deviceId?: string;
}
/** Kimi Code device authorization, polling, and refresh; logout is local because no revoke endpoint is published. */
export declare class KimiCodeDeviceAdapter implements AuthProviderAdapter {
    readonly id = "kimi-code";
    readonly name = "Kimi Code";
    private readonly oauthHost;
    private readonly clientId;
    private readonly request;
    private readonly now;
    private readonly requestTimeoutMs;
    private readonly wait;
    private readonly headers;
    constructor(options?: KimiCodeDeviceOptions);
    private post;
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>;
    revoke(_credential: StoredOAuthCredential, _signal?: AbortSignal): Promise<void>;
}
//# sourceMappingURL=kimi-auth-protocol.d.ts.map