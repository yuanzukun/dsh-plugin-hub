/** Host-only Google Antigravity compatibility OAuth and project discovery. */
import { type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts';
export declare const GOOGLE_ANTIGRAVITY_AUTH_SOURCE = "https://antigravity.google/docs";
export interface GoogleAntigravityAuthOptions {
    readonly clientId?: string;
    readonly clientSecret?: string;
    readonly authorizationEndpoint?: string;
    readonly tokenEndpoint?: string;
    readonly cloudCodeEndpoint?: string;
    readonly dailyCloudCodeEndpoint?: string;
    readonly callbackPort?: number;
    readonly fetch?: typeof fetch;
    readonly now?: () => number;
}
/** Antigravity login uses the desktop client's published OAuth identity but stores only in DSH. */
export declare class GoogleAntigravityCompatibilityAdapter implements AuthProviderAdapter {
    readonly id = "google-antigravity";
    readonly name = "Google Antigravity";
    private readonly clientId;
    private readonly clientSecret;
    private readonly authorizationEndpoint;
    private readonly tokenEndpoint;
    private readonly cloudCodeEndpoint;
    private readonly dailyCloudCodeEndpoint;
    private readonly callbackPort;
    private readonly request;
    private readonly now;
    constructor(options?: GoogleAntigravityAuthOptions);
    private tokens;
    private discoverProject;
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    refresh(previous: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>;
    revoke(_credential: StoredOAuthCredential): Promise<void>;
}
//# sourceMappingURL=google-antigravity-auth.d.ts.map