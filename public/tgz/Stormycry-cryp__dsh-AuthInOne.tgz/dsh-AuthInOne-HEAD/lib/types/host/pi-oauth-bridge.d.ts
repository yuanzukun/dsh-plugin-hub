/** DSH-owned transaction wrapper around the installed pi-ai OAuth protocol implementations. */
import { type AuthLoginHandle, type AuthProviderAdapter, type StoredOAuthCredential } from './auth-protocol.ts';
interface BridgeOAuthCredential {
    readonly type: 'oauth';
    readonly access: string;
    readonly refresh: string;
    readonly expires: number;
    readonly [key: string]: unknown;
}
type BridgeAuthEvent = {
    readonly type: 'auth_url';
    readonly url: string;
    readonly instructions?: string;
} | {
    readonly type: 'device_code';
    readonly userCode: string;
    readonly verificationUri: string;
    readonly intervalSeconds?: number;
    readonly expiresInSeconds?: number;
} | {
    readonly type: 'info' | 'progress';
    readonly message: string;
};
type BridgeAuthPrompt = {
    readonly signal?: AbortSignal;
} & ({
    readonly type: 'text' | 'secret' | 'manual_code';
    readonly message: string;
    readonly placeholder?: string;
} | {
    readonly type: 'select';
    readonly message: string;
    readonly options: readonly {
        readonly id: string;
        readonly label: string;
    }[];
});
/** Structural subset of pi-ai's OAuth flow used without delegating storage. */
export interface BridgeOAuthAuth {
    login(interaction: {
        readonly signal?: AbortSignal;
        prompt(prompt: BridgeAuthPrompt): Promise<string>;
        notify(event: BridgeAuthEvent): void;
    }): Promise<BridgeOAuthCredential>;
    refresh(credential: BridgeOAuthCredential, signal?: AbortSignal): Promise<BridgeOAuthCredential>;
}
/** Converts one pi-ai protocol flow into the plugin's Host-only adapter contract. */
export declare class PiOAuthBridgeAdapter implements AuthProviderAdapter {
    readonly id: string;
    readonly name: string;
    private readonly oauth;
    constructor(id: string, name: string, oauth: BridgeOAuthAuth);
    start(signal?: AbortSignal): Promise<AuthLoginHandle>;
    refresh(credential: StoredOAuthCredential, signal?: AbortSignal): Promise<StoredOAuthCredential>;
    revoke(_credential: StoredOAuthCredential, _signal?: AbortSignal): Promise<void>;
}
export {};
//# sourceMappingURL=pi-oauth-bridge.d.ts.map