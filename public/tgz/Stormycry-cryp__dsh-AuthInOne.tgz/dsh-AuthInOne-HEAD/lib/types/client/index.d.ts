/** AuthInOne settings contributions and package-owned Remote mount. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type AuthInOneLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.authInOne': AuthInOneLocaleKey;
    }
    interface SlotMap {
        'settings.models.insights': {
            kind: 'single';
            scope: 'root';
            owner: {
                children?: never;
            };
        };
    }
}
/** Platform services required before the browser half activates. */
export declare const inject: string[];
/** Mount the package Remote and register Models and Usage surfaces. */
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map