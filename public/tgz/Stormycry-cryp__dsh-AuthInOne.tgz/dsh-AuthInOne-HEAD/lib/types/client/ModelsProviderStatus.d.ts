import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ProviderHubView, ProviderProbeView } from '../types.ts';
/** Host operations consumed by the Models-page enhancement. */
export interface ModelsProviderStatusInjected {
    loadProviders: () => Promise<ProviderHubView>;
    probe: (provider: string) => Promise<ProviderProbeView>;
    saveDefault: (provider: string, model: string) => Promise<void>;
}
export type ModelsProviderStatusProps = PropsRuntime<'settings.models.insights'> & PropsLocale<'settings.authInOne'> & InjectFace<ModelsProviderStatusInjected>;
/** Compact Host facts and operations placed above the native provider cards. */
export declare function ModelsProviderStatus({ loadProviders, probe, saveDefault, t }: ModelsProviderStatusProps): ReactNode;
//# sourceMappingURL=ModelsProviderStatus.d.ts.map