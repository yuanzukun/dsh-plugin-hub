import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { DailyActivityView, InsightsRange, ProviderAnalyticsView } from '../types.ts';
export interface UsageSectionInjected {
    analytics: (range: InsightsRange) => Promise<ProviderAnalyticsView>;
}
export type UsageSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.authInOne'> & InjectFace<UsageSectionInjected>;
type ActivityMode = 'daily' | 'weekly' | 'cumulative';
export declare function activitySeries(activity: readonly DailyActivityView[], mode: ActivityMode): DailyActivityView[];
/** Full cross-session Usage page registered beside Models in Settings. */
export declare function UsageSection({ analytics, t }: UsageSectionProps): ReactNode;
export {};
//# sourceMappingURL=UsageSection.d.ts.map