import { z } from 'zod';
export declare const TYPERT_REMOTE: {
    package: string;
    descriptors: ({
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodObject<{
                    startTime: z.ZodReadonly<z.ZodNumber>;
                    endTimeExclusive: z.ZodReadonly<z.ZodNumber>;
                    timeZone: z.ZodReadonly<z.ZodString>;
                    provider: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                    outputPriceBand: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"all">, z.ZodLiteral<"0-1">, z.ZodLiteral<"1-5">, z.ZodLiteral<"5-15">, z.ZodLiteral<"15-plus">, z.ZodLiteral<"unpriced">]>>;
                }, z.core.$strip>;
            };
        }[];
        cancellation: {
            parameter: string;
        };
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                generatedAt: z.ZodReadonly<z.ZodNumber>;
                query: z.ZodReadonly<z.ZodObject<{
                    startTime: z.ZodReadonly<z.ZodNumber>;
                    endTimeExclusive: z.ZodReadonly<z.ZodNumber>;
                    timeZone: z.ZodReadonly<z.ZodString>;
                    provider: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                    outputPriceBand: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"all">, z.ZodLiteral<"0-1">, z.ZodLiteral<"1-5">, z.ZodLiteral<"5-15">, z.ZodLiteral<"15-plus">, z.ZodLiteral<"unpriced">]>>;
                }, z.core.$strip>>;
                kpis: z.ZodReadonly<z.ZodObject<{
                    calls: z.ZodReadonly<z.ZodNumber>;
                    sessions: z.ZodReadonly<z.ZodNumber>;
                    totalTokens: z.ZodReadonly<z.ZodNumber>;
                    peakDailyTokens: z.ZodReadonly<z.ZodNumber>;
                    longestSessionMs: z.ZodReadonly<z.ZodNumber>;
                    currentStreakDays: z.ZodReadonly<z.ZodNumber>;
                    longestStreakDays: z.ZodReadonly<z.ZodNumber>;
                }, z.core.$strip>>;
                usage: z.ZodReadonly<z.ZodObject<{
                    uncachedInputTokens: z.ZodReadonly<z.ZodNumber>;
                    outputTokens: z.ZodReadonly<z.ZodNumber>;
                    cacheReadTokens: z.ZodReadonly<z.ZodNumber>;
                    cacheWriteTokens: z.ZodReadonly<z.ZodNumber>;
                    reasoningTokens: z.ZodReadonly<z.ZodNumber>;
                    callsWithoutUsage: z.ZodReadonly<z.ZodNumber>;
                    callsWithoutCacheRead: z.ZodReadonly<z.ZodNumber>;
                    callsWithoutCacheWrite: z.ZodReadonly<z.ZodNumber>;
                    callsWithoutReasoning: z.ZodReadonly<z.ZodNumber>;
                }, z.core.$strip>>;
                cost: z.ZodReadonly<z.ZodObject<{
                    currency: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                    known: z.ZodReadonly<z.ZodNumber>;
                    exactCalls: z.ZodReadonly<z.ZodNumber>;
                    partialCalls: z.ZodReadonly<z.ZodNumber>;
                    unknownCalls: z.ZodReadonly<z.ZodNumber>;
                }, z.core.$strip>>;
                callRoles: z.ZodReadonly<z.ZodObject<{
                    main: z.ZodReadonly<z.ZodObject<{
                        calls: z.ZodReadonly<z.ZodNumber>;
                        tokens: z.ZodReadonly<z.ZodNumber>;
                        cost: z.ZodReadonly<z.ZodObject<{
                            currency: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                            known: z.ZodReadonly<z.ZodNumber>;
                            exactCalls: z.ZodReadonly<z.ZodNumber>;
                            partialCalls: z.ZodReadonly<z.ZodNumber>;
                            unknownCalls: z.ZodReadonly<z.ZodNumber>;
                        }, z.core.$strip>>;
                    }, z.core.$strip>>;
                    visionFallback: z.ZodReadonly<z.ZodObject<{
                        calls: z.ZodReadonly<z.ZodNumber>;
                        tokens: z.ZodReadonly<z.ZodNumber>;
                        cost: z.ZodReadonly<z.ZodObject<{
                            currency: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                            known: z.ZodReadonly<z.ZodNumber>;
                            exactCalls: z.ZodReadonly<z.ZodNumber>;
                            partialCalls: z.ZodReadonly<z.ZodNumber>;
                            unknownCalls: z.ZodReadonly<z.ZodNumber>;
                        }, z.core.$strip>>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>;
                activity: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    date: z.ZodReadonly<z.ZodString>;
                    calls: z.ZodReadonly<z.ZodNumber>;
                    tokens: z.ZodReadonly<z.ZodNumber>;
                    costKnown: z.ZodReadonly<z.ZodNumber>;
                    costUnknownCalls: z.ZodReadonly<z.ZodNumber>;
                }, z.core.$strip>>>;
                providers: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodString>;
                    label: z.ZodReadonly<z.ZodString>;
                    calls: z.ZodReadonly<z.ZodNumber>;
                    tokens: z.ZodReadonly<z.ZodNumber>;
                    cost: z.ZodReadonly<z.ZodObject<{
                        currency: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                        known: z.ZodReadonly<z.ZodNumber>;
                        exactCalls: z.ZodReadonly<z.ZodNumber>;
                        partialCalls: z.ZodReadonly<z.ZodNumber>;
                        unknownCalls: z.ZodReadonly<z.ZodNumber>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>>;
                models: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodString>;
                    label: z.ZodReadonly<z.ZodString>;
                    calls: z.ZodReadonly<z.ZodNumber>;
                    tokens: z.ZodReadonly<z.ZodNumber>;
                    cost: z.ZodReadonly<z.ZodObject<{
                        currency: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                        known: z.ZodReadonly<z.ZodNumber>;
                        exactCalls: z.ZodReadonly<z.ZodNumber>;
                        partialCalls: z.ZodReadonly<z.ZodNumber>;
                        unknownCalls: z.ZodReadonly<z.ZodNumber>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>>;
                tools: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodString>;
                    label: z.ZodReadonly<z.ZodString>;
                    calls: z.ZodReadonly<z.ZodNumber>;
                    tokens: z.ZodReadonly<z.ZodNumber>;
                    cost: z.ZodReadonly<z.ZodObject<{
                        currency: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                        known: z.ZodReadonly<z.ZodNumber>;
                        exactCalls: z.ZodReadonly<z.ZodNumber>;
                        partialCalls: z.ZodReadonly<z.ZodNumber>;
                        unknownCalls: z.ZodReadonly<z.ZodNumber>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>>;
                availableProviders: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodString>;
                    label: z.ZodReadonly<z.ZodString>;
                }, z.core.$strip>>>;
                catalogVersion: z.ZodReadonly<z.ZodString>;
                prices: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    provider: z.ZodReadonly<z.ZodString>;
                    model: z.ZodReadonly<z.ZodString>;
                    currency: z.ZodReadonly<z.ZodString>;
                    sourceUrl: z.ZodReadonly<z.ZodString>;
                    updatedAt: z.ZodReadonly<z.ZodString>;
                    effectiveDate: z.ZodReadonly<z.ZodString>;
                    uncachedInputPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    outputPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    cacheReadPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    cacheWritePerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    reasoningPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    source: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"catalog">, z.ZodLiteral<"user">]>>;
                }, z.core.$strip>>>;
            }, z.core.$strip>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodArray<z.ZodObject<{
                id: z.ZodReadonly<z.ZodString>;
                name: z.ZodReadonly<z.ZodString>;
                method: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"browser-oauth">, z.ZodLiteral<"device-code">]>>;
                official: z.ZodReadonly<z.ZodBoolean>;
                available: z.ZodReadonly<z.ZodBoolean>;
                stability: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"stable">, z.ZodLiteral<"experimental">, z.ZodLiteral<"unsupported">]>>;
                sourceUrl: z.ZodReadonly<z.ZodString>;
                availabilityReason: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodLiteral<"third-party-registration-missing">, z.ZodLiteral<"subscription-oauth-blocked">, z.ZodLiteral<"discontinued">, z.ZodLiteral<"sdk-adapter-required">]>>;
                status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"signed-out">, z.ZodLiteral<"starting">, z.ZodLiteral<"pending">, z.ZodLiteral<"connected">, z.ZodLiteral<"cancelled">, z.ZodLiteral<"expired">, z.ZodLiteral<"needs-reauth">, z.ZodLiteral<"error">]>>;
                authorizationUrl: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                verificationUrl: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                userCode: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                inputPrompt: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodObject<{
                    kind: z.ZodReadonly<z.ZodLiteral<"authorization-code">>;
                    label: z.ZodReadonly<z.ZodString>;
                    placeholder: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                }, z.core.$strip>]>>;
                attemptId: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                expiresAt: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodNumber]>>;
                accountLabel: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                errorCategory: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodLiteral<"cancelled">, z.ZodLiteral<"expired">, z.ZodLiteral<"denied">, z.ZodLiteral<"state-mismatch">, z.ZodLiteral<"callback-unavailable">, z.ZodLiteral<"token-exchange-failed">, z.ZodLiteral<"refresh-rejected">, z.ZodLiteral<"network">, z.ZodLiteral<"revocation-failed">, z.ZodLiteral<"invalid-response">]>>;
                error: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
            }, z.core.$strip>>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodString;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                id: z.ZodReadonly<z.ZodString>;
                name: z.ZodReadonly<z.ZodString>;
                method: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"browser-oauth">, z.ZodLiteral<"device-code">]>>;
                official: z.ZodReadonly<z.ZodBoolean>;
                available: z.ZodReadonly<z.ZodBoolean>;
                stability: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"stable">, z.ZodLiteral<"experimental">, z.ZodLiteral<"unsupported">]>>;
                sourceUrl: z.ZodReadonly<z.ZodString>;
                availabilityReason: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodLiteral<"third-party-registration-missing">, z.ZodLiteral<"subscription-oauth-blocked">, z.ZodLiteral<"discontinued">, z.ZodLiteral<"sdk-adapter-required">]>>;
                status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"signed-out">, z.ZodLiteral<"starting">, z.ZodLiteral<"pending">, z.ZodLiteral<"connected">, z.ZodLiteral<"cancelled">, z.ZodLiteral<"expired">, z.ZodLiteral<"needs-reauth">, z.ZodLiteral<"error">]>>;
                authorizationUrl: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                verificationUrl: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                userCode: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                inputPrompt: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodObject<{
                    kind: z.ZodReadonly<z.ZodLiteral<"authorization-code">>;
                    label: z.ZodReadonly<z.ZodString>;
                    placeholder: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                }, z.core.$strip>]>>;
                attemptId: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                expiresAt: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodNumber]>>;
                accountLabel: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                errorCategory: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodLiteral<"cancelled">, z.ZodLiteral<"expired">, z.ZodLiteral<"denied">, z.ZodLiteral<"state-mismatch">, z.ZodLiteral<"callback-unavailable">, z.ZodLiteral<"token-exchange-failed">, z.ZodLiteral<"refresh-rejected">, z.ZodLiteral<"network">, z.ZodLiteral<"revocation-failed">, z.ZodLiteral<"invalid-response">]>>;
                error: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
            }, z.core.$strip>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        cancellation: {
            parameter: string;
        };
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"signed-out">, z.ZodLiteral<"available">, z.ZodLiteral<"unavailable">]>>;
                generatedAt: z.ZodReadonly<z.ZodNumber>;
                bestEffort: z.ZodReadonly<z.ZodLiteral<true>>;
                sourceUrl: z.ZodReadonly<z.ZodString>;
                windows: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"primary">, z.ZodLiteral<"secondary">]>>;
                    usedPercent: z.ZodReadonly<z.ZodNumber>;
                    remainingPercent: z.ZodReadonly<z.ZodNumber>;
                    windowSeconds: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodNumber]>>;
                    resetAt: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodNumber]>>;
                }, z.core.$strip>>>;
                error: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
            }, z.core.$strip>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodArray<z.ZodObject<{
                id: z.ZodReadonly<z.ZodString>;
                name: z.ZodReadonly<z.ZodString>;
                method: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"plan-api-key">, z.ZodLiteral<"api-key">]>>;
                availability: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"available">, z.ZodLiteral<"restricted">]>>;
                sourceUrl: z.ZodReadonly<z.ZodString>;
                availabilityNote: z.ZodReadonly<z.ZodString>;
                provider: z.ZodReadonly<z.ZodString>;
                baseURL: z.ZodReadonly<z.ZodString>;
                api: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"openai-completions">, z.ZodLiteral<"openai-responses">, z.ZodLiteral<"anthropic-messages">]>>;
                models: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodString>;
                    name: z.ZodReadonly<z.ZodString>;
                }, z.core.$strip>>>;
            }, z.core.$strip>>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodString;
            };
        }[];
        cancellation: {
            parameter: string;
        };
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                ok: z.ZodReadonly<z.ZodBoolean>;
                latencyMs: z.ZodReadonly<z.ZodNumber>;
                models: z.ZodReadonly<z.ZodArray<z.ZodString>>;
                error: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
            }, z.core.$strip>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        cancellation: {
            parameter: string;
        };
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodArray<z.ZodObject<{
                provider: z.ZodReadonly<z.ZodString>;
                status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"signed-out">, z.ZodLiteral<"available">, z.ZodLiteral<"unavailable">]>>;
                generatedAt: z.ZodReadonly<z.ZodNumber>;
                bestEffort: z.ZodReadonly<z.ZodLiteral<true>>;
                sourceUrl: z.ZodReadonly<z.ZodString>;
                windows: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodString>;
                    label: z.ZodReadonly<z.ZodString>;
                    usedPercent: z.ZodReadonly<z.ZodNumber>;
                    remainingPercent: z.ZodReadonly<z.ZodNumber>;
                    windowSeconds: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodNumber]>>;
                    resetAt: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodNumber]>>;
                }, z.core.$strip>>>;
                error: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
            }, z.core.$strip>>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                generatedAt: z.ZodReadonly<z.ZodNumber>;
                defaultSelection: z.ZodReadonly<z.ZodObject<{
                    provider: z.ZodReadonly<z.ZodString>;
                    model: z.ZodReadonly<z.ZodString>;
                    reasoningEffort: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodString]>>>;
                }, z.core.$strip>>;
                providers: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    id: z.ZodReadonly<z.ZodString>;
                    name: z.ZodReadonly<z.ZodString>;
                    active: z.ZodReadonly<z.ZodBoolean>;
                    configurable: z.ZodReadonly<z.ZodBoolean>;
                    declared: z.ZodReadonly<z.ZodBoolean>;
                    configured: z.ZodReadonly<z.ZodBoolean>;
                    credentialConfigured: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodLiteral<false>, z.ZodLiteral<true>]>>;
                    credentialWritable: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodLiteral<false>, z.ZodLiteral<true>]>>;
                    authMode: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"api-key-only">, z.ZodLiteral<"oauth">]>>;
                    accessType: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"account-auth">, z.ZodLiteral<"api">, z.ZodLiteral<"custom-api">]>>;
                    accountLabel: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                    settingsNs: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                    baseURL: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                    models: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                        id: z.ZodReadonly<z.ZodString>;
                        name: z.ZodReadonly<z.ZodString>;
                    }, z.core.$strip>>>;
                    modelError: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                }, z.core.$strip>>>;
            }, z.core.$strip>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodString;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodVoid;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodObject<{
                    presetId: z.ZodReadonly<z.ZodString>;
                    apiKey: z.ZodReadonly<z.ZodString>;
                }, z.core.$strip>;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodVoid;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodObject<{
                    provider: z.ZodReadonly<z.ZodString>;
                    model: z.ZodReadonly<z.ZodString>;
                    currency: z.ZodReadonly<z.ZodString>;
                    sourceUrl: z.ZodReadonly<z.ZodString>;
                    updatedAt: z.ZodReadonly<z.ZodString>;
                    effectiveDate: z.ZodReadonly<z.ZodString>;
                    uncachedInputPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    outputPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    cacheReadPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    cacheWritePerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    reasoningPerMillion: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                }, z.core.$strip>;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodVoid;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodObject<{
                    provider: z.ZodReadonly<z.ZodString>;
                    displayName: z.ZodReadonly<z.ZodString>;
                    baseURL: z.ZodReadonly<z.ZodString>;
                    api: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodLiteral<"openai-completions">, z.ZodLiteral<"openai-responses">, z.ZodLiteral<"anthropic-messages">]>>>;
                    apiKey: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodString]>>>;
                    models: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                        id: z.ZodReadonly<z.ZodString>;
                        name: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodString]>>>;
                        contextWindow: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                        maxTokens: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>>;
                    }, z.core.$strip>>>;
                    headers: z.ZodOptional<z.ZodReadonly<z.ZodUnion<readonly [z.ZodUndefined, z.ZodReadonly<z.ZodRecord<z.ZodString, z.ZodString>>]>>>;
                }, z.core.$strip>;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodVoid;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodObject<{
                    enabled: z.ZodOptional<z.ZodUnion<readonly [z.ZodUndefined, z.ZodLiteral<false>, z.ZodLiteral<true>]>>;
                    provider: z.ZodOptional<z.ZodUnion<readonly [z.ZodUndefined, z.ZodString]>>;
                    model: z.ZodOptional<z.ZodUnion<readonly [z.ZodUndefined, z.ZodString]>>;
                    maxOutputTokens: z.ZodOptional<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>;
                    timeoutMs: z.ZodOptional<z.ZodUnion<readonly [z.ZodUndefined, z.ZodNumber]>>;
                }, z.core.$strip>;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodVoid;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                enabled: z.ZodReadonly<z.ZodBoolean>;
                provider: z.ZodReadonly<z.ZodString>;
                model: z.ZodReadonly<z.ZodString>;
                maxOutputTokens: z.ZodReadonly<z.ZodNumber>;
                timeoutMs: z.ZodReadonly<z.ZodNumber>;
                selectionAvailable: z.ZodReadonly<z.ZodBoolean>;
                routes: z.ZodReadonly<z.ZodArray<z.ZodObject<{
                    provider: z.ZodReadonly<z.ZodString>;
                    providerName: z.ZodReadonly<z.ZodString>;
                    model: z.ZodReadonly<z.ZodString>;
                    modelName: z.ZodReadonly<z.ZodString>;
                    accessType: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<"account-auth">, z.ZodLiteral<"api">, z.ZodLiteral<"custom-api">]>>;
                    accountLabel: z.ZodReadonly<z.ZodUnion<readonly [z.ZodLiteral<null>, z.ZodString]>>;
                }, z.core.$strip>>>;
            }, z.core.$strip>;
        };
        sourceLocation: {
            file: string;
            line: number;
            column: number;
        };
        cancellation?: never;
    })[];
};
export default TYPERT_REMOTE;
//# sourceMappingURL=remote.d.ts.map