// @vitest-environment happy-dom

import { fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import React, { type ComponentType } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { SelectMenu } from '../src/client/SelectMenu.tsx'
import { TimeRangePicker, type TimeRangeLabels } from '../src/client/TimeRangePicker.tsx'
import { parseLocalSecond, recentRange } from '../src/client/time-range.ts'
import { UsageSection } from '../src/client/UsageSection.tsx'
import { AuthLoginAction } from '../src/client/AuthLoginAction.tsx'
import { ModelsProviderStatus } from '../src/client/ModelsProviderStatus.tsx'
import { ModelListEditor } from '../src/client/compat/vendor/models/client/ModelListEditor.tsx'
import type { AnalyticsQuery, AuthProviderView, ProviderAnalyticsView, ProviderHubView, ProviderQuotaView } from '../src/types.ts'

vi.mock('@deepseek-ai/dsh-client-ui-primitives', async () => {
  const React = await import('react')
  const Icon = (props: { className?: string; size?: number }) => React.createElement('svg', {
    className: props.className,
    width: props.size,
    height: props.size,
    'aria-hidden': 'true',
  })
  return {
    Button: ({ children, icon, variant: _variant, size: _size, ...props }: {
      children?: React.ReactNode
      icon?: React.ReactNode
      variant?: string
      size?: string
      [key: string]: unknown
    }) => React.createElement('button', props, icon, children),
    Pill: ({ children, active: _active, ...props }: {
      children?: React.ReactNode
      active?: boolean
      [key: string]: unknown
    }) => React.createElement('button', props, children),
    Modal: ({ open, title, children, footer, onClose: _onClose, closeLabel: _closeLabel, description: _description, className: _className }: {
      open: boolean
      title: React.ReactNode
      children?: React.ReactNode
      footer?: React.ReactNode
      onClose?: () => void
      closeLabel?: string
      description?: string
      className?: string
    }) => open ? React.createElement('div', { role: 'dialog', 'aria-label': String(title) }, children, footer) : null,
    StateDot: () => React.createElement('span'),
    IconCheckOutline16: Icon,
    IconChevronDownOutline14: Icon,
    IconChevronLeftOutline14: Icon,
    IconChevronRightOutline14: Icon,
    IconRefreshOutline16: Icon,
    IconLinkOutline16: Icon,
    IconPlusOutline16: Icon,
  }
})

vi.mock('@deepseek-ai/dsh-client-runtime/client', () => ({
  createSnapshotStore: vi.fn(() => { throw new Error('snapshot store is not used in this component test') }),
}))

afterEach(() => {
  document.body.replaceChildren()
})

describe('SelectMenu', () => {
  it('supports arrow navigation, Enter selection, disabled options, and Escape focus restoration', async () => {
    const onChange = vi.fn()
    render(<SelectMenu
      value="beta"
      ariaLabel="Provider"
      onChange={onChange}
      options={[
        { id: 'alpha', label: 'Alpha', group: 'Account Auth', description: 'Account' },
        { id: 'beta', label: 'Beta', group: 'API Provider', description: 'API' },
        { id: 'disabled', label: 'Disabled', disabled: true },
      ]}
    />)
    const trigger = screen.getByRole('combobox', { name: 'Provider' })
    fireEvent.keyDown(trigger, { key: 'ArrowUp' })
    await waitFor(() => { expect(document.activeElement).toBe(screen.getByRole('option', { name: /Alpha/ })) })
    fireEvent.keyDown(screen.getByRole('listbox'), { key: 'Enter' })
    expect(onChange).toHaveBeenCalledWith('alpha')
    await waitFor(() => { expect(document.activeElement).toBe(trigger) })

    fireEvent.click(trigger)
    expect(screen.getByText('Account Auth')).toBeTruthy()
    expect(screen.getByText('API Provider')).toBeTruthy()
    expect((screen.getByRole('option', { name: 'Disabled' }) as HTMLButtonElement).disabled).toBe(true)
    fireEvent.keyDown(screen.getByRole('listbox'), { key: 'Escape' })
    await waitFor(() => { expect(document.activeElement).toBe(trigger) })
    expect(screen.queryByRole('listbox')).toBeNull()
  })
})

describe('Custom model capability', () => {
  it('keeps image input off by default and writes only an explicit custom-model declaration', () => {
    const onChange = vi.fn()
    render(<ModelListEditor
      models={[{ id: 'custom-model' }]}
      onChange={onChange}
      probe={{ settingsNs: 'llm-pi-ai', provider: 'custom' }}
      api={{ llm: {} } as never}
      t={key => key}
      disabled={false}
      allowImageCapability
    />)
    fireEvent.click(screen.getByRole('button', { name: 'modelAdvanced 1' }))
    const checkbox = screen.getByRole('checkbox', { name: /supportsImageInput/ })
    expect((checkbox as HTMLInputElement).checked).toBe(false)
    fireEvent.click(checkbox)
    expect(onChange).toHaveBeenCalledWith([{ id: 'custom-model', input: ['text', 'image'] }])
  })
})

const rangeLabels: TimeRangeLabels = {
  aria: 'Time range',
  start: 'Start time',
  end: 'End time',
  timeZone: 'Time zone',
  cancel: 'Cancel',
  apply: 'Apply',
  invalid: 'Invalid range',
  previousMonth: 'Previous month',
  nextMonth: 'Next month',
  days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  shortcut: days => `Last ${String(days)} days`,
  summary: (start, end) => `${start} to ${end}`,
}

describe('TimeRangePicker', () => {
  it('validates seconds, applies shortcuts explicitly, and discards outside-click edits', async () => {
    const initial = recentRange(30, Date.parse('2026-08-14T12:00:00.000Z'))
    const onChange = vi.fn()
    render(<TimeRangePicker value={initial} labels={rangeLabels} onChange={onChange} />)
    const trigger = screen.getByRole('button', { name: /Time range:/ })
    const originalSummary = trigger.textContent
    fireEvent.click(trigger)
    fireEvent.change(screen.getByLabelText('Start time'), { target: { value: '2026-08-15 00:00:00' } })
    fireEvent.change(screen.getByLabelText('End time'), { target: { value: '2026-08-14 23:59:59' } })
    expect(screen.getByRole('alert').textContent).toBe('Invalid range')
    expect((screen.getByRole('button', { name: 'Apply' }) as HTMLButtonElement).disabled).toBe(true)

    fireEvent.click(screen.getByRole('button', { name: 'Last 7 days' }))
    fireEvent.click(screen.getByRole('button', { name: 'Apply' }))
    expect(onChange).toHaveBeenCalledTimes(1)
    const applied = onChange.mock.calls[0]?.[0] as ReturnType<typeof recentRange>
    expect(applied.presetDays).toBe(7)
    expect(applied.endTimeExclusive - applied.startTime).toBe(7 * 86_400_000)

    fireEvent.click(trigger)
    fireEvent.change(screen.getByLabelText('Start time'), { target: { value: '2026-08-01 00:00:00' } })
    fireEvent.pointerDown(document.body)
    await waitFor(() => { expect(screen.queryByRole('dialog')).toBeNull() })
    expect(onChange).toHaveBeenCalledTimes(1)
    expect(trigger.textContent).toBe(originalSummary)
  })

  it('rejects an ambiguous local second during a daylight-saving fold', () => {
    const previous = process.env.TZ
    process.env.TZ = 'America/New_York'
    try {
      expect(parseLocalSecond('2026-11-01 01:30:00')).toBeNull()
      expect(parseLocalSecond('2026-11-01 03:30:00')).not.toBeNull()
    } finally {
      if (previous === undefined) delete process.env.TZ
      else process.env.TZ = previous
    }
  })
})

function analyticsView(query: AnalyticsQuery): ProviderAnalyticsView {
  const emptyCost = { currency: 'USD', known: 0, exactCalls: 1, partialCalls: 0, unknownCalls: 0 }
  return {
    generatedAt: Date.now(),
    query,
    kpis: {
      calls: 1,
      sessions: 1,
      totalTokens: 1_200_000,
      peakDailyTokens: 1_200_000,
      longestSessionMs: 1_000,
      currentStreakDays: 1,
      longestStreakDays: 1,
    },
    usage: {
      uncachedInputTokens: 800_000,
      outputTokens: 400_000,
      cacheReadTokens: 0,
      cacheWriteTokens: 0,
      reasoningTokens: 0,
      callsWithoutUsage: 0,
      callsWithoutCacheRead: 0,
      callsWithoutCacheWrite: 0,
      callsWithoutReasoning: 0,
    },
    cost: emptyCost,
    callRoles: {
      main: { calls: 1, tokens: 1_200_000, cost: emptyCost },
      visionFallback: { calls: 0, tokens: 0, cost: { ...emptyCost, exactCalls: 0 } },
    },
    activity: [{ date: '2026-08-14', calls: 1, tokens: 1_200_000, costKnown: 0, costUnknownCalls: 0 }],
    providers: [{ id: 'provider-p', label: 'Provider P', calls: 1, tokens: 1_200_000, cost: emptyCost }],
    models: [{ id: 'provider-p/model-m', label: 'Model M', calls: 1, tokens: 1_200_000, cost: emptyCost }],
    tools: [{ id: 'bash', label: 'bash', calls: 1, tokens: 0, cost: emptyCost }],
    availableProviders: [{ id: 'provider-p', label: 'Provider P' }],
    catalogVersion: 'test-v1',
    prices: [],
  }
}

describe('UsageSection filter context', () => {
  it('intersects Provider and output price in one Host query and preserves them on refresh', async () => {
    const analytics = vi.fn(async (query: AnalyticsQuery) => analyticsView(query))
    const Component = UsageSection as unknown as ComponentType<{
      analytics: (query: AnalyticsQuery) => Promise<ProviderAnalyticsView>
      t: (key: string) => string
    }>
    render(<Component analytics={analytics} t={key => key} />)
    await waitFor(() => { expect(analytics).toHaveBeenCalledTimes(1) })

    fireEvent.click(screen.getByRole('combobox', { name: 'providerRanking' }))
    fireEvent.click(screen.getByRole('option', { name: 'Provider P' }))
    await waitFor(() => { expect(analytics).toHaveBeenCalledTimes(2) })

    fireEvent.click(screen.getByRole('combobox', { name: /outputPrice/ }))
    fireEvent.click(screen.getByRole('option', { name: '$1–5' }))
    await waitFor(() => { expect(analytics).toHaveBeenCalledTimes(3) })
    expect(analytics.mock.calls.at(-1)?.[0]).toMatchObject({ provider: 'provider-p', outputPriceBand: '1-5' })

    fireEvent.click(screen.getByRole('button', { name: 'refresh' }))
    await waitFor(() => { expect(analytics).toHaveBeenCalledTimes(4) })
    expect(analytics.mock.calls.at(-1)?.[0]).toMatchObject({ provider: 'provider-p', outputPriceBand: '1-5' })
  })

  it('renders one real bucket inside a 365-cell, seven-row daily calendar with month labels', async () => {
    const analytics = vi.fn(async (query: AnalyticsQuery) => analyticsView(query))
    const Component = UsageSection as unknown as ComponentType<{
      analytics: (query: AnalyticsQuery) => Promise<ProviderAnalyticsView>
      t: (key: string) => string
    }>
    render(<Component analytics={analytics} t={key => key} />)

    const heatmap = await screen.findByRole('group', { name: 'tokenActivity' })
    const cells = within(heatmap).getAllByRole('button')
    expect(cells).toHaveLength(365)
    expect(heatmap.getAttribute('data-layout')).toBe('calendar')
    expect((heatmap as HTMLElement).style.gridTemplateColumns).toContain('repeat(53')
    expect(cells[0]?.getAttribute('style')).toMatch(/grid-row-start/)
    expect(cells.filter(cell => cell.getAttribute('data-level') === '0')).toHaveLength(364)
    expect(cells.some(cell => cell.getAttribute('aria-label')?.startsWith('2026-08-14: 1,200,000 Token'))).toBe(true)
    expect(heatmap.parentElement?.textContent).toMatch(/Jul|Aug/)
  })
})

describe('Models Provider quota visibility', () => {
  const providers: ProviderHubView = {
    generatedAt: Date.now(),
    defaultSelection: { provider: 'openai-codex', model: 'gpt-test' },
    providers: [{
      id: 'openai-codex', name: 'OpenAI Codex', active: true, configurable: true, declared: true,
      configured: true, credentialConfigured: true, credentialWritable: true, authMode: 'oauth',
      accessType: 'account-auth', accountLabel: 'c***@example.com',
      settingsNs: 'test', baseURL: 'https://example.invalid', models: [{ id: 'gpt-test', name: 'GPT Test' }], modelError: null,
    }],
  }
  const available: ProviderQuotaView = {
    provider: 'openai-codex', status: 'available', generatedAt: Date.now(), bestEffort: true,
    sourceUrl: 'https://example.invalid/usage', error: null,
    windows: [{ id: 'primary', label: 'Primary', usedPercent: 25, remainingPercent: 75, windowSeconds: 18_000, resetAt: Date.now() + 1_000 }],
  }
  const Component = ModelsProviderStatus as ComponentType<{
    loadProviders: () => Promise<ProviderHubView>
    loadProviderQuotas: () => Promise<readonly ProviderQuotaView[]>
    loadVisionFallback: () => Promise<import('../src/types.ts').VisionFallbackView>
    saveVisionFallback: (request: import('../src/types.ts').VisionFallbackConfig) => Promise<void>
    probe: () => Promise<never>
    logoutAuth: (provider: string) => Promise<void>
    saveDefault: () => Promise<void>
    subscribeProviderChange: (listener: () => void) => () => void
    t: (key: string) => string
  }>
  const shared = {
    loadProviders: async () => providers,
    loadVisionFallback: async () => ({
      enabled: false, provider: '', model: '', maxOutputTokens: 512, timeoutMs: 60_000,
      selectionAvailable: true, routes: [],
    }),
    saveVisionFallback: async () => {},
    probe: async (): Promise<never> => { throw new Error('not used') },
    logoutAuth: async () => {},
    saveDefault: async () => {},
    subscribeProviderChange: () => () => {},
    t: (key: string) => key,
  }

  it('renders only complete live quota and hides empty, failed, or unsupported responses without exposing errors', async () => {
    const live = render(<Component {...shared} loadProviderQuotas={async () => [available]} />)
    await waitFor(() => { expect(screen.getByLabelText('codexUsage')).toBeTruthy() })
    expect(screen.getByRole('progressbar')).toBeTruthy()
    live.unmount()

    const incomplete = render(<Component {...shared} loadProviderQuotas={async () => [{ ...available, windows: [] }]} />)
    await waitFor(() => { expect(screen.getByText('OpenAI Codex')).toBeTruthy() })
    expect(screen.queryByLabelText('codexUsage')).toBeNull()
    incomplete.unmount()

    render(<Component {...shared} loadProviderQuotas={async () => { throw new Error('private upstream quota failure') }} />)
    await waitFor(() => { expect(screen.getByText('OpenAI Codex')).toBeTruthy() })
    expect(screen.queryByLabelText('codexUsage')).toBeNull()
    expect(document.body.textContent).not.toContain('private upstream quota failure')
    incomplete.unmount()

    render(<Component {...shared} loadProviderQuotas={async () => [{
      ...available,
      windows: [{ ...available.windows[0]!, usedPercent: 80, remainingPercent: 40 }],
    }]} />)
    await waitFor(() => { expect(screen.getByText('OpenAI Codex')).toBeTruthy() })
    expect(screen.queryByLabelText('codexUsage')).toBeNull()
  })

  it('uses HTTP probe only for API instances and offers Host logout for connected Auth instances', async () => {
    const logoutAuth = vi.fn(async () => {})
    const auth = render(<Component {...shared} logoutAuth={logoutAuth} loadProviderQuotas={async () => []} />)
    await waitFor(() => { expect(screen.getByText('OpenAI Codex')).toBeTruthy() })
    expect(screen.queryByRole('button', { name: 'test' })).toBeNull()
    expect(screen.getByRole('button', { name: 'authLogout' })).toBeTruthy()
    expect(screen.getByRole('button', { name: 'saveDefault' }).getAttribute('disabled')).toBeNull()
    fireEvent.click(screen.getByRole('button', { name: 'authLogout' }))
    await waitFor(() => { expect(logoutAuth).toHaveBeenCalledWith('openai-codex') })
    auth.unmount()

    const apiProviders: ProviderHubView = {
      ...providers,
      defaultSelection: { provider: 'custom-api', model: 'model-a' },
      providers: [{
        ...providers.providers[0]!, id: 'custom-api', name: 'Custom API', authMode: 'api-key-only',
        baseURL: 'https://api.example.test', models: [{ id: 'model-a', name: 'Model A' }],
      }],
    }
    render(<Component {...shared} loadProviders={async () => apiProviders} loadProviderQuotas={async () => []} />)
    await waitFor(() => { expect(screen.getByText('Custom API')).toBeTruthy() })
    expect(screen.getByRole('button', { name: 'test' })).toBeTruthy()
    expect(screen.queryByRole('button', { name: 'authLogout' })).toBeNull()
  })

  it('refetches Provider instances when Auth emits an invalidation', async () => {
    let invalidate!: () => void
    const loadProviders = vi.fn(async () => providers)
    render(<Component
      {...shared}
      loadProviders={loadProviders}
      loadProviderQuotas={async () => []}
      subscribeProviderChange={(listener) => { invalidate = listener; return () => {} }}
    />)
    await waitFor(() => { expect(loadProviders).toHaveBeenCalledTimes(1) })
    invalidate()
    await waitFor(() => { expect(loadProviders).toHaveBeenCalledTimes(2) })
  })

  it('keeps vision fallback off by default and saves only an explicitly image-capable route', async () => {
    const saveVisionFallback = vi.fn(async () => {})
    render(<Component
      {...shared}
      loadProviderQuotas={async () => []}
      saveVisionFallback={saveVisionFallback}
      loadVisionFallback={async () => ({
        enabled: false,
        provider: '',
        model: '',
        maxOutputTokens: 512,
        timeoutMs: 60_000,
        selectionAvailable: true,
        routes: [{
          provider: 'vision-provider', providerName: 'Vision Provider', model: 'vision-model', modelName: 'Vision Model',
          accessType: 'custom-api', accountLabel: null,
        }],
      })}
    />)
    await waitFor(() => { expect(screen.getByText('visionFallbackTitle')).toBeTruthy() })
    const toggle = screen.getByRole('checkbox')
    expect((toggle as HTMLInputElement).checked).toBe(false)
    fireEvent.click(toggle)
    fireEvent.click(screen.getByRole('combobox', { name: 'visionProvider' }))
    fireEvent.click(within(screen.getByRole('listbox', { name: 'visionProvider' })).getByText('Vision Provider'))
    fireEvent.click(screen.getByRole('combobox', { name: 'visionModel' }))
    fireEvent.click(within(screen.getByRole('listbox', { name: 'visionModel' })).getByText('Vision Model'))
    fireEvent.click(screen.getByRole('button', { name: 'save' }))
    await waitFor(() => { expect(saveVisionFallback).toHaveBeenCalledWith({
      enabled: true,
      provider: 'vision-provider',
      model: 'vision-model',
      maxOutputTokens: 512,
      timeoutMs: 60_000,
    }) })
  })
})

describe('AuthLoginAction', () => {
  it('keeps the Provider selector usable after one login attempt fails', async () => {
    const providers: AuthProviderView[] = ['xai', 'anthropic'].map((id): AuthProviderView => ({
      id, name: id, method: 'browser-oauth', official: false, available: true, stability: 'experimental',
      sourceUrl: `https://${id}.example/source`, availabilityReason: null, status: 'signed-out',
      authorizationUrl: null, verificationUrl: null, userCode: null, inputPrompt: null, attemptId: null,
      expiresAt: null, accountLabel: null, errorCategory: null, error: null,
    }))
    const Component = AuthLoginAction as unknown as ComponentType<{
      loadAuthProviders: () => Promise<readonly AuthProviderView[]>
      startAuth: (provider: string) => Promise<AuthProviderView>
      cancelAuth: (provider: string, attemptId: string) => Promise<AuthProviderView>
      submitAuth: (provider: string, attemptId: string, value: string) => Promise<AuthProviderView>
      logoutAuth: (provider: string) => Promise<AuthProviderView>
      notifyProviderChange: () => void
      t: (key: string) => string
    }>
    render(<Component
      loadAuthProviders={async () => providers}
      startAuth={async () => { throw new Error('upstream unavailable') }}
      cancelAuth={vi.fn()}
      submitAuth={vi.fn()}
      logoutAuth={vi.fn()}
      notifyProviderChange={vi.fn()}
      t={key => key}
    />)

    fireEvent.click(screen.getByRole('button', { name: 'addAuthLogin' }))
    await waitFor(() => { expect(screen.getByRole('combobox', { name: 'authProvider' })).toBeTruthy() })
    fireEvent.click(screen.getByRole('button', { name: 'authStart' }))
    await waitFor(() => { expect(screen.getByRole('alert').textContent).toBe('upstream unavailable') })
    fireEvent.click(screen.getByRole('combobox', { name: 'authProvider' }))
    expect(screen.getAllByRole('option').some(option => option.textContent?.includes('anthropic'))).toBe(true)
  })

  it('submits a one-time callback value without receiving or rendering Provider tokens', async () => {
    const pending: AuthProviderView = {
      id: 'anthropic', name: 'Anthropic login compatibility', method: 'browser-oauth', official: false,
      available: true, stability: 'experimental', sourceUrl: 'https://provider.example/source', availabilityReason: null,
      status: 'pending', authorizationUrl: 'https://provider.example/authorize?state=public', verificationUrl: null,
      userCode: null, inputPrompt: { kind: 'authorization-code', label: 'Authorization code', placeholder: null },
      attemptId: 'attempt-public', expiresAt: Date.now() + 60_000, accountLabel: null, errorCategory: null, error: null,
    }
    const submitAuth = vi.fn(async () => ({ ...pending, status: 'pending' as const }))
    const Component = AuthLoginAction as unknown as ComponentType<{
      loadAuthProviders: () => Promise<readonly AuthProviderView[]>
      startAuth: (provider: string) => Promise<AuthProviderView>
      cancelAuth: (provider: string, attemptId: string) => Promise<AuthProviderView>
      submitAuth: (provider: string, attemptId: string, value: string) => Promise<AuthProviderView>
      logoutAuth: (provider: string) => Promise<AuthProviderView>
      notifyProviderChange: () => void
      t: (key: string) => string
    }>
    render(<Component
      loadAuthProviders={async () => [pending]}
      startAuth={vi.fn()}
      cancelAuth={vi.fn()}
      submitAuth={submitAuth}
      logoutAuth={vi.fn()}
      notifyProviderChange={vi.fn()}
      t={key => key}
    />)

    fireEvent.click(screen.getByRole('button', { name: 'addAuthLogin' }))
    await waitFor(() => { expect(screen.getByRole('dialog', { name: 'authTitle' })).toBeTruthy() })
    await waitFor(() => { expect(screen.getByRole('combobox', { name: 'authProvider' }).textContent).toContain('Anthropic') })
    fireEvent.change(screen.getByLabelText('authCode'), { target: { value: 'one-time-callback-value' } })
    await waitFor(() => { expect(screen.getByRole('button', { name: 'authSubmit' }).getAttribute('disabled')).toBeNull() })
    fireEvent.click(screen.getByRole('button', { name: 'authSubmit' }))

    await waitFor(() => {
      expect(submitAuth).toHaveBeenCalledWith('anthropic', 'attempt-public', 'one-time-callback-value')
    })
    expect(document.body.textContent).not.toMatch(/access[-_ ]?token|refresh[-_ ]?token/i)
  })

  it('uses a complete Kimi authorization link without a redundant code and refreshes on focus', async () => {
    const pending: AuthProviderView = {
      id: 'kimi-code', name: 'Kimi Code', method: 'device-code', official: true,
      available: true, stability: 'experimental', sourceUrl: 'https://provider.example/source', availabilityReason: null,
      status: 'pending', authorizationUrl: 'https://www.kimi.com/code/authorize_device?user_code=ABCD-EFGH',
      verificationUrl: 'https://www.kimi.com/code/authorize_device', userCode: 'ABCD-EFGH', inputPrompt: null,
      attemptId: 'attempt-public', expiresAt: Date.now() + 60_000, accountLabel: null, errorCategory: null, error: null,
    }
    const connected: AuthProviderView = {
      ...pending, status: 'connected', authorizationUrl: null, verificationUrl: null, userCode: null,
      attemptId: null, expiresAt: null,
    }
    const loadAuthProviders = vi.fn()
      .mockResolvedValueOnce([pending])
      .mockResolvedValue([connected])
    const notifyProviderChange = vi.fn()
    const Component = AuthLoginAction as unknown as ComponentType<{
      loadAuthProviders: () => Promise<readonly AuthProviderView[]>
      startAuth: (provider: string) => Promise<AuthProviderView>
      cancelAuth: (provider: string, attemptId: string) => Promise<AuthProviderView>
      submitAuth: (provider: string, attemptId: string, value: string) => Promise<AuthProviderView>
      logoutAuth: (provider: string) => Promise<AuthProviderView>
      notifyProviderChange: () => void
      t: (key: string) => string
    }>
    render(<Component
      loadAuthProviders={loadAuthProviders}
      startAuth={vi.fn()}
      cancelAuth={vi.fn()}
      submitAuth={vi.fn()}
      logoutAuth={vi.fn()}
      notifyProviderChange={notifyProviderChange}
      t={key => key}
    />)

    fireEvent.click(screen.getByRole('button', { name: 'addAuthLogin' }))
    await waitFor(() => { expect(screen.getByRole('link', { name: 'authOpenOfficial' })).toBeTruthy() })
    expect(screen.queryByText('ABCD-EFGH')).toBeNull()

    fireEvent.focus(window)
    await waitFor(() => { expect(loadAuthProviders).toHaveBeenCalledTimes(2) })
    await waitFor(() => { expect(notifyProviderChange).toHaveBeenCalledOnce() })
  })

  it('invalidates the Models projection when a connected Auth state arrives', async () => {
    const notifyProviderChange = vi.fn()
    const connected: AuthProviderView = {
      id: 'openai-codex', name: 'OpenAI Codex', method: 'browser-oauth', official: true,
      available: true, stability: 'stable', sourceUrl: 'https://provider.example/source', availabilityReason: null,
      status: 'connected', authorizationUrl: null, verificationUrl: null, userCode: null, inputPrompt: null,
      attemptId: null, expiresAt: null, accountLabel: 'account-redacted', errorCategory: null, error: null,
    }
    const Component = AuthLoginAction as unknown as ComponentType<{
      loadAuthProviders: () => Promise<readonly AuthProviderView[]>
      startAuth: (provider: string) => Promise<AuthProviderView>
      cancelAuth: (provider: string, attemptId: string) => Promise<AuthProviderView>
      submitAuth: (provider: string, attemptId: string, value: string) => Promise<AuthProviderView>
      logoutAuth: (provider: string) => Promise<AuthProviderView>
      notifyProviderChange: () => void
      t: (key: string) => string
    }>
    render(<Component
      loadAuthProviders={async () => [connected]}
      startAuth={vi.fn()}
      cancelAuth={vi.fn()}
      submitAuth={vi.fn()}
      logoutAuth={vi.fn()}
      notifyProviderChange={notifyProviderChange}
      t={key => key}
    />)

    fireEvent.click(screen.getByRole('button', { name: 'addAuthLogin' }))
    await waitFor(() => { expect(notifyProviderChange).toHaveBeenCalledOnce() })
  })
})
