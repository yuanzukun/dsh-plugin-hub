import { describe, expect, it } from 'vitest'
import { activitySeries, dailyCalendarLayout } from '../src/client/activity.ts'

const days = [
  { date: '2026-08-10', calls: 1, tokens: 10, costKnown: 0.1, costUnknownCalls: 0 },
  { date: '2026-08-11', calls: 2, tokens: 20, costKnown: 0.2, costUnknownCalls: 1 },
  { date: '2026-08-18', calls: 3, tokens: 30, costKnown: 0.3, costUnknownCalls: 0 },
]

describe('activitySeries', () => {
  it('returns daily activity without mutating the source', () => {
    const result = activitySeries(days, 'daily', 9, '2026-08-18')
    expect(result).toHaveLength(9)
    expect(result[0]).toEqual(days[0])
    expect(result[2]).toEqual({ date: '2026-08-12', calls: 0, tokens: 0, costKnown: 0, costUnknownCalls: 0 })
    expect(result.at(-1)).toEqual(days[2])
    expect(result).not.toBe(days)
  })

  it('builds cumulative values across the visible window', () => {
    const last = activitySeries(days, 'cumulative', 9, '2026-08-18').at(-1)
    expect(last).toMatchObject({ date: '2026-08-17', calls: 6, tokens: 60, costUnknownCalls: 1 })
    expect(last?.costKnown).toBeCloseTo(0.6)
  })

  it('groups UTC days into Monday-based weeks', () => {
    expect(activitySeries(days, 'weekly', 9, '2026-08-18')).toEqual([
      { date: '2026-08-10', calls: 3, tokens: 30, costKnown: 0.30000000000000004, costUnknownCalls: 1 },
      { date: '2026-08-17', calls: 3, tokens: 30, costKnown: 0.3, costUnknownCalls: 0 },
    ])
  })

  it('keeps a 365-day daily calendar with empty dates and seven weekday rows', () => {
    const layout = dailyCalendarLayout([
      { date: '2026-08-14', calls: 2, tokens: 26_383, costKnown: 0.0021, costUnknownCalls: 0 },
    ], '2026-08-15')

    expect(layout.days).toHaveLength(365)
    expect(layout.days.filter(day => day.tokens > 0)).toEqual([
      { date: '2026-08-14', calls: 2, tokens: 26_383, costKnown: 0.0021, costUnknownCalls: 0 },
    ])
    expect(layout.days[0]?.tokens).toBe(0)
    expect(layout.startRow).toBe(new Date(`${layout.days[0]!.date}T00:00:00.000Z`).getUTCDay())
    expect(layout.columns).toBe(53)
  })
})
