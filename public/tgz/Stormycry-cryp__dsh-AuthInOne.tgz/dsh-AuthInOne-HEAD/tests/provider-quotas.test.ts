import { describe, expect, it, vi } from 'vitest'
import {
  fetchAnthropicQuota,
  fetchAntigravityQuota,
  fetchCursorQuota,
  fetchXaiQuota,
} from '../src/host/provider-quotas.ts'
import type { StoredOAuthCredential } from '../src/host/auth-protocol.ts'

function response(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

function jwt(subject: string): string {
  return `header.${Buffer.from(JSON.stringify({ sub: subject })).toString('base64url')}.signature`
}

describe('subscription Provider quota projections', () => {
  it('maps xAI weekly utilization and hides the account token from the view', async () => {
    const request = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
      expect(new Headers(init?.headers).get('authorization')).toBe(`Bearer ${jwt('account-private')}`)
      expect(new Headers(init?.headers).get('x-userid')).toBe('account-private')
      return response({ config: { creditUsagePercent: 0.25, currentPeriod: { type: 'USAGE_PERIOD_TYPE_WEEKLY', end: '2026-08-21T00:00:00Z' } } })
    }) as typeof fetch

    const view = await fetchXaiQuota(jwt('account-private'), undefined, request)

    expect(view).toMatchObject({ provider: 'xai', status: 'available', bestEffort: true })
    expect(view.windows).toEqual([expect.objectContaining({ id: 'weekly', usedPercent: 25, remainingPercent: 75 })])
    expect(JSON.stringify(view)).not.toContain('account-private')
  })

  it('maps only returned Anthropic windows without inventing absent limits', async () => {
    const view = await fetchAnthropicQuota('anthropic-sensitive', undefined, vi.fn(async () => response({
      five_hour: { utilization: 45, resets_at: '2026-08-14T18:00:00Z' },
      seven_day: { utilization: 0.6, resets_at: '2026-08-20T00:00:00Z' },
    })) as typeof fetch)

    expect(view.status).toBe('available')
    expect(view.windows.map(entry => [entry.id, entry.usedPercent])).toEqual([
      ['five-hour', 45],
      ['weekly', 60],
    ])
  })

  it('maps Cursor included usage and Antigravity model quota independently', async () => {
    const cursor = await fetchCursorQuota('cursor-sensitive', undefined, vi.fn(async () => response({
      planUsage: { limitCents: 2_000, remainingCents: 500, autoPercentUsed: 0.2, apiPercentUsed: 30 },
      billingCycleEnd: '1771077734000',
    })) as typeof fetch)
    expect(cursor.windows.map(entry => [entry.id, entry.usedPercent])).toEqual([
      ['monthly', 75],
      ['first-party', 20],
      ['api', 30],
    ])

    const credential: StoredOAuthCredential = {
      version: 1,
      accessToken: 'google-sensitive',
      refreshToken: 'google-refresh-sensitive',
      expiresAt: Date.now() + 60_000,
      providerData: { projectId: 'project-private' },
    }
    const antigravity = await fetchAntigravityQuota(
      credential.accessToken,
      credential,
      undefined,
      vi.fn(async () => response({ models: {
        'gemini-3.6-flash': { quotaInfo: { remainingFraction: 0.7, resetTime: '2026-08-15T00:00:00Z' } },
        'claude-sonnet-4-6': { quotaInfo: { remainingFraction: 0.4, resetTime: '2026-08-15T00:00:00Z' } },
      } })) as typeof fetch,
    )
    expect(antigravity.windows.map(entry => [entry.id, entry.usedPercent])).toEqual([
      ['gemini', 30],
      ['other', 60],
    ])
  })

  it('fails closed on oversized or malformed quota responses', async () => {
    const oversized = vi.fn(async () => new Response('{}', { headers: { 'content-length': '999999' } })) as typeof fetch
    await expect(fetchCursorQuota('cursor-sensitive', undefined, oversized)).resolves.toMatchObject({ status: 'unavailable', windows: [] })
    const malformed = vi.fn(async () => new Response('{', { status: 200 })) as typeof fetch
    await expect(fetchAnthropicQuota('anthropic-sensitive', undefined, malformed)).resolves.toMatchObject({ status: 'unavailable', windows: [] })
  })
})
