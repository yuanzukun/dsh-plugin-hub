import type { SessionEvent, SessionHeader } from '@deepseek-ai/dsh-session'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { describe, expect, it } from 'vitest'
import { foldProviderAnalytics, outputPriceBandOf, type SessionLogInput } from '../src/host/fold.ts'
import type { AnalyticsQuery, ModelPriceView, OutputPriceBand } from '../src/types.ts'

const NOW = Date.parse('2026-08-14T12:00:00.000Z')

function query(overrides: Partial<AnalyticsQuery> = {}): AnalyticsQuery {
  return {
    startTime: NOW - 30 * 86_400_000,
    endTimeExclusive: NOW + 100,
    timeZone: 'UTC',
    provider: null,
    outputPriceBand: 'all',
    ...overrides,
  }
}

function log(id: string, time: number, provider: string, model: string, usage?: {
  inputTokens: number
  outputTokens: number
  cacheReadTokens?: number
  cacheWriteTokens?: number
  reasoningTokens?: number
}, tool?: string): SessionLogInput {
  const events: SessionEvent[] = [
    { type: 'turn/start', seq: 0, time: time - 2, data: { turn: 1 } },
    { type: 'request/context', seq: 1, time: time - 1, data: { provider, model } },
    ...(usage === undefined ? [] : [{
      type: 'assistant/chunk' as const,
      seq: 2,
      time,
      data: { turn: 1, step: 1, chunk: { type: 'usage' as const, usage } },
    }]),
    ...(tool === undefined ? [] : [{
      type: 'tool/call' as const,
      seq: usage === undefined ? 2 : 3,
      time: time + 1,
      data: { turn: 1, step: 1, callId: `call-${id}` as never, name: tool, arguments: '{}' },
    }]),
    {
      type: 'step/end',
      seq: (usage === undefined ? 2 : 3) + (tool === undefined ? 0 : 1),
      time: time + 2,
      data: { turn: 1, step: 1 },
    },
  ]
  return { header: { id } as unknown as SessionHeader, events }
}

function price(provider: string, model: string, outputPerMillion: number | undefined, currency = 'USD'): ModelPriceView {
  return {
    provider,
    model,
    currency,
    sourceUrl: 'https://pricing.example.test',
    updatedAt: '2026-08-14',
    effectiveDate: '2026-08-14',
    uncachedInputPerMillion: 1,
    ...(outputPerMillion === undefined ? {} : { outputPerMillion }),
    source: 'catalog',
  }
}

describe('outputPriceBandOf', () => {
  it.each([
    [0, '0-1'], [0.999999, '0-1'], [1, '1-5'], [4.999999, '1-5'],
    [5, '5-15'], [14.999999, '5-15'], [15, '15-plus'], [500, '15-plus'],
  ] satisfies Array<[number, Exclude<OutputPriceBand, 'all' | 'unpriced'>]>)('classifies %s into %s without overlapping endpoints', (value, expected) => {
    expect(outputPriceBandOf(price('p', 'm', value))).toBe(expected)
  })

  it('treats a missing, invalid, negative, or non-USD output price as unpriced', () => {
    expect(outputPriceBandOf(undefined)).toBe('unpriced')
    expect(outputPriceBandOf(price('p', 'missing', undefined))).toBe('unpriced')
    expect(outputPriceBandOf(price('p', 'eur', 2, 'EUR'))).toBe('unpriced')
    expect(outputPriceBandOf(price('p', 'negative', -1))).toBe('unpriced')
    expect(outputPriceBandOf(price('p', 'nan', Number.NaN))).toBe('unpriced')
  })
})

describe('foldProviderAnalytics', () => {
  it('keeps token buckets disjoint and marks incomplete prices partial', () => {
    const priced = { ...price('deepseek-official', 'deepseek-chat', 2), cacheReadPerMillion: 0.1 }
    const result = foldProviderAnalytics([
      log('one', NOW, 'deepseek-official', 'deepseek-chat', {
        inputTokens: 1_000,
        outputTokens: 500,
        cacheReadTokens: 200,
        cacheWriteTokens: 100,
        reasoningTokens: 50,
      }, 'bash'),
    ], query(), [priced], 'official-2026-08-14', NOW)

    expect(result.usage).toEqual({
      uncachedInputTokens: 1_000,
      outputTokens: 500,
      cacheReadTokens: 200,
      cacheWriteTokens: 100,
      reasoningTokens: 50,
      callsWithoutUsage: 0,
      callsWithoutCacheRead: 0,
      callsWithoutCacheWrite: 0,
      callsWithoutReasoning: 0,
    })
    expect(result.kpis.totalTokens).toBe(1_800)
    expect(result.cost).toMatchObject({ currency: 'USD', exactCalls: 0, partialCalls: 1, unknownCalls: 0 })
    expect(result.cost.known).toBeCloseTo(0.00202)
    expect(result.providers[0]).toMatchObject({ id: 'deepseek-official', calls: 1, tokens: 1_800 })
    expect(result.models[0]).toMatchObject({ id: 'deepseek-official/deepseek-chat', calls: 1 })
    expect(result.tools[0]).toMatchObject({ id: 'bash', calls: 1, tokens: 0 })
    expect(result.callRoles).toMatchObject({
      main: { calls: 1, tokens: 1_800 },
      visionFallback: { calls: 0, tokens: 0 },
    })
  })

  it('attributes auxiliary image understanding separately without inventing missing usage or price', () => {
    const base = log('vision', NOW, 'main-provider', 'text-model', { inputTokens: 10, outputTokens: 2 })
    const events: SessionEvent[] = [...base.events, {
      type: 'user/message',
      seq: base.events.length,
      time: NOW + 10,
      data: createUserMessage({
        content: [{ type: 'text', text: 'A product screenshot.' }],
        source: {
          kind: 'auth-in-one-vision-result',
          form: 'notice',
          summary: 'Vision fallback description',
          requestId: 'vision-request-1',
          sourceMessageId: 'source-message-1',
          route: { provider: 'vision-provider', model: 'vision-model' },
          status: 'success',
          usage: { inputTokens: 20, outputTokens: 5 },
        },
      }),
      surfaceOp: 'append',
    }]
    const result = foldProviderAnalytics([{ ...base, events }], query(), [], 'unpriced-v1', NOW + 10)
    expect(result.kpis).toMatchObject({ calls: 2, totalTokens: 37 })
    expect(result.callRoles).toMatchObject({
      main: { calls: 1, tokens: 12 },
      visionFallback: { calls: 1, tokens: 25, cost: { unknownCalls: 1 } },
    })
    expect(result.models).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: 'main-provider/text-model' }),
      expect.objectContaining({ id: 'vision-provider/vision-model#vision-fallback', label: 'vision-model · Vision fallback' }),
    ]))
  })

  it('applies Provider and output-price filters as one intersection across every projection', () => {
    const prices = [
      price('selected', 'cheap', 0.5),
      price('selected', 'mid', 3),
      price('selected', 'eur', 3, 'EUR'),
      price('other', 'cheap', 0.5),
    ]
    const logs = [
      log('selected-cheap', NOW - 3, 'selected', 'cheap', { inputTokens: 10, outputTokens: 1 }, 'cheap-tool'),
      log('selected-mid', NOW - 2, 'selected', 'mid', { inputTokens: 20, outputTokens: 2 }, 'mid-tool'),
      log('selected-eur', NOW - 1, 'selected', 'eur', { inputTokens: 30, outputTokens: 3 }, 'eur-tool'),
      log('selected-missing', NOW, 'selected', 'missing', { inputTokens: 40, outputTokens: 4 }, 'missing-tool'),
      log('other-cheap', NOW, 'other', 'cheap', { inputTokens: 50, outputTokens: 5 }, 'other-tool'),
    ]
    const cheap = foldProviderAnalytics(logs, query({ provider: 'selected', outputPriceBand: '0-1' }), prices, 'v1', NOW)
    expect(cheap.kpis).toMatchObject({ calls: 1, sessions: 1, totalTokens: 11 })
    expect(cheap.models.map(row => row.id)).toEqual(['selected/cheap'])
    expect(cheap.tools.map(row => row.id)).toEqual(['cheap-tool'])
    expect(cheap.activity).toHaveLength(1)

    const unpriced = foldProviderAnalytics(logs, query({ provider: 'selected', outputPriceBand: 'unpriced' }), prices, 'v1', NOW)
    expect(unpriced.kpis).toMatchObject({ calls: 2, sessions: 2, totalTokens: 77 })
    expect(unpriced.models.map(row => row.id).sort()).toEqual(['selected/eur', 'selected/missing'])
    expect(unpriced.tools.map(row => row.id).sort()).toEqual(['eur-tool', 'missing-tool'])
    expect(unpriced.availableProviders.map(row => row.id).sort()).toEqual(['other', 'selected'])
  })

  it('uses the call event timestamp with a start-inclusive and end-exclusive UTC range', () => {
    const result = foldProviderAnalytics([
      log('before', NOW - 1, 'p', 'before', { inputTokens: 1, outputTokens: 1 }),
      log('start', NOW, 'p', 'start', { inputTokens: 2, outputTokens: 2 }),
      log('last-millisecond', NOW + 999, 'p', 'last', { inputTokens: 3, outputTokens: 3 }),
      log('exclusive-end', NOW + 1_000, 'p', 'end', { inputTokens: 4, outputTokens: 4 }),
    ], query({ startTime: NOW, endTimeExclusive: NOW + 1_000 }), [], 'v1', NOW)
    expect(result.models.map(row => row.id).sort()).toEqual(['p/last', 'p/start'])
    expect(result.kpis).toMatchObject({ calls: 2, totalTokens: 10 })
  })

  it('buckets activity and streaks in the requested local time zone', () => {
    const lateUtc = Date.parse('2026-08-01T16:00:00.000Z')
    const result = foldProviderAnalytics([
      log('local-day-one', lateUtc, 'p', 'm', { inputTokens: 1, outputTokens: 1 }),
      log('local-day-two', lateUtc + 86_400_000, 'p', 'm', { inputTokens: 1, outputTokens: 1 }),
    ], query({
      startTime: lateUtc - 1,
      endTimeExclusive: lateUtc + 86_400_001,
      timeZone: 'Asia/Shanghai',
    }), [], 'v1', lateUtc + 86_400_000)
    expect(result.activity.map(day => day.date)).toEqual(['2026-08-02', '2026-08-03'])
    expect(result.kpis).toMatchObject({ currentStreakDays: 2, longestStreakDays: 2 })
  })

  it('reports absent usage and price as unknown instead of exact zero', () => {
    const result = foldProviderAnalytics([
      log('unknown', NOW - 1, 'custom', 'mystery'),
      log('unpriced', NOW, 'custom', 'mystery', { inputTokens: 4, outputTokens: 2 }),
    ], query(), [], 'unpriced-v1', NOW)
    expect(result.kpis.calls).toBe(2)
    expect(result.usage.callsWithoutUsage).toBe(1)
    expect(result.cost).toEqual({ currency: null, known: 0, exactCalls: 0, partialCalls: 0, unknownCalls: 2 })
  })
})
