import { crc32 } from 'node:zlib'
import type { GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm'
import { describe, expect, it, vi } from 'vitest'
import { CommandCodeLlmAdapter } from '../src/host/command-code-adapter.ts'
import { GoogleAntigravityLlmAdapter } from '../src/host/google-antigravity-adapter.ts'
import { KiroLlmAdapter } from '../src/host/kiro-llm-adapter.ts'
import type { StoredOAuthCredential } from '../src/host/auth-protocol.ts'

function options(provider: string, model: string): GenerateOptions {
  return {
    provider,
    model,
    system: 'Keep the answer short.',
    messages: [{ role: 'user', content: [{ type: 'text', text: 'Hello' }] }],
  }
}

async function collect(source: AsyncIterable<StreamChunk>): Promise<StreamChunk[]> {
  const values: StreamChunk[] = []
  for await (const value of source) values.push(value)
  return values
}

function concat(parts: readonly Uint8Array[]): Uint8Array {
  const value = new Uint8Array(parts.reduce((sum, part) => sum + part.byteLength, 0))
  let offset = 0
  for (const part of parts) {
    value.set(part, offset)
    offset += part.byteLength
  }
  return value
}

function eventHeader(name: string, value: string): Uint8Array {
  const encoder = new TextEncoder()
  const nameBytes = encoder.encode(name)
  const valueBytes = encoder.encode(value)
  const bytes = new Uint8Array(1 + nameBytes.length + 1 + 2 + valueBytes.length)
  const view = new DataView(bytes.buffer)
  view.setUint8(0, nameBytes.length)
  bytes.set(nameBytes, 1)
  view.setUint8(1 + nameBytes.length, 7)
  view.setUint16(2 + nameBytes.length, valueBytes.length, false)
  bytes.set(valueBytes, 4 + nameBytes.length)
  return bytes
}

function eventFrame(eventType: string, payload: Record<string, unknown>): Uint8Array {
  const headers = concat([
    eventHeader(':message-type', 'event'),
    eventHeader(':event-type', eventType),
  ])
  const body = new TextEncoder().encode(JSON.stringify(payload))
  const total = 16 + headers.byteLength + body.byteLength
  const frame = new Uint8Array(total)
  const view = new DataView(frame.buffer)
  view.setUint32(0, total, false)
  view.setUint32(4, headers.byteLength, false)
  view.setUint32(8, crc32(frame.subarray(0, 8)) >>> 0, false)
  frame.set(headers, 12)
  frame.set(body, 12 + headers.byteLength)
  view.setUint32(total - 4, crc32(frame.subarray(0, total - 4)) >>> 0, false)
  return frame
}

describe('compatibility LLM adapters', () => {
  it('maps Command Code NDJSON output and preserves provider usage buckets', async () => {
    const request = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
      expect(new Headers(init?.headers).get('authorization')).toBe('Bearer command-sensitive')
      return new Response([
        JSON.stringify({ type: 'text-delta', text: 'Hello' }),
        JSON.stringify({ type: 'finish', usage: { inputTokens: 10, outputTokens: 3, inputTokenDetails: { cacheReadTokens: 2 } } }),
      ].join('\n'))
    }) as typeof fetch
    const adapter = new CommandCodeLlmAdapter(async () => 'command-sensitive', request)

    const chunks = await collect(adapter.stream(options('command-code', 'deepseek/deepseek-v4-flash')))

    expect(chunks).toContainEqual({ type: 'text-delta', index: 0, text: 'Hello' })
    expect(chunks).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 8, outputTokens: 3, cacheReadTokens: 2 },
    })
    expect(chunks.at(-1)).toEqual({ type: 'finish', reason: { kind: 'stop' } })
  })

  it('accepts CRLF Antigravity SSE while keeping the project id Host-side', async () => {
    const credential: StoredOAuthCredential = {
      version: 1,
      accessToken: 'google-sensitive',
      refreshToken: 'google-refresh-sensitive',
      expiresAt: Date.now() + 60_000,
      providerData: { projectId: 'project-private' },
    }
    const request = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
      expect(new Headers(init?.headers).get('authorization')).toBe('Bearer google-sensitive')
      expect(JSON.parse(String(init?.body))).toMatchObject({ project: 'project-private' })
      return new Response(`data: ${JSON.stringify({ response: {
        candidates: [{ content: { parts: [{ text: 'Hi' }] } }],
        usageMetadata: { promptTokenCount: 12, candidatesTokenCount: 4, cachedContentTokenCount: 2 },
      } })}\r\n\r\n`)
    }) as typeof fetch
    const adapter = new GoogleAntigravityLlmAdapter(async () => credential.accessToken, async () => credential, request)

    const chunks = await collect(adapter.stream(options('google-antigravity', 'gemini-3.6-flash')))

    expect(chunks).toContainEqual({ type: 'text-delta', index: 0, text: 'Hi' })
    expect(chunks).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 10, outputTokens: 4, cacheReadTokens: 2 },
    })
  })

  it('verifies Kiro event-stream checksums before projecting output', async () => {
    const credential: StoredOAuthCredential = {
      version: 1,
      accessToken: 'kiro-sensitive',
      refreshToken: 'kiro-refresh-sensitive',
      expiresAt: Date.now() + 60_000,
      providerData: { region: 'us-east-1' },
    }
    const frames = concat([
      eventFrame('assistantResponseEvent', { content: 'Kiro' }),
      eventFrame('metadataEvent', { tokenUsage: { uncachedInputTokens: 9, outputTokens: 2, cacheReadInputTokens: 1 } }),
    ])
    const request = vi.fn(async () => new Response(frames, { status: 200 })) as typeof fetch
    const adapter = new KiroLlmAdapter(async () => credential.accessToken, async () => credential, request)

    const chunks = await collect(adapter.stream(options('kiro', 'kiro-auto')))

    expect(chunks).toContainEqual({ type: 'text-delta', index: 0, text: 'Kiro' })
    expect(chunks).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 9, outputTokens: 2, cacheReadTokens: 1 },
    })

    const corrupt = eventFrame('assistantResponseEvent', { content: 'unsafe' })
    corrupt[corrupt.length - 5] ^= 1
    const rejected = new KiroLlmAdapter(
      async () => credential.accessToken,
      async () => credential,
      vi.fn(async () => new Response(corrupt, { status: 200 })) as typeof fetch,
    )
    await expect(collect(rejected.stream(options('kiro', 'kiro-auto')))).rejects.toThrow('checksum')
  })
})
