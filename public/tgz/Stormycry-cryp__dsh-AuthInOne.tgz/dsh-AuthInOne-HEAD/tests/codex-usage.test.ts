import { describe, expect, it, vi } from 'vitest'
import { fetchCodexUsage } from '../src/host/codex-usage.ts'

describe('fetchCodexUsage', () => {
  it('projects only primary and secondary percentages with account-scoped Host auth', async () => {
    let headers: Headers | undefined
    const result = await fetchCodexUsage('access-sensitive', 'account-sensitive', undefined, {
      sourceUrl: 'https://usage.example/codex',
      now: () => 99,
      fetch: vi.fn(async (_input, init) => {
        headers = new Headers(init?.headers)
        return Response.json({
          rate_limit: {
            primary_window: { used_percent: 25, limit_window_seconds: 18_000, reset_at: 1_800_000_000 },
            secondary_window: { used_percent: 40, limit_window_seconds: 604_800, reset_at: 1_800_086_400 },
          },
          access_token: 'must-not-project',
        })
      }) as typeof fetch,
    })
    expect(headers?.get('authorization')).toBe('Bearer access-sensitive')
    expect(headers?.get('chatgpt-account-id')).toBe('account-sensitive')
    expect(result).toMatchObject({
      status: 'available',
      generatedAt: 99,
      windows: [
        { id: 'primary', usedPercent: 25, remainingPercent: 75, windowSeconds: 18_000, resetAt: 1_800_000_000_000 },
        { id: 'secondary', usedPercent: 40, remainingPercent: 60, windowSeconds: 604_800, resetAt: 1_800_086_400_000 },
      ],
    })
    expect(JSON.stringify(result)).not.toMatch(/access-sensitive|account-sensitive|must-not-project/)
  })

  it('keeps malformed, unauthorized, and absent windows unavailable instead of fabricating zero', async () => {
    const invalid = await fetchCodexUsage('token', undefined, undefined, {
      fetch: vi.fn(async () => Response.json({ rate_limit: { primary_window: { used_percent: 101 } } })) as typeof fetch,
    })
    expect(invalid).toMatchObject({ status: 'unavailable', windows: [] })
    const unauthorized = await fetchCodexUsage('token', undefined, undefined, {
      fetch: vi.fn(async () => new Response(null, { status: 401 })) as typeof fetch,
    })
    expect(unauthorized).toMatchObject({ status: 'unavailable', windows: [] })
  })
})
