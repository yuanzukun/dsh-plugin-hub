import { existsSync } from 'node:fs'
import type { SDKMessage } from '@cursor/sdk'
import type { GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm'
import { describe, expect, it, vi } from 'vitest'
import {
  CursorSdkLlmAdapter,
  type CursorAgentLike,
  type CursorRunLike,
  type CursorSdkFacade,
} from '../src/host/cursor-sdk-adapter.ts'

function options(tools = false): GenerateOptions {
  return {
    provider: 'cursor',
    model: 'composer-2.5',
    system: 'Answer through DSH.',
    messages: [{ role: 'user', content: [{ type: 'text', text: 'Hello' }] }],
    ...tools ? { tools: [{ name: 'lookup', description: 'Look up one value', parameters: { type: 'object' } }] } : {},
  }
}

async function collect(source: AsyncIterable<StreamChunk>): Promise<StreamChunk[]> {
  const values: StreamChunk[] = []
  for await (const value of source) values.push(value)
  return values
}

function facade(messages: readonly SDKMessage[]): {
  sdk: CursorSdkFacade
  cancel: ReturnType<typeof vi.fn>
  created: { cwd?: string; apiKey?: string; prompt?: string }
} {
  const created: { cwd?: string; apiKey?: string; prompt?: string } = {}
  const cancel = vi.fn(async () => {})
  const run: CursorRunLike = {
    cancel,
    async *stream() {
      for (const message of messages) yield message
    },
  }
  const agent: CursorAgentLike = {
    send: vi.fn(async message => { created.prompt = message; return run }),
    close: vi.fn(),
  }
  return {
    created,
    cancel,
    sdk: {
      listModels: vi.fn(async apiKey => {
        created.apiKey = apiKey
        return [{ id: 'composer-2.5', displayName: 'Composer 2.5' }]
      }),
      createAgent: vi.fn(async input => {
        created.cwd = input.local.cwd
        created.apiKey = input.apiKey
        expect(input.local.settingSources).toEqual([])
        expect(input.local.sandboxOptions).toEqual({ enabled: true })
        return agent
      }),
    },
  }
}

describe('CursorSdkLlmAdapter', () => {
  it('uses the Host token for model discovery and returns no credential fields', async () => {
    const fixture = facade([])
    const adapter = new CursorSdkLlmAdapter(async () => 'cursor-sensitive', fixture.sdk)

    await expect(adapter.listModels('cursor')).resolves.toEqual([
      { provider: 'cursor', id: 'composer-2.5', name: 'Composer 2.5', inputModalities: ['text'] },
    ])
    expect(fixture.created.apiKey).toBe('cursor-sensitive')
  })

  it('projects text and exact usage from an isolated SDK run then removes its workspace', async () => {
    const fixture = facade([
      {
        type: 'assistant', agent_id: 'agent', run_id: 'run',
        message: { role: 'assistant', content: [{ type: 'text', text: 'Cursor reply' }] },
      },
      {
        type: 'usage', agent_id: 'agent', run_id: 'run',
        usage: { inputTokens: 10, outputTokens: 4, cacheReadTokens: 2, cacheWriteTokens: 1, totalTokens: 17, reasoningTokens: 3 },
      },
    ])
    const adapter = new CursorSdkLlmAdapter(async () => 'cursor-sensitive', fixture.sdk)

    const chunks = await collect(adapter.stream(options()))

    expect(chunks).toContainEqual({ type: 'text-delta', index: 0, text: 'Cursor reply' })
    expect(chunks).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 10, outputTokens: 4, cacheReadTokens: 2, cacheWriteTokens: 1, reasoningTokens: 3 },
    })
    expect(fixture.created.prompt).toContain('Do not use Cursor built-in')
    expect(fixture.created.prompt).not.toContain('cursor-sensitive')
    expect(fixture.created.cwd).toBeTruthy()
    expect(existsSync(fixture.created.cwd!)).toBe(false)
  })

  it('surfaces a declared DSH tool call and cancels the vendor run before execution continues', async () => {
    const fixture = facade([{
      type: 'tool_call', agent_id: 'agent', run_id: 'run', call_id: 'call-1',
      name: 'lookup', status: 'running', args: { query: 'value' },
    }])
    const adapter = new CursorSdkLlmAdapter(async () => 'cursor-sensitive', fixture.sdk)

    const chunks = await collect(adapter.stream(options(true)))

    expect(chunks).toContainEqual({
      type: 'block-end', index: 0,
      block: { type: 'tool-call', id: 'call-1', name: 'lookup', arguments: '{"query":"value"}' },
    })
    expect(chunks.at(-1)).toEqual({ type: 'finish', reason: { kind: 'tool-calls' } })
    expect(fixture.cancel).toHaveBeenCalledTimes(1)
  })

  it('fails closed when Cursor requests a built-in tool not declared by DSH', async () => {
    const fixture = facade([{
      type: 'tool_call', agent_id: 'agent', run_id: 'run', call_id: 'call-1',
      name: 'shell', status: 'running', args: { command: 'whoami' },
    }])
    const adapter = new CursorSdkLlmAdapter(async () => 'cursor-sensitive', fixture.sdk)

    await expect(collect(adapter.stream(options()))).rejects.toThrow('unavailable built-in tool')
    expect(fixture.created.cwd).toBeTruthy()
    expect(existsSync(fixture.created.cwd!)).toBe(false)
  })
})
