import { createHash } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import { describe, expect, it, vi } from 'vitest'
import {
  AuthProtocolError,
  OpenAICodexOAuthAdapter,
  type AuthProviderAdapter,
  type StoredOAuthCredential,
} from '../src/host/auth-protocol.ts'
import { DshOAuthCredentialStore } from '../src/host/auth-store.ts'
import { CodexAuthCoordinator, OpenAICodexAuthRuntime, createCompatibilityAuthRuntimes } from '../src/host/auth.ts'
import { KimiCodeDeviceAdapter } from '../src/host/kimi-auth-protocol.ts'
import { CommandCodeCompatibilityAdapter, CursorCompatibilityAdapter } from '../src/host/compat-auth-protocols.ts'
import { GoogleAntigravityCompatibilityAdapter } from '../src/host/google-antigravity-auth.ts'
import { KiroDeviceCompatibilityAdapter } from '../src/host/kiro-auth-protocol.ts'
import { PiOAuthBridgeAdapter, type BridgeOAuthAuth } from '../src/host/pi-oauth-bridge.ts'

const expiredCredential = (overrides: Partial<StoredOAuthCredential> = {}): StoredOAuthCredential => ({
  version: 1,
  accessToken: 'access-old-sensitive',
  refreshToken: 'refresh-old-sensitive',
  expiresAt: 1,
  accountId: 'account-full-sensitive',
  email: 'person@example.test',
  ...overrides,
})

async function categoryOf(promise: Promise<unknown>): Promise<string | undefined> {
  try {
    await promise
    return undefined
  } catch (error) {
    return error instanceof AuthProtocolError ? error.category : 'unexpected'
  }
}

function tokenResponse(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  })
}

describe('OpenAICodexOAuthAdapter', () => {
  it('keeps state and PKCE verifier on the Host and completes a valid loopback callback', async () => {
    let exchanged: URLSearchParams | undefined
    const adapter = new OpenAICodexOAuthAdapter({
      issuer: 'https://issuer.example',
      clientId: 'public-client',
      ports: [0],
      now: () => 1_000,
      fetch: vi.fn(async (_input, init) => {
        exchanged = new URLSearchParams(String(init?.body))
        return tokenResponse({
          access_token: 'access-new-sensitive',
          refresh_token: 'refresh-new-sensitive',
          expires_in: 3600,
        })
      }) as typeof fetch,
    })

    const handle = await adapter.start()
    const authorization = new URL(handle.authorizationUrl)
    const redirect = authorization.searchParams.get('redirect_uri')
    const state = authorization.searchParams.get('state')
    const challenge = authorization.searchParams.get('code_challenge')
    expect(redirect).toMatch(/^http:\/\/localhost:\d+\/auth\/callback$/)
    expect(state).toMatch(/^[A-Za-z0-9_-]{40,}$/)
    expect(handle.authorizationUrl).not.toContain('verifier')
    expect(handle.authorizationUrl).not.toContain('access-new-sensitive')

    const callback = await fetch(`${redirect}?code=one-time-code&state=${state}`)
    expect(callback.status).toBe(200)
    const credential = await handle.completion
    expect(credential).toMatchObject({
      accessToken: 'access-new-sensitive',
      refreshToken: 'refresh-new-sensitive',
      expiresAt: 3_601_000,
    })
    expect(exchanged?.get('code')).toBe('one-time-code')
    expect(exchanged?.get('redirect_uri')).toBe(redirect)
    expect(exchanged?.get('code_verifier')).toBeTruthy()
    expect(createHash('sha256').update(exchanged?.get('code_verifier') ?? '').digest('base64url')).toBe(challenge)
  })

  it('does not consume a transaction for a mismatched state', async () => {
    const adapter = new OpenAICodexOAuthAdapter({
      issuer: 'https://issuer.example',
      ports: [0],
      fetch: vi.fn(async () => tokenResponse({
        access_token: 'access-sensitive', refresh_token: 'refresh-sensitive', expires_in: 60,
      })) as typeof fetch,
    })
    const handle = await adapter.start()
    const authorization = new URL(handle.authorizationUrl)
    const redirect = authorization.searchParams.get('redirect_uri')!
    expect((await fetch(`${redirect}?code=wrong&state=wrong`)).status).toBe(400)
    const marker = Symbol('pending')
    expect(await Promise.race([handle.completion, Promise.resolve(marker)])).toBe(marker)
    expect((await fetch(`${redirect}?code=right&state=${authorization.searchParams.get('state')}`)).status).toBe(200)
    await expect(handle.completion).resolves.toMatchObject({ accessToken: 'access-sensitive' })
  })

  it('closes denial, cancellation, and timeout with stable categories', async () => {
    const denied = await new OpenAICodexOAuthAdapter({ issuer: 'https://issuer.example', ports: [0] }).start()
    const denialUrl = new URL(denied.authorizationUrl)
    const redirect = denialUrl.searchParams.get('redirect_uri')!
    await fetch(`${redirect}?error=access_denied&state=${denialUrl.searchParams.get('state')}`)
    expect(await categoryOf(denied.completion)).toBe('denied')

    const cancelled = await new OpenAICodexOAuthAdapter({ issuer: 'https://issuer.example', ports: [0] }).start()
    cancelled.cancel()
    expect(await categoryOf(cancelled.completion)).toBe('cancelled')

    const expired = await new OpenAICodexOAuthAdapter({ issuer: 'https://issuer.example', ports: [0], timeoutMs: 5 }).start()
    expect(await categoryOf(expired.completion)).toBe('expired')
  })

  it('rotates refresh tokens and maps terminal grant rejection', async () => {
    const request = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
      const body = new URLSearchParams(String(init?.body))
      expect(body.get('grant_type')).toBe('refresh_token')
      expect(body.get('refresh_token')).toBe('refresh-old-sensitive')
      return tokenResponse({ access_token: 'access-new-sensitive', refresh_token: 'refresh-rotated-sensitive', expires_in: 90 })
    }) as typeof fetch
    const adapter = new OpenAICodexOAuthAdapter({ issuer: 'https://issuer.example', now: () => 5_000, fetch: request })
    await expect(adapter.refresh(expiredCredential())).resolves.toMatchObject({
      accessToken: 'access-new-sensitive',
      refreshToken: 'refresh-rotated-sensitive',
      expiresAt: 95_000,
    })

    const rejected = new OpenAICodexOAuthAdapter({
      issuer: 'https://issuer.example',
      fetch: vi.fn(async () => tokenResponse({ error: 'invalid_grant' }, 400)) as typeof fetch,
    })
    expect(await categoryOf(rejected.refresh(expiredCredential()))).toBe('refresh-rejected')
  })

  it('revokes only the refresh credential and reports a sanitized failure category', async () => {
    let body: Record<string, unknown> | undefined
    const adapter = new OpenAICodexOAuthAdapter({
      issuer: 'https://issuer.example',
      clientId: 'public-client',
      fetch: vi.fn(async (_input, init) => {
        body = JSON.parse(String(init?.body)) as Record<string, unknown>
        return new Response(null, { status: 204 })
      }) as typeof fetch,
    })
    await adapter.revoke(expiredCredential())
    expect(body).toEqual({
      token: 'refresh-old-sensitive',
      token_type_hint: 'refresh_token',
      client_id: 'public-client',
    })

    const failed = new OpenAICodexOAuthAdapter({
      issuer: 'https://issuer.example',
      fetch: vi.fn(async () => new Response(null, { status: 503 })) as typeof fetch,
    })
    expect(await categoryOf(failed.revoke(expiredCredential()))).toBe('revocation-failed')
  })

  it('bounds refresh and revocation requests even when the caller supplies no signal', async () => {
    const stalledFetch = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => { reject(new DOMException('aborted', 'AbortError')) }, { once: true })
    })) as typeof fetch
    const adapter = new OpenAICodexOAuthAdapter({
      issuer: 'https://issuer.example',
      requestTimeoutMs: 5,
      fetch: stalledFetch,
    })
    expect(await categoryOf(adapter.refresh(expiredCredential()))).toBe('network')
    expect(await categoryOf(adapter.revoke(expiredCredential()))).toBe('revocation-failed')
  })
})

describe('PiOAuthBridgeAdapter', () => {
  it('contains a login failure that occurs before an authorization URL is ready', async () => {
    const adapter = new PiOAuthBridgeAdapter('broken', 'Broken', {
      login: async () => { throw new Error('upstream unavailable') },
      refresh: vi.fn(),
    })

    await expect(adapter.start()).rejects.toMatchObject({ category: 'network' })
    await Promise.resolve()
  })

  it('projects only a browser URL while preserving Provider metadata in the Host credential', async () => {
    const oauth: BridgeOAuthAuth = {
      login: async interaction => {
        interaction.notify({ type: 'auth_url', url: 'https://provider.example/authorize?state=public' })
        return {
          type: 'oauth', access: 'bridge-access-sensitive', refresh: 'bridge-refresh-sensitive',
          expires: Date.now() + 60_000, enterpriseUrl: 'https://enterprise.example', scopes: ['chat', 'models'],
        }
      },
      refresh: async credential => ({ ...credential, access: 'bridge-access-rotated', refresh: 'bridge-refresh-rotated' }),
    }
    const adapter = new PiOAuthBridgeAdapter('bridge', 'Bridge', oauth)

    const handle = await adapter.start()
    expect(handle.authorizationUrl).toBe('https://provider.example/authorize?state=public')
    expect(JSON.stringify(handle)).not.toMatch(/bridge-access-sensitive|bridge-refresh-sensitive/)
    const credential = await handle.completion
    expect(credential).toMatchObject({
      accessToken: 'bridge-access-sensitive', refreshToken: 'bridge-refresh-sensitive',
      providerData: { enterpriseUrl: 'https://enterprise.example', scopes: ['chat', 'models'] },
    })
    await expect(adapter.refresh(credential)).resolves.toMatchObject({
      accessToken: 'bridge-access-rotated', refreshToken: 'bridge-refresh-rotated',
    })
  })

  it('projects only the RFC 8628 user code and stops a pending bridge flow on cancel', async () => {
    const oauth: BridgeOAuthAuth = {
      login: interaction => new Promise((_resolve, reject) => {
        interaction.notify({
          type: 'device_code', userCode: 'ABCD-EFGH', verificationUri: 'https://device.example/',
          intervalSeconds: 5, expiresInSeconds: 600,
        })
        interaction.signal?.addEventListener('abort', () => { reject(new Error('cancelled')) }, { once: true })
      }),
      refresh: vi.fn(),
    }
    const adapter = new PiOAuthBridgeAdapter('device', 'Device', oauth)

    const handle = await adapter.start()
    expect(handle).toMatchObject({ verificationUrl: 'https://device.example/', userCode: 'ABCD-EFGH' })
    expect(JSON.stringify(handle)).not.toContain('device_code')
    handle.cancel()
    expect(await categoryOf(handle.completion)).toBe('cancelled')
  })

  it('keeps a manually returned authorization value inside the active Host transaction', async () => {
    let submitted: string | undefined
    const oauth: BridgeOAuthAuth = {
      login: async interaction => {
        interaction.notify({ type: 'auth_url', url: 'https://provider.example/authorize?state=public' })
        submitted = await interaction.prompt({
          type: 'manual_code', message: 'Paste the callback URL', placeholder: 'https://callback.example/',
        })
        return {
          type: 'oauth', access: 'manual-access-sensitive', refresh: 'manual-refresh-sensitive',
          expires: Date.now() + 60_000,
        }
      },
      refresh: vi.fn(),
    }
    const handle = await new PiOAuthBridgeAdapter('manual', 'Manual', oauth).start()

    expect(handle.inputPrompt).toEqual({
      kind: 'authorization-code', label: 'Paste the callback URL', placeholder: 'https://callback.example/',
    })
    expect(JSON.stringify(handle)).not.toContain('manual-access-sensitive')
    handle.submit?.('https://callback.example/?code=one-time&state=public')
    await expect(handle.completion).resolves.toMatchObject({ accessToken: 'manual-access-sensitive' })
    expect(submitted).toBe('https://callback.example/?code=one-time&state=public')
  })
})

describe('KimiCodeDeviceAdapter', () => {
  it('keeps the device code on the Host and follows pending plus slow_down before success', async () => {
    const waits: number[] = []
    const forms: URLSearchParams[] = []
    let polls = 0
    const adapter = new KimiCodeDeviceAdapter({
      oauthHost: 'https://kimi.example',
      clientId: 'public-client',
      now: () => 10_000,
      deviceId: 'device-public-id',
      sleep: async milliseconds => { waits.push(milliseconds) },
      fetch: vi.fn(async (_input, init) => {
        const form = new URLSearchParams(String(init?.body))
        forms.push(form)
        if (form.has('device_code')) {
          polls += 1
          if (polls === 1) return tokenResponse({ error: 'authorization_pending' }, 400)
          if (polls === 2) return tokenResponse({ error: 'slow_down' }, 400)
          return tokenResponse({ access_token: 'kimi-access-sensitive', refresh_token: 'kimi-refresh-sensitive', expires_in: 120 })
        }
        return tokenResponse({
          device_code: 'kimi-device-code-sensitive',
          user_code: 'ABCD-EFGH',
          verification_uri: 'https://kimi.example/device',
          verification_uri_complete: 'https://kimi.example/device?user_code=ABCD-EFGH',
          expires_in: 300,
          interval: 1,
        })
      }) as typeof fetch,
    })
    const handle = await adapter.start()
    expect(handle).toMatchObject({
      userCode: 'ABCD-EFGH',
      verificationUrl: 'https://kimi.example/device',
      authorizationUrl: 'https://kimi.example/device?user_code=ABCD-EFGH',
    })
    expect(JSON.stringify(handle)).not.toContain('kimi-device-code-sensitive')
    await expect(handle.completion).resolves.toMatchObject({
      accessToken: 'kimi-access-sensitive',
      refreshToken: 'kimi-refresh-sensitive',
      expiresAt: 130_000,
    })
    expect(waits).toEqual([1_000, 1_000, 6_000])
    expect(forms.at(-1)?.get('device_code')).toBe('kimi-device-code-sensitive')
  })

  it('maps denial and cancellation to stable public categories', async () => {
    const denied = new KimiCodeDeviceAdapter({
      oauthHost: 'https://kimi.example',
      sleep: async () => {},
      fetch: vi.fn(async (_input, init) => {
        const form = new URLSearchParams(String(init?.body))
        return form.has('device_code')
          ? tokenResponse({ error: 'access_denied' }, 400)
          : tokenResponse({
              device_code: 'secret-device', user_code: 'CODE', verification_uri: 'https://kimi.example/device',
              verification_uri_complete: 'https://kimi.example/device?user_code=CODE', expires_in: 300, interval: 1,
            })
      }) as typeof fetch,
    })
    expect(await categoryOf((await denied.start()).completion)).toBe('denied')

    const cancelled = new KimiCodeDeviceAdapter({
      oauthHost: 'https://kimi.example',
      fetch: vi.fn(async () => tokenResponse({
        device_code: 'secret-device', user_code: 'CODE', verification_uri: 'https://kimi.example/device',
        verification_uri_complete: 'https://kimi.example/device?user_code=CODE', expires_in: 300, interval: 30,
      })) as typeof fetch,
    })
    const handle = await cancelled.start()
    handle.cancel()
    expect(await categoryOf(handle.completion)).toBe('cancelled')
  })

  it('rotates refresh tokens and maps terminal refresh rejection', async () => {
    const adapter = new KimiCodeDeviceAdapter({
      oauthHost: 'https://kimi.example',
      now: () => 5_000,
      fetch: vi.fn(async () => tokenResponse({
        access_token: 'kimi-new-access', refresh_token: 'kimi-new-refresh', expires_in: 90,
      })) as typeof fetch,
    })
    await expect(adapter.refresh(expiredCredential())).resolves.toMatchObject({
      accessToken: 'kimi-new-access', refreshToken: 'kimi-new-refresh', expiresAt: 95_000,
    })
    const rejected = new KimiCodeDeviceAdapter({
      oauthHost: 'https://kimi.example',
      fetch: vi.fn(async () => tokenResponse({ error: 'invalid_grant' }, 400)) as typeof fetch,
    })
    expect(await categoryOf(rejected.refresh(expiredCredential()))).toBe('refresh-rejected')
  })
})

describe('compatibility Auth adapters', () => {
  it('keeps the Cursor verifier on the Host and rotates the refresh credential', async () => {
    let pollUrl: URL | undefined
    const payload = Buffer.from(JSON.stringify({ sub: 'cursor-account', email: 'person@example.test', exp: 4_000 })).toString('base64url')
    const access = `x.${payload}.y`
    const request = vi.fn(async (input: string | URL | Request) => {
      const url = new URL(String(input))
      if (url.pathname.endsWith('/auth/poll')) {
        pollUrl = url
        return tokenResponse({ accessToken: access, refreshToken: 'cursor-refresh-sensitive' })
      }
      return tokenResponse({ accessToken: access, refreshToken: 'cursor-refresh-rotated-sensitive' })
    }) as typeof fetch
    const adapter = new CursorCompatibilityAdapter({
      loginUrl: 'https://cursor.example/login',
      pollUrl: 'https://cursor.example/auth/poll',
      refreshUrl: 'https://cursor.example/auth/refresh',
      fetch: request,
      sleep: async () => {},
      now: () => 1_000,
    })
    const handle = await adapter.start()
    const publicUrl = new URL(handle.authorizationUrl)
    expect(publicUrl.searchParams.get('challenge')).toMatch(/^[A-Za-z0-9_-]{40,}$/)
    expect(publicUrl.searchParams.has('verifier')).toBe(false)
    await expect(handle.completion).resolves.toMatchObject({
      accessToken: access,
      refreshToken: 'cursor-refresh-sensitive',
      accountId: 'cursor-account',
      email: 'person@example.test',
    })
    expect(pollUrl?.searchParams.get('verifier')).toMatch(/^[A-Za-z0-9_-]{40,}$/)
    await expect(adapter.refresh(expiredCredential({ refreshToken: 'cursor-refresh-sensitive' }))).resolves.toMatchObject({
      refreshToken: 'cursor-refresh-rotated-sensitive',
    })
  })

  it('accepts Command Code only through the matching Host loopback state', async () => {
    const adapter = new CommandCodeCompatibilityAdapter({
      studioUrl: 'https://command.example', callbackPorts: [0], timeoutMs: 5_000, now: () => 1_000,
    })
    const handle = await adapter.start()
    const authorization = new URL(handle.authorizationUrl)
    const callback = authorization.searchParams.get('callback')
    const state = authorization.searchParams.get('state')
    expect(callback).toMatch(/^http:\/\/127\.0\.0\.1:\d+\/callback$/)
    expect(state).toMatch(/^[A-Za-z0-9_-]{40,}$/)
    const rejected = await fetch(callback!, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ apiKey: 'command-sensitive', userId: 'user-1', userName: 'Person', keyName: 'CLI', state: 'wrong' }),
    })
    expect(rejected.status).toBe(400)
    const accepted = await fetch(callback!, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ apiKey: 'command-sensitive', userId: 'user-1', userName: 'Person', keyName: 'CLI', state }),
    })
    expect(accepted.status).toBe(200)
    await expect(handle.completion).resolves.toMatchObject({ accountId: 'user-1' })
  })

  it('stores a valid Command Code callback without projecting the key', async () => {
    const adapter = new CommandCodeCompatibilityAdapter({
      studioUrl: 'https://command.example', callbackPorts: [0], timeoutMs: 5_000, now: () => 1_000,
    })
    const handle = await adapter.start()
    const authorization = new URL(handle.authorizationUrl)
    const response = await fetch(authorization.searchParams.get('callback')!, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        apiKey: 'command-sensitive', userId: 'user-1', userName: 'Person', keyName: 'CLI',
        state: authorization.searchParams.get('state'),
      }),
    })
    expect(response.status).toBe(200)
    await expect(handle.completion).resolves.toMatchObject({
      accessToken: 'command-sensitive', refreshToken: 'command-sensitive', accountId: 'user-1',
    })
    expect(JSON.stringify({ authorizationUrl: handle.authorizationUrl, expiresAt: handle.expiresAt })).not.toContain('command-sensitive')
  })

  it('runs Kiro Builder ID registration, device polling, and refresh in the Host', async () => {
    const requests: Array<{ path: string; body: Record<string, unknown> }> = []
    let polls = 0
    const adapter = new KiroDeviceCompatibilityAdapter({
      oidcEndpoint: 'https://oidc.example',
      now: () => 1_000,
      sleep: async () => {},
      fetch: vi.fn(async (input, init) => {
        const path = new URL(String(input)).pathname
        const body = JSON.parse(String(init?.body)) as Record<string, unknown>
        requests.push({ path, body })
        if (path === '/client/register') return tokenResponse({ clientId: 'kiro-client-sensitive', clientSecret: 'kiro-secret-sensitive' })
        if (path === '/device_authorization') return tokenResponse({
          deviceCode: 'kiro-device-sensitive', userCode: 'ABCD-EFGH',
          verificationUri: 'https://device.example/', verificationUriComplete: 'https://device.example/?user_code=ABCD-EFGH',
          expiresIn: 300, interval: 1,
        })
        polls += 1
        if (polls === 1) return tokenResponse({ __type: 'AuthorizationPendingException' }, 400)
        return tokenResponse({ accessToken: `kiro-access-${String(polls)}`, refreshToken: `kiro-refresh-${String(polls)}`, expiresIn: 3600 })
      }) as typeof fetch,
    })
    const handle = await adapter.start()
    expect(handle).toMatchObject({ authorizationUrl: 'https://device.example/?user_code=ABCD-EFGH', userCode: 'ABCD-EFGH' })
    expect(JSON.stringify(handle)).not.toContain('kiro-device-sensitive')
    const credential = await handle.completion
    expect(credential).toMatchObject({
      accessToken: 'kiro-access-2', refreshToken: 'kiro-refresh-2',
      providerData: { clientId: 'kiro-client-sensitive', clientSecret: 'kiro-secret-sensitive' },
    })
    await expect(adapter.refresh(credential)).resolves.toMatchObject({ accessToken: 'kiro-access-3', refreshToken: 'kiro-refresh-3' })
    expect(requests.find(entry => entry.path === '/device_authorization')?.body).toMatchObject({ startUrl: 'https://view.awsapps.com/start' })
  })

  it('keeps Antigravity state and PKCE in the Host through project discovery', async () => {
    let tokenBody: URLSearchParams | undefined
    const adapter = new GoogleAntigravityCompatibilityAdapter({
      authorizationEndpoint: 'https://accounts.example/authorize', tokenEndpoint: 'https://oauth.example/token',
      cloudCodeEndpoint: 'https://cloud.example', dailyCloudCodeEndpoint: 'https://daily.example',
      callbackPort: 0, clientId: 'google-client', clientSecret: 'google-secret', now: () => 1_000,
      fetch: vi.fn(async (input, init) => {
        const url = String(input)
        if (url.includes('/token')) {
          tokenBody = new URLSearchParams(String(init?.body))
          return tokenResponse({ access_token: 'google-access-sensitive', refresh_token: 'google-refresh-sensitive', expires_in: 3600 })
        }
        if (url.includes('loadCodeAssist')) return tokenResponse({ cloudaicompanionProject: 'project-123' })
        return tokenResponse({}, 404)
      }) as typeof fetch,
    })
    const handle = await adapter.start()
    const authorization = new URL(handle.authorizationUrl)
    const redirect = authorization.searchParams.get('redirect_uri')
    const state = authorization.searchParams.get('state')
    expect(authorization.searchParams.get('code_challenge')).toMatch(/^[A-Za-z0-9_-]{40,}$/)
    expect(authorization.searchParams.has('code_verifier')).toBe(false)
    const callback = await fetch(`${redirect}?code=official-code&state=${encodeURIComponent(state!)}`)
    expect(callback.status).toBe(200)
    await expect(handle.completion).resolves.toMatchObject({
      accessToken: 'google-access-sensitive', refreshToken: 'google-refresh-sensitive',
      providerData: { projectId: 'project-123' },
    })
    expect(tokenBody?.get('code_verifier')).toMatch(/^[A-Za-z0-9_-]{40,}$/)
    expect(tokenBody?.get('client_secret')).toBe('google-secret')
  })
})

function memoryContext(initial?: StoredOAuthCredential): {
  context: Context
  readValue: () => string | undefined
} {
  let value = initial === undefined ? undefined : JSON.stringify(initial)
  return {
    context: {
      credentials: {
        resolve: vi.fn(async () => value === undefined ? undefined : { value, source: 'test' }),
        set: vi.fn(async (_ref, next: string) => { value = next }),
        unset: vi.fn(async () => { value = undefined }),
      },
    } as unknown as Context,
    readValue: () => value,
  }
}

describe('DshOAuthCredentialStore', () => {
  it('single-flights concurrent refresh and persists the rotated credential once', async () => {
    const memory = memoryContext(expiredCredential())
    const store = new DshOAuthCredentialStore(memory.context)
    let refreshes = 0
    const adapter: AuthProviderAdapter = {
      id: 'test',
      name: 'Test',
      start: vi.fn(),
      refresh: async () => {
        refreshes += 1
        await Promise.resolve()
        return expiredCredential({
          accessToken: 'access-new-sensitive',
          refreshToken: 'refresh-rotated-sensitive',
          expiresAt: Date.now() + 3_600_000,
        })
      },
      revoke: vi.fn(),
    }
    await expect(Promise.all([store.accessToken(adapter), store.accessToken(adapter)])).resolves.toEqual([
      'access-new-sensitive', 'access-new-sensitive',
    ])
    expect(refreshes).toBe(1)
    expect(memory.readValue()).toContain('refresh-rotated-sensitive')
  })

  it('marks only the current credential generation for reauthorization after terminal rejection', async () => {
    const memory = memoryContext(expiredCredential())
    const store = new DshOAuthCredentialStore(memory.context)
    const adapter: AuthProviderAdapter = {
      id: 'test',
      name: 'Test',
      start: vi.fn(),
      refresh: vi.fn(async () => { throw new AuthProtocolError('refresh-rejected') }),
      revoke: vi.fn(),
    }
    expect(await categoryOf(store.accessToken(adapter))).toBe('refresh-rejected')
    expect(JSON.parse(memory.readValue() ?? '{}')).toMatchObject({ needsReauth: true })
  })

  it('deletes the plugin credential without touching other DSH data', async () => {
    const memory = memoryContext(expiredCredential())
    const store = new DshOAuthCredentialStore(memory.context)
    await store.delete()
    expect(memory.readValue()).toBeUndefined()
    await expect(store.status()).resolves.toEqual({ connected: false, needsReauth: false })
  })
})

describe('CodexAuthCoordinator', () => {
  it('projects only public authorization state and a masked account label', async () => {
    let release!: () => void
    const completed = new Promise<void>(resolve => { release = resolve })
    const coordinator = new CodexAuthCoordinator({
      status: async () => ({ connected: false, needsReauth: false, accountLabel: null }),
      login: async (_signal, onReady) => {
        onReady({ authorizationUrl: 'https://issuer.example/authorize?state=public-state', expiresAt: 99 })
        await completed
        return 'p***n@example.test'
      },
      logout: async () => ({}),
    }, vi.fn(), vi.fn())
    const pending = await coordinator.start()
    expect(pending).toMatchObject({ status: 'pending', method: 'browser-oauth' })
    const serialized = JSON.stringify(pending)
    expect(serialized).not.toMatch(/access-sensitive|refresh-sensitive|one-time-code/)
    release()
    await vi.waitFor(() => { expect(coordinator.snapshot().status).toBe('connected') })
    expect(coordinator.snapshot().accountLabel).toBe('p***n@example.test')
  })

  it('cancels the matching attempt and logs out to a signed-out projection', async () => {
    const coordinator = new CodexAuthCoordinator({
      status: async () => ({ connected: false, needsReauth: false, accountLabel: null }),
      login: (signal, onReady) => new Promise((_resolve, reject) => {
        onReady({ authorizationUrl: 'https://issuer.example/authorize', expiresAt: 99 })
        signal.addEventListener('abort', () => { reject(new AuthProtocolError('cancelled')) }, { once: true })
      }),
      logout: async () => ({}),
    }, vi.fn(), vi.fn())
    const pending = await coordinator.start()
    expect(coordinator.cancel(pending.attemptId ?? '')).toMatchObject({ status: 'cancelled' })
    await vi.waitFor(() => { expect(coordinator.snapshot().status).toBe('cancelled') })
    await expect(coordinator.logout()).resolves.toMatchObject({ status: 'signed-out' })
  })

  it('accepts a bounded one-time value only for the matching active attempt', async () => {
    const submit = vi.fn()
    const coordinator = new CodexAuthCoordinator({
      status: async () => ({ connected: false, needsReauth: false, accountLabel: null }),
      login: (signal, onReady) => new Promise((_resolve, reject) => {
        onReady({
          authorizationUrl: 'https://issuer.example/authorize', expiresAt: 99,
          inputPrompt: { kind: 'authorization-code', label: 'Authorization code' },
        })
        signal.addEventListener('abort', () => { reject(new AuthProtocolError('cancelled')) }, { once: true })
      }),
      submit,
      logout: async () => ({}),
    }, vi.fn(), vi.fn())
    const pending = await coordinator.start()

    expect(pending.inputPrompt).toMatchObject({ kind: 'authorization-code' })
    expect(() => coordinator.submit('wrong-attempt', 'code')).toThrow(AuthProtocolError)
    expect(() => coordinator.submit(pending.attemptId!, ' ')).toThrow(AuthProtocolError)
    coordinator.submit(pending.attemptId!, 'one-time-code')
    expect(submit).toHaveBeenCalledWith('one-time-code')
    coordinator.cancel(pending.attemptId!)
  })
})

describe('OpenAICodexAuthRuntime', () => {
  it('removes a credential written after cancellation and clears the transaction', async () => {
    let stored: string | undefined
    let releaseWrite!: () => void
    let writeStarted!: () => void
    const writeGate = new Promise<void>(resolve => { releaseWrite = resolve })
    const started = new Promise<void>(resolve => { writeStarted = resolve })
    let complete!: (credential: StoredOAuthCredential) => void
    const completion = new Promise<StoredOAuthCredential>(resolve => { complete = resolve })
    const context = {
      credentials: {
        resolve: vi.fn(async () => stored === undefined ? undefined : { value: stored, source: 'test' }),
        set: vi.fn(async (_ref, value: string) => {
          writeStarted()
          await writeGate
          stored = value
        }),
        unset: vi.fn(async () => { stored = undefined }),
      },
      llm: { registerAdapter: vi.fn(() => vi.fn()) },
    } as unknown as Context
    const adapter: AuthProviderAdapter = {
      id: 'openai-codex',
      name: 'OpenAI Codex',
      start: vi.fn(async () => ({
        authorizationUrl: 'https://issuer.example/authorize?state=public',
        expiresAt: Date.now() + 60_000,
        completion,
        cancel: vi.fn(),
      })),
      refresh: vi.fn(),
      revoke: vi.fn(),
    }
    const runtime = new OpenAICodexAuthRuntime(context, adapter)
    const pending = await runtime.coordinator.start()
    complete(expiredCredential({ expiresAt: Date.now() + 60_000 }))
    await started
    runtime.coordinator.cancel(pending.attemptId ?? '')
    releaseWrite()
    await vi.waitFor(() => { expect(runtime.coordinator.snapshot().status).toBe('cancelled') })
    await vi.waitFor(() => { expect(stored).toBeUndefined() })
    await expect(runtime.coordinator.synchronize()).resolves.toMatchObject({ status: 'signed-out' })
    runtime.dispose()
  })

  it('deletes the local credential before best-effort remote revocation', async () => {
    const memory = memoryContext(expiredCredential({ expiresAt: Date.now() + 60_000 }))
    const context = memory.context as unknown as Context & { llm: { registerAdapter: () => () => void } }
    context.llm = { registerAdapter: () => vi.fn() }
    const adapter: AuthProviderAdapter = {
      id: 'openai-codex',
      name: 'OpenAI Codex',
      start: vi.fn(),
      refresh: vi.fn(),
      revoke: vi.fn(async () => {
        expect(memory.readValue()).toBeUndefined()
        throw new AuthProtocolError('revocation-failed')
      }),
    }
    const runtime = new OpenAICodexAuthRuntime(context, adapter)
    await expect(runtime.coordinator.synchronize()).resolves.toMatchObject({ status: 'connected' })
    await expect(runtime.coordinator.logout()).resolves.toMatchObject({
      status: 'signed-out',
      errorCategory: 'revocation-failed',
    })
    expect(memory.readValue()).toBeUndefined()
    runtime.dispose()
  })
})

describe('Auth Provider parity runtime assembly', () => {
  it('activates a real model adapter for every compatibility login after a Host credential is present', async () => {
    const memory = memoryContext(expiredCredential({ expiresAt: Date.now() + 60_000 }))
    const registerAdapter = vi.fn(() => vi.fn())
    const context = memory.context as unknown as Context & { llm: { registerAdapter: typeof registerAdapter } }
    context.llm = { registerAdapter }
    const runtimes = createCompatibilityAuthRuntimes(context)

    await Promise.all(runtimes.map(runtime => runtime.coordinator.synchronize()))

    expect(runtimes.map(runtime => runtime.coordinator.snapshot().id)).toEqual([
      'xai',
      'anthropic',
      'github-copilot',
      'command-code',
      'cursor',
      'google-antigravity',
      'kiro',
    ])
    expect(registerAdapter.mock.calls.map(([providers]) => providers)).toEqual([
      ['xai'],
      ['anthropic'],
      ['github-copilot'],
      ['command-code'],
      ['cursor'],
      ['google-antigravity'],
      ['kiro'],
    ])
    expect(runtimes.every(runtime => runtime.coordinator.snapshot().status === 'connected')).toBe(true)

    for (const runtime of runtimes) runtime.dispose()
  })
})
