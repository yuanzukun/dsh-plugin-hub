import { describe, expect, it } from 'vitest'
import { shouldProjectProviderConnection } from '../src/host/provider-projection.ts'

describe('Provider instance projection', () => {
  it('keeps catalog-only Auth entries out while retaining configured and connected instances', () => {
    expect(shouldProjectProviderConnection({
      provider: 'anthropic', hasLiveRoute: false, hasProfile: false, authStatus: 'signed-out',
    })).toBe(false)
    expect(shouldProjectProviderConnection({
      provider: 'github-copilot', hasLiveRoute: false, hasProfile: false, authStatus: 'cancelled',
    })).toBe(false)
    expect(shouldProjectProviderConnection({
      provider: 'github-copilot', hasLiveRoute: false, hasProfile: false, authStatus: 'error',
    })).toBe(false)
    expect(shouldProjectProviderConnection({
      provider: 'openai-codex', hasLiveRoute: true, hasProfile: false, authStatus: 'connected',
    })).toBe(true)
    expect(shouldProjectProviderConnection({
      provider: 'openai-codex', hasLiveRoute: false, hasProfile: false, authStatus: 'needs-reauth',
    })).toBe(true)
    expect(shouldProjectProviderConnection({
      provider: 'anthropic', hasLiveRoute: false, hasProfile: true, authStatus: 'signed-out',
    })).toBe(true)
    expect(shouldProjectProviderConnection({
      provider: 'deepseek-official', hasLiveRoute: false, hasProfile: false, authStatus: null,
    })).toBe(true)
  })
})
