import type { Context } from '@deepseek-ai/cordis'
import { AttachmentId } from '@deepseek-ai/dsh-attachment'
import {
  createUserMessage,
  deepFreeze,
  markAgentLoopRequest,
  type GenerateOptions,
  type StreamChunk,
} from '@deepseek-ai/dsh-llm'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import { describe, expect, it } from 'vitest'
import {
  installVisionFallback,
  listVisionRoutes,
  resolveVisionFallbackConfig,
  type VisionFallbackConfig,
} from '../src/host/vision-fallback.ts'

const image = {
  type: 'image' as const,
  attachment: {
    attachmentId: AttachmentId(`sha256:${'a'.repeat(64)}`),
    mediaType: 'image/png' as const,
    bytes: 10,
    width: 2,
    height: 2,
  },
}

function successful(text: string): StreamChunk[] {
  return [
    { type: 'block-start', index: 0, blockType: 'text' },
    { type: 'text-delta', index: 0, text },
    { type: 'block-end', index: 0, block: { type: 'text', text } },
    { type: 'usage', usage: { inputTokens: 8, outputTokens: 3 } },
    { type: 'finish', reason: { kind: 'stop' } },
  ]
}

async function collect(stream: AsyncIterable<StreamChunk>): Promise<StreamChunk[]> {
  const chunks: StreamChunk[] = []
  for await (const chunk of stream) chunks.push(chunk)
  return chunks
}

function harness(
  config: VisionFallbackConfig,
  visionChunks = successful('A blue diagram with two labeled boxes.'),
  mainModalities: readonly ('text' | 'image')[] = ['text'],
) {
  let middleware: ((options: GenerateOptions, next: () => AsyncIterable<StreamChunk>) => AsyncIterable<StreamChunk>) | undefined
  const sessions = new Map<string, Session>()
  const calls: GenerateOptions[] = []
  const terminal = (options: GenerateOptions): AsyncIterable<StreamChunk> => (async function* () {
    calls.push(options)
    yield* options.provider === 'vision' ? visionChunks : successful('main answer')
  })()
  const ctx = {
    on(event: string, listener: typeof middleware) {
      if (event === 'llm/stream') middleware = listener
      return () => {}
    },
    sessions: { get: (id: SessionId) => sessions.get(String(id)) },
    llm: {
      async resolveModelInfo(provider: string, model: string) {
        return {
          provider,
          id: model,
          name: model,
          inputModalities: provider === 'vision' ? ['text', 'image'] as const : mainModalities,
        }
      },
      listProviders: () => [],
      listModels: async () => [],
      stream(options: GenerateOptions) {
        if (middleware === undefined) throw new Error('middleware is not installed')
        return middleware(options, () => terminal(options))
      },
    },
  } as unknown as Context
  installVisionFallback(ctx, () => config)
  const session = Session.create(SessionId('vision-session'))
  sessions.set(String(session.id), session)
  const source = createUserMessage({
    content: [{ type: 'text', text: 'What changed?' }, image, image],
    source: { kind: 'user' },
  })
  session.append('user/message', source, { surfaceOp: 'append' })
  const request = markAgentLoopRequest(deepFreeze<GenerateOptions>({
    provider: 'main',
    model: 'text-only',
    messages: [source],
    sessionId: session.id,
  }))
  return { ctx, session, source, request, calls, sessions }
}

describe('vision fallback request middleware', () => {
  it('lists only usable configured instances with authoritative image metadata and stable access identity', async () => {
    const ctx = {
      llm: {
        listProviders: () => [],
        listModels: async (provider: string) => provider === 'broken'
          ? Promise.reject(new Error('catalog unavailable'))
          : [{ id: 'seeing', name: 'Seeing' }, { id: 'unknown', name: 'Vision XL' }],
        resolveModelInfo: async (_provider: string, model: string) => ({
          provider: 'ignored', id: model, name: model,
          ...(model === 'seeing' ? { inputModalities: ['text', 'image'] as const } : {}),
        }),
      },
    } as unknown as Context
    const routes = await listVisionRoutes(ctx, [
      { id: 'auth', name: 'Account', active: true, configured: true, credentialConfigured: true, accessType: 'account-auth', accountLabel: 'a***@example.com' },
      { id: 'missing-key', name: 'Missing key', active: true, configured: true, credentialConfigured: false, accessType: 'api', accountLabel: null },
      { id: 'deleted', name: 'Deleted', active: false, configured: false, credentialConfigured: null, accessType: 'custom-api', accountLabel: null },
      { id: 'broken', name: 'Broken', active: true, configured: true, credentialConfigured: true, accessType: 'custom-api', accountLabel: null },
    ])
    expect(routes).toEqual([{
      provider: 'auth', providerName: 'Account', model: 'seeing', modelName: 'Seeing',
      accessType: 'account-auth', accountLabel: 'a***@example.com',
    }])
    expect(JSON.stringify(routes)).not.toContain('Vision XL')
  })

  it('is off by default and validates bounded policy', () => {
    expect(resolveVisionFallbackConfig(undefined)).toMatchObject({ enabled: false, maxOutputTokens: 512, timeoutMs: 60_000 })
    expect(() => resolveVisionFallbackConfig({ maxOutputTokens: 1 })).toThrow(/maxOutputTokens/)
    expect(() => resolveVisionFallbackConfig({ timeoutMs: 999 })).toThrow(/timeoutMs/)
  })

  it('leaves native multimodal and disabled-fallback requests unchanged', async () => {
    const native = harness({ enabled: true, provider: 'vision', model: 'seeing' }, successful('unused'), ['text', 'image'])
    await collect(native.ctx.llm.stream(native.request))
    expect(native.calls).toHaveLength(1)
    expect(native.calls[0]?.provider).toBe('main')
    expect(native.calls[0]?.messages[0]?.content.filter(block => block.type === 'image')).toHaveLength(2)

    const disabled = harness({ enabled: false, provider: 'vision', model: 'seeing' })
    await collect(disabled.ctx.llm.stream(disabled.request))
    expect(disabled.calls).toHaveLength(1)
    expect(disabled.calls[0]?.provider).toBe('main')
    expect(disabled.calls[0]?.messages[0]?.content.filter(block => block.type === 'image')).toHaveLength(2)
  })

  it('describes all images once, logs exact request/result provenance, and reuses it after resume or fork', async () => {
    const setup = harness({ enabled: true, provider: 'vision', model: 'seeing' })
    await expect(collect(setup.ctx.llm.stream(setup.request))).resolves.toEqual(successful('main answer'))
    expect(setup.calls).toHaveLength(2)
    const auxiliary = setup.calls[0]!
    expect(auxiliary.provider).toBe('vision')
    expect(auxiliary.messages[0]?.content.filter(block => block.type === 'image')).toHaveLength(2)
    const main = setup.calls[1]!
    expect(main.messages[0]?.content.some(block => block.type === 'image')).toBe(false)
    expect(main.messages[0]?.content.some(block => block.type === 'text' && block.text.includes('A blue diagram'))).toBe(true)

    const helpers = setup.session.events.filter(event => event.type === 'user/message')
      .map(event => event.data.source)
      .filter(source => source.kind.startsWith('auth-in-one-vision-'))
    expect(helpers).toHaveLength(2)
    expect(helpers[0]).toMatchObject({ kind: 'auth-in-one-vision-request', route: { provider: 'vision', model: 'seeing' } })
    expect(helpers[1]).toMatchObject({ kind: 'auth-in-one-vision-result', status: 'success', usage: { inputTokens: 8, outputTokens: 3 } })

    const fork = Session.create(SessionId('vision-fork'), setup.session.events)
    setup.sessions.set(String(fork.id), fork)
    const resumed = markAgentLoopRequest(deepFreeze<GenerateOptions>({ ...setup.request, sessionId: fork.id }))
    await collect(setup.ctx.llm.stream(resumed))
    expect(setup.calls.filter(call => call.provider === 'vision')).toHaveLength(1)
  })

  it('fails recoverably without dispatching the main model when the vision Provider fails', async () => {
    const setup = harness(
      { enabled: true, provider: 'vision', model: 'seeing' },
      [{ type: 'finish', reason: { kind: 'error', failure: { code: 'AUTH_MISSING', message: 'secret upstream detail' } } }],
    )
    const chunks = await collect(setup.ctx.llm.stream(setup.request))
    expect(chunks).toEqual([expect.objectContaining({
      type: 'finish',
      reason: expect.objectContaining({ kind: 'error', failure: expect.objectContaining({ code: 'VISION_FALLBACK_FAILED' }) }),
    })])
    expect(setup.calls.map(call => call.provider)).toEqual(['vision'])
    expect(JSON.stringify(setup.session.events)).not.toContain('secret upstream detail')
    expect(setup.session.events.findLast(event => event.type === 'user/message')?.data.source)
      .toMatchObject({ kind: 'auth-in-one-vision-result', status: 'error', errorCode: 'AUTH_MISSING' })
  })
})
