import type { SpawnSyncReturns } from 'node:child_process'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  parseInstallerArgs,
  resolveLaunch,
  runInstaller,
  superviseRestart,
  type InstallerOptions,
  type InstallerRuntime,
  type LaunchCommand,
  type RestartPlan,
} from '../src/install.ts'

const originalDshHome = process.env.DSH_HOME
const temporaryDirectories: string[] = []

afterEach(async () => {
  process.env.DSH_HOME = originalDshHome
  await Promise.all(temporaryDirectories.splice(0).map(path => rm(path, { force: true, recursive: true })))
})

function successfulRun(): SpawnSyncReturns<Buffer> {
  return {
    pid: 1,
    output: [null, null, null],
    stdout: Buffer.alloc(0),
    stderr: Buffer.alloc(0),
    status: 0,
    signal: null,
  }
}

function runtime(overrides: Partial<InstallerRuntime> = {}): InstallerRuntime {
  return {
    assertCompatibleHost: vi.fn(),
    run: vi.fn(() => successfulRun()),
    findListeners: vi.fn(() => [123]),
    processCwd: vi.fn(() => '/repo'),
    processCommand: vi.fn(() => 'node /repo/apps/cli/src/bin.ts web'),
    processExists: vi.fn(() => false),
    signal: vi.fn(),
    start: vi.fn(async () => 456),
    startSupervisor: vi.fn(async () => 789),
    probe: vi.fn(async () => true),
    sleep: vi.fn(async () => undefined),
    now: vi.fn(() => new Date('2026-08-15T00:00:00.000Z')),
    ...overrides,
  }
}

async function sourceRoot(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), 'auth-in-one-dsh-'))
  temporaryDirectories.push(root)
  await writeFile(join(root, 'package.json'), JSON.stringify({ scripts: { dsh: 'node apps/cli/src/bin.ts' } }))
  return root
}

function options(root: string): InstallerOptions {
  return {
    action: 'install',
    profile: 'web',
    url: new URL('http://127.0.0.1:3080/'),
    sourceRoot: root,
    packageSpec: 'file:/tmp/auth-in-one.tgz',
    timeoutMs: 30_000,
  }
}

describe('self-contained installer arguments', () => {
  it('defaults to the immutable alpha.4 package and original Web URL', () => {
    const parsed = parseInstallerArgs(['install'])
    expect(parsed).toMatchObject({
      action: 'install',
      profile: 'web',
      packageSpec: 'github:Stormycry-cryp/dsh-AuthInOne#v0.2.0-alpha.4',
      timeoutMs: 90_000,
    })
    if (parsed.action !== '__supervise') expect(parsed.url.href).toBe('http://127.0.0.1:3080/')
  })

  it.each([
    'https://127.0.0.1:3080/',
    'http://example.com:3080/',
    'http://localhost:3080/',
    'http://user:secret@127.0.0.1:3080/',
    'http://127.0.0.1:3080/path',
  ])('rejects unsafe restart target %s', url => {
    expect(() => parseInstallerArgs(['install', '--url', url])).toThrow(/loopback HTTP origin/)
  })

  it('rejects profile traversal', () => {
    expect(() => parseInstallerArgs(['install', '--profile', '../web'])).toThrow(/invalid DSH profile/)
  })
})

describe('standard DSH launch resolution', () => {
  it('uses the running source checkout and preserves the requested port', async () => {
    const root = await sourceRoot()
    const testRuntime = runtime({ processCwd: vi.fn(() => root) })
    const launch = await resolveLaunch(options(root), testRuntime)
    expect(launch.plugin).toEqual({ executable: 'pnpm', args: ['dsh'], cwd: root })
    expect(launch.web).toEqual({ executable: 'pnpm', args: ['dsh', 'web', '--port', '3080'], cwd: root })
    expect(launch.listenerPid).toBe(123)
  })

  it('rejects a non-DSH listener before mutation', async () => {
    const root = await sourceRoot()
    const testRuntime = runtime({ processCommand: vi.fn(() => 'python -m http.server 3080') })
    await expect(resolveLaunch(options(root), testRuntime)).rejects.toThrow(/UNVERIFIED_PROCESS/)
    expect(testRuntime.run).not.toHaveBeenCalled()
  })

  it('rejects more than one listener instead of selecting a PID', async () => {
    const root = await sourceRoot()
    const testRuntime = runtime({ findListeners: vi.fn(() => [123, 124]) })
    await expect(resolveLaunch(options(root), testRuntime)).rejects.toThrow(/AMBIGUOUS_PORT/)
  })
})

describe('official plugin mutation and restart handoff', () => {
  it('checks compatibility before official add and schedules the installed restart helper', async () => {
    const root = await sourceRoot()
    const home = await mkdtemp(join(tmpdir(), 'auth-in-one-home-'))
    temporaryDirectories.push(home)
    process.env.DSH_HOME = home
    const order: string[] = []
    let command: LaunchCommand | undefined
    const testRuntime = runtime({
      processCwd: vi.fn(() => root),
      assertCompatibleHost: vi.fn(() => order.push('compat')),
      run: vi.fn(value => {
        order.push('add')
        command = value
        return successfulRun()
      }),
      startSupervisor: vi.fn(async () => {
        order.push('supervisor')
        return 789
      }),
    })
    const plan = await runInstaller(options(root), testRuntime)
    expect(order).toEqual(['compat', 'add', 'supervisor'])
    expect(command).toEqual({
      executable: 'pnpm',
      args: ['dsh', 'plugin', '--profile', 'web', 'add', 'file:/tmp/auth-in-one.tgz'],
      cwd: root,
    })
    expect(plan).toMatchObject({ url: 'http://127.0.0.1:3080/', port: 3080, listenerPid: 123 })
    const status = JSON.parse(await readFile(join(home, 'profiles/web/.auth-in-one/restart-status.json'), 'utf8'))
    expect(status).toMatchObject({ phase: 'scheduled', url: 'http://127.0.0.1:3080/' })
    expect(JSON.stringify(status)).not.toMatch(/token|secret|cookie|authorization/i)
  })

  it('does not mutate the profile when host compatibility fails', async () => {
    const root = await sourceRoot()
    const testRuntime = runtime({
      processCwd: vi.fn(() => root),
      assertCompatibleHost: vi.fn(() => { throw new Error('unsupported owner') }),
    })
    await expect(runInstaller(options(root), testRuntime)).rejects.toThrow('unsupported owner')
    expect(testRuntime.run).not.toHaveBeenCalled()
    expect(testRuntime.startSupervisor).not.toHaveBeenCalled()
  })
})

describe('detached restart supervisor', () => {
  it('stops only the validated PID and returns on the same URL and port', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'auth-in-one-supervisor-'))
    temporaryDirectories.push(directory)
    const events: string[] = []
    let oldExists = true
    let listeners = [123]
    const testRuntime = runtime({
      processExists: vi.fn(pid => pid === 123 && oldExists),
      signal: vi.fn(pid => {
        events.push(`signal:${pid}`)
        oldExists = false
        listeners = []
      }),
      findListeners: vi.fn(() => listeners),
      start: vi.fn(async command => {
        events.push(`start:${command.args.at(-1)}`)
        listeners = [456]
        return 456
      }),
      probe: vi.fn(async url => {
        events.push(`probe:${url}`)
        return events.some(event => event.startsWith('start:'))
      }),
    })
    const plan: RestartPlan = {
      version: 1,
      callerPid: 999,
      listenerPid: 123,
      profile: 'web',
      profileDir: directory,
      url: 'http://127.0.0.1:3080/',
      port: 3080,
      launch: { executable: 'pnpm', args: ['dsh', 'web', '--port', '3080'], cwd: '/repo' },
      timeoutMs: 30_000,
      handoffDelayMs: 0,
      statusPath: join(directory, 'status.json'),
      supervisorPath: join(directory, 'supervisor.mjs'),
    }
    await writeFile(plan.supervisorPath, '')
    await superviseRestart(plan, testRuntime)
    expect(events).toEqual([
      'signal:123',
      'start:3080',
      'probe:http://127.0.0.1:3080/',
    ])
    const status = JSON.parse(await readFile(plan.statusPath, 'utf8'))
    expect(status).toMatchObject({ phase: 'ready', previousPid: 123, replacementPid: 456 })
    expect(status.recoveryCommand).toBe('pnpm dsh web --port 3080')
  })

  it('does not start a replacement when the old PID cannot stop', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'auth-in-one-supervisor-'))
    temporaryDirectories.push(directory)
    let tick = 0
    const testRuntime = runtime({
      processExists: vi.fn(pid => pid === 123),
      now: vi.fn(() => new Date(tick++ * 31_000)),
    })
    const plan: RestartPlan = {
      version: 1,
      callerPid: 999,
      listenerPid: 123,
      profile: 'web',
      profileDir: directory,
      url: 'http://127.0.0.1:3080/',
      port: 3080,
      launch: { executable: 'dsh', args: ['web', '--port', '3080'], cwd: '/repo' },
      timeoutMs: 30_000,
      handoffDelayMs: 0,
      statusPath: join(directory, 'status.json'),
      supervisorPath: join(directory, 'supervisor.mjs'),
    }
    await expect(superviseRestart(plan, testRuntime)).rejects.toThrow(/did not stop/)
    expect(testRuntime.signal).toHaveBeenCalledWith(123, 'SIGTERM')
    expect(testRuntime.start).not.toHaveBeenCalled()
    const status = JSON.parse(await readFile(plan.statusPath, 'utf8'))
    expect(status.phase).toBe('failed')
  })

  it('does not signal a replacement listener after the install-time PID changes', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'auth-in-one-supervisor-'))
    temporaryDirectories.push(directory)
    const testRuntime = runtime({
      findListeners: vi.fn(() => [321]),
      processExists: vi.fn(() => false),
    })
    const plan: RestartPlan = {
      version: 1,
      callerPid: 999,
      listenerPid: 123,
      profile: 'web',
      profileDir: directory,
      url: 'http://127.0.0.1:3080/',
      port: 3080,
      launch: { executable: 'dsh', args: ['web', '--port', '3080'], cwd: '/repo' },
      timeoutMs: 30_000,
      handoffDelayMs: 0,
      statusPath: join(directory, 'status.json'),
      supervisorPath: join(directory, 'supervisor.mjs'),
    }
    await expect(superviseRestart(plan, testRuntime)).rejects.toThrow(/LISTENER_CHANGED/)
    expect(testRuntime.signal).not.toHaveBeenCalled()
    expect(testRuntime.start).not.toHaveBeenCalled()
  })

  it('leaves the Host running when the installer process does not release the handoff', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'auth-in-one-supervisor-'))
    temporaryDirectories.push(directory)
    let tick = 0
    const testRuntime = runtime({
      processExists: vi.fn(() => true),
      now: vi.fn(() => new Date(tick++ * 11_000)),
    })
    const plan: RestartPlan = {
      version: 1,
      callerPid: 999,
      listenerPid: 123,
      profile: 'web',
      profileDir: directory,
      url: 'http://127.0.0.1:3080/',
      port: 3080,
      launch: { executable: 'dsh', args: ['web', '--port', '3080'], cwd: '/repo' },
      timeoutMs: 30_000,
      handoffDelayMs: 0,
      statusPath: join(directory, 'status.json'),
      supervisorPath: join(directory, 'supervisor.mjs'),
    }
    await expect(superviseRestart(plan, testRuntime)).rejects.toThrow(/installer PID 999 did not exit/)
    expect(testRuntime.signal).not.toHaveBeenCalled()
    expect(testRuntime.start).not.toHaveBeenCalled()
  })
})
