import { describe, expect, it } from 'vitest'
import {
  SUPPORTED_COMPAT_OWNERS,
  assertSupportedCompatOwners,
} from '../src/host/compat-host.ts'

describe('DSH Settings compatibility host guard', () => {
  it('accepts the exact official 47f owner artifacts', () => {
    expect(() => assertSupportedCompatOwners(SUPPORTED_COMPAT_OWNERS)).not.toThrow()
  })

  it('fails loud for a changed owner instead of risking duplicate native seams', () => {
    const changed = SUPPORTED_COMPAT_OWNERS.map((entry, index) => index === 0
      ? { ...entry, version: '0.1.0-rc.6', clientSha256: 'native-seam' }
      : entry)
    expect(() => assertSupportedCompatOwners(changed)).toThrow(/AUTH_IN_ONE_COMPAT_UNSUPPORTED_DSH/)
  })

  it('fails loud when an owner is missing', () => {
    expect(() => assertSupportedCompatOwners(SUPPORTED_COMPAT_OWNERS.slice(1))).toThrow(/observed missing/)
  })
})
