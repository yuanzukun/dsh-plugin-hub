import { describe, expect, it } from 'vitest'
import { PROVIDER_PLAN_PRESETS } from '../src/provider-plans.ts'

describe('Provider Plan and API-key presets', () => {
  it('offers the promised Plan keys and standard API-key routes without duplicate ids', () => {
    expect(PROVIDER_PLAN_PRESETS.map(entry => entry.id)).toEqual([
      'openai-api',
      'xai-api',
      'gemini-api',
      'kimi-code-plan',
      'glm-coding-plan',
      'qwen-coding-plan',
      'anthropic-api',
    ])
    expect(new Set(PROVIDER_PLAN_PRESETS.map(entry => entry.provider)).size).toBe(PROVIDER_PLAN_PRESETS.length)
    expect(PROVIDER_PLAN_PRESETS.every(entry => URL.canParse(entry.sourceUrl) && URL.canParse(entry.baseURL))).toBe(true)
    expect(PROVIDER_PLAN_PRESETS.every(entry => entry.models.length > 0)).toBe(true)
  })

  it('keeps subscription keys distinct from account Auth and uses the intended wire API', () => {
    expect(PROVIDER_PLAN_PRESETS.find(entry => entry.id === 'glm-coding-plan')).toMatchObject({
      method: 'plan-api-key',
      api: 'openai-completions',
      baseURL: 'https://open.bigmodel.cn/api/coding/paas/v4',
    })
    expect(PROVIDER_PLAN_PRESETS.find(entry => entry.id === 'qwen-coding-plan')).toMatchObject({
      method: 'plan-api-key',
      api: 'openai-completions',
      baseURL: 'https://coding.dashscope.aliyuncs.com/v1',
    })
    expect(PROVIDER_PLAN_PRESETS.find(entry => entry.id === 'openai-api')).toMatchObject({
      method: 'api-key',
      api: 'openai-responses',
    })
    expect(PROVIDER_PLAN_PRESETS.find(entry => entry.id === 'anthropic-api')).toMatchObject({
      method: 'api-key',
      api: 'anthropic-messages',
    })
  })
})
