import { describe, expect, it } from 'vitest'
import { existingCompatSeams } from '../src/client/compat/guard.ts'

describe('Settings compatibility client guard', () => {
  it('permits the official 47f host where none of the generic seams exist', () => {
    expect(existingCompatSeams(() => undefined)).toEqual([])
  })

  it('detects a native seam before the compatibility owners double-register it', () => {
    expect(existingCompatSeams(name => name === 'settings.models.actions'
      ? { kind: 'single', scope: 'root' }
      : undefined)).toEqual(['settings.models.actions'])
  })
})
