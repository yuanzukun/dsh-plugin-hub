import { describe, expect, it, vi } from 'vitest'
import { fetchNoRedirect, readBoundedJson } from '../src/host/bounded-json.ts'

describe('bounded Host JSON responses', () => {
  it('rejects redirects before credential headers can reach a second origin', async () => {
    const request = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
      expect(init?.redirect).toBe('error')
      expect(new Headers(init?.headers).get('x-api-key')).toBe('host-secret')
      return new Response('{"data":[]}', { status: 200 })
    }) as typeof fetch

    await expect(fetchNoRedirect('https://provider.example/models', {
      headers: { 'x-api-key': 'host-secret' },
    }, request)).resolves.toBeInstanceOf(Response)
    expect(request).toHaveBeenCalledOnce()
  })

  it('parses a legitimate response within the limit', async () => {
    await expect(readBoundedJson(new Response('{"ok":true}'), 64)).resolves.toEqual({ ok: true })
  })

  it('cancels a chunked response as soon as the byte limit is crossed', async () => {
    let pulls = 0
    let cancelled = false
    const body = new ReadableStream<Uint8Array>({
      pull(controller) {
        pulls += 1
        controller.enqueue(new Uint8Array(16))
      },
      cancel() {
        cancelled = true
      },
    })

    await expect(readBoundedJson(new Response(body), 32)).resolves.toBeUndefined()
    expect(cancelled).toBe(true)
    expect(pulls).toBeLessThanOrEqual(4)
  })

  it('rejects an oversized declared length without reading the body', async () => {
    const response = new Response(new ReadableStream<Uint8Array>({ pull: vi.fn() }), {
      headers: { 'content-length': '65' },
    })
    await expect(readBoundedJson(response, 64)).resolves.toBeUndefined()
    expect(response.bodyUsed).toBe(false)
  })
})
