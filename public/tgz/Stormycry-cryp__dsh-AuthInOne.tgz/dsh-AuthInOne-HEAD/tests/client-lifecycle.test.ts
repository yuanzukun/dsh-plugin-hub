// @vitest-environment happy-dom

import { Context, Service } from '@deepseek-ai/cordis'
import { describe, expect, it, vi } from 'vitest'

vi.mock('@deepseek-ai/dsh-client-ui-primitives', () => {
  const Empty = () => null
  return {
    Button: Empty,
    IconCheckOutline16: Empty,
    IconChevronDownOutline14: Empty,
    IconChevronLeftOutline14: Empty,
    IconChevronRightOutline14: Empty,
    IconLinkOutline16: Empty,
    IconPlusOutline16: Empty,
    IconRefreshOutline16: Empty,
    Modal: Empty,
    Pill: Empty,
    StateDot: Empty,
  }
})

vi.mock('../src/client/compat/index.ts', () => ({ applyCompatOwners: vi.fn() }))

type Entry = { component: unknown; options: Record<string, unknown> }

class TestSlots extends Service {
  private readonly rows = new Map<string, Entry[]>()

  constructor(ctx: Context) {
    super(ctx, 'slots')
  }

  inject(name: string, register: () => () => void): () => void {
    return this.ctx.effect(register, `test slot ${name}`)
  }

  register(options: Record<string, unknown>, component: unknown): () => void {
    const name = String(options.name)
    const list = this.rows.get(name) ?? []
    const entry = { component, options }
    list.push(entry)
    this.rows.set(name, list)
    return () => {
      const current = this.rows.get(name)
      if (current === undefined) return
      const index = current.indexOf(entry)
      if (index >= 0) current.splice(index, 1)
    }
  }

  entries(name: string): Entry[] {
    return this.rows.get(name) ?? []
  }
}

describe('Client plugin lifecycle', () => {
  it('registers its optional Models seats and Usage icon, then frees every seat and Remote on unload', async () => {
    const { apply, inject } = await import('../src/client/index.ts')
    const ctx = new Context()
    await ctx.plugin(TestSlots).await()
    const slots = ctx.get('slots') as unknown as TestSlots

    const remoteDispose = vi.fn()
    const api = {
      providers: vi.fn(),
      probe: vi.fn(),
      saveDefault: vi.fn(),
      analytics: vi.fn(),
      authProviders: vi.fn(),
      startAuth: vi.fn(),
      cancelAuth: vi.fn(),
      submitAuth: vi.fn(),
      logoutAuth: vi.fn(),
      providerQuotas: vi.fn(),
      planProviders: vi.fn(),
      savePlanProvider: vi.fn(),
    }
    ctx.provide('locale', {
      register: vi.fn(() => vi.fn()),
      bind: vi.fn(() => (key: string) => key),
    } as never)
    ctx.provide('remote', {
      $mount: vi.fn(async () => {
        ctx.provide('remote.authInOne', api as never)
        return remoteDispose
      }),
    } as never)
    ctx.provide('connection', {} as never)

    const fiber = ctx.plugin({ inject: [...inject], apply })
    await fiber.await()
    expect(slots.entries('settings.models.insights')).toHaveLength(1)
    expect(slots.entries('settings.models.actions')).toHaveLength(1)
    expect(slots.entries('settings.section.icon').find(entry => entry.options.id === 'usage')?.component)
      .toEqual(expect.any(Function))
    const insights = slots.entries('settings.models.insights')[0]?.options.inject as (() => {
      subscribeProviderChange: (listener: () => void) => () => void
    })
    const actions = slots.entries('settings.models.actions')[0]?.options.inject as (() => {
      notifyProviderChange: () => void
    })
    const listener = vi.fn()
    const disposeListener = insights().subscribeProviderChange(listener)
    actions().notifyProviderChange()
    expect(listener).toHaveBeenCalledOnce()
    disposeListener()

    await fiber.dispose()
    expect(slots.entries('settings.models.insights')).toHaveLength(0)
    expect(slots.entries('settings.models.actions')).toHaveLength(0)
    expect(slots.entries('settings.section').filter(entry => entry.options.id === 'usage')).toHaveLength(0)
    expect(slots.entries('settings.section.icon').filter(entry => entry.options.id === 'usage')).toHaveLength(0)
    expect(remoteDispose).toHaveBeenCalledOnce()
  })
})
