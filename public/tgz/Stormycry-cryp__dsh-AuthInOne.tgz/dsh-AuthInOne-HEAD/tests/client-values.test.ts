import { describe, expect, it } from 'vitest'
import { createElement } from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import { IconUsageBarsOutline16 } from '../src/client/IconUsageBarsOutline16.tsx'
import { parseLocalSecond, recentRange } from '../src/client/time-range.ts'
import { formatTokens } from '../src/client/token-format.ts'

describe('formatTokens', () => {
  it.each([
    [0, '0'],
    [999_999, '999,999'],
    [1_000_000, '1M'],
    [1_200_000, '1.2M'],
    [1_234_567, '1.23M'],
    [999_999_999, '1,000M'],
    [1_000_000_000, '1B'],
    [2_500_000_000, '2.5B'],
  ])('formats %s as %s while retaining the exact Token count', (value, compact) => {
    expect(formatTokens(value, 'en-US')).toEqual({ text: compact, exact: `${value.toLocaleString('en-US')} Token` })
  })

  it.each([undefined, null, Number.NaN, Number.POSITIVE_INFINITY, -1])('keeps %s unknown', value => {
    expect(formatTokens(value)).toBeNull()
  })
})

describe('local second ranges', () => {
  it('parses valid local seconds and rejects overflow or an inverted calendar value', () => {
    expect(parseLocalSecond('2026-08-14 23:59:59')).not.toBeNull()
    expect(parseLocalSecond('2026-02-30 00:00:00')).toBeNull()
    expect(parseLocalSecond('2026-08-14 24:00:00')).toBeNull()
    expect(parseLocalSecond('2026-08-14')).toBeNull()
  })

  it.each([7, 15, 30] as const)('builds a %s-day inclusive-second shortcut with an exclusive Host end', days => {
    const now = Date.parse('2026-08-14T12:34:56.789Z')
    const range = recentRange(days, now)
    expect(range).toEqual({
      startTime: Date.parse('2026-08-14T12:34:56.000Z') - days * 86_400_000 + 1_000,
      endTimeExclusive: Date.parse('2026-08-14T12:34:57.000Z'),
      presetDays: days,
    })
    expect(range.endTimeExclusive - range.startTime).toBe(days * 86_400_000)
  })
})

describe('IconUsageBarsOutline16', () => {
  it('inherits currentColor and accepts the shell size and class name', () => {
    const markup = renderToStaticMarkup(createElement(IconUsageBarsOutline16, { size: 20, className: 'nav-glyph' }))
    expect(markup).toContain('width="20"')
    expect(markup).toContain('height="20"')
    expect(markup).toContain('class="nav-glyph"')
    expect(markup.match(/fill="currentColor"/g)).toHaveLength(3)
    expect(markup).not.toMatch(/#[0-9a-f]{3,8}|rgb\(|hsl\(/i)
  })
})
