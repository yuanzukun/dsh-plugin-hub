import { describe, expect, it, vi } from 'vitest'
import { fetchKimiUsage, parseKimiUsage } from '../src/host/kimi-usage.ts'

describe('Kimi quota projection', () => {
  it('keeps only real five-hour, weekly, and subscription windows', () => {
    expect(parseKimiUsage({
      usage: { limit: 100, used: 25, resetAt: '2026-08-21T00:00:00Z' },
      limits: [{ name: '5 hour requests', detail: { limit: 40, remaining: 10 }, window: { duration: 5, timeUnit: 'HOUR' } }],
      totalQuota: { limit: 1_000, used: 200 },
    })).toEqual([
      expect.objectContaining({ id: 'weekly', usedPercent: 25, remainingPercent: 75 }),
      expect.objectContaining({ id: 'five-hour', usedPercent: 75, remainingPercent: 25 }),
      expect.objectContaining({ id: 'subscription', usedPercent: 20, remainingPercent: 80 }),
    ])
  })

  it('never returns a bearer token and marks malformed quota unavailable', async () => {
    const request = vi.fn(async (_input, init) => {
      expect(new Headers(init?.headers).get('authorization')).toBe('Bearer kimi-sensitive')
      return new Response(JSON.stringify({ data: { unrelated: true } }), { status: 200 })
    }) as typeof fetch
    const result = await fetchKimiUsage('kimi-sensitive', undefined, request)
    expect(result.status).toBe('unavailable')
    expect(JSON.stringify(result)).not.toContain('kimi-sensitive')
  })
})
