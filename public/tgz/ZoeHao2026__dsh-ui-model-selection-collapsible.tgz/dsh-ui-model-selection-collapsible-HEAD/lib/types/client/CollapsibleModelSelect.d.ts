import type { ModelSelection } from '@deepseek-ai/dsh-api-session-controller/types';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { ModelDirectoryState, ModelSelectInjected } from '@deepseek-ai/dsh-client-ui-model-selection/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import './styles.css';
import type { PreferencesStore } from './preferences.js';
type SelectResult = Awaited<ReturnType<ModelSelectInjected['select']>> | boolean;
export type CollapsibleModelSelectProps = Omit<ModelSelectInjected, 'directory' | 'select'> & {
    directory: ObservableSnapshot<ModelDirectoryState>;
} & {
    select: (selection: ModelSelection) => Promise<SelectResult>;
} & {
    locked: boolean;
    preferences: PreferencesStore;
} & PropsLocale<'model'>;
export declare function CollapsibleModelSelect({ locked, available, directory, load, select, preferences, t, }: CollapsibleModelSelectProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=CollapsibleModelSelect.d.ts.map