window.__ModuleLoader__.load({
  id: 'dsh-model-info-fill',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const react = require('react')
    const h = react.createElement
    const { useCallback, useEffect, useLayoutEffect, useRef, useState } = react

    // A portal lets the card's button live inside the host's own action row;
    // when react-dom is not reachable the button falls back to its own line.
    let createPortal = null
    try {
      createPortal = require('react-dom').createPortal ?? null
    } catch {
      createPortal = null
    }

    const PREFIX = '/plugins/models-dev-catalog'
    const STYLE_ID = 'dsh-model-info-fill'

    const CSS = `
.mdc-wrap { display: flex; flex-direction: column; gap: 8px; width: 100%; }
.mdc-row {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 10px;
  width: 100%;
  padding: 12px;
  border: .5px solid var(--dsw-alias-border-l4, rgba(127,127,127,.2));
  border-radius: 16px;
  background: transparent;
  color: var(--dsw-alias-label-primary, inherit);
  box-sizing: border-box;
}
.mdc-head { display: flex; align-items: center; gap: 12px; min-width: 200px; }
.mdc-icon { flex: none; width: 18px; height: 18px; color: var(--dsw-alias-label-secondary, #888); }
.mdc-body { flex: 1; min-width: 0; }
.mdc-title { font-size: 14px; font-weight: 500; line-height: 22px; }
.mdc-meta { margin-top: 2px; font-size: 13px; line-height: 20px; color: var(--dsw-alias-label-secondary, #666); }
.mdc-desc { margin-top: 2px; font-size: 12px; line-height: 18px; color: var(--dsw-alias-label-tertiary, #888); }
.mdc-toolbar { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 12px; }
.mdc-chips { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }
.mdc-chip {
  box-sizing: border-box;
  height: 28px;
  padding: 0 10px;
  border: .5px solid var(--dsw-alias-border-l3, rgba(127,127,127,.3));
  border-radius: 14px;
  background: transparent;
  color: var(--dsw-alias-label-primary, inherit);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  display: inline-flex;
  align-items: center;
  cursor: pointer;
}
.mdc-chip:hover { background: var(--dsw-alias-interactive-bg-hover-solid, rgba(127,127,127,.12)); }
.mdc-chip:focus-visible { box-shadow: 0 0 0 2px var(--dsw-alias-border-l3, rgba(127,127,127,.35)); outline: none; }
.mdc-chip-warn {
  color: var(--dsw-alias-state-warning-primary, #9a3412);
  border-color: color-mix(in srgb, var(--dsw-alias-state-warning-primary, #9a3412) 45%, transparent);
  background: color-mix(in srgb, var(--dsw-alias-state-warning-primary, #c2410c) 10%, transparent);
}
.mdc-chip-on {
  background: var(--dsw-alias-interactive-bg-hover-solid, rgba(127,127,127,.16));
  border-color: var(--dsw-alias-label-secondary, #666);
}
.mdc-chip-warn.mdc-chip-on {
  background: color-mix(in srgb, var(--dsw-alias-state-warning-primary, #c2410c) 18%, transparent);
  border-color: var(--dsw-alias-state-warning-primary, #9a3412);
}
.mdc-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; margin-left: auto; max-width: 100%; }
.mdc-btn {
  box-sizing: border-box;
  height: 36px;
  font: inherit;
  cursor: pointer;
  border: .5px solid var(--dsw-alias-border-l3, rgba(127,127,127,.3));
  border-radius: 18px;
  justify-content: center;
  align-items: center;
  padding: 0 14px;
  font-size: 14px;
  line-height: 22px;
  display: inline-flex;
  color: var(--dsw-alias-label-primary, inherit);
  background: transparent;
}
.mdc-btn:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover-solid, rgba(127,127,127,.12)); }
.mdc-btn:focus-visible { box-shadow: 0 0 0 2px var(--dsw-alias-border-l3, rgba(127,127,127,.35)); outline: none; }
.mdc-btn[disabled] { opacity: .4; cursor: default; }
.mdc-btn-primary {
  border-color: transparent;
  background: var(--dsw-alias-button-primary-fill, #3b82f6);
  color: var(--dsw-alias-label-primary-foreground, #fff);
}
.mdc-btn-primary:hover:not(:disabled) { background: var(--dsw-alias-button-primary-hover, #2563eb); }
.mdc-btn-inline { height: 28px; padding: 0 10px; font-size: 12px; line-height: 18px; border-radius: 14px; }
.mdc-error { color: var(--dsw-alias-state-error-primary, #ef4444); }
.mdc-ok { color: var(--dsw-alias-state-success-primary, #16a34a); }
.mdc-panel {
  border: .5px solid var(--dsw-alias-border-l4, rgba(127,127,127,.2));
  border-radius: 16px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.mdc-group { display: flex; flex-direction: column; gap: 8px; }
.mdc-block-title { font-size: 12px; font-weight: 600; color: var(--dsw-alias-label-secondary, #888); }
.mdc-item {
  border: .5px solid var(--dsw-alias-border-l4, rgba(127,127,127,.2));
  border-radius: 12px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.mdc-item-head { display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap; }
.mdc-item-id { font-size: 13px; font-weight: 500; }
.mdc-item-sub { font-size: 12px; color: var(--dsw-alias-label-tertiary, #888); }
.mdc-input {
  box-sizing: border-box;
  width: 100%;
  height: 32px;
  border: .5px solid var(--dsw-alias-border-l3, rgba(127,127,127,.3));
  border-radius: 8px;
  background: transparent;
  color: inherit;
  padding: 0 8px;
  font: inherit;
  font-size: 12px;
}
.mdc-search { display: flex; flex-direction: column; gap: 6px; }
.mdc-candidates { display: flex; flex-direction: column; gap: 6px; }
.mdc-candidate {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px 10px;
  padding: 6px 8px;
  border: .5px solid var(--dsw-alias-border-l4, rgba(127,127,127,.16));
  border-radius: 8px;
}
.mdc-candidate-name { font-size: 12px; }
.mdc-candidate-meta { font-size: 11px; color: var(--dsw-alias-label-tertiary, #888); }
.mdc-card { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-top: 8px; }
.mdc-anchor { display: none; }
.mdc-in-row { flex: none; }
`

    function messageOf(error) {
      return error instanceof Error ? error.message : String(error)
    }

    async function api(path, options) {
      const response = await fetch(PREFIX + path, {
        credentials: 'same-origin',
        ...options,
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok || data.ok === false) {
        throw new Error(data.error || `HTTP ${response.status}`)
      }
      return data
    }

    function post(path, body) {
      return api(path, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body ?? {}),
      })
    }

    function count(value) {
      return typeof value === 'number' && Number.isFinite(value) ? value.toLocaleString('zh-CN') : '—'
    }

    function fillText(fill) {
      const parts = []
      if (fill?.contextWindow) parts.push(`上下文 ${count(fill.contextWindow)}`)
      if (fill?.maxTokens) parts.push(`maxTokens ${count(fill.maxTokens)}`)
      if (Array.isArray(fill?.input)) parts.push('支持图片')
      if (fill?.name) parts.push(`名称「${fill.name}」`)
      return parts.join(' · ')
    }

    function RefreshIcon() {
      return h('svg', {
        className: 'mdc-icon',
        viewBox: '0 0 20 20',
        width: 18,
        height: 18,
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 1.6,
        'aria-hidden': true,
      }, h('path', { d: 'M4 10a6 6 0 0 1 10.4-4.1L16 4v5h-5l1.7-1.7A4.2 4.2 0 1 0 14.2 13' }))
    }

    function Chip({ label, tone, active, onClick }) {
      const classes = ['mdc-chip']
      if (tone) classes.push(`mdc-chip-${tone}`)
      if (active) classes.push('mdc-chip-on')
      return h('button', {
        className: classes.join(' '),
        type: 'button',
        'aria-pressed': active ? 'true' : 'false',
        onClick,
      }, label)
    }

    function Candidates({ rows, busy, action, onPick }) {
      if (!Array.isArray(rows) || rows.length === 0) return null
      return h('div', { className: 'mdc-candidates' },
        rows.map((candidate) => h('div', { key: candidate.key, className: 'mdc-candidate' },
          h('span', { className: 'mdc-candidate-name' }, `${candidate.id} · ${candidate.providerName}`),
          h('span', { className: 'mdc-candidate-meta' },
            `上下文 ${count(candidate.contextWindow)} · maxTokens ${count(candidate.maxOutput)}${candidate.image ? ' · 图片' : ''}`,
          ),
          h('button', {
            className: 'mdc-btn mdc-btn-inline',
            type: 'button',
            disabled: busy,
            onClick: () => onPick(candidate),
          }, action),
        )),
      )
    }

    function FillRow({ row, busy, onFill }) {
      return h('div', { className: 'mdc-item' },
        h('div', { className: 'mdc-item-head' },
          h('span', { className: 'mdc-item-id' }, row.name),
          h('span', { className: 'mdc-item-sub' }, `${row.provider} · ${row.id}`),
        ),
        h('div', { className: 'mdc-desc' }, `将写入：${fillText(row.fill)}`),
        row.reasoningHint
          ? h('div', { className: 'mdc-desc' }, `百科：${row.reasoningHint} —— 思考档位在宿主的模型编辑里设置`)
          : null,
        h('div', { className: 'mdc-actions' },
          h('button', {
            className: 'mdc-btn mdc-btn-inline',
            type: 'button',
            disabled: busy,
            onClick: onFill,
          }, busy ? '补全中…' : '补全这条'),
        ),
      )
    }

    function ConflictRow({ row, busy, onPick, onIgnore }) {
      const fields = (row.conflicts ?? []).map((key) => ({
        contextWindow: '上下文',
        maxTokens: 'maxTokens',
        input: '图片',
        name: '名称',
      })[key] ?? key)
      return h('div', { className: 'mdc-item' },
        h('div', { className: 'mdc-item-head' },
          h('span', { className: 'mdc-item-id' }, row.name),
          h('span', { className: 'mdc-item-sub' }, `${row.provider} · ${row.id}`),
        ),
        h('div', { className: 'mdc-desc' },
          `百科有 ${row.candidateCount} 条同名记录，${fields.join('、')}对不上，所以没有自动填。选一条作为依据：`,
        ),
        h(Candidates, { rows: row.candidates, busy, action: '用这条', onPick }),
        h('div', { className: 'mdc-actions' },
          h('button', {
            className: 'mdc-btn mdc-btn-inline',
            type: 'button',
            disabled: busy,
            onClick: onIgnore,
          }, '忽略'),
        ),
      )
    }

    function UnmatchedRow({ row, busy, onPick, onIgnore }) {
      const [query, setQuery] = useState(row.id)
      const [rows, setRows] = useState([])
      const [searching, setSearching] = useState(false)

      useEffect(() => {
        const needle = query.trim()
        if (needle.length < 2) {
          setRows([])
          return
        }
        let alive = true
        const timer = setTimeout(async () => {
          setSearching(true)
          try {
            const data = await api(`/search?q=${encodeURIComponent(needle)}&limit=8`)
            if (alive) setRows(Array.isArray(data.rows) ? data.rows : [])
          } catch {
            if (alive) setRows([])
          } finally {
            if (alive) setSearching(false)
          }
        }, 300)
        return () => {
          alive = false
          clearTimeout(timer)
        }
      }, [query])

      return h('div', { className: 'mdc-item' },
        h('div', { className: 'mdc-item-head' },
          h('span', { className: 'mdc-item-id' }, row.name),
          h('span', { className: 'mdc-item-sub' }, `${row.provider} · ${row.id}`),
        ),
        row.staleAlias ? h('div', { className: 'mdc-desc mdc-error' }, '之前指定的百科条目已不存在。') : null,
        h('div', { className: 'mdc-desc' }, '百科里没有这一条。搜索一个等价条目作为依据，或者忽略它。'),
        h('div', { className: 'mdc-search' },
          h('input', {
            className: 'mdc-input',
            type: 'search',
            value: query,
            placeholder: '搜索百科条目，例如 glm-5.3',
            onChange: (event) => setQuery(event.target.value),
          }),
          searching ? h('span', { className: 'mdc-item-sub' }, '搜索中…') : null,
        ),
        h(Candidates, { rows, busy, action: '指定', onPick }),
        h('div', { className: 'mdc-actions' },
          h('button', {
            className: 'mdc-btn mdc-btn-inline',
            type: 'button',
            disabled: busy,
            onClick: onIgnore,
          }, '忽略'),
        ),
      )
    }

    function IgnoredRow({ row, busy, onRestore }) {
      return h('div', { className: 'mdc-item' },
        h('div', { className: 'mdc-item-head' },
          h('span', { className: 'mdc-item-id' }, row.name),
          h('span', { className: 'mdc-item-sub' }, `${row.provider} · ${row.id}`),
        ),
        h('div', { className: 'mdc-actions' },
          h('button', {
            className: 'mdc-btn mdc-btn-inline',
            type: 'button',
            disabled: busy,
            onClick: onRestore,
          }, '恢复'),
        ),
      )
    }

    function Footer() {
      const [state, setState] = useState(null)
      const [panel, setPanel] = useState(null)
      const [busy, setBusy] = useState('')
      const [error, setError] = useState('')
      const [hint, setHint] = useState('')

      const load = useCallback(async () => {
        const next = await api('/status')
        setState(next)
        setError('')
        return next
      }, [])

      useEffect(() => {
        load().catch((err) => setError(messageOf(err)))
      }, [load])

      const run = async (kind, work, okText) => {
        setBusy(kind)
        setError('')
        setHint('')
        try {
          const result = await work()
          await load()
          const text = typeof okText === 'function' ? okText(result) : okText
          if (text) setHint(text)
        } catch (err) {
          setError(messageOf(err))
        } finally {
          setBusy('')
        }
      }

      const groups = Array.isArray(state?.groups) ? state.groups : []
      const models = groups.flatMap((group) => group.models.map((row) => ({ ...row, group })))
      const conflicted = models.filter((row) => !row.ignored && (row.conflicts ?? []).length > 0)
      const fillable = models.filter((row) => !row.ignored
        && (row.conflicts ?? []).length === 0
        && Object.keys(row.fill ?? {}).length > 0)
      const unmatched = models.filter((row) => !row.ignored
        && (row.conflicts ?? []).length === 0
        && Object.keys(row.fill ?? {}).length === 0
        && row.match === 'none')
      const ignored = models.filter((row) => row.ignored)
      const empty = !state || state.modelCount === 0

      const toggle = (next) => setPanel((current) => (current === next ? null : next))
      const visible = (key) => panel === key || panel === 'detail'
      const rowKey = (row) => `${row.provider}/${row.id}`

      const fillHint = (result) => {
        if (result?.fields) return `已补 ${result.fields} 个字段`
        return '没有可补的字段'
      }

      return h('div', { className: 'mdc-wrap' },
        h('div', { className: 'mdc-row' },
          h('div', { className: 'mdc-head' },
            h(RefreshIcon),
            h('div', { className: 'mdc-body' },
              h('div', { className: 'mdc-title' }, '模型信息补全'),
              h('div', { className: 'mdc-meta' }, state?.stamp ?? '尚未更新'),
            ),
          ),
          error ? h('div', { className: 'mdc-desc mdc-error' }, error) : null,
          hint ? h('div', { className: 'mdc-desc mdc-ok' }, hint) : null,
          h('div', { className: 'mdc-toolbar' },
            h('div', { className: 'mdc-chips' },
              fillable.length ? h(Chip, {
                label: `可补全 ${fillable.length}`,
                active: panel === 'fill',
                onClick: () => toggle('fill'),
              }) : null,
              conflicted.length ? h(Chip, {
                label: `有分歧 ${conflicted.length}`,
                tone: 'warn',
                active: panel === 'conflict',
                onClick: () => toggle('conflict'),
              }) : null,
              unmatched.length ? h(Chip, {
                label: `未匹配 ${unmatched.length}`,
                active: panel === 'unmatched',
                onClick: () => toggle('unmatched'),
              }) : null,
              ignored.length ? h(Chip, {
                label: `已忽略 ${ignored.length}`,
                active: panel === 'ignored',
                onClick: () => toggle('ignored'),
              }) : null,
            ),
            h('div', { className: 'mdc-actions' },
              h('button', {
                className: 'mdc-btn',
                type: 'button',
                onClick: () => toggle('detail'),
              }, panel === 'detail' ? '收起' : '详情'),
              h('button', {
                className: 'mdc-btn',
                type: 'button',
                disabled: Boolean(busy) || empty,
                onClick: () => run('fill', () => post('/fill', {}), fillHint),
              }, busy === 'fill' ? '补全中…' : '补全全部缺失'),
              h('button', {
                className: 'mdc-btn mdc-btn-primary',
                type: 'button',
                disabled: Boolean(busy),
                onClick: () => run('refresh', () => post('/refresh'), (result) => `百科已更新：${result.stamp}`),
              }, busy === 'refresh' ? '更新中…' : '更新'),
            ),
          ),
        ),
        panel ? h('div', { className: 'mdc-panel' },
          panel === 'detail' ? h('div', { className: 'mdc-desc' },
            '按模型名从 models.dev 补全缺失的上下文、输出上限、图片与名称。思考档位不写 —— 宿主已支持在模型编辑里手动选择，这里只显示百科的说法。',
          ) : null,
          empty ? h('div', { className: 'mdc-desc' }, '百科还没拉取到，先点「更新」。') : null,
          panel === 'detail' ? h('div', { className: 'mdc-item' },
            h('div', { className: 'mdc-block-title' }, '供应商'),
            groups.length === 0
              ? h('div', { className: 'mdc-desc' }, '还没有自定义供应商。')
              : groups.map((group) => {
                const pending = group.models.filter((row) => !row.ignored
                  && (row.conflicts ?? []).length === 0
                  && Object.keys(row.fill ?? {}).length > 0).length
                const identity = group.catalogProviders.length > 0
                  ? group.catalogProviders.join(' / ')
                  : '未识别（按模型名全局比对）'
                return h('div', { key: group.provider, className: 'mdc-desc' },
                  `${group.displayName}（${group.provider}）· 百科身份：${identity} · 可补 ${pending}`,
                )
              }),
          ) : null,
          panel === 'detail' ? groups.filter((group) => group.reasoning?.unsupported?.length).map((group) => h('div', {
            key: `reasoning-${group.provider}`,
            className: 'mdc-desc mdc-error',
          }, `${group.displayName} 的默认档位是 ${group.reasoning.level}，但 ${group.reasoning.unsupported.join('、')} 没有声明这一档 —— 该供应商的请求可能报 UNSUPPORTED_REASONING_EFFORT。`)) : null,
          visible('fill') && fillable.length > 0
            ? h('div', { className: 'mdc-group' },
              h('div', { className: 'mdc-block-title' }, `可补全（${fillable.length}）`),
              fillable.map((row) => h(FillRow, {
                key: rowKey(row),
                row,
                busy: busy === `one:${rowKey(row)}` || busy === 'fill',
                onFill: () => run(`one:${rowKey(row)}`, () => post('/fill', { provider: row.provider, id: row.id }), fillHint),
              })),
            )
            : null,
          visible('conflict') && conflicted.length > 0
            ? h('div', { className: 'mdc-group' },
              h('div', { className: 'mdc-block-title' }, `有分歧（${conflicted.length}）`),
              conflicted.map((row) => h(ConflictRow, {
                key: rowKey(row),
                row,
                busy: busy.startsWith('alias:'),
                onPick: (candidate) => run(
                  `alias:${rowKey(row)}`,
                  () => post('/alias', { provider: row.provider, id: row.id, key: candidate.key }),
                  `已指定 ${row.id} → ${candidate.key}`,
                ),
                onIgnore: () => run(
                  `ignore:${rowKey(row)}`,
                  () => post('/ignore', { provider: row.provider, id: row.id, ignored: true }),
                  `已忽略 ${row.id}`,
                ),
              })),
            )
            : null,
          visible('unmatched') && unmatched.length > 0
            ? h('div', { className: 'mdc-group' },
              h('div', { className: 'mdc-block-title' }, `未匹配（${unmatched.length}）`),
              unmatched.map((row) => h(UnmatchedRow, {
                key: rowKey(row),
                row,
                busy: busy.startsWith('alias:') || busy.startsWith('ignore:'),
                onPick: (candidate) => run(
                  `alias:${rowKey(row)}`,
                  () => post('/alias', { provider: row.provider, id: row.id, key: candidate.key }),
                  `已指定 ${row.id} → ${candidate.key}`,
                ),
                onIgnore: () => run(
                  `ignore:${rowKey(row)}`,
                  () => post('/ignore', { provider: row.provider, id: row.id, ignored: true }),
                  `已忽略 ${row.id}`,
                ),
              })),
            )
            : null,
          visible('ignored') && ignored.length > 0
            ? h('div', { className: 'mdc-group' },
              h('div', { className: 'mdc-block-title' }, `已忽略（${ignored.length}）`),
              ignored.map((row) => h(IgnoredRow, {
                key: rowKey(row),
                row,
                busy: busy.startsWith('ignore:'),
                onRestore: () => run(
                  `ignore:${rowKey(row)}`,
                  () => post('/ignore', { provider: row.provider, id: row.id, ignored: false }),
                  `已恢复 ${row.id}`,
                ),
              })),
            )
            : null,
          visible('detail') && models.length === 0
            ? h('div', { className: 'mdc-desc' }, '当前还没有自定义模型。')
            : null,
        ) : null,
      )
    }

    function ProviderCard(props) {
      const provider = props?.provider?.provider ?? props?.provider?.key ?? ''
      const configured = props?.configured !== false
      const [group, setGroup] = useState(null)
      const [busy, setBusy] = useState(false)
      const [note, setNote] = useState('')
      const anchor = useRef(null)
      const [actions, setActions] = useState(null)
      const [hostClass, setHostClass] = useState('')

      useEffect(() => {
        if (!provider) return undefined
        let alive = true
        api('/status')
          .then((data) => {
            if (!alive) return
            setGroup((data.groups ?? []).find((item) => item.provider === provider) ?? null)
          })
          .catch(() => {})
        return () => {
          alive = false
        }
      }, [provider, note])

      useEffect(() => {
        if (note === '') return undefined
        const timer = setTimeout(() => setNote(''), 4000)
        return () => clearTimeout(timer)
      }, [note])

      const pending = group
        ? group.models.filter((row) => !row.ignored
          && (row.conflicts ?? []).length === 0
          && Object.keys(row.fill ?? {}).length > 0).length
        : 0
      // Stay put while busy or while a result message is on screen, so the
      // button does not vanish in the middle of its own click.
      const show = configured
        && provider !== ''
        && provider !== 'deepseek-account'
        && (pending > 0 || busy || note !== '')

      // The host draws 编辑 / 删除 in a rowActions span inside the card; our seat
      // is the card's last child, so the button has to travel there to sit on
      // that line, just before 编辑.
      useLayoutEffect(() => {
        if (!show) {
          setActions((prev) => (prev === null ? prev : null))
          return
        }
        const card = anchor.current === null ? null : anchor.current.closest('li')
        const row = card === null ? null : card.querySelector('[class*="rowActions"]')
        setActions((prev) => (prev === row ? prev : row))
        const host = row === null
          ? undefined
          : Array.from(row.querySelectorAll('button')).find((node) => !node.classList.contains('mdc-in-row'))
        const next = host?.className ?? ''
        setHostClass((prev) => (prev === next ? prev : next))
      }, [show, pending, group])

      // Reinsert to stay first in the row; the node keeps that parent, so React
      // can still remove it on unmount.
      useLayoutEffect(() => {
        if (actions === null) return
        const node = actions.querySelector('.mdc-in-row')
        if (node !== null && actions.firstElementChild !== node) {
          actions.insertBefore(node, actions.firstElementChild)
        }
      }, [actions, pending, busy])

      const fill = async () => {
        setBusy(true)
        setNote('')
        try {
          const result = await post('/fill', { provider })
          setNote(result.fields ? `已补 ${result.fields} 个字段` : '没有可补的字段')
        } catch (err) {
          setNote(messageOf(err))
        } finally {
          setBusy(false)
        }
      }

      if (!show) return h('span', { ref: anchor, className: 'mdc-anchor' })

      const identity = group?.catalogProviders?.length
        ? `百科身份：${group.catalogProviders.join(' / ')}`
        : '按 models.dev 补全该供应商缺失的上下文 / 输出上限 / 图片 / 名称'
      const button = h('button', {
        className: `${hostClass} mdc-in-row`.trim(),
        type: 'button',
        disabled: busy,
        'aria-label': `补全 ${provider} 缺失的模型字段`,
        title: note === '' ? identity : note,
        onClick: fill,
      }, busy ? '补全中…' : note === '' ? `补全缺失字段 · ${pending}` : note)

      const target = createPortal === null ? null : actions
      if (target === null) {
        return h('div', { className: 'mdc-card' },
          h('span', { ref: anchor, className: 'mdc-anchor' }),
          h('button', {
            className: 'mdc-btn mdc-btn-inline',
            type: 'button',
            disabled: busy,
            onClick: fill,
          }, busy ? '补全中…' : `补全缺失字段 · ${pending}`),
          note ? h('span', { className: 'mdc-item-sub' }, note) : null,
        )
      }
      return h(react.Fragment, null,
        h('span', { ref: anchor, className: 'mdc-anchor' }),
        createPortal(button, target),
      )
    }

    exports.inject = ['slots']
    exports.apply = function apply(ctx) {
      ctx.effect(() => {
        document.getElementById(STYLE_ID)?.remove()
        const style = document.createElement('style')
        style.id = STYLE_ID
        style.textContent = CSS
        document.head.appendChild(style)
        return () => style.remove()
      }, 'model-info-fill: css')

      ctx.effect(() => ctx.slots.inject('settings.models.footer', () => ctx.slots.register({
        name: 'settings.models.footer',
        id: 'model-info-fill',
        order: 20,
        label: () => '模型信息补全',
      }, Footer)), 'model-info-fill: footer')

      ctx.effect(() => ctx.slots.inject('settings.models.provider-card', () => ctx.slots.register({
        name: 'settings.models.provider-card',
        key: 'llm-pi-ai',
      }, ProviderCard)), 'model-info-fill: provider-card')
    }

    return module.exports
  },
})
