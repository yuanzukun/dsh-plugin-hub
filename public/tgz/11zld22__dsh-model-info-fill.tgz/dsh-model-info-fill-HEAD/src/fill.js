/** Turn catalog matches into the settings ops that fill them. */

import { asRecord, isProviderKey, textOf } from './catalog.js'
import { buildIndex, isIgnored, planFill, resolveModel } from './match.js'

/**
 * The only fields this plugin writes. Thinking is deliberately absent: the host
 * edits `reasoningEfforts` natively and treats a provider default as a per-model
 * capability, so writing either here would only fight the model settings form.
 */
export const FILL_FIELDS = Object.freeze(['contextWindow', 'maxTokens', 'input', 'name'])

/**
 * The ops that fill missing facts, one op per provider whose model list changes.
 *
 * A model keeps every field it already had; a fill only adds what the catalog
 * states and the entry lacks. Providers with nothing to add emit no op at all,
 * so a click that finds no gaps writes nothing.
 * @param {object} config the resolved llm-pi-ai section.
 * @param {object} catalog the parsed cache file.
 * @param {{ provider?: string, ids?: string[] }} [options] limit to a route or to some models.
 * @returns {{ ops: object[], providers: string[], fields: number }}
 */
export function buildFillOps(config, catalog, options = {}) {
  const index = buildIndex(catalog)
  const onlyProvider = textOf(options.provider)
  const onlyIds = Array.isArray(options.ids) && options.ids.length > 0
    ? new Set(options.ids.map((id) => textOf(id)).filter(Boolean))
    : null
  const ops = []
  const providers = []
  let fields = 0

  for (const [provider, raw] of Object.entries(asRecord(config?.providers) ?? {})) {
    if (!isProviderKey(provider)) continue
    if (onlyProvider && provider !== onlyProvider) continue
    const profile = asRecord(raw)
    if (!profile || !Array.isArray(profile.models) || profile.models.length === 0) continue

    let changed = false
    const nextModels = profile.models.map((entry) => {
      const id = textOf(entry?.id)
      if (!id) return entry
      if (onlyIds && !onlyIds.has(id)) return entry
      if (isIgnored(index, provider, id)) return entry
      const resolved = resolveModel(provider, profile, id, index)
      const plan = planFill(entry, resolved)
      const keys = Object.keys(plan.fill)
      if (keys.length === 0) return entry
      for (const key of keys) {
        if (!FILL_FIELDS.includes(key)) throw new Error(`unexpected fill field "${key}"`)
      }
      changed = true
      fields += keys.length
      return { ...entry, ...plan.fill }
    })

    if (!changed) continue
    ops.push({ op: 'set', path: ['providers', provider, 'models'], value: nextModels })
    providers.push(provider)
  }

  return { ops, providers, fields }
}

/**
 * Whether any op would write a thinking field. The plugin must never do this,
 * so the writer refuses the write instead of trusting the planner.
 * @param {object[]} ops
 */
export function writesReasoning(ops) {
  for (const op of Array.isArray(ops) ? ops : []) {
    const path = Array.isArray(op?.path) ? op.path : []
    if (path[0] === 'providers' && path[2] === 'reasoning') return true
  }
  return false
}
