/**
 * The models.dev catalog: the fetch shape, the cached file, and the small
 * host/URL helpers the cache and the matcher both need.
 */

export const MODELS_DEV_URL = 'https://models.dev/api.json'

/** Cache schema. Bumped when the parsed shape changes, so an old cache is re-fetched. */
export const CATALOG_VERSION = 3

export const LLM_PI_AI_NS = 'llm-pi-ai'
export const STALE_MS = 7 * 24 * 60 * 60 * 1000
export const PROVIDER_KEY_PATTERN = /^[a-z][a-z0-9]*(-[a-z0-9]+)*$/
export const MODALITIES = Object.freeze(['text', 'image'])

/** Thinking levels pi-ai dispatches, in its own escalation order. */
export const REASONING_LEVELS = Object.freeze(['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'])

/** Second-level labels that need three labels before the registrable domain starts. */
const SECOND_LEVEL = new Set(['com', 'net', 'org', 'gov', 'edu', 'co', 'ac', 'or', 'ne', 'go', 'gob', 'mil', 'sch', 'nom'])

export function asRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : null
}

export function textOf(value) {
  return typeof value === 'string' ? value.trim() : ''
}

export function isPositiveInt(value) {
  return typeof value === 'number' && Number.isInteger(value) && value > 0
}

export function isProviderKey(value) {
  return typeof value === 'string' && PROVIDER_KEY_PATTERN.test(value.trim())
}

function positiveNumber(value) {
  return typeof value === 'number' && Number.isFinite(value) && value > 0 ? value : null
}

/** The hostname of a URL, lower-cased and without a port; empty when unparseable. */
export function hostOf(value) {
  const raw = textOf(value)
  if (!raw) return ''
  try {
    return (new URL(raw).hostname || '').toLowerCase().replace(/\.$/, '')
  } catch {
    return ''
  }
}

/**
 * The registrable domain of a host: two labels, or three when the last two are a
 * second-level suffix (`token.sensenova.cn`, `foo.co.uk`). IPs and `localhost`
 * answer nothing, so a local gateway never claims a catalog provider.
 * @param {string} host
 * @returns {string}
 */
export function registrableDomain(host) {
  const raw = textOf(host).toLowerCase().replace(/\.$/, '')
  if (!raw || raw.includes(':') || raw.includes('[')) return ''
  if (raw === 'localhost') return ''
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(raw)) return ''
  const parts = raw.split('.').filter(Boolean)
  if (parts.length < 2) return ''
  if (parts.length === 2) return parts.join('.')
  const tail = parts.slice(-2)
  if (SECOND_LEVEL.has(tail[0]) && tail[1].length === 2) return parts.slice(-3).join('.')
  return tail.join('.')
}

/**
 * The identity of one configured model in the plugin's own store: a provider
 * route key plus the model id, joined by NUL so neither half can be mistaken for
 * a separator inside the other.
 * @param {string} provider
 * @param {string} id
 * @returns {string} the key, or an empty string when either half is blank.
 */
export function entryKey(provider, id) {
  const route = textOf(provider)
  const model = textOf(id)
  if (!route || !model) return ''
  return `${route}\u0000${model}`
}

function parseModalities(value) {
  if (!Array.isArray(value)) return ['text']
  const allowed = MODALITIES.filter((item) => value.includes(item))
  return allowed.length > 0 ? allowed : ['text']
}

/**
 * Discrete thinking levels a catalog entry states, or null when it states none.
 *
 * Only an `effort` option names levels; `null` inside its values is the Off
 * entry, and a value the host cannot dispatch (such as `none`) is not a level.
 * A toggle or a token budget affirms reasoning without naming levels, so both
 * answer null rather than a guessed level set.
 * @param {object} entry
 * @returns {string[] | null}
 */
function parseReasoningLevels(entry) {
  const options = Array.isArray(entry.reasoning_options) ? entry.reasoning_options : []
  for (const option of options) {
    const record = asRecord(option)
    if (!record || record.type !== 'effort' || !Array.isArray(record.values)) continue
    const declared = new Set()
    for (const value of record.values) {
      if (value === null) {
        declared.add('off')
        continue
      }
      const level = textOf(value).toLowerCase()
      if (!level) continue
      if (level === 'none' || level === 'off' || level === 'disabled') declared.add('off')
      else if (REASONING_LEVELS.includes(level)) declared.add(level)
    }
    const levels = REASONING_LEVELS.filter((level) => declared.has(level))
    return levels.length > 0 ? levels : null
  }
  return null
}

/**
 * Flatten models.dev's provider-first document into the two lists the cache
 * keeps: providers (identity signals) and models (the facts to fill).
 * @param {unknown} data the `api.json` document.
 * @returns {{ providers: object[], models: object[] }}
 */
export function parseCatalogPayload(data) {
  const root = asRecord(data)
  const providers = []
  const models = []
  if (!root) return { providers, models }

  for (const raw of Object.values(root)) {
    const record = asRecord(raw)
    if (!record) continue
    const providerId = textOf(record.id)
    if (!providerId) continue
    const providerName = textOf(record.name) || providerId
    const apiHost = hostOf(record.api)
    const env = Array.isArray(record.env)
      ? record.env.map((item) => textOf(item).toUpperCase()).filter(Boolean)
      : []
    providers.push({ id: providerId, name: providerName, apiHost, domain: registrableDomain(apiHost), env })

    const nested = asRecord(record.models)
    if (!nested) continue
    for (const value of Object.values(nested)) {
      const entry = asRecord(value)
      if (!entry) continue
      const id = textOf(entry.id)
      if (!id) continue
      const limit = asRecord(entry.limit)
      const modalities = asRecord(entry.modalities)
      models.push({
        id,
        key: `${providerId}/${id}`,
        providerId,
        providerName,
        apiHost,
        name: textOf(entry.name) || id,
        contextWindow: positiveNumber(limit?.context),
        maxOutput: positiveNumber(limit?.output),
        input: parseModalities(modalities?.input),
        reasoning: entry.reasoning === true ? true : entry.reasoning === false ? false : null,
        reasoningLevels: parseReasoningLevels(entry),
      })
    }
  }

  return { providers, models }
}

export function emptyCatalogFile() {
  return {
    version: CATALOG_VERSION,
    updatedAt: '',
    providers: [],
    models: [],
    aliases: {},
    ignored: [],
  }
}

/** Aliases map "provider route + model id" to one exact catalog row key. */
function parseAliases(raw) {
  const record = asRecord(raw)
  const aliases = {}
  if (!record) return aliases
  for (const [key, value] of Object.entries(record)) {
    if (!key.includes('\u0000')) continue
    const target = textOf(value)
    if (!target) continue
    aliases[key] = target
  }
  return aliases
}

function parseIgnored(raw) {
  if (!Array.isArray(raw)) return []
  const keys = raw.filter((value) => typeof value === 'string' && value.includes('\u0000'))
  return [...new Set(keys)]
}

/**
 * Read the cache file. A cache written by an older parser carries a shape this
 * version cannot trust, so it keeps its rows but reports no timestamp — which
 * makes `catalogIsStale` re-fetch on the next start instead of asking the user.
 * @param {unknown} raw
 */
export function parseCatalogFile(raw) {
  const empty = emptyCatalogFile()
  const record = asRecord(raw)
  if (!record) return empty
  const current = record.version === CATALOG_VERSION
  return {
    version: CATALOG_VERSION,
    updatedAt: current ? textOf(record.updatedAt) : '',
    providers: Array.isArray(record.providers)
      ? record.providers.filter((row) => asRecord(row) && textOf(row.id)).map((row) => ({
        id: textOf(row.id),
        name: textOf(row.name) || textOf(row.id),
        apiHost: textOf(row.apiHost),
        domain: textOf(row.domain) || registrableDomain(textOf(row.apiHost)),
        env: Array.isArray(row.env) ? row.env.map((item) => textOf(item).toUpperCase()).filter(Boolean) : [],
      }))
      : [],
    models: Array.isArray(record.models)
      ? record.models.filter((row) => asRecord(row) && textOf(row.id) && textOf(row.key)).map((row) => ({
        id: textOf(row.id),
        key: textOf(row.key),
        providerId: textOf(row.providerId),
        providerName: textOf(row.providerName) || textOf(row.providerId),
        apiHost: textOf(row.apiHost),
        name: textOf(row.name) || textOf(row.id),
        contextWindow: positiveNumber(row.contextWindow),
        maxOutput: positiveNumber(row.maxOutput),
        input: parseModalities(row.input),
        reasoning: row.reasoning === true ? true : row.reasoning === false ? false : null,
        reasoningLevels: Array.isArray(row.reasoningLevels)
          ? REASONING_LEVELS.filter((level) => row.reasoningLevels.includes(level))
          : null,
      }))
      : [],
    aliases: parseAliases(record.aliases),
    ignored: parseIgnored(record.ignored),
  }
}

export function catalogIsStale(updatedAt, now = Date.now()) {
  if (!updatedAt) return true
  const time = Date.parse(updatedAt)
  if (!Number.isFinite(time)) return true
  return now - time > STALE_MS
}

export function formatCatalogStamp(updatedAt, count) {
  if (!updatedAt) return count ? `${count} 个模型` : '尚未更新'
  const date = new Date(updatedAt)
  if (Number.isNaN(date.getTime())) return count ? `${count} 个模型` : '尚未更新'
  const pad = (value) => String(value).padStart(2, '0')
  const stamp = `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
  return `${stamp} · ${count} 个模型`
}
