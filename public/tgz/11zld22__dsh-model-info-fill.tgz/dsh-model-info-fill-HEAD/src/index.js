import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import {
  CATALOG_VERSION,
  LLM_PI_AI_NS,
  MODELS_DEV_URL,
  catalogIsStale,
  emptyCatalogFile,
  entryKey,
  formatCatalogStamp,
  isProviderKey,
  parseCatalogFile,
  parseCatalogPayload,
  textOf,
} from './catalog.js'
import { buildIndex, buildStatus, searchCatalog } from './match.js'
import { buildFillOps, writesReasoning } from './fill.js'

export const name = 'dsh-model-info-fill'
export const inject = ['settings', 'timer']

const FETCH_TIMEOUT_MS = 60_000
const PREFIX = '/plugins/models-dev-catalog'

function dataDir() {
  const configured = process.env.DSH_HOME?.trim()
  return configured || join(homedir(), '.dsh')
}

function catalogPath() {
  return join(dataDir(), 'models-dev.json')
}

function messageOf(error) {
  return error instanceof Error ? error.message : String(error)
}

function send(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(body))
}

function isTrustedRequest(req) {
  const address = req.socket?.remoteAddress || ''
  if (address === '127.0.0.1' || address === '::1' || address === '::ffff:127.0.0.1') return true
  const host = req.headers?.host || ''
  const origin = req.headers?.origin || ''
  if (!origin) return false
  try {
    return new URL(origin).host === host
  } catch {
    return false
  }
}

async function readJsonBody(req) {
  const chunks = []
  for await (const chunk of req) chunks.push(chunk)
  const text = Buffer.concat(chunks).toString('utf8').trim()
  if (!text) return {}
  return JSON.parse(text)
}

function urlOf(req) {
  try {
    return new URL(req.url ?? '/', 'http://127.0.0.1')
  } catch {
    return new URL('/', 'http://127.0.0.1')
  }
}

export function apply(ctx) {
  const store = {
    file: emptyCatalogFile(),
    filling: false,
    refreshing: false,
    inflight: null,
  }

  const readConfig = () => {
    const settings = ctx.settings
    if (typeof settings.get === 'function') return settings.get(LLM_PI_AI_NS)
    const row = settings.describe().find((item) => String(item.ns) === LLM_PI_AI_NS)
    if (!row || !row.value || typeof row.value !== 'object') {
      throw new Error(`Settings for ${LLM_PI_AI_NS} are unavailable`)
    }
    return row.value
  }

  const currentConfig = () => {
    try {
      return readConfig()
    } catch {
      return { providers: {} }
    }
  }

  /** The revision a write must name, so a stale fill is refused instead of applied. */
  const revisionOf = () => {
    try {
      if (typeof ctx.settings.describe !== 'function') return undefined
      const rows = ctx.settings.describe({ redactSecrets: true })
      return rows.find((item) => String(item.ns) === LLM_PI_AI_NS)?.revision
    } catch {
      return undefined
    }
  }

  const status = () => {
    const built = buildStatus(currentConfig(), store.file)
    return {
      ok: true,
      updatedAt: store.file.updatedAt,
      modelCount: store.file.models.length,
      stamp: formatCatalogStamp(store.file.updatedAt, store.file.models.length),
      aliasCount: Object.keys(store.file.aliases).length,
      filling: store.filling,
      refreshing: store.refreshing,
      ...built,
    }
  }

  const persist = async () => {
    const path = catalogPath()
    await mkdir(dirname(path), { recursive: true })
    await writeFile(path, `${JSON.stringify(store.file)}\n`, 'utf8')
  }

  const loadCache = async () => {
    try {
      const raw = JSON.parse(await readFile(catalogPath(), 'utf8'))
      store.file = parseCatalogFile(raw)
    } catch (error) {
      if (error && error.code === 'ENOENT') {
        store.file = emptyCatalogFile()
        return
      }
      throw error
    }
  }

  const refreshCatalog = async () => {
    // One fetch at a time: an explicit refresh that lands while the start-up
    // refresh is still running waits for it instead of answering the old cache.
    if (store.inflight) return store.inflight
    store.refreshing = true
    store.inflight = (async () => {
      try {
        const response = await fetch(MODELS_DEV_URL, {
          signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
          headers: { accept: 'application/json' },
        })
        if (!response.ok) throw new Error(`HTTP ${response.status}`)
        const data = await response.json()
        const parsed = parseCatalogPayload(data)
        store.file = {
          version: CATALOG_VERSION,
          updatedAt: new Date().toISOString(),
          providers: parsed.providers,
          models: parsed.models,
          aliases: store.file.aliases,
          ignored: store.file.ignored,
        }
        await persist()
        return store.file
      } finally {
        store.refreshing = false
        store.inflight = null
      }
    })()
    return store.inflight
  }

  /**
   * Write the fill for the current config. Only an explicit action reaches this
   * function; nothing fills on a settings event, so the model form's revision is
   * never invalidated behind the user's back.
   * @param {{ provider?: string, ids?: string[] }} options
   */
  const fillSettings = async (options) => {
    if (store.filling) return { ok: true, filled: 0, providers: [], fields: 0, skipped: true }
    if (store.file.models.length === 0) return { ok: true, filled: 0, providers: [], fields: 0, empty: true }
    store.filling = true
    try {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const plan = buildFillOps(readConfig(), store.file, options)
        if (plan.ops.length === 0) return { ok: true, filled: 0, providers: [], fields: 0 }
        if (writesReasoning(plan.ops)) throw new Error('refused to write a thinking level')
        try {
          await ctx.settings.mutate(LLM_PI_AI_NS, plan.ops, revisionOf())
          return { ok: true, filled: plan.providers.length, providers: plan.providers, fields: plan.fields }
        } catch (error) {
          // A conflict means someone else wrote first; recompute against the
          // config we can now read instead of replaying a stale model list.
          if (error?.code === 'SETTINGS_CONFLICT') continue
          throw error
        }
      }
      return { ok: false, conflict: true, filled: 0, providers: [], fields: 0, error: '配置刚被改动，请重试' }
    } finally {
      store.filling = false
    }
  }

  let registered = false
  const registerWeb = () => {
    if (registered) return true
    const webServer = ctx.get('webServer') ?? ctx.get('httpServer')
    if (webServer === undefined) return false
    registered = true

    const route = (pathname, handler) => {
      ctx.effect(
        () => webServer.register({ kind: 'exact', path: pathname, handler }),
        `models-dev-catalog: ${pathname}`,
      )
    }

    const guard = async (req, res, work) => {
      if (!isTrustedRequest(req)) {
        send(res, 403, { ok: false, error: 'forbidden' })
        return
      }
      try {
        await work()
      } catch (error) {
        send(res, 500, { ok: false, error: messageOf(error) })
      }
    }

    const method = (req, res, expected) => {
      if (req.method === expected) return false
      send(res, 405, { ok: false, error: 'method not allowed' })
      return true
    }

    route(`${PREFIX}/status`, async (req, res) => {
      await guard(req, res, async () => {
        if (method(req, res, 'GET')) return
        send(res, 200, status())
      })
    })

    route(`${PREFIX}/refresh`, async (req, res) => {
      await guard(req, res, async () => {
        if (method(req, res, 'POST')) return
        await refreshCatalog()
        send(res, 200, status())
      })
    })

    route(`${PREFIX}/fill`, async (req, res) => {
      await guard(req, res, async () => {
        if (method(req, res, 'POST')) return
        const body = await readJsonBody(req).catch(() => ({}))
        const provider = textOf(body.provider)
        const id = textOf(body.id)
        const result = await fillSettings({
          ...provider ? { provider } : {},
          ...id ? { ids: [id] } : {},
        })
        send(res, 200, { ...status(), ...result })
      })
    })

    route(`${PREFIX}/alias`, async (req, res) => {
      await guard(req, res, async () => {
        if (method(req, res, 'POST')) return
        const body = await readJsonBody(req).catch(() => ({}))
        const provider = textOf(body.provider)
        const id = textOf(body.id)
        const key = entryKey(provider, id)
        if (!isProviderKey(provider) || !key) {
          send(res, 400, { ok: false, error: 'provider and model id are required' })
          return
        }
        const target = body.key === null ? '' : textOf(body.key)
        if (!target) {
          delete store.file.aliases[key]
        } else {
          if (!buildIndex(store.file).byKey.has(target)) {
            send(res, 400, { ok: false, error: `no catalog row "${target}"` })
            return
          }
          store.file.aliases[key] = target
        }
        await persist()
        send(res, 200, status())
      })
    })

    route(`${PREFIX}/ignore`, async (req, res) => {
      await guard(req, res, async () => {
        if (method(req, res, 'POST')) return
        const body = await readJsonBody(req).catch(() => ({}))
        const provider = textOf(body.provider)
        const id = textOf(body.id)
        const key = entryKey(provider, id)
        if (!isProviderKey(provider) || !key) {
          send(res, 400, { ok: false, error: 'provider and model id are required' })
          return
        }
        const ignored = new Set(store.file.ignored)
        if (body.ignored === false) ignored.delete(key)
        else ignored.add(key)
        store.file.ignored = [...ignored]
        await persist()
        send(res, 200, status())
      })
    })

    route(`${PREFIX}/search`, async (req, res) => {
      await guard(req, res, async () => {
        if (method(req, res, 'GET')) return
        const url = urlOf(req)
        const rows = searchCatalog(store.file, url.searchParams.get('q') ?? '', Number(url.searchParams.get('limit')) || 20)
        send(res, 200, { ok: true, rows })
      })
    })

    return true
  }

  ctx.effect(() => {
    let disposed = false
    const start = async () => {
      try {
        await loadCache()
      } catch (error) {
        ctx.logger?.warn?.(`[models-dev-catalog] failed to load cache: ${messageOf(error)}`)
        store.file = emptyCatalogFile()
      }
      if (disposed) return
      if (catalogIsStale(store.file.updatedAt)) {
        refreshCatalog().catch((error) => {
          ctx.logger?.warn?.(`[models-dev-catalog] refresh failed: ${messageOf(error)}`)
        })
      }
    }
    start()
    return () => {
      disposed = true
    }
  }, 'models-dev-catalog: cache')

  if (!registerWeb()) {
    ctx.effect(() => {
      const stop = ctx.interval(() => {
        if (registerWeb()) stop()
      }, 250)
      return stop
    }, 'models-dev-catalog: wait for web server')
  }
}
