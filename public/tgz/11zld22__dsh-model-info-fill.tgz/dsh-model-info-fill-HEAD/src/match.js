/** Match a configured model against the catalog, and plan what may be filled. */

import {
  MODALITIES,
  REASONING_LEVELS,
  asRecord,
  entryKey,
  hostOf,
  isPositiveInt,
  isProviderKey,
  registrableDomain,
  textOf,
} from './catalog.js'

function push(map, key, value) {
  if (!map.has(key)) map.set(key, [])
  map.get(key).push(value)
}

function addTo(map, key, value) {
  if (!map.has(key)) map.set(key, new Set())
  map.get(key).add(value)
}

/** A model id without its provider prefix or variant suffix — the comparable name. */
export function normalizeModelId(id) {
  const raw = textOf(id).toLowerCase()
  if (!raw) return ''
  const tail = raw.split('/').filter(Boolean).pop() ?? raw
  return tail.split(':')[0].trim()
}

/** The leading path segment of a vendor-prefixed id (`opencode-zen-free/beam-free`), if any. */
export function vendorNamespace(id) {
  const parts = textOf(id).toLowerCase().split('/').filter(Boolean)
  return parts.length > 1 ? parts[0] : ''
}

/**
 * Index the cached catalog once per evaluation.
 *
 * Provider identity comes from the four things models.dev publishes about a
 * provider — its api host's registrable domain, its credential variable names,
 * and its id/name — so a configured route can be recognised as that provider
 * instead of every same-named model in the database competing with it.
 * @param {object} catalog the parsed cache file.
 */
export function buildIndex(catalog) {
  const providers = new Map()
  const rowsByProvider = new Map()
  const byId = new Map()
  const byBase = new Map()
  const byKey = new Map()

  for (const provider of Array.isArray(catalog?.providers) ? catalog.providers : []) {
    const id = textOf(provider?.id)
    if (!id) continue
    providers.set(id, {
      id,
      name: textOf(provider.name) || id,
      apiHost: textOf(provider.apiHost),
      domain: textOf(provider.domain) || registrableDomain(textOf(provider.apiHost)),
      env: Array.isArray(provider.env) ? provider.env.map((item) => textOf(item).toUpperCase()).filter(Boolean) : [],
    })
  }

  for (const row of Array.isArray(catalog?.models) ? catalog.models : []) {
    const id = textOf(row?.id)
    const key = textOf(row?.key)
    if (!id || !key) continue
    const providerId = textOf(row.providerId) || key.split('/')[0]
    byKey.set(key, row)
    push(byId, id.toLowerCase(), row)
    const base = normalizeModelId(id)
    if (base) push(byBase, base, row)
    push(rowsByProvider, providerId, row)
    if (!providers.has(providerId)) {
      providers.set(providerId, {
        id: providerId,
        name: textOf(row.providerName) || providerId,
        apiHost: textOf(row.apiHost),
        domain: registrableDomain(textOf(row.apiHost)),
        env: [],
      })
    }
  }

  const byDomain = new Map()
  const byEnv = new Map()
  const byName = new Map()
  for (const provider of providers.values()) {
    if (provider.domain) addTo(byDomain, provider.domain, provider.id)
    for (const env of provider.env) addTo(byEnv, env, provider.id)
    for (const name of [provider.id, provider.name]) {
      const lowered = textOf(name).toLowerCase()
      if (lowered && !byName.has(lowered)) byName.set(lowered, provider.id)
    }
  }

  return {
    providers,
    rowsByProvider,
    byId,
    byBase,
    byKey,
    byDomain,
    byEnv,
    byName,
    aliases: asRecord(catalog?.aliases) ?? {},
    ignored: new Set(Array.isArray(catalog?.ignored) ? catalog.ignored : []),
  }
}

/**
 * The models.dev providers a configured route is allowed to be.
 *
 * The endpoint's registrable domain is the strongest signal, because models.dev
 * publishes each provider's api URL; a credential variable name and the route's
 * own name only narrow it further when the endpoint says nothing.
 * @param {object} index from {@link buildIndex}.
 * @param {string} providerKey the configured route key.
 * @param {object} profile the route's config.
 * @returns {Set<string>} catalog provider ids.
 */
export function providerIdsOf(index, providerKey, profile) {
  const ids = new Set()
  const domain = registrableDomain(hostOf(profile?.baseURL))
  if (domain) for (const id of index.byDomain.get(domain) ?? []) ids.add(id)

  if (ids.size === 0) {
    const env = textOf(profile?.apiKeyEnv).toUpperCase()
    if (env) for (const id of index.byEnv.get(env) ?? []) ids.add(id)
  }

  for (const name of [providerKey, profile?.displayName]) {
    const hit = textOf(name).toLowerCase()
    if (!hit) continue
    const id = index.byName.get(hit)
    if (id) ids.add(id)
  }
  return ids
}

/** Catalog rows for a model id inside one candidate set: exact id first, then the bare name. */
function pickRows(rows, id) {
  const lowered = textOf(id).toLowerCase()
  const exact = rows.filter((row) => textOf(row.id).toLowerCase() === lowered)
  if (exact.length > 0) return exact
  const base = normalizeModelId(lowered)
  if (!base) return []
  return rows.filter((row) => normalizeModelId(row.id) === base)
}

/**
 * The value every row agrees on, or `null` when they disagree.
 * @param {object[]} rows
 * @param {(row: object) => unknown} read
 */
function agreed(rows, read) {
  if (!Array.isArray(rows) || rows.length === 0) return { value: null, conflict: false }
  const first = read(rows[0])
  const stamp = JSON.stringify(first === undefined ? null : first)
  const conflict = rows.some((row) => {
    const value = read(row)
    return JSON.stringify(value === undefined ? null : value) !== stamp
  })
  return { value: conflict ? null : first, conflict }
}

/**
 * The four facts a fill can copy, each with the disagreement flag that keeps a
 * conflicting field from being copied from whichever row happened to be first.
 * @param {object[]} rows the matched rows.
 */
export function fieldsOf(rows) {
  const input = agreed(rows, (row) => (Array.isArray(row?.input) ? [...row.input].sort().join('+') : null))
  return {
    contextWindow: agreed(rows, (row) => (isPositiveInt(row?.contextWindow) ? row.contextWindow : null)),
    maxTokens: agreed(rows, (row) => (isPositiveInt(row?.maxOutput) ? row.maxOutput : null)),
    input: { value: input.value ? input.value.split('+') : null, conflict: input.conflict },
    name: agreed(rows, (row) => textOf(row?.name) || null),
  }
}

/**
 * Resolve one configured model to catalog rows.
 *
 * Order: an explicit alias, then the route's own provider (exact id, then bare
 * name), then the whole database by the exact id, then the vendor namespace a
 * gateway prefixes onto its ids, and last by the bare name — which is the
 * loosest step, because many resellers publish the same model under it.
 * @param {string} providerKey
 * @param {object} profile
 * @param {string} entryId
 * @param {object} index from {@link buildIndex}.
 */
export function resolveModel(providerKey, profile, entryId, index) {
  const id = textOf(entryId)
  if (!id) return { kind: 'none', rows: [], fields: fieldsOf([]), staleAlias: false }

  const key = entryKey(providerKey, id)
  const alias = key ? asRecord(index.aliases)?.[key] : undefined
  if (typeof alias === 'string' && alias) {
    const row = index.byKey.get(alias)
    if (row) return { kind: 'alias', rows: [row], fields: fieldsOf([row]), staleAlias: false }
  }
  const staleAlias = Boolean(alias)

  const scoped = providerIdsOf(index, providerKey, profile)
  if (scoped.size > 0) {
    const rows = []
    for (const providerId of scoped) for (const row of index.rowsByProvider.get(providerId) ?? []) rows.push(row)
    const hit = pickRows(rows, id)
    if (hit.length > 0) return { kind: 'provider', rows: hit, fields: fieldsOf(hit), staleAlias }
  }

  const lowered = id.toLowerCase()
  const exact = index.byId.get(lowered)
  if (exact?.length) return { kind: 'global', rows: exact, fields: fieldsOf(exact), staleAlias }

  const namespace = vendorNamespace(lowered)
  if (namespace) {
    const tail = lowered.split('/').slice(1).join('/')
    const rows = []
    for (const [providerId, providerRows] of index.rowsByProvider) {
      const candidate = providerId.toLowerCase()
      if (!(candidate === namespace || candidate.startsWith(namespace) || namespace.startsWith(candidate))) continue
      for (const row of providerRows) {
        const id = textOf(row.id).toLowerCase()
        if (id === tail || id.endsWith(`/${tail}`)) rows.push(row)
      }
    }
    if (rows.length > 0) return { kind: 'namespace', rows, fields: fieldsOf(rows), staleAlias }
  }

  const base = normalizeModelId(lowered)
  const keyed = base ? index.byBase.get(base) : undefined
  if (keyed?.length) return { kind: 'global', rows: keyed, fields: fieldsOf(keyed), staleAlias }

  return { kind: 'none', rows: [], fields: fieldsOf([]), staleAlias }
}

/** The thinking levels a configured model declares, mirroring the host's reading. */
export function declaredLevels(entry) {
  const value = entry?.reasoningEfforts
  if (value === false) return ['off']
  const record = asRecord(value)
  if (!record) return []
  return REASONING_LEVELS.filter((level) => {
    if (!Object.prototype.hasOwnProperty.call(record, level)) return false
    const wire = record[level]
    return level === 'off'
      ? wire === null || typeof wire === 'string'
      : typeof wire === 'string' && wire.length > 0
  })
}

/** One read-only line about what the catalog says about a model's thinking. */
export function reasoningHint(row) {
  if (!row) return null
  if (Array.isArray(row.reasoningLevels) && row.reasoningLevels.length > 0) {
    const thinking = row.reasoningLevels.filter((level) => level !== 'off')
    if (thinking.length > 0) return `会思考：${thinking.join(' / ')}`
    return '只声明了关闭思考'
  }
  if (row.reasoning === false) return '不思考'
  if (row.reasoning === true) return '会思考（百科未写档位）'
  return null
}

/**
 * A provider's configured default effort against what its models declare.
 * Read-only: the host offers no provider-scoped control, and a level its models
 * do not offer makes every request fail with UNSUPPORTED_REASONING_EFFORT.
 * @param {object} profile
 * @returns {{ level: string, unsupported: string[] } | null}
 */
export function reasoningCheck(profile) {
  const level = textOf(profile?.reasoning)
  if (!REASONING_LEVELS.includes(level)) return null
  const unsupported = []
  for (const entry of Array.isArray(profile?.models) ? profile.models : []) {
    if (declaredLevels(entry).includes(level)) continue
    const id = textOf(entry?.id)
    if (id) unsupported.push(id)
  }
  return { level, unsupported }
}

/**
 * What a fill would add to one model, and why a field is being skipped.
 *
 * Only four facts are ever written, and only where they add information: a
 * missing capacity, image support the entry does not claim, and a display name.
 * A blank capacity already falls back to the provider's defaults, so writing a
 * default would be noise; thinking is the host's to edit, so it is never written.
 * @param {object} entry the configured model row.
 * @param {object} resolved from {@link resolveModel}.
 * @returns {{ fill: object, conflicts: string[], reasoningHint: string | null }}
 */
export function planFill(entry, resolved) {
  const fields = resolved?.fields ?? {}
  const fill = {}
  const conflicts = []

  if (!isPositiveInt(entry?.contextWindow)) {
    if (fields.contextWindow?.conflict) conflicts.push('contextWindow')
    else if (isPositiveInt(fields.contextWindow?.value)) fill.contextWindow = fields.contextWindow.value
  }
  if (!isPositiveInt(entry?.maxTokens)) {
    if (fields.maxTokens?.conflict) conflicts.push('maxTokens')
    else if (isPositiveInt(fields.maxTokens?.value)) fill.maxTokens = fields.maxTokens.value
  }
  const currentInput = Array.isArray(entry?.input) ? entry.input : []
  if (!currentInput.includes('image')) {
    if (fields.input?.conflict) conflicts.push('input')
    else if (Array.isArray(fields.input?.value) && fields.input.value.includes('image')) fill.input = [...MODALITIES]
  }
  if (!textOf(entry?.name)) {
    const name = textOf(fields.name?.value)
    if (fields.name?.conflict) conflicts.push('name')
    else if (name) fill.name = name
  }

  return { fill, conflicts, reasoningHint: reasoningHint(resolved?.rows?.[0]) }
}

function candidatesOf(rows, limit = 5) {
  const seen = new Set()
  const out = []
  for (const row of Array.isArray(rows) ? rows : []) {
    const key = textOf(row?.key)
    if (!key || seen.has(key)) continue
    seen.add(key)
    out.push({
      key,
      id: textOf(row.id),
      providerName: textOf(row.providerName),
      contextWindow: isPositiveInt(row.contextWindow) ? row.contextWindow : null,
      maxOutput: isPositiveInt(row.maxOutput) ? row.maxOutput : null,
      image: Array.isArray(row.input) && row.input.includes('image'),
      reasoningLevels: Array.isArray(row.reasoningLevels) ? row.reasoningLevels : null,
    })
    if (out.length >= limit) break
  }
  return out
}

export function isIgnored(index, provider, id) {
  const key = entryKey(provider, id)
  return Boolean(key) && index.ignored.has(key)
}

/**
 * Every configured model, what the catalog says about it, and what a fill would
 * write — grouped by provider for the settings panel.
 * @param {object} config the resolved llm-pi-ai section.
 * @param {object} catalog the parsed cache file.
 */
export function buildStatus(config, catalog) {
  const index = buildIndex(catalog)
  const groups = []
  const counts = { models: 0, fillable: 0, fields: 0, unmatched: 0, conflicted: 0, ignored: 0 }
  const providers = asRecord(config?.providers)
  if (!providers) return { counts, groups }

  for (const [provider, raw] of Object.entries(providers)) {
    if (!isProviderKey(provider)) continue
    const profile = asRecord(raw)
    if (!profile || !Array.isArray(profile.models) || profile.models.length === 0) continue
    const scope = providerIdsOf(index, provider, profile)
    const group = {
      provider,
      displayName: textOf(profile.displayName) || provider,
      catalogProviders: [...scope].map((id) => textOf(index.providers.get(id)?.name) || id),
      reasoning: reasoningCheck(profile),
      models: [],
    }

    for (const entry of profile.models) {
      const id = textOf(entry?.id)
      if (!id) continue
      const ignored = isIgnored(index, provider, id)
      const resolved = resolveModel(provider, profile, id, index)
      const plan = planFill(entry, resolved)
      const levels = declaredLevels(entry)
      const row = {
        provider,
        id,
        name: textOf(entry?.name) || id,
        current: {
          contextWindow: isPositiveInt(entry?.contextWindow) ? entry.contextWindow : null,
          maxTokens: isPositiveInt(entry?.maxTokens) ? entry.maxTokens : null,
          image: Array.isArray(entry?.input) && entry.input.includes('image'),
          reasoning: entry?.reasoningEfforts === false ? false : levels.length > 0 ? levels : null,
        },
        match: resolved.kind,
        rowKey: resolved.rows[0]?.key ?? null,
        source: textOf(resolved.rows[0]?.providerName) || null,
        candidateCount: resolved.rows.length,
        candidates: candidatesOf(resolved.rows),
        fill: plan.fill,
        conflicts: plan.conflicts,
        reasoningHint: plan.reasoningHint,
        ignored,
        staleAlias: resolved.staleAlias,
      }
      counts.models += 1
      if (ignored) counts.ignored += 1
      else if (row.conflicts.length > 0) counts.conflicted += 1
      else if (Object.keys(row.fill).length > 0) {
        counts.fillable += 1
        counts.fields += Object.keys(row.fill).length
      } else if (resolved.kind === 'none') counts.unmatched += 1
      group.models.push(row)
    }
    groups.push(group)
  }

  return { counts, groups }
}

/**
 * Rank catalog rows for the manual picker: exact id, then prefix, then bare
 * name, then containment — shortest id first inside a tier.
 * @param {object} catalog
 * @param {string} query
 * @param {number} limit
 */
export function searchCatalog(catalog, query, limit = 20) {
  const needle = textOf(query).toLowerCase()
  if (!needle) return []
  const max = isPositiveInt(limit) ? Math.min(limit, 100) : 20
  const scored = []
  for (const row of Array.isArray(catalog?.models) ? catalog.models : []) {
    const id = textOf(row?.id).toLowerCase()
    if (!id) continue
    const name = textOf(row.name).toLowerCase()
    let score = 0
    if (id === needle) score = 100
    else if (id.startsWith(needle)) score = 80
    else if (normalizeModelId(id) === needle) score = 70
    else if (id.includes(needle)) score = 55
    else if (name.includes(needle)) score = 40
    else continue
    scored.push({ row, score })
  }
  scored.sort((a, b) => b.score - a.score
    || a.row.id.length - b.row.id.length
    || a.row.id.localeCompare(b.row.id)
    || a.row.key.localeCompare(b.row.key))

  const unique = new Map()
  for (const item of scored) {
    if (unique.size >= max) break
    if (!unique.has(item.row.key)) unique.set(item.row.key, item.row)
  }
  return [...unique.values()].map((row) => ({
    key: row.key,
    id: row.id,
    providerName: row.providerName,
    contextWindow: isPositiveInt(row.contextWindow) ? row.contextWindow : null,
    maxOutput: isPositiveInt(row.maxOutput) ? row.maxOutput : null,
    image: Array.isArray(row.input) && row.input.includes('image'),
    reasoningLevels: Array.isArray(row.reasoningLevels) ? row.reasoningLevels : null,
  }))
}
