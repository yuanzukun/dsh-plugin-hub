/** A small models.dev document plus helpers, shared by the offline tests. */

import { parseCatalogPayload } from '../src/catalog.js'

export const PAYLOAD = {
  alpha: {
    id: 'alpha',
    name: 'Alpha AI',
    env: ['ALPHA_API_KEY'],
    api: 'https://api.alpha.example/v1',
    models: {
      'glm-5.3': {
        id: 'glm-5.3',
        name: 'GLM-5.3',
        limit: { context: 1000000, output: 131072 },
        modalities: { input: ['text', 'image'] },
        reasoning: true,
        reasoning_options: [{ type: 'effort', values: [null, 'low', 'medium', 'high'] }],
      },
      'alpha-flash': {
        id: 'alpha-flash',
        name: 'Alpha Flash',
        limit: { context: 262144, output: 32768 },
        modalities: { input: ['text'] },
        reasoning: false,
      },
    },
  },
  beta: {
    id: 'beta',
    name: 'Beta Gateway',
    env: ['BETA_KEY'],
    api: 'https://beta.example.com/v1',
    models: {
      'glm-5.3': {
        id: 'glm-5.3',
        name: 'GLM 5.3 (Beta)',
        limit: { context: 256000, output: 131072 },
        modalities: { input: ['text'] },
        reasoning: true,
        reasoning_options: [{ type: 'effort', values: ['none', 'high'] }],
      },
      'local-only': {
        id: 'local-only',
        name: 'Local Only',
        limit: { context: 8000, output: 1000 },
      },
    },
  },
  opencode: {
    id: 'opencode',
    name: 'OpenCode',
    api: 'https://opencode.example.net/v1',
    models: {
      'opencode/beam-free': {
        id: 'opencode/beam-free',
        name: 'Beam Free',
        limit: { context: 1000000, output: 131072 },
        modalities: { input: ['text', 'image'] },
      },
    },
  },
}

export function catalogFrom(payload = PAYLOAD, extra = {}) {
  const parsed = parseCatalogPayload(payload)
  return {
    version: 3,
    // Fresh by default: a stale fixture would make the plugin fetch on start,
    // which is a network call no offline test may make.
    updatedAt: new Date().toISOString(),
    providers: parsed.providers,
    models: parsed.models,
    aliases: {},
    ignored: [],
    ...extra,
  }
}

/** A route whose endpoint matches nothing in the catalog. */
export function lonely(models) {
  return { providers: { lonely: { apiKeyEnv: 'LONELY_KEY', api: 'openai-completions', baseURL: 'https://lonely.example.org/v1', models } } }
}

/** A route that resolves to the alpha provider by endpoint. */
export function alphaRoute(models) {
  return { providers: { alpha: { apiKeyEnv: 'ALPHA_API_KEY', api: 'openai-completions', baseURL: 'https://api.alpha.example/v1', models } } }
}
