import test from 'node:test'
import assert from 'node:assert/strict'
import {
  CATALOG_VERSION,
  catalogIsStale,
  emptyCatalogFile,
  entryKey,
  formatCatalogStamp,
  hostOf,
  parseCatalogFile,
  parseCatalogPayload,
  registrableDomain,
} from '../src/catalog.js'
import { PAYLOAD, catalogFrom } from '../test-utils/fixtures.mjs'

test('parseCatalogPayload keeps provider identity and model facts', () => {
  const { providers, models } = parseCatalogPayload(PAYLOAD)
  assert.deepEqual(providers.map((row) => row.id).sort(), ['alpha', 'beta', 'opencode'])
  const alpha = providers.find((row) => row.id === 'alpha')
  assert.equal(alpha.apiHost, 'api.alpha.example')
  assert.equal(alpha.domain, 'alpha.example')
  assert.deepEqual(alpha.env, ['ALPHA_API_KEY'])

  const row = models.find((item) => item.key === 'alpha/glm-5.3')
  assert.equal(row.providerId, 'alpha')
  assert.equal(row.providerName, 'Alpha AI')
  assert.equal(row.contextWindow, 1000000)
  assert.equal(row.maxOutput, 131072)
  assert.deepEqual(row.input, ['text', 'image'])
  assert.deepEqual(row.reasoningLevels, ['off', 'low', 'medium', 'high'])
  assert.equal(row.reasoning, true)
})

test('parseCatalogPayload ignores a document that is not an object', () => {
  assert.deepEqual(parseCatalogPayload(null), { providers: [], models: [] })
  assert.deepEqual(parseCatalogPayload('nope'), { providers: [], models: [] })
})

test('parseCatalogPayload reads effort values, including the null Off entry', () => {
  const { models } = parseCatalogPayload({
    p: {
      id: 'p',
      name: 'P',
      api: 'https://p.example/v1',
      models: {
        a: { id: 'a', reasoning: true, reasoning_options: [{ type: 'effort', values: [null, 'low', 'high'] }] },
        b: { id: 'b', reasoning: true, reasoning_options: [{ type: 'effort', values: ['none', 'high'] }] },
        c: { id: 'c', reasoning: true, reasoning_options: [{ type: 'toggle' }] },
        d: { id: 'd', reasoning: true, reasoning_options: [{ type: 'budget_tokens', min: 1, max: 8 }] },
        e: { id: 'e', reasoning: true },
        f: { id: 'f', reasoning: false },
      },
    },
  })
  const byId = new Map(models.map((row) => [row.id, row]))
  assert.deepEqual(byId.get('a').reasoningLevels, ['off', 'low', 'high'])
  assert.deepEqual(byId.get('b').reasoningLevels, ['off', 'high'])
  assert.equal(byId.get('c').reasoningLevels, null)
  assert.equal(byId.get('d').reasoningLevels, null)
  assert.equal(byId.get('e').reasoningLevels, null)
  assert.equal(byId.get('e').reasoning, true)
  assert.equal(byId.get('f').reasoning, false)
})

test('parseCatalogPayload defaults missing input to text and skips malformed rows', () => {
  const { models } = parseCatalogPayload({
    p: {
      id: 'p',
      models: {
        a: { id: 'a' },
        b: { name: 'no id' },
        c: null,
      },
    },
  })
  assert.equal(models.length, 1)
  assert.deepEqual(models[0].input, ['text'])
  assert.equal(models[0].contextWindow, null)
  assert.equal(models[0].maxOutput, null)
})

test('registrableDomain finds the domain, including two-label suffixes', () => {
  assert.equal(registrableDomain('token.sensenova.cn'), 'sensenova.cn')
  assert.equal(registrableDomain('api.alpha.example'), 'alpha.example')
  assert.equal(registrableDomain('www.infomaniak.com'), 'infomaniak.com')
  assert.equal(registrableDomain('openrouter.ai'), 'openrouter.ai')
  assert.equal(registrableDomain('foo.co.uk'), 'foo.co.uk')
  assert.equal(registrableDomain('example.com.cn'), 'example.com.cn')
  assert.equal(registrableDomain('127.0.0.1'), '')
  assert.equal(registrableDomain('localhost'), '')
  assert.equal(registrableDomain('[::1]'), '')
  assert.equal(registrableDomain(''), '')
})

test('hostOf strips the port and rejects unparseable urls', () => {
  assert.equal(hostOf('http://127.0.0.1:3425/v1'), '127.0.0.1')
  assert.equal(hostOf('https://Token.SenseNova.cn/v1'), 'token.sensenova.cn')
  assert.equal(hostOf('not a url'), '')
  assert.equal(hostOf(undefined), '')
})

test('entryKey joins the route and the model id and rejects a blank half', () => {
  assert.equal(entryKey('magpie', 'workbuddy/x'), 'magpie\u0000workbuddy/x')
  assert.equal(entryKey('', 'x'), '')
  assert.equal(entryKey('magpie', '  '), '')
})

test('parseCatalogFile keeps a current cache and treats an older one as stale', () => {
  const current = parseCatalogFile(catalogFrom(undefined, { updatedAt: '2026-01-02T03:04:05.000Z' }))
  assert.equal(current.version, CATALOG_VERSION)
  assert.equal(current.updatedAt, '2026-01-02T03:04:05.000Z')
  assert.equal(current.providers.length, 3)
  assert.equal(current.models.length, 5)
  assert.equal(catalogIsStale(current.updatedAt, Date.parse('2026-01-03T00:00:00.000Z')), false)

  const older = parseCatalogFile({ ...catalogFrom(), version: 2 })
  assert.equal(older.version, CATALOG_VERSION)
  assert.equal(older.updatedAt, '')
  assert.equal(catalogIsStale(older.updatedAt), true)
  assert.equal(older.models.length, 5, 'the rows stay usable until the refetch lands')
})

test('parseCatalogFile validates aliases and ignores', () => {
  const parsed = parseCatalogFile({
    ...catalogFrom(),
    aliases: {
      'magpie\u0000workbuddy/hy4': 'alpha/glm-5.3',
      'no separator': 'alpha/glm-5.3',
      'magpie\u0000blank': '   ',
    },
    ignored: ['magpie\u0000a', 'magpie\u0000a', 'junk'],
  })
  assert.deepEqual(Object.keys(parsed.aliases), ['magpie\u0000workbuddy/hy4'])
  assert.deepEqual(parsed.ignored, ['magpie\u0000a'])
})

test('parseCatalogFile answers an empty file for junk', () => {
  assert.deepEqual(parseCatalogFile(undefined), emptyCatalogFile())
  assert.deepEqual(parseCatalogFile([]), emptyCatalogFile())
})

test('catalogIsStale uses the seven-day window and rejects an unparseable stamp', () => {
  const now = Date.parse('2026-02-01T00:00:00.000Z')
  assert.equal(catalogIsStale('2026-01-26T00:00:00.000Z', now), false)
  assert.equal(catalogIsStale('2026-01-25T00:00:00.000Z', now), false, 'exactly seven days is not stale yet')
  assert.equal(catalogIsStale('2026-01-24T00:00:00.000Z', now), true)
  assert.equal(catalogIsStale(''), true)
  assert.equal(catalogIsStale('yesterday'), true)
})

test('formatCatalogStamp reads as one line in the panel', () => {
  assert.equal(formatCatalogStamp('', 0), '尚未更新')
  assert.equal(formatCatalogStamp('', 4), '4 个模型')
  assert.match(formatCatalogStamp('2026-01-02T03:04:05.000Z', 4), /^\d{4}\/\d{1,2}\/\d{1,2} \d{2}:\d{2}:\d{2} · 4 个模型$/)
})
