import test from 'node:test'
import assert from 'node:assert/strict'
import { buildFillOps, writesReasoning } from '../src/fill.js'
import { catalogFrom } from '../test-utils/fixtures.mjs'

const catalog = catalogFrom()

function alphaConfig(models, extra = {}) {
  return {
    providers: {
      alpha: {
        apiKeyEnv: 'ALPHA_API_KEY',
        api: 'openai-completions',
        baseURL: 'https://api.alpha.example/v1',
        compat: { thinkingFormat: 'openai' },
        modelOverrides: {},
        ...extra,
        models,
      },
    },
  }
}

test('a fill writes the four facts a missing model lacks', () => {
  const config = alphaConfig([{ id: 'glm-5.3' }])
  const { ops, providers, fields } = buildFillOps(config, catalog)
  assert.equal(ops.length, 1)
  assert.deepEqual(providers, ['alpha'])
  assert.equal(fields, 4)
  assert.deepEqual(ops[0], {
    op: 'set',
    path: ['providers', 'alpha', 'models'],
    value: [{
      id: 'glm-5.3',
      contextWindow: 1000000,
      maxTokens: 131072,
      input: ['text', 'image'],
      name: 'GLM-5.3',
    }],
  })
})

test('a fill keeps every field the entry already had', () => {
  const config = alphaConfig([{
    id: 'glm-5.3',
    name: '我的名字',
    contextWindow: 1234,
    maxTokens: 56,
    input: ['text'],
    compat: { maxTokensField: 'max_tokens' },
    headers: { 'x-test': '1' },
  }])
  const { ops, fields } = buildFillOps(config, catalog)
  assert.equal(fields, 1)
  assert.deepEqual(ops[0].value[0], {
    id: 'glm-5.3',
    name: '我的名字',
    contextWindow: 1234,
    maxTokens: 56,
    input: ['text', 'image'],
    compat: { maxTokensField: 'max_tokens' },
    headers: { 'x-test': '1' },
  })
})

test('a fill never touches thinking, and never writes a provider default', () => {
  const efforts = { off: null, low: 'low', high: 'high' }
  const config = alphaConfig([{ id: 'glm-5.3', reasoningEfforts: efforts }], { reasoning: 'high' })
  const { ops } = buildFillOps(config, catalog)
  assert.equal(writesReasoning(ops), false)
  assert.equal(ops.every((op) => op.path[2] !== 'reasoning'), true)
  assert.deepEqual(ops[0].value[0].reasoningEfforts, efforts)
  assert.equal('reasoning' in ops[0].value[0], false)
  assert.deepEqual(config.providers.alpha.models[0].reasoningEfforts, efforts, 'the config object is not mutated')
})

test('a model with everything already set emits no op', () => {
  const config = alphaConfig([{
    id: 'glm-5.3',
    name: 'GLM-5.3',
    contextWindow: 1000000,
    maxTokens: 131072,
    input: ['text', 'image'],
  }])
  assert.deepEqual(buildFillOps(config, catalog), { ops: [], providers: [], fields: 0 })
})

test('an unmatched model is left alone instead of receiving a default', () => {
  const config = {
    providers: {
      lonely: {
        baseURL: 'https://lonely.example.org/v1',
        models: [{ id: 'nobody-home' }, { id: 'glm-5.3' }],
      },
    },
  }
  const { ops, fields } = buildFillOps(config, catalog)
  assert.equal(fields, 1, 'glm-5.3 only takes the maxTokens every copy agrees on')
  assert.deepEqual(ops[0].value[0], { id: 'nobody-home' })
  assert.deepEqual(ops[0].value[1], { id: 'glm-5.3', maxTokens: 131072 })
  assert.equal(ops[0].value[0].contextWindow, undefined)
  assert.equal(ops[0].value[0].maxTokens, undefined)
})

test('a text-only catalog claim adds no input field', () => {
  const config = alphaConfig([{ id: 'alpha-flash' }])
  const { ops } = buildFillOps(config, catalog)
  assert.deepEqual(ops[0].value[0], {
    id: 'alpha-flash',
    contextWindow: 262144,
    maxTokens: 32768,
    name: 'Alpha Flash',
  })
})

test('an ignored model is skipped', () => {
  const key = 'lonely\u0000glm-5.3'
  const catalogWithIgnore = catalogFrom(undefined, { ignored: [key] })
  const config = {
    providers: { lonely: { baseURL: 'https://lonely.example.org/v1', models: [{ id: 'glm-5.3' }] } },
  }
  assert.deepEqual(buildFillOps(config, catalogWithIgnore), { ops: [], providers: [], fields: 0 })
})

test('the provider filter limits the write to one route', () => {
  const config = {
    providers: {
      alpha: { baseURL: 'https://api.alpha.example/v1', models: [{ id: 'glm-5.3' }] },
      beta: { baseURL: 'https://beta.example.com/v1', models: [{ id: 'local-only' }] },
    },
  }
  const { ops, providers } = buildFillOps(config, catalog, { provider: 'beta' })
  assert.deepEqual(providers, ['beta'])
  assert.equal(ops.length, 1)
  assert.deepEqual(ops[0].value[0], {
    id: 'local-only',
    contextWindow: 8000,
    maxTokens: 1000,
    name: 'Local Only',
  })
})

test('the id filter limits the write to one model', () => {
  const config = alphaConfig([{ id: 'glm-5.3' }, { id: 'alpha-flash' }])
  const { ops, fields } = buildFillOps(config, catalog, { provider: 'alpha', ids: ['alpha-flash'] })
  assert.equal(fields, 3)
  assert.deepEqual(ops[0].value[0], { id: 'glm-5.3' })
  assert.deepEqual(ops[0].value[1], {
    id: 'alpha-flash',
    contextWindow: 262144,
    maxTokens: 32768,
    name: 'Alpha Flash',
  })
})

test('a route with nothing to add writes nothing at all', () => {
  const config = { providers: { alpha: { baseURL: 'https://api.alpha.example/v1', models: [] } } }
  assert.deepEqual(buildFillOps(config, catalog), { ops: [], providers: [], fields: 0 })
  assert.deepEqual(buildFillOps({}, catalog), { ops: [], providers: [], fields: 0 })
})

test('a route key that is not a legal identifier is skipped', () => {
  const config = { providers: { 'Bad Key': { models: [{ id: 'glm-5.3' }] } } }
  assert.deepEqual(buildFillOps(config, catalog), { ops: [], providers: [], fields: 0 })
})

test('a model row without an id keeps its place in the list', () => {
  const config = alphaConfig([{ name: 'no id' }, { id: 'glm-5.3' }])
  const { ops } = buildFillOps(config, catalog)
  assert.deepEqual(ops[0].value[0], { name: 'no id' })
  assert.equal(ops[0].value.length, 2)
})

test('writesReasoning spots a provider default the planner must never emit', () => {
  assert.equal(writesReasoning([{ op: 'set', path: ['providers', 'a', 'reasoning'], value: 'high' }]), true)
  assert.equal(writesReasoning([{ op: 'unset', path: ['providers', 'a', 'reasoning'] }]), true)
  assert.equal(writesReasoning([{ op: 'set', path: ['providers', 'a', 'models'], value: [] }]), false)
  assert.equal(writesReasoning([]), false)
  assert.equal(writesReasoning(undefined), false)
})
