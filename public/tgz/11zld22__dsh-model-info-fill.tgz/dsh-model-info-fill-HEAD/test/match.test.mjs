import test from 'node:test'
import assert from 'node:assert/strict'
import { entryKey } from '../src/catalog.js'
import {
  buildIndex,
  buildStatus,
  declaredLevels,
  isIgnored,
  normalizeModelId,
  planFill,
  providerIdsOf,
  reasoningCheck,
  resolveModel,
  searchCatalog,
  vendorNamespace,
} from '../src/match.js'
import { PAYLOAD, alphaRoute, catalogFrom, lonely } from '../test-utils/fixtures.mjs'

const catalog = catalogFrom()
const index = buildIndex(catalog)

test('normalizeModelId drops the provider prefix and the variant suffix', () => {
  assert.equal(normalizeModelId('google/gemma-4-31b-it:free'), 'gemma-4-31b-it')
  assert.equal(normalizeModelId('GLM-5.3'), 'glm-5.3')
  assert.equal(normalizeModelId(''), '')
})

test('vendorNamespace only answers for a prefixed id', () => {
  assert.equal(vendorNamespace('opencode-zen-free/beam-free'), 'opencode-zen-free')
  assert.equal(vendorNamespace('glm-5.3'), '')
})

test('the endpoint identifies the provider, so a same-named rival row never competes', () => {
  const profile = alphaRoute([]).providers.alpha
  const resolved = resolveModel('alpha', profile, 'glm-5.3', index)
  assert.equal(resolved.kind, 'provider')
  assert.equal(resolved.rows.length, 1)
  assert.equal(resolved.rows[0].key, 'alpha/glm-5.3')
  assert.equal(resolved.fields.contextWindow.value, 1000000)
  assert.equal(resolved.fields.contextWindow.conflict, false)
})

test('the route name and the credential variable also identify a provider', () => {
  const byName = resolveModel('beta', {}, 'glm-5.3', index)
  assert.equal(byName.kind, 'provider')
  assert.equal(byName.rows[0].key, 'beta/glm-5.3')

  const byEnv = resolveModel('vendor-x', { apiKeyEnv: 'ALPHA_API_KEY' }, 'alpha-flash', index)
  assert.equal(byEnv.kind, 'provider')
  assert.equal(byEnv.rows[0].key, 'alpha/alpha-flash')
})

test('a local gateway endpoint claims no provider', () => {
  const profile = { apiKeyEnv: 'MAGPIE_KEY', baseURL: 'http://127.0.0.1:3425/v1' }
  assert.deepEqual([...providerIdsOf(index, 'magpie', profile)], [])
})

test('a gateway namespace resolves an id the bare name cannot pin', () => {
  const profile = { baseURL: 'http://127.0.0.1:3425/v1' }
  const resolved = resolveModel('magpie', profile, 'opencode-zen-free/beam-free', index)
  assert.equal(resolved.kind, 'namespace')
  assert.equal(resolved.rows[0].key, 'opencode/opencode/beam-free')
  assert.equal(resolved.fields.contextWindow.value, 1000000)
})

test('the bare name still resolves when no namespace matches', () => {
  const profile = { baseURL: 'http://127.0.0.1:3425/v1' }
  const resolved = resolveModel('magpie', profile, 'unknown-ns/alpha-flash', index)
  assert.equal(resolved.kind, 'global')
  assert.equal(resolved.rows[0].key, 'alpha/alpha-flash')
})

test('an alias picks one exact row before every heuristic', () => {
  const aliased = catalogFrom(PAYLOAD, {
    aliases: { [entryKey('lonely', 'mystery')]: 'beta/glm-5.3' },
  })
  const aliasedIndex = buildIndex(aliased)
  const resolved = resolveModel('lonely', {}, 'mystery', aliasedIndex)
  assert.equal(resolved.kind, 'alias')
  assert.equal(resolved.rows[0].key, 'beta/glm-5.3')
  assert.equal(resolved.fields.contextWindow.value, 256000)
})

test('an alias pointing at a row that no longer exists falls through and is flagged', () => {
  const aliased = catalogFrom(PAYLOAD, {
    aliases: { [entryKey('alpha', 'glm-5.3')]: 'beta/removed' },
  })
  const resolved = resolveModel('alpha', alphaRoute([]).providers.alpha, 'glm-5.3', buildIndex(aliased))
  assert.equal(resolved.kind, 'provider')
  assert.equal(resolved.staleAlias, true)
})

test('disagreeing copies only block the field they disagree on', () => {
  const resolved = resolveModel('lonely', {}, 'glm-5.3', index)
  assert.equal(resolved.kind, 'global')
  assert.equal(resolved.rows.length, 2)
  const plan = planFill({ id: 'glm-5.3' }, resolved)
  assert.deepEqual(plan.fill, { maxTokens: 131072 })
  assert.deepEqual(plan.conflicts.sort(), ['contextWindow', 'input', 'name'])
})

test('planFill adds only what the entry lacks', () => {
  const resolved = resolveModel('alpha', alphaRoute([]).providers.alpha, 'glm-5.3', index)
  const plan = planFill({ id: 'glm-5.3' }, resolved)
  assert.deepEqual(plan.fill, {
    contextWindow: 1000000,
    maxTokens: 131072,
    input: ['text', 'image'],
    name: 'GLM-5.3',
  })

  const complete = planFill({
    id: 'glm-5.3',
    name: 'Mine',
    contextWindow: 1000,
    maxTokens: 100,
    input: ['text', 'image'],
  }, resolved)
  assert.deepEqual(complete.fill, {})
  assert.deepEqual(complete.conflicts, [])
})

test('planFill never writes a text-only catalog image claim', () => {
  const resolved = resolveModel('alpha', alphaRoute([]).providers.alpha, 'alpha-flash', index)
  const plan = planFill({ id: 'alpha-flash', input: ['text'] }, resolved)
  assert.equal('input' in plan.fill, false)
})

test('planFill reports the catalog thinking as a read-only hint', () => {
  const hit = { reasoningLevels: ['off', 'low', 'high'], reasoning: true }
  assert.equal(planFill({}, { rows: [hit], fields: {} }).reasoningHint, '会思考：low / high')
  assert.equal(planFill({}, { rows: [{ reasoningLevels: null, reasoning: true }], fields: {} }).reasoningHint, '会思考（百科未写档位）')
  assert.equal(planFill({}, { rows: [{ reasoningLevels: null, reasoning: false }], fields: {} }).reasoningHint, '不思考')
  assert.equal(planFill({}, { rows: [], fields: {} }).reasoningHint, null)
})

test('declaredLevels mirrors what the host would dispatch', () => {
  assert.deepEqual(declaredLevels({ reasoningEfforts: { off: null, low: 'low' } }), ['off', 'low'])
  assert.deepEqual(declaredLevels({ reasoningEfforts: { off: 'minimal', high: 'high' } }), ['off', 'high'])
  assert.deepEqual(declaredLevels({ reasoningEfforts: false }), ['off'])
  assert.deepEqual(declaredLevels({}), [])
  assert.deepEqual(declaredLevels({ reasoningEfforts: { off: null } }), ['off'])
  assert.deepEqual(declaredLevels({ reasoningEfforts: { low: '' } }), [])
})

test('reasoningCheck names the models that refuse the provider default', () => {
  const check = reasoningCheck({
    reasoning: 'high',
    models: [
      { id: 'takes-high', reasoningEfforts: { off: null, high: 'high' } },
      { id: 'off-only', reasoningEfforts: false },
      { id: 'undeclared' },
      { id: 'no-off-either', reasoningEfforts: { low: 'low' } },
    ],
  })
  assert.deepEqual(check, { level: 'high', unsupported: ['off-only', 'undeclared', 'no-off-either'] })
  assert.equal(reasoningCheck({ models: [] }), null)
  assert.equal(reasoningCheck({ reasoning: 'ultra', models: [] }), null)
})

test('isIgnored reads the stored key, not the model name', () => {
  const ignored = buildIndex(catalogFrom(PAYLOAD, { ignored: [entryKey('lonely', 'x')] }))
  assert.equal(isIgnored(ignored, 'lonely', 'x'), true)
  assert.equal(isIgnored(ignored, 'lonely', 'y'), false)
})

test('buildStatus counts fillable, conflicted and unmatched models', () => {
  const config = {
    providers: {
      alpha: {
        baseURL: 'https://api.alpha.example/v1',
        models: [
          { id: 'glm-5.3' },
          { id: 'alpha-flash', contextWindow: 1, maxTokens: 2, input: ['text'], name: 'A' },
        ],
      },
      lonely: {
        baseURL: 'https://lonely.example.org/v1',
        models: [
          { id: 'glm-5.3' },
          { id: 'nobody-home' },
        ],
      },
    },
  }
  const status = buildStatus(config, catalog)
  assert.equal(status.counts.models, 4)
  assert.equal(status.counts.fillable, 1)
  assert.equal(status.counts.fields, 4)
  assert.equal(status.counts.conflicted, 1)
  assert.equal(status.counts.unmatched, 1)

  const alpha = status.groups.find((group) => group.provider === 'alpha')
  assert.deepEqual(alpha.catalogProviders, ['Alpha AI'])
  const flash = alpha.models.find((row) => row.id === 'alpha-flash')
  assert.deepEqual(flash.fill, {})
  assert.equal(flash.match, 'provider')
})

test('buildStatus marks an ignored model and leaves it out of every other count', () => {
  const config = lonely([{ id: 'nobody-home' }])
  const ignored = catalogFrom(PAYLOAD, { ignored: [entryKey('lonely', 'nobody-home')] })
  const status = buildStatus(config, ignored)
  assert.equal(status.counts.ignored, 1)
  assert.equal(status.counts.unmatched, 0)
  assert.equal(status.groups[0].models[0].ignored, true)
})

test('buildStatus survives a config with no providers', () => {
  const status = buildStatus({}, catalog)
  assert.deepEqual(status.counts, { models: 0, fillable: 0, fields: 0, unmatched: 0, conflicted: 0, ignored: 0 })
  assert.deepEqual(status.groups, [])
})

test('searchCatalog ranks exact ids first and caps the list', () => {
  const rows = searchCatalog(catalog, 'glm-5.3', 2)
  assert.equal(rows.length, 2)
  assert.deepEqual(rows.map((row) => row.key).sort(), ['alpha/glm-5.3', 'beta/glm-5.3'])
  assert.equal(rows[0].providerName.length > 0, true)
  assert.deepEqual(searchCatalog(catalog, ''), [])
  assert.deepEqual(searchCatalog(catalog, 'zzz'), [])
})

test('searchCatalog finds a model by its display name', () => {
  const rows = searchCatalog(catalog, 'beam')
  assert.equal(rows.length, 1)
  assert.equal(rows[0].key, 'opencode/opencode/beam-free')
  assert.equal(rows[0].image, true)
})
