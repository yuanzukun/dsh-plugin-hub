import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { catalogIsStale } from '../src/catalog.js'
import { apply } from '../src/index.js'
import { catalogFrom } from '../test-utils/fixtures.mjs'

const BASE = '/plugins/models-dev-catalog'

/** The document the refresh test serves, so the fetch never leaves the machine. */
const PAYLOAD_MINIMAL = {
  fresh: {
    id: 'fresh',
    name: 'Fresh',
    api: 'https://fresh.example/v1',
    models: { 'only-model': { id: 'only-model', limit: { context: 4096, output: 512 } } },
  },
}

function harness(options = {}) {
  const routes = new Map()
  const writes = []
  const attempts = []
  let revision = 4
  let conflicts = options.conflicts ?? 0
  const config = options.config ?? { providers: {} }

  const settings = {
    describe() {
      if (options.legacyGet || options.missing) return []
      return [{ ns: 'llm-pi-ai', revision, value: config }]
    },
    async mutate(ns, ops, expected) {
      attempts.push({ ns, ops, expected })
      if (conflicts > 0) {
        conflicts -= 1
        revision += 1
        const error = new Error('settings namespace "llm-pi-ai" changed since it was read')
        error.code = 'SETTINGS_CONFLICT'
        throw error
      }
      assert.equal(ns, 'llm-pi-ai')
      if (!options.legacyGet) assert.equal(expected, revision)
      writes.push(ops)
      for (const op of ops) {
        let parent = config
        for (const key of op.path.slice(0, -1)) parent = parent[key]
        parent[op.path.at(-1)] = op.value
      }
      revision += 1
    },
  }
  if (options.legacyGet) settings.get = () => config

  const webServer = { register({ path, handler }) { routes.set(path, handler) } }
  apply({
    settings,
    get(name) { return name === 'webServer' ? webServer : undefined },
    on() {},
    effect(fn, label) {
      if (label?.startsWith('models-dev-catalog: /')) fn()
      if (options.cache && label === 'models-dev-catalog: cache') fn()
    },
    timeout() {},
    interval() { return () => {} },
    logger: { warn() {} },
  })

  async function request(path, body = {}, method = 'POST') {
    const pathname = path.split('?')[0]
    const handler = routes.get(`${BASE}/${pathname}`)
    assert.equal(typeof handler, 'function', `no route for ${pathname}`)
    const req = {
      method,
      url: `${BASE}/${path}`,
      headers: options.headers ?? {},
      socket: { remoteAddress: options.remoteAddress ?? '127.0.0.1' },
      async *[Symbol.asyncIterator]() {
        if (method !== 'GET') yield Buffer.from(JSON.stringify(body))
      },
    }
    const response = { status: 0, body: null }
    const res = {
      writeHead(status) { response.status = status },
      end(data) { response.body = JSON.parse(data) },
    }
    await handler(req, res)
    return response
  }

  return { config, request, writes, attempts }
}

/** Run a test body with a cache file the plugin will load at start. */
async function withCache(run, catalog = catalogFrom()) {
  const home = await mkdtemp(join(tmpdir(), 'dsh-model-info-fill-'))
  await writeFile(join(home, 'models-dev.json'), `${JSON.stringify(catalog)}\n`)
  const previous = process.env.DSH_HOME
  process.env.DSH_HOME = home
  try {
    return await run()
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
    await rm(home, { recursive: true, force: true })
  }
}

async function waitForCatalog(app) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const response = await app.request('status', {}, 'GET')
    if (response.body.modelCount > 0) return response.body
    await new Promise((resolve) => setTimeout(resolve, 10))
  }
  throw new Error('the cache never loaded')
}

test('the shared fixture is fresh, so no test reaches the network on start', () => {
  // A stale fixture made the plugin refresh in the background, and a refresh
  // that outlived a test wrote into the real DSH_HOME cache.
  assert.equal(catalogIsStale(catalogFrom().updatedAt), false)
})

test('status reports the catalog and the models a fill would touch', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      config: { providers: { alpha: { baseURL: 'https://api.alpha.example/v1', models: [{ id: 'glm-5.3' }] } } },
    })
    const body = await waitForCatalog(app)
    assert.equal(body.ok, true)
    assert.match(body.stamp, /个模型$/)
    assert.deepEqual(body.counts, { models: 1, fillable: 1, fields: 4, unmatched: 0, conflicted: 0, ignored: 0 })
    const row = body.groups[0].models[0]
    assert.equal(row.match, 'provider')
    assert.equal(row.source, 'Alpha AI')
    assert.deepEqual(row.fill, {
      contextWindow: 1000000,
      maxTokens: 131072,
      input: ['text', 'image'],
      name: 'GLM-5.3',
    })
  })
})

test('fill writes once per provider and reports what it wrote', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      config: { providers: { alpha: { baseURL: 'https://api.alpha.example/v1', models: [{ id: 'glm-5.3' }] } } },
    })
    await waitForCatalog(app)
    const response = await app.request('fill', {})
    assert.equal(response.status, 200)
    assert.equal(response.body.filled, 1)
    assert.equal(response.body.fields, 4)
    assert.equal(app.writes.length, 1)
    assert.equal(app.attempts[0].expected, 4)
    assert.equal(app.config.providers.alpha.models[0].contextWindow, 1000000)
    assert.equal('reasoningEfforts' in app.config.providers.alpha.models[0], false)
  })
})

test('a second fill has nothing left to write', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      config: { providers: { alpha: { baseURL: 'https://api.alpha.example/v1', models: [{ id: 'glm-5.3' }] } } },
    })
    await waitForCatalog(app)
    await app.request('fill', {})
    const again = await app.request('fill', {})
    assert.equal(again.body.fields, 0)
    assert.equal(app.writes.length, 1)
  })
})

test('fill can target one model of one provider', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      config: {
        providers: {
          alpha: {
            baseURL: 'https://api.alpha.example/v1',
            models: [{ id: 'glm-5.3' }, { id: 'alpha-flash' }],
          },
        },
      },
    })
    await waitForCatalog(app)
    const response = await app.request('fill', { provider: 'alpha', id: 'alpha-flash' })
    assert.equal(response.body.fields, 3)
    assert.deepEqual(app.config.providers.alpha.models[0], { id: 'glm-5.3' })
    assert.equal(app.config.providers.alpha.models[1].contextWindow, 262144)
  })
})

test('an alias pins one catalog row, and can be cleared', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      config: { providers: { lonely: { baseURL: 'https://lonely.example.org/v1', models: [{ id: 'glm-5.3' }] } } },
    })
    const started = await waitForCatalog(app)
    assert.equal(started.counts.conflicted, 1)

    const aliased = await app.request('alias', { provider: 'lonely', id: 'glm-5.3', key: 'beta/glm-5.3' })
    assert.equal(aliased.status, 200)
    const row = aliased.body.groups[0].models[0]
    assert.equal(row.match, 'alias')
    assert.equal(row.conflicts.length, 0)
    assert.equal(row.fill.contextWindow, 256000)

    const cleared = await app.request('alias', { provider: 'lonely', id: 'glm-5.3', key: null })
    assert.equal(cleared.status, 200)
    assert.equal(cleared.body.groups[0].models[0].match, 'global')
    assert.equal(cleared.body.counts.conflicted, 1)
  })
})

test('an alias to a row that does not exist is refused', async () => {
  await withCache(async () => {
    const app = harness({ cache: true })
    await waitForCatalog(app)
    const response = await app.request('alias', { provider: 'alpha', id: 'glm-5.3', key: 'nobody/here' })
    assert.equal(response.status, 400)
    assert.match(response.body.error, /no catalog row/)
  })
})

test('an alias without a provider or an id is refused', async () => {
  await withCache(async () => {
    const app = harness({ cache: true })
    await waitForCatalog(app)
    assert.equal((await app.request('alias', { provider: 'Bad Key', id: 'x', key: 'alpha/glm-5.3' })).status, 400)
    assert.equal((await app.request('alias', { provider: 'alpha', id: '  ', key: 'alpha/glm-5.3' })).status, 400)
  })
})

test('ignoring a model takes it out of the unmatched list and can be undone', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      config: { providers: { lonely: { baseURL: 'https://lonely.example.org/v1', models: [{ id: 'nobody-home' }] } } },
    })
    const started = await waitForCatalog(app)
    assert.equal(started.counts.unmatched, 1)

    const ignored = await app.request('ignore', { provider: 'lonely', id: 'nobody-home', ignored: true })
    assert.equal(ignored.body.counts.unmatched, 0)
    assert.equal(ignored.body.counts.ignored, 1)

    const restored = await app.request('ignore', { provider: 'lonely', id: 'nobody-home', ignored: false })
    assert.equal(restored.body.counts.ignored, 0)
    assert.equal(restored.body.counts.unmatched, 1)
  })
})

test('search answers candidate rows for the picker', async () => {
  await withCache(async () => {
    const app = harness({ cache: true })
    await waitForCatalog(app)
    const response = await app.request('search?q=glm-5.3&limit=2', {}, 'GET')
    assert.equal(response.status, 200)
    assert.deepEqual(response.body.rows.map((row) => row.key).sort(), ['alpha/glm-5.3', 'beta/glm-5.3'])
    const empty = await app.request('search?q=', {}, 'GET')
    assert.deepEqual(empty.body.rows, [])
  })
})

test('the wrong method is refused on every route', async () => {
  await withCache(async () => {
    const app = harness({ cache: true })
    await waitForCatalog(app)
    assert.equal((await app.request('status', {}, 'POST')).status, 405)
    assert.equal((await app.request('fill', {}, 'GET')).status, 405)
    assert.equal((await app.request('refresh', {}, 'GET')).status, 405)
    assert.equal((await app.request('alias', {}, 'GET')).status, 405)
    assert.equal((await app.request('ignore', {}, 'GET')).status, 405)
    assert.equal((await app.request('search?q=x', {}, 'POST')).status, 405)
  })
})

test('a request from another origin without a matching host is refused', async () => {
  await withCache(async () => {
    const app = harness({ cache: true, remoteAddress: '10.0.0.5' })
    const response = await app.request('status', {}, 'GET')
    assert.equal(response.status, 403)
    assert.equal(response.body.error, 'forbidden')
  })
})

test('a stale revision is retried once against the fresh config', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      conflicts: 1,
      config: { providers: { alpha: { baseURL: 'https://api.alpha.example/v1', models: [{ id: 'glm-5.3' }] } } },
    })
    await waitForCatalog(app)
    const response = await app.request('fill', {})
    assert.equal(response.status, 200)
    assert.equal(response.body.fields, 4)
    assert.equal(app.attempts.length, 2)
    assert.equal(app.writes.length, 1)
  })
})

test('two conflicts in a row surface as a retry message and write nothing', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      conflicts: 2,
      config: { providers: { alpha: { baseURL: 'https://api.alpha.example/v1', models: [{ id: 'glm-5.3' }] } } },
    })
    await waitForCatalog(app)
    const response = await app.request('fill', {})
    assert.equal(response.status, 200)
    assert.equal(response.body.ok, false)
    assert.match(response.body.error, /配置刚被改动/)
    assert.equal(app.attempts.length, 2)
    assert.equal(app.writes.length, 0)
  })
})

test('fill refuses when the model settings entry is unavailable', async () => {
  await withCache(async () => {
    const app = harness({ cache: true, missing: true })
    await waitForCatalog(app)
    const response = await app.request('fill', {})
    assert.equal(response.status, 500)
    assert.match(response.body.error, /unavailable/)
    assert.equal(app.writes.length, 0)
  })
})

test('a host that only offers settings.get still fills', async () => {
  await withCache(async () => {
    const app = harness({
      cache: true,
      legacyGet: true,
      config: { providers: { alpha: { baseURL: 'https://api.alpha.example/v1', models: [{ id: 'glm-5.3' }] } } },
    })
    await waitForCatalog(app)
    const response = await app.request('fill', {})
    assert.equal(response.status, 200)
    assert.equal(response.body.fields, 4)
    assert.equal(app.writes.length, 1)
  })
})

test('refresh persists the fetched catalog and keeps aliases and ignores', async () => {
  const previous = process.env.DSH_HOME
  const home = await mkdtemp(join(tmpdir(), 'dsh-model-info-fill-refresh-'))
  process.env.DSH_HOME = home
  try {
    const { readFile } = await import('node:fs/promises')
    const seeded = catalogFrom(undefined, {
      aliases: { 'alpha\u0000mystery': 'beta/glm-5.3' },
      ignored: ['lonely\u0000nobody-home'],
    })
    await writeFile(join(home, 'models-dev.json'), `${JSON.stringify(seeded)}\n`)
    const app = harness({ cache: true })
    await waitForCatalog(app)

    const original = globalThis.fetch
    globalThis.fetch = async () => ({
      ok: true,
      status: 200,
      async json() { return PAYLOAD_MINIMAL },
    })
    try {
      const response = await app.request('refresh', {})
      assert.equal(response.status, 200)
      assert.equal(response.body.modelCount, 1)
    } finally {
      globalThis.fetch = original
    }

    const stored = JSON.parse(await readFile(join(home, 'models-dev.json'), 'utf8'))
    assert.deepEqual(stored.aliases, { 'alpha\u0000mystery': 'beta/glm-5.3' })
    assert.deepEqual(stored.ignored, ['lonely\u0000nobody-home'])
    assert.equal(stored.models.length, 1)
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
    await rm(home, { recursive: true, force: true })
  }
})
