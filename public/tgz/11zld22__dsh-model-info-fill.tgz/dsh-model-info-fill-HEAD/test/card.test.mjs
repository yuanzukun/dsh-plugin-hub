import assert from 'node:assert/strict'
import test from 'node:test'


/**
 * The provider card borrows the host's own action row through a portal, which
 * is exactly the kind of placement that cannot be checked from the source. This
 * rehearsal mounts the real component into the real markup (a <li> whose header
 * carries the host's rowActions span) and inspects what ends up there.
 *
 * It needs react, react-dom and jsdom; without them the test skips instead of
 * failing, so the suite still runs on a bare checkout.
 */

const CLIENT = new URL('../src/client.js', import.meta.url).href

const HOST_CARD = (provider) => '<ul><li class="rowCard">'
  + `<div class="rowHead"><span class="rowIdentity"><span class="rowName">${provider}</span></span>`
  + '<span class="zf92ZW_rowActions">'
  + '<button type="button" class="zf92ZW_secondaryButton">编辑</button>'
  + '<button type="button" class="zf92ZW_dangerButton">删除</button>'
  + '</span></div><div class="seat"></div></li></ul>'

const STATUS = {
  ok: true,
  stamp: '2026-08-16 10:00',
  counts: { models: 2, fillable: 1, fields: 1, unmatched: 0, conflicted: 0, ignored: 0 },
  groups: [
    {
      provider: 'sensenova',
      catalogProviders: ['SenseNova (China)'],
      models: [{
        key: 'sensenova\u0000kimi-k3',
        id: 'kimi-k3',
        match: 'provider',
        candidateCount: 1,
        fill: { input: ['text', 'image'] },
        conflicts: [],
        ignored: false,
      }],
    },
    { provider: 'quiet', catalogProviders: [], models: [] },
  ],
}

async function stage() {
  let deps
  try {
    deps = {
      jsdom: await import('jsdom'),
      react: (await import('react')).default,
      reactDom: (await import('react-dom')).default,
      root: (await import('react-dom/client')).createRoot,
    }
  } catch {
    return null
  }

  const dom = new deps.jsdom.JSDOM('<!doctype html><html><head></head><body></body></html>', {
    url: 'http://127.0.0.1/',
  })
  const { window } = dom
  for (const key of ['window', 'document', 'HTMLElement', 'Element', 'Node', 'MutationObserver', 'getComputedStyle']) {
    globalThis[key] = window[key] ?? globalThis[key]
  }
  globalThis.fetch = async (url) => ({
    ok: true,
    status: 200,
    json: async () => (String(url).includes('/fill')
      ? { ok: true, filled: 1, fields: 1, providers: ['sensenova'] }
      : STATUS),
  })

  let plugin = null
  globalThis.window.__ModuleLoader__ = {
    load: (spec) => {
      plugin = spec.factory((id) => {
        if (id === 'react') return deps.react
        if (id === 'react-dom') return deps.reactDom
        throw new Error(`unexpected module ${id}`)
      })
    },
  }
  await import(CLIENT)

  const components = []
  plugin.apply({
    effect(fn) { fn(); return () => {} },
    interval(fn) { fn(); return () => {} },
    get() { return undefined },
    slots: {
      inject(name, register) { register() },
      register(spec, component) { components.push({ spec, component }); return () => {} },
    },
    settings: { get: () => undefined },
  })

  const component = components.find((entry) => entry.spec.name === 'settings.models.provider-card')
  assert.ok(component !== undefined, 'the provider card registers itself')

  return { ...deps, window, document, card: component.component }
}

const settle = async () => {
  await new Promise((resolve) => setTimeout(resolve, 60))
}

test('the fill button sits in the card row, just before the edit button', { skip: process.env.MDC_SKIP_DOM === '1' }, async (t) => {
  const dom = await stage()
  if (dom === null) {
    t.skip('react, react-dom and jsdom are not installed (npm i -D react react-dom jsdom)')
    return
  }

  dom.document.body.innerHTML = HOST_CARD('商汤日日新（SenseNova）')
  const seat = dom.document.querySelector('.seat')
  const root = dom.root(seat)
  root.render(dom.react.createElement(dom.card, { provider: { provider: 'sensenova' }, configured: true }))
  await settle()

  const row = dom.document.querySelector('[class*="rowActions"]')
  const labels = [...row.children].map((node) => node.textContent)
  assert.deepEqual(labels, ['补全缺失字段 · 1', '编辑', '删除'])
  assert.match(row.firstElementChild.className, /zf92ZW_secondaryButton/, 'borrows the host button style')
  assert.equal(dom.document.querySelectorAll('.mdc-card').length, 0, 'no extra row under the card')

  // A click reports its result on the button itself, then the button retires.
  row.firstElementChild.dispatchEvent(new dom.window.MouseEvent('click', { bubbles: true }))
  await settle()
  assert.equal([...row.children][0].textContent, '已补 1 个字段')

  // Unmounting has to take the relocated node with it.
  root.unmount()
  await settle()
  assert.deepEqual([...row.children].map((node) => node.textContent), ['编辑', '删除'])

  dom.document.body.innerHTML = HOST_CARD('ali')
  const quietSeat = dom.document.querySelector('.seat')
  const quiet = dom.root(quietSeat)
  quiet.render(dom.react.createElement(dom.card, { provider: { provider: 'quiet' }, configured: true }))
  await settle()
  assert.deepEqual(
    [...dom.document.querySelector('[class*="rowActions"]').children].map((node) => node.textContent),
    ['编辑', '删除'],
    'a provider with nothing to fill adds no button',
  )
  quiet.unmount()
})
