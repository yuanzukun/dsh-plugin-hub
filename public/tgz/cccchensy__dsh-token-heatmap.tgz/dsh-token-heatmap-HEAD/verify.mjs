/**
 * Verification probe for the Host half. Not part of the shipped plugin.
 *
 * Run: node verify.mjs
 * It exercises the real corpus in this machine's Harness home and prints the
 * aggregate the browser half would receive.
 */
import { buildPayload } from './lib/aggregate.js';
import { DEFAULTS, SESSIONS_DIR } from './lib/config.js';
import { currentSignature, decompressAll, eventFingerprint, foldLogText, listSessionLogs, scanSessions, signatureOf } from './lib/scan.js';
import { dayKeyOf, normalizeUsage } from './lib/tokens.js';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const failures = [];
const check = (name, condition, detail) => {
  if (condition) {
    console.log(`  ok   ${name}`);
  } else {
    failures.push(name);
    console.log(`  FAIL ${name}${detail === undefined ? '' : ` — ${detail}`}`);
  }
};

// ── DST: this half of the file runs in a zone that observes it ───────────────
// The day window used to advance by a fixed 24 hours. A local day is not always
// that long, so crossing a DST transition shifted the cursor's wall clock over
// midnight: one calendar day was emitted twice and another skipped, and since the
// totals are summed from those entries, tokens vanished and one day was counted
// twice. This machine's zone has no DST, which is exactly why the bug survived a
// green suite — so this part re-enters the file with TZ set to New York.
if (process.env.DSH_TH_DST_PART === '1') {
  const seeds = {
    '2023-03-12': 1000, // spring forward
    '2023-11-05': 1000, // fall back
    '2024-01-15': 1000,
    '2024-03-10': 1000, // spring forward
  };
  const days = new Map(Object.entries(seeds).map(([key, tokens]) => [key, {
    totalTokens: tokens,
    uncachedInputTokens: tokens,
    outputTokens: 0,
    cacheReadTokens: 0,
    cacheWriteTokens: 0,
    reasoningTokens: 0,
  }]));
  const now = new Date(2024, 2, 20, 12, 0, 0).getTime();
  const payload = buildPayload({ days, windowDays: 371, now });
  const keys = payload.days.map((entry) => entry.date);
  const counts = new Map();
  for (const key of keys) counts.set(key, (counts.get(key) ?? 0) + 1);
  const duplicated = [...counts].filter(([, n]) => n > 1).map(([key]) => key);
  const missing = Object.keys(seeds).filter((key) => !keys.includes(key));
  const first = payload.days[0].date.split('-').map(Number);
  const lead = new Date(first[0], first[1] - 1, first[2]).getDay();
  const misaligned = payload.days.filter((entry, index) => {
    const parts = entry.date.split('-').map(Number);
    return (index + lead) % 7 !== new Date(parts[0], parts[1] - 1, parts[2]).getDay();
  }).length;

  check('no calendar day is emitted twice', duplicated.length === 0, duplicated.join(', '));
  check('no calendar day is skipped', missing.length === 0, missing.join(', '));
  check('every cell sits on its own weekday row', misaligned === 0, String(misaligned));
  check('tokens survive the transition', payload.totals.tokens === 4000, String(payload.totals.tokens));
  check('active days survive the transition', payload.totals.activeDays === 4, String(payload.totals.activeDays));
  check('the window still ends on the reference day', payload.days[payload.days.length - 1].today === true);
  console.log(`\n${failures.length === 0 ? 'DST PART PASSED' : `${failures.length} DST CHECK(S) FAILED`}`);
  process.exit(failures.length === 0 ? 0 : 1);
}

console.log('token normalization (mirrors the official Turn-usage disclosure)');
check('plain counts derive a total', (() => {
  const u = normalizeUsage({ inputTokens: 10, outputTokens: 5, cacheReadTokens: 0, cacheWriteTokens: 0 });
  return u !== undefined && u.totalTokens === 15;
})());
check('explicit total is authoritative', (() => {
  const u = normalizeUsage({ inputTokens: 10, outputTokens: 5, cacheReadTokens: 100, cacheWriteTokens: 2, totalTokens: 117 });
  return u !== undefined && u.totalTokens === 117 && u.cacheReadTokens === 100;
})());
check('a contradictory total is rejected', normalizeUsage({
  inputTokens: 10, outputTokens: 5, cacheReadTokens: 100, cacheWriteTokens: 2, totalTokens: 7,
}) === undefined);
check('negative counts are rejected', normalizeUsage({ inputTokens: -1, outputTokens: 5 }) === undefined);
check('a fractional count is rejected', normalizeUsage({ inputTokens: 1.5, outputTokens: 5 }) === undefined);
check('missing cache buckets without a total are rejected', normalizeUsage({ inputTokens: 10, outputTokens: 5 }) === undefined);
check('reasoning above output is rejected', normalizeUsage({
  inputTokens: 1, outputTokens: 5, cacheReadTokens: 0, cacheWriteTokens: 0, reasoningTokens: 9,
}) === undefined);
check('partial cache buckets with a total are accepted', (() => {
  const u = normalizeUsage({ inputTokens: 1, outputTokens: 5, cacheReadTokens: 4, totalTokens: 10 });
  return u !== undefined && u.totalTokens === 10 && u.cacheWriteTokens === 0;
})());

console.log(`\nscan of ${SESSIONS_DIR}`);
const started = Date.now();
const firstWalk = await currentSignature();
const signature = firstWalk.signature;
const result = await scanSessions({ root: SESSIONS_DIR, includeSubagents: DEFAULTS.includeSubagents });
console.log(`  files=${result.files} unreadable=${result.unreadable} samples=${result.countedSamples} skipped=${result.skippedSamples} days=${result.days.size} in ${Date.now() - started}ms`);
check('at least one session log was read', result.files > 0);
check('the scan produced day buckets', result.days.size > 0);

// The corpus is LIVE: the agent running this check is itself being logged, so a full
// scan takes long enough for its own session log to grow underneath. A plain "two
// walks are equal" assertion therefore fails at random and says nothing about the
// cache. What has to hold is that the signature is a pure function of one listing,
// and that it moves only when a log really moved.
const secondWalk = await currentSignature();
check('the signature is a pure function of the file listing',
  signatureOf(firstWalk.files) === firstWalk.signature
  && signatureOf(secondWalk.files) === secondWalk.signature);
check('the signature moves only when a log actually changed', (() => {
  if (secondWalk.signature === firstWalk.signature) return true;
  if (secondWalk.files.length !== firstWalk.files.length) return true;
  return secondWalk.files.some((after, index) => {
    const before = firstWalk.files[index];
    return before === undefined
      || before.file !== after.file
      || before.size !== after.size
      || Math.round(before.mtimeMs) !== Math.round(after.mtimeMs);
  });
})(), 'the signature moved without any file changing');

// Multi-frame decompression: a session log is one Zstandard frame per append,
// and every Node zstd API decodes exactly the first one.
const logs = await listSessionLogs(SESSIONS_DIR);
const largest = logs.reduce((best, file) => (best === undefined || file.size > best.size ? file : best), undefined);
if (largest !== undefined) {
  const text = decompressAll(await fs.readFile(largest.file));
  const folded = foldLogText(text);
  const lines = text.split('\n').filter(Boolean).length;
  console.log(`  largest log: ${largest.size} bytes → ${text.length} chars, ${lines} records, ${folded.steps.length} usage samples`);
  check('multi-frame decompression yields far more than the first frame', text.length > 1000, `chars=${text.length}`);
  check('the log header parses into a session identity', typeof folded.header?.sessionId === 'string' && folded.header.sessionId.length > 0);
  check('every record parses as JSON', lines > 0 && folded.steps.length + folded.skipped > 0);
  // Compaction summaries are billed calls with no turn or step, so the per-step
  // uniqueness applies to the messages; a session may compact more than once.
  const stepKeys = folded.steps.filter((s) => s.kind !== 'compaction').map((s) => `${s.turn}/${s.step}`);
  check('one sample survives per (turn, step)', new Set(stepKeys).size === stepKeys.length);
  check('every sample says which kind of billed event it is', folded.steps.every((s) => s.kind === 'message' || s.kind === 'compaction'));
}

const payload = buildPayload({
  days: result.days,
  windowDays: DEFAULTS.windowDays,
  root: SESSIONS_DIR,
  files: result.files,
  sessions: result.sessions,
  countedSamples: result.countedSamples,
  skippedSamples: result.skippedSamples,
  durationMs: Date.now() - started,
});

let entryTotal = 0;
let entryActive = 0;
for (const entry of payload.days) {
  entryTotal += entry.tokens;
  if (entry.tokens > 0) entryActive += 1;
}
let bucketTotal = 0;
for (const bucket of result.days.values()) bucketTotal += bucket.totalTokens;

check('the grid starts on a Sunday', new Date(`${payload.days[0].date}T00:00:00`).getDay() === 0, payload.days[0].date);
check('day entries are one per day', payload.days.every((entry, i, all) => {
  if (i === 0) return true;
  const previous = new Date(`${all[i - 1].date}T00:00:00`);
  const current = new Date(`${entry.date}T00:00:00`);
  return Math.round((current - previous) / 86400000) === 1;
}));
check('payload total equals the folded bucket total', entryTotal === bucketTotal, `${entryTotal} vs ${bucketTotal}`);
check('active-day count agrees', entryActive === payload.totals.activeDays, `${entryActive} vs ${payload.totals.activeDays}`);
check('levels are within 1..5', payload.days.every((d) => d.level >= 0 && d.level <= 5));
check('every day key round-trips', payload.days.every((d) => /^\d{4}-\d{2}-\d{2}$/.test(d.date)));
check('the grid ends on today', payload.days[payload.days.length - 1].today === true);
check('calendar months are ordered', payload.calendars.months.every((m, i, all) => i === 0 || all[i - 1].column <= m.column));
check('now maps to a valid day key', /^\d{4}-\d{2}-\d{2}$/.test(dayKeyOf(Date.now())));

// ── a copied history must not be billed twice ────────────────────────────────
// A session log can carry a copy of another session's history (a subagent snapshot,
// a fork, a compaction rewrite). Those inherited attempts are not new spend, and
// folding each log on its own counted every one of them again — a single day read as
// twice the amount the account had actually been billed.
console.log('\nfolded from a synthetic corpus with a copied history');
{
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'dsh-th-dedupe-'));
  const day = new Date(2026, 9, 1, 12, 0, 0).getTime();
  const event = (turn, step, offset, tokens) => JSON.stringify({
    type: 'assistant/message',
    seq: 10 + turn,
    time: day + offset,
    data: {
      turn,
      step,
      usage: { inputTokens: tokens, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 },
    },
  });
  // Three billed attempts on one day…
  const shared = [event(1, 1, 0, 100), event(1, 2, 1000, 200), event(2, 1, 2000, 400)];
  // …which the child's log copies verbatim, plus one of its own.
  const own = event(2, 2, 3000, 800);

  const write = async (dir, header, lines) => {
    await fs.mkdir(path.join(root, dir), { recursive: true });
    await fs.writeFile(path.join(root, dir, 'session.v4.jsonl'), [header, ...lines].join('\n') + '\n');
  };
  try {
    await write('ws/session-parent', JSON.stringify({ type: 'session', id: 'parent', createdAt: day, cwd: '.' }), shared);
    await write('ws/session-child', JSON.stringify({ type: 'session', id: 'child', createdAt: day + 5000, parentSession: 'parent' }), [...shared, own]);

    const scanned = await scanSessions({ root, includeSubagents: true });
    const total = scanned.days.get(dayKeyOf(day))?.totalTokens ?? 0;
    const parent = scanned.sessions.find((s) => s.sessionId === 'parent');
    const child = scanned.sessions.find((s) => s.sessionId === 'child');

    // 100 + 200 + 400 counted once, plus the child's own 800.
    check('a copied attempt is counted once, not once per log', total === 1500, String(total));
    check('the copies are reported, not silently dropped', scanned.duplicatedSamples === 3, String(scanned.duplicatedSamples));
    check('the original session keeps the shared attempts', parent?.contributed === 3, JSON.stringify(parent && { c: parent.contributed, d: parent.duplicated }));
    check('the copy contributes only its own work', child?.contributed === 1 && child?.duplicated === 3,
      JSON.stringify(child && { c: child.contributed, d: child.duplicated, t: child.tokens }));
    check('the copy is credited only its own tokens', child?.tokens === 800, String(child?.tokens));
    check('every counted sample is attributed to exactly one session',
      scanned.sessions.reduce((sum, s) => sum + s.contributed, 0) === scanned.countedSamples);

    // Excluding subagents must not let the copy suppress the original.
    const mainOnly = await scanSessions({ root, includeSubagents: false });
    check('skipping subagents still counts the original history',
      (mainOnly.days.get(dayKeyOf(day))?.totalTokens ?? 0) === 700,
      String(mainOnly.days.get(dayKeyOf(day))?.totalTokens));

    // The fingerprint has to be strict: any real difference must survive it.
    const base = { time: 1, turn: 1, step: 1, usage: { uncachedInputTokens: 1, cacheReadTokens: 2, cacheWriteTokens: 3, outputTokens: 4, reasoningTokens: 5, totalTokens: 15 } };
    const clone = JSON.parse(JSON.stringify(base));
    const bump = (pathName) => {
      const copy = JSON.parse(JSON.stringify(base));
      if (pathName === 'time') copy.time = 2;
      else copy.usage[pathName] += 1;
      return eventFingerprint(copy);
    };
    check('an identical sample has the same fingerprint', eventFingerprint(base) === eventFingerprint(clone));
    check('a differing timestamp is a different event', bump('time') !== eventFingerprint(base));
    check('every token bucket separates two events',
      ['uncachedInputTokens', 'cacheReadTokens', 'cacheWriteTokens', 'outputTokens', 'reasoningTokens', 'totalTokens']
        .every((field) => bump(field) !== eventFingerprint(base)));
  } finally {
    await fs.rm(root, { recursive: true, force: true });
  }
}

// ── a compaction summary is a billed call too ────────────────────────────────
// Summarising a session is an LLM call the account pays for, and its usage is
// recorded in the log. Ignoring it left the day's total short of the official one.
// A long session can compact more than once, so the fold key has to keep the calls
// apart instead of collapsing them under a shared missing turn/step.
console.log('\ncompaction summaries are billed usage');
{
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'dsh-th-compact-'));
  const day = new Date(2026, 9, 2, 12, 0, 0).getTime();
  const compaction = (seq, id, tokens, offset) => JSON.stringify({
    type: 'compaction/summary',
    seq,
    time: day + offset,
    data: {
      compactionId: id,
      usage: { inputTokens: tokens, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 },
    },
  });
  const write = async (dir, header, lines) => {
    await fs.mkdir(path.join(root, dir), { recursive: true });
    await fs.writeFile(path.join(root, dir, 'session.v4.jsonl'), [header, ...lines].join('\n') + '\n');
  };
  try {
    // Two compactions in one session, then a copy of the first in another log.
    await write('ws/session-a', JSON.stringify({ type: 'session', id: 'a', createdAt: day }), [
      compaction(10, 'c1', 100, 0),
      compaction(20, 'c2', 200, 1000),
    ]);
    await write('ws/session-b', JSON.stringify({ type: 'session', id: 'b', createdAt: day + 2000, parentSession: 'a' }), [
      compaction(10, 'c1', 100, 0),
    ]);

    const scanned = await scanSessions({ root, includeSubagents: true });
    const total = scanned.days.get(dayKeyOf(day))?.totalTokens ?? 0;
    check('a compaction summary counts as billed usage', total === 300, String(total));
    check('two compactions in one log are both counted, not collapsed',
      scanned.sessions.find((s) => s.sessionId === 'a')?.contributed === 2,
      String(scanned.sessions.find((s) => s.sessionId === 'a')?.contributed));
    check('a copied compaction is deduplicated like any other event',
      scanned.duplicatedSamples === 1, String(scanned.duplicatedSamples));
    check('the copy contributes nothing of its own',
      scanned.sessions.find((s) => s.sessionId === 'b')?.contributed === 0);
  } finally {
    await fs.rm(root, { recursive: true, force: true });
  }
}

console.log('\nthe day window across a DST transition (TZ=America/New_York)');
// Re-enter this file in a DST zone. A failure to spawn is reported as a skip
// rather than a pass, so a restricted environment cannot make this look green.
const dstRun = (() => {
  try {
    return spawnSync(process.execPath, [fileURLToPath(import.meta.url)], {
      env: { ...process.env, TZ: 'America/New_York', DSH_TH_DST_PART: '1' },
      encoding: 'utf8',
    });
  } catch (error) {
    return { error };
  }
})();
if (dstRun.error !== undefined) {
  console.log(`  --   skipped: cannot spawn a child process (${dstRun.error.message})`);
} else {
  for (const line of String(dstRun.stdout ?? '').split('\n')) {
    if (line.trim() !== '' && !line.startsWith('DST PART')) console.log(line);
  }
  check('the day window is sound in a DST zone',
    dstRun.status === 0, `exit=${dstRun.status} ${String(dstRun.stderr ?? '').trim().slice(0, 200)}`);
}

console.log('\npayload summary');
console.log(`  range     ${payload.range.from} → ${payload.range.to} (${payload.days.length} cells, ${payload.calendars.weeks} columns)`);
console.log(`  tokens    ${payload.totals.tokens.toLocaleString()} over ${payload.totals.activeDays} active days`);
console.log(`  average   ${payload.totals.averagePerActiveDay.toLocaleString()}/active day`);
console.log(`  best      ${payload.totals.bestDay === null ? '—' : `${payload.totals.bestDay.date} (${payload.totals.bestDay.tokens.toLocaleString()})`}`);
console.log(`  streak    current=${payload.totals.streak.current} longest=${payload.totals.streak.longest}`);
console.log('  recent    ' + payload.days.slice(-5).map((d) => `${d.date}:${d.tokens}${d.today ? '*' : ''}`).join('  '));

console.log(`\n${failures.length === 0 ? 'ALL CHECKS PASSED' : `${failures.length} CHECK(S) FAILED`}`);
process.exit(failures.length === 0 ? 0 : 1);
