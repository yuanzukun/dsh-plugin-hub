/**
 * Pure jj template constants and record parsing helpers.
 *
 * This module is deliberately pure: it imports only the type-only vocabulary from
 * `types.ts` (no DSH runtime imports, no I/O, no subprocess) so the
 * build test can protect it as a pure module. Parsers throw
 * {@link TemplateParseError}; the operations layer in `service.ts` converts that
 * into the contract `JjError` so model-facing error codes/messages are unchanged.
 *
 * @module dsh-jj/jj-templates
 */

import type { JjChange } from './types.ts';

/**
 * `jj log -r <rev> --no-graph -T <TPL_STATUS>` template (contract §2.8, plus the
 * rewrite-window fields added with the correction policy).
 *
 * `immutable` is jj's own "never rewrite this" marker (trunk, tags, and by default
 * untracked remote bookmarks) and `remote_bookmarks` names every remote ref that
 * reaches the change. Both are needed: a pushed *tracked* bookmark (for example a
 * feature branch) keeps `immutable` false under jj's default `immutable_heads()`,
 * yet rewriting it diverges the local bookmark from the remote.
 */
export const TPL_STATUS =
  '"{\\"change_id\\":" ++ json(change_id) ++ ",\\"commit_id\\":" ++ json(commit_id) ++ ",\\"description\\":" ++ json(description) ++ ",\\"empty\\":" ++ json(empty) ++ ",\\"conflict\\":" ++ json(conflict) ++ ",\\"current_working_copy\\":" ++ json(current_working_copy) ++ ",\\"bookmarks\\":" ++ json(local_bookmarks.map(|b| b.name())) ++ ",\\"immutable\\":" ++ json(immutable) ++ ",\\"remote_bookmarks\\":" ++ json(remote_bookmarks.filter(|b| b.remote() != "git").map(|b| b.name())) ++ ",\\"author\\":" ++ json(author.email()) ++ ",\\"paths\\":" ++ json(self.diff().files().map(|f| f.path())) ++ "}\\n"';

/**
 * `jj log` change template **without** the diff `paths` field (`TPL_STATUS` minus
 * `paths`).
 *
 * `self.diff()` is the expensive part of `TPL_STATUS`: on a working copy with
 * 3000 changed files one read costs ≈270ms instead of ≈23ms. The generic change
 * reader (the operations layer's `readAt`) therefore uses this template; only
 * `status()` (and `commit()`'s path reporting) needs the `paths` field.
 */
export const TPL_CHANGE =
  '"{\\"change_id\\":" ++ json(change_id) ++ ",\\"commit_id\\":" ++ json(commit_id) ++ ",\\"description\\":" ++ json(description) ++ ",\\"empty\\":" ++ json(empty) ++ ",\\"conflict\\":" ++ json(conflict) ++ ",\\"current_working_copy\\":" ++ json(current_working_copy) ++ ",\\"bookmarks\\":" ++ json(local_bookmarks.map(|b| b.name())) ++ ",\\"immutable\\":" ++ json(immutable) ++ ",\\"remote_bookmarks\\":" ++ json(remote_bookmarks.filter(|b| b.remote() != "git").map(|b| b.name())) ++ ",\\"author\\":" ++ json(author.email()) ++ "}\\n"';

/**
 * `jj log` template returning only the commit id of every selected revision.
 *
 * Used for parent/base checks where the full change record (and its diff) is not
 * needed; one line per revision, in jj's revset order.
 */
export const TPL_COMMIT_IDS = 'commit_id ++ "\\n"';

/** `jj log` per-change template (contract §2.8, plus the rewrite-window fields). */
export const TPL_LOG =
  '"{\\"change_id\\":" ++ json(change_id) ++ ",\\"commit_id\\":" ++ json(commit_id) ++ ",\\"description\\":" ++ json(description.first_line()) ++ ",\\"empty\\":" ++ json(empty) ++ ",\\"conflict\\":" ++ json(conflict) ++ ",\\"current_working_copy\\":" ++ json(current_working_copy) ++ ",\\"bookmarks\\":" ++ json(local_bookmarks.map(|b| b.name())) ++ ",\\"immutable\\":" ++ json(immutable) ++ ",\\"remote_bookmarks\\":" ++ json(remote_bookmarks.filter(|b| b.remote() != "git").map(|b| b.name())) ++ ",\\"author\\":" ++ json(author.email()) ++ "}\\n"';

/**
 * `jj workspace list` template used by the tools (tab-separated; both fields JSON).
 *
 * Both values are `json(...)`-encoded rather than printed bare: jj renders a
 * workspace name that needs quoting (`my session`) as `"my session"` when the
 * template prints the raw name, so the read-back name was quoted and the cleanup
 * ownership comparison failed. `json()` also escapes tabs inside names, keeping the
 * tab field separator unambiguous (detect uses the same JSON encoding).
 */
export const TPL_WORKSPACE_LIST_TAB = 'json(name) ++ "\\t" ++ json(root) ++ "\\n"';

/**
 * `jj workspace list` template that carries each workspace's working-copy state.
 *
 * One line of JSON per workspace: identity (`name`, `root`) plus what the panel and the
 * `full` listing need — the target change id, commit id, first description line, and
 * whether that change is empty or conflicted. jj templates have no object literals, so
 * the JSON is assembled from string pieces exactly like {@link TPL_LOG}.
 */
export const TPL_WORKSPACE_LIST_STATE =
  '"{\\"name\\":" ++ json(name) ++ ",\\"root\\":" ++ json(root) ++ ",\\"change_id\\":" ++ json(target.change_id()) ++ ",\\"commit_id\\":" ++ json(target.commit_id()) ++ ",\\"description\\":" ++ json(target.description().first_line()) ++ ",\\"empty\\":" ++ json(target.empty()) ++ ",\\"conflict\\":" ++ json(target.conflict()) ++ "}\\n"';

/** One workspace's identity plus the state of the change its working copy is on. */
export interface JjWorkspaceStateRecord {
  readonly name: string;
  /** Absolute workspace root as reported by the template's `root` field. */
  readonly root: string;
  readonly changeId: string;
  readonly commitId: string;
  readonly description: string;
  readonly empty: boolean;
  readonly conflict: boolean;
}

/**
 * Parse {@link TPL_WORKSPACE_LIST_STATE} output.
 *
 * @param stdout - the command's standard output (one JSON object per line).
 * @param argv - the command that produced it, for error messages.
 * @returns one record per workspace, in jj's order.
 * @throws TemplateParseError when a line is not a complete workspace record.
 */
export function parseWorkspaceStates(stdout: string, argv: readonly string[]): JjWorkspaceStateRecord[] {
  const states: JjWorkspaceStateRecord[] = [];
  for (const line of stdout.split('\n')) {
    if (line.trim().length === 0) continue;
    let parsed: Record<string, unknown> | undefined;
    try {
      parsed = asRecord(JSON.parse(line));
    } catch {
      parsed = undefined;
    }
    const name = parsed?.name;
    const root = parsed?.root;
    const changeId = parsed?.change_id;
    const commitId = parsed?.commit_id;
    const description = parsed?.description;
    const empty = parsed?.empty;
    const conflict = parsed?.conflict;
    if (
      typeof name !== 'string' ||
      typeof root !== 'string' ||
      typeof changeId !== 'string' ||
      typeof commitId !== 'string' ||
      typeof description !== 'string' ||
      typeof empty !== 'boolean' ||
      typeof conflict !== 'boolean'
    ) {
      throw new TemplateParseError(
        `\`jj ${argv.join(' ')}\` produced an unparseable workspace record: ${bound(line, 256).text}`,
        { argv, stderr: '', stdout: bound(stdout, 512).text },
      );
    }
    states.push({ name, root, changeId, commitId, description, empty, conflict });
  }
  return states;
}

/**
 * `jj op log` template (contract §7.3.8): `json(self)` exposes id/description/
 * time/username/hostname/workspace_name/is_snapshot/attributes.
 */
export const TPL_OP_LOG = 'json(self) ++ "\\n"';

/** `jj bookmark list` template (contract §7.3.11). */
export const TPL_BOOKMARK_LIST = 'json(self) ++ "\\n"';

/**
 * `jj log` template returning one full description per line as JSON.
 *
 * Used by the commit-style sampler: the first line carries the style, but the
 * model also needs to see body/footer habits, which `TPL_LOG` (`first_line`)
 * intentionally drops.
 */
export const TPL_DESCRIPTION = 'json(description) ++ "\\n"';

/** Bounded text helper. */
export function bound(text: string, limit: number): { text: string; truncated: boolean } {
  return text.length <= limit ? { text, truncated: false } : { text: text.slice(0, limit), truncated: true };
}

/** One jj change, as parsed from the JSON templates. */
export interface JjChangeRecord extends JjChange {
  /**
   * Paths changed by this revision.
   *
   * Populated only by `status()` and `commit()` (which read with `TPL_STATUS`);
   * the generic change reader uses the lightweight `TPL_CHANGE` and leaves this
   * array empty so it never pays for `self.diff()`.
   */
  readonly paths: readonly string[];
}

/** Detail a template parser attaches to a parse failure; `JjOperations` rethrows it as a `JjError`. */
interface TemplateParseFailure {
  readonly argv: readonly string[];
  readonly stderr: string;
  readonly stdout: string;
}

/** Error thrown by a template parser; see {@link TemplateParseFailure}. */
export class TemplateParseError extends Error {
  readonly detail: TemplateParseFailure;

  constructor(message: string, detail: TemplateParseFailure) {
    super(message);
    this.name = 'TemplateParseError';
    this.detail = detail;
  }
}

/** Coerce a JSON value to a plain object record, or `undefined` for non-objects. */
export function asRecord(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null ? (value as Record<string, unknown>) : undefined;
}

/**
 * Parse the first non-empty line of a single-revision read as one JSON record.
 *
 * @throws TemplateParseError when the stream has no record or the first line is not a JSON object.
 */
export function parseJsonLine(stdout: string, argv: readonly string[]): Record<string, unknown> {
  const line = stdout.split('\n').find((candidate) => candidate.trim().length > 0);
  if (line === undefined) {
    throw new TemplateParseError(`\`jj ${argv.join(' ')}\` returned no parseable record.`, {
      argv,
      stderr: '',
      stdout: bound(stdout, 512).text,
    });
  }
  try {
    const parsed: unknown = JSON.parse(line);
    const record = asRecord(parsed);
    if (record === undefined) throw new Error('not an object');
    return record;
  } catch (error) {
    throw new TemplateParseError(`\`jj ${argv.join(' ')}\` produced unparseable output: ${bound(stdout, 512).text}`, {
      argv,
      stderr: error instanceof Error ? error.message : String(error),
      stdout: bound(stdout, 512).text,
    });
  }
}

/**
 * Whether a correction may rewrite this change (the correction "window").
 *
 * A change is rewritable only while it has not reached a remote:
 * - `immutable` is jj's own marker (trunk, tags, untracked remote bookmarks);
 * - `remoteBookmarks` catches the case jj still allows rewriting — a pushed
 *   *tracked* bookmark stays outside the default `immutable_heads()`, and folding
 *   into it would diverge the local bookmark from its remote (a force push).
 *
 * Local bookmarks alone never close the window: jj rebases the following changes
 * and moves the bookmark along with them.
 *
 * @param change - any parsed change record.
 * @returns true when a correction may be folded into the change in place.
 */
export function isRewritableChange(change: {
  readonly immutable: boolean;
  readonly remoteBookmarks: readonly string[];
}): boolean {
  return !change.immutable && change.remoteBookmarks.length === 0;
}

/** Convert one parsed template record into a {@link JjChangeRecord}. */
export function changeFromRecord(record: Record<string, unknown>): JjChangeRecord {
  const bookmarks = Array.isArray(record['bookmarks']) ? record['bookmarks'].map((entry) => String(entry)) : [];
  // Two remotes can carry the same bookmark name (`main@origin` + `main@upstream`);
  // the template already drops the colocated repository's `@git` mirror, and the
  // remaining names are deduplicated so the model sees one entry per bookmark.
  const remoteBookmarks = Array.isArray(record['remote_bookmarks'])
    ? [...new Set(record['remote_bookmarks'].map((entry) => String(entry)))]
    : [];
  const paths = Array.isArray(record['paths']) ? record['paths'].map((entry) => String(entry)) : [];
  return {
    changeId: String(record['change_id'] ?? ''),
    commitId: String(record['commit_id'] ?? ''),
    description: String(record['description'] ?? '').replace(/\n$/, ''),
    empty: record['empty'] === true,
    conflict: record['conflict'] === true,
    currentWorkingCopy: record['current_working_copy'] === true,
    bookmarks,
    immutable: record['immutable'] === true,
    remoteBookmarks,
    author: String(record['author'] ?? ''),
    paths,
  };
}

/**
 * Parse every non-empty line of a multi-revision read as JSON records.
 *
 * @throws TemplateParseError on the first unparseable line.
 */
export function parseChangeLines(stdout: string, argv: readonly string[]): JjChangeRecord[] {
  const changes: JjChangeRecord[] = [];
  for (const line of stdout.split('\n')) {
    if (line.trim().length === 0) continue;
    try {
      const record = asRecord(JSON.parse(line));
      if (record !== undefined) changes.push(changeFromRecord(record));
    } catch {
      throw new TemplateParseError(`\`jj ${argv.join(' ')}\` produced unparseable output: ${bound(stdout, 512).text}`, {
        argv,
        stderr: '',
        stdout: bound(stdout, 512).text,
      });
    }
  }
  return changes;
}
