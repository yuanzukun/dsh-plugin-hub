/**
 * Table-driven Git command classification: safety types, the subcommand rule
 * table, and invocation recognition (design contract §8.2 / §8.3).
 *
 * Pure module: no I/O, no subprocess, no `@deepseek-ai/*` imports. Parsing
 * primitives live in `./git-tokenize.ts`; the jj replacement strings and rule
 * shapes live in `./git-equivalence.ts`.
 *
 * @module dsh-jj/git-rules
 */

import { JJ_EQUIVALENCE, mutateRule, readRule } from './git-equivalence.ts';
import type { GitSafety, GitSafetySubtype, RuleResult, SubcommandRule } from './git-equivalence.ts';
import {
  baseName,
  scanArgs,
  scanPrelude,
  segmentDirectoryChange,
  isStaticDirectoryTarget,
  walkSegments,
} from './git-tokenize.ts';
import type { Token } from './git-tokenize.ts';

/** True when any of `names` is present in `flags`. */
function anyFlag(flags: readonly string[], names: readonly string[]): boolean {
  return flags.some((flag) => names.includes(flag));
}

const GIT_PROGRAM_RE = /^git(\.exe|\.cmd|\.bat)?$/i;

const GIT_VALUE_FLAGS = new Set([
  '-C',
  '-c',
  '--git-dir',
  '--work-tree',
  '--namespace',
  '--config-env',
  '--super-prefix',
  '--attr-source',
]);

const GIT_BOOLEAN_FLAGS = new Set([
  '--bare',
  '--no-pager',
  '--paginate',
  '-p',
  '--no-replace-objects',
  '--literal-pathspecs',
  '--glob-pathspecs',
  '--noglob-pathspecs',
  '--icase-pathspecs',
  '--no-lazy-fetch',
  '--no-optional-locks',
  '--no-advice',
]);

const GIT_TERMINAL_FLAGS = new Set([
  '--version',
  '--help',
  '-h',
  '--html-path',
  '--man-path',
  '--info-path',
  '--exec-path',
]);

/**
 * Options that take a **required** value, per Git subcommand.
 *
 * Used only to find *flag positions* when deciding whether `-h`/`--help` really
 * asks for help: an option value that happens to be `-h` (`git commit -a -m -h`)
 * is a commit message, not a help request. Optional-value options are deliberately
 * left out (Git only accepts their value attached, so the following token stays a
 * flag). An empty/unknown table never turns a mutating command into "read": the
 * help flag is then only honoured as the first argument.
 */
const GIT_VALUE_OPTIONS: Readonly<Record<string, readonly string[]>> = Object.freeze({
  commit: [
    '-m',
    '--message',
    '-F',
    '--file',
    '-C',
    '--reuse-message',
    '-c',
    '--reedit-message',
    '--author',
    '--date',
    '--template',
    '--fixup',
    '--squash',
    '--trailer',
    '--pathspec-from-file',
  ],
  checkout: ['-b', '-B', '--orphan', '--conflict', '--pathspec-from-file'],
  switch: ['-c', '-C', '--orphan', '--conflict'],
  reset: ['--pathspec-from-file'],
  restore: ['-s', '--source', '--pathspec-from-file'],
  revert: ['-m', '--mainline', '--strategy', '-X', '--strategy-option'],
  stash: ['-m', '--message', '--pathspec-from-file'],
  merge: ['-m', '--message', '-F', '--file', '-s', '--strategy', '-X', '--strategy-option', '--into-name'],
  rebase: ['--onto', '--exec', '-x', '-s', '--strategy', '-X', '--strategy-option', '--whitespace'],
  'cherry-pick': ['-m', '--mainline', '--strategy', '-X', '--strategy-option'],
  am: ['-p', '--directory', '--whitespace', '-C', '-c'],
  apply: ['-p', '--directory', '--exclude', '--include', '--whitespace', '-C', '-F'],
  add: ['--chmod', '--pathspec-from-file'],
  rm: ['--pathspec-from-file'],
  worktree: ['-b', '-B', '--reason', '--orphan'],
  branch: [
    '-m',
    '-M',
    '-c',
    '-C',
    '--set-upstream-to',
    '-u',
    '--contains',
    '--no-contains',
    '--merged',
    '--no-merged',
    '--points-at',
    '--sort',
    '--format',
  ],
  tag: [
    '-m',
    '--message',
    '-F',
    '--file',
    '-u',
    '--local-user',
    '--format',
    '--sort',
    '--contains',
    '--points-at',
    '--merged',
    '--no-merged',
  ],
  // `--force-with-lease` takes an optional value (attached only), so it never
  // consumes the next token.
  push: ['-o', '--push-option', '--receive-pack', '--exec', '--repo'],
  fetch: [
    '-j',
    '--jobs',
    '--depth',
    '--shallow-since',
    '--shallow-exclude',
    '--deepen',
    '--refmap',
    '--upload-pack',
    '-o',
    '--server-option',
    '--filter',
    '--negotiation-tip',
    '--recurse-submodules-default',
  ],
  pull: ['-s', '--strategy', '-X', '--strategy-option', '--upload-pack', '--depth', '--refmap'],
  remote: ['-t', '--track', '-m', '--master'],
  submodule: ['-b', '--branch', '--name', '--reference', '--depth'],
  config: [
    '--get',
    '--get-all',
    '--get-regexp',
    '--get-urlmatch',
    '--unset',
    '--unset-all',
    '--replace-all',
    '--rename-section',
    '--remove-section',
    '--comment',
    '-f',
    '--file',
    '--blob',
    '--type',
    '--default',
  ],
  'symbolic-ref': ['-m'],
  notes: ['-m', '--message', '-F', '--file', '-C', '--reuse-message', '-c', '--reedit-message', '--ref'],
  archive: ['-o', '--output', '--format', '--prefix', '--remote', '--exec'],
  'update-ref': ['-m', '--message'],
  'update-index': ['--chmod', '--cacheinfo'],
  'commit-tree': ['-p', '-m'],
  'hash-object': ['--path', '-t', '--type'],
  'commit-graph': ['--object-dir'],
  'multi-pack-index': ['--object-dir'],
  'format-patch': ['-o', '--output-directory', '--start-number', '--subject-prefix', '--signature', '--suffix'],
  'filter-branch': [
    '--msg-filter',
    '--env-filter',
    '--tree-filter',
    '--index-filter',
    '--parent-filter',
    '--commit-filter',
    '--tag-name-filter',
    '--subdirectory-filter',
    '--original',
  ],
});

/** Value-taking short options that may be bundled (`-am "msg"`); the value follows. */
function shortBundleTakesValue(bundle: string, valueFlags: ReadonlySet<string>): boolean {
  if (bundle.length < 3 || bundle.startsWith('--')) return false;
  return valueFlags.has(`-${bundle[bundle.length - 1] ?? ''}`);
}

/**
 * Whether `-h`/`--help` appears in a real flag position (not as another option's
 * value, and not after `--`).
 *
 * @param subcommand - the Git subcommand (selects the value-option table).
 * @param rest - arguments after the subcommand (and after Git's global options).
 */
function helpRequested(subcommand: string, rest: readonly string[]): boolean {
  const table = GIT_VALUE_OPTIONS[subcommand];
  // Unknown option arity: only a leading help flag is trusted. A later one may be
  // the value of an option this table does not know, and turning a mutating
  // subcommand into "read" is the unsafe direction.
  if (table === undefined) return rest[0] === '--help' || rest[0] === '-h';
  const values = new Set(table);
  for (let index = 0; index < rest.length; index += 1) {
    const token = rest[index] ?? '';
    if (token === '--') return false; // everything after `--` is a path/revision, not an option
    if (!token.startsWith('-') || token === '-') continue;
    const eq = token.indexOf('=');
    const flag = eq >= 0 ? token.slice(0, eq) : token;
    if (flag === '--help' || flag === '-h') return true;
    if (eq < 0 && values.has(flag)) {
      index += 1;
      continue;
    }
    if (eq < 0 && shortBundleTakesValue(flag, values)) index += 1;
  }
  return false;
}

/** One Git invocation found in a shell command line. */
export interface GitInvocation {
  /** Normalized Git argv (program plus its arguments; leading wrappers stripped). */
  readonly argv: readonly string[];
  /** Raw shell segment this invocation was found in (base-layer extra). */
  readonly raw: string;
  /** The Git program token as written (`git`, `git.exe`, `/usr/bin/git`, …). */
  readonly program: string;
  /** Git subcommand, or `null` when Git was invoked without one. */
  readonly subcommand: string | null;
  readonly safety: GitSafety;
  /** True iff `safety === 'mutate'`. */
  readonly mutating: boolean;
  readonly confidence: 'high' | 'low';
  /** Why this classification, e.g. ``subcommand `commit` is in the mutate table``. */
  readonly reason: string;
  /** Leading global options that change cwd/repo, in order (for example `['-C','sub']`). */
  readonly globalOptions: readonly string[];
  /** jj replacement text shown in refusals; `''` when none is known. */
  readonly equivalence: string;
  /** Base-layer extras: finer class, `-C`, `--git-dir`, `--work-tree`. */
  readonly subtype: GitSafetySubtype;
  readonly changeDir?: string;
  /** Every `-C` target in order: Git applies them left to right (each relative to the previous one). */
  readonly changeDirs?: readonly string[];
  readonly gitDir?: string;
  readonly workTree?: string;
}

/** One shell segment (a command between `;`, `&&`, `||`, `|`, `&`, `(`, `)`, or a newline). */
export interface ParsedSegment {
  readonly raw: string;
  /** `substitution` marks the inner text of `$(…)` or `` `…` ``. */
  readonly kind: 'command' | 'substitution';
  readonly words: readonly string[];
  /** False when the segment contained an unterminated quote or a trailing escape. */
  readonly parsed: boolean;
  /**
   * Statically resolvable target of a leading `cd`/`pushd` in this segment
   * (`cd -P <path>`, `cd -- <path>` and `pushd <path>` included).
   */
  readonly cdTarget?: string;
  /** Indexes into {@link GitCommandClassification.invocations}. */
  readonly invocationIndexes: readonly number[];
}

/** Result of {@link classifyGitInvocation}. */
export interface GitCommandClassification {
  readonly invocations: readonly GitInvocation[];
  /** Segments in command-line order; the guard follows `cd` changes through them. */
  readonly segments: readonly ParsedSegment[];
  /** Non-fatal parse defects, in English. */
  readonly warnings: readonly string[];
}

/**
 * Classification table (contract §8.3). Keys are Git subcommands; `contextual`
 * entries resolve through `refine`.
 */
export const GIT_SUBCOMMAND_RULES: Readonly<Record<string, SubcommandRule>> = Object.freeze({
  // ---- mutate: history / working copy / refs
  commit: {
    ...mutateRule('subcommand `commit` creates a Git commit', JJ_EQUIVALENCE.commit),
    refine: ({ flags }) =>
      anyFlag(flags, ['--dry-run'])
        ? readRule('subcommand `commit --dry-run` only reports what would be committed')
        : undefined,
  },
  checkout: mutateRule('subcommand `checkout` moves Git HEAD and rewrites the working copy', JJ_EQUIVALENCE.checkout),
  switch: {
    ...mutateRule('subcommand `switch` switches Git branches', JJ_EQUIVALENCE.checkout),
    refine: ({ flags }) =>
      anyFlag(flags, ['-c', '-C', '--create', '--force-create'])
        ? mutateRule(
            'subcommand `switch` with `-c` creates and checks out a new Git branch',
            JJ_EQUIVALENCE.switchCreate,
          )
        : undefined,
  },
  reset: {
    ...mutateRule(
      'subcommand `reset` moves Git HEAD/branch and can discard the index and working copy',
      JJ_EQUIVALENCE.reset,
    ),
    refine: ({ flags }) =>
      anyFlag(flags, ['--hard', '--merge', '--keep'])
        ? mutateRule(
            'subcommand `reset` with `--hard`/`--merge`/`--keep` rewrites the working copy',
            JJ_EQUIVALENCE.resetHard,
          )
        : mutateRule('subcommand `reset` moves Git HEAD/branch (jj has no index to reset)', JJ_EQUIVALENCE.reset),
  },
  restore: mutateRule('subcommand `restore` restores paths from the Git index/commit', JJ_EQUIVALENCE.restore),
  revert: mutateRule('subcommand `revert` creates inverse Git commits', JJ_EQUIVALENCE.revert),
  stash: {
    ...mutateRule('subcommand `stash` hides changes in a Git side ref', JJ_EQUIVALENCE.stash),
    refine: ({ positionals }) =>
      positionals[0] === 'list' || positionals[0] === 'show'
        ? readRule('subcommand `stash list`/`stash show` only lists stash entries')
        : undefined,
  },
  merge: {
    ...mutateRule('subcommand `merge` creates a Git merge commit', JJ_EQUIVALENCE.merge),
    refine: ({ flags }) =>
      anyFlag(flags, ['--dry-run'])
        ? readRule('subcommand `merge --dry-run` only reports what would be merged')
        : undefined,
  },
  rebase: {
    ...mutateRule('subcommand `rebase` rewrites Git commits and refs', JJ_EQUIVALENCE.rebase),
    refine: ({ flags }) =>
      anyFlag(flags, ['--dry-run'])
        ? readRule('subcommand `rebase --dry-run` only reports the rebase plan')
        : undefined,
  },
  'cherry-pick': mutateRule('subcommand `cherry-pick` applies commits onto Git HEAD', JJ_EQUIVALENCE.cherryPick),
  am: mutateRule('subcommand `am` applies mailbox patches as Git commits', JJ_EQUIVALENCE.conflict),
  'merge-file': mutateRule(
    "subcommand `merge-file` rewrites files outside jj's conflict model",
    JJ_EQUIVALENCE.conflict,
  ),
  mergetool: mutateRule('subcommand `mergetool` resolves Git merge state', JJ_EQUIVALENCE.conflict),
  apply: {
    ...mutateRule('subcommand `apply` writes patch content', JJ_EQUIVALENCE.conflict),
    refine: ({ flags }) =>
      anyFlag(flags, ['--check', '--stat', '--numstat', '--summary'])
        ? readRule('subcommand `apply --check` only inspects the patch')
        : undefined,
  },
  'format-patch': mutateRule(
    'subcommand `format-patch` writes patch files into the working copy',
    JJ_EQUIVALENCE.noEquivalent,
  ),
  'update-ref': mutateRule('subcommand `update-ref` writes Git refs directly', JJ_EQUIVALENCE.bookmark),
  'update-index': mutateRule(
    "subcommand `update-index` writes Git's index, which jj does not use",
    JJ_EQUIVALENCE.noEquivalent,
  ),
  'read-tree': mutateRule("subcommand `read-tree` replaces Git's index contents", JJ_EQUIVALENCE.noEquivalent),
  'write-tree': mutateRule('subcommand `write-tree` writes the index into a tree object', JJ_EQUIVALENCE.noEquivalent),
  'commit-tree': mutateRule(
    "subcommand `commit-tree` writes commit objects outside jj's change graph",
    JJ_EQUIVALENCE.noEquivalent,
  ),
  mktree: mutateRule("subcommand `mktree` writes tree objects outside jj's change graph", JJ_EQUIVALENCE.noEquivalent),
  'hash-object': {
    ...readRule('subcommand `hash-object` without `-w` only computes an object id'),
    refine: ({ flags }) =>
      anyFlag(flags, ['-w', '--stdin-paths'])
        ? mutateRule('subcommand `hash-object -w` writes objects into the shared store', JJ_EQUIVALENCE.noEquivalent)
        : undefined,
  },
  'checkout-index': mutateRule("subcommand `checkout-index` writes files from Git's index", JJ_EQUIVALENCE.restore),
  clean: {
    ...mutateRule('subcommand `clean` deletes untracked files', JJ_EQUIVALENCE.historyEdit),
    refine: ({ flags }) =>
      anyFlag(flags, ['-n', '--dry-run'])
        ? readRule('subcommand `clean --dry-run` only reports what would be deleted')
        : undefined,
  },
  rm: {
    ...mutateRule("subcommand `rm` removes files and updates Git's index", JJ_EQUIVALENCE.restore),
    refine: ({ flags }) =>
      anyFlag(flags, ['-n', '--dry-run'])
        ? readRule('subcommand `rm --dry-run` only reports what would be removed')
        : undefined,
  },
  mv: {
    ...mutateRule("subcommand `mv` moves files and updates Git's index", JJ_EQUIVALENCE.noEquivalent),
    refine: ({ flags }) =>
      anyFlag(flags, ['-n', '--dry-run'])
        ? readRule('subcommand `mv --dry-run` only reports what would be moved')
        : undefined,
  },
  add: {
    safety: 'mutate',
    subtype: 'index',
    reason: "subcommand `add` stages files in Git's index, which jj does not use",
    equivalence: 'no staging step is needed in jj; `jj status` already sees the change',
    refine: ({ flags }) =>
      anyFlag(flags, ['-n', '--dry-run'])
        ? readRule('subcommand `add --dry-run` only reports what would be added')
        : undefined,
  },
  init: mutateRule(
    'subcommand `init` creates Git metadata jj will not own',
    'jj git init --colocate (the default) or `jj git init --no-colocate`',
  ),
  clone: mutateRule('subcommand `clone` creates a plain Git checkout jj cannot manage', 'jj git clone <url>'),
  worktree: {
    ...mutateRule(
      'subcommand `worktree` creates or removes Git worktrees, which are not jj workspaces',
      JJ_EQUIVALENCE.worktreeAdd,
    ),
    refine: ({ positionals }) => {
      const sub = positionals[0];
      if (sub === 'list') return readRule('subcommand `worktree list` only lists Git worktrees');
      if (sub === 'remove') {
        return mutateRule(
          'subcommand `worktree remove` deletes a Git worktree that jj does not track',
          JJ_EQUIVALENCE.worktreeRemove,
        );
      }
      return mutateRule(
        'subcommand `worktree` changes Git worktrees, which are not jj workspaces',
        JJ_EQUIVALENCE.worktreeAdd,
      );
    },
  },
  branch: {
    contextual: true,
    ...mutateRule('subcommand `branch` changes Git branches', JJ_EQUIVALENCE.bookmark),
    refine: ({ flags, positionals }) => {
      const writeFlags = [
        '-d',
        '-D',
        '--delete',
        '-m',
        '-M',
        '--move',
        '-c',
        '-C',
        '--copy',
        '-f',
        '--force',
        '-u',
        '--set-upstream-to',
        '--unset-upstream',
        '--edit-description',
      ];
      const readFlags = [
        '-l',
        '--list',
        '-a',
        '--all',
        '-r',
        '--remotes',
        '-v',
        '-vv',
        '--verbose',
        '--show-current',
        '--contains',
        '--no-contains',
        '--merged',
        '--no-merged',
        '--points-at',
        '--sort',
        '--format',
      ];
      if (
        anyFlag(flags, ['-f', '--force']) ||
        (positionals.length >= 2 && anyFlag(flags, ['-m', '-M', '--move', '-c', '-C', '--copy']))
      ) {
        return mutateRule('subcommand `branch` force-moves or rewrites a Git branch', JJ_EQUIVALENCE.branchForce);
      }
      if (anyFlag(flags, writeFlags)) {
        return mutateRule('subcommand `branch` creates, moves, or deletes a Git branch', JJ_EQUIVALENCE.bookmark);
      }
      // Read-only selectors win over the positional check: `git branch --contains
      // HEAD` and `git branch -l 'feat*'` are listings, and the revision/pattern
      // they take is not a branch name to create.
      if (anyFlag(flags, readFlags)) return readRule('subcommand `branch` only lists branches');
      if (positionals.length >= 1) {
        return mutateRule('subcommand `branch <name>` creates a Git branch', JJ_EQUIVALENCE.branchCreate);
      }
      if (flags.length === 0) return readRule('subcommand `branch` only lists branches');
      return {
        safety: 'unknown',
        subtype: 'unknown',
        reason: 'subcommand `branch` with unrecognized flags; not classified as mutate',
        equivalence: '',
      };
    },
  },
  tag: {
    contextual: true,
    ...mutateRule(
      'subcommand `tag` creates, edits, or deletes Git tags',
      'jj tag (`jj bookmark` also works for named pointers)',
    ),
    refine: ({ flags, positionals }) => {
      const listFlags = [
        '-l',
        '--list',
        '-v',
        '--verify',
        '-n',
        '--contains',
        '--points-at',
        '--sort',
        '--format',
        '--merged',
        '--no-merged',
      ];
      const writeFlags = ['-d', '--delete', '-a', '--annotate', '-s', '--sign', '-f', '--force', '-m', '-F', '--edit'];
      if (anyFlag(flags, writeFlags)) {
        return mutateRule('subcommand `tag` creates, edits, or deletes Git tags', 'jj tag set/delete');
      }
      if (anyFlag(flags, listFlags) || (positionals.length === 0 && flags.length === 0)) {
        return readRule('subcommand `tag` only lists tags');
      }
      if (positionals.length >= 1) {
        return mutateRule('subcommand `tag <name>` creates a Git tag', 'jj tag set <name> -r <revset>');
      }
      return {
        safety: 'unknown',
        subtype: 'unknown',
        reason: 'subcommand `tag` with unrecognized flags; not classified as mutate',
        equivalence: '',
      };
    },
  },
  push: {
    ...mutateRule('subcommand `push` writes Git refs on the remote', JJ_EQUIVALENCE.push),
    refine: ({ flags }) =>
      anyFlag(flags, ['-n', '--dry-run'])
        ? readRule('subcommand `push --dry-run` only reports what would be pushed')
        : undefined,
  },
  fetch: {
    ...mutateRule("subcommand `fetch` updates Git remote-tracking refs outside jj's import path", JJ_EQUIVALENCE.fetch),
    // `git fetch -n` means `--no-tags`, not a dry run (`git push -n` is the one
    // where `-n` means `--dry-run`); only `--dry-run` skips the ref updates.
    refine: ({ flags }) =>
      anyFlag(flags, ['--dry-run'])
        ? readRule('subcommand `fetch --dry-run` only reports what would be fetched')
        : undefined,
  },
  pull: mutateRule('subcommand `pull` fetches and merges into Git HEAD', JJ_EQUIVALENCE.pull),
  remote: {
    contextual: true,
    ...mutateRule('subcommand `remote` reconfigures Git remotes', JJ_EQUIVALENCE.remote),
    refine: ({ flags, positionals }) => {
      const sub = positionals[0];
      if (sub === undefined || sub === 'show' || sub === 'get-url' || anyFlag(flags, ['-v', '--verbose'])) {
        return readRule('subcommand `remote` only lists or shows remotes');
      }
      return undefined;
    },
  },
  submodule: {
    contextual: true,
    ...mutateRule('subcommand `submodule` changes Git submodules', JJ_EQUIVALENCE.submoduleLimited),
    refine: ({ positionals }) => {
      const sub = positionals[0];
      return sub === undefined || sub === 'status' || sub === 'summary'
        ? readRule('subcommand `submodule status` only reports submodule state')
        : mutateRule(
            'subcommand `submodule` adds, updates, or removes Git submodules',
            JJ_EQUIVALENCE.submoduleLimited,
          );
    },
  },
  config: {
    contextual: true,
    ...mutateRule('subcommand `config` writes Git configuration', 'jj config set --repo <name> <value>'),
    refine: ({ flags, positionals }) => {
      const readFlags = [
        '--get',
        '--get-all',
        '--get-regexp',
        '--get-urlmatch',
        '--list',
        '-l',
        '--show-origin',
        '--show-scope',
        '--name-only',
      ];
      const writeFlags = [
        '--add',
        '--unset',
        '--unset-all',
        '--replace-all',
        '--rename-section',
        '--remove-section',
        '--edit',
        '-e',
      ];
      if (anyFlag(flags, writeFlags)) {
        return mutateRule(
          'subcommand `config` writes Git configuration',
          'jj config set --repo <name> <value> / `jj config unset --repo <name>`',
        );
      }
      if (anyFlag(flags, readFlags) || positionals.length <= 1) {
        return readRule('subcommand `config` only reads Git configuration');
      }
      return mutateRule(
        'subcommand `config <key> <value>` writes Git configuration',
        'jj config set --repo <name> <value>',
      );
    },
  },
  reflog: {
    contextual: true,
    ...mutateRule(
      'subcommand `reflog` deletes Git reflog entries',
      'jj op log / `jj undo` / `jj op restore <operation-id>`',
    ),
    refine: ({ positionals }) => {
      const sub = positionals[0];
      return sub === 'expire' || sub === 'delete'
        ? mutateRule(
            'subcommand `reflog delete`/`expire` deletes Git reflog entries',
            'jj op log / `jj undo` / `jj op restore <operation-id>`',
          )
        : readRule("subcommand `reflog` only shows Git's reflog");
    },
  },
  'symbolic-ref': {
    contextual: true,
    ...readRule('subcommand `symbolic-ref` only reads a symbolic ref'),
    refine: ({ flags, positionals }) =>
      positionals.length >= 2 || anyFlag(flags, ['-m', '--delete', '-d'])
        ? mutateRule('subcommand `symbolic-ref` writes a symbolic ref (HEAD)', JJ_EQUIVALENCE.historyEdit)
        : undefined,
  },
  bisect: {
    contextual: true,
    ...mutateRule('subcommand `bisect` moves Git HEAD during a bisection', 'jj bisect (jj has native bisection)'),
    refine: ({ positionals }) => {
      const sub = positionals[0];
      return sub === 'log' || sub === 'view' || sub === 'visualize'
        ? readRule('subcommand `bisect log`/`view` only reads bisection state')
        : undefined;
    },
  },
  notes: {
    contextual: true,
    ...mutateRule(
      "subcommand `notes` writes Git notes outside jj's model",
      'put the information in the change description with `jj describe`',
    ),
    refine: ({ positionals }) => {
      const sub = positionals[0];
      return sub === undefined || sub === 'list' || sub === 'show' || sub === 'get-ref'
        ? readRule('subcommand `notes list`/`show` only reads Git notes')
        : undefined;
    },
  },
  bundle: {
    contextual: true,
    safety: 'mutate',
    subtype: 'worktree',
    reason: 'subcommand `bundle create` writes a bundle file',
    equivalence: '',
    refine: ({ positionals }) =>
      positionals[0] === 'verify' || positionals[0] === 'list-heads'
        ? readRule('subcommand `bundle verify`/`list-heads` only inspects a bundle')
        : undefined,
  },
  'sparse-checkout': mutateRule(
    'subcommand `sparse-checkout` changes which files are checked out',
    'jj sparse set/edit (jj manages sparse checkouts natively)',
  ),
  archive: mutateRule('subcommand `archive` writes an archive into the working copy', JJ_EQUIVALENCE.noEquivalent),
  lfs: mutateRule('subcommand `lfs` manages Git LFS state outside jj', JJ_EQUIVALENCE.noEquivalent),
  rerere: mutateRule('subcommand `rerere` replays recorded Git conflict resolutions', JJ_EQUIVALENCE.conflict),
  'send-email': mutateRule(
    'subcommand `send-email` sends patches and can rewrite Git state',
    JJ_EQUIVALENCE.noEquivalent,
  ),
  'request-pull': mutateRule(
    'subcommand `request-pull` generates a pull request description',
    JJ_EQUIVALENCE.noEquivalent,
  ),
  gc: mutateRule('subcommand `gc` prunes the object store that jj and git share', JJ_EQUIVALENCE.gc),
  prune: mutateRule('subcommand `prune` deletes unreachable objects from the store jj depends on', JJ_EQUIVALENCE.gc),
  repack: mutateRule('subcommand `repack` rewrites pack files in the store jj depends on', JJ_EQUIVALENCE.store),
  'pack-refs': mutateRule('subcommand `pack-refs` rewrites refs that jj expects to manage', JJ_EQUIVALENCE.store),
  maintenance: mutateRule("subcommand `maintenance` runs gc/repack tasks on jj's backend store", JJ_EQUIVALENCE.gc),
  'filter-branch': mutateRule(
    'subcommand `filter-branch` rewrites all Git history',
    'no jj equivalent — do this in a separate clone, then `jj git fetch`',
  ),
  'filter-repo': mutateRule(
    'subcommand `filter-repo` rewrites Git refs outside jj',
    'no jj equivalent — do this in a separate clone, then `jj git fetch`',
  ),
  replace: mutateRule(
    'subcommand `replace` creates replacement refs that rewrite object history',
    JJ_EQUIVALENCE.noEquivalent,
  ),

  // ---- read-only
  status: readRule(),
  log: readRule(),
  show: readRule(),
  diff: readRule(),
  'diff-tree': readRule(),
  'diff-index': readRule(),
  'diff-files': readRule(),
  shortlog: readRule(),
  describe: readRule(),
  blame: readRule(),
  annotate: readRule(),
  grep: readRule(),
  'rev-list': readRule(),
  'rev-parse': readRule(),
  'merge-base': readRule(),
  'name-rev': readRule(),
  'for-each-ref': readRule(),
  'show-ref': readRule(),
  'ls-files': readRule(),
  'ls-tree': readRule(),
  'ls-remote': readRule(),
  'cat-file': readRule(),
  'count-objects': readRule(),
  'verify-pack': readRule(),
  whatchanged: readRule(),
  cherry: readRule(),
  'range-diff': readRule(),
  help: readRule(),
  version: readRule(),
  'check-ignore': readRule(),
  'check-attr': readRule(),
  fsck: {
    ...readRule('subcommand `fsck` only verifies object connectivity'),
    refine: ({ flags }) =>
      anyFlag(flags, ['--lost-found'])
        ? mutateRule(
            'subcommand `fsck --lost-found` writes dangling objects under `.git/lost-found`',
            JJ_EQUIVALENCE.noEquivalent,
          )
        : undefined,
  },
  'verify-commit': readRule(),
  'verify-tag': readRule(),
  'show-branch': readRule(),
  'show-index': readRule(),
  'get-tar-commit-id': readRule(),
  'patch-id': readRule(),
  'check-ref-format': readRule(),
  'check-mailmap': readRule(),
  var: readRule(),
  column: readRule(),
  bugreport: readRule(),
  diagnose: readRule(),
  credential: readRule('subcommand `credential` only fills credential helper data'),
  'unpack-objects': mutateRule(
    'subcommand `unpack-objects` writes objects into the shared store',
    JJ_EQUIVALENCE.noEquivalent,
  ),
  'commit-graph': {
    ...mutateRule(
      'subcommand `commit-graph write` writes commit-graph files into the shared store',
      JJ_EQUIVALENCE.noEquivalent,
    ),
    refine: ({ positionals }) =>
      positionals[0] === 'verify' ? readRule('subcommand `commit-graph verify` only checks the graph file') : undefined,
  },
  'multi-pack-index': {
    ...mutateRule('subcommand `multi-pack-index` writes or rewrites pack index files', JJ_EQUIVALENCE.noEquivalent),
    refine: ({ positionals }) =>
      positionals[0] === 'verify'
        ? readRule('subcommand `multi-pack-index verify` only checks the index files')
        : undefined,
  },
  'pack-objects': mutateRule(
    'subcommand `pack-objects` writes pack files and deltas into the object store',
    JJ_EQUIVALENCE.noEquivalent,
  ),
  'index-pack': mutateRule(
    'subcommand `index-pack` writes pack index files into the object store',
    JJ_EQUIVALENCE.noEquivalent,
  ),
  'update-server-info': mutateRule(
    'subcommand `update-server-info` rewrites the repository info files',
    JJ_EQUIVALENCE.noEquivalent,
  ),
  'fast-import': mutateRule(
    'subcommand `fast-import` writes commits, refs, and objects into the shared store',
    JJ_EQUIVALENCE.noEquivalent,
  ),
});

function isGitProgram(word: string): boolean {
  return GIT_PROGRAM_RE.test(baseName(word));
}

function classifyWords(
  words: readonly Token[],
  raw: string,
  parsed: boolean,
  warnings: string[],
): GitInvocation | undefined {
  if (!parsed || words.length === 0) return undefined;
  const prelude = scanPrelude(words, warnings);
  let index = prelude.programIndex;
  let lowConfidenceNote: string | undefined;

  const program = words[index]?.value ?? '';
  if (!isGitProgram(program)) return undefined;
  const programIndex = index;
  index += 1;

  const globalOptions: string[] = [];
  let subcommand: string | null = null;
  const changeDirs: string[] = [];
  let gitDir: string | undefined;
  let workTree: string | undefined;
  let terminalFlag: string | undefined;

  // `GIT_DIR=/path git …` retargets the repository exactly like `--git-dir`;
  // the assignment prefix is exported to the command, so it participates in the
  // decision when it can be resolved statically.
  for (const token of words.slice(0, programIndex)) {
    const assignment = /^(GIT_DIR|GIT_WORK_TREE)=(.*)$/.exec(token.value);
    if (assignment === null) continue;
    const value = (assignment[2] ?? '').trim();
    if (value.length === 0 || /[$`~]/.test(value)) {
      lowConfidenceNote = `\`${assignment[1]}\` is set from a shell expansion; Git's target repository was not resolved`;
      continue;
    }
    if (assignment[1] === 'GIT_DIR') gitDir = value;
    else workTree = value;
  }

  while (index < words.length) {
    const token = words[index] ?? { value: '', text: '' };
    index += 1;
    if (token.value === '--') {
      subcommand = words[index]?.value ?? null;
      if (subcommand !== null) index += 1;
      break;
    }
    if (!token.value.startsWith('-') || token.value === '-') {
      subcommand = token.value;
      break;
    }
    const eq = token.value.indexOf('=');
    const flag = eq >= 0 ? token.value.slice(0, eq) : token.value;
    const inlineValue = eq >= 0 ? token.value.slice(eq + 1) : undefined;
    globalOptions.push(token.value);

    if (GIT_TERMINAL_FLAGS.has(flag) && (flag !== '--exec-path' || inlineValue === undefined)) {
      terminalFlag = flag;
      // `git --help commit` / `git -h commit`: the rest is the help topic, not a subcommand.
      break;
    }
    // Attached short-option value: `git -C<path>` (Git accepts both spellings).
    if (eq < 0 && token.value.startsWith('-C') && token.value.length > 2) {
      changeDirs.push(token.value.slice(2));
      continue;
    }
    if (GIT_VALUE_FLAGS.has(flag)) {
      const value = inlineValue ?? words[index]?.value;
      if (inlineValue === undefined) {
        index += 1;
        // Contract §8.2: globalOptions carries the option and its value, e.g. ['-C','sub'].
        if (value !== undefined) globalOptions.push(value);
      }
      // `-C` is cumulative: Git chdirs once per option, each relative to the
      // previous directory (`git -C a -C b` means `a/b`).
      if (flag === '-C') {
        if (value !== undefined) changeDirs.push(value);
      } else if (flag === '--git-dir') {
        gitDir = value;
        if (inlineValue === undefined && value !== undefined) {
          lowConfidenceNote =
            '`--git-dir` was given as a separate argument; Git itself only accepts `--git-dir=<path>`.';
        }
      } else if (flag === '--work-tree') workTree = value;
      continue;
    }
    if (GIT_BOOLEAN_FLAGS.has(flag)) continue;
    lowConfidenceNote = `unrecognised Git global option \`${token.value}\``;
  }
  const changeDir = changeDirs.length > 0 ? changeDirs[changeDirs.length - 1] : undefined;

  const extras = {
    ...(changeDir !== undefined ? { changeDir } : {}),
    ...(changeDirs.length > 1 ? { changeDirs: Object.freeze([...changeDirs]) } : {}),
    ...(gitDir !== undefined ? { gitDir } : {}),
    ...(workTree !== undefined ? { workTree } : {}),
  };

  if (subcommand === null) {
    const isInfoFlag = terminalFlag !== undefined;
    return {
      argv: ['git', ...globalOptions],
      raw,
      program,
      globalOptions,
      subcommand: null,
      safety: isInfoFlag ? 'read' : 'unknown',
      mutating: false,
      confidence: isInfoFlag && lowConfidenceNote === undefined ? 'high' : 'low',
      reason: isInfoFlag
        ? `\`git ${terminalFlag}\` only prints information`
        : 'Git was invoked without a subcommand; not classified as mutate',
      equivalence: '',
      subtype: isInfoFlag ? 'read-only' : 'unknown',
      ...extras,
    };
  }

  const rest = words.slice(index).map((token) => token.value);
  // `git <subcommand> --help` / `-h` only prints help, even for mutating
  // subcommands — but only in a real flag position: `git commit -a -m -h` uses
  // `-h` as the commit message and really commits, and `git checkout -- --help`
  // names a path after `--`.
  if (helpRequested(subcommand, rest)) {
    return {
      argv: ['git', ...globalOptions, subcommand, ...rest],
      raw,
      program,
      globalOptions,
      subcommand,
      safety: 'read',
      mutating: false,
      confidence: 'high',
      reason: `\`git ${subcommand} --help\` only prints help`,
      equivalence: '',
      subtype: 'read-only',
      ...extras,
    };
  }
  const rule = GIT_SUBCOMMAND_RULES[subcommand];
  if (rule === undefined) {
    return {
      argv: ['git', ...globalOptions, subcommand, ...rest],
      raw,
      program,
      globalOptions,
      subcommand,
      safety: 'unknown',
      mutating: false,
      confidence: 'low',
      reason: `unrecognised Git subcommand \`${subcommand}\` (Git alias, Git LFS/subtree extension, or typo); not classified as mutate`,
      equivalence: '',
      subtype: 'unknown',
      ...extras,
    };
  }

  const { flags, positionals } = scanArgs(rest, []);
  const resolved: RuleResult = rule.refine?.({ flags, positionals }) ?? {
    safety: rule.safety,
    subtype: rule.subtype ?? (rule.safety === 'mutate' ? 'mutating' : 'read-only'),
    reason: rule.reason,
    ...(rule.equivalence !== undefined ? { equivalence: rule.equivalence } : {}),
  };

  const confidence: 'high' | 'low' = lowConfidenceNote === undefined ? 'high' : 'low';
  const reason = lowConfidenceNote === undefined ? resolved.reason : `${resolved.reason} (${lowConfidenceNote})`;

  return {
    argv: ['git', ...globalOptions, subcommand, ...rest],
    raw,
    program,
    globalOptions,
    subcommand,
    safety: resolved.safety,
    mutating: resolved.safety === 'mutate',
    confidence,
    reason,
    equivalence: resolved.equivalence ?? '',
    subtype:
      resolved.subtype ??
      (resolved.safety === 'mutate' ? 'mutating' : resolved.safety === 'read' ? 'read-only' : 'unknown'),
    ...extras,
  };
}

/**
 * Recognize Git invocations in a shell command line.
 *
 * @param commandLine - the raw shell command string (as the model wrote it).
 * @returns recognized invocations in order, the parsed segments, and parse warnings.
 */
export function classifyGitInvocation(commandLine: string): GitCommandClassification {
  const invocations: GitInvocation[] = [];
  const segments: ParsedSegment[] = [];
  const warnings: string[] = [];
  walkSegments(commandLine, warnings, (segment) => {
    const invocation = classifyWords(segment.words, segment.raw, segment.parsed, warnings);
    const invocationIndexes: number[] = [];
    if (invocation !== undefined) {
      invocationIndexes.push(invocations.length);
      invocations.push(invocation);
    }
    const change = segment.parsed ? segmentDirectoryChange(segment.words) : undefined;
    if (change?.warning !== undefined) warnings.push(change.warning);
    const cdTarget = change?.target;
    segments.push({
      raw: segment.raw,
      kind: segment.kind,
      words: segment.words.map((token) => token.value),
      parsed: segment.parsed,
      ...(cdTarget !== undefined && isStaticDirectoryTarget(cdTarget) ? { cdTarget } : {}),
      invocationIndexes,
    });
  });

  return {
    invocations: Object.freeze(invocations),
    segments: Object.freeze(segments),
    warnings: Object.freeze(warnings),
  };
}

/**
 * jj replacement text for a denied invocation (contract §8.2).
 *
 * @param invocation - a classified invocation.
 * @returns the §8.6/§8.3 equivalence line, or `''` when no single equivalent is known.
 */
export function gitEquivalence(invocation: GitInvocation): string {
  return invocation.equivalence;
}

/** True when the classification contains at least one mutating Git invocation. */
export function hasMutatingGitInvocation(classification: GitCommandClassification): boolean {
  return classification.invocations.some((invocation) => invocation.mutating);
}
