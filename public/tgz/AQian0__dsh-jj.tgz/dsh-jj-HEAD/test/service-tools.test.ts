/**
 * Service, operation-layer, and `jj_*` tool end-to-end tests against real
 * repositories (task-6 acceptance).
 *
 * Every jj call runs the real `jj` binary through the task-4 runner (via
 * `createCommandRunJj`), and the runner wrapper records argv so the suite can
 * assert that **no** jj path ever falls back to git.
 */
import { test } from 'node:test';
import { existsSync, mkdirSync, mkdtempSync, rmSync } from 'node:fs';
import { homedir } from 'node:os';
import assert from 'node:assert/strict';
import { join } from 'node:path';
import { Context } from '@deepseek-ai/cordis';
import ToolRuntime, { type JsonSchemaNode, type ToolDefinition } from '@deepseek-ai/dsh-tools';
import { resolveConfig } from '../src/config.ts';
import { detectVcs } from '../src/detect.ts';
import { createCommandRunJj, JjError } from '../src/jj-command.ts';
import { JjOperations, TPL_CHANGE, TPL_STATUS, changeFromRecord, isRewritableChange } from '../src/service.ts';
import { WorkspaceOwnership } from '../src/policies.ts';
import { removeSessionHeartbeat, writeSessionHeartbeat } from '../src/session-heartbeat.ts';
import {
  apply as applyTools,
  jjRefusalText,
  jjToolDefinitions,
  registerJjTools,
  type JjToolService,
} from '../src/tools.ts';
import type { JjLiveToolSession } from '../src/tool-shared.ts';
import {
  assertToolchain,
  initGit,
  initJjColocated,
  initJjNative,
  initJjSha256,
  makeFixture,
  mustRun,
  realpath,
  type Fixture,
} from './helpers/fixtures.ts';

/** Canonical JSON value a tool output renderer accepts. */
type JsonValueLike = Parameters<ToolDefinition['output']['render']>[1];
/** Execution context handed to a tool body (only `signal` is exercised here). */
type ExecContext = Parameters<ToolDefinition['execute']>[1];

/** Runner that records every argv so the suite can prove "jj only". */
function recordingRunner(fx: Fixture) {
  const calls: string[][] = [];
  const runJj = createCommandRunJj(async (argv, options) => {
    calls.push([...argv]);
    return await fx.run(argv, options);
  }, resolveConfig({}));
  return { runJj, calls, jjCalls: () => calls.filter((argv) => argv[0] === 'jj') };
}

function fakeExec(agent?: unknown): ExecContext {
  return {
    signal: new AbortController().signal,
    ...(agent !== undefined ? { agent } : {}),
  } as unknown as ExecContext;
}

/** A tool service backed by real operations plus real detection. */
function toolService(
  fx: Fixture,
  operations: JjOperations,
  _extraEnv: Readonly<Record<string, string>> = {},
): JjToolService {
  return {
    operations,
    workspaceOwnership: new WorkspaceOwnership(),
    detect: (cwd, signal) => detectVcs(cwd, fx.run, signal),
  };
}

function toolContext(
  fx: Fixture,
  service: JjToolService,
  config = resolveConfig({}),
  workingDirectory?: {
    ensure(agent: unknown, signal?: AbortSignal): Promise<string>;
    set?(agent: unknown, path: string, signal?: AbortSignal): Promise<string>;
  },
  liveSessions?: () => readonly JjLiveToolSession[],
) {
  return {
    service,
    config,
    host: {
      tools: { register: () => () => {} },
      ...(workingDirectory !== undefined ? { workingDirectory } : {}),
      ...(liveSessions !== undefined ? { liveSessions } : {}),
    },
    // Every tool-calling test assigns `fx.cwd` first; the refusal test overrides this.
    cwdFor: async () => fx.cwd as string,
  };
}

function definitionsByName(definitions: readonly ToolDefinition[]): Map<string, ToolDefinition> {
  return new Map(definitions.map((definition) => [definition.name, definition] as const));
}

test('operation layer: status, new, describe, log, diff, op log, bookmarks, workspace, undo', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-ops');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  // status (@ is the working-copy change)
  const status = await operations.status(repo);
  assert.equal(status.change.currentWorkingCopy, true);
  assert.match(status.change.changeId, /^[a-z]{8,}/);
  assert.ok(status.raw.length > 0, 'jj status text is returned');

  // new change with a description: the empty initial @ must carry content first,
  // because jj_new on an already empty working copy is refused (it would only add
  // another empty commit to the chain).
  await writeFixtureFile(fx, repo, 'seed.txt', 'seed');
  const created = await operations.newChange(repo, [], 'first change', undefined);
  assert.equal(created.currentWorkingCopy, true);
  assert.equal(created.description, 'first change');

  // describe the change in place
  const described = await operations.describeChange(repo, '@', 'renamed change', undefined);
  assert.equal(described.description, 'renamed change');
  assert.equal(described.changeId, created.changeId, 'jj describe edits the same change id');

  // write a file so the diff is non-empty, then diff @ against its parent
  await fx.run(['bash', '-c', 'printf hello > file.txt'], { cwd: repo, timeoutMs: 5_000 });
  const diff = await operations.diff(repo, '@', 'stat', [], undefined);
  assert.match(diff.text, /file\.txt/);

  // log with an explicit revset
  const changes = await operations.log(repo, '@ | @-', 5, undefined);
  assert.ok(changes.length >= 2);
  assert.equal(changes[0]?.description, 'renamed change');

  // bookmark set + list
  const set = await operations.bookmarkSet(repo, 'feature', '@', false, undefined);
  assert.equal(set.name, 'feature');
  assert.equal(set.moved, false, 'created, not moved');
  const bookmarks = await operations.bookmarkList(repo, false, undefined);
  assert.ok(bookmarks.some((bookmark) => bookmark.name === 'feature' && bookmark.target.length > 0));

  // op log
  const ops = await operations.opLog(repo, 5, undefined);
  assert.ok(ops.length >= 1);
  assert.ok(ops[0]?.id.length >= 8);
  assert.equal(ops[0]?.shortId, ops[0]?.id.slice(0, 12));
  assert.equal(typeof ops[0]?.isSnapshot, 'boolean');

  // undo records the head operation first (contract §8.3b self-protection)
  const headBefore = await operations.headOperationId(repo);
  const undone = await operations.undo(repo, undefined, undefined);
  assert.equal(undone.mode, 'undo');
  assert.equal(undone.headOperationId, headBefore);
  assert.match(undone.message, /head operation before this call/);
  assert.match(undone.message, /jj op restore/);

  // workspace add outside the repository root (contract §7.3.9 recommendation)
  const wsPath = join(fx.root, 'ws-outside');
  const workspace = await operations.workspaceAdd(repo, wsPath, 'outside', [], undefined, undefined, undefined);
  assert.equal(workspace.name, 'outside');
  assert.equal(workspace.change.currentWorkingCopy, true);
  const workspaces = await operations.workspaceList(repo, undefined);
  assert.ok(workspaces.some((entry) => entry.name === 'outside'));

  // squash + rebase run through jj as well
  await operations.squash(repo, '@', '@-', undefined, true, [], undefined);
  const rebased = await operations.rebase(repo, '@', '@-', undefined);
  assert.equal(typeof rebased, 'string');
  assert.ok(
    calls.some((argv) => argv.includes('rebase') && argv.includes('-r')),
    'the default rebase mode stays the current `-r` behavior',
  );

  // every recorded call used the jj binary — never git
  assert.ok(calls.length > 10);
  for (const argv of calls) {
    assert.equal(argv[0], 'jj', `unexpected non-jj program: ${argv.join(' ')}`);
  }
  assert.ok(
    calls.every((argv) => argv.includes('--no-pager') && argv.includes('--color=never')),
    'non-interactive flags are always present',
  );
});

test('jj_rebase mode: source moves a whole stack onto the advanced trunk', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-rebase-source');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  // Build a two-commit session stack on top of main.
  await mustRun(fx.run, ['jj', 'commit', '-m', 'chore: init'], repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  await fx.run(['bash', '-c', 'printf b > b.txt'], { cwd: repo, timeoutMs: 5_000 });
  await mustRun(fx.run, ['jj', 'commit', '-m', 'feat: one'], repo);
  await fx.run(['bash', '-c', 'printf c > c.txt'], { cwd: repo, timeoutMs: 5_000 });
  await mustRun(fx.run, ['jj', 'commit', '-m', 'feat: two'], repo);
  const stack = await operations.log(repo, 'main..@', 10, undefined);
  const first = stack.find((change) => change.description === 'feat: one');
  const second = stack.find((change) => change.description === 'feat: two');
  assert.ok(first !== undefined, 'the stack contains its first change');
  assert.ok(second !== undefined, 'the stack contains its last change');

  // Advance main while the session works (the shared trunk moves).
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'feat: advance'], repo);
  await fx.run(['bash', '-c', 'printf d > d.txt'], { cwd: repo, timeoutMs: 5_000 });
  await mustRun(fx.run, ['jj', 'commit', '-m', 'feat: advance'], repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);

  const message = await operations.rebase(repo, first.changeId, 'main', undefined, 'source');
  assert.match(message, /Rebased/);
  // Change ids survive rewrites, so the rebased stack can be inspected and must now
  // sit on top of the advanced trunk: feat two's ancestry contains feat one AND the
  // advance commit. (With `-r` the stack would be split and the advance missing here.)
  const ancestry = await operations.log(repo, `::${second.changeId}`, 20, undefined);
  const descriptions = ancestry.map((change) => change.description).filter((description) => description.length > 0);
  assert.deepEqual(
    descriptions.slice(0, 3),
    ['feat: two', 'feat: one', 'feat: advance'],
    'source mode rebased the whole stack onto the advanced main',
  );
  assert.ok(
    calls.some((argv) => argv.includes('rebase') && argv.includes('-s')),
    'source mode uses `jj rebase -s` instead of `-r`',
  );
});

test('operation layer: bad input is rejected before spawning anything', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-ops-bad');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  await assert.rejects(() => operations.undo(repo, 'NOT-HEX', undefined), /hexadecimal operation id/);
  await assert.rejects(() => operations.squash(repo, '@', '@-', 'msg', true, [], undefined), /mutually exclusive/);
  await assert.rejects(
    () => operations.bookmarkSet(repo, 'bad name', '@', false, undefined),
    /must not contain whitespace/,
  );
  await assert.rejects(
    () => operations.bookmarkSet(repo, 'bad@name', '@', false, undefined),
    /must not contain whitespace or '@'/,
  );
  await assert.rejects(
    () => operations.workspaceAdd(repo, '--evil', undefined, [], undefined, undefined, undefined),
    /does not start with/,
  );
  assert.equal(calls.length, 0, 'no jj process was spawned for invalid input');
});

test('all 24 jj_* tools are defined with contract names, descriptions, and schemas', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-tools-defs');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = jjToolDefinitions(toolContext(fx, toolService(fx, operations)));
  const byName = definitionsByName(definitions);

  const expected = [
    'jj_status',
    'jj_log',
    'jj_diff',
    'jj_new',
    'jj_commit',
    'jj_describe',
    'jj_commit_style',
    'jj_squash',
    'jj_amend',
    'jj_undo',
    'jj_op_log',
    'jj_workspace_add',
    'jj_workspace_list',
    'jj_workspace_enter',
    'jj_workspace_restore',
    'jj_bookmark_list',
    'jj_bookmark_set',
    'jj_rebase',
    'jj_handoff',
    'jj_workspace_cleanup',
    'jj_abandon',
    'jj_fetch',
    'jj_workspace_update_stale',
    'jj_op_restore',
  ];
  assert.deepEqual([...byName.keys()], expected);
  for (const definition of definitions) {
    assert.match(definition.description, /Jujutsu \(jj\)/, `${definition.name} must name jj`);
    assert.match(definition.description, /jj, not git/, `${definition.name} must distinguish itself from git`);
    assert.equal(typeof definition.execute, 'function');
    assert.equal(typeof definition.output.render, 'function');
    assert.equal(definition.output.schema.type, 'object');
    assert.equal(definition.output.schema.additionalProperties, false);
  }
  assert.equal(
    byName.get('jj_workspace_add')?.description.includes('outside the repository root'),
    true,
    'placement advice is in the description',
  );
});

test('tool schemas validate their own arguments and outputs (real DSH validators)', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const fx = makeFixture(t, 'dsh-jj-tools-schema');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await mustRun(fx.run, ['jj', 'describe', '-r', '@', '-m', 'schema check'], repo);
  fx.cwd = repo;
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = jjToolDefinitions(toolContext(fx, toolService(fx, operations)));

  const calls: Record<string, Record<string, unknown> | undefined> = {
    jj_status: {},
    jj_log: { revset: '@', limit: 3 },
    jj_diff: { revset: '@', format: 'stat', paths: [] },
    jj_new: { message: 'from tool', parents: [] },
    jj_commit: { message: 'chore: commit from tool' },
    jj_describe: { message: 'described by tool', revset: '@' },
    jj_commit_style: {},
    jj_squash: { from: '@', into: '@-', useDestinationMessage: true },
    jj_undo: {},
    jj_op_log: { limit: 3 },
    jj_workspace_list: {},
    jj_workspace_enter: { workspace: 'default' },
    jj_bookmark_list: { allRemotes: false },
    jj_bookmark_set: { name: 'tool-bookmark', revset: '@' },
    jj_rebase: { revision: '@', destination: '@-', mode: 'source' },
    jj_fetch: {},
    jj_workspace_update_stale: {},
  };

  for (const definition of definitions) {
    const args = calls[definition.name];
    if (args === undefined) continue; // jj_workspace_add is exercised separately (it creates a directory)
    if (definition.name === 'jj_commit' || definition.name === 'jj_new') {
      // Both tools refuse to create an empty commit; make sure @ has content whichever
      // of them the schema order reaches first.
      const current = await operations.status(repo);
      if (current.change.empty) await writeFixtureFile(fx, repo, `schema-${definition.name}.txt`, definition.name);
    }
    // `ToolDefinition.parameters` / `output.schema` are the compiled JSON Schemas.
    const violations = validateJsonSchemaValue(definition.parameters as JsonSchemaNode, args);
    assert.deepEqual(violations, [], `${definition.name} rejects its own example args`);
    const value = await definition.execute(args, fakeExec());
    const outputViolations = validateJsonSchemaValue(definition.output.schema, value);
    assert.deepEqual(
      outputViolations,
      [],
      `${definition.name} output must satisfy its own schema: ${JSON.stringify(value)}`,
    );
    const rendered = definition.output.render(args, value as JsonValueLike);
    assert.equal(rendered[0]?.type, 'text');
    assert.ok(rendered[0].text.length > 0);
  }

  // invalid args are reported by the same validator path
  const logDefinition = definitionsByName(definitions).get('jj_log')!;
  assert.ok(
    validateJsonSchemaValue(logDefinition.parameters as JsonSchemaNode, { revset: 42 }).length > 0,
    'type violations are surfaced',
  );
});

test('T20: every tool path runs jj only, never git', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-tools-argv');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await mustRun(fx.run, ['jj', 'describe', '-r', '@', '-m', 'argv check'], repo);
  fx.cwd = repo;
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));

  for (const name of [
    'jj_status',
    'jj_log',
    'jj_diff',
    'jj_op_log',
    'jj_workspace_list',
    'jj_bookmark_list',
    'jj_commit_style',
  ]) {
    const definition = definitions.get(name)!;
    await definition.execute(name === 'jj_log' ? { revset: '@', limit: 2 } : {}, fakeExec());
  }
  await definitions.get('jj_bookmark_set')!.execute({ name: 'argv-bookmark', revset: '@' }, fakeExec());
  // Both tools refuse an empty working copy, so give each one real content.
  await writeFixtureFile(fx, repo, 'argv-new.txt', 'new');
  await definitions.get('jj_new')!.execute({ message: 'argv new' }, fakeExec());
  await writeFixtureFile(fx, repo, 'argv-commit.txt', 'commit');
  await definitions.get('jj_commit')!.execute({ message: 'chore: argv commit' }, fakeExec());
  await definitions.get('jj_describe')!.execute({ message: 'argv described' }, fakeExec());

  assert.ok(calls.length >= 8, `expected many jj calls, saw ${calls.length}`);
  for (const argv of calls) {
    assert.equal(argv[0], 'jj', `tool path must not spawn ${argv[0]}: ${argv.join(' ')}`);
    assert.ok(!argv.includes('git') || argv[1] !== 'git', `no git subcommand fallback: ${argv.join(' ')}`);
  }
  assert.equal(
    calls.some((argv) => argv[0] === 'git'),
    false,
    'no git process was ever spawned',
  );
});

test('refusal paths: git-only, no repository, and broken jj metadata are all diagnosable', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-refuse');
  const gitRepo = await initGit(fx.run, fx.path('plain-git'));
  const empty = fx.path('empty');
  const native = await initJjNative(fx.run, fx.path('native'));
  const broken = fx.path('broken');
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  const gitDescriptor = await detectVcs(gitRepo, fx.run);
  const gitText = jjRefusalText(gitDescriptor, gitRepo);
  assert.match(gitText, /No Jujutsu \(jj\) workspace was found/);
  assert.match(gitText, /inside a Git repository at/);
  assert.match(gitText, /jj git init/);
  assert.match(gitText, /never fall back to Git commands/);

  const noneDescriptor = await detectVcs(empty, fx.run);
  const noneText = jjRefusalText(noneDescriptor, empty);
  assert.match(noneText, /no Git repository either/);
  assert.match(noneText, /jj git init --no-colocate/);

  const brokenDescriptor = await detectVcs(join(broken, 'missing'), fx.run);
  const brokenText = jjRefusalText(brokenDescriptor, join(broken, 'missing'));
  assert.ok(brokenText.length > 0);

  // A tool call in the git repository refuses before spawning jj.
  calls.length = 0;
  const definitions = definitionsByName(
    jjToolDefinitions({ ...toolContext(fx, toolService(fx, operations)), cwdFor: async () => gitRepo }),
  );
  await assert.rejects(
    () => definitions.get('jj_status')!.execute({}, fakeExec()),
    /No Jujutsu \(jj\) workspace was found/,
  );
  assert.equal(calls.length, 0, 'refusal happens before any jj process starts');

  // In the jj-native workspace the same tool succeeds.
  const nativeDefinitions = definitionsByName(
    jjToolDefinitions({ ...toolContext(fx, toolService(fx, operations)), cwdFor: async () => native }),
  );
  const status = (await nativeDefinitions.get('jj_status')!.execute({}, fakeExec())) as {
    readonly kind: string;
    readonly changeId: string;
  };
  assert.equal(status.kind, 'jj-native');
  assert.ok(status.changeId.length > 0);
});

test('results carry bounded, schema-valid nextActions', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-next-actions');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  await writeFixtureFile(fx, repo, 'seed.txt', 'seed');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = jjToolDefinitions({
    ...toolContext(fx, toolService(fx, operations)),
    cwdFor: async () => repo,
  });
  const byName = definitionsByName(definitions);
  const known = new Set(definitions.map((definition) => definition.name));

  const committed = (await byName.get('jj_commit')!.execute({ message: 'feat: seed' }, fakeExec())) as {
    nextActions?: { tool: string; args?: Record<string, unknown>; reason: string }[];
  };
  assert.ok(Array.isArray(committed.nextActions) && committed.nextActions.length > 0);
  for (const action of committed.nextActions ?? []) {
    assert.ok(known.has(action.tool), `nextActions must name a tool that exists: ${action.tool}`);
    assert.ok(action.reason.length > 0, 'every next action explains why');
  }

  // A refusal still throws (no partial result carrying instructions).
  await assert.rejects(
    () => byName.get('jj_commit')!.execute({ message: 'feat: empty' }, fakeExec()),
    /empty working-copy change|no content changes/i,
  );

  const abandoned = (await byName.get('jj_abandon')!.execute({ revset: '@-' }, fakeExec())) as {
    nextActions?: { tool: string }[];
  };
  assert.equal(abandoned.nextActions?.[0]?.tool, 'jj_log');

  // No tool ever returns more than three actions.
  const fetch = (await byName.get('jj_fetch')!.execute({}, fakeExec())) as { nextActions?: unknown[] };
  assert.ok((fetch.nextActions?.length ?? 0) <= 3);
});

test('jj_status is a cheap read by default and only diffs with details: true', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-status-details');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  await writeFixtureFile(fx, repo, 'seed.txt', 'seed');
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = definitionsByName(
    jjToolDefinitions({ ...toolContext(fx, toolService(fx, operations)), cwdFor: async () => repo }),
  );
  const status = definitions.get('jj_status')!;

  calls.length = 0;
  const cheap = (await status.execute({}, fakeExec())) as Record<string, unknown>;
  assert.ok(typeof cheap['changeId'] === 'string');
  assert.equal(cheap['changedPaths'], undefined, 'the default read omits changed paths');
  assert.equal(cheap['diffStat'], undefined);
  assert.equal(cheap['statusText'], undefined);
  assert.ok(!calls.some((argv) => argv[1] === 'status'), 'the cheap path never runs jj status');
  assert.ok(
    !calls.some((argv) => argv.some((argument) => argument.includes('self.diff()'))),
    'the cheap path uses the template without self.diff()',
  );

  calls.length = 0;
  const detailed = (await status.execute({ details: true }, fakeExec())) as Record<string, unknown>;
  assert.ok(Array.isArray(detailed['changedPaths']));
  assert.ok(typeof detailed['diffStat'] === 'string' && (detailed['diffStat'] as string).length > 0);
  assert.ok(typeof detailed['statusText'] === 'string');
});

test('jj_op_log honors the configured limit window', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-op-limit');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  await writeFixtureFile(fx, repo, 'seed.txt', 'seed');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const base = toolContext(fx, toolService(fx, operations));
  const definitions = definitionsByName(
    jjToolDefinitions({
      ...base,
      config: resolveConfig({ defaultLogLimit: 3, maxLogLimit: 5 }),
      cwdFor: async () => repo,
    }),
  );
  const opLog = definitions.get('jj_op_log')!;

  const defaulted = (await opLog.execute({}, fakeExec())) as { operations: { id: string }[] };
  assert.ok(defaulted.operations.length <= 3, 'the default limit comes from defaultLogLimit');

  const capped = (await opLog.execute({ limit: 50 }, fakeExec())) as { operations: { id: string }[] };
  assert.ok(capped.operations.length <= 5, 'an explicit limit is capped by maxLogLimit');
});

test('jj_bookmark_list hides the colocated @git mirror unless asked', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-bookmark-mirror');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  await writeFixtureFile(fx, repo, 'seed.txt', 'seed');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  await operations.bookmarkSet(repo, 'feature', '@', false, undefined);
  const definitions = definitionsByName(
    jjToolDefinitions({ ...toolContext(fx, toolService(fx, operations)), cwdFor: async () => repo }),
  );
  const list = definitions.get('jj_bookmark_list')!;

  const local = (await list.execute({ allRemotes: true }, fakeExec())) as {
    bookmarks: { name: string; remote: string | null }[];
  };
  assert.ok(
    local.bookmarks.every((bookmark) => bookmark.remote !== 'git'),
    'the @git mirror is hidden by default',
  );
  assert.ok(local.bookmarks.some((bookmark) => bookmark.name === 'feature'));

  const withMirror = (await list.execute({ allRemotes: true, includeGitMirror: true }, fakeExec())) as {
    bookmarks: { name: string; remote: string | null }[];
  };
  assert.ok(
    withMirror.bookmarks.some((bookmark) => bookmark.remote === 'git'),
    'includeGitMirror exposes the mirror entries',
  );
});

test('registerJjTools registers and disposes every tool', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-tools-register');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const registered: string[] = [];
  const host = {
    tools: {
      register: (definition: ToolDefinition) => {
        registered.push(definition.name);
        return () => {
          const index = registered.indexOf(definition.name);
          if (index >= 0) registered.splice(index, 1);
        };
      },
    },
  };
  const dispose = registerJjTools(host, { service: toolService(fx, operations), config: {} });
  assert.equal(registered.length, 24);
  dispose();
  assert.equal(registered.length, 0);
  dispose();
  assert.equal(registered.length, 0, 'disposer is idempotent');
});

test('operation layer: jj commit describes the change, splits paths, and starts a new @', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-ops-commit');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  await fx.run(['bash', '-c', 'printf one > one.txt; printf two > two.txt'], { cwd: repo, timeoutMs: 5_000 });

  // Partial commit: only one.txt lands in the described change; two.txt stays in @.
  const partial = await operations.commit(repo, 'feat: commit one only', ['one.txt']);
  assert.equal(partial.committed.description, 'feat: commit one only');
  assert.equal(partial.committed.currentWorkingCopy, false, 'the committed change is no longer @');
  assert.equal(partial.committed.empty, false);
  assert.deepEqual(partial.warnings, [], 'a successful commit has no warnings');
  assert.equal(partial.workingCopy.currentWorkingCopy, true);
  assert.equal(partial.workingCopy.empty, false, 'the remaining path stays in the new working copy');
  const status = await operations.status(repo);
  assert.deepEqual([...status.changedPaths], ['two.txt']);

  // A pathspec that matches nothing is a zero-exit jj warning: it must be surfaced,
  // and the empty commit must be visible instead of silently passing as a split.
  await fx.run(['bash', '-c', 'printf leftover > leftover.txt'], { cwd: repo, timeoutMs: 5_000 });
  const missed = await operations.commit(repo, 'feat: misses everything', ['missing.txt']);
  assert.equal(missed.committed.empty, true, 'jj created an empty change for the non-matching path');
  assert.ok(missed.warnings.length > 0, 'the jj warning is surfaced');
  assert.match(missed.warnings.join('\n'), /do not match|No changes matched/);
  assert.deepEqual(
    [...missed.workingCopy.paths].sort(),
    ['leftover.txt', 'two.txt'],
    'the real changes stay in the working copy',
  );

  // Full commit: the working copy becomes a fresh empty change.
  const full = await operations.commit(repo, 'chore: finish the change', []);
  assert.equal(full.committed.description, 'chore: finish the change');
  assert.equal(full.workingCopy.empty, true);
  assert.equal(full.workingCopy.currentWorkingCopy, true);
  const committedLog = await operations.log(repo, '@-', 1);
  assert.equal(committedLog[0]?.description, 'chore: finish the change');

  // Description samples carry full descriptions (newest first), not just subjects.
  const samples = await operations.descriptionSamples(repo, '::@', 10);
  assert.ok(samples.some((description) => description.includes('chore: finish the change')));

  // Invalid input is rejected before spawning.
  calls.length = 0;
  await assert.rejects(() => operations.commit(repo, '   ', []), /non-empty description/);
  await assert.rejects(() => operations.commit(repo, 'feat: x', ['-bad']), /must not start/);
  await assert.rejects(() => operations.commit(repo, 'feat: x', ['   ']), /must be non-empty/);
  assert.equal(calls.length, 0);
  for (const argv of calls) assert.equal(argv[0], 'jj');
});

test('jj_commit tool commits the change and reports the fresh working copy', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-tool-commit');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  await fx.run(['bash', '-c', 'printf one > one.txt; printf two > two.txt'], { cwd: repo, timeoutMs: 5_000 });

  const result = (await definitions
    .get('jj_commit')!
    .execute({ message: 'feat: tool commit', paths: ['one.txt'] }, fakeExec())) as {
    readonly committed: {
      readonly changeId: string;
      readonly description: string;
      readonly empty: boolean;
      readonly currentWorkingCopy: boolean;
    };
    readonly workingCopy: { readonly empty: boolean; readonly currentWorkingCopy: boolean };
    readonly committedPaths: readonly string[];
    readonly workingCopyPaths: readonly string[];
    readonly warnings: readonly string[];
    readonly nextActions: readonly {
      readonly tool: string;
      readonly args?: Record<string, unknown>;
      readonly reason: string;
    }[];
  };
  assert.equal(result.committed.description, 'feat: tool commit');
  assert.equal(result.committed.currentWorkingCopy, false);
  assert.equal(result.workingCopy.currentWorkingCopy, true);
  assert.equal(result.workingCopy.empty, false);
  assert.deepEqual([...result.committedPaths], ['one.txt']);
  assert.deepEqual([...result.workingCopyPaths], ['two.txt']);
  assert.deepEqual([...result.warnings], []);
  const amendAction = result.nextActions.find((action) => action.tool === 'jj_amend');
  assert.ok(amendAction !== undefined, 'an unpushed commit offers the amend follow-up');
  assert.equal(amendAction.args?.['into'], result.committed.changeId, 'the amend hint targets the commit just made');
  assert.match(amendAction.reason, /unpushed|jj_amend/);
  const status = await operations.status(repo);
  assert.deepEqual([...status.changedPaths], ['two.txt']);

  // Non-matching paths: the tool must expose the warning, not report a clean split.
  const missed = (await definitions
    .get('jj_commit')!
    .execute({ message: 'feat: tool miss', paths: ['missing.txt'] }, fakeExec())) as {
    readonly committed: { readonly empty: boolean };
    readonly workingCopyPaths: readonly string[];
    readonly warnings: readonly string[];
  };
  assert.equal(missed.committed.empty, true);
  assert.ok(missed.warnings.length > 0);
  assert.deepEqual([...missed.workingCopyPaths], ['two.txt'], 'the real change remains in the working copy');
});

test('operation layer: jj commit reads the committed change and the new @ in one log call', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-commit-single-read');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  await fx.run(['bash', '-c', 'printf one > one.txt; printf two > two.txt'], { cwd: repo, timeoutMs: 5_000 });

  calls.length = 0;
  const result = await operations.commit(repo, 'feat: merged read', ['one.txt']);
  assert.equal(calls.length, 3, 'one working-copy emptiness read, one commit spawn, one merged read spawn');
  const mergedReads = calls.filter((argv) => argv.includes('@ | @-'));
  assert.equal(mergedReads.length, 1, 'the committed change and the new @ come from a single jj log call');
  assert.ok(
    calls.some((argv) => argv.includes('-r') && argv.includes('@')),
    'the empty-commit guard reads the working copy before committing',
  );
  assert.deepEqual([...result.committed.paths], ['one.txt'], 'the merged read still reports the committed paths');
  assert.deepEqual([...result.workingCopy.paths], ['two.txt'], 'the merged read still reports the remaining paths');
});

test('operation layer: jj_commit and jj_new refuse to create empty commits', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-no-empty-commits');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  // A fresh repository already has an empty @: both commands would only add an
  // empty commit to the chain, so they fail before spawning the mutating command.
  calls.length = 0;
  await assert.rejects(() => operations.commit(repo, 'chore: nothing', []), /would create an empty commit/);
  assert.ok(!calls.some((argv) => argv.includes('commit')), 'the refusal happens before jj commit runs');
  await assert.rejects(() => operations.newChange(repo, [], 'empty'), /another empty change/);
  assert.ok(!calls.some((argv) => argv.includes('new')), 'the refusal happens before jj new runs');

  // Content makes both commands legitimate; after the commit @ is empty again.
  await writeFixtureFile(fx, repo, 'one.txt', 'one');
  const committed = await operations.commit(repo, 'feat: one', []);
  assert.equal(committed.committed.empty, false);
  await assert.rejects(() => operations.commit(repo, 'chore: empty again', []), /would create an empty commit/);
  await assert.rejects(() => operations.newChange(repo, [], undefined), /another empty change/);
  // Explicit parents remain allowed: that is how a stack starts on another revision.
  const elsewhere = await operations.newChange(repo, ['root()'], 'chore: start elsewhere');
  assert.equal(elsewhere.currentWorkingCopy, true);
});

test('jj_commit_style inherits Conventional history, asks when undecidable, and honours config', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-tool-style');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  fx.cwd = repo;
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const styleTool = (policy = resolveConfig({})) => {
    // Commit policy is owned by the runtime entry (`ctx.jj`), i.e. `operations.config`;
    // the second config passed to toolContext is the tools row and must not fork it.
    const runtimeOperations = new JjOperations({ runJj, config: policy });
    return definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, runtimeOperations)))).get(
      'jj_commit_style',
    )!;
  };

  interface StyleResult {
    readonly style: string;
    readonly source: string;
    readonly needsUserChoice: boolean;
    readonly guidance: string;
    readonly confidence: string;
    readonly sampleCount: number;
    readonly examples: readonly string[];
    readonly choices: ReadonlyArray<{ readonly id: string; readonly label: string }>;
  }

  // Empty history: the tool must not guess — it returns the ask-the-user choices.
  const unknown = (await styleTool().execute({}, fakeExec())) as StyleResult;
  assert.equal(unknown.style, 'auto');
  assert.equal(unknown.source, 'needs-user-choice');
  assert.equal(unknown.needsUserChoice, true);
  assert.equal(unknown.choices.length, 5);
  assert.ok(unknown.choices.some((choice) => choice.id === 'angular'));
  assert.match(unknown.guidance, /ask_user_question/);

  // Three Conventional commits: the tool inherits the repository style.
  for (const message of ['feat(core): add alpha', 'fix(parser): handle beta', 'docs: explain gamma']) {
    await mustRun(fx.run, ['jj', '--no-pager', '--color=never', 'commit', '-m', message], repo);
  }
  const detected = (await styleTool().execute({}, fakeExec())) as StyleResult;
  assert.equal(detected.style, 'conventional');
  assert.equal(detected.source, 'history');
  assert.equal(detected.needsUserChoice, false);
  assert.equal(detected.confidence, 'high');
  assert.ok(detected.sampleCount >= 3);
  assert.match(detected.guidance, /Conventional Commits/);
  assert.ok(detected.examples.includes('feat(core): add alpha'));

  // P3: the limit counts non-empty descriptions, not log entries (the empty @ and
  // the empty root commit must not consume the budget).
  const limited = (await styleTool(resolveConfig({ commitStyleSampleLimit: 3 })).execute(
    {},
    fakeExec(),
  )) as StyleResult;
  assert.equal(limited.style, 'conventional');
  assert.equal(limited.sampleCount, 3, 'three decent commits are enough even with the empty @ and root');
  assert.equal(limited.needsUserChoice, false);

  // Body/footer habits are observable: examples carry full descriptions, not just subjects.
  await mustRun(
    fx.run,
    [
      'jj',
      '--no-pager',
      '--color=never',
      'commit',
      '-m',
      'feat(api): add endpoint\n\nExplain the why in the body.\n\nRefs: #42',
    ],
    repo,
  );
  const withBody = (await styleTool().execute({}, fakeExec())) as StyleResult;
  assert.ok(
    withBody.examples.some(
      (example) => example.includes('Explain the why in the body.') && example.includes('Refs: #42'),
    ),
    `full descriptions reach the model: ${JSON.stringify(withBody.examples)}`,
  );

  // A tools-row-only commitStyle must not contradict the runtime policy (single source of truth).
  const toolsRowOnly = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({ commitStyle: 'angular' }))),
  ).get('jj_commit_style')!;
  const runtimeOwnsPolicy = (await toolsRowOnly.execute({}, fakeExec())) as StyleResult;
  assert.equal(
    runtimeOwnsPolicy.style,
    'conventional',
    'runtime-row auto still detects history; tools-row config is ignored',
  );
  assert.equal(runtimeOwnsPolicy.source, 'history');

  // The sampling bound comes from the tools row (`config.maxLogLimit`), and a
  // tools-row commitStyleSampleLimit is inert like the style itself.
  const toolsRowLimit = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({ commitStyleSampleLimit: 1 }))),
  ).get('jj_commit_style')!;
  const ignoredLimit = (await toolsRowLimit.execute({}, fakeExec())) as StyleResult;
  assert.ok(ignoredLimit.sampleCount > 1, 'tools-row sample limit is ignored; the runtime policy applies');

  // A configured preset wins over history.
  const angular = (await styleTool(resolveConfig({ commitStyle: 'angular' })).execute({}, fakeExec())) as StyleResult;
  assert.equal(angular.style, 'angular');
  assert.equal(angular.source, 'config');
  assert.equal(angular.needsUserChoice, false);
  assert.match(angular.guidance, /Angular commit convention/);

  // A configured custom style supplies the rules verbatim.
  const rules = 'lowercase Chinese subject, no prefix, body optional';
  const custom = (await styleTool(resolveConfig({ commitStyle: 'custom', commitStyleCustom: rules })).execute(
    {},
    fakeExec(),
  )) as StyleResult;
  assert.equal(custom.style, 'custom');
  assert.equal(custom.source, 'config');
  assert.ok(custom.guidance.includes(rules));

  // Style sampling must stay jj-only as well.
  assert.ok(calls.length > 0);
  for (const argv of calls) assert.equal(argv[0], 'jj', `unexpected non-jj program: ${argv.join(' ')}`);
});

test('descriptionSamples tolerates a partial JSON record on either side of a truncated stream', async () => {
  // A large full-description sample can trip maxOutputBytes. The DSH runner keeps the
  // TAIL of a truncated stream, so the partial record is the FIRST line and complete
  // records follow it; the style probe must keep them instead of failing.
  const tailKept = new JjOperations({
    runJj: async () => ({
      exitCode: 0,
      signal: null,
      stdout: 'tail of a long first description"\n"feat: second description"\n',
      stderr: '',
      truncated: true,
      killedByTimeout: false,
    }),
  });
  assert.deepEqual([...(await tailKept.descriptionSamples('/anywhere', '::@', 5))], ['feat: second description']);

  // Other runners may keep the head of the stream: tolerate a partial LAST line too.
  const headKept = new JjOperations({
    runJj: async () => ({
      exitCode: 0,
      signal: null,
      stdout: '"feat: first description"\n"feat: second description with a long body',
      stderr: '',
      truncated: true,
      killedByTimeout: false,
    }),
  });
  assert.deepEqual([...(await headKept.descriptionSamples('/anywhere', '::@', 5))], ['feat: first description']);

  // Without truncation an unparseable stream stays a hard error (no silent loss).
  const invalid = new JjOperations({
    runJj: async () => ({
      exitCode: 0,
      signal: null,
      stdout: 'not json\n',
      stderr: '',
      truncated: false,
      killedByTimeout: false,
    }),
  });
  await assert.rejects(() => invalid.descriptionSamples('/anywhere', '::@', 5), /unparseable output/);
});

test('TPL_STATUS is the contract template and parses into a change', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-template');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const result = await mustRun(
    fx.run,
    ['jj', '--no-pager', '--color=never', 'log', '-r', '@', '--no-graph', '-T', TPL_STATUS],
    repo,
  );
  assert.match(result.stdout, /"change_id":/);
  assert.match(result.stdout, /"paths":/);
  assert.match(result.stdout, /"immutable":/);
  assert.match(result.stdout, /"remote_bookmarks":/);
  assert.match(result.stdout, /\n$/, 'the template ends every record with a newline');
});

test('TPL_CHANGE is the lightweight change template without diff paths', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-template-change');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  // A dirty working copy must not leak paths into the lightweight template: the
  // whole point is to skip `self.diff()` on generic change reads.
  await fx.run(['bash', '-c', 'printf dirty > dirty.txt'], { cwd: repo, timeoutMs: 5_000 });
  const result = await mustRun(
    fx.run,
    ['jj', '--no-pager', '--color=never', 'log', '-r', '@', '--no-graph', '-T', TPL_CHANGE],
    repo,
  );
  assert.match(result.stdout, /"change_id":/);
  assert.match(result.stdout, /"current_working_copy":/);
  assert.match(result.stdout, /"immutable":/);
  assert.match(result.stdout, /"remote_bookmarks":/);
  assert.doesNotMatch(result.stdout, /"paths":/);
  assert.doesNotMatch(result.stdout, /self\.diff\(\)/);
  assert.match(result.stdout, /\n$/, 'the template ends every record with a newline');
});

test('change records expose the correction window (immutable + remote bookmarks)', () => {
  const local = changeFromRecord({
    change_id: 'abc',
    commit_id: 'def',
    description: 'feat: x',
    bookmarks: ['main'],
    immutable: false,
    remote_bookmarks: [],
    author: 'a@example.invalid',
  });
  assert.equal(local.immutable, false);
  assert.deepEqual([...local.remoteBookmarks], []);
  assert.equal(isRewritableChange(local), true, 'a local bookmark alone leaves the window open');

  const tracked = changeFromRecord({ immutable: false, remote_bookmarks: ['feat'] });
  assert.deepEqual([...tracked.remoteBookmarks], ['feat']);
  assert.equal(isRewritableChange(tracked), false, 'a pushed tracked bookmark closes the window');

  const trunk = changeFromRecord({ immutable: true, remote_bookmarks: [] });
  assert.equal(isRewritableChange(trunk), false);

  const legacy = changeFromRecord({ change_id: 'x' });
  assert.equal(legacy.immutable, false, 'a record without the field is treated as mutable');
  assert.deepEqual([...legacy.remoteBookmarks], []);
});

// ---------------------------------------------------------------------------
// End-of-work hand-off (jj_handoff) and session-owned workspace cleanup.
// ---------------------------------------------------------------------------

/** Commit the current working copy, leaving a fresh empty @ on top. */
async function commitWorkingCopy(fx: Fixture, cwd: string, message: string): Promise<void> {
  await mustRun(fx.run, ['jj', '--no-pager', '--color=never', 'commit', '-m', message], cwd);
}

/** Write one small file with the same real shell the other tests use. */
async function writeFixtureFile(fx: Fixture, cwd: string, name: string, content: string): Promise<void> {
  const result = await fx.run(['bash', '-c', `printf '%s\\n' '${content}' > '${name}'`], { cwd, timeoutMs: 5_000 });
  assert.equal(result.exitCode, 0, `could not write fixture file ${name}: ${result.stderr}`);
}

/**
 * The multi-session shape: `main` is a base commit and a linked workspace works
 * on a session stack starting from it. Operations and their recorded argv are
 * returned so the tests can prove the hand-off is jj-only and uses source mode.
 */
async function makeHandoffFixture(t: Parameters<typeof makeFixture>[0], label: string) {
  const fx = makeFixture(t, label);
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const ws = join(fx.root, 'ws-session');
  await mustRun(fx.run, ['jj', 'workspace', 'add', ws, '--name', 'session', '-r', 'main'], repo);
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  return { fx, repo, ws, operations, calls };
}

/**
 * Fixture for the real multi-session isolation flow: a commit made in the default
 * workspace, two workspaces created from its parent without `-r`, and an advanced main.
 *
 * A source-mode rebase from the shared pre-isolation commit therefore also moves the
 * default workspace's empty `@` and the second workspace's working copy.
 */
async function makeSharedBaseFixture(t: Parameters<typeof makeFixture>[0], label: string) {
  const fx = makeFixture(t, label);
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  await writeFixtureFile(fx, repo, 'pre.txt', 'pre');
  await commitWorkingCopy(fx, repo, 'feat: pre-isolation');
  const one = join(fx.root, 'ws-one');
  const two = join(fx.root, 'ws-two');
  await mustRun(fx.run, ['jj', 'workspace', 'add', one, '--name', 'one'], repo);
  await mustRun(fx.run, ['jj', 'workspace', 'add', two, '--name', 'two'], repo);
  const upstream = join(fx.root, 'ws-upstream');
  await mustRun(fx.run, ['jj', 'workspace', 'add', upstream, '--name', 'upstream', '-r', 'main'], repo);
  await writeFixtureFile(fx, upstream, 'up.txt', 'up');
  await commitWorkingCopy(fx, upstream, 'chore: upstream');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], upstream);
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  return { fx, repo, one, two, upstream, operations, calls };
}

test("operation layer: jj_handoff refuses a stack that would rewrite another workspace's uncommitted working copy", async (t) => {
  const { fx, one, two, operations, calls } = await makeSharedBaseFixture(t, 'dsh-jj-handoff-foreign-dirty');
  await writeFixtureFile(fx, one, 'one.txt', 'one');
  await commitWorkingCopy(fx, one, 'feat: one');
  // Uncommitted content in the other workspace; snapshot it so jj reports it non-empty.
  await writeFixtureFile(fx, two, 'dirty.txt', 'dirty');
  await operations.status(two);

  await assert.rejects(
    () => operations.handoff(one),
    /would also rewrite the working copy|uncommitted/,
    "a source-mode rebase must not move another workspace's uncommitted work",
  );
  assert.ok(!calls.some((argv) => argv.includes('rebase')), 'the hand-off fails before running any rebase');
  await operations.status(two);
});

test('operation layer: jj_handoff recovers empty foreign working copies instead of leaving them stale', async (t) => {
  const { fx, one, two, repo, operations } = await makeSharedBaseFixture(t, 'dsh-jj-handoff-foreign-empty');
  await writeFixtureFile(fx, one, 'one.txt', 'one');
  await commitWorkingCopy(fx, one, 'feat: one');

  const result = await operations.handoff(one);
  assert.equal(result.rebased, true);
  assert.equal(result.onTarget, true);
  const names = result.foreignWorkingCopies.map((copy) => copy.workspaceName).sort();
  assert.ok(names.includes('default'), `default working copy reported: ${names.join(', ')}`);
  assert.ok(names.includes('two'), `sibling workspace reported: ${names.join(', ')}`);
  assert.ok(
    result.foreignWorkingCopies.every((copy) => copy.empty && !copy.conflict),
    'the empty working copies were the only foreign changes',
  );
  assert.ok(
    result.foreignWorkingCopies.every((copy) => copy.recovered === true),
    `empty foreign working copies are recovered: ${JSON.stringify(result.foreignWorkingCopies)}`,
  );
  // Both foreign workspaces are readable again (not stale).
  await operations.status(two);
  await operations.status(repo);
});

test('jj_handoff tool: reports foreign working copies in a dry run and refuses a live one', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, one, two, upstream, operations } = await makeSharedBaseFixture(t, 'dsh-jj-handoff-foreign-live');
  await writeFixtureFile(fx, one, 'one.txt', 'one');
  await commitWorkingCopy(fx, one, 'feat: one');
  fx.cwd = one;

  const plain = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}))),
  ).get('jj_handoff')!;
  const dry = (await plain.execute({ dryRun: true }, fakeExec({ id: 'one-session' }))) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(plain.output.schema, dry), [], `output: ${JSON.stringify(dry)}`);
  assert.equal(dry['dryRun'], true);
  const reported = dry['foreignWorkingCopies'] as { workspaceName: string; recovered?: boolean }[];
  assert.ok(reported.some((copy) => copy.workspaceName === 'two'));
  assert.ok(reported.some((copy) => copy.workspaceName === 'default'));
  assert.ok(
    reported.every((copy) => copy.recovered === undefined),
    'a dry run reports foreign working copies without recovering them',
  );

  // A live session in the sibling workspace refuses the hand-off before any rewrite.
  const live = definitionsByName(
    jjToolDefinitions(
      toolContext(fx, toolService(fx, operations), resolveConfig({}), undefined, () => [
        { sessionId: 'two-session', cwd: two },
      ]),
    ),
  ).get('jj_handoff')!;
  await assert.rejects(() => live.execute({}, fakeExec({ id: 'one-session' })), /in use by a live session/);
  // The upstream workspace's @ is not part of this stack, so it stays untouched.
  await operations.status(upstream);
});

test('operation layer: jj_handoff resolves a local-only target, rebases the stack, and moves a bookmark', async (t) => {
  const { fx, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-local');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  await writeFixtureFile(fx, ws, 'two.txt', 'two');
  await commitWorkingCopy(fx, ws, 'feat: two');
  const sessionStack = (await operations.log(ws, 'main..@', 10)).filter((change) => change.description.length > 0);
  const firstSessionChange = sessionStack.at(-1);
  assert.ok(firstSessionChange !== undefined);

  // Advance main while the session works (the shared trunk moves).
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], fx.path('repo'));
  await writeFixtureFile(fx, fx.path('repo'), 'adv.txt', 'advance');
  await commitWorkingCopy(fx, fx.path('repo'), 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], fx.path('repo'));

  const result = await operations.handoff(ws, { bookmark: 'feature' });
  assert.equal(result.fetch.status, 'no-remote', 'a repository without remotes is not an error');
  assert.equal(result.destination, 'main', 'trunk() resolves to root, so local main is the fallback');
  assert.equal(result.destinationSource, 'main');
  assert.equal(result.rebased, true);
  assert.equal(result.onTarget, true);
  assert.deepEqual([...result.conflicts], []);
  assert.equal(result.firstChangeId, firstSessionChange.changeId);
  assert.equal(result.bookmark?.name, 'feature');
  assert.equal(result.bookmark?.moved, false, 'the bookmark did not exist yet: it is created, not moved');
  const tip = result.stack.find((change) => change.description === 'feat: two');
  assert.ok(tip !== undefined);
  assert.equal(result.bookmark?.target, tip.commitId, 'the bookmark points at the rebased stack tip');

  const ancestry = (await operations.log(ws, '::@-', 10)).filter((change) => change.description.length > 0);
  assert.deepEqual(
    ancestry.slice(0, 3).map((change) => change.description),
    ['feat: two', 'feat: one', 'chore: advance'],
    'the whole stack moved onto the advanced main',
  );
  assert.ok(
    calls.some((argv) => argv.includes('rebase') && argv.includes('-s')),
    'a stack is moved with source mode',
  );
  for (const argv of calls) assert.equal(argv[0], 'jj', `the hand-off never spawns ${argv[0]}`);
});

test('operation layer: jj_handoff reports an already-integrated stack without rebasing', async (t) => {
  const { fx, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-integrated');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');

  const result = await operations.handoff(ws);
  assert.equal(result.alreadyIntegrated, true);
  assert.equal(result.rebased, false);
  assert.equal(result.onTarget, true);
  assert.equal(result.destinationSource, 'main');
  assert.equal(result.conflicts.length, 0);
  assert.ok(result.firstChangeId.length > 0);
  assert.match(result.message, /already/);
  assert.ok(
    !calls.some((argv) => argv.includes('rebase')),
    'no rebase is spawned when the stack already sits on the target',
  );
  assert.ok(calls.length <= 7, `the clean integrated hand-off budget is 7 spawns, saw ${calls.length}`);
  assert.ok(
    !calls.some((argv) => argv.includes('bookmark') && argv.includes('list')),
    'the happy path must not list bookmarks just to build an unused error hint',
  );
});

test('operation layer: jj_handoff asks for a commit instead of folding uncommitted changes into the rebase', async (t) => {
  const { fx, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-dirty');
  await writeFixtureFile(fx, ws, 'dirty.txt', 'dirty');

  const result = await operations.handoff(ws);
  assert.equal(result.needsCommit, true);
  assert.equal(result.rebased, false);
  assert.match(result.message, /Commit them first with jj_commit/);
  assert.equal(result.stack.length, 1, 'the working-copy change is reported back to the model');
  assert.ok(calls.length <= 1, `a dirty working copy only pays for the @ read, saw ${calls.length} spawns`);
  assert.ok(
    !calls.some((argv) => argv.includes('fetch')),
    'no git fetch is attempted when the working copy needs a commit',
  );
  assert.equal(result.fetch.status, 'skipped', 'the skipped fetch is reported to the model');
});

test('operation layer: jj_handoff surfaces conflicts as data instead of stopping the session', async (t) => {
  const { fx, repo, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-conflict');
  await writeFixtureFile(fx, ws, 'f.txt', 'session edit');
  await commitWorkingCopy(fx, ws, 'feat: session edit');
  const sessionChange = (await operations.log(ws, 'main..@', 5)).find(
    (change) => change.description === 'feat: session edit',
  );
  assert.ok(sessionChange !== undefined);

  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: main edit'], repo);
  await writeFixtureFile(fx, repo, 'f.txt', 'main edit');
  await commitWorkingCopy(fx, repo, 'chore: main edit');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);

  const result = await operations.handoff(ws, { bookmark: 'feature' });
  assert.equal(result.rebased, true);
  assert.equal(result.onTarget, true);
  assert.ok(result.conflicts.length > 0, 'the conflict is reported as data for the model to resolve');
  assert.ok(
    result.conflicts.some((conflict) => conflict.changeId === sessionChange.changeId),
    'the conflicted session change is named',
  );
  assert.equal(result.bookmark, undefined);
  assert.match(result.bookmarkSkipped ?? '', /conflicts/);
});

test('handoff target resolution: explicit, automatic fallback, and the ask-the-user-only case', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-handoff-target');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  // No remote, no bookmark: only then is asking the user for a target legitimate.
  await assert.rejects(
    () => operations.resolveHandoffTarget(repo, { configured: 'trunk()' }),
    /Ask the user which revision/,
  );
  // An explicit destination that does not resolve is an actionable error.
  await assert.rejects(
    () => operations.resolveHandoffTarget(repo, { destination: 'no-such-rev', configured: 'trunk()' }),
    /does not resolve in this repository/,
  );
  // Local main is the automatic fallback once it exists; an explicit one wins.
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const automatic = await operations.resolveHandoffTarget(repo, { configured: 'trunk()' });
  assert.equal(automatic.revset, 'main');
  assert.equal(automatic.source, 'main');
  const explicit = await operations.resolveHandoffTarget(repo, { destination: 'main', configured: 'trunk()' });
  assert.equal(explicit.source, 'argument');
});

test('jj_rebase rejects the empty-root trunk() destination with an actionable message', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-rebase-trunk');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  await assert.rejects(() => operations.rebase(repo, '@', 'trunk()'), /empty root commit/);
  await assert.rejects(() => operations.rebase(repo, '@', 'trunk()'), /jj_handoff/);
});

test('root commit detection works in a SHA-256 repository (64-zero root id)', async (t) => {
  // SHA-256 Git repositories have a 64-zero root commit id, so a hard-coded 40-zero
  // constant would treat `trunk()` as a real target and hand off onto the root.
  const fx = makeFixture(t, 'dsh-jj-sha256');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjSha256(fx.run, fx.path('repo'));
  if (repo === undefined) return t.skip('the local git/jj toolchain cannot create a SHA-256 repository');
  const rootCommit = await mustRun(
    fx.run,
    ['jj', '--no-pager', '--color=never', 'log', '-r', 'root()', '--no-graph', '-T', 'commit_id'],
    repo,
  );
  if (rootCommit.stdout.trim().length !== 64) return t.skip('the fixture was not created with SHA-256 object ids');

  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'main', '-r', '@-'], repo);
  // A feat commit on top of main, then advance main underneath it.
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'feat: one'], repo);
  await writeFixtureFile(fx, repo, 'one.txt', 'one');
  await commitWorkingCopy(fx, repo, 'feat: one');
  const feat = (await operations.log(repo, 'main..@-', 5)).find((change) => change.description === 'feat: one');
  assert.ok(feat !== undefined, 'the fixture has a feat commit above main');
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], repo);
  await writeFixtureFile(fx, repo, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, repo, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  // Return the working copy to the feat stack (an empty @ on top of it).
  await mustRun(fx.run, ['jj', 'new', feat.changeId], repo);

  // 1. Target resolution skips the 64-zero root and falls back to the local main.
  const target = await operations.resolveHandoffTarget(repo, { configured: 'trunk()' });
  assert.equal(target.revset, 'main');
  assert.equal(target.source, 'main');

  // 2. The jj_rebase trunk() preflight rejects the root instead of running the rebase.
  await assert.rejects(() => operations.rebase(repo, '@', 'trunk()'), /empty root commit/);

  // 3. The whole hand-off resolves main and rebases the stack onto it.
  const result = await operations.handoff(repo, { firstChange: feat.changeId });
  assert.equal(result.destinationSource, 'main');
  assert.equal(result.destination, 'main');
  assert.equal(result.rebased, true);
  assert.equal(result.onTarget, true);
  assert.deepEqual([...result.conflicts], []);
  const ancestry = (await operations.log(repo, '::@-', 10)).filter((change) => change.description.length > 0);
  assert.deepEqual(
    ancestry.slice(0, 2).map((change) => change.description),
    ['feat: one', 'chore: advance'],
    'the stack moved onto the advanced main instead of the root commit',
  );
});

test('jj_handoff tool: runs the whole hand-off and reports model next steps', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, repo, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-tool-handoff');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  // The shared main advances while the session works, so the hand-off really rebases.
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], repo);
  await writeFixtureFile(fx, repo, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, repo, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const handoff = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations)))).get('jj_handoff')!;

  fx.cwd = ws;
  const value = (await handoff.execute({ bookmark: 'feature' }, fakeExec())) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(handoff.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  assert.equal(value['workspaceName'], 'session');
  assert.equal(value['destinationSource'], 'main');
  assert.equal(value['rebased'], true);
  assert.deepEqual(value['emptyChanges'], []);
  assert.deepEqual(
    value['cleanup'],
    { required: true, owned: false, workspaceName: 'session' },
    'cleanup of a workspace not created through jj_workspace_add stays with the user',
  );
  assert.ok(
    !(value['nextActions'] as { tool: string }[]).some((action) => action.tool === 'jj_workspace_cleanup'),
    'the tool never offers cleanup for a workspace this session does not own',
  );

  // The root workspace requires the explicit stack bottom: never rebase foreign history.
  fx.cwd = repo;
  await assert.rejects(() => handoff.execute({}, fakeExec()), /needs `firstChange`/);
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'feat: own change'], repo);
  await writeFixtureFile(fx, repo, 'own.txt', 'own');
  await commitWorkingCopy(fx, repo, 'feat: own change');
  const own = (await operations.log(repo, 'main..@', 5)).find((change) => change.description === 'feat: own change');
  assert.ok(own !== undefined);
  const defaultValue = (await handoff.execute({ firstChange: own.changeId }, fakeExec())) as Record<string, unknown>;
  assert.equal(defaultValue['alreadyIntegrated'], true);
  assert.equal(defaultValue['workspaceName'], 'default');

  // The protection is layout-based: renaming the root workspace cannot bypass it.
  await mustRun(fx.run, ['jj', 'workspace', 'rename', 'root-renamed'], repo);
  assert.equal((await operations.status(repo)).change.currentWorkingCopy, true);
  const renamedDefinitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations)))).get(
    'jj_handoff',
  )!;
  fx.cwd = repo;
  await assert.rejects(() => renamedDefinitions.execute({}, fakeExec()), /needs `firstChange`/);
});

test('jj_handoff: a rebase that empties a session change reports it instead of claiming a clean stack', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, repo, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-emptied');
  // Parallel duplicate work: the session change is identical to the one main
  // receives, so after the hand-off rebase jj keeps it as an empty commit.
  await writeFixtureFile(fx, ws, 'same.txt', 'same');
  await commitWorkingCopy(fx, ws, 'feat: parallel duplicate');
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: upstream duplicate'], repo);
  await writeFixtureFile(fx, repo, 'same.txt', 'same');
  await commitWorkingCopy(fx, repo, 'chore: upstream duplicate');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);

  const result = await operations.handoff(ws);
  assert.equal(result.rebased, true);
  const emptied = result.stack.filter((change) => change.empty && !change.currentWorkingCopy);
  assert.equal(emptied.length, 1, 'the session change became empty but jj kept it in the chain');
  assert.equal(emptied[0]?.description, 'feat: parallel duplicate');

  // A second hand-off is already integrated, but the model still gets the warning.
  const handoff = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations)))).get('jj_handoff')!;
  fx.cwd = ws;
  const value = (await handoff.execute({}, fakeExec())) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(handoff.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  const emptyChanges = value['emptyChanges'] as {
    changeId: string;
    description: string;
    currentWorkingCopy: boolean;
  }[];
  assert.equal(emptyChanges.length, 1, 'the empty change is reported as structured data');
  assert.equal(emptyChanges[0]?.description, 'feat: parallel duplicate');
  assert.equal(emptyChanges[0]?.currentWorkingCopy, false);
  assert.ok(
    !(value['nextActions'] as { tool: string }[]).some((action) => action.tool === 'jj_abandon'),
    'the tool reports empty changes but never offers to abandon them itself',
  );
});

test('jj_handoff dryRun reports the plan without fetching, rebasing or moving bookmarks', async (t) => {
  const { fx, repo, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-dry-run');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], repo);
  await writeFixtureFile(fx, repo, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, repo, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);

  const before = await operations.log(ws, '::@', 10);
  const plan = await operations.handoff(ws, { dryRun: true, bookmark: 'feature' });
  assert.equal(plan.dryRun, true);
  assert.equal(plan.rebased, false);
  assert.equal(plan.fetch.status, 'skipped');
  assert.match(plan.fetch.message, /dry run/);
  assert.match(plan.message, /Dry run/);
  assert.ok(
    plan.stack.some((change) => change.description === 'feat: one'),
    'the stack is reported',
  );
  assert.match(String(plan.bookmarkSkipped), /dry run/, 'the requested bookmark is not moved by a dry run');

  const after = await operations.log(ws, '::@', 10);
  assert.deepEqual(
    after.map((change) => change.changeId),
    before.map((change) => change.changeId),
    'a dry run changes no change id (nothing was rebased)',
  );

  // The real hand-off afterwards still rebases the stack onto main.
  const real = await operations.handoff(ws, { bookmark: 'feature', fetch: false });
  assert.equal(real.rebased, true);
  assert.equal(real.dryRun, false);

  // The tool exposes the flag and recommends the real run next.
  const handoff = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations)))).get('jj_handoff')!;
  fx.cwd = ws;
  const value = (await handoff.execute({ dryRun: true }, fakeExec())) as Record<string, unknown>;
  assert.equal(value['dryRun'], true);
  const actions = value['nextActions'] as { tool: string; args?: Record<string, unknown> }[];
  assert.equal(actions[0]?.tool, 'jj_handoff');
  assert.equal(actions[0]?.args?.['dryRun'], false);
});

test('jj_workspace_restore rebuilds a deleted session workspace on its recorded base', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const fx = makeFixture(t, 'dsh-jj-workspace-restore');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'base.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const agent = {};
  const moved: string[] = [];
  const workingDirectory = {
    ensure: async () => repo,
    get: () => repo,
    set: async (_agent: unknown, path: string) => {
      moved.push(path);
      return path;
    },
  };
  const context = {
    ...toolContext(fx, toolService(fx, operations), resolveConfig({}), workingDirectory),
    cwdFor: async () => repo,
  };
  const definitions = definitionsByName(jjToolDefinitions(context));
  const add = definitions.get('jj_workspace_add')!;
  const restore = definitions.get('jj_workspace_restore')!;
  const sessionPath = fx.path('session-ws');

  const created = (await add.execute({ path: sessionPath, name: 'session' }, fakeExec(agent))) as {
    path: string;
    changeId: string;
  };
  assert.equal(created.path, sessionPath);

  // Simulate a lost working copy: forget the registration and delete the directory.
  await operations.workspaceForget(repo, 'session', undefined);
  rmSync(sessionPath, { recursive: true, force: true });

  // A name this session never created is refused.
  await assert.rejects(
    () => restore.execute({ name: 'nope' }, fakeExec(agent)),
    /only rebuilds a workspace this session created/,
  );

  // The rebuild starts on the recorded base and the session enters it.
  const value = (await restore.execute({ name: 'session' }, fakeExec(agent))) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(restore.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  assert.equal(value['path'], sessionPath);
  assert.equal(value['name'], 'session');
  assert.equal(value['entered'], true);
  assert.equal(moved.at(-1), sessionPath);
  const restoredParent = await operations.log(sessionPath, '@-', 1);
  assert.equal(restoredParent[0]?.changeId, value['baseChangeId'], 'the rebuilt workspace sits on the recorded base');

  // A second restore refuses while the workspace is registered again.
  await assert.rejects(() => restore.execute({ name: 'session' }, fakeExec(agent)), /still registered/);

  // A non-empty directory is never overwritten.
  await operations.workspaceForget(repo, 'session', undefined);
  await writeFixtureFile(fx, repo, '../session-ws/keep.txt', 'keep');
  await assert.rejects(
    () => restore.execute({ name: 'session' }, fakeExec(agent)),
    /exists and is not empty/,
    'the tool refuses to write into a non-empty directory',
  );
});

test('jj_workspace_cleanup tool: unregisters only a session-created workspace and returns to the default workspace', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const fx = makeFixture(t, 'dsh-jj-tool-cleanup');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const moved: string[] = [];
  const workingDirectory = {
    ensure: async () => fx.cwd as string,
    set: async (_agent: unknown, path: string) => {
      moved.push(path);
      return path;
    },
  };
  const definitions = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}), workingDirectory)),
  );
  const agent = { id: 'cleanup-agent' };
  const otherAgent = { id: 'other-cleanup-agent' };
  const cleanup = definitions.get('jj_workspace_cleanup')!;
  fx.cwd = repo;

  // A workspace this session created is moved out of and unregistered.
  const wsPath = join(fx.root, 'ws-clean');
  const created = (await definitions
    .get('jj_workspace_add')!
    .execute({ path: wsPath, name: 'clean-me', enter: false }, fakeExec(agent))) as {
    readonly name: string;
  };
  assert.equal(created.name, 'clean-me');
  const forgottenChange = (await operations.status(wsPath)).change;
  fx.cwd = wsPath;
  const value = (await cleanup.execute({}, fakeExec(agent))) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(cleanup.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  assert.equal(value['forgotten'], true);
  assert.ok(
    !String(value['message']).includes('not abandoned by jj'),
    'an abandoned working-copy change is not reported',
  );
  assert.equal(
    await operations.changeExists(repo, forgottenChange.changeId),
    false,
    'jj abandoned the empty, undescribed working-copy change when the workspace was forgotten',
  );
  assert.equal(value['currentWorkspace'], 'default');
  assert.equal(value['currentWorkspaceRoot'], realpath(repo));
  assert.deepEqual(moved, [realpath(repo)], 'the session is moved back to the default workspace before forgetting');
  const remaining = await operations.workspaceList(repo);
  assert.ok(!remaining.some((workspace) => workspace.name === 'clean-me'), 'the workspace is unregistered');

  // The default workspace is never forgotten.
  fx.cwd = repo;
  await assert.rejects(() => cleanup.execute({}, fakeExec(agent)), /default workspace/);

  // A workspace the user created (or another session created) is refused.
  const foreign = join(fx.root, 'ws-foreign');
  await mustRun(fx.run, ['jj', 'workspace', 'add', foreign, '--name', 'foreign'], repo);
  fx.cwd = foreign;
  await assert.rejects(() => cleanup.execute({}, fakeExec(agent)), /not created through jj_workspace_add/);

  // Uncommitted work blocks cleanup so nothing is silently unregistered.
  fx.cwd = repo;
  const dirtyPath = join(fx.root, 'ws-dirty');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: dirtyPath, name: 'dirty-ws', enter: false }, fakeExec(agent));
  fx.cwd = dirtyPath;
  await writeFixtureFile(fx, dirtyPath, 'dirty.txt', 'dirty');
  await assert.rejects(() => cleanup.execute({}, fakeExec(agent)), /uncommitted changes/);

  // Ownership is per session: another agent cannot clean this session's workspace.
  fx.cwd = repo;
  const otherPath = join(fx.root, 'ws-othered');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: otherPath, name: 'other-ws', enter: false }, fakeExec(agent));
  fx.cwd = otherPath;
  await assert.rejects(() => cleanup.execute({}, fakeExec(otherAgent)), /not created through jj_workspace_add/);

  // Ownership is name+root: a user workspace recreated under a name this session
  // once used is never forgotten by the stale ownership record.
  fx.cwd = repo;
  const reusedOld = join(fx.root, 'ws-reused-old');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: reusedOld, name: 'reused', enter: false }, fakeExec(agent));
  await mustRun(fx.run, ['jj', 'workspace', 'forget', 'reused'], repo);
  const reusedNew = join(fx.root, 'ws-reused-new');
  await mustRun(fx.run, ['jj', 'workspace', 'add', reusedNew, '--name', 'reused'], repo);
  fx.cwd = reusedNew;
  await assert.rejects(
    () => cleanup.execute({}, fakeExec(agent)),
    /not created through jj_workspace_add/,
    'a recreated workspace with the same name at another root is not session-owned',
  );

  // A workspace created without an explicit name is still attributed correctly,
  // even when jj's alphabetical workspace order would end on a user workspace.
  fx.cwd = repo;
  await mustRun(fx.run, ['jj', 'workspace', 'add', join(fx.root, 'zzz-user-ws'), '--name', 'zzz-user'], repo);
  const unnamedPath = join(fx.root, 'ws-unnamed');
  const unnamed = (await definitions
    .get('jj_workspace_add')!
    .execute({ path: unnamedPath, enter: false }, fakeExec(agent))) as {
    readonly name: string;
    readonly path: string;
  };
  assert.equal(unnamed.name, 'ws-unnamed', 'jj derives the name from the path basename');
  fx.cwd = unnamed.path;
  const unnamedValue = (await cleanup.execute({}, fakeExec(agent))) as Record<string, unknown>;
  assert.equal(unnamedValue['forgotten'], true);

  // Without workingDirectory.set the plugin cannot move the session back; it must
  // refuse instead of unregistering the working copy underneath the session.
  const plainDefinitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  fx.cwd = repo;
  const unsettablePath = join(fx.root, 'ws-unsettable');
  await plainDefinitions
    .get('jj_workspace_add')!
    .execute({ path: unsettablePath, name: 'unsettable', enter: false }, fakeExec(agent));
  fx.cwd = unsettablePath;
  await assert.rejects(
    () => plainDefinitions.get('jj_workspace_cleanup')!.execute({}, fakeExec(agent)),
    /cannot move this session back to the default workspace/,
  );

  // A described empty working-copy change survives `jj workspace forget` (jj only
  // abandons empty, undescribed changes without descendants). The plugin prunes it when
  // that is provably content-free, so it cannot become a permanent empty commit.
  fx.cwd = repo;
  const retainedPath = join(fx.root, 'ws-retained');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: retainedPath, name: 'retained', enter: false }, fakeExec(agent));
  await mustRun(fx.run, ['jj', '--no-pager', 'describe', '-r', '@', '-m', 'empty marker'], retainedPath);
  const marker = (await operations.log(retainedPath, '@', 1))[0];
  assert.ok(marker !== undefined);
  fx.cwd = retainedPath;
  const retainedValue = (await cleanup.execute({}, fakeExec(agent))) as Record<string, unknown>;
  assert.equal(retainedValue['forgotten'], true);
  assert.equal(retainedValue['prunedEmptyChangeId'], marker.changeId);
  assert.match(String(retainedValue['message']), /was abandoned after the forget/);
  assert.equal(
    await operations.changeExists(repo, marker.changeId),
    false,
    'the empty, unpublished change without descendants is pruned',
  );

  // With another workspace based on it, abandoning would rewrite that workspace: the
  // change is kept and reported instead.
  fx.cwd = repo;
  const sharedPath = join(fx.root, 'ws-shared-empty');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: sharedPath, name: 'shared-empty', enter: false }, fakeExec(agent));
  await mustRun(fx.run, ['jj', '--no-pager', 'describe', '-r', '@', '-m', 'shared empty marker'], sharedPath);
  const sharedMarker = (await operations.log(sharedPath, '@', 1))[0];
  assert.ok(sharedMarker !== undefined);
  await mustRun(
    fx.run,
    ['jj', 'workspace', 'add', join(fx.root, 'ws-keeper'), '--name', 'keeper', '-r', sharedMarker.changeId],
    repo,
  );
  fx.cwd = sharedPath;
  const keptValue = (await cleanup.execute({}, fakeExec(agent))) as Record<string, unknown>;
  assert.equal(keptValue['forgotten'], true);
  assert.equal(keptValue['prunedEmptyChangeId'], undefined);
  assert.match(String(keptValue['message']), /not abandoned by jj/);
  assert.equal(
    await operations.changeExists(repo, sharedMarker.changeId),
    true,
    'a change another workspace is based on is never abandoned',
  );
});

test('jj_workspace_cleanup: recovers a stale default workspace before forgetting', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-cleanup-stale-default');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const moved: string[] = [];
  const workingDirectory = {
    ensure: async () => fx.cwd as string,
    set: async (_agent: unknown, path: string) => {
      moved.push(path);
      return path;
    },
  };
  const definitions = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}), workingDirectory)),
  );
  const agent = { id: 'stale-cleanup-agent' };
  fx.cwd = repo;
  const created = (await definitions
    .get('jj_workspace_add')!
    .execute({ path: join(fx.root, 'ws-stale'), name: 'stale-ws', enter: false }, fakeExec(agent))) as {
    readonly path: string;
  };
  const ws = created.path;
  const rootEmptyChange = (await operations.log(repo, '@', 1))[0];
  assert.ok(rootEmptyChange !== undefined);
  // Advance main from the session workspace, then start the session stack on the
  // root workspace's empty @ — the shape the old `parents: ["@"]` guidance created.
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], ws);
  await writeFixtureFile(fx, ws, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, ws, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], ws);
  await mustRun(fx.run, ['jj', 'new', rootEmptyChange.changeId], ws);
  await writeFixtureFile(fx, ws, 'work.txt', 'work');
  await commitWorkingCopy(fx, ws, 'feat: work');
  // The hand-off rebases the root workspace's checked-out change, leaving it stale. The
  // service normally recovers the affected empty working copy itself; this test disables
  // that recovery (a caller-provided review without recovery roots) so cleanup's own
  // stale recovery stays covered.
  const handoff = await operations.handoff(ws, {
    reviewForeignWorkingCopies: () => ({ action: 'proceed' }),
  });
  assert.equal(handoff.rebased, true);
  await assert.rejects(
    () => operations.status(repo),
    /stale/i,
    'the default workspace is stale after the sibling rebase',
  );

  calls.length = 0;
  fx.cwd = ws;
  const value = (await definitions.get('jj_workspace_cleanup')!.execute({}, fakeExec(agent))) as Record<
    string,
    unknown
  >;
  assert.equal(value['forgotten'], true);
  assert.equal(value['currentWorkspace'], 'default');
  assert.deepEqual(moved, [realpath(repo)]);
  assert.ok(
    calls.some((argv) => argv.includes('workspace') && argv.includes('update-stale')),
    'the stale default workspace is recovered before forgetting it is used again',
  );
});

test('jj_workspace_cleanup: reclaims a recorded workspace left by an interrupted session', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const fx = makeFixture(t, 'dsh-jj-orphan-cleanup');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const meta = join(realpath(repo), '.jj', 'repo');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}))),
  );
  const cleanup = definitions.get('jj_workspace_cleanup')!;
  const owner = { id: 'interrupted-session' };
  const rescuer = { id: 'rescuer-session' };
  fx.cwd = repo;

  // The interrupted session left a recorded workspace behind. Another session sees it
  // as orphaned and reclaims it without entering it.
  const wsPath = join(fx.root, 'ws-orphan');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: wsPath, name: 'orphan-ws', enter: false }, fakeExec(owner));
  const emptyChange = (await operations.status(wsPath)).change;
  const listed = (await definitions.get('jj_workspace_list')!.execute({ detail: 'full' }, fakeExec(rescuer))) as {
    workspaces: Record<string, unknown>[];
  };
  const entry = listed.workspaces.find((workspace) => workspace['name'] === 'orphan-ws');
  assert.equal(entry?.['owned'], false);
  assert.equal(entry?.['ownerSessionId'], 'interrupted-session');
  assert.equal(entry?.['ownerAlive'], false);
  assert.equal(entry?.['orphaned'], true);

  const value = (await cleanup.execute({ workspace: 'orphan-ws' }, fakeExec(rescuer))) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(cleanup.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  assert.equal(value['forgotten'], true);
  assert.equal(value['mode'], 'orphan');
  assert.equal(value['ownerSessionId'], 'interrupted-session');
  assert.equal(value['currentWorkspace'], 'default');
  assert.equal(
    await operations.changeExists(repo, emptyChange.changeId),
    false,
    'the empty working-copy change is abandoned by jj on forget',
  );
  assert.equal(existsSync(wsPath), true, 'the directory is preserved');
  assert.ok(
    !(await operations.workspaceList(repo)).some((workspace) => workspace.name === 'orphan-ws'),
    'the workspace is unregistered',
  );

  // A live recorded owner blocks the reclaim: the interrupted session may still resume.
  const livePath = join(fx.root, 'ws-live');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: livePath, name: 'live-ws', enter: false }, fakeExec(owner));
  const liveDefinitions = definitionsByName(
    jjToolDefinitions(
      toolContext(fx, toolService(fx, operations), resolveConfig({}), undefined, () => [
        { sessionId: 'interrupted-session', cwd: livePath },
      ]),
    ),
  );
  await assert.rejects(
    () => liveDefinitions.get('jj_workspace_cleanup')!.execute({ workspace: 'live-ws' }, fakeExec(rescuer)),
    /still live/,
  );

  // A different live session occupying the workspace also blocks it.
  const busyPath = join(fx.root, 'ws-busy');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: busyPath, name: 'busy-ws', enter: false }, fakeExec(owner));
  writeSessionHeartbeat(meta, {
    sessionId: 'third-session',
    cwd: busyPath,
    workspaceName: 'busy-ws',
    workspaceRoot: realpath(busyPath),
    updatedAt: Date.now(),
  });
  await assert.rejects(() => cleanup.execute({ workspace: 'busy-ws' }, fakeExec(rescuer)), /currently working in/);
  removeSessionHeartbeat(meta, 'third-session');

  // Uncommitted work in the foreign workspace blocks it: cleanup never loses content.
  const dirtyPath = join(fx.root, 'ws-dirty-orphan');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: dirtyPath, name: 'dirty-orphan', enter: false }, fakeExec(owner));
  await writeFixtureFile(fx, dirtyPath, 'dirty.txt', 'dirty');
  await assert.rejects(() => cleanup.execute({ workspace: 'dirty-orphan' }, fakeExec(rescuer)), /uncommitted changes/);

  // A workspace the plugin did not create is never unregistered.
  const userPath = join(fx.root, 'ws-user');
  await mustRun(fx.run, ['jj', 'workspace', 'add', userPath, '--name', 'user-ws'], repo);
  await assert.rejects(
    () => cleanup.execute({ workspace: 'user-ws' }, fakeExec(rescuer)),
    /no jj_workspace_add record/,
  );

  // A recorded workspace whose directory disappeared can still be unregistered.
  const gonePath = join(fx.root, 'ws-gone');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: gonePath, name: 'gone-ws', enter: false }, fakeExec(owner));
  rmSync(gonePath, { recursive: true, force: true });
  const goneValue = (await cleanup.execute({ workspace: 'gone-ws' }, fakeExec(rescuer))) as Record<string, unknown>;
  assert.equal(goneValue['forgotten'], true);
  assert.match(String(goneValue['message']), /directory is gone/);

  // A record whose workspace was already forgotten is pruned instead of failing.
  const stalePath = join(fx.root, 'ws-stale-record');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: stalePath, name: 'stale-record', enter: false }, fakeExec(owner));
  await operations.workspaceForget(repo, 'stale-record', undefined);
  const staleValue = (await cleanup.execute({ workspace: 'stale-record' }, fakeExec(rescuer))) as Record<
    string,
    unknown
  >;
  assert.equal(staleValue['forgotten'], false);
  assert.equal(staleValue['alreadyForgotten'], true);
  assert.match(String(staleValue['message']), /not registered with jj anymore/);
});

test('jj_workspace_cleanup: a restarted host keeps the recorded workspace ownership', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-resume-cleanup');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const first = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}))));
  fx.cwd = repo;
  const wsPath = join(fx.root, 'ws-resumed');
  await first
    .get('jj_workspace_add')!
    .execute({ path: wsPath, name: 'resumed', enter: false }, fakeExec({ id: 'resumed-session' }));

  // A restarted host: brand-new registry instance and a brand-new agent object, but the
  // same DSH session id. Ownership must come back from the durable record.
  const moved: string[] = [];
  const workingDirectory = {
    ensure: async () => fx.cwd as string,
    set: async (_agent: unknown, path: string) => {
      moved.push(path);
      return path;
    },
  };
  const operationsAfterRestart = new JjOperations({ runJj, config: {} });
  const restarted = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operationsAfterRestart), resolveConfig({}), workingDirectory)),
  );
  fx.cwd = wsPath;
  const value = (await restarted
    .get('jj_workspace_cleanup')!
    .execute({}, fakeExec({ id: 'resumed-session' }))) as Record<string, unknown>;
  assert.equal(value['forgotten'], true);
  assert.deepEqual(moved, [realpath(repo)], 'the resumed session moves back to the default workspace');
  assert.ok(!(await operationsAfterRestart.workspaceList(repo)).some((workspace) => workspace.name === 'resumed'));
});

test("jj_workspace_cleanup: rebases the default workspace's empty @ onto the finished stack", async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const fx = makeFixture(t, 'dsh-jj-cleanup-adopt-default');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const moved: string[] = [];
  const workingDirectory = {
    ensure: async () => fx.cwd as string,
    set: async (_agent: unknown, path: string) => {
      moved.push(path);
      return path;
    },
  };
  const definitions = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}), workingDirectory)),
  );
  const agent = { id: 'adopt-agent' };
  fx.cwd = repo;
  const wsPath = join(fx.root, 'ws-adopt');
  await definitions.get('jj_workspace_add')!.execute({ path: wsPath, name: 'adopt', enter: false }, fakeExec(agent));
  // Work committed inside the isolated workspace: its top is a real change, and the
  // default workspace still holds the empty @ created before the isolation.
  await writeFixtureFile(fx, wsPath, 'work.txt', 'work');
  await mustRun(fx.run, ['jj', 'commit', '-m', 'feat: work'], wsPath);
  const work = (await operations.log(wsPath, '@-', 1))[0];
  assert.ok(work !== undefined);
  const defaultBefore = (await operations.status(repo)).change;
  assert.equal(defaultBefore.empty, true);

  fx.cwd = wsPath;
  const cleanup = definitions.get('jj_workspace_cleanup')!;
  const value = (await cleanup.execute({}, fakeExec(agent))) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(cleanup.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  const adopted = value['defaultWorkingCopy'] as {
    changeId: string;
    adopted: boolean;
    ontoChangeId?: string;
  };
  assert.equal(adopted.adopted, true);
  assert.equal(adopted.changeId, defaultBefore.changeId);
  assert.equal(adopted.ontoChangeId, work.changeId);
  assert.match(String(value['message']), /stays linear/);
  // The default workspace is fresh and its @ now sits directly on the delivered commit,
  // so the next work there continues the stack instead of forking it.
  const defaultAfter = (await operations.status(repo)).change;
  assert.equal(defaultAfter.changeId, defaultBefore.changeId);
  assert.equal(defaultAfter.currentWorkingCopy, true);
  const parent = (await operations.log(repo, '@-', 1))[0];
  assert.equal(parent?.changeId, work.changeId);
  assert.deepEqual(moved, [realpath(repo)]);
});

test('jj_workspace_cleanup: leaves the default working copy alone while another session uses it', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-cleanup-adopt-live');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const base = (await operations.log(repo, '@-', 1))[0];
  assert.ok(base !== undefined);
  const workingDirectory = {
    ensure: async () => fx.cwd as string,
    set: async (_agent: unknown, path: string) => path,
  };
  const definitions = definitionsByName(
    jjToolDefinitions(
      toolContext(fx, toolService(fx, operations), resolveConfig({}), workingDirectory, () => [
        { sessionId: 'other-session', cwd: repo },
      ]),
    ),
  );
  const agent = { id: 'adopt-live-agent' };
  fx.cwd = repo;
  const wsPath = join(fx.root, 'ws-adopt-live');
  await definitions
    .get('jj_workspace_add')!
    .execute({ path: wsPath, name: 'adopt-live', enter: false }, fakeExec(agent));
  await writeFixtureFile(fx, wsPath, 'work.txt', 'work');
  await mustRun(fx.run, ['jj', 'commit', '-m', 'feat: work'], wsPath);
  const work = (await operations.log(wsPath, '@-', 1))[0];
  assert.ok(work !== undefined);
  const defaultBefore = (await operations.status(repo)).change;

  fx.cwd = wsPath;
  const value = (await definitions.get('jj_workspace_cleanup')!.execute({}, fakeExec(agent))) as Record<
    string,
    unknown
  >;
  const skipped = value['defaultWorkingCopy'] as { adopted: boolean; reason?: string };
  assert.equal(skipped.adopted, false);
  assert.equal(skipped.reason, 'live-session');
  const defaultAfter = (await operations.status(repo)).change;
  assert.equal(defaultAfter.changeId, defaultBefore.changeId, "the other session's working copy is untouched");
  assert.equal((await operations.log(repo, '@-', 1))[0]?.changeId, base.changeId, 'the empty @ is still a sibling');
});

test('operation layer: jj_handoff rejects a stack that is not the whole stack, and root destinations', async (t) => {
  const { fx, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-validation');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  const workingCopy = await operations.status(ws);
  await assert.rejects(
    () => operations.handoff(ws, { firstChange: workingCopy.change.changeId }),
    /is not the bottom of this workspace's stack/,
    'the empty working copy is not the stack bottom',
  );
  await assert.rejects(
    () => operations.handoff(ws, { destination: 'trunk()' }),
    /resolves to jj's empty root commit/,
    'an explicit root destination is a model mistake, not a silent fallback',
  );
});

test('operation layer: jj_handoff moves a bookmark on an already-integrated stack and honours fetch:false', async (t) => {
  const { fx, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-integrated-bookmark');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');

  const result = await operations.handoff(ws, { bookmark: 'feature', fetch: false });
  assert.equal(result.fetch.status, 'skipped');
  assert.equal(result.alreadyIntegrated, true);
  assert.equal(result.bookmark?.name, 'feature', 'the bookmark request is not silently dropped on the integrated path');
  const tip = result.stack.find((change) => change.description === 'feat: one');
  assert.ok(tip !== undefined);
  assert.equal(result.bookmark?.target, tip.commitId);
  assert.ok(!calls.some((argv) => argv.includes('fetch')), 'fetch:false spawns no git fetch');
  assert.ok(calls.length <= 9, `the integrated+bookmark budget is 9 spawns, saw ${calls.length}`);
  const bookmarkLists = calls.filter((argv) => argv.includes('bookmark') && argv.includes('list'));
  assert.equal(bookmarkLists.length, 1, 'only the pre-set existence check lists bookmarks; the target is known');
});

test('operation layer: jj_handoff falls back to master and ignores an unresolvable configured target', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-handoff-master');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'master', '-r', '@-'], repo);
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  const fallback = await operations.resolveHandoffTarget(repo, { configured: 'no-such-target' });
  assert.equal(fallback.revset, 'master');
  assert.equal(fallback.source, 'master');
  const configured = await operations.resolveHandoffTarget(repo, { configured: 'master' });
  assert.equal(configured.source, 'configured');
});

test('operation layer: jj_handoff recovers a stale working copy instead of handing recovery to the user', async (t) => {
  const { fx, repo, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-stale');
  // Operation that created this workspace's initial working copy (the last one now).
  const opLog = await mustRun(
    fx.run,
    ['jj', '--no-pager', '--color=never', 'op', 'log', '--no-graph', '-n', '1', '-T', 'id.short()'],
    ws,
  );
  const op = opLog.stdout.trim();
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  // Another workspace rewinds the shared operation view: every content read in ws
  // then fails with "The working copy is stale".
  await mustRun(fx.run, ['jj', '--no-pager', '--color=never', 'op', 'restore', op], repo);

  const result = await operations.handoff(ws);
  assert.equal(result.fetch.status, 'no-remote');
  assert.ok(
    calls.some((argv) => argv.includes('workspace') && argv.includes('update-stale')),
    'the hand-off recovers the stale working copy itself and retries',
  );
});

test('jj tools: a stale working copy is recovered once and the tool call retried', async (t) => {
  const { fx, repo, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-tool-stale-recovery');
  const definitions = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}))),
  );
  // Make the session workspace stale: another workspace restores an earlier operation.
  const opLog = await mustRun(
    fx.run,
    ['jj', '--no-pager', '--color=never', 'op', 'log', '--no-graph', '-n', '1', '-T', 'id.short()'],
    ws,
  );
  const op = opLog.stdout.trim();
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  await mustRun(fx.run, ['jj', '--no-pager', '--color=never', 'op', 'restore', op], repo);
  await assert.rejects(() => operations.status(ws), /stale/i, 'the fixture workspace is stale');

  calls.length = 0;
  fx.cwd = ws;
  const value = (await definitions.get('jj_status')!.execute({}, fakeExec({ id: 'stale-tool-session' }))) as Record<
    string,
    unknown
  >;
  assert.equal(value['workspaceName'], 'session');
  assert.ok(
    calls.some((argv) => argv.includes('workspace') && argv.includes('update-stale')),
    'the tool wrapper recovers the stale working copy before retrying',
  );
});

test('operation layer: jj_handoff reports disconnected stacks instead of rebasing one of them', async (t) => {
  const { fx, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-ambiguous');
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'feat: left'], ws);
  await writeFixtureFile(fx, ws, 'left.txt', 'left');
  await commitWorkingCopy(fx, ws, 'feat: left');
  const left = (await operations.log(ws, '@-', 1))[0];
  assert.ok(left !== undefined);
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'feat: right'], ws);
  await writeFixtureFile(fx, ws, 'right.txt', 'right');
  await commitWorkingCopy(fx, ws, 'feat: right');
  const right = (await operations.log(ws, '@-', 1))[0];
  assert.ok(right !== undefined);
  // A merge of two sibling stacks: two roots above main.
  await mustRun(fx.run, ['jj', 'new', left.changeId, right.changeId], ws);

  const result = await operations.handoff(ws);
  assert.equal(result.rebased, false);
  assert.deepEqual([...result.ambiguousRoots].sort(), [left.changeId, right.changeId].sort());
  assert.match(result.message, /disconnected stacks/);
});
test('tools: a failed session-cwd resolution is fail-closed instead of guessing a repository', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-tools-cwd-fail');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const service = toolService(fx, operations);

  const definitions: ToolDefinition[] = [];
  const host = {
    tools: {
      register: (definition: ToolDefinition) => {
        definitions.push(definition);
        return () => {};
      },
    },
    workingDirectory: {
      ensure: async (): Promise<string> => {
        throw new Error('session disappeared');
      },
    },
  };
  registerJjTools(host, { service, config: {} });
  const status = definitions.find((definition) => definition.name === 'jj_status');
  assert.ok(status !== undefined);
  await assert.rejects(
    () => status.execute({}, fakeExec({ id: 'agent-cwd' })),
    /cannot resolve the session working directory/,
    'a failed ensure must not fall back to process.cwd()',
  );

  const noWdDefinitions: ToolDefinition[] = [];
  registerJjTools(
    {
      tools: {
        register: (definition: ToolDefinition) => {
          noWdDefinitions.push(definition);
          return () => {};
        },
      },
    },
    { service, config: {} },
  );
  const status2 = noWdDefinitions.find((definition) => definition.name === 'jj_status');
  assert.ok(status2 !== undefined);
  await assert.rejects(() => status2.execute({}, fakeExec({ id: 'agent-no-wd' })), /no workingDirectory service/);
});

// ---------------------------------------------------------------------------
// A2 audit regressions: hand-off destination safety, workspace names, op log time.
// ---------------------------------------------------------------------------

test('operation layer: jj_handoff refuses a destination unrelated to the workspace instead of rewriting shared history', async (t) => {
  const { fx, repo, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-unrelated');
  // `side` only shares jj's empty root commit with `main`, like the audit repro:
  // `roots(::@ ~ ::side)` would name the shared `main` commit, not session work.
  await mustRun(fx.run, ['jj', 'new', 'root()', '-m', 'other: side'], repo);
  await writeFixtureFile(fx, repo, 'side.txt', 'side');
  await commitWorkingCopy(fx, repo, 'other: side');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'side', '-r', '@-'], repo);
  await mustRun(fx.run, ['jj', 'new', 'main'], repo);
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  await writeFixtureFile(fx, ws, 'two.txt', 'two');
  await commitWorkingCopy(fx, ws, 'feat: two');
  const sessionBottom = (await operations.log(ws, 'main..@', 10))
    .filter((change) => change.description.length > 0)
    .at(-1);
  assert.ok(sessionBottom !== undefined);
  const mainBefore = (await mustRun(fx.run, ['jj', 'log', '-r', 'main', '--no-graph', '-T', 'commit_id'], repo)).stdout;

  // Without firstChange the shared `chore: base` commit would be rebased.
  await assert.rejects(
    () => operations.handoff(ws, { destination: 'side', fetch: false }),
    /refuses to rebase/,
    'shared history must never be moved',
  );
  // An explicit firstChange cannot smuggle an unrelated destination either.
  await assert.rejects(
    () => operations.handoff(ws, { destination: 'side', firstChange: sessionBottom.changeId, fetch: false }),
    /shares no history/,
  );
  const mainAfter = (await mustRun(fx.run, ['jj', 'log', '-r', 'main', '--no-graph', '-T', 'commit_id'], repo)).stdout;
  assert.equal(mainAfter, mainBefore, 'the shared main commit was not rewritten');
  assert.ok(!calls.some((argv) => argv.includes('rebase')), 'no rebase is spawned for an unrelated destination');
  const sessionDescriptions = (await operations.log(ws, 'main..@', 10)).map((change) => change.description);
  assert.deepEqual(
    sessionDescriptions.filter((description) => description.length > 0),
    ['feat: two', 'feat: one'],
    'the session stack is untouched after the refused hand-off',
  );
});

test('operation layer: jj_handoff reports a workspace that is behind the destination instead of claiming success', async (t) => {
  const { fx, repo, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-behind');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  const sessionAt = (await operations.log(ws, '@', 1))[0];
  assert.ok(sessionAt !== undefined);
  // Another process integrates the session's working-copy change into main, so
  // the destination (main) already contains `@`: the workspace is behind it.
  await mustRun(fx.run, ['jj', 'new', sessionAt.changeId, '-m', 'chore: integrate session'], repo);
  await writeFixtureFile(fx, repo, 'integrated.txt', 'x');
  await commitWorkingCopy(fx, repo, 'chore: integrate session');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const before = (await operations.log(ws, '@', 1))[0];
  assert.ok(before !== undefined);

  const result = await operations.handoff(ws, { fetch: false });
  assert.equal(result.destinationSource, 'main');
  assert.equal(result.rebased, false);
  assert.equal(result.alreadyIntegrated, false, 'a workspace behind the destination is not integrated');
  assert.equal(result.onTarget, false, 'the stack does not sit on the destination');
  assert.deepEqual([...result.stack], []);
  assert.match(result.message, /behind/);
  assert.ok(!calls.some((argv) => argv.includes('rebase')), 'nothing is rebased for a behind workspace');
  const after = (await operations.log(ws, '@', 1))[0];
  assert.equal(after?.changeId, before.changeId, 'the workspace working copy is untouched');
});

test('operation layer: jj_handoff rejects a destination that resolves to the working copy itself', async (t) => {
  const { fx, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-at-destination');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  await assert.rejects(
    () => operations.handoff(ws, { destination: '@', fetch: false }),
    /own working copy @/,
    'the working copy is not an integration base',
  );
  assert.ok(!calls.some((argv) => argv.includes('rebase')));
});

test('operation layer: jj_handoff moves a session bookmark that points into the stack it rebases', async (t) => {
  const { fx, repo, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-owned-bookmark');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  await writeFixtureFile(fx, ws, 'two.txt', 'two');
  await commitWorkingCopy(fx, ws, 'feat: two');
  // The session bookmarked its own stack tip; the shared-history guard must let the
  // owned bookmark move with it instead of treating it as foreign history.
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'feature', '-r', '@-'], ws);
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], repo);
  await writeFixtureFile(fx, repo, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, repo, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);

  const result = await operations.handoff(ws, { bookmark: 'feature', fetch: false });
  assert.equal(result.rebased, true);
  assert.equal(result.onTarget, true);
  assert.equal(result.bookmark?.name, 'feature');
  assert.equal(result.bookmark?.moved, true);
  const rebasedTip = result.stack.find((change) => change.description === 'feat: two');
  assert.ok(rebasedTip !== undefined);
  assert.equal(result.bookmark?.target, rebasedTip.commitId, 'the bookmark follows the rebased stack tip');
});

test('operation layer: jj_handoff validates a bookmark name before rebasing and reports later failures without losing the result', async (t) => {
  const { fx, repo, ws, operations, calls } = await makeHandoffFixture(t, 'dsh-jj-handoff-bookmark-errors');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  // Make the hand-off rebase-worthy: the shared main advances.
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], repo);
  await writeFixtureFile(fx, repo, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, repo, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);

  // An invalid name is rejected before the fetch/rebase: nothing was rewritten yet.
  await assert.rejects(() => operations.handoff(ws, { bookmark: 'main@origin', fetch: false }), /must not contain/);
  assert.ok(!calls.some((argv) => argv.includes('rebase')), 'no rebase runs before the bookmark validation');

  // jj itself rejects this name after the rebase: the rebase result must survive
  // as a bookmarkSkipped note instead of turning the whole hand-off into an error.
  const result = await operations.handoff(ws, { bookmark: '--allow-backwards', fetch: false });
  assert.equal(result.rebased, true);
  assert.equal(result.bookmark, undefined);
  assert.match(result.bookmarkSkipped ?? '', /was not moved/);
});

test('operation layer: revset-shaped operation inputs cannot be parsed as options or batch-rewrite history', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-op-input-shape');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  const atBefore = (await operations.status(repo)).change.changeId;

  // A parent such as `--help` must be treated as a revset (and fail), not let jj
  // print help, exit 0, and report the untouched working copy as a new change.
  await assert.rejects(() => operations.newChange(repo, ['--help'], 'feat: never created'), /revset/i);
  assert.equal((await operations.status(repo)).change.changeId, atBefore, 'the working copy was not replaced');

  // A multi-revision revset must be refused instead of describing every change.
  await writeFixtureFile(fx, repo, 'one.txt', 'one');
  await commitWorkingCopy(fx, repo, 'feat: one');
  await writeFixtureFile(fx, repo, 'two.txt', 'two');
  await commitWorkingCopy(fx, repo, 'feat: two');
  await assert.rejects(() => operations.describeChange(repo, '::@', 'chore: batch rewrite'), /more than one revision/);
  const descriptions = (await operations.log(repo, '@ | @-', 5)).map((change) => change.description);
  assert.deepEqual(descriptions, ['', 'feat: two'], 'no description was rewritten');
  assert.ok(!calls.some((argv) => argv.includes('describe')), 'no describe ran for a multi-revision revset');
});

test('operation layer: jj_op_log returns a parseable operation timestamp (json time is a { start, end } object)', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const fx = makeFixture(t, 'dsh-jj-oplog-time');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');

  const operationsList = await operations.opLog(repo, 3, undefined);
  assert.ok(operationsList.length > 0);
  for (const operation of operationsList) {
    assert.notEqual(operation.time, '[object Object]', 'the time must not stringify the jj object');
    assert.ok(operation.time.length > 0);
    assert.equal(Number.isNaN(Date.parse(operation.time)), false, `the time must parse: ${operation.time}`);
  }

  // The tool output schema still accepts the parseable string.
  fx.cwd = repo;
  const tool = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations)))).get('jj_op_log')!;
  const value = (await tool.execute({ limit: 2 }, fakeExec())) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(tool.output.schema, value), [], `output: ${JSON.stringify(value)}`);
});

test('operation layer: workspaceAdd returns the bare name for names with spaces and trims the path', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-workspace-name');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  const spacedPath = join(fx.root, 'ws spaced');
  const created = await operations.workspaceAdd(repo, spacedPath, 'my session', [], undefined, undefined);
  assert.equal(created.name, 'my session', 'jj quote-decoration must not leak into the name');
  assert.equal(created.path, realpath(spacedPath));
  const listed = await operations.workspaceList(repo);
  assert.ok(listed.some((workspace) => workspace.name === 'my session'));

  // The default name is the basename; surrounding whitespace must not reach jj.
  const defaultPath = join(fx.root, 'My Project ws');
  const defaulted = await operations.workspaceAdd(repo, `  ${defaultPath}  `, undefined, [], undefined, undefined);
  assert.equal(defaulted.name, 'My Project ws');
  assert.equal(defaulted.path, realpath(defaultPath));
});

test('operation layer: workspaceAdd drops an empty @ parent so no empty commit enters the new chain', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const fx = makeFixture(t, 'dsh-jj-workspace-at-parent');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  fx.cwd = repo;

  // The old multi-session guidance told the model to pass parents ["@"]; after a
  // commit @ is the fresh empty change, so that put an empty description-less
  // commit into the new workspace's ancestry, which later reached Git history.
  calls.length = 0;
  const tool = definitions.get('jj_workspace_add')!;
  const value = (await tool.execute(
    { path: join(fx.root, 'ws-at-parent'), name: 'at-parent', parents: ['@'] },
    fakeExec(),
  )) as Record<string, unknown>;
  assert.deepEqual(validateJsonSchemaValue(tool.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  assert.match(String(value['note'] ?? ''), /dropped/);
  assert.ok(!calls.some((argv) => argv.includes('workspace') && argv.includes('-r')), 'no -r @ reaches jj');

  const wsPath = fx.path('ws-at-parent');
  const ancestry = await operations.log(wsPath, 'main..@', 5);
  assert.deepEqual(
    ancestry.map((change) => change.empty),
    [true],
    'only the new empty working copy is above main',
  );
  const parent = (await operations.log(wsPath, '@-', 1))[0];
  assert.equal(parent?.description, 'chore: base');
  await writeFixtureFile(fx, wsPath, 'one.txt', 'one');
  await commitWorkingCopy(fx, wsPath, 'feat: one');
  const chain = (await operations.log(wsPath, 'main..@-', 5)).filter((change) => !change.empty);
  assert.deepEqual(
    chain.map((change) => change.description),
    ['feat: one'],
    'the session work sits directly on main with no empty commit in between',
  );
});

test('operation layer: workspaceAdd refuses @ while the working copy still has uncommitted content', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-workspace-at-dirty');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  const { runJj, calls } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  await writeFixtureFile(fx, repo, 'dirty.txt', 'dirty');
  calls.length = 0;
  await assert.rejects(
    () => operations.workspaceAdd(repo, join(fx.root, 'ws-dirty-at'), 'dirty-at', ['@'], undefined, undefined),
    /cannot use the working-copy change @ as a parent/,
    'a non-empty @ would become an undescribed commit in the new workspace chain',
  );
  assert.ok(
    !calls.some((argv) => argv.includes('workspace') && argv.includes('add')),
    'the refusal happens before jj workspace add runs',
  );
  const listed = await operations.workspaceList(repo);
  assert.ok(!listed.some((workspace) => workspace.name === 'dirty-at'), 'no workspace was created');
});

test('jj_workspace_cleanup: a session-created workspace whose name contains spaces is cleaned up end to end', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-cleanup-spaced');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  const moved: string[] = [];
  const workingDirectory = {
    ensure: async () => fx.cwd as string,
    set: async (_agent: unknown, path: string) => {
      moved.push(path);
      return path;
    },
  };
  const definitions = definitionsByName(
    jjToolDefinitions(toolContext(fx, toolService(fx, operations), resolveConfig({}), workingDirectory)),
  );
  const agent = { id: 'spaced-cleanup-agent' };
  fx.cwd = repo;
  const created = (await definitions
    .get('jj_workspace_add')!
    .execute({ path: join(fx.root, 'My Session ws') }, fakeExec(agent))) as {
    readonly name: string;
    readonly path: string;
  };
  assert.equal(created.name, 'My Session ws', 'the default name is the basename, unquoted');
  assert.deepEqual(moved, [created.path], 'jj_workspace_add enters the new workspace by default');
  fx.cwd = created.path;
  const value = (await definitions.get('jj_workspace_cleanup')!.execute({}, fakeExec(agent))) as Record<
    string,
    unknown
  >;
  assert.equal(value['forgotten'], true);
  assert.equal(value['workspaceName'], 'My Session ws');
  assert.deepEqual(moved, [created.path, realpath(repo)], 'cleanup moves the session back to the default workspace');
});

test('operation layer: jj_handoff does not move a bookmark that points at shared history', async (t) => {
  const { fx, repo, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-shared-bookmark');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  // The shared trunk advances while the session works; `main` must stay where it is.
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], repo);
  await writeFixtureFile(fx, repo, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, repo, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const mainBefore = (await mustRun(fx.run, ['jj', 'log', '-r', 'main', '--no-graph', '-T', 'commit_id'], repo)).stdout;

  const result = await operations.handoff(ws, { bookmark: 'main', fetch: false });
  assert.equal(result.rebased, true);
  assert.equal(result.bookmark, undefined, 'a shared bookmark is not moved by a hand-off');
  assert.match(result.bookmarkSkipped ?? '', /outside this workspace's stack/);
  const mainAfter = (await mustRun(fx.run, ['jj', 'log', '-r', 'main', '--no-graph', '-T', 'commit_id'], repo)).stdout;
  assert.equal(mainAfter, mainBefore, 'the shared main bookmark was not moved');
});

test('operation layer: a conflicted bookmark with an absent side lists a real target and is not moved by a hand-off', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, repo, ws, operations } = await makeHandoffFixture(t, 'dsh-jj-handoff-conflicted-bookmark');
  await writeFixtureFile(fx, ws, 'one.txt', 'one');
  await commitWorkingCopy(fx, ws, 'feat: one');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'feature', '-r', '@-'], ws);
  // Two concurrent operations from the same base: one deletes `feature`, the other
  // moves it to main. jj records the conflict as [absent, old tip, main] — the
  // first added side is `null` in json(self) and "(absent)" in `jj bookmark list`.
  const baseOp = (await mustRun(fx.run, ['jj', 'op', 'log', '-n', '1', '--no-graph', '-T', 'id'], repo)).stdout.trim();
  await mustRun(fx.run, ['jj', 'bookmark', 'delete', 'feature'], repo);
  await mustRun(
    fx.run,
    ['jj', '--at-op', baseOp, 'bookmark', 'set', 'feature', '-r', 'main', '--allow-backwards'],
    repo,
  );
  const mainCommit = (await mustRun(fx.run, ['jj', 'log', '-r', 'main', '--no-graph', '-T', 'commit_id'], repo)).stdout;

  const listed = (await operations.bookmarkList(repo, false, undefined)).find(
    (bookmark) => bookmark.name === 'feature' && bookmark.remote === null,
  );
  assert.ok(listed !== undefined, 'the conflicted bookmark is listed');
  assert.equal(listed.conflicted, true);
  assert.notEqual(listed.target, 'null', 'an absent side must never become the literal revset "null"');
  assert.equal(listed.target, mainCommit, 'the first present added side is reported');
  const plain = (await operations.bookmarkList(repo, false, undefined)).find((bookmark) => bookmark.name === 'main');
  assert.equal(plain?.conflicted, false);

  // The tool output carries the flag and still validates against its own schema.
  fx.cwd = repo;
  const tool = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations)))).get(
    'jj_bookmark_list',
  )!;
  const value = (await tool.execute({}, fakeExec())) as { bookmarks: { name: string; conflicted: boolean }[] };
  assert.deepEqual(validateJsonSchemaValue(tool.output.schema, value), [], `output: ${JSON.stringify(value)}`);
  assert.equal(value.bookmarks.find((bookmark) => bookmark.name === 'feature')?.conflicted, true);

  // Make the hand-off rebase-worthy, then request the conflicted bookmark.
  await mustRun(fx.run, ['jj', 'new', 'main', '-m', 'chore: advance'], repo);
  await writeFixtureFile(fx, repo, 'adv.txt', 'advance');
  await commitWorkingCopy(fx, repo, 'chore: advance');
  await mustRun(fx.run, ['jj', 'bookmark', 'set', 'main', '-r', '@-'], repo);
  const result = await operations.handoff(ws, { bookmark: 'feature', fetch: false });
  assert.equal(result.rebased, true, 'the rebase result survives the skipped bookmark');
  assert.equal(result.bookmark, undefined, 'a conflicted bookmark is not resolved by picking a side');
  assert.match(result.bookmarkSkipped ?? '', /is conflicted/);
  const after = (await operations.bookmarkList(repo, false, undefined)).find(
    (bookmark) => bookmark.name === 'feature' && bookmark.remote === null,
  );
  assert.equal(after?.conflicted, true, 'the bookmark is still conflicted after the hand-off');
});

// ---------------------------------------------------------------------------
// Correction folding (amend): rewrite an unpushed target instead of appending.
// Policy: the window stays open until a remote bookmark, trunk or tag reaches
// the change; a local bookmark (even at the tip) does not close it.
// ---------------------------------------------------------------------------

/** Read one change id through the real jj CLI (fixture assertions). */
async function changeIdAt(fx: Fixture, cwd: string, revset: string): Promise<string> {
  const result = await mustRun(
    fx.run,
    ['jj', '--no-pager', '--color=never', 'log', '-r', revset, '--no-graph', '-T', 'json(change_id)'],
    cwd,
  );
  return JSON.parse(result.stdout.trim()) as string;
}

/** Number of changes above jj's root: the whole local stack, including the empty @. */
async function stackSize(fx: Fixture, cwd: string): Promise<number> {
  const result = await mustRun(
    fx.run,
    ['jj', '--no-pager', '--color=never', 'log', '-r', '::@ ~ root()', '--no-graph', '-T', 'json(change_id) ++ "\\n"'],
    cwd,
  );
  return result.stdout.split('\n').filter((line) => line.trim().length > 0).length;
}

/** Three unpushed commits (`one`, `two`, `three`) plus an empty @ on top. */
async function makeAmendFixture(t: Parameters<typeof makeFixture>[0], label: string) {
  const fx = makeFixture(t, label);
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'one.txt', 'one');
  await commitWorkingCopy(fx, repo, 'feat(one): add one');
  await writeFixtureFile(fx, repo, 'two.txt', 'two');
  await commitWorkingCopy(fx, repo, 'feat(two): add two');
  await writeFixtureFile(fx, repo, 'three.txt', 'three');
  await commitWorkingCopy(fx, repo, 'feat(three): add three');
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });
  return {
    fx,
    repo,
    operations,
    one: await changeIdAt(fx, repo, '@---'),
    two: await changeIdAt(fx, repo, '@--'),
    three: await changeIdAt(fx, repo, '@-'),
  };
}

/** Local bare remote wired as `origin`; nothing is pushed by this helper. */
async function addBareRemote(fx: Fixture, repo: string): Promise<string> {
  const remote = join(fx.root, 'remote.git');
  await mustRun(fx.run, ['git', 'init', '--bare', '--quiet', remote], fx.root);
  await mustRun(fx.run, ['jj', 'git', 'remote', 'add', 'origin', remote], repo);
  return remote;
}

test('operation layer: amend folds a working-copy correction into an earlier change', async (t) => {
  const { fx, repo, operations, one, two, three } = await makeAmendFixture(t, 'dsh-jj-amend-basic');
  await writeFixtureFile(fx, repo, 'one.txt', 'one fixed');

  const result = await operations.amend(repo, { into: one });

  assert.equal(result.amended.changeId, one, 'the target change id is stable');
  assert.equal(result.amended.description, 'feat(one): add one', 'the target description is kept');
  assert.equal(result.workingCopy.empty, true, 'the folded working copy is empty');
  assert.deepEqual(
    result.rewritten.map((change) => change.changeId),
    [three, two],
    'the rebased descendants are reported, newest first',
  );
  assert.equal(result.sourceAbandoned, false);
  assert.equal(await stackSize(fx, repo), 4, 'no new commit was appended');
  const shown = await mustRun(fx.run, ['jj', 'file', 'show', '-r', one, 'one.txt'], repo);
  assert.match(shown.stdout, /one fixed/);
});

test('operation layer: amend folds an already-committed correction and abandons it', async (t) => {
  const { fx, repo, operations, one, two, three } = await makeAmendFixture(t, 'dsh-jj-amend-committed');
  await writeFixtureFile(fx, repo, 'one.txt', 'one fixed');
  await commitWorkingCopy(fx, repo, 'fix: fold me into one');
  const correction = await changeIdAt(fx, repo, '@-');
  assert.equal(await stackSize(fx, repo), 5, 'four commits plus the empty @');

  const result = await operations.amend(repo, { from: correction, into: one });

  assert.equal(result.amended.changeId, one);
  assert.equal(result.sourceAbandoned, true, 'the emptied correction commit is abandoned');
  assert.deepEqual(
    result.rewritten.map((change) => change.changeId),
    [three, two],
  );
  assert.equal(await stackSize(fx, repo), 4, 'the correction commit is gone');
  const shown = await mustRun(fx.run, ['jj', 'file', 'show', '-r', one, 'one.txt'], repo);
  assert.match(shown.stdout, /one fixed/);
});

test('operation layer: amend with paths folds only the given files', async (t) => {
  const { fx, repo, operations, one } = await makeAmendFixture(t, 'dsh-jj-amend-paths');
  await writeFixtureFile(fx, repo, 'one.txt', 'one fixed');
  await writeFixtureFile(fx, repo, 'extra.txt', 'extra');

  const result = await operations.amend(repo, { into: one, paths: ['one.txt'] });

  assert.equal(result.workingCopy.empty, false, 'the unrelated change stays in the working copy');
  assert.ok(result.warnings.some((warning) => /remaining working-copy changes/.test(warning)));
  const target = await mustRun(fx.run, ['jj', 'file', 'show', '-r', one, 'one.txt'], repo);
  assert.match(target.stdout, /one fixed/);
  const workingCopyFiles = await mustRun(
    fx.run,
    ['jj', 'log', '-r', '@', '--no-graph', '-T', 'json(self.diff().files().map(|f| f.path()))'],
    repo,
  );
  assert.match(workingCopyFiles.stdout, /extra\.txt/);
  assert.doesNotMatch(workingCopyFiles.stdout, /one\.txt/);
});

test('operation layer: amend rewrites the target description only when message is passed', async (t) => {
  const { fx, repo, operations, two } = await makeAmendFixture(t, 'dsh-jj-amend-message');
  await writeFixtureFile(fx, repo, 'two.txt', 'two fixed');

  const result = await operations.amend(repo, { into: two, message: 'feat(two): add two, corrected' });

  assert.equal(result.amended.description, 'feat(two): add two, corrected');
  assert.equal(result.amended.changeId, two);
});

test('operation layer: amend refuses a published target (trunk push) without rewriting anything', async (t) => {
  const { fx, repo, operations, one } = await makeAmendFixture(t, 'dsh-jj-amend-trunk');
  await addBareRemote(fx, repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'main', '-r', '@-'], repo);
  await mustRun(fx.run, ['jj', 'git', 'push', '--bookmark', 'main'], repo);
  await mustRun(fx.run, ['jj', 'git', 'fetch'], repo);
  await writeFixtureFile(fx, repo, 'one.txt', 'one fixed');

  await assert.rejects(
    () => operations.amend(repo, { into: one }),
    (error: unknown) =>
      error instanceof JjError && error.code === 'JJ_BAD_INPUT' && /published change/.test(error.message),
  );
  const target = await mustRun(fx.run, ['jj', 'file', 'show', '-r', one, 'one.txt'], repo);
  assert.match(target.stdout, /^one$/m, 'the published target was not rewritten');
});

test('operation layer: amend refuses a pushed tracked bookmark even though jj still calls it mutable', async (t) => {
  const { fx, repo, operations, three } = await makeAmendFixture(t, 'dsh-jj-amend-remote-bookmark');
  await addBareRemote(fx, repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'feat', '-r', three], repo);
  await mustRun(fx.run, ['jj', 'git', 'push', '--bookmark', 'feat'], repo);
  await mustRun(fx.run, ['jj', 'git', 'fetch'], repo);
  const target = await operations.log(repo, three, 1);
  assert.equal(target[0]?.immutable, false, 'tracked bookmarks stay outside the default immutable_heads()');
  assert.deepEqual([...(target[0]?.remoteBookmarks ?? [])], ['feat']);
  await writeFixtureFile(fx, repo, 'three.txt', 'three fixed');

  await assert.rejects(
    () => operations.amend(repo, { into: three }),
    (error: unknown) =>
      error instanceof JjError && error.code === 'JJ_BAD_INPUT' && /remote bookmark/.test(error.message),
  );
});

test('operation layer: amend rejects a target outside the stack, an empty source, and a merge target', async (t) => {
  const { fx, repo, operations, two, three } = await makeAmendFixture(t, 'dsh-jj-amend-invalid');
  await assert.rejects(
    () => operations.amend(repo, { into: three, from: two }),
    (error: unknown) => error instanceof JjError && /not an ancestor/.test(error.message),
  );
  await assert.rejects(
    () => operations.amend(repo, { into: two }),
    (error: unknown) => error instanceof JjError && /nothing to fold/.test(error.message),
  );

  await mustRun(fx.run, ['jj', 'new', two, three, '-m', 'merge: combine'], repo);
  await mustRun(fx.run, ['jj', 'new'], repo);
  const merge = await changeIdAt(fx, repo, '@-');
  await writeFixtureFile(fx, repo, 'one.txt', 'one more');
  await assert.rejects(
    () => operations.amend(repo, { into: merge }),
    (error: unknown) => error instanceof JjError && /merge commit/.test(error.message),
  );
});

test('operation layer: amend refuses a conflicted source', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-amend-conflict');
  await assertToolchain(fx.run, fx.root);
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  await writeFixtureFile(fx, repo, 'f.txt', 'base');
  await commitWorkingCopy(fx, repo, 'chore: base');
  const base = await changeIdAt(fx, repo, '@-');
  await mustRun(fx.run, ['jj', 'new', base], repo);
  await writeFixtureFile(fx, repo, 'f.txt', 'left');
  await commitWorkingCopy(fx, repo, 'feat: left');
  const left = await changeIdAt(fx, repo, '@-');
  await mustRun(fx.run, ['jj', 'new', base], repo);
  await writeFixtureFile(fx, repo, 'f.txt', 'right');
  await commitWorkingCopy(fx, repo, 'feat: right');
  const right = await changeIdAt(fx, repo, '@-');
  await mustRun(fx.run, ['jj', 'new', left, right], repo);
  const { runJj } = recordingRunner(fx);
  const operations = new JjOperations({ runJj, config: {} });

  await assert.rejects(
    () => operations.amend(repo, { into: left }),
    (error: unknown) => error instanceof JjError && /has conflicts/.test(error.message),
  );
});

test('operation layer: jj_squash moves only the given paths and reports published targets', async (t) => {
  const { fx, repo, operations, three } = await makeAmendFixture(t, 'dsh-jj-squash-paths');
  await writeFixtureFile(fx, repo, 'three.txt', 'three fixed');
  await writeFixtureFile(fx, repo, 'extra.txt', 'extra');

  const workingCopy = await operations.squash(repo, '@', three, undefined, true, ['three.txt']);
  assert.equal(workingCopy.empty, false, 'the unrelated change stays in @');
  const target = await mustRun(fx.run, ['jj', 'file', 'show', '-r', three, 'three.txt'], repo);
  assert.match(target.stdout, /three fixed/);

  await addBareRemote(fx, repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'main', '-r', three], repo);
  await mustRun(fx.run, ['jj', 'git', 'push', '--bookmark', 'main'], repo);
  await mustRun(fx.run, ['jj', 'git', 'fetch'], repo);
  await writeFixtureFile(fx, repo, 'three.txt', 'three fixed again');
  await assert.rejects(
    () => operations.squash(repo, '@', three, undefined, true, []),
    (error: unknown) =>
      error instanceof JjError && error.code === 'JJ_BAD_INPUT' && /published change/.test(error.message),
  );
});

test('jj_amend tool folds the correction, reports descendants, and validates its own output schema', async (t) => {
  const { fx, repo, operations, one, two, three } = await makeAmendFixture(t, 'dsh-jj-tool-amend');
  fx.cwd = repo;
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  await writeFixtureFile(fx, repo, 'one.txt', 'one fixed');

  const value = (await definitions.get('jj_amend')!.execute({ into: one }, fakeExec())) as {
    readonly amended: { readonly changeId: string; readonly rewritable: boolean };
    readonly workingCopy: { readonly empty: boolean };
    readonly sourceAbandoned: boolean;
    readonly rewritten: readonly { readonly changeId: string; readonly conflict: boolean }[];
    readonly warnings: readonly string[];
    readonly nextActions: readonly { readonly tool: string; readonly reason: string }[];
  };
  assert.equal(value.amended.changeId, one);
  assert.equal(value.sourceAbandoned, false);
  assert.deepEqual(
    value.rewritten.map((change) => change.changeId),
    [three, two],
  );
  assert.equal(value.workingCopy.empty, true);
  assert.ok(
    value.nextActions.some((action) => action.tool === 'jj_log'),
    'a clean fold recommends confirming the rewritten stack',
  );

  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  assert.deepEqual(
    validateJsonSchemaValue(definitions.get('jj_amend')!.output.schema, value),
    [],
    'the jj_amend output satisfies its own schema',
  );

  // Published targets fail closed through the tool as well.
  await addBareRemote(fx, repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'main', '-r', three], repo);
  await mustRun(fx.run, ['jj', 'git', 'push', '--bookmark', 'main'], repo);
  await mustRun(fx.run, ['jj', 'git', 'fetch'], repo);
  await writeFixtureFile(fx, repo, 'two.txt', 'two fixed');
  await assert.rejects(
    () => definitions.get('jj_amend')!.execute({ into: two }, fakeExec()),
    (error: unknown) => error instanceof JjError && /published change/.test(error.message),
  );
});

test('operation layer: squash refuses a published rewrite range before any rewrite', async (t) => {
  const { fx, repo, operations, one } = await makeAmendFixture(t, 'dsh-jj-squash-published');
  await addBareRemote(fx, repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'main', '-r', one], repo);
  await mustRun(fx.run, ['jj', 'git', 'push', '--bookmark', 'main'], repo);
  await mustRun(fx.run, ['jj', 'git', 'fetch'], repo);
  await writeFixtureFile(fx, repo, 'one.txt', 'one squashed');

  await assert.rejects(
    () => operations.squash(repo, '@', one, 'squash into published', false, []),
    (error: unknown) =>
      error instanceof JjError && error.code === 'JJ_BAD_INPUT' && /published change/.test(error.message),
  );
  const target = await mustRun(fx.run, ['jj', 'file', 'show', '-r', one, 'one.txt'], repo);
  assert.match(target.stdout, /^one$/m, 'the published target was not rewritten');
});

test('operation layer: abandon drops a change and rebases its descendants', async (t) => {
  const { fx, repo, operations, one, two, three } = await makeAmendFixture(t, 'dsh-jj-abandon-basic');
  const result = await operations.abandon(repo, two);
  assert.equal(result.abandoned.length, 1);
  assert.equal(result.abandoned[0]?.changeId, two);
  assert.match(result.message, /Abandoned/);

  const remaining = await mustRun(fx.run, ['jj', 'log', '-r', '::@', '--no-graph', '-T', 'change_id ++ "\n"'], repo);
  const ids = remaining.stdout.split('\n').map((line) => line.trim());
  assert.ok(!ids.includes(two), 'the abandoned change left the graph');
  assert.ok(ids.includes(one) && ids.includes(three), 'ancestors and descendants keep their change ids');

  const parents = await mustRun(
    fx.run,
    ['jj', 'log', '-r', `${three}-`, '--no-graph', '-T', 'change_id ++ "\n"'],
    repo,
  );
  assert.equal(parents.stdout.trim(), one, 'the descendant was rebased onto the abandoned change parent');
});

test('operation layer: abandon refuses @ and published changes', async (t) => {
  const { fx, repo, operations, one } = await makeAmendFixture(t, 'dsh-jj-abandon-refusals');
  await assert.rejects(
    () => operations.abandon(repo, '@'),
    (error: unknown) => error instanceof JjError && /refuses to abandon the working-copy change/.test(error.message),
  );
  await assert.rejects(
    () => operations.abandon(repo, '   '),
    (error: unknown) => error instanceof JjError && /needs an explicit revset/.test(error.message),
  );
  await assert.rejects(
    () => operations.abandon(repo, 'description(nonexistent-subject)'),
    (error: unknown) => error instanceof JjError && /found no revision/.test(error.message),
  );

  await addBareRemote(fx, repo);
  await mustRun(fx.run, ['jj', 'bookmark', 'create', 'main', '-r', one], repo);
  await mustRun(fx.run, ['jj', 'git', 'push', '--bookmark', 'main'], repo);
  await mustRun(fx.run, ['jj', 'git', 'fetch'], repo);
  await assert.rejects(
    () => operations.abandon(repo, one),
    (error: unknown) => error instanceof JjError && /is published/.test(error.message),
  );
  const stillThere = await mustRun(fx.run, ['jj', 'log', '-r', one, '--no-graph', '-T', 'change_id'], repo);
  assert.equal(stillThere.stdout.trim(), one, 'the published change was not abandoned');
});

test('jj_abandon tool validates its own output schema and renders text', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, repo, operations, two } = await makeAmendFixture(t, 'dsh-jj-abandon-tool');
  fx.cwd = repo;
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  const definition = definitions.get('jj_abandon')!;
  const value = (await definition.execute({ revset: two }, fakeExec())) as Record<string, unknown>;
  const violations = validateJsonSchemaValue(definition.output.schema as JsonSchemaNode, value);
  assert.deepEqual(violations, [], 'abandon output satisfies its schema');
  const rendered = definition.output.render({ revset: two }, value as never);
  const first = rendered[0];
  assert.ok(first !== undefined && first.type === 'text' && first.text.length > 0);
});

test('jj_op_restore restores to the head operation and reports it', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-op-restore');
  const head = await operations.headOperationId(repo);
  fx.cwd = repo;
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  const definition = definitions.get('jj_op_restore')!;
  const value = (await definition.execute({ operationId: head }, fakeExec())) as Record<string, unknown>;
  assert.deepEqual(
    validateJsonSchemaValue(definition.output.schema as JsonSchemaNode, value),
    [],
    'restore output satisfies its schema',
  );
  assert.equal(value.operationId, head);
  assert.match(String(value.message), /head operation before this call/);
});

test('jj_fetch reports a local-only repository as no-remote instead of failing', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-fetch-tool');
  fx.cwd = repo;
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  const value = (await definitions.get('jj_fetch')!.execute({}, fakeExec())) as Record<string, unknown>;
  assert.equal(value.status, 'no-remote');
  assert.match(String(value.message), /no git remote/i);
});

test('jj_workspace_update_stale is a no-op on a fresh workspace and returns @', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-update-stale');
  fx.cwd = repo;
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  const value = (await definitions.get('jj_workspace_update_stale')!.execute({}, fakeExec())) as Record<
    string,
    unknown
  > & { change: Record<string, unknown> };
  assert.equal(typeof value.message, 'string');
  assert.equal(typeof value.change.changeId, 'string');
  assert.equal(value.change.currentWorkingCopy, true);
});

test('operation layer: workspaceStates lists every workspace with its @ change in one call', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-workspace-states');
  const created = await operations.workspaceAdd(repo, join(fx.root, 'ws-state'), 'state-ws', [], undefined, undefined);
  const states = await operations.workspaceStates(repo);
  assert.equal(states.length, 2, 'both workspaces are listed');
  const current = states.find((state) => state.current);
  const other = states.find((state) => !state.current);
  assert.ok(current !== undefined && other !== undefined, 'exactly one workspace is current');
  assert.equal(current.name, 'default');
  assert.equal(current.stale, 'no', 'a readable current working copy is fresh');
  assert.deepEqual([...current.changeId], [...(await operations.readAt(repo)).changeId]);
  assert.equal(other.name, 'state-ws');
  assert.equal(other.changeId.length > 0, true, 'the sibling reports its own @ change');
  assert.equal(other.stale, 'unknown', 'sibling staleness needs a snapshot, so it is not claimed');
  assert.equal(other.empty, true);
  assert.equal(created.name, 'state-ws');
});

test('jj_workspace_list detail full validates its output schema', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-workspace-list-full');
  fx.cwd = repo;
  await operations.workspaceAdd(repo, join(fx.root, 'ws-full'), 'full-ws', [], undefined, undefined);
  const definitions = definitionsByName(jjToolDefinitions(toolContext(fx, toolService(fx, operations))));
  const definition = definitions.get('jj_workspace_list')!;
  const value = (await definition.execute({ detail: 'full' }, fakeExec())) as {
    workspaces: Array<Record<string, unknown>>;
    currentWorkspace: string;
  };
  assert.deepEqual(
    validateJsonSchemaValue(definition.output.schema as JsonSchemaNode, value),
    [],
    'full listing satisfies its schema',
  );
  assert.equal(value.currentWorkspace, 'default');
  assert.equal(value.workspaces.length, 2);
  for (const workspace of value.workspaces) {
    assert.equal(typeof workspace.changeId, 'string');
    assert.equal(typeof workspace.empty, 'boolean');
    assert.equal(typeof workspace.stale, 'string');
  }
});

test('jj_workspace_add moves the session into the new workspace by default', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-workspace-add-enters');
  fx.cwd = repo;
  const switches: string[] = [];
  const context = toolContext(fx, toolService(fx, operations), resolveConfig({}), {
    ensure: async () => repo,
    set: async (_agent, path) => {
      switches.push(path);
      return path;
    },
  });
  const definitions = definitionsByName(jjToolDefinitions(context));
  const target = join(fx.root, 'ws-enter');
  const agent = { id: 'add-enter-agent' };
  const value = (await definitions
    .get('jj_workspace_add')!
    .execute({ path: target, name: 'entered' }, fakeExec(agent))) as {
    entered: boolean;
    path: string;
  };
  assert.equal(value.entered, true, 'the session is moved into the workspace');
  assert.deepEqual(switches, [value.path], 'exactly one working-directory switch happens');
});

test('jj_workspace_add can create without switching when enter is false', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-workspace-add-no-enter');
  fx.cwd = repo;
  const switches: string[] = [];
  const context = toolContext(fx, toolService(fx, operations), resolveConfig({}), {
    ensure: async () => repo,
    set: async (_agent, path) => {
      switches.push(path);
      return path;
    },
  });
  const definitions = definitionsByName(jjToolDefinitions(context));
  const value = (await definitions
    .get('jj_workspace_add')!
    .execute(
      { path: join(fx.root, 'ws-no-enter'), name: 'no-enter', enter: false },
      fakeExec({ id: 'no-enter-agent' }),
    )) as { entered: boolean };
  assert.equal(value.entered, false);
  assert.deepEqual(switches, [], 'the session stays where it was');
});

test('jj_workspace_enter switches into an existing workspace and validates its output', async (t) => {
  const { validateJsonSchemaValue } = await import('@deepseek-ai/dsh-tools');
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-workspace-enter');
  fx.cwd = repo;
  const created = await operations.workspaceAdd(
    repo,
    join(fx.root, 'ws-target'),
    'target-ws',
    [],
    undefined,
    undefined,
  );
  const switches: string[] = [];
  const context = toolContext(fx, toolService(fx, operations), resolveConfig({}), {
    ensure: async () => repo,
    set: async (_agent, path) => {
      switches.push(path);
      return path;
    },
  });
  const definition = definitionsByName(jjToolDefinitions(context)).get('jj_workspace_enter')!;
  const agent = { id: 'enter-agent' };
  const value = (await definition.execute({ workspace: 'target-ws' }, fakeExec(agent))) as Record<string, unknown>;
  assert.deepEqual(
    validateJsonSchemaValue(definition.output.schema as JsonSchemaNode, value),
    [],
    'enter output satisfies its schema',
  );
  assert.equal(value.alreadyCurrent, false);
  assert.equal(value.workspaceName, 'target-ws');
  assert.deepEqual(switches, [created.path], 'the session moved to the workspace root');

  // Entering the current workspace is a no-op that reports it.
  const current = (await definition.execute({ workspace: 'default' }, fakeExec(agent))) as Record<string, unknown>;
  assert.equal(current.alreadyCurrent, true);
  assert.equal(switches.length, 1);

  await assert.rejects(
    () => definition.execute({ workspace: 'no-such-workspace' }, fakeExec()),
    /found no workspace named or located at/,
  );
});

test('sandboxPolicy read-only: read tools never snapshot dirty working copies and mutating tools require approval', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-sandbox-readonly');
  const roSibling = await operations.workspaceAdd(repo, join(fx.root, 'ro-ws'), 'ro-ws', [], undefined, undefined);
  // Leave an unsnapshotted edit in the default workspace so any read without
  // `--ignore-working-copy` would append a snapshot operation to `op log`.
  await writeFixtureFile(fx, repo, 'dirty-readonly.txt', 'unsnapshotted\n');
  const opsBefore = (await operations.opLog(repo, 20)).map((op) => op.id);

  let currentCwd = repo;
  let approvalMode: 'absent' | 'rejected' | 'allowed-once' = 'absent';
  const approvalCalls: Array<{ toolName: string; reason?: string }> = [];

  const ctx = new Context();
  ctx.provide('systemPrompt', {
    tools: () => () => {},
    section: () => () => {},
    context: () => {},
    getContextOrder: () => 0,
  });
  ctx.provide('jj', toolService(fx, operations));
  ctx.provide('workingDirectory', {
    ensure: async () => currentCwd,
    get: () => currentCwd,
    set: async (_agent: unknown, path: string) => {
      currentCwd = path;
      return path;
    },
  });
  ctx.provide('sandboxPolicy', {
    resolve: () => ({ mode: 'read-only', workspaceRoot: repo }),
  });
  new ToolRuntime(ctx);
  applyTools(ctx, {});

  const agent = { id: 'ro-agent', session: { id: 'ro-session', header: { cwd: repo } } };
  let nextSeq = 1;
  const runTool = async (name: string, args: Record<string, unknown> = {}) => {
    const callId = `ro-call-${nextSeq}` as Parameters<ToolRuntime['execute']>[0]['callId'];
    nextSeq += 1;
    return await ctx.tools.execute({
      callId,
      name,
      arguments: args,
      agent: agent as never,
      signal: new AbortController().signal,
    });
  };

  // All 7 read tools + jj_workspace_enter succeed with zero approvals and zero new op-log entries.
  for (const [name, args] of [
    ['jj_status', {}],
    ['jj_status', { details: true }],
    ['jj_log', { revset: '@ | @-' }],
    ['jj_diff', { format: 'stat' }],
    ['jj_commit_style', {}],
    ['jj_op_log', { limit: 5 }],
    ['jj_bookmark_list', {}],
    ['jj_workspace_list', { detail: 'basic' }],
    ['jj_workspace_list', { detail: 'full' }],
    ['jj_workspace_enter', { workspace: 'ro-ws' }],
    ['jj_workspace_enter', { workspace: 'default' }],
  ] as const) {
    const outcome = await runTool(name, args);
    assert.equal(outcome.isError, false, `${name} should succeed in read-only mode`);
  }
  assert.equal(currentCwd, repo);
  assert.equal(roSibling.name, 'ro-ws');
  const opsAfterReads = (await operations.opLog(repo, 20)).map((op) => op.id);
  assert.deepEqual(opsAfterReads, opsBefore, 'read-only tools must not create working-copy snapshot operations');

  // Without ApprovalService mounted, mutating tools fail closed via PreToolDecision `ask` -> `deny`.
  const deniedCommit = await runTool('jj_commit', { message: 'feat: blocked in read-only' });
  assert.equal(deniedCommit.isError, true);
  assert.match(JSON.stringify(deniedCommit.content), /read-only/);
  assert.deepEqual(
    (await operations.opLog(repo, 20)).map((op) => op.id),
    opsBefore,
    'denied jj_commit never ran jj',
  );

  // Mount ApprovalService: rejected calls prompt once and abort; allowed-once calls prompt once and run.
  ctx.provide('approval', {
    request: async (req: { toolName: string; reason?: string }) => {
      approvalCalls.push({ toolName: req.toolName, ...(req.reason !== undefined ? { reason: req.reason } : {}) });
      return approvalMode === 'allowed-once' ? 'allowed-once' : 'rejected';
    },
  });

  approvalMode = 'rejected';
  const rejectedUndo = await runTool('jj_undo', {});
  assert.equal(rejectedUndo.isError, true);
  assert.match(JSON.stringify(rejectedUndo.content), /rejected/);
  assert.equal(approvalCalls.length, 1, 'prompted once through ToolRuntime without double-prompting in execute');
  assert.equal(approvalCalls[0]?.toolName, 'jj_undo');

  approvalMode = 'allowed-once';
  const allowedCommit = await runTool('jj_commit', { message: 'feat: user approved in read-only' });
  assert.equal(allowedCommit.isError, false, 'approved mutation runs cleanly');
  assert.equal(approvalCalls.length, 2, 'prompted once for jj_commit');
});

test('sandboxPolicy workspace-write: os.tmpdir() isolation needs zero prompts while external paths require approval', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-sandbox-wswrite');
  await operations.bookmarkSet(repo, 'main', '@-', false);
  const scopedTmp = fx.path('scoped-tmp');
  // Place `externalParent` outside `/tmp` as well as `scopedTmp` (on Linux `fx` lives under `/tmp`,
  // which is always in `workspace-write` writable roots).
  const nonTmpParent = existsSync('/var/tmp') ? '/var/tmp' : homedir();
  const externalParent = mkdtempSync(join(nonTmpParent, 'dsh-jj-sandbox-ext-'));
  t.after(() => rmSync(externalParent, { recursive: true, force: true }));
  const plainGitDir = join(externalParent, 'plain-git');
  mkdirSync(plainGitDir, { recursive: true });
  const plainGit = await initGit(fx.run, plainGitDir);
  mkdirSync(scopedTmp, { recursive: true });

  const previousTmp = process.env.TMPDIR;
  process.env.TMPDIR = scopedTmp;
  t.after(() => {
    if (previousTmp === undefined) delete process.env.TMPDIR;
    else process.env.TMPDIR = previousTmp;
  });

  let currentCwd = repo;
  let approvalOutcome: 'allowed-once' | 'rejected' = 'rejected';
  const approvalCalls: string[] = [];

  const ctx = new Context();
  ctx.provide('systemPrompt', {
    tools: () => () => {},
    section: () => () => {},
    context: () => {},
    getContextOrder: () => 0,
  });
  ctx.provide('jj', toolService(fx, operations));
  ctx.provide('workingDirectory', {
    ensure: async () => currentCwd,
    get: () => currentCwd,
    set: async (_agent: unknown, path: string) => {
      currentCwd = path;
      return path;
    },
  });
  ctx.provide('sandboxPolicy', {
    resolve: () => ({ mode: 'workspace-write', workspaceRoot: repo }),
  });
  ctx.provide('approval', {
    request: async (req: { toolName: string }) => {
      approvalCalls.push(req.toolName);
      return approvalOutcome;
    },
  });
  new ToolRuntime(ctx);
  applyTools(ctx, {});

  const agent = { id: 'ws-agent', session: { id: 'ws-session', header: { cwd: repo } } };
  let nextSeq = 1;
  const runTool = async (name: string, args: Record<string, unknown> = {}) => {
    const callId = `ws-call-${nextSeq}` as Parameters<ToolRuntime['execute']>[0]['callId'];
    nextSeq += 1;
    return await ctx.tools.execute({
      callId,
      name,
      arguments: args,
      agent: agent as never,
      signal: new AbortController().signal,
    });
  };

  // 1. Full multi-session lifecycle inside os.tmpdir() (`scopedTmp`): ZERO approval prompts!
  const tmpWsPath = join(scopedTmp, 'repo-session-a');
  const addTmp = await runTool('jj_workspace_add', { path: tmpWsPath, name: 'session-a' });
  assert.equal(addTmp.isError, false);
  assert.equal(approvalCalls.length, 0, 'os.tmpdir() workspace creation needs zero approvals');
  assert.doesNotMatch(JSON.stringify(addTmp.content), /outside the workspace-write sandbox root/);

  await writeFixtureFile(fx, currentCwd, 'isolated.txt', 'isolated work\n');
  const commitTmp = await runTool('jj_commit', { message: 'feat: isolated commit' });
  assert.equal(commitTmp.isError, false);
  const handoffTmp = await runTool('jj_handoff', { destination: 'main', fetch: false });
  assert.equal(handoffTmp.isError, false);
  const cleanupTmp = await runTool('jj_workspace_cleanup', {});
  assert.equal(cleanupTmp.isError, false);
  assert.equal(realpath(currentCwd), realpath(repo));
  assert.equal(approvalCalls.length, 0, 'entire tmp workspace lifecycle completed with zero approvals');

  // 2. External sibling directory (`externalParent`): asks approval before creating or entering!
  const externalWsPath = join(externalParent, 'repo-external');
  approvalOutcome = 'rejected';
  const rejectedExternal = await runTool('jj_workspace_add', { path: externalWsPath, name: 'ext-ws' });
  assert.equal(rejectedExternal.isError, true);
  assert.equal(existsSync(externalWsPath), false, 'rejected external workspace was never created on disk');
  assert.deepEqual(approvalCalls, ['jj_workspace_add']);

  approvalOutcome = 'allowed-once';
  const approvedExternal = await runTool('jj_workspace_add', { path: externalWsPath, name: 'ext-ws' });
  assert.equal(approvedExternal.isError, false);
  assert.deepEqual(approvalCalls, ['jj_workspace_add', 'jj_workspace_add']);
  assert.match(
    JSON.stringify(approvedExternal.content),
    /outside the workspace-write sandbox root/,
    'approved external workspace surfaces a model-visible boundary note',
  );

  // Switch back to repo (`workspaceRoot`: allowed without prompt), then re-enter `ext-ws` (outside: prompts!).
  const enterRepo = await runTool('jj_workspace_enter', { workspace: 'default' });
  assert.equal(enterRepo.isError, false);
  assert.equal(approvalCalls.length, 2, 'entering default inside workspaceRoot needs no prompt');

  approvalOutcome = 'rejected';
  const enterExternalRejected = await runTool('jj_workspace_enter', { workspace: 'ext-ws' });
  assert.equal(enterExternalRejected.isError, true);
  assert.equal(approvalCalls.length, 3, 'entering external workspace prompts in workspace-write mode');
  assert.equal(realpath(currentCwd), realpath(repo));

  // 3. Plain Git directory outside workspaceRoot still surfaces jjRefusalText without a spurious prompt.
  currentCwd = plainGit;
  const plainGitCall = await runTool('jj_commit', { message: 'feat: wrong vcs' });
  assert.equal(plainGitCall.isError, true);
  assert.equal(approvalCalls.length, 3, 'non-jj directory fails in requireWorkspace without prompting');
  assert.match(JSON.stringify(plainGitCall.content), /No Jujutsu \(jj\) workspace was found/);
});

test('direct ToolDefinition.execute fallback enforces sandbox approval when tools/pre-execute is absent', async (t) => {
  const { fx, repo, operations } = await makeAmendFixture(t, 'dsh-jj-direct-sandbox-gate');
  fx.cwd = repo;
  let outcome: 'rejected' | 'cancelled' | 'allowed-once' = 'rejected';
  let prompted = 0;
  const service = toolService(fx, operations);
  const definitions = definitionsByName(
    jjToolDefinitions({
      service,
      config: resolveConfig({}),
      host: {
        tools: { register: () => () => {} },
        sandboxPolicy: { resolve: () => ({ mode: 'read-only', workspaceRoot: repo }) },
        approval: {
          request: async () => {
            prompted += 1;
            return outcome;
          },
        },
      },
      cwdFor: async () => repo,
    }),
  );
  const describeDef = definitions.get('jj_describe')!;
  await assert.rejects(() => describeDef.execute({ message: 'x' }, fakeExec()), /no agent to route it through/);
  assert.equal(prompted, 0);

  await assert.rejects(
    () => describeDef.execute({ message: 'x' }, fakeExec({ id: 'direct-agent' })),
    /the user rejected tool "jj_describe"/,
  );
  assert.equal(prompted, 1);

  outcome = 'cancelled';
  await assert.rejects(
    () => describeDef.execute({ message: 'x' }, fakeExec({ id: 'direct-agent' })),
    /approval for tool "jj_describe" was cancelled/,
  );
  assert.equal(prompted, 2);

  outcome = 'allowed-once';
  const result = (await describeDef.execute(
    { message: 'feat: direct approved' },
    fakeExec({ id: 'direct-agent' }),
  )) as { description: string };
  assert.equal(result.description, 'feat: direct approved');
  assert.equal(prompted, 3);

  // Stale-recovery never spawns `workspace update-stale` for read tools in read-only mode.
  const staleArgvs: string[][] = [];
  const staleOps = new JjOperations({
    runJj: async (opts) => {
      staleArgvs.push([...opts.argv]);
      return {
        exitCode: 1,
        signal: null,
        stdout: '',
        stderr: 'Error: The working copy is stale (not updated since operation abc); run `jj workspace update-stale`',
        truncated: false,
        killedByTimeout: false,
      };
    },
  });
  const roDefs = definitionsByName(
    jjToolDefinitions({
      service: {
        operations: staleOps,
        workspaceOwnership: new WorkspaceOwnership(),
        detect: (cwd, sig) => detectVcs(cwd, fx.run, sig),
      },
      config: resolveConfig({}),
      host: {
        tools: { register: () => () => {} },
        sandboxPolicy: { resolve: () => ({ mode: 'read-only', workspaceRoot: repo }) },
      },
      cwdFor: async () => repo,
    }),
  );
  await assert.rejects(() => roDefs.get('jj_status')!.execute({}, fakeExec({ id: 'ro-stale' })), /stale/i);
  assert.equal(
    staleArgvs.some((argv) => argv.includes('update-stale')),
    false,
    'read-only read tools must never run workspace update-stale',
  );
});
