/**
 * Build and loadability evidence.
 *
 * `tsc -p tsconfig.json` must produce `lib/*.js` plus `lib/types/*.d.ts`, the
 * three entry points must import under plain Node with `name`/`inject`/`apply`/
 * `Config`, and the built guard must still refuse a mutating Git command inside a
 * real jj workspace.
 */
import { test } from 'vite-plus/test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync, readFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { Script, createContext } from 'node:vm';
import { ROW_CONFIG_KEYS } from '../src/config.ts';
import { sniffVcsSync } from '../src/detect.ts';
import { SESSION_HEARTBEAT_DIR, sessionHeartbeatPath, writeSessionHeartbeat } from '../src/session-heartbeat.ts';
import { createGuardContext, initJjColocated, makeFixture, mustRun } from './helpers/fixtures.ts';

const packageDir = dirname(dirname(fileURLToPath(import.meta.url)));
const execFileAsync = promisify(execFile);

/** Structural view of the `ctx.jj` service the runtime entry must register. */
interface BuiltJjService {
  readonly peek: unknown;
  readonly warm: unknown;
  readonly operations: Record<string, unknown>;
  describe(kind: string): string;
}

/**
 * Compiler the build test must use.
 *
 * Prefer the workspace-local `tsc` so a direct `vp test test/build.test.ts`
 * produces the same emit as `vp run test`/CI (a different global compiler preserves
 * different string quotes and would make the committed lib/ look stale).
 */
function tscCommand(): string {
  const local = join(packageDir, 'node_modules', '.bin', 'tsc');
  return existsSync(local) ? local : 'tsc';
}

/** Hand-written source modules (`src/<name>.ts`), derived from disk instead of a hardcoded list. */
function sourceModuleNames(): string[] {
  return readdirSync(join(packageDir, 'src'))
    .filter((entry) => entry.endsWith('.ts'))
    .map((entry) => entry.slice(0, -'.ts'.length))
    .sort();
}

/**
 * Modules that must stay free of DSH runtime imports (AGENTS.md rule 3).
 *
 * `build.test.ts` asserts this list still matches the source tree and that the
 * compiled output only imports DSH packages with a declared runtime dependency.
 */
const PURE_MODULES = [
  'detect',
  'git-command',
  'git-tokenize',
  'git-equivalence',
  'git-rules',
  'jj-rules',
  'jj-templates',
  'policies',
  'panel-host',
  'session-heartbeat',
  'workspace-registry',
  'types',
  'commit-style',
  'multi-session',
  'changes-types',
  'changes-paths',
  'changes-diff',
  'changes-jj',
  'changes-recorder',
  'changes-service',
] as const;

/** Manifest fields the packaging and toolchain guards inspect. */
interface PackageManifest {
  readonly main?: string;
  readonly types?: string;
  readonly exports?: Readonly<Record<string, unknown>>;
  readonly files?: readonly string[];
  readonly peerDependencies?: Readonly<Record<string, string>>;
  readonly devDependencies?: Readonly<Record<string, string>>;
  readonly scripts?: Readonly<Record<string, string>>;
  readonly packageManager?: string;
}

/** Read and parse the package manifest. */
function readPackageManifest(): PackageManifest {
  return JSON.parse(readFileSync(join(packageDir, 'package.json'), 'utf8')) as PackageManifest;
}

/**
 * Read a tsconfig-style JSON file that carries `//` comments.
 *
 * Only whole-line comments are stripped: every comment in this repository's
 * tsconfigs starts its own line and none appears inside a string value.
 */
function readJsonWithComments(relativePath: string): unknown {
  const text = readFileSync(join(packageDir, relativePath), 'utf8').replace(/^\s*\/\/.*$/gm, '');
  return JSON.parse(text) as unknown;
}

/** Every hand-written TypeScript test source under `test/`, recursively. */
function testSourceFiles(): string[] {
  const files: string[] = [];
  const walk = (directory: string): void => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const full = join(directory, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.endsWith('.ts')) files.push(full);
    }
  };
  walk(join(packageDir, 'test'));
  return files.sort();
}

/** Strip the leading `./` from a `package.json` path target. */
function packageTargetPath(target: string): string {
  return target.replace(/^\.\//, '');
}

/**
 * Assert one `exports` target exists.
 *
 * Object targets are checked recursively. Wildcard targets (`./locale/*.json`)
 * are checked as directory patterns: the static prefix must resolve to
 * a directory and at least one entry must match the suffix — never one literal file.
 */
function assertExportTarget(specifier: string, target: unknown): void {
  if (typeof target === 'string') {
    const relativeTarget = packageTargetPath(target);
    const wildcard = relativeTarget.indexOf('*');
    if (wildcard >= 0) {
      const prefix = relativeTarget.slice(0, wildcard);
      const directory = prefix.endsWith('/') ? prefix.slice(0, -1) : dirname(prefix);
      const suffix = relativeTarget.slice(wildcard + 1);
      const directoryPath = join(packageDir, directory);
      assert.ok(existsSync(directoryPath), `exports ${specifier}: wildcard directory ${directory}/ is missing`);
      const entries = readdirSync(directoryPath);
      assert.ok(
        entries.some((entry) => suffix.length === 0 || entry.endsWith(suffix)),
        `exports ${specifier}: no ${directory}/*${suffix} file exists`,
      );
      return;
    }
    assert.ok(existsSync(join(packageDir, relativeTarget)), `exports ${specifier}: target ${target} is missing`);
    return;
  }
  if (target !== null && typeof target === 'object') {
    for (const [condition, nested] of Object.entries(target as Record<string, unknown>)) {
      assertExportTarget(`${specifier} (${condition})`, nested);
    }
    return;
  }
  assert.fail(`exports ${specifier}: unsupported target ${JSON.stringify(target)}`);
}

/** Assert one `files` entry actually ships something (literal path or wildcard directory). */
function assertFilesEntry(entry: string): void {
  const wildcard = entry.indexOf('*');
  const basePath = wildcard >= 0 ? entry.slice(0, wildcard).replace(/\/$/, '') : entry;
  assert.ok(existsSync(join(packageDir, basePath)), `files entry ${entry} does not resolve to a shipped path`);
}

/** Collect every string target from one `exports` value, recursively. */
function exportTargets(target: unknown, collected: string[] = []): string[] {
  if (typeof target === 'string') collected.push(packageTargetPath(target));
  else if (target !== null && typeof target === 'object') {
    for (const nested of Object.values(target as Record<string, unknown>)) exportTargets(nested, collected);
  }
  return collected;
}

/**
 * Whether one `files` glob covers one package-relative path.
 *
 * `**` matches across directory separators, `*` stays inside one segment. Static
 * exports targets are checked against this so a target cannot silently drop out
 * of the tarball just because `files` changed (A5-F4).
 */
function filesPatternCovers(pattern: string, target: string): boolean {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  const regex = escaped
    .replace(/\*\*\//g, '(?:.*/)?')
    .replace(/\*\*/g, '.*')
    .replace(/\*/g, '[^/]*');
  return new RegExp(`^${regex}$`).test(target);
}

/** Targets npm always includes regardless of `files` (package identity documents). */
const IMPLICIT_TARBALL_FILES = new Set(['package.json']);

/**
 * Build `lib/` exactly like `vp run build`.
 *
 * Two projects, not one: `tsconfig.json` emits the ESM modules, and
 * `tsconfig.client.json` emits the classic-script client bundle that the main
 * project excludes. Building only the first leaves `lib/panel-client.js` (and its
 * declaration) missing, which every downstream assertion needs — and that gap is
 * invisible on a machine whose `lib/` came from a real `vp run build`.
 */
async function buildLib(): Promise<void> {
  for (const project of ['tsconfig.json', 'tsconfig.client.json']) {
    const result = await execFileAsync(tscCommand(), ['-p', project], { cwd: packageDir, timeout: 180_000 });
    assert.equal(String(result.stderr).trim(), '', `tsc -p ${project} stderr: ${String(result.stderr)}`);
  }
}

test('the documented build emits lib/ and lib/types/ for every source module', async () => {
  await buildLib();
  const modules = sourceModuleNames();
  for (const required of ['index', 'tools', 'guard', 'jj-command']) {
    assert.ok(modules.includes(required), `src/${required}.ts is missing from ${modules.join(', ')}`);
  }
  for (const name of modules) {
    assert.ok(existsSync(join(packageDir, 'lib', `${name}.js`)), `missing build artifact lib/${name}.js`);
    assert.ok(
      existsSync(join(packageDir, 'lib', 'types', `${name}.d.ts`)),
      `missing declaration lib/types/${name}.d.ts`,
    );
  }
});

test('pure modules stay free of runtime @deepseek-ai imports', () => {
  // Every import form the compiler can emit: static import/re-export, side-effect
  // import, dynamic import(), and require(). A `from '…'`-only check let the last
  // three forms slip through (A5-F2).
  const runtimeImportPatterns = [
    /\bfrom\s*['"]@deepseek-ai\//,
    /\bimport\s*['"]@deepseek-ai\//,
    /\bimport\s*\(\s*['"]@deepseek-ai\//,
    /\brequire\s*\(\s*['"]@deepseek-ai\//,
  ];
  const modules = sourceModuleNames();
  for (const name of PURE_MODULES) {
    assert.ok(modules.includes(name), `pure module src/${name}.ts is missing from ${modules.join(', ')}`);
    const source = readFileSync(join(packageDir, 'lib', `${name}.js`), 'utf8');
    for (const pattern of runtimeImportPatterns) {
      assert.ok(!pattern.test(source), `lib/${name}.js must not import a DSH package at runtime (matched ${pattern})`);
    }
  }
});

/** `exports` subpaths the published package must keep. */
const REQUIRED_EXPORTS = [
  '.',
  './tools',
  './guard',
  './changes',
  './detect',
  './git-command',
  './service',
  './jj-command',
  './commit-style',
  './multi-session',
  './prompt-context',
  './client',
] as const;

/** `files` entries the published package must ship (`lib/` artifacts plus the runtime data). */
const REQUIRED_FILES = [
  'lib/**/*.js',
  'lib/types/**/*.d.ts',
  'cordis.patch.yml',
  'locale/*.json',
  'tools/locale/*.json',
  'guard/locale/*.json',
  'changes/locale/*.json',
  'icon.svg',
] as const;

test('the published package manifest points only at shipped artifacts', () => {
  // This test runs after the build test above: every manifest target is compiled output.
  assert.ok(
    existsSync(join(packageDir, 'lib', 'index.js')),
    'lib/ is missing: run this file so the build test runs first',
  );
  const manifest = readPackageManifest();

  const main = manifest.main;
  assert.ok(typeof main === 'string', 'package.json main must be a string');
  assert.ok(existsSync(join(packageDir, packageTargetPath(main))), `main ${main} does not exist`);
  const types = manifest.types;
  assert.ok(typeof types === 'string', 'package.json types must be a string');
  assert.ok(existsSync(join(packageDir, packageTargetPath(types))), `types ${types} does not exist`);

  const exportsMap = manifest.exports ?? {};
  for (const specifier of REQUIRED_EXPORTS) {
    assert.ok(specifier in exportsMap, `package.json exports is missing the ${specifier} entry`);
  }
  for (const [specifier, target] of Object.entries(exportsMap)) assertExportTarget(specifier, target);

  const files = manifest.files ?? [];
  for (const entry of REQUIRED_FILES) {
    assert.ok(files.includes(entry), `package.json files is missing ${entry}`);
  }
  for (const entry of files) assertFilesEntry(entry);

  // Every static exports target must be covered by a `files` pattern: a shipped
  // subpath whose file is not in the tarball is a broken public API (A5-F4).
  for (const target of Object.entries(exportsMap).flatMap(([, value]) => exportTargets(value))) {
    if (target.includes('*') || IMPLICIT_TARBALL_FILES.has(target)) continue;
    assert.ok(
      files.some((pattern) => filesPatternCovers(pattern, target)),
      `exports target ${target} is not covered by any files pattern (the tarball would omit it)`,
    );
  }
  // Raw sources cannot be imported from node_modules (Node disables type stripping
  // there), so they are neither an exports subpath nor runtime weight (A5-F5).
  assert.equal('./src/*' in exportsMap, false, 'exports must not advertise the unusable ./src/* source subpath');
  assert.equal(
    files.some((entry) => entry.startsWith('src/')),
    false,
    'the tarball must not ship raw TypeScript sources that cannot be loaded from node_modules',
  );
});

test('every bundle entry ships its locale metadata and icon', () => {
  // The host resolves `<entry>/locale/<lang>.json` and `<entry>/icon` for each
  // bundle row; a missing export makes that row degrade (no icon/locale) even
  // though the files are in the tarball (A5-F1).
  const manifest = readPackageManifest();
  const exportsMap = manifest.exports ?? {};
  const entries = [
    { specifier: '.', locale: './locale/*.json', icon: './icon' },
    { specifier: './tools', locale: './tools/locale/*.json', icon: './tools/icon' },
    { specifier: './guard', locale: './guard/locale/*.json', icon: './guard/icon' },
    { specifier: './changes', locale: './changes/locale/*.json', icon: './changes/icon' },
  ] as const;
  for (const entry of entries) {
    assert.ok(entry.locale in exportsMap, `${entry.specifier} must export ${entry.locale}`);
    assert.ok(entry.icon in exportsMap, `${entry.specifier} must export ${entry.icon} (the host reads <entry>/icon)`);
    assert.equal(exportsMap[entry.icon], './icon.svg', `${entry.icon} must resolve to the shared icon`);
    assertExportTarget(entry.icon, exportsMap[entry.icon]);
    assertExportTarget(entry.locale, exportsMap[entry.locale]);
  }
});

test('the release workflow validates every published entry and locale', () => {
  // The release tarball gate is a hard-coded list; when it drifts from the real
  // tarball a missing entry/locale would ship unrecoverably (A5-F4). Pin the list
  // the workflow asserts, and keep raw sources out of it.
  const workflow = readFileSync(join(packageDir, '.github', 'workflows', 'release.yml'), 'utf8');
  const required = [
    'lib/index.js',
    'lib/types/index.d.ts',
    'lib/tools.js',
    'lib/types/tools.d.ts',
    'lib/guard.js',
    'lib/types/guard.d.ts',
    'lib/changes.js',
    'lib/types/changes.d.ts',
    'cordis.patch.yml',
    'icon.svg',
    'locale/en.json',
    'locale/zh.json',
    'tools/locale/en.json',
    'tools/locale/zh.json',
    'guard/locale/en.json',
    'guard/locale/zh.json',
    'changes/locale/en.json',
    'changes/locale/zh.json',
  ];
  for (const path of required) assert.ok(workflow.includes(`'${path}'`), `release.yml must validate the ${path} entry`);
  assert.doesNotMatch(workflow, /'src\//, 'release.yml must not expect raw TypeScript sources in the tarball');
});

test('DSH peer ranges admit later 0.2.x releases instead of pinning one runtime', () => {
  const manifest = readPackageManifest();
  const dshPeers = Object.entries(manifest.peerDependencies ?? {}).filter(
    ([name]) => name === '@deepseek-ai/dsh' || name.startsWith('@deepseek-ai/dsh-'),
  );
  assert.ok(dshPeers.length > 0, 'the manifest must state its DSH runtime requirement');
  for (const [name, range] of dshPeers) {
    // DSH matches the running version against each peer range, so an exact pin rejects every
    // later 0.2.x release. A caret range keeps patch/prerelease updates compatible while still
    // rejecting the next minor line, whose plugin-facing APIs may change incompatibly.
    assert.match(
      range,
      /^\^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/,
      `${name} must declare a caret range so later DSH patch releases stay compatible, got ${JSON.stringify(range)}`,
    );
  }
});

test('pnpm and Vite+ are wired as the repository toolchain', () => {
  const manifest = readPackageManifest();
  assert.equal(
    manifest.packageManager?.startsWith('pnpm@'),
    true,
    'package.json must pin the pnpm version used locally and in CI',
  );
  const devDependencies = manifest.devDependencies ?? {};
  for (const name of [
    'vite-plus',
    '@vitest/coverage-v8',
    'typescript',
    '@types/node',
    '@deepseek-ai/dsh-session-projection',
  ]) {
    assert.ok((devDependencies[name] ?? '').length > 0, `package.json devDependencies is missing ${name}`);
  }

  const scripts = manifest.scripts ?? {};
  for (const name of [
    'build',
    'format',
    'format:check',
    'lint',
    'lint:fix',
    'check',
    'typecheck',
    'test',
    'test:unit',
    'test:coverage',
  ]) {
    assert.ok((scripts[name] ?? '').length > 0, `package.json scripts.${name} is missing`);
  }
  assert.equal(scripts.prepack, 'vp run build', 'prepack must invoke the build script through Vite+');
  assert.equal(scripts.format, 'vp fmt', 'formatting must go through the Vite+ CLI');
  assert.equal(scripts['format:check'], 'vp fmt --check', 'CI must check formatting through the Vite+ CLI');
  assert.equal(scripts.lint, 'vp lint', 'linting must go through the Vite+ CLI');
  assert.equal(scripts.check, 'vp check --deny-warnings', 'the static gate must deny Oxlint warnings');
  assert.equal(scripts['test:unit'], 'vp test', 'unit tests must run through Vite+ Vitest');
  assert.equal(scripts['test:coverage'], 'vp test --coverage', 'coverage must run through Vite+ Vitest');
  assert.match(scripts.test ?? '', /vp run check/, 'the test gate must run the static checks');
  assert.match(scripts.test ?? '', /vp test/, 'the test gate must run Vite+ Vitest');

  for (const file of ['pnpm-lock.yaml', 'pnpm-workspace.yaml', 'vite.config.ts']) {
    assert.ok(existsSync(join(packageDir, file)), `${file} must exist at the repository root`);
  }
  const workspace = readFileSync(join(packageDir, 'pnpm-workspace.yaml'), 'utf8');
  const alias = /vite@\*:\s*npm:@voidzero-dev\/vite-plus-core@(\S+)/.exec(workspace);
  assert.ok(alias !== null, 'pnpm-workspace.yaml must alias vite to the Vite+ core package');
  assert.equal(
    alias[1],
    devDependencies['vite-plus'],
    'the pnpm vite alias must track the installed vite-plus version',
  );
  const viteConfig = readFileSync(join(packageDir, 'vite.config.ts'), 'utf8');
  assert.match(viteConfig, /fmt:\s*\{/, 'vite.config.ts must configure Oxfmt');
  assert.match(viteConfig, /lint:\s*\{/, 'vite.config.ts must configure Oxlint');
  assert.match(viteConfig, /test:\s*\{/, 'vite.config.ts must configure Vitest');
  assert.match(viteConfig, /coverage:\s*\{/, 'vite.config.ts must configure coverage');
});

test('all four entries import under plain Node with name/inject/apply/Config', async () => {
  const entries: ReadonlyArray<readonly [string, string, readonly string[]]> = [
    ['.', 'jj', ['subprocess', 'workingDirectory']],
    ['./tools', 'jj-tools', ['tools', 'jj', 'workingDirectory']],
    ['./guard', 'jj-guard', ['tools', 'jj']],
    ['./changes', 'jj-changes', ['subprocess', 'fs', 'jj']],
  ];
  // Run inside a real plain Node.js subprocess so Vitest's module runner cannot mask
  // broken ESM specifiers or package.json exports in the built `lib/` output.
  const urls = entries.map(([specifier]) => pathToFileURL(join(packageDir, 'lib', entryFile(specifier))).href);
  const probe = `
    const urls = JSON.parse(process.argv[1]);
    const out = [];
    for (const url of urls) {
      const m = await import(url);
      out.push({
        name: m.name,
        inject: Array.isArray(m.inject) ? [...m.inject] : [],
        applyType: typeof m.apply,
        hasConfig: m.Config !== undefined,
      });
    }
    process.stdout.write(JSON.stringify(out));
  `;
  const { stdout, stderr } = await execFileAsync(
    process.execPath,
    ['--input-type=module', '-e', probe, JSON.stringify(urls)],
    { cwd: packageDir, timeout: 30_000 },
  );
  assert.equal(String(stderr).trim(), '', `plain Node import stderr: ${String(stderr)}`);
  const loaded = JSON.parse(String(stdout)) as Array<{
    name: unknown;
    inject: string[];
    applyType: string;
    hasConfig: boolean;
  }>;
  assert.equal(loaded.length, entries.length);
  for (const [index, [specifier, expectedName, expectedInject]] of entries.entries()) {
    const module = loaded[index]!;
    assert.equal(module.name, expectedName, `${specifier} name`);
    assert.deepEqual(module.inject, expectedInject, `${specifier} inject`);
    assert.equal(module.applyType, 'function', `${specifier} apply`);
    assert.equal(module.hasConfig, true, `${specifier} must export Config`);
  }
});

test('the bare package name resolves each documented export', async () => {
  const root = await import('@aqian0/dsh-jj');
  const tools = await import('@aqian0/dsh-jj/tools');
  const guard = await import('@aqian0/dsh-jj/guard');
  const changes = await import('@aqian0/dsh-jj/changes');
  assert.equal(root.name, 'jj');
  assert.equal(tools.name, 'jj-tools');
  assert.equal(guard.name, 'jj-guard');
  assert.equal(changes.name, 'jj-changes');
  assert.ok(changes.Config !== undefined, 'the changes row validates its own configuration schema');
  assert.equal(typeof changes.apply, 'function');
  assert.equal(typeof changes.jjWorkspaceRootAt, 'function', 'jj workspace classification is part of the public API');
  // Each row validates its own scoped schema: the rows must not share one schema object
  // (that is what let a key be accepted on a row that never reads it).
  const rowKeys = (module: { Config?: unknown }): string[] =>
    Object.keys((module.Config as { dict?: Record<string, unknown> } | undefined)?.dict ?? {}).sort();
  assert.notEqual(root.Config, tools.Config, 'each row exports its own scoped configuration schema');
  assert.deepEqual(rowKeys(root), [...ROW_CONFIG_KEYS.runtime].sort(), 'the runtime schema is scoped to runtime keys');
  assert.deepEqual(rowKeys(tools), [...ROW_CONFIG_KEYS.tools].sort());
  assert.deepEqual(rowKeys(guard), [...ROW_CONFIG_KEYS.guard].sort());
  assert.deepEqual(rowKeys(changes), [...ROW_CONFIG_KEYS.changes].sort());
  assert.deepEqual(
    Object.keys(root).sort(),
    ['Config', 'JjService', 'apply', 'assembleBaseLayer', 'describeVcsKind', 'inject', 'name'].sort(),
    'the runtime entry must not re-export other components; implementations live on their subpaths',
  );
  assert.equal(typeof root.assembleBaseLayer, 'function', 'the embed helper is part of the entry surface');
});

test('the test project maps every self-referenced subpath to source', () => {
  // `vp run test` type-checks before this file builds lib/, so a bare
  // `@aqian0/dsh-jj/<subpath>` import in the suite only resolves pre-build through
  // the tsconfig `paths` map. A subpath missing there still passes on a machine
  // that happens to have a stale `lib/types/*.d.ts` and fails on a clean checkout
  // (CI), so the map is asserted against the imports the suite actually writes.
  const config = readJsonWithComments('tsconfig.test.json') as {
    compilerOptions?: { paths?: Record<string, readonly string[]> };
  };
  const paths = config.compilerOptions?.paths ?? {};

  const specifiers = new Set<string>();
  for (const file of testSourceFiles()) {
    for (const match of readFileSync(file, 'utf8').matchAll(/@aqian0\/dsh-jj(?:\/[a-z][a-z-]*)?/g)) {
      specifiers.add(match[0]);
    }
  }
  assert.ok(specifiers.size >= 8, 'the suite should self-reference the published subpaths');
  for (const specifier of specifiers) {
    assert.ok(
      specifier in paths,
      `tsconfig.test.json paths is missing ${specifier}: the type-check would only pass after lib/ is built`,
    );
  }
  for (const [specifier, targets] of Object.entries(paths)) {
    assert.equal(targets.length, 1, `${specifier} must map to exactly one source file`);
    const [target] = targets;
    assert.ok(target !== undefined && existsSync(join(packageDir, target)), `${specifier} maps to missing ${target}`);
  }
});

test('each component publishes its implementation on its own subpath', async () => {
  const service = await import('@aqian0/dsh-jj/service');
  assert.equal(service.ROOT_COMMIT_ID, '0'.repeat(40), 'the empty root commit id is exported for hand-off logic');
  assert.equal(typeof service.JjOperations, 'function');
  for (const name of [
    'TPL_STATUS',
    'TPL_LOG',
    'TPL_DESCRIPTION',
    'TPL_OP_LOG',
    'TPL_BOOKMARK_LIST',
    'TPL_WORKSPACE_LIST_TAB',
  ] as const) {
    assert.equal(typeof service[name], 'string', `${name} is a template constant`);
  }

  const jjCommand = await import('@aqian0/dsh-jj/jj-command');
  for (const name of [
    'JjError',
    'classifyJjFailure',
    'createCommandRunGit',
    'createCommandRunJj',
    'createRunGit',
    'createRunJj',
    'jjErrorMessage',
    'jjNonInteractiveEnv',
  ] as const) {
    assert.equal(typeof jjCommand[name], 'function', `${name} lives on ./jj-command`);
  }

  const detect = await import('@aqian0/dsh-jj/detect');
  for (const name of ['detectVcs', 'sniffVcsSync', 'parseWorkspaceList'] as const) {
    assert.equal(typeof detect[name], 'function', `${name} lives on ./detect`);
  }
  assert.equal(typeof detect.TPL_WORKSPACE_LIST, 'string');
  assert.ok(detect.DEFAULT_PROBE_TIMEOUT_MS > 0);
  assert.ok(detect.GIT_PROBE_ENV !== undefined && detect.JJ_PROBE_ENV !== undefined);

  const gitCommand = await import('@aqian0/dsh-jj/git-command');
  for (const name of ['classifyGitInvocation', 'hasMutatingGitInvocation'] as const) {
    assert.equal(typeof gitCommand[name], 'function', `${name} lives on ./git-command`);
  }
  assert.equal(typeof gitCommand.gitEquivalence, 'function');
  assert.equal(typeof gitCommand.GIT_SUBCOMMAND_RULES, 'object');
  assert.equal(typeof gitCommand.JJ_EQUIVALENCE, 'object');

  const commitStyle = await import('@aqian0/dsh-jj/commit-style');
  for (const name of [
    'detectCommitStyle',
    'resolveCommitStylePolicy',
    'classifyDescriptionStyle',
    'commitStylePromptText',
    'firstDescriptionLine',
  ] as const) {
    assert.equal(typeof commitStyle[name], 'function', `${name} lives on ./commit-style`);
  }
  assert.ok(Array.isArray(commitStyle.COMMIT_STYLE_IDS));
  assert.ok(Array.isArray(commitStyle.COMMIT_STYLE_CHOICES));
  assert.equal(typeof commitStyle.COMMIT_STYLE_PRESETS, 'object');
  assert.ok(Array.isArray(commitStyle.CONCRETE_COMMIT_STYLE_IDS));
  assert.ok(commitStyle.MIN_COMMIT_STYLE_SAMPLES > 0);
  assert.equal(typeof commitStyle.SPLIT_COMMITS_GUIDANCE, 'string');
  assert.equal(typeof commitStyle.CORRECTION_GUIDANCE, 'string');
  assert.ok(commitStyle.COMMIT_STYLE_DOMINANCE !== undefined);

  const multiSession = await import('@aqian0/dsh-jj/multi-session');
  for (const name of [
    'detectParallelSessions',
    'multiSessionPromptText',
    'multiSessionFinishChecklistText',
    'parallelPeerCwds',
  ] as const) {
    assert.equal(typeof multiSession[name], 'function', `${name} lives on ./multi-session`);
  }
  assert.ok(Array.isArray(multiSession.MULTI_SESSION_GUIDANCE_MODES));
  assert.equal(typeof multiSession.DEFAULT_REBASE_TARGET, 'string');

  const promptContext = await import('@aqian0/dsh-jj/prompt-context');
  for (const name of ['installJjPromptContext', 'jjPreferenceContextText'] as const) {
    assert.equal(typeof promptContext[name], 'function', `${name} lives on ./prompt-context`);
  }
  assert.equal(typeof promptContext.JJ_CONTEXT_NAME, 'string');
  assert.equal(typeof promptContext.JJ_CONTEXT_ORDER_FALLBACK, 'number');

  const guard = await import('@aqian0/dsh-jj/guard');
  for (const name of [
    'buildGitRefusalMessage',
    'buildJjWorkspaceForgetRefusal',
    'buildJjWorkspaceRemoveRefusal',
    'buildWorktreeToolRefusalMessage',
    'evaluateGitCommand',
    'gitConfusionWhy',
    'installGitConfusionGuard',
  ] as const) {
    assert.equal(typeof guard[name], 'function', `${name} lives on ./guard`);
  }

  const tools = await import('@aqian0/dsh-jj/tools');
  for (const name of ['jjToolDefinitions', 'registerJjTools', 'jjRefusalText'] as const) {
    assert.equal(typeof tools[name], 'function', `${name} lives on ./tools`);
  }
});

test('the client bundle survives re-execution as a classic script without leaking globals', () => {
  // The host injects `<script src=…&rev=…>` again whenever the bundle revision changes
  // (HMR, upgrade). Classic scripts share one global lexical scope, so a top-level
  // `const` would throw "already declared" on the second run before registering.
  const source = readFileSync(join(packageDir, 'lib', 'panel-client.js'), 'utf8');
  const registered: string[] = [];
  const sandbox: Record<string, unknown> = {
    __ModuleLoader__: { load: (module: { id: string }) => registered.push(module.id) },
  };
  const context = createContext(sandbox);
  const baseline = new Set(Object.getOwnPropertyNames(sandbox));
  for (const run of [1, 2]) {
    new Script(source, { filename: `panel-client.js?rev=${run}` }).runInContext(context);
  }
  assert.deepEqual(registered, ['@aqian0/dsh-jj', '@aqian0/dsh-jj'], 'every execution registers the factory');
  const leaked = Object.getOwnPropertyNames(sandbox).filter((name) => !baseline.has(name));
  assert.deepEqual(leaked, [], 'the bundle must not define globals other plugins could clash with');
  const lexical = new Script('typeof PANEL_BUNDLE_ID').runInContext(context) as string;
  assert.equal(lexical, 'undefined', 'top-level bindings stay inside the bundle scope');
});

test('the client bundle is a classic script that registers a lazy sidebar tab', async () => {
  const bundlePath = join(packageDir, 'lib', 'panel-client.js');
  const source = readFileSync(bundlePath, 'utf8');
  assert.doesNotMatch(source, /^\s*(import|export)\s/m, 'a client bundle must be a classic script, not an ES module');
  assert.match(source, /__ModuleLoader__|globalThis/, 'the bundle registers itself through the module loader');
  assert.match(source, /@aqian0\/dsh-jj/, 'the loader id is the package name the host resolves');

  // Evaluate the bundle the way the browser does: a global loader captures the factory,
  // then the factory runs with a stubbed host `require`.
  interface LoaderModule {
    readonly id: string;
    readonly factory: (require: (id: string) => unknown) => { readonly apply?: unknown; readonly inject?: unknown };
  }
  const captured: LoaderModule[] = [];
  const globalWithLoader = globalThis as unknown as {
    __ModuleLoader__?: { load(module: LoaderModule): void };
  };
  const previous = globalWithLoader.__ModuleLoader__;
  globalWithLoader.__ModuleLoader__ = { load: (module) => captured.push(module) };
  try {
    await import(pathToFileURL(bundlePath).href);
  } finally {
    globalWithLoader.__ModuleLoader__ = previous;
  }
  const loaded = captured[0];
  assert.ok(loaded !== undefined, 'evaluating the bundle registers exactly one module');
  assert.equal(loaded.id, '@aqian0/dsh-jj', 'the bundle id must match the package name');
  interface FakeElement {
    readonly type: unknown;
    readonly props: Record<string, unknown>;
  }
  const reactStub = {
    createElement: (type: unknown, props?: Record<string, unknown> | null, ...children: unknown[]): FakeElement => ({
      type,
      props: { ...props, children },
    }),
    useState: <T>(initial: T): [T, (next: T) => void] => [initial, () => {}],
    useEffect: (): void => {},
  };
  // The shell's frozen platform table provides the shared UI primitives; the tool rows
  // reuse its disclosure row and icons, so the stub mirrors that module's shape.
  const primitivesStub: Record<string, unknown> = {
    DisclosureRow: (props: Record<string, unknown>): FakeElement => ({ type: 'DisclosureRow', props }),
    IconChecklistOutlineRegular: (props: Record<string, unknown>): FakeElement => ({ type: 'IconChecklist', props }),
    IconBranchOutlineRegular: (props: Record<string, unknown>): FakeElement => ({ type: 'IconBranch', props }),
    IconWorkspaceTreeOutlineRegular: (props: Record<string, unknown>): FakeElement => ({
      type: 'IconWorkspaceTree',
      props,
    }),
    IconShareOutlineRegular: (props: Record<string, unknown>): FakeElement => ({ type: 'IconShare', props }),
  };
  const clientModule = loaded.factory((id) => {
    if (id === 'react') return reactStub;
    if (id === '@deepseek-ai/dsh-client-ui-primitives') return primitivesStub;
    throw new Error(`unexpected host module request: ${id}`);
  });
  assert.equal(typeof clientModule.apply, 'function', 'the client module exposes apply');
  assert.deepEqual(
    [...(clientModule.inject as readonly string[])],
    ['slots', 'locale', 'sidebarRight', 'sidebarRightTabs'],
    'the tab registry is a separate service and must be injected explicitly',
  );

  // The tab registration goes through the public sidebar-right API and tolerates a host
  // that only provides some of the services. `bind` reads the registered dictionary so
  // the assertions below exercise the same lookup the real locale service performs.
  const tabs: Record<string, unknown>[] = [];
  const slots: { name: string; key: string; locale: unknown; component: unknown }[] = [];
  const locales: string[] = [];
  const dictionariesByNamespace: Record<string, Record<string, Record<string, string>>> = {};
  const translate = (namespace: string, key: string): string => dictionariesByNamespace[namespace]?.zh?.[key] ?? key;
  (clientModule.apply as (ctx: unknown) => void)({
    locale: {
      register: (namespace: string, dictionaries: Record<string, Record<string, string>>) => {
        locales.push(namespace);
        dictionariesByNamespace[namespace] = dictionaries;
      },
      bind: (namespace: string) => (key: string) => translate(namespace, key),
    },
    sidebarRightTabs: { register: (definition: Record<string, unknown>) => tabs.push(definition) },
    slots: {
      inject: (_name: string, callback: () => unknown) => callback(),
      register: (definition: Record<string, unknown>, component: unknown) =>
        slots.push({
          name: String(definition.name),
          key: String(definition.key),
          locale: definition['locale'],
          component,
        }),
    },
  });
  assert.deepEqual(locales, ['jjPanel']);

  // Both baseline dictionaries are registered with the same keys, and the Chinese copy
  // no longer leaks English UI terms such as "change", "commit" or "stale".
  const dictionaries = dictionariesByNamespace['jjPanel'];
  assert.ok(dictionaries !== undefined, 'the panel registers its jjPanel dictionaries');
  const zhDictionary = dictionaries['zh'];
  const enDictionary = dictionaries['en'];
  assert.ok(zhDictionary !== undefined && enDictionary !== undefined, 'both locale baselines exist');
  assert.deepEqual(
    Object.keys(zhDictionary).sort(),
    Object.keys(enDictionary).sort(),
    'zh and en must carry exactly the same keys',
  );
  for (const [key, value] of Object.entries(zhDictionary)) {
    assert.equal(typeof value, 'string', `zh.${key} is a string`);
    assert.ok(value.length > 0, `zh.${key} is not empty`);
  }
  for (const [key, value] of Object.entries(enDictionary)) {
    assert.equal(typeof value, 'string', `en.${key} is a string`);
    assert.ok(value.length > 0, `en.${key} is not empty`);
  }
  assert.equal(zhDictionary['changeId'], '变更');
  assert.equal(zhDictionary['commitId'], '提交');
  assert.equal(zhDictionary['modified'], '有改动');
  assert.equal(zhDictionary['stale'], '过期');
  assert.equal(zhDictionary['noOperations'], '没有操作记录。');
  assert.match(zhDictionary['conflictCount'] ?? '', /\{count\}/);
  assert.match(zhDictionary['revisionCount'] ?? '', /\{count\}/);
  const zhT = (key: string): string => zhDictionary[key] ?? key;
  assert.deepEqual(
    tabs.map((tab) => tab['kind']),
    ['jj'],
  );
  // The sidebar calls these lazily: `title` must be a function and `guide` an ARRAY of
  // entries (each with its own id and lazy title/description). A string/object here
  // throws inside the registry and silently removes the tab from the UI.
  const tabDefinition = tabs[0] as Record<string, unknown>;
  assert.equal(typeof tabDefinition['title'], 'function', 'the tab type title is a function');
  assert.equal((tabDefinition['title'] as () => string)(), 'Jujutsu 状态');
  const guide = tabDefinition['guide'] as { id: string; title: () => string; description?: () => string }[];
  assert.ok(Array.isArray(guide) && guide.length === 1, 'the guide is an array of entries');
  assert.equal(guide[0]?.id, 'jj');
  assert.equal(typeof guide[0]?.title, 'function');
  assert.equal(guide[0]?.title(), 'Jujutsu 状态');
  assert.equal(typeof guide[0]?.description, 'function');
  assert.equal(guide[0]?.description?.(), '工作副本、栈、工作区与书签');
  // The title seat is separate from the body: it must carry the panel namespace too, or
  // its chip falls back to English while the body renders Chinese.
  assert.deepEqual(
    slots.map((slot) => ({ name: slot.name, key: slot.key, locale: slot.locale })),
    [
      { name: 'sidebar.right.pane.tab', key: 'jj-panel', locale: 'jjPanel' },
      { name: 'sidebar.right.pane.tab.title', key: 'jj-panel', locale: 'jjPanel' },
      { name: 'tool.call.toolview', key: 'jj_status', locale: 'jjPanel' },
      { name: 'tool.call.toolview', key: 'jj_log', locale: 'jjPanel' },
      { name: 'tool.call.toolview', key: 'jj_workspace_list', locale: 'jjPanel' },
      { name: 'tool.call.toolview', key: 'jj_handoff', locale: 'jjPanel' },
    ],
  );
  // The body renders its page shell even before any data arrives (no session cwd here),
  // and its chrome follows the registered Chinese dictionary.
  const body = slots[0]?.component as (props: Record<string, unknown>) => FakeElement;
  const tree = body({
    sessionId: 'session-1',
    useSessions: () => undefined,
    useSessionStatus: () => false,
    t: zhT,
  });
  assert.equal(tree.props['className'], 'dshjj');
  assert.ok(Array.isArray(tree.props['children']) && (tree.props['children'] as unknown[]).length > 0);
  const treeText = JSON.stringify(tree.props);
  assert.match(treeText, /Jujutsu 状态/, 'the body header uses the localized title');
  assert.match(treeText, /刷新/, 'the refresh control is localized');
  const title = slots[1]?.component as (props: Record<string, unknown>) => FakeElement;
  const zhTitleEl = title({ t: zhT });
  assert.equal(zhTitleEl.props['className'], 'dshjj-tab-title');
  assert.match(JSON.stringify(zhTitleEl), /svg/, 'the tab title chip includes a monochrome Jujutsu glyph');
  assert.match(JSON.stringify(zhTitleEl), /Jujutsu 状态/, 'the tab title chip renders the localized title');
  const rawTitleEl = title({ t: (key: string) => key });
  assert.match(JSON.stringify(rawTitleEl), /"title"/, 'an unbound title still renders its key');

  // Every tool view renders one compact disclosure row (the same shape as DSH's own
  // tool rows), never a standalone bordered card: these rows sit inside the streaming
  // thinking steps, where a big card breaks the row rhythm.
  const statusCard = slots[2]?.component as (props: Record<string, unknown>) => FakeElement;
  const statusBlock = {
    call: { name: 'jj_status', argsRaw: JSON.stringify({ details: true }) },
    content: [
      {
        type: 'text',
        text: JSON.stringify({
          changeId: 'abcdefghijkl',
          commitId: '0123456789abcdef',
          description: 'feat: seed',
          empty: false,
          diffStat: '1 file changed',
          workspaceRoot: '/tmp/repo',
        }),
      },
    ],
    isError: false,
  };
  const statusTree = statusCard({ phase: 'result', t: (key: string) => key, block: statusBlock });
  assert.equal(statusTree.type, primitivesStub['DisclosureRow'], 'the row reuses the host disclosure chrome');
  assert.equal(statusTree.props['title'], 'statusCard', 'the row title is localized');
  assert.equal(
    (statusTree.props['icon'] as FakeElement).type,
    primitivesStub['IconChecklistOutlineRegular'],
    'the row keeps a tool icon',
  );
  const statusCollapsed = JSON.stringify(statusTree.props['collapsedContent']);
  assert.match(statusCollapsed, /abcdefghij/, 'the change id is summarized (short form)');
  assert.match(statusCollapsed, /feat: seed/, 'the description is summarized');
  assert.equal(statusTree.props['expandable'], true, 'a settled call with details is expandable');
  assert.equal(statusTree.props['open'], false, 'the body starts collapsed');
  // The expanded body carries the precise ids and the diff line.
  const statusExpanded = statusCard({
    phase: 'result',
    t: (key: string) => key,
    useDisclosure: () => ({ expanded: true, toggle: () => {} }),
    block: statusBlock,
  });
  assert.equal(statusExpanded.props['open'], true, 'the chat-owned disclosure opens the body');
  const statusDetail = JSON.stringify(statusExpanded.props['children']);
  assert.match(statusDetail, /0123456789abcdef/, 'the expanded body shows the full commit id');
  assert.match(statusDetail, /1 file changed/, 'the expanded body keeps the diff summary');
  // A call that has not settled is a non-expandable line with the localized state.
  const runningTree = statusCard({
    phase: 'start',
    t: (key: string) => key,
    block: { phase: 'start', name: 'jj_status' },
  });
  assert.equal(runningTree.props['expandable'], false, 'a running call has no body yet');
  assert.equal(runningTree.props['running'], true, 'a running call shimmers');
  assert.match(JSON.stringify(runningTree.props['collapsedContent']), /running/, 'the running state is localized');

  // Row copy goes through the same dictionary; a hardcoded English fragment here would
  // reappear in the Chinese UI.
  const logCard = slots[3]?.component as (props: Record<string, unknown>) => FakeElement;
  const logChanges = Array.from({ length: 8 }, (_, index) => ({
    changeId: `change-${String(index)}`,
    description: `commit ${String(index)}`,
  }));
  const logBlock = {
    call: { name: 'jj_log', argsRaw: JSON.stringify({ revset: '@ | @-' }) },
    content: [{ type: 'text', text: JSON.stringify({ changes: logChanges, truncated: true }) }],
    isError: false,
  };
  const logKeys = new Set<string>();
  const logTree = logCard({
    phase: 'result',
    t: (key: string) => {
      logKeys.add(key);
      return zhT(key);
    },
    block: logBlock,
  });
  assert.equal(logTree.props['title'], '提交历史', 'the log row title is localized');
  assert.ok(logKeys.has('revisionCount'), 'the log row localizes its revision count');
  assert.ok(logKeys.has('moreItems'), 'the capped detail list localizes its overflow');
  assert.ok(logKeys.has('truncated'), 'a truncated result says so');
  const logCollapsed = JSON.stringify(logTree.props['collapsedContent']);
  assert.match(logCollapsed, /@ \| @-/, 'the requested revset is summarized');
  assert.match(logCollapsed, /8 条修订/, 'the matched revision count is localized');
  const logDetail = JSON.stringify(logTree.props['children']);
  assert.match(logDetail, /commit 0/, 'the expanded body lists the matched changes');
  assert.match(logDetail, /另有 3 项/, 'detail rows beyond the cap are counted');
  assert.match(logDetail, /结果已截断/, 'the truncated marker reaches the row');

  const workspacesCard = slots[4]?.component as (props: Record<string, unknown>) => FakeElement;
  const workspacesTree = workspacesCard({
    phase: 'result',
    t: zhT,
    block: {
      call: { name: 'jj_workspace_list', argsRaw: '{}' },
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            workspaces: [
              { name: 'default', root: '/repo', isCurrent: true },
              { name: 'feat', root: '/repo-feat', isCurrent: false },
            ],
          }),
        },
      ],
      isError: false,
    },
  });
  assert.equal(workspacesTree.props['title'], '工作区清单');
  assert.match(JSON.stringify(workspacesTree.props['collapsedContent']), /2 个工作区/);
  const workspacesDetail = JSON.stringify(workspacesTree.props['children']);
  assert.match(workspacesDetail, /default · 当前/, 'the current workspace is marked');
  assert.match(workspacesDetail, /\/repo-feat/, 'each workspace root is listed');

  const handoffCard = slots[5]?.component as (props: Record<string, unknown>) => FakeElement;
  const handoffKeys = new Set<string>();
  const handoffTree = handoffCard({
    phase: 'result',
    t: (key: string) => {
      handoffKeys.add(key);
      return key;
    },
    block: {
      call: { name: 'jj_handoff', argsRaw: '{}' },
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            destination: 'main',
            rebased: true,
            conflicts: [{ changeId: 'x' }],
            nextActions: [{ tool: 'jj_status', reason: 'resolve the conflict' }],
          }),
        },
      ],
      isError: false,
    },
  });
  assert.equal(handoffTree.props['title'], 'handoffCard');
  assert.match(JSON.stringify(handoffTree.props['collapsedContent']), /main/, 'the destination is summarized');
  assert.match(
    JSON.stringify(handoffTree.props['children']),
    /resolve the conflict/,
    'the recommended action is shown',
  );
  assert.ok(handoffKeys.has('rebased'), 'the handoff row localizes its rebase state');
  assert.ok(handoffKeys.has('conflictCount'), 'the handoff row localizes its conflict count');

  const integratedTree = handoffCard({
    phase: 'result',
    t: zhT,
    block: {
      call: { name: 'jj_handoff', argsRaw: '{}' },
      content: [
        {
          type: 'text',
          text: JSON.stringify({ destination: 'trunk()', rebased: false, conflicts: [{ changeId: 'x' }] }),
        },
      ],
      isError: false,
    },
  });
  const integratedText = JSON.stringify(integratedTree.props);
  assert.match(integratedText, /已集成/, 'an already-integrated hand-off is localized');
  assert.match(integratedText, /1 处冲突/, 'the localized conflict count fills its placeholder');

  // A failed call keeps its one-line error text and exposes the raw payload on expand.
  const failedTree = logCard({
    phase: 'result',
    t: zhT,
    block: {
      call: { name: 'jj_log', argsRaw: '{}' },
      content: [{ type: 'text', text: 'boom: not a jj repository' }],
      isError: true,
    },
  });
  assert.equal(failedTree.props['title'], '提交历史', 'a failed call keeps its tool title');
  assert.match(JSON.stringify(failedTree.props['collapsedContent']), /boom: not a jj repository/);
  assert.equal(failedTree.props['expandable'], true, 'a failed call exposes its payload');

  // A malformed payload degrades to a title-only row instead of throwing.
  assert.doesNotThrow(() =>
    statusCard({ phase: 'result', t: (key: string) => key, block: { call: { argsRaw: 'not json' } } }),
  );
  // A host without sidebar-right must not throw during activation.
  assert.doesNotThrow(() => (clientModule.apply as (ctx: unknown) => void)({}));

  // A host that does not expose the shared primitives still gets a compact one-line
  // row (never a bordered card, and never a thrown render).
  const fallbackModule = loaded.factory((id) => {
    if (id === 'react') return reactStub;
    throw new Error(`host module missing: ${id}`);
  });
  assert.equal(typeof fallbackModule.apply, 'function');
  const fallbackTree = logCard({ phase: 'result', t: (key: string) => key, block: logBlock });
  assert.equal(fallbackTree.props['className'], 'dshjj-tool-row');
  assert.match(JSON.stringify(fallbackTree.props), /logCard/, 'the fallback row keeps its title');
  assert.match(JSON.stringify(fallbackTree.props), /@ \\| @-/, 'the fallback row keeps its summary');
});

test('the built guard entry installs a working guard against a real jj workspace', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-build');
  const colo = await initJjColocated(fx.run, fx.path('colo'));

  const guardEntry = await import('@aqian0/dsh-jj/guard');
  const harness = createGuardContext();
  guardEntry.apply(harness.ctx, { guardMutatingGit: 'deny', defaultCwd: colo });
  const reason = harness.runGuard({ name: 'bash', arguments: { command: 'git commit -m x' } });
  assert.ok(typeof reason === 'string', 'the built guard must refuse the git write');
  assert.match(reason, /^Blocked: `git commit`/);
});

test('the built runtime entry registers the ctx.jj service on a real Cordis context', async () => {
  const { Context } = await import('@deepseek-ai/cordis');
  const runtimeEntry = await import('@aqian0/dsh-jj');
  const ctx = new Context();
  assert.doesNotThrow(() => runtimeEntry.apply(ctx, {}));
  const service = (ctx as unknown as { jj: BuiltJjService }).jj;
  assert.ok(service !== undefined, 'ctx.jj must be registered by the runtime entry');
  assert.equal(typeof service.peek, 'function');
  assert.equal(typeof service.warm, 'function');
  assert.equal(typeof service.operations.status, 'function');
  assert.equal(service.describe('jj-native'), 'Jujutsu (jj) native repository');
});

test('the runtime entry registers the panel routes once the connection service exists', async (t) => {
  const { Context } = await import('@deepseek-ai/cordis');
  const runtimeEntry = await import('@aqian0/dsh-jj');
  interface RegisteredRoute {
    readonly path: string;
    readonly fetch: (request: Request) => Promise<Response>;
  }
  const routesOf = (): { routes: RegisteredRoute[]; connection: unknown } => {
    const routes: RegisteredRoute[] = [];
    return {
      routes,
      connection: {
        fetch: {
          register: (entry: RegisteredRoute) => {
            routes.push(entry);
            return () => {};
          },
        },
      },
    };
  };
  const overviewPath = '/api/jj.overview';
  const refreshPath = '/api/jj.refresh';
  const revisionPath = '/api/jj.revision';

  // Available before apply: the routes register synchronously.
  const early = routesOf();
  const earlyCtx = new Context();
  earlyCtx.provide('connection');
  earlyCtx.set('connection', early.connection);
  runtimeEntry.apply(earlyCtx, {});
  assert.deepEqual(
    early.routes.map((route) => route.path),
    [overviewPath, refreshPath, revisionPath],
  );

  // Provided later (the real boot order): a child fiber through `ctx.inject` must
  // install them when the Web app's connection row finally appears.
  const late = routesOf();
  const lateCtx = new Context();
  runtimeEntry.apply(lateCtx, {});
  assert.equal(late.routes.length, 0, 'no connection yet, so no panel routes');
  lateCtx.provide('connection');
  lateCtx.set('connection', late.connection);
  await new Promise((resolve) => setTimeout(resolve, 10));
  assert.deepEqual(
    late.routes.map((route) => route.path),
    [overviewPath, refreshPath, revisionPath],
    'the routes register when the connection service is provided later',
  );

  // When live sessions are present, panel routes allow the session workspace and any
  // sibling jj workspace of the same repository, and reject unrelated host paths.
  const fx = makeFixture(t, 'dsh-jj-panel-scope');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const sibling = fx.path('repo-sibling');
  await mustRun(fx.run, ['jj', 'workspace', 'add', sibling, '--name', 'sibling'], repo);
  const unrelated = fx.path('unrelated');
  mkdirSync(unrelated, { recursive: true });
  const scoped = routesOf();
  const scopedCtx = new Context();
  const session = { id: 'panel-session', header: { cwd: repo } };
  scopedCtx.provide('connection');
  scopedCtx.set('connection', scoped.connection);
  scopedCtx.provide('workingDirectory');
  scopedCtx.set('workingDirectory', { get: () => repo });
  scopedCtx.provide('sessions');
  scopedCtx.set('sessions', { list: () => [session] });
  runtimeEntry.apply(scopedCtx, {});
  const scopedOverview = scoped.routes.find((route) => route.path === overviewPath)!;
  const scopedRevision = scoped.routes.find((route) => route.path === revisionPath)!;
  const blocked = await scopedOverview.fetch(
    new Request(`http://localhost/api/jj.overview?cwd=${encodeURIComponent(unrelated)}`),
  );
  assert.equal(blocked.status, 403, 'unrelated host directories must be rejected when sessions are known');
  const blockedRev = await scopedRevision.fetch(
    new Request(`http://localhost/api/jj.revision?cwd=${encodeURIComponent(unrelated)}&rev=@`),
  );
  assert.equal(blockedRev.status, 403, 'revision inspection must enforce the same session directory scope');
  const siblingResp = await scopedOverview.fetch(
    new Request(`http://localhost/api/jj.overview?cwd=${encodeURIComponent(sibling)}`),
  );
  assert.equal(siblingResp.status, 200, 'sibling workspaces of an open repository remain inspectable');
});

test('the runtime entry forwards the commit policy into the registered prompt context', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-apply-policy');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const { Context } = await import('@deepseek-ai/cordis');
  const runtimeEntry = await import('@aqian0/dsh-jj');

  interface CapturedPromptContext {
    readonly name: string;
    readonly text: (context: { readonly agent?: { readonly session?: unknown } } | undefined) => string;
  }

  /** Apply the runtime entry over a fresh Cordis context with the two DSH services faked. */
  const applyWith = (
    config: Parameters<typeof runtimeEntry.apply>[1],
  ): { captured: CapturedPromptContext[]; text: string } => {
    const captured: CapturedPromptContext[] = [];
    const ctx = new Context();
    ctx.provide('systemPrompt');
    ctx.set('systemPrompt', {
      context: (context: CapturedPromptContext) => {
        captured.push(context);
        return () => {};
      },
      getContextOrder: () => 100,
    });
    ctx.provide('workingDirectory');
    ctx.set('workingDirectory', { get: () => repo });
    runtimeEntry.apply(ctx, config);
    const text = captured[0]?.text({ agent: { session: { id: 'policy' } } }) ?? '';
    return { captured, text };
  };

  const angular = applyWith({ preferJjContext: true, commitStyle: 'angular' });
  assert.equal(angular.captured.length, 1, 'exactly one global prompt context is registered');
  assert.equal(angular.captured[0]?.name, 'dsh-jj-workspace');
  assert.match(angular.text, /Angular commit convention/, 'commitStyle reaches the model context');
  assert.match(angular.text, /Commit granularity/, 'preferSplitCommits defaults on');

  const disabled = applyWith({ preferJjContext: false, commitStyle: 'angular' });
  assert.equal(disabled.captured.length, 0, 'preferJjContext:false registers no context at all');
});

test('the runtime entry forwards live top-level sessions into the multi-session guidance', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-apply-parallel');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const { Context } = await import('@deepseek-ai/cordis');
  const runtimeEntry = await import('@aqian0/dsh-jj');

  interface CapturedPromptContext {
    readonly name: string;
    readonly text: (context: { readonly agent?: { readonly session?: unknown } } | undefined) => string;
  }

  /**
   * Apply the runtime entry with fake systemPrompt/workingDirectory/agents services.
   *
   * `turnState` fakes the host's `sessionProjections.stateOf(session, 'turnBoundary')`
   * activity read: `{openTurnStartSeq: null}` is an idle session, a sequence number is an
   * open turn; omitting the map fakes an older host without the projection (unknown).
   */
  const applyWith = (
    config: Parameters<typeof runtimeEntry.apply>[1],
    roots: ReadonlyArray<{ readonly session: unknown }>,
    turnState?: ReadonlyMap<unknown, unknown> | ((session: unknown) => unknown),
  ): string => {
    const captured: CapturedPromptContext[] = [];
    const ctx = new Context();
    ctx.provide('systemPrompt');
    ctx.set('systemPrompt', {
      context: (context: CapturedPromptContext) => {
        captured.push(context);
        return () => {};
      },
      getContextOrder: () => 100,
    });
    ctx.provide('workingDirectory');
    ctx.set('workingDirectory', { get: () => repo });
    if (roots.length > 0) {
      ctx.provide('agents');
      ctx.set('agents', { roots: () => roots });
    }
    if (turnState !== undefined) {
      ctx.provide('sessionProjections');
      ctx.set('sessionProjections', {
        stateOf: (session: unknown, key: string) => {
          assert.equal(key, 'turnBoundary', 'the activity read must use the agent-loop projection');
          return typeof turnState === 'function' ? turnState(session) : turnState.get(session);
        },
      });
    }
    runtimeEntry.apply(ctx, config);
    return captured[0]?.text({ agent: roots[0] !== undefined ? { session: roots[0].session } : undefined }) ?? '';
  };

  const current = { id: 'apply-current' };
  const peer = { id: 'apply-peer' };
  const activeTurn = new Map<unknown, unknown>([
    [current, { openTurnStartSeq: 1 }],
    [peer, { openTurnStartSeq: 5 }],
  ]);
  const parallel = applyWith({}, [{ session: current }, { session: peer }], activeTurn);
  assert.match(parallel, /Parallel sessions: another DSH session is running in this Jujutsu working copy/);
  assert.match(parallel, /jj_workspace_add/);
  assert.match(parallel, /standard rebase hand-off/);

  const idleTurn = new Map<unknown, unknown>([
    [current, { openTurnStartSeq: 1 }],
    [peer, { openTurnStartSeq: null }],
  ]);
  const idle = applyWith({}, [{ session: current }, { session: peer }], idleTurn);
  assert.ok(!idle.includes('Parallel sessions'), 'an idle live peer is not concurrent work');
  assert.ok(!idle.includes('jj_workspace_add'), 'a single active session keeps its current working copy');
  assert.match(idle, /Jujutsu \(jj\) workspace/, 'the base jj preference is unaffected');

  const unknown = applyWith({}, [{ session: current }, { session: peer }], undefined);
  assert.match(unknown, /Parallel sessions/, 'a host without activity reporting keeps the fail-open behavior');

  const throwingRead = applyWith({}, [{ session: current }, { session: peer }], () => {
    throw new Error('projection exploded');
  });
  assert.match(throwingRead, /Parallel sessions/, 'a throwing activity read stays fail-open and never breaks assembly');
  assert.match(throwingRead, /Jujutsu \(jj\) workspace/, 'the base jj guidance survives a throwing projection');

  const malformedRead = applyWith({}, [{ session: current }, { session: peer }], () => ({}));
  assert.match(malformedRead, /Parallel sessions/, 'an unexpected projection shape stays fail-open');
  assert.match(malformedRead, /Jujutsu \(jj\) workspace/, 'the base jj guidance survives a malformed projection');

  const off = applyWith({ multiSessionGuidance: 'off' }, [{ session: current }, { session: peer }], activeTurn);
  assert.ok(!off.includes('Parallel sessions'), 'off disables the injected section');

  const always = applyWith({ multiSessionGuidance: 'always' }, [{ session: current }], idleTurn);
  assert.match(always, /separate dsh processes/, 'always covers cross-process parallel sessions');

  assert.throws(() => applyWith({ rebaseTarget: '   ' }, [{ session: current }]), /rebaseTarget/);
});

test('runtime heartbeats deduplicate in-process peers, flip idle on turn/end, and respect read-only mode', async (t) => {
  const fx = makeFixture(t, 'dsh-jj-apply-heartbeats');
  const repo = await initJjColocated(fx.run, fx.path('repo'));
  const outside = fx.path('outside');
  mkdirSync(outside, { recursive: true });
  const jjRepoPath = sniffVcsSync(repo).jjRepoPath;
  assert.ok(jjRepoPath !== undefined, 'fixture repo must expose jjRepoPath');
  const { Context } = await import('@deepseek-ai/cordis');
  const runtimeEntry = await import('@aqian0/dsh-jj');

  interface CapturedPromptContext {
    readonly name: string;
    readonly text: (context: { readonly agent?: { readonly session?: unknown } } | undefined) => string;
  }

  const sessionA = { id: 'hb-peer' };
  const sessionB = { id: 'hb-current' };
  const subagent = { id: 'hb-subagent', header: { origin: 'subagent', delegationDepth: 1 } };
  const cwdBySession = new Map<unknown, string>([
    [sessionA, repo],
    [sessionB, repo],
    [subagent, repo],
  ]);
  const turnState = new Map<unknown, unknown>([
    [sessionA, { openTurnStartSeq: 1 }],
    [sessionB, { openTurnStartSeq: null }],
  ]);
  let sandboxMode: 'read-only' | 'workspace-write' = 'workspace-write';

  const captured: CapturedPromptContext[] = [];
  const ctx = new Context();
  ctx.provide('systemPrompt');
  ctx.set('systemPrompt', {
    context: (context: CapturedPromptContext) => {
      captured.push(context);
      return () => {};
    },
    getContextOrder: () => 100,
  });
  ctx.provide('workingDirectory');
  ctx.set('workingDirectory', { get: (session: unknown) => cwdBySession.get(session) });
  ctx.provide('agents');
  ctx.set('agents', { roots: () => [{ session: sessionA }, { session: sessionB }] });
  ctx.provide('sessionProjections');
  ctx.set('sessionProjections', { stateOf: (session: unknown) => turnState.get(session) });
  ctx.provide('sandboxPolicy');
  ctx.set('sandboxPolicy', { resolve: () => ({ mode: sandboxMode, workspaceRoot: repo }) });
  runtimeEntry.apply(ctx, {});

  // 1. Session A runs an active turn: its heartbeat is written with `active: true`.
  const firstTurn = captured[0]?.text({ agent: { session: sessionA } }) ?? '';
  assert.ok(!firstTurn.includes('Parallel sessions'), 'session B is idle during session A turn');
  const peerHbFile = sessionHeartbeatPath(jjRepoPath, sessionA.id);
  assert.equal(existsSync(peerHbFile), true);
  assert.equal((JSON.parse(readFileSync(peerHbFile, 'utf8')) as { active?: boolean }).active, true);

  // 2. Even if `sessionA` still had `active: true` on disk before `turn/end` processed,
  // an in-process assembly for `sessionB` trusts `turnBoundary` (`openTurnStartSeq: null`)
  // and excludes in-process peers from disk heartbeats instead of double-counting them.
  turnState.set(sessionA, { openTurnStartSeq: null });
  turnState.set(sessionB, { openTurnStartSeq: 2 });
  const secondTurnInProcess = captured[0]?.text({ agent: { session: sessionB } }) ?? '';
  assert.ok(
    !secondTurnInProcess.includes('Parallel sessions'),
    'stale active:true disk heartbeat of an in-process idle peer must not trigger parallel isolation',
  );

  // 3. `turn/end` immediately marks the on-disk heartbeat `active: false` while keeping
  // the file alive for cross-process ownership liveness.
  (ctx as unknown as { emit: (event: string, ...args: unknown[]) => void }).emit('session/event', sessionA, {
    type: 'turn/end',
    data: { turn: 0 },
  });
  const afterTurnEnd = JSON.parse(readFileSync(peerHbFile, 'utf8')) as { active?: boolean };
  assert.equal(afterTurnEnd.active, false, 'turn/end must clear active:true on disk');

  // A separate DSH process reading the same repository now sees `sessionA` as idle too.
  const otherProcessCaptured: CapturedPromptContext[] = [];
  const otherCtx = new Context();
  otherCtx.provide('systemPrompt');
  otherCtx.set('systemPrompt', {
    context: (context: CapturedPromptContext) => {
      otherProcessCaptured.push(context);
      return () => {};
    },
    getContextOrder: () => 100,
  });
  otherCtx.provide('workingDirectory');
  otherCtx.set('workingDirectory', { get: () => repo });
  const remoteSession = { id: 'hb-remote' };
  otherCtx.provide('agents');
  otherCtx.set('agents', { roots: () => [{ session: remoteSession }] });
  otherCtx.provide('sessionProjections');
  otherCtx.set('sessionProjections', { stateOf: () => ({ openTurnStartSeq: 1 }) });
  // Ensure `sessionB` also finishes its turn first so both earlier turns are idle on disk.
  (ctx as unknown as { emit: (event: string, ...args: unknown[]) => void }).emit('session/event', sessionB, {
    type: 'turn/end',
    data: { turn: 0 },
  });
  runtimeEntry.apply(otherCtx, {});
  const crossProcessText = otherProcessCaptured[0]?.text({ agent: { session: remoteSession } }) ?? '';
  assert.ok(
    !crossProcessText.includes('Parallel sessions'),
    'cross-process peers whose turns ended must not look concurrently active',
  );

  // 4. Delegated subagents never publish a heartbeat file.
  captured[0]?.text({ agent: { session: subagent } });
  assert.equal(existsSync(sessionHeartbeatPath(jjRepoPath, subagent.id)), false);

  // 5. Moving a tracked session outside any jj repository removes its old heartbeat;
  // disposing a session removes its heartbeat immediately.
  (ctx as unknown as { emit: (event: string, ...args: unknown[]) => void }).emit('session/event', sessionA, {
    type: 'working-directory/change',
    data: { cwd: outside },
  });
  assert.equal(existsSync(peerHbFile), false, 'leaving the jj repository clears the old heartbeat');

  assert.equal(existsSync(sessionHeartbeatPath(jjRepoPath, sessionB.id)), true);
  (ctx as unknown as { emit: (event: string, ...args: unknown[]) => void }).emit('session/disposed', sessionB);
  assert.equal(existsSync(sessionHeartbeatPath(jjRepoPath, sessionB.id)), false, 'dispose removes the heartbeat');

  // 6. Under `read-only` sandboxPolicy, prompt assembly neither writes a new heartbeat
  // nor purges expired heartbeat files from `.jj/repo/dsh-jj/sessions/`.
  writeSessionHeartbeat(jjRepoPath, {
    sessionId: 'hb-expired',
    cwd: repo,
    workspaceName: 'default',
    workspaceRoot: repo,
    active: false,
    updatedAt: 1,
  });
  sandboxMode = 'read-only';
  const readOnlySession = { id: 'hb-readonly' };
  cwdBySession.set(readOnlySession, repo);
  ctx.set('agents', { roots: () => [{ session: readOnlySession }] });
  captured[0]?.text({ agent: { session: readOnlySession } });
  assert.equal(
    existsSync(sessionHeartbeatPath(jjRepoPath, readOnlySession.id)),
    false,
    'read-only mode must not write heartbeat files',
  );
  assert.ok(
    readdirSync(join(jjRepoPath, SESSION_HEARTBEAT_DIR)).includes('hb-expired.json'),
    'read-only mode must not delete expired heartbeat files',
  );
});

/** Map a subpath step in the loadability loop to the emitted entry file. */
function entryFile(specifier: string): string {
  if (specifier === './tools') return 'tools.js';
  if (specifier === './guard') return 'guard.js';
  if (specifier === './changes') return 'changes.js';
  return 'index.js';
}

test('assembleBaseLayer still returns undefined (with one warning) without a tool registry', async () => {
  const runtimeEntry = await import('@aqian0/dsh-jj');
  const warnings: string[] = [];
  const bareContext = { logger: { warn: (message: string) => warnings.push(message) } };
  assert.equal(runtimeEntry.assembleBaseLayer(bareContext as unknown as never), undefined);
  assert.equal(warnings.length, 1);
  assert.match(warnings[0] ?? '', /tools service is unavailable/);
});

/** Recursively collect hand-written JavaScript files under one source directory. */
function collectJavaScript(dir: string, found: string[] = []): string[] {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) {
      collectJavaScript(path, found);
    } else if (/\.(?:js|mjs|cjs)$/.test(entry.name)) {
      found.push(relative(packageDir, path));
    }
  }
  return found;
}

test('all hand-written source is TypeScript (only built lib/ may contain JavaScript)', () => {
  const offenders = ['src', 'test'].flatMap((dir) => collectJavaScript(join(packageDir, dir)));
  assert.deepEqual(offenders, [], `hand-written JavaScript must be migrated to TypeScript: ${offenders.join(', ')}`);
});

/** Recursively collect hand-written TypeScript files under one directory. */
function collectTypeScript(dir: string, found: string[] = []): string[] {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) {
      collectTypeScript(path, found);
    } else if (entry.name.endsWith('.ts')) {
      found.push(path);
    }
  }
  return found;
}

test('hand-written TypeScript has no tabs, trailing whitespace, or CRLF line endings', async (t) => {
  const problems: string[] = [];
  const longLines: string[] = [];
  const files = ['src', 'test'].flatMap((dir) => collectTypeScript(join(packageDir, dir)));
  files.push(join(packageDir, 'vite.config.ts'));
  for (const file of files) {
    const relativePath = relative(packageDir, file);
    const text = readFileSync(file, 'utf8');
    if (text.includes('\r')) problems.push(`${relativePath}: CRLF line ending`);
    text.split('\n').forEach((line, index) => {
      const location = `${relativePath}:${index + 1}`;
      if (line.includes('\t')) problems.push(`${location}: tab character`);
      if (/[ \t]+$/.test(line)) problems.push(`${location}: trailing whitespace`);
      if (line.length > 120) longLines.push(location);
    });
  }
  assert.deepEqual(problems, [], `style problems: ${problems.join(', ')}`);
  if (longLines.length > 0) {
    // Oxfmt wraps at 120 columns, so this is now a regression warning, not a style gate.
    await t.annotate(
      `${longLines.length} lines exceed 120 columns (warning only, not failing): ${longLines.slice(0, 5).join(', ')}`,
    );
  }
});

test('bundle patch carries the jj-aware project-root row and the change-recording rows', () => {
  const patch = readFileSync(join(packageDir, 'cordis.patch.yml'), 'utf8');
  assert.match(patch, /- insert:[\s\S]*name: '@aqian0\/dsh-jj'/, 'the runtime row is declared');
  assert.match(patch, /name: '@aqian0\/dsh-jj\/tools'/, 'the tools row is declared');
  assert.match(patch, /name: '@aqian0\/dsh-jj\/guard'/, 'the guard row is declared');
  assert.match(patch, /name: '@aqian0\/dsh-jj\/changes'/, 'the jj change-recording row is declared');
  assert.match(
    patch,
    /^- id: workspace-changes$\n  name: '@deepseek-ai\/dsh-workspace-changes'\n  disabled: true$/m,
    'the built-in Git-only workspace-changes row must be disabled so jj owns the changed-files card',
  );
  assert.match(patch, /^- id: agent-instructions$/m, 'the id-targeted agent-instructions row is declared');
  assert.match(patch, /name: '@deepseek-ai\/dsh-agent-instructions'/);
  assert.match(patch, /maxBytes: 65536/, 'the composed maxBytes value must be restated (whole-config replacement)');
  assert.match(patch, /projectRootMarkers: \['\.git', '\.jj'\]/, 'jj must be a project-root marker');

  // The checks above only prove that some matching lines exist. The host's patch
  // algorithm is additive, so a SECOND `workspace-changes` row (or a later
  // `disabled: false`) would re-enable the Git-only provider while every
  // string-presence assertion still passes (A5-F3). Pin the composed semantics.
  assert.equal(
    (patch.match(/^- id: workspace-changes$/gm) ?? []).length,
    1,
    'the patch must disable the built-in workspace-changes row exactly once',
  );
  assert.doesNotMatch(patch, /disabled:\s*false/, 'no patch row may re-enable a disabled row');
  const insertedIds = [...patch.matchAll(/^ {4}- id: (jj-[a-z]+)$/gm)].map((match) => match[1]);
  assert.deepEqual(
    [...insertedIds].sort(),
    ['jj-changes', 'jj-guard', 'jj-runtime', 'jj-tools'],
    'the four jj bundle rows must be inserted exactly once each',
  );
});
