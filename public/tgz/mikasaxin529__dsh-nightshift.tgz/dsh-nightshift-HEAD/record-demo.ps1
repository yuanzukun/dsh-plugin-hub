# dsh-nightshift demo GIF recorder — captures a 1270x800 window of the dsh web
# GUI with ffmpeg gdigrab, for embedding in the README.
# Usage: powershell -File record-demo.ps1 -Seconds 30
param(
    [int]$Seconds = 30,
    [string]$Out = "demo-raw.mp4"
)
$ErrorActionPreference = 'Stop'

# 1. bring the browser window to front (best effort)
Add-Type -AssemblyName System.Windows.Forms
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32 {
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindowW(string cls, string title);
}
"@
$sw = [Diagnostics.Stopwatch]::StartNew()
$hwnd = [IntPtr]::Zero
while ($sw.Elapsed.TotalSeconds -lt 5 -and $hwnd -eq [IntPtr]::Zero) {
    Get-Process | Where-Object { $_.MainWindowTitle -match 'dsh|DeepSeek|127\.0\.0\.1' -and $_.MainWindowHandle -ne 0 } | ForEach-Object {
        if ($_.ProcessName -match 'chrome|msedge|firefox|browser') { $script:hwnd = $_.MainWindowHandle }
    }
    Start-Sleep -Milliseconds 500
}
if ($hwnd -ne [IntPtr]::Zero) {
    [Win32]::MoveWindow($hwnd, 40, 40, 1280, 820, $true) | Out-Null
    [Win32]::SetForegroundWindow($hwnd) | Out-Null
    Write-Host "recorder: browser window positioned (hwnd $hwnd)"
} else {
    Write-Host "recorder: browser window not found — recording top-left region anyway" -ForegroundColor Yellow
}
Start-Sleep -Milliseconds 800

# 2. record with ffmpeg gdigrab
$ffmpeg = (Get-Command ffmpeg -ErrorAction Stop).Source
& $ffmpeg -y -f gdigrab -framerate 12 -video_size 1280x800 -offset_x 48 -offset_y 88 `
    -i desktop -t $Seconds -pix_fmt yuv420p -c:v libx264 -preset veryfast -crf 26 $Out
Write-Host "recorder: wrote $Out"
