# dsh-nightshift installer — official channel first (dsh plugin add), manual
# fallback (junction + patch entry) for setups without the `dsh` CLI.
#
# Usage:
#   .\install.ps1                                   # official: dsh plugin --profile web add .
#   .\install.ps1 -Profile headless                 # another profile
#   .\install.ps1 -Manual -Target <node_modules> [-Profile <dir>]   # manual fallback
#
# The official channel (dsh ≥ 0.1.x) links the repo into the profile's own
# node_modules via pnpm and appends the package to dsh.profile.bundles —
# no cordis.patch.yml edit is needed (the bundle layer carries the plugin's
# own patch). The manual fallback reproduces that by hand: a junction into
# the node_modules the loader resolves from plus an insert entry in the
# profile's cordis.patch.yml.

param(
    [string]$Profile = 'web',
    [switch]$Manual,
    [string]$Target,
    [string]$Dsh = 'dsh'
)

$ErrorActionPreference = 'Stop'
$pluginName = 'dsh-nightshift'
$source = $PSScriptRoot

function Fail([string]$message) {
    Write-Host "nightshift: $message" -ForegroundColor Red
    exit 1
}

# --- 0. sanity ---------------------------------------------------------------

if (-not (Test-Path (Join-Path $source 'client.js'))) { Fail "run from the plugin repo (client.js not found in $source)" }
if (-not (Test-Path (Join-Path $source 'index.js')))  { Fail "index.js not found in $source" }

$pkg = [System.IO.File]::ReadAllText((Join-Path $source 'package.json')) | ConvertFrom-Json
if ($pkg.exports.'./client' -ne './client.js') { Fail "package.json exports['./client'] is malformed" }
if (-not (Test-Path (Join-Path $source $pkg.exports.'./client'))) { Fail "client export target missing" }
if ($pkg.dsh.client.platform -ne 'web') { Fail "package.json dsh.client.platform must be 'web'" }

# --- official channel --------------------------------------------------------

if (-not $Manual) {
    Write-Host "nightshift: profile = $Profile"
    Write-Host "nightshift: plugin  = $source"
    Write-Host ''
    $dshBin = Get-Command $Dsh -ErrorAction SilentlyContinue
    if ($null -eq $dshBin) {
        Write-Host "nightshift: '$Dsh' not found on PATH — falling back to manual mode" -ForegroundColor Yellow
        $Manual = $true
    } else {
        Write-Host "nightshift: installing via official channel (dsh plugin add)"
        & $Dsh plugin --profile $Profile add $source
        if ($LASTEXITCODE -ne 0) {
            Fail "dsh plugin add failed (exit $LASTEXITCODE); fix the error above or retry with -Manual"
        }
        Write-Host ''
        Write-Host "nightshift: installed via official channel. Restart dsh (or reload the profile) to activate." -ForegroundColor Green
        exit 0
    }
}

# --- manual fallback: target/profile resolution ------------------------------

if ([string]::IsNullOrWhiteSpace($Target)) {
    Fail "manual mode needs -Target: the node_modules directory the loader resolves plugins from (for the default dsh layout that is the shared ~/.dsh/profiles/node_modules)"
}
if (-not (Test-Path $Target)) {
    Fail "target directory '$Target' does not exist (expected a node_modules the loader resolves plugins from)"
}
$nodeModules = (Resolve-Path $Target).Path
if ([string]::IsNullOrWhiteSpace($Profile) -or $Profile -eq 'web') {
    # -Profile carried its default through; manual mode wants a directory.
    $profileRoot = Join-Path (Split-Path -Parent $nodeModules) 'web'
} else {
    $profileRoot = $Profile
}
if (-not (Test-Path $profileRoot)) {
    Fail "profile directory '$profileRoot' does not exist (it should hold cordis.patch.yml)"
}
$profileRoot = (Resolve-Path $profileRoot).Path
$destination = Join-Path $nodeModules $pluginName

Write-Host "nightshift: profile  = $profileRoot"
Write-Host "nightshift: plugin   = $source"
Write-Host "nightshift: install  = $destination"
Write-Host ''

# --- 1. link (junction preferred, copy fallback) -----------------------------

if (Test-Path $destination) {
    $existing = Get-Item $destination -Force
    if ($existing.LinkType -eq 'Junction' -or $existing.LinkType -eq 'SymbolicLink') {
        $resolved = $existing.Target
        if (@($resolved) -contains $source) {
            Write-Host "nightshift: junction already points at this repo — skipping link" -ForegroundColor Yellow
        } else {
            Fail "$destination is a link to another location; remove it first or pass the right target"
        }
    } else {
        Fail "$destination already exists and is not a link; remove it first (a stale copy would shadow the repo)"
    }
} elseif (-not (Test-Path $destination)) {
    $linked = $true
    try {
        New-Item -ItemType Junction -Path $destination -Target $source | Out-Null
        Write-Host "nightshift: junction created"
    } catch {
        $linked = $false
        Write-Host "nightshift: junction failed ($($_.Exception.Message)) — falling back to copy" -ForegroundColor Yellow
    }
    if (-not $linked) {
        try {
            New-Item -ItemType SymbolicLink -Path $destination -Target $source | Out-Null
            Write-Host "nightshift: symbolic link created"
        } catch {
            Copy-Item -Recurse -Force $source $destination
            Write-Host "nightshift: copied (no link — config edits need a re-run)" -ForegroundColor Yellow
        }
    }
}

# --- 2. patch entry (idempotent) ---------------------------------------------
#
# The patch file is a top-level YAML ARRAY. Textually appending "- insert:"
# after a "[]" root produces TWO top-level nodes — invalid YAML that fails the
# loader's parse at boot. Merge instead: drop a lone "[]" root (keep comments
# and any existing entries) and append our entry as the last array item.

$patchPath = Join-Path $profileRoot 'cordis.patch.yml'
if (-not (Test-Path $patchPath)) {
    New-Item -ItemType File $patchPath -Force | Out-Null
    Write-Host "nightshift: created empty $patchPath"
}
$patchContent = [System.IO.File]::ReadAllText($patchPath)
if ($patchContent -match '(?m)^\s*-\s*id:\s*nightshift\s*$') {
    Write-Host "nightshift: patch entry already present — skipping"
} else {
    $entry = "- insert:`n  - id: nightshift`n    name: dsh-nightshift"
    # Strip a bare root "[]" (comments around it survive); other roots keep
    # their entries so ours lands as a new item, not a second document.
    $body = $patchContent -replace '(?m)^\s*\[\]\s*$', ''
    $trimmed = $body.TrimEnd("`r`n", ' ', "`t")
    $separator = if ($trimmed -eq '') { '' } else { "`n" }
    [System.IO.File]::WriteAllText($patchPath, $trimmed + $separator + $entry + "`n",
        [System.Text.UTF8Encoding]::new($false))
    Write-Host "nightshift: patch entry appended to $patchPath"
}

# --- 3. verify linked copy ---------------------------------------------------

$pkg2 = [System.IO.File]::ReadAllText((Join-Path $destination 'package.json')) | ConvertFrom-Json
if ($pkg2.exports.'./client' -ne './client.js') { Fail "linked package.json exports['./client'] is malformed" }
if (-not (Test-Path (Join-Path $destination $pkg2.exports.'./client'))) { Fail "client export target missing in link" }
Write-Host "nightshift: exports verified (./client -> $($pkg2.exports.'./client'))"

Write-Host ''
Write-Host "nightshift: installed (manual). Restart dsh (or reload the loader profile) to activate." -ForegroundColor Green
