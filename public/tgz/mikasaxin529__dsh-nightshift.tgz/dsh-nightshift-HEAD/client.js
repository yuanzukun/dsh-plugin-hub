/**
 * dsh-nightshift — client-side web plugin (hand-authored module-loader factory).
 *
 * Shape contract (packages/client/tsdown.client.ts:566-568): a classic script
 * calling `window.__ModuleLoader__.load({ id, factory })`; the factory receives
 * a synchronous `require` that resolves only the platform seed table
 * (packages/client/web/src/platform.ts:8-14). Seed values are `import * as`
 * namespace objects, so exports arrive as named properties.
 *
 * This file is executed verbatim by the browser — no transpiler, so no JSX:
 * every element is React.createElement via the `h` alias.
 *
 * Registers two slots (components never touch ctx — props only):
 *  - conversation.input.dock  → the enqueue chip above the composer
 *  - sidebar.footer.action    → the panel entry at the sidebar foot
 *
 * Both halves read `GET /api/nightshift/state` (same-origin fetch, cookie
 * auth) on a poll; writes go through the POST routes the host half owns.
 * All copy is Chinese (v1 scope); classes are `nightshift-` prefixed and
 * colors come only from `--dsw-alias-*` / `--dsw-specific-*` tokens.
 *
 * @module dsh-nightshift/client
 */

window.__ModuleLoader__.load({ id: "dsh-nightshift", factory: (require) => {
  var module = { exports: {} }; var exports = module.exports;

  // ---- platform requires (seed table = `import * as` namespaces) -----------

  const React = require('react')
  const { useState, useEffect, useRef, useCallback, Fragment } = React
  const { createElement: h } = React
  const { createPortal } = require('react-dom')
  const {
    useAnchoredPosition,
    useDismissOnOutsidePointer,
    IconCloseOutline16,
    IconNewChatOutline16,
    IconPlayOutline16,
  } = require('@deepseek-ai/dsh-client-ui-primitives')

  // ---- copy ----------------------------------------------------------------

  const STR = {
    chipPeak: '等低谷',
    chipOffPeak: '夜航中',
    chipCountdown: (label) => ` ${label}`,
    chipQueued: (n) => `已排队 ${n} 个`,
    chipEmptyHint: '把输入框草稿交给夜航，低谷时自动执行',
    chipNoDraft: '输入框没有内容',
    chipContinueHint: '把输入框草稿交给夜航，低谷时在当前会话继续执行',
    chipFresh: '新会话',
    chipFreshHint: '低谷时在新会话执行（目录：',
    chipFreshDefault: 'dsh 默认目录）',
    enqueueFailed: '入队失败',
    enqueued: '已入队',
    enqueuedFresh: '已入队（新会话）',
    peakBadge: '高峰 · 冻结派发',
    offPeakBadge: '低谷 · 自动执行',
    nextTransition: (label) => `下次切换 ${label}`,
    panelTitle: '夜航',
    close: '关闭',
    panelEmpty: '队列为空。把输入框草稿交给夜航，低谷时段会自动逐个执行。',
    panelLoading: '读取中…',
    panelError: '连接失败，稍后自动重试',
    queueSection: (n) => `排队 ${n}`,
    historySection: '历史',
    runNow: '立即跑',
    cancel: '取消',
    actionFailed: '操作失败',
    retryLabel: (n) => `重试 ${n}`,
    reportTitle: (date) => `${date} 报告`,
    reportTasks: (t) => `共 ${t.total} 个 · 成功 ${t.done} · 失败 ${t.failed} · 待人工 ${t.blocked}`,
    reportTokens: (v) => `tokens ${v}`,
    reportCost: (v) => `实际花费 ${v}`,
    reportSaved: (v) => `省下 ${v}`,
  }

  // ---- state polling ---------------------------------------------------------

  const POLL_OPEN_MS = 30_000
  const POLL_CLOSED_MS = 120_000
  const FETCH_DEDUPE_MS = 5_000

  /**
   * One shared fetch + subscribers. Both slots poll the same state route;
   * a single in-flight dedupe keeps the chip and the panel consistent and
   * halves the request rate when both are visible.
   */
  function createStateClient() {
    let state = null          // last successful body
    let error = null
    let revision = 0          // bumps on every settle; components re-read via it
    const listeners = new Set()
    let inFlight = null
    let lastFetchAt = 0

    function notify() {
      revision += 1
      for (const listener of listeners) listener()
    }

    function refresh(force) {
      const now = Date.now()
      if (!force && now - lastFetchAt < FETCH_DEDUPE_MS) return Promise.resolve()
      if (inFlight !== null) return inFlight
      lastFetchAt = now
      inFlight = fetch('/api/nightshift/state', { cache: 'no-store' })
        .then((response) => {
          if (!response.ok) throw new Error(`HTTP ${response.status}`)
          return response.json()
        })
        .then((body) => { state = body; error = null; notify() })
        .catch((cause) => {
          // State stays at the last good snapshot; a transient failure must
          // not blank the panel (SPEC §10: silent retry).
          error = cause instanceof Error ? cause.message : String(cause)
          notify()
        })
        .finally(() => { inFlight = null })
      return inFlight
    }

    return {
      subscribe(listener) {
        listeners.add(listener)
        return () => { listeners.delete(listener) }
      },
      snapshot() { return { state, error, revision } },
      refresh,
    }
  }

  const stateClient = createStateClient()

  /** Identity-stable snapshot getter: re-renders ride the listener, not this. */
  let cachedSnapshot = null
  let cachedSnapshotRev = -1
  function getSnapshot() {
    const snap = stateClient.snapshot()
    if (snap.revision !== cachedSnapshotRev) {
      cachedSnapshot = snap
      cachedSnapshotRev = snap.revision
    }
    return cachedSnapshot
  }

  /**
   * Poll while mounted; the period adapts to `active` (panel open vs closed).
   * State updates arrive through the shared store, so an HMR remount picks the
   * last snapshot up again instead of depending on component-local memory.
   * Opening the panel force-refreshes past the fetch dedupe: host-side changes
   * (a turn settling, a cancel) otherwise wait out the whole poll period.
   */
  function useNightshiftState(active) {
    const [, setTick] = useState(0)
    const tickRef = useRef(0)
    const activeRef = useRef(active)
    activeRef.current = active

    useEffect(() => {
      function onNotify() {
        tickRef.current += 1
        setTick(tickRef.current)
      }
      const unsubscribe = stateClient.subscribe(onNotify)
      // A rising edge (panel opening) always re-reads; a mount or a closing
      // edge keeps the dedupe so rapid toggles stay cheap.
      stateClient.refresh(active)
      let timer
      function arm() {
        timer = setTimeout(() => {
          stateClient.refresh(false)
          arm()
        }, activeRef.current ? POLL_OPEN_MS : POLL_CLOSED_MS)
      }
      arm()
      return () => {
        unsubscribe()
        clearTimeout(timer)
      }
    }, [active])
    return getSnapshot()
  }

  /** POST one action route; resolves to { ok, error, body }. */
  async function postAction(path, payload) {
    try {
      const response = await fetch(path, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        cache: 'no-store',
        body: JSON.stringify(payload),
      })
      const body = await response.json().catch(() => ({}))
      if (!response.ok || body.ok === false) {
        return { ok: false, error: body.error || `HTTP ${response.status}` }
      }
      return { ok: true, body }
    } catch (cause) {
      return { ok: false, error: cause instanceof Error ? cause.message : String(cause) }
    }
  }

  // ---- presentation helpers (lib/format.js semantics, re-inlined) -----------
  // The host half imports lib/format.js through ESM; this factory cannot reach
  // the host's module graph, so the display helpers are re-implemented here
  // (pure, zero-dependency, same output shapes as lib/format.js).

  const STATUS_LABEL = {
    queued: '排队中', running: '执行中', done: '已完成',
    failed: '失败', blocked: '待人工', cancelled: '已取消',
  }
  const STATUS_COLOR = {
    queued: 'var(--dsw-alias-label-tertiary)',
    running: 'var(--dsw-alias-state-business-primary)',
    done: 'var(--dsw-alias-state-success-primary)',
    failed: 'var(--dsw-alias-state-error-primary)',
    blocked: 'var(--dsw-alias-state-warn-primary)',
    cancelled: 'var(--dsw-alias-label-dimmed)',
  }

  function labelOf(status) { return STATUS_LABEL[status] || String(status) }
  function colorOf(status) { return STATUS_COLOR[status] || STATUS_COLOR.queued }

  function formatCountdown(msRemaining) {
    if (msRemaining == null || !Number.isFinite(msRemaining)) return '—'
    if (msRemaining <= 0) return '即将'
    const totalSeconds = Math.floor(msRemaining / 1000)
    const days = Math.floor(totalSeconds / 86_400)
    const hours = Math.floor((totalSeconds % 86_400) / 3600)
    const minutes = Math.floor((totalSeconds % 3600) / 60)
    if (days > 0) return `${days}天${hours}小时`
    if (hours > 0) return `${hours}小时${minutes}分`
    if (minutes > 0) return `${minutes}分`
    return '即将'
  }

  /** Remaining ms until the next window transition, from server timestamps. */
  function transitionRemaining(state) {
    if (state?.nextTransitionAt == null || state?.now == null) return null
    return state.nextTransitionAt - state.now
  }

  function formatTokens(n) {
    if (n == null || !Number.isFinite(n)) return '0'
    return new Intl.NumberFormat('zh-CN').format(Math.round(n))
  }

  function formatMoney(value, currency) {
    const num = value == null || !Number.isFinite(value) ? 0 : value
    const body = new Intl.NumberFormat('zh-CN', {
      minimumFractionDigits: 2, maximumFractionDigits: 2,
    }).format(num)
    return `${currency || '¥'}${body}`
  }

  function summarizePrompt(text, max = 80) {
    if (text == null) return ''
    const flat = String(text).replace(/\s+/g, ' ').trim()
    if (flat.length <= max) return flat
    return `${flat.slice(0, max - 1)}…`
  }

  /** Local HH:MM for a timestamp, in the browser's zone (running-row metadata). */
  function formatClock(at) {
    if (at == null) return ''
    const date = new Date(at)
    const pad = (n) => String(n).padStart(2, '0')
    return `${pad(date.getHours())}:${pad(date.getMinutes())}`
  }

  // ---- the enqueue chip (conversation.input.dock) ---------------------------
  //
  // Owner props: { session: SessionSnapshot, input: InputState } (InputZone).
  // The session standard kit adds inputActions (setDraft) and useWorkspaces
  // (the global standard kit). The chip reads the draft from owner props and
  // clears it through inputActions after a successful enqueue; inputActions is
  // optional-chained so a kit without it still enqueues (the draft just stays
  // in the composer).

  /**
   * The workspace path the current Session belongs to, when the Workspace UI
   * is loaded and one of its rows accounts this session. Fresh targets carry
   * it as `cwd` so the new session lands in the same workspace (dsh groups by
   * directory path); an ungrouped session yields undefined (host default cwd).
   * Called at RENDER time only — `useWorkspaces` is a useSyncExternalStore
   * selector hook, and calling it in an event handler would throw.
   */
  function workspaceCwdOf(useWorkspaces, sessionId) {
    if (typeof useWorkspaces !== 'function' || sessionId == null) return undefined
    const workspaces = useWorkspaces(snapshot => snapshot)
    const items = workspaces?.items ?? []
    const found = items.find((workspace) =>
      (workspace.sessionIds ?? []).includes(sessionId))
    return found?.path
  }

  function NightshiftChip({ session, input, inputActions, useWorkspaces }) {
    // The chip renders no surface of its own: it always polls at the
    // closed-panel cadence.
    const snap = useNightshiftState(false)
    const [notice, setNotice] = useState(null)
    const [pending, setPending] = useState(false)

    const sessionId = session?.sessionId
    const draft = typeof input?.draft === 'string' ? input.draft : ''
    const hasDraft = draft.trim() !== ''
    const state = snap.state
    // Read at render time (hook rules) and snapshotted: the path the fresh
    // enqueue uses is the workspace owning the session when the chip rendered.
    const currentCwd = workspaceCwdOf(useWorkspaces, sessionId)

    const peak = state?.window === 'peak'
    const countdown = formatCountdown(transitionRemaining(state))
    const queuedCount = state?.queue?.length ?? 0

    const enqueue = useCallback(async (mode) => {
      if (pending || !hasDraft || sessionId == null) return
      setPending(true)
      setNotice(null)
      const target = mode === 'fresh'
        ? { mode: 'fresh', ...(currentCwd != null ? { cwd: currentCwd } : {}) }
        : { mode: 'continue', sessionId }
      const result = await postAction('/api/nightshift/enqueue', {
        prompt: draft,
        target,
        source: 'panel',
      })
      setPending(false)
      if (result.ok) {
        // Success: clear the composer draft so the text lives only in the queue.
        try { inputActions?.setDraft('') } catch { /* draft API is advisory */ }
        setNotice(mode === 'fresh' ? STR.enqueuedFresh : STR.enqueued)
        stateClient.refresh(true)
      } else {
        setNotice(result.error || STR.enqueueFailed)
      }
    }, [pending, hasDraft, sessionId, draft, inputActions, currentCwd])

    if (sessionId == null) return null

    const hint = notice ?? (hasDraft ? STR.chipEmptyHint : STR.chipNoDraft)

    return h('div', { className: 'nightshift-chip' },
      h('button', {
        type: 'button',
        className: 'nightshift-chip-btn',
        disabled: pending || !hasDraft,
        title: STR.chipContinueHint,
        onClick: () => { void enqueue('continue') },
      },
        h('span', { className: 'nightshift-chip-glyph', 'aria-hidden': true },
          peak ? '🌙' : '🚀'),
        h('span', { className: 'nightshift-chip-label' },
          peak ? STR.chipPeak : STR.chipOffPeak),
        state?.nextTransitionAt != null && h('span', { className: 'nightshift-chip-count' },
          STR.chipCountdown(countdown)),
      ),
      h('button', {
        type: 'button',
        className: 'nightshift-chip-btn nightshift-chip-fresh',
        disabled: pending || !hasDraft,
        title: currentCwd != null
          ? STR.chipFreshHint + currentCwd + '）'
          : STR.chipFreshHint + STR.chipFreshDefault,
        onClick: () => { void enqueue('fresh') },
      },
        h(IconNewChatOutline16, { size: 14 }),
        h('span', { className: 'nightshift-chip-label' }, STR.chipFresh),
      ),
      queuedCount > 0 && h('span', { className: 'nightshift-chip-queued' },
        STR.chipQueued(queuedCount)),
      notice != null && h('span', {
        className: notice === STR.enqueued || notice === STR.enqueuedFresh
          ? 'nightshift-notice nightshift-notice-ok'
          : 'nightshift-notice nightshift-notice-bad',
      }, notice),
    )
  }

  // ---- the sidebar panel entry (sidebar.footer.action) ----------------------
  //
  // Owner props: { wide: boolean }. A trigger row (wide) or icon (rail) opens
  // a portaled popover: window banner, running task, queue list with
  // run-now / cancel, terminal history, and the latest report summary.

  function NightshiftPanelButton({ wide }) {
    const [open, setOpen] = useState(false)
    const snap = useNightshiftState(open)
    const state = snap.state
    const rootRef = useRef(null)
    const triggerRef = useRef(null)
    const panelRef = useRef(null)
    const position = useAnchoredPosition({
      open,
      anchorRef: triggerRef,
      panelRef,
      side: 'top',
      gap: 5,
      margin: 16,
    })

    useDismissOnOutsidePointer(rootRef, open, setOpen, panelRef)

    // Escape closes and restores focus to the trigger (ScheduleCatalogAction).
    function onKeyDown(event) {
      if (event.key !== 'Escape' || !open) return
      event.preventDefault()
      setOpen(false)
      if (typeof triggerRef.current?.focus === 'function') triggerRef.current.focus()
    }

    // History rows arrive pre-filtered and capped by the host (terminal only,
    // newest 50) — the queue array carries only queued rows.
    const attention = (state?.history ?? [])
      .filter((task) => task.status === 'blocked' || task.status === 'failed').length

    const running = state?.running ?? null
    const queued = state?.queue ?? []
    const terminal = state?.history ?? []
    const lastReport = state?.lastReport ?? null
    const currency = state?.config?.currency ?? '¥'
    const allowRunNow = state?.config?.allowRunNow !== false

    const peak = state?.window === 'peak'
    const countdown = formatCountdown(transitionRemaining(state))

    const trigger = h('button', {
      ref: triggerRef,
      type: 'button',
      className: wide ? 'nightshift-entry' : 'nightshift-entry nightshift-entry-rail',
      'aria-expanded': open,
      'aria-label': STR.panelTitle,
      title: STR.panelTitle,
      onClick: () => { setOpen((v) => !v) },
    },
      h('span', { className: 'nightshift-entry-glyph', 'aria-hidden': true }, '🌙'),
      wide && h('span', { className: 'nightshift-entry-label' }, STR.panelTitle),
      attention > 0 && h('span', { className: 'nightshift-entry-badge' }, String(attention)),
    )

    const panel = open
      ? createPortal(
        h('div', {
          ref: panelRef,
          className: 'nightshift-panel',
          style: position ?? { visibility: 'hidden', left: 0, top: 0 },
          role: 'dialog',
          'aria-label': STR.panelTitle,
        },
          h('header', { className: 'nightshift-panel-head' },
            h('span', { className: 'nightshift-panel-title' }, STR.panelTitle),
            h('button', {
              type: 'button',
              className: 'nightshift-panel-close',
              'aria-label': STR.close,
              onClick: () => { setOpen(false) },
            }, h(IconCloseOutline16, { size: 14 })),
          ),
          state != null && h('div', {
            className: peak
              ? 'nightshift-window nightshift-window-peak'
              : 'nightshift-window',
          },
            h('span', null, peak ? STR.peakBadge : STR.offPeakBadge),
            state.nextTransitionAt != null && h('span', { className: 'nightshift-window-next' },
              STR.nextTransition(countdown)),
          ),
          state == null
            ? h('p', { className: 'nightshift-muted' },
              snap.error ? STR.panelError : STR.panelLoading)
            : h(Fragment, null,
              running != null && h(RunningRow, { task: running }),
              queued.length > 0 && h('section', { className: 'nightshift-section' },
                h('h3', { className: 'nightshift-section-title' }, STR.queueSection(queued.length)),
                queued.map((task) => h(TaskRow, {
                  key: task.id,
                  task,
                  allowRunNow: allowRunNow && running == null,
                  onDone: () => { stateClient.refresh(true) },
                })),
              ),
              terminal.length > 0 && h('section', { className: 'nightshift-section' },
                h('h3', { className: 'nightshift-section-title' }, STR.historySection),
                terminal.map((task) => h(TaskRow, {
                  key: task.id, task, allowRunNow: false, onDone: () => {},
                })),
              ),
              running == null && queued.length === 0 && terminal.length === 0
                && h('p', { className: 'nightshift-muted' }, STR.panelEmpty),
              lastReport != null && h(ReportBlock, {
                report: lastReport, currency,
              }),
            ),
        ),
        document.body,
      )
      : null

    return h('div', { ref: rootRef, className: 'nightshift-root', onKeyDown },
      trigger,
      panel,
    )
  }

  /** The live task row (single, above the queue section). */
  function RunningRow({ task }) {
    const clock = formatClock(task.lastAttemptAt)
    return h('div', { className: 'nightshift-row nightshift-row-running' },
      h(StatusDot, { status: 'running' }),
      h('span', { className: 'nightshift-row-prompt' }, summarizePrompt(task.prompt)),
      h('span', { className: 'nightshift-row-meta' },
        labelOf(task.status) + (clock === '' ? '' : ` · ${clock}`)),
    )
  }

  /** One queue/history row with run-now + cancel actions. */
  function TaskRow({ task, allowRunNow, onDone }) {
    const [busy, setBusy] = useState(false)
    const [error, setError] = useState(null)

    async function act(path) {
      if (busy) return
      setBusy(true)
      setError(null)
      const result = await postAction(path, { taskId: task.id })
      setBusy(false)
      if (!result.ok) setError(result.error || STR.actionFailed)
      onDone()
    }

    const cancellable = task.status === 'queued' || task.status === 'running'

    return h('div', { className: 'nightshift-row' },
      h(StatusDot, { status: task.status }),
      h('span', { className: 'nightshift-row-prompt' }, summarizePrompt(task.prompt)),
      h('span', { className: 'nightshift-row-meta' },
        labelOf(task.status)
        + (task.attempts > 0 ? ` · ${STR.retryLabel(task.attempts)}` : '')),
      task.lastError != null && h('span', {
        className: 'nightshift-row-error', title: task.lastError,
      }, task.lastError),
      (allowRunNow && task.status === 'queued') || cancellable
        ? h('span', { className: 'nightshift-row-actions' },
          allowRunNow && task.status === 'queued' && h('button', {
            type: 'button',
            className: 'nightshift-iconbtn',
            title: STR.runNow,
            'aria-label': STR.runNow,
            disabled: busy,
            onClick: () => { void act('/api/nightshift/task/run-now') },
          }, h(IconPlayOutline16, { size: 14 })),
          cancellable && h('button', {
            type: 'button',
            className: 'nightshift-iconbtn',
            title: STR.cancel,
            'aria-label': STR.cancel,
            disabled: busy,
            onClick: () => { void act('/api/nightshift/task/cancel') },
          }, h(IconCloseOutline16, { size: 14 })),
        ) : null,
      error != null && h('span', {
        className: 'nightshift-notice nightshift-notice-bad',
      }, error),
    )
  }

  /** Latest report summary: task counts, token total, cost, savings. */
  function ReportBlock({ report, currency }) {
    const tokens = report.tokens ?? {}
    const totalTokens = (tokens.uncachedInput ?? 0) + (tokens.output ?? 0)
      + (tokens.cacheRead ?? 0) + (tokens.cacheWrite ?? 0)
    return h('section', { className: 'nightshift-section nightshift-report' },
      h('h3', { className: 'nightshift-section-title' }, STR.reportTitle(report.date)),
      h('p', { className: 'nightshift-report-line' }, STR.reportTasks(report.tasks)),
      h('p', { className: 'nightshift-report-line' },
        `${STR.reportTokens(formatTokens(totalTokens))} · `
        + `${STR.reportCost(formatMoney(report.cost, currency))} · `,
        h('span', { className: 'nightshift-report-saved' },
          STR.reportSaved(formatMoney(report.savedVsPeak, currency))),
      ),
    )
  }

  function StatusDot({ status }) {
    return h('span', {
      className: 'nightshift-dot',
      'aria-hidden': true,
      style: { background: colorOf(status) },
    })
  }

  // ---- styles (self-inserted <style>, nightshift- prefixed, token colors) ---
  // Every color is a --dsw-alias-* / --dsw-specific-* token; the theme layer
  // re-resolves them per light/dark, so this stylesheet holds no theme branch.

  const STYLE_ID = 'nightshift-client-style'

  const STYLE_TEXT = `
.nightshift-root { position: relative; }
.nightshift-chip {
  display: flex; align-items: center; gap: 8px;
  margin: 0 auto; padding: 2px 0 0;
  width: calc(100% - 16px);
  font-size: 12px; color: var(--dsw-alias-label-tertiary);
}
.nightshift-chip-btn {
  display: inline-flex; align-items: center; gap: 6px;
  min-height: 26px; padding: 2px 10px;
  border: 1px solid var(--dsw-alias-border-l2); border-radius: 999px;
  background: var(--dsw-specific-tip);
  color: var(--dsw-alias-label-secondary);
  font-size: 12px; line-height: 18px; cursor: pointer;
}
.nightshift-chip-btn:hover:not(:disabled),
.nightshift-chip-btn:focus-visible:not(:disabled) { color: var(--dsw-alias-label-primary); }
.nightshift-chip-btn:disabled { opacity: .6; cursor: default; }
.nightshift-chip-fresh { padding: 2px 8px; }
.nightshift-chip-glyph { line-height: 1; }
.nightshift-chip-count { color: var(--dsw-alias-label-tertiary); }
.nightshift-chip-queued { color: var(--dsw-alias-label-tertiary); }
.nightshift-notice { font-size: 11px; color: var(--dsw-alias-label-tertiary); }
.nightshift-notice-ok { color: var(--dsw-alias-state-success-primary); }
.nightshift-notice-bad { color: var(--dsw-alias-state-error-primary); }
.nightshift-entry {
  display: flex; align-items: center; gap: 8px;
  min-height: 32px; padding: 4px 10px;
  border: 0; border-radius: 8px;
  background: transparent; cursor: pointer;
  color: var(--dsw-alias-label-secondary); font-size: 12px;
}
.nightshift-entry:hover, .nightshift-entry:focus-visible { color: var(--dsw-alias-label-primary); }
.nightshift-entry-rail { justify-content: center; width: 100%; padding: 4px 0; }
.nightshift-entry-badge {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 16px; height: 16px; padding: 0 4px;
  border-radius: 999px;
  background: var(--dsw-alias-state-warn-primary);
  color: var(--dsw-alias-state-warn-label);
  font-size: 10px; line-height: 1;
}
.nightshift-panel {
  position: fixed; z-index: 100;
  box-sizing: border-box;
  display: flex; flex-direction: column; gap: 8px;
  width: 340px; max-width: min(340px, calc(100vw - 32px));
  max-height: min(480px, calc(100vh - 32px));
  padding: 10px;
  overflow: auto;
  border: 1px solid var(--dsw-alias-border-l2); border-radius: 12px;
  background: var(--dsw-specific-menu);
  --dsh-scrollbar-thumb: var(--dsw-alias-scrollbar-bg-l2);
  --dsh-scrollbar-thumb-hover: var(--dsw-alias-scrollbar-hover-l2);
  box-shadow: var(--dsw-shadow-lv3);
  font-size: 12px; color: var(--dsw-alias-label-primary);
}
.nightshift-panel-head {
  display: flex; align-items: center; justify-content: space-between;
}
.nightshift-panel-title { font-size: 13px; font-weight: 600; color: var(--dsw-alias-label-primary); }
.nightshift-panel-close {
  display: inline-flex; align-items: center;
  border: 0; border-radius: 6px; background: transparent;
  color: var(--dsw-alias-label-tertiary); cursor: pointer;
}
.nightshift-panel-close:hover { color: var(--dsw-alias-label-secondary); }
.nightshift-window {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 4px 8px; border-radius: 8px;
  background: var(--dsw-alias-state-business-tertiary);
  color: var(--dsw-alias-label-primary);
}
.nightshift-window-peak {
  background: var(--dsw-alias-state-warn-tertiary);
  color: var(--dsw-alias-state-warn-label);
}
.nightshift-window-next { font-size: 11px; }
.nightshift-section { display: flex; flex-direction: column; gap: 4px; }
.nightshift-section-title {
  margin: 0; font-size: 11px; font-weight: 600;
  color: var(--dsw-alias-label-tertiary);
}
.nightshift-muted { margin: 0; color: var(--dsw-alias-label-tertiary); }
.nightshift-row {
  display: grid;
  grid-template-columns: auto 1fr auto auto;
  align-items: start; gap: 4px 8px;
  padding: 6px 8px; border-radius: 8px;
  color: var(--dsw-alias-label-primary);
}
.nightshift-row:hover { background: var(--dsw-alias-interactive-bg-hover); }
.nightshift-row-prompt { overflow-wrap: anywhere; }
.nightshift-row-meta {
  color: var(--dsw-alias-label-tertiary); font-size: 11px; white-space: nowrap;
}
.nightshift-row-error {
  grid-column: 2 / -1;
  color: var(--dsw-alias-state-error-primary); font-size: 11px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.nightshift-row-actions { display: inline-flex; gap: 4px; }
.nightshift-iconbtn {
  display: inline-flex; align-items: center;
  border: 0; border-radius: 6px; background: transparent;
  color: var(--dsw-alias-label-tertiary); cursor: pointer;
}
.nightshift-iconbtn:hover:not(:disabled) { color: var(--dsw-alias-label-secondary); }
.nightshift-iconbtn:disabled { opacity: .5; cursor: default; }
.nightshift-dot { width: 8px; height: 8px; margin-top: 5px; border-radius: 50%; flex: none; }
.nightshift-report { border-top: 1px solid var(--dsw-alias-border-l2); padding-top: 8px; }
.nightshift-report-line { margin: 0; color: var(--dsw-alias-label-secondary); }
.nightshift-report-saved { color: var(--dsw-alias-state-success-primary); }
`

  function ensureStyles() {
    if (document.getElementById(STYLE_ID) != null) return
    const style = document.createElement('style')
    style.id = STYLE_ID
    style.textContent = STYLE_TEXT
    document.head.appendChild(style)
  }

  // ---- plugin face ----------------------------------------------------------

  exports.name = 'nightshift-client'
  exports.inject = ['slots']

  exports.apply = function (ctx) {
    ensureStyles()

    // Input-dock chip: session-scoped list slot. Owner props carry the
    // InputZone ({ session, input }); the session standard kit provides
    // inputActions. slots.inject tolerates a load order where the declaring
    // package (ui-conversation) activates after this plugin.
    ctx.slots.inject('conversation.input.dock', () => ctx.slots.register(
      { name: 'conversation.input.dock', id: 'nightshift-chip', order: 30 },
      NightshiftChip,
    ))

    // Sidebar foot entry: root-scoped list slot, owner props { wide }.
    ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register(
      { name: 'sidebar.footer.action', id: 'nightshift-panel', order: 30 },
      NightshiftPanelButton,
    ))
  }

  return module.exports
} })
