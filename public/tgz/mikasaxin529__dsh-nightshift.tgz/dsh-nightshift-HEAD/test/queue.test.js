import { describe, it, expect } from 'vitest'
import {
  isTerminal,
  isDue,
  dueTasks,
  makeTaskRow,
  normalizeEnqueueRequest,
  applyTurnEnd,
  reconcileOrphans,
  deferToTail,
  cancelTask,
} from '../lib/queue.js'

/** No-jitter env so backoff deadlines are exactly base×factor^n. */
const env = {
  now: 1000,
  maxRetries: 3,
  continuationLimit: 3,
  retryBaseMs: 60_000,
  retryFactor: 2,
  retryMaxMs: 1_800_000,
  jitterFraction: 0,
  rand: () => 0.5,
}

const running = (overrides = {}) => ({
  id: 't1',
  prompt: 'p',
  target: { mode: 'continue', sessionId: 's' },
  createdAt: 1,
  status: 'running',
  attempts: 0,
  continuations: 0,
  enqueueSource: 'panel',
  ...overrides,
})

describe('isTerminal / isDue', () => {
  it('classifies terminal statuses', () => {
    for (const status of ['done', 'failed', 'blocked', 'cancelled']) {
      expect(isTerminal({ status })).toBe(true)
    }
    for (const status of ['queued', 'running']) {
      expect(isTerminal({ status })).toBe(false)
    }
  })

  it('a queued row without nextRetryAt is due; with a future one is not', () => {
    expect(isDue({ status: 'queued' }, 5)).toBe(true)
    expect(isDue({ status: 'queued', nextRetryAt: 4 }, 5)).toBe(true)
    expect(isDue({ status: 'queued', nextRetryAt: 6 }, 5)).toBe(false)
    expect(isDue({ status: 'running' }, 99)).toBe(false)
  })
})

describe('dueTasks', () => {
  it('filters non-queued and not-yet-due, then orders by createdAt FIFO', () => {
    const rows = [
      running({ id: 'r', status: 'running' }),
      { id: 'a', status: 'queued', createdAt: 30 },
      { id: 'b', status: 'queued', createdAt: 10 },
      { id: 'c', status: 'queued', createdAt: 20, nextRetryAt: 9999 }, // not due
      { id: 'd', status: 'done', createdAt: 1 },
    ]
    expect(dueTasks(rows, 100).map(row => row.id)).toEqual(['b', 'a'])
  })

  it('a matured retry interleaves into plain FIFO by createdAt', () => {
    const rows = [
      { id: 'new', status: 'queued', createdAt: 50 },
      { id: 'retry', status: 'queued', createdAt: 10, nextRetryAt: 40 },
    ]
    expect(dueTasks(rows, 100).map(row => row.id)).toEqual(['retry', 'new'])
  })

  it('returns a new array; input untouched', () => {
    const rows = [{ id: 'x', status: 'queued', createdAt: 1 }]
    const out = dueTasks(rows, 1)
    expect(out).not.toBe(rows)
  })
})

describe('makeTaskRow / normalizeEnqueueRequest', () => {
  it('mints a fresh queued row', () => {
    const row = makeTaskRow({ id: 'nightshift-1', prompt: 'hi', target: { mode: 'fresh', cwd: '/w' }, nowMs: 7 })
    expect(row).toEqual({
      id: 'nightshift-1', prompt: 'hi', target: { mode: 'fresh', cwd: '/w' },
      createdAt: 7, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
  })

  it('accepts both target modes', () => {
    expect(normalizeEnqueueRequest({ prompt: 'x', target: { mode: 'continue', sessionId: 's' } }))
      .toEqual({ prompt: 'x', target: { mode: 'continue', sessionId: 's' } })
    expect(normalizeEnqueueRequest({ prompt: 'x', target: { mode: 'fresh', cwd: 'c' } }))
      .toEqual({ prompt: 'x', target: { mode: 'fresh', cwd: 'c' } })
  })

  it('accepts a fresh target without cwd (ungrouped origin, host default)', () => {
    expect(normalizeEnqueueRequest({ prompt: 'x', target: { mode: 'fresh' } }))
      .toEqual({ prompt: 'x', target: { mode: 'fresh' } })
    expect(() => normalizeEnqueueRequest({ prompt: 'x', target: { mode: 'fresh', cwd: '' } })).toThrow()
    expect(() => normalizeEnqueueRequest({ prompt: 'x', target: { mode: 'fresh', cwd: 7 } })).toThrow()
  })

  it('rejects malformed bodies', () => {
    expect(() => normalizeEnqueueRequest(null)).toThrow()
    expect(() => normalizeEnqueueRequest({ prompt: '  ' })).toThrow()
    expect(() => normalizeEnqueueRequest({ prompt: 'x'.repeat(100_001), target: { mode: 'fresh', cwd: 'c' } })).toThrow()
    expect(() => normalizeEnqueueRequest({ prompt: 'x', target: { mode: 'nope' } })).toThrow()
    expect(() => normalizeEnqueueRequest({ prompt: 'x', target: { mode: 'continue' } })).toThrow()
    expect(() => normalizeEnqueueRequest({ prompt: 'x' })).toThrow()
  })
})

describe('applyTurnEnd — the §5 matrix', () => {
  it('completed → done, terminal, slot released', () => {
    const o = applyTurnEnd(running(), { kind: 'completed' }, env)
    expect(o.action).toBe('settle')
    expect(o.row.status).toBe('done')
    expect(o.row.lastError).toBeUndefined()
  })

  it('error under the cap → queued retry with backoff deadline, attempts++', () => {
    const o = applyTurnEnd(running({ attempts: 1 }), { kind: 'error', detail: 'boom' }, env)
    expect(o.action).toBe('retry')
    expect(o.row.status).toBe('queued')
    expect(o.row.attempts).toBe(2)
    expect(o.row.nextRetryAt).toBe(1000 + 60_000 * 2 ** 1) // base×factor^2-1
    expect(o.row.lastError).toBe('error: boom')
  })

  it('error over the cap → failed', () => {
    const o = applyTurnEnd(running({ attempts: 3 }), { kind: 'error' }, env)
    expect(o.action).toBe('settle')
    expect(o.row.status).toBe('failed')
    expect(o.row.attempts).toBe(4)
  })

  it('interrupted retries like error (same backoff arm)', () => {
    const o = applyTurnEnd(running(), { kind: 'interrupted' }, env)
    expect(o.row.status).toBe('queued')
    expect(o.row.attempts).toBe(1)
  })

  it('max-tokens under the limit → keep running + continuations++', () => {
    const o = applyTurnEnd(running(), { kind: 'max-tokens' }, env)
    expect(o.action).toBe('continue')
    expect(o.row.continuations).toBe(1)
    expect(o.row.status).toBe('running')
  })

  it('max-tokens at the limit → failed with the exact §5 label', () => {
    const o = applyTurnEnd(running({ continuations: 3 }), { kind: 'max-tokens' }, env)
    expect(o.action).toBe('settle')
    expect(o.row.status).toBe('failed')
    expect(o.row.lastError).toBe('max-tokens 连续截断')
  })

  it('max-tokens does NOT bump attempts (counters never mix)', () => {
    const o = applyTurnEnd(running({ attempts: 2 }), { kind: 'max-tokens' }, env)
    expect(o.row.attempts).toBe(2)
  })

  it('error does NOT bump continuations', () => {
    const o = applyTurnEnd(running({ continuations: 1 }), { kind: 'error' }, env)
    expect(o.row.continuations).toBe(1)
  })

  it('blocked → blocked terminal, waiting for a human', () => {
    const o = applyTurnEnd(running(), { kind: 'blocked' }, env)
    expect(o.action).toBe('settle')
    expect(o.row.status).toBe('blocked')
  })

  it('aborted → cancelled, never retried', () => {
    const o = applyTurnEnd(running({ attempts: 0 }), { kind: 'aborted', detail: '{"kind":"user"}' }, env)
    expect(o.action).toBe('settle')
    expect(o.row.status).toBe('cancelled')
    expect(o.row.attempts).toBe(0)
  })

  it('an unknown merge-extensible kind fails loud as failed, not retried forever', () => {
    const o = applyTurnEnd(running({ attempts: 0 }), { kind: 'from-another-plugin' }, env)
    expect(o.action).toBe('settle')
    expect(o.row.status).toBe('failed')
    expect(o.row.attempts).toBe(0)
  })

  it('never mutates the input row', () => {
    const row = running()
    applyTurnEnd(row, { kind: 'completed' }, env)
    expect(row.status).toBe('running')
  })
})

describe('reconcileOrphans', () => {
  it('running rows re-queue with the restart note, optionals dropped', () => {
    const rows = [
      running({ id: 'r1', nextRetryAt: 5, lastError: 'stale' }),
      { id: 'q', status: 'queued', createdAt: 1, attempts: 0, continuations: 0 },
    ]
    const out = reconcileOrphans(rows)
    expect(out).toHaveLength(1)
    const { id, row } = out[0]
    expect(id).toBe('r1')
    expect(row.status).toBe('queued')
    expect(row.lastError).toBe('重启重排')
    // zod-optional fields must be absent, not null, for the next durable write.
    expect('nextRetryAt' in row).toBe(false)
    expect('lastAttemptAt' in row).toBe(false)
    // Idempotent against the row schema: no leftovers from the running state.
    expect(row.id).toBe('r1')
  })
})

describe('deferToTail', () => {
  it('re-stamps createdAt so the task lands at the queue tail', () => {
    const row = { id: 'x', status: 'queued', createdAt: 10, attempts: 0, continuations: 0 }
    const moved = deferToTail(row, 900)
    expect(moved.createdAt).toBe(900)
    expect(row.createdAt).toBe(10)
  })
})

describe('cancelTask', () => {
  it('queued cancels directly, no agent call needed', () => {
    const d = cancelTask({ id: 'x', status: 'queued' })
    expect(d.ok).toBe(true)
    expect(d.needsAgentCancel).toBe(false)
    expect(d.row.status).toBe('cancelled')
  })
  it('running cancels and requires agent.cancel first', () => {
    const d = cancelTask({ id: 'x', status: 'running' })
    expect(d.ok).toBe(true)
    expect(d.needsAgentCancel).toBe(true)
  })
  it('terminal rows reject cancellation', () => {
    for (const status of ['done', 'failed', 'blocked', 'cancelled']) {
      const d = cancelTask({ id: 'x', status })
      expect(d.ok).toBe(false)
      expect(d.error).toContain(status)
    }
  })
})
