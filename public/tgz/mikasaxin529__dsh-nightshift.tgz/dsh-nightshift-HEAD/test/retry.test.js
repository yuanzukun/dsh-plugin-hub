import { describe, it, expect } from 'vitest'
import { backoffDelayMs } from '../lib/retry.js'

const cfg = { base: 60_000, factor: 2, max: 1_800_000, jitterFraction: 0 }
const mid = () => 0.5 // jitter-neutral rand

describe('backoffDelayMs — pure sequence (no jitter)', () => {
  it('base × factor^n for n = attempts-1', () => {
    expect(backoffDelayMs(1, cfg, mid)).toBe(60_000)
    expect(backoffDelayMs(2, cfg, mid)).toBe(120_000)
    expect(backoffDelayMs(3, cfg, mid)).toBe(240_000)
    expect(backoffDelayMs(4, cfg, mid)).toBe(480_000)
  })

  it('caps at maxMs (raw 60s×2^5 = 1.92M > 30min cap)', () => {
    expect(backoffDelayMs(6, cfg, mid)).toBe(1_800_000)
    expect(backoffDelayMs(10, cfg, mid)).toBe(1_800_000)
  })

  it('rejects bad inputs loudly', () => {
    expect(() => backoffDelayMs(0, cfg, mid)).toThrow()
    expect(() => backoffDelayMs(1.5, cfg, mid)).toThrow()
    expect(() => backoffDelayMs(1, { ...cfg, factor: 0 }, mid)).toThrow()
    expect(() => backoffDelayMs(1, { ...cfg, jitterFraction: 2 }, mid)).toThrow()
  })
})

describe('backoffDelayMs — jitter bounds', () => {
  const j = { base: 60_000, factor: 2, max: 1_800_000, jitterFraction: 0.2 }

  it('rand 0/0.5/1 map to -20%/±0/+20%', () => {
    expect(backoffDelayMs(1, j, () => 0)).toBe(48_000)
    expect(backoffDelayMs(1, j, () => 0.5)).toBe(60_000)
    expect(backoffDelayMs(1, j, () => 0.999999)).toBeCloseTo(72_000, 0)
  })

  it('output always stays within ±fraction of the raw value', () => {
    for (let attempts = 1; attempts <= 8; attempts += 1) {
      const raw = Math.min(60_000 * 2 ** (attempts - 1), 1_800_000)
      for (let i = 0; i < 50; i += 1) {
        const d = backoffDelayMs(attempts, j)
        expect(d).toBeGreaterThanOrEqual(Math.max(0, raw * 0.8 - 1))
        expect(d).toBeLessThanOrEqual(raw * 1.2 + 1)
      }
    }
  })

  it('never negative', () => {
    expect(backoffDelayMs(1, { ...j, jitterFraction: 1 }, () => 0)).toBe(0)
  })
})
