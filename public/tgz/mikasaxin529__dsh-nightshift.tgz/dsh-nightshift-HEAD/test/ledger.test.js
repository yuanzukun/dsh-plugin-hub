import { describe, it, expect } from 'vitest'
import {
  zeroBuckets,
  bucketsFromTotals,
  tokenDelta,
  addBuckets,
  totalTokens,
  costOfBuckets,
  savedVsPeakOfBuckets,
  recordTaskUsage,
  summarizePrompt,
  reportEntryFromTask,
  assembleReport,
  mergeReports,
} from '../lib/ledger.js'

describe('bucketsFromTotals', () => {
  it('maps the token-meter projection field names onto ledger buckets', () => {
    expect(bucketsFromTotals({
      uncachedInputTokens: 1, outputTokens: 2, cacheReadTokens: 3, cacheWriteTokens: 4,
    })).toEqual({ uncachedInput: 1, output: 2, cacheRead: 3, cacheWrite: 4 })
  })
  it('missing totals read as zeros', () => {
    expect(bucketsFromTotals(undefined)).toEqual(zeroBuckets())
    expect(bucketsFromTotals({ outputTokens: 5 })).toEqual({ uncachedInput: 0, output: 5, cacheRead: 0, cacheWrite: 0 })
  })
})

describe('tokenDelta', () => {
  it('per-bucket after-minus-before', () => {
    expect(tokenDelta({ uncachedInput: 10, output: 5, cacheRead: 20, cacheWrite: 1 },
      { uncachedInput: 30, output: 9, cacheRead: 25, cacheWrite: 1 })).toEqual({
      uncachedInput: 20, output: 4, cacheRead: 5, cacheWrite: 0,
    })
  })
  it('compaction-driven regressions clamp to zero, never negative', () => {
    expect(tokenDelta({ uncachedInput: 100 }, { uncachedInput: 10 })).toEqual({
      uncachedInput: 0, output: 0, cacheRead: 0, cacheWrite: 0,
    })
  })
})

describe('addBuckets / totalTokens', () => {
  it('sums any number of records', () => {
    expect(addBuckets({ uncachedInput: 1 }, { uncachedInput: 2, output: 3 }, undefined))
      .toEqual({ uncachedInput: 3, output: 3, cacheRead: 0, cacheWrite: 0 })
  })
  it('totals the four buckets', () => {
    expect(totalTokens({ uncachedInput: 1, output: 2, cacheRead: 3, cacheWrite: 4 })).toBe(10)
  })
})

describe('costing', () => {
  const all1M = { uncachedInput: 250_000, output: 250_000, cacheRead: 250_000, cacheWrite: 250_000 }
  it('four buckets × price / 1e6', () => {
    expect(costOfBuckets(all1M, 2)).toBeCloseTo(2, 10)
    expect(costOfBuckets(zeroBuckets(), 5)).toBe(0)
  })
  it('savedVsPeak = same usage at peak price minus actual', () => {
    expect(savedVsPeakOfBuckets(all1M, 2, 1)).toBeCloseTo(1, 10)
    expect(savedVsPeakOfBuckets(all1M, 2, 2)).toBe(0)
    // A peak-priced run "saves" negative against a cheaper assumed price.
    expect(savedVsPeakOfBuckets(all1M, 1, 2)).toBeCloseTo(-1, 10)
  })
})

describe('recordTaskUsage', () => {
  it('accumulates tokens and money across attempts', () => {
    const first = recordTaskUsage({ attempts: 0, continuations: 0 }, { uncachedInput: 10, output: 1, cacheRead: 0, cacheWrite: 0 }, { windowPrice: 1, peakPrice: 2 })
    const second = recordTaskUsage(first, { uncachedInput: 5, output: 0, cacheRead: 5, cacheWrite: 0 }, { windowPrice: 1, peakPrice: 2 })
    expect(second.tokens).toEqual({ uncachedInput: 15, output: 1, cacheRead: 5, cacheWrite: 0 })
    expect(second.cost).toBeCloseTo(21e-6, 10)
    expect(second.savedVsPeak).toBeCloseTo(21e-6, 10)
    // Input row untouched.
    expect(first.tokens.uncachedInput).toBe(10)
  })
})

describe('summarizePrompt', () => {
  it('collapses whitespace and truncates with an ellipsis at the limit', () => {
    expect(summarizePrompt('a\n b\t c')).toBe('a b c')
    const long = 'x'.repeat(100)
    const digest = summarizePrompt(long)
    expect(digest.length).toBe(80)
    expect(digest.endsWith('…')).toBe(true)
  })
  it('short prompts pass through', () => {
    expect(summarizePrompt('hi')).toBe('hi')
  })
})

const task = (overrides) => ({
  id: 't', prompt: 'p', status: 'done', attempts: 0,
  tokens: { uncachedInput: 100, output: 50, cacheRead: 0, cacheWrite: 0 },
  cost: 0.00015, savedVsPeak: 0.000075, ...overrides,
})

describe('report assembly', () => {
  it('roll-ups counts, buckets, money', () => {
    const entries = [
      reportEntryFromTask(task({ id: 'a' })),
      reportEntryFromTask(task({ id: 'b', status: 'failed', attempts: 2 })),
      reportEntryFromTask(task({ id: 'c', status: 'cancelled' })),
      reportEntryFromTask(task({ id: 'd', status: 'blocked' })),
    ]
    const report = assembleReport(entries, { dateKey: '2026-09-01', generatedAt: 5, window: 'off-peak' })
    expect(report.date).toBe('2026-09-01')
    expect(report.window).toBe('off-peak')
    expect(report.tasks).toEqual({ total: 4, done: 1, failed: 1, blocked: 1, cancelled: 1, retried: 1 })
    expect(report.tokens).toEqual({ uncachedInput: 400, output: 200, cacheRead: 0, cacheWrite: 0 })
    expect(report.cost).toBeCloseTo(0.0006, 10)
    expect(report.savedVsPeak).toBeCloseTo(0.0003, 10)
    expect(report.perTask).toHaveLength(4)
  })

  it('retried counts tasks with attempts>0', () => {
    const report = assembleReport([reportEntryFromTask(task({ attempts: 1 }))], { dateKey: 'd', generatedAt: 1, window: 'peak' })
    expect(report.tasks.retried).toBe(1)
  })
})

describe('mergeReports', () => {
  const meta = { dateKey: '2026-09-01', generatedAt: 100, window: 'off-peak' }
  it('fresh report with no existing one is returned as-is', () => {
    const fresh = assembleReport([reportEntryFromTask(task())], meta)
    expect(mergeReports(undefined, fresh)).toBe(fresh)
  })

  it('keeps historical entries and replaces same-id ones (re-run case)', () => {
    const morning = assembleReport([
      reportEntryFromTask(task({ id: 'a', cost: 1, savedVsPeak: 2 })),
      reportEntryFromTask(task({ id: 'b', cost: 3, savedVsPeak: 4 })),
    ], { ...meta, generatedAt: 50 })
    const night = assembleReport([
      reportEntryFromTask(task({ id: 'b', cost: 10, savedVsPeak: 20 })), // re-run, full new record
      reportEntryFromTask(task({ id: 'c', cost: 100, savedVsPeak: 200 })), // brand new task
    ], meta)
    const merged = mergeReports(morning, night)
    const ids = merged.perTask.map(e => e.id).sort()
    expect(ids).toEqual(['a', 'b', 'c'])
    const b = merged.perTask.find(e => e.id === 'b')
    expect(b.cost).toBe(10) // the new entry superseded the morning one
    expect(merged.cost).toBeCloseTo(1 + 10 + 100, 10)
    expect(merged.savedVsPeak).toBeCloseTo(2 + 20 + 200, 10)
    expect(merged.date).toBe('2026-09-01')
    expect(merged.generatedAt).toBe(100)
  })
})
