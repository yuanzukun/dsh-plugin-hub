/**
 * index.js dispatch behavior against a mocked cordis context.
 *
 * The real @deepseek-ai/* packages are installed as devDependencies and used
 * unmocked for the pure parts they provide (schemastery Config defaults,
 * zod-backed defineDomain, createUserMessage) — they carry no host state, so
 * exercising them for real is a stronger test than mocking. Only the context
 * services (storage, sessions, connection, webServer) are faked.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { EventEmitter } from 'node:events'
import { apply, Config, inject, name } from '../index.js'

const TZ = 'Asia/Shanghai'
/** SH wall clock = UTC+8 all September (no DST), so SH(h) = UTC(h−8). */
const shMs = (day, hour, minute = 0) => Date.UTC(2026, 8, day, hour - 8, minute)

const DEFAULT_CONFIG = {
  ...Config.apply({}),
  tickMs: 100,
  drainGapMs: 0,
  timeZone: TZ,
}

// ---- fake context -----------------------------------------------------------

function clone(value) {
  return value === undefined ? undefined : structuredClone(value)
}

function fakeTable() {
  const map = new Map()
  return {
    map,
    get: key => clone(map.get(key)),
    put: async (key, value) => { map.set(key, structuredClone(value)) },
    delete: async key => map.delete(key),
    entries: () => [...map.entries()].map(([key, value]) => [key, clone(value)]),
    update: async (key, fn) => {
      const next = structuredClone(fn(clone(map.get(key))))
      map.set(key, next)
      return clone(next)
    },
  }
}

class FakeAgent {
  constructor(sessionId, { status = 'idle' } = {}) {
    this.session = { id: sessionId }
    this.status = status
    this.followups = []
    this.cancels = []
  }
  followup(message) {
    this.followups.push(message)
  }
  cancel(cause, options) {
    this.cancels.push({ cause, options })
  }
}

function makeCtx(overrides = {}) {
  const config = { ...DEFAULT_CONFIG, ...overrides }
  const tables = { queue: fakeTable(), reports: fakeTable() }
  const domainClosed = { value: false }
  const effects = []
  const listeners = { 'session/event': [] }
  const fetchRoutes = new Map()
  const webRoutes = new Map()
  const workspaces = [] // { path } — known to the fake registry
  const agents = new Map() // sessionId -> FakeAgent
  const totals = new Map() // sessionId -> projection totals
  const created = []
  const attached = [] // { workspacePath, sessionId } — workspaceRegistry.attach calls
  const logger = { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() }

  const ctx = {
    logger,
    storageDomain: {
      open: async spec => ({
        table: tableName => tables[tableName],
        close: async () => { domainClosed.value = true },
      }),
    },
    effect: (fn) => {
      const disposer = fn()
      effects.push(disposer)
      return disposer
    },
    on: (event, listener) => {
      listeners[event].push(listener)
      return () => { listeners[event] = listeners[event].filter(l => l !== listener) }
    },
    sessionController: {
      resolveAgent: async sessionId => ({ agent: agents.get(sessionId) }),
      create: async (request = {}) => {
        const sessionId = `s${created.length + 1}`
        created.push({ cwd: request.cwd, sessionId })
        agents.set(sessionId, new FakeAgent(sessionId))
        return { sessionId }
      },
    },
    workspaceRegistry: {
      resolveByPath: async (path) => {
        const known = workspaces.find(workspace => workspace.path === path)
        if (known === undefined) return undefined
        return {
          ...known,
          attachSession: async (sessionId) => { attached.push({ workspacePath: known.path, sessionId }) },
        }
      },
    },
    sessionProjections: {
      stateOf: (session, key) => key === 'tokenUsage' ? { totals: totals.get(session.id) ?? {} } : undefined,
    },
    connection: {
      // Matches the real contract: register is synchronous, the disposer async.
      fetch: { register: route => { fetchRoutes.set(route.path, route); return async () => { fetchRoutes.delete(route.path) } } },
      requestRejection: req => (req.rejected === true ? 403 : undefined),
    },
    webServer: {
      register: (route) => { webRoutes.set(route.path, route); return () => { webRoutes.delete(route.path) } },
    },
  }
  return {
    ctx, config, tables, domainClosed, effects, listeners, fetchRoutes, webRoutes, agents, totals, created, workspaces, attached,
    emitTurnEnd(session, reason) {
      for (const listener of listeners['session/event']) listener(session, { type: 'turn/end', data: { turn: 1, reason } })
    },
  }
}

/** Drive one POST through the captured webServer handler. */
async function post(webRoutes, path, body, { rejected = false } = {}) {
  const route = webRoutes.get(path)
  const req = new EventEmitter()
  req.method = 'POST'
  req.rejected = rejected
  const res = {
    statusCode: 0,
    headers: {},
    body: undefined,
    writeHead(status, headers) { this.statusCode = status; Object.assign(this.headers, headers ?? {}) },
    end(body) { this.body = body },
  }
  const done = route.handler(req, res)
  req.emit('data', Buffer.from(JSON.stringify(body)))
  req.emit('end')
  await done
  return { status: res.statusCode, json: res.body === undefined ? undefined : JSON.parse(res.body) }
}

async function get(fetchRoutes, path, url = `http://host${path}`, method = 'GET') {
  const route = fetchRoutes.get(path)
  const response = await route.fetch(new Request(url, { method }))
  const body = method === 'HEAD' ? null : await response.json()
  return { status: response.status, headers: response.headers, json: body }
}

const flush = () => vi.advanceTimersByTimeAsync(0)

// ---- tests -------------------------------------------------------------------

describe('plugin surface', () => {
  it('declares name and required services (no tools in v1)', () => {
    expect(name).toBe('nightshift')
    expect(inject).not.toContain('tools')
    expect(inject).toEqual(expect.arrayContaining(['sessionController', 'sessionProjections', 'storageDomain', 'connection', 'webServer']))
  })
})

describe('peak freeze / off-peak dispatch', () => {
  beforeEach(() => { vi.useFakeTimers() })
  afterEach(() => { vi.useRealTimers() })

  it('peak boot: queued task is NOT dispatched', async () => {
    vi.setSystemTime(shMs(1, 10)) // 10:00 SH = inside 09-12 peak
    const h = makeCtx()
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'x', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    h.agents.set('sA', new FakeAgent('sA'))
    await apply(h.ctx, h.config)
    await flush()
    expect(h.agents.get('sA').followups).toHaveLength(0)
    expect(h.tables.queue.map.get('t1').status).toBe('queued')
    // Advancing ticks keeps it frozen while peak.
    await vi.advanceTimersByTimeAsync(500)
    expect(h.agents.get('sA').followups).toHaveLength(0)
  })

  it('off-peak boot: first drain dispatches the queue head', async () => {
    vi.setSystemTime(shMs(1, 13)) // 13:00 SH = lunch valley
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'run me', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    const agent = h.agents.get('sA')
    expect(agent.followups).toHaveLength(1)
    expect(agent.followups[0].content[0].text).toBe('run me')
    expect(agent.followups[0].source).toEqual({ kind: 'plugin', plugin: 'nightshift' })
    expect(h.tables.queue.map.get('t1').status).toBe('running')
  })

  it('peak onset does not interrupt the running task', async () => {
    vi.setSystemTime(shMs(1, 11, 30)) // peak 09-12, running crosses 12:00
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await apply(h.ctx, h.config)
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await vi.advanceTimersByTimeAsync(100) // off? no — 11:30 is peak; stays queued
    expect(h.agents.get('sA').followups).toHaveLength(0)
    // Now off-peak: dispatch, then peak returns while running.
    vi.setSystemTime(shMs(1, 12, 30))
    await vi.advanceTimersByTimeAsync(100)
    expect(h.agents.get('sA').followups).toHaveLength(1)
    vi.setSystemTime(shMs(1, 14)) // 14:00 peak begins; task is running
    await vi.advanceTimersByTimeAsync(100)
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('running') // frozen means no NEW dispatch, not interruption
    // It finishes naturally during peak.
    h.totals.set('sA', { uncachedInputTokens: 500, outputTokens: 100 })
    h.emitTurnEnd({ id: 'sA' }, { kind: 'completed' })
    await flush()
    expect(h.tables.queue.map.get('t1').status).toBe('done')
  })

  it('busy target moves the task to the tail and defers', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA', { status: 'running' }))
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    expect(h.agents.get('sA').followups).toHaveLength(0)
    expect(h.tables.queue.map.get('t1').status).toBe('queued')
    expect(h.tables.queue.map.get('t1').createdAt).toBe(shMs(1, 13)) // re-stamped to tail
  })

  it('fresh target creates a session once, then continues it on retry', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'fresh', cwd: '/work' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    expect(h.created).toEqual([{ cwd: '/work', sessionId: 's1' }])
    expect(h.tables.queue.map.get('t1').target).toEqual({ mode: 'continue', sessionId: 's1' })
    const createdAgent = h.agents.get('s1')
    expect(createdAgent.followups).toHaveLength(1)
    // Fail it; retry must reuse session s1 (no second create).
    h.emitTurnEnd({ id: 's1' }, { kind: 'error', error: { message: 'boom' } })
    await flush()
    vi.setSystemTime(shMs(1, 13, 5)) // past backoff (>= base*0.8)
    h.ctx.sessionProjections.stateOf = (s, k) => k === 'tokenUsage' ? { totals: {} } : undefined
    await vi.advanceTimersByTimeAsync(5 * 60_000)
    expect(h.created).toHaveLength(1)
    expect(h.agents.get('s1').followups).toHaveLength(2)

  })

  it('fresh target without cwd (ungrouped origin) uses the host default', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'fresh' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    expect(h.created).toEqual([{ cwd: undefined, sessionId: 's1' }])
    expect(h.tables.queue.map.get('t1').target).toEqual({ mode: 'continue', sessionId: 's1' })
    expect(h.agents.get('s1').followups).toHaveLength(1)
    expect(h.attached).toEqual([]) // no cwd → no workspace lookup at all
  })

  it('fresh target with a known workspace cwd attaches the minted session to it', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    h.workspaces.push({ path: '/work' })
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'fresh', cwd: '/work' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    expect(h.attached).toEqual([{ workspacePath: '/work', sessionId: 's1' }])
    expect(h.agents.get('s1').followups).toHaveLength(1) // attach failure must not block dispatch
  })

  it('fresh target with an unknown cwd dispatches without any attach', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'fresh', cwd: '/nowhere' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    expect(h.created).toEqual([{ cwd: '/nowhere', sessionId: 's1' }])
    expect(h.attached).toEqual([])
    expect(h.agents.get('s1').followups).toHaveLength(1)
  })
})

describe('turn/end dispatch matrix', () => {
  beforeEach(() => { vi.useFakeTimers() })
  afterEach(() => { vi.useRealTimers() })

  /** Boot at 13:00 SH off-peak with one queued task already dispatched. */
  async function runningTaskHarness(overrides = {}) {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx(overrides)
    h.agents.set('sA', new FakeAgent('sA'))
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    h.totals.set('sA', { uncachedInputTokens: 1000, outputTokens: 200, cacheReadTokens: 3000, cacheWriteTokens: 50 })
    return h
  }

  it('completed → done + token accounting at the off-peak price', async () => {
    const h = await runningTaskHarness()
    h.emitTurnEnd({ id: 'sA' }, { kind: 'completed' })
    await flush()
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('done')
    expect(row.tokens).toEqual({ uncachedInput: 1000, output: 200, cacheRead: 3000, cacheWrite: 50 })
    // 4250 tokens at offPeak 1/Mtok = ¥0.00425; saved = same at peak 2 − actual.
    expect(row.cost).toBeCloseTo(0.00425, 10)
    expect(row.savedVsPeak).toBeCloseTo(0.00425, 10)
    // Queue emptied → report trigger #1 written for today.
    const report = h.tables.reports.map.get('2026-09-01')
    expect(report.tasks).toMatchObject({ total: 1, done: 1 })
    expect(report.window).toBe('off-peak')
  })

  it('error → queued with attempts+1 and a jittered backoff deadline', async () => {
    const h = await runningTaskHarness()
    h.emitTurnEnd({ id: 'sA' }, { kind: 'error', error: { message: 'upstream 500' } })
    await flush()
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('queued')
    expect(row.attempts).toBe(1)
    expect(row.lastError).toBe('error: upstream 500')
    const now = shMs(1, 13)
    expect(row.nextRetryAt).toBeGreaterThanOrEqual(now + 60_000 * 0.8 - 1)
    expect(row.nextRetryAt).toBeLessThanOrEqual(now + 60_000 * 1.2 + 1)
    // Not re-dispatched before the backoff matures…
    await vi.advanceTimersByTimeAsync(100)
    expect(h.agents.get('sA').followups).toHaveLength(1)
    // …but it is once matured.
    vi.setSystemTime(now + 10 * 60_000)
    await vi.advanceTimersByTimeAsync(100)
    expect(h.agents.get('sA').followups).toHaveLength(2)
  })

  it('error exhausting maxRetries → failed', async () => {
    const h = await runningTaskHarness({ maxRetries: 0 })
    h.emitTurnEnd({ id: 'sA' }, { kind: 'error', error: { message: 'x' } })
    await flush()
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('failed')
    expect(row.attempts).toBe(1)
  })

  it('max-tokens sends 「继续」 up to continuationLimit then fails', async () => {
    const h = await runningTaskHarness({ continuationLimit: 2 })
    const agent = h.agents.get('sA')
    h.emitTurnEnd({ id: 'sA' }, { kind: 'max-tokens' })
    await flush()
    expect(agent.followups).toHaveLength(2)
    expect(agent.followups[1].content[0].text).toBe('继续')
    expect(h.tables.queue.map.get('t1').continuations).toBe(1)
    h.emitTurnEnd({ id: 'sA' }, { kind: 'max-tokens' })
    await flush()
    expect(h.tables.queue.map.get('t1').continuations).toBe(2)
    h.emitTurnEnd({ id: 'sA' }, { kind: 'max-tokens' })
    await flush()
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('failed')
    expect(row.lastError).toBe('max-tokens 连续截断')
    expect(agent.followups).toHaveLength(3) // no third continuation sent
  })

  it('max-tokens accumulates per-step token deltas without double count', async () => {
    const h = await runningTaskHarness({ continuationLimit: 3 })
    // First turn consumed 1000+200+3000+50 = 4250. Next step 10 more.
    h.emitTurnEnd({ id: 'sA' }, { kind: 'max-tokens' })
    await flush()
    h.totals.set('sA', { uncachedInputTokens: 1010, outputTokens: 200, cacheReadTokens: 3000, cacheWriteTokens: 50 })
    h.emitTurnEnd({ id: 'sA' }, { kind: 'completed' })
    await flush()
    const row = h.tables.queue.map.get('t1')
    expect(row.tokens.uncachedInput).toBe(1010) // 1000 + 10, baseline re-armed
    // cost = 4250×offPeak/1e6 + 10×offPeak/1e6 (each step priced separately).
    expect(row.cost).toBeCloseTo(4250 / 1e6 + 10 / 1e6, 10)
  })

  it('blocked → blocked (waits for a human)', async () => {
    const h = await runningTaskHarness()
    h.emitTurnEnd({ id: 'sA' }, { kind: 'blocked' })
    await flush()
    expect(h.tables.queue.map.get('t1').status).toBe('blocked')
  })

  it('aborted → cancelled, never re-dispatched', async () => {
    const h = await runningTaskHarness()
    h.emitTurnEnd({ id: 'sA' }, { kind: 'aborted', reason: { kind: 'user' } })
    await flush()
    expect(h.tables.queue.map.get('t1').status).toBe('cancelled')
    await vi.advanceTimersByTimeAsync(1000)
    expect(h.agents.get('sA').followups).toHaveLength(1)
  })

  it('interrupted → queued retry like error', async () => {
    const h = await runningTaskHarness()
    h.emitTurnEnd({ id: 'sA' }, { kind: 'interrupted' })
    await flush()
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('queued')
    expect(row.attempts).toBe(1)
    expect(row.lastError).toBe('interrupted')
  })

  it('turn/end from an unrelated session is ignored', async () => {
    const h = await runningTaskHarness()
    h.emitTurnEnd({ id: 'other' }, { kind: 'completed' })
    await flush()
    expect(h.tables.queue.map.get('t1').status).toBe('running')
  })
})

describe('reports', () => {
  beforeEach(() => { vi.useFakeTimers() })
  afterEach(() => { vi.useRealTimers() })

  it('peak onset triggers report generation for finished work', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    // A finished-but-unreported task from the overnight run:
    await h.tables.queue.put('t0', {
      id: 't0', prompt: 'done last night', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'done', attempts: 0, continuations: 0, enqueueSource: 'panel',
      tokens: { uncachedInput: 100, output: 10, cacheRead: 0, cacheWrite: 0 }, cost: 0.00011, savedVsPeak: 0.00011,
    })
    await apply(h.ctx, h.config)
    await flush()
    expect(h.tables.reports.map.size).toBe(0) // off-peak idle: nothing new
    vi.setSystemTime(shMs(1, 14)) // peak begins
    await vi.advanceTimersByTimeAsync(100)
    const report = h.tables.reports.map.get('2026-09-01')
    expect(report).toBeDefined()
    expect(report.window).toBe('peak')
    expect(report.tasks.total).toBe(1)
    expect(h.tables.queue.map.get('t0').reportedAt).toBeDefined() // not counted twice
    // Reported terminal rows survive (the panel's history section reads them)
    // but are pruned after reportRetentionDays. Jump past the horizon into a
    // PEAK window first (no dispatch there), verify survival, then one more
    // day into off-peak so pruneHistory actually runs.
    vi.setSystemTime(shMs(1, 14) + 31 * 86_400_000) // still peak 14:00
    await vi.advanceTimersByTimeAsync(100)
    expect(h.tables.queue.map.has('t0')).toBe(true) // peak ticks never prune
    vi.setSystemTime(shMs(2, 20) + 31 * 86_400_000) // 20:00 = off-peak
    await vi.advanceTimersByTimeAsync(100)
    expect(h.tables.queue.map.has('t0')).toBe(false)
    // And the report itself survived (it is the archive).
    expect(h.tables.reports.map.get('2026-09-01')).toBeDefined()
  })

  it('second wave same day merges into the existing report without double counting', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'a', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    h.emitTurnEnd({ id: 'sA' }, { kind: 'completed' })
    await flush()
    expect(h.tables.reports.map.get('2026-09-01').perTask.map(e => e.id)).toEqual(['t1'])
    // Enqueue and finish a second task the same day.
    await h.tables.queue.put('t2', {
      id: 't2', prompt: 'b', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: shMs(1, 13) + 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await vi.advanceTimersByTimeAsync(100)
    h.emitTurnEnd({ id: 'sA' }, { kind: 'completed' })
    await flush()
    const report = h.tables.reports.map.get('2026-09-01')
    expect(report.perTask.map(e => e.id)).toEqual(['t1', 't2'])
    expect(report.tasks.total).toBe(2)
    expect(report.cost).toBeCloseTo(report.perTask[0].cost + report.perTask[1].cost, 8)
  })
})

describe('HTTP API', () => {
  beforeEach(() => { vi.useFakeTimers() })
  afterEach(() => { vi.useRealTimers() })

  it('enqueue validates, persists, and returns the task id', async () => {
    vi.setSystemTime(shMs(1, 10)) // peak: enqueue accepted but not dispatched
    const h = makeCtx()
    await apply(h.ctx, h.config)
    const bad = await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: '' })
    expect(bad.status).toBe(400)
    const ok = await post(h.webRoutes, '/api/nightshift/enqueue', {
      prompt: 'hello', target: { mode: 'continue', sessionId: 'sZ' },
    })
    expect(ok.status).toBe(200)
    expect(ok.json.ok).toBe(true)
    expect(ok.json.taskId).toMatch(/^nightshift-/)
    const row = h.tables.queue.map.get(ok.json.taskId)
    expect(row.status).toBe('queued')
    expect(row.enqueueSource).toBe('panel')
  })

  it('routes reject unauthenticated requests with the connection verdict', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    await apply(h.ctx, h.config)
    const denied = await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: 'x', target: { mode: 'fresh', cwd: '/c' } }, { rejected: true })
    expect(denied.status).toBe(403)
    expect(denied.json).toBeUndefined()
  })

  it('cancel: queued → cancelled; unknown → 404; terminal → 400', async () => {
    vi.setSystemTime(shMs(1, 10)) // peak freeze so queued stays queued
    const h = makeCtx()
    await apply(h.ctx, h.config)
    const enq = await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: 'p', target: { mode: 'continue', sessionId: 's' } })
    expect((await post(h.webRoutes, '/api/nightshift/task/cancel', { taskId: 'nope' })).status).toBe(404)
    expect((await post(h.webRoutes, '/api/nightshift/task/cancel', { taskId: enq.json.taskId })).json).toEqual({ ok: true })
    expect(h.tables.queue.map.get(enq.json.taskId).status).toBe('cancelled')
    expect((await post(h.webRoutes, '/api/nightshift/task/cancel', { taskId: enq.json.taskId })).status).toBe(400)
  })

  it('cancel of running calls agent.cancel with keepInbox and books usage', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    h.totals.set('sA', { uncachedInputTokens: 100, outputTokens: 40, cacheReadTokens: 0, cacheWriteTokens: 0 })
    const r = await post(h.webRoutes, '/api/nightshift/task/cancel', { taskId: 't1' })
    expect(r.json).toEqual({ ok: true })
    const agent = h.agents.get('sA')
    expect(agent.cancels).toEqual([{ cause: { kind: 'user' }, options: { keepInbox: true } }])
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('cancelled')
    expect(row.tokens).toEqual({ uncachedInput: 100, output: 40, cacheRead: 0, cacheWrite: 0 })
  })

  it('run-now bypasses the peak freeze; gated by allowRunNow', async () => {
    vi.setSystemTime(shMs(1, 10)) // peak
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await apply(h.ctx, h.config)
    const enq = await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: 'p', target: { mode: 'continue', sessionId: 'sA' } })
    expect(h.agents.get('sA').followups).toHaveLength(0)
    const r = await post(h.webRoutes, '/api/nightshift/task/run-now', { taskId: enq.json.taskId })
    expect(r.json).toEqual({ ok: true })
    expect(h.agents.get('sA').followups).toHaveLength(1)
    expect(h.tables.queue.map.get(enq.json.taskId).status).toBe('running')
    // usage booked at PEAK price despite the off-… no: it completes at peak → peak price
    h.totals.set('sA', { uncachedInputTokens: 1000, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 })
    h.emitTurnEnd({ id: 'sA' }, { kind: 'completed' })
    await flush()
    expect(h.tables.queue.map.get(enq.json.taskId).cost).toBeCloseTo(1000 * 2 / 1e6, 10)
    // Disabled by config:
    const h2 = makeCtx({ allowRunNow: false })
    await apply(h2.ctx, h2.config)
    const enq2 = await post(h2.webRoutes, '/api/nightshift/enqueue', { prompt: 'p', target: { mode: 'continue', sessionId: 's' } })
    expect((await post(h2.webRoutes, '/api/nightshift/task/run-now', { taskId: enq2.json.taskId })).status).toBe(403)
  })

  it('run-now during an in-flight dispatch is rejected (409), not double-dispatched', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'a', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await h.tables.queue.put('t2', {
      id: 't2', prompt: 'b', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 2, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    // Suspend the boot drain mid-resolve: resolveAgent never settles, so the
    // drain holds the `dispatching` latch while `runningTask` is still null —
    // exactly the window where run-now used to slip through.
    let releaseResolve
    const gate = new Promise(resolve => { releaseResolve = resolve })
    const realResolve = h.ctx.sessionController.resolveAgent
    h.ctx.sessionController.resolveAgent = async sessionId => {
      await gate
      return realResolve(sessionId)
    }
    const drained = (async () => { await vi.advanceTimersByTimeAsync(0) })()
    await Promise.resolve() // let the drain reach its first await inside resolve
    const r = await post(h.webRoutes, '/api/nightshift/task/run-now', { taskId: 't2' })
    expect(r.status).toBe(409)
    expect(r.json.error).toMatch(/in flight|already running/)
    releaseResolve()
    await drained
    await flush()
    // Only the drain's target ever dispatched — no overwrite, no orphan.
    expect(h.agents.get('sA').followups).toHaveLength(1)
    expect(h.tables.queue.map.get('t1').status).toBe('running')
    expect(h.tables.queue.map.get('t2').status).toBe('queued')
  })

  it('GET state exposes window/queue/nextTransitionAt and no-store headers', async () => {
    vi.setSystemTime(shMs(1, 10)) // peak
    const h = makeCtx()
    await apply(h.ctx, h.config)
    await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: 'p', target: { mode: 'continue', sessionId: 's' } })
    const state = await get(h.fetchRoutes, '/api/nightshift/state')
    expect(state.status).toBe(200)
    expect(state.headers.get('cache-control')).toBe('no-store')
    expect(state.json.window).toBe('peak')
    expect(state.json.nextTransitionAt).toBe(shMs(1, 12))
    expect(state.json.queue).toHaveLength(1)
    expect(state.json.queue[0].prompt).toBe('p')
    expect(state.json.running).toBeNull()
    expect(state.json.config.timeZone).toBe(TZ)
    // Long prompts truncated to 2000 chars in TaskView.
    await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: 'x'.repeat(3000), target: { mode: 'continue', sessionId: 's' } })
    const state2 = await get(h.fetchRoutes, '/api/nightshift/state')
    expect(state2.json.queue[1].prompt.length).toBe(2001) // 2000 + ellipsis
  })

  it('GET state separates queued rows from terminal history', async () => {
    vi.setSystemTime(shMs(1, 10)) // peak: nothing dispatches
    const h = makeCtx()
    await apply(h.ctx, h.config)
    // One queued row and one terminal row from an earlier run.
    await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: 'live', target: { mode: 'continue', sessionId: 's' } })
    await h.tables.queue.put('tDone', {
      id: 'tDone', prompt: 'past', target: { mode: 'continue', sessionId: 's' },
      createdAt: 1, status: 'done', attempts: 0, continuations: 0, enqueueSource: 'panel',
      tokens: { uncachedInput: 1, output: 1, cacheRead: 0, cacheWrite: 0 }, cost: 0, savedVsPeak: 0,
      lastAttemptAt: 2,
    })
    const state = await get(h.fetchRoutes, '/api/nightshift/state')
    // queue carries ONLY queued rows (the client used to filter terminal rows
    // out of it — they never arrived, so history and badges were dead).
    expect(state.json.queue).toHaveLength(1)
    expect(state.json.queue[0].status).toBe('queued')
    expect(state.json.history.map(t => t.id)).toEqual(['tDone'])
  })

  it('GET report returns latest or ?date; missing 404', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await apply(h.ctx, h.config)
    await post(h.webRoutes, '/api/nightshift/enqueue', { prompt: 'p', target: { mode: 'continue', sessionId: 'sA' } })
    await vi.advanceTimersByTimeAsync(100)
    h.emitTurnEnd({ id: 'sA' }, { kind: 'completed' })
    await flush()
    const latest = await get(h.fetchRoutes, '/api/nightshift/report')
    expect(latest.status).toBe(200)
    expect(latest.json.date).toBe('2026-09-01')
    const dated = await get(h.fetchRoutes, '/api/nightshift/report', 'http://host/api/nightshift/report?date=2026-09-01')
    expect(dated.json.tasks.total).toBe(1)
    const missing = await get(h.fetchRoutes, '/api/nightshift/report', 'http://host/api/nightshift/report?date=2020-01-01')
    expect(missing.status).toBe(404)
  })

  it('POST body over size cap / invalid JSON → 400', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    await apply(h.ctx, h.config)
    const route = h.webRoutes.get('/api/nightshift/enqueue')
    const req = new EventEmitter()
    req.method = 'POST'
    const res = { writeHead() {}, end(b) { this.body = b }, statusCode: 200 }
    const done = route.handler(req, Object.assign(res, { writeHead(s) { res.statusCode = s } }))
    req.emit('end')
    await done
    expect(res.statusCode).toBe(400) // empty body → invalid JSON
  })
})

describe('boot reconcile & HMR cleanup', () => {
  beforeEach(() => { vi.useFakeTimers() })
  afterEach(() => { vi.useRealTimers() })

  it('running orphans re-queue at boot with the restart note', async () => {
    vi.setSystemTime(shMs(1, 10)) // peak so it re-queues but does NOT re-dispatch
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'running', attempts: 0, continuations: 0,
      lastAttemptAt: 5, nextRetryAt: 9, enqueueSource: 'panel',
    })
    await apply(h.ctx, h.config)
    await flush()
    const row = h.tables.queue.map.get('t1')
    expect(row.status).toBe('queued')
    expect(row.lastError).toBe('重启重排')
    expect(row.nextRetryAt).toBeUndefined()
    expect(row.lastAttemptAt).toBeUndefined()
  })

  it('dispose stops timers, closes domain, unregisters routes (HMR)', async () => {
    vi.setSystemTime(shMs(1, 13))
    const h = makeCtx()
    h.agents.set('sA', new FakeAgent('sA'))
    await apply(h.ctx, h.config)
    await h.tables.queue.put('t1', {
      id: 't1', prompt: 'p', target: { mode: 'continue', sessionId: 'sA' },
      createdAt: 1, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await vi.advanceTimersByTimeAsync(100)
    expect(h.agents.get('sA').followups).toHaveLength(1)
    // Tear down exactly like cordis HMR: run every effect disposer.
    for (const disposer of h.effects) await disposer()
    expect(h.domainClosed.value).toBe(true)
    expect(h.fetchRoutes.size).toBe(0)
    expect(h.webRoutes.size).toBe(0)
    // A late second task cannot dispatch after teardown.
    h.agents.set('sB', new FakeAgent('sB'))
    await h.tables.queue.put('t2', {
      id: 't2', prompt: 'q', target: { mode: 'continue', sessionId: 'sB' },
      createdAt: shMs(1, 13) + 1000, status: 'queued', attempts: 0, continuations: 0, enqueueSource: 'panel',
    })
    await vi.advanceTimersByTimeAsync(1000)
    expect(h.agents.get('sB').followups).toHaveLength(0)
  })

  it('invalid config fails loud before anything mounts', async () => {
    const h = makeCtx()
    await expect(apply(h.ctx, { ...DEFAULT_CONFIG, timeZone: 'Not/AZone' })).rejects.toThrow(/timeZone/)
    await expect(apply(h.ctx, { ...DEFAULT_CONFIG, peakWindows: [{ start: '25:00', end: '27:00' }] })).rejects.toThrow()
    await expect(apply(h.ctx, { ...DEFAULT_CONFIG, tickMs: 10 })).rejects.toThrow()
  })
})
