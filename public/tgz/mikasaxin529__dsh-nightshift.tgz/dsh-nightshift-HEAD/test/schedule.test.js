import { describe, it, expect } from 'vitest'
import { wallClockInZone, isInPeakWindow, nextTransition, parseHhmm } from '../lib/schedule.js'

/**
 * Build a UTC instant whose wall clock in `timeZone` reads the given
 * Y-M-D h:m. Converges via offset feedback: the naive UTC guess is corrected
 * by the observed wall drift; two passes are exact for fixed-offset zones and
 * non-ambiguous DST days (which the tests avoid).
 */
function msInZone(year, month, day, hour, minute, timeZone) {
  const want = hour * 60 + minute
  let guess = Date.UTC(year, month - 1, day, hour, minute)
  for (let i = 0; i < 4; i += 1) {
    const read = wallClockInZone(guess, timeZone)
    const drift = want - read.minutesOfDay
    if (drift === 0 && read.dateKey === dateKey(year, month, day)) break
    guess += drift * 60_000 + (Date.parse(dateKey(year, month, day)) - Date.parse(read.dateKey))
  }
  return guess
}

function dateKey(year, month, day) {
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
}

const DEFAULT_WINDOWS = [{ start: '09:00', end: '12:00' }, { start: '14:00', end: '18:00' }]

describe('wallClockInZone', () => {
  it('reads Asia/Shanghai wall clock (UTC+8, no DST)', () => {
    const r = wallClockInZone(Date.UTC(2026, 8, 1, 1, 30), 'Asia/Shanghai')
    expect(r).toEqual({ minutesOfDay: 9 * 60 + 30, hhmm: '09:30', dateKey: '2026-09-01' })
  })

  it('reads New York wall clock on the 2026-03-08 DST spring-forward day', () => {
    // 07:30Z on 2026-03-08 = 02:30 EST, but that minute does not exist:
    // the clock jumps 02:00→03:00, so Intl reports 03:30 EDT.
    const r = wallClockInZone(Date.UTC(2026, 2, 8, 7, 30), 'America/New_York')
    expect(r.minutesOfDay).toBe(3 * 60 + 30)
    expect(r.hhmm).toBe('03:30')
    expect(r.dateKey).toBe('2026-03-08')
  })

  it('handles a minute-boundary and hour rollover', () => {
    const r = wallClockInZone(msInZone(2026, 9, 1, 23, 59, 'Asia/Shanghai'), 'Asia/Shanghai')
    expect(r.hhmm).toBe('23:59')
    expect(r.minutesOfDay).toBe(1439)
  })

  it('throws on an invalid timezone (fail loud)', () => {
    expect(() => wallClockInZone(0, 'Not/AZone')).toThrow()
  })
})

describe('isInPeakWindow', () => {
  it('regular windows: inside peak true, valley false', () => {
    expect(isInPeakWindow(9 * 60 + 30, DEFAULT_WINDOWS)).toBe(true)
    expect(isInPeakWindow(15 * 60, DEFAULT_WINDOWS)).toBe(true)
    expect(isInPeakWindow(13 * 60, DEFAULT_WINDOWS)).toBe(false) // lunch valley
    expect(isInPeakWindow(22 * 60, DEFAULT_WINDOWS)).toBe(false) // night valley
  })

  it('edges are half-open [start,end)', () => {
    expect(isInPeakWindow(9 * 60, [{ start: '09:00', end: '12:00' }])).toBe(true)
    expect(isInPeakWindow(12 * 60, [{ start: '09:00', end: '12:00' }])).toBe(false)
    expect(isInPeakWindow(11 * 60 + 59, [{ start: '09:00', end: '12:00' }])).toBe(true)
  })

  it('midnight-crossing window 22:00→06:00 wraps', () => {
    const windows = [{ start: '22:00', end: '06:00' }]
    expect(isInPeakWindow(23 * 60, windows)).toBe(true)
    expect(isInPeakWindow(2 * 60, windows)).toBe(true)
    expect(isInPeakWindow(5 * 60 + 59, windows)).toBe(true)
    expect(isInPeakWindow(6 * 60, windows)).toBe(false) // end exclusive
    expect(isInPeakWindow(21 * 60 + 59, windows)).toBe(false) // start inclusive below
    expect(isInPeakWindow(22 * 60, windows)).toBe(true)
  })

  it('a 24:00 end covers through end-of-day', () => {
    expect(isInPeakWindow(1439, [{ start: '20:00', end: '24:00' }])).toBe(true)
    expect(isInPeakWindow(20 * 60, [{ start: '20:00', end: '24:00' }])).toBe(true)
    expect(isInPeakWindow(19 * 60 + 59, [{ start: '20:00', end: '24:00' }])).toBe(false)
  })

  it('start === end is an empty window (never peak)', () => {
    expect(isInPeakWindow(230, [{ start: '09:00', end: '09:00' }])).toBe(false)
  })

  it('full-day peak 00:00→24:00', () => {
    const all = [{ start: '00:00', end: '24:00' }]
    expect(isInPeakWindow(0, all)).toBe(true)
    expect(isInPeakWindow(1439, all)).toBe(true)
    expect(isInPeakWindow(720, all)).toBe(true)
  })

  it('empty window list means never peak', () => {
    expect(isInPeakWindow(10 * 60, [])).toBe(false)
    expect(isInPeakWindow(0, [])).toBe(false)
  })
})

describe('parseHhmm', () => {
  it('parses normal values', () => {
    expect(parseHhmm('00:00', 'start')).toBe(0)
    expect(parseHhmm('23:59', 'start')).toBe(1439)
    expect(parseHhmm('24:00', 'end')).toBe(1440)
  })
  it('rejects malformed, out-of-range, and 24:xx minute>0', () => {
    expect(() => parseHhmm('9:00')).toThrow()
    expect(() => parseHhmm('25:00')).toThrow()
    expect(() => parseHhmm('12:60')).toThrow()
    expect(() => parseHhmm('24:30')).toThrow()
    expect(() => parseHhmm('24:00', 'start')).toThrow() // 24:00 only valid as end
  })
})

describe('nextTransition', () => {
  it('from mid-peak goes to off-peak at the window end', () => {
    // Shanghai 11:30 (peak, window ends 12:00).
    const now = msInZone(2026, 9, 1, 11, 30, 'Asia/Shanghai')
    const t = nextTransition(now, 'Asia/Shanghai', [{ start: '09:00', end: '12:00' }])
    expect(t.toWindow).toBe('off-peak')
    const landed = wallClockInZone(t.atMs, 'Asia/Shanghai')
    expect(landed.minutesOfDay).toBe(12 * 60)
    expect(t.atMs).toBeGreaterThan(now)
    expect(t.atMs - now).toBeLessThanOrEqual(90 * 60_000)
  })

  it('from a valley inside the day goes forward to the next peak start', () => {
    // Shanghai 13:00 (valley; next peak starts 14:00).
    const now = msInZone(2026, 9, 1, 13, 0, 'Asia/Shanghai')
    const t = nextTransition(now, 'Asia/Shanghai', DEFAULT_WINDOWS)
    expect(t.toWindow).toBe('peak')
    expect(wallClockInZone(t.atMs, 'Asia/Shanghai').minutesOfDay).toBe(14 * 60)
  })

  it('resolves a transition that crosses midnight', () => {
    // Window 22:00→06:00; from 23:00 (peak) next is off-peak at 06:00 next day.
    const now = msInZone(2026, 9, 1, 23, 0, 'Asia/Shanghai')
    const t = nextTransition(now, 'Asia/Shanghai', [{ start: '22:00', end: '06:00' }])
    expect(t.toWindow).toBe('off-peak')
    const landed = wallClockInZone(t.atMs, 'Asia/Shanghai')
    expect(landed.minutesOfDay).toBe(6 * 60)
    expect(landed.dateKey).toBe('2026-09-02')
  })

  it('returns null when there is no transition (empty windows)', () => {
    expect(nextTransition(0, 'Asia/Shanghai', [])).toBeNull()
  })

  it('full-day peak never transitions', () => {
    const now = msInZone(2026, 9, 1, 12, 0, 'Asia/Shanghai')
    expect(nextTransition(now, 'Asia/Shanghai', [{ start: '00:00', end: '24:00' }])).toBeNull()
  })

  it('atMs lands on a whole-minute boundary', () => {
    const now = msInZone(2026, 9, 1, 11, 30, 'Asia/Shanghai') + 45_000 // +45s
    const t = nextTransition(now, 'Asia/Shanghai', [{ start: '09:00', end: '12:00' }])
    expect(t.atMs % 60_000).toBe(0)
  })
})
