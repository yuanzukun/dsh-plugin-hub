import { describe, expect, it } from 'vitest'
import {
  formatCountdown,
  formatMoney,
  formatRetries,
  formatTokenCount,
  statusColorToken,
  statusLabel,
  summarizePrompt,
} from '../lib/format.js'

describe('statusColorToken', () => {
  it('每个状态映射到 --dsw-alias-* 语义 token', () => {
    for (const status of ['queued', 'running', 'done', 'failed', 'blocked', 'cancelled']) {
      expect(statusColorToken(status)).toMatch(/^var\(--dsw-alias-[a-z0-9-]+\)$/)
    }
  })
  it('未知状态回落 queued 灰', () => {
    expect(statusColorToken('nope')).toBe(statusColorToken('queued'))
    expect(statusColorToken(undefined)).toBe(statusColorToken('queued'))
  })
})

describe('statusLabel', () => {
  it('六态中文标签', () => {
    expect(statusLabel('queued')).toBe('排队中')
    expect(statusLabel('running')).toBe('执行中')
    expect(statusLabel('done')).toBe('已完成')
    expect(statusLabel('failed')).toBe('失败')
    expect(statusLabel('blocked')).toBe('待人工')
    expect(statusLabel('cancelled')).toBe('已取消')
  })
  it('未知状态原样返回', () => {
    expect(statusLabel('weird')).toBe('weird')
  })
})

describe('formatCountdown', () => {
  it('null / NaN → 占位', () => {
    expect(formatCountdown(null)).toBe('—')
    expect(formatCountdown(undefined)).toBe('—')
    expect(formatCountdown(Number.NaN)).toBe('—')
    expect(formatCountdown(Number.POSITIVE_INFINITY)).toBe('—')
  })
  it('非正 → 即将', () => {
    expect(formatCountdown(0)).toBe('即将')
    expect(formatCountdown(-5000)).toBe('即将')
  })
  it('不足一分钟 → 即将', () => {
    expect(formatCountdown(59_000)).toBe('即将')
  })
  it('分钟粒度', () => {
    expect(formatCountdown(45 * 60_000)).toBe('45分')
    expect(formatCountdown(59 * 60_000 + 59_000)).toBe('59分')
  })
  it('小时 + 分钟', () => {
    expect(formatCountdown(2 * 3600_000 + 13 * 60_000)).toBe('2小时13分')
    expect(formatCountdown(3600_000)).toBe('1小时0分')
  })
  it('天 + 小时', () => {
    expect(formatCountdown(2 * 86_400_000 + 5 * 3600_000)).toBe('2天5小时')
    expect(formatCountdown(86_400_000)).toBe('1天0小时')
  })
})

describe('formatTokenCount', () => {
  it('千分位 zh-CN', () => {
    expect(formatTokenCount(1234567)).toBe('1,234,567')
  })
  it('取整', () => {
    expect(formatTokenCount(1234.6)).toBe('1,235')
  })
  it('缺省 0', () => {
    expect(formatTokenCount(null)).toBe('0')
    expect(formatTokenCount(undefined)).toBe('0')
    expect(formatTokenCount(Number.NaN)).toBe('0')
  })
})

describe('formatMoney', () => {
  it('两位小数 + 货币符号', () => {
    expect(formatMoney(3.4)).toBe('¥3.40')
    expect(formatMoney(1024)).toBe('¥1,024.00')
    expect(formatMoney(0.005)).toBe('¥0.01')
  })
  it('自定义符号', () => {
    expect(formatMoney(1.5, '$')).toBe('$1.50')
  })
  it('缺省 ¥0.00', () => {
    expect(formatMoney(null)).toBe('¥0.00')
    expect(formatMoney(undefined, '¥')).toBe('¥0.00')
  })
})

describe('summarizePrompt', () => {
  it('压平空白并原样返回短文本', () => {
    expect(summarizePrompt('  多行\n任务  内容 ')).toBe('多行 任务 内容')
  })
  it('截断到默认 80 字符并以 … 结尾', () => {
    const long = 'x'.repeat(200)
    const out = summarizePrompt(long)
    expect(out.length).toBe(80)
    expect(out.endsWith('…')).toBe(true)
  })
  it('自定义 max', () => {
    expect(summarizePrompt('abcdef', 4)).toBe('abc…')
  })
  it('null → 空串', () => {
    expect(summarizePrompt(null)).toBe('')
  })
})

describe('formatRetries', () => {
  it('0 / null → 空串', () => {
    expect(formatRetries(0)).toBe('')
    expect(formatRetries(null)).toBe('')
  })
  it('正数 → 重试 n 次', () => {
    expect(formatRetries(2)).toBe('重试 2 次')
  })
})
