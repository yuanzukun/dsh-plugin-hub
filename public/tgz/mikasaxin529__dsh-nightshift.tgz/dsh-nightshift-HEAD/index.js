/**
 * dsh-nightshift — host-side cordis function plugin.
 *
 * Daytime: tasks freeze in the queue. Off-peak: the drain loop dispatches
 * them one at a time, retries failures with backoff, continues max-tokens
 * truncations, and books real token spend against configured peak/off-peak
 * prices. When the queue empties (or peak returns) a savings report is
 * written to the reports table.
 *
 * Shape follows SPEC §9: an async `apply` that opens the storage domain,
 * owns one self-rescheduling top-level `setTimeout` tick (never
 * `setInterval`, never a session-scoped timer), dispatches on `session/event`
 * `turn/end`, registers two GET exact-fetch routes and three POST webServer
 * routes, and cleans everything up on HMR unload via `ctx.effect` disposers.
 *
 * @module dsh-nightshift
 */

import { randomUUID } from 'node:crypto'
import Schema from '@deepseek-ai/schemastery'
import { z } from 'zod'
import { defineDomain, domainTable } from '@deepseek-ai/dsh-storage-domain'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import * as schedule from './lib/schedule.js'
import * as queue from './lib/queue.js'
import * as ledger from './lib/ledger.js'

/** Largest delay node:http/node timers represent without overflow. */
const MAX_TIMER_DELAY_MS = 2_147_483_647

/** Cordis function-plugin name (matches the cordis.patch.yml id). */
export const name = 'nightshift'

/**
 * Host services. `tools` is deliberately NOT injected in v1 (SPEC §9
 * [TBD-验证] resolved): injecting a service the running bundle omits would
 * strand the fiber, and v1 never registers a tool, so the dependency is not
 * real. Re-add `tools` in v1.1 only when `exposeTool` actually registers one.
 * `workspaceRegistry` attaches fresh sessions to the workspace that owns
 * their cwd, so a nightshift-minted session groups in the sidebar like a
 * hand-created one (the webhook plugin's create flow does the same).
 * `logger` is a cordis built-in always present in the root context.
 */
export const inject = ['sessionController', 'sessionProjections', 'storageDomain', 'connection', 'webServer', 'workspaceRegistry']

const peakWindowSchema = Schema.object({
  start: Schema.string().default('09:00'),
  end: Schema.string().default('12:00'),
})

/** Plugin config (SPEC §3). */
export const Config = Schema.object({
  timeZone: Schema.string().default('Asia/Shanghai'),
  peakWindows: Schema.array(peakWindowSchema).default([
    { start: '09:00', end: '12:00' },
    { start: '14:00', end: '18:00' },
  ]),
  peakPricePerMTok: Schema.number().default(2),
  offPeakPricePerMTok: Schema.number().default(1),
  currency: Schema.string().default('¥'),
  tickMs: Schema.number().default(30_000),
  maxRetries: Schema.number().default(3),
  retryBaseMs: Schema.number().default(60_000),
  retryFactor: Schema.number().default(2),
  retryMaxMs: Schema.number().default(1_800_000),
  continuationLimit: Schema.number().default(3),
  continuationPrompt: Schema.string().default('继续'),
  drainGapMs: Schema.number().default(5_000),
  allowRunNow: Schema.boolean().default(true),
  reportRetentionDays: Schema.number().default(30),
  exposeTool: Schema.boolean().default(false),
})

/** Row schemas are zod at the durable boundary (SPEC §4). */
const bucketsSchema = z.object({
  uncachedInput: z.number(),
  output: z.number(),
  cacheRead: z.number(),
  cacheWrite: z.number(),
})

const queueRowSchema = z.object({
  id: z.string(),
  prompt: z.string(),
  target: z.union([
    z.object({ mode: z.literal('continue'), sessionId: z.string() }),
    // cwd optional: absent means the host's default cwd (ungrouped sessions).
    z.object({ mode: z.literal('fresh'), cwd: z.string().optional() }),
  ]),
  createdAt: z.number(),
  status: z.enum(['queued', 'running', 'done', 'failed', 'blocked', 'cancelled']),
  attempts: z.number().int().min(0),
  continuations: z.number().int().min(0),
  lastError: z.string().optional(),
  lastAttemptAt: z.number().optional(),
  nextRetryAt: z.number().optional(),
  tokens: bucketsSchema.optional(),
  // Ledger extension (see ledger.js): persisted per-task money so a report
  // generated in a later tick — or after a restart — can sum faithful cost.
  cost: z.number().optional(),
  savedVsPeak: z.number().optional(),
  enqueueSource: z.enum(['panel', 'tool']),
  // Terminal rows stay in the queue table (the panel shows them; failed /
  // blocked wait for a human). `reportedAt` marks one already folded into a
  // day report so the next report's per-task set holds only new completions.
  reportedAt: z.number().optional(),
})

const reportRowSchema = z.object({
  date: z.string(),
  generatedAt: z.number(),
  window: z.enum(['off-peak', 'peak']),
  tasks: z.object({
    total: z.number(), done: z.number(), failed: z.number(),
    blocked: z.number(), cancelled: z.number(), retried: z.number(),
  }),
  tokens: bucketsSchema,
  cost: z.number(),
  savedVsPeak: z.number(),
  perTask: z.array(z.object({
    id: z.string(),
    prompt: z.string(),
    status: queueRowSchema.shape.status,
    tokens: bucketsSchema,
    cost: z.number(),
    savedVsPeak: z.number(),
    attempts: z.number(),
  })),
})

const domainSpec = defineDomain({
  name: 'nightshift',
  version: 0,
  tables: {
    queue: domainTable(queueRowSchema),
    reports: domainTable(reportRowSchema),
  },
})

/**
 * One config sanity pass the schemastery shape cannot express: real zone +
 * parseable windows. Fail loud at load, before any timer or route mounts.
 * @param {object} config
 */
function assertConfig(config) {
  try {
    new Intl.DateTimeFormat('en-GB', { timeZone: config.timeZone })
  } catch {
    throw new Error(`nightshift: invalid timeZone ${JSON.stringify(config.timeZone)}`)
  }
  for (const window of config.peakWindows) {
    schedule.parseHhmm(window.start, 'start')
    schedule.parseHhmm(window.end, 'end')
  }
  if (config.tickMs < 100) {
    throw new Error('nightshift: tickMs must be >= 100ms')
  }
}

/**
 * @param {import('@deepseek-ai/cordis').Context} ctx
 * @param {object} config - validated {@link Config}.
 */
export async function apply(ctx, config) {
  assertConfig(config)
  const domain = await ctx.storageDomain.open(domainSpec)
  ctx.effect(() => async () => { await domain.close() }, 'nightshift.domain')
  /** @type {{queue: import('@deepseek-ai/dsh-storage-domain').KvTable<string,any>, reports: import('@deepseek-ai/dsh-storage-domain').KvTable<string,any>}} */
  const tables = {
    queue: domain.table('queue'),
    reports: domain.table('reports'),
  }

  // Single-instance runtime state. `runningTask` holds the live row plus the
  // agent + pre-turn token snapshot so the turn/end handler can compute the
  // per-turn delta. One running task at a time (SPEC §5).
  const runtime = {
    /** @type {{ row:object, agent:any, beforeBuckets:object }|null} */
    runningTask: null,
    /** next instant the drain may dispatch (enforces drainGapMs). */
    nextDispatchAt: 0,
    /** last observed window, so a peak→off-peak edge can be detected. */
    wasPeak: null,
    /** report needs regeneration after a state change touched the table. */
    needsReport: false,
    /** in-flight dispatch latch: drainStep awaits resolve/followup before
     *  `runningTask` is set, so without this a tick and a run-now request
     *  could interleave and double-dispatch. */
    dispatching: false,
    disposed: false,
  }

  // ---- helpers bound to config/runtime -------------------------------------

  /** @returns {number} current wall-clock minutes in the configured zone. */
  const nowMinutes = now => schedule.wallClockInZone(now, config.timeZone).minutesOfDay
  const peakNow = now => schedule.isInPeakWindow(nowMinutes(now), config.peakWindows)
  /** Window price in effect now (peak or off-peak). */
  const priceNow = now => peakNow(now) ? config.peakPricePerMTok : config.offPeakPricePerMTok

  /** Read every queue row into a fresh array (rows are storage snapshots). */
  function readQueue() {
    return [...tables.queue.entries()].map(([, row]) => row)
  }

  /** Persist a row; storage failure propagates (fail loud). */
  async function writeTask(row) {
    await tables.queue.put(row.id, row)
    runtime.needsReport = true
  }

  /**
   * Generate/refresh today's report from terminal rows not yet reported,
   * merging into any existing report for the same date key. Reported rows get
   * `reportedAt` stamped so a later report (tomorrow, or a re-run the same
   * day after the queue emptied) never double-counts them.
   */
  async function generateReport(now) {
    const dateKey = schedule.wallClockInZone(now, config.timeZone).dateKey
    const freshTerminal = readQueue()
      .filter(row => queue.isTerminal(row) && row.reportedAt === undefined)
      .sort((a, b) => a.createdAt - b.createdAt)
    if (freshTerminal.length === 0) return
    const entries = freshTerminal.map(ledger.reportEntryFromTask)
    const fresh = ledger.assembleReport(entries, {
      dateKey,
      generatedAt: now,
      window: peakNow(now) ? 'peak' : 'off-peak',
    })
    const merged = ledger.mergeReports(tables.reports.get(dateKey), fresh)
    await tables.reports.put(dateKey, merged)
    for (const row of freshTerminal) {
      await tables.queue.put(row.id, { ...row, reportedAt: now })
    }
    runtime.needsReport = false
    pruneReports(now)
  }

  /**
   * Drop terminal rows older than reportRetentionDays (best-effort): they
   * stay visible in the panel history meanwhile, but an unbounded queue
   * table would bloat every tick's full scan after months of daily runs.
   * The report itself is the long-term archive.
   */
  function pruneHistory(now) {
    if (!(config.reportRetentionDays > 0)) return
    const cutoff = now - config.reportRetentionDays * 86_400_000
    for (const [id, row] of [...tables.queue.entries()]) {
      if (queue.isTerminal(row) && row.reportedAt !== undefined && row.reportedAt < cutoff) {
        void tables.queue.delete(id).catch(error => {
          ctx.logger.warn(`nightshift: history prune failed for ${id}: ${messageOf(error)}`)
        })
      }
    }
  }

  /** Drop report rows older than reportRetentionDays (best-effort). */
  function pruneReports(now) {
    if (!(config.reportRetentionDays > 0)) return
    const cutoff = now - config.reportRetentionDays * 86_400_000
    for (const [date, row] of [...tables.reports.entries()]) {
      // Report date is a local YYYY-MM-DD; compare its generatedAt instant.
      if (row.generatedAt < cutoff) {
        void tables.reports.delete(date).catch(error => {
          ctx.logger.warn(`nightshift: report prune failed for ${date}: ${messageOf(error)}`)
        })
      }
    }
  }

  /** Build the TaskView the client renders (prompt truncated to 2000). */
  function taskView(row) {
    return { ...row, prompt: row.prompt.length > 2000 ? `${row.prompt.slice(0, 2000)}…` : row.prompt }
  }

  /**
   * Resolve the target agent for a task: continue an existing session, or
   * create a fresh one then adopt it. Returns the agent *and* the row with
   * its target rewritten to `continue` (a retry of the same task must reuse
   * the session it created, never mint a second one). Throws on a
   * Session-domain error, which the drain surfaces for the next tick.
   * @returns {Promise<{agent:any, row:object}>}
   */
  async function resolveTargetAgent(row) {
    let resolved = row
    if (row.target.mode === 'fresh') {
      // cwd absent (ungrouped origin) → dsh default cwd.
      const created = row.target.cwd === undefined
        ? await ctx.sessionController.create({})
        : await ctx.sessionController.create({ cwd: row.target.cwd })
      // Group the minted session under the workspace owning its cwd, so the
      // sidebar shows it in the same group as the session it was enqueued
      // from. Best-effort: an attach failure never blocks the dispatch (the
      // session still runs; it just stays ungrouped) — resolveByPath only
      // matches existing workspaces, so an unknown cwd is a no-op by design.
      if (row.target.cwd !== undefined) {
        try {
          const workspace = await ctx.workspaceRegistry.resolveByPath(row.target.cwd)
          if (workspace !== undefined) await workspace.attachSession(created.sessionId)
        } catch (error) {
          ctx.logger.warn(`nightshift: workspace attach failed for ${created.sessionId}: ${messageOf(error)}`)
        }
      }
      resolved = { ...row, target: { mode: 'continue', sessionId: created.sessionId } }
      await writeTask(resolved)
    }
    const agent = await resolveExistingAgent(resolved.target.sessionId)
    return { agent, row: resolved }
  }

  async function resolveExistingAgent(sessionId) {
    const result = await ctx.sessionController.resolveAgent(sessionId)
    if (result.error !== undefined) {
      throw new Error(`resolveAgent(${sessionId}): ${result.error.message ?? result.error.code ?? 'failed'}`)
    }
    return result.agent
  }

  // ---- the drain step ------------------------------------------------------

  /**
   * One drain pass. Never throws to the timer; storage/dispatch errors are
   * logged and retried on the following tick.
   * @param {number} now
   */
  async function drainStep(now) {
    const peak = peakNow(now)

    // Entering peak: freeze dispatch (running task is left to finish) and
    // flush a report so the panel can show what the overnight run saved.
    if (peak) {
      if (runtime.wasPeak === false || runtime.needsReport) await safeReport(now)
      runtime.wasPeak = true
      return
    }
    runtime.wasPeak = false
    pruneHistory(now)

    // Still executing a task: the turn/end event handler drives progress.
    if (runtime.runningTask !== null) return
    // Honor drainGapMs between successive dispatches.
    if (now < runtime.nextDispatchAt) return

    const due = queue.dueTasks(readQueue(), now)
    if (due.length === 0) {
      // Off-peak with nothing pending and nothing running: if the queue just
      // emptied, that is the other report trigger (SPEC §7).
      if (runtime.needsReport) await safeReport(now)
      return
    }

    // Claim the single-dispatch slot before the first await inside resolution
    // — resolveTargetAgent and the busy-check below both await, and a
    // concurrent run-now/enqueue drain must not slip into the gap.
    if (runtime.dispatching) return
    runtime.dispatching = true
    try {
      const head = due[0]
      const { agent, row: target } = await resolveTargetAgent(head)
      // A concurrent drain may have grabbed the running slot during the
      // resolve await; abandon (its write already owns the task).
      if (runtime.runningTask !== null) return

      // Target busy this round: move to the tail, retry next tick.
      if (agent.status === 'running') {
        await writeTask(queue.deferToTail(target, now))
        runtime.nextDispatchAt = now + config.drainGapMs
        return
      }

      // Snapshot cumulative usage BEFORE following up so the turn/end delta is
      // attributable to exactly this attempt. token-meter mounts in the base
      // bundle by default; a missing projection means usage cannot be metered
      // (bill nothing silently) — warn loudly but keep the run going.
      const state = ctx.sessionProjections.stateOf(agent.session, 'tokenUsage')
      if (state === undefined) {
        ctx.logger.warn(`nightshift: tokenUsage projection missing for task ${head.id} — usage will not be metered`)
      }
      const beforeBuckets = ledger.bucketsFromTotals(state?.totals)

      const running = { ...target, status: 'running', lastAttemptAt: now, nextRetryAt: undefined }
      // Assign the slot synchronously before any await in writeTask so a
      // second drainStep (event-driven or run-now) never sees the slot free.
      runtime.runningTask = { row: running, agent, beforeBuckets }
      await writeTask(running)
      try {
        agent.followup(buildPromptMessage(running.prompt))
      } catch (error) {
        // The prompt never entered the loop: put the task back for retry.
        ctx.logger.warn(`nightshift: followup failed for task ${running.id}: ${messageOf(error)}`)
        runtime.runningTask = null
        await writeTask({ ...running, status: 'queued', lastError: `followup: ${messageOf(error)}`, nextRetryAt: now + config.drainGapMs })
        runtime.nextDispatchAt = now + config.drainGapMs
      }
    } catch (error) {
      ctx.logger.warn(`nightshift: dispatch attempt failed: ${messageOf(error)}`)
      runtime.runningTask = null
      runtime.nextDispatchAt = now + config.drainGapMs
    } finally {
      runtime.dispatching = false
    }
  }

  async function safeReport(now) {
    try {
      await generateReport(now)
    } catch (error) {
      ctx.logger.error(`nightshift: report generation failed: ${messageOf(error)}`)
    }
  }

  // ---- turn/end dispatch ---------------------------------------------------

  ctx.on('session/event', (session, event) => {
    if (event.type !== 'turn/end') return
    const running = runtime.runningTask
    if (running === null) return
    if (running.agent.session !== session && running.agent.session?.id !== session?.id) return
    void handleTurnEnd(event.data.reason).catch(error => {
      ctx.logger.error(`nightshift: turn/end handling failed: ${messageOf(error)}`)
    })
  })

  async function handleTurnEnd(reason) {
    const running = runtime.runningTask
    if (running === null) return
    const now = Date.now()
    const { row, agent, beforeBuckets } = running

    let afterBuckets
    try {
      const state = ctx.sessionProjections.stateOf(agent.session, 'tokenUsage')
      afterBuckets = ledger.bucketsFromTotals(state?.totals)
    } catch (error) {
      ctx.logger.warn(`nightshift: post-turn usage read failed: ${messageOf(error)}`)
      afterBuckets = beforeBuckets
    }
    const delta = ledger.tokenDelta(beforeBuckets, afterBuckets)
    const priced = ledger.recordTaskUsage(row, delta, {
      windowPrice: priceNow(now),
      peakPrice: config.peakPricePerMTok,
    })

    const env = {
      now,
      maxRetries: config.maxRetries,
      continuationLimit: config.continuationLimit,
      retryBaseMs: config.retryBaseMs,
      retryFactor: config.retryFactor,
      retryMaxMs: config.retryMaxMs,
    }
    const outcome = queue.applyTurnEnd(priced, detailReason(reason), env)

    if (outcome.action === 'continue') {
      // Keep the task running; re-snapshot usage at the post-turn totals so
      // the next turn/end delta covers only the continuation step (the old
      // baseline would re-book every token already recorded above).
      try {
        agent.followup(buildPromptMessage(config.continuationPrompt))
        runtime.runningTask = { row: outcome.row, agent, beforeBuckets: afterBuckets }
        await writeTask(outcome.row)
      } catch (error) {
        runtime.runningTask = null
        await writeTask({ ...outcome.row, status: 'queued', lastError: `continuation: ${messageOf(error)}` })
        runtime.nextDispatchAt = now + config.drainGapMs
      }
      return
    }

    runtime.runningTask = null
    await writeTask(outcome.row)
    if (outcome.action === 'retry') {
      runtime.nextDispatchAt = now + config.drainGapMs
    }
    // Terminal or re-queued: if the queue is now empty off-peak, report.
    const remaining = readQueue().filter(r => !queue.isTerminal(r))
    if (remaining.length === 0) await safeReport(Date.now())
  }

  // Map a turn/end reason into queue.js's shape (extract a short detail).
  function detailReason(reason) {
    const detail = reason.kind === 'error' && reason.error !== undefined
      ? (reason.error.message ?? String(reason.error)) : undefined
    return { kind: reason.kind, detail }
  }

  function buildPromptMessage(text) {
    return createUserMessage({
      content: [{ type: 'text', text }],
      source: { kind: 'plugin', plugin: 'nightshift' },
    })
  }

  // ---- self-rescheduling tick ---------------------------------------------

  let timer
  function arm() {
    const delay = Math.min(Math.max(1, config.tickMs), MAX_TIMER_DELAY_MS)
    timer = setTimeout(() => {
      timer = undefined
      if (runtime.disposed) return
      void drainStep(Date.now())
        .catch(error => ctx.logger.error(`nightshift: tick failed: ${messageOf(error)}`))
        .finally(() => { if (!runtime.disposed) arm() })
    }, delay)
  }

  ctx.effect(() => {
    // Boot reconcile: any persisted `running` row belongs to a dead process.
    for (const { id, row } of queue.reconcileOrphans(readQueue())) {
      void tables.queue.put(id, row).catch(error => {
        ctx.logger.error(`nightshift: reconcile write failed: ${messageOf(error)}`)
      })
    }
    arm()
    // Run one drain immediately so an off-peak queue starts without a tick lag.
    void drainStep(Date.now()).catch(error => ctx.logger.error(`nightshift: boot drain failed: ${messageOf(error)}`))
    return () => {
      runtime.disposed = true
      if (timer !== undefined) clearTimeout(timer)
    }
  }, 'nightshift.tick')

  // ---- read routes (exact fetch, GET only) --------------------------------

  const stateRoute = {
    path: '/api/nightshift/state',
    methods: ['GET', 'HEAD'],
    fetch: async (request) => headOr(request, () => jsonResponse(buildStateView(Date.now()))),
  }
  const reportRoute = {
    path: '/api/nightshift/report',
    methods: ['GET', 'HEAD'],
    fetch: async (request) => headOr(request, () => {
      const url = new URL(request.url)
      const date = url.searchParams.get('date')
      const found = date === null ? latestReport() : tables.reports.get(date)
      return found === undefined ? jsonResponse({ ok: false, error: 'no report' }, 404) : jsonResponse(found)
    }),
  }
  ctx.effect(() => {
    const disposes = [stateRoute, reportRoute].map(route => ctx.connection.fetch.register(route))
    return async () => { await Promise.allSettled(disposes.map(dispose => dispose())) }
  }, 'nightshift.fetch')

  function latestReport() {
    const all = [...tables.reports.entries()].map(([date, row]) => ({ date, row }))
    if (all.length === 0) return undefined
    all.sort((a, b) => (a.row.generatedAt < b.row.generatedAt ? 1 : -1))
    return all[0].row
  }

  function buildStateView(now) {
    const rows = readQueue()
    const transition = schedule.nextTransition(now, config.timeZone, config.peakWindows)
    const runningRow = runtime.runningTask?.row
    // Terminal rows stay in the table for the panel (SPEC §4); the response
    // caps them at the most recent 50 so an old queue cannot bloat the poll.
    const history = rows
      .filter(r => queue.isTerminal(r))
      .sort((a, b) => (b.lastAttemptAt ?? b.createdAt) - (a.lastAttemptAt ?? a.createdAt))
      .slice(0, 50)
      .map(taskView)
    return {
      window: peakNow(now) ? 'peak' : 'off-peak',
      nextTransitionAt: transition?.atMs ?? null,
      now,
      running: runningRow === undefined ? null : taskView(runningRow),
      queue: rows.filter(r => r.status === 'queued').sort((a, b) => a.createdAt - b.createdAt).map(taskView),
      history,
      lastReport: summarizeReport(latestReport()),
      config: {
        timeZone: config.timeZone,
        peakWindows: config.peakWindows,
        peakPricePerMTok: config.peakPricePerMTok,
        offPeakPricePerMTok: config.offPeakPricePerMTok,
        currency: config.currency,
        allowRunNow: config.allowRunNow,
      },
    }
  }

  function summarizeReport(report) {
    if (report === undefined) return null
    const { date, generatedAt, window, tasks, tokens, cost, savedVsPeak } = report
    return { date, generatedAt, window, tasks, tokens, cost, savedVsPeak }
  }

  // ---- write routes (webServer POST + requestRejection) -------------------

  registerPost('/api/nightshift/enqueue', handleEnqueue)
  registerPost('/api/nightshift/task/cancel', handleCancel)
  registerPost('/api/nightshift/task/run-now', handleRunNow)

  function registerPost(path, handle) {
    ctx.effect(() => ctx.webServer.register({
      kind: 'exact',
      path,
      handler: async (req, res) => {
        const rejection = ctx.connection.requestRejection(req)
        if (rejection !== undefined) { res.writeHead(rejection); res.end(); return }
        if (req.method !== 'POST') { sendJson(res, 405, { ok: false, error: 'method not allowed' }); return }
        let body
        try {
          body = JSON.parse(await readBody(req))
        } catch {
          sendJson(res, 400, { ok: false, error: 'invalid JSON body' })
          return
        }
        try {
          const result = await handle(body)
          sendJson(res, result.status ?? 200, result.body)
        } catch (error) {
          sendJson(res, error.status ?? 500, { ok: false, error: messageOf(error) })
        }
      },
    }), `nightshift: ${path}`)
  }

  async function handleEnqueue(body) {
    let normalized
    try {
      normalized = queue.normalizeEnqueueRequest(body)
    } catch (error) {
      return { status: 400, body: { ok: false, error: messageOf(error) } }
    }
    const row = queue.makeTaskRow({
      id: `nightshift-${randomUUID()}`,
      prompt: normalized.prompt,
      target: normalized.target,
      nowMs: Date.now(),
      enqueueSource: body?.source === 'tool' ? 'tool' : 'panel',
    })
    await tables.queue.put(row.id, row)
    runtime.needsReport = true
    void drainStep(Date.now()).catch(() => {})
    return { body: { ok: true, taskId: row.id } }
  }

  async function handleCancel(body) {
    const id = body?.taskId
    if (typeof id !== 'string') return { status: 400, body: { ok: false, error: 'taskId required' } }
    const row = tables.queue.get(id)
    if (row === undefined) return { status: 404, body: { ok: false, error: 'not found' } }
    let settledRow = row
    if (runtime.runningTask?.row.id === id && runtime.runningTask.agent !== undefined) {
      const { agent, beforeBuckets } = runtime.runningTask
      try { agent.cancel({ kind: 'user' }, { keepInbox: true }) } catch { /* best effort */ }
      // Book the partial usage before settling: the aborted turn/end that
      // follows will be ignored (the slot is released here), and silently
      // dropping real spend would understate the report.
      try {
        const state = ctx.sessionProjections.stateOf(agent.session, 'tokenUsage')
        const delta = ledger.tokenDelta(beforeBuckets, ledger.bucketsFromTotals(state?.totals))
        settledRow = ledger.recordTaskUsage(row, delta, {
          windowPrice: priceNow(Date.now()),
          peakPrice: config.peakPricePerMTok,
        })
      } catch (error) {
        ctx.logger.warn(`nightshift: cancel-time usage read failed: ${messageOf(error)}`)
      }
      runtime.runningTask = null
    }
    const decision = queue.cancelTask(settledRow)
    if (!decision.ok) return { status: 400, body: { ok: false, error: decision.error } }
    await writeTask(decision.row)
    return { body: { ok: true } }
  }

  async function handleRunNow(body) {
    if (!config.allowRunNow) return { status: 403, body: { ok: false, error: 'run-now disabled' } }
    const id = body?.taskId
    if (typeof id !== 'string') return { status: 400, body: { ok: false, error: 'taskId required' } }
    const row = tables.queue.get(id)
    if (row === undefined) return { status: 404, body: { ok: false, error: 'not found' } }
    if (row.status !== 'queued') return { status: 400, body: { ok: false, error: `cannot run-now a ${row.status} task` } }
    if (runtime.runningTask !== null) return { status: 409, body: { ok: false, error: 'a task is already running' } }
    // A drain (tick- or enqueue-driven) may be mid-resolve with the slot not
    // yet claimed; its latch is authoritative for that window (the runtime
    // comment above documents why `runningTask` alone cannot be).
    if (runtime.dispatching) return { status: 409, body: { ok: false, error: 'a dispatch is already in flight' } }
    // Bypass peak-freeze and drainGap: dispatch exactly this task now.
    await dispatchNow(row)
    return { body: { ok: true } }
  }

  /** Force-dispatch one queued row, ignoring the current window. */
  async function dispatchNow(row) {
    const now = Date.now()
    runtime.dispatching = true
    let running = null
    try {
      const { agent, row: target } = await resolveTargetAgent(row)
      // A concurrent drain may have claimed the slot during the resolve
      // await; abandon (its write already owns the task).
      if (runtime.runningTask !== null) return
      const state = ctx.sessionProjections.stateOf(agent.session, 'tokenUsage')
      if (state === undefined) {
        ctx.logger.warn(`nightshift: tokenUsage projection missing for task ${row.id} — usage will not be metered`)
      }
      const beforeBuckets = ledger.bucketsFromTotals(state?.totals)
      running = { ...target, status: 'running', lastAttemptAt: now, nextRetryAt: undefined }
      runtime.runningTask = { row: running, agent, beforeBuckets }
      await writeTask(running)
      agent.followup(buildPromptMessage(running.prompt))
    } catch (error) {
      // Roll back the claimed slot + persisted running state, re-queueing.
      runtime.runningTask = null
      if (running !== null) {
        await writeTask({ ...running, status: 'queued', lastError: `run-now: ${messageOf(error)}` }).catch(() => {})
      }
      throw error
    } finally {
      runtime.dispatching = false
    }
  }

  ctx.logger.debug?.(`nightshift: mounted (${config.peakWindows.length} peak windows, ${config.timeZone})`)
}

// ---- module-level IO helpers (kept out of apply for testability) -----------

function messageOf(error) {
  return error instanceof Error ? error.message : String(error)
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = ''
    let size = 0
    req.on('data', chunk => {
      size += chunk.length
      if (size > 1_000_000) { reject(new Error('body too large')); req.destroy(); return }
      data += chunk
    })
    req.on('end', () => resolve(data))
    req.on('error', reject)
  })
}

function sendJson(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' })
  res.end(JSON.stringify(body))
}

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  })
}

/** Produce a response for GET; for HEAD, drop the body (session-log-export pattern). */
async function headOr(request, produce) {
  const response = await produce()
  if (request.method === 'GET') return response
  await response.body?.cancel()
  return new Response(null, { status: response.status, headers: response.headers })
}
