import { randomBytes } from 'node:crypto'
import { chmod, mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { platform } from 'node:process'

/**
 * Plugin configuration (cordis config object, injected via cordis.patch.yml).
 */
export interface DshPluginAdapterConfig {
  /**
   * Integration mode. `adapter` (default) registers a DSH LlmAdapter that
   * streams directly from the Zen anonymous lane — no child process. `sidecar`
   * (legacy, not bundled with the published package) spawns the Go agent
   * binary and registers an llm-pi-ai route to it; build the agent from
   * legacy/agent and pass agentPath.
   */
  mode?: 'adapter' | 'sidecar'
  /** Path to the agent binary (sidecar mode). Not bundled: build from legacy/agent. */
  agentPath?: string
  /** Extra CLI args forwarded to the agent (after --config). */
  agentArgs?: string[]
  /** Provider route name registered into llm-pi-ai settings. */
  providerId?: string
  /** Credential reference (env var name) holding the local agent token. */
  apiKeyEnv?: string
  /** Model list refresh interval in seconds (agent refresh_seconds matches). */
  refreshSeconds?: number
  /** Restart backoff: initial delay ms. */
  restartDelayMs?: number
  /** Restart backoff: max delay ms. */
  restartMaxDelayMs?: number
  /** Consecutive crash count that trips the circuit breaker. */
  maxConsecutiveCrashes?: number
  /**
   * Fixed session id sent as `x-opencode-session` for every request instead
   * of the derived per-conversation id. Leave it unset by default: the Zen
   * free lane meters its quota per SESSION id (measured 2026-10-21: a pinned
   * id that ran out kept returning 429 even on a fresh exit IP, while
   * another id answered 200 on the same IP), so a pinned id makes every
   * conversation share one bucket. Unpinned, the adapter derives a
   * canonical id per conversation — stable across turns, distinct per
   * conversation — so each conversation gets its own quota pool.
   *
   * Escape hatch for a conversation stuck on a sick upstream replica: pin a
   * live OpenCode CLI session id (canonical shape `ses_` + 12 hex + 14
   * base62; generate with `canonicalSessionID()` from adapter/ids.ts).
   */
  gatewaySession?: string
  /**
   * Stream-liveness watchdog windows, in milliseconds (adapter/zen-adapter.ts).
   *
   * The first-event window is a TIME-TO-FIRST-TOKEN budget: the Zen lane
   * holds the response head back until the upstream emits its first token,
   * so a slow first token is not a dead exit (see WATCHDOG_FIRST_MESSAGE).
   */
  watchdog?: {
    /** First-event window for plain models (default 60000). */
    firstEventMs?: number
    /** First-event window for reasoning models (default 90000). */
    reasoningFirstEventMs?: number
    /** Body-idle window after content started flowing (default 120000). */
    bodyIdleMs?: number
  }
  /**
   * Cap for the context window the adapter advertises to DSH (tokens).
   *
   * DSH compacts against the window the provider reports: the free models
   * declare 1,000,000 tokens, so a long session never triggers compaction and
   * every turn re-sends the whole growing surface (measured 2026-10-21:
   * 404K surface tokens, 205K read back from the prompt cache per step).
   * That is the biggest latency and quota lever on the Zen free lane.
   * Unset = advertise the model's own window (today's behaviour).
   */
  contextWindow?: number
  /**
   * Zen-lane transport (adapter/transport.ts + adapter/zen-relay.ts).
   *
   * The free tier answers Node's HTTP stack with 429 no matter how the request
   * is shaped: measured 2026-10-26, an identical body/header set was refused
   * 6/6 through Node/undici and served 5/5 through Bun's fetch on the same
   * machine, minute and exit IP. DSH itself runs on Node, so the lane is
   * re-originated by a tiny loopback relay run by `bun`.
   *
   * `relay: 'auto'` (default) uses bun when it is installed and silently falls
   * back to the previous Node path when it is not; 'off' never starts it;
   * an absolute `bunPath` pins the executable.
   */
  transport?: {
    /** Exit candidate for the Zen lane, e.g. http://127.0.0.1:10808 (v2rayN). */
    proxyUrl?: string
    /**
     * Every exit the relay may rotate through, in preference order
     * (e.g. the v2rayN inbound plus pool proxies). The free tier meters a
     * DAILY quota per exit IP, so a spent exit answers 429 until the day rolls
     * over — walking to the next exit is what refreshes the allowance, and a
     * 429 or a dead node sends the relay to the next entry instead of failing
     * the turn. `proxyUrl` is shorthand for a one-entry list.
     */
    proxyUrls?: string[]
    /** How long a failing exit is benched before it is retried (default 20s). */
    proxyCooldownMs?: number
    /** Force a fresh tunnel per request (default true). */
    noReuse?: boolean
    /** Bun egress relay: 'auto' (default), 'off'. */
    relay?: 'auto' | 'off'
    /** `bun` executable (absolute path or PATH name); auto-detected by default. */
    bunPath?: string
  }
  /**
   * IP-pool exit routing (docs/ip-pool.md). Everything below is pure plugin
   * config; the settings page (IP-6) will own these live, this object is
   * the cordis.patch.yml seam.
   */
  ipPool?: IpPoolConfig
}

/** docs/ip-pool.md section 5.1 schema (subset owned by config today). */
export interface IpPoolConfig {
  /** Master switch; false keeps the process exactly as today (direct). */
  enabled?: boolean
  /** Manually added plain proxies: 'http://h:p' or 'socks5://h:p'. */
  manual?: string[]
  /** Fixed primary exit address (docs/ip-pool.md 3.6). */
  pinnedExitId?: string
  /** Absolute pinning: never rotate, never direct-fallback (3.6). */
  pinnedStrict?: boolean
  /** Hosts whose traffic goes through the pool (default opencode.ai). */
  proxyHosts?: string[]
  /** Free-source pool (docs/ip-pool.md 1.2 source 1, 3.5, 4.5). */
  free?: {
    enabled?: boolean
    /** Target capacity for the free pool (docs 3.5). */
    targetSize?: number
    /** Admission geo blocklist (country codes). */
    blockedCountries?: string[]
  }
  /** Airport/Clash subscriptions (docs 1.2 source 3, IP-3). */
  subscriptions?: string[]
  /** Subscription refresh interval ms (docs 4.6, default 30min). */
  subscription?: { refreshMs?: number }
  /** Cross-exit probe concurrency cap (docs 4.1; same-exit always serial). */
  maxConcurrentProbes?: number
  /** sing-box conversion core for encrypted nodes (docs 1.2.2, IP-4). */
  singbox?: {
    /** sing-box binary: PATH name or absolute path; unset parks encrypted
     *  nodes as pending-conversion. */
    path?: string
  }
  /** Admission smoke model (docs 4.1 probeModels[0]). */
  probeModels?: string[]
  /** Same-request rotate attempts on pre-content failures (docs 3.4). */
  maxRotateAttempts?: number
}

export const defaults = {
  providerId: 'zen-free',
  apiKeyEnv: 'DSH_PLUGIN_ADAPTER_TOKEN',
  refreshSeconds: 300,
  restartDelayMs: 1000,
  restartMaxDelayMs: 60000,
  maxConsecutiveCrashes: 5,
}

export type ResolvedConfig = Required<
  Pick<DshPluginAdapterConfig, 'providerId' | 'apiKeyEnv' | 'refreshSeconds' | 'restartDelayMs' | 'restartMaxDelayMs' | 'maxConsecutiveCrashes'>
> & DshPluginAdapterConfig

export function resolveConfig(config: DshPluginAdapterConfig = {}): ResolvedConfig {
  return { ...defaults, ...config }
}

/**
 * Pre-0.3.9 name of {@link DshPluginAdapterConfig}. Kept as a type alias so
 * external consumers (and old cordis config typings) keep compiling.
 * @deprecated Use DshPluginAdapterConfig.
 */
export type Opencode2dshConfig = DshPluginAdapterConfig

/**
 * Everything the plugin persists next to the agent: the generated
 * agent-config.json (design.md section 8.3 template) and the local auth token.
 * The data directory doubles as the models.dev cache location for the agent.
 */
export interface AgentConfigPaths {
  dataDir: string
  configPath: string
  tokenPath: string
}

export function configPaths(dataDir: string): AgentConfigPaths {
  return {
    dataDir,
    configPath: join(dataDir, 'agent-config.json'),
    tokenPath: join(dataDir, 'agent-token.txt'),
  }
}

/** 32-byte random token, base64url (design.md section 7). */
export function generateToken(): string {
  return randomBytes(32).toString('base64url')
}

async function fileExists(path: string): Promise<boolean> {
  try {
    await stat(path)
    return true
  } catch {
    return false
  }
}

/**
 * Read the persisted token or generate and persist a fresh one.
 * Best-effort 0600 on POSIX; Windows profile dirs are user-scoped already.
 */
export async function ensureToken(paths: AgentConfigPaths): Promise<string> {
  if (await fileExists(paths.tokenPath)) {
    const existing = (await readFile(paths.tokenPath, 'utf8')).trim()
    if (existing.length > 0) return existing
  }
  const token = generateToken()
  await mkdir(dirname(paths.tokenPath), { recursive: true })
  await writeFile(paths.tokenPath, token + '\n', { encoding: 'utf8' })
  if (platform !== 'win32') {
    await chmod(paths.tokenPath, 0o600).catch(() => {})
  }
  return token
}

/**
 * Write agent-config.json atomically (tmp + rename) every plugin start, so a
 * version upgrade or option change reaches the next agent spawn. The agent
 * accepts JSON with comments; we emit plain JSON.
 */
export async function writeAgentConfig(
  paths: AgentConfigPaths,
  options: { token: string; refreshSeconds: number },
): Promise<void> {
  // design.md section 8.3 template; listen 127.0.0.1:0 => random port,
  // discovered via the READY line (--print-ready).
  const config = {
    listen: '127.0.0.1:0',
    server_keys: [options.token],
    anonymous: true,
    zen_keys: [],
    go_keys: [],
    upstream: { zen: 'https://opencode.ai/zen' },
    models: { refresh_seconds: options.refreshSeconds },
    retry: { max_attempts: 2, timeout_seconds: 300 },
    proxies: ['direct'],
    logging: { level: 'info' },
  }
  await mkdir(paths.dataDir, { recursive: true })
  const tmpPath = paths.configPath + '.tmp'
  await writeFile(tmpPath, JSON.stringify(config, null, 2), 'utf8')
  await rm(paths.configPath, { force: true })
  await rename(tmpPath, paths.configPath)
}
