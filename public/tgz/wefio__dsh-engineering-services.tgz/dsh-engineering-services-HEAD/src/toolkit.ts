/**
 * Shared DSH tool-layer helpers for the engineering-services port.
 *
 * These bridge the pi wire-up layer (defineTool + ExtensionAPI) to DSH's
 * cordis `ctx.tools.register(ToolDefinition)` contract. The heavy machinery
 * (lsp-client / dap session / task discovery) is host-agnostic and untouched;
 * only the thin glue below adapts pi tool semantics to DSH.
 * @module dsh-engineering-services/toolkit
 */
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { ToolDefinition, ToolExecution } from '@deepseek-ai/dsh-tools'
import type { JsonValue } from '@deepseek-ai/dsh-session'

/** Resolve the calling session's working directory, DSH-style. */
export function sessionCwd(exec: ToolExecution): string | undefined {
  const header = exec.agent?.session?.header
  const cwd = header?.cwd
  return typeof cwd === 'string' && cwd.length > 0 ? cwd : undefined
}

/** A resolved cwd, falling back to process.cwd() when the session has none. */
export function cwdOrProcess(exec: ToolExecution): string {
  return sessionCwd(exec) ?? process.cwd()
}

/** Render a text-tool's canonical string value as a single text block. */
function textRender(_args: unknown, value: JsonValue): ContentBlock[] {
  return [{ type: 'text', text: String(value) }]
}

/**
 * The standard output contract for the text-returning engineering tools
 * (lsp_*, debug, task): the canonical value is a formatted string, rendered
 * verbatim as model-facing text. Typed as `JsonSchemaNode`/`ToolOutputDefinition`
 * so `schema.type` stays the `'string'` literal, not a widened `string`.
 */
export function textOutput(): ToolDefinition['output'] {
  return {
    schema: { type: 'string', description: 'Formatted result text for the model.' },
    render: textRender,
  }
}
