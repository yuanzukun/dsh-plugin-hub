/**
 * dsh-engineering-services — IDE engineering services for DeepSeek Harness.
 *
 * Port of the pi `pi-engineering-services` extension suite: LSP / DAP / Task
 * three pillars plus an IDE-tooling usage skill.
 *
 * Node half: registers the tool suites (lsp_diagnostics…, debug, task) and the
 * system-prompt section that teaches them, mirroring dsh-genui's optional-
 * service probe pattern — `tools` and `systemPrompt` may bind after this plugin
 * starts, so both are probed immediately and on the `internal/service` event.
 * @module dsh-engineering-services
 */
import type { Context } from '@deepseek-ai/cordis'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'

import { lspTools, lspSection } from './lsp/dsh-lsp.js'
import { dapTools } from './dap/dap.js'
import { taskTools } from './task/task.js'

/** Only the system prompt is a hard runtime dependency; tools are probed. */
export const name = 'dsh-engineering-services'
export const inject = ['systemPrompt']

/** Every tool registered by this plugin (lsp + dap + task). */
function allTools(): ToolDefinition[] {
  return [...lspTools(), ...dapTools(), ...taskTools()]
}

export function apply(ctx: Context): void {
  const tools = ctx.reflect.get('tools', false) as { register(tool: unknown): unknown } | undefined
  const known = new Set<string>()
  const list = allTools()

  const tryTools = (value: { register(tool: unknown): unknown } | undefined): void => {
    const registry = value ?? (ctx.reflect.get('tools', false) as { register(tool: unknown): unknown } | undefined)
    if (registry === undefined) return
    for (const tool of list) {
      if (tool.name && !known.has(tool.name)) {
        registry.register(tool)
        known.add(tool.name)
      }
    }
  }

  const trySection = (value: { section(section: unknown): unknown } | undefined): void => {
    const systemPrompt = value ?? (ctx.reflect.get('systemPrompt', false) as { section(section: unknown): unknown } | undefined)
    if (systemPrompt === undefined) return
    systemPrompt.section(lspSection())
  }

  tryTools(tools)
  trySection(undefined)
  ctx.on('internal/service', (name: string, value: unknown) => {
    if (name === 'tools') tryTools(value as { register(tool: unknown): unknown })
    if (name === 'systemPrompt') trySection(value as { section(section: unknown): unknown })
  })
}
