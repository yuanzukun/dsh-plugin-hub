/**
 * Toolchain task runner — structured exec with output capture & truncation.
 * Reuses the NON_INTERACTIVE_ENV pattern from the dap extension.
 */

import { spawn } from "node:child_process";
import { NON_INTERACTIVE_ENV } from "./non-interactive-env.js";

export interface RunResult {
  command: string;
  cwd: string;
  exitCode: number | null;
  durationMs: number;
  output: string;
  truncated: boolean;
  timedOut: boolean;
}

const MAX_OUTPUT_BYTES = 64 * 1024;

export function runCommand(command: string, cwd: string, timeoutMs: number): Promise<RunResult> {
  return new Promise((resolve) => {
    const start = Date.now();
    let proc;
    try {
      proc = spawn(command, {
        cwd,
        shell: true,
        windowsHide: true,
        env: { ...process.env, ...NON_INTERACTIVE_ENV },
      });
    } catch (e) {
      resolve({
        command, cwd, exitCode: -1, durationMs: Date.now() - start,
        output: `[spawn error] ${e instanceof Error ? e.message : String(e)}`, truncated: false, timedOut: false,
      });
      return;
    }

    let output = "";
    let truncated = false;
    let timedOut = false;
    const append = (chunk: string) => {
      if (truncated) return;
      const room = MAX_OUTPUT_BYTES - output.length;
      if (room <= 0) { truncated = true; return; }
      output += chunk.slice(0, room);
      if (output.length >= MAX_OUTPUT_BYTES) truncated = true;
    };

    proc.stdout?.on("data", (d: Buffer) => append(d.toString("utf8")));
    proc.stderr?.on("data", (d: Buffer) => append(d.toString("utf8")));

    const timer = setTimeout(() => { timedOut = true; try { proc.kill(); } catch { /* already gone */ } }, timeoutMs);

    proc.on("error", (e) => {
      clearTimeout(timer);
      resolve({ command, cwd, exitCode: -1, durationMs: Date.now() - start, output: output + `\n[error] ${e.message}`, truncated, timedOut });
    });
    proc.on("close", (code) => {
      clearTimeout(timer);
      resolve({ command, cwd, exitCode: code, durationMs: Date.now() - start, output, truncated, timedOut });
    });
  });
}
