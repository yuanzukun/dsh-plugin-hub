/**
 * Toolchain task runner for DSH — discover & run build/test/lint tasks.
 *
 * Ported from the pi extension of the same name. The core (`discovery.ts`,
 * `runner.ts`, `non-interactive-env.ts`) is host-agnostic; this file is the
 * DSH wire-up that registers a single `task` tool via `ctx.tools.register`.
 *
 *   task list                → discover tasks (npm/make/just)
 *   task run name=build      → run a discovered task (npm run build / make build / just build)
 *   task run command="..."   → exec mode: run an arbitrary shell command
 * @module dsh-engineering-services/task
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import * as path from 'node:path'

import { discoverTasks, type DiscoveredTask } from './discovery.js'
import { runCommand } from './runner.js'
import { cwdOrProcess } from '../toolkit.js'

// ── Formatting ────────────────────────────────────────────────

function fmtList(cwd: string, tasks: DiscoveredTask[]): string {
  if (tasks.length === 0) return `No tasks discovered in ${cwd}.`
  const rows = tasks.map((t) => {
    const desc = t.description ? ` — ${t.description}` : ''
    return `  ${t.name.padEnd(24)} (${t.source.padEnd(4)})  ${t.command}${desc}`
  })
  return `Discovered ${tasks.length} task(s) in ${cwd}:\n${rows.join('\n')}`
}

function fmtRun(r: {
  command: string
  cwd: string
  exitCode: number | null
  durationMs: number
  output: string
  truncated: boolean
  timedOut: boolean
}): string {
  const status = r.timedOut ? 'TIMED OUT' : r.exitCode === 0 ? 'OK' : `FAILED (exit ${r.exitCode})`
  const out = r.output ? `\n${r.output}` : '\n(no output)'
  const tail = r.truncated ? '\n[output truncated]' : ''
  return `$ ${r.command}  [${status}] in ${r.cwd} (${r.durationMs}ms)${out}${tail}`
}

const TASK_PARAMETERS: Record<string, unknown> = {
  type: 'object',
  properties: {
    action: { type: 'string', description: "Action: 'list' to discover tasks, 'run' to run one" },
    name: { type: 'string', description: 'Task name to run (from `task list`)' },
    command: {
      type: 'string',
      description: 'Raw shell command to run (exec mode; mutually exclusive with name)',
    },
    source: {
      type: 'string',
      description: 'Filter discovery / disambiguate by source: npm | make | just',
    },
    cwd: { type: 'string', description: 'Working directory (defaults to the session workspace)' },
    timeout: { type: 'number', description: 'Timeout in seconds (default 120)' },
  },
  required: ['action'],
  additionalProperties: false,
}

function taskTool(): ToolDefinition {
  return {
    name: 'task',
    description: [
      'Discover and run toolchain tasks (build/test/lint/format) for the current project.',
      'Discovery sources: package.json scripts (npm), Makefile targets (make), justfile recipes (just).',
      'Actions:',
      '  list — discover available tasks (optional source filter: npm | make | just)',
      '  run  — run a discovered task by name, OR exec an arbitrary command via `command`',
      'Use `list` first to see what build/test/lint tasks exist, then `run` them.',
    ].join('\n'),
    parameters: TASK_PARAMETERS,
    output: {
      schema: { type: 'string', description: 'One-line task summary plus captured output for the model.' },
      render: (_args: unknown, value) => [{ type: 'text', text: String(value) }],
    },
    async execute(args: unknown, exec) {
      const params = (args ?? {}) as {
        action?: unknown
        name?: unknown
        command?: unknown
        source?: unknown
        cwd?: unknown
        timeout?: unknown
      }
      const sessionCwd = cwdOrProcess(exec)
      const cwd =
        typeof params.cwd === 'string' && params.cwd ? path.resolve(sessionCwd, params.cwd) : sessionCwd
      const timeoutMs = (typeof params.timeout === 'number' ? params.timeout : 120) * 1000
      const source = params.source as 'npm' | 'make' | 'just' | undefined

      if (params.action === 'list') {
        const all = discoverTasks(cwd)
        const tasks = source ? all.filter((t) => t.source === source) : all
        return fmtList(cwd, tasks)
      }

      if (params.action === 'run') {
        if (typeof params.command === 'string' && params.command) {
          const r = await runCommand(params.command, cwd, timeoutMs)
          return fmtRun(r)
        }
        if (typeof params.name !== 'string' || !params.name) {
          throw new Error("'name' (a discovered task) or 'command' (raw shell command) is required for run.")
        }
        const tasks = discoverTasks(cwd)
        const match = tasks.find((t) => t.name === params.name && (source === undefined || t.source === source))
        if (!match) {
          throw new Error(
            `Task '${params.name}'${source ? ` (source ${source})` : ''} not found in ${cwd}. ` +
              `Available: ${tasks.map((t) => t.name).join(', ')}`,
          )
        }
        const r = await runCommand(match.command, path.dirname(match.sourceFile), timeoutMs)
        return fmtRun(r)
      }

      throw new Error(`Unknown task action '${params.action}'. Use 'list' or 'run'.`)
    },
  }
}

/** The `task` ToolDefinition(s). */
export function taskTools(): ToolDefinition[] {
  return [taskTool()]
}