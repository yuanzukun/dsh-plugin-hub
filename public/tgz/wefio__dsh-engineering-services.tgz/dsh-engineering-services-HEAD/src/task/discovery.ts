/**
 * Toolchain task discovery — adapted from vscode-workspace-tasks (camalot).
 *
 * Sources (lean, v1):
 *   - package.json `scripts`  → npm run <name>
 *   - Makefile targets        → make <target>
 *   - justfile recipes        → just <recipe>
 */

import * as path from "node:path";
import * as fs from "node:fs";

export type TaskSource = "npm" | "make" | "just";

export interface DiscoveredTask {
  name: string;
  command: string;
  source: TaskSource;
  sourceFile: string;
  description?: string;
}

function readLines(file: string): string[] | null {
  try {
    return fs.readFileSync(file, "utf8").split(/\r?\n/);
  } catch {
    return null;
  }
}

export function discoverTasks(cwd: string): DiscoveredTask[] {
  const tasks: DiscoveredTask[] = [];

  // ── package.json scripts ──────────────────────────────────────
  const pkgPath = path.join(cwd, "package.json");
  try {
    const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
    const scripts = pkg?.scripts;
    if (scripts && typeof scripts === "object" && !Array.isArray(scripts)) {
      for (const [name, raw] of Object.entries(scripts)) {
        if (typeof raw !== "string") continue;
        tasks.push({ name, command: `npm run ${name}`, source: "npm", sourceFile: pkgPath, description: raw });
      }
    }
  } catch { /* no package.json or unparseable */ }

  // ── Makefile targets ──────────────────────────────────────────
  const mkPath = path.join(cwd, "Makefile");
  const mkLines = readLines(mkPath);
  if (mkLines) {
    for (const line of mkLines) {
      // `target: [deps]` — but skip variable assignments (`VAR := / ?= / ::= / +=`)
      const m = line.match(/^\s*([a-zA-Z0-9_.\-]+)\s*:/);
      if (!m) continue;
      const target = m[1];
      if (target === ".PHONY") continue;
      const afterColon = line.slice(m[0].length);
      if (afterColon.startsWith("=")) continue; // assignment, not a target
      tasks.push({ name: target, command: `make ${target}`, source: "make", sourceFile: mkPath });
    }
  }

  // ── justfile recipes ──────────────────────────────────────────
  const jfPath = path.join(cwd, "justfile");
  const jfLines = readLines(jfPath);
  if (jfLines) {
    for (const lineRaw of jfLines) {
      const line = lineRaw.trim();
      if (!line || line.startsWith("#")) continue;
      const m = line.match(/^@?([a-zA-Z_][a-zA-Z0-9_-]*)\s*.*:/);
      if (!m) continue;
      if (line.includes(":=")) continue; // assignment, not a recipe
      const recipe = m[1];
      if (["mod", "import", "export", "alias", "set"].includes(recipe)) continue;
      tasks.push({ name: recipe, command: `just ${recipe}`, source: "just", sourceFile: jfPath });
    }
  }

  return tasks;
}
