# debugpy 配置与说明

> ⚠️ **本目录不是 debugpy 运行时本体。** debugpy 是 pip 包，装在 **Python 3.13** 环境里（解释器由 `PI_DEBUGPY_PYTHON` 指定，见下）。这里只放它的配置、说明和检查脚本。
> 对比：`../js-debug/` 是 vendored 运行时（npm 装不到，必须 vendor）；debugpy pip 装得到，不 vendor（33MB 含 cp313 native 扩展，且离不开 Python 解释器）。

## 运行时（外部依赖，不 vendor）

| 项 | 值 |
|---|---|
| 解释器 | `$PI_DEBUGPY_PYTHON`（未设则 PATH 找 `python3.13`；必须是 3.13） |
| 适配器 | `python -m debugpy.adapter`（pip 包，site-packages/debugpy，532 文件） |
| 版本 | debugpy 1.8.21（PyPI 最新） |

## 版本锁定（为什么钉 Python 3.13，不用 3.14）

- debugpy 1.8.21 与 **Python 3.14 深度不兼容**：launch 带 `stopOnEntry:true` 也不发 stopped 事件（程序直接跑、断点全错过），加 `-Xfrozen_modules=off` 无效。
- 根因：[debugpy #1893 "Python 3.14 and above broke the debug extension"](https://github.com/microsoft/debugpy/issues/1893)（官方未修，修复在 next release，尚未发布）。
- 默认 `python` 若是 3.14：debugpy 已装但 stopOnEntry 坏；必须用 **Python 3.13** 解释器。
- **所以 defaults.json 里 debugpy.command 用 `${env:PI_DEBUGPY_PYTHON|python3.13}`**，不是疏忽：设 `PI_DEBUGPY_PYTHON` 指向你的 3.13 解释器（或确保 `python3.13` 在 PATH）。

## 配置（defaults.json 的 debugpy 段，完整参考见 `defaults-debugpy.json`）

```jsonc
"debugpy": {
  "command": "${env:PI_DEBUGPY_PYTHON|python3.13}",
  "args": ["-m", "debugpy.adapter"],
  "launchDefaults": {
    "request": "launch",
    "justMyCode": false,
    "stopOnEntry": true,
    "pythonArgs": ["-X", "frozen_modules=off"]
  },
  "attachDefaults": { "request": "attach", "justMyCode": false },
  "directAttach": true
}
```

## attach 机制（direct-TCP，不走 adapter 进程）

debugpy attach = 直连 target 的 `--listen` 端口（target 自己 spawn 自己的 adapter）。三个已验证的关键行为：

1. **attach 响应要等 configurationDone 之后才返回** → attach() 用 `initialized` 事件当"已 attach"信号，不能 `await attachP`。
2. **断点必须在 configurationDone 前设好**，否则 release 后设的断点永不命中 → `deferConfigDone` 机制（attach 后停 `configuring`，首 continue 才 release）。
3. **configDone 后立即 continue 会无响应**（debugpy 启动过渡竞态）→ 首 continue = release + 等断点 stopped，不额外发 DAP continue。

详见 `../../MAINTENANCE-NOTES.md` §3.8。

## 升级路径（以后 debugpy 出 3.14 兼容版时）

1. 用你的 Python 3.13 解释器升级：`$PI_DEBUGPY_PYTHON -m pip install -U debugpy`。
2. 跑 `bun verify.mjs` 确认版本 + 3.14 是否已兼容。
3. 若 3.14 已兼容：把 defaults.json 的 `debugpy.command` 改回 `python`（3.14），可保留/删掉 `-Xfrozen_modules=off`。
4. 真会话跑 launch + attach 各一遍回归（launch 流程：entry→断点→continue→evaluate→terminate；attach 流程见 §3.8）。

## 健康检查

```
bun verify.mjs    # 检查解释器存在 + debugpy 版本 + 是否踩 3.14 坑
```

## 相关文件

- `requirements.txt` — 版本钉（`debugpy==1.8.21`），复现 Python 3.13 环境用
- `defaults-debugpy.json` — defaults.json 的 debugpy 段（独立参考）
- `verify.mjs` — 健康检查脚本
