/**
 * debugpy 健康检查（不搬运行时，只验证外部依赖齐不齐）。
 * 用：bun verify.mjs   或   node verify.mjs
 */

import { spawn } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

// Python 3.13 interpreter: env var > argv[2] > PATH lookup (e.g. `python3.13`).
const PY313 = process.env.PI_DEBUGPY_PYTHON ?? process.argv[2] ?? "python3.13";
// Resolve defaults.json relative to this script, so it works from any checkout.
const HERE = path.dirname(fileURLToPath(import.meta.url));
const DEFAULTS = path.join(HERE, "..", "extensions", "defaults.json");

function run(py, args) {
  return new Promise((resolve) => {
    const p = spawn(py, args, { stdio: ["ignore", "pipe", "pipe"] });
    let out = "", err = "";
    p.stdout?.on("data", (d) => (out += d.toString()));
    p.stderr?.on("data", (d) => (err += d.toString()));
    p.on("close", (code) => resolve({ code, out, err }));
  });
}

let fail = 0;
const ok = (m) => console.log(`  ✓ ${m}`);
const bad = (m) => { console.log(`  ✗ ${m}`); fail++; };
const warn = (m) => console.log(`  ⚠ ${m}`);

console.log("debugpy 健康检查\n");

// 1) 解释器存在
console.log("1) Python 3.13 解释器");
if (fs.existsSync(PY313)) ok(`${PY313} 存在`);
else { bad(`${PY313} 不存在 —— debugpy 无法运行`); process.exit(1); }

// 2) debugpy 版本
console.log("2) debugpy 版本（3.13 环境）");
const v313 = await run(PY313, ["-c", "import debugpy; print(debugpy.__version__)"]);
if (v313.code === 0) ok(`debugpy ${v313.out.trim()} @ ${PY313}`);
else bad(`import debugpy 失败: ${v313.err.trim().split("\n").slice(-1)}`);

// 3) 默认 python 版本（3.14 坑预警）
console.log("3) 默认 python 版本预警");
const vdef = await run("python", ["-c", "import sys, debugpy; print(sys.version.split()[0], debugpy.__version__)"]);
if (vdef.code === 0) {
  const [pyver, dpver] = vdef.out.trim().split(/\s+/);
  if (pyver.startsWith("3.14")) {
    warn(`默认 python = ${pyver} + debugpy ${dpver} —— 3.14 不兼容（#1893），别用默认 python 跑调试（defaults 已钉 3.13，无碍）`);
  } else ok(`默认 python = ${pyver} + debugpy ${dpver}`);
} else {
  console.log(`  (默认 python 无 debugpy: ${vdef.err.trim().split("\n").slice(-1) || "未知"})`);
}

// 4) defaults.json 指向
console.log("4) defaults.json 配置指向");
try {
  const cfg = JSON.parse(fs.readFileSync(DEFAULTS, "utf8")).debugpy;
  ok(`command = ${cfg.command}`);
  ok(`args = ${cfg.args.join(" ")}`);
  ok(`directAttach = ${cfg.directAttach}`);
} catch {
  bad("读 defaults.json 失败");
}

console.log(fail === 0 ? "\n✅ 全部通过" : `\n❌ ${fail} 项有问题`);
process.exit(fail === 0 ? 0 : 1);
