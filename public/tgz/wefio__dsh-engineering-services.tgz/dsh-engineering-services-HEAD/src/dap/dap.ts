/**
 * DAP extension for DSH — registers a `debug` tool for DAP (Debug Adapter
 * Protocol).
 *
 * Ported from the pi extension of the same name. The DAP machinery
 * (`session.ts`, `client.ts`, `config.ts`) is host-agnostic and untouched;
 * this file is the DSH wire-up that registers a single `debug` tool whose
 * `action` parameter dispatches DAP operations.
 *
 * Verified adapters (the pi edition's tested scope): **debugpy** (Python) and
 * **js-debug** (JS/TS). Other adapters are configured in defaults.json but
 * are experimental.
 *
 * @module dsh-engineering-services/dap
 */
import type { ToolDefinition, ToolExecution } from '@deepseek-ai/dsh-tools'
import * as path from 'node:path'
import * as fs from 'node:fs/promises'

import { DapSessionManager } from './session.js'
import {
  selectLaunchAdapter,
  selectAttachAdapter,
  resolveLaunchOverrides,
  getAvailableAdapters,
  type LaunchProgramKind,
} from './config.js'
import type {
  DapBreakpointRecord,
  DapContinueOutcome,
  DapDataBreakpointInfoResponse,
  DapDataBreakpointRecord,
  DapDisassembledInstruction,
  DapEvaluateResponse,
  DapFunctionBreakpointRecord,
  DapInstructionBreakpointRecord,
  DapModule,
  DapResolvedAdapter,
  DapScope,
  DapSessionSummary,
  DapSource,
  DapStackFrame,
  DapThread,
  DapVariable,
} from './types.js'
import { isEnoent } from './utils.js'
import { cwdOrProcess } from '../toolkit.js'

// ── Singleton ──────────────────────────────────────────────────

let _manager: DapSessionManager | null = null
function mgr(): DapSessionManager {
  if (!_manager) _manager = new DapSessionManager()
  return _manager
}

// ── Helpers ────────────────────────────────────────────────────

function resolveToCwd(t: string, cwd: string): string {
  return path.isAbsolute(t) ? t : path.resolve(cwd, t)
}

async function classifyProgram(p: string): Promise<LaunchProgramKind> {
  try { const s = await fs.stat(p); return s.isDirectory() ? 'directory' : 'file' }
  catch (e) { if (isEnoent(e)) return 'missing'; throw e }
}

function getAdaptersList(cwd: string): string {
  return getAvailableAdapters(cwd).map(a => a.name).join(', ') || 'none'
}

function requireCap(cap: string, label: string): void {
  const caps = mgr().getCapabilities()
  if (!caps || !(caps as Record<string, unknown>)[cap]) throw new Error(`This debug adapter does not support ${label}.`)
}

// ── Timeout ────────────────────────────────────────────────────

const T_MIN = 5, T_MAX = 300, T_DEF = 30
function clampT(s: unknown): number {
  const n = typeof s === 'number' ? s : Number(s)
  return Number.isFinite(n) && n > 0 ? Math.max(T_MIN, Math.min(T_MAX, n)) : T_DEF
}

/** Fuse the caller's cancellation signal with a wall-clock timeout. */
function signalAndTimeout(timeoutS: number, exec: ToolExecution): { signal: AbortSignal; timeoutMs: number } {
  const timeoutMs = timeoutS * 1000
  const execSignal = exec.signal
  // AbortSignal.any fuses the caller's cancellation with our timeout so a
  // caller abort cancels DAP requests too (Node >= 20 / ES2024).
  const signal = AbortSignal.any([execSignal, AbortSignal.timeout(timeoutMs)])
  return { signal, timeoutMs }
}

// ── Formatting ─────────────────────────────────────────────────

function fmtSession(s: DapSessionSummary): string[] {
  const l = [`Adapter: ${s.adapter}`, `Status: ${s.status}`]
  if (s.program) l.push(`Program: ${s.program}`)
  if (s.status === 'stopped' && s.stopReason) {
    l.push(`Stop reason: ${s.stopReason}${s.stopDescription ? ` (${s.stopDescription})` : ''}`)
    if (s.frameName) l.push(`Stopped at: ${[s.frameName, s.source?.path, s.line].filter(Boolean).join(':')}`)
  } else if (s.status === 'running') {
    l.push('Program is running.')
  } else if (s.status === 'terminated') {
    if (s.exitCode !== undefined) l.push(`Exit code: ${s.exitCode}`)
  }
  if (s.breakpointCount > 0) l.push(`Breakpoints: ${s.breakpointCount} in ${s.breakpointFiles} files`)
  return l
}

function fmtBps(sp: string, bps: DapBreakpointRecord[]): string {
  const l = [`Breakpoints in ${path.basename(sp)}:`]
  if (!bps.length) l.push('  (none)')
  else for (const bp of bps) { l.push(`  ${bp.verified ? '✓' : '✗'} L${bp.line}${bp.condition ? ` if ${bp.condition}` : ''}`); if (!bp.verified && bp.message) l.push(`    ${bp.message}`) }
  return l.join('\n')
}

function fmtFnBps(bps: DapFunctionBreakpointRecord[]): string {
  const l = ['Function breakpoints:']; if (!bps.length) l.push('  (none)')
  else for (const bp of bps) l.push(`  ${bp.verified ? '✓' : '✗'} ${bp.name}${bp.condition ? ` if ${bp.condition}` : ''}`)
  return l.join('\n')
}

function fmtThreads(ts: DapThread[]): string {
  return ts.length ? ts.map(t => `  #${t.id} ${t.name}`).join('\n') : '(no threads)'
}

function fmtFrames(fs: DapStackFrame[]): string {
  return fs.length ? fs.map((f, i) => `  #${i} ${f.name}${f.source?.path ? ` — ${path.basename(f.source.path)}:${f.line}` : ''}`).join('\n') : '(no stack frames)'
}

function fmtScopes(sc: DapScope[]): string {
  return sc.length ? sc.map(s => `  ${s.name} (ref: ${s.variablesReference}, expensive: ${s.expensive})`).join('\n') : '(no scopes)'
}

function fmtVars(vs: DapVariable[]): string {
  return vs.length ? vs.map(v => `  ${v.name} = ${v.value}${v.type ? ` (${v.type})` : ''}`).join('\n') : '(no variables)'
}

function fmtEval(e: DapEvaluateResponse): string {
  return [e.result, e.type ? `Type: ${e.type}` : ''].filter(Boolean).join('\n')
}

function fmtDisasm(ins: DapDisassembledInstruction[]): string {
  return ins.length ? ins.map(i => `  ${i.address}: ${i.instruction}${i.symbol ? ` ; ${i.symbol}` : ''}`).join('\n') : '(no instructions)'
}

function fmtMemRead(addr: string, data: string | undefined, unreadable: number | undefined): string {
  const l = [`Address: ${addr}`]; if (unreadable) l.push(`Unreadable bytes: ${unreadable}`)
  if (data) l.push(`Data: ${data}`); return l.join('\n')
}

function fmtModules(ms: DapModule[]): string {
  return ms.length ? ms.map(m => `  ${m.name} (${m.id})`).join('\n') : '(no modules)'
}

function fmtSources(ss: DapSource[]): string {
  return ss.length ? ss.map(s => `  ${s.path ?? s.name ?? '(unnamed)'}`).join('\n') : '(no sources)'
}

function fmtSessions(ss: DapSessionSummary[]): string {
  return ss.length ? ss.map(s => `  [${s.id}] ${s.adapter} - ${s.status}${s.program ? ` - ${s.program}` : ''}`).join('\n') : 'No debug sessions.'
}

function outcomeText(o: DapContinueOutcome, t: number, label: string): string {
  return [`${label} result: ${o.state}`, o.timedOut ? `(timed out after ${t}s)` : '', ...fmtSession(o.snapshot)].join('\n')
}

// ── Tool ───────────────────────────────────────────────────────

const DEBUG_PARAMETERS: Record<string, unknown> = {
  type: 'object',
  properties: {
    action: { type: 'string', description: 'Debug action to perform' },
    program: { type: 'string', description: 'Path to program or script (for launch)' },
    args: { type: 'array', items: { type: 'string' }, description: 'Command-line arguments' },
    cwd: { type: 'string', description: 'Working directory (defaults to the session workspace)' },
    adapter: { type: 'string', description: 'Debug adapter name (auto-selected if omitted)' },
    pid: { type: 'number', description: 'Process ID to attach to' },
    port: { type: 'number', description: 'Port to attach to' },
    host: { type: 'string', description: 'Host for TCP attach (default: localhost)' },
    file: { type: 'string', description: 'Source file for breakpoints' },
    line: { type: 'number', description: 'Line number for breakpoints' },
    function: { type: 'string', description: 'Function name for function breakpoints' },
    condition: { type: 'string', description: 'Conditional expression for breakpoints' },
    expression: { type: 'string', description: 'Expression to evaluate' },
    context: { type: 'string', description: 'Evaluation context (repl, watch, hover, clipboard, variables)' },
    frame_id: { type: 'number', description: 'Stack frame ID' },
    levels: { type: 'number', description: 'Number of stack frames' },
    variable_ref: { type: 'number', description: 'Variable reference for child variables' },
    scope_id: { type: 'number', description: 'Scope reference for variables' },
    instruction_reference: { type: 'string', description: 'Instruction pointer reference' },
    offset: { type: 'number', description: 'Byte offset' },
    instruction_count: { type: 'number', description: 'Number of instructions' },
    resolve_symbols: { type: 'boolean', description: 'Resolve symbols in disassembly' },
    memory_reference: { type: 'string', description: 'Memory reference' },
    count: { type: 'number', description: 'Byte count for memory read' },
    data: { type: 'string', description: 'Data to write (base64 for memory, string for expressions)' },
    name: { type: 'string', description: 'Variable name for data breakpoint info' },
    data_id: { type: 'string', description: 'Data ID for data breakpoints' },
    access_type: { type: 'string', description: 'Access type: read, write, or readWrite' },
    command: { type: 'string', description: 'Custom DAP command name' },
    arguments: { type: 'object', additionalProperties: true, description: 'Custom DAP command arguments' },
    timeout: { type: 'number', description: 'Timeout in seconds (default: 30)' },
  },
  required: ['action'],
  additionalProperties: false,
}

function debugTool(): ToolDefinition {
  return {
    name: 'debug',
    description: `Debug a program using the Debug Adapter Protocol (DAP).

Supports debug adapters: gdb, lldb-dap, codelldb, debugpy (Python), dlv (Go),
js-debug-adapter (JS/TS), netcoredbg (C#), kotlin-debug-adapter, rdbg (Ruby),
php-debug-adapter, bash-debug-adapter, dart-debug-adapter, flutter-debug-adapter,
elixir-ls-debugger.

Verified scope: **debugpy (Python)** and **js-debug (JS/TS)**. Others are configured but experimental.

Actions: launch, attach, set_breakpoint, remove_breakpoint, continue, step_over,
step_in, step_out, pause, evaluate, stack_trace, threads, scopes, variables, output,
terminate, sessions, disassemble, read_memory, write_memory, modules, loaded_sources,
custom_request`,
    parameters: DEBUG_PARAMETERS,
    output: {
      schema: { type: 'string', description: 'Debug session/operation summary for the model.' },
      render: (_args: unknown, value) => [{ type: 'text', text: String(value) }],
    },
    async execute(args: unknown, exec) {
      const params = (args ?? {}) as Record<string, unknown>
      const timeout = clampT(params.timeout)
      const { signal, timeoutMs } = signalAndTimeout(timeout, exec)
      const callerCwd = cwdOrProcess(exec)
      const cwd = typeof params.cwd === 'string' && params.cwd ? resolveToCwd(params.cwd, callerCwd) : callerCwd
      const action = String(params.action ?? '').trim()

      switch (action) {
        // ── Session management ─────────────────────────
        case 'launch': {
          const program = typeof params.program === 'string' && params.program ? params.program : ''
          if (!program) throw new Error("'program' is required for launch.")
          const absProgram = resolveToCwd(program, cwd)
          const kind = await classifyProgram(absProgram)
          const adapter = selectLaunchAdapter(absProgram, cwd, typeof params.adapter === 'string' ? params.adapter : undefined, kind)
          if (!adapter) {
            if (params.adapter === 'debugpy') throw new Error("Adapter 'debugpy' is not available. Install it with: pip install debugpy")
            throw new Error(`No debug adapter available. Installed: ${getAdaptersList(cwd)}`)
          }
          const extra = resolveLaunchOverrides(adapter, absProgram, kind)
          const progArgs = Array.isArray(params.args) ? params.args as string[] : undefined
          const snap = await mgr().launch({ adapter, program: absProgram, args: progArgs, cwd, extraLaunchArguments: extra }, signal, timeoutMs)
          return fmtSession(snap).join('\n')
        }
        case 'attach': {
          const pid = typeof params.pid === 'number' ? params.pid : undefined
          const port = typeof params.port === 'number' ? params.port : undefined
          if (pid === undefined && port === undefined) throw new Error("'pid' or 'port' is required for attach.")
          const adapter = selectAttachAdapter(cwd, typeof params.adapter === 'string' ? params.adapter : undefined, port)
          if (!adapter) throw new Error(`No debug adapter available. Installed: ${getAdaptersList(cwd)}`)
          const snap = await mgr().attach({ adapter, cwd, pid, port, host: typeof params.host === 'string' ? params.host : undefined }, signal, timeoutMs)
          return fmtSession(snap).join('\n')
        }
        case 'terminate': {
          const snap = await mgr().terminate(signal, timeoutMs)
          if (!snap) return 'No debug session to terminate.'
          return [...fmtSession(snap), 'Debug session terminated.'].join('\n')
        }
        case 'sessions': {
          return fmtSessions(mgr().listSessions())
        }
        case 'output': {
          const { snapshot, output } = mgr().getOutput()
          const hdr = fmtSession(snapshot).join('\n')
          return output.length ? `${hdr}\n--- output ---\n${output}` : `${hdr}\n(no output captured)`
        }

        // ── Breakpoints ───────────────────────────────
        case 'set_breakpoint': {
          if (typeof params.function === 'string' && params.function) {
            const r = await mgr().setFunctionBreakpoint(params.function, typeof params.condition === 'string' ? params.condition : undefined, signal, timeoutMs)
            return fmtFnBps(r.breakpoints)
          }
          if (typeof params.file !== 'string' || typeof params.line !== 'number') throw new Error("'file' and 'line' required.")
          const r = await mgr().setBreakpoint(resolveToCwd(params.file, cwd), params.line, typeof params.condition === 'string' ? params.condition : undefined, signal, timeoutMs)
          return fmtBps(r.sourcePath, r.breakpoints)
        }
        case 'remove_breakpoint': {
          if (typeof params.function === 'string' && params.function) {
            const r = await mgr().removeFunctionBreakpoint(params.function, signal, timeoutMs)
            return fmtFnBps(r.breakpoints)
          }
          if (typeof params.file !== 'string' || typeof params.line !== 'number') throw new Error("'file' and 'line' required.")
          const r = await mgr().removeBreakpoint(resolveToCwd(params.file, cwd), params.line, signal, timeoutMs)
          return fmtBps(r.sourcePath, r.breakpoints)
        }

        // ── Execution control ─────────────────────────
        case 'continue': { const o = await mgr().continue(signal, timeoutMs); return outcomeText(o, timeout, 'Continue') }
        case 'step_over': { const o = await mgr().stepOver(signal, timeoutMs); return outcomeText(o, timeout, 'Step over') }
        case 'step_in': { const o = await mgr().stepIn(signal, timeoutMs); return outcomeText(o, timeout, 'Step in') }
        case 'step_out': { const o = await mgr().stepOut(signal, timeoutMs); return outcomeText(o, timeout, 'Step out') }
        case 'pause': { const snap = await mgr().pause(signal, timeoutMs); return [...fmtSession(snap), 'Program paused.'].join('\n') }

        // ── State inspection ──────────────────────────
        case 'evaluate': {
          if (typeof params.expression !== 'string' || !params.expression) throw new Error("'expression' required.")
          const evalCtx = (typeof params.context === 'string' ? params.context : 'repl') as 'watch' | 'repl' | 'hover' | 'clipboard' | 'variables'
          const r = await mgr().evaluate(params.expression, evalCtx, typeof params.frame_id === 'number' ? params.frame_id : undefined, signal, timeoutMs)
          return fmtEval(r.evaluation)
        }
        case 'stack_trace': {
          const r = await mgr().stackTrace(typeof params.levels === 'number' ? params.levels : undefined, signal, timeoutMs)
          return `${fmtSession(r.snapshot).join('\n')}\n${fmtFrames(r.stackFrames)}`
        }
        case 'threads': { const r = await mgr().threads(signal, timeoutMs); return fmtThreads(r.threads) }
        case 'scopes': { const r = await mgr().scopes(typeof params.frame_id === 'number' ? params.frame_id : undefined, signal, timeoutMs); return fmtScopes(r.scopes) }
        case 'variables': {
          const ref = typeof params.variable_ref === 'number' ? params.variable_ref : typeof params.scope_id === 'number' ? params.scope_id : undefined
          if (ref === undefined) throw new Error("'variable_ref' or 'scope_id' required.")
          const r = await mgr().variables(ref, signal, timeoutMs)
          return fmtVars(r.variables)
        }

        // ── Memory & disassembly ──────────────────────
        case 'disassemble': {
          requireCap('supportsDisassembleRequest', 'disassembly')
          if (typeof params.instruction_count !== 'number') throw new Error("'instruction_count' required.")
          const mref = typeof params.memory_reference === 'string' ? params.memory_reference : mgr().getActiveSession()?.instructionPointerReference ?? ''
          const r = await mgr().disassemble(mref, params.instruction_count, typeof params.offset === 'number' ? params.offset : undefined, undefined, params.resolve_symbols as boolean | undefined, signal, timeoutMs)
          return fmtDisasm(r.instructions)
        }
        case 'read_memory': {
          requireCap('supportsReadMemoryRequest', 'memory reads')
          if (typeof params.memory_reference !== 'string' || typeof params.count !== 'number') throw new Error("'memory_reference' and 'count' required.")
          const r = await mgr().readMemory(params.memory_reference, params.count, typeof params.offset === 'number' ? params.offset : undefined, signal, timeoutMs)
          return fmtMemRead(r.address, r.data, r.unreadableBytes)
        }
        case 'write_memory': {
          requireCap('supportsWriteMemoryRequest', 'memory writes')
          if (typeof params.memory_reference !== 'string' || typeof params.data !== 'string')
            throw new Error("'memory_reference' and 'data' required (data is base64-encoded bytes).")
          const r = await mgr().writeMemory(params.memory_reference, params.data, typeof params.offset === 'number' ? params.offset : undefined, undefined, signal, timeoutMs)
          const bytesStr = r.bytesWritten !== undefined ? `${r.bytesWritten} bytes` : ''
          const offStr = r.offset !== undefined ? ` at offset ${r.offset}` : ''
          return `Wrote ${bytesStr}${offStr} to ${params.memory_reference}`
        }
        case 'custom_request': {
          if (typeof params.command !== 'string' || !params.command)
            throw new Error("'command' required for custom_request.")
          const reqArgs = params.arguments as Record<string, unknown> | undefined
          const r = await mgr().customRequest(params.command, reqArgs, signal, timeoutMs)
          return JSON.stringify(r, null, 2)
        }

        // ── Introspection ─────────────────────────────
        case 'modules': {
          requireCap('supportsModulesRequest', 'module introspection')
          const r = await mgr().modules(undefined, undefined, signal, timeoutMs)
          return fmtModules(r.modules)
        }
        case 'loaded_sources': {
          requireCap('supportsLoadedSourcesRequest', 'loaded sources')
          const r = await mgr().loadedSources(signal, timeoutMs)
          return fmtSources(r.sources)
        }

        default:
          throw new Error(`Unsupported debug action: ${action}. Supported: launch, attach, set_breakpoint, remove_breakpoint, continue, step_over, step_in, step_out, pause, evaluate, stack_trace, threads, scopes, variables, output, terminate, sessions, disassemble, read_memory, write_memory, modules, loaded_sources, custom_request`)
      }
    },
  }
}

/**
 * The `debug` ToolDefinition. Debug-session cleanup is handled by the manager's
 * own idle/cleanup timers (terminated or idle sessions are disposed on a fixed
 * cadence), so no plugin lifecycle hook is required.
 */
export function dapTools(): ToolDefinition[] {
  return [debugTool()]
}
