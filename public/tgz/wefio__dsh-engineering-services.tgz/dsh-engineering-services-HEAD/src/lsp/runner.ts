import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { collectSupportedFiles, resolveRoot, resolveSupportedFile } from "./files.js";
import { LspClient } from "./lsp-client.js";
import { applyTextEdits, collectAllWorkspaceEdits, collectWorkspaceEdits, hasOverlappingTextEdits } from "./text-edits.js";
import type {
	CodeAction,
	DiagnosticEntry,
	LspServerAdapter,
	LspTextEdit,
	StatusContext,
	WorkspaceEdit,
} from "./types.js";

export const DEFAULT_FILE_LIMIT = 50;

export async function runDiagnostics(
	adapter: LspServerAdapter,
	params: { root?: string; paths?: string[]; limit?: number; files?: string[] },
	timeoutMs: number,
	signal: AbortSignal | undefined,
	ctx: StatusContext,
	statusKey: string,
) {
	const root = resolveRoot(params.root);
	const command = adapter.defaultCommand;
	const files =
		params.files ??
		collectSupportedFiles(adapter, root, params.paths, params.limit ?? DEFAULT_FILE_LIMIT);
	if (files.length === 0) {
		return textResult(`${adapter.name} LSP found no supported files to check.`, {
			root,
			command,
			files: [],
			summary: { files: 0, diagnostics: 0 },
		});
	}

	const client = new LspClient(adapter, command, root, timeoutMs);
	const abort = () => client.close();
	throwIfAborted(signal, adapter);
	signal?.addEventListener("abort", abort, { once: true });

	try {
		ctx.ui.setStatus(statusKey, `${adapter.name} diagnostics`);
		throwIfAborted(signal, adapter);
		await client.start();
		await client.initialize(root);

		const openedFiles: Array<{ file: string; uri: string }> = [];
		try {
			for (const file of files) {
				throwIfAborted(signal, adapter);
				const uri = pathToFileURL(file).href;
				const text = readFileSync(file, "utf8");
				client.didOpen(uri, text, adapter.languageIdFor(file));
				openedFiles.push({ file, uri });
			}

			const entries: DiagnosticEntry[] = await Promise.all(
				openedFiles.map(async ({ file, uri }) => ({
					path: path.relative(root, file) || file,
					uri,
					diagnostics: await client.diagnostics(uri),
				})),
			);
			return textResult(formatDiagnostics(adapter, entries), {
				root,
				command,
				files: entries,
				summary: summarize(entries),
			});
		} finally {
			for (const { uri } of openedFiles) client.didClose(uri);
		}
	} finally {
		ctx.ui.setStatus(statusKey, undefined);
		signal?.removeEventListener("abort", abort);
		await client.shutdown();
	}
}

export async function runFix(
	adapter: LspServerAdapter,
	params: { root?: string; path: string; kind?: string; write?: boolean },
	timeoutMs: number,
	signal: AbortSignal | undefined,
	ctx: StatusContext,
	statusKey: string,
) {
	const root = resolveRoot(params.root);
	const file = resolveSupportedFile(adapter, root, params.path);
	const actionKind = params.kind?.trim() || "source.fixAll";

	const command = adapter.defaultCommand;
	const client = new LspClient(adapter, command, root, timeoutMs);
	const abort = () => client.close();
	throwIfAborted(signal, adapter);
	signal?.addEventListener("abort", abort, { once: true });

	try {
		ctx.ui.setStatus(statusKey, `${adapter.name} fix`);
		throwIfAborted(signal, adapter);
		await client.start();
		await client.initialize(root);
		throwIfAborted(signal, adapter);
		const uri = pathToFileURL(file).href;
		const text = readFileSync(file, "utf8");
		client.didOpen(uri, text, adapter.languageIdFor(file));
		let resolvedActions: CodeAction[];
		let selectedActions: CodeAction[];
		let edits: LspTextEdit[];
		let newText: string;
		try {
			const diagnostics = await client.diagnostics(uri);
			const actions = await client.codeActions(uri, text, diagnostics, actionKind);
			resolvedActions = await client.resolveActions(actions);
			selectedActions = selectCodeActions(resolvedActions, actionKind);
			edits = selectedActions.flatMap((action) => collectWorkspaceEdits(action.edit, uri));
			if (hasOverlappingTextEdits(text, edits)) {
				const relativePath = path.relative(root, file) || file;
				throw new Error(
					`${adapter.name} LSP returned overlapping code-action edits for ${relativePath}; ` +
						"use a narrower action kind.",
				);
			}
			newText = applyTextEdits(text, edits);
		} finally {
			client.didClose(uri);
		}
		const changed = newText !== text;

		if (params.write && changed) writeFileSync(file, newText);

		return textResult(
			formatEditSummary(adapter, "fix", root, file, changed, params.write, newText),
			{
				path: path.relative(root, file) || file,
				uri,
				changed,
				write: params.write ?? false,
				kind: actionKind,
				actions: resolvedActions.map(({ title, kind }) => ({ title, kind })),
				appliedActions: selectedActions.map(({ title, kind }) => ({ title, kind })),
				edits,
				text: params.write ? undefined : newText,
			},
		);
	} finally {
		ctx.ui.setStatus(statusKey, undefined);
		signal?.removeEventListener("abort", abort);
		await client.shutdown();
	}
}

function selectCodeActions(actions: CodeAction[], requestedKind: string) {
	return actions.filter(
		(action) => action.kind === requestedKind || action.kind?.startsWith(`${requestedKind}.`),
	);
}

function formatDiagnostics(adapter: LspServerAdapter, entries: DiagnosticEntry[]) {
	const lines = entries.flatMap((entry) => {
		if (entry.diagnostics.length === 0) return [`${entry.path}: no diagnostics`];

		return entry.diagnostics.map((diagnostic) => {
			const line = diagnostic.range.start.line + 1;
			const column = diagnostic.range.start.character + 1;
			const severity = severityName(diagnostic.severity);
			const source = diagnostic.source ?? adapter.name;
			const code = diagnostic.code === undefined ? "" : ` ${diagnostic.code}`;
			return `${entry.path}:${line}:${column}: ${severity} ${source}${code}: ${diagnostic.message}`;
		});
	});

	const summary = summarize(entries);
	return [
		`${adapter.name} LSP diagnostics: ${summary.diagnostics} diagnostic(s) across ${summary.files} file(s).`,
		"",
		...lines,
	].join("\n");
}

function formatEditSummary(
	adapter: LspServerAdapter,
	action: "fix",
	root: string,
	file: string,
	changed: boolean,
	write: boolean | undefined,
	text: string,
) {
	const relativePath = path.relative(root, file) || file;
	const status = changed ? (write ? "updated" : "computed changes for") : "left unchanged";
	const summary = `${adapter.name} LSP ${action} ${status} ${relativePath}.`;
	if (write || !changed) return summary;
	return `${summary}\n\n${text}`;
}

function summarize(entries: DiagnosticEntry[]) {
	return {
		files: entries.length,
		diagnostics: entries.reduce((total, entry) => total + entry.diagnostics.length, 0),
	};
}

function severityName(severity: number | undefined) {
	if (severity === 1) return "error";
	if (severity === 2) return "warning";
	if (severity === 3) return "info";
	if (severity === 4) return "hint";
	return "diagnostic";
}

function throwIfAborted(signal: AbortSignal | undefined, adapter: LspServerAdapter) {
	if (signal?.aborted) throw new Error(`${adapter.name} LSP request aborted.`);
}

export type NavigationMode =
	| "hover"
	| "definition"
	| "implementation"
	| "references"
	| "symbols"
	| "type_definition"
	| "document_highlight";

export interface NavigationParams {
	root: string;
	file: string;
	mode: NavigationMode;
	line?: number;
	character?: number;
	includeDeclaration?: boolean;
}

interface LspLocation {
	uri?: string;
	range?: {
		start: { line: number; character: number };
		end: { line: number; character: number };
	};
}

type HoverContent =
	| string
	| { kind?: string; value?: string }
	| Array<string | { kind?: string; value?: string }>;

export async function runNavigationQuery(
	adapter: LspServerAdapter,
	params: NavigationParams,
	timeoutMs: number,
	signal: AbortSignal | undefined,
	ctx: StatusContext,
	statusKey: string,
) {
	const client = new LspClient(adapter, adapter.defaultCommand, params.root, timeoutMs);
	const abort = () => client.close();
	throwIfAborted(signal, adapter);
	signal?.addEventListener("abort", abort, { once: true });

	try {
		ctx.ui.setStatus(statusKey, `${adapter.name} ${params.mode}`);
		throwIfAborted(signal, adapter);
		await client.start();
		await client.initialize(params.root);
		const uri = pathToFileURL(params.file).href;
		const text = readFileSync(params.file, "utf8");
		client.didOpen(uri, text, adapter.languageIdFor(params.file));

		const line = params.line ?? 0;
		const character = params.character ?? 0;
		let result: unknown;
		switch (params.mode) {
			case "hover":
				result = await client.hover(uri, line, character);
				break;
			case "definition":
				result = await client.definition(uri, line, character);
				break;
			case "implementation":
				result = await client.implementation(uri, line, character);
				break;
			case "references":
				result = await client.references(uri, line, character, params.includeDeclaration ?? true);
				break;
			case "symbols":
				result = await client.documentSymbols(uri);
				break;
			case "type_definition":
				result = await client.typeDefinition(uri, line, character);
				break;
			case "document_highlight":
				result = await client.documentHighlight(uri, line, character);
				break;
		}

		const formatted = formatNavigationResult(params, result);
		const relativeFile = path.relative(params.root, params.file) || params.file;
		return textResult(`${adapter.name} ${params.mode} — ${relativeFile}\n\n${formatted}`, {
			file: relativeFile,
			mode: params.mode,
			adapter: adapter.name,
			result,
		});
	} finally {
		ctx.ui.setStatus(statusKey, undefined);
		signal?.removeEventListener("abort", abort);
		await client.shutdown();
	}
}

function formatNavigationResult(
	params: NavigationParams,
	result: unknown,
): string {
	if (result === null || result === undefined) {
		return `No ${params.mode} result at ${params.line ?? 0}:${params.character ?? 0}.`;
	}
	switch (params.mode) {
		case "hover":
			return formatHover(result);
		case "definition":
		case "implementation":
		case "references":
		case "type_definition":
			return formatLocations(result as LspLocation | LspLocation[]);
		case "document_highlight":
			return formatHighlights(result);
		case "symbols":
			return formatSymbols(result);
		default:
			return JSON.stringify(result, null, 2);
	}
}

function formatHover(result: unknown): string {
	const contents = (result as { contents?: HoverContent }).contents;
	if (contents === undefined || contents === null) {
		const raw = JSON.stringify(result, null, 2);
		return raw.length > 2000 ? `${raw.slice(0, 2000)}…` : raw;
	}
	const text = hoverContentToText(contents).trim();
	return text || "(empty hover)";
}

function hoverContentToText(contents: HoverContent): string {
	if (typeof contents === "string") return contents;
	if (Array.isArray(contents)) return contents.map(hoverContentToText).join("\n\n");
	if (contents && typeof contents === "object") return contents.value ?? "";
	return "";
}

function locationToText(loc: LspLocation): string {
	const file = loc.uri ? uriToDisplayPath(loc.uri) : "?";
	const start = loc.range?.start;
	const pos = start ? `${start.line + 1}:${start.character}` : "?";
	return `${file}:${pos}`;
}

function uriToDisplayPath(uri: string): string {
	try {
		return fileURLToPath(uri);
	} catch {
		return uri;
	}
}

function formatLocations(locations: LspLocation | LspLocation[]): string {
	const list = Array.isArray(locations) ? locations : [locations];
	if (list.length === 0) return "No locations.";
	return list.map(locationToText).join("\n");
}

interface LspHighlight {
	range?: {
		start: { line: number; character: number };
		end: { line: number; character: number };
	};
	kind?: number;
}

function formatHighlights(result: unknown): string {
	const list = Array.isArray(result) ? (result as LspHighlight[]) : [];
	if (list.length === 0) return "No highlights at this position.";
	return list
		.map((h) => {
			const start = h.range?.start;
			if (!start) return "?";
			const end = h.range?.end;
			const endText = end ? `-${end.line + 1}:${end.character}` : "";
			return `${start.line + 1}:${start.character}${endText}`;
		})
		.join("\n");
}

interface DocSymbol {
	name?: string;
	kind?: number;
	detail?: string;
	range?: { start: { line: number; character: number } };
	location?: LspLocation;
	children?: DocSymbol[];
}

function formatSymbols(result: unknown, indent = ""): string {
	const list = Array.isArray(result) ? (result as DocSymbol[]) : [];
	const lines: string[] = [];
	for (const symbol of list) {
		if (!symbol) continue;
		const name = symbol.name ?? "?";
		const detail = symbol.detail ? ` — ${symbol.detail}` : "";
		const pos = symbol.range?.start
			? `:${symbol.range.start.line + 1}`
			: symbol.location?.range?.start
				? `:${symbol.location.range.start.line + 1}`
				: "";
		lines.push(`${indent}${name}${pos}${detail}`);
		if (symbol.children?.length) {
			lines.push(formatSymbols(symbol.children, `${indent}  `));
		}
	}
	return lines.join("\n");
}

export async function runWorkspaceSymbolQuery(
	adapter: LspServerAdapter,
	params: { root: string; query: string; files: string[] },
	timeoutMs: number,
	signal: AbortSignal | undefined,
	ctx: StatusContext,
	statusKey: string,
) {
	const client = new LspClient(adapter, adapter.defaultCommand, params.root, timeoutMs);
	const abort = () => client.close();
	throwIfAborted(signal, adapter);
	signal?.addEventListener("abort", abort, { once: true });

	try {
		ctx.ui.setStatus(statusKey, `${adapter.name} workspace symbol`);
		throwIfAborted(signal, adapter);
		await client.start();
		await client.initialize(params.root);
		// Open context files so servers that search a loaded program (e.g.
		// tsserver) have files to index before answering workspace/symbol.
		// tsserver's workspace/symbol is anchored to its most recently opened
		// document (navto file=lastFileOrDummy), so the first context file (the
		// anchor / requested path) must be opened LAST.
		for (const file of [...params.files].reverse()) {
			if (!existsSync(file)) continue;
			const uri = pathToFileURL(file).href;
			client.didOpen(uri, readFileSync(file, "utf8"), adapter.languageIdFor(file));
		}
		const result = await client.workspaceSymbol(params.query);
		const note =
			adapter.name === "typescript-language-server"
				? "\n\nNote: tsserver only searches the program loaded from the opened context file (it does not index the whole project). Pass `path` to anchor the search; for whole-project symbol search use rg/grep."
				: "";
		return textResult(
			`${adapter.name} workspace symbol — "${params.query}"\n\n${formatWorkspaceSymbols(result)}${note}`,
			{ query: params.query, adapter: adapter.name, result, openedFiles: params.files.length },
		);
	} finally {
		ctx.ui.setStatus(statusKey, undefined);
		signal?.removeEventListener("abort", abort);
		await client.shutdown();
	}
}

interface WorkspaceSymbolInfo {
	name?: string;
	kind?: number;
	containerName?: string;
	location?:
		| { uri?: string; range?: { start: { line: number; character: number } } }
		| string;
}

function formatWorkspaceSymbols(result: unknown): string {
	const list = Array.isArray(result) ? (result as WorkspaceSymbolInfo[]) : [];
	if (list.length === 0) return "No symbols found.";
	return list
		.map((symbol) => {
			const name = symbol.name ?? "?";
			const container = symbol.containerName ? ` (in ${symbol.containerName})` : "";
			const loc = symbol.location;
			if (typeof loc === "string") return `${name}${container} — ${loc}`;
			const file = loc?.uri ? uriToDisplayPath(loc.uri) : "?";
			const line = loc?.range?.start ? loc.range.start.line + 1 : "?";
			return `${name}${container} — ${file}:${line}`;
		})
		.join("\n");
}

export async function runRename(
	adapter: LspServerAdapter,
	params: {
		root: string;
		file: string;
		line: number;
		character: number;
		newName: string;
		write: boolean;
	},
	timeoutMs: number,
	signal: AbortSignal | undefined,
	ctx: StatusContext,
	statusKey: string,
) {
	const client = new LspClient(adapter, adapter.defaultCommand, params.root, timeoutMs);
	const abort = () => client.close();
	throwIfAborted(signal, adapter);
	signal?.addEventListener("abort", abort, { once: true });

	try {
		ctx.ui.setStatus(statusKey, `${adapter.name} rename`);
		throwIfAborted(signal, adapter);
		await client.start();
		await client.initialize(params.root);
		const uri = pathToFileURL(params.file).href;
		const text = readFileSync(params.file, "utf8");
		client.didOpen(uri, text, adapter.languageIdFor(params.file));

		const workspaceEdit = (await client.rename(
			uri,
			params.line,
			params.character,
			params.newName,
		)) as WorkspaceEdit | null | undefined;
		if (!workspaceEdit) {
			return textResult(
				`${adapter.name} rename returned no edits — no symbol found at ${params.line}:${params.character} or the server does not support rename there.`,
				{ changed: false },
			);
		}

		const byUri = collectAllWorkspaceEdits(workspaceEdit);
		const changedFiles: Array<{ file: string; edits: LspTextEdit[]; newText: string }> = [];
		const errors: string[] = [];
		for (const [u, edits] of byUri) {
			try {
				const file = fileURLToPath(u);
				const oldText = readFileSync(file, "utf8");
				if (hasOverlappingTextEdits(oldText, edits)) {
					errors.push(`${file}: overlapping edits; skipped`);
					continue;
				}
				const newText = applyTextEdits(oldText, edits);
				changedFiles.push({ file, edits, newText });
			} catch (error) {
				errors.push(`${u}: ${error instanceof Error ? error.message : String(error)}`);
			}
		}

		let applied = 0;
		for (const c of changedFiles) {
			if (c.newText === readFileSync(c.file, "utf8")) continue;
			if (params.write) writeFileSync(c.file, c.newText);
			applied += 1;
		}

		const relative = (f: string) => path.relative(params.root, f) || f;
		const lines = changedFiles.map(
			(c) => `  ${relative(c.file)} — ${c.edits.length} edit(s)${params.write ? " (applied)" : ""}`,
		);
		const preview = params.write
			? ""
			: `\n\n${changedFiles
					.map((c) => `## ${relative(c.file)}\n${formatEditsDiff(readFileSync(c.file, "utf8"), c.edits)}`)
					.join("\n")}`;
		const errorBlock = errors.length ? `\n\nErrors (skipped):\n${errors.join("\n")}` : "";
		return textResult(
			`${adapter.name} rename → "${params.newName}" — ${applied} file(s) ${
				params.write ? "rewritten" : "would be changed"
			}\n${lines.join("\n")}${preview}${errorBlock}`,
			{
				changed: applied > 0,
				applied,
				newName: params.newName,
				files: changedFiles.map((c) => c.file),
			},
		);
	} finally {
		ctx.ui.setStatus(statusKey, undefined);
		signal?.removeEventListener("abort", abort);
		await client.shutdown();
	}
}

function formatEditsDiff(text: string, edits: LspTextEdit[]): string {
	const lines = text.split("\n");
	const out: string[] = [];
	const sorted = [...edits].sort(
		(a, b) =>
			a.range.start.line - b.range.start.line ||
			a.range.start.character - b.range.start.character,
	);
	for (const e of sorted) {
		const firstLine = lines[e.range.start.line] ?? "";
		out.push(`  - ${firstLine}`);
		for (const nl of e.newText.split("\n")) out.push(`  + ${nl}`);
	}
	return out.join("\n");
}

export function textResult(text: string, details: unknown) {
	return {
		content: [{ type: "text" as const, text }],
		details,
	};
}
