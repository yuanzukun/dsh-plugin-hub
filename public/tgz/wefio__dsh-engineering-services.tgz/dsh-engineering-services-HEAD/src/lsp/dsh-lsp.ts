/**
 * LSP tool suite for DSH — 12 tools over language servers (pyright / tsserver
 * and friends), ported from the pi edition.
 *
 * The core (`lsp-client`, `files`, `routes`, `command`, `runner`, `types`) is
 * host-agnostic and untouched. Only the wire-up below adapts pi's
 * defineTool + ExtensionAPI to DSH's `ctx.tools.register(ToolDefinition)`.
 *
 * Verified scope (the pi edition's tested servers): **pyright** (Python) and
 * **typescript-language-server** (TS/JS). They are configured via
 * `<workspace>/.dsh/pi-lsp.json` or `~/.dsh/pi-lsp.json` (same schema as the
 * pi edition's `pi-lsp.json`); a broad set of built-in fallback servers is
 * also available but experimental.
 * @module dsh-engineering-services/lsp
 */
import type { ToolDefinition, ToolRunContext } from '@deepseek-ai/dsh-tools'
import path from 'node:path'

import { consumeLspConfigNotice, loadRuntime } from './adapters.js'
import { commandExists, commandPathValue } from './command.js'
import { collectContextFiles, resolveRoot } from './files.js'
import { selectDiagnosticRoutes, selectFixRoute } from './routes.js'
import {
  DEFAULT_FILE_LIMIT,
  runDiagnostics,
  runFix,
  runNavigationQuery,
  runRename,
  runWorkspaceSymbolQuery,
  type NavigationMode,
} from './runner.js'
import type { LspServerAdapter, StatusContext } from './types.js'
import { cwdOrProcess, textOutput } from '../toolkit.js'

const STATUS_KEY = 'lsp'

// Per-process LSP state. Servers here are skipped by the tools until re-enabled
// with lsp_toggle. (pi kept this per-conversation; DSH lifetimes are process-bound.)
const disabledServers = new Set<string>()

const LSP_TOOL_NAMES: string[] = [
  'lsp_diagnostics',
  'lsp_fix',
  'lsp_toggle',
  'lsp_hover',
  'lsp_definition',
  'lsp_implementation',
  'lsp_references',
  'lsp_symbols',
  'lsp_type_definition',
  'lsp_document_highlight',
  'lsp_rename',
  'lsp_workspace_symbol',
]

/** A no-op status banner. pi drove a status line via ctx.ui; DSH has no such
 * per-tool banner, so the runner's StatusContext is satisfied with a no-op. */
const STATUS_CTX: StatusContext = { ui: { setStatus: () => {} } }

/** Pull the model-facing text out of a pi-style `{ content, details }` result. */
function textOf(result: { content?: Array<{ type?: string; text?: string }> }): string {
  return result.content?.find((item) => item.type === 'text')?.text ?? ''
}

function selectedServerNames(selected: string | string[] | undefined): string[] {
  if (!selected) return []
  return (Array.isArray(selected) ? selected : [selected])
    .map((name) => name.trim())
    .filter((name) => name.length > 0)
}

function resolveServerEnabled(server: string, mode: 'on' | 'off' | 'toggle'): boolean {
  return mode === 'on' ? true : mode === 'off' ? false : disabledServers.has(server)
}

function applyServerEnabled(server: string, enabled: boolean) {
  if (enabled) disabledServers.delete(server)
  else disabledServers.add(server)
}

// ── Tool definitions ───────────────────────────────────────────

const ServerParameter = {
  type: ['string', 'array'],
  items: { type: 'string' },
  description: 'Optional configured LSP server name, or names for diagnostics. Defaults to all servers matching the file extension.',
}

const SingleFileProperties: Record<string, unknown> = {
  path: { type: 'string', description: 'File to process. The server is selected from configured file extensions.' },
  root: { type: 'string', description: 'Workspace root for language servers. Defaults to the session workspace.' },
  write: { type: 'boolean', description: 'Write changed text back to the file. Defaults to false.' },
  server: { type: 'string', description: 'Optional configured LSP server name. Defaults to extension-based inference.' },
}

const NavigationBaseProperties: Record<string, unknown> = {
  path: { type: 'string', description: 'File path to query.' },
  root: { type: 'string', description: 'Workspace root for language servers. Defaults to the session workspace.' },
  server: { type: 'string', description: 'Server name. Defaults to extension-based inference.' },
}

function diagnosticsTool(): ToolDefinition {
  return {
    name: 'lsp_diagnostics',
    description: 'Run diagnostics using configured, language-agnostic LSP server routes.',
    parameters: {
      type: 'object',
      properties: {
        paths: { type: 'array', items: { type: 'string' }, description: 'Files or directories to check. Defaults to the workspace root and routes by configured server extensions.' },
        root: { type: 'string', description: 'Workspace root for language servers. Defaults to the session workspace.' },
        limit: { type: 'number', description: 'Maximum files to open per selected server.' },
        server: ServerParameter,
      },
      additionalProperties: false,
    },
    output: textOutput(),
    async execute(args: unknown, ctx: ToolRunContext) {
      const params = (args ?? {}) as {
        paths?: string[]; root?: string; limit?: number; server?: string | string[]
      }
      const cwd = cwdOrProcess(ctx)
      const requestedRoot = resolveRoot(params.root)
      const { adapters, timeoutMs } = loadRuntime(cwd, { projectTrusted: true })
      const explicitlyDisabled = selectedServerNames(params.server).filter((name) =>
        disabledServers.has(name),
      )
      if (explicitlyDisabled.length > 0) {
        throw new Error(
          `Disabled LSP server(s): ${explicitlyDisabled.join(', ')}. Enable with lsp_toggle (server: ${explicitlyDisabled.join(' ')}, enable: true).`,
        )
      }
      const available = adapters.filter((adapter) => !disabledServers.has(adapter.name))
      const disabled = adapters
        .filter((adapter) => disabledServers.has(adapter.name))
        .map((adapter) => adapter.name)
      const { root, routes, skipped } = selectDiagnosticRoutes(
        available,
        { ...params, root: requestedRoot },
        DEFAULT_FILE_LIMIT,
      )
      const sections: string[] = []
      const details: Array<{ server: string; reason: string; files: string[]; details?: unknown }> = []
      for (const route of routes) {
        const result = await runDiagnostics(
          route.adapter,
          { root, paths: params.paths, limit: params.limit, files: route.files },
          timeoutMs,
          ctx.signal,
          STATUS_CTX,
          STATUS_KEY,
        )
        sections.push(`${route.reason}\n\n${textOf(result)}`)
        details.push({ server: route.adapter.name, reason: route.reason, files: route.files, details: (result as { details?: unknown }).details })
      }
      if (skipped.length) {
        sections.push(
          `Skipped unavailable default LSP server(s): ${skipped
            .map((route) => route.adapter.name)
            .join(', ')}.`,
        )
      }
      if (disabled.length) {
        sections.push(`Disabled LSP server(s) skipped: ${disabled.join(', ')}.`)
      }
      const notice = consumeLspConfigNotice()
      if (notice) sections.push(`LSP config: ${notice}`)
      return sections.join('\n\n---\n\n')
    },
  }
}

function fixTool(): ToolDefinition {
  return {
    name: 'lsp_fix',
    description: 'Apply source fixes or import organization using configured LSP server routes.',
    parameters: {
      type: 'object',
      properties: {
        ...SingleFileProperties,
        kind: { type: 'string', description: 'Source action kind. Defaults to source.fixAll.' },
      },
      required: ['path'],
      additionalProperties: false,
    },
    output: textOutput(),
    async execute(args: unknown, ctx: ToolRunContext) {
      const params = (args ?? {}) as {
        path?: string; root?: string; write?: boolean; server?: string; kind?: string
      }
      const cwd = cwdOrProcess(ctx)
      const requestedRoot = resolveRoot(params.root)
      const { adapters, timeoutMs } = loadRuntime(cwd, { projectTrusted: true })
      if (params.server && disabledServers.has(params.server!)) {
        throw new Error(`Disabled LSP server: ${params.server}. Enable with lsp_toggle.`)
      }
      const available = adapters.filter((adapter) => !disabledServers.has(adapter.name))
      const { root, route } = selectFixRoute(available, {
        path: params.path ?? '',
        root: requestedRoot,
        server: params.server,
      })
      const result = await runFix(
        route.adapter,
        { root, path: params.path ?? '', kind: params.kind, write: params.write },
        timeoutMs,
        ctx.signal,
        STATUS_CTX,
        STATUS_KEY,
      )
      return textOf(result)
    },
  }
}

function toggleTool(): ToolDefinition {
  return {
    name: 'lsp_toggle',
    description:
      'Enable or disable an LSP server for this session. Disabled servers are skipped by lsp_diagnostics and lsp_fix until re-enabled. State lasts until the plugin reloads.',
    parameters: {
      type: 'object',
      properties: {
        server: { type: 'string', description: 'Server name to enable or disable.' },
        enable: { type: 'boolean', description: 'true = enable, false = disable. Omit to toggle the current state.' },
      },
      additionalProperties: false,
    },
    output: textOutput(),
    async execute(args: unknown, ctx: ToolRunContext) {
      const params = (args ?? {}) as { server?: string; enable?: boolean }
      const cwd = cwdOrProcess(ctx)
      const mode: 'on' | 'off' | 'toggle' =
        params.enable === undefined ? 'toggle' : params.enable ? 'on' : 'off'
      if (params.server) {
        const { adapters } = loadRuntime(cwd, { projectTrusted: true })
        if (!adapters.some((adapter) => adapter.name === params.server)) {
          return `Unknown LSP server: ${params.server}. Configured: ${adapters
            .map((a) => a.name)
            .join(', ') || 'none'}.`
        }
        const enabled = resolveServerEnabled(params.server, mode)
        applyServerEnabled(params.server, enabled)
        return `LSP server ${params.server} ${enabled ? 'enabled' : 'disabled'} for this session.`
      }
      // Without a server we toggle by resetting the whole disabled set — DSH has
      // no per-conversation active-tool-set API (pi's /lsp did). Keep the tool set
      // always-present; a bare `lsp_toggle` with enable=false disables ALL servers.
      if (mode === 'off') {
        for (const a of loadRuntime(cwd, { projectTrusted: true }).adapters) disabledServers.add(a.name)
        return `All ${disabledServers.size} LSP server(s) disabled for this session.`
      }
      disabledServers.clear()
      return 'Enabled all configured LSP servers for this session.'
    },
  }
}

interface NavigationParams {
  path: string
  root?: string
  server?: string
  line?: number
  character?: number
  includeDeclaration?: boolean
}

function selectNavigationAdapter(
  adapters: ReturnType<typeof loadRuntime>['adapters'],
  params: { root?: string; path: string; server?: string },
): { root: string; file: string; adapter: LspServerAdapter } {
  const root = resolveRoot(params.root)
  const file = path.resolve(root, params.path)
  const candidates = adapters
    .filter((adapter) => !params.server || adapter.name === params.server)
    .filter((adapter) => adapter.isSupportedFile(file))
  if (candidates.length === 0) {
    throw new Error(
      `No LSP server supports ${params.path}${params.server ? ` for server '${params.server}'` : ''}. ` +
        'Configured servers are selected by file extension in pi-lsp.json.',
    )
  }
  if (!params.server && candidates.length > 1) {
    throw new Error(
      `Multiple LSP servers support ${params.path}: ${candidates
        .map((adapter) => adapter.name)
        .join(', ')}. Specify the server parameter.`,
    )
  }
  return { root, file, adapter: candidates[0]! }
}

function makeNavigationTool(opts: {
  name: string
  description: string
  mode: NavigationMode
  includePosition?: boolean
  extra?: Record<string, unknown>
}): ToolDefinition {
  const properties: Record<string, unknown> = { ...NavigationBaseProperties }
  if (opts.includePosition !== false) {
    properties.line = { type: 'number', description: 'Zero-based line number. Defaults to 0.' }
    properties.character = { type: 'number', description: 'Zero-based character offset on the line. Defaults to 0.' }
  }
  if (opts.extra) Object.assign(properties, opts.extra)

  return {
    name: opts.name,
    description: opts.description,
    parameters: { type: 'object', properties, required: ['path'], additionalProperties: false },
    output: textOutput(),
    async execute(args: unknown, ctx: ToolRunContext) {
      const p = (args ?? {}) as NavigationParams
      const cwd = cwdOrProcess(ctx)
      const { adapters, timeoutMs } = loadRuntime(cwd, { projectTrusted: true })
      if (p.server && disabledServers.has(p.server)) {
        throw new Error(`Disabled LSP server: ${p.server}. Enable with lsp_toggle.`)
      }
      const available = adapters.filter((adapter) => !disabledServers.has(adapter.name))
      const { root, file, adapter } = selectNavigationAdapter(available, {
        root: p.root,
        path: p.path,
        server: p.server,
      })
      const result = await runNavigationQuery(
        adapter,
        {
          root,
          file,
          mode: opts.mode,
          line: p.line,
          character: p.character,
          includeDeclaration: p.includeDeclaration,
        },
        timeoutMs,
        ctx.signal,
        STATUS_CTX,
        STATUS_KEY,
      )
      return textOf(result)
    },
  }
}

function navigationTools(): ToolDefinition[] {
  return [
    makeNavigationTool({
      name: 'lsp_hover',
      description:
        'Show hover documentation (signature, types, doc comments) at a position in a file — e.g. what a function or variable does.',
      mode: 'hover',
    }),
    makeNavigationTool({
      name: 'lsp_definition',
      description: 'Find where the symbol at a position is defined (file:line:col).',
      mode: 'definition',
    }),
    makeNavigationTool({
      name: 'lsp_implementation',
      description:
        'Find where the symbol at a position is implemented (file:line:col). Note: tsserver only finds implementations in its loaded program (the opened file + its imports) — for an interface declared in a file that does not import its implementers, it may return nothing until the implementing file is loaded; pyright indexes the whole workspace instead.',
      mode: 'implementation',
    }),
    makeNavigationTool({
      name: 'lsp_references',
      description: 'Find references to the symbol at a position (file:line:col list).',
      mode: 'references',
      extra: {
        includeDeclaration: {
          type: 'boolean',
          description: 'Include the declaration itself in the results. Defaults to true.',
        },
      },
    }),
    makeNavigationTool({
      name: 'lsp_symbols',
      description: 'List the symbols (functions, classes, variables) declared in a file.',
      mode: 'symbols',
      includePosition: false,
    }),
    makeNavigationTool({
      name: 'lsp_type_definition',
      description: 'Find where the type of the symbol at a position is defined (file:line:col).',
      mode: 'type_definition',
    }),
    makeNavigationTool({
      name: 'lsp_document_highlight',
      description:
        'Highlight all occurrences of the symbol at a position within the same file (file:line:col list).',
      mode: 'document_highlight',
    }),
  ]
}

function renameTool(): ToolDefinition {
  return {
    name: 'lsp_rename',
    description:
      'Rename a symbol across the project (symbol-aware, safer than search-and-replace). Preview by default; set write:true to apply changes to disk.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path containing the symbol to rename.' },
        root: { type: 'string', description: 'Workspace root for language servers. Defaults to the session workspace.' },
        line: { type: 'number', description: 'Zero-based line number of the symbol. Defaults to 0.' },
        character: { type: 'number', description: 'Zero-based character offset of the symbol on the line. Defaults to 0.' },
        newName: { type: 'string', description: 'The new symbol name.' },
        write: { type: 'boolean', description: 'Write the changes to disk. Defaults to false (preview only).' },
        server: { type: 'string', description: 'Server name. Defaults to extension-based inference.' },
      },
      required: ['path', 'newName'],
      additionalProperties: false,
    },
    output: textOutput(),
    async execute(args: unknown, ctx: ToolRunContext) {
      const p = (args ?? {}) as {
        path: string; root?: string; line?: number; character?: number
        newName: string; write?: boolean; server?: string
      }
      const cwd = cwdOrProcess(ctx)
      const { adapters, timeoutMs } = loadRuntime(cwd, { projectTrusted: true })
      if (p.server && disabledServers.has(p.server)) {
        throw new Error(`Disabled LSP server: ${p.server}. Enable with lsp_toggle.`)
      }
      const available = adapters.filter((adapter) => !disabledServers.has(adapter.name))
      const { root, file, adapter } = selectNavigationAdapter(available, {
        root: p.root,
        path: p.path,
        server: p.server,
      })
      const result = await runRename(
        adapter,
        {
          root,
          file,
          line: p.line ?? 0,
          character: p.character ?? 0,
          newName: p.newName,
          write: p.write ?? false,
        },
        timeoutMs,
        ctx.signal,
        STATUS_CTX,
        STATUS_KEY,
      )
      return textOf(result)
    },
  }
}

function workspaceSymbolTool(): ToolDefinition {
  return {
    name: 'lsp_workspace_symbol',
    description:
      'Search for a symbol by name via workspace/symbol. Coverage depends on the server: pyright indexes the whole detected workspace; tsserver only searches the program loaded from the opened context file (pass `path` to anchor it) and does NOT index the whole project — for whole-project TS/JS symbol search prefer rg/grep.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Symbol name (or part of it) to search for.' },
        root: { type: 'string', description: 'Workspace root for language servers. Defaults to the session workspace.' },
        path: { type: 'string', description: 'A file in the workspace to open as project context (optional; a supported file is auto-picked if omitted).' },
        server: { type: 'string', description: 'Server name. Omit to search all configured servers.' },
      },
      required: ['query'],
      additionalProperties: false,
    },
    output: textOutput(),
    async execute(args: unknown, ctx: ToolRunContext) {
      const p = (args ?? {}) as { query: string; root?: string; path?: string; server?: string }
      const cwd = cwdOrProcess(ctx)
      const { adapters, timeoutMs } = loadRuntime(cwd, { projectTrusted: true })
      if (p.server && disabledServers.has(p.server)) {
        throw new Error(`Disabled LSP server: ${p.server}. Enable with lsp_toggle.`)
      }
      const available = adapters.filter((adapter) => !disabledServers.has(adapter.name))
      const root = resolveRoot(p.root)
      let targets = p.server
        ? available.filter((adapter) => adapter.name === p.server)
        : available
      // Same policy as diagnostics: when no server is requested, skip default
      // servers whose command isn't installed (e.g. biome) rather than spiralling
      // them and failing the whole search. Explicitly requested servers are kept
      // as-is so a user can still see the precise missing-command error.
      const skippedUnavailable: string[] = []
      if (!p.server) {
        targets = targets.filter((adapter) => {
          if (!adapter.isDefault) return true
          if (commandExists(adapter.defaultCommand.command, root, commandPathValue(adapter.env))) return true
          skippedUnavailable.push(adapter.name)
          return false
        })
      }
      if (targets.length === 0) {
        throw new Error('No LSP server available for workspace symbol search.')
      }
      const parts: string[] = []
      const serverNames: string[] = []
      for (const adapter of targets) {
        const files = collectContextFiles(adapter, root, p.path)
        if (files.length === 0) continue
        const res = await runWorkspaceSymbolQuery(
          adapter,
          { root, query: p.query, files },
          timeoutMs,
          ctx.signal,
          STATUS_CTX,
          STATUS_KEY,
        )
        parts.push(textOf(res))
        serverNames.push(adapter.name)
      }
      const skippedNote =
        skippedUnavailable.length > 0
          ? `Skipped unavailable default LSP server(s): ${skippedUnavailable.join(', ')}.`
          : ''
      return [skippedNote, parts.join('\n\n---\n\n')].filter(Boolean).join('\n\n')
    },
  }
}

/** Standard text output contract for LSP tools (from toolkit.ts). */

// ── System prompt section ──────────────────────────────────────

const LSP_SECTION_TEXT = `## LSP tools

Inspect code through LSP servers (pyright / typescript-language-server) instead of guessing:
use these before answering questions about a symbol (what it does, where it is defined,
where it is used), and to check or fix files. After editing .ts/.js/.py, run lsp_diagnostics
and expect 0 new errors. Available LSP tools:

- lsp_diagnostics: Run LSP diagnostics on .ts/.js/.py — use after edits.
- lsp_fix: Apply source fixes or organize imports.
- lsp_toggle: Enable/disable an LSP server for this session.
- lsp_hover / lsp_definition / lsp_implementation / lsp_references / lsp_symbols /
  lsp_type_definition / lsp_document_highlight: symbol navigation.
- lsp_rename: symbol-aware rename across the project.
- lsp_workspace_symbol: workspace-wide symbol search.`

const LSP_SECTION_ORDER = 110

/** Build every LSP tool definition. */
/** Every LSP ToolDefinition. */
export function lspTools(): ToolDefinition[] {
  return [
    diagnosticsTool(),
    fixTool(),
    toggleTool(),
    ...navigationTools(),
    renameTool(),
    workspaceSymbolTool(),
  ]
}

/** The system-prompt section that teaches the LSP tools (registered centrally). */
export function lspSection(): { name: string; order: number; text: string } {
  return { name: 'engineering-services:lsp', order: LSP_SECTION_ORDER, text: LSP_SECTION_TEXT }
}
