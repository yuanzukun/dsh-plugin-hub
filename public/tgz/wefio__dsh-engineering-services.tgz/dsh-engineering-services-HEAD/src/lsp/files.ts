import { existsSync, readdirSync, realpathSync, statSync } from "node:fs";
import path from "node:path";
import process from "node:process";
import { pathToFileURL } from "node:url";
import type { LspServerAdapter } from "./types.js";

export function resolveRoot(root?: string) {
	const resolvedRoot = path.resolve(root?.trim() || process.cwd());
	if (!existsSync(resolvedRoot)) throw new Error(`Workspace root does not exist: ${resolvedRoot}`);
	if (!statSync(resolvedRoot).isDirectory()) {
		throw new Error(`Expected workspace root to be a directory: ${resolvedRoot}`);
	}
	return resolvedRoot;
}

export function directoryUri(directory: string) {
	return pathToFileURL(directory.endsWith(path.sep) ? directory : `${directory}${path.sep}`).href;
}

export function resolveSupportedFile(adapter: LspServerAdapter, root: string, filePath: string) {
	const resolvedPath = resolveWorkspacePath(root, filePath, "File path");
	if (!existsSync(resolvedPath))
		throw new Error(`${adapter.name} file does not exist: ${resolvedPath}`);
	if (!isInsidePath(realpathSync(root), realpathSync(resolvedPath))) {
		throw new Error(`File resolves outside workspace root: ${resolvedPath}`);
	}
	if (!statSync(resolvedPath).isFile()) throw new Error(`Expected a file: ${resolvedPath}`);
	if (!adapter.isSupportedFile(resolvedPath)) {
		throw new Error(`Expected a ${adapter.name} supported file: ${resolvedPath}`);
	}
	return resolvedPath;
}

export function collectSupportedFiles(
	adapter: LspServerAdapter,
	root: string,
	requestedPaths: string[] | undefined,
	limit: number,
) {
	const cappedLimit = Math.max(1, Math.floor(limit));
	const files: string[] = [];
	const seen = new Set<string>();
	const visitedDirectories = new Set<string>();
	const realRoot = realpathSync(root);
	const inputs = requestedPaths?.length ? requestedPaths : [root];

	for (const input of inputs) {
		const targetPath = resolveWorkspacePath(root, input, "Requested path");
		if (!existsSync(targetPath)) throw new Error(`Requested path does not exist: ${targetPath}`);
		if (!isInsidePath(realRoot, realpathSync(targetPath))) {
			throw new Error(`Requested path resolves outside workspace root: ${targetPath}`);
		}
		collectPath(adapter, targetPath, files, seen, visitedDirectories, realRoot, cappedLimit);
		if (files.length >= cappedLimit) break;
	}

	return files;
}

/**
 * Conventional source-root directory names tried in order across languages
 * (TS/Rust/Go: src, Python: src or lib, JS: src or app, monorepos: packages).
 */
const CONVENTIONAL_SOURCE_ROOTS = ["src", "lib", "app", "server", "client", "packages"];

/**
 * Collect a small, predictable set of context files to open before a
 * workspace/symbol query. Servers differ in how they answer workspace symbols
 * (tsserver's navto only searches the loaded program of the project containing
 * an opened file; pyright indexes its detected workspace on its own), so opening
 * a handful of related files gives a clean, fast, bounded scope that works for
 * any language:
 *  1. the requested path (if any) plus spread samples of its sibling files;
 *  2. otherwise spread samples from the first conventional source root found;
 *  3. otherwise spread samples of any supported files under the root.
 */
export function collectContextFiles(
	adapter: LspServerAdapter,
	root: string,
	requestedPath: string | undefined,
	cap = 5,
) {
	const out: string[] = [];
	const spreadInto = (list: string[]) => {
		if (list.length === 0) return;
		const stride = Math.max(1, Math.floor(list.length / Math.max(1, cap - out.length)));
		for (let i = 0; i < list.length && out.length < cap; i += stride) {
			const f = list[i];
			if (!out.includes(f)) out.push(f);
		}
	};
	if (requestedPath) {
		try {
			const anchor = resolveSupportedFile(adapter, root, requestedPath);
			out.push(anchor);
			spreadInto(collectSupportedFiles(adapter, path.dirname(anchor), undefined, cap * 4));
		} catch {
			// fall through to discovery
		}
	}
	if (out.length < cap) {
		for (const dir of CONVENTIONAL_SOURCE_ROOTS) {
			if (out.length >= cap) break;
			const candidate = path.join(root, dir);
			if (!existsSync(candidate) || !statSync(candidate).isDirectory()) continue;
			spreadInto(collectSupportedFiles(adapter, candidate, undefined, cap * 6));
		}
	}
	if (out.length < cap) {
		spreadInto(collectSupportedFiles(adapter, root, undefined, cap * 20));
	}
	return out;
}

function collectPath(
	adapter: LspServerAdapter,
	targetPath: string,
	files: string[],
	seen: Set<string>,
	visitedDirectories: Set<string>,
	realRoot: string,
	limit: number,
) {
	if (files.length >= limit || !existsSync(targetPath)) return;
	if (!isInsidePath(realRoot, realpathSync(targetPath))) return;

	const stats = statSync(targetPath);
	if (stats.isFile()) {
		if (adapter.isSupportedFile(targetPath) && !seen.has(targetPath)) {
			seen.add(targetPath);
			files.push(targetPath);
		}
		return;
	}

	if (!stats.isDirectory()) return;
	const directoryKey = realpathSync(targetPath);
	if (visitedDirectories.has(directoryKey)) return;
	visitedDirectories.add(directoryKey);

	const entries = readdirSync(targetPath, { withFileTypes: true }).sort((left, right) =>
		left.name.localeCompare(right.name),
	);
	for (const entry of entries) {
		if (files.length >= limit) break;
		if ((entry.isDirectory() || entry.isSymbolicLink()) && adapter.skipDirectories.has(entry.name))
			continue;
		collectPath(
			adapter,
			path.join(targetPath, entry.name),
			files,
			seen,
			visitedDirectories,
			realRoot,
			limit,
		);
	}
}

function resolveWorkspacePath(root: string, inputPath: string, label: string) {
	const resolvedPath = path.resolve(root, inputPath);
	const realRoot = realpathSync(root);
	const isLexicallyInsideRoot = isInsidePath(root, resolvedPath);

	if (existsSync(resolvedPath)) {
		const realResolvedPath = realpathSync(resolvedPath);
		if (!isInsidePath(realRoot, realResolvedPath)) {
			throw new Error(`${label} resolves outside workspace root: ${resolvedPath}`);
		}
		return isLexicallyInsideRoot
			? resolvedPath
			: path.join(root, path.relative(realRoot, realResolvedPath));
	}

	if (!isLexicallyInsideRoot && !isInsidePath(realRoot, resolvedPath)) {
		throw new Error(`${label} escapes workspace root: ${resolvedPath}`);
	}
	return resolvedPath;
}

function isInsidePath(parent: string, child: string) {
	const relativePath = path.relative(parent, child);
	return relativePath === "" || (!relativePath.startsWith("..") && !path.isAbsolute(relativePath));
}
