---
name: ide-three-pillars
description: Use the three IDE-pillar tool sets provided by the dsh-engineering-services plugin — LSP (lsp_diagnostics / navigation / rename), DAP (debug: launch/attach/breakpoints/step/evaluate), Task (task: build/test/lint discovery & structured run). 用 LSP 查代码/改后收尾、用 debug 调运行中程序、用 task 跑构建/测试/lint 时触发。触发词：LSP、诊断、hover、定义/引用/改名、debug/调试/断点、task/构建/测试/工具链。
---

# IDE 三大件使用指南（LSP / DAP / Task）

本套件作为 DSH host plugin（`dsh-engineering-services`）提供三个 IDE 级工具组。本 skill 讲**什么时候用什么、怎么用、有哪些坑**；插件的 system-prompt 段只保证「工具存在并会被用」，细节在这里。

## 快速选择

| 想干嘛 | 用哪个 | 工具 |
|---|---|---|
| 改完代码查类型/回归错误 | LSP | `lsp_diagnostics` |
| 看符号定义/引用/调用实现 | LSP | `lsp_definition` / `lsp_references` / `lsp_implementation` / `lsp_hover` |
| 列文件符号 / 全工作区搜符号 | LSP | `lsp_symbols` / `lsp_workspace_symbol` |
| 符号感知改名 | LSP | `lsp_rename`（先 preview，确认后 write:true） |
| 查类型定义 / 高亮同符号 | LSP | `lsp_type_definition` / `lsp_document_highlight` |
| 关掉某语言 LSP | LSP | `lsp_toggle` |
| 调试运行中的程序（断点/步进/变量） | DAP | `debug`（action: launch/attach/…） |
| 跑构建/测试/lint/格式化 | Task | `task list` → `task run name=...` |
| 跑任意命令且要结构化返回 | Task | `task run command="..."` |

## LSP（语言服务）

- **当用**：改完 `.ts/.js/.py` 后查回归（`lsp_diagnostics` 应 0 新增错误）；理解/导航代码。
- **实测范围**：pyright（Python）与 typescript-language-server（TS/JS）。可通过 `<工作区>/.dsh/pi-lsp.json` 或 `~/.dsh/pi-lsp.json` 配置更多服务器（schema 与 pi 版一致）。
- **诚实边界**：LSP 抓**类型/回归错误**和导航，**不是逻辑 bug 探测器**（运行时/数据流 bug 抓不到）。找逻辑 bug 靠直驱真实代码。
- 工具描述由插件注入到提示中；`lsp_toggle` 把失配服务器移出诊断/修复集合。

## DAP（调试，debug 工具）

- **launch 流程**：`debug` action=launch(program, cwd) → action=set_breakpoint → action=continue → action=stack_trace/scopes/variables/evaluate → action=terminate。
- **debugpy attach**：target 需 `python -m debugpy --listen 127.0.0.1:<port> --wait-for-client script.py` 预启动；然后 `debug` action=attach(adapter=debugpy, port) → **先设断点再 continue**（断点必须在 configurationDone 前设好，否则不命中）。
- **关键坑**：
  - **debug 工具不排他，action 必须串行**（一次一个，等返回再发下一个）。
  - **Python 用「装有 debugpy 的解释器」**：debugpy 走 `DSH_DEBUGPY_PYTHON` 指定的解释器（默认 `${env:DSH_DEBUGPY_PYTHON|python3.13}`）。**别照抄「Python 用 3.13」的旧结论**——不同机器差异很大：本机实测 `python`(3.14) 装有 debugpy 1.8.21、`python3.13` 反而没有。以你机器上 `python -c "import debugpy"` 谁成功为准；成功那个设进 `DSH_DEBUGPY_PYTHON`。
  - **js-debug 测常驻脚本**（setInterval/长循环），快脚本断点会 unbound。

## Task（工具链，task 工具）

- **发现**：`task` action=list（package.json scripts / Makefile targets / justfile recipes）；`source=make` 过滤。
- **跑**：`task` action=run name=build（同名用 `source` 消歧）；`command="..."` = exec 模式。
- 工具 cwd 缺省为「当前会话的工作区」；可传 `cwd` 覆盖。

## 详细文档

- 插件仓库 `src/lsp/` — LSP（12 工具 + 配置加载）
- `src/dap/` — DAP（debug 工具 28 action；js-debug 内置、debugpy 需按说明装）
- `src/task/` — Task（发现 + 结构化运行）
