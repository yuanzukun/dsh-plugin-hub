# DETAILED.md — dsh-engineering-services migration map

> Concise overview: [README.md](./README.md). This file maps the pi edition
> (`pi-engineering-services`) to this DSH port, file by file, and records what
> changed and why.

## 1. Why a new port, not a drop-in

`pi-engineering-services` was written against pi's extension API:
`defineTool` + `ExtensionAPI.registerTool`, `ctx.cwd` / `ctx.isProjectTrusted()`,
`ctx.ui`, `pi.on("before_agent_start")` (system-prompt injection),
`pi.registerCommand` (the `/lsp` command), and per-conversation active-tool toggles.
DSH host plugins are cordis plugins: `apply(ctx)` + `ctx.tools.register(ToolDefinition)`,
with the session cwd on `exec.agent.session.header.cwd` and system-prompt sections via
`ctx.systemPrompt.section`.

The migration keeps the **heavy machinery host-agnostic** and rewrites only the thin
wire-up files. Auditing showed the three pillars' cores (`lsp-client`, `session`,
`client`, `config`, `discovery`, `runner`) import **nothing** from pi — they are pure
Node ESM. Only the entrypoints (`pi-lsp.ts`, `dap.ts`, `task.ts`) and two small helpers
(`adapters.ts` for LSP config dirs; the `ctx.ui.setStatus` status banner) are pi-coupled.

## 2. File-by-file map

### LSP

| pi source | DSH destination | Change |
|---|---|---|
| `lsp/src/lsp-client.ts` | `src/lsp/lsp-client.ts` | unchanged |
| `lsp/src/text-edits.ts` | `src/lsp/text-edits.ts` | unchanged |
| `lsp/src/files.ts` | `src/lsp/files.ts` | unchanged |
| `lsp/src/command.ts` | `src/lsp/command.ts` | **changed**: Windows command-name resolution now tries `.exe → .cmd → .bat → bare` (bare last) so an extension-less Unix shim can't shadow the real `.cmd`/`.exe` (fixes `spawn ENOENT`) |
| `lsp/src/routes.ts` | `src/lsp/routes.ts` | unchanged |
| `lsp/src/types.ts` | `src/lsp/types.ts` | unchanged |
| `lsp/src/runner.ts` | `src/lsp/runner.ts` | unchanged (uses a `StatusContext` that is now a no-op in DSH) |
| `lsp/src/adapters.ts` | `src/lsp/adapters.ts` | **de-coupled**: replaced pi `CONFIG_DIR_NAME`/`getAgentDir()` with `.dsh` + `~/.dsh`; config filename stays `pi-lsp.json` for drop-in parity. **Also** added `pyright` + `typescript-language-server` to the built-in `DEFAULT_SERVER_CONFIGS` (out-of-box TS/JS/Python coverage) |
| `lsp/src/pi-lsp.ts` | `src/lsp/dsh-lsp.ts` | **rewritten**: 12 `ToolDefinition`s via `ctx.tools.register`; TypeBox → JSON Schema; string outputs; no `/lsp` command / no `ctx.ui`. **Later**: workspace-symbol path now skips uninstalled default servers (matching diagnostics) so an uninstalled `biome` can't abort a symbol search |

### DAP

| pi source | DSH destination | Change |
|---|---|---|
| `dap/extensions/session.ts` | `src/dap/session.ts` | unchanged |
| `dap/extensions/client.ts` | `src/dap/client.ts` | unchanged |
| `dap/extensions/config.ts` | `src/dap/config.ts` | unchanged |
| `dap/extensions/types.ts` | `src/dap/types.ts` | unchanged |
| `dap/extensions/utils.ts` | `src/dap/utils.ts` | unchanged |
| `dap/extensions/non-interactive-env.ts` | `src/dap/non-interactive-env.ts` | unchanged |
| `dap/extensions/defaults.json` | `src/dap/defaults.json` | js-debug path → `./js-debug/...` (layout change); `PI_DEBUGPY_PYTHON` → `DSH_DEBUGPY_PYTHON` |
| `dap/js-debug/` | `src/dap/js-debug/` | vendored as-is (own `{"type":"commonjs"}`) |
| `dap/debugpy/` | `src/dap/debugpy/` | vendored as-is |
| `dap/extensions/dap.ts` | `src/dap/dap.ts` | **rewritten**: `debug` `ToolDefinition`; `ctx.cwd` → session cwd; `signal` → `exec.signal` + timeout; no `pi.on("session_shutdown")` (manager self-cleans via idle timer) |

### Task

| pi source | DSH destination | Change |
|---|---|---|
| `task/extensions/discovery.ts` | `src/task/discovery.ts` | unchanged |
| `task/extensions/runner.ts` | `src/task/runner.ts` | unchanged |
| `task/extensions/non-interactive-env.ts` | `src/task/non-interactive-env.ts` | unchanged |
| `task/extensions/task.ts` | `src/task/task.ts` | **rewritten**: `task` `ToolDefinition`; `ctx.cwd` → session cwd |

### Skill / docs

- `skills/ide-three-pillars/SKILL.md` — usage skill, ported to DSH naming (`dsh`, `DSH_DEBUGPY_PYTHON`, session-cwd).
- `skills/ide-runbook/SKILL.md` — operations runbook (install / activate / smoke incl. **self-bootstrap** / troubleshoot); added after live-host verification so the real tsserver/debugpy/Windows pitfalls are recorded.
- `docs/MAINTENANCE-NOTES.md` — **upstream pi-era vendor note** for the vendored `@piex-dev/dap` (child-session / TCP / ECONNRESET / direct-TCP attach design record). It uses pi names (`vendor/dap/`, `PI_DEBUGPY_PYTHON`) and **is kept as-is** — not authoritative for DSH behavior (see the runbook for the real `DSH_DEBUGPY_PYTHON`/tsserver pitfalls). Not shipped in the published package (`package.json` `files` excludes `docs/`).
- `docs/THIRD-PARTY-NOTICES.md` — upstream sources & licenses.

## 3. Wire-up layer: pi → DSH

| pi concept | DSH equivalent |
|---|---|
| `defineTool({...})` + `pi.registerTool` | plain `ToolDefinition` + `ctx.tools.register` |
| `execute(toolCallId, params, signal, onUpdate, ctx)` | `execute(args, exec)` |
| `ctx.cwd` | `exec.agent.session.header.cwd` (via `cwdOrProcess(exec)`) |
| `ctx.isProjectTrusted()` | treated as trusted (language servers are the plugin's purpose); gated by sandbox policy at the host |
| TypeBox `Type.Object(...)` | JSON Schema `Record<string, unknown>` |
| return `{ content: [{type:'text',text}], details }` | return a plain string; `output.schema={type:'string'}`, `render` → text block |
| `ctx.ui.setStatus` | no-op `StatusContext` |
| `pi.on("before_agent_start")` LSP catalog | `ctx.systemPrompt.section(...)` |
| `pi.registerCommand("lsp")` | dropped; replaced by `lsp_toggle` |
| `pi.on("session_shutdown")` | not needed — DAP manager self-cleans (idle + cleanup timers) |

## 4. Registered tools

- `lsp_diagnostics`, `lsp_fix`, `lsp_toggle`, `lsp_hover`, `lsp_definition`,
  `lsp_implementation`, `lsp_references`, `lsp_symbols`, `lsp_type_definition`,
  `lsp_document_highlight`, `lsp_rename`, `lsp_workspace_symbol`
- `debug` (DAP, action-dispatched)
- `task` (list / run)

## 5. Verification

- `npm run check` runs `tsc --noEmit -p tsconfig.json` — **passes clean (exit 0)**.
- Live-host (2026-08-14): mounted into the **web** profile (`dsh.profile.bundles` +
  `@local/dsh-engineering-services`), all 14 tools present, and smoke-suite run against real
  runtimes (see §6 and the runbook skill).
- Package layout mirrors `dsh-genui`: `package.json` `dsh.bundle` + `cordis.patch.yml`,
  node-half `src/index.ts` `apply(ctx)`.
- `node_modules/@deepseek-ai/*` are junctions to an installed `@deepseek-ai/dsh` profile
  for offline typechecking (dev-only, gitignored).

## 6. Known limits of this port

- **Live-host verification (2026-08-14)**: the plugin **has** been mounted into a real
  `dsh web` profile and its tools run end-to-end against real runtimes — pyright
  diagnostics/symbols, tsserver symbols (needs a workspace-resolvable `typescript@5`),
  `task list`/`run`, and `debug` (js-debug + debugpy). See the runbook skill for the
  exact smoke steps and the pitfalls (Windows `.cmd` spawn, TS7 `tsserver.js` gap, and
  debugpy interpreter selection).
- **js-debug path**: `defaults.json` uses `./js-debug/...` relative to `src/dap/`;
  if you relocate the vendored tree, adjust that entry.
- **No slash command**: the `/lsp` UX is replaced by `lsp_toggle`. Whole-tool-set toggling
  is not exposed because DSH host plugins have no per-conversation active-tool-set API.
- **Windows spawn ordering**: `src/lsp/command.ts` resolves commands by trying
  `.exe` → `.cmd` → `.bat` → bare (bare last). On Windows, npm installs an extension-less
  Unix shim for some tools (e.g. `typescript-language-server`); bare-first resolution used
  to pick that unspawnable shim → `ENOENT`. This ordering is the fix.
- **Default server selection**: `src/lsp/dsh-lsp.ts` skips default LSP servers whose
  command isn't installed (diagnostics **and** workspace-symbol paths), so an uninstalled
  `biome` no longer aborts a symbol search — pyright/tsserver carry the result.
