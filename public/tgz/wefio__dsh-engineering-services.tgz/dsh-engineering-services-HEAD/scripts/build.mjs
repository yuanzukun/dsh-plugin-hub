/**
 * Build the dsh-engineering-services plugin.
 *
 * 1. Emit the TS sources to `lib/` with tsc (tsconfig.build.json).
 * 2. Copy the vendored runtime assets (js-debug, debugpy) into `lib/dap/`,
 *    to match defaults.json's `./js-debug/...` / `./debugpy/...` env paths,
 *    which resolve relative to the emitted config.js.
 */
import { cp, rm } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const LIB = join(ROOT, 'lib')

/**
 * Run tsc without a shell `spawn` concat warning. On Windows drive the `.cmd`
 * shim through cmd.exe; elsewhere spawn `tsc` directly.
 */
function spawnTsc(args) {
  if (process.platform === 'win32') {
    return spawnSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', 'tsc.cmd', ...args], {
      cwd: ROOT,
      stdio: 'inherit',
    })
  }
  return spawnSync('tsc', args, { cwd: ROOT, stdio: 'inherit' })
}

await rm(LIB, { recursive: true, force: true })

const tsc = spawnTsc(['-p', join(ROOT, 'tsconfig.build.json')])
if (tsc.status !== 0) process.exit(tsc.status ?? 1)

// Static vendored DAP assets live under src/dap; copy them beside the emitted
// lib/dap/*.js so defaults.json's package-relative paths resolve at runtime.
await cp(join(ROOT, 'src', 'dap', 'js-debug'), join(LIB, 'dap', 'js-debug'), { recursive: true })
await cp(join(ROOT, 'src', 'dap', 'debugpy'), join(LIB, 'dap', 'debugpy'), { recursive: true })

console.log('build ok → ' + LIB)
