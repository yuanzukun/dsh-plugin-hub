# Third-Party Notices

`pi-engineering-services` is MIT licensed, but it contains code and assets derived from
the following upstream projects. Their license notices are preserved alongside the
code and reproduced here.

## @narumitw/pi-lsp (forked → `lsp/`)

- Source: https://www.npmjs.com/package/@narumitw/pi-lsp
- License: MIT — see `lsp/LICENSE`
- Copyright (c) 2026 narumiruna
- Notes: local fork, heavily modified (12 tools, config additions).

## @piex-dev/dap (forked → `dap/`)

- Source: https://www.npmjs.com/package/@piex-dev/dap (v0.1.1)
- License: MIT
- Notes: local fork, extended for debugpy/js-debug/attach support. The upstream
  MIT notice was not shipped with the fork; it is reproduced below:

```
MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## vscode-js-debug (vendored → `dap/js-debug/`)

- Source: https://github.com/microsoft/vscode-js-debug (v1.117.0)
- License: MIT — see `dap/js-debug/LICENSE`
- Copyright (c) Microsoft Corporation. All rights reserved.
- Notes: vendored because it is not published to npm (unlike debugpy, which is
  a pip package). It is a CommonJS runtime guarded by `{"type":"commonjs"}` in
  its own `package.json`.

## vscode-workspace-tasks (reference for `task/` discovery)

- Source: https://github.com/microsoft/vscode (task discovery logic)
- License: MIT
- Copyright (c) Microsoft Corporation. All rights reserved.
- Notes: task/extension discovery is modeled on the VSCode workspace-tasks
  discovery logic; this is a reference implementation, not a copy of VSCode
  source.

## debugpy (external dependency, NOT vendored)

- Source: https://github.com/microsoft/debugpy
- License: MIT
- Notes: not vendored — the plugin ships only config, a version pin, and a health-check
  script. Install it into the interpreter used for debugging: `pip install debugpy` into the
  Python chosen via `DSH_DEBUGPY_PYTHON` (no hard 3.13 requirement; use any interpreter where
  `python -c "import debugpy"` succeeds).
