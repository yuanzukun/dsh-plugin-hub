# @piex-dev/dap 维护笔记（本地复刻版）

> 本目录是 `@piex-dev/dap` v0.1.1 的 vendor 本地复刻（settings.json `packages` 里注册为 `vendor\dap`，`pi update` 不碰）。
> 基于 `@piex-dev/dap` 改造以支持 **debugpy (Python) + js-debug (Node)** 双调试器，并修复了若干会导致崩溃/失效的问题。
> 记录日期：2026-08-08。本文档面向后续维护者。

---

## 1. 目录结构

```
vendor/dap/
  extensions/
    dap.ts               # 扩展入口，注册单一 debug 工具（28 个 action）
    client.ts            # DAP 客户端（stdio + 我们加的 tcp 传输）
    session.ts           # 会话管理器（我们加了子会话支持）
    config.ts            # 适配器解析/选择
    defaults.json        # 内置适配器定义（我们改过 debugpy / js-debug-adapter）
    types.ts / utils.ts / non-interactive-env.ts
  node_modules -> NodeMemoryGraph/node_modules   # junction（供 LSP 检查，勿删）
  package.json / README.md / LICENSE
```

js-debug 本体（独立 DAP server）在 dap 包内部（2026-08-08 从 vendor/js-debug-dap 合并进来）：
```
vendor/dap/js-debug/src/dapDebugServer.js   # vscode-js-debug v1.117.0 的 dapDebugServer.js（~800K，TCP server）
vendor/dap/js-debug/src/chromehash_bg.wasm  # 运行时的 wasm 依赖（dapDebugServer 非自包含，需同包文件）
```
> 结构：`vendor/dap/extensions/` = 我们的扩展代码；`vendor/dap/js-debug/` = 上游运行时（60 文件，完整 vscode-js-debug release）。分开维护、分别升级。
>
> **⚠️ type 陷阱**：`vendor/dap/package.json` 是 `"type": "module"`，Node 按最近 package.json 的 type 决定 .js 模块类型。合并后 dapDebugServer.js 的最近 package.json 变成 dap 的 type:module → 被当 ESM 加载 → `Dynamic require of "fs" is not supported` 崩溃（js-debug 是 CJS）。
> **修复**：`vendor/dap/js-debug/package.json` 必须是 `{"type": "commonjs"}`（已加）。换 js-debug 版本时保留这个 package.json。

---

## 2. 相对原包的改动清单

### client.ts —— 新增 TCP 传输 + socket-only 子会话
- `connectMode === "tcp"` 分支：`reservePort()` 预留本地端口 → `args` 里 `${port}` 替换 → spawn 适配器 → `connectWithRetry()` 等监听后连 socket。
- `DapClient.connect({ adapter, cwd, host, port })`：纯 socket 客户端（无子进程），用于 startDebugging 子会话。
- `#proc` 改为可选；`get port()` 暴露适配器 TCP 端口。
- **崩溃修复**：`#startMessageReader` 给消息流挂 `stream.on("error")` / socket `on("close")` → `#handleTransportError` / `#handleTransportClose`（拒绝 pending、标记 disposed）。没有这个，terminate 时 `ECONNRESET` 会变 uncaughtException 把整个 pi 崩掉。

### session.ts —— 子会话（startDebugging）支持
- `DapSession` 加 `parentSessionId` / `childSessionIds`。
- `#register` 里把 startDebugging 反向请求从**空壳 stub** 换成真实处理 → `#startChildSession`。
- `#startChildSession`：要求 `parent.client.port`（tcp）→ `DapClient.connect` 连同一端口 → 注册子会话 → initialize → 转发 launch/attach → `#applyRootBreakpointsToChild` 同步断点 → `#configDone`。
- `stopped` 事件切 `#activeSessionId` 到子会话（这样 stack/scopes/evaluate 作用在真正跑脚本的子会话上）。
- `#terminateTree` 递归终止 + `#dispose` 递归清理 + 从父会话 childSessionIds 摘除。
- **没有子会话支持时 js-debug 的 threads 永远空**（js-debug 靠 startDebugging 把真实脚本目标挂成子会话）。

### types.ts / config.ts
- `connectMode` 类型加 `"tcp"`（原本只有 `stdio | socket`）。

### defaults.json —— 两个适配器实测可用配置
```jsonc
"debugpy": {
  "command": "${env:PI_DEBUGPY_PYTHON|python3.13}",   // 不能用默认 python(3.14)！见 §3.1
  "args": ["-m", "debugpy.adapter"],
  "launchDefaults": {
    "request": "launch", "justMyCode": false, "stopOnEntry": true,
    "pythonArgs": ["-X", "frozen_modules=off"]   // 消 frozen-modules 警告
  }
},
"js-debug-adapter": {
  "command": "node",
  "args": ["<pkg>/dap/js-debug/src/dapDebugServer.js", "${port}", "127.0.0.1"],   // 相对包根，resolveAdapter 按 config 目录解析
  "connectMode": "tcp",                          // 必须 tcp；第三参 127.0.0.1 必须传（见 §3.3）
  "launchDefaults": { "request": "launch", "type": "pwa-node", "stopOnEntry": true }
}
```

---

## 3. 踩过的坑（根因都在这里）

### 3.1 debugpy 1.8.21 与 Python 3.14 深度不兼容
- 症状：launch 带 `stopOnEntry: true` 也**不发 stopped 事件**，程序直接跑完，之后设断点全错过。
- 加 `pythonArgs -Xfrozen_modules=off` 无效 → 根因不是 frozen modules，是 [debugpy #1893 "Python 3.14 and above broke the debug extension"]（修复在 next release，PyPI 上 1.8.21 已是最新）。
- 默认 `python`(3.14) 坏；用 Python 3.13 解释器正常。
- **结论：debugpy command 用 `${env:PI_DEBUGPY_PYTHON|python3.13}` 指向 Python 3.13**（设 `PI_DEBUGPY_PYTHON` 或 PATH 有 `python3.13`）。若日后 debugpy 出 3.14 兼容版，改回 `python` 即可。

### 3.2 js-debug 不在 npm，且 marketplace latest 是旧版
- `vscode-js-debug` / `js-debug-adapter` / `@vscode/js-debug` 在 npm 全是 404。
- VS Code marketplace 的 `latest` 会返回 **2022.8 旧版**（没有 `dapDebugServer.js`，不可用）。
- **正确获取**：GitHub release 资产 `js-debug-dap-v<ver>.tar.gz`（内含 `js-debug/src/dapDebugServer.js`）：
  `https://github.com/microsoft/vscode-js-debug/releases/download/v1.117.0/js-debug-dap-v1.117.0.tar.gz`

### 3.3 dapDebugServer.js 默认监听 IPv6 `::1`
- 默认 `node dapDebugServer.js <port>` 只监听 `::1`；client 连 `127.0.0.1` 会超时。
- **必须传第二个参数**：`node dapDebugServer.js <port> 127.0.0.1`。

### 3.4 js-debug 必须走 startDebugging 子会话
- js-debug 启动脚本目标时向客户端发 `startDebugging` 反向请求（带 `__pendingTargetId`）。
- 原包 handler 是空壳（只 log "not supported"）→ 子会话不建 → **threads 永远空、断点 unbound**。
- 已实现真实子会话（见 §2）。这也是为什么需要 TCP + `DapClient.connect`。

### 3.5 ECONNRESET 崩溃（重要，会崩整个 pi）
- 症状：真实会话 terminate js-debug 时 pi 直接退出，报 `uncaughtException: read ECONNRESET @ TCP.onStreamRead`。
- 根因：TCP socket 无 `error` 监听器（`connectWithRetry` 里 `removeAllListeners("error")` 清掉了重试监听，之后没人管 socket error）→ Node 默认把无监听的 `error` 事件抛成 uncaughtException。
- Node 官方：ECONNRESET 崩溃根因就是缺 error 监听器；正确做法是**在 socket 上挂 error handler**（`process.on('uncaughtException')` 被官方不建议）。
- 已修（见 §2 client.ts）。

### 3.6 debug 工具不排他，agent 必须串行调用
- 原包没有并发互斥。并行发多个 debug action（如 `variables` + `terminate`）会竞态，3.5 的崩溃就是这么撞出来的。
- **使用约定：debug 工具一次只发一个 action，等返回再发下一个。**

### 3.7 快脚本断点竞态
- `stopOnEntry` 对 debugpy 有效（launch 后停在入口，再设断点来得及）。
- 对 js-debug 子会话基本无效：launch 后脚本立刻跑，毫秒级脚本会先跑完 → 断点 unbound。
- **测试 js-debug 用常驻脚本**（setInterval / 长循环），断点设在其循环体内。

### 3.8 debugpy attach：走 direct-TCP，不走 adapter 进程（重点）
- **架构**：`python -m debugpy --listen <port>` 时 **target 自己会 spawn 一个 adapter**（`--for-server <endpoints_port>`），target 的 debug server 连到自己 spawn 的 adapter 的内联端口。
- **所以 attach 绝不能**再 spawn 一个 adapter 进程发 attach —— 两个 adapter 互相不知道对方，`servers.wait_for_connection` 永远等不到 server 连接 → attach 超时（这正是 Zed/nvim-dap 踩的坑）。
- **正确姿势（wiki `DebugAdapterServer(port, host)`）**：客户端**直接 TCP 连 target 的 `--listen` 端口**（该端口就是 DAP 端点，`initialize` 秒回），attach 用嵌套 `connect: {host, port}`（不能同时带扁平 `host`/`port`，debugpy 会报 mutually exclusive）。
- **实现**：debugpy 在 defaults.json 配 `directAttach: true` → session.ts `attach()` 走 `DapClient.connect`（直连 socket），attach 参数用 `connect`。
- **三个 debugpy 直连 attach 的关键行为（都验证过）**：
  1. **attach 响应要等 configurationDone 之后才返回** —— attach() 不能 `await attachP`，要用 `initialized` 事件当“已 attach”信号（它在 attach 请求后秒回）。
  2. **断点必须在 configurationDone 之前设好**，否则 release 后设的断点永远不命中（`--wait-for-client` 冻结在入口，configDone 一释放就跑起来了）。所以 directAttach 会话设 `deferConfigDone`：attach() 不发 configDone（状态停留 `configuring`），`#req` 对这类会话跳过自动 configDone（避免 set_breakpoint 误 release），首次 `continue`/`step` 走 `#ensureReleased` 才发 configDone。
  3. **configDone 后不要立即发 `continue` 请求** —— debugpy 启动过渡期会不回 continue 响应（竞态）。首次 continue 对 defer 会话就是“release + 等断点 stopped”，不额外发 DAP continue。
- **target 端要求**：`python -m debugpy --listen 127.0.0.1:<port> --wait-for-client script.py`（`--wait-for-client` 让 debuggee 冻结等 attach）。attach 后用户先设断点、再 continue。

---

## 4. 验证记录

### bun 直驱 DapSessionManager（回归基线）
- debugpy(Python 3.13)：launch→entry 停→断点 compute→continue 停→frames `compute@4|main@12`→vars `a=10,b=20`→evaluate `a+b=30`→output `result=60`→terminate。
- js-debug：launch→断点→continue 停→frames `global.compute@slow.js:2`→vars `a=1,b=2`→evaluate `a+b=3`→terminate（**无崩溃**）。

### debugpy direct-TCP attach（2026-08-08 新增实现后）
- target `python -m debugpy --listen <port> --wait-for-client slow.py`；`mgr.attach({adapter, cwd, port})` → `configuring`（冻结，未 release）；`set_breakpoint` L5 verified（不 release）；`continue` → `stopped stop=breakpoint line=5 frame=loop`；`evaluate n`；`step_over`；`pause`；`terminate` 全通。
- 三种顺序原始 probe 对照：attach→setBP→configDone→continue ✅；attach→configDone→setBP→continue ✗（断点不命中）；configDone 后立即 continue ✗（continue 请求无响应）—— 两个坑分别用 deferConfigDone + 首 continue 不额外发请求解决。
- 改动后回归：debugpy launch（entry→bp→step_in/out/over→remove_bp→terminate）+ js-debug launch（launch→pause→bp→continue→evaluate→step_over→remove_bp→terminate）全绿，非 directAttach 流程零影响。

### 真实 pi 会话（reload 后）
- debugpy：launch→entry→断点 L2→停 compute:2→evaluate `a+b=30`→terminate exit 0。
- js-debug：launch→断点 L7→停 slow.js:7→stack→evaluate `n=1`→terminate（**不再崩**）→再 terminate 返回 "No debug session to terminate"。
- 错误路径：debugpy 误 launch `.js` → exit 1 → 干净 terminate，不崩。

---

## 4.5 DAP 自指调试（debugging the debugger，2026-08-08 验证可行）

用 DAP 插件调试 DAP 插件自己的源码，全链路验证过：attach→断点 session.ts→stack/scopes/variables/evaluate/step 全通。

**为什么不能直接 attach pi / bun**：
- 不能 attach 当前 pi 会话（重启会断会话）。
- `bun --inspect` 的 inspector 只绑 `[::1]`（IPv6）且**不提供 `/json/list`**（404），js-debug 标准 attach 靠 /json/list 发现 target → 连不上；js-debug 也不支持把原始 ws URL 塞进 `address`（vscode-js-debug #668）。

**可行配方（node 中转）**：
1. 写一个 bun entry import 扩展（`DapSessionManager` + `resolveAdapter`），先 `sleep(120000)` 留出 attach+断点窗口，再执行真实动作（如 launch debugpy）。
2. `bun build entry.mjs --target=node --sourcemap=inline --outfile=ext-bundle.mjs`（打包处理 extensionless import + `with {type:"json"}` + TS；sourcemap 把 bundle 行映射回原始 .ts）。
3. `node --inspect=9229 ext-bundle.mjs`（node 的 inspector 是标准实现：127.0.0.1 IPv4 + /json/list，js-debug 天生适配）。
4. `debug attach(adapter=js-debug-adapter, port=9229, host=127.0.0.1)` → running。
5. `debug set_breakpoint(file=.../extensions/session.ts, line=<launch 方法行>)` → verified（sourcemap 生效）。
6. 等 entry 计时器到点 → 断点在扩展自己的 launch() 命中（stack 显示 `DapSessionManager.launch@session.ts` ← entry.mjs）。
7. `scopes`（不传 frame_id 自动用栈顶帧真实 id）、`variables`（Local ref）、`evaluate`（如 `opts.adapter.name` → 'debugpy'）、`step_over`（176→177）全通。
8. terminate 收尾。

注：scopes/variables 必须用 DAP 返回的真实 frame id（stack_trace 顶帧），硬传 0 会报 "Stack frame not found"。

## 5. 升级 / 回退

- 升级 `@piex-dev/dap`：重新 `npm pack` → 解包替换 extensions/ → **重放 §2 的全部改动**（无补丁文件，改动是直接改源码的）。
- js-debug 升级：重新下对应版本 `js-debug-dap-*.tar.gz`，替换 `vendor/dap/js-debug`，同步改 defaults.json 的 dapDebugServer 路径。
- 回退：settings.json `packages` 去掉 `vendor\dap` 即可（不影响 LSP 扩展）。

---

## 6. 相关链接

- DAP 规范：https://microsoft.github.io/debug-adapter-protocol/specification.html
- debugpy 3.14 issue：https://github.com/microsoft/debugpy/issues/1893
- vscode-js-debug standalone DAP server（PR #1614，v1.77.0+）：https://github.com/microsoft/vscode-js-debug/pull/1614
- 上游 PieX：https://github.com/piex-dev/piex （`packages/dap`）
- oh-my-pi 的 DAP 实现（子会话参考）：https://github.com/can1357/oh-my-pi （`packages/coding-agent/src/dap/`）
