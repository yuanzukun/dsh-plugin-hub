/**
 * Offline smoke test for the Host half.
 *
 * Runs on plain Node (no Electron, no DSH): the Host half only uses `node:fs`,
 * `node:path` and the global `fetch`, so every branch below is exercised for
 * real. The one thing it cannot cover is the host wiring itself (events + route),
 * which is verified by loading the plugin in DSH.
 *
 *   node smoke-host.mjs
 */
import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { classify, extractTargets } from './detect.js'
import {
  LINGER_MS,
  beginTask,
  noteInstallLog,
  noteInstallPhase,
  snapshot,
  sweep,
} from './state.js'
import { clip, extractUrl, firstLine, lastLine, uniq, unquote } from './utils.js'
import {
  backgroundSnapshot,
  noteJobEvent,
  noteToolEnd,
  noteToolStart,
  resetBackground,
  setTitleLookup,
} from './background.js'

const ok = (message) => console.log('  ok ' + message)

/* ------------------------------------------------------------------ */
/* 1. string helpers                                                   */
/* ------------------------------------------------------------------ */

assert.equal(clip('  a   b  ', 20), 'a b')
assert.equal(clip('abcdef', 3), 'abc…')
assert.equal(clip(null), '')
assert.equal(firstLine('\n\n  one  \ntwo\n'), 'one')
assert.equal(lastLine('one\n\n  two  \n\n'), 'two')
assert.equal(lastLine(''), '')
assert.equal(extractUrl('curl -o a.bin https://x/y?z=1&w=2 done'), 'https://x/y?z=1&w=2')
assert.equal(extractUrl('no url here'), '')
assert.deepEqual(uniq([1, 2, 1, 3]), [1, 2, 3])
assert.equal(unquote('"a b"'), 'a b')
assert.equal(unquote("'a b'"), 'a b')
assert.equal(unquote('plain'), 'plain')
ok('utils: clip / lines / url / uniq / unquote')

/* ------------------------------------------------------------------ */
/* 2. classification                                                   */
/* ------------------------------------------------------------------ */

assert.deepEqual(classify({ name: 'web_search', arguments: { query: 'dsh plugin' } }), {
  kind: 'search',
  label: 'dsh plugin',
  detail: 'dsh plugin',
})
assert.equal(classify({ name: 'web_search', arguments: { question: 'q' } }).label, 'q')
assert.equal(classify({ name: 'research', arguments: { q: 'x' } }).kind, 'search')
assert.equal(classify({ name: 'web_fetch', arguments: { url: 'https://a/b' } }).kind, 'fetch')
assert.equal(
  classify({ name: 'plugin_manager', arguments: { action: 'install_bundle', target: 'pkg' } }).kind,
  'install',
)
// Listing plugins is not an install and must not raise a card.
assert.equal(classify({ name: 'plugin_manager', arguments: { action: 'list_plugins' } }), null)

const shell = (command) => classify({ name: 'pwsh', arguments: { command } })
assert.equal(shell('curl.exe -sS -o out.bin https://x/y').kind, 'download')
assert.equal(shell('wget -O out.bin https://x/y').kind, 'download')
assert.equal(shell('git clone https://github.com/a/b.git d:/repo').kind, 'download')
assert.equal(shell('pwsh -c "Invoke-WebRequest -Uri u -OutFile f"').kind, 'download')
// Invoke-WebRequest without -OutFile buffers in memory: nothing to sample.
assert.equal(shell('Invoke-WebRequest -Uri https://x/y'), null)
assert.equal(shell('iwr https://x/y'), null)
assert.equal(shell('pnpm add lodash').kind, 'pkg')
assert.equal(shell('npm i -g foo').kind, 'pkg')
assert.equal(shell('docker pull nginx').kind, 'pkg')
assert.equal(shell('ls -la'), null)
assert.equal(shell(''), null)
// The word `curl` is not a download. Every one of these used to raise a card
// that could never move, because the match was anchored on whitespace instead
// of on the start of a command.
assert.equal(shell('Get-Process curl -ErrorAction SilentlyContinue | Measure-Object'), null)
assert.equal(shell('# curl is not installed here\nWrite-Host hi'), null)
assert.equal(shell('Write-Host "use curl -o file url"'), null)
assert.equal(shell('git log --grep=clone'), null)
// Wrapped invocations still count: the quote boundary makes the inner command
// its own segment.
assert.equal(shell('pwsh -c "curl -o C:\\tmp\\c.bin https://x/c.bin"').kind, 'download')
assert.equal(shell('a && curl -o out.bin https://x/y').kind, 'download')
// A non-shell tool is never inspected for a command line.
assert.equal(classify({ name: 'read', arguments: { file_path: 'x' } }), null)
ok('detect: classify covers download / install / pkg / search / fetch / ignore')

/* ------------------------------------------------------------------ */
/* 3. target parsing                                                   */
/* ------------------------------------------------------------------ */

const CWD = 'D:\\work'
assert.deepEqual(extractTargets('curl -o "C:\\a b\\f.zip" https://x/f.zip', CWD), [
  'C:\\a b\\f.zip',
])
assert.deepEqual(extractTargets('curl --output out.bin https://x/y', CWD), [
  join('D:\\work', 'out.bin'),
])
assert.deepEqual(extractTargets('wget -q --output-document=o.bin https://x/y', CWD), [])
assert.deepEqual(extractTargets('Invoke-WebRequest -Uri u -OutFile .\\x.zip', CWD), [
  join('D:\\work', '.\\x.zip'),
].map((p) => p))
assert.deepEqual(extractTargets('curl -O https://host/dir/file.tgz', CWD), [
  join('D:\\work', 'file.tgz'),
])
assert.deepEqual(extractTargets('git clone https://github.com/a/b.git D:\\repo', CWD), [
  'D:\\repo',
])
// The same flag twice must not double-count the same file.
assert.equal(extractTargets('curl -o a.bin --output a.bin https://x/y', CWD).length, 1)
// A target built from a variable stays a literal we cannot resolve. This is a
// documented limitation, not a bug: guessing would put a confident bar on a file
// we are not actually watching.
assert.deepEqual(extractTargets('curl -o $dst https://x/y', CWD), [join('D:\\work', '$dst')])
// wget's `-O` names the output file; curl's `-O` names it after the URL. Reading
// them the same way pointed the card at a file the transfer never writes.
assert.deepEqual(extractTargets('wget -O out.bin https://x/y.bin', CWD), [
  join('D:\\work', 'out.bin'),
])
// `Start-Process -ArgumentList` hands the child an array, so `-o` and its value
// are separate comma-delimited items that the whitespace-anchored flags miss.
assert.deepEqual(
  extractTargets(
    "Start-Process -FilePath 'curl.exe' -ArgumentList '-L','-o','D:\\work\\p.bin','https://x/p.bin'",
    CWD,
  ),
  ['D:\\work\\p.bin'],
)
ok('detect: extractTargets handles quotes, cwd, -O, clone, dedupe, variables')

/* ------------------------------------------------------------------ */
/* 4. task lifecycle                                                   */
/* ------------------------------------------------------------------ */

const dir = mkdtempSync(join(tmpdir(), 'ddp-smoke-'))
const target = join(dir, 'payload.bin')

try {
  // Point the URL at a closed port so the HEAD probe fails fast and predictably.
  const task = beginTask(
    { callId: 'call-1', name: 'pwsh' },
    { kind: 'download', command: `curl -o "${target}" http://127.0.0.1:9/payload.bin` },
    dir,
  )
  assert.equal(task.kind, 'download')
  assert.deepEqual(task.targets, [target])
  assert.equal(task.label, 'payload.bin')
  assert.equal(task.log, 'http://127.0.0.1:9/payload.bin')

  const t0 = 1_000_000
  writeFileSync(target, Buffer.alloc(100))
  sweep(t0)
  let [snap] = snapshot()
  assert.equal(snap.bytes, 100, 'first sample reads the bytes already on disk')
  assert.equal(snap.total, null, 'a failed HEAD leaves total unknown')
  assert.equal(snap.unresolved, false)

  writeFileSync(target, Buffer.alloc(300))
  sweep(t0 + 1000)
  ;[snap] = snapshot()
  assert.equal(snap.bytes, 300)
  // 200 bytes over 1000 ms = 200 B/s, within rounding of the window.
  assert.ok(snap.speed > 150 && snap.speed < 250, 'speed ~200 B/s, got ' + snap.speed)

  // Tool returned, file stopped growing: stays visible for the linger window.
  task.done = true
  sweep(t0 + 2000)
  sweep(t0 + 3000)
  sweep(t0 + 4000)
  assert.equal(snapshot().length, 1, 'quiet ticks are counted, card still lingering')
  sweep(t0 + 4000 + LINGER_MS)
  assert.equal(snapshot().length, 0, 'card is retired after the linger window')

  // A download whose target could not be resolved reports `unresolved`, which the
  // client renders as an indeterminate bar.
  const blind = beginTask(
    { callId: 'call-2', name: 'pwsh' },
    { kind: 'download', command: 'curl -o $dst http://127.0.0.1:9/x' },
    'D:\\work',
  )
  blind.done = true
  ;[snap] = snapshot()
  assert.equal(snap.unresolved, false)
  const blind2 = beginTask(
    { callId: 'call-3', name: 'pwsh' },
    { kind: 'download', command: 'curl -O http://127.0.0.1:9/x', },
    'D:\\work',
  )
  // `-O` derives a name from the URL, so this one IS resolved; `unresolved` needs
  // a download with no target at all, which happens when parsing yields nothing.
  assert.equal(blind2.targets.length, 1)
  blind2.done = true

  // Install tasks are driven by host events, never by sampling.
  beginTask({ callId: 'call-inst', name: 'plugin_manager' }, { kind: 'install', label: 'pkg' }, '')
  assert.equal(snapshot().find((t) => t.id === 'call-inst').log, 'pnpm add pkg')
  noteInstallLog({ text: 'Progress: resolved 1\nProgress: resolved 128, downloaded 8' })
  assert.equal(
    snapshot().find((t) => t.id === 'call-inst').log,
    'Progress: resolved 128, downloaded 8',
  )
  noteInstallPhase({ phase: 'applying' })
  assert.equal(snapshot().find((t) => t.id === 'call-inst').phase, 'applying')
  ok('state: sample → speed window → linger → retire, plus install events')

  // Snapshot shape is the wire contract with the client. Every field the client
  // reads must be present for every kind.
  const shape = snapshot().find((t) => t.id === 'call-inst')
  for (const key of ['id', 'kind', 'label', 'bytes', 'total', 'speed', 'phase', 'log', 'elapsedMs', 'done', 'unresolved']) {
    assert.ok(key in shape, 'snapshot must expose ' + key)
  }
  ok('state: snapshot exposes the full wire contract')
} finally {
  rmSync(dir, { recursive: true, force: true })
}

/* ------------------------------------------------------------------ */
/* 5. a rejected HEAD must not become the file size                    */
/* ------------------------------------------------------------------ */
// Cloudflare (and plenty of other CDNs) answer HEAD with 403 and a one-byte
// error body. Reading `content-length` without looking at the status made the
// card render "0 B / 1 B" as if the download were one byte long. Only a 2xx
// response describes the resource being downloaded.
const server = createServer((req, res) => {
  res.writeHead(403, { 'content-type': 'text/plain', 'content-length': '1' })
  res.end('x')
})
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
const port = server.address().port
// The section above deletes its own temp directory, so this one needs its own.
const headDir = mkdtempSync(join(tmpdir(), 'ddp-head-'))

try {
  const probed = beginTask(
    { callId: 'call-head', name: 'pwsh' },
    { kind: 'download', command: `curl -o "${join(headDir, 'blocked.bin')}" http://127.0.0.1:${port}/blocked.bin` },
    headDir,
  )
  // probeTotal() is fire-and-forget, so let the HEAD land before asserting. A
  // fixed wait is right here: the absence of a value is what is being tested, so
  // polling for it would exit immediately.
  await new Promise((resolve) => setTimeout(resolve, 400))
  assert.equal(
    probed.total,
    null,
    'a 403 HEAD with content-length: 1 must leave total unknown, not report a one-byte file',
  )
  ok('state: a rejected HEAD probe leaves total unknown instead of trusting content-length')
} finally {
  await new Promise((resolve) => server.close(resolve))
  rmSync(headDir, { recursive: true, force: true })
}

/* ------------------------------------------------------------------ */
/* background: jobs, foreground filtering, waiting                     */
/* ------------------------------------------------------------------ */

{
  setTitleLookup((sessionId) => (sessionId === 's1' ? '会话一' : ''))
  resetBackground()

  // A foreground command is registered as a job while it runs. It must NOT
  // become a background row: the transcript already shows the call, and calling
  // it "the agent is waiting on background work" would be wrong.
  const fgStart = Date.now()
  noteToolStart('s1', 'pwsh', {})
  noteJobEvent({
    type: 'registered',
    job: {
      id: 'pwsh-fg',
      kind: 'bash',
      label: 'Get-ChildItem',
      owner: 's1',
      status: 'running',
      startedAt: fgStart,
    },
  })
  let rows = backgroundSnapshot(fgStart + 500)
  assert.equal(rows.length, 0, 'a foreground shell call must not appear as background work')
  ok('background: a foreground shell call is filtered out')

  // The call returns; a genuinely detached job (started before the call) stays.
  const bgStart = fgStart - 60_000
  noteJobEvent({
    type: 'registered',
    job: {
      id: 'bash-bg',
      kind: 'bash',
      label: 'npm run build',
      owner: 's1',
      status: 'running',
      startedAt: bgStart,
    },
  })
  rows = backgroundSnapshot(fgStart + 600)
  assert.equal(rows.length, 1, 'the detached job must survive the foreground filter')
  assert.equal(rows[0].id, 'bash-bg')
  assert.equal(rows[0].sessionTitle, '会话一', 'background rows share the session-title lookup')
  assert.equal(rows[0].waiting, false, 'a running job the agent is not blocked on is not waiting')
  ok('background: a job that outlived its tool call is listed, and carries the session name')

  // The agent now blocks on it: the row must say so.
  noteToolEnd('s1')
  noteToolStart('s1', 'job_wait', {})
  rows = backgroundSnapshot(fgStart + 700)
  assert.equal(rows[0].waiting, true, 'job_wait blocks the agent on the job')
  ok('background: waiting is claimed only while the agent is blocked on it')

  // A polling readout does not block; a waiting one does.
  noteToolStart('s1', 'job_output', { wait: false })
  assert.equal(backgroundSnapshot(fgStart + 800)[0].waiting, false)
  noteToolStart('s1', 'job_output', { wait: true })
  assert.equal(backgroundSnapshot(fgStart + 900)[0].waiting, true)
  ok('background: job_output counts as blocking only with wait:true')

  // Settlement lingers briefly, then drops. The foreground call's own record is
  // removed by the shell tool when it returns, so drop it here too: without the
  // active call the filter no longer recognises it as foreground, and reality
  // is that the tool has already taken it away.
  noteToolEnd('s1')
  noteJobEvent({ type: 'removed', job: { id: 'pwsh-fg' } })
  noteJobEvent({
    type: 'settled',
    cause: 'producer',
    awaited: false,
    job: {
      id: 'bash-bg',
      kind: 'bash',
      label: 'npm run build',
      owner: 's1',
      status: 'completed',
      startedAt: bgStart,
      finishedAt: fgStart + 1000,
    },
  })
  assert.equal(backgroundSnapshot(fgStart + 1500).length, 1, 'a settled job lingers to be noticed')
  assert.equal(backgroundSnapshot(fgStart + 60_000).length, 0, 'and then it drops')
  ok('background: a settled row lingers, then leaves the payload')

  // Reset is what a disabled plugin calls; it must leave nothing behind.
  resetBackground()
  assert.equal(backgroundSnapshot(Date.now()).length, 0, 'reset clears every table')
  ok('background: reset clears every table')

  setTitleLookup(() => '')
}

console.log('\nHOST SMOKE OK — utils, detect and state behave as documented')
