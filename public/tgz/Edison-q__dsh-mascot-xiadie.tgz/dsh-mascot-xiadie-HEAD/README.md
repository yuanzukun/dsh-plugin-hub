# dsh-mascot-xiadie · Q版遐蝶余额小管家

DeepSeek Harness（DSH）网页插件：一个悬浮在页面上的 Q 版小人，用遐蝶的口吻替你查余额、报账。

## 玩法

| 操作 | 反应 |
|---|---|
| **单击**（待机时） | 查最新数据 → 图5 严谨表情 + 播报"余额还剩 ¥X。今日消耗 Y tokens。"（12 秒） |
| **单击**（播报时） | 刷新数据再报一次 |
| **双击 / 三连击**（播报时） | 切图3 害羞 + "不要再摸我啦" |
| **连点 8 次**（图3 时） | 切图4 无语 + "……" |
| **5 秒不碰** | 回图2 待机（看蝴蝶） |
| **拖动** | 移到任意位置；靠近屏幕边松手自动吸附；位置记住 |
| **右键** | 菜单「统计 / 进度 / 总账」+ 大小滑块（120–360px，位置大小均记住） |

- 每次点击都有摸头 Q 弹效果；
- 播报气泡 = 两团小圆 → 云朵气泡的三段动画，淡紫边白底；
- 反应气泡（2 秒）与播报气泡（12 秒）叠放共存，各自计时；
- **里程碑**：全机累计每跨 100 万 tokens，触发图1 + 两条庆祝气泡（"累计已使用 X Tokens……" / "项目会越来越成功的哦！"）。

## 状态图

| 图 | 状态 |
|---|---|
| state1 | 伤心（里程碑庆祝） |
| state2 | 待机 · 看蝴蝶 |
| state3 | 害羞 |
| state4 | 无语 |
| state5 | 严谨 · 播报 |

## 安装

```bash
dsh plugin --profile web add dsh-mascot-xiadie
dsh web   # 重启后刷新页面
```

余额查询需要 API Key：在 **设置 → 模型** 中配置 `DEEPSEEK_API_KEY`。
"今日消耗 tokens" 来自 [dsh-usage-plugin](https://www.npmjs.com/package/@feiyang666/dsh-usage-plugin) 的本地记录（北京时间口径）。

## 数据口径（重要）

| 数据 | 来源 | 说明 |
|---|---|---|
| 余额 | DeepSeek 官方 `GET /user/balance` | 实时 |
| 今日 / 全机 tokens | 读取 `@feiyang666/dsh-usage-plugin` 的本地记录 | 本机、从安装该插件起算；官网网页 / App 的用量拿不到 |
| 本项目 tokens | 本插件按会话工作区（文件夹）实时记账 | 每个项目文件夹独立账本，新项目从零 |

所有数据均存储在本机（`%LOCALAPPDATA%`），不上传任何服务器。

## 换成你的角色（不用改代码）

### 换图

把图按状态命名（PNG 透明底最佳）：

| 文件 | 状态 |
|---|---|
| `state1.png` | 伤心（里程碑） |
| `state2.png` | 待机 |
| `state3.png` | 害羞 |
| `state4.png` | 无语 |
| `state5.png` | 播报 |

放法二选一（改完重启）：
1. 替换插件目录 `assets/` 下的同名文件；
2. 设置环境变量 `DSH_MASCOT_DIR` 指向你自己的图目录。

### 换台词 / 换配色 / 换角色名

1. 复制下面的默认配置，存成一个 JSON 文件（比如 `my-mascot.json`）：
2. 改成你喜欢的人设；
3. 设置环境变量 `DSH_MASCOT_CONFIG` 指向该文件（Windows 可开 PowerShell 执行 `setx DSH_MASCOT_CONFIG "D:\path\to\my-mascot.json"`，或系统属性 → 环境变量）;
4. 重启 dsh web。

默认配置：

```json
{
  "name": "遐蝶",
  "accent": "#c4a8f5",
  "lines": {
    "report": "余额还剩 ¥{balance}。今日消耗 {tokens}。",
    "error": "未能读取账目。",
    "shy": "不要再摸我啦",
    "speechless": "……",
    "milestone1": "累计已使用 {tokens} Tokens……",
    "milestone2": "项目会越来越成功的哦！",
    "project": "本项目累计 {tokens} Tokens……",
    "total": "全机累计 {tokens} Tokens。",
    "noUsage": "暂无用量记录。",
    "noProject": "暂无项目用量记录。",
    "noTotal": "暂无全机记录。",
    "noStats": "暂无统计"
  }
}
```

- 配置文件**不需要写全**：只写想改的字段即可，其余自动沿用默认值；
- `{balance}`、`{tokens}` 是占位符，播报时自动替换成真实数字；
- `accent` 是主题色（描边、气泡、菜单、滑块都会跟随），支持 `#rgb` 和 `#rrggbb` 格式；
- `name` 用于图片的替代文本，也建议和台词口吻一致。

## License

代码以 [MIT](./LICENSE) 协议开源。

`assets/` 中的角色立绘（state1–5.png）为《崩坏：星穹铁道》官方素材，版权归 © miHoYo 所有，仅作个人非商业用途示例；二次分发前请替换为你自己的素材（见上文换图教程）。
