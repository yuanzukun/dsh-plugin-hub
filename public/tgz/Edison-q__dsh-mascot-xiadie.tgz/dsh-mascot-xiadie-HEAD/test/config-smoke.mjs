// config-smoke.mjs — 验证 /mascot/config 的合并与回退逻辑（无需真实 DSH 环境）
import { strict as assert } from 'node:assert'
import { writeFileSync, mkdtempSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import plugin from '../lib/index.js'

const routes = new Map()
const ctx = {
  get: (name) => {
    if (name === 'webServer') {
      return { register: (r) => { routes.set(r.path, r.handler) } }
    }
    return {}
  },
  on: () => {}
}

plugin.apply(ctx)

async function callConfig(env) {
  if (env) process.env.DSH_MASCOT_CONFIG = env
  else delete process.env.DSH_MASCOT_CONFIG
  const handler = routes.get('/mascot/config')
  if (!handler) throw new Error('/mascot/config 路由未注册')
  let body = null
  const res = {
    writeHead: () => {},
    end: (data) => { body = JSON.parse(data) }
  }
  await handler({ method: 'GET', url: '/mascot/config' }, res)
  return body
}

// 场景1：无环境变量 → 内置默认
const d = await callConfig(null)
assert.equal(d.name, '遐蝶')
assert.equal(d.accent, '#c4a8f5')
assert.equal(d.lines.report, '余额还剩 ¥{balance}。今日消耗 {tokens}，花费 ¥{cost}。')
assert.equal(d.lines.shy, '不要再摸我啦')
console.log('PASS 1: 默认配置')

// 场景2：部分覆盖 → 只覆盖写了的字段
const dir = mkdtempSync(join(tmpdir(), 'mascot-smoke-'))
const cfgFile = join(dir, 'custom.json')
writeFileSync(cfgFile, JSON.stringify({ name: '测试小人', lines: { shy: '别碰我！' } }), 'utf8')
const c = await callConfig(cfgFile)
assert.equal(c.name, '测试小人')          // 已覆盖
assert.equal(c.accent, '#c4a8f5')         // 未覆盖 → 默认
assert.equal(c.lines.shy, '别碰我！')      // 已覆盖
assert.equal(c.lines.report, '余额还剩 ¥{balance}。今日消耗 {tokens}，花费 ¥{cost}。') // 未覆盖 → 默认
console.log('PASS 2: 部分覆盖合并')

// 场景3：非法 JSON → 回退默认
const badFile = join(dir, 'bad.json')
writeFileSync(badFile, '{not json', 'utf8')
const b = await callConfig(badFile)
assert.equal(b.name, '遐蝶')
console.log('PASS 3: 非法 JSON 回退默认')

// 场景4：文件不存在 → 回退默认
const none = await callConfig(join(dir, 'missing.json'))
assert.equal(none.name, '遐蝶')
console.log('PASS 4: 文件缺失回退默认')

// 场景5：lines 不是对象 → 回退默认台词
const weirdFile = join(dir, 'weird.json')
writeFileSync(weirdFile, JSON.stringify({ name: 'X', lines: 'oops' }), 'utf8')
const w = await callConfig(weirdFile)
assert.equal(w.name, 'X')
assert.equal(w.lines.shy, '不要再摸我啦')
console.log('PASS 5: lines 类型异常回退')

rmSync(dir, { recursive: true, force: true })
console.log('ALL PASS')
