// shadow-check.mjs — 防变量遮蔽回归测试
// 2026-09-07 事故：模块级函数 fill() 被 build 内的 var fill（滑块进度条）遮蔽，
// 导致播报时 "fill is not a function"。此测试静态检查 client.js 中
// 任何 var 声明名与函数声明名重名（跨作用域遮蔽风险）即失败。
import { readFileSync } from 'node:fs'
import { strict as assert } from 'node:assert'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const target = process.argv[2]
  ? process.argv[2]
  : join(dirname(fileURLToPath(import.meta.url)), '..', 'lib', 'client.js')

const src = readFileSync(target, 'utf8')

// 收集全部函数声明名（含 build 内的局部函数）
const fnNames = new Set()
const fnRe = /\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g
let m
while ((m = fnRe.exec(src))) fnNames.add(m[1])

// 收集全部 var 声明名
const varNames = new Set()
const varRe = /\bvar\s+([A-Za-z_$][\w$]*)\s*[=;,]/g
while ((m = varRe.exec(src))) varNames.add(m[1])

// 交集 = 遮蔽风险
const shadowed = [...fnNames].filter((n) => varNames.has(n))

console.log('函数名（' + fnNames.size + ' 个）:', [...fnNames].join(', '))
console.log('var 名（' + varNames.size + ' 个）:', [...varNames].join(', '))

assert.deepEqual(shadowed, [], '检测到变量遮蔽函数: ' + shadowed.join(', '))
console.log('PASS: 无变量遮蔽')
