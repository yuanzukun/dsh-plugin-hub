// progress-fallback-smoke.mjs — 验证「里程碑按 1000 万档 + 旧记录换算」与「进度的工作区回退」
// 2026-10-05：桌面端前端报不上工作区 → 进度显示成"本项目累计 0.00"。
// 本测试全程用临时目录充当 LOCALAPPDATA，不读写真实账本、不联网（credentials 为空 → 不查余额）。
import { strict as assert } from 'node:assert'
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'

const root = mkdtempSync(join(tmpdir(), 'mascot-progress-'))
process.env.LOCALAPPDATA = root // 必须在 apply() 之前：三个账本都在 apply 时加载
delete process.env.DSH_USAGE_DATA_DIR
delete process.env.DSH_MASCOT_CONFIG

const stateDir = join(root, 'dsh-mascot-xiadie')
const usageDir = join(root, 'dsh-usage-plugin', 'dsh-usage')
mkdirSync(stateDir, { recursive: true })
mkdirSync(usageDir, { recursive: true })

// 旧格式里程碑：记的是"第几档"（1 档 = 100 万），361 档 = 3.61 亿
const stateFile = join(stateDir, 'milestone-state.json')
writeFileSync(stateFile, JSON.stringify({ lastCelebrated: 361 }), 'utf8')

const usageFile = join(usageDir, 'usage-records.json')
const writeUsage = (totalTokens) => {
  writeFileSync(usageFile, JSON.stringify([{ time: Date.now(), inputTokens: totalTokens, outputTokens: 0 }]), 'utf8')
}
writeUsage(375000000) // 全机 3.75 亿

const routes = new Map()
let streamHandler = null
const ctx = {
  get: (name) => {
    if (name === 'webServer') return { register: (r) => { routes.set(r.path, r.handler) } }
    if (name === 'agents') return { currentInitiator: () => ({ session: { header: { cwd: 'D:\\project4' } } }) }
    return {}
  },
  on: (name, handler) => { if (name === 'llm/stream') streamHandler = handler },
  effect: () => {}
}

const plugin = (await import('../lib/index.js')).default
plugin.apply(ctx)

async function callApi(query) {
  const handler = routes.get('/mascot/api')
  if (!handler) throw new Error('/mascot/api 路由未注册')
  let body = null
  const res = { writeHead: () => {}, end: (data) => { body = JSON.parse(data) } }
  await handler({ method: 'GET', url: '/mascot/api?' + query }, res)
  return body
}

// 场景1：旧档位 361 必须被换算成 3.6 亿（若按新单位直读，会变成 36.1 亿 → 这一档根本不会触发保存），
//        且方案B下"首次检查只吸收、不庆祝"。
const r1 = await callApi('force=1&m=1')
assert.equal(r1.milestone.crossed, false, '首次检查不应庆祝（方案B）')
const st1 = JSON.parse(readFileSync(stateFile, 'utf8'))
assert.equal(st1.lastCelebrated, 370000000, '旧档位 361(3.61亿) 应换算后吸收到 3.7 亿')
assert.equal(st1.unit, 10000000, '状态文件应记下新单位 1000 万')
console.log('PASS 1: 旧档位 361 自动换算 → 吸收到 3.7 亿，未庆祝')

// 场景2：同一档位内再查不重复庆祝
const r2 = await callApi('force=1&m=1')
assert.equal(r2.milestone.crossed, false, '未跨新档不应庆祝')
console.log('PASS 2: 未跨新档不重复庆祝')

// 场景3：跨到 3.8 亿 → 庆祝一次，且 value 是绝对 token 数
writeUsage(385000000)
const r3 = await callApi('force=1&m=1')
assert.equal(r3.milestone.crossed, true, '跨 1000 万档应庆祝')
assert.equal(r3.milestone.value, 380000000, 'value 应为绝对 token 数 3.8 亿')
console.log('PASS 3: 跨 3.8 亿庆祝一次，value=' + r3.milestone.value)

// 场景4：既没前端工作区、也还没有任何记账 → null（前端显示"暂无"，而不是误导性的 0.00）
const r4 = await callApi('force=1&m=0')
assert.equal(r4.projectTokens, null, '无工作区且无记账时应为 null')
assert.equal(r4.projectFallback, false)
console.log('PASS 4: 无工作区且无记账 → null（不会显示成 0.00）')

// 场景5：模拟一次流式记账（桌面端"实时监听"走的就是这条路），随后前端仍然报不上工作区
assert.ok(streamHandler, 'llm/stream 应已注册')
const stream = streamHandler({}, () => (async function* () {
  yield { type: 'text', text: 'hi' }
  yield { type: 'usage', usage: { inputTokens: 1000, outputTokens: 200, cacheReadTokens: 30, cacheWriteTokens: 4, reasoningTokens: 6 } }
})())
for await (const _ of stream) { /* 必须消费，观察器才会走完并落账 */ }

const r5 = await callApi('force=1&m=0')
assert.equal(r5.projectTokens, 1240, '回退后应取到最近记账的工作区累计')
assert.equal(r5.projectPath, 'd:/project4', '应回报实际使用的项目路径')
assert.equal(r5.projectFallback, true, '应标记为"前端未报工作区"回退')
console.log('PASS 5: 前端未报工作区时回退成功 → ' + r5.projectTokens + ' tokens @ ' + r5.projectPath)

// 场景6：前端报上工作区时优先用它，且不再标记回退
const r6 = await callApi('force=1&m=0&ws=' + encodeURIComponent('D:\\project4'))
assert.equal(r6.projectTokens, 1240)
assert.equal(r6.projectFallback, false, '前端报上时不应标记回退')
console.log('PASS 6: 前端报上工作区时按它查，不标记回退')

// 场景7：前端报了一个没有账目的工作区 → 老实给 0，不冒充别的项目
const r7 = await callApi('force=1&m=0&ws=' + encodeURIComponent('D:\\nope'))
assert.equal(r7.projectTokens, 0)
assert.equal(r7.projectPath, 'd:/nope')
console.log('PASS 7: 陌生工作区 → 0，不冒充其他项目')

// 场景8：模拟"重启"（重新 apply 一次、共用同一份数据目录）——即使还没有任何新对话，
//        也应能靠落盘的 lastCwd 直接回退到上次用过的项目（修"重启后第一次点进度显示暂无"的关键）
const routes2 = new Map()
const ctx2 = {
  get: (name) => {
    if (name === 'webServer') return { register: (r) => { routes2.set(r.path, r.handler) } }
    return {}
  },
  on: () => {},
  effect: () => {}
}
plugin.apply(ctx2)
let body2 = null
await routes2.get('/mascot/api')({ method: 'GET', url: '/mascot/api?force=1&m=0' }, {
  writeHead: () => {},
  end: (d) => { body2 = JSON.parse(d) }
})
assert.equal(body2.projectTokens, 1240, '重启后应靠落盘的 lastCwd 回退')
assert.equal(body2.projectPath, 'd:/project4')
assert.equal(body2.projectFallback, true)
console.log('PASS 8: 模拟重启后（无新对话）仍能回退到上次项目')

// 场景9：账本文件已是新格式 { map, lastCwd }
const ledgerJson = JSON.parse(readFileSync(join(stateDir, 'project-ledger.json'), 'utf8'))
assert.equal(ledgerJson.lastCwd, 'D:\\project4', '新格式应把 lastCwd 落盘')
assert.equal(ledgerJson.map['d:/project4'], 1240)
console.log('PASS 9: 账本文件为 { map, lastCwd } 新格式')

rmSync(root, { recursive: true, force: true })
console.log('ALL PASS')
