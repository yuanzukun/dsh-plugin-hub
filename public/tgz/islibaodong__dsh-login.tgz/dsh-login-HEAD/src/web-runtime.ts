import { networkInterfaces } from 'node:os'
import { createRequire } from 'node:module'
import type { Context } from '@deepseek-ai/cordis'

/** Values of the `webRuntime` service dsh-login provides when taking over. */
export interface WebRuntimeValues {
  /** LAN IPv4 literals sampled once when the server binds all interfaces. */
  lanAddresses: string[]
  /** LAN literals followed by explicit invocation authorities. */
  trustedHosts: string[]
}

/** The webserver schema's all-interfaces bind literal. */
const ALL_INTERFACES_HOST = '0.0.0.0'

/**
 * Resolve one LAN-trust snapshot from the active server bind — the same
 * derivation dsh-web-app's resolveLanTrust performs (LAN IPv4 literals when
 * bound to all interfaces, plus the explicit extras).
 */
export function resolveLanTrust(bindHost: string, extra: readonly string[]): WebRuntimeValues {
  const lanAddresses = bindHost === ALL_INTERFACES_HOST
    ? Object.values(networkInterfaces()).flat()
      .filter((iface): iface is NonNullable<typeof iface> => iface !== undefined && iface.family === 'IPv4' && !iface.internal)
      .map(iface => iface.address)
    : []
  return { lanAddresses, trustedHosts: [...lanAddresses, ...extra] }
}

/**
 * Resolve the frontend dist anchor through @deepseek-ai/dsh-web-frontend's
 * package exports, exactly like dsh-web-app's internals.resolveDistIndex.
 * Throws with a build hint when the dist is not built.
 */
export function resolveDistIndex(): string {
  const require = createRequire(import.meta.url)
  try {
    return require.resolve('@deepseek-ai/dsh-web-frontend/dist/index.html')
  } catch {
    throw new Error('dsh-login: frontend dist not found; run pnpm run build from the deepseek-harness repository root first, or set config.distIndex explicitly')
  }
}

/** Environment variable naming the canonical local URL of this Web GUI. */
const DSH_WEB_URL = 'DSH_WEB_URL'

/** Display-only mirror of the webserver schema's loopback host. */
const LOOPBACK_HOST = '127.0.0.1'

/**
 * The URL host a `dsh web:` line / shell variable should spell. DSH
 * 0.2.1-alpha.2 makes the webserver bind a concrete IP literal only
 * (wildcard binds are schema-rejected), so the actual bind address is the
 * correct advertised URL; on older harness versions a 0.0.0.0 bind still
 * exists and falls back to loopback (the LAN suffix covers LAN access).
 */
function urlHost(bindHost: string): string {
  return bindHost === ALL_INTERFACES_HOST ? LOOPBACK_HOST : bindHost
}

/**
 * Print the `dsh web:` URL line once the server is up — the readiness signal
 * dsh-web-app's web-runtime row used to print before dsh-login took it over.
 * Waits for the Loader tree to settle so a sibling failure cannot announce a
 * dead app, exactly like the original row. Mirrors upstream web-app's
 * bind-address URL (0.2.1-alpha.2 dropped the loopback-only spelling).
 */
function printWebUrl(ctx: Context, runtime: WebRuntimeValues): void {
  const print = (): void => {
    const webServer = ctx.get('webServer')
    if (webServer === undefined) return
    const host = urlHost(webServer.host)
    const lanCandidate = runtime.lanAddresses[0]
    const suffix = lanCandidate === undefined ? '' : ` (LAN: http://${lanCandidate}:${String(webServer.port)})`
    console.log(`dsh web: http://${host}:${String(webServer.port)}${suffix}`)
  }
  const settled = ctx.get('loader')?.await()
  if (settled === undefined) print()
  else void settled.then(() => print(), () => {})
}

/**
 * The canonical `http://<url-host>:<port>` origin of the Web GUI. DSH
 * 0.2.1-alpha.3 adds `webServer.getOrigin()` — the same URL-host
 * canonicalization (literal bind address, IPv6 brackets, loopback folding)
 * the upstream web-app row now advertises through its `webApp` service;
 * feature-detect it and fall back to the manual formation for older harness
 * versions and for a pre-bind read (getOrigin throws before the listener
 * binds a port).
 */
function advertisedUrl(ctx: Context): string {
  const webServer = ctx.get('webServer')
  if (webServer === undefined) return ''
  const origin = webServer as { getOrigin?: () => string }
  if (typeof origin.getOrigin === 'function') {
    try {
      return origin.getOrigin()
    } catch {
      // Pre-bind or a non-advertisable bind (zone-id literal); fall through
      // to the manual spelling below, matching the `dsh web:` print line.
    }
  }
  return `http://${urlHost(webServer.host)}:${String(webServer.port)}`
}

/**
 * Provide the `webRuntime` service and the DSH_WEB_URL shell variable —
 * the parts of dsh-web-app's web-runtime row the rest of the composition
 * depends on once that row is disabled in favor of dsh-login.
 *
 * Also provides the `webApp` service: DSH 0.2.1-alpha.3 splits web-app's
 * web-runtime row, moving its prompt sections into the new
 * `harness-dev-context` row, which injects `webApp` for its
 * `app:web-surface` runtime-context line (`Current DeepSeek Harness Web GUI
 * URL`). With the web-runtime row disabled, dsh-login is that service's only
 * possible provider — without it the harness-dev-context row fails injection
 * at composition. The read is lazy (prompt context assembles per session,
 * long after the bind), so getOrigin is safe by the time anyone calls it.
 */
export function provideWebRuntime(ctx: Context, trustedHosts: readonly string[]): WebRuntimeValues {
  const runtime = resolveLanTrust(ctx.webServer.host, trustedHosts)
  ctx.provide('webRuntime', runtime)
  ctx.provide('webApp', { getAdvertisedUrl: () => advertisedUrl(ctx) })
  printWebUrl(ctx, runtime)
  // Keep the bash-visible web URL alive for agent sessions.
  const shellEnv = ctx.get('shellEnv')
  if (shellEnv !== undefined) {
    ctx.effect(() => shellEnv.register({
      name: 'web-runtime',
      variables: {
        [DSH_WEB_URL]: { description: 'Canonical local URL of the DeepSeek Harness Web GUI serving this session.' },
      },
      resolve: () => {
        const webServer = ctx.get('webServer')
        if (webServer === undefined) return { [DSH_WEB_URL]: '' }
        return { [DSH_WEB_URL]: `http://${urlHost(webServer.host)}:${String(webServer.port)}` }
      },
    }), 'dsh-login: DSH_WEB_URL shell variable')
  }
  return runtime
}
