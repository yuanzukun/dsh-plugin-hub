import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
// Type-only: pulls in the `connection/request` Events augmentation (DSH
// ≥ 0.1.6-alpha.2) so the bridge wall below typechecks. Erased at build.
import type {} from '@deepseek-ai/dsh-client-connection'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import type { Config } from './config.ts'
import { Config as ConfigSchema } from './config.ts'
import { SessionStore } from './session.ts'
import { UserStore } from './users.ts'
import { OwnershipIndex } from './ownership.ts'
import { TrustedHosts } from './hosts.ts'
import { DefaultWorkspaceSetting } from './workspace-setting.ts'
import { BooleanSetting } from './boolean-setting.ts'
import { applyWithRetry, RemoteWebUiCompat, type RemoteWebUiCompatDeps } from './remote-web-ui-compat.ts'
import { createGatewayHandler } from './gateway.ts'
import { createRootRouteListener } from './root-route.ts'
import { createWebIdentity, sessionFromHeaders, type ConnectionLike, type HeaderSource, type WebIdentity } from './web-auth.ts'
import { createApiBridgeAuth } from './api-bridge-auth.ts'
import { installAdmitShadow, installDispatchShadows, type DispatchGuardDeps } from './dispatch-guard.ts'
import { WIRE_SURFACE_DSH_VERSION } from './api-filter.ts'
import { DefaultWorkspaceProvisioner, type WorkspaceRegistryLike } from './provision.ts'
import { createHostSessionApi, createHostSessionSource, tryGetService } from './host-session-access.ts'
import { probeOwnedSessionIds } from './bridge-list-filter.ts'
import { createLoginHandler, createLogoutHandler, createLogoutRedirectHandler, createSetupHandler } from './login-api.ts'
import { createAdminRoutes } from './admin-api.ts'
import { renderLoginPage, renderSetupPage } from './login-page.ts'
import { provideWebRuntime, resolveDistIndex } from './web-runtime.ts'
import { resolveDshHome } from './http-json.ts'
import { deriveCapabilities } from './capabilities.ts'

/** Stable Cordis plugin name. */
export const name = 'dsh-login'

/** Hard dependencies: the web server and credentials services. */
export const inject = ['webServer', 'credentials']

export { ConfigSchema as Config }

// Compatibility seam (option A, DSH ≥ 0.1.5-alpha.1): the REMOTE-layer
// per-user isolation guard. Re-exported from the host bundle so a deployment
// that wants per-user isolation can import `wrapRemoteGateway` /
// `createRemoteIsolation` FROM THIS PACKAGE and compose them over the native
// `typertGateway` (see docs/verify-option-A.md §B). Note: this is a
// composition primitive, NOT a runtime re-provide — dsh-login cannot
// hot-swap the live `typertGateway` service (duplicate-service error).
export { wrapRemoteGateway, createRemoteIsolation } from './remote-guard.ts'
export type {
  RemoteGateway,
  RemoteInvokeRequest,
  GuardUser,
  UserResolver,
  OwnedPredicate,
} from './remote-guard.ts'
// Deployment-side composition glue (option B): helper + types for wrapping a
// native `typertGateway` row with dsh-login's per-user isolation guard, keyed
// to the ownership sidecar dsh-login publishes as the `dshLoginOwnership`
// service below (see docs/compose-guard.md).
export {
  DSH_LOGIN_OWNERSHIP_SERVICE,
  createDshLoginIsolation,
  composeGuardedGateway,
  composeDshLoginGuard,
  getDshLoginOwnership,
} from './glue.ts'
export type { DshLoginIsolationDeps, WrappedRemoteGateway } from './glue.ts'

/** Minimal webserver shape the fallback-seat probe needs. */
interface FallbackHost {
  registerFallback(fallback: unknown): () => void
  /** Retained seat (private on the real service; probed by capability). */
  fallback?: unknown
}

/**
 * Claim the webserver fallback seat for the gateway handler.
 *
 * DSH 0.2.3-alpha.1 stores the seat as an object and honours its `auth` rule,
 * which is what lets a logged-in browser's index render see the admitted
 * `PeerScope`. rc.5 stores the handler itself and has no admission concept.
 * The two are told apart by what the service retained after the first
 * registration: a normalized seat still exposes `handler === <the function>`.
 * When the server normalized, the seat is replaced by the auth-aware form
 * (claimed while a dsh_session is live, anonymous otherwise, so /login still
 * loads and the gateway can answer its own 302).
 *
 * @param webServer - the webserver service.
 * @param handler - gateway fallback handler.
 * @param store - dsh-login session store.
 * @returns the disposer releasing the seat.
 */
function registerGatewayFallback(webServer: FallbackHost, handler: WebRoute['handler'], store: SessionStore, identity: WebIdentity): () => void {
  const seat = webServer.registerFallback(handler)
  const retained = webServer.fallback
  const normalized = typeof retained === 'object' && retained !== null && (retained as { handler?: unknown }).handler === handler
  if (!normalized) return seat
  seat()
  return webServer.registerFallback({
    handler,
    // Require a Peer only where this deployment can actually mint one: the
    // connection seam's provider is registered when `connection` loads. A
    // boot without it (tests, minimal hosts) keeps serving the shell, exactly
    // as the rc.5 path did, because the gateway still runs its own cookie wall.
    auth: (request: { headers: HeaderSource }) => {
      const session = sessionFromHeaders(request.headers, store)
      if (session === undefined) return 'anonymous'
      return identity.peerForSession(session.token, session.user) === undefined ? 'anonymous' : 'required'
    },
  })
}

/**
 * Register the multi-user authentication gateway on the web server:
 *
 * - Login/logout/setup JSON API (`{username, password}` against the
 *   UserStore — scrypt hashes stored under the `${password}_USERS`
 *   credential ref; the old single-password ref itself stays configured but
 *   is no longer used for authentication).
 * - Admin JSON API + `GET /admin` management page (admin sessions only).
 * - The identity-aware `/api` carrier takeover (`createConnectionPlugin`)
 *   mounted as a child plugin, and the OwnershipIndex sidecar with a
 *   teardown flush so pending ownership writes reach disk on stop/update.
 *
 * All route disposers are owned by the plugin fiber via ctx.effect for clean
 * teardown on stop/update/undefine. dsh-login takes over the webRuntime
 * service and the fallback seat from dsh-web-app's web-runtime row (which
 * the shipped cordis.patch.yml disables) and serves the frontend dist
 * through the authenticated gateway.
 */
export function apply(ctx: Context, config: Config): void {
  if (!config.enabled) return
  const dataDir = config.dataDir === '' ? join(resolveDshHome(), '.dsh-login') : config.dataDir
  // Persisted session store: sessions survive a process restart (so an already
  // open SPA's /api calls are not suddenly 401'd — the in-memory-only store
  // invalidated every cookie on reload). Tokens live in <dataDir>/sessions.json
  // (0o600). Session TTL still applies on load, so stale records are dropped.
  const store = new SessionStore(config.sessionTtl, join(dataDir, 'sessions.json'))
  const users = new UserStore(ctx.credentials, credentialRef(`${config.password}_USERS`))
  const ownership = new OwnershipIndex(join(dataDir, 'ownership.json'))
  const hosts = new TrustedHosts(join(dataDir, 'trusted-hosts.json'))
  // Live + persisted "默认用户工作空间" toggle: starts from config.defaultWorkspace
  // (default on) and can be flipped by an admin at runtime from the settings
  // panel. The provisioner reads it per request, so the toggle binds immediately.
  const defaultWorkspaceSetting = new DefaultWorkspaceSetting(join(dataDir, 'settings.json'), config.defaultWorkspace)
  // Live + persisted "remote-web-ui 兼容" toggle: when on (default), dsh-login
  // writes @linxin666/dsh-remote-web-ui's requirePairingForLan to false so
  // non-loopback (public FRP) desktop traffic rides dsh-login's /api channel
  // instead of remote-web-ui's device-pairing gate. No-op if remote-web-ui is
  // not installed. The toggle is settings-backed + hot-reloaded by that plugin,
  // so flipping it at runtime takes effect immediately and persists.
  const remoteWebUiSetting = new BooleanSetting(join(dataDir, 'settings-remote-web-ui.json'), config.remoteWebUiCompat)
  const sidebarSetting = new BooleanSetting(join(dataDir, 'settings-sidebar.json'), true)
  const remoteWebUiCompat = new RemoteWebUiCompat({
    getSettings: () => ctx.get('settings') as unknown as ReturnType<RemoteWebUiCompatDeps['getSettings']>,
  })
  const distIndex = config.distIndex === '' ? resolveDistIndex() : config.distIndex
  const gatewayConfig = { ...config, distIndex }
  const loginDeps = { users, store, sessionTtl: config.sessionTtl, hosts, autoTrust: config.autoTrustHosts }

  // Capture the webRuntime LAN literals so the /api takeover trusts the
  // bound LAN addresses automatically (the shipped connection row read them
  // from webRuntime too; dsh-login's own fence used to see only the static
  // config list, which is why LAN IPs and frp public hosts needed hand-listing).
  const runtime = config.takeOverWebRuntime ? provideWebRuntime(ctx, config.trustedHosts) : undefined

  // Per-user default-workspace provisioning: the provisioner resolves the
  // host session surface lazily (sessionController first, typertGateway as
  // fallback) and the durable workspace registry lazily, because neither
  // service is guaranteed to be registered at dsh-login's apply time. It
  // reads the defaultWorkspace toggle live so the admin switch binds without
  // a restart.
  const workspaceRoot = config.workspaceRoot === '' ? join(resolveDshHome(), 'workspaces') : config.workspaceRoot
  const provisioner = new DefaultWorkspaceProvisioner({
    workspaceRoot,
    getApi: createHostSessionApi(ctx),
    ownership,
    getRegistry: () => tryGetService<WorkspaceRegistryLike>(ctx, 'workspaceRegistry'),
    enabled: () => defaultWorkspaceSetting.get(),
  })
  // Publish the live ownership sidecar as a service so a deployment row
  // (docs/compose-guard.md) can compose dsh-login's isolation guard over the
  // native typertGateway without reaching into dsh-login internals. Declared
  // in the composing row's `inject` so the composition runs after dsh-login.
  ctx.provide('dshLoginOwnership', ownership)

  const loginPageRoute: WebRoute = {
    kind: 'exact',
    path: '/login',
    // DSH 0.2.3-alpha.1 admission: every route defaults to `required`, so the
    // login wall's own pages must declare themselves reachable without a Peer
    // (otherwise the webserver answers 503 before the cookie check runs).
    // rc.5 lines ignore the field.
    auth: 'anonymous',
    handler: async (_req, res) => {
      // No users yet → first-time setup form; otherwise the login form.
      const html = (await users.isEmpty()) ? renderSetupPage() : renderLoginPage()
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
      res.end(html)
    },
  }

  // Browser identity for the DSH 0.2.3-alpha.1 connection seam: one tagged
  // owner Peer per live dsh_session, registered as a credential provider on
  // `connection.authentication` below.
  const identity = createWebIdentity(ctx, store)
  const gatewayHandler = createGatewayHandler(ctx, gatewayConfig, store, identity)

  ctx.effect(() => ctx.webServer.register(loginPageRoute), 'dsh-login: /login')
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: '/api/auth/setup',
    auth: 'anonymous',
    handler: createSetupHandler(loginDeps),
  }), 'dsh-login: /api/auth/setup')
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: '/api/auth/login',
    auth: 'anonymous',
    handler: createLoginHandler(loginDeps),
  }), 'dsh-login: /api/auth/login')
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: '/api/auth/logout',
    auth: 'anonymous',
    handler: createLogoutHandler(store),
  }), 'dsh-login: /api/auth/logout')
  // Link-friendly logout: same revocation, but answers with a redirect so
  // plain <a href="/logout"> entries (e.g. the admin page topbar) work.
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: '/logout',
    auth: 'anonymous',
    handler: createLogoutRedirectHandler(store),
  }), 'dsh-login: /logout')
  for (const route of createAdminRoutes({ users, store, hosts, defaultWorkspaceSetting, remoteWebUiSetting, sidebarSetting, remoteWebUiCompat, onRemoteWebUiApply: (enabled) => applyWithRetry(remoteWebUiCompat, enabled, config.remoteWebUiPublicBaseUrl, 3, 50) })) {
    ctx.effect(() => ctx.webServer.register({ ...route, auth: 'anonymous' }), `dsh-login: ${route.path}`)
  }
  // Boot-time application of the remote-web-ui compatibility toggle. Deferred
  // so it never blocks startup; applyWithRetry keeps retrying a few hundred ms
  // in case remote-web-ui's settings namespace registers after dsh-login does.
  const bootCompat = applyWithRetry(remoteWebUiCompat, remoteWebUiSetting.get(), config.remoteWebUiPublicBaseUrl)
  void bootCompat
  // The gateway claims the fallback seat (not prefix /) because the
  // WebServer's prefix match only catches the exact path '/' for a '/'
  // prefix. The fallback catches everything no named route claims.
  //
  // DSH 0.2.3-alpha.1 added per-seat admission: an object seat can declare an
  // `auth` rule, and only an admitted Peer is handed to the handler (the
  // index render needs it). rc.5 stores the bare handler with no auth concept,
  // so the seat is chosen by probing what the server retained.
  ctx.effect(
    () => registerGatewayFallback(ctx.webServer as unknown as FallbackHost, gatewayHandler, store, identity),
    'dsh-login: gateway fallback',
  )

  // DSH 0.2.3-alpha.2 keeps the core exact `/` route added in alpha.1
  // (remote-connection's browser pairing page) in front of the fallback seat,
  // so a named route — not the wall — owns the bare root. `webserver/request`
  // is a waterfall emitted before named-route dispatch, which lets the same
  // gateway handler answer `/` (login wall or rendered index) while every
  // other path keeps its existing route/fallback handling.
  ctx.effect(
    () => ctx.on('webserver/request', createRootRouteListener(gatewayHandler)),
    'dsh-login: root route hook',
  )

  // The alpha.1 connection seam: /api carriers admit through
  // `connection.authentication`, so dsh-login registers a provider that maps
  // a live dsh_session cookie to its own tagged owner Peer. Registered lazily
  // (the connection service may load after this plugin). On rc.5 connections
  // there is no `authentication` registry and this is a no-op; the admit
  // shadow below keeps covering that line.
  ctx.inject(['connection', 'connection.authentication'], (fork) => {
    fork.effect(
      () => identity.register(fork.connection as unknown as ConnectionLike),
      'dsh-login: connection authentication provider',
    )
  })

  // DSH ≥ 0.1.6-alpha.2: the native connection row fires `connection/request`
  // on its shared /api route before bridging. dsh-login registers a wall
  // (default on, config.apiBridgeAuth) so /api requires a live dsh-login
  // session — logout/expiry actually revokes the bridge even though the
  // process-wide browser-auth cookie persists. `global: true` keeps the
  // listener firing regardless of any context filter at the emit site; on
  // DSH < 0.1.6-alpha.2 the event never fires and this is a harmless no-op.
  if (config.apiBridgeAuth) {
    // Diagnostics for a stale allow-list: a denial of a method this build does
    // not know about means upstream renamed something (the issue #4 failure
    // mode). Warn once per method so a rename is visible in the host log
    // instead of only in the user's browser console.
    const reported = new Set<string>()
    const reportUnknownMethod = (method: string, username: string): void => {
      if (reported.has(method)) return
      reported.add(method)
      const message = `dsh-login: /api/${method} was denied for '${username}' but is not part of the DSH ${WIRE_SURFACE_DSH_VERSION} wire surface this build knows — upstream may have renamed it; refresh src/api-filter.ts (node scripts/dump-wire-surface.mjs)`
      const logger = (ctx as unknown as { logger?: { warn?: (msg: string) => void } }).logger
      if (typeof logger?.warn === 'function') logger.warn(message)
      else console.warn(message)
    }
    // Owned-set resolution for response filtering: best-effort probe over the
    // sidecar closure plus the caller's live session list. A failed probe
    // degrades to sidecar-only filtering (or none when the sidecar is empty).
    const ownedProvider = (username: string) => probeOwnedSessionIds(username, ownership, createHostSessionSource(ctx))
    ctx.effect(
      () => ctx.on('connection/request', createApiBridgeAuth({
        store,
        ownership,
        quietDenials: config.quietDenials,
        ownedProvider,
        provisioner,
        onUnknownMethod: reportUnknownMethod,
      }), { global: true }),
      'dsh-login: /api bridge auth wall',
    )
  }

  // Issue #11: streaming methods (`workspace.follow`, `session.follow`, …)
  // ride the Remote stream mux WebSocket, which the bridge wall above never
  // sees. The dispatch-seam guard shadows the connection service's `admit`
  // (so the mux upgrade requires a live dsh-login session too) and the
  // gateway's `dispatchRpc` / `openWireStream` (so tagged browser peers are
  // checked against the wire surface and per-id ownership, and
  // `workspace.follow` trees are filtered per user). Untagged peers —
  // launch-token CLI/SDK sessions and host-internal callers — pass through
  // untouched. Same feature gate as the wall: this is the isolation
  // boundary, not a standalone feature.
  if (config.apiBridgeAuth) {
    const warnLog = (message: string): void => {
      const logger = (ctx as unknown as { logger?: { warn?: (msg: string) => void } }).logger
      if (typeof logger?.warn === 'function') logger.warn(message)
      else console.warn(message)
    }
    const guardDeps = {
      store,
      ownership,
      sessionSource: () => createHostSessionSource(ctx),
    }
    ctx.inject(['connection', 'typertGateway'], (fork) => {
      fork.effect(() => {
        const uninstallAdmit = installAdmitShadow(fork.connection, guardDeps, warnLog)
        const uninstallDispatch = installDispatchShadows(tryGetService(fork, 'typertGateway'), guardDeps, warnLog)
        return () => {
          uninstallAdmit()
          uninstallDispatch()
        }
      }, 'dsh-login: dispatch-seam guard')
    })
  }

  // Per-identity capability baseline, injected at render time. index-inject
  // fires before any specific user's request, so this declares the ordinary-
  // user surface as a static, safe default (the common case for dsh-login);
  // clients that need the exact identity (an admin, a special account) fetch
  // GET /api/auth/capabilities, which is authoritative. UI-plugin boot code
  // can read window.__DSH_SESSION__ to skip features the current user cannot
  // use instead of probing (and being denied on) them.
  const cap = deriveCapabilities({ username: '', isAdmin: false })
  const sessionBaselineScript = `window.__DSH_SESSION__={username:null,isAdmin:false,capabilities:${JSON.stringify(cap)}};`
  ctx.effect(() => ctx.on('webserver/index-inject', (table: Array<{ kind: string; placement: string; text: string }>) => {
    table.push({ kind: 'script', placement: 'head', text: sessionBaselineScript })
  }), 'dsh-login: capability baseline injection')

  // Teardown: flush any pending ownership-index / trusted-hosts writes to
  // disk. Returning the Promise lets Cordis await it on stop so a freshly
  // learned host (debounce still pending) is not dropped (review #3).
  // Claimed browser Peers are released first: their abort signals belong to
  // this plugin's lifetime.
  ctx.effect(() => () => {
    identity.disposeAll()
    return Promise.all([store.flush(), ownership.flush(), hosts.flush(), defaultWorkspaceSetting.flush(), remoteWebUiSetting.flush(), sidebarSetting.flush()])
  }, 'dsh-login: sessions + ownership + hosts + settings flush')
}
