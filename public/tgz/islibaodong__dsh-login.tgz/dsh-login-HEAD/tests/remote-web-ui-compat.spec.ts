import { describe, expect, it, vi } from 'vitest'
import { RemoteWebUiCompat, applyWithRetry, REMOTE_WEB_UI_NAMESPACE } from '../src/remote-web-ui-compat.ts'

/** A minimal fake SettingsProvider.update capturing the namespace + patch. */
function fakeSettings(updateImpl?: (ns: string, patch: unknown) => Promise<void> | void) {
  const calls: Array<{ ns: string; patch: unknown }> = []
  const settings = {
    async update(ns: string, patch: unknown): Promise<void> {
      calls.push({ ns, patch })
      await updateImpl?.(ns, patch)
    },
  }
  return { settings, calls }
}

describe('RemoteWebUiCompat.apply', () => {
  it('writes enabled:true + requirePairingForLan:false for compat ON into the remote-web-ui namespace', async () => {
    const { settings, calls } = fakeSettings()
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await compat.apply(true)).toBe('ok')
    expect(calls).toEqual([{ ns: REMOTE_WEB_UI_NAMESPACE as unknown as string, patch: { enabled: true, requirePairingForLan: false } }])
  })

  it('writes requirePairingForLan:true (restore pairing) for compat OFF', async () => {
    const { settings, calls } = fakeSettings()
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await compat.apply(false)).toBe('ok')
    expect(calls).toEqual([{ ns: REMOTE_WEB_UI_NAMESPACE as unknown as string, patch: { requirePairingForLan: true } }])
  })

  it('returns skipped when there is no settings service', async () => {
    const compat = new RemoteWebUiCompat({ getSettings: () => undefined })
    expect(await compat.apply(true)).toBe('skipped')
  })

  it('returns unregistered when the namespace is not registered (not remote-web-ui)', async () => {
    const { settings } = fakeSettings(() => { throw new Error('settings namespace not registered') })
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await compat.apply(true)).toBe('unregistered')
  })

  it('returns unregistered for the profile-backed form error (DSH settings refactor)', async () => {
    // DSH ≥ 2026-09-21 replaced the "not registered" wording with
    // `No configurable plugin entry "<ns>"` (packages/settings write()).
    const { settings } = fakeSettings(() => { throw new Error('No configurable plugin entry "remote-web-ui"') })
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await compat.apply(true)).toBe('unregistered')
  })

  it('gives up with unregistered under applyWithRetry for the profile-backed form error', async () => {
    const { settings } = fakeSettings(() => { throw new Error('No configurable plugin entry "remote-web-ui"') })
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await applyWithRetry(compat, true, '', 2, 1)).toBe('unregistered')
  })

  it('rethrows unexpected errors (a real failure, not a missing namespace)', async () => {
    const { settings } = fakeSettings(() => { throw new Error('disk full') })
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    await expect(compat.apply(true)).rejects.toThrow('disk full')
  })

  it('includes publicBaseUrl in the patch when compat ON and a valid http URL is given', async () => {
    const { settings, calls } = fakeSettings()
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await compat.apply(true, 'http://8.137.156.163:13080')).toBe('ok')
    expect(calls).toEqual([{
      ns: REMOTE_WEB_UI_NAMESPACE as unknown as string,
      patch: { enabled: true, requirePairingForLan: false, publicBaseUrl: 'http://8.137.156.163:13080' },
    }])
  })

  it('omits publicBaseUrl when compat ON but the value is empty or invalid', async () => {
    const { settings, calls } = fakeSettings()
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    await compat.apply(true, '')
    await compat.apply(true, 'not-a-url')
    const patches = calls.map(call => (call.patch as Record<string, unknown>).publicBaseUrl)
    expect(patches).toEqual([undefined, undefined])
    expect(calls[0].patch).toEqual({ enabled: true, requirePairingForLan: false })
  })

  it('never writes publicBaseUrl when compat is OFF (restore pairing only)', async () => {
    const { settings, calls } = fakeSettings()
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    await compat.apply(false, 'http://8.137.156.163:13080')
    expect(calls[0].patch).toEqual({ requirePairingForLan: true })
  })
})

describe('applyWithRetry', () => {
  it('returns ok on the first attempt when the namespace is registered', async () => {
    const { settings } = fakeSettings()
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await applyWithRetry(compat, true, '', 3, 1)).toBe('ok')
  })

  it('retries until the namespace registers within budget', async () => {
    const { settings } = fakeSettings()
    const spy = vi.spyOn(settings, 'update')
    spy.mockImplementationOnce(() => { throw new Error('settings namespace not registered') })
      .mockImplementationOnce(() => { throw new Error('settings namespace not registered') })
      .mockImplementationOnce(() => { /* noop — registers on the third */ })
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await applyWithRetry(compat, true, '', 5, 1)).toBe('ok')
    expect(spy).toHaveBeenCalledTimes(3)
  })

  it('gives up with unregistered after exhausting the budget', async () => {
    const { settings } = fakeSettings()
    const spy = vi.spyOn(settings, 'update')
    spy.mockImplementation(() => { throw new Error('settings namespace not registered') })
    const compat = new RemoteWebUiCompat({ getSettings: () => settings })
    expect(await applyWithRetry(compat, true, '', 2, 1)).toBe('unregistered')
    expect(spy).toHaveBeenCalledTimes(2)
  })

  it('retries while the settings service is absent until it appears, then writes', async () => {
    // Settings resolves only after the first two probes — the boot race where
    // dsh-login applies before the settings provider mounts.
    const { settings } = fakeSettings()
    let probes = 0
    const compat = new RemoteWebUiCompat({
      getSettings: () => { probes++; return probes >= 3 ? settings : undefined },
    })
    expect(await applyWithRetry(compat, true, '', 6, 1)).toBe('ok')
    expect(probes).toBeGreaterThanOrEqual(3)
  })

  it('gives up with skipped when the settings service never appears', async () => {
    const compat = new RemoteWebUiCompat({ getSettings: () => undefined })
    expect(await applyWithRetry(compat, true, '', 3, 1)).toBe('skipped')
  })
})