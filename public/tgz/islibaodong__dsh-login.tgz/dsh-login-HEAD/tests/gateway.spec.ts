import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import Include from '@deepseek-ai/cordis-plugin-include'
import HttpServer from '@deepseek-ai/dsh-host-webserver'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import { MemoryCredentials } from './memory-credentials.ts'
import { SessionStore } from '../src/session.ts'
import { createGatewayHandler } from '../src/gateway.ts'
import type { Config } from '../src/config.ts'

let root: string | undefined
let context: Context | undefined

afterEach(async () => {
  await context?.fiber.dispose()
  context = undefined
  if (root !== undefined) await rm(root, { recursive: true, force: true })
  root = undefined
})

async function bootServer(): Promise<{ ctx: Context; port: number }> {
  root = await mkdtemp(join(tmpdir(), 'dsh-gateway-'))
  const configPath = join(root, 'cordis.yml')
  await writeFile(configPath, [
    "- name: '@deepseek-ai/dsh-host-webserver'",
    '  config:',
    "    host: '127.0.0.1'",
    '    port: 0',
    '',
  ].join('\n'))
  context = new Context()
  context.baseUrl = pathToFileURL(root).href + '/'
  await context.plugin(Loader)
  context.loader.builtins.include = Include
  const modules = new Map<string, unknown>([['@deepseek-ai/dsh-host-webserver', HttpServer]])
  context.loader.internal = {
    version: 'v2',
    async import(specifier: string) {
      if (!modules.has(specifier)) throw new Error(`unexpected import: ${specifier}`)
      return modules.get(specifier)
    },
  } as unknown as NonNullable<typeof context.loader.internal>
  await context.loader.create({ name: 'cordis:include', config: { path: pathToFileURL(configPath).href } })
  await context.loader.await()
  return { ctx: context, port: context.webServer.port }
}

async function request(port: number, path: string, init?: RequestInit): Promise<{ status: number; body: string; headers: Headers }> {
  const response = await fetch(`http://127.0.0.1:${String(port)}${path}`, { ...init, redirect: 'manual' })
  return { status: response.status, body: await response.text(), headers: response.headers }
}

const config: Config = {
  password: 'DSH_LOGIN_PASSWORD',
  distIndex: '/nonexistent/index.html',
  sessionTtl: 3600,
  enabled: true,
}

describe('gateway handler', () => {
  it('redirects unauthenticated requests to /login', { timeout: 60_000 }, async () => {
    const { ctx, port } = await bootServer()
    const store = new SessionStore(3600)
    const handler = createGatewayHandler(ctx, config, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    const res = await request(port, '/')
    expect(res.status).toBe(302)
    expect(res.headers.get('location')).toBe('/login')
  })

  it('serves static files when authenticated', { timeout: 60_000 }, async () => {
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', true)
    const cfg = { ...config, distIndex }
    const handler = createGatewayHandler(ctx, cfg, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    const res = await request(port, '/', {
      headers: { Cookie: `dsh_session=${session.token}` },
    })
    expect(res.status).toBe(200)
    expect(res.body).toContain('shell')
  })

  it('redirects to /login when cookie is invalid', { timeout: 60_000 }, async () => {
    const { ctx, port } = await bootServer()
    const store = new SessionStore(3600)
    const handler = createGatewayHandler(ctx, config, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    const res = await request(port, '/', {
      headers: { Cookie: 'dsh_session=invalidtoken' },
    })
    expect(res.status).toBe(302)
    expect(res.headers.get('location')).toBe('/login')
  })

  it('returns 404 for unknown paths when authenticated (hash-routed shell)', { timeout: 60_000 }, async () => {
    // Harness 0.1.1-rc.1 removed frontend-static's SPA fallback: the web shell
    // is hash-routed and only '/' and the configured index path serve HTML,
    // every miss is a plain 404. The gateway delegates to serveStatic and
    // inherits the same semantics.
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', true)
    const cfg = { ...config, distIndex }
    const handler = createGatewayHandler(ctx, cfg, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    const res = await request(port, '/some/spa/route', {
      headers: { Cookie: `dsh_session=${session.token}` },
    })
    expect(res.status).toBe(404)
  })

  it('renders the structured index injection table (boot manifest)', { timeout: 60_000 }, async () => {
    // Regression for harness 0.1.1-rc.1: the boot manifest (the
    // window.__ModuleLoader__ queue facade and window.__DSH_BOOT__) moved from
    // raw tapIndex transforms into the structured injection table, rendered
    // only by webServer.renderIndex. A gateway that still calls
    // applyIndexTaps alone serves an index with no module loader and the shell
    // fails with "web boot: window.__ModuleLoader__ bootstrap facade is
    // missing". The gateway must render through whichever pipeline exists.
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><head></head><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', true)
    const cfg = { ...config, distIndex }
    const handler = createGatewayHandler(ctx, cfg, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    ctx.on('webserver/index-inject', (table) => {
      table.push({ kind: 'script', placement: 'head', text: 'window.__ModuleLoader__ = { marker: true }' })
      table.push({ kind: 'global', name: '__DSH_BOOT__', value: { marker: true } })
    })
    const res = await request(port, '/', {
      headers: { Cookie: `dsh_session=${session.token}` },
    })
    expect(res.status).toBe(200)
    expect(res.body).toContain('window.__ModuleLoader__ = { marker: true }')
    expect(res.body).toContain('globalThis["__DSH_BOOT__"]')
  })

  it('serves the shell dist verbatim apart from the framework boot manifest', { timeout: 60_000 }, async () => {
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', true)
    const cfg = { ...config, distIndex }
    const handler = createGatewayHandler(ctx, cfg, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    const res = await request(port, '/', {
      headers: { Cookie: `dsh_session=${session.token}` },
    })
    expect(res.status).toBe(200)
    // dsh-login adds no DOM of its own; the served index is the shell's body
    // plus whatever the framework's renderIndex boot-manifest injects (the
    // sibling "renders structured injection" test pins that pipeline).
    expect(res.body).toContain('shell')
    expect(res.body).toContain('<html')
  })

  it.each([true, false])('supplies the owner principal to index injections (isAdmin=%s)', async (isAdmin) => {
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><head></head><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', isAdmin)
    const handler = createGatewayHandler(ctx, { ...config, distIndex, uiRoleGate: true }, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    const principals: unknown[] = []
    ctx.on('webserver/index-inject', (table, peer) => {
      // DSH 0.2.2's remote-access listener reads peer.principal here.
      // Omitting the peer makes authenticated index requests return 400.
      principals.push(peer.principal)
      table.push({ kind: 'global', name: '__DSH_REMOTE_ACCESS__', value: { kind: peer.principal.kind } })
    })

    const anonymous = await request(port, '/')
    expect(anonymous.status).toBe(302)
    expect(anonymous.headers.get('location')).toBe('/login')
    expect(principals).toEqual([])

    for (const path of ['/', '/index.html']) {
      const res = await request(port, path, {
        headers: { Cookie: `dsh_session=${session.token}` },
      })
      expect(res.status).toBe(200)
      expect(res.body).toContain('shell')
      expect(res.body).toContain('globalThis["__DSH_REMOTE_ACCESS__"]')
      expect(res.body).toContain('"kind":"owner"')
    }
    expect(principals).toEqual([{ kind: 'owner' }, { kind: 'owner' }])
  })
})

/**
 * The upstream Connection service dsh-login's index handshake forwards to.
 * The core dsh-client-connection provides HostConnectionService: the real
 * BrowserAuth lives in its `browserAuth` field, whose `authorizeIndex` only
 * mints the authority-bound browser cookie during the `GET /?token=`
 * exchange and answers every cookie-less request with its plain-text 401.
 */
describe('gateway authorizeIndex: core browser-auth handshake (issue #3)', () => {
  interface FakeConnectionOptions {
    /** Whether the core browser cookie is present and valid on requests. */
    coreCookie?: boolean
    /** The process launch token exposed by browserAuth ('' = unusable). */
    launchToken?: string
    /** Collector for the `secure` argument each isAuthenticated probe saw. */
    probeSecure?: Array<boolean | undefined>
  }

  /**
   * Provide a fake upstream `connection` service that mirrors the core
   * decision shape: the token exchange mints a cookie and 303s to clean
   * `./`, a valid cookie admits the index, everything else is the same
   * plain-text 401 the real BrowserAuth writes.
   */
  function provideFakeConnection(ctx: Context, options: FakeConnectionOptions): void {
    ctx.provide('connection', {
      browserAuth: {
        launchToken: options.launchToken,
        isAuthenticated: (_request, secure) => {
          options.probeSecure?.push(secure)
          return options.coreCookie === true
        },
      },
      authorizeIndex(req: IncomingMessage, res: ServerResponse): boolean {
        const url = new URL(req.url ?? '/', 'http://dsh.invalid')
        if (url.searchParams.getAll('token').length > 0) {
          res.writeHead(303, { location: './', 'set-cookie': 'dsh.browser=core-minted' })
          res.end()
          return false
        }
        if (options.coreCookie === true) return true
        res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
        res.end('dsh web authentication required; reopen the URL printed by dsh web.\n')
        return false
      },
    })
  }

  /** Boot the gateway over a real webserver with a dist shell and a session. */
  async function bootGateway(fake: FakeConnectionOptions): Promise<{ ctx: Context; port: number; token: string }> {
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', true)
    const handler = createGatewayHandler(ctx, { ...config, distIndex }, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    provideFakeConnection(ctx, fake)
    return { ctx, port, token: session.token }
  }

  it('bootstraps a logged-in fresh device via a server-side exchange (issue #10)', { timeout: 60_000 }, async () => {
    // Fresh device: valid dsh_session, no core browser cookie, no token in
    // the URL. The core answers a bare index forward with its plain-text 401
    // ("dsh web authentication required"), so the gateway must run the
    // launch-token exchange itself. Issue #10: it must do so SERVER-SIDE —
    // the old 302 bounce to /?token=<launchToken> handed the process launch
    // token (which /connect exchanges for an owner-principal API credential)
    // to the remote client. The index is now served directly with the minted
    // cookie replayed onto it: no redirect, no token anywhere on the wire.
    const { port, token } = await bootGateway({ coreCookie: false, launchToken: 'test-launch-token' })
    const res = await request(port, '/', { headers: { Cookie: `dsh_session=${token}` } })
    expect(res.status).toBe(200)
    expect(res.body).toContain('shell')
    expect(res.headers.get('set-cookie')).toContain('dsh.browser=core-minted')
    expect(res.headers.get('location')).toBeNull()
    expect(res.body).not.toContain('test-launch-token')
  })

  it('lets the forwarded token exchange mint the core cookie', { timeout: 60_000 }, async () => {
    // A request that already carries the token reaches the core directly:
    // the exchange mints the authority-bound cookie and 303s to clean `./`.
    // This is the out-of-band console-URL path, unchanged by issue #10.
    const { port, token } = await bootGateway({ coreCookie: false, launchToken: 'test-launch-token' })
    const res = await request(port, '/?token=test-launch-token', { headers: { Cookie: `dsh_session=${token}` } })
    expect(res.status).toBe(303)
    expect(res.headers.get('location')).toBe('./')
    expect(res.headers.get('set-cookie')).toContain('dsh.browser=core-minted')
  })

  it('serves the index directly when the core browser cookie is valid', { timeout: 60_000 }, async () => {
    // Devices that already hold a valid core cookie keep the direct serve —
    // no redirect may be injected on their path.
    const { port, token } = await bootGateway({ coreCookie: true, launchToken: 'test-launch-token' })
    const res = await request(port, '/', { headers: { Cookie: `dsh_session=${token}` } })
    expect(res.status).toBe(200)
    expect(res.body).toContain('shell')
  })

  it('still forwards to a connection without the browserAuth wrapper', { timeout: 60_000 }, async () => {
    // Alternative/test connection services expose authorizeIndex directly
    // with no browserAuth field: they keep the plain forward semantics.
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', true)
    const handler = createGatewayHandler(ctx, { ...config, distIndex }, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    ctx.provide('connection', { authorizeIndex: () => true })
    const res = await request(port, '/', { headers: { Cookie: `dsh_session=${session.token}` } })
    expect(res.status).toBe(200)
    expect(res.body).toContain('shell')
  })

  it('lets the core answer when no usable launch token is available', { timeout: 60_000 }, async () => {
    // Without a launch token dsh-login cannot run the exchange; the core's
    // own 401 must pass through untouched instead of a redirect to /?token=.
    const { port, token } = await bootGateway({ coreCookie: false, launchToken: '' })
    const res = await request(port, '/', { headers: { Cookie: `dsh_session=${token}` } })
    expect(res.status).toBe(401)
    expect(res.body).toContain('dsh web authentication required')
  })

  it('falls back to the core 401 when the server-side exchange mints nothing (issue #10)', { timeout: 60_000 }, async () => {
    // If the captured exchange produces no cookie (e.g. no usable Host
    // authority), the gateway must fall through to the connection's own
    // answer — never back to a redirect that would hand out the token.
    const { ctx, port } = await bootServer()
    const dist = join(root!, 'dist')
    await mkdir(dist, { recursive: true })
    const distIndex = join(dist, 'index.html')
    await writeFile(distIndex, '<html><body>shell</body></html>')
    const store = new SessionStore(3600)
    const session = store.create('alice', true)
    const handler = createGatewayHandler(ctx, { ...config, distIndex }, store)
    ctx.effect(() => ctx.webServer.registerFallback({ handler, auth: 'anonymous' }), 'gateway')
    ctx.provide('connection', {
      browserAuth: {
        launchToken: 'test-launch-token',
        isAuthenticated: () => false,
      },
      authorizeIndex(_req: IncomingMessage, res: ServerResponse): boolean {
        res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
        res.end('dsh web authentication required; reopen the URL printed by dsh web.\n')
        return false
      },
    })
    const res = await request(port, '/', { headers: { Cookie: `dsh_session=${session.token}` } })
    expect(res.status).toBe(401)
    expect(res.body).toContain('dsh web authentication required')
    expect(res.headers.get('location')).toBeNull()
    expect(res.body).not.toContain('test-launch-token')
  })

  it('probes the core cookie with the listener protocol (native-TLS authority match)', { timeout: 60_000 }, async () => {
    // Native-TLS listeners mint cookies bound to the https-origin audience;
    // probing with secure=false never matches them (0.3.8 bounced forever
    // there). The probe must receive the listener's own protocol decision —
    // the same derivation the core's service wrapper applies.
    const probeSecure: Array<boolean | undefined> = []
    const { ctx, port, token } = await bootGateway({ coreCookie: false, launchToken: 'test-launch-token', probeSecure })
    Object.defineProperty(ctx.webServer, 'protocol', { value: 'https:' })
    const res = await request(port, '/', { headers: { Cookie: `dsh_session=${token}` } })
    expect(res.status).toBe(200)
    expect(res.body).toContain('shell')
    expect(res.headers.get('set-cookie')).toContain('dsh.browser=core-minted')
    expect(probeSecure.length).toBeGreaterThan(0)
    expect(probeSecure.every((secure) => secure === true)).toBe(true)
  })
})
