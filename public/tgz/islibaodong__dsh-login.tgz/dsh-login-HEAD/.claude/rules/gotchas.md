# Gotchas & Workarounds

## Known Quirks
> **2026-10-02 staleness sweep:** the first four bullets below described the
> **pre-option-A** design, where dsh-login took over the `/api` carrier and the
> shipped `connection` row was disabled. Under option A (DSH ≥ 0.1.5-alpha.1)
> the `connection` row is **ENABLED** (`cordis.patch.yml` disables only
> `web-runtime`), `src/connection.ts` / `src/connection.client.ts` are gone, and
> the `/api` takeover bullets no longer apply. Read them as history only.
- `isUserAllowed`/`USER_ALLOWED` keys must match RpcMethodMap spellings
  EXACTLY (e.g. `session.list` singular); a typo silently 403s a legit method.
  Keep in sync with the `createUserProxy` decorator.
- **DSH ≥ 0.2.3-alpha.1 admission rules:** every `webServer.register(...)` seat
  now defaults to `auth: 'required'` and answers **503 before the plugin's own
  logic runs**; dsh-login's public seats (`/login`, `/api/auth/*`, `/logout`,
  admin routes) and its fallback must declare `auth: 'anonymous'` (or an `auth`
  rule). The index fallback only receives a `PeerScope` in the object form
  `{handler, auth}` — a bare function handler gets none on that line.
- **Cordis inject guards service property access:** inside
  `ctx.inject(['connection'], …)`, reading `connection.authentication` throws
  `cannot get property "connection.authentication" without inject`; the throw is
  swallowed by the effect and the provider never registers (symptom: blanket 401
  on `/api` while `/api/auth/*` works). Declare both services:
  `ctx.inject(['connection', 'connection.authentication'], …)`. Also, a
  `console.log` argument that touches an undeclared service throws **before** the
  log line prints — misleading "callback never fired" diagnostics.
- **0.2.3-alpha.1 is not on the npmmirror default registry:** `npm install` fails
  with `ETARGET` for `@deepseek-ai/dsh-client-modules`; use
  `--registry=https://registry.npmjs.org`. The Typert artifacts needed for the
  wire dump are generated (`scripts/generate-typert.ts`) and are **not** in npm
  tarballs — always dump from a built checkout/worktree.
- **The 0.2.3-alpha.1 npm channel cannot boot (upstream):** `@deepseek-ai/dsh`
  installs `@deepseek-ai/cordis-plugin-loader@1.1.0`, whose `lib/index.js` does
  not export `EntryValidationError`, `formatIssues`, `relocate` or
  `validateOptions`, yet `dsh-app-boot@0.2.3-alpha.1` imports all four →
  `SyntaxError: The requested module '@deepseek-ai/cordis-plugin-loader' does not
  provide an export named 'EntryValidationError'` at startup, before any profile
  row loads. The newer loader exists only as `vendor/loader` source in the
  monorepo. So alpha.1 can only be exercised via `pnpm start:web` in the
  checkout; do not claim a live alpha.1 boot from an npm install.
- **Never capability-probe `connection.createPeer` for the rc.5/alpha.1 split:**
  rc.5 already exposed `createPeer`, so gating "skip the legacy cookie mint" on
  it drops the rc.5 `dsh-auth` cookie → every authenticated `/api` call 401s.
  Probe the **registry** instead (`connection.authentication`), with a guarded
  read (cordis throws on undeclared service properties; catch that as "absent").

- Disabled rows drop their browser halves from the boot graph: with the
  shipped `connection` row disabled, the GUI's wire client must come from this
  package's own `dsh.client` declaration + built `dist/client.js`.
- The disabled shipped `connection` row also stops providing the `connection`
  service — without it the Typert Remote gateway never registers its shared
  `/api` interceptor and every installed UI plugin's host RPC
  (`POST /api/<namespace>/<method>`) dies after login. The takeover
  re-provides it via `HostConnectionService`; two-segment endpoints dispatch
  through `createSharedFetchHandler` (native, no per-user wrap — cookie auth
  still applies; unclaimed `a/b` shapes 404).
- `frameVisible` forwards global `host/remote-event` pushes
  (commands/change, llm/adapters-updated, …) to ordinary users — UI-plugin
  client caches freeze without them — but keeps `cordis/*` lifecycle frames
  admin-only.
- WebServer rejects duplicate `/api` prefix registrations (throws at boot):
  the shipped `connection` row must stay disabled while dsh-login's takeover
  is active.
- vitest resolves `@deepseek-ai/*` at RUNTIME from `node_modules` (real npm
  tarballs, devDeps pinned to `^0.2.2-rc.5` since 2026-11-19, before that
  `^0.2.2-rc.4` since 2026-11-18, before that
  `^0.2.2-rc.3` since 2026-11-14, before that
  `^0.2.2-rc.2` since 2026-11-13, before that
  `^0.2.2-rc.1` since 2026-11-05, before that
  `^0.2.2-alpha.3` since 2026-11-04, before that
  `^0.2.2-alpha.2` since 2026-10-28, before that
  `^0.2.1-rc.3` since 2026-10-24, before that
  `^0.2.1-rc.2` since 2026-10-18; before that
  `^0.2.1-alpha.4`, and `^0.1.7-alpha.2` before 2026-09-23) — there are
  NO vitest aliases. Only tsconfig `paths` map `@deepseek-ai/*` to the harness
  checkout (`E:/code/deepseek-harness`) for TYPES. After a DSH upgrade:
  `npm i -D @deepseek-ai/<pkgs>@<tag>` — do not assume node_modules matches
  the harness checkout, and beware an `npm ci`/`install` resetting hand-set
  versions to the lockfile (that regressed the tree to 0.1.1-rc.2 once, whose
  5-arg `serveStatic` mis-slotted the `authorizeIndex` callback → gateway
  failures). On the 0.2.2 line the static fallback no longer imports the
  package at all: upstream PR #6901 deleted the `serveStatic` export from
  `@deepseek-ai/dsh-host-frontend-static` and dsh-login self-hosts it
  (`src/serve-static.ts`), so the old 5-arg slotting trap is dead there.
- Wire-surface fixture regeneration needs a BUILT checkout: typert
  `lib/typert.remote-client.d.ts` files are generated by the harness build
  (`pnpm run typecheck` = `tsx scripts/build.ts --scope typecheck` in the dsh
  repo) and are NOT shipped in npm tarballs — dumping from an unpacked
  tarball yields 0 methods. Use the detached worktree
  `E:\code\deepseek-harness-wt-022a3` (@ dsh-v0.2.2-alpha.3; before that
  `wt-022a2` @ dsh-v0.2.2-alpha.2, cleaned post-0.3.10) or build the
  main checkout. NOTE (2026-11-05): rc.1 needed NO new worktree — its range
  is package.json-only, so the alpha.3-built worktree remains the newest
  valid dump source (registries byte-identical). `tests/wire-surface.spec.ts` live cross-check is
  generation-guarded (strict comparison only when live registry size ==
  fixture size) — an older checkout no longer false-positives.
- Worktree CLEANUP trap: `git worktree remove` can fail on ONE file —
  `@koromix+koffi-win32-x64`'s `koffi.node` (loaded by the koromix typert
  toolchain during `pnpm run typecheck`) intermittently returns raw Win32
  "Access denied" on DELETE (and sometimes even on OPEN), while RENAME of
  the same file and deleting sibling files work; no module/handle holder is
  findable (happened twice: post-0.3.8 and post-0.3.10). Fix: rename the
  locked file's ancestor directory out of the worktree into
  `E:\koffi-locked-remnant\` (e.g. `wt-022a3-node_modules`), then delete the
  rest normally — renaming an ancestor only touches that dir entry, not the
  locked file. Do NOT try to delete `E:\koffi-locked-remnant` contents; the
  file there is the same un-deletable hardlink (links: pnpm store
  `E:\dev-cache\pnpm-store\v11\files\…`, main checkout node_modules, and
  each quarantine copy).
- Upgrading to 0.1.7+ hits TWO ERESOLVE traps (2026-09-23): (1) the plugin's
  OWN peerDependencies must gain the new tuple branch BEFORE installing
  (`0.1.7-alpha.2` does not satisfy `>=0.1.6-alpha.1` — node-semver prerelease
  rule); (2) `dsh-client-connection` now exact-pins NEW peers
  `@deepseek-ai/dsh-scope`, `dsh-session`, `dsh-brand` — add them to the
  install list. When npm's incremental resolution wedges on the old tree,
  delete node_modules + lockfile and reinstall fresh. Also `npm
  install-scripts` may warn that esbuild's postinstall is not
  allowScripts-covered (harmless so far — build works).
- `npm view <pkg> dist-tags --json` returns the tags object at the TOP LEVEL
  (not nested under a `dist-tags` key): read `$d.alpha`, not
  `$d.'dist-tags'.alpha` (2026-09-21 false-alarm re-run). BUT requesting two
  fields (`npm view <pkg> dist-tags time --json`) NESTS them — read
  `$d.'dist-tags'.alpha` / `$d.time.<ver>` in that shape (2026-09-24).
- DSH ≥ 0.1.7-rc.1 runs a BOOT-TIME plugin compatibility admission (app-boot
  PR #5061): every bundle's/row's `@deepseek-ai/dsh*` peerDependencies is
  tested with `semver.satisfies(runtime, range, { includePrerelease: true })`
  — MORE lenient than npm's install-time tuple rule. Incompatible bundles are
  stderr-reported and SKIPPED, so dsh-login's patch (web-runtime disable)
  never applies and the GUI boots WITHOUT the login wall (fail-open). After
  any DSH upgrade, verify dsh-login actually loaded (login page appears).
  Exemption: profile `compatibility.json` + `dsh plugin allow-version
  --accept-risk` (exact `name@version` → exact runtime versions).
- `dist/client.js` must be regenerated (`npm run build:client`) after
  upgrading `@deepseek-ai/dsh-client-connection`; the script re-stamps the
  module-loader id banner and fails loudly if the banner pattern is missing.
  alpha.3 note: `@deepseek-ai/dsh-client-connection` now ships dual exports
  (`client.node.js`/`client.browser.js`); the logical `/plugins/<pkg>/client.js`
  URL is unchanged and dsh-login's single-file `dist/client.js` flow is
  unaffected (verified 2026-10-15). rc.2 note (2026-10-18): the
  `dsh-client-connection` client half is unchanged alpha.4→rc.2, so a rebuild
  reproduces `dist/*` byte-identical — no re-stamp churn. rc.3 note
  (2026-10-24): unchanged again rc.2→rc.3 (`dist/client.js` byte-identical;
  only `dist/index.js` re-stamps `WIRE_SURFACE_DSH_VERSION`). alpha.3 note
  (2026-11-04): connection/modules/ui-slots are package.json-bump-only vs
  alpha.2, so the rebuild is byte-identical again (`dist/client.js` 37134
  chars, banner-only re-stamp); only `dist/index.js`/`.map` carry the new
  204-method buckets. rc.1 note (2026-11-05): same again alpha.3→rc.1
  (`dist/client.js` byte-identical, SHA-256 verified; `dist/index.js`
  stamp-only).
- Incremental `npm install` on a STALE lockfile tree can ERESOLVE-wedge even
  when package.json is consistent (2026-11-05, alpha.3→rc.1: old
  `cordis-plugin-group` peer from the alpha.3 `dsh-app-boot` chain blocked
  resolution). Fix: delete `node_modules` + `package-lock.json` and clean
  install (resolved 111 packages in 10s). Don't burn time debugging peer
  math first — if the tree predates the devDep retarget, just clean-install.
- **`verify:imports` tsx strip-only failure is RESOLVED (2026-11-05):** the
  pre-existing environment issue recorded since 0.3.9 (node v24.20.0 +
  tsx failing 9 src files with a strip-only parameter-property error) no
  longer reproduces — `npm run verify:imports` exits 0 after the rc.1 clean
  install. If it resurfaces, treat as environment, not regression.
- **rc.2 moved the vendored packages to STABLE** (2026-10-18): pin cordis
  `~4.0.5`, schemastery `~3.18.5`, include `~1.0.10`, loader `~1.0.6` — the
  npm `dsh-0-2-1-alpha-3` vendor dist-tags still point at the alpha vintages
  and are the wrong pins now. REVERSED on the 0.2.2 line: alpha.2 re-issued
  vendor ALPHAS (cordis 4.0.6-alpha.1 etc.) and alpha.3 re-issued them again
  (cordis `4.0.6-alpha.2`, schemastery `3.18.6-alpha.2`, include
  `1.0.11-alpha.2`, loader `1.0.7-alpha.2` — 0.3.9/0.3.10 pin those), so the
  "STABLE pin" guidance applies only to the 0.2.1 line. Also at rc.2
  `dsh-client-connection` peers only
  `cordis ~4.0.5` + `dsh-scope 0.2.1-rc.2` (no longer direct `dsh-session` /
  `dsh-brand` peers), so the "exact-pins NEW peers" ERESOLVE trap below has a
  different shape than at 0.1.7.
- **webApp provider duty (alpha.3+)**: the web-app bundle's new enabled
  `harness-dev-context` row injects `['systemPrompt','sessionProjections',
  'webApp']` and reads `ctx.webApp.getAdvertisedUrl()` at context-assembly
  time; the disabled web-runtime row was the sole upstream `webApp` provider.
  dsh-login's `provideWebRuntime` therefore provides `webApp` itself (see
  modules.md). If a future upstream adds another webApp-providing row, a
  duplicate-provide conflict would fail the boot — re-check composition after
  web-app bundle changes.
- Testing a cordis ctx with a fake: `provide(name, value)` must ALSO set
  `ctx[name] = value` (services are read as properties, not only via `get()`);
  a fake that records into a separate target object passes `get()` but breaks
  any code reading `ctx.webApp` style properties (2026-10-15, five red tests
  from exactly this).
- Ownership sidecar persistence is best-effort; the in-memory map is
  authoritative and a corrupt file starts empty (fail-closed → admin-only
  until sessions are re-attributed).
- Legacy single-password flow is dead: the `password` ref stays configured but
  authenticates nobody (it only namespaces `${password}_USERS`).
- `tests/runner.mjs` / `integration-runner.mjs` predate multi-user; the
  `.spec.ts` files are canonical.

## Levers / Opportunities
- **Whole-UI role gating is implementable in-plugin (verified 2026-10-02, not
  built).** The gateway renders the index itself (`webServer.renderIndex` in
  `src/gateway.ts`), and the client module roster travels in that HTML as
  `window.__DSH_BOOT__` (`bootInjections()` at
  `packages/client/modules/src/index.ts:552` emits
  `{kind:'global', name:'__DSH_BOOT__', value: graph}`). The page activates
  exactly that roster: `ClientEntries.reconcile()` creates one Loader entry per
  `manifest.modules` row and **removes** managed entries absent from
  `manifest.plugins`. So filtering the graph per role before serving the index
  decides which bundles ever mount — no upstream change needed. Role data
  already exists (`deriveCapabilities(user)` in `src/capabilities.ts`).
  Constraints: keep the bootstrap batch + the `dsh-client-modules` entry (else
  "bootstrap facade is missing"); keep the shape valid (`parseBootManifest`
  requires string id/url/rev, duplicate batch URLs throw); granularity is
  **per package**; presentation-only (the `/api` allow-list is the real
  boundary); dev-mode `client-hmr` is always mounted but idle, yet a dev rebuild
  pushes `{type:'graph'}` and re-syncs the full roster. See
  `docs/adapt-dsh-0.2.0-rc.2.md` §6.

## Do Not Touch
- `package-lock.json` — auto-generated by npm
- `dist/client.js` — generated by `scripts/build-client.mjs`, not hand-edited

## Known Bugs / TODOs
- [ ] Review codebase for existing TODOs

## Environment Notes
- No .env.example found. `DSH_HOME` (data dir resolution) and
  `DSH_HARNESS_CHECKOUT` (tests/client build) are the relevant env vars.
- **npm publish auth (2026-10-15):** the `//registry.npmjs.org/:_authToken`
  line in `~/.npmrc` (untouched since 09-30) is DEAD on the official
  registry (`whoami` → 401; publish PUT → 404-masked auth failure; OTP
  retries change nothing — the failing layer is auth, not OTP). The working
  publish token lives in `E:\code\dsh-login\.env` (git-ignored, verified
  untracked) as `NPM_ACCESS_TOKENS`; publish via a TEMP npmrc
  (`//registry.npmjs.org/:_authToken=<token>` → `npm publish --access
  public --registry=https://registry.npmjs.org --userconfig .npmrc.publish`)
  and DELETE the temp file immediately after. Post-publish registry reads
  may lag (`dist-tags.latest` still shows the old version right after a
  successful publish — observed ~2 min on 2026-11-17 and ~4 min on
  2026-11-18, so poll the no-cache packument several times, never conclude
  a failure or re-publish from the first negative read). Never
  commit, paste, or log the token.
- The `E:\code\deepseek-harness` checkout working tree can be STALE relative
  to releases (2026-10-15: `dev` still at the alpha.2 merge `d743267388`
  while `origin/master` = `571902028a`, 868 commits ahead; tag
  `dsh-v0.2.1-alpha.3`). For release-state analysis grep the TAG
  (`git grep <pat> dsh-v<ver> -- packages/`), never the tree; or make a
  detached worktree (`git worktree add E:\code\deepseek-harness-wt-alpha3
  dsh-v0.2.1-alpha.3`) when you need full files. Test/build runtime truth is
  `node_modules`.
- `git fetch` against github.com can fail with "TLS connect error:
  unexpected eof while reading" (2026-09-19); retrying with
  `git -c http.version=HTTP/1.1 fetch --tags origin` succeeded. Treat a bare
  tag list BEFORE a successful fetch as stale data, not release evidence.
- **Dev-tree live boot (2026-11-14):** a fresh `DSH_HOME` profile boots on the
  DEFAULT port 3080 — EADDRINUSE while the running GUI holds it; pass
  `--port 0` (OS-picked). The default-profile temp boot prints the URL **with
  a boot token**, but once dsh-login is mounted the URL has NO token (the
  login wall owns the entry — that difference is itself the "wall is mounted"
  signal). To mount dsh-login in a temp profile: `npm pack`, `npm install
  <tgz>` inside `<DSH_HOME>\profiles\web`, append `"@islibaodong/dsh-login"`
  to `dsh.profile.bundles` in the profile `package.json` (rewrite BOM-free,
  UTF-8 no-BOM), then reboot — a running server does not hot-load bundles.
- **PowerShell 5.1 + curl.exe JSON (2026-11-14):** single-quoted JSON bodies
  lose their inner double quotes through PowerShell's native argument
  parsing — the server answers 400 `{"error":"bad request"}` (a JSON parse
  failure, not a payload problem). Pass payloads with `--data "@file"`
  (ASCII, `-NoNewline`). Same class as the npm ENEEDAUTH lesson: each fresh
  shell re-parses arguments; never assume quoting survives.
- **npm dist-tag propagation (2026-11-14, confirmed twice):** right after a
  successful `npm publish` the packument CDN can serve a stale copy for
  several minutes — `npm view ... dist-tags` showed 0.3.13 while 0.3.14 was
  already accepted (`+ @islibaodong/dsh-login@0.3.14` printed). Verify with a
  no-cache HTTP GET of the packument
  (`Invoke-WebRequest https://registry.npmjs.org/@islibaodong%2Fdsh-login`),
  not by polling `npm view` through the same CDN.
- `scripts/dump-wire-surface.mjs` **writes** `tests/fixtures/wire-surface.json`
  when run from the CLI (it exists to regenerate the vendored snapshot), so it
  is the wrong tool for the pre-release drift radar — running it with a dev
  checkout that is 811 commits past the tag silently replaces the pinned 204
  snapshot with the WIP 210 and dirties the tree (2026-11-11: had to
  `git checkout -- tests/fixtures/wire-surface.json`). Probe through its
  exported `enumerateWireSurface(checkout)` instead and diff against the
  fixture in memory:
  `node -e "import('./scripts/dump-wire-surface.mjs').then(m=>{const live=m.enumerateWireSurface('E:/code/deepseek-harness');const snap=JSON.parse(require('fs').readFileSync('tests/fixtures/wire-surface.json','utf8')).methods;…})"`.
  Note `tests/wire-surface.spec.ts` deliberately tolerates a size mismatch
  (returns early), so a dev checkout never reds the suite.
- **DSH session sandbox vs npm registry reads (2026-11-15):** under the dsh
  harness session sandbox (workspace-write on this repo), `npm view` fails with
  EPERM — npm writes its request cache to the global `E:\dev-cache\npm-cache`
  (outside the workspace), so even a read-only registry query dies
  ("Invalid response body ... EPERM ... `_cacache\tmp`"), and its log write
  fails the same way. `curl.exe` against the registry failed the same day for a
  different reason (connection closed mid-body). Working pattern: plain
  `node -e "fetch('https://registry.npmmirror.com/<pkg>',{headers:{Accept:'application/vnd.npm.install-v1+json'}})"`
  — node's fetch reaches the mirror, `dist-tags` parse from the abbreviated
  packument, zero local writes. (Redirecting npm's `--cache` into the workspace
  would also work.)
- **git fetch vs the same sandbox (2026-11-15):** `git -C
  E:\code\deepseek-harness fetch` fails with "error: cannot open
  '.git/FETCH_HEAD': Permission denied" — the harness checkout is outside the
  session workspace, so the FETCH_HEAD write is denied. Remote authority
  without any local write: `git ls-remote origin` (live tags + branch tips; the
  same standing convention as the 11-11 watch). Greps at a remote tip still
  work once its objects were fetched in a previous unsandboxed session — e.g.
  master tip `39163dd30f` was fetched on 11-14, so `git grep <pat> 39163dd30f`
  resolves locally; a NEW tip needs a sandbox escalation of the fetch (or a
  session with write access to that checkout) before tip-level greps can run.
  Same boundary blocks `git push` to this repo (msys2 ssh fatal:
  `NtCreateDirectoryObject(\BaseNamedObjects\msys-2.0S5-…) 0xC0000022` — access
  denied before ssh even starts). Sanctioned path: commit first, then a one-shot
  `sandbox_permissions` escalation of the exact push command; on an unattended
  scheduled run the approval may sit unanswered for hours (11-15 watch: approval
  landed 11-16 08:55 +0800, ~21 h later, push then succeeded).
- **vitest/tsx cannot run under the session sandbox (2026-11-15):** both
  `npm test` (vitest worker processes) and `node --import tsx/esm
  tests/runner.mjs` (tsx transform workers) die with EPERM on `spawn` — the
  sandbox forbids child spawns with piped stdio, and both toolchains pipe
  worker output. Direct spawns are fine (node -e, git, curl all work). Docs-only
  watch days: skip the suite re-run and lean on the last green baseline from an
  unsandboxed session (11-14: 22 files / 298 tests green on `8546bea`); a
  release day needs a session whose sandbox permits piped spawns (or
  escalation) before publishing anything.
