# Gotchas & Workarounds

## Known Quirks
> **2026-10-02 staleness sweep:** the first four bullets below described the
> **pre-option-A** design, where dsh-login took over the `/api` carrier and the
> shipped `connection` row was disabled. Under option A (DSH ≥ 0.1.5-alpha.1)
> the `connection` row is **ENABLED** (`cordis.patch.yml` disables only
> `web-runtime`), `src/connection.ts` / `src/connection.client.ts` are gone, and
> the `/api` takeover bullets no longer apply. Read them as history only.
- `isUserAllowed`/`USER_ALLOWED` keys must match RpcMethodMap spellings
  EXACTLY (e.g. `session.list` singular); a typo silently 403s a legit method.
  Keep in sync with the `createUserProxy` decorator.
- Disabled rows drop their browser halves from the boot graph: with the
  shipped `connection` row disabled, the GUI's wire client must come from this
  package's own `dsh.client` declaration + built `dist/client.js`.
- The disabled shipped `connection` row also stops providing the `connection`
  service — without it the Typert Remote gateway never registers its shared
  `/api` interceptor and every installed UI plugin's host RPC
  (`POST /api/<namespace>/<method>`) dies after login. The takeover
  re-provides it via `HostConnectionService`; two-segment endpoints dispatch
  through `createSharedFetchHandler` (native, no per-user wrap — cookie auth
  still applies; unclaimed `a/b` shapes 404).
- `frameVisible` forwards global `host/remote-event` pushes
  (commands/change, llm/adapters-updated, …) to ordinary users — UI-plugin
  client caches freeze without them — but keeps `cordis/*` lifecycle frames
  admin-only.
- WebServer rejects duplicate `/api` prefix registrations (throws at boot):
  the shipped `connection` row must stay disabled while dsh-login's takeover
  is active.
- vitest resolves `@deepseek-ai/*` at RUNTIME from `node_modules` (real npm
  tarballs, devDeps pinned to `^0.2.1-rc.3` since 2026-10-24, before that
  `^0.2.1-rc.2` since 2026-10-18; before that
  `^0.2.1-alpha.4`, and `^0.1.7-alpha.2` before 2026-09-23) — there are
  NO vitest aliases. Only tsconfig `paths` map `@deepseek-ai/*` to the harness
  checkout (`E:/code/deepseek-harness`) for TYPES. After a DSH upgrade:
  `npm i -D @deepseek-ai/<pkgs>@<tag>` — do not assume node_modules matches
  the harness checkout, and beware an `npm ci`/`install` resetting hand-set
  versions to the lockfile (that regressed the tree to 0.1.1-rc.2 once, whose
  5-arg `serveStatic` mis-slotted the `authorizeIndex` callback → gateway
  failures).
- Upgrading to 0.1.7+ hits TWO ERESOLVE traps (2026-09-23): (1) the plugin's
  OWN peerDependencies must gain the new tuple branch BEFORE installing
  (`0.1.7-alpha.2` does not satisfy `>=0.1.6-alpha.1` — node-semver prerelease
  rule); (2) `dsh-client-connection` now exact-pins NEW peers
  `@deepseek-ai/dsh-scope`, `dsh-session`, `dsh-brand` — add them to the
  install list. When npm's incremental resolution wedges on the old tree,
  delete node_modules + lockfile and reinstall fresh. Also `npm
  install-scripts` may warn that esbuild's postinstall is not
  allowScripts-covered (harmless so far — build works).
- `npm view <pkg> dist-tags --json` returns the tags object at the TOP LEVEL
  (not nested under a `dist-tags` key): read `$d.alpha`, not
  `$d.'dist-tags'.alpha` (2026-09-21 false-alarm re-run). BUT requesting two
  fields (`npm view <pkg> dist-tags time --json`) NESTS them — read
  `$d.'dist-tags'.alpha` / `$d.time.<ver>` in that shape (2026-09-24).
- DSH ≥ 0.1.7-rc.1 runs a BOOT-TIME plugin compatibility admission (app-boot
  PR #5061): every bundle's/row's `@deepseek-ai/dsh*` peerDependencies is
  tested with `semver.satisfies(runtime, range, { includePrerelease: true })`
  — MORE lenient than npm's install-time tuple rule. Incompatible bundles are
  stderr-reported and SKIPPED, so dsh-login's patch (web-runtime disable)
  never applies and the GUI boots WITHOUT the login wall (fail-open). After
  any DSH upgrade, verify dsh-login actually loaded (login page appears).
  Exemption: profile `compatibility.json` + `dsh plugin allow-version
  --accept-risk` (exact `name@version` → exact runtime versions).
- `dist/client.js` must be regenerated (`npm run build:client`) after
  upgrading `@deepseek-ai/dsh-client-connection`; the script re-stamps the
  module-loader id banner and fails loudly if the banner pattern is missing.
  alpha.3 note: `@deepseek-ai/dsh-client-connection` now ships dual exports
  (`client.node.js`/`client.browser.js`); the logical `/plugins/<pkg>/client.js`
  URL is unchanged and dsh-login's single-file `dist/client.js` flow is
  unaffected (verified 2026-10-15). rc.2 note (2026-10-18): the
  `dsh-client-connection` client half is unchanged alpha.4→rc.2, so a rebuild
  reproduces `dist/*` byte-identical — no re-stamp churn. rc.3 note
  (2026-10-24): unchanged again rc.2→rc.3 (`dist/client.js` byte-identical;
  only `dist/index.js` re-stamps `WIRE_SURFACE_DSH_VERSION`).
- **rc.2 moved the vendored packages to STABLE** (2026-10-18): pin cordis
  `~4.0.5`, schemastery `~3.18.5`, include `~1.0.10`, loader `~1.0.6` — the
  npm `dsh-0-2-1-alpha-3` vendor dist-tags still point at the alpha vintages
  and are the wrong pins now. Also at rc.2 `dsh-client-connection` peers only
  `cordis ~4.0.5` + `dsh-scope 0.2.1-rc.2` (no longer direct `dsh-session` /
  `dsh-brand` peers), so the "exact-pins NEW peers" ERESOLVE trap below has a
  different shape than at 0.1.7.
- **webApp provider duty (alpha.3+)**: the web-app bundle's new enabled
  `harness-dev-context` row injects `['systemPrompt','sessionProjections',
  'webApp']` and reads `ctx.webApp.getAdvertisedUrl()` at context-assembly
  time; the disabled web-runtime row was the sole upstream `webApp` provider.
  dsh-login's `provideWebRuntime` therefore provides `webApp` itself (see
  modules.md). If a future upstream adds another webApp-providing row, a
  duplicate-provide conflict would fail the boot — re-check composition after
  web-app bundle changes.
- Testing a cordis ctx with a fake: `provide(name, value)` must ALSO set
  `ctx[name] = value` (services are read as properties, not only via `get()`);
  a fake that records into a separate target object passes `get()` but breaks
  any code reading `ctx.webApp` style properties (2026-10-15, five red tests
  from exactly this).
- Ownership sidecar persistence is best-effort; the in-memory map is
  authoritative and a corrupt file starts empty (fail-closed → admin-only
  until sessions are re-attributed).
- Legacy single-password flow is dead: the `password` ref stays configured but
  authenticates nobody (it only namespaces `${password}_USERS`).
- `tests/runner.mjs` / `integration-runner.mjs` predate multi-user; the
  `.spec.ts` files are canonical.

## Levers / Opportunities
- **Whole-UI role gating is implementable in-plugin (verified 2026-10-02, not
  built).** The gateway renders the index itself (`webServer.renderIndex` in
  `src/gateway.ts`), and the client module roster travels in that HTML as
  `window.__DSH_BOOT__` (`bootInjections()` at
  `packages/client/modules/src/index.ts:552` emits
  `{kind:'global', name:'__DSH_BOOT__', value: graph}`). The page activates
  exactly that roster: `ClientEntries.reconcile()` creates one Loader entry per
  `manifest.modules` row and **removes** managed entries absent from
  `manifest.plugins`. So filtering the graph per role before serving the index
  decides which bundles ever mount — no upstream change needed. Role data
  already exists (`deriveCapabilities(user)` in `src/capabilities.ts`).
  Constraints: keep the bootstrap batch + the `dsh-client-modules` entry (else
  "bootstrap facade is missing"); keep the shape valid (`parseBootManifest`
  requires string id/url/rev, duplicate batch URLs throw); granularity is
  **per package**; presentation-only (the `/api` allow-list is the real
  boundary); dev-mode `client-hmr` is always mounted but idle, yet a dev rebuild
  pushes `{type:'graph'}` and re-syncs the full roster. See
  `docs/adapt-dsh-0.2.0-rc.2.md` §6.

## Do Not Touch
- `package-lock.json` — auto-generated by npm
- `dist/client.js` — generated by `scripts/build-client.mjs`, not hand-edited

## Known Bugs / TODOs
- [ ] Review codebase for existing TODOs

## Environment Notes
- No .env.example found. `DSH_HOME` (data dir resolution) and
  `DSH_HARNESS_CHECKOUT` (tests/client build) are the relevant env vars.
- **npm publish auth (2026-10-15):** the `//registry.npmjs.org/:_authToken`
  line in `~/.npmrc` (untouched since 09-30) is DEAD on the official
  registry (`whoami` → 401; publish PUT → 404-masked auth failure; OTP
  retries change nothing — the failing layer is auth, not OTP). The working
  publish token lives in `E:\code\dsh-login\.env` (git-ignored, verified
  untracked) as `NPM_ACCESS_TOKENS`; publish via a TEMP npmrc
  (`//registry.npmjs.org/:_authToken=<token>` → `npm publish --access
  public --registry=https://registry.npmjs.org --userconfig .npmrc.publish`)
  and DELETE the temp file immediately after. Post-publish registry reads
  may lag ~2 min (`dist-tags.latest` still shows the old version right
  after a successful publish — wait ~60 s before re-checking). Never
  commit, paste, or log the token.
- The `E:\code\deepseek-harness` checkout working tree can be STALE relative
  to releases (2026-10-15: `dev` still at the alpha.2 merge `d743267388`
  while `origin/master` = `571902028a`, 868 commits ahead; tag
  `dsh-v0.2.1-alpha.3`). For release-state analysis grep the TAG
  (`git grep <pat> dsh-v<ver> -- packages/`), never the tree; or make a
  detached worktree (`git worktree add E:\code\deepseek-harness-wt-alpha3
  dsh-v0.2.1-alpha.3`) when you need full files. Test/build runtime truth is
  `node_modules`.
- `git fetch` against github.com can fail with "TLS connect error:
  unexpected eof while reading" (2026-09-19); retrying with
  `git -c http.version=HTTP/1.1 fetch --tags origin` succeeded. Treat a bare
  tag list BEFORE a successful fetch as stale data, not release evidence.
