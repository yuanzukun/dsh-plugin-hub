## 2026-11-09 — README/README.zh reorganized (removed stale watch banners and duplicated release prose)
- Both READMEs trimmed 334→161 / 307→137 lines: the six timed watch banners, duplicated 0.3.8/0.3.11 release prose, the adaptation-history wall, and the two-browser sign-off narrative are gone; replaced by a compact status block (0.3.12 summary + compatibility table 0.3.6-0.3.12 + upstream multi-user watch).
- Technical sections corrected to the 0.3.12 reality: permission model rewritten around the three seams (bridge wall / dispatch-seam guard automatic / REMOTE guard optional), bucket numbers 204/124/79/1, WS paths /api/events.mux|host → /api/remote.mux, upgrade fenced by the dispatch-seam guard, project structure adds api-bridge-auth.ts + dispatch-guard.ts, tests 22/291, troubleshooting compressed.
- 291 tests green after the edit (README-only change).

## 2026-11-09 (scheduled watch) — no new DSH release; 0.3.12 stays current, no adaptation, no publish
- Scheduled watch (cron `0 12 * * *` Asia/Shanghai; trigger 2026-11-09T04:00:00.016Z / 12:00 +0800).
  Detection (all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: no new objects. Newest tag still `dsh-v0.2.2-rc.1` (no `dsh-v0.2.2` stable tag, no 0.2.3/0.3 line). origin/master tip = `fcc0ad4621` (2026-11-04 16:40 +0800, PR #7873) — unchanged; `git log --since="2026-11-08 00:00" origin/master` = **0 commits** — nothing landed upstream since the 11-08 watch; backlog past the tag stays 811, no release cut. (Local checkout branch `dev` == `origin/master` == `fcc0ad4621`; there is no remote `dev` branch.)
  - npm dist-tags: `@deepseek-ai/dsh` `latest`/`next` = **0.2.2-rc.1**, `alpha` = 0.2.2-alpha.3, `time.modified` = 2026-11-05T13:22:05Z — unchanged from the 11-06 state. `@islibaodong/dsh-login` `latest` = **0.3.12** (`time.modified` 2026-11-08T14:17:29Z) — the 11-08 watch banner's "0.3.11 stays current" is superseded by the same-day 0.3.12 publish; the current release is 0.3.12.
  - Multi-user grep at the master tip (`multi.?user|multiuser|role.?based|\brbac\b` over `packages/`): still exactly **1 hit** — `packages/api/remote-access/README.md`. `__DSH_BOOT__` lever intact at the master tip (`packages/client/modules/src/index.ts:635`). No native accounts; dsh-login remains the account layer; uiRoleGate unaffected. Evaluation stays closed.
- **Pre-release drift radar re-probed (unreleased WIP, no action taken):** `enumerateWireSurface('E:/code/deepseek-harness')` at master tip `fcc0ad4621` vs `tests/fixtures/wire-surface.json` → **210 vs 204, unchanged from the 11-08 radar** — added: `agentTeams.setEnabled`, `forgePanel.diffBases`, `mcpManager.probe`, `mcpManager.restart`, `mcpManager.watch`, `subagents.interruptByUser`, `web.listProviders`; removed: `subagents.interruptByParent`. No further drift since 11-08 (upstream quiet). When the next DSH tag lands, the re-pin absorbs the 7 and drops the 1.
- **Conclusion: no new DSH version (0.2.2-rc.1 remains the newest release, already adapted + released as 0.3.11 → 0.3.12 security follow-up) → no adaptation needed.** dsh-login 0.3.12 stays current; peer ranges already cover the latest runtime. No code changes → no version bump, no release (release only when a new DSH version requires adaptation).
- Verification: clean tree `npm test` = **22 files / 291 tests green** (2026-11-09 12:03 +0800, 6.04 s) on commit `1ad21a8` (master == origin/master).
- Docs updated (README.md / README.zh.md new 2026-11-09 watch paragraph — explicitly noting 0.3.12 supersedes the 11-08 banner's "0.3.11 stays current" — plus multi-user/RBAC and per-identity-UI-gate re-verification dates). Changelog entry committed + pushed per the release-watch convention.

## 2026-11-08 (0.3.12 released) — streaming-method isolation fix (issue #11) + gateway owner-peer fix (PR #12) shipped to npm
- npm latest = 0.3.12 (shasum 50e306f343c1a3df1d7eaa4171073766476014bd, 38 files, published 2026-11-08 via temp-npmrc flow, token deleted after). Git tag v0.3.12 on release commit 4e562e4 (master chain: 8a48aa3 fix → 1e6aa8f ci → 58b9990 docs → 4e562e4 release).
- README/README.zh release lines updated to 0.3.12 (22 files / 291 tests green); prepack rebuild during publish reproduced committed dist byte-identically (git status clean after publish — the .gitattributes LF fix holds across the real publish path).
- Issue #11 closed (completed) with release note comment (6722606506); main reply 6722514256.

# Memory Changelog

## 2026-11-08 (issue #11 fix) — dispatch-seam guard: streaming methods now isolated per user (workspace.follow tree + id args); 20 new tests; no release
- **Issue #11 (xdrs, 2026-11-05) verified + fixed: 工作区隔离未覆盖流式方法** — the bridge wall only gates HTTP POST; streaming methods (`workspace.follow`, `session.follow`, `terminal.attach`, …) ride the Remote stream mux WebSocket `/api/remote.mux`, which upstream upgrades directly with **no per-request hook and no frame filtering**. Root cause: every dsh-login browser session shares upstream's single `browserPeer` whose principal is `{kind:'owner'}` (dsh-login mints the launch-token cookie server-side), so no upstream access control applies and any user could enumerate ALL workspaces + sessionIds via `workspace.follow` and open other users' sessions by id. All 5 issue claims reproduced against HEAD (`src/api-bridge-auth.ts:188` POST-only wall; `src/api-filter.ts` header admits the WS gap; `workspace.follow` only in USER_ALLOWED; `src/glue.ts` guard composition is deployment-side; `src/remote-guard.ts` stream() forwards unfiltered).
- **Fix = dispatch-seam guard, zero upstream changes** (new `src/dispatch-guard.ts` ~530 lines):
  - **admit shadow**: own-property on the connection service shadows `admit(request)` (dynamically invoked at every dispatch site: HTTP route handler, `requestRejection`, and `admitConnection`/mux upgrade) — browser-path admissions (shared `browserPeer`) now REQUIRE a live dsh-login session (`{rejection:401}` otherwise — closes the known "WS upgrade skips the wall" gap) and tag the admitted peer with the dsh-login user via a lightweight wrapper (`Object.create(peer)` + non-enumerable symbol; wrappers cached per `peer.id|token`, cap 1024, so `$events` result `client.peer === peer` identity checks hold). API-credential (v2 CLI/SDK) peers stay untouched unless a dsh-login session rides along. Untagged peers keep exact upstream semantics.
  - **dispatch shadows**: own-properties on the gateway service shadow `dispatchRpc(endpoint,payload,signal,peer)` and `openWireStream(endpoint,payload,uplink,peer,signal,control,window)` — tagged non-admin peers are checked against `classifyWireMethod` (non-user methods denied with the wall's forbidden envelope / a forbidden stream error; unknown methods fail closed + warn once) and every `GUARDED_ID_FIELDS` id in `payload.args` must resolve to the caller via the ownership index; **`workspace.follow` streams are filtered frame-by-frame** mirroring the upstream workspace-controller's per-principal filter (baseline narrowing, `upsert`/`remove`/`order` delivered-set bookkeeping, `replace` resyncs on visibility loss, archived/pinned narrowing, unknown frames dropped fail-closed; owned-session set re-probed per frame so long streams pick up new sessions).
  - **identity model constraint (recorded):** per-user identity only exists at the dispatch seam via the dsh_session cookie seen by `admit` — dispatch itself has no request context. Full upstream integration (`remoteAccess.registerPolicy` + non-owner principals) was evaluated and REJECTED: exact-fetch routes 403 non-owners (`/api/file` breaks), interactions are owner-only (waterfall UI breaks). `$events` broadcast frames are NOT filtered (documented residual; same class as before).
  - Install (`src/index.ts`): gated on `config.apiBridgeAuth` (same boundary, not a separate feature); `ctx.inject(['connection','typertGateway'], fork => fork.effect(...))` installs/uninstalls with service lifecycles. **option B doc caveat discovered:** `glue.ts`/`docs/compose-guard.md`'s `wrapRemoteGateway` only swaps the gateway's PUBLIC `invoke`/`stream` — browser traffic flows through internal `dispatchRpc`/`openWireStream` closures, so the deployment-side composition never covered real browser calls; the new in-plugin dispatch seam is what actually intercepts them.
- **Supporting edits:** `src/remote-guard.ts` exports `collectIds` + `GUARDED_ID_FIELDS`; `src/bridge-list-filter.ts` `recordOwnershipFromResponse` now also records `payload.workspace.workspaceId` (workspace.create's nested WorkspaceView shape); `src/provision.ts` records the provisioned `workspaceId` for its owner (previously only the seed session was recorded — the new workspaceId id-checks would have refused the user's own sandbox).
- **New regression tests** (`tests/dispatch-guard.spec.ts`, 20 cases): admit tagging + wrapper-cache reuse + 401s (missing/expired/mismatched cookies, browser path) + v2 passthrough + uninstall restore; dispatch verdicts (untagged/admin passthrough, admin-only + unknown deny with envelope + warn-once, $events/$events-result passthrough, foreign sessionId deny, owned allow, stream-open reject, multi-field args); follow filtering (baseline narrowing, foreign upsert drop + replace resync, remove only-if-delivered + revocation resync, archived/pinned narrowing + unknown-frame drop, mid-stream ownership refresh); collectIds/multi-field regression. Harness mirrors upstream admit (no cookie→401; `dsh-auth-v2=`→apiPeer; `dsh-auth-`→browserPeer).
- **Verification:** 22 files / **291 tests green** (291 = 271 + 20, 6.83 s); `verify:imports` ok; `npm run build` fresh; dist blobs committed (index.js `cf650cf`, map `3637739`). Not released — dist stamp stays 0.3.11 until the next release trigger (next `prepack` rebuilds).
- **CI freshness-gate fix (follow-up commit):** the first push's CI failed `git diff --exit-code -- dist/` — the Linux build produced map `13f8a18` while the committed map was `3637739`: **CRLF smudge** (core.autocrlf=true) made esbuild embed CRLF `sourcesContent` into dist/index.js.map (index.js itself is LF-normalized output and matched). Fix: new `.gitattributes` (`* text=auto eol=lf` — Windows checkouts now LF, local builds byte-identical to CI forever), src/*.ts + settings-panel.client.js normalized to LF in the working tree, rebuilt — map blob now `13f8a18` exactly == CI's; client.js also shrank 37134→36443 (embedded CRLF gone). Suite re-run 291 green (5.67 s). LESSON (extends the autocrlf blob-hash lesson from PR #12): on this repo, working-tree diffs are CRLF-noisy — but now `.gitattributes` pins LF checkouts, so local `npm run build` output should match CI byte-for-byte.
- Residuals disclosed in the issue reply: `$events` broadcast content unfiltered; `terminal.attach`/`job.follow` id-free (jobId/agentId not ownership-mapped); `/api/file` media GET has no per-user check (UUID unguessable, session-gated).

## 2026-11-08 (PR #12 merged) — gateway renderIndex owner-peer fix (DSH 0.2.2 homepage 400) + CI rewrite; no release
- **External PR #12 (JiZhi-Error:fix/index-render-peer, 2 commits d8bcd3a + d14cfb9, squash-merged as `4cc3eef`) verified + merged.** Not released: dist stamp stays 0.3.11 (npm `prepack` builds fresh per publish; git dist/ now slightly newer than the v0.3.11 tag). Master was red on the OLD CI (run 42445765783: `npx tsx@4 tests/runner.mjs` died on undefined `assertEqual`) — this PR also fixes that.
  - **Gateway fix (src/gateway.ts:24-37):** DSH 0.2.2 `WebServer.renderIndex(html: string, peer: PeerScope)` (webserver/src/index.ts:738 at rc.1) requires the peer; `collectIndexInjections` emits `('webserver/index-inject', table, peer)` and the remote-access listener (`packages/api/remote-access/src/index.ts:139`) reads `peer.principal` → `snapshotFor` → with peer undefined: `TypeError: Cannot read properties of undefined (reading 'principal')` → WebServer converts to **400 on authenticated `/`**. Fix: `render.call(webServer, body, { principal: { kind: 'owner' } })`; `applyIndexTaps` fallback kept for old DSH (extra arg harmless there). **Security-reviewed: `snapshotFor(owner)` returns `OWNER_BASELINE {type:'baseline',owner:true}` only — no grants/admin data reach the page; real boundaries remain login wall + api-bridge method gate + uiRoleGate.** Matches upstream convention (frontend-static README: owner browser pages open with the owner baseline).
  - **CI rewritten** (.github/workflows/ci.yml): Node 20/22 matrix → **24.9.0 + 24.x**; the harness-checkout integration job is GONE — `npm ci` + `npm test` (lockfile resolves @deepseek-ai/* rc.1 from npm) + `node --import tsx/esm tests/runner.mjs` smoke + `verify:imports` + `npm run build` + `git diff --exit-code -- dist/` bundle-freshness gate. `tests/integration-runner.mjs` (565 lines) → 18-line shim delegating to vitest (gateway/login-api/plugin-entry specs); `tests/runner.mjs` 6 legacy `assertEqual`→`assert` fixes. README/zh test sections → Node >=24.9.0 + npm ci workflow. First real CI run green on Linux (27s/19s both matrix legs).
  - **New regression test** (tests/gateway.spec.ts:179-213): parameterized isAdmin true/false — registers a `webserver/index-inject` listener reading `peer.principal`, asserts `/` + `/index.html` render 200 with `__DSH_REMOTE_ACCESS__` owner snapshot and anonymous still 302→/login with zero listener calls.
  - **Local verification before merge:** on pr-12 — `npm ci` clean, `npm test` 21 files / **271 tests green** (271 = 269 + 2 new parameterized), runner.mjs smoke 40/40, `verify:imports` 0, `npm run build` exit 0; post-merge re-run on master `4cc3eef`: 271 green again (5.87 s) + CI success. Rebuild vs committed dist diff was **line-endings only** (git show CRLF smudge artifact; blobs 9152900/0b92635 match exactly).
  - README on master now documents Node >=24.9.0 for the test workflow (PR body's "Node 22.23.2" verification note is stale wording; actual gates pass on 24.x).

## 2026-11-08 (scheduled watch) — no new DSH release; 0.3.11 stays current, no adaptation, no publish
- Scheduled watch (cron `0 12 * * *` Asia/Shanghai; trigger 2026-11-08T04:00:00.016Z / 12:00 +0800).
  Detection (all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: no new objects. Newest tag still `dsh-v0.2.2-rc.1` (no `dsh-v0.2.2` stable tag, no 0.2.3/0.3 line). origin/master tip = `fcc0ad4621` (2026-11-04 16:40 +0800, PR #7873) — unchanged since the 11-04 state; `rev-list --count dsh-v0.2.2-rc.1..origin/master` = **811** — unreleased backlog on master, no release cut. (Local checkout branch `dev` == `origin/master` == `fcc0ad4621`; there is no remote `dev` branch.)
  - npm dist-tags: `@deepseek-ai/dsh` `latest`/`next` = **0.2.2-rc.1**, `alpha` = 0.2.2-alpha.3 — unchanged from the 11-06 state (last move was 11-06: `latest` promoted onto rc.1). `dsh-web-frontend` dist-tags: `latest` = 0.0.1-rc.5 (legacy placeholder), `next` = 0.2.2-rc.1, `alpha` = 0.2.2-alpha.3. `@islibaodong/dsh-login` `latest` = 0.3.11 (nothing newer). No publish beyond rc.1 anywhere.
  - Multi-user grep at the master tip (`multi.?user|multiuser|role.?based|\brbac\b` over `packages/ apps/`): still exactly **1 hit** — `packages/api/remote-access/README.md`. `__DSH_BOOT__` lever intact at the master tip (`packages/client/modules/src/index.ts:635`). No native accounts; dsh-login remains the account layer; uiRoleGate unaffected. Evaluation stays closed.
- **Pre-release drift radar (new, recorded for the NEXT re-pin — unreleased WIP, no action taken):** the wire surface on origin/master has drifted 204 → **210** vs the rc.1-pinned snapshot (probe: `enumerateWireSurface('E:/code/deepseek-harness')` at master tip `fcc0ad4621` vs `tests/fixtures/wire-surface.json`). Added: `agentTeams.setEnabled`, `forgePanel.diffBases`, `mcpManager.probe`, `mcpManager.restart`, `mcpManager.watch`, `subagents.interruptByUser`, `web.listProviders`; removed: `subagents.interruptByParent`. Driver commits: the named-subagents/team line (PR #7697 merge `a2f3a18580`, `30bf5733d6` "refactor(mcp-manager): publish the manager as ctx.mcpManager", `ff563d07e0` "feat(subagent): name subagents in their creator catalog") and the web provider-listing rework (`WebRuntime extends TypertRemoteService`, `@Remote listProviders()` — `packages/web/web/src/index.ts`). Also on the WIP tree: `packages/client/modules/src/client/entries.ts` initial-roster creation now catches per-entry create rejections (`await this.create(loader, id).catch(...)` — one bad module row no longer aborts startup); `packages/client/locale` grew 2 keys per locale. None of this affects the rc.1-released line; when the next DSH tag lands, re-pin: buckets must absorb the 7 additions (likely classification: `web.listProviders` user, `mcpManager.*` admin-or-user per the manager's operator status, `subagents.interruptByUser` user, `agentTeams.setEnabled` user-or-admin, `forgePanel.diffBases` user like the rest of forgePanel) and drop `subagents.interruptByParent`.
- **Conclusion: no new DSH version (0.2.2-rc.1 remains the newest release, already adapted + released as 0.3.11) → no adaptation needed.** dsh-login 0.3.11 stays current; peer ranges already cover the latest runtime. No code changes → no version bump, no release (release only when a new DSH version requires adaptation).
- Verification: clean tree `npm test` = **21 files / 269 tests green** (2026-11-08 12:06 +0800, 7.10 s) on commit `d43d339` (master == origin/master == tag `v0.3.11`); `npm run verify:imports` exit 0.
- Docs updated (README.md / README.zh.md new watch paragraph + multi-user/RBAC and per-identity-UI-gate re-verification dates). Changelog entry committed + pushed per the release-watch convention.

## 2026-11-06 (scheduled watch) — no new DSH release; 0.3.11 stays current, no adaptation, no publish
- Scheduled watch (cron `0 12 * * *` Asia/Shanghai; trigger 2026-11-06T04:00:00.005Z / 12:00 +0800).
  Detection (all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: no new objects. Newest tag still `dsh-v0.2.2-rc.1` (no `dsh-v0.2.2` stable tag, no 0.2.3/0.3 line). origin/master tip = `fcc0ad4621` (2026-11-04 16:40 +0800, PR #7873) — unchanged since the 11-04 state; `rev-list --count dsh-v0.2.2-rc.1..origin/master` = **811** — unreleased backlog on master (long-running branch merges), no release cut. Local checkout `dev` == `origin/master` == `fcc0ad4621`, dirty only CLAUDE.md + untracked agent dirs (known noise).
  - npm dist-tags: `@deepseek-ai/dsh` `latest`/`next` = **0.2.2-rc.1**, `alpha` = 0.2.2-alpha.3 — `latest` has now ALSO moved onto rc.1 (the stable channel caught up with `next`; on 11-05 only `next` had moved). `dsh-host-webserver`/`dsh-web-frontend`: `next` = 0.2.2-rc.1, `alpha` = 0.2.2-alpha.3. `@islibaodong/dsh-login` `latest` = 0.3.11 (the 11-05 release; nothing newer). No publish beyond rc.1 anywhere.
  - Multi-user grep at the rc.1 tag AND the master tip (`multi.?user|multiuser|role.?based|\brbac\b` over `packages/ apps/`): still exactly **1 hit** — `packages/api/remote-access/README.md`. `__DSH_BOOT__` lever intact at the master tip (`packages/client/modules/src/index.ts:635`). No native accounts; dsh-login remains the account layer; uiRoleGate unaffected. Evaluation stays closed.
- **Conclusion: no new DSH version (0.2.2-rc.1 remains the newest release, already adapted + released as 0.3.11 yesterday) → no adaptation needed.** dsh-login 0.3.11 stays current; peer ranges already cover the latest runtime. No code changes → no version bump, no release (release only when a new DSH version requires adaptation).
- Verification: clean tree `npm test` = **21 files / 269 tests green** (2026-11-06 12:04 +0800, 5.83 s) on commit `9350e05` (master == origin/master == tag `v0.3.11`).
- Docs updated (README.md / README.zh.md new watch paragraph + multi-user/RBAC and per-identity-UI-gate re-verification dates). Changelog entry committed + pushed per the release-watch convention.

## 2026-11-05 (scheduled watch) — DSH 0.2.2-rc.1 released; adapted + released as **0.3.11**
- Scheduled watch (cron `0 12 * * *` Asia/Shanghai; trigger 2026-11-05T04:00:01.859Z / 12:00 +0800).
  Detection: every peer package's npm `next` dist-tag moved to **0.2.2-rc.1** (published from
  tag commit `2f97f60455` "release(dsh): 0.2.2-rc.1", 2026-11-04 15:50 +0800); `alpha` stays
  0.2.2-alpha.3. Git tag `dsh-v0.2.2-rc.1` → `66491b05e3` (merge PR #7870); range
  `dsh-v0.2.2-alpha.3..dsh-v0.2.2-rc.1` = **2 content commits**: `60d811de43` "release(vendor):
  cordis 4.1.0, cosmokit 1.9.0, group 1.1.0, hmr 1.1.0, include 1.1.0, loader 1.1.0,
  logger-console 1.1.0, schemastery 3.19.0, timer 1.2.0" (vendor **stable** re-issue) + the
  version-bump release commit. **387 files changed, all package.json — zero source changes**,
  so the 204-method wire registry is provably identical → no re-dump (only version-pin moves).
- Files: `package.json` (v0.3.11; devDeps → `^0.2.2-rc.1` + vendor stable cordis `~4.1.0` /
  schemastery `~3.19.0` / include `~1.1.0` / loader `~1.1.0`; **peers +=** cordis `|| ~4.1.0`,
  schemastery `|| ~3.19.0` — the old `^4.0.1-rc.1`/`^3.18.1-rc.1` branches cannot admit the
  new `[4,1,0]`/`[3,19,0]` tuples under npm's install-time prerelease rule; DSH-package peer
  branches unchanged), `src/api-filter.ts` (`WIRE_SURFACE_DSH_VERSION = '0.2.2-rc.1'` + header
  note; method lists untouched, buckets stay 124/79/1), `tests/fixtures/wire-surface.json`
  (`dshVersion` → 0.2.2-rc.1, methods unchanged), `dist/*` rebuilt (`client.js` byte-identical
  37134 chars, SHA-256 verified; `index.js` stamp-only), `docs/adapt-dsh-0.2.2-rc.1.md` (new),
  README.md / README.zh.md (banner + 11-05 watch + history + tracking/eval dates).
- **Install trap (new lesson):** incremental `npm install` on the stale alpha.3 lockfile tree
  ERESOLVE-wedged (old `cordis-plugin-group` peer from the alpha.3 `dsh-app-boot` chain) —
  fixed by **clean install** (delete `node_modules` + `package-lock.json`; 111 packages in 10s,
  all resolved at rc.1/stable line). See gotchas.md.
- Verification: `npm test` = 21 files / 269 tests green (incl. strict live cross-check
  204==204); `npm run build` exit 0; **`verify:imports` exit 0 — the tsx strip-only failure
  recorded since 0.3.9 no longer reproduces** (env issue resolved, drop it from future
  verification tables).
- Multi-user grep at the rc.1 tag: still exactly **1 hit** —
  `packages/api/remote-access/README.md`. `__DSH_BOOT__` lever intact
  (`packages/client/modules/src/index.ts:635`). No native accounts; dsh-login remains the
  account layer; uiRoleGate unaffected. Release: commit + tag `v0.3.11` + push + npm publish
  (see git/npm for the record).

## 2026-11-04 (scheduled watch) — DSH 0.2.2-alpha.3 released; adapted + released as **0.3.10**
- Scheduled watch (cron `0 12 * * *` Asia/Shanghai; trigger 2026-11-04T04:00:00Z / 12:00 +0800).
  Detection: `dsh-v0.2.2-alpha.3` tag → `05b1cae8db` ("release(vendor): cordis 4.0.6-alpha.2,
  cosmokit 1.8.7-alpha.2, group 1.0.6-alpha.2, hmr 1.0.21-alpha.2, include 1.0.11-alpha.2,
  loader 1.0.7-alpha.2, logger-console 1.0.6-alpha.2, schemastery 3.18.6-alpha.2,
  timer 1.1.8-alpha.2"), tagged 2026-11-03 14:19:06 +0800; **111 commits** past
  `ce7073d512`; npm `alpha` = 0.2.2-alpha.3 (published 2026-11-03T07:48:26Z), `latest`/`next`
  stay 0.2.1-rc.5; all ten peer packages verified published at 0.2.2-alpha.3.
- Adapter surface: `packages/api` sees **only** the session-controller projection rework
  (~130 src lines: `ApiSessionList` keeps a `ProjectionHandle<SessionListMetadata>`;
  `cachedSnapshot` → `snapshot`; **`SessionProjectionUpdate` wire shape changed**
  `{sessionId, key, value, seq}` → `{sessionId, seq, changes: {key, val}[]}` — one update
  per committed event). `@Remote` method names unchanged → method walls untouched; frame
  payload rides inside session-scoped streams already gated by ownership. Client packages
  (`connection`/`modules`/`ui-slots`) and host (`webserver`/`frontend-static`): package.json
  bumps only → `dist/client.js` banner-only re-stamp (byte-identical, 37134 chars).
- **Wire surface re-pinned 199 → 204** (the 11-02 dev-tree observation released):
  `schedule.update`/`schedule.delete` folded into `schedule.edit`; + `schedule.create`/
  `deliveryLimits`/`run`/`view` + `forgePanel.changeRequestChecks`/`submitReview`, all
  classified **user** (schedule CRUD = caller's own surface, same trust shape as the
  already-admitted schedule reads — shared host schedule domain, no per-task ownership
  upstream; forge pair session-scoped via `this.bound(session, url)`, `submitReview` =
  same trust shape as `merge`/`markReady`). Buckets **124 / 79 / 1**.
- Files: `package.json` (v0.3.10, devDeps → alpha.3 + vendor alphas, **peers unchanged** —
  `>=0.2.2-alpha.2 <0.3.0-0` admits alpha.3 via same-tuple rule), `src/api-filter.ts`,
  `tests/fixtures/wire-surface.json` (re-dumped from a **built** alpha.3 worktree
  `E:\code\deepseek-harness-wt-022a3` @ `05b1cae8db`: `pnpm install` + `pnpm run typecheck`,
  5 gates pass in 191.20s, 36 typert files), `tests/wire-surface.spec.ts` (pins 124/79/1,
  no-checkout expects 204), `dist/*` rebuilt, `docs/adapt-dsh-0.2.2-alpha.3.md` (new),
  README.md / README.zh.md (banner + 11-04 watch + history + tracking/eval dates).
- Verification: `npm install` clean (30 packages); `npm test` = 21 files / 269 tests green;
  strict live cross-check 204 == 204 vs the checkout; `npm run build` exit 0;
  `verify:imports` still fails on node v24.20.0 tsx strip-only (pre-existing env issue).
- Multi-user grep at the alpha.3 tag: still exactly **1 hit** —
  `packages/api/remote-access/README.md`. `__DSH_BOOT__` lever intact
  (`packages/client/modules/src/index.ts:635`). No native accounts; dsh-login remains the
  account layer; uiRoleGate unaffected. Release: commit + tag `v0.3.10` + push + npm
  publish + gh release (see git/npm for the record).

## 2026-11-03 (scheduled watch) — no new DSH release; 0.3.9 stays current, no adaptation, no publish
- Scheduled watch (cron `0 12 * * *` Asia/Shanghai; trigger 2026-11-03T04:00:00Z / 12:00 +0800).
  Detection (all three channels):
  - `git fetch --tags` in `E:\code\deepseek-harness`: no new objects. Newest tags remain
    `dsh-v0.2.1-rc.5` (2026-10-29 21:01 +0800, `b830ec950f`/`31cfe2aafe`) > `dsh-v0.2.2-alpha.2`
    (2026-10-28, `f3803c9697`). Local `master` == `origin/master` == `ce7073d512` — unchanged
    since the 10-30 watch; nothing new landed upstream, so the 11-02 dev-tree observations
    (wire surface drift 199 → 204; remote-access `whenAccess`/`whenAllowed`/per-Peer
    `snapshotFor`) remain the latest and still carry no action.
  - npm dist-tags unchanged: `@deepseek-ai/dsh` `latest`/`next` = 0.2.1-rc.5, `alpha` =
    0.2.2-alpha.2 (`time.modified` 2026-10-29T16:01:42Z); `dsh-web-frontend` (`next` rc.5 /
    `alpha` alpha.2, `time.modified` 2026-10-29T14:13:50Z) and `dsh-host-webserver` (same
    dist-tags, `time.modified` 2026-10-29T13:50:52Z) — no registry activity since the 10-29
    rc.5 publish window.
  - Multi-user grep at the rc.5 tag (`multi.?user|multiuser|role.?based|\brbac\b` over
    `packages/ apps/`): still exactly **1 hit** — `packages/api/remote-access/README.md`.
    No native accounts upstream; dsh-login remains the account/authn layer. Role-based
    whole-UI control remains delivered in-plugin (0.3.0 `uiRoleGate` + 0.3.1 bridge wall);
    evaluation stays closed.
- Verification: clean tree `npm test` = 21 files / 269 tests green (2026-11-03 12:01 +0800).
  Docs updated (README.md / README.zh.md new watch paragraph + multi-user/RBAC and
  per-identity-UI-gate re-verification dates). **No npm publish** — no new DSH release, no
  adaptation; 0.3.9 stays current.

## 2026-11-02 (scheduled watch) — no new DSH release; 0.3.9 stays current, no adaptation, no publish
- Scheduled watch (cron `0 12 * * *` Asia/Shanghai family; run 2026-11-02 ~16:35 +0800).
  Detection (all three channels):
  - `git fetch --tags` in `E:\code\deepseek-harness`: no new objects. Newest
    tags remain `dsh-v0.2.1-rc.5` (2026-10-29 21:01 +0800, `b830ec950f` /
    `31cfe2aafe`) > `dsh-v0.2.2-alpha.2` (2026-10-28, `f3803c9697`). Local
    `master` == `origin/master` == `ce7073d512` (2026-10-30 00:13, PR #7552)
    — unchanged since the 10-30 watch.
  - npm dist-tags unchanged: `@deepseek-ai/dsh-host-webserver` and
    `dsh-web-frontend` both `next`=0.2.1-rc.5 / `alpha`=0.2.2-alpha.2;
    `time.modified` = 2026-10-29T13:50:52Z (the rc.5 publish window) — no
    registry activity since.
  - Multi-user grep at the rc.5 tag (`multi.?user|multiuser|role.?based|\brbac\b`
    over `packages/ apps/`): still exactly **1 hit** —
    `packages/api/remote-access/README.md`. No native accounts upstream;
    dsh-login remains the account/authn layer. Role-based whole-UI control
    remains delivered in-plugin (0.3.0 `uiRoleGate` + 0.3.1 bridge wall);
    evaluation stays closed.
- Dev-tree observations recorded for the NEXT re-pin (unreleased; NO action
  taken — the vendored fixture keeps tracking the newest RELEASE line):
  - Wire surface drift: `node scripts/dump-wire-surface.mjs --checkout` on the
    dev tree (HEAD `ce7073d512`) dumps **204 methods** vs the vendored 199
    (0.2.2-alpha.2). Added: `forgePanel.changeRequestChecks`,
    `forgePanel.submitReview`, `schedule.create`, `schedule.deliveryLimits`,
    `schedule.edit`, `schedule.run`, `schedule.view`. Removed:
    `schedule.update`, `schedule.delete` (dev-tree `ScheduleService` @Remote
    methods are now deliveryLimits/create/list/catalog/view/history/run/
    deleteInactive/edit; "Host-wide durable reminders"; no resource
    declarations → global resource). Decision: **reverted
    `tests/fixtures/wire-surface.json` to the vendored 199** — the fixture
    pins a released wire generation, and `tests/wire-surface.spec.ts:79-100`
    already no-ops its strict cross-check when the live checkout's length
    differs from the snapshot's (vendored snapshot is authoritative; "next
    watch re-pins" when a release lands). The 7 new methods are unclassified
    in `src/api-filter.ts` → denied by default on dev trees (harmless; not a
    released line).
  - remote-access evolution (rc.5..HEAD diff, unreleased): new
    `packages/api/remote-access/src/client/when-allowed.ts`
    (`whenAllowed(ctx, answer, callback, label)` effect controller) and
    `client/mount.ts` `ClientRemoteAccess.source(kind, id, action)` /
    `whenAccess`; README adds session/attachment whole-library-read warnings;
    the `__DSH_REMOTE_ACCESS__` snapshot became per-Peer
    (`snapshotFor(peer.principal)`). Liveshare non-owner-Peer authorization —
    a future native substrate if dsh-login ever mints non-owner principals;
    no impact on the current owner-principal model.
- Environment note: `npm run verify:imports` currently fails on node
  v24.20.0 + tsx 4.23.15 — "TypeScript parameter property is not supported in
  strip-only mode" for 9 src files using TS parameter properties
  (admin-api/boolean-setting/hosts/index/ownership/provision/
  remote-web-ui-compat/session/users/workspace-setting.ts). Reproduces on
  unmodified HEAD → environment issue, not a code regression (the 10-29 run
  was clean); `npm test` and the esbuild `build` are unaffected.
- Verification: clean tree `npm test` = 21 files / 269 tests green
  (2026-11-02 16:37 +0800). Docs updated (README.md / README.zh.md watch
  paragraph + multi-user/RBAC and per-identity-UI-gate re-verification
  dates). **No npm publish** — no new DSH release, no adaptation; 0.3.9
  stays current.

## 2026-10-30 (12:00 scheduled watch) — DSH 0.2.1-rc.5 released; verified compatible, NO adaptation, 0.3.9 stays current
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-30T04:00:01Z).
  Detection (all three channels):
  - `git fetch --all --tags` in `E:\code\deepseek-harness` (retry with
    `git -c http.version=HTTP/1.1 fetch --tags origin` on TLS eof): NEW tag
    since the 10-29 noon watch — `dsh-v0.2.1-rc.5` → `b830ec950f` (merge PR
    #7572 `worktree/release-dsh-0.2.1-rc.5`; release commit `31cfe2aafe`),
    tagged 2026-10-29 21:01:28 +0800, npm published 2026-10-29T14:15:23Z
    (22:15 +0800 — after the 10-29 watch). rc.4 IS an ancestor of rc.5;
    alpha.2 is NOT (separate 0.2.2 line). rc.4..rc.5 = **4 commits**, the
    only functional one PR #7484 (customize thinking-block rendering, ui-chat
    only). Local `dev` still parked at `22ddee3792` (rc.3+1533), HEAD does not
    contain rc.5 — detection source only, never retargeted.
  - npm dist-tags, all 11 plugin-graph packages re-published at 0.2.1-rc.5
    (`next`=rc.5 on every row; `@deepseek-ai/dsh` `latest` **promoted from
    rc.2 to rc.5** — first stable-channel move since 10-17; the other rows'
    `latest` dist-tags are stale 0.0.1-rc.*, use `next`); `alpha` stays
    0.2.2-alpha.2 everywhere.
  - Multi-user grep at the rc.5 tag (`multi.?user|multiuser|role.?based|\brbac\b`
    over `packages/`): still exactly **1 hit** —
    `packages/api/remote-access/README.md`. No native accounts upstream;
    dsh-login remains the account/authn layer.
- Adapter-surface verification (all against the rc.5 TAG, never the stale
  tree): `git diff dsh-v0.2.1-rc.4..dsh-v0.2.1-rc.5 -- packages/host/webserver
  packages/client/connection packages/host-frontend-static
  packages/client/modules packages/api packages/boot apps/web apps/web-app
  ui-slots ...` = 24 files, +41/−29, ALL package.json — zero source change on
  the rc line (wire registry stays at the 146 rc-line methods). Direct tag
  greps: `authorizeIndex(req, res, secure = false)` present at
  `packages/client/connection/src/browser-auth.ts:263` and the core's
  rpc-host already passes `webServer.protocol === 'https:'` (rpc-host.ts:194);
  `get protocol(): 'http:' | 'https:'` at
  `packages/host/webserver/src/index.ts:341` (src/, NOT src/lib/ — the 0.3.9
  HTTPS-probe surface exists at rc.5); `__DSH_BOOT__` boot-graph lever intact
  (`packages/client/modules/src/index.ts:592`,
  `rows.push({kind:'global', name:'__DSH_BOOT__', value: graph})`).
- Method-wall subset proof: all 146 rc-line methods as classified by v0.3.7
  (`git show v0.3.7:src/api-filter.ts`) keep their EXACT bucket in HEAD's
  199-method classification (92/53/1 ⊂ 119/79/1, checked per method via the
  `new Set([...])` extraction). Combined with the zero-diff integration
  layer, rc.5 needs no re-classification.
- Decision: peers already admit rc.5 (`>=0.2.1-alpha.1 <0.3.0-0` branch,
  semver prerelease tuple rule) and devDeps stay pinned to `^0.2.2-alpha.2`
  (newer-generation line; same treatment rc.4 received on 10-28). **No
  adapter release — 0.3.9 stays current.**
- Verification: `npm test` = **21 files / 269 tests green** (12:12 +0800).
- Repo-hygiene fix in the same pass: HEAD's `dist/index.js` was missing the
  0.3.9 mintCoreCookie rebuild (the published v0.3.9 tarball DOES contain it
  — verified by `npm pack @islibaodong/dsh-login@0.3.9` extraction) — the
  working-tree dist (identical to the published tarball) is now committed so
  HEAD == published state.
- README.md + README.zh.md: banner/status updated 0.3.8 → 0.3.9 (they were
  never updated at the 0.3.9 release and still claimed `latest` = 0.3.8);
  0.3.9 added to both adaptation-history lines; 2026-10-30 rc.5 watch
  paragraph added to both banners; multi-user/RBAC evaluation headers and
  no-native-accounts rows extended with the rc.5 re-check (2026-10-30).
- Changelog entry committed + pushed per the release-watch convention.

## 2026-10-29 — 0.3.9: issue #10 fixed (launch-token exposure via fresh-device bounce)
- Issue #10 (hatsuyuki280/初雪, opened 2026-10-25, framed as spec-deviation
  not a vuln report): `createAuthorizeIndex` (src/gateway.ts) bounced any
  logged-in fresh device to `/?token=<launchToken>` — the process launch
  token reached the remote client (Location header → history, proxy logs),
  and the SAME token is accepted by the core's `GET /connect` for an
  owner-principal API credential (`authorizeConnect` validates the same
  `this.launchToken`; apiBridgeAuth never gates /connect). Multi-user
  deployments only; also a revocation-boundary violation (token outlives
  disable/logout until process restart). All claims verified against
  @deepseek-ai/dsh-client-connection 0.2.2-alpha.2.
- Fix (server-side virtual exchange, no cookie-format replication): when the
  probe says the core cookie is missing and the request carries no token,
  dsh-login synthesizes `GET /?token=<launchToken>` (real request headers)
  and feeds it through `connection.authorizeIndex` with a capture response;
  the minted `set-cookie` is replayed onto the real response and the index
  is served inline (no redirect). Mint failure (e.g. no Host authority)
  falls through to the core's plain-text 401 — never back to the token URL.
  The core owns cookie format/authority/Secure via its own service wrapper
  (`authorizeIndex` derives `secure` from `webServer.protocol === 'https:'`).
- Drive-by fix (same code path): the `isAuthenticated` probe now receives
  the listener's `secure` decision. 0.3.8 probed with secure=false, but
  native-TLS listeners mint cookies bound to the https-origin audience →
  probe never matched → infinite bounce loop on native-TLS deployments
  (and a stale http-audience cookie would 401-lock the index after an
  HTTP→TLS switch). `webServer.protocol` is a getter ("'https:' when tls
  is configured", dsh-host-webserver lib index.js:350-354).
- isAdmin gating was considered and rejected: it would break non-admin
  fresh-device bootstrap (the issue #3 scenario). The virtual exchange
  preserves bootstrap for everyone while never exposing the token.
- Long-term upstream suggestion (issue #10): split launch-token scopes —
  belongs in deepseek-ai/deepseek-harness Discussions, out of dsh-login's
  control; with this fix the plugin path no longer needs it.
- Tests: bounce test rewritten as server-side-exchange test (200 + minted
  cookie + NO location + no token on the wire); added mint-failure → core
  401 test and HTTPS probe (`secure === true` recorded) test. `npm test` =
  **21 files / 269 tests green**; `verify:imports` ok.
- README.md + README.zh.md Security notes: launch-token paragraph added
  under "Protected by the gateway / 网关保护范围"; test counts 247→269.
- Version 0.3.8 → 0.3.9; published per the .npmrc.publish procedure.

## 2026-10-29 (12:00 scheduled watch) — no new DSH release; 0.3.8 stays current
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-29T04:00Z).
  Detection (fresh evidence, all three channels):
  - `git fetch --all --tags` in `E:\code\deepseek-harness`: clean, no output —
    origin unchanged since the 10-28 watch. Newest tag still
    `dsh-v0.2.2-alpha.2` (→ `f3803c9697`, the release merge PR #7437);
    `origin/master` tip = `f3803c9697`; `git rev-list
    dsh-v0.2.2-alpha.2..origin/master --count` = **0** — no commits past the
    release merge. (Local `dev` branch still parked at `22ddee3792` on the
    pre-alpha.2 backlog — same as every watch since 10-23; the local checkout
    is only ever a detection source, never retargeted.)
  - npm official registry, all 11 `@deepseek-ai/dsh-*` plugin-graph packages
    (dsh, host-webserver, host-frontend-static, client-connection, settings,
    web-frontend, client-modules, scope, session, brand, credentials):
    `alpha=0.2.2-alpha.2` / `next=0.2.1-rc.4` on every row; `time.modified`
    all within the alpha.2 publish window (2026-10-27T18:46–19:10Z) —
    **nothing published since**. `@deepseek-ai/dsh` `latest` stays
    `0.2.1-rc.2`.
  - Multi-user re-check at `origin/master` (= the tag commit): grep
    `multi.?user|multiuser|role.?based|\brbac\b` over `packages/ apps/` =
    **1 hit** — `packages/api/remote-access/README.md` (identical to every
    watch since alpha.3). No native accounts upstream; dsh-login remains the
    multi-user layer. `__DSH_BOOT__` lever intact
    (`packages/client/modules/src/index.ts:633`) — uiRoleGate intact. Role-
    based whole-UI gating stays SHIPPED (0.3.0 uiRoleGate + 0.3.1
    bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version (0.2.2-alpha.2 remains the newest release,
  already adapted + released as 0.3.8 yesterday) → no adaptation needed.**
  dsh-login 0.3.8 stays current; peer ranges (`>=0.2.2-alpha.2 <0.3.0-0` on
  the prerelease tuple + `>=0.2.1-alpha.1` branches, alpha-line vendor pins)
  already cover the latest runtime. No code changes → no README fix, no
  release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **21 files / 267 tests green** (6.70 s) on the
  current tree (commit `7544df9`, master == origin/master, clean).
- Changelog entry committed + pushed per the release-watch convention.

## 2026-10-28 (12:00 scheduled watch) — DSH 0.2.1-rc.4 + 0.2.2-alpha.2 released; adapted as 0.3.8
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-28T04:00Z).
  Detection (fresh evidence, all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: **two new
    tags** since the 10-26 watch — `dsh-v0.2.1-rc.4` (→ `504a01a957`, tagged
    2026-10-26 16:15 +0800, npm published 2026-10-26T15:09Z; 9 commits over
    rc.3: 4 package.json bumps + tooltip/acp-stdout/mcp-diagnostics fixes,
    **zero adapter-surface impact**) and `dsh-v0.2.2-alpha.2` (→ `f3803c9697`,
    release merge PR #7437, tagged 2026-10-28 02:17 +0800, npm published
    2026-10-27T18:52Z; **2161 commits** over rc.4). No `0.2.2-alpha.1` exists
    (git and npm). origin/master tip `22ddee3792` → `f3803c9697`. Analysis ran
    in detached worktree `E:\code\deepseek-harness-wt-022a2` @ alpha.2 (the
    running harness's own checkout at `E:\code\deepseek-harness` stayed on
    `dev` @ `22ddee3792`, untouched).
  - npm official registry: all 11 `@deepseek-ai/dsh-*` plugin-graph packages
    re-published at both tags (`next=0.2.1-rc.4`, `alpha=0.2.2-alpha.2`);
    `@deepseek-ai/dsh` `latest` stays `0.2.1-rc.2`. Vendor `next` dist-tags
    re-issued on the 0.2.2 line: cordis `4.0.6-alpha.1`, schemastery
    `3.18.6-alpha.1`, include `1.0.11-alpha.1`, loader `1.0.7-alpha.1`.
    Published-tarball peer check @alpha.2: cross-package peers pin exact
    `0.2.2-alpha.2`, cordis `~4.0.6-alpha.1`, schemastery `~3.18.6-alpha.1`.
  - Adapter surface rc.4→alpha.2: 176 files / +6221/−521. Headliners: PR
    #6901 (`73931626be`) rewrote `@deepseek-ai/dsh-host-frontend-static` into
    a WebResource cordis plugin and **removed the `serveStatic` export**;
    `/api` wire registry **146 → 199 methods (+53)**; webserver index-inject
    now `(table, peer)` (listener-only consumption stays compatible);
    settings 3-line internal projection fix (no surface); web-app patch
    roster churn (not ours; the `web-runtime` row dsh-login's
    `cordis.patch.yml` disables still exists); boot-graph lever intact
    (`__DSH_BOOT__`, types re-homed to `client/modules/src/client/manifest.ts`)
    → uiRoleGate unaffected.
  - Note: a prior session (2026-10-27 evening, uncommitted WIP in the tree)
    had pre-adapted against then-unreleased master (`src/serve-static.ts`,
    gateway import swap, 16/53 methods classified, fixture stamped 162). This
    watch verified the WIP against the real published alpha.2, corrected the
    fixture to the true 199-method registry, and completed the remaining 37
    classifications.
  - Multi-user re-check at `dsh-v0.2.2-alpha.2`: grep
    `multi.?user|multiuser|role.?based|\brbac\b` over `packages/ apps/` =
    **1 hit** — `packages/api/remote-access/README.md` (identical to every
    watch since alpha.3; 2161 commits of backlog, still no account store).
    remote-access grew role bindings over the new `forgePanel`/
    `liveshareShares`/`session` resource kinds + per-Peer access snapshots,
    but still only gates **non-owner** peers; dsh-login users are owner
    principals. dsh-login remains the multi-user layer; evaluation unchanged.
- **Adaptation shipped as 0.3.8** (devDep retarget + real code changes; full
  analysis in `docs/adapt-dsh-0.2.2-alpha.2.md`):
  - `src/serve-static.ts` (new): self-hosted node:http static fallback for
    the `serveStatic` export upstream deleted — dist-root confinement (403 on
    traversal), `ENOENT/EISDIR/ENOTDIR` → 404, index via `authorizeIndex()` +
    `renderIndex()` (login wall still gates the SPA); trust shape unchanged.
    Compatible with rc.3/rc.4 (which still export it) — fallback is
    version-agnostic. `src/gateway.ts` imports it locally.
  - `src/api-filter.ts`: `WIRE_SURFACE_DSH_VERSION = '0.2.2-alpha.2'`; +53
    methods classified — **user** (+27 total since rc.3): `forgePanel.*` 18
    (session-scoped worktree/PR panel, first param `sessionId`, ownership
    checked, same trust shape as `terminal.*`), `session.{events,observeEvent,
    observeProjections,observeState,state,wait}` 6, `toolResults.watch`,
    `actionCards.act`, `pluginRecommendations.describe`; **admin** (+26):
    `cuaAccess.*` 9 (CUA consent + host app inventory), `pluginManager.
    listVersions/readBundleDetail/updateBundle` + `pluginMarket.
    readEntryDetail` 4, `schedule.deleteInactive`, whole `liveshareShares`
    namespace 12 (upstream header: "Owner-only Remote surface" — external
    publishing/relay/identity/audit = operator territory; a user-scoped
    subset would need per-share ownership checks dsh-login doesn't model).
    Buckets **119 user / 79 admin / 1 host-internal = 199**, exhaustive and
    test-enforced.
  - `tests/fixtures/wire-surface.json`: re-dumped from a *built* alpha.2
    worktree (typert files are generated by `pnpm run typecheck`; npm
    tarballs don't ship them — dumping from an unpacked tarball yields 0
    methods). `tests/wire-surface.spec.ts`: buckets 119/79/1, no-checkout
    expects 199, live cross-check now generation-guarded (strict
    unclassified/vanished only when live registry size == fixture size, so
    the older-generation default checkout can't false-positive).
  - `package.json`: version 0.3.8; 11 dsh devDeps → `^0.2.2-alpha.2`; vendor
    devDeps → alpha vintage (cordis `~4.0.6-alpha.1`, schemastery
    `~3.18.6-alpha.1`, include `~1.0.11-alpha.1`, loader `~1.0.7-alpha.1`);
    peers extended with `|| >=0.2.2-alpha.2 <0.3.0-0` (prerelease tuple rule:
    `>=0.2.1-alpha.1 <0.3.0-0` doesn't match the `[0,2,2]` tuple) and vendor
    alpha branches.
- Verification: `npm install` clean after node_modules+lockfile reset (old
  lockfile wedged ERESOLVE against the alpha line); `npm test` = **21 files
  / 267 tests green** against the published alpha.2 builds; `npm run build`
  exit 0; `npm run verify:imports` all ok. README + README.zh banner/history/
  headline/tracking/evaluation updated; `docs/adapt-dsh-0.2.2-alpha.2.md`
  added (§5 classification table, §6 RBAC verdict); gotchas devDep pin
  updated. Committed, tagged `v0.3.8`, pushed, npm published (`latest`),
  GitHub release `v0.3.8` created.
- 15:40 manual re-verification (user-prompted, same day): fresh `git fetch`
  confirms no DSH release after alpha.2 (`origin/master` == `f3803c9697`, 0
  commits ahead; npm dist-tags unchanged `alpha=0.2.2-alpha.2`,
  `next=0.2.1-rc.4`); `npm test` re-run **21 files / 267 tests green** against
  the published alpha.2 builds; multi-user grep re-checked at the alpha.2 tag
  = still the single `packages/api/remote-access/README.md` hit (no native
  accounts). v0.3.8 tag confirmed on origin; nothing left to adapt.

## 2026-10-26 (12:00 scheduled watch) — no new DSH release; 0.3.7 stays current
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-26T04:00Z).
  Detection (fresh evidence, all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: newest tag
    still `dsh-v0.2.1-rc.3` (→ `1f81c047fc`, PR #6999 merge) — **no new tag**.
    origin/master tip = `22ddee3792` (PR #7075 chatgap merge) — **byte-identical
    to the 10-25 watch tip: 0 new commits since yesterday's watch**, still 1533
    commits beyond the rc.3 tag (unreleased backlog: liveshare-protocol #6748,
    desktop-packaging-cache #6675, session-baseline-split #7003,
    tab-scroll-animation #7054, windows-runner-network-recovery #7057). The
    10-25 post-rc.3 backlog heads-up (webserver resource routes #6901,
    liveshare-protocol package, typert resolvers) therefore still stands
    unchanged for the NEXT release watch. Local `dev` branch still at
    `687f282e86` (rc.2), dirty only CLAUDE.md + untracked agent dirs.
  - npm official registry: all 11 `@deepseek-ai/dsh-*` packages in the plugin
    graph (dsh, host-webserver, host-frontend-static, client-connection,
    credentials, settings, web-frontend, client-modules, scope, session,
    brand) still `next=0.2.1-rc.3` with `time.modified` 2026-10-23T07:34–
    07:56Z — the rc.3 publish window itself; **nothing published since**.
    `@deepseek-ai/dsh` `latest` stays `0.2.1-rc.2` / `next=0.2.1-rc.3`.
    `@deepseek-ai/dsh-liveshare-protocol` still NOT on npm (registry 404) —
    no npm-only release either.
  - Multi-user re-check at `origin/master` (= `22ddee3792`): grep
    `multi.?user|multiuser|role.?based|\brbac\b` over `packages/ apps/` =
    **1 hit** — `packages/api/remote-access/README.md` (the authorize-only
    non-owner-Peer substrate; identical to every watch since alpha.3). No
    native accounts upstream; dsh-login remains the multi-user layer.
    `__DSH_BOOT__` boot-graph lever intact
    (`packages/client/modules/src/index.ts:633`,
    `rows.push({ kind: 'global', name: '__DSH_BOOT__', value: graph })`) —
    uiRoleGate intact. Role-based whole-UI gating stays SHIPPED (0.3.0
    uiRoleGate + 0.3.1 bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version (rc.3 remains the newest release, already
  adapted + released as 0.3.7 on 10-24) → no adaptation needed.** dsh-login
  0.3.7 stays current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0`) + rc.3
  devDeps already cover the latest runtime. No code changes → no README fix,
  no release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **21 files / 267 tests green** (5.94 s) on the
  current tree (commit `fb302b4`, master == origin/master, clean); the
  wire-surface live cross-check against the `E:\code\deepseek-harness`
  checkout passed inside the suite (146-method registry unchanged).
- Changelog entry committed + pushed per the release-watch convention.

## 2026-10-25 (12:00 scheduled watch) — no new DSH release; 0.3.7 stays current
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-25T04:00Z).
  Detection (fresh evidence, all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: newest tag
    still `dsh-v0.2.1-rc.3` (→ `1f81c047fc`, 2026-10-23 11:29:36 +0800, PR
    #6999 merge) — **no new tag** since the 10-24 watch. origin/master tip =
    `22ddee3792` (2026-10-23 19:48:59 +0800, PR #7075 chatgap merge):
    **1533 commits beyond the rc.3 tag** — long-running branches merged after
    the release (liveshare-protocol #6748, desktop-packaging-cache #6675,
    session-baseline-split #7003, tab-scroll-animation #7054,
    windows-runner-network-recovery #7057) = unreleased backlog, no release
    cut. Local `dev` branch still at `687f282e86` (rc.2), dirty only CLAUDE.md
    + untracked agent dirs.
  - npm official registry: all 11 `@deepseek-ai/dsh-*` packages in the plugin
    graph (dsh, host-webserver, host-frontend-static, client-connection,
    credentials, settings, web-frontend, client-modules, scope, session,
    brand) still `next=0.2.1-rc.3` with `time.modified` 2026-10-23T07:34–
    07:55Z — the rc.3 publish window itself; **nothing published since**.
    `@deepseek-ai/dsh` `latest` stays `0.2.1-rc.2` / `next=0.2.1-rc.3`
    (`web-frontend`'s `latest` dist-tag still stale at `0.0.1-rc.5` — use
    `next`). New package `@deepseek-ai/dsh-liveshare-protocol` NOT on npm
    (registry 404) — no npm-only release either.
  - Post-rc.3 backlog heads-up for the NEXT release watch (all unreleased at
    tip): `feat(webserver): add resource routes and in-process readResource`
    (#6901 — `WebResourceRoute`/`WebResource` types; `renderIndex`/
    `collectIndexInjections` take a `peer`, `webserver/index-inject` fires
    `(table, peer)` per `docs/upgrade-guide/v0.2.1-rc.2/webserver-index-peer/`;
    dsh-login's `index.ts:235` listener consumes only `table` → compatible as
    a listener; dsh-login does not call `renderIndex`); new
    `@deepseek-ai/dsh-liveshare-protocol` package; typert default resource
    resolvers. Verified at the tip: rc.3 itself still emits the one-arg
    `webserver/index-inject(table)`, so the published runtime is unaffected.
- Multi-user re-check at `origin/master` (= `22ddee3792`): grep
  `multi.?user|multiuser|role.?based|\brbac\b` over `packages/ apps/` =
  **1 hit** — `packages/api/remote-access/README.md` (the authorize-only
  non-owner-Peer substrate; identical to every watch since alpha.3). No
  native accounts upstream; dsh-login remains the multi-user layer.
  `__DSH_BOOT__` boot-graph lever intact
  (`packages/client/modules/src/index.ts:633`,
  `rows.push({ kind: 'global', name: '__DSH_BOOT__', value: graph })`) —
  uiRoleGate intact. Role-based whole-UI gating stays SHIPPED (0.3.0
  uiRoleGate + 0.3.1 bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version (rc.3 remains the newest release, already
  adapted + released as 0.3.7 yesterday) → no adaptation needed.** dsh-login
  0.3.7 stays current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0`) + rc.3
  devDeps already cover the latest runtime. No code changes → no README fix,
  no release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **21 files / 267 tests green** (5.79 s) on the
  current tree (commit `15db686`, master == origin/master, clean).
- Changelog entry committed + pushed per the release-watch convention.

## 2026-10-24 (12:00 scheduled watch) — NEW DSH 0.2.1-rc.3 → adapted + RELEASED 0.3.7
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-24T04:00Z).
  Detection (fresh evidence, all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: new tag
    `dsh-v0.2.1-rc.3` → `1f81c047fc` (2026-10-23 11:29:36 +0800, PR #6999
    merge); previous tag `dsh-v0.2.1-rc.2` → `687f282e86`. **6 commits**
    rc.2..rc.3 (release bump `d02ea370ee`; #6944 llm `/models` listing re-home
    `c48f8523f2`; #6883 nav pins/menu icons `39d2903841`; #6600 analytics
    tracking `675164957a`; #6247 navigation entry customization
    `5ff29190ed`). Local `dev` branch still at 687f282e86 (rc.2), dirty only
    CLAUDE.md + untracked agent dirs.
  - npm official registry: `@deepseek-ai/dsh` dist-tags
    `{latest: 0.2.1-rc.2, next: 0.2.1-rc.3, alpha: 0.2.1-alpha.5}`,
    time.modified 2026-10-23T07:54Z. All ten `@deepseek-ai/dsh-*` devDep
    peers published at `0.2.1-rc.3` (each verified via `npm view`;
    `dsh-web-frontend`'s `latest` dist-tag still points at stale
    `0.0.1-rc.5` — use `next`). Vendored pins unchanged (cordis 4.0.5,
    schemastery 3.18.5, include 1.0.10, loader 1.0.6); one transitive tool
    3.1.8 → 3.1.9.
  - Multi-user re-check: rc.2..rc.3 diff analysis + boot-graph lever intact
    (`packages/client/modules/src/index.ts` zero diff). No native accounts,
    no per-identity UI gate; `uiRoleGate` intact; role-based whole-UI gating
    stays SHIPPED (0.3.0 + 0.3.1) — evaluation closed, unchanged.
- **Upstream surface (full analysis in `docs/adapt-dsh-0.2.1-rc.3.md`): the
  whole adapter surface is SOURCE-UNCHANGED.** rc.3 is a client-UI-only
  release (640 files, mostly tests/snapshots/bumps): NEW `ui-entry-customization`
  package, ui-sidebar `panel-pins.ts`, ui-sidebar-right `guide-pins.ts`,
  ui-conversation `view-pins.ts` (+2-line slots.ts), ui-primitives Menu/
  Tooltip, ui-workspace `navigation.ts`, llm catalog re-home
  (`llm-deepseek-account` → `llm-deepseek`), product-analytics events. No new
  wire method or namespace — the api-catalog change is doc strings + a client
  type `AnalyticsPreset = 'creator'|'ptc'|'minimal'|'standard'`.
  Mechanically verified: `node scripts/dump-wire-surface.mjs --checkout
  E:\code\deepseek-harness --version 0.2.1-rc.3` → 146 methods, the ordered
  method list byte-identical to the committed rc.2 snapshot (Compare-Object
  diff count 0). No new admin-only community client bundle →
  `ADMIN_ONLY_UI_PLUGINS` unchanged.
- **Changes shipped (0.3.7):** `version` 0.3.6 → 0.3.7; 10 dsh-* devDeps
  `^0.2.1-rc.2` → `^0.2.1-rc.3`. **Own peers unchanged** (the
  `>=0.2.1-alpha.1 <0.3.0-0` branch already admits rc.3).
  `src/api-filter.ts`: metadata only — `WIRE_SURFACE_DSH_VERSION = '0.2.1-rc.3'`
  + header note (classification byte-identical to rc.2's registry; rc.3
  touched only the client UI). `tests/fixtures/wire-surface.json` regenerated
  at rc.3 (method list unchanged). **No other source changes** (the
  `remote-guard.ts:81` "DSH 0.2.1-rc.2 (dsh-login 0.3.6, issue #4)" comment
  stays — it documents when those namespaces were first listed). dist
  rebuilt: `dist/client.js` byte-identical; `dist/index.js`/`.map` re-stamp
  the version constant.
- **Verification:** baseline `vitest run` **21 files / 267 tests green** on
  the rc.2 tree BEFORE the retarget (proves rc.3 compatibility of the current
  code), then again against the rc.3 builds after it — 267/267 both times;
  `npm run build` exit 0 (`dist/client.js` 37134 chars); `npm run
  verify:imports` ok.
- Docs: README/README.zh banner + headline + adaptation history + tracking +
  evaluation updated (0.3.7 / rc.3, re-verified 2026-10-24; L168/L164
  "92 of the 146 methods DSH 0.2.1-rc.3 actually exposes"); new
  `docs/adapt-dsh-0.2.1-rc.3.md`; gotchas.md devDep-pin + dist-restamp notes
  updated. `docs/PROJECT-INDEX.md` deliberately NOT touched — it is a
  v0.1.0-era snapshot last updated in August; no release since 0.3.4 has
  updated it (stale, flagged).
- Release: commit `27eed37` + tag `v0.3.7` + push (master `e2f6053..27eed37`,
  tag `* [new tag] v0.3.7`); npm publish exit 0 via the `.env`
  `NPM_ACCESS_TOKENS` temp-npmrc flow (temp file deleted, token never
  printed; unpacked 744.3 kB, shasum `e5c5fe32…`, 36 files); registry
  verified `dist-tags.latest = 0.3.7` after the ~60s lag; gh release
  https://github.com/islibaodong/dsh-login/releases/tag/v0.3.7.

## 2026-10-23 (manual watch) — no new DSH release; 0.3.6 stays current
- Manual release watch (user-requested, session 2026-10-23T14:48+08:00).
  Detection (fresh evidence, all channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness` (clean):
    newest tag still `dsh-v0.2.1-rc.2` (→ `687f282e86`, the release merge
    PR #6408); `git rev-list dsh-v0.2.1-rc.2..origin/master --count` = **0**
    — no commits past the release merge; local `dev` == `origin/master` ==
    the tag commit (checkout CLAUDE.md dirty + untracked agent dirs only,
    no source drift).
  - npm official registry: `@deepseek-ai/dsh` dist-tags
    `{latest: 0.2.1-rc.2, next: 0.2.1-rc.2, alpha: 0.2.1-alpha.5}` — the
    `latest` tag now ALSO sits on rc.2 (published 2026-10-17T08:24Z); all
    six `@deepseek-ai/dsh-*` peers (web-frontend, host-webserver,
    host-frontend-static, settings, client-connection, credentials) still
    `alpha=0.2.1-alpha.5` / `next=0.2.1-rc.2`, `time.modified` 2026-10-17 —
    no publish since rc.2. Vendored pins stable: cordis `4.0.5`,
    schemastery `3.18.5`, include `1.0.10`, loader `1.0.6`.
    `@islibaodong/dsh-login` `latest=0.3.6` (published 2026-10-21, time.modified
    2026-10-21T08:51Z — the current release; nothing newer).
  - Multi-user re-check at `origin/master` (= the tag commit): grep
    `multi.?user|multiuser|role.?based|\brbac\b` over `packages/` + `apps/`
    (rg, tests excluded) = **1 hit** — `packages/api/remote-access/README.md`
    (the authorize-only non-owner-Peer substrate; identical to the 10-18 and
    10-19 verdicts). No native accounts upstream; dsh-login remains the
    multi-user layer. `__DSH_BOOT__` boot-graph lever intact
    (`packages/client/modules/src/index.ts:592`,
    `rows.push({ kind: 'global', name: '__DSH_BOOT__', value: graph })`)
    — uiRoleGate intact. Role-based whole-UI gating stays SHIPPED
    (0.3.0 uiRoleGate + 0.3.1 bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.6 remains current (last-adapted runtime 0.2.1-rc.2 IS the current
  npm `latest`); peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` + the rc.2 devDeps)
  already cover the latest runtime. No code changes → no README fix, no
  release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **21 files / 267 tests green** (5.92 s) on the
  current tree (commit `c39eab2`); node_modules verified in place at
  `0.2.1-rc.2` × 10 + cordis 4.0.5 / schemastery 3.18.5 / include 1.0.10 /
  loader 1.0.6 — the wire-surface live cross-check against the checkout
  passed inside the suite.
- Changelog entry committed + pushed per the release-watch convention.
- **Follow-up same day (user request): README restructure.** In both
  `README.md` and `README.zh.md` the problem-statement section
  (`## The problem it solves` / `## 这个插件解决什么问题`) moved to the very
  top (right after the intro + screenshots, L11-23), and the huge
  `> **Released:**` / `> **已发布：**` + adaptation-history blockquotes moved
  down inside `## Current status` / `## 当前状态` (now directly under that
  heading). Pure line re-ordering, no content edits; line counts unchanged
  (300 / 284), CRLF preserved. Motivation: the release-notes wall of text was
  burying the repo introduction.

## 2026-10-21 — 0.3.6: issue #4 fix (ordinary-user allow-list drifted off the 0.2.1-rc.2 wire surface)
- **Report** (issue #4, author lingistic123, DSH 0.2.1-rc.2 + dsh-login 0.3.5):
  ordinary users get `not permitted for this user` on (1) add-workspace,
  (2) the composer model dialog, (3) settings → models ("加载提供商目录失败").
  Admins unaffected. Root cause: `USER_ALLOWED` was written against the
  **pre-0.2 spelling set** (`session.models`, `session.history`,
  `llm.providers`/`llm.models`, `skill.list`, `goal.*`, `subagent.*`,
  `host.describe`, `workspace.list`, `respond`, `workspaceFiles.readAll`/
  `readRelated`) — every entry a dead name on rc.2 — while the real names
  (`session.modelCatalog`, `llm.listProviders`, `directoryPicker.*`, …) were
  absent, so `api-bridge-auth.ts` denied them at the method gate.
- **Fix**: `src/api-filter.ts` rewritten as an **exhaustive** classification of
  the 146-method registry: `USER_ALLOWED` (92), `ADMIN_ONLY_METHODS` (53),
  `HOST_INTERNAL_METHODS` (1, `workspace.initializeDefault`), plus
  `classifyWireMethod()`/`isKnownWireMethod()`; `WIRE_SURFACE_DSH_VERSION =
  '0.2.1-rc.2'`. New `scripts/dump-wire-surface.mjs` (re-derives the list from
  a DSH checkout) and `tests/fixtures/wire-surface.json` (vendored snapshot),
  guarded by `tests/wire-surface.spec.ts` (9 cases: no unclassified method, no
  dead entry, buckets disjoint + sizes 92/53/1, live cross-check against the
  checkout, each issue-#4 method user-reachable, each retired spelling gone).
- `src/capabilities.ts`: `USER_DOMAINS`/`adminOnlyMethods()`/`allDomains()` are
  now derived from the buckets; `QUIET_DENY_METHODS` re-spelled to real names;
  `isReadProbe()` matches read verbs as prefixes (`listProviders`,
  `listIndexes`, `discoverModels`) instead of exact words.
- `src/remote-guard.ts`: `ADMIN_ONLY_NAMESPACES` += `pluginInventory`,
  `pluginRegistryProbe`, `dynamicCordisRunner`, `claudeCodeMods`.
- `src/api-bridge-auth.ts` + `src/index.ts`: unknown-method denials (not on this
  build's wire surface) are reported **once per method** through `ctx.logger`
  (fallback `console.warn`) with the target DSH version — an upstream rename is
  now a host-log diagnostic instead of a silent user lockout.
- Policy call: `directoryPicker.pick`/`list`/`createDirectory` **admitted** to
  ordinary users (issue #4's own recommendation). Rationale: the privilege
  boundary is `workspace.create`, still confined to the caller's sandbox, and
  `terminal.*` already lets users run shell as the same system user — no new
  capability class. README troubleshooting section rewritten accordingly.
- Docs: README/README.zh "two-layer model" re-spelled to real names (+ 0.3.6
  headline, 21 files/267 tests), `docs/compose-guard.md`,
  `docs/verify-option-A.md`, new `docs/adapt-dsh-0.2.1-rc.2-issue-4.md`.
- Tests: 267/267 green (21 files). Bundle rebuilt (`dist/index.js` carries the
  new surface). Published as 0.3.6.


## 2026-10-19 (12:00 scheduled watch) — no new DSH release; 0.3.5 stays current
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-19T04:00Z).
  Fresh evidence, all three channels, all unchanged since the 10-18 watch:
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness` (clean,
    exit 0, no TLS-EOF retry needed): newest tag still `dsh-v0.2.1-rc.2`
    (→ `687f282e86`, the release merge PR #6408); `git rev-list
    dsh-v0.2.1-rc.2..origin/master --count` = **0** — no commits past the
    release merge.
  - npm official registry (`/-/package/<pkg>/dist-tags` + `time.modified`):
    all six `@deepseek-ai/dsh-*` peers (web-frontend, host-webserver,
    host-frontend-static, settings, client-connection, credentials) still
    `alpha=0.2.1-alpha.5` / `next=0.2.1-rc.2`, `time.modified` all
    2026-10-17 — no publish since rc.2. Vendored pins unchanged at the
    stable re-release (cordis `latest=4.0.5`, schemastery `3.18.5`, include
    `1.0.10`, loader `1.0.6`; modified 2026-10-16). `@islibaodong/dsh-login`
    `latest=0.3.5` (modified 2026-10-18 — yesterday's publish).
  - Multi-user re-check at `origin/master` (= the tag commit): grep
    `multi.?user|multiuser|role.?based|\brbac\b` over `packages/ apps/` =
    **1 hit** — `packages/api/remote-access/README.md` (the authorize-only
    non-owner-Peer substrate; identical to the 10-18 verdict). No native
    accounts upstream; dsh-login remains the multi-user layer.
    `__DSH_BOOT__` boot-graph lever intact
    (`packages/client/modules/src/index.ts:592`,
    `rows.push({ kind: 'global', name: '__DSH_BOOT__', value: graph })`)
    — uiRoleGate intact. Role-based whole-UI gating stays SHIPPED
    (0.3.0 uiRoleGate + 0.3.1 bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.5 remains current (last-adapted runtime 0.2.1-rc.2 IS the current
  latest); peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` + the rc.2 devDeps)
  already cover the latest runtime. No code changes → no README fix, no
  release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **20 files / 256 tests green** (5.61 s) on the
  current tree (commit `c30e3b6`) against devDeps `^0.2.1-rc.2`.
- Changelog entry committed + pushed per the release-watch convention.

## 2026-10-18 (watch) — NEW DSH 0.2.1-alpha.5 / rc.1 / rc.2 → adapted + RELEASED 0.3.5
- Detection (both channels):
  - npm official registry: `@deepseek-ai/dsh-host-webserver` dist-tags
    `{alpha: 0.2.1-alpha.5, next: 0.2.1-rc.2, latest: 0.0.1-rc.1}` — the alpha
    tag moved alpha.4 → alpha.5; rc.2 is the newest published build. (Bare
    `dsh` npm name still `latest: 1.0.1` — a different package; keep using
    `@deepseek-ai/dsh*`.)
  - git tags: `dsh-v0.2.1-alpha.5` → `1517a4dbca` (2026-10-16 19:02:34, PR
    #6327); `dsh-v0.2.1-rc.1` → `1600d8a1e1` (2026-10-16 21:46:57, PR #6387);
    `dsh-v0.2.1-rc.2` → `687f282e86` (2026-10-17 15:22:43, PR #6408).
    alpha.4..rc.2 = **49 commits** (36 + 4 + 9); 533 files +6073/−1146.
- **Upstream surface (full analysis in `docs/adapt-dsh-0.2.1-rc.2.md`): the
  whole adapter surface is SOURCE-UNCHANGED.** Every integration point
  (`host/webserver`, `client/connection`, `settings`, `host/frontend-static`,
  `client/modules` boot graph, `client/runtime` + `ui-slots`, `web-app`,
  `app-boot`, gateway/remotes, plugin-manager/-market) changed only in
  `package.json`; all `/api` controllers (session/workspace/terminal/settings/
  job/account/plugin-*/remote-*/remotes) have **zero src diff** → the wire
  method registry is unchanged, `USER_ALLOWED`/`ADMIN_ONLY_*` need no edits.
  - Vendor re-release (PR #6388) moved the vendored packages to **stable**:
    cordis `4.0.5`, cosmokit `1.8.6`, group `1.0.5`, hmr `1.0.20`, include
    `1.0.10`, loader `1.0.6`, logger-console `1.0.5`, schemastery `3.18.5`,
    timer `1.1.7`. The npm `dsh-0-2-1-alpha-3` vendor dist-tags stayed at the
    alpha vintages → pin the STABLE releases. All rc.2 dsh packages peer
    `cordis ~4.0.5` (settings also `schemastery ~3.18.5`);
    `dsh-client-connection`'s peers are now `cordis ~4.0.5` + `dsh-scope
    0.2.1-rc.2` (no longer direct session/brand peers).
  - NEW packages, none a wire/typert surface: `web/web-deepseek-api`
    (registers `deepseek-search-api`/`deepseek-fetch-api` into `ctx.web` —
    agent-side providers), `client/ui-deepseek-model-label-1017` (native 1017
    badge UI), `client/ui-settings-web-search` (settings card).
  - `api/terminal-controller` got client-only additions (`src/client/
    inventory.ts` etc.); its `src/index.ts` + server half are zero-diff → no
    new wire methods.
  - Multi-user verdict: still **no native accounts** — the recurring
    `multi.?user|multiuser|role.?based|\brbac\b` grep yields the same single
    hit (`packages/api/remote-access/README.md`, the authorize-only
    non-owner-Peer substrate; dsh-login users are owner principals).
    Whole-UI role gating still not natively implementable (runtime/ui-slots
    unchanged, no `isAdmin`/`isAllowed`/account `role`); dsh-login's
    `uiRoleGate` remains THE answer, boot-graph lever intact.
- **Changes shipped (0.3.5):** `version` 0.3.4 → 0.3.5; 10 dsh-* devDeps
  `^0.2.1-alpha.4` → `^0.2.1-rc.2`; vendor pins alpha → stable (cordis
  `~4.0.5`, schemastery `~3.18.5`, include `~1.0.10`, loader `~1.0.6`).
  **Own peers unchanged** (the `>=0.2.1-alpha.1 <0.3.0-0` branch admits
  alpha.5/rc.1/rc.2; `~4.0.5-alpha.1` admits stable). **No source changes.**
  dist rebuilt and byte-identical (`git hash-object` == the index blobs).
- **Verification:** `npm install` no ERESOLVE (21 lockfile version rows);
  node_modules = `0.2.1-rc.2` × 10 + cordis 4.0.5 / schemastery 3.18.5 /
  include 1.0.10 / loader 1.0.6; `vitest run` **20 files / 256 tests green**
  (baseline on alpha.4 was also 256/256); `npm run build` exit 0
  (`dist/client.js` 37134 chars); `npm run verify:imports` ok. Two-browser
  isolation sign-off remains deployment-side.
- **Release:** README/README.zh banner + history + status + tracking +
  evaluation updated (0.3.5 / rc.2, re-verified 2026-10-18); commit `f27375a`,
  tag `v0.3.5` (`f6fa9d1e…`) + push; npm publish via the `.env`
  `NPM_ACCESS_TOKENS` temp-npmrc (temp `.npmrc.publish` deleted immediately,
  token never printed) — registry verified **`latest = 0.3.5`**, tarball 35
  files / 206.5 kB / shasum `7efde2f1…`; gh release
  https://github.com/islibaodong/dsh-login/releases/tag/v0.3.5.

## 2026-10-16 (watch) — NEW DSH 0.2.1-alpha.4 → adapted + RELEASED 0.3.4
- Detection (fresh evidence, both channels):
  - npm official registry: `@deepseek-ai/dsh` dist-tags
    `{latest: 0.2.0-rc.2, next: 0.2.0-rc.2, alpha: 0.2.1-alpha.4}` — the
    `alpha` tag moved alpha.3 → alpha.4 (stable channel unmoved). (Side note:
    the bare `dsh` npm name now shows `latest: 1.0.1` — a different package,
    not upstream's; keep using `@deepseek-ai/dsh`.)
  - git tag `dsh-v0.2.1-alpha.4` → `86a402200d` (2026-10-15 20:22:44 +0800,
    PR #6301 merge; checkout master == the tag); alpha.3 tag `2fbf4359b8`;
    **89 commits** alpha.3..alpha.4. Source inspected read-only at the tag
    (no worktree needed — checkout HEAD already at alpha.4).
- **Upstream surface (full analysis in `docs/adapt-dsh-0.2.1-alpha.4.md`):**
  - NEW `packages/boot/plugin-market`: market index list + bundle install;
    typert namespace **`pluginMarket`** (`listIndexes`/`setIndexes`/`search`,
    emits `plugin-market/changed`). `setIndexes` reconfigures the
    instance-wide index list → admin-only wholesale, mirroring
    `pluginManager`. Gated in all three dsh-login layers.
  - Boot graph carries a **`release`** stamp
    (`packages/client/modules/src/index.ts:636` `this.release = {version,
    commit?}`; attached at `:826`; commit from `DSH_CLIENT_COMMIT_HASH`) —
    release-identity plumbing for client reload gating, NOT a permission
    axis. `filterBootGraph` passes it through; regression-tested.
  - webserver exports intact (`bindUrlHost` :210, `getOrigin` :351,
    `renderIndex` :584 → `applyIndexTaps(...)`); `web-runtime.ts` untouched;
    `terminal.attach` (:216) and `remoteAccess.follow` (:271) unchanged; boot
    admission wording now "requirements", `engines.dsh` first,
    `includePrerelease: true` — dsh-login (no engines.dsh, peers admit
    alpha.4) unaffected.
  - Multi-user verdict: **no native accounts**, no new grep hits; remote-access
    substrate unchanged; whole-UI role gating still not natively implementable
    → dsh-login's own `uiRoleGate` (0.3.0) remains THE answer. Evaluation
    closed.
- **Changes shipped (0.3.4):** devDeps `^0.2.1-alpha.3` → `^0.2.1-alpha.4`
  (13 dsh-* rows; vendor alphas unchanged; own peers already admitted
  alpha.4); `src/remote-guard.ts` ADMIN_ONLY_NAMESPACES += `pluginMarket`;
  `src/capabilities.ts` two-segment deny + adminOnlyMethods(all three) +
  allDomains + QUIET_DENY_METHODS(`listIndexes`/`search` read probes;
  `setIndexes` loud 403); +3 tests (capabilities three-layer, remote-guard
  deny/pass, ui-gate `release` preservation). NO `USER_ALLOWED` /
  `ADMIN_ONLY_UI_PLUGINS` / `ui-gate.ts` changes.
- Verification: install (21 pkgs changed, dsh builds = alpha.4), vitest
  **20 files / 256 tests green** (253 + 3), build exit 0, verify:imports ok.
- Released: docs (README ×2, adapt doc, changelog), commit `03fb779` + tag
  `v0.3.4` + push, **npm publish completed 2026-10-16 (~17:55 +08:00)** via
  `.env` `NPM_ACCESS_TOKENS` temp-npmrc flow (temp file deleted, token never
  printed; registry propagation <1 min — dist-tags.latest=0.3.4 verified via
  Invoke-RestMethod on the official registry), gh release
  https://github.com/islibaodong/dsh-login/releases/tag/v0.3.4
  (--generate-notes).

## 2026-10-15 (12:00 scheduled watch) — NEW DSH 0.2.1-alpha.3 → adapted + RELEASED 0.3.3
- Scheduled cron run (`0 12 * * *` Asia/Shanghai). Detection (fresh evidence,
  all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness` (clean, no
    TLS retry): new tag `dsh-v0.2.1-alpha.3` (commit `2fbf4359b8`);
    `origin/master` = `571902028a` — **868 commits** past the alpha.2 merge
    `d743267388`, 16 past the tag. Diff alpha.2..alpha.3 over `packages/` +
    `apps/`: 2404 files, +74908/−11541 (188 plugin-visible). Local `dev`
    worktree stale at alpha.2 → detached worktree
    `E:\code\deepseek-harness-wt-alpha3` @ the tag for source inspection
    (kept).
  - npm official registry: all six `@deepseek-ai/dsh-*` peers re-published at
    `alpha=0.2.1-alpha.3` (web-frontend `time.modified` 2026-10-14T12:37Z);
    `next=0.2.0-rc.2`. Vendored packages RE-PUBLISHED for alpha.3 (dist-tag
    `dsh-0-2-1-alpha-3`): cordis `4.0.5-alpha.2`, schemastery `3.18.5-alpha.2`,
    cordis-plugin-include `1.0.10-alpha.2`, cordis-plugin-loader
    `1.0.6-alpha.2`. dsh-login npm `latest` = 0.3.2 before this release.
  - Multi-user grep at the tag (`multi.?user|multiuser|role.?based|\brbac\b`
    over packages/ + apps/): **1 hit** — `packages/api/remote-access/README.md`
    (first hit in six watches — NEW package). `__DSH_BOOT__` lever intact
    (`packages/client/modules/src/index.ts:585`).
- **Upstream surface (subagent-diffed alpha.2..alpha.3; full analysis in
  `docs/adapt-dsh-0.2.1-alpha.3.md`):**
  - NEW `packages/api/remote-access`: authorize-only RBAC for NON-owner Peers
    (`Principal`/`PrincipalMap` owner-only today; `registerPolicy`/`decide`;
    owner baseline injected as `__DSH_REMOTE_ACCESS__`; `remoteAccess.follow`
    is the one always-allowed method, answering only the caller's own grants).
    dsh-login users are owner principals (v1 cookie → `browserPeer
    {kind:'owner'}`) → never gated by it. **NO native user accounts** —
    dsh-login remains the account/authn layer. Multi-principal machinery:
    `createPeer`/`admitConnection`, v2 API cookies `{version:2,id:PeerId}`,
    `GET /connect` exchange, socket-ownership 409.
  - Terminal BREAKING: `terminal.follow` → `terminal.attach` (bidirectional;
    uplink write/resize as sequenced commands); `terminal.write`/`resize`
    methods REMOVED.
  - Gateway BREAKING internals: `inject: ['typert','remoteAccess']`;
    `InvokeRemoteRequest.peer` REQUIRED; `admitConnection`; new RemoteError
    codes. dsh-login's `wrapRemoteGateway` spread-wrap unaffected (overrides
    only invoke/stream; implements no PeerScope).
  - web-app bundle split: prompt sections moved to NEW enabled
    `harness-dev-context` row (`inject: ['systemPrompt','sessionProjections',
    'webApp']`) → **webApp injection would fail** with dsh-login's disabled
    web-runtime row (the sole upstream webApp provider).
  - webserver additive: `getOrigin()` (throws pre-bind), `get port()`,
    `bindUrlHost()`. client-connection host-half refactor (peer.ts, v2
    cookies) — no option-A impact; client half dual exports
    `client.node.js`/`client.browser.js` (logical `/plugins/<pkg>/client.js`
    URL unchanged). credentials precedence flip (managed file > env > .env;
    `assertUnshadowed` deleted) — net-positive, compatible. modules: only a
    node-chunk guard — boot-graph lever intact.
- **Changes shipped (0.3.3):**
  - `package.json` version → `0.3.3`; 10 dsh devDeps → `^0.2.1-alpha.3`;
    vendor pins → cordis `~4.0.5-alpha.2`, schemastery `~3.18.5-alpha.2`,
    include `~1.0.10-alpha.2`, loader `~1.0.6-alpha.2`. **Peers unchanged**
    (tuples already admit alpha.3 + same-tuple vendor alphas).
  - `src/web-runtime.ts`: `provideWebRuntime` now also provides **`webApp`**
    (`advertisedUrl(ctx)` feature-detects `webServer.getOrigin()` with
    try/catch → fallback `http://<urlHost(host)>:<port>`; `''` when absent;
    read is lazy per-session context assembly) so the alpha.3
    `harness-dev-context` row injects. `cordis.patch.yml` UNCHANGED.
  - `src/api-filter.ts` `USER_ALLOWED`: − `terminal.follow`/`write`/`resize`,
    + `terminal.attach`, + `remoteAccess.follow`. `src/capabilities.ts` flows
    from `USER_ALLOWED` — no change. No change to `remote-guard.ts`,
    `bridge-list-filter.ts`, `ui-gate.ts`, `gateway.ts`.
  - `dist/client.js` regenerated (`build:client` gotcha after the
    client-connection bump).
  - Tests: NEW `tests/web-runtime.spec.ts` (5 unit tests; fake ctx mirrors
    cordis semantics — provide() must also set ctx[name]); `plugin-entry.spec.ts`
    + real-composition webApp assertion on a booted alpha.3 HttpServer;
    `capabilities.spec.ts` + `remote-guard.spec.ts` updated for the new
    terminal surface. Suite **20 files / 253 tests green** (5.67 s);
    `npm run build` + `verify:imports` ok. ERESOLVE wedge hit again →
    node_modules + lockfile deleted, fresh install (109 packages).
  - README.md / README.zh.md: 0.3.3 banner + adaptation history + new
    "Upstream multi-user / RBAC evaluation" sections (no native accounts;
    first RBAC substrate for non-owner Peers; dsh-login users stay owner
    principals; future option: register remote-access policies per role).
- **Conclusion: NEW DSH version required adaptation → 0.3.3 RELEASED** (npm
  publish + git tag `v0.3.3` + master push). Multi-user verdict recorded:
  alpha.3 = substrate only, no accounts; dsh-login's walls remain the
  boundary.
- **npm publish completion note (14:14):** first publish attempts failed
  (`npm whoami` 401, publish PUT 404-masked auth) — the `~/.npmrc`
  `//registry.npmjs.org/:_authToken` line (untouched since 09-30) is dead on
  the official registry. `--otp` / `NPM_CONFIG_OTP` retries changed nothing
  (auth layer, not OTP). WORKING AUTH SOURCE: `E:\code\dsh-login\.env`
  (git-ignored, LastWrite 2026-10-12) exports `NPM_ACCESS_TOKENS` (40-char
  `npm_` granular token) — publish via temp npmrc
  (`Set-Content .npmrc.publish` with
  `//registry.npmjs.org/:_authToken=<token>` → `npm publish --access public
  --registry=https://registry.npmjs.org --userconfig .npmrc.publish`), then
  DELETE the temp file (done immediately after). Publish verified live:
  `0.3.3` in dist-tags `latest`, `time["0.3.3"]` =
  2026-10-15T06:14:08Z (mirror lag ~2 min; the first two post-publish
  `npm view` reads still showed 0.3.2 — wait ~60 s before re-checking).
  Future watches: go straight to the `.env` token when `~/.npmrc` auth
  fails; never commit or paste the token.

## 2026-10-14 (14:57 watch) — no new DSH release; 0.3.2 stays current
- Scheduled release watch (session started 2026-10-14T14:57+08:00 — ran after
  the 12:00 cron slot). Detection (fresh evidence, all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: first
    attempt hit the recurring TLS-EOF; the documented
    `git -c http.version=HTTP/1.1` retry (gotchas.md) succeeded (exit 0).
    Newest tag still `dsh-v0.2.1-alpha.2` (2026-10-09); `origin/master` tip
    = `d743267388` (the release merge, PR #5946);
    `git rev-list d743267388..origin/master --count` = **0** — no commits
    past the release merge.
  - npm official registry: all six `@deepseek-ai/dsh-*` peers
    (web-frontend, host-webserver, host-frontend-static, settings,
    client-connection, credentials) still `alpha=0.2.1-alpha.2` /
    `next=0.2.0-rc.2`; `web-frontend time.modified` 2026-10-09T08:17Z —
    no publish since 10-09. Vendored pins unchanged: `@deepseek-ai/cordis`
    `dsh-0-2-1-alpha-1` still 4.0.5-alpha.1 (time.modified 2026-10-03);
    schemastery `latest` still 3.18.0 (time.modified 2026-03-09, no `dsh-*`
    dist-tag — 10-13 note stands). Data point: unscoped `cordis` (koishi
    mainline, NOT the vendored fork) published 4.0.0-rc.11 today —
    irrelevant to the plugin's `@deepseek-ai/cordis` pin; do not mistake it
    for a vendor re-publish.
  - Multi-user re-check at `origin/master` (= tag commit `d743267388`):
    `git grep -ilE 'multi.?user|multiuser|role.?based|\brbac\b' -- packages/
    apps/` = **0 hits** — upstream still has no native multi-user; dsh-login
    remains the multi-user layer. `__DSH_BOOT__` boot-graph lever still
    present (`packages/client/modules/src/index.ts:585`,
    `rows.push({ kind: 'global', name: '__DSH_BOOT__', value: graph })`) —
    uiRoleGate intact. Role-based whole-UI gating stays SHIPPED (0.3.0
    uiRoleGate + 0.3.1 bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.2 remains current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` on all six
  dsh peers) already cover the latest runtime. No code changes → no README
  fix, no release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **19 files / 247 tests green** (5.57 s) on the
  current tree (commit `d1f6915`) against devDeps `^0.2.1-alpha.2`.

## 2026-10-13 (12:00 scheduled watch) — no new DSH release; 0.3.2 stays current
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-13T04:00Z).
  Detection (fresh evidence, all three channels):
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness`: newest
    tag still `dsh-v0.2.1-alpha.2` (2026-10-09); `origin/master` tip =
    `d743267388` (the release merge, PR #5946);
    `git rev-list d743267388..origin/master --count` = **0** — no commits
    past the release merge. (Local `dev` tip also = `d743267388`.)
  - npm official registry: all six `@deepseek-ai/dsh-*` peers
    (web-frontend, host-webserver, host-frontend-static, settings,
    client-connection, credentials) still `alpha=0.2.1-alpha.2` /
    `next=0.2.0-rc.2`; `web-frontend time.modified` 2026-10-09T08:17Z —
    no publish since 10-09. Vendored cordis/schemastery not re-published
    (no `dsh-*` dist-tags on npm; time.modified 2026-09-08 / 2026-03-09) —
    vendor pins unchanged.
  - Multi-user re-check at `origin/master` (= tag commit `d743267388`):
    `git grep -ilE 'multi.?user|multiuser|role.?based|\brbac\b' -- packages/
    apps/` = **0 hits** — upstream still has no native multi-user; dsh-login
    remains the multi-user layer. Role-based whole-UI gating stays SHIPPED
    (0.3.0 uiRoleGate + 0.3.1 bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.2 remains current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` on all six
  dsh peers) already cover the latest runtime. No code changes → no README
  fix, no release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **19 files / 247 tests green** (5.46 s) on the
  current tree (commit `8e7c888`) against devDeps `^0.2.1-alpha.2`.

## 2026-10-12 (16:42 watch) — no new DSH release; 0.3.2 stays current; pending 10-11 entry committed
- Scheduled release watch (manual session). Fresh evidence, all three channels:
  - `git fetch origin --tags --prune` in `E:\code\deepseek-harness` (clean):
    newest tag still `dsh-v0.2.1-alpha.2` (peeled commit `d743267388` = the
    release merge, PR #5946); `git rev-list d743267388..origin/master --count`
    = **0**; local `dev` == `origin/master` (0/0).
  - npm official registry, all six `@deepseek-ai/dsh-*` peers
    (web-frontend, host-webserver, host-frontend-static, settings,
    client-connection, credentials): dist-tags `alpha=0.2.1-alpha.2`
    (`time.modified` 2026-10-09 — no publish since), `next=0.2.0-rc.2`;
    cordis/schemastery `time.modified` 2026-10-03 — vendor pins unchanged.
  - Multi-user re-check at `origin/master` (= the tag commit):
    `git grep -ilE 'multi.?user|multiuser|role.?based|\brbac\b' -- packages/
    apps/` = **0 hits** — upstream still has no native multi-user; dsh-login
    remains the multi-user layer. `__DSH_BOOT__` boot-graph lever still
    present (`packages/client/modules/src/index.ts`,
    `rows.push({ kind: 'global', name: '__DSH_BOOT__', value: graph })`) —
    uiRoleGate intact. Role-based whole-UI gating stays SHIPPED (0.3.0
    uiRoleGate + 0.3.1 bridge-wall enforcement) — evaluation closed.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.2 remains current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` on all six
  dsh peers) already cover the latest runtime. No code changes → no README
  fix, no release (release only when a new DSH version requires adaptation).
- Verification: `npm test` = **19 files / 247 tests green** (6.45 s) on the
  current tree against devDeps `^0.2.1-alpha.2`.
- Housekeeping: the 2026-10-11 changelog entry (written but left uncommitted
  by that session's pwsh outage) committed together with this entry per the
  release-watch convention.

## 2026-10-11 (12:00 scheduled watch) — no new DSH release; 0.3.2 stays current; EXECUTION DEGRADED (pwsh outage)
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-11T04:00Z).
  Detection (fresh evidence, shell-free channels — see DEGRADED note):
  - npm official registry `@deepseek-ai/dsh-web-frontend`: dist-tags
    `alpha=0.2.1-alpha.2` (published 2026-10-09T08:17Z — no publish since),
    `next=0.2.0-rc.2`, `latest=0.0.1-rc.5`; `time.modified` 2026-10-09T08:17Z.
  - Broad sweep via the `/-/package/<pkg>/dist-tags` endpoint: all six
    `@deepseek-ai/dsh-*` peers (web-frontend, host-webserver,
    host-frontend-static, settings, client-connection, credentials) still
    `alpha=0.2.1-alpha.2` / `next=0.2.0-rc.2`; vendored cordis
    (`dsh-0-2-1-alpha-1` = 4.0.5-alpha.1) and schemastery
    (3.18.5-alpha.1) dist-tags unchanged → vendor pins unchanged.
  - `git ls-remote` on the harness repo (run from the zctz-prod SSH host —
    local shell unavailable): newest tag still `dsh-v0.2.1-alpha.2` (peeled
    commit `d743267388`); `refs/heads/master` = `d743267388` — **0 commits**
    past the release merge (PR #5946). Origin state byte-identical to the
    2026-10-10 watch.
  - dsh-login remote `refs/heads/master` = `4ccf1d7e` (10-10 changelog
    entry) — local tip in sync; tag `v0.3.2` = `74ffba3` on the remote.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.2 remains current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` on all six
  dsh peers) already cover the latest runtime. Multi-user verdict
  unchanged: origin/master == the dsh-v0.2.1-alpha.2 tag commit, so the
  10-10 grep result (multi-user/rbac 0 hits) is still current — upstream
  has no native multi-user; dsh-login remains the multi-user layer.
  Role-based whole-UI gating stays SHIPPED (0.3.0 uiRoleGate + 0.3.1
  bridge-wall enforcement) — evaluation closed.
- **DEGRADED EXECUTION — pwsh job-runner outage**: every pwsh invocation
  this session failed with `0xC0000142` (STATUS_DLL_INIT_FAILED,
  "Windows Job runner exited with exit code 3221225794"), foreground and
  background alike; a fresh subagent session reproduced the same failure →
  Host-wide, not session-scoped. Consequences: (1) no local
  `git fetch --all --tags` (replaced by ls-remote evidence above — same
  objects); (2) no fresh in-tree `npm test` re-run (tree unchanged since
  the 10-10 green run at commit `4ccf1d7e` — 19 files / 247 tests);
  (3) this entry written into the working tree but NOT committed/pushed —
  commit `docs: changelog — 2026-10-11 scheduled watch` + push pending;
  the next watch (or the user) should pick it up. glob/grep file tools
  failed with the same subprocess-spawn breakage; read/write/edit worked.

## 2026-10-10 (12:00 scheduled watch) — NEW DSH 0.2.1-alpha.2 → adapted + RELEASED 0.3.2
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-10T04:00Z).
  Detection (fresh evidence):
  - npm official registry `@deepseek-ai/dsh-web-frontend`: dist-tags
    `alpha=0.2.1-alpha.2` (published 2026-10-09T08:17Z — first publish since
    10-03), `next=0.2.0-rc.2`, `latest=0.0.1-rc.5` unchanged. Vendored
    cordis/schemastery NOT re-published (dist-tag `dsh-0-2-1-alpha-1` still
    4.0.5-alpha.1 / 3.18.5-alpha.1) → vendor pins unchanged.
  - `git fetch --all --tags` in `E:\code\deepseek-harness` (one TLS-EOF
    retry): new tag `dsh-v0.2.1-alpha.2`; `origin/master` = `d743267388`
    (release merge PR #5946); **669 commits** since 5badb15009 (1964 files,
    +51881/−16126).
- Compat surface (alpha.1→alpha.2): webserver gains TLS (`Config.tls`,
  `createSecureServer`, `protocol` getter; deps ipaddr.js/negotiator) and
  `host` becomes concrete-IP-literal-only (wildcard schema-rejected);
  connection row trust authorities move to the new `webStartup` service and
  the **upstream `webRuntime` service is REMOVED** (web-runtime row config =
  {openBrowser, printUrl, publicUrl, surfaceContext}); BrowserAuth
  `authorizeIndex`/`isAuthenticated` gain optional trailing `secure` param
  (HostConnectionService.authorizeIndex stays 2-arg, computes secure
  internally); new RemoteError code `'session/migration-required'`; NO new
  wire methods/namespaces → capabilities lists unchanged; session-controller
  migration-required flow + terminal-controller `workingDirectory` inject
  are internal; `__DSH_BOOT__` lever intact
  (`packages/client/modules/src/index.ts:585`); multi-user grep **0 hits**.
- Adaptation shipped as **0.3.2** (patch):
  - devDeps: 10 dsh packages → `^0.2.1-alpha.2` (peer tuple
    `>=0.2.1-alpha.1 <0.3.0-0` already admitted alpha.2 — NO peer retarget).
  - `src/web-runtime.ts`: `dsh web:` URL line + `DSH_WEB_URL` now spell the
    actual bind address (`webServer.host`) instead of hardcoded 127.0.0.1,
    mirroring upstream's new bind-address URL; 0.0.0.0 binds (pre-alpha.2
    only) still fall back to loopback + LAN suffix. webRuntime takeover kept
    (compat-only upstream — nothing consumes it anymore; harmless).
  - gateway.ts needs NO change (2-arg authorizeIndex / 1-arg isAuthenticated
    remain assignable; secure computed internally).
  - Fresh reinstall required (node_modules + lockfile deleted — recurring
    ERESOLVE wedge). `docs/adapt-dsh-0.2.1-alpha.2.md` written.
- Verification: `npm test` = **19 files / 247 tests green** (7.02 s) on the
  published 0.2.1-alpha.2 packages; `verify:imports` all ok; `npm run build`
  exit 0.
- README.md + README.zh.md release quotes/adaptation history/status updated
  to 0.3.2. Version bumped, commit `74ffba3`, tag `v0.3.2` pushed; npm
  published (`latest` = 0.3.2 after ~1 min propagation); GitHub release
  https://github.com/islibaodong/dsh-login/releases/tag/v0.3.2 created.

## 2026-10-09 (12:00 scheduled watch) — no new DSH release; 0.3.1 stays green
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-09T04:00Z).
  Fresh evidence, all unchanged:
  - npm official registry `@deepseek-ai/dsh-web-frontend`: dist-tags
    `alpha=0.2.1-alpha.1`, `next=0.2.0-rc.2`, `latest=0.0.1-rc.5`;
    `time.modified` 2026-10-03T04:55Z — no publish since 0.2.1-alpha.1.
    (Broad sweep the same hour: all 14 `@deepseek-ai/dsh-*`/vendor packages
    in the plugin's dep graph report `time.modified` 2026-10-03 — nothing
    newer anywhere.)
  - `git fetch --all --tags` in `E:\code\deepseek-harness` (one TLS-EOF
    retry needed this time): newest tag still `dsh-v0.2.1-alpha.1`
    (created 2026-10-03); `origin/master` = `5badb15009` = the release
    merge (PR #5648); `git rev-list 5badb15009..origin/master --count`
    = **0**; local `dev` == `origin/master` (0/0).
  - Multi-user re-check at the tag: `git grep -ilE 'multi.?user|multiuser|
    role.?based|\brbac\b' -- packages/ apps/` = **0 hits** — upstream
    still has no native multi-user; dsh-login remains the multi-user
    layer. `__DSH_BOOT__` boot-graph lever still present
    (`packages/client/modules/src/index.ts:585`) — uiRoleGate intact.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.1 remains current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` on all
  six dsh peers) already cover the latest runtime. Role-based whole-UI
  gating stays SHIPPED (0.3.0 uiRoleGate + 0.3.1 bridge-wall
  enforcement) — evaluation closed, nothing new to assess.
- Verification: `npm test` = **19 files / 247 tests green** (5.91 s) on
  the current tree against devDeps `^0.2.1-alpha.1`.
- No code changes → no README fix, no release (release only when a new
  DSH version requires adaptation). Changelog entry committed + pushed
  per the release-watch convention.

## 2026-10-08 (12:00 scheduled watch) — no new DSH release; 0.3.1 stays green
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-08T04:00Z).
  Fresh evidence, all unchanged:
  - npm official registry `@deepseek-ai/dsh-web-frontend`: dist-tags
    `alpha=0.2.1-alpha.1`, `next=0.2.0-rc.2`, `latest=0.0.1-rc.5`;
    `modified` 2026-10-03T04:55Z — no publish since 0.2.1-alpha.1.
  - `git fetch --tags` in `E:\code\deepseek-harness` (clean): newest tag
    still `dsh-v0.2.1-alpha.1` (created 2026-10-03); `origin/master` =
    `5badb15009` = the release merge (PR #5648); `git rev-list
    5badb15009..origin/master --count` = **0**.
  - Multi-user re-check at the tag: `git grep -ilE 'multi.?user|multiuser|
    role.?based|\brbac\b' -- packages/ apps/` = **0 hits** — upstream
    still has no native multi-user. `__DSH_BOOT__` boot-graph lever still
    present (`packages/client/modules/src/index.ts:585`) — uiRoleGate
    intact.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.1 remains current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` on all
  six dsh peers) already cover the latest runtime. Role-based whole-UI
  gating stays SHIPPED (0.3.0 uiRoleGate + 0.3.1 bridge-wall
  enforcement) — evaluation closed, nothing new to assess.
- Verification: `npm test` = **19 files / 247 tests green** (5.56 s) on
  the current tree against devDeps `^0.2.1-alpha.1`.
- No code changes → no README fix, no release (release only when a new
  DSH version requires adaptation). Changelog entry committed + pushed
  per the release-watch convention.

## 2026-10-07 (12:00 scheduled watch) — re-check: still no new DSH release; 0.3.1 stays green
- Scheduled cron run (`0 12 * * *` Asia/Shanghai, trigger 2026-10-07T04:00Z),
  ~1.5 h after the 10:40 watch. Fresh evidence, all unchanged:
  - npm official registry `@deepseek-ai/dsh-web-frontend`: dist-tags
    `alpha=0.2.1-alpha.1`, `next=0.2.0-rc.2`, `latest=0.0.1-rc.5`;
    `modified` 2026-10-03T04:55Z — no publish since 0.2.1-alpha.1.
    (Data point: `@deepseek-ai/dsh-root` is NOT on npm — registry 404
    "Not found". The six `@deepseek-ai/dsh-*` peer packages are the
    authoritative check surface.)
  - `git fetch origin --tags` in `E:\code\deepseek-harness` (clean, no
    retry needed): newest tag still `dsh-v0.2.1-alpha.1`; `origin/master`
    = `5badb15009` = the release merge; `git rev-list
    5badb15009..origin/master --count` = **0**.
  - Multi-user re-check at tag `dsh-v0.2.1-alpha.1`:
    `git grep -ilE 'multi.?user|multiuser|role.?based|\brbac\b' --
    packages/ apps/` = **0 hits** — upstream still has no native
    multi-user. `__DSH_BOOT__` boot-graph lever still present
    (`packages/client/modules/src/index.ts:585`) — uiRoleGate intact.
- **Conclusion: no new DSH version → no adaptation needed.** dsh-login
  0.3.1 remains current; peer ranges (`>=0.2.1-alpha.1 <0.3.0-0` on all
  six dsh peers) already cover the latest runtime. Role-based whole-UI
  gating stays SHIPPED (0.3.0 uiRoleGate + 0.3.1 bridge-wall
  enforcement) — evaluation closed, nothing new to assess.
- Verification: `npm test` = **19 files / 247 tests green** (5.66 s) on
  the current tree against devDeps `^0.2.1-alpha.1`.
- No code changes → no README fix, no release (release only when a new
  DSH version requires adaptation). Changelog entry committed + pushed
  per the release-watch convention.

## 2026-10-07 — DSH release watch: no new DSH version; dsh-login 0.3.1 verified green on the latest runtime
- Routine release-watch session (goal task). Three-source check, all fresh:
  - npm dist-tags for the **harness** (`Invoke-RestMethod
    registry.npmjs.org/@deepseek-ai%2fdsh-root` etc.): `alpha=0.2.1-alpha.1`
    (published 2026-10-03T04:53Z), `next=latest=0.2.0-rc.2`; `modified`
    2026-10-03 — unchanged since the 0.2.1-alpha.1 release.
  - `git fetch --tags origin` in `E:\code\deepseek-harness` (succeeded on the
    1st attempt this time — the TLS-EOF retry dance isn't always needed):
    newest tag still `dsh-v0.2.1-alpha.1`; `origin/master` = `5badb15009` =
    the release merge (PR #5648, 2026-10-03); `git rev-list
    5badb15009..origin/master --count` = **0** (zero post-release commits).
  - GitHub API tags endpoint now 404s unauthenticated (worked on 10-06) —
    treat it as an auth-gated fallback, not a required source; the two live
    sources above already agree.
- **Conclusion: no new DSH release since 0.2.1-alpha.1 → no compatibility
  adaptation needed.** dsh-login 0.3.1's last-adapted runtime IS the current
  latest runtime. Peer tuples already cover it (`>=0.2.1-alpha.1 <0.3.0-0`
  on all six `@deepseek-ai/dsh-*` peer deps, package.json peerDependencies).
- Multi-user re-check: `git grep -ilE 'multi.?user|multiuser|role.?based|\brbac\b'`
  on tag `dsh-v0.2.1-alpha.1` still **0 hits** in packages/ apps/ — upstream
  still has no native multi-user; dsh-login remains the multi-user layer.
- `__DSH_BOOT__` boot-graph injection still present at
  `packages/client/modules/src/index.ts:585` on the tag
  (`rows.push({ kind: 'global', name: '__DSH_BOOT__', value: graph })`) —
  the uiRoleGate lever is intact upstream.
- Test suite: `npm test` = **247/247 passed, 19 files** (vitest, 5.79 s) on
  the current tree against devDeps `^0.2.1-alpha.1` — green on the latest
  runtime, no changes required.
- Local runtime observation: the live `dsh web` (PID 16136, IDEA terminal)
  runs from the `E:\code\deepseek-harness` checkout (branch `dev`, HEAD
  `5badb15009` = the release tag) via tsx source execution — so the running
  instance is exactly 0.2.1-alpha.1. The web profile
  (`C:\Users\Administrator\.dsh\profiles\web`) has `@islibaodong/dsh-login
  ^0.3.1` installed; profile `node_modules/@deepseek-ai` contains only
  cosmokit+schemastery (core packages come from the harness checkout, not
  the profile).
- No code changes → no README fix, no commit, no release (per task rule:
  release only when a new DSH version requires adaptation).

## 2026-10-06 (final) — 0.3.1 released: bridge-wall per-user enforcement shipped, `latest` = 0.3.1
- Audit-fix session completed end-to-end: committed the per-user enforcement
  work, split as feature/docs, then released as **0.3.1** on npm + GitHub.
  Commits: `3168c54` feat (11 files, +1827/−92: `src/api-bridge-auth.ts` wall —
  `USER_ALLOWED` method gate for ordinary users, owned-only
  `session.list`/`session.search`/`workspace.list` response narrowing via
  `src/bridge-list-filter.ts`, ownership recording incl. admin record-only,
  default-workspace provisioning via `src/provision.ts` +
  `src/host-session-access.ts`; new tests: 232→**247**), `733694f` docs
  (`docs/compose-guard.md` deployment guide + both READMEs rewritten to the
  two-layer model: bridge-wall method gate shipped + REMOTE guard composed),
  `43cb81c` release (version 0.3.1 + README release sync + dist rebuild
  93160 B @ 16:49:47).
- Publish flow (all exit 0): push `master` + tag `v0.3.1` BEFORE staging
  (427281f..43cb81c; tag `[new tag] v0.3.1`) → token from `.env`
  `NPM_ACCESS_TOKENS` → temp `.npmrc.publish` → `npm whoami` = `islibaodong`
  → **`+ @islibaodong/dsh-login@0.3.1`** (35 files, 197.3 kB tgz, 681.2 kB
  unpacked, sha 468cc8bf) → `.npmrc.publish` deleted. Token never printed.
- **Propagation gotcha (new data point):** "may take a few minutes" is real —
  registry.npmjs.org itself 404'd `@0.3.1` for ~5 minutes after the publish
  PUT returned success (polled every 30 s: gone at 16:54–16:55, live at
  16:56:05 with `latest`=0.3.1). This lag is on the authoritative registry,
  not just npmmirror. Don't misread it as publish failure; verify with
  `Invoke-RestMethod https://registry.npmjs.org/@islibaodong%2fdsh-login`
  (abbreviated JSON), not bare `npm view` (default registry here is the
  npmmirror mirror — double lag).
- GitHub release: `gh release create v0.3.1 --generate-notes` →
  https://github.com/islibaodong/dsh-login/releases/tag/v0.3.1
- Open item unchanged: two-browser boot acceptance of the composed REMOTE
  guard (`docs/compose-guard.md` checklist) remains a deployment-side step.

## 2026-10-06 (even later) — npm publish COMPLETE: 0.2.7 + 0.3.0 are live, `latest` = 0.3.0
- User supplied a fresh npm granular token in **`E:\code\dsh-login\.env`** under
  key **`NPM_ACCESS_TOKENS`** (40 chars, `npm_` prefix). SAFETY: `/.env` is
  gitignored (checked before any `git add`); the token was never printed to the
  conversation — handled only inside pwsh (`Select-String` → temp
  `.npmrc.publish` → `npm whoami` → publish → delete).
- `npm whoami --registry=https://registry.npmjs.org --userconfig .npmrc.publish`
  → `islibaodong`. Published from the v0.2.7 git worktree
  (`E:\code\tmp-dsh-login-027`, tag = 6b35ac6; npm install + prepack build):
  **`+ @islibaodong/dsh-login@0.2.7`** (31 files, 538.4 kB). Published from the
  main tree: **`+ @islibaodong/dsh-login@0.3.0`** (32 files, 560.5 kB).
- Cleanup done: worktree removed, `.npmrc.publish` deleted. Registry CDN lag:
  `npm view` immediately after publish still showed latest=0.2.6 — re-check
  before trusting dist-tags.
- README.md + README.zh.md "npm publish pending" claims replaced with
  "published on npm — latest = 0.3.0" (README.md:11, :19; README.zh.md:11, :19).

## 2026-10-06 (later) — 0.3.0: whole-UI per-role gate (uiRoleGate) IMPLEMENTED on the boot-graph lever
- User selected (ask_user_question) **"实现整 UI 按角色门控"** — ship the
  2026-10-02/05 "boot-graph lever" as a feature.
- **Mechanism (verified in harness source at 0.2.1-alpha.1):** the boot roster
  travels in the rendered index HTML as `window.__DSH_BOOT__`
  (WebBootGraph `{rev, entries, batches}`); the page activates exactly
  `graph.entries` and `reconcile` removes bundles absent from the roster —
  so filtering the graph per role gates which bundles ever mount.
  `parseBootManifest` requires string ids/urls/revs, unique entry ids and
  batch URLs, non-empty batches, and every batch entry naming a graph entry.
  `webServer.renderIndex` renders the global row as
  `<script>globalThis["__DSH_BOOT__"] = <json></script>` with `<` escaped to
  `\u003c` inside the value.
- **New `src/ui-gate.ts`:** `filterBootGraph(graph)` (deny-list =
  `ADMIN_ONLY_UI_PLUGINS`, now **exported** from `src/capabilities.ts`;
  patches owning batches, drops emptied batches, fails open on unexpected
  shapes, aborts if a kept bundle injects/externals a removed id incl. the
  `<pkg>/client` alias) + `applyUiGate(html)` (splice the decoded→filtered→
  re-encoded `\u003c`-escaped global row; every failure returns the input).
  **Config:** `uiRoleGate: boolean` default **true** (`src/config.ts`).
  **Gateway:** gated `renderIndex` only when `uiRoleGate && !session.isAdmin`
  — admins/unauthenticated see the graph untouched. Presentation only: the
  `/api` allow-list stays the security boundary; dev HMR graph push is the
  documented dev-only bypass.
- **`tests/ui-gate.spec.ts`** (16 tests): filter semantics, fail-open shapes,
  kept-depends-on-gated abort, HTML round-trip + `\u003c` re-escaping, and 4
  gateway integration tests on a REAL webserver boot (user filtered / admin
  full / off = full / unauthenticated 302). Full suite now **19 files /
  232 tests green**; `verify:imports` ok; build exit 0 (`dist/client.js`
  still 37134 chars — the client half is untouched).
- **New devDep `@deepseek-ai/dsh-client-modules@^0.2.1-alpha.1`** (test-time
  acceptance). GOTCHA: its shipped lib **omits `parseBootManifest`** from the
  runtime export list (`lib/index.js:981`) despite
  `lib/types/index.d.ts:19` promising it — the spec asserts against
  `orderByModuleGraph` (shipped; throws on cycles/unknown externals) instead.
- **Gotcha hit:** the no-op fast path (`removed.size === 0`) originally ran
  BEFORE the batch shape checks, so `batches: [null]` with no denied ids
  returned the graph instead of failing open — validation now precedes the
  fast path.
- **Version 0.3.0** (minor: new feature); package description gained "with
  per-role whole-UI gating". Docs: `docs/adapt-dsh-0.2.1-alpha.1.md` §6
  (mechanism + implementation + verification), README/README.zh release +
  history + RBAC sections rewritten to "SHIPPED", counts 19/232. NOT
  boot-verified against a real `dsh web` run (like the isolation guard).

## 2026-10-06 morning — token still 401; no new DSH release; README npm-claim corrected
- `npm whoami --registry=https://registry.npmjs.org` STILL **401** → 0.2.7
  remains **unpublished** (npm latest 0.2.6). Upstream dist-tags unchanged
  (`alpha` = 0.2.1-alpha.1; latest/next = 0.2.0-rc.2) — no overnight release,
  no adaptation work triggered. README.md/README.zh.md "（npm latest）" claims
  softened to "git tag v0.2.7; npm publish pending a fresh token" (restore the
  npm-latest wording once the new token lands and 0.2.7 is published).

## 2026-10-05 — DSH 0.2.1-alpha.1 released; adapted + RELEASED as 0.2.7 (invariant retirement, peer retarget)
- **Version check: NEW DSH release.** npm `@deepseek-ai/dsh` dist-tags now
  **`alpha` = 0.2.1-alpha.1** (`latest` = `next` = 0.2.0-rc.2); GitHub newest
  tag `dsh-v0.2.1-alpha.1`; harness `origin/master` = `5badb15009`; **266
  commits** since `dsh-v0.2.0-rc.2`. Local harness checkout is on branch `dev`
  (258 behind) — read upstream content via `git show origin/master:<path>` /
  `git grep … origin/master`, never through that worktree.
- **The breaking change: runtime invariant plugins removed** (`f028f25667`,
  1355 files, −15.4k lines) — `@deepseek-ai/dsh-invariants` retired (npm stops
  at 0.2.0-rc.2) and every `./invariant` subpath export deleted. dsh-login
  referenced it in exactly three places, all config-only (devDep,
  tsconfig path, two test-runner PACKAGE_MAP entries) — **no `src/` import**,
  so removal was mechanical. Other churn: new wire namespace
  `claudeCodeMods` (agent-mod band UI; rides default deny, no allow-list
  change), `SignInErrorCode` gains `'no-response'`, session-list scheduling
  work, `packages/client/modules` + `ui-slots` src-unchanged at the
  plugin-visible level.
- **Peer graph moved too**: ALL 0.2.1-alpha.1 packages peer-require
  `@deepseek-ai/cordis@~4.0.5-alpha.1`; `dsh-settings` also peers
  `schemastery ~3.18.5-alpha.1`; `cordis@4.0.5-alpha.1` peers
  `cordis-plugin-loader ~1.0.6-alpha.1` + `include ~1.0.10-alpha.1`.
  `@deepseek-ai/cordis` npm versions: …4.0.4, **4.0.5-alpha.1**;
  schemastery: …3.18.4, **3.18.5-alpha.1**.
- **0.2.7 shipped** (version bump 0.2.6 → 0.2.7): six dsh peers gain
  `|| >=0.2.1-alpha.1 <0.3.0-0` (tuple rule); cordis peer gains
  `|| ~4.0.5-alpha.1`; schemastery peer gains `|| ~3.18.5-alpha.1`; devDeps →
  9 dsh packages `^0.2.1-alpha.1`, cordis `~4.0.5-alpha.1`, include
  `~1.0.10-alpha.1`, loader `~1.0.6-alpha.1`, schemastery
  `~3.18.5-alpha.1`; `dsh-invariants` removed from package.json /
  tsconfig.json / tests/runner.mjs / tests/integration-runner.mjs. **No src/
  change.**
- **The recurring ERESOLVE wedge struck again (3rd time)**: incremental
  `npm install` failed because the stale rc.2 `node_modules` still carried
  `dsh-settings@0.2.0-rc.2` → `dsh-config-editor@0.2.0-rc.2` →
  `dsh-app-boot@0.2.0-rc.2` → `cordis-plugin-group@1.0.4` demanding
  cordis `~4.0.4`. **Delete `node_modules` + `package-lock.json` and
  reinstall fresh FIRST** — don't debug the conflict, nuke the tree.
- **Verification on real 0.2.1-alpha.1 builds**: `npm test` **18 files /
  216 tests green**; `verify:imports` all ok; `npm run build` exit 0 with
  `dist/client.js` **byte-identical (37134 chars)** — the harness bump
  changed nothing in the client bundle.
- **Multi-user / role verdict at 0.2.1-alpha.1 (git grep on origin/master)**:
  multi-user/rbac greps **0 hits**; `isAdmin|isAllowed` in `packages/client`
  **0 hits**; `SlotEntryDef` (`packages/client/ui-slots/src/index.ts:116`)
  unchanged, still no visibility/permission field. The 2026-10-02 verdict
  stands: no upstream multi-user, no native role gate; the boot-graph lever
  (rc.2 doc §6.5) remains valid and **unimplemented**. Trap persists: ~238
  files under `packages/client` match a raw `\brole\b` grep (DOM a11y
  attributes) — never read that as account roles.
- Records: `docs/adapt-dsh-0.2.1-alpha.1.md` (new), README.md + README.zh.md
  status/history updated, this entry. Commit `6b35ac6` + tag `v0.2.7` + push.
- **Follow-up (same day): GitHub Releases channel CREATED** — all 8 tags
  v0.2.0…v0.2.7 now have Releases (previously 0 releases / 7 tags);
  v0.2.7 marked Latest with custom notes (release id 403690403). gh CLI
  paths: `gh release create <tag> --generate-notes`; editing a release body
  needs `gh api -X PATCH repos/.../releases/<id> --input file.json` (PATCH by
  tag 404s; build the JSON with ConvertTo-Json + WriteAllText UTF8-no-BOM —
  here-strings with backticks break "Problems parsing JSON").
- **npm publish of 0.2.7 BLOCKED — user action required**: `npm whoami
  --registry=https://registry.npmjs.org` → **401 Unauthorized** (the
  `_authToken` in `C:\Users\Administrator\.npmrc` is revoked/invalid); the
  default registry is registry.npmmirror.com (a mirror — cannot publish).
  `npm pack` works (156.0 kB, 31 files). **npm still shows 0.2.6 as latest;
  0.2.7 is NOT on npm.** Fix per docs/PUBLISHING.md: user mints a NEW granular
  token (Read/write, @islibaodong scope, bypass 2FA) → update `.npmrc` →
  `npm publish --access public --registry=https://registry.npmjs.org`.

## 2026-10-02 (later) — NO new DSH release; 0.2.0-rc.2 re-verified; whole-UI role gating found FEASIBLE in-plugin
- **Version check (12:15 local): no new DSH release.** npm `@deepseek-ai/dsh`
  dist-tags `latest` = `next` = **0.2.0-rc.2** (`alpha` 0.1.7-alpha.2); GitHub
  newest tag `dsh-v0.2.0-rc.2`; harness `origin/master` == `639ed01539` == the
  tag commit (0 ahead). **So no compatibility adaptation was needed** — 0.2.6
  is current for the newest runtime. (Gotcha re-confirmed: all DSH releases are
  prereleases, so `GET /releases/latest` 404s — read the tags endpoint instead.)
- **Re-verified on the current tree**: suite **18 files / 216 tests green**
  against the published 0.2.0-rc.2 builds; `verify:imports` exit 0; build exit 0
  with `dist/client.js` re-stamp **byte-identical** (37134 chars; `git status`
  clean right after the build). **Local run is 0.2.0-rc.2** — the
  `~/.dsh/profiles/web` store has dsh-base/web-app/client-connection/
  host-webserver/credentials/web-frontend/host-frontend-static all at rc.2, with
  dsh-login 0.2.6 installed. `dsh-client-runtime` absent from the store (the
  2026-08-23 fold is real — never diff that path).
- **Multi-user: still NONE** (0 hits for `multi.?user|multiuser|role.?based|
  \brbac\b` in `packages/` + `apps/`). Lead resolved: the new-looking
  `@deepseek-ai/dsh-authorization` is a **credentials sub-package**
  (`packages/credentials/authorization`, a nested `packages/*/*` workspace) =
  a credential-acquisition seam ("obtain a credential through a conversation
  with the human"), NOT account RBAC. dsh-login remains the multi-user layer.
- **Role surface: no native per-identity filter** — `packages/client/modules/src`
  + `ui-slots/src` have 0 hits for `isAdmin|isAllowed|role|permission`;
  `SlotEntryDef` has no visibility field and `SlotScope` is
  `root|session-maybe|session` (session-bound, not identity-bound). **Grep
  trap:** the ~250 `role` hits under `packages/client` are ALL DOM
  `role="…"` a11y attributes.
- **NEW / IMPORTANT — whole-UI role control IS implementable inside dsh-login,
  without upstream changes.** The old verdict ("blocked on upstream") was too
  strong. Verified mechanism: (1) dsh-login's gateway renders the index via
  `webServer.renderIndex` and the rendered HTML carries the client module
  roster as `window.__DSH_BOOT__` (`bootInjections()` at
  `packages/client/modules/src/index.ts:552` emits
  `{kind:'global', name:'__DSH_BOOT__', value: graph}`; web-app's patch comment
  confirms the node half composes it); (2) the page activates exactly that
  roster — `ClientEntries.reconcile()` creates one Loader entry per
  `manifest.modules` row and **removes** managed entries absent from
  `manifest.plugins`; (3) so filtering the graph per role before serving the
  index gates which bundles ever mount. Role data already exists
  (`deriveCapabilities(user)`). Constraints: keep the bootstrap batch +
  `dsh-client-modules` entry (else "bootstrap facade is missing"); keep graph
  shape valid (`parseBootManifest` string id/url/rev, no duplicate batch URLs);
  granularity is **per package** (hiding one slot/section inside an allowed
  package needs dsh-login's own client half to wrap the slot registry);
  presentation-only (the boundary stays the `/api` allow-list + remote guard);
  dev-mode `client-hmr` is always mounted but idle, yet a dev rebuild pushes
  `{type:'graph'}` and re-syncs the full roster — a robust gate must cover that
  channel too. **Not implemented, not boot-verified.** Full write-up:
  `docs/adapt-dsh-0.2.0-rc.2.md` §6.
- **README fix**: the stale `211` test count (missed by the 0.2.6 release, which
  updated the 216 counts at the top) corrected in `README.md` and `README.zh.md`;
  the RBAC verdict text refined in both to the accurate split (no *native*
  upstream filter; in-plugin boot-graph gate feasible).
- **Repo-memory correction**: `.claude/rules/architecture.md` / `modules.md` /
  `gotchas.md` still described the pre-option-A `/api` takeover
  (`src/connection.ts`, `src/connection.client.ts`, `/api` prefix route,
  "the shipped `connection` row stays disabled", `dsh-host-apiproxy`) — those
  files/specs are gone and `cordis.patch.yml` keeps `connection` **ENABLED**
  (only `web-runtime` disabled). Corrected in place; `modules.md` needs a fuller
  re-analysis, and `docs/PROJECT-INDEX.md` is stale (v0.1.0 era).

## 2026-10-02 — PUBLISHED 0.2.6 (issue #3 fix) — first publish fully on the .env granular token path
- **`@islibaodong/dsh-login@0.2.6` is LIVE on npmjs** (`latest = 0.2.6`,
  31 files / 154.8 kB tarball / 531.0 kB unpacked, shasum
  `e0b8a000f578b1e3bfec9986f7bd6dc7a7b0ea15` — identical to the dry-run AND
  the staged tarball; prepack rebuild deterministic as always). Registry
  timestamp 2026-10-02T04:04:37Z. `npm view @0.2.6` re-verified version +
  shasum on the official registry.
- **Publish path — NO web login needed (new):** the stored ~/.npmrc token was
  dead (whoami E401) as usual, but the user proposed the `.env`
  `NPM_ACCESS_TOKENS` granular token and it is STILL ALIVE: token copied
  (value never echoed) into a temp publish npmrc in %TEMP% → whoami →
  `islibaodong` → `npm stage publish ./ --registry=…
  --userconfig=<temp>` staged id `7cab5226-1eb1-4211-b863-b3112fe34ef4`
  directly from the agent shell. **BUT the bypass-2FA setting still does NOT
  cover approve**: fresh EOTP evidence on 0.2.6 day — `npm stage approve`
  with the granular token errors EOTP with the auth URL redacted to `***`
  (non-TTY); approve remains the human 2FA gate of npm's staged-publishing
  policy (the publish output itself warns "npm tokens that bypass 2FA are
  being restricted for account changes and direct publishing",
  gh.io/npm-gat-bypass2fa-deprecation). The user approved in the browser via
  the launched interactive approve window; dist-tags polled until `latest`
  flipped (10-min background poll, hit at 12:04:59 local). Temp npmrc +
  approve script deleted after success. **Runbook update: publish step can
  now be fully scripted with the .env token; only approve needs one browser
  2FA click.** For real end-to-end automation the offered path is npm
  trusted publishing (GitHub Actions OIDC, no token at all) — user has not
  decided yet.
- Release commit `c7494ea` (version bump + README EN/ZH sync: banner 0.2.6,
  adaptation-history entry for 0.2.6, test counts 211→216) + **git tag
  `v0.2.6` + master pushed BEFORE staging** (github install channel serves
  0.2.6). Fix commit `171aaf7` had auto-closed issue #3 on push.
- Pre-publish verification on the 0.2.6 tree: suite 18 files / 216 tests
  green; verify:imports exit 0; `npm pack --dry-run` 31 files / 531.0 kB,
  shasum e0b8a000…, no `.env` side effect.
- **Web profile upgraded the same session:** profile dependency is the
  github channel (`github:islibaodong/dsh-login`, not an npm range) —
  `pnpm update '@islibaodong/dsh-login' --dir <profile>` re-resolves the ref
  and pulled 0.2.6; installed dist/index.js verified to contain the
  browserAuth-redirect fix. `compatibility.json` stays `{}` (no exemption).
  Boot verification (login wall 302, fresh-device login now lands on the SPA
  via the ?token= bootstrap) is the user's restart. Gotcha: `pwsh` is not on
  PATH for nested invocations — use `pnpm --dir` instead of wrapping in
  another shell.

## 2026-09-30 (later) — GitHub issue #3 fixed in-repo: fresh-device core-401 after login (launch-token bootstrap redirect)
- **Issue #3** (github.com/islibaodong/dsh-login/issues/3, reporter Johnwikix,
  against 0.2.4/DSH 0.1.7-rc.2): on a NEW device (no historical cookies),
  after a successful dsh-login login the first page load returns the core's
  plain-text 401 "dsh web authentication required; reopen the URL printed by
  dsh web." instead of the SPA. Devices already holding a valid core cookie
  worked fine, masking the bug (the same 401 also surfaced after the core
  cookie expired).
- **Root cause verified against the real dsh-client-connection 0.2.0-rc.2
  source (source-identical to 0.1.7-rc.2 per the compat analysis)**: core
  `BrowserAuth.authorizeIndex` (lib/index.js ~L388-427) mints its
  authority-bound cookie ONLY in the `GET /?token=<launchToken>` exchange
  (303 → clean `./` + set-cookie); a valid cookie admits the index; EVERYTHING
  else → writeUnauthorized 401. dsh-login's login wall (302 /login until
  `dsh_session`) never routes the browser through `?token=` — POST
  /api/auth/login sets only `dsh_session` and login-page redirects to `/` —
  so the forwarded bare index request hits the core 401. The gateway tests
  never caught it: `bootServer()` compositions provide NO `connection`
  service, so `createAuthorizeIndex` short-circuited to `return true`.
  Wrapper shape confirmed: `ctx.get('connection')` = HostConnectionService,
  real BrowserAuth in `.browserAuth` (`.launchToken` is a plain runtime field
  despite the private TS annotation; the wrapper itself has NO
  isAuthenticated/launchToken — only authorizeIndex/authenticatedUrl
  delegates).
- **Fix (src/gateway.ts `createAuthorizeIndex`)**: before forwarding to
  `connection.authorizeIndex`, resolve `auth = connection.browserAuth ??
  connection`; when the request has no `token` query param, auth exposes
  `isAuthenticated`, the core cookie is missing/expired (`!auth.isAuthenticated(req)`),
  and `auth.launchToken` is a non-empty string → writeHead(302,
  Location `/?token=<encodeURIComponent(launchToken)>`, cache-control
  no-store) + return false (one bounce; the core mints the cookie and 303s to
  `./`, then the index serves normally). Requests already carrying a token
  always forward (the core owns the exchange — a second bounce would loop);
  connections without the browserAuth surface keep plain-forward semantics;
  no usable launchToken → forward, the core's own 401 passes through. The
  redirect Location is root-RELATIVE on purpose (works behind the nginx
  0.0.0.0:3088 proxy; the browser re-sends its own Host authority, which the
  cookie is bound to).
- **Tests**: 5 new cases in tests/gateway.spec.ts (new describe "gateway
  authorizeIndex: core browser-auth handshake (issue #3)") with a fake
  connection service mirroring the real BrowserAuth decision shape (token
  exchange → 303 + set-cookie; cookie-valid → admit; else 401 plain text):
  fresh-device 302 (RED first: `expected 401 to be 302`), forwarded exchange
  mints (303 + location ./ + set-cookie), cookie-valid direct serve, no
  browserAuth back-compat forward, empty launchToken → core 401 passthrough.
  Suite **18 files / 216 tests** green (was 211); verify:imports exit 0;
  `npm run build` green — dist/index.js carries the fix, dist/client.js
  re-stamp byte-identical (37134 chars). NOT yet published (needs the user:
  commit + npm stage publish + tag/push per the release runbook).

## 2026-09-30 (later) — 0.2.0 re-verified + multi-user/RBAC detection recorded + guard-forwarding hardening (in-repo)
- **Full state re-check**: 0.2.5 confirmed PUBLISHED (npm latest,
  2026-09-30T02:55Z), tag `v0.2.5` + master pushed (nothing unpushed). Suite
  re-run on the current tree against real 0.2.0-rc.2 builds: green.
- **Multi-user detection at 0.2.0-rc.2 (was missing from the 0.2.5 entry)**:
  `git grep -ilE 'multi.?user|multiuser|role.?based|\brbac\b' dsh-v0.2.0-rc.2
  -- packages/ apps/` → **0 hits**; no user/account/auth package (identity =
  telemetry ids, telemetry/otel = OTLP log channels, no wire namespace).
  Still NO native multi-user; dsh-login remains the multi-user layer.
- **Role-based whole-UI control at 0.2.0-rc.2**: still infeasible —
  `packages/client/modules/src` (boot/activation; the client-runtime package
  was folded into it on 2026-08-23, commit `be531688f3`, so a
  `packages/client/runtime` diff is silently empty — always verify the path
  exists before trusting a zero-diff!) and `packages/client/ui-slots/src`
  are source-identical to 0.1.7-rc.2, 0 hits for
  isAdmin/isAllowed/role/permission. The new `ui-settings-session-log`
  web-app row ships no per-identity visibility hook (global section list).
- **Guard hardening (in-repo, rides the next release)**: 0.2.0-rc.2 made
  `TypertGateway.hasLiveClient()` a REQUIRED interface member (rc.1 lacks
  it; consumers `cordis-host-runner/inspect-registry` +
  `tool-cordis/api-catalog`). The shipped deployment never composes the
  guard, so nothing breaks live, but the hand-rolled two-method
  `wrapRemoteGateway` would go structurally incomplete the moment a
  deployment composed it. Now spreads the gateway and overrides only
  invoke/stream (`WrappedRemoteGateway<G>` type); +2 regression tests.
  Suite **18 files / 211 tests** green; verify:imports exit 0; build exit 0;
  `dist/client.js` unchanged (37134 chars).
- Full analysis written to `docs/adapt-dsh-0.2.0-rc.2.md` (includes the
  path-correction lessons: web-app rows live at `packages/bundle/web-app`,
  dsh-web-frontend at `apps/web`).
- Repo hygiene: `.gitignore` += `/.claude/` + `/.github/` (untracked local
  hooks/settings/copilot-instructions; the tracked `.claude/rules/*` memory
  files are unaffected).

## 2026-09-30 — DSH 0.2.0-rc.2 adaptation (0.2.5 — peer retarget only; PUBLISHED, see below)
- **New DSH release detected**: `0.2.0-rc.2` (harness tag `dsh-v0.2.0-rc.2`, release merge
  `639ed01539`, commit 2026-09-29; npm `next` dist-tag 2026-09-29T09:44Z). First release
  on the **0.2.0 tuple line** — this forces a peer retarget (unlike rc.1/rc.2 of 0.1.7,
  which the existing `>=0.1.7-alpha.2 <0.2.0-0` branch already admitted).
- **Compat surface verified between `dsh-v0.1.7-rc.2..dsh-v0.2.0-rc.2`** (33 files,
  +354/−49 on the nine integrated packages): webserver / frontend-static / settings /
  client-runtime / ui-slots / client-connection are **source-unchanged** (version bumps
  only); gateway gains additive `hasLiveClient()` + client `signal` field (no
  connection/request waterfall change); credentials is additive (`DeepSeekAccount`
  gains abstract `getDeviceIdentity()` — Host-side, no wire method); controllers:
  session `fork` gains optional `onCreated` arg (wire-backward-compatible), terminal
  shell-discovery + workspace default-directory are internal logic. web-app rows:
  `web-runtime`/`connection` untouched (schedule rows removed, desktop-gated
  product-telemetry/otel rows added) — the shipped `cordis.patch.yml` applies as-is.
  **Zero new wire methods, zero new namespaces** → capabilities/quiet-deny lists
  unchanged. **Verdict: source-compatible, no code adaptation.**
- **Changes shipped in 0.2.5**: `peerDependencies` retargeted (tuple convention) —
  all six dsh peers gain `|| >=0.2.0-rc.2 <0.3.0-0`; devDeps → `^0.2.0-rc.2`
  (10 pkgs) via fresh reinstall per the 09-23 runbook (incremental ERESOLVE wedge
  confirmed again — lingering 0.1.7-rc.2 `dsh-host-frontend-static` pinned
  `dsh-client-connection@0.1.7-rc.2`); cordis 4.0.4 / schemastery 3.18.4 unchanged
  (verified against the 0.2.0-rc.2 published peers).
- **Verification**: full suite green **18 files / 209 tests** on real 0.2.0-rc.2
  builds (incl. the full-composition boot spec); `verify:imports` exit 0; build exit 0;
  `dist/client.js` re-stamp **byte-identical (37134 chars)** — connection client
  unchanged, as the source diff predicted.
- Runtime boot already smoke-verified on the live web profile (0.2.0-rc.2 harness):
  login wall active (302 to /login), no peer-gate skip under the
  `dsh plugin allow-version` exemption — the exemption in
  `~/.dsh/profiles/web/compatibility.json` becomes unnecessary once 0.2.5 is
  installed (revoke after the profile upgrade).
- Publish: needs the user (`npm stage publish` + npmjs 2FA), then git tag `v0.2.5`
  + master push (GitHub install channel), then profile `pnpm update
  @islibaodong/dsh-login` + `dsh plugin revoke-version`.

## 2026-09-30 (later) — PUBLISHED 0.2.5 + exemption revoked
- **`@islibaodong/dsh-login@0.2.5` is LIVE on npmjs** (`latest = 0.2.5`,
  31 files / 150.8 kB, shasum `86299e3d462783f82d58b3c728e2bb5ccb2d6a57`,
  unpacked 522.1 kB). Stage id `8ad14b49-cdf0-4718-89b3-390d2ed01df3`.
- Publish path: fresh web login in an interactive window (first attempt's CLI
  session expired → relaunched; the follow-on scripted `stage publish` step
  hung after login, so publish ran from the agent shell with the fresh token).
  `npm stage publish` (prepack rebuild deterministic — client.js 37134 chars
  staged identical). **`npm stage approve` with the `.env` granular token hit
  EOTP** (non-TTY redacts the auth URL `***`) — approval completed by the
  user in the interactive approve window's browser popup. dist-tags polled:
  `latest` flipped to 0.2.5.
- Release commit `033cf3b` + **git tag `v0.2.5` + master pushed to GitHub**
  before staging (the github install channel serves 0.2.5).
- Profile upgraded: `pnpm update @islibaodong/dsh-login` → 0.2.5 installed;
  `dsh plugin revoke-version @islibaodong/dsh-login@0.2.4 --dsh-version
  0.2.0-rc.2` executed — profile `compatibility.json` back to `{}`. Boot
  verification (login wall 302, no peer-gate skip) is the user's restart.
- Hygiene: the fresh `//registry.npmjs.org/:_authToken` from this web login
  sits in `~/.npmrc` — revoke it on npmjs.com if the machine is shared (same
  note as after 0.2.1–0.2.4). The `.env` `NPM_ACCESS_TOKENS` remains
  staging-publish-capable but NOT approve-capable (EOTP) — expected under the
  npm bypass-2FA restriction policy.

## 2026-09-28 (later) — READMEs synced to the released-0.2.4 / rc.2 reality (commit e19a61b)
- Both `README.md` + `README.zh.md` were still describing the 0.2.0-era state
  (0.2.1/0.2.2 labeled "unpublished", "17 files / 189 tests", "203 tests
  through 0.1.6-alpha.2"). Synced, verified against the changelog + source:
  banner now leads with **0.2.4 (npm latest) verified against DSH
  0.1.7-rc.2** and a compact published adaptation history (0.2.1→0.1.6-alpha.1,
  0.2.2→0.1.6-alpha.2, 0.2.3→0.1.7-alpha.2, 0.2.4→#4587 fix; rc.1/rc.2
  no-release verifications linked); "Current status" rewritten around the
  completed option-A adaptation (apiBridgeAuth wall included) with the guard
  caveat kept verbatim-accurate (verified `src/index.ts` only exports
  `wrapRemoteGateway`/`createRemoteIsolation` — still a composition primitive,
  not auto-composed; two-browser sign-off still outstanding); new
  "Tracks upstream" bullet (user-surface growth + admin-only namespaces +
  the rc.1 boot-time compatibility-admission fail-open note); the
  permission-model enumeration now matches `USER_ALLOWED` (terminal.*/job.*/
  workspaceFiles.*/officeToPdf.*/pin-unpin/unarchive) and the admin-only
  domain list (pluginManager+pluginRegistryProbe+account incl. watchExpiry);
  test counts 189/203 → **18 files / 209 tests, DSH range through
  0.1.7-rc.2** in "Running tests" + "Project structure" (both languages).

## 2026-09-28 — DSH 0.1.7-rc.2 detected → verified compatible, NO release needed (devDeps pinned, advertisement +1)
- **New DSH release detected**: `0.1.7-rc.2` (2026-09-24T14:01–14:19Z) under the
  **`next`** dist-tag (alpha stays 0.1.7-alpha.2; latest still stale
  0.0.1-rc.1), tag `dsh-v0.1.7-rc.2` (release commit `787b746b80`); **346
  commits** since 0.1.7-rc.1; `origin/master` already past the tag (post-
  release pwsh tail-grace fix PR #5282). Verified on all seven integrated
  packages + `dsh-invariants`. Full analysis: `docs/adapt-dsh-0.1.7-rc.2.md`.
- **Compat verdict: 0.2.4 already works on rc.2 — no release.** The change
  mass is account/Platform credential lifecycle + i18n; every integration
  point is source-unchanged (webserver/frontend-static/settings/credentials/
  gateway/connection waterfall/web-app rows/runtime/ui-slots). Sole wire
  addition: `account.watchExpiry` (expiry-notice stream — admin-only
  namespace, denied for users by construction);
  `workspace.initializeDefault` dropped its `{directoryName,title}` request
  but was never user-allowed → no impact. New session error codes only.
- **Changes shipped in-repo (NOT published)**: devDeps → `^0.1.7-rc.2`
  (10 pkgs; the known incremental ERESOLVE wedge → fresh reinstall per the
  09-23 runbook, exit 0; cordis 4.0.4 / schemastery 3.18.4 unchanged);
  `capabilities.ts` adminOnlyMethods() + QUIET_DENY_METHODS +=
  `account.watchExpiry` (advertisement accuracy + read-shaped stream quiet
  204); spec asserts all three layers. peerDependencies **unchanged** —
  `>=0.1.7-alpha.2 <0.2.0-0` admits rc.2 (tuple rule; verified
  semver.satisfies includePrerelease). `dist/client.js` re-stamp
  **byte-identical** (37134 chars). Suite green **18 files / 209 tests** on
  real rc.2 builds; verify:imports exit 0; build exit 0.
- Multi-user at rc.2: still NONE (0 grep hits; `packages/identity` still
  telemetry-only; the rc.2 `account` work manages the ONE process-wide
  Platform grant). Role-based whole-UI control: still infeasible
  (runtime/ui-slots source-identical to rc.1, 0 permission/role hits).
  Upstream asks unchanged: docs/adapt-dsh-0.1.6.md §6.

## 2026-09-24 (later) — PUBLISHED 0.2.4 (DSH #4587 settings-error-wording fix)
- **`@islibaodong/dsh-login@0.2.4` is LIVE on npmjs** (`latest = 0.2.4`,
  tarball 31 files / 149.2 kB, shasum `2dd288d269addf527a9274d0b171c8d7bab62415`,
  unpacked 518.2 kB). Stage id `98ecd73c-87f8-48d5-9764-fad3c73a29b8`.
  Publish path = the 0.2.3 runbook, executed end-to-end this session: the
  0.2.3 token was dead (whoami E401) → fresh **web login** in an interactive
  `Start-Process powershell` window (whoami polling confirmed `islibaodong`
  after 4×15s polls) → fresh pre-publish verification (suite 18 files / 209
  tests green 6.54s; verify:imports exit 0; `npm pack --dry-run` 31 files,
  shasum 2dd288d2…, no `.env` side effect, working tree clean after prepack)
  → `npm stage publish ./ --registry=https://registry.npmjs.org` (prepack
  rebuild deterministic — staged shasum identical to dry-run) → `npm stage
  approve <id>` in another interactive window → user approved 2FA in the
  browser → dist-tags polled until `latest` flipped to 0.2.4 (7th 15s poll).
  `npm view @0.2.4` re-verified version + dist-tags on the official registry.
- Release commit `1a4da85` (the #4587 fix, 7 files +66/−7); **git tag
  `v0.2.4` + master pushed to GitHub** (`f68a658..1a4da85 master` +
  `[new tag] v0.2.4`) — the `dsh plugin add github:islibaodong/dsh-login`
  install channel now serves 0.2.4. Git push stderr shows the usual cosmetic
  PowerShell NativeCommandError wrapper — push succeeds.
- Hygiene: the fresh `//registry.npmjs.org/:_authToken` from this login sits
  in `~/.npmrc` — revoke it on npmjs.com if the machine is shared (same note
  as after 0.2.1/0.2.2/0.2.3; expect a fresh web login again next release).

## 2026-09-24 — 0.2.4 prepared (published, see the entry above): DSH dev settings refactor broke remote-web-ui-compat graceful skip
- **Upstream break found on dev** (post-rc.1, commit `601d6761e4`,
  2026-09-21, #4587 "profile-owned live configuration"): the settings
  service's `write()` now throws `No configurable plugin entry "<ns>"`
  where the legacy service threw "settings namespace not registered".
  `RemoteWebUiCompat.apply` classifies the unregistered-namespace case by
  matching the error MESSAGE (both generations throw a plain `Error`),
  so the new wording no longer matched → the graceful
  `'unregistered'` skip became a rethrow → `applyWithRetry` has no
  catch → **fiber-fatal: the whole `dsh web` boot dies** whenever
  `@linxin666/dsh-remote-web-ui` is NOT installed (its own namespace
  absent — the exact path designed to be a no-op). Triggered in the
  web profile on 2026-09-24 boot.
- **Fix (0.2.4)**: new `isUnregisteredNamespace()` helper matches both
  wordings ("not registered" legacy + "No configurable plugin entry"
  #4587); comments pin the provenance of each. Same break class as the
  2026-08-31 seam-rehome — settings error TEXT is not a stable contract;
  replace message matching with a structural probe if upstream ever
  exposes one.
- **Tests**: 2 new cases in `remote-web-ui-compat.spec.ts` (apply +
  applyWithRetry against the new wording) — both red before the fix,
  green after; compat suite 15/15, full suite 209/209.
- **Deployed to the web profile install directly** (dist+src copied
  after `npm run build`) as a stopgap — boot verified clean
  (`dsh web: http://127.0.0.1:3080`). Gotcha re-confirmed: the plugin
  loads `dist/index.js`; src-only edits are invisible (stack src
  line numbers are sourcemap-resolved). A profile `pnpm update` will
  restore npm 0.2.3 (still broken) until 0.2.4 is published.
- ~~**Not yet done**: npm stage publish + git tag `v0.2.4` + master push~~ →
  all three done — published 0.2.4, tag `v0.2.4` + master pushed (see the
  PUBLISHED entry above). A profile `pnpm update` now restores the official
  npm 0.2.4 (no longer needs the stopgap dist+src copy).

## 2026-09-24 — DSH 0.1.7-rc.1 detected → verified compatible, NO release needed (devDeps pinned, advertisement +1)
- **New DSH release detected**: `0.1.7-rc.1` (2026-09-23T13:25Z) under the
  **`next`** dist-tag (alpha stays 0.1.7-alpha.2; latest still stale
  0.0.1-rc.1), tag `dsh-v0.1.7-rc.1` (`46a7f68b09`, PR #5073); **156
  commits** since 0.1.7-alpha.2. Verified on all 12 relevant packages.
  Full analysis: `docs/adapt-dsh-0.1.7-rc.1.md`.
- **Compat verdict: 0.2.3 already works on rc.1 — no release.** Compat
  surface source-unchanged (webserver/frontend-static/settings/credentials/
  web-app rows/connection waterfall/runtime/ui-slots); wire registry only
  gained a type re-export. Sole wire addition:
  `agentPresets.readDocument` (admin namespace → deny-by-default for
  ordinary users already; admins pass). Gateway changes are internal
  stream-cancellation hygiene.
- **NEW upstream mechanism (PR #5061) — plugin/bundle compatibility
  admission**: app-boot now evaluates every bundle's + row's
  `@deepseek-ai/dsh*` peerDependencies against the running runtime with
  `semver.satisfies(..., { includePrerelease: true })`; incompatible
  bundles are stderr-reported and SKIPPED (patch layer never loads),
  incompatible rows disabled, Include trees denied whole; exemption =
  profile `compatibility.json` (exact `name@version` → exact runtime
  versions) via `dsh plugin allow-version --accept-risk`. dsh-login 0.2.3
  passes (its peers admit rc.1; boot check is MORE lenient than npm's
  install-time tuple rule). **Operational fail-open note**: a future DSH
  beyond the peer ranges makes the bundle skip → GUI boots WITHOUT the
  login wall (stderr diagnostic only) — always verify dsh-login loaded
  after upgrading DSH.
- **Changes shipped in-repo (not published)**: devDeps → `^0.1.7-rc.1`
  (10 pkgs; incremental install ERESOLVE'd on the stale tree → fresh
  reinstall per runbook, exit 0; no new transitive peers); `capabilities.ts`
  adminOnlyMethods() += `agentPresets.readDocument` (advertisement
  accuracy discipline); `dist/client.js` re-stamp byte-identical (37134
  chars — connection client unchanged). Suite green **18 files / 207
  tests** on real rc.1 builds; verify:imports exit 0; build exit 0.
- Multi-user at rc.1: still NONE (0 grep hits; `account` namespace still
  the single process-wide Platform grant). Role-based whole-UI control:
  still infeasible (runtime/ui-slots source-unchanged, 0 hits; rc.1's
  compatibility machinery is per-plugin admission, not per-user
  visibility). Upstream asks unchanged: docs/adapt-dsh-0.1.6.md §6.

## 2026-09-23 (later) — PUBLISHED 0.2.3 (DSH 0.1.7-alpha.2 adaptation)
- **`@islibaodong/dsh-login@0.2.3` is LIVE on npmjs** (`latest = 0.2.3`,
  tarball 31 files / 148.5 kB, shasum `b543eec6240bf25a0784efd2cbcf78ef2619d383`,
  unpacked 515.9 kB). Stage id `806b86ab-ebd2-43cd-a506-178832a1e3e0`.
  Publish path = the 0.2.2 runbook, executed end-to-end this session: the
  0.2.2 token was dead again (whoami E401) → fresh **web login** in an
  interactive `Start-Process powershell` window (whoami polling confirmed
  `islibaodong` after one 30s poll) → `npm pack --dry-run` (31 files,
  shasum b543eec6…; no `.env` side effect this time) → `npm stage publish
  ./ --registry=https://registry.npmjs.org` (prepack rebuild deterministic —
  staged shasum identical to dry-run) → `npm stage approve <id>` in another
  interactive window → user approved in the browser → dist-tags polled until
  `latest` flipped to 0.2.3 (3rd 15s poll). `npm view @0.2.3` re-verified
  version + dist-tags on the official registry.
- Release commit `5a664a5` (the 0.2.3 adaptation, 13 files +1305/−331);
  **git tag `v0.2.3` + master pushed to GitHub** (the `dsh plugin add
  github:islibaodong/dsh-login` install channel). Git push stderr shows a
  cosmetic PowerShell NativeCommandError wrapper around git's progress line —
  push succeeds.
- Hygiene: the fresh `//registry.npmjs.org/:_authToken` from this login sits
  in `~/.npmrc` — revoke it on npmjs.com if the machine is shared (same note
  as after 0.2.1/0.2.2; past tokens were revoked and each release needed a
  fresh web login — expect the same next time).

## 2026-09-23 — DSH 0.1.7-alpha.2 RELEASE DETECTED → adapted (0.2.3 — published, see the entry above)
- **New DSH release detected** (third same-day re-check found it; 09-21's two
  checks predate it): `@deepseek-ai/dsh-*` `0.1.7-alpha.1`
  (2026-09-22T06:10Z) + `0.1.7-alpha.2` (2026-09-22T15:54Z) under the
  **`alpha`** dist-tag; harness tags `dsh-v0.1.7-alpha.1` (`c36a83ff6b`) /
  `dsh-v0.1.7-alpha.2` (`00102833df`); **1461 commits** since 0.1.6-alpha.2;
  vendored cordis 4.0.4 / schemastery 3.18.4 / include 1.0.9 / loader 1.0.5.
  Full analysis + adaptation: `docs/adapt-dsh-0.1.7.md`.
- **Compat surface**: webserver (gzip multipart only), frontend-static
  (`<base href="./">` sub-path mounts), web-app rows (**`web-runtime` +
  `connection` untouched — patch applies as-is**), credentials main entry,
  session/terminal/workspace-files/goal/llm/skill/subagent wire faces all
  compatible. `connection/request` waterfall survives (now
  `webCtx.waterfall`, string-first) — the api-bridge-auth wall works as-is.
  What changed and mattered:
  1. **`dsh-settings` rewritten** (provider seam → `SettingsForms`):
     `ctx.settings` + merge-patch `update(ns, patch)` survive; the
     `SettingsProvider` type export is gone → remote-web-ui-compat.ts now
     uses a local structural `SettingsWriteSeam` (no upstream type imports).
  2. **New namespace `account`** (api-account-controller): startSignIn/
     cancelSignIn/signOut drive the ONE process-wide upstream DeepSeek
     Platform grant; reads leak the operator's profile/wallet balance →
     strictly admin-only (USER_ALLOWED absent + ADMIN_ONLY_NAMESPACES +
     two-segment deny list + quiet-deny reads + admin advertisement).
  3. **New namespace `job`** (api-job-controller; SessionJob moved out of
     `session`): list/follow streams + kill, all sessionId-scoped →
     USER_ALLOWED += job.list/follow/kill; USER_DOMAINS += job; `jobId`
     deliberately NOT a guarded field (not in the ownership sidecar —
     collecting it would deny legitimate kills).
  4. **workspace += pinSession/unpinSession** → USER_ALLOWED += both.
  5. `agentPresets` package renamed (`dsh-agent-presets` →
     `dsh-agent-preset-registry`) but the **wire namespace stays
     `agentPresets`** — admin lists unchanged. settings wire methods are
     `describe/update/replace` (`canOpenAgentPresetDirectory` removed;
     `settings.list/reset` never existed on the wire — advertisement
     corrected). New `pluginRegistryProbe` (bundled plugin-manager UI)
     advertised admin-only.
- **Dependencies**: peerDependencies retargeted (tuple convention) to
  `>=0.1.5-alpha.1 <0.2.0-0 || >=0.1.6-alpha.1 <0.2.0-0 || >=0.1.7-alpha.2
  <0.2.0-0` for all six dsh peers — the new branch is MANDATORY
  (node-semver prerelease rule: 0.1.7-alpha.2 does not satisfy
  `>=0.1.6-alpha.1`; this exact mismatch caused the ERESOLVEs). devDeps
  pinned to ^0.1.7-alpha.2 incl. NEW exact-pinned transitive peers
  **dsh-scope / dsh-session / dsh-brand** (dsh-client-connection peers on
  them; omitting them also ERESOLVEs) + cordis 4.0.4 + schemastery 3.18.4 +
  include 1.0.9 + loader 1.0.5. Clean reinstall regenerated the lockfile.
- **Verification**: `dist/client.js` re-stamped from the 0.1.7 connection
  client (37134 chars); full suite **green 18 files / 207 tests** (203 + 4
  new 0.1.7 regression tests: job/pin grants scoped to owned sessions,
  foreign-session kill denied, account denied for ordinary users + admin
  passthrough, three-layer account posture); `verify:imports` exit 0; build
  exit 0. Publish needs the user (`npm stage publish` + npmjs 2FA).
- **Multi-user detection at 0.1.7**: still NO native multi-user (0 grep
  hits; no user/account/auth package; the new `account` namespace manages
  the single process-wide Platform grant — reinforces the one-operator
  model). dsh-login remains the multi-user layer.
- **Role-based whole-UI control at 0.1.7**: still infeasible —
  `packages/client/runtime` is byte-identical to 0.1.6 (activates every
  bundle unconditionally, no identity gate), ui-slots ±5 lines
  (`renderFactorySlot()` still takes no Session identity), zero
  permission/isAdmin/isAllowed/role hits in both. `permission-presets`
  (packages/interaction/permission-presets) is Agent-execution permission
  modes (sandbox × approval presets), NOT user-account RBAC. Upstream asks
  unchanged: docs/adapt-dsh-0.1.6.md §6.
- Env notes: `npm install-scripts` now warns that esbuild's postinstall is
  not allowScripts-covered (build still worked). The 09-21 gotcha about
  `npm view <pkg> dist-tags --json` returning the top-level tags object
  (not nested) cost one false-alarm re-run — remember `$d.alpha`.

## 2026-09-21 — DSH release re-check: still NO new version (tri-source, all fresh)
- **Detection result**: no DSH release since `0.1.6-alpha.2`. Three independent
  sources, all fetched fresh this session: (1) npm official registry
  (`--registry=https://registry.npmjs.org`) — all six peer packages PLUS
  `dsh-web-app`, `dsh-invariants` end at `0.1.6-alpha.2`, dist-tags unchanged
  (alpha=0.1.6-alpha.2, next=0.1.5-rc.2, `latest` still stale 0.0.1-rc.x;
  cordis latest=4.0.2); (2) harness git fetch (succeeded on the HTTP/1.1
  retry) — newest tag `dsh-v0.1.6-alpha.2`, `origin/master` == `ddefc45fbc` ==
  the release merge, **0 post-release commits**; (3) github API tags
  (`api.github.com/repos/deepseek-ai/deepseek-harness/tags`) — newest tag
  `dsh-v0.1.6-alpha.2` @ `ddefc45fbc`. (The HTML tags page fetch failed with a
  network TypeError; the API endpoint was used as the third source instead.)
  → **No compatibility adaptation required**; published
  `@islibaodong/dsh-login@0.2.2` remains the current adapted release (peer
  ranges admit alpha.2, exclude 0.1.7-alpha.x).
- **Fresh compat verification (evidence today, not inherited)**: node_modules
  confirmed at real `0.1.6-alpha.2` for all seven `@deepseek-ai/dsh-*` deps
  (six peers + invariants); full vitest suite **green 18 files / 203 tests**
  (exit 0, 9.57s). Plugin works as-is on the current latest release.
- **Multi-user detection (re-verified at the release tag)**: `git grep -ilE
  'multi.?user|multiuser|role.?based|\brbac\b' dsh-v0.1.6-alpha.2 --
  packages/` → **0 hits**; the package listing has no user/account/auth
  package (`identity` matches only `anonymous-user-id` — telemetry
  correlation ids, not accounts). Still NO native multi-user; dsh-login
  remains the multi-user layer.
- **Role-based whole-UI control (re-verified)**: still infeasible — **0 hits**
  for `permission|isAdmin|isAllowed|role` in `packages/client/runtime/src` +
  `packages/client/ui-slots/src` (client runtime still activates every bundle
  unconditionally; no per-identity slot filter / activation gate / role
  concept; ui-slots README still states `renderFactorySlot()` accepts no
  Session identity). The one webserver `middleware` grep hit is gzip
  `NodeMiddleware` (compression) — still **no pre-routing auth hook**, so
  plugin-self-registered exact routes remain outside any gate. Upstream asks
  unchanged: docs/adapt-dsh-0.1.6.md §6.
- Environment note: the HTTP/1.1 `git fetch` retry workaround from gotchas.md
  was used directly this session and succeeded (plain fetch not attempted, so
  whether the TLS EOF is still live is unknown).

## 2026-09-19 (later) — DSH release re-check: still NO new version (fresh tri-source evidence)
- **Detection result**: no DSH release since `0.1.6-alpha.2`. Three independent
  sources, all fetched fresh this session: (1) npm official registry — all six
  peer packages end at `0.1.6-alpha.2`, `time.modified` 2026-09-17T13:38–13:57Z,
  dist-tags unchanged (alpha=0.1.6-alpha.2, next=0.1.5-rc.2, latest stale
  0.0.1-rc.x); (2) harness git fetch (succeeded on HTTP/1.1 retry) — newest tag
  `dsh-v0.1.6-alpha.2`, origin/master == `ddefc45fbc` == the release merge,
  zero post-release commits; (3) github.com/deepseek-ai/deepseek-harness tags
  page — newest tag `dsh-v0.1.6-alpha.2` (2026-09-17). → **No compatibility
  adaptation required**; published `@islibaodong/dsh-login@0.2.2` remains the
  current adapted release (peer ranges admit alpha.2, exclude 0.1.7-alpha.x).
- **Fresh compat verification (evidence today, not inherited)**: node_modules
  confirmed at real `0.1.6-alpha.2` tarballs for all six peers (plugin at
  0.2.2); full vitest suite **green 18 files / 203 tests** (exit 0, 44.1s).
  Plugin works as-is on the current latest release.
- **Multi-user detection (fresh at the release tag)**: `git grep -ilE
  'multi.?user|multiuser|role.?based|\brbac\b' dsh-v0.1.6-alpha.2 --
  packages/` → zero hits; the package listing has no user/account/auth
  package (`packages/identity` remains telemetry correlation ids). Still NO
  native multi-user; dsh-login remains the multi-user layer.
- **Role-based whole-UI control (fresh at the release tag)**: still
  infeasible — zero hits for `permission|isAdmin|isAllowed` in
  `packages/client/runtime/src` and `packages/client/ui-slots/src` (client
  runtime still activates every bundle unconditionally; no per-identity slot
  filter / activation gate / role concept). Upstream asks unchanged:
  docs/adapt-dsh-0.1.6.md §6.
- **Environment note**: `git fetch` against github.com failed once with
  "TLS connect error: unexpected eof while reading"; retrying with
  `git -c http.version=HTTP/1.1 fetch --tags origin` succeeded (recorded in
  gotchas.md).

## 2026-09-19 (later) — PUBLISHED 0.2.2 (DSH 0.1.6-alpha.2 adaptation)
- **`@islibaodong/dsh-login@0.2.2` is LIVE on npmjs** (`latest = 0.2.2`,
  tarball 31 files / 144.4 kB, shasum `3e7f02a2c836f5965853e1a2548ef2a984972ac5`).
  Stage id `3c59197f-1271-4c3f-872b-6a59a1d5ce05`. Publish path = the 0.2.1
  runbook: the 0.2.1 login's leftover token had been revoked (whoami E401) →
  fresh **web login** in an interactive `Start-Process powershell` window
  (non-TTY gets the redacted URL; interactive auto-opens the browser and
  polls) → `npm stage publish ./ --registry=https://registry.npmjs.org`
  (prepack rebuild ran; deterministic) → `npm stage approve <id>` in another
  interactive window → user approved 2FA in the browser → dist-tags polled
  until `latest` flipped to 0.2.2. The "NO new version" entry below was the
  auto-captured re-check session that ran between adaptation and publish; it
  correctly found 0.1.6-alpha.2 still latest — no conflict with the 09-18
  adaptation above.
- Hygiene: the fresh `//registry.npmjs.org/:_authToken` from this login sits
  in `~/.npmrc` — revoke it on npmjs.com if the machine is shared.
- Git tag `v0.2.2` + master pushed to GitHub (the `dsh plugin add
  github:islibaodong/dsh-login` install channel).

## 2026-09-19 — DSH release check: NO new version (0.1.6-alpha.2 still latest)
- **Detection result**: no DSH release since `0.1.6-alpha.2`. npm official
  registry (`--registry=https://registry.npmjs.org`, mirror has propagation
  delay): all six peer packages (`dsh-host-webserver`, `dsh-client-connection`,
  `dsh-credentials`, `dsh-host-frontend-static`, `dsh-settings`,
  `dsh-web-frontend`) end at `0.1.6-alpha.2`; dist-tags unchanged (`latest`
  stale at 0.0.1-rc.x, `next` 0.1.5-rc.2, `alpha` 0.1.6-alpha.2). Harness git:
  newest release tag `dsh-v0.1.6-alpha.2` = commit `ddefc45fbc` (PR #4469,
  release merge) and `origin/master` == that same commit — zero post-release
  commits at fetch time. → **No compatibility adaptation required**; 0.2.2's
  peer ranges already admit alpha.2 and exclude 0.1.7-alpha.x.
- **Fresh compat verification** (evidence today, not inherited): node_modules
  confirmed at real `0.1.6-alpha.2` tarballs (cordis 4.0.2); full vitest suite
  **green 18 files / 203 tests** (8.25s). Plugin works as-is on the current
  latest release. 0.2.2 remains adapted+verified+unpublished (publish needs
  the user: `npm stage publish` + npmjs 2FA).
- **Multi-user detection (re-verified at the release tree)**: `git grep -iE
  'multi.?user|multiuser|role.?based' dsh-v0.1.6-alpha.2 -- packages/` → zero
  hits. Still NO native multi-user; dsh-login remains the multi-user layer.
- **Role-based whole-UI control (re-verified)**: still infeasible at
  0.1.6-alpha.2 — `ui-slots` "identity" hits are diagnostics/definition/scope
  identities only (no per-user/role slot filter or activation gate);
  `client/runtime/src` has ZERO hits for role/permission/isAdmin/isAllowed
  (client runtime still activates every bundle unconditionally). Upstream
  asks unchanged: docs/adapt-dsh-0.1.6.md §6.
- **Environment note**: the `E:\code\deepseek-harness` working tree is STALE
  (HEAD `0d1f50007f`, 882 commits behind the alpha.2 tag / origin/master).
  Release-state analysis must grep the TAG (`git grep <pat>
  dsh-v0.1.6-alpha.2 -- packages/`), not the tree; runtime truth for tests is
  node_modules. Recorded in gotchas.md.

## 2026-09-18 — DSH 0.1.6-alpha.2 adaptation + /api bridge auth wall (0.2.2, unpublished)
- **New DSH release detected**: `@deepseek-ai/dsh-*` `0.1.6-alpha.2` on npm under
  the **`alpha`** dist-tag (`latest` still stale at 0.0.1-rc.x; `next` at
  0.1.5-rc.2). Harness tag `dsh-v0.1.6-alpha.2` (commit `ddefc45fbc`). Full
  analysis in `docs/adapt-dsh-0.1.6-alpha.2.md`.
- **Compat surface**: webserver / frontend-static / settings / credentials /
  web-app `web-runtime`+`connection` rows all source-unchanged — the shipped
  `cordis.patch.yml` applies as-is. What changed and mattered:
  1. **`connection/request` waterfall** (dsh-client-connection): the native
     /api route now lets a listener admit/wrap/veto each bridged request →
     dsh-login 0.2.2 registers an **/api bridge auth wall**
     (`src/api-bridge-auth.ts`, config `apiBridgeAuth`, default true): 401
     without a valid `dsh_session`; closes the option-A hole where the
     process-wide browser-auth cookie outlived logout. Cordis mechanics
     verified: one shared hook registry (root EventsService, prototypally
     inherited), string-first waterfall args → no dispatch filter → the
     listener fires from any fiber; `{global:true}` for future-proofing. On
     DSH < 0.1.6-alpha.2 the event never fires (no-op, 0.1.5 peer branch safe).
  2. **`terminal.retain`** new wire method (retention) → USER_ALLOWED;
     alpha.2 user terminals now run with **system-user permissions** (no
     sandbox) — terminal.* grants are stronger than at alpha.1 (posture note
     in docs §4).
  3. **New namespace `officeToPdf`** (`render`/`generation`, document-preview
     conversion) + the previously-unlisted `workspaceFiles` read surface →
     added to USER_ALLOWED/USER_DOMAINS (document preview for ordinary users).
     The scoped session identity rides the wire as **`workspaceFileScopeId`**
     (confirmed from generated typert descriptors) → added to the guard's
     GUARDED_ID_FIELDS.
  4. **New namespace `pluginManager`** (native bundle install/remove) →
     admin-only: guard ADMIN_ONLY_NAMESPACES += pluginManager; admin
     capabilities advertise it; ordinary advertisement forbids it.
- peerDependencies UNCHANGED — node-semver verified the shipped range already
  admits 0.1.6-alpha.2 (same [0,1,6] tuple) and still excludes 0.1.7-alpha.1.
- **Multi-user detection**: still NO native multi-user at alpha.2 (zero
  multi-user/rbac hits; identity pkg = telemetry ids; one process-wide
  browser session). dsh-login remains the multi-user layer.
- **Role-based whole-UI control**: still infeasible — ui-slots' +522 lines are
  Component Factories (reusability); README explicit that renderFactorySlot
  takes no Session identity; no per-identity slot filter / activation gate /
  role concept; client runtime still activates all bundles. The bridge wall
  makes the API layer role-aware, but whole-UI visibility control still needs
  the upstream asks in docs/adapt-dsh-0.1.6.md §6.
- remote-web-ui note (verified against its 0.3.23 tarball): `/api/pair/*` are
  webServer EXACT routes (pre-login pairing unaffected by the wall); its
  `/remote` paired-device channel re-issues requests server-side without
  dsh_session → 401 with the wall on (by design — pairing is a full-control
  credential outside the user model; deployments wanting it set
  `apiBridgeAuth: false`).
- Suite green **18 files / 203 tests** against published 0.1.6-alpha.2 builds;
  `verify:imports` exit 0; `npm run build` green (dist re-stamped from the
  alpha.2 connection client). Publish needs the user (`npm stage publish` +
  npmjs 2FA approval).

## 2026-09-17 (later) — PUBLISHED 0.2.1 + login-page redesign ride-along
- **`@islibaodong/dsh-login@0.2.1` is LIVE on npmjs** (`latest = 0.2.1`), git tag
  `v0.2.1` + master pushed to GitHub (the plugin's other install channel). Full
  publish-path record in `docs/adapt-dsh-0.1.6.md` §7.
- Between sessions the adaptation had already been committed (`7d4e4ec`) and the
  **login-page redesign** (entry below) landed on top (`762d3f7`, src/login-page.ts
  ±661, no spec changes — suite still green 17 files / 192 at publish time). Its
  dist was already rebuilt+committed pre-publish; a post-redesign rebuild was
  byte-identical (deterministic esbuild output). The leftover uncommitted
  changelog session-log was committed as `0279a16 chore(release): 0.2.1 —
  rebuild dist (redesigned login page) + session log` — the release commit.
- Publish runbook that worked (npm 11.19, mirror-default machine):
  1. Machine default registry is **npmmirror** (`registry=npmmirror.com` in
     ~/.npmrc) — whoami/login/publish ALL need explicit
     `--registry=https://registry.npmjs.org`. A default `npm login` opens an
     npmmirror login session, which cannot publish.
  2. The stored npmjs token was dead (0.2.0's granular token had been revoked
     as reminded) → fresh **web login** (`--auth-type=web`). Shell caveat:
     piping npm through `Select-Object -First N` stops the pipeline and kills
     the login mid-flow; stream without `First`.
  3. Direct `npm publish` → **EOTP**; npm's browser-auth URL is redacted to
     `***` in captured output AND the debug log — unrecoverable non-TTY.
  4. Working path: `npm stage publish` (stage id
     `1a545a63-427c-482a-9010-2408f129fbc7`; tarball identical to dry-run,
     30 files / 136.6 kB, shasum d0bfb0c7…) → `npm stage approve` in an
     **interactive terminal window** (Start-Process powershell; `pwsh` was not
     on PATH for Start-Process) → npm auto-opens the browser, polls, completes
     after the user's 2FA approval.
  5. Verified `npm view @islibaodong/dsh-login dist-tags` → latest 0.2.1.
- npm login left a FRESH `//registry.npmjs.org/:_authToken` in ~/.npmrc —
  remind user to revoke it on npmjs.com if the machine is shared.
- npmmirror mirrors the published tarball with propagation delay; verify
  against the official registry, not the mirror.

## 2026-09-17 — login page visual redesign (万物皆插件 identity)
- `src/login-page.ts` fully redesigned (frontend-design skill pass), both
  `renderLoginPage` and `renderSetupPage` now share one `renderPage` shell.
- Visual identity: the "everything is a plugin" motif — the page is a plugin
  board (faint 72px grid backdrop + 8–16 JS-placed plugin tiles snapped to the
  grid, some "lit" with a slow breath glow; tiles hidden <420px), and the login
  card IS the dsh-login plugin: a connector tab on the top edge
  (`::before` with two pin dots), a plugin-row header (inline plug SVG +
  `dsh-login` + pkg id + status dot 已加载), and the footer line
  「万物皆插件，这道门也不例外。」. Setup page headline 初始化 DSH.
- Palette (DSH deep-navy): bg `#0f1420`, panel `#151b2c`, inset `#0d1220`,
  line `#262f47`, accent `#6f9bff`, ok `#46d19a`, danger `#ff7a7a`. System
  font stack (no external assets — spec forbids `src="http`/`href="http`/
  `<link`). Copy now zh-CN.
- Motion budget: one orchestrated load (card rise 120ms-delayed + tiles
  staggered in at 45ms), then only the lit tiles' 7s breath;
  `prefers-reduced-motion` disables everything. Focus-visible rings on
  inputs/button; error area keeps `role="alert"`.
- Test compatibility preserved (login-page.spec guards `name="username"`,
  autocomplete attrs, `id="confirm"`, endpoints, no external resources, dark
  background); full suite green **17 files / 192 tests**.
- Local check: node 24 type-strips the TS — a throwaway .mjs importing
  `src/login-page.ts` rendered `preview-login.html` / `preview-setup.html`
  (gitignored `/preview-*.html`), opened in the browser. Artifact preview was
  unavailable (AUTH_TOKEN session, no claude.ai login).

## 2026-09-17 — DSH 0.1.6-alpha.1 compatibility adaptation (0.2.1, unpublished)
- **New DSH release detected**: `@deepseek-ai/dsh-*` `0.1.6-alpha.1` on npm under the
  **`alpha`** dist-tag (`latest` is stale at 0.0.1-rc.x; `next` at 0.1.5-rc.2). Harness
  tag `dsh-v0.1.6-alpha.1` (release commit `ea53423b60`, PR #4171); 800 commits since
  `dsh-v0.1.5-rc.2`. Full analysis in `docs/adapt-dsh-0.1.6.md`.
- **Compatibility surface**: host packages the plugin integrates with are source-unchanged
  (webserver incl. `webserver/index-inject`, frontend-static 6-arg `serveStatic`, settings,
  credentials). New/changed that matters: (1) new `dsh-api-terminal-controller` — typert
  namespace `terminal`, 9 agent-scoped methods (environment/shells/list/create/follow/write/
  resize/rename/close), new web-app rows `terminal-controller` + `ui-sidebar-terminal`;
  (2) new `workspace.unarchiveSession` wire method; (3) web-app cordis rows −`code-runtime`,
  `workflow-worker-thread`→`workflow-ptc`, +`ui-settings-unarchive-sessions`. The rows
  dsh-login patches (`web-runtime` disable, `connection` keep-enabled) are untouched —
  the shipped `cordis.patch.yml` applies to 0.1.6 as-is.
- **Local-env incident**: the 09-14 `npm install` reset node_modules to the lockfile's
  0.1.1-rc.2 builds (the previously hand-advanced bits were lost) — 0.1.1's 5-arg
  `serveStatic` turned the plugin's `authorizeIndex` callback into the `renderIndex` slot
  → 4 failures (gateway static/index specs + one full-composition boot). Fixed by pinning
  devDeps to real `0.1.6-alpha.1` tarballs, which also made the suite exercise the new
  release. `vitest` has NEVER aliased to the harness checkout at runtime — only tsconfig
  `paths` do (types); runtime resolution is node_modules. The old gotcha claiming
  checkout aliases was wrong/stale.
- **Shipped in 0.2.1 (version bumped, NOT published)**: peerDependencies retargeted to
  `>=0.1.5-alpha.1 <0.2.0-0 || >=0.1.6-alpha.1 <0.2.0-0` (same tuple convention: 0.1.6
  prereleases/stable included, future 0.1.7-alpha.x excluded); `USER_ALLOWED` +=
  `workspace.unarchiveSession` + the nine `terminal.*` methods (agent-scoped by the
  Gateway = same trust boundary as `session.prompt`; `terminal.list`'s explicit
  `sessionId` is ownership-guarded); `USER_DOMAINS` += `terminal`; +3 tests. Suite green
  **17 files / 192 tests** against published 0.1.6-alpha.1 builds; `verify:imports` exit 0;
  build green. Publish needs the user (`npm stage publish` + npmjs approval — token is
  staging-only).
- **Multi-user detection**: DSH 0.1.6 still has NO native multi-user support (grep
  `multi-user|multiuser` zero hits; `packages/identity` = telemetry correlation ids, not
  accounts; `packages/guard` = loop hygiene; `packages/sandbox` = process-confinement seam
  — a future building block, not multi-user). dsh-login remains the multi-user layer.
- **Role-based whole-UI control**: still infeasible at 0.1.6 — `ui-slots` source-unchanged
  (no per-identity slot filter / activation gate / role concept), client runtime still
  activates all bundles, third-party plugin exact routes still outside any gate. Upstream
  asks recorded in `docs/adapt-dsh-0.1.6.md` §6.
- Memory-file staleness flag: `architecture.md`/`modules.md`/`api.md` still describe the
  pre-option-A `/api` takeover (connection.ts/api-filter createUserProxy era); the
  changelog entries of 2026-09-08/11 + `docs/adapt-dsh-0.1.5.md` are the current truth.

## 2026-09-11 — npm release 0.2.0 (option A adaptation)
- Published `@islibaodong/dsh-login@0.2.0`: the DSH ≥ 0.1.5-alpha.1 option-A adaptation
  (no /api takeover; native connection row; remote-guard isolation seam exported from the
  host bundle) plus the code-review hardening. Version is a **minor** bump per 0.x semver
  convention (carries breaking changes: requires DSH ≥ 0.1.5-alpha.1, `./connection` /
  `./connection-client` exports removed).
- **peerDependencies retargeted** to `>=0.1.5-alpha.1 <0.2.0-0` for all six `@deepseek-ai/dsh-*`
  peers. The old `>=0.1.1-rc.0 <0.2.0-0` branch silently EXCLUDED `0.1.5-alpha.1` (node-semver
  prerelease rule: a prerelease version only satisfies a range containing a comparator with the
  same [major,minor,patch] tuple — PUBLISHING.md §四 pitfall). The new range covers the whole
  0.1.5 line (alpha.1/alpha.2/rc.1/rc.2/stable): tuple [0,1,5] matches the `>=0.1.5-alpha.1`
  comparator; future 0.1.6-alpha.x is (correctly) excluded. The floor is honest: option-A code
  requires the 6-arg serveStatic + string settings namespace + connection.authorizeIndex, none
  of which exist before 0.1.5-alpha.1.
- devDependencies left at `^0.1.1-rc.2` deliberately (published tarball excludes devDeps and the
  lockfile; builds keep `@deepseek-ai/*` external; local node_modules/lockfile already diverged —
  don't churn the verified-green environment). Known wart: a fresh `npm ci` installs 0.1.1-rc.2
  types; vitest resolves the real 0.1.5 sources via checkout aliases.
- `npm pack --dry-run`: 30 files / 121.4 kB (0.1.0 was 23 files / 120.9 kB). LICENSE is in the
  tarball (head-truncated notice output looks like it's missing — it isn't).
- npm toolchain side-effect: `npm pack` created an empty `.env` in the repo root; unstaged and
  gitignored (`/.env`).
- **Published 2026-09-11:** `@islibaodong/dsh-login@0.2.0` LIVE on npmjs (latest = 0.2.0,
  tarball `dsh-login-0.2.0.tgz`). Publish path hit two auth walls of npm's evolving 2FA policy:
  (1) the stale `//registry.npmjs.org/:_authToken` in `~/.npmrc` was dead (whoami E401, publish
  PUT 404 — npmjs returns 404 for an underprivileged publish); (2) after a fresh web `npm login`,
  direct `npm publish` gave E403 `E_STAGE_REQUIRED` — the account's granular token is
  **staging-only** (npm tightening bypass-2FA direct publish; per gh.io/npm-gat-bypass2fa-deprecation),
  so it published via `npm stage publish` → user approved on npmjs.com → 0.2.0 went live.
  Hygiene: temp publish npmrc (in `%TEMP%`), the repos' `.env`, and `npm_recovery_codes.txt`
  (created by `npm login`) were all deleted after publish; `/.env` + `/npm_recovery_codes.txt`
  gitignored. Remind user to revoke the granular token on npmjs.com.

## 2026-09-08 — code-review fixes for the option-A guard (requesting-code-review round)
- External code review of the option-A adaptation returned "with fixes". Applied the
  in-repo-fixable items:
- **(#2) package.json dangling exports:** removed `./connection` and `./connection-client`
  export entries (both pointed to deleted `dist/connection*.js`).
- **(#3) guard ID-scan hardening:** `collectIds()` now recurses arrays and nested
  `{id}/{sessionId}/{workspaceId}/{agentId}` records, not just top-level string fields;
  enabled `sessionIds`/`parentSessionIds`/`childSessionIds`/`agentId` fields. `ownershipGuarded`
  rejects any collected foreign id. 3 new regression tests (array `sessionIds`, array of nested
  `{id}`, nested `agentId`), all pass.
- **(#4 admin) `createRemoteIsolation` admin resolution:** new optional `isAdminSession(sid)`
  short-circuits before the sidecar, so an admin session with no ownership record still resolves
  as admin (admin passes the guard unfiltered). `owns` returns true for an admin. 2 new tests.
- **(#4 activation) guard reachable from the artifact:** `src/index.ts` re-exports
  `wrapRemoteGateway`/`createRemoteIsolation` (+ types), so `dist/index.js` carries them for
  deployment composition. **Reconciled with the architecture:** a runtime `isolateRemote`
  re-provide would be a duplicate-service conflict (docs confirmed); the guard remains a
  composition primitive, not a hot-swap — documented in README + verify-option-A §B.
- **(#7 README/zh resync):** removed the false "isolation working" claim and the stale
  "disables the connection row" manual-install block + `/api takeover` ASCII diagram; test count
  168 → 184; project-structure adds `remote-guard.ts`; EN+ZH both describe the composition
  primitive truthfully. remote-guard.spec now **21 tests**; suite green **17 files / 189 tests**;
  imports exit 0; build exit 0.
- Remaining (genuinely boot-bound): compose the guard over the native `typertGateway` in a real
  deployment + two-browser isolation behavioral sign-off (§B).

## 2026-09-08 — composed seam end-to-end tests (item 3 progress)
- Added 3 integration tests to `remote-guard.spec.ts` composing the whole seam:
  a fake `agents` service → `createRemoteIsolation` → `wrapRemoteGateway` → fake gateway.
  Verifies: a user may read their own session, a foreign session is blocked before reaching
  the gateway, two users are isolated per the active agent, non-admin denied admin namespaces.
  remote-guard.spec now 16 tests; suite green **17 files / 184 tests**; imports exit 0;
  build exit 0.
- `cordis.patch.yml` comment corrected (`/admin` → 设置→用户管理); composition already
  option-A coherent (connection enabled, web-runtime disabled, plugin row present).
- Remaining (genuinely boot-bound): compose the guard over the native `typertGateway` in a
  real deployment + two-browser isolation behavioral sign-off.

## 2026-09-08 — remote-guard glue fix (owns user-scoped) + createRemoteIsolation coverage
- Writing tests for `createRemoteIsolation` exposed a real bug: its `owns` predicate was
  user-independent (`lookup(id) !== undefined`), so user A would "own" user/workspace ids
  belonging to any user who has an ownership record. Fixed: `owns` now scopes to the resolved
  user (`ownership.lookup(id) === user.username`), fail-closed when the caller can't be
  resolved.
- Added 5 `createRemoteIsolation` tests (resolve user from current session id via sidecar;
  user-scoped owns; isAdmin callback; fail-closed on no current session; fail-closed on
  unknown session). Suite now green **17 files / 181 tests**; imports exit 0; build exit 0.
- Remaining: compose the guard over native typertGateway + two-user boot sign-off (§B).

## 2026-09-08 — option A settings-panel client re-home (verified)
- `src/settings-panel.client.js`: standalone `dsh.client` — removed the stale
  `@islibaodong/dsh-login/connection` require and the `connection` provision
  (the native `connection` row owns /api under option A); registers 设置→用户管理/账户
  over `slots`+`locale` only.
- `scripts/build-client.mjs` recreated: `dist/client.js` = a single
  `__ModuleLoader__.load({ id:"@islibaodong/dsh-login", factory })` closure over the panel
  (no connection re-stamp). `package.json` `build` = `build:host && build:client`.
- Removed stale `dist/connection*.js`; `dist/` now only `index.js` + `client.js`.
- Tests updated: `settings-panel.client.spec.ts` (dropped connection-apply assertions),
  `client-bundle.spec.ts` (single-registration option-A shape). Suite green 17/176.
- Remaining isolation gap (also handoff §B): composed guard; needs multi-user web boot.

## 2026-09-08 — CORRECTION: "blocked" was wrong; build + seam are achievable in this session
- Earlier round marked the goal blocked citing (1) "no webServer" and (2) "no TS toolchain".
  Both were **refuted by in-session evidence**: `webServer` is a live injectable service
  (`ctx.get("webServer")` / `inject:["webServer"]`), the harness checkout has
  `node_modules/.bin/tsc` + `pnpm` + built `connection` lib, and this plugin's
  `npm run build:host` **succeeds** (`dist/index.js`, 46.2kb, bundle imports and exports
  `Config/apply/inject/name`). The earlier "no tsc" check ran `npx tsc` from the plugin
  workspace, missing the harness node_modules.
- Live seam characterization: `typertGateway` is injectable with
  `invoke({namespace,method,args})` / `stream`; `InvokeRemoteRequest` carries **no browser-user
  field** — Remote is agent-keyed (Typert Context/agentId). `connection` is NOT a catalogued
  service in this runtime (it's the web-profile transport row).
- New `src/remote-guard.ts` (`wrapRemoteGateway`): typertGateway RBAC wrapper — denies
  admin-only namespaces, denies methods outside the ordinary-user surface
  (`USER_ALLOWED`), denies args addressing a non-owned session/workspace (fail-closed `owns`
  default), admin passthrough. Wired with `resolveUser`/`owns` callbacks. 8 unit tests added;
  suite now **green 17 files / 176 tests**.
- Isolation-in-option-A conclusion: Remote is agent-keyed, so per-user isolation is best
  achieved by construction (each dsh-login user acts inside their own agent subtree recorded in
  the ownership sidecar) + the typertGateway guard. Remaining real deployment glue: the
  agentId→dsh-login-user resolver and owned-set lookup (needs a running multi-session web,
  which this agent session cannot host — no connection/multi-agent). Docs `verify-option-A.md`
  §B updated.

## 2026-09-08 — option A adaptation: host loads + test suite green on 0.1.5
- Continued `docs/adapt-dsh-0.1.5.md` option A. Verifiable state: `scripts/verify-imports.mjs`
  exit 0; **full vitest suite green (16 files / 168 tests)** against the built 0.1.5 harness
  (vitest runs in this workspace).
- `gateway.ts`: login wall (302 /login) restored in the handler; `authorizeIndex` param now
  only forwards to upstream `connection.authorizeIndex` (the 0.1.5 `serveStatic` 6-arg shape).
- Removed obsolete `tests/connection.spec.ts`, `tests/api-filter.spec.ts`,
  `tests/multiuser-e2e.spec.ts` (imported the deleted `dsh-host-apiproxy` takeover); updated
  stale `gateway.spec.ts` (renderIndex always injects boot manifest) and `plugin-entry.spec.ts`
  (no /api takeover → fallback 405).
- Build pipeline reconciled for option A: `build-host.mjs` bundles only `src/index.ts` →
  `dist/index.js`; `build-client.mjs` deleted; `package.json` `build` = `build:host`,
  `vendor/` dropped from files, `dsh-host-apiproxy`/`ws` deps removed.
- Still boot-bound (cannot run in this agent session — no webServer to boot, no TS toolchain):
  per-user isolation seam re-home, settings-panel client re-home + `dist` rebuild, isolation
  tests. Handoff in `docs/verify-option-A.md`.

## 2026-09-08 — analysis: dsh-login incompatible with DSH ≥ 0.1.5-alpha.1 (transport rework)
- Upstream `dsh-v0.1.5-alpha.1` removed the WebSocket-downlink event carrier that
  `src/connection.ts` takes over: commit `dcddaa1a6e` "replace legacy Host event carriers"
  deletes `packages/client/connection/src/websocket-downlink.ts` (`WebSocketDownlinks`,
  `rejectWebSocketUpgrade`), drops `HOST_EVENTS_PATH`/`MUX_EVENTS_PATH` from `api-path.ts`,
  changes `HostConnectionService` ctor to `(ctx, trustedHosts, browserAuth)` and
  `createSharedFetchHandler(channel)` to return a `ConnectionFetchHandler`, and (in a related
  rework) removes the `dsh-host-apiproxy` package (`ApiProxy`, `toFetchHandler`) that the whole
  per-user proxy layer in `api-filter.ts`/`connection.ts` was built on.
- New transport: unary `/api` stays in `dsh-client-connection`; live Remote streams move to a
  **gateway-owned WebSocket mux** (`packages/api/gateway` `TypertGateway` `RemoteStreamMuxServer`)
  fed by `dsh-api-remotes`; `dsh-client-connection` now ships its own **persistent single-session
  `BrowserAuth`** (HMAC cookie + process launch-token index exchange).
- Consequence: shipped dsh-login loads only against DSH `< 0.1.5-alpha.1`. Port is a redesign
  (compose a per-user ownership/authorization layer on the native connection+gateway rather than
  replacing the carrier; decide whether the `connection` row stays disabled; re-filter Remote
  streams at the controller or gateway layer; rebuild `dist/client.js`). Full plan in
  `docs/adapt-dsh-0.1.5.md`.
- Role-based control of third-party UI-plugin slots/sections: **still absent at 0.1.5**
  (`useSections` unchanged, no per-identity slot filter / activation gate).
- Not ported here: this workspace cannot build/verify the security-critical carrier rewrite
  (harness `lib` for apiproxy/connection unbuilt; `connection.ts` can't typecheck). Do not ship
  a blind port. README status + changelog updated to document the incompatibility.

## 2026-08-28 — boundary note: plugin-self-registered `/api/*` exact routes are outside dsh-login
- Regression found that UI plugins (e.g. `@linxin666/dsh-pet`) register their OWN
  exact routes (`/api/pet/pets`, `/api/pet/state`, …) via `webServer.register`
  and serve them with "no session dimension".
- DSH route precedence is **exact beats prefix** and **duplicate exact throws**
  (`packages/host/webserver/src/index.ts` `match()`), and the webserver exposes
  no pre-routing request hook. So dsh-login's `prefix: '/api'` carrier **cannot
  intercept** those plugin routes — they never reach dsh-login's auth layer.
  `/api/pet/pets` returns whatever the plugin serves (200 + public pet-asset
  metadata), not a dsh-login 403/204. Live: `GET /api/pet/pets` as ordinary user
  `test` → 200 with data — the pet plugin's own behavior, not dsh-login's.
- Client-side, plugin fetches fire at client activation (before any slot render);
  `@deepseek-ai/dsh-client-ui-slots` has no capability registration filter; and
  `@deepseek-ai/dsh-client-runtime` activates all bundles with no per-identity
  gate. So for an **unchanged** third-party plugin, dsh-login cannot make it fire
  zero requests.
- dsh-login's OWN client surface is already capability-pruned: the settings panel
  (`settings-panel.client.js`) does `fetchMe()` → renders UsersPanel (admin) or
  AccountPanel (账户) by `me.isAdmin`; ordinary users call only `/api/auth/me`,
  never the admin API. `/api/auth/capabilities` (live, session-authenticated)
  backs any capability-aware client; `window.__DSH_SESSION__` carries a
  conservative ordinary baseline at render.
- Decision (user, Path A): keep capability discovery + the two-segment 204 deny;
  do NOT change harness/webServer; accept that plugin-self-registered `/api/pet/*`
  exact routes are the plugin's own behavior. Committed + deployed + 212 tests.

## 2026-08-28 — two-segment grace: admin-only `/api/<domain>/<member>` probes go quiet (204)
- The capability feature fixed single-segment probes, but two-segment Typert
  endpoints that reach dsh-login's carrier (e.g. `/api/plugin-manager/…`) were
  still 403-ing: `connection.ts` forwarded every two-segment path straight to the
  harness interceptor, bypassing the 204 quiet-denial. Ordinary-user browsers
  kept printing forbidden walls. (Plugin-exact `/api/pet/pets` is a separate
  boundary — see the note above.)
- Fix: `connection.ts` now denies a non-admin request to an admin-only
  **two-segment domain** with the same read-quiet / write-loud shape
  (`isReadProbe(member) || GET/HEAD → 204`, else `403`, gated by `quietDenials`).
- New `capabilities.ts`: `ADMIN_ONLY_TWO_SEGMENT_DOMAINS` (config/secrets,
  pair/update/remote loopback, admin+decoration UI-plugin domains) +
  `isUserDeniedTwoSegment(domain)`. It is a **deny-list by design** to avoid the
  allow-list regression of user-facing two-segment domains (`ssh`, `skill`,
  `settings`, …) — SSH host management (`/api/ssh/*`) is a real ordinary-user
  feature and must keep dispatching. Denying only admin domains strictly
  converts 403→204 with zero user-feature regression.
- Tests: connection.spec.ts (two-segment GET 204 / POST 403 / off→403 / admin
  forwards / allowed-domain two-segment still dispatched 404), capabilities.spec.ts
  (deny-list admits pet/credentials/pair…, never ssh/skill/settings/session/api,
  no overlap with ordinary domain surface). Full suite 212 pass.

## 2026-08-28 — capability discovery + quiet denial of read probes (graceful auth)
- Returning to the plugin's design purpose: an ordinary-user browser session was
  splashing "forbidden" walls + potential retries because installed
  `@linxin666/dsh-client-ui-*` plugins (task-board, plugin-manager, agentPreset,
  doctor, …) probe `/api/*` at startup even when the user has no access. Redesign
  the permission experience from "passively reject with 403" to "the client knows
  the boundary and quiet side." Authorization is NOT loosened — only the shape of a
  denied read.
- new `src/capabilities.ts`: `deriveCapabilities(isAdmin)` (methods from
  USER_ALLOWED + USER_DOMAINS + uiPlugins; admin = full superset incl.
  credentials/settings/agentPresets and admin-only UI plugins),
  `isReadProbe(method)` (read-verb heuristic + `QUIET_DENY_METHODS` set),
  `userAllowedMethods()`.
- new route `GET /api/auth/capabilities` (admin-api.ts): returns per-identity
  `{ username, isAdmin, capabilities }`; session-authenticated (not admin-gated).
- index.ts: `webserver/index-inject` pushes a static non-admin baseline into
  `window.__DSH_SESSION__` (render-time cannot know the identity; clients needing
  the exact identity fetch the live endpoint).
- connection.ts physical layer: for a non-admin, non-allowed single-segment
  method, a **read probe** (read-verb name OR GET/HEAD on a forbidden path OR a
  QUIET_DENY_METHODS verb) answers **204 No Content** when `quietDenials` is on;
  side-effecting writes keep **403**. New config `quietDenials: boolean` (default
  true) wired through TakeoverDeps; off restores plain 403 everywhere.
- Tests: `capabilities.spec.ts` (derive + isReadProbe + parity with allow-list);
  connection.spec.ts (+5: read probe→204, GET probe→204, write→403, quietDenials
  off→403); admin-api.spec.ts (+3 capabilities endpoint: ordinary/admin/anonymous).
  Full suite 205 pass.

## 2026-08-28 — remote-web-ui compat: mount host routes + trust public host
- Root cause found for the public-FRP 405/403 wall: remote-web-ui registers its
  host routes (`/remote`, `/api/pair/*`) ONLY when `enabled===true`; the earlier
  compat write of `requirePairingForLan:false` alone could not help because
  nothing was mounted. Fix: `RemoteWebUiCompat.apply` now writes
  `{ enabled: true, requirePairingForLan: false }` (enabled:true mounts routes).
- The `/api/pair/*` fence (`routes.ts` `lanFence`) is **Host-header based** —
  a browser at a public FRP host sends `Host: <public>:<port>` which loopback/`lanAddresses`
  don't match, so `/api/pair/status` 403s and the client still fail-closes to `/remote`.
  Fix: new config `remoteWebUiPublicBaseUrl` (string) is threaded through `apply` and
  written as remote-web-ui's `publicBaseUrl` (which its `sync()` hot-applies via
  `service.setPublicBaseUrl`), so the fence trusts the public origin.
- `applyWithRetry` signature now `(compat, enabled, publicBaseUrl?, attempts?, delayMs?)`.
- Tests: `remote-web-ui-compat.spec.ts` 10 → 13 (publicBaseUrl written/omitted/off-only).

## 2026-08-22 — feature: remote-web-ui pairing gate bypass (requirePairingForLan toggle)
- Accommodates `@linxin666/dsh-remote-web-ui` unchanged (the popular community
  plugin whose `/remote` device-pairing gate 401s non-loopback desktop traffic
  from a public FRP host, independently of dsh-login's working /api auth).
- new `src/remote-web-ui-compat.ts`: `RemoteWebUiCompat.apply(enabled)` writes
  `requirePairingForLan: !enabled` into remote-web-ui's
  `settingsNamespace('remote-web-ui')` (live + hot-reloaded by that plugin);
  `ok | skipped (no settings svc) | unregistered (namespace missing)`; plus
  `applyWithRetry` for the boot race where remote-web-ui registers its namespace
  after dsh-login applies. No-op whenever remote-web-ui is not installed.
- new `src/boolean-setting.ts`: shared live+persisted `{enabled}` flag backing
  the runtime toggles; `DefaultWorkspaceSetting` now extends it (back-compat).
- config: `remoteWebUiCompat: boolean` (default **true**). index.ts wires a
  `BooleanSetting`, a deferred boot `applyWithRetry`, passes it into
  `createAdminRoutes`, flushes it on teardown.
- admin route `GET/POST /api/auth/admin/settings/remote-web-ui-compat` returns
  `{enabled}` (+ `applied: ok|skipped|unregistered`); 设置-用户管理 gains a
  switch card (zh/en).
- Build/tests: vitest + tsconfig alias `@deepseek-ai/dsh-settings` → harness
  `packages/settings/settings`; peerDependency added. 185 tests pass.

## 2026-08-21 — README restructure: showcase first, tech later
- Both READMEs rewritten front-to-back: one-liner → side-by-side
  screenshots (images/login.png, images/users.png — new, committed) →
  "problem it solves" in plain language (DSH GUI has no login; exposing
  0.0.0.0 hands everything to the network) → 6-bullet feature list →
  3-step quick start → FAQ (re-login after restart / what ordinary
  users can do / single-password migration). ALL prior technical
  content preserved verbatim under a `# 技术细节` / `# Technical
  details` divider at the bottom (install mechanics + manual install,
  setup flow, request-routing diagram, permission model, data
  locations, carrier takeover & bundle, security notes, fallback
  architecture, tests — count updated 109 → 134, settings-panel suite
  added to the list —, project structure).

## 2026-08-21 — Users table: single-line actions + last-login column
- 设置-用户管理 table: the actions cell (重置密码/禁用-启用/删除) is now a
  regular grid track at the row's end — `flex-wrap: nowrap`, no more
  `grid-column: 1 / -1` second line. `UserRecord.lastLoginAt?` (epoch ms)
  stamped by `touchLastLogin()` on every successful login/setup; the table
  dropped `createdAt` for a compact 最后登录 column (从未登录 placeholder,
  API returns `lastLoginAt: null` for never).
- Layout fix (same day): the first inline-actions attempt used three
  fixed-px tracks (56/150/112) + a nowrap max-content actions track — the
  minimum row width exceeded the panel and the grid overflowed/collapsed.
  Now only 状态+操作 are max-content; 用户名/最后登录 are `minmax(0, …)`
  flexible (ellipsis), the redundant 角色 column is gone (admin badge on
  the name covers it), and `@media (max-width: 620px)` drops the
  last-login column. Spec guards: no px-valued grid tracks, no col.role.
- Alignment fix (same day): header and rows were SEPARATE grids, so the
  max-content tracks (状态/操作) resolved per container — ~30px for the
  header labels vs ~250px for row buttons — and the header landed fully
  offset from the body. Now `.dshlu-table` owns one shared column grid
  and head/rows are `grid-template-columns: subgrid` spanning `1 / -1`
  (identical 14px side padding + 1px border on both, so tracks share the
  same origin). Narrow-viewport rule now retargets `.dshlu-table`.
  Spec guards: subgrid present, cells never carry grid-column spans.
- Tests: admin list (root stamped / bob null → stamped after login), login
  200 stamps / 401 does not, setup stamps; settings-panel spec guards the
  layout invariants in source.

## 2026-08-20 — Fix: UI plugins dead after login
- Root cause: the takeover bridged `/api` straight to `toFetchHandler` and
  never re-provided the `connection` service, so the Typert Remote gateway
  (dsh-api-gateway) never registered its shared `/api` interceptor — every
  installed UI plugin's host RPC (`POST /api/<namespace>/<method>`) failed
  after login, admin included; non-admins additionally lost all
  `host/remote-event` pushes.
- Fix: `connection.ts` instantiates `HostConnectionService` (re-provides
  `connection`) and routes two-segment endpoints through
  `createSharedFetchHandler`; `api-filter.ts` `frameVisible` forwards global
  remote-event signals to ordinary users (cordis/* stays admin-only).
- Tests: typert interceptor dispatch, cookie-gated typert, unclaimed-shape
  404, connection-service presence; frameVisible expectations updated.

## 2026-08-18 — Multi-user gateway (feat/multiuser-isolation)
- Multi-user auth: UserStore (scrypt, `${password}_USERS` credential ref),
  admin bootstrap on first visit, `/admin` page + `/api/auth/admin/*` routes,
  `/api/auth/me`; legacy single password no longer authenticates.
- Identity-aware `/api` carrier takeover: `connection.ts` child plugin
  (prefix route + WS upgrades), `api-filter.ts` per-user proxy with
  allow-list + ownership filtering, `ownership.ts` sessionId→username
  sidecar; `cordis.patch.yml` disables the shipped `web-runtime` and
  `connection` rows; browser half shipped as `dist/client.js`
  (`connection.client.ts`, `scripts/build-client.mjs`).
- Memory files rewritten to match (architecture/modules/api/gotchas).

## 2026-08-18 — Initial analysis
- Full codebase analyzed and memory files written
- 3 modules mapped, 0 endpoints documented, 0 models captured

### Session ended at 18:01

**Git diff:**
```
 .claude/rules/changelog.md |   71 ++++
 .claude/rules/gotchas.md   |   13 +-
 .gitignore                 |    1 +
 README.md                  |    4 +-
 README.zh.md               |    4 +-
 dist/index.js              |   24 +-
 dist/index.js.map          |    4 +-
 package-lock.json          | 1142 +++++++++++++--------------------------------------
 package.json               |   28 +-
 src/api-filter.ts          |   12 +
 src/capabilities.ts        |    4 +
 src/login-page.ts          |  511 +++++++++++++++++------
 tests/capabilities.spec.ts |   23 ++
 tests/remote-guard.spec.ts |   21 +
 14 files changed, 866 insertions(+), 996 deletions(-)
```

**Recent commits:**
```
5f7b64b docs: sync READMEs with released 0.2.0 state + lockfile deps cleanup
87920be chore: gitignore npm artifacts (env + recovery codes); record 0.2.0 publish
31feecd chore(release): 0.2.0 — retarget peerDependencies to DSH >= 0.1.5-alpha.1
a1db200 chore: ignore tooling config and scratch files
8f5e28f feat(option-a): re-adapt to DSH >= 0.1.5-alpha.1 + code-review hardening
```

### Session ended at 18:05

**Git diff:**
```
 .claude/rules/changelog.md |  101 +++++
 .claude/rules/gotchas.md   |   13 +-
 .gitignore                 |    1 +
 README.md                  |    4 +-
 README.zh.md               |    4 +-
 dist/index.js              |   24 +-
 dist/index.js.map          |    4 +-
 package-lock.json          | 1142 +++++++++++++--------------------------------------
 package.json               |   28 +-
 src/api-filter.ts          |   12 +
 src/capabilities.ts        |    4 +
 src/login-page.ts          |  496 ++++++++++++++++------
 tests/capabilities.spec.ts |   23 ++
 tests/remote-guard.spec.ts |   21 +
 14 files changed, 883 insertions(+), 994 deletions(-)
```

**Recent commits:**
```
5f7b64b docs: sync READMEs with released 0.2.0 state + lockfile deps cleanup
87920be chore: gitignore npm artifacts (env + recovery codes); record 0.2.0 publish
31feecd chore(release): 0.2.0 — retarget peerDependencies to DSH >= 0.1.5-alpha.1
a1db200 chore: ignore tooling config and scratch files
8f5e28f feat(option-a): re-adapt to DSH >= 0.1.5-alpha.1 + code-review hardening
```

### Session ended at 18:15

**Git diff:**
```
 .claude/rules/changelog.md |  131 ++++++
 .claude/rules/gotchas.md   |   13 +-
 .gitignore                 |    1 +
 README.md                  |    4 +-
 README.zh.md               |    4 +-
 dist/index.js              |   24 +-
 dist/index.js.map          |    4 +-
 package-lock.json          | 1142 +++++++++++++--------------------------------------
 package.json               |   28 +-
 src/api-filter.ts          |   12 +
 src/capabilities.ts        |    4 +
 src/login-page.ts          |  567 +++++++++++++++++++------
 tests/capabilities.spec.ts |   23 ++
 tests/remote-guard.spec.ts |   21 +
 14 files changed, 981 insertions(+), 997 deletions(-)
```

**Recent commits:**
```
5f7b64b docs: sync READMEs with released 0.2.0 state + lockfile deps cleanup
87920be chore: gitignore npm artifacts (env + recovery codes); record 0.2.0 publish
31feecd chore(release): 0.2.0 — retarget peerDependencies to DSH >= 0.1.5-alpha.1
a1db200 chore: ignore tooling config and scratch files
8f5e28f feat(option-a): re-adapt to DSH >= 0.1.5-alpha.1 + code-review hardening
```

### Session ended at 18:16

**Git diff:**
```
 .claude/rules/changelog.md |  161 ++++++++
 .claude/rules/gotchas.md   |   13 +-
 .gitignore                 |    1 +
 README.md                  |    4 +-
 README.zh.md               |    4 +-
 dist/index.js              |   24 +-
 dist/index.js.map          |    4 +-
 package-lock.json          | 1142 +++++++++++++--------------------------------------
 package.json               |   28 +-
 src/api-filter.ts          |   12 +
 src/capabilities.ts        |    4 +
 src/login-page.ts          |  653 +++++++++++++++++++++++------
 tests/capabilities.spec.ts |   23 ++
 tests/remote-guard.spec.ts |   21 +
 14 files changed, 1097 insertions(+), 997 deletions(-)
```

**Recent commits:**
```
5f7b64b docs: sync READMEs with released 0.2.0 state + lockfile deps cleanup
87920be chore: gitignore npm artifacts (env + recovery codes); record 0.2.0 publish
31feecd chore(release): 0.2.0 — retarget peerDependencies to DSH >= 0.1.5-alpha.1
a1db200 chore: ignore tooling config and scratch files
8f5e28f feat(option-a): re-adapt to DSH >= 0.1.5-alpha.1 + code-review hardening
```

### Session ended at 18:20

**Git diff:**
```
 .claude/rules/changelog.md |  191 +++++++++
 .claude/rules/gotchas.md   |   13 +-
 .gitignore                 |    1 +
 README.md                  |    4 +-
 README.zh.md               |    4 +-
 dist/index.js              |   24 +-
 dist/index.js.map          |    4 +-
 package-lock.json          | 1142 +++++++++++++--------------------------------------
 package.json               |   28 +-
 src/api-filter.ts          |   12 +
 src/capabilities.ts        |    4 +
 src/login-page.ts          |  661 +++++++++++++++++++++++------
 tests/capabilities.spec.ts |   23 ++
 tests/remote-guard.spec.ts |   21 +
 14 files changed, 1135 insertions(+), 997 deletions(-)
```

**Recent commits:**
```
5f7b64b docs: sync READMEs with released 0.2.0 state + lockfile deps cleanup
87920be chore: gitignore npm artifacts (env + recovery codes); record 0.2.0 publish
31feecd chore(release): 0.2.0 — retarget peerDependencies to DSH >= 0.1.5-alpha.1
a1db200 chore: ignore tooling config and scratch files
8f5e28f feat(option-a): re-adapt to DSH >= 0.1.5-alpha.1 + code-review hardening
```

### Session ended at 18:23

**Git diff:**
```
 .claude/rules/changelog.md | 2 ++
 1 file changed, 2 insertions(+)
```

**Recent commits:**
```
762d3f7 feat(login-page): 重设计登录界面 —— 分屏布局与插件特色文案
7d4e4ec feat: 适配 DSH 0.1.6-alpha.1（0.2.1，未发布）
5f7b64b docs: sync READMEs with released 0.2.0 state + lockfile deps cleanup
87920be chore: gitignore npm artifacts (env + recovery codes); record 0.2.0 publish
31feecd chore(release): 0.2.0 — retarget peerDependencies to DSH >= 0.1.5-alpha.1
```

### Session ended at 18:24

**Git diff:**
```
 .claude/rules/changelog.md | 19 +++++++++++++++++++
 1 file changed, 19 insertions(+)
```

**Recent commits:**
```
762d3f7 feat(login-page): 重设计登录界面 —— 分屏布局与插件特色文案
7d4e4ec feat: 适配 DSH 0.1.6-alpha.1（0.2.1，未发布）
5f7b64b docs: sync READMEs with released 0.2.0 state + lockfile deps cleanup
87920be chore: gitignore npm artifacts (env + recovery codes); record 0.2.0 publish
31feecd chore(release): 0.2.0 — retarget peerDependencies to DSH >= 0.1.5-alpha.1
```
