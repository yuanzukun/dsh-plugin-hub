#!/usr/bin/env node
import { createInterface } from 'node:readline/promises'
import { Writable } from 'node:stream'
import { saveToken, tokenFromRedirect } from './credential.js'

async function main() {
  if (!process.stdin.isTTY) throw new Error('Run this command in an interactive terminal.')
  const silent = new Writable({ write(_chunk, _encoding, done) { done() } })
  const prompt = createInterface({ input: process.stdin, output: silent, terminal: true, historySize: 0 })
  const abort = new AbortController()
  prompt.once('SIGINT', () => abort.abort())
  try {
    console.error('Complete authorization from https://github.com/baidu-netdisk/mcp#使用准备')
    console.error('Paste the official authorization result URL here (input hidden), then press Enter.')
    saveToken(tokenFromRedirect(await prompt.question('', { signal: abort.signal })))
    console.error('Credential saved. Restart the DeepSeek Harness profile.')
  } finally {
    prompt.close()
  }
}

main().catch(error => {
  console.error(error.name === 'AbortError' ? 'Authorization cancelled.' : error.message)
  process.exitCode = 1
})
