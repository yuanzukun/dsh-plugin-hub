import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js'

const origin = 'https://mcp-pan.baidu.com'
export const readTools = [
  'file_content_get', 'file_doc_list', 'file_image_list', 'file_keyword_search',
  'file_list', 'file_meta', 'file_semantics_search', 'file_sharelink_list',
  'file_sharelink_taskquery', 'file_sharelink_verify', 'file_video_list',
  'get_quota', 'user_info',
]
export const writeTools = [
  'file_content_create', 'file_copy', 'file_move', 'file_rename',
  'file_sharelink_set', 'file_sharelink_transfer', 'file_upload',
  'file_upload_by_content', 'file_upload_by_url', 'make_dir',
]

// Pin the SSE stream and session POST requests to the official HTTPS origin.
function officialFetch(input, init) {
  const url = new URL(input instanceof Request ? input.url : input)
  if (url.origin !== origin || url.username || url.password) {
    throw new Error('Unexpected Baidu MCP endpoint.')
  }
  return fetch(input, { ...init, redirect: 'error' })
}

export function openBaidu(token) {
  const endpoint = new URL('/sse', origin)
  endpoint.searchParams.set('access_token', token)
  const client = new Client({ name: 'dsh-baidu-netdisk', version: '0.1.0' })
  const transport = new SSEClientTransport(endpoint, {
    fetch: officialFetch,
    eventSourceInit: { fetch: officialFetch },
  })

  function sanitize(value) {
    return JSON.parse(JSON.stringify(value).replaceAll(token, '[redacted]'))
  }

  return {
    async connect() {
      let timer
      try {
        await Promise.race([
          client.connect(transport, { timeout: 15_000 }),
          new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error('Baidu connection timed out.')), 20_000)
          }),
        ])
      } finally {
        clearTimeout(timer)
      }
    },
    async listTools() {
      const tools = new Map()
      const cursors = new Set()
      let cursor
      do {
        const page = await client.listTools(cursor ? { cursor } : undefined, { timeout: 15_000 })
        for (const tool of page.tools) {
          if (tools.has(tool.name)) throw new Error('Baidu returned a duplicate tool name.')
          tools.set(tool.name, tool)
        }
        cursor = page.nextCursor
        if (cursor && (cursors.has(cursor) || cursors.size >= 9)) {
          throw new Error('Baidu returned an invalid tool pagination sequence.')
        }
        if (cursor) cursors.add(cursor)
      } while (cursor)
      if (!tools.has('get_quota')) throw new Error('Baidu account authorization is missing or expired.')
      return sanitize([...tools.values()])
    },
    async callTool(name, args, signal) {
      let result
      try {
        result = sanitize(await client.callTool({ name, arguments: args }, undefined, {
          signal,
          timeout: 55_000,
        }))
      } catch {
        throw new Error('Baidu Netdisk request failed. Check connectivity and authorization.')
      }
      const content = result.content ?? []
      if (result.isError) {
        const message = content.filter(block => block.type === 'text').map(block => block.text).join('\n')
        throw new Error(message || 'Baidu Netdisk rejected the request.')
      }
      return {
        content,
        ...(result.structuredContent === undefined ? {} : { structuredContent: result.structuredContent }),
      }
    },
    async close() {
      await client.close().catch(() => {})
      await transport.close().catch(() => {})
    },
  }
}
