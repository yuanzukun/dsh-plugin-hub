import Schema from '@deepseek-ai/schemastery'
import { openBaidu, readTools, writeTools } from './baidu.js'
import { readToken } from './credential.js'

export const name = 'dsh-baidu-netdisk'
export const inject = ['tools']
export const Config = Schema.object({
  enableWrites: Schema.boolean().default(false).description(
    'Expose file changes, uploads and sharing tools. Each write still requires approval.',
  ),
})

const prefix = 'mcp__baidu_netdisk__'
const output = {
  schema: {
    type: 'object',
    properties: {
      content: { type: 'array', items: {} },
      structuredContent: {},
    },
    required: ['content'],
    additionalProperties: false,
  },
  render(_args, result) {
    return result.content.map(block => block.type === 'text'
      ? block
      : { type: 'text', text: `[Baidu returned ${block.type} content]` })
  },
}

export async function apply(ctx, { enableWrites = false } = {}) {
  const token = readToken()
  if (!token) return

  const baidu = openBaidu(token)
  ctx.effect(() => () => baidu.close(), 'baidu-netdisk.connection')
  let tools
  try {
    await baidu.connect()
    tools = await baidu.listTools()
  } catch {
    await baidu.close()
    ctx.logger.warn('Baidu Netdisk is unavailable. Check connectivity and renew authorization if needed.')
    return
  }

  const allowed = new Set(readTools)
  if (enableWrites === true) for (const name of writeTools) allowed.add(name)
  const writes = new Set([...writeTools].map(name => prefix + name))
  if (enableWrites === true) {
    ctx.on('tools/pre-execute', async (execution, next) => {
      const decision = await next()
      if (decision.kind === 'allow' && writes.has(execution.name)) {
        return { kind: 'ask', reason: 'Review this Baidu Netdisk operation before it runs.' }
      }
      return decision
    })
  }

  const registered = []
  try {
    for (const tool of tools) {
      if (!allowed.has(tool.name)) continue
      const toolName = prefix + tool.name
      const instruction = tool.name === 'file_upload'
        ? '\nPrepare an upload draft only. Do not run the bdpan CLI without explicit user approval.'
        : ''
      registered.push(ctx.tools.register({
        name: toolName,
        description: (tool.description ?? '') + instruction,
        parameters: tool.inputSchema,
        output,
        timeoutMs: 60_000,
        execute: (args, execution) => baidu.callTool(tool.name, args, execution.signal),
      }))
    }
  } catch (error) {
    for (const dispose of registered.reverse()) await dispose()
    await baidu.close()
    throw error
  }
}
