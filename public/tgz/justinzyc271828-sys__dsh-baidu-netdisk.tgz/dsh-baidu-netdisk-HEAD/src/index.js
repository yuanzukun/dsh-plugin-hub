import Schema from '@deepseek-ai/schemastery'
import { openBaidu, readTools, writeTools } from './baidu.js'
import { readToken } from './credential.js'
import { openTransfer, transferReadTools, transferWriteTools } from './transfer.js'

export const name = 'dsh-baidu-netdisk'
export const inject = ['tools']
export const Config = Schema.object({
  enableWrites: Schema.boolean().default(false).description(
    'Expose official Baidu file changes and sharing. Each write requires approval.',
  ),
  credentialDirectory: Schema.string().description(
    'Optional absolute directory of an existing Baidu credential for official tools.',
  ),
  transferMcp: Schema.union([Schema.const(null), Schema.object({
    command: Schema.string().required().description('Absolute path to the transfer MCP executable.'),
    args: Schema.array(Schema.string()).default([]),
    cwd: Schema.string().description('Optional absolute working directory.'),
    enableTransfers: Schema.boolean().default(false).description(
      'Expose upload and download jobs. Each new transfer requires approval.',
    ),
  })]).default(null).description('Use an existing local Baidu Netdisk transfer MCP.'),
})

const officialPrefix = 'mcp__baidu_netdisk__'
const transferPrefix = 'mcp__baidu_netdisk_transfer__'
const output = {
  schema: {
    type: 'object',
    properties: {
      content: { type: 'array', items: {} },
      structuredContent: {},
    },
    required: ['content'],
    additionalProperties: false,
  },
  render(_args, result) {
    return result.content.map(block => block.type === 'text'
      ? block
      : { type: 'text', text: '[Baidu returned ' + block.type + ' content]' })
  },
}

async function registerTools(ctx, connection, { prefix, allowed, unavailable }) {
  ctx.effect(() => () => connection.close(), prefix + 'connection')
  let tools
  try {
    await connection.connect()
    tools = await connection.listTools()
  } catch {
    await connection.close()
    ctx.logger.warn(unavailable)
    return false
  }

  const registered = []
  try {
    for (const tool of tools) {
      if (!allowed.has(tool.name)) continue
      const instruction = tool.name === 'file_upload'
        ? '\nPrepare a bdpan command draft. Execute the CLI only after explicit user approval.'
        : ''
      registered.push(ctx.tools.register({
        name: prefix + tool.name,
        description: (tool.description ?? '') + instruction,
        parameters: tool.inputSchema,
        output,
        timeoutMs: 60_000,
        execute: (args, execution) => connection.callTool(tool.name, args, execution.signal),
      }))
    }
  } catch (error) {
    for (const dispose of registered.reverse()) await dispose()
    await connection.close()
    throw error
  }
  return true
}

export async function apply(ctx, { enableWrites = false, credentialDirectory, transferMcp } = {}) {
  const writes = new Set()
  if (enableWrites === true) {
    for (const tool of writeTools) writes.add(officialPrefix + tool)
  }
  if (transferMcp?.enableTransfers === true) {
    for (const tool of transferWriteTools) writes.add(transferPrefix + tool)
  }
  if (writes.size) {
    ctx.on('tools/pre-execute', async (execution, next) => {
      const decision = await next()
      if (decision.kind === 'allow' && writes.has(execution.name)) {
        return { kind: 'ask', reason: 'Review this Baidu Netdisk operation before it runs.' }
      }
      return decision
    })
  }

  let transferReady = false
  if (transferMcp) {
    let transfer
    try {
      transfer = openTransfer(transferMcp)
    } catch {
      ctx.logger.warn('Check the executable and working directory of the Baidu Netdisk transfer MCP.')
    }
    if (transfer) {
      transferReady = await registerTools(ctx, transfer, {
        prefix: transferPrefix,
        allowed: new Set(transferMcp.enableTransfers === true
          ? [...transferReadTools, ...transferWriteTools]
          : transferReadTools),
        unavailable: 'Baidu Netdisk transfer MCP is unavailable. Check the local server configuration.',
      })
    }
  }

  let token
  try {
    token = readToken(credentialDirectory)
  } catch {
    ctx.logger.warn('Baidu Netdisk could not read the credential for its official tools.')
    return
  }
  if (!token) return

  const allowed = new Set(enableWrites === true ? [...readTools, ...writeTools] : readTools)
  if (transferReady && transferMcp.enableTransfers === true) allowed.delete('file_upload')
  await registerTools(ctx, openBaidu(token), {
    prefix: officialPrefix,
    allowed,
    unavailable: 'Baidu Netdisk is unavailable. Check connectivity and renew authorization if needed.',
  })
}
