import { readFileSync, mkdirSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { randomUUID } from 'node:crypto'
import { spawnSync } from 'node:child_process'

const windows = process.platform === 'win32'
const directory = process.env.DSH_BAIDU_NETDISK_CREDENTIAL_DIR
  ? resolve(process.env.DSH_BAIDU_NETDISK_CREDENTIAL_DIR)
  : join(homedir(), '.dsh-baidu-netdisk')
const credentialFile = join(directory, windows ? 'access-token.dpapi' : 'access.token')

function validateToken(value) {
  if (!/^[!-~]{20,4096}$/.test(value)) throw new Error('Invalid Baidu access token.')
  return value
}

function dpapi(input, decrypt = false) {
  const command = [
    "$ErrorActionPreference = 'Stop'",
    'Add-Type -AssemblyName System.Security',
    '$bytes = [Convert]::FromBase64String([Console]::In.ReadToEnd())',
    '$scope = [Security.Cryptography.DataProtectionScope]::CurrentUser',
    `$result = [Security.Cryptography.ProtectedData]::${decrypt ? 'Unprotect' : 'Protect'}($bytes, $null, $scope)`,
    '[Console]::Out.Write([Convert]::ToBase64String($result))',
  ].join('; ')
  const executable = join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
  const output = spawnSync(executable, ['-NoProfile', '-NonInteractive', '-Command', command], {
    input: input.toString('base64'), encoding: 'utf8', windowsHide: true, timeout: 15_000,
  })
  if (output.status !== 0 || !output.stdout?.trim()) {
    throw new Error('Windows could not access the Baidu credential store.')
  }
  return Buffer.from(output.stdout.trim(), 'base64')
}

export function readToken() {
  let bytes
  try {
    if (!windows && (statSync(credentialFile).mode & 0o077)) {
      throw new Error('Set permissions on the Baidu credential file to 0600.')
    }
    bytes = readFileSync(credentialFile)
  } catch (error) {
    if (error.code === 'ENOENT') return null
    throw error
  }
  return validateToken((windows ? dpapi(bytes, true) : bytes).toString('utf8'))
}

export function saveToken(value) {
  const bytes = Buffer.from(validateToken(value))
  const stored = windows ? dpapi(bytes) : bytes
  mkdirSync(directory, { recursive: true, mode: 0o700 })
  const temporary = join(directory, randomUUID())
  try {
    writeFileSync(temporary, stored, { mode: 0o600, flag: 'wx' })
    renameSync(temporary, credentialFile)
  } finally {
    rmSync(temporary, { force: true })
  }
}

export function tokenFromRedirect(input) {
  let url
  try { url = new URL(input.trim()) } catch { throw new Error('Expected the Baidu authorization result URL.') }
  if (url.origin !== 'https://openapi.baidu.com' || url.pathname !== '/oauth/2.0/login_success') {
    throw new Error('Expected the Baidu authorization result URL.')
  }
  const token = new URLSearchParams(url.hash.slice(1)).get('access_token')
  if (!token) throw new Error('The authorization result has no access token.')
  return validateToken(token)
}
