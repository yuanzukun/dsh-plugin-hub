import { isAbsolute } from 'node:path'
import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js'

export const transferReadTools = ['account_status', 'list_directory', 'transfer_status']
export const transferWriteTools = ['start_upload', 'start_download']

export function openTransfer({ command, args = [], cwd }) {
  if (!command || !isAbsolute(command) || (cwd && !isAbsolute(cwd))) {
    throw new Error('Use absolute paths for the transfer MCP executable and working directory.')
  }

  const client = new Client({ name: 'dsh-baidu-netdisk', version: '0.2.0' })
  const transport = new StdioClientTransport({ command, args, cwd, stderr: 'ignore' })

  return {
    connect: () => client.connect(transport, { timeout: 10_000 }),
    async listTools() {
      const { tools } = await client.listTools(undefined, { timeout: 10_000 })
      const names = new Set(tools.map(tool => tool.name))
      if (names.size !== tools.length || ![...transferReadTools, ...transferWriteTools].every(name => names.has(name))) {
        throw new Error('The transfer MCP does not provide the required file transfer tools.')
      }
      return tools
    },
    async callTool(name, args, signal) {
      let result
      try {
        result = await client.callTool({ name, arguments: args }, undefined, { signal, timeout: 55_000 })
      } catch {
        throw new Error('Transfer MCP request failed. Check the same request ID before submitting again.')
      }
      const content = result.content ?? []
      if (result.isError) {
        const message = content.filter(block => block.type === 'text').map(block => block.text).join('\n')
        throw new Error(message || 'The transfer MCP rejected the request.')
      }
      return {
        content,
        ...(result.structuredContent === undefined ? {} : { structuredContent: result.structuredContent }),
      }
    },
    async close() {
      await client.close().catch(() => {})
      await transport.close().catch(() => {})
    },
  }
}
