# DeepSeek Harness 百度网盘插件

[English](README.md)

把[百度网盘官方 MCP](https://github.com/baidu-netdisk/mcp) 接入 DeepSeek Harness。每位用户自行授权百度账号。安装后可用自然语言查询网盘容量、列目录、按文件名或语义搜索，并读取文件信息和内容。

## 安装与授权

1. 安装到正在使用的 DSH 配置。下例用 `desktop`，使用其他配置时请替换名称。

   ```sh
   dsh plugin --profile desktop add github:justinzyc271828-sys/dsh-baidu-netdisk
   ```

2. 按[百度官方授权说明](https://github.com/baidu-netdisk/mcp#使用准备)登录并授权。官方个人账号入口属于限时体验，百度可能调整可用性或凭据。
3. 运行下方命令。在隐藏输入提示里粘贴百度授权成功页的完整地址，按回车。重新授权会替换本地凭据。重启 DSH 配置后，可以问「查一下我的百度网盘容量」。

   Windows PowerShell：

   ```powershell
   $dshRoot = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $env:USERPROFILE '.dsh' }
   node (Join-Path $dshRoot 'profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js')
   ```

   macOS/Linux：

   ```sh
   node "${DSH_HOME:-$HOME/.dsh}/profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js"
   ```

授权命令需要 Node.js 22 或以上。令牌保存在 `~/.dsh-baidu-netdisk/`。Windows 用当前用户的 DPAPI 加密，macOS 和 Linux 用文件权限限制访问。若要使用其他私有目录，可为授权助手与 DSH 进程设置同一个 `DSH_BAIDU_NETDISK_CREDENTIAL_DIR`。请勿把令牌或授权成功页地址发到聊天里，也不要写入配置文件。可在[百度账号授权管理](https://passport.baidu.com/v6/appAuthority)撤销授权。

## 工具与写入

截至 2026-11-02，实测默认加载 13 个查询工具，开启写入后发现全部 23 个工具。默认模式支持按类型列文件、查询元数据和内容、关键词及语义搜索、查询账号与容量，以及查看分享内容、校验提取码和查询分享任务状态。

需要创建目录、复制、移动、重命名、分享、转存或上传时，在 DSH 中开启插件的 `enableWrites`，或为配置加入下列补丁并重启。DSH 会为每次写入请求确认。没有审批通道的配置会拒绝写入。

```yaml
- id: baidu-netdisk
  config:
    enableWrites: true
```

官方 `file_upload` 只生成 `bdpan` CLI 上传草稿。实际上传本地文件需要单独按百度官方说明安装并登录 `bdpan`。本插件直接转发百度提供的文本、URL 上传工具，具体可用性受账号授权和服务限制。
