# DeepSeek Harness 百度网盘插件

[English](README.md)

把[百度网盘官方 MCP](https://github.com/baidu-netdisk/mcp) 接入 DeepSeek Harness。每位用户自行授权百度账号。安装后可用自然语言查询网盘容量、列目录、按文件名或语义搜索，并读取文件信息和内容。

[从 GitHub Releases 下载安装包](https://github.com/justinzyc271828-sys/dsh-baidu-netdisk/releases)。在 DSH Market 搜 `dsh-baidu-netdisk`，安装作者为 `justinzyc271828-sys` 的条目。 [市场条目](https://awesome-dsh-plugin.com/p/justinzyc271828-sys/dsh-baidu-netdisk/)

## 安装与授权

1. 在 DSH Market 安装，或在官方桌面端「发现」添加[社区索引](https://realguan.github.io/dsh-plugin-market/dsh-index.json)后安装。使用下载的安装包时，完全退出 Desktop，在下载目录用桌面端附带的 `dsh` 命令行运行下方命令。使用其他配置时请替换 `desktop`。

   ```sh
   dsh plugin --profile desktop add ./dsh-baidu-netdisk-0.2.0.tgz
   ```

2. 按[百度官方授权说明](https://github.com/baidu-netdisk/mcp#使用准备)登录并授权。官方个人账号入口属于限时体验，百度可能调整可用性或凭据。
3. 运行下方命令。在隐藏输入提示里粘贴百度授权成功页的完整地址，按回车。重新授权会替换本地凭据。重启 DSH 配置后，可以问「查一下我的百度网盘容量」。

   Windows PowerShell：

   ```powershell
   $dshRoot = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $env:USERPROFILE '.dsh' }
   node (Join-Path $dshRoot 'profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js')
   ```

   macOS/Linux：

   ```sh
   node "${DSH_HOME:-$HOME/.dsh}/profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js"
   ```

授权命令需要 Node.js 22 或以上。令牌保存在 `~/.dsh-baidu-netdisk/`。Windows 用当前用户的 DPAPI 加密，macOS 和 Linux 用文件权限限制访问。若要使用其他私有目录，可为授权助手与 DSH 进程设置同一个 `DSH_BAIDU_NETDISK_CREDENTIAL_DIR`。请勿把令牌或授权成功页地址发到聊天里，也不要写入配置文件。可在[百度账号授权管理](https://passport.baidu.com/v6/appAuthority)撤销授权。

## 工具与写入

**首次只读验证。** 重启刚才安装插件的配置，然后问「查一下我的百度网盘容量」。成功时应能看到总容量与已用容量。若工具列表中没有 `mcp__baidu_netdisk__`，先确认插件已在该配置中启用，且授权助手和 DSH 使用同一系统账户及凭据目录。若工具已出现但服务拒绝授权，重新运行本地授权助手后再重启配置。

截至 2026-11-02，实测默认加载 13 个查询工具，开启写入后发现全部 23 个工具。默认模式支持按类型列文件、查询元数据和内容、关键词及语义搜索、查询账号与容量，以及查看分享内容、校验提取码和查询分享任务状态。

在 DSH 中开启 `enableWrites`，可使用百度官方接口创建目录、复制、移动、重命名、分享、转存以及按文本或 URL 上传。也可为配置加入下列补丁并重启。每次写入都经过 DSH 的审批通道。

```yaml
- id: baidu-netdisk
  config:
    enableWrites: true
```

官方 `file_upload` 用来生成 `bdpan` 命令草稿。需要从 DSH 实际传输本地文件时，可接入下方的传输 MCP。

## 上传和下载本地文件

从 0.2.0 开始，插件可以通过 stdio 调用已安装的百度网盘传输 MCP。与其他本地工具共用同一服务时，DSH 也能查询同一个传输任务。把服务的实际路径填入 DSH 配置，下方路径仅供示例。

```yaml
- id: baidu-netdisk
  config:
    transferMcp:
      command: D:/Tools/Python/python.exe
      args:
        - D:/Tools/netdisk-transfer/server.py
      cwd: D:/Tools/netdisk-transfer
      enableTransfers: true
```

工具名以 `mcp__baidu_netdisk_transfer__` 开头。`account_status` 和 `list_directory` 用于核对账号与目录。开启 `enableTransfers` 后，`start_upload` 和 `start_download` 进入 DSH 的审批流程，`transfer_status` 用于查询进度和校验结果。官方接口的写入工具仍由 `enableWrites` 控制。

上传时填写已确认的本地绝对路径、完整网盘目标路径、SHA‑256 和请求 UUID。轮询原 UUID，等回读哈希和文件 ID 返回。下载时使用精确的网盘路径与字符串形式的文件 ID。可以填写一个新的本地文件路径，或省略路径来只做回读校验。

传输由已安装的 MCP 服务执行，账号和可访问目录由该服务管理。插件包提供 DSH 客户端。已有兼容授权文件时，可用 `credentialDirectory` 指向该文件所在的绝对目录，供官方工具使用。凭据仍由系统当前用户保护。
