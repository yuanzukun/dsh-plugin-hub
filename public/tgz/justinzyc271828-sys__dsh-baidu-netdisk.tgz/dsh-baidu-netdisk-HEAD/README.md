# Baidu Netdisk for DeepSeek Harness

[简体中文](README.zh-CN.md)

Connect DeepSeek Harness to [Baidu Netdisk's official MCP service](https://github.com/baidu-netdisk/mcp). This community plugin registers the service's SSE tools in DSH. Each user authorizes their own Baidu account.

## Install and authorize

1. Install in the DSH profile you use. Replace `desktop` with your profile name if needed.

   ```sh
   dsh plugin --profile desktop add github:justinzyc271828-sys/dsh-baidu-netdisk
   ```

2. Open the [official authorization guide](https://github.com/baidu-netdisk/mcp#使用准备) and follow the account authorization steps. The individual-account application is a limited trial. Baidu may change its availability or credentials.
3. Run the local prompt below. Copy the complete address of the official Baidu success page into the hidden prompt, then press Enter. A new authorization replaces the previous one. Restart the DSH profile and ask it to check your Baidu Netdisk capacity.

   Windows PowerShell:

   ```powershell
   $dshRoot = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $env:USERPROFILE '.dsh' }
   node (Join-Path $dshRoot 'profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js')
   ```

   macOS/Linux:

   ```sh
   node "${DSH_HOME:-$HOME/.dsh}/profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js"
   ```

The helper requires Node.js 22 or later. It saves the token under `~/.dsh-baidu-netdisk/`. Windows encrypts it with user-scoped DPAPI. On macOS and Linux, the helper creates the directory and token file with user-only permissions. You can set `DSH_BAIDU_NETDISK_CREDENTIAL_DIR` in both processes to choose a different private directory. Never paste the token or success URL into an agent chat or a profile file. Revoke access via [Baidu's account authorization page](https://passport.baidu.com/v6/appAuthority).

## Available tools

The plugin filters the tools advertised by the official service. As of 2026-11-02, it discovered 13 tools by default and 23 with writes enabled. Tools use the `mcp__baidu_netdisk__` prefix.

| Mode | Capabilities |
| --- | --- |
| Default | List files by type, get metadata and content, search by keyword or meaning, read account and quota, inspect share contents, verify share codes, and check share task status |
| With writes enabled | Create folders and documents, copy, move, rename, create shares, transfer shared files, and request upload by URL or text |

The optional `file_upload` tool produces a draft for Baidu's separate `bdpan` CLI. The plugin does not install or run that CLI. Use Baidu's own instructions for local-file uploads. The tools exposed to an account depend on Baidu's authorization and service responses.

To enable write tools, set `enableWrites` for this plugin in DSH, or apply this profile patch and restart:

```yaml
- id: baidu-netdisk
  config:
    enableWrites: true
```

DSH prompts for approval on each write call. Profiles without an approval channel deny the call.
