# Baidu Netdisk for DeepSeek Harness

[简体中文](README.zh-CN.md)

Connect DeepSeek Harness to [Baidu Netdisk's official MCP service](https://github.com/baidu-netdisk/mcp). This community plugin registers the service's SSE tools in DSH. Each user authorizes their own Baidu account.

[Download an installation package from GitHub Releases](https://github.com/justinzyc271828-sys/dsh-baidu-netdisk/releases). In DSH Market, search `dsh-baidu-netdisk` and install the entry by `justinzyc271828-sys`. [Market listing](https://awesome-dsh-plugin.com/p/justinzyc271828-sys/dsh-baidu-netdisk/)

## Install and authorize

1. Install from DSH Market or the official Desktop **Discover** tab using the [community index](https://realguan.github.io/dsh-plugin-market/dsh-index.json). For a downloaded tarball, fully quit Desktop and run this command in the download directory with the Desktop-installed `dsh` CLI. Replace `desktop` if you use another profile.

   ```sh
   dsh plugin --profile desktop add ./dsh-baidu-netdisk-0.2.0.tgz
   ```

2. Open the [official authorization guide](https://github.com/baidu-netdisk/mcp#使用准备) and follow the account authorization steps. The individual-account application is a limited trial. Baidu may change its availability or credentials.
3. Run the local prompt below. Copy the complete address of the official Baidu success page into the hidden prompt, then press Enter. A new authorization replaces the previous one. Restart the DSH profile and ask it to check your Baidu Netdisk capacity.

   Windows PowerShell:

   ```powershell
   $dshRoot = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $env:USERPROFILE '.dsh' }
   node (Join-Path $dshRoot 'profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js')
   ```

   macOS/Linux:

   ```sh
   node "${DSH_HOME:-$HOME/.dsh}/profiles/desktop/node_modules/dsh-baidu-netdisk/src/auth.js"
   ```

The helper requires Node.js 22 or later. It saves the token under `~/.dsh-baidu-netdisk/`. Windows encrypts it with user-scoped DPAPI. On macOS and Linux, the helper creates the directory and token file with user-only permissions. You can set `DSH_BAIDU_NETDISK_CREDENTIAL_DIR` in both processes to choose a different private directory. Never paste the token or success URL into an agent chat or a profile file. Revoke access via [Baidu's account authorization page](https://passport.baidu.com/v6/appAuthority).

## First read-only check

After restarting the same profile, ask **“How much space is available on my Baidu Netdisk?”** A successful reply reports the quota and space used. If there are no `mcp__baidu_netdisk__` tools, confirm that the plugin is enabled in that profile, and that the helper and DSH use the same account and credential directory. If the tools appear but the service rejects authorization, run the local authorization helper again and restart the profile.

## Available tools

The plugin filters the tools advertised by the official service. As of 2026-11-02, it discovered 13 tools by default and 23 with writes enabled. Tools use the `mcp__baidu_netdisk__` prefix.

| Mode | Capabilities |
| --- | --- |
| Default | List files by type, get metadata and content, search by keyword or meaning, read account and quota, inspect share contents, verify share codes, and check share task status |
| With writes enabled | Create folders and documents, copy, move, rename, create shares, transfer shared files, and request upload by URL or text |

The official `file_upload` tool prepares a `bdpan` CLI draft. Connect a transfer MCP to send local file bytes from DSH. Account authorization controls which official tools are available.

To enable write tools, set `enableWrites` for this plugin in DSH, or apply this profile patch and restart:

```yaml
- id: baidu-netdisk
  config:
    enableWrites: true
```

DSH prompts for approval on each write call. Profiles without an approval channel deny the call.

## Local file transfers

Version 0.2.0 can connect to an existing Baidu Netdisk transfer MCP over stdio.
Use the same server as your other local tools to share the transfer job history.
Configure the command, arguments and working directory for the installed server
in the DSH profile patch. This example uses placeholder paths.

```yaml
- id: baidu-netdisk
  config:
    transferMcp:
      command: D:/Tools/Python/python.exe
      args:
        - D:/Tools/netdisk-transfer/server.py
      cwd: D:/Tools/netdisk-transfer
      enableTransfers: true
```

The transfer MCP supplies `account_status`, `list_directory`, `start_upload`,
`start_download` and `transfer_status`. The plugin exposes them under
`mcp__baidu_netdisk_transfer__`. Set `enableTransfers` to expose the two start
tools, which DSH sends through its approval prompt. The official API write
tools have their own `enableWrites` switch.

Check the account and destination before upload. Supply the approved absolute
local path, exact remote file path, SHA-256 and a request UUID to `start_upload`.
Use `transfer_status` with that UUID until the job returns the file ID and
verified readback SHA-256. Keep the same UUID if the response is interrupted.
For downloads, use the exact remote path and file ID as a string. Supply a
new local destination or omit it for checksum-only readback.

An installed transfer server provides the byte transfer, credentials and path
scopes. The plugin package contains the DSH client. For the official tools,
`credentialDirectory` can point to an existing absolute directory with a
compatible credential file. The user's Windows DPAPI identity or POSIX file
permissions still apply. Keep the credential itself in its protected store.
