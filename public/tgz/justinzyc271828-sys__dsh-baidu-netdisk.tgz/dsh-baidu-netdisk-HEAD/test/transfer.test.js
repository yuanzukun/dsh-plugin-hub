import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import test from 'node:test'
import { apply, Config } from '../src/index.js'

const prefix = 'mcp__baidu_netdisk_transfer__'
const server = String.raw`
import readline from 'node:readline'

const names = ['account_status', 'list_directory', 'transfer_status', 'start_upload', 'start_download', 'delete_file']
const lines = readline.createInterface({ input: process.stdin })
for await (const line of lines) {
  const message = JSON.parse(line)
  if (message.id === undefined) continue
  let result
  if (message.method === 'initialize') {
    result = {
      protocolVersion: message.params.protocolVersion,
      capabilities: { tools: {} },
      serverInfo: { name: 'baidu-netdisk-transfer-test', version: '1' },
    }
  } else if (message.method === 'tools/list') {
    result = { tools: names.map(name => ({ name, inputSchema: { type: 'object' } })) }
  } else if (message.method === 'tools/call') {
    const { name, arguments: args } = message.params
    result = { content: [{ type: 'text', text: JSON.stringify({ name, args }) }] }
  }
  console.log(JSON.stringify({ jsonrpc: '2.0', id: message.id, result }))
}
`

function context(t) {
  const tools = new Map()
  const hooks = new Map()
  const ctx = {
    effect(factory) { t.after(factory()) },
    logger: { warn(message) { assert.fail(message) } },
    on(event, handler) { hooks.set(event, handler) },
    tools: {
      register(tool) {
        tools.set(tool.name, tool)
        return () => tools.delete(tool.name)
      },
    },
  }
  return { ctx, tools, hooks }
}

const credentialDirectory = fileURLToPath(new URL('./', import.meta.url))
const connection = {
  command: process.execPath,
  args: ['--input-type=module', '--eval', server],
}

test('existing configuration and transfer metadata mode expose no start tools', async t => {
  assert.equal(Config({}).transferMcp, undefined)
  const { ctx, tools, hooks } = context(t)
  await apply(ctx, Config({ credentialDirectory, transferMcp: connection }))
  assert.deepEqual([...tools.keys()].sort(), [
    prefix + 'account_status',
    prefix + 'list_directory',
    prefix + 'transfer_status',
  ])
  assert.equal(hooks.size, 0)
})

test('transfer starts require DSH approval and forward the exact request', async t => {
  const { ctx, tools, hooks } = context(t)
  await apply(ctx, Config({ credentialDirectory, transferMcp: { ...connection, enableTransfers: true } }))
  const review = hooks.get('tools/pre-execute')
  const allow = async () => ({ kind: 'allow' })
  assert.equal((await review({ name: prefix + 'start_upload' }, allow)).kind, 'ask')
  assert.equal((await review({ name: prefix + 'start_download' }, allow)).kind, 'ask')
  assert.equal((await review({ name: prefix + 'transfer_status' }, allow)).kind, 'allow')
  const denial = { kind: 'deny', reason: 'Profile policy' }
  assert.deepEqual(await review({ name: prefix + 'start_upload' }, async () => denial), denial)
  assert.equal(tools.has(prefix + 'delete_file'), false)

  const args = {
    request_id: '7347f460-8af7-4969-906d-ddac4e13af96',
    local_path: 'D:/Test Archive/clip.mp4',
    remote_path: '/Archive/clip.mp4',
    sha256: '1'.repeat(64),
  }
  const result = await tools.get(prefix + 'start_upload').execute(args, { signal: AbortSignal.timeout(5000) })
  assert.deepEqual(JSON.parse(result.content[0].text), { name: 'start_upload', args })
})
