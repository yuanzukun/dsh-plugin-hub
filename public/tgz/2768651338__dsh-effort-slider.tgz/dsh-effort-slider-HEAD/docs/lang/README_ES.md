<!-- Versión en español. English: [README](../../README.md) -->
<div align="center">

[**English**](../../README.md) · [中文](README_ZH.md) · **Español** · [日本語](README_JA.md) · [Deutsch](README_DE.md) · [Русский](README_RU.md) · [Português](README_PT.md) · [한국어](README_KO.md)

</div>

> ※ Este documento es una traducción del [original en inglés](../../README.md); en caso de discrepancia prevalece la versión inglesa. Las correcciones vía Issue / PR son bienvenidas.

<div align="center">

# dsh-effort-slider

> **Un deslizador de nivel de razonamiento estilo Claude Code para DeepSeek Harness** — haz clic en **Effort** en el menú de modelos, arrastra sin escalones, suelta y se ajusta, con una estela de fuego WebGL; cualquier modelo/proveedor de terceros obtiene un control real y funcional del esfuerzo de razonamiento.

[![License: BSD-3-Clause](https://img.shields.io/badge/License-BSD--3--Clause-yellow.svg)](../../LICENSE)
[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-Plugin-4C9AFF.svg)](https://github.com/deepseek-ai/deepseek-harness)
[![version](https://img.shields.io/badge/version-v0.5.0-success.svg)](https://github.com/2768651338/dsh-effort-slider/releases)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6.svg)](https://www.typescriptlang.org)
[![React](https://img.shields.io/badge/React-18-61DAFB.svg)](https://react.dev)
[![topic: dsh-plugin](https://img.shields.io/badge/topic-dsh--plugin-7B68EE.svg)](https://github.com/topics/dsh-plugin)

<br>

Haz clic en la fila **Effort** (segunda fila del menú de modelos oficial) en lugar de la lista de niveles integrada: se despliega un **panel deslizante de Effort** — marcas OFF/MAX, estado Low/Medium/High/Ultracode en vivo y, tras cerrar el panel, el valor de esfuerzo permanece coloreado en la fila del menú y en el botón disparador del asiento de modelos.

[Características](#características) · [Compatibilidad](#compatibilidad) · [Instalación / Desinstalación](#instalación--desinstalación) · [Inicio rápido](#inicio-rápido) · [Configuración](#configuración) · [Permisos y datos](#permisos-y-datos) · [Cómo funciona](#cómo-funciona) · [Solución de problemas](#solución-de-problemas) · [Desarrollo](#desarrollo)

**Capturas de demostración** (coloreado de la fila del menú / disparador del asiento de modelos / panel de Effort — nivel coloreado):

| Fila del menú | Disparador del asiento | Panel de Effort |
| --- | --- | --- |
| <img src="../../assets/screenshots/屏幕截图 2026-08-16 190943.png" alt="Fila Effort del menú de modelos coloreada" width="240"> | <img src="../../assets/screenshots/屏幕截图 2026-08-16 190950.png" alt="Disparador del asiento de modelos coloreado" width="240"> | <img src="../../assets/screenshots/屏幕截图 2026-08-16 190903.png" alt="Panel deslizante de Effort" width="240"> |

</div>

---

> 🆕 **v0.5.0** — Lote de correcciones de la evaluación. Fiabilidad: el panel separa cargando / error de carga / no compatible en tres estados con botón de reintento; las escrituras fallidas del deslizador muestran un estado rojo transitorio en lugar de fallar en silencio; las ediciones concurrentes del usuario se detectan (la entrada se relee antes de `mutate`, las rondas en conflicto ceden el paso); todas las rutas de fallo del aprovisionamiento del host registran ahora una advertencia, y una fila Effort nunca reconocida genera un diagnóstico único. UX del panel: se reancla con scroll/resize, se cierra con Esc / clic fuera / desmontaje del ancla, y pulsar de nuevo la fila Effort la alterna; los puntos y etiquetas de la escala se alinean con los puntos reales de ajuste; el deslizador lleva `aria-label` / `aria-valuetext`; los textos de la UI son bilingües (zh/en, según `<html lang>`). Nueva opción `debugReport`: detalle de aprovisionamiento por ruta/modelo más un trazador opcional de solo lectura `llm/stream` que registra ruta/modelo/effort por petición; una ayuda `?` en la cabecera del panel apunta a `enabled` / dialecto / `debugReport`. Además: CI con GitHub Actions (typecheck + tests + build + puerta de frescura de artefactos), el fuego WebGL ya no arde a 60 fps cuando es invisible, y el paquete npm pasa a llamarse `@txc2768651338/dsh-effort-slider` (el antiguo nombre sin scope `dsh-effort-slider` se retira).
>
> 🆕 **v0.4.0** — Portado a DSH **0.2.0**: DSH sustituyó su servicio de settings por `SettingsForms` (los ajustes son ahora configuraciones de profile entry; `installSection` / `settings.get` / `settings/updated` desaparecieron). La parte host ahora localiza la profile entry de pi-ai (`llm-pi-ai`), la lee vía `settings.describe()`, escribe vía `settings.mutate()` y escucha `settings/document-updated`. La parte cliente deriva la sesión actual de `retainedBy.mainView` (`SessionListState.current` fue eliminado). Las opciones del plugin (`enabled` / `defaultDialect` / `routes`) viven en la configuración de la entry del plugin, editables en la página de ajustes de DSH. DSH ≤ 0.1.5 ya no es compatible (usa ahí la v0.3.0).
>
> 🆕 **v0.3.0** — Portado a DSH 0.1.5: el `Context` del cliente viene ahora de `@deepseek-ai/cordis`, el estado por sesión se lee/escribe vía `ctx.modelDirectories` y la sección de ajustes se instala vía `settings.installSection()`; el envoltorio de metadatos de adaptadores fue eliminado (ver «Ajuste universal de esfuerzo»). DSH ≤ 0.1.1 ya no es compatible.
>
> 🔧 **v0.2.5** — Corregido el fallo silencioso del aprovisionamiento universal con arrays `models` explícitos (las operaciones path de dsh-settings no pueden atravesar nodos de array — ahora el array se reemplaza como un todo).
>
> 🔧 **v0.2.4** — Corregido el aprovisionamiento universal que nunca aterrizaba cuando la sección de ajustes pi-ai se registra tarde (ahora reintenta hasta que la sección está lista).
>
> 🆕 **v0.2.3** — El botón disparador del asiento de modelos también colorea el nombre del esfuerzo según el nivel, persistente tras cerrar el menú.
>
> 🔧 **v0.2.2** — Corregido el coloreado de la fila del menú que se rompía al remontarse todo el árbol del menú (repintado completo con estrangulación; color inferido del texto del esfuerzo).
>
> 🆕 **v0.2.1** — Tras cerrar el panel, el valor de esfuerzo en la fila Effort del menú de modelos conserva el color del nivel.
>
> ✨ **v0.2.0** — Cualquier modelo/proveedor personalizado de terceros obtiene un control de esfuerzo de razonamiento que funciona de verdad (aplicado en caliente).
>
> 🎛️ **v0.1.0** — Lanzamiento inicial: intercepta el menú Effort oficial y muestra un panel deslizante de Effort estilo Claude Code.
>
> Notas completas de cada versión: [Releases](https://github.com/2768651338/dsh-effort-slider/releases)

---

## Características

| Característica | Descripción |
| --- | --- |
| 🎚️ Arrastre continuo | Arrastre 0–100 continuo que escribe `reasoningEffort` en tiempo real (estrangulación de 16 ms, sin acumulación de peticiones mientras arrastras) |
| 🎯 Ajuste al soltar | Al soltar / perder el foco / terminar con el teclado, se ajusta al nivel más cercano y envía una escritura de confirmación |
| 🔥 Estela de fuego WebGL | Shaders de tres pasadas (ignición → desenfoque → composición); el frente del fuego sigue el pulgar con amortiguación de resorte |
| 🏁 Marcas OFF/MAX | El primer y el último nivel muestran siempre `OFF` / `MAX`; los niveles intermedios muestran el nombre devuelto por la API |
| 🎨 Estado del nivel | El nombre del esfuerzo se muestra en la cabecera del panel, coloreado/brillante según el nivel; la fila del menú y el disparador del asiento de modelos conservan el mismo color al cerrar (v0.2.3) |
| 🌐 Esfuerzo universal | Los modelos de terceros sin metadatos `reasoning` obtienen automáticamente la escala universal de 5 niveles; los modelos pi-ai reciben los diccionarios a nivel de cable parcheados, **aplicado en caliente** (v0.2.0) |

Solo se escribe `reasoningEffort` — la selección de modelo no se toca. Los modelos sin razonamiento multinivel muestran 「当前模型不提供多档推理等级」 (el modelo actual no ofrece varios niveles de razonamiento).

### Ajuste universal de esfuerzo (v0.2.0, simplificado en v0.3.0)

**Cualquier modelo/proveedor personalizado de terceros obtiene un control del esfuerzo de razonamiento que de verdad funciona en el cable**:

- **Aprovisionamiento a nivel de cable (host, pi-ai)**: para los modelos `llm-pi-ai` sin `reasoningEfforts`, se parchean el diccionario y el dialecto de cable `compat` (**aplicado en caliente, sin reinicio**); pi-ai traduce el nivel a campos reales del cable (`reasoning_effort` / `thinking` / `reasoning.effort` de OpenRouter, etc.) **y** publica la misma declaración como metadatos `reasoning` del catálogo del modelo — gracias a eso aparece la fila oficial **Effort** en un modelo declarado a mano;
- **Escala de respaldo en el cliente**: si el directorio no devuelve metadatos de razonamiento, el panel se abre igualmente con la escala universal de 5 niveles;
- Las declaraciones existentes del usuario (`reasoningEfforts: false` o un diccionario personalizado) siempre se respetan y nunca se sobrescriben.

> **Por qué ya no hay envoltorio de adaptadores.** Hasta la v0.2.5, la parte host también envolvía el `resolveModel` de cada adaptador para inyectar `universalReasoning` en los modelos que no declaraban metadatos `reasoning`. DSH 0.1.5 convirtió `llm.adapters` en un campo privado sin accesor público, así que esa vía es imposible — y ya no es necesaria: `reasoningEfforts` es la única declaración que alimenta tanto la solicitud real como el catálogo de modelos. El `compat` a nivel de modelo solo se escribe cuando la ruta declara `api: openai-completions`, porque pi-ai rechaza un interruptor que el protocolo del modelo no puede leer.

Dialectos de cable admitidos para endpoints personalizados (configura `effort-slider.defaultDialect` o `routes.<ruta>`).
Un dialecto traduce niveles solo en rutas `api: openai-completions` — los protocolos nativos usan el mapeo integrado de
pi-ai, así que el dialecto no tiene efecto en el cable allí:

| Dialecto | Efecto en el cable |
| --- | --- |
| `effort` (predeterminado) | `reasoning_effort: low/medium/high/max` estilo OpenAI |
| `deepseek` | conmutador `thinking:{type}` + `reasoning_effort` |
| `openrouter` | `reasoning: { effort }` (normalizado por OpenRouter) |
| `together` / `zai` | `reasoning.enabled` / `thinking:{type}` + esfuerzo opcional |
| `qwen` | conmutador `enable_thinking` |
| `string-thinking` / `ant-ling` | cadenas `thinking` / `reasoning.effort` |

## Compatibilidad

| Elemento | Valor |
| --- | --- |
| Versión de DSH | **0.2.0-rc.2** (el dist-tag `latest` de npm; la versión contra la que se verificó esta compilación), perfil web en Windows |
| No funciona en | DSH ≤ 0.1.5 — la v0.4.0 apunta al servicio de settings `SettingsForms` introducido en 0.2.0 (usa la v0.3.0 para DSH 0.1.5; la v0.2.5 y anteriores también importan `@deepseek-ai/dsh-client-runtime`, eliminado tras 0.1.1-rc.2) |
| Mecanismo de instalación | `dsh plugin --profile web add` (parche de bundle + doble mitad) |
| Depende de | `ctx.sessions` (`@deepseek-ai/dsh-api-session-controller`) y `ctx.modelDirectories` (`@deepseek-ai/dsh-client-ui-model-selection`); host: `ctx.llm`, `ctx.settings` (`SettingsForms`) |
| Peticiones de módulos del cliente | ninguna más allá de la base de la plataforma (`react`, `react-dom/client`, `react/jsx-runtime`) — todos los import de DSH son solo de tipos y se eliminan al empaquetar |

## Instalación / Desinstalación

```sh
# Instalar desde npm (el paquete listado en deepseek1024.com)
dsh plugin --profile web add @txc2768651338/dsh-effort-slider

# O instalar desde GitHub (los artefactos de lib/ están comprometidos, no hace falta compilar)
dsh plugin --profile web add github:2768651338/dsh-effort-slider#main

# O compilar localmente e instalar desde un checkout
pnpm install && pnpm build
dsh plugin --profile web add file:./dsh-effort-slider
```

> Tras instalar, **reinicia DeepSeek Harness** y pulsa **Ctrl+F5** una vez en la página web.
> Los artefactos de `lib/` están comprometidos: las instalaciones desde GitHub no requieren compilación local.

**¿Vienes de una versión fijada a un DSH antiguo?** Elimina cualquier fila `- id: ui-effort-slider` / `disabled: true` de `~/.dsh/profiles/web/cordis.patch.yml`, o la nueva compilación seguirá desactivada.

| Acción | Comando |
| --- | --- |
| Actualizar | `dsh plugin --profile web update @txc2768651338/dsh-effort-slider` (o reejecutar `add`), luego reiniciar DSH |
| Desinstalar | `dsh plugin --profile web remove @txc2768651338/dsh-effort-slider`, y quitar su fila de `cordis.patch.yml` si la hay |

## Inicio rápido

1. Instala el plugin, reinicia DSH, pulsa `Ctrl+F5`.
2. Abre el menú de modelos sobre el composer → haz clic en **Effort** → aparece el panel deslizante de Effort.
3. Arrastra para elegir un nivel; se ajusta al soltar. Tras cerrar el panel, el valor de esfuerzo conserva su color en la fila del menú.
4. Para modelos personalizados sin esfuerzo de razonamiento, el panel se abre con la escala universal de 5 niveles; los modelos pi-ai reciben sus diccionarios de cable parcheados en el host (aplicado en caliente).

Una línea `[effort-slider] intercept row: ...` en la Consola de DevTools significa que la intercepción funciona.

## Configuración

| Elemento | Detalles |
| --- | --- |
| Opciones del plugin | la configuración de profile entry del plugin (`enabled` / `defaultDialect` / `routes` / `debugReport`), editable en la página de ajustes de DSH (formulario generado automáticamente), aplicada al remontar el plugin |
| Valores por defecto | `enabled: true`, `defaultDialect: effort`, `debugReport: false` |
| Variables de entorno | ninguna propia; sigue la resolución de `DSH_HOME` de DSH |
| Elementos sensibles | ninguno — no se leen ni almacenan claves, tokens ni credenciales |

```yaml
effort-slider:
  enabled: true          # interruptor maestro del aprovisionamiento
  defaultDialect: effort # dialecto de cable por defecto global
  routes:
    my-gateway: deepseek # anulación por ruta
  debugReport: false     # informe de aprovisionamiento por pasada (ruta/modelo/dialecto/escrito-u-omitido) + traza de esfuerzo por solicitud (llm/stream) en el log del host
```

## Permisos y datos

| Alcance | Qué toca |
| --- | --- |
| Archivos (lectura) | ninguno — no se leen ni escriben archivos de usuario (los ajustes van por el servicio de settings de DSH) |
| Red | ninguna propia — el panel lee y escribe el directorio en el navegador del Model Controller; la llamada resultante a `session.selectModel` viaja por la conexión existente de DSH |
| Credenciales | nunca se leen |
| Datos de usuario | no se leen (sin acceso al contenido de conversaciones/mensajes/prompts; solo provider/model/`reasoningEffort` de la sesión actual a través del directorio de modelos compartido) |

## Cómo funciona

| Mitad | Archivo | Función |
| --- | --- | --- |
| Host | `lib/index.js` | Aprovisionamiento universal de esfuerzo: localiza la profile entry de pi-ai (`llm-pi-ai`), la lee vía `settings.describe()`, parchea los dialectos de cable vía `settings.mutate` (`buildProvisionOps`, idempotente, respeta las declaraciones del usuario); escucha `llm/adapters-updated` / `settings/document-updated`. Con `debugReport: true`, cada pasada registra un informe por ruta/modelo (campos escritos u omisión y su motivo, con nota donde el dialecto no aplica) en lugar del recuento de una línea, y traza cada llamada como `[debug] request route=… model=… effort=…` mediante un paso de solo lectura por `llm/stream` |
| Navegador | `lib/client.js` | Captura los clics en la fila Effort del menú de modelos → muestra el panel Effort; lee `ctx.modelDirectories.directoryFor(sessionId)` y escribe con `directory.select({ reasoningEffort })`; un MutationObserver mantiene vivo el color de nivel de la fila del menú tras cerrar el panel |

> La parte del navegador sigue la convención oficial de plugins externos: script clásico + factoría `window.__ModuleLoader__.load`; `react` / `react-dom/client` / `react/jsx-runtime` son externals de plataforma; `effort.module.css` se hashea e incrusta con lightningcss, inyectado como `<style data-plugin>` cuando se ejecuta la factoría.

## Solución de problemas

| Síntoma | Solución |
| --- | --- |
| No hay fila Effort en el menú de modelos | El modelo no declara metadatos de razonamiento y el aprovisionamiento del host no actúa — confirma que reiniciaste DSH y revisa `enabled` en la página de ajustes del plugin (su configuración de profile entry); pon `debugReport: true` y revisa el log del host para ver el informe de aprovisionamiento por modelo |
| El panel dice 「当前模型不支持思考强度调节」 | El respaldo universal no está activo — actualiza a v0.2.0+ y reinicia |
| El plugin no carga en absoluto (la fila muestra `disabled: true`) | Una compilación anterior quedó desactivada en `~/.dsh/profiles/web/cordis.patch.yml`; borra esa fila y reinicia |
| Arrastrar no tiene efecto | Comprueba si el dialecto de cable del endpoint coincide (ver tabla de dialectos — los dialectos solo traducen en rutas `api: openai-completions`) o fija `defaultDialect` para esa ruta. Con `debugReport: true` el log del host cubre toda la cadena verificable: el informe por modelo indica exactamente qué se escribió (u omitió, y por qué) y señala las rutas donde el dialecto no aplica, y las líneas `[debug] request route=… model=… effort=…` prueban qué nivel lleva cada llamada. Solo queda la traducción de cable dentro de pi-ai, que ningún plugin puede observar. El botón `?` del panel repite esta lista de comprobación |
| Conflictos con otros plugins de piel | Si tienes otra piel que intercepta la fila Effort (p. ej. la piel aurora de dsh-ui-web), desactiva su intercepción para evitar paneles dobles |
| La versión sigue mostrando la antigua tras reiniciar | Las instalaciones `file:` son copias instantáneas — usa la especificación `github:` o reejecuta `add` antes de reiniciar |
| ¿Dónde están los registros? | Errores del host: log de arranque de DSH (con `debugReport: true`, los detalles del aprovisionamiento y las trazas de esfuerzo por solicitud aparecen como líneas `effort-slider: [debug]`); errores del cliente: Consola de DevTools del navegador (F12) (prefijo `[effort-slider]`) |

## Estructura del proyecto

```text
src/
  index.ts                  mitad host: aprovisionamiento de cable pi-ai vía la costura de SettingsForms
  effort-core.ts             lógica pura: mapeo dialecto → cable, generación de parches de aprovisionamiento (testeada)
  client/
    index.ts                mitad navegador: intercepción de la fila Effort + ancla del panel + coloreado de la fila del menú
    css-modules.d.ts
    effort/
      directory.ts          cara estructural de ctx.modelDirectories / ctx.sessions (solo tipos, sin import del runtime de DSH)
      EffortPanel.tsx       Panel Effort (niveles / marcas / deslizador / brillo)
      useWebglFire.ts       Bucle de fuego WebGL2 de tres pasadas (seguimiento con resorte + reposo en inactividad)
      shaders.ts            shaders de vértices / ignición / desenfoque / composición
      effortColors.ts       mapeo nivel → color (compartido por panel y fila del menú)
      effort.module.css     estilos del panel (incrustados vía lightningcss)
cordis.patch.yml           parche de bundle (inserta la fila ui-effort-slider)
lib/                       artefactos compilados (client.js incluye sourcemap)
test/                      pruebas unitarias host.spec.mjs + host-apply.spec.mjs + client.smoke.mjs
```

## Desarrollo

```sh
pnpm install
pnpm build       # tsdown → lib/index.js (mitad host) + lib/client.js (mitad navegador)
pnpm typecheck   # tsc --noEmit (en verde contra @deepseek-ai/* 0.2.0-rc.2)
pnpm test        # unitarias del host + integración apply + integración de costura real + smoke jsdom
```

Capas de `test/`, de la más barata a la más costosa:

| Archivo | Alcance |
| --- | --- |
| `host.spec.mjs` | Lógica pura: mapeo dialecto → cable, generación de parches de aprovisionamiento, idempotencia |
| `host-apply.spec.mjs` | `apply()` contra un contexto cordis simulado: reintento por registro tardío de la entry de pi-ai, control de `compat` según el protocolo declarado, idempotencia de `settings/document-updated` |
| `host-integration.spec.mjs` | **Costura real**: `@deepseek-ai/cordis` real + un doble fiel de la costura `SettingsForms` (los paquetes npm de 0.2.0 no tienen proveedor independiente) — descubrimiento de la entry, escrituras path-op reales aterrizando en la configuración de profile entry, y el `reasoningEfforts`/`compat` escrito pasando las reglas de validación de pi-ai |
| `client.smoke.mjs` | jsdom: materialización de la factoría del bundle, intercepción de la fila Effort, render del panel, escrituras de arrastre/ajuste vía `directory.select`, coloreado, limpieza al desmontar |

**Contribuir.** Fork → cambiar → `pnpm build` → ejecutar `pnpm test` → abrir un PR contra `main`. Los arreglos pequeños (documentación, pruebas) son bienvenidos sin discusión previa; reporta issues con la versión de DSH y el error exacto.

## Licencia y seguridad

**Licencia**: BSD-3-Clause — ver [LICENSE](../../LICENSE).
La implementación de la interfaz referencia la piel aurora del proyecto comunitario dsh-ui-web (BSD-3-Clause); los avisos completos de origen y los textos de licencia están en
[THIRD_PARTY_NOTICES.md](../../THIRD_PARTY_NOTICES.md).

**Seguridad**: este plugin no lee credenciales ni envía nada por la red (solo habla con el DSH local). Para reportar un problema de seguridad de forma privada, usa **Report a vulnerability** en la pestaña Security de GitHub — no abras un issue público con detalles de explotación.

## Star History

<div align="center">

<a href="https://star-history.com/#2768651338/dsh-effort-slider&Date">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=2768651338/dsh-effort-slider&type=Date&theme=dark" />
    <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=2768651338/dsh-effort-slider&type=Date" />
    <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=2768651338/dsh-effort-slider&type=Date" />
  </picture>
</a>

</div>

---

<div align="center">

BSD-3-Clause © [2768651338](https://github.com/2768651338)

</div>
