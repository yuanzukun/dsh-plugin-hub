/**
 * 客户端目录服务的最小结构面 —— 本插件只依赖这些成员，不 import 任何
 * DSH 运行时包（纯类型 import 会在打包时被擦除，因此客户端产物没有
 * DSH 模块请求，无需 dsh.client.external）。
 *
 * 0.1.5 起，模型目录与档位写入不再走 `connection.api.sessions.models/selectModel`
 * 这两个直连 RPC（ConnectionHandle 已不暴露 `.api`），而是走
 * `ctx.modelDirectories`（ModelDirectoryResolver）暴露的每会话共享目录：
 * 同一个 store 同时驱动 /model 弹层与输入框上方的模型座位，写入走
 * `directory.select(...)`。0.2.1 的 select 改为返回 RemoteResult，目录另带
 * routable 表示当前模型是否可用；本插件同时兼容旧版的 Promise<void>。
 */

/** 一档推理等级（宿主目录返回的 effort 条目）。 */
export interface EffortLevel {
  id: string
  name: string
  description?: string
}

/** 目录里的一个模型。 */
export interface DirectoryModel {
  id: string
  name?: string
  /** 适配器声明的可选推理档位；缺失表示该模型没有原生多档推理。 */
  reasoning?: {
    efforts?: readonly EffortLevel[]
    defaultEffort?: string
  }
}

/** 一个提供方分组。 */
export interface DirectoryGroup {
  id: string
  name?: string
  models: readonly DirectoryModel[]
}

/** 一次完整的模型 + 档位选择。 */
export interface DirectorySelection {
  provider: string
  model: string
  reasoningEffort?: string
}

/** 目录快照（ModelDirectoryState 的结构子集）。 */
export interface DirectoryState {
  /** 生效选择：会话投影或宿主默认值。 */
  current: DirectorySelection | null
  /** 0.2.1：当前选择是否仍在目录中；null 表示会话投影尚未就绪。 */
  routable?: boolean | null
  /** 已加载的提供方分组。 */
  groups: readonly DirectoryGroup[]
  /** 进行中的操作生命周期。 */
  status?: 'idle' | 'loading' | 'ready' | 'selecting' | 'error'
  /** 整请求或选择失败的文案。 */
  error?: string | null
}

/** 一个会话的共享目录。 */
export interface ModelDirectoryLike {
  readonly store: {
    getSnapshot(): DirectoryState
    subscribe(listener: () => void): () => void
  }
  /** 确保宿主目录已加载。 */
  load(): Promise<unknown>
  /** 提交 provider/model/reasoningEffort 选择。 */
  select(selection: DirectorySelection): Promise<void | {
    ok: true
    value?: unknown
  } | {
    ok: false
    error: { code: string; message: string }
  }>
}

/** `ctx.modelDirectories`。 */
export interface ModelDirectoriesLike {
  directoryFor(sessionId: string): ModelDirectoryLike
}

/** 会话目录里的一行（SessionSummary 的结构子集）。 */
export interface SessionRowLike {
  id?: string
  /** 本地持有计数；0.2.0 的 mainView 计数 > 0 即当前主视图会话。 */
  retainedBy?: Partial<Record<string, number | undefined>>
}

/** 会话目录快照（SessionListState 的结构子集，兼容 0.1.x / 0.2.0）。 */
export interface SessionListLike {
  /** 0.1.x 直出的当前会话 id；0.2.0 起移除。 */
  current?: string
  /** 0.2.0 的目录行（键为会话 id）。 */
  byId?: Record<string, SessionRowLike>
}

/** `ctx.sessions`（只用到当前会话 id）。 */
export interface SessionsLike {
  readonly list: {
    getSnapshot(): SessionListLike
    subscribe?(listener: () => void): () => void
  }
}

/** 兼容旧版 rejection 与 0.2.1 的 RemoteResult，且接住同步抛错。 */
export async function selectEffort(directory: ModelDirectoryLike, selection: DirectorySelection): Promise<void> {
  const result = await directory.select(selection)
  if (result?.ok === false) throw new Error(`${result.error.code}: ${result.error.message}`)
}

/** Wait for a real catalog refresh without submitting against an unknown model. */
function readyForSelection(directory: ModelDirectoryLike): Promise<DirectoryState> {
  return new Promise((resolve, reject) => {
    let stop: (() => void) | undefined
    let settled = false
    const finish = (error?: Error, state?: DirectoryState): void => {
      if (settled) return
      settled = true
      clearTimeout(timeout)
      stop?.()
      if (error !== undefined) reject(error)
      else resolve(state!)
    }
    const read = (): void => {
      const state = snapshotOf(directory)
      if (state !== null && state.current !== null && state.routable !== null
        && (state.status !== 'error' || state.routable === true)
        && state.status !== 'loading' && state.status !== 'idle') {
        finish(undefined, state)
      } else if (state?.status === 'error') {
        finish(new Error(state.error ?? 'Model directory refresh failed'))
      }
    }
    const timeout = setTimeout(() => finish(new Error('Model directory refresh timed out')), 10000)
    stop = directory.store.subscribe(read)
    if (settled) stop()
    else read()
  })
}

/**
 * One active selection plus the latest requested value. Settings updates can
 * refresh the whole DSH catalog mid-drag; wait for it, then validate the actual
 * model again. Never replay a backlog of obsolete intermediate effort levels.
 * A committed request can finish after its panel closes, in its owning Session.
 */
export function effortWriter(directory: ModelDirectoryLike): (selection: DirectorySelection) => Promise<void> {
  let pending: DirectorySelection | undefined
  let active: Promise<void> | undefined
  const drain = async (): Promise<void> => {
    while (pending !== undefined) {
      let submitted = false
      try {
        const state = await readyForSelection(directory)
        const selection = pending
        pending = undefined
        submitted = true
        if (state.current?.provider !== selection.provider || state.current.model !== selection.model
          || state.routable === false) {
          throw new Error('The selected model changed before the effort could be saved')
        }
        await selectEffort(directory, selection)
      } catch (error) {
        if (!submitted) {
          pending = undefined
          throw error
        }
        // An older failure must not discard a newer pointer/keyboard request.
        if (pending === undefined) throw error
      }
    }
  }
  return (selection) => {
    pending = selection
    active ??= drain().finally(() => { active = undefined })
    return active
  }
}

/**
 * 解析当前主视图会话 id。0.1.x 直接读 `list.current`；0.2.0 该字段移除
 * （「导航归视图所有」），官方 uiSession 以 `retainedBy.mainView > 0`
 * 判定当前会话，这里跟随同一判定，并保留旧字段兜底。
 */
export function currentSessionId(sessions: SessionsLike): string | undefined {
  let snapshot: SessionListLike
  try {
    snapshot = sessions.list.getSnapshot()
  } catch {
    return undefined
  }
  const direct = snapshot.current
  if (typeof direct === 'string' && direct.length > 0) return direct
  for (const [key, row] of Object.entries(snapshot.byId ?? {})) {
    if ((row?.retainedBy?.mainView ?? 0) > 0) {
      return typeof row?.id === 'string' && row.id.length > 0 ? row.id : key
    }
  }
  return undefined
}

/** 安全读取目录快照：目录可能尚未装配完整。 */
export function snapshotOf(directory: ModelDirectoryLike): DirectoryState | null {
  try {
    return directory.store.getSnapshot() ?? null
  } catch {
    return null
  }
}
