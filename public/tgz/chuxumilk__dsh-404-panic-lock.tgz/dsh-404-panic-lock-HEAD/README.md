# 404 Panic Lock(DSH 404 防打扰锁)

按一个快捷键(`Ctrl+Shift+L`),整个页面瞬间变成一张**静态的 404 错误页截图**——鼠标、键盘、右键全部失效,看起来就像网站挂了;再按一次快捷键恢复。

> 防止别人趁你离开时乱动你的电脑。大概只有这样了(确信)

## 效果预览(草稿演示)

**在线预览**:<https://chuxumilk.github.io/dsh-404-panic-lock/> —— 打开后按 `Ctrl+Shift+L` 锁定,再按一次恢复。

也可以直接打开 [`demo/index.html`](demo/index.html)(本地文件)体验:页面会变成一个假的聊天界面,按 `Ctrl+Shift+L` 锁定,再按一次恢复。

## 功能

- 一键把 DSH Web 界面伪装成「404 Not Found」错误页(Canvas 现画的静态图片,像素级不可交互)
- **锁定自动进入浏览器全屏**,404 遮罩盖满整个屏幕(连地址栏/标签栏一起盖住),解锁自动退出
- 锁定时:点击、滚动、右键、键盘输入全部被吞掉;标签页标题同步变成 `404 Not Found`
- 再按一次快捷键恢复,标题还原
- 插件停止/卸载时自动解锁清理,不残留
- 轻量:客户端纯 DOM、无框架依赖

## 在 DSH 中运行

这是一个**标准 DSH 插件包**(bundle),命令行安装:

```bash
dsh plugin --profile web add github:chuxumilk/dsh-404-panic-lock
```

或者也可以通过DSH自己运行。
```text
  发送命令:安装 https://github.com/chuxumilk/dsh-404-panic-lock
```
同时，也支持在DSH插件市场搜索。
安装后重启 DSH,按 `Ctrl+Shift+L` 即可锁定/恢复。
## 快捷键自定义

默认 `Ctrl+Shift+L`(L = Lock)。改 `client.js` 顶部的 `HOTKEY_CODE` 即可,例如:

```js
const HOTKEY_CODE = 'KeyD' // Ctrl+Shift+D
```

## 工作原理

1. 浏览器半部(`client.js`)在 `document` 捕获阶段监听 `keydown`,命中快捷键时切换锁定状态
2. 锁定时用 Canvas 按当前窗口尺寸画一张逼真的 404 页面(伪浏览器地址条 + 大号 404 + 说明文字),导出为 PNG 图片
3. 图片放进 `position: fixed` + 最大 z-index 的全屏遮罩,盖住整个页面
4. 锁定期间拦截所有键盘事件和右键菜单;失焦输入框,防止焦点留在背后

## 目录结构

```
├── package.json        # 包清单:dsh.bundle.patch + dsh.client(web) 声明
├── cordis.patch.yml    # bundle 补丁:把插件行插入 profile 插件名单
├── index.js            # 宿主半部(空实现,仅占位)
├── client.js           # 浏览器半部:bundle 格式(__ModuleLoader__.load)
└── demo/
    └── index.html      # 独立演示页:打开后按 Ctrl+Shift+L 体验
```

## 免责声明

本插件是**防打扰**工具,它只是盖住页面、吞掉输入,不能阻止任何真正的系统级操作。
