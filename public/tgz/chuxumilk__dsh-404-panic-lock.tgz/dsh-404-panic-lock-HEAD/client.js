/**
 * 404 Panic Lock — 标准 DSH 插件包,浏览器半部(client.js)
 *
 * 这是 web 插件表服务的客户端 bundle:通过 window.__ModuleLoader__.load
 * 注册,工厂返回的 module.exports 即插件对象(带 apply)。
 *
 * 纯浏览器端实现,无任何后端依赖:
 * 按 Ctrl+Shift+L 锁定(整页变成一张静态 404 截图,鼠标键盘全部锁死),
 * 再按一次恢复。
 */
window.__ModuleLoader__.load({
  id: 'dsh-404-panic-lock',
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });

    // ===== 配置:快捷键 Ctrl+Shift+L(改这里即可换键)=====
    const HOTKEY_CODE = 'KeyL';

    let locked = false;
    let overlay = null;
    let savedTitle = '';

    function roundRect(g, x, y, w, h, r) {
      g.beginPath();
      g.moveTo(x + r, y);
      g.arcTo(x + w, y, x + w, y + h, r);
      g.arcTo(x + w, y + h, x, y + h, r);
      g.arcTo(x, y + h, x, y, r);
      g.arcTo(x, y, x + w, y, r);
      g.closePath();
    }

    // 用 Canvas 画一张逼真的 404 错误页(静态图片,像截图一样完全不可交互)
    function render404() {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const dpr = window.devicePixelRatio || 1;
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
      const g = canvas.getContext('2d');
      g.scale(dpr, dpr);
      const font = (size, weight, family) => weight + ' ' + size + 'px ' + family;

      // 背景
      g.fillStyle = '#ffffff';
      g.fillRect(0, 0, w, h);

      // 顶部伪浏览器地址条
      g.fillStyle = '#24292f';
      g.fillRect(0, 0, w, 48);
      g.fillStyle = '#e6edf3';
      g.font = font(15, '400', 'system-ui, sans-serif');
      g.textAlign = 'left';
      g.textBaseline = 'middle';
      g.fillText('\u2190', 18, 24);
      const pillW = Math.min(w - 100, 520);
      g.fillStyle = 'rgba(255, 255, 255, 0.14)';
      roundRect(g, 46, 12, pillW, 24, 12);
      g.fill();
      g.fillStyle = '#9da7b3';
      g.font = font(13, '400', 'system-ui, sans-serif');
      g.fillText('localhost:3081/404', 60, 24);

      // 正文
      const cx = w / 2;
      const baseY = h * 0.38;
      g.textAlign = 'center';
      g.fillStyle = '#57606a';
      g.font = font(96, '700', 'ui-monospace, SFMono-Regular, Consolas, monospace');
      g.fillText('404', cx, baseY);
      g.fillStyle = '#24292f';
      g.font = font(26, '600', 'system-ui, sans-serif');
      g.fillText('Page Not Found', cx, baseY + 76);
      g.fillStyle = '#57606a';
      g.font = font(15, '400', 'system-ui, sans-serif');
      g.fillText('The page you are looking for might have been removed,', cx, baseY + 116);
      g.fillText('had its name changed, or is temporarily unavailable.', cx, baseY + 140);
      const bw = 120;
      const bh = 36;
      const by = baseY + 172;
      g.fillStyle = '#0969da';
      roundRect(g, cx - bw / 2, by, bw, bh, 18);
      g.fill();
      g.fillStyle = '#ffffff';
      g.font = font(14, '600', 'system-ui, sans-serif');
      g.fillText('Try again', cx, by + bh / 2);

      // 页脚
      g.fillStyle = '#8b949e';
      g.font = font(12, '400', 'system-ui, sans-serif');
      g.fillText('Error code: 404', cx, h - 26);

      return canvas.toDataURL('image/png');
    }

    // 进入/退出浏览器全屏,让遮罩盖住整个屏幕(连地址栏/标签栏一起盖住)
    function requestFullscreen() {
      try {
        const el = document.documentElement;
        if (el.requestFullscreen && !document.fullscreenElement) {
          const p = el.requestFullscreen();
          if (p && typeof p.catch === 'function') p.catch(() => {});
        }
      } catch (e) {
        // 不支持全屏就保持页面内遮罩
      }
    }

    function exitFullscreen() {
      try {
        if (document.fullscreenElement && document.exitFullscreen) {
          const p = document.exitFullscreen();
          if (p && typeof p.catch === 'function') p.catch(() => {});
        }
      } catch (e) {}
    }

    // 全屏切换后视口变大,按新尺寸重画 404 图片,避免拉伸模糊
    function onFullscreenChange() {
      if (locked && overlay) {
        const img = overlay.querySelector('img');
        if (img) img.src = render404();
      }
    }

    function lock() {
      if (locked) return;
      locked = true;
      savedTitle = document.title;
      document.title = '404 Not Found';
      const active = document.activeElement;
      if (active && typeof active.blur === 'function') active.blur();
      requestFullscreen();

      const img = document.createElement('img');
      img.src = render404();
      img.alt = '';
      img.style.width = '100%';
      img.style.height = '100%';
      img.style.display = 'block';
      img.style.pointerEvents = 'none';
      img.style.userSelect = 'none';

      overlay = document.createElement('div');
      overlay.setAttribute('data-panic-lock', '');
      const s = overlay.style;
      s.position = 'fixed';
      s.top = '0';
      s.left = '0';
      s.width = '100vw';
      s.height = '100vh';
      s.zIndex = '2147483647';
      s.margin = '0';
      s.padding = '0';
      s.background = '#ffffff';
      s.cursor = 'default';
      s.overflow = 'hidden';
      overlay.appendChild(img);
      document.documentElement.appendChild(overlay);
    }

    function unlock() {
      if (!locked) return;
      document.title = savedTitle;
      if (overlay) overlay.remove();
      overlay = null;
      locked = false;
      exitFullscreen();
    }

    function onKeyDown(e) {
      const isHotkey = e.ctrlKey && e.shiftKey && e.code === HOTKEY_CODE;
      if (locked && !isHotkey) {
        // 锁定期间吞掉所有键盘输入
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (isHotkey) {
        e.preventDefault();
        if (locked) unlock();
        else lock();
      }
    }

    function onContextMenu(e) {
      if (locked) e.preventDefault();
    }

    exports.apply = function apply(ctx) {
      ctx.effect(() => {
        document.addEventListener('keydown', onKeyDown, true);
        document.addEventListener('contextmenu', onContextMenu, true);
        document.addEventListener('fullscreenchange', onFullscreenChange);
        return () => {
          document.removeEventListener('keydown', onKeyDown, true);
          document.removeEventListener('contextmenu', onContextMenu, true);
          document.removeEventListener('fullscreenchange', onFullscreenChange);
          unlock();
        };
      });
    };

    return module.exports;
  },
});
