/**
 * 404 Panic Lock — 宿主半部(空实现)
 *
 * 插件是纯浏览器端功能(快捷键 + 404 截图遮罩),宿主侧不需要任何
 * 行为。空的 apply 让插件行能出现在 host 的 cordis.yml / Loader 中
 * (浏览器半部通过 package.json 的 dsh.client 声明,由 web 插件表提供)。
 */
function apply() {}

export { apply }
