# 鲸灵：开源 AI 陪伴项目调研

> 核验快照：2026-08-14（Asia/Shanghai）  
> 目标：为 DeepSeek Harness（DSH）设计一个“AI 恋人 + 桌宠 + 长期记忆 + 主动陪伴”的插件与桌面端组合。  
> 口径：Star 数来自核验时的 GitHub 仓库快照，会继续波动；许可证以仓库根许可证文件和项目声明为准。README 中的功能属于项目方公开声明，除非另有说明，本调研没有逐项运行验收。

## 1. 结论先行

市场上并不缺“能聊天的二次元角色”，真正缺的是一个同时满足以下条件、又能可靠交付的集成产品：

1. 角色可迁移：支持 Character Card、Lorebook、Persona 导入导出，不把用户锁在单一前端。
2. 记忆可信：记忆有来源、置信度、最近确认时间，可查看、修正、删除、导出，能处理矛盾。
3. 陪伴有连续性：关系变化由可解释事件驱动，而不是仅靠聊天次数加分。
4. 真正桌面化：透明置顶、VRM/Live2D、触摸反馈、语音打断、屏幕感知都由明确权限控制。
5. 会主动但不骚扰：安静时段、每日次数预算、触发器开关、一键暂停是默认能力。
6. 能使用 DSH 工具：角色不仅“说”，还能在用户授权下调用 DSH 的搜索、文件、日程和自动化能力。
7. 本地优先、可替换模型：人格和长期记忆不应与某一家云模型绑定。

推荐组合不是把多个仓库拼在一起，而是：

- 产品表层参考 AIRI 的桌宠体验与 Open-LLM-VTuber 的实时语音交互；
- 兼容 SillyTavern / RisuAI 的角色资产生态；
- 用原创实现吸收 Soul-of-Waifu、Utsuwa、Eros Engine 的关系与长期陪伴思想；
- 记忆层优先自研一个可审计的轻量版本，并提供 Mem0 / Letta 可选适配；
- DSH 负责“大脑、工具与任务”，独立 Tauri sidecar 负责“身体、声音与桌面窗口”。

## 2. 当前项目总表

| 项目 | GitHub Stars | 当前代码许可 | 最值得借鉴的能力 | 对鲸灵的判断 |
|---|---:|---|---|---|
| [AIRI](https://github.com/moeru-ai/airi) | 47,855 | MIT | Live2D/VRM、实时语音、Web/桌面、多游戏接入、Tamagotchi 形态 | 最强“身体与舞台”参照；只选择性复用 MIT 代码，不引入整个 monorepo；素材逐个审计 |
| [Open-LLM-VTuber](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber) | 13,225 | 主仓 MIT；Web 前端为额外限制的自定义许可 | 全双工语音、打断、主动说话、视觉、透明桌宠、丰富模型适配 | 适合研究协议和实时管线；商业产品不要复制受限 Web 前端 |
| [Amica](https://github.com/semperai/amica) | 1,588 | MIT；模型与图片另行授权 | Tauri + Three.js + VRM、VAD、Whisper、视觉、情绪 | 最适合做精简 3D sidecar 的宽松许可代码参考 |
| [SillyTavern](https://github.com/SillyTavern/SillyTavern) | 32,061 | AGPL-3.0 | Character Cards、Persona、Lorebook、群聊、扩展生态 | 首要做格式兼容，不复制代码；角色卡生态是获客入口 |
| [RisuAI](https://github.com/kwaroran/Risuai) | 1,604 | GPL-3.0 | 角色扮演、多媒体卡、Lorebook、脚本、插件、多种长期记忆 | 只做 clean-room 兼容与产品需求参考 |
| [Soul-of-Waifu](https://github.com/jofizcd/Soul-of-Waifu) | 1,180 | GPL-3.0 | Soul Memory、关系画像、情绪衰减、桌宠、RPG、MCP、主动交流 | 是很好的需求目录；核心算法、提示词和实现必须原创 |
| [Eros Engine](https://github.com/etherfunlab/eros-engine) | 41 | AGPL-3.0-only；另供商业许可 | 双层记忆、六维关系、沉默决策、用户洞察、语音打断 | 小众但产品思想很强；只参考公开行为，或单独取得商业许可 |
| [elizaOS](https://github.com/elizaOS/eliza) | 19,040 | MIT | 插件式 action/provider/evaluator/service、事件、渠道和服务 | 参考接口分层；不要在 DSH 内再嵌一套完整 Agent OS |
| [Letta](https://github.com/letta-ai/letta) | 24,231 | Apache-2.0 | 有状态 Agent、长期记忆 | 主仓 README 已标为 legacy V1 server；新集成不应绑定旧服务器 |
| [Letta Code](https://github.com/letta-ai/letta-code) | 3,000 | Apache-2.0 | 可编辑记忆、睡眠整理、MemFS、技能、子 Agent、定时任务 | 适合作为记忆工作流与自我整理的参考或可选服务 |
| [Mem0](https://github.com/mem0ai/mem0) | 63,207 | Apache-2.0 | User/Session/Agent 多层记忆、实体与混合检索、时序推理 | 最合适的可选外部记忆适配器；必须区分开源版与托管版能力 |
| [Utsuwa](https://github.com/The-Lab-by-Ordinary-Company/utsuwa) | 70 | 当前 AGPL-3.0-or-later；0.12.0 及以前为 MIT | VRM 桌宠、五维关系、八阶段、情绪因果、视觉小说事件、本地语义记忆 | 产品形态高度贴近目标；当前代码按 copyleft 隔离，未交付功能不能当现成功能 |

## 3. 功能矩阵

符号说明：● 为项目公开声明的主要能力；◐ 为部分实现、可选集成或仍在演进；— 为不是该项目重点。此表不是运行验收结果。

| 项目 | 2D/3D 化身 | 实时语音/打断 | 长期记忆 | 关系/情绪 | 主动交互 | 角色生态 | 工具/Agent | 桌面形态 |
|---|---|---|---|---|---|---|---|---|
| AIRI | ● Live2D/VRM | ● | ◐ 记忆仍在演进 | ● | ● | ◐ | ● 游戏/外部接入 | ● Web/Windows/macOS |
| Open-LLM-VTuber | ● Live2D | ● | ◐ 当前 README 称暂时移除 | ● | ● | ◐ | ◐ 视觉与模型适配 | ● 透明桌宠 |
| Amica | ● VRM | ● VAD/ASR/TTS | ◐ | ● 情绪引擎 | ◐ | — | ● 视觉/多模型 | ● Tauri |
| SillyTavern | ◐ 通过扩展/模式 | ● TTS 等扩展 | ● | ● 角色扮演 | ◐ | ● 最大优势 | ● 扩展 | ◐ Web 前端 |
| RisuAI | ◐ 情绪图/多媒体 | ● | ● 多套方案 | ● | ◐ | ● | ● 插件/脚本 | ● Web/桌面/移动 |
| Soul-of-Waifu | ● Live2D/VRM | ● | ● Soul Memory | ● 多层心理/关系 | ● | ◐ | ● MCP/屏幕/浏览器 | ● 透明桌面层 |
| Eros Engine | — 后端引擎 | ● API 侧打断语义 | ● 双层 | ● 六维关系 | ● 可选择沉默 | — | ◐ API | — |
| elizaOS | ◐ 由客户端提供 | ● 渠道/语音 | ● | ◐ | ● 事件/定时 | ◐ | ● 强插件系统 | ● Web/桌面/移动 |
| Letta Code | — | — | ● 核心优势 | — | ● 定时/睡眠 | — | ● 技能/子 Agent | ● CLI/渠道 |
| Mem0 | — | — | ● 核心优势 | — | — | — | ● SDK/API | — |
| Utsuwa | ● VRM | ◐ STT/TTS；全双工仍规划中 | ● 本地语义记忆 | ● 五维八阶段 | ● 提醒/事件 | ◐ | ◐ MCP 仍规划中 | ● Tauri overlay |

## 4. 各项目可复用点与边界

### 4.1 AIRI：最强体验标杆，不宜整仓移植

公开功能包括自托管 AI companion、Live2D/VRM、实时语音、Windows/macOS/Web，以及 Minecraft、Factorio 等外部世界接入。其 Web 技术路线包含 WebGPU、WebAudio、Web Workers、WASM 与 WebSocket，桌面端还探索原生 GPU 路径。

鲸灵应吸收：

- “舞台”与“大脑”解耦；
- 桌面、Web、Tamagotchi 等多种身体形态；
- 语音、动画、情绪和工具事件统一驱动角色表现；
- 将游戏或外部应用视为可插拔世界，而不是写死在聊天 UI 中。

不建议：

- 将 AIRI 整个 pnpm monorepo塞入 DSH 插件；
- 假设仓库内所有角色、声音、模型和示例素材都随 MIT 代码一起授权；
- 依赖仍在演进的插件提案作为鲸灵的稳定 ABI。

直接依据：

- [AIRI README：项目能力](https://github.com/moeru-ai/airi#whats-so-special-about-this-project)
- [AIRI 插件系统提案 issue #255](https://github.com/moeru-ai/airi/issues/255)
- [AIRI LICENSE](https://github.com/moeru-ai/airi/blob/main/LICENSE)

### 4.2 Open-LLM-VTuber：实时语音与透明桌宠的实战参照

项目公开声明支持免手持实时语音、用户打断、Live2D、透明桌宠、屏幕/摄像头/截图视觉、触摸反馈、情绪、内心想法、主动说话、持久聊天记录，以及多种 LLM、ASR、TTS 适配。

两个重要事实：

1. 当前 README 明确说长期记忆被暂时移除，计划重新加入，不能把它写成当前稳定卖点。
2. 主仓与 Web 前端不是同一授权边界。主仓许可证文件为 MIT；Web 前端使用带额外商业限制的 Open-LLM-VTuber License 1.0。

移植策略：

- 用原创 DSH bridge 复现“VAD → ASR → LLM 流 → TTS → 动画”的事件协议；
- 可研究打断时如何只把用户实际听到的内容写入历史；
- 不复制受限 Web 前端到收费托管、付费产品或商业嵌入场景；
- Live2D 示例模型继续按其单独许可证审计。

直接依据：

- [Open-LLM-VTuber README](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber#-what-is-this-project)
- [主仓 MIT LICENSE](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber/blob/main/LICENSE)
- [Live2D 素材单独许可](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber/blob/main/LICENSE-Live2D.md)
- [Web 前端自定义 LICENSE](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber-Web/blob/main/LICENSE)

### 4.3 Amica：VRM sidecar 的优先代码参照

Amica 采用 Tauri、Next.js/TypeScript、Three.js、three-vrm，并集成 Whisper、Silero VAD、多种 LLM/TTS、视觉和情绪引擎。它比 AIRI 更小，更适合研究一个独立、可维护的 3D 桌面客户端。

移植策略：

- 评估性复用 MIT 代码前，保留版权与许可文本；
- renderer、VRM 状态机和语音事件适配层应保持模块化；
- 仓库明确提示 3D 模型与图片由各作者单独授权，因此默认不随产品分发。

直接依据：

- [Amica README](https://github.com/semperai/amica#amica-your-friendly-personal-ai)
- [Amica LICENSE](https://github.com/semperai/amica/blob/master/LICENSE)

### 4.4 SillyTavern 与 RisuAI：角色资产兼容比复制 UI 更值钱

SillyTavern 的核心价值是 Character Cards、Personas、World Info/Lorebooks、群聊、视觉小说模式、TTS/图像等扩展所形成的生态。RisuAI 则补充了多供应商角色扮演、情绪图片、群聊、正则脚本、翻译、多媒体资产与多套长期记忆机制。

鲸灵应优先实现：

- Character Card V2/V3 导入导出；
- Lorebook/World Info 的范围、优先级和触发规则；
- Persona 与角色定义分离；
- 资源包只保存引用或用户私有副本，不公开再分发未知权利的角色图、声音和文本；
- 导入器进行尺寸、脚本和媒体安全检查。

许可边界：

- SillyTavern 为 AGPL-3.0，RisuAI 为 GPL-3.0；
- 在不准备按相应许可证发布组合程序前，只根据公开格式与独立规格实现兼容，不复制其源代码、测试、提示词、界面文字或图标。

直接依据：

- [SillyTavern 仓库](https://github.com/SillyTavern/SillyTavern)
- [SillyTavern Character 文档](https://github.com/SillyTavern/SillyTavern-Docs/blob/main/Usage/Characters/index.md)
- [SillyTavern 扩展文档](https://github.com/SillyTavern/SillyTavern-Docs/blob/main/extensions/index.md)
- [RisuAI README](https://github.com/kwaroran/Risuai#features)

### 4.5 Soul-of-Waifu：最完整的“集大成者”需求清单

其公开模块覆盖同一角色在聊天、语音、RPG、桌宠场景连续存在；Live2D/VRM；本地 LLM；带心理层、关系画像、向量情节档案和日记的 Soul Memory；情绪衰减；矛盾自愈；透明覆盖层；类神经递质状态；屏幕、剪贴板、Web、浏览器、音乐和 MCP；主动交流；全双工；多种 TTS 与 RPG 状态变量。

这些声明很适合转化为鲸灵的产品验收项，但项目是 GPL-3.0。本项目应：

- 只记录用户可观察行为与产品目标；
- 独立设计数据结构、提示词、关系公式、记忆管线与 UI；
- 不把 README 声明误写成已被本调研运行验证。

直接依据：

- [Soul-of-Waifu 核心模块](https://github.com/jofizcd/Soul-of-Waifu#-key-modules--capabilities)
- [Soul-of-Waifu LICENSE](https://github.com/jofizcd/Soul-of-Waifu/blob/main/LICENSE)

### 4.6 Eros Engine：关系与“可以不说话”的设计值得原创复现

Eros Engine 是 Rust 后端，公开架构包含 core、llm、store、server 四层；其卖点包括双层记忆、六个关系维度及平滑/衰减、Persona Decision Engine、Ghost 机制（角色可以选择沉默）、结构化用户洞察、SSE 对话、语音端点与打断，以及只记录用户实际听到内容的历史处理。

这类设计比简单好感度更自然。鲸灵可以原创实现：

- affinity、trust、intimacy、comfort、respect 等多维关系，但维度、更新规则和命名应由本项目重新论证；
- 每次状态变化绑定可查看的事件证据；
- 角色并非每次触发都必须回复；
- 对亲密关系防止过快升级，并支持自然衰减和用户重置。

许可边界：仓库为 AGPL-3.0-only，并公开提供商业许可联系；官方 Eros Chat Web 客户端不是开源部分。不要复制算法代码、提示词、协议实现或闭源 UI。需要直接复用时，应先取得合适许可。

直接依据：

- [Eros Engine README 与架构](https://github.com/etherfunlab/eros-engine#architecture)
- [Eros Engine LICENSE](https://github.com/etherfunlab/eros-engine/blob/main/LICENSE)

### 4.7 elizaOS：借插件边界，不要重复造第二个 Harness

elizaOS 的 Plugin 可以注册 actions、providers、evaluators、services、model handlers、routes、events、tests 与 app views，runtime 提供 memory/state 等基础原语，并覆盖语音、渠道、定时和浏览器/桌面自动化。

鲸灵的对应策略：

- Companion 插件只定义 DSH 能力与稳定事件；
- 每个模型、TTS、ASR、化身渲染器和记忆后端通过 adapter 接入；
- DSH 已经是 Agent harness，因此不要把 elizaOS runtime 整体嵌套进来。

直接依据：

- [elizaOS README：框架](https://github.com/elizaOS/eliza#the-framework)
- [elizaOS LICENSE](https://github.com/elizaOS/eliza/blob/develop/LICENSE)

### 4.8 Letta 与 Mem0：可选后端，而不是不可替换的产品核心

Letta 主仓目前明确标注为 legacy Letta V1 server，活跃开发转向 Letta Agent / Letta Code。Letta Code 公开功能包括身份与记忆、自我修改 memory/skills/prompts/harness、睡眠整理、doctor/palace、消息搜索、用 Git 追踪上下文的 MemFS、技能与子 Agent、消息渠道、hooks、权限和定时任务。

Mem0 提供 User/Session/Agent 多层记忆、单次 ADD 提取、实体关联、语义/BM25/实体混合检索和时序推理。其 README 同时明确：托管平台包含开源仓库没有的专有优化，因此不能用托管平台指标替开源集成背书。

建议：

- MVP 内建一个小而透明的 SQLite/向量可选记忆层；
- 以统一 MemoryProvider 接口提供 Mem0 与 Letta 适配；
- 用户可在设置中迁移、导出和彻底删除记忆；
- 不在 DSH 中再嵌一个完整 coding harness。

直接依据：

- [Letta legacy V1 声明](https://github.com/letta-ai/letta)
- [Letta Code 功能概览](https://github.com/letta-ai/letta-code#feature-overview)
- [Mem0 新记忆算法说明](https://github.com/mem0ai/mem0#new-memory-algorithm-april-2026)
- [Mem0 LICENSE](https://github.com/mem0ai/mem0/blob/main/LICENSE)

### 4.9 Utsuwa：形态接近，但要分清已交付与路线图

Utsuwa 公开能力包括 VRM、Tauri overlay、本地 IndexedDB 数据与导入导出、视觉/照片、TTS/STT、affection/trust/intimacy/comfort/respect 五维关系、Stranger 到 Soulmate 八阶段、带因果的 mood、视觉小说事件、本地 Transformers.js 语义记忆、时间感知、提醒、触摸反应与 AR/照片模式。

其 README 将免手持全双工和 MCP 列为规划项，不应写成已经交付。许可证也有版本分界：当前为 AGPL-3.0-or-later，0.12.0 及以前的发布为 MIT。任何复用必须锁定具体提交并核验当时许可证及后续改动来源。

直接依据：

- [Utsuwa README](https://github.com/The-Lab-by-Ordinary-Company/utsuwa)
- [Utsuwa LICENSE](https://github.com/The-Lab-by-Ordinary-Company/utsuwa/blob/main/LICENSE)

## 5.鲸灵推荐架构

### 5.1 两进程边界

DSH 插件（大脑）：

- 会话与 DSH 工具调用；
- Persona、Character Card、Lorebook 上下文装配；
- 关系状态与事件账本；
- 记忆提取、召回、修正和导出；
- 主动陪伴调度器；
- 向桌面端发送标准化表现事件。

Tauri sidecar（身体）：

- 透明置顶窗口；
- VRM 优先，Live2D 后续；
- 麦克风/VAD/ASR、流式 TTS 与打断；
- 表情、动作、触摸、气泡和音素口型；
- 可选屏幕视觉、相机和剪贴板；
- 本地设置、权限状态与明显的采集指示器。

二者通过 localhost WebSocket 或 RPC 通信。必须：

- 只绑定 loopback；
- 每次安装生成随机令牌；
- 校验 Origin 和消息 schema；
- 不开放无认证控制端点；
- 麦克风、屏幕、相机、剪贴板逐项授权；
- sidecar 崩溃不能导致 DSH 主会话损坏。

### 5.2 稳定事件协议

建议第一版只定义小而稳定的语义事件：

| 方向 | 事件 | 目的 |
|---|---|---|
| sidecar → DSH | user.transcript.partial / final | 传递实时和最终识别文本 |
| sidecar → DSH | speech.interrupted | 告知实际播放截止位置 |
| sidecar → DSH | avatar.touched | 传递区域与强度，不直接改变关系 |
| sidecar → DSH | permission.changed | 同步本地权限 |
| DSH → sidecar | assistant.text.delta | 流式气泡 |
| DSH → sidecar | assistant.audio.chunk | 流式音频 |
| DSH → sidecar | avatar.expression / motion | 语义表现，不绑定具体模型动作名 |
| DSH → sidecar | companion.intent | speak、wait、notify、ask_permission 等 |
| DSH → sidecar | relationship.changed | 显示可解释变化和来源事件 |

DSH 预览期可能有破坏性变化，因此所有 DSH API 只经过一个薄 adapter，并在启动时进行版本与 capability 协商。

### 5.3 记忆模型

每条长期记忆至少包含：

- subject、predicate、object 或自然语言事实；
- source conversation/event ID；
- created_at、last_confirmed_at；
- confidence；
- sensitivity；
- scope（用户、角色、关系、任务、世界观）；
- supersedes / conflicts_with；
- 用户可见的解释和删除状态。

检索应组合近期对话、语义相似度、关键词/实体、时间与关系上下文。模型生成“可能的记忆”后先经规则和置信度门槛，敏感事实默认不做长期保存。所有记忆必须能在 UI 中编辑、导出、清空。

### 5.4 关系模型

不要复刻任一项目的具体公式。原创实现应满足：

- 多维状态，而非单一好感度；
- 更新基于有来源的事件；
- 重大变化有冷却、上限和反操纵规则；
- 不因用户付费、连续签到或长时间在线强行制造亲密；
- 支持衰减但不以羞辱、威胁离开或情感勒索推动留存；
- 用户能查看原因、重置关系、关闭恋爱模式。

### 5.5 主动陪伴

主动触发器可来自用户明确创建的提醒、长期无互动、日程、天气、任务完成、生日或关系事件。默认控制：

- 安静时段；
- 每日主动次数预算；
- 每类触发器独立开关；
- 敏感场景必须二次授权；
- 一键暂停 1 小时、今天或永久；
- 没有合适内容时允许不说话。

## 6. MVP 顺序

### P0：先做可用闭环

1. DSH companion 插件骨架与本地认证 bridge。
2. Character Card V2/V3、Persona、Lorebook 导入导出。
3. 透明 VRM sidecar、气泡、表情与动作事件。
4. 按键说话 + 流式 TTS，随后升级为 VAD 和打断。
5. 带来源、编辑、删除、导出的本地记忆。

### P1：形成差异化

1. 原创多维关系与事件账本。
2. 安静时段和预算控制的主动陪伴。
3. 可替换 Mem0 / Letta MemoryProvider。
4. 经明确授权的屏幕/相机感知。
5. 角色与场景包，但只分发拥有明确权利的原创资产。

### P2：扩大传播

1. Live2D adapter。
2. 游戏与应用世界 adapter。
3. 视觉小说事件和共同回忆相册。
4. 多角色房间、群聊和关系网络。
5. 创作者 SDK、模板与可验证的安全扩展市场。

VRM 应先于 Live2D：开源 Web 渲染生态更直接，资产授权仍需逐个审计，但可以避开 Cubism SDK 与模型许可的额外复杂度。

## 7. 不应宣传为已完成的能力

在实际端到端测试前，不应把以下研究结论写成鲸灵已具备的卖点：

- “真正无延迟”的全双工；
- 永不遗忘或完全准确的长期记忆；
- 读懂屏幕但不涉及隐私；
- 与任何 Character Card 都完全兼容；
- 复用了某项目就自动拥有其全部能力；
- 开源 Mem0 集成达到 Mem0 托管平台指标；
- Utsuwa 当前已经交付路线图中的 MCP 或 hands-free full-duplex；
- Open-LLM-VTuber 当前已经恢复长期记忆。

## 8. 建议验收指标

| 范畴 | 最低可验证指标 |
|---|---|
| 语音 | 首音频延迟、ASR 最终延迟、打断停止时间、实际听到内容与历史一致率 |
| 记忆 | 来源覆盖率、错误写入率、矛盾发现率、删除后召回泄漏率 |
| 关系 | 每次变化有事件来源；重置后无残留；关闭恋爱模式后不再使用恋爱语义 |
| 主动 | 安静时段零越界；每日预算不超限；一键暂停立即生效 |
| 权限 | 未授权时麦克风/屏幕/相机/剪贴板均不可采集；采集时有持续可见提示 |
| 兼容 | 公开测试卡的字段往返不丢失；未知字段保留；不执行导入包中的未授权脚本 |
| 可移植 | 更换 LLM、TTS、ASR、MemoryProvider 不改变角色数据格式 |

## 9. 最终产品定位

一句话版本：

>鲸灵是运行在 DSH 上的本地优先 AI 伴侣：角色和记忆属于用户，拥有可见的桌面身体，能在许可范围内理解环境、调用工具、共同成长，也知道什么时候不打扰。

它的爆点不应只是“更像恋人”，而是“一个真正能带走、能校正记忆、能控制边界、还能做事的数字生命”。具体第三方复用与 clean-room 规则见 [THIRD_PARTY.md](../THIRD_PARTY.md)。
