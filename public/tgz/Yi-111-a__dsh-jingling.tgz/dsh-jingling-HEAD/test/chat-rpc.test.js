import assert from 'node:assert/strict'
import test from 'node:test'

import {
  CHAT_INPUT_MAX_CODE_POINTS,
  CHAT_SESSION_PREFIX,
  SoulDockChatBridge,
  projectChatHistory,
} from '../src/chat.js'
import { createSoulDockRpcHandler } from '../src/rpc.js'

function ok(request, value) {
  return Promise.resolve({ rpcId: request.rpcId, result: { ok: true, value } })
}

function fakeRuntime({ items = [], historyEvents = [] } = {}) {
  const calls = { list: [], create: [], history: [], prompt: [], cancel: [] }
  const api = { sessions: {
    list: request => { calls.list.push(request); return ok(request, { items }) },
    create: request => {
      calls.create.push(request)
      return ok(request, { sessionId: request.payload.sessionId, agentPreset: request.payload.agentPreset })
    },
    history: request => {
      calls.history.push(request)
      return ok(request, { events: historyEvents, hasMore: false })
    },
    prompt: request => { calls.prompt.push(request); return ok(request, { accepted: true }) },
    cancel: request => { calls.cancel.push(request); return ok(request, { accepted: true }) },
  } }
  const warnings = []
  const ctx = { logger: { warn: message => warnings.push(message) } }
  const service = { sidecarStatus: () => ({ persona: { id: 'lingqi', name: '鲸灵' } }) }
  return { api, calls, ctx, service, warnings }
}

function entry(event) {
  return { event }
}

test('chat open creates only a dedicated SoulDock session and projects text without private surfaces', async () => {
  const runtime = fakeRuntime({ historyEvents: [
    entry({
      type: 'user/message', seq: 0, time: 10, surfaceOp: 'append',
      data: { id: 'user-1', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: '你好' }] },
    }),
    entry({
      type: 'user/message', seq: 1, time: 11, surfaceOp: 'append',
      data: { id: 'plugin-1', role: 'user', source: { kind: 'plugin', plugin: 'secret' }, content: [{ type: 'text', text: 'PRIVATE_PROMPT_MARKER' }] },
    }),
    entry({
      type: 'assistant/chunk', seq: 2, time: 12,
      data: { turn: 0, step: 0, chunk: { type: 'reasoning-delta', index: 0, text: 'PRIVATE_REASONING_MARKER' } },
    }),
    entry({
      type: 'tool/call', seq: 3, time: 13,
      data: { turn: 0, step: 0, callId: 'call-1', name: 'companion_memory_recall', arguments: '{"secret":"PRIVATE_TOOL_MARKER"}' },
    }),
    entry({
      type: 'assistant/message', seq: 4, time: 14, surfaceOp: 'append',
      data: {
        turn: 0, step: 0,
        message: { id: 'assistant-1', role: 'assistant', source: { kind: 'model' }, content: [{ type: 'text', text: '你好呀' }] },
      },
    }),
    entry({
      type: 'tool/result', seq: 5, time: 15, surfaceOp: 'append',
      data: { message: { id: 'tool-1', role: 'user', source: { kind: 'tool' }, content: [{ type: 'text', text: 'PRIVATE_MEMORY_MARKER' }] } },
    }),
  ] })
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)

  const opened = await bridge.open(new AbortController().signal)
  assert.match(opened.chatId, /^chat-/)
  assert.equal(Object.hasOwn(opened, 'sessionId'), false)
  assert.equal(runtime.calls.create.length, 1)
  assert.match(runtime.calls.create[0].payload.sessionId, /^souldock-sidecar-/)
  assert.equal(runtime.calls.create[0].payload.agentPreset, 'souldock')
  assert.deepEqual(opened.messages.map(message => [message.role, message.text]), [
    ['user', '你好'],
    ['assistant', '你好呀'],
  ])
  assert.equal(opened.limits.inputCodePoints, CHAT_INPUT_MAX_CODE_POINTS)
  const serialized = JSON.stringify(opened)
  assert.doesNotMatch(serialized, /PRIVATE_PROMPT_MARKER|PRIVATE_REASONING_MARKER|PRIVATE_TOOL_MARKER|PRIVATE_MEMORY_MARKER/)
})

test('chat reuses only a dedicated root SoulDock session', async () => {
  const runtime = fakeRuntime({ items: [
    { sessionId: 'session-work', agentPreset: 'souldock', updatedAt: 500, running: false },
    { sessionId: `${CHAT_SESSION_PREFIX}wrong`, agentPreset: 'standard', updatedAt: 400, running: false },
    { sessionId: `${CHAT_SESSION_PREFIX}child`, agentPreset: 'souldock', parentSessionId: 'parent', updatedAt: 300, running: false },
    { sessionId: `${CHAT_SESSION_PREFIX}good`, agentPreset: 'souldock', updatedAt: 200, running: true },
  ] })
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)

  const opened = await bridge.open()
  assert.equal(opened.status, 'running')
  assert.equal(runtime.calls.create.length, 0)
  assert.equal(runtime.calls.history[0].payload.sessionId, `${CHAT_SESSION_PREFIX}good`)
})

test('chat send is idempotent text-only queue input and rejects commands or extra authority', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)
  const opened = await bridge.open()
  const request = {
    chatId: opened.chatId,
    clientMessageId: 'client-message-1',
    text: '今天过得怎么样？',
    clientTimeZone: 'Asia/Shanghai',
  }

  const duplicate = await Promise.all([bridge.send(request), bridge.send(request)])
  assert.deepEqual(duplicate, [
    { accepted: true, clientMessageId: 'client-message-1' },
    { accepted: true, clientMessageId: 'client-message-1' },
  ])
  assert.deepEqual(await bridge.send(request), { accepted: true, clientMessageId: 'client-message-1' })
  assert.equal(runtime.calls.prompt.length, 1)
  assert.equal(runtime.calls.prompt[0].rpcId, 'client-message-1')
  assert.deepEqual(runtime.calls.prompt[0].payload, {
    sessionId: runtime.calls.create[0].payload.sessionId,
    mode: 'queue',
    content: [{ type: 'text', text: request.text }],
    clientTimeZone: 'Asia/Shanghai',
  })
  await assert.rejects(() => bridge.send({ ...request, clientMessageId: 'client-message-2', text: '/compact' }), /slash commands/)
  await assert.rejects(() => bridge.send({ ...request, text: '相同 id 的另一条消息' }), /already used/)
  await assert.rejects(() => bridge.send({ ...request, clientMessageId: 'client-message-3', sessionId: 'session-work' }), /unsupported fields/)
  await assert.rejects(() => bridge.send({ ...request, clientMessageId: 'client-message-4', text: 'x'.repeat(CHAT_INPUT_MAX_CODE_POINTS + 1) }), /exceeds/)
})

test('chat send rechecks the dedicated preset immediately before dispatch', async () => {
  const runtime = fakeRuntime()
  let createCount = 0
  runtime.api.sessions.create = request => {
    runtime.calls.create.push(request)
    createCount += 1
    return ok(request, {
      sessionId: request.payload.sessionId,
      agentPreset: createCount === 1 ? 'souldock' : 'standard',
    })
  }
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)
  const opened = await bridge.open()

  await assert.rejects(() => bridge.send({
    chatId: opened.chatId,
    clientMessageId: 'client-message-preset-race',
    text: '你好',
  }), /no longer uses the Jingling preset/)
  assert.equal(runtime.calls.prompt.length, 0)
})

test('chat poll streams visible deltas and finals but drops reasoning, tools, and plugin context', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)
  const opened = await bridge.open()
  const session = { id: runtime.calls.create[0].payload.sessionId }

  bridge.acceptSessionEvent(session, {
    type: 'assistant/chunk', seq: 1, time: 100,
    data: { turn: 1, step: 1, chunk: { type: 'reasoning-delta', index: 0, text: 'PRIVATE_REASONING' } },
  })
  bridge.acceptSessionEvent(session, {
    type: 'tool/call', seq: 2, time: 101,
    data: { turn: 1, step: 1, name: 'secret_tool', arguments: 'PRIVATE_ARGUMENTS' },
  })
  bridge.acceptSessionEvent(session, {
    type: 'user/message', seq: 3, time: 102,
    data: { id: 'plugin-context', source: { kind: 'plugin', plugin: 'private' }, content: [{ type: 'text', text: 'PRIVATE_CONTEXT' }] },
  })
  bridge.acceptSessionEvent(session, {
    type: 'assistant/chunk', seq: 4, time: 103,
    data: { turn: 1, step: 1, chunk: { type: 'text-delta', index: 0, text: '晚' } },
  })
  bridge.acceptSessionEvent(session, {
    type: 'assistant/message', seq: 5, time: 104,
    data: {
      turn: 1, step: 1,
      message: { id: 'assistant-final-1', content: [{ type: 'text', text: '晚上好' }] },
    },
  })

  const polled = await bridge.poll({ chatId: opened.chatId, afterSequence: opened.sequence, timeoutMilliseconds: 0 })
  assert.deepEqual(polled.events.map(event => event.type), ['assistant-delta', 'assistant-final'])
  assert.doesNotMatch(JSON.stringify(polled), /PRIVATE_REASONING|PRIVATE_ARGUMENTS|PRIVATE_CONTEXT/)
})

test('chat long poll wakes on a visible event and reports an overflow resync boundary', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)
  const opened = await bridge.open()
  const session = { id: runtime.calls.create[0].payload.sessionId }
  const waiting = bridge.poll({ chatId: opened.chatId, afterSequence: 0, timeoutMilliseconds: 1_000 })
  queueMicrotask(() => bridge.acceptSessionEvent(session, {
    type: 'assistant/chunk', seq: 1, time: 100,
    data: { turn: 1, step: 1, chunk: { type: 'text-delta', index: 0, text: '醒' } },
  }))
  const awakened = await waiting
  assert.deepEqual(awakened.events.map(event => event.delta), ['醒'])

  for (let index = 2; index < 260; index += 1) {
    bridge.acceptSessionEvent(session, {
      type: 'assistant/chunk', seq: index, time: 100 + index,
      data: { turn: 1, step: 1, chunk: { type: 'text-delta', index: 0, text: 'x' } },
    })
  }
  const overflow = await bridge.poll({ chatId: opened.chatId, afterSequence: 0, timeoutMilliseconds: 0 })
  assert.equal(overflow.resetRequired, true)
  assert.deepEqual(overflow.events, [])
})

test('chat emits one public error when agent/error and turn/end report the same failure', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)
  const opened = await bridge.open()
  const sessionId = runtime.calls.create[0].payload.sessionId
  const session = { id: sessionId }
  const agent = { id: sessionId }

  bridge.acceptError(agent)
  bridge.acceptSessionEvent(session, {
    type: 'turn/end', seq: 9, time: Date.now(),
    data: { reason: { kind: 'error' } },
  })

  const polled = await bridge.poll({ chatId: opened.chatId, afterSequence: opened.sequence, timeoutMilliseconds: 0 })
  assert.deepEqual(polled.events.filter(event => event.type === 'error'), [{
    type: 'error',
    at: polled.events.find(event => event.type === 'error').at,
    code: 'failed',
    message: '生成失败，请稍后重试。',
    sequence: 1,
  }])
})

test('chat cancel stays bound to its capability session and close revokes the handle', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockChatBridge(runtime.ctx, runtime.service, runtime.api)
  const opened = await bridge.open()

  assert.deepEqual(await bridge.cancel({ chatId: opened.chatId }), { accepted: true })
  assert.equal(runtime.calls.cancel[0].payload.sessionId, runtime.calls.create[0].payload.sessionId)
  assert.deepEqual(bridge.close({ chatId: opened.chatId }), { closed: true })
  await assert.rejects(
    () => bridge.poll({ chatId: opened.chatId, afterSequence: 0, timeoutMilliseconds: 0 }),
    /missing or expired/,
  )
})

test('chat RPC endpoints retain the existing protected application envelope', async () => {
  const calls = []
  const chat = {
    open: async () => { calls.push('open'); return { version: 1, chatId: 'chat-one' } },
    send: async payload => { calls.push(['send', payload]); return { accepted: true } },
    poll: async payload => { calls.push(['poll', payload]); return { version: 1, sequence: 0, status: 'idle', events: [] } },
    cancel: async payload => { calls.push(['cancel', payload]); return { accepted: true } },
    close: payload => { calls.push(['close', payload]); return { closed: true } },
  }
  const rpc = createSoulDockRpcHandler({}, chat)
  const signal = new AbortController().signal
  const opened = await rpc('chat/open', {}, signal)
  assert.equal(opened.ok, true)
  assert.equal(opened.value.ok, true)
  assert.equal(opened.value.value.chatId, 'chat-one')
  const invalid = await rpc('chat/open', { sessionId: 'arbitrary' }, signal)
  assert.equal(invalid.value.ok, false)
  assert.deepEqual(calls, ['open'])
})

test('history projection exposes an unfinished visible text draft only', () => {
  const projected = projectChatHistory([
    entry({ type: 'assistant/chunk', seq: 0, time: 1, data: { turn: 2, step: 3, chunk: { type: 'reasoning-delta', text: 'hidden' } } }),
    entry({ type: 'assistant/chunk', seq: 1, time: 2, data: { turn: 2, step: 3, chunk: { type: 'text-delta', text: '正在' } } }),
    entry({ type: 'assistant/chunk', seq: 2, time: 3, data: { turn: 2, step: 3, chunk: { type: 'text-delta', text: '回答' } } }),
  ])
  assert.deepEqual(projected.partial, { turn: 2, step: 3, text: '正在回答' })
  assert.doesNotMatch(JSON.stringify(projected), /hidden/)
})
