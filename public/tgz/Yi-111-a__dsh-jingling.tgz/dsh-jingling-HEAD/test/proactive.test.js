import assert from 'node:assert/strict'
import test from 'node:test'

import { createDefaultState, updateSettings } from '../src/core.js'
import { installProactiveRuntime } from '../src/proactive.js'
import { SoulDockService } from '../src/service.js'

function globalOf(initial) {
  let value = structuredClone(initial)
  return { get: () => structuredClone(value), set: async next => { value = structuredClone(next) } }
}

function contextHarness(agent, preset = 'souldock') {
  const handlers = new Map()
  const effects = []
  const on = (name, handler) => {
    const list = handlers.get(name) ?? []
    list.push(handler); handlers.set(name, list)
    return () => handlers.set(name, (handlers.get(name) ?? []).filter(item => item !== handler))
  }
  const effect = factory => {
    const cleanup = factory()
    effects.push(cleanup)
    return cleanup
  }
  const ctx = {
    agents: { roots: () => [agent], get: id => id === agent.id ? agent : undefined },
    agentPresets: { composedPreset: () => preset },
    sessions: { flush: async () => true },
    logger: { warn: () => {} },
    on, effect,
  }
  agent.ctx = { on, effect }
  return { ctx, handlers, effects }
}

test('proactive runtime sends at most one plugin-source followup after atomic admission', async () => {
  const now = Date.now()
  let state = updateSettings(createDefaultState(now - 86400000), { proactive: {
    enabled: true, dailyLimit: 1, idleAfterMinutes: 30, minimumGapMinutes: 60,
    quietHoursStart: '00:00', quietHoursEnd: '00:00', timeZone: 'UTC',
  } }, { now: now - 10 * 3600000 })
  const service = new SoulDockService(globalOf(state))
  const followups = []
  const agent = {
    id: 'session-1',
    status: 'idle',
    inbox: { hasPending: false },
    session: {
      firstLiveSeq: 0,
      events: [{ type: 'user/message', time: now - 4 * 3600000, data: { source: { kind: 'user' } } }],
    },
    runMaintenance: task => task(new AbortController().signal),
    whenIdle: () => Promise.resolve(),
    followup: message => { followups.push(message) },
  }
  const { ctx, effects } = contextHarness(agent)
  installProactiveRuntime(ctx, service, {
    pollMilliseconds: 3600000,
    createUserMessage: input => ({ id: 'generated', ...input }),
    boundContextSummary: text => text,
  })
  await new Promise(resolve => setTimeout(resolve, 25))
  assert.equal(followups.length, 1)
  assert.equal(followups[0].source.kind, 'plugin')
  assert.equal(service.read().proactiveHistory.length, 1)

  // Re-admission through the shared service cannot exceed the global budget.
  const second = await service.admitCheckIn(agent.id, now - 4 * 3600000, now + 1000)
  assert.equal(second.allowed, false)
  assert.equal(second.reason, 'daily-limit-reached')
  await new Promise(resolve => setTimeout(resolve, 10))
  assert.equal(followups.length, 1)
  await Promise.allSettled(effects.reverse().map(cleanup => Promise.resolve().then(cleanup)))
})

test('proactive runtime ignores non-SoulDock presets', async () => {
  const service = new SoulDockService(globalOf(createDefaultState()))
  const agent = {
    id: 'work', status: 'idle', inbox: { hasPending: false },
    session: { firstLiveSeq: 0, events: [] }, followup: () => assert.fail('must not send'),
  }
  const { ctx, effects } = contextHarness(agent, 'standard')
  installProactiveRuntime(ctx, service, {
    pollMilliseconds: 3600000,
    createUserMessage: input => ({ id: 'generated', ...input }),
    boundContextSummary: text => text,
  })
  await new Promise(resolve => setTimeout(resolve, 5))
  await Promise.allSettled(effects.reverse().map(cleanup => Promise.resolve().then(cleanup)))
})

test('an explicit user stop phrase persistently disables proactive greetings', async () => {
  const now = Date.now()
  const configured = updateSettings(createDefaultState(now - 86400000), { proactive: {
    enabled: true, dailyLimit: 3, idleAfterMinutes: 30, minimumGapMinutes: 60,
    quietHoursStart: '00:00', quietHoursEnd: '00:00', timeZone: 'UTC',
  } })
  const service = new SoulDockService(globalOf(configured))
  const followups = []
  const agent = {
    id: 'session-stop', status: 'idle', inbox: { hasPending: false },
    session: { firstLiveSeq: 0, events: [] },
    runMaintenance: task => task(new AbortController().signal),
    whenIdle: () => Promise.resolve(),
    followup: message => followups.push(message),
  }
  const { ctx, handlers, effects } = contextHarness(agent)
  installProactiveRuntime(ctx, service, {
    pollMilliseconds: 3600000,
    createUserMessage: input => ({ id: 'generated', ...input }),
    boundContextSummary: text => text,
  })
  for (const handler of handlers.get('agent/inbox/inserted') ?? []) {
    handler({ agent, message: { source: { kind: 'user' }, content: [{ type: 'text', text: '别再主动问候了' }] } })
  }
  await new Promise(resolve => setTimeout(resolve, 20))
  assert.equal(service.read().settings.proactive.enabled, false)
  assert.equal(followups.length, 0)
  await Promise.allSettled(effects.reverse().map(cleanup => Promise.resolve().then(cleanup)))
})
