import assert from 'node:assert/strict'
import test from 'node:test'

import { createSoulDockRpcHandler } from '../src/rpc.js'
import {
  SoulDockWorkspaceBridge,
  WORKSPACE_INPUT_MAX_CODE_POINTS,
  WORKSPACE_PRESET_ID,
  WORKSPACE_SESSION_PREFIX,
} from '../src/workspace.js'

const OWNED_SESSION = `${WORKSPACE_SESSION_PREFIX}11111111-1111-4111-8111-111111111111`
const OTHER_OWNED_SESSION = `${WORKSPACE_SESSION_PREFIX}22222222-2222-4222-8222-222222222222`

function ok(request, value) {
  return Promise.resolve({ rpcId: request.rpcId, result: { ok: true, value } })
}

function entry(event) {
  return { event }
}

function fakeRuntime({ sessionItems, workspaceItems, historyEvents = [], mux } = {}) {
  const workspace = {
    workspaceId: 'dsh-internal-workspace-one',
    path: 'C:\\selected\\project',
    title: 'Selected Project',
    sessionIds: [OWNED_SESSION],
    createdAt: '2026-08-14T00:00:00.000Z',
    updatedAt: '2026-08-14T00:00:00.000Z',
  }
  const calls = { workspaceList: [], workspaceCreate: [], list: [], create: [], history: [], rename: [], prompt: [], cancel: [] }
  const api = {
    workspace: {
      list: request => {
        calls.workspaceList.push(request)
        return ok(request, { items: workspaceItems ?? [workspace], archivedSessionIds: [] })
      },
      create: request => {
        calls.workspaceCreate.push(request)
        return ok(request, { workspace: { ...workspace, path: request.payload.path, sessionIds: [] }, created: true })
      },
    },
    sessions: {
      list: request => {
        calls.list.push(request)
        return ok(request, { items: sessionItems ?? [{
          sessionId: OWNED_SESSION,
          updatedAt: 1234,
          running: false,
          blank: false,
          cwd: workspace.path,
          agentPreset: WORKSPACE_PRESET_ID,
          projections: { asOfSeq: 9, values: { title: '修复登录流程' } },
        }] })
      },
      create: request => {
        calls.create.push(request)
        return ok(request, { sessionId: request.payload.sessionId, agentPreset: request.payload.agentPreset })
      },
      history: request => {
        calls.history.push(request)
        return ok(request, { events: historyEvents, hasMore: false })
      },
      rename: request => {
        calls.rename.push(request)
        return ok(request, { title: request.payload.title.trim(), seq: 0 })
      },
      prompt: request => {
        calls.prompt.push(request)
        return ok(request, { accepted: true })
      },
      cancel: request => {
        calls.cancel.push(request)
        return ok(request, { accepted: true })
      },
    },
    ...(mux === undefined ? {} : { events: { mux } }),
  }
  const warnings = []
  const ctx = { logger: { warn: message => warnings.push(message) } }
  return { api, calls, ctx, workspace, warnings }
}

test('workspace list projects only dedicated standard root tasks with opaque ids', async () => {
  const runtime = fakeRuntime({
    sessionItems: [
      {
        sessionId: OWNED_SESSION,
        updatedAt: 1234,
        running: true,
        blank: false,
        cwd: 'C:\\selected\\project',
        agentPreset: WORKSPACE_PRESET_ID,
        projections: { values: { title: '修复登录流程' } },
      },
      { sessionId: 'session-arbitrary', updatedAt: 9999, running: false, blank: false, agentPreset: WORKSPACE_PRESET_ID },
      { sessionId: OTHER_OWNED_SESSION, updatedAt: 9998, running: false, blank: false, agentPreset: 'souldock' },
      { sessionId: `${WORKSPACE_SESSION_PREFIX}33333333-3333-4333-8333-333333333333`, updatedAt: 9997, running: false, blank: false, agentPreset: WORKSPACE_PRESET_ID, parentSessionId: 'parent' },
    ],
    workspaceItems: [{
      workspaceId: 'dsh-internal-workspace-one',
      path: 'C:\\selected\\project',
      title: 'Selected Project',
      sessionIds: [OWNED_SESSION, 'session-arbitrary', OTHER_OWNED_SESSION, `${WORKSPACE_SESSION_PREFIX}33333333-3333-4333-8333-333333333333`],
      createdAt: '2026-08-14T00:00:00.000Z',
      updatedAt: '2026-08-14T00:00:00.000Z',
    }],
  })
  const bridge = new SoulDockWorkspaceBridge(runtime.ctx, runtime.api)

  const listed = await bridge.list()
  assert.equal(listed.version, 1)
  assert.equal(listed.workspaces.length, 1)
  assert.match(listed.workspaces[0].workspaceId, /^workspace-[0-9a-f]{32}$/)
  assert.equal(listed.workspaces[0].tasks.length, 1)
  assert.match(listed.workspaces[0].tasks[0].taskId, /^task-[0-9a-f]{32}$/)
  assert.equal(listed.workspaces[0].tasks[0].title, '修复登录流程')
  assert.equal(listed.workspaces[0].tasks[0].status, 'running')
  const serialized = JSON.stringify(listed)
  assert.doesNotMatch(serialized, /dsh-internal-workspace-one|souldock-workspace-|session-arbitrary/)
  bridge.dispose()
})

test('workspace create adopts only an explicit absolute cwd and creates the verified standard preset', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockWorkspaceBridge(runtime.ctx, runtime.api)
  const opened = await bridge.create({ cwd: 'C:\\chosen\\repo', title: '实现工作区模式' })

  assert.match(opened.task.taskId, /^task-[0-9a-f]{32}$/)
  assert.equal(opened.task.workspacePath, 'C:\\chosen\\repo')
  assert.equal(opened.task.title, '实现工作区模式')
  assert.equal(opened.status, 'idle')
  assert.equal(opened.limits.inputCodePoints, WORKSPACE_INPUT_MAX_CODE_POINTS)
  assert.deepEqual(runtime.calls.workspaceCreate[0].payload, { path: 'C:\\chosen\\repo' })
  assert.equal(runtime.calls.create[0].payload.workspaceId, runtime.workspace.workspaceId)
  assert.match(runtime.calls.create[0].payload.sessionId, /^souldock-workspace-/)
  assert.equal(runtime.calls.create[0].payload.agentPreset, 'standard')
  assert.equal(runtime.calls.rename[0].payload.title, '实现工作区模式')
  assert.equal(Object.hasOwn(opened, 'sessionId'), false)
  assert.doesNotMatch(JSON.stringify(opened), /dsh-internal-workspace-one|souldock-workspace-/)

  await assert.rejects(() => bridge.create({ cwd: 'relative\\repo' }), /absolute path/)
  await assert.rejects(() => bridge.create({ cwd: 'C:\\chosen\\repo', sessionId: 'arbitrary' }), /unsupported fields/)
  bridge.dispose()
})

test('workspace open accepts only an opaque owned task and projects public text without private surfaces', async () => {
  const runtime = fakeRuntime({ historyEvents: [
    entry({
      type: 'user/message', seq: 0, time: 10,
      data: { id: 'raw-user-message-id', source: { kind: 'user' }, content: [{ type: 'text', text: '检查测试' }] },
    }),
    entry({
      type: 'user/message', seq: 1, time: 11,
      data: { id: 'plugin-secret', source: { kind: 'plugin' }, content: [{ type: 'text', text: 'PRIVATE_PROMPT_CONTEXT' }] },
    }),
    entry({
      type: 'assistant/chunk', seq: 2, time: 12,
      data: { turn: 0, step: 0, chunk: { type: 'reasoning-delta', text: 'PRIVATE_REASONING' } },
    }),
    entry({
      type: 'tool/call', seq: 3, time: 13,
      data: { name: 'shell', arguments: { command: 'PRIVATE_TOOL_ARGUMENT' } },
    }),
    entry({
      type: 'assistant/message', seq: 4, time: 14,
      data: { turn: 0, step: 0, message: { id: 'raw-assistant-message-id', content: [{ type: 'text', text: '测试已通过' }] } },
    }),
  ] })
  const bridge = new SoulDockWorkspaceBridge(runtime.ctx, runtime.api)
  const listed = await bridge.list()
  const taskId = listed.workspaces[0].tasks[0].taskId
  const opened = await bridge.open({ taskId })

  assert.deepEqual(opened.messages.map(message => [message.role, message.text]), [
    ['user', '检查测试'],
    ['assistant', '测试已通过'],
  ])
  assert.match(opened.messages[0].id, /^message-[0-9a-f]{32}$/)
  const serialized = JSON.stringify(opened)
  assert.doesNotMatch(serialized, /raw-user-message-id|raw-assistant-message-id|PRIVATE_PROMPT_CONTEXT|PRIVATE_REASONING|PRIVATE_TOOL_ARGUMENT/)
  await assert.rejects(() => bridge.open({ taskId: OWNED_SESSION }), /valid Jingling task/)
  await assert.rejects(() => bridge.open({ taskId: 'task-00000000000000000000000000000000' }), /missing or is not owned/)
  bridge.dispose()
})

test('workspace send is idempotent, text-only, and rechecks preset/workspace ownership', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockWorkspaceBridge(runtime.ctx, runtime.api)
  const listed = await bridge.list()
  const taskId = listed.workspaces[0].tasks[0].taskId
  await bridge.open({ taskId })
  const request = {
    taskId,
    clientMessageId: 'workspace-client-1',
    text: '运行测试并修复失败',
    clientTimeZone: 'Asia/Shanghai',
  }

  assert.deepEqual(await Promise.all([bridge.send(request), bridge.send(request)]), [
    { accepted: true, clientMessageId: 'workspace-client-1' },
    { accepted: true, clientMessageId: 'workspace-client-1' },
  ])
  assert.deepEqual(await bridge.send(request), { accepted: true, clientMessageId: 'workspace-client-1' })
  assert.equal(runtime.calls.prompt.length, 1)
  assert.deepEqual(runtime.calls.prompt[0].payload, {
    sessionId: OWNED_SESSION,
    mode: 'queue',
    content: [{ type: 'text', text: request.text }],
    clientTimeZone: 'Asia/Shanghai',
  })
  const ensure = runtime.calls.create.at(-1).payload
  assert.equal(ensure.sessionId, OWNED_SESSION)
  assert.equal(ensure.workspaceId, runtime.workspace.workspaceId)
  assert.equal(ensure.agentPreset, WORKSPACE_PRESET_ID)
  await assert.rejects(() => bridge.send({ ...request, clientMessageId: 'workspace-client-2', text: '/compact' }), /slash commands/)
  await assert.rejects(() => bridge.send({ ...request, sessionId: 'arbitrary' }), /unsupported fields/)
  bridge.dispose()
})

test('workspace polling exposes text and safe needs-input state, never tool or approval payloads', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockWorkspaceBridge(runtime.ctx, runtime.api)
  const listed = await bridge.list()
  const taskId = listed.workspaces[0].tasks[0].taskId
  const opened = await bridge.open({ taskId })
  const session = { id: OWNED_SESSION }

  bridge.acceptSessionEvent(session, {
    type: 'approval/asked', seq: 1, time: 100,
    data: { id: 'approval-private-id', callId: 'PRIVATE_CALL', toolName: 'shell', reason: 'PRIVATE_REASON' },
  })
  bridge.acceptSessionEvent(session, {
    type: 'tool/call', seq: 2, time: 101,
    data: { name: 'shell', arguments: { command: 'PRIVATE_COMMAND' } },
  })
  bridge.acceptSessionEvent(session, {
    type: 'assistant/chunk', seq: 3, time: 102,
    data: { turn: 1, step: 1, chunk: { type: 'text-delta', text: '正在处理' } },
  })

  const polled = await bridge.poll({ taskId, afterSequence: opened.sequence, timeoutMilliseconds: 0 })
  assert.equal(polled.status, 'needs-input')
  assert.deepEqual(polled.events.map(event => event.type), ['status', 'assistant-delta'])
  assert.equal(polled.events[0].status, 'needs-input')
  assert.doesNotMatch(JSON.stringify(polled), /approval-private-id|PRIVATE_CALL|PRIVATE_REASON|PRIVATE_COMMAND|shell/)

  bridge.acceptSessionEvent(session, {
    type: 'approval/decided', seq: 4, time: 103,
    data: { id: 'approval-private-id', outcome: 'allowed-once' },
  })
  const resumed = await bridge.poll({ taskId, afterSequence: polled.sequence, timeoutMilliseconds: 0 })
  assert.equal(resumed.status, 'running')
  assert.deepEqual(resumed.events.map(event => event.status), ['running'])
  bridge.dispose()
})

test('workspace cancel and close remain bound to the opaque opened task capability', async () => {
  const runtime = fakeRuntime()
  const bridge = new SoulDockWorkspaceBridge(runtime.ctx, runtime.api)
  const listed = await bridge.list()
  const taskId = listed.workspaces[0].tasks[0].taskId
  await bridge.open({ taskId })

  assert.deepEqual(await bridge.cancel({ taskId }), { accepted: true })
  assert.equal(runtime.calls.cancel[0].payload.sessionId, OWNED_SESSION)
  assert.deepEqual(bridge.close({ taskId }), { closed: true })
  await assert.rejects(() => bridge.poll({ taskId, afterSequence: 0, timeoutMilliseconds: 0 }), /missing or expired/)
  bridge.dispose()
})

test('workspace RPC routes preserve the protected double application envelope', async () => {
  const calls = []
  const workspace = {
    list: async () => { calls.push('list'); return { version: 1, workspaces: [] } },
    create: async payload => { calls.push(['create', payload]); return { version: 1, task: { taskId: 'task-one' } } },
    open: async payload => { calls.push(['open', payload]); return { version: 1, task: { taskId: payload.taskId } } },
    send: async payload => { calls.push(['send', payload]); return { accepted: true } },
    poll: async payload => { calls.push(['poll', payload]); return { version: 1, sequence: 0, status: 'idle', events: [] } },
    cancel: async payload => { calls.push(['cancel', payload]); return { accepted: true } },
    close: payload => { calls.push(['close', payload]); return { closed: true } },
  }
  const rpc = createSoulDockRpcHandler({}, undefined, workspace)
  const signal = new AbortController().signal
  const listed = await rpc('workspace/list', {}, signal)
  assert.deepEqual(listed, { ok: true, value: { ok: true, value: { version: 1, workspaces: [] } } })
  const opened = await rpc('workspace/task/open', { taskId: 'task-one' }, signal)
  assert.equal(opened.value.ok, true)
  const invalid = await rpc('workspace/list', { sessionId: 'arbitrary' }, signal)
  assert.equal(invalid.value.ok, false)
  assert.deepEqual(calls, ['list', ['open', { taskId: 'task-one' }]])
})
