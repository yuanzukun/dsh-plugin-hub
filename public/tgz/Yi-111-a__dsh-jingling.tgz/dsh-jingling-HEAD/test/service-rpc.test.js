import assert from 'node:assert/strict'
import test from 'node:test'

import { createSoulDockRpcHandler } from '../src/rpc.js'
import { SoulDockService } from '../src/service.js'

function memoryGlobal(initial) {
  let value = structuredClone(initial)
  return {
    get: () => structuredClone(value),
    set: async next => { value = structuredClone(next) },
    inspect: () => structuredClone(value),
  }
}

test('service writes durable state before resolving and survives reconstruction', async () => {
  const { createDefaultState } = await import('../src/core.js')
  const global = memoryGlobal(createDefaultState(0))
  const service = new SoulDockService(global)
  await service.initialize()
  await service.createMemory({ content: '用户喜欢爵士乐', kind: 'preference', subject: 'music', sourceSummary: 'manual UI' })
  assert.match(JSON.stringify(global.inspect()), /爵士乐/)
  const reconstructed = new SoulDockService(global)
  assert.equal(reconstructed.recall('爵士').length, 1)
})

test('assistant proposals stay in process memory until loopback UI confirmation', async () => {
  const { createDefaultState } = await import('../src/core.js')
  const global = memoryGlobal(createDefaultState(Date.parse('2026-01-01T00:00:00Z')))
  const service = new SoulDockService(global)
  await service.initialize()
  const proposed = await service.propose({
    content: 'User likes jazz', kind: 'preference', subject: 'music', sourceSummary: 'User said this directly',
  })
  assert.equal(proposed.durable, false)
  assert.equal(global.inspect().proposals.length, 0)
  assert.doesNotMatch(JSON.stringify(global.inspect()), /User likes jazz/)
  assert.equal(service.clientState().proposals.length, 1)

  const reconstructed = new SoulDockService(global)
  await reconstructed.initialize()
  assert.equal(reconstructed.clientState().proposals.length, 0)

  await service.confirmProposal(proposed.proposal.id)
  assert.equal(service.clientState().proposals.length, 0)
  assert.match(JSON.stringify(global.inspect()), /User likes jazz/)
  assert.equal(service.recall('jazz').length, 1)
})

test('service initialization durably scrubs unsafe legacy pending data', async () => {
  const { createDefaultState } = await import('../src/core.js')
  const initial = createDefaultState(Date.parse('2026-01-01T00:00:00Z'))
  const baseProposal = {
    id: 'proposal_legacy', personaId: 'lingqi', content: 'User likes jazz', kind: 'preference',
    sensitivity: 'standard', subject: 'music', sourceSummary: 'User said this directly',
    reason: 'Future continuity', salience: 0.5, createdAt: '2026-01-01T00:00:00.000Z',
    expiresAt: '2000-01-01T00:00:00.000Z',
  }
  initial.proposals = [
    baseProposal,
    {
      ...baseProposal,
      id: 'proposal_private_legacy',
      content: 'User diagnosis: diabetes; medication daily',
      expiresAt: '2999-01-01T00:00:00.000Z',
    },
  ]
  initial.personas.push({
    ...initial.personas[0], id: 'persona_minor_legacy', name: 'Legacy', firstMessage: 'I am a 16-year-old high schooler',
  })
  initial.activePersonaId = 'persona_minor_legacy'
  initial.settings.adultConfirmed = true
  initial.relationship.style = 'romantic'
  initial.relationship.label = '浪漫伙伴'

  const global = memoryGlobal(initial)
  const service = new SoulDockService(global)
  await service.initialize()
  const persisted = global.inspect()
  assert.equal(persisted.proposals.length, 0)
  assert.equal(persisted.personas.some(item => item.id === 'persona_minor_legacy'), false)
  assert.equal(persisted.activePersonaId, 'lingqi')
  assert.equal(persisted.settings.adultConfirmed, false)
  assert.equal(persisted.relationship.style, 'companion')
})

test('atomic proactive admission prevents concurrent sessions exceeding the global budget', async () => {
  const { createDefaultState, updateSettings } = await import('../src/core.js')
  const now = Date.parse('2026-08-14T12:00:00Z')
  const configured = updateSettings(createDefaultState(0), { proactive: {
    enabled: true, dailyLimit: 1, idleAfterMinutes: 30, minimumGapMinutes: 60,
    quietHoursStart: '00:00', quietHoursEnd: '00:00', timeZone: 'UTC',
  } }, { now: now - 1000 })
  const service = new SoulDockService(memoryGlobal(configured))
  const results = await Promise.all([
    service.admitCheckIn('session-a', now - 3600000, now),
    service.admitCheckIn('session-b', now - 3600000, now),
  ])
  assert.equal(results.filter(item => item.allowed).length, 1)
  assert.equal(service.read().proactiveHistory.length, 1)
})

test('RPC uses application envelope, validates confirmation, and never leaks a thrown transport error', async () => {
  const calls = []
  const service = {
    clientState: () => ({ ready: true }),
    privateArchive: () => ({ secret: true }),
    resetAll: async () => { calls.push('reset'); return { reset: true } },
  }
  const rpc = createSoulDockRpcHandler(service)
  const signal = new AbortController().signal
  assert.deepEqual(await rpc('state/get', {}, signal), { ok: true, value: { ok: true, value: { ready: true } } })
  const denied = await rpc('data/reset', { confirm: 'no' }, signal)
  assert.equal(denied.ok, true)
  assert.equal(denied.value.ok, false)
  assert.equal(calls.length, 0)
  const exported = await rpc('export/private-archive', { confirm: 'PRIVATE_EXPORT' }, signal)
  assert.equal(exported.value.value.secret, true)
})

test('cancelled RPC fails closed inside the protected envelope', async () => {
  const controller = new AbortController()
  controller.abort()
  const rpc = createSoulDockRpcHandler({ clientState: () => ({}) })
  const result = await rpc('state/get', {}, controller.signal)
  assert.equal(result.ok, true)
  assert.equal(result.value.ok, false)
  assert.match(result.value.error.message, /cancelled/)
})

test('sidecar status is a narrow DTO and never exposes memory or persona prompt fields', async () => {
  const { createDefaultState } = await import('../src/core.js')
  const global = memoryGlobal(createDefaultState(0))
  const service = new SoulDockService(global)
  await service.initialize()
  await service.createMemory({
    content: 'SIDECAR_PRIVATE_MARKER_7281',
    kind: 'fact',
    subject: 'sidecar audit',
    sourceSummary: 'Manual UI',
  })
  service.publishActivity(
    { phase: 'working', detail: 'DSH is calling a tool' },
    'tool/call',
    { sessionId: 'session-safe-1' },
  )

  const status = service.sidecarStatus()
  const serialized = JSON.stringify(status)
  assert.equal(status.runtime.phase, 'working')
  assert.equal(status.capabilities.assistantText, false)
  assert.doesNotMatch(serialized, /SIDECAR_PRIVATE_MARKER_7281|"memories":|"proposals":|"personality":|"scenario":/)
  assert.equal(service.publishAssistantMessage({ text: 'not opted in' }), false)
})

test('sidecar long poll wakes on activity and opt-in assistant text remains ephemeral', async () => {
  const { createDefaultState } = await import('../src/core.js')
  const service = new SoulDockService(memoryGlobal(createDefaultState(0)), { shareAssistantText: true })
  await service.initialize()

  const waiting = service.pollSidecar(0, 1000, new AbortController().signal)
  service.publishActivity(
    { phase: 'thinking', detail: 'DSH is thinking' },
    'step/start',
    { sessionId: 'session-safe-2' },
  )
  const activity = await waiting
  assert.equal(activity.events.length, 1)
  assert.equal(activity.events[0].type, 'activity')

  const cursor = activity.sequence
  assert.equal(service.publishAssistantMessage({
    sessionId: 'session-safe-2',
    messageId: 'session-safe-2:4',
    text: 'Hello from the assistant',
  }), true)
  const message = await service.pollSidecar(cursor, 0)
  assert.deepEqual(message.events.map(event => event.type), ['assistant-message'])
  assert.equal(message.events[0].text, 'Hello from the assistant')

  const reconstructed = new SoulDockService(service.globalState, { shareAssistantText: true })
  await reconstructed.initialize()
  assert.equal(reconstructed.sidecarStatus().sequence, 0)
  assert.equal((await reconstructed.pollSidecar(0, 0)).events.length, 0)
})

test('sidecar RPC endpoints preserve the DSH application envelope', async () => {
  const { createDefaultState } = await import('../src/core.js')
  const service = new SoulDockService(memoryGlobal(createDefaultState(0)))
  await service.initialize()
  const rpc = createSoulDockRpcHandler(service)
  const signal = new AbortController().signal

  const status = await rpc('sidecar/status', {}, signal)
  assert.equal(status.ok, true)
  assert.equal(status.value.ok, true)
  assert.equal(status.value.value.version, 1)
  const poll = await rpc('sidecar/poll', { afterSequence: 0, timeoutMilliseconds: 0 }, signal)
  assert.deepEqual(poll.value.value.events, [])
})

test('launching the sidecar refuses to spawn when the same executable is already running', async () => {
  const { createDefaultState } = await import('../src/core.js')
  const service = new SoulDockService(memoryGlobal(createDefaultState(0)))
  await service.initialize()

  // The test runner itself is a running `node.exe`, so a live process with
  // the same executable name must be detected and no second instance spawned
  // (a second portable exe would fail its single-instance lock with a native
  // error dialog).
  const result = service.launchSidecar(process.execPath)
  assert.equal(result.launched, false)
  assert.equal(result.alreadyRunning, true)
  assert.equal(service.sidecar.process, undefined)
})
