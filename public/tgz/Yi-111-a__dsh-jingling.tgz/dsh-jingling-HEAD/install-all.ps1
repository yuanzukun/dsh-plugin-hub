#Requires -Version 7
<#
.SYNOPSIS
  一键安装鲸灵插件 + 构建 Windows 桌面伙伴 sidecar，并接入 DSH web profile。
.DESCRIPTION
  1. 安装插件依赖并跑测试/构建
  2. 进入 sidecar/ 安装依赖并构建 portable exe
  3. 打包插件为 tgz
  4. 安装到 DSH web profile（如未指定则使用 web）
  5. 安装 agent preset
  完成后在 DSH Web 的鲸灵页面点击“打开桌面伙伴”即可。
#>
param(
  [string]$Profile = 'web'
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$sidecar = Join-Path $root 'sidecar'

function Step-Run($title, $script) {
  Write-Host "`n▶ $title" -ForegroundColor Cyan
  & $script
  if ($LASTEXITCODE -ne 0) { throw "$title failed" }
}

Step-Run '安装插件依赖' { npm install --ignore-scripts }
Step-Run '插件测试与构建' { npm run check }

if (-not (Test-Path $sidecar)) { throw "sidecar/ 目录不存在" }
Step-Run '构建桌面伙伴 sidecar' {
  Set-Location $sidecar
  npm ci
  npm run dist:win
  Set-Location $root
}

Step-Run '打包插件' { npm pack --ignore-scripts }

$tgz = Get-ChildItem -Path $root -Filter 'dsh-jingling-*.tgz' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $tgz) { throw "找不到打包好的 dsh-jingling-*.tgz" }
Write-Host "  打包产物: $($tgz.Name)" -ForegroundColor Gray

Step-Run "安装插件到 DSH profile: $Profile" { dsh plugin --profile $Profile add $tgz.FullName }
Step-Run '安装 agent preset' { npm run install:preset }

Write-Host "`n✅ 安装完成。" -ForegroundColor Green
Write-Host "   启动 DSH:  dsh --profile $Profile" -ForegroundColor White
Write-Host "   或直接:    npx @deepseek-ai/dsh $Profile" -ForegroundColor White
Write-Host "   然后在鲸灵页面点击“打开桌面伙伴”。" -ForegroundColor White
