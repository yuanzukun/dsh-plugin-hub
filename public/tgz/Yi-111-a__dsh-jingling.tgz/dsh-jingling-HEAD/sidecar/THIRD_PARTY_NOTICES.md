# Third-party notices

This file covers source and assets intentionally reused by Jingling Sidecar.
Exact versions and SHA-256 values are recorded in `upstream.lock.json` and the
npm-generated `package-lock.json`.

## AIRI desktop overlay reference

Source: <https://github.com/moeru-ai/airi>

Referenced file: `apps/stage-tamagotchi/src/main/windows/desktop-overlay/window-contract.ts`

Pinned commit: `71dd65cb99b14eb24602eecfa43f0e571f011a13`

Use in this project: `electron/window-contract.ts` is directly adapted from
the transparent, non-focus-stealing Electron window contract. No AIRI model,
image, audio, character, or local dirty-worktree change is included.

### AIRI VRM interaction migration

Pinned commit: `cc791fab954fbcfbef0bcb8d49ff75514f549c74`

The following committed MIT source was migrated from the clean pinned clone:

- `packages/stage-ui-three/src/composables/vrm/interaction.ts` ->
  `src/renderer/upstream/airi/vrm-interaction.ts` (normalized humanoid hit
  regions, invisible colliders, target-name mapping, and click threshold).
- `packages/stage-ui-three/src/components/ThreeScene.vue` -> the raycasting
  integration in `src/renderer/adapters/vrm.ts`.
- `packages/stage-ui-three/src/composables/vrm/interaction.test.ts` ->
  `test/vrm-interaction.test.ts`, converted to Node's test runner and extended
  with collider lifecycle coverage.

Jingling's generic `AvatarHost` delegation and body-bounds hit test are
project-specific integration code. No AIRI VRM, animation, HDRI, image, audio,
character, or other asset is copied or distributed by this migration.

### AIRI conversation and Controls Island adaptation

Pinned commit: `cc791fab954fbcfbef0bcb8d49ff75514f549c74`

Jingling also adapts the user-interface structure and interaction patterns from
these committed MIT files:

- `apps/stage-tamagotchi/src/renderer/components/InteractiveArea.vue`
- `apps/stage-tamagotchi/src/renderer/components/stage-islands/controls-island/index.vue`
- `apps/stage-tamagotchi/src/renderer/pages/chat.vue`
- `apps/stage-tamagotchi/src/main/windows/chat/index.ts`

Their exact SHA-256 values and destination-file mappings are recorded in
`upstream.lock.json`. AIRI currently opens chat from Controls Island into a
separate window, while character clicks trigger reactions. Jingling deliberately
combines those two paths: a click-like avatar gesture opens a character-attached
panel, and the collapsed state renders only the avatar. Vue/Pinia provider
stores, analytics, authentication, MCP, attachment handling and AIRI model
assets were not copied; the adapted UI talks only to Jingling's filtered DSH
chat port.

```text
MIT License

Copyright (c) 2024-PRESENT Neko Ayaka

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Jingling bundled avatar — user authorization

The sole bundled character asset is
`src/renderer/assets/jingling/jingling-idle.png`: the exact transparent
top-left character cell from an image supplied by the user in this Codex
session. On 2026-08-14 the user expressly authorized its public use for
`Yi-111-a/jingling`.

Its SHA-256 is
`A6E4F3D40D4195BE7ECA211A504EDD99C48DCBBB708A0F8BE4537600B390B9EE`.
The public renderer displays it as a stable still image. No other character
image, frame, Sprite Sheet, animation asset, or model is included in this
source tree or production renderer output. See `UPSTREAM_AUTHORIZATION.md`
and `upstream.lock.json` for the exact selection and authorization scope.

Jingling must not be presented as an official DeepSeek character, DeepSeek
application, or affiliated product.

## Runtime libraries

The shipped renderer and Electron application use these permissively licensed
projects as pinned npm dependencies:

- Electron, MIT, <https://github.com/electron/electron>
- PixiJS, MIT, <https://github.com/pixijs/pixijs>
- three.js, MIT, <https://github.com/mrdoob/three.js>
- `@pixiv/three-vrm`, MIT, <https://github.com/pixiv/three-vrm>
- Zod, MIT, <https://github.com/colinhacks/zod>

Build-only dependencies are recorded in `package.json` and
`package-lock.json`. Their license files remain available in the corresponding
npm packages during source builds.

## Optional external VOICEVOX compatibility

Jingling includes an independently written loopback client for the official
VOICEVOX Engine `audio_query` and `synthesis` endpoints. It does not copy or
redistribute VOICEVOX Engine, the VOICEVOX application, voice libraries, or
character assets.

- Engine source and license: <https://github.com/VOICEVOX/voicevox_engine>
- Engine API: <https://voicevox.github.io/voicevox_engine/api/>
- VOICEVOX terms: <https://voicevox.hiroshiba.jp/term/>

Users who enable this optional provider must install the engine separately,
follow the selected voice library and character terms, and provide any
required VOICEVOX credit.

## Optional external edge-tts compatibility

Jingling can optionally invoke a Python `edge-tts` installation that is
already present on the user's own machine. It does not copy, distribute,
install, link against, or bundle `edge-tts`, Python, Microsoft voice assets,
or credentials. The integration passes only the selected voice and bounded
plain text to `python -m edge_tts` through a no-shell process invocation.

- Source and license: <https://github.com/rany2/edge-tts>
- Usage documentation: <https://github.com/rany2/edge-tts#usage>

Users who enable this optional online provider are responsible for obtaining
and maintaining the Python package, reviewing its LGPLv3 terms, and complying
with the applicable Microsoft service and voice terms. Jingling automatically
falls back to the system SpeechSynthesis provider if that optional process or
its playback fails.

## Explicit exclusions

Jingling Sidecar does not distribute Live2D Cubism Core, the Cubism SDK,
Live2D sample models, VRM models, AIRI character assets, Python, `edge-tts`,
provider API keys, or third-party voices. Users are responsible for the
licenses of assets they choose through the optional adapter interfaces.
