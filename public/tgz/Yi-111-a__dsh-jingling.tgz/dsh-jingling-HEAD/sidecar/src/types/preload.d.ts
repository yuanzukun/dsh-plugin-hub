import type { SidecarViewState } from '../core/poller'
import type { RendererVoiceBridge } from '../core/voice-config'
import type { SidecarChatPort } from '../core/chat-controller'
import type { SidecarWorkspacePort } from '../core/workspace-controller'

declare global {
  interface Window {
    soulDockSidecar: {
      getState: () => Promise<SidecarViewState>
      readAvatarFrames: () => Promise<Record<string, string> | undefined>
      setPetInteractive: (interactive: boolean) => Promise<void>
      setConversationOpen: (open: boolean) => Promise<void>
      quit: () => Promise<void>
      voice: RendererVoiceBridge
      chat: SidecarChatPort
      workspace: SidecarWorkspacePort
      onState: (listener: (state: SidecarViewState) => void) => () => void
    }
  }
}

export {}
